import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useMemo as n, useState as r } from "react";
import { useFxAnchor as i } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as a } from "@bgparty/sdk/fx/delta-number";
import { useT as o } from "@bgparty/sdk/i18n";
import { IconInfo as s } from "@bgparty/sdk/icons";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { HintRing as l } from "@bgparty/sdk/ui/hint-ring";
import { LogTicker as u } from "@bgparty/sdk/ui/log-sheet";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as f } from "@bgparty/sdk/ui/player-strip";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { Floater as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { playSettle as v } from "@bgparty/sdk/sfx";
import { GameOverScreen as y } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/decko/cards.ts
var b = [
	{
		id: "s0",
		rank: 2,
		suit: "S",
		starter: !0
	},
	{
		id: "s1",
		rank: 2,
		suit: "H",
		starter: !0
	},
	{
		id: "s2",
		rank: 3,
		suit: "D",
		starter: !0
	},
	{
		id: "s3",
		rank: 3,
		suit: "H",
		starter: !0
	},
	{
		id: "s4",
		rank: 4,
		suit: "C",
		starter: !0
	},
	{
		id: "s5",
		rank: 4,
		suit: "D",
		starter: !0
	},
	{
		id: "s6",
		rank: 5,
		suit: "S",
		starter: !0
	},
	{
		id: "s7",
		rank: 5,
		suit: "H",
		starter: !0
	},
	{
		id: "s8",
		rank: 6,
		suit: "D",
		starter: !0
	},
	{
		id: "s9",
		rank: 6,
		suit: "C",
		starter: !0
	},
	{
		id: "s10",
		rank: 7,
		suit: "S",
		starter: !0
	},
	{
		id: "s11",
		rank: 7,
		suit: "D",
		starter: !0
	},
	{
		id: "s12",
		rank: 8,
		suit: "D",
		starter: !0
	},
	{
		id: "s13",
		rank: 8,
		suit: "C",
		starter: !0
	}
], ee = [
	{
		id: "m0",
		rank: 14,
		suit: "D",
		assistAce: !0
	},
	{
		id: "m1",
		rank: 14,
		suit: "C",
		assistAce: !0
	},
	{
		id: "m2",
		rank: 14,
		suit: "S",
		assistAce: !0
	},
	{
		id: "m3",
		rank: 14,
		suit: "H",
		assistAce: !0
	},
	{
		id: "m4",
		rank: 2,
		suit: "H",
		onReveal: "crypto"
	},
	{
		id: "m5",
		rank: 2,
		suit: "S",
		onReveal: "crypto"
	},
	{
		id: "m6",
		rank: 2,
		suit: "C",
		onReveal: "crypto"
	},
	{
		id: "m7",
		rank: 2,
		suit: "D",
		onReveal: "crypto"
	},
	{
		id: "m8",
		rank: 3,
		suit: "H",
		onAcquire: "voucher"
	},
	{
		id: "m9",
		rank: 3,
		suit: "S",
		onAcquire: "voucher"
	},
	{
		id: "m10",
		rank: 3,
		suit: "C",
		onAcquire: "voucher"
	},
	{
		id: "m11",
		rank: 3,
		suit: "D",
		onAcquire: "voucher"
	},
	{
		id: "m12",
		rank: 4,
		suit: "H",
		junkFood: !0
	},
	{
		id: "m13",
		rank: 4,
		suit: "S",
		junkFood: !0
	},
	{
		id: "m14",
		rank: 4,
		suit: "C",
		junkFood: !0
	},
	{
		id: "m15",
		rank: 4,
		suit: "D",
		junkFood: !0
	},
	{
		id: "m16",
		rank: 5,
		suit: "H",
		onReveal: "chip1"
	},
	{
		id: "m17",
		rank: 5,
		suit: "S",
		onReveal: "chip1"
	},
	{
		id: "m18",
		rank: 5,
		suit: "D",
		onReveal: "chip1"
	},
	{
		id: "m19",
		rank: 5,
		suit: "C",
		onAcquire: "smolder1"
	},
	{
		id: "m20",
		rank: 6,
		suit: "H",
		onReveal: "credit"
	},
	{
		id: "m21",
		rank: 6,
		suit: "D",
		onAcquire: "smolder1"
	},
	{
		id: "m22",
		rank: 6,
		suit: "S",
		altRank: 5
	},
	{
		id: "m23",
		rank: 6,
		suit: "C",
		altRank: 7
	},
	{
		id: "m24",
		rank: 7,
		suit: "H",
		onAcquire: "smolder1"
	},
	{
		id: "m25",
		rank: 7,
		suit: "S",
		doubleAs: {
			rank: 14,
			suit: "S"
		}
	},
	{
		id: "m26",
		rank: 7,
		suit: "C",
		doubleAs: {
			rank: 14,
			suit: "C"
		}
	},
	{
		id: "m27",
		rank: 7,
		suit: "D",
		doubleAs: {
			rank: 9,
			suit: "H"
		}
	},
	{
		id: "m28",
		rank: 8,
		suit: "H"
	},
	{
		id: "m29",
		rank: 8,
		suit: "S"
	},
	{
		id: "m30",
		rank: 8,
		suit: "C"
	},
	{
		id: "m31",
		rank: 8,
		suit: "D"
	},
	{
		id: "m32",
		rank: 9,
		suit: "H",
		onReveal: "chip2"
	},
	{
		id: "m33",
		rank: 9,
		suit: "C",
		onReveal: "chip2"
	},
	{
		id: "m34",
		rank: 9,
		suit: "D",
		onAcquire: "smolder2"
	},
	{
		id: "m35",
		rank: 9,
		suit: "S",
		doubleAs: {
			rank: 9,
			suit: "S"
		}
	},
	{
		id: "m36",
		rank: 10,
		suit: "S",
		onReveal: "credit"
	},
	{
		id: "m37",
		rank: 10,
		suit: "H",
		doubleAs: {
			rank: 10,
			suit: "H"
		}
	},
	{
		id: "m38",
		rank: 10,
		suit: "C",
		altRank: 9
	},
	{
		id: "m39",
		rank: 10,
		suit: "D",
		doubleAs: {
			rank: 11,
			suit: "D"
		}
	},
	{
		id: "m40",
		rank: 11,
		suit: "S",
		altRank: 3,
		jovial: !0
	},
	{
		id: "m41",
		rank: 11,
		suit: "C",
		altRank: 4,
		jovial: !0
	},
	{
		id: "m42",
		rank: 11,
		suit: "D",
		altRank: 5,
		jovial: !0
	},
	{
		id: "m43",
		rank: 11,
		suit: "H",
		altRank: 2,
		jovial: !0
	},
	{
		id: "m44",
		rank: 12,
		suit: "H",
		queen: "pyro"
	},
	{
		id: "m45",
		rank: 12,
		suit: "S",
		queen: "dumpster"
	},
	{
		id: "m46",
		rank: 12,
		suit: "C",
		queen: "shopping"
	},
	{
		id: "m47",
		rank: 12,
		suit: "D",
		queen: "bridge"
	},
	{
		id: "m48",
		rank: 13,
		suit: "C",
		onReveal: "richKing"
	},
	{
		id: "m49",
		rank: 13,
		suit: "D",
		onReveal: "richKing"
	},
	{
		id: "m50",
		rank: 13,
		suit: "H",
		onReveal: "richKing"
	},
	{
		id: "m51",
		rank: 13,
		suit: "S",
		onReveal: "richKing"
	}
], x = Object.fromEntries([...b, ...ee].map((e) => [e.id, e])), S = Object.fromEntries([
	{
		id: "fortuneTeller",
		type: "deal",
		cost: 1
	},
	{
		id: "mulligan",
		type: "deal",
		cost: 4
	},
	{
		id: "hobo",
		type: "deal",
		cost: 1
	},
	{
		id: "magicHat",
		type: "deal",
		cost: 7
	},
	{
		id: "babyJoker",
		type: "deal",
		cost: 1
	},
	{
		id: "merlin",
		type: "deal",
		cost: 3
	},
	{
		id: "garbagePailBoy",
		type: "deal",
		cost: 4
	},
	{
		id: "redJester",
		type: "raise",
		cost: 1
	},
	{
		id: "mrJackpot",
		type: "raise",
		cost: 1
	},
	{
		id: "sewerClown",
		type: "raise",
		cost: 4
	},
	{
		id: "whiteClown",
		type: "raise",
		cost: 4
	},
	{
		id: "witch",
		type: "raise",
		cost: 1
	},
	{
		id: "tableTalker",
		type: "raise",
		cost: 1
	},
	{
		id: "vampire",
		type: "call",
		cost: 3
	},
	{
		id: "coolCat",
		type: "call",
		cost: 5
	},
	{
		id: "fishbait",
		type: "call",
		cost: 2
	},
	{
		id: "monochroma",
		type: "call",
		cost: 0
	},
	{
		id: "blackKnight",
		type: "call",
		cost: 2
	},
	{
		id: "kingmaker",
		type: "call",
		cost: 0
	},
	{
		id: "devil",
		type: "burn",
		cost: 6
	},
	{
		id: "marshmallow",
		type: "burn",
		cost: 3
	},
	{
		id: "burningMan",
		type: "burn",
		cost: 2
	},
	{
		id: "harlequin",
		type: "burn",
		cost: 0
	},
	{
		id: "dumpsterFire",
		type: "burn",
		cost: 2
	},
	{
		id: "minmaxer",
		type: "burn",
		cost: 6
	},
	{
		id: "sadClown",
		type: "fold",
		cost: 0
	},
	{
		id: "taxman",
		type: "fold",
		cost: 0
	},
	{
		id: "gun",
		type: "fold",
		cost: 0
	},
	{
		id: "patchface",
		type: "fold",
		cost: 0
	},
	{
		id: "robin",
		type: "fold",
		cost: 0
	},
	{
		id: "analysisParalysis",
		type: "fold",
		cost: 2
	},
	{
		id: "cherry",
		type: "buy",
		cost: 0
	},
	{
		id: "saleswoman",
		type: "buy",
		cost: 2
	},
	{
		id: "chipGirl",
		type: "buy",
		cost: 3
	},
	{
		id: "pizzaTime",
		type: "buy",
		cost: 2
	},
	{
		id: "energyDrink",
		type: "buy",
		cost: 2
	},
	{
		id: "toilet",
		type: "buy",
		cost: 0
	}
].map((e) => [e.id, e])), C = [
	"fortuneTeller",
	"harlequin",
	"pizzaTime",
	"patchface",
	"robin"
], w = [
	{
		id: "holdem",
		color: "red"
	},
	{
		id: "clownCar",
		color: "red"
	},
	{
		id: "lowball",
		color: "red"
	},
	{
		id: "stud",
		color: "red"
	},
	{
		id: "tcg",
		color: "red"
	},
	{
		id: "deckorama",
		color: "red"
	},
	{
		id: "friedChicken",
		color: "red"
	},
	{
		id: "inferno",
		color: "blue"
	},
	{
		id: "purge",
		color: "blue"
	},
	{
		id: "battleRoyale",
		color: "blue"
	},
	{
		id: "lowSum",
		color: "blue"
	},
	{
		id: "solo",
		color: "blue"
	},
	{
		id: "proTable",
		color: "blue"
	},
	{
		id: "penultimo",
		color: "blue"
	}
];
function T(e) {
	return e <= 3 ? [1, 5] : e <= 7 ? [2, 7] : e <= 11 ? [3, 9] : [5, 12];
}
var te = {
	4: "red",
	8: "blue"
}, E = [5, 9], D = (e) => e >= 5 ? 70 : 60, O = [
	4,
	3,
	2,
	1,
	0
], ne = {
	fortuneTeller: "games.decko.jokerFortuneTeller",
	mulligan: "games.decko.jokerMulligan",
	hobo: "games.decko.jokerHobo",
	magicHat: "games.decko.jokerMagicHat",
	babyJoker: "games.decko.jokerBabyJoker",
	merlin: "games.decko.jokerMerlin",
	garbagePailBoy: "games.decko.jokerGarbagePailBoy",
	redJester: "games.decko.jokerRedJester",
	mrJackpot: "games.decko.jokerMrJackpot",
	sewerClown: "games.decko.jokerSewerClown",
	whiteClown: "games.decko.jokerWhiteClown",
	witch: "games.decko.jokerWitch",
	tableTalker: "games.decko.jokerTableTalker",
	vampire: "games.decko.jokerVampire",
	coolCat: "games.decko.jokerCoolCat",
	fishbait: "games.decko.jokerFishbait",
	monochroma: "games.decko.jokerMonochroma",
	blackKnight: "games.decko.jokerBlackKnight",
	kingmaker: "games.decko.jokerKingmaker",
	devil: "games.decko.jokerDevil",
	marshmallow: "games.decko.jokerMarshmallow",
	burningMan: "games.decko.jokerBurningMan",
	harlequin: "games.decko.jokerHarlequin",
	dumpsterFire: "games.decko.jokerDumpsterFire",
	minmaxer: "games.decko.jokerMinmaxer",
	sadClown: "games.decko.jokerSadClown",
	taxman: "games.decko.jokerTaxman",
	gun: "games.decko.jokerGun",
	patchface: "games.decko.jokerPatchface",
	robin: "games.decko.jokerRobin",
	analysisParalysis: "games.decko.jokerAnalysisParalysis",
	cherry: "games.decko.jokerCherry",
	saleswoman: "games.decko.jokerSaleswoman",
	chipGirl: "games.decko.jokerChipGirl",
	pizzaTime: "games.decko.jokerPizzaTime",
	energyDrink: "games.decko.jokerEnergyDrink",
	toilet: "games.decko.jokerToilet"
}, re = Object.fromEntries(Object.entries(ne).map(([e, t]) => [e, `${t}D`])), ie = {
	holdem: "games.decko.wcHoldem",
	clownCar: "games.decko.wcClownCar",
	lowball: "games.decko.wcLowball",
	stud: "games.decko.wcStud",
	tcg: "games.decko.wcTcg",
	deckorama: "games.decko.wcDeckorama",
	friedChicken: "games.decko.wcFriedChicken",
	inferno: "games.decko.wcInferno",
	purge: "games.decko.wcPurge",
	battleRoyale: "games.decko.wcBattleRoyale",
	lowSum: "games.decko.wcLowSum",
	solo: "games.decko.wcSolo",
	proTable: "games.decko.wcProTable",
	penultimo: "games.decko.wcPenultimo"
}, ae = Object.fromEntries(Object.entries(ie).map(([e, t]) => [e, `${t}D`])), oe = {
	deal: "games.decko.jtypeDeal",
	raise: "games.decko.jtypeRaise",
	call: "games.decko.jtypeCall",
	burn: "games.decko.jtypeBurn",
	fold: "games.decko.jtypeFold",
	buy: "games.decko.jtypeBuy"
}, se = [
	"games.decko.hand0",
	"games.decko.hand1",
	"games.decko.hand2",
	"games.decko.hand3",
	"games.decko.hand4",
	"games.decko.hand5",
	"games.decko.hand6",
	"games.decko.hand7",
	"games.decko.hand8",
	"games.decko.hand9"
];
function ce(e) {
	let t = [];
	return e.assistAce && t.push("games.decko.effectAssistAce"), e.onReveal === "crypto" && t.push("games.decko.effectCrypto"), e.onReveal === "chip1" && t.push("games.decko.effectChip1"), e.onReveal === "chip2" && t.push("games.decko.effectChip2"), e.onReveal === "credit" && t.push("games.decko.effectCredit"), e.onReveal === "richKing" && t.push("games.decko.effectRichKing"), e.onAcquire === "voucher" && t.push("games.decko.effectVoucher"), e.onAcquire === "smolder1" && t.push("games.decko.effectSmolder1"), e.onAcquire === "smolder2" && t.push("games.decko.effectSmolder2"), e.junkFood && t.push("games.decko.effectJunkFood"), e.doubleAs && t.push("games.decko.effectDouble"), e.altRank !== void 0 && !e.jovial && t.push("games.decko.effectDissolving"), e.jovial && t.push("games.decko.effectJovial"), e.queen === "pyro" && t.push("games.decko.effectPyro"), e.queen === "dumpster" && t.push("games.decko.effectDumpster"), e.queen === "shopping" && t.push("games.decko.effectShopping"), e.queen === "bridge" && t.push("games.decko.effectBridge"), t;
}
//#endregion
//#region src/games/decko/eval.ts
function k(e, t) {
	if (e.setRank !== t.setRank) return e.setRank - t.setRank;
	let n = Math.max(e.tiebreak.length, t.tiebreak.length);
	for (let r = 0; r < n; r += 1) {
		let n = (e.tiebreak[r] ?? 0) - (t.tiebreak[r] ?? 0);
		if (n !== 0) return n;
	}
	return 0;
}
function le(e) {
	let t = e.length;
	if (t === 0) return null;
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t.rank, (n.get(t.rank) ?? 0) + 1);
	let r = [...n.entries()].sort((e, t) => t[1] - e[1] || t[0] - e[0]);
	if (t === 5) {
		let t = e.every((t) => t.suit === e[0].suit), i = 0;
		if (n.size === 5) {
			let e = [...n.keys()].sort((e, t) => e - t);
			e[4] - e[0] === 4 ? i = e[4] : e[0] === 2 && e[4] === 14 && (i = 5);
		}
		return t && i === 14 ? {
			setRank: 9,
			tiebreak: [14]
		} : t && i > 0 ? {
			setRank: 8,
			tiebreak: [i]
		} : t ? {
			setRank: 6,
			tiebreak: e.map((e) => e.rank).sort((e, t) => t - e)
		} : i > 0 ? {
			setRank: 5,
			tiebreak: [i]
		} : r[0][1] === 3 && r[1]?.[1] === 2 ? {
			setRank: 4,
			tiebreak: [r[0][0], r[1][0]]
		} : null;
	}
	return t === 4 ? r[0][1] === 4 ? {
		setRank: 7,
		tiebreak: [r[0][0]]
	} : r[0][1] === 2 && r[1]?.[1] === 2 ? {
		setRank: 2,
		tiebreak: r.map((e) => e[0]).sort((e, t) => t - e)
	} : null : t === 3 ? r[0][1] === 3 ? {
		setRank: 3,
		tiebreak: [r[0][0]]
	} : null : t === 2 ? r[0][1] === 2 ? {
		setRank: 1,
		tiebreak: [r[0][0]]
	} : null : {
		setRank: 0,
		tiebreak: [e[0].rank]
	};
}
function ue(e) {
	let t = [{
		rank: e.rank,
		suit: e.suit
	}];
	return e.doubleAs && t.push({ ...e.doubleAs }), t;
}
function de(e, t, n) {
	if (t.battleRoyale && e.rank >= 11) return [];
	let r = {
		faces: ue(e),
		def: e
	}, i = (e) => {
		let t = [{
			faces: ue(e),
			def: e
		}];
		return e.altRank !== void 0 && t.push({
			faces: [{
				rank: e.altRank,
				suit: e.suit
			}],
			def: e
		}), t;
	};
	if (!e.queen) return i(e);
	let a = [];
	if (e.queen === "pyro" && t.burnTop && a.push(x[t.burnTop]), e.queen === "dumpster" && t.discardTop && a.push(x[t.discardTop]), e.queen === "shopping") for (let e of t.marketSlots) a.push(x[e]);
	if (e.queen === "bridge") for (let t of n) t.suit === "D" && t.id !== e.id && a.push(t);
	return [r, ...a.flatMap(i)];
}
function A(e, t) {
	let n = e.filter((e) => !e.card.fromMarket || t.has(e.card.physId)), r = n.filter((e) => e.opt.def.onReveal === "crypto").length, i = r * r, a = 0, o = n.flatMap((e) => e.opt.faces);
	for (let e of n) {
		let t = e.opt.def.onReveal;
		if (t === "chip1") i += 1;
		else if (t === "chip2") i += 2;
		else if (t === "credit") a += 1;
		else if (t === "richKing") {
			let t = e.opt.faces[0].suit;
			i += o.filter((e) => e.suit === t).length;
		}
	}
	return {
		chips: i,
		credits: a
	};
}
function fe(e) {
	let t = 0;
	for (let n of e) if (!n.jovial) {
		if (n.altRank !== void 0 && n.rank <= 10) {
			t += Math.min(n.rank, n.altRank);
			continue;
		}
		n.rank <= 10 && (t += n.rank), n.doubleAs && n.doubleAs.rank <= 10 && (t += n.doubleAs.rank);
	}
	return t;
}
function j(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) {
		let e = n.get(t.rank) ?? [];
		e.push(t), n.set(t.rank, e);
	}
	let r = (e) => n.get(e)?.length ?? 0, i = [
		"S",
		"H",
		"D",
		"C"
	], a = [
		14,
		13,
		12,
		11,
		10,
		9,
		8,
		7,
		6,
		5,
		4,
		3,
		2
	], o = [];
	for (let e = 14; e >= 6; --e) o.push([
		e,
		e - 1,
		e - 2,
		e - 3,
		e - 4
	]);
	o.push([
		5,
		4,
		3,
		2,
		14
	]);
	let s = (e) => e[0] === 5 ? 5 : e[0];
	for (let n of i) for (let r of o) {
		let i = /* @__PURE__ */ new Set(), a = [];
		for (let t of e) t.suit === n && r.includes(t.rank) && !i.has(t.rank) && (i.add(t.rank), a.push(t));
		if (5 - i.size <= t) {
			let e = s(r), t = e === 14 ? 9 : 8, o = r.filter((e) => !i.has(e)).map((e) => ({
				rank: e,
				suit: n,
				physId: "$wild"
			}));
			return {
				setRank: t,
				tiebreak: [e],
				faces: [...a, ...o]
			};
		}
	}
	for (let e of a) {
		let i = 4 - r(e);
		if (i <= t && i >= 0 && r(e) + t >= 4) {
			let t = (n.get(e) ?? []).slice(0, 4), r = Array.from({ length: Math.max(0, 4 - t.length) }, () => ({
				rank: e,
				suit: "S",
				physId: "$wild"
			}));
			return {
				setRank: 7,
				tiebreak: [e],
				faces: [...t, ...r]
			};
		}
	}
	let c = null;
	for (let n of i) {
		let r = e.filter((e) => e.suit === n).sort((e, t) => t.rank - e.rank);
		if (r.length + t < 5) continue;
		let i = r.slice(0, 5), o = new Set(i.map((e) => e.rank)), s = i.map((e) => e.rank), l = [];
		for (let e of a) {
			if (s.length >= 5) break;
			o.has(e) || (s.push(e), l.push({
				rank: e,
				suit: n,
				physId: "$wild"
			}));
		}
		let u = {
			setRank: 6,
			tiebreak: s,
			faces: [...i, ...l]
		};
		(!c || k(u, c) > 0) && (c = u);
	}
	if (c) return c;
	for (let e of o) if (e.filter((e) => r(e) === 0).length <= t) {
		let t = [];
		for (let r of e) {
			let e = (n.get(r) ?? [])[0];
			e ? t.push(e) : t.push({
				rank: r,
				suit: "S",
				physId: "$wild"
			});
		}
		return {
			setRank: 5,
			tiebreak: [s(e)],
			faces: t
		};
	}
	for (let e of a) for (let i of a) {
		if (e === i || Math.max(0, 3 - r(e)) + Math.max(0, 2 - r(i)) > t) continue;
		let a = [...(n.get(e) ?? []).slice(0, 3), ...(n.get(i) ?? []).slice(0, 2)], o = 5 - a.length;
		for (let t = 0; t < o; t += 1) a.push({
			rank: t < 3 - r(e) ? e : i,
			suit: "S",
			physId: "$wild"
		});
		return {
			setRank: 4,
			tiebreak: [e, i],
			faces: a
		};
	}
	for (let e of a) if (Math.max(0, 3 - r(e)) <= t && r(e) >= 1) {
		let t = (n.get(e) ?? []).slice(0, 3);
		for (; t.length < 3;) t.push({
			rank: e,
			suit: "S",
			physId: "$wild"
		});
		return {
			setRank: 3,
			tiebreak: [e],
			faces: t
		};
	}
	for (let e = 0; e < a.length; e += 1) for (let i = e + 1; i < a.length; i += 1) {
		let o = a[e], s = a[i];
		if (Math.max(0, 2 - r(o)) + Math.max(0, 2 - r(s)) > t) continue;
		let c = [...(n.get(o) ?? []).slice(0, 2), ...(n.get(s) ?? []).slice(0, 2)];
		for (; c.length < 4;) c.push({
			rank: c.filter((e) => e.rank === o).length < 2 ? o : s,
			suit: "S",
			physId: "$wild"
		});
		return {
			setRank: 2,
			tiebreak: [o, s],
			faces: c
		};
	}
	for (let e of a) if (Math.max(0, 2 - r(e)) <= t) {
		let t = (n.get(e) ?? []).slice(0, 2);
		for (; t.length < 2;) t.push({
			rank: e,
			suit: "S",
			physId: "$wild"
		});
		return {
			setRank: 1,
			tiebreak: [e],
			faces: t
		};
	}
	if (t > 0) return {
		setRank: 0,
		tiebreak: [14],
		faces: [{
			rank: 14,
			suit: "S",
			physId: "$wild"
		}]
	};
	let l = [...e].sort((e, t) => t.rank - e.rank)[0];
	return l ? {
		setRank: 0,
		tiebreak: [l.rank],
		faces: [l]
	} : null;
}
function pe(e, t) {
	let n = null, r = e.length, i = [], a = (o, s) => {
		if (s === 0) {
			if (i.length === 0) return;
			let r = i.map((t) => e[t]);
			if (t) {
				let e = new Set(r.filter((e) => e.fromMarket).map((e) => e.physId)), t = new Set(r.filter((e) => !e.fromMarket).map((e) => e.physId));
				if (e.size !== 3 || t.size > 2) return;
			}
			let a = le(r);
			if (!a) return;
			(!n || k(a, n) > 0) && (n = {
				...a,
				picked: r
			});
			return;
		}
		for (let e = o; e <= r - s; e += 1) i.push(e), a(e + 1, s - 1), i.pop();
	};
	for (let e = 1; e <= 5; e += 1) a(0, e);
	return n;
}
function me(e) {
	let t = e.hand.map((e) => x[e]), n = fe(t);
	if (e.solo) {
		let r = [];
		for (let n of t) e.noSetIds?.has(n.id) || (r.push({
			rank: n.rank,
			suit: n.suit,
			physId: n.id
		}), n.doubleAs && r.push({
			rank: n.doubleAs.rank,
			suit: n.doubleAs.suit,
			physId: n.id
		}));
		r.sort((e, t) => t.rank - e.rank);
		let i = M(e, t), a = r[0];
		return {
			setRank: 0,
			tiebreak: r.map((e) => e.rank),
			setCardIds: a ? [a.physId] : [],
			setFaces: a ? [a] : [],
			chips: i.chips,
			credits: i.credits,
			lowSum: n
		};
	}
	let r = [], i = (n, i) => {
		let a = !!e.battleRoyale && n.rank >= 11;
		r.push({
			physId: n.id,
			options: de(n, e, t),
			wild: a,
			noSet: !!e.noSetIds?.has(n.id),
			fromMarket: i,
			modifiable: n.rank <= 10 && !e.battleRoyale
		});
	};
	for (let e of t) i(e, !1);
	if (e.holdem) for (let t of e.marketSlots) i(x[t], !0);
	let a = e.battleRoyale ? 0 : t.filter((e) => e.assistAce).length, o = r.filter((e) => e.wild && !e.noSet), s = { v: null }, c = (t) => {
		if (e.battleRoyale) {
			let e = j(t.filter((e) => !e.card.noSet).flatMap((e) => e.opt.faces.map((t) => ({
				...t,
				physId: e.card.physId
			}))), o.length);
			if (!e) return;
			let n = new Set(e.faces.map((e) => e.physId).filter((e) => e !== "$wild")), r = A(t, n), i = {
				setRank: e.setRank,
				tiebreak: e.tiebreak,
				setCardIds: [...n],
				setFaces: e.faces,
				chips: r.chips,
				credits: r.credits
			};
			(!s.v || k(i, s.v.res) > 0 || k(i, s.v.res) === 0 && i.chips > s.v.res.chips) && (s.v = {
				res: i,
				cmp: 0
			});
			return;
		}
		let n = pe(t.filter((e) => !e.card.noSet).flatMap((e) => e.opt.faces.map((t) => ({
			...t,
			physId: e.card.physId,
			fromMarket: e.card.fromMarket
		}))), !!e.holdem);
		if (!n) return;
		let r = new Set(n.picked.map((e) => e.physId)), i = A(t, r), a = {
			setRank: n.setRank,
			tiebreak: n.tiebreak,
			setCardIds: [...r],
			setFaces: n.picked,
			chips: i.chips,
			credits: i.credits
		};
		(!s.v || k(a, s.v.res) > 0 || k(a, s.v.res) === 0 && a.chips > s.v.res.chips) && (s.v = {
			res: a,
			cmp: 0
		});
	}, l = [], u = (e, t) => {
		if (e >= r.length) {
			c(l);
			return;
		}
		let n = r[e];
		if (n.wild || n.options.length === 0) {
			u(e + 1, t);
			return;
		}
		for (let r of n.options) {
			if (l.push({
				card: n,
				opt: r
			}), u(e + 1, t), t > 0 && n.modifiable && r.faces.length === 1) {
				let i = r.faces[0];
				for (let a = 1; a <= t; a += 1) for (let o of [1, -1]) {
					let s = i.rank + o * a;
					s < 2 || s > 10 || (l[l.length - 1] = {
						card: n,
						opt: {
							faces: [{
								rank: s,
								suit: i.suit
							}],
							def: r.def
						}
					}, u(e + 1, t - a));
				}
			}
			l.pop();
		}
	};
	return u(0, a), s.v ? {
		...s.v.res,
		lowSum: n
	} : {
		setRank: 0,
		tiebreak: [],
		setCardIds: [],
		setFaces: [],
		chips: 0,
		credits: 0,
		lowSum: n
	};
}
function M(e, t) {
	return A(t.filter((t) => !(e.battleRoyale && t.rank >= 11)).map((e) => ({
		card: {
			physId: e.id,
			fromMarket: !1
		},
		opt: {
			faces: ue(e),
			def: e
		}
	})), /* @__PURE__ */ new Set());
}
//#endregion
//#region src/games/decko/meta.ts
var N = {
	id: "decko",
	tier: "beta",
	mechanics: ["deck-bag-building", "betting"],
	interactionTags: [],
	nameKey: "games.decko.name",
	descKey: "games.decko.desc",
	rulesKey: "games.decko.rules",
	icon: "🃏",
	iconImg: "games/decko.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/decko/en.pdf" },
	precacheAssets: [
		"mat.webp",
		"joker-deal.webp",
		"joker-raise.webp",
		"joker-call.webp",
		"joker-burn.webp",
		"joker-fold.webp",
		"joker-buy.webp"
	],
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [5],
	accent: "#0d766f",
	releasedAt: "2026-09-26",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover"
}, he = [
	"games.decko.logRound",
	"games.decko.logWildcard",
	"games.decko.logAnte",
	"games.decko.logRefresh",
	"games.decko.logDeal",
	"games.decko.logBurn",
	"games.decko.logJunkFood",
	"games.decko.logRaise",
	"games.decko.logCall",
	"games.decko.logFold",
	"games.decko.logShowdown",
	"games.decko.logLastStanding",
	"games.decko.logAllFold",
	"games.decko.logBuyCard",
	"games.decko.logBuySpecial",
	"games.decko.logBuyChips",
	"games.decko.logBuyJoker",
	"games.decko.logBabyJoker",
	"games.decko.logGameOver"
], P = t.string(), F = t.string(), ge = t.enum([
	"deal",
	"raise",
	"call",
	"burn",
	"fold",
	"buy"
]), _e = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("deal"),
		merlinSlot: t.int().min(0).max(4).optional(),
		garbagePail: t.boolean().optional(),
		babyJokerType: ge.optional(),
		fortuneTellerTarget: F.optional()
	}),
	t.object({
		type: t.literal("mulligan"),
		cards: t.array(P).max(3)
	}),
	t.object({
		type: t.literal("smolderResolve"),
		cards: t.array(P).max(2)
	}),
	t.object({
		type: t.literal("studReveal"),
		cards: t.array(P).length(3)
	}),
	t.object({
		type: t.literal("tcg"),
		cardId: P.optional()
	}),
	t.object({
		type: t.literal("burn"),
		cards: t.array(P).max(2),
		devil: t.boolean().optional(),
		burningMan: t.boolean().optional(),
		harlequinTarget: F.optional(),
		marshmallowTake: P.optional(),
		dumpsterFire: t.boolean().optional()
	}),
	t.object({
		type: t.literal("junkFood"),
		cardIds: t.array(P).min(1)
	}),
	t.object({
		type: t.literal("raise"),
		fcBurn: P.optional(),
		redJester: t.boolean().optional(),
		sewerSwap: P.optional(),
		whiteClown: t.boolean().optional(),
		witchFrom: F.optional(),
		tableTalker: t.object({
			target: F,
			card: P
		}).optional()
	}),
	t.object({
		type: t.literal("redJesterResolve"),
		keep: t.boolean(),
		burns: t.array(P).max(2).optional()
	}),
	t.object({
		type: t.literal("call"),
		fcBurn: P.optional(),
		coolCat: t.boolean().optional(),
		fishbaitOrder: t.array(P).optional(),
		monochromaSlot: t.int().min(0).max(4).optional(),
		monochromaBurns: t.array(P).max(2).optional(),
		blackKnightCard: P.optional()
	}),
	t.object({
		type: t.literal("fold"),
		marketSlots: t.array(t.int().min(0).max(4)).max(2),
		smolderBurns: t.array(P).max(2).optional(),
		discardOrder: t.array(P),
		gunTarget: F.optional(),
		gunBurn: P.optional(),
		patchfaceGuess: F.optional(),
		apKeep: t.array(P).length(2).optional()
	}),
	t.object({
		type: t.literal("buyCard"),
		slot: t.int().min(0).max(4),
		burns: t.array(P).max(2).optional()
	}),
	t.object({ type: t.literal("buyFlush") }),
	t.object({
		type: t.literal("buyBurn"),
		card: P
	}),
	t.object({
		type: t.literal("buyGift"),
		card: P,
		target: F
	}),
	t.object({
		type: t.literal("buyChips"),
		n: t.union([
			t.literal(1),
			t.literal(2),
			t.literal(3)
		])
	}),
	t.object({
		type: t.literal("buyJoker"),
		jokerType: ge
	}),
	t.object({
		type: t.literal("buyDone"),
		discardOrder: t.array(P),
		energyToTop: t.array(P).optional()
	})
]), ve = t.object({
	rank: t.int(),
	suit: t.enum([
		"S",
		"H",
		"D",
		"C"
	]),
	physId: t.string()
}), ye = t.object({
	rid: F,
	chips: t.int(),
	bet: t.int().nonnegative(),
	handCount: t.int().nonnegative(),
	drawCount: t.int().nonnegative(),
	discard: t.array(P),
	burn: t.array(P),
	jokers: t.array(t.string()),
	loans: t.int().nonnegative(),
	folded: t.boolean(),
	dealt: t.boolean(),
	studRevealed: t.array(P),
	jackpot: t.int().nonnegative(),
	patchfaceGuess: F.nullable()
}), I = t.object({
	round: t.int().min(1),
	phase: t.enum([
		"deal",
		"stud",
		"tcg",
		"bet",
		"buy",
		"done"
	]),
	turn: F,
	blind: F,
	housePot: t.int().nonnegative(),
	highest: t.int().nonnegative(),
	minBet: t.int(),
	maxBet: t.int(),
	firstBetRound: t.boolean(),
	burnUsed: t.boolean(),
	market: t.array(P),
	marketDeckCount: t.int().nonnegative(),
	jokerTops: t.record(t.string(), t.string().nullable()),
	wildcard: t.string().nullable(),
	players: t.array(ye),
	reveal: t.object({
		results: t.record(t.string(), t.object({
			setRank: t.int(),
			tiebreak: t.array(t.int()),
			setFaces: t.array(ve),
			chips: t.int(),
			lowSum: t.int()
		})),
		winners: t.array(F),
		potShare: t.int().nonnegative(),
		lastPlayerStanding: t.boolean()
	}).nullable(),
	buyQueue: t.array(F),
	buyerMoney: t.int().nonnegative(),
	buyerSpecials: t.array(t.string()),
	buyerJokerBought: t.boolean(),
	buyerAcquired: t.array(P),
	buyerCherryUsed: t.boolean(),
	log: t.array(t.object({
		k: t.enum(he),
		p: t.record(t.string(), t.union([t.string(), t.int()])).optional()
	})),
	finalChips: t.record(t.string(), t.int()).nullable()
}), be = t.object({
	hand: t.array(P),
	peek: t.object({
		target: F,
		hand: t.array(P)
	}).nullable(),
	redJesterCard: P.nullable(),
	pendingSmolder: t.object({
		rid: F,
		need: t.int()
	}).nullable(),
	pendingMulligan: t.boolean(),
	myMoney: t.int().nonnegative()
}), L = (e, t) => ({
	code: e,
	params: t
}), R = (e, t) => e.players.find((e) => e.rid === t);
function xe(e, t) {
	return e.wildcard === "clownCar" ? Object.values(e.jokerPiles).map((e) => e[0]).filter((e) => !!e) : t.jokers;
}
var z = (e, t, n) => xe(e, t).includes(n);
function Se(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.rngSeed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Ce(e, t, n, r = {}) {
	let i = [];
	for (let a = 0; a < n; a += 1) {
		if (t.draw.length === 0) {
			if (t.discard.length === 0) break;
			t.draw = Se(e, t.discard), t.discard = [], r.hobo && z(e, t, "hobo") && (t.chips += 3);
		}
		let n = t.draw.pop();
		if (n === void 0) break;
		i.push(n);
	}
	return i;
}
var B = (e) => e.hand.length + e.draw.length + e.discard.length;
function we(e, t) {
	for (; e.chips < t && e.loans < 2;) e.chips += 10, e.loans += 1;
	return e.chips >= t;
}
function V(e, t, n) {
	e.log.push({
		k: t,
		...n ? { p: n } : {}
	}), e.log.length > 200 && e.log.splice(0, e.log.length - 200);
}
function Te(e) {
	let t = e.market.filter((e) => e !== "");
	for (; t.length < 5 && e.marketDeck.length > 0;) t.unshift(e.marketDeck.pop());
	e.market = t;
}
function H(e, t) {
	let n = e.market[t];
	return n ? (e.market[t] = "", n) : null;
}
function Ee(e, t, n) {
	let r = x[t];
	r.onAcquire === "voucher" && (e.chips += 3);
	let i = r.onAcquire === "smolder1" ? 1 : r.onAcquire === "smolder2" ? 2 : 0;
	if (i === 0) return null;
	let a = n ?? [];
	if (a.length > i) return L("games.decko.errBadBurns");
	for (let t of a) {
		if (!e.hand.includes(t)) return L("games.decko.errInvalidCard");
		if (B(e) <= 7) return L("games.decko.errDeckMin");
		e.hand.splice(e.hand.indexOf(t), 1), e.burn.push(t);
	}
	return null;
}
var U = (e, t) => (t + 1) % e.players.length;
function De(e) {
	return T(e.round);
}
function Oe(e, t) {
	return {
		rid: e,
		chips: 20,
		draw: Se(t, b.map((e) => e.id)),
		hand: [],
		discard: [],
		burn: [],
		bet: 0,
		jokers: [],
		loans: 0,
		folded: !1,
		dealt: !1,
		jackpot: 0,
		studRevealed: [],
		keptCards: [],
		patchfaceGuess: null,
		money: 0,
		specials: [],
		jokerBought: !1,
		cherryUsed: !1,
		acquired: []
	};
}
function ke(t, n, r) {
	let i = {
		players: [],
		round: 0,
		phase: "deal",
		turnIdx: 0,
		blindIdx: 0,
		housePot: 0,
		market: [],
		marketDeck: [],
		jokerPiles: {
			deal: [],
			raise: [],
			call: [],
			burn: [],
			fold: [],
			buy: []
		},
		wildcard: null,
		highest: 0,
		firstBetRound: !0,
		burnUsed: !1,
		pendingRedJester: null,
		pendingSmolder: null,
		pendingMulligan: null,
		ftPeek: null,
		reveal: null,
		buyQueue: [],
		log: [],
		finalChips: null,
		ranking: null,
		rngSeed: r,
		rngCursor: 0
	};
	i.players = n.map((e) => Oe(e, i)), i.marketDeck = Se(i, ee.map((e) => e.id));
	let a = n.length === 2 ? new Set(C) : /* @__PURE__ */ new Set();
	for (let e of Object.keys(i.jokerPiles)) i.jokerPiles[e] = Se(i, Object.values(S).filter((t) => t.type === e && !a.has(t.id)).map((e) => e.id));
	return i.blindIdx = e(i.rngSeed, i.rngCursor, n.length), i.rngCursor += 1, {
		state: i,
		fx: Ae(i)
	};
}
function Ae(t) {
	t.round += 1;
	let n = t.players.length;
	if (t.round > 1 && (t.blindIdx = (t.blindIdx + 1) % n), E.includes(t.round)) {
		t.marketDeck = [...t.market.filter((e) => e !== ""), ...t.marketDeck], t.market = [], Te(t);
		for (let e of Object.keys(t.jokerPiles)) {
			let n = t.jokerPiles[e];
			n.length > 1 && n.push(n.shift());
		}
		V(t, "games.decko.logRefresh");
	}
	let r = te[t.round];
	if (t.wildcard = null, r) {
		let n = w.filter((e) => e.color === r).map((e) => e.id);
		t.wildcard = n[e(t.rngSeed, t.rngCursor, n.length)], t.rngCursor += 1, V(t, "games.decko.logWildcard", { w: t.wildcard });
	}
	for (let e of t.players) e.bet = 0, e.folded = !1, e.dealt = !1, e.studRevealed = [], e.patchfaceGuess = null, e.money = 0, e.specials = [], e.jokerBought = !1, e.cherryUsed = !1, e.acquired = [];
	t.housePot = 0, t.highest = 0, t.firstBetRound = !0, t.burnUsed = !1, t.pendingRedJester = null, t.pendingSmolder = null, t.pendingMulligan = null, t.ftPeek = null, t.reveal = null, t.buyQueue = [];
	let [i] = De(t);
	if (t.housePot += n === 2 ? i * 2 : i, t.wildcard) {
		for (let e of t.players) we(e, i) && (e.chips -= i), t.housePot += i;
		V(t, "games.decko.logAnte", { n: i });
	}
	let a = t.players[t.blindIdx];
	return we(a, i) && (a.chips -= i), a.bet = i, t.highest = i, t.phase = "deal", t.turnIdx = U(t, t.blindIdx), V(t, "games.decko.logRound", { n: t.round }), [];
}
function je(e, t, n) {
	if (e.wildcard === "inferno") {
		let e = [];
		for (let r = 0; r < n && t.burn.length > 0; r += 1) e.push(t.burn.pop());
		return e;
	}
	return Ce(e, t, n, { hobo: !0 });
}
function Me(e) {
	let t = e.turnIdx;
	for (; t = (t + 1) % e.players.length, e.players[t].dealt && t !== e.turnIdx;);
	e.players.every((e) => e.dealt) ? (e.ftPeek = null, e.phase = e.wildcard === "stud" ? "stud" : e.wildcard === "tcg" ? "tcg" : "bet", e.turnIdx = U(e, e.blindIdx)) : e.turnIdx = t;
}
function W(e, t, n) {
	if (t.dealt) return L("games.decko.errAlreadyActed");
	let r = xe(e, t), i = (e) => r.includes(e), a = 5;
	e.wildcard === "deckorama" ? a = 7 : i("magicHat") && t.keptCards.length === 0 && (a = 6), a = Math.min(a, 7 - t.keptCards.length), e.wildcard === "inferno" && t.burn.length > 0 && (t.burn = Se(e, t.burn));
	let o = [...t.keptCards];
	t.keptCards = [];
	let s = null;
	if (n.merlinSlot !== void 0) {
		if (!i("merlin")) return L("games.decko.errNoJoker");
		let t = H(e, n.merlinSlot);
		if (!t) return L("games.decko.errInvalidCard");
		s = t, o.push(t), --a;
	}
	if (n.garbagePail) {
		if (!i("garbagePailBoy")) return L("games.decko.errNoJoker");
		if (t.discard.length === 0) return L("games.decko.errEmptyDiscard");
		--a;
	}
	if (o.push(...je(e, t, a)), n.garbagePail) {
		let e = t.discard.pop();
		e && o.push(e);
	}
	t.hand = o;
	let c = 0;
	if (s !== null) {
		let n = x[s];
		n.onAcquire === "voucher" && (t.chips += 3), c = n.onAcquire === "smolder1" ? 1 : n.onAcquire === "smolder2" ? 2 : 0, Te(e);
	}
	if (n.babyJokerType) {
		if (!i("babyJoker")) return L("games.decko.errNoJoker");
		e.wildcard !== "clownCar" && (t.jokers = t.jokers.filter((e) => e !== "babyJoker"));
		let r = e.jokerPiles[n.babyJokerType], a = r[0];
		if (!a) return L("games.decko.errEmptyPile");
		if (t.jokers.some((e) => S[e].type === n.babyJokerType)) return L("games.decko.errHaveType");
		r.shift(), t.jokers.push(a), V(e, "games.decko.logBabyJoker", {
			rid: t.rid,
			j: a
		});
	}
	if (n.fortuneTellerTarget) {
		if (!i("fortuneTeller")) return L("games.decko.errNoJoker");
		let r = R(e, n.fortuneTellerTarget);
		if (!r || r.rid === t.rid) return L("games.decko.errInvalidTarget");
		e.ftPeek = {
			by: t.rid,
			target: r.rid
		};
	}
	return c > 0 ? (e.pendingSmolder = {
		rid: t.rid,
		need: c
	}, null) : (Ne(e, t), null);
}
function Ne(e, t) {
	if (z(e, t, "mulligan")) {
		e.pendingMulligan = t.rid;
		return;
	}
	t.dealt = !0, V(e, "games.decko.logDeal", { rid: t.rid });
}
function G(e) {
	let t = (e) => {
		let t = /* @__PURE__ */ new Set();
		for (let n of e.hand) {
			let e = x[n];
			e.rank <= 10 && t.add(e.rank), e.altRank !== void 0 && e.altRank <= 10 && t.add(e.altRank), e.doubleAs && e.doubleAs.rank <= 10 && t.add(e.doubleAs.rank);
		}
		return t;
	}, n = new Map(e.players.map((e) => [e.rid, t(e)])), r = /* @__PURE__ */ new Set();
	for (let t of e.players) {
		let e = /* @__PURE__ */ new Set();
		for (let [r, i] of n) if (r !== t.rid) for (let t of i) e.add(t);
		for (let n of t.hand) {
			let t = x[n];
			t.rank >= 11 && !t.jovial || [
				t.rank,
				t.altRank,
				t.doubleAs?.rank
			].filter((e) => e !== void 0 && e <= 10).some((t) => e.has(t)) && r.add(n);
		}
	}
	return r;
}
function Pe(e, t, n) {
	return {
		hand: t.hand,
		burnTop: t.burn[t.burn.length - 1],
		discardTop: t.discard[t.discard.length - 1],
		marketSlots: e.market.filter((e) => e !== ""),
		holdem: e.wildcard === "holdem",
		battleRoyale: e.wildcard === "battleRoyale",
		solo: e.wildcard === "solo",
		noSetIds: n
	};
}
function Fe(e) {
	let t = e.players.filter((e) => !e.folded), n = e.wildcard === "purge" ? G(e) : /* @__PURE__ */ new Set(), r = (t) => {
		let r = /* @__PURE__ */ new Set();
		for (let i of t.hand) (n.has(i) || e.wildcard === "proTable" && x[i].starter) && r.add(i);
		return r;
	}, i = {}, a = /* @__PURE__ */ new Map();
	for (let n of t) {
		let t = me(Pe(e, n, r(n)));
		a.set(n.rid, t), i[n.rid] = {
			setRank: t.setRank,
			tiebreak: t.tiebreak,
			setFaces: t.setFaces,
			chips: t.chips,
			lowSum: t.lowSum
		};
	}
	let o;
	if (e.wildcard === "lowSum") {
		let e = Math.min(...t.map((e) => a.get(e.rid)?.lowSum ?? Infinity));
		o = t.filter((t) => a.get(t.rid)?.lowSum === e).map((e) => e.rid);
	} else if (e.wildcard === "penultimo") {
		let e = [...t].sort((e, t) => k(a.get(t.rid), a.get(e.rid))), n = [];
		for (let t of e) {
			let e = n[n.length - 1];
			e && k(a.get(e[0]), a.get(t.rid)) === 0 ? e.push(t.rid) : n.push([t.rid]);
		}
		o = n[1] ?? n[0];
	} else {
		let n = (e, t) => k(a.get(e), a.get(t)), r = t.reduce((e, t) => n(e.rid, t.rid) >= 0 ? e : t);
		if (o = t.filter((e) => n(e.rid, r.rid) === 0).map((e) => e.rid), e.wildcard === "lowball") {
			let e = t.reduce((e, t) => n(e.rid, t.rid) <= 0 ? e : t);
			o = t.filter((t) => n(t.rid, e.rid) === 0).map((e) => e.rid);
		}
	}
	let s = t.reduce((e, t) => e + t.bet, 0) + e.housePot, c = Math.floor(s / o.length);
	for (let t of e.players) t.bet = 0, t.jackpot > 0 && (o.includes(t.rid) && (t.chips += t.jackpot), t.jackpot = 0);
	for (let t of o) {
		let n = R(e, t);
		n.chips += c;
	}
	e.housePot = 0;
	for (let e of t) {
		let t = a.get(e.rid);
		e.chips += t.chips;
	}
	for (let t of e.players) t.patchfaceGuess && o.includes(t.patchfaceGuess) && (t.chips += 7);
	e.reveal = {
		results: i,
		winners: o,
		potShare: c,
		lastPlayerStanding: !1
	}, V(e, "games.decko.logShowdown", {
		w: o.join(","),
		n: s
	});
	for (let t of o) {
		let n = R(e, t);
		n.discard.push(...n.hand), n.hand = [];
	}
	let l = [];
	for (let t = 1; t <= e.players.length; t += 1) {
		let n = e.players[(e.blindIdx + t) % e.players.length];
		!n.folded && !o.includes(n.rid) && l.push(n.rid);
	}
	for (let t of l) {
		let n = R(e, t), r = a.get(t);
		n.money = r.setRank + r.credits * 3;
	}
	return e.buyQueue = l, [{
		kind: "showdown",
		data: {
			winners: o,
			pot: s,
			results: i
		}
	}];
}
function Ie(e, t) {
	if (t === null) return e.housePot = 0, V(e, "games.decko.logAllFold"), e.reveal = null, Le(e), [];
	let n = R(e, t), r = me(Pe(e, n, /* @__PURE__ */ new Set())), i = n.bet + e.housePot;
	n.chips += i + n.jackpot, n.jackpot = 0, n.bet = 0, e.housePot = 0;
	for (let t of e.players) t.bet = 0;
	for (let n of e.players) n.patchfaceGuess === t && (n.chips += 7);
	return e.reveal = {
		results: { [t]: {
			setRank: r.setRank,
			tiebreak: r.tiebreak,
			setFaces: r.setFaces,
			chips: r.chips,
			lowSum: r.lowSum
		} },
		winners: [t],
		potShare: i,
		lastPlayerStanding: !0
	}, V(e, "games.decko.logLastStanding", {
		rid: t,
		n: i
	}), n.money = r.setRank + r.credits * 3, n.chips += r.chips, e.buyQueue = [t], e.phase = "buy", e.turnIdx = e.players.indexOf(n), [{
		kind: "showdown",
		data: {
			winners: [t],
			pot: i,
			results: e.reveal.results
		}
	}];
}
function Le(e) {
	let t = D(e.players.length);
	if (!(e.players.some((e) => e.chips >= t) || e.round >= 12)) {
		Ae(e);
		return;
	}
	let n = {};
	for (let t of e.players) t.chips = Math.max(0, t.chips - t.loans * 5), n[t.rid] = t.chips;
	let r = [...e.players];
	for (;;) {
		let e = Math.max(...r.map((e) => e.chips));
		if (r = r.filter((t) => t.chips === e), r.length === 1) break;
		let t = r.map((e) => ({
			p: e,
			rank: x[e.draw.pop() ?? e.discard.pop() ?? "s0"].rank
		})), n = Math.max(...t.map((e) => e.rank));
		r = t.filter((e) => e.rank === n).map((e) => e.p);
	}
	e.finalChips = n, e.ranking = [...e.players].sort((e, t) => t.chips - e.chips || (e === r[0] ? -1 : +(t === r[0]))).map((e) => e.rid), e.ranking = [r[0].rid, ...e.ranking.filter((e) => e !== r[0].rid)], e.phase = "done", V(e, "games.decko.logGameOver", { rid: r[0].rid });
}
function K(e) {
	return e.players[e.turnIdx];
}
function q(e) {
	let t = e.players.filter((e) => !e.folded);
	if (t.length === 0) return Ie(e, null);
	if (t.length === 1 && e.players.length > 1) return Ie(e, t[0].rid);
	let n = e.turnIdx === e.blindIdx;
	if (n && (e.firstBetRound = !1), (n || !e.firstBetRound) && t.every((t) => t.bet === e.highest)) {
		e.phase = "buy";
		let t = Fe(e);
		return e.buyQueue.length > 0 ? (e.turnIdx = e.players.findIndex((t) => t.rid === e.buyQueue[0]), Re(e, K(e))) : Le(e), t;
	}
	let r = e.turnIdx;
	do
		r = (r + 1) % e.players.length;
	while (e.players[r].folded);
	return e.turnIdx = r, e.burnUsed = !1, [];
}
function Re(e, t) {
	z(e, t, "cherry") && (t.chips += 2);
}
function ze(e, t) {
	if (e.phase !== "bet") return L("games.decko.errBadPhase");
	if (e.pendingRedJester) return L("games.decko.errPending");
	let n = K(e);
	return n.rid === t ? n.folded ? L("games.decko.errBadPhase") : n : L("games.decko.errNotYourTurn");
}
function Be(e, t, n) {
	if (!e.firstBetRound || e.burnUsed) return L("games.decko.errBurnUsed");
	let r = (n) => z(e, t, n), i = [...n.cards];
	if (n.dumpsterFire) {
		if (!r("dumpsterFire")) return L("games.decko.errNoJoker");
		if (t.hand.length >= 7) return L("games.decko.errHandLimit");
		if (i.length > 0) return L("games.decko.errInvalidCard");
	}
	let a = i.length + +!!n.dumpsterFire, o = r("minmaxer") && !n.dumpsterFire ? 2 : 1;
	if (!n.dumpsterFire && a !== o && (o !== 2 || a !== 1) && (a !== 1 || !r("minmaxer"))) return L("games.decko.errInvalidCard");
	if (B(t) - a < 7) return L("games.decko.errDeckMin");
	if (n.harlequinTarget) {
		if (!r("harlequin")) return L("games.decko.errNoJoker");
		if (n.dumpsterFire || i.length !== 1) return L("games.decko.errInvalidCard");
	}
	let s = n.devil ? 2 : 1;
	if (n.devil && !r("devil")) return L("games.decko.errNoJoker");
	if (t.hand.length - i.length + s > 7) return L("games.decko.errHandLimit");
	if (n.burningMan && !r("burningMan")) return L("games.decko.errNoJoker");
	let c = [];
	if (n.dumpsterFire) {
		if (t.discard.length === 0) {
			let e = t.draw.pop();
			if (!e) return L("games.decko.errEmptyDiscard");
			t.discard.push(e);
		}
		c.push(t.discard.pop());
	} else for (let e of i) {
		if (!t.hand.includes(e)) return L("games.decko.errInvalidCard");
		t.hand.splice(t.hand.indexOf(e), 1), c.push(e);
	}
	if (n.harlequinTarget) {
		let r = R(e, n.harlequinTarget);
		if (!r || r.rid === t.rid) return L("games.decko.errInvalidTarget");
		r.draw.push(c[0]);
	} else t.burn.push(...c);
	let l = c.filter((e) => t.studRevealed.includes(e)).length;
	t.studRevealed = t.studRevealed.filter((e) => !c.includes(e));
	let u;
	if (n.burningMan) {
		if (t.discard.length === 0) {
			let e = t.draw.pop();
			if (!e) return L("games.decko.errEmptyDiscard");
			t.discard.push(e);
		}
		u = [t.discard.pop()], s === 2 && u.push(...Ce(e, t, 1));
	} else u = Ce(e, t, s);
	t.hand.push(...u);
	for (let e = 0; e < Math.min(l, u.length); e += 1) t.studRevealed.push(u[e]);
	if (n.marshmallowTake) {
		if (!r("marshmallow")) return L("games.decko.errNoJoker");
		if (t.hand.length >= 7) return L("games.decko.errHandLimit");
		let e = t.burn.indexOf(n.marshmallowTake);
		if (e < 0) return L("games.decko.errInvalidCard");
		t.burn.splice(e, 1), t.hand.push(n.marshmallowTake);
	}
	return e.burnUsed = !0, V(e, "games.decko.logBurn", {
		rid: t.rid,
		n: c.length
	}), null;
}
function Ve(e, t, n) {
	let [, r] = De(e);
	if (e.highest >= r) return L("games.decko.errMaxBet");
	let i = e.highest + 1 - t.bet;
	if (!we(t, i)) return L("games.decko.errCantAfford");
	if (t.chips -= i, t.bet = e.highest + 1, e.highest = t.bet, e.wildcard === "friedChicken") {
		if (!n.fcBurn || !t.hand.includes(n.fcBurn)) return L("games.decko.errFcBurn");
		if (B(t) <= 7) return L("games.decko.errDeckMin");
		t.hand.splice(t.hand.indexOf(n.fcBurn), 1), t.burn.push(n.fcBurn);
	}
	let a = (n) => z(e, t, n);
	if (a("mrJackpot") && (t.jackpot += 4), n.witchFrom) {
		if (!a("witch")) return L("games.decko.errNoJoker");
		let i = R(e, n.witchFrom);
		if (!i || i.rid === t.rid || i.folded || i.bet < 2) return L("games.decko.errInvalidTarget");
		if (t.bet + 2 > r) return L("games.decko.errMaxBet");
		i.bet -= 2, t.bet += 2, e.highest = Math.max(e.highest, t.bet);
	}
	if (n.redJester) {
		if (!a("redJester")) return L("games.decko.errNoJoker");
		if (t.hand.length >= 7) return L("games.decko.errHandLimit");
		let n = e.marketDeck[e.marketDeck.length - 1];
		n && (e.pendingRedJester = {
			rid: t.rid,
			card: n
		});
	}
	if (n.sewerSwap) {
		if (!a("sewerClown")) return L("games.decko.errNoJoker");
		if (!t.hand.includes(n.sewerSwap)) return L("games.decko.errInvalidCard");
		if (t.discard.length === 0) {
			let e = t.draw.pop();
			if (!e) return L("games.decko.errEmptyDiscard");
			t.discard.push(e);
		}
		let e = t.discard.pop();
		t.discard.push(n.sewerSwap), t.hand.splice(t.hand.indexOf(n.sewerSwap), 1), t.hand.push(e);
	}
	if (n.whiteClown) {
		if (!a("whiteClown")) return L("games.decko.errNoJoker");
		if (t.hand.length >= 7) return L("games.decko.errHandLimit");
		t.hand.push(...Ce(e, t, 1));
	}
	if (n.tableTalker) {
		if (!a("tableTalker")) return L("games.decko.errNoJoker");
		let r = R(e, n.tableTalker.target);
		if (!r || r.rid === t.rid) return L("games.decko.errInvalidTarget");
		if (r.hand.length >= 7) return L("games.decko.errHandLimit");
		if (!t.hand.includes(n.tableTalker.card)) return L("games.decko.errInvalidCard");
		t.hand.splice(t.hand.indexOf(n.tableTalker.card), 1), r.hand.push(n.tableTalker.card);
	}
	return V(e, "games.decko.logRaise", {
		rid: t.rid,
		n: t.bet
	}), null;
}
function He(e, t, n) {
	let r = e.highest - t.bet;
	if (!we(t, r)) return L("games.decko.errCantAfford");
	if (t.chips -= r, t.bet = e.highest, e.wildcard === "friedChicken") {
		if (!n.fcBurn || !t.hand.includes(n.fcBurn)) return L("games.decko.errFcBurn");
		if (B(t) <= 7) return L("games.decko.errDeckMin");
		t.hand.splice(t.hand.indexOf(n.fcBurn), 1), t.burn.push(n.fcBurn);
	}
	let i = (n) => z(e, t, n);
	if (i("vampire")) {
		let n = e.players.filter((e) => e.rid !== t.rid && !e.folded && e.bet === t.bet).length;
		t.chips += n;
	}
	if (i("kingmaker")) for (let n of e.players) n.rid === t.rid || n.folded || (we(n, 1) && --n.chips, e.housePot += 1);
	if (n.coolCat) {
		if (!i("coolCat")) return L("games.decko.errNoJoker");
		if (t.hand.length >= 7) return L("games.decko.errHandLimit");
		t.hand.push(...Ce(e, t, 1));
	}
	if (n.fishbaitOrder) {
		if (!i("fishbait")) return L("games.decko.errNoJoker");
		let r = [...t.hand].sort();
		if ([...n.fishbaitOrder].sort().join() !== r.join()) return L("games.decko.errInvalidCard");
		let a = t.hand.filter((e) => t.studRevealed.includes(e)).length;
		t.discard.push(...n.fishbaitOrder), t.hand = [], t.studRevealed = [];
		let o = Ce(e, t, n.fishbaitOrder.length);
		t.hand.push(...o);
		for (let e = 0; e < Math.min(a, o.length); e += 1) t.studRevealed.push(o[e]);
	}
	if (n.monochromaSlot !== void 0) {
		if (!i("monochroma")) return L("games.decko.errNoJoker");
		let r = H(e, n.monochromaSlot);
		if (!r) return L("games.decko.errInvalidCard");
		let a = Ee(t, r, n.monochromaBurns);
		if (a) return a;
		t.discard.push(r), Te(e);
	}
	if (n.blackKnightCard) {
		if (!i("blackKnight")) return L("games.decko.errNoJoker");
		if (!t.hand.includes(n.blackKnightCard)) return L("games.decko.errInvalidCard");
		t.hand.splice(t.hand.indexOf(n.blackKnightCard), 1), t.discard.push(n.blackKnightCard), t.chips += 3;
	}
	return V(e, "games.decko.logCall", {
		rid: t.rid,
		n: t.bet
	}), null;
}
function Ue(e, t, n) {
	let r = (n) => z(e, t, n), i = r("sadClown") ? 2 : 1;
	if (n.marketSlots.length > i || new Set(n.marketSlots).size !== n.marketSlots.length) return L("games.decko.errInvalidCard");
	if (e.housePot += t.bet, t.bet = 0, t.folded = !0, n.gunTarget || n.gunBurn) {
		if (!r("gun")) return L("games.decko.errNoJoker");
		if (!n.gunTarget || !n.gunBurn) return L("games.decko.errInvalidTarget");
		let i = R(e, n.gunTarget);
		if (!i || i.rid === t.rid || i.chips < 2) return L("games.decko.errInvalidTarget");
		if (!t.hand.includes(n.gunBurn)) return L("games.decko.errInvalidCard");
		if (B(t) <= 7) return L("games.decko.errDeckMin");
		i.chips -= 2, t.chips += 2, t.hand.splice(t.hand.indexOf(n.gunBurn), 1), t.burn.push(n.gunBurn);
	}
	if (r("taxman")) {
		let n = t.chips;
		for (let r of e.players) r.rid !== t.rid && r.chips + r.bet > n && r.chips >= 2 && (r.chips -= 2, t.chips += 2);
	}
	if (r("robin")) {
		let n = e.players.filter((e) => e.rid !== t.rid && e.chips + e.bet > t.chips).sort((e, t) => t.chips + t.bet - (e.chips + e.bet))[0];
		n && n.chips >= 4 && (n.chips -= 4, t.chips += 4);
	}
	if (n.patchfaceGuess) {
		if (!r("patchface")) return L("games.decko.errNoJoker");
		if (!R(e, n.patchfaceGuess)) return L("games.decko.errInvalidTarget");
		t.patchfaceGuess = n.patchfaceGuess;
	}
	if (n.apKeep) {
		if (!r("analysisParalysis")) return L("games.decko.errNoJoker");
		for (let e of n.apKeep) if (!t.hand.includes(e)) return L("games.decko.errInvalidCard");
		t.keptCards = [...n.apKeep];
	}
	let a = [];
	for (let t of n.marketSlots) {
		let n = H(e, t);
		if (!n) return L("games.decko.errInvalidCard");
		a.push(n);
	}
	for (let e of a) {
		let r = Ee(t, e, n.smolderBurns);
		if (r) return r;
	}
	Te(e);
	let o = [...t.hand, ...a].filter((e) => !t.keptCards.includes(e)).sort();
	return [...n.discardOrder].sort().join() === o.join() ? (t.discard.push(...n.discardOrder), t.hand = [], V(e, "games.decko.logFold", { rid: t.rid }), null) : L("games.decko.errInvalidCard");
}
function We(e, t) {
	if (e.phase !== "buy") return L("games.decko.errBadPhase");
	let n = K(e);
	return e.buyQueue[0] !== t || n.rid !== t ? L("games.decko.errNotYourTurn") : n;
}
var Ge = (e, t, n) => Math.max(0, n - +!!z(e, t, "saleswoman"));
function Ke(e, t, n) {
	let r = z(e, t, "cherry");
	if (r && t.cherryUsed) return L("games.decko.errCherryLimit");
	let i = r ? 0 : Ge(e, t, O[n.slot] ?? 0);
	if (t.money < i) return L("games.decko.errCantAfford");
	let a = e.market[n.slot];
	return a ? (t.money -= i, e.market[n.slot] = "", t.acquired.push(a), r && (t.cherryUsed = !0), Ee(t, a, n.burns) || (V(e, "games.decko.logBuyCard", {
		rid: t.rid,
		c: a,
		n: i
	}), null)) : L("games.decko.errInvalidCard");
}
function qe(e, t, n) {
	let r = n.type === "buyFlush" ? "flush" : n.type === "buyBurn" ? "burn" : n.type === "buyGift" ? "gift" : "chips";
	if (t.specials.includes(r)) return L("games.decko.errAlreadyUsed");
	let i = r === "flush" && z(e, t, "toilet") || (r === "burn" || r === "gift") && z(e, t, "pizzaTime"), a = r === "flush" || r === "burn" ? 2 : r === "gift" ? 3 : 0;
	if (n.type === "buyChips") {
		let i = [
			0,
			2,
			3,
			5
		][n.n], a = Ge(e, t, i);
		return t.money < a ? L("games.decko.errCantAfford") : (t.money -= a, t.chips += n.n * (z(e, t, "chipGirl") ? 3 : 1), t.specials.push(r), V(e, "games.decko.logBuyChips", {
			rid: t.rid,
			n: n.n
		}), null);
	}
	let o = i ? 0 : Ge(e, t, a);
	if (t.money < o) return L("games.decko.errCantAfford");
	if (n.type === "buyFlush") t.money -= o, e.marketDeck = [...e.market.filter((e) => e !== ""), ...e.marketDeck], e.market = [], Te(e);
	else if (n.type === "buyBurn") {
		if (!t.hand.includes(n.card)) return L("games.decko.errInvalidCard");
		if (B(t) <= 7) return L("games.decko.errDeckMin");
		t.money -= o, t.hand.splice(t.hand.indexOf(n.card), 1), t.burn.push(n.card);
	} else if (n.type === "buyGift") {
		let r = R(e, n.target);
		if (!r || r.rid === t.rid) return L("games.decko.errInvalidTarget");
		let i = t.burn.indexOf(n.card);
		if (i < 0) return L("games.decko.errInvalidCard");
		t.money -= o, t.burn.splice(i, 1), r.draw.push(n.card);
	}
	return t.specials.push(r), V(e, "games.decko.logBuySpecial", {
		rid: t.rid,
		k: r
	}), null;
}
function Je(e, t, n) {
	if (t.jokerBought) return L("games.decko.errAlreadyUsed");
	if (t.jokers.some((e) => S[e].type === n.jokerType)) return L("games.decko.errHaveType");
	let r = e.jokerPiles[n.jokerType], i = r[0];
	if (!i) return L("games.decko.errEmptyPile");
	let a = S[i].cost;
	return we(t, a) ? (t.chips -= a, r.shift(), t.jokers.push(i), t.jokerBought = !0, V(e, "games.decko.logBuyJoker", {
		rid: t.rid,
		j: i,
		n: a
	}), null) : L("games.decko.errCantAfford");
}
function Ye(e, t, n) {
	let r = z(e, t, "energyDrink") ? n.energyToTop ?? [] : [];
	for (let e of r) if (!t.acquired.includes(e)) return L("games.decko.errInvalidCard");
	let i = [...t.hand, ...t.acquired.filter((e) => !r.includes(e))].sort();
	return [...n.discardOrder].sort().join() === i.join() ? (t.discard.push(...n.discardOrder), t.draw.push(...r), t.hand = [], t.acquired = [], Te(e), e.buyQueue.shift(), e.buyQueue.length > 0 ? (e.turnIdx = e.players.findIndex((t) => t.rid === e.buyQueue[0]), Re(e, K(e))) : Le(e), null) : L("games.decko.errInvalidCard");
}
function Xe(e, t, n) {
	return Ze(structuredClone(e), t, n);
}
function Ze(e, t, n) {
	let r = n.by, i = R(e, r);
	if (!i) return L("games.decko.errNotYourTurn");
	switch (t.type) {
		case "deal": return e.phase === "deal" ? e.pendingSmolder || e.pendingMulligan ? L("games.decko.errPending") : K(e).rid === r ? W(e, i, t) || (e.pendingSmolder || e.pendingMulligan || Me(e), { state: e }) : L("games.decko.errNotYourTurn") : L("games.decko.errBadPhase");
		case "smolderResolve":
			if (e.phase !== "deal" || !e.pendingSmolder || e.pendingSmolder.rid !== r) return L("games.decko.errBadPhase");
			if (t.cards.length > e.pendingSmolder.need) return L("games.decko.errBadBurns");
			for (let e of t.cards) {
				if (!i.hand.includes(e)) return L("games.decko.errInvalidCard");
				if (B(i) <= 7) return L("games.decko.errDeckMin");
			}
			for (let e of t.cards) i.hand.splice(i.hand.indexOf(e), 1), i.burn.push(e);
			return e.pendingSmolder = null, Ne(e, i), e.pendingMulligan || Me(e), { state: e };
		case "mulligan":
			if (e.phase !== "deal" || e.pendingMulligan !== r) return L("games.decko.errBadPhase");
			if (t.cards.length !== 0 && t.cards.length !== 3) return L("games.decko.errInvalidCard");
			for (let e of t.cards) if (!i.hand.includes(e)) return L("games.decko.errInvalidCard");
			for (let e of t.cards) i.hand.splice(i.hand.indexOf(e), 1), i.discard.push(e);
			return i.hand.push(...je(e, i, t.cards.length)), e.pendingMulligan = null, i.dealt = !0, V(e, "games.decko.logDeal", { rid: r }), Me(e), { state: e };
		case "studReveal": {
			if (e.phase !== "stud" || e.wildcard !== "stud") return L("games.decko.errBadPhase");
			if (K(e).rid !== r) return L("games.decko.errNotYourTurn");
			for (let e of t.cards) if (!i.hand.includes(e)) return L("games.decko.errInvalidCard");
			if (new Set(t.cards).size !== 3) return L("games.decko.errInvalidCard");
			i.studRevealed = [...t.cards], i.dealt = !1;
			let n = e.turnIdx;
			for (; n = (n + 1) % e.players.length, !(e.players[n].dealt || n === e.turnIdx););
			if (e.players.every((e) => !e.dealt)) {
				for (let t of e.players) t.dealt = !0;
				e.phase = "bet", e.turnIdx = U(e, e.blindIdx);
			} else e.turnIdx = n;
			return { state: e };
		}
		case "tcg": {
			if (e.phase !== "tcg" || e.wildcard !== "tcg") return L("games.decko.errBadPhase");
			if (K(e).rid !== r) return L("games.decko.errNotYourTurn");
			if (t.cardId) {
				if (i.hand.length >= 7) return L("games.decko.errHandLimit");
				let n = e.players[(e.turnIdx + 1) % e.players.length], r = n.burn.indexOf(t.cardId);
				if (r < 0) return L("games.decko.errInvalidCard");
				n.burn.splice(r, 1), i.hand.push(t.cardId);
			}
			i.dealt = !1;
			let n = e.turnIdx;
			for (; n = (n + 1) % e.players.length, !(e.players[n].dealt || n === e.turnIdx););
			if (e.players.every((e) => !e.dealt)) {
				for (let t of e.players) t.dealt = !0;
				e.phase = "bet", e.turnIdx = U(e, e.blindIdx);
			} else e.turnIdx = n;
			return { state: e };
		}
		case "burn": {
			let n = ze(e, r);
			return "code" in n ? n : Be(e, n, t) || { state: e };
		}
		case "junkFood": {
			let n = ze(e, r);
			if ("code" in n) return n;
			for (let e of t.cardIds) if (!n.hand.includes(e) || !x[e].junkFood) return L("games.decko.errInvalidCard");
			for (let e of t.cardIds) n.hand.splice(n.hand.indexOf(e), 1), n.discard.push(e);
			return n.hand.push(...Ce(e, n, t.cardIds.length)), V(e, "games.decko.logJunkFood", {
				rid: r,
				n: t.cardIds.length
			}), { state: e };
		}
		case "raise": {
			let n = ze(e, r);
			return "code" in n ? n : Ve(e, n, t) || (e.pendingRedJester ? { state: e } : {
				state: e,
				fx: q(e)
			});
		}
		case "redJesterResolve": {
			if (e.phase !== "bet" || !e.pendingRedJester || e.pendingRedJester.rid !== r) return L("games.decko.errBadPhase");
			let n = e.pendingRedJester.card;
			if (e.pendingRedJester = null, t.keep) {
				e.marketDeck.pop();
				let r = Ee(i, n, t.burns);
				if (r) return r;
				i.hand.push(n);
			}
			return {
				state: e,
				fx: q(e)
			};
		}
		case "call": {
			let n = ze(e, r);
			return "code" in n ? n : He(e, n, t) || {
				state: e,
				fx: q(e)
			};
		}
		case "fold": {
			let n = ze(e, r);
			return "code" in n ? n : Ue(e, n, t) || {
				state: e,
				fx: q(e)
			};
		}
		case "buyCard": {
			let n = We(e, r);
			return "code" in n ? n : Ke(e, n, t) || { state: e };
		}
		case "buyFlush":
		case "buyBurn":
		case "buyGift":
		case "buyChips": {
			let n = We(e, r);
			return "code" in n ? n : qe(e, n, t) || { state: e };
		}
		case "buyJoker": {
			let n = We(e, r);
			return "code" in n ? n : Je(e, n, t) || { state: e };
		}
		case "buyDone": {
			let n = We(e, r);
			return "code" in n ? n : Ye(e, n, t) || { state: e };
		}
		default: return L("games.decko.errBadPhase");
	}
}
function Qe(e, t) {
	let n = R(e, t), [r, i] = De(e), a = e.phase === "buy" && e.buyQueue.length > 0 ? R(e, e.buyQueue[0]) : void 0;
	return {
		public: {
			round: e.round,
			phase: e.phase,
			turn: e.phase === "done" ? "" : K(e).rid,
			blind: e.players[e.blindIdx].rid,
			housePot: e.housePot,
			highest: e.highest,
			minBet: r,
			maxBet: i,
			firstBetRound: e.firstBetRound,
			burnUsed: e.burnUsed,
			market: e.market,
			marketDeckCount: e.marketDeck.length,
			jokerTops: Object.fromEntries(Object.entries(e.jokerPiles).map(([e, t]) => [e, t[0] ?? null])),
			wildcard: e.wildcard,
			players: e.players.map((e) => ({
				rid: e.rid,
				chips: e.chips,
				bet: e.bet,
				handCount: e.hand.length,
				drawCount: e.draw.length,
				discard: e.discard,
				burn: e.burn,
				jokers: e.jokers,
				loans: e.loans,
				folded: e.folded,
				dealt: e.dealt,
				studRevealed: e.studRevealed,
				jackpot: e.jackpot,
				patchfaceGuess: e.patchfaceGuess
			})),
			reveal: e.reveal,
			buyQueue: e.buyQueue,
			buyerMoney: a?.money ?? 0,
			buyerSpecials: a?.specials ?? [],
			buyerJokerBought: a?.jokerBought ?? !1,
			buyerAcquired: a?.acquired ?? [],
			buyerCherryUsed: a?.cherryUsed ?? !1,
			log: e.log.slice(-30),
			finalChips: e.finalChips
		},
		private: {
			hand: n ? [...n.hand] : [],
			peek: e.ftPeek && e.ftPeek.by === t && e.phase === "deal" ? {
				target: e.ftPeek.target,
				hand: [...R(e, e.ftPeek.target)?.hand ?? []]
			} : null,
			redJesterCard: e.pendingRedJester && e.pendingRedJester.rid === t ? e.pendingRedJester.card : null,
			pendingSmolder: e.pendingSmolder && e.pendingSmolder.rid === t ? { ...e.pendingSmolder } : null,
			pendingMulligan: e.pendingMulligan === t,
			myMoney: a?.rid === t ? a.money : 0
		}
	};
}
function $e(e) {
	return e.phase !== "done" || !e.ranking ? { phase: e.phase } : {
		phase: "done",
		winner: [e.ranking[0]],
		ranking: e.ranking,
		scores: e.finalChips ?? void 0
	};
}
var J = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: N,
	schemas: {
		action: _e,
		publicView: I,
		privateView: be
	},
	setup: ke,
	reduce: Xe,
	viewFor: Qe,
	status: $e
}, et = {
	S: "♠",
	H: "♥",
	D: "♦",
	C: "♣"
}, tt = {
	S: "#142533",
	H: "#d74246",
	D: "#d74246",
	C: "#142533"
};
function nt(e) {
	return e === 14 ? "A" : e === 13 ? "K" : e === 12 ? "Q" : e === 11 ? "J" : String(e);
}
function rt(e) {
	let t = x[e], n = [];
	return t.assistAce && n.push("±1"), t.onReveal === "crypto" && n.push("🪙"), t.onReveal === "chip1" && n.push("+1"), t.onReveal === "chip2" && n.push("+2"), t.onReveal === "credit" && n.push("$3"), t.onReveal === "richKing" && n.push("K+"), t.onAcquire === "voucher" && n.push("🎟"), t.onAcquire === "smolder1" && n.push("🔥"), t.onAcquire === "smolder2" && n.push("🔥×2"), t.junkFood && n.push("🍔"), t.queen === "pyro" && n.push("🔥Q"), t.queen === "dumpster" && n.push("🗑Q"), t.queen === "shopping" && n.push("🛒Q"), t.queen === "bridge" && n.push("♦Q"), t.doubleAs && n.push("×2"), t.altRank !== void 0 && !t.jovial && n.push("💧"), n;
}
function it(e) {
	let t = x[e], n = nt(t.rank);
	return t.altRank === void 0 ? {
		main: n,
		color: tt[t.suit]
	} : {
		main: `${n}/${nt(t.altRank)}`,
		color: tt[t.suit]
	};
}
function Y({ id: e, w: t = 54, h: n = 76, dimmed: r = !1 }) {
	let i = x[e], { main: a, color: o } = it(e), s = rt(e), c = (e) => `calc(var(--decko-card-w, ${t}px) * ${e / 54})`;
	return /* @__PURE__ */ h("span", {
		className: `decko-card relative inline-flex flex-none flex-col overflow-hidden rounded-md border-2 border-ink bg-surface ${r ? "opacity-45" : ""}`,
		style: {
			width: `var(--decko-card-w, ${t}px)`,
			height: `var(--decko-card-h, ${n}px)`
		},
		children: [
			/* @__PURE__ */ h("svg", {
				className: "pointer-events-none absolute inset-0 size-full",
				viewBox: "0 0 54 76",
				preserveAspectRatio: "none",
				"aria-hidden": !0,
				children: [
					/* @__PURE__ */ m("polygon", {
						points: "0,0 54,0 54,13 0,36",
						fill: o,
						opacity: i.starter ? .055 : .035
					}),
					/* @__PURE__ */ m("polygon", {
						points: "0,76 54,48 54,76",
						fill: o,
						opacity: .045
					}),
					/* @__PURE__ */ m("path", {
						d: "M5 60H49",
						stroke: o,
						strokeWidth: "0.7",
						opacity: "0.25"
					}),
					i.doubleAs && /* @__PURE__ */ m("text", {
						x: 42,
						y: 56,
						textAnchor: "middle",
						fontSize: 18,
						fill: tt[i.doubleAs.suit],
						opacity: .55,
						children: et[i.doubleAs.suit]
					})
				]
			}),
			/* @__PURE__ */ h("span", {
				className: "relative flex items-start justify-between px-1 pt-0.5 leading-none",
				style: {
					paddingInline: "var(--decko-card-pad-x, 4px)",
					paddingTop: "var(--decko-card-pad-y, 2px)"
				},
				children: [/* @__PURE__ */ h("span", {
					className: "flex flex-col items-center font-display font-extrabold",
					style: {
						color: o,
						fontSize: c(13)
					},
					children: [/* @__PURE__ */ m("span", { children: a }), /* @__PURE__ */ m("span", {
						style: { fontSize: c(11) },
						children: et[i.suit]
					})]
				}), i.doubleAs && /* @__PURE__ */ h("span", {
					className: "flex flex-col items-center font-display font-extrabold",
					style: {
						color: tt[i.doubleAs.suit],
						fontSize: c(13)
					},
					children: [/* @__PURE__ */ m("span", { children: nt(i.doubleAs.rank) }), /* @__PURE__ */ m("span", {
						style: { fontSize: c(11) },
						children: et[i.doubleAs.suit]
					})]
				})]
			}),
			/* @__PURE__ */ m("span", {
				className: "relative flex flex-1 items-center justify-center font-display font-extrabold tabular-nums",
				style: {
					color: o,
					fontSize: c(a.length > 2 ? 16 : 22)
				},
				children: /* @__PURE__ */ m("span", {
					style: {
						fontSize: c(30),
						lineHeight: 1
					},
					children: et[i.suit]
				})
			}),
			/* @__PURE__ */ m("span", {
				className: "relative flex items-center justify-center gap-0.5 border-t border-ink/15 font-mono font-bold tabular-nums",
				style: {
					fontSize: c(9),
					height: c(14)
				},
				children: s.join(" ")
			})
		]
	});
}
function at({ w: e = 54, h: t = 76, accent: n = "#0d766f" }) {
	return /* @__PURE__ */ m("span", {
		className: "decko-card-back relative inline-flex flex-none overflow-hidden rounded-md border-2 border-ink",
		style: {
			width: `var(--decko-card-w, ${e}px)`,
			height: `var(--decko-card-h, ${t}px)`
		},
		"aria-hidden": !0,
		children: /* @__PURE__ */ h("svg", {
			className: "absolute inset-0 size-full",
			viewBox: "0 0 54 76",
			preserveAspectRatio: "none",
			children: [
				/* @__PURE__ */ m("rect", {
					width: 54,
					height: 76,
					fill: n
				}),
				[
					-20,
					0,
					20,
					40,
					60,
					80
				].map((e) => /* @__PURE__ */ m("line", {
					x1: e,
					y1: 0,
					x2: e - 40,
					y2: 76,
					stroke: "#ffffff",
					strokeWidth: 2,
					opacity: .12
				}, e)),
				/* @__PURE__ */ m("rect", {
					x: 4,
					y: 4,
					width: 46,
					height: 68,
					rx: 4,
					fill: "none",
					stroke: "#ffffff",
					strokeWidth: 1.4,
					opacity: .5
				}),
				/* @__PURE__ */ m("text", {
					x: 27,
					y: 44,
					textAnchor: "middle",
					fontSize: 30,
					fill: "#ffffff",
					opacity: .9,
					children: "♠"
				})
			]
		})
	});
}
//#endregion
//#region src/games/decko/joker-card.tsx
var ot = (e) => `./games/decko/joker-${e}.webp`;
function st({ type: e, typeLabel: t, name: n, ariaLabel: r, cost: i, status: a, buyable: o, selected: s, onClick: c }) {
	let l = /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("span", {
			className: "decko-joker__art",
			children: /* @__PURE__ */ m("img", {
				src: ot(e),
				alt: "",
				draggable: !1
			})
		}),
		/* @__PURE__ */ h("span", {
			className: "decko-joker__copy",
			children: [
				/* @__PURE__ */ m("span", {
					className: "decko-joker__type",
					children: t
				}),
				/* @__PURE__ */ m("span", {
					className: "decko-joker__name",
					children: n
				}),
				/* @__PURE__ */ m("span", {
					className: "decko-joker__cost",
					children: i === null ? "—" : `● ${i}`
				})
			]
		}),
		a && /* @__PURE__ */ m("span", {
			className: "decko-joker__status",
			children: a
		})
	] }), u = `decko-joker${o ? " decko-joker--buyable" : ""}${s ? " decko-joker--selected" : ""}${i === null ? " decko-joker--empty" : ""}`;
	return c ? /* @__PURE__ */ m("button", {
		type: "button",
		onClick: c,
		className: u,
		"aria-label": r,
		children: l
	}) : /* @__PURE__ */ m("span", {
		className: u,
		"aria-label": r,
		children: l
	});
}
//#endregion
//#region src/games/decko/view-player.tsx
function ct(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ m(_t, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: (t) => e.send(t)
	});
}
var lt = [
	"deal",
	"raise",
	"call",
	"burn",
	"fold",
	"buy"
], ut = {
	deal: "bg-info-soft text-info-ink",
	raise: "bg-warn-soft text-warn-ink",
	call: "bg-done-soft text-done-ink",
	burn: "bg-danger-soft text-danger-ink",
	fold: "bg-ink/10 text-ink",
	buy: "bg-surface text-ink"
}, dt = {
	S: "♠",
	H: "♥",
	D: "♦",
	C: "♣"
}, ft = /* @__PURE__ */ new Set([
	"hobo",
	"magicHat",
	"mrJackpot",
	"vampire",
	"kingmaker",
	"taxman",
	"robin",
	"cherry",
	"saleswoman"
]), pt = [
	"redJester",
	"sewerClown",
	"whiteClown",
	"witch",
	"tableTalker"
], mt = [
	"coolCat",
	"fishbait",
	"monochroma",
	"blackKnight"
], ht = [
	"devil",
	"burningMan",
	"dumpsterFire",
	"harlequin",
	"marshmallow",
	"minmaxer"
], gt = [
	"sadClown",
	"gun",
	"patchface",
	"analysisParalysis"
], X = (e) => {
	let t = x[e];
	return `${nt(t.rank)}${dt[t.suit]}`;
};
function _t({ pub: e, priv: t, members: s, myRid: g, send: _ }) {
	let v = o(), y = (e) => s.find((t) => t.rid === e)?.name ?? e, b = e.players.find((e) => e.rid === g), ee = n(() => e.wildcard === "clownCar" ? lt.map((t) => e.jokerTops[t]).filter((e) => !!e) : b?.jokers ?? [], [
		e.wildcard,
		e.jokerTops,
		b?.jokers
	]), C = (e) => ee.includes(e), w = e.wildcard === "friedChicken", [T, te] = r([]), [E, D] = r("none"), [k, le] = r([]), [ue, de] = r(null), [A, fe] = r(null), [j, pe] = r(null), [M, he] = r(null), [P, F] = r(null), [ge, _e] = r(null), [ve, ye] = r(null), [I, be] = r({}), [L, R] = r({}), [xe, z] = r([]), [Se, Ce] = r(!0), [B, we] = r(null), [V, Te] = r(!1), [H, Ee] = r(null), [U, De] = r(null), Oe = `${e.round}:${e.phase}:${e.turn}`, [ke, Ae] = r(Oe);
	ke !== Oe && (Ae(Oe), te([]), D("none"), le([]), de(null), fe(null), pe(null), he(null), F(null), _e(null), ye(null), be({}), R({}), z([]), Ee(null), De(null));
	let [je, Me] = r(e.round);
	je !== e.round && (Me(e.round), Ce(!0));
	let W = e.phase === "bet" && e.turn === g && !b?.folded && !t.redJesterCard, Ne = e.phase === "deal" && e.turn === g && !b?.dealt && !t.pendingSmolder && !t.pendingMulligan, G = e.phase === "buy" && e.buyQueue[0] === g, Pe = e.phase === "stud" && e.turn === g && b?.studRevealed.length === 0, Fe = e.phase === "tcg" && e.turn === g, Ie = /* @__PURE__ */ new Set();
	(Ne || t.pendingMulligan) && Ie.add("deal"), W && (Ie.add("raise"), Ie.add("call"), Ie.add("fold"), e.firstBetRound && !e.burnUsed && Ie.add("burn")), G && Ie.add("buy");
	let Le = (e) => Ie.has(S[e].type) && !ft.has(e), K = "info", q = "", Re;
	e.wildcard && (Re = v(ae[e.wildcard])), t.redJesterCard ? (K = "accent", q = v("games.decko.redJesterPrompt")) : t.pendingSmolder ? (K = "accent", q = v("games.decko.smolderPrompt", { n: t.pendingSmolder.need })) : t.pendingMulligan ? (K = "accent", q = v("games.decko.jokerMulliganD")) : Ne ? (K = "accent", q = v("games.decko.yourTurnDeal")) : Pe ? (K = "accent", q = v("games.decko.studPick")) : Fe ? (K = "accent", q = v("games.decko.tcgPick")) : W ? (K = "accent", q = v("games.decko.yourTurnBet")) : G ? (K = "accent", q = v("games.decko.yourTurnBuy")) : e.phase === "deal" ? q = b?.dealt ? v("games.decko.waitingDeal") : v("games.decko.waitingBet", { name: y(e.turn) }) : e.phase === "buy" ? q = v("games.decko.waitingBuy", { name: y(e.buyQueue[0] ?? "") }) : e.phase !== "done" && (q = v("games.decko.waitingBet", { name: y(e.turn) }));
	let ze = t.pendingSmolder ? t.pendingSmolder.need : t.pendingMulligan || Pe ? 3 : E === "burn" ? C("minmaxer") ? 2 : 1 : E === "fold" && I.apKeep ? 2 : 1, Be = (e) => {
		if (w && W && (E === "none" || E === "raise" || E === "call")) {
			he(M === e ? null : e);
			return;
		}
		if (E === "buyBurn") {
			te([e]);
			return;
		}
		if (I.sewerSwap || I.tableTalker || I.blackKnight || I.gun) {
			pe(j === e ? null : e);
			return;
		}
		te((t) => t.includes(e) ? t.filter((t) => t !== e) : t.length >= ze ? [...t.slice(1), e] : [...t, e]);
	}, Ve = (t) => {
		if (e.market[t]) {
			if (Ne && C("merlin")) {
				R((e) => ({
					...e,
					merlinSlot: e.merlinSlot === t ? void 0 : t
				}));
				return;
			}
			if (E === "fold") {
				let e = C("sadClown") ? 2 : 1;
				le((n) => n.includes(t) ? n.filter((e) => e !== t) : n.length >= e ? [...n.slice(1), t] : [...n, t]);
				return;
			}
			if (W && I.monochroma) {
				ye(ve === t ? null : t);
				return;
			}
			Ee(H === t ? null : t);
		}
	}, He = () => {
		if (H === null) return;
		let n = H, r = e.market[n];
		if (Ee(null), !r) return;
		let i = x[r];
		(i.onAcquire === "smolder1" ? 1 : i.onAcquire === "smolder2" ? 2 : 0) > 0 && t.hand.length > 0 ? (D("buySmolder"), de(n), te([])) : _({
			type: "buyCard",
			slot: n
		});
	}, Ue = n(() => {
		if (!b || b.folded || t.hand.length === 0 || e.phase !== "deal" && e.phase !== "stud" && e.phase !== "tcg" && e.phase !== "bet" || e.wildcard === "purge") return null;
		let n = new Set(e.wildcard === "proTable" ? t.hand.filter((e) => x[e].starter) : []);
		return me({
			hand: t.hand,
			burnTop: b.burn[b.burn.length - 1],
			discardTop: b.discard[b.discard.length - 1],
			marketSlots: e.market.filter((e) => e !== ""),
			holdem: e.wildcard === "holdem",
			battleRoyale: e.wildcard === "battleRoyale",
			solo: e.wildcard === "solo",
			noSetIds: n
		});
	}, [
		b,
		t.hand,
		e.phase,
		e.wildcard,
		e.market
	]), We = n(() => new Set(Ue?.setFaces.map((e) => e.physId) ?? []), [Ue]), Ge = () => {
		if (!b) return;
		let n = k.map((t) => e.market[t]).filter((e) => e !== ""), r = I.apKeep ? T : [], i = I.gun ? j : null, a = [...t.hand.filter((e) => !r.includes(e) && e !== i), ...n];
		_({
			type: "fold",
			marketSlots: k,
			discardOrder: a,
			gunTarget: I.gun ? A ?? void 0 : void 0,
			gunBurn: i ?? void 0,
			patchfaceGuess: I.patchface ? A ?? void 0 : void 0,
			apKeep: I.apKeep && T.length === 2 ? T : void 0
		});
	}, Ke = (!I.gun || A !== null && j !== null) && (!I.patchface || A !== null) && (!I.apKeep || T.length === 2), qe = () => _({
		type: "raise",
		fcBurn: w ? M ?? void 0 : void 0,
		redJester: I.redJester || void 0,
		sewerSwap: I.sewerSwap ? j ?? void 0 : void 0,
		whiteClown: I.whiteClown || void 0,
		witchFrom: I.witch ? A ?? void 0 : void 0,
		tableTalker: I.tableTalker && A && j ? {
			target: A,
			card: j
		} : void 0
	}), Je = e.highest < e.maxBet && (!w || M !== null) && (!I.sewerSwap || j !== null) && (!I.witch || A !== null) && (!I.tableTalker || A !== null && j !== null), Ye = () => _({
		type: "call",
		fcBurn: w ? M ?? void 0 : void 0,
		coolCat: I.coolCat || void 0,
		fishbaitOrder: I.fishbait ? [...t.hand] : void 0,
		monochromaSlot: I.monochroma ? ve ?? void 0 : void 0,
		blackKnightCard: I.blackKnight ? j ?? void 0 : void 0
	}), Xe = (!w || M !== null) && (!I.monochroma || ve !== null) && (!I.blackKnight || j !== null), Ze = () => _({
		type: "burn",
		cards: I.dumpsterFire ? [] : T,
		devil: I.devil || void 0,
		burningMan: I.burningMan || void 0,
		harlequinTarget: I.harlequin ? A ?? void 0 : void 0,
		marshmallowTake: I.marshmallow ? P ?? void 0 : void 0,
		dumpsterFire: I.dumpsterFire || void 0
	}), Qe = (I.dumpsterFire ? T.length === 0 : T.length >= 1) && (!I.harlequin || A !== null) && (!I.marshmallow || P !== null), $e = t.hand.filter((e) => x[e].junkFood), J = (e) => be({
		...I,
		[e]: !I[e]
	}), et = (e) => e.filter((e) => ee.includes(e)).map((e) => v(ne[e])).join("·"), tt = et(pt), nt = et(mt), rt = Math.max(0, e.highest - (b?.bet ?? 0)), it = (e) => {
		let t = { ...e.p };
		return typeof t.rid == "string" && (t.rid = y(t.rid)), e.k === "games.decko.logShowdown" && typeof t.w == "string" && (t.w = t.w.split(",").map(y).join("、")), e.k === "games.decko.logWildcard" && typeof t.w == "string" && (t.w = v(ie[t.w])), typeof t.j == "string" && (t.j = v(ne[t.j])), typeof t.c == "string" && (t.c = X(t.c)), typeof t.k == "string" && (t.k = v({
			flush: "games.decko.specialFlush",
			burn: "games.decko.specialBurn",
			gift: "games.decko.specialGift",
			chips: "games.decko.specialChips"
		}[t.k] ?? "games.decko.specialChips")), v(e.k, t);
	}, { ref: ot } = i("pot"), { ref: ct } = i("market"), dt = G && C("cherry"), _t = G && C("saleswoman"), Q = (e) => Math.max(0, e - +!!_t), $ = e.reveal?.results[e.buyQueue[0] ?? ""]?.setRank ?? null, At = b ? /* @__PURE__ */ h("div", {
		className: "decko-piles",
		children: [
			/* @__PURE__ */ m(yt, {
				kind: "draw",
				label: v("games.decko.pileDraw"),
				count: b.drawCount,
				face: null
			}),
			/* @__PURE__ */ m(yt, {
				kind: "burn",
				label: v("games.decko.pileBurn"),
				count: b.burn.length,
				face: b.burn[b.burn.length - 1] ?? null,
				onOpen: () => we("burn")
			}),
			/* @__PURE__ */ m(yt, {
				kind: "discard",
				label: v("games.decko.pileDiscard"),
				count: b.discard.length,
				face: b.discard[b.discard.length - 1] ?? null,
				onOpen: () => we("discard")
			})
		]
	}) : null;
	return /* @__PURE__ */ m("div", {
		className: "decko-view h-full min-h-0",
		style: { "--decko-seats": e.players.length },
		children: /* @__PURE__ */ m(c, {
			adaptive: !0,
			className: "decko-layout",
			scroll: !1,
			banner: /* @__PURE__ */ h("div", {
				className: "decko-banner",
				children: [
					/* @__PURE__ */ m("div", {
						className: "decko-banner__phase",
						children: /* @__PURE__ */ m(d, {
							tone: K,
							text: q,
							sub: Re,
							chip: v("games.decko.round", { n: e.round }),
							accent: N.accent
						})
					}),
					/* @__PURE__ */ m("div", {
						className: "decko-banner__players",
						children: /* @__PURE__ */ m(f, {
							variant: "plate",
							members: s.filter((t) => e.players.some((e) => e.rid === t.rid)),
							myRid: g,
							anchorOf: (e) => `seat:${e}`,
							dimmed: (t) => e.players.find((e) => e.rid === t)?.folded ?? !1,
							action: (t) => {
								if (e.phase === "done") return null;
								let n = e.players.find((e) => e.rid === t);
								return n ? e.phase === "deal" ? n.dealt ? "done" : e.turn === t ? "pending" : null : e.phase === "stud" ? n.studRevealed.length > 0 ? "done" : e.turn === t ? "pending" : null : e.phase === "buy" ? e.buyQueue[0] === t ? "pending" : e.buyQueue.includes(t) ? null : "done" : e.turn === t && !n.folded ? "pending" : null : null;
							},
							status: (t) => {
								let n = e.players.find((e) => e.rid === t);
								return n ? /* @__PURE__ */ h("span", {
									className: "decko-seat-status flex items-center gap-1.5 text-[10px] leading-3.5 font-bold",
									children: [
										/* @__PURE__ */ h("span", {
											className: "font-mono tabular-nums",
											"aria-label": v("games.decko.pot", { n: n.chips }),
											children: ["🪙", /* @__PURE__ */ m(a, { value: n.chips })]
										}),
										n.bet > 0 && /* @__PURE__ */ h("span", {
											className: "font-mono tabular-nums text-warn-ink",
											children: ["▲", n.bet]
										}),
										n.loans > 0 && /* @__PURE__ */ h("span", {
											className: "font-mono tabular-nums text-danger-ink",
											children: ["-", n.loans * 5]
										}),
										t === e.blind && /* @__PURE__ */ m("span", {
											"aria-label": v("games.decko.blind"),
											children: "🎰"
										}),
										n.folded && /* @__PURE__ */ m("span", {
											"aria-label": v("games.decko.folded"),
											children: "🏳"
										})
									]
								}) : null;
							}
						})
					}),
					/* @__PURE__ */ m("div", {
						className: "decko-banner__log",
						children: /* @__PURE__ */ m(u, {
							log: e.log,
							line: it
						})
					})
				]
			}),
			overlay: /* @__PURE__ */ h(p, { children: [
				e.phase === "buy" && e.reveal && Se && /* @__PURE__ */ m(Ot, {
					pub: e,
					nameOf: y,
					onClose: () => Ce(!1)
				}),
				t.redJesterCard && /* @__PURE__ */ m(kt, {
					card: t.redJesterCard,
					onKeep: () => _({
						type: "redJesterResolve",
						keep: !0,
						burns: T
					}),
					onReturn: () => _({
						type: "redJesterResolve",
						keep: !1
					})
				}),
				V && /* @__PURE__ */ h("div", {
					className: "decko-overlay pointer-events-auto card mx-2 mb-2 p-2",
					children: [/* @__PURE__ */ h("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ m("p", {
							className: "flex-1 text-xs font-extrabold",
							children: v("games.decko.marketHelpTitle")
						}), /* @__PURE__ */ m("button", {
							type: "button",
							"aria-label": v("games.decko.marketHelpTitle"),
							onClick: () => Te(!1),
							className: "grid size-8 cursor-pointer place-items-center text-sm",
							children: "✕"
						})]
					}), /* @__PURE__ */ h("ul", {
						className: "mt-1 flex flex-col gap-0.5 text-[11px] leading-4",
						children: [
							/* @__PURE__ */ m("li", { children: v("games.decko.marketHelpPrice") }),
							/* @__PURE__ */ m("li", { children: v("games.decko.marketHelpBuy") }),
							/* @__PURE__ */ m("li", { children: v("games.decko.marketHelpFold") }),
							/* @__PURE__ */ m("li", { children: v("games.decko.marketHelpRefill") })
						]
					})]
				}),
				H !== null && e.market[H] && /* @__PURE__ */ h("div", {
					className: "decko-overlay pointer-events-auto card mx-2 mb-2 p-2",
					children: [
						/* @__PURE__ */ h("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ h("p", {
								className: "flex-1 text-xs font-extrabold",
								children: [
									X(e.market[H]),
									" · $",
									dt ? 0 : Q(O[H])
								]
							}), /* @__PURE__ */ m("button", {
								type: "button",
								"aria-label": X(e.market[H]),
								onClick: () => Ee(null),
								className: "grid size-8 cursor-pointer place-items-center text-sm",
								children: "✕"
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: "decko-detail-body mt-1 flex items-start gap-2",
							children: [/* @__PURE__ */ m(Y, {
								id: e.market[H],
								w: 56,
								h: 78
							}), /* @__PURE__ */ h("ul", {
								className: "flex min-w-0 flex-1 flex-col gap-0.5 text-[11px] leading-4",
								children: [ce(x[e.market[H]]).map((e) => /* @__PURE__ */ m("li", { children: v(e) }, e)), ce(x[e.market[H]]).length === 0 && /* @__PURE__ */ m("li", {
									className: "opacity-60",
									children: v("games.decko.effectNone")
								})]
							})]
						}),
						G && /* @__PURE__ */ m("button", {
							type: "button",
							disabled: t.myMoney < (dt ? 0 : Q(O[H])) || C("cherry") && e.buyerCherryUsed,
							onClick: He,
							className: "btn-base mt-2 min-h-11 w-full text-xs text-white disabled:opacity-40",
							style: { background: N.accent },
							children: v("games.decko.buyCardAt", { n: dt ? 0 : Q(O[H]) })
						})
					]
				}),
				U && /* @__PURE__ */ h("div", {
					className: "decko-overlay pointer-events-auto card mx-2 mb-2 p-2",
					children: [
						/* @__PURE__ */ h("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ m("span", {
									className: `flex-none rounded px-1 text-[9px] font-extrabold ${ut[S[U.id].type]}`,
									children: v(oe[S[U.id].type])
								}),
								/* @__PURE__ */ m("p", {
									className: "min-w-0 flex-1 truncate text-xs font-extrabold",
									children: v(ne[U.id])
								}),
								/* @__PURE__ */ h("span", {
									className: "flex-none font-mono text-[10px] tabular-nums opacity-70",
									children: ["🪙", S[U.id].cost]
								}),
								/* @__PURE__ */ m("button", {
									type: "button",
									"aria-label": v(ne[U.id]),
									onClick: () => De(null),
									className: "grid size-8 flex-none cursor-pointer place-items-center text-sm",
									children: "✕"
								})
							]
						}),
						/* @__PURE__ */ m("p", {
							className: "mt-1 text-[11px] leading-4",
							children: v(re[U.id])
						}),
						U.pile && (() => {
							let t = U.pile, n = S[U.id].cost, r = G && e.jokerTops[t] === U.id && !e.buyerJokerBought && !b?.jokers.some((e) => S[e].type === t) && (b?.chips ?? 0) >= n;
							return G && /* @__PURE__ */ h("button", {
								type: "button",
								disabled: !r,
								onClick: () => {
									_({
										type: "buyJoker",
										jokerType: t
									}), De(null);
								},
								className: "btn-base mt-2 min-h-11 w-full text-xs text-white disabled:opacity-40",
								style: { background: N.accent },
								children: [
									v("games.decko.buyJoker"),
									" 🪙",
									n
								]
							});
						})()
					]
				}),
				B && b && /* @__PURE__ */ h("div", {
					className: "decko-overlay pointer-events-auto card mx-2 mb-2 max-h-56 overflow-y-auto p-2",
					children: [/* @__PURE__ */ h("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ m("p", {
							className: "flex-1 text-xs font-extrabold",
							children: v(B === "discard" ? "games.decko.pileDiscard" : "games.decko.pileBurn")
						}), /* @__PURE__ */ m("button", {
							type: "button",
							"aria-label": v(B === "discard" ? "games.decko.pileDiscard" : "games.decko.pileBurn"),
							onClick: () => we(null),
							className: "grid size-8 cursor-pointer place-items-center text-sm",
							children: "✕"
						})]
					}), /* @__PURE__ */ h("div", {
						className: "mt-1 flex flex-wrap gap-1",
						children: [[...B === "discard" ? b.discard : b.burn].reverse().map((e) => /* @__PURE__ */ m(Y, {
							id: e,
							w: 36,
							h: 50
						}, e)), (B === "discard" ? b.discard : b.burn).length === 0 && /* @__PURE__ */ m("p", {
							className: "text-[11px] opacity-60",
							children: v("games.decko.pileEmpty")
						})]
					})]
				}),
				t.peek && /* @__PURE__ */ h("div", {
					className: "decko-overlay pointer-events-auto card mx-2 mb-2 p-2",
					children: [/* @__PURE__ */ m("p", {
						className: "text-xs font-extrabold",
						children: v("games.decko.peekTitle", { name: y(t.peek.target) })
					}), /* @__PURE__ */ m("div", {
						className: "decko-overlay-cards mt-1 flex gap-1 overflow-x-auto scrollbar-none",
						children: t.peek.hand.map((e) => /* @__PURE__ */ m(Y, {
							id: e,
							w: 36,
							h: 50
						}, e))
					})]
				}),
				t.pendingSmolder && /* @__PURE__ */ h("div", {
					className: "decko-overlay pointer-events-auto card mx-2 mb-2 p-2",
					children: [/* @__PURE__ */ m("p", {
						className: "text-xs font-extrabold",
						children: v("games.decko.smolderPrompt", { n: t.pendingSmolder.need })
					}), /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => _({
							type: "smolderResolve",
							cards: T
						}),
						className: "btn-base mt-2 min-h-11 w-full text-xs text-white",
						style: { background: N.accent },
						children: [
							v("games.decko.confirmBtn"),
							"(",
							T.length,
							"/",
							t.pendingSmolder.need,
							")"
						]
					})]
				}),
				t.pendingMulligan && /* @__PURE__ */ h("div", {
					className: "decko-overlay pointer-events-auto card mx-2 mb-2 p-2",
					children: [/* @__PURE__ */ m("p", {
						className: "text-xs font-extrabold",
						children: v("games.decko.jokerMulliganD")
					}), /* @__PURE__ */ h("div", {
						className: "mt-2 flex gap-1.5",
						children: [/* @__PURE__ */ h("button", {
							type: "button",
							disabled: T.length !== 3,
							onClick: () => _({
								type: "mulligan",
								cards: T
							}),
							className: "btn-base min-h-11 flex-1 text-xs text-white disabled:opacity-40",
							style: { background: N.accent },
							children: [
								v("games.decko.jokerMulligan"),
								"(",
								T.length,
								"/3)"
							]
						}), /* @__PURE__ */ m("button", {
							type: "button",
							onClick: () => _({
								type: "mulligan",
								cards: []
							}),
							className: "btn-quiet min-h-11 flex-none px-3 text-xs",
							children: v("games.decko.tcgSkip")
						})]
					})]
				})
			] }),
			actionsHeight: "decko-actions-slot h-53 short:h-28",
			actions: /* @__PURE__ */ h("div", {
				className: "decko-actions",
				children: [
					/* @__PURE__ */ h("div", {
						className: "decko-owned",
						children: [
							Ue && /* @__PURE__ */ h("span", {
								className: "decko-owned__preview",
								children: [
									v("games.decko.previewBest"),
									": ",
									v(se[Ue.setRank])
								]
							}),
							ee.map((e) => /* @__PURE__ */ h("button", {
								type: "button",
								"aria-label": v(ne[e]),
								onClick: () => De({ id: e }),
								className: "decko-owned__joker relative cursor-pointer",
								children: [
									Le(e) && /* @__PURE__ */ m(l, { radius: 4 }),
									/* @__PURE__ */ m("img", {
										src: `./games/decko/joker-${S[e].type}.webp`,
										alt: "",
										draggable: !1
									}),
									v(ne[e])
								]
							}, e)),
							W && $e.length > 0 && /* @__PURE__ */ h("button", {
								type: "button",
								title: v("games.decko.junkFood", { n: $e.length }),
								"aria-label": v("games.decko.junkFood", { n: $e.length }),
								onClick: () => _({
									type: "junkFood",
									cardIds: $e
								}),
								className: "flex-none rounded bg-warn-soft px-1.5 py-0.5 text-[10px] font-extrabold text-warn-ink",
								children: ["🍔×", $e.length]
							})
						]
					}),
					e.phase === "buy" && E !== "buyBurn" && E !== "buySmolder" ? /* @__PURE__ */ h("div", {
						className: "decko-hand",
						children: [
							/* @__PURE__ */ m("span", {
								className: "decko-acquired-title flex-none text-[9px] font-extrabold opacity-60",
								children: v("games.decko.acquiredTitle")
							}),
							e.buyerAcquired.map((e) => {
								let t = G && C("energyDrink");
								return /* @__PURE__ */ h("button", {
									type: "button",
									disabled: !t,
									"aria-pressed": xe.includes(e),
									onClick: () => z((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]),
									className: `relative flex-none ${t ? "cursor-pointer" : "cursor-default"} ${xe.includes(e) ? "rounded ring-2 ring-ink" : ""}`,
									children: [/* @__PURE__ */ m(Y, {
										id: e,
										w: 44,
										h: 62
									}), xe.includes(e) && /* @__PURE__ */ m("span", {
										className: "absolute -top-1 -right-1 text-[10px]",
										children: "⚡"
									})]
								}, e);
							}),
							e.buyerAcquired.length === 0 && /* @__PURE__ */ m("span", {
								className: "text-[10px] opacity-50",
								children: v("games.decko.acquiredEmpty")
							})
						]
					}) : /* @__PURE__ */ h("div", {
						className: "decko-hand",
						children: [t.hand.map((e) => {
							let n = T.includes(e) || j === e || M === e, r = We.has(e), i = Ne || t.pendingSmolder !== null || t.pendingMulligan || Pe || W || E === "buyBurn";
							return /* @__PURE__ */ m("button", {
								type: "button",
								disabled: !i,
								"aria-pressed": n,
								onClick: () => Be(e),
								style: r ? {
									outline: `2px solid ${N.accent}`,
									outlineOffset: 1,
									borderRadius: 6
								} : void 0,
								className: `flex-none transition-transform ${i ? "cursor-pointer" : "cursor-default"}`,
								children: /* @__PURE__ */ m(Y, {
									id: e,
									w: 60,
									h: 84,
									dimmed: b?.folded
								})
							}, e);
						}), t.hand.length === 0 && /* @__PURE__ */ m(at, {
							w: 60,
							h: 84,
							accent: N.accent
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "decko-controls relative",
						children: [
							e.phase === "deal" && Ne && /* @__PURE__ */ m(xt, {
								pub: e,
								members: s,
								myRid: g,
								hasJ: C,
								dealOpts: L,
								setDealOpts: R,
								onDeal: () => _({
									type: "deal",
									...L
								})
							}),
							e.phase === "deal" && !Ne && /* @__PURE__ */ m("p", {
								className: "flex flex-1 items-center justify-center text-xs font-bold opacity-60",
								children: v("games.decko.waitingDeal")
							}),
							e.phase === "stud" && (Pe ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("p", {
								className: "flex flex-1 items-center text-xs font-bold",
								children: [
									v("games.decko.studPick"),
									": ",
									T.length,
									"/3"
								]
							}), /* @__PURE__ */ m("button", {
								type: "button",
								disabled: T.length !== 3,
								onClick: () => _({
									type: "studReveal",
									cards: T
								}),
								className: "btn-base px-4 text-sm text-white disabled:opacity-40",
								style: { background: N.accent },
								children: v("games.decko.studPick")
							})] }) : /* @__PURE__ */ m("p", {
								className: "flex flex-1 items-center justify-center text-xs font-bold opacity-60",
								children: v("games.decko.waitingBet", { name: y(e.turn) })
							})),
							e.phase === "tcg" && (Fe ? /* @__PURE__ */ m(St, {
								pub: e,
								myRid: g,
								send: _
							}) : /* @__PURE__ */ m("p", {
								className: "flex flex-1 items-center justify-center text-xs font-bold opacity-60",
								children: v("games.decko.waitingBet", { name: y(e.turn) })
							})),
							e.phase === "bet" && W && E === "none" && /* @__PURE__ */ h(p, { children: [
								e.firstBetRound && !e.burnUsed && /* @__PURE__ */ m(Ct, {
									kind: "quiet",
									label: `🔥${v("games.decko.burn")}`,
									caption: et(ht),
									onClick: () => D("burn")
								}),
								/* @__PURE__ */ m(Ct, {
									kind: "accent",
									label: v("games.decko.raise", { n: e.highest + 1 }),
									caption: tt,
									disabled: e.highest >= e.maxBet || w && !M && !tt,
									onClick: () => {
										tt ? D("raise") : qe();
									}
								}),
								/* @__PURE__ */ m(Ct, {
									kind: "surface",
									label: rt > 0 ? v("games.decko.call", { n: rt }) : v("games.decko.callFree"),
									caption: nt,
									disabled: w && !M && !nt,
									onClick: () => {
										nt ? D("call") : Ye();
									}
								}),
								/* @__PURE__ */ m(Ct, {
									kind: "danger",
									label: v("games.decko.fold"),
									caption: et(gt),
									onClick: () => D("fold")
								}),
								w && !M && /* @__PURE__ */ m("span", {
									className: "absolute -top-5 right-1 text-[10px] font-bold text-warn-ink",
									children: v("games.decko.errFcBurn")
								})
							] }),
							e.phase === "bet" && W && E === "raise" && /* @__PURE__ */ h(p, { children: [
								/* @__PURE__ */ h("span", {
									className: "decko-options flex min-w-0 flex-1 items-center gap-1 overflow-x-auto overflow-y-hidden scrollbar-none",
									children: [
										C("redJester") && /* @__PURE__ */ m(Z, {
											label: v("games.decko.jokerRedJester"),
											on: !!I.redJester,
											onToggle: () => J("redJester")
										}),
										C("sewerClown") && /* @__PURE__ */ m(Z, {
											label: `${v("games.decko.jokerSewerClown")}${I.sewerSwap ? j ? ` ${X(j)}` : " ?" : ""}`,
											on: !!I.sewerSwap,
											onToggle: () => J("sewerSwap")
										}),
										C("whiteClown") && /* @__PURE__ */ m(Z, {
											label: v("games.decko.jokerWhiteClown"),
											on: !!I.whiteClown,
											onToggle: () => J("whiteClown")
										}),
										C("witch") && /* @__PURE__ */ m(Z, {
											label: v("games.decko.jokerWitch"),
											on: !!I.witch,
											onToggle: () => J("witch")
										}),
										C("tableTalker") && /* @__PURE__ */ m(Z, {
											label: `${v("games.decko.jokerTableTalker")}${I.tableTalker ? j ? ` ${X(j)}` : " ?" : ""}`,
											on: !!I.tableTalker,
											onToggle: () => J("tableTalker")
										}),
										(I.witch || I.tableTalker) && /* @__PURE__ */ m(bt, {
											pub: e,
											members: s,
											myRid: g,
											target: A,
											setTarget: fe
										})
									]
								}),
								/* @__PURE__ */ m("button", {
									type: "button",
									disabled: !Je,
									onClick: () => {
										qe(), D("none");
									},
									className: "btn-base min-h-11 flex-none px-3 text-xs text-white disabled:opacity-40",
									style: { background: N.accent },
									children: v("games.decko.raise", { n: e.highest + 1 })
								}),
								/* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => D("none"),
									className: "btn-quiet min-h-11 flex-none px-2 text-sm",
									children: "✕"
								}),
								w && !M && /* @__PURE__ */ m("span", {
									className: "absolute -top-5 right-1 text-[10px] font-bold text-warn-ink",
									children: v("games.decko.errFcBurn")
								})
							] }),
							e.phase === "bet" && W && E === "call" && /* @__PURE__ */ h(p, { children: [
								/* @__PURE__ */ h("span", {
									className: "decko-options flex min-w-0 flex-1 items-center gap-1 overflow-x-auto overflow-y-hidden scrollbar-none",
									children: [
										C("coolCat") && /* @__PURE__ */ m(Z, {
											label: v("games.decko.jokerCoolCat"),
											on: !!I.coolCat,
											onToggle: () => J("coolCat")
										}),
										C("fishbait") && /* @__PURE__ */ m(Z, {
											label: v("games.decko.jokerFishbait"),
											on: !!I.fishbait,
											onToggle: () => J("fishbait")
										}),
										C("monochroma") && /* @__PURE__ */ m(Z, {
											label: `${v("games.decko.jokerMonochroma")}${I.monochroma ? ve === null ? " ?" : ` ${X(e.market[ve])}` : ""}`,
											on: !!I.monochroma,
											onToggle: () => J("monochroma")
										}),
										C("blackKnight") && /* @__PURE__ */ m(Z, {
											label: `${v("games.decko.jokerBlackKnight")}${I.blackKnight ? j ? ` ${X(j)}` : " ?" : ""}`,
											on: !!I.blackKnight,
											onToggle: () => J("blackKnight")
										})
									]
								}),
								/* @__PURE__ */ m("button", {
									type: "button",
									disabled: !Xe,
									onClick: () => {
										Ye(), D("none");
									},
									className: "btn-base min-h-11 flex-none bg-surface px-3 text-xs disabled:opacity-40",
									children: rt > 0 ? v("games.decko.call", { n: rt }) : v("games.decko.callFree")
								}),
								/* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => D("none"),
									className: "btn-quiet min-h-11 flex-none px-2 text-sm",
									children: "✕"
								}),
								w && !M && /* @__PURE__ */ m("span", {
									className: "absolute -top-5 right-1 text-[10px] font-bold text-warn-ink",
									children: v("games.decko.errFcBurn")
								})
							] }),
							e.phase === "bet" && W && E === "burn" && /* @__PURE__ */ m(wt, {
								me: b,
								pub: e,
								members: s,
								myRid: g,
								hasJ: C,
								sel: T,
								opts: I,
								setOpts: be,
								target: A,
								setTarget: fe,
								burnPick: P,
								setBurnPick: F,
								ready: Qe,
								onConfirm: Ze,
								onCancel: () => D("none")
							}),
							e.phase === "bet" && W && E === "fold" && /* @__PURE__ */ m(Tt, {
								pub: e,
								members: s,
								myRid: g,
								hasJ: C,
								foldSlots: k,
								opts: I,
								setOpts: be,
								target: A,
								setTarget: fe,
								sel: T,
								ready: Ke,
								onConfirm: Ge,
								onCancel: () => D("none")
							}),
							e.phase === "bet" && !W && /* @__PURE__ */ m("p", {
								className: "flex flex-1 items-center justify-center text-xs font-bold opacity-60",
								children: b?.folded ? v("games.decko.folded") : v("games.decko.waitingBet", { name: y(e.turn) })
							}),
							e.phase === "buy" && G && E !== "buyBurn" && E !== "buyGift" && E !== "buySmolder" && /* @__PURE__ */ m(Et, {
								pub: e,
								priv: t,
								hasJ: C,
								priceOf: Q,
								onFlush: () => _({ type: "buyFlush" }),
								onBurnMode: () => D("buyBurn"),
								onGiftMode: () => D("buyGift"),
								onChips: (e) => _({
									type: "buyChips",
									n: e
								}),
								onDone: () => _({
									type: "buyDone",
									discardOrder: [...t.hand, ...e.buyerAcquired.filter((e) => !xe.includes(e))],
									energyToTop: xe.length > 0 ? xe : void 0
								})
							}),
							e.phase === "buy" && G && E === "buyBurn" && /* @__PURE__ */ h(p, { children: [
								/* @__PURE__ */ m("p", {
									className: "flex flex-1 items-center text-xs font-bold",
									children: v("games.decko.buyBurn", { n: Q(2) })
								}),
								/* @__PURE__ */ m("button", {
									type: "button",
									disabled: T.length !== 1,
									onClick: () => {
										_({
											type: "buyBurn",
											card: T[0]
										}), D("none");
									},
									className: "btn-base bg-surface px-3 text-sm disabled:opacity-40",
									children: v("games.decko.buyBurn", { n: Q(2) })
								}),
								/* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => D("none"),
									className: "btn-quiet px-3 text-sm",
									children: "✕"
								})
							] }),
							e.phase === "buy" && G && E === "buyGift" && /* @__PURE__ */ m(Dt, {
								pub: e,
								members: s,
								myRid: g,
								giftCard: ge,
								setGiftCard: _e,
								target: A,
								setTarget: fe,
								cost: Q(3),
								onConfirm: () => {
									ge && A && _({
										type: "buyGift",
										card: ge,
										target: A
									}), D("none");
								},
								onCancel: () => D("none")
							}),
							e.phase === "buy" && G && E === "buySmolder" && ue !== null && /* @__PURE__ */ h(p, { children: [
								/* @__PURE__ */ m("p", {
									className: "flex flex-1 items-center text-xs font-bold",
									children: v("games.decko.smolderPrompt", { n: x[e.market[ue]].onAcquire === "smolder2" ? 2 : 1 })
								}),
								/* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => {
										_({
											type: "buyCard",
											slot: ue,
											burns: T
										}), D("none");
									},
									className: "btn-base px-3 text-sm text-white",
									style: { background: N.accent },
									children: v("games.decko.dealDone")
								}),
								/* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => D("none"),
									className: "btn-quiet px-3 text-sm",
									children: "✕"
								})
							] }),
							e.phase === "buy" && !G && /* @__PURE__ */ m("p", {
								className: "flex flex-1 items-center justify-center text-xs font-bold opacity-60",
								children: v("games.decko.waitingBuy", { name: y(e.buyQueue[0] ?? "") })
							})
						]
					})
				]
			}),
			children: /* @__PURE__ */ m("div", {
				className: "decko-board",
				style: { backgroundImage: "url(./games/decko/mat.webp)" },
				children: /* @__PURE__ */ h("div", {
					className: "decko-board__inner",
					children: [
						/* @__PURE__ */ h("div", {
							className: "decko-track-zone",
							children: [
								/* @__PURE__ */ h("div", {
									className: "decko-board__head",
									children: [/* @__PURE__ */ m("strong", { children: v("games.decko.roundTrack") }), /* @__PURE__ */ m("span", { children: v("games.decko.betRange", {
										min: e.minBet,
										max: e.maxBet
									}) })]
								}),
								/* @__PURE__ */ m("div", {
									className: "decko-track",
									role: "list",
									"aria-label": v("games.decko.roundTrack"),
									children: Array.from({ length: 12 }, (e, t) => t + 1).map((t) => /* @__PURE__ */ m("span", {
										role: "listitem",
										"aria-current": e.round === t ? "step" : void 0,
										className: `decko-track__space${t === 4 ? " decko-track__space--red" : t === 8 ? " decko-track__space--blue" : t === 5 || t === 9 ? " decko-track__space--refresh" : ""}${e.round === t ? " decko-track__space--current" : ""}`,
										children: t
									}, t))
								}),
								/* @__PURE__ */ h("div", {
									className: "decko-track__ranges",
									children: [
										/* @__PURE__ */ m("span", { children: "1–3: 1/5" }),
										/* @__PURE__ */ m("span", { children: "4–7: 2/7" }),
										/* @__PURE__ */ m("span", { children: "8–11: 3/9" }),
										/* @__PURE__ */ m("span", { children: "12: 5/12" })
									]
								})
							]
						}),
						/* @__PURE__ */ h("div", {
							className: "decko-pot-zone",
							children: [
								/* @__PURE__ */ h("div", {
									className: "decko-pot-side",
									children: [
										/* @__PURE__ */ m("span", {
											className: "decko-blind-mark",
											"aria-hidden": !0,
											children: "★"
										}),
										/* @__PURE__ */ m("span", { children: v("games.decko.blind") }),
										/* @__PURE__ */ m("span", { children: y(e.blind) })
									]
								}),
								/* @__PURE__ */ h("div", {
									className: "decko-pot",
									children: [
										/* @__PURE__ */ m("span", {
											className: "decko-pot__title",
											children: e.phase === "buy" ? v("games.decko.phaseBuy") : v("games.decko.housePot")
										}),
										/* @__PURE__ */ m("span", {
											ref: ot,
											className: "decko-pot__value font-mono tabular-nums",
											children: e.phase === "buy" ? /* @__PURE__ */ h(p, { children: ["$", e.buyerMoney] }) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("span", {
												className: "decko-pot__chips",
												"aria-hidden": !0,
												children: [
													/* @__PURE__ */ m("i", { className: "decko-chip" }),
													/* @__PURE__ */ m("i", { className: "decko-chip decko-chip--red" }),
													/* @__PURE__ */ m("i", { className: "decko-chip" })
												]
											}), e.housePot + e.players.reduce((e, t) => e + t.bet, 0)] })
										}),
										/* @__PURE__ */ m("span", {
											className: "decko-pot__sub",
											children: e.phase === "buy" ? $ === null ? y(e.buyQueue[0] ?? "") : v(se[$]) : e.wildcard ? v(ie[e.wildcard]) : v("games.decko.round", { n: e.round })
										})
									]
								}),
								/* @__PURE__ */ h("div", {
									className: "decko-pot-side",
									children: [/* @__PURE__ */ m("span", { children: v("games.decko.highest", { n: e.highest }) }), /* @__PURE__ */ m("strong", {
										className: "font-mono tabular-nums",
										children: e.highest
									})]
								})
							]
						}),
						/* @__PURE__ */ h("div", {
							ref: ct,
							className: `decko-market${e.market.length === 0 ? " decko-market--unstocked" : ""}`,
							children: [
								/* @__PURE__ */ m(vt, { onHelp: () => Te(!0) }),
								/* @__PURE__ */ m("div", {
									className: "decko-market__slots",
									children: O.map((n, r) => {
										let i = e.market[r], a = L.merlinSlot === r || k.includes(r) || ve === r || H === r || ue === r, o = dt ? 0 : Q(O[r]), s = Ne && C("merlin") || E === "fold" || E === "call" && !!I.monochroma, c = G && t.myMoney >= o && (!C("cherry") || !e.buyerCherryUsed);
										return /* @__PURE__ */ h("div", {
											className: `decko-market-slot${a ? " decko-market-slot--selected" : ""}${i && (s || c) && !a ? " decko-market-slot--legal" : ""}`,
											children: [/* @__PURE__ */ h("span", {
												className: "decko-market-slot__price",
												children: ["$", o]
											}), i ? /* @__PURE__ */ m("button", {
												type: "button",
												onClick: () => Ve(r),
												"aria-label": `${X(i)}, $${o}`,
												"aria-pressed": a,
												className: "decko-market-slot__card",
												children: /* @__PURE__ */ m(Y, {
													id: i,
													w: 53,
													h: 75
												})
											}) : /* @__PURE__ */ m("span", {
												className: "decko-market-slot__empty",
												children: v(e.market.length === 0 ? "games.decko.marketEmpty" : "games.decko.marketSold")
											})]
										}, r);
									})
								}),
								/* @__PURE__ */ m("div", {
									className: "decko-market__hint",
									children: H !== null && e.market[H] ? v("games.decko.selectedMarket", {
										card: X(e.market[H]),
										price: dt ? 0 : Q(O[H])
									}) : v("games.decko.marketCurrentPrices", { prices: O.map((e) => dt ? 0 : Q(e)).join(" / $") })
								})
							]
						}),
						/* @__PURE__ */ h("div", {
							className: "decko-jokers",
							children: [/* @__PURE__ */ h("div", {
								className: "decko-section-head",
								children: [/* @__PURE__ */ m("strong", { children: v("games.decko.jokerPiles") }), /* @__PURE__ */ m("span", { children: v("games.decko.buyJoker") })]
							}), /* @__PURE__ */ m("div", {
								className: "decko-jokers__grid",
								children: lt.map((t) => {
									let n = e.jokerTops[t], r = b?.jokers.some((e) => S[e].type === t) ?? !1, i = n ? S[n].cost : null, a = G && n ? r ? v("games.decko.jokerOwned") : e.buyerJokerBought ? v("games.decko.jokerPurchased") : (b?.chips ?? 0) < (i ?? 0) ? v("games.decko.jokerNoChips") : void 0 : void 0, o = v(n ? ne[n] : "games.decko.pileEmpty");
									return /* @__PURE__ */ m(st, {
										type: t,
										typeLabel: v(oe[t]),
										name: o,
										ariaLabel: `${v(oe[t])}: ${o}${i === null ? "" : `, ${i}`}${a ? `, ${a}` : ""}`,
										cost: i,
										status: a,
										buyable: G && !!n && !a,
										selected: U?.pile === t,
										onClick: n ? () => De({
											id: n,
											pile: t
										}) : void 0
									}, t);
								})
							})]
						}),
						At
					]
				})
			})
		})
	});
}
function vt({ onHelp: e }) {
	let t = o();
	return /* @__PURE__ */ h("div", {
		className: "decko-section-head",
		children: [/* @__PURE__ */ m("strong", { children: t("games.decko.market") }), /* @__PURE__ */ h("span", {
			className: "decko-market__help",
			children: [/* @__PURE__ */ m("span", { children: t("games.decko.marketHelpTitle") }), /* @__PURE__ */ m("button", {
				type: "button",
				"aria-label": t("games.decko.marketHelpTitle"),
				onClick: e,
				children: /* @__PURE__ */ m(s, { size: 16 })
			})]
		})]
	});
}
function yt({ kind: e, label: t, count: n, face: r, onOpen: i }) {
	let a = /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("span", {
		className: "decko-pile__face",
		"aria-hidden": !0,
		children: r ? /* @__PURE__ */ m(Y, {
			id: r,
			w: 26,
			h: 36
		}) : i ? /* @__PURE__ */ m("span", { className: "decko-pile__empty block h-9 w-6.5 rounded border-2 border-dashed border-white/50" }) : /* @__PURE__ */ m(at, {
			w: 26,
			h: 36,
			accent: N.accent
		})
	}), /* @__PURE__ */ h("span", {
		className: "decko-pile__copy",
		children: [/* @__PURE__ */ m("span", {
			className: "decko-pile__name",
			children: t
		}), /* @__PURE__ */ m("span", {
			className: "decko-pile__count font-mono tabular-nums",
			children: n
		})]
	})] }), o = `decko-pile decko-pile--${e}`;
	return i ? /* @__PURE__ */ m("button", {
		type: "button",
		"aria-label": `${t}: ${n}`,
		onClick: i,
		className: o,
		children: a
	}) : /* @__PURE__ */ m("span", {
		className: o,
		"aria-label": `${t}: ${n}`,
		children: a
	});
}
function bt({ pub: e, members: t, myRid: n, target: r, setTarget: i, includeFolded: a = !1 }) {
	let o = e.players.filter((e) => e.rid !== n && (a || !e.folded));
	return /* @__PURE__ */ m("span", {
		className: "decko-targets flex items-center gap-1 overflow-x-auto",
		children: o.map((e) => {
			let n = t.find((t) => t.rid === e.rid)?.name ?? e.rid;
			return /* @__PURE__ */ m("button", {
				type: "button",
				onClick: () => i(r === e.rid ? null : e.rid),
				className: `min-h-8 flex-none rounded-lg border-2 px-2 text-xs font-bold ${r === e.rid ? "border-ink bg-surface" : "border-ink/25"}`,
				children: n
			}, e.rid);
		})
	});
}
function Z({ label: e, on: t, onToggle: n, disabled: r = !1 }) {
	return /* @__PURE__ */ m("button", {
		type: "button",
		disabled: r,
		onClick: n,
		"aria-pressed": t,
		className: `decko-option min-h-8 flex-none rounded-lg border-2 px-2 text-[11px] font-extrabold disabled:opacity-40 ${t ? "border-ink bg-surface shadow-[2px_2px_0_var(--color-ink)]" : "border-ink/25"}`,
		children: e
	});
}
function xt({ pub: e, members: t, myRid: n, hasJ: r, dealOpts: i, setDealOpts: a, onDeal: s }) {
	let c = o(), l = e.players.find((e) => e.rid === n);
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("span", {
		className: "decko-options flex min-w-0 flex-1 items-center gap-1 overflow-x-auto overflow-y-hidden scrollbar-none",
		children: [
			r("garbagePailBoy") && /* @__PURE__ */ m(Z, {
				label: c("games.decko.jokerGarbagePailBoy"),
				on: !!i.garbagePail,
				onToggle: () => a({
					...i,
					garbagePail: !i.garbagePail
				}),
				disabled: (l?.discard.length ?? 0) === 0
			}),
			r("merlin") && /* @__PURE__ */ h("span", {
				className: "flex-none text-[10px] font-bold opacity-70",
				children: [
					c("games.decko.jokerMerlin"),
					": ",
					i.merlinSlot === void 0 ? "—" : X(e.market[i.merlinSlot])
				]
			}),
			r("babyJoker") && !i.babyJokerType && /* @__PURE__ */ m("span", {
				className: "flex items-center gap-0.5",
				children: lt.filter((t) => e.jokerTops[t] && !l?.jokers.some((e) => S[e].type === t)).map((e) => /* @__PURE__ */ m(Z, {
					label: `👶${c(oe[e])}`,
					on: !1,
					onToggle: () => a({
						...i,
						babyJokerType: e
					})
				}, e))
			}),
			i.babyJokerType && /* @__PURE__ */ m(Z, {
				label: `👶${c(oe[i.babyJokerType])}`,
				on: !0,
				onToggle: () => a({
					...i,
					babyJokerType: void 0
				})
			}),
			r("fortuneTeller") && /* @__PURE__ */ m(bt, {
				pub: e,
				members: t,
				myRid: n,
				target: i.fortuneTellerTarget ?? null,
				setTarget: (e) => a({
					...i,
					fortuneTellerTarget: e ?? void 0
				}),
				includeFolded: !0
			})
		]
	}), /* @__PURE__ */ m("button", {
		type: "button",
		onClick: s,
		className: "btn-base flex-none px-4 text-sm text-white",
		style: { background: N.accent },
		children: c("games.decko.dealDone")
	})] });
}
function St({ pub: e, myRid: t, send: n }) {
	let r = o(), i = e.players.findIndex((e) => e.rid === t), a = e.players[(i + 1) % e.players.length];
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("span", {
		className: "decko-options flex min-w-0 flex-1 items-center gap-1 overflow-x-auto overflow-y-hidden scrollbar-none",
		children: [a.burn.length === 0 && /* @__PURE__ */ m("span", {
			className: "text-xs opacity-60",
			children: "🔥—"
		}), a.burn.map((e) => /* @__PURE__ */ m("button", {
			type: "button",
			onClick: () => n({
				type: "tcg",
				cardId: e
			}),
			className: "flex-none cursor-pointer",
			children: /* @__PURE__ */ m(Y, {
				id: e,
				w: 36,
				h: 50
			})
		}, e))]
	}), /* @__PURE__ */ m("button", {
		type: "button",
		onClick: () => n({ type: "tcg" }),
		className: "btn-quiet flex-none px-3 text-sm",
		children: r("games.decko.tcgSkip")
	})] });
}
function Ct({ label: e, caption: t, onClick: n, disabled: r = !1, kind: i }) {
	return /* @__PURE__ */ h("button", {
		type: "button",
		disabled: r,
		onClick: n,
		className: `decko-dock flex min-h-11 min-w-0 flex-1 flex-col items-center justify-center gap-0 px-2 disabled:opacity-40 ${{
			accent: "btn-base text-white",
			surface: "btn-base bg-surface",
			danger: "btn-base bg-danger-soft text-danger-ink",
			quiet: "btn-quiet"
		}[i]}`,
		style: i === "accent" ? { background: N.accent } : void 0,
		children: [/* @__PURE__ */ m("span", {
			className: "max-w-full text-center text-xs leading-4 font-extrabold",
			children: e
		}), t && /* @__PURE__ */ m("span", {
			className: "decko-dock__caption max-w-full truncate text-[9px] leading-3 opacity-70",
			children: t
		})]
	});
}
function wt({ me: e, pub: t, members: n, myRid: r, hasJ: i, sel: a, opts: s, setOpts: c, target: l, setTarget: u, burnPick: d, setBurnPick: f, ready: g, onConfirm: _, onCancel: v }) {
	let y = o(), b = (e) => c({
		...s,
		[e]: !s[e]
	});
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ h("span", {
			className: "decko-options flex min-w-0 flex-1 items-center gap-1 overflow-x-auto overflow-y-hidden scrollbar-none",
			children: [
				/* @__PURE__ */ h("span", {
					className: "flex-none text-xs font-bold",
					children: [
						"🔥",
						a.length,
						"/",
						i("minmaxer") ? 2 : 1
					]
				}),
				i("devil") && /* @__PURE__ */ m(Z, {
					label: y("games.decko.jokerDevil"),
					on: !!s.devil,
					onToggle: () => b("devil")
				}),
				i("burningMan") && /* @__PURE__ */ m(Z, {
					label: y("games.decko.jokerBurningMan"),
					on: !!s.burningMan,
					onToggle: () => b("burningMan")
				}),
				i("dumpsterFire") && /* @__PURE__ */ m(Z, {
					label: y("games.decko.jokerDumpsterFire"),
					on: !!s.dumpsterFire,
					onToggle: () => b("dumpsterFire")
				}),
				i("harlequin") && /* @__PURE__ */ m(Z, {
					label: y("games.decko.jokerHarlequin"),
					on: !!s.harlequin,
					onToggle: () => b("harlequin")
				}),
				s.harlequin && /* @__PURE__ */ m(bt, {
					pub: t,
					members: n,
					myRid: r,
					target: l,
					setTarget: u
				}),
				i("marshmallow") && e && e.burn.length > 0 && /* @__PURE__ */ m("span", {
					className: "flex items-center gap-0.5",
					children: e.burn.map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => f(d === e ? null : e),
						className: `flex-none rounded ${d === e ? "ring-2 ring-ink" : ""}`,
						children: /* @__PURE__ */ m(Y, {
							id: e,
							w: 26,
							h: 36
						})
					}, e))
				})
			]
		}),
		/* @__PURE__ */ m("button", {
			type: "button",
			disabled: !g,
			onClick: _,
			className: "btn-base min-h-11 flex-none px-3 text-xs text-white disabled:opacity-40",
			style: { background: N.accent },
			children: y("games.decko.burn")
		}),
		/* @__PURE__ */ m("button", {
			type: "button",
			onClick: v,
			className: "btn-quiet min-h-11 flex-none px-2 text-sm",
			children: "✕"
		})
	] });
}
function Tt({ pub: e, members: t, myRid: n, hasJ: r, foldSlots: i, opts: a, setOpts: s, target: c, setTarget: l, sel: u, ready: d, onConfirm: f, onCancel: g }) {
	let _ = o(), v = (e) => s({
		...a,
		[e]: !a[e]
	}), y = a.gun || a.patchface;
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ h("span", {
			className: "decko-options flex min-w-0 flex-1 items-center gap-1 overflow-x-auto overflow-y-hidden scrollbar-none",
			children: [
				/* @__PURE__ */ h("span", {
					className: "flex-none text-xs font-bold",
					children: [
						_("games.decko.takeMarket", { n: r("sadClown") ? 2 : 1 }),
						": ",
						i.length
					]
				}),
				r("gun") && /* @__PURE__ */ m(Z, {
					label: _("games.decko.jokerGun"),
					on: !!a.gun,
					onToggle: () => v("gun")
				}),
				r("patchface") && /* @__PURE__ */ m(Z, {
					label: _("games.decko.jokerPatchface"),
					on: !!a.patchface,
					onToggle: () => v("patchface")
				}),
				r("analysisParalysis") && /* @__PURE__ */ m(Z, {
					label: `${_("games.decko.jokerAnalysisParalysis")}${a.apKeep ? ` ${u.length}/2` : ""}`,
					on: !!a.apKeep,
					onToggle: () => v("apKeep")
				}),
				y && /* @__PURE__ */ m(bt, {
					pub: e,
					members: t,
					myRid: n,
					target: c,
					setTarget: l,
					includeFolded: !!a.patchface
				})
			]
		}),
		/* @__PURE__ */ m("button", {
			type: "button",
			disabled: !d,
			onClick: f,
			className: "btn-base min-h-11 flex-none bg-danger-soft px-3 text-xs text-danger-ink disabled:opacity-40",
			children: _("games.decko.confirmFold")
		}),
		/* @__PURE__ */ m("button", {
			type: "button",
			onClick: g,
			className: "btn-quiet min-h-11 flex-none px-2 text-sm",
			children: "✕"
		})
	] });
}
function Et({ pub: e, priv: t, hasJ: n, priceOf: r, onFlush: i, onBurnMode: a, onGiftMode: s, onChips: c, onDone: l }) {
	let u = o(), d = t.myMoney, f = e.buyerSpecials, g = e.players.find((t) => t.rid === e.buyQueue[0]), _ = n("toilet") ? 0 : r(2), v = n("pizzaTime") ? 0 : r(2), y = n("pizzaTime") ? 0 : r(3);
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("span", {
		className: "decko-options flex min-w-0 flex-1 items-center gap-1 overflow-x-auto overflow-y-hidden scrollbar-none",
		children: [
			/* @__PURE__ */ h("span", {
				className: "flex-none font-mono text-sm font-extrabold tabular-nums",
				children: ["$", d]
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				disabled: f.includes("flush") || d < _,
				onClick: i,
				className: "btn-quiet min-h-11 flex-none px-2 text-[11px] disabled:opacity-40",
				children: u("games.decko.buyFlush", { n: _ })
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				disabled: f.includes("burn") || d < v || t.hand.length === 0,
				onClick: a,
				className: "btn-quiet min-h-11 flex-none px-2 text-[11px] disabled:opacity-40",
				children: u("games.decko.buyBurn", { n: v })
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				disabled: f.includes("gift") || d < y || (g?.burn.length ?? 0) === 0,
				onClick: s,
				className: "btn-quiet min-h-11 flex-none px-2 text-[11px] disabled:opacity-40",
				children: u("games.decko.buyGift", { n: y })
			}),
			[
				[1, 2],
				[2, 3],
				[3, 5]
			].map(([e, t]) => {
				let i = r(t);
				return /* @__PURE__ */ h("button", {
					type: "button",
					disabled: f.includes("chips") || d < i,
					onClick: () => c(e),
					className: "btn-quiet min-h-11 flex-none px-2 font-mono text-[11px] tabular-nums disabled:opacity-40",
					children: [
						"🪙×",
						n("chipGirl") ? e * 3 : e,
						"/$",
						i
					]
				}, e);
			})
		]
	}), /* @__PURE__ */ m("button", {
		type: "button",
		onClick: l,
		className: "btn-base min-h-11 flex-none px-4 text-sm text-white",
		style: { background: N.accent },
		children: u("games.decko.buyDone")
	})] });
}
function Dt({ pub: e, members: t, myRid: n, giftCard: r, setGiftCard: i, target: a, setTarget: s, cost: c, onConfirm: l, onCancel: u }) {
	let d = o(), f = e.players.find((e) => e.rid === n);
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ h("span", {
			className: "decko-options flex min-w-0 flex-1 items-center gap-1 overflow-x-auto overflow-y-hidden scrollbar-none",
			children: [(f?.burn ?? []).map((e) => /* @__PURE__ */ m("button", {
				type: "button",
				onClick: () => i(r === e ? null : e),
				className: `flex-none rounded ${r === e ? "ring-2 ring-ink" : ""}`,
				children: /* @__PURE__ */ m(Y, {
					id: e,
					w: 26,
					h: 36
				})
			}, e)), /* @__PURE__ */ m(bt, {
				pub: e,
				members: t,
				myRid: n,
				target: a,
				setTarget: s,
				includeFolded: !0
			})]
		}),
		/* @__PURE__ */ m("button", {
			type: "button",
			disabled: !r || !a,
			onClick: l,
			className: "btn-base min-h-11 flex-none px-3 text-xs text-white disabled:opacity-40",
			style: { background: N.accent },
			children: d("games.decko.buyGift", { n: c })
		}),
		/* @__PURE__ */ m("button", {
			type: "button",
			onClick: u,
			className: "btn-quiet min-h-11 flex-none px-2 text-sm",
			children: "✕"
		})
	] });
}
function Ot({ pub: e, nameOf: t, onClose: n }) {
	let r = o(), i = e.reveal;
	if (!i) return null;
	let a = Object.entries(i.results).sort(([, e], [, t]) => t.setRank - e.setRank);
	return /* @__PURE__ */ h("div", {
		className: "decko-overlay pointer-events-auto card mx-2 mb-2 max-h-56 overflow-y-auto p-2",
		children: [/* @__PURE__ */ h("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ m("p", {
				className: "flex-1 text-xs font-extrabold",
				children: r("games.decko.revealTitle")
			}), /* @__PURE__ */ m("button", {
				type: "button",
				"aria-label": r("games.decko.revealTitle"),
				onClick: n,
				className: "grid size-8 cursor-pointer place-items-center text-sm",
				children: "✕"
			})]
		}), /* @__PURE__ */ m("ul", {
			className: "mt-1 flex flex-col gap-1",
			children: a.map(([e, n]) => {
				let a = i.winners.includes(e);
				return /* @__PURE__ */ h("li", {
					className: `decko-reveal-row flex items-center gap-1.5 rounded-lg border-2 px-1.5 py-1 ${a ? "border-ink bg-done-soft" : "border-ink/15"}`,
					children: [
						/* @__PURE__ */ h("span", {
							className: "min-w-0 flex-none truncate text-xs font-extrabold",
							children: [a && "🏆", t(e)]
						}),
						/* @__PURE__ */ m("span", {
							className: "flex-none rounded bg-surface px-1 text-[10px] font-bold",
							children: r(se[n.setRank])
						}),
						/* @__PURE__ */ m("span", {
							className: "decko-reveal-cards flex min-w-0 flex-1 gap-0.5 overflow-x-auto scrollbar-none",
							children: n.setFaces.map((e, t) => /* @__PURE__ */ m(Y, {
								id: e.physId,
								w: 22,
								h: 30
							}, `${e.physId}-${t}`))
						}),
						n.chips > 0 && /* @__PURE__ */ h("span", {
							className: "flex-none font-mono text-[10px] font-bold tabular-nums",
							children: ["🪙+", n.chips]
						}),
						a && /* @__PURE__ */ m("span", {
							className: "flex-none font-mono text-[10px] font-extrabold tabular-nums text-done-ink",
							children: r("games.decko.revealWin", { n: i.potShare })
						})
					]
				}, e);
			})
		})]
	});
}
function kt({ card: e, onKeep: t, onReturn: n }) {
	let r = o(), i = x[e].onAcquire === "smolder1" ? 1 : x[e].onAcquire === "smolder2" ? 2 : 0;
	return /* @__PURE__ */ h("div", {
		className: "decko-overlay decko-red-jester pointer-events-auto card mx-2 mb-2 flex items-center gap-2 p-2",
		children: [
			/* @__PURE__ */ m(Y, {
				id: e,
				w: 44,
				h: 62
			}),
			/* @__PURE__ */ h("p", {
				className: "min-w-0 flex-1 text-xs font-bold",
				children: [r("games.decko.redJesterPrompt"), i > 0 && /* @__PURE__ */ m("span", {
					className: "block text-warn-ink",
					children: r("games.decko.smolderPrompt", { n: i })
				})]
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				onClick: t,
				className: "btn-base min-h-11 flex-none px-3 text-xs text-white",
				style: { background: N.accent },
				children: r("games.decko.redJesterKeep")
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				onClick: n,
				className: "btn-quiet min-h-11 flex-none px-3 text-xs",
				children: r("games.decko.redJesterReturn")
			})
		]
	});
}
//#endregion
//#region src/games/decko/bot.ts
function Q(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function $(e) {
	let t = x[e], n = 0;
	return t.onAcquire === "voucher" && (n += 6), t.onReveal === "chip1" && (n += 2), t.onReveal === "chip2" && (n += 4), t.onReveal === "credit" && (n += 3), t.onReveal === "crypto" && (n += 2), t.onReveal === "richKing" && (n += 2), t.assistAce && (n += 4), t.doubleAs && (n += 5), t.altRank !== void 0 && (n += 2), t.queen && (n += 3), t.onAcquire === "smolder1" && (n -= 2), t.onAcquire === "smolder2" && (n -= 4), t.junkFood && (n += 1), n;
}
function At(e) {
	return [...e].sort((e, t) => x[e].rank + $(e) - (x[t].rank + $(t)));
}
function jt(e) {
	let t = null, n = -Infinity;
	for (let r = 0; r < e.market.length; r += 1) {
		let i = e.market[r];
		if (!i) continue;
		let a = x[i].rank + $(i) - O[r];
		a > n && (n = a, t = r);
	}
	return t;
}
function Mt(e, t, n) {
	return me({
		hand: t.hand,
		marketSlots: e.market.filter((e) => e !== ""),
		holdem: e.wildcard === "holdem",
		battleRoyale: e.wildcard === "battleRoyale",
		solo: e.wildcard === "solo",
		burnTop: n.burn[n.burn.length - 1],
		discardTop: n.discard[n.discard.length - 1]
	});
}
var Nt = (e, t) => {
	let n = e.public, r = e.private, i = n.players.find((e) => e.rid === t.rid);
	if (!i || !r) return null;
	let a = t.difficulty === "weak", o = n.wildcard === "clownCar" ? Object.values(n.jokerTops).filter((e) => !!e) : i.jokers, s = (e) => o.includes(e), c = n.wildcard === "friedChicken";
	if (r.redJesterCard) {
		let e = x[r.redJesterCard];
		if (!(e.rank + $(r.redJesterCard) >= 12)) return { action: {
			type: "redJesterResolve",
			keep: !1
		} };
		let t = e.onAcquire === "smolder1" ? 1 : e.onAcquire === "smolder2" ? 2 : 0, n = t > 0 ? At(r.hand).slice(0, Math.min(t, Math.max(0, r.hand.length - 1))) : void 0;
		return { action: {
			type: "redJesterResolve",
			keep: !0,
			burns: n && n.length > 0 ? n : void 0
		} };
	}
	if (r.pendingSmolder) return { action: {
		type: "smolderResolve",
		cards: At(r.hand).slice(0, Math.min(r.pendingSmolder.need, Math.max(0, r.hand.length - 1)))
	} };
	if (r.pendingMulligan) {
		let e = At(r.hand.filter((e) => x[e].rank <= 9 && $(e) <= 1));
		return { action: {
			type: "mulligan",
			cards: e.length >= 3 ? e.slice(0, 3) : []
		} };
	}
	switch (n.phase) {
		case "deal": {
			if (n.turn !== t.rid || i.dealt) return null;
			let e = s("garbagePailBoy") && i.discard.length > 0 && x[i.discard[i.discard.length - 1]].rank >= 12, r = s("merlin") ? jt(n) ?? void 0 : void 0, a = n.players.filter((e) => e.rid !== t.rid), o = s("fortuneTeller") && a.length > 0 ? Q(a).rid : void 0, c = { type: "deal" };
			return r !== void 0 && (c.merlinSlot = r), e && (c.garbagePail = !0), o && (c.fortuneTellerTarget = o), { action: c };
		}
		case "stud": return n.turn !== t.rid || i.studRevealed.length > 0 ? null : { action: {
			type: "studReveal",
			cards: At(r.hand).slice(0, 3)
		} };
		case "tcg": {
			if (n.turn !== t.rid) return null;
			let e = n.players.findIndex((e) => e.rid === t.rid), r = n.players[(e + 1) % n.players.length];
			return r.burn.length === 0 ? { action: { type: "tcg" } } : { action: {
				type: "tcg",
				cardId: [...r.burn].sort((e, t) => x[t].rank + $(t) - (x[e].rank + $(e)))[0]
			} };
		}
		case "bet": {
			if (n.turn !== t.rid || i.folded) return null;
			let e = r.hand.filter((e) => x[e].junkFood);
			if (e.length > 0) return { action: {
				type: "junkFood",
				cardIds: e
			} };
			let o = Mt(n, r, i), l = Math.max(0, n.highest - i.bet), u = c && r.hand.length > 1 ? At(r.hand)[0] : void 0;
			if (n.firstBetRound && !n.burnUsed && o.setRank === 0 && r.hand.length >= 4 && !a) return { action: {
				type: "burn",
				cards: [At(r.hand)[0]]
			} };
			let d = o.setRank >= 3 || o.setRank === 2 && o.tiebreak[0] >= 11, f = o.setRank >= 1;
			if (a) {
				if (crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 10 < 2 && n.highest < n.maxBet) {
					let e = { type: "raise" };
					return u && (e.fcBurn = u), { action: e };
				}
				if (l <= (f ? 4 : 1)) {
					let e = { type: "call" };
					return u && (e.fcBurn = u), { action: e };
				}
			} else if (d && n.highest < n.maxBet) {
				let e = { type: "raise" };
				return u && (e.fcBurn = u), { action: e };
			} else if (f && l <= 3 || l === 0) {
				let e = { type: "call" };
				return u && (e.fcBurn = u), { action: e };
			}
			let p = s("sadClown") ? 2 : 1, m = n.market.map((e, t) => ({
				c: e,
				i: t,
				score: e ? x[e].rank + $(e) + O[t] : -1
			})).filter((e) => e.c).sort((e, t) => t.score - e.score).slice(0, p).map((e) => e.i);
			return { action: {
				type: "fold",
				marketSlots: m,
				discardOrder: [...r.hand, ...m.map((e) => n.market[e])]
			} };
		}
		case "buy": {
			if (n.buyQueue[0] !== t.rid) return null;
			let e = r.myMoney, a = +!!s("saleswoman"), o = -1, c = 8;
			for (let t = 0; t < n.market.length; t += 1) {
				let r = n.market[t];
				if (!r) continue;
				let i = s("cherry") && !n.buyerCherryUsed ? 0 : Math.max(0, O[t] - a);
				if (i > e) continue;
				let l = x[r].rank + $(r) - i;
				l > c && (c = l, o = t);
			}
			if (o >= 0) {
				let e = n.market[o], t = x[e].onAcquire === "smolder1" ? 1 : x[e].onAcquire === "smolder2" ? 2 : 0, i = t > 0 && r.hand.length > 0 ? At(r.hand).slice(0, t) : void 0;
				return { action: {
					type: "buyCard",
					slot: o,
					burns: i
				} };
			}
			for (let t of [
				"deal",
				"raise",
				"call",
				"burn",
				"fold",
				"buy"
			]) {
				let r = n.jokerTops[t];
				if (r && !n.buyerJokerBought && !i.jokers.some((e) => S[e].type === t) && S[r].cost <= e - 2) return { action: {
					type: "buyJoker",
					jokerType: t
				} };
			}
			if (!n.buyerSpecials.includes("chips")) {
				let t = e >= 5 - a ? 3 : e >= 3 - a ? 2 : +(e >= 2 - a);
				if (t > 0) return { action: {
					type: "buyChips",
					n: t
				} };
			}
			let l = {
				type: "buyDone",
				discardOrder: [...r.hand, ...n.buyerAcquired]
			};
			if (s("energyDrink") && n.buyerAcquired.length > 0) {
				let e = [...n.buyerAcquired].sort((e, t) => x[t].rank - x[e].rank)[0];
				l.energyToTop = [e], l.discardOrder = [...r.hand, ...n.buyerAcquired.filter((t) => t !== e)];
			}
			return { action: l };
		}
		default: return null;
	}
}, Pt = { showdown(e, t) {
	v();
	let n = e.data;
	if (!n || !Array.isArray(n.winners) || typeof n.pot != "number") return null;
	let r = n.winners.filter((e) => typeof e == "string"), i = r.length > 0 ? Math.floor(n.pot / r.length) : 0, a = n.results ?? {}, o = r.map((e, n) => {
		let r = t.anchor(`seat:${e}`);
		if (!r) return null;
		let o = a[e], s = Array.isArray(o?.tiebreak) ? o.tiebreak : [], c = Math.max(18, Math.min(36, 18 * r.w / 44));
		return /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(_, {
			at: r,
			ms: 1400,
			delay: n * 120
		}), /* @__PURE__ */ m(g, {
			at: r,
			ms: 1300,
			delay: n * 120,
			children: /* @__PURE__ */ h("span", {
				className: "flex flex-col items-center font-mono font-extrabold tabular-nums text-done-ink",
				children: [/* @__PURE__ */ h("span", {
					style: { fontSize: c },
					children: ["🪙+", i]
				}), s.length > 0 && /* @__PURE__ */ m("span", {
					style: { fontSize: c * 10 / 18 },
					children: s.slice(0, 3).map(nt).join(" ")
				})]
			})
		})] }, e);
	}), s = t.anchor("pot");
	return {
		ms: 1500,
		node: /* @__PURE__ */ h(p, { children: [o, s && /* @__PURE__ */ m(_, {
			at: s,
			ms: 900
		})] })
	};
} };
//#endregion
//#region src/games/decko/game-over.tsx
function Ft(e) {
	return /* @__PURE__ */ m("div", {
		className: "decko-over",
		children: /* @__PURE__ */ m(y, {
			hintCount: e.hintCount,
			result: e.result,
			members: e.members,
			myRid: e.myRid,
			accent: N.accent,
			onPlayAgain: e.onPlayAgain,
			onBackToLobby: e.onBackToLobby
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/decko/entry.tsx
var It = {
	definition: J,
	View: ct,
	bot: Nt,
	fx: Pt,
	OverView: Ft,
	locales: {
		zh: {
			name: "DECKO",
			desc: "扑克×卡组构筑:下注抢底池,买牌改牌组,王牌各显神通",
			rules: "目标:十二轮结束后,持有筹码最多的玩家获胜。\n· 若有玩家率先达到 60 枚筹码(五人局为 70 枚),游戏立即结束。\n准备:\n· 每名玩家获得 20 枚筹码、十四张相同的起始牌,以及两次借贷额度。\n· 每次借贷立即获得 10 枚筹码,终局结算时每次扣除 5 枚。\n流程:每一轮按顺序进行以下阶段\n· 起始注:奖池放入本轮的最小注,担任盲位的玩家同时下最小注。\n· 发牌:从自己的抽牌堆抽取五张牌;抽牌堆抽空时,将弃牌堆洗回作为新的抽牌堆。\n· 下注:从盲位左手边的玩家开始轮流行动,选择加注、跟注或弃牌。\n· 每轮首次行动前,可以烧毁一张手牌并补抽一张。\n· 摊牌:未弃牌的玩家必须用手牌组成所能达到的最高牌型,牌型最大者赢走全部下注与奖池。\n· 购买:本轮未获胜也未弃牌的玩家按牌型获得 $0 至 $9 的资金。\n· 资金可用于购买市场牌、特殊行动与王牌。\n牌型:从大到小依次为皇家同花顺、同花顺、四条、同花、顺子、葫芦、三条、两对、一对、高牌。\n· 葫芦在同花和顺子之下;比较牌型时不使用踢脚,完全相同的牌型平分底池。\n· 弃牌的玩家可以免费拿取一张市场牌;手牌上限为七张,牌组下限为七张。\n特殊规则:\n· 第四轮和第八轮是万能牌回合,当轮启用一张影响全场的规则变体。\n· 市场牌和王牌各带有特殊能力;王牌分为六种,只能在对应的行动时机使用。\n终局结算:先偿还全部借贷,之后筹码最多的玩家获胜;筹码相同时抽牌比较大小。",
			phaseDeal: "发牌",
			phaseStud: "明置",
			phaseTcg: "拾荒",
			phaseBet: "下注",
			phaseBuy: "购买",
			phaseDone: "结束",
			round: "第 {{n}}/12 轮",
			hand0: "高牌",
			hand1: "一对",
			hand2: "两对",
			hand3: "三条",
			hand4: "葫芦",
			hand5: "顺子",
			hand6: "同花",
			hand7: "四条",
			hand8: "同花顺",
			hand9: "皇家同花顺",
			effectAssistAce: "辅助 A:摊牌时可使手上一张数字牌的点数加一或减一",
			effectCrypto: "加密币:摊牌时每持有一张加密币,获得 1 枚筹码",
			effectVoucher: "礼券:获得这张牌时得到 3 枚筹码",
			effectJunkFood: "垃圾食品:下注阶段轮到自己时,可以弃掉这张牌并抽一张牌",
			effectChip1: "筹码牌:摊牌时获得 1 枚筹码",
			effectChip2: "筹码牌:摊牌时获得 2 枚筹码",
			effectCredit: "信用卡:摊牌时,本轮购买阶段额外获得 $3",
			effectSmolder1: "阴燃:获得这张牌时可从手牌烧毁至多一张牌",
			effectSmolder2: "阴燃 ×2:获得这张牌时可从手牌烧毁至多两张牌",
			effectRichKing: "富豪 K:摊牌时手上每有一张同花色的牌,获得 1 枚筹码",
			effectDouble: "双头牌:摊牌时算作两张牌",
			effectDissolving: "溶解牌:摊牌时从两个点数中任选其一",
			effectJovial: "欢乐 J:可当作 J 或牌面所示的副点数",
			effectPyro: "纵火 Q:摊牌时可当作自己烧牌堆顶的那张牌",
			effectDumpster: "拾荒 Q:摊牌时可当作自己弃牌堆顶的那张牌",
			effectShopping: "购物 Q:摊牌时可当作市场任意一张明牌",
			effectBridge: "桥伴 Q:摊牌时可复制手上的另一张 ♦ 牌",
			jtypeDeal: "发牌",
			jtypeRaise: "加注",
			jtypeCall: "跟注",
			jtypeBurn: "烧牌",
			jtypeFold: "弃牌",
			jtypeBuy: "购买",
			jokerFortuneTeller: "算命先生",
			jokerFortuneTellerD: "发牌阶段的最后,查看另一名玩家的手牌",
			jokerMulligan: "重抽",
			jokerMulliganD: "发牌阶段:恰好弃掉三张手牌,然后抽三张牌",
			jokerHobo: "流浪汉",
			jokerHoboD: "发牌阶段若洗混了弃牌堆,获得 3 枚筹码",
			jokerMagicHat: "魔术帽",
			jokerMagicHatD: "发牌阶段改为抽六张牌",
			jokerBabyJoker: "小王牌",
			jokerBabyJokerD: "发牌后弃掉这张王牌,免费拿取任意一堆的王牌顶牌",
			jokerMerlin: "梅林",
			jokerMerlinD: "发牌时的第一张牌可以从市场明牌中选择",
			jokerGarbagePailBoy: "垃圾桶小子",
			jokerGarbagePailBoyD: "发牌时的最后一张牌从自己的弃牌堆顶抽取",
			jokerRedJester: "红小丑",
			jokerRedJesterD: "加注后:查看市场牌堆的顶牌,选择入手或放回",
			jokerMrJackpot: "头奖先生",
			jokerMrJackpotD: "加注后:将 4 枚筹码放到这张王牌上;本轮获胜则全部收回,落败或弃牌则归还供给",
			jokerSewerClown: "下水道小丑",
			jokerSewerClownD: "加注后:将一张手牌与自己弃牌堆的顶牌交换",
			jokerWhiteClown: "白面小丑",
			jokerWhiteClownD: "加注后:抽一张牌(手牌已有七张时不可使用)",
			jokerWitch: "女巫",
			jokerWitchD: "加注后:从另一名玩家的注区偷取 2 枚筹码,放入自己的注区",
			jokerTableTalker: "话痨",
			jokerTableTalkerD: "加注后:将一张手牌永久送给另一名玩家",
			jokerVampire: "吸血鬼",
			jokerVampireD: "跟注后:每有一名注码与你相同的玩家,获得 1 枚筹码",
			jokerCoolCat: "酷猫",
			jokerCoolCatD: "跟注后:抽一张牌(手牌已有七张时不可使用)",
			jokerFishbait: "鱼饵",
			jokerFishbaitD: "跟注后:弃掉全部手牌,然后抽取等量的牌",
			jokerMonochroma: "单色魔",
			jokerMonochromaD: "跟注后:从市场明牌中选一张放入自己的弃牌堆",
			jokerBlackKnight: "黑骑士",
			jokerBlackKnightD: "跟注后:弃掉一张手牌,获得 3 枚筹码",
			jokerKingmaker: "造王者",
			jokerKingmakerD: "跟注后:其他未弃牌的玩家各向奖池放入 1 枚筹码",
			jokerDevil: "恶魔",
			jokerDevilD: "烧牌后改为抽两张牌",
			jokerMarshmallow: "棉花糖",
			jokerMarshmallowD: "烧牌并补抽后,可以从自己的烧牌堆中任选一张收回手中",
			jokerBurningMan: "火人",
			jokerBurningManD: "烧牌后改为从自己的弃牌堆顶补抽",
			jokerHarlequin: "丑角",
			jokerHarlequinD: "被烧毁的牌改为面朝下放到另一名玩家的抽牌堆顶",
			jokerDumpsterFire: "垃圾火",
			jokerDumpsterFireD: "改为烧毁弃牌堆的顶牌(手牌数量不减少)",
			jokerMinmaxer: "极客",
			jokerMinmaxerD: "烧牌时可以额外多烧一张,但仍只补抽一张",
			jokerSadClown: "伤心小丑",
			jokerSadClownD: "弃牌时可以从市场拿取至多两张牌",
			jokerTaxman: "税务官",
			jokerTaxmanD: "弃牌时:从每名筹码比你多的玩家处偷取 2 枚筹码",
			jokerGun: "枪",
			jokerGunD: "弃牌时:从另一名玩家处偷取 2 枚筹码,并烧毁一张手牌",
			jokerPatchface: "补丁脸",
			jokerPatchfaceD: "弃牌时:猜测本轮的获胜者,猜中获得 7 枚筹码",
			jokerRobin: "罗宾",
			jokerRobinD: "弃牌时:从筹码最多的玩家处偷取 4 枚筹码",
			jokerAnalysisParalysis: "分析瘫痪",
			jokerAnalysisParalysisD: "弃牌时:保留两张手牌,带到下一轮",
			jokerCherry: "樱桃",
			jokerCherryD: "购买阶段:获得 2 枚筹码;市场牌全部免费,但只能购买一张",
			jokerSaleswoman: "女售货员",
			jokerSaleswomanD: "购买阶段:所有购买价格减少 $1(王牌的筹码价格不变)",
			jokerChipGirl: "筹码妹",
			jokerChipGirlD: "购买阶段:购买筹码时三倍获得",
			jokerPizzaTime: "披萨时间",
			jokerPizzaTimeD: "购买阶段:赠牌与烧牌行动不收取费用",
			jokerEnergyDrink: "能量饮料",
			jokerEnergyDrinkD: "购买阶段:购买的牌可以放到抽牌堆顶",
			jokerToilet: "马桶",
			jokerToiletD: "购买阶段:刷新市场不收取费用",
			wcHoldem: "德州局",
			wcHoldemD: "牌型必须包含三张市场牌,手牌至多两张计入牌型",
			wcClownCar: "小丑车",
			wcClownCarD: "所有玩家改用桌面六堆王牌的顶牌,自己持有的王牌失效",
			wcLowball: "低位局",
			wcLowballD: "牌型最低者获胜(仍须组成自己最高的牌型;牌型的资金价值不变)",
			wcStud: "明牌局",
			wcStudD: "发牌后每名玩家选择三张手牌明置;被换掉的牌在补抽后也须明置",
			wcTcg: "集换局",
			wcTcgD: "发牌后按顺序从左手边玩家的烧牌堆中任选一张入手",
			wcDeckorama: "七张局",
			wcDeckoramaD: "发牌时改为抽七张牌",
			wcFriedChicken: "炸鸡",
			wcFriedChickenD: "加注或跟注后必须先烧毁一张手牌,然后才能使用王牌",
			wcInferno: "炼狱",
			wcInfernoD: "从自己的烧牌堆洗混后抽取手牌;不足五张时手牌相应减少",
			wcPurge: "大清洗",
			wcPurgeD: "与其他玩家手牌数字重复的数字牌不可计入牌型",
			wcBattleRoyale: "大逃杀",
			wcBattleRoyaleD: "人头牌(J、Q、K、A)摊牌时可当作任意牌,但失去自身效果",
			wcLowSum: "最小和",
			wcLowSumD: "手上数字牌点数之和最小者获胜(牌型仍照常用于获得资金)",
			wcSolo: "单挑",
			wcSoloD: "只比较单张最大的牌,双头牌不能组成对子",
			wcProTable: "职业桌",
			wcProTableD: "起始牌不可计入牌型(其效果仍然生效)",
			wcPenultimo: "老二局",
			wcPenultimoD: "牌型第二高者获胜",
			pot: "奖池 {{n}}",
			highest: "当前最高注 {{n}}",
			betRange: "本轮下注 {{min}}-{{max}}",
			raise: "加注到 {{n}}",
			call: "跟注 {{n}}",
			callFree: "跟注 0",
			fold: "弃牌",
			burn: "烧牌",
			burnDone: "已烧牌",
			junkFood: "弃掉垃圾食品,抽 {{n}} 张",
			dealDone: "完成发牌",
			studPick: "选 3 张明置",
			tcgPick: "从左手玩家烧牌堆拿 1 张(可跳过)",
			tcgSkip: "跳过",
			takeMarket: "拿取市场牌(至多 {{n}} 张)",
			confirmFold: "确认弃牌",
			discardHint: "点选手牌调整弃牌堆顺序(末位在顶)",
			buyTitle: "购买阶段:剩余 ${{n}}",
			buyFlush: "刷新市场 ${{n}}",
			buyBurn: "烧 1 张 ${{n}}",
			buyGift: "赠牌 ${{n}}",
			buyChips: "买 {{n}} 筹码 ${{cost}}",
			buyJoker: "买王牌",
			buyDone: "结束购买",
			free: "免费",
			waitingDeal: "等待其他玩家完成发牌…",
			waitingBet: "等待 {{name}} 行动…",
			waitingBuy: "等待 {{name}} 购买…",
			yourTurnBet: "轮到你:加注、跟注或弃牌",
			yourTurnDeal: "轮到你发牌:可使用发牌王牌",
			yourTurnBuy: "轮到你购买",
			youWon: "你赢下了底池!",
			revealTitle: "摊牌结果",
			revealWin: "赢下 {{n}} 筹码",
			redJesterPrompt: "市场牌堆顶是:入手还是放回?",
			redJesterKeep: "入手",
			redJesterReturn: "放回",
			smolderPrompt: "阴燃:从手牌选至多 {{n}} 张烧掉",
			loansUsed: "借贷 {{n}}/2",
			blind: "盲位",
			folded: "已弃牌",
			winnerMark: "赢家",
			peekTitle: "偷看 {{name}} 的手牌",
			selectOne: "请选择",
			market: "市场",
			roundTrack: "回合轨",
			housePot: "公共奖池",
			jokerPiles: "王牌牌堆",
			marketSold: "售空",
			marketEmpty: "待补牌",
			jokerOwned: "已持有",
			jokerNoChips: "筹码不足",
			jokerPurchased: "本轮已买",
			selectedMarket: "已选 {{card}} · 价格 ${{price}}",
			marketHelpTitle: "市场规则",
			marketHelpPrice: "价格从左到右依次为 $4、$3、$2、$1、$0",
			marketCurrentPrices: "当前价格 ${{prices}}",
			marketHelpBuy: "购买阶段:本轮未获胜也未弃牌的玩家,用牌型折算的资金在此买牌",
			marketHelpFold: "弃牌补偿:弃牌时可免费拿取一张市场牌",
			marketHelpRefill: "补位:牌被拿走后其余牌向右滑动,新牌补到最左;第五轮与第九轮刷新市场",
			pileDraw: "抽牌堆",
			pileDiscard: "弃牌堆",
			pileBurn: "烧牌堆",
			pileEmpty: "(空)",
			funds: "资金 ${{n}}",
			previewBest: "当前最佳",
			buyCardAt: "购买 ${{n}}",
			effectNone: "无特殊效果",
			confirmBtn: "确认",
			acquiredTitle: "本轮已购",
			acquiredEmpty: "还没买牌——点上方市场挑一张",
			logRound: "—— 第 {{n}} 轮 ——",
			logWildcard: "万能牌回合:{{w}}",
			logAnte: "全员下底注 {{n}}",
			logRefresh: "市场与王牌堆刷新",
			logDeal: "{{rid}} 完成发牌",
			logBurn: "{{rid}} 烧了 {{n}} 张牌",
			logJunkFood: "{{rid}} 弃掉垃圾食品,抽 {{n}} 张",
			logRaise: "{{rid}} 加注到 {{n}}",
			logCall: "{{rid}} 跟注 {{n}}",
			logFold: "{{rid}} 弃牌",
			logShowdown: "{{w}} 赢下底池 {{n}}",
			logLastStanding: "{{rid}} 独存,赢下 {{n}}",
			logAllFold: "全员弃牌,奖池归还",
			logBuyCard: "{{rid}} 买了 {{c}}(${{n}})",
			logBuySpecial: "{{rid}} 购买了{{k}}",
			logBuyChips: "{{rid}} 买了 {{n}} 筹码",
			logBuyJoker: "{{rid}} 买了王牌 {{j}}",
			logBabyJoker: "{{rid}} 用小王牌换了 {{j}}",
			logGameOver: "游戏结束,{{rid}} 获胜",
			specialFlush: "刷新市场",
			specialBurn: "烧牌",
			specialGift: "赠牌",
			specialChips: "买筹码",
			errBadPhase: "现在不能这么做",
			errNotYourTurn: "还没轮到你",
			errPending: "先处理完当前选择",
			errAlreadyActed: "你已经行动过了",
			errNoJoker: "你没有这张王牌",
			errInvalidCard: "无效的选择",
			errInvalidTarget: "无效的目标",
			errEmptyDiscard: "弃牌堆是空的",
			errEmptyPile: "这堆王牌已空",
			errHaveType: "你已有同类王牌",
			errBadBurns: "烧牌数量不对",
			errDeckMin: "牌组不能少于 7 张",
			errHandLimit: "手牌不能超过 7 张",
			errBurnUsed: "本轮已烧过牌",
			errMaxBet: "已达本轮下注上限",
			errCantAfford: "筹码或资金不够",
			errFcBurn: "炸鸡规则:须先烧 1 张手牌",
			errCherryLimit: "樱桃规则:只能买 1 张牌",
			errAlreadyUsed: "本阶段已用过"
		},
		en: {
			name: "DECKO",
			desc: "Poker hands meet deck-building: bet, buy, and bend the rules with jokers",
			rules: "Goal: after 12 rounds, the player with the most chips wins.\n· If any player reaches 60 chips (70 in a 5-player game), the game ends immediately.\nSetup:\n· Each player receives 20 chips, an identical 14-card starting deck, and two loan markers.\n· Each loan grants 10 chips immediately and costs 5 chips at the end of the game.\nPlay: each round proceeds through the following phases in order\n· Ante: the house pot receives the minimum bet, and the blind player bets the same amount.\n· Deal: draw five cards from your own deck; when it runs out, shuffle your discard pile to form a new deck.\n· Betting: starting with the player to the left of the blind, take turns raising, calling, or folding.\n· Before your first action each round, you may burn one card from your hand to draw one.\n· Showdown: players who have not folded must form the highest set their hand allows; the highest set wins all bets and the pot.\n· Buy: players who neither won nor folded receive $0 to $9 according to their set rank.\n· The money can be spent on market cards, special actions, and jokers.\nSets: from strongest to weakest — royal flush, straight flush, four of a kind, flush, straight, full house, three of a kind, two pair, one pair, high card.\n· A full house ranks below a flush and a straight; there are no kickers, and identical sets split the pot.\n· A player who folds takes one market card for free; the hand limit is seven cards and the deck minimum is seven.\nSpecial rules:\n· Rounds 4 and 8 are wildcard rounds, each activating a table-wide rules twist.\n· Market cards and jokers carry their own abilities; jokers come in six types, each usable only at its matching timing.\nFinal scoring: repay all loans first, then the player with the most chips wins; ties are broken by drawing cards.",
			phaseDeal: "Deal",
			phaseStud: "Reveal",
			phaseTcg: "Scavenge",
			phaseBet: "Betting",
			phaseBuy: "Buy",
			phaseDone: "Done",
			round: "Round {{n}}/12",
			hand0: "High card",
			hand1: "Pair",
			hand2: "Two pair",
			hand3: "Trips",
			hand4: "Full house",
			hand5: "Straight",
			hand6: "Flush",
			hand7: "Quads",
			hand8: "Straight flush",
			hand9: "Royal flush",
			effectAssistAce: "Assisting Ace: at showdown, raise or lower the rank of one numbered card in your hand by one",
			effectCrypto: "Crypto: at showdown, gain 1 chip for each Crypto card in your hand",
			effectVoucher: "Voucher: gain 3 chips when you acquire this card",
			effectJunkFood: "Junk Food: on your betting turn, you may discard this card to draw one",
			effectChip1: "Chip card: gain 1 chip at showdown",
			effectChip2: "Chip card: gain 2 chips at showdown",
			effectCredit: "Credit card: at showdown, gain an extra $3 for the buy phase this round",
			effectSmolder1: "Smoldering: when you acquire this card, you may burn up to 1 card from your hand",
			effectSmolder2: "Smoldering ×2: when you acquire this card, you may burn up to 2 cards from your hand",
			effectRichKing: "Rich King: at showdown, gain 1 chip for each card of the same suit in your hand",
			effectDouble: "Double card: counts as two cards at showdown",
			effectDissolving: "Dissolving: at showdown, choose either of its two ranks",
			effectJovial: "Jovial Jack: may count as a J or as the shown number",
			effectPyro: "Pyromaniac Queen: at showdown, may count as the top card of your burn pile",
			effectDumpster: "Dumpster Diving Queen: at showdown, may count as the top card of your discard pile",
			effectShopping: "Shopping Queen: at showdown, may count as any face-up market card",
			effectBridge: "Bridge Partner Queen: at showdown, may copy another ♦ card in your hand",
			jtypeDeal: "Deal",
			jtypeRaise: "Raise",
			jtypeCall: "Call",
			jtypeBurn: "Burn",
			jtypeFold: "Fold",
			jtypeBuy: "Buy",
			jokerFortuneTeller: "Fortune Teller",
			jokerFortuneTellerD: "At the end of the deal phase, look at another player's hand",
			jokerMulligan: "Mulligan",
			jokerMulliganD: "Deal phase: discard exactly 3 cards from your hand, then draw 3",
			jokerHobo: "Hobo",
			jokerHoboD: "Deal phase: if you reshuffle your discard pile, gain 3 chips",
			jokerMagicHat: "Magic Hat",
			jokerMagicHatD: "Draw 6 cards in the deal phase instead",
			jokerBabyJoker: "Baby Joker",
			jokerBabyJokerD: "After drawing, discard this joker to take the top joker of any pile for free",
			jokerMerlin: "Merlin",
			jokerMerlinD: "The first card you draw may be chosen from the face-up market",
			jokerGarbagePailBoy: "Garbage Pail Boy",
			jokerGarbagePailBoyD: "Draw your last card from the top of your discard pile",
			jokerRedJester: "Red Jester",
			jokerRedJesterD: "After raising: look at the top card of the market deck, then keep it or return it",
			jokerMrJackpot: "Mr. Jackpot",
			jokerMrJackpotD: "After raising: place 4 chips on this joker; win the round to collect them all, lose or fold and they return to the supply",
			jokerSewerClown: "Sewer Clown",
			jokerSewerClownD: "After raising: swap one card from your hand with the top card of your discard pile",
			jokerWhiteClown: "White Clown",
			jokerWhiteClownD: "After raising: draw 1 card (unusable while holding 7)",
			jokerWitch: "The Witch",
			jokerWitchD: "After raising: steal 2 chips from another player's bet into your own",
			jokerTableTalker: "Table Talker",
			jokerTableTalkerD: "After raising: give one card from your hand to another player permanently",
			jokerVampire: "Vampire",
			jokerVampireD: "After calling: gain 1 chip for each player whose bet equals yours",
			jokerCoolCat: "Cool Cat",
			jokerCoolCatD: "After calling: draw 1 card (unusable while holding 7)",
			jokerFishbait: "Fishbait",
			jokerFishbaitD: "After calling: discard your whole hand, then draw that many cards",
			jokerMonochroma: "Monochroma",
			jokerMonochromaD: "After calling: choose a face-up market card and put it on your discard pile",
			jokerBlackKnight: "Black Knight",
			jokerBlackKnightD: "After calling: discard 1 card from your hand to gain 3 chips",
			jokerKingmaker: "Kingmaker",
			jokerKingmakerD: "After calling: every other player who has not folded adds 1 chip to the pot",
			jokerDevil: "The Devil",
			jokerDevilD: "Draw 2 cards after burning instead",
			jokerMarshmallow: "Marshmallow",
			jokerMarshmallowD: "After burning and drawing, you may take any 1 card from your burn pile back into your hand",
			jokerBurningMan: "Burning Man",
			jokerBurningManD: "After burning, draw from the top of your discard pile instead",
			jokerHarlequin: "Harlequin",
			jokerHarlequinD: "The burned card goes face-down onto another player's draw pile instead",
			jokerDumpsterFire: "Dumpster Fire",
			jokerDumpsterFireD: "Burn the top card of your discard pile instead (your hand size is unchanged)",
			jokerMinmaxer: "Minmaxer",
			jokerMinmaxerD: "You may burn 1 extra card (still draw only 1)",
			jokerSadClown: "Sad Clown",
			jokerSadClownD: "When folding: you may take up to 2 market cards",
			jokerTaxman: "Taxman",
			jokerTaxmanD: "When folding: steal 2 chips from each player who has more chips than you",
			jokerGun: "Gun",
			jokerGunD: "When folding: steal 2 chips from another player and burn 1 card from your hand",
			jokerPatchface: "Patchface",
			jokerPatchfaceD: "When folding: guess who wins the round; gain 7 chips if correct",
			jokerRobin: "Robin",
			jokerRobinD: "When folding: steal 4 chips from the player with the most chips",
			jokerAnalysisParalysis: "Analysis Paralysis",
			jokerAnalysisParalysisD: "When folding: keep 2 cards from your hand for the next round",
			jokerCherry: "Cherry",
			jokerCherryD: "Buy phase: gain 2 chips; market cards are free, but you may buy only 1",
			jokerSaleswoman: "Saleswoman",
			jokerSaleswomanD: "Buy phase: all purchases cost $1 less (joker chip prices are unchanged)",
			jokerChipGirl: "Chip Girl",
			jokerChipGirlD: "Buy phase: chip purchases yield triple",
			jokerPizzaTime: "Pizza Time",
			jokerPizzaTimeD: "Buy phase: gift and burn actions are free",
			jokerEnergyDrink: "Energy Drink",
			jokerEnergyDrinkD: "Buy phase: purchased cards may be placed on top of your draw pile",
			jokerToilet: "Toilet",
			jokerToiletD: "Buy phase: flushing the market is free",
			wcHoldem: "Hold'em",
			wcHoldemD: "Sets must include 3 market cards; at most 2 cards from your hand may count",
			wcClownCar: "Clown Car",
			wcClownCarD: "Everyone uses the top jokers of the six table piles; your own jokers have no effect",
			wcLowball: "Lowball",
			wcLowballD: "The lowest set wins (you must still form your highest set; $ values are unchanged)",
			wcStud: "Stud",
			wcStudD: "After dealing, each player reveals 3 cards from their hand; replacements drawn are revealed as well",
			wcTcg: "TCG",
			wcTcgD: "After dealing, in turn order, take 1 card of your choice from the burn pile of the player to your left",
			wcDeckorama: "Deckorama",
			wcDeckoramaD: "Draw 7 cards when dealing",
			wcFriedChicken: "Fried Chicken",
			wcFriedChickenD: "After calling or raising, you must burn 1 card from your hand before using jokers",
			wcInferno: "Inferno",
			wcInfernoD: "Draw your hand from your shuffled burn pile; with fewer than 5 cards your hand is smaller",
			wcPurge: "Purge",
			wcPurgeD: "Numbered cards whose rank appears in another player's hand cannot count toward sets",
			wcBattleRoyale: "Battle Royale",
			wcBattleRoyaleD: "Royal cards (J, Q, K, A) may count as any card at showdown but lose their own effects",
			wcLowSum: "Low Sum",
			wcLowSumD: "The player with the lowest sum of numbered cards in hand wins (sets still pay $ as normal)",
			wcSolo: "Solo",
			wcSoloD: "Only the single highest card is compared; double cards cannot form a pair",
			wcProTable: "Pro Table",
			wcProTableD: "Starting cards cannot count toward sets (their effects still apply)",
			wcPenultimo: "Penultimo",
			wcPenultimoD: "The second-highest set wins",
			pot: "Pot {{n}}",
			highest: "Highest bet {{n}}",
			betRange: "Bets {{min}}-{{max}} this round",
			raise: "Raise to {{n}}",
			call: "Call {{n}}",
			callFree: "Call $0",
			fold: "Fold",
			burn: "Burn",
			burnDone: "Burned",
			junkFood: "Discard Junk Food, draw {{n}} cards",
			dealDone: "Done dealing",
			studPick: "Reveal 3 cards",
			tcgPick: "Take 1 card from the burn pile on your left (or skip)",
			tcgSkip: "Skip",
			takeMarket: "Take market cards (up to {{n}})",
			confirmFold: "Confirm fold",
			discardHint: "Tap cards to order the discard pile (last = top)",
			buyTitle: "Buy phase: ${{n}} left",
			buyFlush: "Flush market ${{n}}",
			buyBurn: "Burn 1 ${{n}}",
			buyGift: "Gift ${{n}}",
			buyChips: "Buy {{n}} chips ${{cost}}",
			buyJoker: "Buy joker",
			buyDone: "Done buying",
			free: "Free",
			waitingDeal: "Waiting for others to finish dealing…",
			waitingBet: "Waiting for {{name}}…",
			waitingBuy: "Waiting for {{name}} to buy…",
			yourTurnBet: "Your turn: raise, call, or fold",
			yourTurnDeal: "Your deal: you may use DEAL jokers",
			yourTurnBuy: "Your turn to buy",
			youWon: "You won the pot!",
			revealTitle: "Showdown",
			revealWin: "Won {{n}} chips",
			redJesterPrompt: "Top of the market deck: keep or return?",
			redJesterKeep: "Keep",
			redJesterReturn: "Return",
			smolderPrompt: "Smoldering: burn up to {{n}} card(s) from hand",
			loansUsed: "Loans {{n}}/2",
			blind: "Blind",
			folded: "Folded",
			winnerMark: "Winner",
			peekTitle: "Peeking at {{name}}'s hand",
			selectOne: "Choose one",
			market: "Market",
			roundTrack: "Round track",
			housePot: "House pot",
			jokerPiles: "Joker piles",
			marketSold: "Sold out",
			marketEmpty: "No cards",
			jokerOwned: "Owned",
			jokerNoChips: "No chips",
			jokerPurchased: "Bought this round",
			selectedMarket: "Selected {{card}} · Price ${{price}}",
			marketHelpTitle: "Market rules",
			marketHelpPrice: "Prices from left to right: $4, $3, $2, $1, $0",
			marketCurrentPrices: "Current prices ${{prices}}",
			marketHelpBuy: "Buy phase: players who neither won nor folded spend their set money here",
			marketHelpFold: "Fold bonus: folding lets you take one market card for free",
			marketHelpRefill: "Refill: cards slide right and new cards enter on the left; the market refreshes on rounds 5 and 9",
			pileDraw: "Draw pile",
			pileDiscard: "Discard pile",
			pileBurn: "Burn pile",
			pileEmpty: "(empty)",
			funds: "Funds ${{n}}",
			previewBest: "Best now",
			buyCardAt: "Buy for ${{n}}",
			effectNone: "No special effect",
			confirmBtn: "Confirm",
			acquiredTitle: "Bought this round",
			acquiredEmpty: "Nothing yet — tap the market above",
			logRound: "—— Round {{n}} ——",
			logWildcard: "Wildcard round: {{w}}",
			logAnte: "Everyone antes {{n}}",
			logRefresh: "Market and joker piles refreshed",
			logDeal: "{{rid}} finished dealing",
			logBurn: "{{rid}} burned {{n}} card(s)",
			logJunkFood: "{{rid}} discarded Junk Food and drew {{n}} cards",
			logRaise: "{{rid}} raised to {{n}}",
			logCall: "{{rid}} called {{n}}",
			logFold: "{{rid}} folded",
			logShowdown: "{{w}} won the pot of {{n}}",
			logLastStanding: "{{rid}} stood last and won {{n}}",
			logAllFold: "Everyone folded; pot returned",
			logBuyCard: "{{rid}} bought {{c}} (${{n}})",
			logBuySpecial: "{{rid}} bought: {{k}}",
			logBuyChips: "{{rid}} bought {{n}} chip(s)",
			logBuyJoker: "{{rid}} bought joker {{j}}",
			logBabyJoker: "{{rid}} traded Baby Joker for {{j}}",
			logGameOver: "Game over — {{rid}} wins",
			specialFlush: "flush market",
			specialBurn: "burn",
			specialGift: "gift",
			specialChips: "buy chips",
			errBadPhase: "Not right now",
			errNotYourTurn: "Not your turn",
			errPending: "Finish the pending choice first",
			errAlreadyActed: "You already acted",
			errNoJoker: "You don't have that joker",
			errInvalidCard: "Invalid choice",
			errInvalidTarget: "Invalid target",
			errEmptyDiscard: "Discard pile is empty",
			errEmptyPile: "That joker pile is empty",
			errHaveType: "You already own that joker type",
			errBadBurns: "Wrong number of burns",
			errDeckMin: "Deck cannot drop below 7 cards",
			errHandLimit: "Hand cannot exceed 7 cards",
			errBurnUsed: "Already burned this round",
			errMaxBet: "Bet cap reached this round",
			errCantAfford: "Not enough chips or money",
			errFcBurn: "Fried Chicken: burn 1 hand card first",
			errCherryLimit: "Cherry: only 1 card purchase",
			errAlreadyUsed: "Already used this phase"
		}
	}
};
//#endregion
export { It as default };
