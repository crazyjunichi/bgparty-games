import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { seatName as d } from "@bgparty/sdk/ui/player-strip";
import { IconBot as f, IconCheck as p, IconClose as m, IconEye as h } from "@bgparty/sdk/icons";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { AVATARS as y } from "@bgparty/sdk/avatars";
import { DeltaNumber as b } from "@bgparty/sdk/fx/delta-number";
import { PLAYER_COLORS as x } from "@bgparty/sdk/player-colors";
import { botAvatarOf as S } from "@bgparty/sdk/lobby";
import { botPersonality as C } from "@bgparty/sdk/bot-personality";
import { Floater as w, FlySprite as T, PulseBox as E } from "@bgparty/sdk/fx/primitives";
import { Confetti as D } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as O, OptionSection as k } from "@bgparty/sdk/ui/game-options";
//#region src/games/loveletter/cards.ts
var A = {
	spy: {
		value: {
			classic: -1,
			modern: 0
		},
		count: {
			classic: 0,
			modern: 2
		},
		needsTarget: !1,
		emoji: "🕵️"
	},
	guard: {
		value: {
			classic: 1,
			modern: 1
		},
		count: {
			classic: 5,
			modern: 6
		},
		needsTarget: !0,
		emoji: "💂"
	},
	priest: {
		value: {
			classic: 2,
			modern: 2
		},
		count: {
			classic: 2,
			modern: 2
		},
		needsTarget: !0,
		emoji: "🕯️"
	},
	baron: {
		value: {
			classic: 3,
			modern: 3
		},
		count: {
			classic: 2,
			modern: 2
		},
		needsTarget: !0,
		emoji: "⚔️"
	},
	handmaid: {
		value: {
			classic: 4,
			modern: 4
		},
		count: {
			classic: 2,
			modern: 2
		},
		needsTarget: !1,
		emoji: "🌹"
	},
	prince: {
		value: {
			classic: 5,
			modern: 5
		},
		count: {
			classic: 2,
			modern: 2
		},
		needsTarget: !0,
		emoji: "🤴"
	},
	chancellor: {
		value: {
			classic: -1,
			modern: 6
		},
		count: {
			classic: 0,
			modern: 2
		},
		needsTarget: !1,
		emoji: "📜"
	},
	king: {
		value: {
			classic: 6,
			modern: 7
		},
		count: {
			classic: 1,
			modern: 1
		},
		needsTarget: !0,
		emoji: "👑"
	},
	countess: {
		value: {
			classic: 7,
			modern: 8
		},
		count: {
			classic: 1,
			modern: 1
		},
		needsTarget: !1,
		emoji: "💎"
	},
	princess: {
		value: {
			classic: 8,
			modern: 9
		},
		count: {
			classic: 1,
			modern: 1
		},
		needsTarget: !1,
		emoji: "👸"
	}
}, ee = [
	"spy",
	"guard",
	"priest",
	"baron",
	"handmaid",
	"prince",
	"chancellor",
	"king",
	"countess",
	"princess"
], j = (e, t) => A[e].value[t];
function M(e) {
	return ee.filter((t) => A[t].count[e] > 0);
}
function N(e) {
	return M(e).flatMap((t) => Array.from({ length: A[t].count[e] }, () => t));
}
function P(e, t) {
	return e === "classic" ? t <= 2 ? 7 : t === 3 ? 5 : 4 : t <= 2 ? 6 : t === 3 ? 5 : t === 4 ? 4 : 3;
}
var F = (e) => e === "classic" ? 4 : 6, I = {
	spy: "games.loveletter.role.spy",
	guard: "games.loveletter.role.guard",
	priest: "games.loveletter.role.priest",
	baron: "games.loveletter.role.baron",
	handmaid: "games.loveletter.role.handmaid",
	prince: "games.loveletter.role.prince",
	chancellor: "games.loveletter.role.chancellor",
	king: "games.loveletter.role.king",
	countess: "games.loveletter.role.countess",
	princess: "games.loveletter.role.princess"
}, te = {
	spy: "games.loveletter.roleDesc.spy",
	guard: "games.loveletter.roleDesc.guard",
	priest: "games.loveletter.roleDesc.priest",
	baron: "games.loveletter.roleDesc.baron",
	handmaid: "games.loveletter.roleDesc.handmaid",
	prince: "games.loveletter.roleDesc.prince",
	chancellor: "games.loveletter.roleDesc.chancellor",
	king: "games.loveletter.roleDesc.king",
	countess: "games.loveletter.roleDesc.countess",
	princess: "games.loveletter.roleDesc.princess"
}, L = {
	id: "loveletter",
	tier: "released",
	mechanics: ["hand-management", "deduction"],
	interactionTags: [],
	nameKey: "games.loveletter.name",
	descKey: "games.loveletter.desc",
	rulesKey: "games.loveletter.rules",
	icon: "💌",
	iconImg: "games/loveletter.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/loveletter/en.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [4],
	accent: "#db2777",
	releasedAt: "2026-09-15",
	search: {
		py: "qing shu",
		init: "qs"
	},
	hotseat: "cover"
}, R = t.enum([
	"spy",
	"guard",
	"priest",
	"baron",
	"handmaid",
	"prince",
	"chancellor",
	"king",
	"countess",
	"princess"
]), z = t.string(), B = t.object({ edition: t.enum(["classic", "modern"]).default("modern") }).default({ edition: "modern" }), V = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		card: R,
		target: z.optional(),
		guess: R.optional()
	}),
	t.object({
		type: t.literal("chancellorPick"),
		keep: R,
		deeper: R
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), ne = t.discriminatedUnion("kind", [t.object({
	kind: t.literal("priest"),
	target: z,
	card: R
}), t.object({
	kind: t.literal("baron"),
	opponent: z,
	myCard: R,
	theirCard: R,
	iWon: t.boolean().nullable()
})]), re = t.object({
	kind: t.literal("play"),
	rid: z,
	card: R,
	target: z.nullable(),
	guess: R.nullable(),
	hit: t.boolean(),
	outRid: z.nullable()
}), ie = t.object({
	kind: t.literal("roundEnd"),
	reason: t.enum(["lastStanding", "deckOut"]),
	winners: t.array(z),
	spyBonus: t.array(z)
}), ae = t.discriminatedUnion("kind", [re, ie]), oe = t.discriminatedUnion("kind", [
	re,
	ie,
	t.object({
		kind: t.literal("round"),
		n: t.int().min(1)
	})
]), se = t.object({
	edition: t.enum(["classic", "modern"]),
	round: t.int().min(1),
	phase: t.enum([
		"play",
		"settle",
		"roundEnd",
		"done"
	]),
	settleBeat: t.enum([
		"show",
		"effect",
		"princeDraw",
		"out"
	]).nullable(),
	deckCount: t.int().nonnegative(),
	burnAvailable: t.boolean(),
	burnUp: t.array(R),
	turn: z.nullable(),
	needTokens: t.int().min(1),
	players: t.array(t.object({
		rid: z,
		out: t.boolean(),
		protected: t.boolean(),
		tokens: t.int().nonnegative(),
		handCount: t.int().nonnegative(),
		discards: t.array(R)
	})),
	pendingChancellor: t.object({
		rid: z,
		count: t.int().min(2).max(3)
	}).nullable(),
	revealHands: t.record(z, t.array(R)).nullable(),
	last: ae.nullable(),
	log: t.array(oe)
}), ce = t.object({
	hand: t.array(R),
	reveal: ne.nullable(),
	chancellorCards: t.array(R).nullable()
}), H = 4200, U = {
	show: 1700,
	effect: (e) => ({
		spy: 1500,
		guard: 2400,
		priest: 1900,
		baron: 2500,
		handmaid: 1700,
		prince: 2700,
		chancellor: 2100,
		king: 2200,
		countess: 1500,
		princess: 1700
	})[e],
	princeDraw: 1700,
	out: 1400
}, le = (e) => e.players.filter((t) => !e.outRids.includes(t));
function W(e, t, n) {
	let r = le(e).filter((n) => n !== t && !e.protectedRids.includes(n));
	return n === "prince" ? [t, ...r] : r;
}
function ue(e) {
	return e.includes("countess") && (e.includes("king") || e.includes("prince"));
}
function G(t, n) {
	let r = t.rngCursor;
	for (let i = n.length - 1; i > 0; --i) {
		let a = e(t.seed, r, i + 1);
		r += 1, [n[i], n[a]] = [n[a], n[i]];
	}
	return t.rngCursor = r, n;
}
function K(e, t) {
	e.discards[t] = [...e.discards[t], ...e.hands[t]], e.hands[t] = [], e.outRids.includes(t) || (e.outRids = [...e.outRids, t]), e.protectedRids = e.protectedRids.filter((e) => e !== t);
}
function de(e, t) {
	let n = le(e), r;
	if (t === "lastStanding") r = n.slice(0, 1);
	else {
		let t = (t) => e.hands[t].length ? j(e.hands[t][0], e.edition) : -1, i = Math.max(...n.map(t)), a = n.filter((e) => t(e) === i);
		if (a.length === 1) r = a;
		else {
			let t = (t) => e.discards[t].reduce((t, n) => t + j(n, e.edition), 0), n = Math.max(...a.map(t)), i = a.filter((e) => t(e) === n);
			r = i.length === 1 ? i : [];
		}
	}
	let i = e.edition === "modern" && e.spyPlayed.length === 1 ? [...e.spyPlayed] : [];
	for (let t of [...r, ...i]) e.tokens[t] += 1;
	let a = {
		kind: "roundEnd",
		reason: t,
		winners: r,
		spyBonus: i
	};
	e.last = a, e.log = [...e.log, a];
	let o = [{
		kind: "roundEnd",
		data: {
			reason: t,
			winners: r,
			spyBonus: i
		}
	}, ...[...r, ...i].map((e, t) => ({
		kind: "token",
		rid: e,
		...t > 0 ? { with: !0 } : {}
	}))];
	return e.phase = e.players.some((t) => e.tokens[t] >= e.needTokens) ? "done" : "roundEnd", e.beatMs = H, o;
}
function fe(e, t) {
	e.deck = G(e, N(e.edition)), e.burnDown = e.deck.pop() ?? null, e.burnUp = e.players.length === 2 ? [
		e.deck.pop(),
		e.deck.pop(),
		e.deck.pop()
	] : [], e.hands = Object.fromEntries(e.players.map((t) => [t, [e.deck.pop()]])), e.discards = Object.fromEntries(e.players.map((e) => [e, []])), e.protectedRids = [], e.outRids = [], e.spyPlayed = [], e.reveals = Object.fromEntries(e.players.map((e) => [e, null])), e.stagedReveals = null, e.pendingOutRid = null, e.settleBeat = null, e.pendingPlay = null, e.pendingEntry = null, e.pendingPrinceDrawRid = null, e.pendingChancellor = null, e.firstIndex = e.players.indexOf(t);
}
function pe(e, t) {
	if (e.protectedRids = e.protectedRids.filter((e) => e !== t), e.deck.length === 0) return e.turn = null, de(e, "deckOut");
	let n = e.deck.pop();
	return e.hands[t] = [...e.hands[t], n], e.turn = t, [{
		kind: "draw",
		rid: t,
		data: { edition: e.edition },
		for: [t],
		secret: { card: n }
	}];
}
function me(e) {
	if (le(e).length <= 1) return e.turn = null, de(e, "lastStanding");
	let t = e.players.indexOf(e.turn);
	for (let n = 1; n <= e.players.length; n += 1) {
		let r = e.players[(t + n) % e.players.length];
		if (!e.outRids.includes(r)) return pe(e, r);
	}
	return [];
}
function he(t, n, r) {
	let i = {
		edition: t.edition,
		players: n,
		round: 1,
		phase: "play",
		settleBeat: null,
		pendingPlay: null,
		pendingEntry: null,
		pendingPrinceDrawRid: null,
		deck: [],
		burnDown: null,
		burnUp: [],
		hands: {},
		discards: {},
		protectedRids: [],
		outRids: [],
		turn: null,
		tokens: Object.fromEntries(n.map((e) => [e, 0])),
		spyPlayed: [],
		firstIndex: 0,
		reveals: {},
		stagedReveals: null,
		pendingOutRid: null,
		pendingChancellor: null,
		last: null,
		log: [{
			kind: "round",
			n: 1
		}],
		needTokens: P(t.edition, n.length),
		beatMs: 0,
		seed: r,
		rngCursor: 0
	};
	return fe(i, n[e(r, i.rngCursor++, n.length)]), {
		state: i,
		fx: [{
			kind: "roundStart",
			data: { round: 1 }
		}, ...pe(i, i.players[i.firstIndex])]
	};
}
function ge(e, t) {
	let { rid: n, card: r, target: i, guess: a } = t, o = null, s = !1, c = null, l = null, u = null;
	switch (r) {
		case "guard":
			i && e.hands[i][0] === a && (o = i, s = !0);
			break;
		case "priest":
			if (i) {
				let t = e.hands[i][0];
				e.stagedReveals = { [n]: {
					kind: "priest",
					target: i,
					card: t
				} }, l = [n], u = { peek: t };
			}
			break;
		case "baron":
			if (i) {
				let t = e.hands[n][0], r = e.hands[i][0], a = j(t, e.edition) - j(r, e.edition);
				e.stagedReveals = {
					[n]: {
						kind: "baron",
						opponent: i,
						myCard: t,
						theirCard: r,
						iWon: a === 0 ? null : a > 0
					},
					[i]: {
						kind: "baron",
						opponent: n,
						myCard: r,
						theirCard: t,
						iWon: a === 0 ? null : a < 0
					}
				}, l = [n, i], u = {
					mine: t,
					theirs: r
				}, a !== 0 && (o = a < 0 ? n : i);
			}
			break;
		case "handmaid":
			e.protectedRids = [...e.protectedRids, n];
			break;
		case "prince":
			i && (c = e.hands[i][0], e.hands[i] = [], e.discards[i] = [...e.discards[i], c], c === "spy" && !e.spyPlayed.includes(i) && (e.spyPlayed = [...e.spyPlayed, i]), c === "princess" ? o = i : e.pendingPrinceDrawRid = i);
			break;
		case "chancellor":
			if (e.deck.length > 0) {
				let t = [...e.hands[n]];
				for (let n = 0, r = Math.min(2, e.deck.length); n < r; n += 1) t.push(e.deck.pop());
				e.pendingChancellor = {
					rid: n,
					cards: t
				};
			}
			break;
		case "king":
			if (i) {
				l = [n, i], u = {
					mine: e.hands[n][0],
					theirs: e.hands[i][0]
				};
				let t = e.hands[n];
				e.hands[n] = e.hands[i], e.hands[i] = t;
			}
			break;
		case "princess": o = n;
	}
	return e.pendingOutRid = o, e.pendingEntry = {
		kind: "play",
		rid: n,
		card: r,
		target: i,
		guess: a,
		hit: s,
		outRid: null
	}, {
		kind: "playEffect",
		rid: n,
		data: {
			card: r,
			target: i,
			guess: a,
			edition: e.edition,
			outRid: o,
			...c ? { dropped: c } : {}
		},
		...l && u ? {
			for: l,
			secret: u
		} : {}
	};
}
function _e(e, t, n) {
	if (t.type === "tick") {
		if (e.phase === "settle") {
			let t = structuredClone(e);
			if (t.settleBeat === "show" && t.pendingPlay) {
				let e = t.pendingPlay;
				t.pendingPlay = null;
				let n = ge(t, e);
				return t.settleBeat = "effect", t.beatMs = U.effect(e.card), {
					state: t,
					fx: [n]
				};
			}
			if (t.settleBeat === "effect" || !t.settleBeat) {
				if (t.stagedReveals) {
					for (let [e, n] of Object.entries(t.stagedReveals)) t.reveals[e] = n;
					t.stagedReveals = null;
				}
				if (t.pendingEntry &&= (t.last = t.pendingEntry, t.log = [...t.log.slice(0, -1), t.pendingEntry], null), t.pendingPrinceDrawRid) {
					let e = t.pendingPrinceDrawRid;
					t.pendingPrinceDrawRid = null;
					let n = t.deck.length === 0, r = n ? t.burnDown : t.deck.pop() ?? null;
					if (n && (t.burnDown = null), r) return t.hands[e] = [r], t.settleBeat = "princeDraw", t.beatMs = U.princeDraw, {
						state: t,
						fx: [{
							kind: "princeDraw",
							rid: e,
							data: {
								edition: t.edition,
								fromBurn: n
							},
							for: [e],
							secret: { card: r }
						}]
					};
				}
				if (t.pendingOutRid) {
					let e = t.pendingOutRid;
					t.pendingOutRid = null, K(t, e), t.last?.kind === "play" && (t.last = {
						...t.last,
						outRid: e
					});
					let n = t.log.at(-1);
					return n?.kind === "play" && (t.log = [...t.log.slice(0, -1), {
						...n,
						outRid: e
					}]), t.settleBeat = "out", t.beatMs = U.out, {
						state: t,
						fx: [{
							kind: "out",
							rid: e
						}]
					};
				}
			}
			return t.phase = "play", t.settleBeat = null, t.beatMs = 0, t.pendingChancellor ? {
				state: t,
				fx: []
			} : {
				state: t,
				fx: me(t)
			};
		}
		if (e.phase !== "roundEnd") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = t.last?.kind === "roundEnd" ? t.last : null, r = n && n.winners.length > 0 ? n.winners[0] : t.players[(t.firstIndex + 1) % t.players.length];
		t.round += 1, t.phase = "play", t.last = null, t.log = [...t.log, {
			kind: "round",
			n: t.round
		}], t.beatMs = 0, fe(t, r);
		let i = pe(t, t.players[t.firstIndex]);
		return {
			state: t,
			fx: [{
				kind: "roundStart",
				data: { round: t.round }
			}, ...i]
		};
	}
	if (e.phase !== "play" || e.turn !== n.by) return { code: "games.loveletter.errNotYourTurn" };
	if (e.pendingChancellor) {
		if (t.type !== "chancellorPick") return { code: "games.loveletter.errChancellorPending" };
		if (e.pendingChancellor.rid !== n.by) return { code: "games.loveletter.errNotYourTurn" };
		let { cards: r } = e.pendingChancellor, i = [...r];
		for (let e of [t.keep, t.deeper]) {
			let t = i.indexOf(e);
			if (t < 0) return { code: "games.loveletter.errBadChancellor" };
			i.splice(t, 1);
		}
		let a = structuredClone(e);
		return a.hands[n.by] = [t.keep], a.deck = [
			t.deeper,
			...i,
			...a.deck
		], a.pendingChancellor = null, a.last = {
			kind: "play",
			rid: n.by,
			card: "chancellor",
			target: null,
			guess: null,
			hit: !1,
			outRid: null
		}, {
			state: a,
			fx: me(a)
		};
	}
	if (t.type !== "play") return { code: "games.loveletter.errNotYourTurn" };
	let r = e.hands[n.by];
	if (!r.includes(t.card)) return { code: "games.loveletter.errBadCard" };
	if (ue(r) && t.card !== "countess") return { code: "games.loveletter.errCountess" };
	let i = W(e, n.by, t.card), a = A[t.card].needsTarget && i.length > 0;
	if (a && (!t.target || !i.includes(t.target))) return { code: "games.loveletter.errBadTarget" };
	let o = a ? t.target : null;
	if (t.card === "guard" && o && (!t.guess || t.guess === "guard" || !((t) => A[t].count[e.edition] > 0)(t.guess))) return { code: "games.loveletter.errBadGuess" };
	let s = structuredClone(e);
	s.reveals[n.by] = null;
	let c = s.hands[n.by].indexOf(t.card);
	s.hands[n.by] = s.hands[n.by].filter((e, t) => t !== c), s.discards[n.by] = [...s.discards[n.by], t.card], t.card === "spy" && !s.spyPlayed.includes(n.by) && (s.spyPlayed = [...s.spyPlayed, n.by]);
	let l = {
		kind: "play",
		rid: n.by,
		card: t.card,
		target: null,
		guess: null,
		hit: !1,
		outRid: null
	};
	return s.last = l, s.log = [...s.log, l], s.phase = "settle", s.settleBeat = "show", s.pendingPlay = {
		rid: n.by,
		card: t.card,
		target: o,
		guess: t.card === "guard" ? t.guess ?? null : null
	}, s.pendingEntry = null, s.pendingOutRid = null, s.pendingPrinceDrawRid = null, s.beatMs = U.show, {
		state: s,
		fx: [{
			kind: "playShow",
			rid: n.by,
			data: {
				card: t.card,
				edition: s.edition
			}
		}]
	};
}
function ve(e, t) {
	let n = e.phase === "roundEnd" || e.phase === "done" ? Object.fromEntries(le(e).map((t) => [t, e.hands[t]])) : null;
	return {
		public: {
			edition: e.edition,
			round: e.round,
			phase: e.phase,
			settleBeat: e.settleBeat ?? null,
			deckCount: e.deck.length,
			burnAvailable: e.burnDown !== null,
			burnUp: e.burnUp,
			turn: e.turn,
			needTokens: e.needTokens,
			players: e.players.map((t) => ({
				rid: t,
				out: e.outRids.includes(t),
				protected: e.protectedRids.includes(t),
				tokens: e.tokens[t],
				handCount: e.hands[t]?.length ?? 0,
				discards: e.discards[t]
			})),
			revealHands: n,
			pendingChancellor: e.pendingChancellor ? {
				rid: e.pendingChancellor.rid,
				count: e.pendingChancellor.cards.length
			} : null,
			last: e.last,
			log: e.log
		},
		private: {
			hand: e.hands[t] ?? [],
			reveal: e.reveals[t] ?? null,
			chancellorCards: e.pendingChancellor?.rid === t ? e.pendingChancellor.cards : null
		}
	};
}
function ye(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.tokens[n] - e.tokens[t]), n = e.tokens[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.tokens[t] === n),
		ranking: t,
		scores: { ...e.tokens }
	};
}
function be(e) {
	return e.phase === "settle" || e.phase === "roundEnd" ? e.beatMs : null;
}
var xe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: L,
	schemas: {
		action: V,
		publicView: se,
		privateView: ce,
		config: B
	},
	setup: he,
	reduce: _e,
	viewFor: ve,
	status: ye,
	nextTickIn: be
};
//#endregion
//#region src/games/loveletter/seal-icon.tsx
function Se({ size: e = 16, color: t = "var(--color-ink)", className: n }) {
	return /* @__PURE__ */ v("svg", {
		width: e,
		height: e,
		viewBox: "0 0 64 64",
		fill: "none",
		"aria-hidden": !0,
		className: n,
		children: [
			/* @__PURE__ */ _("rect", {
				x: 7,
				y: 17,
				width: 50,
				height: 32,
				rx: 5,
				stroke: t,
				strokeWidth: 3.5
			}),
			/* @__PURE__ */ _("path", {
				d: "M9 20.5 L32 36 L55 20.5",
				stroke: t,
				strokeWidth: 3.5,
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ _("path", {
				fillRule: "evenodd",
				fill: t,
				d: "M22 36 a10 10 0 1 0 20 0 a10 10 0 1 0 -20 0 Z M32 42.2 C28.4 38.6 27.2 36 29.4 34.4 C30.8 33.4 31.7 34 32 35.3 C32.3 34 33.2 33.4 34.6 34.4 C36.8 36 35.6 38.6 32 42.2 Z"
			})
		]
	});
}
//#endregion
//#region src/games/loveletter/card.tsx
var Ce = {
	hand: "h-32 w-22 rounded-md border-2",
	featured: "rounded-md border-2",
	small: "h-14 w-11 rounded border",
	ledger: "h-[82px] w-[58px] rounded border-2"
}, we = {
	spy: "games/loveletter/spy.webp",
	guard: "games/loveletter/guard.webp",
	priest: "games/loveletter/priest.webp",
	baron: "games/loveletter/baron.webp",
	handmaid: "games/loveletter/handmaid.webp",
	prince: "games/loveletter/prince.webp",
	chancellor: "games/loveletter/chancellor.webp",
	king: "games/loveletter/king.webp",
	countess: "games/loveletter/countess.webp",
	princess: "games/loveletter/princess.webp"
}, Te = `color-mix(in srgb, ${L.accent} 16%, #fff)`;
function Ee({ role: e, className: t }) {
	return /* @__PURE__ */ _("img", {
		src: we[e],
		alt: "",
		draggable: !1,
		className: `scale-105 rounded-full ${t ?? ""}`,
		style: { background: Te }
	});
}
function q({ role: e, edition: t, size: n, selected: r, elevated: i, mark: a, style: o }) {
	let s = c(), l = n === "hand" || n === "featured", u = n !== "small";
	return /* @__PURE__ */ v("span", {
		"aria-label": s(I[e]),
		className: `ll-card ll-card-${n}${o ? " ll-card-sized" : ""} relative inline-flex flex-none flex-col items-stretch border-ink bg-surface ${Ce[n]} ${i ? "shadow-[2px_2px_0_var(--color-ink)]" : ""}`,
		style: {
			...r ? {
				borderColor: L.accent,
				boxShadow: `4px 4px 0 ${L.accent}`
			} : {},
			...o
		},
		children: [
			u && /* @__PURE__ */ _("span", {
				"aria-hidden": !0,
				className: "pointer-events-none absolute inset-1 rounded-[4px] border border-ink/20"
			}),
			/* @__PURE__ */ _("span", {
				className: `ll-card-value-wrap absolute z-10 ${l ? "top-1 left-1" : "top-0.5 left-0.5"}`,
				children: /* @__PURE__ */ _("span", {
					className: `ll-card-value grid place-items-center rounded-full border-ink font-mono leading-none font-extrabold tabular-nums text-white ${n === "featured" ? "size-8 border-2 text-lg" : l ? "size-7 border-2 text-base" : "size-5 border-2 text-[10px]"}`,
					style: { background: L.accent },
					children: j(e, t)
				})
			}),
			u && /* @__PURE__ */ _("span", {
				"aria-hidden": !0,
				className: "ll-card-seal absolute top-1.5 right-1.5 opacity-50",
				children: /* @__PURE__ */ _(Se, {
					size: n === "featured" ? 17 : 14,
					color: L.accent
				})
			}),
			/* @__PURE__ */ _("span", {
				className: `ll-card-art relative flex flex-1 items-end justify-center ${l ? "pb-2.5" : "pb-1"}`,
				children: /* @__PURE__ */ _(Ee, {
					role: e,
					className: n === "featured" ? "size-20" : l ? "size-16" : n === "ledger" ? "size-10" : "size-6"
				})
			}),
			u && /* @__PURE__ */ _("span", {
				className: `ll-card-name relative truncate border-t-2 border-ink/15 px-1 py-0.5 text-center leading-tight font-bold ${l ? "text-xs" : "text-[10px]"}`,
				style: { background: Te },
				children: s(I[e])
			}),
			r && /* @__PURE__ */ _("span", {
				className: "ll-card-check absolute top-0.5 right-0.5 grid size-4 place-items-center rounded-full border-2 border-ink text-white",
				style: { background: L.accent },
				children: /* @__PURE__ */ _(p, { size: 10 })
			}),
			a && /* @__PURE__ */ _("span", {
				className: "ll-card-mark absolute -top-2 left-1/2 -translate-x-1/2 rounded-full border-2 border-ink px-1.5 text-[10px] leading-4 font-bold whitespace-nowrap text-white",
				style: { background: a === "keep" ? L.accent : "var(--color-warn)" },
				children: s(a === "keep" ? "games.loveletter.keepMark" : "games.loveletter.deeperMark")
			})
		]
	});
}
function J({ size: e = "small", style: t }) {
	return /* @__PURE__ */ v("span", {
		className: `ll-card-back${t ? " ll-card-sized" : ""} relative inline-flex flex-none place-items-center items-center justify-center overflow-hidden rounded border-2 border-ink ${e === "deck" ? "ll-back-deck h-[70px] w-[50px]" : "h-14 w-11"}`,
		style: {
			background: L.accent,
			...t
		},
		children: [/* @__PURE__ */ _("svg", {
			className: "absolute inset-0 size-full",
			viewBox: "0 0 44 64",
			preserveAspectRatio: "none",
			"aria-hidden": !0,
			children: /* @__PURE__ */ _("path", {
				d: "M-10 16 L54 -12 M-10 36 L54 8 M-10 56 L54 28 M-10 76 L54 48",
				stroke: "#ffffff",
				strokeWidth: 5,
				opacity: .14,
				fill: "none"
			})
		}), /* @__PURE__ */ _("span", {
			"aria-hidden": !0,
			className: "absolute inset-0 grid place-items-center",
			children: /* @__PURE__ */ _(Se, {
				size: e === "deck" ? 28 : 18,
				color: "#ffffff"
			})
		})]
	});
}
function Y(e, t) {
	return {
		width: e,
		height: t,
		"--ll-card-w": `${e}px`,
		"--ll-card-h": `${t}px`
	};
}
//#endregion
//#region src/games/loveletter/letter-table.tsx
function De(e, t, n) {
	if (e.kind === "round") return n("games.loveletter.logRound", { n: e.n });
	if (e.kind === "roundEnd") {
		let r = e.winners.length ? n("games.loveletter.roundWin", { name: e.winners.map(t).join("、") }) : n("games.loveletter.roundNoWin");
		return e.spyBonus.length ? `${r} ${n("games.loveletter.spyBonus", { name: e.spyBonus.map(t).join("、") })}` : r;
	}
	return `${e.card === "guard" && e.target && e.guess ? n("games.loveletter.playLineGuess", {
		name: t(e.rid),
		target: t(e.target),
		guess: n(I[e.guess])
	}) : e.target ? n("games.loveletter.playLineTarget", {
		name: t(e.rid),
		target: t(e.target),
		card: n(I[e.card])
	}) : n("games.loveletter.playLine", {
		name: t(e.rid),
		card: n(I[e.card])
	})}${e.outRid ? ` ${n("games.loveletter.playLineOut", { name: t(e.outRid) })}` : e.card === "guard" && e.target && !e.hit ? ` ${n("games.loveletter.playLineMiss")}` : ""}`;
}
function Oe({ rid: e, children: t }) {
	let { ref: n } = o(`disc:${e}`);
	return /* @__PURE__ */ _("span", {
		ref: n,
		className: "ll-seat-avatar",
		children: t
	});
}
function ke({ rid: e }) {
	let { ref: t } = o(`discTop:${e}`);
	return /* @__PURE__ */ _("span", {
		ref: t,
		className: "ll-discard-anchor",
		"aria-hidden": !0
	});
}
function Ae({ player: e, member: t, myRid: n, isTurn: r, slot: i, picking: a }) {
	let o = c(), l = s((e) => e.locale), u = e.rid === n, f = x[(t?.colorIndex ?? 0) % x.length], p = !!a && a.eligible.includes(e.rid) && !e.out, m = a?.target === e.rid, h = t ? d(t, l) : e.rid, g = e.out ? o("games.loveletter.seatOut") : r ? o("games.loveletter.seatTurn") : e.protected ? o("games.loveletter.seatProtected") : "";
	return /* @__PURE__ */ v("li", {
		className: `ll-seat ll-slot-${i}${u ? " ll-self" : ""}${r ? " ll-turn" : ""}${e.out ? " ll-out" : ""}${e.protected ? " ll-protected" : ""}${p ? " ll-eligible" : ""}${m ? " ll-picked" : ""}`,
		"data-rid": e.rid,
		children: [
			/* @__PURE__ */ _("span", {
				className: "ll-seat-shape",
				"aria-hidden": !0
			}),
			p && /* @__PURE__ */ _("span", {
				className: "ll-seat-choice",
				"aria-hidden": !0,
				children: o(m ? "games.loveletter.targetPicked" : "games.loveletter.targetAvailable")
			}),
			/* @__PURE__ */ v("div", {
				className: "ll-seat-head",
				children: [
					/* @__PURE__ */ _(Oe, {
						rid: e.rid,
						children: /* @__PURE__ */ _("img", {
							src: y[(t?.avatar ?? 0) % y.length],
							alt: "",
							draggable: !1,
							style: { backgroundColor: f.hex }
						})
					}),
					/* @__PURE__ */ v("span", {
						className: "ll-seat-identity",
						children: [/* @__PURE__ */ _("strong", { children: h }), /* @__PURE__ */ _("small", { children: g })]
					}),
					/* @__PURE__ */ v("span", {
						className: "ll-seat-score",
						"aria-label": o("games.loveletter.tokensAria", { n: e.tokens }),
						children: [/* @__PURE__ */ _("b", {
							"aria-hidden": !0,
							children: "♥"
						}), /* @__PURE__ */ _(b, { value: e.tokens })]
					})
				]
			}),
			/* @__PURE__ */ _(ke, { rid: e.rid }),
			p && /* @__PURE__ */ _("button", {
				type: "button",
				className: "ll-seat-target",
				"aria-label": o(m ? "games.loveletter.cancelTargetAria" : "games.loveletter.pickTargetAria", { name: h }),
				"aria-pressed": m,
				onClick: () => a.onPick(e.rid)
			})
		]
	});
}
function je({ reveal: e, nameOf: t, onClose: n }) {
	let r = c(), i = e.kind === "priest" ? r("games.loveletter.revealPriest", {
		name: t(e.target),
		card: r(I[e.card])
	}) : e.iWon === null ? r("games.loveletter.revealBaronTie", {
		name: t(e.opponent),
		card: r(I[e.theirCard])
	}) : r(e.iWon ? "games.loveletter.revealBaronWin" : "games.loveletter.revealBaronLose", {
		name: t(e.opponent),
		card: r(I[e.theirCard])
	});
	return /* @__PURE__ */ v("div", {
		className: "ll-reveal",
		children: [
			/* @__PURE__ */ _(h, { size: 16 }),
			/* @__PURE__ */ _("span", { children: i }),
			/* @__PURE__ */ _("button", {
				type: "button",
				"aria-label": r("games.loveletter.dismiss"),
				onClick: n,
				children: /* @__PURE__ */ _(m, { size: 16 })
			})
		]
	});
}
function Me({ pub: e, members: t, myRid: l, picking: u, guardGuess: f, reveal: p, onRevealClose: h }) {
	let y = c(), b = s((e) => e.locale), x = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? d(n, b) : e;
	}, { ref: S } = o("table"), { ref: C } = o("deck"), { ref: w } = o("burn"), { ref: T, hidden: E } = o("showcase"), [D, O] = a(!1), [k, A] = a(!1), ee = i(null), j = i(null), N = i(null), [P, F] = a(null), te = Math.max(0, e.players.findIndex((e) => e.rid === l)), L = [...e.players.slice(te + 1), ...e.players.slice(0, te + 1)].filter((e) => e.rid !== l), R = e.players.find((e) => e.rid === l), z = e.players.reduce((e, t) => e + t.discards.length, 0), B = e.log.at(-1), V = () => {
		O(!1), ee.current?.focus();
	}, ne = () => {
		A(!1), j.current?.focus();
	};
	return n(() => {
		if (!D && !k) return;
		let e = (e) => {
			e.key === "Escape" && (D ? V() : ne());
		};
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}, [D, k]), r(() => {
		let e = N.current;
		if (!e || !u?.target || !R) {
			F(null);
			return;
		}
		let t = (t) => [...e.querySelectorAll(".ll-seat")].find((e) => e.dataset.rid === t), n = t(l)?.querySelector(".ll-seat-avatar"), r = t(u.target)?.querySelector(".ll-seat-avatar");
		if (!n || !r) {
			F(null);
			return;
		}
		let i = () => {
			let t = e.getBoundingClientRect(), i = n.getBoundingClientRect(), a = r.getBoundingClientRect(), o = i.left + i.width / 2 - t.left, s = i.top + 4 - t.top, c = a.left + a.width / 2 - t.left, l = a.bottom + 4 - t.top, u = c < t.width / 2 ? -1 : 1, d = s - l < 120, f = u < 0 ? 14 : t.width - 14, p = Math.min(48, Math.max(16, (s - l) * .34)), m = d ? o + u * 30 : f, h = s - (d ? 18 : p), g = d ? c - u * 18 : f, _ = l + (d ? 22 : p), v = c - g, y = l - _, b = Math.hypot(v, y) || 1, x = v / b, S = y / b, C = c - x * 19, w = l - S * 19, T = `${c},${l} ${C - S * 7},${w + x * 7} ${C + S * 7},${w - x * 7}`;
			F({
				path: `M ${o} ${s} C ${m} ${h}, ${g} ${_}, ${c} ${l}`,
				head: T,
				width: t.width,
				height: t.height
			});
		};
		i();
		let a = new ResizeObserver(i);
		return a.observe(e), window.addEventListener("resize", i), () => {
			a.disconnect(), window.removeEventListener("resize", i);
		};
	}, [
		l,
		u?.target,
		e.players.length,
		R
	]), /* @__PURE__ */ v("div", {
		ref: S,
		className: "ll-desk",
		children: [
			/* @__PURE__ */ v("div", {
				className: "ll-desk-title",
				children: [/* @__PURE__ */ _("strong", { children: y("games.loveletter.tableTitle") }), /* @__PURE__ */ _("span", { children: y("games.loveletter.tableSubtitle", { n: e.players.length }) })]
			}),
			/* @__PURE__ */ v("ul", {
				ref: N,
				className: "ll-board",
				"data-count": e.players.length,
				children: [
					P && /* @__PURE__ */ _("li", {
						className: "ll-arrow-layer",
						"aria-hidden": "true",
						children: /* @__PURE__ */ v("svg", {
							className: "ll-target-arrow",
							viewBox: `0 0 ${P.width} ${P.height}`,
							preserveAspectRatio: "none",
							children: [
								/* @__PURE__ */ _("path", {
									className: "ll-arrow-shadow",
									d: P.path
								}),
								/* @__PURE__ */ _("path", {
									className: "ll-arrow-line",
									d: P.path
								}),
								/* @__PURE__ */ _("polygon", {
									className: "ll-arrow-head",
									points: P.head
								})
							]
						}, u?.target)
					}),
					L.map((n, r) => /* @__PURE__ */ _(Ae, {
						player: n,
						member: t.find((e) => e.rid === n.rid),
						myRid: l,
						isTurn: e.turn === n.rid || e.pendingChancellor?.rid === n.rid,
						slot: r + 1,
						picking: u
					}, n.rid)),
					/* @__PURE__ */ _("li", {
						className: "ll-mail-stage",
						"data-burn-up": e.burnUp.length > 0,
						children: e.phase === "roundEnd" || e.phase === "done" ? /* @__PURE__ */ v("div", {
							className: "ll-round-summary",
							children: [
								/* @__PURE__ */ _("small", { children: y(e.last?.kind === "roundEnd" && e.last.reason === "deckOut" ? "games.loveletter.reasonDeckOut" : "games.loveletter.reasonLastStanding") }),
								/* @__PURE__ */ _("strong", { children: e.last?.kind === "roundEnd" && e.last.winners.length ? y("games.loveletter.roundWin", { name: e.last.winners.map(x).join("、") }) : y("games.loveletter.roundNoWin") }),
								e.last?.kind === "roundEnd" && e.last.spyBonus.length > 0 && /* @__PURE__ */ _("span", { children: y("games.loveletter.spyBonus", { name: e.last.spyBonus.map(x).join("、") }) })
							]
						}) : /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("div", {
							className: "ll-mail-objects",
							children: [/* @__PURE__ */ v("div", {
								className: "ll-mail-object",
								children: [/* @__PURE__ */ v("span", {
									ref: C,
									className: "ll-deck-stack",
									"aria-label": y("games.loveletter.deckAria", { n: e.deckCount }),
									children: [/* @__PURE__ */ _(J, { size: "deck" }), /* @__PURE__ */ _("b", { children: e.deckCount })]
								}), /* @__PURE__ */ _("span", { children: y("games.loveletter.deckLabel") })]
							}), /* @__PURE__ */ v("div", {
								className: "ll-mail-object",
								children: [/* @__PURE__ */ _("span", {
									ref: w,
									className: "ll-burn-card",
									"aria-label": y("games.loveletter.burnDownAria"),
									children: e.burnAvailable && /* @__PURE__ */ _(J, { size: "deck" })
								}), /* @__PURE__ */ _("span", { children: y("games.loveletter.burnDownLabel") })]
							})]
						}), e.burnUp.length > 0 && /* @__PURE__ */ _("div", {
							className: "ll-burn-up",
							"aria-label": y("games.loveletter.burnUpAria"),
							children: e.burnUp.map((t, n) => /* @__PURE__ */ _(q, {
								role: t,
								edition: e.edition,
								size: "small"
							}, `${t}:${n}`))
						})] })
					}),
					R && /* @__PURE__ */ _(Ae, {
						player: R,
						member: t.find((e) => e.rid === l),
						myRid: l,
						isTurn: e.turn === l || e.pendingChancellor?.rid === l,
						slot: 0,
						picking: u
					}),
					e.revealHands && /* @__PURE__ */ v("li", {
						className: "ll-round-hands",
						children: [
							/* @__PURE__ */ _("small", { children: y(e.last?.kind === "roundEnd" && e.last.reason === "deckOut" ? "games.loveletter.reasonDeckOut" : "games.loveletter.reasonLastStanding") }),
							/* @__PURE__ */ _("strong", { children: e.last?.kind === "roundEnd" && e.last.winners.length ? y("games.loveletter.roundWin", { name: e.last.winners.map(x).join("、") }) : y("games.loveletter.roundNoWin") }),
							/* @__PURE__ */ _("span", { children: y("games.loveletter.handReveal") }),
							/* @__PURE__ */ _("div", { children: Object.entries(e.revealHands).map(([t, n]) => /* @__PURE__ */ v("span", {
								className: "ll-round-hand",
								children: [/* @__PURE__ */ _("b", { children: x(t) }), n.map((t, n) => /* @__PURE__ */ _(q, {
									role: t,
									edition: e.edition,
									size: "small"
								}, `${t}:${n}`))]
							}, t)) }),
							e.last?.kind === "roundEnd" && e.last.spyBonus.length > 0 && /* @__PURE__ */ _("small", { children: y("games.loveletter.spyBonus", { name: e.last.spyBonus.map(x).join("、") }) })
						]
					})
				]
			}),
			e.settleBeat === "show" && e.last?.kind === "play" && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("div", {
				className: "ll-showcase-scrim",
				"aria-hidden": !0
			}), /* @__PURE__ */ v("div", {
				className: "ll-showcase",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ _("span", {
					className: "ll-showcase-actor",
					children: x(e.last.rid)
				}), /* @__PURE__ */ _("span", {
					ref: T,
					style: E ? { visibility: "hidden" } : void 0,
					children: /* @__PURE__ */ _(q, {
						role: e.last.card,
						edition: e.edition,
						size: "featured"
					})
				})]
			})] }),
			/* @__PURE__ */ v("div", {
				className: "ll-desk-actions",
				children: [/* @__PURE__ */ v("button", {
					ref: j,
					type: "button",
					className: "ll-log-ticker",
					"aria-label": y("games.loveletter.logAria"),
					onClick: () => A(!0),
					children: [/* @__PURE__ */ v("span", { children: ["✉ ", B ? De(B, x, y) : y("games.loveletter.logEmpty")] }), /* @__PURE__ */ v("b", { children: [y("games.loveletter.logOpen"), " ›"] })]
				}), /* @__PURE__ */ v("button", {
					ref: ee,
					type: "button",
					className: "ll-ledger-open",
					"aria-label": y("games.loveletter.ledgerOpenAria", { n: z }),
					onClick: () => O(!0),
					children: [/* @__PURE__ */ _("span", { children: y("games.loveletter.ledgerTitle") }), /* @__PURE__ */ _("b", { children: z })]
				})]
			}),
			p && /* @__PURE__ */ _(je, {
				reveal: p,
				nameOf: x,
				onClose: h
			}),
			f && !f.guess && /* @__PURE__ */ v("div", {
				className: "ll-guess-panel",
				children: [/* @__PURE__ */ _("p", { children: y("games.loveletter.selectGuess", { name: x(f.target) }) }), /* @__PURE__ */ _("div", {
					className: "ll-guess-grid",
					children: M(e.edition).filter((e) => e !== "guard").map((e) => /* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => f.onGuess(e),
						children: [/* @__PURE__ */ _(Ee, {
							role: e,
							className: "size-7"
						}), /* @__PURE__ */ _("span", { children: y(I[e]) })]
					}, e))
				})]
			}),
			k && /* @__PURE__ */ _("div", {
				className: "ll-modal",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": y("games.loveletter.logAria"),
				onClick: ne,
				children: /* @__PURE__ */ v("div", {
					className: "ll-sheet",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ v("div", {
						className: "ll-sheet-head",
						children: [/* @__PURE__ */ _("strong", { children: y("games.loveletter.logAria") }), /* @__PURE__ */ _("button", {
							type: "button",
							autoFocus: !0,
							"aria-label": y("games.loveletter.dismiss"),
							onClick: ne,
							children: /* @__PURE__ */ _(m, { size: 18 })
						})]
					}), /* @__PURE__ */ _("ol", {
						className: "ll-history-list",
						children: e.log.map((e, t) => /* @__PURE__ */ _("li", { children: De(e, x, y) }, t))
					})]
				})
			}),
			D && /* @__PURE__ */ _("div", {
				className: "ll-modal",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": y("games.loveletter.ledgerTitle"),
				onClick: V,
				children: /* @__PURE__ */ v("div", {
					className: "ll-sheet",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ v("div", {
						className: "ll-sheet-head",
						children: [/* @__PURE__ */ _("strong", { children: y("games.loveletter.ledgerTitle") }), /* @__PURE__ */ _("button", {
							type: "button",
							autoFocus: !0,
							"aria-label": y("games.loveletter.dismiss"),
							onClick: V,
							children: /* @__PURE__ */ _(m, { size: 18 })
						})]
					}), /* @__PURE__ */ _("div", {
						className: "ll-ledger-groups",
						children: [R, ...L].filter((e) => !!e).map((t) => /* @__PURE__ */ v("section", {
							className: "ll-ledger-group",
							children: [/* @__PURE__ */ v("div", {
								className: "ll-ledger-group-head",
								children: [/* @__PURE__ */ _("span", { children: x(t.rid) }), /* @__PURE__ */ _("b", { children: y("games.loveletter.ledgerCount", { n: t.discards.length }) })]
							}), /* @__PURE__ */ _("div", {
								className: "ll-ledger-cards",
								children: t.discards.length ? t.discards.map((t, n) => /* @__PURE__ */ _(q, {
									role: t,
									edition: e.edition,
									size: "ledger"
								}, `${t}:${n}`)) : /* @__PURE__ */ _("span", {
									className: "ll-ledger-empty",
									children: y("games.loveletter.ledgerEmpty")
								})
							})]
						}, t.rid))
					})]
				})
			})
		]
	});
}
//#endregion
//#region src/games/loveletter/view-player.tsx
function Ne(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ _(Fe, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Pe(e, t, n) {
	let r = e.players.filter((e) => e.rid !== t && !e.out && !e.protected).map((e) => e.rid);
	return n === "prince" ? [t, ...r] : r;
}
function Fe({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let f = c(), p = s((e) => e.locale), m = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? d(t, p) : e;
	}, { ref: h } = o(`hand:${r}`), y = e.phase === "play" && e.turn === r, b = e.phase === "play" && e.pendingChancellor?.rid === r, x = t?.hand ?? [], [S, C] = a(null), [w, T] = a(null), [E, D] = a(null), [O, k] = a(0), [ee, j] = a(!1), [M, N] = a(null), [P, F] = a(null), [R, z] = a(!1), B = S === null ? null : x[S] ?? null, V = `${e.round}|${e.turn}|${e.pendingChancellor?.rid ?? ""}|${x.join(",")}|${t?.chancellorCards?.join(",") ?? ""}`, [ne, re] = a(V);
	ne !== V && (re(V), C(null), T(null), D(null), e.phase !== "settle" && (k(0), j(!1)), N(null), F(null));
	let ie = JSON.stringify(t?.reveal ?? null), [ae, oe] = a(ie);
	ae !== ie && (oe(ie), z(!1));
	let se = y && x.includes("countess") && (x.includes("king") || x.includes("prince")), ce = B ? Pe(e, r, B) : [], H = B !== null && A[B].needsTarget && ce.length > 0, U = B !== null && x.includes(B) && (!H || w !== null) && (B !== "guard" || w === null || E !== null), le = () => {
		B && U && (k(S ?? 0), j(!0), i({
			type: "play",
			card: B,
			...H && w ? { target: w } : {},
			...B === "guard" && w && E ? { guess: E } : {}
		}), C(null), T(null), D(null));
	}, W = t?.chancellorCards ?? null, ue = () => {
		W && M !== null && P !== null && i({
			type: "chancellorPick",
			keep: W[M],
			deeper: W[P]
		});
	}, G, K;
	e.phase === "roundEnd" || e.phase === "done" ? (G = "info", K = f("games.loveletter.roundEnding")) : e.phase === "settle" ? (G = "info", K = f("games.loveletter.resolving", { name: m(e.turn ?? "") })) : b ? (G = "accent", K = f("games.loveletter.chancellorPick")) : e.pendingChancellor ? (G = "info", K = f("games.loveletter.chancellorWait", { name: m(e.pendingChancellor.rid) })) : y ? (G = "accent", K = f("games.loveletter.yourTurn")) : (G = "info", K = f("games.loveletter.waiting", { name: m(e.turn ?? "") }));
	let de = f(b ? "games.loveletter.stepChancellor" : y ? B ? H && !w ? "games.loveletter.stepChooseTarget" : B === "guard" && w && !E ? "games.loveletter.stepGuess" : "games.loveletter.stepConfirm" : "games.loveletter.stepChooseCard" : "games.loveletter.stepWaiting");
	return /* @__PURE__ */ _("div", {
		className: "ll-screen",
		children: /* @__PURE__ */ _(l, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ _("div", {
				className: "ll-banner",
				children: /* @__PURE__ */ _(u, {
					tone: G,
					text: K,
					sub: de,
					chip: /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("strong", { children: f("games.loveletter.roundNumber", { n: e.round }) }), /* @__PURE__ */ _("small", { children: f("games.loveletter.goalCount", { n: e.needTokens }) })] }),
					accent: L.accent
				})
			}),
			actionsHeight: "ll-actions-height",
			actions: /* @__PURE__ */ v("div", {
				className: `ll-hand-dock${b ? " ll-chancellor" : ""}`,
				children: [/* @__PURE__ */ v("div", {
					className: "ll-dock-heading",
					children: [/* @__PURE__ */ _("span", { children: f(b ? "games.loveletter.chancellorCards" : "games.loveletter.yourHand") }), /* @__PURE__ */ _("span", { children: de })]
				}), /* @__PURE__ */ _("div", {
					className: "ll-dock-body",
					children: b && W ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("div", {
						className: "ll-hand-cards",
						children: [/* @__PURE__ */ _("span", {
							ref: h,
							className: "ll-fx-hand-anchor",
							"data-index": O,
							style: { "--ll-hand-index": O },
							"aria-hidden": !0
						}), W.map((t, n) => /* @__PURE__ */ _("button", {
							type: "button",
							"aria-label": f(I[t]),
							onClick: () => {
								M === n ? N(null) : P === n ? F(null) : M === null ? N(n) : F(n);
							},
							children: /* @__PURE__ */ _(q, {
								role: t,
								edition: e.edition,
								size: "hand",
								elevated: !0,
								mark: M === n ? "keep" : P === n ? "deeper" : void 0
							})
						}, `${t}:${n}`))]
					}), /* @__PURE__ */ v("div", {
						className: "ll-action-side",
						children: [/* @__PURE__ */ _("p", { children: /* @__PURE__ */ _("strong", { children: f("games.loveletter.chancellorPick") }) }), /* @__PURE__ */ _("button", {
							type: "button",
							className: "ll-play-button",
							disabled: M === null || P === null,
							onClick: ue,
							children: f("games.loveletter.confirm")
						})]
					})] }) : /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("div", {
						className: "ll-hand-cards",
						children: [/* @__PURE__ */ _("span", {
							ref: h,
							className: "ll-fx-hand-anchor",
							style: { "--ll-hand-index": ee ? O : S ?? 0 },
							"aria-hidden": !0
						}), x.map((t, n) => /* @__PURE__ */ _("button", {
							type: "button",
							disabled: !y || se && t !== "countess",
							"aria-label": y ? f("games.loveletter.playCardAria", { card: f(I[t]) }) : f(I[t]),
							"aria-pressed": S === n,
							onClick: () => {
								C((e) => e === n ? null : n), T(null), D(null);
							},
							children: /* @__PURE__ */ _(q, {
								role: t,
								edition: e.edition,
								size: "hand",
								elevated: !0,
								selected: S === n
							})
						}, `${t}:${n}`))]
					}), /* @__PURE__ */ v("div", {
						className: "ll-action-side",
						children: [/* @__PURE__ */ v("p", { children: [/* @__PURE__ */ _("strong", { children: f(B && y ? I[B] : y ? "games.loveletter.awaitCard" : "games.loveletter.awaitTurn") }), B && y ? H && !w ? f("games.loveletter.selectTarget") : B === "guard" && w && E ? /* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => D(null),
							children: f("games.loveletter.changeGuess", { card: f(I[E]) })
						}) : f(te[B]) : f("games.loveletter.awaitHint")] }), /* @__PURE__ */ _("button", {
							type: "button",
							className: "ll-play-button",
							disabled: !y || !U,
							onClick: le,
							children: B ? f("games.loveletter.playNamed", { card: f(I[B]) }) : f("games.loveletter.playLetter")
						})]
					})] })
				})]
			}),
			children: /* @__PURE__ */ _(Me, {
				pub: e,
				members: n,
				myRid: r,
				picking: y && H ? {
					eligible: ce,
					target: w,
					onPick: (e) => {
						T((t) => t === e ? null : e), D(null);
					}
				} : null,
				guardGuess: y && B === "guard" && w ? {
					target: w,
					guess: E,
					onGuess: D
				} : null,
				reveal: t?.reveal && !R ? t.reveal : null,
				onRevealClose: () => z(!0)
			})
		})
	});
}
//#endregion
//#region src/games/loveletter/bot.ts
function Ie() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function X(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Le = {
	princess: 100,
	countess: 88,
	king: 70,
	chancellor: 60,
	prince: 55,
	handmaid: 46,
	baron: 40,
	priest: 34,
	guard: 24,
	spy: 18
};
function Re(e, t, n) {
	let r = e.round === t.round ? {
		...e,
		seen: { ...e.seen }
	} : {
		round: t.round,
		seen: {},
		lastKey: ""
	}, i = t.last;
	if (i) {
		let e = `${t.round}:${JSON.stringify(i)}`;
		if (e !== r.lastKey && (r.lastKey = e, i.kind === "play")) {
			let e = r.seen;
			switch (e[i.rid] === i.card && (e[i.rid] = void 0), i.card) {
				case "king":
					if (i.target) {
						let t = e[i.rid];
						e[i.rid] = e[i.target], e[i.target] = t;
					}
					break;
				case "prince":
					i.target && i.outRid !== i.target && (e[i.target] = void 0);
					break;
				case "chancellor": e[i.rid] = void 0;
			}
		}
	}
	let a = n?.reveal;
	return a && (a.kind === "priest" ? r.seen[a.target] = a.card : r.seen[a.opponent] = a.theirCard), r;
}
function ze(e, t, n, r) {
	let i = /* @__PURE__ */ new Map();
	for (let t of N(e.edition)) i.set(t, (i.get(t) ?? 0) + 1);
	let a = (e) => i.set(e, (i.get(e) ?? 0) - 1);
	for (let e of t?.hand ?? []) a(e);
	for (let t of e.players) for (let e of t.discards) a(e);
	for (let t of e.burnUp) a(t);
	for (let [e, t] of Object.entries(n)) e !== r && t && a(t);
	return i;
}
function Be(e, t, n, r) {
	let i = n[e];
	if (i) return +(i === t);
	let a = [...r.values()].reduce((e, t) => e + t, 0);
	return a > 0 ? (r.get(t) ?? 0) / a : 0;
}
var Ve = (e, t) => {
	let n = e.public, r = e.private;
	if (n.phase !== "play") return null;
	let i = n.players.find((e) => e.rid === t.rid);
	if (!i || i.out) return null;
	let a = Re(t.memory ?? {
		round: n.round,
		seen: {},
		lastKey: ""
	}, n, r), o = r?.hand ?? [];
	if (n.pendingChancellor) {
		if (n.pendingChancellor.rid !== t.rid || !r?.chancellorCards) return null;
		let e = [...r.chancellorCards];
		if (t.difficulty === "weak") {
			let t = X(e);
			return {
				action: {
					type: "chancellorPick",
					keep: t,
					deeper: X(e.filter((n, r) => r !== e.indexOf(t)))
				},
				memory: a
			};
		}
		return e.sort((e, t) => Le[t] - Le[e]), {
			action: {
				type: "chancellorPick",
				keep: e[0],
				deeper: e[1]
			},
			memory: a
		};
	}
	if (n.turn !== t.rid || o.length === 0) return null;
	let s = n.edition, c = M(s), l = n.players.filter((e) => e.rid !== t.rid && !e.out), u = l.filter((e) => !e.protected), d = ze(n, r, a.seen, t.rid), f = (e, t) => Be(e, t, a.seen, d), p = [...l].sort((e, t) => t.tokens - e.tokens)[0], m = n.needTokens > 0 ? ((p?.tokens ?? 0) - i.tokens + 1) / n.needTokens : 0, h = (e) => A[e].needsTarget ? e === "prince" ? [t.rid, ...u.map((e) => e.rid)] : u.map((e) => e.rid) : [], g = (e, t, n) => ({
		type: "play",
		card: e,
		...t ? { target: t } : {},
		...n ? { guess: n } : {}
	});
	if (t.difficulty === "weak") {
		let e = o.includes("countess") && (o.includes("king") || o.includes("prince")) ? "countess" : X(o), t = h(e), n = t.length > 0 ? X(t) : void 0;
		return {
			action: g(e, n, e === "guard" && n ? X(c.filter((e) => e !== "guard")) : void 0),
			memory: a
		};
	}
	let _ = C(S(t.rid)), v = () => (Ie() - .5) * _.noise * 1.6, y = (e) => {
		if (e.length !== 0) return p && _.aggression + Ie() * .5 > .6 && e.includes(p.rid) ? p.rid : X(e);
	}, b = [], x = o.includes("countess") && (o.includes("king") || o.includes("prince"));
	for (let e of o) {
		if (x && e !== "countess") continue;
		let r = o.find((t) => t !== e) ?? e, u = j(r, s), S = (t, n, r) => b.push({
			action: g(e, n, r),
			score: t + v()
		});
		switch (e) {
			case "princess": break;
			case "countess":
				S(1.4);
				break;
			case "spy": {
				let e = i.discards.includes("spy"), t = l.some((e) => e.discards.includes("spy"));
				S(1.3 + (e ? .5 : 0) + (t ? _.cunning * .9 : .4));
				break;
			}
			case "handmaid":
				S(1 + Le[r] / 60 + Math.max(0, l.length - 2) * .2);
				break;
			case "guard": {
				let e = h("guard");
				if (e.length === 0) {
					S(.6);
					break;
				}
				let t = null;
				for (let n of e) for (let e of c) {
					if (e === "guard") continue;
					let r = f(n, e);
					(!t || r > t.p) && (t = {
						target: n,
						guess: e,
						p: r
					});
				}
				if (!t) break;
				let n = .12 + (1 - _.risk) * .25;
				S(t.p > n ? 1.2 + t.p * 3 * (.6 + _.aggression * .8) + m * _.compete : .5, t.target, t.guess);
				break;
			}
			case "priest": {
				let e = y(h("priest"));
				S(1.1 + _.cunning * 1.3, e);
				break;
			}
			case "baron": {
				let e = h("baron");
				if (e.length === 0) {
					S(.5);
					break;
				}
				let t = -99, n;
				for (let r of e) {
					let e = 0, i = 0;
					for (let t of c) {
						let n = f(r, t), a = j(t, s);
						a < u ? e += n : a > u && (i += n);
					}
					let a = 2 * (e - i * (.4 + _.risk)) + _.aggression * .5;
					a > t && (t = a, n = r);
				}
				S(t, n);
				break;
			}
			case "prince": {
				let e = -Infinity, n;
				for (let i of h("prince")) {
					let o = i === t.rid ? r : a.seen[i], c;
					c = i === t.rid ? o !== "princess" && Le[r] < 30 ? 1.5 : -99 : o === "princess" ? 6 : o && j(o, s) >= 6 ? 2.5 : .4 + _.aggression * .9 - (1 - _.risk) * .2 + (p?.rid === i ? m * _.compete : 0), c > e && (e = c, n = i);
				}
				S(e, n);
				break;
			}
			case "king": {
				let e = h("king");
				if (e.length === 0) {
					S(.4);
					break;
				}
				let t = 0, n = 0;
				for (let e of c) {
					let r = d.get(e) ?? 0;
					t += r, n += r * j(e, s);
				}
				let r = t > 0 ? n / t : 3.5, i = -99, o;
				for (let t of e) {
					let e = a.seen[t], n = (e ? j(e, s) : r) - u, c = .5 + n * .4 + _.cunning * .3 - (n < 0 ? (1 - _.risk) * 1.5 : 0);
					c > i && (i = c, o = t);
				}
				o && a.seen[o] === "princess" && (i = 7), S(i, o);
				break;
			}
			case "chancellor":
				if (n.deckCount < 1) {
					S(.2);
					break;
				}
				S(2.1 + _.greed * .5 - Le[r] / 90);
				break;
			default: S(.5);
		}
	}
	if (b.length === 0) return {
		action: g(o[0], h(o[0])[0]),
		memory: a
	};
	b.sort((e, t) => t.score - e.score);
	let w = b[0];
	if (w.action.type === "play" && w.action.card === "king" && w.action.target) {
		let e = o.find((e) => e !== "king");
		e && (a.seen[w.action.target] = e);
	}
	return {
		action: w.action,
		memory: a
	};
}, He = (e, t, n) => e.type === "chancellorPick" ? n("games.loveletter.hintChancellor", {
	keep: n(I[e.keep]),
	deeper: n(I[e.deeper])
}) : e.type === "play" ? e.card === "guard" && e.guess ? n("games.loveletter.hintGuard", { guess: n(I[e.guess]) }) : n("games.loveletter.playCardAria", { card: n(I[e.card]) }) : "", Ue = {
	spy: "间谍",
	guard: "卫兵",
	priest: "牧师",
	baron: "男爵",
	handmaid: "侍女",
	prince: "王子",
	chancellor: "大臣",
	king: "国王",
	countess: "女伯爵",
	princess: "公主"
}, We = {
	spy: "无效果;回合结束时若全场只有你打出/弃过间谍,+1 好感",
	guard: "猜一名玩家的手牌(不能猜卫兵),猜中对方出局",
	priest: "偷看一名玩家的手牌",
	baron: "与一名玩家暗比手牌点数,小者出局",
	handmaid: "直到你的下个回合,其他玩家不能指定你",
	prince: "指定一名玩家(可以是自己)弃掉手牌重摸一张;被逼弃公主会直接出局",
	chancellor: "再摸 2 张,留 1 张,其余按自选顺序压回牌库底",
	king: "与一名玩家交换手牌",
	countess: "无效果;但手里同时有国王或王子时必须打出她",
	princess: "打出或弃掉她的人直接出局"
}, Ge = {
	needsAction(e, t) {
		let n = e.public;
		return n.phase === "play" ? n.pendingChancellor ? n.pendingChancellor.rid === t.rid : n.turn === t.rid : !1;
	},
	describeView(e, t) {
		let n = e.public, r = (e) => `${e}(${Ue[e]},点数 ${j(e, n.edition)})`, i = [`第 ${n.round} 局,先集满 ${n.needTokens} 个好感标记获胜。牌堆剩 ${n.deckCount} 张。角色一律用英文枚举值输出。`];
		i.push("角色一览: " + Object.keys(A).filter((e) => A[e].count[n.edition] > 0).map((e) => `${r(e)}——${We[e]}`).join(";")), n.burnUp.length && i.push(`开局明烧(2 人局公开): ${n.burnUp.map(r).join(", ")}`), i.push("玩家:");
		for (let e of n.players) {
			let n = e.rid === t.rid ? "你" : e.rid, a = [e.out ? "已出局" : null, e.protected ? "侍女保护中" : null].filter(Boolean).join(",");
			i.push(`  ${n}: ${e.tokens} 标记,手牌 ${e.handCount} 张${a ? `,${a}` : ""};弃牌堆: ${e.discards.map(r).join(", ") || "(无)"}`);
		}
		let a = e.private;
		return n.pendingChancellor?.rid === t.rid && a?.chancellorCards ? i.push(`你打出了大臣,候选牌: ${a.chancellorCards.map(r).join(", ")}。选 1 张留下(keep)、1 张压到牌库最底(deeper),输出 chancellorPick 行动。`) : a && (a.reveal && (a.reveal.kind === "priest" ? i.push(`(情报)你偷看到 ${a.reveal.target} 的手牌是 ${r(a.reveal.card)}。`) : i.push(`(情报)男爵比牌:你的 ${r(a.reveal.myCard)} vs 对方的 ${r(a.reveal.theirCard)},${a.reveal.iWon === null ? "平手" : a.reveal.iWon ? "你赢了" : "你输了"}。`)), i.push(`你的手牌: ${a.hand.map(r).join(", ")}。打出一张(play),需要时带 target(玩家 rid)和 guess(卫兵猜的角色)。`)), i.join("\n");
	},
	actionJsonSchema: { oneOf: [{
		type: "object",
		properties: {
			type: { const: "play" },
			card: { enum: [
				"spy",
				"guard",
				"priest",
				"baron",
				"handmaid",
				"prince",
				"chancellor",
				"king",
				"countess",
				"princess"
			] },
			target: {
				type: "string",
				description: "目标玩家 rid;卫兵/牧师/男爵/王子/国王必填"
			},
			guess: {
				enum: [
					"spy",
					"priest",
					"baron",
					"handmaid",
					"prince",
					"chancellor",
					"king",
					"countess",
					"princess"
				],
				description: "仅卫兵:猜的角色,不能是 guard"
			}
		},
		required: ["type", "card"],
		additionalProperties: !1
	}, {
		type: "object",
		properties: {
			type: { const: "chancellorPick" },
			keep: { enum: [
				"spy",
				"guard",
				"priest",
				"baron",
				"handmaid",
				"prince",
				"chancellor",
				"king",
				"countess",
				"princess"
			] },
			deeper: { enum: [
				"spy",
				"guard",
				"priest",
				"baron",
				"handmaid",
				"prince",
				"chancellor",
				"king",
				"countess",
				"princess"
			] }
		},
		required: [
			"type",
			"keep",
			"deeper"
		],
		additionalProperties: !1
	}] },
	parseAction(e, t, n) {
		let r = V.safeParse(e);
		if (!r.success) return null;
		let i = r.data;
		if (i.type === "tick") return null;
		let a = t.public;
		if (a.phase !== "play") return null;
		if (i.type === "chancellorPick") {
			if (a.pendingChancellor?.rid !== n.rid) return null;
			let e = [...t.private?.chancellorCards ?? []];
			for (let t of [i.keep, i.deeper]) {
				let n = e.indexOf(t);
				if (n < 0) return null;
				e.splice(n, 1);
			}
			return i;
		}
		if (a.turn !== n.rid || a.pendingChancellor) return null;
		let o = t.private?.hand ?? [];
		if (!o.includes(i.card) || ue(o) && i.card !== "countess") return null;
		if (A[i.card].needsTarget) {
			if (!i.target) return null;
			let e = a.players.filter((e) => e.protected).map((e) => e.rid), t = a.players.filter((e) => !e.out).map((e) => e.rid).filter((t) => t !== n.rid && !e.includes(t));
			if (!(i.card === "prince" ? [n.rid, ...t] : t).includes(i.target)) return null;
		}
		return i.card === "guard" && (!i.guess || i.guess === "guard") ? null : i;
	}
}, Ke = (e) => e === "classic" ? "classic" : "modern", Z = (e) => typeof e == "string" ? e : null, Q = (e) => ({
	x: e.x + e.w / 2,
	y: e.y + e.h / 2
}), qe = (e) => e.w >= 600 && e.h >= 360 ? Math.max(1.35, Math.min(2.4, e.w / 430, e.h / 280)) : 1, $ = (e) => e.w > 64 || e.h > 90 ? Y(Math.min(e.w, e.h * .71), Math.min(e.w / .71, e.h)) : void 0;
function Je({ from: e, stage: t, to: n, card: a, edition: o }) {
	let s = i(null);
	return r(() => {
		let r = s.current;
		if (!r) return;
		let i = Q(e), a = Q(t), o = Q(n), c = Math.min(.74, Math.max(.3, Math.min(e.w / t.w, e.h / t.h))), l = Math.min(n.w / t.w, n.h / t.h), u = r.animate([
			{
				transform: `translate(${i.x - a.x}px, ${i.y - a.y}px) scale(${c})`,
				opacity: .85,
				offset: 0
			},
			{
				transform: "translate(0, -9px) scale(1.04)",
				opacity: 1,
				offset: .29
			},
			{
				transform: "translate(0, -9px) scale(1.04)",
				opacity: 1,
				offset: .76
			},
			{
				transform: `translate(${o.x - a.x}px, ${o.y - a.y}px) scale(${l})`,
				opacity: 1,
				offset: 1
			}
		], {
			duration: U.show,
			easing: "cubic-bezier(.28,.7,.2,1)",
			fill: "both"
		});
		return () => u.cancel();
	}, [
		e,
		t,
		n
	]), /* @__PURE__ */ _("div", {
		ref: s,
		className: "absolute",
		style: {
			left: t.x,
			top: t.y,
			width: t.w,
			height: t.h,
			transformOrigin: "center"
		},
		children: /* @__PURE__ */ _(q, {
			role: a,
			edition: o,
			size: "featured",
			style: Y(t.w, t.h)
		})
	});
}
function Ye({ from: e, target: t, table: n, guess: r, hit: i, edition: a }) {
	let o = Q(e), s = Q(t), c = qe(n), l = Math.max(n.x + 43 * c, Math.min(n.x + n.w - 43 * c, s.x)), u = Math.max(n.y + 99 * c, Math.min(n.y + n.h - 87 * c, s.y + 54 * c));
	return /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("svg", {
		className: "ll-fx-guard-line",
		"aria-hidden": !0,
		children: /* @__PURE__ */ _("path", { d: `M ${o.x} ${o.y} Q ${(o.x + s.x) / 2} ${Math.min(o.y, s.y) - 42} ${s.x} ${s.y}` })
	}), /* @__PURE__ */ v("div", {
		className: "ll-fx-guard-target",
		style: {
			left: l,
			top: u
		},
		children: [
			/* @__PURE__ */ _(q, {
				role: r,
				edition: a,
				size: "ledger",
				style: c > 1 ? Y(58 * c, 82 * c) : void 0
			}),
			/* @__PURE__ */ _("span", {
				className: "ll-fx-guard-question",
				style: {
					width: 22 * c,
					height: 22 * c,
					fontSize: 15 * c
				},
				children: "?"
			}),
			/* @__PURE__ */ _("span", {
				className: `ll-fx-guard-result ${i ? "ll-fx-hit" : "ll-fx-miss"}`,
				style: {
					width: 31 * c,
					height: 31 * c,
					fontSize: 19 * c
				},
				children: i ? "✓" : "✕"
			})
		]
	})] });
}
function Xe({ table: e, mine: t, theirs: n, edition: r, loser: i, actor: a, target: o }) {
	let s = Q(e), c = i === a ? 9 : i === o ? -9 : 0, l = qe(e), u = l > 1 ? Y(58 * l, 82 * l) : void 0;
	return /* @__PURE__ */ v("div", {
		className: "ll-fx-baron",
		style: {
			left: s.x,
			top: s.y,
			width: 188 * l,
			"--ll-baron-tilt": `${c}deg`
		},
		children: [/* @__PURE__ */ v("div", {
			className: "ll-fx-baron-beam",
			style: {
				height: 95 * l,
				paddingInline: 10 * l
			},
			children: [/* @__PURE__ */ _("span", {
				style: {
					width: 60 * l,
					minHeight: 82 * l
				},
				children: t ? /* @__PURE__ */ _(q, {
					role: t,
					edition: r,
					size: "ledger",
					style: u
				}) : /* @__PURE__ */ _(J, {
					size: "deck",
					style: u
				})
			}), /* @__PURE__ */ _("span", {
				style: {
					width: 60 * l,
					minHeight: 82 * l
				},
				children: n ? /* @__PURE__ */ _(q, {
					role: n,
					edition: r,
					size: "ledger",
					style: u
				}) : /* @__PURE__ */ _(J, {
					size: "deck",
					style: u
				})
			})]
		}), /* @__PURE__ */ _("div", { className: "ll-fx-baron-pivot" })]
	});
}
function Ze({ from: e, target: t, table: n, to: r, dropped: i, edition: a }) {
	let o = Q(n), s = qe(n), c = {
		x: o.x - 32 * s,
		y: o.y - 45 * s,
		w: 64 * s,
		h: 90 * s
	}, l = s > 1 ? Y(c.w, c.h) : void 0, u = s > 1 ? Y(126 * s, 126 / .71 * s) : void 0;
	return /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _(T, {
			from: e,
			to: t,
			ms: 850,
			children: /* @__PURE__ */ _("span", {
				className: "ll-fx-prince-seal",
				"aria-hidden": !0,
				children: "♛"
			})
		}),
		/* @__PURE__ */ _(T, {
			from: t,
			to: c,
			ms: 800,
			delay: 550,
			children: /* @__PURE__ */ _("span", {
				className: "ll-fx-prince-arrival",
				children: /* @__PURE__ */ _(q, {
					role: i,
					edition: a,
					size: "ledger",
					style: $(t)
				})
			})
		}),
		/* @__PURE__ */ _("div", {
			className: "ll-fx-prince-reveal",
			style: {
				left: o.x,
				top: o.y
			},
			children: /* @__PURE__ */ _(q, {
				role: i,
				edition: a,
				size: "featured",
				style: u
			})
		}),
		r && /* @__PURE__ */ _(T, {
			from: c,
			to: r,
			ms: 750,
			delay: 1850,
			children: /* @__PURE__ */ _("span", {
				className: "ll-fx-prince-departure",
				children: /* @__PURE__ */ _(q, {
					role: i,
					edition: a,
					size: "small",
					style: l
				})
			})
		})
	] });
}
var Qe = {
	roundStart(e, t) {
		let n = t.anchor("deck");
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ _(E, {
				at: n,
				ms: 900
			})
		} : null;
	},
	draw(e, t) {
		let n = t.anchor("deck"), r = e.rid ? t.anchor(`disc:${e.rid}`) : null;
		if (!n || !r) return null;
		let i = Z(e.secret?.card);
		return {
			ms: 900,
			node: /* @__PURE__ */ _(T, {
				from: n,
				to: r,
				ms: 800,
				children: i ? /* @__PURE__ */ _(q, {
					role: i,
					edition: Ke(e.data?.edition),
					size: "small",
					style: $(n)
				}) : /* @__PURE__ */ _(J, { style: $(n) })
			})
		};
	},
	playShow(e, t) {
		let n = e.data, r = Z(n?.card), i = e.rid, a = i ? t.anchor(`disc:${i}`) : null, o = t.anchor("showcase"), s = i ? t.anchor(`discTop:${i}`) : null;
		if (!r || !i || !a || !o || !s) return null;
		let c = t.myRid === i ? t.anchor(`hand:${i}`) ?? a : a;
		return {
			ms: U.show,
			hide: t.queued ? [] : ["showcase", `discTop:${i}`],
			node: /* @__PURE__ */ _(Je, {
				from: c,
				stage: o,
				to: s,
				card: r,
				edition: Ke(n?.edition)
			})
		};
	},
	playEffect(e, t) {
		let n = e.data, r = Z(n?.card), i = e.rid, a = i ? t.anchor(`disc:${i}`) : null;
		if (!r || !i || !a) return null;
		let o = Ke(n?.edition), s = typeof n?.target == "string" ? n.target : null, c = s ? t.anchor(`disc:${s}`) : null, l = t.anchor("table"), u = Z(n?.guess), d = typeof n?.outRid == "string" ? n.outRid : null, f = Z(n?.dropped), p = e.secret, m = Z(p?.peek), h = Z(p?.mine), y = Z(p?.theirs), b = h !== null && y !== null && (t.myRid === i || t.myRid === s), x = U.effect(r);
		if (r === "guard" && c && u && l) return {
			ms: x,
			node: /* @__PURE__ */ _(Ye, {
				from: a,
				target: c,
				table: l,
				guess: u,
				hit: d === s,
				edition: o
			})
		};
		if (r === "baron" && c && s && l) return {
			ms: x,
			node: /* @__PURE__ */ _(Xe, {
				table: l,
				mine: b ? h : null,
				theirs: b ? y : null,
				edition: o,
				loser: d,
				actor: i,
				target: s
			})
		};
		if (r === "prince" && c && s && f && l) {
			let e = t.anchor(`discTop:${s}`);
			return {
				ms: x,
				hide: e && !t.queued ? [`discTop:${s}`] : [],
				node: /* @__PURE__ */ _(Ze, {
					from: a,
					target: c,
					table: l,
					to: e,
					dropped: f,
					edition: o
				})
			};
		}
		if (r === "priest" && c) return {
			ms: x,
			node: /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(E, {
				at: c,
				ms: 1500
			}), /* @__PURE__ */ _(w, {
				at: c,
				ms: 1700,
				children: m ? /* @__PURE__ */ _(q, {
					role: m,
					edition: o,
					size: "ledger",
					style: l && qe(l) > 1 ? Y(58 * qe(l), 82 * qe(l)) : void 0
				}) : /* @__PURE__ */ _("span", {
					className: "text-3xl",
					"aria-hidden": !0,
					children: "🕯️"
				})
			})] })
		};
		if (r === "king" && c) {
			let e = b ? t.myRid === i ? y : h : null, n = b ? t.myRid === i ? h : y : null;
			return {
				ms: x,
				node: /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(T, {
					from: c,
					to: a,
					ms: 1800,
					children: e ? /* @__PURE__ */ _(q, {
						role: e,
						edition: o,
						size: "small",
						style: $(c)
					}) : /* @__PURE__ */ _(J, { style: $(c) })
				}), /* @__PURE__ */ _(T, {
					from: a,
					to: c,
					ms: 1800,
					children: n ? /* @__PURE__ */ _(q, {
						role: n,
						edition: o,
						size: "small",
						style: $(a)
					}) : /* @__PURE__ */ _(J, { style: $(a) })
				})] })
			};
		}
		if (r === "chancellor") {
			let e = t.anchor("deck");
			return e ? {
				ms: x,
				node: /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(T, {
					from: e,
					to: a,
					ms: 1300,
					children: /* @__PURE__ */ _(J, { style: $(e) })
				}), /* @__PURE__ */ _(T, {
					from: e,
					to: a,
					ms: 1300,
					delay: 350,
					children: /* @__PURE__ */ _(J, { style: $(e) })
				})] })
			} : null;
		}
		return r === "handmaid" ? {
			ms: x,
			node: /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(E, {
				at: a,
				ms: 1400
			}), /* @__PURE__ */ _(w, {
				at: a,
				ms: 1500,
				children: /* @__PURE__ */ _("span", {
					className: "text-3xl",
					"aria-hidden": !0,
					children: "🛡️"
				})
			})] })
		} : {
			ms: x,
			node: /* @__PURE__ */ _(w, {
				at: a,
				ms: Math.min(x, 1500),
				children: /* @__PURE__ */ _("span", {
					className: "text-3xl",
					"aria-hidden": !0,
					children: A[r].emoji
				})
			})
		};
	},
	princeDraw(e, t) {
		let n = e.data, r = t.anchor(n?.fromBurn ? "burn" : "deck"), i = e.rid ? t.anchor(`disc:${e.rid}`) : null;
		if (!r || !i) return null;
		let a = Z(e.secret?.card);
		return {
			ms: U.princeDraw,
			node: /* @__PURE__ */ _(T, {
				from: r,
				to: i,
				ms: U.princeDraw - 150,
				children: a ? /* @__PURE__ */ _(q, {
					role: a,
					edition: Ke(n?.edition),
					size: "small",
					style: $(r)
				}) : /* @__PURE__ */ _(J, { style: $(r) })
			})
		};
	},
	out(e, t) {
		let n = e.rid ? t.anchor(`disc:${e.rid}`) : null;
		return n ? (navigator.vibrate?.(160), {
			ms: U.out,
			node: /* @__PURE__ */ _(w, {
				at: n,
				ms: U.out - 50,
				children: /* @__PURE__ */ _("span", {
					"aria-hidden": !0,
					className: "text-3xl",
					style: { fontSize: Math.max(30, n.w * .75) },
					children: "💔"
				})
			})
		}) : null;
	},
	token(e, t) {
		let n = e.rid ? t.anchor(`disc:${e.rid}`) : null;
		return n ? {
			ms: 1300,
			node: /* @__PURE__ */ _(w, {
				at: n,
				ms: 1200,
				children: /* @__PURE__ */ _("span", {
					className: "font-bold",
					style: {
						color: "#db2777",
						fontSize: Math.max(14, n.w * .5)
					},
					children: "+1💌"
				})
			})
		} : null;
	},
	roundEnd(e, t) {
		let n = t.anchor("table");
		return n ? {
			ms: 1e3,
			node: /* @__PURE__ */ _(E, {
				at: n,
				ms: 1e3
			})
		} : null;
	}
}, $e = .71, et = 96, tt = 240;
function nt(e, t) {
	let n = 0, r = 0, i = 0;
	for (let a of e.labelParts) r && r + e.labelColumnGap + a.width > t && (n += i + e.labelRowGap, r = 0, i = 0), r += (r ? e.labelColumnGap : 0) + a.width, i = Math.max(i, a.height);
	return n + i + e.labelMargin;
}
function rt(e, t, n, r, i, a) {
	let o = (n, o, s) => {
		let c = e.map((e, t) => e.count ? o[t] * n + (o[t] - 1) * i : 0), l = e.map((e) => Math.max(...e.labelParts.map((e) => e.width))), u = Math.max(c[0], l[0]), d = s ? [u, t - u - r] : e.map(() => t), f = d.every((e, t) => e >= Math.max(c[t], l[t])), p = e.map((e, t) => {
			let r = Math.ceil(e.count / o[t]), i = e.count ? r * n / $e + (r - 1) * a : e.emptyHeight;
			return nt(e, d[t]) + i;
		});
		return {
			fitsWidth: f,
			contentHeight: s ? Math.max(...p) : p.reduce((e, t) => e + t, 0) + r * (e.length - 1),
			groupColumns: s ? `${u}px minmax(0, 1fr)` : "minmax(0, 1fr)"
		};
	}, s = e.map((e) => Array.from({ length: Math.max(1, e.count) }, (e, t) => t + 1)), c = e.length === 2 && e.every((e) => e.count > 0) ? [!1, !0] : [!1], l;
	for (let t of s[0]) for (let r of s[1] ?? [1]) {
		let i = e.length === 2 ? [t, r] : [t];
		for (let e of c) {
			let t = o(et, i, e);
			if (!t.fitsWidth) continue;
			let r = t.contentHeight <= n, a = et, s = tt;
			if (r) for (let t = 0; t < 18; t++) {
				let t = (a + s) / 2, r = o(t, i, e);
				r.fitsWidth && r.contentHeight <= n ? a = t : s = t;
			}
			let c = Math.floor(a * 100) / 100, u = o(c, i, e), d = {
				cardWidth: c,
				columns: i,
				contentHeight: u.contentHeight,
				groupColumns: u.groupColumns,
				fitsHeight: r
			};
			(!l || r && !l.fitsHeight || r && l.fitsHeight && (c > l.cardWidth || c === l.cardWidth && d.contentHeight < l.contentHeight) || !r && !l.fitsHeight && d.contentHeight < l.contentHeight) && (l = d);
		}
	}
	return l;
}
function it({ pub: e, nameOf: t }) {
	let n = c(), a = s((e) => e.locale), o = i(null);
	return r(() => {
		let e = o.current;
		if (!e) return;
		let t = [...e.querySelectorAll(".ll-over-seat")], n = (e) => Number.parseFloat(e) || 0, r = (e, t, n) => {
			e.style.getPropertyValue(t) !== n && e.style.setProperty(t, n);
		}, i = () => {
			if (getComputedStyle(e).getPropertyValue("--ll-over-fit").trim() !== "1") {
				for (let e of t) {
					for (let t of [
						"--ll-over-seat-h",
						"--ll-card-w",
						"--ll-over-group-columns"
					]) e.style.removeProperty(t);
					for (let t of e.querySelectorAll(".ll-over-card-group")) t.style.removeProperty("--ll-over-card-columns");
				}
				return;
			}
			let i = getComputedStyle(e), a = Math.ceil(t.length / 2), o = e.clientHeight - n(i.paddingTop) - n(i.paddingBottom), s = Math.max(t.length > 2 ? 350 : 0, (o - n(i.rowGap) * (a - 1)) / a), c = t.map((e) => {
				let t = getComputedStyle(e), r = e.querySelector("h3"), i = getComputedStyle(r), a = [...e.querySelectorAll(".ll-over-card-group")], o = getComputedStyle(e.querySelector(".ll-over-seat-groups")), c = getComputedStyle(a[0].querySelector(".ll-over-cards")), l = n(t.paddingTop) + n(t.paddingBottom) + n(t.borderTopWidth) + n(t.borderBottomWidth) + r.getBoundingClientRect().height + n(i.marginTop) + n(i.marginBottom), u = e.clientWidth - n(t.paddingLeft) - n(t.paddingRight), d = a.map((e) => {
					let t = e.querySelector("h4"), r = getComputedStyle(t);
					return {
						count: Number(e.dataset.count),
						labelParts: [...t.children].map((e) => ({
							width: e.getBoundingClientRect().width,
							height: e.getBoundingClientRect().height
						})),
						labelColumnGap: n(r.columnGap),
						labelRowGap: n(r.rowGap),
						labelMargin: n(r.marginTop) + n(r.marginBottom),
						emptyHeight: e.querySelector("p")?.getBoundingClientRect().height ?? 0
					};
				}), f = (e) => rt(d, u, e - l, n(o.columnGap), n(c.columnGap), n(c.rowGap));
				return {
					player: e,
					groupElements: a,
					frameHeight: l,
					fit: f,
					layout: f(s)
				};
			});
			for (let e = 0; e < c.length; e += 2) {
				let t = c.slice(e, e + 2), n = Math.max(s, ...t.map((e) => (e.layout?.contentHeight ?? 0) + e.frameHeight));
				for (let e of t) {
					let t = e.fit(n);
					t && (r(e.player, "--ll-over-seat-h", `${Math.ceil(n * 100) / 100}px`), r(e.player, "--ll-card-w", `${t.cardWidth}px`), r(e.player, "--ll-over-group-columns", t.groupColumns), e.groupElements.forEach((e, n) => r(e, "--ll-over-card-columns", String(t.columns[n]))));
				}
			}
		};
		i();
		let a = new ResizeObserver(i);
		a.observe(e);
		for (let t of e.querySelectorAll("h3, h4 > span, .ll-over-cards p")) a.observe(t);
		return () => a.disconnect();
	}, [
		e.players,
		e.revealHands,
		a
	]), /* @__PURE__ */ _("div", {
		ref: o,
		className: "ll-over-seats",
		children: e.players.map((r) => {
			let i = e.revealHands?.[r.rid] ?? [];
			return /* @__PURE__ */ v("section", {
				className: "ll-over-seat",
				children: [/* @__PURE__ */ v("h3", { children: [t(r.rid), r.out && /* @__PURE__ */ _("small", { children: n("games.loveletter.seatOut") })] }), /* @__PURE__ */ v("div", {
					className: "ll-over-seat-groups",
					children: [i.length > 0 && /* @__PURE__ */ v("div", {
						className: "ll-over-card-group",
						"data-count": i.length,
						children: [/* @__PURE__ */ _("h4", { children: /* @__PURE__ */ _("span", { children: n("games.loveletter.handReveal") }) }), /* @__PURE__ */ _("div", {
							className: "ll-over-cards",
							children: i.map((t, n) => /* @__PURE__ */ _(q, {
								role: t,
								edition: e.edition,
								size: "ledger"
							}, `${t}:${n}`))
						})]
					}), /* @__PURE__ */ v("div", {
						className: "ll-over-card-group",
						"data-count": r.discards.length,
						children: [/* @__PURE__ */ v("h4", { children: [/* @__PURE__ */ _("span", { children: n("games.loveletter.resultDiscards") }), /* @__PURE__ */ _("span", { children: n("games.loveletter.ledgerCount", { n: r.discards.length }) })] }), /* @__PURE__ */ _("div", {
							className: "ll-over-cards",
							children: r.discards.length ? r.discards.map((t, n) => /* @__PURE__ */ _(q, {
								role: t,
								edition: e.edition,
								size: "ledger"
							}, `${t}:${n}`)) : /* @__PURE__ */ _("p", { children: n("games.loveletter.ledgerEmpty") })
						})]
					})]
				})]
			}, r.rid);
		})
	});
}
function at({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let o = c(), l = s((e) => e.locale), u = t, p = u.last?.kind === "roundEnd" ? u.last : null, m = i ?? a, h = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? d(t, l) : e;
	}, g = (e) => e.map(h).join(l === "zh" ? "、" : ", ");
	return /* @__PURE__ */ _("div", {
		className: "ll-over",
		"data-count": e.ranking.length,
		style: { "--ll-result-count": e.ranking.length },
		children: /* @__PURE__ */ v("div", {
			className: "ll-over-layout",
			children: [
				e.winner.length > 0 && /* @__PURE__ */ _(D, {}),
				/* @__PURE__ */ v("h1", {
					className: "ll-over-title",
					children: [/* @__PURE__ */ _(Se, {
						size: 32,
						color: L.accent
					}), o("session.result.title")]
				}),
				/* @__PURE__ */ v("div", {
					className: "ll-over-body",
					children: [/* @__PURE__ */ v("section", {
						className: "ll-over-ranking",
						children: [/* @__PURE__ */ _("h2", { children: o("games.loveletter.resultRanking") }), /* @__PURE__ */ _("ol", { children: e.ranking.map((t, i) => {
							let a = n.find((e) => e.rid === t), s = e.scores?.[t] ?? u.players.find((e) => e.rid === t)?.tokens ?? 0, c = e.winner.includes(t), l = e.autopilot?.[t];
							return /* @__PURE__ */ v("li", {
								className: "ll-over-player",
								"data-winner": c,
								children: [
									/* @__PURE__ */ _("span", {
										className: "ll-over-rank",
										children: c ? "🏆" : i + 1
									}),
									/* @__PURE__ */ _("span", {
										className: "ll-over-avatar",
										style: { backgroundColor: x[(a?.colorIndex ?? 0) % x.length].hex },
										children: a && /* @__PURE__ */ _("img", {
											src: y[a.avatar % y.length],
											alt: "",
											draggable: !1
										})
									}),
									/* @__PURE__ */ v("div", {
										className: "ll-over-person",
										children: [
											/* @__PURE__ */ v("strong", { children: [h(t), t === r && /* @__PURE__ */ _("small", { children: o("lobby.you") })] }),
											/* @__PURE__ */ v("span", {
												className: "ll-over-tokens",
												"aria-label": o("games.loveletter.tokensAria", { n: s }),
												children: [
													/* @__PURE__ */ _("b", {
														"aria-hidden": !0,
														children: "♥"
													}),
													/* @__PURE__ */ _("strong", { children: s }),
													/* @__PURE__ */ _("small", { children: o("games.loveletter.goalCount", { n: u.needTokens }) })
												]
											}),
											/* @__PURE__ */ _("progress", {
												value: s,
												max: u.needTokens,
												"aria-label": o("games.loveletter.tokensAria", { n: s })
											}),
											l !== void 0 && l > 0 && /* @__PURE__ */ v("small", {
												className: "ll-over-autopilot",
												children: [/* @__PURE__ */ _(f, { size: 14 }), o("session.autopilot.share", { n: Math.round(l * 100) })]
											})
										]
									})
								]
							}, t);
						}) })]
					}), /* @__PURE__ */ v("section", {
						className: "ll-over-round",
						children: [
							/* @__PURE__ */ v("h2", { children: [o("games.loveletter.resultFinalRound"), /* @__PURE__ */ _("small", { children: o("games.loveletter.roundNumber", { n: u.round }) })] }),
							p && /* @__PURE__ */ v("div", {
								className: "ll-over-round-summary",
								children: [
									/* @__PURE__ */ _("small", { children: o(p.reason === "deckOut" ? "games.loveletter.reasonDeckOut" : "games.loveletter.reasonLastStanding") }),
									/* @__PURE__ */ _("strong", { children: p.winners.length ? o("games.loveletter.roundWin", { name: g(p.winners) }) : o("games.loveletter.roundNoWin") }),
									p.spyBonus.length > 0 && /* @__PURE__ */ _("span", { children: o("games.loveletter.spyBonus", { name: g(p.spyBonus) }) })
								]
							}),
							/* @__PURE__ */ _(it, {
								pub: u,
								nameOf: h
							})
						]
					})]
				}),
				m ? /* @__PURE__ */ v("div", {
					className: "ll-over-controls safe-b",
					children: [i && /* @__PURE__ */ _("button", {
						type: "button",
						className: "btn-base text-white",
						style: { background: L.accent },
						onClick: i,
						children: o("session.result.playAgain")
					}), a && /* @__PURE__ */ _("button", {
						type: "button",
						className: "btn-quiet",
						onClick: a,
						children: o("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ _("p", {
					className: "ll-over-wait safe-b",
					children: o("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region src/games/loveletter/options.tsx
var ot = [{
	id: "modern",
	labelKey: "games.loveletter.optModern"
}, {
	id: "classic",
	labelKey: "games.loveletter.optClassic"
}];
function st({ value: e, onChange: t }) {
	let n = c(), r = B.safeParse(e), i = r.success ? r.data : B.parse(void 0);
	return /* @__PURE__ */ v("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ _(k, {
			title: n("games.loveletter.optEdition"),
			children: ot.map((e) => /* @__PURE__ */ _(O, {
				name: "loveletter-edition",
				value: e.id,
				checked: i.edition === e.id,
				label: n(e.labelKey),
				hint: n("games.loveletter.optMaxPlayers", { n: F(e.id) }),
				accent: L.accent,
				onChange: () => t({ edition: e.id })
			}, e.id))
		}), /* @__PURE__ */ _("p", {
			className: "text-xs text-ink/70",
			children: n("games.loveletter.optEditionHint")
		})]
	});
}
//#endregion
//#region src/games/loveletter/guide.tsx
function ct() {
	return /* @__PURE__ */ v("div", {
		className: "flex w-full flex-col gap-3",
		children: [/* @__PURE__ */ _(lt, { edition: "modern" }), /* @__PURE__ */ _(lt, { edition: "classic" })]
	});
}
function lt({ edition: e }) {
	let t = c();
	return /* @__PURE__ */ v("section", {
		className: "flex w-full flex-col gap-1.5",
		children: [/* @__PURE__ */ _("p", {
			className: "section-label",
			children: t(e === "modern" ? "games.loveletter.guideModern" : "games.loveletter.guideClassic")
		}), /* @__PURE__ */ _("ul", {
			className: "flex w-full flex-col gap-2",
			children: M(e).map((n) => /* @__PURE__ */ v("li", {
				className: "frame flex items-center gap-3 p-2",
				children: [/* @__PURE__ */ _(q, {
					role: n,
					edition: e,
					size: "hand"
				}), /* @__PURE__ */ v("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ v("p", {
						className: "text-sm font-extrabold",
						children: [t(I[n]), /* @__PURE__ */ v("span", {
							className: "ml-1.5 font-mono text-xs tabular-nums opacity-60",
							children: ["×", A[n].count[e]]
						})]
					}), /* @__PURE__ */ _("p", {
						className: "text-xs leading-5 font-bold opacity-70",
						children: t(te[n])
					})]
				})]
			}, n))
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/loveletter/entry.tsx
var ut = {
	definition: xe,
	View: Ne,
	bot: Ve,
	describe: He,
	llm: Ge,
	fx: Qe,
	OverView: at,
	Options: st,
	Guide: ct,
	locales: {
		zh: {
			name: "情书",
			desc: "把情书递到公主手里:猜牌、比大小、护住自己,活到最后",
			rules: "目标:赢下回合收集好感标记,先集齐目标数的人获胜。\n流程(轮到你):\n· 抽一张牌,从手牌两张中选一张打出并执行效果(各角色效果见下方图鉴)。\n· 女伯爵与国王或王子同在手时,必须打出她。\n回合结束:\n· 牌库耗尽或只剩一人时回合结束:幸存者中手牌最大者获得 1 枚好感标记;平手比弃牌点数总和,再平则无人得分。\n· 新版中,回合结束时若全场只有你打出或弃过间谍,额外获得 1 枚好感标记。\n获胜所需标记:\n· 经典版(2~4 人):2 人 7 枚,3 人 5 枚,4 人 4 枚。\n· 新版(2~6 人):2 人 6 枚,3 人 5 枚,4 人 4 枚,5~6 人 3 枚。\n新版牌面点数：国王为 7，女伯爵为 8，公主为 9。",
			optEdition: "版本",
			optModern: "新版 2-6 人",
			optClassic: "经典版 2-4 人",
			optMaxPlayers: "最多 {{n}} 人",
			optEditionHint: "新版加入间谍与大臣,人数上限 6;经典版是最初的 16 张牌",
			guideModern: "新版 · 2-6 人",
			guideClassic: "经典版 · 2-4 人",
			roundChip: "第 {{n}} 轮 · {{need}}💌 获胜",
			roundNumber: "第 {{n}} 轮",
			goalCount: "目标 {{n}} ♥",
			resultRanking: "好感总榜",
			resultFinalRound: "最终回合",
			resultDiscards: "本轮弃牌",
			tableTitle: "御前密函",
			tableSubtitle: "{{n}} 位求信者的信桌",
			seatTurn: "行动中",
			seatOut: "淘汰",
			seatProtected: "🛡 保护",
			targetAvailable: "可选",
			targetPicked: "✓ 已选",
			pickTargetAria: "选择 {{name}} 为目标",
			cancelTargetAria: "取消 {{name}} 为目标",
			deckLabel: "牌库",
			burnDownLabel: "暗烧牌",
			logEmpty: "尚无记录",
			logOpen: "记录",
			ledgerTitle: "已出牌",
			ledgerCount: "{{n}} 张",
			ledgerEmpty: "尚未打出",
			ledgerOpenAria: "查看按玩家分类的已出牌，共 {{n}} 张",
			yourHand: "你的手牌",
			chancellorCards: "大臣候选牌",
			stepChancellor: "先选留下，再选压底",
			stepWaiting: "等待行动",
			stepChooseCard: "① 选择要打出的角色",
			stepChooseTarget: "② 点桌上的合法目标",
			stepGuess: "③ 猜目标的手牌",
			stepConfirm: "④ 确认投递",
			awaitCard: "等待选牌",
			awaitTurn: "等待出牌",
			awaitHint: "点一张手牌查看下一步",
			changeGuess: "已猜 {{card}} · 点此修改",
			playNamed: "打出 {{card}}",
			playLetter: "打出密函",
			roundEnding: "回合结束,结算中…",
			resolving: "{{name}} 的出牌结算中…",
			yourTurn: "轮到你:选一张牌打出",
			waiting: "等 {{name}} 出牌…",
			selectTarget: "点选一个目标",
			selectGuess: "猜 {{name}} 的手牌",
			confirm: "打出",
			chancellorPick: "大臣:先点要留下的牌,再点压库底的牌",
			chancellorWait: "等 {{name}} 整理手牌…",
			keepMark: "留下",
			deeperMark: "压底",
			tokensAria: "{{n}} 枚好感标记",
			protectedAria: "被侍女保护中",
			outAria: "已出局",
			deckAria: "牌库还剩 {{n}} 张",
			burnDownAria: "暗烧牌:本局移出的未知牌",
			burnUpAria: "明烧牌:本局移出的公开牌",
			discardsAria: "{{name}} 的弃牌",
			revealPriest: "你偷看了 {{name}} 的手牌:是 {{card}}",
			revealBaronWin: "男爵对决:你赢了,{{name}} 拿着 {{card}}",
			revealBaronLose: "男爵对决:你输了,{{name}} 拿着 {{card}}",
			revealBaronTie: "男爵对决:平手,{{name}} 也拿着 {{card}}",
			dismiss: "知道了",
			playLine: "{{name}} 打出 {{card}}",
			playLineTarget: "{{name}} 对 {{target}} 打出 {{card}}",
			playLineGuess: "{{name}} 猜 {{target}} 是 {{guess}}",
			playLineOut: "{{name}} 出局!",
			playLineMiss: "没猜中",
			logRound: "第 {{n}} 轮",
			logAria: "对局记录",
			reasonLastStanding: "唯一幸存",
			reasonDeckOut: "牌库耗尽,比手牌大小",
			roundWin: "{{name}} 赢下本局 +1💌",
			roundNoWin: "平局,本局无人得分",
			spyBonus: "{{name}} 独占间谍 +1💌",
			handReveal: "幸存手牌",
			playCardAria: "打出 {{card}}",
			errNotYourTurn: "现在轮不到你",
			errBadCard: "手里没有这张牌",
			errBadTarget: "这个目标选不了",
			errBadGuess: "卫兵只能猜非卫兵的牌",
			errCountess: "女伯爵与国王/王子同在手时,必须打出她",
			errBadChancellor: "大臣的留牌选择不对",
			errChancellorPending: "先完成大臣的选牌",
			role: {
				spy: "间谍",
				guard: "卫兵",
				priest: "牧师",
				baron: "男爵",
				handmaid: "侍女",
				prince: "王子",
				chancellor: "大臣",
				king: "国王",
				countess: "女伯爵",
				princess: "公主"
			},
			roleDesc: {
				spy: "打出时无效果。回合结束时,若全场只有你打出或弃过间谍,你额外获得 1 枚好感标记(打出两张也只计一次)",
				guard: "选择一名对手,猜其手牌的角色(不能猜卫兵)。猜中,该对手立即出局;猜错则无事发生",
				priest: "选择一名对手,偷看其手牌。牌面只有你知道",
				baron: "选择一名对手,双方暗中比较手牌点数。点数小的一方立即出局;点数相同则无事发生",
				handmaid: "直到你的下个回合开始,其他玩家不能选择你为卡牌目标",
				prince: "选择一名玩家(可以是自己),其弃掉手牌并抽一张新牌。若因此弃掉的是公主,该玩家立即出局;若牌库已空,改为拿取暗烧牌",
				chancellor: "抽 2 张牌(牌库不足则有多少抽多少),然后从手牌中选 1 张留下,其余按你选择的顺序压回牌库底",
				king: "选择一名对手,与其交换手牌",
				countess: "当女伯爵与国王或王子同在你手中时,你必须打出她。打出本身无效果",
				princess: "只要你打出或弃掉公主,你立即出局"
			},
			hintGuard: "打出卫兵,猜对手是 {{guess}}",
			hintChancellor: "留下 {{keep}},{{deeper}} 压库底"
		},
		en: {
			name: "Love Letter",
			desc: "Get your letter to the princess: guess hands, compare values, stay alive",
			rules: "Goal: win rounds to collect favor tokens; the first to the target wins.\nOn your turn:\n· Draw one card, then play one of your two cards and apply its effect (each role is listed in the gallery below).\n· The Countess must be played while held with the King or the Prince.\nRound end:\n· A round ends when the deck runs out or one player remains: the highest surviving hand earns 1 favor token; ties break on discard-pile total, and a further tie scores nobody.\n· In the new edition, if you alone played or discarded a Spy this round, gain 1 bonus favor token at round end.\nTokens to win:\n· Classic (2–4 players): 7 with 2 players, 5 with 3, 4 with 4.\n· New edition (2–6 players): 6 with 2 players, 5 with 3, 4 with 4, 3 with 5–6.\nCard values in the new edition: the King has value 7, the Countess 8 and the Princess 9.",
			optEdition: "Edition",
			optModern: "2019 · 2-6 players",
			optClassic: "Classic · 2-4 players",
			optMaxPlayers: "Up to {{n}} players",
			optEditionHint: "The 2019 edition adds the Spy and Chancellor and supports 6 players; classic is the original 16 cards",
			guideModern: "2019 edition · 2-6 players",
			guideClassic: "Classic · 2-4 players",
			roundChip: "Round {{n}} · {{need}}💌 to win",
			roundNumber: "Round {{n}}",
			goalCount: "Goal {{n}} ♥",
			resultRanking: "Favor standings",
			resultFinalRound: "Final round",
			resultDiscards: "Round discards",
			tableTitle: "Royal correspondence",
			tableSubtitle: "{{n}} seekers at the court table",
			seatTurn: "Playing",
			seatOut: "Out",
			seatProtected: "🛡 Safe",
			targetAvailable: "Target",
			targetPicked: "✓ Selected",
			pickTargetAria: "Select {{name}} as target",
			cancelTargetAria: "Deselect {{name}} as target",
			deckLabel: "Deck",
			burnDownLabel: "Burn card",
			logEmpty: "No plays yet",
			logOpen: "Log",
			ledgerTitle: "Played cards",
			ledgerCount: "{{n}} cards",
			ledgerEmpty: "None played",
			ledgerOpenAria: "See {{n}} played cards grouped by player",
			yourHand: "Your hand",
			chancellorCards: "Chancellor choices",
			stepChancellor: "Choose one to keep, one for the bottom",
			stepWaiting: "Waiting",
			stepChooseCard: "① Choose a role to play",
			stepChooseTarget: "② Tap an eligible target",
			stepGuess: "③ Guess their hand",
			stepConfirm: "④ Confirm your play",
			awaitCard: "Choose a card",
			awaitTurn: "Waiting for a play",
			awaitHint: "Tap a card to see the next step",
			changeGuess: "Guessing {{card}} · tap to change",
			playNamed: "Play {{card}}",
			playLetter: "Play a letter",
			roundEnding: "Round over, scoring…",
			resolving: "Resolving {{name}}'s play…",
			yourTurn: "Your turn: play a card",
			waiting: "Waiting for {{name}}…",
			selectTarget: "Tap a target",
			selectGuess: "Guess {{name}}'s hand",
			confirm: "Play",
			chancellorPick: "Chancellor: tap the card to keep, then the one to bury deepest",
			chancellorWait: "{{name}} is sorting cards…",
			keepMark: "Keep",
			deeperMark: "Bottom",
			tokensAria: "{{n}} favor tokens",
			protectedAria: "Protected by the Handmaid",
			outAria: "Out of the round",
			deckAria: "{{n}} cards left in the deck",
			burnDownAria: "Face-down burn card",
			burnUpAria: "Face-up burn card",
			discardsAria: "{{name}}'s discards",
			revealPriest: "You peeked at {{name}}'s hand: {{card}}",
			revealBaronWin: "Baron duel: you won — {{name}} held {{card}}",
			revealBaronLose: "Baron duel: you lost — {{name}} held {{card}}",
			revealBaronTie: "Baron duel: a tie — {{name}} also held {{card}}",
			dismiss: "Got it",
			playLine: "{{name}} played {{card}}",
			playLineTarget: "{{name}} played {{card}} on {{target}}",
			playLineGuess: "{{name}} guessed {{target}} has {{guess}}",
			playLineOut: "{{name}} is out!",
			playLineMiss: "miss",
			logRound: "Round {{n}}",
			logAria: "Game log",
			reasonLastStanding: "Last one standing",
			reasonDeckOut: "Deck empty — compare hands",
			roundWin: "{{name}} wins the round +1💌",
			roundNoWin: "Tie — nobody scores",
			spyBonus: "{{name}} alone played the Spy +1💌",
			handReveal: "Surviving hands",
			playCardAria: "Play {{card}}",
			errNotYourTurn: "Not your turn",
			errBadCard: "Card not in hand",
			errBadTarget: "Invalid target",
			errBadGuess: "The Guard must name a non-Guard card",
			errCountess: "The Countess must be played while held with the King or Prince",
			errBadChancellor: "Invalid Chancellor pick",
			errChancellorPending: "Finish the Chancellor pick first",
			role: {
				spy: "Spy",
				guard: "Guard",
				priest: "Priest",
				baron: "Baron",
				handmaid: "Handmaid",
				prince: "Prince",
				chancellor: "Chancellor",
				king: "King",
				countess: "Countess",
				princess: "Princess"
			},
			roleDesc: {
				spy: "No effect when played. At round end, if you are the only player who played or discarded a Spy, gain 1 bonus favor token (playing both copies still counts once)",
				guard: "Choose a rival and name a non-Guard role. If that is their hand, they are out; otherwise nothing happens",
				priest: "Choose a rival and secretly look at their hand. Only you see it",
				baron: "Choose an opponent and secretly compare the values of your hand cards. The player holding the lower-valued card is eliminated; if the values are equal, nothing happens.",
				handmaid: "Until your next turn, other players cannot choose you as a target",
				prince: "Choose any player (even yourself): they discard their hand and draw a new card. If the Princess is discarded this way, that player is out; if the deck is empty, they take the face-down burn card instead",
				chancellor: "Draw 2 cards (or as many as the deck has left), keep 1 of your cards, and put the rest on the bottom of the deck in the order of your choice",
				king: "Choose a rival and trade hands with them",
				countess: "You must play the Countess while she is held with the King or the Prince. Playing her has no effect",
				princess: "If you ever play or discard the Princess, you are out immediately"
			},
			hintGuard: "Play Guard: guess a rival is {{guess}}",
			hintChancellor: "Keep {{keep}}, bury {{deeper}}"
		}
	}
};
//#endregion
export { ut as default };
