import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useState as r, useSyncExternalStore as i } from "react";
import { BottomSheet as a } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { playTurn as u, useSoundEdge as d } from "@bgparty/sdk/sfx";
import { useWakeLock as f } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { seatName as m } from "@bgparty/sdk/ui/player-strip";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { FlySprite as v, PulseBox as y } from "@bgparty/sdk/fx/primitives";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
//#region src/games/customheroes/data.ts
var x = [], S = (e, t, n, r = null) => {
	for (let i = 0; i < n; i++) x.push({
		id: x.length,
		slot: e,
		value: t,
		ability: r,
		cost: r === "ascended" ? 2 : r && r !== "kodora" ? 1 : 0
	});
};
for (let [e, t] of [
	[-1, 2],
	[-2, 2],
	[1, 2],
	[2, 2],
	[3, 2],
	[4, 2],
	[5, 2],
	[7, 1],
	[8, 1]
]) S("right", e, t);
for (let [e, t] of [
	[5, 1],
	[6, 1],
	[7, 1],
	[8, 2],
	[9, 2],
	[10, 2],
	[11, 2],
	[12, 2],
	[13, 1],
	[14, 1]
]) S("aura", e, t);
for (let [e, t] of [
	[-4, 1],
	[-3, 1],
	[-2, 1],
	[-1, 2],
	[1, 2],
	[2, 2],
	[3, 2],
	[4, 1],
	[6, 1],
	[7, 1],
	[8, 1],
	[9, 1]
]) S("left", e, t);
S("buddy", 0, 8, "burny"), S("buddy", 0, 8, "edge"), S("buddy", 0, 4, "spector"), S("buddy", 0, 5, "charmy");
var C = x.length;
S("buddy", 0, 6, "ascended"), S("buddy", 0, 6, "kodora");
var w = (e) => e.upgrades.map((e) => x[e].ability).find((e) => e !== null) ?? null;
function T(e) {
	return (e.upgrades.map((e) => x[e]).find((e) => e.slot === "aura")?.value ?? e.base) + e.upgrades.reduce((e, t) => e + (x[t].slot === "left" || x[t].slot === "right" ? x[t].value : 0), 0);
}
var E = (e, t) => !e.upgrades.some((e) => x[e].slot === t.slot), D = {
	2: [[
		4,
		0,
		2
	], [
		-1,
		1,
		2
	]],
	3: [
		[
			5,
			0,
			1
		],
		[
			2,
			1,
			2
		],
		[
			-1,
			2,
			3
		]
	],
	4: [
		[
			5,
			0,
			1
		],
		[
			3,
			1,
			2
		],
		[
			1,
			2,
			2
		],
		[
			-1,
			2,
			3
		]
	],
	5: [
		[
			5,
			0,
			1
		],
		[
			3,
			1,
			2
		],
		[
			2,
			1,
			2
		],
		[
			1,
			2,
			2
		],
		[
			-1,
			2,
			3
		]
	],
	6: [
		[
			5,
			0,
			1
		],
		[
			4,
			1,
			1
		],
		[
			3,
			1,
			2
		],
		[
			2,
			2,
			2
		],
		[
			1,
			2,
			3
		],
		[
			-1,
			3,
			3
		]
	]
}, O = {
	id: "customheroes",
	tier: "alpha",
	nameKey: "games.customheroes.name",
	descKey: "games.customheroes.desc",
	rulesKey: "games.customheroes.rules",
	icon: "🦸",
	iconImg: "games/customheroes.webp",
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [
		4,
		5,
		6
	],
	hotseat: "cover",
	mechanics: ["hand-management", "set-collection"],
	interactionTags: [],
	accent: "#405bbb",
	search: {
		py: "bai bian ying xiong",
		init: "bbyx"
	},
	releasedAt: "2026-10-29T20:11:05+08:00",
	rulesUrl: { en: "https://www.alderac.com/wp-content/uploads/2017/02/custom-heroes-rulebook-v2.pdf" }
}, k = t.object({
	id: t.int().nonnegative(),
	base: t.int().min(1).max(10),
	upgrades: t.array(t.int().min(0).max(83))
}), A = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("craft"),
		card: t.int().nonnegative(),
		upgrade: t.int().min(0).max(83)
	}),
	t.object({
		type: t.literal("wager"),
		card: t.int().nonnegative()
	}),
	t.object({ type: t.literal("ready") }),
	t.object({
		type: t.literal("play"),
		cards: t.array(t.int().nonnegative()).min(1).max(15),
		activate: t.array(t.int().nonnegative()).max(15)
	}),
	t.object({ type: t.literal("pass") }),
	t.object({ type: t.literal("trade") }),
	t.object({
		type: t.literal("cap"),
		trades: t.int().min(0).max(10)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), j = t.object({
	owner: t.string(),
	cards: t.array(k),
	activate: t.array(t.int()),
	value: t.int(),
	count: t.int().min(1),
	ascended: t.boolean(),
	spectors: t.int().nonnegative()
}), M = t.object({
	kind: t.enum([
		"play",
		"pass",
		"craft",
		"wager",
		"finish",
		"trick",
		"trade",
		"round"
	]),
	rid: t.string(),
	n: t.int(),
	value: t.int()
}), N = t.object({
	phase: t.enum([
		"upkeep",
		"play",
		"resolve",
		"cap",
		"roundOver",
		"done"
	]),
	round: t.int(),
	turn: t.string(),
	capPlayer: t.string().nullable(),
	descending: t.boolean(),
	final: t.boolean(),
	players: t.array(t.object({
		rid: t.string(),
		score: t.int(),
		handCount: t.int(),
		ready: t.boolean(),
		place: t.int().nullable(),
		active: t.boolean(),
		wagers: t.array(k)
	})),
	table: j.nullable(),
	log: t.array(M),
	bagCount: t.int().nonnegative(),
	winner: t.string().nullable()
}), ee = t.object({
	hand: t.array(k),
	upgrades: t.array(t.int().min(0).max(83)),
	power: t.int().nonnegative()
}), P = () => ({ code: "games.customheroes.invalid" });
function F(t, n) {
	let r = n.slice();
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function I(e, t, n, r = 0, i = 0) {
	e.log.push({
		kind: t,
		rid: n,
		n: r,
		value: i
	}), e.log = e.log.slice(-60);
}
function te(e, t, n) {
	e.inventory[t].push(...e.bag.splice(0, n));
}
function L(e) {
	let t = F(e, e.cards.map((e) => e.id)), n = e.players.length === 2 ? 15 : 10;
	e.active.forEach((r, i) => {
		e.hands[r] = t.slice(i * n, (i + 1) * n), e.bets[r] = [];
	}), e.out = [], e.ready = [], e.table = null, e.descending = !1, e.phase = "upkeep", e.firstWinBase = null, e.turn = e.starter, I(e, "round", "", e.round);
}
function ne(e, t, n) {
	let r = {
		seed: n,
		cursor: 0,
		players: [...t],
		active: [...t],
		cards: Array.from({ length: (t.length === 2 ? 3 : t.length) * 10 }, (e, t) => ({
			id: t,
			base: t % 10 + 1,
			upgrades: []
		})),
		hands: {},
		inventory: {},
		power: {},
		scores: {},
		bets: {},
		bag: [],
		round: 1,
		turn: t[0],
		starter: t[0],
		phase: "upkeep",
		table: null,
		descending: !1,
		ready: [],
		out: [],
		queue: [],
		capPlayer: null,
		capResume: "resolve",
		log: [],
		winner: null,
		firstWinBase: null
	};
	return r.bag = F(r, Array.from({ length: C }, (e, t) => t)), t.forEach((e, n) => {
		r.hands[e] = [], r.scores[e] = 1, r.power[e] = 2, r.bets[e] = [], r.inventory[e] = [C + n, C + 6 + n], te(r, e, t.length === 2 ? 3 : 1);
	}), L(r), { state: r };
}
function R(e, t, n) {
	if (!e.length || new Set(e.map((e) => e.id)).size !== e.length || new Set(t).size !== t.length || t.some((t) => !e.some((e) => e.id === t && w(e) && w(e) !== "kodora"))) return null;
	let r = e.filter((e) => t.includes(e.id));
	if (r.reduce((e, t) => e + (w(t) === "ascended" ? 2 : 1), 0) > n) return null;
	if (r.some((e) => w(e) === "ascended")) return e.length === 1 ? {
		cards: e,
		activate: t,
		value: 0,
		count: 1,
		ascended: !0,
		spectors: 0
	} : null;
	let i = e.filter((e) => !(t.includes(e.id) && w(e) === "edge"));
	if (!i.length) return null;
	let a = T(i[0]);
	return i.some((e) => T(e) !== a) ? null : {
		cards: e,
		activate: t,
		value: a,
		count: e.length + r.filter((e) => w(e) === "burny").length,
		ascended: !1,
		spectors: r.filter((e) => w(e) === "spector").length
	};
}
function re(e, t, n, r) {
	return !t || e.ascended ? !0 : t.ascended || e.count !== t.count ? !1 : n ? r ? e.value < t.value : e.value <= t.value : r ? e.value > t.value : e.value >= t.value;
}
function z(e, t) {
	e.power[t] <= 6 || (e.capPlayer = t, e.capResume = e.phase === "play" ? "play" : "resolve", e.phase = "cap");
}
function B(e, t) {
	if (e.out.includes(t)) return;
	let n = e.out.length;
	if (e.out.push(t), n === 0 && (e.scores[t] += e.bets[t].length * 4), n === 0 && (e.round === 7 || e.scores[t] >= 10)) {
		e.winner = t, e.phase = "done", e.queue = [];
		return;
	}
	if (n === 0 && (e.firstWinBase = e.scores[t]), e.round < 7) {
		let [r, i, a] = D[e.players.length][n];
		e.scores[t] = Math.max(0, e.scores[t] + r), e.power[t] += i, te(e, t, a), n === e.active.length - 1 && e.scores[t] >= 10 && (e.scores[t] = 9), z(e, t);
	}
	I(e, "finish", t, n + 1, e.scores[t]);
}
function V(e) {
	let t = e.table;
	if (t.spectors && (e.scores[t.owner] += t.spectors, e.out[0] === t.owner && e.firstWinBase !== null && (e.firstWinBase += t.spectors, e.firstWinBase >= 10))) {
		e.winner = t.owner, e.phase = "done", e.queue = [];
		return;
	}
	I(e, "trick", t.owner, t.spectors);
	let n = e.players.indexOf(t.owner);
	for (let t = 0; t < e.players.length; t++, n = (n + 1) % e.players.length) {
		let t = e.players[n];
		if (e.active.includes(t) && !e.out.includes(t) && e.hands[t].length) {
			e.turn = t;
			break;
		}
	}
	e.table = null, e.descending = !1, e.phase = "play";
}
function H(e) {
	let t = e.queue.shift();
	if (!t) {
		e.phase = "play";
		return;
	}
	if (t.kind === "finish") {
		B(e, t.rid);
		return;
	}
	if (t.kind === "endRound") {
		e.starter = e.out[e.out.length - 1], e.ready = [], e.phase = "roundOver";
		return;
	}
	let n = e.active.filter((t) => !e.out.includes(t));
	if (n.length === 1) {
		e.queue.unshift({
			kind: "finish",
			rid: n[0]
		}, { kind: "endRound" });
		return;
	}
	let r = e.players.indexOf(t.rid), i = t.skip;
	for (let t = 1; t <= e.players.length; t++) {
		let a = e.players[(r + t) % e.players.length];
		if (e.table?.owner === a) {
			V(e);
			return;
		}
		if (n.includes(a) && e.hands[a].length) {
			if (i > 0) {
				i--;
				continue;
			}
			e.turn = a, e.phase = "play";
			return;
		}
	}
}
function U(e, t, { by: n }) {
	if (e.phase === "done") return P();
	if (t.type === "tick") {
		if (n !== "$engine" || e.phase !== "resolve") return P();
		let t = structuredClone(e);
		return H(t), { state: t };
	}
	if (!e.active.includes(n)) return P();
	let r = structuredClone(e);
	if (t.type === "ready") {
		if (!["upkeep", "roundOver"].includes(r.phase) || r.ready.includes(n)) return P();
		if (r.ready.push(n), r.ready.length === r.active.length) {
			if (r.phase === "upkeep") r.phase = "play", r.ready = [];
			else {
				if (r.round === 6) {
					let e = Math.max(...r.players.map((e) => r.scores[e])), t = r.out[0];
					if (r.scores[t] === e && r.players.every((n) => n === t || r.scores[n] < e)) return r.winner = t, r.phase = "done", { state: r };
					r.active = r.players.filter((n) => n === t || r.scores[n] === e), r.starter = [...r.out].reverse().find((e) => r.active.includes(e)), r.players.forEach((e) => {
						r.hands[e] = [], r.bets[e] = [];
					});
				}
				r.round++, L(r);
			}
		}
		return { state: r };
	}
	if (t.type === "craft") {
		if (r.phase !== "play" && r.phase !== "upkeep" || r.phase === "play" && r.turn !== n || r.phase === "upkeep" && r.ready.includes(n) || !r.hands[n].includes(t.card) || !r.inventory[n].includes(t.upgrade)) return P();
		let e = r.cards[t.card], i = x[t.upgrade];
		return !E(e, i) || r.phase === "upkeep" && i.ability !== "kodora" ? P() : (e.upgrades.push(i.id), r.inventory[n] = r.inventory[n].filter((e) => e !== i.id), {
			state: r,
			fx: [{
				kind: "craft",
				for: [n],
				secret: { card: e.id }
			}]
		});
	}
	if (t.type === "wager") return r.phase !== "upkeep" || r.ready.includes(n) || r.scores[n] < 2 || !r.hands[n].includes(t.card) || w(r.cards[t.card]) !== "kodora" ? P() : (r.hands[n] = r.hands[n].filter((e) => e !== t.card), r.bets[n].push(t.card), r.scores[n] -= 2, I(r, "wager", n), { state: r });
	if (t.type === "cap") return r.phase !== "cap" || r.capPlayer !== n || t.trades * 4 > r.power[n] ? P() : (r.scores[n] += t.trades, r.power[n] = Math.min(6, r.power[n] - t.trades * 4), r.out[r.out.length - 1] === n && r.out.length === r.active.length && r.scores[n] >= 10 && (r.scores[n] = 9), r.phase = r.capResume, r.capPlayer = null, { state: r });
	if (r.phase !== "play" || r.turn !== n || r.out.includes(n)) return P();
	if (t.type === "trade") return r.power[n] < 4 ? P() : (r.power[n] -= 4, r.scores[n]++, I(r, "trade", n), { state: r });
	if (t.type === "pass") return r.table ? (I(r, "pass", n), r.queue = [{
		kind: "advance",
		rid: n,
		skip: 0
	}], r.phase = "resolve", { state: r }) : P();
	if (t.type !== "play" || t.cards.some((e) => !r.hands[n].includes(e))) return P();
	let i = t.cards.map((e) => r.cards[e]), a = R(i, t.activate, r.power[n]);
	if (!a || !re(a, r.table, r.descending, r.players.length === 2)) return P();
	let o = r.table, s = 0;
	for (let e of i) {
		let i = w(e);
		i && (t.activate.includes(e.id) ? (r.power[n] -= i === "ascended" ? 2 : 1, i === "charmy" && (r.descending = !r.descending)) : s++);
	}
	r.power[n] += s, r.hands[n] = r.hands[n].filter((e) => !t.cards.includes(e)), r.table = {
		...a,
		owner: n
	};
	let c = o && o.ascended === a.ascended && (a.ascended || o.value === a.value) && r.players.length > 2 ? 1 : 0;
	return r.queue = [...r.hands[n].length ? [] : [{
		kind: "finish",
		rid: n
	}], {
		kind: "advance",
		rid: n,
		skip: c
	}], r.phase = "resolve", z(r, n), I(r, "play", n, a.count, a.ascended ? 999 : a.value), {
		state: r,
		fx: [{
			kind: "play",
			rid: n,
			data: {
				cards: i,
				count: a.count,
				ascended: a.ascended
			}
		}]
	};
}
function W(e, t) {
	return {
		public: {
			phase: e.phase,
			round: e.round,
			turn: e.turn,
			capPlayer: e.capPlayer,
			descending: e.descending,
			final: e.round === 7,
			table: e.table,
			log: e.log,
			winner: e.winner,
			bagCount: e.bag.length,
			players: e.players.map((t) => ({
				rid: t,
				score: e.scores[t],
				handCount: e.out.includes(t) ? 0 : e.hands[t].length,
				ready: e.ready.includes(t),
				place: e.out.includes(t) ? e.out.indexOf(t) + 1 : null,
				active: e.active.includes(t),
				wagers: e.bets[t].map((t) => e.cards[t])
			}))
		},
		...e.players.includes(t) ? { private: {
			hand: e.out.includes(t) ? [] : e.hands[t].map((t) => e.cards[t]),
			upgrades: e.inventory[t],
			power: e.power[t]
		} } : {}
	};
}
var G = {
	meta: O,
	saveCompatibility: { version: "1" },
	schemas: {
		action: A,
		publicView: N,
		privateView: ee
	},
	setup: ne,
	reduce: U,
	viewFor: W,
	nextTickIn: (e) => e.phase === "resolve" ? 650 : null,
	status: (e) => ({
		phase: e.phase,
		scores: e.scores,
		...e.winner ? {
			winner: [e.winner],
			ranking: [e.winner, ...e.players.filter((t) => t !== e.winner).sort((t, n) => e.scores[n] - e.scores[t])]
		} : {}
	})
};
//#endregion
//#region src/games/customheroes/characters-human.tsx
function ie({ id: e }) {
	let t = `url(#${e}-skin)`, n = `url(#${e}-purple)`, r = `url(#${e}-white)`, i = `url(#${e}-inkhair)`, a = `url(#${e}-gold)`;
	return /* @__PURE__ */ _("g", {
		stroke: "#4b3546",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M330 350C285 370 245 436 205 447 149 463 123 421 79 414c39 29 63 83 133 62 63-18 89-72 129-87Zm110 5c59 4 122-11 164 39 23 28 17 64 58 87 28 14 57 9 83-9-32 7-55 5-66-12-18-26-6-79-48-106-49-31-117-28-173-25Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "M321 375C284 459 198 500 127 533c-81 37-90 102-60 155 20 35 71 49 96 94 29 53 14 89-26 90-40 2-51-23-51-55-12 37 6 76 46 81 69 9 89-57 54-117-25-43-68-69-83-107-15-42 5-70 61-98 96-46 147-96 177-161Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "M314 425C268 496 162 517 113 573 75 616 93 664 110 685m49 83c38 59 15 108-18 113",
				fill: "none",
				stroke: "#616078",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M480 373C524 440 574 472 645 500 699 522 735 501 755 482L764 552C702 588 621 548 567 515c-52-32-91-71-110-111Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "M521 432q102 97 192 102",
				fill: "none",
				stroke: "#666279",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M356 721C345 765 336 800 344 841L362 895 417 897 429 859 407 781 406 724Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M354 788q-7 51 20 95l17 4-9-80Z",
				fill: "#e2a976",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M495 720C511 753 527 796 537 835L563 885 605 862C590 812 581 774 568 726Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M555 745q7 61 29 117l14-6-22-108Z",
				fill: "#c88b61",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m357 866 62-1 10 57-23 54-45-2 4-57Zm186-26 51-16 28 68-48 35-22-44Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m366 879 41-2 3 39-27 49m173-108 28-13 19 41-27 27",
				fill: "none",
				stroke: "#80728a",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m361 866 56-3m127-25 45-17",
				stroke: "#dc86ae",
				strokeWidth: "7"
			}),
			/* @__PURE__ */ g("path", {
				d: "M348 600C314 630 295 673 263 715L224 747C242 762 261 760 279 746c25 3 44 26 71 37 13-1 28-16 39-25 21 21 48 41 74 51 31-11 51-39 70-56 12-7 24-3 31 3l26 26c28-5 52-23 69-44-26-34-65-54-96-77L485 611Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M367 622C336 651 315 705 280 738l34 9 44 27 31-23 28 25c18-53 1-108-11-139Zm95 12c24 46 15 105 0 162l31-14 40-38 30 4-49-83Zm68 17 38 47 42 41 24 18 17-18-67-49Z",
				fill: "#8c9fae",
				opacity: ".7",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M237 746q25-13 42-4l77 42 33-25q33 35 74 49l40-21 34-27 29 4 22 20 38-19 26-27",
				fill: "none",
				stroke: "#d88daf",
				strokeWidth: "13"
			}),
			/* @__PURE__ */ g("path", {
				d: "M345 640c-14 38-41 74-65 93m140-81q17 72 1 118m75-94q13 37 0 82m57-79 48 47",
				fill: "none",
				stroke: "#f6f0dd",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "M330 501C318 530 314 575 287 603L202 633 166 641l-5 27 49 5 110-38c31-20 44-67 51-99Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M334 548c-8 28-22 55-42 65l-90 36-32 4 6 14 34-1 106-38q25-19 33-52Z",
				fill: "#c98c62",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M173 642 145 644 123 639 102 647 98 658 118 657 139 665 125 676 111 677 108 686 128 689 145 681 157 686 179 671Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m122 650 26 10m-24 15 24-9 10 7m-9-27 11 11",
				fill: "none",
				stroke: "#a16a51",
				strokeWidth: "2.4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M539 404C565 410 587 429 605 440l28-39 23-47 28 7-12 58-31 66c-8 13-21 17-38 7l-62-31Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m552 427 52 47q18 11 26-4l31-62 13-39-3 48-30 65q-9 16-30 8l-66-36Z",
				fill: "#cf8e62",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m568 438 31 21 14 3m25-56 20-40",
				fill: "none",
				stroke: "#ffe1a4",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M656 360 650 337 642 320 645 295 654 277 661 280 657 303l7 15 1-37 8-24 8-2-3 24-1 23 18-25 15-1 1 7-20 15-6 16 23-5 9 7-17 4-15 13 2 22-7 18Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m652 316 13 12 9 20m-8-20 15-13m-13 17 15-6",
				fill: "none",
				stroke: "#ab7057",
				strokeWidth: "2.3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M358 432C382 414 433 417 458 435l14 86-16 37 17 48-39 21-67-6-34-25 8-39-22-38 11-61Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M365 481c8 7 22 25 29 42 10-18 24-33 37-38l4 80c-8 15-16 25-26 32-19-9-34-19-45-34Z",
				fill: "#172e3c"
			}),
			/* @__PURE__ */ g("path", {
				d: "m347 536 18 23 67 8 34-29-7 39 16 28-51 22-62-9-30-24 10-36Z",
				fill: "#322b32"
			}),
			/* @__PURE__ */ g("path", {
				d: "m357 546 15 48 41 11 41-22m-109-25 17 14m67-2 25-17",
				fill: "none",
				stroke: "#6e5360",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M379 390 379 421 396 448 421 456 441 434 437 394Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m382 402 20 26 26 7 9-24-16-15Z",
				fill: "#ce8c65",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M375 391C351 399 326 411 298 416 272 415 251 413 254 438c3 29 14 59 43 82l28-7c10-11 8-29 14-42l32-5c8 10 10 29 17 41l27-6 16-39c12 1 27 11 32 23 8 13 3 32 7 43 7 9 20 14 31 16 18-2 31-10 40-22 15-18 22-46 30-66-8-16-15-22-25-29l-49-11-38-21-7 21-15 22-21-13Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M264 438q10-14 35-6l31 17-17 40-23 13-13-22m208-47q29 13 53 10l18-13-13 57-20 30-26-2-12-40",
				fill: "#322e5b",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m265 442q-14 12 2 30 17 17 18 2 2-12-8-12m23-32q21 0 18 18-4 12-13 3m-13 38q15-4 16 10 1 15-11 13m210-85q24 2 19 17-6 12-16 3m27 23q-18-4-17 11 4 16 15 5m-40 18q-15-5-17 9-1 12 11 11",
				fill: "none",
				stroke: "#df87b2",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m377 405 14 32m43-33-13 35",
				stroke: "#9c80ae",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M388 445c-19-16-38-10-36 8 1 15 23 22 37 15l13-12-5-10Zm24 0c6-18 31-19 37-4 6 14-7 32-29 31l-16-14Z",
				fill: `url(#${e}-pink)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m390 457 17-12 13 14-18 15Z",
				fill: "#e482a0"
			}),
			/* @__PURE__ */ g("path", {
				d: "m371 451 14 10m39-7 14-10m-40 29-14 22m25-21 12 19",
				stroke: "#f5afbd",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "m342 573 124 12 6 18-130-11Z",
				fill: a
			}),
			/* @__PURE__ */ g("path", {
				d: "m344 608 122-11 8 20-116 39-34-15Z",
				fill: a
			}),
			/* @__PURE__ */ g("path", {
				d: "m344 628 91-15-78 28m-17-58 115 11",
				fill: "none",
				stroke: "#f6d476",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m447 608 27 0 2 17-26 2Z",
				fill: "#435364",
				stroke: "#e1c16f",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M323 272c-10 34-5 85 13 109 8 12 17 20 29 24 9 4 20 5 28 3 13-5 24-13 31-23 8-12 13-25 15-35 4-25 4-43-1-63l-49-31Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M415 302c10 27 12 54-3 75l-31 23 15 5 31-22 15-35-6-48Z",
				fill: "#c58b68",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M307 351c-28-42-22-96 6-127 26-30 82-31 119-10 32 19 39 48 50 84l10 42-7 33-30 19-30-6 13-24 1-33-12-33-9-35-5 53-10 14-10-43-9 43-13 9-9-38-10 37-15 1-7-30-9 26-1 44 12 18-18 13-26-15Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "M317 267q-3-39 31-47m-20 68q-6-39 16-59m12-7 1 64m12-67 12 62m6-60 19 53m10-44 22 48 11 65m-135-48q-10 35 2 51m142-102q23 47 15 85l-19 14",
				fill: "none",
				stroke: "#62566e",
				strokeWidth: "4"
			})
		]
	});
}
function ae({ id: e }) {
	let t = `url(#${e}-skin)`, n = `url(#${e}-chestnut)`, r = `url(#${e}-linen)`, i = `url(#${e}-leather)`;
	return /* @__PURE__ */ _("g", {
		stroke: "#493c32",
		strokeWidth: "2.2",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M365 319C435 314 480 279 535 237c72-57 146-65 182-32-12-40-81-67-137-46-83 31-124 127-207 145Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M419 306C492 294 526 202 615 175c41-13 77-7 99 17m-233 79q66-71 116-85",
				fill: "none",
				stroke: "#b6955d",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M299 663C246 693 208 749 166 799c-48 56-58 83-43 123l84 9 48-25 34-65 74-39 68 55 10 90 47 15 31-43-27-73 67-5 48 58 43-19 13-50-72-69-90-76Z",
				fill: `url(#${e}-black)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M281 704c-69 47-95 110-124 160l-13 50 53 7 42-32 29-70 75-45Zm140-10 49 83 53 23 59 72 32-10-65-88-47-21Z",
				fill: "#1e252b",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M218 812q23-53 65-69l-26 51-18 54m56-90q41-34 65-36m75 18 26 62 52 24m-79 55 19 74",
				fill: "none",
				stroke: "#647071",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M331 673 432 682 440 752 410 804 353 778 350 729Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "m359 708 20 48 30 28-2 17-40-21-11-52m46-20 17 37-11 31",
				fill: "none",
				stroke: "#8c8570",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M313 706C369 733 421 750 479 751l83-1c68-16 112-23 170 1-38 14-63 36-72 64l-40-11 33-34c-68 2-113 14-173 9l-128-31Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M321 727C410 747 458 778 518 821l65 53 8 36-52 9-31-42c-68-62-124-83-163-107Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M367 751q95 42 175 124l36 22m-95-137 105-2 80 4",
				fill: "none",
				stroke: "#c7c2a5",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "m542 882 17 13 22 7-2 9-39 6-27-38Z",
				fill: "#746e5e",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M266 435 254 499 269 557l-25 40-64 35-29 21 8 33 42-18 89-36c30-17 36-58 37-100l-18-68Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M280 495c15 44 25 72-4 106l-75 39-33 23 11 13 105-44q34-20 34-79Z",
				fill: "#b67d50",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m199 586 51 48-36 25-51-34Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m183 615 36 24m-21-28 33 21m-19-38 34 28",
				stroke: "#cba06b",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M160 642 143 639 126 645 115 657 110 681 124 692 153 689 173 676l9-19Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m128 654-6 23m17-28-7 26m17-24-6 23m-24 8 30-2",
				fill: "none",
				stroke: "#8e5c42",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M477 391C514 389 534 413 551 430l48 10 22-48 10-43 37 2-2 65-20 56c-7 17-18 25-40 21l-70-7-68-31Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M516 420c15 25 35 40 63 43l38 6 22-42 17-52-3 45-18 53q-9 18-30 13l-70-7-37-18Z",
				fill: "#b77449",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m532 431 35 20 35 6m29-62 11-27",
				fill: "none",
				stroke: "#f9cf8c",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m624 343 49 12-13 70-49-12Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m634 353 26 7-11 47m-33-1 41 9",
				fill: "none",
				stroke: "#a68154",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M633 348 626 329 617 303 623 285 637 279 646 288 658 277 674 282 688 289 690 304 680 338 669 354Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m632 288 9 23m12-26 9 18m11-18 6 16m-45 19 25 11 17-8m-37-15-10 11",
				fill: "none",
				stroke: "#a16a45",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M295 421 358 411 417 428 451 499 443 598 402 628 346 612 326 550Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M308 467c27-15 54-7 80 15l26 3q12 15 21 37c-17-12-35-20-54-21-9-1-18 2-26-1-18-9-34-19-47-33Zm46 44q18 0 30 4c6 12 10 22 10 35-11-7-23-7-34-10q-7-15-6-29Zm42 10q14-4 24 1c5 9 8 18 8 28-9-5-15-3-25-5Zm-29 30q15 0 30 4l5 32q-16-9-34-11Zm37 5q12-9 24-3 7 16 8 30l-28 1Zm-31 31q17 1 30 5l17 26q-24-2-38-9Z",
				fill: "#b47950",
				opacity: ".6",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M318 455q27 5 45 18m6 39 15 3m25 9 10 5m-41 28 14 4m18 4 11 3m-36 29 12 3",
				fill: "none",
				stroke: "#f6cf94",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M273 402 312 427l11 50-18 18-17 79-48 24-39-49 38-76Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "M423 371 485 376 522 399 500 469l7 94 30 57-43 51-38-54-10-88-7-75Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m279 412-21 50-32 76 18 25 31-69 28-30m172-76 15 17-18 81 13 90 25 43-19 27-26-47-10-93 3-61",
				fill: "none",
				stroke: "#bc8b49",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m288 463 20 18-20 64-31 33m233-121-4 54 22 84",
				fill: "none",
				stroke: "#362e29",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M336 344 328 387 363 422l45-11 15-54Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m343 365 22 25 38 9 10-23Z",
				fill: "#a96d48",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M281 380c-25 16-22 42 6 62 28 22 74 23 117 11 48-15 71-47 58-80l-14-38-32-10-10 36-27 24-31 8-31-14Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M282 403c36 22 84 27 128 5 22-12 38-28 42-42m-159 61q68 28 120-1m-96-39 32 17 37-5m32-55 10 32-13 21",
				fill: "none",
				stroke: "#8f917f",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "M287 392q-9 16 22 31m16-17q49 13 86-11",
				fill: "none",
				stroke: "#ede3b9",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M445 397C536 371 576 334 637 322l81-30 9-12c-74 20-133 31-190 66l-94 33Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "m483 382 125-56 64-19",
				stroke: "#e7dfbd",
				strokeWidth: "4",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M255 276c-12 27-3 71 15 92 11 12 25 22 36 26l25 1c8-3 17-9 23-16 10-9 16-20 19-28 3-15-1-34-9-50l-34-40Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M334 291c10 24 15 47 3 68l-25 24-15 3 30 7 27-16 17-28-13-42Z",
				fill: "#b67c53",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M244 315 229 331l8-39-13-1 17-26-4-28 29 12 10-32 9 19 52-29 3 26 36-8-15 21 34-2-20 28 23 12-26 10 26 14-32 3 13 20-31-7 11 34-35-28-23-22-29-39 8 39-22-19 6 42-24-33Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m250 267 15-32m-3 31 17-25 40-15m-34 47 42-26 33-3m-53 42 44-17m-28 28 42 13m-88-31 22 39m-24-23 8 31",
				fill: "none",
				stroke: "#bd9c60",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M328 596c34 8 76 9 113 2l19 45 40 18-95 25-103-21 15-39Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m328 612q53 14 113 3m-123 18q69 13 132-2m-133 19 152-9",
				fill: "none",
				stroke: "#b08b59",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m298 661 203 11-5 29-202-14Z",
				fill: "#3b332c"
			}),
			/* @__PURE__ */ g("path", {
				d: "m427 674 38 5-6 23-38-5Z",
				fill: "none",
				stroke: "#b99c68",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m472 686 60-2 11 26-5 40-45 4-12-19Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m490 697 42 6-1 14-35-2m-11 18 45 8",
				fill: "none",
				stroke: "#95794e",
				strokeWidth: "4"
			})
		]
	});
}
function oe({ id: e }) {
	let t = `url(#${e}-skin)`, n = `url(#${e}-plumhair)`, r = `url(#${e}-white)`, i = `url(#${e}-leather)`, a = `url(#${e}-gold)`;
	return /* @__PURE__ */ _("g", {
		stroke: "#4c3540",
		strokeWidth: "2.1",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M373 257C458 263 504 291 550 324c45 38 43 76 80 102-27-6-45-23-58-42 29 77 9 130 58 163-36-14-49-43-55-71 14 70 44 117 75 180 28 56 31 99-7 140 18-43-9-78-47-113-58-52-99-102-108-167L395 369Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M448 304q100 42 102 148c1 90 63 148 91 218 12 32 13 56 6 79m-159-397 41 58m-37-25q2 141 83 221",
				fill: "none",
				stroke: "#d1a0a1",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M475 350c49 93 25 153 76 245l44 62c-71-51-94-105-104-169Z",
				fill: "#603244",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M316 455C278 466 243 489 236 526c-9 49 45 85 78 83l21-45-5-70Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M270 481c-41 34-29 87 13 107m-11-94q-28 43 8 72",
				fill: "none",
				stroke: "#c39b9d",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M374 708C337 757 311 817 299 866l-1 123 114 8 39-106 45-95-33-78Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M444 747c-6 44-14 72-34 104l-40 115 35 16 45-95 39-93Z",
				fill: "#ba7958",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m324 876 56 17 8 52-11 58-79-14 2-68Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m308 900 60 16m-58 2 55 17m-53 2 51 17",
				stroke: "#aa8660",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M382 716c57-3 97 21 127 53 16 25 20 60 34 86 13 25 35 39 58 53l-58 53c-23-13-51-29-68-45-27-24-42-38-56-58l-47-86Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "M342 695C275 735 237 747 179 753l-130-1 26 55 93 34 119-38c-79 68-134 89-202 103l39 51 86 35c70-42 138-96 185-148l68-69 27-54Z",
				fill: `url(#${e}-skirtgreen)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M371 729C322 752 266 781 230 791l-81 21-60-33 14 35 63 22 114-35 97-50Zm-20 63C286 873 210 913 136 945l29 22 95-62 82-68 53-60Z",
				fill: "#54795f",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M89 769q91 28 190-8m-162 178q81-19 180-98m77-80-57 64",
				fill: "none",
				stroke: "#c2d69a",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "M341 464c-18 28-23 68-35 98l-41 45-80 32-27 6 2 32 44-6 96-29c34-15 64-57 70-92l10-53Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M324 537 302 591l-39 30-64 25-17 22 24-2 96-31q46-27 55-73Z",
				fill: "#b87353",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M288 577 323 603l-28 36-81 28-27-32 67-23Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m213 638 12 22m48-51 29 18m-14-11-18 11m21-21-8 10",
				fill: "none",
				stroke: "#be986c",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m181 635 12 28-29 14-14-32Z",
				fill: a
			}),
			/* @__PURE__ */ g("path", {
				d: "M161 648 138 643 119 637 91 638 82 647 101 653 118 652 107 661 84 661 81 670 108 675 126 672 118 684 122 692 143 680 156 670 178 663Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m104 644 29 11m-17 9 22-7m-16 16 22-12",
				fill: "none",
				stroke: "#9f664e",
				strokeWidth: "2.3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M509 397c39 7 58 39 79 57l25-44 23-75 32 2-2 100c-7 38-20 74-43 86-23-1-45-20-68-34l-48-34Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M555 437q25 43 58 62l27-39 17-72-3 54q-10 51-31 72c-25-3-48-25-69-38Z",
				fill: "#b67554",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M625 336 672 345 662 430c-5 32-16 67-34 91l-36-14-32-33 20-33 30 32 12-61Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "M638 351c7 46-5 110-24 142m-39-38 28 33m17-112 46 11",
				fill: "none",
				stroke: "#9d6e59",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m623 316 48 11-4 24-47-10Z",
				fill: a
			}),
			/* @__PURE__ */ g("path", {
				d: "M628 317 621 297 624 281 634 271 641 277 644 263 656 258 669 267 674 278 675 302 666 327 647 331Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m636 278 11 16m7-25 11 17m-36 15 24 8 14-11",
				fill: "none",
				stroke: "#98614a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "m629 292 14 7",
				stroke: "#f5d094",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M343 386C371 371 411 367 437 377l47 20 22 34-30 55-9 51 10 65-15 86-51 24-52-41-12-80-27-59-22-56Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M356 490C355 539 383 554 394 588l18 80 31 8 16-86-13-63-15-26Z",
				fill: "#6d5974",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M441 513c-2 43 30 78 10 139l-26-12-1-68-14-37Z",
				fill: "#b8a2b7",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M360 526c-6 44 16 68 19 102l15 39-24-15-17-70Z",
				fill: "#c6c8d0",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M360 512 410 538 453 503 445 566 426 622 409 640 393 580Z",
				fill: a
			}),
			/* @__PURE__ */ g("path", {
				d: "m372 530 37 27 30-33-12 51-17 44-13-49Z",
				fill: "#e0d7b6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m380 548 50 14m-44-2 36 28m-36-8 40-32m-33 42 29-21",
				stroke: "#8b7770",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M332 659q76 48 146 30l15 34-61 53-57-32-38-39-17-16Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m341 671 37 42 51 33 53-30",
				fill: "none",
				stroke: "#d0a065",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m427 723 14-12 12 13-13 17Z",
				fill: a
			}),
			/* @__PURE__ */ g("path", {
				d: "M325 321 315 359 337 397 371 416 420 405 440 375 422 336Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M328 341q13 31 40 43l41 9 13-19-38-15Z",
				fill: "#b57658",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M308 371c-29 19-40 44-36 74l30 20 42-15 58-18 52 15 47 7 44-23-11-32-22-52-12 39-35 30-61-7Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m337 381 22 16 40 21 27-1-44-24m48 6 18 13 26-13",
				fill: "none",
				stroke: "#f4c799",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M277 435c35 7 73-6 111-9 22 0 39 10 60 12 22-1 40-9 55-18 13-13 24-34 31-49l14 29c-5 17-10 34-19 46-9 11-24 20-37 25 16 5 27 12 40 22l-19 40c-14 7-25 8-39 6-15-8-22-30-32-41l-23-19c-21 11-45 29-71 40-24 11-47 12-71 15-12-9-21-21-26-36Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M281 447c43 4 71-10 108-13l44 15-62 17-63 41-28-10Z",
				fill: "#e8d9db",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M287 501q58-8 108-42l42-8-30 28-65 34-56 14Z",
				fill: `url(#${e}-skirtgreen)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M476 448 523 427l-13 23-35 15 28 20 17 5-10 29-25-4-25-42Z",
				fill: "#bca9c0",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m290 445-16 18 8 31m28 14 60-34m115-21 35-16m-37 40 20 15",
				fill: "none",
				stroke: "#f6e8dc",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m414 456-22 52 18 26 22-31 6 40 31-9-10-70Z",
				fill: `url(#${e}-pink)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m416 475-13 29m39-26 8 47",
				stroke: "#e4a6bd",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "447",
				cy: "451",
				r: "17",
				fill: a
			}),
			/* @__PURE__ */ g("circle", {
				cx: "447",
				cy: "451",
				r: "10",
				fill: "#5ba9c8",
				stroke: "#bacfce"
			}),
			/* @__PURE__ */ g("path", {
				d: "m343 355 19-11 43 13 15 20-18 29-41-19Z",
				fill: a
			}),
			/* @__PURE__ */ g("path", {
				d: "m363 359 32 11-6 20-25-13Z",
				fill: "#9d7739"
			}),
			/* @__PURE__ */ g("path", {
				d: "m382 353 16 12 3 19-16 9-13-15Z",
				fill: "#4ab2d3",
				stroke: "#b9e0d9",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M283 237c-10 31-3 72 12 94 7 10 17 15 28 18 8 4 17 5 22 3 14-4 26-11 31-17l25-36c4-12 4-26 1-40l-54-42Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M371 248c13 21 17 45 7 64l-31 30 1 8 30-17 24-35-4-37Z",
				fill: "#b8795b",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m294 303 18 13 13 4-14 10-15-10Z",
				fill: "#cf8f6a",
				opacity: ".6",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M280 289c-16 1-23 29-13 43-22-11-24-38-16-61l14-35-9-2 23-19 22-6-13-18 26 10c11-31 44-25 71-4l24 15 28-8-16 22 26 8 6 28-28 20-33-6-24-27-16-14-6 30-18 26 3-31-24 15-12 23-6-18Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M286 221q22-18 40-2m-12-8q5-26 27-15l31 26 39 9m-81-10 40 31 27 5m-84-23-29 35m45-48 15 23m34-6 34 13",
				fill: "none",
				stroke: "#c59a96",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m316 199-12-19-26-7m37 21-1-24",
				fill: "none",
				stroke: "#91636b",
				strokeWidth: "3"
			})
		]
	});
}
function K({ id: e }) {
	let t = `url(#${e}-skin)`, n = `url(#${e}-wine)`, r = `url(#${e}-fur)`, i = `url(#${e}-leather)`, a = `url(#${e}-gold)`;
	return /* @__PURE__ */ _("g", {
		stroke: "#473333",
		strokeWidth: "2.4",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M340 657C293 702 258 764 224 825L175 967 279 1001 353 921 411 868 489 904 548 974 653 923 632 825 559 701 456 650Z",
				fill: `url(#${e}-black)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M332 723c-71 61-100 149-131 235l55 26 76-100 67-48-40-35Zm137 6 39 71 47 75 47 66 32-27-51-80-38-78Z",
				fill: "#20252b",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M274 824q28-49 62-66l-24 41-20 60m93-49 27 38m79-36 39 37m-183 74-62 68",
				fill: "none",
				stroke: "#677071",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M330 468C293 484 272 517 249 550L212 588 177 630 198 663l49-26 71-37c32-29 47-66 48-105Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M317 505c-4 34-18 62-44 84l-44 23-39 37 11 11 57-30 58-31q36-40 41-91Z",
				fill: "#b87950",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M268 556q-3 22-21 37m-24 23-25 20m82-69 27-32",
				fill: "none",
				stroke: "#f0c18b",
				strokeWidth: "7"
			}),
			/* @__PURE__ */ g("path", {
				d: "m180 621 36 28-20 27-31-9-7-30Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m180 624 21 24m-28-18 22 26m-29-13 23 25",
				stroke: "#c19d69",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M164 642 144 638 123 640 103 650 87 656l2 7 25-3 19-2-8 16-14 7 2 9 18-4 13-14-5 21 5 8 12-17 7-18 7-9Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m118 651 29 4 12 9m-25 9 17-10m-4 29 10-23",
				fill: "none",
				stroke: "#9f6c4f",
				strokeWidth: "2.6"
			}),
			/* @__PURE__ */ g("path", {
				d: "M529 375C561 349 597 358 620 385l20 49 21-23 2-58 38-6 17 85c6 37 0 82-26 101-34 11-60-13-78-39l-52-55Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M587 390c27 10 36 30 45 56l27 35c13-5 25-25 24-50l-8-53 20-4 17 63c6 35-2 74-25 85-34 10-60-27-75-51l-33-40Z",
				fill: "#b77548",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M600 392c16 11 25 30 30 48m22 55q14 4 26-11m-88-55 10 26",
				fill: "none",
				stroke: "#f4c48a",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "M649 333 703 321 710 366 706 397 663 413 651 389Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m655 349 42-10 5 18m-44 14 47-11m-43 28 40-13",
				fill: "none",
				stroke: "#b08a55",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M657 337 639 314 633 288 641 267 658 259 670 269 677 254 690 256 702 270 712 289 710 315 701 341 680 351Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M648 292 664 280 687 277 706 296 705 318 690 341 667 344 655 331Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m643 279 12 18m4-29 11 18m12-27 11 20m-19 26 9-7 12 6-2 15-14 4Z",
				fill: "none",
				stroke: "#926a49",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M374 344C334 347 306 386 303 437L313 510C319 546 325 579 332 608l-6 48-41 63-28 70 73-16 80 99 71-108 84 56 78 48-14-81-45-103-6-85 17-107-17-84-53-42-89-1Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M341 408c-16 52-2 93 19 132l39 42 12 66-60 11-19-59-15-91-8-65Zm126-33c55 18 73 64 78 98l-27 38-55 26-49 22 39-59 22-45Zm58 163-18 68-36 39-40-2 22-30 41-28Z",
				fill: "#4d2030",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M358 431q30-23 68 8c20 17 26 47 24 73l-30 37-44-41-29-43Zm111 37q34-24 66-11l-7 37-55 30-29-1Z",
				fill: "#a24849",
				opacity: ".65",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M347 464q-7 30 14 59m91-1q25-26 60-26m-145 40 23 25m81 8 30-17",
				fill: "none",
				stroke: "#bd6b64",
				strokeWidth: "3.4"
			}),
			/* @__PURE__ */ g("defs", { children: /* @__PURE__ */ g("clipPath", {
				id: `${e}-quilt`,
				children: /* @__PURE__ */ g("path", { d: "M344 428q37-20 62 17l-9 175-40 4-20-86Zm93 6q52-20 89 16l-15 84-57 57-36-3 7-83Z" })
			}) }),
			/* @__PURE__ */ g("g", {
				clipPath: `url(#${e}-quilt)`,
				fill: "none",
				stroke: "#d18b7d",
				strokeWidth: "1.7",
				opacity: ".4",
				children: [
					390,
					427,
					464,
					501,
					538,
					575,
					612
				].map((e) => /* @__PURE__ */ g("path", { d: `M318 ${e}q82 57 202 112M318 ${e + 90}q100-42 212-115` }, e))
			}),
			/* @__PURE__ */ g("path", {
				d: "M405 447c-10 62-7 135 13 204l-9 202m-64-87 64-60 78 57m-73-61-37-8m42 33 31 13",
				fill: "none",
				stroke: "#5a2d36",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "m389 465 23 22-24 16 25 18-23 18 28 18-22 18 25 14-21 20",
				fill: "none",
				stroke: "#bd915c",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "m396 475 17 7m-22 17 22 4m-20 24 23-3m-18 39 22-4m-17 29 20-3",
				stroke: "#38282b",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M352 366C323 374 308 399 302 430c-6 21 2 42 1 57-2 14-16 29-23 35-5-14-6-31-2-47-1-24 9-51 16-69 2-15 9-24 16-31 7-14 23-21 37-34 13-8 32-13 45-17 14 0 29 6 37 15l-17 33c-8 10-18 24-35 43l-22 31-11-23c2-12 9-17 14-27l26-35-31 5Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M484 337C507 327 527 327 544 332c25-1 43 11 60 24 15 8 24 20 30 32l-15 35c5 15 3 37 11 51l-20 33c-15-4-25-13-35-22-17-14-23-32-29-55-3-17-12-36-20-46l-39-11-40 43-29 18 11-33 24-38Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M327 371q-25 38-24 77l-14 48m59-143-14 38m48-39-24 37m137-40q57-1 89 34m-56-15 25 25m-5-14 24 45 14 31m-8-55 18 17",
				fill: "none",
				stroke: "#e5c994",
				strokeWidth: "7"
			}),
			/* @__PURE__ */ g("path", {
				d: "m313 407-11 33m29-65-10 20m235-37 27 21m-24-7 27 35 13 46m-22-19 10 28",
				stroke: "#8e6851",
				strokeWidth: "4",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M371 314 367 352 391 390 422 413 460 367 466 325Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m397 341 24 23 21-5-17 30-26-24Z",
				fill: "#9f6849",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M353 243c1-21 29-36 57-28 25 7 49 31 50 53l-7 40c-2 10-6 22-10 30-5 8-16 20-24 26l-29 6c-9-3-19-11-25-20-7-11-12-26-14-40l-11-43Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M426 242c19 13 21 37 17 57l-15 28-22 16-2 22 20-9 21-23 13-33 3-32-18-30Z",
				fill: "#bd8054",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m365 304 18 16 10 22-19-9-12-18Z",
				fill: "#d79866",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M348 283c-12-14-16-35-8-53 12-30 39-41 68-33 29-6 56 16 66 45 7 21 6 43 17 60l-26 10-11-31 3-32-17-17-39-10-34 10-13 26Z",
				fill: `url(#${e}-chestnut)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M356 230q31-31 68-14m-58 10q33-20 69-2m-73 12 26-9m51-6q17 11 22 32m-116-11-4 24",
				fill: "none",
				stroke: "#d5af6c",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "m460 270 12 29m-124-45-7 31",
				stroke: "#654832",
				strokeWidth: "3",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m332 640 192-13 48 22-6 41-59 15-182 0-3-35Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m333 649 91-7m57-4 72 15-3 27m-214 16 168-5",
				fill: "none",
				stroke: "#b99661",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m344 652 92-7 14 47-99 8Z",
				fill: "#574033",
				stroke: "#b18a4a",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m359 655 20 37m18-44 20 39m-22-29 18 13",
				stroke: "#947147",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m491 638 20 9-20 44-18-5Zm40 10 27 42-17 7-27-45Z",
				fill: a
			}),
			/* @__PURE__ */ g("circle", {
				cx: "462",
				cy: "671",
				r: "5",
				fill: "#b89c63"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "531",
				cy: "676",
				r: "5",
				fill: "#b89c63"
			})
		]
	});
}
function q({ id: e }) {
	let t = `url(#${e}-skin)`, n = `url(#${e}-white)`, r = `url(#${e}-gold)`, i = `url(#${e}-warmmetal)`;
	return /* @__PURE__ */ _("g", {
		stroke: "#64463a",
		strokeWidth: "2.1",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M329 386C267 441 198 489 97 519l-58 7-17 210 40 141 70-89 58-95 104-45 104-109 146-8 72 92 72 197 25 68 31-46-16-143-58-188-45-82-45-40Z",
				fill: `url(#${e}-cape)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M333 418C253 476 156 537 53 542L29 702l73-84 99-69 91-35m226-98q57 74 88 182l55 205",
				fill: "none",
				stroke: "#c8dc77",
				strokeWidth: "9"
			}),
			/* @__PURE__ */ g("path", {
				d: "M321 475c-67 77-163 105-209 188L64 781l67 111 112-8 153-81 110 85 70-30-17-197-60-148Z",
				fill: "#30272d"
			}),
			/* @__PURE__ */ g("path", {
				d: "M305 544q-71 69-115 168l-45 112m372-198 21 166",
				fill: "none",
				stroke: "#514036",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M336 708C303 749 296 790 291 838l37 40 53-8 24-36 28-57-17-65Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M391 739c2 37-16 72-26 92l-36 25 13 13 39-3 24-32 28-57Z",
				fill: "#cc8d5c",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M299 833 359 846 373 876 358 930 329 961 283 965 266 944 272 913Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m285 856 62 14-15 52-40 35m12-105-3 35",
				fill: "none",
				stroke: "#e2cc9f",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m295 844 59 13 7 24-13 40-13-4 12-38-60-11Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M452 717C481 739 519 771 534 804l-24 56-45 25-52-42 6-64Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M471 756c32 13 50 31 46 55l-25 34-25 11 10 17 34-18 21-52-19-34Z",
				fill: "#ca895b",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M421 849 474 867 493 894 488 938 466 971 402 970 390 940 401 897Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m420 866 48 17 7 28-17 46m-43-80-13 42",
				fill: "none",
				stroke: "#dbc99f",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m420 850 54 19 12 25-57-20-18 54-9-9Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M331 614C298 648 286 683 273 719l35 16 22 26 30-4 34 13 25-18 20 21 30-4 26 16 14-21 31 17 26-21-40-98-83-50Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M318 670q-1 36-20 56m41-42-10 54m41-54 15 61m51-65 4 72m41-58 28 60",
				stroke: "#b8b6aa",
				strokeWidth: "4",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M327 462c-30-4-63 20-72 46l-22 48-30 35-40 35 18 35 42-21 48-27 51-58 29-60Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M271 509c-7 27-10 53-33 77l-49 43-9 22 39-17 49-25 45-55-1-46Z",
				fill: "#c88b60",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M218 572 260 590l-1 33-47 33-26 6-20-36Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m222 580 26 19-14 25-33 23m12-69-11 28",
				stroke: "#c7c3b2",
				strokeWidth: "5",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M230 577 258 584l18 27-10 30-20 11 3-24-11-25-15-8Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m240 588 22 25-8 25",
				fill: "none",
				stroke: "#fff0ba",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M176 623 158 632 136 623 113 613l-12 2 7 10 24 15-19 2-15 11-4 11 14-4 19-7-10 18-16 16 4 6 19-15 15-21-3 24 7 6 9-30 10-1 11 12 12-3 2-17Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m140 643 16-6 14 7m-43 8 17-4m-8 12 10-11",
				stroke: "#a36d50",
				strokeWidth: "2.3",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M487 388C516 379 538 395 554 421l33 32 35-52 22-47 34 10-12 61-27 87c-9 25-29 32-53 17l-68-40-43-39Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M520 414c12 26 27 51 56 64l24 16 30-44 25-65-4 44-25 79c-6 14-18 17-35 9l-54-34-30-32Z",
				fill: "#c48256",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M553 408c16 8 23 23 29 39l14 13 15-36 31-3 42 33-12 42-30 29c-23 13-46 13-65-2l-38-34-17-45Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M545 428q13 54 55 72l22 2 27-21 13-25m-84-16-4 28m41-35-12 34",
				fill: "none",
				stroke: "#b6b5ad",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "M621 415 643 434 665 434 704 455 677 470 659 463 650 495 627 488 630 458 611 441Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m640 442 17 10 28 4m-49 10 6 19",
				stroke: "#fff2ca",
				strokeWidth: "4",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M640 356 637 332 642 306 633 291 640 274 656 270 663 260 677 266 685 279 691 301 686 324 673 366 653 373Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m642 288 17 8 17 7m-22-29 10 16m12-12 9 13m-38 20 23 9 12-9",
				fill: "none",
				stroke: "#a67155",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M642 350 680 362 675 395 665 422 626 407Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m647 357 23 10-12 41",
				fill: "none",
				stroke: "#b6baa9",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M347 437C370 418 427 415 462 431l45 39 1 67 30 74 40 49 57 30 27 47-37 27-71-37-49-31-61-15-69 29-52 46-66 44 7-56 44-100 17-71-5-57Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "M353 496c-14 35-3 78 12 112l17 51 39-17-22-69-2-65Zm107 4c31 50 12 81 35 115l63 65 65 44-12 17-68-41-58-34-53-10 23-55-22-43Z",
				fill: "#8c693f",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M370 505q28-4 55 16l26 16-13 65-35 27-29-53Zm123 134q37 29 54 64l37 24-50-18-47-22Z",
				fill: "#d4b373",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m330 671-40 99 50-30 65-65m46-9 60 27 102 56m-239-210 15 57",
				fill: "none",
				stroke: "#f7dd9d",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M331 453q9-9 20-8l14 20 26 17 29-8 24-27q11-3 20 5l15 47c-8 19-24 38-38 51l-42 11c-18-3-37-12-51-22-14-10-23-25-31-41Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M327 485 351 517 391 535 428 521 464 478l8 20-32 42-41 16-47-19-31-32Z",
				fill: "#bdb9ae",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m347 452 42 35 58-38m-92 22 34 37 54-36",
				fill: "none",
				stroke: r,
				strokeWidth: "7"
			}),
			/* @__PURE__ */ g("path", {
				d: "M365 373 357 415 378 444 421 458 447 422 442 374Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m372 397 18 21 40 9 13-17-19-23Z",
				fill: "#be805a",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M341 419 366 407 382 443 368 467 338 456 313 478 321 440Zm89 19 13-32 30 14 22 37-41-9-15 18Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m349 430 15 22m93-31 15 18",
				stroke: "#c2bb9d",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M337 275c-11 33 1 81 22 106 9 13 21 23 34 26 9 2 18 1 26-4 12-7 23-20 30-30 6-13 12-28 10-42l-14-57-60-25Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M424 277c18 23 22 47 12 77l-24 38-16 10 23-1 29-29 11-39-12-51Z",
				fill: "#c98b64",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m348 343 18 18 18 5-8 12-19-17Z",
				fill: "#de9d71",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M316 337c-22 17-51 20-74 16 14 20 37 34 68 27-3 11-15 19-27 22 28 8 54 3 77-16l-6-29 9-31 27-24 30-25 11-25c5 11 10 21 11 32 4 15 2 27 6 40 2 12 6 18 11 23 12 15 29 19 50 13-6 13-24 22-46 15 5 10 16 17 26 15-7 11-24 11-30 8-18-3-27-14-24-46l11-36-11-44-16-27-22 43-34 30-51 18Z",
				fill: `url(#${e}-blond)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M303 306c-14-44 1-80 32-98 39-24 80-18 110 9 19 18 26 51 20 76l-17 38-2-50-20-41c-22 44-51 77-100 88l-41 1Z",
				fill: `url(#${e}-blond)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M315 278q6-48 48-60m-39 72q32-34 71-51m-96 84q66-7 110-72m-97 100-51 9m57-2-30 18m156-82q9 42 27 56",
				fill: "none",
				stroke: "#ffe0a0",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "m334 248 37-28m-38 78 60-43m49-23 12 35m-117 94-23 22",
				fill: "none",
				stroke: "#b87a43",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "m369 624 123 20-2 22-121-17Z",
				fill: "#704b35"
			}),
			/* @__PURE__ */ g("path", {
				d: "M399 634c-15 2-20 16-15 30 5 13 19 21 33 19 16-2 24-17 18-30-6-14-22-21-36-19Z",
				fill: "none",
				stroke: r,
				strokeWidth: "9"
			}),
			/* @__PURE__ */ g("path", {
				d: "m407 639 13 8 6 18",
				fill: "none",
				stroke: "#f3db9d",
				strokeWidth: "3"
			})
		]
	});
}
function J({ id: e }) {
	let t = `url(#${e}-elderskin)`, n = `url(#${e}-linen)`, r = `url(#${e}-olive)`, i = `url(#${e}-red)`;
	return /* @__PURE__ */ _("g", {
		stroke: "#494333",
		strokeWidth: "2.2",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M337 650C291 680 236 729 183 774L97 846 85 890 135 961 202 955 222 898 284 852 340 831 398 759Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M334 710q-79 67-141 127l-50 59-39 16 19 35 67 1 23-53 62-47 53-19Z",
				fill: "#9c8a57",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M114 855q77-34 124-91m-43 115 53-51 43-28",
				fill: "none",
				stroke: "#d8c78d",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "M314 641 467 625 505 677 545 785 573 977 466 1004 345 1000 303 939 297 792Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M340 686c-17 82 0 187 15 279l37 24-20-122 9-147Zm81 24c7 65-4 115 1 183l23 100 26-6-18-131 12-134Zm55-30q30 70 36 153l34 132-3-175-39-101Z",
				fill: "#9a8a52",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m325 767 16 167m25-225 18 124m43-123 13 153m42-146 22 113M344 968l99 16",
				fill: "none",
				stroke: "#cec38b",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M332 437C284 473 259 519 234 574l-14 53-48 25-28 3 4 30 50-3 64-24c23-26 43-68 60-104l41-78Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M298 513c-14 55-35 101-61 131l-47 23-36 5 4 9 40-5 64-23 37-67 31-63Z",
				fill: "#a67248",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M148 655 136 641 121 642 112 655 110 677 119 687 142 688 162 677 161 662Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m122 651-4 22m16-23-5 24m16-19-4 19m-25 4 27 4",
				fill: "none",
				stroke: "#855a40",
				strokeWidth: "2.8"
			}),
			/* @__PURE__ */ g("path", {
				d: "M506 397c29-5 53 17 74 37l50-13 15-51 23-27 30 18-8 72-36 71c-15 19-47 14-74 2l-79-49Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M547 432c25 22 50 34 75 33l25-33 27-64 11 13-8 50-31 64c-14 12-42 8-65-1l-56-34Z",
				fill: "#a87448",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M647 372 644 344 638 326 634 293 644 275 655 271 668 259 684 266 698 280 706 299 699 321 693 355 697 382 675 399Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m646 285 18 17 13 5m-18-31 17 15m5-24 11 16m-48 34 14 12 25-12m-21-8-10 13",
				fill: "none",
				stroke: "#986846",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M347 383C313 397 304 440 294 484l-38 76-47 55 29 17 10 69 51-13 25-120 40-93 31-83Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M307 438 284 523l-36 71-21 22 20 17 15 41 32-87 18-102Z",
				fill: "#3b5033",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m342 400-18 43-10 68-29 95-15 67m51-228 13-20",
				fill: "none",
				stroke: "#9ca957",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "M459 364C496 352 522 355 547 371l17 65 27 51 3 86 38 95 44 53 53 43-5 57-53 37-38-55-75-50-46-49-11-75-38-99Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M501 384c33 39 23 91 42 139l18 103c15 62 61 102 102 127l32 62-19 23-44-52-73-47-44-46-10-83-39-103Z",
				fill: "#33472d",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m492 376 26 50-5 62 27 112m28 94 68 70 66 57m-168-426 17 47",
				fill: "none",
				stroke: "#a7a55d",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M367 391c28-21 68-30 96-20l28 108-13 92 5 48-59 43-98-14 3-96 17-98Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M381 427c-13 44-18 79-6 112l9 78 35-1-8-60 10-62 18-90 15-16-40 28Z",
				fill: "#d6cf98",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M459 392q30 65 9 129l4 87-28 29 1-83 17-62-16-69Z",
				fill: "#91864e",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m366 462-12 82 9 70m65-107-14 65 9 42",
				fill: "none",
				stroke: "#a6a16e",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M359 407 393 382 424 415 459 370 470 385 450 456 400 507 363 565 332 600 347 550 385 480 402 434Z",
				fill: "#b95f36"
			}),
			/* @__PURE__ */ g("path", {
				d: "m404 438 45-39-21 52-29 28-44 78m-5-7 39-70",
				fill: "none",
				stroke: "#de9c5f",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M353 376 339 406 347 433 383 444 400 420 375 388Zm105-14-28 41 5 30 28-19 20-31Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m350 407 31 22m59-20 20-27",
				stroke: "#e4dcab",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M537 397c-28 19-28 64-19 96l27 28 64 15 59-6 22-50 18-51-40-25-36-16 3 36-28 17-28-12-26-36Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M524 421c-12 40 0 72 22 85l53 19 63-8 13-38-58 15-38-15-20-47Z",
				fill: "#99915a",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m543 411 3 49 20 25m19-47 10 44 26 5m53-49-15 42m-48 28-43-11",
				fill: "none",
				stroke: "#d3cc93",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "M637 374 652 397 682 406 707 428l-20 20-46-22-13-17Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "m643 389 19 21 35 17",
				fill: "none",
				stroke: "#acac67",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M363 324 363 369 383 413 425 397 446 361 431 319Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m376 340 14 30 28 9 14-25-14-20Z",
				fill: "#9e6844",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M345 284c-4 22 4 55 20 72 8 9 18 15 27 18l23-4c9-7 15-17 20-29 4-11 7-27 6-42l-21-39-40-9Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M414 274q21 32 8 63l-18 22-20 9 11 5 22-5 20-27 4-42Z",
				fill: "#a5714a",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m357 313 9 17 17 10-6 10-19-20Z",
				fill: "#9d704b",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M345 295c-15-6-16-28-3-41 19-21 43-26 64-15 30-4 45 13 51 38l7 29 23 26 13 31-30-4-21-11-9-19-9-29-4-32-24-13-30 7-22 21Z",
				fill: `url(#${e}-greyhair)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m347 272 22-21 24-2m-36 28 24-17 22-2m6-15q28 12 30 37m9 23 6 30 17 15m-47-94 15 27",
				fill: "none",
				stroke: "#d0d6c4",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m461 324 16 20m-24-19 11 22",
				stroke: "#8c9890",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M365 351c9 7 24 5 33-5 4 16 4 31-3 46-4 11-12 25-16 39l-2-24-6 9c4-18-2-29-5-40-2-10-3-17-1-25Z",
				fill: `url(#${e}-greyhair)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M369 359q5 12 5 24l5 24m13-50c2 15-5 31-8 41",
				stroke: "#d6daca",
				strokeWidth: "2.6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m330 609 127-14 20 14 7 39-150 23-21-26Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m330 621 129-16m-133 27 144-16m-144 26 149-15m-139 27 132-17",
				stroke: "#e78046",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M410 655q16 14 53 18l21 16-36-6-40-15Zm43 6 41-4 12 21-4 28-15 15-25-12 13-26-20-14Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "M481 675c-23-18-35 4-20 15 13 9 31-17 37-9 15 9-7 26-20 12m10-5-9 39-10 22m23-45-3 49",
				fill: "none",
				stroke: "#d87943",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "m467 740 24 0 5 77-9 16-17-5-9-20Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m475 748 2 70m9-68-1 67",
				stroke: "#f3a05a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "m367 462 16 11 18 1m-15-7-10 15 9 26m-3-33 15 10-2 29m-14-28-6 77m17-74 3 72",
				fill: "none",
				stroke: "#b65e36",
				strokeWidth: "3"
			})
		]
	});
}
function se({ base: e, id: t }) {
	return e === 2 ? /* @__PURE__ */ g(ie, { id: t }) : e === 3 ? /* @__PURE__ */ g(ae, { id: t }) : e === 4 ? /* @__PURE__ */ g(oe, { id: t }) : e === 5 ? /* @__PURE__ */ g(K, { id: t }) : e === 6 ? /* @__PURE__ */ g(q, { id: t }) : e === 7 ? /* @__PURE__ */ g(J, { id: t }) : null;
}
//#endregion
//#region src/games/customheroes/character-cyborg.tsx
function ce({ id: e }) {
	let t = `url(#${e}-porcelain)`, n = `url(#${e}-gold)`, r = `url(#${e}-black)`, i = `url(#${e}-cyberskin)`;
	return /* @__PURE__ */ _("g", {
		stroke: "#3b3843",
		strokeWidth: "2.1",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M438 366 470 355 501 386 524 461 531 563 508 631 469 632 449 565 442 484Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "m467 381 14 76 18 93-11 57m-9-185 23 80",
				fill: "none",
				stroke: "#566a83",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m480 365 26 12-1 32-24 2Z",
				fill: "#263348"
			}),
			/* @__PURE__ */ g("path", {
				d: "M328 716C300 753 299 799 317 839l54 98 43 55 46-19-2-80-47-107-27-68Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M323 741c-7 52 17 91 42 128l49 102 28-6-27-86-43-117Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M334 771c5 34 22 57 43 82l26 51-22-58-26-75Z",
				fill: "#dde0cf",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m340 775 24 60 31 41m-33-129 18 24 34 13m-26 2 16 42",
				fill: "none",
				stroke: "#798c9e",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M314 775 332 838l50 84 13-1-40-93-21-61Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m319 792 14 44 41 74",
				stroke: "#efce78",
				strokeWidth: "4",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M447 715C474 715 507 739 523 774l32 105 10 64-51 37-57-60-17-68-40-89Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M463 746c33 27 42 64 46 101l27 106 22-16-14-70-31-93-35-34Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M461 754c-2 37 15 66 29 93l18 76 12 21-13-103-33-83Z",
				fill: "#758591",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m477 762 22 33 12 56m10 18 18 63",
				fill: "none",
				stroke: "#e0e5d5",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M335 628C307 649 300 692 306 724l44 27 46 29 46-19 47-32 17-37-41-63-67-20Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "m329 651 20 39 52 35 40-18 39-37-10-24-36-10Z",
				fill: "#324254"
			}),
			/* @__PURE__ */ g("path", {
				d: "m353 667 48 31 34-16m-62 58 27 18 31-15",
				fill: "none",
				stroke: "#697589",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M368 529C353 558 346 588 351 615l-26 44 14 51 58 56 39-52 14-33 20-29-26-52 4-53Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M389 551c-10 30 4 63 14 86l10 56-16 66 34-44 12-36-7-44-25-49 5-37Z",
				fill: "#a2aeb0",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m368 554-5 53 12 22 13 62m29-130 1 33 16 31m-96 34 32 41",
				fill: "none",
				stroke: "#687a8c",
				strokeWidth: "2.7"
			}),
			/* @__PURE__ */ g("path", {
				d: "m383 572-6 31 14 30 5 35m40-31-7 36",
				fill: "none",
				stroke: "#d5dcd0",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M464 630c37-6 66 19 78 47l17 43-20 21-47-17-26-34-14-37Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M468 645q40-4 61 31l16 40-11 9-35-14-22-31Z",
				fill: "#6d522e"
			}),
			/* @__PURE__ */ g("path", {
				d: "M475 651q31 0 50 28l15 33-33-13-21-24Z",
				fill: "#bd943e"
			}),
			/* @__PURE__ */ g("path", {
				d: "m475 650 20 25 31 19",
				fill: "none",
				stroke: "#edcb6e",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M333 637c-21 9-25 30-27 48l-3 25 19 0 16-23 11-30Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M337 449c-21-4-43 15-48 39l-2 49-20 46-59 28-38 19 6 30 52-12 76-27 30-49 17-68Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M308 475c-16 40-5 67-26 111l-62 35-38 17 7 15 43-13 69-24 27-48 15-74Z",
				fill: "#909e9d",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m298 555-12 31-48 29m-13 7-43 20m150-162-9 51",
				fill: "none",
				stroke: "#d8dfd3",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "m286 544 19 4-10 23-17 12Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "m282 551 14 4",
				stroke: "#708499",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M176 629 151 622 130 626 109 637 92 648 85 658 96 661 121 646 137 643 121 659 110 680 113 690 123 688 137 664 146 662 138 687 139 700 148 701 158 672 166 662 181 658Z",
				fill: "#1a2634"
			}),
			/* @__PURE__ */ g("path", {
				d: "m120 640 18-7 16 5m-15 14 17-8m-9 26 10-19",
				fill: "none",
				stroke: "#4f6579",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "m172 630 9 25",
				stroke: "#c9d2c9",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M516 422c24-6 42 12 58 32l32 18 22-45 16-67 22-13 17 17-11 89-22 64c-10 16-26 18-43 7l-61-30-32-29Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M550 443c20 31 44 52 66 58l22-25 20-57 14-50-6 81-20 60q-7 15-22 8l-55-26-31-32Z",
				fill: "#939fa4",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M646 371q-3 32-11 58l19-4 11-40-3-22Z",
				fill: "#cdd9cf",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m554 454 43 35 20 5m25-114-9 34",
				fill: "none",
				stroke: "#dce4da",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "m628 481 10-22 15-3-4 26-12 14Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M646 367 630 353 620 334 611 318 596 311 594 303 605 301 624 313 616 292 606 280 604 271 613 272 627 285 638 305 639 280 632 261 635 252 643 256 650 277 652 304 658 288 660 269 669 267 671 290 663 315 667 333 665 354 658 370Z",
				fill: "#182330"
			}),
			/* @__PURE__ */ g("path", {
				d: "m625 315 16 20 10 4m-15-45 10 25m7-12 1 22m-24 14 13 10 16-4",
				fill: "none",
				stroke: "#536879",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M358 394c-18 16-34 42-37 72l17 51 22 24 6 29 42 8 32-31 35-2 43-50 14-60-25-30-50 3-43 4Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M381 431c-16-2-35 10-45 31l-1 28 34 25 39 6 9-30-9-42Z",
				fill: "#e3b351",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M443 438c33-24 68-12 72 16l-5 38-36 36-32 10-21-29Z",
				fill: "#b4812f",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M344 491q21 16 58 15l16-7 17 24 40-7-32 28-33 25-42-9-9-24Z",
				fill: "#876132",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M346 452q24-22 45-4m59-5q29-19 54 0m-160 23q-2 19 24 28m77-36-13 38m-27 22 8 30",
				fill: "none",
				stroke: "#f6d97d",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m378 432-19-20 21-17 37 12 17 23-19 27-28-4Z",
				fill: "#59394f",
				stroke: "#ad7543",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m369 414 29 0 19 14-10 17-16-4Z",
				fill: "#713e62",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m381 406 18 2 12 9",
				fill: "none",
				stroke: "#aa6b85",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "m415 426 20-10 17 5-12 13-12-2Zm-63 10 5 15-6 6-5-12Zm85 16 4 5-6 8-4-5Z",
				fill: "#242c3a",
				stroke: "#916a3b",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ g("path", {
				d: "m413 434 16 18 5 29m-16 40 2 27",
				fill: "none",
				stroke: "#926e36",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M372 346 368 387 380 413 402 418 436 398 449 378 432 337Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m404 355 7 31 21 13 13-22-14-31Z",
				fill: "#a69c80",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m386 392 14 14 15-7m-30-28-4 16",
				fill: "none",
				stroke: "#63738a",
				strokeWidth: "2.3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M342 267c-12 25-13 56-2 78l28 34 23 12 27-10 29-26 14-35-7-48-39-32Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "M430 266c18 22 20 49 7 73l-26 25-13 19 20-5 26-23 14-34-5-42Z",
				fill: "#a59c7e",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M338 321c-12 29-17 61-9 84 8 18 25 26 46 24-13-7-22-20-23-34l7-63 10-40 18-30 12 23 13-17 16-29 15 27 8 33 7 38 24-16 18-25-3-52-19-35-30-20-38 8-24 20-24 43Z",
				fill: `url(#${e}-blond)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M345 318c-11 42-9 76 9 91m-5-95 13-39 14-30 24-23m-18 28 9-24 28-15m18 17 18 40 7 47m-10-79 26 36 5 28",
				fill: "none",
				stroke: "#d9b956",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "m359 286 5-36 31-32m44-1 18 31 17 61m-136 72-1 18 12 13",
				fill: "none",
				stroke: "#78653a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M477 389c29 5 51 20 67 47l-13 10-37 1-31-11-25-20 10-23Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M452 410q36 30 78 22m-74-27q32 20 68 18",
				fill: "none",
				stroke: "#f2cd71",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M449 397q-7 16 9 27l28 14-19-1-29-18Z",
				fill: "#89592d",
				stroke: "none"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "479",
				cy: "394",
				r: "11",
				fill: "#ad5c8b",
				stroke: "#e8b5a9",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "m473 389 6-4 5 6-7 5Z",
				fill: "#edb6cf",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m346 410-20 17-17 29 10 10 20-36 16-10Z",
				fill: n
			})
		]
	});
}
//#endregion
//#region src/games/customheroes/character-art.tsx
function le({ id: e }) {
	return /* @__PURE__ */ _("g", {
		stroke: "#493b3b",
		strokeWidth: "2.2",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M338 235C288 243 259 280 222 316S141 383 90 410C139 395 185 372 211 351 171 402 115 441 54 461 135 449 217 402 265 358 306 321 320 294 355 286Z",
				fill: `url(#${e}-hair)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M318 258C288 307 235 345 195 376 137 421 73 463 66 506c-7 43 69 60 116 32-34 14-88 1-88-26 0-31 68-76 117-113 60-45 103-87 128-132Z",
				fill: `url(#${e}-hair)`,
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M314 271C267 343 176 391 111 456 64 503 95 547 153 545M307 284C270 342 211 371 173 407",
				fill: "none",
				stroke: "#ceb88b",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M301 266C275 310 232 342 177 369M290 288C248 340 177 391 122 417M254 326C211 372 151 407 103 427",
				fill: "none",
				stroke: "#ceb98c",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M298 790C257 808 242 853 233 907L228 1000 361 1015C365 969 378 932 392 898c8 41 19 76 32 111l140-23C550 933 532 858 514 802L414 773Z",
				fill: `url(#${e}-red)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M290 817q-36 70-44 163l37 11c-2-51 11-97 35-135l5-43Zm90 7q-4 46 9 74l21-53 15 45 41 98 27-8q-13-70-47-131l-20-39Z",
				fill: "#591c31",
				opacity: ".44",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M285 843q-25 54-32 109l11 12q9-71 30-105Zm174-13q24 48 34 99l15 14-10-78Z",
				fill: "#e06342",
				opacity: ".65",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m282 847 22 90-15 62M334 859l22 63 13-43M443 857l37 123 25-9-38-103M247 951l31-54",
				fill: "none",
				stroke: "#741f32",
				strokeWidth: "9"
			}),
			/* @__PURE__ */ g("path", {
				d: "m434 951 8-53 61 73-4 22-51-41-18 34-18 5Z",
				fill: "#b18337"
			}),
			/* @__PURE__ */ g("path", {
				d: "m447 918 10 37 29 22",
				fill: "none",
				stroke: "#edcd69",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M314 541C281 561 240 589 202 608L151 622 132 601 112 608 113 641 137 664C204 672 262 653 317 630L341 592Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M304 579C267 611 211 640 151 642l-16 14c54 14 119-1 171-23",
				fill: "#b87c4a",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M153 622 146 603 131 596 121 607l8 18-14-18-12 4 7 20-14-14-10 9 12 19-6 10 15 16 34 4 17-16Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m112 623 12 18m-22-3 15 16m20-41 7 21m-44 19 28 7 12-5",
				fill: "none",
				stroke: "#905b3c",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M331 365C309 376 301 396 301 430c0 24 11 47 16 66-4 40-20 91-16 128l12 38c-18 39-35 74-45 113l-8 68 76-19 38 21 85-35 83 32c-2-33-9-58-15-84l-28-105c-5-43 5-82 9-123l26-86c-2-25-18-53-30-66l-52-31Z",
				fill: `url(#${e}-blue)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M331 391C307 450 333 486 339 526l-20 94 21 34 51-9 12-89-1-143Z",
				fill: "#416caf",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M473 449C464 492 426 507 414 538l-17 98 70 12 32-76 8-117Z",
				fill: "#17294d",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m337 482 20 43-9 80m118-90-44 39-13 74m-92 59-21 94 44-39 27-67m34 10-7 99 45-30 22-67M288 804l44-12 41 30 80-26 65 25",
				fill: "none",
				stroke: "#7792bd",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M349 473c16 15 20 38 30 45l23 9-16 11c-17-5-22-35-37-65Zm120 12c-9 35-32 44-42 63l-12 42 6-48c8-18 34-29 48-57ZM327 572c-8 26-10 42 8 59l-15-5c-14-21-7-37 7-54Zm80 38q21-20 63-16c-22 2-38 9-48 22l-10 15Zm-60 101c-6 28-22 63-41 79l40-23 15-64Zm60-8q-5 47 2 78l40-18-26 5-2-68Z",
				fill: "#0f254c",
				opacity: ".65",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M353 489c11 11 14 32 26 40m-54 82c-6 9 0 17 9 23m79-14q27-17 60-15m-113 81q-13 38-29 65",
				fill: "none",
				stroke: "#7293c3",
				strokeWidth: "2.3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M456 353C483 345 520 347 546 371L574 411 529 442 492 425 460 397Z",
				fill: `url(#${e}-red)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M459 362 488 360 523 373 548 402 536 415 518 393 491 384 471 390Z",
				fill: "#d5ad52"
			}),
			/* @__PURE__ */ g("path", {
				d: "m481 366 8 21 31 13",
				fill: "none",
				stroke: "#fff0a7",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M532 385C572 391 588 422 605 439l25-32 12-78 38-18 12 39-8 106C677 493 660 526 641 541 621 539 604 526 585 514L525 463C512 447 507 414 532 385Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M533 405C547 404 560 413 570 430 577 448 592 464 612 476L639 499 661 466 679 395 677 462C673 487 657 522 640 531 614 523 594 502 575 491 559 478 538 470 531 451Z",
				fill: "#b77842",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M548 405C571 408 573 434 590 447l24 15M630 478l17-50M537 457q16 6 26 20",
				fill: "none",
				stroke: "#e7b979",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M642 337 627 316 622 293 630 278 641 282 647 262 657 253 669 260 679 256 691 271 697 292 691 319 679 342 660 352Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m635 286 18 18 5 20m-10-57 17 23m3-29 12 19m-35 35-10-5m22 17 23-12",
				fill: "none",
				stroke: "#98613e",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "m638 284 8 12m11-32 9 11m13-12 9 13",
				stroke: "#f8d69a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M354 289 342 337 358 380 417 398 445 354 442 297Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m369 322 32 20 31-18-14 42-36-4Z",
				fill: "#b27850",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M338 313 354 350 382 370 376 407 331 402 319 352Zm80 39 31-50 26 10-6 69-55 32-16-28Z",
				fill: "#162b51",
				stroke: "#8aa4b9",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M338 355q29 14 30 40m-34-35q-12 20 7 24 19 1 7-13m98-47q13 19-1 29-14 7-4 17 9 7 14-3m-20-15-14 22 1 20",
				fill: "none",
				stroke: "#c7aa65",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M345 225C348 201 378 184 408 187c36 0 59 21 62 51-1 11-7 20-6 26l8 20c1 5-7 7-11 9l-3 23c-3 9-13 16-23 21l-22 10c-9-1-22-7-30-12-12-7-19-16-22-25l-9-32c-9 1-19-5-20-15-1-7 0-13 1-17Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M447 223C458 247 447 268 452 284l-10 11 3 17-25 23 15 1 22-19 4-23 9-11-9-22 7-21Z",
				fill: "#ba855d",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M353 261q17 31 29 37l17 5-20 13-17-23Z",
				fill: "#d09a6b",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M335 265q-13-10-15-37c-2-50 31-78 81-78 36 0 63 20 62 45 20-2 42-13 56-31-5 31-25 48-52 52l-21-16c-24 26-57 45-91 54l-6 34Z",
				fill: `url(#${e}-hair)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M334 221C354 183 390 167 435 178M348 236C377 226 405 210 437 188M365 238q36-13 68-39m30-4 19 10 21-13",
				fill: "none",
				stroke: "#cfbb8e",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M324 243q-4-29 8-47m31-24q-19 15-26 36",
				fill: "none",
				stroke: "#6b553b",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M333 383C314 400 306 427 311 454l36 21 25-58-15-24Z",
				fill: `url(#${e}-gold)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M445 392 469 377 486 423 510 461 483 484 455 441Z",
				fill: `url(#${e}-gold)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m322 419 18-19 20 15-14 36m123-43 4 30 20 25m-29-37q-21-9-11-20 15-8 12 9",
				fill: "none",
				stroke: "#f5d987",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M321 437c-5-14 6-28 16-28 14-1 22 14 13 24-7 8-15 0-10-5 5-4 10 2 5 5m112-28c1 10 14 12 20 4 4-7-4-14-8-8m-19 21q-10 8-4 20 5 12 15 9 8-2 5-9-5-6-10-1m28 8q16 10 13 24m-159-76q-12 0-17 16",
				fill: "none",
				stroke: "#72502e",
				strokeWidth: "2.3"
			}),
			/* @__PURE__ */ g("path", {
				d: "m323 427q-3-18 16-25m119 17q-10 12-2 22m25 12 8 15",
				fill: "none",
				stroke: "#ffe79d",
				strokeWidth: "2"
			}),
			[
				435,
				495,
				552,
				610
			].map((t, n) => /* @__PURE__ */ _("g", {
				transform: `translate(${356 - n * 2} ${t})`,
				children: [
					/* @__PURE__ */ g("path", {
						d: "m0-24 19 23-19 29-20-27Z",
						fill: `url(#${e}-gold)`
					}),
					/* @__PURE__ */ g("path", {
						d: "m0-14 10 14-10 16-11-15Z",
						fill: n === 0 ? "#d9e4e7" : "#8e96a1",
						stroke: "#f9e9ab",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ g("path", {
						d: "m0-14 1 18-12-3",
						fill: "#f3f6e8",
						stroke: "none"
					})
				]
			}, t)),
			/* @__PURE__ */ g("path", {
				d: "m307 643 194-6 2 21-191 23Z",
				fill: "#a63135"
			}),
			/* @__PURE__ */ g("path", {
				d: "M317 639q8 23 29 22 24-3 25-25l17 6q4 35-39 36-42-1-47-28Z",
				fill: `url(#${e}-silver)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m331 646 12-12 14 11-11 13Z",
				fill: "#273d58"
			}),
			/* @__PURE__ */ g("path", {
				d: "M283 722 311 692 297 768 276 795 285 739M462 688 508 709 523 767 495 749 478 716 472 759 451 776Z",
				fill: `url(#${e}-gold)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m487 724 21 10m-24 4 20 13m-32-3 7 17m-183-37 3 39",
				fill: "none",
				stroke: "#7d572c",
				strokeWidth: "3"
			})
		]
	});
}
function ue({ id: e }) {
	let t = `url(#${e}-bronze)`, n = "#302b22", r = "#f0cb79";
	return /* @__PURE__ */ _("g", {
		stroke: "#3f3024",
		strokeWidth: "3",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M310 437 438 437 439 573 323 573Z",
				fill: "#202c30"
			}),
			/* @__PURE__ */ g("path", {
				d: "m325 459 94 0m-97 19h101m-100 19h102m-100 20h100m-96 19h91m-92 17h93",
				stroke: "#75633c",
				strokeWidth: "10"
			}),
			/* @__PURE__ */ g("path", {
				d: "m326 462 82-1m-81 36 84 0m-84 39h82",
				stroke: "#b2985e",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "m278 582 42-13 32 23-18 63-42 33-49-21 4-48Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m428 582 35-16 44 35 2 53-52 38-40-36Z",
				fill: t
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "291",
				cy: "631",
				rx: "34",
				ry: "41",
				transform: "rotate(22 291 631)",
				fill: "#61482b"
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "291",
				cy: "631",
				rx: "23",
				ry: "29",
				fill: t
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "462",
				cy: "632",
				rx: "36",
				ry: "42",
				transform: "rotate(-22 462 632)",
				fill: "#61482b"
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "462",
				cy: "632",
				rx: "24",
				ry: "29",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M244 657 322 682 297 773 270 825 202 802 212 740Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M437 690 506 662 536 755 541 823 477 835 452 770Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m246 685 26 9-26 88-24-4Zm239 6 17-9 26 89-17 7Z",
				fill: "#d3a24f",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m292 709-12 62-23 31m221-91 14 65 30 28",
				fill: "none",
				stroke: "#5d4227",
				strokeWidth: "7"
			}),
			/* @__PURE__ */ g("path", {
				d: "M198 793 274 813 264 867 183 855Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M476 816 540 804 557 857 487 877Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m213 810 46 13-7 25-47-12m284 1 37-10 12 22-42 12",
				fill: "#66523c"
			}),
			/* @__PURE__ */ g("path", {
				d: "M177 847 267 866 240 973 208 1013 129 985 159 920Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M485 865 554 846 562 948 596 1003 509 1020 493 947Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m189 872 32 7-23 87-31 18m337-93 15-6 6 81-11 21",
				fill: "none",
				stroke: r,
				strokeWidth: "7"
			}),
			/* @__PURE__ */ g("path", {
				d: "m158 922 82 22m257-13 61-12",
				stroke: "#68472c",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M319 544 432 545 451 587 427 655 392 701 366 638 341 701 309 658 296 592Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m326 561 41 12-1 65-25 62-15-30 3-57-23-24Zm89 1-23 11 1 65 31 60 8-28-5-55 18-29Z",
				fill: "#9b682e",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m334 569 25 8m42-2 22-11",
				stroke: r,
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m368 578 22 0 1 56-22 0Z",
				fill: "#40494a"
			}),
			/* @__PURE__ */ g("path", {
				d: "M293 551 280 535 270 534 255 557 280 615 305 600Zm151-4 11-18 21 3 12 26-10 57-34-17Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m277 551 17 43m169-48-6 44",
				stroke: r,
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "283",
				cy: "566",
				r: "6",
				fill: n
			}),
			/* @__PURE__ */ g("circle", {
				cx: "466",
				cy: "563",
				r: "6",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M240 317 272 308 289 341 267 402 220 412 209 375Z",
				fill: t
			}),
			/* @__PURE__ */ g("circle", {
				cx: "249",
				cy: "344",
				r: "28",
				fill: "#694a2a"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "249",
				cy: "344",
				r: "18",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M455 314 482 306 514 338 525 381 477 405 451 357Z",
				fill: t
			}),
			/* @__PURE__ */ g("circle", {
				cx: "484",
				cy: "344",
				r: "27",
				fill: "#694a2a"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "484",
				cy: "344",
				r: "17",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M214 384 261 399 244 450 211 489 181 462Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m211 400 28 9-27 58-20-12Z",
				fill: "#d7ac61",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m187 455 56 17-8 20-55-18Z",
				fill: "#a07c42"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "201",
				cy: "488",
				r: "24",
				fill: n
			}),
			/* @__PURE__ */ g("circle", {
				cx: "201",
				cy: "488",
				r: "14",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M179 489 220 508 188 557 162 608 117 594 138 546Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m180 511 17 8-35 64-20-4Z",
				fill: "#d8aa58",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m161 530-11 26 14 9-14 19m38-59-8 23",
				fill: "none",
				stroke: "#73512b",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m121 588 42 15-9 24-41-17Z",
				fill: "#9d743a"
			}),
			/* @__PURE__ */ g("path", {
				d: "M116 610 103 616 97 644 113 674 145 684 160 669 160 638 146 617Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m108 632 34 11 8-6m-43 10 34 10m-29 6 23 7m-8-52-4 16m13-13-2 15",
				fill: "none",
				stroke: "#67452a",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m111 620 12 4-3 9-14-3",
				fill: r,
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M496 392 527 376 556 411 570 433 543 465 511 443 489 417Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m510 398 29 28-16 13m13-33 21 24",
				fill: "none",
				stroke: r,
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "554",
				cy: "443",
				r: "23",
				fill: n
			}),
			/* @__PURE__ */ g("circle", {
				cx: "554",
				cy: "443",
				r: "14",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M558 420 604 387 633 348 666 370 648 415 585 457 567 448Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m584 422 39-27 23-35m-46 64 38-26",
				fill: "none",
				stroke: r,
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "m625 350 37 25 12-21-34-23Z",
				fill: "#a77b3a"
			}),
			/* @__PURE__ */ g("path", {
				d: "M640 333 630 313 635 299 650 296 655 281 672 278 684 288 697 289 706 307 701 328 681 354 657 353Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m643 304 17 12 15 5m-15-29 16 15 12 2m-1-13 10 13m-50 14 18 18 16-8m-22-15-4 16",
				fill: "none",
				stroke: "#66452b",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M304 295 330 284 413 282 439 297 456 327 462 394 441 441 404 465 335 462 299 435 280 387 282 333Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M305 310 335 301 330 341 306 387 314 430 296 411 289 375 290 337Z",
				fill: "#e3bc66",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M427 310 444 330 450 393 430 435 413 447 427 397 424 349Z",
				fill: "#754a27",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m311 308 21-7m85 1 17 8M293 350l-2 24m156-33 3 33",
				fill: "none",
				stroke: r,
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "373",
				cy: "380",
				r: "67",
				fill: "#67492b"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "373",
				cy: "380",
				r: "58",
				fill: `url(#${e}-glass)`,
				stroke: "#d1a14d",
				strokeWidth: "7"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "373",
				cy: "380",
				r: "6",
				fill: "#d8ab5d"
			}),
			/* @__PURE__ */ g("path", {
				d: "m373 380-36-21 37 13 37-11 7 8-42 17Z",
				fill: "#d2a04a"
			}),
			/* @__PURE__ */ g("path", {
				d: "m329 342 12 5m-19 31 13 1m8 35 8-9m36 21v-12m29-16-11-5m13-34-11 5",
				stroke: "#d6dce0",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M338 335q38-23 69 10",
				fill: "none",
				stroke: "#edf3e5",
				strokeWidth: "4",
				opacity: ".6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m313 434 17 14-8 29-13-7-13-28Zm112 1 17-6 7 15-15 32-14-5Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m335 450 30 9-4 22-27-3Zm52 9 26-6 1 23-24 7Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M347 266 393 266 391 298 349 298Z",
				fill: "#292725"
			}),
			/* @__PURE__ */ g("path", {
				d: "m351 272 39 1m-39 11 38 0",
				stroke: "#9f7a3f",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m337 295 66 0 10 15-81 3Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M329 157 350 145 390 145 415 163 423 218 407 249 386 272 352 273 329 250 316 216Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m332 166 16-9 8 34-18 20-12-7Zm61-12 17 16 6 33-16 12-20-24Z",
				fill: "#8d5b29"
			}),
			/* @__PURE__ */ g("path", {
				d: "m357 150 24 0 4 32-26 0Z",
				fill: "#eed18a"
			}),
			/* @__PURE__ */ g("path", {
				d: "m334 217 16 19 37 0 17-20-4 31-15 17-29 1-18-21Z",
				fill: "#a77234"
			}),
			/* @__PURE__ */ g("path", {
				d: "m349 244 39-1-3 16-32 1Z",
				fill: "#b88d4b",
				stroke: "#594127"
			}),
			/* @__PURE__ */ g("path", {
				d: "m321 215-8 3 11 29 10-2m79-31 13 2-13 29-9-3",
				fill: "#d7d6b7"
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "347",
				cy: "204",
				rx: "17",
				ry: "20",
				fill: "#282d2e"
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "389",
				cy: "204",
				rx: "17",
				ry: "20",
				fill: "#282d2e"
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "347",
				cy: "204",
				rx: "10",
				ry: "12",
				fill: "#a4e5ef",
				stroke: "#e9f4e4",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "389",
				cy: "204",
				rx: "10",
				ry: "12",
				fill: "#a4e5ef",
				stroke: "#e9f4e4",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "m369 202-6 23 13 0m-13 23 15-1M328 177l10-8m66 1 8 10",
				fill: "none",
				stroke: "#5e402a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M247 281 226 273 207 291 182 348 185 378 213 374 225 337 250 315Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m228 285-14 9-21 53 4 14 11-1 13-35 16-17m6-22 3 18",
				fill: "none",
				stroke: r,
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M486 274 501 265 524 284 554 339 558 369 530 376 515 337 483 312Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m500 279 15 17 22 49 2 18m-45-65 21 28",
				fill: "none",
				stroke: r,
				strokeWidth: "5"
			}),
			[
				[304, 322],
				[435, 321],
				[209, 361],
				[539, 356],
				[341, 456],
				[405, 455],
				[241, 705],
				[501, 703]
			].map(([e, t]) => /* @__PURE__ */ g("circle", {
				cx: e,
				cy: t,
				r: "4",
				fill: "#ead095",
				stroke: "#68512f",
				strokeWidth: "2"
			}, e + "," + t))
		]
	});
}
function de({ id: e }) {
	return /* @__PURE__ */ _("g", {
		stroke: "#4a3a3c",
		strokeWidth: "2.2",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M558 562C640 588 699 667 664 737 640 785 555 805 506 862 469 906 444 946 401 932 365 922 388 862 422 826 473 774 543 746 574 709 598 682 577 661 549 659Z",
				fill: `url(#${e}-tail)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M649 681q3 44-48 68l-45 26 15-36 16-30-9-32 8-24q40 4 63 28",
				fill: "#a44c2b",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M464 804q-36 32-60 69c-18 28-10 51 5 54 22-11 32-50 56-71l47-37Z",
				fill: "#f3c27c",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M475 463C512 427 553 429 572 454L617 491 644 493 617 525 584 532 646 559 665 601 641 632 611 598 575 581 589 627 571 653 545 619 531 564 479 530Z",
				fill: `url(#${e}-pink)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m529 467 44 61-5-66 33 32-18 35m2 18 47 41 12 30M562 568l9 52",
				fill: "none",
				stroke: "#ed8cad",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "m535 512 35 20-26 29-29-35Z",
				fill: "#8d315b"
			}),
			/* @__PURE__ */ g("path", {
				d: "M355 662C326 683 313 708 294 730L255 751 272 785 317 770C347 749 382 709 402 675Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M374 684C360 714 332 748 313 757l-31 13 20-29 36-47Z",
				fill: "#cd8855",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M285 741 314 768C299 810 282 838 248 853L219 845 224 824 257 787Z",
				fill: `url(#${e}-violet)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m266 782 19 15-21 30-23 13m24-86 19 18",
				fill: "none",
				stroke: "#a6aec6",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M235 744C210 725 184 730 170 754L158 796 133 821 138 852 154 859 180 838 198 793 223 791 246 765Z",
				fill: `url(#${e}-black)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m184 753-13 49-25 31m39-79 30 6",
				fill: "none",
				stroke: "#7b8495",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m141 846 16 3 20-22",
				fill: "none",
				stroke: "#17232e",
				strokeWidth: "8"
			}),
			/* @__PURE__ */ g("path", {
				d: "M468 665C467 718 446 745 449 785L463 831 506 822 510 785C529 748 546 708 540 675Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M512 689C508 729 484 753 487 782l-1 43 20-10 4-39 25-65Z",
				fill: "#c2865c",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M448 767 514 777 511 818 532 846 510 891 484 894 465 868 452 815Z",
				fill: `url(#${e}-violet)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M458 778q-6 36 13 62l12 28 16 13m-16-97 12 37",
				fill: "none",
				stroke: "#abb7cd",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M512 851 540 859 547 885 527 905 513 925 481 925 464 912 469 887 484 878Z",
				fill: `url(#${e}-black)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m474 900 18 7 31-6 13-12m-38-15 23 5",
				fill: "none",
				stroke: "#8594a1",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M380 466C422 446 468 465 487 487L523 559 562 638 542 697 510 710 462 694 414 678 371 679 330 704 341 662 376 606 382 561Z",
				fill: `url(#${e}-white)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M425 528C441 557 441 584 459 615l48 44 30 22-25 13-51-17-32-28-29-73Z",
				fill: "#aeb4c1",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m407 617-40 62 46-10 28 14 5-27m62-37 35 43-5 18",
				fill: "none",
				stroke: "#a8a3b6",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m383 585-29 38 15 37 40-26 18-46Zm109-24 35 21 35 55-27-16-29-18-19 25-20-49Z",
				fill: `url(#${e}-pink)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m367 630 30-23m104-25 29 23",
				fill: "none",
				stroke: "#ec8aaf",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M310 453C293 472 279 508 255 535L214 576 190 625 219 641 263 593 302 568 337 501Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M298 489C287 524 265 550 238 571l-30 58 11 3 43-45 39-24 28-54Z",
				fill: "#c98556",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m260 550 22-18m-57 63 15-22",
				fill: "none",
				stroke: "#ffe0a0",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M201 605 227 620 216 648 189 636Z",
				fill: `url(#${e}-gold)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m200 615 15 9-9 15-15-8Z",
				fill: "#986431"
			}),
			/* @__PURE__ */ g("path", {
				d: "M192 632 174 643 147 645 116 656 91 660 90 668 111 671 133 663 125 678 107 687 112 694 132 687 150 672 143 696 131 712 138 717 154 703 169 678 168 699 160 714 168 719 178 704 185 681 190 663 207 648Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m150 665 22-7 12 2m-51 6 14-7m26 23 6-14m-22 33 9-22",
				fill: "none",
				stroke: "#aa6f4c",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M503 348C535 349 548 367 564 382L593 377 628 342 651 299 680 305 678 348 646 398C628 427 608 448 584 447L532 424 498 398Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M532 383q15 25 48 37c25 3 39-17 56-35l29-44-4 28-24 38q-24 36-49 31l-49-20Z",
				fill: "#cc8554",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m565 403 22 7 24-16m22-34 14-26",
				fill: "none",
				stroke: "#ffde99",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ g("path", {
				d: "M652 310 641 292 646 272 655 262 668 265 674 278 684 278 693 291 690 308 677 329 662 328Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m652 279 12 13 14 4m-9-24 10 13m-23 14 10 9 18-7",
				fill: "none",
				stroke: "#a36a48",
				strokeWidth: "2.8"
			}),
			/* @__PURE__ */ g("path", {
				d: "M389 386 415 366 452 371 471 424 489 468 469 513 403 541 360 506 340 443Z",
				fill: `url(#${e}-pink)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M363 414 383 410 410 488 445 493 473 458 481 475 461 519 401 535 365 502Z",
				fill: "#9a365e",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M383 404 414 394 438 439 476 414 484 445 460 480 420 491 396 474Z",
				fill: `url(#${e}-white)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M295 404C306 375 334 367 359 384 380 397 392 426 379 454L348 479 316 473C297 461 284 431 295 404Z",
				fill: `url(#${e}-white)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M310 397q-14 36 13 57l29 11-8 13-29-7q-30-21-25-50Z",
				fill: "#afb8bc",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m327 382-4 28 14 26m32-25 2 25-9 16",
				fill: "none",
				stroke: "#e7e9df",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M462 336C490 317 520 329 533 354L542 385 529 417 509 427 480 410 463 381Z",
				fill: `url(#${e}-white)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m474 346 8 34 25 23 22 3-13 14-29-15-16-25Z",
				fill: "#a3adb7",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m509 337 12 22-3 21m-20-44-8 24",
				fill: "none",
				stroke: "#f6f7e8",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M373 363 376 395 399 416 441 414 456 397 431 355Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m385 372 9 23 33 10 15-7-15-29Z",
				fill: "#cc8a56",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m394 408 11 22 15-7-9-18Z",
				fill: `url(#${e}-gold)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m381 503 95-38 15 17-104 40Z",
				fill: `url(#${e}-gold)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m395 530 86-31 16 36-84 26Z",
				fill: `url(#${e}-gold)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m403 540 83-28m-77 39 83-27",
				stroke: "#f3d47d",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M489 496 525 502 535 533 511 554 475 543 474 514Z",
				fill: `url(#${e}-gold)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m502 531 60 25-10 36-39-26 13 55-27 3-11-81Z",
				fill: `url(#${e}-gold)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m511 550 28 24m-34-30 5 48",
				fill: "none",
				stroke: "#f5dc8b",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M324 247 373 197 408 171 415 204 436 226 419 260Z",
				fill: "#8c4d31"
			}),
			/* @__PURE__ */ g("path", {
				d: "m352 228 44-38 8 36-31 10Z",
				fill: "#da9c4c",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M272 271 247 229 202 220 224 268 261 300Z",
				fill: "#955137"
			}),
			/* @__PURE__ */ g("path", {
				d: "m250 250-33-21 23 36Z",
				fill: "#e2a65e",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M272 268C261 302 266 353 286 379L314 405 349 413 379 399 410 368 420 334 408 279 358 252Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M385 296C403 318 400 349 386 370l-31 25-28 6 20 9 28-12 29-27 14-36-11-48Z",
				fill: "#cf8d56",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M257 319C235 297 245 258 267 233L298 213 335 208 371 219 404 244 433 256 461 252 449 270 481 261 467 285 493 282 473 306 448 312 470 326 431 328 414 316 421 348 410 374 390 385 389 354 376 338 382 294 362 258 356 310 333 332 329 286 308 320 301 287 288 325 274 351 256 368 263 341Z",
				fill: `url(#${e}-green)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M266 293q0-45 39-64m-14 55 15-46 12 43m9-60 10 53 9 26m9-74 33 35 8 43m5-57 31 28 24 9m-29 17 28 9m-47 1 12 16m-145 15-2 28",
				fill: "none",
				stroke: "#b0cf70",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "m274 242 19-15-8 35m66-40 17 24 10 36m32-19 31 27-27-10m-22 54 13 18-5 23",
				fill: "none",
				stroke: "#326b50",
				strokeWidth: "4"
			})
		]
	});
}
function fe({ base: e, id: t }) {
	return /* @__PURE__ */ _("g", {
		transform: "scale(.2425876)",
		children: [/* @__PURE__ */ _("defs", { children: [
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-skin`,
				x1: ".12",
				y1: ".1",
				x2: ".9",
				y2: ".8",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#ffe2a1" }),
					/* @__PURE__ */ g("stop", {
						offset: ".35",
						stopColor: "#e8b77e"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".7",
						stopColor: "#d7975d"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#a26747"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-hair`,
				x1: "0",
				y1: "0",
				x2: ".8",
				y2: "1",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#d9c798" }),
					/* @__PURE__ */ g("stop", {
						offset: ".35",
						stopColor: "#9b7e50"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".7",
						stopColor: "#6c5136"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#382f2c"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-blue`,
				x1: "0",
				x2: "1",
				y2: ".7",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#22395e" }),
					/* @__PURE__ */ g("stop", {
						offset: ".38",
						stopColor: "#416db6"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".63",
						stopColor: "#31518d"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#142747"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-red`,
				x1: "0",
				x2: "1",
				y2: ".7",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#d85540" }),
					/* @__PURE__ */ g("stop", {
						offset: ".5",
						stopColor: "#ac3536"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#592337"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-gold`,
				x1: "0",
				x2: "1",
				y2: ".65",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#f9dd83" }),
					/* @__PURE__ */ g("stop", {
						offset: ".3",
						stopColor: "#dfb557"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".6",
						stopColor: "#ac7b32"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".78",
						stopColor: "#e5c472"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#6f4c2b"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-silver`,
				x1: "0",
				x2: "1",
				y2: ".7",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#3b4b58" }),
					/* @__PURE__ */ g("stop", {
						offset: ".35",
						stopColor: "#dae3df"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".5",
						stopColor: "#b1c0c3"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#45566c"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-bronze`,
				x1: "0",
				x2: "1",
				y2: ".45",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#4e361f" }),
					/* @__PURE__ */ g("stop", {
						offset: ".2",
						stopColor: "#b17b36"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".4",
						stopColor: "#e3b863"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".53",
						stopColor: "#c38e43"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".78",
						stopColor: "#855527"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#3f2e25"
					})
				]
			}),
			/* @__PURE__ */ _("radialGradient", {
				id: `${t}-glass`,
				cx: ".35",
				cy: ".25",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#c3d8de" }),
					/* @__PURE__ */ g("stop", {
						offset: ".6",
						stopColor: "#8999bc"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#5b627c"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-green`,
				x1: ".15",
				y1: "0",
				x2: ".9",
				y2: "1",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#8ec574" }),
					/* @__PURE__ */ g("stop", {
						offset: ".36",
						stopColor: "#67a35d"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".7",
						stopColor: "#377f60"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#285049"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-white`,
				x1: ".1",
				y1: ".1",
				x2: ".8",
				y2: "1",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#fff5d6" }),
					/* @__PURE__ */ g("stop", {
						offset: ".5",
						stopColor: "#e0e2d7"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#929eaf"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-pink`,
				x1: "0",
				x2: "1",
				y2: ".8",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#e47999" }),
					/* @__PURE__ */ g("stop", {
						offset: ".4",
						stopColor: "#c84e7c"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#6b294c"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-violet`,
				x1: "0",
				x2: "1",
				y2: ".6",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#b7bfdb" }),
					/* @__PURE__ */ g("stop", {
						offset: ".4",
						stopColor: "#8e98b6"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#455779"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-black`,
				x1: "0",
				x2: "1",
				y2: "1",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#697a8c" }),
					/* @__PURE__ */ g("stop", {
						offset: ".4",
						stopColor: "#354c66"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#1e293a"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-tail`,
				x1: ".2",
				y1: ".8",
				x2: ".7",
				y2: ".2",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#f7df9c" }),
					/* @__PURE__ */ g("stop", {
						offset: ".3",
						stopColor: "#cd8040"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".65",
						stopColor: "#b15a30"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#6b3c30"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-purple`,
				x1: "0",
				x2: "1",
				y2: ".7",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#b09ac8" }),
					/* @__PURE__ */ g("stop", {
						offset: ".32",
						stopColor: "#80649d"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".65",
						stopColor: "#53406f"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#302c55"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-inkhair`,
				x1: ".1",
				y1: ".1",
				x2: ".9",
				y2: ".7",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#665d75" }),
					/* @__PURE__ */ g("stop", {
						offset: ".25",
						stopColor: "#393345"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".65",
						stopColor: "#252b3a"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#151c29"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-chestnut`,
				x1: "0",
				y1: "0",
				x2: ".7",
				y2: "1",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#d0ad68" }),
					/* @__PURE__ */ g("stop", {
						offset: ".35",
						stopColor: "#947043"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".7",
						stopColor: "#64452f"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#39332b"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-linen`,
				x1: "0",
				x2: "1",
				y2: ".7",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#eee0ad" }),
					/* @__PURE__ */ g("stop", {
						offset: ".3",
						stopColor: "#d0c99e"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".7",
						stopColor: "#a29e75"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#6b725a"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-leather`,
				x1: "0",
				x2: "1",
				y2: ".6",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#986445" }),
					/* @__PURE__ */ g("stop", {
						offset: ".25",
						stopColor: "#754a38"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".7",
						stopColor: "#482b2e"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#2a242b"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-plumhair`,
				x1: "0",
				y1: "0",
				x2: "1",
				y2: ".8",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#c28b86" }),
					/* @__PURE__ */ g("stop", {
						offset: ".3",
						stopColor: "#a16369"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".65",
						stopColor: "#784250"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#482f41"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-skirtgreen`,
				x1: ".1",
				y1: "0",
				x2: ".7",
				y2: "1",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#d5e1b3" }),
					/* @__PURE__ */ g("stop", {
						offset: ".32",
						stopColor: "#9ab98a"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".68",
						stopColor: "#619583"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#345958"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-wine`,
				x1: "0",
				x2: "1",
				y2: ".8",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#ad5c59" }),
					/* @__PURE__ */ g("stop", {
						offset: ".3",
						stopColor: "#7e3841"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".65",
						stopColor: "#632d36"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#30262e"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-fur`,
				x1: "0",
				y1: "0",
				x2: ".8",
				y2: "1",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#f4dfaf" }),
					/* @__PURE__ */ g("stop", {
						offset: ".4",
						stopColor: "#cdaf7c"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".75",
						stopColor: "#997352"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#694c3e"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-cape`,
				x1: "0",
				x2: "1",
				y2: ".8",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#beda74" }),
					/* @__PURE__ */ g("stop", {
						offset: ".35",
						stopColor: "#9ac44b"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".7",
						stopColor: "#6b9c46"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#405d36"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-warmmetal`,
				x1: "0",
				x2: "1",
				y2: ".8",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#eee6be" }),
					/* @__PURE__ */ g("stop", {
						offset: ".3",
						stopColor: "#d6ba7a"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".55",
						stopColor: "#aa8551"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".7",
						stopColor: "#c7a970"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#6d4c36"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-blond`,
				x1: ".1",
				y1: "0",
				x2: ".8",
				y2: "1",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#f8d797" }),
					/* @__PURE__ */ g("stop", {
						offset: ".35",
						stopColor: "#d4a76b"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".65",
						stopColor: "#b17b47"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#785336"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-olive`,
				x1: "0",
				x2: "1",
				y2: ".7",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#b4ae6b" }),
					/* @__PURE__ */ g("stop", {
						offset: ".35",
						stopColor: "#8e9451"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".65",
						stopColor: "#62713e"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#303f2c"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-greyhair`,
				x1: "0",
				x2: "1",
				y2: "1",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#b7c7c2" }),
					/* @__PURE__ */ g("stop", {
						offset: ".4",
						stopColor: "#829992"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#475e5b"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-elderskin`,
				x1: "0",
				x2: "1",
				y2: ".7",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#e8c48c" }),
					/* @__PURE__ */ g("stop", {
						offset: ".45",
						stopColor: "#c59662"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#95613f"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-porcelain`,
				x1: "0",
				x2: "1",
				y2: ".7",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#f2f1dc" }),
					/* @__PURE__ */ g("stop", {
						offset: ".35",
						stopColor: "#c7cfbd"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".65",
						stopColor: "#a4b0a7"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#64758a"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-cyberskin`,
				x1: "0",
				x2: "1",
				y2: ".8",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#ddd3aa" }),
					/* @__PURE__ */ g("stop", {
						offset: ".4",
						stopColor: "#c0b18b"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#898575"
					})
				]
			})
		] }), e === 1 ? /* @__PURE__ */ g(le, { id: t }) : e === 8 ? /* @__PURE__ */ g(ue, { id: t }) : e === 9 ? /* @__PURE__ */ g(de, { id: t }) : e === 10 ? /* @__PURE__ */ g(ce, { id: t }) : /* @__PURE__ */ g(se, {
			base: e,
			id: t
		})]
	});
}
//#endregion
//#region src/games/customheroes/companion-art.tsx
function Y({ id: e }) {
	return /* @__PURE__ */ _("g", {
		stroke: "#263d31",
		strokeWidth: "1.5",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M28 57C10 48 8 33 4 25l-1 27 11 8-9 8 23 8m58-17 24-23 4 24-11 1 10 12-24 7",
				fill: "#3f6450"
			}),
			/* @__PURE__ */ g("path", {
				d: "m9 41 9 14 7 8m78-10-14 13",
				fill: "none",
				stroke: "#7caa72"
			}),
			/* @__PURE__ */ g("path", {
				d: "M83 85c26-3 33 11 27 23-4 8-19 8-30 3l9-11q16 4 15-4-3-4-13 0",
				fill: `url(#${e}-green)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M36 56C21 68 21 91 35 105q18 12 42-1c17-17 13-39-1-51Z",
				fill: `url(#${e}-green)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M45 65c-7 12-8 30 3 40q10 5 20-1c8-10 10-26 1-41Z",
				fill: "#a0b77c"
			}),
			/* @__PURE__ */ g("path", {
				d: "M43 75q13 7 27 0m-26 10q12 6 26 0m-24 9q10 5 21 0",
				fill: "none",
				stroke: "#526e48"
			}),
			/* @__PURE__ */ g("path", {
				d: "M30 65c-11 4-17 15-14 24 3 9 14 7 20-2l6-15m35-2c11 5 15 16 12 23-6 7-16 2-18-7",
				fill: `url(#${e}-green)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M37 92c-12 0-17 11-13 21l10 8 10-4 3-15m26-9c14-3 24 12 17 23l-12 4-12-10Z",
				fill: `url(#${e}-green)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m27 111 4 7 3-7m6 0 2 7m32-1 1-7m7 1 3 6",
				stroke: "#e2dfb0",
				fill: "none",
				strokeWidth: "2.2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M22 31c-2-12 7-23 23-25 19-4 39 4 47 19l3 22c-4 18-23 27-40 25-24 0-39-16-33-41Z",
				fill: `url(#${e}-green)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M25 24q-12-11-15-23c1 16 2 26 10 34l12-3m51-12q4-13 0-24c10 10 14 21 12 31Z",
				fill: "#a8ac77"
			}),
			/* @__PURE__ */ g("path", {
				d: "m17 14 7 13m64-17 2 12",
				fill: "none",
				stroke: "#e3d7a2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M22 36c-8-13 6-21 17-17 8 4 10 17 6 24-7 6-17 2-23-7Zm48-12c6-9 18-7 22 1 3 10-3 17-11 18-11 0-16-10-11-19Z",
				fill: "#172b2a"
			}),
			/* @__PURE__ */ g("path", {
				d: "M26 22q8-5 15 3M75 25q7-7 13-1",
				fill: "none",
				stroke: "#749488",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "30",
				cy: "27",
				rx: "3.4",
				ry: "4",
				fill: "#c7dfd7",
				stroke: "none"
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "80",
				cy: "26",
				rx: "3",
				ry: "3.5",
				fill: "#dae7cc",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M35 47q20-11 40-2 6 8 1 15c-13 9-31 8-41-1-4-4-5-9 0-12Z",
				fill: "#88b955",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m42 48 2 2m21-3 2 2M42 60q13 5 26-1",
				fill: "none",
				stroke: "#3e603c"
			}),
			/* @__PURE__ */ g("path", {
				d: "m44 11 4 5 4-8 7 5 4-5m-14 13 5 4",
				fill: "none",
				stroke: "#6b8c3e",
				strokeWidth: "2"
			})
		]
	});
}
function pe({ id: e }) {
	return /* @__PURE__ */ _("g", {
		stroke: "#9b2834",
		strokeWidth: "1.5",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M34 71C15 63 20 49 14 43c-3 18-11 14-10 29 1 9 9 12 16 7 5 15 21 17 26 6Z",
				fill: "#ffbc38",
				stroke: "#eb7328"
			}),
			/* @__PURE__ */ g("path", {
				d: "M79 68c20-15 24-32 37-40-3 15-8 27-20 38l-13 11Z",
				fill: `url(#${e}-red)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M48 56c-17 7-18 30-8 47 8 14 27 19 39 11 16-10 14-32 4-45L68 55Z",
				fill: `url(#${e}-red)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M46 71c-6 12 0 29 10 35l10 3c-13-12-18-24-13-37Z",
				fill: "#a91630",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M46 67q4-6 10-3l-3 11-9-2Z",
				fill: "#ffd855",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M39 68c-11 7-17 18-18 32 5-6 8-15 18-18m35 2c7 10 13 22 28 29-12 0-22-7-29-17",
				fill: `url(#${e}-red)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M67 99q12 22 38 22c-15 10-36 3-44-12m-12-4c-3 13 0 20 10 25-15 1-23-9-21-22",
				fill: `url(#${e}-red)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M63 84c12-4 21 9 16 19-7 7-18-3-19-11Z",
				fill: "#d7423e"
			}),
			/* @__PURE__ */ g("path", {
				d: "M42 28C35 17 43 1 58-8c6-2 3 10-1 16l-8 20m11 8c11-11 24-13 35-10 4 4-17 13-31 15",
				fill: `url(#${e}-red)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M44 23q0-14 12-25m10 35 22-4",
				fill: "none",
				stroke: "#79162e",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M37 33c1-13 18-20 29-11 8 8 13 22 7 31-6 10-18 12-28 5-11-7-14-16-8-25Z",
				fill: `url(#${e}-red)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m51 38-5-4 1 8 5 2m11-7 5-4-1 9-4 2",
				fill: "#651b2a",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m55 49 5 2 5-4q-2 12-10 2Z",
				fill: "#931d31",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M58 27q7 0 7 7l-7 1Z",
				fill: "#ffb847",
				stroke: "none"
			})
		]
	});
}
function me({ id: e }) {
	return /* @__PURE__ */ _("g", {
		stroke: "#2f3921",
		strokeWidth: "1.5",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M59 73 47 92 31 105l-4 19 9-15 20-13 16-23m-2 8 5 17 18 9 5 15 4-16-16-14-1-18m10 1 14 12 9 1-9-15-4-15",
				fill: "#566137"
			}),
			/* @__PURE__ */ g("path", {
				d: "m42 54-14 9 1 25-14 14m47-42-8 24 8 11m22-29 16 18 12 2",
				fill: "none",
				stroke: "#728141",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M47 38c9-20 41-26 59-7 15 15 14 38-1 51-17 12-44 2-51-15Z",
				fill: `url(#${e}-shell)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M58 30c23-10 43 2 49 19l-2 17c-7-12-24-20-43-19Z",
				fill: "#7a982f"
			}),
			/* @__PURE__ */ g("path", {
				d: "M53 51q24-10 53 6m-50 5q19-8 45 7m-36-44 12 18m-12-21 6 0m16 7 8 9m-18-10 8-1m-14 24q-3 17 5 28",
				fill: "none",
				stroke: "#344a24",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M75 23 83 9 87 26l12 2 12-17-4 23 10 12-1 11-12-16m-37-15 1-14 7 12",
				fill: "#a3ac57"
			}),
			/* @__PURE__ */ g("path", {
				d: "M20 29C9 21 4 11 1 1c2 19 9 34 23 42l18-8Z",
				fill: `url(#${e}-horn)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m8 16 16 18",
				fill: "none",
				stroke: "#bbc38b",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M29 27c10-8 27-7 33 5 7 13-2 29-15 35-12 5-26-2-28-14-3-12 1-20 10-26Z",
				fill: `url(#${e}-shell)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M20 38c-13 6-8 20 3 26l15-1 6-13Z",
				fill: "#7e9542"
			}),
			/* @__PURE__ */ g("path", {
				d: "M23 37q12 5 24-4l-5 13-18-1Z",
				fill: "#d5d894"
			}),
			/* @__PURE__ */ g("path", {
				d: "m27 37 11 3-6 6",
				fill: "#202e24"
			}),
			/* @__PURE__ */ g("path", {
				d: "M41 27 48 13 53 9 53 28m-7 35 5 8 7-13",
				fill: "#818d45"
			}),
			/* @__PURE__ */ g("path", {
				d: "M26 53q9 2 14-3M49 31q7 4 7 13",
				fill: "none",
				stroke: "#c5ca7b"
			})
		]
	});
}
function he({ id: e }) {
	return /* @__PURE__ */ _("g", {
		stroke: "#27203e",
		strokeWidth: "1.3",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M18 50C-2 35 7 18 24 21 4 12 0 3 10-1m58 50c26-12 23-33 5-37 27 1 34-8 26-18M37 81C12 78 2 67 9 59m70 25 20-6 15 5",
				fill: "none",
				stroke: "#b8a8cb",
				strokeWidth: "4",
				opacity: ".65"
			}),
			/* @__PURE__ */ _("g", {
				transform: "translate(70 2) scale(.64)",
				children: [
					/* @__PURE__ */ g("path", {
						d: "M9 24 2 17l9 1C14 7 24 2 34 5l7-5 1 9c11 4 14 14 10 24l7 7-9-1c-11 15-35 17-42 0l-8 2 7-8Z",
						fill: `url(#${e}-purple)`
					}),
					/* @__PURE__ */ g("path", {
						d: "m13 20 12 4-1 12-9-2m18-10 12-6-1 14-9 4",
						fill: "#e5da7b"
					}),
					/* @__PURE__ */ g("path", {
						d: "M15 40q14 7 29-3-7 16-20 12Z",
						fill: "#c9d6ad"
					})
				]
			}),
			/* @__PURE__ */ _("g", {
				transform: "translate(0 21) scale(.9)",
				children: [
					/* @__PURE__ */ g("path", {
						d: "M9 24 2 17l9 1C14 7 24 2 34 5l7-5 1 9c11 4 14 14 10 24l7 7-9-1c-11 15-35 17-42 0l-8 2 7-8Z",
						fill: `url(#${e}-purple)`
					}),
					/* @__PURE__ */ g("path", {
						d: "m13 20 12 4-1 12-9-2m18-10 12-6-1 14-9 4",
						fill: "#e5da7b"
					}),
					/* @__PURE__ */ g("path", {
						d: "M15 40q14 7 29-3-7 16-20 12Z",
						fill: "#c9d6ad"
					}),
					/* @__PURE__ */ g("path", {
						d: "m27 8 4 9 4-11",
						fill: "#34304d"
					})
				]
			}),
			/* @__PURE__ */ g("path", {
				d: "M43 75 34 61l15 3c7-15 28-21 44-10l10-5-2 12c15 12 19 27 9 43l7 7-14-1c-18 18-47 16-57-5l-12 1 7-15Z",
				fill: `url(#${e}-purple)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m51 75 20 6-3 19-16-5m31-16 21-8-3 19-17 8",
				fill: "#e0db81"
			}),
			/* @__PURE__ */ g("path", {
				d: "m61 79 1 17m30-18-3 15",
				fill: "none",
				stroke: "#919e67",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M52 106q22 7 47-6c-6 21-36 27-47 6Z",
				fill: "#c1cc9f"
			}),
			/* @__PURE__ */ g("path", {
				d: "m68 56 4 14 7-17",
				fill: "#34304d"
			}),
			/* @__PURE__ */ g("path", {
				d: "M54 63q9-7 17-4",
				fill: "none",
				stroke: "#9d8ebb",
				strokeWidth: "2.2"
			})
		]
	});
}
function ge({ id: e }) {
	return /* @__PURE__ */ _("g", {
		stroke: "#67413c",
		strokeWidth: "1.3",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M49 73c-7 6-14 10-25 13l-7 11 24-2 8 12 15-9 20 7 20-14-13-10-22-10Z",
				fill: "#4b2533"
			}),
			/* @__PURE__ */ g("path", {
				d: "M49 89c-7 10-7 22-3 30l-6 14 11-11 9-19m9-11c10 4 17 14 13 23l-8 7-4-15-9-8Z",
				fill: `url(#${e}-white)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M49 47c-8 1-12 12-19 15L8 60l-5 3 23 5 12-3 13-10m25-9c6 0 11 7 17 8l8-9-1-11 4-5 4 5-2 15-9 13-13-4-11-6",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M52 45 70 43l7 22 13 18-24 8-24-6 9-18Z",
				fill: `url(#${e}-red)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m53 50 7 12 10-15m-11 14-3 12 15-2",
				fill: "none",
				stroke: "#e1b15e",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M60 76c-14-11-21-5-20 2 3 6 14 8 20 3l5-4c-1-10 16-11 20-3 1 8-11 11-17 6l-5-3-7 17 6-2 3-11 4 11 12 3-10-18",
				fill: "#b83136"
			}),
			/* @__PURE__ */ g("path", {
				d: "M43 76q8-2 14 3m15-3 10-2m-22 9-9 7m17-6 7 7",
				fill: "none",
				stroke: "#ee7b64"
			}),
			/* @__PURE__ */ g("path", {
				d: "M36 21 20 6 21 25 31 35m43-17L95 4 90 26 78 35",
				fill: "#9b603d"
			}),
			/* @__PURE__ */ g("path", {
				d: "m24 13 9 11-8 2m56-5 10-10-5 15",
				fill: "#da9b6d",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M35 26c-3 11 2 25 12 30 8 4 21 0 26-9 5-7 5-17 0-25Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M36 41c-12 3-17-6-12-14-5-11 5-20 14-19 5-9 16-8 23-2 12-3 20 5 20 14 12 5 12 19 3 25 1 10-10 16-18 10l6-12c8-3 6-12 0-14-5-1-8-7-8-13-2 14-11 21-20 15l-7-7c3 11-1 17-7 18Z",
				fill: `url(#${e}-hair)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M31 20q-8 2-5 9 1 7 10 2m9-22c-11 3-9 16 0 18 8 2 14-7 8-10m12-6q13 2 10 15m2 6q12-3 11 6c-1 5-7 7-11 2",
				fill: "none",
				stroke: "#e0b79b",
				strokeWidth: "2"
			})
		]
	});
}
function _e({ ability: e }) {
	let t = n().replaceAll(":", "") + "companion", r = e === "kodora" ? /* @__PURE__ */ g(Y, { id: t }) : e === "burny" ? /* @__PURE__ */ g(pe, { id: t }) : e === "edge" ? /* @__PURE__ */ g(me, { id: t }) : e === "spector" ? /* @__PURE__ */ g(he, { id: t }) : e === "charmy" ? /* @__PURE__ */ g(ge, { id: t }) : null;
	return /* @__PURE__ */ _("g", {
		transform: "scale(.48)",
		children: [/* @__PURE__ */ _("defs", { children: [
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-green`,
				x1: "0",
				y1: "0",
				x2: "100%",
				y2: "100%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#c0df7c" }),
					/* @__PURE__ */ g("stop", {
						offset: ".4",
						stopColor: "#78b755"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#285a42"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-shell`,
				x1: "0",
				y1: "0",
				x2: "100%",
				y2: "80%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#b7ca68" }),
					/* @__PURE__ */ g("stop", {
						offset: ".45",
						stopColor: "#7b9638"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".7",
						stopColor: "#465e2d"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#242e23"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-horn`,
				x2: "60%",
				y2: "100%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#e4dca6" }),
					/* @__PURE__ */ g("stop", {
						offset: ".5",
						stopColor: "#8c9061"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#39472a"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-red`,
				x2: "100%",
				y2: "80%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#fa6a5f" }),
					/* @__PURE__ */ g("stop", {
						offset: ".4",
						stopColor: "#dc313e"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#8e1830"
					})
				]
			}),
			/* @__PURE__ */ _("radialGradient", {
				id: `${t}-purple`,
				cx: ".35",
				cy: ".2",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#8a70ac" }),
					/* @__PURE__ */ g("stop", {
						offset: ".5",
						stopColor: "#57436f"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#241c3f"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-skin`,
				x2: "100%",
				y2: "100%",
				children: [/* @__PURE__ */ g("stop", { stopColor: "#ffe6b5" }), /* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#ca936b"
				})]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-white`,
				x2: "100%",
				y2: "100%",
				children: [/* @__PURE__ */ g("stop", { stopColor: "#faf1da" }), /* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#8e859a"
				})]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-hair`,
				x2: "100%",
				y2: "100%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#dcc0a5" }),
					/* @__PURE__ */ g("stop", {
						offset: ".5",
						stopColor: "#ac826b"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#75524d"
					})
				]
			})
		] }), r]
	});
}
//#endregion
//#region src/games/customheroes/equipment-art.tsx
function ve({ value: e, id: t }) {
	let n = `url(#${t}-steel)`, r = `url(#${t}-gold)`, i = `url(#${t}-wood)`, a = `url(#${t}-red)`;
	switch (e) {
		case -1: return /* @__PURE__ */ _("g", {
			transform: "translate(0 105) rotate(-18 50 45)",
			children: [
				/* @__PURE__ */ g("path", {
					d: "M5 19 20 13 31 17 76 13 91 23 98 42 88 60 72 64 28 69 11 57 2 39Z",
					fill: "#b5b17b"
				}),
				/* @__PURE__ */ g("path", {
					d: "m10 24 9 30 67 2 5-24m-73-6-5 16 9 17m59-32 6 16-7 13",
					fill: "none",
					stroke: "#e3d4a0",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ g("path", {
					d: "M20 24c9-10 52-12 64-2 10 7 10 24 0 32-17 10-48 10-64 2-11-7-10-25 0-32Z",
					fill: `url(#${t}-bun)`
				}),
				/* @__PURE__ */ g("path", {
					d: "M26 27c15-6 38-8 51-3 11 4 12 14 5 22-13 11-42 13-55 5-11-4-12-17-1-24Z",
					fill: "#9a3b20"
				}),
				/* @__PURE__ */ g("path", {
					d: "M24 28q30-13 54-1 12 6 1 18-31 13-53 2-10-8-2-19Z",
					fill: "#c66b29"
				}),
				/* @__PURE__ */ g("path", {
					d: "M26 31c7 0 2 7 9 7s2-10 10-9 1 11 8 10 2-11 10-10 0 10 8 9 4-10 10-9",
					fill: "none",
					stroke: "#e5b631",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("path", {
					d: "M24 43q13-7 22 2 11-7 22-1l13-7",
					fill: "none",
					stroke: "#608834",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("path", {
					d: "M19 53q28 15 61-1",
					fill: "none",
					stroke: "#f2ca73",
					strokeWidth: "3"
				})
			]
		});
		case -2: return /* @__PURE__ */ _("g", {
			transform: "translate(0 93) rotate(-20 50 45)",
			children: [
				/* @__PURE__ */ g("path", {
					d: "M12 48 5 31q8-6 16-8l19 5 10-12L75 0q9-2 15 5l4 29-11 8c-1 13 0 22-5 32q-6 10-17 15l-21 1q-8-4-13-12l-12-6Z",
					fill: a,
					stroke: "#77352b",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ g("path", {
					d: "M13 37q12-5 21 3l9 15-12 8-15-5m25-28 15 12-10 16-7-17m15-23 11 20-8 17m6-29 13 19-5 17m-27 11 6 17 15-3 8-15M12 37 22 68l19 15",
					fill: "none",
					stroke: "#e0997a",
					strokeWidth: "1.7"
				}),
				/* @__PURE__ */ g("text", {
					x: "67",
					y: "32",
					transform: "rotate(40 67 32)",
					fill: "#efc79c",
					stroke: "none",
					fontSize: "20",
					fontWeight: "800",
					children: "1"
				}),
				/* @__PURE__ */ g("path", {
					d: "m46 61 15-8m-19 17 15-9m-8-14 7 19m-1-23 8 18",
					stroke: "#f1c8a3",
					strokeWidth: "2"
				})
			]
		});
		case 1: return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "M47 3C28 22 17 51 22 78l21 65 15-3 1-66Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "M46 12 30 64l20 67 5-5-9-70Z",
				fill: "#d4a85d",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M25 68q12 41 24 66m-7-109-8 27m7-7 4 50",
				fill: "none",
				stroke: "#6e4c28",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "m31 138 34-7 5 10-37 9Z",
				fill: "#696343"
			}),
			/* @__PURE__ */ g("path", {
				d: "m41 145 18-3 6 39-14 7-11-5Z",
				fill: "#4d4b32"
			}),
			/* @__PURE__ */ g("path", {
				d: "m43 153 18-1m-17 10 18-1m-17 10 18-1m-12 14 9 18-6 5-12-18Z",
				fill: "none",
				stroke: "#8f8b5a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M58 144c15 10 22 27 21 44l-11-13 2-8-11-15m-9 31-11 18-7-1 15-27",
				fill: "#646748"
			})
		] });
		case 2: return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "M49 145C41 116 20 101 3 106c14-15 29-31 44-23l4-12 6 19 12-1-1 12c19 1 28 21 27 44-11-15-24-19-37-3Z",
				fill: "#242c32"
			}),
			/* @__PURE__ */ g("path", {
				d: "M7 104q19-14 34-12l7 12-13 6-14-3m36-6 11 5 4 14 9-2 12 17",
				fill: "none",
				stroke: "#aaa879",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m45 96 12-3 8 9-5 11-11-1Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "m49 98 8 0 3 7-6 6-4-4Z",
				fill: "#702f64"
			}),
			/* @__PURE__ */ g("path", {
				d: "M48 140 60 138l10 37-11 5-5-7Z",
				fill: "#4e342c"
			}),
			/* @__PURE__ */ g("path", {
				d: "m51 145 11-3m-9 11 11-3m-8 10 12-2m-8 9 11-3",
				stroke: "#caa86b",
				strokeWidth: "2"
			})
		] });
		case 3: return /* @__PURE__ */ _("g", {
			transform: "translate(0 112)",
			children: [
				/* @__PURE__ */ g("path", {
					d: "M12 48C1 31 7 13 23 10L38 3 56 12 79 5 94 9 98 46 84 65 36 66Z",
					fill: "#5b4b2c"
				}),
				/* @__PURE__ */ g("path", {
					d: "M76 10 89 8 94 17 91 51 80 63 65 57Z",
					fill: "#a4512e"
				}),
				/* @__PURE__ */ g("path", {
					d: "m82 12-8 42m14-40-6 41m-3-22 10 3",
					fill: "none",
					stroke: "#dca15e",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ g("path", {
					d: "M12 31c-5-12 1-22 10-22 10 1 18 16 14 23-4 8-19 7-24-1Zm24-14c-1-13 11-18 20-9 5 6 8 17 2 21-9 4-21-4-22-12Zm-16 26c3-10 21-13 29-4 5 5 4 15-5 18-13 5-27-4-24-14Z",
					fill: r
				}),
				/* @__PURE__ */ g("path", {
					d: "m15 18 12 13m17-18 9 11m-27 19 15 5M57 33q7 5 10 15m-14 13 16-5",
					fill: "none",
					stroke: "#463d25",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ g("path", {
					d: "M17 8q13-5 18 10m6-14q13-2 17 12",
					fill: "none",
					stroke: "#c6af6f",
					strokeWidth: "2"
				})
			]
		});
		case 4: return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "M20 2c15 18 23 22 29 13l-2 29c17 19 22 42 15 63l-16 33-13-11c18-17 22-33 15-50L34 54 24 46 11 17l18 12Z",
				fill: `url(#${t}-ice)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M19 14 35 42l12 9 12 28-9-34-2-21-10 5Z",
				fill: "#5fc1d3",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M49 93c-22-9-27-5-35 3l2-22c13 2 28 9 36 19Z",
				fill: "#1e4d59"
			}),
			/* @__PURE__ */ g("path", {
				d: "M37 124C21 116 17 107 12 103l-9 9 22 18-21 1 13 10 23 5-11 14 16-8 7 22 8-22 17 13-9-20 15-6-20-4-7-17Z",
				fill: `url(#${t}-ice)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M39 127q10-9 20 3l5 14-13 10-12-7-5-8Z",
				fill: "#255d6c"
			}),
			/* @__PURE__ */ g("path", {
				d: "m40 134 8 0-4 6m10-7 7 6-7 0m-8 9 9 0",
				stroke: "#9cdad5",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m48 152 11 2 6 31-16-8-6-13Z",
				fill: `url(#${t}-ice)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m29 32 21 42m-13 53-16-7m36 30 5 20",
				stroke: "#bbefec",
				fill: "none",
				strokeWidth: "2"
			})
		] });
		case 5: return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "M31 2 59 32 67 120l-17 34-19-25-7-88Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M31 5 39 37 47 122l-14 10-7-90Z",
				fill: "#a2d0cc",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m40 22 13 16 8 78-9 22-9-102Z",
				fill: "#214e68",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M39 132 22 115l-5 8 8 19-21-2 14 13-12 15 22-4 3 17 13-10 12 10 9-17 22 1-13-16 17-12-24 4 4-21-13 15Z",
				fill: "#3b322c"
			}),
			/* @__PURE__ */ g("path", {
				d: "M34 139q15-14 29 0l5 18-7 6-4 13-19-4-7-18Z",
				fill: "#74684c"
			}),
			/* @__PURE__ */ g("path", {
				d: "M37 144 45 146 41 156 35 153m19-7 8 1-1 9-8-1m-5 3-3 7 8 0m-12 3 2 6m5-6 1 7m5-7 1 7",
				fill: "#2b2c28",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ g("path", {
				d: "m46 174 12 0 10 36-15 5-10-10Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m47 180 12-1m-10 9 12-1m-10 9 12-1m-11 9 12-1",
				stroke: "#b49556",
				strokeWidth: "2"
			})
		] });
		case 7: return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "m43 65 11-1 11 109-9 9-7-5Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "M44 75 53 74 61 167 55 170Z",
				fill: "#a09150",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M43 3 49 24 66 10 62 32 83 29 68 45 83 58 62 59 70 79 51 66 40 84 36 64 16 69 25 50 9 36 30 35 26 15 40 29Z",
				fill: "#292c2a"
			}),
			/* @__PURE__ */ g("path", {
				d: "M35 28q18-7 27 10l1 19-15 9-16-11-3-14Z",
				fill: "#4d4c35"
			}),
			/* @__PURE__ */ g("path", {
				d: "m36 29 7 17-17 3m22-9 11 18m-25-9 13 6m0-10 13-7",
				fill: "none",
				stroke: "#867b47",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "47",
				cy: "46",
				r: "5",
				fill: "#b14c22",
				stroke: "#dcb066"
			}),
			/* @__PURE__ */ g("path", {
				d: "M57 136c19 8 21 27 6 39-12 9-11 19 3 24l4 12-17-9c-20-13-15-29 0-37 12-6 14-16 4-29Z",
				fill: "#3c3c28"
			}),
			/* @__PURE__ */ g("path", {
				d: "M59 145q13 14-2 25c-12 11-14 18-3 27",
				fill: "none",
				stroke: "#b0a268",
				strokeWidth: "2"
			})
		] });
		case 8: return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "M27 88C6 76 14 63 7 57 24 62 28 75 36 69 46 56 33 49 27 45 49 45 61 54 66 67 84 69 91 47 99 48 100 66 90 80 83 88 98 101 85 121 99 130 76 133 65 120 54 127 42 140 23 130 14 139 5 132 15 117 8 102 1 99Z",
				fill: "#e54650",
				stroke: "#b83354"
			}),
			/* @__PURE__ */ g("path", {
				d: "M24 75C4 66 5 40 20 34c17-8 38-4 59-9 10-3 8-11 17-15 8 16 1 29-18 32L42 45C21 43 9 54 24 75Z",
				fill: "#f05759",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M23 78C41 60 68 62 80 80c15 21 7 43-12 51-19 6-42-2-48-17-8-12-6-25 3-36Z",
				fill: `url(#${t}-orb)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M28 82q20-16 38-2m-39 27q17 17 38 12m-24-29-3 16 14 7m13-27 4 15-9 7",
				stroke: "#f4a8b5",
				fill: "none",
				opacity: ".6"
			}),
			/* @__PURE__ */ g("path", {
				d: "M26 73q-5 12-11 12l-4 13m72-16 7-8m-59 46-9 9m51-12 9 4",
				stroke: "#ffb273",
				strokeWidth: "3",
				fill: "none"
			})
		] });
		default: return null;
	}
}
function ye({ value: e, id: t }) {
	let n = `url(#${t}-steel)`, r = `url(#${t}-gold)`, i = `url(#${t}-wood)`, a = `url(#${t}-red)`;
	switch (e) {
		case -4: return /* @__PURE__ */ _("g", {
			transform: "translate(0 101)",
			children: [
				/* @__PURE__ */ g("path", {
					d: "M20 38C31 8 59 8 70 25c4 7 4 15 1 23 17 9 12 32-4 44l-16 7 8-19c10-9 11-18 2-23-14 8-31 0-41-8l-8-4Z",
					fill: `url(#${t}-fish)`
				}),
				/* @__PURE__ */ g("path", {
					d: "M49 15 55 4 58 17l14-3-6 13m-32-9-5-7-11 13m46 37 10 4-8 13",
					fill: "#4a394c"
				}),
				/* @__PURE__ */ g("path", {
					d: "M65 83c-7 11-18 17-26 22l15-1 4 10 9-16 18 7-6-20Z",
					fill: "#635469"
				}),
				/* @__PURE__ */ g("path", {
					d: "M35 22q12 12 10 27m5-29q12 12 8 30m7-24q7 10 2 18m-3 16q8 8-3 20m-4 15 6-9",
					fill: "none",
					stroke: "#a397aa",
					strokeWidth: "1.8"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "27",
					cy: "33",
					r: "4",
					fill: "#2f2639"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "26",
					cy: "32",
					r: "1.3",
					fill: "#cfbbc2"
				}),
				/* @__PURE__ */ g("path", {
					d: "m15 40 12 4-5 4",
					fill: "none",
					stroke: "#b6a4ad"
				})
			]
		});
		case -3: return /* @__PURE__ */ _("g", {
			transform: "translate(0 71)",
			children: [
				/* @__PURE__ */ g("path", {
					d: "M21 34 10 20 27 19 33 4 46 14 59 5 64 17 84 10 83 29 95 39 80 47 83 65 65 69 54 83 42 66 24 69 28 50 10 47Z",
					fill: "#465a34"
				}),
				/* @__PURE__ */ g("path", {
					d: "M30 56 48 83 74 62 63 98 39 103 22 79Z",
					fill: "#ece1c3"
				}),
				/* @__PURE__ */ g("path", {
					d: "M46 94c-20 0-25 13-13 17 9 4 17-7 18-12 5 13 18 16 23 8 7-8-6-18-23-8l-7 15c-12 10-17 23-14 41l11-14 8-5 1-29 12 30 17 12-4-27-18-19",
					fill: a
				}),
				/* @__PURE__ */ g("path", {
					d: "m30 97q7-2 15 4m14 0 11 4m-28 15-6 17m22-24 7 18",
					stroke: "#e39c86",
					fill: "none"
				}),
				[
					[25, 31],
					[45, 23],
					[65, 30],
					[78, 44],
					[57, 48],
					[36, 49],
					[43, 65]
				].map(([e, t], n) => /* @__PURE__ */ _("g", {
					transform: `translate(${e} ${t}) rotate(${n * 41})`,
					children: [/* @__PURE__ */ g("path", {
						d: "M-12-3c-2-9 7-14 14-9 8-6 15 2 11 9 6 8-2 15-10 12-9 5-17-3-13-10Z",
						fill: n % 2 ? "#a7343d" : "#ca4650"
					}), /* @__PURE__ */ g("path", {
						d: "M-7-5q9-6 14 1 5 8-4 10-7 0-6-6 2-4 6 0l-2 3m-11-4 5 8m13-9-6 4",
						fill: "none",
						stroke: "#ec8c85",
						strokeWidth: "1.4"
					})]
				}, n))
			]
		});
		case -2: return /* @__PURE__ */ _("g", {
			transform: "translate(0 90)",
			children: [
				/* @__PURE__ */ g("path", {
					d: "M32 29C20 15 19 0 27-1 38-1 44 17 42 26m17 2C57 14 69 1 77 6c6 8-5 22-15 25",
					fill: "#e8717c"
				}),
				/* @__PURE__ */ g("path", {
					d: "m29 3 6 17m34-7-5 13",
					stroke: "#f4b698",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("path", {
					d: "M29 29c9-11 29-13 41-3 14 11 12 25 5 34 6 10 1 18-5 22 7 14 1 21-9 24-4 7-14 5-19 1-14-2-18-9-12-20-10-8-10-17-4-25-9-10-8-23 3-33Z",
					fill: a
				}),
				/* @__PURE__ */ g("path", {
					d: "M26 60q22 13 50-3M30 83q22 11 40-1m-28 21 6 5m10-3 6 0",
					fill: "none",
					stroke: "#a4313f",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ g("path", {
					d: "M66 29q12 0 10 12l-12-6Z",
					fill: "#ebc651",
					stroke: "none"
				}),
				/* @__PURE__ */ g("path", {
					d: "m61 28 5-8 7 4-2 9Z",
					fill: "#a2ae43"
				})
			]
		});
		case -1: return /* @__PURE__ */ _("g", {
			transform: "translate(0 101)",
			children: [
				/* @__PURE__ */ g("path", {
					d: "M15 40 7 25 20 16 31 19 38 5 53 12 65 3 73 16 89 20 87 36 97 49 83 60 78 77 62 75 47 84 37 72 18 73 16 58 4 52Z",
					fill: `url(#${t}-leaf)`
				}),
				/* @__PURE__ */ g("path", {
					d: "M17 24q12-5 20 9L29 53 18 46Zm26-14q11 15 8 25l-11 9-4-15Zm25 0q-1 24-18 36l21-7 9-15Zm20 34Q62 38 54 54l8 15 17-9Zm-65 11q20-10 31 6l-9 17-17-12Z",
					fill: "#5e8b2c"
				}),
				/* @__PURE__ */ g("path", {
					d: "M42 35c16-12 30-2 24 11-4 10-18 15-25 9-10-10 4-19 10-14 7 7-9 12-8 5m-17-18q8 3 10 12m38-19-11 17m18 13-15 8M23 58l13 7",
					fill: "none",
					stroke: "#b2cc58",
					strokeWidth: "2.4"
				})
			]
		});
		case 1: return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "m39 88 21 0 6 118-16 11-5-10Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m45 96 6 2 6 109",
				stroke: "#d7b86d",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M9 47 62 26 96 41 92 81 42 103 5 79Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "M10 48 62 29 89 42 39 65Z",
				fill: "#9e844b"
			}),
			/* @__PURE__ */ g("path", {
				d: "m39 65 2 33 51-19 1-34Z",
				fill: "#4c3d2c"
			}),
			/* @__PURE__ */ g("path", {
				d: "m11 60 28 15m-25-7 23 15m11-15 31-13m-30 21 28-11M58 32l4 15m8-17 6 16",
				stroke: "#b29454",
				fill: "none",
				strokeWidth: "1.7"
			}),
			/* @__PURE__ */ g("path", {
				d: "M8 48 20 44 18 84 7 77m64-44 13 5-1 45-11 5Z",
				fill: "#4b4c35"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "14",
				cy: "58",
				r: "2",
				fill: "#af6c31"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "77",
				cy: "50",
				r: "2",
				fill: "#c58d36"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "76",
				cy: "78",
				r: "2",
				fill: "#bb7432"
			})
		] });
		case 2: return /* @__PURE__ */ _("g", {
			transform: "translate(0 98)",
			children: [
				/* @__PURE__ */ g("path", {
					d: "M21 31c-7-28 19-39 42-28 20 9 27 28 21 47L67 68 64 88 40 95 24 80 24 58c-11-5-14-16-3-27Z",
					fill: a
				}),
				/* @__PURE__ */ g("path", {
					d: "M23 33q19 7 22 25l-5 18-15-10c-13-10-13-25-2-33Z",
					fill: "#a93531"
				}),
				/* @__PURE__ */ g("path", {
					d: "M53 8c-5 11 3 17 11 13 9-4 13 5 5 14-4 8-18 10-11 21-11-4-11-15-3-22-10 4-17-5-13-12-12 10-9 26-1 32-17-1-16-18-7-25-4-9 2-15 8-15Z",
					fill: "#c6a451",
					stroke: "none"
				}),
				/* @__PURE__ */ g("path", {
					d: "M30 70q16 16 34 5l-1 13-21 6-15-14Z",
					fill: "#63432f"
				}),
				/* @__PURE__ */ g("path", {
					d: "m33 78 9 8 14-3m-27-63q8-13 19-13",
					stroke: "#e39b68",
					fill: "none",
					strokeWidth: "2"
				})
			]
		});
		case 3: return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "m40 7 24 2-1 86-11 17-15-6Z",
				fill: "#4c4e39"
			}),
			/* @__PURE__ */ g("path", {
				d: "m45 11 7 1 0 77-7 10Z",
				fill: "#c0b88a"
			}),
			/* @__PURE__ */ g("path", {
				d: "M37 82 63 82q6 11 6 22l-9 20c0 15 11 28 12 43l-15 25q-9 0-17-7c3-9 6-18 3-28l-15-29-2-26Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m37 95 20-5 4 18-15 15-7-4Z",
				fill: "#575841"
			}),
			/* @__PURE__ */ g("path", {
				d: "M60 101c17-2 23 10 17 21l-12 7-3-10 7-3 0-9-8 1",
				fill: "none",
				stroke: "#c5a858",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m45 127 12 36-7 15m-8-47 5 12m-9-34-7-3m6 13-4 5",
				fill: "none",
				stroke: "#a6935c",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "m39 39 26 0m-27 12 25 0",
				stroke: "#747658",
				strokeWidth: "3"
			})
		] });
		case 4: return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "M29 1C12 39 18 64 34 81L20 93q5 12 16 20l34-6 15-22-17-8C83 48 79 18 72 0L58 41q-4 15-5 30l-10-4q-3-15 2-31l-7-24Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m28 12-3 32 11 34 6-8-7-27Zm40 6-6 29-6 25 11 6 10-37Z",
				fill: "#a9b6a0",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M35 82q19-13 33 1c6 8 8 20 7 30l-8 26-15 24q-9-2-16-10l-10-28Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "m39 91 9-1-4 13-9-2m19-14 10 3-1 12-10 0m-7 4-6 10 15-1m-17 7 3 8m5-9 2 10m6-9 1 8",
				fill: "#3c322b"
			}),
			/* @__PURE__ */ g("path", {
				d: "M37 136q18-7 30 3l-11 31-14-4Z",
				fill: "#7c4e33"
			}),
			/* @__PURE__ */ g("path", {
				d: "m44 142 10-3 4 9-7 11-7-3Z",
				fill: "#794465",
				stroke: "#c8a66a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M48 169 60 165 59 198 49 212 42 198Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m45 183 14-1m-15 9 14-1m-11 8 11-2",
				stroke: "#c9ab6b",
				strokeWidth: "2"
			})
		] });
		case 6: return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("ellipse", {
				cx: "51",
				cy: "99",
				rx: "46",
				ry: "77",
				fill: "#94cbd0",
				opacity: ".22",
				stroke: "#7ab5b9",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M48 1 62 34l24 12 9 32-12 43-19 47-10 43-23-22 11-39-26-31-3-41 17-37Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M48 11 40 53 28 73l-3 39 20 26 10-4 24-45-1-32-19-15-5-25-5 35 19 17-7 40-13 18-10-16 3-31 8-3-6-15Z",
				fill: "#819f9a"
			}),
			/* @__PURE__ */ g("path", {
				d: "M42 53c32-14 57 15 40 42-8 16-34 21-43 6-13-15 4-37 16-30 11 9-10 20-3 26 10 3 20-5 17-13-1-6-8-7-10-1m-17-21-11 15m5 29 10 10m13-63 11 5",
				fill: "none",
				stroke: "#284e59",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M49 148 64 136 55 177 42 188 45 169Z",
				fill: "#263f42"
			}),
			/* @__PURE__ */ g("path", {
				d: "m22 66 12-6m-17 22 11-3m49 47 9-10M43 28l8-12m-17 38 14-9m-20 81 12 6",
				stroke: "#d3e4d9",
				fill: "none",
				strokeWidth: "2"
			})
		] });
		case 7: return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "m24 15 47-2 13 100-11 19 5 44-21 27-21-2-7-33 15-21-18-26Z",
				fill: "#363839"
			}),
			/* @__PURE__ */ g("path", {
				d: "m30 20 23-1 8 75-29 4Z",
				fill: "#929293"
			}),
			/* @__PURE__ */ g("path", {
				d: "m56 18 9-1 12 80-11 9Z",
				fill: "#4a4440"
			}),
			/* @__PURE__ */ g("path", {
				d: "m18 43 14-2 5 47-20 4-9-8-2-31Z",
				fill: "#8c8980"
			}),
			/* @__PURE__ */ g("path", {
				d: "m13 55 11-1 2 22-13 3Z",
				fill: "#aaa79a"
			}),
			/* @__PURE__ */ g("path", {
				d: "M63 113c30-9 31 16 17 32l-12 0m2-25q16-4 11 13l-12 6",
				fill: "none",
				stroke: "#a1937a",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m40 148 22-10 8 41-15 14-15-5Z",
				fill: "#4a3d33"
			}),
			/* @__PURE__ */ g("path", {
				d: "m43 155 21 7m-22 1 24 7m-23 1 23 7m-21 1 18 7",
				stroke: "#777064",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "m34 26 11 0m-8 52 15-2m-17 29 37-4m-34 14 37-4",
				stroke: "#343438",
				strokeWidth: "3"
			})
		] });
		case 8: return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "M33 0c2 37-7 68-24 89l8 31 20-13 12 30 18-27 21 10 6-27C76 72 69 36 72 0L58 35l-8 45-9-2 3-44Z",
				fill: `url(#${t}-blacksteel)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M20 81c2 19-3 32-9 46l18-8 2 17 18-14 15 16 5-19 18 9c-8-20-7-29-4-41l-18 7-16 19-14-20Z",
				fill: "#3a3932"
			}),
			/* @__PURE__ */ g("path", {
				d: "m33 16 2 39-14 31m46-69-5 40 15 31",
				fill: "none",
				stroke: "#918d68",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "51",
				cy: "88",
				rx: "14",
				ry: "16",
				fill: `url(#${t}-blueglass)`,
				stroke: "#171f24",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m35 104 17 10 16-10m-31 11 14 10 14-9",
				fill: "none",
				stroke: "#888666",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M47 128 59 126 63 192 50 211 42 193Z",
				fill: "#3a3a2f"
			}),
			/* @__PURE__ */ g("path", {
				d: "m46 142 15-1m-15 12 15-1m-15 12 15-1m-15 12 15-1m-14 12 14-1",
				stroke: "#807d57",
				strokeWidth: "3"
			})
		] });
		case 9: return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "M51 0c-7 20 7 27 1 44-6 15-2 24-11 36-4 16 5 29 14 34 10-20 5-27 17-43 9-10 6-28 0-38l-2 18-9 12C62 38 48 29 51 0Z",
				fill: "#f4cc43",
				stroke: "#d49a26"
			}),
			/* @__PURE__ */ g("path", {
				d: "M54 26c-6 32 16 38-1 69l-8-6c4-20 1-31 9-63Z",
				fill: "#c5bc3d",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M35 83c-15-10-16-26-9-35-1 18 14 22 14 37m32-10c17-8 20-19 15-29 1 12-11 12-12 20m-37-8-8-7m46-9 6-11",
				fill: "none",
				stroke: "#efb847",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M36 97q17-10 33 1c3 9 8 16 9 27q-4 13-14 21l-15 26q-13-8-22-21l-5-31Z",
				fill: "#342b29"
			}),
			/* @__PURE__ */ g("path", {
				d: "M39 104c-10-13-20-5-15 6 5 10 21 0 17 18-3 11-15 6-14-1m36-24c17-6 23 6 13 14-7 6-14-2-13 10 1 9 12 9 13 1m-29-13q15-1 13 11l-13 9-3 13 13 9",
				fill: "none",
				stroke: "#9a7a4d",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "m42 153 19-1 1 43-12 16-12-18Z",
				fill: "#3d3027"
			}),
			/* @__PURE__ */ g("path", {
				d: "m42 162 16-1m-16 11 16-1m-15 10 14-1m-12 11 10-1",
				stroke: "#b79a62",
				strokeWidth: "2"
			})
		] });
		default: return null;
	}
}
function be({ u: e, id: t }) {
	let n = e.slot === "left";
	return /* @__PURE__ */ _("g", {
		transform: `translate(${n ? 12 : 142} ${n ? 101 : 17}) scale(.34)`,
		stroke: "#403c31",
		strokeWidth: "1.3",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [/* @__PURE__ */ _("defs", { children: [
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-steel`,
				x2: "100%",
				y2: "50%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#2b4751" }),
					/* @__PURE__ */ g("stop", {
						offset: ".25",
						stopColor: "#a6c4c4"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".48",
						stopColor: "#e6e9d3"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".58",
						stopColor: "#779da5"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#273b45"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-blacksteel`,
				x2: "100%",
				y2: "60%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#252d2e" }),
					/* @__PURE__ */ g("stop", {
						offset: ".4",
						stopColor: "#75785b"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".6",
						stopColor: "#444a3e"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#202729"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-gold`,
				x2: "100%",
				y2: "60%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#c7af70" }),
					/* @__PURE__ */ g("stop", {
						offset: ".4",
						stopColor: "#837547"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".6",
						stopColor: "#b7a267"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#423e2a"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-wood`,
				x2: "100%",
				y2: "50%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#4c3b24" }),
					/* @__PURE__ */ g("stop", {
						offset: ".3",
						stopColor: "#ac8345"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".5",
						stopColor: "#795b30"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#312e24"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-bun`,
				x2: "100%",
				y2: "70%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#f2d283" }),
					/* @__PURE__ */ g("stop", {
						offset: ".5",
						stopColor: "#b98a38"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#72512b"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-red`,
				x2: "100%",
				y2: "60%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#f49c78" }),
					/* @__PURE__ */ g("stop", {
						offset: ".4",
						stopColor: "#c95543"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#762c2c"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-ice`,
				x2: "100%",
				y2: "60%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#b6eeee" }),
					/* @__PURE__ */ g("stop", {
						offset: ".3",
						stopColor: "#4e9cba"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".6",
						stopColor: "#214b68"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#93d4d2"
					})
				]
			}),
			/* @__PURE__ */ _("radialGradient", {
				id: `${t}-orb`,
				cx: ".36",
				cy: ".3",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#ffd5b0" }),
					/* @__PURE__ */ g("stop", {
						offset: ".23",
						stopColor: "#ed97ad"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".6",
						stopColor: "#b54b93"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#6e3c83"
					})
				]
			}),
			/* @__PURE__ */ _("radialGradient", {
				id: `${t}-blueglass`,
				cx: ".3",
				cy: ".2",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#8caebe" }),
					/* @__PURE__ */ g("stop", {
						offset: ".5",
						stopColor: "#456372"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#203039"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-fish`,
				x2: "100%",
				y2: "70%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#ada0ad" }),
					/* @__PURE__ */ g("stop", {
						offset: ".5",
						stopColor: "#74617a"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#362b41"
					})
				]
			}),
			/* @__PURE__ */ _("linearGradient", {
				id: `${t}-leaf`,
				x2: "100%",
				y2: "70%",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#a7c854" }),
					/* @__PURE__ */ g("stop", {
						offset: ".5",
						stopColor: "#6c9a33"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#304d27"
					})
				]
			})
		] }), g(n ? ye : ve, {
			value: e.value,
			id: t
		})]
	});
}
//#endregion
//#region src/games/customheroes/ascended-art.tsx
function xe({ id: e }) {
	let t = `url(#${e}-skin)`, n = `url(#${e}-purple)`, r = `url(#${e}-night)`;
	return /* @__PURE__ */ _("g", {
		stroke: "#363040",
		strokeWidth: ".8",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M112 57C83 66 67 58 43 50q-12-3-20-1c16 6 18 11 28 15 24 14 49 10 64 6M116 70c-40-1-50 10-82 5l-13-7q2 9 11 14c32 9 53-3 83-3m17-4c30 3 33 17 38 37l8 21c-14-5-17-17-19-28l-14-18Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M55 60q34 18 60 8m-64 14 34-2m52-2q18 10 21 27",
				fill: "none",
				stroke: "#607c99"
			}),
			/* @__PURE__ */ g("path", {
				d: "M77 149c-19 10-29 25-38 47l-11 13 28 12 16-16 17-24 16-8m18-5 7 35 13 25 22-10-8-29-15-24Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m44 194 27 14-10 25-32-11 4-15m97-13 28-6 7 31-24 12Z",
				fill: "#272739"
			}),
			/* @__PURE__ */ g("path", {
				d: "m45 199 19 10m75-12 15-3",
				stroke: "#c2859a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M86 133C67 145 63 164 46 176q-10 7-21 9c8 5 16 9 25 10l21-10q8 8 17 15l17-16q8 7 18 10l26-7q12-8 25-23-15 5-26 4c-4-11-8-20-14-26Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M79 147 64 176l22 11 12-30m11-1 10 28 21-3-14-30m12 14 19 12",
				fill: "#3a344b",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M36 184q20-5 29-14m12 16 12 4 16-15 18 10 22-8m-38-22 7 17",
				fill: "none",
				stroke: "#91839d"
			}),
			/* @__PURE__ */ g("path", {
				d: "M88 88c-13-2-24 4-30 15l-18 9-18-5-8 7 25 13 30-8 24-15m44-18c12-1 21 7 26 19l17 10 2 11-22-6-27-19Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M61 91c-8 6-12 17-16 28l16 5 5 13 14-9 7-24m54-21 14 9 10 14-6 8-12-15-8-3Z",
				fill: `url(#${e}-white)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m62 97-7 16 14 6m81-24 7 11",
				stroke: "#aaa5ad",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M91 86c7-7 22-6 31-1q9 5 13 17c-1 14-4 25-8 36l-14 22q-14-4-29-10c-3-8-10-15-13-25q0-14 5-24Z",
				fill: "#242a3a"
			}),
			/* @__PURE__ */ g("path", {
				d: "M83 101c10 2 17 9 22 20q-2 14-1 27l-17-4q-6-10-9-23Zm31-7c12 3 15 14 10 26l-9 25-8-3q2-12 4-25Z",
				fill: "#494054"
			}),
			/* @__PURE__ */ g("path", {
				d: "m92 117 29-10m-26 17 23-9m-21 16 19-9m-17 16 14-9",
				stroke: "#bc9d75",
				fill: "none",
				strokeWidth: ".7"
			}),
			/* @__PURE__ */ g("path", {
				d: "M95 73 94 86 108 96 123 86 119 70Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M117 51c12 0 22 10 22 20q0 8-4 14c-2 5-7 8-12 9l-14-8q-4-8-5-16l4-14Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m126 58 9 10-3 16-9 6",
				fill: "#bc8378",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M101 58c-4 16 3 28 14 32l-4-21 11-8 9-8 6 16 2 23 12 13-4-24-7-24-15-10Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "M103 63c-15 5-23 8-34 7q9-8 14-12c12-1 23-4 32-9l15-13q7-9 14-9c0 9 7 13 14 17l22 27q-12-2-23-4l-21-7q-8 5-17 7Z",
				fill: "#262b3a"
			}),
			/* @__PURE__ */ g("path", {
				d: "M78 65q33-5 49-15l12-13q2 7 10 13l23 18q-10-8-19-12l-20-3-15 9Z",
				fill: "#4a3b54"
			}),
			/* @__PURE__ */ g("path", {
				d: "M89 64q22 1 40-11m11-12 14 15",
				stroke: "#8b6681",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M73 138 123 149l-3 12-46-10-18 4-5-12Z",
				fill: "#696042"
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "66",
				cy: "146",
				rx: "11",
				ry: "13",
				fill: `url(#${e}-orb)`,
				stroke: "#bc955a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "m97 148-3 9 8 3 4-9Z",
				fill: "#d6b566"
			}),
			/* @__PURE__ */ g("path", {
				d: "m104 152-4 4",
				stroke: "#514337"
			}),
			/* @__PURE__ */ g("path", {
				d: "M22 107 15 101 8 103l-3 7 10 8 11-6m148 5-2-10 5-4 7 9-3 10",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M92 88q8 4 14 11m18-11q-5 4-7 8m-32 4q-4 10-3 20m32-27q10 9 6 23m-29 26 10 5m-36 4 7-6m-3 23-9 14m30-19-7 14m27-18 7 16m-23 16 8-8m-46 26 10 5m69-11 4 8",
				fill: "none",
				stroke: "#b39daf",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ g("path", {
				d: "m15 107 3 3m-5-2-1 4m164 3 1-5m-2 8 3-1M79 126q1 11 8 17",
				fill: "none",
				stroke: "#9e7b73",
				strokeWidth: ".7"
			})
		]
	});
}
function Se({ id: e }) {
	let t = `url(#${e}-gold)`, n = `url(#${e}-white)`;
	return /* @__PURE__ */ _("g", {
		stroke: "#6c6143",
		strokeWidth: ".75",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("ellipse", {
				cx: "102",
				cy: "58",
				rx: "47",
				ry: "43",
				fill: "none",
				stroke: "#f8e6a0",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "102",
				cy: "58",
				rx: "39",
				ry: "36",
				fill: "none",
				stroke: "#cdb76b",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ g("path", {
				d: "M95 91C64 80 48 60 52 25c-12 10-16 24-13 36-11-10-14-23-14-35-9 32 4 61 21 75L11 90c15 25 40 28 62 24l-38 22 48-8m35-35c21-32 53-39 57-72 12 33-6 53-27 68l31-7c-12 22-29 31-50 31l38 10-30 17-25-25Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M57 78Q41 54 43 42m17 43Q42 79 38 62m35 39-41 0m92-6q36-23 41-48m-37 52 31-11m-28 19 28-2",
				fill: "none",
				stroke: "#c2bb86",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M85 143c-21 26-29 53-34 77l34 13 17-27 12 27 42-14c-17-18-20-45-31-73Z",
				fill: "#574e3d"
			}),
			/* @__PURE__ */ g("path", {
				d: "M89 156c-14 21-16 44-26 61l21 6 15-28 3-31Zm27 0 4 46 13 25 14-8-19-57Z",
				fill: "#807757"
			}),
			/* @__PURE__ */ g("path", {
				d: "M88 110c-11 4-19 16-25 31l-16 18q-7 3-11 7l-3 12 9-1 14-17 28-20m37-34c8 4 15 9 19 15l8 23 15 15q3 6 0 12l-10 0-19-26-20-19",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M66 129 79 136 63 151 51 167l-9-2Zm68-5 9 4 7 23-12-6-11-18Z",
				fill: "#7d6742"
			}),
			/* @__PURE__ */ g("path", {
				d: "m69 127 10-11m-26 36 13-16m71-15 5 10",
				fill: "none",
				stroke: "#f4d791",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M84 97c11-9 24-11 39-3l7 20c-2 10-6 18-6 28l9 34-25 10-33-12c4-11 8-22 10-34l-8-22Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m87 102 19 9 17-8-2 21-17 10-20-9Zm0 31 18 9 17-11-3 18-15 11-18-9Zm-3 28 20 7 20-10 5 15-23 11-28-12Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m89 112 16 9 13-7m-30 26 16 10 13-9m-29 26 17 6 17-7",
				fill: "none",
				stroke: "#c6bd8d"
			}),
			/* @__PURE__ */ g("path", {
				d: "M95 75 92 94 103 106 118 94 117 74Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M90 54c6-12 24-12 31 0q4 10 1 22l-14 16q-8-3-14-8l-7-20Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M87 63C82 46 93 37 105 40c15-5 26 12 22 26l-2 42-9-15 1-29-7-13-6 9-10-3-1 26-10 31-7 5Z",
				fill: `url(#${e}-hair)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M90 53q2-13 14-8m13 3 5 13m-33 9-7 32m38-39 1 22",
				fill: "none",
				stroke: "#ead29b"
			}),
			/* @__PURE__ */ g("path", {
				d: "M68 111C95 91 133 87 168 57c-3 21-16 38-32 46l-53 29-15-7Z",
				fill: `url(#${e}-linen)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M75 115q37-13 76-39m-70 47 53-25",
				fill: "none",
				stroke: "#dfe1b6",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m160 68 2 0-16 163-3 1Z",
				fill: "#6d5437"
			}),
			/* @__PURE__ */ g("path", {
				d: "m161 66-2-25 5-14 4 17-4 23Z",
				fill: "#f2df9a",
				stroke: "#bd9c50"
			}),
			/* @__PURE__ */ g("path", {
				d: "m156 154 4 7-5 12-4-3-3-7",
				fill: "#8a6a46"
			}),
			/* @__PURE__ */ g("path", {
				d: "m82 111 3 15m34-20 4 9m-39 15 1 11m33-7-2 11m-32 7-4 13m34-10 7 12m-27 11-7 12m21-15 11 9M69 139l-8 9m71-17 6 9M95 68q-1 12 6 17",
				fill: "none",
				stroke: "#f4e8bc",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ g("path", {
				d: "m66 213 15 6 6-9m39 5 7 8 10-4m-52-62 9 4 19-9",
				fill: "none",
				stroke: "#aea57c",
				strokeWidth: "1.2"
			})
		]
	});
}
function Ce({ id: e }) {
	let t = `url(#${e}-night)`, n = `url(#${e}-gold)`;
	return /* @__PURE__ */ _("g", {
		stroke: "#292b36",
		strokeWidth: ".8",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M103 73C140 49 164 52 181 33l-1 170-37 30-32-42-14-71Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m130 77 37-22-14 35 26-11-18 52 14 30-20 50-18-31-12-61Z",
				fill: "#202338"
			}),
			/* @__PURE__ */ g("path", {
				d: "m143 75 15-9m-8 50 14-14m-22 63 18 20",
				stroke: "#676076",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M75 154q31 4 62-3c4 15 11 27 13 41l-8 40-38-5q-4-16-7-32l-13 37-29-12c3-13 6-26 13-37Z",
				fill: "#232831"
			}),
			/* @__PURE__ */ g("path", {
				d: "m81 170-8 38 10 8 14-40m19-3 9 41 14 5-8-45",
				fill: "none",
				stroke: "#5f5662",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M76 99c-18 7-27 24-29 42l-5 31 13 8 15-21 13-34m46-32 21 20 9 39-17 18-15-33Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M47 154 65 161l-5 18-20-5Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m45 160 13 6m-10-9-3 11m-5 4 7 6 6-1-7 19-10 4-3-13Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m36 183 2 9m5-11-1 12m5-10-2 8",
				stroke: "#a38c75",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M80 88c17-7 40-9 51 3 4 9 10 21 13 33l-6 39q-14 16-29 31l-36-13c4-13 6-26 7-39l-10-30Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M79 112c6 14 9 22 10 37l-7 28 21 8 4-46-8-35m27-6 8 27-7 38-16 18 4-43Z",
				fill: "#514657",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m81 130 23 14 27-11m-45 12 18 9 23-11m-43 14 20 8 20-10m-25-41 8 24 2 45",
				fill: "none",
				stroke: "#a59167"
			}),
			/* @__PURE__ */ g("path", {
				d: "M73 108 56 85l11-16 27 11-3 25m26-16 14-29 30 20-14 37-21 7Z",
				fill: "#4d425f",
				stroke: "#ad925a",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ g("path", {
				d: "m69 77 9 19 9 1m55-24 7 15-17 17m-1-17 8-8 2 15",
				fill: "none",
				stroke: "#d6bb80"
			}),
			/* @__PURE__ */ g("path", {
				d: "M88 81 88 97 104 111 119 95 116 78Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M79 53c4-14 24-19 37-9q6 8 7 17l-4 24q-6 9-15 14l-15-10q-7-9-9-22Z",
				fill: `url(#${e}-skin)`
			}),
			/* @__PURE__ */ g("path", {
				d: "M108 51q14 16 3 35l-10 6 15-4 8-25-7-16Z",
				fill: "#aaa697",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M79 63C62 47 71 32 88 32c4-8 17-7 22-2 15-1 25 9 22 21-5 11-16 13-23 13l-1-15-18 5-10 12Z",
				fill: "#222632"
			}),
			/* @__PURE__ */ g("path", {
				d: "M77 45q12-12 27-9m-14 11q21-14 34-3m-14 7 13-3",
				fill: "none",
				stroke: "#4c5060"
			}),
			/* @__PURE__ */ g("path", {
				d: "M86 91c9 1 17 7 25 4l9-5-3 15-13 16-19-15-3-9Z",
				fill: `url(#${e}-white)`
			}),
			/* @__PURE__ */ g("path", {
				d: "m91 99 12 11 10-9",
				fill: "none",
				stroke: "#a9aaa5"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "139",
				cy: "98",
				r: "5",
				fill: "#815075",
				stroke: "#d2b86e",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ g("path", {
				d: "m136 96 3-2 2 3-3 2Z",
				fill: "#c59ab7",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M81 111q6 10 7 22m43-22q7 13 5 26m-49 15-3 17m34-20-6 19m-25-24 9 5m-10 14 9 4m25-27-6 6m13-17 2-8m-56-22 6 8m74 2 5 7M90 66q-2 12 3 19",
				fill: "none",
				stroke: "#8d808c",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ g("path", {
				d: "M78 169q10 3 23 5m18-3 11-13m-60-37q-7 14-8 24m80-38q11 15 11 31",
				fill: "none",
				stroke: "#211f30",
				strokeWidth: "1.7"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "106",
				cy: "139",
				r: "1.8",
				fill: "#c9ac6f"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "105",
				cy: "152",
				r: "1.8",
				fill: "#c9ac6f"
			})
		]
	});
}
function we({ id: e }) {
	let t = `url(#${e}-beast)`;
	return /* @__PURE__ */ _("g", {
		stroke: "#263953",
		strokeWidth: ".85",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M116 69c20-24 40-37 64-28l-1 107-20 33-23-25-13-48Z",
				fill: "#253951"
			}),
			/* @__PURE__ */ g("path", {
				d: "M120 69q28-19 46-14l-12 26 20 6-18 26 15 18-28 32-15-28Z",
				fill: "#3f6694"
			}),
			/* @__PURE__ */ g("path", {
				d: "M105 132c30 1 47 20 52 49q0 19-8 37l-31-7c2-10 2-20-2-27l-18-10m-12-33c-3 12-7 22-14 31l-20 23-23-11q7-18 17-33l26-24Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m130 164 14 24-6 23m-52-56-17 27-15 4",
				fill: "none",
				stroke: "#699bc2",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M97 75c20-14 50-6 58 14q3 27-9 48l-25 28c-11 0-26-3-35-10q-9-12-11-29l6-33Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M113 87c18 0 24 20 16 35l-18 25-18-5-2-22 17-20Z",
				fill: "#325279",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M109 82q24 5 26 23m-3 8-11 24m-31-3 6 11",
				fill: "none",
				stroke: "#7ba6c5",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M75 116C57 121 45 138 39 157l-8 20-15 7-4 12 17 4 26-20 12-29 26-15m50-29c17 6 23 28 14 46l-21 19-23-4-6-14 24-9 5-19Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M51 145q-11 13-14 30l-18 14m122-63q8 15-8 22l-14 1",
				fill: "none",
				stroke: "#71a0c9",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "m17 183-10 1-4 7 10-2-4 11 6-6 4 0 1 9 5-9 6 5 0-11m83-22-13 4-8 10 12-4-1 9 8-7 6 7 1-9 8 3-4-11",
				fill: "#c1d2d0",
				stroke: "#3d5771"
			}),
			/* @__PURE__ */ g("path", {
				d: "M66 74c9-18 30-20 47-8l8 20-14 22-25 16-18-12-8-21Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M59 91q-7 7-17 16c-1 6 2 11 6 17l17 15q7-1 14-6l18-20q-7-6-18-7Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M50 108 67 113 75 125l-9 8-11-8Z",
				fill: "#84bcce",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M61 115q5-5 11-6l5 3-13 12Z",
				fill: "#8fe8ca"
			}),
			/* @__PURE__ */ g("path", {
				d: "m56 126 6 0 3 4 4-3 5-1m-21-10 5-5",
				stroke: "#b8dce2",
				strokeWidth: "1.5",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M62 85 49 47 46 14 57 46 70 74l9-7-3-38 6-27 4 39 7 24 12-15 15-27 8-13-9 32-11 26 12-6 21-25 30-18-26 31-20 38-17 15-28-8Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m52 41 15 37m13-50 8 37m37-32-19 41m41-28-28 42",
				fill: "none",
				stroke: "#79aac6",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ g("path", {
				d: "M93 68q18 9 23 24l9-10-2-17-9-12-4 14-9-17-3 16-10-14-1 13Z",
				fill: "#22344c"
			}),
			/* @__PURE__ */ g("path", {
				d: "m84 86-10 14m21-10-11 12",
				stroke: "#71a8cb",
				strokeWidth: "2",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M76 78q-13 6-17 18m29-21q14-5 24 6m-20 28q-8 12-8 26m-27 10q-9 11-13 25m72-81q23-5 29 14m-9 34q-4 15-17 22",
				fill: "none",
				stroke: "#9ec1d0",
				strokeWidth: "1.2",
				opacity: ".7"
			}),
			/* @__PURE__ */ g("path", {
				d: "M62 132q8 7 17 2m-48 52q4-3 11-1m82-8q9-4 16 2",
				fill: "none",
				stroke: "#20354e",
				strokeWidth: "2"
			})
		]
	});
}
function Te({ id: e }) {
	let t = `url(#${e}-orange)`, n = `url(#${e}-armour)`;
	return /* @__PURE__ */ _("g", {
		stroke: "#3b4844",
		strokeWidth: ".9",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M89 157q27 3 50-6l19 53-11 24-27-13-10-33-13 43-27-4-4-33Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m78 185 17 0-7 34-14-1m51-40 15-4 10 32-13 10",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M83 63q20-5 42-1l25 19 4 46-18 41-24 11-35-18-8-44Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "M80 77q12-3 20 4l12 18-9 17-26-7-6-18Zm31-2q14-5 27-1l12 13-4 21-31 9-8-20Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m84 119 24 9 29-10-2 13-27 10-25-10Zm-2 17 25 12 25-11-2 12-23 12-23-15Z",
				fill: "#b1b49a"
			}),
			/* @__PURE__ */ g("path", {
				d: "m88 121 20 8 24-9m-43 20 18 9 20-10",
				fill: "none",
				stroke: "#3e5454"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "91",
				cy: "99",
				r: "10",
				fill: "#394d46",
				stroke: "#939b63",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "91",
				cy: "99",
				r: "6",
				fill: `url(#${e}-core)`
			}),
			/* @__PURE__ */ g("circle", {
				cx: "106",
				cy: "160",
				r: "5",
				fill: `url(#${e}-core)`,
				stroke: "#586858"
			}),
			/* @__PURE__ */ g("path", {
				d: "M72 72q-7-12-11-17l-16 3q-6 12-9 28l6 26 20-5 17-22m62-18 7-20 15 9q12 14 16 33l-6 21-29-5-10-21Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m46 69 15-6 11 12-13 24-13-3m105-39 15 21 7 13-9 9-20-8",
				fill: "#f1be62",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M52 103 68 113 64 143 51 158 38 146 39 124m113-28 23 14-10 28-29 18-19-10 9-20 23-12Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m54 118 8 1-4 19-9 9m107-33 11-1-9 19-21 12",
				fill: "none",
				stroke: "#d9cc8d",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M13 51 40 38 68 67 66 128 48 147 14 130 8 88Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m17 56 20-10 2 78-20-5-5-38m28-32 20 22-1 55-17 13Z",
				fill: "#7b8c76"
			}),
			/* @__PURE__ */ g("path", {
				d: "m37 49 1 75-19-5m25-65 1 78 14-9",
				fill: "none",
				stroke: "#c4c9a2",
				strokeWidth: "1.3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M165 117c-12 4-27 17-40 29l-40 34-25 15 9 16 30-18 40-25 24-19 13-18Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m158 124-23 25-42 34-24 15 5 8 27-20 39-28 25-25Z",
				fill: "#9da98e"
			}),
			/* @__PURE__ */ g("path", {
				d: "m133 148 10 7m-19 1 9 8m-19 0 9 7m-19 0 9 7m-20 0 9 8m-19-1 8 7m-18-1 7 8",
				stroke: "#374c47",
				strokeWidth: "1.4",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M171 111 179 127 62 216 49 203Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m168 121 6 4-111 81-4-4Z",
				fill: "#e7d8ac"
			}),
			/* @__PURE__ */ g("path", {
				d: "m48 192 17 19-6 8-20-20Z",
				fill: "#475b55"
			}),
			/* @__PURE__ */ g("path", {
				d: "m44 198-22 17 6 9 23-18Z",
				fill: "#9d843f"
			}),
			/* @__PURE__ */ g("path", {
				d: "m27 213 7 6m-1-11 8 6",
				stroke: "#dbbd73"
			}),
			/* @__PURE__ */ g("path", {
				d: "M69 195c-8-6-17-1-22 5l-11 7c-4 4-1 9 3 10l7 8c4 4 9 0 8-4 6 0 9-3 8-8l11-8Z",
				fill: "#3c514b"
			}),
			/* @__PURE__ */ g("path", {
				d: "M62 195q-9 0-13 9l-9 6 6 7 10-8 9-5Z",
				fill: "#a7b095"
			}),
			/* @__PURE__ */ g("path", {
				d: "m39 208 8 7m-4-11 9 7m-3-12 9 7m-11 9 6 6m-3-18 6-6 8 4-3 6-7 0",
				fill: "none",
				stroke: "#d0d1b0",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ g("path", {
				d: "M94 46 99 34 120 33 128 43l-1 25-28 2-6-10Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m99 36 17-1 7 7-23 1Z",
				fill: "#d8d1a7"
			}),
			/* @__PURE__ */ g("path", {
				d: "m97 49 7-6 5 6 11-3 7 5-2 8-27 1Z",
				fill: "#293a3b"
			}),
			/* @__PURE__ */ g("path", {
				d: "m101 61 22 1-3 4-16 0Z",
				fill: "#7e8a72"
			}),
			/* @__PURE__ */ g("path", {
				d: "m94 48-5-17 5 6m30 5 4-22 3 2-3 23",
				stroke: "#adb494",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m42 61 18 16-1 39-12 13m-27-67 5-3m-5 62 6 3m29-48 4 3m-9 45 6-4m24-47 17 5m25-4 13 6m-13 30 14-3m-57 17 13 4m14 19 10-5",
				fill: "none",
				stroke: "#f2dfaa",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "70",
				cy: "100",
				r: "5",
				fill: "#354b48"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "144",
				cy: "109",
				r: "5",
				fill: "#354b48"
			}),
			/* @__PURE__ */ g("path", {
				d: "m66 99 7 1m68 8 7 2",
				stroke: "#899c7d"
			}),
			/* @__PURE__ */ g("path", {
				d: "m80 113 12 7 10-1m17-1 15-5m-47 43 17 8 21-9",
				fill: "none",
				stroke: "#293f3f",
				strokeWidth: "1.6"
			})
		]
	});
}
function Ee({ id: e }) {
	let t = `url(#${e}-skin)`;
	return /* @__PURE__ */ _("g", {
		stroke: "#694b3e",
		strokeWidth: ".9",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M117 51c27-9 33 2 45 8l18 3-15 10-14-9-19-1m-34-13C65 37 44 52 21 58l-15 2c23-18 52-34 82-23Z",
				fill: "#5c333d"
			}),
			/* @__PURE__ */ g("path", {
				d: "M93 26c0-14 17-19 23-9l8 12-14 9Z",
				fill: "#3c2e2d"
			}),
			/* @__PURE__ */ g("path", {
				d: "M73 170 135 169l14 58-36 4-13-30-8 29-32-6Z",
				fill: "#2c2b31"
			}),
			/* @__PURE__ */ g("path", {
				d: "m79 187-11 32 21 3 9-25m26-13 12 35",
				fill: "none",
				stroke: "#59515a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M76 92c13-14 40-15 57-2q10 14 13 37c-1 15-4 30-9 43l-17 23-42-6c-6-11-10-20-11-30l-2-39Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M73 109c12-9 24-7 34 2q1 13-1 24c-7 5-14 7-20 6q-11-4-13-12m41-20c10-8 20-7 27 1q4 12-2 21c-7 5-15 7-24 6Z",
				fill: "#b17b58",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M83 146q14-7 21-1l-1 16q-9 2-18-2m26-16q10-5 22-6l-6 18-16 6m-25 6q8-2 15 0l8 17q-11-1-20-7",
				fill: "#a67150",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M77 111q11-7 22 0m20-1q8-6 15-1m-29 30-1 18m3 10 3 14",
				fill: "none",
				stroke: "#ecc18a",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M71 97c-15-2-29 11-33 27l-12 42 10 36 16-2 0-23-7-18 14-27 20-16m52-24c18-3 31 9 35 25l-2 44-13 25-17-4 5-28-12-17Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M45 124q-5 16-8 34l9 22 1 15m100-79q11 13 6 28l-9 27",
				fill: "none",
				stroke: "#b27a54",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M36 193c-1 9-4 15-2 22l3 8q2 3 4 0l-1-12 2 12q3 4 5 0l-1-13 3 11q3 3 5-1l-2-15 4-6q3-8-2-12l-4-1-1 12-2-8Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m36 201 4 4m3-6 3 4m2-7 4 5m-11 8 0 6m5-9 1 9",
				stroke: "#a97051",
				fill: "none",
				strokeWidth: ".7"
			}),
			/* @__PURE__ */ g("path", {
				d: "m143 108 10 5 3 6-13-4m0 5 16 7m-19 1 18 6",
				fill: "none",
				stroke: "#51443c",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M92 65 87 88 100 103 122 90 116 65Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M84 43c5-17 27-20 37-8q6 7 7 20l-5 20q-6 9-13 15c-6-1-12-4-17-8l-11-21Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "M114 42q12 14 4 29l-11 10 12-5 8-20-5-17Z",
				fill: "#ad7654",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M82 53C75 41 82 27 95 26c16-9 31 4 33 18l-2 12-9-17-24 1-9 17Z",
				fill: "#45312f"
			}),
			/* @__PURE__ */ g("path", {
				d: "M85 43q17-6 39-1l2 5-38 1-5 8Z",
				fill: "#a24750"
			}),
			/* @__PURE__ */ g("path", {
				d: "M87 45C57 48 49 68 24 74c26-1 43-22 64-24m36-7 17-10 12 4-23 10",
				fill: "#934855"
			}),
			[
				[84, 85],
				[88, 94],
				[95, 100],
				[105, 101],
				[116, 96],
				[122, 86]
			].map(([t, n], r) => /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("circle", {
				cx: t,
				cy: n,
				r: "4.6",
				fill: `url(#${e}-wood)`
			}), /* @__PURE__ */ g("path", {
				d: `m${t - 2} ${n - 2} 2-1`,
				stroke: "#d8b675",
				fill: "none"
			})] }, r)),
			/* @__PURE__ */ g("path", {
				d: "M80 176 133 175l5 11-57 8-15-6Z",
				fill: "#6a3743"
			}),
			/* @__PURE__ */ g("path", {
				d: "m81 182 51-2",
				stroke: "#b37470",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M118 160c-11-8-13-21-9-31 7 10 8 4 7-8 10 8 10 16 15 23 4-7 8-11 11-12 3 17-6 29-24 28Z",
				fill: "#f1a736",
				stroke: "#d67d2f"
			}),
			/* @__PURE__ */ g("path", {
				d: "M119 154c-5-11 2-14 0-24 10 7 5 15 11 19-2 7-9 11-11 5Z",
				fill: "#fce282",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M132 171c-14-2-24-13-28-21l-9-13q-2-8 1-8 5-3 7 1l8 12-4-16q0-7 4-4l7 3 5 14-1-15q4-4 7 0l6 16q5 10 5 15l10 5-6 15Z",
				fill: t
			}),
			/* @__PURE__ */ g("path", {
				d: "m105 139 9 9 12 4m-7-16 7 9m5-9 4 10m-19 12 17 6",
				fill: "none",
				stroke: "#9b694f"
			})
		]
	});
}
function De({ variant: e, id: t }) {
	return /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ _("defs", { children: [
		/* @__PURE__ */ _("linearGradient", {
			id: `${t}-skin`,
			x2: "100%",
			y2: "70%",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#f4d0a3" }),
				/* @__PURE__ */ g("stop", {
					offset: ".45",
					stopColor: "#d7a27d"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#96664f"
				})
			]
		}),
		/* @__PURE__ */ _("linearGradient", {
			id: `${t}-purple`,
			x2: "100%",
			y2: "70%",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#8a718f" }),
				/* @__PURE__ */ g("stop", {
					offset: ".4",
					stopColor: "#514363"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#252b40"
				})
			]
		}),
		/* @__PURE__ */ _("linearGradient", {
			id: `${t}-hair`,
			x2: "100%",
			y2: "80%",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#ead79f" }),
				/* @__PURE__ */ g("stop", {
					offset: ".4",
					stopColor: "#b5a56b"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#6c684b"
				})
			]
		}),
		/* @__PURE__ */ _("linearGradient", {
			id: `${t}-white`,
			x2: "100%",
			y2: "100%",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#fff4cd" }),
				/* @__PURE__ */ g("stop", {
					offset: ".5",
					stopColor: "#d5d6ba"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#8c9b98"
				})
			]
		}),
		/* @__PURE__ */ _("linearGradient", {
			id: `${t}-gold`,
			x2: "100%",
			y2: "60%",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#f2d38b" }),
				/* @__PURE__ */ g("stop", {
					offset: ".4",
					stopColor: "#c7a05c"
				}),
				/* @__PURE__ */ g("stop", {
					offset: ".7",
					stopColor: "#98794e"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#60513b"
				})
			]
		}),
		/* @__PURE__ */ _("linearGradient", {
			id: `${t}-linen`,
			x2: "100%",
			y2: "70%",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#f0dfac" }),
				/* @__PURE__ */ g("stop", {
					offset: ".4",
					stopColor: "#c7c295"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#77836d"
				})
			]
		}),
		/* @__PURE__ */ _("linearGradient", {
			id: `${t}-night`,
			x2: "100%",
			y2: "70%",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#676174" }),
				/* @__PURE__ */ g("stop", {
					offset: ".35",
					stopColor: "#3b394d"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#1c2333"
				})
			]
		}),
		/* @__PURE__ */ _("linearGradient", {
			id: `${t}-beast`,
			x2: "100%",
			y2: "80%",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#79a7c4" }),
				/* @__PURE__ */ g("stop", {
					offset: ".35",
					stopColor: "#47749e"
				}),
				/* @__PURE__ */ g("stop", {
					offset: ".7",
					stopColor: "#355980"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#203650"
				})
			]
		}),
		/* @__PURE__ */ _("linearGradient", {
			id: `${t}-orange`,
			x2: "100%",
			y2: "70%",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#f2cb7a" }),
				/* @__PURE__ */ g("stop", {
					offset: ".4",
					stopColor: "#d29640"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#7f5b30"
				})
			]
		}),
		/* @__PURE__ */ _("linearGradient", {
			id: `${t}-armour`,
			x2: "100%",
			y2: "80%",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#c2c9a7" }),
				/* @__PURE__ */ g("stop", {
					offset: ".4",
					stopColor: "#8b9d86"
				}),
				/* @__PURE__ */ g("stop", {
					offset: ".7",
					stopColor: "#596f67"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#344746"
				})
			]
		}),
		/* @__PURE__ */ _("linearGradient", {
			id: `${t}-wood`,
			x2: "100%",
			y2: "70%",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#cdb075" }),
				/* @__PURE__ */ g("stop", {
					offset: ".45",
					stopColor: "#8c683b"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#4c3b2c"
				})
			]
		}),
		/* @__PURE__ */ _("radialGradient", {
			id: `${t}-orb`,
			cx: ".3",
			cy: ".25",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#f7dd91" }),
				/* @__PURE__ */ g("stop", {
					offset: ".4",
					stopColor: "#dc963a"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#7b4e38"
				})
			]
		}),
		/* @__PURE__ */ _("radialGradient", {
			id: `${t}-core`,
			cx: ".35",
			cy: ".3",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#d4f6c1" }),
				/* @__PURE__ */ g("stop", {
					offset: ".4",
					stopColor: "#8dc5a1"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#345a55"
				})
			]
		})
	] }), g(e === 0 ? xe : e === 1 ? Se : e === 2 ? Ce : e === 3 ? we : e === 4 ? Te : Ee, { id: t })] });
}
//#endregion
//#region src/games/customheroes/aura-art.tsx
function Oe({ x: e, y: t, s: n = 1 }) {
	return /* @__PURE__ */ _("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		stroke: "#5d9da5",
		strokeWidth: ".55",
		children: [
			/* @__PURE__ */ g("path", {
				d: "m0 0-1-23 5-19 7 35 5-19 6 22 10-11 8 20Z",
				fill: "#92c8c8"
			}),
			/* @__PURE__ */ g("path", {
				d: "m-1-23 5-19 2 37Zm12-7 4 22 1-18 2 21m4-8 2 9 10-11-6 14",
				fill: "#d3ece0"
			}),
			/* @__PURE__ */ g("path", {
				d: "m4-42 2 37m10-21 2 21m16-12-6 14",
				stroke: "#eff6e9",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "m0 0 6-5 18 1 14 4",
				fill: "#679baf"
			})
		]
	});
}
function ke() {
	return /* @__PURE__ */ _("g", {
		fill: "#252832",
		stroke: "#141c26",
		strokeWidth: ".7",
		children: [/* @__PURE__ */ g("path", { d: "M3 21C11 22 15 18 21 18c9-4 22-4 30 0l7-8 4-1 4-7 3 8 7 5-4 6-9 4-9-1c-5 5-13 8-21 5L20 31 8 40l-6-1 11-7 5-8C5 33-7 31-10 20c-2-8 2-17 6-17-6 11-5 22 7 18Zm44 5 8 7 14 3 3 5-7-1-15-6-10-8M25 25l-4 11-9 11-5-1 8-10 4-13Z" }), /* @__PURE__ */ g("path", {
			d: "M24 19q13-6 27 0m9-3 6 3",
			fill: "none",
			stroke: "#59616a",
			strokeWidth: "1.2"
		})]
	});
}
function Ae() {
	return /* @__PURE__ */ _("g", {
		fill: "#272b31",
		stroke: "#151d23",
		strokeWidth: ".8",
		children: [/* @__PURE__ */ g("path", { d: "M10 40c-14-1-14-13-7-18-3 8 0 13 7 13l3-9 3-8-3-6 1-10 6 7 10-5-1 9 5 5-6 5 6 13 8 4-6 4-12-2-6 2-10-1Z" }), /* @__PURE__ */ g("path", {
			d: "M15 28q10-6 14 5m-11-19 7 2",
			fill: "none",
			stroke: "#556267"
		})]
	});
}
function je({ value: e, id: t }) {
	switch (e) {
		case 5: return /* @__PURE__ */ _("g", {
			stroke: "#a94942",
			strokeWidth: ".7",
			children: [[
				[
					16,
					54,
					1
				],
				[
					167,
					91,
					.8
				],
				[
					12,
					136,
					1.1
				],
				[
					160,
					197,
					.9
				],
				[
					49,
					220,
					.7
				]
			].map(([e, n, r], i) => /* @__PURE__ */ _("g", {
				transform: `translate(${e} ${n}) scale(${r})`,
				children: [
					/* @__PURE__ */ g("ellipse", {
						rx: "8",
						ry: "12",
						fill: `url(#${t}-${i % 2 ? "blueball" : "redball"})`
					}),
					/* @__PURE__ */ g("path", {
						d: "m-2 11 2 3 2-3m-2 3c-6 7 7 10 1 15s-4 11-1 15",
						fill: "none"
					}),
					/* @__PURE__ */ g("path", {
						d: "M-5-7q-2 4-1 7",
						fill: "none",
						stroke: "#f7d8bd",
						strokeWidth: "1.5"
					})
				]
			}, i)), /* @__PURE__ */ _("defs", { children: [/* @__PURE__ */ _("radialGradient", {
				id: `${t}-redball`,
				cx: ".3",
				cy: ".2",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#ffb29a" }),
					/* @__PURE__ */ g("stop", {
						offset: ".45",
						stopColor: "#cb5043"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#752735"
					})
				]
			}), /* @__PURE__ */ _("radialGradient", {
				id: `${t}-blueball`,
				cx: ".3",
				cy: ".2",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#c4cdd0" }),
					/* @__PURE__ */ g("stop", {
						offset: ".45",
						stopColor: "#63727f"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#2c394b"
					})
				]
			})] })]
		});
		case 6: return /* @__PURE__ */ _("g", { children: [
			/* @__PURE__ */ g("g", {
				transform: "translate(53 28) scale(.42) rotate(4)",
				children: /* @__PURE__ */ g(ke, {})
			}),
			/* @__PURE__ */ g("g", {
				transform: "translate(154 32) scale(.4) rotate(85)",
				children: /* @__PURE__ */ g(ke, {})
			}),
			/* @__PURE__ */ g("g", {
				transform: "translate(10 163) scale(.4) rotate(-58)",
				children: /* @__PURE__ */ g(ke, {})
			}),
			/* @__PURE__ */ g("g", {
				transform: "translate(168 134) scale(-.45 .45) rotate(-48)",
				children: /* @__PURE__ */ g(ke, {})
			}),
			/* @__PURE__ */ g("g", {
				transform: "translate(12 211) scale(.46)",
				children: /* @__PURE__ */ g(Ae, {})
			})
		] });
		case 7: return /* @__PURE__ */ g("g", { children: Array.from({ length: 32 }, (e, t) => {
			let n = t % 4, r = Math.floor(t / 4), i = n === 0 ? 12 + r % 3 * 2 : n === 1 ? 167 - r % 3 * 2 : 25 + r * 18, a = n < 2 ? 41 + r * 25 : n === 2 ? 37 + r % 2 * 4 : 218 - r % 2 * 4;
			return /* @__PURE__ */ _("g", {
				transform: `translate(${i} ${a}) rotate(${t * 37})`,
				children: [/* @__PURE__ */ g("path", {
					d: "M-3-2q1-6 6-3 5 6-5 10 4-5-1-7Z",
					fill: t % 2 ? "#85303f" : "#bd5264"
				}), /* @__PURE__ */ g("path", {
					d: "m-1-2 2 4",
					stroke: "#d79294",
					strokeWidth: ".5"
				})]
			}, t);
		}) });
		case 8: return /* @__PURE__ */ _("g", {
			fill: "#f7faf1",
			stroke: "#b2c5c8",
			strokeWidth: ".4",
			children: [[
				[
					10,
					74,
					4
				],
				[
					164,
					62,
					3
				],
				[
					18,
					152,
					2
				],
				[
					171,
					181,
					3
				],
				[
					42,
					218,
					3
				],
				[
					120,
					223,
					2
				],
				[
					159,
					111,
					2
				]
			].map(([e, t, n], r) => /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("ellipse", {
				cx: e,
				cy: t,
				rx: n,
				ry: n * .7
			}), /* @__PURE__ */ g("path", {
				d: `m${e - 5} ${t - 7} 4-3 7 0m-2 2 6-2`,
				fill: "none",
				stroke: "#e4eded",
				strokeWidth: ".7"
			})] }, r)), /* @__PURE__ */ g("path", {
				d: "m8 89 9 4 4-3m-8 68 7 4 9-2m126-55 11 1 5-4",
				fill: "none",
				stroke: "#f0f6f0",
				strokeWidth: "1.5"
			})]
		});
		case 9: return /* @__PURE__ */ _("g", { children: [
			/* @__PURE__ */ g(Oe, {
				x: 7,
				y: 225,
				s: .65
			}),
			/* @__PURE__ */ g(Oe, {
				x: 23,
				y: 226,
				s: .47
			}),
			/* @__PURE__ */ _("g", {
				transform: "translate(174 0) scale(-1 1)",
				children: [/* @__PURE__ */ g(Oe, {
					x: 0,
					y: 225,
					s: .9
				}), /* @__PURE__ */ g(Oe, {
					x: 14,
					y: 228,
					s: .45
				})]
			}),
			/* @__PURE__ */ g("path", {
				d: "m12 190-1-5m151-11 0-6m-126 54-2-4",
				stroke: "#c5e6e0",
				strokeWidth: ".8"
			})
		] });
		case 10: return /* @__PURE__ */ g("g", {
			fill: "#668845",
			stroke: "#3d633e",
			strokeWidth: ".8",
			children: [
				[
					11,
					39,
					25
				],
				[
					167,
					45,
					-65
				],
				[
					12,
					182,
					85
				],
				[
					163,
					203,
					20
				],
				[
					143,
					222,
					95
				],
				[
					21,
					226,
					-40
				],
				[
					12,
					51,
					65
				],
				[
					168,
					63,
					-10
				],
				[
					17,
					214,
					5
				],
				[
					29,
					225,
					75
				],
				[
					150,
					225,
					-30
				],
				[
					167,
					218,
					55
				],
				[
					11,
					197,
					15
				],
				[
					167,
					154,
					15
				],
				[
					38,
					36,
					-20
				],
				[
					147,
					37,
					90
				]
			].map(([e, t, n], r) => /* @__PURE__ */ _("g", {
				transform: `translate(${e} ${t}) rotate(${n})`,
				children: [/* @__PURE__ */ g("path", {
					d: "M-9-3C-5-11 3-8 8-4q2 3 5 7C5 3 4 13-5 7l-6 2q3-3 4-6Z",
					fill: r % 2 ? "#a2b774" : "#5f894b"
				}), /* @__PURE__ */ g("path", {
					d: "m-8 6 15-10m-10 7-1-6m3 4 6 2",
					fill: "none",
					stroke: "#c4d295",
					strokeWidth: ".6"
				})]
			}, r))
		});
		case 11: return /* @__PURE__ */ _("g", {
			fill: "#ed8c30",
			stroke: "#cf5f2e",
			strokeWidth: ".5",
			children: [
				/* @__PURE__ */ g("path", { d: "M7 224V174c6 13 10 13 8 26 12-8 1-16 6-25 1 14 10 18 7 32q4-3 6-7c3 12-2 18 7 24Zm136 0c12-9 11-24 16-31-1 15 6 11 7 22 7-16-1-18 5-32l2 41ZM7 45V26q6 9 10 10c1 5-5 7-4 8q6 1 9-1c-2 10-9 10-10 17Z" }),
				/* @__PURE__ */ g("path", {
					d: "M9 222q4-9 2-28c4 6 1 11 4 16l5-7q-2 9-1 17m138-3q4-5 3-14c5 5-1 9 4 15q3-8 6-17l-1 20M10 37q4 4 2 10",
					fill: "#f9dc6a",
					stroke: "none"
				}),
				/* @__PURE__ */ g("path", {
					d: "M9 139c-4-10 6-13 4-23 7 11-1 16 2 23m153-47c-5-9 4-12 2-23",
					fill: "none",
					stroke: "#efb943",
					strokeWidth: "2"
				})
			]
		});
		case 12: return /* @__PURE__ */ g("g", {
			stroke: "#edf1cb",
			strokeWidth: ".9",
			fill: "none",
			opacity: ".9",
			children: /* @__PURE__ */ g("path", { d: "m151 30 5-8 3 13m-2-10 3 6m-145 46-4 13 9-4-5 17m144-11-8-10 0 19m-141 28 4-10 3 15m11 20 2 13 5-7-7-5m132 2-8-2 7 14m-12 3 5 15m-9-9 12 1M12 205l8-14 0 11 10-2-8 17m34 0 4-12 8 7-10 5 6 8m75-20 3 10 6-5-9-5 7 16-10 2m24-5 6-17 3 14-13-4" })
		});
		case 13: return /* @__PURE__ */ _("g", {
			fill: "none",
			strokeLinecap: "round",
			children: [/* @__PURE__ */ g("path", {
				d: "m8 110 6 5 1 9 7 3-1 9 12 7m-23 7 11 8-2 11 10 4m-21 15 5 10-6 8 11 8 18-3 9 10 19-4 7 6m94-5-8-11 10-9-2-12 9-7m-5-48-8 5 1 11-14 5-2 8-12 4m16-14-6-8m-2 22-9 8M30 215l-4-10m120-61-11-4",
				stroke: "#c8f1eb",
				strokeWidth: "1.3"
			}), /* @__PURE__ */ g("path", {
				d: "m8 110 6 5 1 9 7 3-1 9 12 7m135 40-9 8 2 12-10 9 8 11",
				stroke: "#f5ffff",
				strokeWidth: ".5"
			})]
		});
		case 14: return /* @__PURE__ */ _("g", {
			fill: `url(#${t}-cloud)`,
			children: [
				/* @__PURE__ */ g("path", { d: "M7 172c12-5 20-16 29-12 10-15 28-9 29 5 17-4 30 12 24 28 15-3 28 8 27 21l15 10H7Zm109 53c-7-12 0-26 14-28-2-17 11-29 24-23-3-17 4-27 19-30v81Zm-109-98c11-4 12-13 8-20 14-6 8-24 0-25 10-11 5-26-8-27Z" }),
				/* @__PURE__ */ g("path", {
					d: "M7 207c15-5 23 1 27 10 10-5 20-1 23 8m-21-34c12-3 18 6 16 14 13-5 20 1 22 9m61 2c-3-12 9-19 16-13 2-11 10-14 19-10",
					fill: "none",
					stroke: "#f4f7f0",
					strokeWidth: "1.5",
					opacity: ".65"
				}),
				/* @__PURE__ */ g("defs", { children: /* @__PURE__ */ _("linearGradient", {
					id: `${t}-cloud`,
					x2: ".7",
					y2: "1",
					children: [
						/* @__PURE__ */ g("stop", {
							stopColor: "#ecf2f0",
							stopOpacity: ".82"
						}),
						/* @__PURE__ */ g("stop", {
							offset: ".6",
							stopColor: "#b9c6d2",
							stopOpacity: ".75"
						}),
						/* @__PURE__ */ g("stop", {
							offset: "1",
							stopColor: "#6e88a8",
							stopOpacity: ".2"
						})
					]
				}) })
			]
		});
		default: return null;
	}
}
//#endregion
//#region src/games/customheroes/slot-gem.tsx
var Me = {
	right: [
		"#438abc",
		"#9ed5ee",
		"#5ea2d4",
		"#27597f",
		"#1c3d63"
	],
	left: [
		"#c55147",
		"#f8ac93",
		"#df7961",
		"#8f3435",
		"#672d37"
	],
	aura: [
		"#7ba954",
		"#c4dda1",
		"#9bc76b",
		"#4f7e41",
		"#325d3b"
	],
	buddy: [
		"#d1a945",
		"#f8e5a0",
		"#edca66",
		"#9b7429",
		"#715424"
	]
};
function Ne({ slot: e, filled: t = !0 }) {
	let [n, r, i, a, o] = t ? Me[e] : [
		"#8898a0",
		"#c8d3cd",
		"#a5b4b9",
		"#5c7281",
		"#3a536b"
	];
	return /* @__PURE__ */ _("g", {
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ g("circle", {
				r: "7.3",
				fill: "#34454d",
				stroke: "#ded8bf",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ g("path", {
				d: "m0-6 4.3 1.5 1.7 4.4-1.7 4.4L0 6-4.3 4.3-6-.1-4.3-4.5Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m0-6 4.3 1.5-2.1 2.7-5.1 0-1.4-2.7Z",
				fill: r
			}),
			/* @__PURE__ */ g("path", {
				d: "m-4.3-4.5 1.4 2.7-.8 4.6-2.3-2.9Z",
				fill: i
			}),
			/* @__PURE__ */ g("path", {
				d: "m4.3-4.5 1.7 4.4-2.3 2.9-1.5-4.8Z",
				fill: a
			}),
			/* @__PURE__ */ g("path", {
				d: "m-6-.1 2.3 2.9 7.4.2 2.3-3.1-1.7 4.4L0 6l-4.3-1.7Z",
				fill: o
			}),
			/* @__PURE__ */ g("path", {
				d: "m-2.9-1.8 5.1 0 1.5 4.8-7.4-.2Z",
				fill: n
			}),
			/* @__PURE__ */ g("path", {
				d: "m-3.8-3.4 3.2-1.1",
				stroke: "#fff4dc",
				strokeWidth: ".7",
				opacity: ".8"
			})
		]
	});
}
//#endregion
//#region src/games/customheroes/card.tsx
var X = [
	"games.customheroes.hero1",
	"games.customheroes.hero2",
	"games.customheroes.hero3",
	"games.customheroes.hero4",
	"games.customheroes.hero5",
	"games.customheroes.hero6",
	"games.customheroes.hero7",
	"games.customheroes.hero8",
	"games.customheroes.hero9",
	"games.customheroes.hero10"
], Pe = {
	burny: "games.customheroes.burny",
	edge: "games.customheroes.edge",
	spector: "games.customheroes.spector",
	charmy: "games.customheroes.charmy",
	kodora: "games.customheroes.kodora",
	ascended: "games.customheroes.ascended"
}, Fe = {
	burny: "games.customheroes.burnyEffect",
	edge: "games.customheroes.edgeEffect",
	spector: "games.customheroes.spectorEffect",
	charmy: "games.customheroes.charmyEffect",
	kodora: "games.customheroes.kodoraEffect",
	ascended: "games.customheroes.ascendedEffect"
}, Ie = {
	aura: "games.customheroes.aura",
	left: "games.customheroes.left",
	right: "games.customheroes.right",
	buddy: "games.customheroes.buddy"
};
function Le(e, t) {
	return e.ability ? t(Pe[e.ability]) : `${t(Ie[e.slot])} ${e.slot === "aura" ? e.value : e.value > 0 ? "+" + e.value : e.value}`;
}
function Re(e, t) {
	return e.ability ? t(Fe[e.ability]) : t(e.slot === "aura" ? "games.customheroes.auraEffect" : "games.customheroes.itemEffect", { n: e.value > 0 && e.slot !== "aura" ? "+" + e.value : e.value });
}
function Z({ kind: e, size: t = 20 }) {
	return /* @__PURE__ */ g("svg", {
		width: t,
		height: t,
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: e === "vp" ? /* @__PURE__ */ _("g", {
			strokeLinejoin: "round",
			children: [
				/* @__PURE__ */ g("path", {
					d: "M7 2Q4 2 3 6L2 26q0 4 5 4l22-12q4-2 0-5Z",
					fill: "#8c8b83",
					stroke: "#4e5156",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ g("path", {
					d: "M7 4 28 15l-1 3L7 28l-3-3L5 7Z",
					fill: "#e33532",
					stroke: "#f0d9ce",
					strokeWidth: "1.1"
				}),
				/* @__PURE__ */ g("path", {
					d: "m7 4 6 10-6 14-3-3 1-18Z",
					fill: "#a91d24"
				}),
				/* @__PURE__ */ g("path", {
					d: "m7 4 21 11-15-1Z",
					fill: "#ff8070"
				}),
				/* @__PURE__ */ g("path", {
					d: "m13 14 14 4L7 28Z",
					fill: "#cf1e25"
				}),
				/* @__PURE__ */ g("path", {
					d: "m8 7 11 6-9-1-3 9Z",
					fill: "#ffb5a1",
					opacity: ".8"
				})
			]
		}) : /* @__PURE__ */ _("g", {
			stroke: "#887026",
			strokeWidth: "1",
			strokeLinejoin: "round",
			children: [
				/* @__PURE__ */ g("path", {
					d: "m16 2 14 10-5 17H7L2 12Z",
					fill: "#9e8525"
				}),
				/* @__PURE__ */ g("path", {
					d: "m16 4 12 9-4 14H8L4 13Z",
					fill: "#c7aa3b",
					stroke: "#e4cb68"
				}),
				/* @__PURE__ */ g("path", {
					d: "m16 7 3 7 8 1-6 5 1 7-6-4-6 4 1-7-6-5 8-1Z",
					fill: "#b69a30",
					stroke: "#e2c45a"
				}),
				/* @__PURE__ */ g("path", {
					d: "m16 10 2 5 5 1-4 3 1 5-4-3-4 3 1-5-4-3 5-1Z",
					fill: "#d5b743",
					stroke: "#a48a29",
					strokeWidth: ".7"
				}),
				/* @__PURE__ */ g("path", {
					d: "m16 5-2 6m-8 2 5 3m-3 9 5-3m11 3-5-3m8-9-6 3",
					fill: "none",
					stroke: "#8f7824",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ g("path", {
					d: "m4 12 4 15h16M16 3l12 9",
					fill: "none",
					stroke: "#e8cf6f"
				})
			]
		})
	});
}
function Q({ card: e, name: t, className: r = "" }) {
	let i = n().replaceAll(":", ""), a = e.upgrades.map((e) => x[e]).find((e) => e.ability === "ascended"), o = w(e), s = e.upgrades.map((e) => x[e]).find((e) => e.slot === "aura");
	return /* @__PURE__ */ _("svg", {
		className: `ch-card ${r}`,
		viewBox: "0 0 180 250",
		role: "img",
		"aria-label": `${t} ${T(e)}`,
		children: [
			/* @__PURE__ */ _("defs", { children: [
				/* @__PURE__ */ _("linearGradient", {
					id: `${i}-bg`,
					x2: ".7",
					y2: "1",
					children: [
						/* @__PURE__ */ g("stop", { stopColor: "#edf2dd" }),
						/* @__PURE__ */ g("stop", {
							offset: ".5",
							stopColor: "#92b2c0"
						}),
						/* @__PURE__ */ g("stop", {
							offset: "1",
							stopColor: "#334b79"
						})
					]
				}),
				/* @__PURE__ */ _("linearGradient", {
					id: `${i}-frame`,
					x2: "1",
					y2: "1",
					children: [
						/* @__PURE__ */ g("stop", { stopColor: "#293f88" }),
						/* @__PURE__ */ g("stop", {
							offset: ".4",
							stopColor: "#83acb9"
						}),
						/* @__PURE__ */ g("stop", {
							offset: ".5",
							stopColor: "#dce8df"
						}),
						/* @__PURE__ */ g("stop", {
							offset: ".54",
							stopColor: "#526da0"
						}),
						/* @__PURE__ */ g("stop", {
							offset: "1",
							stopColor: "#23305e"
						})
					]
				}),
				/* @__PURE__ */ g("clipPath", {
					id: `${i}-clip`,
					children: /* @__PURE__ */ g("rect", {
						x: "6",
						y: "6",
						width: "168",
						height: "238",
						rx: "12"
					})
				})
			] }),
			/* @__PURE__ */ g("rect", {
				x: "1",
				y: "1",
				width: "178",
				height: "248",
				rx: "15",
				fill: `url(#${i}-frame)`,
				stroke: "#23365c",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ _("g", {
				clipPath: `url(#${i}-clip)`,
				children: [
					/* @__PURE__ */ g("rect", {
						x: "8",
						y: "8",
						width: "164",
						height: "234",
						fill: `url(#${i}-bg)`
					}),
					/* @__PURE__ */ g("path", {
						d: "m0 165 50-52 30 19 40-37 60 10v145H0Z",
						fill: "#55728b",
						opacity: ".35"
					}),
					/* @__PURE__ */ g("path", {
						d: "M0 189 180 126M0 211l180-58M0 228l180-54",
						stroke: "#dce7db",
						strokeWidth: "2",
						opacity: ".45"
					}),
					/* @__PURE__ */ g("path", {
						d: "m21 0 36 250M150 0l-30 250",
						stroke: "#fffce8",
						opacity: ".2",
						strokeWidth: "16"
					}),
					a ? /* @__PURE__ */ g(De, {
						variant: a.id - C,
						id: `${i}-ascended`
					}) : /* @__PURE__ */ g(fe, {
						base: e.base,
						id: i
					}),
					s && /* @__PURE__ */ g(je, {
						value: s.value,
						id: `${i}-aura`
					}),
					!a && e.upgrades.map((e) => x[e]).filter((e) => e.slot === "left" || e.slot === "right").map((e) => /* @__PURE__ */ g(be, {
						u: e,
						id: `${i}-${e.slot}`
					}, e.id)),
					a && /* @__PURE__ */ g("rect", {
						x: "8",
						y: "8",
						width: "164",
						height: "234",
						rx: "10",
						fill: "none",
						stroke: "#dcc27a",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ g("path", {
						d: "M6 6h168l-11 28H39L26 52 6 42Z",
						fill: `url(#${i}-frame)`
					}),
					/* @__PURE__ */ g("path", {
						d: "m39 12 127 1-7 18H37Z",
						fill: "#bd3d32"
					}),
					/* @__PURE__ */ g("text", {
						x: "98",
						y: "26",
						textAnchor: "middle",
						fill: "#fff8df",
						fontSize: "12",
						fontWeight: "800",
						children: t
					}),
					/* @__PURE__ */ g("circle", {
						cx: "23",
						cy: "23",
						r: "17",
						fill: "#eef0e4",
						stroke: "#3b4960",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ g("text", {
						x: "23",
						y: "30",
						textAnchor: "middle",
						fontSize: Math.abs(T(e)) > 9 ? 19 : 23,
						fontWeight: "900",
						fill: s ? "#a52f36" : "#26354d",
						children: T(e)
					}),
					/* @__PURE__ */ g("path", {
						d: "M5 220q82 25 170 0v28H5Z",
						fill: "#30436b",
						opacity: ".95"
					}),
					[
						"right",
						"left",
						"aura",
						"buddy"
					].map((t, n) => /* @__PURE__ */ g("g", {
						transform: `translate(${56 + n * 23} 235)`,
						children: /* @__PURE__ */ g(Ne, {
							slot: t,
							filled: e.upgrades.some((e) => x[e].slot === t)
						})
					}, t)),
					o && o !== "ascended" && /* @__PURE__ */ g("g", {
						transform: "translate(111 166) scale(.86)",
						children: /* @__PURE__ */ g(_e, { ability: o })
					}),
					e.upgrades.filter((e) => x[e].slot === "left" || x[e].slot === "right").map((e, t) => /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("circle", {
						cx: "23",
						cy: 61 + t * 25,
						r: "11",
						fill: "#faf7e7",
						stroke: "#817b6e"
					}), /* @__PURE__ */ _("text", {
						x: "23",
						y: 65 + t * 25,
						textAnchor: "middle",
						fontSize: "12",
						fontWeight: "800",
						fill: "#26354d",
						children: [x[e].value > 0 ? "+" : "", x[e].value]
					})] }, e))
				]
			})
		]
	});
}
//#endregion
//#region src/games/customheroes/view-player.tsx
var ze = "(prefers-reduced-motion: reduce)";
function Be(e) {
	let t = window.matchMedia(ze);
	return t.addEventListener("change", e), () => t.removeEventListener("change", e);
}
var Ve = () => window.matchMedia(ze).matches;
function He({ card: e, name: t, area: n, active: r = !1 }) {
	let { ref: i, hidden: a } = o(`${n}:${e.id}`);
	return /* @__PURE__ */ g("span", {
		className: "ch-card-anchor",
		ref: i,
		"data-activated": r,
		style: { visibility: a ? "hidden" : void 0 },
		children: /* @__PURE__ */ g(Q, {
			card: e,
			name: t
		})
	});
}
function Ue({ player: e, name: t, active: n, mine: r, onWagers: i }) {
	let a = l(), { ref: c } = o(`seat:${e.rid}`);
	return /* @__PURE__ */ _("div", {
		ref: c,
		className: "ch-seat",
		"data-turn": n,
		"data-mine": r,
		"data-out": !e.active,
		children: [
			/* @__PURE__ */ g("strong", { children: t }),
			/* @__PURE__ */ _("span", {
				className: "ch-seat-score",
				children: [/* @__PURE__ */ g(Z, { kind: "vp" }), /* @__PURE__ */ g(s, { value: e.score })]
			}),
			/* @__PURE__ */ g("small", { children: e.place === null ? e.ready ? a("games.customheroes.ready") : a("games.customheroes.handCount", { n: e.handCount }) : a("games.customheroes.place", { n: e.place }) }),
			e.wagers.length > 0 && /* @__PURE__ */ _("button", {
				className: "ch-wager-mark",
				"aria-label": `${t} · ${a("games.customheroes.wagered", { n: e.wagers.length })}`,
				onClick: i,
				children: ["◆", e.wagers.length]
			})
		]
	});
}
function We(e) {
	return /* @__PURE__ */ g(Ge, { ...e });
}
function Ge({ public: e, private: t, members: n, myRid: v, send: y, review: b = !1 }) {
	f();
	let S = i(Be, Ve, () => !1), C = e, D = t, O = l(), k = c((e) => e.locale), A = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? m(t, k) : e;
	}, j = C.players.find((e) => e.rid === v), M = !b && C.phase === "play" && C.turn === v && j?.place === null, N = !b && C.phase === "upkeep" && !j?.ready && j?.active, ee = M || N, P = [...D?.hand ?? []].sort((e, t) => T(e) - T(t) || e.id - t.id), [F, I] = r([]), [te, L] = r([]), [ne, z] = r(!1), [B, V] = r(null), [H, U] = r(null), [W, G] = r(null), ie = `${C.round}|${C.phase}|${C.turn}|${v}`, [ae, oe] = r(ie);
	ie !== ae && (oe(ie), I([]), L([]));
	let K = P.filter((e) => F.includes(e.id)), q = te.filter((e) => K.some((t) => t.id === e)), J = R(K, q, D?.power ?? 0), se = M && J && re(J, C.table, C.descending, C.players.length === 2), { ref: ce } = o("table");
	d(!!(M || N || C.capPlayer === v && C.phase === "cap"), u);
	let le = (e) => {
		I(F.includes(e) ? F.filter((t) => t !== e) : [...F, e]), L(te.filter((t) => t !== e));
	}, ue = D?.upgrades.filter((e) => !N || x[e].ability === "kodora") ?? [], de = b ? O("games.customheroes.review") : C.phase === "upkeep" ? j?.ready ? O("games.customheroes.waiting", { name: C.players.filter((e) => !e.ready && e.active).map((e) => A(e.rid)).join(" · ") }) : O("games.customheroes.upkeep") : C.phase === "roundOver" ? O("games.customheroes.roundOver") : C.phase === "resolve" ? O("games.customheroes.resolving") : M ? O("games.customheroes.yourTurn") : O("games.customheroes.waiting", { name: A(C.capPlayer ?? C.turn) }), fe = J ? J.ascended ? O("games.customheroes.ascended") : O("games.customheroes.selection", {
		n: J.count,
		value: J.value
	}) : O("games.customheroes.invalidSet"), Y = C.log[C.log.length - 1], pe = Y ? Y.kind === "play" ? O(Y.value === 999 ? "games.customheroes.logAscended" : "games.customheroes.logPlay", {
		name: A(Y.rid),
		n: Y.n,
		value: Y.value
	}) : O({
		pass: "games.customheroes.logPass",
		wager: "games.customheroes.logWager",
		finish: "games.customheroes.logFinish",
		trick: "games.customheroes.logTrick",
		trade: "games.customheroes.logTrade",
		round: "games.customheroes.logRound",
		craft: "games.customheroes.craft"
	}[Y.kind], {
		name: A(Y.rid),
		n: Y.n
	}) : "";
	return /* @__PURE__ */ _(p, {
		adaptive: !0,
		className: "ch-screen",
		scroll: !1,
		banner: /* @__PURE__ */ _("div", {
			className: "ch-header",
			children: [/* @__PURE__ */ _("div", {
				className: "ch-round",
				children: [/* @__PURE__ */ g("span", { children: C.final ? O("games.customheroes.final") : O("games.customheroes.round", { n: C.round }) }), D && /* @__PURE__ */ _("b", {
					title: O("games.customheroes.power"),
					children: [/* @__PURE__ */ g(Z, { kind: "power" }), /* @__PURE__ */ g(s, { value: D.power })]
				})]
			}), /* @__PURE__ */ g("div", {
				className: "ch-seats",
				children: C.players.map((e) => /* @__PURE__ */ g(Ue, {
					player: e,
					name: A(e.rid),
					active: C.phase === "play" && C.turn === e.rid,
					mine: e.rid === v,
					onWagers: () => G(e.rid)
				}, e.rid))
			})]
		}),
		actionsHeight: "ch-actions-height",
		actions: /* @__PURE__ */ _("div", {
			className: "ch-actions",
			children: [/* @__PURE__ */ g("div", {
				className: "ch-ability-row",
				children: M && K.length ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("span", {
					className: se ? "ch-selection-valid" : "ch-selection-invalid",
					children: fe
				}), K.filter((e) => w(e) && w(e) !== "kodora").map((e) => {
					let t = w(e);
					return /* @__PURE__ */ g("button", {
						className: "ch-ability-toggle",
						"aria-pressed": q.includes(e.id),
						onClick: () => L(q.includes(e.id) ? q.filter((t) => t !== e.id) : [...q, e.id]),
						children: O("games.customheroes.activate", {
							name: `${T(e)} · ${O(Pe[t])}`,
							n: t === "ascended" ? 2 : 1
						})
					}, e.id);
				})] }) : /* @__PURE__ */ g("span", { children: de })
			}), /* @__PURE__ */ g("div", {
				className: "ch-buttons",
				children: C.phase === "upkeep" && !b ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("button", {
					className: "ch-primary",
					disabled: !N,
					onClick: () => y({ type: "ready" }),
					children: O("games.customheroes.ready")
				}), /* @__PURE__ */ g("button", {
					disabled: !N || !ue.length,
					onClick: () => {
						V(null), z(!0);
					},
					children: O("games.customheroes.craft")
				})] }) : C.phase === "roundOver" && !b ? /* @__PURE__ */ g("button", {
					className: "ch-primary",
					disabled: j?.ready || !j?.active,
					onClick: () => y({ type: "ready" }),
					children: O("games.customheroes.next")
				}) : /* @__PURE__ */ _(h, { children: [
					/* @__PURE__ */ g("button", {
						className: "ch-primary",
						disabled: !se,
						onClick: () => y({
							type: "play",
							cards: F,
							activate: q
						}),
						children: O("games.customheroes.play")
					}),
					/* @__PURE__ */ g("button", {
						disabled: !M || !C.table,
						onClick: () => y({ type: "pass" }),
						children: O("games.customheroes.pass")
					}),
					/* @__PURE__ */ _("button", {
						disabled: !D?.upgrades.length,
						onClick: () => {
							V(null), z(!0);
						},
						children: [
							O("games.customheroes.craft"),
							" ",
							/* @__PURE__ */ g("small", { children: D?.upgrades.length ?? 0 })
						]
					}),
					/* @__PURE__ */ _("button", {
						className: "ch-trade",
						title: O("games.customheroes.trade"),
						disabled: !M || (D?.power ?? 0) < 4,
						onClick: () => y({ type: "trade" }),
						children: [
							/* @__PURE__ */ g(Z, {
								kind: "power",
								size: 17
							}),
							"4 → ",
							/* @__PURE__ */ g(Z, {
								kind: "vp",
								size: 17
							}),
							"1"
						]
					})
				] })
			})]
		}),
		children: [
			/* @__PURE__ */ _("div", {
				className: "ch-arena",
				children: [/* @__PURE__ */ _("section", {
					className: "ch-trick",
					ref: ce,
					children: [
						/* @__PURE__ */ _("div", {
							className: "ch-trick-label",
							children: [/* @__PURE__ */ g("span", { children: C.table ? A(C.table.owner) : O("games.customheroes.lead") }), /* @__PURE__ */ g("b", { children: C.table?.ascended ? O("games.customheroes.ascended") : C.descending ? `↓ ${O("games.customheroes.descending")}` : `↑ ${O("games.customheroes.ascending")}` })]
						}),
						/* @__PURE__ */ g("div", {
							className: "ch-table-cards",
							children: C.table ? C.table.cards.map((e) => /* @__PURE__ */ g("button", {
								className: "ch-table-card",
								onClick: () => U(e),
								"aria-label": O("games.customheroes.cardLabel", {
									name: O(X[e.base - 1]),
									n: T(e)
								}),
								children: /* @__PURE__ */ g(He, {
									card: e,
									name: O(X[e.base - 1]),
									area: "table",
									active: C.table.activate.includes(e.id)
								})
							}, e.id)) : /* @__PURE__ */ g("div", {
								className: "ch-crest",
								"aria-hidden": "true",
								children: /* @__PURE__ */ _("svg", {
									viewBox: "0 0 240 130",
									children: [/* @__PURE__ */ g("path", {
										d: "m120 8 22 32 55-13-21 40 37 22-65 9-28 27-28-27-65-9 37-22-21-40 55 13Z",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "3"
									}), /* @__PURE__ */ g("path", {
										d: "m120 22 13 33 31-9-16 26 30 12-40 3-18 24-18-24-40-3 30-12-16-26 31 9Z",
										fill: "currentColor",
										opacity: ".25"
									})]
								})
							})
						}),
						/* @__PURE__ */ _("div", {
							className: "ch-trick-footer",
							children: [/* @__PURE__ */ g("span", { children: C.table && (C.table.ascended ? O("games.customheroes.ascended") : O("games.customheroes.selection", {
								n: C.table.count,
								value: C.table.value
							})) }), /* @__PURE__ */ g("small", {
								"aria-live": "polite",
								children: pe
							})]
						})
					]
				}), /* @__PURE__ */ _("section", {
					className: "ch-hand-zone",
					children: [/* @__PURE__ */ _("div", {
						className: "ch-hand-title",
						children: [
							/* @__PURE__ */ g("strong", { children: A(v) }),
							/* @__PURE__ */ g("span", { children: O("games.customheroes.handCount", { n: P.length }) }),
							j && j.wagers.length > 0 && /* @__PURE__ */ g("button", {
								onClick: () => U(j.wagers[0]),
								children: O("games.customheroes.wagered", { n: j.wagers.length })
							})
						]
					}), /* @__PURE__ */ _("div", {
						className: "ch-hand",
						children: [P.map((e) => /* @__PURE__ */ _("div", {
							className: "ch-hand-card",
							"data-selected": F.includes(e.id),
							children: [/* @__PURE__ */ g("button", {
								className: "ch-card-button",
								disabled: !M && !N,
								"aria-pressed": F.includes(e.id),
								"aria-label": O("games.customheroes.cardLabel", {
									name: O(X[e.base - 1]),
									n: T(e)
								}),
								onClick: () => N ? U(e) : le(e.id),
								children: /* @__PURE__ */ g(He, {
									card: e,
									name: O(X[e.base - 1]),
									area: "hand"
								})
							}), /* @__PURE__ */ g("button", {
								className: "ch-inspect",
								onClick: () => U(e),
								"aria-label": O("games.customheroes.inspect"),
								children: "ⓘ"
							})]
						}, e.id)), !P.length && /* @__PURE__ */ g("div", {
							className: "ch-empty-hand",
							children: O(j?.active === !1 ? "games.customheroes.eliminated" : "games.customheroes.noHand")
						})]
					})]
				})]
			}),
			/* @__PURE__ */ _(a, {
				open: ne,
				onClose: () => z(!1),
				label: O("games.customheroes.upgrades"),
				title: O(B === null ? "games.customheroes.upgrades" : "games.customheroes.chooseCard"),
				children: [/* @__PURE__ */ _("div", {
					className: "ch-inventory",
					children: [ue.map((e) => /* @__PURE__ */ _("button", {
						className: "ch-upgrade",
						"data-selected": B === e,
						disabled: !ee,
						onClick: () => V(e),
						children: [
							/* @__PURE__ */ g("svg", {
								className: "ch-gem",
								viewBox: "-8 -8 16 16",
								"aria-hidden": "true",
								children: /* @__PURE__ */ g(Ne, { slot: x[e].slot })
							}),
							/* @__PURE__ */ g("strong", { children: Le(x[e], O) }),
							/* @__PURE__ */ g("p", { children: Re(x[e], O) })
						]
					}, e)), !ue.length && /* @__PURE__ */ g("p", { children: O("games.customheroes.emptyInventory") })]
				}), B !== null && /* @__PURE__ */ g("div", {
					className: "ch-craft-targets",
					children: P.map((e) => {
						let t = !!ee && E(e, x[B]);
						return /* @__PURE__ */ _("button", {
							className: "ch-craft-target",
							"data-legal": t,
							disabled: !t,
							onClick: () => {
								y({
									type: "craft",
									card: e.id,
									upgrade: B
								}), V(null), z(!1);
							},
							children: [
								/* @__PURE__ */ g(Q, {
									card: e,
									name: O(X[e.base - 1])
								}),
								/* @__PURE__ */ g("span", { children: O("games.customheroes.attach") }),
								t && /* @__PURE__ */ g("svg", {
									className: "ch-choice-outline",
									viewBox: "0 0 180 250",
									preserveAspectRatio: "none",
									"aria-hidden": "true",
									children: /* @__PURE__ */ g("rect", {
										x: "2",
										y: "2",
										width: "176",
										height: "246",
										rx: "14",
										children: !S && /* @__PURE__ */ g("animate", {
											attributeName: "stroke-dashoffset",
											values: "0;-24",
											dur: "1.2s",
											repeatCount: "indefinite"
										})
									})
								})
							]
						}, e.id);
					})
				})]
			}),
			/* @__PURE__ */ g(a, {
				open: H !== null,
				onClose: () => U(null),
				label: O("games.customheroes.inspect"),
				title: H ? O(X[H.base - 1]) : "",
				children: H && /* @__PURE__ */ _("div", {
					className: "ch-detail",
					children: [/* @__PURE__ */ g(Q, {
						card: H,
						name: O(X[H.base - 1])
					}), /* @__PURE__ */ _("div", { children: [
						/* @__PURE__ */ g("h3", { children: O("games.customheroes.cardLabel", {
							name: O(X[H.base - 1]),
							n: T(H)
						}) }),
						H.upgrades.map((e) => /* @__PURE__ */ _("p", { children: [
							/* @__PURE__ */ g("b", { children: Le(x[e], O) }),
							/* @__PURE__ */ g("br", {}),
							Re(x[e], O)
						] }, e)),
						N && w(H) === "kodora" && P.some((e) => e.id === H.id) && /* @__PURE__ */ g("button", {
							className: "ch-primary",
							disabled: (j?.score ?? 0) < 2,
							onClick: () => {
								y({
									type: "wager",
									card: H.id
								}), U(null);
							},
							children: O("games.customheroes.wager")
						})
					] })]
				})
			}),
			/* @__PURE__ */ g(a, {
				open: W !== null,
				onClose: () => G(null),
				label: O("games.customheroes.kodora"),
				title: W ? `${A(W)} · ${O("games.customheroes.kodora")}` : "",
				children: /* @__PURE__ */ g("div", {
					className: "ch-craft-targets",
					children: C.players.find((e) => e.rid === W)?.wagers.map((e) => /* @__PURE__ */ g("button", {
						className: "ch-craft-target",
						onClick: () => {
							G(null), U(e);
						},
						children: /* @__PURE__ */ g(Q, {
							card: e,
							name: O(X[e.base - 1])
						})
					}, e.id))
				})
			}),
			/* @__PURE__ */ _(a, {
				open: !b && C.phase === "cap" && C.capPlayer === v,
				label: O("games.customheroes.cap"),
				title: O("games.customheroes.cap"),
				children: [/* @__PURE__ */ g("p", { children: O("games.customheroes.capHelp") }), Array.from({ length: Math.floor((D?.power ?? 0) / 4) + 1 }, (e, t) => /* @__PURE__ */ g("button", {
					className: "ch-cap-choice",
					onClick: () => y({
						type: "cap",
						trades: t
					}),
					children: O("games.customheroes.capChoice", {
						n: t,
						power: Math.min(6, (D?.power ?? 0) - 4 * t)
					})
				}, t))]
			})
		]
	});
}
//#endregion
//#region src/games/customheroes/bot.ts
var Ke = {
	group: 2,
	power: .45,
	craft: 1,
	wager: 2.4
};
function qe(e, t, n) {
	let r = [];
	for (let e of t) w(e) === "ascended" && n >= 2 && r.push({
		type: "play",
		cards: [e.id],
		activate: [e.id]
	});
	if (e.table?.ascended) return r;
	let i = [...new Set(t.map(T))];
	for (let a of i) {
		let i = t.filter((e) => T(e) === a || w(e) === "edge"), o = [], s = [], c = e.table?.count ?? t.length * 2;
		function l(t, u, d, f) {
			if (u > c || d > n) return;
			if (t === i.length) {
				if (!u || !f || e.table && u !== c) return;
				let t = R(o, s, n);
				t && re(t, e.table, e.descending, e.players.length === 2) && r.push({
					type: "play",
					cards: o.map((e) => e.id),
					activate: [...s]
				});
				return;
			}
			l(t + 1, u, d, f);
			let p = i[t], m = w(p);
			o.push(p), T(p) === a && l(t + 1, u + 1, d, !0), m && m !== "kodora" && m !== "ascended" && (s.push(p.id), m === "edge" ? l(t + 1, u + 1, d + 1, f) : T(p) === a && l(t + 1, u + (m === "burny" ? 2 : 1), d + 1, !0), s.pop()), o.pop();
		}
		l(0, 0, 0, !1);
	}
	return r;
}
function $(e) {
	let t = /* @__PURE__ */ new Map();
	return e.forEach((e) => t.set(T(e), (t.get(T(e)) ?? 0) + 1)), e.length - t.size;
}
function Je(e, t, n, r) {
	let i = t.hand.filter((e) => n.cards.includes(e.id)), a = R(i, n.activate, t.power), o = t.hand.filter((e) => !n.cards.includes(e.id));
	if (!o.length) return 1e4;
	let s = 0, c = 0;
	for (let e of i) w(e) && (n.activate.includes(e.id) ? s += w(e) === "ascended" ? 2 : 1 : c++);
	let l = e.descending ? -1 : 1, u = o.length ? Math.min(...o.map((e) => l * T(e))) : 0, d = i.filter((e) => n.activate.includes(e.id) && w(e) === "charmy").length % 2, f = a.ascended ? 5 : l * a.value;
	return i.length * 8 + r.group * ($(o) - $(t.hand)) + r.power * (c - s) - (e.table ? Math.max(0, f - l * e.table.value) * .06 : f * .12) + (d ? l * a.value < u ? 1.2 : -.5 : 0) + a.spectors * (f > 10 ? .6 : -.7);
}
function Ye(e = Ke) {
	return ({ public: t, private: n }, r) => {
		let i = t.players.find((e) => e.rid === r.rid);
		if (!i?.active || !n || t.phase === "done" || t.phase === "resolve") return null;
		let a = r.difficulty === "weak";
		if (t.phase === "upkeep") {
			if (i.ready) return null;
			if (!a && i.score >= 2 && $(n.hand) >= e.wager && n.hand.length >= 7) {
				let e = n.hand.find((e) => w(e) === "kodora");
				if (e) return { action: {
					type: "wager",
					card: e.id
				} };
				let t = n.upgrades.find((e) => x[e].ability === "kodora"), r = [...n.hand].sort((e, t) => T(e) - T(t)).find((e) => t !== void 0 && E(e, x[t]));
				if (t !== void 0 && r) return { action: {
					type: "craft",
					card: r.id,
					upgrade: t
				} };
			}
			return { action: { type: "ready" } };
		}
		if (t.phase === "roundOver") return i.ready ? null : { action: { type: "ready" } };
		if (t.phase === "cap") return t.capPlayer === r.rid ? { action: {
			type: "cap",
			trades: Math.max(1, Math.floor((n.power - 3) / 4))
		} } : null;
		if (t.turn !== r.rid || i.place !== null) return null;
		let o = qe(t, n.hand, n.power).map((r) => ({
			a: r,
			value: Je(t, n, r, e)
		})).sort((e, t) => t.value - e.value);
		if (!a && e.craft > 0) {
			let r = o[0]?.value ?? -20, i = null;
			for (let a of n.upgrades) {
				let o = x[a];
				if (o.ability !== "kodora") for (let s of n.hand) {
					if (!E(s, o)) continue;
					let c = {
						...n,
						hand: n.hand.map((e) => e.id === s.id ? {
							...e,
							upgrades: [...e.upgrades, a]
						} : e)
					}, l = qe(t, c.hand, c.power).reduce((n, r) => Math.max(n, Je(t, c, r, e)), -20) + e.craft * ($(c.hand) - $(n.hand)) - .8;
					l > r + .05 && (r = l, i = {
						type: "craft",
						card: s.id,
						upgrade: a
					});
				}
			}
			if (i) return { action: i };
		}
		return !a && n.power >= 4 && (i.score >= 9 && n.hand.length <= 3 || n.power >= 6 && !o[0]?.a.activate.length) ? { action: { type: "trade" } } : o.length ? { action: a ? o[o.length - 1].a : o[0].a } : { action: { type: "pass" } };
	};
}
var Xe = Ye();
//#endregion
//#region src/games/customheroes/fx.tsx
function Ze({ card: e }) {
	let t = l();
	return /* @__PURE__ */ g(Q, {
		card: e,
		name: t(X[e.base - 1])
	});
}
var Qe = {
	play(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		if (!r || !n?.cards?.length) return null;
		let i = n.cards.map((e) => ({
			card: e,
			to: t.anchor(`table:${e.id}`)
		})).filter((e) => e.to !== null);
		return i.length ? {
			ms: 650,
			hide: i.map(({ card: e }) => `table:${e.id}`),
			node: i.map(({ card: e, to: t }) => /* @__PURE__ */ g(v, {
				from: {
					x: r.x,
					y: r.y,
					w: t.w,
					h: t.h
				},
				to: t,
				ms: 420,
				children: /* @__PURE__ */ g("div", {
					style: {
						width: t.w,
						height: t.h
					},
					children: /* @__PURE__ */ g(Ze, { card: e })
				})
			}, e.id))
		} : null;
	},
	craft(e, t) {
		let n = e.secret, r = n?.card === void 0 ? null : t.anchor(`hand:${n.card}`);
		return r ? {
			ms: 420,
			node: /* @__PURE__ */ g(y, {
				at: r,
				ms: 420
			})
		} : null;
	}
};
//#endregion
//#region src/games/customheroes/game-over.tsx
function $e(e) {
	let { result: t, members: n, myRid: i, onPlayAgain: a, onBackToLobby: o, hintCount: s } = e, u = e.public, d = l(), f = c((e) => e.locale), [p, h] = r(!0), v = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? m(t, f) : e;
	};
	return /* @__PURE__ */ _("div", {
		className: "ch-result-shell",
		children: [
			/* @__PURE__ */ g(Ge, {
				public: u,
				private: e.private,
				members: n,
				myRid: i,
				send: () => {},
				review: !0
			}),
			!p && /* @__PURE__ */ g("button", {
				className: "ch-primary ch-result-review",
				onClick: () => h(!0),
				children: d("games.customheroes.showResult")
			}),
			/* @__PURE__ */ _("div", {
				className: "ch-results",
				hidden: !p,
				children: [/* @__PURE__ */ g(b, {}), /* @__PURE__ */ _("div", {
					className: "ch-result-panel",
					children: [
						/* @__PURE__ */ _("div", {
							className: "ch-result-top",
							children: [/* @__PURE__ */ g("h1", { children: d("games.customheroes.result") }), /* @__PURE__ */ g("button", {
								onClick: () => h(!1),
								children: d("games.customheroes.review")
							})]
						}),
						/* @__PURE__ */ _("div", {
							className: "ch-result-content",
							children: [
								/* @__PURE__ */ _("div", {
									className: "ch-champion",
									children: [/* @__PURE__ */ _("svg", {
										viewBox: "0 0 120 120",
										"aria-hidden": "true",
										children: [
											/* @__PURE__ */ g("path", {
												d: "m31 17 20 12 9-21 10 21 20-12-7 37H38Z",
												fill: "#e9ca79",
												stroke: "#8c682c",
												strokeWidth: "2"
											}),
											/* @__PURE__ */ g("path", {
												d: "m40 51 5 19-14 36 28-12 30 12-15-37 6-18Z",
												fill: "#3b5b85"
											}),
											/* @__PURE__ */ g("circle", {
												cx: "60",
												cy: "68",
												r: "27",
												fill: "#d2ad59",
												stroke: "#977132",
												strokeWidth: "2"
											}),
											/* @__PURE__ */ g("circle", {
												cx: "60",
												cy: "68",
												r: "21",
												fill: "#f2dc9d",
												stroke: "#b38a42"
											}),
											/* @__PURE__ */ g("path", {
												d: "m60 48 5 13 14 1-11 9 4 14-12-8-12 8 4-14-11-9 14-1Z",
												fill: "#b79247"
											}),
											/* @__PURE__ */ g("path", {
												d: "m38 22 6 20m38-19-6 20",
												stroke: "#fff0b8",
												strokeWidth: "3"
											})
										]
									}), /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("h2", { children: t.winner.map(v).join(" · ") }), /* @__PURE__ */ g("p", { children: d("games.customheroes.resultReason", { n: u.round }) })] })]
								}),
								/* @__PURE__ */ g("ol", {
									className: "ch-result-ranking",
									children: t.ranking.map((e, n) => /* @__PURE__ */ _("li", {
										"data-winner": t.winner.includes(e),
										children: [
											/* @__PURE__ */ g("strong", { children: n + 1 }),
											/* @__PURE__ */ _("div", {
												className: "ch-result-person",
												children: [/* @__PURE__ */ g("span", { children: v(e) }), (t.autopilot?.[e] ?? 0) > 0 && /* @__PURE__ */ g("small", { children: d("session.autopilot.share", { n: Math.round(t.autopilot[e] * 100) }) })]
											}),
											/* @__PURE__ */ _("span", {
												className: "ch-result-points",
												children: [/* @__PURE__ */ g(Z, {
													kind: "vp",
													size: 24
												}), t.scores?.[e] ?? u.players.find((t) => t.rid === e)?.score]
											})
										]
									}, e))
								}),
								s !== void 0 && /* @__PURE__ */ g("p", {
									className: "ch-result-hints",
									children: d("session.hint.usedCount", { n: s })
								})
							]
						}),
						/* @__PURE__ */ _("div", {
							className: "ch-result-controls",
							children: [
								a && /* @__PURE__ */ g("button", {
									className: "ch-primary",
									onClick: a,
									children: d("session.result.playAgain")
								}),
								o && /* @__PURE__ */ g("button", {
									className: "ch-primary",
									onClick: o,
									children: d("session.result.backToLobby")
								}),
								!a && !o && /* @__PURE__ */ g("p", {
									className: "ch-result-wait",
									children: d("session.result.waitHost")
								})
							]
						})
					]
				})]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/customheroes/entry.tsx
var et = {
	definition: G,
	View: We,
	bot: Xe,
	fx: Qe,
	OverView: $e,
	locales: {
		zh: {
			name: "百变英雄",
			desc: "叠加装备改变英雄，抢先出完手牌",
			rules: "目标：先拥有至少 10 胜利点，再成为某轮第一个出完手牌的人。该轮第一名奖励不能用于立即获胜。\n准备：\n每个点数 1–10 取与人数相等的角色卡；双人改用每值 3 张。每人 1 胜利点、2 能量、1 张升华、1 张科多拉和 1 张随机升级；双人随机升级为 3 张。每轮洗匀全部角色卡，每人发 10 张，双人发 15 张；卡上的升级永久保留。\n准备阶段可以安装科多拉，支付 2 胜利点，将该角色置于手牌外押注，本轮不能打出。每张科多拉可单独押注。准备后开始出牌。\n出牌：\n领出者打出任意张同值牌。其余玩家依次打出张数相同、点数相等或更大的同值牌组，或过牌。原双人局必须严格大于。过牌后仍可再次参与；多人局同值接牌跳过下一位尚未出完的玩家。被跳过者之后仍可参与。\n当连续过牌或跳过使行动回到最后出牌者时，牌墩结束，由其领出新牌墩；若其已出完，则由左侧下一位未出完者领出。只剩一人有手牌时，本轮结束。\n升级：\n自己回合出牌前，可免费把任意库存升级永久装入手牌。每张卡最多容纳光环、左手、右手、伙伴各一张。光环重设基础点数，左右手修正点数，最终可以为零或负数。升级不能移除；下轮重新发牌，可能换人持有。\n伙伴能力：\n· 燃火兔（Burny）：支付 1 能量，该卡计为两张。\n· 利刃兽（Edge）：支付 1 能量，作为同组其他牌点数的百搭；必须至少有一张固定点数牌，不能全是百搭。\n· 恶灵球（Spector）：支付 1 能量，若这组牌最终赢得牌墩，每张已发动的恶灵球获得 1 胜利点；被压过则无奖励。\n· 小魅灵（Charmy）：支付 1 能量，合法打出后反转当前牌墩的大小比较方向；双人仍不允许同值接牌。牌墩结束后恢复递增。\n· 升华（Ascended Form）：支付 2 能量，必须单张打出，可以压任何普通牌组；之后只能接另一张已发动的升华。多人局升华接升华仍跳过下家，原双人局不跳过。\n· 科多拉（Kodora）：准备阶段押注。若第一出完，收回押注的 2 胜利点并额外获得 2 胜利点，再检查获胜门槛；否则押注丢失。押注牌下轮重新洗回。\n带伙伴能力的卡不发动能力打出时，每张获得 1 能量；这些能量不能用于同一组其他牌的发动费用。自己回合可用 4 能量换 1 胜利点；回合末或名次结算后超过 6 能量时，选择兑换若干次后将剩余能量减至 6。\n名次奖励：\n下列每项依次为“胜利点／能量／随机升级”，按第一至末名排列：\n2 人：4／0／2；−1／1／2。\n3 人：5／0／1；2／1／2；−1／2／3。\n4 人：5／0／1；3／1／2；1／2／2；−1／2／3。\n5 人：5／0／1；3／1／2；2／1／2；1／2／2；−1／2／3。\n6 人：5／0／1；4／1／1；3／1／2；2／2／2；1／2／3；−1／3／3。\n出完时立即领取名次奖励；积分最低为零。末名结算后若仍有至少 10 胜利点，降至 9。升级袋耗尽时只抽剩余卡。下一轮由本轮末名先手。\n结束：\n六轮后仍无人正常获胜，若第六轮第一名的积分独占最高，其立即获胜。否则第六轮第一名与所有积分最高者进入第七轮决赛，由这些人中第六轮名次最差者先手。洗匀全部牌库，原双人每人发 15 张，原多人发 10 张，余牌不公开；仍使用原游戏人数对应的同值规则。决赛第一位出完者获胜，不要求积分门槛。",
			invalid: "当前不能执行这个行动",
			round: "第 {{n}} 轮",
			final: "最终决赛",
			score: "胜利点",
			power: "能量",
			handCount: "手牌 {{n}}",
			place: "第 {{n}} 名",
			ready: "准备完成",
			next: "下一轮",
			waiting: "等待 {{name}}",
			yourTurn: "轮到你出牌",
			upkeep: "可以押注科多拉，或准备开始",
			roundOver: "本轮结束",
			resolving: "结算中",
			lead: "领出新牌墩",
			ascending: "点数递增",
			descending: "点数递减",
			ascended: "升华",
			play: "出牌",
			pass: "过牌",
			craft: "升级",
			trade: "4 能量换 1 胜利点",
			selection: "{{n}} 张 · 点数 {{value}}",
			invalidSet: "请选择合法的同值牌组",
			activate: "发动 {{name}}（{{n}} 能量）",
			abilityOff: "{{name}}：未发动",
			inspect: "卡牌详情",
			cardLabel: "{{name}}，点数 {{n}}",
			upgrades: "升级库存",
			chooseCard: "选择要永久升级的角色",
			attach: "安装升级",
			emptyInventory: "没有可用升级",
			wager: "押注科多拉（2 胜利点）",
			wagered: "已押注 {{n}} 张",
			cap: "能量超过上限",
			capChoice: "兑换 {{n}} 胜利点，保留 {{power}} 能量",
			capHelp: "选择兑换次数，超过 6 的剩余能量将被丢弃。",
			ability: "伙伴",
			aura: "光环",
			left: "左手装备",
			right: "右手装备",
			buddy: "伙伴",
			burny: "燃火兔",
			edge: "利刃兽",
			spector: "恶灵球",
			charmy: "小魅灵",
			kodora: "科多拉",
			burnyEffect: "支付 1 能量，计为两张牌。",
			edgeEffect: "支付 1 能量，匹配同组固定牌的点数。",
			spectorEffect: "支付 1 能量，赢得这个牌墩时获得 1 胜利点。",
			charmyEffect: "支付 1 能量，合法打出后反转比较方向。",
			kodoraEffect: "准备阶段支付 2 胜利点押注；第一出完时收回并额外获得 2 胜利点。",
			ascendedEffect: "支付 2 能量，单张压任何普通牌组，之后只能接升华。",
			auraEffect: "将基础点数重设为 {{n}}。",
			itemEffect: "永久修正点数 {{n}}。",
			hero1: "道雄",
			hero2: "晶子",
			hero3: "智",
			hero4: "久美",
			hero5: "岩",
			hero6: "美纱绪",
			hero7: "吉郎",
			hero8: "机器人",
			hero9: "芳间",
			hero10: "赛博人",
			logPlay: "{{name}} 打出 {{n}} 张，点数 {{value}}",
			logAscended: "{{name}} 打出升华",
			logPass: "{{name}} 过牌",
			logWager: "{{name}} 押注科多拉",
			logFinish: "{{name}} 获得第 {{n}} 名",
			logTrick: "{{name}} 赢得牌墩",
			logTrade: "{{name}} 兑换 1 胜利点",
			logRound: "第 {{n}} 轮开始",
			result: "英雄桂冠",
			resultReason: "第 {{n}} 轮率先出完手牌",
			review: "回看牌桌",
			showResult: "查看结果",
			eliminated: "未进入决赛",
			noHand: "本轮手牌已出完",
			hintPlay: "打出 {{n}} 张牌。",
			hintCraft: "给点数 {{n}} 的角色安装升级。",
			hintPass: "这次过牌，保留手牌。",
			hintReady: "完成准备，继续对局。",
			hintTrade: "用能量兑换胜利点。",
			hintWager: "用科多拉押注本轮第一名。"
		},
		en: {
			name: "Custom Heroes",
			desc: "Craft evolving heroes and race to empty your hand",
			rules: "Goal: Have at least 10 victory points, then be the first to empty your hand in a round. That round’s placement reward cannot satisfy this requirement.\nSetup:\nUse one set of values 1–10 per player; with two players use three sets. Each player starts with 1 VP, 2 power, an Ascended Form, a Kodora and one random advancement (three random advancements with two players). Shuffle all character cards each round, keeping all sleeved advancements attached. Deal ten cards each, or fifteen in an originally two-player game.\nDuring upkeep, you may sleeve Kodora and wager 2 VP per Kodora, setting those characters aside for the round. Then everyone confirms readiness.\nPlay:\nThe leader plays any number of cards of one value. Each following player plays the same number of matching cards with an equal or higher value, or passes. Originally two-player games require a strictly higher value. Passing does not prevent playing later. In multiplayer games, matching the previous value skips the next unfinished player; they may participate later.\nWhen consecutive passes or skips return to the last player who played, that player wins the trick and leads again. If they have finished, the next unfinished player to their left leads. The round ends when only one player has cards.\nCrafting:\nAt the start of your turn, before playing, freely sleeve advancements from your inventory into cards in your hand. Each card may have one aura, left-hand item, right-hand item and buddy. An aura replaces the base value; items modify it. Values can be zero or negative. Advancements cannot be removed, and the card may be dealt to someone else next round.\nAbilities:\n· Burny: Pay 1 power for this card to count as two cards.\n· Edge: Pay 1 power to match another fixed-value card in the set. At least one card must have a fixed value; an entirely wild set is illegal.\n· Spector: Pay 1 power; if this play wins the trick, gain 1 VP per activated Spector. Being beaten gives no reward.\n· Charmy: Pay 1 power. After a legal play, reverse the comparison direction for this trick. Two-player games still require unequal values. The next trick returns to ascending.\n· Ascended Form: Pay 2 power and play it alone to beat any ordinary set. Only another activated Ascended Form can follow. Ascended-on-Ascended skips in multiplayer, but not in an originally two-player game.\n· Kodora: Wager 2 VP during upkeep and set the card aside. If you finish first, recover the wager and gain 2 additional VP before checking victory. Otherwise lose the wager. The card returns to the deck next round.\nPlaying a card with an unused ability gains 1 power per card, after paying all activation costs. This new power cannot pay for other abilities in the same play. On your turn, trade 4 power for 1 VP. At the end of a turn or placement scoring, if you exceed 6 power, choose exchanges and discard any remaining excess down to 6.\nPlacement:\nEach entry is VP / power / random advancements, from first to last:\n2 players: 4/0/2; −1/1/2.\n3 players: 5/0/1; 2/1/2; −1/2/3.\n4 players: 5/0/1; 3/1/2; 1/2/2; −1/2/3.\n5 players: 5/0/1; 3/1/2; 2/1/2; 1/2/2; −1/2/3.\n6 players: 5/0/1; 4/1/1; 3/1/2; 2/2/2; 1/2/3; −1/3/3.\nClaim your reward immediately on finishing. VP cannot fall below zero. If last place still has at least 10 VP after scoring, reset to 9. Draw only the advancements remaining if the bag runs out. Last place leads the next round.\nEnding:\nIf nobody wins normally after six rounds and the sixth-round winner has uniquely the most VP, they win. Otherwise that winner and everyone tied for most VP enter a seventh-round final, led by the qualifier who placed worst in round six. Shuffle the entire deck; deal fifteen each in an originally two-player game, otherwise ten. Keep unused cards hidden and retain the original game’s equal-value rule. The first player to empty their hand wins, regardless of VP.",
			invalid: "That action is not available now",
			round: "Round {{n}}",
			final: "Sudden death",
			score: "Victory points",
			power: "Power",
			handCount: "{{n}} cards",
			place: "Place {{n}}",
			ready: "Ready",
			next: "Next round",
			waiting: "Waiting for {{name}}",
			yourTurn: "Your turn",
			upkeep: "Wager a Kodora or get ready",
			roundOver: "Round complete",
			resolving: "Resolving",
			lead: "Lead a new trick",
			ascending: "Ascending",
			descending: "Descending",
			ascended: "Ascended Form",
			play: "Play",
			pass: "Pass",
			craft: "Craft",
			trade: "4 power for 1 VP",
			selection: "{{n}} cards · value {{value}}",
			invalidSet: "Select a legal matching set",
			activate: "Activate {{name}} ({{n}} power)",
			abilityOff: "{{name}}: inactive",
			inspect: "Card details",
			cardLabel: "{{name}}, value {{n}}",
			upgrades: "Advancements",
			chooseCard: "Choose a character to craft permanently",
			attach: "Sleeve advancement",
			emptyInventory: "No available advancements",
			wager: "Wager Kodora (2 VP)",
			wagered: "{{n}} Kodora wagers",
			cap: "Power limit exceeded",
			capChoice: "Gain {{n}} VP, keep {{power}} power",
			capHelp: "Choose exchanges. Remaining power above 6 is discarded.",
			ability: "Buddy",
			aura: "Aura",
			left: "Left-hand item",
			right: "Right-hand item",
			buddy: "Buddy",
			burny: "Burny",
			edge: "Edge",
			spector: "Spector",
			charmy: "Charmy",
			kodora: "Kodora",
			burnyEffect: "Pay 1 power to count as two cards.",
			edgeEffect: "Pay 1 power to match a fixed-value card in this set.",
			spectorEffect: "Pay 1 power to gain 1 VP if this play wins the trick.",
			charmyEffect: "Pay 1 power to reverse the comparison after a legal play.",
			kodoraEffect: "Wager 2 VP during upkeep. Finish first to recover it and gain 2 more VP.",
			ascendedEffect: "Pay 2 power, play alone to beat any ordinary set. Only Ascended Forms can follow.",
			auraEffect: "Reset the base value to {{n}}.",
			itemEffect: "Permanently modify the value by {{n}}.",
			hero1: "Michio",
			hero2: "Akiko",
			hero3: "Satoshi",
			hero4: "Kumi",
			hero5: "Iwao",
			hero6: "Misao",
			hero7: "Kichiro",
			hero8: "Robot",
			hero9: "Yoshima",
			hero10: "Cyborg",
			logPlay: "{{name}} played {{n}} cards, value {{value}}",
			logAscended: "{{name}} played an Ascended Form",
			logPass: "{{name}} passed",
			logWager: "{{name}} wagered Kodora",
			logFinish: "{{name}} finished in place {{n}}",
			logTrick: "{{name}} won the trick",
			logTrade: "{{name}} traded for 1 VP",
			logRound: "Round {{n}} begins",
			result: "Hero’s laurels",
			resultReason: "First to finish in round {{n}}",
			review: "Review table",
			showResult: "Show results",
			eliminated: "Outside the final",
			noHand: "You have finished this round",
			hintPlay: "Play {{n}} cards.",
			hintCraft: "Craft the character currently valued at {{n}}.",
			hintPass: "Pass and keep your cards.",
			hintReady: "Confirm readiness to continue.",
			hintTrade: "Exchange power for VP.",
			hintWager: "Wager Kodora on finishing first."
		}
	}
};
//#endregion
export { et as default };
