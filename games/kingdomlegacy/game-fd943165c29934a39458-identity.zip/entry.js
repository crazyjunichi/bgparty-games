import { z as e } from "zod";
import { randomIntAt as t } from "@bgparty/sdk/engine/prng";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconClose as u, IconDownload as d, IconHistory as f, IconPlay as p } from "@bgparty/sdk/icons";
import { ConfirmButton as m } from "@bgparty/sdk/confirm-button";
import { BottomSheet as h } from "@bgparty/sdk/bottom-sheet";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { readGameStorage as g, writeGameStorage as _ } from "@bgparty/sdk/storage";
import { Fragment as te, jsx as v, jsxs as y } from "react/jsx-runtime";
import { FlySprite as b, PulseBox as ne } from "@bgparty/sdk/fx/primitives";
import { GameOverChime as re } from "@bgparty/sdk/ui/game-over-screen";
//#region \0bgparty-json:D:/Other/BG/BGParty/src/games/kingdomlegacy/card-data.json.mjs
var ie = await fetch("games/kingdomlegacy/data/card-data.json").then((e) => e.json()), ae = Object.fromEntries("wild_grass=草地\nplains=平原\nfarmlands=农田\nfood_barns=粮仓\ndistant_mountain=远山\nrocky_area=岩地\nquarry=采石场\nshallow_mines=浅矿井\nforest=森林\nriver=河流\nmason=石匠\nroyal_architect=皇家建筑师\ntraveller=旅人\nshipyard=造船厂\nsweet_water_river=淡水河\nfelled_forest=伐后林地\nlumberjack=伐木场\nsacred_well=圣井\nheadquarters=总部\ntown_hall=市政厅\nkeep=城堡主楼\ncastle=城堡\ntrader=商贩\nbazaar=集市\nmarket=市场\ntrader_obj=商人\npine_forest=松林\njungle=丛林\nhuge_trees=巨木\ndeep_jungle=密林\nbridge=桥梁\nexplorers=探险家\nstone_bridge=石桥\nbridge_of_marvel=奇迹之桥\nfield_worker=田间劳工\nbandit=强盗\nworker=工人\nlabourer=劳工\nservant=仆人\nchapel=小教堂\nchurch=教堂\ncathedral=大教堂\nsmithy=铁匠铺\narsenal=军械库\nhill=山丘\nhill_settlement=山丘聚落\nsmall_hill_town=山丘小镇\nhill_town=山丘城镇\npond=池塘\nfish_pond=鱼塘\nlake=湖泊\nlighthouse=灯塔\nfishing_boat=渔船\nstop=停下\nfertile_soil_efficiency=沃土与效率\narmy=军队\ngrand_army=大军\ntreasure=宝藏\nextended_treasure=巨额宝藏\nexport=出口\nmass_export=大量出口\nyoung_forest=幼林\nplague=瘟疫\nsickness=疾病\ncrippled=残障\ncooperation=合作\njester=弄臣\npretend_noble=冒牌贵族\nentrepreneur=企业家\ninvestor=投资者\ninventor=发明家\ninspired_inventor=灵感迸发的发明家\ninn=旅店\ntavern=酒馆\ncozy_pub=温馨酒吧\nhotel=旅馆\nmercenary=佣兵\nrecruit=新兵\nsquire=侍从\nloyalty=忠诚\nstrength_in_number=人多势众\nmilitary_domination=军事统治\nhoarding=囤积\nmaximizer=极致追求\nquests=任务\nprosperity_expansion=繁荣小扩展\nopportunist=投机者\nthunderstorm=雷暴\ntornado=龙卷风\nrain=雨水\nfish_n_chips=炸鱼薯条\nbrick_road=砖路\nstone_street=石街\ncanals=运河\ncity_fire=城市大火\nashlands=灰烬之地\ndark_knight=黑骑士\nbackstabber=背叛者\ntraining_grounds=训练场\ntrade_relations=贸易关系\ndiplomat=外交官\nemissary=特使\nenvoy=使节\nambassador=大使\ndeep_pit=深坑\nchasm=裂隙\npit_settlement=坑地聚落\nlarge_town=大城市\nmagistrate=地方官\noratory=演说术\nscribe=书记员\nstrategist=战略家\nskilled_ally=能干的盟友\nnoble_ally=贵族盟友\nhill_village=丘陵村庄\npeak_village=山顶村庄\nwitch=女巫\nwitch_cabin=女巫小屋\nblood_curse=血咒\narchitect=建筑师\nlord_nimrod=尼姆罗德领主\nskilled_bandit=老练强盗\nenemy_soldier=敌兵\nassassin=刺客\nvolcanic_eruption=火山喷发\nfountain=喷泉\ntreasures=珍宝\npirate_treasure=海盗宝藏\nlost_civilization=失落文明\ninnkeeper=旅店老板\nnoble_residence=贵族宅邸\nflooding=洪水\nyoung_princess=年轻公主\nspoiled_princess=娇纵公主\neducated_princess=博学公主\nlooting=劫掠\nplundering=掠夺\npillaging=劫掠战利品\nfinishing_touch=最后的润色\npost_barbaric=走出蛮荒\npriest=牧师\ninquisitor=审判官\neast_cliffs=东部峭壁\nwest_canyon=西部峡谷\nnorth_plains=北部平原\nsouth_hills=南部丘陵\nhorse=马匹\naric_blackwood=阿里克·布莱克伍德\nadmiring_boy=仰慕的男孩\nimpressed_boy=仰慕的男孩\nminers=矿工\nswamp=沼泽\naccessible_swamp=可通行的沼泽\nswamp_garden=沼泽花园\nhot_springs=温泉\nshore=海岸\nfishermans_cabin=渔夫小屋\nlaggon=泻湖\nraft=木筏\ntrade_ship=商船\npirate=海盗\nlush_island=葱郁之岛\nexotic_fruit_trees=异果树\nbordering_lands=边境土地\nexpanding_borders=扩张边界\nwall=城墙\ntown_border=城镇边界\nsea_gate_wall=海门城墙\nstorage=仓库\nroyal_storehouse=皇家仓库\nforced_labour=强迫劳动\nsanctuary=庇护所\nshrine=神龛\ntemple=神庙\ntemple_of_light=光明神庙\ndeep_mine=深矿井\nmine=矿井\nruby_mine=红宝石矿\ndiamond_mine=钻石矿\ndubbing=册封\nrenovation=翻修\nguild=公会\nsmall_guild=小公会\nguild_hall=公会大厅\ngrand_guild_hall=大公会大厅\npublic_punishment=公开惩罚\ntorture_chamber=刑讯室\ntorture_device=刑具\ndungeon=地牢\nprison=监狱\njewellery=珠宝业\njewel_cutting=宝石切割\njewel_polishing=宝石抛光\njewel_extraction=宝石开采\njewel_exhibit=珠宝展览\nbuild_an_ark=建造方舟\nthe_ark=方舟\n___=陌生人\nsir__=骑士\nfavor=恩惠\ndark_prince=黑暗王子\nroyal_consort=王室配偶\nastrologist=占星师\nastronomer=天文学家\nalchemist=炼金术师\nhealing_potion=治疗药剂\nlove_potion=爱情药剂\npotion_of_strength=力量药剂\nspinning_wheel=纺车\nsilk=丝绸\nfashion=时尚\ncloth_export=布匹出口\ncompass=指南针\nastrolabe=星盘\nnavigation=航海术\ncalendar=历法\ntrebuchet=投石机\nengineer=工程师\nsaw_mill=锯木厂\nwood_industry=木材工业\nwood_export=木材出口\nlarge_barn=大粮仓\nlarger_barns=更大的粮仓\nfarming_machines=农业机械\nfishing_ships=捕鱼船队\nfishing_excellence=渔业精进\nfish_quota=捕鱼配额\nmissionary=传教士\nbeekeeper=养蜂人\ncardinal=红衣主教\ncity_on_a_hill=山上之城\nlarge_manor=大庄园\nmanor=庄园\nmansion=豪宅\npalace=宫殿\nfeast=盛宴\nbanquet=宴会\nfestival=庆典\nroyal_visit=王室来访\nroyal_decree=王室敕令\nether_crystal=以太水晶\nschool=学校\nsmall_school=小学堂\nrenowned_school=知名学堂\nprominent_school=名校\nstatue=雕像\nobelisk=方尖碑\nmonument=纪念碑\ngolden_pillar=金色巨柱\nstable=马厩\nlarge_stable=大马厩\ngroom=驯马师\neadric_shadowstrike=埃德里克·影袭\nimpressed_boy=仰慕的男孩\nking_alahar=阿拉哈尔国王\nscientist=科学家\nmerchant=商人\nqueen_jeminah=杰米玛女王\nlord_aethan=伊桑领主\naethan_estate=伊桑庄园\nestate=地产\nvilla=别墅\ngrand_residence=宏伟府邸\ngrand_castle=大城堡\nhuge_castle=巨型城堡\nfortress=要塞\nimpregnable_fortress=坚不可摧的要塞\nornate_temple=华美神庙\nlarge_temple=大神庙\nlegendary_temple=传奇神庙\ntreehouses=树屋\ntown_well=镇井\nswamp_garden=沼泽花园\ncountryside=乡野\nthriving_countryside=繁荣乡野\nmushrooms=蘑菇\nancient_ruins=古代遗迹\nexcavation_site=发掘现场\ntreasure_map=藏宝图\ntreasure_hunt=寻宝\nwatchtower=瞭望塔\ndouble_wall=双重城墙\ninner_wall=内城墙\nmoat=护城河\nmoat_bridge=护城河桥\nboulders=巨石\nterrace_land=梯田\nbarn=谷仓\ncamp=营地\nraid=袭击\nwood_shipment=木材运输\nsurplus=盈余\nhandsome_rival=俊美的情敌\nravine=山谷\nvassal_states=附庸国\nefficient_farming=高效农业\nobsolete_farms=过时农场\nuprising=起义\nunruly_towns=失序城镇\nborder_dispute_expansion=边境争端小扩展\nfunding=资助\nploughs=犁具\noccupation=占领\nresistance=抵抗\nthe_water_mill_expansion=水磨坊小扩展\nattack=进攻\nespionage=谍报\ntrade_route=贸易路线\ncamelot=卡美洛\nfishing_excellence=渔业精进\nlarge_stable=大马厩\nmilitary_domination=军事统治\na_perfect_tower=完美高塔\nmighty_mound=宏伟土丘\nmysterious_cave=神秘洞穴\nemissary=特使\neast_cliffs=东部峭壁\nfar_fields=远郊田地\nwindmill=风车\nobservatory=天文台\nlab=实验室\nlake=湖泊\npirate_cove=海盗湾".split("\n").map((e) => e.split("="))), x = [
	"coin",
	"wood",
	"stone",
	"metal",
	"sword",
	"tradegood"
], S = {
	coin: ["金币", "Coin"],
	wood: ["木材", "Wood"],
	stone: ["石材", "Stone"],
	metal: ["金属", "Metal"],
	sword: ["武力", "Sword"],
	tradegood: ["商品", "Trade good"]
}, C = Object.fromEntries(ie.map((e) => [e.id, e])), oe = {
	coin: 10,
	wood: 10,
	stone: 5,
	metal: 5,
	sword: 5,
	tradegood: 5,
	stay: 2,
	fame2: 5,
	fame5: 5,
	blank: 5,
	chapter: 3,
	knight: 1
};
function w(e, t) {
	return C[e].stages[t];
}
function T(e, t) {
	let n = w(e, t);
	return [ae[n.key] ?? n.name, n.name];
}
function se(e) {
	return [0, 1].map((t) => e.replace(/effects\/arrow/g, t === 0 ? "转向" : "Turn").replace(/\bfame\b/g, t === 0 ? "声望" : "Fame").replace(/\b(coin|wood|stone|metal|sword|tradegood)\b/g, (e) => S[e][t]).replace(/ x(\d+)/g, " ×$1"));
}
function ce(e) {
	return Object.fromEntries(x.flatMap((t) => {
		let n = [...e.matchAll(RegExp(`\\b${t}(?: x(\\d+))?`, "g"))];
		return n.length ? [[t, n.reduce((e, t) => e + Number(t[1] ?? 1), 0)]] : [];
	}));
}
function E(e) {
	return x.reduce((t, n) => t + (e[n] ?? 0), 0);
}
function le(e) {
	return [x.filter((t) => e[t]).map((t) => `${e[t]} ${S[t][0]}`).join("、"), x.filter((t) => e[t]).map((t) => `${e[t]} ${S[t][1]}`).join(", ")];
}
function ue(e, t) {
	return Object.fromEntries(x.map((n) => [n, (e[n] ?? 0) + (t[n] ?? 0)]).filter(([, e]) => Number(e) !== 0));
}
var de = {
	25: [
		1,
		4,
		7,
		10,
		14,
		19,
		25,
		32,
		40
	],
	26: [
		1,
		2,
		3,
		5,
		7,
		10,
		14,
		19,
		25,
		32,
		40
	],
	87: [
		1,
		3,
		6,
		10,
		14,
		20,
		27,
		35,
		45
	],
	88: [
		3,
		6,
		10,
		15,
		22,
		30,
		38,
		48,
		60,
		75
	],
	90: [
		1,
		2,
		3,
		5,
		7,
		10,
		14,
		20,
		28,
		40
	]
}, fe = e.object({
	coin: e.int().min(-100).max(1e4).optional(),
	wood: e.int().min(-100).max(1e4).optional(),
	stone: e.int().min(-100).max(1e4).optional(),
	metal: e.int().min(-100).max(1e4).optional(),
	sword: e.int().min(-100).max(1e4).optional(),
	tradegood: e.int().min(-100).max(1e4).optional()
}), D = e.tuple([e.string(), e.string()]), pe = e.enum([
	"box",
	"deck",
	"play",
	"discard",
	"permanent",
	"destroyed",
	"blocked"
]), me = e.object({
	added: fe,
	removed: fe,
	stickers: e.array(e.string()).max(60),
	boxes: e.array(e.int().min(0).max(100)).max(100),
	medals: e.array(e.int().min(0).max(1e4)).max(12),
	discount: fe,
	used: e.array(e.string()).max(30)
}), he = e.object({
	id: e.int().min(1).max(138),
	stage: e.int().min(1).max(4),
	zone: pe,
	changes: e.record(e.string(), me),
	blockedBy: e.int().optional(),
	played: e.int().nonnegative(),
	name: e.string().max(40)
}), O = e.lazy(() => e.object({
	op: e.string().max(40),
	id: e.int().optional(),
	stage: e.int().optional(),
	n: e.number().optional(),
	key: e.string().optional(),
	ids: e.array(e.int()).max(140).optional(),
	res: fe.optional(),
	pool: e.array(e.string()).max(20).optional(),
	filter: e.string().optional(),
	zone: e.string().optional(),
	mode: e.string().optional(),
	then: e.array(O).max(150).optional(),
	title: D.optional(),
	optional: e.boolean().optional(),
	selected: e.array(e.int()).max(140).optional()
})), ge = e.object({
	version: e.literal(1),
	campaignId: e.string().max(100),
	serial: e.int().nonnegative(),
	owner: e.string(),
	seed: e.number(),
	cursor: e.int().nonnegative(),
	cards: e.array(he).length(138),
	deck: e.array(e.int().min(1).max(138)).max(138),
	discard: e.array(e.int().min(1).max(138)).max(138),
	resources: fe,
	stickers: e.record(e.string(), e.int().nonnegative()),
	round: e.int().min(1),
	turn: e.int().min(1),
	phase: e.enum([
		"play",
		"resolving",
		"chapterEnd",
		"done"
	]),
	queue: e.array(O).max(600),
	prompt: O.nullable(),
	beatMs: e.int().nonnegative(),
	finalRound: e.boolean(),
	chapter: e.int().min(0).max(138),
	finished: e.array(e.int()).max(4),
	scores: e.array(e.object({
		chapter: e.int(),
		score: e.int()
	})).max(4),
	purgedFame: e.int(),
	purging: e.array(e.int()).max(138),
	retained: e.array(e.int()).max(138),
	turnUsed: e.array(e.string()).max(100),
	log: e.array(D).max(60)
});
function k() {
	return {
		added: {},
		removed: {},
		stickers: [],
		boxes: [],
		medals: [],
		discount: {},
		used: []
	};
}
function A(e, t = e.stage) {
	return e.changes[t] ?? k();
}
function j(e, t = e.stage) {
	return e.changes[t] ?? (e.changes[t] = k());
}
//#endregion
//#region src/games/kingdomlegacy/state.ts
function M(e, t) {
	return e.cards[t - 1];
}
function N(e) {
	return w(e.id, e.stage);
}
function P(e, t) {
	return N(e).types.includes(t) || t === "knight" && A(e).stickers.includes("knight") || t === "wall" && /wall/.test(N(e).key);
}
function _e(e) {
	return !N(e).negative;
}
function F(e) {
	return P(e, "permanent");
}
function I(e) {
	return e.cards.filter((e) => e.zone === "play");
}
function ve(e) {
	return e.cards.filter((e) => e.zone === "play" || e.zone === "permanent");
}
function ye(e) {
	return e.cards.filter((e) => [
		"play",
		"discard",
		"deck",
		"permanent"
	].includes(e.zone));
}
function L(e) {
	return e.name ? [e.name, e.name] : T(e.id, e.stage);
}
function be(e, t) {
	return ![
		"box",
		"destroyed",
		"blocked"
	].includes(M(e, t).zone);
}
function R(e, t, n) {
	let r = M(e, t);
	return ["play", "permanent"].includes(r.zone) && (n === void 0 || r.stage === n);
}
function z(e) {
	return e.reduce((e, t) => e + (P(t, "person") ? t.id === 73 && t.stage === 2 ? 2 : 1 : 0), 0);
}
function B(e, t = 0) {
	let n = N(e), r = A(e);
	return ue(ue(n.production[t] ?? {}, r.added), Object.fromEntries(x.map((e) => [e, -(r.removed[e] ?? 0)])));
}
function xe(e, t, n = 0) {
	let r = B(t, n), i = {};
	return P(t, "person") && R(e, 32, 1) && (i.coin = (i.coin ?? 0) + 1), P(t, "land") && R(e, 44, 4) && (i.coin = (i.coin ?? 0) + 2), P(t, "building") && R(e, 89, 2) && (i.coin = (i.coin ?? 0) + 1), P(t, "seafaring") && R(e, 102, 3) && (i.coin = (i.coin ?? 0) + 1), t.id === 17 && t.stage === 4 && (i.coin = (i.coin ?? 0) + z(I(e))), R(e, 136, 1) && _e(t) && (i.coin = (i.coin ?? 0) + 1), r = ue(r, i), Object.fromEntries(x.map((e) => [e, Math.max(0, r[e] ?? 0)]).filter(([, e]) => Number(e) > 0));
}
function Se(e, t) {
	return Math.max(...N(t).production.map((e, n) => E(B(t, n))));
}
function V(e, t = "any", n = "play", r) {
	return (n === "kingdom" ? ye(e) : n === "visible" ? e.cards.filter((e) => [
		"play",
		"discard",
		"permanent"
	].includes(e.zone)) : n === "playOrDiscard" ? e.cards.filter((e) => ["play", "discard"].includes(e.zone)) : e.cards.filter((e) => e.zone === n)).filter((n) => n.id !== r && t.split("|").some((t) => t === "any" ? !0 : t === "friendly" ? _e(n) : t === "negative" ? !_e(n) : t === "friendlyNonPermanent" ? _e(n) && !F(n) : t === "coinProduction" ? (B(n).coin ?? 0) > 0 : t === "production" ? Se(e, n) > 0 : t === "buildingProduction" ? P(n, "building") && Se(e, n) > 0 : t === "horseTrainable" ? P(n, "horse") && Se(e, n) <= 3 : t === "personFame5" ? P(n, "person") && Ie(e, n) >= 5 : t.startsWith("key:") ? N(n).key === t.slice(4) : t.startsWith("id:") ? n.id === Number(t.slice(3)) : t === "destroyable" ? Ce(e, n) : P(n, t)));
}
function Ce(e, t) {
	return t.id !== 108 && (t.id !== 134 || t.stage !== 1 || M(e, 55).zone === "destroyed");
}
function we(e) {
	return e.deck.length > 0 && !R(e, 44, 4) && !R(e, 45, 1) && !R(e, 61, 1);
}
function Te(e) {
	return !R(e, 45, 1) && !R(e, 61, 1);
}
function Ee(e, t) {
	e.deck = e.deck.filter((e) => e !== t), e.discard = e.discard.filter((e) => e !== t);
}
function H(e, t, n, r = !1) {
	let i = M(e, t);
	if (i.zone === "destroyed" && n !== "box" || n === "discard" && F(i)) return;
	Ee(e, t), i.zone = n, delete i.blockedBy, n === "discard" && e.discard.push(t), n === "deck" && e.deck.push(t);
	let a = e.cards.filter((e) => e.zone === "blocked" && e.blockedBy === t);
	for (let t of a) delete t.blockedBy, t.zone = r ? "discard" : "play", r && e.discard.push(t.id);
}
function De(e, t, n) {
	let r = M(e, t);
	C[t].stages[n] && (r.stage = n, H(e, t, F(r) ? "permanent" : "discard"));
}
function Oe(e, t) {
	let n = { ...t };
	R(e, 76, 1) && (n.coin ?? 0) > 0 && (n.coin = Math.max(0, (n.coin ?? 0) - 1)), e.resources = ue(e.resources, n);
}
function ke(e, t) {
	return x.every((n) => (e.resources[n] ?? 0) >= (t[n] ?? 0)) ? (e.resources = ue(e.resources, Object.fromEntries(x.map((e) => [e, -(t[e] ?? 0)]))), !0) : !1;
}
function Ae(e, t) {
	return x.every((n) => (e.resources[n] ?? 0) >= (t[n] ?? 0));
}
function je(e, t) {
	let n = A(e).discount;
	return Object.fromEntries(x.map((e) => [e, Math.max(0, (t[e] ?? 0) - (n[e] ?? 0))]).filter(([, e]) => Number(e) > 0));
}
function Me(e, t, n, r, i) {
	let a = M(e, t), o = r ?? a.stage;
	if (!(e.stickers[n] > 0)) return !1;
	if (x.includes(n)) {
		let t = a.stage;
		a.stage = o;
		let n = Se(e, a) >= 9;
		if (a.stage = t, n) return !1;
	}
	let s = j(a, o);
	if (s.stickers.push(n), --e.stickers[n], x.includes(n)) {
		let e = n;
		s.added[e] = (s.added[e] ?? 0) + 1;
	}
	return n === "blank" && s.medals.push(i ?? 0), !0;
}
function U(e, t = e.stage) {
	return A(e, t).boxes.length;
}
function Ne(e, t, n, r) {
	let i = M(e, t), a = j(i, r ?? i.stage), o = w(t, r ?? i.stage);
	n < 0 || n >= o.boxes.length || a.boxes.includes(n) || (a.boxes.push(n), t !== 134 && Oe(e, ce(o.boxes[n].text)));
}
function Pe(e, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = t(e.seed, e.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Fe(e, t) {
	e.log = [...e.log.slice(-59), t];
}
function W(e, ...t) {
	e.queue.unshift(...t), e.phase = "resolving";
}
function Ie(e, t, n = !1, r = !1, i = 0) {
	let a = N(t), o = A(t), s = a.fame + o.medals.reduce((e, t) => e + t, 0) + o.stickers.filter((e) => e === "fame2").length * 2 + o.stickers.filter((e) => e === "fame5").length * 5, c = U(t);
	[25, 26].includes(t.id) && (s += t.stage === 1 ? de[t.id][c - 1] ?? 0 : c * 10), [
		87,
		88,
		90
	].includes(t.id) && (s += de[t.id][c - 1] ?? 0), t.id === 34 && (s += U(t, 1) * 5), t.id === 89 && t.stage === 3 && (s += c * 2), t.id === 91 && t.stage === 4 && (s += c), t.id === 95 && t.stage === 1 && (s += c * 2), t.id === 106 && t.stage === 4 && (s += c * 5), t.id === 109 && t.stage === 4 && (s += o.medals.reduce((e, t) => e + t, 0) * 0), t.id === 121 && t.stage === 4 && (s += c * 3), t.id === 125 && t.stage === 4 && r && (s += c * 10), t.id === 128 && t.stage === 4 && (s += c * 7), t.id === 134 && t.stage === 1 && (s -= 5 * (4 - c)), t.id === 135 && (s += A(t, 4).medals.reduce((e, t) => e + t, 0) - (t.stage === 4 ? o.medals.reduce((e, t) => e + t, 0) : 0));
	let l = n ? ye(e) : e.cards.filter((e) => [
		"play",
		"discard",
		"permanent"
	].includes(e.zone));
	return t.id === 130 && t.stage === 3 && (s += l.filter((e) => P(e, "wall")).length * 4), t.id === 38 && (s += t.stage === 1 ? z(l) * 2 : l.reduce((e, t) => e + Math.max(...N(t).production.map((e, n) => B(t, n).sword ?? 0)), 0) * 2), t.id === 39 && (t.stage === 1 ? s -= Math.max(0, 75 - l.filter((e) => !F(e)).length) * 2 : i === 0 && (s -= l.filter((t) => !F(t) && Ie(e, t, n, !1, 1) === 0).length)), t.id === 40 && (t.stage === 1 && !l.some((e) => P(e, "enemy")) && (s += 25), t.stage === 4 && l.reduce((e, t) => e + Math.max(...N(t).production.map((e, n) => B(t, n).tradegood ?? 0)), 0) >= 10 && (s += 25)), s;
}
function Le(e) {
	return e.purgedFame + ye(e).reduce((t, n) => t + Ie(e, n, !0), 0);
}
function Re(e, t) {
	return {
		version: 1,
		campaignId: `kingdom-${t}`,
		serial: 0,
		owner: e,
		seed: t,
		cursor: 0,
		cards: Array.from({ length: 138 }, (e, t) => ({
			id: t + 1,
			stage: 1,
			zone: t < 10 ? "discard" : "box",
			changes: {},
			played: 0,
			name: ""
		})),
		deck: [],
		discard: Array.from({ length: 10 }, (e, t) => t + 1),
		resources: {},
		stickers: { ...oe },
		round: 1,
		turn: 1,
		phase: "resolving",
		queue: [{ op: "shuffleRound" }, {
			op: "draw",
			n: 4
		}],
		prompt: null,
		beatMs: 450,
		finalRound: !1,
		chapter: 0,
		finished: [],
		scores: [],
		purgedFame: 0,
		purging: [],
		retained: [],
		turnUsed: [],
		log: []
	};
}
//#endregion
//#region src/games/kingdomlegacy/abilities.ts
var G = (e, t, n) => ({
	op: e,
	...t === void 0 ? {} : { id: t },
	...n === void 0 ? {} : { n }
}), K = (e, t = 1, n = "discard", r = [], i = "play", a, o = !1) => ({
	op: "select",
	filter: e,
	n: t,
	mode: n,
	then: r,
	zone: i,
	id: a,
	optional: o
}), q = (e = 1, t = x) => ({
	op: "resource",
	n: e,
	pool: [...t]
}), J = (e = "friendly", t = x, n = "play", r) => ({
	...K(e, 1, "bind", [{
		op: "sticker",
		id: -1,
		pool: [...t]
	}], n, r),
	title: ["选择添加贴纸的牌", "Choose a card for the sticker"]
}), Y = (e, t = 1, n = !1) => ({
	op: "discoverChoice",
	ids: e,
	n: t,
	mode: n ? "destroyRest" : "normal"
}), ze = (e, t) => K(e, 1, "bind", [G("copyProduction", -1)], "play", t), Be = (e, t = "activate") => ({
	op: t === "destroy" ? "destroy" : t === "passive" ? "noop" : "discard",
	id: e
});
function X(e, t, n = 1, r, i = "play") {
	let a = V(e, t, i, r);
	return t === "person" ? z(a) >= n : a.length >= n;
}
function Ve(e, t) {
	return t.some((t) => M(e, t).zone === "box");
}
function He(e, t) {
	return t.map(([t, n]) => K(t === "stone_bridge" ? "key:stone_bridge" : t, n, t === "stone_bridge" ? "destroy" : "discard", [], "play", e));
}
function Ue(e, t, n = !1, r = !0, i) {
	return Te(e) ? N(t).upgrades.flatMap((a, o) => {
		let s = je(t, a.cost);
		if (!n && (!Ae(e, s) || a.extra.some(([n, r]) => !X(e, n === "stone_bridge" ? "key:stone_bridge" : n, r, t.id)))) return [];
		let c = [];
		i && c.push(Be(i)), n || c.push({
			op: "spend",
			res: s
		}, ...He(t.id, a.extra)), c.push({
			op: "upgrade",
			id: t.id,
			stage: a.to
		}, ...r ? [G("endTurn")] : []);
		let l = le(s);
		return [{
			key: `upgrade:${t.id}:${o}:${i ?? 0}`,
			card: t.id,
			kind: "upgrade",
			label: [`升级为 ${T(t.id, a.to)[0]}${n ? "" : `（${l[0] || "无资源费用"}）`}`, `Upgrade to ${C[t.id].stages[a.to].name}${n ? "" : ` (${l[1] || "no resource cost"})`}`],
			steps: c
		}];
	}) : [];
}
function We(e, t) {
	let n = t.id, r = t.stage, i = N(t).key, a = [];
	function o(t, r, i, o = {}, s = "activate", c = !0) {
		if (!c || !Ae(e, o) || s === "time" && !Te(e)) return;
		let l = le(o), u = E(o) ? [`${r[0]}（支付 ${l[0]}）`, `${r[1]} (pay ${l[1]})`] : r;
		a.push({
			key: `effect:${n}:${t}`,
			card: n,
			label: u,
			danger: s === "destroy",
			kind: "effect",
			steps: [
				{
					op: "spend",
					res: o
				},
				Be(n, s),
				...i,
				...s === "time" ? [G("timeWindow")] : []
			]
		});
	}
	let s = (t, n = {}, r = "activate", i = []) => o(`discover${t}`, ["发现新卡牌", "Discover a card"], [...i, Y(t)], n, r, Ve(e, t)), c = (e, t = {}, n = "activate", r = []) => o(`resource${e}`, ["获得自选资源", "Gain resources of your choice"], [...r, q(e)], t, n), l = (t, n = {}) => o("recall", ["从弃牌堆打出卡牌", "Play a card from the discard"], [K(t, 1, "play", [], "discard")], n, "activate", X(e, t, 1, void 0, "discard"));
	if (i === "plains" && o("plains", ["弃置友好牌，获得 2 金币", "Discard a friendly card; gain 2 coins"], [K("friendly", 1, "discard", [], "play", n), {
		op: "gain",
		res: { coin: 2 }
	}], {}, "activate", X(e, "friendly", 1, n)), i === "rocky_area" && o("stone", ["获得 2 石材", "Gain 2 stone"], [{
		op: "gain",
		res: { stone: 2 }
	}], { coin: 1 }), (i === "shallow_mines" || i === "shallow_mine") && s([84, 85], {}, "destroy"), i === "forest" && o("fell", ["砍伐：获得 3 木材并转向", "Fell: gain 3 wood and turn"], [{
		op: "gain",
		res: { wood: 3 }
	}, G("turn", n, 2)]), i === "sacred_well" && s([82, 83], {}, "destroy"), [
		"town_hall",
		"keep",
		"castle",
		"grand_castle",
		"huge_castle",
		"monumental_castle",
		"fortress",
		"impregnable_fortress"
	].includes(i) && l(i === "town_hall" ? "land" : i === "keep" ? "land|building" : "any"), [
		"trader",
		"bazaar",
		"market"
	].includes(i) && [10, 119].includes(n) && o("trade", ["交易", "Trade"], [q(1, i === "trader" ? ["wood"] : i === "bazaar" ? ["wood", "stone"] : [
		"wood",
		"stone",
		"metal"
	])], { coin: 1 }), (i === "jungle" || i === "huge_trees") && o("wood", ["获得木材", "Gain wood"], [{
		op: "gain",
		res: { wood: i === "jungle" ? 1 : 2 }
	}], { coin: 1 }), i === "explorers" && s([
		71,
		72,
		73,
		74
	], {}, "activate", [G("turn", n, 3)]), i === "field_worker" && o("land", ["获得一张土地的产出", "Gain a land card’s production"], [ze("land", n)], {}, "activate", X(e, "land", 1, n)), i === "worker" && o("building", ["获得一张建筑的产出", "Gain a building’s production"], [ze("building", n)], {}, "activate", X(e, "building", 1, n)), i === "servant" && o("servant", ["获得自选资源", "Gain a resource"], [q(1, [
		"coin",
		"wood",
		"stone"
	])]), [
		14,
		16,
		60,
		64
	].includes(n) && r === 1 && o("defeat", ["击败强盗", "Defeat the bandit"], [q(n < 20 ? 2 : 3)], { sword: n < 20 ? 1 : 3 }, "destroy"), i === "chapel" && s([103], { coin: 3 }), i === "church" && s([104], { coin: 4 }), i === "smithy" && s([90], {}, "activate", [G("turn", n, 1)]), i === "arsenal" && o("army", ["每位场上人物提供 1 武力", "Gain 1 sword per person in play"], [{
		op: "gain",
		res: { sword: z(I(e)) }
	}]), i === "lighthouse" && o("discardTop", ["弃置牌库顶牌", "Discard the top card"], [G("discardTop", void 0, 1)], {}, "passive", e.deck.length > 0), i === "fishing_boat" && s([75]), [
		25,
		26,
		87,
		88,
		90,
		91
	].includes(n) && (n !== 91 || r === 1)) {
		let r = U(t), i = N(t).boxes[r];
		if (i) {
			let t = n === 25 ? { sword: i.cost } : n === 26 ? { coin: i.cost } : n === 88 ? { stone: i.cost } : n === 90 ? { metal: i.cost } : n === 91 ? { wood: i.cost } : {};
			o("track", ["推进轨道", "Advance the track"], [...n === 87 ? [K("person", i.cost, "discard", [], "play", n)] : [], {
				op: "track",
				id: n,
				n: r
			}], t, "time", n !== 87 || X(e, "person", i.cost, n));
		}
	}
	if (n === 27 && o("export", ["出口 1 商品", "Export 1 trade good"], [{
		op: "tally",
		id: n,
		n: 1
	}], { tradegood: 1 }, "passive"), i === "young_forest" && o("grow", ["培育幼林", "Grow the young forest"], [{
		op: "track",
		id: n,
		n: U(t)
	}], {}, "time", U(t) < 5), i === "pretend_noble" && o("resetSticker", ["重置并改良一个未贴贴纸的阶段", "Reset and improve an unmodified stage"], [G("turn", n, 1), {
		op: "stageSticker",
		id: n
	}], {}, "activate", Object.keys(C[n].stages).some((e) => !A(t, Number(e)).stickers.length)), i === "entrepreneur" && s([118], {}, "time"), i === "hotel" && o("hotel", ["每位场上人物提供 1 金币", "Gain 1 coin per person in play"], [{
		op: "gain",
		res: { coin: z(I(e)) }
	}]), i === "tavern" && s([87]), i === "cozy_pub" && o("stranger", ["弃置人物，发现陌生人", "Discard a person; discover the stranger"], [K("person", 1, "discard", [], "play", n), Y([92])], {}, "activate", X(e, "person", 1, n) && Ve(e, [92])), i === "observatory" && s([95], {}, "time"), i === "lab" && s([96], {}, "time"), i === "engineer" || i === "royal_architect") {
		let t = i === "engineer" ? [
			["lumberjack", 100],
			["food_barns", 101],
			["fishing_boat", 102]
		] : [
			["castle", 123],
			["diamond_mine", 124],
			["temple", 125]
		];
		for (let [r, i] of t) o(`replace${r}`, [`拆除 ${ae[r]} 并发现新牌`, `Destroy ${r.replaceAll("_", " ")} and discover a card`], [K(`key:${r}`, 1, "destroy", [], "play", n), Y([i])], {}, "activate", X(e, `key:${r}`, 1, n) && Ve(e, [i]));
	}
	if (i === "trebuchet" && o("siege", ["击败敌人，推进军队", "Defeat an enemy and advance the Army"], [K("enemy", 1, "defeat", [], "visible"), {
		op: "track",
		id: 25,
		n: U(M(e, 25))
	}], {}, "destroy", X(e, "enemy", 1, void 0, "visible")), i === "inspired_inventor" && (s([
		97,
		98,
		99
	], {}, "activate", [G("turn", n, 1), {
		op: "markFirst",
		id: n,
		stage: 1
	}]), c(Math.min(3, U(t, 1) + 1), {}, "activate", [G("turn", n, 1), {
		op: "markFirst",
		id: n,
		stage: 1
	}])), i === "mercenary" && o("mercenary", ["勾选 1–2 个资源格", "Mark 1–2 resource boxes"], [{
		op: "markChoice",
		id: n,
		n: 2,
		optional: !0
	}], { coin: 2 }, "activate", U(t) < 8), n === 36 && r === 4) for (let e of [3, 4]) o(`train${e}`, ["增加武力生产（一次）", "Add sword production (once)"], [{
		op: "once",
		id: n,
		key: `train${e}`
	}, {
		op: "sticker",
		id: n,
		pool: ["sword"]
	}], { metal: e }, "time", !A(t).used.includes(`train${e}`));
	if (n === 41 && (r === 1 && o("discardTop", ["弃置牌库顶牌", "Discard the top card"], [G("discardTop", void 0, 1)], {}, "activate", e.deck.length > 0), o("mark", ["勾选资源格", "Mark resource boxes"], [{
		op: "markChoice",
		id: n,
		n: r === 1 ? 1 : 2,
		optional: r === 4
	}], {}, "activate", U(t) < N(t).boxes.length)), i === "mason" && s([88, 89], { coin: 2 }), i === "brick_road" && o("project", ["查看并选取建造项目", "Inspect and choose a building project"], [Y([109, 110], 1, !0)], {}, "time", Ve(e, [109, 110])), i === "stone_street" && o("project", ["查看并选取建造项目", "Inspect and choose a building project"], [Y([111, 112], 1, !0)], {}, "time", Ve(e, [111, 112])), [45, 61].includes(n) && (r === 1 && o("defeat", ["击败敌人", "Defeat the enemy"], [G("turn", n, 4)], { sword: n === 45 ? 3 : 5 }), (r === 4 || r === 3) && o("sacrifice", ["摧毁并获得武力", "Destroy to gain swords"], [{
		op: "gain",
		res: { sword: r === 4 ? 2 : 3 }
	}], {}, "destroy")), i === "training_grounds" && o("train", ["获得 1 武力", "Gain 1 sword"], [{
		op: "gain",
		res: { sword: 1 }
	}], { coin: 1 }), n === 48 && s([
		[119],
		[120],
		[121],
		[122]
	][r - 1], { coin: 3 }, "time"), n === 50 && (s([
		[126],
		[127],
		[128],
		[129]
	][r - 1], {}, "time"), r === 4 && o("land", ["弃置土地，获得资源", "Discard a land; gain resources"], [K("land", 1, "discard", [], "play", n), q(2)], {}, "activate", X(e, "land", 1, n))), n === 51 && r < 4 && s([
		[130],
		[131],
		[132]
	][r - 1], {}, "time"), i === "strategist" && l("wall|knight"), (i === "summit_village" || i === "peak_village") && s([105], {}, "activate", [G("turn", n, 1)]), n === 53 && (o("defeat", ["击败女巫", "Defeat the witch"], [], { sword: r === 1 ? 4 : 3 }, "destroy"), o("sacrifice", ["献出人物，解除威胁", "Sacrifice people to remove the threat"], [K("person", r === 1 ? 3 : 1, r === 1 ? "discard" : "destroy", [], "play", n), ...r === 1 ? [G("turn", n, 4)] : [G("destroy", n)]], {}, "activate", X(e, "person", r === 1 ? 3 : 1, n))), i === "architect" && s([78, 79], {}, "time", [G("turn", n, 1)]), n === 55 && (r === 1 ? (s([80]), s([81])) : o("raid", ["发现袭击与对手", "Discover a raid and rival"], [Y([133]), Y([134])], {}, "time", Ve(e, [133, 134])), o("mark", ["勾选资源格", "Mark a resource box"], [{
		op: "markChoice",
		id: n,
		n: 1
	}], {}, r === 1 ? "passive" : "activate", U(t) < N(t).boxes.length)), [56, 57].includes(n) && r === 4 && o("defeat", ["击败敌兵", "Defeat the enemy soldier"], [], { sword: 2 }, "destroy"), n === 57 && r === 1 && o("defeat", ["击败刺客", "Defeat the assassin"], [G("turn", n, 4)], { sword: 3 }), i === "lost_civilization" && o("artifact", ["弃置 6 张友好牌，发现遗物", "Discard 6 friendly cards; discover an artifact"], [K("friendly", 6, "discard", [], "play", n), Y([108])], {}, "activate", X(e, "friendly", 6, n) && Ve(e, [108])), (i === "innkeeper" || i === "eadric_shadowstrike") && o("person", ["弃置另一人物，获得资源", "Discard another person; gain resources"], [K("person", 1, "discard", [], "play", n), ...n === 116 ? [{
		op: "gain",
		res: { sword: 3 }
	}] : [q(2)]], {}, "activate", X(e, "person", 1, n)), [66, 67].includes(n) && r === 4 && c(1), n === 69 && r === 1 && o("finish", ["强化一张友好牌", "Improve a friendly card"], [K("friendly", 1, "bind", [{
		op: "sticker",
		id: -1,
		pool: ["tradegood"]
	}, {
		op: "sticker",
		id: -1,
		pool: ["fame5"]
	}], "play", n)], {}, "destroy", X(e, "friendly", 1, n)), n === 69 && r === 4 && c(4, {}, "destroy"), [70, 107].includes(n) && (r === 1 ? o("discount", ["降低一项升级资源费用", "Reduce an upgrade resource cost"], [K("any", 1, "bind", [G("discountChoice", -1)], "play", n)], {}, "activate", I(e).some((e) => e.id !== n && N(e).upgrades.length > 0)) : o("inquisitor", ["摧毁一张负面牌", "Destroy a negative card"], [K("negative", 1, "destroy", [], "play", n)], {}, "destroy", X(e, "negative", 1, n))), n === 76 && (r === 1 ? o("defeat", ["击败海盗，发现泻湖", "Defeat the pirate; discover the lagoon"], [Y([77])], { sword: 2 }, "destroy") : s([93])), i === "sea_gate_wall" && l("seafaring"), n === 94 && r === 1 && o("defeat", ["击败背叛者", "Defeat the Backstabber"], [], { sword: 4 }, "destroy"), n === 80 && (r === 1 ? o("cooperate", ["弃置 2 人物，获得 3 资源", "Discard 2 people; gain 3 resources"], [
		K("person", 2, "discard", [], "play", n),
		q(3),
		G("turn", n, 4)
	], {}, "activate", X(e, "person", 2, n)) : c(1, {}, "activate", [G("turn", n, 1)])), n === 89 && r === 3 && o("prison", ["囚禁敌人并勾格", "Imprison an enemy and mark a box"], [K("enemy", 1, "discard"), {
		op: "markChoice",
		id: n,
		n: 1
	}], {}, "activate", X(e, "enemy") && U(t) < 8), n === 89 && r === 4 && o("settlement", ["勾选进度格", "Mark a progress box"], [{
		op: "markFirst",
		id: n
	}, {
		op: "turnIfFull",
		id: n,
		n: 3
	}], {}, "activate", U(t) < 3), n === 91 && r === 4 && o("ark", ["每 2 位人物勾选 1 格", "Mark 1 box per 2 people"], [{
		op: "markMany",
		id: n,
		n: Math.floor(z(I(e)) / 2)
	}], {}, "activate", U(t) < 16 && z(I(e)) >= 2), n === 95 && (r === 1 ? o("astronomy", ["勾选 1 声望格", "Mark a fame box"], [{
		op: "markFirst",
		id: n
	}], { coin: 2 }, "activate", U(t) < 16) : o("arrange", ["将至多 3 张其他牌放到牌库顶或底", "Move up to 3 other cards to the top or bottom of the deck"], [K("any", 3, "topOrBottom", [], "play", n, !0)], {}, "activate", e.deck.length > 0 && X(e, "any", 1, n))), n === 96) {
		if (r === 1) for (let e of [
			2,
			3,
			4
		]) o(`potion${e}`, ["调配药剂", "Prepare a potion"], [G("turn", n, e)], { coin: 2 });
		(r === 2 || r === 4) && o("drink", ["重置并获得资源", "Reset and gain resources"], [G("turn", n, 1), {
			op: "gain",
			res: r === 2 ? { sword: 3 } : { tradegood: 5 }
		}]);
	}
	if (n === 98 && (r < 4 ? o("navigation", ["推进航海研究", "Advance navigation research"], [{
		op: "markMany",
		id: n,
		n: I(e).filter((e) => P(e, "seafaring")).length
	}, {
		op: "turnIfFull",
		id: n,
		n: r + 1
	}], {}, "activate") : o("calendar", ["勾格，将弃牌补入牌库底", "Mark a box; add discard cards to the bottom of the deck"], [{
		op: "markFirst",
		id: n
	}, G("calendar")], {}, "activate", U(t) < 4 && e.deck.length > 0)), n === 100 && r === 2 && s([91]), n === 100 && r === 3) for (let [e, t] of [["wood", "tradegood"], ["tradegood", "wood"]]) o(`exchange${e}`, ["转换木材与商品", "Exchange wood and trade goods"], [{
		op: "gain",
		res: { [t]: 1 }
	}], { [e]: 1 }, "passive");
	if (n === 102 && r === 4 && o("quota", ["勾选配额格", "Mark a quota box"], [{
		op: "markFirst",
		id: n
	}, {
		op: "turnIfFull",
		id: n,
		n: 3
	}], {}, "activate", U(t) < 4), n === 103 && (r === 1 ? o("convert", ["感化强盗", "Convert a bandit"], [K("key:bandit|key:skilled_bandit", 1, "bind", [G("turn", -1, 4)], "play", n)], { coin: 3 }, "activate", I(e).some((e) => [
		14,
		16,
		60,
		64
	].includes(e.id) && e.stage === 1)) : o("honey", ["勾格，完成后增加金币生产", "Mark a box; add coin production when complete"], [{
		op: "markFirst",
		id: n
	}, {
		op: "beeComplete",
		id: n
	}], {}, "activate", U(t) < 4)), n === 104 && Ae(e, r === 1 ? { coin: 2 } : {})) for (let t of I(e).filter((e) => e.id !== n)) for (let i of Ue(e, t, !1, !1)) {
		let t = r === 1 ? { coin: 2 } : {};
		Ae(e, ue(i.steps.find((e) => e.op === "spend")?.res ?? {}, t)) && a.push({
			...i,
			key: `priest:${n}:${i.key}`,
			label: [`${i.label[0]}${r === 1 ? "，另付 2 金币" : ""}；继续回合`, `${i.label[1]}${r === 1 ? ", plus 2 coins" : ""}; continue the turn`],
			steps: [
				{
					op: "spend",
					res: r === 1 ? { coin: 2 } : {}
				},
				Be(n),
				...i.steps
			]
		});
	}
	if (n === 105) {
		if (r < 3 && c(1, { coin: r === 1 ? 2 : 1 }), r === 3) for (let e of x) o(`trade${e}`, ["交换 1 资源", "Exchange 1 resource"], [q()], { [e]: 1 });
		r === 4 && (s([106], {}, "activate", [G("undiscover", n)]), c(1));
	}
	if (n === 109 && r === 4 && o("guild", ["弃置任意数量人物，记入声望", "Discard any number of people and record their fame"], [{
		op: "guild",
		id: n,
		selected: []
	}], {}, "activate", A(t).medals.length < 3), n === 110 && r >= 3 && o("bottom", ["将卡牌放到牌库底", "Move a card to the bottom of the deck"], [K("any", 1, "bottom", [], r === 3 ? "play" : "playOrDiscard")], {}, "activate", e.deck.length > 0 && X(e, "any", 1, n, r === 3 ? "play" : "playOrDiscard")), n === 111 && r === 4 && s([116], {}, "time"), n === 112 && (r < 4 ? s([112 + r], { coin: 2 }, "time") : o("groom", ["训练场上马匹", "Train a horse in play"], [J("horseTrainable")], { coin: 2 }, "activate", X(e, "horseTrainable"))), n === 117 && c(1, { tradegood: 3 }, "passive"), n === 118) {
		if (r <= 2 && Te(e)) for (let t of I(e).filter((e) => P(e, "person"))) for (let i of Ue(e, t, !0, !1)) a.push({
			...i,
			key: `school:${n}:${i.key}`,
			label: ["免费升级人物", "Upgrade a person for free"],
			steps: [
				Be(n),
				...i.steps,
				G("turn", n, r + 1),
				G("endTurn")
			]
		});
		else r > 2 && o("teach", ["增加人物生产", "Improve a person’s production"], [J("person"), ...r === 3 ? [G("turn", n, 4)] : [{
			op: "once",
			id: n,
			key: "teach"
		}]], {}, "time", X(e, "person", 1, n) && !A(t).used.includes("teach"));
	}
	return n === 120 && c(r === 4 ? 1 : 3, {}, "activate", r < 4 ? [G("turn", n, r + 1)] : []), n === 121 && r === 4 && o("queen", ["弃置高声望人物，勾选 1 格", "Discard a person with at least 5 fame; mark a box"], [K("personFame5", 1, "discard", [], "play", n), {
		op: "markFirst",
		id: n
	}], {}, "activate", X(e, "personFame5", 1, n) && U(t) < 7), n === 125 && r === 4 && o("temple", ["为净化积累声望", "Prepare fame for the purge"], [{
		op: "markFirst",
		id: n
	}], { tradegood: 4 }, "time", U(t) < 4), n === 127 && r === 3 && o("mushroom", ["弃置人物，获得 2 商品", "Discard a person; gain 2 trade goods"], [K("person", 1, "discard", [], "play", n), {
		op: "gain",
		res: { tradegood: 2 }
	}], {}, "passive", X(e, "person", 1, n)), n === 128 && r === 4 && o("excavate", ["发掘遗址并勾格", "Excavate and mark a box"], [K("person", 1, "discard", [], "play", n), {
		op: "markFirst",
		id: n
	}], { stone: 3 }, "time", X(e, "person", 1, n) && U(t) < 7), n === 131 && (r === 2 && o("moat", ["弃置另一张牌，获得 2 武力", "Discard another card; gain 2 swords"], [K("any", 1, "discard", [], "play", n), {
		op: "gain",
		res: { sword: 2 }
	}], {}, "activate", X(e, "any", 1, n)), r === 3 && l("person", { coin: 1 })), n === 133 && c([
		1,
		2,
		2,
		3
	][r - 1]), n === 134 && (r === 1 && R(e, 55, 4) ? [
		{ coin: 5 },
		{ sword: 2 },
		{ sword: 3 },
		{ tradegood: 3 }
	].forEach((e, r) => o(`rival${r}`, ["弃置尼姆罗德领主，勾选资源格", "Discard Lord Nimrod; mark a box"], [
		G("discard", 55),
		{
			op: "mark",
			id: n,
			n: r
		},
		{
			op: "turnIfFull",
			id: n,
			n: 4
		}
	], e, "activate", !A(t).boxes.includes(r))) : r === 4 && o("ally", ["获得人物产出", "Gain a person’s production"], [ze("person", n)], {}, "activate", X(e, "person", 1, n))), n === 135 && (r < 4 ? o("border", ["降低本阶段升级武力费用", "Reduce this stage’s sword upgrade cost"], [{
		op: "discount",
		id: n,
		res: { sword: 1 }
	}], { sword: 4 }, "passive", N(t).upgrades.some((e) => (je(t, e.cost).sword ?? 0) > 0)) : o("reset", ["重置附庸国", "Reset the vassal states"], [G("turn", n, 1)])), n === 137 && (r === 1 && o("funding", ["获得 3 金币（每回合一次）", "Gain 3 coins (once per turn)"], [{
		op: "gain",
		res: { coin: 3 }
	}, {
		op: "turnUsed",
		key: "137fund"
	}], {}, "passive", !e.turnUsed.includes("137fund")), r === 2 && o("farm", ["弃置 2 建筑，改良土地", "Discard 2 buildings; improve a land"], [K("building", 2, "discard"), J("land", ["coin"])], {}, "time", X(e, "building", 2) && X(e, "land"))), n === 138 && r === 4 && o("resist", ["投入 1 武力", "Commit 1 sword"], [{
		op: "tally",
		id: n,
		n: 1
	}], { sword: 1 }, "passive"), a;
}
function Ge(e) {
	let t = [];
	for (let n of e.cards.filter((e) => ["play", "permanent"].includes(e.zone))) n.zone === "play" && (N(n).production.forEach((r, i) => {
		let a = xe(e, n, i);
		if (E(a) > 0) {
			let r = le(a);
			t.push({
				key: `produce:${n.id}:${i}`,
				card: n.id,
				kind: "produce",
				label: [`生产：${r[0]}`, `Produce: ${r[1]}`],
				steps: [{
					op: "produce",
					id: n.id,
					n: i
				}]
			}), R(e, 137, 3) && P(n, "land") && (a.coin ?? 0) > 0 && t.push({
				key: `produceTrade:${n.id}:${i}`,
				card: n.id,
				kind: "produce",
				label: ["将金币产出改为商品", "Produce trade goods instead of coins"],
				steps: [{
					op: "produce",
					id: n.id,
					n: i,
					mode: "trade"
				}]
			});
		}
	}), t.push(...Ue(e, n))), t.push(...We(e, n));
	return we(e) && t.push({
		key: "advance",
		label: ["推进：打出 2 张牌", "Advance: play 2 cards"],
		kind: "control",
		steps: [{
			op: "draw",
			n: 2 + (R(e, 94, 4) ? 2 : 0)
		}]
	}), t.push({
		key: "pass",
		label: ["结束回合", "End turn"],
		kind: "control",
		steps: [G("endTurn")]
	}), t;
}
//#endregion
//#region src/games/kingdomlegacy/events.ts
function Ke(e) {
	return A(e).stickers.includes("stay") || [
		"food_barns",
		"treehouses",
		"lighthouse",
		"wall",
		"storage",
		"jester",
		"plague",
		"enemy_soldier",
		"city_fire",
		"tornado",
		"flooding",
		"treasures",
		"pirate",
		"favor",
		"dubbing",
		"renovation",
		"prison",
		"farming_machines",
		"royal_storehouse",
		"aric_blackwood",
		"eadric_shadowstrike",
		"king_alahar",
		"double_wall",
		"inner_wall"
	].includes(N(e).key) || e.id === 92 && e.stage === 4;
}
function qe(e, t, n) {
	let r = [];
	for (let n of t) {
		let t = M(e, n).stage;
		([
			14,
			16,
			60,
			64
		].includes(n) && t === 1 || [56, 57].includes(n) && t === 4 || [
			44,
			67,
			116,
			94
		].includes(n) && t === 1 || n === 66 && t === 2 || n === 92 || n === 112 && t === 4 || [74, 75].includes(n) && t === 4) && r.push({
			op: "trigger",
			id: n,
			stage: t,
			mode: "played"
		});
	}
	for (let i of n) {
		let n = M(e, i);
		if (n.zone === "play" && (i === 28 || i === 57) && n.stage === 1) {
			let a = i === 28 ? "land" : "person", o = t.filter((t) => P(M(e, t), a));
			o.length && r.push({
				op: "trigger",
				id: i,
				stage: n.stage,
				mode: "next",
				ids: o
			});
		}
	}
	if (R(e, 65, 4) && I(e).some((e) => P(e, "building")) && r.push({
		op: "trigger",
		id: 65,
		stage: 4,
		mode: "flood"
	}), R(e, 136, 3)) {
		let i = t.filter((t) => P(M(e, t), "person")), a = n.filter((t) => P(M(e, t), "person")).length;
		for (let e = 0; e < i.length; e++) a + i.length > 1 && r.push({
			op: "trigger",
			id: 136,
			stage: 3,
			mode: "uprising"
		});
	}
	if (R(e, 138, 2)) for (let n of t.filter((t) => P(M(e, t), "person"))) r.push({
		op: "trigger",
		id: 138,
		stage: 2,
		mode: "attack",
		ids: [n]
	});
	return r;
}
function Je(e) {
	return ve(e).flatMap((e) => e.id === 44 && e.stage === 4 || e.id === 53 || e.id === 66 && e.stage === 1 || e.id === 93 && e.stage === 2 || e.id === 106 && e.stage === 4 || [
		79,
		82,
		83,
		125
	].includes(e.id) || e.id === 42 && e.stage === 4 || e.id === 54 && e.stage === 1 || e.id === 101 && e.stage >= 3 || e.id === 136 && e.stage === 2 || e.id === 138 && [1, 3].includes(e.stage) ? [{
		op: "trigger",
		id: e.id,
		stage: e.stage,
		mode: "endTurn"
	}] : []);
}
function Ye(e) {
	return ve(e).flatMap((t) => t.id === 56 || t.id === 57 && t.stage === 4 || t.id === 58 && t.stage === 1 || t.id === 65 || t.id === 86 || [
		136,
		137,
		138
	].includes(t.id) ? [{
		op: "trigger",
		id: t.id,
		stage: t.stage,
		mode: "endRound",
		ids: e.cards.filter((e) => e.blockedBy === t.id).map((e) => e.id)
	}] : []);
}
function Xe(e, t) {
	let n = t.id, r = t.stage, i = t.mode, a = M(e, n);
	if (i === "next") return [{
		...K("any", 1, "destroy", [G("turn", n, 4)]),
		ids: t.ids
	}];
	if (i === "flood") return [K("building", Math.max(0, 5 - e.cards.filter((e) => e.blockedBy === 65).length), "block", [], "play", 65)];
	if (i === "uprising") return U(a) < 8 ? [{
		op: "markFirst",
		id: n
	}] : [];
	if (i === "attack") return [{
		op: "attack",
		id: n
	}];
	if (i === "played") {
		if ([14, 16].includes(n)) return [K("coinProduction", 1, "block", [], "play", n)];
		if ([60, 64].includes(n)) return [K("production", 3, "block", [], "play", n)];
		if ([56, 57].includes(n)) return [K("land|building", 1, "block", [], "play", n)];
		if (n === 44) return [G("discardTop", void 0, 3), G("turn", 44, 4)];
		if (n === 67) return [G("discardTop", void 0, 2)];
		if (n === 66) return [K("friendly", 2, "discard")];
		if (n === 94) return [K("person", 2, "discard")];
		if (n === 116) return [K("any", 1, "discard")];
		if ([74, 75].includes(n)) return [{
			op: "discover",
			id: 76
		}];
		if (n === 112) return [{
			...K("horse", 1, "play", [], "discard"),
			optional: !0
		}];
		if (n === 92) return a.played === 1 ? [G("name", n)] : a.played <= 3 ? [{
			op: "sticker",
			id: n,
			pool: r === 4 ? [
				"coin",
				"wood",
				"stone",
				"metal",
				"sword",
				"tradegood"
			] : a.played === 2 ? ["sword", "fame5"] : ["tradegood", "fame5"]
		}] : [];
	}
	if (i === "endTurn") {
		if (n === 44) return [G("turn", n, 1)];
		if (n === 53) return [{
			op: "discoverNext",
			n: 2
		}, r === 1 ? G("turn", n, 4) : G("destroy", n)];
		if (n === 66) return [{
			op: "princess",
			id: n
		}];
		if (n === 93) return [{
			op: "discover",
			id: 94
		}];
		if (n === 106) return e.deck.length === 0 && U(a) < 8 ? [{
			...G("markFirst", n),
			optional: !0
		}] : [];
		if (n === 138 && r === 1) return I(e).filter((e) => P(e, "land")).map((e) => G("retain", e.id));
		if (n === 138 && r === 3) return (e.resources.sword ?? 0) < 1 ? [K("production", 1, "crossout")] : [];
		let t = n === 79 ? [
			1,
			2,
			1,
			2
		] : [
			1,
			2,
			3,
			4
		], i = n === 79 && r <= 2 ? "person" : "any", o = t[r - 1], s = !0;
		n === 42 && (o = 1), n === 54 && (o = 2), n === 125 && (o = 5), n === 101 && (o = 1, s = !1), n === 136 && (o = 1, s = !1);
		let c = n === 101 && r === 4 ? void 0 : n;
		return V(e, i, "play", c).length ? [{
			op: "optionalEffect",
			id: n,
			then: [...s ? [G("discard", n)] : [], K(i, o, "retain", [], "play", c, !0)]
		}] : [];
	}
	if (i === "endRound") {
		if (n === 56 && r === 1) return [K("person", 2, "destroy", [], "kingdom"), G("turn", n, 4)];
		if ([56, 57].includes(n) && r === 4) return (t.ids ?? []).map((e) => G("destroy", e));
		if (n === 58) return [K("building", 1, "destroy", [], "kingdom"), G("turn", n, 4)];
		if (n === 65) return r === 1 ? [K("friendlyNonPermanent", 3, "destroy", [], "kingdom"), G("turn", n, 4)] : [G("destroy", n), {
			op: "floodDestroy",
			ids: t.ids ?? []
		}];
		if (n === 86 && r === 1) return [K("person", 1, "bind", [
			{
				op: "sticker",
				id: -1,
				pool: ["coin"]
			},
			{
				op: "sticker",
				id: -1,
				pool: ["sword"]
			},
			{
				op: "sticker",
				id: -1,
				pool: ["knight"]
			}
		], "kingdom"), G("turn", n, 4)];
		if (n === 86 && r === 4) return [K("building", 1, "bind", [{
			op: "sticker",
			id: -1,
			pool: ["wood", "stone"]
		}, {
			op: "sticker",
			id: -1,
			pool: ["metal", "tradegood"]
		}], "kingdom"), G("destroy", n)];
		if ([
			136,
			137,
			138
		].includes(n)) return r < 4 ? [...n === 138 && r === 3 ? [J("friendly", void 0, "kingdom")] : [], G("turn", n, r + 1)] : n === 136 ? [{
			...K("friendly", U(a, 3), "crossout", [], "kingdom"),
			mode: "crossoutRepeated"
		}, G("destroy", n)] : n === 137 ? [K("coinProduction", 1, "destroy", [], "kingdom"), G("destroy", n)] : [K("land", 1, "bind", [{
			op: "sticker",
			id: -1,
			pool: ["blank"],
			n: Math.min(100, A(a).medals[0] ?? 0)
		}], "kingdom"), G("destroy", n)];
	}
	return [];
}
function Ze(e) {
	return e === 23 ? [{ op: "tutorialChoice" }] : e === 24 ? [J("land", ["coin"], "kingdom"), K("buildingProduction", 1, "bind", [G("boost", -1)], "kingdom")] : e === 30 ? [{
		op: "discoverChoice",
		ids: [
			31,
			32,
			33,
			34
		],
		n: 2,
		mode: "destroyRest"
	}] : e === 37 ? [...[
		38,
		39,
		40,
		41,
		42
	].map((e) => ({
		op: "discover",
		id: e
	}))] : e === 47 ? [{
		op: "discoverChoice",
		ids: [
			48,
			49,
			50,
			51
		],
		n: 2,
		mode: "destroyRest"
	}] : e === 68 ? [
		{ op: "finalRound" },
		G("discover", 69),
		G("discover", 70)
	] : [];
}
function Qe(e, t) {
	return _e(t) && t.id !== 108 && (t.id !== 134 || t.stage !== 1 || M(e, 55).zone === "destroyed");
}
function $e(e, t) {
	return e.map((e) => ({
		...e,
		...e.id === -1 ? { id: t } : {},
		...e.then ? { then: $e(e.then, t) } : {}
	}));
}
function Z(e, t, n) {
	e.prompt = {
		...t,
		title: n
	}, e.phase = "resolving";
}
function et(e, t) {
	t.mode !== "bind" && t.then && W(e, ...t.then);
}
function tt(e, t) {
	return V(e, t.filter, t.zone, t.id).filter((n) => (!t.ids || t.ids.includes(n.id)) && (!t.selected?.includes(n.id) || t.mode === "crossoutRepeated") && (!["destroy", "purge"].includes(t.mode ?? "") || Ce(e, n)) && (t.mode !== "purge" || Qe(e, n)) && (!["crossout", "crossoutRepeated"].includes(t.mode ?? "") || Se(e, n) > 0));
}
function Q(e, t, n, r, i = !1) {
	return {
		key: e,
		label: t,
		steps: n,
		card: r,
		danger: i,
		kind: r ? "target" : "control"
	};
}
function nt(e, t) {
	let n = [];
	if (t.op === "timing") return (t.then ?? []).map((n, r) => Q(`order:${r}`, [`${L(M(e, n.id))[0]}：结算效果`, `${L(M(e, n.id))[1]}: resolve effect`], [n, {
		...t,
		then: t.then.filter((e, t) => t !== r)
	}], n.id));
	if (t.op === "select") {
		for (let r of tt(e, t)) n.push(Q(`target:${r.id}`, L(r), [{
			...t,
			op: "selected",
			key: String(r.id)
		}], r.id, ["destroy", "purge"].includes(t.mode ?? "")));
		t.optional && n.push(Q("selectionDone", ["完成选择", "Finish selection"], t.then ?? []));
	}
	if (t.op === "resource") for (let e of (t.pool ?? x).filter((e) => x.includes(e))) n.push(Q(`resource:${e}`, S[e], [{
		op: "gain",
		res: { [e]: 1 }
	}, ...t.n > 1 ? [{
		...t,
		n: t.n - 1
	}] : []]));
	if (t.op === "sticker") for (let r of t.pool ?? x) {
		let i = x.includes(r);
		if ((e.stickers[r] ?? 0) <= 0 || i && Se(e, {
			...M(e, t.id),
			stage: t.stage ?? M(e, t.id).stage
		}) >= 9) continue;
		let a = i ? S[r] : r === "stay" ? ["留场", "Stays in play"] : r === "knight" ? ["骑士", "Knight"] : r === "blank" ? [`${t.n ?? 0} 声望`, `${t.n ?? 0} fame`] : r === "fame2" ? ["2 声望", "2 fame"] : ["5 声望", "5 fame"];
		n.push(Q(`sticker:${r}`, a, [{
			...t,
			op: "applySticker",
			key: r
		}], t.id));
	}
	if (t.op === "markChoice") {
		let r = M(e, t.id), i = t.stage ?? r.stage;
		for (let e = 0; e < w(r.id, i).boxes.length; e++) {
			if (A(r, i).boxes.includes(e)) continue;
			let a = w(r.id, i).boxes[e];
			n.push(Q(`box:${e}`, [`勾选第 ${e + 1} 格${a.text ? `：${se(a.text)[0]}` : ""}`, `Mark box ${e + 1}${a.text ? `: ${se(a.text)[1]}` : ""}`], [{
				op: "mark",
				id: r.id,
				stage: i,
				n: e
			}, ...t.n > 1 ? [{
				...t,
				n: t.n - 1
			}] : []], r.id));
		}
		t.optional && n.push(Q("markDone", ["完成勾选", "Finish marking"], []));
	}
	if (t.op === "discoverChoice") for (let r of (t.ids ?? []).filter((t) => M(e, t).zone === "box")) n.push(Q(`discover:${r}`, L(M(e, r)), [{
		op: "discover",
		id: r
	}, {
		...t,
		op: "discovered",
		key: String(r)
	}], r));
	if (t.op === "side") for (let e of [1, 4].filter((e) => !!C[t.id].stages[e])) n.push(Q(`side:${e}`, [`选择 ${T(t.id, e)[0]}`, `Choose ${T(t.id, e)[1]}`], [{
		op: "discoverSide",
		id: t.id,
		stage: e
	}], t.id));
	if (t.op === "optionalEffect") return [Q("use", ["使用此效果", "Use this effect"], t.then ?? [], t.id), Q("skip", ["跳过", "Skip"], [])];
	if (t.op === "princess" && (z(V(e, "person")) >= 2 && n.push(Q("princessPay", ["弃置 2 人物", "Discard 2 people"], [K("person", 2, "discard")])), n.push(Q("princessTurn", ["转为娇纵公主", "Turn to Spoiled Princess"], [G("turn", 66, 2)], 66))), t.op === "attack" && (U(M(e, 138), 2) < 6 && n.push(Q("attackMark", ["勾选密谋格", "Mark an espionage box"], [{
		op: "markFirst",
		id: 138,
		stage: 2
	}, { op: "attackCheck" }], 138)), V(e, "friendly").length && n.push(Q("attackDiscard", ["弃置 2 张友好牌", "Discard 2 friendly cards"], [K("friendly", 2, "discard")]))), t.op === "timeWindow") {
		for (let r of ve(e)) for (let i of We(e, r)) i.steps.some((e) => e.op === "noop") && n.push({
			...i,
			key: `window:${i.key}`,
			steps: [...i.steps, t]
		});
		n.push(Q("timeEnd", ["完成并结束回合", "Finish and end the turn"], [G("endTurn")]));
	}
	if (t.op === "discardChoice" && (n.push(Q("discardNormally", ["弃置该牌", "Discard this card"], [{
		op: "discardDirect",
		id: t.id,
		mode: t.mode
	}], t.id)), P(M(e, t.id), "person") && R(e, 96, 3) && n.push(Q("healInstead", ["重置治疗药剂代替弃置", "Reset Healing Potion instead"], [G("turn", 96, 1)], 96)), t.id === 123 && M(e, 123).stage === 4 && V(e, "wall", "play", 123).length >= 2 && n.push(Q("wallsInstead", ["弃置 2 面城墙代替", "Discard 2 walls instead"], [K("wall", 2, "discard", [], "play", 123)], 123))), t.op === "stageSticker") for (let r of Object.keys(C[t.id].stages).map(Number).filter((n) => !A(M(e, t.id), n).stickers.length)) n.push(Q(`stage:${r}`, [`改良 ${T(t.id, r)[0]}`, `Improve ${T(t.id, r)[1]}`], [{
		op: "sticker",
		id: t.id,
		stage: r,
		pool: [...x]
	}], t.id));
	if (t.op === "discountChoice") {
		let r = M(e, t.id), i = new Set(N(r).upgrades.flatMap((e) => Object.keys(je(r, e.cost))));
		for (let e of i) n.push(Q(`discount:${e}`, [`降低 1 ${S[e][0]}`, `Reduce by 1 ${S[e][1]}`], [{
			op: "discount",
			id: t.id,
			res: { [e]: 1 }
		}], t.id));
	}
	if (t.op === "boost") {
		let r = M(e, t.id), i = x.filter((e) => N(r).production.some((t, n) => (B(r, n)[e] ?? 0) > 0));
		for (let r of i) e.stickers[r] > 0 && n.push(Q(`boost:${r}`, S[r], [{
			op: "sticker",
			id: t.id,
			pool: [r]
		}], t.id));
	}
	if (t.op === "productionChoice") {
		let r = M(e, t.id);
		N(r).production.forEach((i, a) => {
			let o = xe(e, r, a), s = le(o);
			E(o) > 0 && n.push(Q(`copy:${a}`, s, [{
				op: "gain",
				res: o
			}], t.id));
		});
	}
	if (t.op === "crossout") {
		let r = M(e, t.id), i = x.filter((e) => N(r).production.some((t, n) => (B(r, n)[e] ?? 0) > 0));
		for (let e of i) n.push(Q(`crossout:${e}`, [`划去 1 ${S[e][0]} 生产`, `Cross out 1 ${S[e][1]} production`], [{
			op: "removeProduction",
			id: t.id,
			key: e
		}], t.id));
	}
	if (t.op === "placeTopBottom") return [Q("top", ["放到牌库顶", "Place on top"], [{
		op: "moveDeck",
		id: t.id,
		mode: "top"
	}], t.id), Q("bottom", ["放到牌库底", "Place on bottom"], [{
		op: "moveDeck",
		id: t.id,
		mode: "bottom"
	}], t.id)];
	if (t.op === "guild") {
		for (let r of V(e, "person", "play", t.id)) n.push(Q(`guild:${r.id}`, L(r), [G("discard", r.id), {
			...t,
			selected: [...t.selected ?? [], r.id]
		}], r.id));
		n.push(Q("guildDone", [`记录 ${z((t.selected ?? []).map((t) => M(e, t)))} 声望`, `Record ${z((t.selected ?? []).map((t) => M(e, t)))} fame`], [{
			op: "guildScore",
			id: t.id,
			ids: t.selected ?? []
		}], t.id));
	}
	if (t.op === "tutorialChoice") return [Q("continue", ["继续发展王国", "Continue the kingdom"], [
		G("discover", 24),
		G("discover", 25),
		G("discover", 26),
		G("discover", 27)
	]), Q("restart", ["重新开始教学", "Restart the tutorial"], [G("restart")], void 0, !0)];
	if (t.op === "continueRound") return [Q("continueRound", ["开始下一轮", "Start the next round"], [G("shuffleRound"), {
		op: "draw",
		n: 4
	}])];
	if (t.op === "floodDestroy") {
		for (let r of (t.ids ?? []).filter((t) => M(e, t).zone !== "destroyed")) n.push(Q(`floodBuilding:${r}`, ["摧毁被洪水阻挡的建筑", "Destroy a building blocked by the flood"], [G("destroy", r)], r, !0));
		V(e, "friendlyNonPermanent", "kingdom", 65).length && n.push(Q("floodOther", ["摧毁 2 张其他友好牌", "Destroy 2 other friendly cards"], [K("friendlyNonPermanent", 2, "destroy", [], "kingdom", 65)], void 0, !0));
	}
	if (t.op === "purgeCancel") {
		for (let r of e.purging.filter((e) => e !== 81)) n.push(Q(`savePurge:${r}`, ["取消此牌的净化", "Cancel this card’s purge"], [{
			op: "cancelPurge",
			id: r
		}, ...t.n > 1 ? [{
			...t,
			n: t.n - 1
		}] : []], r));
		n.push(Q("purgeCancelDone", ["完成净化选择", "Finish purge selection"], []));
	}
	return n;
}
function rt(e) {
	if (e.prompt) return nt(e, e.prompt);
	if (e.phase === "play" && e.queue.length === 0) return Ge(e);
	if (e.phase === "chapterEnd") {
		let t = [];
		for (let n of [
			136,
			137,
			138
		].filter((t) => !e.finished.includes(t))) t.push(Q(`chapter:${n}`, [`开始小扩展：${T(n, 1)[0]}`, `Start mini expansion: ${T(n, 1)[1]}`], [{
			op: "startExpansion",
			id: n
		}], n));
		return t.push(Q("finishCampaign", ["结束本次王国记录", "Finish this kingdom record"], [G("finishCampaign")])), t;
	}
	return [];
}
function it(e, t) {
	let n = Number(t.key), r = M(e, n), i = t.n ?? 1, a = t.mode ?? "discard", o = [...t.selected ?? [], n], s = i - (t.filter === "person" && a === "discard" ? z([r]) : 1), c = t.then ?? [], l = s > 0 ? [{
		...t,
		op: "select",
		n: s,
		selected: o,
		key: void 0
	}] : [...c], u = [];
	a === "bind" ? (u = $e(c, n), l = s > 0 ? [{
		...t,
		op: "select",
		n: s,
		selected: o,
		key: void 0
	}] : []) : a === "discard" ? u = [G("discard", n)] : a === "destroy" ? u = [G("destroy", n)] : a === "block" ? u = [{
		op: "block",
		id: n,
		key: String(t.id)
	}] : a === "retain" ? u = [G("retain", n)] : a === "play" ? u = [G("play", n)] : a === "defeat" ? u = [G("defeat", n)] : a === "bottom" ? u = [{
		op: "moveDeck",
		id: n,
		mode: "bottom"
	}] : a === "topOrBottom" ? u = [G("placeTopBottom", n)] : a === "crossout" || a === "crossoutRepeated" ? u = [G("crossout", n)] : a === "purge" && (u = [G("selectPurge", n)]), W(e, ...u, ...l);
}
function at(e, t) {
	let n = t.id, r = n === void 0 ? void 0 : M(e, n);
	switch (t.op) {
		case "noop": break;
		case "gain":
			Oe(e, t.res ?? {});
			break;
		case "spend":
			ke(e, t.res ?? {});
			break;
		case "discard":
			if (!r || F(r) || ["box", "destroyed"].includes(r.zone)) break;
			P(r, "person") && R(e, 96, 3) && n !== 96 || n === 123 && r.stage === 4 && V(e, "wall", "play", 123).length >= 2 ? Z(e, {
				...t,
				op: "discardChoice"
			}, ["选择弃置方式", "Choose how to discard"]) : H(e, n, "discard", t.mode === "ending");
			break;
		case "discardDirect":
			H(e, n, "discard", t.mode === "ending");
			break;
		case "destroy":
			r && Ce(e, r) && (H(e, n, "destroyed"), Fe(e, [`摧毁 ${L(r)[0]}`, `Destroyed ${L(r)[1]}`]));
			break;
		case "turn":
			De(e, n, t.n ?? t.stage ?? 1);
			break;
		case "upgrade": {
			let i = r.stage;
			De(e, n, t.stage), Fe(e, [`${L(r)[0]} 已升级`, `${L(r)[1]} upgraded`]), n === 129 && W(e, {
				op: "optionalEffect",
				id: n,
				then: i === 1 ? [J("land", ["coin"])] : i === 2 ? [K("any", 1, "bind", [G("boost", -1)])] : [J("land", ["stay"])]
			}), n === 135 && i === 3 && A(r, 4).medals.length < 9 && j(r, 4).medals.push(20);
			break;
		}
		case "produce": {
			let i = xe(e, r, t.n ?? 0);
			t.mode === "trade" && (i = {
				...i,
				tradegood: (i.tradegood ?? 0) + (i.coin ?? 0)
			}, delete i.coin), W(e, G("discard", n), {
				op: "gain",
				res: i
			}, ...n === 111 && r.stage < 4 ? [{
				op: "removeProduction",
				id: n,
				key: "coin"
			}] : []);
			break;
		}
		case "copyProduction":
			N(r).production.length > 1 ? Z(e, {
				...t,
				op: "productionChoice"
			}, ["选择复制的产出", "Choose the production to copy"]) : Oe(e, xe(e, r));
			break;
		case "discardTop":
			for (let n = 0; n < (t.n ?? 1) && e.deck.length; n++) H(e, e.deck[0], "discard");
			break;
		case "draw": {
			let n = e.deck.slice(0, t.n ?? 1);
			if (!n.length) break;
			let r = I(e).map((e) => e.id);
			e.resources = {};
			for (let t of n) H(e, t, "play"), M(e, t).played++;
			let i = qe(e, n, r);
			i.length && W(e, {
				op: "timing",
				then: i
			}), Fe(e, [`打出 ${n.length} 张牌`, `Played ${n.length} cards`]);
			break;
		}
		case "play": {
			if (!r || !["discard", "play"].includes(r.zone)) break;
			let t = I(e).map((e) => e.id);
			e.resources = {}, H(e, n, "play"), r.played++, W(e, {
				op: "timing",
				then: qe(e, [n], t)
			});
			break;
		}
		case "block":
			r && r.zone === "play" && (H(e, n, "blocked"), r.blockedBy = Number(t.key));
			break;
		case "discover":
			if (!r || r.zone !== "box") break;
			if (N(r).types.includes("scroll")) {
				r.zone = "destroyed", W(e, ...Ze(n));
				break;
			}
			if (C[n].choice) {
				Z(e, {
					op: "side",
					id: n
				}, ["选择发现时的朝向", "Choose the card’s starting side"]);
				break;
			}
			H(e, n, F(r) ? "permanent" : "discard"), Fe(e, [`发现 ${L(r)[0]}`, `Discovered ${L(r)[1]}`]), n === 70 && (e.finalRound = !0);
			break;
		case "discoverSide":
			r.stage = t.stage, H(e, n, F(r) ? "permanent" : "discard"), Fe(e, [`发现 ${L(r)[0]}`, `Discovered ${L(r)[1]}`]), n === 70 && (e.finalRound = !0);
			break;
		case "discoverNext": {
			let n = e.cards.find((e) => e.zone === "box" && e.id <= 70);
			if (!n) {
				e.finalRound = !0;
				break;
			}
			let r = P(n, "scroll");
			W(e, {
				op: "discover",
				id: n.id
			}, ...!r && (t.n ?? 1) > 1 ? [{
				...t,
				n: t.n - 1
			}] : []);
			break;
		}
		case "discovered": {
			let n = (t.ids ?? []).filter((n) => n !== Number(t.key) && M(e, n).zone === "box");
			if ((t.n ?? 1) > 1 && n.length) W(e, {
				...t,
				op: "discoverChoice",
				ids: n,
				n: t.n - 1
			});
			else if (t.mode === "destroyRest") for (let t of n) H(e, t, "destroyed");
			break;
		}
		case "undiscover":
			De(e, n, 1), H(e, n, "box");
			break;
		case "finalRound":
			e.finalRound = !0;
			break;
		case "timing":
			t.then?.length === 1 ? W(e, t.then[0]) : t.then?.length && Z(e, t, ["选择下一项同时触发的效果", "Choose the next simultaneous effect"]);
			break;
		case "trigger":
			W(e, ...Xe(e, t));
			break;
		case "select":
			(t.n ?? 1) <= 0 || !tt(e, t).length ? et(e, t) : Z(e, t, t.title ?? ["选择目标卡牌", "Choose a target card"]);
			break;
		case "selected":
			it(e, t);
			break;
		case "resource":
			(t.n ?? 1) > 0 && Z(e, t, ["选择获得的资源", "Choose a resource to gain"]);
			break;
		case "sticker":
			nt(e, t).length === 1 ? W(e, ...nt(e, t)[0].steps) : nt(e, t).length && Z(e, t, ["选择贴纸", "Choose a sticker"]);
			break;
		case "applySticker":
			Me(e, n, t.key, t.stage, t.n);
			break;
		case "mark":
			Ne(e, n, t.n, t.stage);
			break;
		case "markFirst": {
			let i = t.stage ?? r.stage;
			Ne(e, n, w(n, i).boxes.findIndex((e, t) => !A(r, i).boxes.includes(t)), i);
			break;
		}
		case "markMany": {
			let i = N(r).boxes.length - U(r);
			i > 0 && (t.n ?? 1) > 0 && W(e, {
				op: "markChoice",
				id: n,
				n: Math.min(i, t.n ?? 1)
			});
			break;
		}
		case "track": {
			let i = r.stage, a = t.n ?? U(r);
			Ne(e, n, a), n === 25 && i === 1 && U(r) === 10 && W(e, G("turn", 25, 4), G("discover", 135)), n === 26 && i === 1 && U(r) === 12 && De(e, 26, 4), n === 91 && i === 1 && U(r) === 5 && De(e, 91, 4), n === 90 && Oe(e, { tradegood: 5 }), [28, 58].includes(n) && [
				0,
				2,
				4
			].includes(a) && W(e, {
				op: "sticker",
				id: n,
				pool: ["wood"]
			});
			break;
		}
		case "turnIfFull":
			U(r) >= N(r).boxes.length && De(e, n, t.n);
			break;
		case "beeComplete":
			U(r) === 4 && W(e, {
				op: "sticker",
				id: n,
				pool: ["coin"]
			});
			break;
		case "once":
			j(r).used.push(t.key);
			break;
		case "turnUsed":
			e.turnUsed.push(t.key);
			break;
		case "discount": {
			let e = j(r);
			for (let n of x) e.discount[n] = (e.discount[n] ?? 0) + (t.res?.[n] ?? 0);
			break;
		}
		case "removeProduction": {
			let e = j(r), n = t.key;
			e.removed[n] = (e.removed[n] ?? 0) + 1;
			break;
		}
		case "tally": {
			let e = j(r);
			e.medals[0] = (e.medals[0] ?? 0) + (t.n ?? 1);
			break;
		}
		case "guildScore":
			j(r).medals.push(z((t.ids ?? []).map((t) => M(e, t))));
			break;
		case "calendar": {
			let t = Pe(e, e.discard).slice(0, 15);
			for (let n of t) H(e, n, "deck");
			break;
		}
		case "moveDeck":
			e.deck.length && (Ee(e, n), r.zone = "deck", delete r.blockedBy, t.mode === "top" ? e.deck.unshift(n) : e.deck.push(n));
			break;
		case "retain":
			r?.zone === "play" && !e.retained.includes(n) && e.retained.push(n);
			break;
		case "attackCheck":
			if (U(M(e, 138), 2) >= 6) for (let t of [...e.deck]) H(e, t, "discard");
			break;
		case "name":
			Z(e, t, ["为陌生人命名", "Name the stranger"]);
			break;
		case "defeat":
			[
				45,
				61,
				57
			].includes(n) && r.stage === 1 ? De(e, n, 4) : [
				14,
				16,
				60,
				64
			].includes(n) && r.stage === 1 ? (H(e, n, "destroyed"), W(e, q(n < 20 ? 2 : 3))) : n === 76 && r.stage === 1 ? (H(e, n, "destroyed"), W(e, G("discover", 77))) : [
				53,
				56,
				57,
				94
			].includes(n) && H(e, n, "destroyed");
			break;
		case "timeWindow":
			Z(e, t, ["可使用被动效果，然后结束回合", "Use passive effects, then end the turn"]);
			break;
		case "endTurn":
			W(e, {
				op: "timing",
				then: Je(e)
			}, G("cleanupTurn"));
			break;
		case "cleanupTurn":
			W(e, ...I(e).filter((t) => !Ke(t) && !e.retained.includes(t.id)).map((e) => e.id).map((e) => ({
				op: "discard",
				id: e,
				mode: "ending"
			})), G("afterTurn"));
			break;
		case "afterTurn":
			e.resources = {}, e.retained = [], e.turnUsed = [], e.deck.length ? (e.turn++, W(e, {
				op: "draw",
				n: 4
			})) : W(e, G("endRound"));
			break;
		case "endRound": {
			let t = Ye(e);
			for (let t of [...I(e)]) H(e, t.id, "discard", !0);
			W(e, {
				op: "timing",
				then: t
			}, G("exports"), G("afterRound"));
			break;
		}
		case "exports": {
			if (!be(e, 27)) break;
			let t = M(e, 27), n = t.stage, r = A(t).medals[0] ?? 0, i = (n === 1 ? [
				10,
				20,
				30,
				40,
				55,
				75,
				100
			] : [
				25,
				50,
				75,
				100,
				150,
				200,
				250
			]).find((e) => r >= e && !A(t).used.includes(`reward:${e}`));
			i && W(e, {
				op: "exportReward",
				id: 27,
				stage: n,
				n: i
			}, G("exports"));
			break;
		}
		case "exportReward": {
			j(r).used.push(`reward:${t.n}`);
			let n = t.n;
			t.stage === 1 ? (n === 10 && W(e, J("land", [
				"coin",
				"wood",
				"stone"
			], "kingdom")), n === 20 && W(e, J("person", ["stay"], "kingdom")), n === 30 && W(e, G("discover", 86)), n === 40 && W(e, J("building", [
				"metal",
				"sword",
				"tradegood"
			], "kingdom")), n === 55 && W(e, J("friendly", [
				"wood",
				"stone",
				"metal",
				"sword"
			], "kingdom")), n === 75 && W(e, J("any", ["fame5"], "kingdom")), n === 100 && De(e, 27, 4)) : (n === 25 && W(e, K("land", 2, "bind", [{
				op: "sticker",
				id: -1,
				pool: ["fame2"]
			}], "kingdom")), n === 50 && W(e, J("person", ["fame5"], "kingdom")), n === 75 && W(e, G("discover", 107)), n === 100 && W(e, J("building", ["fame5"], "kingdom")), n === 150 && W(e, K("permanent", 1, "bind", [G("freeTrack", -1)], "permanent", 27)), n === 200 && W(e, ...ye(e).filter((e) => F(e) && e.id !== 27).map((e) => ({
				op: "optionalEffect",
				id: e.id,
				then: [G("freeTrack", e.id)]
			}))), n === 250 && W(e, G("discover", 117)));
			break;
		}
		case "freeTrack": {
			let t = U(r);
			N(r).boxes.length > t && W(e, {
				op: "track",
				id: n,
				n: t
			});
			break;
		}
		case "afterRound":
			if (e.chapter === 0 && e.finalRound) {
				W(e, G("completeChapter"));
				break;
			}
			if (e.chapter > 0 && M(e, e.chapter).zone === "destroyed") {
				W(e, G("completeChapter"));
				break;
			}
			e.round++, e.turn = 1, W(e, ...e.chapter === 0 ? [{
				op: "discoverNext",
				n: 2
			}] : [], G("roundCheckpoint"));
			break;
		case "roundCheckpoint":
			Z(e, { op: "continueRound" }, ["本轮已结束，可保存后开始下一轮", "Round complete; save before starting the next round"]);
			break;
		case "shuffleRound":
			e.deck = Pe(e, e.cards.filter((e) => [
				"deck",
				"discard",
				"play"
			].includes(e.zone) && !F(e)).map((e) => e.id)), e.discard = [];
			for (let t of e.deck) M(e, t).zone = "deck";
			e.resources = {};
			break;
		case "completeChapter": {
			let t = Le(e);
			e.scores.push({
				chapter: e.chapter,
				score: t
			}), e.finished.push(e.chapter), e.chapter > 0 && e.stickers.chapter > 0 && e.stickers.chapter--, e.phase = "chapterEnd", e.queue = [], e.prompt = null, Fe(e, [`本章完成，王国声望 ${t}`, `Chapter complete: ${t} kingdom fame`]);
			break;
		}
		case "startExpansion": {
			e.chapter = n, e.finalRound = !1, e.round = 1, e.turn = 1, r.stage = 1, r.zone = "permanent", e.purging = [];
			let t = Pe(e, ye(e).filter((e) => !F(e)).map((e) => e.id)), i = [];
			for (let n = 0; n + 12 <= t.length; n += 12) {
				let r = t.slice(n, n + 12).filter((t) => Qe(e, M(e, t)));
				r.length && i.push({
					...K("any", 1, "purge", [], "kingdom"),
					ids: r,
					title: ["从本组 12 张牌中净化 1 张友好牌", "Purge a friendly card from this group of 12"]
				});
			}
			W(e, ...i, {
				...K("permanent", 1, "purge", [], "permanent", n),
				title: ["净化 1 张友好永久牌", "Purge 1 friendly permanent card"]
			}, G("purgeResolve"), G("shuffleRound"), {
				op: "draw",
				n: 4
			});
			break;
		}
		case "selectPurge":
			r && Qe(e, r) && !e.purging.includes(n) && e.purging.push(n);
			break;
		case "purgeResolve":
			W(e, ...e.purging.includes(81) && M(e, 81).stage > 1 ? [{
				op: "purgeCancel",
				n: M(e, 81).stage - 1
			}] : [], G("purgeFinish"));
			break;
		case "cancelPurge":
			e.purging = e.purging.filter((e) => e !== n);
			break;
		case "purgeFinish": {
			let t = e.purging.reduce((t, n) => t + Ie(e, M(e, n), !0, !0), 0);
			e.stickers.blank > 0 && (e.stickers.blank--, e.purgedFame += t);
			for (let t of e.purging) H(e, t, "destroyed");
			e.purging = [];
			break;
		}
		case "finishCampaign":
			e.phase = "done", e.queue = [], e.prompt = null;
			break;
		case "restart": {
			let t = Re(e.owner, e.seed), n = e.serial;
			Object.assign(e, t, { serial: n });
			break;
		}
		case "optionalEffect":
		case "princess":
		case "attack":
		case "stageSticker":
		case "discountChoice":
		case "boost":
		case "crossout":
		case "placeTopBottom":
		case "guild":
		case "tutorialChoice":
		case "floodDestroy":
		case "purgeCancel":
		case "discoverChoice":
		case "markChoice": nt(e, t).length && Z(e, t, t.title ?? ["选择卡牌效果", "Choose a card effect"]);
	}
}
function ot(e) {
	if (e.prompt) return;
	let t = e.queue.shift();
	return t && at(e, t), !e.prompt && !e.queue.length && e.phase === "resolving" && (e.phase = "play"), e.beatMs = 460, t;
}
//#endregion
//#region src/games/kingdomlegacy/meta.ts
var st = {
	id: "kingdomlegacy",
	sdkApi: 2,
	tier: "alpha",
	mechanics: ["deck-bag-building", "engine-building"],
	interactionTags: [],
	nameKey: "games.kingdomlegacy.name",
	descKey: "games.kingdomlegacy.desc",
	rulesKey: "games.kingdomlegacy.rules",
	icon: "🏰",
	iconImg: "games/kingdomlegacy.webp",
	rulesUrl: { en: "https://kingdomlegacygame.com/public_assets/FK-Rules-2nd-edition.pdf" },
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#725133",
	releasedAt: "2026-11-03T03:12:42+08:00",
	search: {
		py: "wang guo xing wang lu feng jian wang guo",
		init: "wgxwlfjwg"
	},
	hotseat: "open"
}, ct = e.object({ checkpoint: ge.nullable().default(null) }).prefault({}), lt = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("choose"),
		key: e.string().max(160)
	}),
	e.object({
		type: e.literal("name"),
		value: e.string().trim().min(1).max(40)
	}),
	e.object({
		type: e.literal("tick"),
		now: e.number()
	})
]), ut = e.object({
	key: e.string(),
	label: D,
	card: e.int().optional(),
	danger: e.boolean().optional(),
	kind: e.enum([
		"produce",
		"upgrade",
		"effect",
		"target",
		"control"
	]).optional()
}), dt = e.object({
	owner: e.string(),
	campaignId: e.string(),
	serial: e.int(),
	round: e.int(),
	turn: e.int(),
	chapter: e.int(),
	phase: e.enum([
		"play",
		"resolving",
		"chapterEnd",
		"done"
	]),
	cards: e.array(he),
	offered: e.array(he),
	values: e.record(e.string(), e.object({
		fame: e.int(),
		production: e.array(fe)
	})),
	top: e.array(he).max(2),
	deckCount: e.int(),
	discard: e.array(e.int()),
	resources: fe,
	stickers: e.record(e.string(), e.int()),
	choices: e.array(ut),
	prompt: D.nullable(),
	naming: e.boolean(),
	fame: e.int(),
	purgedFame: e.int(),
	scores: e.array(e.object({
		chapter: e.int(),
		score: e.int()
	})),
	log: e.array(D)
}), ft = e.object({ checkpoint: ge.nullable() }), pt = () => ({ code: "games.kingdomlegacy.invalid" }), mt = {
	meta: st,
	saveCompatibility: { version: "1" },
	schemas: {
		action: lt,
		publicView: dt,
		privateView: ft,
		config: ct
	},
	setup(e, t, n) {
		let r = e.checkpoint ? structuredClone(e.checkpoint) : Re(t[0], n);
		return r.owner = t[0], { state: r };
	},
	reduce(e, t, n) {
		if (t.type === "tick") {
			if (n.by !== "$engine" || e.prompt || !e.queue.length) return pt();
		} else if (n.by !== e.owner || e.phase === "done") return pt();
		let r = structuredClone(e), i = [];
		if (t.type === "name") {
			if (r.prompt?.op !== "name") return pt();
			r.cards[r.prompt.id - 1].name = t.value, r.prompt = null;
		} else if (t.type === "choose") {
			let e = rt(r).find((e) => e.key === t.key);
			if (!e) return pt();
			r.prompt = null, r.phase = "resolving", r.queue.unshift(...e.steps);
		} else {
			let e = structuredClone(r.cards), t = ot(r), n = r.cards.filter((t) => JSON.stringify(e[t.id - 1]) !== JSON.stringify(t));
			n.length && i.push({
				kind: "change",
				data: {
					cards: n.map((t) => ({
						before: e[t.id - 1],
						after: t
					})),
					op: t?.op ?? ""
				}
			});
		}
		return r.serial++, !r.prompt && !r.queue.length && r.phase === "resolving" && (r.phase = "play"), {
			state: r,
			fx: i
		};
	},
	viewFor(e, t) {
		let n = R(e, 130, 2) ? 2 : 1, r = rt(e).map((e) => ({
			key: e.key,
			label: e.label,
			card: e.card,
			kind: e.kind,
			danger: e.danger
		})), i = new Set(e.cards.filter((e) => [
			"play",
			"discard",
			"permanent",
			"blocked"
		].includes(e.zone)).map((e) => e.id));
		return {
			public: {
				owner: e.owner,
				campaignId: e.campaignId,
				serial: e.serial,
				round: e.round,
				turn: e.turn,
				chapter: e.chapter,
				phase: e.phase,
				cards: e.cards.filter((e) => i.has(e.id)),
				offered: e.prompt || e.phase === "chapterEnd" ? e.cards.filter((e) => !i.has(e.id) && r.some((t) => t.card === e.id)) : [],
				top: e.deck.slice(0, n).map((t) => {
					let n = e.cards[t - 1];
					return {
						...n,
						changes: { [n.stage]: n.changes[n.stage] }
					};
				}).map((e) => ({
					...e,
					changes: Object.fromEntries(Object.entries(e.changes).filter(([, e]) => e !== void 0))
				})),
				values: Object.fromEntries(e.cards.filter((t) => i.has(t.id) || e.deck.slice(0, n).includes(t.id) || r.some((e) => e.card === t.id)).map((t) => [t.id, {
					fame: Ie(e, t, e.phase === "done" || e.phase === "chapterEnd"),
					production: N(t).production.map((n, r) => xe(e, t, r))
				}])),
				deckCount: e.deck.length,
				discard: e.discard,
				resources: e.resources,
				stickers: e.stickers,
				choices: r,
				prompt: e.prompt?.title ?? null,
				naming: e.prompt?.op === "name",
				fame: Le(e),
				purgedFame: e.purgedFame,
				scores: e.scores,
				log: e.log
			},
			private: { checkpoint: t === e.owner ? structuredClone(e) : null }
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: [e.owner],
			ranking: [e.owner],
			scores: { [e.owner]: Le(e) }
		} : { phase: e.phase };
	},
	nextTickIn(e) {
		return e.queue.length && !e.prompt ? e.beatMs || 460 : null;
	}
}, ht = "kingdom-v1";
async function gt() {
	let e = await g();
	return e.values[ht] ? ge.parse(JSON.parse(e.values[ht])) : null;
}
async function _t(e) {
	let t = await g();
	for (let n = 0; n < 5; n++) {
		let n = t.values[ht], r = n ? ge.parse(JSON.parse(n)) : null;
		if (r?.campaignId === e.campaignId && r.serial > e.serial) return "newer";
		if (r?.campaignId === e.campaignId && r.serial === e.serial) return JSON.stringify(r) === JSON.stringify(e) ? "saved" : "newer";
		let i = await _({
			revision: t.revision,
			values: {
				...t.values,
				[ht]: JSON.stringify(e)
			}
		});
		if (i.status === "saved") return "saved";
		if (i.snapshot.values[ht] !== t.values[ht]) return "newer";
		t = i.snapshot;
	}
	throw Error("storage-conflict");
}
//#endregion
//#region src/games/kingdomlegacy/card-info.ts
var vt = {
	plains: ["激活：弃置另一张友好牌，获得 2 金币。", "Activate: discard another friendly card to gain 2 coins."],
	rocky_area: ["激活：支付 1 金币，获得 2 石材。", "Activate: pay 1 coin to gain 2 stone."],
	shallow_mines: ["摧毁：发现 84 或 85 号矿井。", "Destroy: discover Mine 84 or 85."],
	forest: ["激活：获得 3 木材，然后转为伐后林地。", "Activate: gain 3 wood, then turn to Felled Forest."],
	sacred_well: ["摧毁：发现 82 或 83 号神龛。", "Destroy: discover Shrine 82 or 83."],
	town_hall: ["激活：从弃牌堆打出 1 张土地。", "Activate: play 1 land from your discard."],
	keep: ["激活：从弃牌堆打出 1 张土地或建筑。", "Activate: play 1 land or building from your discard."],
	castle: ["激活：从弃牌堆打出 1 张牌。", "Activate: play 1 card from your discard."],
	trader: ["激活：支付 1 金币，获得 1 木材。", "Activate: pay 1 coin to gain 1 wood."],
	bazaar: ["激活：支付 1 金币，获得 1 木材或石材。", "Activate: pay 1 coin to gain 1 wood or stone."],
	market: ["激活：支付 1 金币，获得 1 木材、石材或金属。", "Activate: pay 1 coin to gain 1 wood, stone or metal."],
	jungle: ["激活：支付 1 金币，获得 1 木材。", "Activate: pay 1 coin to gain 1 wood."],
	huge_trees: ["激活：支付 1 金币，获得 2 木材。", "Activate: pay 1 coin to gain 2 wood."],
	explorers: ["激活：发现一片新领土（71–74），然后转向。", "Activate: discover a new territory (71–74), then turn."],
	field_worker: ["激活：获得场上另一张土地的产出。", "Activate: gain another land’s production in play."],
	worker: ["激活：获得场上另一张建筑的产出。", "Activate: gain another building’s production in play."],
	servant: ["激活：获得 1 金币、木材或石材。", "Activate: gain 1 coin, wood or stone."],
	bandit: ["入场：阻挡 1 张生产金币的牌。支付 1 武力可击败并摧毁本牌，获得 2 自选资源。", "When played: block 1 coin-producing card. Pay 1 sword to defeat and destroy this card, gaining 2 resources."],
	skilled_bandit: ["入场：阻挡 3 张有产出的牌。支付 3 武力可击败并摧毁本牌，获得 3 自选资源。", "When played: block 3 producing cards. Pay 3 swords to defeat and destroy this card, gaining 3 resources."],
	chapel: ["激活：支付 3 金币，发现传教士（103）。", "Activate: pay 3 coins to discover the Missionary (103)."],
	church: ["激活：支付 4 金币，发现牧师（104）。", "Activate: pay 4 coins to discover the Priest (104)."],
	cathedral: ["场上每位人物使本牌额外生产 1 金币。", "This card produces 1 extra coin per person in play."],
	smithy: ["激活：重置本牌，发现珠宝业（90）。", "Activate: reset this card and discover Jewellery (90)."],
	arsenal: ["激活：场上每位人物提供 1 武力。", "Activate: gain 1 sword per person in play."],
	lighthouse: ["被动：可弃置牌库顶牌。", "Passive: you may discard the top card of your deck."],
	fishing_boat: ["激活：发现海岸（75）。", "Activate: discover the Shores (75)."],
	army: ["时间效果：支付下一格的武力费用并勾选。填满后转为大军，发现附庸国（135）。", "Time effect: pay the next box’s sword cost and mark it. When full, turn to Grand Army and discover Vassal States (135)."],
	grand_army: ["时间效果：支付下一格的武力费用并勾选。", "Time effect: pay the next box’s sword cost and mark it."],
	treasure: ["时间效果：支付下一格的金币费用并勾选。填满后转为巨额宝藏。", "Time effect: pay the next box’s coin cost and mark it. When full, turn to Immense Treasure."],
	extended_treasure: ["时间效果：支付下一格的金币费用并勾选。", "Time effect: pay the next box’s coin cost and mark it."],
	export: ["被动：每支付 1 商品，出口总量增加 1；轮末领取达到的奖励。", "Passive: pay 1 trade good to increase exports by 1. Claim reached rewards at round end."],
	mass_export: ["被动：每支付 1 商品，出口总量增加 1；轮末领取达到的奖励。", "Passive: pay 1 trade good to increase exports by 1. Claim reached rewards at round end."],
	young_forest: ["时间效果：勾选下一格；指定格为本牌增加木材生产。", "Time effect: mark the next box; indicated boxes add wood production to this card."],
	volcanic_eruption: ["下一张打出的土地将被摧毁，然后本牌转向。", "Destroy the next land played, then turn this card."],
	pretend_noble: ["激活：重置本牌，选择一个尚无贴纸的阶段，增加 1 自选资源生产。", "Activate: reset this card, then add 1 resource production to an unmodified stage."],
	entrepreneur: ["时间效果：发现学校（118）。", "Time effect: discover the School (118)."],
	tavern: ["激活：发现任务（87）。", "Activate: discover Quests (87)."],
	cozy_pub: ["激活：弃置另一位人物，发现陌生人（92）。", "Activate: discard another person to discover the Stranger (92)."],
	hotel: ["激活：场上每位人物提供 1 金币。", "Activate: gain 1 coin per person in play."],
	observatory: ["时间效果：发现天文学家（95）。", "Time effect: discover the Astronomer (95)."],
	lab: ["时间效果：发现炼金术师（96）。", "Time effect: discover the Alchemist (96)."],
	engineer: ["激活：摧毁伐木场、粮仓或渔船，发现对应建造项目（100–102）。", "Activate: destroy Lumberjack, Food Barns or Fishing Boat to discover its building project (100–102)."],
	royal_architect: ["激活：摧毁城堡、钻石矿或神庙，发现对应建造项目（123–125）。", "Activate: destroy Castle, Diamond Mine or Temple to discover its building project (123–125)."],
	trebuchet: ["摧毁：击败 1 个敌人，并推进军队轨道。", "Destroy: defeat 1 enemy and advance the Army track."],
	inspired_inventor: ["激活：重置本牌并勾格，发现一项发明，或获得自选资源。", "Activate: reset and mark this card to discover an invention or gain resources."],
	mercenary: ["激活：支付 2 金币，勾选 1–2 个资源格。", "Activate: pay 2 coins to mark 1–2 resource boxes."],
	mason: ["激活：支付 2 金币，发现纪念建筑（88 或 89）。", "Activate: pay 2 coins to discover Monument 88 or 89."],
	brick_road: ["时间效果：从建造项目 109、110 中保留 1 张，摧毁另一张。", "Time effect: keep 1 of building projects 109 and 110, destroying the other."],
	stone_street: ["时间效果：从建造项目 111、112 中保留 1 张，摧毁另一张。", "Time effect: keep 1 of building projects 111 and 112, destroying the other."],
	dark_knight: ["不能推进或使用时间效果。激活：支付 3 武力击败本牌，使其转向。", "You cannot advance or use time effects. Activate: pay 3 swords to defeat and turn this card."],
	training_grounds: ["激活：支付 1 金币，获得 1 武力。", "Activate: pay 1 coin to gain 1 sword."],
	strategist: ["激活：从弃牌堆打出 1 张城墙或骑士。", "Activate: play 1 wall or knight from your discard."],
	peak_village: ["激活：发现山上之城（105），然后重置。", "Activate: discover City on a Hill (105), then reset."],
	architect: ["时间效果：重置本牌，发现雕像（78）或别墅（79）。", "Time effect: reset this card and discover Statue (78) or Villa (79)."],
	enemy_soldier: ["入场：阻挡 1 张土地或建筑。轮末：摧毁其阻挡的牌。支付 2 武力可摧毁敌兵。", "When played: block 1 land or building. Round end: destroy its blocked card. Pay 2 swords to destroy this enemy."],
	assassin: ["入场后，摧毁接下来打出的 1 位人物，然后转向。支付 3 武力也可击败并转向。", "Destroy the next person played, then turn. You may also pay 3 swords to defeat and turn this card."],
	lost_civilization: ["激活：弃置另外 6 张友好牌，发现遗物（108）。", "Activate: discard 6 other friendly cards to discover the artifact (108)."],
	innkeeper: ["激活：弃置另一位人物，获得 2 自选资源。", "Activate: discard another person to gain 2 resources."],
	young_princess: ["回合末：弃置 2 位人物，否则转为娇纵公主。", "Turn end: discard 2 people or turn to Spoiled Princess."],
	spoiled_princess: ["入场：弃置 2 张友好牌。", "When played: discard 2 friendly cards."],
	sickness: ["入场：弃置牌库顶的 2 张牌。", "When played: discard the top 2 cards of your deck."],
	finishing_touch: ["摧毁：给另一张友好牌添加商品与 5 声望贴纸。", "Destroy: add a trade-good sticker and a 5-fame sticker to another friendly card."],
	royal_visit: ["激活：使另一张牌的一项升级资源费用永久降低 1。", "Activate: permanently reduce another card’s upgrade resource cost by 1."],
	inquisitor: ["摧毁：摧毁另一张负面牌。", "Destroy: destroy another negative card."],
	pirate: ["每次获得金币时少获得 1。支付 2 武力可击败并摧毁海盗，发现泻湖（77）。", "Gain 1 fewer coin each time. Pay 2 swords to defeat and destroy the Pirate, discovering Lagoon (77)."],
	sea_gate_wall: ["激活：从弃牌堆打出 1 张航海牌。", "Activate: play 1 seafaring card from your discard."],
	quests: ["时间效果：弃置下一格指定数量的人物并勾选该格。", "Time effect: discard the next box’s number of people and mark it."],
	a_perfect_tower: ["时间效果：支付下一格的石材费用并勾选。", "Time effect: pay the next box’s stone cost and mark it."],
	prison: ["激活：弃置 1 个敌人并勾格，每格额外提供 2 声望。", "Activate: discard 1 enemy and mark a box. Gain 2 fame per marked box."],
	jewellery: ["时间效果：支付下一格的金属费用并勾选，获得 5 商品。", "Time effect: pay the next box’s metal cost, mark it and gain 5 trade goods."],
	the_ark: ["激活：场上每有 2 位人物，勾选 1 格。每格提供 1 声望。", "Activate: mark 1 box per 2 people in play. Gain 1 fame per marked box."],
	astronomer: ["激活：支付 2 金币，勾选 1 个声望格。", "Activate: pay 2 coins to mark 1 fame box."],
	astrologist: ["激活：将场上至多 3 张其他牌放到牌库顶或底。牌库须非空。", "Activate: move up to 3 other cards in play to the deck top or bottom. The deck must be nonempty."],
	alchemist: ["激活：支付 2 金币，将本牌转为一种药剂。", "Activate: pay 2 coins to turn this card to a potion."],
	potion_of_strength: ["激活：重置本牌，获得 3 武力。", "Activate: reset this card to gain 3 swords."],
	healing_potion: ["人物即将弃置时，可重置本牌代替弃置。", "When a person would be discarded, you may reset this card instead."],
	love_potion: ["激活：重置本牌，获得 5 商品。", "Activate: reset this card to gain 5 trade goods."],
	compass: ["激活：场上每张航海牌使本牌勾选 1 格，填满后转向。", "Activate: mark 1 box per seafaring card in play; turn when full."],
	astrolabe: ["激活：场上每张航海牌使本牌勾选 1 格，填满后转向。", "Activate: mark 1 box per seafaring card in play; turn when full."],
	navigation: ["激活：场上每张航海牌使本牌勾选 1 格，填满后转向。", "Activate: mark 1 box per seafaring card in play; turn when full."],
	calendar: ["激活：勾格，将弃牌堆洗牌后至多 15 张放入牌库底；牌库须非空。", "Activate: mark a box, shuffle your discard and add up to 15 cards to the deck bottom. The deck must be nonempty."],
	wood_industry: ["激活：发现建造方舟（91）。", "Activate: discover Build an Ark (91)."],
	wood_shipment: ["被动：可以将 1 木材与 1 商品相互转换。", "Passive: exchange 1 wood for 1 trade good or vice versa."],
	fish_quota: ["激活：勾选下一格，填满后转向。", "Activate: mark the next box; turn when full."],
	missionary: ["激活：支付 3 金币，将 1 个强盗转为工人。", "Activate: pay 3 coins to turn 1 bandit into a Worker."],
	beekeeper: ["激活：勾格；第 4 格使本牌增加 1 金币生产。", "Activate: mark a box; the fourth adds 1 coin production to this card."],
	grand_guild_hall: ["激活：弃置任意数量的其他人物，将人数写入一个空声望奖章。共 3 个奖章。", "Activate: discard any number of other people and record their count in an empty fame medal. There are 3 medals."],
	groom: ["入场：可从弃牌堆打出 1 匹马。激活：支付 2 金币，为生产总量 0–3 的马添加资源贴纸。", "When played: you may play 1 horse from your discard. Activate: pay 2 coins to add a resource sticker to a horse with 0–3 production."],
	eadric_shadowstrike: ["入场：弃置另一张牌。激活：弃置另一位人物，获得 3 武力。", "When played: discard another card. Activate: discard another person to gain 3 swords."],
	royal_storehouse: ["回合末：可选择保留另一张场上牌。", "Turn end: you may retain 1 other card in play."],
	double_wall: ["整个王国每面城墙提供 4 声望；进行中只计算可见牌。", "Gain 4 fame per wall in your kingdom; only visible cards count during play."],
	moat_bridge: ["激活：支付 1 金币，从弃牌堆打出 1 位人物。", "Activate: pay 1 coin to play 1 person from your discard."],
	moat: ["激活：弃置另一张牌，获得 2 武力。", "Activate: discard another card to gain 2 swords."],
	vassal_states: ["激活：重置本牌；永久保留已写入的声望奖章。", "Activate: reset this card, retaining its recorded fame medals."],
	resistance: ["被动：每支付 1 武力，记录 1 点抵抗；轮末可转成至多 100 声望贴纸。", "Passive: pay 1 sword to record 1 resistance. At round end, convert up to 100 into a fame sticker."]
};
function yt(e) {
	let t = N(e).key, n = e.stage, r = [];
	if (Ke(e) && r.push(["留场：回合末不弃置，轮末仍弃置。", "Stays in play at turn end; discard at round end."]), vt[t] && r.push(vt[t]), (e.id === 123 || e.id === 9 && n >= 2 && t !== "keep" && t !== "castle") && r.push(vt.castle), e.id === 36 && n === 4) {
		let t = e.changes[String(n)]?.used ?? [];
		for (let e of [3, 4]) t.includes(`train${e}`) || r.push([`时间效果（一次）：支付 ${e} 金属，为本牌添加 1 武力贴纸。`, `Time effect (once): pay ${e} metal to add 1 sword-production sticker here.`]);
	}
	if (e.id === 41 && r.push(n === 1 ? ["激活：弃置牌库顶牌，或勾选 1 格并获得格内资源。", "Activate: discard the deck’s top card, or mark 1 box and gain its resources."] : ["激活：勾选 1–2 格并获得格内资源。", "Activate: mark 1–2 boxes and gain their resources."]), e.id === 42 && n === 4 && r.push(["回合末：可弃置本牌，保留另一张牌。", "Turn end: you may discard this to retain 1 other card."]), e.id === 48 && r.push([`时间效果：支付 3 金币，发现 ${[
		119,
		120,
		121,
		122
	][n - 1]} 号牌。`, `Time effect: pay 3 coins to discover card ${[
		119,
		120,
		121,
		122
	][n - 1]}.`]), e.id === 50 && (r.push([`时间效果：发现 ${125 + n} 号土地。`, `Time effect: discover land ${125 + n}.`]), n === 4 && r.push(["激活：弃置另一张土地，获得 2 自选资源。", "Activate: discard another land to gain 2 resources of your choice."])), e.id === 51 && n < 4 && r.push([`时间效果：发现 ${129 + n} 号边境土地。`, `Time effect: discover border land ${129 + n}.`]), e.id === 54 && n === 1 && r.push(["回合末：可弃置本牌，保留至多 2 张其他牌。", "Turn end: you may discard this to retain up to 2 other cards."]), e.id === 55 && r.push(n === 1 ? ["激活：发现合作（80）或庄园（81）。被动：勾选 1 格并获得格内资源。", "Activate: discover Cooperation (80) or Estate (81). Passive: mark 1 box and gain its resources."] : ["时间效果：发现袭击与对手（133、134）。激活：勾选 1 格并获得格内资源。", "Time effect: discover Raid and Rival (133, 134). Activate: mark 1 box and gain its resources."]), e.id === 73 && n === 2 && r.push(["可算作 1 或 2 位人物；作为 2 人使用时须同时弃置。", "May count as 1 or 2 people; when used as 2, both must be discarded together."]), [74, 75].includes(e.id) && n === 4 && r.push(["入场：发现海盗（76）。", "When played: discover the Pirate (76)."]), e.id === 76 && n === 4 && r.push(["激活：发现寻宝（93）。", "Activate: discover Treasure Hunt (93)."]), [
		79,
		82,
		83,
		125
	].includes(e.id)) {
		let t = e.id === 125 ? 5 : e.id === 79 ? [
			1,
			2,
			1,
			2
		][n - 1] : n;
		r.push(e.id === 79 && n <= 2 ? [`回合末：可弃置本牌，保留至多 ${t} 位其他人物。`, `Turn end: you may discard this to retain up to ${t} other people.`] : [`回合末：可弃置本牌，保留至多 ${t} 张其他牌。`, `Turn end: you may discard this to retain up to ${t} other cards.`]);
	}
	return e.id === 80 && r.push(n === 1 ? ["激活：弃置 2 位人物，获得 3 自选资源，然后转向。", "Activate: discard 2 people to gain 3 resources of your choice, then turn."] : ["激活：获得 1 自选资源，然后转向。", "Activate: gain 1 resource of your choice, then turn."]), e.id === 81 && n > 1 && r.push([`净化本牌时，可使至多 ${n - 1} 张其他待净化牌免于净化。`, `When purging this, you may save up to ${n - 1} other selected cards from the purge.`]), e.id === 86 && r.push(n === 1 ? ["轮末：为王国中 1 位人物添加金币、武力与骑士贴纸，然后转向。", "Round end: add coin, sword and knight stickers to 1 person in your kingdom, then turn."] : ["轮末：为 1 张建筑添加木材或石材贴纸，以及金属或商品贴纸，然后摧毁本牌。", "Round end: add a wood or stone sticker, and a metal or trade-good sticker, to 1 building; then destroy this."]), e.id === 89 && n === 2 && r.push(["所有建筑额外生产 1 金币。", "All buildings produce 1 extra coin."]), e.id === 89 && n === 4 && r.push(["激活：勾选 1 格，填满后转为监狱。", "Activate: mark 1 box; turn to Prison when full."]), e.id === 91 && n === 1 && r.push(["时间效果：支付下一格的木材费用并勾选，填满后转为方舟。", "Time effect: pay the next box’s wood cost and mark it; turn to the Ark when full."]), e.id === 93 && n === 2 && r.push(["回合末：发现背叛者（94）。", "Turn end: discover the Backstabber (94)."]), e.id === 94 && r.push(n === 1 ? ["入场：弃置 2 位人物。激活：支付 4 武力，摧毁本牌。", "When played: discard 2 people. Activate: pay 4 swords to destroy this."] : ["推进时额外打出 2 张牌。", "Play 2 additional cards whenever you advance."]), e.id === 101 && n === 4 && r.push(["回合末：可保留本牌或另一张场上牌。", "Turn end: you may retain this or 1 other card in play."]), e.id === 102 && n === 3 && r.push(["所有航海牌额外生产 1 金币。", "All seafaring cards produce 1 extra coin."]), e.id === 105 && r.push(n === 4 ? ["激活：忘却本牌，发现卡美洛（106）；或获得 1 自选资源。", "Activate: undiscover this to discover Camelot (106), or gain 1 resource of your choice."] : n === 3 ? ["激活：支付任意 1 资源，获得任意 1 资源。", "Activate: pay any 1 resource to gain any 1 resource."] : [`激活：支付 ${n === 1 ? 2 : 1} 金币，获得 1 自选资源。`, `Activate: pay ${n === 1 ? 2 : 1} coins to gain 1 resource of your choice.`]), e.id === 106 && n === 4 && r.push(["回合末：牌库为空时，可勾选 1 格；每格额外提供 5 声望。", "Turn end: if your deck is empty, you may mark 1 box. Each marked box adds 5 fame."]), e.id === 108 && r.push(["本牌不能被摧毁或净化。", "This card cannot be destroyed or purged."]), e.id === 111 && r.push(n === 4 ? ["时间效果：发现贵族（116）。", "Time effect: discover a noble (116)."] : ["生产后：划去本牌 1 点生产。", "After producing: cross out 1 production on this card."]), e.id === 112 && n < 4 && r.push([`时间效果：支付 2 金币，发现 ${112 + n} 号马匹。`, `Time effect: pay 2 coins to discover horse ${112 + n}.`]), e.id === 116 && n === 1 && r.push(["入场：弃置任意 1 张场上牌。", "When played: discard any 1 card in play."]), e.id === 117 && r.push(["被动：支付 3 商品，获得任意 1 资源。", "Passive: pay 3 trade goods to gain any 1 resource."]), e.id === 120 && r.push(n === 4 ? ["激活：获得 1 自选资源。", "Activate: gain 1 resource of your choice."] : ["激活：获得 3 自选资源，然后转向。", "Activate: gain 3 resources of your choice, then turn."]), e.id === 121 && n === 4 && r.push(["激活：弃置另一位声望至少为 5 的人物并勾选 1 格，每格提供 3 声望。", "Activate: discard another person with at least 5 fame to mark 1 box. Each marked box gives 3 fame."]), e.id === 127 && n === 3 && r.push(["被动：弃置 1 位人物，获得 2 商品。", "Passive: discard 1 person to gain 2 trade goods."]), e.id === 128 && n === 4 && r.push(["时间效果：弃置 1 位人物并支付 3 石材，勾选 1 格；每格提供 7 声望。", "Time effect: discard 1 person and pay 3 stone to mark 1 box. Each marked box gives 7 fame."]), e.id === 129 && n < 4 && r.push([[
		"升级本牌时：为 1 张场上土地添加金币贴纸。",
		"升级本牌时：为 1 张场上牌添加其已有的一种资源贴纸。",
		"升级本牌时：为 1 张场上土地添加留场贴纸。"
	][n - 1], [
		"When upgrading this: add a coin sticker to 1 land in play.",
		"When upgrading this: boost 1 existing production on 1 card in play.",
		"When upgrading this: add a stay-in-play sticker to 1 land in play."
	][n - 1]]), e.id === 130 && n === 2 && r.push(["被动：可查看牌库顶的 2 张牌。", "Passive: you may look at the top 2 cards of your deck."]), e.id === 133 && r.push([`激活：获得 ${[
		1,
		2,
		2,
		3
	][n - 1]} 自选资源。`, `Activate: gain ${[
		1,
		2,
		2,
		3
	][n - 1]} resources of your choice.`]), e.id === 134 && r.push(n === 1 ? ["尼姆罗德领主仍在王国中时，本牌不能被摧毁。激活：弃置该领主并支付所选格费用，勾选该格；填满后转向。每个未勾格减少 5 声望。", "Cannot be destroyed while Lord Nimrod remains in your kingdom. Activate: discard him and pay a box’s cost to mark it; turn when full. Lose 5 fame per unmarked box."] : ["激活：获得另一位场上人物的产出。", "Activate: gain another person’s production in play."]), e.id === 136 && r.push([[
		"本轮所有友好牌额外生产 1 金币；轮末转向。",
		"本轮回合末可保留 1 张牌；轮末转向。",
		"人物入场且场上已有其他人物时，勾选 1 格；轮末转向。",
		"轮末：按起义已勾格数，在王国友好牌上划去等量生产，然后摧毁本牌。"
	][n - 1], [
		"All friendly cards produce 1 extra coin this round; turn at round end.",
		"You may retain 1 card at each turn end this round; turn at round end.",
		"Mark 1 box when a person is played with another person in play; turn at round end.",
		"Round end: cross out 1 production on friendly kingdom cards per marked Uprising box, then destroy this."
	][n - 1]]), e.id === 137 && r.push([[
		"每回合可获得 3 金币一次；轮末转向。",
		"时间效果：弃置 2 张建筑，为 1 张场上土地添加金币贴纸；轮末转向。",
		"土地生产时可将金币产出改为商品；轮末转向。",
		"轮末：摧毁王国中 1 张生产金币的牌，然后摧毁本牌。"
	][n - 1], [
		"Gain 3 coins once per turn; turn at round end.",
		"Time effect: discard 2 buildings to add a coin sticker to 1 land in play; turn at round end.",
		"Lands may produce trade goods instead of coins; turn at round end.",
		"Round end: destroy 1 coin-producing card in your kingdom, then destroy this."
	][n - 1]]), e.id === 138 && n < 4 && r.push([[
		"回合末：保留所有土地；轮末转向。",
		"人物入场时，勾选 1 格或弃置 2 张友好牌；填满时弃置整个牌库。轮末转向。",
		"回合末：若没有武力，划去 1 张场上牌的 1 点生产。轮末：为 1 张王国友好牌添加资源贴纸，然后转向。"
	][n - 1], [
		"Turn end: retain all lands; turn at round end.",
		"When a person is played, mark 1 box or discard 2 friendly cards. Discard the whole deck when full; turn at round end.",
		"Turn end: if you have no swords, cross out 1 production on a card in play. Round end: add a resource sticker to 1 friendly kingdom card, then turn."
	][n - 1]]), e.id === 123 && n === 4 && r.push(["本牌即将弃置时，可以弃置 2 面城墙代替。", "When this card would be discarded, you may discard 2 walls instead."]), e.id === 32 && n === 1 && r.push(["所有人物额外生产 1 金币。", "All people produce 1 extra coin."]), e.id === 38 && r.push(n === 1 ? ["整个王国每位人物提供 2 声望。", "Gain 2 fame per person in your kingdom."] : ["整个王国每点武力生产提供 2 声望。", "Gain 2 fame per sword production in your kingdom."]), e.id === 39 && r.push(n === 1 ? ["王国每少于 75 张非永久牌，减少 2 声望。", "Lose 2 fame for each non-permanent card fewer than 75."] : ["王国每张没有声望的非永久牌使本牌减少 1 声望。", "Lose 1 fame per non-permanent card with no fame in your kingdom."]), e.id === 40 && r.push(n === 1 ? ["王国没有敌人时，额外获得 25 声望。", "Gain 25 extra fame if your kingdom contains no enemies."] : ["王国商品生产总量达到 10 时，额外获得 25 声望。", "Gain 25 extra fame if your kingdom has at least 10 trade-good production."]), e.id === 44 && r.push(n === 1 ? ["入场：弃置牌库顶 3 张牌，然后转向。", "When played: discard the top 3 cards, then turn."] : ["不能推进；土地额外生产 2 金币。回合末本牌重置。", "You cannot advance. Lands produce 2 extra coins. Reset this card at turn end."]), e.id === 53 && r.push(n === 1 ? ["支付 4 武力可摧毁；或弃置 3 人物使其转向。回合末发现 2 张牌，然后转向。", "Pay 4 swords to destroy it, or discard 3 people to turn it. Turn end: discover 2 cards, then turn."] : ["支付 3 武力，或摧毁 1 人物，可摧毁本牌。回合末发现 2 张牌，然后摧毁本牌。", "Pay 3 swords, or destroy 1 person, to destroy this card. Turn end: discover 2 cards, then destroy it."]), e.id === 56 && n === 1 && r.push(["轮末：摧毁王国中 2 位人物，然后转向。", "Round end: destroy 2 people in your kingdom, then turn."]), e.id === 58 && n === 1 && r.push(["轮末：摧毁王国中 1 张建筑，然后转向。", "Round end: destroy 1 building in your kingdom, then turn."]), e.id === 65 && r.push(n === 1 ? ["轮末：摧毁王国中 3 张友好非永久牌，然后转向。", "Round end: destroy 3 friendly non-permanent cards in your kingdom, then turn."] : ["阻挡至多 5 张建筑。轮末摧毁本牌，并选择摧毁 1 张被阻挡建筑或 2 张其他友好牌。", "Block up to 5 buildings. Round end: destroy this card and 1 blocked building, or 2 other friendly cards."]), e.id === 92 && r.push(["前三次入场时，依次命名并添加指定贴纸；各次入场记录永久保留。", "On the first three plays, name this person and add the indicated stickers. Play history is permanent."]), e.id === 104 && r.push([`激活：${n === 1 ? "支付 2 金币，" : ""}支付另一张牌的升级费用，使其升级而不结束回合。`, `Activate: ${n === 1 ? "pay 2 coins, then " : ""}pay another card’s upgrade cost to upgrade it without ending the turn.`]), e.id === 110 && n >= 3 && r.push([`激活：将${n === 3 ? "场上" : "场上或弃牌堆"}1 张其他牌放到牌库底。牌库须非空。`, `Activate: put 1 other card from ${n === 3 ? "play" : "play or discard"} on the deck bottom. The deck must be nonempty.`]), e.id === 118 && r.push(n <= 2 ? ["时间效果：免费升级 1 位人物，本牌转向，然后结束回合。", "Time effect: upgrade 1 person for free, turn this card, then end the turn."] : ["时间效果：给 1 位人物增加资源生产；第三阶段随后转向，第四阶段仅可使用一次。", "Time effect: add resource production to 1 person. Turn after stage 3; usable once at stage 4."]), e.id === 125 && n === 4 && r.push(["时间效果：支付 4 商品，勾选 1 格；每格仅在净化时额外提供 10 声望。", "Time effect: pay 4 trade goods to mark a box. Each marked box adds 10 fame only when purged."]), e.id === 135 && n < 4 && r.push(["被动：支付 4 武力，使本阶段升级武力费用永久降低 1。升至第四阶段时写入 20 声望，最多 9 次。", "Passive: pay 4 swords to permanently reduce this stage’s sword upgrade cost by 1. Upgrading to stage 4 records 20 fame, up to 9 times."]), r;
}
//#endregion
//#region src/games/kingdomlegacy/card.tsx
var bt = (e) => `./games/kingdomlegacy/${e}`, xt = {
	25: "sword",
	26: "coin",
	27: "tradegood",
	88: "stone",
	90: "metal",
	91: "wood"
}, St = {
	land: "games.kingdomlegacy.typeLand",
	building: "games.kingdomlegacy.typeBuilding",
	person: "games.kingdomlegacy.typePerson",
	livestock: "games.kingdomlegacy.typeLivestock",
	seafaring: "games.kingdomlegacy.typeSeafaring",
	permanent: "games.kingdomlegacy.typePermanent",
	enemy: "games.kingdomlegacy.typeEnemy",
	event: "games.kingdomlegacy.typeEvent",
	knight: "games.kingdomlegacy.typeKnight",
	horse: "games.kingdomlegacy.typeHorse",
	wall: "games.kingdomlegacy.typeWall",
	item: "games.kingdomlegacy.typeItem",
	invention: "games.kingdomlegacy.typeInvention",
	state: "games.kingdomlegacy.typeState",
	loot: "games.kingdomlegacy.typeLoot",
	scroll: "games.kingdomlegacy.typeScroll",
	elder: "games.kingdomlegacy.typeElder",
	ship: "games.kingdomlegacy.typeShip",
	goal: "games.kingdomlegacy.typeGoal",
	artifact: "games.kingdomlegacy.typeArtifact",
	lady: "games.kingdomlegacy.typeLady"
};
function Ct({ resource: e }) {
	return /* @__PURE__ */ v("img", {
		className: "kl-resource-icon",
		src: bt(`icons/${e}.svg`),
		alt: "",
		draggable: !1
	});
}
function wt({ bag: e, zero: t = !1 }) {
	let n = c((e) => e.locale) === "zh" ? 0 : 1;
	return /* @__PURE__ */ v("span", {
		className: "kl-resource-group",
		children: x.filter((n) => t || e[n]).map((t) => /* @__PURE__ */ y("span", {
			className: "kl-resource",
			title: S[t][n],
			children: [
				/* @__PURE__ */ v(Ct, { resource: t }),
				/* @__PURE__ */ v("b", { children: e[t] ?? 0 }),
				/* @__PURE__ */ v("span", {
					className: "kl-sr",
					children: S[t][n]
				})
			]
		}, t))
	});
}
function $({ card: e, detail: t = !1, production: n, fame: r }) {
	let i = l(), a = c((e) => e.locale) === "zh" ? 0 : 1, o = w(e.id, e.stage), s = A(e), u = o.negative ? "negative" : o.types.find((e) => [
		"land",
		"building",
		"person",
		"livestock",
		"seafaring"
	].includes(e)) ?? "other", d = r ?? o.fame + s.medals.reduce((e, t) => e + t, 0) + s.stickers.filter((e) => e === "fame2").length * 2 + s.stickers.filter((e) => e === "fame5").length * 5, f = yt(e), p = xt[e.id], m = o.boxes.find((e, t) => !s.boxes.includes(t));
	return /* @__PURE__ */ y("div", {
		className: "kl-card",
		"data-category": u,
		"data-detail": t,
		children: [
			/* @__PURE__ */ y("div", {
				className: "kl-card-picture",
				children: [/* @__PURE__ */ v("img", {
					src: bt(`art/${o.key}.svg`),
					alt: "",
					draggable: !1
				}), /* @__PURE__ */ y("span", {
					className: "kl-serial",
					children: [String(e.id).padStart(3, "0"), /* @__PURE__ */ v("small", { children: e.stage })]
				})]
			}),
			/* @__PURE__ */ y("div", {
				className: "kl-card-ribbon",
				children: [/* @__PURE__ */ v("strong", { children: e.name || T(e.id, e.stage)[a] }), /* @__PURE__ */ v("span", { children: o.types.map((e) => St[e] ? i(St[e]) : e).join(" · ") })]
			}),
			/* @__PURE__ */ y("div", {
				className: "kl-card-content",
				children: [
					e.zone === "blocked" && /* @__PURE__ */ v("strong", {
						className: "kl-blocked-tag",
						children: i("games.kingdomlegacy.blockedBy", { n: String(e.blockedBy).padStart(3, "0") })
					}),
					/* @__PURE__ */ y("div", {
						className: "kl-card-production",
						children: [(n ?? o.production.map((t, n) => B(e, n))).map((e, t) => /* @__PURE__ */ y("span", {
							className: "kl-production-option",
							children: [t > 0 && /* @__PURE__ */ v("small", { children: i("games.kingdomlegacy.or") }), /* @__PURE__ */ v(wt, { bag: e })]
						}, t)), d !== 0 && /* @__PURE__ */ v("span", {
							className: "kl-medal",
							title: i("games.kingdomlegacy.fame"),
							children: d
						})]
					}),
					f.length > 0 && /* @__PURE__ */ v("div", {
						className: "kl-card-effects",
						children: f.map((e, t) => /* @__PURE__ */ v("p", { children: e[a] }, t))
					}),
					o.boxes.length > 0 && /* @__PURE__ */ y("span", {
						className: "kl-track-summary",
						children: [/* @__PURE__ */ y("span", { children: [
							e.id === 109 ? s.medals.length : s.boxes.length,
							" / ",
							o.boxes.length,
							" ✓"
						] }), m?.cost ? /* @__PURE__ */ y("span", { children: [
							i("games.kingdomlegacy.nextBox"),
							m.cost,
							p && /* @__PURE__ */ v(Ct, { resource: p })
						] }) : null]
					}),
					o.boxes.length > 0 && /* @__PURE__ */ v("div", {
						className: "kl-boxes",
						"aria-label": i("games.kingdomlegacy.checkboxes"),
						children: o.boxes.map((t, n) => {
							let r = ce(t.text), o = e.id === 109 ? n < s.medals.length : s.boxes.includes(n);
							return /* @__PURE__ */ y("span", {
								"data-checked": o,
								title: se(t.text)[a] || String(n + 1),
								children: [
									t.cost > 0 && /* @__PURE__ */ y("span", {
										className: "kl-box-cost",
										children: [
											p && /* @__PURE__ */ v(Ct, { resource: p }),
											e.id === 87 && /* @__PURE__ */ v("small", { children: i("games.kingdomlegacy.typePerson") }),
											t.cost
										]
									}),
									Object.keys(r).length > 0 ? /* @__PURE__ */ v(wt, { bag: r }) : t.text.includes("fame") ? /* @__PURE__ */ y("small", {
										className: "kl-box-fame",
										children: [t.text.match(/\d+/)?.[0], "★"]
									}) : t.text.includes("arrow") ? "↻" : e.id === 109 ? s.medals[n] ?? "·" : t.text === "*" ? /* @__PURE__ */ v(Ct, { resource: "wood" }) : t.cost ? null : "·",
									o && /* @__PURE__ */ v("b", {
										className: "kl-box-check",
										children: "✓"
									})
								]
							}, n);
						})
					}),
					s.stickers.length > 0 && /* @__PURE__ */ v("span", {
						className: "kl-stickers",
						title: i("games.kingdomlegacy.addedStickers"),
						children: s.stickers.map((e, t) => x.includes(e) ? /* @__PURE__ */ v(Ct, { resource: e }, t) : /* @__PURE__ */ v("small", { children: e === "stay" ? "∞" : e === "fame2" ? "2★" : e === "fame5" ? "5★" : e === "knight" ? i("games.kingdomlegacy.typeKnight") : "★" }, t))
					}),
					o.upgrades.length > 0 && /* @__PURE__ */ v("div", {
						className: "kl-card-upgrades",
						children: o.upgrades.map((t, n) => /* @__PURE__ */ y("span", { children: [
							/* @__PURE__ */ y("b", { children: ["↻ ", T(e.id, t.to)[a]] }),
							/* @__PURE__ */ v(wt, { bag: je(e, t.cost) }),
							t.extra.map(([e, t]) => /* @__PURE__ */ y("small", { children: [
								t,
								" ",
								St[e] ? i(St[e]) : e === "stone_bridge" ? i("games.kingdomlegacy.stoneBridge") : e
							] }, e))
						] }, n))
					})
				]
			})
		]
	});
}
function Tt({ card: e, selected: t = !1, target: n = !1, ghost: r = !1, onClick: i, production: a, fame: s }) {
	let { ref: c, hidden: l } = o(r ? null : `card:${e.id}`), { ref: u } = o(`${r ? "origin" : "live"}:${e.id}`);
	return /* @__PURE__ */ v("div", {
		className: "kl-card-slot",
		ref: c,
		style: { visibility: r || l ? "hidden" : void 0 },
		children: /* @__PURE__ */ y("button", {
			className: "kl-card-hit",
			ref: u,
			type: "button",
			"data-selected": t,
			"data-blocked": e.zone === "blocked",
			disabled: r,
			"aria-pressed": t,
			onClick: i,
			children: [/* @__PURE__ */ v($, {
				card: e,
				production: a,
				fame: s
			}), n && /* @__PURE__ */ y("svg", {
				className: "kl-target",
				viewBox: "0 0 100 100",
				preserveAspectRatio: "none",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ v("rect", {
					x: "1",
					y: "1",
					width: "98",
					height: "98",
					rx: "3",
					fill: "none",
					vectorEffect: "non-scaling-stroke",
					stroke: "white",
					strokeWidth: "5"
				}), /* @__PURE__ */ v("rect", {
					x: "1",
					y: "1",
					width: "98",
					height: "98",
					rx: "3",
					fill: "none",
					vectorEffect: "non-scaling-stroke",
					stroke: "#176481",
					strokeWidth: "3",
					strokeDasharray: "8 6",
					children: /* @__PURE__ */ v("animate", {
						attributeName: "stroke-dashoffset",
						from: "0",
						to: "-28",
						dur: "1s",
						repeatCount: "indefinite"
					})
				})]
			})]
		})
	});
}
//#endregion
//#region src/games/kingdomlegacy/view-player.tsx
var Et = {
	discard: "games.kingdomlegacy.discard",
	history: "games.kingdomlegacy.history",
	stickers: "games.kingdomlegacy.stickers"
}, Dt = {
	stay: "games.kingdomlegacy.stickerStay",
	fame2: "games.kingdomlegacy.stickerFame2",
	fame5: "games.kingdomlegacy.stickerFame5",
	blank: "games.kingdomlegacy.stickerBlank",
	chapter: "games.kingdomlegacy.stickerChapter",
	knight: "games.kingdomlegacy.typeKnight"
};
function Ot({ title: e, onClose: t, children: n, footer: r }) {
	let i = l();
	return /* @__PURE__ */ v("div", {
		className: "kl-modal",
		children: /* @__PURE__ */ v(h, {
			open: !0,
			onClose: t,
			label: e,
			tall: !0,
			compact: !0,
			children: /* @__PURE__ */ y("section", {
				className: "kl-panel",
				children: [
					/* @__PURE__ */ y("header", { children: [/* @__PURE__ */ v("h2", { children: e }), t && /* @__PURE__ */ v("button", {
						type: "button",
						onClick: t,
						"aria-label": i("games.kingdomlegacy.close"),
						children: /* @__PURE__ */ v(u, { size: 22 })
					})] }),
					/* @__PURE__ */ v("div", {
						className: "kl-panel-scroll",
						children: n
					}),
					r && /* @__PURE__ */ v("footer", { children: r })
				]
			})
		})
	});
}
function kt({ checkpoint: e }) {
	let t = l(), [n, r] = a(null), [i, o] = a(!1), [s, c] = a(!1);
	async function u(t = !1) {
		if (e && !i) {
			o(!0);
			try {
				let n = await gt();
				if (!t && n && n.campaignId !== e.campaignId) {
					c(!0);
					return;
				}
				let i = await _t(e);
				r({
					campaignId: e.campaignId,
					serial: e.serial,
					key: i === "saved" ? "games.kingdomlegacy.saved" : "games.kingdomlegacy.saveNewer"
				}), c(!1);
			} catch {
				r({
					campaignId: e.campaignId,
					serial: e.serial,
					key: "games.kingdomlegacy.saveError"
				});
			} finally {
				o(!1);
			}
		}
	}
	return /* @__PURE__ */ y("div", {
		className: "kl-save",
		children: [
			/* @__PURE__ */ y("button", {
				type: "button",
				"aria-label": t("games.kingdomlegacy.save"),
				disabled: !e || i,
				onClick: () => void u(),
				children: [/* @__PURE__ */ v(d, { size: 18 }), /* @__PURE__ */ v("span", { children: t(i ? "games.kingdomlegacy.saving" : "games.kingdomlegacy.save") })]
			}),
			n && n.campaignId === e?.campaignId && n.serial === e.serial && /* @__PURE__ */ v("span", {
				className: "kl-save-status",
				role: "status",
				children: t(n.key)
			}),
			s && /* @__PURE__ */ v(Ot, {
				title: t("games.kingdomlegacy.archive"),
				onClose: () => c(!1),
				footer: /* @__PURE__ */ y(te, { children: [/* @__PURE__ */ v("button", {
					type: "button",
					onClick: () => c(!1),
					children: t("games.kingdomlegacy.cancel")
				}), /* @__PURE__ */ v("button", {
					type: "button",
					className: "danger-stripes",
					disabled: i,
					onClick: () => void u(!0),
					children: t("games.kingdomlegacy.confirm")
				})] }),
				children: /* @__PURE__ */ v("p", { children: t("games.kingdomlegacy.confirmNew") })
			})
		]
	});
}
function At({ choice: e, onChoose: t }) {
	let n = c((e) => e.locale) === "zh" ? 0 : 1, r = l();
	return e.danger ? /* @__PURE__ */ v(m, {
		label: e.label[n],
		confirmLabel: r("games.kingdomlegacy.destroyConfirm"),
		onConfirm: () => t(e),
		className: "kl-choice"
	}) : /* @__PURE__ */ y("button", {
		className: "kl-choice",
		type: "button",
		"data-kind": e.kind,
		onClick: () => t(e),
		children: [
			e.key.startsWith("resource:") && /* @__PURE__ */ v(Ct, { resource: e.key.slice(9) }),
			/* @__PURE__ */ v("span", { children: e.label[n] }),
			/* @__PURE__ */ v(p, { size: 17 })
		]
	});
}
function jt({ name: e, children: t, count: n, onClick: r, anchor: i }) {
	let { ref: a } = o(i);
	return /* @__PURE__ */ y("div", {
		className: "kl-pile",
		ref: a,
		children: [/* @__PURE__ */ y("div", {
			className: "kl-pile-heading",
			children: [/* @__PURE__ */ v("span", { children: e }), /* @__PURE__ */ v("b", { children: n })]
		}), /* @__PURE__ */ v("button", {
			className: "kl-pile-card",
			type: "button",
			onClick: r,
			disabled: !r,
			children: t ?? /* @__PURE__ */ y("span", {
				className: "kl-card-back",
				children: [/* @__PURE__ */ v("span", { children: "KL" }), /* @__PURE__ */ v("small", { children: n })]
			})
		})]
	});
}
function Mt(e) {
	return /* @__PURE__ */ v(Nt, {
		pub: e.public,
		checkpoint: e.private?.checkpoint,
		send: e.send,
		active: e.myRid === e.public.owner
	});
}
function Nt({ pub: e, checkpoint: t, send: r, active: i = !0, readOnly: u = !1, resultButton: d }) {
	let p = l(), m = c((e) => e.locale) === "zh" ? 0 : 1, [h, g] = a(null), [_, b] = a(null), [ne, re] = a(""), { ref: ie } = o("archive"), [ae, oe] = a(e), [w, se] = a(e);
	ae.serial !== e.serial && (se(ae), oe(e)), n(() => {
		let t = window.setTimeout(() => se(e), 460);
		return () => window.clearTimeout(t);
	}, [e]);
	let ce = [...e.cards, ...e.offered], E = e.cards.filter((e) => e.zone === "play" || e.zone === "blocked"), le = e.cards.filter((e) => e.zone === "permanent"), ue = w.cards.filter((e) => ["play", "blocked"].includes(e.zone) && !E.some((t) => t.id === e.id)), de = w.cards.filter((e) => e.zone === "permanent" && !le.some((t) => t.id === e.id)), fe = [...E, ...ue].sort((e, t) => e.id - t.id), D = ce.find((e) => e.id === h) ?? e.top.find((e) => e.id === h), pe = i && !u, me = pe ? e.choices : [], he = me.filter((e) => e.card === h), O = me.filter((e) => e.card === void 0), ge = ce.filter((t) => ![
		"play",
		"blocked",
		"permanent"
	].includes(t.zone) && (e.offered.some((e) => e.id === t.id) || e.prompt && me.some((e) => e.kind === "target" && e.card === t.id))), k = u ? null : e.prompt, A = !!(D || _ || e.naming && !u || pe && k && O.length > 2), j = D && (!e.top.some((e) => e.id === D.id) || e.cards.some((e) => e.id === D.id));
	function M(e) {
		r({
			type: "choose",
			key: e.key
		}), g(null);
	}
	let N = (t, n = !1) => /* @__PURE__ */ v(Tt, {
		card: t,
		ghost: n,
		selected: h === t.id,
		target: !n && me.some((e) => e.card === t.id),
		onClick: () => g(t.id),
		production: e.values[t.id]?.production,
		fame: e.values[t.id]?.fame
	}, t.id), P = e.top[0], _e = e.cards.find((t) => t.id === e.discard.at(-1));
	return /* @__PURE__ */ y("div", {
		className: "kl-root",
		children: [
			/* @__PURE__ */ v("div", {
				className: "kl-table-base",
				inert: A,
				children: /* @__PURE__ */ v(ee, {
					adaptive: !0,
					scroll: !1,
					className: "kl-screen",
					actionsHeight: "kl-actions-height",
					banner: /* @__PURE__ */ y("div", {
						className: "kl-banner",
						children: [/* @__PURE__ */ y("header", {
							className: "kl-header",
							children: [
								/* @__PURE__ */ y("div", {
									className: "kl-brand",
									children: [/* @__PURE__ */ v("span", { children: "KL" }), /* @__PURE__ */ v("h1", { children: e.chapter === 0 ? p("games.kingdomlegacy.chapterBase") : T(e.chapter, 1)[m] })]
								}),
								/* @__PURE__ */ y("div", {
									className: "kl-time",
									children: [/* @__PURE__ */ v("b", { children: p("games.kingdomlegacy.round", { n: e.round }) }), /* @__PURE__ */ v("span", { children: p("games.kingdomlegacy.turn", { n: e.turn }) })]
								}),
								/* @__PURE__ */ y("div", {
									className: "kl-fame",
									children: [/* @__PURE__ */ v("span", { children: p("games.kingdomlegacy.fame") }), /* @__PURE__ */ v(s, { value: e.fame })]
								})
							]
						}), /* @__PURE__ */ v("div", {
							className: "kl-treasury",
							children: x.map((t) => /* @__PURE__ */ y("div", {
								className: "kl-treasury-resource",
								title: S[t][m],
								children: [
									/* @__PURE__ */ v(Ct, { resource: t }),
									/* @__PURE__ */ v(s, { value: e.resources[t] ?? 0 }),
									/* @__PURE__ */ v("span", { children: S[t][m] })
								]
							}, t))
						})]
					}),
					actions: /* @__PURE__ */ v("div", {
						className: "kl-actions",
						children: u ? d : /* @__PURE__ */ y(te, { children: [/* @__PURE__ */ v(kt, { checkpoint: t }), /* @__PURE__ */ y("div", {
							className: "kl-control-buttons",
							children: [(O.length <= 2 ? O : []).map((e) => /* @__PURE__ */ v(At, {
								choice: e,
								onChoose: M
							}, e.key)), !O.length && /* @__PURE__ */ v("span", {
								role: "status",
								children: p(i ? k ? "games.kingdomlegacy.choose" : "games.kingdomlegacy.settling" : "games.kingdomlegacy.wait")
							})]
						})] })
					}),
					overlay: k ? /* @__PURE__ */ v("div", {
						className: "kl-prompt",
						role: "status",
						children: k[m]
					}) : void 0,
					children: /* @__PURE__ */ y("div", {
						className: "kl-table",
						children: [/* @__PURE__ */ y("aside", {
							className: "kl-piles",
							children: [
								/* @__PURE__ */ v(jt, {
									name: p("games.kingdomlegacy.deck"),
									count: e.deckCount,
									anchor: "deck",
									onClick: P ? () => g(P.id) : void 0,
									children: P && /* @__PURE__ */ v($, {
										card: P,
										production: e.values[P.id]?.production,
										fame: e.values[P.id]?.fame
									})
								}),
								/* @__PURE__ */ v(jt, {
									name: p("games.kingdomlegacy.discard"),
									count: e.discard.length,
									anchor: "discard",
									onClick: () => b("discard"),
									children: _e && /* @__PURE__ */ v($, { card: _e })
								}),
								/* @__PURE__ */ v("button", {
									type: "button",
									className: "kl-archive-entry",
									onClick: () => b("stickers"),
									children: p("games.kingdomlegacy.stickers")
								})
							]
						}), /* @__PURE__ */ y("div", {
							className: "kl-kingdom",
							children: [/* @__PURE__ */ y("section", {
								className: "kl-permanents",
								children: [/* @__PURE__ */ y("div", {
									className: "kl-section-label",
									children: [
										/* @__PURE__ */ v("h2", { children: p("games.kingdomlegacy.permanent") }),
										/* @__PURE__ */ v("span", { children: le.length }),
										/* @__PURE__ */ v("button", {
											type: "button",
											onClick: () => b("history"),
											ref: ie,
											"aria-label": p("games.kingdomlegacy.history"),
											children: /* @__PURE__ */ v(f, { size: 20 })
										})
									]
								}), /* @__PURE__ */ y("div", {
									className: "kl-permanent-scroll",
									children: [
										le.map((e) => N(e)),
										de.map((e) => N(e, !0)),
										!le.length && /* @__PURE__ */ v("span", {
											className: "kl-empty-permanents",
											children: "—"
										})
									]
								})]
							}), /* @__PURE__ */ y("section", {
								className: "kl-field",
								children: [/* @__PURE__ */ y("div", {
									className: "kl-section-label",
									children: [/* @__PURE__ */ v("h2", { children: ge.length ? p("games.kingdomlegacy.choose") : p("games.kingdomlegacy.play") }), /* @__PURE__ */ v("span", { children: ge.length || E.length })]
								}), /* @__PURE__ */ y("div", {
									className: "kl-field-scroll",
									children: [/* @__PURE__ */ y("div", {
										className: "kl-card-grid",
										children: [fe.map((e) => N(e, ue.some((t) => t.id === e.id))), ge.map((e) => N(e))]
									}), e.phase === "chapterEnd" && /* @__PURE__ */ y("div", {
										className: "kl-chapter",
										children: [
											/* @__PURE__ */ v("h2", { children: p("games.kingdomlegacy.chapterEnd") }),
											/* @__PURE__ */ v("strong", { children: p("games.kingdomlegacy.score", { n: e.fame }) }),
											me.filter((e) => e.card !== void 0).map((e) => /* @__PURE__ */ v(At, {
												choice: e,
												onChoose: M
											}, e.key))
										]
									})]
								})]
							})]
						})]
					})
				})
			}),
			D && /* @__PURE__ */ y(Ot, {
				title: D.name || T(D.id, D.stage)[m],
				onClose: () => g(null),
				footer: he.length > 0 ? /* @__PURE__ */ v("div", {
					className: "kl-card-actions",
					children: he.map((e) => /* @__PURE__ */ v(At, {
						choice: e,
						onChoose: M
					}, e.key))
				}) : void 0,
				children: [
					/* @__PURE__ */ v($, {
						card: D,
						detail: !0,
						production: e.values[D.id]?.production,
						fame: e.values[D.id]?.fame
					}),
					/* @__PURE__ */ v(wt, {
						bag: e.resources,
						zero: !0
					}),
					!j && e.top.length > 1 && /* @__PURE__ */ v("div", {
						className: "kl-card-actions",
						children: e.top.map((e, t) => /* @__PURE__ */ y("button", {
							type: "button",
							className: "kl-choice",
							onClick: () => g(e.id),
							children: [p("games.kingdomlegacy.deckPosition", { n: t + 1 }), T(e.id, e.stage)[m]]
						}, e.id))
					}),
					j && /* @__PURE__ */ y("details", {
						className: "kl-stage-details",
						children: [/* @__PURE__ */ v("summary", { children: p("games.kingdomlegacy.inspect") }), Object.keys(C[D.id].stages).map(Number).filter((e) => e !== D.stage).map((e) => /* @__PURE__ */ v($, {
							card: {
								...D,
								stage: e
							},
							detail: !0
						}, e))]
					})
				]
			}),
			_ && /* @__PURE__ */ v(Ot, {
				title: p(Et[_]),
				onClose: () => b(null),
				children: _ === "discard" ? /* @__PURE__ */ v("div", {
					className: "kl-discard-grid",
					children: e.discard.map((t) => e.cards.find((e) => e.id === t)).filter((e) => !!e).map((e) => /* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => {
							b(null), g(e.id);
						},
						children: /* @__PURE__ */ v($, { card: e })
					}, e.id))
				}) : _ === "history" ? /* @__PURE__ */ v("ol", {
					className: "kl-chronicle",
					children: e.log.map((e, t) => /* @__PURE__ */ v("li", { children: e[m] }, t))
				}) : /* @__PURE__ */ v("div", {
					className: "kl-sticker-inventory",
					children: Object.entries(e.stickers).map(([e, t]) => /* @__PURE__ */ y("div", { children: [x.includes(e) ? /* @__PURE__ */ y(te, { children: [/* @__PURE__ */ v(Ct, { resource: e }), /* @__PURE__ */ v("span", { children: S[e][m] })] }) : /* @__PURE__ */ v("span", { children: Dt[e] ? p(Dt[e]) : e }), /* @__PURE__ */ v("b", { children: t })] }, e))
				})
			}),
			pe && k && O.length > 2 && /* @__PURE__ */ v(Ot, {
				title: k[m],
				children: /* @__PURE__ */ v("div", {
					className: "kl-card-actions",
					children: O.map((e) => /* @__PURE__ */ v(At, {
						choice: e,
						onChoose: M
					}, e.key))
				})
			}),
			e.naming && !u && /* @__PURE__ */ v(Ot, {
				title: p("games.kingdomlegacy.nameStranger"),
				footer: /* @__PURE__ */ v("button", {
					type: "button",
					disabled: !ne.trim() || !pe,
					onClick: () => {
						r({
							type: "name",
							value: ne.trim()
						}), re("");
					},
					children: p("games.kingdomlegacy.nameConfirm")
				}),
				children: /* @__PURE__ */ v("input", {
					className: "kl-name-input",
					"aria-label": p("games.kingdomlegacy.nameStranger"),
					maxLength: 40,
					value: ne,
					onChange: (e) => re(e.target.value)
				})
			})
		]
	});
}
//#endregion
//#region src/games/kingdomlegacy/bot.ts
var Pt = (e, t) => {
	let n = e.public;
	if (n.owner !== t.rid || n.phase === "done") return null;
	if (n.naming) return { action: {
		type: "name",
		value: "Rowan"
	} };
	if (!n.choices.length) return null;
	let r = `${n.campaignId}:${n.chapter}:${n.round}:${n.turn}`, i = t.memory, a = i?.turn === r ? { ...i.used } : {}, o = [
		...n.cards,
		...n.top,
		...n.offered
	], s = (e) => {
		let t = o.find((t) => t.id === e);
		return t ? (n.values[e]?.fame ?? 0) * 2 + Math.max(0, ...(n.values[e]?.production ?? []).map(E)) * 3 + (w(t.id, t.stage).negative ? -15 : 0) : 0;
	}, c = (e) => {
		let t = a[e.key] ?? 0;
		if (e.key === "restart") return -1e3;
		if (e.key.startsWith("chapter:") || e.key === "continue") return 100;
		if (e.key === "finishCampaign") return 0;
		if (e.key === "skip") return -5;
		if ([
			"selectionDone",
			"markDone",
			"guildDone"
		].includes(e.key)) return -2;
		if (e.key === "timeEnd") return -1;
		if (e.key === "princessPay") return 30;
		if (e.key === "princessTurn") return -10;
		if (e.key.startsWith("resource:") || e.key.startsWith("sticker:")) {
			let t = e.key.split(":")[1];
			return t === "fame5" || t === "stay" ? 10 : t === "coin" ? 2 : +(t === "wood");
		}
		if (n.prompt) return e.card && e.key.startsWith("target:") ? e.danger ? -s(e.card) : s(e.card) : 4 - t * 2;
		if (e.kind === "upgrade") {
			let t = o.find((t) => t.id === e.card), n = w(t.id, t.stage).upgrades[Number(e.key.split(":")[2])];
			return 30 + (n ? w(t.id, n.to).fame * 2 : 0);
		}
		return e.kind === "produce" ? 8 + E(n.values[e.card]?.production[Number(e.key.split(":")[2])] ?? {}) : e.kind === "effect" || /^(window|priest|school):/.test(e.key) ? (e.key.includes(":defeat") ? 35 : 7) - t * 30 : e.key === "advance" ? 3 : e.key === "pass" ? 0 : 5 - t * 30;
	}, l = n.choices.map((e, t) => ({
		option: e,
		i: t,
		score: c(e)
	})).sort((e, t) => t.score - e.score || e.i - t.i)[0].option;
	return a[l.key] = (a[l.key] ?? 0) + 1, {
		action: {
			type: "choose",
			key: l.key
		},
		memory: {
			turn: r,
			used: a
		}
	};
}, Ft = (e, t, n) => {
	if (e.type === "name") return `${n("games.kingdomlegacy.nameConfirm")}：${e.value}`;
	if (e.type === "choose") {
		let r = t.public.choices.find((t) => t.key === e.key)?.label;
		return r ? n("games.kingdomlegacy.actionLabel", {
			zh: r[0],
			en: r[1]
		}) : "";
	}
	return "";
};
//#endregion
//#region src/games/kingdomlegacy/fx.tsx
function It({ before: e, after: t, from: n, to: a, ms: o }) {
	let s = i(null), c = e.stage !== t.stage, l = t.zone === "destroyed";
	return r(() => {
		let e = l ? [
			{
				opacity: 1,
				transform: "scale(1)"
			},
			{
				opacity: 1,
				transform: "scale(.95)",
				offset: .5
			},
			{
				opacity: 0,
				transform: "scale(.3)"
			}
		] : c ? [{ transform: "rotateY(0deg)" }, { transform: "rotateY(180deg)" }] : [{ opacity: 1 }, { opacity: 1 }], t = s.current?.animate(e, {
			duration: o,
			easing: "ease-in-out",
			fill: "both"
		});
		return () => t?.cancel();
	}, [
		o,
		c,
		l
	]), /* @__PURE__ */ v(b, {
		from: n,
		to: a,
		ms: o,
		children: /* @__PURE__ */ v("div", {
			className: "kl-fx-card",
			ref: s,
			"data-turning": c,
			style: {
				width: n.w,
				height: n.h
			},
			children: c ? /* @__PURE__ */ y(te, { children: [/* @__PURE__ */ v("div", {
				className: "kl-fx-face",
				children: /* @__PURE__ */ v($, { card: e })
			}), /* @__PURE__ */ v("div", {
				className: "kl-fx-face kl-fx-reverse",
				children: /* @__PURE__ */ v($, { card: t })
			})] }) : /* @__PURE__ */ v($, { card: t })
		})
	});
}
var Lt = { change(e, t) {
	let n = e.data, r = t.queued ? 220 : 415, i = [], a = [];
	for (let { before: e, after: o } of n.cards) {
		if (e.zone === "box" && o.zone === "destroyed") continue;
		let n = e.stage === o.stage && e.zone === o.zone, s = o.zone === "play" || o.zone === "permanent" || o.zone === "blocked" ? `card:${o.id}` : o.zone === "discard" ? "discard" : o.zone === "deck" ? "deck" : "archive", c = t.anchor(s);
		if (!c) continue;
		if (n) {
			i.push(/* @__PURE__ */ v(ne, {
				at: c,
				ms: r
			}, o.id));
			continue;
		}
		let l = e.zone === "play" || e.zone === "blocked" || e.zone === "permanent" ? `origin:${e.id}` : e.zone === "deck" ? "deck" : e.zone === "discard" ? "discard" : "archive", u = t.anchor(l) ?? t.anchor(`live:${e.id}`) ?? (e.zone === "permanent" ? t.anchor("permanents") : null);
		if (!u) continue;
		let d = s.startsWith("card:") ? c : {
			...c,
			w: Math.min(c.w, u.w),
			h: Math.min(c.h, u.h)
		};
		i.push(/* @__PURE__ */ v(It, {
			before: e,
			after: o,
			from: u,
			to: d,
			ms: r
		}, o.id)), s.startsWith("card:") && !t.queued && a.push(s);
	}
	return i.length ? {
		ms: r,
		node: i,
		hide: a
	} : null;
} };
//#endregion
//#region src/games/kingdomlegacy/game-over.tsx
function Rt({ public: e, private: t, result: n, members: r, myRid: i, hintCount: o, onPlayAgain: s, onBackToLobby: d }) {
	let f = e, p = t?.checkpoint, h = l(), ee = c((e) => e.locale) === "zh" ? 0 : 1, [g, _] = a(!0), te = r.find((e) => e.rid === i), b = n.autopilot?.[f.owner];
	return /* @__PURE__ */ y("div", {
		className: "kl-final",
		children: [
			/* @__PURE__ */ v(re, {}),
			/* @__PURE__ */ v("div", {
				className: "kl-final-table",
				inert: g,
				children: /* @__PURE__ */ v(Nt, {
					pub: f,
					checkpoint: p,
					send: () => {},
					readOnly: !0,
					resultButton: /* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => _(!0),
						children: h("games.kingdomlegacy.finalTitle")
					})
				})
			}),
			/* @__PURE__ */ v("div", {
				className: "kl-shade kl-result-shade",
				hidden: !g,
				children: /* @__PURE__ */ y("section", {
					className: "kl-result-panel",
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "kl-result-title",
					children: [
						/* @__PURE__ */ y("header", { children: [
							/* @__PURE__ */ v("span", {
								className: "kl-book-seal",
								children: "KL"
							}),
							/* @__PURE__ */ v("h1", {
								id: "kl-result-title",
								children: h("games.kingdomlegacy.finalTitle")
							}),
							/* @__PURE__ */ v("button", {
								type: "button",
								"aria-label": h("games.kingdomlegacy.review"),
								onClick: () => _(!1),
								children: /* @__PURE__ */ v(u, {})
							})
						] }),
						/* @__PURE__ */ y("div", {
							className: "kl-result-scroll",
							children: [
								/* @__PURE__ */ v("p", {
									className: "kl-result-owner",
									children: te?.name
								}),
								/* @__PURE__ */ v("span", { children: h("games.kingdomlegacy.fame") }),
								/* @__PURE__ */ v("strong", {
									className: "kl-result-score",
									children: n.scores?.[f.owner] ?? f.fame
								}),
								/* @__PURE__ */ y("div", {
									className: "kl-result-chapters",
									children: [f.scores.map((e, t) => /* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("span", { children: e.chapter ? T(e.chapter, 1)[ee] : h("games.kingdomlegacy.chapterBase") }), /* @__PURE__ */ v("b", { children: e.score })] }, t)), /* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("span", { children: h("games.kingdomlegacy.purged") }), /* @__PURE__ */ v("b", { children: f.purgedFame })] })]
								}),
								o !== void 0 && /* @__PURE__ */ v("p", { children: h("session.hint.usedCount", { n: o }) }),
								b !== void 0 && b > 0 && /* @__PURE__ */ v("p", { children: h("session.autopilot.share", { n: Math.round(b * 100) }) }),
								/* @__PURE__ */ v(kt, { checkpoint: p })
							]
						}),
						/* @__PURE__ */ y("footer", { children: [
							/* @__PURE__ */ v("button", {
								type: "button",
								onClick: () => _(!1),
								children: h("games.kingdomlegacy.review")
							}),
							s && /* @__PURE__ */ v(m, {
								label: h("games.kingdomlegacy.again"),
								confirmLabel: h("games.kingdomlegacy.confirm"),
								onConfirm: s
							}),
							d && /* @__PURE__ */ v(m, {
								label: h("games.kingdomlegacy.back"),
								confirmLabel: h("games.kingdomlegacy.confirm"),
								onConfirm: d
							}),
							!s && !d && /* @__PURE__ */ v("p", { children: h("games.kingdomlegacy.wait") })
						] })
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/kingdomlegacy/options.tsx
function zt({ value: e, onChange: t }) {
	let n = l(), r = ct.safeParse(e), i = r.success ? r.data : ct.parse({}), [o, s] = a(""), [c, u] = a(!1);
	async function d() {
		u(!0), s("");
		try {
			let e = await gt();
			e ? (t({ checkpoint: e }), s(n("games.kingdomlegacy.checkpoint"))) : s(n("games.kingdomlegacy.emptyArchive"));
		} catch {
			s(n("games.kingdomlegacy.loadError"));
		} finally {
			u(!1);
		}
	}
	return /* @__PURE__ */ y("section", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ v("h3", {
				className: "font-bold",
				children: n("games.kingdomlegacy.archive")
			}),
			/* @__PURE__ */ v("button", {
				className: "btn-base bg-surface",
				type: "button",
				disabled: c,
				onClick: () => void d(),
				children: n(c ? "games.kingdomlegacy.loading" : "games.kingdomlegacy.load")
			}),
			i.checkpoint && /* @__PURE__ */ y(te, { children: [/* @__PURE__ */ y("p", { children: [
				n("games.kingdomlegacy.round", { n: i.checkpoint.round }),
				" ·",
				" ",
				n("games.kingdomlegacy.turn", { n: i.checkpoint.turn })
			] }), /* @__PURE__ */ v("button", {
				type: "button",
				className: "btn-quiet",
				onClick: () => {
					t({ checkpoint: null }), s("");
				},
				children: n("games.kingdomlegacy.newKingdom")
			})] }),
			/* @__PURE__ */ v("p", {
				role: "status",
				children: o
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/kingdomlegacy/entry.tsx
var Bt = {
	definition: mt,
	View: Mt,
	bot: Pt,
	describe: Ft,
	fx: Lt,
	OverView: Rt,
	Options: zt,
	locales: {
		zh: {
			name: "王国兴亡录：封建王国",
			desc: "升级、发现与永久改写卡牌，经营独一无二的单人王国。",
			rules: "目标：\n发展王国，争取更高声望。采用《Kingdom Legacy: Feudal Kingdom》第二版，包含基础内容与盒内三个小扩展。\n\n开局：\n将 1–10 号牌组成王国。每轮洗牌，每回合打出 4 张牌；牌库顶公开，其余未发现内容保持隐藏。\n\n行动：\n每回合可选择以下行动：\n· 弃置卡牌，获得其产出。\n· 支付费用，升级卡牌。\n· 使用卡牌效果。\n· 推进并打出 2 张牌。\n· 结束回合。\n可以反复推进。升级会使该牌转向并弃置，随后结束回合。卡效造成的转向同样弃牌，但通常不结束回合。\n\n资源与效果：\n新牌进入场上或回合结束时，清空资源。声望不是资源。同批打出的牌同时入场；同时触发的效果由你选择顺序，所有强制效果都必须结算。时间效果完成后可先使用被动效果，再结束回合。\n\n轮末与发现：\n回合末弃置没有留场能力的牌；牌库空时结束本轮，所有非永久牌均弃置，再结算轮末效果。下一轮通常发现接下来两张牌；羊皮纸以其说明替代普通发现。发现 70 号后为基础篇最终轮。\n\n永久、阻挡与贴纸：\n· 永久牌在场外，不能弃置，不参与洗牌。\n· 被阻挡牌视为不存在；回合中解除阻挡会释放该牌，回合或轮末则一并弃置。\n· 贴纸数量有限，用完时忽略对应贴纸效果。默认只改写当前阶段；生产总量达到 9 时不能再加资源贴纸。\n\n计分与扩展：\n基础篇结束时计算整个王国的声望。可继续选择尚未游玩的盒内小扩展；先每 12 张牌净化 1 张友好牌，再净化 1 张友好永久牌，保留净化声望。每个小扩展有 4 轮，不再普通发现新牌。王国的阶段、贴纸、勾格及摧毁记录持续保留。\n\n保存：\n使用“保存王国”写入本机档案，只有显示已保存才代表成功。开局选项可载入档案；发生并发冲突时保留当前画面并重新载入最新档案。",
			typeLand: "土地",
			typeBuilding: "建筑",
			typePerson: "人物",
			typeLivestock: "牲畜",
			typeSeafaring: "航海",
			typePermanent: "永久",
			typeEnemy: "敌人",
			typeEvent: "事件",
			typeKnight: "骑士",
			typeHorse: "马匹",
			typeWall: "城墙",
			typeItem: "物品",
			typeInvention: "发明",
			typeState: "状态",
			typeLoot: "战利品",
			typeScroll: "羊皮纸",
			typeElder: "长者",
			typeShip: "船",
			typeGoal: "目标",
			typeArtifact: "遗物",
			typeLady: "贵妇",
			stickerStay: "留场",
			stickerFame2: "2 声望",
			stickerFame5: "5 声望",
			stickerBlank: "空白声望",
			stickerChapter: "篇章记录",
			deckPosition: "牌库第 {{n}} 张：",
			blockedBy: "被 {{n}} 号牌阻挡",
			or: "或",
			nextBox: "下一格 ",
			checkboxes: "勾选格",
			addedStickers: "已添加贴纸",
			stoneBridge: "石桥",
			invalid: "这个行动当前不可执行。",
			actionLabel: "{{zh}}",
			round: "第 {{n}} 轮",
			turn: "回合 {{n}}",
			fame: "声望",
			purged: "净化声望",
			play: "场上",
			permanent: "永久牌",
			discard: "弃牌堆",
			deck: "牌库",
			blocked: "被阻挡",
			choose: "选择卡牌",
			inspect: "查看所有阶段",
			close: "关闭",
			save: "保存王国",
			saving: "正在保存…",
			saved: "已保存",
			saveError: "保存失败，请重试。",
			saveNewer: "档案已被另一页面更新，请载入最新档案。",
			load: "载入王国档案",
			loading: "正在读取档案…",
			loadError: "读取失败，请重试。",
			emptyArchive: "尚无王国档案。",
			newKingdom: "新建王国",
			resume: "继续档案",
			archive: "王国档案",
			confirmNew: "保存后将替换现有王国档案，是否继续？",
			cancel: "取消",
			confirm: "确认",
			nameStranger: "输入陌生人的名字",
			nameConfirm: "确认名字",
			settling: "正在结算…",
			history: "王国记录",
			stickers: "贴纸余量",
			chapter: "王国篇章",
			chapterBase: "封建王国",
			chapterEnd: "本章完成",
			finalTitle: "王国编年史",
			score: "王国声望 {{n}}",
			review: "回看王国",
			again: "重新开局",
			back: "返回大厅",
			wait: "等待主机继续",
			noProduction: "没有资源产出",
			fameValue: "{{n}} 声望",
			stage: "阶段 {{n}}",
			cost: "升级费用",
			destroyConfirm: "此选择将永久摧毁卡牌，是否继续？",
			continue: "继续",
			free: "无资源费用",
			noActions: "选择场上卡牌以查看可执行动作。",
			cardsCount: "{{n}} 张",
			checkpoint: "王国档案已选中；开局后从保存位置继续。"
		},
		en: {
			name: "Kingdom Legacy: Feudal Kingdom",
			desc: "Discover, upgrade and permanently change cards to build a unique solo kingdom.",
			rules: "Goal: develop your kingdom and earn fame. Uses the second edition of Feudal Kingdom and the three mini expansions in the box.\n\nSetup: cards 1–10 form your kingdom. Shuffle each round and play 4 cards each turn. The top card is visible; undiscovered content stays hidden.\n\nActions: choose one of the following:\n· Discard a card to gain its production.\n· Pay to upgrade a card.\n· Use a card effect.\n· Advance to play 2 more cards.\n· End the turn.\nYou may advance repeatedly. Upgrading turns and discards the card, then ends the turn. Other orientation changes also discard it, but usually do not end the turn.\n\nResources and timing: resources are lost when new cards enter play or the turn ends. Fame is not a resource. Cards played together are all in play before resolving their effects. Choose the order of simultaneous effects and resolve every mandatory effect. After a time effect, passive effects may be used before the turn ends.\n\nRounds and discovery: discard cards without staying effects at turn end. When the deck is empty, discard all non-permanent cards and resolve round-end effects. Normally discover the next 2 cards before a new round. Parchments replace normal discovery with their instructions. Discovering card 70 starts the final base-game round.\n\nPermanents, blocking and stickers:\n· Permanents are outside play, cannot be discarded and are never shuffled.\n· Blocked cards do not exist for game purposes. Releasing them during a turn is not playing them; at turn or round end they are discarded together with the blocking card.\n· Sticker supplies are limited; ignore an unavailable sticker effect. Normally modify only the active stage. A card with 9 or more production cannot receive another resource sticker.\n\nScoring and expansions: count fame throughout your kingdom after the base chapter. You may continue with an unplayed built-in mini expansion. First purge 1 friendly card from each group of 12, then 1 friendly permanent, retaining their fame. Each mini expansion lasts 4 rounds without normal new-card discovery. Stages, stickers, checkboxes and destroyed cards persist.\n\nSaving: Save kingdom writes a local archive. Only Saved confirms success. Load it in game options to resume. On a conflict, keep the current game and reload the newest archive.",
			typeLand: "Land",
			typeBuilding: "Building",
			typePerson: "Person",
			typeLivestock: "Livestock",
			typeSeafaring: "Seafaring",
			typePermanent: "Permanent",
			typeEnemy: "Enemy",
			typeEvent: "Event",
			typeKnight: "Knight",
			typeHorse: "Horse",
			typeWall: "Wall",
			typeItem: "Item",
			typeInvention: "Invention",
			typeState: "State",
			typeLoot: "Loot",
			typeScroll: "Parchment",
			typeElder: "Elder",
			typeShip: "Ship",
			typeGoal: "Goal",
			typeArtifact: "Artifact",
			typeLady: "Lady",
			stickerStay: "Stay",
			stickerFame2: "2 fame",
			stickerFame5: "5 fame",
			stickerBlank: "Blank fame",
			stickerChapter: "Chapter record",
			deckPosition: "Deck card {{n}}: ",
			blockedBy: "Blocked by card {{n}}",
			or: "or",
			nextBox: "Next ",
			checkboxes: "Checkboxes",
			addedStickers: "Added stickers",
			stoneBridge: "Stone Bridge",
			invalid: "That action is not available now.",
			actionLabel: "{{en}}",
			round: "Round {{n}}",
			turn: "Turn {{n}}",
			fame: "Fame",
			purged: "Purged fame",
			play: "In play",
			permanent: "Permanents",
			discard: "Discard",
			deck: "Draw deck",
			blocked: "Blocked",
			choose: "Choose a card",
			inspect: "Inspect all stages",
			close: "Close",
			save: "Save kingdom",
			saving: "Saving…",
			saved: "Saved",
			saveError: "Could not save. Please retry.",
			saveNewer: "Another page updated this archive. Load the newest archive.",
			load: "Load kingdom archive",
			loading: "Reading archive…",
			loadError: "Could not read. Please retry.",
			emptyArchive: "No kingdom archive yet.",
			newKingdom: "New kingdom",
			resume: "Resume archive",
			archive: "Kingdom archive",
			confirmNew: "Saving will replace the existing kingdom archive. Continue?",
			cancel: "Cancel",
			confirm: "Confirm",
			nameStranger: "Enter the stranger’s name",
			nameConfirm: "Confirm name",
			settling: "Resolving…",
			history: "Kingdom chronicle",
			stickers: "Remaining stickers",
			chapter: "Kingdom chapter",
			chapterBase: "Feudal Kingdom",
			chapterEnd: "Chapter complete",
			finalTitle: "Chronicle of a Kingdom",
			score: "Kingdom fame {{n}}",
			review: "Review kingdom",
			again: "Play again",
			back: "Back to lobby",
			wait: "Waiting for the host",
			noProduction: "No resource production",
			fameValue: "{{n}} fame",
			stage: "Stage {{n}}",
			cost: "Upgrade cost",
			destroyConfirm: "This choice will permanently destroy cards. Continue?",
			continue: "Continue",
			free: "No resource cost",
			noActions: "Choose a card in play to see its available actions.",
			cardsCount: "{{n}} cards",
			checkpoint: "Archive selected. Start to continue from the saved position."
		}
	}
};
//#endregion
export { Bt as default };
