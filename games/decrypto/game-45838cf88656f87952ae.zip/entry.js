import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import n from "@bgparty/sdk/word-list";
import { useEffect as r, useRef as i, useState as a } from "react";
import { ConfirmButton as o } from "@bgparty/sdk/confirm-button";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useT as c } from "@bgparty/sdk/i18n";
import { IconShuffle as l } from "@bgparty/sdk/icons";
import { TeamMedal as u } from "@bgparty/sdk/team-medal";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { BottomSheet as p } from "@bgparty/sdk/bottom-sheet";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Floater as _ } from "@bgparty/sdk/fx/primitives";
import { Confetti as v } from "@bgparty/sdk/ui/confetti";
//#region src/games/decrypto/meta.ts
var y = {
	id: "decrypto",
	tier: "beta",
	mechanics: ["word-association", "deduction"],
	interactionTags: ["team-based"],
	nameKey: "games.decrypto.name",
	descKey: "games.decrypto.desc",
	rulesKey: "games.decrypto.rules",
	icon: "📟",
	iconImg: "games/decrypto.webp",
	rulesUrl: { zh: "https://rules.bgparty.uuppi.com/decrypto/zh.pdf" },
	minPlayers: 4,
	maxPlayers: 8,
	bestPlayers: [4, 6],
	accent: "#4338ca",
	releasedAt: "2026-09-17",
	search: {
		py: "die bao feng yun",
		init: "dbfy"
	},
	hotseat: "cover"
}, b = t.string(), x = t.enum(["white", "black"]), S = t.int().min(1).max(4), C = t.tuple([
	S,
	S,
	S
]), w = t.string().trim().min(1).max(24), T = t.array(S).max(3), E = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("teams:set"),
		teams: t.object({
			white: t.array(b),
			black: t.array(b)
		})
	}),
	t.object({ type: t.literal("teams:shuffle") }),
	t.object({ type: t.literal("teams:start") }),
	t.object({
		type: t.literal("clue:give"),
		clues: t.tuple([
			w,
			w,
			w
		])
	}),
	t.object({
		type: t.literal("guess:set"),
		digits: T
	}),
	t.object({ type: t.literal("guess:lock") }),
	t.object({ type: t.literal("reveal:next") }),
	t.object({
		type: t.literal("tie:set"),
		words: t.array(t.string().trim().max(24)).length(4)
	}),
	t.object({ type: t.literal("tie:lock") }),
	t.object({
		type: t.literal("tie:judge"),
		count: t.int().min(0).max(4)
	})
]), D = t.object({
	intercept: t.int().nonnegative(),
	miscomm: t.int().nonnegative()
}), ee = t.object({
	n: t.int().positive(),
	team: x,
	code: C,
	clues: t.tuple([
		t.string(),
		t.string(),
		t.string()
	]),
	decrypt: t.object({
		digits: C,
		by: b
	}),
	intercept: t.object({
		digits: C,
		by: b
	}).nullable()
}), te = t.enum([
	"white",
	"black",
	"both"
]), ne = t.object({
	phase: t.enum([
		"teams",
		"play",
		"tiebreak",
		"done"
	]),
	players: t.array(b),
	teams: t.object({
		white: t.array(b),
		black: t.array(b)
	}),
	round: t.int().nonnegative(),
	stage: t.enum([
		"encrypt",
		"white",
		"whiteReveal",
		"black",
		"blackReveal"
	]).nullable(),
	encryptors: t.object({
		white: b.nullable(),
		black: b.nullable()
	}),
	cluesSubmitted: t.object({
		white: t.boolean(),
		black: t.boolean()
	}),
	activeTeam: x.nullable(),
	activeClues: t.tuple([
		t.string(),
		t.string(),
		t.string()
	]).nullable(),
	locks: t.object({
		decrypt: t.boolean(),
		intercept: t.boolean().nullable()
	}),
	tokens: t.object({
		white: D,
		black: D
	}),
	history: t.array(ee),
	tie: t.object({
		stage: t.enum(["guess", "judge"]),
		guessesLocked: t.object({
			white: t.boolean(),
			black: t.boolean()
		}),
		guesses: t.object({
			white: t.array(t.string()).nullable(),
			black: t.array(t.string()).nullable()
		}),
		judged: t.object({
			white: t.int().min(0).max(4).nullable(),
			black: t.int().min(0).max(4).nullable()
		})
	}).nullable(),
	winner: te.nullable(),
	endDetail: t.enum([
		"intercept",
		"mistake",
		"score",
		"keywords",
		"shared"
	]).nullable(),
	finalKeywords: t.object({
		white: t.array(t.string()),
		black: t.array(t.string())
	}).nullable()
}), O = t.object({
	team: x,
	keywords: t.array(t.string()),
	code: C.nullable(),
	draftKind: t.enum(["decrypt", "intercept"]).nullable(),
	draft: t.array(S).nullable(),
	draftLocked: t.boolean(),
	tieDraft: t.array(t.string()).nullable(),
	tieLocked: t.boolean()
}), re = n;
function k(e) {
	return e === "white" ? "black" : "white";
}
function A(e, t) {
	return e.teams.white.includes(t) ? "white" : e.teams.black.includes(t) ? "black" : null;
}
function j(e, t) {
	let n = e.teams[t];
	return n.length === 0 || e.round === 0 ? null : n[(e.round - 1) % n.length];
}
var M = (e) => e.trim().toLowerCase();
function N(e, t) {
	let n = e.map(M).filter(Boolean), r = /* @__PURE__ */ new Set(), i = 0;
	for (let e of t.map(M)) {
		let t = n.findIndex((t, n) => !r.has(n) && t === e);
		t >= 0 && (r.add(t), i += 1);
	}
	return i;
}
function P(t, n, r) {
	let i = [...r];
	for (let r = i.length - 1; r > 0; --r) {
		let a = e(t, n, r + 1);
		n += 1, [i[r], i[a]] = [i[a], i[r]];
	}
	return {
		out: i,
		cursor: n
	};
}
function F(e, t) {
	let { out: n, cursor: r } = P(e, t, [
		1,
		2,
		3,
		4
	]);
	return {
		code: [
			n[0],
			n[1],
			n[2]
		],
		cursor: r
	};
}
function ie(e, t, n) {
	return { state: {
		players: t,
		phase: "teams",
		teams: {
			white: [],
			black: []
		},
		seed: n,
		rngCursor: 0,
		keywords: {
			white: [],
			black: []
		},
		round: 0,
		stage: "encrypt",
		codes: {
			white: null,
			black: null
		},
		clues: {
			white: null,
			black: null
		},
		decryptDraft: {
			white: [],
			black: []
		},
		interceptDraft: {
			white: [],
			black: []
		},
		decryptLock: {
			white: null,
			black: null
		},
		interceptLock: {
			white: null,
			black: null
		},
		tokens: {
			white: {
				intercept: 0,
				miscomm: 0
			},
			black: {
				intercept: 0,
				miscomm: 0
			}
		},
		history: [],
		tie: null,
		winner: null,
		endDetail: null
	} };
}
function ae(e) {
	let t = P(e.seed, e.rngCursor, re);
	e.rngCursor = t.cursor, e.keywords = {
		white: t.out.slice(0, 4),
		black: t.out.slice(4, 8)
	}, e.round = 1, I(e);
}
function I(e) {
	let t = F(e.seed, e.rngCursor);
	e.codes.white = t.code;
	let n = F(e.seed, t.cursor);
	e.codes.black = n.code, e.rngCursor = n.cursor, e.clues = {
		white: null,
		black: null
	}, e.stage = "encrypt";
}
function L(e) {
	e.decryptDraft = {
		white: [],
		black: []
	}, e.interceptDraft = {
		white: [],
		black: []
	}, e.decryptLock = {
		white: null,
		black: null
	}, e.interceptLock = {
		white: null,
		black: null
	};
}
function oe(e, t) {
	let n = [], r = e.codes[t], i = e.clues[t], a = e.decryptLock[t], o = e.round >= 2 ? e.interceptLock[k(t)] : null;
	return e.history = [...e.history, {
		n: e.round,
		team: t,
		code: r,
		clues: i,
		decrypt: {
			digits: a.digits,
			by: a.by
		},
		intercept: o
	}], o && R(o.digits, r) && (e.tokens[k(t)].intercept += 1, n.push({
		kind: "token",
		data: {
			team: k(t),
			token: "intercept"
		}
	})), R(a.digits, r) || (e.tokens[t].miscomm += 1, n.push({
		kind: "token",
		data: {
			team: t,
			token: "miscomm"
		}
	})), n;
}
function R(e, t) {
	return e.length === 3 && t.length === 3 && e[0] === t[0] && e[1] === t[1] && e[2] === t[2];
}
function z(e, t, n) {
	e.winner = t, e.endDetail = n, e.phase = "done";
}
function B(e) {
	let t = e.tokens.white.intercept - e.tokens.white.miscomm, n = e.tokens.black.intercept - e.tokens.black.miscomm;
	if (t !== n) {
		z(e, t > n ? "white" : "black", "score");
		return;
	}
	e.phase = "tiebreak", e.tie = {
		stage: "guess",
		drafts: {
			white: [
				"",
				"",
				"",
				""
			],
			black: [
				"",
				"",
				"",
				""
			]
		},
		lockedBy: {
			white: null,
			black: null
		},
		judged: {
			white: null,
			black: null
		}
	};
}
function se(e) {
	let t = e.tokens.white.intercept >= 2, n = e.tokens.white.miscomm >= 2, r = e.tokens.black.intercept >= 2, i = e.tokens.black.miscomm >= 2;
	if (!(t && n || r && i || t && r || n && i)) {
		if (t || i) return z(e, "white", t ? "intercept" : "mistake");
		if (r || n) return z(e, "black", r ? "intercept" : "mistake");
		if (e.round >= 8) return B(e);
		e.round += 1, L(e), I(e);
		return;
	}
	B(e);
}
function ce(e, t, n) {
	let r = n.by === e.players[0];
	if (t.type === "teams:set") {
		if (e.phase !== "teams" || !r) return { code: "games.decrypto.errNotHost" };
		let n = [...t.teams.white, ...t.teams.black];
		if (new Set(n).size !== n.length || !n.every((t) => e.players.includes(t))) return { code: "games.decrypto.errBadTeams" };
		let i = structuredClone(e);
		return i.teams = {
			white: [...t.teams.white],
			black: [...t.teams.black]
		}, { state: i };
	}
	if (t.type === "teams:shuffle") {
		if (e.phase !== "teams" || !r) return { code: "games.decrypto.errNotHost" };
		let t = structuredClone(e), { out: n, cursor: i } = P(t.seed, t.rngCursor, t.players);
		t.rngCursor = i;
		let a = Math.ceil(n.length / 2);
		return t.teams = {
			white: n.slice(0, a),
			black: n.slice(a)
		}, { state: t };
	}
	if (t.type === "teams:start") {
		if (e.phase !== "teams" || !r) return { code: "games.decrypto.errNotHost" };
		let t = [...e.teams.white, ...e.teams.black];
		if (!(t.length === e.players.length && new Set(t).size === t.length && t.every((t) => e.players.includes(t)) && e.teams.white.length >= 2 && e.teams.black.length >= 2)) return { code: "games.decrypto.errTeamsNotReady" };
		let n = structuredClone(e);
		return ae(n), n.phase = "play", { state: n };
	}
	if (t.type === "clue:give") {
		if (e.phase !== "play" || e.stage !== "encrypt") return { code: "games.decrypto.errBadStage" };
		let r = ["white", "black"].find((t) => j(e, t) === n.by);
		if (!r) return { code: "games.decrypto.errNotEncryptor" };
		if (e.clues[r] !== null) return { code: "games.decrypto.errAlreadySubmitted" };
		let i = /* @__PURE__ */ new Set();
		for (let n of t.clues) {
			let t = M(n);
			if (i.has(t)) return { code: "games.decrypto.errClueDup" };
			i.add(t);
			for (let n of e.keywords[r]) {
				let e = M(n);
				if (t.includes(e) || e.includes(t)) return { code: "games.decrypto.errClueKeyword" };
			}
		}
		for (let t of e.history) if (t.team === r) {
			for (let e of t.clues) if (i.has(M(e))) return { code: "games.decrypto.errClueRepeat" };
		}
		let a = structuredClone(e);
		return a.clues[r] = [...t.clues], a.clues.white !== null && a.clues.black !== null && (a.stage = "white"), { state: a };
	}
	if (t.type === "guess:set" || t.type === "guess:lock") {
		if (e.phase !== "play" || e.stage !== "white" && e.stage !== "black") return { code: "games.decrypto.errBadStage" };
		let r = e.stage, i = A(e, n.by);
		if (i === null) return { code: "games.decrypto.errNotGuesser" };
		let a = i !== r;
		if (!a && j(e, r) === n.by) return { code: "games.decrypto.errNotGuesser" };
		if (a && e.round < 2) return { code: "games.decrypto.errNoIntercept" };
		if ((a ? e.interceptLock[i] : e.decryptLock[i]) !== null) return { code: "games.decrypto.errLocked" };
		if (t.type === "guess:set") {
			if (new Set(t.digits).size !== t.digits.length) return { code: "games.decrypto.errBadDigits" };
			let n = structuredClone(e);
			return a ? n.interceptDraft[i] = [...t.digits] : n.decryptDraft[i] = [...t.digits], { state: n };
		}
		let o = a ? e.interceptDraft[i] : e.decryptDraft[i];
		if (o.length !== 3 || new Set(o).size !== 3) return { code: "games.decrypto.errBadDigits" };
		let s = structuredClone(e);
		a ? s.interceptLock[i] = {
			digits: o,
			by: n.by
		} : s.decryptLock[i] = {
			digits: o,
			by: n.by
		};
		let c = s.decryptLock[r] !== null, l = s.round < 2 || s.interceptLock[k(r)] !== null;
		if (c && l) {
			let e = oe(s, r);
			return s.stage = r === "white" ? "whiteReveal" : "blackReveal", {
				state: s,
				fx: e
			};
		}
		return { state: s };
	}
	if (t.type === "reveal:next") {
		if (e.phase !== "play" || e.stage !== "whiteReveal" && e.stage !== "blackReveal") return { code: "games.decrypto.errBadStage" };
		if (A(e, n.by) === null) return { code: "games.decrypto.errNotGuesser" };
		let t = structuredClone(e);
		return L(t), t.stage === "whiteReveal" ? (t.stage = "black", { state: t }) : (se(t), { state: t });
	}
	let i = A(e, n.by);
	if (e.phase !== "tiebreak" || e.tie === null || i === null) return { code: "games.decrypto.errBadStage" };
	let a = e.tie;
	if (t.type === "tie:set") {
		if (a.stage !== "guess" || a.lockedBy[i] !== null) return { code: "games.decrypto.errLocked" };
		let n = structuredClone(e);
		return n.tie.drafts[i] = [...t.words], { state: n };
	}
	if (t.type === "tie:lock") {
		if (a.stage !== "guess" || a.lockedBy[i] !== null) return { code: "games.decrypto.errLocked" };
		if (a.drafts[i].some((e) => !M(e))) return { code: "games.decrypto.errTieWords" };
		let t = structuredClone(e);
		return t.tie.lockedBy[i] = n.by, t.tie.lockedBy.white !== null && t.tie.lockedBy.black !== null && (t.tie.stage = "judge"), { state: t };
	}
	if (a.stage !== "judge" || a.judged[i] !== null) return { code: "games.decrypto.errBadStage" };
	let o = structuredClone(e);
	o.tie.judged[i] = t.count;
	let s = o.tie.judged;
	return s.white !== null && s.black !== null && (s.black === s.white ? z(o, "both", "shared") : z(o, s.black > s.white ? "white" : "black", "keywords")), { state: o };
}
function le(e, t) {
	let n = A(e, t), r = e.phase === "play", i = r && (e.stage === "white" || e.stage === "black"), a = i || e.stage === "whiteReveal" || e.stage === "blackReveal" ? e.stage.startsWith("white") ? "white" : "black" : null, o = {
		phase: e.phase,
		players: e.players,
		teams: e.teams,
		round: e.round,
		stage: r ? e.stage : null,
		encryptors: r ? {
			white: j(e, "white"),
			black: j(e, "black")
		} : {
			white: null,
			black: null
		},
		cluesSubmitted: {
			white: e.clues.white !== null,
			black: e.clues.black !== null
		},
		activeTeam: r ? a : null,
		activeClues: r && a !== null ? e.clues[a] : null,
		locks: i ? {
			decrypt: e.decryptLock[a] !== null,
			intercept: e.round < 2 ? null : e.interceptLock[k(a)] !== null
		} : {
			decrypt: !1,
			intercept: null
		},
		tokens: {
			white: { ...e.tokens.white },
			black: { ...e.tokens.black }
		},
		history: e.history,
		tie: e.tie !== null && (e.phase === "tiebreak" || e.phase === "done") ? {
			stage: e.tie.stage,
			guessesLocked: {
				white: e.tie.lockedBy.white !== null,
				black: e.tie.lockedBy.black !== null
			},
			guesses: e.tie.stage === "judge" || e.phase === "done" ? {
				white: [...e.tie.drafts.white],
				black: [...e.tie.drafts.black]
			} : {
				white: null,
				black: null
			},
			judged: { ...e.tie.judged }
		} : null,
		winner: e.winner,
		endDetail: e.endDetail,
		finalKeywords: e.phase === "done" ? {
			white: [...e.keywords.white],
			black: [...e.keywords.black]
		} : null
	};
	if (n === null || e.phase === "teams") return { public: o };
	let s = null, c = null, l = !1;
	return i && (n === a && j(e, a) !== t ? (s = "decrypt", l = e.decryptLock[n] !== null, c = e.decryptLock[n]?.digits ?? [...e.decryptDraft[n]]) : n !== a && e.round >= 2 && (s = "intercept", l = e.interceptLock[n] !== null, c = e.interceptLock[n]?.digits ?? [...e.interceptDraft[n]])), {
		public: o,
		private: {
			team: n,
			keywords: [...e.keywords[n]],
			code: r && j(e, n) === t ? e.codes[n] : null,
			draftKind: s,
			draft: c,
			draftLocked: l,
			tieDraft: e.tie === null ? null : [...e.tie.drafts[n]],
			tieLocked: e.tie !== null && e.tie.lockedBy[n] !== null
		}
	};
}
function ue(e) {
	if (e.phase !== "done" || e.winner === null) return { phase: e.phase };
	let t = e.winner === "both" ? [...e.teams.white, ...e.teams.black] : [...e.teams[e.winner]], n = e.winner === "both" ? [...e.teams.white, ...e.teams.black] : [...e.teams[e.winner], ...e.teams[k(e.winner)]], r = (t) => e.tokens[t].intercept - e.tokens[t].miscomm, i = {};
	for (let t of e.players) {
		let n = A(e, t);
		n && (i[t] = r(n));
	}
	return {
		phase: "done",
		winner: t,
		ranking: n,
		scores: i
	};
}
var de = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: y,
	schemas: {
		action: E,
		publicView: ne,
		privateView: O
	},
	setup: ie,
	reduce: ce,
	viewFor: le,
	status: ue
}, V = {
	white: "#fafaf9",
	black: "#292524"
}, H = {
	white: "#1c1917",
	black: "#fafaf9"
}, U = {
	white: "games.decrypto.white",
	black: "games.decrypto.black"
};
//#endregion
//#region src/games/decrypto/history-sheet.tsx
function W({ open: e, onClose: t, pub: n, myTeam: r, myKeywords: i }) {
	let o = c(), [s, l] = a(null), u = s ?? k(r), d = n.history.filter((e) => e.team === u), f = [
		[],
		[],
		[],
		[]
	], _ = [
		[],
		[],
		[],
		[]
	];
	for (let e of d) e.code.forEach((t, n) => f[t - 1].push(e.clues[n])), e.intercept?.digits.forEach((t, n) => {
		t !== e.code[n] && _[t - 1].push(e.clues[n]);
	});
	let v = n.finalKeywords?.[u] ?? (u === r ? i : void 0);
	return /* @__PURE__ */ h(p, {
		open: e,
		onClose: t,
		label: o("games.decrypto.historyTitle"),
		children: /* @__PURE__ */ g("div", {
			className: "dc-notes flex flex-col gap-3",
			children: [/* @__PURE__ */ h("div", {
				className: "dc-notes-tabs grid grid-cols-2 gap-1.5",
				children: ["white", "black"].map((e) => {
					let t = e === u;
					return /* @__PURE__ */ g("button", {
						type: "button",
						"aria-pressed": t,
						onClick: () => l(e),
						className: `flex min-h-11 cursor-pointer items-center justify-center gap-1 rounded-lg border-2 border-ink text-xs font-extrabold ${t ? "shadow-[2px_2px_0_var(--color-ink)]" : "bg-surface opacity-50"}`,
						style: t ? {
							backgroundColor: V[e],
							color: H[e]
						} : void 0,
						children: [o(U[e]), /* @__PURE__ */ h("span", {
							className: "opacity-70",
							children: o(e === r ? "games.decrypto.myTeamTag" : "games.decrypto.foeTeamTag")
						})]
					}, e);
				})
			}), d.length === 0 ? /* @__PURE__ */ h("p", {
				className: "text-sm font-bold opacity-70",
				children: o("games.decrypto.historyEmpty")
			}) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("section", {
				className: "dc-notes-grid flex flex-col gap-1",
				children: [/* @__PURE__ */ h("span", {
					className: "section-label",
					children: o("games.decrypto.digitNotes")
				}), [
					0,
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ g("div", {
					className: "dc-notes-digit-row flex items-start gap-2",
					children: [/* @__PURE__ */ h("span", {
						className: "flex h-6 w-6 flex-none items-center justify-center rounded-md border-2 border-ink bg-surface font-mono text-xs font-extrabold tabular-nums",
						children: e + 1
					}), /* @__PURE__ */ g("div", {
						className: "flex min-w-0 flex-1 flex-wrap items-center gap-1 pt-0.5",
						children: [
							v && /* @__PURE__ */ g("span", {
								className: "text-xs font-extrabold text-done-ink",
								children: [v[e], " ·"]
							}),
							f[e].map((e, t) => /* @__PURE__ */ h("span", {
								className: "rounded-md bg-done-soft px-1.5 py-0.5 text-xs font-bold text-done-ink",
								children: e
							}, t)),
							_[e].map((e, t) => /* @__PURE__ */ h("span", {
								className: "rounded-md bg-danger-soft px-1.5 py-0.5 text-xs font-bold text-danger-ink line-through",
								children: e
							}, t))
						]
					})]
				}, e))]
			}), /* @__PURE__ */ g("section", {
				className: "dc-notes-rounds flex flex-col gap-1",
				children: [/* @__PURE__ */ h("span", {
					className: "section-label",
					children: o("games.decrypto.roundList")
				}), /* @__PURE__ */ h("ol", {
					className: "flex flex-col gap-2",
					children: d.map((e) => /* @__PURE__ */ h(fe, {
						h: e,
						viewingTeam: u,
						myTeam: r
					}, e.n))
				})]
			})] })]
		})
	});
}
function fe({ h: e, viewingTeam: t, myTeam: n }) {
	let r = c(), i = r(t === n ? "games.decrypto.myDecrypt" : "games.decrypto.foeDecrypt"), a = r(t === n ? "games.decrypto.foeIntercept" : "games.decrypto.myIntercept");
	return /* @__PURE__ */ g("li", {
		className: "dc-round-card flex flex-col gap-1 px-3 py-2",
		children: [/* @__PURE__ */ h("span", {
			className: "text-xs font-bold opacity-70",
			children: r("games.decrypto.roundChip", { n: e.n })
		}), /* @__PURE__ */ g("div", {
			className: "grid grid-cols-[auto_1fr_1fr_1fr_auto] items-center gap-x-1.5 gap-y-0.5 text-xs font-bold",
			children: [
				/* @__PURE__ */ h("span", {}),
				e.clues.map((e, t) => /* @__PURE__ */ g("span", {
					className: "min-w-0 truncate text-center",
					children: [
						"「",
						e,
						"」"
					]
				}, t)),
				/* @__PURE__ */ h("span", {}),
				/* @__PURE__ */ h("span", {
					className: "pr-1 text-right opacity-70",
					children: r("games.decrypto.codeLabel")
				}),
				/* @__PURE__ */ h(G, {
					guess: e.code,
					code: e.code
				}),
				/* @__PURE__ */ h("span", {}),
				/* @__PURE__ */ h("span", {
					className: "pr-1 text-right opacity-70",
					children: i
				}),
				/* @__PURE__ */ h(G, {
					guess: e.decrypt.digits,
					code: e.code
				}),
				/* @__PURE__ */ h(K, {
					guess: e.decrypt.digits,
					code: e.code
				}),
				/* @__PURE__ */ h("span", {
					className: "pr-1 text-right opacity-70",
					children: a
				}),
				e.intercept ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(G, {
					guess: e.intercept.digits,
					code: e.code
				}), /* @__PURE__ */ h(K, {
					guess: e.intercept.digits,
					code: e.code
				})] }) : /* @__PURE__ */ h("span", {
					className: "col-span-4 opacity-60",
					children: r("games.decrypto.noIntercept")
				})
			]
		})]
	});
}
function G({ guess: e, code: t }) {
	return /* @__PURE__ */ h(m, { children: e.map((e, n) => /* @__PURE__ */ h("span", {
		className: `text-center font-mono font-extrabold tabular-nums ${e === t[n] ? "" : "text-danger line-through"}`,
		children: e
	}, n)) });
}
function K({ guess: e, code: t }) {
	let n = e.join() === t.join();
	return /* @__PURE__ */ h("span", {
		className: `font-extrabold ${n ? "text-done-ink" : "text-danger"}`,
		children: n ? "✓" : "✗"
	});
}
//#endregion
//#region src/games/decrypto/view-player.tsx
function pe(e) {
	let t = e.public, n = e.private;
	return t.phase === "teams" ? /* @__PURE__ */ h(ge, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	}) : t.phase === "tiebreak" ? /* @__PURE__ */ h(Ce, {
		pub: t,
		priv: n,
		send: e.send
	}) : /* @__PURE__ */ h(ve, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function me(e, t) {
	return e.teams.white.includes(t) ? "white" : e.teams.black.includes(t) ? "black" : null;
}
function he(e, t, n) {
	let r = {
		white: e.teams.white.filter((e) => e !== t),
		black: e.teams.black.filter((e) => e !== t)
	};
	return n !== "pool" && r[n].push(t), r;
}
function ge({ pub: e, members: t, myRid: n, send: r }) {
	let s = c(), f = e.players[0] === n, [p, m] = a(null), [_, v] = a(null), y = i(/* @__PURE__ */ new Map()), b = (e, t) => {
		for (let n of [
			"white",
			"black",
			"pool"
		]) {
			let r = y.current.get(n);
			if (!r) continue;
			let i = r.getBoundingClientRect();
			if (e >= i.left && e <= i.right && t >= i.top && t <= i.bottom) return n;
		}
		return null;
	}, x = (t, n) => {
		if (!f) return;
		let i = n.clientX, a = n.clientY, o = !1, s = (e) => {
			!o && Math.hypot(e.clientX - i, e.clientY - a) < 8 || (o = !0, m({
				rid: t,
				x: e.clientX,
				y: e.clientY
			}), v(b(e.clientX, e.clientY)));
		}, c = (n) => {
			if (window.removeEventListener("pointermove", s), window.removeEventListener("pointercancel", c), o) {
				let i = b(n.clientX, n.clientY);
				i && r({
					type: "teams:set",
					teams: he(e, t, i)
				});
			}
			m(null), v(null);
		};
		window.addEventListener("pointermove", s), window.addEventListener("pointerup", c, { once: !0 }), window.addEventListener("pointercancel", c, { once: !0 });
	}, S = e.players.filter((t) => me(e, t) === null), C = (e) => t.find((t) => t.rid === e);
	return /* @__PURE__ */ g("div", {
		className: "dc-root dc-teams flex h-full min-h-0 flex-col gap-2",
		children: [
			/* @__PURE__ */ h(d, {
				tone: "info",
				text: s("games.decrypto.teamsTitle"),
				sub: f ? void 0 : s("games.decrypto.teamsWait")
			}),
			/* @__PURE__ */ h("div", {
				className: "grid min-h-0 flex-1 grid-cols-2 gap-2",
				children: ["white", "black"].map((t) => /* @__PURE__ */ g("section", {
					ref: (e) => {
						e ? y.current.set(t, e) : y.current.delete(t);
					},
					className: `dc-team-zone flex min-h-0 flex-col gap-1.5 overflow-y-auto rounded-2xl border-3 border-ink p-2 ${_ === t ? "dc-team-hover" : ""}`,
					style: {
						backgroundColor: V[t],
						color: H[t]
					},
					children: [
						/* @__PURE__ */ g("h3", {
							className: "dc-team-title flex items-center gap-1 text-sm font-extrabold",
							style: { color: H[t] },
							children: [s(U[t]), /* @__PURE__ */ h("span", {
								className: "font-mono tabular-nums",
								children: e.teams[t].length
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: "dc-team-screen",
							"aria-hidden": !0,
							children: /* @__PURE__ */ h("svg", {
								viewBox: "0 0 96 38",
								preserveAspectRatio: "none",
								children: /* @__PURE__ */ h("path", {
									d: "M2 19h21l5-9 8 19 8-14 6 4h44",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "2"
								})
							})
						}),
						/* @__PURE__ */ h("div", {
							className: "dc-team-members flex flex-wrap content-start gap-1.5",
							children: e.teams[t].map((e) => /* @__PURE__ */ h(u, {
								member: C(e),
								rid: e,
								editable: f,
								dragging: p?.rid === e,
								onStartDrag: x
							}, e))
						}),
						/* @__PURE__ */ h("div", {
							className: "dc-team-circuit",
							"aria-hidden": !0,
							children: /* @__PURE__ */ g("svg", {
								viewBox: "0 0 120 260",
								preserveAspectRatio: "xMidYMid meet",
								children: [
									/* @__PURE__ */ h("path", {
										d: "M8 14h74l15 15v48H26l-13 13v48h79l16 16v61H39l-18 18h88",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "2"
									}),
									/* @__PURE__ */ h("circle", {
										cx: "8",
										cy: "14",
										r: "5",
										fill: "currentColor"
									}),
									/* @__PURE__ */ h("circle", {
										cx: "97",
										cy: "77",
										r: "5",
										fill: "currentColor"
									}),
									/* @__PURE__ */ h("circle", {
										cx: "13",
										cy: "138",
										r: "5",
										fill: "currentColor"
									}),
									/* @__PURE__ */ h("circle", {
										cx: "108",
										cy: "215",
										r: "5",
										fill: "currentColor"
									})
								]
							})
						}),
						e.teams[t].length === 0 && /* @__PURE__ */ h("p", {
							className: "dc-team-empty",
							children: s("games.decrypto.teamDropHint")
						})
					]
				}, t))
			}),
			S.length > 0 && /* @__PURE__ */ g("div", {
				ref: (e) => {
					e ? y.current.set("pool", e) : y.current.delete("pool");
				},
				className: `dc-team-pool frame flex flex-none flex-wrap items-center gap-1.5 p-2 ${_ === "pool" ? "outline-3 outline-info" : ""}`,
				children: [/* @__PURE__ */ h("span", {
					className: "section-label",
					children: s("games.decrypto.unassigned")
				}), S.map((e) => /* @__PURE__ */ h(u, {
					member: C(e),
					rid: e,
					editable: f,
					dragging: p?.rid === e,
					onStartDrag: x
				}, e))]
			}),
			f && /* @__PURE__ */ g("div", {
				className: "dc-team-actions flex flex-none gap-2",
				children: [/* @__PURE__ */ g("button", {
					type: "button",
					className: "btn-quiet flex-1 cursor-pointer",
					onClick: () => r({ type: "teams:shuffle" }),
					children: [/* @__PURE__ */ h(l, { size: 16 }), s("games.decrypto.shuffle")]
				}), /* @__PURE__ */ h(o, {
					className: "flex-1",
					label: s("games.decrypto.startGame"),
					confirmLabel: s("games.decrypto.startGameConfirm"),
					ariaLabel: s("games.decrypto.startGame"),
					onConfirm: () => r({ type: "teams:start" })
				})]
			}),
			p && /* @__PURE__ */ h("div", {
				className: "pointer-events-none fixed z-50",
				style: {
					left: p.x,
					top: p.y,
					transform: "translate(-50%, -70%)"
				},
				children: /* @__PURE__ */ h(u, {
					member: C(p.rid),
					rid: p.rid,
					floating: !0
				})
			})
		]
	});
}
function q({ n: e, size: t = "md" }) {
	return /* @__PURE__ */ g("span", {
		className: `dc-code-card ${t === "lg" ? "dc-code-card-large" : ""}`,
		children: [/* @__PURE__ */ g("svg", {
			viewBox: "0 0 48 56",
			preserveAspectRatio: "none",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ h("rect", {
					x: "2",
					y: "2",
					width: "44",
					height: "52",
					rx: "5",
					fill: "var(--color-surface)",
					stroke: "var(--color-ink)",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ h("path", {
					d: "M6 7h36v8H6z",
					fill: "var(--color-dc-accent)"
				}),
				/* @__PURE__ */ h("path", {
					d: "M8 47h32",
					stroke: "var(--color-dc-shell-deep)",
					strokeWidth: "1.5"
				})
			]
		}), /* @__PURE__ */ h("span", {
			className: "font-mono font-extrabold tabular-nums",
			children: e
		})]
	});
}
function J({ keywords: e }) {
	let t = c();
	return /* @__PURE__ */ g("div", {
		className: "dc-keywords flex-none",
		"aria-label": t("games.decrypto.keywordsMine"),
		children: [/* @__PURE__ */ g("div", {
			className: "dc-keywords-heading",
			children: [/* @__PURE__ */ h("span", { className: "dc-led" }), t("games.decrypto.keywordsMine")]
		}), /* @__PURE__ */ h("div", {
			className: "dc-keywords-grid",
			children: [
				0,
				1,
				2,
				3
			].map((t) => /* @__PURE__ */ g("span", {
				className: "dc-keyword-card",
				children: [
					/* @__PURE__ */ g("svg", {
						viewBox: "0 0 80 54",
						preserveAspectRatio: "none",
						"aria-hidden": !0,
						children: [/* @__PURE__ */ h("rect", {
							x: "1.5",
							y: "1.5",
							width: "77",
							height: "51",
							rx: "4",
							fill: "var(--color-dc-screen)",
							stroke: "var(--color-ink)",
							strokeWidth: "3"
						}), /* @__PURE__ */ h("path", {
							d: "M5 10h70M5 16h70M5 22h70M5 28h70M5 34h70M5 40h70M5 46h70",
							stroke: "var(--color-surface)",
							strokeOpacity: ".15"
						})]
					}),
					/* @__PURE__ */ h("span", {
						className: "dc-keyword-number font-mono tabular-nums",
						children: t + 1
					}),
					/* @__PURE__ */ h("span", {
						className: "dc-keyword-text",
						children: e[t] ?? "••••"
					})
				]
			}, t))
		})]
	});
}
function Y({ earned: e, kind: t, label: n }) {
	return /* @__PURE__ */ h("span", {
		className: "dc-token-pips",
		role: "img",
		"aria-label": `${n} ${e}/2`,
		children: [0, 1].map((n) => /* @__PURE__ */ g("svg", {
			viewBox: "0 0 24 24",
			className: `dc-token ${n < e ? "dc-token-earned" : ""}`,
			"aria-hidden": !0,
			children: [/* @__PURE__ */ h("circle", {
				cx: "12",
				cy: "12",
				r: "10",
				fill: n < e ? t === "intercept" ? "var(--color-surface)" : V.black : "none",
				stroke: "currentColor",
				strokeWidth: "2",
				strokeDasharray: n < e ? void 0 : "3 2"
			}), n < e && (t === "intercept" ? /* @__PURE__ */ h("path", {
				d: "m13 3-6 10h5l-2 8 8-11h-5l2-7Z",
				fill: "var(--color-dc-accent)"
			}) : /* @__PURE__ */ h("path", {
				d: "m8 8 8 8m0-8-8 8",
				fill: "none",
				stroke: "var(--color-surface)",
				strokeWidth: "2.5",
				strokeLinecap: "round"
			}))]
		}, n))
	});
}
function _e({ team: e, pub: t, active: n }) {
	let r = c(), { ref: i } = s(`tokens:${e}`), a = t.tokens[e];
	return /* @__PURE__ */ g("span", {
		ref: i,
		className: `dc-score-panel ${n ? "dc-score-active" : ""}`,
		style: {
			backgroundColor: V[e],
			color: H[e]
		},
		children: [
			/* @__PURE__ */ g("span", {
				className: "dc-score-name",
				children: [n && /* @__PURE__ */ h("span", {
					"aria-hidden": !0,
					children: "▸ "
				}), r(U[e])]
			}),
			/* @__PURE__ */ g("span", {
				className: "dc-score-track",
				children: [/* @__PURE__ */ g("span", { children: ["⚡ ", r("games.decrypto.interceptShort")] }), /* @__PURE__ */ h(Y, {
					earned: a.intercept,
					kind: "intercept",
					label: r("games.decrypto.interceptToken")
				})]
			}),
			/* @__PURE__ */ g("span", {
				className: "dc-score-track",
				children: [/* @__PURE__ */ g("span", { children: ["✕ ", r("games.decrypto.miscommShort")] }), /* @__PURE__ */ h(Y, {
					earned: a.miscomm,
					kind: "miscomm",
					label: r("games.decrypto.miscommToken")
				})]
			})
		]
	});
}
function X() {
	return /* @__PURE__ */ g("svg", {
		className: "dc-console-circuit",
		viewBox: "0 0 340 340",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ h("path", {
				d: "M12 330V250l35-35h85l28-28h105l60-60V8M325 330V260l-28-28h-84l-35-35H80L12 129V8",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ h("path", {
				d: "M50 330v-66l40-40h70m130 106v-55l-40-40h-74",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "12",
				cy: "129",
				r: "7",
				fill: "currentColor"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "325",
				cy: "127",
				r: "7",
				fill: "currentColor"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "160",
				cy: "187",
				r: "7",
				fill: "currentColor"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "178",
				cy: "197",
				r: "7",
				fill: "currentColor"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "50",
				cy: "264",
				r: "5",
				fill: "currentColor"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "290",
				cy: "275",
				r: "5",
				fill: "currentColor"
			})
		]
	});
}
function ve({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let o = c(), [s, l] = a(!1), u = (e) => e ? n.find((t) => t.rid === e)?.name ?? e : "", p = e.stage ?? "encrypt", m = p === "white" || p === "black", _ = p === "whiteReveal" || p === "blackReveal", v = e.activeTeam ? o(U[e.activeTeam]) : "", b = "info", x;
	p === "encrypt" ? t?.code ? (b = "accent", x = o("games.decrypto.encryptYou", { team: o(U[t.team]) })) : x = o("games.decrypto.encryptWait") : m ? t?.draftKind === "decrypt" ? (b = "accent", x = o("games.decrypto.guessDecrypt", { team: v })) : t?.draftKind === "intercept" ? (b = "accent", x = o("games.decrypto.guessIntercept", { team: v })) : x = t && e.activeTeam && e.encryptors[e.activeTeam] === r ? o("games.decrypto.guessWatchOnly") : o("games.decrypto.guessNoIntercept") : x = o("games.decrypto.revealTitle", { team: v });
	let S = o(p === "encrypt" ? "games.decrypto.signalDesk" : m ? "games.decrypto.signalFrom" : "games.decrypto.revealDesk"), C = /* @__PURE__ */ g("div", {
		className: "dc-top-stack",
		children: [
			/* @__PURE__ */ h("div", {
				className: "dc-phase flex h-16 flex-none flex-col justify-center",
				children: /* @__PURE__ */ h(d, {
					tone: b,
					text: x,
					chip: o("games.decrypto.roundChip", { n: e.round }),
					accent: y.accent
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "dc-score-rail flex-none",
				children: ["white", "black"].map((t) => /* @__PURE__ */ h(_e, {
					team: t,
					pub: e,
					active: e.activeTeam === t
				}, t))
			}),
			t && /* @__PURE__ */ h(J, { keywords: t.keywords })
		]
	}), w = /* @__PURE__ */ g("div", {
		className: "dc-footer flex h-full items-center justify-center gap-2",
		children: [
			p === "encrypt" && /* @__PURE__ */ h("div", {
				className: "dc-submission-rail",
				children: ["white", "black"].map((t) => /* @__PURE__ */ g("span", {
					className: e.cluesSubmitted[t] ? "is-submitted" : "",
					children: [/* @__PURE__ */ h("span", { children: o(U[t]) }), /* @__PURE__ */ h("strong", { children: e.cluesSubmitted[t] ? "✓" : "…" })]
				}, t))
			}),
			m && t?.draftKind && !t.draftLocked && /* @__PURE__ */ h(Se, {
				draft: t.draft ?? [],
				send: i
			}),
			m && t?.draftKind && t.draftLocked && t.draft && /* @__PURE__ */ h("p", {
				className: "dc-footer-status",
				children: o("games.decrypto.guessLocked", { code: t.draft.join("-") })
			}),
			m && !t?.draftKind && /* @__PURE__ */ h("p", {
				className: "dc-footer-status",
				children: o("games.decrypto.guessWaiting")
			}),
			_ && /* @__PURE__ */ h("button", {
				type: "button",
				className: "btn-base w-full cursor-pointer text-white",
				style: { background: y.accent },
				onClick: () => i({ type: "reveal:next" }),
				children: o("games.decrypto.next")
			})
		]
	});
	return /* @__PURE__ */ g("div", {
		className: "dc-root dc-play h-full min-h-0",
		children: [/* @__PURE__ */ h(f, {
			adaptive: !0,
			className: "dc-screen",
			banner: C,
			actions: w,
			actionsHeight: "dc-actions-slot",
			scroll: !1,
			children: /* @__PURE__ */ g("section", {
				className: "dc-console flex h-full min-h-0 flex-col",
				children: [
					/* @__PURE__ */ h(X, {}),
					/* @__PURE__ */ g("div", {
						className: "dc-console-head",
						children: [
							/* @__PURE__ */ g("svg", {
								viewBox: "0 0 38 28",
								"aria-hidden": !0,
								children: [
									/* @__PURE__ */ h("circle", {
										cx: "8",
										cy: "14",
										r: "5",
										fill: "var(--color-dc-shell-deep)",
										stroke: "var(--color-dc-navy)",
										strokeWidth: "2"
									}),
									/* @__PURE__ */ h("path", {
										d: "M6 14h4",
										stroke: "var(--color-dc-navy)",
										strokeWidth: "1.5"
									}),
									/* @__PURE__ */ h("path", {
										d: "M18 14h18",
										stroke: "var(--color-surface)",
										strokeWidth: "2"
									})
								]
							}),
							/* @__PURE__ */ h("span", {
								className: "dc-console-title",
								children: S
							}),
							e.history.length > 0 && /* @__PURE__ */ h("button", {
								type: "button",
								className: "dc-notes-button",
								onClick: () => l(!0),
								children: o("games.decrypto.history", { n: e.history.length })
							})
						]
					}),
					/* @__PURE__ */ g("div", {
						className: "dc-console-body flex min-h-0 flex-1 flex-col overflow-y-auto",
						children: [
							p === "encrypt" && /* @__PURE__ */ h(ye, {
								pub: e,
								priv: t,
								nameOf: u,
								send: i
							}),
							m && /* @__PURE__ */ h(be, {
								pub: e,
								priv: t,
								nameOf: u
							}),
							_ && /* @__PURE__ */ h(Z, {
								pub: e,
								priv: t
							})
						]
					}, `${e.round}:${p}`)
				]
			})
		}), /* @__PURE__ */ h(W, {
			open: s,
			onClose: () => l(!1),
			pub: e,
			myTeam: t?.team ?? "white",
			myKeywords: t?.keywords
		})]
	});
}
function ye({ pub: e, priv: t, nameOf: n, send: r }) {
	let i = c(), o = t?.code, [s, l] = a([
		"",
		"",
		""
	]);
	if (!o || !t) return /* @__PURE__ */ g("div", {
		className: "dc-wait",
		children: [
			/* @__PURE__ */ g("svg", {
				className: "dc-wait-signal",
				viewBox: "0 0 96 80",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ h("path", {
					d: "M48 67V38m-14 0a20 20 0 0 1 28 0m-39-11a35 35 0 0 1 50 0M12 16a51 51 0 0 1 72 0",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "5",
					strokeLinecap: "round"
				}), /* @__PURE__ */ h("circle", {
					cx: "48",
					cy: "70",
					r: "6",
					fill: "currentColor"
				})]
			}),
			/* @__PURE__ */ g("div", {
				className: "dc-wait-team",
				children: [/* @__PURE__ */ g("span", { children: [
					i(U.white),
					" · ",
					n(e.encryptors.white)
				] }), /* @__PURE__ */ h("strong", { children: e.cluesSubmitted.white ? "✓" : "…" })]
			}),
			/* @__PURE__ */ g("div", {
				className: "dc-wait-team",
				children: [/* @__PURE__ */ g("span", { children: [
					i(U.black),
					" · ",
					n(e.encryptors.black)
				] }), /* @__PURE__ */ h("strong", { children: e.cluesSubmitted.black ? "✓" : "…" })]
			})
		]
	});
	let u = s.every((e) => e.trim().length > 0), d = e.cluesSubmitted[t.team], f = d ? -1 : s.findIndex((e) => !e.trim());
	return /* @__PURE__ */ g("div", {
		className: "dc-encrypt",
		children: [
			/* @__PURE__ */ g("div", {
				className: "dc-code-strip",
				children: [/* @__PURE__ */ h("span", {
					className: "dc-strip-label",
					children: i("games.decrypto.codeIs")
				}), /* @__PURE__ */ h("span", {
					className: "dc-code-cards",
					children: o.map((e, t) => /* @__PURE__ */ h(q, { n: e }, t))
				})]
			}),
			o.map((e, n) => /* @__PURE__ */ g("label", {
				className: `dc-clue-editor ${n === f ? "is-next" : ""} ${s[n].trim() ? "is-complete" : ""}`,
				children: [/* @__PURE__ */ h(q, { n: e }), /* @__PURE__ */ g("span", {
					className: "dc-clue-editor-content",
					children: [/* @__PURE__ */ h("span", {
						className: "dc-clue-word",
						children: t.keywords[e - 1] ?? ""
					}), /* @__PURE__ */ h("input", {
						value: s[n],
						disabled: d,
						onChange: (e) => l((t) => t.map((t, r) => r === n ? e.target.value : t)),
						maxLength: 24,
						placeholder: i("games.decrypto.cluePh", { n: n + 1 }),
						"aria-label": i("games.decrypto.cluePh", { n: n + 1 }),
						className: "dc-clue-input"
					})]
				})]
			}, n)),
			/* @__PURE__ */ h("button", {
				type: "button",
				disabled: !u || d,
				onClick: () => r({
					type: "clue:give",
					clues: s.map((e) => e.trim())
				}),
				className: "btn-base dc-action-button w-full cursor-pointer text-white disabled:opacity-40",
				style: { background: y.accent },
				children: i("games.decrypto.submitClues")
			}),
			d && /* @__PURE__ */ h("p", {
				className: "dc-inline-status",
				role: "status",
				children: i("games.decrypto.encryptSubmitted", { team: i(U[t.team]) })
			})
		]
	});
}
function be({ pub: e, priv: t, nameOf: n }) {
	let r = c(), i = e.activeTeam ?? "white", a = e.activeClues;
	return /* @__PURE__ */ g("div", {
		className: "dc-guess",
		children: [
			/* @__PURE__ */ g("div", {
				className: "dc-signal-screen",
				children: [/* @__PURE__ */ g("div", {
					className: "dc-signal-head",
					children: [
						/* @__PURE__ */ h("span", { className: "dc-led dc-led-red" }),
						/* @__PURE__ */ g("span", { children: [
							r(U[i]),
							" · ",
							r("games.decrypto.encryptorBadge"),
							" ",
							n(e.encryptors[i])
						] }),
						/* @__PURE__ */ h("span", {
							className: "dc-signal-live",
							children: r("games.decrypto.signalLive")
						})
					]
				}), (a ?? []).map((e, t) => /* @__PURE__ */ g("div", {
					className: "dc-signal-line",
					children: [
						/* @__PURE__ */ h("span", {
							className: "dc-signal-index font-mono tabular-nums",
							children: String(t + 1).padStart(2, "0")
						}),
						/* @__PURE__ */ h("span", {
							className: "dc-signal-text",
							children: e
						}),
						/* @__PURE__ */ h("svg", {
							viewBox: "0 0 36 18",
							"aria-hidden": !0,
							children: /* @__PURE__ */ h("path", {
								d: "M0 9h10l4-7 6 14 5-10 3 3h8",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "1.5"
							})
						})
					]
				}, t))]
			}),
			/* @__PURE__ */ g("div", {
				className: "dc-lock-status",
				children: [/* @__PURE__ */ g("span", {
					className: e.locks.decrypt ? "is-locked" : "",
					children: [
						r("games.decrypto.decryptLabel"),
						" ",
						e.locks.decrypt ? "✓" : "…"
					]
				}), e.locks.intercept !== null && /* @__PURE__ */ g("span", {
					className: e.locks.intercept ? "is-locked" : "",
					children: [
						r("games.decrypto.interceptLabel"),
						" ",
						e.locks.intercept ? "✓" : "…"
					]
				})]
			}),
			t?.draftKind && /* @__PURE__ */ h(xe, {
				draft: t.draft ?? [],
				locked: t.draftLocked
			})
		]
	});
}
function xe({ draft: e, locked: t }) {
	let n = c();
	return /* @__PURE__ */ g("div", {
		className: "dc-draft",
		children: [/* @__PURE__ */ g("div", {
			className: "dc-draft-heading",
			children: [/* @__PURE__ */ h("span", { children: n("games.decrypto.myAnswer") }), /* @__PURE__ */ h("span", {
				"aria-live": "polite",
				children: t ? n("games.decrypto.answerSealed") : e.length === 3 ? n("games.decrypto.answerReady") : n("games.decrypto.pickDigit", { n: e.length + 1 })
			})]
		}), /* @__PURE__ */ g("div", {
			className: "dc-draft-slots",
			children: [[
				0,
				1,
				2
			].map((n) => /* @__PURE__ */ g("span", {
				className: `dc-draft-slot ${e[n] === void 0 ? "" : "is-filled"} ${!t && n === e.length ? "is-current" : ""}`,
				children: [/* @__PURE__ */ g("svg", {
					viewBox: "0 0 72 64",
					preserveAspectRatio: "none",
					"aria-hidden": !0,
					children: [/* @__PURE__ */ h("rect", {
						x: "2",
						y: "2",
						width: "68",
						height: "60",
						rx: "6",
						fill: e[n] === void 0 ? "var(--color-dc-lavender)" : "var(--color-surface)",
						stroke: n === e.length && !t ? "var(--color-dc-accent)" : "var(--color-ink)",
						strokeWidth: "3",
						strokeDasharray: e[n] === void 0 ? "6 4" : void 0
					}), e[n] !== void 0 && /* @__PURE__ */ h("path", {
						d: "M6 6h60v9H6z",
						fill: "var(--color-dc-accent)"
					})]
				}), /* @__PURE__ */ h("span", {
					className: "font-mono tabular-nums",
					children: e[n] ?? "?"
				})]
			}, n)), t && /* @__PURE__ */ h("span", {
				className: "dc-draft-seal",
				"aria-hidden": !0,
				children: "🔒"
			})]
		})]
	});
}
function Se({ draft: e, send: t }) {
	let n = c(), r = (e) => t({
		type: "guess:set",
		digits: e
	}), i = e.length === 3;
	return /* @__PURE__ */ g("div", {
		className: "dc-pad flex w-full flex-col gap-1.5",
		children: [/* @__PURE__ */ g("div", {
			className: "dc-pad-keys",
			children: [[
				1,
				2,
				3,
				4
			].map((t) => /* @__PURE__ */ h("button", {
				type: "button",
				disabled: i || e.includes(t),
				onClick: () => r([...e, t]),
				className: "dc-pad-key font-mono text-base font-extrabold tabular-nums",
				children: t
			}, t)), /* @__PURE__ */ h("button", {
				type: "button",
				"aria-label": n("games.decrypto.backspace"),
				disabled: e.length === 0,
				onClick: () => r(e.slice(0, -1)),
				className: "dc-pad-key dc-pad-delete font-mono text-base font-extrabold",
				children: "⌫"
			})]
		}), i ? /* @__PURE__ */ h(o, {
			className: "w-full",
			label: n("games.decrypto.lockGuess"),
			confirmLabel: n("games.decrypto.lockGuessConfirm", { code: e.join("-") }),
			ariaLabel: n("games.decrypto.lockGuess"),
			onConfirm: () => t({ type: "guess:lock" })
		}) : /* @__PURE__ */ h("button", {
			type: "button",
			disabled: !0,
			className: "btn-base w-full opacity-40",
			children: n("games.decrypto.lockGuess")
		})]
	});
}
function Z({ pub: e, priv: t }) {
	let n = c(), r = e.history[e.history.length - 1];
	if (!r) return null;
	let i = r.decrypt.digits.join() === r.code.join(), a = r.intercept !== null && r.intercept.digits.join() === r.code.join();
	return /* @__PURE__ */ g("div", {
		className: "dc-reveal",
		children: [
			/* @__PURE__ */ g("div", {
				className: "dc-reveal-code",
				children: [/* @__PURE__ */ h("span", {
					className: "dc-strip-label",
					children: n("games.decrypto.revealCode")
				}), /* @__PURE__ */ h("span", {
					className: "dc-code-cards",
					children: r.code.map((e, t) => /* @__PURE__ */ h(q, {
						n: e,
						size: "lg"
					}, t))
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: "dc-signal-screen dc-reveal-clues",
				children: r.clues.map((e, n) => /* @__PURE__ */ g("div", {
					className: "dc-signal-line",
					children: [
						/* @__PURE__ */ h("span", {
							className: "dc-signal-index font-mono tabular-nums",
							children: String(n + 1).padStart(2, "0")
						}),
						/* @__PURE__ */ h("span", {
							className: "dc-signal-text",
							children: e
						}),
						/* @__PURE__ */ g("span", {
							className: "dc-reveal-arrow",
							children: ["→ ", r.code[n]]
						}),
						t?.team === r.team && /* @__PURE__ */ h("span", {
							className: "dc-reveal-keyword",
							children: t.keywords[r.code[n] - 1]
						})
					]
				}, n))
			}),
			/* @__PURE__ */ g("div", {
				className: "dc-verdicts",
				children: [/* @__PURE__ */ g("p", {
					className: i ? "is-good" : "is-bad",
					children: [/* @__PURE__ */ g("span", {
						className: "dc-verdict-label",
						children: [
							i ? "✓" : "✗",
							" ",
							n(i ? "games.decrypto.decryptOk" : "games.decrypto.decryptBad")
						]
					}), /* @__PURE__ */ h("span", {
						className: "dc-verdict-digits font-mono tabular-nums",
						children: r.decrypt.digits.join("-")
					})]
				}), r.intercept ? /* @__PURE__ */ g("p", {
					className: a ? "is-good" : "is-bad",
					children: [/* @__PURE__ */ g("span", {
						className: "dc-verdict-label",
						children: [
							a ? "✓" : "✗",
							" ",
							n(a ? "games.decrypto.interceptOk" : "games.decrypto.interceptBad", { team: n(U[k(r.team)]) })
						]
					}), /* @__PURE__ */ h("span", {
						className: "dc-verdict-digits font-mono tabular-nums",
						children: r.intercept.digits.join("-")
					})]
				}) : /* @__PURE__ */ h("p", { children: n("games.decrypto.noIntercept") })]
			})
		]
	});
}
function Ce({ pub: e, priv: t, send: n }) {
	let r = c(), i = e.tie, a = t?.team;
	if (!i || !a) return null;
	let o = t?.tieLocked ?? !1, s = i.stage === "judge", l = k(a), u = i.guesses[l], p = i.judged[a], m = /* @__PURE__ */ g("div", {
		className: "dc-top-stack",
		children: [/* @__PURE__ */ h("div", {
			className: "dc-phase flex h-16 flex-none flex-col justify-center",
			children: /* @__PURE__ */ h(d, {
				tone: "accent",
				text: r("games.decrypto.tieTitle"),
				sub: r(s ? "games.decrypto.judgeYou" : "games.decrypto.tiePrompt"),
				accent: y.accent
			})
		}), /* @__PURE__ */ h(J, { keywords: t?.keywords ?? [] })]
	}), _ = /* @__PURE__ */ g("div", {
		className: "dc-footer flex h-full items-center justify-center gap-2",
		children: [
			!s && (o ? /* @__PURE__ */ h("p", {
				className: "dc-footer-status",
				children: r("games.decrypto.tieWait")
			}) : t && /* @__PURE__ */ h(Te, {
				priv: t,
				send: n
			})),
			s && p === null && t && u && /* @__PURE__ */ h(Ee, {
				enemyGuesses: u,
				keywords: t.keywords,
				send: n
			}),
			s && p === null && !u && /* @__PURE__ */ h("p", {
				className: "dc-footer-status",
				children: r("games.decrypto.judgeWait")
			}),
			s && p !== null && /* @__PURE__ */ h("p", {
				className: "dc-footer-status",
				children: r("games.decrypto.judgeWait")
			})
		]
	});
	return /* @__PURE__ */ h("div", {
		className: "dc-root dc-tiebreak h-full min-h-0",
		children: /* @__PURE__ */ h(f, {
			adaptive: !0,
			className: "dc-screen",
			banner: m,
			actions: _,
			actionsHeight: "dc-actions-slot",
			scroll: !1,
			children: /* @__PURE__ */ g("section", {
				className: "dc-console flex h-full min-h-0 flex-col",
				children: [
					/* @__PURE__ */ h(X, {}),
					/* @__PURE__ */ g("div", {
						className: "dc-console-head",
						children: [/* @__PURE__ */ g("svg", {
							viewBox: "0 0 38 28",
							"aria-hidden": !0,
							children: [/* @__PURE__ */ h("circle", {
								cx: "8",
								cy: "14",
								r: "5",
								fill: "var(--color-dc-shell-deep)",
								stroke: "var(--color-dc-navy)",
								strokeWidth: "2"
							}), /* @__PURE__ */ h("path", {
								d: "M6 14h4M18 14h18",
								stroke: "var(--color-dc-navy)",
								strokeWidth: "1.5"
							})]
						}), /* @__PURE__ */ h("span", {
							className: "dc-console-title",
							children: r(s ? "games.decrypto.foeGuesses" : "games.decrypto.tieEntry")
						})]
					}),
					/* @__PURE__ */ g("div", {
						className: "dc-console-body flex min-h-0 flex-1 flex-col gap-2 overflow-y-auto",
						children: [
							!s && t && /* @__PURE__ */ h(we, {
								priv: t,
								locked: o,
								send: n
							}),
							s && u && /* @__PURE__ */ g("div", {
								className: "dc-tie-received",
								children: [/* @__PURE__ */ h("span", {
									className: "dc-tie-team",
									style: {
										backgroundColor: V[l],
										color: H[l]
									},
									children: r(U[l])
								}), u.map((e, t) => /* @__PURE__ */ g("p", {
									className: "dc-tie-word",
									children: [/* @__PURE__ */ h("span", {
										className: "font-mono tabular-nums",
										children: t + 1
									}), e]
								}, t))]
							}),
							s && p !== null && /* @__PURE__ */ g("p", {
								className: "dc-watch-status",
								children: [r("games.decrypto.judgeDone", { n: p }), i.judged[l] === null && /* @__PURE__ */ h("span", {
									className: "block text-xs font-bold opacity-70",
									children: r("games.decrypto.judgeWait")
								})]
							})
						]
					}, i.stage)
				]
			})
		})
	});
}
function we({ priv: e, locked: t, send: n }) {
	let o = c(), [s, l] = a(() => [...e.tieDraft ?? [
		"",
		"",
		"",
		""
	]]), u = i(-1), d = e.tieDraft;
	r(() => {
		d && l((e) => e.map((e, t) => t === u.current ? e : d[t] ?? e));
	}, [d]);
	let f = (e) => {
		let t = [...d ?? [
			"",
			"",
			"",
			""
		]];
		t[e] = s[e] ?? "", n({
			type: "tie:set",
			words: t
		});
	};
	return /* @__PURE__ */ h("div", {
		className: "dc-tie-form",
		children: [
			0,
			1,
			2,
			3
		].map((e) => /* @__PURE__ */ g("label", {
			className: "dc-tie-input-row",
			children: [/* @__PURE__ */ h("span", {
				className: "dc-tie-number font-mono tabular-nums",
				children: e + 1
			}), /* @__PURE__ */ h("input", {
				value: s[e] ?? "",
				disabled: t,
				onChange: (t) => l((n) => n.map((n, r) => r === e ? t.target.value : n)),
				onFocus: () => {
					u.current = e;
				},
				onBlur: () => {
					u.current = -1, f(e);
				},
				maxLength: 24,
				placeholder: o("games.decrypto.tieWordPh", { n: e + 1 }),
				"aria-label": o("games.decrypto.tieWordPh", { n: e + 1 }),
				className: "dc-clue-input"
			})]
		}, e))
	});
}
function Te({ priv: e, send: t }) {
	let n = c(), r = e.tieDraft;
	return r !== null && r.length === 4 && r.every((e) => e.trim().length > 0) ? /* @__PURE__ */ h(o, {
		className: "w-full",
		label: n("games.decrypto.tieLock"),
		confirmLabel: n("games.decrypto.tieLockConfirm"),
		ariaLabel: n("games.decrypto.tieLock"),
		onConfirm: () => t({ type: "tie:lock" })
	}) : /* @__PURE__ */ h("button", {
		type: "button",
		disabled: !0,
		className: "btn-base w-full opacity-40",
		children: n("games.decrypto.tieLock")
	});
}
function Ee({ enemyGuesses: e, keywords: t, send: n }) {
	let r = c(), [i, s] = a(() => N(e, t));
	return /* @__PURE__ */ g("div", {
		className: "dc-judge-stepper",
		children: [
			/* @__PURE__ */ h("button", {
				type: "button",
				"aria-label": r("games.decrypto.judgeLess"),
				disabled: i <= 0,
				onClick: () => s((e) => Math.max(0, e - 1)),
				className: "size-11 cursor-pointer rounded-xl border-2 border-ink bg-surface font-mono text-xl font-extrabold disabled:opacity-30",
				children: "−"
			}),
			/* @__PURE__ */ h("span", {
				className: "w-10 text-center font-mono text-3xl font-extrabold tabular-nums",
				children: i
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				"aria-label": r("games.decrypto.judgeMore"),
				disabled: i >= Q,
				onClick: () => s((e) => Math.min(Q, e + 1)),
				className: "size-11 cursor-pointer rounded-xl border-2 border-ink bg-surface font-mono text-xl font-extrabold disabled:opacity-30",
				children: "+"
			}),
			/* @__PURE__ */ h(o, {
				className: "flex-1",
				label: r("games.decrypto.judgeConfirm", { n: i }),
				confirmLabel: r("games.decrypto.judgeConfirm", { n: i }),
				ariaLabel: r("games.decrypto.judgeConfirm", { n: i }),
				onConfirm: () => n({
					type: "tie:judge",
					count: i
				})
			})
		]
	});
}
var Q = 4, $ = (e) => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e, De = (e) => {
	let t = e.public, n = e.private;
	if (!n) return null;
	if (t.phase === "play") {
		if (t.stage === "encrypt") return n.code && !t.cluesSubmitted[n.team] ? { action: {
			type: "clue:give",
			clues: [
				0,
				1,
				2
			].map((e) => `X${t.round}${e}${$(9e3) + 1e3}`)
		} } : null;
		if (t.stage === "white" || t.stage === "black") {
			if (!n.draftKind || n.draftLocked) return null;
			let e = n.draft ?? [];
			if (e.length < 3) {
				let t = [
					1,
					2,
					3,
					4
				].filter((t) => !e.includes(t));
				return { action: {
					type: "guess:set",
					digits: [...e, t[$(t.length)]]
				} };
			}
			return { action: { type: "guess:lock" } };
		}
		return { action: { type: "reveal:next" } };
	}
	if (t.phase === "tiebreak" && t.tie) {
		if (t.tie.stage === "guess") return n.tieLocked ? null : (n.tieDraft ?? []).every((e) => e.trim().length > 0) ? { action: { type: "tie:lock" } } : { action: {
			type: "tie:set",
			words: [
				"甲",
				"乙",
				"丙",
				"丁"
			]
		} };
		if (t.tie.judged[n.team] === null) {
			let e = t.tie.guesses[k(n.team)];
			return e ? { action: {
				type: "tie:judge",
				count: N(e, n.keywords)
			} } : null;
		}
	}
	return null;
}, Oe = { token(e, t) {
	let n = e.data;
	if (n?.team !== "white" && n?.team !== "black") return null;
	let r = t.anchor(`tokens:${n.team}`);
	if (!r) return null;
	let i = n?.token === "intercept", a = Math.max(36, Math.min(64, r.h * .5));
	return {
		ms: 900,
		node: /* @__PURE__ */ h(_, {
			at: r,
			ms: 900,
			children: /* @__PURE__ */ h("span", {
				className: `grid place-items-center rounded-full border-3 border-ink font-extrabold ${i ? "bg-white text-black" : "bg-black text-white"}`,
				style: {
					width: a,
					height: a,
					fontSize: a * .45
				},
				children: i ? "⚡" : "✕"
			})
		})
	};
} };
//#endregion
//#region src/games/decrypto/game-over.tsx
function ke({ public: e, private: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let o = c(), s = e, l = t ? O.safeParse(t) : null, d = l?.success ? l.data.team : "white", [f, p] = a(!1), m = s.winner, _ = m === "white" || m === "black" ? m : null, b = _ ? k(_) : null, x = (e) => n.find((t) => t.rid === e), S = r ?? i, C = (e) => s.tokens[e].intercept - s.tokens[e].miscomm, w = (e) => s.tie?.judged[k(e)] ?? 0, T = (() => {
		if (!_ || !b) return o("games.decrypto.endShared");
		let e = o(U[_]);
		switch (s.endDetail) {
			case "intercept": return o("games.decrypto.endIntercept", { team: e });
			case "mistake": return o("games.decrypto.endMistake", {
				loser: o(U[b]),
				winner: e
			});
			case "score": return o("games.decrypto.endScore", {
				winner: e,
				a: C(_),
				b: C(b)
			});
			case "keywords": return o("games.decrypto.endKeywords", {
				winner: e,
				a: w(_),
				b: w(b)
			});
			default: return o("games.decrypto.endShared");
		}
	})(), E = _ ? [_, b] : ["white", "black"];
	return /* @__PURE__ */ g("div", {
		className: "dc-over relative flex h-full min-h-0 flex-col gap-2",
		children: [
			m !== null && /* @__PURE__ */ h(v, {}),
			/* @__PURE__ */ g("div", {
				className: "dc-over-content",
				children: [/* @__PURE__ */ g("section", {
					className: "dc-over-summary",
					children: [
						/* @__PURE__ */ g("h1", {
							className: "dc-over-banner flex flex-none items-center gap-2 text-center font-display text-xl font-extrabold",
							children: [/* @__PURE__ */ h("span", {
								"aria-hidden": !0,
								children: "📟"
							}), T]
						}),
						/* @__PURE__ */ h("div", {
							className: "dc-over-scores flex w-full flex-none justify-center gap-2",
							children: E.map((e) => /* @__PURE__ */ g("span", {
								className: "dc-over-score flex min-h-11 items-center gap-1.5 border-2 border-ink px-2 text-xs font-extrabold",
								style: {
									backgroundColor: V[e],
									color: H[e]
								},
								children: [o(U[e]), /* @__PURE__ */ g("span", {
									className: "font-mono tabular-nums",
									children: [
										"⚡",
										s.tokens[e].intercept,
										" ✕",
										s.tokens[e].miscomm
									]
								})]
							}, e))
						}),
						s.finalKeywords && /* @__PURE__ */ g("div", {
							className: "dc-over-words flex w-full flex-none flex-col gap-1",
							children: [/* @__PURE__ */ h("span", {
								className: "dc-over-section-label",
								children: o("games.decrypto.finalKeywords")
							}), E.map((e) => /* @__PURE__ */ h("div", {
								className: "dc-over-word-row grid grid-cols-4 gap-1",
								style: {
									backgroundColor: V[e],
									color: H[e]
								},
								children: s.finalKeywords[e].map((e, t) => /* @__PURE__ */ g("span", {
									className: "dc-over-word flex min-w-0 items-center gap-1 border-2 border-ink px-1 py-0.5 text-[11px] font-extrabold",
									children: [/* @__PURE__ */ h("span", {
										className: "flex-none font-mono tabular-nums",
										children: t + 1
									}), /* @__PURE__ */ h("span", {
										className: "truncate",
										children: e
									})]
								}, t))
							}, e))]
						}),
						s.tie && s.tie.guesses.white && s.tie.guesses.black && /* @__PURE__ */ h("p", {
							className: "flex-none text-xs font-bold opacity-80",
							children: o("games.decrypto.tieResult", {
								w: w("white"),
								b: w("black")
							})
						})
					]
				}), /* @__PURE__ */ g("section", {
					className: "dc-over-review",
					children: [/* @__PURE__ */ h("div", {
						className: "dc-over-members flex w-full flex-none flex-col gap-1",
						children: E.map((e) => /* @__PURE__ */ g("div", {
							className: "dc-over-member-row flex items-center gap-1.5",
							children: [/* @__PURE__ */ g("span", {
								className: "dc-over-team-label flex w-14 flex-none items-center gap-0.5 text-xs font-extrabold",
								children: [/* @__PURE__ */ h("span", {
									"aria-hidden": !0,
									className: `w-4 flex-none ${m === "both" || m === e ? "" : "invisible"}`,
									children: "🏆"
								}), o(U[e])]
							}), /* @__PURE__ */ h("div", {
								className: "dc-over-team-members flex min-w-0 flex-1 flex-wrap gap-1",
								children: s.teams[e].map((e) => /* @__PURE__ */ h(u, {
									member: x(e),
									rid: e
								}, e))
							})]
						}, e))
					}), s.history.length > 0 && /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => p(!0),
						className: "dc-over-notes flex min-h-11 flex-none cursor-pointer items-center border-2 border-ink bg-surface px-3 text-xs font-bold shadow-[2px_2px_0_var(--color-ink)]",
						children: o("games.decrypto.history", { n: s.history.length })
					})]
				})]
			}),
			S ? /* @__PURE__ */ g("div", {
				className: "dc-over-actions safe-b flex w-full flex-none flex-col gap-2 pb-1",
				children: [r && /* @__PURE__ */ h("button", {
					className: "btn-base w-full cursor-pointer text-white",
					style: { background: y.accent },
					onClick: r,
					children: o("session.result.playAgain")
				}), i && /* @__PURE__ */ h("button", {
					className: "btn-quiet w-full cursor-pointer",
					onClick: i,
					children: o("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ h("p", {
				className: "dc-over-wait safe-b flex-none pb-1 text-center text-sm font-bold opacity-70",
				children: o("session.result.waitHost")
			}),
			/* @__PURE__ */ h(W, {
				open: f,
				onClose: () => p(!1),
				pub: s,
				myTeam: d
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/decrypto/entry.tsx
var Ae = {
	definition: de,
	View: pe,
	bot: De,
	fx: Oe,
	OverView: ke,
	locales: {
		zh: {
			name: "谍报风云",
			desc: "两队密码战:给队友加密,破译截对手",
			rules: "目标:先集齐 2 个拦截指示物的队伍获胜;集齐 2 个错误传讯指示物的队伍落败。\n准备:\n· 全员分成白队与黑队,每队至少 2 人。\n· 每队各持有 4 个关键词(编号 ①-④),只有本队成员能看到。\n流程:\n· 每轮两队各由一名加密者(按队内顺序轮换)秘密抽取一个三位密码:1-4 中 3 个不重复数字的排列,并依次写下 3 条提示。\n· 白队提示先公布:白队解读自家密码,黑队同时尝试拦截;双方锁定答案后揭晓。\n· 随后公布黑队提示,黑队解读、白队拦截,同样结算。\n· 第一轮双方不能拦截,但仍要解读自家密码。\n· 一轮结束检查胜负;未分胜负则进入下一轮,最多 8 轮。\n计分:\n· 本队解读错误:本队获得 1 个错误传讯指示物。\n· 拦截对方成功:本队获得 1 个拦截指示物;两者可在同一半场同时发生。\n提示规范:\n· 提示必须与关键词含义相关;不能包含关键词本身,不能与已公布过的提示重复。\n· 不能借发音、字数、位置等游戏外信息提示;提示公布后不能修改。\n平局:\n· 双方同时达成胜负条件,或 8 轮结束未分胜负:按「拦截数减错误数」计分,高者胜。\n· 仍平:双方各猜对方 4 个关键词,命中多者胜;再平则共享胜利。",
			white: "白队",
			black: "黑队",
			teamsTitle: "拖入队伍 · 顺序决定加密者",
			teamsWait: "主机正在分组…",
			teamDropHint: "拖玩家到这里 · 至少 2 人",
			unassigned: "待分配",
			shuffle: "随机分组",
			startGame: "开始游戏",
			startGameConfirm: "确认分组,开局?",
			roundChip: "第{{n}}轮",
			encryptorBadge: "加密者",
			history: "笔记 {{n}}",
			historyTitle: "笔记纸",
			historyEmpty: "还没有已揭晓的回合",
			digitNotes: "数字线索",
			roundList: "轮次记录",
			codeLabel: "密码",
			foeDecrypt: "对方解读",
			myIntercept: "我方拦截",
			myDecrypt: "我方解读",
			foeIntercept: "对方拦截",
			myTeamTag: "我方",
			foeTeamTag: "对方",
			interceptToken: "拦截指示物",
			miscommToken: "错误传讯指示物",
			interceptShort: "拦截",
			miscommShort: "失误",
			decryptLabel: "解读",
			interceptLabel: "拦截",
			backspace: "退格",
			judgeLess: "少算一个",
			judgeMore: "多算一个",
			encryptYou: "为{{team}}写 3 条提示",
			encryptWait: "等待两队提示",
			encryptSubmitted: "{{team}}已提交",
			codeIs: "本轮密码",
			signalDesk: "传讯台",
			signalFrom: "收到的线索",
			revealDesk: "解密记录",
			signalLive: "接收中",
			clueForWord: "第 {{n}} 条 → {{pos}}号「{{word}}」",
			cluePh: "提示 {{n}}",
			submitClues: "公布提示",
			keywordsMine: "本队关键词",
			guessDecrypt: "解读{{team}}密码",
			guessIntercept: "拦截{{team}}的密码",
			guessWatchOnly: "加密者旁观解读",
			guessNoIntercept: "首轮不能拦截 · 记住线索",
			guessWaiting: "等双方锁定答案…",
			myAnswer: "我方答案",
			pickDigit: "选择第 {{n}} 位",
			answerReady: "可以锁定",
			answerSealed: "答案已封存",
			lockGuess: "锁定答案",
			lockGuessConfirm: "锁定 {{code}}?",
			guessLocked: "已锁定 {{code}}",
			revealTitle: "{{team}}密码揭晓",
			revealCode: "正确密码",
			decryptOk: "解读成功",
			decryptBad: "解读错误,错误传讯 +1",
			interceptOk: "{{team}}拦截成功,拦截 +1",
			interceptBad: "{{team}}拦截失败",
			noIntercept: "第一轮无拦截",
			next: "继续",
			tieTitle: "平局!互猜关键词",
			tiePrompt: "讨论并猜出对方的 4 个关键词",
			tieEntry: "填入对方关键词",
			tieWordPh: "关键词 {{n}}",
			tieLock: "锁定猜测",
			tieLockConfirm: "锁定这 4 个词?",
			tieWait: "等对方提交猜测…",
			judgeYou: "核对对方猜测:命中了几个?",
			foeGuesses: "对方猜测",
			judgeWait: "等对方核对我方命中数…",
			judgeConfirm: "确认命中 {{n}} 个",
			judgeDone: "已确认对方命中 {{n}} 个",
			endIntercept: "{{team}}两次拦截成功,破译对手!",
			endMistake: "{{loser}}两次错误传讯,{{winner}}获胜!",
			endScore: "平局计分:{{winner}} {{a}} 比 {{b}} 获胜!",
			endKeywords: "猜词决胜:{{winner}} {{a}} 比 {{b}} 获胜!",
			endShared: "棋逢对手,两队共享胜利!",
			finalKeywords: "关键词揭晓",
			tieResult: "平局猜词:白队命中 {{w}} 个 · 黑队命中 {{b}} 个",
			errNotHost: "只有主机能操作分组",
			errBadTeams: "分组里有重复或不在场的人",
			errTeamsNotReady: "全员都要入队,每队至少 2 人",
			errBadStage: "现在不能这么操作",
			errNotEncryptor: "本轮你不是加密者",
			errAlreadySubmitted: "提示已提交过了",
			errClueKeyword: "提示不能包含本队关键词",
			errClueDup: "三条提示不能重复",
			errClueRepeat: "不能与已公布过的提示重复",
			errNotGuesser: "现在轮不到你猜",
			errNoIntercept: "第一轮不能拦截",
			errLocked: "你们已经锁定答案了",
			errBadDigits: "答案是 1-4 里不重复的 3 个数字",
			errTieWords: "4 个词都要填"
		},
		en: {
			name: "Decrypto",
			desc: "Team code war: clue your side, crack theirs",
			rules: "Goal: the first team to collect 2 Interception tokens wins; a team with 2 Miscommunication tokens loses.\nSetup:\n· Split into White and Black teams, at least 2 players each.\n· Each team holds 4 keywords (①-④), visible only to teammates.\nPlay:\n· Each round, one Encryptor per team (rotating in seat order) secretly draws a 3-digit code — a permutation of 1-4 — and writes 3 clues in order.\n· White clues are revealed first: White decodes their own code while Black tries to intercept; both lock in answers, then the code is revealed.\n· Then Black clues are revealed; Black decodes and White intercepts.\n· In round 1 neither team may intercept, but you still decode your own code.\n· Win/loss is checked at the end of each round; at most 8 rounds.\nScoring:\n· Decode your own code wrong: your team takes 1 Miscommunication token.\n· Intercept the enemy code: your team takes 1 Interception token; both can happen in the same half-round.\nClue rules:\n· Clues must relate to the keyword's meaning; never contain the keyword itself, never repeat a clue already given.\n· No hints via sounds, word length or positions; clues cannot be changed once revealed.\nTiebreak:\n· If both teams trigger a win/loss condition at once, or 8 rounds pass: score = interceptions minus miscommunications, higher wins.\n· Still tied: each team guesses the enemy's 4 keywords; most hits wins; still tied, the victory is shared.",
			white: "White",
			black: "Black",
			teamsTitle: "Drag into teams · order sets Encryptors",
			teamsWait: "Host is assigning teams…",
			teamDropHint: "Drop players here · at least 2",
			unassigned: "Unassigned",
			shuffle: "Shuffle",
			startGame: "Start game",
			startGameConfirm: "Lock teams and start?",
			roundChip: "Round {{n}}",
			encryptorBadge: "Encryptor",
			history: "Notes {{n}}",
			historyTitle: "Notepad",
			historyEmpty: "Nothing revealed yet",
			digitNotes: "Digit clues",
			roundList: "Rounds",
			codeLabel: "Code",
			foeDecrypt: "Their decode",
			myIntercept: "Our intercept",
			myDecrypt: "Our decode",
			foeIntercept: "Their intercept",
			myTeamTag: "ours",
			foeTeamTag: "theirs",
			interceptToken: "Interception token",
			miscommToken: "Miscommunication token",
			interceptShort: "Intercept",
			miscommShort: "Mistake",
			decryptLabel: "Decode",
			interceptLabel: "Intercept",
			backspace: "Delete digit",
			judgeLess: "One fewer hit",
			judgeMore: "One more hit",
			encryptYou: "Write 3 clues for {{team}}",
			encryptWait: "Waiting for both teams’ clues",
			encryptSubmitted: "{{team}} submitted",
			codeIs: "Code this round",
			signalDesk: "Transmit desk",
			signalFrom: "Incoming clues",
			revealDesk: "Decoded record",
			signalLive: "LIVE",
			clueForWord: "Clue {{n}} → #{{pos}} \"{{word}}\"",
			cluePh: "Clue {{n}}",
			submitClues: "Reveal clues",
			keywordsMine: "Your keywords",
			guessDecrypt: "Decode the {{team}} code",
			guessIntercept: "Intercept the {{team}} code",
			guessWatchOnly: "Encryptor watches the decode",
			guessNoIntercept: "No round 1 intercept · note clues",
			guessWaiting: "Waiting for both teams to lock in…",
			myAnswer: "Our answer",
			pickDigit: "Choose digit {{n}}",
			answerReady: "Ready to lock",
			answerSealed: "Answer sealed",
			lockGuess: "Lock answer",
			lockGuessConfirm: "Lock {{code}}?",
			guessLocked: "Locked {{code}}",
			revealTitle: "{{team}} code revealed",
			revealCode: "Actual code",
			decryptOk: "Decoded correctly",
			decryptBad: "Decode failed: Miscommunication +1",
			interceptOk: "{{team}} intercepted: Interception +1",
			interceptBad: "{{team}} failed to intercept",
			noIntercept: "No interception in round 1",
			next: "Continue",
			tieTitle: "Tie! Guess enemy keywords",
			tiePrompt: "Discuss and guess the enemy's 4 keywords",
			tieEntry: "Enter enemy keywords",
			tieWordPh: "Keyword {{n}}",
			tieLock: "Lock guesses",
			tieLockConfirm: "Lock these 4 words?",
			tieWait: "Waiting for the enemy guesses…",
			judgeYou: "Check enemy guesses: how many hits?",
			foeGuesses: "Enemy guesses",
			judgeWait: "Enemy is confirming our hits…",
			judgeConfirm: "Confirm {{n}} hits",
			judgeDone: "Confirmed {{n}} enemy hits",
			endIntercept: "{{team}} intercepted twice and cracked the enemy!",
			endMistake: "{{loser}} miscommunicated twice — {{winner}} win!",
			endScore: "Tiebreak score: {{winner}} win {{a}} to {{b}}!",
			endKeywords: "Keyword duel: {{winner}} win {{a}} to {{b}}!",
			endShared: "Dead even — victory shared!",
			finalKeywords: "Keywords revealed",
			tieResult: "Keyword duel: White hit {{w}} · Black hit {{b}}",
			errNotHost: "Only the host can assign teams",
			errBadTeams: "Duplicate or absent players in teams",
			errTeamsNotReady: "Everyone must join a team; at least 2 per team",
			errBadStage: "Not allowed right now",
			errNotEncryptor: "You are not the Encryptor this round",
			errAlreadySubmitted: "Clues already submitted",
			errClueKeyword: "A clue cannot contain one of your keywords",
			errClueDup: "The three clues must differ",
			errClueRepeat: "Cannot repeat a clue already given",
			errNotGuesser: "Not your guess to make",
			errNoIntercept: "No interception in round 1",
			errLocked: "Your team already locked in",
			errBadDigits: "Answer is 3 distinct digits from 1-4",
			errTieWords: "All 4 words are required"
		}
	}
};
//#endregion
export { Ae as default };
