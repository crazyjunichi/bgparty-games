import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { DICE_ROLL_MS as t } from "@bgparty/sdk/fx/dice-roll-ms";
import { z as n } from "zod";
import { Fragment as r, Suspense as i, useEffect as a, useLayoutEffect as o, useMemo as s, useRef as c, useState as l } from "react";
import { useFxAnchor as u, useFxAnchorsMaybe as d } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as f, useT as p } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as m } from "@bgparty/sdk/player-colors";
import { playTurn as h, useSoundEdge as g } from "@bgparty/sdk/sfx";
import { GameScreen as _ } from "@bgparty/sdk/ui/game-screen";
import { useFrame as v, useLoader as ee, useThree as y } from "@react-three/fiber";
import { BackSide as b, CanvasTexture as x, ClampToEdgeWrapping as te, DoubleSide as S, SRGBColorSpace as C, ShaderMaterial as w, Shape as ne, TextureLoader as T, Vector3 as E } from "three";
import { usePrefersReducedMotion as re } from "@bgparty/sdk/fx/use-reduced-motion";
import { ResilientCanvas as ie } from "@bgparty/sdk/three/resilient-canvas";
import { Fragment as D, jsx as O, jsxs as k } from "react/jsx-runtime";
import { DICE_ROLL_MS as A, createDiceRollRenderer as j } from "@bgparty/sdk/fx/dice-roll";
import { Floater as M, FlySprite as N, PulseBox as P } from "@bgparty/sdk/fx/primitives";
import { DiceCube as ae } from "@bgparty/sdk/fx/dice-cube";
import { IconBack as F, IconBot as oe, IconExpand as I, IconLog as se } from "@bgparty/sdk/icons";
import { seatName as ce } from "@bgparty/sdk/ui/player-strip";
import { Confetti as le } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as ue, OptionSection as de, OptionSwitch as fe } from "@bgparty/sdk/ui/game-options";
//#region src/games/lairs/cards.ts
var L = [
	{
		id: 300,
		base: 1,
		type: "shard",
		keyword: null
	},
	{
		id: 301,
		base: 1,
		type: "crown",
		keyword: null
	},
	{
		id: 302,
		base: 1,
		type: "cup",
		keyword: "harmony"
	},
	{
		id: 303,
		base: 1,
		type: "amulet",
		keyword: null
	},
	{
		id: 304,
		base: 1,
		type: "shard",
		keyword: null
	},
	{
		id: 305,
		base: 1,
		type: "book",
		keyword: "harmony"
	},
	{
		id: 306,
		base: 1,
		type: "cup",
		keyword: "discord"
	},
	{
		id: 307,
		base: 1,
		type: "amulet",
		keyword: "discord"
	},
	{
		id: 308,
		base: 1,
		type: "orb",
		keyword: "harmony"
	},
	{
		id: 309,
		base: 1,
		type: "orb",
		keyword: "discord"
	},
	{
		id: 310,
		base: 1,
		type: "shard",
		keyword: null
	},
	{
		id: 311,
		base: 1,
		type: "book",
		keyword: "discord"
	},
	{
		id: 312,
		base: 1,
		type: "amulet",
		keyword: null
	},
	{
		id: 313,
		base: 2,
		type: "book",
		keyword: null
	},
	{
		id: 314,
		base: 2,
		type: "scroll",
		keyword: null
	},
	{
		id: 315,
		base: 2,
		type: "scroll",
		keyword: "harmony"
	},
	{
		id: 316,
		base: 2,
		type: "orb",
		keyword: null
	},
	{
		id: 317,
		base: 2,
		type: "crown",
		keyword: null
	},
	{
		id: 318,
		base: 2,
		type: "statue",
		keyword: "discord"
	},
	{
		id: 319,
		base: 3,
		type: "scroll",
		keyword: null
	},
	{
		id: 320,
		base: 3,
		type: "statue",
		keyword: "discord"
	},
	{
		id: 321,
		base: 3,
		type: "crown",
		keyword: null
	},
	{
		id: 322,
		base: 1,
		type: "instrument",
		keyword: null
	},
	{
		id: 323,
		base: 1,
		type: "instrument",
		keyword: null
	},
	{
		id: 324,
		base: 1,
		type: "instrument",
		keyword: null
	},
	{
		id: 325,
		base: 2,
		type: "amulet",
		keyword: null
	}
], R = new Map(L.map((e) => [e.id, e])), pe = L.map((e) => e.id);
function me(e, t, n) {
	let r = t.filter((t) => t !== e).map((e) => R.get(e)), i = (e) => r.filter((t) => t.type === e).length;
	switch (e) {
		case 300: return (r.some((e) => e.id === 304) ? 2 : 0) + (r.some((e) => e.id === 310) ? 2 : 0);
		case 304: return (r.some((e) => e.id === 300) ? 2 : 0) + (r.some((e) => e.id === 310) ? 2 : 0);
		case 310: return (r.some((e) => e.id === 300) ? 2 : 0) + (r.some((e) => e.id === 304) ? 2 : 0);
		case 301: return n.exitedFirst ? 4 : 0;
		case 302: return i("cup") > 0 ? 4 : 0;
		case 303: return n.monstersDefeated;
		case 305: return i("book") > 0 ? 3 : 0;
		case 306: return 2 * n.monstersDefeated;
		case 307: return i("amulet") > 0 ? 4 : 0;
		case 308: return i("orb") > 0 ? 4 : 0;
		case 309: return i("orb") > 0 ? 3 : 0;
		case 311: return i("book") > 0 ? 4 : 0;
		case 312: return n.chestsOpened;
		case 313: return n.monstersDefeated >= 2 ? 2 : 0;
		case 314: return n.mapFullyKnown ? 3 : 0;
		case 315: return t.every((e) => R.get(e)?.keyword !== "discord") ? 3 : 0;
		case 316: return n.trapsDisarmed;
		case 317: return +(i("crown") > 0) + (n.mapFullyKnown ? 3 : 0);
		case 318: return i("statue");
		case 319: return 2 * r.filter((e) => e.keyword === "harmony").length;
		case 320: return 2 * t.filter((e) => R.get(e)?.keyword === "discord").length;
		case 321: return i("crown");
		case 325: return 5 * i("instrument");
		default: return 0;
	}
}
function he(e, t, n) {
	t = t.filter((e) => !n.forcedTucked?.includes(e));
	let r = e.length - t.length;
	for (let e of t) {
		let i = R.get(e);
		i && (r += i.base + me(e, t, n));
	}
	return r;
}
var ge = [
	0,
	0,
	2,
	6
];
function _e(e, t) {
	e = e.filter((e) => !t.forcedTucked?.includes(e));
	let n = [], r = -1, i = e.length;
	for (let a = 0; a <= Math.min(4, i); a += 1) {
		let o = [], s = (c) => {
			if (o.length === a) {
				let i = o.map((t) => e[t]), a = he(e, i, t);
				a > r && (r = a, n = i);
				return;
			}
			for (let e = c; e < i; e += 1) o.push(e), s(e + 1), o.pop();
		};
		s(0);
	}
	return n;
}
var z = (e) => [Math.floor(e / 6), e % 6], ve = (e, t) => e * 6 + t, ye = (e, t) => e * 5 + t, be = (e, t) => 30 + e * 6 + t, xe = [
	[-1, 0],
	[0, 1],
	[1, 0],
	[0, -1]
];
function B(e, t) {
	let [n, r] = z(e), [i, a] = xe[t], o = n + i, s = r + a;
	return o >= 0 && o < 6 && s >= 0 && s < 6 ? ve(o, s) : -1;
}
function Se(e, t) {
	let [n, r] = z(e), [i, a] = z(t);
	return n === i && Math.abs(r - a) === 1 ? ye(n, Math.min(r, a)) : r === a && Math.abs(n - i) === 1 ? be(Math.min(n, i), r) : -1;
}
function V(e, t, n) {
	let r = B(t, n);
	return r < 0 || e.has(Se(t, r));
}
function Ce(e) {
	let t = Array.from({ length: 36 }, () => null);
	t[e.start] = "start", t[e.exit] = "exit";
	for (let n of e.chests) t[n] = "chest";
	for (let n of e.traps) t[n] = "trap";
	for (let n of e.monsters) t[n] = "monster";
	return t;
}
function we(e, t) {
	let n = /* @__PURE__ */ new Set([t]), r = [t];
	for (; r.length;) {
		let t = r.pop();
		for (let i = 0; i < 4; i += 1) {
			if (V(e, t, i)) continue;
			let a = B(t, i);
			a >= 0 && !n.has(a) && (n.add(a), r.push(a));
		}
	}
	return n;
}
function Te(e, t, n, r) {
	let i = /* @__PURE__ */ new Set(), a = (e, t, n) => e * 9 + t * 3 + n, o = [[
		n,
		0,
		0
	]];
	for (i.add(a(n, 0, 0)); o.length;) {
		let [n, s, c] = o.pop();
		if (n === r) return !0;
		for (let r = 0; r < 4; r += 1) {
			if (V(e, n, r)) continue;
			let l = B(n, r);
			if (l < 0) continue;
			let u = t[l], d = u === "monster" ? s + 1 : s, f = u === "trap" ? c + 1 : c;
			if (d > 1 || f > 1) continue;
			let p = a(l, d, f);
			i.has(p) || (i.add(p), o.push([
				l,
				d,
				f
			]));
		}
	}
	return !1;
}
function Ee(e) {
	let t = [
		e.start,
		e.exit,
		...e.chests,
		...e.traps,
		...e.monsters
	];
	if (e.chests.length !== 3 || e.traps.length !== 3 || e.monsters.length !== 3) return "errFeatureCount";
	if (t.some((e) => !Number.isInteger(e) || e < 0 || e >= 36)) return "errFeatureCell";
	if (new Set(t).size !== t.length) return "errFeatureOverlap";
	if (e.walls.length < 17 || e.walls.length > 20) return "errWallCount";
	if (new Set(e.walls).size !== e.walls.length) return "errWallDup";
	if (e.walls.some((e) => !Number.isInteger(e) || e < 0 || e >= 60)) return "errWallIdx";
	let n = new Set(e.walls);
	if (we(n, e.start).size !== 36) return "errNotConnected";
	let r = Ce(e);
	for (let t of [e.exit, ...e.chests]) if (!Te(n, r, e.start, t)) return "errPeril";
	return null;
}
function De(e) {
	let t = (t) => Math.floor(e() * t);
	for (let e = 0; e < 300; e += 1) {
		let e = Array.from({ length: 36 }, (e, t) => t);
		for (let n = e.length - 1; n > 0; --n) {
			let r = t(n + 1);
			[e[n], e[r]] = [e[r], e[n]];
		}
		let n = {
			walls: [],
			start: e[0],
			exit: e[1],
			chests: e.slice(2, 5),
			traps: e.slice(5, 8),
			monsters: e.slice(8, 11)
		}, r = Array.from({ length: 60 }, (e, t) => t);
		for (let e = r.length - 1; e > 0; --e) {
			let n = t(e + 1);
			[r[e], r[n]] = [r[n], r[e]];
		}
		let i = /* @__PURE__ */ new Set();
		for (let e of r) {
			if (i.size >= 20) break;
			i.add(e);
			let t = Ce(n);
			we(i, n.start).size === 36 && [n.exit, ...n.chests].every((e) => Te(i, t, n.start, e)) || i.delete(e);
		}
		if (i.size >= 17) return {
			...n,
			walls: [...i]
		};
	}
	throw Error("genMaze: no valid maze in 300 attempts");
}
//#endregion
//#region src/games/lairs/meta.ts
var Oe = {
	id: "lairs",
	tier: "beta",
	mechanics: [
		"tile-placement",
		"dice-rolling",
		"action-points"
	],
	interactionTags: [],
	nameKey: "games.lairs.name",
	descKey: "games.lairs.desc",
	rulesKey: "games.lairs.rules",
	icon: "🏰",
	iconImg: "games/lairs.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/lairs/en.pdf" },
	precacheAssets: [
		"board.webp",
		"chest.webp",
		"monster.webp",
		"trap.webp",
		"exit.webp",
		"sun-shard.webp",
		"hero-crown.webp",
		"lore-book.webp"
	],
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#c58f51",
	releasedAt: "2026-09-27",
	search: {
		py: "qing jun ru keng",
		init: "qjrk"
	},
	hotseat: "cover",
	botDelayMs: 2e3
}, ke = n.union([
	n.literal(0),
	n.literal(1),
	n.literal(2),
	n.literal(3)
]), H = n.int().min(0).max(35), Ae = n.int().min(0).max(59), je = n.int().min(300).max(325), Me = n.enum([
	"white",
	"quick",
	"perc",
	"know",
	"brawn",
	"guile"
]), Ne = n.enum([
	"blob",
	"tangle",
	"autoflail",
	"golem",
	"whisper",
	"forge",
	"pit",
	"blink",
	"gremling",
	"walls",
	"mantle",
	"sentry",
	"screamer",
	"banish",
	"acid"
]), Pe = n.object({
	mode: n.enum(["base", "adventure"]).default("base"),
	stage: n.int().min(1).max(4).default(4),
	selection: n.enum([
		"random",
		"manual",
		"draft"
	]).default("random"),
	boxZero: n.boolean().default(!1),
	monsters: n.array(Ne).length(3).default([
		"blob",
		"tangle",
		"autoflail"
	]),
	traps: n.array(Ne).length(3).default([
		"pit",
		"blink",
		"gremling"
	])
}).prefault({}), Fe = n.object({
	kind: Me,
	from: n.enum(["fresh", "conserved"]),
	double: n.boolean().optional()
}), U = n.array(Fe).min(1).max(12).optional(), Ie = n.object({
	walls: n.array(Ae).max(20),
	start: H,
	exit: H,
	chests: n.array(H).length(3),
	traps: n.array(H).length(3),
	monsters: n.array(H).length(3)
}), Le = n.discriminatedUnion("type", [
	n.object({
		type: n.literal("draftHazard"),
		id: Ne
	}),
	n.object({
		type: n.literal("chooseAttributes"),
		kinds: n.array(Me).length(3)
	}),
	n.object({
		type: n.literal("adventureChoice"),
		indices: n.array(n.int().nonnegative()).max(36)
	}),
	n.object({
		type: n.literal("charge"),
		dir: ke,
		pay: U
	}),
	n.object({
		type: n.literal("sneak"),
		dir: ke,
		pay: U
	}),
	n.object({
		type: n.literal("scrounge"),
		pay: U
	}),
	n.object({
		type: n.literal("scavenge"),
		pay: U
	}),
	n.object({
		type: n.literal("recover"),
		pay: U
	}),
	n.object({
		type: n.literal("improvise"),
		pay: U
	}),
	n.object({ type: n.literal("finishCheck") }),
	n.object({
		type: n.literal("useJunk"),
		index: n.int().nonnegative(),
		cell: H.optional(),
		to: H.optional(),
		die: n.int().nonnegative().optional(),
		delta: n.int().min(-2).max(2).optional(),
		dir: ke.optional()
	}),
	n.object({
		type: n.literal("useFlute"),
		cell: H,
		to: H,
		pay: U
	}),
	n.object({
		type: n.literal("build"),
		maze: Ie
	}),
	n.object({
		type: n.literal("pickFirst"),
		rid: n.string()
	}),
	n.object({
		type: n.literal("creep"),
		dir: ke,
		pay: U
	}),
	n.object({
		type: n.literal("hustle"),
		pay: U
	}),
	n.object({
		type: n.literal("move"),
		dir: ke
	}),
	n.object({ type: n.literal("stopHustle") }),
	n.object({
		type: n.literal("backtrack"),
		to: H,
		pay: U
	}),
	n.object({
		type: n.literal("peer"),
		dir: ke,
		pay: U
	}),
	n.object({
		type: n.literal("fight"),
		dice: n.int().min(0).max(12),
		pay: U
	}),
	n.object({
		type: n.literal("disarm"),
		dice: n.int().min(0).max(12),
		pay: U
	}),
	n.object({
		type: n.literal("chooseFatigue"),
		cubes: n.array(n.object({
			kind: Me,
			from: n.enum([
				"spent",
				"fresh",
				"conserved"
			])
		})).min(1).max(3)
	}),
	n.object({
		type: n.literal("chooseTreasure"),
		index: n.int().min(0).max(2)
	}),
	n.object({ type: n.literal("exit") }),
	n.object({
		type: n.literal("conserve"),
		cubes: n.array(Me).min(1).max(3)
	}),
	n.object({ type: n.literal("endTurn") }),
	n.object({
		type: n.literal("reveal"),
		cards: n.array(je).max(4)
	}),
	n.object({
		type: n.literal("tick"),
		now: n.number()
	})
]), Re = n.object({
	white: n.int().nonnegative(),
	quick: n.int().nonnegative(),
	perc: n.int().nonnegative(),
	know: n.int().nonnegative().default(0),
	brawn: n.int().nonnegative().default(0),
	guile: n.int().nonnegative().default(0)
}), ze = n.object({
	walls: n.tuple([
		n.boolean(),
		n.boolean(),
		n.boolean(),
		n.boolean()
	]),
	feature: n.enum([
		"start",
		"exit",
		"chest",
		"trap",
		"monster",
		"empty"
	]),
	resolved: n.boolean(),
	monsterTarget: n.int().min(0).nullable(),
	hazardId: Ne.optional(),
	hidden: n.boolean().optional()
}), Be = n.object({
	rid: n.string(),
	submitted: n.boolean(),
	pos: H,
	known: n.record(n.string(), ze),
	fresh: Re,
	spent: Re,
	fatigued: Re,
	conserved: n.array(Me),
	chests: n.int().min(0).max(3),
	monsters: n.int().min(0),
	traps: n.int().min(0),
	hoardCount: n.int().nonnegative(),
	escaped: n.boolean(),
	exitOrder: n.int().min(0).max(2)
}), Ve = n.object({
	phase: n.enum([
		"draft",
		"attributes",
		"build",
		"pickFirst",
		"explore",
		"finalTurn",
		"handoff",
		"scoring",
		"done"
	]),
	turn: n.string().nullable(),
	handoff: n.object({
		from: n.string(),
		to: n.string().nullable(),
		fxMs: n.number().nonnegative()
	}).nullable(),
	buildOrder: n.array(n.string()),
	firstExplorer: n.string().nullable(),
	players: n.array(Be),
	display: n.array(je).max(3),
	deckCount: n.int().nonnegative(),
	discardCount: n.int().nonnegative(),
	hustleLeft: n.int().min(0).max(5),
	pendingChest: n.boolean(),
	pendingFatigue: n.object({
		n: n.int().min(1).max(3),
		freshOnly: n.boolean()
	}).nullable(),
	pendingHazard: n.enum(["monster", "trap"]).nullable(),
	peerFree: H.nullable(),
	lastCheck: n.object({
		id: n.int().nonnegative(),
		cell: H,
		kind: n.enum(["fight", "disarm"]),
		dice: n.int().min(0).max(36),
		success: n.boolean(),
		total: n.int().optional(),
		target: n.int().optional()
	}).nullable(),
	scoringDone: n.record(n.string(), n.boolean()),
	final: n.object({
		revealed: n.record(n.string(), n.array(je)),
		breakdown: n.record(n.string(), n.object({
			treasures: n.int(),
			monsters: n.int(),
			exit: n.int(),
			total: n.int()
		}))
	}).nullable(),
	adventure: n.object({
		config: Pe,
		monsters: n.array(Ne).max(3),
		traps: n.array(Ne).max(3),
		draftActor: n.string().nullable(),
		draftKind: n.enum(["monster", "trap"]),
		pending: n.object({
			kind: n.string(),
			actor: n.string(),
			min: n.int(),
			max: n.int()
		}).nullable(),
		check: n.object({
			stage: n.enum([
				"rolled",
				"monster",
				"resolve"
			]),
			kind: n.enum(["fight", "disarm"]),
			cell: H,
			target: n.int(),
			dice: n.array(n.object({
				value: n.int(),
				power: n.boolean(),
				source: Me.nullable()
			})),
			monsterDice: n.array(n.union([n.number(), n.literal("skull")])),
			modifier: n.int(),
			total: n.int()
		}).nullable(),
		players: n.record(n.string(), n.object({
			junkCount: n.int(),
			searched: n.array(H),
			located: n.array(H),
			wallNotes: n.array(Ae),
			enraging: n.enum([
				"fatigued",
				"spent",
				"fresh"
			]).nullable(),
			attributesChosen: n.boolean(),
			extraVP: n.int()
		})),
		scavengeCell: H.nullable(),
		freeDice: n.array(n.boolean()),
		scroungeFree: n.boolean(),
		junkDeckCount: n.int(),
		junkDiscardCount: n.int()
	}).optional()
}), He = n.object({
	maze: Ie.nullable(),
	hoard: n.array(je),
	adventure: n.object({
		junk: n.array(n.int().min(0).max(25)),
		forcedTucked: n.array(je),
		hazardCells: n.record(n.string(), Ne),
		appraisal: n.array(je),
		options: n.array(n.object({
			cell: H.optional(),
			wall: Ae.optional(),
			card: je.optional(),
			junk: n.int().min(0).max(25).optional(),
			cube: Me.optional(),
			from: n.enum([
				"fresh",
				"spent",
				"fatigued",
				"conserved"
			]).optional(),
			hazard: Ne.optional(),
			skip: n.boolean().optional()
		}))
	}).optional()
}), Ue = [
	"white",
	"quick",
	"perc",
	"know",
	"brawn",
	"guile"
], We = () => ({
	white: 0,
	quick: 0,
	perc: 0,
	know: 0,
	brawn: 0,
	guile: 0
}), W = (e) => Ue.reduce((t, n) => t + e[n], 0), Ge = [
	1,
	2,
	2,
	3,
	3,
	4
], Ke = [
	3,
	4,
	4,
	5,
	5,
	6
], qe = [
	0,
	0,
	-1,
	-1,
	-2,
	"skull"
], G = {
	white: "games.lairs.cubeWhite",
	quick: "games.lairs.cubeQuick",
	perc: "games.lairs.cubePerc",
	know: "games.lairs.cubeKnow",
	brawn: "games.lairs.cubeBrawn",
	guile: "games.lairs.cubeGuile"
}, Je = [
	{
		id: "blob",
		name: "games.lairs.hBlob",
		text: "games.lairs.hBlobText",
		kind: "monster",
		category: "nature",
		stage: 1,
		targets: [
			6,
			8,
			8,
			8
		],
		weak: ["brawn", "quick"]
	},
	{
		id: "tangle",
		name: "games.lairs.hTangle",
		text: "games.lairs.hTangleText",
		kind: "monster",
		category: "nature",
		stage: 1,
		targets: [
			8,
			10,
			10,
			10
		],
		weak: ["brawn", "perc"]
	},
	{
		id: "autoflail",
		name: "games.lairs.hAutoflail",
		text: "games.lairs.hAutoflailText",
		kind: "monster",
		category: "machine",
		stage: 2,
		targets: [
			11,
			11,
			11,
			12
		],
		weak: ["brawn", "know"]
	},
	{
		id: "golem",
		name: "games.lairs.hGolem",
		text: "games.lairs.hGolemText",
		kind: "monster",
		category: "magic",
		stage: 3,
		targets: [
			13,
			13,
			13,
			13
		],
		weak: ["brawn", "guile"]
	},
	{
		id: "whisper",
		name: "games.lairs.hWhisper",
		text: "games.lairs.hWhisperText",
		kind: "monster",
		category: "magic",
		stage: 4,
		targets: [
			9,
			9,
			9,
			9
		],
		weak: ["brawn", "perc"],
		hidden: !0,
		placement: "deadend"
	},
	{
		id: "forge",
		name: "games.lairs.hForge",
		text: "games.lairs.hForgeText",
		kind: "monster",
		category: "machine",
		stage: 4,
		targets: [
			19,
			19,
			19,
			19
		],
		weak: ["brawn", "quick"]
	},
	{
		id: "pit",
		name: "games.lairs.hPit",
		text: "games.lairs.hPitText",
		kind: "trap",
		category: "machine",
		stage: 1,
		targets: [
			5,
			5,
			5,
			5
		],
		weak: ["guile", "quick"]
	},
	{
		id: "blink",
		name: "games.lairs.hBlink",
		text: "games.lairs.hBlinkText",
		kind: "trap",
		category: "magic",
		stage: 1,
		targets: [
			7,
			7,
			7,
			7
		],
		weak: ["guile", "perc"]
	},
	{
		id: "gremling",
		name: "games.lairs.hGremling",
		text: "games.lairs.hGremlingText",
		kind: "trap",
		category: "nature",
		stage: 2,
		targets: [
			7,
			7,
			7,
			7
		],
		weak: ["guile", "know"]
	},
	{
		id: "walls",
		name: "games.lairs.hWalls",
		text: "games.lairs.hWallsText",
		kind: "trap",
		category: "machine",
		stage: 3,
		targets: [
			8,
			8,
			8,
			8
		],
		weak: ["guile", "quick"],
		hidden: !0,
		placement: "corridor"
	},
	{
		id: "mantle",
		name: "games.lairs.hMantle",
		text: "games.lairs.hMantleText",
		kind: "trap",
		category: "magic",
		stage: 3,
		targets: [
			7,
			7,
			7,
			7
		],
		weak: ["guile", "know"]
	},
	{
		id: "sentry",
		name: "games.lairs.hSentry",
		text: "games.lairs.hSentryText",
		kind: "monster",
		category: "machine",
		stage: 1,
		targets: [
			8,
			14,
			14,
			14
		],
		weak: ["brawn", "quick"],
		zero: !0
	},
	{
		id: "screamer",
		name: "games.lairs.hScreamer",
		text: "games.lairs.hScreamerText",
		kind: "monster",
		category: "magic",
		stage: 1,
		targets: [
			6,
			10,
			10,
			10
		],
		weak: ["brawn", "guile"],
		zero: !0
	},
	{
		id: "banish",
		name: "games.lairs.hBanish",
		text: "games.lairs.hBanishText",
		kind: "trap",
		category: "machine",
		stage: 1,
		targets: [
			5,
			7,
			7,
			7
		],
		weak: ["guile", "know"],
		zero: !0
	},
	{
		id: "acid",
		name: "games.lairs.hAcid",
		text: "games.lairs.hAcidText",
		kind: "trap",
		category: "nature",
		stage: 1,
		targets: [
			6,
			8,
			8,
			8
		],
		weak: ["guile", "perc"],
		zero: !0
	}
], K = Object.fromEntries(Je.map((e) => [e.id, e])), Ye = (e, t, n) => Je.filter((r) => r.stage <= e && (!r.zero || t) && (!n || r.kind === n)), Xe = (e) => Ue.slice(1, e === 1 ? 4 : e === 2 ? 5 : 6), Ze = [
	{
		id: 0,
		stage: 1,
		count: 1,
		name: "games.lairs.jShield",
		text: "games.lairs.jShieldText"
	},
	{
		id: 1,
		stage: 1,
		count: 1,
		name: "games.lairs.jBread",
		text: "games.lairs.jBreadText"
	},
	{
		id: 2,
		stage: 1,
		count: 1,
		name: "games.lairs.jDiary",
		text: "games.lairs.jDiaryText"
	},
	{
		id: 3,
		stage: 1,
		count: 1,
		name: "games.lairs.jManual",
		text: "games.lairs.jManualText"
	},
	{
		id: 4,
		stage: 1,
		count: 1,
		name: "games.lairs.jDagger",
		text: "games.lairs.jDaggerText"
	},
	{
		id: 5,
		stage: 1,
		count: 1,
		name: "games.lairs.jMirror",
		text: "games.lairs.jMirrorText"
	},
	{
		id: 6,
		stage: 1,
		count: 2,
		name: "games.lairs.jCoffee",
		text: "games.lairs.jCoffeeText"
	},
	{
		id: 7,
		stage: 1,
		count: 2,
		name: "games.lairs.jTracks",
		text: "games.lairs.jTracksText"
	},
	{
		id: 8,
		stage: 1,
		count: 2,
		name: "games.lairs.jScroll",
		text: "games.lairs.jScrollText"
	},
	{
		id: 9,
		stage: 1,
		count: 2,
		name: "games.lairs.jCheese",
		text: "games.lairs.jCheeseText"
	},
	{
		id: 10,
		stage: 1,
		count: 2,
		name: "games.lairs.jMap",
		text: "games.lairs.jMapText"
	},
	{
		id: 11,
		stage: 1,
		count: 2,
		name: "games.lairs.jCandle",
		text: "games.lairs.jCandleText"
	},
	{
		id: 12,
		stage: 1,
		count: 2,
		name: "games.lairs.jChalk",
		text: "games.lairs.jChalkText"
	},
	{
		id: 13,
		stage: 1,
		count: 1,
		name: "games.lairs.jWand",
		text: "games.lairs.jWandText"
	},
	{
		id: 14,
		stage: 1,
		count: 2,
		name: "games.lairs.jRope",
		text: "games.lairs.jRopeText"
	},
	{
		id: 15,
		stage: 1,
		count: 1,
		name: "games.lairs.jCloak",
		text: "games.lairs.jCloakText"
	},
	{
		id: 16,
		stage: 2,
		count: 1,
		name: "games.lairs.jLantern",
		text: "games.lairs.jLanternText"
	},
	{
		id: 17,
		stage: 2,
		count: 1,
		name: "games.lairs.jNotes",
		text: "games.lairs.jNotesText"
	},
	{
		id: 18,
		stage: 2,
		count: 1,
		name: "games.lairs.jStrength",
		text: "games.lairs.jStrengthText"
	},
	{
		id: 19,
		stage: 2,
		count: 1,
		name: "games.lairs.jSpeed",
		text: "games.lairs.jSpeedText"
	},
	{
		id: 20,
		stage: 3,
		count: 1,
		name: "games.lairs.jPowder",
		text: "games.lairs.jPowderText"
	},
	{
		id: 21,
		stage: 3,
		count: 1,
		name: "games.lairs.jWeedkiller",
		text: "games.lairs.jWeedkillerText"
	},
	{
		id: 22,
		stage: 3,
		count: 1,
		name: "games.lairs.jWrench",
		text: "games.lairs.jWrenchText"
	},
	{
		id: 23,
		stage: 3,
		count: 1,
		name: "games.lairs.jRune",
		text: "games.lairs.jRuneText"
	},
	{
		id: 24,
		stage: 3,
		count: 1,
		name: "games.lairs.jBlanket",
		text: "games.lairs.jBlanketText"
	},
	{
		id: 25,
		stage: 3,
		count: 1,
		name: "games.lairs.jShovel",
		text: "games.lairs.jShovelText"
	}
], Qe = new Map(Ze.map((e) => [e.id, e]));
//#endregion
//#region src/games/lairs/adventure-maze.ts
function $e(e, t, n) {
	let r = K[n].placement;
	if (!r) return !0;
	let i = new Set(e.walls), a = [
		0,
		1,
		2,
		3
	].map((e) => V(i, t, e));
	return r === "deadend" ? a.filter(Boolean).length === 3 : a.filter(Boolean).length === 2 && (a[0] && a[2] || a[1] && a[3]);
}
function et(e, t, n) {
	return Ee(e) || (t.some((t, n) => !$e(e, e.monsters[n], t)) || n.some((t, n) => !$e(e, e.traps[n], t)) ? "errHazardPlacement" : null);
}
function tt(e, t, n) {
	for (let r = 0; r < 300; r++) {
		let r = De(e), i = /* @__PURE__ */ new Set(), a = !0;
		for (let [o, s] of [[r.monsters, t], [r.traps, n]]) for (let t = 0; t < s.length; t++) {
			if (!K[s[t]].placement) continue;
			let n = Array.from({ length: 36 }, (e, t) => t).filter((e) => !i.has(e) && $e(r, e, s[t]));
			if (!n.length) {
				a = !1;
				break;
			}
			let c = n[Math.floor(e() * n.length)], l = o[t];
			if (r.start === c) r.start = l;
			else if (r.exit === c) r.exit = l;
			else for (let e of [
				r.chests,
				r.monsters,
				r.traps
			]) {
				let t = e.indexOf(c);
				if (t >= 0) {
					e[t] = l;
					break;
				}
			}
			o[t] = c, i.add(c);
		}
		if (a && !et(r, t, n)) return r;
	}
	throw Error("genAdventureMaze: no valid maze");
}
//#endregion
//#region src/games/lairs/adventure.ts
var q = (e) => e.adventure, J = (e, t) => e.players.find((e) => e !== t), nt = (e) => W(e.fresh) + e.conserved.length * 2, rt = (e) => e.chests >= 3 || e.monsters >= 3 || e.chests >= 2 && e.monsters >= 2, Y = (e = "errBusy") => ({ code: `games.lairs.${e}` }), it = (t, n) => e(t.seed, t.rngCursor++, n);
function at(e, t) {
	for (let n = t.length - 1; n > 0; n--) {
		let r = it(e, n + 1);
		[t[n], t[r]] = [t[r], t[n]];
	}
	return t;
}
function ot(e, t = !1) {
	let n = q(e);
	return t ? (n.junkDeck.length || (n.junkDeck = at(e, n.junkDiscard.splice(0))), n.junkDeck.shift() ?? null) : (e.deck.length || (e.deck = at(e, e.discard.splice(0))), e.deck.shift() ?? null);
}
function st(e, t, n) {
	let r = q(e), i = r.players[t];
	for (let t = 0; t < n; t++) {
		let t = ot(e, !0);
		t != null && i.junk.push(t);
	}
	let a = i.junk.length - 3;
	a > 0 && r.tasks.unshift({
		job: "discardJunk",
		actor: t,
		n: a
	});
}
function ct(e, t) {
	let n = ot(e);
	n != null && e.ps[t].hoard.push(n);
}
function lt(e, t) {
	let n = () => ({
		junk: [],
		forcedTucked: [],
		searched: [],
		located: [],
		wallNotes: [],
		hazardCells: {},
		cleared: [],
		opened: [],
		scavengeUsed: [],
		enraging: null,
		attributesChosen: t.stage === 1,
		extraVP: 0,
		cubesAdded: 0
	});
	e.adventure = {
		config: t,
		monsters: [],
		traps: [],
		players: Object.fromEntries(e.players.map((e) => [e, n()])),
		tasks: [],
		junkDeck: [],
		junkDiscard: [],
		check: null,
		freeDice: [],
		scavengeCell: null,
		lastFrom: 0,
		turns: 0
	};
	let r = q(e);
	e.deck = at(e, pe.filter((e) => t.stage >= 2 || e <= 321)), e.display = e.deck.splice(0, 3), r.junkDeck = at(e, Ze.filter((e) => e.stage <= t.stage).flatMap((e) => Array(e.count).fill(e.id)));
	for (let n of e.players) e.ps[n].spent = {
		...We(),
		white: 3,
		...t.stage === 1 ? {
			quick: 1,
			perc: 1,
			know: 1
		} : {}
	};
	if (t.stage <= 2) r.monsters = t.stage === 1 ? [
		"blob",
		"blob",
		"tangle"
	] : [
		"blob",
		"tangle",
		"autoflail"
	], r.traps = t.stage === 1 ? [
		"pit",
		"pit",
		"blink"
	] : [
		"pit",
		"blink",
		"gremling"
	];
	else if (t.selection === "draft") e.phase = "draft";
	else for (let n of ["monster", "trap"]) {
		let i = Ye(t.stage, t.boxZero, n).map((e) => e.id), a = n === "monster" ? t.monsters : t.traps, o = new Set(a).size === 3 && a.every((e) => i.includes(e)), s = t.selection === "manual" && o ? [...a] : at(e, i.map((e) => ut.indexOf(e))).slice(0, 3).map((e) => ut[e]);
		n === "monster" ? r.monsters = s : r.traps = s;
	}
}
var ut = Ye(4, !0).map((e) => e.id);
function dt(e) {
	let t = q(e), n = t.monsters.length + t.traps.length;
	return {
		actor: e.phase === "draft" ? e.players[n % 2] : null,
		kind: t.monsters.length < 3 ? "monster" : "trap"
	};
}
function ft(e, t, n) {
	let r = q(e), i = J(e, t), a = r.players[i].hazardCells[n], o = r.players[t].cleared.includes(n);
	if (a && !o) return {
		feature: K[a].kind,
		id: a,
		resolved: !1
	};
	let s = Ce(e.ps[i].maze)[n];
	return s === "monster" || s === "trap" || o || r.players[t].opened.includes(n) ? {
		feature: "empty",
		resolved: !0
	} : {
		feature: s ?? "empty",
		resolved: e.ps[t].known[n]?.resolved ?? !1
	};
}
function pt(e, t, n, r = !1) {
	let i = e.ps[t], a = e.ps[J(e, t)].maze, o = ft(e, t, n), s = !!o.id && !!K[o.id].hidden && !r && !i.known[n]?.hazardId, c = new Set(a.walls);
	i.known[n] = {
		walls: [
			0,
			1,
			2,
			3
		].map((e) => V(c, n, e)),
		feature: s ? "empty" : o.feature,
		resolved: o.resolved,
		...o.id && !s ? { hazardId: o.id } : {}
	};
}
function mt(e, t, n, r, i) {
	let a = e.ps[t], o = structuredClone(a);
	if (r) {
		let e = i && r.length === 1 && r[0].kind === i && !r[0].double, t = 0;
		for (let e of r) if (e.from === "fresh") {
			if (e.double || o.fresh[e.kind] < 1) return !1;
			o.fresh[e.kind]--, o.spent[e.kind]++, t++;
		} else {
			let n = o.conserved.indexOf(e.kind);
			if (n < 0) return !1;
			o.conserved.splice(n, 1), e.double ? (o.spent[e.kind]++, t += 2) : (o.fresh[e.kind]++, t++);
		}
		if (t !== (e ? 1 : n)) return !1;
	} else if (i && (o.fresh[i] || o.conserved.includes(i))) o.fresh[i] ? (o.fresh[i]--, o.spent[i]++) : (o.conserved.splice(o.conserved.indexOf(i), 1), o.fresh[i]++);
	else {
		if (nt(o) < n) return !1;
		for (let e of Ue) for (; n && o.fresh[e];) o.fresh[e]--, o.spent[e]++, n--;
		for (; n;) {
			let e = o.conserved.shift();
			n--, o.fresh[e]++, n && (n--, o.fresh[e]--, o.spent[e]++);
		}
	}
	return a.fresh = o.fresh, a.spent = o.spent, a.conserved = o.conserved, !0;
}
function ht(e, t) {
	return t.flatMap((t) => t === "conserved" ? e.conserved.map((e) => ({
		cube: e,
		from: t
	})) : t ? Ue.flatMap((n) => Array.from({ length: e[t][n] }, () => ({
		cube: n,
		from: t
	}))) : []);
}
function gt(e, t, n, r = t.cube) {
	t.from === "conserved" ? e.conserved.splice(e.conserved.indexOf(t.cube), 1) : e[t.from][t.cube]--, e[n][r]++;
}
function X(e, t, n, r, i = !1) {
	q(e).tasks.push({
		job: "fatigue",
		actor: t,
		n,
		cube: r,
		freshOnly: i
	});
}
function _t(e, t) {
	let n = q(e), r = e.ps[t.actor], i = n.players[t.actor], a = [], o = [
		"fatigue",
		"discardJunk",
		"discardTreasure",
		"refresh",
		"blanket",
		"learn",
		"walls"
	].includes(t.job) ? t.n ?? 1 : 1, s = o;
	switch (t.job) {
		case "fatigue":
			if (a = ht(r, [
				"spent",
				"fresh",
				"conserved"
			]), t.cube) {
				let e = a.filter((e) => e.cube === t.cube);
				e.length && (a = e);
			}
			if (t.freshOnly) {
				let e = a.filter((e) => e.from !== "spent");
				e.length && (a = e);
			}
			o = s = Math.min(t.n ?? 1, a.length);
			break;
		case "shield":
			a = [{ skip: !0 }, ...i.junk.flatMap((e, t) => e === 0 ? [{
				junk: e,
				cell: t
			}] : [])];
			break;
		case "discardJunk":
			a = i.junk.map((e) => ({ junk: e })), o = s = Math.min(o, a.length);
			break;
		case "discardTreasure":
			a = r.hoard.map((e) => ({ card: e })), o = s = Math.min(o, a.length);
			break;
		case "discardEither":
			a = [...i.junk.map((e) => ({ junk: e })), ...r.hoard.map((e) => ({ card: e }))];
			break;
		case "tuck":
			a = r.hoard.filter((e) => !i.forcedTucked.includes(e)).map((e) => ({ card: e }));
			break;
		case "downgrade":
			a = ht(r, [
				"spent",
				"fatigued",
				"fresh",
				"conserved"
			]).filter((e) => e.cube === t.cube);
			break;
		case "refresh":
			a = ht(r, t.mode === "cheese" ? ["spent", "fatigued"] : ["spent"]), o = s = Math.min(o, a.length);
			break;
		case "exchange":
			a = ht(r, ["fresh", "conserved"]);
			break;
		case "recover":
			a = ht(r, ["fatigued"]);
			break;
		case "blanket":
			a = ht(r, [
				"spent",
				"fresh",
				"conserved"
			]);
			break;
		case "adapt":
			a = [{ skip: !0 }, ...Xe(n.config.stage).concat("white").flatMap((e) => t.cards.map((t) => ({
				cube: e,
				from: "spent",
				junk: t
			})))];
			break;
		case "scrounge":
		case "appraiseKeep":
			a = (t.cards ?? []).map((e) => t.job === "scrounge" ? { junk: e } : { card: e });
			break;
		case "appraise":
			a = [{ skip: !0 }, ...r.fresh.perc || r.conserved.includes("perc") ? [{ cube: "perc" }] : []];
			break;
		case "shovel":
			a = [{ skip: !0 }, ...i.junk.flatMap((e, t) => e === 25 ? [{
				junk: e,
				cell: t
			}] : [])];
			break;
		case "learn":
		case "locate":
		case "teleport":
		case "spawn":
			a = (t.cells ?? []).map((e) => ({ cell: e }));
			break;
		case "walls":
			a = (t.cells ?? []).map((e) => ({ wall: e })), o = s = Math.min(o, a.length);
			break;
		case "return":
			a = [{ cell: t.to }];
			break;
		case "ignore":
			a = [
				{ skip: !0 },
				...r.hoard.includes(323) && !i.forcedTucked.includes(323) && (r.fresh.perc || r.conserved.includes("perc")) ? [{ card: 323 }] : [],
				...i.junk.flatMap((e, t) => e === 15 ? [{
					junk: e,
					cell: t
				}] : [])
			];
			break;
		case "rope": a = [{ skip: !0 }, ...i.junk.flatMap((e, t) => e === 14 ? [{
			junk: e,
			cell: t
		}] : [])];
	}
	return a.length || (o = s = 0), {
		options: a,
		min: o,
		max: s
	};
}
function vt(e) {
	let t = q(e);
	for (; t.tasks.length && !_t(e, t.tasks[0]).options.length;) {
		let n = t.tasks.shift();
		n.job === "discardEither" && X(e, n.actor, 1);
	}
}
function yt(e, t) {
	let n = q(e), r = e.ps[t], i = n.players[t], a = Ue.flatMap((e) => Array(r.fatigued[e]).fill(Ue.indexOf(e)));
	for (let e of Ue) r.fresh[e] += r.spent[e], r.spent[e] = r.fatigued[e], r.fatigued[e] = 0;
	i.enraging = i.enraging === "fatigued" ? "spent" : i.enraging === "spent" ? "fresh" : null, e.turn = t, e.hustleLeft = 0, e.peerFree = null, e.pendingHazard = null, e.pendingChest = !1, n.freeDice = [], n.scavengeCell = null, n.check = null, n.turns++, n.config.stage >= 2 && a.length && n.tasks.push({
		job: "adapt",
		actor: t,
		cards: [...new Set(a)]
	});
}
function bt(e, t, n) {
	e.handoff = {
		from: e.turn,
		to: t,
		nextPhase: n,
		fxMs: 350
	}, e.phase = "handoff";
}
function xt(e) {
	e.peerFree = null, bt(e, e.phase === "finalTurn" ? null : J(e, e.turn), e.phase === "finalTurn" ? "scoring" : "explore");
}
function St(e, t, n) {
	let r = q(e);
	r.players[t].cleared.includes(n) || r.players[t].cleared.push(n), e.ps[t].known[n].resolved = !0;
}
function Ct(e, t, n, r) {
	let i = q(e);
	e.ps[t].known[n].resolved = !0, e.ps[t].chests++, i.players[t].opened.push(n), i.scavengeCell = n;
	let a = ot(e);
	a == null ? (e.pendingChest = e.display.length > 0, i.players[t].junk.includes(25) && i.tasks.push({
		job: "shovel",
		actor: t
	})) : i.tasks.push({
		job: "appraise",
		actor: t,
		cards: [a]
	}), r.push({
		kind: "chest",
		rid: t,
		data: { cell: n }
	});
}
function wt(e, t, n, r, i = "creep", a = !1) {
	let o = q(e), s = e.ps[t], c = s.known[n], l = !!c && (!K[o.players[J(e, t)].hazardCells[n]]?.hidden || !!c.hazardId), u = s.pos, d = e.hustleLeft;
	s.pos = n, o.lastFrom = u, e.peerFree = null, o.scavengeCell = null, pt(e, t, n, !0);
	let f = ft(e, t, n);
	if (r.push({
		kind: "move",
		rid: t,
		data: {
			from: u,
			to: n
		}
	}), c || r.push({
		kind: "reveal",
		rid: t,
		data: { cell: n },
		with: !0
	}), f.feature !== "empty" && !f.resolved && (e.hustleLeft = 0), f.feature === "chest" && !f.resolved) {
		Ct(e, t, n, r);
		return;
	}
	if (f.id && !f.resolved) {
		if (f.feature === "monster" && o.players[t].enraging) {
			let r = e.ps[J(e, t)];
			r.blobTargets[n] = (r.blobTargets[n] ?? K[f.id].targets[o.config.stage - 1]) + 3;
		}
		if (!a) {
			if (l && f.feature === "monster" && (s.hoard.includes(323) && !o.players[t].forcedTucked.includes(323) || o.players[t].junk.includes(15))) {
				o.tasks.push({
					job: "ignore",
					actor: t,
					to: n,
					mode: i,
					n: d
				});
				return;
			}
			Tt(e, t, f.id, l, i, r);
		}
	}
}
function Tt(e, t, n, r, i, a) {
	let o = q(e), s = K[n].kind, c = i === "charge" && s === "monster" && n !== "sentry" || i === "sneak" && s === "trap";
	r ? (e.pendingHazard = s, o.freeDice = c ? [!0] : []) : c || Et(e, t, n, a);
}
function Et(e, t, n, r) {
	let i = q(e), a = e.ps[t];
	r.push({
		kind: "strike",
		rid: t,
		data: {
			cell: a.pos,
			hazard: K[n].kind
		}
	});
	let o = i.tasks.length;
	switch (n) {
		case "blob":
			i.config.stage === 1 ? X(e, t, 2) : (X(e, t, 1, "quick"), X(e, t, 1));
			break;
		case "tangle":
			X(e, t, 1), i.tasks.push({
				job: "discardJunk",
				actor: t,
				n: 2
			});
			break;
		case "autoflail":
			X(e, t, 1, i.config.stage < 4 ? "know" : "quick"), X(e, t, 1, "brawn");
			break;
		case "golem":
			X(e, t, 1, "quick"), X(e, t, 1, "guile"), i.tasks.push({
				job: "return",
				actor: t,
				to: i.lastFrom
			});
			break;
		case "whisper":
			X(e, t, 2, "perc");
			break;
		case "forge":
			X(e, t, 2, "brawn"), X(e, t, 1);
			{
				let n = e.ps[J(e, t)];
				n.blobTargets[a.pos] = (n.blobTargets[a.pos] ?? 19) + 3;
				break;
			}
		case "pit":
			X(e, t, 2, void 0, !0);
			break;
		case "blink":
			X(e, t, 1, "perc"), X(e, t, 1, "know"), i.tasks.push({
				job: "teleport",
				actor: J(e, t),
				mode: t,
				cells: Array.from({ length: 36 }, (e, t) => t).filter((n) => ft(e, t, n).feature === "empty")
			});
			break;
		case "gremling":
			X(e, t, 1), i.tasks.push({
				job: "discardEither",
				actor: t
			});
			break;
		case "walls":
			X(e, t, 2, "brawn");
			break;
		case "mantle":
			X(e, t, 1, "guile"), i.players[t].enraging = "fatigued";
			break;
		case "sentry":
			X(e, t, 2, void 0, !0), i.tasks.push({
				job: "return",
				actor: t,
				to: i.lastFrom
			});
			break;
		case "screamer":
			X(e, t, 1, "perc"), X(e, t, 1, "guile");
			break;
		case "banish":
			X(e, t, 1, "quick"), i.tasks.push({
				job: "teleport",
				actor: t,
				mode: t,
				cells: [e.ps[J(e, t)].maze.start]
			});
			break;
		case "acid": X(e, t, 1), i.tasks.push({
			job: "tuck",
			actor: t
		});
	}
	K[n].kind === "monster" && i.players[t].junk.includes(0) && i.tasks.splice(o, 0, {
		job: "shield",
		actor: t,
		n: i.tasks.length - o
	});
}
function Dt(e) {
	return Math.max(0, e.dice.reduce((e, t) => e + t.value, 0) + e.modifier + e.monsterDice.reduce((e, t) => e + (typeof t == "number" ? t : 0), 0));
}
function Ot(e, t) {
	let n = q(e), r = n.check, i = n.players[J(e, t)].hazardCells[r.cell];
	switch (r.skull = !0, i) {
		case "blob":
			Dt(r) >= r.target + 2 && (r.blobImmune = !0, e.ps[J(e, t)].blobTargets[r.cell] = Dt(r));
			break;
		case "tangle":
			r.modifier -= 2;
			break;
		case "autoflail":
			n.tasks.push({
				job: "downgrade",
				actor: t,
				cube: "know"
			});
			break;
		case "golem":
			r.modifier -= 2, n.tasks.push({
				job: "downgrade",
				actor: t,
				cube: "perc"
			});
			break;
		case "whisper":
			r.modifier -= r.dice.filter((e) => e.power && e.source === "brawn").length * 4;
			break;
		case "forge":
			n.tasks.push({
				job: "discardJunk",
				actor: t,
				n: 2
			});
			break;
		case "sentry":
			r.dice = r.dice.map((e) => e.power ? {
				...e,
				value: 2
			} : e);
			break;
		case "screamer": {
			let r = /* @__PURE__ */ new Set([...n.monsters, ...e.players.flatMap((e) => Object.values(n.players[e].hazardCells))]), i = Ye(n.config.stage, n.config.boxZero, "monster").filter((n) => !r.has(n.id) && Array.from({ length: 36 }, (e, t) => t).some((r) => !e.ps[t].known[r] && ft(e, t, r).feature === "empty" && $e(e.ps[J(e, t)].maze, r, n.id)));
			if (!i.length) break;
			let a = i[it(e, i.length)];
			n.tasks.push({
				job: "spawn",
				actor: J(e, t),
				mode: t,
				id: a.id,
				cells: Array.from({ length: 36 }, (e, t) => t).filter((n) => !e.ps[t].known[n] && ft(e, t, n).feature === "empty" && $e(e.ps[J(e, t)].maze, n, a.id))
			});
			break;
		}
	}
	r.total = Dt(r);
}
function kt(e, t, n) {
	let r = q(e), i = r.check, a = r.players[J(e, t)].hazardCells[i.cell];
	i.total = Dt(i);
	let o = i.dice.length > 0 && i.total >= i.target && !i.blobImmune;
	e.lastCheck = {
		id: (e.lastCheck?.id ?? 0) + 1,
		cell: i.cell,
		kind: i.kind,
		dice: i.dice.length,
		success: o,
		total: i.total,
		target: i.target
	}, n.push({
		kind: "adventureResult",
		rid: t,
		data: {
			cell: i.cell,
			success: o,
			total: i.total,
			target: i.target
		}
	}), i.kind === "fight" ? o ? (e.ps[t].monsters++, St(e, t, i.cell), r.scavengeCell = i.cell, a === "tangle" || a === "autoflail" || a === "blob" && r.config.stage >= 2 ? st(e, t, 1) : a === "golem" || a === "sentry" ? ct(e, t) : a === "whisper" ? (r.players[t].extraVP++, r.tasks.push({
		job: "learn",
		actor: t,
		cells: Array.from({ length: 36 }, (e, t) => t).filter((n) => !e.ps[t].known[n])
	})) : a === "forge" ? (r.players[t].extraVP += 2, ct(e, t)) : a === "screamer" && r.players[t].extraVP++) : (i.blobImmune || (e.ps[J(e, t)].blobTargets[i.cell] = Math.max(0, i.target - i.total)), a === "tangle" && i.skull && r.tasks.push({
		job: "discardTreasure",
		actor: t
	}), Et(e, t, a, n)) : (o ? (e.ps[t].traps++, r.scavengeCell = i.cell) : Et(e, t, a, n), St(e, t, i.cell)), r.check = null, r.freeDice = [], e.pendingHazard = null, vt(e);
}
function At(e, t, n, r) {
	let i = q(e), a = e.ps[t], o = ft(e, t, a.pos);
	if (!o.id || o.resolved || o.feature !== (n.type === "fight" ? "monster" : "trap")) return !1;
	let s = K[o.id], c = i.config.stage >= (n.type === "fight" ? 2 : 3) ? s.weak : [], l = [...ht(a, ["fresh"]), ...a.conserved.flatMap((e) => [{
		cube: e,
		from: "conserved"
	}, {
		cube: e,
		from: "conserved"
	}])], u = n.pay ?? l.sort((e, t) => Number(c.includes(t.cube)) - Number(c.includes(e.cube))).slice(0, n.dice).reduce((e, t) => {
		let n = e.find((e) => e.from === "conserved" && e.kind === t.cube && !e.double);
		return t.from === "conserved" && n ? n.double = !0 : e.push({
			kind: t.cube,
			from: t.from
		}), e;
	}, []);
	if (n.dice === 0 && u.length || n.dice > 0 && !mt(e, t, n.dice, u)) return !1;
	let d = u.flatMap((e) => Array(e.double ? 2 : 1).fill(e.kind)), f = [...i.freeDice.map((e) => ({
		power: e,
		source: null
	})), ...d.map((e) => ({
		source: e,
		power: c.includes(e)
	}))].map((t) => ({
		...t,
		value: (t.power ? Ke : Ge)[it(e, 6)]
	})), p = e.ps[J(e, t)].blobTargets[a.pos] ?? s.targets[i.config.stage - 1];
	return i.check = {
		stage: "rolled",
		kind: n.type,
		cell: a.pos,
		target: p,
		dice: f,
		monsterDice: [],
		modifier: 0,
		total: 0,
		skull: !1,
		blobImmune: !1
	}, i.check.total = Dt(i.check), e.peerFree = null, e.hustleLeft = 0, r.push({
		kind: "adventureRoll",
		rid: t,
		data: {
			dice: f.map((e) => e.value),
			power: f.map((e) => e.power),
			target: p
		}
	}), !0;
}
function jt(e, t, n) {
	let r = q(e);
	r.junkDiscard.push(...r.players[t].junk.splice(n, 1));
}
function Mt(e, t, n, r) {
	let i = q(e), a = i.tasks[0];
	if (!a || a.actor !== t) return !1;
	let { options: o, min: s, max: c } = _t(e, a);
	if (n.length < s || n.length > c || new Set(n).size !== n.length || n.some((e) => !o[e])) return !1;
	let l = n.map((e) => o[e]), u = e.ps[t], d = i.players[t];
	switch (i.tasks.shift(), a.job) {
		case "fatigue":
			for (let e of l) gt(u, e, "fatigued");
			(a.n ?? 1) > l.length && ht(u, [
				"spent",
				"fresh",
				"conserved"
			]).length && i.tasks.unshift({
				...a,
				n: (a.n ?? 1) - l.length
			}), r.push({
				kind: "fatigue",
				rid: t,
				data: { n: l.length }
			});
			break;
		case "shield":
			l[0]?.skip || (jt(e, t, l[0].cell), i.tasks = i.tasks.filter((e, t) => t >= (a.n ?? 0) || e.job !== "fatigue"));
			break;
		case "discardJunk":
			for (let n of l) jt(e, t, d.junk.indexOf(n.junk));
			break;
		case "discardTreasure":
		case "discardEither":
			for (let n of l) n.card == null ? jt(e, t, d.junk.indexOf(n.junk)) : (u.hoard.splice(u.hoard.indexOf(n.card), 1), e.discard.push(n.card), d.forcedTucked = d.forcedTucked.filter((e) => e !== n.card));
			break;
		case "tuck":
			d.forcedTucked.push(l[0].card);
			break;
		case "downgrade": {
			let e = l[0];
			e.from === "conserved" ? u.conserved[u.conserved.indexOf(e.cube)] = "white" : (u[e.from][e.cube]--, u[e.from].white++);
			break;
		}
		case "refresh":
			for (let e of l) gt(u, e, "fresh");
			break;
		case "exchange":
			gt(u, l[0], l[0].from === "conserved" ? "fresh" : "spent", a.cube);
			break;
		case "recover":
			gt(u, l[0], "spent");
			break;
		case "blanket":
			for (let e of l) gt(u, e, "fatigued");
			u.spent.white++, d.cubesAdded++;
			break;
		case "adapt": {
			let e = l[0];
			e.skip || (u.spent[Ue[e.junk]]--, u.spent[e.cube]++);
			break;
		}
		case "scrounge": {
			let e = l[0]?.junk;
			e != null && d.junk.push(e);
			let n = [...a.cards ?? []];
			e != null && n.splice(n.indexOf(e), 1), i.junkDiscard.push(...n), d.junk.length > 3 && i.tasks.unshift({
				job: "discardJunk",
				actor: t,
				n: d.junk.length - 3
			});
			break;
		}
		case "appraise":
			if (l[0].skip) i.tasks.unshift({
				job: "appraiseKeep",
				actor: t,
				cards: a.cards
			});
			else {
				if (!mt(e, t, 1, [{
					kind: "perc",
					from: u.fresh.perc ? "fresh" : "conserved"
				}])) return !1;
				let n = ot(e);
				i.tasks.unshift({
					job: n == null ? "appraiseKeep" : "appraise",
					actor: t,
					cards: n == null ? a.cards : [...a.cards ?? [], n]
				});
			}
			break;
		case "appraiseKeep": {
			let n = l[0].card;
			u.hoard.push(n), e.discard.push(...(a.cards ?? []).filter((e) => e !== n)), e.pendingChest = e.display.length > 0, e.pendingChest && d.junk.includes(25) && i.tasks.unshift({
				job: "shovel",
				actor: t
			});
			break;
		}
		case "shovel":
			if (!l[0].skip) for (jt(e, t, l[0].cell), e.discard.push(...e.display.splice(0)); e.display.length < 3;) {
				let t = ot(e);
				if (t == null) break;
				e.display.push(t);
			}
			break;
		case "learn":
			for (let n of l) pt(e, a.mode ?? t, n.cell);
			break;
		case "locate":
			i.players[a.mode].located.push(l[0].cell);
			break;
		case "walls":
			i.players[a.mode].wallNotes.push(...l.map((e) => e.wall));
			break;
		case "teleport":
			wt(e, a.mode, l[0].cell, r);
			break;
		case "return":
			wt(e, t, a.to, r);
			break;
		case "spawn":
			d.hazardCells[l[0].cell] = a.id;
			break;
		case "ignore": {
			let n = l[0];
			if (n.skip) Tt(e, t, i.players[J(e, t)].hazardCells[u.pos], !0, a.mode ?? "creep", r);
			else {
				if (n.card === 323) {
					if (!mt(e, t, 1, [{
						kind: "perc",
						from: u.fresh.perc ? "fresh" : "conserved"
					}])) return !1;
				} else jt(e, t, n.cell);
				e.hustleLeft = a.n ?? 0;
			}
			break;
		}
	}
	return vt(e), !0;
}
function Nt(e, t, n, r) {
	let i = e.ps[t];
	if (!i.known[n] || n === i.pos) return !1;
	let a = /* @__PURE__ */ new Set([i.pos]), o = [i.pos];
	for (; o.length;) {
		let e = o.shift(), t = i.known[e];
		for (let s = 0; s < 4; s++) {
			let c = B(e, s);
			if (c < 0 || t.walls[s] || !i.known[c] || a.has(c)) continue;
			if (c === n) return !0;
			let l = i.known[c];
			(c === r || l.feature === "empty" || l.resolved) && (a.add(c), o.push(c));
		}
	}
	return !1;
}
function Pt(e, t, n, r) {
	let i = q(e), a = e.ps[t], o = i.players[t], s = o.junk[n.index];
	if (s == null || i.tasks.length || e.pendingChest) return !1;
	let c = i.check, l = ft(e, t, a.pos), u = !!l.id && !c && (e.pendingHazard || l.feature === "monster" || l.feature === "trap"), d = c?.stage === "rolled", f = !c && !e.pendingHazard && !e.hustleLeft;
	if (s === 4 || s === 5 || s >= 21 && s <= 23) {
		if (!u || !l.id || s === 4 && l.feature !== "monster" || s === 5 && l.feature !== "trap" || s >= 21 && K[l.id].category !== (s === 21 ? "nature" : s === 22 ? "machine" : "magic")) return !1;
		i.freeDice.push(s >= 21);
	} else if (s === 6) {
		if (!d || n.die == null || !c.dice[n.die]) return !1;
		let i = c.dice[n.die];
		i.value = (i.power ? Ke : Ge)[it(e, 6)], c.total = Dt(c), r.push({
			kind: "adventureRoll",
			rid: t,
			data: {
				dice: [i.value],
				power: [i.power]
			}
		});
	} else if (s === 13) {
		if (!d || !n.delta) return !1;
		c.modifier += n.delta, c.total = Dt(c);
	} else if (s === 14) {
		if (!f || n.cell == null || n.to == null || !a.known[n.cell] || !Nt(e, t, n.to, n.cell) || !(a.fresh.quick || a.conserved.includes("quick")) || !mt(e, t, 1, [{
			kind: "quick",
			from: a.fresh.quick ? "fresh" : "conserved"
		}])) return !1;
		wt(e, t, n.to, r);
	} else {
		if (!f) return !1;
		switch (s) {
			case 1:
			case 9:
				if (!ht(a, s === 1 ? ["spent"] : ["spent", "fatigued"]).length) return !1;
				i.tasks.push({
					job: "refresh",
					actor: t,
					n: s === 1 ? 2 : 1,
					mode: s === 9 ? "cheese" : "bread"
				});
				break;
			case 2:
			case 7:
			case 8: {
				let n = Array.from({ length: 36 }, (e, t) => t).filter((n) => {
					if (a.known[n]) return !1;
					let r = ft(e, t, n);
					return r.id && K[r.id].hidden ? !1 : s === 2 ? r.feature === "chest" || r.feature === "exit" : r.feature === (s === 7 ? "monster" : "trap");
				});
				if (!n.length) return !1;
				let r = (e) => Math.abs(Math.floor(e / 6) - Math.floor(a.pos / 6)) + Math.abs(e % 6 - a.pos % 6), o = Math.min(...n.map(r));
				i.tasks.push({
					job: "locate",
					actor: J(e, t),
					mode: t,
					cells: n.filter((e) => r(e) === o)
				});
				break;
			}
			case 3:
				if (n.cell == null || !a.known[n.cell] || a.known[n.cell].feature !== "trap" || a.known[n.cell].resolved || Se(a.pos, n.cell) < 0 || V(new Set(e.ps[J(e, t)].maze.walls), a.pos, [
					0,
					1,
					2,
					3
				].find((e) => B(a.pos, e) === n.cell)) || !mt(e, t, 1)) return !1;
				St(e, t, n.cell), a.traps++, i.scavengeCell = n.cell;
				break;
			case 10:
				if (n.cell == null || a.known[n.cell]) return !1;
				pt(e, t, n.cell);
				break;
			case 11: {
				let n = [
					0,
					1,
					2,
					3
				].map((e) => B(a.pos, e)).filter((e) => e >= 0);
				if (!n.length) return !1;
				i.tasks.push({
					job: "learn",
					actor: J(e, t),
					mode: t,
					cells: n,
					n: Math.min(2, n.length)
				});
				break;
			}
			case 12: {
				let n = e.ps[J(e, t)].maze, r = new Set(o.wallNotes);
				for (let [e, t] of Object.entries(a.known)) for (let n = 0; n < 4; n++) if (t.walls[n]) {
					let t = Se(Number(e), B(Number(e), n));
					t >= 0 && r.add(t);
				}
				let s = n.walls.filter((e) => !r.has(e));
				if (!s.length) return !1;
				i.tasks.push({
					job: "walls",
					actor: J(e, t),
					mode: t,
					cells: s,
					n: 3
				});
				break;
			}
			case 16:
			case 17:
			case 18:
			case 19:
			case 20:
				if (!nt(a)) return !1;
				i.tasks.push({
					job: "exchange",
					actor: t,
					cube: s === 16 ? "perc" : s === 17 ? "know" : s === 18 ? "brawn" : s === 19 ? "quick" : "guile"
				});
				break;
			case 24:
				if (ht(a, [
					"spent",
					"fresh",
					"conserved"
				]).length < 3) return !1;
				i.tasks.push({
					job: "blanket",
					actor: t,
					n: 3
				});
				break;
			default: return !1;
		}
	}
	return jt(e, t, n.index), e.peerFree = null, vt(e), !0;
}
function Ft(e) {
	let t = q(e), n = {};
	for (let r of e.players) {
		let i = e.ps[r], a = he(i.hoard, e.revealed[r] ?? [], {
			monstersDefeated: i.monsters,
			chestsOpened: i.chests,
			trapsDisarmed: i.traps,
			exitedFirst: i.exitOrder === 1,
			mapFullyKnown: Object.keys(i.known).length === 36,
			forcedTucked: t.players[r].forcedTucked
		}), o = ge[Math.min(i.monsters, 3)] + t.players[r].extraVP, s = i.exitOrder === 1 ? 4 : i.exitOrder === 2 ? 2 : 0;
		n[r] = {
			treasures: a,
			monsters: o,
			exit: s,
			total: a + o + s
		};
	}
	e.final = {
		revealed: e.revealed,
		breakdown: n
	}, e.phase = "done";
}
function It(e, t, { by: n }) {
	let r = structuredClone(e), i = q(r), a = r.ps[n], o = [];
	if (t.type === "tick") {
		if (r.phase === "handoff" && r.handoff) {
			let e = r.handoff;
			r.handoff = null, r.phase = e.nextPhase, e.nextPhase === "scoring" ? (r.turn = null, r.revealed = {}) : yt(r, e.to);
		} else i.check && !i.tasks.length && i.check.stage !== "rolled" && (i.check.stage === "monster" ? (i.check.monsterDice.includes("skull") && Ot(r, r.turn), i.check.stage = "resolve", vt(r)) : kt(r, r.turn, o));
		return {
			state: r,
			fx: o
		};
	}
	if (!a) return Y("errPhase");
	if (t.type === "draftHazard") {
		let e = dt(r), a = Ye(i.config.stage, i.config.boxZero, e.kind), o = e.kind === "monster" ? i.monsters : i.traps;
		if (e.actor !== n || !a.some((e) => e.id === t.id) || o.includes(t.id)) return Y("errPhase");
		o.push(t.id), i.monsters.length + i.traps.length === 6 && (r.phase = "build");
	} else if (t.type === "build") {
		if (r.phase !== "build" || a.maze) return Y("errPhase");
		let e = et(t.maze, i.monsters, i.traps);
		if (e) return Y(e);
		a.maze = t.maze, r.buildOrder.push(n), i.players[n].hazardCells = Object.fromEntries([...i.monsters.map((e, n) => [t.maze.monsters[n], e]), ...i.traps.map((e, n) => [t.maze.traps[n], e])]), r.buildOrder.length === 2 && (r.phase = i.config.stage >= 2 ? "attributes" : "pickFirst");
	} else if (t.type === "chooseAttributes") {
		if (r.phase !== "attributes" || i.players[n].attributesChosen || new Set(t.kinds).size !== 3 || !t.kinds.every((e) => Xe(i.config.stage).includes(e))) return Y("errPhase");
		for (let e of t.kinds) a.spent[e]++;
		i.players[n].attributesChosen = !0, r.players.every((e) => i.players[e].attributesChosen) && (r.phase = "pickFirst");
	} else if (t.type === "pickFirst") {
		if (r.phase !== "pickFirst" || n !== r.buildOrder[0] || !r.players.includes(t.rid)) return Y("errPhase");
		r.firstExplorer = t.rid, r.phase = "explore";
		for (let e of r.players) r.ps[e].pos = r.ps[J(r, e)].maze.start, pt(r, e, r.ps[e].pos, !0);
		yt(r, t.rid);
	} else if (t.type === "reveal") {
		if (r.phase !== "scoring" || n in r.revealed || new Set(t.cards).size !== t.cards.length || t.cards.some((e) => !a.hoard.includes(e) || i.players[n].forcedTucked.includes(e))) return Y("errPhase");
		r.revealed[n] = t.cards, r.players.every((e) => e in r.revealed) && Ft(r);
	} else if (t.type === "adventureChoice") {
		if (!Mt(r, n, t.indices, o)) return Y();
	} else {
		if (n !== r.turn || r.phase !== "explore" && r.phase !== "finalTurn" || i.tasks.length) return Y("errPhase");
		if (i.check && ![
			"finishCheck",
			"improvise",
			"useJunk"
		].includes(t.type) || r.pendingChest && t.type !== "chooseTreasure" || r.pendingHazard && !i.check && ![
			"fight",
			"disarm",
			"useJunk"
		].includes(t.type)) return Y();
		let e = a.known[a.pos];
		if (r.peerFree != null && r.peerFree >= 0 && (e.feature === "monster" || e.feature === "trap") && !e.resolved && (t.type !== "creep" || B(a.pos, t.dir) !== r.peerFree)) return Y();
		let s = e && (e.feature === "empty" || e.resolved);
		if (t.type === "useJunk") {
			if (!Pt(r, n, t, o)) return Y();
		} else if (t.type === "fight" || t.type === "disarm") {
			if (r.hustleLeft || !At(r, n, t, o)) return Y("errNoCubes");
		} else if (t.type === "improvise") {
			if (i.config.stage < 3 || i.check?.stage !== "rolled" || !(a.fresh.guile || a.conserved.includes("guile")) || !mt(r, n, 1, t.pay ?? [{
				kind: "guile",
				from: a.fresh.guile ? "fresh" : "conserved"
			}]) || t.pay && (t.pay.length !== 1 || t.pay[0].kind !== "guile" || t.pay[0].double)) return Y("errNoCubes");
			let e = Ge[it(r, 6)];
			i.check.dice.push({
				value: e,
				power: !1,
				source: "guile"
			}), i.check.total = Dt(i.check), o.push({
				kind: "adventureRoll",
				rid: n,
				data: { dice: [e] }
			});
		} else if (t.type === "finishCheck") {
			if (i.check?.stage !== "rolled") return Y();
			i.check.kind === "fight" && i.config.stage === 4 ? (i.check.monsterDice = [qe[it(r, 6)], qe[it(r, 6)]], i.check.stage = "monster", o.push({
				kind: "monsterRoll",
				rid: n,
				data: { dice: i.check.monsterDice }
			})) : i.check.stage = "resolve";
		} else if (t.type === "chooseTreasure") {
			if (!r.pendingChest || t.index >= r.display.length) return Y();
			a.hoard.push(r.display.splice(t.index, 1)[0]);
			let e = ot(r);
			e != null && r.display.push(e), r.pendingChest = !1;
		} else if (t.type === "hustle") {
			let e = !!(a.fresh.quick || a.conserved.includes("quick"));
			if (r.hustleLeft || !mt(r, n, 2, t.pay, "quick")) return Y("errNoCubes");
			let o = t.pay ? t.pay.length === 1 && t.pay[0].kind === "quick" : e;
			r.hustleLeft = a.hoard.includes(324) && !i.players[n].forcedTucked.includes(324) && o ? 5 : 3, r.peerFree = null;
		} else if (t.type === "stopHustle") {
			if (!r.hustleLeft) return Y();
			r.hustleLeft = 0;
		} else if (t.type === "creep" || t.type === "move" || t.type === "charge" || t.type === "sneak") {
			let s = B(a.pos, t.dir);
			if (s < 0 || e.walls[t.dir] || (t.type === "move" ? !r.hustleLeft : r.hustleLeft > 0)) return Y("errWall");
			if (t.type === "charge" && i.config.stage < 2 || t.type === "sneak" && i.config.stage < 3) return Y("errPhase");
			if (t.type === "move") r.hustleLeft--;
			else if (r.peerFree !== s && r.peerFree !== -1 || t.type !== "creep") {
				let e = t.type === "charge" ? "brawn" : t.type === "sneak" ? "guile" : void 0;
				if (!mt(r, n, e ? 2 : 1, t.pay, e)) return Y("errNoCubes");
			}
			wt(r, n, s, o, t.type);
		} else if (t.type === "peer") {
			let i = B(a.pos, t.dir);
			if (r.hustleLeft || i < 0 || e.walls[t.dir] || a.known[i] || !mt(r, n, 2, t.pay, "perc")) return Y("errNoCubes");
			pt(r, n, i), r.peerFree = i;
		} else if (t.type === "backtrack") {
			if (r.hustleLeft || !Nt(r, n, t.to) || !(a.fresh.quick || a.conserved.includes("quick")) || !mt(r, n, 1, t.pay ?? [{
				kind: "quick",
				from: a.fresh.quick ? "fresh" : "conserved"
			}])) return Y("errBacktrack");
			if (t.pay && (t.pay.length !== 1 || t.pay[0].kind !== "quick" || t.pay[0].double)) return Y("errNoCubes");
			wt(r, n, t.to, o);
		} else if (t.type === "scrounge") {
			if (!s || r.hustleLeft || i.players[n].searched.includes(a.pos) || !mt(r, n, 2, t.pay, "know")) return Y("errNoCubes");
			i.players[n].searched.push(a.pos);
			let e = r.ps[J(r, n)].maze, o = [
				0,
				1,
				2,
				3
			].filter((t) => B(a.pos, t) >= 0 && V(new Set(e.walls), a.pos, t)).length, c = [];
			for (let e = 0; e < o; e++) {
				let e = ot(r, !0);
				e != null && c.push(e);
			}
			c.length && i.tasks.push({
				job: "scrounge",
				actor: n,
				cards: c
			}), r.peerFree = -1;
		} else if (t.type === "scavenge") {
			if (r.hustleLeft || i.scavengeCell == null || i.players[n].scavengeUsed.includes(i.scavengeCell) || !(a.fresh.know || a.conserved.includes("know")) || !mt(r, n, 1, t.pay ?? [{
				kind: "know",
				from: a.fresh.know ? "fresh" : "conserved"
			}]) || t.pay && (t.pay.length !== 1 || t.pay[0].kind !== "know" || t.pay[0].double)) return Y("errNoCubes");
			i.players[n].scavengeUsed.push(i.scavengeCell), st(r, n, 2), r.peerFree = null, i.scavengeCell = null;
		} else if (t.type === "recover") {
			if (i.config.stage < 3 || !s || r.hustleLeft || !W(a.fatigued) || !(a.fresh.brawn || a.conserved.includes("brawn")) || !mt(r, n, 1, t.pay ?? [{
				kind: "brawn",
				from: a.fresh.brawn ? "fresh" : "conserved"
			}]) || t.pay && (t.pay.length !== 1 || t.pay[0].kind !== "brawn" || t.pay[0].double)) return Y("errNoCubes");
			i.tasks.push({
				job: "recover",
				actor: n
			}), r.peerFree = null;
		} else if (t.type === "useFlute") {
			if (r.hustleLeft || !a.hoard.includes(322) || i.players[n].forcedTucked.includes(322) || !a.known[t.cell]?.hazardId || a.known[t.cell].feature !== "monster" || a.known[t.cell].resolved || !a.known[t.to] || a.known[t.to].feature !== "empty" && !a.known[t.to].resolved || ft(r, n, t.to).feature !== "empty" || Math.abs(Math.floor(t.cell / 6) - Math.floor(t.to / 6)) + Math.abs(t.cell % 6 - t.to % 6) > 2 || !(a.fresh.know || a.conserved.includes("know"))) return Y();
			let e = J(r, n), o = i.players[e].hazardCells[t.cell];
			if (!$e(r.ps[e].maze, t.to, o) || !mt(r, n, 1, t.pay ?? [{
				kind: "know",
				from: a.fresh.know ? "fresh" : "conserved"
			}])) return Y();
			if (t.pay && (t.pay.length !== 1 || t.pay[0].kind !== "know" || t.pay[0].double)) return Y("errNoCubes");
			delete i.players[e].hazardCells[t.cell], i.players[e].hazardCells[t.to] = o, r.ps[e].blobTargets[t.cell] != null && (r.ps[e].blobTargets[t.to] = r.ps[e].blobTargets[t.cell], delete r.ps[e].blobTargets[t.cell]), i.players[n].cleared = i.players[n].cleared.filter((e) => e !== t.to), pt(r, n, t.cell), pt(r, n, t.to, !0), r.peerFree = null;
		} else if (t.type === "conserve") {
			if (!s || r.hustleLeft || a.conserved.length + t.cubes.length > 3) return Y("errConserveFull");
			for (let e of t.cubes) {
				if (a.fresh[e] < 1) return Y("errNoCubes");
				a.fresh[e]--, a.conserved.push(e);
			}
			xt(r);
		} else if (t.type === "endTurn") {
			if (r.hustleLeft) return Y();
			xt(r);
		} else if (t.type === "exit") {
			if (r.hustleLeft || e.feature !== "exit" || !rt(a)) return Y("errExitNotQualified");
			a.exitOrder = r.players.some((e) => r.ps[e].escaped) ? 2 : 1, a.escaped = !0, o.push({
				kind: "exit",
				rid: n,
				data: { cell: a.pos }
			}), bt(r, a.exitOrder === 1 ? J(r, n) : null, a.exitOrder === 1 ? "finalTurn" : "scoring");
		} else return Y("errPhase");
	}
	return vt(r), {
		state: r,
		fx: o
	};
}
function Lt(e) {
	if (e.phase === "handoff") return 1950;
	let t = q(e);
	return t.check && t.check.stage !== "rolled" && !t.tasks.length ? Ht : null;
}
function Rt(e, t) {
	let n = q(e), r = n.tasks[0], i = r ? _t(e, r) : null, a = n.check ? {
		...n.check,
		dice: n.check.dice.map((e) => ({ ...e })),
		monsterDice: [...n.check.monsterDice]
	} : null, o = dt(e);
	return {
		public: {
			phase: e.phase,
			turn: e.turn,
			handoff: e.handoff ? {
				from: e.handoff.from,
				to: e.handoff.to,
				fxMs: e.handoff.fxMs
			} : null,
			buildOrder: [...e.buildOrder],
			firstExplorer: e.firstExplorer,
			players: e.players.map((t) => {
				let r = e.ps[t], i = J(e, t);
				return {
					rid: t,
					submitted: r.maze !== null,
					pos: r.pos,
					known: Object.fromEntries(Object.entries(r.known).map(([t, r]) => [t, {
						...r,
						walls: [...r.walls],
						monsterTarget: r.hazardId && r.feature === "monster" && !r.resolved ? e.ps[i].blobTargets[Number(t)] ?? K[r.hazardId].targets[n.config.stage - 1] : null
					}])),
					fresh: { ...r.fresh },
					spent: { ...r.spent },
					fatigued: { ...r.fatigued },
					conserved: [...r.conserved],
					chests: r.chests,
					monsters: r.monsters,
					traps: r.traps,
					hoardCount: r.hoard.length,
					escaped: r.escaped,
					exitOrder: r.exitOrder
				};
			}),
			display: [...e.display],
			deckCount: e.deck.length,
			discardCount: e.discard.length,
			hustleLeft: e.hustleLeft,
			pendingChest: e.pendingChest,
			pendingFatigue: null,
			pendingHazard: e.pendingHazard,
			peerFree: e.peerFree === -1 ? null : e.peerFree,
			lastCheck: e.lastCheck ? { ...e.lastCheck } : null,
			scoringDone: Object.fromEntries(e.players.map((t) => [t, t in e.revealed])),
			final: e.final ? structuredClone(e.final) : null,
			adventure: {
				config: structuredClone(n.config),
				monsters: [...n.monsters],
				traps: [...n.traps],
				draftActor: o.actor,
				draftKind: o.kind,
				pending: r && i ? {
					kind: r.job,
					actor: r.actor,
					min: i.min,
					max: i.max
				} : null,
				check: a,
				freeDice: [...n.freeDice],
				scavengeCell: n.scavengeCell,
				scroungeFree: e.peerFree === -1,
				players: Object.fromEntries(e.players.map((e) => {
					let t = n.players[e];
					return [e, {
						junkCount: t.junk.length,
						searched: [...t.searched],
						located: [...t.located],
						wallNotes: [...t.wallNotes],
						enraging: t.enraging,
						attributesChosen: t.attributesChosen,
						extraVP: t.extraVP
					}];
				})),
				junkDeckCount: n.junkDeck.length,
				junkDiscardCount: n.junkDiscard.length
			}
		},
		private: {
			maze: e.ps[t]?.maze ? structuredClone(e.ps[t].maze) : null,
			hoard: [...e.ps[t]?.hoard ?? []],
			adventure: {
				junk: [...n.players[t]?.junk ?? []],
				forcedTucked: [...n.players[t]?.forcedTucked ?? []],
				hazardCells: { ...n.players[t]?.hazardCells ?? {} },
				appraisal: r?.actor === t && ["appraise", "appraiseKeep"].includes(r.job) ? [...r.cards ?? []] : [],
				options: r?.actor === t && i ? structuredClone(i.options) : []
			}
		}
	};
}
//#endregion
//#region src/games/lairs/rules.ts
var zt = [
	1,
	2,
	2,
	3,
	3,
	4
], Bt = 3, Vt = 1600, Ht = 1300, Ut = (e = 0) => ({
	...We(),
	white: e
}), Wt = (e) => e.fresh.white + e.fresh.quick + e.fresh.perc, Gt = (e) => Wt(e) + 2 * e.conserved.length;
function Kt(e, t) {
	if (Gt(e) < t) return !1;
	for (let n of [
		"white",
		"quick",
		"perc"
	]) for (; t > 0 && e.fresh[n] > 0;) --e.fresh[n], e.spent[n] += 1, --t;
	for (let n of [
		"white",
		"quick",
		"perc"
	]) {
		for (; t > 0;) {
			let r = e.conserved.indexOf(n);
			if (r < 0) break;
			e.conserved.splice(r, 1), e.fresh[n] += 1, --t, t > 0 && (--e.fresh[n], e.spent[n] += 1, --t);
		}
		if (t <= 0) break;
	}
	return !0;
}
function qt(e, t) {
	if (e.fresh[t] > 0) return --e.fresh[t], e.spent[t] += 1, !0;
	let n = e.conserved.indexOf(t);
	return n < 0 ? !1 : (e.conserved.splice(n, 1), e.fresh[t] += 1, !0);
}
function Jt(e, t) {
	return e.fresh.white >= 2 ? Kt(e, 2) : qt(e, t) || Kt(e, 2);
}
function Yt(e, t, n) {
	let r = 0, i = Ut(), a = [];
	for (let e of n) r += e.from === "conserved" && e.double ? 2 : 1, e.from === "fresh" ? i[e.kind] += 1 : a.push(e.kind);
	if (r !== t) return !1;
	for (let t of [
		"white",
		"quick",
		"perc"
	]) if (i[t] > e.fresh[t]) return !1;
	let o = [...e.conserved];
	for (let e of a) {
		let t = o.indexOf(e);
		if (t < 0) return !1;
		o.splice(t, 1);
	}
	for (let t of n) t.from === "fresh" ? (--e.fresh[t.kind], e.spent[t.kind] += 1) : (e.conserved.splice(e.conserved.indexOf(t.kind), 1), t.double ? e.spent[t.kind] += 1 : e.fresh[t.kind] += 1);
	return !0;
}
function Xt(e, t, n) {
	return Yt(e, n.length === 1 && n[0].kind === t && !(n[0].from === "conserved" && n[0].double) ? 1 : 2, n);
}
function Zt(e, t) {
	let n = 0, r = (t, i) => {
		if (!(n > 1)) {
			if (i === 0) {
				n += 1;
				return;
			}
			if (!(t >= e.length)) for (let n = 0; n <= Math.min(e[t], i); n += 1) r(t + 1, i - n);
		}
	};
	return r(0, t), n;
}
function Qt(e, t, n) {
	let r = (t) => e.conserved.filter((e) => e === t).length, i = [
		e.fresh.white,
		e.fresh.quick,
		e.fresh.perc,
		r("white"),
		r("quick"),
		r("perc")
	], a = [
		e.spent.white,
		e.spent.quick,
		e.spent.perc
	];
	if (!n) return Zt([...a, ...i], t);
	let o = i.reduce((e, t) => e + t, 0);
	return o >= t ? Zt(i, t) : Zt(a, t - o);
}
function $t(e, t, n, r, i, a, o) {
	if (i.push({
		kind: "strike",
		rid: e.turn ?? void 0,
		data: {
			cell: a,
			hazard: o
		}
	}), Qt(t, n, r) > 1) {
		e.pendingFatigue = {
			n,
			freshOnly: r
		};
		return;
	}
	r ? tn(t, n) : en(t, n);
}
function en(e, t) {
	let n = [
		[e.spent, "white"],
		[e.spent, "quick"],
		[e.spent, "perc"],
		[e.fresh, "white"],
		[e.fresh, "quick"],
		[e.fresh, "perc"]
	];
	for (let [r, i] of n) {
		let n = r;
		for (; t > 0 && n[i] > 0;) --n[i], e.fatigued[i] += 1, --t;
	}
	for (let n of [
		"white",
		"quick",
		"perc"
	]) for (; t > 0;) {
		let r = e.conserved.indexOf(n);
		if (r < 0) break;
		e.conserved.splice(r, 1), e.fatigued[n] += 1, --t;
	}
}
function tn(e, t) {
	let n = t;
	for (let t of [
		"white",
		"quick",
		"perc"
	]) for (; n > 0 && e.fresh[t] > 0;) --e.fresh[t], e.fatigued[t] += 1, --n;
	for (let t of [
		"white",
		"quick",
		"perc"
	]) for (; n > 0;) {
		let r = e.conserved.indexOf(t);
		if (r < 0) break;
		e.conserved.splice(r, 1), e.fatigued[t] += 1, --n;
	}
	n > 0 && en(e, n);
}
function nn(e, t, n) {
	if (e.known[n]) return !1;
	let r = new Set(t.walls), i = Ce(t)[n] ?? "empty";
	return e.known[n] = {
		walls: [
			V(r, n, 0),
			V(r, n, 1),
			V(r, n, 2),
			V(r, n, 3)
		],
		feature: i,
		resolved: !1
	}, !0;
}
function rn(e) {
	for (let t of [
		"white",
		"quick",
		"perc"
	]) e.fresh[t] += e.spent[t], e.spent[t] = e.fatigued[t], e.fatigued[t] = 0;
}
function an(e, t) {
	e.turn = t, e.hustleLeft = 0, e.pendingChest = !1, e.pendingFatigue = null, e.pendingHazard = null, e.peerFree = null, rn(e.ps[t]);
}
var on = (e) => e.chests >= 3 || e.monsters >= 3 || e.chests >= 2 && e.monsters >= 2;
function sn(t, n, r) {
	let i = Pe.parse(t), a = 0, o = pe.filter((e) => e <= 321);
	for (let t = o.length - 1; t > 0; --t) {
		let n = e(r, a, t + 1);
		a += 1, [o[t], o[n]] = [o[n], o[t]];
	}
	let s = o.splice(0, 3), c = () => ({
		maze: null,
		pos: 0,
		known: {},
		fresh: Ut(),
		spent: {
			...Ut(4),
			quick: 1,
			perc: 1
		},
		fatigued: Ut(),
		conserved: [],
		chests: 0,
		monsters: 0,
		traps: 0,
		hoard: [],
		escaped: !1,
		exitOrder: 0,
		blobTargets: {}
	}), l = {
		players: [n[0], n[1]],
		phase: "build",
		ps: {
			[n[0]]: c(),
			[n[1]]: c()
		},
		deck: o,
		discard: [],
		display: s,
		turn: null,
		handoff: null,
		buildOrder: [],
		firstExplorer: null,
		hustleLeft: 0,
		pendingChest: !1,
		pendingFatigue: null,
		pendingHazard: null,
		peerFree: null,
		lastCheck: null,
		revealed: {},
		final: null,
		seed: r,
		rngCursor: a
	};
	return i.mode === "adventure" && lt(l, i), {
		state: l,
		fx: []
	};
}
function cn(t, n) {
	let r = [];
	for (let i = 0; i < n; i += 1) r.push(zt[e(t.seed, t.rngCursor, 6)]), t.rngCursor += 1;
	return r;
}
function ln(t, n) {
	if (t.deck.length === 0 && t.discard.length > 0) {
		t.deck = t.discard, t.discard = [];
		for (let n = t.deck.length - 1; n > 0; --n) {
			let r = e(t.seed, t.rngCursor, n + 1);
			t.rngCursor += 1, [t.deck[n], t.deck[r]] = [t.deck[r], t.deck[n]];
		}
	}
	let r = t.deck.shift();
	return r === void 0 ? null : (n.hoard.push(r), r);
}
function un(e, t, n, r, i, a, o) {
	let s = n.maze, c = !nn(t, s, r), l = t.pos;
	t.pos = r;
	let u = t.known[r];
	if (i.push({
		kind: "move",
		rid: e.turn ?? void 0,
		data: {
			from: l,
			to: r
		}
	}), c || i.push({
		kind: "reveal",
		rid: e.turn ?? void 0,
		data: { cell: r },
		with: !0
	}), u.feature === "chest" && !u.resolved) {
		u.resolved = !0, t.chests += 1, i.push({
			kind: "chest",
			rid: e.turn ?? void 0,
			data: { cell: r }
		});
		let n = ln(e, t);
		n !== null && e.turn && i.push({
			kind: "draw",
			rid: e.turn,
			data: { count: 1 },
			for: [e.turn],
			secret: { card: n },
			with: !0
		}), e.pendingChest = e.display.length > 0;
	}
	!c && !o ? u.feature === "monster" && !u.resolved ? $t(e, t, 2, !1, i, r, "monster") : u.feature === "trap" && !u.resolved && $t(e, t, 2, !0, i, r, "trap") : c && (u.feature === "monster" || u.feature === "trap") && !u.resolved && (e.pendingHazard = u.feature), a && u.feature !== "empty" && !u.resolved && (e.hustleLeft = 0);
}
function dn(e, t) {
	if (e.phase !== "explore" && e.phase !== "finalTurn") return;
	let n = e.turn;
	if (!n) return;
	let r = e.ps[n];
	e.hustleLeft > 0 || e.pendingChest || e.pendingFatigue || e.pendingHazard || (e.peerFree ?? (Gt(r) > 0 || r.known[r.pos]?.feature === "exit" && on(r) || hn(e, t)));
}
function fn(e) {
	if (e.kind === "roll") {
		let n = e.data?.dice, r = Array.isArray(n) ? n.length : 1;
		return r === 0 ? 900 : Math.max(t.banner(r), (r - 1) * t.stagger + t.tumble + t.hold + 900);
	}
	return {
		move: 340,
		reveal: 600,
		strike: 900,
		fatigue: 600,
		chest: 800,
		draw: 420,
		takeCard: 420,
		exit: 1e3
	}[e.kind] ?? 0;
}
function pn(e) {
	let t = 0, n = 0;
	for (let r of e) r.with || (t += n, n = 0), n = Math.max(n, fn(r));
	return e.length ? t + n + 120 : 0;
}
function mn(e, t, n, r) {
	e.handoff = {
		from: e.turn,
		to: t,
		nextPhase: n,
		fxMs: pn(r)
	}, e.phase = "handoff";
}
function hn(e, t = []) {
	e.phase === "explore" ? mn(e, e.players.find((t) => t !== e.turn), "explore", t) : e.phase === "finalTurn" && mn(e, null, "scoring", t);
}
function gn(e) {
	e.phase = "scoring", e.turn = null, e.revealed = {};
}
function _n(e) {
	let t = {};
	for (let n of e.players) {
		let r = e.ps[n], i = {
			monstersDefeated: r.monsters,
			chestsOpened: r.chests,
			trapsDisarmed: r.traps,
			exitedFirst: r.exitOrder === 1,
			mapFullyKnown: Object.keys(r.known).length >= 36
		}, a = he(r.hoard, e.revealed[n] ?? [], i), o = ge[Math.min(3, r.monsters)], s = r.exitOrder === 1 ? 4 : r.exitOrder === 2 ? 2 : 0;
		t[n] = {
			treasures: a,
			monsters: o,
			exit: s,
			total: a + o + s
		};
	}
	e.final = {
		revealed: { ...e.revealed },
		breakdown: t
	}, e.phase = "done";
}
var Z = (e) => ({ code: `games.lairs.${e}` });
function vn(t, n, r) {
	if (t.adventure) return It(t, n, r);
	if ("pay" in n && n.pay?.some((e) => ![
		"white",
		"quick",
		"perc"
	].includes(e.kind))) return Z("errNoCubes");
	let { by: i } = r;
	if (n.type === "tick") {
		if (t.phase !== "handoff" || !t.handoff) return {
			state: t,
			fx: []
		};
		let e = structuredClone(t), { to: n, nextPhase: r } = e.handoff;
		return e.handoff = null, r === "scoring" ? gn(e) : (e.phase = r, an(e, n)), {
			state: e,
			fx: []
		};
	}
	if (n.type === "build") {
		if (t.phase !== "build" || t.ps[i]?.maze) return Z("errPhase");
		let e = Ee(n.maze);
		if (e) return Z(e);
		let r = structuredClone(t);
		r.ps[i].maze = n.maze, r.buildOrder.push(i);
		let a = [{
			kind: "built",
			rid: i
		}];
		return r.buildOrder.length === 2 && (r.phase = "pickFirst"), {
			state: r,
			fx: a
		};
	}
	if (n.type === "pickFirst") {
		if (t.phase !== "pickFirst" || i !== t.buildOrder[0] || !t.players.includes(n.rid)) return Z("errPhase");
		let e = structuredClone(t);
		e.firstExplorer = n.rid, e.phase = "explore";
		for (let t of e.players) {
			let n = e.ps[e.players.find((e) => e !== t)].maze;
			e.ps[t].pos = n.start, nn(e.ps[t], n, n.start);
		}
		return an(e, n.rid), {
			state: e,
			fx: []
		};
	}
	if (n.type === "reveal") {
		if (t.phase !== "scoring" || t.revealed[i]) return Z("errPhase");
		let e = t.ps[i]?.hoard ?? [];
		if (new Set(n.cards).size !== n.cards.length || n.cards.some((t) => !e.includes(t))) return Z("errBadReveal");
		let r = structuredClone(t);
		return r.revealed[i] = n.cards, r.players.every((e) => r.revealed[e]) && _n(r), {
			state: r,
			fx: []
		};
	}
	if (t.phase !== "explore" && t.phase !== "finalTurn" || t.turn !== i) return Z("errPhase");
	let a = t.ps[i], o = t.players.find((e) => e !== i), s = t.ps[o].maze, c = new Set(s.walls);
	if (n.type === "chooseTreasure") {
		if (!t.pendingChest) return Z("errPhase");
		if (n.index >= t.display.length) return Z("errBadCard");
		let r = structuredClone(t), a = r.display.splice(n.index, 1)[0];
		if (r.ps[i].hoard.push(a), r.pendingChest = !1, r.deck.length > 0 || r.discard.length > 0) {
			if (r.deck.length === 0) {
				r.deck = r.discard, r.discard = [];
				for (let t = r.deck.length - 1; t > 0; --t) {
					let n = e(r.seed, r.rngCursor, t + 1);
					r.rngCursor += 1, [r.deck[t], r.deck[n]] = [r.deck[n], r.deck[t]];
				}
			}
			let t = r.deck.shift();
			t !== void 0 && r.display.push(t);
		}
		return dn(r, [{
			kind: "takeCard",
			rid: i,
			data: { card: a }
		}]), {
			state: r,
			fx: [{
				kind: "takeCard",
				rid: i,
				data: { card: a }
			}]
		};
	}
	if (n.type === "chooseFatigue") {
		let e = t.pendingFatigue;
		if (!e || n.cubes.length !== e.n) return Z("errBadPay");
		let r = a;
		if (e.freshOnly) {
			let t = Wt(r) + r.conserved.length;
			if (n.cubes.filter((e) => e.from !== "spent").length !== Math.min(e.n, t)) return Z("errBadPay");
		}
		let o = Ut(), s = Ut(), c = [];
		for (let e of n.cubes) e.from === "fresh" ? o[e.kind] += 1 : e.from === "spent" ? s[e.kind] += 1 : c.push(e.kind);
		for (let e of [
			"white",
			"quick",
			"perc"
		]) if (o[e] > r.fresh[e] || s[e] > r.spent[e] || c.filter((t) => t === e).length > r.conserved.filter((t) => t === e).length) return Z("errBadPay");
		let l = structuredClone(t), u = l.ps[i];
		for (let e of n.cubes) e.from === "fresh" ? --u.fresh[e.kind] : e.from === "spent" ? --u.spent[e.kind] : u.conserved.splice(u.conserved.indexOf(e.kind), 1), u.fatigued[e.kind] += 1;
		l.pendingFatigue = null;
		let d = [{
			kind: "fatigue",
			rid: i,
			data: { n: n.cubes.length }
		}];
		return dn(l, d), {
			state: l,
			fx: d
		};
	}
	if (t.pendingChest || t.pendingFatigue || t.pendingHazard && n.type !== (t.pendingHazard === "monster" ? "fight" : "disarm")) return Z("errBusy");
	let l = a.known[a.pos], u = (l?.feature === "monster" || l?.feature === "trap") && !l.resolved;
	if (t.peerFree != null && u && (n.type !== "creep" || B(a.pos, n.dir) !== t.peerFree) || u && (n.type === "hustle" || n.type === "conserve")) return Z("errBusy");
	if (n.type === "creep" || n.type === "move") {
		if (n.type === "creep" && t.hustleLeft > 0) return Z("errBusy");
		if (n.type === "move" && t.hustleLeft <= 0) return Z("errPhase");
		let e = B(a.pos, n.dir);
		if (e < 0 || V(c, a.pos, n.dir)) return Z("errWall");
		let r = structuredClone(t), s = r.ps[i], l = r.ps[o], u = n.type === "creep" && e === r.peerFree;
		if (r.peerFree = null, n.type === "creep" && !u && !(n.pay ? Yt(s, 1, n.pay) : Kt(s, 1))) return Z(n.pay ? "errBadPay" : "errNoCubes");
		let d = [];
		return n.type === "move" && --r.hustleLeft, un(r, s, l, e, d, n.type === "move", !1), dn(r, d), {
			state: r,
			fx: d
		};
	}
	if (n.type === "hustle") {
		if (t.hustleLeft > 0) return Z("errBusy");
		let e = structuredClone(t);
		return e.peerFree = null, (n.pay ? Xt(e.ps[i], "quick", n.pay) : Jt(e.ps[i], "quick")) ? (e.hustleLeft = 3, {
			state: e,
			fx: [{
				kind: "hustle",
				rid: i
			}]
		}) : Z(n.pay ? "errBadPay" : "errNoCubes");
	}
	if (n.type === "stopHustle") {
		if (t.hustleLeft <= 0) return Z("errPhase");
		let e = structuredClone(t);
		return e.hustleLeft = 0, dn(e, []), {
			state: e,
			fx: []
		};
	}
	if (n.type === "backtrack") {
		if (t.hustleLeft > 0) return Z("errBusy");
		let e = n.to;
		if (!a.known[e] || e === a.pos) return Z("errBadCell");
		let r = (e) => {
			let t = a.known[e];
			return !!t && (t.feature === "empty" || t.resolved);
		}, s = /* @__PURE__ */ new Set([a.pos]), c = [a.pos], l = !1;
		for (; c.length && !l;) {
			let t = c.pop();
			for (let n = 0; n < 4; n += 1) {
				let i = B(t, n);
				if (!(i < 0 || s.has(i)) && !a.known[t]?.walls[n]) {
					if (i === e) {
						l = !0;
						break;
					}
					r(i) && (s.add(i), c.push(i));
				}
			}
		}
		if (!l) return Z("errBadCell");
		let u = structuredClone(t);
		if (u.peerFree = null, !(n.pay ? n.pay.length === 1 && n.pay[0].kind === "quick" && !n.pay[0].double && Yt(u.ps[i], 1, n.pay) : qt(u.ps[i], "quick"))) return Z(n.pay ? "errBadPay" : "errNoCubes");
		let d = u.ps[i], f = [];
		return un(u, d, u.ps[o], e, f, !1, !0), dn(u, f), {
			state: u,
			fx: f
		};
	}
	if (n.type === "peer") {
		if (t.hustleLeft > 0) return Z("errBusy");
		let e = B(a.pos, n.dir);
		if (e < 0 || V(c, a.pos, n.dir)) return Z("errWall");
		if (a.known[e]) return Z("errPeerKnown");
		let r = structuredClone(t);
		if (!(n.pay ? Xt(r.ps[i], "perc", n.pay) : Jt(r.ps[i], "perc"))) return Z(n.pay ? "errBadPay" : "errNoCubes");
		let o = r.ps[i];
		nn(o, s, e), r.peerFree = e;
		let l = [{
			kind: "reveal",
			rid: i,
			data: { cell: e }
		}];
		return dn(r, l), {
			state: r,
			fx: l
		};
	}
	if (n.type === "fight" || n.type === "disarm") {
		if (t.hustleLeft > 0) return Z("errBusy");
		let e = a.known[a.pos], r = n.type === "fight" ? "monster" : "trap";
		if (!e || e.feature !== r || e.resolved) return Z("errNotHazard");
		if (Gt(a) < n.dice) return Z("errNoCubes");
		let s = structuredClone(t);
		s.pendingHazard = null, s.peerFree = null;
		let c = s.ps[i], l = s.ps[o];
		if (n.pay && !Yt(c, n.dice, n.pay)) return Z("errBadPay");
		n.pay || Kt(c, n.dice);
		let u = cn(s, n.dice), d = u.reduce((e, t) => e + t, 0), f = c.pos, p = [];
		if (n.type === "fight") {
			let e = l.blobTargets[f] ?? 6, t = n.dice > 0 && d >= e;
			s.lastCheck = {
				id: (s.lastCheck?.id ?? 0) + 1,
				cell: f,
				kind: "fight",
				dice: n.dice,
				success: t
			}, p.push({
				kind: "roll",
				rid: i,
				data: {
					dice: u,
					target: e,
					success: t,
					kind: "fight",
					cell: f
				}
			}), t ? (c.monsters += 1, c.known[f].resolved = !0) : ($t(s, c, 2, !1, p, f, "monster"), l.blobTargets[f] = Math.max(0, e - d));
		} else {
			let e = n.dice > 0 && d >= 5;
			s.lastCheck = {
				id: (s.lastCheck?.id ?? 0) + 1,
				cell: f,
				kind: "disarm",
				dice: n.dice,
				success: e
			}, p.push({
				kind: "roll",
				rid: i,
				data: {
					dice: u,
					target: 5,
					success: e,
					kind: "disarm",
					cell: f
				}
			}), e ? c.traps += 1 : $t(s, c, 2, !0, p, f, "trap"), c.known[f].resolved = !0;
		}
		return dn(s, p), {
			state: s,
			fx: p
		};
	}
	if (n.type === "exit") {
		if (t.hustleLeft > 0) return Z("errBusy");
		if (a.known[a.pos]?.feature !== "exit") return Z("errNotExit");
		if (!on(a)) return Z("errExitNotQualified");
		let e = structuredClone(t);
		e.peerFree = null;
		let n = e.ps[i];
		n.exitOrder = e.players.some((t) => t !== i && e.ps[t].escaped) ? 2 : 1, n.escaped = !0;
		let r = [{
			kind: "exit",
			rid: i,
			data: { cell: n.pos }
		}];
		return n.exitOrder === 1 ? mn(e, o, "finalTurn", r) : mn(e, null, "scoring", r), {
			state: e,
			fx: r
		};
	}
	if (n.type === "conserve") {
		if (t.hustleLeft > 0) return Z("errBusy");
		let e = a;
		if (e.conserved.length + n.cubes.length > Bt) return Z("errConserveFull");
		for (let t of n.cubes) if (e.fresh[t] <= 0) return Z("errNoCubes");
		let r = structuredClone(t);
		r.peerFree = null;
		for (let e of n.cubes) --r.ps[i].fresh[e], r.ps[i].conserved.push(e);
		let o = [{
			kind: "conserve",
			rid: i,
			data: { n: n.cubes.length }
		}];
		return hn(r), {
			state: r,
			fx: o
		};
	}
	if (n.type === "endTurn") {
		if (t.hustleLeft > 0) return Z("errBusy");
		let e = structuredClone(t);
		return e.peerFree = null, hn(e), {
			state: e,
			fx: []
		};
	}
	return Z("errPhase");
}
function yn(e, t) {
	if (e.adventure) return Rt(e, t);
	let n = e.players.map((t) => {
		let n = e.ps[t], r = e.players.find((e) => e !== t), i = e.ps[r], a = {};
		for (let [e, t] of Object.entries(n.known)) a[e] = {
			...t,
			monsterTarget: t.feature === "monster" && !t.resolved ? i.blobTargets[Number(e)] ?? 6 : null
		};
		return {
			rid: t,
			submitted: n.maze !== null,
			pos: n.pos,
			known: a,
			fresh: n.fresh,
			spent: n.spent,
			fatigued: n.fatigued,
			conserved: [...n.conserved],
			chests: n.chests,
			monsters: n.monsters,
			traps: n.traps,
			hoardCount: n.hoard.length,
			escaped: n.escaped,
			exitOrder: n.exitOrder
		};
	});
	return {
		public: {
			phase: e.phase,
			turn: e.turn,
			handoff: e.handoff ? {
				from: e.handoff.from,
				to: e.handoff.to,
				fxMs: e.handoff.fxMs
			} : null,
			buildOrder: [...e.buildOrder],
			firstExplorer: e.firstExplorer,
			players: n,
			display: [...e.display],
			deckCount: e.deck.length,
			discardCount: e.discard.length,
			hustleLeft: e.hustleLeft,
			pendingChest: e.pendingChest,
			pendingFatigue: e.pendingFatigue ? { ...e.pendingFatigue } : null,
			pendingHazard: e.pendingHazard ?? null,
			peerFree: e.peerFree,
			lastCheck: e.lastCheck ? { ...e.lastCheck } : null,
			scoringDone: Object.fromEntries(e.players.map((t) => [t, t in e.revealed])),
			final: e.final
		},
		private: {
			maze: e.ps[t]?.maze ?? null,
			hoard: [...e.ps[t]?.hoard ?? []]
		}
	};
}
function bn(e) {
	if (e.phase !== "done" || !e.final) return { phase: e.phase };
	let t = (t) => e.final?.breakdown[t]?.total ?? 0, n = [...e.players].sort((n, r) => t(r) - t(n) || e.ps[n].exitOrder - e.ps[r].exitOrder), r = t(n[0]);
	return {
		phase: "done",
		winner: n.filter((i) => t(i) === r && e.ps[i].exitOrder === e.ps[n[0]].exitOrder),
		ranking: n,
		scores: Object.fromEntries(e.players.map((e) => [e, t(e)]))
	};
}
var xn = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: Oe,
	schemas: {
		config: Pe,
		action: Le,
		publicView: Ve,
		privateView: He
	},
	setup: sn,
	reduce: vn,
	viewFor: yn,
	status: bn,
	nextTickIn: (e) => e.adventure ? Lt(e) : e.phase === "handoff" && e.handoff ? e.handoff.fxMs + Vt : null
}, Sn = "./games/lairs/", Cn = [
	"exit.webp",
	"chest.webp",
	"trap.webp",
	"monster.webp"
], wn = "#34445c", Tn = "#63738c", En = "#dca75e", Dn = "#72e8f2", On = 320, kn = "#25374a", An = new ne();
An.moveTo(0, .12), An.lineTo(.37, .1), An.lineTo(.28, 0), An.lineTo(.37, -.1), An.lineTo(0, -.12), An.closePath();
var jn = "\n  varying vec3 vDirection;\n  void main() {\n    vDirection = normalize(position);\n    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);\n  }\n", Mn = "\n  varying vec3 vDirection;\n  void main() {\n    float height = smoothstep(-0.18, 0.72, vDirection.y);\n    vec3 horizon = vec3(0.145, 0.216, 0.290);\n    vec3 ceiling = vec3(0.075, 0.118, 0.180);\n    vec3 color = mix(horizon, ceiling, height);\n    float coldGlow = pow(max(0.0, 1.0 - abs(vDirection.x + 0.24) * 2.0), 3.0)\n      * (1.0 - height) * 0.065;\n    gl_FragColor = vec4(color + vec3(coldGlow * 0.45, coldGlow * 0.7, coldGlow), 1.0);\n  }\n", Nn = "\n  varying vec2 vUv;\n  void main() {\n    vUv = uv;\n    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);\n  }\n", Pn = "\n  varying vec2 vUv;\n  void main() {\n    float fadeX = smoothstep(0.0, 0.22, vUv.x) * (1.0 - smoothstep(0.78, 1.0, vUv.x));\n    float fadeY = smoothstep(0.0, 0.32, vUv.y) * (1.0 - smoothstep(0.62, 1.0, vUv.y));\n    float wisps = 0.72 + 0.28 * sin(vUv.x * 22.0 + sin(vUv.y * 13.0) * 2.0);\n    gl_FragColor = vec4(0.36, 0.47, 0.61, fadeX * fadeY * wisps * 0.24);\n  }\n", Fn = [
	[
		-18,
		-13,
		3.6,
		7.4
	],
	[
		-13,
		-10,
		2.9,
		5.8
	],
	[
		-8,
		-13,
		4.1,
		8.2
	],
	[
		-2,
		-11,
		3.3,
		6.6
	],
	[
		4,
		-14,
		4.5,
		7.5
	],
	[
		11,
		-10,
		3.2,
		6.3
	],
	[
		18,
		-13,
		4.2,
		8.8
	],
	[
		-11,
		-5,
		3.1,
		6.8
	],
	[
		11,
		-4,
		3.5,
		7.2
	]
], In = "\n  varying vec2 vFogWorld;\n  void main() {\n    vec4 world = modelMatrix * vec4(position, 1.0);\n    vFogWorld = world.xz;\n    gl_Position = projectionMatrix * viewMatrix * world;\n  }\n", Ln = "\n  uniform float uTime;\n  uniform float uDimmed;\n  varying vec2 vFogWorld;\n  float fogHash(vec2 p) {\n    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);\n  }\n  float fogNoise(vec2 p) {\n    vec2 i = floor(p);\n    vec2 f = fract(p);\n    f = f * f * (3.0 - 2.0 * f);\n    return mix(mix(fogHash(i), fogHash(i + vec2(1.0, 0.0)), f.x),\n               mix(fogHash(i + vec2(0.0, 1.0)), fogHash(i + vec2(1.0, 1.0)), f.x), f.y);\n  }\n  void main() {\n    vec2 drift = vec2(uTime * 0.035, uTime * 0.018);\n    float broad = fogNoise(vFogWorld * 0.85 + drift);\n    float wisps = fogNoise(vFogWorld * 2.1 - drift * 0.7);\n    float density = smoothstep(0.27, 0.72, broad * 0.7 + wisps * 0.3);\n    vec3 fogColor = mix(vec3(0.06, 0.10, 0.17), vec3(0.22, 0.30, 0.40), density);\n    float denseFog = 0.64 + density * 0.20;\n    float shallowFog = 0.30 + density * 0.16;\n    gl_FragColor = vec4(fogColor, mix(denseFog, shallowFog, uDimmed));\n  }\n";
function Rn() {
	try {
		let e = document.createElement("canvas"), t = e.getContext("webgl2") ?? e.getContext("webgl");
		return t?.getExtension("WEBGL_lose_context")?.loseContext(), !!t;
	} catch {
		return !1;
	}
}
var zn = (e) => e - 5 / 2, Bn = (e) => e - 5 / 2;
function Vn({ fallback: e, ...t }) {
	let n = d(), r = re(), o = c(null), s = c({
		yaw: .14,
		pitch: .7
	}), u = c(null), f = c(!1), [p, m] = l(!1), h = t.anchorRid;
	return a(() => {
		if (!n || !h || p) return;
		let e = [], t = (e) => {
			let t = o.current;
			if (!t) return null;
			let [n, r] = z(e), i = zn(r), a = Bn(n), s = .47, c = .09, l = t.canvas.getBoundingClientRect(), u = [
				new E(i - s, c, a - s),
				new E(i + s, c, a - s),
				new E(i - s, c, a + s),
				new E(i + s, c, a + s)
			], d = Infinity, f = -Infinity, p = Infinity, m = -Infinity;
			for (let e of u) {
				e.project(t.camera);
				let n = l.left + (e.x + 1) * l.width / 2, r = l.top + (1 - e.y) * l.height / 2;
				d = Math.min(d, n), f = Math.max(f, n), p = Math.min(p, r), m = Math.max(m, r);
			}
			return {
				x: d,
				y: p,
				w: f - d,
				h: m - p
			};
		};
		for (let r = 0; r < 36; r += 1) {
			let i = `cell:${h}:${r}`;
			n.registerProbe(i, () => t(r)), e.push(i);
		}
		let r = `board3d:${h}`;
		return n.registerProbe(r, () => {
			let e = o.current?.canvas.getBoundingClientRect();
			return e ? {
				x: e.left,
				y: e.top,
				w: e.width,
				h: e.height
			} : null;
		}), e.push(r), () => {
			for (let t of e) n.registerProbe(t, null);
		};
	}, [
		n,
		h,
		p
	]), /* @__PURE__ */ O("div", {
		className: p ? "contents" : "lairs-board3d",
		onPointerDown: (e) => {
			p || (f.current = !1, u.current = {
				x: e.clientX,
				y: e.clientY,
				moved: !1
			});
		},
		onPointerMove: (e) => {
			if (p) return;
			let t = u.current;
			if (!t) return;
			let n = e.clientX - t.x, r = e.clientY - t.y;
			Math.abs(n) + Math.abs(r) > 9 && (t.moved = !0, f.current = !0), t.moved && (s.current.yaw = Math.min(.65, Math.max(-.65, s.current.yaw - n * .006)), s.current.pitch = Math.min(1.45, Math.max(.5, s.current.pitch + r * .005)), t.x = e.clientX, t.y = e.clientY, o.current?.invalidate());
		},
		onPointerUp: () => {
			u.current = null;
		},
		onPointerCancel: () => {
			u.current = null;
		},
		onPointerLeave: () => {
			u.current = null;
		},
		children: /* @__PURE__ */ k(ie, {
			fallback: null,
			recoveryFallback: e,
			onRecoveryChange: m,
			camera: {
				fov: 40,
				near: .1,
				far: 130
			},
			dpr: [1, 2],
			frameloop: "demand",
			gl: {
				antialias: !0,
				powerPreference: "low-power",
				alpha: !1
			},
			children: [
				/* @__PURE__ */ O("color", {
					attach: "background",
					args: [kn]
				}),
				/* @__PURE__ */ O("fog", {
					attach: "fog",
					args: [
						kn,
						15,
						36
					]
				}),
				/* @__PURE__ */ O(Hn, {}),
				/* @__PURE__ */ O("ambientLight", { intensity: 1.25 }),
				/* @__PURE__ */ O("directionalLight", {
					position: [
						-5,
						9,
						7
					],
					intensity: 1.5,
					color: "#ffe0ae"
				}),
				/* @__PURE__ */ O("directionalLight", {
					position: [
						5,
						5,
						-7
					],
					intensity: .55,
					color: "#91a9f5"
				}),
				/* @__PURE__ */ O(Un, {
					rigRef: o,
					orbit: s
				}),
				/* @__PURE__ */ O(i, {
					fallback: null,
					children: /* @__PURE__ */ O(Wn, {
						...t,
						reducedMotion: r,
						canClick: () => !f.current
					})
				})
			]
		})
	});
}
function Hn() {
	return /* @__PURE__ */ k("group", { children: [
		/* @__PURE__ */ k("mesh", { children: [/* @__PURE__ */ O("sphereGeometry", { args: [
			90,
			24,
			16
		] }), /* @__PURE__ */ O("shaderMaterial", {
			vertexShader: jn,
			fragmentShader: Mn,
			side: b,
			depthWrite: !1
		})] }),
		Fn.map(([e, t, n, r]) => {
			let i = r * .72;
			return /* @__PURE__ */ k("mesh", {
				position: [
					e,
					i / 2 - .45,
					t
				],
				children: [/* @__PURE__ */ O("cylinderGeometry", { args: [
					n * .25,
					n * .7,
					i,
					5
				] }), /* @__PURE__ */ O("meshLambertMaterial", {
					color: "#31475d",
					emissive: "#1a2939",
					emissiveIntensity: .4,
					flatShading: !0
				})]
			}, `${e}:${t}`);
		}),
		/* @__PURE__ */ k("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				-.405,
				-8.5
			],
			children: [/* @__PURE__ */ O("planeGeometry", { args: [28, 8] }), /* @__PURE__ */ O("shaderMaterial", {
				vertexShader: Nn,
				fragmentShader: Pn,
				transparent: !0,
				depthWrite: !1
			})]
		})
	] });
}
function Un({ rigRef: e, orbit: t }) {
	let n = y((e) => e.camera), r = y((e) => e.gl), i = y((e) => e.invalidate), o = y((e) => e.size);
	return a(() => (e.current = {
		camera: n,
		canvas: r.domElement,
		invalidate: i
	}, () => {
		e.current = null;
	}), [
		n,
		r,
		i,
		e
	]), v(() => {
		let { yaw: e, pitch: r } = t.current, i = 11.5 + Math.max(0, 1.12 - o.width / Math.max(o.height, 1)) * 7 + Math.max(0, r - 1.02) * 1.8;
		n.position.set(Math.sin(e) * Math.cos(r) * i, Math.sin(r) * i, Math.cos(e) * Math.cos(r) * i), n.lookAt(0, 0, 0);
	}), null;
}
function Wn({ cells: e, walls: t, onCell: n, onInspectCell: r, highlights: i, selectedCell: o, anchorRid: l, reducedMotion: u, canClick: d }) {
	let [f, ...p] = ee(T, [`${Sn}board.webp`, ...Cn.map((e) => `${Sn}${e}`)]), m = s(() => {
		let e = f.clone();
		return e.colorSpace = C, e.wrapS = te, e.wrapT = te, e.repeat.set(.58, .68), e.offset.set(.21, .16), e.needsUpdate = !0, e;
	}, [f]);
	a(() => () => m.dispose(), [m]);
	let h = s(() => ({
		exit: p[0],
		chest: p[1],
		trap: p[2],
		monster: p[3]
	}), [p]), g = s(() => {
		let e = (e) => new w({
			uniforms: {
				uTime: { value: 0 },
				uDimmed: { value: +!!e }
			},
			vertexShader: In,
			fragmentShader: Ln,
			transparent: !0,
			depthWrite: !1,
			side: S
		});
		return {
			unknown: e(!1),
			dimmed: e(!0)
		};
	}, []), _ = c(g);
	a(() => () => {
		g.unknown.dispose(), g.dimmed.dispose();
	}, [g]);
	let b = e.some((e) => e.walls === null || e.dimmed), x = y((e) => e.invalidate);
	return a(() => {
		x();
	}, [
		e,
		t,
		o,
		i,
		x
	]), a(() => {
		if (!b || u) return;
		let e = window.setInterval(x, 100);
		return () => window.clearInterval(e);
	}, [
		b,
		u,
		x
	]), v(({ clock: e }) => {
		b && !u && (_.current.unknown.uniforms.uTime.value = e.elapsedTime, _.current.dimmed.uniforms.uTime.value = e.elapsedTime);
	}), /* @__PURE__ */ k("group", { children: [
		/* @__PURE__ */ k("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				-.45,
				0
			],
			children: [/* @__PURE__ */ O("planeGeometry", { args: [120, 120] }), /* @__PURE__ */ O("meshBasicMaterial", { color: "#203047" })]
		}),
		/* @__PURE__ */ k("mesh", {
			position: [
				0,
				-.17,
				0
			],
			children: [/* @__PURE__ */ O("boxGeometry", { args: [
				6.65,
				.34,
				6.65
			] }), /* @__PURE__ */ O("meshLambertMaterial", { color: "#1b263d" })]
		}),
		/* @__PURE__ */ k("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				.015,
				0
			],
			children: [/* @__PURE__ */ O("planeGeometry", { args: [6, 6] }), /* @__PURE__ */ O("meshBasicMaterial", { map: m })]
		}),
		e.map((e, t) => /* @__PURE__ */ O(Gn, {
			i: t,
			cell: e,
			onCell: n && (!i || i.has(t)) ? n : r && e.walls !== null && e.feature !== "empty" && !e.resolved ? r : void 0,
			highlight: i?.has(t) ?? !1,
			selected: o === t,
			featureMap: h,
			fogMaterials: g,
			canClick: d
		}, t)),
		/* @__PURE__ */ O(Kn, {
			cells: e,
			anchorRid: l,
			reducedMotion: u
		}),
		[...t].map((t) => /* @__PURE__ */ O(Yn, {
			edge: t,
			cells: e
		}, t)),
		Array.from({ length: 5 }, (e, t) => /* @__PURE__ */ k("group", { children: [/* @__PURE__ */ k("mesh", {
			position: [
				t - 2,
				.075,
				0
			],
			children: [/* @__PURE__ */ O("boxGeometry", { args: [
				.018,
				.015,
				6
			] }), /* @__PURE__ */ O("meshBasicMaterial", { color: "#2b3853" })]
		}), /* @__PURE__ */ k("mesh", {
			position: [
				0,
				.075,
				t - 2
			],
			children: [/* @__PURE__ */ O("boxGeometry", { args: [
				6,
				.015,
				.018
			] }), /* @__PURE__ */ O("meshBasicMaterial", { color: "#2b3853" })]
		})] }, t)),
		Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ O(Jn, {
			value: String.fromCharCode(65 + t),
			position: [
				-3.16,
				.7,
				Bn(t)
			]
		}, `row-${t}`)),
		Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ O(Jn, {
			value: String(t + 1),
			position: [
				zn(t),
				.7,
				3.16
			]
		}, `col-${t}`)),
		/* @__PURE__ */ O(Xn, {})
	] });
}
function Gn({ i: e, cell: t, onCell: n, highlight: r, selected: i, featureMap: a, fogMaterials: o, canClick: s }) {
	let [c, l] = z(e), u = t.walls !== null, d = u && !t.resolved ? t.feature : "empty", f = u ? t.dimmed ? "#0d1630" : i ? "#e6b16e" : r ? Dn : "#91a3c3" : "#080c1d", p = u ? t.dimmed ? .46 : i ? .25 : r ? .3 : .09 : .86, m = zn(l), h = Bn(c);
	return /* @__PURE__ */ k("group", {
		position: [
			m,
			0,
			h
		],
		onClick: n ? (t) => {
			t.stopPropagation(), s() && n(e);
		} : void 0,
		children: [
			/* @__PURE__ */ k("mesh", {
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				position: [
					0,
					.065,
					0
				],
				children: [/* @__PURE__ */ O("planeGeometry", { args: [.98, .98] }), /* @__PURE__ */ O("meshBasicMaterial", {
					color: f,
					transparent: !0,
					opacity: p,
					depthWrite: !1
				})]
			}),
			!u && /* @__PURE__ */ O("mesh", {
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				position: [
					0,
					.075,
					0
				],
				material: o.unknown,
				children: /* @__PURE__ */ O("planeGeometry", { args: [1, 1] })
			}),
			t.dimmed && /* @__PURE__ */ O("mesh", {
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				position: [
					0,
					.68,
					0
				],
				material: o.dimmed,
				children: /* @__PURE__ */ O("planeGeometry", { args: [1, 1] })
			}),
			(r || i) && /* @__PURE__ */ O("group", { children: [-.46, .46].map((e) => /* @__PURE__ */ k("group", { children: [/* @__PURE__ */ k("mesh", {
				position: [
					e,
					.084,
					0
				],
				children: [/* @__PURE__ */ O("boxGeometry", { args: [
					.035,
					.015,
					.93
				] }), /* @__PURE__ */ O("meshBasicMaterial", { color: i ? En : Dn })]
			}), /* @__PURE__ */ k("mesh", {
				position: [
					0,
					.084,
					e
				],
				children: [/* @__PURE__ */ O("boxGeometry", { args: [
					.93,
					.015,
					.035
				] }), /* @__PURE__ */ O("meshBasicMaterial", { color: i ? En : Dn })]
			})] }, e)) }),
			d === "start" && /* @__PURE__ */ k("group", {
				position: [
					-.26,
					0,
					-.24
				],
				children: [
					/* @__PURE__ */ k("mesh", {
						position: [
							0,
							.105,
							0
						],
						children: [/* @__PURE__ */ O("cylinderGeometry", { args: [
							.11,
							.14,
							.12,
							8
						] }), /* @__PURE__ */ O("meshLambertMaterial", { color: t.dimmed ? "#414757" : "#6c5c57" })]
					}),
					/* @__PURE__ */ k("mesh", {
						position: [
							0,
							.36,
							0
						],
						children: [/* @__PURE__ */ O("cylinderGeometry", { args: [
							.018,
							.023,
							.53,
							8
						] }), /* @__PURE__ */ O("meshLambertMaterial", { color: t.dimmed ? "#625551" : "#a87b4b" })]
					}),
					/* @__PURE__ */ k("mesh", {
						position: [
							0,
							.64,
							0
						],
						children: [/* @__PURE__ */ O("sphereGeometry", { args: [
							.035,
							8,
							6
						] }), /* @__PURE__ */ O("meshBasicMaterial", { color: t.dimmed ? "#806f70" : En })]
					}),
					/* @__PURE__ */ k("mesh", {
						position: [
							0,
							.5,
							0
						],
						rotation: [
							-.72,
							0,
							0
						],
						children: [/* @__PURE__ */ O("shapeGeometry", { args: [An] }), /* @__PURE__ */ O("meshLambertMaterial", {
							color: t.dimmed ? "#74646a" : En,
							side: S,
							emissive: t.dimmed ? "#211e2a" : "#49301d",
							emissiveIntensity: .35
						})]
					})
				]
			}),
			d !== "empty" && d !== "start" && /* @__PURE__ */ O("sprite", {
				position: [
					0,
					d === "trap" ? .25 : .47,
					0
				],
				scale: d === "trap" ? [
					.68,
					.5,
					1
				] : [
					.72,
					.84,
					1
				],
				children: /* @__PURE__ */ O("spriteMaterial", {
					map: a[d],
					color: t.dimmed ? "#8a9aad" : "#ffffff",
					transparent: !0,
					alphaTest: .04,
					depthWrite: !1,
					toneMapped: !1
				})
			}),
			d === "monster" && t.monsterTarget != null && /* @__PURE__ */ O(Jn, {
				value: String(t.monsterTarget),
				position: [
					.27,
					.42,
					.2
				]
			}),
			i && /* @__PURE__ */ O(Jn, {
				value: `${String.fromCharCode(65 + c)}${l + 1}`,
				position: [
					-.29,
					.28,
					.3
				]
			}),
			n && /* @__PURE__ */ k("mesh", {
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				position: [
					0,
					.105,
					0
				],
				children: [/* @__PURE__ */ O("planeGeometry", { args: [1, 1] }), /* @__PURE__ */ O("meshBasicMaterial", {
					transparent: !0,
					opacity: 0,
					depthWrite: !1
				})]
			})
		]
	});
}
function Kn({ cells: e, anchorRid: t, reducedMotion: n }) {
	let r = e.findIndex((e) => !!e.pawn), i = r >= 0 ? e[r].pawn : null, a = c(null), s = c(r), l = c(t), u = c(null), d = y((e) => e.invalidate);
	return o(() => {
		let [e, i] = r >= 0 ? z(r) : [0, 0], o = zn(i), c = Bn(e), f = a.current, p = s.current, m = l.current !== t;
		if (s.current = r, l.current = t, !f || r < 0) {
			u.current = null;
			return;
		}
		if (p < 0 || p === r || m) u.current = null, f.position.set(o, 0, c), (p < 0 || m) && (f.rotation.y = 0);
		else {
			let [t, r] = z(p), a = Math.atan2(i - r, e - t);
			if (n) u.current = null, f.position.set(o, 0, c), f.rotation.y = a;
			else {
				let e = f.rotation.y, t = Math.atan2(Math.sin(a - e), Math.cos(a - e));
				u.current = {
					fromX: f.position.x,
					fromZ: f.position.z,
					toX: o,
					toZ: c,
					fromYaw: e,
					turnBy: t,
					started: performance.now()
				};
			}
		}
		d();
	}, [
		r,
		t,
		n,
		d
	]), v((e) => {
		let t = u.current, n = a.current;
		if (!t || !n) return;
		let r = Math.min(1, (performance.now() - t.started) / On), i = r * r * (3 - 2 * r);
		n.position.set(t.fromX + (t.toX - t.fromX) * i, 0, t.fromZ + (t.toZ - t.fromZ) * i), n.rotation.y = t.fromYaw + t.turnBy * i, r < 1 ? e.invalidate() : u.current = null;
	}), !i || r < 0 ? null : /* @__PURE__ */ O("group", {
		ref: a,
		children: /* @__PURE__ */ O(qn, { color: i })
	});
}
function qn({ color: e }) {
	return /* @__PURE__ */ k("group", { children: [
		[-.1, .1].map((e) => /* @__PURE__ */ k("group", {
			position: [
				e,
				0,
				0
			],
			children: [/* @__PURE__ */ k("mesh", {
				position: [
					0,
					.15,
					0
				],
				children: [/* @__PURE__ */ O("boxGeometry", { args: [
					.105,
					.21,
					.12
				] }), /* @__PURE__ */ O("meshLambertMaterial", {
					color: "#40394a",
					flatShading: !0
				})]
			}), /* @__PURE__ */ k("mesh", {
				position: [
					0,
					.065,
					.055
				],
				children: [/* @__PURE__ */ O("boxGeometry", { args: [
					.13,
					.13,
					.19
				] }), /* @__PURE__ */ O("meshLambertMaterial", {
					color: "#675447",
					flatShading: !0
				})]
			})]
		}, e)),
		/* @__PURE__ */ k("mesh", {
			position: [
				0,
				.36,
				0
			],
			children: [/* @__PURE__ */ O("cylinderGeometry", { args: [
				.15,
				.23,
				.35,
				6
			] }), /* @__PURE__ */ O("meshLambertMaterial", {
				color: e,
				emissive: e,
				emissiveIntensity: .14,
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ k("mesh", {
			position: [
				0,
				.37,
				.17
			],
			children: [/* @__PURE__ */ O("boxGeometry", { args: [
				.2,
				.22,
				.045
			] }), /* @__PURE__ */ O("meshLambertMaterial", {
				color: "#4c3c43",
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ k("mesh", {
			position: [
				0,
				.29,
				.2
			],
			children: [/* @__PURE__ */ O("boxGeometry", { args: [
				.25,
				.045,
				.05
			] }), /* @__PURE__ */ O("meshBasicMaterial", { color: "#c3965a" })]
		}),
		[-1, 1].map((t) => /* @__PURE__ */ k("group", {
			position: [
				t * .205,
				.4,
				.01
			],
			children: [/* @__PURE__ */ k("mesh", {
				rotation: [
					0,
					0,
					t * .28
				],
				children: [/* @__PURE__ */ O("cylinderGeometry", { args: [
					.055,
					.075,
					.24,
					6
				] }), /* @__PURE__ */ O("meshLambertMaterial", {
					color: e,
					flatShading: !0
				})]
			}), /* @__PURE__ */ k("mesh", {
				position: [
					t * .035,
					-.135,
					.045
				],
				children: [/* @__PURE__ */ O("boxGeometry", { args: [
					.1,
					.095,
					.11
				] }), /* @__PURE__ */ O("meshLambertMaterial", {
					color: "#a88365",
					flatShading: !0
				})]
			})]
		}, t)),
		/* @__PURE__ */ k("mesh", {
			position: [
				0,
				.43,
				-.2
			],
			children: [/* @__PURE__ */ O("boxGeometry", { args: [
				.24,
				.27,
				.14
			] }), /* @__PURE__ */ O("meshLambertMaterial", {
				color: "#775b48",
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ k("mesh", {
			position: [
				0,
				.59,
				-.2
			],
			rotation: [
				0,
				0,
				Math.PI / 2
			],
			children: [/* @__PURE__ */ O("cylinderGeometry", { args: [
				.055,
				.055,
				.25,
				6
			] }), /* @__PURE__ */ O("meshLambertMaterial", {
				color: "#a18563",
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ k("mesh", {
			position: [
				0,
				.64,
				0
			],
			children: [/* @__PURE__ */ O("sphereGeometry", { args: [
				.16,
				8,
				6
			] }), /* @__PURE__ */ O("meshLambertMaterial", {
				color: e,
				emissive: e,
				emissiveIntensity: .12,
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ k("mesh", {
			position: [
				0,
				.625,
				.12
			],
			children: [/* @__PURE__ */ O("sphereGeometry", { args: [
				.105,
				8,
				6
			] }), /* @__PURE__ */ O("meshLambertMaterial", {
				color: "#d7ab80",
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ k("mesh", {
			position: [
				0,
				.71,
				.12
			],
			children: [/* @__PURE__ */ O("boxGeometry", { args: [
				.24,
				.045,
				.11
			] }), /* @__PURE__ */ O("meshLambertMaterial", {
				color: e,
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ k("mesh", {
			position: [
				.28,
				.24,
				.075
			],
			children: [/* @__PURE__ */ O("boxGeometry", { args: [
				.12,
				.14,
				.12
			] }), /* @__PURE__ */ O("meshLambertMaterial", {
				color: "#a57144",
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ k("mesh", {
			position: [
				.28,
				.24,
				.138
			],
			children: [/* @__PURE__ */ O("boxGeometry", { args: [
				.075,
				.085,
				.012
			] }), /* @__PURE__ */ O("meshBasicMaterial", { color: "#ffc66a" })]
		})
	] });
}
function Jn({ value: e, position: t }) {
	let n = s(() => {
		let t = document.createElement("canvas");
		t.width = 128, t.height = 96;
		let n = t.getContext("2d");
		n && (n.fillStyle = "#102238", n.fillRect(4, 4, 120, 88), n.strokeStyle = "#d4a668", n.lineWidth = 7, n.strokeRect(5, 5, 118, 86), n.fillStyle = "#fff0cf", n.font = "bold 56px sans-serif", n.textAlign = "center", n.textBaseline = "middle", n.fillText(e, 64, 49));
		let r = new x(t);
		return r.colorSpace = C, r;
	}, [e]);
	return a(() => () => n.dispose(), [n]), /* @__PURE__ */ O("sprite", {
		position: t,
		scale: [
			.34,
			.25,
			1
		],
		children: /* @__PURE__ */ O("spriteMaterial", {
			map: n,
			transparent: !0,
			depthWrite: !1,
			toneMapped: !1
		})
	});
}
function Yn({ edge: e, cells: t }) {
	let n = e < 30, r = n ? e : e - 30, i = Math.floor(n ? r / 5 : r / 6), a = n ? r % 5 : r % 6, o = n ? a - 2 : zn(a), s = n ? Bn(i) : i - 2, c = i * 6 + a, l = n ? c + 1 : c + 6, u = !!t[c]?.dimmed && !!t[l]?.dimmed, d = n ? [
		.18,
		.5,
		.93
	] : [
		.93,
		.5,
		.18
	], f = n ? [
		.24,
		.075,
		.99
	] : [
		.99,
		.075,
		.24
	];
	return /* @__PURE__ */ k("group", {
		position: [
			o,
			0,
			s
		],
		children: [
			/* @__PURE__ */ k("mesh", {
				position: [
					.06,
					.055,
					.07
				],
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ O("planeGeometry", { args: [n ? .34 : 1.04, n ? 1.04 : .34] }), /* @__PURE__ */ O("meshBasicMaterial", {
					color: "#050c1a",
					transparent: !0,
					opacity: .48,
					depthWrite: !1
				})]
			}),
			/* @__PURE__ */ k("mesh", {
				position: [
					0,
					.3,
					0
				],
				children: [/* @__PURE__ */ O("boxGeometry", { args: d }), /* @__PURE__ */ O("meshLambertMaterial", {
					color: u ? "#243348" : wn,
					flatShading: !0
				})]
			}),
			/* @__PURE__ */ k("mesh", {
				position: [
					0,
					.585,
					0
				],
				children: [/* @__PURE__ */ O("boxGeometry", { args: f }), /* @__PURE__ */ O("meshLambertMaterial", {
					color: u ? "#44536a" : Tn,
					flatShading: !0
				})]
			}),
			[-.22, .22].map((e) => /* @__PURE__ */ k("mesh", {
				position: n ? [
					0,
					.31,
					e
				] : [
					e,
					.31,
					0
				],
				children: [/* @__PURE__ */ O("boxGeometry", { args: n ? [
					.205,
					.43,
					.015
				] : [
					.015,
					.43,
					.205
				] }), /* @__PURE__ */ O("meshBasicMaterial", { color: "#1c293d" })]
			}, e))
		]
	});
}
function Xn() {
	return /* @__PURE__ */ k("group", { children: [[-3.16, 3.16].map((e) => /* @__PURE__ */ k("group", { children: [
		/* @__PURE__ */ k("mesh", {
			position: [
				e,
				.2,
				0
			],
			children: [/* @__PURE__ */ O("boxGeometry", { args: [
				.3,
				.48,
				6.65
			] }), /* @__PURE__ */ O("meshLambertMaterial", { color: wn })]
		}),
		/* @__PURE__ */ k("mesh", {
			position: [
				0,
				.2,
				e
			],
			children: [/* @__PURE__ */ O("boxGeometry", { args: [
				6.65,
				.48,
				.3
			] }), /* @__PURE__ */ O("meshLambertMaterial", { color: wn })]
		}),
		/* @__PURE__ */ k("mesh", {
			position: [
				e,
				.47,
				0
			],
			children: [/* @__PURE__ */ O("boxGeometry", { args: [
				.38,
				.075,
				6.72
			] }), /* @__PURE__ */ O("meshLambertMaterial", { color: Tn })]
		}),
		/* @__PURE__ */ k("mesh", {
			position: [
				0,
				.47,
				e
			],
			children: [/* @__PURE__ */ O("boxGeometry", { args: [
				6.72,
				.075,
				.38
			] }), /* @__PURE__ */ O("meshLambertMaterial", { color: Tn })]
		})
	] }, e)), [-3.15, 3.15].flatMap((e) => [-3.15, 3.15].map((t) => /* @__PURE__ */ k("group", {
		position: [
			e,
			0,
			t
		],
		children: [
			/* @__PURE__ */ k("mesh", {
				position: [
					0,
					.42,
					0
				],
				children: [/* @__PURE__ */ O("boxGeometry", { args: [
					.45,
					.85,
					.45
				] }), /* @__PURE__ */ O("meshLambertMaterial", { color: "#44546b" })]
			}),
			/* @__PURE__ */ k("mesh", {
				position: [
					0,
					.88,
					0
				],
				children: [/* @__PURE__ */ O("boxGeometry", { args: [
					.52,
					.12,
					.52
				] }), /* @__PURE__ */ O("meshLambertMaterial", { color: Tn })]
			}),
			/* @__PURE__ */ k("mesh", {
				position: [
					0,
					1.08,
					0
				],
				children: [/* @__PURE__ */ O("coneGeometry", { args: [
					.14,
					.38,
					6
				] }), /* @__PURE__ */ O("meshBasicMaterial", { color: e === t ? "#ffbb62" : "#9470e7" })]
			}),
			e === t && /* @__PURE__ */ O("pointLight", {
				position: [
					0,
					1.2,
					0
				],
				color: "#ff9e56",
				intensity: 2,
				distance: 4.2
			})
		]
	}, `${e}:${t}`)))] });
}
//#endregion
//#region src/games/lairs/board-scene.tsx
var Zn = "./games/lairs/", Qn = {
	exit: "exit.webp",
	chest: "chest.webp",
	trap: "trap.webp",
	monster: "monster.webp"
};
function $n({ color: e, size: t, className: n = "", anchorRef: r }) {
	return /* @__PURE__ */ k("span", {
		ref: r,
		className: `lairs-pawn-token ${n}`,
		style: {
			"--lairs-pawn": e,
			...t ? {
				width: t,
				height: t
			} : {}
		},
		"aria-hidden": "true",
		children: [/* @__PURE__ */ O("span", { className: "lairs-pawn-token__inlay" }), /* @__PURE__ */ O("span", { className: "lairs-pawn-token__core" })]
	});
}
function er({ i: e, cell: t, onClick: n, inspectLabel: r, highlight: i, selected: a, anchorRid: o }) {
	let { ref: s } = u(o ? `cell:${o}:${e}` : null), { ref: c, hidden: l } = u(o && t.pawn ? `pawn:${o}:${e}` : null), [d, f] = z(e), p = t.walls !== null, m = p && t.feature !== "empty" && !t.resolved, h = m ? Qn[t.feature] : void 0, g = `${String.fromCharCode(65 + d)}${f + 1}`, _ = /* @__PURE__ */ k(D, { children: [
		i && /* @__PURE__ */ O("span", {
			className: "lairs-cell__target",
			"aria-hidden": "true"
		}),
		m && (h ? /* @__PURE__ */ O("img", {
			className: `lairs-cell__feature lairs-cell__feature--${t.feature}`,
			src: `${Zn}${h}`,
			alt: "",
			draggable: !1
		}) : /* @__PURE__ */ O("span", {
			className: "lairs-cell__start",
			"aria-hidden": "true",
			children: "⚑"
		})),
		m && t.feature === "monster" && t.monsterTarget != null && /* @__PURE__ */ O("span", {
			className: "lairs-cell__target-number font-mono tabular-nums",
			children: t.monsterTarget
		}),
		t.pawn && /* @__PURE__ */ O($n, {
			color: t.pawn,
			className: `lairs-cell__pawn ${l ? "is-fx-hidden" : ""}`,
			anchorRef: c
		}),
		a && /* @__PURE__ */ O("span", {
			className: "lairs-cell__coord font-mono",
			children: g
		})
	] });
	return /* @__PURE__ */ O("div", {
		ref: s,
		className: `lairs-cell ${p ? "" : "is-unknown"} ${t.dimmed ? "is-dimmed" : ""} ${i ? "is-target" : ""} ${a ? "is-selected" : ""}`,
		style: {
			left: `${f / 6 * 100}%`,
			top: `${d / 6 * 100}%`,
			width: `${100 / 6}%`,
			height: `${100 / 6}%`
		},
		children: n ? /* @__PURE__ */ O("button", {
			type: "button",
			className: "lairs-cell__hit",
			"aria-label": r ?? g,
			onClick: () => n(e),
			children: _
		}) : /* @__PURE__ */ O("div", {
			className: "lairs-cell__hit",
			children: _
		})
	});
}
function tr({ e }) {
	if (e < 30) {
		let t = Math.floor(e / 5), n = e % 5;
		return /* @__PURE__ */ O("span", {
			className: "lairs-wall lairs-wall--vertical",
			style: {
				left: `${(n + 1) / 6 * 100}%`,
				top: `${t / 6 * 100}%`,
				height: `${100 / 6}%`
			}
		});
	}
	let t = e - 30, n = Math.floor(t / 6), r = t % 6;
	return /* @__PURE__ */ O("span", {
		className: "lairs-wall lairs-wall--horizontal",
		style: {
			left: `${r / 6 * 100}%`,
			top: `${(n + 1) / 6 * 100}%`,
			width: `${100 / 6}%`
		}
	});
}
function nr({ cells: e, walls: t, onCell: n, onInspectCell: r, inspectLabel: i, highlights: a, selectedCell: o, anchorRid: s }) {
	return /* @__PURE__ */ k("div", {
		className: "lairs-board",
		"aria-label": "6 × 6 maze",
		style: { backgroundImage: `url(${Zn}board.webp)` },
		children: [/* @__PURE__ */ k("div", {
			className: "lairs-board__floor",
			children: [
				e.map((e, t) => {
					let c = !!n && (!a || a.has(t)), l = !c && !!r && e.walls !== null && e.feature !== "empty" && !e.resolved;
					return /* @__PURE__ */ O(er, {
						i: t,
						cell: e,
						onClick: c ? n : l ? r : void 0,
						inspectLabel: l ? i?.(t) : void 0,
						highlight: a?.has(t) ?? !1,
						selected: o === t,
						anchorRid: s
					}, t);
				}),
				[...t].map((e) => /* @__PURE__ */ O(tr, { e }, e)),
				Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ O("span", {
					className: "lairs-board__axis lairs-board__axis--row",
					style: { top: `${(t + .5) / 6 * 100}%` },
					children: String.fromCharCode(65 + t)
				}, `row-${t}`)),
				Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ O("span", {
					className: "lairs-board__axis lairs-board__axis--col",
					style: { left: `${(t + .5) / 6 * 100}%` },
					children: t + 1
				}, `col-${t}`))
			]
		}), /* @__PURE__ */ O("span", {
			className: "lairs-board__sigil",
			"aria-hidden": "true",
			children: "✦"
		})]
	});
}
function rr(e) {
	let [t, n] = l(Rn);
	a(() => {
		if (t) return;
		let e = null, r = 0, i = () => {
			if (document.hidden) {
				e !== null && window.clearTimeout(e), e = null, r = 0;
				return;
			}
			if (Rn()) {
				n(!0);
				return;
			}
			e !== null || r >= 2 || (e = window.setTimeout(() => {
				e = null, r += 1, i();
			}, r === 0 ? 500 : 2e3));
		};
		i();
		let a = () => {
			document.hidden || (r = 0), i();
		};
		return document.addEventListener("visibilitychange", a), window.addEventListener("pageshow", a), window.addEventListener("focus", a), () => {
			e !== null && window.clearTimeout(e), document.removeEventListener("visibilitychange", a), window.removeEventListener("pageshow", a), window.removeEventListener("focus", a);
		};
	}, [t]);
	let r = /* @__PURE__ */ O(nr, { ...e });
	return t ? /* @__PURE__ */ O(Vn, {
		...e,
		fallback: r
	}) : r;
}
//#endregion
//#region src/games/lairs/card-scene.tsx
var ir = "./games/lairs/", ar = {
	300: "sun-shard.webp",
	301: "hero-crown.webp",
	311: "lore-book.webp"
}, or = {
	book: "✦",
	statue: "♜",
	scroll: "⌁",
	amulet: "◇",
	cup: "♛",
	shard: "◆",
	crown: "♛",
	orb: "◉",
	instrument: "♫"
};
function sr({ id: e, small: t = !1 }) {
	let n = ar[e], r = R.get(e)?.type;
	return n ? /* @__PURE__ */ O("img", {
		className: t ? "lairs-treasure__icon is-small" : "lairs-treasure__icon",
		src: `${ir}${n}`,
		alt: "",
		draggable: !1
	}) : /* @__PURE__ */ O("span", {
		className: t ? "lairs-treasure__glyph is-small" : "lairs-treasure__glyph",
		"aria-hidden": "true",
		children: r ? or[r] : "✦"
	});
}
function cr({ id: e, selected: t = !1, onClick: n }) {
	let r = p(), i = R.get(e);
	if (!i) return null;
	let a = r(`games.lairs.card${e}name`), o = r(`games.lairs.card${e}bonus`);
	return /* @__PURE__ */ k("button", {
		type: "button",
		onClick: n,
		disabled: !n,
		"aria-pressed": n ? t : void 0,
		"aria-label": `${a}，${i.base}，${o}`,
		className: `lairs-treasure ${n ? "is-pickable" : ""} ${t ? "is-selected" : ""}`,
		children: [
			/* @__PURE__ */ O("span", {
				className: "lairs-treasure__art",
				children: /* @__PURE__ */ O(sr, { id: e })
			}),
			/* @__PURE__ */ k("span", {
				className: "lairs-treasure__name",
				children: [/* @__PURE__ */ O("strong", { children: a }), /* @__PURE__ */ k("b", {
					className: "font-mono tabular-nums",
					children: ["★", i.base]
				})]
			}),
			/* @__PURE__ */ O("span", {
				className: "lairs-treasure__bonus",
				children: o
			}),
			t && /* @__PURE__ */ O("span", {
				className: "lairs-treasure__check",
				"aria-hidden": "true",
				children: "✓"
			})
		]
	});
}
//#endregion
//#region src/games/lairs/adventure-view.tsx
var lr = (e) => `${String.fromCharCode(65 + Math.floor(e / 6))}${e % 6 + 1}`, ur = {
	white: "□",
	quick: "⚡",
	perc: "◉",
	know: "⚒",
	brawn: "✊",
	guile: "◆"
}, dr = {
	fresh: "games.lairs.apReady",
	spent: "games.lairs.apSpent",
	fatigued: "games.lairs.apFatigued",
	conserved: "games.lairs.apConserved"
}, fr = {
	adapt: "games.lairs.taskAdapt",
	fatigue: "games.lairs.taskFatigue",
	discardJunk: "games.lairs.taskDiscardJunk",
	discardTreasure: "games.lairs.taskDiscardTreasure",
	discardEither: "games.lairs.taskDiscardEither",
	tuck: "games.lairs.taskTuck",
	downgrade: "games.lairs.taskDowngrade",
	refresh: "games.lairs.taskRefresh",
	exchange: "games.lairs.taskExchange",
	recover: "games.lairs.taskRecover",
	blanket: "games.lairs.taskBlanket",
	learn: "games.lairs.taskLearn",
	locate: "games.lairs.taskLocate",
	walls: "games.lairs.taskWalls",
	scrounge: "games.lairs.taskScrounge",
	appraise: "games.lairs.taskAppraise",
	appraiseKeep: "games.lairs.taskAppraiseKeep",
	shovel: "games.lairs.taskShovel",
	teleport: "games.lairs.taskTeleport",
	return: "games.lairs.taskReturn",
	spawn: "games.lairs.taskSpawn",
	shield: "games.lairs.taskShield",
	ignore: "games.lairs.taskIgnore",
	rope: "games.lairs.taskRope"
}, pr = {
	creep: "games.lairs.actCreep",
	peer: "games.lairs.actPeer",
	backtrack: "games.lairs.actBacktrack",
	charge: "games.lairs.apCharge",
	sneak: "games.lairs.apSneak"
}, mr = {
	creep: "games.lairs.costAnyOne",
	peer: "games.lairs.apCostPeer",
	backtrack: "games.lairs.costQuick",
	charge: "games.lairs.apCostCharge",
	sneak: "games.lairs.apCostSneak"
};
function Q({ children: e, onClick: t, disabled: n, selected: r }) {
	return /* @__PURE__ */ k("button", {
		type: "button",
		className: `lairs-command ${r ? "is-primary" : ""}`,
		onClick: t,
		disabled: n,
		"aria-pressed": r,
		children: [r && "✓ ", e]
	});
}
function hr(e) {
	let t = e.public, n = e.private, r = p(), i = t.adventure, a = t.players.find((t) => t.rid === e.myRid), o = t.players.find((t) => t.rid !== e.myRid), s = i.players[e.myRid], c = n?.adventure, [d, f] = l(null), [h, g] = l(null), [v, ee] = l([]), [y, b] = l(3), [x, te] = l(null), [S, C] = l(null), [w, ne] = l(!1), { ref: T } = u("lairs-ap-dice"), { ref: E } = u("lairs-ap-monster-dice"), re = (t) => e.members.find((e) => e.rid === t)?.name ?? t, ie = (t) => m[(e.members.find((e) => e.rid === t)?.colorIndex ?? 0) % m.length].hex, A = (t) => {
		e.send(t), ee([]), f(null), g(null), C(null);
	}, j = v.length ? v : void 0, M = W(a.fresh) + 2 * a.conserved.length, N = t.turn === e.myRid && (t.phase === "explore" || t.phase === "finalTurn"), P = a.known[String(a.pos)], ae = i.pending?.actor === e.myRid, F = v.reduce((e, t) => e + (t.double ? 2 : 1), 0), oe = (v.length ? v.filter((e) => e.from === "fresh").map((e) => e.kind) : Ue.flatMap((e) => Array(a.fresh[e]).fill(e))).slice(0, 3 - a.conserved.length), I = N && !i.pending && !i.check && !t.pendingChest && !t.pendingHazard && !t.hustleLeft, se = (e) => M >= 2 || a.fresh[e] > 0 || a.conserved.includes(e), ce = (e) => a.fresh[e] > 0 || a.conserved.includes(e), le = P && (P.feature === "empty" || P.resolved), ue = t.peerFree != null && (P?.feature === "monster" || P?.feature === "trap") && !P.resolved, de = t.phase === "draft" ? r("games.lairs.apDraft") : t.phase === "attributes" ? r("games.lairs.apAttributes") : t.phase === "build" ? r("games.lairs.buildTitle") : t.phase === "scoring" ? r("games.lairs.scoringTitle") : r("games.lairs.apStage", { n: i.config.stage }), fe = i.pending ? r(fr[i.pending.kind]) : t.phase === "handoff" ? r("games.lairs.handoffTitle") : t.phase === "finalTurn" && N ? r("games.lairs.finalTurnBanner") : t.turn ? r(N ? "games.lairs.turnBanner" : "games.lairs.apWait", { name: re(t.turn) }) : de, L = /* @__PURE__ */ k("div", {
		className: "lairs-ap-banner",
		children: [/* @__PURE__ */ k("div", { children: [/* @__PURE__ */ O("strong", { children: de }), /* @__PURE__ */ O("span", { children: fe })] }), /* @__PURE__ */ O("div", {
			className: "lairs-ap-seat-row",
			children: t.players.map((e) => /* @__PURE__ */ k("span", {
				style: { "--lairs-seat": ie(e.rid) },
				children: [
					/* @__PURE__ */ O("b", { children: re(e.rid) }),
					" 🎁",
					e.chests,
					" / 👾",
					e.monsters,
					" / 🕳",
					e.traps,
					" ",
					/* @__PURE__ */ k("small", { children: [
						"◆",
						e.hoardCount,
						" · ",
						r("games.lairs.apJunk"),
						i.players[e.rid].junkCount
					] })
				]
			}, e.rid))
		})]
	});
	if (t.phase === "build") return /* @__PURE__ */ O(Vr, {
		t: r,
		banner: L,
		me: a,
		send: A,
		pool: {
			monsters: i.monsters,
			traps: i.traps
		}
	});
	if (t.phase === "draft") {
		let t = i.draftKind === "monster" ? i.monsters : i.traps;
		return /* @__PURE__ */ O(_, {
			adaptive: !0,
			className: "lairs-screen lairs-screen--full",
			banner: L,
			children: /* @__PURE__ */ k("div", {
				className: "lairs-ap-list",
				children: [
					/* @__PURE__ */ k("p", { children: [
						r("games.lairs.apPool"),
						": ",
						[...i.monsters, ...i.traps].map((e) => r(K[e].name)).join(" / ")
					] }),
					/* @__PURE__ */ O("p", { children: r("games.lairs.apWait", { name: re(i.draftActor) }) }),
					Ye(i.config.stage, i.config.boxZero, i.draftKind).filter((e) => !t.includes(e.id)).map((t) => /* @__PURE__ */ k(Q, {
						disabled: i.draftActor !== e.myRid,
						onClick: () => A({
							type: "draftHazard",
							id: t.id
						}),
						children: [/* @__PURE__ */ k("strong", { children: [
							r(t.name),
							" · ",
							t.targets[i.config.stage - 1]
						] }), /* @__PURE__ */ O("small", { children: r(t.text) })]
					}, t.id))
				]
			})
		});
	}
	if (t.phase === "attributes") return /* @__PURE__ */ O(gr, {
		stage: i.config.stage,
		chosen: s.attributesChosen,
		banner: L,
		send: A
	}, e.myRid);
	if (t.phase === "pickFirst") return /* @__PURE__ */ O(_, {
		adaptive: !0,
		className: "lairs-screen lairs-screen--full",
		banner: L,
		children: /* @__PURE__ */ k("div", {
			className: "lairs-ap-list",
			children: [/* @__PURE__ */ O("p", { children: r(t.buildOrder[0] === e.myRid ? "games.lairs.pickFirstPrompt" : "games.lairs.pickFirstWaiting", { name: re(t.buildOrder[0]) }) }), t.buildOrder[0] === e.myRid && t.players.map((e) => /* @__PURE__ */ O(Q, {
				onClick: () => A({
					type: "pickFirst",
					rid: e.rid
				}),
				children: re(e.rid)
			}, e.rid))]
		})
	});
	if (t.phase === "scoring") return /* @__PURE__ */ O(vr, {
		pub: t,
		priv: n,
		rid: e.myRid,
		banner: L,
		send: A
	});
	if (t.phase === "done" && !e.review) return /* @__PURE__ */ O(_, {
		adaptive: !0,
		className: "lairs-screen lairs-screen--full",
		banner: L,
		children: /* @__PURE__ */ O("div", {
			className: "lairs-ap-list",
			children: t.players.map((e) => /* @__PURE__ */ k("p", { children: [
				re(e.rid),
				" · ",
				t.final?.breakdown[e.rid].total,
				" VP"
			] }, e.rid))
		})
	});
	let R = w ? o : a, pe = w ? n?.maze : null, me = Array.from({ length: 36 }, (e, t) => {
		let n = R.known[String(t)];
		if (pe) {
			let e = c?.hazardCells[String(t)], r = e ? K[e].kind : pe.start === t ? "start" : pe.exit === t ? "exit" : pe.chests.includes(t) ? "chest" : "empty", i = new Set(pe.walls);
			return {
				walls: [
					0,
					1,
					2,
					3
				].map((e) => V(i, t, e)),
				feature: r,
				resolved: !!n?.resolved,
				dimmed: !n,
				pawn: R.pos === t ? ie(R.rid) : null,
				monsterTarget: n?.monsterTarget
			};
		}
		return {
			walls: n?.walls ?? null,
			feature: n?.feature ?? "empty",
			resolved: n?.resolved ?? !1,
			pawn: R.pos === t ? ie(R.rid) : null,
			monsterTarget: n?.monsterTarget
		};
	}), he = new Set(pe?.walls ?? s.wallNotes);
	if (!pe) {
		for (let [e, t] of Object.entries(a.known)) for (let n = 0; n < 4; n++) if (t.walls[n]) {
			let t = Se(Number(e), B(Number(e), n));
			t >= 0 && he.add(t);
		}
	}
	let ge = /* @__PURE__ */ new Set();
	if (N && !i.pending && !i.check && !t.pendingChest && !t.pendingHazard && !w) {
		if (d === "backtrack" || d === "flute" || d?.startsWith("junk")) for (let e = 0; e < 36; e++) ge.add(e);
		else for (let e = 0; e < 4; e++) {
			let n = B(a.pos, e);
			n >= 0 && P && !P.walls[e] && (!ue || n === t.peerFree) && ge.add(n);
		}
	}
	let _e = (e) => {
		if (!N || w || i.pending || i.check || t.pendingChest || t.pendingHazard) return;
		if (d === "flute") {
			h == null ? g(e) : A({
				type: "useFlute",
				cell: h,
				to: e,
				pay: j
			});
			return;
		}
		if (d === "junkRope" && S != null) {
			h == null ? g(e) : A({
				type: "useJunk",
				index: S,
				cell: h,
				to: e
			});
			return;
		}
		if ((d === "junkMap" || d === "junkManual") && S != null) {
			A({
				type: "useJunk",
				index: S,
				cell: e
			});
			return;
		}
		if (d === "backtrack") {
			A({
				type: "backtrack",
				to: e,
				pay: j
			});
			return;
		}
		let n = [
			0,
			1,
			2,
			3
		].find((t) => B(a.pos, t) === e);
		n != null && A(t.hustleLeft ? {
			type: "move",
			dir: n
		} : {
			type: !ue && (d === "peer" || d === "charge" || d === "sneak") ? d : "creep",
			dir: n,
			pay: j
		});
	}, z = (e, t) => {
		let n = [...v], r = n.filter((n) => n.kind === e && n.from === t), i = t === "fresh" ? a.fresh[e] : a.conserved.filter((t) => t === e).length;
		if (t === "conserved" && r.some((e) => !e.double)) {
			let r = n.findIndex((n) => n.kind === e && n.from === t && !n.double);
			n[r] = {
				...n[r],
				double: !0
			};
		} else r.length < i ? n.push({
			kind: e,
			from: t
		}) : ee(n.filter((n) => n.kind !== e || n.from !== t));
		(r.length < i || t === "conserved" && r.some((e) => !e.double)) && ee(n);
	}, ve = (e) => {
		let t = c?.junk[e];
		t === 10 || t === 3 || t === 14 ? (C(e), g(null), f(t === 10 ? "junkMap" : t === 3 ? "junkManual" : "junkRope"), te(null)) : A({
			type: "useJunk",
			index: e
		});
	}, ye = P?.hazardId && !P.resolved ? K[P.hazardId] : null, be = t.pendingHazard ?? ye?.kind, xe = /* @__PURE__ */ k("div", {
		className: "lairs-ap-controls",
		children: [
			/* @__PURE__ */ k("div", {
				className: "lairs-ap-toolbar",
				children: [
					/* @__PURE__ */ k(Q, {
						onClick: () => te("junk"),
						children: [
							r("games.lairs.apJunk"),
							" ",
							c?.junk.length ?? 0,
							"/3"
						]
					}),
					/* @__PURE__ */ O(Q, {
						onClick: () => te("hoard"),
						children: r("games.lairs.apHoard")
					}),
					/* @__PURE__ */ O(Q, {
						onClick: () => te("info"),
						children: r("games.lairs.apInfo")
					}),
					/* @__PURE__ */ O(Q, {
						onClick: () => ne(!w),
						children: r("games.lairs.apViewSwitch")
					})
				]
			}),
			/* @__PURE__ */ O("div", {
				className: "lairs-ap-actions",
				children: !N || i.pending || i.check || t.pendingChest ? /* @__PURE__ */ O("p", { children: fe }) : ue ? /* @__PURE__ */ O(Q, {
					onClick: () => A({
						type: "creep",
						dir: [
							0,
							1,
							2,
							3
						].find((e) => B(a.pos, e) === t.peerFree)
					}),
					children: r("games.lairs.peerEnter")
				}) : t.hustleLeft ? /* @__PURE__ */ k(D, { children: [/* @__PURE__ */ O("b", { children: r("games.lairs.hustleLeft", { n: t.hustleLeft }) }), /* @__PURE__ */ O(Q, {
					onClick: () => A({ type: "stopHustle" }),
					children: r("games.lairs.apSkip")
				})] }) : /* @__PURE__ */ k(D, { children: [!t.pendingHazard && /* @__PURE__ */ k(D, { children: [
					[
						"creep",
						"peer",
						"backtrack",
						...i.config.stage >= 2 ? ["charge"] : [],
						...i.config.stage >= 3 ? ["sneak"] : []
					].map((e) => /* @__PURE__ */ k(Q, {
						selected: d === e,
						disabled: e === "backtrack" ? !ce("quick") : e === "peer" ? !se("perc") : e === "charge" ? !se("brawn") : e === "sneak" ? !se("guile") : !M && t.peerFree == null && !i.scroungeFree,
						onClick: () => {
							ne(!1), f(e);
						},
						children: [r(pr[e]), /* @__PURE__ */ O("small", { children: r(mr[e]) })]
					}, e)),
					/* @__PURE__ */ k(Q, {
						disabled: !se("quick"),
						onClick: () => A({
							type: "hustle",
							pay: j
						}),
						children: [r("games.lairs.actHustle"), /* @__PURE__ */ O("small", { children: r("games.lairs.costHustle") })]
					}),
					/* @__PURE__ */ k(Q, {
						disabled: !le || !se("know") || s.searched.includes(a.pos),
						onClick: () => A({
							type: "scrounge",
							pay: j
						}),
						children: [r("games.lairs.apScrounge"), /* @__PURE__ */ O("small", { children: r("games.lairs.apCostScrounge") })]
					}),
					/* @__PURE__ */ k(Q, {
						disabled: i.scavengeCell == null || !ce("know"),
						onClick: () => A({
							type: "scavenge",
							pay: j
						}),
						children: [r("games.lairs.apScavenge"), /* @__PURE__ */ O("small", { children: r("games.lairs.apCostKnow") })]
					}),
					i.config.stage >= 3 && /* @__PURE__ */ k(Q, {
						disabled: !le || !ce("brawn") || !W(a.fatigued),
						onClick: () => A({
							type: "recover",
							pay: j
						}),
						children: [r("games.lairs.apRecover"), /* @__PURE__ */ O("small", { children: r("games.lairs.apCostBrawn") })]
					}),
					/* @__PURE__ */ O(Q, {
						onClick: () => A({ type: "endTurn" }),
						children: r("games.lairs.actEndTurn")
					}),
					P?.feature === "exit" && /* @__PURE__ */ O(Q, {
						disabled: !(a.chests >= 3 || a.monsters >= 3 || a.chests >= 2 && a.monsters >= 2),
						onClick: () => A({ type: "exit" }),
						children: r("games.lairs.actExit")
					}),
					n?.hoard.includes(322) && !c?.forcedTucked.includes(322) && /* @__PURE__ */ O(Q, {
						disabled: !ce("know"),
						onClick: () => {
							f("flute"), ne(!1), g(null);
						},
						children: r("games.lairs.card322name")
					}),
					/* @__PURE__ */ O(Q, {
						disabled: !le || !oe.length,
						onClick: () => A({
							type: "conserve",
							cubes: oe
						}),
						children: r("games.lairs.actConserve")
					})
				] }), be && /* @__PURE__ */ k("div", {
					className: "lairs-ap-check-buy",
					children: [
						/* @__PURE__ */ k("label", { children: [
							r("games.lairs.apBuy"),
							" ",
							/* @__PURE__ */ O("select", {
								value: Math.min(y, M),
								onChange: (e) => b(Number(e.target.value)),
								children: Array.from({ length: Math.min(12, M) + 1 }, (e, t) => /* @__PURE__ */ O("option", {
									value: t,
									children: t
								}, t))
							})
						] }),
						/* @__PURE__ */ O(Q, {
							onClick: () => A({
								type: be === "monster" ? "fight" : "disarm",
								dice: j ? F : Math.min(y, M),
								pay: j
							}),
							children: r("games.lairs.apRoll", { n: j ? F : Math.min(y, M) })
						}),
						/* @__PURE__ */ k("small", { children: [
							r("games.lairs.apBeforeDice"),
							" ",
							i.freeDice.map((e) => e ? "◆" : "□").join(" ")
						] })
					]
				})] })
			}),
			/* @__PURE__ */ k("div", {
				className: "lairs-ap-pay-info",
				children: [
					r("games.lairs.apPay"),
					" · ",
					r("games.lairs.apDouble")
				]
			}),
			/* @__PURE__ */ O("div", {
				className: "lairs-ap-pay-row",
				children: Ue.map((e) => {
					let t = v.filter((t) => t.kind === e && t.from === "fresh").length, n = v.filter((t) => t.kind === e && t.from === "conserved").reduce((e, t) => e + (t.double ? 2 : 1), 0);
					return /* @__PURE__ */ k("div", {
						className: "lairs-ap-energy",
						children: [
							/* @__PURE__ */ k("span", { children: [
								ur[e],
								" ",
								r(G[e])
							] }),
							/* @__PURE__ */ k("button", {
								type: "button",
								disabled: !N || !a.fresh[e] || !!i.check || !!i.pending,
								"aria-label": `${r(G[e])} ${r("games.lairs.apReady")}`,
								"aria-pressed": t > 0,
								onClick: () => z(e, "fresh"),
								className: t ? "is-picked" : "",
								children: [t ? `✓${t}/` : "", a.fresh[e]]
							}),
							/* @__PURE__ */ k("button", {
								type: "button",
								disabled: !N || !a.conserved.includes(e) || !!i.check || !!i.pending,
								"aria-label": `${r(G[e])} ${r("games.lairs.apConserved")}`,
								"aria-pressed": n > 0,
								title: r("games.lairs.apDouble"),
								onClick: () => z(e, "conserved"),
								className: n ? "is-picked" : "",
								children: [
									n ? `✓${n}/` : "",
									"◇",
									a.conserved.filter((t) => t === e).length
								]
							}),
							/* @__PURE__ */ k("small", { children: [
								r("games.lairs.apSpent"),
								a.spent[e],
								" · ",
								r("games.lairs.apFatigued"),
								a.fatigued[e]
							] })
						]
					}, e);
				})
			})
		]
	}), Ce = i.pending && ae && c ? /* @__PURE__ */ O(_r, {
		pub: t,
		priv: n,
		send: A
	}, `${i.pending.kind}-${JSON.stringify(c.options)}-${c.appraisal.join(",")}`) : i.check ? /* @__PURE__ */ k("div", {
		className: "lairs-ap-dialog",
		children: [
			/* @__PURE__ */ O("strong", { children: r("games.lairs.apTotal", {
				n: i.check.total,
				target: i.check.target
			}) }),
			/* @__PURE__ */ O("div", {
				ref: T,
				className: "lairs-ap-dice",
				children: i.check.dice.map((e, t) => /* @__PURE__ */ k("span", {
					className: e.power ? "is-power" : "",
					children: [e.value, /* @__PURE__ */ O("small", { children: e.source ? r(G[e.source]) : "★" })]
				}, t))
			}),
			i.check.monsterDice.length > 0 && /* @__PURE__ */ k("p", {
				ref: E,
				children: [
					r("games.lairs.apMonsterDice"),
					": ",
					i.check.monsterDice.map((e) => e === "skull" ? r("games.lairs.apSkull") : e === 0 ? r("games.lairs.apBlank") : e).join(" / ")
				]
			}),
			N && i.check.stage === "rolled" ? /* @__PURE__ */ k(D, { children: [
				i.config.stage >= 3 && /* @__PURE__ */ O(Q, {
					disabled: !ce("guile"),
					onClick: () => A({ type: "improvise" }),
					children: r("games.lairs.apImprovise")
				}),
				c?.junk.map((e, t) => e === 6 ? /* @__PURE__ */ O("div", { children: i.check.dice.map((e, n) => /* @__PURE__ */ O(Q, {
					onClick: () => A({
						type: "useJunk",
						index: t,
						die: n
					}),
					children: r("games.lairs.apCoffee", { n: n + 1 })
				}, n)) }, t) : e === 13 ? /* @__PURE__ */ O("div", { children: [
					-2,
					-1,
					1,
					2
				].map((e) => /* @__PURE__ */ O(Q, {
					onClick: () => A({
						type: "useJunk",
						index: t,
						delta: e
					}),
					children: r("games.lairs.apWandDelta", { n: e > 0 ? `+${e}` : e })
				}, e)) }, t) : null),
				/* @__PURE__ */ O(Q, {
					onClick: () => A({ type: "finishCheck" }),
					children: r("games.lairs.apFinishCheck")
				})
			] }) : /* @__PURE__ */ O("p", { children: r("games.lairs.apCheckWait") })
		]
	}) : N && t.pendingChest ? /* @__PURE__ */ k("div", {
		className: "lairs-ap-dialog",
		children: [/* @__PURE__ */ O("strong", { children: r("games.lairs.chooseTreasure") }), /* @__PURE__ */ O("div", {
			className: "lairs-ap-cards",
			children: t.display.map((e, t) => /* @__PURE__ */ O(cr, {
				id: e,
				onClick: () => A({
					type: "chooseTreasure",
					index: t
				})
			}, e))
		})]
	}) : x ? /* @__PURE__ */ k("div", {
		className: "lairs-ap-dialog",
		children: [/* @__PURE__ */ O(Q, {
			onClick: () => te(null),
			children: r("games.lairs.apClose")
		}), x === "info" ? /* @__PURE__ */ k(D, { children: [
			/* @__PURE__ */ O("p", { children: r("games.lairs.apRules") }),
			/* @__PURE__ */ O("p", { children: r("games.lairs.compatibility") }),
			/* @__PURE__ */ O("p", { children: r("games.lairs.monsterDiceRule") }),
			[...i.monsters, ...i.traps].map((e, t) => /* @__PURE__ */ k("p", { children: [
				/* @__PURE__ */ k("b", { children: [
					r(K[e].name),
					" · ",
					K[e].targets[i.config.stage - 1]
				] }),
				/* @__PURE__ */ O("br", {}),
				r(K[e].text)
			] }, `${e}-${t}`))
		] }) : x === "hoard" ? /* @__PURE__ */ O("div", {
			className: "lairs-ap-cards",
			children: n?.hoard.map((e) => /* @__PURE__ */ k("div", { children: [/* @__PURE__ */ O(cr, { id: e }), c?.forcedTucked.includes(e) && /* @__PURE__ */ O("small", { children: r("games.lairs.apForcedTucked") })] }, e))
		}) : /* @__PURE__ */ O("div", {
			className: "lairs-ap-list",
			children: c?.junk.map((e, n) => /* @__PURE__ */ k("div", { children: [
				/* @__PURE__ */ O("b", { children: r(Qe.get(e).name) }),
				/* @__PURE__ */ O("p", { children: r(Qe.get(e).text) }),
				/* @__PURE__ */ O(Q, {
					disabled: !N || !!i.pending || !!i.check || t.pendingChest || [
						0,
						6,
						13,
						15,
						25
					].includes(e),
					onClick: () => ve(n),
					children: r("games.lairs.apUse")
				})
			] }, n))
		})]
	}) : null;
	return /* @__PURE__ */ O("div", {
		className: "lairs-ap-screen",
		children: /* @__PURE__ */ k(_, {
			adaptive: !0,
			className: "lairs-screen lairs-screen--board lairs-screen--adventure",
			banner: L,
			scroll: !1,
			actionsHeight: "h-[254px]",
			actions: xe,
			children: [/* @__PURE__ */ k("div", {
				className: "lairs-ap-board-area",
				children: [
					/* @__PURE__ */ k("div", {
						className: "lairs-ap-map-label",
						children: [
							r(w ? "games.lairs.apBuilderMap" : "games.lairs.apExplorerMap"),
							" ",
							I && d ? r(d === "flute" ? "games.lairs.apFlute" : d === "junkRope" ? "games.lairs.apUseRope" : "games.lairs.apTarget") : ""
						]
					}),
					/* @__PURE__ */ O("div", {
						className: "lairs-board-wrap",
						children: /* @__PURE__ */ O(rr, {
							cells: me,
							walls: he,
							onCell: ge.size ? _e : void 0,
							highlights: ge,
							selectedCell: h,
							anchorRid: R.rid
						})
					}),
					/* @__PURE__ */ k("div", {
						className: "lairs-ap-notes",
						children: [
							s.enraging ? r("games.lairs.apEnraging") : i.scroungeFree || t.peerFree != null ? r("games.lairs.apFree") : r("games.lairs.apSearched", { cells: s.searched.map(lr).join(" ") }),
							/* @__PURE__ */ O("br", {}),
							r("games.lairs.apLocated", { cells: s.located.map(lr).join(" ") }),
							" ",
							F > 0 && /* @__PURE__ */ k("button", {
								type: "button",
								onClick: () => ee([]),
								children: [
									r("games.lairs.apAutoPay"),
									" (",
									F,
									")"
								]
							})
						]
					})
				]
			}), Ce && /* @__PURE__ */ O("div", {
				className: "lairs-ap-modal",
				children: Ce
			})]
		})
	});
}
function gr({ stage: e, chosen: t, banner: n, send: r }) {
	let i = p(), [a, o] = l([]);
	return /* @__PURE__ */ O(_, {
		adaptive: !0,
		className: "lairs-screen lairs-screen--full",
		banner: n,
		children: /* @__PURE__ */ k("div", {
			className: "lairs-ap-list",
			children: [
				/* @__PURE__ */ O("p", { children: i("games.lairs.apAttributes") }),
				Xe(e).map((e) => /* @__PURE__ */ k(Q, {
					disabled: t,
					selected: a.includes(e),
					onClick: () => o(a.includes(e) ? a.filter((t) => t !== e) : a.length < 3 ? [...a, e] : a),
					children: [
						ur[e],
						" ",
						i(G[e])
					]
				}, e)),
				/* @__PURE__ */ O(Q, {
					disabled: t || a.length !== 3,
					onClick: () => r({
						type: "chooseAttributes",
						kinds: a
					}),
					children: i("games.lairs.apConfirm")
				})
			]
		})
	});
}
function _r({ pub: e, priv: t, send: n }) {
	let r = p(), i = e.adventure.pending, [a, o] = l([]), s = t.adventure.options, c = (e) => o(a.includes(e) ? a.filter((t) => t !== e) : i.max === 1 ? [e] : a.length < i.max ? [...a, e] : a);
	return /* @__PURE__ */ k("div", {
		className: "lairs-ap-dialog",
		children: [
			/* @__PURE__ */ O("strong", { children: r(fr[i.kind]) }),
			i.kind === "appraise" && /* @__PURE__ */ O("div", {
				className: "lairs-ap-cards",
				children: t.adventure.appraisal.map((e) => /* @__PURE__ */ O(cr, { id: e }, e))
			}),
			/* @__PURE__ */ O("div", {
				className: "lairs-ap-choice-grid",
				children: s.map((e, t) => e.card == null ? /* @__PURE__ */ O(Q, {
					selected: a.includes(t),
					onClick: () => c(t),
					children: e.skip ? r("games.lairs.apSkip") : i.kind === "appraise" ? r("games.lairs.apContinue") : e.junk != null && i.kind !== "adapt" ? /* @__PURE__ */ k(D, { children: [/* @__PURE__ */ O("b", { children: r(Qe.get(e.junk).name) }), /* @__PURE__ */ O("small", { children: r(Qe.get(e.junk).text) })] }) : e.cube ? /* @__PURE__ */ k(D, { children: [
						i.kind === "adapt" ? `${r(G[Ue[e.junk]])} → ` : "",
						ur[e.cube],
						" ",
						r(G[e.cube]),
						e.from && /* @__PURE__ */ O("small", { children: r(dr[e.from]) })
					] }) : e.cell == null ? e.wall == null ? r("games.lairs.apContinue") : /* @__PURE__ */ k(D, { children: [
						lr(e.wall < 30 ? Math.floor(e.wall / 5) * 6 + e.wall % 5 : e.wall - 30),
						" ",
						e.wall < 30 ? "→" : "↓"
					] }) : lr(e.cell)
				}, t) : /* @__PURE__ */ O(cr, {
					id: e.card,
					selected: a.includes(t),
					onClick: () => c(t)
				}, t))
			}),
			/* @__PURE__ */ O("span", { children: r("games.lairs.apChoiceCount", {
				n: a.length,
				max: i.max
			}) }),
			/* @__PURE__ */ O(Q, {
				disabled: a.length < i.min || a.length > i.max,
				onClick: () => n({
					type: "adventureChoice",
					indices: a
				}),
				children: r("games.lairs.apConfirm")
			})
		]
	});
}
function vr({ pub: e, priv: t, rid: n, banner: r, send: i }) {
	let a = p(), o = e.players.find((e) => e.rid === n), s = {
		monstersDefeated: o.monsters,
		chestsOpened: o.chests,
		trapsDisarmed: o.traps,
		exitedFirst: o.exitOrder === 1,
		mapFullyKnown: Object.keys(o.known).length === 36,
		forcedTucked: t?.adventure?.forcedTucked
	}, [c, u] = l(() => _e(t?.hoard ?? [], s)), d = e.scoringDone[n];
	return /* @__PURE__ */ O(_, {
		adaptive: !0,
		className: "lairs-screen lairs-screen--scoring",
		banner: r,
		actionsHeight: "h-16",
		actions: /* @__PURE__ */ k(Q, {
			disabled: d,
			onClick: () => i({
				type: "reveal",
				cards: c
			}),
			children: [
				a(d ? "games.lairs.scoringWaiting" : "games.lairs.apConfirm"),
				" · ",
				he(t?.hoard ?? [], c, s),
				" VP"
			]
		}),
		children: /* @__PURE__ */ O("div", {
			className: "lairs-ap-cards",
			children: t?.hoard.map((e) => /* @__PURE__ */ k("div", { children: [/* @__PURE__ */ O(cr, {
				id: e,
				selected: c.includes(e),
				onClick: d || s.forcedTucked?.includes(e) ? void 0 : () => u(c.includes(e) ? c.filter((t) => t !== e) : c.length < 4 ? [...c, e] : c)
			}), s.forcedTucked?.includes(e) && /* @__PURE__ */ O("span", { children: a("games.lairs.apForcedTucked") })] }, e))
		})
	});
}
//#endregion
//#region src/games/lairs/view-player.tsx
var yr = [
	...Array.from({ length: 4 }, (e, t) => ({
		id: `white-${t}`,
		kind: "white"
	})),
	{
		id: "quick-0",
		kind: "quick"
	},
	{
		id: "perc-0",
		kind: "perc"
	}
];
function br(e, t) {
	return {
		fresh: e.fresh[t],
		spent: e.spent[t],
		fatigued: e.fatigued[t],
		conserved: e.conserved.filter((e) => e === t).length
	};
}
function xr(e) {
	return yr.map((t) => {
		let n = yr.filter((e) => e.kind === t.kind).findIndex((e) => e.id === t.id), r = br(e, t.kind), i = n < r.spent ? "spent" : n < r.spent + r.fatigued ? "fatigued" : n < r.spent + r.fatigued + r.fresh ? "fresh" : "conserved";
		return {
			...t,
			state: i
		};
	});
}
function Sr(e, t, n) {
	let r = new Set(n), i = /* @__PURE__ */ new Map();
	for (let n of [
		"white",
		"quick",
		"perc"
	]) {
		let a = e.filter((e) => e.kind === n), o = br(t, n);
		for (let e of [...a].sort((e, t) => Number(r.has(e.id)) - Number(r.has(t.id)))) o[e.state] > 0 && (i.set(e.id, e.state), --o[e.state]);
		let s = {
			fresh: [
				"spent",
				"conserved",
				"fatigued",
				"fresh"
			],
			spent: [
				"fresh",
				"fatigued",
				"conserved",
				"spent"
			],
			fatigued: [
				"spent",
				"fresh",
				"conserved",
				"fatigued"
			],
			conserved: [
				"fresh",
				"spent",
				"fatigued",
				"conserved"
			]
		};
		for (let e of a) {
			if (i.has(e.id)) continue;
			let t = s[e.state].find((e) => o[e] > 0);
			t && (i.set(e.id, t), --o[t]);
		}
	}
	return yr.map((e) => ({
		...e,
		state: i.get(e.id) ?? "spent"
	}));
}
var Cr = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32, wr = (e, t) => {
	for (let n = 0; n < 4; n += 1) if (B(e, n) === t) return n;
	return 0;
}, Tr = (e) => e.fresh.white + e.fresh.quick + e.fresh.perc + 2 * e.conserved.length, Er = (e) => e.fresh.white + e.fresh.quick + e.fresh.perc, Dr = (e) => e.chests >= 3 || e.monsters >= 3 || e.chests >= 2 && e.monsters >= 2, Or = (e) => `${String.fromCharCode(65 + Math.floor(e / 6))}${e % 6 + 1}`, kr = {
	empty: "games.lairs.featEmpty",
	start: "games.lairs.featStart",
	exit: "games.lairs.featExit",
	chest: "games.lairs.featChest",
	trap: "games.lairs.featTrap",
	monster: "games.lairs.featMonster"
}, Ar = {
	start: "games.lairs.startEffect",
	exit: "games.lairs.exitEffect",
	chest: "games.lairs.chestEffect",
	trap: "games.lairs.trapEffect",
	monster: "games.lairs.monsterEffect"
}, jr = [
	"games.lairs.wallNorth",
	"games.lairs.wallEast",
	"games.lairs.wallSouth",
	"games.lairs.wallWest"
];
function Mr(e, t, n) {
	let r = e.peer, i = r?.walls.flatMap((e, n) => e ? [t(jr[n])] : []) ?? [];
	return t(e.key, {
		name: n(e.rid),
		...e.vars,
		...r ? {
			feature: t(kr[r.feature]),
			walls: i.length ? i.join("/") : t("games.lairs.wallNone")
		} : {}
	});
}
function Nr(e, t) {
	if (e.phase !== "explore" && e.phase !== "finalTurn" || !e.turn) return null;
	let n = e.turn, r = e.players.find((e) => e.rid === n), i = t.players.find((e) => e.rid === n);
	if (!r || !i) return null;
	let a = Or(i.pos);
	if (!r.escaped && i.escaped) return {
		rid: n,
		key: "games.lairs.stepExit"
	};
	if (t.lastCheck && t.lastCheck.id !== e.lastCheck?.id) {
		let { kind: e, success: r, dice: o } = t.lastCheck;
		return {
			rid: n,
			key: e === "fight" ? r ? "games.lairs.stepMonsterWin" : o === 0 ? "games.lairs.stepMonsterZero" : "games.lairs.stepMonsterFail" : r ? "games.lairs.stepTrapWin" : o === 0 ? "games.lairs.stepTrapZero" : "games.lairs.stepTrapFail",
			vars: {
				cell: a,
				dice: o,
				target: i.known[String(i.pos)]?.monsterTarget ?? 6
			}
		};
	}
	if (i.monsters > r.monsters) return {
		rid: n,
		key: "games.lairs.stepMonsterWin",
		vars: { cell: a }
	};
	if (i.traps > r.traps) return {
		rid: n,
		key: "games.lairs.stepTrapWin",
		vars: { cell: a }
	};
	if (i.chests > r.chests) return {
		rid: n,
		key: "games.lairs.stepChest",
		vars: { cell: a }
	};
	if (i.hoardCount > r.hoardCount) return {
		rid: n,
		key: "games.lairs.stepTreasure"
	};
	let o = r.known[String(r.pos)], s = i.known[String(r.pos)];
	if (o?.feature === "monster" && !o.resolved && !s?.resolved && i.pos === r.pos && s.monsterTarget !== o.monsterTarget) return {
		rid: n,
		key: "games.lairs.stepMonsterFail",
		vars: {
			cell: a,
			target: s.monsterTarget ?? 6
		}
	};
	if (o?.feature === "trap" && !o.resolved && s?.resolved) return {
		rid: n,
		key: "games.lairs.stepTrapFail",
		vars: { cell: a }
	};
	if (i.pos !== r.pos) {
		let t = i.known[String(i.pos)]?.feature;
		return t === "monster" && !i.known[String(i.pos)]?.resolved ? {
			rid: n,
			key: r.known[String(i.pos)] ? "games.lairs.stepMonsterKnown" : "games.lairs.stepMonsterFound",
			vars: { cell: a }
		} : t === "trap" && !i.known[String(i.pos)]?.resolved ? {
			rid: n,
			key: r.known[String(i.pos)] ? "games.lairs.stepTrapKnown" : "games.lairs.stepTrapFound",
			vars: { cell: a }
		} : Math.abs(Math.floor(i.pos / 6) - Math.floor(r.pos / 6)) + Math.abs(i.pos % 6 - r.pos % 6) > 1 ? {
			rid: n,
			key: "games.lairs.stepBacktrack",
			vars: { cell: a }
		} : {
			rid: n,
			key: e.hustleLeft > 0 ? "games.lairs.stepHustleMove" : "games.lairs.stepMove",
			vars: { cell: a }
		};
	}
	let c = t.peerFree, l = c == null ? null : i.known[String(c)];
	return c != null && l && !r.known[String(c)] && i.pos === r.pos ? {
		rid: n,
		key: "games.lairs.stepPeer",
		vars: { cell: Or(c) },
		peer: {
			feature: l.feature,
			walls: l.walls
		}
	} : i.conserved.length > r.conserved.length ? {
		rid: n,
		key: "games.lairs.stepConserve",
		vars: { n: i.conserved.length - r.conserved.length }
	} : e.hustleLeft === 0 && t.hustleLeft > 0 ? {
		rid: n,
		key: "games.lairs.stepHustle"
	} : e.hustleLeft > 0 && t.hustleLeft === 0 ? {
		rid: n,
		key: "games.lairs.stepStop"
	} : t.turn !== n || t.phase === "handoff" ? {
		rid: n,
		key: "games.lairs.stepEndTurn"
	} : null;
}
function Pr(e) {
	let t = e.public;
	return t.adventure ? /* @__PURE__ */ O("div", {
		className: "lairs",
		children: /* @__PURE__ */ O(hr, { ...e })
	}) : /* @__PURE__ */ O("div", {
		className: `lairs ${t.phase === "pickFirst" ? "lairs--pick-first" : ""}`,
		children: /* @__PURE__ */ O(Fr, {
			review: e.review,
			pub: t,
			priv: e.private,
			members: e.members,
			myRid: e.myRid,
			send: e.send
		})
	});
}
function Fr({ pub: e, priv: t, members: n, myRid: r, send: i, review: o }) {
	let s = p(), [c, u] = l(!1), [d, f] = l({
		turn: e.turn,
		explorer: null
	}), [v, ee] = l({
		pub: e,
		entries: []
	}), [y, b] = l(() => ({
		pub: e,
		byRid: Object.fromEntries(e.players.map((e) => [e.rid, xr(e)])),
		refresh: null,
		pending: null
	}));
	if (a(() => {
		let e = y.refresh;
		if (!e) return;
		let t = 470 + (Object.keys(e.states).length - 1) * 95 + 80, n = window.setTimeout(() => {
			b((t) => t.refresh === e ? {
				...t,
				refresh: null
			} : t);
		}, t);
		return () => window.clearTimeout(n);
	}, [y.refresh]), d.turn !== e.turn && f({
		turn: e.turn,
		explorer: null
	}), v.pub !== e) {
		let t = Nr(v.pub, e);
		ee({
			pub: e,
			entries: t ? [...v.entries, t] : v.entries
		});
	}
	if (y.pub !== e) {
		let t = {};
		for (let n of e.players) {
			let r = y.byRid[n.rid], i = y.pending, a = e.turn === n.rid && (e.phase === "explore" || e.phase === "finalTurn") && (y.pub.phase === "handoff" || y.pub.phase === "pickFirst");
			t[n.rid] = r ? a ? r.map((e) => ({
				...e,
				state: e.state === "spent" ? "fresh" : e.state === "fatigued" ? "spent" : e.state
			})) : Sr(r, n, i?.pub === y.pub && i.rid === n.rid ? i.ids : []) : xr(n);
		}
		let n = e.turn === r && (e.phase === "explore" || e.phase === "finalTurn") && (y.pub.phase === "handoff" || y.pub.phase === "pickFirst"), i = {};
		if (n) for (let e of t[r] ?? []) {
			let t = y.byRid[r]?.find((t) => t.id === e.id)?.state;
			t === "spent" && e.state === "fresh" && (i[e.id] = "fresh"), t === "fatigued" && e.state === "spent" && (i[e.id] = "spent");
		}
		b({
			pub: e,
			byRid: t,
			refresh: Object.keys(i).length ? {
				rid: r,
				states: i
			} : null,
			pending: null
		});
	}
	let x = (e) => n.find((t) => t.rid === e)?.name ?? e, te = (e) => {
		let t = n.find((t) => t.rid === e);
		return m[(t?.colorIndex ?? 0) % m.length].hex;
	}, S = e.players.find((e) => e.rid === r), C = e.players.find((e) => e.rid !== r), w = e.phase !== "done" && e.turn === r, ne = e.phase === "explore" || e.phase === "finalTurn" || e.phase === "handoff" || !!o, T = ne ? (e.phase === "handoff" ? e.turn : (d.turn === e.turn ? d.explorer : null) ?? e.turn ?? r) ?? void 0 : void 0, E = T === r ? C?.rid : T === C?.rid ? r : void 0, re = T === e.turn, ie = S?.known[String(S.pos)], A = w && re && (ie?.feature === "monster" || ie?.feature === "trap") && !ie.resolved;
	g(e.phase === "build" ? !S?.submitted : w && !e.pendingChest, h);
	let j = e.phase === "build" ? s("games.lairs.buildTitle") : e.phase === "pickFirst" ? s("games.lairs.pickFirstTitle") : e.phase === "scoring" ? s("games.lairs.scoringTitle") : e.phase === "done" ? s("games.lairs.finishedTitle") : e.phase === "handoff" ? s("games.lairs.handoffTitle") : re ? e.pendingChest && w ? s("games.lairs.chestTitle") : s(A ? "games.lairs.encounterTitle" : w ? "games.lairs.exploreTitle" : "games.lairs.watchTitle") : s(T === r ? "games.lairs.viewOwnTitle" : "games.lairs.viewRivalTitle"), M = e.phase === "build" ? S?.submitted ? s("games.lairs.buildWaiting") : s("games.lairs.buildPrompt") : e.phase === "pickFirst" ? "" : e.phase === "scoring" ? e.scoringDone[r] ? s("games.lairs.scoringWaiting") : s("games.lairs.scoringPrompt") : e.phase === "done" ? s("games.lairs.finishedTitle") : e.phase === "handoff" ? s(e.handoff?.to ? "games.lairs.handoffTo" : "games.lairs.handoffScoring", { name: x(e.handoff?.to ?? "") }) : re ? e.phase === "finalTurn" && w ? s("games.lairs.finalTurnBanner") : w ? e.pendingChest ? s("games.lairs.chooseTreasure") : s("games.lairs.turnBanner") : s("games.lairs.waitBanner", { name: x(e.turn ?? "") }) : s(T === r ? "games.lairs.viewOwnHint" : "games.lairs.viewRivalHint"), N = /* @__PURE__ */ O(Rr, {
		pub: e,
		members: n,
		myRid: r,
		brand: s("games.lairs.name"),
		title: j,
		subtitle: M,
		viewedExplorerRid: T,
		onSelectExplorer: ne && e.phase !== "handoff" ? (t) => {
			f({
				turn: e.turn,
				explorer: t
			}), u(!1);
		} : void 0,
		treasureControl: e.phase === "explore" || e.phase === "finalTurn" ? /* @__PURE__ */ O(zr, {
			t: s,
			pub: e,
			open: c && !e.pendingChest,
			onToggle: () => u((e) => !e)
		}) : void 0
	});
	if (e.phase === "build") return /* @__PURE__ */ O(Vr, {
		t: s,
		banner: N,
		me: S,
		send: i
	});
	if (e.phase === "pickFirst") {
		let t = e.buildOrder[0] === r;
		return /* @__PURE__ */ O(_, {
			adaptive: !0,
			className: "lairs-screen lairs-screen--full",
			banner: N,
			scroll: !1,
			children: /* @__PURE__ */ k("div", {
				className: "lairs-first-gate",
				children: [
					/* @__PURE__ */ k("div", {
						className: "lairs-first-gate__vault",
						"aria-hidden": "true",
						children: [
							/* @__PURE__ */ O("div", { className: "lairs-first-gate__door lairs-first-gate__door--left" }),
							/* @__PURE__ */ O("div", { className: "lairs-first-gate__door lairs-first-gate__door--right" }),
							/* @__PURE__ */ O("div", { className: "lairs-first-gate__seam" })
						]
					}),
					/* @__PURE__ */ O("div", {
						className: "lairs-first-gate__floor",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ k("div", {
						className: "lairs-first-gate__content",
						role: t ? void 0 : "status",
						"aria-live": t ? void 0 : "polite",
						children: [
							/* @__PURE__ */ O("span", {
								className: "lairs-first-gate__sigil",
								"aria-hidden": "true",
								children: "✦"
							}),
							/* @__PURE__ */ O("strong", { children: t ? s("games.lairs.pickFirstPrompt") : s("games.lairs.pickFirstWaiting", { name: x(e.buildOrder[0]) }) }),
							t && /* @__PURE__ */ k("div", {
								className: "lairs-first-gate__choices",
								children: [/* @__PURE__ */ O("button", {
									type: "button",
									className: "lairs-command is-primary",
									onClick: () => i({
										type: "pickFirst",
										rid: r
									}),
									children: s("games.lairs.firstMe")
								}), /* @__PURE__ */ O("button", {
									type: "button",
									className: "lairs-command",
									onClick: () => i({
										type: "pickFirst",
										rid: C?.rid ?? ""
									}),
									children: s("games.lairs.firstOpp")
								})]
							})
						]
					})
				]
			})
		});
	}
	return e.phase === "scoring" ? /* @__PURE__ */ O(ti, {
		t: s,
		banner: N,
		pub: e,
		priv: t,
		me: S,
		send: i
	}) : e.phase === "done" && e.final && !o ? /* @__PURE__ */ O(ni, {
		t: s,
		banner: N,
		pub: e,
		nameOf: x
	}) : /* @__PURE__ */ k(D, { children: [/* @__PURE__ */ O(qr, {
		t: s,
		banner: N,
		pub: e,
		priv: t,
		me: S,
		opp: C,
		myRid: r,
		send: (e) => {
			u(!1), i(e);
		},
		colorOf: te,
		treasureOpen: c,
		closeTreasure: () => u(!1),
		viewedOwner: E,
		stepHistory: v.entries,
		nameOf: x,
		cubeSlots: y.byRid,
		cubeRefresh: y.refresh,
		recordCubeChoice: (e) => b((t) => ({
			...t,
			pending: {
				pub: t.pub,
				rid: r,
				ids: e
			}
		}))
	}), e.phase === "handoff" && e.handoff && /* @__PURE__ */ O(Ir, {
		from: x(e.handoff.from),
		to: e.handoff.to ? x(e.handoff.to) : null,
		fxMs: e.handoff.fxMs,
		t: s
	})] });
}
function Ir({ from: e, to: t, fxMs: n, t: r }) {
	return /* @__PURE__ */ k("div", {
		className: "lairs-handoff",
		role: "status",
		"aria-live": "polite",
		style: {
			"--lairs-handoff-lead": `${n}ms`,
			"--lairs-handoff-ms": `${Vt}ms`
		},
		children: [
			/* @__PURE__ */ O("div", {
				className: "lairs-handoff__door lairs-handoff__door--left",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ O("div", {
				className: "lairs-handoff__door lairs-handoff__door--right",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ k("div", {
				className: "lairs-handoff__message",
				children: [
					/* @__PURE__ */ O("span", {
						className: "lairs-handoff__sigil",
						"aria-hidden": "true",
						children: "✦"
					}),
					/* @__PURE__ */ O("strong", { children: r("games.lairs.handoffFrom", { name: e }) }),
					/* @__PURE__ */ O("span", { children: t ? r("games.lairs.handoffTo", { name: t }) : r("games.lairs.handoffScoring") })
				]
			})
		]
	});
}
function Lr({ player: e, name: t, color: n, active: r, mine: i, build: a, viewed: o, onSelect: s, viewLabel: c }) {
	let l = p(), { ref: d } = u(`seat:${e.rid}`), f = l("games.lairs.progressChests", { n: e.chests }), m = l("games.lairs.progressMonsters", { n: e.monsters }), h = l("games.lairs.progressHoard", { n: e.hoardCount }), g = !e.escaped && Dr(e);
	return /* @__PURE__ */ k("button", {
		type: "button",
		className: `lairs-seat ${r ? "is-active" : ""} ${o ? "is-viewed" : ""}`,
		onClick: s,
		disabled: !s,
		"aria-label": s ? `${c} · ${f} · ${m} · ${h}${g ? ` · ${l("games.lairs.exitReadyShort")}` : ""}` : void 0,
		"aria-pressed": s ? o : void 0,
		children: [
			/* @__PURE__ */ O("span", {
				ref: d,
				className: "lairs-seat__seal",
				style: { "--lairs-player": n },
				children: i ? "✦" : "◇"
			}),
			/* @__PURE__ */ k("span", {
				className: "lairs-seat__copy",
				children: [/* @__PURE__ */ O("strong", { children: t }), a ? /* @__PURE__ */ O("small", { children: e.submitted ? "✓" : "···" }) : /* @__PURE__ */ k("span", {
					className: "lairs-seat__stats",
					children: [/* @__PURE__ */ k("span", { children: [/* @__PURE__ */ O("span", { children: f }), /* @__PURE__ */ O("span", { children: m })] }), /* @__PURE__ */ k("span", { children: [/* @__PURE__ */ O("span", { children: h }), g && /* @__PURE__ */ O("em", { children: l("games.lairs.exitReadyShort") })] })]
				})]
			}),
			e.escaped && /* @__PURE__ */ O("span", {
				className: "lairs-seat__exit",
				"aria-label": "escaped",
				children: "↗"
			}),
			s && /* @__PURE__ */ O("span", {
				className: "lairs-seat__map",
				"aria-hidden": "true",
				children: "↗"
			})
		]
	});
}
function Rr({ pub: e, members: t, myRid: n, brand: r, title: i, subtitle: a, treasureControl: o, viewedExplorerRid: s, onSelectExplorer: c }) {
	let l = p(), u = [e.players.find((e) => e.rid === n), ...e.players.filter((e) => e.rid !== n)].filter((e) => !!e);
	return /* @__PURE__ */ k("header", {
		className: "lairs-header",
		children: [/* @__PURE__ */ k("div", {
			className: `lairs-header__copy ${o ? "has-treasure" : ""}`,
			children: [
				/* @__PURE__ */ k("span", {
					className: "lairs-header__brand",
					children: ["✦ ", r]
				}),
				/* @__PURE__ */ O("strong", { children: i }),
				/* @__PURE__ */ O("small", { children: a }),
				o
			]
		}), /* @__PURE__ */ O("div", {
			className: "lairs-header__seats",
			children: u.map((r) => {
				let i = t.find((e) => e.rid === r.rid), a = m[(i?.colorIndex ?? 0) % m.length].hex, o = i?.name ?? r.rid;
				return /* @__PURE__ */ O(Lr, {
					player: r,
					name: o,
					color: a,
					active: e.turn === r.rid || e.phase === "build" && !r.submitted,
					mine: r.rid === n,
					build: e.phase === "build",
					viewed: s === r.rid,
					onSelect: c ? () => c(r.rid) : void 0,
					viewLabel: l("games.lairs.viewExploration", { name: o })
				}, r.rid);
			})
		})]
	});
}
function zr({ t: e, pub: t, open: n, onToggle: r }) {
	let { ref: i } = u("display"), { ref: a } = u("deck");
	return /* @__PURE__ */ k("button", {
		ref: i,
		type: "button",
		className: `lairs-header__treasure ${n ? "is-open" : ""}`,
		"aria-label": e("games.lairs.peekTreasure"),
		"aria-expanded": n,
		onClick: r,
		disabled: t.pendingChest,
		children: [/* @__PURE__ */ O("span", {
			ref: a,
			className: "lairs-header__treasure-icon",
			"aria-hidden": "true",
			children: "◆"
		}), /* @__PURE__ */ O("span", { children: e("games.lairs.treasureOfferTitle") })]
	});
}
var Br = {
	wall: "games.lairs.wallMode",
	erase: "games.lairs.eraseMode",
	start: "games.lairs.featStart",
	exit: "games.lairs.featExit",
	chest: "games.lairs.featChest",
	trap: "games.lairs.featTrap",
	monster: "games.lairs.featMonster"
};
function Vr({ t: e, banner: t, me: n, send: r, pool: i }) {
	let [a, o] = l(/* @__PURE__ */ new Set()), [c, u] = l(null), [d, f] = l(null), [p, m] = l([]), [h, g] = l([]), [v, ee] = l([]), [y, b] = l("wall"), [x, te] = l(null), [S, C] = l(null), [w, ne] = l(!1), T = n?.submitted ?? !1, E = c !== null && d !== null ? {
		walls: [...a],
		start: c,
		exit: d,
		chests: p,
		traps: h,
		monsters: v
	} : null, re = s(() => {
		let e = Array.from({ length: 36 }, () => null);
		c !== null && (e[c] = "start"), d !== null && (e[d] = "exit");
		for (let t of p) e[t] = "chest";
		for (let t of h) e[t] = "trap";
		for (let t of v) e[t] = "monster";
		return e;
	}, [
		c,
		d,
		p,
		h,
		v
	]), ie = (e) => {
		c === e && u(null), d === e && f(null), m(p.filter((t) => t !== e)), g(h.filter((t) => t !== e)), ee(v.filter((t) => t !== e));
	}, D = (e) => {
		if (C(null), te(e), y === "wall") return;
		if (y === "erase") {
			ie(e);
			return;
		}
		let t = p.filter((t) => t !== e), n = h.filter((t) => t !== e), r = v.filter((t) => t !== e);
		if (y === "chest" && t.length >= 3 || y === "trap" && n.length >= 3 || y === "monster" && r.length >= 3) {
			C("inventoryFull");
			return;
		}
		ie(e), y === "start" ? u(e) : y === "exit" ? f(e) : y === "chest" ? m([...t, e]) : y === "trap" ? g([...n, e]) : y === "monster" && ee([...r, e]);
	}, A = (e) => {
		if (x === null) return;
		let t = B(x, e);
		if (t < 0) return;
		let n = Se(x, t);
		C(null);
		let r = new Set(a);
		r.has(n) ? r.delete(n) : r.size < 20 && r.add(n), o(r);
	}, j = () => {
		let e = i ? tt(Cr, i.monsters, i.traps) : De(Cr);
		o(new Set(e.walls)), u(e.start), f(e.exit), m(e.chests), g(e.traps), ee(e.monsters), te(null), C(null);
	}, M = () => {
		if (!E) {
			C("errFeatureCell");
			return;
		}
		let e = i ? et(E, i.monsters, i.traps) : Ee(E);
		if (e) {
			C(`games.lairs.${e}`);
			return;
		}
		r({
			type: "build",
			maze: E
		});
	}, N = re.map((e) => ({
		walls: [
			!1,
			!1,
			!1,
			!1
		],
		feature: e ?? "empty",
		resolved: !1
	})), P = E ? i ? et(E, i.monsters, i.traps) : Ee(E) : "errFeatureCell", ae = [
		{
			id: "wall",
			glyph: "▤",
			count: `${a.size}/20`
		},
		{
			id: "erase",
			glyph: "×"
		},
		{
			id: "start",
			glyph: "⚑",
			count: `${c === null ? 0 : 1}/1`
		},
		{
			id: "exit",
			glyph: "",
			art: "exit.webp",
			count: `${d === null ? 0 : 1}/1`
		},
		{
			id: "chest",
			glyph: "",
			art: "chest.webp",
			count: `${p.length}/3`
		},
		{
			id: "trap",
			glyph: "",
			art: "trap.webp",
			count: `${h.length}/3`
		},
		{
			id: "monster",
			glyph: "",
			art: "monster.webp",
			count: `${v.length}/3`
		}
	], F = (t) => {
		let n = t === "monster" ? i?.monsters : t === "trap" ? i?.traps : null, r = t === "monster" ? v.length : h.length;
		return e(n && r < 3 ? K[n[r]].name : Br[t]);
	};
	return /* @__PURE__ */ k(_, {
		adaptive: !0,
		className: "lairs-screen lairs-screen--board",
		banner: t,
		scroll: !1,
		actionsHeight: "h-[304px]",
		actions: T ? /* @__PURE__ */ k("div", {
			className: "lairs-build-controls is-waiting",
			children: [/* @__PURE__ */ O("strong", { children: e("games.lairs.mazeSealed") }), /* @__PURE__ */ O("span", { children: e("games.lairs.buildWaiting") })]
		}) : /* @__PURE__ */ k("div", {
			className: "lairs-build-controls",
			children: [
				/* @__PURE__ */ k("div", {
					className: "lairs-build-controls__heading",
					children: [/* @__PURE__ */ O("strong", { children: e("games.lairs.wallsUsed", { n: a.size }) }), /* @__PURE__ */ O("span", { children: x === null ? e("games.lairs.selectCellHint") : `${e("games.lairs.selectedCell")} ${String.fromCharCode(65 + z(x)[0])}${z(x)[1] + 1}` })]
				}),
				/* @__PURE__ */ O("div", {
					className: "lairs-directions",
					children: [
						"↑",
						"→",
						"↓",
						"←"
					].map((t, n) => {
						let r = x === null ? -1 : B(x, n), i = r < 0 || x === null ? -1 : Se(x, r);
						return /* @__PURE__ */ O("button", {
							type: "button",
							className: `lairs-direction ${i >= 0 && a.has(i) ? "is-built" : ""}`,
							disabled: i < 0,
							"aria-label": `${e("games.lairs.wallMode")} ${t}`,
							onClick: () => A(n),
							children: t
						}, n);
					})
				}),
				/* @__PURE__ */ O("div", {
					className: "lairs-build-controls__label",
					children: i ? /* @__PURE__ */ k("button", {
						type: "button",
						onClick: () => ne(!0),
						children: [e("games.lairs.apPool"), " ▾"]
					}) : e("games.lairs.inventoryTitle")
				}),
				/* @__PURE__ */ O("div", {
					className: "lairs-tools",
					children: ae.map((e) => /* @__PURE__ */ k("button", {
						type: "button",
						onClick: () => b(e.id),
						"aria-pressed": y === e.id,
						"aria-label": `${F(e.id)} ${e.count ?? ""}`,
						className: `lairs-tool ${y === e.id ? "is-selected" : ""}`,
						children: [
							/* @__PURE__ */ O("span", {
								className: "lairs-tool__icon",
								"aria-hidden": !0,
								children: e.art ? /* @__PURE__ */ O("img", {
									src: `./games/lairs/${e.art}`,
									alt: ""
								}) : e.glyph
							}),
							/* @__PURE__ */ O("span", {
								className: "lairs-tool__name",
								children: F(e.id)
							}),
							/* @__PURE__ */ O("span", {
								className: "lairs-tool__count font-mono tabular-nums",
								children: e.count ?? " "
							})
						]
					}, e.id))
				}),
				/* @__PURE__ */ k("div", {
					className: "lairs-build-controls__finish",
					children: [/* @__PURE__ */ O("button", {
						type: "button",
						className: "lairs-command",
						onClick: j,
						children: e("games.lairs.randomMaze")
					}), /* @__PURE__ */ O("button", {
						type: "button",
						className: "lairs-command is-primary",
						onClick: M,
						disabled: !!P,
						children: e("games.lairs.submitMaze")
					})]
				}),
				/* @__PURE__ */ O("p", {
					className: "lairs-build-controls__rule",
					children: e(S || P ? `games.lairs.${S ?? P}` : "games.lairs.mazeReady")
				})
			]
		}),
		children: [/* @__PURE__ */ O("div", {
			className: "lairs-board-wrap",
			children: /* @__PURE__ */ O(rr, {
				cells: N,
				walls: a,
				onCell: T ? void 0 : D,
				selectedCell: x
			})
		}), i && w && /* @__PURE__ */ O("div", {
			className: "lairs-ap-modal",
			children: /* @__PURE__ */ k("div", {
				className: "lairs-ap-dialog",
				children: [/* @__PURE__ */ O("button", {
					type: "button",
					className: "lairs-command",
					onClick: () => ne(!1),
					children: e("games.lairs.apClose")
				}), [...i.monsters.map((e, t) => ({
					id: e,
					cell: v[t],
					i: t,
					kind: "games.lairs.featMonster"
				})), ...i.traps.map((e, t) => ({
					id: e,
					cell: h[t],
					i: t,
					kind: "games.lairs.featTrap"
				}))].map(({ id: t, cell: n, i: r, kind: i }, a) => /* @__PURE__ */ k("p", { children: [
					/* @__PURE__ */ k("b", { children: [
						e(i),
						" ",
						r + 1,
						" · ",
						e(K[t].name),
						" · ",
						n == null ? "—" : `${String.fromCharCode(65 + z(n)[0])}${z(n)[1] + 1}`
					] }),
					/* @__PURE__ */ O("br", {}),
					e(K[t].text)
				] }, a))]
			})
		})]
	});
}
var Hr = (e) => e.act === "creep" ? { cost: 1 } : e.act === "hustle" ? {
	cost: 2,
	special: "quick"
} : e.act === "backtrack" ? {
	cost: 1,
	kindOnly: "quick"
} : e.act === "peer" ? {
	cost: 2,
	special: "perc"
} : { cost: e.dice };
function Ur(e, t) {
	let n = [];
	for (let t of [
		"white",
		"quick",
		"perc"
	]) for (let r = 0; r < e.fresh[t]; r += 1) n.push({
		kind: t,
		from: "fresh"
	});
	for (let t of e.conserved) (t === "white" || t === "quick" || t === "perc") && n.push({
		kind: t,
		from: "conserved"
	});
	let r = /* @__PURE__ */ new Set(), i = (e, a, o) => {
		if (r.size > 1) return;
		if (e === n.length) {
			let e = a.length === 1 ? a[0].split(":")[0] : null;
			(t.kindOnly ? a.length === 1 && e === t.kindOnly && o === 1 : o === t.cost || t.special && a.length === 1 && e === t.special && o === 1) && r.add([...a].sort().join("|"));
			return;
		}
		let s = n[e];
		i(e + 1, a, o), i(e + 1, [...a, `${s.kind}:${e}:${s.from}:1`], o + 1), s.from === "conserved" && i(e + 1, [...a, `${s.kind}:${e}:${s.from}:2`], o + 2);
	};
	return i(0, [], 0), r.size;
}
function Wr(e, t) {
	let n = e.reduce((e, t) => e + (t.double ? 2 : 1), 0);
	return t.kindOnly ? e.length === 1 && e[0].kind === t.kindOnly && n === 1 : n === t.cost || !!t.special && e.length === 1 && e[0].kind === t.special && n === 1;
}
function Gr(e, t) {
	let n = [], r = e.filter((e) => e.state === "fresh"), i = e.filter((e) => e.state === "conserved"), a = (e) => {
		let t = r.findIndex((t) => t.kind === e);
		if (t < 0) return;
		let i = r.splice(t, 1)[0];
		n.push({
			slotId: i.id,
			kind: e,
			from: "fresh"
		});
	}, o = (e) => {
		let t = e;
		for (let e of [
			"white",
			"quick",
			"perc"
		]) for (; t > 0 && r.some((t) => t.kind === e);) a(e), --t;
		for (let e of [
			"white",
			"quick",
			"perc"
		]) {
			for (; t > 0;) {
				let r = i.findIndex((t) => t.kind === e);
				if (r < 0) break;
				let a = i.splice(r, 1)[0];
				n.push({
					slotId: a.id,
					kind: e,
					from: "conserved"
				}), --t, t > 0 && (n[n.length - 1].double = !0, --t);
			}
			if (t <= 0) break;
		}
	};
	if (t.kindOnly) {
		let e = t.kindOnly;
		if (r.some((t) => t.kind === e)) a(e);
		else {
			let t = i.findIndex((t) => t.kind === e);
			t >= 0 && n.push({
				slotId: i[t].id,
				kind: e,
				from: "conserved"
			});
		}
		return n;
	}
	if (t.special && r.filter((e) => e.kind === "white").length < 2) {
		let e = t.special, o = i.find((t) => t.kind === e);
		if (r.some((t) => t.kind === e)) return a(e), n;
		if (o) return [{
			slotId: o.id,
			kind: e,
			from: "conserved"
		}];
	}
	return o(t.cost), n;
}
function Kr(e, t) {
	let n = [], r = [...e], i = t.n, a = (e) => {
		for (let t of [
			"white",
			"quick",
			"perc"
		]) for (; i > 0;) {
			let a = r.findIndex((n) => n.kind === t && n.state === e);
			if (a < 0) break;
			let o = r.splice(a, 1)[0];
			n.push({
				slotId: o.id,
				kind: t,
				from: e
			}), --i;
		}
	};
	return t.freshOnly ? (a("fresh"), a("conserved"), a("spent")) : (a("spent"), a("fresh"), a("conserved")), n;
}
function qr({ t: e, banner: t, pub: n, priv: r, me: i, opp: a, myRid: o, send: c, colorOf: u, treasureOpen: d, closeTreasure: f, viewedOwner: p, stepHistory: m, nameOf: h, cubeSlots: g, cubeRefresh: v, recordCubeChoice: ee }) {
	let y = p === o ? a : i, b = g[o] ?? [], x = g[y?.rid ?? ""] ?? [], te = (n.phase === "explore" || n.phase === "finalTurn") && n.turn === o && p === a?.rid, S = te && !n.pendingChest, C = Math.min(i ? Tr(i) : 0, 3), w = n.pendingHazard && i && C > 0 && Ur(i, { cost: C }) > 1 ? {
		act: n.pendingHazard === "monster" ? "fight" : "disarm",
		dice: C
	} : null, ne = n.peerFree != null && i && (i.known[String(i.pos)]?.feature === "monster" || i.known[String(i.pos)]?.feature === "trap") && !i.known[String(i.pos)]?.resolved, [T, E] = l(null), [re, ie] = l(!1), [A, j] = l(C), [M, N] = l(!1), [P, ae] = l([]), [F, oe] = l(w), [I, se] = l(w ? Gr(b, { cost: C }) : []), [ce, le] = l(null), [ue, de] = l(!1), [fe, L] = l(null), R = `${n.phase}:${n.turn}:${n.hustleLeft}:${n.pendingChest}:${+!!n.pendingFatigue}:${n.pendingHazard ?? ""}:${n.peerFree ?? ""}:${p}`, [pe, me] = l(R);
	pe !== R && (me(R), E(null), ie(!1), j(C), N(!1), ae([]), oe(w), se(w ? Gr(b, { cost: C }) : []), le(null), de(!1), L(null));
	let he = s(() => {
		let e = [];
		if (p === a?.rid && i) for (let t = 0; t < 36; t += 1) {
			let n = i.known[String(t)];
			e.push(n ? {
				walls: n.walls,
				feature: n.feature,
				resolved: n.resolved,
				pawn: t === i.pos ? u(o) : null,
				monsterTarget: n.monsterTarget
			} : {
				walls: null,
				feature: "empty",
				resolved: !1
			});
		}
		else if (p === o && a) {
			let t = r?.maze, n = t ? Ce(t) : Array.from({ length: 36 }, () => null);
			for (let t = 0; t < 36; t += 1) {
				let r = a.known[String(t)];
				e.push({
					walls: [
						!1,
						!1,
						!1,
						!1
					],
					feature: n[t] ?? "empty",
					resolved: r ? r.resolved : !1,
					pawn: t === a.pos ? u(a.rid) : null,
					dimmed: !r,
					monsterTarget: r?.monsterTarget ?? null
				});
			}
		}
		return e;
	}, [
		p,
		o,
		i,
		a,
		r?.maze,
		u
	]), ge = /* @__PURE__ */ new Set();
	if (p === a?.rid && i) for (let [e, t] of Object.entries(i.known)) {
		let n = Number(e);
		for (let e = 0; e < 4; e += 1) {
			if (!t.walls[e]) continue;
			let r = B(n, e);
			if (r < 0) continue;
			let [i, a] = [Math.floor(n / 6), n % 6], [o, s] = [Math.floor(r / 6), r % 6];
			ge.add(i === o ? i * 5 + Math.min(a, s) : 30 + Math.min(i, o) * 6 + a);
		}
	}
	else if (r?.maze) for (let e of r.maze.walls) ge.add(e);
	let _e = s(() => {
		let e = /* @__PURE__ */ new Set();
		if (!S || !i || n.pendingHazard) return e;
		if (ne && n.peerFree != null) return e.add(n.peerFree), e;
		let t = i.known[String(i.pos)];
		if (!t) return e;
		if (n.hustleLeft > 0 || T === "creep") {
			if (Tr(i) >= 1 || n.hustleLeft > 0) for (let n = 0; n < 4; n += 1) {
				let r = B(i.pos, n);
				r >= 0 && !t.walls[n] && e.add(r);
			}
		} else if (T === "backtrack" && i.fresh.quick + +!!i.conserved.includes("quick") >= 1) {
			let t = (e) => {
				let t = i.known[String(e)];
				return !!t && (t.feature === "empty" || t.resolved);
			}, n = /* @__PURE__ */ new Set([i.pos]), r = [i.pos];
			for (; r.length;) {
				let a = r.pop();
				for (let o = 0; o < 4; o += 1) {
					let s = i.known[String(a)];
					if (!s || s.walls[o]) continue;
					let c = B(a, o);
					c < 0 || n.has(c) || (t(c) ? (n.add(c), r.push(c)) : i.known[String(c)] && e.add(c));
				}
			}
			for (let t of n) t !== i.pos && e.add(t);
		} else if (T === "peer" && (i.fresh.perc > 0 || i.conserved.includes("perc") || Tr(i) >= 2)) for (let n = 0; n < 4; n += 1) {
			let r = B(i.pos, n);
			r >= 0 && !t.walls[n] && !i.known[String(r)] && e.add(r);
		}
		return n.hustleLeft === 0 && n.peerFree != null && e.add(n.peerFree), e;
	}, [
		S,
		i,
		T,
		n.hustleLeft,
		n.peerFree,
		n.pendingHazard,
		ne
	]);
	if (!i || !a || !y) return null;
	let z = () => {
		oe(null), se([]);
	}, ve = (e) => Wr(I, Hr(e)), ye = (e, t) => {
		ee(I.map((e) => e.slotId));
		let n = I.map(({ kind: e, from: t, double: n }) => ({
			kind: e,
			from: t,
			...n ? { double: n } : {}
		}));
		e.act === "creep" ? c({
			type: "creep",
			dir: t?.dir ?? 0,
			pay: n
		}) : e.act === "hustle" ? c({
			type: "hustle",
			pay: n
		}) : e.act === "backtrack" ? c({
			type: "backtrack",
			to: t?.to ?? 0,
			pay: n
		}) : e.act === "peer" ? c({
			type: "peer",
			dir: t?.dir ?? 0,
			pay: n
		}) : c({
			type: e.act,
			dice: e.dice,
			pay: n
		}), z(), E(null);
	}, be = (e, t) => {
		let n = Hr(e);
		Ur(i, n) > 1 ? (oe(e), se(Gr(b, n))) : (z(), t?.());
	}, xe = (e) => {
		T === e ? (E(null), F?.act === e && z()) : (E(e), be({ act: e }));
	}, Se = (e) => {
		if (S && _e.has(e)) {
			if (L(null), n.hustleLeft > 0) {
				c({
					type: "move",
					dir: wr(i.pos, e)
				});
				return;
			}
			if (e === n.peerFree) {
				z(), E(null), c({
					type: "creep",
					dir: wr(i.pos, e)
				});
				return;
			}
			if (T === "peer") {
				F?.act === "peer" ? ve(F) && ye(F, { dir: wr(i.pos, e) }) : (c({
					type: "peer",
					dir: wr(i.pos, e)
				}), E(null));
				return;
			}
			T === "creep" ? F?.act === "creep" ? ve(F) && ye(F, { dir: wr(i.pos, e) }) : (c({
				type: "creep",
				dir: wr(i.pos, e)
			}), E(null)) : T === "backtrack" && (F?.act === "backtrack" ? ve(F) && ye(F, {
				dir: 0,
				to: e
			}) : (c({
				type: "backtrack",
				to: e
			}), E(null)));
		}
	}, V = i.known[String(i.pos)], we = S && n.hustleLeft === 0 && V?.feature === "monster" && !V.resolved, Te = S && n.hustleLeft === 0 && V?.feature === "trap" && !V.resolved, Ee = S && n.hustleLeft === 0 && V?.feature === "exit" && Dr(i), De = Tr(i), Oe = i.fresh.quick > 0 || i.conserved.includes("quick") || De >= 2, ke = i.fresh.perc > 0 || i.conserved.includes("perc") || De >= 2, H = n.pendingFatigue, Ae = ce ?? (H ? Kr(b, H) : []), je = Er(i) + i.conserved.length, Me = H ? H.n - (H.freshOnly ? Math.min(H.n, je) : 0) : 0, Ne = !!H && Ae.length === H.n && Ae.filter((e) => e.from === "spent").length <= Me, Pe = () => {
		H && Ne && (ee(Ae.map((e) => e.slotId)), c({
			type: "chooseFatigue",
			cubes: Ae.map(({ kind: e, from: t }) => ({
				kind: e,
				from: t
			}))
		}), le(null));
	}, Fe = we ? "fight" : "disarm", U = (e) => {
		e > 0 && Ur(i, { cost: e }) > 1 ? (oe({
			act: Fe,
			dice: e
		}), se(Gr(b, { cost: e }))) : z();
	}, Ie = () => {
		z(), E(null);
		let e = Math.min(De, 3);
		j(e), ie(!0), U(e);
	}, Le = F?.act === "hustle", Re = "lairs-command", ze = S ? /* @__PURE__ */ k("div", {
		className: "lairs-actions",
		children: [H ? /* @__PURE__ */ k("div", {
			className: "lairs-actions__primary is-hustle",
			children: [/* @__PURE__ */ O("span", { children: e("games.lairs.fatigueTitle", { n: H.n }) }), /* @__PURE__ */ k("button", {
				type: "button",
				className: `${Re} is-primary`,
				disabled: !Ne,
				onClick: Pe,
				children: [
					e("games.lairs.fatigueConfirm"),
					" · ",
					Ae.length,
					"/",
					H.n
				]
			})]
		}) : ne && n.peerFree != null ? /* @__PURE__ */ k("div", {
			className: "lairs-actions__primary is-hustle",
			children: [/* @__PURE__ */ O("span", { children: e("games.lairs.peerMustEnter") }), /* @__PURE__ */ O("button", {
				type: "button",
				className: `${Re} is-primary`,
				onClick: () => c({
					type: "creep",
					dir: wr(i.pos, n.peerFree)
				}),
				children: e("games.lairs.peerEnter")
			})]
		}) : n.hustleLeft > 0 ? /* @__PURE__ */ k("div", {
			className: "lairs-actions__primary is-hustle",
			children: [/* @__PURE__ */ O("span", { children: e("games.lairs.hustleLeft", { n: n.hustleLeft }) }), /* @__PURE__ */ O("button", {
				type: "button",
				className: Re,
				onClick: () => c({ type: "stopHustle" }),
				children: e("games.lairs.actStop")
			})]
		}) : /* @__PURE__ */ k("div", {
			className: "lairs-actions__primary",
			children: [
				/* @__PURE__ */ k("button", {
					type: "button",
					"aria-label": `${e("games.lairs.actCreep")} · ${e("games.lairs.costAnyOne")}`,
					"aria-pressed": T === "creep",
					className: `lairs-action-slab ${T === "creep" ? "is-selected" : ""}`,
					onClick: () => xe("creep"),
					disabled: De < 1,
					children: [/* @__PURE__ */ k("span", {
						className: "lairs-action-slab__heading",
						children: [/* @__PURE__ */ O("span", {
							className: "lairs-action-slab__glyph",
							"aria-hidden": "true",
							children: "✥"
						}), /* @__PURE__ */ O("strong", { children: e("games.lairs.actCreep") })]
					}), /* @__PURE__ */ O(Xr, { any: 1 })]
				}),
				/* @__PURE__ */ k("button", {
					type: "button",
					"aria-label": Le ? e("games.lairs.payConfirm") : `${e("games.lairs.actHustle")} · ${e("games.lairs.costHustle")}`,
					"aria-pressed": Le,
					className: `lairs-action-slab ${Le ? "is-selected" : ""}`,
					onClick: () => {
						if (F?.act === "hustle") {
							ve(F) && ye(F);
							return;
						}
						E(null), be({ act: "hustle" }, () => c({ type: "hustle" }));
					},
					disabled: !Oe || we || Te || Le && !ve(F),
					children: [/* @__PURE__ */ k("span", {
						className: "lairs-action-slab__heading",
						children: [/* @__PURE__ */ O("span", {
							className: "lairs-action-slab__glyph",
							"aria-hidden": "true",
							children: "↯"
						}), /* @__PURE__ */ O("strong", { children: e(Le ? "games.lairs.payConfirm" : "games.lairs.actHustle") })]
					}), /* @__PURE__ */ O(Xr, {
						any: 2,
						special: "quick"
					})]
				}),
				/* @__PURE__ */ k("button", {
					type: "button",
					"aria-label": `${e("games.lairs.actBacktrack")} · ${e("games.lairs.costQuick")}`,
					"aria-pressed": T === "backtrack",
					className: `lairs-action-slab ${T === "backtrack" ? "is-selected" : ""}`,
					onClick: () => xe("backtrack"),
					disabled: i.fresh.quick < 1 && !i.conserved.includes("quick"),
					children: [/* @__PURE__ */ k("span", {
						className: "lairs-action-slab__heading",
						children: [/* @__PURE__ */ O("span", {
							className: "lairs-action-slab__glyph",
							"aria-hidden": "true",
							children: "↶"
						}), /* @__PURE__ */ O("strong", { children: e("games.lairs.actBacktrack") })]
					}), /* @__PURE__ */ O(Xr, { special: "quick" })]
				}),
				/* @__PURE__ */ k("button", {
					type: "button",
					"aria-label": `${e("games.lairs.actPeer")} · ${e("games.lairs.costPeer")}`,
					"aria-pressed": T === "peer",
					className: `lairs-action-slab ${T === "peer" ? "is-selected" : ""}`,
					onClick: () => xe("peer"),
					disabled: !ke,
					children: [/* @__PURE__ */ k("span", {
						className: "lairs-action-slab__heading",
						children: [/* @__PURE__ */ O("span", {
							className: "lairs-action-slab__glyph",
							"aria-hidden": "true",
							children: "◉"
						}), /* @__PURE__ */ O("strong", { children: e("games.lairs.actPeer") })]
					}), /* @__PURE__ */ O(Xr, {
						any: 2,
						special: "perc"
					})]
				})
			]
		}), H || ne ? H?.freshOnly && /* @__PURE__ */ O("div", {
			className: "lairs-actions__secondary",
			children: /* @__PURE__ */ O("span", {
				className: "lairs-overlay__note",
				children: e("games.lairs.fatigueTrapNote")
			})
		}) : /* @__PURE__ */ k("div", {
			className: "lairs-actions__secondary",
			children: [
				we && /* @__PURE__ */ k("button", {
					type: "button",
					className: `${Re} is-encounter`,
					onClick: Ie,
					children: [
						e("games.lairs.actFight"),
						" · ",
						e("games.lairs.target", { n: V?.monsterTarget ?? 6 })
					]
				}),
				Te && /* @__PURE__ */ k("button", {
					type: "button",
					className: `${Re} is-encounter`,
					onClick: Ie,
					children: [
						e("games.lairs.actDisarm"),
						" · ",
						e("games.lairs.target", { n: 5 })
					]
				}),
				Ee && /* @__PURE__ */ O("button", {
					type: "button",
					className: `${Re} is-primary`,
					onClick: () => {
						z(), E(null), c({ type: "exit" });
					},
					children: e("games.lairs.actExit")
				}),
				/* @__PURE__ */ k("button", {
					type: "button",
					className: `${Re} lairs-command--conserve`,
					onClick: () => {
						z(), E(null), ae([]), N(!0);
					},
					disabled: Er(i) < 1 || i.conserved.length >= 3 || n.hustleLeft > 0 || we || Te,
					children: [/* @__PURE__ */ O("strong", { children: e("games.lairs.actConserve") }), /* @__PURE__ */ O("small", { children: e("games.lairs.conserveHint") })]
				}),
				/* @__PURE__ */ O("button", {
					type: "button",
					className: Re,
					onClick: () => {
						z(), c({ type: "endTurn" });
					},
					disabled: n.hustleLeft > 0,
					children: e("games.lairs.actEndTurn")
				})
			]
		})]
	}) : /* @__PURE__ */ O("div", {
		className: "lairs-actions is-waiting",
		children: /* @__PURE__ */ O("span", { children: n.pendingChest && n.turn === o ? e("games.lairs.chooseTreasure") : e("games.lairs.waitingActions") })
	}), Be = /* @__PURE__ */ k(D, { children: [
		n.pendingChest && n.turn === o && /* @__PURE__ */ k("div", {
			className: "lairs-overlay lairs-overlay--chest pointer-events-auto",
			children: [
				/* @__PURE__ */ O("p", {
					className: "lairs-overlay__heading",
					children: e("games.lairs.chooseTreasure")
				}),
				/* @__PURE__ */ O("div", {
					className: "lairs-overlay__cards",
					children: n.display.map((e, t) => /* @__PURE__ */ O(cr, {
						id: e,
						onClick: () => c({
							type: "chooseTreasure",
							index: t
						})
					}, e))
				}),
				/* @__PURE__ */ O("p", {
					className: "lairs-overlay__note",
					children: e("games.lairs.secretDrawn")
				}),
				/* @__PURE__ */ O($r, {
					t: e,
					hoard: r?.hoard ?? []
				})
			]
		}),
		(re || S && !!n.pendingHazard) && /* @__PURE__ */ k("div", {
			className: "lairs-overlay lairs-overlay--fight pointer-events-auto",
			children: [
				/* @__PURE__ */ O("div", {
					className: "lairs-overlay__heading",
					children: /* @__PURE__ */ k("strong", { children: [
						e(we ? "games.lairs.actFight" : "games.lairs.actDisarm"),
						" · ",
						e("games.lairs.target", { n: we ? V?.monsterTarget ?? 6 : 5 })
					] })
				}),
				n.pendingHazard && /* @__PURE__ */ O("p", {
					className: "lairs-overlay__note",
					children: e("games.lairs.forcedCheck")
				}),
				/* @__PURE__ */ k("div", {
					className: "lairs-overlay__dice",
					children: [
						/* @__PURE__ */ O("span", { children: e("games.lairs.diceBuy", { n: A }) }),
						/* @__PURE__ */ O("button", {
							type: "button",
							className: Re,
							onClick: () => {
								let e = Math.max(0, A - 1);
								j(e), U(e);
							},
							disabled: A <= 0,
							children: "−"
						}),
						/* @__PURE__ */ k("span", {
							className: "lairs-dice-count font-mono tabular-nums",
							children: ["🎲 ", A]
						}),
						/* @__PURE__ */ O("button", {
							type: "button",
							className: Re,
							onClick: () => {
								let e = Math.min(De, A + 1);
								j(e), U(e);
							},
							disabled: A >= De,
							children: "+"
						}),
						/* @__PURE__ */ O("button", {
							type: "button",
							className: `${Re} is-primary`,
							disabled: F !== null && !ve(F),
							onClick: () => {
								ie(!1), F ? ye(F) : c({
									type: Fe,
									dice: A
								});
							},
							children: e(A === 0 ? "games.lairs.zeroDiceCheck" : "games.lairs.rollDice")
						})
					]
				}),
				!n.pendingHazard && /* @__PURE__ */ O("button", {
					type: "button",
					className: "lairs-overlay__cancel",
					onClick: () => {
						ie(!1), z();
					},
					children: e("games.lairs.backToActions")
				})
			]
		}),
		M && /* @__PURE__ */ k("div", {
			className: "lairs-overlay lairs-overlay--conserve pointer-events-auto",
			children: [
				/* @__PURE__ */ k("p", {
					className: "lairs-overlay__heading",
					children: [
						e("games.lairs.actConserve"),
						"(",
						P.length,
						"/",
						Math.min(3 - i.conserved.length, Er(i)),
						")"
					]
				}),
				/* @__PURE__ */ k("div", {
					className: "lairs-overlay__dice",
					children: [/* @__PURE__ */ O("div", {
						className: "lairs-cube-picker",
						children: /* @__PURE__ */ O(Qr, {
							me: i,
							slots: b,
							pick: P,
							onChange: ae
						})
					}), /* @__PURE__ */ O("button", {
						type: "button",
						className: `${Re} is-primary`,
						disabled: P.length === 0,
						onClick: () => {
							let e = P.map((e) => b.find((t) => t.id === e)?.kind);
							e.some((e) => !e) || (ee(P), c({
								type: "conserve",
								cubes: e
							}), N(!1));
						},
						children: e("games.lairs.confirmConserve")
					})]
				}),
				/* @__PURE__ */ O("button", {
					type: "button",
					className: "lairs-overlay__cancel",
					onClick: () => N(!1),
					children: e("games.lairs.backToActions")
				})
			]
		})
	] }), Ve = n.pendingChest && te, He = re || M || !!n.pendingHazard, Ue = S && F ? {
		selectable: (e) => e.state === "fresh" || e.state === "conserved",
		isSelected: (e) => I.some((t) => t.slotId === e),
		isDouble: (e) => I.some((t) => t.slotId === e && t.double),
		onToggle: (e, t) => {
			if (e.state === "conserved") {
				let t = I.findIndex((t) => t.slotId === e.id);
				t < 0 ? se([...I, {
					slotId: e.id,
					kind: e.kind,
					from: "conserved"
				}]) : !I[t].double && !Hr(F).kindOnly ? se(I.map((e, n) => n === t ? {
					...e,
					double: !0
				} : e)) : se(I.filter((e, n) => n !== t));
			} else e.state === "fresh" && se(t ? I.filter((t) => t.slotId !== e.id) : [...I, {
				slotId: e.id,
				kind: e.kind,
				from: "fresh"
			}]);
		},
		caption: `${e("games.lairs.payPicked", {
			n: I.reduce((e, t) => e + (t.double ? 2 : 1), 0),
			m: Hr(F).cost
		})}${i.conserved.length > 0 ? ` · ${e("games.lairs.payConservedHint")}` : ""}`
	} : void 0, We = S && H ? {
		selectable: (e) => e.state === "fresh" || e.state === "conserved" || e.state === "spent" && Me > 0,
		locked: (e) => H.freshOnly && je < H.n && e.state !== "spent",
		isSelected: (e) => Ae.some((t) => t.slotId === e),
		onToggle: (e, t) => {
			if (t) {
				le(Ae.filter((t) => t.slotId !== e.id));
				return;
			}
			Ae.length >= H.n || e.state === "spent" && Ae.filter((e) => e.from === "spent").length >= Me || e.state !== "fatigued" && le([...Ae, {
				slotId: e.id,
				kind: e.kind,
				from: e.state
			}]);
		},
		caption: `${Ae.length}/${H.n}`
	} : void 0, W = y.known[String(y.pos)], Ge = n.phase === "handoff" ? e("games.lairs.handoffHolding") : y.escaped ? e("games.lairs.observeEscaped") : n.pendingFatigue && n.turn === y.rid ? e("games.lairs.observeFatigue") : n.pendingHazard && n.turn === y.rid ? e("games.lairs.forcedCheck") : W?.feature === "monster" && !W.resolved ? e("games.lairs.observeMonster", { n: W.monsterTarget ?? 6 }) : W?.feature === "trap" && !W.resolved ? e("games.lairs.observeTrap", { n: 5 }) : W?.feature === "exit" ? e("games.lairs.observeExit") : n.pendingChest && n.turn === y.rid ? e("games.lairs.observeChest") : n.turn === y.rid ? e("games.lairs.observeMoving") : e("games.lairs.observeWaiting"), Ke = m.map((e, t) => ({
		step: e,
		index: t
	})).filter(({ step: e }) => e.rid === y.rid).reverse(), qe = Ke.length ? Mr(Ke[0].step, e, h) : "", G = W && !W.resolved && (W.feature === "monster" || W.feature === "trap") ? W : null, Je = fe === null ? null : he[fe], K = Je && Je.walls !== null && Je.feature !== "empty" && !Je.resolved ? Je.feature : null, Ye = K && fe !== null ? /* @__PURE__ */ k("section", {
		className: "lairs-feature-detail",
		"aria-label": e("games.lairs.featureDetail"),
		children: [
			/* @__PURE__ */ k("div", {
				className: "lairs-feature-detail__heading",
				children: [/* @__PURE__ */ k("strong", { children: [
					e(kr[K]),
					" · ",
					Or(fe)
				] }), /* @__PURE__ */ O("button", {
					type: "button",
					onClick: () => L(null),
					"aria-label": e("games.lairs.closeFeatureDetail"),
					children: "×"
				})]
			}),
			(K === "monster" || K === "trap") && /* @__PURE__ */ O("span", {
				className: "lairs-feature-detail__target",
				children: e("games.lairs.target", { n: K === "monster" ? Je?.monsterTarget ?? 6 : 5 })
			}),
			/* @__PURE__ */ O("p", { children: e(Ar[K]) }),
			(K === "monster" || K === "trap") && /* @__PURE__ */ O("small", { children: e("games.lairs.hazardLeave") })
		]
	}) : null, Xe = /* @__PURE__ */ k("div", {
		className: "lairs-observe",
		children: [/* @__PURE__ */ k("div", {
			className: "lairs-observe__current",
			children: [/* @__PURE__ */ O("strong", { children: e("games.lairs.observePosition", {
				name: h(y.rid),
				cell: Or(y.pos),
				n: Object.keys(y.known).length
			}) }), /* @__PURE__ */ O("span", { children: Ge })]
		}), Ke.length > 0 && /* @__PURE__ */ k("div", {
			className: "lairs-observe__history",
			role: "log",
			"aria-live": "off",
			"aria-label": e("games.lairs.actionHistory"),
			children: [/* @__PURE__ */ O("strong", { children: e("games.lairs.actionHistory") }), Ke.map(({ step: t, index: n }) => /* @__PURE__ */ O("span", { children: Mr(t, e, h) }, n))]
		})]
	}), Ze = /* @__PURE__ */ k("div", {
		className: "lairs-history-panel pointer-events-auto",
		role: "dialog",
		"aria-label": e("games.lairs.actionHistory"),
		children: [/* @__PURE__ */ k("div", {
			className: "lairs-history-panel__heading",
			children: [/* @__PURE__ */ k("strong", { children: [
				e("games.lairs.actionHistory"),
				" · ",
				h(y.rid)
			] }), /* @__PURE__ */ O("button", {
				type: "button",
				onClick: () => de(!1),
				"aria-label": e("games.lairs.closeHistory"),
				children: "×"
			})]
		}), /* @__PURE__ */ O("div", {
			className: "lairs-history-panel__entries",
			role: "log",
			"aria-live": "off",
			children: Ke.map(({ step: t, index: n }) => /* @__PURE__ */ O("span", { children: Mr(t, e, h) }, n))
		})]
	}), Qe = () => {
		f(), L(null), de((e) => !e);
	}, $e = Ve ? /* @__PURE__ */ O("div", {
		className: "lairs-chest-panel",
		children: Be
	}) : /* @__PURE__ */ k("div", {
		className: "lairs-control-stack",
		children: [
			/* @__PURE__ */ k("div", {
				className: `lairs-step-ticker ${G ? "is-encounter" : ""}`,
				children: [/* @__PURE__ */ k("button", {
					type: "button",
					className: "lairs-step-ticker__main",
					"aria-label": G ? fe === y.pos ? e("games.lairs.closeFeatureDetail") : e("games.lairs.inspectFeatureAt", {
						cell: Or(y.pos),
						feature: e(kr[G.feature])
					}) : e("games.lairs.openHistory"),
					"aria-expanded": G ? fe === y.pos : ue,
					onClick: G ? () => {
						f(), de(!1), L((e) => e === y.pos ? null : y.pos);
					} : Qe,
					children: [!G && /* @__PURE__ */ O("span", {
						"aria-hidden": "true",
						children: "✦"
					}), /* @__PURE__ */ O("span", {
						className: "lairs-step-ticker__content",
						"aria-live": "polite",
						children: G ? /* @__PURE__ */ k(D, { children: [/* @__PURE__ */ k("strong", { children: [
							e(kr[G.feature]),
							" · ",
							e("games.lairs.target", { n: G.feature === "monster" ? G.monsterTarget ?? 6 : 5 })
						] }), /* @__PURE__ */ O("small", { children: e(G.feature === "monster" ? "games.lairs.monsterBrief" : "games.lairs.trapBrief") })] }) : qe || e("games.lairs.actionHistory")
					})]
				}), /* @__PURE__ */ k("button", {
					type: "button",
					className: "lairs-step-ticker__history",
					"aria-label": e("games.lairs.openHistory"),
					"aria-expanded": ue,
					onClick: Qe,
					children: [
						e("games.lairs.actionHistory"),
						" ",
						/* @__PURE__ */ O("span", {
							"aria-hidden": "true",
							children: "▴"
						})
					]
				})]
			}),
			/* @__PURE__ */ O(Zr, {
				t: e,
				me: y,
				slots: x,
				select: S ? Ue ?? We : void 0,
				refresh: v
			}),
			Ye ?? (S && He ? /* @__PURE__ */ O("div", {
				className: "lairs-resolution",
				children: Be
			}) : S ? ze : Xe)
		]
	});
	return /* @__PURE__ */ O(_, {
		adaptive: !0,
		className: "lairs-screen lairs-screen--board",
		banner: t,
		actions: $e,
		actionsHeight: "h-[304px]",
		scroll: !1,
		overlay: ue && !Ve ? Ze : d && !Ve ? /* @__PURE__ */ O(ei, {
			t: e,
			pub: n,
			hoard: r?.hoard ?? [],
			onClose: f
		}) : S && n.peerFree != null ? /* @__PURE__ */ O("div", {
			className: "lairs-peer-hint",
			role: "status",
			children: e(ne ? "games.lairs.peerMustEnter" : "games.lairs.peerFreeHint")
		}) : void 0,
		children: /* @__PURE__ */ O("div", {
			className: "lairs-board-wrap",
			children: /* @__PURE__ */ O(rr, {
				cells: he,
				walls: ge,
				onCell: S ? Se : void 0,
				onInspectCell: (e) => {
					L((t) => t === e ? null : e), de(!1), f();
				},
				inspectLabel: (t) => e("games.lairs.inspectFeatureAt", {
					cell: Or(t),
					feature: e(kr[he[t].feature])
				}),
				highlights: S ? _e : void 0,
				anchorRid: y.rid
			})
		})
	});
}
function Jr({ kind: e }) {
	return e === "quick" ? /* @__PURE__ */ O("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		"aria-hidden": "true",
		children: /* @__PURE__ */ O("path", {
			d: "M13.8 2 5.7 13h5.5L9.8 22l8.5-12h-5.4L13.8 2Z",
			fill: "currentColor",
			stroke: "currentColor",
			strokeLinejoin: "round"
		})
	}) : e === "perc" ? /* @__PURE__ */ k("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ O("path", {
			d: "M2 12c2.7-3.7 6-5.5 10-5.5S19.3 8.3 22 12c-2.7 3.7-6 5.5-10 5.5S4.7 15.7 2 12Z",
			stroke: "currentColor",
			strokeWidth: "2"
		}), /* @__PURE__ */ O("circle", {
			cx: "12",
			cy: "12",
			r: "3.2",
			fill: "currentColor"
		})]
	}) : /* @__PURE__ */ O("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		"aria-hidden": "true",
		children: /* @__PURE__ */ O("path", {
			d: "m12 2 2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5L12 2Z",
			fill: "currentColor"
		})
	});
}
function Yr({ kind: e, amount: t }) {
	let n = p();
	return /* @__PURE__ */ k("span", {
		className: "lairs-action-cost__mark",
		children: [e === "any" ? /* @__PURE__ */ O("span", {
			className: "lairs-action-cost__any",
			children: n("games.lairs.costAny")
		}) : /* @__PURE__ */ O("span", {
			className: `lairs-action-cost__icon is-${e}`,
			children: /* @__PURE__ */ O(Jr, { kind: e })
		}), /* @__PURE__ */ k("b", {
			className: "font-mono tabular-nums",
			children: ["×", t]
		})]
	});
}
function Xr({ any: e, special: t }) {
	return /* @__PURE__ */ k("span", {
		className: "lairs-action-slab__cost",
		"aria-hidden": "true",
		children: [
			e && /* @__PURE__ */ O(Yr, {
				kind: "any",
				amount: e
			}),
			e && t && /* @__PURE__ */ O("span", {
				className: "lairs-action-cost__or",
				children: "/"
			}),
			t && /* @__PURE__ */ O(Yr, {
				kind: t,
				amount: 1
			})
		]
	});
}
function Zr({ t: e, me: t, slots: n, select: r, refresh: i }) {
	let a = i?.rid === t.rid ? Object.keys(i.states) : [];
	return /* @__PURE__ */ k("div", {
		className: "lairs-energy",
		children: [/* @__PURE__ */ k("div", {
			className: "lairs-energy__caption",
			children: [/* @__PURE__ */ O("strong", { children: e("games.lairs.energyTitle") }), r?.caption && /* @__PURE__ */ O("small", {
				className: "font-mono tabular-nums",
				children: r.caption
			})]
		}), /* @__PURE__ */ O("div", {
			className: "lairs-energy__row",
			children: n.map((n) => {
				let o = n.kind === "white" ? e("games.lairs.cubeWhite") : n.kind === "quick" ? e("games.lairs.cubeQuick") : e("games.lairs.cubePerc"), s = n.state === "fresh" ? e("games.lairs.fresh") : n.state === "spent" ? e("games.lairs.spent") : n.state === "fatigued" ? e("games.lairs.fatigued") : e("games.lairs.conserved"), c = !!r?.selectable(n) && !r.locked?.(n), l = r?.isSelected(n.id) ?? !1, u = n.state === "conserved" && (r?.isDouble?.(n.id) ?? !1), d = n.state === "conserved" && l ? u ? "Ⅱ" : "✓" : n.state === "fresh" ? "✓" : n.state === "spent" ? "×" : n.state === "fatigued" ? "−" : "Ⅱ", f = i?.rid === t.rid ? i.states[n.id] : void 0, p = `lairs-cube is-${n.kind} is-${n.state}${c ? " is-selectable" : ""}${l ? " is-selected" : ""}${u ? " is-double" : ""}${f ? ` is-recharging-${f}` : ""}`, m = f ? { "--lairs-charge-delay": `${a.indexOf(n.id) * 95}ms` } : void 0;
				return /* @__PURE__ */ k("button", {
					type: "button",
					disabled: !c,
					"aria-label": `${o} ${s}`,
					"aria-pressed": c ? l : void 0,
					className: p,
					style: m,
					onClick: c && r ? () => r.onToggle(n, l) : void 0,
					children: [/* @__PURE__ */ O(Jr, { kind: n.kind }), /* @__PURE__ */ O("b", {
						className: "lairs-cube__mark",
						"aria-hidden": "true",
						children: d
					})]
				}, n.id);
			})
		})]
	});
}
function Qr({ me: e, slots: t, pick: n, onChange: r }) {
	let i = p(), a = t.filter((e) => e.state === "fresh");
	return /* @__PURE__ */ O(D, { children: a.map((t) => {
		let a = n.includes(t.id);
		return /* @__PURE__ */ k("button", {
			type: "button",
			"aria-label": t.kind === "quick" ? i("games.lairs.cubeQuick") : t.kind === "perc" ? i("games.lairs.cubePerc") : i("games.lairs.cubeWhite"),
			"aria-pressed": a,
			className: `lairs-cube-pick is-${t.kind} is-fresh ${a ? "is-selected" : ""}`,
			onClick: () => {
				a ? r(n.filter((e) => e !== t.id)) : n.length < Math.min(3 - e.conserved.length, e.fresh.white + e.fresh.quick + e.fresh.perc) && r([...n, t.id]);
			},
			children: [/* @__PURE__ */ O(Jr, { kind: t.kind }), a && /* @__PURE__ */ O("b", {
				className: "lairs-cube__mark",
				"aria-hidden": "true",
				children: "✓"
			})]
		}, t.id);
	}) });
}
function $r({ t: e, hoard: t }) {
	return /* @__PURE__ */ k("section", {
		className: "lairs-overlay__hoard",
		"aria-label": e("games.lairs.hoardTitle", { n: t.length }),
		children: [/* @__PURE__ */ O("h3", {
			className: "lairs-overlay__subheading",
			children: e("games.lairs.hoardTitle", { n: t.length })
		}), t.length > 0 && /* @__PURE__ */ O("div", {
			className: "lairs-overlay__cards lairs-overlay__cards--hoard",
			children: t.map((e, t) => /* @__PURE__ */ O(cr, { id: e }, `${e}-${t}`))
		})]
	});
}
function ei({ t: e, pub: t, hoard: n, onClose: r }) {
	return /* @__PURE__ */ k("div", {
		className: "lairs-overlay lairs-overlay--treasures pointer-events-auto",
		role: "dialog",
		"aria-label": e("games.lairs.treasureOfferTitle"),
		children: [
			/* @__PURE__ */ k("div", {
				className: "lairs-overlay__heading",
				children: [/* @__PURE__ */ O("strong", { children: e("games.lairs.treasureOfferTitle") }), /* @__PURE__ */ k("span", {
					className: "lairs-overlay__treasure-tools",
					children: [/* @__PURE__ */ O("small", {
						className: "font-mono tabular-nums",
						children: e("games.lairs.deckLabel", { n: t.deckCount })
					}), /* @__PURE__ */ O("button", {
						type: "button",
						className: "lairs-overlay__close",
						onClick: r,
						"aria-label": e("games.lairs.closeTreasure"),
						children: "×"
					})]
				})]
			}),
			/* @__PURE__ */ O("div", {
				className: "lairs-overlay__cards",
				children: t.display.map((e) => /* @__PURE__ */ O(cr, { id: e }, e))
			}),
			/* @__PURE__ */ O($r, {
				t: e,
				hoard: n
			})
		]
	});
}
function ti({ t: e, banner: t, pub: n, priv: r, me: i, send: a }) {
	let [o, s] = l([]), c = n.scoringDone[i?.rid ?? ""], u = r?.hoard ?? [], d = {
		monstersDefeated: i?.monsters ?? 0,
		chestsOpened: i?.chests ?? 0,
		trapsDisarmed: i?.traps ?? 0,
		exitedFirst: i?.exitOrder === 1,
		mapFullyKnown: Object.keys(i?.known ?? {}).length >= 36
	}, f = i ? he(u, o, d) + ge[Math.min(3, i.monsters)] + (i.exitOrder === 1 ? 4 : i.exitOrder === 2 ? 2 : 0) : 0;
	return /* @__PURE__ */ k(_, {
		adaptive: !0,
		className: "lairs-screen lairs-screen--scoring",
		banner: t,
		actionsHeight: "h-[304px]",
		actions: c ? /* @__PURE__ */ O("div", {
			className: "lairs-interlude-actions",
			children: /* @__PURE__ */ O("strong", { children: e("games.lairs.scoringWaiting") })
		}) : /* @__PURE__ */ k("div", {
			className: "lairs-interlude-actions",
			children: [/* @__PURE__ */ O("strong", { children: e("games.lairs.scoringPrompt") }), /* @__PURE__ */ k("div", {
				className: "lairs-choice-actions",
				children: [
					/* @__PURE__ */ k("span", {
						className: "lairs-scoring__estimate",
						children: [
							e("games.lairs.revealHint", { n: o.length }),
							" · ★",
							f
						]
					}),
					/* @__PURE__ */ O("button", {
						type: "button",
						className: "lairs-command",
						onClick: () => s(_e(u, d)),
						children: "★?"
					}),
					/* @__PURE__ */ O("button", {
						type: "button",
						className: "lairs-command is-primary",
						onClick: () => a({
							type: "reveal",
							cards: o
						}),
						children: e("games.lairs.revealSubmit")
					})
				]
			})]
		}),
		children: [/* @__PURE__ */ O("div", {
			className: "lairs-scoring__cards",
			children: u.map((e) => /* @__PURE__ */ O(cr, {
				id: e,
				selected: o.includes(e),
				onClick: c ? void 0 : () => s(o.includes(e) ? o.filter((t) => t !== e) : o.length < 4 ? [...o, e] : o)
			}, e))
		}), /* @__PURE__ */ O("p", {
			className: "lairs-scoring__note",
			children: e("games.lairs.tuckedNote")
		})]
	});
}
function ni({ t: e, banner: t, pub: n, nameOf: r }) {
	let i = n.final;
	return /* @__PURE__ */ O(_, {
		adaptive: !0,
		className: "lairs-screen lairs-screen--full",
		banner: t,
		children: i && /* @__PURE__ */ O("div", {
			className: "lairs-results",
			children: n.players.map((t) => {
				let n = i.breakdown[t.rid];
				return n ? /* @__PURE__ */ k("div", {
					className: "lairs-results__player",
					children: [
						/* @__PURE__ */ O("p", {
							className: "text-sm font-extrabold",
							children: r(t.rid)
						}),
						/* @__PURE__ */ k("p", {
							className: "font-mono text-xs tabular-nums",
							children: [
								e("games.lairs.breakTreasures"),
								" ",
								n.treasures,
								" · ",
								e("games.lairs.breakMonsters"),
								" ",
								n.monsters,
								" · ",
								e("games.lairs.breakExit"),
								" ",
								n.exit,
								" · ",
								e("games.lairs.breakTotal"),
								" ",
								n.total
							]
						}),
						/* @__PURE__ */ O("div", {
							className: "mt-1 grid grid-cols-4 gap-1",
							children: (i.revealed[t.rid] ?? []).map((e) => /* @__PURE__ */ O(cr, { id: e }, e))
						})
					]
				}, t.rid) : null;
			})
		})
	});
}
//#endregion
//#region src/games/lairs/adventure-bot.ts
var ri = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32, ii = (e) => W(e.fresh) + e.conserved.length * 2, ai = (e) => e.chests >= 3 || e.monsters >= 3 || e.chests >= 2 && e.monsters >= 2, oi = (e, t) => ({
	monstersDefeated: e.monsters,
	chestsOpened: e.chests,
	trapsDisarmed: e.traps,
	exitedFirst: e.exitOrder === 1,
	mapFullyKnown: Object.keys(e.known).length === 36,
	forcedTucked: t.adventure?.forcedTucked
}), si = (e, t) => {
	let n = e.public, r = e.private, i = n.adventure, a = n.players.find((e) => e.rid === t.rid);
	if (!i || !a || !r?.adventure) return null;
	let o = t.memory ?? {
		visits: {},
		turns: 0
	}, s = (e) => ({
		action: e,
		memory: o
	});
	if (n.phase === "draft") {
		if (i.draftActor !== t.rid) return null;
		let e = i.draftKind === "monster" ? i.monsters : i.traps;
		return s({
			type: "draftHazard",
			id: Ye(i.config.stage, i.config.boxZero, i.draftKind).filter((t) => !e.includes(t.id)).sort((e, t) => t.targets[i.config.stage - 1] - e.targets[i.config.stage - 1])[0].id
		});
	}
	if (n.phase === "build") return a.submitted ? null : s({
		type: "build",
		maze: tt(ri, i.monsters, i.traps)
	});
	if (n.phase === "attributes") return i.players[t.rid].attributesChosen ? null : s({
		type: "chooseAttributes",
		kinds: i.config.stage >= 3 ? [
			"know",
			"brawn",
			"guile"
		] : [
			"quick",
			"perc",
			"brawn"
		]
	});
	if (n.phase === "pickFirst") return n.buildOrder[0] === t.rid ? s({
		type: "pickFirst",
		rid: t.rid
	}) : null;
	if (n.phase === "scoring") return n.scoringDone[t.rid] ? null : s({
		type: "reveal",
		cards: _e(r.hoard, oi(a, r))
	});
	let c = i.pending;
	if (c) return c.actor === t.rid ? s({
		type: "adventureChoice",
		indices: r.adventure.options.map((e, t) => ({
			o: e,
			i: t
		})).sort((e, t) => {
			if (["appraise", "ignore"].includes(c.kind)) return Number(t.o.skip) - Number(e.o.skip);
			if (c.kind === "shield" || c.kind === "shovel") return Number(e.o.skip) - Number(t.o.skip);
			if (c.kind === "adapt") {
				let n = (e) => e.skip ? 0 : e.cube === "know" ? 4 : e.cube === "brawn" ? 3 : e.cube === "perc" ? 2 : 1;
				return n(t.o) - n(e.o);
			}
			if (c.kind === "appraiseKeep") {
				let n = (e) => e == null ? 0 : he([...r.hoard, e], _e([...r.hoard, e], oi(a, r)), oi(a, r));
				return n(t.o.card) - n(e.o.card);
			}
			return c.kind === "fatigue" || c.kind === "blanket" ? Number(e.o.from !== "spent") - Number(t.o.from !== "spent") || Ue.indexOf(e.o.cube) - Ue.indexOf(t.o.cube) : 0;
		}).slice(0, c.min).map((e) => e.i)
	}) : null;
	if (n.phase !== "explore" && n.phase !== "finalTurn" || n.turn !== t.rid) return null;
	if (i.check) {
		if (i.check.stage !== "rolled") return null;
		if (i.config.stage >= 3 && i.check.total < i.check.target + (i.check.kind === "fight" && i.config.stage === 4 ? 2 : 0) && (a.fresh.guile || a.conserved.includes("guile"))) return s({ type: "improvise" });
		let e = r.adventure.junk.indexOf(6), t = r.adventure.junk.indexOf(13);
		if (i.check.total < i.check.target && t >= 0) return s({
			type: "useJunk",
			index: t,
			delta: 2
		});
		if (i.check.total < i.check.target && e >= 0 && i.check.dice.length) {
			let t = i.check.dice.map((e, t) => ({
				...e,
				i: t
			})).sort((e, t) => e.value - t.value)[0];
			if (t.value < (t.power ? 5 : 3)) return s({
				type: "useJunk",
				index: e,
				die: t.i
			});
		}
		return s({ type: "finishCheck" });
	}
	if (n.pendingChest) return s({
		type: "chooseTreasure",
		index: n.display.map((e, t) => ({
			i: t,
			score: he([...r.hoard, e], _e([...r.hoard, e], oi(a, r)), oi(a, r))
		})).sort((e, t) => t.score - e.score)[0].i
	});
	let l = a.known[String(a.pos)];
	if (n.peerFree != null && (l?.feature === "monster" || l?.feature === "trap") && !l.resolved) return s({
		type: "creep",
		dir: [
			0,
			1,
			2,
			3
		].find((e) => B(a.pos, e) === n.peerFree)
	});
	if (n.pendingHazard) return li(e, a, o, t.difficulty === "weak");
	if (n.hustleLeft > 0) return s({ type: "stopHustle" });
	if (l?.hazardId && !l.resolved && ii(a) >= 2 && (l.feature === "trap" || l.feature === "monster")) return li(e, a, o, t.difficulty === "weak");
	if (l?.feature === "exit" && ai(a)) return s({ type: "exit" });
	let u = r.adventure.junk.findIndex((e) => e === 1 || e === 9);
	if (u >= 0 && (W(a.spent) || r.adventure.junk[u] === 9 && W(a.fatigued))) return s({
		type: "useJunk",
		index: u
	});
	if (i.scavengeCell != null && i.players[t.rid].junkCount <= 1 && (a.fresh.know || a.conserved.includes("know"))) return s({ type: "scavenge" });
	if ((l?.feature === "empty" || l?.resolved) && i.players[t.rid].junkCount < 2 && !i.players[t.rid].searched.includes(a.pos) && a.fresh.know && l.walls.some((e, t) => e && B(a.pos, t) >= 0)) return s({ type: "scrounge" });
	if (!ii(a) && !i.scroungeFree && n.peerFree == null) return s({ type: "endTurn" });
	let d = [...ci(a).entries()].filter(([e]) => e !== a.pos).map(([e, t]) => {
		let n = a.known[String(e)], r = o.visits[e] ?? 0;
		return {
			cell: e,
			path: t,
			score: (n ? n.feature === "exit" && ai(a) ? 100 : n.feature === "chest" && !n.resolved ? 40 : n.feature === "monster" && !n.resolved && a.monsters < 3 ? 17 : -10 : 14) - t.length * 2 - r * 3
		};
	}).sort((e, t) => t.score - e.score || e.cell - t.cell)[0];
	if (!d) return s({ type: "endTurn" });
	let f = d.path[0], p = B(a.pos, f), m = a.known[String(p)];
	return n.peerFree === p || i.scroungeFree ? (o.visits[p] = (o.visits[p] ?? 0) + 1, s({
		type: "creep",
		dir: f
	})) : !m && (a.fresh.perc || a.conserved.includes("perc")) && ii(a) >= 1 ? s({
		type: "peer",
		dir: f
	}) : (o.visits[p] = (o.visits[p] ?? 0) + 1, m?.feature === "monster" && !m.resolved && i.config.stage >= 2 && (a.fresh.brawn || a.conserved.includes("brawn")) ? s({
		type: "charge",
		dir: f
	}) : m?.feature === "trap" && !m.resolved && i.config.stage >= 3 && (a.fresh.guile || a.conserved.includes("guile")) ? s({
		type: "sneak",
		dir: f
	}) : s({
		type: "creep",
		dir: f
	}));
};
function ci(e) {
	let t = /* @__PURE__ */ new Map([[e.pos, []]]), n = [e.pos];
	for (; n.length;) {
		let r = n.shift(), i = e.known[String(r)];
		if (i) for (let e = 0; e < 4; e++) {
			let a = B(r, e);
			a < 0 || i.walls[e] || t.has(a) || (t.set(a, [...t.get(r), e]), n.push(a));
		}
	}
	return t;
}
function li(e, t, n, r) {
	let i = e.public.adventure, a = t.known[String(t.pos)], o = K[a.hazardId], s = o.kind === "monster" ? "fight" : "disarm", c = e.private.adventure.junk.findIndex((e) => e === (s === "fight" ? 4 : 5) || e === (o.category === "nature" ? 21 : o.category === "machine" ? 22 : 23));
	if (c >= 0) return {
		action: {
			type: "useJunk",
			index: c
		},
		memory: n
	};
	let l = i.config.stage >= (s === "fight" ? 2 : 3) ? o.weak : [], u = Ue.flatMap((e) => [...Array(t.fresh[e]).fill(1), ...Array(t.conserved.filter((t) => t === e).length * 2).fill(1)].map(() => e)).sort((e, t) => Number(l.includes(t)) - Number(l.includes(e))), d = a.monsterTarget ?? o.targets[i.config.stage - 1], f = 0;
	for (; f < u.length && f < 12;) {
		let e = u.slice(0, f), t = [...i.freeDice, ...e.map((e) => l.includes(e))], n = e.filter((e) => e === "brawn" && l.includes(e)).length;
		if (ui(t, d, i.config.stage === 4 && s === "fight" ? o.id : null, n) >= (r ? .5 : .8)) break;
		f++;
	}
	return {
		action: {
			type: s,
			dice: f
		},
		memory: n
	};
}
function ui(e, t, n, r) {
	if (!e.length) return 0;
	let i = (t) => {
		let r = /* @__PURE__ */ new Map([[0, 1]]);
		for (let i of e) {
			let e = t && n === "sentry" && i ? [2] : i ? Ke : Ge, a = /* @__PURE__ */ new Map();
			for (let [t, n] of r) for (let r of e) a.set(t + r, (a.get(t + r) ?? 0) + n / e.length);
			r = a;
		}
		return r;
	}, a = i(!1), o = i(!0), s = n ? qe.flatMap((e) => qe.map((t) => ({
		skull: e === "skull" || t === "skull",
		penalty: (typeof e == "number" ? e : 0) + (typeof t == "number" ? t : 0),
		chance: 1 / 36
	}))) : [{
		skull: !1,
		penalty: 0,
		chance: 1
	}], c = 0;
	for (let e of s) for (let [i, s] of e.skull ? o : a) {
		let a = i + (e.penalty + (e.skull && (n === "tangle" || n === "golem") ? -2 : 0) + (e.skull && n === "whisper" ? -4 * r : 0));
		a >= t && !(e.skull && n === "blob" && a >= t + 2) && (c += s * e.chance);
	}
	return c;
}
//#endregion
//#region src/games/lairs/bot.ts
var di = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32, fi = (e) => e.fresh.white + e.fresh.quick + e.fresh.perc, pi = (e) => fi(e) + 2 * e.conserved.length, mi = (e) => e.chests >= 3 || e.monsters >= 3 || e.chests >= 2 && e.monsters >= 2;
function hi(e, t) {
	let n = [], r = [
		"white",
		"quick",
		"perc"
	], i = {
		spent: { ...e.spent },
		fresh: { ...e.fresh },
		conserved: [...e.conserved]
	}, a = t.n, o = (e) => {
		for (let t of r) for (; a > 0 && i[e][t] > 0;) --i[e][t], n.push({
			kind: t,
			from: e
		}), --a;
	}, s = () => {
		for (let e of r) for (; a > 0;) {
			let t = i.conserved.indexOf(e);
			if (t < 0) break;
			i.conserved.splice(t, 1), n.push({
				kind: e,
				from: "conserved"
			}), --a;
		}
	};
	return t.freshOnly ? (o("fresh"), s(), o("spent")) : (o("spent"), o("fresh"), s()), {
		type: "chooseFatigue",
		cubes: n
	};
}
var $ = {
	buildCandidates: 16,
	hazardPathBonus: 2,
	exitValue: 60,
	chestValue: 8,
	fightCost: 2.5,
	qualNeedValue: 3.5,
	frontierValue: 2.5,
	raceFrontierBonus: 2,
	stepCost: 1,
	fightP: .6,
	fightPMin: .3,
	fightDiceCap: 5,
	hustleMin: 3,
	backtrackSave: 2,
	whitePeerDensity: .3
}, gi = 6, _i = (() => {
	let e = [
		0,
		1,
		2,
		2,
		1
	], t = [[1]];
	for (let n = 1; n <= gi; n += 1) {
		let r = t[n - 1], i = Array(r.length + 4).fill(0);
		for (let t = 0; t < r.length; t += 1) if (r[t] !== 0) for (let n = 1; n <= 4; n += 1) i[t + n] += r[t] * e[n] / 6;
		t.push(i);
	}
	return t.map((e) => {
		let t = Array(50).fill(0);
		for (let n = 48; n >= 0; --n) t[n] = (n < e.length ? e[n] : 0) + t[n + 1];
		return t;
	});
})(), vi = (e, t) => t <= 0 ? 1 : e <= 0 ? 0 : _i[Math.min(e, gi)][Math.min(t, 49)] ?? 0;
function yi(e, t) {
	let n = Math.min(t, $.fightDiceCap);
	for (let t = 1; t <= n; t += 1) if (vi(t, e) >= $.fightP) return t;
	return n > 0 && vi(n, e) >= $.fightPMin ? n : 0;
}
function bi(e) {
	if (e.monsters >= 3) return 0;
	let t = [
		0,
		2,
		4
	][e.monsters], n = e.chests >= 2 ? 2 : 3;
	return t + (e.monsters < n ? $.qualNeedValue : 0);
}
function xi(e, t, n) {
	if (t === n) return null;
	let r = /* @__PURE__ */ new Map([[t, -1]]), i = [t];
	for (; i.length;) {
		let a = i.shift();
		for (let o = 0; o < 4; o += 1) {
			let s = B(a, o);
			if (s < 0 || r.has(s)) continue;
			let c = e[String(a)];
			if (c && !c.walls[o] && (e[String(s)] || s === n)) {
				if (r.set(s, a), s === n) {
					let e = s;
					for (; r.get(e) !== t;) e = r.get(e);
					return e;
				}
				i.push(s);
			}
		}
	}
	return null;
}
function Si(e, t, n) {
	if (t === n) return 0;
	let r = /* @__PURE__ */ new Map([[t, 0]]), i = [t];
	for (; i.length;) {
		let t = i.shift();
		for (let a = 0; a < 4; a += 1) {
			let o = B(t, a);
			if (o < 0 || r.has(o)) continue;
			let s = e[String(t)];
			if (s && !s.walls[a] && e[String(o)]) {
				if (r.set(o, r.get(t) + 1), o === n) return r.get(o);
				i.push(o);
			}
		}
	}
	return Infinity;
}
function Ci(e, t) {
	for (let n = 0; n < 4; n += 1) if (B(e, n) === t) return n;
	return 0;
}
var wi = (e) => e.fresh.white >= 2 || e.fresh.quick >= 1 || e.conserved.includes("quick") || pi(e) >= 2, Ti = (e) => e.fresh.quick >= 1 || e.conserved.includes("quick");
function Ei(e, t, n) {
	if (t === n || !e[String(n)]) return !1;
	let r = (t) => {
		let n = e[String(t)];
		return !!n && (n.feature === "empty" || n.resolved);
	}, i = /* @__PURE__ */ new Set([t]), a = [t];
	for (; a.length;) {
		let t = a.pop();
		for (let o = 0; o < 4; o += 1) {
			let s = B(t, o);
			if (!(s < 0 || i.has(s)) && !e[String(t)]?.walls[o]) {
				if (s === n) return !0;
				r(s) && (i.add(s), a.push(s));
			}
		}
	}
	return !1;
}
function Di(e) {
	let t = e.known[String(e.pos)];
	if (!t) return null;
	let n = null, r = -1;
	for (let i = 0; i < 4; i += 1) {
		let a = B(e.pos, i);
		if (a < 0 || t.walls[i] || e.known[String(a)]) continue;
		let o = 0;
		for (let t = 0; t < 4; t += 1) {
			let n = B(a, t);
			n >= 0 && n !== e.pos && !e.known[String(n)] && (o += 1);
		}
		o > r && (r = o, n = i);
	}
	return n;
}
function Oi(e) {
	let t = 0;
	for (let n of Object.keys(e)) {
		let r = e[n].feature;
		(r === "monster" || r === "trap") && (t += 1);
	}
	let n = 36 - Object.keys(e).length;
	return n > 0 ? (6 - t) / n : 0;
}
function ki(e, t) {
	return e.fresh.perc >= 1 || e.conserved.includes("perc") || Oi(e.known) >= $.whitePeerDensity && pi(e) >= 2 ? { action: {
		type: "peer",
		dir: t
	} } : pi(e) >= 1 ? { action: {
		type: "creep",
		dir: t
	} } : null;
}
var Ai = (e, t) => {
	for (let n of Object.keys(e)) if (e[n].feature === t) return Number(n);
	return null;
};
function ji(e) {
	for (let t of Object.keys(e.known)) {
		let n = e.known[t];
		if (n.feature === "chest" && !n.resolved || n.feature === "monster" && !n.resolved && bi(e) > 0) return !0;
	}
	return !1;
}
function Mi(e, t, n) {
	return mi(e) ? n.phase === "finalTurn" || t.escaped || mi(t) || e.chests >= 3 || e.monsters >= 3 ? !0 : !ji(e) : !1;
}
function Ni(e, t) {
	let n = e.known, r = null;
	for (let i of Object.keys(n)) {
		let a = Number(i), o = n[i], s = !1;
		for (let e = 0; e < 4; e += 1) {
			let t = B(a, e);
			t >= 0 && !o.walls[e] && !n[String(t)] && (s = !0);
		}
		if (!s) continue;
		let c = Si(n, e.pos, a);
		if (!Number.isFinite(c)) continue;
		let l = $.frontierValue + t - (c + 1) * $.stepCost;
		(!r || l > r.score) && (r = {
			kind: "frontier",
			cell: a,
			score: l,
			dist: c
		});
	}
	return r;
}
function Pi(e, t, n) {
	let r = e.known, i = e.pos, a = Ai(r, "exit"), o = n.phase === "finalTurn" || t.escaped || mi(t), s = null, c = (e) => {
		(!s || e.score > s.score || e.score === s.score && e.dist < s.dist) && (s = e);
	};
	if (a !== null && Mi(e, t, n)) {
		let e = Si(r, i, a);
		Number.isFinite(e) && c({
			kind: "exit",
			cell: a,
			score: $.exitValue - e * $.stepCost,
			dist: e
		});
	}
	let l = bi(e);
	for (let e of Object.keys(r)) {
		let t = Number(e);
		if (t === i) continue;
		let n = r[e];
		if (n.feature === "chest" && !n.resolved) {
			let e = Si(r, i, t);
			Number.isFinite(e) && c({
				kind: "chest",
				cell: t,
				score: $.chestValue - e * $.stepCost,
				dist: e
			});
		} else if (n.feature === "monster" && !n.resolved && l > 0) {
			let e = Si(r, i, t);
			Number.isFinite(e) && c({
				kind: "monster",
				cell: t,
				score: l - (e + $.fightCost) * $.stepCost,
				dist: e
			});
		}
	}
	let u = Ni(e, mi(e) && a === null && o ? $.raceFrontierBonus : 0);
	return u && c(u), s;
}
function Fi(e, t, n, r) {
	let i = t;
	for (let t = 0; t < r; t += 1) {
		let t = xi(e, i, n);
		if (t === null) return !1;
		let r = e[String(t)];
		if (!r || r.feature !== "empty" && !r.resolved) return !1;
		i = t;
	}
	return !0;
}
function Ii(e, t) {
	let n = e.known, r = e.pos;
	if (t.dist === 0) {
		if (t.kind !== "frontier") return null;
		let n = Di(e);
		return n === null ? null : ki(e, n);
	}
	if (Ti(e)) {
		let e = -1, i = $.backtrackSave;
		for (let a of Object.keys(n)) {
			let o = Number(a);
			if (o === r || !Ei(n, r, o)) continue;
			let s = Si(n, o, t.cell);
			if (!Number.isFinite(s)) continue;
			let c = t.dist - s;
			c >= i && (i = c, e = o);
		}
		if (e >= 0) return { action: {
			type: "backtrack",
			to: e
		} };
	}
	let i = n[String(r)];
	if ((i?.feature !== "monster" && i?.feature !== "trap" || i.resolved) && t.dist >= $.hustleMin && wi(e) && Fi(n, r, t.cell, 2)) return { action: { type: "hustle" } };
	let a = xi(n, r, t.cell);
	return a === null || pi(e) < 1 ? null : n[String(a)] ? { action: {
		type: "creep",
		dir: Ci(r, a)
	} } : ki(e, Ci(r, a));
}
function Li(e, t) {
	let n = e.known[String(e.pos)], r = (n?.feature === "monster" || n?.feature === "trap") && !n.resolved;
	if (t.phase !== "finalTurn" && !r) {
		let t = 3 - e.conserved.length;
		if (t > 0) {
			let n = [], r = { ...e.fresh };
			for (let e of [
				"white",
				"perc",
				"quick"
			]) for (; n.length < t && r[e] > 0;) n.push(e), --r[e];
			if (n.length > 0) return { action: {
				type: "conserve",
				cubes: n
			} };
		}
	}
	return { action: { type: "endTurn" } };
}
function Ri(e, t, n) {
	let r = {
		monstersDefeated: n.monsters,
		chestsOpened: n.chests,
		trapsDisarmed: n.traps,
		exitedFirst: n.exitOrder === 1,
		mapFullyKnown: Object.keys(n.known).length >= 36
	}, i = he(t.hoard, _e(t.hoard, r), r), a = 0, o = -Infinity;
	return e.display.forEach((e, n) => {
		let s = [...t.hoard, e], c = he(s, _e(s, r), r) - i;
		c > o && (o = c, a = n);
	}), a;
}
function zi(e, t, n, r) {
	let i = /* @__PURE__ */ new Map([[n, 0]]), a = [n];
	for (; a.length;) {
		let t = a.shift();
		if (t === r) break;
		for (let n = 0; n < 4; n += 1) {
			if (V(e, t, n)) continue;
			let r = B(t, n);
			r < 0 || i.has(r) || (i.set(r, i.get(t) + 1), a.push(r));
		}
	}
	let o = i.get(r);
	if (o === void 0) return {
		d: 99,
		hazards: 0
	};
	let s = 0, c = r;
	for (let r = 0; c !== n && r < 36; r += 1) {
		let n = t[c];
		(n === "monster" || n === "trap") && (s += 1);
		let r = i.get(c) - 1;
		for (let t = 0; t < 4; t += 1) {
			let n = B(c, t);
			if (!(n < 0 || V(e, c, t)) && i.get(n) === r) {
				c = n;
				break;
			}
		}
	}
	return {
		d: o,
		hazards: s
	};
}
function Bi() {
	let e = De(di), t = -Infinity;
	for (let n = 0; n < $.buildCandidates; n += 1) {
		let r = n === 0 ? e : De(di), i = new Set(r.walls), a = Ce(r), o = 0;
		for (let e of [r.exit, ...r.chests]) {
			let t = zi(i, a, r.start, e);
			o += t.d + t.hazards * $.hazardPathBonus;
		}
		o > t && (t = o, e = r);
	}
	return e;
}
function Vi(e, t) {
	let n = e.public, r = e.private, i = n.players.find((e) => e.rid === t);
	if (!i) return null;
	if (n.phase === "build") return i.submitted ? null : { action: {
		type: "build",
		maze: Bi()
	} };
	if (n.phase === "pickFirst") return n.buildOrder[0] === t ? { action: {
		type: "pickFirst",
		rid: t
	} } : null;
	if (n.phase === "scoring") {
		if (n.scoringDone[t] || !r) return null;
		let e = {
			monstersDefeated: i.monsters,
			chestsOpened: i.chests,
			trapsDisarmed: i.traps,
			exitedFirst: i.exitOrder === 1,
			mapFullyKnown: Object.keys(i.known).length >= 36
		};
		return { action: {
			type: "reveal",
			cards: _e(r.hoard, e)
		} };
	}
	if (n.phase !== "explore" && n.phase !== "finalTurn" || n.turn !== t) return null;
	let a = n.players.find((e) => e.rid !== t), o = i.known, s = i.pos, c = pi(i);
	if (n.pendingChest && r) return { action: {
		type: "chooseTreasure",
		index: Ri(n, r, i)
	} };
	if (n.pendingFatigue) return { action: hi(i, n.pendingFatigue) };
	if (n.pendingHazard) {
		let e = n.pendingHazard === "monster" ? o[String(s)]?.monsterTarget ?? 6 : 5;
		return { action: {
			type: n.pendingHazard === "monster" ? "fight" : "disarm",
			dice: yi(e, c) || 0
		} };
	}
	if (n.peerFree != null) {
		let e = o[String(n.peerFree)], t = o[String(s)];
		if ((t?.feature === "monster" || t?.feature === "trap") && !t.resolved) return { action: {
			type: "creep",
			dir: Ci(s, n.peerFree)
		} };
		let r = Pi(i, a, n), c = !!r && r.dist > 0 && xi(o, s, r.cell) === n.peerFree, l = !!e && (e.feature === "chest" && !e.resolved || e.feature === "monster" && !e.resolved && bi(i) > 0 || e.feature === "exit" && mi(i));
		if (c || l) return { action: {
			type: "creep",
			dir: Ci(s, n.peerFree)
		} };
	}
	let l = o[String(s)];
	if (n.hustleLeft > 0) {
		let e = Pi(i, a, n);
		if (e) {
			if (e.dist === 0) {
				let t = e.kind === "frontier" ? Di(i) : null;
				if (t !== null) return { action: {
					type: "move",
					dir: t
				} };
			} else {
				let t = xi(o, s, e.cell);
				if (t !== null) return { action: {
					type: "move",
					dir: Ci(s, t)
				} };
			}
		}
		return { action: { type: "stopHustle" } };
	}
	if (l && l.feature === "monster" && !l.resolved) {
		let e = yi(l.monsterTarget ?? 6, c);
		if (bi(i) > 0 && e > 0) return { action: {
			type: "fight",
			dice: e
		} };
	}
	if (l && l.feature === "trap" && !l.resolved) {
		let e = yi(5, c);
		if ((r?.hoard.includes(316) ?? !1) && e > 0) return { action: {
			type: "disarm",
			dice: e
		} };
	}
	if (l?.feature === "exit" && Mi(i, a, n)) return { action: { type: "exit" } };
	let u = Pi(i, a, n);
	if (u) {
		let e = Ii(i, u);
		if (e) return e;
	}
	return Li(i, n);
}
function Hi(e, t) {
	let n = e.public;
	if (n.phase === "build" || n.phase === "pickFirst" || n.phase === "scoring") return Vi(e, t);
	if (n.phase !== "explore" && n.phase !== "finalTurn" || n.turn !== t) return null;
	let r = n.players.find((e) => e.rid === t);
	if (!r) return null;
	if (n.pendingChest) return { action: {
		type: "chooseTreasure",
		index: Math.floor(di() * n.display.length)
	} };
	if (n.pendingFatigue) return { action: hi(r, n.pendingFatigue) };
	if (n.pendingHazard) return { action: {
		type: n.pendingHazard === "monster" ? "fight" : "disarm",
		dice: Math.min(2, pi(r))
	} };
	let i = r.known[String(r.pos)];
	if (n.peerFree != null && (i?.feature === "monster" || i?.feature === "trap") && !i.resolved) return { action: {
		type: "creep",
		dir: Ci(r.pos, n.peerFree)
	} };
	if (n.hustleLeft > 0) {
		let e = r.known[String(r.pos)], t = [];
		for (let n = 0; n < 4; n += 1) B(r.pos, n) >= 0 && e && !e.walls[n] && t.push(n);
		return t.length === 0 || di() < .3 ? { action: { type: "stopHustle" } } : { action: {
			type: "move",
			dir: t[Math.floor(di() * t.length)]
		} };
	}
	let a = r.known[String(r.pos)], o = [];
	if (a) {
		for (let e = 0; e < 4; e += 1) B(r.pos, e) >= 0 && !a.walls[e] && fi(r) >= 1 && o.push({
			type: "creep",
			dir: e
		});
		a.feature === "monster" && !a.resolved && pi(r) >= 1 && o.push({
			type: "fight",
			dice: Math.min(2, pi(r))
		}), a.feature === "trap" && !a.resolved && pi(r) >= 1 && o.push({
			type: "disarm",
			dice: Math.min(2, pi(r))
		}), a.feature === "exit" && mi(r) && o.push({ type: "exit" });
	}
	return o.push({ type: "endTurn" }), { action: o[Math.floor(di() * o.length)] };
}
var Ui = (e, t) => e.public.adventure ? si(e, t) : t.difficulty === "weak" ? Hi(e, t.rid) : Vi(e, t.rid);
//#endregion
//#region src/games/lairs/fx.tsx
function Wi(e, t) {
	let n = t ? e.member(t) : void 0;
	return m[(n?.colorIndex ?? 0) % m.length].hex;
}
function Gi(e, t, n) {
	let r = t.data?.[n];
	return t.rid && typeof r == "number" ? e.anchor(`cell:${t.rid}:${r}`) : null;
}
function Ki(e, t) {
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - t) / 2,
		w: t,
		h: t
	};
}
function qi(e, t) {
	let n = 0;
	for (let r = 1; r <= t; r += 1) {
		let i = Math.ceil(t / r);
		n = Math.max(n, Math.min(e.w / (i + (i - 1) / 8), e.h / (r + (r - 1) / 8)));
	}
	let r = Math.max(24, n);
	return {
		size: r * 44 / 48,
		gap: r / 8
	};
}
var Ji = {
	1: [4],
	2: [0, 8],
	3: [
		0,
		4,
		8
	],
	4: [
		0,
		2,
		6,
		8
	],
	5: [
		0,
		2,
		4,
		6,
		8
	],
	6: [
		0,
		2,
		3,
		5,
		6,
		8
	]
};
function Yi({ value: e }) {
	return /* @__PURE__ */ O("span", {
		className: "lairs-fx-die-face",
		"aria-label": String(e),
		children: Array.from({ length: 9 }, (t, n) => /* @__PURE__ */ O("i", { className: Ji[e]?.includes(n) ? "is-on" : "" }, n))
	});
}
var Xi = j({
	faces: [
		1,
		4,
		2,
		3,
		2,
		3
	].map((e, t) => /* @__PURE__ */ O(Yi, { value: e }, t)),
	slotOf: (e) => ({
		1: 0,
		2: 2,
		3: 3,
		4: 1
	})[e] ?? 0
}), Zi = {
	adventureRoll(e, t) {
		let n = e.data, r = t.anchor("lairs-ap-dice");
		if (!r || !n?.dice?.length) return null;
		let i = qi(r, n.dice.length);
		return {
			ms: Ht,
			node: /* @__PURE__ */ O("div", {
				className: "lairs-ap-fx-dice",
				style: {
					left: r.x,
					top: r.y,
					width: r.w,
					height: r.h,
					gap: i.gap
				},
				children: n.dice.map((e, t) => {
					let r = n.power?.[t] ? Ke : Ge;
					return /* @__PURE__ */ O(ae, {
						size: i.size,
						ms: Ht,
						face: r.indexOf(e),
						faces: r.map((e, t) => /* @__PURE__ */ O(Yi, { value: e }, t))
					}, t);
				})
			})
		};
	},
	monsterRoll(e, t) {
		let n = e.data, r = t.anchor("lairs-ap-monster-dice");
		return !r || !n?.dice ? null : {
			ms: Ht,
			node: /* @__PURE__ */ O("div", {
				className: "lairs-ap-fx-dice",
				style: {
					left: r.x,
					top: r.y,
					width: r.w,
					height: r.h
				},
				children: n.dice.map((e, t) => /* @__PURE__ */ O(ae, {
					size: 44,
					ms: Ht,
					face: qe.indexOf(e),
					faces: qe.map((e, t) => /* @__PURE__ */ O("span", { children: e === "skull" ? "☠" : e === 0 ? "—" : e }, t))
				}, t))
			})
		};
	},
	adventureResult(e, t) {
		let n = e.data, r = Gi(t, e, "cell");
		return r ? {
			ms: Ht,
			node: /* @__PURE__ */ O(M, {
				at: r,
				ms: Ht,
				children: /* @__PURE__ */ k("span", {
					className: `lairs-fx-result ${n.success ? "is-success" : "is-failure"}`,
					children: [
						n.success ? "✓" : "✕",
						" ",
						n.total,
						"/",
						n.target
					]
				})
			})
		} : null;
	},
	built(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ O(P, {
				at: n,
				ms: 700
			})
		} : null;
	},
	move(e, t) {
		if (e.rid && t.anchor(`board3d:${e.rid}`)) return {
			ms: 340,
			node: null
		};
		let n = Gi(t, e, "from"), r = Gi(t, e, "to");
		if (!n || !r) return null;
		let i = Math.round(Math.min(n.w, n.h, r.w, r.h) * .56), a = e.data?.to, o = e.rid && typeof a == "number" ? `pawn:${e.rid}:${a}` : null;
		return {
			ms: 340,
			hide: o && t.anchor(o) ? [o] : void 0,
			node: /* @__PURE__ */ O(N, {
				from: Ki(n, i),
				to: Ki(r, i),
				ms: 320,
				children: /* @__PURE__ */ O($n, {
					color: Wi(t, e.rid),
					size: i
				})
			})
		};
	},
	reveal(e, t) {
		let n = Gi(t, e, "cell");
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ O(P, {
				at: n,
				ms: 600
			})
		} : null;
	},
	strike(e, t) {
		let n = Gi(t, e, "cell");
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ O(M, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ O("span", {
					className: "text-lg",
					children: "💥"
				})
			})
		} : null;
	},
	fatigue(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ O(M, {
				at: n,
				ms: 600,
				children: /* @__PURE__ */ O("span", {
					className: "text-lg",
					children: "💤"
				})
			})
		} : null;
	},
	roll(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.dice) || typeof n.target != "number" || typeof n.success != "boolean") return null;
		let r = Gi(t, e, "cell") ?? (e.rid ? t.anchor(`seat:${e.rid}`) : null), i = n.dice.reduce((e, t) => e + t, 0), a = e.rid && typeof n.cell == "number" ? `cell:${e.rid}:${n.cell}` : e.rid ? `seat:${e.rid}` : void 0, o = n.dice.length > 0 ? Xi({
			...e,
			data: {
				dice: n.dice,
				banner: !0,
				target: a ?? "dice"
			}
		}, {
			...t,
			queued: 0
		}) : null;
		if (!o && !r) return null;
		let s = o ? (n.dice.length - 1) * A.stagger + A.tumble + A.hold : 0;
		return {
			ms: Math.max(o?.ms ?? 0, r ? s + 900 : 0),
			hide: o?.hide,
			node: /* @__PURE__ */ k(D, { children: [o?.node, r && /* @__PURE__ */ O(M, {
				at: r,
				ms: 900,
				delay: s,
				children: /* @__PURE__ */ k("span", {
					className: `lairs-fx-result font-mono tabular-nums ${n.success ? "is-success" : "is-failure"}`,
					children: [
						n.success ? "✓" : "✕",
						" 🎲",
						i,
						"/",
						n.target
					]
				})
			})] })
		};
	},
	chest(e, t) {
		let n = Gi(t, e, "cell");
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ O(M, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ O("span", {
					className: "text-lg",
					children: "🎁"
				})
			})
		} : null;
	},
	draw(e, t) {
		let n = t.anchor("deck"), r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !n || !r ? null : {
			ms: 420,
			node: /* @__PURE__ */ O(N, {
				from: n,
				to: r,
				ms: 400,
				children: /* @__PURE__ */ O("div", {
					className: "lairs-fx-cardback",
					children: "✦"
				})
			})
		};
	},
	takeCard(e, t) {
		let n = t.anchor("display"), r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !n || !r ? null : {
			ms: 420,
			node: /* @__PURE__ */ O(N, {
				from: n,
				to: r,
				ms: 400,
				children: /* @__PURE__ */ O("div", {
					className: "lairs-fx-cardback is-treasure",
					children: "◆"
				})
			})
		};
	},
	exit(e, t) {
		let n = Gi(t, e, "cell");
		return n ? {
			ms: 1e3,
			node: /* @__PURE__ */ k(D, { children: [/* @__PURE__ */ O(P, {
				at: n,
				ms: 800
			}), /* @__PURE__ */ O(M, {
				at: n,
				ms: 1e3,
				children: /* @__PURE__ */ O("span", {
					className: "text-lg",
					children: "🚪"
				})
			})] })
		} : null;
	}
};
//#endregion
//#region src/games/lairs/endgame-review.tsx
function Qi({ board: e, renderResult: t, ...n }) {
	let r = p(), [i, o] = l(!0), [u, d] = l(null), f = c(null), m = c(null), h = c(null);
	a(() => {
		if (!u) return;
		h.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => d(null), 5e3);
		return () => clearTimeout(e);
	}, [u]);
	let g = (e) => {
		d(null), o(e), requestAnimationFrame(() => (e ? f : m).current?.focus({ preventScroll: !0 }));
	}, _ = s(() => ({
		onPlayAgain: n.onPlayAgain && (() => d({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => d({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => d({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), v = {
		...n,
		..._
	};
	return /* @__PURE__ */ k("div", {
		className: "lairs-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ O("div", {
				className: "lairs-endgame-board",
				inert: i,
				children: e
			}),
			/* @__PURE__ */ O("div", {
				className: "lairs-endgame-overlay",
				hidden: !i,
				children: /* @__PURE__ */ k("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), g(!1));
					},
					className: "lairs-endgame-panel",
					"aria-label": r("session.result.title"),
					children: [
						/* @__PURE__ */ k("header", {
							className: "lairs-endgame-heading",
							children: [/* @__PURE__ */ k("div", {
								className: "lairs-endgame-brand",
								children: [/* @__PURE__ */ O("span", {
									"aria-hidden": "true",
									children: Oe.icon
								}), r(Oe.nameKey)]
							}), /* @__PURE__ */ O("button", {
								type: "button",
								ref: f,
								className: "btn-quiet",
								"aria-label": r("games.lairs.reviewHide"),
								title: r("games.lairs.reviewHide"),
								onClick: () => g(!1),
								children: /* @__PURE__ */ O(I, { size: 19 })
							})]
						}),
						/* @__PURE__ */ O("div", {
							className: "lairs-endgame-result",
							inert: u !== null,
							children: t(v)
						}),
						u && /* @__PURE__ */ k("div", {
							className: "lairs-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || d(null);
							},
							children: [/* @__PURE__ */ O("button", {
								type: "button",
								ref: h,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = u.run;
									d(null), e();
								},
								children: r(u.label === "again" ? "games.lairs.reviewConfirmAgain" : "games.lairs.reviewConfirmLobby")
							}), /* @__PURE__ */ O("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									d(null), f.current?.focus({ preventScroll: !0 });
								},
								children: r("games.lairs.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ O("div", {
				className: "lairs-endgame-toolbar",
				hidden: i,
				children: /* @__PURE__ */ k("button", {
					type: "button",
					className: "btn-base",
					ref: m,
					onClick: () => g(!0),
					children: [
						/* @__PURE__ */ O(se, { size: 18 }),
						r("games.lairs.reviewShow"),
						/* @__PURE__ */ O(F, { size: 18 })
					]
				})
			})
		]
	});
}
function $i({ result: e, members: t, myRid: n, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: s, renderRowExtra: c, summary: u, navigation: d, content: m, afterRanking: h, scoreUnit: g, rankOf: _ }) {
	let v = p(), ee = f((e) => e.locale), [y, b] = l({}), x = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? ce(n, ee) : e;
	}, te = (t, n) => _?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), S = e.ranking.some((t) => e.scores?.[t] !== void 0), C = (t, r) => /* @__PURE__ */ k("div", {
		className: "lairs-score-identity",
		children: [
			/* @__PURE__ */ k("span", {
				className: "lairs-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ O("span", {
					"aria-label": v("games.lairs.reviewWinner"),
					children: "♛ "
				}), S && te(t, r)]
			}),
			/* @__PURE__ */ k("span", {
				className: "lairs-score-name",
				children: [x(t), t === n && /* @__PURE__ */ O("small", { children: v("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ k("small", {
				className: "lairs-score-autopilot",
				children: [
					/* @__PURE__ */ O(oe, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), w = (t) => e.ranking.map((n) => /* @__PURE__ */ O("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ k("div", {
		className: "lairs-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ O(le, {}),
			d,
			/* @__PURE__ */ k("div", {
				className: "lairs-score-body",
				children: [
					u && /* @__PURE__ */ O("div", {
						className: "lairs-score-summary",
						children: u
					}),
					i !== void 0 && /* @__PURE__ */ O("p", {
						className: "lairs-score-hints",
						children: v("session.hint.usedCount", { n: i })
					}),
					m ?? (s?.length ? /* @__PURE__ */ O("div", {
						className: "lairs-score-table-scroll",
						children: /* @__PURE__ */ k("table", {
							className: "lairs-score-table",
							"aria-label": v(Oe.nameKey),
							children: [
								/* @__PURE__ */ O("thead", { children: /* @__PURE__ */ k("tr", { children: [/* @__PURE__ */ O("th", { scope: "col" }), /* @__PURE__ */ O(D, { children: e.ranking.map((t, n) => /* @__PURE__ */ O("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: C(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ O("tbody", { children: s.map((e, t) => /* @__PURE__ */ k(r, { children: [/* @__PURE__ */ k("tr", { children: [/* @__PURE__ */ O("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ k("button", {
										type: "button",
										"aria-expanded": !!y[t],
										onClick: () => b((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ O(I, { size: 15 }), e.label]
									}) : e.label
								}), w(e)] }), y[t] && e.details?.map((e, t) => /* @__PURE__ */ k("tr", {
									className: "lairs-score-sub",
									children: [/* @__PURE__ */ O("th", {
										scope: "row",
										children: e.label
									}), w(e)]
								}, t))] }, t)) }),
								S && /* @__PURE__ */ O("tfoot", { children: /* @__PURE__ */ k("tr", { children: [/* @__PURE__ */ O("th", {
									scope: "row",
									children: v("games.lairs.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ O("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ O("ol", {
						className: "lairs-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ k("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ k("div", {
								className: "lairs-score-rankline",
								children: [C(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ k("strong", {
									className: "lairs-score-points",
									children: [e.scores[t], g && /* @__PURE__ */ O("small", { children: g })]
								})]
							}), c?.(t)]
						}, t))
					})),
					h,
					!!s?.length && c && /* @__PURE__ */ O("div", {
						className: "lairs-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ k("details", { children: [/* @__PURE__ */ O("summary", { children: x(e) }), c(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ k("footer", {
				className: "lairs-score-actions",
				children: [
					o && /* @__PURE__ */ O("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: v("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ O("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: v("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ O("p", { children: v("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/lairs/endgame-scores.tsx
function ea(e) {
	let t = p(), n = e.public, r = [
		["treasures", "games.lairs.breakTreasures"],
		["monsters", "games.lairs.breakMonsters"],
		["exit", "games.lairs.breakExit"]
	].map(([e, r]) => ({
		label: t(r),
		value: (t) => n.final?.breakdown[t]?.[e] ?? "—"
	}));
	return /* @__PURE__ */ O($i, {
		...e,
		rows: r,
		renderRowExtra: (e) => /* @__PURE__ */ O("div", {
			className: "grid grid-cols-4 gap-1",
			children: (n.final?.revealed[e] ?? []).map((e) => /* @__PURE__ */ O(cr, { id: e }, e))
		})
	});
}
//#endregion
//#region src/games/lairs/game-over.tsx
function ta(e) {
	return /* @__PURE__ */ O(ea, { ...e });
}
function na(e) {
	return /* @__PURE__ */ O(Qi, {
		...e,
		board: /* @__PURE__ */ O(Pr, {
			review: !0,
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ O(ta, { ...e })
	});
}
//#endregion
//#region src/games/lairs/options.tsx
var ra = [
	"games.lairs.stage1",
	"games.lairs.stage2",
	"games.lairs.stage3",
	"games.lairs.stage4"
];
function ia({ value: e, onChange: t }) {
	let n = p(), r = Pe.safeParse(e), i = r.success ? r.data : Pe.parse(void 0);
	return /* @__PURE__ */ k("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ O(de, {
			title: n("games.lairs.optMode"),
			children: ["base", "adventure"].map((e) => /* @__PURE__ */ O(ue, {
				name: "lairs-mode",
				value: e,
				checked: i.mode === e,
				label: n(e === "base" ? "games.lairs.modeBase" : "games.lairs.modeAdventure"),
				accent: Oe.accent,
				onChange: () => t({
					...i,
					mode: e
				})
			}, e))
		}), i.mode === "adventure" && /* @__PURE__ */ k(D, { children: [
			/* @__PURE__ */ O(de, {
				title: n("games.lairs.optStage"),
				children: [
					1,
					2,
					3,
					4
				].map((e) => /* @__PURE__ */ O(ue, {
					name: "lairs-stage",
					value: String(e),
					checked: i.stage === e,
					label: n(ra[e - 1]),
					accent: Oe.accent,
					onChange: () => {
						let n = (t) => {
							let n = Ye(e, i.boxZero, t).map((e) => e.id), r = i[t === "monster" ? "monsters" : "traps"].filter((e) => n.includes(e));
							return [...r, ...n.filter((e) => !r.includes(e))].slice(0, 3);
						};
						t({
							...i,
							stage: e,
							monsters: e >= 3 ? n("monster") : i.monsters,
							traps: e >= 3 ? n("trap") : i.traps
						});
					}
				}, e))
			}),
			/* @__PURE__ */ O("p", {
				className: "text-xs text-ink/65",
				children: n("games.lairs.stageHint")
			}),
			i.stage >= 3 && /* @__PURE__ */ O(de, {
				title: n("games.lairs.optSelection"),
				columns: 3,
				children: [
					"random",
					"manual",
					"draft"
				].map((e) => /* @__PURE__ */ O(ue, {
					name: "lairs-selection",
					value: e,
					checked: i.selection === e,
					label: n(e === "random" ? "games.lairs.selectRandom" : e === "manual" ? "games.lairs.selectManual" : "games.lairs.selectDraft"),
					accent: Oe.accent,
					onChange: () => t({
						...i,
						selection: e
					})
				}, e))
			}),
			/* @__PURE__ */ O(fe, {
				checked: i.boxZero,
				disabled: i.stage < 3,
				label: n("games.lairs.optZero"),
				hint: n("games.lairs.zeroHint"),
				accent: Oe.accent,
				onChange: () => {
					let e = (e) => {
						let t = e === "monster" ? "monsters" : "traps", n = Ye(i.stage, !i.boxZero, e).map((e) => e.id), r = [...new Set(i[t].filter((e) => n.includes(e)))];
						return [...r, ...n.filter((e) => !r.includes(e))].slice(0, 3);
					};
					t({
						...i,
						boxZero: !i.boxZero,
						monsters: e("monster"),
						traps: e("trap")
					});
				}
			}),
			i.stage >= 3 && i.selection === "manual" && ["monster", "trap"].map((e) => {
				let r = e === "monster" ? "monsters" : "traps";
				return /* @__PURE__ */ O("div", {
					className: "flex flex-col gap-3",
					children: [
						0,
						1,
						2
					].map((a) => /* @__PURE__ */ O(de, {
						title: `${n(e === "monster" ? "games.lairs.featMonster" : "games.lairs.featTrap")} ${a + 1}`,
						children: Ye(i.stage, i.boxZero, e).map((o) => /* @__PURE__ */ O(ue, {
							name: `lairs-${e}-${a}`,
							value: o.id,
							checked: i[r][a] === o.id,
							label: n(o.name),
							hint: `${o.targets[i.stage - 1]}`,
							accent: Oe.accent,
							onChange: () => {
								let e = [...i[r]], n = e[a], s = e.indexOf(o.id);
								e[a] = o.id, s >= 0 && s !== a && (e[s] = n), t({
									...i,
									[r]: e
								});
							}
						}, o.id))
					}, a))
				}, e);
			}),
			/* @__PURE__ */ O("p", {
				className: "text-xs text-ink/65",
				children: n("games.lairs.compatibility")
			}),
			i.stage === 4 && /* @__PURE__ */ O("p", {
				className: "text-xs text-ink/65",
				children: n("games.lairs.monsterDiceRule")
			})
		] })]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/lairs/entry.tsx
var aa = {
	definition: xn,
	View: Pr,
	bot: Ui,
	fx: Zi,
	OverView: na,
	Options: ia,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			optMode: "玩法",
			modeBase: "基础版",
			modeAdventure: "冒险者扩展",
			optStage: "累计阶段",
			stage1: "盒 1 + A、B",
			stage2: "盒 2 + C、D",
			stage3: "盒 3 + E、F",
			stage4: "盒 4 · 怪物骰",
			optSelection: "危险物选择",
			selectRandom: "随机",
			selectManual: "手动指定",
			selectDraft: "双方轮选",
			optZero: "Box Zero",
			zeroHint: "盒 3 起，将已收录的 4 种危险物加入候选池",
			stageHint: "各阶段累计包含之前的内容。盒 1、2 使用指定危险物；双人、6×6。",
			compatibility: "本期收录 34 张杂物、4 张新宝藏；缺卡不入池。尖啸怪从已收录且符合摆位的怪物中随机抽取。",
			monsterDiceRule: "两颗怪物骰各为空白×2、−1×2、−2×1、骷髅×1；双骷髅只触发一次能力。",
			cubeKnow: "变废为宝",
			cubeBrawn: "战力",
			cubeGuile: "狡诈",
			apDraft: "选择共同危险物",
			apAttributes: "选择 3 种不同属性",
			apStage: "冒险者 · 盒 {{n}}",
			apWait: "等待 {{name}} 选择",
			apConfirm: "确认选择",
			apSkip: "跳过 / 完成",
			apContinue: "付感知再抽 1 张",
			apPool: "本局危险物",
			apJunk: "杂物",
			apHoard: "收藏",
			apClose: "关闭",
			apInfo: "卡牌与规则",
			apPay: "点选能量指定支付，未选则自动支付",
			apAutoPay: "自动支付",
			apDouble: "积蓄：再点一次花两档",
			apReady: "就绪",
			apSpent: "已用",
			apFatigued: "疲劳",
			apConserved: "积蓄",
			apFree: "免费潜行可用",
			apCharge: "冲锋",
			apSneak: "遁行",
			apScrounge: "搜寻",
			apScavenge: "席卷",
			apRecover: "休养",
			apImprovise: "即兴发挥",
			apFinishCheck: "完成玩家骰",
			apRoll: "购买 {{n}} 骰并掷骰",
			apDice: "基础 / 强力骰",
			apTotal: "总和 {{n}} / 目标 {{target}}",
			apMonsterDice: "怪物骰",
			apSkull: "骷髅",
			apBlank: "空白",
			apCheckWait: "正在结算检定…",
			apSearched: "已搜寻格：{{cells}}",
			apLocated: "已定位格：{{cells}}",
			apEnraging: "激怒：进入怪格，目标永久 +3",
			apForcedTucked: "酸蚀盖扣 · 只计 1 分",
			apFlute: "风汐笛：先点怪物，再点两格内空格",
			apTarget: "点选目标格",
			apUse: "使用",
			apDiscard: "弃置",
			apChoiceCount: "已选 {{n}} / {{max}}",
			apBuilderMap: "你的完整迷宫",
			apExplorerMap: "你的认知地图",
			apViewSwitch: "切换地图",
			apBeforeDice: "买骰前的免费骰",
			apAfterDice: "玩家骰后：重掷或调整总和",
			apJunkTarget: "选择卡牌目标",
			apCoffee: "重掷第 {{n}} 骰",
			apWandPlus: "总和 +2",
			apWandMinus: "总和 −2",
			apWandDelta: "总和 {{n}}",
			apCostPeer: "2 或感知 1",
			apCostCharge: "2 或战力 1",
			apCostSneak: "2 或狡诈 1",
			apCostScrounge: "2 或变废为宝 1",
			apCostKnow: "变废为宝 1",
			apCostBrawn: "战力 1",
			apBuy: "骰子数量",
			apUseRope: "先点视为空格的部件，再点回退终点",
			apNextHazard: "按列表顺序放置：{{name}}",
			apCellHazard: "{{cell}}：{{name}}",
			errHazardPlacement: "窃语怪群须在三墙死路，碾压墙须在相对双墙走廊",
			taskAdapt: "刷新：可将刚恢复的 1 块换色",
			taskFatigue: "选择要疲劳的块",
			taskDiscardJunk: "杂物超过上限或受到罚则：先弃牌",
			taskDiscardTreasure: "选择弃掉的宝藏",
			taskDiscardEither: "弃 1 杂物或宝藏",
			taskTuck: "选择永久盖扣的宝藏",
			taskDowngrade: "选择降级为白色的属性块",
			taskRefresh: "选择变为就绪的块",
			taskExchange: "选择支付并换色的块",
			taskRecover: "选择疲劳块移至已用区",
			taskBlanket: "疲劳 3 块，新增 1 白块至已用区",
			taskLearn: "选择要告知的格",
			taskLocate: "建造者选择最近的定位格",
			taskWalls: "建造者选择未知墙",
			taskScrounge: "搜寻：留 1 张杂物",
			taskAppraise: "暗抽宝藏：可逐次付感知继续抽",
			taskAppraiseKeep: "暗抽宝藏：留 1 张",
			taskShovel: "是否用碎裂铲子刷新公开宝藏？",
			taskTeleport: "选择传送位置",
			taskReturn: "潜行退回进入前格并结算",
			taskSpawn: "尖啸怪：放置抽中的怪物",
			taskShield: "是否用破碎盾牌取消本次怪物袭击的疲劳？",
			taskIgnore: "是否忽略本次进入的怪物？",
			taskRope: "选择回退路径",
			hBlob: "饥饿软泥怪",
			hTangle: "荆棘怪",
			hAutoflail: "流星锤",
			hGolem: "家具魔像",
			hWhisper: "窃语怪群",
			hForge: "熔炉巨像",
			hPit: "滑鼠深坑",
			hBlink: "闪现符咒",
			hGremling: "精怪群",
			hWalls: "碾压墙",
			hMantle: "狂怒披风",
			hSentry: "蒸汽哨兵",
			hScreamer: "尖啸怪",
			hBanish: "放逐盒",
			hAcid: "酸蚀池",
			hBlobText: "自然；盒2起弱战力/敏捷。盒1袭击疲劳任意2、胜利无额外奖励；盒2起疲劳敏捷1+任意1、胜：杂物1。盒4骷髅：总和≥目标+2则免伤，目标升至总和。",
			hTangleText: "自然；弱战力/感知。袭击：疲劳任意1、弃杂物2；胜：杂物1。盒4骷髅：总和−2，若存活弃宝藏1。",
			hAutoflailText: "机械；弱战力/变废为宝。袭击：盒2、3疲劳变废为宝1+战力1，盒4改为敏捷1+战力1；胜：杂物1。盒4骷髅：将1变废为宝块降级为白。",
			hGolemText: "魔法；弱战力/狡诈。袭击：疲劳敏捷1+狡诈1，潜行退回原格并结算；胜：宝藏1。盒4骷髅：总和−2，感知1降级为白。",
			hWhisperText: "魔法；弱战力/感知。仅放三墙死路，实际进入才揭示。袭击：疲劳感知2；胜：1VP并获知未知格1。骷髅：每颗战力买的强力骰使总和−4。",
			hForgeText: "机械；弱战力/敏捷。袭击：疲劳战力2+任意1、目标永久+3；胜：2VP+宝藏1。骷髅：弃杂物2。",
			hPitText: "机械；盒3起弱狡诈/敏捷。袭击：疲劳2，就绪及积蓄优先。",
			hBlinkText: "魔法；盒3起弱狡诈/感知。袭击：疲劳感知1+变废为宝1，建造者传送你到任意空格。",
			hGremlingText: "自然；盒3起弱狡诈/变废为宝。袭击：疲劳任意1，弃杂物或宝藏1；无牌则再疲劳1。",
			hWallsText: "机械；弱狡诈/敏捷。仅放相对双墙走廊，实际进入才揭示。袭击：疲劳战力2。",
			hMantleText: "魔法；弱狡诈/变废为宝。袭击：疲劳狡诈1并激怒。状态随本人回合刷新：疲劳→已用→就绪→移除。",
			hSentryText: "机械；弱战力/敏捷。冲锋视为潜行。袭击：就绪优先疲劳2并退回原格；胜：宝藏1。盒4骷髅：每颗强力骰改为2。",
			hScreamerText: "魔法；弱战力/狡诈。袭击：疲劳感知1+狡诈1；胜：1VP。盒4骷髅：从已收录合法候选抽怪，由建造者置于未知空格。",
			hBanishText: "机械；盒3起弱狡诈/变废为宝。袭击：疲劳敏捷1，直接回起点。",
			hAcidText: "自然；盒3起弱狡诈/感知。袭击：疲劳任意1，宝藏1永久盖扣，只计1分。",
			jShield: "破碎盾牌",
			jShieldText: "怪物袭击时取消疲劳，其他效果照常。",
			jBread: "勉能果腹的面包",
			jBreadText: "2个已用块变为就绪。",
			jDiary: "莱尼的日记",
			jDiaryText: "定位最近未知出口或宝箱，不揭示种类；等距由建造者选。",
			jManual: "皱巴巴的陷阱组装手册",
			jManualText: "付任意1块，自动解除无墙相邻的已知陷阱。",
			jDagger: "破损匕首",
			jDaggerText: "战斗买骰前免费1基础骰。",
			jMirror: "裂镜",
			jMirrorText: "拆除买骰前免费1基础骰。",
			jCoffee: "咖啡黏块",
			jCoffeeText: "玩家骰后立即重掷选择的1颗骰。",
			jTracks: "神秘脚印",
			jTracksText: "定位最近未知怪物；等距由建造者选；隐身怪不能定位。",
			jScroll: "卷轴残片",
			jScrollText: "定位最近未知陷阱；等距由建造者选；隐身陷阱不能定位。",
			jCheese: "发霉奶酪",
			jCheeseText: "1个已用或疲劳块变为就绪。",
			jMap: "地图碎片",
			jMapText: "任选1未知格获知；隐身危险物不揭示。",
			jCandle: "残烛",
			jCandleText: "建造者选相邻2格告知。",
			jChalk: "仓促绘制的粉笔图",
			jChalkText: "建造者选3条未知墙，记入认知地图。",
			jWand: "炽热魔杖",
			jWandText: "玩家骰后总和增加或降低最多2点。",
			jRope: "一段绳索",
			jRopeText: "回退时视1已知部件格为空格，仍付敏捷。",
			jCloak: "霉臭斗篷",
			jCloakText: "进入已知怪物格时完全忽略该怪物。",
			jLantern: "将熄提灯",
			jLanternText: "支付1块并将该块换为感知。",
			jNotes: "他人笔记",
			jNotesText: "支付1块并将该块换为变废为宝。",
			jStrength: "残存力量药剂",
			jStrengthText: "支付1块并将该块换为战力。",
			jSpeed: "残存速度灵药",
			jSpeedText: "支付1块并将该块换为敏捷。",
			jPowder: "洒落黑火药",
			jPowderText: "支付1块并将该块换为狡诈。",
			jWeedkiller: "残存除草剂",
			jWeedkillerText: "自然危险物买骰前免费1强力骰。",
			jWrench: "生锈的旧扳手",
			jWrenchText: "机械危险物买骰前免费1强力骰。",
			jRune: "残缺的反魔符文",
			jRuneText: "魔法危险物买骰前免费1强力骰。",
			jBlanket: "破旧毯子",
			jBlanketText: "疲劳任意3块，新增1白块放入已用区。",
			jShovel: "碎裂的铲子",
			jShovelText: "开箱选公开宝藏前，弃全部展示牌并补满。",
			card322name: "风汐笛",
			card322bonus: "乐器；付变废为宝，将已知怪移到两格内已知空格，无视墙。",
			card323name: "安眠竖琴",
			card323bonus: "乐器；入已知怪格可付感知，将本次进入视为空格。",
			card324name: "速行鼓",
			card324bonus: "乐器；以敏捷支付的疾行可走5格。",
			card325name: "吟游锁链",
			card325bonus: "护符；每件明置乐器+5分。",
			apRules: "扩展按盒1～4累计启用；基础版默认不变。盒1为3白+敏捷+感知+变废为宝，盒2起造完迷宫后选3种不同属性+3白。弱点属性买强力骰(3/4/4/5/5/6)。搜寻空格付任意2或变废为宝1，按相邻内墙抽杂物留1，可免费潜行离开。杂物上限3，超限先弃。开箱暗抽可逐次付感知再抽，最后留1，再选公开宝藏1。开箱、胜怪、成功拆陷阱后，本回合可付变废为宝1抽杂物2，每部件一次。刷新疲劳块时可将其中1块换成任意允许属性。盒2起冲锋付任意2或战力1，已知怪检定免费强力骰1，未知怪免入格袭击。盒3起遁行对陷阱同理；空格付战力1恢复疲劳块1至已用；玩家骰后可逐次付狡诈追加基础骰。盒4战斗在玩家骰后掷两颗怪物骰，再结算一次骷髅能力与成败。陷阱每次拆除尝试后移除。危险物各自的目标、弱点、罚则及奖励见本局卡牌。",
			name: "请君入坑",
			desc: "建一座迷宫困住对手,再深入对手的地城夺宝脱身",
			rules: "目标:建造迷宫困住对手,同时探索对手的迷宫;总分更高者获胜。\n建造迷宫:\n· 双方各自建造一座 6 行 6 列的迷宫,使用 17 至 20 道墙。\n· 迷宫中放置起点、出口各 1 个,宝箱、陷阱、怪物各 3 个。\n· 所有格子必须能从起点到达。\n· 起点到出口与每个宝箱,都要有一条至多经过 1 只怪物和 1 个陷阱的路径。\n· 先提交迷宫的一方决定谁先探索。\n能量块:每人 6 块——4 块通用、1 块敏捷、1 块感知。\n· 敏捷与感知费用,也可用 2 块通用能量支付。\n回合:轮流探索;回合开始先恢复能量,再花费能量行动,次数不限。\n· 恢复规则:已用能量转为可用,疲劳能量转为已用。\n· 潜行(1 点任意能量):移动 1 格,未知格会被探明。\n· 疾行(2 点任意能量或 1 点敏捷):至多连续移动 3 格,进入有部件的格子时停下。\n· 窥视(2 点任意能量或 1 点感知):探明相邻的未知格,并可免费走入。\n· 回退(1 点敏捷):沿已知空格回到任意已知格。\n· 积蓄:将 1 至 3 块可用能量储存,下回合每块当 2 点使用;积蓄后立即结束回合。\n遭遇:危险格按是否已知结算。\n· 未知格入场先受袭击,之后可挑战、行动离开或结束回合。\n· 已知格入场免入格袭击,但必须立即检定。\n· 每 1 点能量购买 1 颗骰子;0 骰检定直接失败。\n· 检定后危险仍在,可再挑战、行动离开或结束回合。\n· 危险格不可原地积蓄;从危险格窥视离开后须走入目标格。\n· 点数合计达到目标值则成功;骰面为 1、2、2、3、3、4。\n· 怪物目标 6:未知入格和战斗失败时各使任意 2 块能量疲劳;战斗失败还会使目标值永久减去本次合计点数。\n· 陷阱目标 5:未知入格和拆除失败时各使 2 块可用能量疲劳;无论成败,陷阱都会移除。\n宝箱:到达后免费开启——暗抽牌库顶一张,再从三张公开宝藏牌中另选一张。\n出洞:完成 3 宝箱、3 怪物,或两者各 2 个后,走到出口格可出洞。\n· 先出洞获得 4 分,对手补最后一回合;后出洞获得 2 分。\n计分:收藏中至多 4 张宝藏明置全额计分,其余每张计 1 分。\n· 击败第 2、3 只怪物分别再获得 2 分、4 分;平分则先出洞者获胜。\n\n冒险者扩展（开局可选）:\n· 选择盒 1 至 4 的累计阶段，包含此前各盒与对应信封。\n· 盒 1、2 使用固定危险物；盒 3 起可随机、指定或双方轮选。\n· 双方共用三种怪物与三种陷阱，仍各自建造一座迷宫。\n· Box Zero 默认关闭；盒 3 起可将已收录危险物加入候选池。\n· 盒 1 起始为三块通用、敏捷、感知、变废为宝各一块。\n· 盒 2 起，建造后选择三种不同属性，并加入三块通用能量。\n· 搜寻未搜寻过的空格：支付任意两点或一点变废为宝。\n· 每相邻一道内墙抽一张杂物，保留一张，并可免费潜行离开。\n· 杂物上限三张；超限时必须先弃置，使用后进入弃牌堆。\n· 开箱暗抽后可逐次支付感知继续抽牌，最后留一张，再选一张公开宝藏。\n· 开箱、击败怪物、成功拆陷阱的同回合，可支付变废为宝抽两张杂物。\n· 此席卷行动每个部件只能使用一次。\n· 回合刷新疲劳块时，可将其中一块换成当前阶段允许的任意属性。\n· 盒 2 起，怪物弱点属性可购买强力骰：3、4、4、5、5、6。\n· 冲锋支付任意两点或一点战力；已知怪检定获一颗免费强力骰。\n· 冲锋进入未知怪格免入场袭击；盒 3 起遁行对陷阱同理，使用狡诈。\n· 盒 3 起陷阱也有弱点；空格支付战力可将一块疲劳块移至已用区。\n· 玩家骰后，可逐次支付狡诈追加一颗基础骰，再决定是否继续。\n· 盒 4 怪物骰每颗为空白两面、−1两面、−2一面、骷髅一面。\n· 双骷髅只触发一次能力；先结算骷髅效果，再判定成败。\n· 危险物目标与罚则以本局卡牌为准；陷阱每次拆除尝试后移除。\n· 当前使用实拍 34 张杂物与四张新宝藏，缺卡不入池；DD 尚未启用。\n· 尖啸怪暂从已收录、未使用且有合法未知空格摆位的怪物中抽取。",
			buildTitle: "筑造你的魔窟",
			pickFirstTitle: "决定先手",
			exploreTitle: "潜入对手魔窟",
			watchTitle: "守望你的魔窟",
			viewOwnTitle: "查看我的探索",
			viewRivalTitle: "查看对手探索",
			viewOwnHint: "你在对方地城的认知图与进度",
			viewRivalHint: "对手在你的地城的探索进度",
			handoffTitle: "探索交接",
			handoffFrom: "{{name}}的探索结束",
			handoffTo: "{{name}}即将进入",
			handoffScoring: "即将清点宝藏",
			handoffHolding: "本回合结束，交接中",
			encounterTitle: "地城遭遇",
			chestTitle: "宝箱开启",
			scoringTitle: "陈列宝藏",
			finishedTitle: "探宝结束",
			buildPrompt: "建造你的迷宫(对手将来探索它)",
			buildWaiting: "已提交,等待对手建完…",
			pickFirstPrompt: "你先建完,选择谁先探索",
			pickFirstWaiting: "等待 {{name}} 选择先手…",
			firstMe: "我先探索",
			firstOpp: "对手先探索",
			turnBanner: "轮到你探索",
			waitBanner: "{{name}} 正在你的迷宫里探索…",
			finalTurnBanner: "对手已出洞,这是你的最后一回合",
			scoringPrompt: "选择至多 4 张宝藏明置计分",
			scoringWaiting: "已提交,等待对手选择…",
			featStart: "起点",
			featExit: "出口",
			featChest: "宝箱",
			featTrap: "陷阱",
			featMonster: "怪物",
			featEmpty: "空格",
			wallNorth: "北",
			wallEast: "东",
			wallSouth: "南",
			wallWest: "西",
			wallNone: "无",
			wallMode: "墙",
			eraseMode: "擦除",
			randomMaze: "随机迷宫",
			submitMaze: "提交迷宫",
			wallsUsed: "墙 {{n}}/20",
			featLeft: "剩 {{n}}",
			selectCellHint: "点选格位，再按方向筑墙",
			selectedCell: "已选",
			inventoryTitle: "部件库存",
			inventoryFull: "部件已满，请先擦除一个",
			mazeReady: "迷宫合法，可以封存",
			mazeSealed: "迷宫已封存",
			actCreep: "潜行",
			actHustle: "疾行",
			actBacktrack: "回退",
			actPeer: "窥视",
			actFight: "战斗",
			actDisarm: "拆除",
			actConserve: "积蓄",
			actEndTurn: "结束回合",
			actExit: "出洞",
			actStop: "停下",
			hustleLeft: "疾行剩 {{n}} 步",
			chooseTreasure: "宝箱开启：选取 1 张宝藏牌",
			diceBuy: "买骰(当前 {{n}} 颗)",
			target: "目标 {{n}}",
			exitReady: "已满足出洞条件",
			exitReadyShort: "可出洞",
			exitProgress: "出洞",
			progressChests: "宝箱 {{n}}/3",
			progressMonsters: "怪物 {{n}}/3",
			progressHoard: "宝藏 {{n}}",
			routeChests: "开启 {{n}}/3 个宝箱即可出洞",
			routeMonsters: "击败 {{n}}/3 只怪物即可出洞",
			routeMixed: "开启 {{chests}}/2 个宝箱并击败 {{monsters}}/2 只怪物即可出洞",
			costAnyOne: "任意 1",
			costAny: "任意",
			costHustle: "2 或敏 1",
			costQuick: "敏捷 1",
			costPeer: "2 或感 1",
			waitingActions: "等待对手行动",
			secretDrawn: "已暗抽 1 张宝藏，只有你知道牌面",
			peerFreeHint: "已窥视该格：点高亮格免费走入",
			peerMustEnter: "已从危险格窥视离开，必须走入刚探明的格位",
			peerEnter: "走入探明格",
			forcedCheck: "已知危险格入场：必须立即检定，可选择 0 骰（直接失败）",
			zeroDiceCheck: "0 骰检定 · 直接失败",
			failFatigue: "失败会使 2 块能量疲劳",
			monsterEffect: "未知格入场：任意 2 块疲劳；战斗失败：再疲劳任意 2 块，怪物目标减去骰点；胜利：移除怪物。",
			trapEffect: "未知格入场：2 块可用能量疲劳；拆除失败：再疲劳 2 块可用能量；无论成败，陷阱都会移除。",
			monsterBrief: "每次受袭或战败：任意 2 块疲劳；战败还会降低目标",
			trapBrief: "每次受袭或拆除失败：2 块可用能量疲劳",
			startEffect: "探索从这里开始。",
			exitEffect: "满足出洞条件后，抵达这里即可出洞。",
			chestEffect: "到达后免费开启：暗抽 1 张宝藏牌，再从 3 张公开宝藏牌中选 1 张。",
			featureDetail: "地城物件详情",
			inspectFeatureAt: "查看{{cell}}的{{feature}}",
			closeFeatureDetail: "关闭物件详情",
			hazardLeave: "未知入格先受袭击；已知入格须立即检定。结算后可再挑战、行动离开或结束回合。",
			rollDice: "掷骰",
			backToActions: "返回行动",
			payPicked: "已选 {{n}}/{{m}} 档",
			payConservedHint: "积蓄块点两下 = 连花两档",
			payConfirm: "确认支付",
			fatigueTitle: "选择疲劳的能量块({{n}} 块)",
			fatigueTrapNote: "陷阱袭击:只能从可用/积蓄中选,不够才动用已用块",
			fatigueConfirm: "确认疲劳",
			confirmConserve: "确认积蓄",
			conserveHint: "存1–3块，下回合×2",
			viewExploration: "查看{{name}}的探索",
			observePosition: "{{name}}位于{{cell}} · 已探明{{n}}/36格",
			observeMoving: "继续探索中",
			observeWaiting: "等待下次行动",
			observeMonster: "位于怪物格 · 目标 {{n}}",
			observeTrap: "位于陷阱格 · 目标 {{n}}",
			observeExit: "已抵达出口",
			observeChest: "宝箱已开启，等待选牌",
			observeFatigue: "遭受袭击，正在选择疲劳块",
			observeEscaped: "已经出洞",
			actionHistory: "行动记录",
			openHistory: "打开行动记录",
			closeHistory: "关闭行动记录",
			stepExit: "{{name}}成功出洞",
			stepMonsterWin: "{{name}}在{{cell}}击败怪物，格位变空",
			stepMonsterFail: "{{name}}在{{cell}}战斗失败：任意 2 块疲劳，怪物目标降至 {{target}}",
			stepMonsterZero: "{{name}}在{{cell}}用 0 骰战斗，直接失败：任意 2 块疲劳，怪物目标仍为 {{target}}",
			stepTrapWin: "{{name}}在{{cell}}成功拆除陷阱，格位变空",
			stepTrapFail: "{{name}}在{{cell}}拆除失败：2 块可用能量疲劳，陷阱仍移除",
			stepTrapZero: "{{name}}在{{cell}}用 0 骰拆除，直接失败：2 块可用能量疲劳，陷阱仍移除",
			stepChest: "{{name}}在{{cell}}打开宝箱",
			stepTreasure: "{{name}}选取了一张宝藏牌",
			stepMonsterFound: "{{name}}在{{cell}}闯入未知怪物格：受袭，任意 2 块疲劳",
			stepTrapFound: "{{name}}在{{cell}}闯入未知陷阱格：受袭，2 块可用能量疲劳",
			stepMonsterKnown: "{{name}}进入{{cell}}已知怪物格：免入格袭击，必须立即战斗",
			stepTrapKnown: "{{name}}进入{{cell}}已知陷阱格：免入格袭击，必须立即拆除",
			stepBacktrack: "{{name}}回退至{{cell}}",
			stepHustleMove: "{{name}}疾行至{{cell}}",
			stepMove: "{{name}}移动至{{cell}}",
			stepPeer: "{{name}}窥视{{cell}}：{{feature}}；墙：{{walls}}",
			stepConserve: "{{name}}积蓄了{{n}}块能量",
			stepHustle: "{{name}}开始疾行",
			stepStop: "{{name}}停下疾行",
			stepEndTurn: "{{name}}结束回合",
			fresh: "可用",
			energyTitle: "能量块",
			spent: "已用",
			fatigued: "疲劳",
			conserved: "积蓄",
			cubeQuick: "敏捷",
			cubePerc: "感知",
			cubeWhite: "通用",
			hoardTitle: "收藏({{n}})",
			treasureOfferTitle: "宝藏牌",
			peekTreasure: "查看宝藏牌",
			closeTreasure: "收起宝藏牌",
			deckLabel: "牌库 {{n}}",
			revealHint: "已选 {{n}}/4",
			revealSubmit: "确认明置",
			tuckedNote: "未明置的卡各计 1 分",
			breakTreasures: "宝藏",
			breakMonsters: "怪物",
			breakExit: "出洞",
			breakTotal: "总分",
			firstOut: "先出洞",
			errPhase: "现在不能这么做",
			errNoCubes: "可用能量块不足",
			errWall: "那个方向有墙",
			errBadCell: "无法回退到该格",
			errPeerKnown: "该格已知,无需窥视",
			errNotHazard: "此处没有对应遭遇",
			errNotExit: "你不在出口格",
			errExitNotQualified: "尚未满足出洞条件(3 宝箱 / 3 怪物 / 2 宝箱加 2 怪物)",
			errConserveFull: "积蓄槽已满(至多 3 块)",
			errBusy: "请先完成当前结算",
			errBadCard: "无效的卡牌选择",
			errBadPay: "支付选择无效",
			errBadReveal: "明置选择无效",
			errFeatureCount: "需要恰好 3 宝箱、3 陷阱、3 怪物",
			errFeatureCell: "部件位置无效",
			errFeatureOverlap: "部件不能放在同一格",
			errWallCount: "必须使用 17-20 道墙",
			errWallDup: "墙重复了",
			errWallIdx: "墙位置无效",
			errNotConnected: "所有格子必须从起点可达",
			errPeril: "起点到出口/每个宝箱须有一条路径,其上怪物与陷阱至多各 1 个",
			typeBook: "书籍",
			typeStatue: "雕像",
			typeScroll: "卷轴",
			typeAmulet: "护符",
			typeCup: "圣杯",
			typeShard: "碎片",
			typeCrown: "王冠",
			typeOrb: "宝珠",
			kwHarmony: "和谐",
			kwDiscord: "纷争",
			card300name: "日光碎片",
			card300bonus: "每有一张其他不同名的碎片,+2 分",
			card301name: "英雄之冠",
			card301bonus: "若你最先出洞,+4 分",
			card302name: "静谧圣杯",
			card302bonus: "若另有其他圣杯,+4 分",
			card303name: "勇士护符",
			card303bonus: "每击败 1 只怪物,+1 分",
			card304name: "月光碎片",
			card304bonus: "每有一张其他不同名的碎片,+2 分",
			card305name: "神圣典籍",
			card305bonus: "若另有其他书籍,+3 分",
			card306name: "鲜血圣杯",
			card306bonus: "每击败 1 只怪物,+2 分",
			card307name: "诅咒护符",
			card307bonus: "若另有其他护符,+4 分",
			card308name: "水晶宝珠",
			card308bonus: "若另有其他宝珠,+4 分",
			card309name: "暗影宝珠",
			card309bonus: "若另有其他宝珠,+3 分",
			card310name: "星光碎片",
			card310bonus: "每有一张其他不同名的碎片,+2 分",
			card311name: "秘闻之书",
			card311bonus: "若另有其他书籍,+4 分",
			card312name: "窃贼护符",
			card312bonus: "每开启 1 个宝箱,+1 分",
			card313name: "猎人图鉴",
			card313bonus: "若击败至少 2 只怪物,+2 分",
			card314name: "制图师卷轴",
			card314bonus: "若地图没有未知格,+3 分",
			card315name: "真理卷轴",
			card315bonus: "若没有纷争藏品,+3 分",
			card316name: "洞察宝珠",
			card316bonus: "每拆除 1 个陷阱,+1 分",
			card317name: "林间行者头冠",
			card317bonus: "若另有其他王冠,+1 分;若地图无未知格,+3 分",
			card318name: "恶魔雕像",
			card318bonus: "每有一张其他雕像,+1 分",
			card319name: "和谐卷轴",
			card319bonus: "每个和谐藏品 +2 分(自身不算和谐)",
			card320name: "纷争神像",
			card320bonus: "每个纷争藏品 +2 分(含自身)",
			card321name: "国王之冠",
			card321bonus: "每有一张其他王冠,+1 分"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			optMode: "Mode",
			modeBase: "Base game",
			modeAdventure: "Adventurer’s Pack",
			optStage: "Cumulative stage",
			stage1: "Box 1 + A/B",
			stage2: "Box 2 + C/D",
			stage3: "Box 3 + E/F",
			stage4: "Box 4 · Monster dice",
			optSelection: "Hazard selection",
			selectRandom: "Random",
			selectManual: "Choose",
			selectDraft: "Alternate picks",
			optZero: "Box Zero",
			zeroHint: "From Box 3, add the 4 recorded hazards to the pool",
			stageHint: "Stages include all earlier content. Boxes 1/2 use preset hazards. Two players, 6×6.",
			compatibility: "34 Junk cards and 4 new Treasures are recorded. Missing cards are excluded. Screamer draws a recorded Monster with a legal placement.",
			monsterDiceRule: "Each of the two dice: 2 blanks, 2 −1, 1 −2, 1 Skull. Two Skulls trigger the ability once.",
			cubeKnow: "Know-how",
			cubeBrawn: "Brawn",
			cubeGuile: "Guile",
			apDraft: "Choose shared hazards",
			apAttributes: "Choose 3 different attributes",
			apStage: "Adventure · Box {{n}}",
			apWait: "Waiting for {{name}}",
			apConfirm: "Confirm",
			apSkip: "Skip / Finish",
			apContinue: "Spend Perception to draw 1",
			apPool: "This game’s hazards",
			apJunk: "Junk",
			apHoard: "Hoard",
			apClose: "Close",
			apInfo: "Cards & rules",
			apPay: "Select cubes for payment, or leave blank for automatic payment",
			apAutoPay: "Auto pay",
			apDouble: "Conserved: tap again to spend twice",
			apReady: "Fresh",
			apSpent: "Spent",
			apFatigued: "Fatigued",
			apConserved: "Conserved",
			apFree: "Free Creep available",
			apCharge: "Charge",
			apSneak: "Sneak",
			apScrounge: "Scrounge",
			apScavenge: "Scavenge",
			apRecover: "Recover",
			apImprovise: "Improvise",
			apFinishCheck: "Finish explorer roll",
			apRoll: "Buy & roll {{n}} dice",
			apDice: "Basic / Power dice",
			apTotal: "Total {{n}} / Target {{target}}",
			apMonsterDice: "Monster dice",
			apSkull: "Skull",
			apBlank: "Blank",
			apCheckWait: "Resolving check…",
			apSearched: "Searched: {{cells}}",
			apLocated: "Located: {{cells}}",
			apEnraging: "Enraging: entering a Monster permanently adds 3 to its Target",
			apForcedTucked: "Acid-tucked · 1 VP only",
			apFlute: "Windtide Flute: choose a Monster, then an Empty cell within 2",
			apTarget: "Choose a target cell",
			apUse: "Use",
			apDiscard: "Discard",
			apChoiceCount: "Selected {{n}} / {{max}}",
			apBuilderMap: "Your complete maze",
			apExplorerMap: "Your known map",
			apViewSwitch: "Switch map",
			apBeforeDice: "Free dice before purchase",
			apAfterDice: "After rolling: reroll or adjust total",
			apJunkTarget: "Choose card target",
			apCoffee: "Reroll die {{n}}",
			apWandPlus: "Total +2",
			apWandMinus: "Total −2",
			apWandDelta: "Total {{n}}",
			apCostPeer: "2 / Perc 1",
			apCostCharge: "2 / Brawn 1",
			apCostSneak: "2 / Guile 1",
			apCostScrounge: "2 / Know-how 1",
			apCostKnow: "Know-how 1",
			apCostBrawn: "Brawn 1",
			apBuy: "Number of dice",
			apUseRope: "Choose a feature to ignore, then your Backtrack destination",
			apNextHazard: "Place in listed order: {{name}}",
			apCellHazard: "{{cell}}: {{name}}",
			errHazardPlacement: "Whisperling needs a 3-wall dead end; Crushing Walls need opposite walls",
			taskAdapt: "Refresh: swap one recovered cube",
			taskFatigue: "Choose cubes to fatigue",
			taskDiscardJunk: "Discard Junk before continuing",
			taskDiscardTreasure: "Discard a Treasure",
			taskDiscardEither: "Discard a Junk or Treasure",
			taskTuck: "Permanently tuck a Treasure",
			taskDowngrade: "Downgrade an attribute cube to Basic",
			taskRefresh: "Choose cubes to make Fresh",
			taskExchange: "Choose a cube to spend and swap",
			taskRecover: "Move a Fatigued cube to Spent",
			taskBlanket: "Fatigue 3 cubes; add 1 Basic cube to Spent",
			taskLearn: "Choose cells to reveal",
			taskLocate: "Builder: choose the nearest location",
			taskWalls: "Builder: choose unknown walls",
			taskScrounge: "Scrounge: keep 1 Junk",
			taskAppraise: "Hidden draw: spend Perception to draw again",
			taskAppraiseKeep: "Hidden draw: keep 1 Treasure",
			taskShovel: "Use the Cracked Shovel to refresh the display?",
			taskTeleport: "Choose teleport destination",
			taskReturn: "Creep back to the previous cell and resolve it",
			taskSpawn: "Screamer: place the drawn Monster",
			taskShield: "Use the Broken Shield to cancel this Monster Strike’s fatigue?",
			taskIgnore: "Ignore the Monster on this entry?",
			taskRope: "Choose Backtrack route",
			hBlob: "Hungry Blob",
			hTangle: "Tanglethorn",
			hAutoflail: "Autoflail",
			hGolem: "Furniture Golem",
			hWhisper: "Whisperling Mob",
			hForge: "Forge Hulk",
			hPit: "Greased Pit",
			hBlink: "Blink Runes",
			hGremling: "Gremling Swarm",
			hWalls: "Crushing Walls",
			hMantle: "Maddening Mantle",
			hSentry: "Steam Sentry",
			hScreamer: "Screamer",
			hBanish: "Banish Box",
			hAcid: "Acid Pool",
			hBlobText: "Nature; from Box 2 weak to Brawn/Quickness. Box 1 Strike: fatigue 2 any, no extra win reward. From Box 2: fatigue 1 Quickness + 1 any; win 1 Junk. Box 4 Skull: if total ≥ Target+2, no damage and Target becomes the total.",
			hTangleText: "Nature; weak to Brawn/Perception. Strike: fatigue 1 any, discard 2 Junk. Win: 1 Junk. Box 4 Skull: −2 total; discard 1 Treasure if it survives.",
			hAutoflailText: "Machine; weak to Brawn/Know-how. Boxes 2/3 Strike: fatigue 1 Know-how + 1 Brawn; Box 4 replaces Know-how with Quickness. Win: 1 Junk. Box 4 Skull: downgrade 1 Know-how to Basic.",
			hGolemText: "Magic; weak to Brawn/Guile. Strike: fatigue 1 Quickness + 1 Guile; Creep back and resolve the previous cell. Win: 1 Treasure. Box 4 Skull: −2 total and downgrade 1 Perception.",
			hWhisperText: "Magic; weak to Brawn/Perception. Place in a 3-wall dead end; reveal only on entry. Strike: fatigue 2 Perception. Win: 1 VP + reveal 1 unknown cell. Skull: −4 per Power die bought with Brawn.",
			hForgeText: "Machine; weak to Brawn/Quickness. Strike: fatigue 2 Brawn + 1 any, permanently add 3 to Target. Win: 2 VP + 1 Treasure. Skull: discard 2 Junk.",
			hPitText: "Machine; from Box 3 weak to Guile/Quickness. Strike: fatigue 2, Fresh/Conserved first.",
			hBlinkText: "Magic; from Box 3 weak to Guile/Perception. Strike: fatigue 1 Perception + 1 Know-how; Builder teleports you to an Empty cell.",
			hGremlingText: "Nature; from Box 3 weak to Guile/Know-how. Strike: fatigue 1 any, discard 1 Junk or Treasure; if no cards, fatigue 1 more.",
			hWallsText: "Machine; weak to Guile/Quickness. Place between exactly 2 opposite walls; reveal only on entry. Strike: fatigue 2 Brawn.",
			hMantleText: "Magic; weak to Guile/Know-how. Strike: fatigue 1 Guile and gain Enraging. Status refreshes Fatigued → Spent → Fresh → removed.",
			hSentryText: "Machine; weak to Brawn/Quickness. Charge counts as Creep. Strike: fatigue 2, Fresh first, and return to the previous cell. Win: 1 Treasure. Box 4 Skull: every Power die becomes 2.",
			hScreamerText: "Magic; weak to Brawn/Guile. Strike: fatigue 1 Perception + 1 Guile. Win: 1 VP. Box 4 Skull: Builder places a random recorded, eligible Monster in an unknown Empty cell.",
			hBanishText: "Machine; from Box 3 weak to Guile/Know-how. Strike: fatigue 1 Quickness and return directly to Start.",
			hAcidText: "Nature; from Box 3 weak to Guile/Perception. Strike: fatigue 1 any; permanently tuck 1 Treasure for only 1 VP.",
			jShield: "Broken Shield",
			jShieldText: "Cancel fatigue from a Monster Strike; other effects still occur.",
			jBread: "Barely Edible Bread",
			jBreadText: "Make 2 Spent cubes Fresh.",
			jDiary: "Lenny’s Diary",
			jDiaryText: "Locate the nearest unknown Exit or Chest, without its type. Builder breaks ties.",
			jManual: "Crumpled Trap Manual",
			jManualText: "Spend 1 any cube to disarm an adjacent known Trap with no wall between.",
			jDagger: "Broken Dagger",
			jDaggerText: "Gain 1 free Basic die before buying fight dice.",
			jMirror: "Cracked Mirror",
			jMirrorText: "Gain 1 free Basic die before buying disarm dice.",
			jCoffee: "Coffee Clump",
			jCoffeeText: "Immediately reroll 1 selected explorer die.",
			jTracks: "Mysterious Footprints",
			jTracksText: "Locate the nearest unknown Monster; Builder breaks ties. Invisible Monsters cannot be located.",
			jScroll: "Scroll Fragment",
			jScrollText: "Locate the nearest unknown Trap; Builder breaks ties. Invisible Traps cannot be located.",
			jCheese: "Mouldy Cheese",
			jCheeseText: "Make 1 Spent or Fatigued cube Fresh.",
			jMap: "Map Fragment",
			jMapText: "Reveal 1 unknown cell; invisible hazards remain concealed.",
			jCandle: "Candle Stub",
			jCandleText: "Builder reveals 2 chosen adjacent cells.",
			jChalk: "Hastily Chalked Map",
			jChalkText: "Builder records 3 unknown walls on your map.",
			jWand: "Hot Wand",
			jWandText: "After explorer dice, add or subtract up to 2 from the total.",
			jRope: "Length of Rope",
			jRopeText: "Treat 1 known feature as Empty when Backtracking; pay Quickness as usual.",
			jCloak: "Musty Cloak",
			jCloakText: "Ignore a known Monster when entering its cell.",
			jLantern: "Fading Lantern",
			jLanternText: "Spend 1 cube and swap that cube for Perception.",
			jNotes: "Someone Else’s Notes",
			jNotesText: "Spend 1 cube and swap it for Know-how.",
			jStrength: "Strength Potion Dregs",
			jStrengthText: "Spend 1 cube and swap it for Brawn.",
			jSpeed: "Speed Elixir Dregs",
			jSpeedText: "Spend 1 cube and swap it for Quickness.",
			jPowder: "Spilled Gunpowder",
			jPowderText: "Spend 1 cube and swap it for Guile.",
			jWeedkiller: "Leftover Weedkiller",
			jWeedkillerText: "Gain 1 free Power die before a Nature check.",
			jWrench: "Rusty Wrench",
			jWrenchText: "Gain 1 free Power die before a Machine check.",
			jRune: "Partial Anti-magic Rune",
			jRuneText: "Gain 1 free Power die before a Magic check.",
			jBlanket: "Ragged Blanket",
			jBlanketText: "Fatigue any 3 cubes; add 1 Basic cube to Spent.",
			jShovel: "Cracked Shovel",
			jShovelText: "Before taking a displayed Chest Treasure, discard and refill the display.",
			card322name: "Windtide Flute",
			card322bonus: "Instrument. Spend Know-how to move a known Monster to a known Empty cell within 2, ignoring walls.",
			card323name: "Lullaby Harp",
			card323bonus: "Instrument. Spend Perception on entering a known Monster to treat this entry as Empty.",
			card324name: "Quickstep Drum",
			card324bonus: "Instrument. Hustle paid with Quickness allows up to 5 steps.",
			card325name: "Bard’s Chain",
			card325bonus: "Amulet. +5 VP per revealed Instrument.",
			apRules: "Boxes 1–4 include earlier content. Box 1 starts with 3 Basic + Quickness + Perception + Know-how. From Box 2 choose 3 distinct attributes after building, plus 3 Basic. A weakness cube buys a Power die (3/4/4/5/5/6). Scrounge an unsearched Empty cell for 2 any or 1 Know-how: draw Junk per adjacent inner wall, keep 1, and optionally Creep free. Junk limit 3; discard excess first. Appraise a hidden Chest draw by spending Perception to draw again; keep 1, then take 1 displayed Treasure. After opening a Chest, defeating a Monster or disarming a Trap, spend Know-how to draw 2 Junk, once per feature that turn. When Fatigued cubes refresh, swap 1 for any available attribute. From Box 2 Charge for 2 any or 1 Brawn: free Power die against a known Monster, no entry Strike against an unknown one. From Box 3 Sneak does the same for Traps; Recover in an Empty cell for 1 Brawn to move 1 Fatigued cube to Spent; after rolling spend Guile repeatedly for extra Basic dice. Box 4 fights roll two Monster dice after explorer dice, then resolve a single Skull ability and the result. Traps are removed after any disarm attempt. See each hazard card for Targets, weaknesses, Strikes and rewards.",
			name: "Lairs",
			desc: "Build a maze to trap your rival, then delve theirs for treasure and escape",
			rules: "Goal: build a maze to trap your rival while you explore theirs; the higher total wins.\nBuild:\n· Each player secretly builds a 6×6 maze with 17-20 walls.\n· Place 1 Start, 1 Exit, 3 chests, 3 traps and 3 monsters.\n· Every cell must be reachable from the Start.\n· From the Start to the Exit and to each chest, some path must pass at most 1 monster and 1 trap.\n· Whoever submits first decides who explores first.\nEnergy: 6 cubes each — 4 wild, 1 Quickness, 1 Perception.\n· A Quickness or Perception cost may also be paid with 2 wild cubes.\nTurn: take turns exploring; refresh energy, then take any number of actions.\n· Refreshing: spent cubes become ready; fatigued cubes become spent.\n· Creep (1 any): move 1 cell; unknown cells are revealed.\n· Hustle (2 any or 1 Quickness): up to 3 cells; stop upon entering a feature cell.\n· Peer (2 any or 1 Perception): reveal an adjacent unknown cell and may step in free.\n· Backtrack (1 Quickness): move through known empty cells to any known cell.\n· Conserve: store 1-3 ready cubes; each is worth 2 energy next turn; ends your turn.\nHazards: checks depend on whether the cell was known.\n· Unknown entry strikes first; then challenge, move away or end your turn.\n· Known entry avoids the strike but requires an immediate check.\n· Buy 1 die per energy; a check with 0 dice fails.\n· If the hazard remains, challenge again, move away or end your turn.\n· You cannot conserve on a hazard; peering away commits you to entering the revealed cell.\n· Succeed when the total meets the target; dice faces are 1, 2, 2, 3, 3, 4.\n· Monster target 6: unknown entry and a failed fight each fatigue any 2 cubes; failure also lowers the target by the rolled total.\n· Trap target 5: unknown entry and a failed disarm each fatigue 2 fresh cubes; the trap is removed either way.\nChests: free to open — draw the top card face down, then take 1 of the 3 face-up treasures.\nEscape: after 3 chests, 3 monsters, or 2 of each, reach the Exit to escape.\n· First out scores 4 and the rival takes one last turn; second out scores 2.\nScoring: reveal up to 4 hoard cards for full value; the rest score 1 each.\n· Your 2nd and 3rd slain monsters score 2 and 4 more; ties go to the first escapee.\n\nAdventurer expansion (optional at setup):\n· Choose cumulative Box 1–4, including earlier boxes and envelopes.\n· Boxes 1–2 have fixed hazards; from Box 3, randomize, specify or draft.\n· Share three Monster and three Trap types, but build separate mazes.\n· Box Zero is off by default; from Box 3 it adds recorded hazards to the pool.\n· Box 1 starts with three Basic, one Quickness, one Perception and one Know-how.\n· From Box 2 choose three distinct attributes after building, plus three Basic.\n· Scrounge an unsearched Empty cell for two any energy or one Know-how.\n· Draw one Junk per adjacent inner wall, keep one, and optionally Creep free.\n· Hold at most three Junk; discard excess before using cards, then discard used cards.\n· On a hidden Chest draw, pay Perception repeatedly to draw again; keep one, then take one displayed Treasure.\n· In the turn you open a Chest, defeat a Monster or disarm a Trap, pay Know-how to draw two Junk.\n· This Scavenge action may be used once per feature.\n· When Fatigued cubes refresh, swap one for any attribute allowed by this stage.\n· From Box 2, Monster weakness attributes buy Power dice: 3, 4, 4, 5, 5, 6.\n· Charge costs two any or one Brawn; gain one free Power die against a known Monster.\n· Charge avoids an unknown Monster’s entry Strike; from Box 3 Sneak does the same for Traps using Guile.\n· From Box 3 Traps have weaknesses; pay Brawn in an Empty cell to move one Fatigued cube to Spent.\n· After explorer dice, pay Guile repeatedly for one extra Basic die, deciding each time.\n· Box 4 fights then roll two Monster dice: each has two blanks, two −1, one −2 and one Skull.\n· Two Skulls trigger once; resolve the Skull ability before judging success.\n· See the current hazard cards for Targets and Strikes; remove Traps after any disarm attempt.\n· Uses 34 photographed Junk and four new Treasures; missing cards are excluded; DD is unavailable.\n· Screamer draws from recorded, unused Monsters with a legal unknown Empty placement.",
			buildTitle: "Forge your lair",
			pickFirstTitle: "Choose first explorer",
			exploreTitle: "Enter your rival’s lair",
			watchTitle: "Guard your lair",
			viewOwnTitle: "View your exploration",
			viewRivalTitle: "View rival's exploration",
			viewOwnHint: "Your known map and progress in the rival lair",
			viewRivalHint: "Rival progress inside your lair",
			handoffTitle: "Passing the torch",
			handoffFrom: "{{name}}'s exploration ended",
			handoffTo: "{{name}} enters next",
			handoffScoring: "Treasure scoring is next",
			handoffHolding: "Turn ended · passing control",
			encounterTitle: "Dungeon encounter",
			chestTitle: "Chest opened",
			scoringTitle: "Display your treasures",
			finishedTitle: "Expedition ended",
			buildPrompt: "Build your maze (your rival will explore it)",
			buildWaiting: "Submitted. Waiting for your rival…",
			pickFirstPrompt: "You finished first — choose who explores first",
			pickFirstWaiting: "Waiting for {{name}} to choose first explorer…",
			firstMe: "Me first",
			firstOpp: "Rival first",
			turnBanner: "Your turn to explore",
			waitBanner: "{{name}} is exploring your maze…",
			finalTurnBanner: "Your rival escaped — this is your last turn",
			scoringPrompt: "Choose up to 4 treasures to reveal for scoring",
			scoringWaiting: "Submitted. Waiting for your rival…",
			featStart: "Start",
			featExit: "Exit",
			featChest: "Chest",
			featTrap: "Trap",
			featMonster: "Monster",
			featEmpty: "Empty",
			wallNorth: "N",
			wallEast: "E",
			wallSouth: "S",
			wallWest: "W",
			wallNone: "none",
			wallMode: "Wall",
			eraseMode: "Erase",
			randomMaze: "Random maze",
			submitMaze: "Submit maze",
			wallsUsed: "Walls {{n}}/20",
			featLeft: "{{n}} left",
			selectCellHint: "Select a cell, then a wall direction",
			selectedCell: "Selected",
			inventoryTitle: "Feature supply",
			inventoryFull: "Supply full — erase one first",
			mazeReady: "Maze valid — ready to seal",
			mazeSealed: "Maze sealed",
			actCreep: "Creep",
			actHustle: "Hustle",
			actBacktrack: "Backtrack",
			actPeer: "Peer",
			actFight: "Fight",
			actDisarm: "Disarm",
			actConserve: "Conserve",
			actEndTurn: "End turn",
			actExit: "Escape",
			actStop: "Stop",
			hustleLeft: "Hustle: {{n}} steps left",
			chooseTreasure: "Chest opened: choose 1 treasure card",
			diceBuy: "Buy dice (now {{n}})",
			target: "Target {{n}}",
			exitReady: "Escape condition met",
			exitReadyShort: "Can escape",
			exitProgress: "Escape",
			progressChests: "Chests {{n}}/3",
			progressMonsters: "Monsters {{n}}/3",
			progressHoard: "Treasure {{n}}",
			routeChests: "{{n}}/3 chests opened to escape",
			routeMonsters: "{{n}}/3 monsters defeated to escape",
			routeMixed: "{{chests}}/2 chests and {{monsters}}/2 monsters to escape",
			costAnyOne: "Any 1",
			costAny: "Any",
			costHustle: "2 or Quick 1",
			costQuick: "Quick 1",
			costPeer: "2 or Perception 1",
			waitingActions: "Waiting for rival",
			secretDrawn: "1 treasure drawn face down into your private hoard",
			peerFreeHint: "Peeked: tap the highlighted cell to step in for free",
			peerMustEnter: "You peered away from a hazard: enter the revealed cell now",
			peerEnter: "Enter revealed cell",
			forcedCheck: "Known hazard entry: check now. You may use 0 dice and fail.",
			zeroDiceCheck: "0-die check · automatic failure",
			failFatigue: "Failure fatigues 2 cubes",
			monsterEffect: "Unknown entry: fatigue any 2 cubes. Failed fight: fatigue 2 more and lower its target by the roll. Win: remove the monster.",
			trapEffect: "Unknown entry: fatigue 2 fresh cubes. Failed disarm: fatigue 2 more fresh cubes. Remove the trap either way.",
			monsterBrief: "Each strike or loss: fatigue any 2 cubes; a loss lowers its target",
			trapBrief: "Each strike or failed disarm: fatigue 2 fresh cubes",
			startEffect: "Your exploration begins here.",
			exitEffect: "After meeting an escape condition, reach this cell to leave the dungeon.",
			chestEffect: "Open for free on arrival: draw 1 treasure face down, then take 1 of the 3 face-up treasures.",
			featureDetail: "Dungeon feature details",
			inspectFeatureAt: "Inspect {{feature}} at {{cell}}",
			closeFeatureDetail: "Close feature details",
			hazardLeave: "Unknown entry strikes first; known entry requires a check. Afterward, challenge again, move away or end your turn.",
			rollDice: "Roll",
			backToActions: "Back to actions",
			payPicked: "{{n}}/{{m}} charges picked",
			payConservedHint: "Tap a conserved cube twice to spend both charges",
			payConfirm: "Pay",
			fatigueTitle: "Choose cubes to fatigue ({{n}})",
			fatigueTrapNote: "Trap strike: pick from fresh/conserved first; spent only if short",
			fatigueConfirm: "Fatigue",
			confirmConserve: "Store cubes",
			conserveHint: "Store 1–3 · ×2 next turn",
			viewExploration: "View {{name}}'s exploration",
			observePosition: "{{name}} at {{cell}} · {{n}}/36 cells explored",
			observeMoving: "Still exploring",
			observeWaiting: "Waiting for the next turn",
			observeMonster: "On a monster cell · target {{n}}",
			observeTrap: "On a trap cell · target {{n}}",
			observeExit: "At the exit",
			observeChest: "Chest opened · choosing treasure",
			observeFatigue: "Struck · choosing cubes to fatigue",
			observeEscaped: "Escaped the dungeon",
			actionHistory: "Action history",
			openHistory: "Open action history",
			closeHistory: "Close action history",
			stepExit: "{{name}} escaped the dungeon",
			stepMonsterWin: "{{name}} defeated the monster at {{cell}}; the cell is empty",
			stepMonsterFail: "{{name}} lost at {{cell}}: fatigue any 2 cubes; monster target is now {{target}}",
			stepMonsterZero: "{{name}} fought at {{cell}} with 0 dice and failed: fatigue any 2 cubes; target stays at {{target}}",
			stepTrapWin: "{{name}} disarmed the trap at {{cell}}; the cell is empty",
			stepTrapFail: "{{name}} failed at {{cell}}: fatigue 2 fresh cubes; the trap is removed",
			stepTrapZero: "{{name}} checked the trap at {{cell}} with 0 dice and failed: fatigue 2 fresh cubes; trap removed",
			stepChest: "{{name}} opened a chest at {{cell}}",
			stepTreasure: "{{name}} took a treasure card",
			stepMonsterFound: "{{name}} entered unknown {{cell}}: monster strike, fatigue any 2 cubes",
			stepTrapFound: "{{name}} entered unknown {{cell}}: trap strike, fatigue 2 fresh cubes",
			stepMonsterKnown: "{{name}} entered known monster cell {{cell}}: no entry strike; fight now",
			stepTrapKnown: "{{name}} entered known trap cell {{cell}}: no entry strike; disarm now",
			stepBacktrack: "{{name}} backtracked to {{cell}}",
			stepHustleMove: "{{name}} hustled to {{cell}}",
			stepMove: "{{name}} moved to {{cell}}",
			stepPeer: "{{name}} peered into {{cell}}: {{feature}}; walls: {{walls}}",
			stepConserve: "{{name}} conserved {{n}} energy cubes",
			stepHustle: "{{name}} started hustling",
			stepStop: "{{name}} stopped hustling",
			stepEndTurn: "{{name}} ended their turn",
			fresh: "Ready",
			energyTitle: "Energy cubes",
			spent: "Spent",
			fatigued: "Fatigued",
			conserved: "Conserved",
			cubeQuick: "Quickness",
			cubePerc: "Perception",
			cubeWhite: "White",
			hoardTitle: "Hoard ({{n}})",
			treasureOfferTitle: "Treasures",
			peekTreasure: "View treasure cards",
			closeTreasure: "Close treasure cards",
			deckLabel: "Deck {{n}}",
			revealHint: "Chosen {{n}}/4",
			revealSubmit: "Confirm reveal",
			tuckedNote: "Unrevealed cards score 1 each",
			breakTreasures: "Treasures",
			breakMonsters: "Monsters",
			breakExit: "Escape",
			breakTotal: "Total",
			firstOut: "First out",
			errPhase: "Not allowed right now",
			errNoCubes: "Not enough ready cubes",
			errWall: "A wall blocks that way",
			errBadCell: "Cannot backtrack there",
			errPeerKnown: "That cell is already known",
			errNotHazard: "No such encounter here",
			errNotExit: "You are not on the Exit",
			errExitNotQualified: "Escape not unlocked (3 chests / 3 monsters / 2 chests + 2 monsters)",
			errConserveFull: "Conserved slots full (max 3)",
			errBusy: "Finish the current resolution first",
			errBadCard: "Invalid card choice",
			errBadPay: "Invalid payment",
			errBadReveal: "Invalid reveal selection",
			errFeatureCount: "Need exactly 3 chests, 3 traps and 3 monsters",
			errFeatureCell: "Invalid feature cell",
			errFeatureOverlap: "Features cannot share a cell",
			errWallCount: "Must use 17-20 walls",
			errWallDup: "Duplicate wall",
			errWallIdx: "Invalid wall position",
			errNotConnected: "All cells must be reachable from Start",
			errPeril: "Each Start→Exit/chest path may pass at most 1 monster and 1 trap",
			typeBook: "Book",
			typeStatue: "Statue",
			typeScroll: "Scroll",
			typeAmulet: "Amulet",
			typeCup: "Cup",
			typeShard: "Shard",
			typeCrown: "Crown",
			typeOrb: "Orb",
			kwHarmony: "Harmony",
			kwDiscord: "Discord",
			card300name: "Sun Shard",
			card300bonus: "+2 per other differently-named Shard",
			card301name: "Hero's Crown",
			card301bonus: "+4 if you escaped first",
			card302name: "Tranquil Goblet",
			card302bonus: "+4 if another Cup",
			card303name: "Warrior's Amulet",
			card303bonus: "+1 per monster defeated",
			card304name: "Moon Shard",
			card304bonus: "+2 per other differently-named Shard",
			card305name: "Tome of Divinity",
			card305bonus: "+3 if another Book",
			card306name: "Chalice of Blood",
			card306bonus: "+2 per monster defeated",
			card307name: "Cursed Amulet",
			card307bonus: "+4 if another Amulet",
			card308name: "Crystal Orb",
			card308bonus: "+4 if another Orb",
			card309name: "Shadow Orb",
			card309bonus: "+3 if another Orb",
			card310name: "Star Shard",
			card310bonus: "+2 per other differently-named Shard",
			card311name: "Book of Secrets",
			card311bonus: "+4 if another Book",
			card312name: "Thief's Amulet",
			card312bonus: "+1 per chest opened",
			card313name: "Hunter's Bestiary",
			card313bonus: "+2 if at least 2 monsters defeated",
			card314name: "Cartographer's Scroll",
			card314bonus: "+3 if no unknown cells",
			card315name: "Scroll of Truth",
			card315bonus: "+3 if no Discord treasure",
			card316name: "Orb of Sight",
			card316bonus: "+1 per trap disarmed",
			card317name: "Gladewalker's Tiara",
			card317bonus: "+1 if another Crown; +3 if no unknown cells",
			card318name: "Demon Statue",
			card318bonus: "+1 per other Statue",
			card319name: "Scroll of Harmony",
			card319bonus: "+2 per Harmony treasure (not itself)",
			card320name: "Idol of Discord",
			card320bonus: "+2 per Discord treasure (incl. itself)",
			card321name: "King's Crown",
			card321bonus: "+1 per other Crown"
		}
	}
};
//#endregion
export { aa as default };
