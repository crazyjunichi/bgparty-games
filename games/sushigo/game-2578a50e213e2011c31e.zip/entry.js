import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useState as r } from "react";
import { botAvatarOf as i } from "@bgparty/sdk/lobby";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { avatarNameAt as c, useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { IconBot as d } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { Texture as p } from "@bgparty/sdk/texture";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as h } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { Floater as y, FlySprite as b, PulseBox as ee } from "@bgparty/sdk/fx/primitives";
import { seatName as te } from "@bgparty/sdk/ui/player-strip";
//#region src/games/sushigo/cards.ts
var x = [
	"maki",
	"temaki",
	"uramaki"
], S = [
	"tempura",
	"sashimi",
	"dumpling",
	"eel",
	"tofu",
	"onigiri",
	"edamame",
	"miso"
], ne = [
	"chopsticks",
	"soy",
	"tea",
	"menu",
	"spoon",
	"specialOrder",
	"takeout",
	"wasabi"
], re = [
	"pudding",
	"gtic",
	"fruit"
];
function ie(e, t) {
	let n = new Set(e.specials), r = new Set(e.appetizers);
	return !(t >= 7 && (n.has("menu") || n.has("specialOrder")) || t === 2 && (n.has("spoon") || r.has("edamame")));
}
var C = {
	myFirstMeal: {
		roll: "maki",
		appetizers: [
			"tempura",
			"sashimi",
			"miso"
		],
		specials: ["wasabi", "tea"],
		dessert: "gtic"
	},
	sushiGo: {
		roll: "maki",
		appetizers: [
			"tempura",
			"sashimi",
			"dumpling"
		],
		specials: ["chopsticks", "wasabi"],
		dessert: "pudding"
	},
	partySampler: {
		roll: "temaki",
		appetizers: [
			"tempura",
			"dumpling",
			"tofu"
		],
		specials: ["wasabi", "menu"],
		dessert: "gtic"
	},
	masterMenu: {
		roll: "temaki",
		appetizers: [
			"onigiri",
			"tofu",
			"sashimi"
		],
		specials: ["spoon", "takeout"],
		dessert: "fruit"
	},
	pointsPlatter: {
		roll: "uramaki",
		appetizers: [
			"onigiri",
			"dumpling",
			"edamame"
		],
		specials: ["specialOrder", "tea"],
		dessert: "gtic"
	},
	cutthroatCombo: {
		roll: "temaki",
		appetizers: [
			"eel",
			"tofu",
			"miso"
		],
		specials: ["spoon", "soy"],
		dessert: "pudding"
	},
	bigBanquet: {
		roll: "maki",
		appetizers: [
			"tempura",
			"dumpling",
			"eel"
		],
		specials: ["spoon", "chopsticks"],
		dessert: "gtic"
	},
	dinnerForTwo: {
		roll: "uramaki",
		appetizers: [
			"onigiri",
			"tofu",
			"miso"
		],
		specials: ["menu", "specialOrder"],
		dessert: "fruit"
	}
}, w = C.sushiGo, T = {
	egg: "#facc15",
	salmon: "#facc15",
	squid: "#facc15",
	maki1: "#ef4444",
	maki2: "#ef4444",
	maki3: "#ef4444",
	temaki: "#1e3a8a",
	uramaki3: "#a3e635",
	uramaki4: "#a3e635",
	uramaki5: "#a3e635",
	tempura: "#fb923c",
	sashimi: "#84cc16",
	dumpling: "#60a5fa",
	eel: "#a78bfa",
	tofu: "#4ade80",
	onigiri_circle: "#f9a8d4",
	onigiri_triangle: "#f9a8d4",
	onigiri_square: "#f9a8d4",
	onigiri_rectangle: "#f9a8d4",
	edamame: "#c084fc",
	miso: "#b45309",
	chopsticks1: "#7dd3fc",
	chopsticks2: "#7dd3fc",
	chopsticks3: "#7dd3fc",
	soy: "#991b1b",
	tea: "#166534",
	menu7: "#fde68a",
	menu8: "#fde68a",
	menu9: "#fde68a",
	spoon4: "#3b82f6",
	spoon5: "#3b82f6",
	spoon6: "#3b82f6",
	specialOrder: "#f472b6",
	takeout10: "#9ca3af",
	takeout11: "#9ca3af",
	takeout12: "#9ca3af",
	wasabi: "#facc15",
	pudding: "#f9a8d4",
	gtic: "#93c5fd",
	fruit_ww: "#fda4af",
	fruit_oo: "#fda4af",
	fruit_pp: "#fda4af",
	fruit_wo: "#fda4af",
	fruit_wp: "#fda4af",
	fruit_op: "#fda4af"
}, E = (e) => e === "egg" || e === "salmon" || e === "squid", D = (e) => e.startsWith("maki"), O = (e) => e.startsWith("uramaki"), k = (e) => e.startsWith("fruit_"), A = (e) => e.startsWith("chopsticks"), j = (e) => e.startsWith("spoon"), M = (e) => e.startsWith("menu"), N = (e) => e.startsWith("takeout"), P = (e) => e === "pudding" || e === "gtic" || k(e), F = (e) => A(e) || j(e), ae = (e) => A(e) || j(e) || M(e) || N(e);
function I(e) {
	return ae(e) ? Number(e.replace(/[a-z]/g, "")) : 0;
}
var L = {
	maki1: 1,
	maki2: 2,
	maki3: 3
}, R = {
	uramaki3: 3,
	uramaki4: 4,
	uramaki5: 5
}, z = {
	egg: 1,
	salmon: 2,
	squid: 3
}, oe = [
	"circle",
	"triangle",
	"square",
	"rectangle"
], B = [
	"watermelon",
	"orange",
	"pineapple"
], V = {
	fruit_ww: ["watermelon", "watermelon"],
	fruit_oo: ["orange", "orange"],
	fruit_pp: ["pineapple", "pineapple"],
	fruit_wo: ["watermelon", "orange"],
	fruit_wp: ["watermelon", "pineapple"],
	fruit_op: ["orange", "pineapple"]
}, se = [
	0,
	1,
	3,
	6,
	10,
	15
], ce = [
	0,
	1,
	4,
	9,
	16
], H = [
	-2,
	0,
	1,
	3,
	6,
	10
], le = [
	8,
	5,
	2
];
function ue(e) {
	let t = [
		"egg",
		"egg",
		"egg",
		"egg",
		"salmon",
		"salmon",
		"salmon",
		"salmon",
		"salmon",
		"squid",
		"squid",
		"squid"
	];
	e.roll === "maki" ? t.push("maki1", "maki1", "maki1", "maki1", "maki2", "maki2", "maki2", "maki2", "maki2", "maki3", "maki3", "maki3") : e.roll === "temaki" ? t.push(...Array(12).fill("temaki")) : t.push("uramaki3", "uramaki3", "uramaki3", "uramaki3", "uramaki4", "uramaki4", "uramaki4", "uramaki4", "uramaki5", "uramaki5", "uramaki5", "uramaki5");
	for (let n of e.appetizers) if (n === "onigiri") for (let e of oe) t.push(`onigiri_${e}`, `onigiri_${e}`);
	else {
		let e = n;
		for (let n = 0; n < 8; n += 1) t.push(e);
	}
	for (let n of e.specials) if (n === "chopsticks") t.push("chopsticks1", "chopsticks2", "chopsticks3");
	else if (n === "spoon") t.push("spoon4", "spoon5", "spoon6");
	else if (n === "menu") t.push("menu7", "menu8", "menu9");
	else if (n === "takeout") t.push("takeout10", "takeout11", "takeout12");
	else {
		let e = n;
		t.push(e, e, e);
	}
	return t;
}
function de(e) {
	return e === "pudding" ? Array(15).fill("pudding") : e === "gtic" ? Array(15).fill("gtic") : [
		"fruit_ww",
		"fruit_ww",
		"fruit_oo",
		"fruit_oo",
		"fruit_pp",
		"fruit_pp",
		"fruit_wo",
		"fruit_wo",
		"fruit_wo",
		"fruit_wp",
		"fruit_wp",
		"fruit_wp",
		"fruit_op",
		"fruit_op",
		"fruit_op"
	];
}
function fe(e) {
	return 11 - Math.floor(e / 2);
}
function U(e, t) {
	return e <= 5 ? [
		0,
		5,
		3,
		2
	][t] : [
		0,
		7,
		5,
		3
	][t];
}
var pe = {
	egg: "games.sushigo.helpEgg",
	salmon: "games.sushigo.helpSalmon",
	squid: "games.sushigo.helpSquid",
	maki1: "games.sushigo.helpMaki",
	maki2: "games.sushigo.helpMaki",
	maki3: "games.sushigo.helpMaki",
	temaki: "games.sushigo.helpTemaki",
	uramaki3: "games.sushigo.helpUramaki",
	uramaki4: "games.sushigo.helpUramaki",
	uramaki5: "games.sushigo.helpUramaki",
	tempura: "games.sushigo.helpTempura",
	sashimi: "games.sushigo.helpSashimi",
	dumpling: "games.sushigo.helpDumpling",
	eel: "games.sushigo.helpEel",
	tofu: "games.sushigo.helpTofu",
	onigiri_circle: "games.sushigo.helpOnigiri",
	onigiri_triangle: "games.sushigo.helpOnigiri",
	onigiri_square: "games.sushigo.helpOnigiri",
	onigiri_rectangle: "games.sushigo.helpOnigiri",
	edamame: "games.sushigo.helpEdamame",
	miso: "games.sushigo.helpMiso",
	chopsticks1: "games.sushigo.helpChopsticks",
	chopsticks2: "games.sushigo.helpChopsticks",
	chopsticks3: "games.sushigo.helpChopsticks",
	soy: "games.sushigo.helpSoy",
	tea: "games.sushigo.helpTea",
	menu7: "games.sushigo.helpMenu",
	menu8: "games.sushigo.helpMenu",
	menu9: "games.sushigo.helpMenu",
	spoon4: "games.sushigo.helpSpoon",
	spoon5: "games.sushigo.helpSpoon",
	spoon6: "games.sushigo.helpSpoon",
	specialOrder: "games.sushigo.helpSpecialOrder",
	takeout10: "games.sushigo.helpTakeout",
	takeout11: "games.sushigo.helpTakeout",
	takeout12: "games.sushigo.helpTakeout",
	wasabi: "games.sushigo.helpWasabi",
	pudding: "games.sushigo.helpPudding",
	gtic: "games.sushigo.helpGtic",
	fruit_ww: "games.sushigo.helpFruit",
	fruit_oo: "games.sushigo.helpFruit",
	fruit_pp: "games.sushigo.helpFruit",
	fruit_wo: "games.sushigo.helpFruit",
	fruit_wp: "games.sushigo.helpFruit",
	fruit_op: "games.sushigo.helpFruit"
}, W = {
	egg: "games.sushigo.cardEgg",
	salmon: "games.sushigo.cardSalmon",
	squid: "games.sushigo.cardSquid",
	maki1: "games.sushigo.cardMaki1",
	maki2: "games.sushigo.cardMaki2",
	maki3: "games.sushigo.cardMaki3",
	temaki: "games.sushigo.cardTemaki",
	uramaki3: "games.sushigo.cardUramaki3",
	uramaki4: "games.sushigo.cardUramaki4",
	uramaki5: "games.sushigo.cardUramaki5",
	tempura: "games.sushigo.cardTempura",
	sashimi: "games.sushigo.cardSashimi",
	dumpling: "games.sushigo.cardDumpling",
	eel: "games.sushigo.cardEel",
	tofu: "games.sushigo.cardTofu",
	onigiri_circle: "games.sushigo.cardOnigiriCircle",
	onigiri_triangle: "games.sushigo.cardOnigiriTriangle",
	onigiri_square: "games.sushigo.cardOnigiriSquare",
	onigiri_rectangle: "games.sushigo.cardOnigiriRectangle",
	edamame: "games.sushigo.cardEdamame",
	miso: "games.sushigo.cardMiso",
	chopsticks1: "games.sushigo.cardChopsticks",
	chopsticks2: "games.sushigo.cardChopsticks",
	chopsticks3: "games.sushigo.cardChopsticks",
	soy: "games.sushigo.cardSoy",
	tea: "games.sushigo.cardTea",
	menu7: "games.sushigo.cardMenu",
	menu8: "games.sushigo.cardMenu",
	menu9: "games.sushigo.cardMenu",
	spoon4: "games.sushigo.cardSpoon",
	spoon5: "games.sushigo.cardSpoon",
	spoon6: "games.sushigo.cardSpoon",
	specialOrder: "games.sushigo.cardSpecialOrder",
	takeout10: "games.sushigo.cardTakeout",
	takeout11: "games.sushigo.cardTakeout",
	takeout12: "games.sushigo.cardTakeout",
	wasabi: "games.sushigo.cardWasabi",
	pudding: "games.sushigo.cardPudding",
	gtic: "games.sushigo.cardGtic",
	fruit_ww: "games.sushigo.cardFruitWw",
	fruit_oo: "games.sushigo.cardFruitOo",
	fruit_pp: "games.sushigo.cardFruitPp",
	fruit_wo: "games.sushigo.cardFruitWo",
	fruit_wp: "games.sushigo.cardFruitWp",
	fruit_op: "games.sushigo.cardFruitOp"
}, me = {
	id: "sushigo",
	tier: "released",
	mechanics: ["drafting", "set-collection"],
	interactionTags: [],
	nameKey: "games.sushigo.name",
	descKey: "games.sushigo.desc",
	rulesKey: "games.sushigo.rules",
	icon: "🍣",
	iconImg: "games/sushigo.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/sushigo/en.pdf" },
	minPlayers: 2,
	maxPlayers: 8,
	bestPlayers: [4, 5],
	accent: "#f97316",
	releasedAt: "2026-09-21",
	search: {
		py: "shou si gou pai dui",
		init: "ssgpd"
	},
	hotseat: "cover"
}, G = t.enum(/* @__PURE__ */ "egg.salmon.squid.maki1.maki2.maki3.temaki.uramaki3.uramaki4.uramaki5.tempura.sashimi.dumpling.eel.tofu.onigiri_circle.onigiri_triangle.onigiri_square.onigiri_rectangle.edamame.miso.chopsticks1.chopsticks2.chopsticks3.soy.tea.menu7.menu8.menu9.spoon4.spoon5.spoon6.specialOrder.takeout10.takeout11.takeout12.wasabi.pudding.gtic.fruit_ww.fruit_oo.fruit_pp.fruit_wo.fruit_wp.fruit_op".split(".")), he = t.enum([
	"maki",
	"temaki",
	"uramaki"
]), ge = t.enum([
	"tempura",
	"sashimi",
	"dumpling",
	"eel",
	"tofu",
	"onigiri",
	"edamame",
	"miso"
]), _e = t.enum([
	"chopsticks",
	"soy",
	"tea",
	"menu",
	"spoon",
	"specialOrder",
	"takeout",
	"wasabi"
]), ve = t.enum([
	"pudding",
	"gtic",
	"fruit"
]), ye = t.object({
	roll: he,
	appetizers: t.array(ge).length(3),
	specials: t.array(_e).length(2),
	dessert: ve
}), be = ye.default(w), xe = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("pick"),
		card: t.int(),
		chop: t.int().optional(),
		spoon: G.optional(),
		flips: t.array(t.int()).max(20).optional(),
		copyTarget: t.int().optional()
	}),
	t.object({
		type: t.literal("menuPick"),
		drawnId: t.int()
	}),
	t.object({ type: t.literal("confirm") })
]), Se = t.string(), Ce = t.object({
	id: t.int(),
	t: G
}), we = t.object({
	id: t.int(),
	t: G,
	turn: t.int(),
	flipped: t.boolean().optional(),
	copyOf: G.optional(),
	top: t.object({
		id: t.int(),
		t: G,
		copyOf: G.optional()
	}).optional()
}), Te = t.object({
	cat: t.string(),
	pts: t.int(),
	n: t.int().optional()
}), Ee = t.object({
	rid: Se,
	tableau: t.array(we),
	desserts: t.array(t.object({
		id: t.int(),
		t: G,
		copyOf: G.optional()
	})),
	score: t.int(),
	picked: t.boolean(),
	uramakiIcons: t.int(),
	roundPts: t.int()
}), De = t.object({
	phase: t.enum([
		"pick",
		"menu",
		"roundEnd",
		"done"
	]),
	round: t.int().min(1).max(3),
	roundStartTurn: t.int(),
	menu: ye,
	players: t.array(Ee),
	menuQueue: t.array(t.object({
		rid: Se,
		entryId: t.int()
	})),
	uramakiClaims: t.array(t.object({
		rid: Se,
		place: t.int(),
		pts: t.int()
	})),
	confirmed: t.array(Se),
	lastRound: t.object({
		round: t.int(),
		lines: t.record(Se, t.array(Te))
	}).nullable()
}), Oe = t.object({
	hand: t.array(Ce),
	myPick: t.object({
		card: Ce,
		chop: Ce.nullable(),
		spoon: G.nullable()
	}).nullable(),
	menuDrawn: t.array(Ce).nullable()
}), K = (e) => ({ code: e });
function ke(t, n, r) {
	for (let i = t.length - 1; i > 0; --i) {
		let a = e(n, r, i + 1);
		r += 1, [t[i], t[a]] = [t[a], t[i]];
	}
	return r;
}
function Ae(e, t, n) {
	let r = ie(e, t.length) ? e : w, i = ue(r).map((e, t) => ({
		id: t,
		t: e
	})), a = de(r.dessert).map((e, t) => ({
		id: i.length + t,
		t: e
	})), o = {};
	for (let e of t) o[e] = {
		hand: [],
		tableau: [],
		desserts: [],
		score: 0
	};
	let s = {
		players: t,
		menu: r,
		round: 0,
		phase: "pick",
		turn: 0,
		roundStartTurn: 0,
		deck: i,
		dessertDeck: a,
		discard: [],
		ps: o,
		picks: {},
		effects: [],
		uramakiClaims: [],
		lastRound: null,
		confirmed: [],
		rngCursor: 0,
		seed: n
	};
	return je(s, 1), {
		state: s,
		fx: t.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: { count: s.ps[e].hand.length },
			for: [e],
			secret: { cards: s.ps[e].hand },
			...t > 0 ? { with: !0 } : {}
		}))
	};
}
function je(e, t) {
	let n = [...e.deck];
	if (t > 1) {
		for (let t of e.players) {
			let r = e.ps[t];
			for (let e of r.tableau) n.push({
				id: e.id,
				t: e.t
			}), e.top && n.push({
				id: e.top.id,
				t: e.top.t
			});
			r.tableau = [];
		}
		n.push(...e.discard), e.discard = [];
	}
	let r = Math.min(U(e.players.length, t), e.dessertDeck.length);
	n.push(...e.dessertDeck.splice(0, r)), e.rngCursor = ke(n, e.seed, e.rngCursor);
	let i = fe(e.players.length);
	for (let t of e.players) e.ps[t].hand = n.splice(0, i);
	e.deck = n, e.round = t, e.phase = "pick", e.roundStartTurn = e.turn, e.picks = {}, e.effects = [], e.uramakiClaims = [], e.confirmed = [];
}
function Me(e, t, n, r) {
	let i = e.ps[t], a = r ?? n.t;
	if (P(a)) {
		i.desserts.push({
			id: n.id,
			t: n.t,
			...r ? { copyOf: r } : {},
			round: e.round
		});
		return;
	}
	if (E(a)) {
		let e = i.tableau.find((e) => e.t === "wasabi" && !e.top && !e.flipped);
		if (e) {
			e.top = {
				id: n.id,
				t: n.t,
				...r ? { copyOf: r } : {}
			};
			return;
		}
	}
	i.tableau.push({
		id: n.id,
		t: n.t,
		turn: e.turn,
		...r ? { copyOf: r } : {}
	});
}
function q(e) {
	return e.flipped ? null : e.copyOf ?? e.t;
}
function Ne(e) {
	let t = 0;
	for (let n of e.tableau) {
		let e = q(n);
		e && O(e) && (t += R[e]);
	}
	return t;
}
function Pe(e, t) {
	let n = e.players.map((t) => ({
		rid: t,
		icons: Ne(e.ps[t])
	})).filter((e) => e.icons >= 10).sort((e, t) => t.icons - e.icons), r = 0;
	for (; r < n.length && e.uramakiClaims.length < 3;) {
		let i = e.uramakiClaims.length, a = le[i], o = r;
		for (; o < n.length && n[o].icons === n[r].icons;) o += 1;
		for (let s = r; s < o; s += 1) {
			let r = n[s].rid;
			e.ps[r].score += a, e.uramakiClaims.push({
				rid: r,
				place: i,
				pts: a
			});
			let o = e.ps[r], c = [];
			for (let t of o.tableau) {
				let n = q(t);
				n && O(n) ? e.discard.push({
					id: t.id,
					t: t.t
				}) : c.push(t);
			}
			o.tableau = c, t.push({
				kind: "uramaki",
				rid: r,
				data: {
					place: i,
					pts: a
				}
			});
		}
		r = o;
	}
}
function Fe(e, t) {
	for (; e.effects.length > 0;) {
		let n = e.effects[0];
		if (n.kind === "menu") {
			e.phase = "menu";
			return;
		}
		if (e.effects.shift(), n.kind === "chop") {
			let r = e.ps[n.rid], i = r.tableau.findIndex((e) => e.id === n.entryId);
			i >= 0 && (r.hand.push({
				id: r.tableau[i].id,
				t: r.tableau[i].t
			}), r.tableau.splice(i, 1)), Me(e, n.rid, n.card), Pe(e, t), t.push({
				kind: "chopUsed",
				rid: n.rid,
				data: { card: n.card.t }
			});
		} else if (n.kind === "spoon") {
			let r = e.ps[n.rid], i = r.tableau.findIndex((e) => e.id === n.entryId);
			if (i < 0) continue;
			let a = {
				id: r.tableau[i].id,
				t: r.tableau[i].t
			}, o = e.players.indexOf(n.rid), s = null;
			for (let t = 1; t < e.players.length; t += 1) {
				let r = e.players[(o + t) % e.players.length], i = e.ps[r].hand, a = i.findIndex((e) => e.t === n.want);
				if (a >= 0) {
					s = {
						rid: r,
						card: i[a]
					}, i.splice(a, 1);
					break;
				}
			}
			r.tableau.splice(i, 1), s ? (Me(e, n.rid, s.card), e.ps[s.rid].hand.push(a), t.push({
				kind: "spoonHit",
				rid: n.rid,
				data: {
					from: s.rid,
					card: s.card.t
				}
			}), Pe(e, t)) : (e.discard.push(a), t.push({
				kind: "spoonMiss",
				rid: n.rid,
				data: { want: n.want }
			}));
		} else if (n.kind === "takeout") {
			let r = e.ps[n.rid];
			for (let e of n.flips) {
				let t = r.tableau.find((t) => t.id === e);
				t && (t.flipped = !0);
			}
			let i = r.tableau.findIndex((e) => e.id === n.entryId);
			i >= 0 && (e.discard.push({
				id: r.tableau[i].id,
				t: r.tableau[i].t
			}), r.tableau.splice(i, 1)), t.push({
				kind: "takeout",
				rid: n.rid,
				data: { count: n.flips.length }
			});
		}
	}
	Ie(e, t);
}
function Ie(e, t) {
	let n = [];
	for (let t of e.players) for (let r of e.ps[t].tableau) r.turn === e.turn && q(r) === "miso" && n.push({
		rid: t,
		entryId: r.id
	});
	if (n.length >= 2) {
		for (let t of n) {
			let n = e.ps[t.rid], r = n.tableau.findIndex((e) => e.id === t.entryId);
			r >= 0 && (e.discard.push({
				id: n.tableau[r].id,
				t: n.tableau[r].t
			}), n.tableau.splice(r, 1));
		}
		t.push({
			kind: "misoOut",
			data: { rids: [...new Set(n.map((e) => e.rid))] }
		});
	}
	let r = e.players.map((t) => e.ps[t].hand);
	for (let t = 0; t < e.players.length; t += 1) e.ps[e.players[(t + 1) % e.players.length]].hand = r[t];
	e.turn += 1, r[0].length === 0 ? ze(e, t) : e.phase = "pick";
}
function Le(e, t, n) {
	let r = e.players.map((e) => t[e]), i = Math.max(...r), a = Math.min(...r);
	if (i !== a) for (let r of e.players) t[r] === i ? n[r].push({
		cat: "games.sushigo.catTemaki",
		pts: 4,
		n: t[r]
	}) : t[r] === a && e.players.length > 2 && n[r].push({
		cat: "games.sushigo.catTemaki",
		pts: -4,
		n: t[r]
	});
}
function Re(e) {
	let t = e.players.length, n = {};
	for (let t of e.players) n[t] = [];
	let r = {}, i = {};
	for (let t of e.players) {
		r[t] = 0, i[t] = 0;
		for (let n of e.ps[t].tableau) {
			let e = q(n);
			e && (D(e) && (r[t] += L[e]), e === "temaki" && (i[t] += 1));
		}
	}
	if (e.menu.roll === "maki") {
		let i = t >= 6 ? [
			6,
			4,
			2
		] : [6, 3];
		[...new Set(e.players.map((e) => r[e]).filter((e) => e > 0))].sort((e, t) => t - e).slice(0, i.length).forEach((t, a) => {
			for (let o of e.players) r[o] === t && n[o].push({
				cat: "games.sushigo.catMaki",
				pts: i[a],
				n: t
			});
		});
	} else if (e.menu.roll === "temaki") Le(e, i, n);
	else if (e.uramakiClaims.length < 3) {
		let t = e.players.map((t) => ({
			rid: t,
			icons: Ne(e.ps[t])
		})).filter((e) => e.icons > 0);
		if (t.length > 0) {
			let r = Math.max(...t.map((e) => e.icons)), i = le[e.uramakiClaims.length];
			for (let e of t) e.icons === r && n[e.rid].push({
				cat: "games.sushigo.catUramaki",
				pts: i,
				n: e.icons
			});
		}
	}
	let a = {};
	for (let t of e.players) {
		let n = /* @__PURE__ */ new Set();
		for (let r of e.ps[t].tableau) {
			let e = q(r);
			e && n.add(T[e]), r.top && !r.flipped && n.add(T[r.top.copyOf ?? r.top.t]);
		}
		for (let r of e.ps[t].desserts) r.round === e.round && n.add(T[r.copyOf ?? r.t]);
		a[t] = n.size;
	}
	let o = Math.max(...e.players.map((e) => a[e]));
	for (let t of e.players) {
		let r = e.ps[t], i = (e, r, i) => {
			r !== 0 && n[t].push({
				cat: e,
				pts: r,
				...i === void 0 ? {} : { n: i }
			});
		}, s = (e) => r.tableau.filter((t) => {
			let n = q(t);
			return n !== null && e(n);
		}).length, c = 0, l = 0;
		for (let e of r.tableau) {
			if (e.flipped) continue;
			let t = e.copyOf ?? e.t;
			if (E(t) && (c += z[t], l += 1), e.t === "wasabi" && e.top) {
				let t = e.top.copyOf ?? e.top.t;
				E(t) && (c += z[t] * 3, l += 1);
			}
		}
		i("games.sushigo.catNigiri", c, l);
		let u = s((e) => e === "tempura");
		i("games.sushigo.catTempura", Math.floor(u / 2) * 5, u);
		let d = s((e) => e === "sashimi");
		i("games.sushigo.catSashimi", Math.floor(d / 3) * 10, d);
		let f = s((e) => e === "dumpling");
		i("games.sushigo.catDumpling", se[Math.min(f, 5)], f);
		let p = s((e) => e === "eel");
		i("games.sushigo.catEel", p === 0 ? 0 : p === 1 ? -3 : 7, p);
		let m = s((e) => e === "tofu");
		i("games.sushigo.catTofu", m === 1 ? 2 : m === 2 ? 6 : 0, m);
		let h = {
			circle: 0,
			triangle: 0,
			square: 0,
			rectangle: 0
		};
		for (let e of r.tableau) {
			let t = q(e);
			t && t.startsWith("onigiri_") && (h[t.slice(8)] += 1);
		}
		let g = 0, _ = 0;
		for (let e = 0; e < 8; e += 1) {
			let t = 0;
			for (let n of [
				"circle",
				"triangle",
				"square",
				"rectangle"
			]) h[n] > e && (t += 1);
			if (t === 0) break;
			g += ce[t], _ += t;
		}
		e.menu.appetizers.includes("onigiri") && i("games.sushigo.catOnigiri", g, _);
		let v = s((e) => e === "edamame");
		if (v > 0) {
			let n = e.players.filter((n) => n !== t && e.ps[n].tableau.some((e) => q(e) === "edamame")).length;
			i("games.sushigo.catEdamame", v * Math.min(n, 4), v);
		}
		let y = s((e) => e === "miso");
		if (i("games.sushigo.catMiso", y * 3, y), s((e) => e === "tea") > 0) {
			let t = /* @__PURE__ */ new Map();
			for (let e of r.tableau) {
				let n = q(e);
				if (n && t.set(T[n], (t.get(T[n]) ?? 0) + 1), e.top && !e.flipped) {
					let n = e.top.copyOf ?? e.top.t;
					t.set(T[n], (t.get(T[n]) ?? 0) + 1);
				}
			}
			for (let n of r.desserts) if (n.round === e.round) {
				let e = T[n.copyOf ?? n.t];
				t.set(e, (t.get(e) ?? 0) + 1);
			}
			let n = Math.max(0, ...t.values());
			i("games.sushigo.catTea", s((e) => e === "tea") * n, n);
		}
		let b = s((e) => e === "soy");
		b > 0 && a[t] === o && i("games.sushigo.catSoy", b * 4, a[t]);
		let ee = r.tableau.filter((e) => e.flipped).length;
		i("games.sushigo.catTakeout", ee * 2, ee);
	}
	return n;
}
function ze(e, t) {
	let n = Re(e);
	for (let t of e.players) for (let r of n[t]) e.ps[t].score += r.pts;
	e.lastRound = {
		round: e.round,
		lines: n
	}, t.push({
		kind: "roundScore",
		data: { round: e.round }
	}), e.round >= 3 ? (Be(e), e.phase = "done") : e.phase = "roundEnd";
}
function Be(e) {
	let t = e.players.length, n = e.lastRound.lines, r = (t, n) => e.ps[t].desserts.filter((e) => n(e.copyOf ?? e.t)).length;
	if (e.menu.dessert === "pudding") {
		let i = e.players.map((e) => r(e, (e) => e === "pudding")), a = Math.max(...i), o = Math.min(...i);
		e.players.forEach((r, s) => {
			i[s] === a && a > 0 ? n[r].push({
				cat: "games.sushigo.catPudding",
				pts: 6,
				n: i[s]
			}) : i[s] === o && t > 2 && a !== o && n[r].push({
				cat: "games.sushigo.catPudding",
				pts: -6,
				n: i[s]
			}), e.ps[r].score += (i[s] === a && a > 0 ? 6 : 0) + (i[s] === o && t > 2 && a !== o ? -6 : 0);
		});
	} else if (e.menu.dessert === "gtic") for (let t of e.players) {
		let i = r(t, (e) => e === "gtic"), a = Math.floor(i / 4) * 12;
		a !== 0 && n[t].push({
			cat: "games.sushigo.catGtic",
			pts: a,
			n: i
		}), e.ps[t].score += a;
	}
	else for (let t of e.players) {
		let r = 0;
		for (let n of B) {
			let i = e.ps[t].desserts.reduce((e, t) => e + V[t.copyOf ?? t.t].filter((e) => e === n).length, 0);
			r += H[Math.min(i, 5)];
		}
		let i = e.ps[t].desserts.length;
		(r !== 0 || i > 0) && n[t].push({
			cat: "games.sushigo.catFruit",
			pts: r,
			n: i
		}), e.ps[t].score += r;
	}
}
function Ve(e, t, n) {
	return t.type === "pick" ? He(e, t, n) : t.type === "menuPick" ? We(e, t, n) : Ge(e, n);
}
function He(e, t, n) {
	if (e.phase !== "pick") return K("games.sushigo.errNotYourTurn");
	if (n.by in e.picks) return K("games.sushigo.errAlreadyPicked");
	let r = e.ps[n.by]?.hand;
	if (!r) return K("games.sushigo.errNotYourTurn");
	let i = r.find((e) => e.id === t.card);
	if (!i) return K("games.sushigo.errBadCard");
	if (t.chop !== void 0 && t.spoon !== void 0) return K("games.sushigo.errBothBonus");
	let a = structuredClone(e), o = a.ps[n.by], s = o.tableau, c = null;
	if (t.chop !== void 0) {
		if (!s.some((e) => A(e.t) && !e.flipped && e.turn < a.turn)) return K("games.sushigo.errNoBonus");
		let e = o.hand.find((e) => e.id === t.chop);
		if (!e || e.id === i.id) return K("games.sushigo.errBadCard");
		if (M(e.t) || N(e.t) || e.t === "specialOrder") return K("games.sushigo.errBadBonusCard");
		c = e;
	}
	if (t.spoon !== void 0) {
		if (!s.some((e) => j(e.t) && !e.flipped && e.turn < a.turn)) return K("games.sushigo.errNoBonus");
		if (M(t.spoon) || N(t.spoon) || t.spoon === "specialOrder") return K("games.sushigo.errBadBonusCard");
	}
	let l = t.flips ?? [];
	if (l.length > 0) {
		if (!N(i.t)) return K("games.sushigo.errBadCard");
		for (let e of l) {
			let t = s.find((t) => t.id === e);
			if (!t || t.flipped || t.turn < a.roundStartTurn || t.turn >= a.turn) return K("games.sushigo.errBadFlip");
		}
	}
	if (t.copyTarget !== void 0 && i.t !== "specialOrder") return K("games.sushigo.errBadCard");
	if (o.hand = o.hand.filter((e) => e.id !== i.id && e.id !== c?.id), a.picks[n.by] = {
		card: i,
		chop: c,
		spoon: t.spoon ?? null,
		flips: l,
		copyTarget: t.copyTarget ?? null
	}, Object.keys(a.picks).length === a.players.length) {
		let e = [];
		return Ue(a, e), {
			state: a,
			fx: e
		};
	}
	return {
		state: a,
		fx: []
	};
}
function Ue(e, t) {
	let n = [];
	for (let t of e.players) {
		let r = e.picks[t];
		if (Me(e, t, r.card), r.card.t === "specialOrder") {
			let n = e.ps[t], i = n.tableau[n.tableau.length - 1], a = r.copyTarget === null ? void 0 : n.tableau.find((e) => e.id === r.copyTarget);
			if (a && a.id !== i.id) {
				i.copyOf = a.copyOf ?? a.t, a.flipped && (i.flipped = !0);
				let e = i.flipped ? null : i.copyOf ?? null;
				if (e && E(e)) {
					let e = n.tableau.find((e) => e.t === "wasabi" && !e.top && !e.flipped);
					e && (e.top = {
						id: i.id,
						t: i.t,
						copyOf: i.copyOf
					}, n.tableau = n.tableau.filter((e) => e.id !== i.id));
				}
			} else n.tableau = n.tableau.filter((e) => e.id !== i.id), e.discard.push({
				id: i.id,
				t: i.t
			});
		}
		let i = e.ps[t].tableau.some((e) => e.id === r.card.id || e.top?.id === r.card.id);
		n.push({
			rid: t,
			card: r.card.t,
			chop: r.chop?.t ?? null,
			dest: i ? r.card.id : null
		});
	}
	t.push({
		kind: "reveal",
		data: { plays: n }
	}), Pe(e, t);
	let r = [];
	for (let t of e.players) {
		let n = e.picks[t], i = e.ps[t];
		if (n.chop) {
			let a = i.tableau.find((t) => A(t.t) && !t.flipped && t.turn < e.turn);
			a && r.push({
				kind: "chop",
				rid: t,
				entryId: a.id,
				card: n.chop,
				order: I(a.t)
			});
		}
		if (n.spoon) {
			let a = i.tableau.find((t) => j(t.t) && !t.flipped && t.turn < e.turn);
			a && r.push({
				kind: "spoon",
				rid: t,
				entryId: a.id,
				want: n.spoon,
				order: I(a.t)
			});
		}
		let a = i.tableau.find((e) => e.id === n.card.id);
		if (a && M(a.t)) {
			let n = e.deck.splice(0, 4).filter((e) => !M(e.t));
			n.length === 0 && e.deck.length > 0 && (e.rngCursor = ke(e.deck, e.seed, e.rngCursor), n = e.deck.splice(0, 4).filter((e) => !M(e.t))), r.push({
				kind: "menu",
				rid: t,
				entryId: a.id,
				drawn: n,
				order: I(a.t)
			});
		}
		a && N(a.t) && n.flips.length > 0 && r.push({
			kind: "takeout",
			rid: t,
			entryId: a.id,
			flips: n.flips,
			order: I(a.t)
		}), a && N(a.t) && n.flips.length === 0 && (e.discard.push({
			id: a.id,
			t: a.t
		}), i.tableau = i.tableau.filter((e) => e.id !== a.id));
	}
	r.sort((e, t) => e.order - t.order), e.effects = r, e.picks = {}, Fe(e, t);
}
function We(e, t, n) {
	if (e.phase !== "menu") return K("games.sushigo.errNotYourTurn");
	let r = e.effects[0];
	if (!r || r.kind !== "menu" || r.rid !== n.by) return K("games.sushigo.errNotYourTurn");
	if (!r.drawn.find((e) => e.id === t.drawnId)) return K("games.sushigo.errBadCard");
	let i = structuredClone(e), a = i.effects[0], o = a.drawn.find((e) => e.id === t.drawnId), s = a.drawn.filter((e) => e.id !== t.drawnId);
	i.deck.push(...s), i.rngCursor = ke(i.deck, i.seed, i.rngCursor);
	let c = i.ps[n.by], l = c.tableau.findIndex((e) => e.id === a.entryId);
	l >= 0 && (i.discard.push({
		id: c.tableau[l].id,
		t: c.tableau[l].t
	}), c.tableau.splice(l, 1)), i.effects.shift();
	let u = [{
		kind: "menuPick",
		rid: n.by,
		data: { card: o.t }
	}];
	return Me(i, n.by, o), Pe(i, u), Fe(i, u), {
		state: i,
		fx: u
	};
}
function Ge(e, t) {
	if (e.phase !== "roundEnd") return K("games.sushigo.errNotYourTurn");
	if (e.confirmed.includes(t.by)) return K("games.sushigo.errAlreadyPicked");
	let n = structuredClone(e);
	return n.confirmed.push(t.by), n.confirmed.length === n.players.length ? (je(n, n.round + 1), {
		state: n,
		fx: n.players.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: { count: n.ps[e].hand.length },
			for: [e],
			secret: { cards: n.ps[e].hand },
			...t > 0 ? { with: !0 } : {}
		}))
	}) : {
		state: n,
		fx: []
	};
}
function Ke(e, t) {
	let n = e.ps[t], r = e.picks[t], i = e.phase === "menu" && e.effects[0]?.kind === "menu" ? e.effects[0] : null, a = e.phase === "pick" || e.phase === "menu" ? Re(e) : null;
	return {
		public: {
			phase: e.phase,
			round: e.round,
			roundStartTurn: e.roundStartTurn,
			menu: e.menu,
			players: e.players.map((t) => ({
				rid: t,
				tableau: e.ps[t].tableau,
				desserts: e.ps[t].desserts.map((e) => ({
					id: e.id,
					t: e.t,
					...e.copyOf ? { copyOf: e.copyOf } : {}
				})),
				score: e.ps[t].score,
				picked: t in e.picks,
				uramakiIcons: Ne(e.ps[t]),
				roundPts: a ? a[t].reduce((e, t) => e + t.pts, 0) : 0
			})),
			menuQueue: e.effects.filter((e) => e.kind === "menu").map((e) => ({
				rid: e.rid,
				entryId: e.entryId
			})),
			uramakiClaims: e.uramakiClaims,
			confirmed: e.confirmed,
			lastRound: e.lastRound
		},
		private: {
			hand: n?.hand ?? [],
			myPick: r ? {
				card: r.card,
				chop: r.chop,
				spoon: r.spoon
			} : null,
			menuDrawn: i && i.rid === t ? i.drawn : null
		}
	};
}
function qe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => e.ps[t].desserts.length, n = [...e.players].sort((n, r) => e.ps[r].score - e.ps[n].score || t(r) - t(n)), r = e.ps[n[0]].score, i = t(n[0]), a = n.filter((n) => e.ps[n].score === r && t(n) === i), o = {};
	for (let t of e.players) o[t] = e.ps[t].score;
	return {
		phase: "done",
		winner: a,
		ranking: n,
		scores: o
	};
}
var Je = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: me,
	schemas: {
		action: xe,
		publicView: De,
		privateView: Oe,
		config: be
	},
	setup: Ae,
	reduce: Ve,
	viewFor: Ke,
	status: qe
}, Ye = "/games/sushigo/", Xe = {
	egg: "egg",
	salmon: "salmon",
	maki1: "maki",
	maki2: "maki",
	maki3: "maki",
	tempura: "tempura",
	sashimi: "sashimi",
	dumpling: "dumpling",
	chopsticks1: "chopsticks",
	chopsticks2: "chopsticks",
	chopsticks3: "chopsticks",
	wasabi: "wasabi",
	pudding: "pudding"
}, J = "#51372b";
function Ze({ type: e }) {
	let t;
	if (e === "squid") t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("ellipse", {
			cx: "32",
			cy: "43",
			rx: "23",
			ry: "10",
			fill: "#f8f2e3",
			stroke: J,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("path", {
			d: "M12 33Q13 17 31 16Q50 16 52 32L45 42H19Z",
			fill: "#eee3da",
			stroke: J,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("path", {
			d: "M19 25Q31 20 45 25M18 31Q31 26 47 31",
			fill: "none",
			stroke: "#cba8a5",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("path", {
			d: "M22 42Q31 46 42 42",
			fill: "none",
			stroke: "#b1a6a0",
			strokeWidth: "2"
		})
	] });
	else if (e === "temaki") t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M15 11Q29 8 50 16L32 56Z",
			fill: "#193e36",
			stroke: J,
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ _("path", {
			d: "M16 13Q29 8 48 16L43 24Q27 19 18 23Z",
			fill: "#fff5dc",
			stroke: J,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("path", {
			d: "M19 13Q26 6 31 12Q39 5 46 16",
			fill: "none",
			stroke: "#df7365",
			strokeWidth: "5",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "32",
			cy: "15",
			r: "4",
			fill: "#9ac476"
		}),
		/* @__PURE__ */ _("path", {
			d: "M24 29L34 48",
			stroke: "#457369",
			strokeWidth: "2"
		})
	] });
	else if (e.startsWith("uramaki")) t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("circle", {
			cx: "21",
			cy: "31",
			r: "13",
			fill: "#e9dcb9",
			stroke: J,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "43",
			cy: "34",
			r: "13",
			fill: "#e9dcb9",
			stroke: J,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "21",
			cy: "31",
			r: "8",
			fill: "#f9f6dc",
			stroke: "#65806b",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "43",
			cy: "34",
			r: "8",
			fill: "#f9f6dc",
			stroke: "#65806b",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "21",
			cy: "31",
			r: "4",
			fill: "#e78572"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "43",
			cy: "34",
			r: "4",
			fill: "#e78572"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "17",
			cy: "27",
			r: "2",
			fill: "#8cba83"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "39",
			cy: "29",
			r: "2",
			fill: "#8cba83"
		})
	] });
	else if (e === "eel") t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("ellipse", {
			cx: "32",
			cy: "45",
			rx: "23",
			ry: "9",
			fill: "#f7f0dd",
			stroke: J,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("path", {
			d: "M11 32Q17 18 28 24Q42 19 52 31Q46 42 34 39Q20 45 11 32Z",
			fill: "#965139",
			stroke: J,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("path", {
			d: "M16 30Q25 36 35 26M30 37Q40 29 48 31",
			fill: "none",
			stroke: "#e7a45c",
			strokeWidth: "3",
			strokeLinecap: "round"
		})
	] });
	else if (e === "tofu") t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M14 25L35 17L51 26L30 35Z",
			fill: "#fff6d7",
			stroke: J,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("path", {
			d: "M14 25V43L30 52V35Z",
			fill: "#ddd6ac",
			stroke: J,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("path", {
			d: "M30 35L51 26V44L30 52Z",
			fill: "#f4eac3",
			stroke: J,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "36",
			cy: "30",
			r: "2",
			fill: "#8fb470"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "42",
			cy: "36",
			r: "1.5",
			fill: "#8fb470"
		})
	] });
	else if (e.startsWith("onigiri_")) {
		let n = e.slice(8);
		t = /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _("g", {
				fill: "#fcf7de",
				stroke: J,
				strokeWidth: "2.5",
				children: n === "circle" ? /* @__PURE__ */ _("circle", {
					cx: "32",
					cy: "32",
					r: "21"
				}) : n === "square" ? /* @__PURE__ */ _("rect", {
					x: "11",
					y: "11",
					width: "42",
					height: "42",
					rx: "7"
				}) : n === "rectangle" ? /* @__PURE__ */ _("rect", {
					x: "8",
					y: "16",
					width: "48",
					height: "32",
					rx: "6"
				}) : /* @__PURE__ */ _("path", { d: "M32 8Q35 8 38 14L56 45Q58 52 49 54H15Q6 52 8 45L26 14Q29 8 32 8Z" })
			}),
			/* @__PURE__ */ _("path", {
				d: "M23 39Q32 35 41 39L40 54H24Z",
				fill: "#263f39",
				stroke: J,
				strokeWidth: "2"
			}),
			/* @__PURE__ */ _("circle", {
				cx: "22",
				cy: "25",
				r: "1",
				fill: "#d9d1b0"
			}),
			/* @__PURE__ */ _("circle", {
				cx: "40",
				cy: "25",
				r: "1",
				fill: "#d9d1b0"
			}),
			/* @__PURE__ */ _("circle", {
				cx: "31",
				cy: "21",
				r: "1",
				fill: "#d9d1b0"
			})
		] });
	} else if (e === "edamame") t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M9 39Q23 10 54 24Q50 52 18 51Q11 49 9 39Z",
			fill: "#85b45b",
			stroke: J,
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ _("path", {
			d: "M14 43Q31 23 51 27",
			fill: "none",
			stroke: "#c4db78",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "24",
			cy: "35",
			r: "6",
			fill: "#bad675",
			stroke: "#5b814d"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "36",
			cy: "30",
			r: "6",
			fill: "#bad675",
			stroke: "#5b814d"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "46",
			cy: "27",
			r: "5",
			fill: "#bad675",
			stroke: "#5b814d"
		})
	] });
	else if (e === "miso") t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M9 29Q10 52 32 54Q54 52 55 29Z",
			fill: "#cc694e",
			stroke: J,
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ _("ellipse", {
			cx: "32",
			cy: "29",
			rx: "23",
			ry: "10",
			fill: "#f5d8a3",
			stroke: J,
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ _("path", {
			d: "M18 28Q25 20 30 27M34 29Q41 22 47 29",
			fill: "none",
			stroke: "#619373",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ _("rect", {
			x: "27",
			y: "27",
			width: "8",
			height: "6",
			rx: "2",
			fill: "#faf0d1"
		}),
		/* @__PURE__ */ _("path", {
			d: "M20 12Q16 19 21 23M32 9Q28 16 32 21M44 12Q40 19 43 23",
			fill: "none",
			stroke: "#c3aaa0",
			strokeWidth: "2",
			strokeLinecap: "round"
		})
	] });
	else if (e === "soy") t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M24 12H40V19L45 24V52Q32 57 19 52V24L24 19Z",
			fill: "#59362e",
			stroke: J,
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ _("path", {
			d: "M24 12H40V19H24Z",
			fill: "#a94c41",
			stroke: J,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("rect", {
			x: "21",
			y: "30",
			width: "22",
			height: "16",
			rx: "3",
			fill: "#f3d7a3"
		}),
		/* @__PURE__ */ _("path", {
			d: "M27 38H37",
			stroke: "#9f5b42",
			strokeWidth: "3",
			strokeLinecap: "round"
		})
	] });
	else if (e === "tea") t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M12 27H48L44 49Q32 55 16 49Z",
			fill: "#e8f1dd",
			stroke: J,
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ _("ellipse", {
			cx: "30",
			cy: "27",
			rx: "18",
			ry: "6",
			fill: "#8eb985",
			stroke: J,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("path", {
			d: "M48 32Q60 28 56 40Q53 47 46 44",
			fill: "none",
			stroke: J,
			strokeWidth: "3"
		}),
		/* @__PURE__ */ _("path", {
			d: "M21 10Q17 16 22 21M34 9Q30 15 35 20",
			fill: "none",
			stroke: "#b7c7aa",
			strokeWidth: "2",
			strokeLinecap: "round"
		})
	] });
	else if (e.startsWith("menu")) t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M17 9H46V52H17Q11 52 11 46V16Q11 9 17 9Z",
			fill: "#f6dba4",
			stroke: J,
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ _("path", {
			d: "M21 17H42M21 25H39M21 33H42",
			stroke: "#b77850",
			strokeWidth: "2.5",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "33",
			cy: "42",
			r: "5",
			fill: "#d57965"
		}),
		/* @__PURE__ */ _("path", {
			d: "M11 46Q14 42 17 46",
			fill: "none",
			stroke: J,
			strokeWidth: "2"
		})
	] });
	else if (e.startsWith("spoon")) t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M28 36L48 55",
			stroke: J,
			strokeWidth: "7",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ _("path", {
			d: "M28 36L48 55",
			stroke: "#c4cbd0",
			strokeWidth: "4",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ _("ellipse", {
			cx: "21",
			cy: "22",
			rx: "12",
			ry: "16",
			transform: "rotate(-35 21 22)",
			fill: "#e4edf0",
			stroke: J,
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ _("ellipse", {
			cx: "20",
			cy: "22",
			rx: "6",
			ry: "9",
			transform: "rotate(-35 20 22)",
			fill: "#b1c9d0"
		})
	] });
	else if (e === "specialOrder") t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M15 9H44L51 16V53H15Z",
			fill: "#fff0d2",
			stroke: J,
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ _("path", {
			d: "M44 9V17H51M22 26H43M22 34H40",
			fill: "none",
			stroke: "#c07869",
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ _("path", {
			d: "M32 40L35 45L41 37",
			fill: "none",
			stroke: "#7baf76",
			strokeWidth: "3",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	] });
	else if (e.startsWith("takeout")) t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M11 23L20 15H44L53 23L47 51H17Z",
			fill: "#f1e4ca",
			stroke: J,
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ _("path", {
			d: "M11 23H53M20 15L25 23M44 15L39 23",
			fill: "none",
			stroke: J,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ _("path", {
			d: "M23 35Q30 28 40 35M39 31L40 35L35 36",
			fill: "none",
			stroke: "#d98064",
			strokeWidth: "3",
			strokeLinecap: "round"
		})
	] });
	else if (e === "gtic") t = /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("path", {
			d: "M16 35Q14 26 21 23Q20 14 30 13Q37 9 42 18Q51 18 49 28Q55 35 46 38H20Z",
			fill: "#b2d6a6",
			stroke: J,
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ _("path", {
			d: "M18 37H47L42 52H23Z",
			fill: "#f4dfad",
			stroke: J,
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "27",
			cy: "25",
			r: "2",
			fill: "#7ba476"
		}),
		/* @__PURE__ */ _("circle", {
			cx: "38",
			cy: "30",
			r: "2",
			fill: "#7ba476"
		})
	] });
	else {
		let n = e.slice(6).split("");
		t = /* @__PURE__ */ _(g, { children: n.map((e, t) => e === "w" ? /* @__PURE__ */ v("g", {
			transform: `translate(${t * 23} 0)`,
			children: [
				/* @__PURE__ */ _("path", {
					d: "M12 27Q12 14 27 14Q42 14 42 27L27 47Z",
					fill: "#ec6d64",
					stroke: J,
					strokeWidth: "2"
				}),
				/* @__PURE__ */ _("path", {
					d: "M12 27Q27 35 42 27",
					fill: "none",
					stroke: "#f7dfbd",
					strokeWidth: "5"
				}),
				/* @__PURE__ */ _("path", {
					d: "M12 30Q27 38 42 30",
					fill: "none",
					stroke: "#478c5c",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ _("circle", {
					cx: "27",
					cy: "27",
					r: "1.5",
					fill: J
				})
			]
		}, t) : e === "o" ? /* @__PURE__ */ v("g", {
			transform: `translate(${t * 23} 0)`,
			children: [
				/* @__PURE__ */ _("circle", {
					cx: "27",
					cy: "31",
					r: "16",
					fill: "#f3a35a",
					stroke: J,
					strokeWidth: "2"
				}),
				/* @__PURE__ */ _("path", {
					d: "M27 16Q32 9 38 14",
					fill: "none",
					stroke: "#75a76b",
					strokeWidth: "4"
				}),
				/* @__PURE__ */ _("path", {
					d: "M27 18V45",
					stroke: "#ffd296",
					strokeWidth: "2"
				})
			]
		}, t) : /* @__PURE__ */ v("g", {
			transform: `translate(${t * 23} 0)`,
			children: [
				/* @__PURE__ */ _("path", {
					d: "M27 14L37 29L34 48H20L17 29Z",
					fill: "#f5c879",
					stroke: J,
					strokeWidth: "2"
				}),
				/* @__PURE__ */ _("path", {
					d: "M26 17L20 10M27 17L33 10",
					stroke: "#77a569",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ _("path", {
					d: "M21 30L33 39M33 30L21 39",
					stroke: "#d9a25e",
					strokeWidth: "2"
				})
			]
		}, t)) });
	}
	return /* @__PURE__ */ _("svg", {
		viewBox: "0 0 64 64",
		className: "sushigo-food-art",
		"aria-hidden": "true",
		children: t
	});
}
function Y({ type: e }) {
	let t = Xe[e];
	return t ? /* @__PURE__ */ _("img", {
		className: "sushigo-food-art sushigo-food-art--painted",
		src: `${Ye}${t}.webp`,
		alt: "",
		draggable: !1
	}) : /* @__PURE__ */ _(Ze, { type: e });
}
function Qe({ kind: e }) {
	return /* @__PURE__ */ _("svg", {
		className: "sushigo-fruit-mark",
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: e === "watermelon" ? /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _("path", {
				d: "M3 8Q12 21 21 8Z",
				fill: "#ed6c65",
				stroke: J,
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ _("path", {
				d: "M3 8Q12 22 21 8",
				fill: "none",
				stroke: "#5a9b6b",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ _("path", {
				d: "M5 8Q12 18 19 8",
				fill: "none",
				stroke: "#f7e5ba",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ _("circle", {
				cx: "10",
				cy: "11",
				r: ".8",
				fill: J
			}),
			/* @__PURE__ */ _("circle", {
				cx: "14",
				cy: "12",
				r: ".8",
				fill: J
			})
		] }) : e === "orange" ? /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _("circle", {
				cx: "12",
				cy: "12",
				r: "8",
				fill: "#f5a451",
				stroke: J,
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ _("path", {
				d: "M12 4Q15 0 19 4Q16 7 12 6",
				fill: "#76a66c",
				stroke: J,
				strokeWidth: "1"
			}),
			/* @__PURE__ */ _("path", {
				d: "M12 7V18M7 10L17 15M17 10L7 15",
				stroke: "#ffd7a0",
				strokeWidth: "1.3"
			})
		] }) : /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _("path", {
				d: "M12 7L8 3M12 7L12 1M12 7L16 3",
				fill: "none",
				stroke: "#70a467",
				strokeWidth: "2.5",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ _("path", {
				d: "M7 8Q12 5 17 8L18 16Q16 21 12 22Q8 21 6 16Z",
				fill: "#f5cc72",
				stroke: J,
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ _("path", {
				d: "M7 11L17 18M6 16L16 9M10 20L18 12",
				stroke: "#ca9854",
				strokeWidth: "1.2"
			})
		] })
	});
}
//#endregion
//#region src/games/sushigo/card.tsx
function $e({ t: e, dim: t, flipped: n }) {
	let r = u();
	return /* @__PURE__ */ v("div", {
		className: `sushigo-card-face ${t ? "sushigo-card-face--dim" : ""}`,
		style: { "--sushigo-card-color": T[e] },
		children: [
			/* @__PURE__ */ _("span", { className: "sushigo-card-band" }),
			/* @__PURE__ */ _("span", {
				className: "sushigo-card-illustration",
				children: n ? /* @__PURE__ */ _("span", {
					className: "sushigo-card-back",
					"aria-hidden": !0,
					children: "2"
				}) : /* @__PURE__ */ _(Y, { type: e })
			}),
			!n && /* @__PURE__ */ _("span", {
				className: "sushigo-card-name",
				title: r(W[e]),
				children: r(W[e])
			}),
			ae(e) && /* @__PURE__ */ _("span", {
				className: "sushigo-card-number font-mono tabular-nums",
				children: I(e)
			}),
			F(e) && /* @__PURE__ */ _("span", {
				className: "sushigo-card-bonus",
				"aria-hidden": !0,
				children: "✦"
			})
		]
	});
}
//#endregion
//#region src/games/sushigo/score-sheet.tsx
var et = /* @__PURE__ */ new Set([
	"games.sushigo.catPudding",
	"games.sushigo.catGtic",
	"games.sushigo.catFruit"
]), tt = {
	"games.sushigo.catMaki": "maki3",
	"games.sushigo.catTemaki": "temaki",
	"games.sushigo.catUramaki": "uramaki5",
	"games.sushigo.catNigiri": "salmon",
	"games.sushigo.catTempura": "tempura",
	"games.sushigo.catSashimi": "sashimi",
	"games.sushigo.catDumpling": "dumpling",
	"games.sushigo.catEel": "eel",
	"games.sushigo.catTofu": "tofu",
	"games.sushigo.catOnigiri": "onigiri_triangle",
	"games.sushigo.catEdamame": "edamame",
	"games.sushigo.catMiso": "miso",
	"games.sushigo.catTea": "tea",
	"games.sushigo.catSoy": "soy",
	"games.sushigo.catTakeout": "takeout10",
	"games.sushigo.catPudding": "pudding",
	"games.sushigo.catGtic": "gtic",
	"games.sushigo.catFruit": "fruit_wo"
}, nt = {
	watermelon: "games.sushigo.fruitWatermelon",
	orange: "games.sushigo.fruitOrange",
	pineapple: "games.sushigo.fruitPineapple"
};
function rt(e, t) {
	if (!e.lastRound || e.lastRound.round !== e.round) return null;
	let n = e.lastRound.lines[t];
	if (!n) return null;
	let r = n.filter((e) => !et.has(e.cat)), i = n.filter((e) => et.has(e.cat)), a = e.uramakiClaims.filter((e) => e.rid === t).reduce((e, t) => e + t.pts, 0);
	return {
		main: r,
		dessert: i,
		raceBonus: a,
		roundPoints: r.reduce((e, t) => e + t.pts, 0) + a,
		dessertPoints: i.reduce((e, t) => e + t.pts, 0)
	};
}
function it(e, t, n) {
	let r = t.scores?.[n.rid] ?? n.score;
	return t.ranking.findIndex((i) => {
		let a = e.players.find((e) => e.rid === i);
		return a !== void 0 && (t.scores?.[i] ?? a.score) === r && a.desserts.length === n.desserts.length;
	}) + 1;
}
function at({ player: e, kind: t }) {
	let n = u(), r = e.desserts.length, i = n("games.sushigo.dessertCount", { n: r });
	if (t === "fruit") {
		let t = {
			watermelon: 0,
			orange: 0,
			pineapple: 0
		};
		for (let n of e.desserts) {
			let e = n.copyOf ?? n.t;
			if (k(e)) for (let n of V[e]) t[n] += 1;
		}
		return /* @__PURE__ */ v("div", {
			className: "sushigo-score-desserts",
			"aria-label": i,
			children: [/* @__PURE__ */ _("span", { children: i }), B.map((e) => /* @__PURE__ */ v("span", {
				className: "sushigo-score-fruit",
				"aria-label": `${n(nt[e])} ${t[e]}`,
				children: [/* @__PURE__ */ _(Qe, { kind: e }), /* @__PURE__ */ _("b", {
					className: "font-mono tabular-nums",
					children: t[e]
				})]
			}, e))]
		});
	}
	return /* @__PURE__ */ v("div", {
		className: "sushigo-score-desserts",
		"aria-label": i,
		children: [/* @__PURE__ */ _("span", {
			className: "sushigo-score-dessert-art",
			"aria-hidden": !0,
			children: /* @__PURE__ */ _(Y, { type: t === "pudding" ? "pudding" : "gtic" })
		}), /* @__PURE__ */ _("span", { children: i })]
	});
}
function ot({ lines: e }) {
	let t = u();
	return /* @__PURE__ */ _("ul", {
		className: "sushigo-receipt-lines",
		children: e.map((e, n) => /* @__PURE__ */ v("li", { children: [
			/* @__PURE__ */ _("span", {
				className: "sushigo-score-art",
				"aria-hidden": !0,
				children: tt[e.cat] && /* @__PURE__ */ _(Y, { type: tt[e.cat] })
			}),
			/* @__PURE__ */ v("span", {
				className: "sushigo-score-category",
				children: [t(e.cat), e.n !== void 0 && /* @__PURE__ */ v("small", {
					className: "font-mono tabular-nums",
					children: [" ×", e.n]
				})]
			}),
			/* @__PURE__ */ v("b", {
				className: "sushigo-score-delta font-mono tabular-nums",
				"data-negative": e.pts < 0,
				children: [e.pts > 0 ? "+" : "", e.pts]
			})
		] }, `${e.cat}:${n}`))
	});
}
function st({ pub: e, players: t, members: n, myRid: r, nameOf: i, result: o }) {
	let s = u(), c = e.phase === "done", l = e.lastRound?.round ?? e.round;
	return /* @__PURE__ */ v("div", {
		className: `sushigo-score-sheet${t.length >= 5 ? " is-many" : ""}${t.length >= 7 ? " is-full" : ""}`,
		children: [/* @__PURE__ */ _("div", {
			className: "sushigo-table-caption",
			children: /* @__PURE__ */ _("strong", { children: s("games.sushigo.roundBreakdown", { n: l }) })
		}), /* @__PURE__ */ _("div", {
			className: "sushigo-score-list",
			children: t.map((t) => {
				let l = rt(e, t.rid), u = n.find((e) => e.rid === t.rid), p = i(t.rid), m = o?.winner.includes(t.rid) ?? !1, h = o ? it(e, o, t) : 0, y = o?.autopilot?.[t.rid];
				return /* @__PURE__ */ v("section", {
					className: "sushigo-receipt",
					"data-winner": m,
					children: [
						/* @__PURE__ */ v("header", {
							className: "sushigo-receipt-head",
							children: [
								/* @__PURE__ */ v("div", {
									className: "sushigo-receipt-person",
									children: [
										h > 0 && /* @__PURE__ */ _("span", {
											className: "sushigo-score-rank font-mono tabular-nums",
											"aria-label": s("games.sushigo.rank", { n: h }),
											children: h
										}),
										/* @__PURE__ */ v("span", {
											className: "sushigo-score-avatar",
											style: { backgroundColor: f[(u?.colorIndex ?? 0) % f.length].hex },
											children: [u && /* @__PURE__ */ _("img", {
												src: a[u.avatar % a.length],
												alt: "",
												draggable: !1
											}), m && /* @__PURE__ */ _("span", {
												className: "sushigo-score-winner",
												role: "img",
												"aria-label": s("games.sushigo.winner"),
												children: "★"
											})]
										}),
										/* @__PURE__ */ _("h2", {
											title: p,
											children: p
										}),
										t.rid === r && /* @__PURE__ */ _("small", {
											className: "sushigo-score-you",
											children: s("lobby.you")
										})
									]
								}),
								/* @__PURE__ */ v("div", {
									className: "sushigo-receipt-total",
									children: [/* @__PURE__ */ _("span", { children: s(c ? "games.sushigo.finalScore" : "games.sushigo.totalPoints") }), /* @__PURE__ */ _("b", {
										className: "font-mono tabular-nums",
										children: o?.scores?.[t.rid] ?? t.score
									})]
								}),
								y !== void 0 && y > 0 && /* @__PURE__ */ v("span", {
									className: "sushigo-score-autopilot",
									children: [/* @__PURE__ */ _(d, {
										size: 16,
										"aria-hidden": !0
									}), s("session.autopilot.share", { n: Math.round(y * 100) })]
								})
							]
						}),
						l ? /* @__PURE__ */ v(g, { children: [
							/* @__PURE__ */ v("div", {
								className: "sushigo-receipt-subtotal",
								children: [/* @__PURE__ */ _("span", { children: s("games.sushigo.roundPoints") }), /* @__PURE__ */ v("b", {
									className: "font-mono tabular-nums",
									children: [l.roundPoints > 0 ? "+" : "", l.roundPoints]
								})]
							}),
							/* @__PURE__ */ _(ot, { lines: l.main }),
							l.raceBonus !== 0 && /* @__PURE__ */ v("div", {
								className: "sushigo-receipt-bonus",
								children: [
									/* @__PURE__ */ _("span", {
										className: "sushigo-score-art",
										"aria-hidden": !0,
										children: /* @__PURE__ */ _(Y, { type: "uramaki5" })
									}),
									/* @__PURE__ */ _("span", { children: s("games.sushigo.raceBonus") }),
									/* @__PURE__ */ v("b", {
										className: "font-mono tabular-nums",
										children: ["+", l.raceBonus]
									})
								]
							}),
							c && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("div", {
								className: "sushigo-receipt-subtotal sushigo-receipt-subtotal--dessert",
								children: [/* @__PURE__ */ _("span", { children: s("games.sushigo.dessertPoints") }), /* @__PURE__ */ v("b", {
									className: "font-mono tabular-nums",
									children: [l.dessertPoints > 0 ? "+" : "", l.dessertPoints]
								})]
							}), /* @__PURE__ */ _(ot, { lines: l.dessert })] })
						] }) : /* @__PURE__ */ _("p", {
							className: "sushigo-score-missing",
							children: s("games.sushigo.noScoreBreakdown")
						}),
						/* @__PURE__ */ _(at, {
							player: t,
							kind: e.menu.dessert
						})
					]
				}, t.rid);
			})
		})]
	});
}
//#endregion
//#region src/games/sushigo/view-player.tsx
var ct = [];
function lt(e) {
	return /* @__PURE__ */ _(pt, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ut(e, t) {
	return i(e.rid) === null ? e.name : c(t, e.avatar);
}
function dt(e, t) {
	let n = e.findIndex((e) => e.rid === t);
	return n < 0 ? e : [...e.slice(n), ...e.slice(0, n)];
}
function ft(e) {
	return [...new Set(ue(e.menu))].filter((e) => !M(e) && !N(e) && e !== "specialOrder").sort((e, t) => I(e) - I(t));
}
function pt({ pub: e, priv: t, members: i, myRid: a, send: s }) {
	let c = u(), d = l((e) => e.locale), f = (e) => {
		let t = i.find((t) => t.rid === e);
		return t ? ut(t, d) : e;
	}, { ref: y } = o("table"), [b, ee] = r(null), [te, x] = r(null), [S, ne] = r(!1), [re, ie] = r(!1), [C, w] = r(null), [T, D] = r([]), [O, k] = r(null), P = e.players.find((e) => e.rid === a), F = t?.hand ?? ct, ae = F.map((e) => e.id).join(","), I = t?.myPick ?? null, L = F.find((e) => e.id === b) ?? null, R = dt(e.players, a), z = `${e.phase}:${e.round}:${ae}`, [oe, B] = r(z);
	z !== oe && (B(z), ee(null), x(null), ne(!1), ie(!1), w(null), D([]), k(null));
	let V = (P?.tableau ?? []).some((e) => A(e.t) && !e.flipped), se = (P?.tableau ?? []).some((e) => j(e.t) && !e.flipped), ce = L !== null && N(L.t), H = L?.t === "specialOrder", le = new Set((P?.tableau ?? []).filter((t) => !t.flipped && t.turn >= e.roundStartTurn).map((e) => e.id)), ue = new Set((P?.tableau ?? []).filter((e) => e.t !== "specialOrder" && !e.flipped).map((e) => e.id)), de = L && E(L.t) ? P?.tableau.find((e) => e.t === "wasabi" && !e.top && !e.flipped)?.id : void 0, fe = () => {
		if (b === null || I !== null) return;
		let e = {
			type: "pick",
			card: b
		};
		S && te !== null && (e.chop = te), re && C !== null && (e.spoon = C), ce && T.length > 0 && (e.flips = T), H && O !== null && (e.copyTarget = O), s(e);
	}, U, G, he;
	e.phase === "pick" ? (U = I ? "info" : "accent", G = c(I ? "games.sushigo.waitingOthers" : "games.sushigo.phasePick"), he = c("games.sushigo.readyCount", {
		n: e.players.filter((e) => e.picked).length,
		total: e.players.length
	})) : e.phase === "menu" ? (U = t?.menuDrawn == null ? "info" : "accent", G = t?.menuDrawn == null ? c("games.sushigo.waitingOthers") : c("games.sushigo.phaseMenu"), he = e.menuQueue[0] ? f(e.menuQueue[0].rid) : void 0) : e.phase === "roundEnd" ? (U = "info", G = c("games.sushigo.phaseRoundEnd", { n: e.round }), he = c("games.sushigo.readyCount", {
		n: e.confirmed.length,
		total: e.players.length
	})) : (U = "done", G = c("games.sushigo.finalScore"));
	let ge = {
		flippableIds: ce ? le : null,
		flips: T,
		onFlip: (e) => D((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]),
		copyableIds: H ? ue : null,
		copyTarget: O,
		onCopy: k,
		wasabiTargetId: de
	}, _e = (e) => {
		if (S && b !== null && e !== b) {
			x((t) => t === e ? null : e);
			return;
		}
		ee((t) => t === e ? null : e), x(null), D([]), k(null);
	}, ve = /* @__PURE__ */ v("div", {
		className: "sushigo-dock",
		children: [
			/* @__PURE__ */ v("div", {
				className: "sushigo-decision plate",
				children: [
					/* @__PURE__ */ _("span", {
						className: "sushigo-decision-mark",
						"aria-hidden": !0,
						children: I || e.phase === "roundEnd" && e.confirmed.includes(a) ? "✓" : L ? "1" : "·"
					}),
					/* @__PURE__ */ v("span", {
						className: "sushigo-decision-copy",
						children: [/* @__PURE__ */ _("strong", { children: e.phase === "pick" ? I ? `${c("games.sushigo.selected")} ${c(W[I.card.t])}` : L ? `${c("games.sushigo.selected")} ${c(W[L.t])}` : null : e.phase === "menu" ? c("games.sushigo.phaseMenu") : G }), /* @__PURE__ */ _("small", {
							title: L ? c(pe[L.t]) : void 0,
							children: e.phase === "pick" ? I ? c("games.sushigo.waitingOthers") : L ? c(pe[L.t]) : null : e.phase === "menu" ? c("games.sushigo.menuPickHint") : c("games.sushigo.scoreReceipt")
						})]
					}),
					e.phase === "pick" && /* @__PURE__ */ _("button", {
						type: "button",
						className: "sushigo-play-button btn-base",
						onClick: fe,
						disabled: b === null || I !== null || S && te === null || re && C === null,
						children: I ? "✓" : c("games.sushigo.submit")
					}),
					e.phase === "roundEnd" && /* @__PURE__ */ v("button", {
						type: "button",
						className: "sushigo-play-button sushigo-confirm-button btn-base",
						onClick: () => s({ type: "confirm" }),
						disabled: e.confirmed.includes(a),
						children: [/* @__PURE__ */ _("span", {
							className: "sushigo-confirm-width",
							"aria-hidden": !0,
							children: c("games.sushigo.confirm")
						}), /* @__PURE__ */ _("span", { children: e.confirmed.includes(a) ? "✓" : c("games.sushigo.confirm") })]
					})
				]
			}),
			/* @__PURE__ */ v("div", {
				className: "sushigo-tools",
				children: [e.phase === "pick" && I === null ? re ? /* @__PURE__ */ v("div", {
					className: "sushigo-tool-scroll",
					children: [/* @__PURE__ */ _("button", {
						type: "button",
						className: "sushigo-tool sushigo-tool--back",
						onClick: () => {
							ie(!1), w(null);
						},
						children: "‹"
					}), ft(e).map((e) => /* @__PURE__ */ _("button", {
						type: "button",
						className: `sushigo-tool ${C === e ? "is-active" : ""}`,
						"aria-pressed": C === e,
						onClick: () => w(e),
						children: c(W[e])
					}, e))]
				}) : V || se || ce || H ? /* @__PURE__ */ v("div", {
					className: "sushigo-tool-scroll",
					children: [
						V && /* @__PURE__ */ _("button", {
							type: "button",
							className: `sushigo-tool ${S ? "is-active" : ""}`,
							"aria-pressed": S,
							onClick: () => {
								ne((e) => !e), x(null), ie(!1), w(null);
							},
							children: c("games.sushigo.useChopsticks")
						}),
						se && /* @__PURE__ */ _("button", {
							type: "button",
							className: "sushigo-tool",
							onClick: () => {
								ie(!0), ne(!1), x(null);
							},
							children: c("games.sushigo.useSpoon")
						}),
						S && /* @__PURE__ */ _("span", {
							className: "sushigo-tool-note",
							children: c("games.sushigo.chopPrompt")
						}),
						ce && /* @__PURE__ */ _("span", {
							className: "sushigo-tool-note",
							children: c("games.sushigo.takeoutPrompt")
						}),
						H && /* @__PURE__ */ _("span", {
							className: "sushigo-tool-note",
							children: c("games.sushigo.copyPrompt")
						})
					]
				}) : /* @__PURE__ */ _("span", {
					className: "sushigo-hand-heading",
					children: c("games.sushigo.myHand")
				}) : /* @__PURE__ */ _("span", {
					className: "sushigo-hand-heading",
					children: e.phase === "menu" ? c("games.sushigo.menuChoices") : c("games.sushigo.allPlates")
				}), /* @__PURE__ */ _("span", {
					className: "sushigo-hand-count font-mono tabular-nums",
					children: e.phase === "pick" ? F.length : e.phase === "menu" ? t?.menuDrawn?.length ?? 0 : e.players.length
				})]
			}),
			/* @__PURE__ */ v("div", {
				className: "sushigo-hand-strip",
				style: { "--sg-hand-count": Math.max(1, e.phase === "menu" ? t?.menuDrawn?.length ?? 0 : F.length) },
				children: [
					e.phase === "pick" && F.map((e) => {
						let t = e.id === b, n = e.id === te, r = S && b !== null && e.id !== b && (M(e.t) || N(e.t) || e.t === "specialOrder");
						return /* @__PURE__ */ _("button", {
							type: "button",
							className: `sushigo-hand-card ${t ? "is-selected" : ""} ${n ? "is-extra" : ""}`,
							"aria-label": c(W[e.t]),
							"aria-pressed": t || n,
							disabled: I !== null || r,
							onClick: () => _e(e.id),
							children: /* @__PURE__ */ _($e, { t: e.t })
						}, e.id);
					}),
					e.phase === "menu" && (t?.menuDrawn ?? []).map((e) => /* @__PURE__ */ _("button", {
						type: "button",
						className: "sushigo-hand-card",
						"aria-label": c(W[e.t]),
						onClick: () => s({
							type: "menuPick",
							drawnId: e.id
						}),
						children: /* @__PURE__ */ _($e, { t: e.t })
					}, e.id)),
					e.phase === "menu" && t?.menuDrawn == null && /* @__PURE__ */ _("span", {
						className: "sushigo-dock-placeholder",
						children: c("games.sushigo.waitingOthers")
					}),
					(e.phase === "roundEnd" || e.phase === "done") && /* @__PURE__ */ _("div", {
						className: "sushigo-round-summary",
						children: R.map((t) => {
							let n = rt(e, t.rid);
							return /* @__PURE__ */ v("section", {
								className: "sushigo-round-summary-player",
								children: [
									/* @__PURE__ */ _("b", {
										title: f(t.rid),
										children: f(t.rid)
									}),
									/* @__PURE__ */ _("strong", {
										className: "font-mono tabular-nums",
										children: t.score
									}),
									n && /* @__PURE__ */ v("small", { children: [
										c("games.sushigo.roundPoints"),
										" ",
										/* @__PURE__ */ v("b", {
											className: "font-mono tabular-nums",
											children: [n.roundPoints > 0 ? "+" : "", n.roundPoints]
										})
									] }),
									/* @__PURE__ */ _(at, {
										player: t,
										kind: e.menu.dessert
									})
								]
							}, t.rid);
						})
					})
				]
			})
		]
	});
	return /* @__PURE__ */ _("div", {
		className: "sushigo-game",
		"data-phase": e.phase,
		children: /* @__PURE__ */ _(m, {
			adaptive: !0,
			className: "sushigo-adaptive",
			banner: /* @__PURE__ */ _("div", {
				className: "sushigo-banner",
				children: /* @__PURE__ */ _(h, {
					tone: U,
					text: G,
					sub: he,
					chip: `${e.round}/3`,
					accent: me.accent
				})
			}),
			actions: ve,
			actionsHeight: `sushigo-actions-height${e.phase === "roundEnd" ? " sushigo-round-actions-height" : ""}`,
			scroll: !1,
			children: /* @__PURE__ */ v("div", {
				ref: y,
				className: "sushigo-table",
				children: [/* @__PURE__ */ _(p, {
					kind: "sheen",
					base: "#104641",
					className: "sushigo-table-texture"
				}), /* @__PURE__ */ _("div", {
					className: "sushigo-table-scroll",
					children: e.phase === "roundEnd" || e.phase === "done" ? /* @__PURE__ */ _(st, {
						pub: e,
						players: R,
						members: i,
						myRid: a,
						nameOf: f
					}) : /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("div", {
						className: "sushigo-table-caption",
						children: /* @__PURE__ */ v("strong", { children: [
							c("games.sushigo.allPlates"),
							" · ",
							e.players.length
						] })
					}), /* @__PURE__ */ _("div", {
						className: `sushigo-plate-list${R.length >= 5 ? " is-many" : ""}`,
						children: R.map((t, r) => {
							let o = i.find((e) => e.rid === t.rid);
							return /* @__PURE__ */ v(n, { children: [/* @__PURE__ */ _("div", {
								className: "sushigo-plate-slot",
								children: /* @__PURE__ */ _(mt, {
									player: t,
									pub: e,
									member: o,
									name: f(t.rid),
									isMe: t.rid === a,
									isNext: r === 1,
									mine: t.rid === a ? ge : void 0
								})
							}), r < R.length - 1 && /* @__PURE__ */ _("div", {
								className: "sushigo-pass-marker",
								"aria-hidden": !0,
								children: "↓"
							})] }, t.rid);
						})
					})] })
				})]
			})
		})
	});
}
function mt({ player: e, pub: t, member: n, name: r, isMe: c, isNext: l, mine: p }) {
	let m = u(), { ref: h } = o(`seat:${e.rid}`), g = f[(n?.colorIndex ?? 0) % f.length], y = i(e.rid) !== null, b = e.tableau.length;
	return /* @__PURE__ */ v("section", {
		className: `sushigo-plate ${b > 8 ? "is-crowded" : ""} ${e.desserts.length > 0 ? "has-dessert" : ""} ${t.menu.dessert === "fruit" ? "has-fruit" : ""}`,
		"aria-label": `${r} · ${m("games.sushigo.visibleCards")} ${b + e.desserts.length}`,
		children: [
			/* @__PURE__ */ v("header", {
				className: `sushigo-plate-name ${c ? "is-me" : ""}`,
				children: [
					/* @__PURE__ */ v("span", {
						ref: h,
						className: "sushigo-seat-avatar",
						style: { "--sushigo-player-color": g.hex },
						children: [/* @__PURE__ */ _("img", {
							src: a[(n?.avatar ?? 0) % a.length],
							alt: "",
							draggable: !1
						}), y && /* @__PURE__ */ _("span", {
							className: "sushigo-bot-icon",
							title: m("lobby.bot"),
							children: /* @__PURE__ */ _(d, {
								size: 9,
								"aria-hidden": !0
							})
						})]
					}),
					/* @__PURE__ */ v("strong", {
						title: r,
						children: [r, c && /* @__PURE__ */ v("span", {
							className: "sushigo-you",
							children: [" ", m("lobby.you")]
						})]
					}),
					l && /* @__PURE__ */ _("span", {
						className: "sushigo-next-tag",
						children: m("games.sushigo.nextPlayer")
					})
				]
			}),
			/* @__PURE__ */ v("div", {
				className: "sushigo-plate-score",
				children: [/* @__PURE__ */ _(s, {
					value: e.score,
					className: "font-mono tabular-nums"
				}), /* @__PURE__ */ _("span", { children: m("games.sushigo.points") })]
			}),
			/* @__PURE__ */ _("div", {
				className: "sushigo-food-grid",
				children: e.tableau.map((t) => /* @__PURE__ */ _(vt, {
					entry: t,
					tableau: e.tableau,
					mine: p
				}, t.id))
			}),
			/* @__PURE__ */ v("footer", {
				className: "sushigo-plate-status",
				children: [
					t.menu.roll === "uramaki" && /* @__PURE__ */ v("span", {
						className: "sushigo-plate-mini font-mono tabular-nums",
						children: [
							m("games.sushigo.uramakiIcons"),
							" ",
							e.uramakiIcons
						]
					}),
					e.picked && /* @__PURE__ */ _("span", {
						className: "is-ready",
						role: "img",
						"aria-label": m("games.sushigo.ready"),
						children: "✓"
					}),
					e.roundPts !== 0 && /* @__PURE__ */ v("span", {
						className: "sushigo-plate-mini font-mono tabular-nums",
						children: [e.roundPts > 0 ? "+" : "", e.roundPts]
					})
				]
			}),
			/* @__PURE__ */ _(gt, {
				desserts: e.desserts,
				kind: t.menu.dessert,
				name: r
			})
		]
	});
}
var ht = {
	watermelon: "games.sushigo.fruitWatermelon",
	orange: "games.sushigo.fruitOrange",
	pineapple: "games.sushigo.fruitPineapple"
};
function gt({ desserts: e, kind: t, name: n }) {
	let r = u();
	if (e.length === 0) return null;
	let i = e.length;
	if (t === "fruit") {
		let t = {
			watermelon: 0,
			orange: 0,
			pineapple: 0
		};
		for (let n of e) {
			let e = n.copyOf ?? n.t;
			if (k(e)) for (let n of V[e]) t[n] += 1;
		}
		let a = `${n} · ${r("games.sushigo.kindFruit")} ×${i} · ${B.map((e) => `${r(ht[e])} ${t[e]}`).join(" · ")}`;
		return /* @__PURE__ */ v("div", {
			className: "sushigo-dessert-corner sushigo-dessert-corner--fruit",
			role: "img",
			"aria-label": a,
			title: a,
			children: [/* @__PURE__ */ v("span", {
				className: "sushigo-dessert-corner-title",
				children: [r("games.sushigo.kindDessert"), /* @__PURE__ */ v("b", {
					className: "font-mono tabular-nums",
					children: ["×", i]
				})]
			}), B.map((e) => /* @__PURE__ */ v("span", {
				className: "sushigo-fruit-count",
				children: [/* @__PURE__ */ _(Qe, { kind: e }), /* @__PURE__ */ _("b", {
					className: "font-mono tabular-nums",
					children: t[e]
				})]
			}, e))]
		});
	}
	let a = t === "pudding" ? "pudding" : "gtic", o = `${n} · ${r(t === "pudding" ? "games.sushigo.kindPudding" : "games.sushigo.kindGtic")} ×${i}`;
	return /* @__PURE__ */ v("div", {
		className: "sushigo-dessert-corner",
		role: "img",
		"aria-label": o,
		title: o,
		children: [
			/* @__PURE__ */ _("span", {
				className: "sushigo-dessert-corner-title",
				children: r("games.sushigo.kindDessert")
			}),
			/* @__PURE__ */ _("span", {
				className: "sushigo-dessert-corner-art",
				children: /* @__PURE__ */ _(Y, { type: a })
			}),
			/* @__PURE__ */ v("strong", {
				className: "font-mono tabular-nums",
				children: ["×", i]
			})
		]
	});
}
function _t(e, t) {
	if (e.flipped) return "2";
	let n = e.copyOf ?? e.t;
	if (e.top || n === "wasabi") return "×3";
	if (n === "egg") return "+1";
	if (n === "salmon") return "+2";
	if (n === "squid") return "+3";
	if (D(n) || O(n)) return n.slice(-1);
	if (n === "tempura" || n === "sashimi" || n === "dumpling" || n === "eel" || n === "tofu") {
		let e = t.filter((e) => !e.flipped && (e.copyOf ?? e.t) === n).length;
		return n === "tempura" ? `${(e - 1) % 2 + 1}/2` : n === "sashimi" ? `${(e - 1) % 3 + 1}/3` : `${e}`;
	}
	return A(n) || j(n) ? n.slice(-1) : null;
}
function vt({ entry: e, tableau: t, mine: n }) {
	let r = u(), { ref: i, hidden: a } = o(`tcard:${e.id}`), { ref: s, hidden: c } = o(e.top ? `tcard:${e.top.id}` : null), l = e.copyOf ?? e.t, d = n?.flippableIds?.has(e.id) ?? !1, f = n?.copyableIds?.has(e.id) ?? !1, p = n?.flips.includes(e.id) || n?.copyTarget === e.id, m = n?.wasabiTargetId === e.id, h = e.flipped ? r("games.sushigo.flippedCard") : e.top ? r(W[e.top.copyOf ?? e.top.t]) : r(W[l]), g = /* @__PURE__ */ v("div", {
		className: `sushigo-food ${d || f ? "is-target" : ""} ${p ? "is-active" : ""} ${m ? "is-wasabi-target" : ""}`,
		style: a ? { visibility: "hidden" } : void 0,
		children: [/* @__PURE__ */ v("span", {
			ref: i,
			className: "sushigo-food-figure",
			children: [
				e.flipped ? /* @__PURE__ */ _("span", {
					className: "sushigo-food-flipped font-mono tabular-nums",
					children: "2"
				}) : /* @__PURE__ */ _(Y, { type: l }),
				e.top && /* @__PURE__ */ _("span", {
					ref: s,
					className: "sushigo-food-top",
					style: c ? { visibility: "hidden" } : void 0,
					children: /* @__PURE__ */ _(Y, { type: e.top.copyOf ?? e.top.t })
				}),
				e.copyOf && /* @__PURE__ */ _("span", {
					className: "sushigo-copy-stamp",
					"aria-label": r("games.sushigo.copiedCard"),
					children: "⧉"
				}),
				_t(e, t) && /* @__PURE__ */ _("span", {
					className: "sushigo-food-badge font-mono tabular-nums",
					children: _t(e, t)
				})
			]
		}), /* @__PURE__ */ _("span", {
			className: "sushigo-food-label",
			title: h,
			children: h
		})]
	});
	return !d && !f ? g : /* @__PURE__ */ _("button", {
		type: "button",
		className: "sushigo-food-button",
		"aria-label": `${r(d ? "games.sushigo.flipTarget" : "games.sushigo.copyTargetLabel")} ${h}`,
		"aria-pressed": !!p,
		onClick: () => d ? n?.onFlip(e.id) : n?.onCopy(n.copyTarget === e.id ? null : e.id),
		children: g
	});
}
//#endregion
//#region src/games/sushigo/bot.ts
var yt = {
	nigiriW: 1,
	wasabiMult: 3,
	wasabiV: 4,
	makiPerIcon: 1,
	makiLeadMult: 1.2,
	makiLeadGap: 3,
	temakiV: 2.5,
	uraInstantV: 8,
	uraPerIcon: .4,
	uraCloseBonus: 1.5,
	uraCloseGap: 5,
	tempuraPairV: 5,
	tempuraSingleV: 2.5,
	sashimiCompleteV: 10,
	sashimiSecondV: 3,
	sashimiFirstV: 3,
	dumplingW: 1.5,
	eelFirstV: 1,
	eelSecondV: 10,
	eelExtraV: .5,
	tofuFirstV: 2,
	tofuSecondV: 4,
	tofuThirdV: -6,
	onigiriBaseV: 2.5,
	onigiriNewV: 3.5,
	onigiriDupV: .5,
	edamamePerOpp: 1,
	edamameBase: 1,
	misoV: 1,
	teaV: 2.5,
	soyV: 1.5,
	chopsticksV: 3,
	chopsticksDupV: .5,
	spoonV: 1,
	menuV: 2.5,
	takeoutPerFlip: 1,
	takeoutCap: 3,
	specialOrderV: 3.5,
	puddingEarlyV: 1.5,
	puddingLateV: 3,
	gticV: 3,
	gticCompleteV: 12,
	fruitW: 1.5,
	fruitMinV: .5,
	chopPairThreshold: 2,
	copySquidV: 9,
	copySalmonV: 6,
	copyEelV: 7,
	copyUraV: 5,
	copyMakiPerIcon: 2,
	copySetV: 3,
	copyBaseV: 1,
	uraDeadZero: 1,
	makiLock: 1,
	makiLockMult: .2
};
function bt(e) {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e;
}
function xt(e) {
	return e.flipped ? null : e.copyOf ?? e.t;
}
function St(e, t, n, r, i) {
	let a = t.players.find((e) => e.rid === n);
	if (!a) return 0;
	let o = a.tableau.map(xt).filter((e) => e !== null), s = (e) => o.filter(e).length, c = a.tableau.some((e) => e.t === "wasabi" && !e.top && !e.flipped);
	if (E(e)) return z[e] * r.nigiriW * (c ? r.wasabiMult : 1);
	if (e === "wasabi") return r.wasabiV;
	if (D(e)) {
		let a = o.filter(D).reduce((e, t) => e + L[t], 0) - Math.max(0, ...t.players.filter((e) => e.rid !== n).map((e) => e.tableau.map(xt).filter((e) => e !== null && D(e)).reduce((e, t) => e + L[t], 0)));
		return r.makiLock === 1 && a - L[e] > 3 * (i - 1) ? L[e] * r.makiLeadMult * r.makiLockMult : L[e] * (a >= r.makiLeadGap ? r.makiLeadMult : r.makiPerIcon);
	}
	if (e === "temaki") return r.temakiV;
	if (O(e)) {
		if (r.uraDeadZero === 1 && t.uramakiClaims.length >= 3) return 0;
		let n = a.uramakiIcons + R[e];
		return n >= 10 ? r.uraInstantV : R[e] * r.uraPerIcon + (10 - n <= r.uraCloseGap ? r.uraCloseBonus : 0);
	}
	if (e === "tempura") return s((e) => e === "tempura") % 2 == 1 ? r.tempuraPairV : r.tempuraSingleV;
	if (e === "sashimi") {
		let e = s((e) => e === "sashimi") % 3;
		return e === 2 ? r.sashimiCompleteV : e === 1 ? r.sashimiSecondV : r.sashimiFirstV;
	}
	if (e === "dumpling") {
		let e = Math.min(s((e) => e === "dumpling"), 5);
		return e >= 5 ? 0 : (se[e + 1] - se[e]) * r.dumplingW;
	}
	if (e === "eel") {
		let e = s((e) => e === "eel");
		return e === 1 ? r.eelSecondV : e >= 2 ? r.eelExtraV : r.eelFirstV;
	}
	if (e === "tofu") {
		let e = s((e) => e === "tofu");
		return e === 0 ? r.tofuFirstV : e === 1 ? r.tofuSecondV : r.tofuThirdV;
	}
	if (e.startsWith("onigiri_")) {
		let t = new Set(o.filter((e) => e.startsWith("onigiri_")).map((e) => e.slice(8)));
		return t.has(e.slice(8)) ? r.onigiriDupV : t.size + 1 >= 2 ? r.onigiriNewV : r.onigiriBaseV;
	}
	if (e === "edamame") {
		let e = t.players.filter((e) => e.rid !== n && e.tableau.some((e) => xt(e) === "edamame")).length;
		return Math.min(e, 4) * r.edamamePerOpp + (e > 0 ? r.edamameBase : 0);
	}
	if (e === "miso") return r.misoV;
	if (e === "tea") return r.teaV;
	if (e === "soy") return r.soyV;
	if (A(e)) return a.tableau.some((e) => A(e.t) && !e.flipped) ? r.chopsticksDupV : r.chopsticksV;
	if (j(e)) return r.spoonV;
	if (e.startsWith("menu")) return r.menuV;
	if (e.startsWith("takeout")) {
		let e = a.tableau.filter((e) => !e.flipped && e.turn >= t.roundStartTurn).length;
		return Math.min(e, r.takeoutCap) * r.takeoutPerFlip;
	}
	if (e === "specialOrder") return Ct(t, n, r) === null ? 0 : r.specialOrderV;
	if (e === "pudding") return t.round === 3 ? r.puddingLateV : r.puddingEarlyV;
	if (e === "gtic") return a.desserts.filter((e) => (e.copyOf ?? e.t) === "gtic").length % 4 == 3 ? r.gticCompleteV : r.gticV;
	let l = [
		"watermelon",
		"orange",
		"pineapple"
	], u = 0, d = {
		fruit_ww: ["watermelon", "watermelon"],
		fruit_oo: ["orange", "orange"],
		fruit_pp: ["pineapple", "pineapple"],
		fruit_wo: ["watermelon", "orange"],
		fruit_wp: ["watermelon", "pineapple"],
		fruit_op: ["orange", "pineapple"]
	}, f = d[e] ?? [], p = {
		watermelon: 0,
		orange: 0,
		pineapple: 0
	};
	for (let e of a.desserts) for (let t of d[e.copyOf ?? e.t] ?? []) p[t] += 1;
	for (let e of l) {
		let t = f.filter((t) => t === e).length;
		if (t > 0) {
			let n = H[Math.min(p[e], 5)], r = H[Math.min(p[e] + t, 5)];
			u = Math.max(u, r - n);
		}
	}
	return Math.max(u * r.fruitW, r.fruitMinV);
}
function Ct(e, t, n) {
	let r = e.players.find((e) => e.rid === t);
	if (!r) return null;
	let i = null, a = 0;
	for (let e of r.tableau) {
		if (e.t === "specialOrder" || e.flipped) continue;
		let t = e.copyOf ?? e.t, r = t === "squid" ? n.copySquidV : t === "salmon" ? n.copySalmonV : t === "eel" ? n.copyEelV : O(t) ? n.copyUraV : D(t) ? L[t] * n.copyMakiPerIcon : t === "tempura" || t === "sashimi" ? n.copySetV : n.copyBaseV;
		r > a && (a = r, i = e.id);
	}
	return i;
}
function wt(e = {}) {
	let t = {
		...yt,
		...e
	};
	return (e, n) => {
		let r = e.public, i = e.private;
		if (r.phase === "done") return null;
		if (r.phase === "roundEnd") return r.confirmed.includes(n.rid) ? null : { action: { type: "confirm" } };
		if (r.phase === "menu") {
			let e = i?.menuDrawn;
			return !e || e.length === 0 ? null : n.difficulty === "weak" ? { action: {
				type: "menuPick",
				drawnId: e[bt(e.length)].id
			} } : { action: {
				type: "menuPick",
				drawnId: e.reduce((e, i) => St(i.t, r, n.rid, t, 0) > St(e.t, r, n.rid, t, 0) ? i : e).id
			} };
		}
		if (!i || i.myPick) return null;
		let a = i.hand;
		if (a.length === 0) return null;
		if (n.difficulty === "weak") return { action: {
			type: "pick",
			card: a[bt(a.length)].id
		} };
		let o = r.players.find((e) => e.rid === n.rid), s = o?.tableau.some((e) => A(e.t) && !e.flipped) ?? !1, c = a.map((e) => {
			let i = {
				type: "pick",
				card: e.id
			};
			if (e.t.startsWith("takeout") && o && (i.flips = o.tableau.filter((e) => !e.flipped && e.turn >= r.roundStartTurn).map((e) => e.id)), e.t === "specialOrder") {
				let e = Ct(r, n.rid, t);
				e !== null && (i.copyTarget = e);
			}
			return {
				c: e,
				v: St(e.t, r, n.rid, t, a.length),
				action: i
			};
		});
		c.sort((e, t) => t.v - e.v);
		let l = c[0];
		if (s && c.length >= 2) {
			let e = c[1], n = (e) => e.startsWith("menu") || e.startsWith("takeout") || e === "specialOrder";
			if (!n(l.c.t) && !n(e.c.t) && l.v > t.chopPairThreshold && e.v > t.chopPairThreshold) return { action: {
				type: "pick",
				card: l.c.id,
				chop: e.c.id
			} };
		}
		return { action: l.action };
	};
}
var Tt = wt(), Et = (e, t, n) => {
	if (e.type === "confirm") return n("games.sushigo.hintConfirm");
	if (e.type === "menuPick") {
		let r = t.private?.menuDrawn?.find((t) => t.id === e.drawnId);
		return n("games.sushigo.hintMenu", { card: r ? n(W[r.t]) : "?" });
	}
	let r = t.private?.hand.find((t) => t.id === e.card) ?? t.private?.myPick?.card;
	return n("games.sushigo.hintPick", { card: r ? n(W[r.t]) : "?" });
}, Dt = {
	egg: "鸡蛋握寿司",
	salmon: "三文鱼握寿司",
	squid: "鱿鱼握寿司",
	maki1: "寿司卷×1",
	maki2: "寿司卷×2",
	maki3: "寿司卷×3",
	temaki: "手卷",
	uramaki3: "反卷寿司×3",
	uramaki4: "反卷寿司×4",
	uramaki5: "反卷寿司×5",
	tempura: "天妇罗",
	sashimi: "刺身",
	dumpling: "饺子",
	eel: "鳗鱼",
	tofu: "豆腐",
	onigiri_circle: "饭团○",
	onigiri_triangle: "饭团△",
	onigiri_square: "饭团□",
	onigiri_rectangle: "饭团▭",
	edamame: "毛豆",
	miso: "味噌汤",
	chopsticks1: "筷子",
	chopsticks2: "筷子",
	chopsticks3: "筷子",
	soy: "酱油",
	tea: "茶",
	menu7: "菜单",
	menu8: "菜单",
	menu9: "菜单",
	spoon4: "勺子",
	spoon5: "勺子",
	spoon6: "勺子",
	specialOrder: "特别订单",
	takeout10: "打包盒",
	takeout11: "打包盒",
	takeout12: "打包盒",
	wasabi: "山葵",
	pudding: "布丁",
	gtic: "绿茶冰淇淋",
	fruit_ww: "水果🍉🍉",
	fruit_oo: "水果🍊🍊",
	fruit_pp: "水果🍍🍍",
	fruit_wo: "水果🍉🍊",
	fruit_wp: "水果🍉🍍",
	fruit_op: "水果🍊🍍"
}, Ot = {
	egg: "1分",
	salmon: "2分",
	squid: "3分",
	wasabi: "下一张握寿司×3",
	maki: "图标总数比名次 6/3 分",
	temaki: "轮末最多+4 最少−4",
	uramaki: "图标满10立即抢 8/5/2 分",
	tempura: "每2张5分",
	sashimi: "每3张10分",
	dumpling: "1/2/3/4/5+张=1/3/6/10/15分",
	eel: "仅1张−3,2张以上7分",
	tofu: "1张2分,2张6分,3张以上0分",
	onigiri: "不同形状组套,每套1/2/3/4种=1/4/9/16分",
	edamame: "每个也有毛豆的对手使你每张+1分",
	miso: "同回合无人跟打则3分,撞车全弃",
	chopsticks: "留场;之后回合可换回并同时打出两张手牌",
	soy: "卡面颜色种类全场最多才得分,每张×4",
	tea: "每张得分=你数量最多一类卡的张数",
	menu: "从牌堆抽4张选1张立即打出",
	spoon: "点名一种牌,从其他玩家手牌拿一张",
	specialOrder: "复制你场上一张非特别订单牌的效果",
	takeout: "把已打出的牌翻面,每张固定2分",
	pudding: "终局最多+6 最少−6",
	gtic: "终局每4张12分",
	fruit: "终局按图标数查表 −2/0/1/3/6/10"
}, kt = (e) => {
	for (let t of [
		"maki",
		"uramaki",
		"onigiri",
		"chopsticks",
		"menu",
		"spoon",
		"takeout",
		"fruit"
	]) if (e.startsWith(t)) return Ot[t];
	return Ot[e] ?? "";
}, At = (e) => `#${e.id} ${e.t}(${Dt[e.t] ?? e.t})`, jt = {
	needsAction(e, t) {
		let n = e.public;
		return n.phase === "pick" ? (e.private?.hand.length ?? 0) > 0 && e.private?.myPick == null : n.phase === "menu" ? n.menuQueue[0]?.rid === t.rid : n.phase === "roundEnd" && !n.confirmed.includes(t.rid);
	},
	describeView(e, t) {
		let n = e.public, r = [`第 ${n.round}/3 轮。卡类型一律用英文枚举值输出,id 用 # 后的数字。`], i = n.players.find((e) => e.rid === t.rid), a = /* @__PURE__ */ new Set();
		for (let t of e.private?.hand ?? []) a.add(t.t);
		for (let e of n.players) {
			for (let t of e.tableau) a.add(t.t);
			for (let t of e.desserts) a.add(t.t);
		}
		r.push("本局相关牌类: " + [...a].map((e) => `${e}(${Dt[e] ?? e}):${kt(e)}`).join(";")), r.push("各玩家场上:");
		for (let e of n.players) {
			let n = e.rid === t.rid ? "你" : e.rid, i = e.tableau.map((e) => {
				let t = At(e);
				return e.top && (t += `+叠着${Dt[e.top.t] ?? e.top.t}`), e.flipped && (t += "(已翻面=2分)"), t;
			}), a = e.desserts.map((e) => `${Dt[e.t] ?? e.t}`).join(",");
			r.push(`  ${n}(${e.score}分): ${i.join(" ") || "(空)"}${a ? `;甜品: ${a}` : ""}`);
		}
		if (n.phase === "menu" && n.menuQueue[0]?.rid === t.rid) r.push(`你的菜单牌抽到了: ${(e.private?.menuDrawn ?? []).map(At).join(", ")}。选一张立即打出,输出 menuPick 行动。`);
		else if (n.phase === "roundEnd") r.push("本轮结算完毕,确认进入下一轮,输出 confirm 行动。");
		else {
			let t = e.private?.hand ?? [];
			r.push(`你的手牌: ${t.map(At).join(", ")}`), r.push("输出 pick 行动(全员同时暗选,选完同时亮出,剩余手牌传给下家)。"), i?.tableau.some((e) => A(e.t)) && r.push("你场上有筷子:pick 时可带 chop=另一张手牌 id,一并打出。"), t.some((e) => j(e.t)) && r.push("手牌有勺子:以它为主牌时带 spoon=要点名的牌类型。"), t.some((e) => N(e.t)) && r.push("手牌有打包盒:以它为主牌时带 flips=要翻面的自己场上条目 id 数组。"), t.some((e) => e.t === "specialOrder") && r.push("手牌有特别订单:以它为主牌时带 copyTarget=要复制的自己场上条目 id。");
		}
		return r.join("\n");
	},
	actionJsonSchema: { oneOf: [
		{
			type: "object",
			properties: {
				type: { const: "pick" },
				card: {
					type: "integer",
					description: "主选手牌 id"
				},
				chop: {
					type: "integer",
					description: "可选:用筷子额外打出的手牌 id"
				},
				spoon: {
					type: "string",
					description: "可选:主牌是勺子时点名的牌类型"
				},
				flips: {
					type: "array",
					items: { type: "integer" },
					description: "可选:主牌是打包盒时要翻面的自己场上条目 id"
				},
				copyTarget: {
					type: "integer",
					description: "可选:主牌是特别订单时要复制的自己场上条目 id"
				}
			},
			required: ["type", "card"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "menuPick" },
				drawnId: { type: "integer" }
			},
			required: ["type", "drawnId"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "confirm" } },
			required: ["type"],
			additionalProperties: !1
		}
	] },
	parseAction(e, t, n) {
		let r = xe.safeParse(e);
		if (!r.success) return null;
		let i = r.data, a = t.public, o = a.players.find((e) => e.rid === n.rid);
		if (!o) return null;
		if (i.type === "confirm") return a.phase === "roundEnd" && !a.confirmed.includes(n.rid) ? i : null;
		if (i.type === "menuPick") return a.phase !== "menu" || a.menuQueue[0]?.rid !== n.rid ? null : (t.private?.menuDrawn ?? []).some((e) => e.id === i.drawnId) ? i : null;
		if (a.phase !== "pick" || t.private?.myPick != null) return null;
		let s = t.private?.hand ?? [], c = s.find((e) => e.id === i.card);
		if (!c || P(c.t)) return null;
		if (i.chop != null) {
			let e = s.find((e) => e.id === i.chop);
			if (!e || !A(e.t) || !o.tableau.some((e) => A(e.t))) return null;
		}
		if (i.spoon != null && !j(c.t)) return null;
		if (i.flips != null) {
			if (!N(c.t)) return null;
			let e = new Set(o.tableau.map((e) => e.id));
			if (!i.flips.every((t) => e.has(t))) return null;
		}
		if (i.copyTarget != null) {
			if (c.t !== "specialOrder") return null;
			let e = o.tableau.find((e) => e.id === i.copyTarget);
			if (!e || e.t === "specialOrder") return null;
		}
		return i;
	}
}, X = (e, t, n) => Math.max(t, Math.min(n, e));
function Mt(e, t) {
	return e.w > 0 && e.h > 0 && e.x >= t.x && e.y >= t.y && e.x + e.w <= t.x + t.w + .5 && e.y + e.h <= t.y + t.h + .5;
}
function Z(e, t) {
	let n = e.anchor("table"), r = e.anchor(t);
	return n && r && Mt(r, n) ? r : null;
}
function Q(e, t, n, r) {
	let i = Math.min(1, r.w / t, r.h / n), a = t * i, o = n * i;
	return {
		x: X(e.x + (e.w - a) / 2, r.x, r.x + r.w - a),
		y: X(e.y + (e.h - o) / 2, r.y, r.y + r.h - o),
		w: a,
		h: o
	};
}
function Nt(e, t) {
	let n = e.anchor("table");
	return Math.min(X(t.w * 1.7, 32, 84), (n?.h ?? 168) / 2);
}
function Pt({ type: e, size: t }) {
	return /* @__PURE__ */ _("span", {
		className: "sushigo-fx-food",
		style: {
			width: t,
			height: t
		},
		children: /* @__PURE__ */ _(Y, { type: e })
	});
}
function Ft({ types: e, value: t, size: n }) {
	return /* @__PURE__ */ v("span", {
		className: "sushigo-fx-note",
		style: { fontSize: X(n * .45, 16, 32) },
		children: [e.map((e, t) => /* @__PURE__ */ _(Pt, {
			type: e,
			size: n
		}, `${e}:${t}`)), t !== void 0 && /* @__PURE__ */ _("b", { children: t })]
	});
}
function $(e, t, n, r, i, a = i - 50) {
	let o = t ? Z(e, `seat:${t}`) : null;
	return o ? {
		ms: e.queued > 0 ? 220 : i,
		node: /* @__PURE__ */ _(y, {
			at: o,
			ms: e.queued > 0 ? 180 : a,
			children: /* @__PURE__ */ _(Ft, {
				types: n,
				value: r,
				size: Nt(e, o)
			})
		})
	} : null;
}
var It = {
	deal(e, t) {
		let n = t.anchor("table"), r = e.rid ? Z(t, `seat:${e.rid}`) : null;
		if (!n || !r) return null;
		let i = X(r.w * 2, 44, 96), a = Q(n, i, i * 46 / 34, n), o = Q(r, a.w, a.h, n), s = t.queued > 0 ? 160 : 320;
		return {
			ms: s + 20,
			node: /* @__PURE__ */ _(b, {
				from: a,
				to: o,
				ms: s,
				children: /* @__PURE__ */ _("span", {
					className: "sushigo-fx-back",
					style: {
						width: a.w,
						height: a.h
					},
					"aria-hidden": !0,
					children: "✦"
				})
			})
		};
	},
	reveal(e, t) {
		let n = e.data?.plays ?? [], r = t.anchor("table");
		if (!r) return null;
		let i = t.queued > 0, a = i ? 180 : 380, o = [], s = n.map((e, n) => {
			let s = Z(t, `seat:${e.rid}`);
			if (!s) return null;
			let c = e.dest == null ? null : Z(t, `tcard:${e.dest}`);
			if (e.dest != null && !c) return null;
			let l = Nt(t, s), u = Q(s, l, l, r), d = c ? Q(c, Math.min(c.w, c.h), Math.min(c.w, c.h), r) : u;
			return c && !i && o.push(`tcard:${e.dest}`), /* @__PURE__ */ _(b, {
				from: u,
				to: d,
				ms: a,
				delay: i ? 0 : n * 90,
				children: /* @__PURE__ */ _(Pt, {
					type: e.card,
					size: u.w
				})
			}, e.rid);
		}).filter(Boolean);
		return s.length ? {
			ms: a + (i ? 0 : n.length * 90),
			node: /* @__PURE__ */ _(g, { children: s }),
			hide: o
		} : null;
	},
	uramaki(e, t) {
		let n = e.data;
		return typeof n?.pts != "number" || typeof n?.place != "number" ? null : $(t, e.rid, ["uramaki5"], `+${n.pts}`, 1100, 1e3);
	},
	misoOut(e, t) {
		let n = t.anchor("table");
		if (!n) return null;
		let r = Math.min(X(n.w * .1, 52, 128), n.h * .45), i = Q(n, r, r, n);
		return {
			ms: t.queued > 0 ? 220 : 900,
			node: /* @__PURE__ */ _("span", {
				className: "absolute",
				style: {
					left: i.x,
					top: i.y
				},
				children: /* @__PURE__ */ _(Ft, {
					types: ["miso"],
					value: "×",
					size: r
				})
			})
		};
	},
	spoonHit(e, t) {
		let n = e.data;
		if (typeof n?.card != "string") return null;
		let r = t.anchor("table"), i = typeof n.from == "string" ? Z(t, `seat:${n.from}`) : null, a = e.rid ? Z(t, `seat:${e.rid}`) : null;
		if (!r || !i || !a || t.queued > 0) return $(t, e.rid, ["spoon4", n.card], void 0, 900);
		let o = Nt(t, a), s = Q(i, o, o, r), c = Q(a, o, o, r);
		return {
			ms: 900,
			node: /* @__PURE__ */ _(b, {
				from: s,
				to: c,
				ms: 850,
				children: /* @__PURE__ */ _(Pt, {
					type: n.card,
					size: o
				})
			})
		};
	},
	spoonMiss(e, t) {
		return $(t, e.rid, ["spoon4"], "×", 800);
	},
	chopUsed(e, t) {
		let n = e.data;
		return typeof n?.card == "string" ? $(t, e.rid, ["chopsticks1", n.card], void 0, 800) : null;
	},
	menuPick(e, t) {
		let n = e.data;
		return typeof n?.card == "string" ? $(t, e.rid, ["menu7", n.card], void 0, 800) : null;
	},
	takeout(e, t) {
		let n = e.data;
		return $(t, e.rid, ["takeout10"], typeof n?.count == "number" ? `×${n.count}` : void 0, 800);
	},
	roundScore(e, t) {
		let n = t.anchor("table");
		if (!n) return null;
		let r = t.queued > 0 ? 220 : 700, i = {
			x: n.x + 4,
			y: n.y + 4,
			w: Math.max(1, n.w - 8),
			h: Math.max(1, n.h - 8)
		};
		return {
			ms: r,
			node: /* @__PURE__ */ _(ee, {
				at: i,
				ms: r
			})
		};
	}
};
function Lt(e) {
	return (t, n) => {
		let r = e(t, n), i = n.anchor("table");
		if (!r || !i) return null;
		let a = `inset(${i.y}px calc(100% - ${i.x + i.w}px) calc(100% - ${i.y + i.h}px) ${i.x}px)`;
		return {
			...r,
			node: /* @__PURE__ */ _("div", {
				className: "absolute inset-0",
				style: { clipPath: a },
				children: r.node
			})
		};
	};
}
var Rt = Object.fromEntries(Object.entries(It).map(([e, t]) => [e, Lt(t)]));
//#endregion
//#region src/games/sushigo/game-over.tsx
function zt({ public: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let o = e, s = u(), c = l((e) => e.locale), d = t.ranking.flatMap((e) => {
		let t = o.players.find((t) => t.rid === e);
		return t ? [t] : [];
	});
	return /* @__PURE__ */ _("div", {
		className: "sushigo-game sushigo-over",
		children: /* @__PURE__ */ _(m, {
			adaptive: !0,
			className: "sushigo-over-adaptive",
			scroll: !1,
			banner: /* @__PURE__ */ v("header", {
				className: "sushigo-over-heading",
				children: [
					/* @__PURE__ */ _("span", {
						"aria-hidden": !0,
						children: "✦"
					}),
					/* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("small", { children: s("games.sushigo.name") }), /* @__PURE__ */ _("h1", { children: s("games.sushigo.finalScore") })] }),
					/* @__PURE__ */ _("span", {
						"aria-hidden": !0,
						children: "✦"
					})
				]
			}),
			actionsHeight: "sushigo-over-actions-height",
			actions: /* @__PURE__ */ v("div", {
				className: "sushigo-over-actions",
				children: [
					i && /* @__PURE__ */ _("button", {
						type: "button",
						className: "sushigo-over-play btn-base",
						onClick: i,
						children: s("session.result.playAgain")
					}),
					a && /* @__PURE__ */ _("button", {
						type: "button",
						className: "sushigo-over-back btn-quiet",
						onClick: a,
						children: s("session.result.backToLobby")
					}),
					!i && !a && /* @__PURE__ */ _("p", { children: s("session.result.waitHost") })
				]
			}),
			children: /* @__PURE__ */ _("div", {
				className: "sushigo-over-scroll",
				children: /* @__PURE__ */ _(st, {
					pub: o,
					players: d,
					members: n,
					myRid: r,
					nameOf: (e) => {
						let t = n.find((t) => t.rid === e);
						return t ? te(t, c) : e;
					},
					result: t
				})
			})
		})
	});
}
//#endregion
//#region src/games/sushigo/options.tsx
var Bt = {
	myFirstMeal: "games.sushigo.menuMyFirstMeal",
	sushiGo: "games.sushigo.menuSushiGo",
	partySampler: "games.sushigo.menuPartySampler",
	masterMenu: "games.sushigo.menuMasterMenu",
	pointsPlatter: "games.sushigo.menuPointsPlatter",
	cutthroatCombo: "games.sushigo.menuCutthroatCombo",
	bigBanquet: "games.sushigo.menuBigBanquet",
	dinnerForTwo: "games.sushigo.menuDinnerForTwo"
}, Vt = {
	maki: "games.sushigo.kindMaki",
	temaki: "games.sushigo.kindTemaki",
	uramaki: "games.sushigo.kindUramaki"
}, Ht = {
	tempura: "games.sushigo.catTempura",
	sashimi: "games.sushigo.catSashimi",
	dumpling: "games.sushigo.catDumpling",
	eel: "games.sushigo.catEel",
	tofu: "games.sushigo.catTofu",
	onigiri: "games.sushigo.catOnigiri",
	edamame: "games.sushigo.catEdamame",
	miso: "games.sushigo.catMiso"
}, Ut = {
	chopsticks: "games.sushigo.kindChopsticks",
	soy: "games.sushigo.kindSoy",
	tea: "games.sushigo.kindTea",
	menu: "games.sushigo.kindMenu",
	spoon: "games.sushigo.kindSpoon",
	specialOrder: "games.sushigo.kindSpecialOrder",
	takeout: "games.sushigo.kindTakeout",
	wasabi: "games.sushigo.kindWasabi"
}, Wt = {
	pudding: "games.sushigo.kindPudding",
	gtic: "games.sushigo.kindGtic",
	fruit: "games.sushigo.kindFruit"
}, Gt = {
	maki: "maki2",
	temaki: "temaki",
	uramaki: "uramaki4"
}, Kt = {
	tempura: "tempura",
	sashimi: "sashimi",
	dumpling: "dumpling",
	eel: "eel",
	tofu: "tofu",
	onigiri: "onigiri_triangle",
	edamame: "edamame",
	miso: "miso"
}, qt = {
	chopsticks: "chopsticks1",
	soy: "soy",
	tea: "tea",
	menu: "menu7",
	spoon: "spoon4",
	specialOrder: "specialOrder",
	takeout: "takeout10",
	wasabi: "wasabi"
}, Jt = {
	pudding: "pudding",
	gtic: "gtic",
	fruit: "fruit_wo"
};
function Yt(e, t) {
	return e.roll === t.roll && e.dessert === t.dessert && e.appetizers.length === t.appetizers.length && e.appetizers.every((e) => t.appetizers.includes(e)) && e.specials.length === t.specials.length && e.specials.every((e) => t.specials.includes(e));
}
function Xt(e, t, n) {
	return e.includes(t) ? e : [...e.slice(Math.max(0, e.length - n + 1)), t];
}
function Zt({ value: e, onChange: t }) {
	let n = u(), r = be.safeParse(e), i = r.success ? r.data : be.parse(void 0), a = Object.keys(C).find((e) => Yt(C[e], i)), o = i.specials.includes("menu") || i.specials.includes("specialOrder"), s = i.specials.includes("spoon") || i.appetizers.includes("edamame"), c = (e, t, n, r, i, a) => /* @__PURE__ */ v("button", {
		type: "button",
		"aria-pressed": t,
		onClick: n,
		className: `sushigo-menu-choice kind-${e} ${t ? "is-active" : ""} ${a ? "has-art" : ""}`,
		style: t ? { "--sushigo-choice-color": me.accent } : void 0,
		children: [
			/* @__PURE__ */ _("span", {
				className: "sushigo-menu-indicator",
				"aria-hidden": !0,
				children: t ? e === "single" ? /* @__PURE__ */ _("i", {}) : "✓" : null
			}),
			a && /* @__PURE__ */ _("span", {
				className: "sushigo-menu-choice-art",
				children: /* @__PURE__ */ _(Y, { type: a })
			}),
			/* @__PURE__ */ _("span", { children: r })
		]
	}, i);
	return /* @__PURE__ */ v("div", {
		className: "sushigo-game sushigo-menu",
		children: [
			/* @__PURE__ */ v("div", {
				className: "sushigo-menu-board",
				children: [/* @__PURE__ */ _("header", { children: /* @__PURE__ */ _("strong", { children: n("games.sushigo.menuBoardTitle") }) }), /* @__PURE__ */ _("div", {
					className: "sushigo-menu-preview",
					children: [
						{
							key: "roll",
							label: n("games.sushigo.kindRoll"),
							art: Gt[i.roll],
							name: n(Vt[i.roll])
						},
						...i.appetizers.map((e, t) => ({
							key: `app-${t}`,
							label: n("games.sushigo.kindAppetizer"),
							art: Kt[e],
							name: n(Ht[e])
						})),
						...i.specials.map((e, t) => ({
							key: `spec-${t}`,
							label: n("games.sushigo.kindSpecial"),
							art: qt[e],
							name: n(Ut[e])
						})),
						{
							key: "dessert",
							label: n("games.sushigo.kindDessert"),
							art: Jt[i.dessert],
							name: n(Wt[i.dessert])
						}
					].map((e) => /* @__PURE__ */ v("div", {
						className: "sushigo-menu-slot",
						children: [
							/* @__PURE__ */ _("span", {
								className: "sushigo-menu-slot-art",
								children: /* @__PURE__ */ _(Y, { type: e.art })
							}),
							/* @__PURE__ */ _("small", { children: e.label }),
							/* @__PURE__ */ _("b", {
								title: e.name,
								children: e.name
							})
						]
					}, e.key))
				})]
			}),
			/* @__PURE__ */ v("div", {
				className: "sushigo-menu-presets",
				children: [Object.keys(C).map((e) => c("single", a === e, () => t(C[e]), n(Bt[e]), e)), c("single", !a, () => t({ ...i }), n("games.sushigo.menuCustom"), "custom")]
			}),
			(o || s) && /* @__PURE__ */ v("div", {
				className: "flex flex-col gap-1 rounded-lg border-2 border-ink bg-warn-soft px-2 py-1.5 text-[11px] leading-4 font-bold text-warn-ink",
				children: [o && /* @__PURE__ */ _("p", { children: n("games.sushigo.menuIllegal78") }), s && /* @__PURE__ */ _("p", { children: n("games.sushigo.menuIllegal2") })]
			}),
			/* @__PURE__ */ _("p", {
				className: "section-label",
				children: n("games.sushigo.menuPickRoll")
			}),
			/* @__PURE__ */ _("div", {
				className: "sushigo-menu-choices",
				children: x.map((e) => c("single", i.roll === e, () => t({
					...i,
					roll: e
				}), n(Vt[e]), e, Gt[e]))
			}),
			/* @__PURE__ */ _("p", {
				className: "section-label",
				children: n("games.sushigo.menuPickAppetizers")
			}),
			/* @__PURE__ */ _("div", {
				className: "sushigo-menu-choices",
				children: S.map((e) => c("multi", i.appetizers.includes(e), () => t({
					...i,
					appetizers: Xt(i.appetizers, e, 3)
				}), n(Ht[e]), e, Kt[e]))
			}),
			/* @__PURE__ */ _("p", {
				className: "section-label",
				children: n("games.sushigo.menuPickSpecials")
			}),
			/* @__PURE__ */ _("div", {
				className: "sushigo-menu-choices",
				children: ne.map((e) => c("multi", i.specials.includes(e), () => t({
					...i,
					specials: Xt(i.specials, e, 2)
				}), n(Ut[e]), e, qt[e]))
			}),
			/* @__PURE__ */ _("p", {
				className: "section-label",
				children: n("games.sushigo.menuPickDessert")
			}),
			/* @__PURE__ */ _("div", {
				className: "sushigo-menu-choices",
				children: re.map((e) => c("single", i.dessert === e, () => t({
					...i,
					dessert: e
				}), n(Wt[e]), e, Jt[e]))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/sushigo/entry.tsx
var Qt = {
	definition: Je,
	View: lt,
	bot: Tt,
	describe: Et,
	llm: jt,
	fx: Rt,
	OverView: zt,
	Options: Zt,
	locales: {
		zh: {
			name: "寿司狗派对",
			desc: "传牌点餐的寿司盛宴,自定义菜单,2-8 人",
			rules: "目标:\n· 三轮过后总分最高者获胜。每轮从手牌选一张留下,其余传给下家,循环到手牌打空。\n\n准备:\n· 主机选定菜单(8 套预置或自定义),握寿司与山葵（常称日式芥末）固定。\n· 卷类 3 选 1、开胃菜 8 选 3、特殊牌 8 选 2、甜品 3 选 1。\n· 每轮按人数发牌:2-3 人 10 张,4-5 人 9 张。\n· 6-7 人 8 张,8 人 7 张;该轮的甜品牌混入牌堆。\n\n流程:\n· 每人同时从手牌选一张扣下,全员选定后同时亮出,剩余手牌传给左手边玩家。\n· 握寿司打出时若自己场上有空山葵,自动叠上去(分数翻三倍)。\n· 场上已打出的筷子/勺子,之后回合可随主牌声明使用,每回合限用一张。\n· 筷子 = 额外再打出一张手牌;勺子 = 点名一种牌,左手边起第一个有它的玩家交给你。\n· 菜单牌亮出后从牌堆顶抽 4 张,选 1 张立即打出。\n· 打包盒可翻回自己本轮已打出的牌,每张翻面的值 2 分。\n· 特别订单复制自己场上一张牌的效果。\n· 味噌汤同回合被两人以上打出则全部作废;反卷寿司累计满 10 个图标立即抢名次(8/5/2 分)。\n\n结算:\n· 每轮末结算卷类、开胃菜与特殊牌分数;甜品留到终局,平分比甜品数量。\n· 布丁最多者获得 6 分、最少者扣 6 分(2 人免罚)。\n· 绿茶冰淇淋每 4 张 12 分;水果按类查表。",
			phasePick: "选一张牌打出",
			phaseMenu: "菜单:选一张立即打出",
			phaseRoundEnd: "第 {{n}} 轮结算",
			waitingOthers: "等待其他玩家…",
			confirm: "看好了,下一轮",
			useChopsticks: "用筷子",
			useSpoon: "用勺子",
			spoonPrompt: "点名一种牌",
			chopPrompt: "再选一张手牌",
			takeoutPrompt: "可翻回本轮已打出的牌(每张 2 分)",
			copyPrompt: "选择要复制的牌",
			noCopy: "不复制(弃置)",
			submit: "打出",
			uramakiRace: "反卷寿司竞速",
			readyCount: "{{n}} / {{total}} 人已选好",
			allPlates: "全员餐盘",
			nextPlayer: "下家",
			myHand: "我的手牌",
			selected: "已选",
			ready: "已选好",
			visibleCards: "公开餐牌",
			flippedCard: "翻面牌",
			copiedCard: "复制牌",
			flipTarget: "翻回",
			copyTargetLabel: "复制",
			points: "分",
			uramakiIcons: "反卷寿司",
			menuChoices: "菜单抽牌",
			menuPickHint: "从抽到的牌中选一张立即摆盘",
			scoreReceipt: "逐菜品查看本轮得分",
			finalScore: "终局总分",
			roundBreakdown: "第 {{n}} 轮明细",
			roundPoints: "本轮得分",
			totalPoints: "累计得分",
			raceBonus: "抢位奖励",
			dessertPoints: "甜品得分",
			dessertCount: "甜品 {{n}} 张",
			noScoreBreakdown: "暂无计分明细",
			winner: "获胜",
			rank: "第 {{n}} 名",
			helpEgg: "鸡蛋握寿司:1 分。打在山葵上则翻三倍。",
			helpSalmon: "三文鱼握寿司:2 分。打在山葵上则翻三倍。",
			helpSquid: "鱿鱼握寿司:3 分。打在山葵上则翻三倍。",
			helpWasabi: "山葵:本身 0 分,之后打上的第一张握寿司 ×3。",
			helpMaki: "寿司卷:比 🍥 图标总数,按名次得 6/3 分(6 人及以上 6/4/2);并列同拿该档分。",
			helpTemaki: "手卷:轮末最多 +4、最少 −4;全员打平都不得分,2 人局最少免罚。",
			helpUramaki: "反卷寿司:图标攒满 10 个立即抢名次 8/5/2 分并清空;轮末仍有空位,则图标最多者拿下一名次(并列同得)。",
			helpTempura: "天妇罗:每凑 2 张得 5 分。",
			helpSashimi: "刺身:每凑 3 张得 10 分。",
			helpDumpling: "饺子:1/2/3/4/5+ 张 = 1/3/6/10/15 分。",
			helpEel: "鳗鱼:只 1 张 −3 分;2 张及以上 7 分。",
			helpTofu: "豆腐:1 张 2 分、2 张 6 分;3 张及以上 0 分。",
			helpOnigiri: "饭团:按不同形状组套,每套 1/2/3/4 种形状 = 1/4/9/16 分,可组多套。",
			helpEdamame: "毛豆:每个同样打出毛豆的对手让你每张毛豆 +1 分(最多按 4 人算);只有自己有则 0 分。",
			helpMiso: "味噌汤:打出时若同回合无人跟着打,得 3 分;撞车则全部弃掉。",
			helpSoy: "酱油:卡面颜色种类全场最多(可并列)才得分,每张酱油 ×4 分。",
			helpTea: "茶:每张茶的得分 = 你数量最多的一类卡的张数(含本轮甜品)。",
			helpMenu: "菜单:立即从牌堆抽 4 张,选 1 张打出。",
			helpSpoon: "勺子:点名一种牌,左手边起第一个手牌里有它的玩家交给你;没人有则落空。",
			helpChopsticks: "筷子:留在场上;之后回合可声明使用,将它换回手牌,并同时打出两张手牌。",
			helpSpecialOrder: "特别订单:复制一张你已打出的非特别订单牌,继承其计分。",
			helpTakeout: "打包盒:把任意张已打出的牌翻面,翻面的牌每张固定 2 分。",
			helpPudding: "布丁:终局结算,最多 +6、最少 −6(2 人局免罚);并列比数量平分。",
			helpGtic: "绿茶冰淇淋:终局结算,每凑 4 张得 12 分。",
			helpFruit: "水果:终局按图标总数计分(🍉2 🍊2 🍍1),0/1/2/3/4/5+ 个 = −2/0/1/3/6/10 分。",
			catMaki: "寿司卷",
			catTemaki: "手卷",
			catUramaki: "反卷寿司",
			catNigiri: "握寿司",
			catTempura: "天妇罗",
			catSashimi: "刺身",
			catDumpling: "饺子",
			catEel: "鳗鱼",
			catTofu: "豆腐",
			catOnigiri: "饭团",
			catEdamame: "毛豆",
			catMiso: "味噌汤",
			catTea: "茶",
			catSoy: "酱油",
			catTakeout: "打包盒",
			catPudding: "布丁",
			catGtic: "绿茶冰淇淋",
			catFruit: "水果",
			cardEgg: "鸡蛋握寿司",
			cardSalmon: "三文鱼握寿司",
			cardSquid: "鱿鱼握寿司",
			cardMaki1: "寿司卷 ×1",
			cardMaki2: "寿司卷 ×2",
			cardMaki3: "寿司卷 ×3",
			cardTemaki: "手卷",
			cardUramaki3: "反卷寿司 ×3",
			cardUramaki4: "反卷寿司 ×4",
			cardUramaki5: "反卷寿司 ×5",
			cardTempura: "天妇罗",
			cardSashimi: "刺身",
			cardDumpling: "饺子",
			cardEel: "鳗鱼",
			cardTofu: "豆腐",
			cardOnigiriCircle: "圆饭团",
			cardOnigiriTriangle: "三角饭团",
			cardOnigiriSquare: "方饭团",
			cardOnigiriRectangle: "长饭团",
			cardEdamame: "毛豆",
			cardMiso: "味噌汤",
			cardChopsticks: "筷子",
			cardSoy: "酱油",
			cardTea: "茶",
			cardMenu: "菜单",
			cardSpoon: "勺子",
			cardSpecialOrder: "特别订单",
			cardTakeout: "打包盒",
			cardWasabi: "山葵",
			cardPudding: "布丁",
			cardGtic: "绿茶冰淇淋",
			cardFruitWw: "双西瓜",
			cardFruitOo: "双橙",
			cardFruitPp: "双菠萝",
			cardFruitWo: "西瓜橙",
			cardFruitWp: "西瓜菠萝",
			cardFruitOp: "橙菠萝",
			kindNigiri: "握寿司",
			kindRoll: "卷类",
			kindAppetizer: "开胃菜",
			kindSpecial: "特殊牌",
			kindDessert: "甜品",
			kindMaki: "寿司卷",
			kindTemaki: "手卷",
			kindUramaki: "反卷寿司",
			kindChopsticks: "筷子",
			kindSoy: "酱油",
			kindTea: "茶",
			kindMenu: "菜单",
			kindSpoon: "勺子",
			kindSpecialOrder: "特别订单",
			kindTakeout: "打包盒",
			kindWasabi: "山葵",
			kindPudding: "布丁",
			kindGtic: "绿茶冰淇淋",
			kindFruit: "水果",
			fruitWatermelon: "西瓜",
			fruitOrange: "橙子",
			fruitPineapple: "菠萝",
			menuBoardTitle: "本局菜单",
			menuMyFirstMeal: "第一餐",
			menuSushiGo: "寿司狗经典",
			menuPartySampler: "派对拼盘",
			menuMasterMenu: "大师菜单",
			menuPointsPlatter: "得分大拼盘",
			menuCutthroatCombo: "激烈角逐",
			menuBigBanquet: "盛大宴会",
			menuDinnerForTwo: "双人晚餐",
			menuCustom: "自定义菜单",
			menuPickRoll: "卷类(选 1)",
			menuPickAppetizers: "开胃菜(选 3)",
			menuPickSpecials: "特殊牌(选 2)",
			menuPickDessert: "甜品(选 1)",
			menuIllegal78: "菜单/特别订单不支持 7-8 人局",
			menuIllegal2: "勺子/毛豆不支持 2 人局",
			errNotYourTurn: "现在不能这么操作",
			errAlreadyPicked: "本回合已提交",
			errBadCard: "无效的牌",
			errBadBonusCard: "这张牌不能这样用",
			errNoBonus: "场上没有可用的筷子/勺子",
			errBadFlip: "只能翻回本轮内此前回合打出的牌",
			errBothBonus: "每回合限用一张奖励牌",
			fxMisoOut: "味噌汤相撞,全部作废!",
			fxUramaki: "抢下反卷寿司第 {{n}} 名!",
			fxSpoonMiss: "没人有这张牌,勺子落空",
			botDesc: "会按边际收益选牌、记甜品数",
			hintPick: "建议打出「{{card}}」",
			hintMenu: "建议从菜单里拿「{{card}}」",
			hintConfirm: "确认结算,进入下一轮"
		},
		en: {
			name: "Sushi Go Party!",
			desc: "Draft-and-pass sushi feast with custom menus, 2-8 players",
			rules: "Goal:\n· Highest total score after 3 rounds wins. Each round, pick a card from your hand and pass the rest left until hands run out.\n\nSetup:\n· The host picks a menu (8 presets or custom); nigiri and wasabi are always in.\n· Pick 1 roll of 3, 3 appetizers of 8, 2 specials of 8, and 1 dessert of 3.\n· Deal by player count: 10 cards for 2-3 players, 9 for 4-5.\n· 8 cards for 6-7 players, 7 for 8; shuffle that round's desserts into the deck.\n\nPlay:\n· Everyone secretly picks a card, then all reveal at once; remaining hands pass left.\n· Nigiri played onto a free wasabi on your board scores triple.\n· Chopsticks/spoon already on your board can be declared with a later pick, one bonus card per turn.\n· Chopsticks = play a second card from hand; spoon = name a card and the first player to your left holding it hands it to you.\n· Menu: draw 4 from the deck and play 1 immediately.\n· Takeout box: flip back your cards from this round; each flipped card is worth 2 points.\n· Special order: copy the effect of a card on your board.\n· Miso soup played by 2+ players in the same turn is discarded; uramaki claims 8/5/2 race bonuses at 10 icons.\n\nScoring:\n· Rolls, appetizers and specials score each round; desserts score at game end; ties break on dessert count.\n· Pudding: most scores 6, fewest loses 6 (no penalty with 2 players).\n· Green tea ice cream scores 12 per 4 cards; fruit scores by table.",
			phasePick: "Pick a card to play",
			phaseMenu: "Menu: play one card now",
			phaseRoundEnd: "Round {{n}} scoring",
			waitingOthers: "Waiting for others…",
			confirm: "Got it, next round",
			useChopsticks: "Use chopsticks",
			useSpoon: "Use spoon",
			spoonPrompt: "Name a card",
			chopPrompt: "Pick a second card",
			takeoutPrompt: "Flip back your cards from this round (2 pts each)",
			copyPrompt: "Choose a card to copy",
			noCopy: "Copy nothing (discard)",
			submit: "Play",
			uramakiRace: "Uramaki race",
			readyCount: "{{n}} / {{total}} ready",
			allPlates: "Everyone’s plates",
			nextPlayer: "Next",
			myHand: "My hand",
			selected: "Selected",
			ready: "Ready",
			visibleCards: "visible cards",
			flippedCard: "Flipped card",
			copiedCard: "Copied card",
			flipTarget: "Flip",
			copyTargetLabel: "Copy",
			points: "pts",
			uramakiIcons: "Uramaki",
			menuChoices: "Menu draw",
			menuPickHint: "Choose one drawn card to plate now",
			scoreReceipt: "Review points by dish",
			finalScore: "Final score",
			roundBreakdown: "Round {{n}} breakdown",
			roundPoints: "Round points",
			totalPoints: "Total points",
			raceBonus: "Race bonus",
			dessertPoints: "Dessert points",
			dessertCount: "{{n}} dessert cards",
			noScoreBreakdown: "No scoring breakdown",
			winner: "Winner",
			rank: "Rank {{n}}",
			helpEgg: "Egg nigiri: 1 pt. ×3 if played on wasabi.",
			helpSalmon: "Salmon nigiri: 2 pts. ×3 if played on wasabi.",
			helpSquid: "Squid nigiri: 3 pts. ×3 if played on wasabi.",
			helpWasabi: "Wasabi: 0 pts itself; the next nigiri played on it scores ×3.",
			helpMaki: "Maki: most 🍥 icons scores 6, second 3 (6/4/2 with 6+ players); ties all score that tier.",
			helpTemaki: "Temaki: most +4, fewest −4 at round end; no score on all-tie, no penalty with 2 players.",
			helpUramaki: "Uramaki: reach 10 icons to claim 8/5/2 immediately and clear them; at round end the leader takes the next prize (ties all score).",
			helpTempura: "Tempura: every 2 cards score 5.",
			helpSashimi: "Sashimi: every 3 cards score 10.",
			helpDumpling: "Dumpling: 1/2/3/4/5+ cards = 1/3/6/10/15 pts.",
			helpEel: "Eel: a single eel is −3; 2 or more score 7.",
			helpTofu: "Tofu: 1 card = 2, 2 cards = 6; 3 or more = 0.",
			helpOnigiri: "Onigiri: each set of 1/2/3/4 distinct shapes = 1/4/9/16 pts; multiple sets allowed.",
			helpEdamame: "Edamame: +1 per card for each opponent who also has edamame (max 4); 0 if only you have it.",
			helpMiso: "Miso soup: 3 pts if nobody else plays one this turn; on a clash all copies are discarded.",
			helpSoy: "Soy sauce: only the most card colors (ties ok) scores — 4 pts per soy.",
			helpTea: "Tea: each tea scores the size of your largest group of one card kind (incl. this round’s desserts).",
			helpMenu: "Menu: draw 4 from the deck and play 1 immediately.",
			helpSpoon: "Spoon: name a card; the first player to your left holding it hands it to you; fizzles if nobody has it.",
			helpChopsticks: "Chopsticks: stays on the table; on a later turn, return it to your hand and play two hand cards at once.",
			helpSpecialOrder: "Special order: copies a non-special-order card you already played, inheriting its scoring.",
			helpTakeout: "Takeout box: flip any of your played cards face-down; each flipped card is worth 2.",
			helpPudding: "Pudding: at game end most +6, fewest −6 (no penalty with 2 players); ties split.",
			helpGtic: "Green tea ice cream: at game end, every 4 cards score 12.",
			helpFruit: "Fruit: at game end, total icons (🍉2 🍊2 🍍1): 0/1/2/3/4/5+ = −2/0/1/3/6/10.",
			catMaki: "Maki rolls",
			catTemaki: "Temaki",
			catUramaki: "Uramaki",
			catNigiri: "Nigiri",
			catTempura: "Tempura",
			catSashimi: "Sashimi",
			catDumpling: "Dumplings",
			catEel: "Eel",
			catTofu: "Tofu",
			catOnigiri: "Onigiri",
			catEdamame: "Edamame",
			catMiso: "Miso soup",
			catTea: "Tea",
			catSoy: "Soy sauce",
			catTakeout: "Takeout box",
			catPudding: "Pudding",
			catGtic: "Green tea ice cream",
			catFruit: "Fruit",
			cardEgg: "Egg",
			cardSalmon: "Salmon",
			cardSquid: "Squid",
			cardMaki1: "Maki ×1",
			cardMaki2: "Maki ×2",
			cardMaki3: "Maki ×3",
			cardTemaki: "Temaki",
			cardUramaki3: "Uramaki ×3",
			cardUramaki4: "Uramaki ×4",
			cardUramaki5: "Uramaki ×5",
			cardTempura: "Tempura",
			cardSashimi: "Sashimi",
			cardDumpling: "Dumpling",
			cardEel: "Eel",
			cardTofu: "Tofu",
			cardOnigiriCircle: "Onigiri ○",
			cardOnigiriTriangle: "Onigiri △",
			cardOnigiriSquare: "Onigiri □",
			cardOnigiriRectangle: "Onigiri ▭",
			cardEdamame: "Edamame",
			cardMiso: "Miso soup",
			cardChopsticks: "Chopsticks",
			cardSoy: "Soy sauce",
			cardTea: "Tea",
			cardMenu: "Menu",
			cardSpoon: "Spoon",
			cardSpecialOrder: "Special order",
			cardTakeout: "Takeout box",
			cardWasabi: "Wasabi",
			cardPudding: "Pudding",
			cardGtic: "Green tea ice cream",
			cardFruitWw: "2 watermelon",
			cardFruitOo: "2 orange",
			cardFruitPp: "2 pineapple",
			cardFruitWo: "Watermelon-orange",
			cardFruitWp: "Watermelon-pineapple",
			cardFruitOp: "Orange-pineapple",
			kindNigiri: "Nigiri",
			kindRoll: "Rolls",
			kindAppetizer: "Appetizers",
			kindSpecial: "Specials",
			kindDessert: "Dessert",
			kindMaki: "Maki rolls",
			kindTemaki: "Temaki",
			kindUramaki: "Uramaki",
			kindChopsticks: "Chopsticks",
			kindSoy: "Soy sauce",
			kindTea: "Tea",
			kindMenu: "Menu",
			kindSpoon: "Spoon",
			kindSpecialOrder: "Special order",
			kindTakeout: "Takeout box",
			kindWasabi: "Wasabi",
			kindPudding: "Pudding",
			kindGtic: "Green tea ice cream",
			kindFruit: "Fruit",
			fruitWatermelon: "Watermelon",
			fruitOrange: "Orange",
			fruitPineapple: "Pineapple",
			menuBoardTitle: "Tonight's menu",
			menuMyFirstMeal: "My First Meal",
			menuSushiGo: "Sushi Go Classic",
			menuPartySampler: "Party Sampler",
			menuMasterMenu: "Master Menu",
			menuPointsPlatter: "Points Platter",
			menuCutthroatCombo: "Cutthroat Combo",
			menuBigBanquet: "Big Banquet",
			menuDinnerForTwo: "Dinner for Two",
			menuCustom: "Custom menu",
			menuPickRoll: "Roll (pick 1)",
			menuPickAppetizers: "Appetizers (pick 3)",
			menuPickSpecials: "Specials (pick 2)",
			menuPickDessert: "Dessert (pick 1)",
			menuIllegal78: "Menu/special order not for 7-8 players",
			menuIllegal2: "Spoon/edamame not for 2 players",
			errNotYourTurn: "Not allowed right now",
			errAlreadyPicked: "Already picked this turn",
			errBadCard: "Invalid card",
			errBadBonusCard: "Can't use that card this way",
			errNoBonus: "No usable chopsticks/spoon on board",
			errBadFlip: "Only flip cards played in earlier turns of this round",
			errBothBonus: "Only one bonus card per turn",
			fxMisoOut: "Miso clash — all discarded!",
			fxUramaki: "Claims uramaki place {{n}}!",
			fxSpoonMiss: "Nobody has it — spoon wasted",
			botDesc: "Picks by marginal value, tracks desserts",
			hintPick: "Suggest playing \"{{card}}\"",
			hintMenu: "Suggest taking \"{{card}}\" from the menu",
			hintConfirm: "Confirm scoring and start the next round"
		}
	}
};
//#endregion
export { Qt as default };
