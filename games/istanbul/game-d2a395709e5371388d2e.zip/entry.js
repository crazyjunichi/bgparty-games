import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { gameAssetUrl as a } from "@bgparty/sdk/assets";
import { useT as o } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as s } from "@bgparty/sdk/player-colors";
import { useWakeLock as c } from "@bgparty/sdk/use-wake-lock";
import { Texture as l } from "@bgparty/sdk/texture";
import { DeltaNumber as ee } from "@bgparty/sdk/fx/delta-number";
import { IconAdd as te, IconBack as ne, IconClose as re, IconSearch as ie } from "@bgparty/sdk/icons";
import { GameScreen as ae } from "@bgparty/sdk/ui/game-screen";
import { useFxAnchor as u } from "@bgparty/sdk/fx/anchors";
import { Fragment as oe, jsx as d, jsxs as f } from "react/jsx-runtime";
import { Floater as se, FlySprite as p, PulseBox as m } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as h } from "@bgparty/sdk/confirm-button";
import { OptionRadio as ce, OptionSection as g, OptionSwitch as _ } from "@bgparty/sdk/ui/game-options";
//#region src/games/istanbul/data.ts
var v = [
	15,
	5,
	2,
	14,
	4,
	12,
	7,
	3,
	8,
	6,
	11,
	9,
	13,
	10,
	1,
	16
], le = [
	16,
	2,
	8,
	11,
	15,
	7,
	6,
	4,
	3,
	5,
	12,
	1,
	10,
	9,
	14,
	13
], y = [
	16,
	8,
	2,
	20,
	15,
	1,
	19,
	11,
	18,
	7,
	6,
	5,
	3,
	17,
	12,
	14,
	10,
	4,
	9,
	13
], ue = [
	9,
	15,
	13,
	10,
	1,
	6,
	24,
	2,
	4,
	7,
	12,
	23,
	21,
	11,
	14,
	5,
	3,
	22,
	8,
	16
], de = [
	[
		1,
		1,
		2,
		1
	],
	[
		1,
		1,
		3,
		0
	],
	[
		1,
		3,
		1,
		0
	],
	[
		0,
		2,
		2,
		1
	],
	[
		1,
		2,
		2,
		0
	],
	[
		1,
		2,
		1,
		1
	]
], fe = [
	[
		1,
		0,
		1,
		3
	],
	[
		2,
		0,
		1,
		2
	],
	[
		2,
		1,
		0,
		2
	],
	[
		1,
		1,
		1,
		2
	],
	[
		3,
		0,
		0,
		2
	],
	[
		1,
		1,
		0,
		3
	]
], pe = [
	3,
	0,
	1,
	2,
	4,
	3,
	0,
	1,
	2,
	4
], me = [
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	6,
	6,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13
], he = [
	14,
	15,
	16,
	17,
	18,
	19,
	20,
	21,
	22
].flatMap((e) => [e, e]), ge = [
	0,
	0,
	1,
	2,
	3,
	23,
	23,
	23,
	...[
		24,
		25,
		26,
		27,
		28,
		29,
		30,
		31,
		32,
		33
	].flatMap((e) => [e, e])
], b = [
	0,
	1,
	2,
	3
], _e = [
	"games.istanbul.fabric",
	"games.istanbul.spice",
	"games.istanbul.fruit",
	"games.istanbul.jewel",
	"games.istanbul.coffee"
], ve = [
	"games.istanbul.places.p1",
	"games.istanbul.places.p2",
	"games.istanbul.places.p3",
	"games.istanbul.places.p4",
	"games.istanbul.places.p5",
	"games.istanbul.places.p6",
	"games.istanbul.places.p7",
	"games.istanbul.places.p8",
	"games.istanbul.places.p9",
	"games.istanbul.places.p10",
	"games.istanbul.places.p11",
	"games.istanbul.places.p12",
	"games.istanbul.places.p13",
	"games.istanbul.places.p14",
	"games.istanbul.places.p15",
	"games.istanbul.places.p16",
	"games.istanbul.places.p17",
	"games.istanbul.places.p18",
	"games.istanbul.places.p19",
	"games.istanbul.places.p20",
	"games.istanbul.places.p21",
	"games.istanbul.places.p22",
	"games.istanbul.places.p23",
	"games.istanbul.places.p24",
	"games.istanbul.places.p25"
];
Array.from({ length: 34 }, (e, t) => t);
var x = [
	"games.istanbul.governor",
	"games.istanbul.smuggler",
	"games.istanbul.coffeeTrader",
	"games.istanbul.courier"
], S = {
	id: "istanbul",
	tier: "alpha",
	mechanics: [
		"grid-movement",
		"race",
		"hand-management",
		"set-collection",
		"auction"
	],
	interactionTags: [],
	nameKey: "games.istanbul.name",
	descKey: "games.istanbul.desc",
	rulesKey: "games.istanbul.rules",
	icon: "💎",
	iconImg: "games/istanbul.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/1692777289026870053/782572DADD060339AD422454F9D25F59C211729D/" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	accent: "#99602a",
	releasedAt: "2026-10-31T13:13:12+08:00",
	search: {
		py: "yi si tan bao istanbul",
		init: "ystb"
	},
	hotseat: "cover",
	botDelayMs: 600
}, C = t.object({
	mocha: t.boolean().default(!1),
	letters: t.boolean().default(!1),
	letterDeck: t.enum(["mixed", "new"]).default("mixed"),
	layout: t.enum([
		"short",
		"long",
		"ordered",
		"random"
	]).default("short"),
	neutralAssistants: t.boolean().default(!1),
	caravanLeader: t.boolean().default(!1),
	depot: t.boolean().default(!1),
	kebab: t.boolean().default(!1)
}).default({
	mocha: !1,
	letters: !1,
	letterDeck: "mixed",
	layout: "short",
	neutralAssistants: !1,
	caravanLeader: !1,
	depot: !1,
	kebab: !1
}), w = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().min(1).max(180)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), T = t.array(t.int().nonnegative()), E = t.object({
	id: t.int(),
	destination: t.int().min(1).max(24),
	delivered: t.boolean()
}), D = t.object({
	rid: t.string(),
	money: t.int().nonnegative(),
	goods: t.tuple([
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative()
	]),
	coffee: t.int().nonnegative(),
	capacity: t.int().min(2).max(5),
	rubies: t.int().nonnegative(),
	merchant: t.int().min(1).max(25),
	family: t.int().min(1).max(25),
	companion: t.int().min(-2).max(25),
	assistants: t.array(t.string()),
	mosque: T,
	tavern: T,
	letters: t.array(E),
	bonusCount: t.int().nonnegative(),
	guildCount: t.int().nonnegative()
}), ye = t.object({
	id: t.string(),
	label: t.string(),
	n: t.number().optional(),
	place: t.number().optional(),
	resource: t.number().optional(),
	card: t.number().optional(),
	guild: t.number().optional(),
	target: t.string().optional(),
	values: T.optional(),
	cost: t.number().optional()
}), be = t.object({
	config: C,
	players: t.array(D),
	board: T,
	columns: t.int(),
	active: t.string(),
	decisionRid: t.string(),
	round: t.int(),
	target: t.int(),
	phase: t.string(),
	place: t.int(),
	actor: t.enum([
		"merchant",
		"companion",
		"family"
	]),
	ending: t.boolean(),
	done: t.boolean(),
	required: t.int(),
	selection: T,
	dropped: t.array(t.object({
		place: t.int(),
		owner: t.string()
	})),
	npcs: t.array(t.int()),
	neutralMerchants: T,
	post: t.int(),
	depotCovered: T,
	rubyPrices: t.object({
		palace: t.int(),
		dealer: t.int(),
		coffee: t.int()
	}),
	mosqueStacks: t.array(T),
	mosqueRubies: T,
	tavernStacks: t.array(T),
	demandSmall: T,
	demandLarge: T,
	bonusTop: t.int().nullable(),
	guildTop: t.int().nullable(),
	bonusRemaining: t.int(),
	guildRemaining: t.int(),
	barrier: t.object({
		a: t.int(),
		b: t.int(),
		owner: t.string()
	}).nullable(),
	baksheesh: t.boolean(),
	caravanLeader: t.string().nullable(),
	societyUses: t.int(),
	dice: T,
	kiosk: T,
	log: t.array(t.object({
		key: t.string(),
		rid: t.string(),
		n: t.number().optional(),
		place: t.number().optional()
	}))
}), xe = t.object({
	bonus: T,
	guild: T,
	choices: t.array(ye)
}), O = {
	move: 440,
	card: 380,
	resource: 440,
	ruby: 620,
	dice: 540,
	step: 100
}, k = (e, t) => e.players.find((e) => e.rid === t), Se = (e) => e.players[e.activeIndex].rid, A = (e, t, n = {}) => ({
	kind: e,
	rid: t,
	...n
}), j = (e, ...t) => {
	e.tasks.unshift(...t);
}, M = (e) => e.goods.reduce((e, t) => e + t, 0), Ce = (e) => e.letters.reduce((e, t) => e + (t.delivered ? 2 : 1), 0), N = (e) => e.config.mocha ? [
	0,
	1,
	2,
	3,
	4
] : [
	0,
	1,
	2,
	3
];
function P(e, t, n, r = {}, i = !1) {
	return {
		choice: {
			id: e,
			label: t,
			...r
		},
		run: n,
		keep: i
	};
}
function F(e, t, n, r, i) {
	e.log.push({
		key: t,
		rid: n,
		...r === void 0 ? {} : { n: r },
		...i === void 0 ? {} : { place: i }
	}), e.log.length > 120 && e.log.shift();
}
function I(e, t, n, r = {}) {
	e.push({
		kind: t,
		rid: n,
		data: r,
		...e.length ? { with: !0 } : {}
	});
}
function L(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function R(t) {
	return e(t.seed, t.cursor++, 6) + 1;
}
function z(e, t, n, r, i, a = e.actionPlace) {
	let o = k(e, t), s = n === 4 ? o.coffee : o.goods[n];
	n === 4 ? o.coffee += r : o.goods[n] = Math.min(o.capacity, o.goods[n] + r);
	let c = (n === 4 ? o.coffee : o.goods[n]) - s;
	c && I(i, "resource", t, {
		resource: n,
		n: c,
		from: a
	});
}
function B(e, t, n, r) {
	k(e, t).money += n, n && I(r, "money", t, {
		n,
		from: e.actionPlace
	});
}
function we(e, t, n) {
	let r = k(e, t);
	n === 4 ? r.coffee-- : r.goods[n]--;
}
function Te(e, t) {
	let n = e[`${t}Deck`], r = e[`${t}Discard`];
	!n.length && r.length && (n.push(...L(e, r)), r.length = 0);
}
function Ee(e, t, n, r, i = !1) {
	i || Te(e, n);
	let a = (i ? e.bonusDiscard : e[`${n}Deck`]).pop();
	if (a === void 0) return;
	let o = k(e, t);
	n === "letter" ? (o.letters.push({
		id: a,
		destination: a % 18 < 16 ? a % 18 + 1 : a % 18 + 7,
		delivered: !1
	}), I(r, "letter", t, {
		n: a,
		from: e.actionPlace
	})) : (o[n].push(a), r.push({
		kind: "draw",
		rid: t,
		data: {
			kind: n,
			index: o[n].length - 1,
			from: n === "bonus" ? 6 : 18
		},
		for: [t],
		secret: { card: a },
		...r.length ? { with: !0 } : {}
	})), Te(e, n);
}
function V(e, t, n, r, i, a = !1) {
	let o = k(e, t)[n].splice(r, 1)[0];
	return e[`${n}Discard`].push(o), Te(e, n), I(i, a ? "play" : "discard", t, {
		kind: n,
		card: o,
		index: r,
		to: n === "bonus" ? 6 : 18
	}), o;
}
function H(e, t, n, r) {
	k(e, t).rubies++, n === 13 && (e.rubyPrices.palace = Math.min(10, e.rubyPrices.palace + 1)), n === 16 && (e.rubyPrices.dealer = Math.min(23, e.rubyPrices.dealer + 1)), n === 20 && (e.rubyPrices.coffee = Math.min(10, e.rubyPrices.coffee + 1)), k(e, t).rubies >= e.target && (e.ending = !0), I(r, "ruby", t, { from: n }), F(e, "ruby", t, k(e, t).rubies, n);
}
function De(e, t, n) {
	let r = k(e, t);
	r.capacity++, I(n, "extension", t), r.capacity === 5 && H(e, t, 1, n);
}
function Oe(e, t) {
	for (let n of e.players) for (let e of n.letters) !e.delivered && [
		n.merchant,
		n.family,
		n.companion
	].includes(e.destination) && (e.delivered = !0, I(t, "deliver", n.rid, {
		letter: e.id,
		place: e.destination
	}));
}
function U(e, t, n, r, i) {
	let a = k(e, t), o = a[n];
	a[n] = r, I(i, "move", t, {
		actor: n,
		from: o,
		to: r
	}), F(e, "move", t, void 0, r);
}
function ke(e, t, n) {
	let r = e.board.indexOf(t);
	return [
		-e.columns,
		e.columns,
		-1,
		1
	].flatMap((i) => {
		let a = r + i;
		if (a < 0 || a >= e.board.length || Math.abs(i) === 1 && Math.floor(r / e.columns) !== Math.floor(a / e.columns)) return [];
		let o = e.board[a];
		return e.barrier && e.barrier.owner !== n && (e.barrier.a === t && e.barrier.b === o || e.barrier.b === t && e.barrier.a === o) ? [] : [o];
	});
}
function Ae(e, t, n, r = "") {
	let i = k(e, t), a = i[n];
	if (a < 1) return [];
	if (r === "any") return e.board.filter((e) => e !== a);
	if (r === "corner") return [
		e.board[0],
		e.board[e.columns - 1],
		e.board.at(-e.columns),
		e.board.at(-1)
	].filter((e) => e !== a);
	let o = /* @__PURE__ */ new Set(), s = r === "long" ? 3 : r === "double" ? 2 : r === "stay" ? 0 : 1, c = r === "long" ? 4 : n === "companion" ? r === "double" ? 2 : 1 : 2;
	if (r === "stay") return [a];
	let l = [a];
	for (let n = 1; n <= c; n++) l = [...new Set(l.flatMap((n) => ke(e, n, t)))], n >= s && l.forEach((e) => {
		e !== a && o.add(e);
	});
	if (n === "merchant" && i.tavern.includes(0) && !r) {
		e.board.indexOf(a);
		for (let n of [
			-e.columns,
			e.columns,
			-1,
			1
		]) {
			let r = a;
			for (let i = 0; i < e.board.length; i++) {
				let i = e.board.indexOf(r), a = i + n;
				if (a < 0 || a >= e.board.length || Math.abs(n) === 1 && Math.floor(i / e.columns) !== Math.floor(a / e.columns)) break;
				let s = e.board[a];
				if (!ke(e, r, t).includes(s)) break;
				o.add(s), r = s;
			}
		}
	}
	return [...o].sort((e, t) => e - t);
}
function je(e) {
	let t = Se(e);
	e.yellowUsed = !1, e.guildTurn = !1, e.lastAction = 0, e.actor = "merchant", e.actionActor = "merchant", e.place = k(e, t).merchant, e.actionPlace = e.place, e.tasks = [A("start", t)];
}
function Me(e, t, n, r, i, a) {
	e.actor = n, e.place = r, U(e, t, n, r, i), e.tasks = [
		A("assistant", t),
		A("merchantFees", t, { names: a ? [a] : [] }),
		A("action", t, { place: r }),
		A("encounters", t, { list: [] }),
		A("end", t)
	];
}
function W(e, t = 1, n = [
	0,
	1,
	2,
	3
], r = "gain") {
	return A("resource", e, {
		n: t,
		list: n,
		mode: r
	});
}
function Ne(e, t, n, r = [
	0,
	1,
	2,
	3
]) {
	return A("resource", e, {
		n: t,
		list: r,
		mode: "pay",
		after: n
	});
}
function Pe(e, t, n) {
	return A("seals", e, {
		n: t,
		after: n
	});
}
function Fe(e, t) {
	let n = [
		0,
		0,
		0,
		0
	], r = 0;
	for (let t of pe.slice(0, e.rubyPrices.palace)) t === 4 ? r++ : n[t]++;
	return n.every((e, n) => t.goods[n] >= e) && M(t) >= n.reduce((e, t) => e + t, 0) + r;
}
function Ie(e, t, n) {
	let r = 0;
	for (let n of pe.slice(0, e.rubyPrices.palace)) n === 4 ? r++ : we(e, t, n);
	r ? j(e, Ne(t, r, [A("ruby", t, { place: 13 })])) : H(e, t, 13, n);
}
function Le(e, t, n, r) {
	let i = k(e, t);
	we(e, t, n), e.mosqueStacks[n].shift(), i.mosque.push(n), n === 3 && i.assistants.unshift(t), I(r, "mosque", t, { resource: n });
	let a = n < 2 ? 0 : 1;
	(a === 0 ? [0, 1] : [2, 3]).every((e) => i.mosque.includes(e)) && e.mosqueRubies[a] > 0 && (e.mosqueRubies[a]--, H(e, t, a === 0 ? 14 : 15, r));
}
function Re(e, t) {
	let n = k(e, t.rid), r = t.rid, i = t.place, a = [], o = (e, n, o, s = {}) => a.push(P(e, n, (e, n) => {
		e.lastAction = 0, e.actionPlace = i, e.actionActor = t.actor ?? e.actor, j(e, A("actionFinished", r, { place: i })), o(e, n), F(e, "action", r, void 0, i);
	}, {
		place: i,
		...s
	}));
	if (i === 1 && n.capacity < 5 && n.money >= 7 && o("extend", "extend", (e, t) => {
		B(e, r, -7, t), De(e, r, t);
	}, { cost: 7 }), i >= 2 && i <= 4) {
		let e = i - 2;
		o("warehouse", "fill", (t, n) => {
			z(t, r, e, k(t, r).capacity, n), !t.guildTurn && k(t, r).mosque.includes(1) && k(t, r).money >= 2 && j(t, A("warehouseExtra", r));
		}, { resource: e });
	}
	if (i === 5 && o("post", "post", (e, t) => {
		if (e.config.depot) j(e, A("roll", r, { mode: "depot" }));
		else {
			let n = [
				0,
				-1,
				3,
				-1
			], i = [
				1,
				-1,
				2,
				-1
			];
			for (let a = 0; a < 4; a++) {
				let o = a < e.post ? i[a] : n[a];
				o < 0 ? B(e, r, a < e.post ? 1 : 2, t) : z(e, r, o, 1, t, 5);
			}
			e.post = (e.post + 1) % 5;
		}
	}), i === 6 && o("caravan", "caravan", (e, t) => {
		e.config.mocha && z(e, r, 4, 1, t, 6), j(e, A("caravanDraw", r, { n: 2 }), ...e.config.caravanLeader && e.caravanLeader === r ? [] : [A("discardCard", r, { mode: "bonus" })], A("caravanFinish", r));
	}), i === 7 && (o("fountain", "fountain", (e) => {
		j(e, A("fountain", r)), e.config.letters && j(e, A("companionRecall", r));
	}), e.config.kebab && (t.actor ?? e.actor) !== "family" && n.family !== 12 && n.money >= 2 && t.mode !== "freeFountain" && o("kebab", "kebab", (e, t) => {
		B(e, r, -2, t), j(e, A("familyDestination", r, { mode: "kebab" }));
	}, { cost: 2 })), i === 8 && (o("blackBefore", "blackBefore", (e) => j(e, W(r, 1, [
		0,
		1,
		2
	]), A("roll", r, { mode: "black" }))), o("blackAfter", "blackAfter", (e) => j(e, A("roll", r, { mode: "black" }), W(r, 1, [
		0,
		1,
		2
	])))), i === 9) for (let e = 3; e <= 12; e++) o(`tea:${e}`, "announce", (n) => j(n, A("roll", r, {
		mode: t.mode === "guildTea" ? "guildTea" : "tea",
		n: e
	})), { n: e });
	if ((i === 10 || i === 11) && ((i === 10 ? fe[e.large[0]] : de[e.small[0]]).some((e, t) => e && n.goods[t]) && o("market", "sell", (e) => j(e, A("market", r, {
		place: i,
		list: [
			0,
			0,
			0,
			0
		],
		mode: "normal"
	}))), i === 11 && n.bonus.includes(9) && M(n) > 0 && !e.guildTurn && o("flexMarket", "flexMarket", (e, t) => {
		V(e, r, "bonus", k(e, r).bonus.indexOf(9), t, !0), j(e, A("market", r, {
			place: i,
			list: [
				0,
				0,
				0,
				0
			],
			mode: "flex"
		}));
	})), i === 12 && n.family === 12 && o("family", "sendFamily", (e) => j(e, A("familyDestination", r))), i === 13 && Fe(e, n) && o("palace", "buyRuby", (e, t) => Ie(e, r, t), { n: e.rubyPrices.palace }), i === 14 || i === 15) for (let a of i === 14 ? [0, 1] : [3, 2]) {
		let i = e.mosqueStacks[a][0];
		!n.mosque.includes(a) && i !== void 0 && n.goods[a] >= (t.mode === "guildMosque" ? 1 : i) && o(`mosque:${a}`, "takeMosque", (e, t) => Le(e, r, a, t), {
			resource: a,
			n: t.mode === "guildMosque" ? 1 : i
		});
	}
	if (i === 16 && n.money >= e.rubyPrices.dealer && o("dealer", "buyRuby", (e, t) => {
		B(e, r, -e.rubyPrices.dealer, t), H(e, r, 16, t);
	}, { cost: e.rubyPrices.dealer }), i === 17 && (n.money >= 2 || M(n) > 0 || n.bonus.length + n.guild.length > 0) && o("roast", "roast", (e) => j(e, A("roast", r, { list: [] }))), i === 18 && o("guildHall", "guildHall", (e, t) => {
		z(e, r, 4, 1, t, 18), j(e, A("draw", r, {
			mode: "guild",
			n: 2
		}), A("discardCard", r, { mode: "guild" }));
	}), i === 19) {
		let i = t.discount ?? 0, a = Math.max(0, 2 - i);
		n.coffee >= a && o("barrier", "barrier", (e) => {
			k(e, r).coffee -= a, ze(e, t), j(e, A("barrierFirst", r));
		}, { cost: a });
		for (let a = 0; a < 2; a++) {
			let s = Math.max(0, (e.tavernStacks[a][0] ?? 99) - i);
			!n.tavern.includes(a) && n.coffee >= s && o(`tavern:${a}`, "takeTavern", (e, n) => {
				k(e, r).coffee -= s, e.tavernStacks[a].shift(), k(e, r).tavern.push(a), I(n, "tavern", r, { n: a }), ze(e, t);
			}, {
				n: a,
				cost: s
			});
		}
		let s = e.baksheesh ? [
			1,
			1,
			0,
			1
		] : [
			0,
			0,
			3,
			0
		], c = Math.max(0, 4 - i);
		n.coffee >= c && s.every((e, t) => n.goods[t] >= e) && o("bribe", "bribe", (e) => {
			k(e, r).coffee -= c, s.forEach((t, n) => k(e, r).goods[n] -= t), e.baksheesh = !e.baksheesh, ze(e, t), j(e, A("rubySource", r));
		}, { cost: c });
	}
	return i === 20 && n.coffee >= e.rubyPrices.coffee && o("coffee", "buyRuby", (e, t) => {
		k(e, r).coffee -= e.rubyPrices.coffee, H(e, r, 20, t);
	}, { cost: e.rubyPrices.coffee }), i === 21 && o("embassy", "takeLetters", (e) => j(e, A("draw", r, {
		mode: "letter",
		n: 2
	})), { n: 2 }), i === 22 && o("kiosk", "kiosk", (e) => {
		let t = e.players.map((e) => e.rid), n = t.indexOf(r), i = [
			...t.slice(n),
			...t.slice(0, n),
			r
		];
		j(e, A("draw", r, {
			mode: "letter",
			n: 1
		}), A("kioskReveal", r, { names: i }));
	}), i === 23 && n.money >= 1 && o("auction", "auction", (e) => j(e, W(r), A("auctionStart", r))), i === 24 && Ce(n) >= 6 && o("society", "society", (e) => j(e, Pe(r, 6, [A("societyRuby", r)])), { n: 6 }), i === 25 && o("catacombs", "catacombs", (e) => j(e, W(r, 1, N(e)), A("teleport", r, { actor: e.actionActor }))), t.used || a.push(P("skip", "skipAction", () => {}, { place: i })), a;
}
function ze(e, t) {
	if (t.discount) for (let t of e.tasks) (t.kind === "tavernSecond" || t.kind === "action" && t.place === 19) && (t.discount = 0);
}
function Be(e, t, n) {
	let r = k(e, t), i = e.tasks[0]?.kind, a = !!i, o = [
		1,
		2,
		3
	].includes(n) ? 3 : n === 5 ? 5 : n === 16 && r.coffee ? 8 : n === 28 ? 7 : 0;
	if (r.money + o < G(e, r, {
		bonus: -1,
		goods: n === 28 ? -1 : 0
	}) || [
		22,
		24,
		28
	].includes(n) && e.tasks.some((e) => e.rid === t && ([
		"seals",
		"auctionStart",
		"auctionBid",
		"discardLetter"
	].includes(e.kind) || e.kind === "resource" && e.mode === "pay")) || r.bonus.length === 1 && e.tasks.some((e) => e.rid === t && e.kind === "discardCard" && (e.mode === "bonus" || e.mode === "either" && !r.guild.length)) || n === 24 && !e.npcs.some((t, n) => t >= 0 && Ge(e, {
		...r,
		bonus: r.bonus.slice(1)
	}, n))) return !1;
	if (n === 33) {
		let n = e.bonusDiscard.at(-1);
		return n !== void 0 && n !== 33 && Be(e, t, n);
	}
	if (e.cleanup && ![
		1,
		2,
		3,
		4,
		5,
		14,
		16,
		17,
		22,
		26,
		28
	].includes(n)) return !1;
	if (n === 8) return ["start", "assistant"].includes(i) && e.dropped.some((e) => e.owner === t);
	if ([
		0,
		6,
		7,
		18,
		30,
		31,
		32
	].includes(n)) return i === "start" && (n !== 0 || r.companion > 0) && (n !== 8 || e.dropped.some((e) => e.owner === t)) && (n !== 31 || r.money >= 3) && (n !== 32 || r.family !== 12 && ke(e, r.family, t).some((e) => e !== 12));
	if (n === 9 || n === 19) return !1;
	let s = {
		11: [5],
		12: [16],
		13: [13],
		20: [1],
		21: [20],
		27: [14, 15],
		29: [24]
	};
	return s[n] ? a && !e.guildTurn && s[n].includes(e.lastAction) && Re(e, A("action", t, {
		place: e.lastAction,
		used: !0
	})).length > 0 : !a || [
		15,
		16,
		22,
		28
	].includes(n) && e.tasks.some((e) => e.kind === "market" && e.list?.some((e) => e > 0)) || n === 4 && ![
		"start",
		"assistant",
		"merchantFees",
		"action",
		"encounters",
		"end",
		"finalCards"
	].includes(i) ? !1 : n === 10 ? r.family !== 12 : n === 15 ? r.coffee >= 2 : n === 16 ? r.coffee >= 1 : n === 22 ? M(r) + r.coffee > 0 : n !== 28 || M(r) + r.coffee > 0;
}
function Ve(e, t, n, r) {
	let i = k(e, t), a = (e, n = {}) => A(e, t, n);
	n >= 1 && n <= 3 && (z(e, t, n === 1 ? 2 : +(n === 2), 1, r), B(e, t, 3, r)), n === 4 && j(e, W(t)), n === 5 && B(e, t, 5, r), [
		0,
		6,
		7,
		18,
		30,
		31
	].includes(n) && j(e, a("specialMove", {
		mode: n === 0 ? "double" : n === 6 ? "long" : n === 7 ? "stay" : n === 18 ? "corner" : n === 30 ? "player" : "any",
		a: +(n === 0)
	})), n === 31 && B(e, t, -3, r), n === 8 && j(e, a("recallOne")), n === 10 && (U(e, t, "family", 12, r), j(e, a("captureReward"))), [
		11,
		12,
		13,
		20,
		21,
		27,
		29
	].includes(n) && j(e, a("action", {
		place: e.lastAction,
		used: !0
	})), n === 14 && z(e, t, 4, 2, r), n === 15 && (i.coffee -= 2, j(e, a("draw", {
		mode: "guild",
		n: 1
	}))), n === 16 && (i.coffee--, B(e, t, 8, r)), [
		17,
		25,
		26
	].includes(n) && j(e, a("roll", { mode: `bonus${n}` })), n === 22 && j(e, a("exchange", { n: 0 })), n === 23 && j(e, a("draw", {
		mode: "letter",
		n: 1
	})), n === 24 && j(e, a("npcPick")), n === 28 && j(e, Ne(t, 1, [a("money", { n: 7 })], N(e))), n === 32 && j(e, a("familyStep"));
}
function He(e, t, n) {
	return n === 1 ? t.capacity < 5 : n === 10 ? [
		0,
		1,
		2
	].every((e) => t.goods[e] > 0) : n === 11 ? [
		0,
		1,
		3
	].every((e) => t.goods[e] > 0) : n === 13 ? M(t) >= 6 : n === 14 || n === 15 ? (n === 14 ? [0, 1] : [3, 2]).some((n) => !t.mosque.includes(n) && e.mosqueStacks[n].length > 0 && t.goods[n] > 0) : n === 16 ? t.money >= 15 : n === 19 ? Re(e, A("action", t.rid, {
		place: 19,
		discount: 1,
		used: !0
	})).length > 0 : n !== 20 || t.coffee >= Math.ceil(e.rubyPrices.coffee / 2);
}
function Ue(e, t, n, r) {
	let i = k(e, t), a = (e, n = {}) => A(e, t, n);
	if (e.guildTurn = !0, e.tasks = [a("end")], n === 1 && De(e, t, r), n >= 2 && n <= 4 && (z(e, t, n - 2, i.capacity, r), j(e, a("differentGoods", {
		n: 3,
		list: []
	}))), n === 5 && (B(e, t, 4, r), j(e, a("differentGoods", {
		n: 4,
		list: []
	}))), n === 6 && j(e, a("draw", {
		mode: "bonus",
		n: 3
	})), n === 7 && (U(e, t, "merchant", 7, r), j(e, a("fountain")), e.extra = !0), n === 8 && j(e, a("guildBlack")), n === 9 && j(e, a("action", {
		place: 9,
		mode: "guildTea",
		used: !0
	})), n === 10 || n === 11) {
		for (let r of n === 10 ? [
			0,
			1,
			2
		] : [
			0,
			1,
			3
		]) we(e, t, r);
		B(e, t, n === 10 ? 15 : 20, r);
	}
	n === 12 && j(e, a("guildDestination"), a("familyHome")), n === 13 && j(e, Ne(t, 6, [a("ruby", { place: 13 })])), (n === 14 || n === 15) && j(e, a("action", {
		place: n === 14 ? 14 : 15,
		mode: "guildMosque",
		used: !0
	})), n === 16 && (B(e, t, -15, r), H(e, t, 16, r), z(e, t, 4, i.rubies, r, 16)), n === 17 && z(e, t, 4, 5, r), n === 18 && (z(e, t, 4, 1, r), j(e, a("draw", {
		mode: "guild",
		n: 2
	}))), n === 19 && j(e, a("action", {
		place: 19,
		discount: 1,
		used: !0
	}), a("tavernSecond", { discount: 1 })), n === 20 && (i.coffee -= Math.ceil(e.rubyPrices.coffee / 2), H(e, t, 20, r));
}
function We(e, t, n = []) {
	if (e.place === 7 && !e.config.kebab) return [];
	let r = [];
	for (let n of e.players) n.rid !== t && (n.merchant === e.place && r.push({
		id: `m:${n.rid}`,
		target: n.rid
	}), n.companion === e.place && r.push({
		id: `c:${n.rid}`,
		target: n.rid
	}));
	return e.neutralMerchants.forEach((t, n) => {
		t === e.place && r.push({
			id: `n:${n}`,
			neutral: n
		});
	}), r.filter((e) => !n.includes(e.id));
}
function G(e, t, n = {}, r = !1, i) {
	if (t.tavern.includes(1)) return 0;
	let a = [
		0,
		0,
		0
	];
	return e.tasks.forEach((e, n) => {
		e.kind === "npcPay" && e.rid === t.rid && (!r || n > 0) && a[e.a === 0 ? 0 : e.a === 3 ? 2 : 1]++;
	}), i !== void 0 && a[i === 0 ? 0 : i === 3 ? 2 : 1]++, 2 * (Math.max(0, a[0] - t.bonus.length - (n.bonus ?? 0)) + Math.max(0, a[1] - M(t) - (n.goods ?? 0)) + Math.max(0, a[2] - t.letters.length - (n.letters ?? 0)));
}
function Ge(e, t, n) {
	let r = +(n === 0 && e.bonusDeck.length + e.bonusDiscard.length > 0), i = +(n === 3 && e.letterDeck.length + e.letterDiscard.length > 0);
	return t.money >= G(e, t, {
		bonus: r,
		letters: i,
		goods: +(n === 1)
	}, !1, n);
}
function Ke(e, t) {
	let n = G(e, t);
	for (let r of e.tasks) r.kind === "auctionStart" && r.rid === t.rid && (n = Math.max(n, 1)), r.kind === "auctionBid" && e.players[r.list?.[0] ?? -1]?.rid === t.rid && (n = Math.max(n, r.n ?? 0));
	return Math.max(0, t.money - n);
}
function qe(e, t, n, r) {
	j(e, A("npcTake", t.rid, {
		a: n,
		after: [A("npcMove", t.rid, { a: n }), ...r]
	}));
}
function Je(e, t) {
	return t === 4 ? e.coffee : e.goods[t];
}
function Ye(e, t) {
	let n = t.rid, r = k(e, n), i = t.n ?? 1, a = t.list ?? [], o = [], s = (e, t, n, r = {}, i = !1) => o.push(P(e, t, n, r, i)), c = (e, n = {}) => j(e, {
		...t,
		...n
	});
	switch (t.kind) {
		case "start":
			for (let t of ["merchant", "companion"]) for (let r of Ae(e, n, t)) s(`move:${t}:${r}`, t === "merchant" ? "moveMerchant" : "moveCompanion", (e, i) => Me(e, n, t, r, i), { place: r });
			r.companion === -1 && s("deployCompanion", "deployCompanion", (e, t) => U(e, n, "companion", k(e, n).merchant, t), { place: r.merchant }, !0), r.guild.forEach((t, i) => {
				He(e, r, t) && s(`guild:${i}`, "playGuild", (e, r) => {
					V(e, n, "guild", i, r, !0), Ue(e, n, t, r);
				}, { guild: t });
			});
			break;
		case "specialMove":
			if (t.mode === "player") for (let t of e.players) t.rid !== n && s(`other:${t.rid}`, "moveToPlayer", (e, r) => Me(e, n, "merchant", t.merchant, r, `m:${t.rid}`), {
				target: t.rid,
				place: t.merchant
			});
			else for (let r of Ae(e, n, t.a === 1 ? "companion" : "merchant", t.mode)) s(`special:${r}`, "moveHere", (e, i) => {
				Me(e, n, t.a === 1 ? "companion" : "merchant", r, i);
			}, { place: r });
			break;
		case "assistant": {
			let t = e.dropped.filter((t) => t.place === e.place && (t.owner === n || t.owner === "neutral")), i = [...new Set(t.map((e) => e.owner))];
			if (e.place === 7 && s("freeFountain", "fountain", (e) => {
				e.tasks = e.tasks.filter((e) => e.kind !== "merchantFees");
				let t = e.tasks.find((e) => e.kind === "action");
				t && (t.mode = "freeFountain");
			}), e.actor === "companion") s("solo", "continue", () => {});
			else if (i.length) for (let e of i) s(`pick:${e}`, e === "neutral" ? "pickNeutral" : "pickAssistant", (t, r) => {
				let i = t.dropped.findIndex((n) => n.place === t.place && n.owner === e);
				t.dropped.splice(i, 1), k(t, n).assistants.unshift(e), I(r, "assistant", n, {
					from: t.place,
					to: 0,
					owner: e
				});
			});
			else r.assistants.length && s("leaveAssistant", "leaveAssistant", (e, t) => {
				let r = k(e, n).assistants.shift();
				e.dropped.push({
					place: e.place,
					owner: r
				}), I(t, "assistant", n, {
					from: 0,
					to: e.place,
					owner: r
				});
			});
			s("endEarly", "endTurn", (e) => {
				e.tasks = [A("end", n)];
			});
			break;
		}
		case "merchantFees":
			for (let i of We(e, n, t.names)) r.money >= 2 && s(`fee:${i.id}`, "payMerchant", (e, r) => {
				B(e, n, -2, r), i.target && B(e, i.target, 2, r);
				let a = {
					...t,
					names: [...t.names ?? [], i.id]
				};
				j(e, ...i.neutral === void 0 ? [] : [A("neutralMove", n, { a: i.neutral })], a);
			}, {
				target: i.target,
				cost: 2
			});
			s("endEarly", "endTurn", (e) => {
				e.tasks = [A("end", n)];
			});
			break;
		case "action": return Re(e, t);
		case "warehouseExtra":
			r.money >= 2 && s("buyExtra", "buyExtra", (e, t) => {
				B(e, n, -2, t), j(e, W(n));
			}, { cost: 2 }), s("skip", "skip", () => {});
			break;
		case "resource":
			for (let e of a) (t.mode !== "pay" || Je(r, e) > 0) && s(`resource:${e}`, t.mode === "pay" ? "payResource" : "takeResource", (r, a) => {
				t.mode === "pay" ? we(r, n, e) : z(r, n, e, 1, a), i > 1 ? c(r, { n: i - 1 }) : j(r, ...t.after ?? []);
			}, {
				resource: e,
				n: i
			});
			break;
		case "differentGoods":
			for (let e of b) a.includes(e) || s(`different:${e}`, "takeResource", (t, r) => {
				z(t, n, e, 1, r), i > 1 && c(t, {
					n: i - 1,
					list: [...a, e]
				});
			}, { resource: e });
			s("finish", "finish", () => {});
			break;
		case "fountain":
			for (let t of [...new Set(e.dropped.filter((e) => e.owner === n).map((e) => e.place))]) s(`recall:${t}`, "recallAssistant", (e, r) => {
				let i = e.dropped.findIndex((e) => e.owner === n && e.place === t);
				e.dropped.splice(i, 1), k(e, n).assistants.unshift(n), I(r, "assistant", n, {
					from: t,
					to: 0,
					owner: n
				}), c(e);
			}, { place: t });
			s("finish", "finish", () => {});
			break;
		case "recallOne":
			for (let t of [...new Set(e.dropped.filter((e) => e.owner === n).map((e) => e.place))]) s(`recallOne:${t}`, "recallAssistant", (e, r) => {
				let i = e.dropped.findIndex((e) => e.owner === n && e.place === t);
				e.dropped.splice(i, 1), k(e, n).assistants.unshift(n), I(r, "assistant", n, {
					from: t,
					to: 0,
					owner: n
				});
			}, { place: t });
			break;
		case "companionRecall":
			r.companion !== -1 && s("recallCompanion", r.companion === -2 ? "takeCompanion" : "recallCompanion", (e, t) => U(e, n, "companion", -1, t)), s("skip", "skip", () => {});
			break;
		case "familyDestination":
		case "familyStep": {
			let i = t.kind === "familyStep" ? ke(e, r.family, n).filter((e) => e !== 12) : e.board.filter((r) => r !== k(e, n).family && (t.mode === "kebab" || r !== 12));
			for (let e of i) s(`family:${e}`, "sendFamily", (r, i) => {
				U(r, n, "family", e, i), t.kind === "familyStep" ? (r.actor = "family", r.place = e, r.tasks = [A("action", n, { place: e }), A("end", n)]) : j(r, A("action", n, {
					place: e,
					actor: "family"
				}));
			}, { place: e });
			break;
		}
		case "teleport":
			for (let r of e.board) s(`teleport:${r}`, "moveHere", (e, i) => {
				U(e, n, t.actor ?? e.actor, r, i), (t.actor ?? e.actor) === e.actor && (e.place = r, e.tasks = e.tasks.filter((e) => e.kind !== "encounters"));
			}, { place: r });
			break;
		case "market": {
			let i = t.mode === "flex" ? [
				5,
				5,
				5,
				5
			] : t.place === 10 ? fe[e.large[0]] : de[e.small[0]], o = a.reduce((e, t) => e + t, 0);
			for (let e of b) o < 5 && a[e] < r.goods[e] && a[e] < i[e] && s(`sell:${e}`, "selectGood", (t) => {
				let n = [...a];
				n[e]++, c(t, { list: n });
			}, {
				resource: e,
				n: a[e]
			}), a[e] > 0 && s(`unsell:${e}`, "unselectGood", (t) => {
				let n = [...a];
				n[e]--, c(t, { list: n });
			}, { resource: e });
			o > 0 && s("sell", "sellSelected", (e, r) => {
				a.forEach((t, r) => k(e, n).goods[r] -= t), B(e, n, (t.place === 10 ? [
					0,
					3,
					7,
					12,
					18,
					25
				] : [
					0,
					2,
					5,
					9,
					14,
					20
				])[o], r);
				let i = t.place === 10 ? e.large : e.small;
				i.push(i.shift());
			}, {
				n: o,
				cost: (t.place === 10 ? [
					0,
					3,
					7,
					12,
					18,
					25
				] : [
					0,
					2,
					5,
					9,
					14,
					20
				])[o]
			});
			break;
		}
		case "caravanDraw":
			(e.bonusDeck.length || e.bonusDiscard.length) && s("fromDeck", "drawDeck", (e, t) => {
				Ee(e, n, "bonus", t), i > 1 && c(e, { n: i - 1 });
			}), e.bonusDiscard.length && s("fromDiscard", "drawDiscard", (e, t) => {
				Ee(e, n, "bonus", t, !0), i > 1 && c(e, { n: i - 1 });
			});
			break;
		case "discardCard": {
			let e = t.mode === "either" ? ["bonus", "guild"] : [t.mode === "guild" ? "guild" : "bonus"];
			for (let i of e) r[i].forEach((e, r) => s(`discard:${i}:${r}`, "discardCard", (e, a) => {
				V(e, n, i, r, a), j(e, ...t.after ?? []);
			}, i === "bonus" ? { card: e } : { guild: e }));
			break;
		}
		case "roast":
			!a.includes(0) && r.money >= 2 && s("roastMoney", "roastMoney", (e, t) => {
				B(e, n, -2, t), z(e, n, 4, 2, t), c(e, { list: [...a, 0] });
			}, { cost: 2 }), !a.includes(1) && M(r) > 0 && s("roastGood", "roastGood", (e) => j(e, Ne(n, 1, [A("gainCoffee", n, { n: 2 }), {
				...t,
				list: [...a, 1]
			}]))), !a.includes(2) && r.bonus.length + r.guild.length > 0 && s("roastCard", "roastCard", (e) => j(e, A("discardCard", n, {
				mode: "either",
				after: [A("gainCoffee", n, { n: 2 }), {
					...t,
					list: [...a, 2]
				}]
			}))), a.length && s("finish", "finish", () => {});
			break;
		case "barrierFirst":
			for (let r of e.board) s(`edgeFirst:${r}`, "barrierFirst", (e) => j(e, A("barrierSecond", n, {
				place: r,
				discount: t.discount
			})), { place: r });
			break;
		case "barrierSecond":
			for (let r of ke({
				...e,
				barrier: null
			}, t.place, n)) s(`edgeSecond:${r}`, "barrierSecond", (e, i) => {
				e.barrier = {
					a: t.place,
					b: r,
					owner: n
				}, I(i, "barrier", n, {
					from: t.place,
					to: r
				}), j(e, A("barrierAction", n, { list: [t.place, r] }));
			}, { place: r });
			break;
		case "barrierAction":
			for (let e of a) s(`barrierAction:${e}`, "takeAction", (t) => j(t, A("action", n, {
				place: e,
				actor: t.actionActor
			})), { place: e });
			break;
		case "tavernSecond":
			Re(e, A("action", n, {
				place: 19,
				discount: t.discount,
				used: !0
			})).length && s("tavernAgain", "tavernAgain", (e) => j(e, A("action", n, {
				place: 19,
				discount: t.discount,
				used: !0
			}))), s("finish", "finish", () => {});
			break;
		case "rubySource":
			for (let t of e.config.mocha ? [
				13,
				16,
				20
			] : [13, 16]) s(`ruby:${t}`, "takeRuby", (e, r) => H(e, n, t, r), { place: t });
			break;
		case "seals":
			for (let a of r.letters) s(`seal:${a.id}`, "payLetter", (r, o) => {
				let s = k(r, n).letters, l = s.findIndex((e) => e.id === a.id);
				s.splice(l, 1), r.letterDiscard.push(a.id), I(o, "spendLetter", n, {
					letter: a.id,
					to: e.actionPlace
				});
				let ee = i - (a.delivered ? 2 : 1);
				ee > 0 ? c(r, { n: ee }) : j(r, ...t.after ?? []);
			}, {
				n: a.delivered ? 2 : 1,
				values: [a.id]
			});
			break;
		case "encounters": {
			let i = e.place === 12 ? [] : e.players.filter((t) => t.rid !== n && t.family === e.place);
			for (let e of i) s(`capture:${e.rid}`, "captureFamily", (r, i) => {
				U(r, e.rid, "family", 12, i), j(r, A("captureReward", n), t);
			}, { target: e.rid });
			for (let n = 0; n < e.npcs.length; n++) e.npcs[n] === e.place && !a.includes(n) && Ge(e, r, n) && s(`npc:${n}`, "useNpc", (e) => qe(e, t, n, [{
				...t,
				list: [...a, n]
			}]), { n });
			i.length || s("finish", "endEncounters", () => {});
			break;
		}
		case "npcPick":
			for (let n = 0; n < e.npcs.length; n++) e.npcs[n] >= 0 && Ge(e, r, n) && s(`anyNpc:${n}`, "useNpc", (e) => qe(e, t, n, []), { n });
			break;
		case "npcPay":
			if (r.tavern.includes(1)) s("freeEncounter", "freeEncounter", (e) => j(e, ...t.after ?? []));
			else {
				if (r.money - 2 >= G(e, r, {}, !0) && s("npcMoney", "payMoney", (e, r) => {
					B(e, n, -2, r), j(e, ...t.after ?? []);
				}, { cost: 2 }), t.a === 0 && r.money >= G(e, r, { bonus: -1 }, !0) && r.bonus.forEach((e, r) => s(`npcCard:${r}`, "discardCard", (e, i) => {
					V(e, n, "bonus", r, i), j(e, ...t.after ?? []);
				}, { card: e })), (t.a === 1 || t.a === 2) && r.money >= G(e, r, { goods: -1 }, !0)) for (let e of b) r.goods[e] && s(`npcGood:${e}`, "payResource", (r) => {
					we(r, n, e), j(r, ...t.after ?? []);
				}, { resource: e });
				if (t.a === 3 && r.money >= G(e, r, { letters: -1 }, !0)) for (let e of r.letters) s(`npcLetter:${e.id}`, "payLetter", (r, i) => {
					let a = k(r, n).letters;
					a.splice(a.findIndex((t) => t.id === e.id), 1), r.letterDiscard.push(e.id), I(i, "spendLetter", n, {
						letter: e.id,
						npc: 3,
						to: r.npcs[3]
					}), j(r, ...t.after ?? []);
				}, {
					values: [e.id],
					n: e.delivered ? 2 : 1
				});
			}
			break;
		case "captureReward":
			s("rewardMoney", "rewardMoney", (e, t) => B(e, n, 3, t), { n: 3 }), s("rewardCard", "rewardCard", (e) => j(e, A("draw", n, {
				mode: "bonus",
				n: 1
			})));
			break;
		case "diceChoice":
			if (s("acceptDice", "acceptDice", (e) => j(e, {
				...t,
				kind: "diceResult"
			}), { values: e.dice }), (t.mode === "black" || t.mode === "tea") && r.mosque.includes(0) && !t.used) {
				for (let t = 0; t < 2; t++) e.dice[t] !== 4 && s(`four:${t}`, "changeFour", (e, r) => {
					e.dice[t] = 4, c(e, { used: !0 }), I(r, "dice", n, { values: e.dice });
				}, { n: t + 1 });
				s("reroll", "reroll", (e, t) => {
					e.dice = [R(e), R(e)], c(e, { used: !0 }), I(t, "dice", n, { values: e.dice });
				});
			}
			r.bonus.forEach((t, r) => {
				if (t === 19) for (let t = 0; t < e.dice.length; t++) e.dice[t] !== 6 && s(`six:${r}:${t}`, "changeSix", (e, i) => {
					V(e, n, "bonus", r, i, !0), e.dice[t] = 6, c(e), I(i, "dice", n, { values: e.dice });
				}, {
					n: t + 1,
					card: 19
				});
			});
			break;
		case "depotCover": {
			let t = [...new Set(e.dice)], r = e.depotCovered, i = t.filter((e) => !r.includes(e)).length;
			for (let e = 1; e <= 4; e++) for (let a = e + 1; a <= 5; a++) for (let o = a + 1; o <= 6; o++) {
				let c = [
					e,
					a,
					o
				];
				t.every((e) => c.includes(e)) && c.filter((e) => !r.includes(e)).length === i && r.filter((e) => t.includes(e)).every((e) => c.includes(e)) && s(`cover:${e}${a}${o}`, "coverDice", (e, t) => {
					e.depotCovered = c;
					for (let r = 1; r <= 5; r++) c.includes(r) || (r <= 2 ? B(e, n, r + 1, t) : z(e, n, r === 3 ? 2 : r === 4 ? 0 : 1, 1, t, 5));
					c.includes(6) || j(e, A("depotSix", n));
				}, { values: c });
			}
			break;
		}
		case "depotSix":
			s("depotBlue", "takeResource", (e, t) => z(e, n, 3, 1, t, 5), { resource: 3 }), e.config.mocha && s("depotCoffee", "takeResource", (e, t) => z(e, n, 4, 1, t, 5), { resource: 4 }), e.config.letters && s("depotLetter", "takeLetters", (e) => j(e, A("draw", n, {
				mode: "letter",
				n: 1
			})), { n: 1 });
			break;
		case "guildBlack":
			for (let e of [
				0,
				1,
				2
			]) s(`guildBlack:${e}`, "takeTwo", (t) => j(t, W(n, 2, [e]), A("roll", n, { mode: "guildBlack" })), {
				resource: e,
				n: 2
			});
			break;
		case "guildDestination":
			for (let t of e.board) s(`guildPlace:${t}`, "takeAction", (e) => j(e, A("action", n, { place: t })), { place: t });
			break;
		case "exchange":
			for (let t of N(e)) i < 3 && Je(r, t) > 0 && s(`tradeOut:${t}`, "exchangeOut", (e) => {
				we(e, n, t), c(e, { n: i + 1 });
			}, {
				resource: t,
				n: i
			});
			s("finishExchange", "finishExchange", (e) => {
				i && j(e, W(n, i, N(e)));
			}, { n: i });
			break;
		case "auctionStart":
			for (let e = 1; e <= r.money; e++) s(`initialBid:${e}`, "bid", (t) => {
				let r = t.players.map((e) => e.rid), i = r.indexOf(n), a = [
					...r.slice(i + 1),
					...r.slice(0, i),
					n
				];
				j(t, A("auctionBid", a[0], {
					n: e,
					names: Xe(a),
					mode: n,
					list: [t.players.findIndex((e) => e.rid === n)]
				}));
			}, { n: e });
			break;
		case "auctionBid": {
			let e = t.names ?? [], o = t.mode, c = a[0], l = (t, n, r) => {
				let i = e.slice(1);
				i.length ? j(t, A("auctionBid", i[0], {
					n,
					names: i,
					mode: o,
					list: [r]
				})) : j(t, A("auctionFinish", o, {
					n,
					a: r
				}));
			};
			for (let e = i + 1; e <= r.money; e++) s(`bid:${e}`, "bid", (t) => l(t, e, t.players.findIndex((e) => e.rid === n)), { n: e });
			s("pass", "pass", (e) => l(e, i, c));
			break;
		}
		case "kioskChoose":
			for (let r of e.kiosk) s(`kiosk:${r}`, "chooseKiosk", (e) => {
				e.kiosk.splice(e.kiosk.indexOf(r), 1), e.kioskDiscard.push(r);
				let i = t.names ?? [];
				i.length > 1 && j(e, A("kioskChoose", i[1], { names: i.slice(1) })), j(e, A("kioskEffect", n, { a: r }));
			}, { n: r });
			break;
		case "kioskEffect": return Ze(e, t);
		case "kioskExchange": return Qe(e, t);
		case "end": {
			let t = (e) => {
				e.caravanPending &&= (e.caravanLeader = e.caravanPending, null);
			};
			e.config.letters && r.doubleRound !== e.round && Ce(r) >= 3 && s("doubleTurn", "doubleTurn", (e) => {
				t(e), k(e, n).doubleRound = e.round, j(e, Pe(n, 3, [A("extraTurn", n)]));
			}, { n: 3 }), s("finishTurn", "endTurn", (e) => {
				t(e), j(e, A("advance", n));
			});
			break;
		}
		case "finalCards": s("finishFinal", "finishFinal", (e) => {
			let t = e.players.findIndex((e) => e.rid === n);
			t + 1 < e.players.length ? j(e, A("finalCards", e.players[t + 1].rid)) : (e.done = !0, e.tasks = []);
		});
	}
	return o;
}
function Xe(e) {
	return e;
}
function Ze(e, t) {
	let n = t.rid, r = k(e, n), i = t.a, a = [P("kioskSkip", "skip", () => {})], o = (e) => a.unshift(P("kioskUse", "useKiosk", e, { n: i }));
	i === 0 && o((e, t) => B(e, n, 2, t)), [
		1,
		2,
		3,
		4,
		5
	].includes(i) && o((e) => j(e, A("kioskExchange", n, { a: i }))), i === 6 && o((e, t) => U(e, n, "merchant", 7, t)), i === 7 && o((e) => j(e, A("roll", n, { mode: "kioskMoney" }))), i === 8 && o((e, t) => U(e, n, "companion", -1, t)), i === 9 && o((e) => j(e, A("draw", n, {
		mode: "bonus",
		n: 1
	}))), i === 10 && r.money >= 10 && r.capacity < 5 && o((e, t) => {
		B(e, n, -10, t), De(e, n, t);
	});
	let s = {
		11: [
			1,
			1,
			1
		],
		12: [
			2,
			1,
			1
		],
		13: [
			1,
			2,
			0
		],
		14: [
			0,
			2,
			0
		],
		16: [
			0,
			1,
			1
		],
		17: [
			2,
			1,
			0
		],
		19: [
			2,
			2,
			0
		],
		20: [
			3,
			1,
			0
		],
		21: [
			1,
			1,
			0
		],
		22: [
			0,
			1,
			0
		]
	};
	return s[i] && o((e, t) => {
		let [r, a, o] = s[i];
		z(e, n, r, a, t), o && B(e, n, o, t);
	}), (i === 15 || i === 18) && (a.unshift(P("kioskMoney", "takeMoney", (e, t) => B(e, n, i === 15 ? 2 : 3, t), { n: i === 15 ? 2 : 3 })), e.config.mocha && a.unshift(P("kioskCoffee", "takeResource", (e, t) => z(e, n, 4, 1, t), { resource: 4 }))), i === 23 && r.capacity < 5 && r.goods.every((e) => e > 0) && o((e, t) => {
		k(e, n).goods = k(e, n).goods.map((e) => e - 1), De(e, n, t);
	}), a;
}
function Qe(e, t) {
	let n = t.rid, r = k(e, n), i = t.a, a = [P("kioskSkip", "skip", () => {})], o = N(e);
	return i === 1 && (M(r) + r.coffee > 0 && a.push(P("goodLetter", "goodLetter", (e) => j(e, Ne(n, 1, [A("draw", n, {
		mode: "letter",
		n: 1
	})], o)))), r.letters.length && a.push(P("letterGood", "letterGood", (e) => j(e, A("discardLetter", n, { after: [W(n, 1, o)] }))))), i === 2 && (r.money >= 2 && a.push(P("moneyGood", "moneyGood", (e, t) => {
		B(e, n, -2, t), j(e, W(n, 1, o));
	})), M(r) + r.coffee > 0 && a.push(P("goodMoney", "goodMoney", (e) => j(e, Ne(n, 1, [A("money", n, { n: 3 })], o))))), i === 3 && (r.money >= 2 && a.push(P("moneyCard", "moneyCard", (e, t) => {
		B(e, n, -2, t), j(e, A("draw", n, {
			mode: "bonus",
			n: 1
		}));
	})), r.bonus.length && a.push(P("cardMoney", "cardMoney", (e) => j(e, A("discardCard", n, {
		mode: "bonus",
		after: [A("money", n, { n: 3 })]
	}))))), i === 4 && (r.money >= 2 && a.push(P("moneyLetter", "moneyLetter", (e, t) => {
		B(e, n, -2, t), j(e, A("draw", n, {
			mode: "letter",
			n: 1
		}));
	})), r.letters.length && a.push(P("letterMoney", "letterMoney", (e) => j(e, A("discardLetter", n, { after: [A("money", n, { n: 3 })] }))))), i === 5 && (r.bonus.length && a.push(P("cardLetter", "cardLetter", (e) => j(e, A("discardCard", n, {
		mode: "bonus",
		after: [A("draw", n, {
			mode: "letter",
			n: 1
		})]
	})))), r.letters.length && a.push(P("letterCard", "letterCard", (e) => j(e, A("discardLetter", n, { after: [A("draw", n, {
		mode: "bonus",
		n: 1
	})] }))))), a;
}
function $e(e, t) {
	let n = e.tasks[0];
	if (!n || n.rid !== t || tt(e, n) || e.done) return [];
	let r = Ye(e, n), i = k(e, t);
	if (n.kind === "discardLetter") for (let a of i.letters) r.push(P(`discardLetter:${a.id}`, "payLetter", (r, i) => {
		let o = k(r, t).letters;
		o.splice(o.findIndex((e) => e.id === a.id), 1), r.letterDiscard.push(a.id), I(i, "spendLetter", t, {
			letter: a.id,
			to: e.actionPlace
		}), j(r, ...n.after ?? []);
	}, { values: [a.id] }));
	return (t === Se(e) || e.cleanup) && (i.bonus.forEach((n, i) => {
		Be(e, t, n) && r.push(P(`bonus:${i}`, "playBonus", (e, r) => {
			let a = n === 33 ? e.bonusDiscard.at(-1) : n;
			V(e, t, "bonus", i, r, !0), Ve(e, t, a, r);
		}, { card: n }, !0));
	}), !e.cleanup && i.mosque.includes(2) && !e.yellowUsed && Ke(e, i) >= 2 && e.dropped.some((e) => e.owner === t) && r.push(P("yellowMosque", "yellowMosque", (e, n) => {
		B(e, t, -2, n), e.yellowUsed = !0, j(e, A("recallOne", t));
	}, { cost: 2 }, !0))), r;
}
var et = /* @__PURE__ */ new Set([
	"actionFinished",
	"draw",
	"ruby",
	"money",
	"gainCoffee",
	"roll",
	"diceResult",
	"npcTake",
	"npcMove",
	"neutralMove",
	"caravanFinish",
	"societyRuby",
	"kioskReveal",
	"auctionFinish",
	"extraTurn",
	"advance",
	"familyHome"
]);
function tt(e, t) {
	let n = k(e, t.rid);
	return et.has(t.kind) || t.kind === "merchantFees" && !We(e, t.rid, t.names).length || t.kind === "caravanDraw" && !e.bonusDeck.length && !e.bonusDiscard.length || t.kind === "discardCard" && (t.mode === "either" ? n.bonus.length + n.guild.length === 0 : !n[t.mode === "guild" ? "guild" : "bonus"].length);
}
function nt(e, t, n) {
	let r = t.rid, i = k(e, r), a = t.n ?? 1;
	if (t.kind === "draw" && (Ee(e, r, t.mode, n), a > 1 && j(e, {
		...t,
		n: a - 1
	})), t.kind === "ruby" && H(e, r, t.place, n), t.kind === "money" && B(e, r, a, n), t.kind === "gainCoffee" && z(e, r, 4, a, n), t.kind === "caravanFinish" && e.config.caravanLeader && (e.caravanPending = r), t.kind === "roll" && (e.dice = t.mode === "kioskMoney" ? [R(e)] : [R(e), R(e)], I(n, "dice", r, { values: e.dice }), j(e, {
		...t,
		kind: "diceChoice"
	})), t.kind === "diceResult") {
		let i = e.dice[0] + e.dice[1];
		if (t.mode === "black" && z(e, r, 3, i >= 11 ? 3 : i >= 9 ? 2 : +(i >= 7), n, 8), t.mode === "guildBlack" && z(e, r, 3, i >= 7 ? 3 : +(i >= 4), n), (t.mode === "tea" || t.mode === "guildTea") && B(e, r, (i >= a ? a : 2) * (t.mode === "guildTea" ? 2 : 1), n), t.mode === "depot" && j(e, A("depotCover", r)), t.mode === "kioskMoney" && B(e, r, e.dice[0], n), t.mode === "bonus17") for (let t of e.dice) t === 1 ? B(e, r, 2, n) : z(e, r, t === 2 ? 2 : t === 3 ? 1 : t === 4 ? 0 : t === 5 ? 3 : 4, 1, n);
		if (t.mode === "bonus25" || t.mode === "bonus26") {
			let i = e.dice.filter((e) => e >= 4).length;
			B(e, r, 2 - i, n), i && j(e, t.mode === "bonus25" ? A("draw", r, {
				mode: "letter",
				n: i
			}) : W(r, i, N(e)));
		}
	}
	if (t.kind === "actionFinished" && (e.lastAction = t.place), t.kind === "npcTake") {
		let i = A("npcPay", r, {
			a: t.a,
			after: t.after
		});
		t.a === 0 && j(e, A("draw", r, {
			mode: "bonus",
			n: 1
		}), i), t.a === 1 && j(e, W(r), i), t.a === 2 && (z(e, r, 4, 1, n), j(e, i)), t.a === 3 && j(e, A("draw", r, {
			mode: "letter",
			n: 1
		}), i);
	}
	if (t.kind === "npcMove" || t.kind === "neutralMove") {
		let i = t.kind === "npcMove" ? e.npcs[t.a] : e.neutralMerchants[t.a], a = R(e) + R(e);
		t.kind === "npcMove" ? e.npcs[t.a] = a : e.neutralMerchants[t.a] = a, I(n, "npcMove", r, {
			n: t.a,
			from: i,
			to: a,
			neutral: t.kind === "neutralMove"
		});
	}
	if (t.kind === "societyRuby" && (B(e, r, Math.max(0, 3 - e.societyUses), n), e.societyUses++, j(e, A("rubySource", r))), t.kind === "kioskReveal") {
		e.kiosk = [];
		for (let t = 0; t < e.players.length + 1; t++) {
			Te(e, "kiosk");
			let t = e.kioskDeck.pop();
			t !== void 0 && e.kiosk.push(t);
		}
		e.kiosk.length && j(e, A("kioskChoose", t.names[0], { names: t.names })), I(n, "kiosk", r, { values: e.kiosk });
	}
	if (t.kind === "auctionFinish") {
		let i = e.players[t.a];
		B(e, i.rid, -a, n), i.rid !== r && B(e, r, a, n), j(e, A("draw", i.rid, {
			mode: "bonus",
			n: 2
		})), F(e, "auction", i.rid, a);
	}
	t.kind === "extraTurn" && je(e), t.kind === "familyHome" && i.family !== 12 && U(e, r, "family", 12, n), t.kind === "advance" && (e.extra ? (e.extra = !1, je(e)) : e.activeIndex === e.players.length - 1 && e.ending ? (e.cleanup = !0, e.tasks = [A("finalCards", e.players[0].rid)]) : (e.activeIndex = (e.activeIndex + 1) % e.players.length, e.activeIndex === 0 && e.round++, je(e)));
}
function rt(t, n, r) {
	let i = C.parse(t), a = {
		config: i,
		players: [],
		board: i.mocha && i.letters ? Array.from({ length: 25 }, (e, t) => t + 1) : i.mocha ? [...y] : i.letters ? [...ue] : i.layout === "long" ? [...le] : i.layout === "ordered" ? Array.from({ length: 16 }, (e, t) => t + 1) : [...v],
		columns: i.mocha || i.letters ? 5 : 4,
		activeIndex: 0,
		round: 1,
		target: n.length === 2 || i.mocha || i.letters ? 6 : 5,
		seed: r,
		cursor: 0,
		tasks: [],
		place: 7,
		actor: "merchant",
		ending: !1,
		done: !1,
		cleanup: !1,
		extra: !1,
		yellowUsed: !1,
		guildTurn: !1,
		lastAction: 0,
		actionActor: "merchant",
		actionPlace: 7,
		caravanPending: null,
		dropped: [],
		npcs: [],
		neutralMerchants: n.length === 2 ? [
			14,
			15,
			16
		] : [],
		post: 0,
		depotCovered: [
			4,
			5,
			6
		],
		rubyPrices: {
			palace: n.length <= 3 ? 5 : 4,
			dealer: n.length === 2 ? 15 : n.length === 3 ? 14 : 12,
			coffee: 6
		},
		mosqueStacks: Array.from({ length: 4 }, () => n.length === 2 ? [2, 4] : n.length === 3 ? [
			2,
			3,
			4
		] : [
			2,
			3,
			4,
			5
		]),
		mosqueRubies: [Math.min(4, n.length), Math.min(4, n.length)],
		tavernStacks: [[
			1,
			2,
			3,
			4
		], [
			1,
			2,
			3,
			4
		]],
		small: [],
		large: [],
		bonusDeck: [],
		bonusDiscard: [],
		guildDeck: [],
		guildDiscard: [],
		letterDeck: [],
		letterDiscard: [],
		kioskDeck: [],
		kioskDiscard: [],
		kiosk: [],
		barrier: null,
		baksheesh: !1,
		caravanLeader: null,
		societyUses: 0,
		dice: [],
		beat: 0,
		log: []
	}, o = e(r, a.cursor++, n.length);
	if (a.players = [...n.slice(o), ...n.slice(0, o)].map((e, t) => ({
		rid: e,
		money: 2 + t,
		goods: [
			0,
			0,
			0,
			0
		],
		coffee: 0,
		capacity: 2,
		rubies: 0,
		merchant: 7,
		family: 12,
		companion: -2,
		assistants: i.neutralAssistants ? [
			"neutral",
			e,
			e,
			e
		] : [
			e,
			e,
			e,
			e
		],
		mosque: [],
		tavern: [],
		letters: [],
		bonus: [],
		guild: [],
		bonusCount: 0,
		guildCount: 0,
		doubleRound: 0
	})), i.layout === "random" || i.mocha && i.letters) {
		let e = !1;
		for (let t = 0; t < 1e3 && !e; t++) {
			a.board = L(a, a.board);
			let t = a.board.indexOf(7), n = i.mocha && i.letters ? 12 : a.columns + 1;
			[a.board[t], a.board[n]] = [a.board[n], a.board[t]];
			let r = a.board.indexOf(8), o = a.board.indexOf(9), s = Math.abs(r % a.columns - o % a.columns), c = Math.abs(Math.floor(r / a.columns) - Math.floor(o / a.columns));
			e = s > 0 && c > 0 && s + c >= 3;
		}
	}
	a.npcs = [
		R(a) + R(a),
		R(a) + R(a),
		i.mocha ? R(a) + R(a) : -1,
		i.letters ? R(a) + R(a) : -1
	], a.small = L(a, [
		0,
		1,
		2,
		3,
		4,
		5
	]), a.large = L(a, [
		0,
		1,
		2,
		3,
		4,
		5
	]), a.bonusDeck = L(a, [
		...i.letters && !i.mocha && i.letterDeck === "new" ? [] : me,
		...i.mocha ? he : [],
		...i.letters ? ge : []
	]), a.guildDeck = i.mocha ? L(a, Array.from({ length: 20 }, (e, t) => t + 1)) : [], a.letterDeck = i.letters ? L(a, Array.from({ length: 36 }, (e, t) => t)) : [], a.kioskDeck = i.letters ? L(a, Array.from({ length: 24 }, (e, t) => t)) : [];
	let s = [];
	for (let e of a.players) Ee(a, e.rid, "bonus", s);
	return je(a), {
		state: a,
		fx: s
	};
}
function it(e, t, n) {
	let r = e.tasks[0];
	if (!r || e.done) return { code: "games.istanbul.errAction" };
	if (t.type === "tick") {
		if (n.by !== "$engine" || !tt(e, r)) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), i = [];
		return t.tasks.shift(), nt(t, r, i), Oe(t, i), t.beat = at(i), {
			state: t,
			fx: i
		};
	}
	if (r.rid !== n.by) return { code: "games.istanbul.errTurn" };
	let i = $e(e, n.by).find((e) => e.choice.id === t.id);
	if (!i) return { code: "games.istanbul.errAction" };
	let a = structuredClone(e), o = [];
	return i.keep || a.tasks.shift(), i.run(a, o), Oe(a, o), a.beat = at(o), {
		state: a,
		fx: o
	};
}
function at(e) {
	return e.some((e) => e.kind === "ruby") ? O.ruby : e.some((e) => e.kind === "dice") ? O.dice : e.some((e) => e.kind === "move" || e.kind === "npcMove" || e.kind === "assistant") ? O.move : e.length ? O.resource : O.step;
}
function ot(e, t) {
	let n = e.players.find((e) => e.rid === t), r = e.tasks[0], i = r?.place ?? ([
		"assistant",
		"merchantFees",
		"encounters",
		"end",
		"start"
	].includes(r?.kind ?? "") ? e.place : e.actionPlace);
	return {
		public: {
			config: e.config,
			players: e.players.map(({ bonus: e, guild: t, doubleRound: n, ...r }) => ({
				...r,
				bonusCount: e.length,
				guildCount: t.length
			})),
			board: e.board,
			columns: e.columns,
			active: Se(e),
			decisionRid: r?.rid ?? "",
			round: e.round,
			target: e.target,
			phase: r?.kind ?? "done",
			required: r?.n ?? 0,
			selection: r?.list ?? [],
			place: i,
			actor: e.actor,
			ending: e.ending,
			done: e.done,
			dropped: e.dropped,
			npcs: e.npcs,
			neutralMerchants: e.neutralMerchants,
			post: e.post,
			depotCovered: e.depotCovered,
			rubyPrices: e.rubyPrices,
			mosqueStacks: e.mosqueStacks,
			mosqueRubies: e.mosqueRubies,
			tavernStacks: e.tavernStacks,
			demandSmall: de[e.small[0]],
			demandLarge: fe[e.large[0]],
			bonusTop: e.bonusDiscard.at(-1) ?? null,
			guildTop: e.guildDiscard.at(-1) ?? null,
			bonusRemaining: e.bonusDeck.length,
			guildRemaining: e.guildDeck.length,
			barrier: e.barrier,
			baksheesh: e.baksheesh,
			caravanLeader: e.caravanLeader,
			societyUses: e.societyUses,
			dice: e.dice,
			kiosk: e.kiosk,
			log: e.log
		},
		private: {
			bonus: n?.bonus ?? [],
			guild: n?.guild ?? [],
			choices: $e(e, t).map((e) => e.choice)
		}
	};
}
function st(e) {
	return [...e.players].sort((e, t) => t.rubies - e.rubies || t.money - e.money || M(t) - M(e) || t.bonus.length - e.bonus.length);
}
function ct(e) {
	if (!e.done) return { phase: e.tasks[0]?.kind ?? "playing" };
	let t = st(e), n = t[0];
	return {
		phase: "done",
		winner: t.filter((e) => e.rubies === n.rubies && e.money === n.money && M(e) === M(n) && e.bonus.length === n.bonus.length).map((e) => e.rid),
		ranking: t.map((e) => e.rid),
		scores: Object.fromEntries(e.players.map((e) => [e.rid, e.rubies]))
	};
}
var lt = {
	meta: S,
	saveCompatibility: { version: "1" },
	schemas: {
		action: w,
		publicView: be,
		privateView: xe,
		config: C
	},
	setup: rt,
	reduce: it,
	viewFor: ot,
	status: ct,
	nextTickIn: (e) => e.tasks[0] && tt(e, e.tasks[0]) ? e.beat : null
}, ut = {
	extend: "games.istanbul.labels.extend",
	fill: "games.istanbul.labels.fill",
	post: "games.istanbul.labels.post",
	caravan: "games.istanbul.labels.caravan",
	fountain: "games.istanbul.labels.fountain",
	kebab: "games.istanbul.labels.kebab",
	blackBefore: "games.istanbul.labels.blackBefore",
	blackAfter: "games.istanbul.labels.blackAfter",
	announce: "games.istanbul.labels.announce",
	sell: "games.istanbul.labels.sell",
	flexMarket: "games.istanbul.labels.flexMarket",
	sendFamily: "games.istanbul.labels.sendFamily",
	buyRuby: "games.istanbul.labels.buyRuby",
	takeMosque: "games.istanbul.labels.takeMosque",
	roast: "games.istanbul.labels.roast",
	guildHall: "games.istanbul.labels.guildHall",
	barrier: "games.istanbul.labels.barrier",
	takeTavern: "games.istanbul.labels.takeTavern",
	bribe: "games.istanbul.labels.bribe",
	takeLetters: "games.istanbul.labels.takeLetters",
	kiosk: "games.istanbul.labels.kiosk",
	auction: "games.istanbul.labels.auction",
	society: "games.istanbul.labels.society",
	catacombs: "games.istanbul.labels.catacombs",
	skipAction: "games.istanbul.labels.skipAction",
	moveMerchant: "games.istanbul.labels.moveMerchant",
	moveCompanion: "games.istanbul.labels.moveCompanion",
	deployCompanion: "games.istanbul.labels.deployCompanion",
	playGuild: "games.istanbul.labels.playGuild",
	moveToPlayer: "games.istanbul.labels.moveToPlayer",
	moveHere: "games.istanbul.labels.moveHere",
	continue: "games.istanbul.labels.continue",
	pickNeutral: "games.istanbul.labels.pickNeutral",
	pickAssistant: "games.istanbul.labels.pickAssistant",
	leaveAssistant: "games.istanbul.labels.leaveAssistant",
	endTurn: "games.istanbul.labels.endTurn",
	payMerchant: "games.istanbul.labels.payMerchant",
	buyExtra: "games.istanbul.labels.buyExtra",
	skip: "games.istanbul.labels.skip",
	payResource: "games.istanbul.labels.payResource",
	takeResource: "games.istanbul.labels.takeResource",
	finish: "games.istanbul.labels.finish",
	recallAssistant: "games.istanbul.labels.recallAssistant",
	takeCompanion: "games.istanbul.labels.takeCompanion",
	recallCompanion: "games.istanbul.labels.recallCompanion",
	selectGood: "games.istanbul.labels.selectGood",
	unselectGood: "games.istanbul.labels.unselectGood",
	sellSelected: "games.istanbul.labels.sellSelected",
	drawDeck: "games.istanbul.labels.drawDeck",
	drawDiscard: "games.istanbul.labels.drawDiscard",
	discardCard: "games.istanbul.labels.discardCard",
	roastMoney: "games.istanbul.labels.roastMoney",
	roastGood: "games.istanbul.labels.roastGood",
	roastCard: "games.istanbul.labels.roastCard",
	barrierFirst: "games.istanbul.labels.barrierFirst",
	barrierSecond: "games.istanbul.labels.barrierSecond",
	takeAction: "games.istanbul.labels.takeAction",
	tavernAgain: "games.istanbul.labels.tavernAgain",
	takeRuby: "games.istanbul.labels.takeRuby",
	payLetter: "games.istanbul.labels.payLetter",
	captureFamily: "games.istanbul.labels.captureFamily",
	useNpc: "games.istanbul.labels.useNpc",
	endEncounters: "games.istanbul.labels.endEncounters",
	freeEncounter: "games.istanbul.labels.freeEncounter",
	payMoney: "games.istanbul.labels.payMoney",
	rewardMoney: "games.istanbul.labels.rewardMoney",
	rewardCard: "games.istanbul.labels.rewardCard",
	acceptDice: "games.istanbul.labels.acceptDice",
	changeFour: "games.istanbul.labels.changeFour",
	reroll: "games.istanbul.labels.reroll",
	changeSix: "games.istanbul.labels.changeSix",
	coverDice: "games.istanbul.labels.coverDice",
	takeTwo: "games.istanbul.labels.takeTwo",
	exchangeOut: "games.istanbul.labels.exchangeOut",
	finishExchange: "games.istanbul.labels.finishExchange",
	bid: "games.istanbul.labels.bid",
	pass: "games.istanbul.labels.pass",
	chooseKiosk: "games.istanbul.labels.chooseKiosk",
	useKiosk: "games.istanbul.labels.useKiosk",
	takeMoney: "games.istanbul.labels.takeMoney",
	goodLetter: "games.istanbul.labels.goodLetter",
	letterGood: "games.istanbul.labels.letterGood",
	moneyGood: "games.istanbul.labels.moneyGood",
	goodMoney: "games.istanbul.labels.goodMoney",
	moneyCard: "games.istanbul.labels.moneyCard",
	cardMoney: "games.istanbul.labels.cardMoney",
	moneyLetter: "games.istanbul.labels.moneyLetter",
	letterMoney: "games.istanbul.labels.letterMoney",
	cardLetter: "games.istanbul.labels.cardLetter",
	letterCard: "games.istanbul.labels.letterCard",
	doubleTurn: "games.istanbul.labels.doubleTurn",
	finishFinal: "games.istanbul.labels.finishFinal",
	playBonus: "games.istanbul.labels.playBonus",
	yellowMosque: "games.istanbul.labels.yellowMosque"
}, dt = {
	start: "games.istanbul.phases.start",
	specialMove: "games.istanbul.phases.specialMove",
	assistant: "games.istanbul.phases.assistant",
	merchantFees: "games.istanbul.phases.merchantFees",
	action: "games.istanbul.phases.action",
	warehouseExtra: "games.istanbul.phases.warehouseExtra",
	resource: "games.istanbul.phases.resource",
	differentGoods: "games.istanbul.phases.differentGoods",
	fountain: "games.istanbul.phases.fountain",
	recallOne: "games.istanbul.phases.recallOne",
	companionRecall: "games.istanbul.phases.companionRecall",
	familyDestination: "games.istanbul.phases.familyDestination",
	familyStep: "games.istanbul.phases.familyStep",
	teleport: "games.istanbul.phases.teleport",
	market: "games.istanbul.phases.market",
	caravanDraw: "games.istanbul.phases.caravanDraw",
	discardCard: "games.istanbul.phases.discardCard",
	roast: "games.istanbul.phases.roast",
	barrierFirst: "games.istanbul.phases.barrierFirst",
	barrierSecond: "games.istanbul.phases.barrierSecond",
	barrierAction: "games.istanbul.phases.barrierAction",
	tavernSecond: "games.istanbul.phases.tavernSecond",
	rubySource: "games.istanbul.phases.rubySource",
	seals: "games.istanbul.phases.seals",
	encounters: "games.istanbul.phases.encounters",
	npcPick: "games.istanbul.phases.npcPick",
	npcPay: "games.istanbul.phases.npcPay",
	captureReward: "games.istanbul.phases.captureReward",
	diceChoice: "games.istanbul.phases.diceChoice",
	depotCover: "games.istanbul.phases.depotCover",
	depotSix: "games.istanbul.phases.depotSix",
	guildBlack: "games.istanbul.phases.guildBlack",
	guildDestination: "games.istanbul.phases.guildDestination",
	exchange: "games.istanbul.phases.exchange",
	auctionStart: "games.istanbul.phases.auctionStart",
	auctionBid: "games.istanbul.phases.auctionBid",
	kioskChoose: "games.istanbul.phases.kioskChoose",
	kioskEffect: "games.istanbul.phases.kioskEffect",
	kioskExchange: "games.istanbul.phases.kioskExchange",
	end: "games.istanbul.phases.end",
	finalCards: "games.istanbul.phases.finalCards",
	discardLetter: "games.istanbul.phases.discardLetter",
	done: "games.istanbul.phases.done",
	auto: "games.istanbul.phases.auto"
}, ft = {
	c0: "games.istanbul.bonusText.c0",
	c1: "games.istanbul.bonusText.c1",
	c2: "games.istanbul.bonusText.c2",
	c3: "games.istanbul.bonusText.c3",
	c4: "games.istanbul.bonusText.c4",
	c5: "games.istanbul.bonusText.c5",
	c6: "games.istanbul.bonusText.c6",
	c7: "games.istanbul.bonusText.c7",
	c8: "games.istanbul.bonusText.c8",
	c9: "games.istanbul.bonusText.c9",
	c10: "games.istanbul.bonusText.c10",
	c11: "games.istanbul.bonusText.c11",
	c12: "games.istanbul.bonusText.c12",
	c13: "games.istanbul.bonusText.c13",
	c14: "games.istanbul.bonusText.c14",
	c15: "games.istanbul.bonusText.c15",
	c16: "games.istanbul.bonusText.c16",
	c17: "games.istanbul.bonusText.c17",
	c18: "games.istanbul.bonusText.c18",
	c19: "games.istanbul.bonusText.c19",
	c20: "games.istanbul.bonusText.c20",
	c21: "games.istanbul.bonusText.c21",
	c22: "games.istanbul.bonusText.c22",
	c23: "games.istanbul.bonusText.c23",
	c24: "games.istanbul.bonusText.c24",
	c25: "games.istanbul.bonusText.c25",
	c26: "games.istanbul.bonusText.c26",
	c27: "games.istanbul.bonusText.c27",
	c28: "games.istanbul.bonusText.c28",
	c29: "games.istanbul.bonusText.c29",
	c30: "games.istanbul.bonusText.c30",
	c31: "games.istanbul.bonusText.c31",
	c32: "games.istanbul.bonusText.c32",
	c33: "games.istanbul.bonusText.c33"
}, pt = {
	c1: "games.istanbul.guildText.c1",
	c2: "games.istanbul.guildText.c2",
	c3: "games.istanbul.guildText.c3",
	c4: "games.istanbul.guildText.c4",
	c5: "games.istanbul.guildText.c5",
	c6: "games.istanbul.guildText.c6",
	c7: "games.istanbul.guildText.c7",
	c8: "games.istanbul.guildText.c8",
	c9: "games.istanbul.guildText.c9",
	c10: "games.istanbul.guildText.c10",
	c11: "games.istanbul.guildText.c11",
	c12: "games.istanbul.guildText.c12",
	c13: "games.istanbul.guildText.c13",
	c14: "games.istanbul.guildText.c14",
	c15: "games.istanbul.guildText.c15",
	c16: "games.istanbul.guildText.c16",
	c17: "games.istanbul.guildText.c17",
	c18: "games.istanbul.guildText.c18",
	c19: "games.istanbul.guildText.c19",
	c20: "games.istanbul.guildText.c20"
}, mt = {
	c0: "games.istanbul.kioskText.c0",
	c1: "games.istanbul.kioskText.c1",
	c2: "games.istanbul.kioskText.c2",
	c3: "games.istanbul.kioskText.c3",
	c4: "games.istanbul.kioskText.c4",
	c5: "games.istanbul.kioskText.c5",
	c6: "games.istanbul.kioskText.c6",
	c7: "games.istanbul.kioskText.c7",
	c8: "games.istanbul.kioskText.c8",
	c9: "games.istanbul.kioskText.c9",
	c10: "games.istanbul.kioskText.c10",
	c11: "games.istanbul.kioskText.c11",
	c12: "games.istanbul.kioskText.c12",
	c13: "games.istanbul.kioskText.c13",
	c14: "games.istanbul.kioskText.c14",
	c15: "games.istanbul.kioskText.c15",
	c16: "games.istanbul.kioskText.c16",
	c17: "games.istanbul.kioskText.c17",
	c18: "games.istanbul.kioskText.c18",
	c19: "games.istanbul.kioskText.c19",
	c20: "games.istanbul.kioskText.c20",
	c21: "games.istanbul.kioskText.c21",
	c22: "games.istanbul.kioskText.c22",
	c23: "games.istanbul.kioskText.c23"
}, ht = {
	p1: "games.istanbul.placeText.p1",
	p2: "games.istanbul.placeText.p2",
	p3: "games.istanbul.placeText.p3",
	p4: "games.istanbul.placeText.p4",
	p5: "games.istanbul.placeText.p5",
	p6: "games.istanbul.placeText.p6",
	p7: "games.istanbul.placeText.p7",
	p8: "games.istanbul.placeText.p8",
	p9: "games.istanbul.placeText.p9",
	p10: "games.istanbul.placeText.p10",
	p11: "games.istanbul.placeText.p11",
	p12: "games.istanbul.placeText.p12",
	p13: "games.istanbul.placeText.p13",
	p14: "games.istanbul.placeText.p14",
	p15: "games.istanbul.placeText.p15",
	p16: "games.istanbul.placeText.p16",
	p17: "games.istanbul.placeText.p17",
	p18: "games.istanbul.placeText.p18",
	p19: "games.istanbul.placeText.p19",
	p20: "games.istanbul.placeText.p20",
	p21: "games.istanbul.placeText.p21",
	p22: "games.istanbul.placeText.p22",
	p23: "games.istanbul.placeText.p23",
	p24: "games.istanbul.placeText.p24",
	p25: "games.istanbul.placeText.p25"
};
//#endregion
//#region src/games/istanbul/components.tsx
function K({ name: e, className: t, children: n, style: r }) {
	let { ref: i, hidden: a } = u(e);
	return /* @__PURE__ */ d("div", {
		ref: i,
		className: t,
		style: {
			...r,
			visibility: a ? "hidden" : void 0
		},
		children: n
	});
}
function q({ resource: e, className: t = "" }) {
	let n = o()(typeof e == "number" ? _e[e] : e === "ruby" ? "games.istanbul.rubies" : e === "money" ? "games.istanbul.money" : e === "any" ? "games.istanbul.anyGood" : "games.istanbul.letters");
	if (typeof e == "number" && e < 4) return /* @__PURE__ */ d("img", {
		className: `ist-icon ${t}`,
		src: a(`games/istanbul/good-${e}.svg`),
		alt: n,
		draggable: !1
	});
	let r = e === 4 ? "coffee" : String(e);
	return /* @__PURE__ */ d("img", {
		className: `ist-icon ${t}`,
		src: a(`games/istanbul/icon-${r}.svg`),
		alt: n,
		draggable: !1
	});
}
function gt({ color: e, kind: t = "merchant", tiny: n = !1 }) {
	return /* @__PURE__ */ d("svg", {
		className: `ist-pawn${n ? " ist-pawn-tiny" : ""}`,
		viewBox: "0 0 44 52",
		"aria-hidden": !0,
		children: t === "family" ? /* @__PURE__ */ d("path", {
			d: "M10 12q12-8 24 0v32q-12 9-24 0Z",
			fill: e,
			stroke: "#382e24",
			strokeWidth: "2"
		}) : t === "companion" ? /* @__PURE__ */ d("path", {
			d: "m7 12 24-5 8 10v28l-24 4-8-8Z",
			fill: e,
			stroke: "#382e24",
			strokeWidth: "2"
		}) : /* @__PURE__ */ f(oe, { children: [
			/* @__PURE__ */ d("path", {
				d: "M5 24v17c0 13 34 13 34 0V24",
				fill: e,
				stroke: "#382e24",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ d("ellipse", {
				cx: "22",
				cy: "24",
				rx: "17",
				ry: "10",
				fill: e,
				stroke: "#382e24",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ d("ellipse", {
				cx: "22",
				cy: "23",
				rx: "11",
				ry: "6",
				fill: "#f4e5c4",
				opacity: ".65"
			}),
			/* @__PURE__ */ d("path", {
				d: "M10 35q12 8 24 0M10 42q12 8 24 0",
				stroke: "#fff",
				opacity: ".35",
				fill: "none"
			})
		] })
	});
}
function J({ kind: e, card: t, back: n = !1 }) {
	let r = o(), i = t === void 0 ? void 0 : e === "bonus" ? ft[`c${t}`] : pt[`c${t}`];
	return /* @__PURE__ */ f("div", {
		className: `ist-card-face ${e === "guild" ? "ist-guild-card" : "ist-bonus-card"}${n ? " ist-card-back" : ""}`,
		children: [/* @__PURE__ */ d("span", {
			className: "ist-card-seal",
			children: /* @__PURE__ */ d(q, { resource: e === "guild" ? 4 : "ruby" })
		}), !n && /* @__PURE__ */ f(oe, { children: [/* @__PURE__ */ d("strong", { children: r(e === "guild" ? "games.istanbul.guildCard" : "games.istanbul.bonusCard", { n: e === "guild" ? t ?? 0 : (t ?? 0) + 1 }) }), /* @__PURE__ */ d("span", { children: i ? r(i) : "" })] })]
	});
}
function _t({ choice: e, nameOf: t, letters: n = [] }) {
	let r = o(), i = e, a = ut[i.label], s = i.label === "chooseKiosk" || i.label === "useKiosk";
	return /* @__PURE__ */ f(oe, { children: [
		i.resource !== void 0 && /* @__PURE__ */ d(q, { resource: i.resource }),
		i.label === "buyRuby" || i.label === "takeRuby" ? /* @__PURE__ */ d(q, { resource: "ruby" }) : null,
		/* @__PURE__ */ f("span", { children: [
			a ? r(a, { n: i.n ?? 1 }) : r("games.istanbul.choose"),
			i.place && /* @__PURE__ */ f("small", { children: [
				i.place,
				" · ",
				r(ve[i.place - 1])
			] }),
			i.target && /* @__PURE__ */ d("small", { children: t(i.target) }),
			i.label === "useNpc" && i.n !== void 0 && /* @__PURE__ */ d("small", { children: r(x[i.n]) }),
			i.label === "takeTavern" && /* @__PURE__ */ d("small", { children: r(i.n === 0 ? "games.istanbul.movementTile" : "games.istanbul.encounterTile") }),
			s && i.n !== void 0 && /* @__PURE__ */ d("small", { children: r(mt[`c${i.n}`]) }),
			i.cost !== void 0 && /* @__PURE__ */ d("small", { children: r(i.label === "sellSelected" ? "games.istanbul.saleReturn" : "games.istanbul.cost", { n: i.cost }) }),
			i.values && /* @__PURE__ */ d("small", { children: i.label === "payLetter" ? i.values.map((e) => {
				let t = n.find((t) => t.id === e);
				return t ? t.delivered ? r("games.istanbul.delivered") : r("games.istanbul.destination", { n: t.destination }) : "";
			}).join(" · ") : i.values.join(" · ") })
		] })
	] });
}
//#endregion
//#region src/games/istanbul/view-player.tsx
function vt(e) {
	return /* @__PURE__ */ d(yt, { ...e }, e.myRid);
}
function yt({ public: e, private: t, members: a, myRid: u, send: se, readOnly: p = !1 }) {
	c();
	let m = o(), h = e, ce = t, [g, _] = i(null), [v, le] = i(null), [y, ue] = i(1), [de, fe] = i(u), pe = r(null), [me, he] = i({
		w: 600,
		h: 500
	}), [ge, b] = i({
		x: 0,
		y: 0
	}), x = r(/* @__PURE__ */ new Map()), S = r(null), C = r(!1), w = p ? [] : ce?.choices ?? [], T = h.players.find((e) => e.rid === u), E = h.players.find((e) => e.rid === de) ?? T ?? h.players[0], D = (e) => a.find((t) => t.rid === e)?.name ?? e, ye = (e) => e === "neutral" ? "#e7dfce" : s[(a.find((t) => t.rid === e)?.colorIndex ?? 0) % s.length].hex;
	n(() => {
		let e = pe.current;
		if (!e) return;
		let t = new ResizeObserver(([e]) => he({
			w: e.contentRect.width,
			h: e.contentRect.height
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let be = h.columns, xe = be / (h.board.length / be) * 1.55, O = Math.max(100, Math.min(me.w - 12, (me.h - 12) * xe)), k = w.filter((e) => e.place !== void 0 && e.card === void 0 && e.guild === void 0), Se = new Set(k.map((e) => e.place)), A = g ?? (h.phase === "start" || h.phase === "specialMove" || h.phase === "familyDestination" || h.phase === "familyStep" || h.phase === "teleport" || h.phase === "barrierFirst" || h.phase === "barrierSecond" || h.phase === "barrierAction" || h.phase === "guildDestination" || h.phase === "rubySource" || h.phase === "recallOne" ? null : h.place), j = w.filter((e) => e.card === void 0 && e.guild === void 0 && (![
		"start",
		"specialMove",
		"familyDestination",
		"familyStep",
		"teleport",
		"barrierFirst",
		"barrierSecond",
		"barrierAction",
		"guildDestination",
		"rubySource",
		"recallOne"
	].includes(h.phase) || e.place === g)), M = (e) => {
		se({
			type: "choose",
			id: e.id
		}), le(null), e.place !== void 0 && _(null);
	}, Ce = dt[h.phase] ?? dt.auto, N = [
		"start",
		"specialMove",
		"familyDestination",
		"familyStep",
		"teleport",
		"barrierFirst",
		"barrierSecond",
		"barrierAction",
		"guildDestination",
		"rubySource",
		"recallOne"
	].includes(h.phase), P = p ? m("games.istanbul.readonly") : h.decisionRid === u ? m(Ce, { n: h.required }) : m("games.istanbul.waiting", { name: D(h.decisionRid) }), F = (e, t) => {
		if (t === "down") {
			x.current.size || (C.current = !1), x.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let t = [...x.current.values()], n = t[0], r = t[1];
			S.current = {
				x: r ? (n.x + r.x) / 2 : n.x,
				y: r ? (n.y + r.y) / 2 : n.y,
				pan: { ...ge },
				d: r ? Math.hypot(n.x - r.x, n.y - r.y) : 0,
				zoom: y
			};
			return;
		}
		if (t === "up") {
			x.current.delete(e.pointerId);
			let t = [...x.current.values()][0];
			S.current = t ? {
				x: t.x,
				y: t.y,
				pan: { ...ge },
				d: 0,
				zoom: y
			} : null;
			return;
		}
		if (!x.current.has(e.pointerId) || !S.current) return;
		x.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
		let n = [...x.current.values()], r = n[0], i = n[1], a = S.current, o = i ? (r.x + i.x) / 2 : r.x, s = i ? (r.y + i.y) / 2 : r.y;
		if (Math.hypot(o - a.x, s - a.y) > 5 && (C.current = !0), i && a.d > 0) {
			Math.abs(Math.hypot(r.x - i.x, r.y - i.y) - a.d) > 5 && (C.current = !0);
			let e = Math.max(1, Math.min(3, a.zoom * Math.hypot(r.x - i.x, r.y - i.y) / a.d)), t = pe.current.getBoundingClientRect(), n = a.x - t.left - t.width / 2, c = a.y - t.top - t.height / 2;
			ue(e), b({
				x: o - a.x + a.pan.x + (n - a.pan.x) * (1 - e / a.zoom),
				y: s - a.y + a.pan.y + (c - a.pan.y) * (1 - e / a.zoom)
			});
		} else y > 1 && b({
			x: a.pan.x + o - a.x,
			y: a.pan.y + s - a.y
		});
	};
	return /* @__PURE__ */ f(ae, {
		adaptive: !0,
		className: "ist-root",
		scroll: !1,
		banner: /* @__PURE__ */ f("div", {
			className: "ist-banner",
			children: [/* @__PURE__ */ f("div", {
				className: "ist-heading",
				children: [
					/* @__PURE__ */ d("span", {
						className: "ist-brand",
						children: m("games.istanbul.name")
					}),
					/* @__PURE__ */ d("span", { children: m("games.istanbul.round", { n: h.round }) }),
					h.ending && /* @__PURE__ */ d("b", { children: m("games.istanbul.finalRound") }),
					/* @__PURE__ */ f("span", {
						className: "ist-target",
						children: [/* @__PURE__ */ d(q, { resource: "ruby" }), h.target]
					})
				]
			}), /* @__PURE__ */ d("div", {
				className: "ist-players",
				children: h.players.map((e) => /* @__PURE__ */ d("button", {
					className: `ist-seat${e.rid === h.active ? " ist-active" : ""}${e.rid === E.rid ? " ist-shown" : ""}`,
					onClick: () => fe(e.rid),
					"aria-pressed": E.rid === e.rid,
					children: /* @__PURE__ */ f(K, {
						name: `seat:${e.rid}`,
						children: [/* @__PURE__ */ d("span", {
							className: "ist-name",
							style: { borderColor: ye(e.rid) },
							children: D(e.rid)
						}), /* @__PURE__ */ f("span", { children: [
							/* @__PURE__ */ d(q, { resource: "ruby" }),
							e.rubies,
							/* @__PURE__ */ d(q, { resource: "money" }),
							e.money,
							h.config.mocha && /* @__PURE__ */ f(oe, { children: [/* @__PURE__ */ d(q, { resource: 4 }), e.coffee] })
						] })]
					})
				}, e.rid))
			})]
		}),
		actionsHeight: "ist-actions-height",
		actions: /* @__PURE__ */ f("div", {
			className: "ist-footer",
			"aria-live": "polite",
			children: [/* @__PURE__ */ d("span", { children: P }), !p && w.filter((e) => e.label === "endTurn" || e.label === "finishFinal" || e.label === "endEncounters" || e.label === "finish").map((e) => /* @__PURE__ */ d("button", {
				className: "ist-control",
				onClick: () => M(e),
				children: /* @__PURE__ */ d(_t, {
					choice: e,
					nameOf: D,
					letters: T?.letters
				})
			}, e.id))]
		}),
		children: [/* @__PURE__ */ f("div", {
			className: "ist-layout",
			children: [/* @__PURE__ */ f("div", {
				className: "ist-bazaar",
				children: [
					/* @__PURE__ */ d(l, {
						kind: "sheen",
						base: "#b99a70",
						line: "#e4d3ab"
					}),
					/* @__PURE__ */ d("div", {
						ref: pe,
						className: "ist-viewport",
						onPointerDown: (e) => F(e, "down"),
						onPointerMove: (e) => F(e, "move"),
						onPointerUp: (e) => F(e, "up"),
						onPointerCancel: (e) => F(e, "up"),
						children: /* @__PURE__ */ f("div", {
							className: "ist-board",
							style: {
								width: O,
								height: O / xe,
								gridTemplateColumns: `repeat(${be},1fr)`,
								transform: `translate(${ge.x}px,${ge.y}px) scale(${y})`
							},
							children: [h.board.map((e) => /* @__PURE__ */ d(bt, {
								place: e,
								v: h,
								legal: Se.has(e),
								selected: g === e,
								nameOf: D,
								colorOf: ye,
								onClick: () => {
									C.current || _(g === e ? null : e);
								}
							}, e)), h.barrier && /* @__PURE__ */ d(St, {
								v: h,
								color: ye(h.barrier.owner),
								name: D(h.barrier.owner)
							})]
						})
					}),
					/* @__PURE__ */ f("div", {
						className: "ist-map-tools",
						children: [
							/* @__PURE__ */ d("button", {
								className: "ist-tool",
								"aria-label": m("games.istanbul.zoomOut"),
								onClick: () => {
									ue(Math.max(1, y - .4)), y <= 1.4 && b({
										x: 0,
										y: 0
									});
								},
								children: "−"
							}),
							/* @__PURE__ */ d("button", {
								className: "ist-tool",
								"aria-label": m("games.istanbul.zoomIn"),
								onClick: () => ue(Math.min(3, y + .4)),
								children: /* @__PURE__ */ d(te, { size: 15 })
							}),
							/* @__PURE__ */ d("button", {
								className: "ist-tool",
								"aria-label": m("games.istanbul.resetView"),
								onClick: () => {
									ue(1), b({
										x: 0,
										y: 0
									});
								},
								children: /* @__PURE__ */ d(ie, { size: 15 })
							})
						]
					}),
					(g !== null || !p && !N && j.some((e) => ![
						"endTurn",
						"finishFinal",
						"endEncounters"
					].includes(e.label))) && /* @__PURE__ */ f("div", {
						className: "ist-decision",
						children: [
							/* @__PURE__ */ f("div", {
								className: "ist-decision-head",
								children: [/* @__PURE__ */ d("strong", { children: A ? `${A} · ${m(ve[A - 1])}` : P }), g !== null && /* @__PURE__ */ d("button", {
									className: "ist-tool",
									"aria-label": m("games.istanbul.close"),
									onClick: () => _(null),
									children: /* @__PURE__ */ d(re, { size: 15 })
								})]
							}),
							g !== null && /* @__PURE__ */ f(oe, { children: [/* @__PURE__ */ d("p", {
								className: "ist-place-description",
								children: m(ht[`p${g}`])
							}), /* @__PURE__ */ d(xt, {
								place: g,
								v: h
							})] }),
							h.phase === "diceChoice" && /* @__PURE__ */ d(K, {
								name: "dice",
								className: "ist-dice",
								children: h.dice.map((e, t) => /* @__PURE__ */ d("span", { children: [
									"",
									"⚀",
									"⚁",
									"⚂",
									"⚃",
									"⚄",
									"⚅"
								][e] }, t))
							}),
							/* @__PURE__ */ d("div", {
								className: "ist-choice-grid",
								children: j.filter((e) => ![
									"endTurn",
									"finishFinal",
									"endEncounters"
								].includes(e.label)).map((e) => /* @__PURE__ */ d("button", {
									className: `ist-choice${e.label === "skip" || e.label === "skipAction" ? " ist-quiet" : ""}`,
									onClick: () => M(e),
									children: /* @__PURE__ */ d(_t, {
										choice: e,
										nameOf: D,
										letters: T?.letters
									})
								}, e.id))
							})
						]
					})
				]
			}), /* @__PURE__ */ f("section", {
				className: "ist-personal",
				children: [
					/* @__PURE__ */ f("div", {
						className: "ist-personal-title",
						children: [
							/* @__PURE__ */ d("strong", { children: D(E.rid) }),
							/* @__PURE__ */ d(K, {
								name: `extension:${E.rid}`,
								children: /* @__PURE__ */ f("span", { children: [
									m("games.istanbul.capacity"),
									" ",
									E.capacity
								] })
							}),
							/* @__PURE__ */ f("span", { children: [
								m("games.istanbul.assistants"),
								" ",
								E.assistants.length
							] })
						]
					}),
					/* @__PURE__ */ d(K, {
						name: `inventory:${E.rid}`,
						className: "ist-inventory",
						children: [
							0,
							1,
							2,
							3,
							...h.config.mocha ? [4] : []
						].map((e) => {
							let t = w.filter((t) => t.resource === e && t.card === void 0 && t.guild === void 0 && t.place === void 0), n = t.find((e) => e.label !== "unselectGood"), r = t.find((e) => e.label === "unselectGood");
							return /* @__PURE__ */ f("div", {
								className: "ist-cargo",
								children: [/* @__PURE__ */ f("button", {
									disabled: !n || E.rid !== u,
									className: `ist-resource${n ? " ist-available" : ""}`,
									onClick: () => n && M(n),
									"aria-label": m(_e[e]),
									children: [
										/* @__PURE__ */ d(q, { resource: e }),
										/* @__PURE__ */ f("strong", { children: [/* @__PURE__ */ d(ee, { value: e === 4 ? E.coffee : E.goods[e] }), e < 4 && /* @__PURE__ */ f("small", { children: ["/", E.capacity] })] }),
										h.phase === "market" && h.selection[e] > 0 && /* @__PURE__ */ d("b", {
											className: "ist-selected-count",
											children: h.selection[e]
										})
									]
								}), r && /* @__PURE__ */ d("button", {
									className: "ist-unselect",
									"aria-label": m("games.istanbul.labels.unselectGood"),
									onClick: () => M(r),
									children: "−"
								})]
							}, e);
						})
					}),
					/* @__PURE__ */ f("div", {
						className: "ist-abilities",
						children: [
							E.mosque.map((e) => /* @__PURE__ */ d(K, {
								name: `mosque:${E.rid}:${e}`,
								children: /* @__PURE__ */ f("span", {
									title: m(_e[e]),
									children: [/* @__PURE__ */ d(q, { resource: e }), e === 0 ? "⚄" : e === 3 ? "⑤" : e === 1 ? "₺" : "↶"]
								})
							}, e)),
							E.tavern.map((e) => /* @__PURE__ */ d(K, {
								name: `tavern:${E.rid}:${e}`,
								children: /* @__PURE__ */ d("span", { children: m(e === 0 ? "games.istanbul.movementTile" : "games.istanbul.encounterTile") })
							}, `t${e}`)),
							w.find((e) => e.id === "yellowMosque") && /* @__PURE__ */ d("button", {
								className: "ist-control",
								onClick: () => M(w.find((e) => e.id === "yellowMosque")),
								children: m("games.istanbul.labels.yellowMosque")
							})
						]
					}),
					/* @__PURE__ */ f(K, {
						name: `hand:${E.rid}`,
						className: "ist-hand",
						children: [
							E.rid === u ? ["bonus", "guild"].flatMap((e) => (ce?.[e] ?? []).map((t, n) => {
								let r = w.find((t) => t.id === `${e === "bonus" ? "bonus" : "guild"}:${n}`);
								return /* @__PURE__ */ d("button", {
									className: `ist-hand-card${r ? " ist-playable" : ""}`,
									onClick: () => le({
										kind: e,
										card: t,
										index: n
									}),
									"aria-label": m(e === "bonus" ? "games.istanbul.bonusCard" : "games.istanbul.guildCard", { n: e === "bonus" ? t + 1 : t }),
									children: /* @__PURE__ */ d(K, {
										name: `${e}:${u}:${n}`,
										children: /* @__PURE__ */ d(J, {
											kind: e,
											card: t
										})
									})
								}, `${e}:${n}`);
							})) : Array.from({ length: E.bonusCount + E.guildCount }, (e, t) => /* @__PURE__ */ d("div", {
								className: "ist-hand-card",
								children: /* @__PURE__ */ d(J, {
									kind: t < E.bonusCount ? "bonus" : "guild",
									back: !0
								})
							}, t)),
							/* @__PURE__ */ f(K, {
								name: "bonusDeck",
								className: "ist-deck",
								children: [/* @__PURE__ */ d(J, {
									kind: "bonus",
									back: !0
								}), /* @__PURE__ */ d("span", { children: h.bonusRemaining })]
							}),
							h.config.mocha && /* @__PURE__ */ f(K, {
								name: "guildDeck",
								className: "ist-deck",
								children: [/* @__PURE__ */ d(J, {
									kind: "guild",
									back: !0
								}), /* @__PURE__ */ d("span", { children: h.guildRemaining })]
							})
						]
					}),
					h.config.letters && /* @__PURE__ */ d("div", {
						className: "ist-letters",
						children: E.letters.map((e) => {
							let t = E.rid === u ? w.find((t) => t.values?.includes(e.id) && t.label === "payLetter") : void 0;
							return /* @__PURE__ */ d("button", {
								className: `ist-letter${e.delivered ? " ist-letter-delivered" : ""}${t ? " ist-available" : ""}`,
								disabled: !t,
								onClick: () => t && M(t),
								title: e.delivered ? m("games.istanbul.delivered") : m("games.istanbul.destination", { n: e.destination }),
								children: /* @__PURE__ */ f(K, {
									name: `letter:${e.id}`,
									children: [/* @__PURE__ */ d(q, { resource: "letter" }), /* @__PURE__ */ d("span", { children: e.delivered ? "②" : e.destination })]
								})
							}, e.id);
						})
					}),
					/* @__PURE__ */ d(K, {
						name: "bonusDiscard",
						className: "ist-discard-mark"
					}),
					/* @__PURE__ */ d(K, {
						name: "guildDiscard",
						className: "ist-discard-mark"
					})
				]
			})]
		}), v && /* @__PURE__ */ d("div", {
			className: "ist-card-modal",
			onClick: () => le(null),
			children: /* @__PURE__ */ f("div", {
				className: "ist-card-dialog",
				role: "dialog",
				"aria-modal": "true",
				onClick: (e) => e.stopPropagation(),
				children: [
					/* @__PURE__ */ d("button", {
						className: "ist-tool ist-dialog-close",
						"aria-label": m("games.istanbul.close"),
						onClick: () => le(null),
						children: /* @__PURE__ */ d(re, { size: 20 })
					}),
					/* @__PURE__ */ d(J, {
						kind: v.kind,
						card: v.card
					}),
					w.filter((e) => v.kind === "bonus" ? e.card === v.card && (e.id === `bonus:${v.index}` || e.id === `discard:bonus:${v.index}` || e.id === `npcCard:${v.index}` || e.id.startsWith(`six:${v.index}:`)) : e.guild === v.card && (e.id === `guild:${v.index}` || e.id === `discard:guild:${v.index}`)).map((e) => /* @__PURE__ */ d("button", {
						className: "ist-control",
						onClick: () => M(e),
						children: /* @__PURE__ */ d(_t, {
							choice: e,
							nameOf: D,
							letters: T?.letters
						})
					}, e.id)),
					/* @__PURE__ */ f("button", {
						className: "ist-control ist-quiet",
						onClick: () => le(null),
						children: [/* @__PURE__ */ d(ne, { size: 15 }), m("games.istanbul.close")]
					})
				]
			})
		})]
	});
}
function bt({ place: e, v: t, legal: n, selected: r, nameOf: i, colorOf: s, onClick: c }) {
	let l = o();
	return /* @__PURE__ */ d(K, {
		name: `place:${e}`,
		className: `ist-place${n ? " ist-legal" : ""}${r ? " ist-selected" : ""}`,
		children: /* @__PURE__ */ f("button", {
			onClick: c,
			className: "ist-place-hit",
			"aria-label": `${e} · ${l(ve[e - 1])}`,
			"aria-pressed": r,
			children: [
				/* @__PURE__ */ d("img", {
					src: a(`games/istanbul/place-${e}.svg`),
					className: "ist-place-art",
					alt: "",
					draggable: !1
				}),
				/* @__PURE__ */ f("div", {
					className: "ist-place-name",
					children: [/* @__PURE__ */ d("b", { children: e }), /* @__PURE__ */ d("span", { children: l(ve[e - 1]) })]
				}),
				/* @__PURE__ */ f("div", {
					className: "ist-token-row",
					children: [
						t.players.flatMap((t) => [
							"merchant",
							"family",
							"companion"
						].filter((n) => t[n] === e).map((e) => /* @__PURE__ */ f(K, {
							name: `pawn:${t.rid}:${e}`,
							className: "ist-token",
							children: [/* @__PURE__ */ d(gt, {
								color: s(t.rid),
								kind: e
							}), /* @__PURE__ */ d("small", { children: i(t.rid) })]
						}, `${t.rid}:${e}`))),
						t.dropped.filter((t) => t.place === e).map((e, t) => /* @__PURE__ */ d("span", {
							className: "ist-assistant",
							style: { "--ist-owner": s(e.owner) },
							title: e.owner === "neutral" ? l("games.istanbul.neutral") : i(e.owner),
							children: /* @__PURE__ */ d("small", { children: e.owner === "neutral" ? "○" : i(e.owner).slice(0, 1) })
						}, `a${t}`)),
						t.neutralMerchants.map((t, n) => t === e ? /* @__PURE__ */ d(K, {
							name: `neutral:${n}`,
							className: "ist-neutral-merchant",
							children: "○"
						}, `n${n}`) : null)
					]
				}),
				/* @__PURE__ */ f("div", {
					className: "ist-place-bottom",
					children: [/* @__PURE__ */ d(xt, {
						place: e,
						v: t,
						compact: !0
					}), t.npcs.map((t, n) => t === e ? /* @__PURE__ */ d(K, {
						name: `npc:${n}`,
						className: "ist-npc",
						style: { background: [
							"#5d3c83",
							"#55544d",
							"#744d2c",
							"#a6342d"
						][n] },
						children: /* @__PURE__ */ d("span", {
							title: l(x[n]),
							children: [
								"◆",
								"▰",
								"●",
								"✉"
							][n]
						})
					}, n) : null)]
				})
			]
		})
	});
}
function xt({ place: e, v: t, compact: n = !1 }) {
	return e === 13 ? /* @__PURE__ */ d("span", {
		className: "ist-cost",
		children: pe.slice(0, t.rubyPrices.palace).map((e, t) => /* @__PURE__ */ d("span", { children: /* @__PURE__ */ d(q, { resource: e === 4 ? "any" : e }) }, t))
	}) : e === 16 || e === 20 ? /* @__PURE__ */ f("span", {
		className: "ist-cost",
		children: [
			/* @__PURE__ */ d(q, { resource: e === 16 ? "money" : 4 }),
			e === 16 ? t.rubyPrices.dealer : t.rubyPrices.coffee,
			/* @__PURE__ */ d(q, { resource: "ruby" })
		]
	}) : e === 10 || e === 11 ? /* @__PURE__ */ d("span", {
		className: "ist-cost",
		children: (e === 10 ? t.demandLarge : t.demandSmall).map((e, t) => e ? /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d(q, { resource: t }), e] }, t) : null)
	}) : e >= 2 && e <= 4 ? /* @__PURE__ */ d(q, { resource: e - 2 }) : e === 1 ? /* @__PURE__ */ f("span", {
		className: "ist-cost",
		children: [/* @__PURE__ */ d(q, { resource: "money" }), "7"]
	}) : e === 14 || e === 15 ? /* @__PURE__ */ d("span", {
		className: "ist-cost",
		children: (e === 14 ? [0, 1] : [3, 2]).map((e) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d(q, { resource: e }), t.mosqueStacks[e][0] ?? "—"] }, e))
	}) : !n && e === 19 ? /* @__PURE__ */ f("span", {
		className: "ist-cost",
		children: [
			(t.baksheesh ? [
				0,
				1,
				3
			] : [
				2,
				2,
				2
			]).map((e, t) => /* @__PURE__ */ d(q, { resource: e }, t)),
			/* @__PURE__ */ d(q, { resource: 4 }),
			"4"
		]
	}) : null;
}
function St({ v: e, color: t, name: n }) {
	let r = o(), i = e.barrier, a = e.board.indexOf(i.a), s = e.board.indexOf(i.b), c = e.board.length / e.columns, l = Math.floor(a / e.columns) === Math.floor(s / e.columns), ee = l ? Math.max(a % e.columns, s % e.columns) / e.columns * 100 : (a % e.columns + .5) / e.columns * 100, te = l ? (Math.floor(a / e.columns) + .5) / c * 100 : Math.max(Math.floor(a / e.columns), Math.floor(s / e.columns)) / c * 100;
	return /* @__PURE__ */ d(K, {
		name: "barrier",
		className: `ist-barrier${l ? " ist-barrier-vertical" : ""}`,
		style: {
			left: `${ee}%`,
			top: `${te}%`,
			"--ist-owner": t
		},
		children: /* @__PURE__ */ d("span", {
			title: r("games.istanbul.barrierOwner", { name: n }),
			"aria-label": r("games.istanbul.barrierOwner", { name: n })
		})
	});
}
var Ct = {
	ruby: 38,
	money: 1,
	good: 1.9,
	route: .3,
	card: 3,
	mosque: 8,
	fee: 1
}, Y = (e) => e.reduce((e, t) => e + t, 0);
function wt(e, t, n) {
	return t === 4 ? 1.8 : e.goods[t] >= e.capacity ? 0 : (t === 3 ? 1.25 : 1) * n.good;
}
function Tt(e, t, n, r) {
	let i = Y(t.goods), a = n >= 2 && n <= 4 ? (t.capacity - t.goods[n - 2]) * r.good : 0;
	if (a) return a;
	if (n >= 2 && n <= 4) return -.5;
	if (n === 1) return t.capacity < 5 && t.money >= 7 ? 5 + (t.capacity === 4 ? r.ruby : 2) - 7 * r.money : -1;
	if (n === 5) return 3.7 + (t.goods.some((e) => e < t.capacity) ? 2 : 0);
	if (n === 6) return r.card + (e.config.mocha ? 1.8 : 0);
	if (n === 7) return Math.max(0, 3.5 - t.assistants.length) * 3 + e.dropped.filter((e) => e.owner === t.rid).length * .4 + (e.config.letters && t.companion === -2 ? 2 : 0);
	if (n === 8) return wt(t, 3, r) * .92 + Math.max(...[
		0,
		1,
		2
	].map((e) => wt(t, e, r)));
	if (n === 9) return 4.5 * r.money;
	if (n === 10 || n === 11) {
		let i = Y((n === 10 ? e.demandLarge : e.demandSmall).map((e, n) => Math.min(e, t.goods[n])));
		return (n === 10 ? [
			0,
			3,
			7,
			12,
			18,
			25
		] : [
			0,
			2,
			5,
			9,
			14,
			20
		])[i] * r.money - i * r.good;
	}
	if (n === 12) return t.family === 12 ? 6 : 0;
	if (n === 13) {
		let n = [
			0,
			0,
			0,
			0
		];
		for (let t of [
			3,
			0,
			1,
			2,
			4,
			3,
			0,
			1,
			2,
			4
		].slice(0, e.rubyPrices.palace)) t < 4 && n[t]++;
		return n.every((e, n) => t.goods[n] >= e) && i >= e.rubyPrices.palace ? r.ruby - e.rubyPrices.palace * r.good : -2;
	}
	if (n === 14 || n === 15) {
		let i = n === 14 ? [0, 1] : [3, 2];
		return Math.max(-1, ...i.map((n) => !t.mosque.includes(n) && t.goods[n] >= (e.mosqueStacks[n][0] ?? 99) ? r.mosque + (t.mosque.includes(i[0] === n ? i[1] : i[0]) ? r.ruby : 0) + (n === 1 ? 2 : 0) : -1));
	}
	if (n === 16) return t.money >= e.rubyPrices.dealer ? r.ruby - e.rubyPrices.dealer * r.money : -1;
	if (n === 17) return (t.money >= 2 ? 1.6 : 0) + (i > 0 ? 1.7 : 0) + +(t.bonusCount + t.guildCount > 0);
	if (n === 18) return 4.8;
	if (n === 19) {
		let n = e.baksheesh ? [
			1,
			1,
			0,
			1
		] : [
			0,
			0,
			3,
			0
		];
		return t.coffee >= 4 && n.every((e, n) => t.goods[n] >= e) ? r.ruby - 7 : t.coffee >= 1 ? 6 : -1;
	}
	return n === 20 ? t.coffee >= e.rubyPrices.coffee ? r.ruby - e.rubyPrices.coffee * 1.8 : -1 : n === 21 ? 5 : n === 22 ? 5.5 : n === 23 ? t.money > 0 ? 4.5 : 0 : n === 24 ? Y(t.letters.map((e) => e.delivered ? 2 : 1)) >= 6 ? r.ruby - 9 : -1 : n === 25 ? 3 : 0;
}
function Et(e, t, n) {
	let r = e.board.indexOf(t), i = e.board.indexOf(n);
	return Math.abs(r % e.columns - i % e.columns) + Math.abs(Math.floor(r / e.columns) - Math.floor(i / e.columns));
}
function Dt(e, t, n, r, i = Ct) {
	let a = t.players.find((e) => e.rid === r), o = e.resource ?? 0, s = e.label;
	if (s === "moveMerchant" || s === "moveCompanion" || s === "moveHere" || s === "moveToPlayer") {
		let n = e.place, o = s !== "moveCompanion" && t.phase !== "teleport";
		if (!(n === 7 || !o || a.assistants.length > 0 || t.dropped.some((e) => e.place === n && (e.owner === r || e.owner === "neutral")))) return -1e3;
		let c = n === 7 ? 0 : 2 * t.players.filter((e) => e.rid !== r).reduce((e, t) => e + Number(t.merchant === n) + Number(t.companion === n), 0) + 2 * t.neutralMerchants.filter((e) => e === n).length;
		if (c > a.money) return -100;
		let l = Math.max(...t.board.map((e) => Tt(t, a, e, i) / (1 + Et(t, n, e) * .5)));
		return Tt(t, {
			...a,
			money: a.money - c
		}, n, i) - c * i.fee + i.route * l + Y(a.letters.filter((e) => !e.delivered && e.destination === n).map(() => 2.8));
	}
	if (s === "playGuild") return [
		0,
		14,
		10,
		10,
		10,
		10,
		10,
		5,
		10,
		9,
		15,
		20,
		9,
		35,
		17,
		17,
		35,
		8,
		7,
		7,
		35
	][e.guild ?? 0];
	if (s === "playBonus") {
		let t = e.card;
		if ([
			1,
			2,
			3,
			4,
			5,
			14,
			16,
			17,
			23,
			25,
			26,
			28
		].includes(t)) return 50;
		if (t === 10) return a.family === 12 ? -1 : 30;
		if ([
			11,
			12,
			13,
			20,
			21,
			27,
			29
		].includes(t)) return 40;
		if (t === 8) return a.assistants.length < 2 ? 30 : -3;
		if (t === 19) return -5;
		if (t === 33) return 20;
		if ([
			0,
			6,
			7,
			18,
			30,
			31,
			32
		].includes(t)) return -2;
		if (t === 15) return a.guildCount === 0 ? 5 : -1;
		if (t === 22) return -3;
		if (t === 24) return 3;
	}
	if (s === "yellowMosque") return a.assistants.length === 0 ? 20 : -10;
	if (s === "deployCompanion") return 1;
	if (s === "pickAssistant" || s === "pickNeutral" || s === "leaveAssistant" || s === "continue") return 10;
	if (s === "payMerchant") return 5;
	if (s === "fountain") return 9;
	if (s === "buyRuby" || s === "takeRuby" || s === "society") return 100;
	if (s === "extend") return 25;
	if (s === "takeMosque") return 35 + +(o === 1);
	if (s === "fill" || s === "post" || s === "caravan" || s === "blackAfter") return 20;
	if (s === "blackBefore") return 10;
	if (s === "announce") {
		let t = e.n ?? 3, n = 0;
		for (let e = 1; e <= 6; e++) for (let r = 1; r <= 6; r++) n += e + r >= t ? t : 2;
		return n / 36;
	}
	return s === "sell" ? 20 : s === "flexMarket" ? 22 : s === "selectGood" ? 100 + (o === 3 ? -1 : 0) : s === "unselectGood" ? -100 : s === "sellSelected" ? 30 : s === "takeResource" || s === "takeTwo" ? wt(a, o, i) + +(a.goods[o] < 2 && !a.mosque.includes(o)) : s === "payResource" || s === "exchangeOut" ? -wt(a, o, i) + (Ot(a, o) > 2 ? 2 : 0) - (s === "exchangeOut" && t.required >= 1 ? 10 : 0) : s === "finishExchange" ? 0 : s === "discardCard" ? -(e.card === void 0 ? At(e.guild ?? 0) : kt(e.card, a)) : s === "drawDiscard" ? t.bonusTop === null ? 0 : kt(t.bonusTop, a) : s === "drawDeck" ? i.card : s === "recallAssistant" || s === "takeCompanion" ? 5 : s === "recallCompanion" ? a.companion > 0 && Et(t, a.companion, a.merchant) > 2 ? 3 : -1 : s === "sendFamily" || s === "takeAction" ? Tt(t, a, e.place, i) : s === "useNpc" ? 8 : s === "captureFamily" ? 10 : s === "freeEncounter" ? 100 : s === "rewardMoney" ? a.money < 8 ? 5 : 3 : s === "rewardCard" ? 4 : s === "payMoney" ? -2 : s === "payLetter" ? -(e.n ?? 1) + +(e.n === 2 && t.required > 1) : s === "acceptDice" ? 0 : s === "changeFour" ? 4 - t.dice[(e.n ?? 1) - 1] > .5 ? 2 : -1 : s === "reroll" ? Y(t.dice) < 6 ? 1 : -1 : s === "changeSix" ? t.dice[(e.n ?? 1) - 1] <= 2 && Y(t.dice) < 8 ? 1 : -1 : s === "coverDice" ? Y([
		1,
		2,
		3,
		4,
		5,
		6
	].filter((t) => !e.values?.includes(t)).map((e) => e === 1 ? 2 : e === 2 ? 3 : wt(a, e === 3 ? 2 : e === 4 ? 0 : e === 5 ? 1 : 3, i))) : s === "takeLetters" ? 8 : s === "guildHall" ? 10 : s === "roast" ? 5 : s === "roastMoney" ? 2 : s === "roastGood" ? Y(a.goods) > 1 ? 1 : -1 : s === "roastCard" ? a.bonusCount > 2 || a.guildCount > 1 ? 1 : -1 : s === "takeTavern" ? 10 : s === "bribe" ? 90 : s === "barrier" ? a.coffee >= 5 ? 3 : -1 : s === "barrierFirst" || s === "barrierSecond" ? Tt(t, a, e.place, i) : s === "tavernAgain" ? 3 : s === "kiosk" ? 8 : s === "auction" ? 4 : s === "bid" ? (e.n ?? 1) <= Math.min(4, Math.floor(a.money / 3)) ? 5 - (e.n ?? 1) * .1 : -5 : s === "chooseKiosk" || s === "useKiosk" ? jt(e.n ?? 0, a) : s === "takeMoney" ? e.n ?? 0 : [
		"goodLetter",
		"letterGood",
		"moneyGood",
		"goodMoney",
		"moneyCard",
		"cardMoney",
		"moneyLetter",
		"letterMoney",
		"cardLetter",
		"letterCard"
	].includes(s) ? s === "goodMoney" ? 2 : s === "moneyGood" ? 1 : .5 : s === "catacombs" ? 4 : s === "buyExtra" ? a.money > 3 && Y(a.goods) < a.capacity * 3 ? 1 : -1 : s === "doubleTurn" ? a.rubies >= t.target - 1 ? 8 : .5 : [
		"endTurn",
		"endEncounters",
		"finish",
		"finishFinal",
		"pass"
	].includes(s) ? -.1 : s === "skip" || s === "skipAction" ? -2 : 0;
}
function Ot(e, t) {
	return t === 4 ? e.coffee : e.goods[t];
}
function kt(e, t) {
	return e === 5 ? 5 : e === 4 ? 3 : e === 16 && t.coffee ? 7 : [
		1,
		2,
		3
	].includes(e) ? 5 : [
		12,
		13,
		21,
		29
	].includes(e) ? 4 : 3;
}
function At(e) {
	return [
		1,
		13,
		14,
		15,
		16,
		20
	].includes(e) ? 12 : 7;
}
function jt(e, t) {
	return e === 10 || e === 23 ? t.capacity < 5 ? 8 : 0 : e === 9 ? 4 : e === 20 ? 3.2 : [
		11,
		12,
		16
	].includes(e) ? 3 : [
		13,
		14,
		19
	].includes(e) ? 4 : e === 7 ? 3.5 : e === 6 || e === 8 ? 0 : 2.5;
}
function Mt(e = Ct) {
	return (t, n) => {
		let r = t.private;
		if (!r?.choices.length || t.public.decisionRid !== n.rid) return null;
		let i = r.choices;
		if (n.difficulty === "weak") {
			let e = Math.floor(4294967296 / i.length) * i.length, t;
			do
				t = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
			while (t >= e);
			return { action: {
				type: "choose",
				id: i[t % i.length].id
			} };
		}
		return { action: {
			type: "choose",
			id: i.map((i, a) => ({
				c: i,
				i: a,
				value: Dt(i, t.public, r, n.rid, e)
			})).sort((e, t) => t.value - e.value || e.i - t.i)[0].c.id
		} };
	};
}
var Nt = Mt(), X = (e) => e.data;
function Z(e, t) {
	return e.anchor(`inventory:${t}`) ?? e.anchor(`seat:${t}`);
}
function Q(e, t, n) {
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - n) / 2,
		w: t,
		h: n
	};
}
function $(e, t) {
	return e.anchor(`place:${t}`);
}
function Pt(e, t) {
	return s[(e.member(t ?? "")?.colorIndex ?? 0) % s.length].hex;
}
var Ft = {
	move(e, t) {
		let n = X(e), r = String(n.actor), i = `pawn:${e.rid}:${r}`, a = Number(n.from) > 0 ? $(t, Number(n.from)) : Z(t, e.rid), o = t.anchor(i) ?? $(t, Number(n.to)) ?? Z(t, e.rid);
		return !a || !o ? null : {
			ms: O.move,
			hide: t.anchor(i) ? [i] : [],
			node: /* @__PURE__ */ d(p, {
				from: Q(a, o.w, o.h),
				to: o,
				ms: O.move,
				children: /* @__PURE__ */ d("div", {
					className: "ist-fx-sprite",
					children: /* @__PURE__ */ d(gt, {
						color: Pt(t, e.rid),
						kind: r
					})
				})
			})
		};
	},
	assistant(e, t) {
		let n = X(e), r = Number(n.from) ? $(t, Number(n.from)) : Z(t, e.rid), i = Number(n.to) ? $(t, Number(n.to)) : Z(t, e.rid);
		return !r || !i ? null : {
			ms: O.move,
			node: /* @__PURE__ */ d(p, {
				from: Q(r, 22, 14),
				to: Q(i, 22, 14),
				ms: O.move,
				children: /* @__PURE__ */ d("div", { style: {
					width: 22,
					height: 14,
					borderRadius: "50%",
					background: n.owner === "neutral" ? "#e7dfce" : Pt(t, String(n.owner)),
					border: "1px solid #3d3026"
				} })
			})
		};
	},
	draw(e, t) {
		let n = X(e), r = n.kind === "guild" ? "guild" : "bonus", i = t.anchor(r === "guild" ? "guildDeck" : "bonusDeck"), a = `${r}:${e.rid}:${n.index}`, o = e.rid === t.myRid ? t.anchor(a) ?? t.anchor(`hand:${e.rid}`) : t.anchor(`seat:${e.rid}`);
		if (!i || !o) return null;
		let s = e.secret;
		return {
			ms: O.card,
			hide: t.anchor(a) ? [a] : [],
			node: /* @__PURE__ */ d(p, {
				from: Q(i, 65, 92),
				to: Q(o, 65, 92),
				ms: O.card,
				children: /* @__PURE__ */ d("div", {
					className: "ist-fx-card",
					children: /* @__PURE__ */ d(J, {
						kind: r,
						card: s?.card,
						back: s?.card === void 0
					})
				})
			})
		};
	},
	discard(e, t) {
		let n = X(e), r = n.kind === "guild" ? "guild" : "bonus", i = t.anchor(`hand:${e.rid}`) ?? Z(t, e.rid), a = $(t, r === "guild" ? 18 : 6);
		return !i || !a ? null : {
			ms: O.card,
			node: /* @__PURE__ */ d(p, {
				from: Q(i, 65, 92),
				to: Q(a, 65, 92),
				ms: O.card,
				children: /* @__PURE__ */ d("div", {
					className: "ist-fx-card",
					children: /* @__PURE__ */ d(J, {
						kind: r,
						card: Number(n.card)
					})
				})
			})
		};
	},
	play(e, t) {
		return Ft.discard(e, t);
	},
	ruby(e, t) {
		let n = X(e), r = $(t, Number(n.from)), i = Z(t, e.rid);
		return !r || !i ? null : {
			ms: O.ruby,
			node: /* @__PURE__ */ d(p, {
				from: Q(r, 42, 42),
				to: Q(i, 42, 42),
				ms: O.ruby,
				children: /* @__PURE__ */ d("div", {
					className: "ist-fx-resource",
					children: /* @__PURE__ */ d(q, { resource: "ruby" })
				})
			})
		};
	},
	resource(e, t) {
		let n = X(e), r = $(t, Number(n.from)), i = Z(t, e.rid);
		return !r || !i ? null : {
			ms: O.resource,
			node: /* @__PURE__ */ d(p, {
				from: Q(r, 36, 36),
				to: Q(i, 36, 36),
				ms: O.resource,
				children: /* @__PURE__ */ d("div", {
					className: "ist-fx-resource",
					children: /* @__PURE__ */ d(q, { resource: Number(n.resource) })
				})
			})
		};
	},
	money(e, t) {
		let n = X(e), r = Z(t, e.rid);
		return r ? {
			ms: O.resource,
			node: /* @__PURE__ */ d(se, {
				at: r,
				ms: O.resource,
				children: /* @__PURE__ */ f("span", {
					className: "ist-fx-resource",
					children: [
						Number(n.n) > 0 ? "+" : "",
						String(n.n),
						" ₺"
					]
				})
			})
		} : null;
	},
	letter(e, t) {
		let n = X(e), r = $(t, Number(n.from)), i = t.anchor(`letter:${n.n}`) ?? Z(t, e.rid);
		return !r || !i ? null : {
			ms: O.card,
			hide: t.anchor(`letter:${n.n}`) ? [`letter:${n.n}`] : [],
			node: /* @__PURE__ */ d(p, {
				from: Q(r, 44, 30),
				to: Q(i, 44, 30),
				ms: O.card,
				children: /* @__PURE__ */ d("div", {
					className: "ist-fx-resource",
					children: /* @__PURE__ */ d(q, { resource: "letter" })
				})
			})
		};
	},
	deliver(e, t) {
		let n = X(e), r = t.anchor(`letter:${n.letter}`) ?? Z(t, e.rid);
		return r ? {
			ms: O.card,
			node: /* @__PURE__ */ d(m, {
				at: r,
				ms: O.card
			})
		} : null;
	},
	spendLetter(e, t) {
		let n = X(e), r = Z(t, e.rid), i = $(t, Number(n.to)) ?? r;
		return !r || !i ? null : {
			ms: O.card,
			node: /* @__PURE__ */ d(p, {
				from: Q(r, 44, 30),
				to: Q(i, 44, 30),
				ms: O.card,
				children: /* @__PURE__ */ d("div", {
					className: "ist-fx-resource",
					children: /* @__PURE__ */ d(q, { resource: "letter" })
				})
			})
		};
	},
	dice(e, t) {
		let n = t.anchor("dice") ?? Z(t, e.rid);
		return n ? {
			ms: O.dice,
			node: /* @__PURE__ */ d(m, {
				at: n,
				ms: O.dice
			})
		} : null;
	},
	npcMove(e, t) {
		let n = X(e), r = `${n.neutral ? "neutral" : "npc"}:${n.n}`, i = $(t, Number(n.from)), a = t.anchor(r) ?? $(t, Number(n.to));
		if (!i || !a) return null;
		let o = Number(n.n);
		return {
			ms: O.move,
			hide: t.anchor(r) ? [r] : [],
			node: /* @__PURE__ */ d(p, {
				from: Q(i, 22, 22),
				to: Q(a, 22, 22),
				ms: O.move,
				children: /* @__PURE__ */ d("span", {
					style: {
						display: "grid",
						placeItems: "center",
						width: 22,
						height: 22,
						borderRadius: "50%",
						color: "#fff",
						background: n.neutral ? "#5b5146" : [
							"#5d3c83",
							"#55544d",
							"#744d2c",
							"#a6342d"
						][o],
						border: "2px solid #f5e8ca"
					},
					children: n.neutral ? "○" : [
						"◆",
						"▰",
						"●",
						"✉"
					][o]
				})
			})
		};
	},
	extension(e, t) {
		return It(e, t, "extension", 1);
	},
	mosque(e, t) {
		let n = X(e), r = Number(n.resource);
		return It(e, t, `mosque:${r}`, r < 2 ? 14 : 15, r);
	},
	tavern(e, t) {
		return It(e, t, `tavern:${X(e).n}`, 19);
	},
	barrier(e, t) {
		let n = t.anchor("barrier");
		return n ? {
			ms: O.resource,
			node: /* @__PURE__ */ d(m, {
				at: n,
				ms: O.resource
			})
		} : null;
	},
	kiosk(e, t) {
		let n = $(t, 22);
		return n ? {
			ms: O.card,
			node: /* @__PURE__ */ d(m, {
				at: n,
				ms: O.card
			})
		} : null;
	}
};
function It(e, t, n, r, i) {
	let [a, o] = n.split(":"), s = `${a}:${e.rid}${o === void 0 ? "" : `:${o}`}`, c = $(t, r), l = t.anchor(s) ?? Z(t, e.rid);
	return !c || !l ? null : {
		ms: O.resource,
		hide: t.anchor(s) ? [s] : [],
		node: /* @__PURE__ */ d(p, {
			from: Q(c, 38, 30),
			to: Q(l, 38, 30),
			ms: O.resource,
			children: /* @__PURE__ */ d("div", {
				className: "ist-fx-tile",
				children: i === void 0 ? a === "extension" ? "▤" : o === "0" ? "↔" : "◆" : /* @__PURE__ */ d(q, { resource: i })
			})
		})
	};
}
//#endregion
//#region src/games/istanbul/game-over.tsx
function Lt(e) {
	let t = o(), [n, r] = i(!0), a = e.public, s = e.result, c = (t) => e.members.find((e) => e.rid === t)?.name ?? t, l = [
		{
			key: "games.istanbul.rubies",
			value: (e) => a.players.find((t) => t.rid === e).rubies,
			icon: "ruby"
		},
		{
			key: "games.istanbul.money",
			value: (e) => a.players.find((t) => t.rid === e).money,
			icon: "money"
		},
		{
			key: "games.istanbul.goods",
			value: (e) => a.players.find((t) => t.rid === e).goods.reduce((e, t) => e + t, 0),
			icon: 0
		},
		{
			key: "games.istanbul.bonus",
			value: (e) => a.players.find((t) => t.rid === e).bonusCount,
			icon: null
		}
	];
	return /* @__PURE__ */ f("div", {
		className: "ist-root ist-result-root",
		children: [
			/* @__PURE__ */ d(yt, {
				...e,
				send: () => {},
				readOnly: !0
			}),
			/* @__PURE__ */ d("button", {
				className: "ist-control ist-review-return",
				onClick: () => r(!0),
				children: t("games.istanbul.showResult")
			}),
			n && /* @__PURE__ */ d("div", {
				className: "ist-result-layer",
				children: /* @__PURE__ */ f("section", {
					className: "ist-ledger",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("games.istanbul.ledger"),
					children: [
						/* @__PURE__ */ f("header", {
							className: "ist-ledger-head",
							children: [/* @__PURE__ */ d("h1", { children: t("games.istanbul.ledger") }), /* @__PURE__ */ d("button", {
								className: "ist-tool",
								"aria-label": t("games.istanbul.reviewBoard"),
								onClick: () => r(!1),
								children: /* @__PURE__ */ d(re, { size: 20 })
							})]
						}),
						/* @__PURE__ */ f("div", {
							className: "ist-ledger-body",
							children: [
								/* @__PURE__ */ f("p", {
									className: "ist-ledger-title",
									children: [
										s.winner.map(c).join(" · "),
										" · ",
										t(s.winner.length > 1 ? "games.istanbul.jointWinner" : "games.istanbul.winner")
									]
								}),
								/* @__PURE__ */ f("table", {
									className: "ist-score-table",
									children: [/* @__PURE__ */ d("thead", { children: /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: t("games.istanbul.ranking") }), s.ranking.map((e, t) => /* @__PURE__ */ f("th", { children: [
										t + 1,
										" · ",
										c(e)
									] }, e))] }) }), /* @__PURE__ */ d("tbody", { children: l.map((e) => /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ f("th", { children: [
										e.icon !== null && /* @__PURE__ */ d(q, { resource: e.icon }),
										" ",
										t(e.key)
									] }), s.ranking.map((t) => /* @__PURE__ */ d("td", {
										className: `${s.winner.includes(t) ? "ist-winner " : ""}${e.key === "games.istanbul.rubies" ? "ist-score-rubies" : ""}`,
										children: e.value(t)
									}, t))] }, e.key)) })]
								}),
								e.hintCount !== void 0 && /* @__PURE__ */ d("p", { children: t("games.istanbul.hintCount", { n: e.hintCount }) }),
								s.ranking.filter((e) => (s.autopilot?.[e] ?? 0) > 0).map((e) => /* @__PURE__ */ f("p", { children: [
									c(e),
									" · ",
									t("games.istanbul.autopilot", { n: Math.round((s.autopilot?.[e] ?? 0) * 100) })
								] }, e))
							]
						}),
						/* @__PURE__ */ f("footer", {
							className: "ist-ledger-foot",
							children: [
								/* @__PURE__ */ d("button", {
									className: "ist-control ist-quiet",
									onClick: () => r(!1),
									children: t("games.istanbul.reviewBoard")
								}),
								e.onPlayAgain && /* @__PURE__ */ d(h, {
									label: t("session.result.playAgain"),
									confirmLabel: t("games.istanbul.playAgainConfirm"),
									onConfirm: e.onPlayAgain
								}),
								" ",
								e.onBackToLobby && /* @__PURE__ */ d(h, {
									label: t("session.result.backToLobby"),
									confirmLabel: t("games.istanbul.exitConfirm"),
									onConfirm: e.onBackToLobby
								}),
								" ",
								!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ d("span", { children: t("session.result.waitHost") })
							]
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/istanbul/options.tsx
function Rt({ value: e, onChange: t }) {
	let n = o(), r = C.safeParse(e), i = r.success ? r.data : C.parse(void 0), a = (e) => {
		let n = {
			...i,
			[e]: !i[e]
		};
		n.mocha && n.letters ? n.layout = "random" : (n.mocha || n.letters) && (n.layout = n.layout === "random" ? "random" : "short"), t(n);
	}, s = i.mocha && i.letters ? "random" : i.mocha || i.letters ? i.layout === "random" ? "random" : "short" : i.layout;
	return /* @__PURE__ */ f("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ f("div", { children: [
				/* @__PURE__ */ d("p", {
					className: "section-label",
					children: n("games.istanbul.expansions")
				}),
				/* @__PURE__ */ d(_, {
					checked: i.mocha,
					label: n("games.istanbul.mocha"),
					accent: S.accent,
					onChange: () => a("mocha")
				}),
				/* @__PURE__ */ d(_, {
					checked: i.letters,
					label: n("games.istanbul.letterExpansion"),
					accent: S.accent,
					onChange: () => a("letters")
				})
			] }),
			/* @__PURE__ */ d(g, {
				title: n("games.istanbul.layoutTitle"),
				children: [
					{
						id: "short",
						key: "games.istanbul.short"
					},
					{
						id: "long",
						key: "games.istanbul.long"
					},
					{
						id: "ordered",
						key: "games.istanbul.ordered"
					},
					{
						id: "random",
						key: "games.istanbul.random"
					}
				].filter((e) => i.mocha && i.letters ? e.id === "random" : i.mocha || i.letters ? e.id === "short" || e.id === "random" : !0).map((e) => /* @__PURE__ */ d(ce, {
					name: "istanbul-layout",
					value: e.id,
					label: n(e.id === "short" && (i.mocha || i.letters) ? "games.istanbul.recommended" : e.key),
					checked: s === e.id,
					onChange: () => t({
						...i,
						layout: e.id
					}),
					accent: S.accent
				}, e.id))
			}),
			i.letters && !i.mocha && /* @__PURE__ */ d(g, {
				title: n("games.istanbul.letterDeckTitle"),
				children: [{
					id: "mixed",
					key: "games.istanbul.mixedDeck"
				}, {
					id: "new",
					key: "games.istanbul.newDeck"
				}].map((e) => /* @__PURE__ */ d(ce, {
					name: "istanbul-deck",
					value: e.id,
					label: n(e.key),
					checked: i.letterDeck === e.id,
					onChange: () => t({
						...i,
						letterDeck: e.id
					}),
					accent: S.accent
				}, e.id))
			}),
			/* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("p", {
				className: "section-label",
				children: n("games.istanbul.variants")
			}), [
				{
					id: "neutralAssistants",
					key: "games.istanbul.neutralAssistants"
				},
				{
					id: "caravanLeader",
					key: "games.istanbul.caravanLeader"
				},
				{
					id: "depot",
					key: "games.istanbul.depot"
				},
				{
					id: "kebab",
					key: "games.istanbul.kebab"
				}
			].map((e) => /* @__PURE__ */ d(_, {
				checked: i[e.id],
				label: n(e.key),
				onChange: () => a(e.id),
				accent: S.accent
			}, e.id))] })
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/istanbul/entry.tsx
var zt = {
	definition: lt,
	View: vt,
	bot: Nt,
	fx: Ft,
	OverView: Lt,
	Options: Rt,
	locales: {
		zh: {
			name: "伊斯坦堡",
			desc: "带领商人与助手穿行市集，率先收集红宝石；支持两款官方扩展。",
			fabric: "布料",
			spice: "香料",
			fruit: "水果",
			jewel: "珠宝",
			coffee: "咖啡",
			money: "里拉",
			rubies: "红宝石",
			goods: "货物",
			bonus: "奖励牌",
			guild: "行会牌",
			letters: "信件",
			assistants: "助手",
			capacity: "容量",
			merchant: "商人",
			companion: "同伴",
			family: "家族成员",
			neutral: "中立助手",
			governor: "官员",
			smuggler: "走私者",
			coffeeTrader: "咖啡商",
			courier: "信使",
			waiting: "等待{{name}}",
			round: "第{{n}}轮",
			target: "{{n}}颗红宝石触发终局",
			finalRound: "最后一轮",
			resolving: "正在结算",
			yourTurn: "轮到你行动",
			details: "地点详情",
			close: "关闭",
			confirm: "确认",
			cancel: "取消",
			zoomIn: "放大版图",
			zoomOut: "缩小版图",
			resetView: "重置视角",
			choose: "选择",
			hand: "本人桌面",
			cost: "费用{{n}}",
			need: "需要{{n}}件货物",
			nextRuby: "下一颗红宝石",
			delivered: "已送达",
			destination: "送往{{n}}号地点",
			seals: "{{n}}枚封印",
			bonusCard: "奖励牌{{n}}",
			guildCard: "行会牌{{n}}",
			kioskTile: "报亭板块",
			emptyHand: "暂无手牌",
			ledger: "市集账簿",
			winner: "胜出",
			jointWinner: "并列胜出",
			reviewBoard: "回看市集",
			showResult: "查看结算",
			ranking: "排名",
			hintCount: "求助{{n}}次",
			autopilot: "托管{{n}}%",
			exitConfirm: "确认返回大厅？",
			playAgainConfirm: "确认开始新的一局？",
			on: "启用",
			off: "关闭",
			expansions: "官方扩展",
			mocha: "咖啡与贿赂 · Mocha & Baksheesh",
			letterExpansion: "信件与封印 · Letters & Seals",
			variants: "官方变体与推广",
			layoutTitle: "市集布局",
			short: "短路径",
			recommended: "推荐布局",
			anyGood: "任意货物",
			saleReturn: "获得{{n}}里拉",
			long: "长路径",
			ordered: "按编号排列",
			random: "随机布局",
			neutralAssistants: "中立助手",
			caravanLeader: "商队领袖",
			depot: "Pegasus Depot：替换邮局",
			kebab: "Kebab Shop：替换喷泉",
			letterDeckTitle: "信件扩展奖励牌堆",
			mixedDeck: "混合基础版",
			newDeck: "仅使用扩展牌",
			barrierOwner: "屏障控制者：{{name}}",
			movementTile: "直线移动",
			encounterTile: "免费人物交易",
			errAction: "当前不能执行此操作。",
			errTurn: "请等待轮到你行动。",
			readonly: "最终市集",
			rules: "目标：\n带领商人、助手与家族成员在市集行动，收集最多红宝石。基础版3至5人以5颗触发结束；2人或任一扩展以6颗触发结束。\n准备：\n各玩家从喷泉出发，带4名助手，手推车每类货物容量2，家族成员在警局。起始玩家获得2里拉，顺时针每人多1里拉，各抽1奖励牌。四类货物为布料、香料、水果和珠宝；咖啡独立储存、不限量，也不算货物。\n每回合：\n· 商人正交移动1或2步，终点必须不同。若目标地点有自己的助手便收起，否则留下最底下1名助手；不能或不愿使用助手则回合结束。喷泉行动不需要助手。\n· 向目的地每位其他商人或同伴支付2里拉，不能或不愿支付则结束回合。喷泉普通行动免付。2人局另有3位中立商人，费用交供应，付费后以两骰总和决定新位置。\n· 可执行地点行动，也可放弃；随后按自选顺序处理遭遇。必须将当地其他玩家的家族成员送回警局，每人可领取3里拉或1奖励牌，警局内不领取逮捕奖励。官员可给予1张奖励牌，支付2里拉或弃1奖励牌；走私者可给予1件任意货物，支付2里拉或1货物。使用后分别掷2骰移动人物。\n· 回合中可使用任意数量奖励牌，牌面写明具体时机。手牌不设上限，牌堆耗尽重洗弃牌；新获得物资超容量的部分不能保留。\n地点与能力：\n点击地点可查阅完整行动和当前费用。车匠每次7里拉扩容，第3次送1红宝石。仓库补满一种货物；市场按当前需求出售；邮局领取未覆盖物资并更新标记；驿站抽2弃1，可取弃牌堆顶。警局可派家族成员至其他地点行动，无须助手、费用或遭遇。苏丹宫、宝石商、咖啡馆每取1宝石提高后续费用，最高费用处持续补充宝石。\n清真寺板块要求持有指定数量货物，只支付其中1件。红色允许在黑市或茶馆将1骰改4或重掷两骰一次；蓝色立即增加第5助手；绿色在仓库可支付2里拉额外获得1任意货物；黄色每回合一次支付2里拉召回自己1助手。每座清真寺的两种板块集齐获得1红宝石。\n咖啡与贿赂扩展：\n增加4地点、咖啡、行会牌和咖啡商。行会牌替代整个正常回合，全部效果须能执行，无通常遭遇，不能搭配要求特定地点的奖励牌或清真寺能力。咖啡商给予1咖啡，支付2里拉或1货物。酒馆屏障仅控制者可穿越；永久板块允许商人任意直线移动或人物交易免费。贿赂所需货物在3水果和布料、香料、珠宝各1之间翻换。\n信件与封印扩展：\n信件正面为目标地点及1枚封印。自己的商人、家族成员或同伴在目标地点时立即翻面为2封印，先后取得或到达均可。使用喷泉可招募同伴，之后可在回合开始免费部署到商人处；每回合选择商人或同伴移动，同伴通常只走1步且不使用助手，仍支付其他商人和同伴费用。回合结束可交付3封印额外行动一回合，每轮至多一次，超付不退。信使给予1信件，支付2里拉或交付1信件。\n两个扩展组合为五行五列的大市集，喷泉在中央并加入地下通道。所有扩展与推广默认关闭；中立助手、商队领袖、Pegasus Depot和Kebab Shop可独立启用。中立助手可由任何商人收起，喷泉只召回自己颜色助手；商队领袖再次使用驿站时无须弃牌。Depot替换邮局，掷骰后移动标记覆盖点数，领取其余3数物资；Kebab替换喷泉，可改为支付2里拉将家族成员移往其他地点行动，此时仍须助手并支付其他商人费用。\n结束与胜负：\n触发结束后完成当前轮，每位玩家可使用剩余提供货物或里拉的奖励牌。依次比较红宝石、里拉、手推车货物总数、奖励牌数量，仍相同则并列获胜。咖啡和信件不计入货物平局比较。",
			labels: {
				extend: "支付7里拉扩充手推车",
				fill: "装满货物",
				post: "领取邮局物资",
				caravan: "抽取奖励牌",
				fountain: "使用喷泉",
				kebab: "支付2里拉派出家族成员",
				blackBefore: "先获得货物，再掷骰",
				blackAfter: "先掷骰，再获得货物",
				announce: "宣布{{n}}",
				sell: "选择出售的货物",
				flexMarket: "使用奖励牌灵活出售",
				sendFamily: "派出家族成员",
				buyRuby: "购买红宝石",
				takeMosque: "获得清真寺板块",
				roast: "烘焙咖啡",
				guildHall: "领取咖啡与行会牌",
				barrier: "放置屏障并行动",
				takeTavern: "购买酒馆板块",
				bribe: "支付贿赂获得红宝石",
				takeLetters: "获得{{n}}封信件",
				kiosk: "使用报亭",
				auction: "拍卖奖励牌",
				society: "交付6枚封印",
				catacombs: "获得物资并转移",
				skipAction: "放弃地点行动",
				moveMerchant: "移动商人",
				moveCompanion: "移动同伴",
				deployCompanion: "部署同伴",
				playGuild: "使用行会牌",
				moveToPlayer: "移至商人所在地点",
				moveHere: "移动至此处",
				continue: "继续",
				pickNeutral: "收起中立助手",
				pickAssistant: "收起助手",
				leaveAssistant: "留下助手",
				endTurn: "结束回合",
				payMerchant: "支付商人费用",
				buyExtra: "支付2里拉获得额外货物",
				skip: "跳过",
				payResource: "支付物资",
				takeResource: "获得物资",
				finish: "完成",
				recallAssistant: "召回助手",
				takeCompanion: "招募同伴",
				recallCompanion: "召回同伴",
				selectGood: "加入出售",
				unselectGood: "移出出售",
				sellSelected: "出售{{n}}件货物",
				drawDeck: "从牌堆抽牌",
				drawDiscard: "取弃牌堆顶牌",
				discardCard: "弃置卡牌",
				roastMoney: "支付2里拉换2咖啡",
				roastGood: "支付1货物换2咖啡",
				roastCard: "弃置1张牌换2咖啡",
				barrierFirst: "选择屏障一侧",
				barrierSecond: "选择相邻另一侧",
				takeAction: "执行地点行动",
				tavernAgain: "再执行一次酒馆行动",
				takeRuby: "取得此处红宝石",
				payLetter: "交付信件",
				captureFamily: "逮捕家族成员",
				useNpc: "与人物交易",
				endEncounters: "结束遭遇",
				freeEncounter: "免费领取",
				payMoney: "支付里拉",
				rewardMoney: "领取3里拉",
				rewardCard: "领取1张奖励牌",
				acceptDice: "采用骰子结果",
				changeFour: "将第{{n}}颗骰子改为4",
				reroll: "重掷两颗骰子",
				changeSix: "用奖励牌将第{{n}}颗骰子改为6",
				coverDice: "按此组合放置标记",
				takeTwo: "获得2件货物",
				exchangeOut: "交出物资",
				finishExchange: "换取{{n}}件物资",
				bid: "出价{{n}}里拉",
				pass: "放弃竞价",
				chooseKiosk: "选择报亭板块",
				useKiosk: "执行报亭效果",
				takeMoney: "领取{{n}}里拉",
				goodLetter: "支付1物资，获得1信件",
				letterGood: "交付1信件，获得1物资",
				moneyGood: "支付2里拉，获得1物资",
				goodMoney: "支付1物资，获得3里拉",
				moneyCard: "支付2里拉，获得1奖励牌",
				cardMoney: "弃置1奖励牌，获得3里拉",
				moneyLetter: "支付2里拉，获得1信件",
				letterMoney: "交付1信件，获得3里拉",
				cardLetter: "弃置1奖励牌，获得1信件",
				letterCard: "交付1信件，获得1奖励牌",
				doubleTurn: "交付3枚封印，额外行动一回合",
				finishFinal: "完成终局整理",
				playBonus: "使用奖励牌",
				yellowMosque: "支付2里拉召回助手"
			},
			places: {
				p1: "车匠",
				p2: "布料仓库",
				p3: "香料仓库",
				p4: "水果仓库",
				p5: "邮局",
				p6: "驿站",
				p7: "喷泉",
				p8: "黑市",
				p9: "茶馆",
				p10: "大市场",
				p11: "小市场",
				p12: "警局",
				p13: "苏丹宫",
				p14: "小清真寺",
				p15: "大清真寺",
				p16: "宝石商",
				p17: "烘焙厂",
				p18: "行会厅",
				p19: "酒馆",
				p20: "咖啡馆",
				p21: "使馆",
				p22: "报亭",
				p23: "拍卖场",
				p24: "秘密社团",
				p25: "地下通道"
			},
			placeText: {
				p1: "支付7里拉扩充手推车，容量提高1；第三次扩充获得1红宝石。",
				p2: "将布料装至容量上限。",
				p3: "将香料装至容量上限。",
				p4: "将水果装至容量上限。",
				p5: "领取4个未覆盖格的物资，再移动最左侧上排标记；全部在下排时移回上排。",
				p6: "依次抽2奖励牌，可选择牌堆或弃牌堆顶，然后弃1手牌；咖啡扩展额外获得1咖啡。",
				p7: "召回任意数量自己的助手；无须助手或商人费用。信件扩展可招募或召回同伴。",
				p8: "获得1布料、香料或水果，并掷2骰；总和7–8获得1珠宝，9–10获得2，11–12获得3。",
				p9: "宣布3至12，再掷2骰；达到宣布值便获得等值里拉，否则获得2里拉。",
				p10: "按需求出售1至5货物，收入依次为3、7、12、18、25里拉；需求板块移至堆底。",
				p11: "按需求出售1至5货物，收入依次为2、5、9、14、20里拉；需求板块移至堆底。",
				p12: "将警局内的自己家族成员派往另一地点并行动，不发生遭遇。",
				p13: "交付当前轨道要求的货物，取得下一颗红宝石；后续需求增加。任意货物不含咖啡。",
				p14: "满足所示货物数量，支付其中1件，获得尚未拥有的能力；集齐此处两种能力获得红宝石。",
				p15: "满足所示货物数量，支付其中1件，获得尚未拥有的能力；集齐此处两种能力获得红宝石。",
				p16: "支付当前价格的里拉取得红宝石，价格逐次提高，最高23。",
				p17: "每种方式各至多一次：支付2里拉、支付1货物、弃1奖励或行会牌；每种获得2咖啡。",
				p18: "获得1咖啡，抽2行会牌，弃1行会牌。",
				p19: "可支付2咖啡放屏障并执行相邻地点行动；购买永久能力；或支付4咖啡及贿赂板块货物获得红宝石。",
				p20: "交付当前要求的咖啡取得红宝石，费用从6提高至10。",
				p21: "获得2信件。",
				p22: "获得1信件，翻开人数加1块报亭板块；顺时针各选1块，主动玩家最后再选剩余1块。",
				p23: "获得1任意货物，然后拍卖2奖励牌。主动玩家先出价至少1里拉，其他人各一次加价或放弃，主动玩家可最后加价。",
				p24: "交付6枚封印，取得苏丹宫、宝石商或已启用咖啡馆的下一颗红宝石。前三次额外获得3、2、1里拉。",
				p25: "获得1货物或咖啡，将行动棋件移至任意地点，不再行动或遭遇。"
			},
			bonusText: {
				c0: "同伴本次移动2步。",
				c1: "获得1水果和3里拉。",
				c2: "获得1香料和3里拉。",
				c3: "获得1布料和3里拉。",
				c4: "在行动前或后获得1任意货物。",
				c5: "获得5里拉。",
				c6: "商人本次移动3或4步。",
				c7: "商人留在原地，仍须使用助手。",
				c8: "移动阶段召回1名自己的助手。",
				c9: "小市场本次可用其他种类的货物支付。",
				c10: "将自己的家族成员送回警局，领取逮捕奖励。",
				c11: "完成邮局行动后，再执行一次。",
				c12: "完成宝石商行动后，再执行一次。",
				c13: "完成苏丹宫行动后，再执行一次。",
				c14: "获得2咖啡。",
				c15: "支付2咖啡，抽取1行会牌。",
				c16: "支付1咖啡，获得8里拉。",
				c17: "掷2骰：每颗1获得2里拉；2水果、3香料、4布料、5珠宝、6咖啡，各获得1。",
				c18: "将商人移动至任意角落地点。",
				c19: "掷骰后，将1颗骰子改为6；不能用于移动中立人物。",
				c20: "在车匠处再行动一次。",
				c21: "在咖啡馆再行动一次。",
				c22: "交出至多3件货物或咖啡，换取同数量的其他货物或咖啡。",
				c23: "获得1信件。",
				c24: "在任意地点使用1个人物并支付费用，随后掷骰移动该人物。",
				c25: "掷2骰：每颗1–3获得1里拉，4–6获得1信件。",
				c26: "掷2骰：每颗1–3获得1里拉，4–6获得1任意货物或咖啡。",
				c27: "在清真寺再行动一次。",
				c28: "支付1货物或咖啡，获得7里拉。",
				c29: "在秘密社团再行动一次。",
				c30: "移至另一玩家商人所在地点，免付对该商人的费用。",
				c31: "支付3里拉，将商人移至任意其他地点。",
				c32: "家族成员正交移动1步并行动，替代本回合；不能从警局出发或进入警局。",
				c33: "执行弃牌堆顶奖励牌的效果。"
			},
			guildText: {
				c1: "免费扩充手推车1次。",
				c2: "装满布料，再获得至多3种不同货物各1。",
				c3: "装满香料，再获得至多3种不同货物各1。",
				c4: "装满水果，再获得至多3种不同货物各1。",
				c5: "获得4里拉和至多4种不同货物各1。",
				c6: "抽取3张奖励牌。",
				c7: "将商人和任意数量自己的助手移至喷泉，再行动一回合。",
				c8: "获得2布料、2香料或2水果；掷2骰，总和4–6获得1珠宝，7–12获得3珠宝。",
				c9: "执行茶馆行动，收入翻倍；不能使用红清真寺能力。",
				c10: "支付布料、香料、水果各1，获得15里拉。",
				c11: "支付布料、香料、珠宝各1，获得20里拉。",
				c12: "执行任意地点行动，然后将家族成员送回警局，不领取奖励。",
				c13: "支付任意6件货物，取得苏丹宫下一颗红宝石。",
				c14: "支付1对应货物，获得尚未拥有的小清真寺板块。",
				c15: "支付1对应货物，获得尚未拥有的大清真寺板块。",
				c16: "支付15里拉取得宝石商下一颗红宝石，再按自己的红宝石数量获得咖啡。",
				c17: "获得5咖啡。",
				c18: "获得1咖啡，抽取2张行会牌，无须弃牌。",
				c19: "执行1或2次酒馆行动，总费用减少1咖啡。",
				c20: "支付咖啡馆当前费用的一半咖啡，向上取整，取得下一颗红宝石。"
			},
			kioskText: {
				c0: "获得2里拉",
				c1: "物资与信件互换",
				c2: "2里拉购1物资，或1物资售3里拉",
				c3: "2里拉购1奖励牌，或弃牌获3里拉",
				c4: "2里拉购1信件，或交信获3里拉",
				c5: "奖励牌与信件互换",
				c6: "商人移至喷泉，不回收助手",
				c7: "掷1骰，获得等值里拉",
				c8: "同伴返回个人供应区",
				c9: "抽取1奖励牌",
				c10: "支付10里拉扩充手推车",
				c11: "获得1香料和1里拉",
				c12: "获得1水果和1里拉",
				c13: "获得2香料",
				c14: "获得2布料",
				c15: "获得1咖啡或2里拉",
				c16: "获得1布料和1里拉",
				c17: "获得1水果",
				c18: "获得1咖啡或3里拉",
				c19: "获得2水果",
				c20: "获得1珠宝",
				c21: "获得1香料",
				c22: "获得1布料",
				c23: "支付四类货物各1，扩充手推车"
			},
			phases: {
				start: "选择商人或同伴的目的地，也可使用行会牌。",
				specialMove: "选择目的地。",
				assistant: "收起或留下助手，继续行动。",
				merchantFees: "支付在场商人的费用，或结束回合。",
				action: "选择地点行动。",
				warehouseExtra: "是否购买额外货物？",
				resource: "选择物资。",
				differentGoods: "选择不同种类的货物。",
				fountain: "选择要召回的助手，完成后继续。",
				recallOne: "选择要召回的助手。",
				companionRecall: "招募或召回同伴。",
				familyDestination: "选择家族成员的目的地。",
				familyStep: "选择家族成员的相邻目的地。",
				teleport: "选择转移目的地。",
				market: "选择出售的货物，再确认出售。",
				caravanDraw: "选择抽牌来源。",
				discardCard: "选择要弃置的卡牌。",
				roast: "每种兑换方式最多使用一次。",
				barrierFirst: "选择屏障一侧地点。",
				barrierSecond: "选择相邻的另一侧地点。",
				barrierAction: "选择屏障两侧之一并行动。",
				tavernSecond: "是否再次使用酒馆？",
				rubySource: "选择红宝石来源。",
				seals: "选择信件以支付剩余{{n}}枚封印。",
				encounters: "处理家族成员或人物遭遇。",
				npcPick: "选择要使用的人物。",
				npcPay: "支付人物的交易费用。",
				captureReward: "选择逮捕奖励。",
				diceChoice: "采用或调整骰子。",
				depotCover: "覆盖掷出的数字，再领取未覆盖物资。",
				depotSix: "选择数字6的物资。",
				guildBlack: "选择行会牌提供的货物。",
				guildDestination: "选择要执行行动的地点。",
				exchange: "交出至多3物资，再选择换取的物资。",
				auctionStart: "至少出价1里拉。",
				auctionBid: "提高出价或放弃。",
				kioskChoose: "选择一个报亭板块。",
				kioskEffect: "执行或放弃报亭效果。",
				kioskExchange: "选择兑换方向。",
				end: "可使用奖励牌或封印，然后结束回合。",
				finalCards: "可使用提供货物或里拉的奖励牌，再确认。",
				discardLetter: "选择要交付的信件。",
				done: "对局结束",
				auto: "正在结算，请稍候。"
			},
			events: {
				move: "移动至{{place}}",
				action: "在{{place}}行动",
				ruby: "获得第{{n}}颗红宝石",
				auction: "以{{n}}里拉赢得拍卖"
			}
		},
		en: {
			name: "Istanbul",
			desc: "Navigate the bazaar with your Merchant and Assistants in a race for Rubies, with both official expansions.",
			fabric: "Fabric",
			spice: "Spice",
			fruit: "Fruit",
			jewel: "Jewellery",
			coffee: "Coffee",
			money: "Lira",
			rubies: "Rubies",
			goods: "Goods",
			bonus: "Bonus cards",
			guild: "Guild cards",
			letters: "Letters",
			assistants: "Assistants",
			capacity: "Capacity",
			merchant: "Merchant",
			companion: "Companion",
			family: "Family member",
			neutral: "Neutral Assistant",
			governor: "Governor",
			smuggler: "Smuggler",
			coffeeTrader: "Coffee trader",
			courier: "Courier",
			waiting: "Waiting for {{name}}",
			round: "Round {{n}}",
			target: "{{n}} Rubies trigger the final round",
			finalRound: "Final round",
			resolving: "Resolving",
			yourTurn: "Your turn",
			details: "Place details",
			close: "Close",
			confirm: "Confirm",
			cancel: "Cancel",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			resetView: "Reset view",
			choose: "Choose",
			hand: "Your table",
			cost: "Cost {{n}}",
			need: "Requires {{n}} goods",
			nextRuby: "Next Ruby",
			delivered: "Delivered",
			destination: "Deliver to Place {{n}}",
			seals: "{{n}} Seals",
			bonusCard: "Bonus card {{n}}",
			guildCard: "Guild card {{n}}",
			kioskTile: "Kiosk tile",
			emptyHand: "No cards",
			ledger: "Bazaar ledger",
			winner: "Winner",
			jointWinner: "Joint winners",
			reviewBoard: "Review bazaar",
			showResult: "Show results",
			ranking: "Rank",
			hintCount: "Hints used: {{n}}",
			autopilot: "Autopilot {{n}}%",
			exitConfirm: "Return to the lobby?",
			playAgainConfirm: "Start a new game?",
			on: "On",
			off: "Off",
			expansions: "Official expansions",
			mocha: "Mocha & Baksheesh",
			letterExpansion: "Letters & Seals",
			variants: "Official variants and promos",
			layoutTitle: "Bazaar layout",
			short: "Short paths",
			recommended: "Recommended layout",
			anyGood: "Any good",
			saleReturn: "Gain {{n}} Lira",
			long: "Long paths",
			ordered: "Number order",
			random: "Random layout",
			neutralAssistants: "Neutral Assistants",
			caravanLeader: "Caravan Leader",
			depot: "Pegasus Depot: replace Post Office",
			kebab: "Kebab Shop: replace Fountain",
			letterDeckTitle: "Letters expansion Bonus deck",
			mixedDeck: "Mix with Base Game",
			newDeck: "Expansion cards only",
			barrierOwner: "Barrier controlled by {{name}}",
			movementTile: "Straight-line movement",
			encounterTile: "Free encounters",
			errAction: "This action is not available now.",
			errTurn: "Please wait for your turn.",
			readonly: "Final bazaar",
			rules: "Goal:\nCollect the most Rubies by travelling through the bazaar with your Merchant, Assistants and Family member. The final round is triggered at 5 Rubies with 3–5 players in the Base Game, or 6 with 2 players or either expansion.\nSetup:\nStart at the Fountain with 4 Assistants, capacity 2 for each good, and your Family member at the Police Station. The start player receives 2 Lira, each clockwise player one more, and everyone draws a Bonus card. Goods are fabric, spice, fruit and jewellery. Coffee is unlimited, separately stored, and is not a good.\nYour turn:\n· Move your Merchant 1 or 2 orthogonal steps to a different Place. Pick up an Assistant of yours there, or leave the bottom Assistant from your stack. If you cannot or decline, end your turn. The normal Fountain action needs no Assistant.\n· Pay 2 Lira for every opposing Merchant or Companion at the destination, or end your turn. The normal Fountain action is free. In a 2-player game, three neutral Merchants are also present: pay the supply, then roll two dice to relocate each.\n· Take or skip the Place action, then resolve encounters in any order. Catch all opposing Family members here, sending them to the Police Station and taking 3 Lira or a Bonus card each. No capture rewards at the Police Station. The Governor offers a Bonus card for 2 Lira or a discarded Bonus card. The Smuggler offers any good for 2 Lira or a good. After using each, roll two dice to relocate it.\n· Play any number of Bonus cards, observing their timing. There is no hand limit. Empty decks reshuffle their discards. Goods exceeding capacity are lost.\nPlaces and abilities:\nOpen a Place for its full action and current costs. Wainwright extensions cost 7 Lira; the third gives a Ruby. Warehouses fill one good, Markets buy demanded goods, the Post Office gives uncovered resources and updates markers, and the Caravansary draws 2 and discards 1, with access to the top discard. The Police Station sends your Family member to act elsewhere without Assistants, fees or encounters. Palace, Dealer and Coffee House costs rise after each Ruby and replenish indefinitely at their maximum costs.\nMeet a Mosque tile’s required goods but pay only 1 matching good. Red allows one re-roll of both dice or turning one die to 4 at the Black Market or Tea House. Blue immediately adds your fifth Assistant. Green allows buying an extra good for 2 Lira at a Warehouse. Yellow recalls an Assistant for 2 Lira once per turn. Collect both tiles from one Mosque for a Ruby.\nMocha & Baksheesh:\nAdds four Places, coffee, Guild cards and the Coffee trader. A Guild card replaces your normal turn; all its instructions must be possible. You have no normal encounters and cannot use cards or Mosque abilities requiring a specific Place. The Coffee trader gives coffee for 2 Lira or a good. Only the Barrier controller may cross it. Permanent Tavern tiles give straight-line Merchant movement or free encounters. The Baksheesh cost alternates between 3 fruit and 1 each of fabric, spice and jewellery.\nLetters & Seals:\nEach Letter begins with a destination and 1 Seal. Flip it to 2 Seals whenever your Merchant, Family member or Companion is there, regardless of whether the Letter or token arrived first. Recruit your Companion at the Fountain; at the start of a later turn, freely deploy it at your Merchant. Choose to move the Merchant or Companion; the Companion normally moves one step without Assistants but still pays other Merchants and Companions. At the end of your turn, spend 3 Seals for another turn, at most once per round; excess Seals are lost. The Courier gives a Letter for 2 Lira or a discarded Letter.\nBoth expansions create the 5×5 Great Bazaar with the Fountain central and the Catacombs added. Expansions and promos default off. Neutral Assistants can be picked up by anyone, but the Fountain only recalls your own colour. A Caravan Leader keeps both cards on subsequent Caravansary visits. Pegasus Depot replaces the Post Office: cover rolled numbers with markers, then take three uncovered rewards. Kebab Shop replaces the Fountain: alternatively pay 2 Lira to move your Family member elsewhere and act, using an Assistant and paying Merchant fees as usual.\nEnd and ties:\nAfter the trigger, finish the current round. Each player may use remaining Bonus cards providing goods or Lira. Compare Rubies, then Lira, then total goods in the Wheelbarrow, then Bonus card count. Remaining ties share victory. Coffee and Letters are excluded from the goods tie-breaker.",
			labels: {
				extend: "Extend for 7 Lira",
				fill: "Fill warehouse goods",
				post: "Collect postal resources",
				caravan: "Draw Bonus cards",
				fountain: "Use the Fountain",
				kebab: "Send family for 2 Lira",
				blackBefore: "Take a good, then roll",
				blackAfter: "Roll, then take a good",
				announce: "Announce {{n}}",
				sell: "Select goods to sell",
				flexMarket: "Use flexible sale card",
				sendFamily: "Send Family member",
				buyRuby: "Buy a Ruby",
				takeMosque: "Take Mosque tile",
				roast: "Roast coffee",
				guildHall: "Take coffee and Guild cards",
				barrier: "Place Barrier and take action",
				takeTavern: "Buy Tavern tile",
				bribe: "Pay baksheesh for a Ruby",
				takeLetters: "Take {{n}} Letters",
				kiosk: "Use the Kiosk",
				auction: "Auction Bonus cards",
				society: "Spend 6 Seals",
				catacombs: "Take a resource and relocate",
				skipAction: "Skip Place action",
				moveMerchant: "Move Merchant",
				moveCompanion: "Move Companion",
				deployCompanion: "Deploy Companion",
				playGuild: "Play Guild card",
				moveToPlayer: "Move to this Merchant",
				moveHere: "Move here",
				continue: "Continue",
				pickNeutral: "Pick up neutral Assistant",
				pickAssistant: "Pick up Assistant",
				leaveAssistant: "Leave an Assistant",
				endTurn: "End turn",
				payMerchant: "Pay encounter fee",
				buyExtra: "Pay 2 Lira for a good",
				skip: "Skip",
				payResource: "Pay resource",
				takeResource: "Take resource",
				finish: "Finish",
				recallAssistant: "Recall Assistant",
				takeCompanion: "Recruit Companion",
				recallCompanion: "Recall Companion",
				selectGood: "Add to sale",
				unselectGood: "Remove from sale",
				sellSelected: "Sell {{n}} goods",
				drawDeck: "Draw from deck",
				drawDiscard: "Take top discard",
				discardCard: "Discard card",
				roastMoney: "Pay 2 Lira for 2 coffee",
				roastGood: "Pay 1 good for 2 coffee",
				roastCard: "Discard a card for 2 coffee",
				barrierFirst: "Choose first side",
				barrierSecond: "Choose adjacent side",
				takeAction: "Take Place action",
				tavernAgain: "Take another Tavern action",
				takeRuby: "Take Ruby here",
				payLetter: "Spend Letter",
				captureFamily: "Catch Family member",
				useNpc: "Use encounter",
				endEncounters: "Finish encounters",
				freeEncounter: "Take for free",
				payMoney: "Pay Lira",
				rewardMoney: "Take 3 Lira",
				rewardCard: "Take a Bonus card",
				acceptDice: "Accept dice",
				changeFour: "Turn die {{n}} to 4",
				reroll: "Re-roll both dice",
				changeSix: "Use card to turn die {{n}} to 6",
				coverDice: "Use this marker arrangement",
				takeTwo: "Take 2 goods",
				exchangeOut: "Trade resource away",
				finishExchange: "Take {{n}} resources",
				bid: "Bid {{n}} Lira",
				pass: "Pass",
				chooseKiosk: "Choose Kiosk tile",
				useKiosk: "Use Kiosk effect",
				takeMoney: "Take {{n}} Lira",
				goodLetter: "Pay a resource for a Letter",
				letterGood: "Spend a Letter for a resource",
				moneyGood: "Pay 2 Lira for a resource",
				goodMoney: "Pay a resource for 3 Lira",
				moneyCard: "Pay 2 Lira for a Bonus card",
				cardMoney: "Discard a Bonus card for 3 Lira",
				moneyLetter: "Pay 2 Lira for a Letter",
				letterMoney: "Spend a Letter for 3 Lira",
				cardLetter: "Discard a Bonus card for a Letter",
				letterCard: "Spend a Letter for a Bonus card",
				doubleTurn: "Spend 3 Seals for another turn",
				finishFinal: "Finish final cards",
				playBonus: "Play Bonus card",
				yellowMosque: "Pay 2 Lira to recall an Assistant"
			},
			places: {
				p1: "Wainwright",
				p2: "Fabric Warehouse",
				p3: "Spice Warehouse",
				p4: "Fruit Warehouse",
				p5: "Post Office",
				p6: "Caravansary",
				p7: "Fountain",
				p8: "Black Market",
				p9: "Tea House",
				p10: "Large Market",
				p11: "Small Market",
				p12: "Police Station",
				p13: "Sultan’s Palace",
				p14: "Small Mosque",
				p15: "Great Mosque",
				p16: "Gemstone Dealer",
				p17: "Roasting Plant",
				p18: "Guild Hall",
				p19: "Tavern",
				p20: "Coffee House",
				p21: "Embassy",
				p22: "Kiosk",
				p23: "Auction House",
				p24: "Secret Society",
				p25: "Catacombs"
			},
			placeText: {
				p1: "Pay 7 Lira for an extension, increasing capacity by 1. The third extension gives a Ruby.",
				p2: "Fill fabric to capacity.",
				p3: "Fill spice to capacity.",
				p4: "Fill fruit to capacity.",
				p5: "Take the four uncovered resources, then lower the leftmost upper marker, or reset all markers if all are lowered.",
				p6: "Draw 2 Bonus cards from the deck or top discard, then discard 1 card. With Mocha, also gain 1 coffee.",
				p7: "Recall any of your Assistants without using an Assistant or paying Merchants. With Letters, recruit or recall your Companion.",
				p8: "Gain a fabric, spice or fruit, and roll 2 dice: total 7–8 gives 1 jewellery, 9–10 gives 2, 11–12 gives 3.",
				p9: "Announce 3–12, then roll 2 dice. Gain the announced Lira if the total meets it; otherwise gain 2 Lira.",
				p10: "Sell 1–5 demanded goods for 3, 7, 12, 18 or 25 Lira; move the Demand tile to the bottom.",
				p11: "Sell 1–5 demanded goods for 2, 5, 9, 14 or 20 Lira; move the Demand tile to the bottom.",
				p12: "Send your Family member from the Police Station to another Place and take its action without encounters.",
				p13: "Pay the goods currently required for the next Ruby; later costs increase. Any good excludes coffee.",
				p14: "Meet the depicted quantity and pay 1 matching good for a new ability. Collect both abilities here for a Ruby.",
				p15: "Meet the depicted quantity and pay 1 matching good for a new ability. Collect both abilities here for a Ruby.",
				p16: "Pay the current Lira price for a Ruby; the price rises to a maximum of 23.",
				p17: "Once each, pay 2 Lira, pay a good, or discard a Bonus/Guild card, gaining 2 coffee per trade.",
				p18: "Gain 1 coffee, draw 2 Guild cards, then discard 1 Guild card.",
				p19: "Place a Barrier for 2 coffee and act at an adjacent Place; buy a permanent ability; or pay 4 coffee and the Baksheesh goods for a Ruby.",
				p20: "Pay the current coffee cost for a Ruby, rising from 6 to 10.",
				p21: "Gain 2 Letters.",
				p22: "Gain 1 Letter. Reveal one more Kiosk tile than the player count. Each chooses one clockwise; the active player then takes the last.",
				p23: "Gain any good, then auction 2 Bonus cards. Open at 1 or more Lira, each opponent may raise once, then you may raise last.",
				p24: "Spend 6 Seals for a next Ruby at the Palace, Dealer or enabled Coffee House. The first three uses also give 3, 2 and 1 Lira.",
				p25: "Gain a good or coffee, then move the acting token anywhere without another action or encounters."
			},
			bonusText: {
				c0: "Move your Companion exactly 2 Places.",
				c1: "Gain 1 fruit and 3 Lira.",
				c2: "Gain 1 spice and 3 Lira.",
				c3: "Gain 1 fabric and 3 Lira.",
				c4: "Before or after an action, gain any 1 good.",
				c5: "Gain 5 Lira.",
				c6: "Move your Merchant 3 or 4 Places.",
				c7: "Keep your Merchant here; use an Assistant again.",
				c8: "During Movement, recall one of your Assistants.",
				c9: "At the Small Market, use any types of goods for this sale.",
				c10: "Send your Family member to the Police Station and take the reward.",
				c11: "Repeat the Post Office action after completing it.",
				c12: "Repeat the Gemstone Dealer action after completing it.",
				c13: "Repeat the Sultan’s Palace action after completing it.",
				c14: "Gain 2 coffee.",
				c15: "Pay 2 coffee to draw 1 Guild card.",
				c16: "Pay 1 coffee to gain 8 Lira.",
				c17: "Roll 2 dice: each 1 gives 2 Lira; 2 fruit, 3 spice, 4 fabric, 5 jewellery, 6 coffee, one each.",
				c18: "Move your Merchant to any corner Place.",
				c19: "After rolling, turn one die to 6, except when moving neutral tokens.",
				c20: "Take another Wainwright action.",
				c21: "Take another Coffee House action.",
				c22: "Exchange up to 3 goods or coffee for the same number of other goods or coffee.",
				c23: "Gain 1 Letter.",
				c24: "Use one encounter token anywhere, pay its cost, then roll to move it.",
				c25: "Roll 2 dice: each 1–3 gives 1 Lira; each 4–6 gives 1 Letter.",
				c26: "Roll 2 dice: each 1–3 gives 1 Lira; each 4–6 gives any 1 good or coffee.",
				c27: "Take another action at the Mosque.",
				c28: "Pay 1 good or coffee to gain 7 Lira.",
				c29: "Take another Secret Society action.",
				c30: "Move to another player’s Merchant, waiving that Merchant’s fee.",
				c31: "Pay 3 Lira to move your Merchant to any other Place.",
				c32: "Instead of your turn, move your Family member one adjacent Place and act; neither endpoint may be the Police Station.",
				c33: "Copy the top Bonus discard’s effect."
			},
			guildText: {
				c1: "Take a free Wheelbarrow extension.",
				c2: "Fill fabric, then take up to 3 different goods.",
				c3: "Fill spice, then take up to 3 different goods.",
				c4: "Fill fruit, then take up to 3 different goods.",
				c5: "Gain 4 Lira and up to 4 different goods.",
				c6: "Draw 3 Bonus cards.",
				c7: "Move your Merchant and any of your Assistants to the Fountain, then take another turn.",
				c8: "Take 2 fabric, spice or fruit. Roll 2 dice: total 4–6 gives 1 jewellery; 7–12 gives 3.",
				c9: "Take the Tea House action for double income, without the red Mosque ability.",
				c10: "Pay 1 fabric, spice and fruit to gain 15 Lira.",
				c11: "Pay 1 fabric, spice and jewellery to gain 20 Lira.",
				c12: "Take any Place action, then send your Family member to the Police Station without a reward.",
				c13: "Pay any 6 goods for the next Ruby at the Sultan’s Palace.",
				c14: "Pay 1 matching good for a Small Mosque tile you do not own.",
				c15: "Pay 1 matching good for a Great Mosque tile you do not own.",
				c16: "Pay 15 Lira for the next Gemstone Dealer Ruby, then gain coffee equal to your Ruby total.",
				c17: "Gain 5 coffee.",
				c18: "Gain 1 coffee and draw 2 Guild cards without discarding.",
				c19: "Take 1 or 2 Tavern actions, reducing the total cost by 1 coffee.",
				c20: "Pay half the Coffee House cost, rounded up, for its next Ruby."
			},
			kioskText: {
				c0: "Gain 2 Lira",
				c1: "Trade resource / Letter",
				c2: "Buy a resource for 2 Lira / sell for 3",
				c3: "Buy a Bonus card for 2 Lira / discard for 3",
				c4: "Buy a Letter for 2 Lira / spend for 3",
				c5: "Trade Bonus card / Letter",
				c6: "Move Merchant to Fountain without recalling Assistants",
				c7: "Roll 1 die and gain that many Lira",
				c8: "Return Companion to personal supply",
				c9: "Draw 1 Bonus card",
				c10: "Pay 10 Lira for an extension",
				c11: "Gain 1 spice and 1 Lira",
				c12: "Gain 1 fruit and 1 Lira",
				c13: "Gain 2 spice",
				c14: "Gain 2 fabric",
				c15: "Gain 1 coffee or 2 Lira",
				c16: "Gain 1 fabric and 1 Lira",
				c17: "Gain 1 fruit",
				c18: "Gain 1 coffee or 3 Lira",
				c19: "Gain 2 fruit",
				c20: "Gain 1 jewellery",
				c21: "Gain 1 spice",
				c22: "Gain 1 fabric",
				c23: "Pay 1 of each good for an extension"
			},
			phases: {
				start: "Choose a Merchant or Companion destination, or play a Guild card.",
				specialMove: "Choose a destination.",
				assistant: "Pick up or leave an Assistant to act.",
				merchantFees: "Pay the Merchants present, or end your turn.",
				action: "Choose the Place action.",
				warehouseExtra: "Buy an additional good?",
				resource: "Choose a resource.",
				differentGoods: "Choose different types of goods.",
				fountain: "Choose Assistants to recall, then finish.",
				recallOne: "Choose an Assistant to recall.",
				companionRecall: "Recruit or recall your Companion.",
				familyDestination: "Choose a destination for your Family member.",
				familyStep: "Choose an adjacent Family destination.",
				teleport: "Choose where to relocate.",
				market: "Select goods, then confirm the sale.",
				caravanDraw: "Choose where to draw from.",
				discardCard: "Choose a card to discard.",
				roast: "Use each trade at most once.",
				barrierFirst: "Choose one side of the Barrier.",
				barrierSecond: "Choose the adjacent second side.",
				barrierAction: "Act at one of the two adjacent Places.",
				tavernSecond: "Use the Tavern again?",
				rubySource: "Choose the Ruby source.",
				seals: "Choose Letters to pay {{n}} remaining Seals.",
				encounters: "Resolve Family members and encounters.",
				npcPick: "Choose an encounter token.",
				npcPay: "Pay for the encounter.",
				captureReward: "Choose a capture reward.",
				diceChoice: "Accept or adjust the dice.",
				depotCover: "Cover the rolled numbers, then collect uncovered resources.",
				depotSix: "Choose the resource for number 6.",
				guildBlack: "Choose the goods from your Guild card.",
				guildDestination: "Choose a Place for its action.",
				exchange: "Give up to 3 resources, then choose replacements.",
				auctionStart: "Open bidding with at least 1 Lira.",
				auctionBid: "Raise the bid or pass.",
				kioskChoose: "Choose a Kiosk tile.",
				kioskEffect: "Use or decline the Kiosk effect.",
				kioskExchange: "Choose the trade direction.",
				end: "Use Bonus cards or Seals, or end your turn.",
				finalCards: "Use remaining Bonus cards for goods or Lira, then finish.",
				discardLetter: "Choose a Letter to spend.",
				done: "Game over",
				auto: "Resolving the action."
			},
			events: {
				move: "Moved to {{place}}",
				action: "Acted at {{place}}",
				ruby: "Gained Ruby {{n}}",
				auction: "Won the auction for {{n}} Lira"
			}
		}
	}
};
//#endregion
export { zt as default };
