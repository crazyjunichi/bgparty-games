import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { BottomSheet as s } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { IconBack as ee, IconBot as v, IconExpand as te, IconLog as y } from "@bgparty/sdk/icons";
import { seatName as b } from "@bgparty/sdk/ui/player-strip";
import { Confetti as ne } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as x, OptionSection as S } from "@bgparty/sdk/ui/game-options";
//#region src/games/warchest/board.ts
var C = (e, t) => `${e},${t}`, w = {
	2: [
		-2,
		-1,
		1
	],
	3: [
		-2,
		-1,
		0,
		1,
		2
	],
	4: [
		-3,
		-2,
		-1,
		0,
		1,
		2
	],
	5: [
		-3,
		-2,
		-1,
		0,
		1,
		2,
		3
	],
	6: [
		-3,
		-2,
		-1,
		0,
		1,
		2
	],
	7: [
		-2,
		-1,
		0,
		1,
		2
	],
	8: [
		-2,
		0,
		1
	]
}, T = {
	A: {
		c: 4,
		r: -3,
		startOf: 0
	},
	B: {
		c: 7,
		r: -2,
		startOf: 0
	},
	M: {
		c: 3,
		r: 2,
		startOf: 1
	},
	N: {
		c: 6,
		r: 2,
		startOf: 1
	},
	D: {
		c: 3,
		r: -1
	},
	E: {
		c: 6,
		r: -1
	},
	J: {
		c: 4,
		r: 0
	},
	K: {
		c: 7,
		r: 1
	}
}, E = 10, D = E * .866, O = [];
for (let [e, t] of Object.entries(w)) {
	let n = Number(e);
	for (let e of t) {
		let t = ((n % 2 == 0 ? 8 : 7) + 2 * e) * D;
		O.push({
			key: C(n, e),
			c: n,
			r: e,
			x: (n - 2) * 1.5 * E,
			y: t
		});
	}
}
for (let [e, t] of Object.entries(T)) {
	let n = O.find((e) => e.c === t.c && e.r === t.r);
	if (!n) throw Error(`location ${e} 不在版图格集内`);
	n.loc = e, n.startOf = t.startOf;
}
var k = new Set(O.map((e) => e.key)), A = new Set(O.filter((e) => e.loc).map((e) => e.key)), re = (e) => O.find((t) => t.key === e), ie = (e, t) => {
	let n = e % 2 == 0 ? [0, 1] : [-1, 0];
	return [
		C(e, t - 1),
		C(e, t + 1),
		C(e - 1, t + n[0]),
		C(e - 1, t + n[1]),
		C(e + 1, t + n[0]),
		C(e + 1, t + n[1])
	].filter((e) => k.has(e));
}, j = new Map(O.map((e) => [e.key, ie(e.c, e.r)])), M = (e) => {
	let [t, n] = e.split(",").map(Number);
	return [t, n - Math.ceil(t / 2)];
}, ae = (e, t) => C(e, t + Math.ceil(e / 2)), N = (e, t) => {
	let [n, r] = M(e), [i, a] = M(t);
	return (Math.abs(n - i) + Math.abs(r - a) + Math.abs(n + r - i - a)) / 2;
}, oe = [
	[1, 0],
	[1, -1],
	[0, -1],
	[-1, 0],
	[-1, 1],
	[0, 1]
], P = (e, t) => {
	let [n, r] = M(e), [i, a] = M(t), o = i - n, s = a - r;
	for (let [e, t] of oe) {
		if (e === 0 && t === 0) continue;
		let n = e === 0 ? s / t : o / e;
		if (n > 0 && Number.isInteger(n) && o === e * n && s === t * n) return n;
	}
	return null;
}, F = (e, t) => {
	let n = P(e, t);
	if (n === null || n < 2) return n === 1 ? [] : null;
	let [r, i] = M(e), [a, o] = M(t), s = (a - r) / n, c = (o - i) / n, l = [];
	for (let e = 1; e < n; e += 1) l.push(ae(r + s * e, i + c * e));
	return l;
}, I = {
	id: "warchest",
	tier: "beta",
	mechanics: [
		"deck-bag-building",
		"area-control",
		"grid-movement"
	],
	interactionTags: [],
	nameKey: "games.warchest.name",
	descKey: "games.warchest.desc",
	rulesKey: "games.warchest.rules",
	icon: "⚔️",
	iconImg: "games/warchest.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/warchest/en.pdf" },
	precacheAssets: ["board.webp"],
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#b45309",
	releasedAt: "2026-09-21",
	search: {
		py: "zhan zheng zhi xia",
		init: "zzzx"
	},
	hotseat: "cover"
}, L = [
	"berserker",
	"royalguard",
	"scout",
	"knight",
	"marshall",
	"mercenary",
	"ensign",
	"footman",
	"lancer",
	"cavalry",
	"archer",
	"lightcavalry",
	"pikeman",
	"warriorpriest",
	"swordsman",
	"crossbowman"
], R = "royal", z = {
	berserker: {
		id: "berserker",
		coins: 5,
		tactic: !1,
		emoji: "🪓",
		nameKey: "games.warchest.unit.berserker",
		infoKey: "games.warchest.unitInfo.berserker"
	},
	royalguard: {
		id: "royalguard",
		coins: 5,
		tactic: !0,
		emoji: "💂",
		nameKey: "games.warchest.unit.royalguard",
		infoKey: "games.warchest.unitInfo.royalguard"
	},
	scout: {
		id: "scout",
		coins: 5,
		tactic: !1,
		emoji: "🔭",
		nameKey: "games.warchest.unit.scout",
		infoKey: "games.warchest.unitInfo.scout"
	},
	knight: {
		id: "knight",
		coins: 4,
		tactic: !1,
		emoji: "♞",
		nameKey: "games.warchest.unit.knight",
		infoKey: "games.warchest.unitInfo.knight"
	},
	marshall: {
		id: "marshall",
		coins: 5,
		tactic: !0,
		emoji: "🎖️",
		nameKey: "games.warchest.unit.marshall",
		infoKey: "games.warchest.unitInfo.marshall"
	},
	mercenary: {
		id: "mercenary",
		coins: 5,
		tactic: !1,
		emoji: "💰",
		nameKey: "games.warchest.unit.mercenary",
		infoKey: "games.warchest.unitInfo.mercenary"
	},
	ensign: {
		id: "ensign",
		coins: 5,
		tactic: !0,
		emoji: "🚩",
		nameKey: "games.warchest.unit.ensign",
		infoKey: "games.warchest.unitInfo.ensign"
	},
	footman: {
		id: "footman",
		coins: 5,
		tactic: !0,
		emoji: "🥾",
		nameKey: "games.warchest.unit.footman",
		infoKey: "games.warchest.unitInfo.footman"
	},
	lancer: {
		id: "lancer",
		coins: 4,
		tactic: !0,
		emoji: "🐎",
		nameKey: "games.warchest.unit.lancer",
		infoKey: "games.warchest.unitInfo.lancer"
	},
	cavalry: {
		id: "cavalry",
		coins: 4,
		tactic: !0,
		emoji: "🏇",
		nameKey: "games.warchest.unit.cavalry",
		infoKey: "games.warchest.unitInfo.cavalry"
	},
	archer: {
		id: "archer",
		coins: 4,
		tactic: !0,
		emoji: "🏹",
		nameKey: "games.warchest.unit.archer",
		infoKey: "games.warchest.unitInfo.archer"
	},
	lightcavalry: {
		id: "lightcavalry",
		coins: 5,
		tactic: !0,
		emoji: "🐴",
		nameKey: "games.warchest.unit.lightcavalry",
		infoKey: "games.warchest.unitInfo.lightcavalry"
	},
	pikeman: {
		id: "pikeman",
		coins: 4,
		tactic: !1,
		emoji: "🔱",
		nameKey: "games.warchest.unit.pikeman",
		infoKey: "games.warchest.unitInfo.pikeman"
	},
	warriorpriest: {
		id: "warriorpriest",
		coins: 4,
		tactic: !1,
		emoji: "📿",
		nameKey: "games.warchest.unit.warriorpriest",
		infoKey: "games.warchest.unitInfo.warriorpriest"
	},
	swordsman: {
		id: "swordsman",
		coins: 5,
		tactic: !1,
		emoji: "⚔️",
		nameKey: "games.warchest.unit.swordsman",
		infoKey: "games.warchest.unitInfo.swordsman"
	},
	crossbowman: {
		id: "crossbowman",
		coins: 5,
		tactic: !0,
		emoji: "🎯",
		nameKey: "games.warchest.unit.crossbowman",
		infoKey: "games.warchest.unitInfo.crossbowman"
	}
}, se = (e) => e === "footman" ? 2 : 1, ce = [[
	"swordsman",
	"pikeman",
	"crossbowman",
	"lightcavalry"
], [
	"archer",
	"cavalry",
	"lancer",
	"scout"
]], B = t.enum(L), le = t.union([B, t.literal("royal")]), V = t.union([t.literal(0), t.literal(1)]), H = t.string().regex(/^-?\d+,-?\d+$/), U = t.int().min(0).max(8), ue = t.object({
	move: H.optional(),
	attack: H.optional(),
	control: t.literal(!0).optional()
}), W = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draft"),
		unit: B
	}),
	t.object({
		type: t.literal("deploy"),
		hand: U,
		cell: H
	}),
	t.object({
		type: t.literal("bolster"),
		hand: U,
		cell: H
	}),
	t.object({
		type: t.literal("seize"),
		hand: U
	}),
	t.object({
		type: t.literal("recruit"),
		hand: U,
		take: B
	}),
	t.object({
		type: t.literal("pass"),
		hand: U
	}),
	t.object({
		type: t.literal("move"),
		hand: U,
		from: H,
		to: H
	}),
	t.object({
		type: t.literal("control"),
		hand: U,
		cell: H
	}),
	t.object({
		type: t.literal("attack"),
		hand: U,
		from: H,
		target: H
	}),
	t.object({
		type: t.literal("tactic"),
		hand: U,
		from: H,
		to: H.optional(),
		via: H.optional(),
		target: H.optional(),
		ally: H.optional(),
		subs: t.array(ue.extend({ from: H })).max(2).optional()
	}),
	t.object({
		type: t.literal("maneuver"),
		move: H.optional(),
		attack: H.optional(),
		control: t.literal(!0).optional()
	}),
	t.object({ type: t.literal("endPending") }),
	t.object({
		type: t.literal("rgDefend"),
		use: t.boolean()
	})
]), de = t.object({ mode: t.enum([
	"random",
	"draft",
	"tutorial"
]).catch("random") }).default({ mode: "random" }), fe = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("zerk"),
		side: V,
		cell: H
	}),
	t.object({
		kind: t.literal("priest"),
		side: V,
		coinIdx: t.int().min(0)
	}),
	t.object({
		kind: t.literal("rgdefend"),
		side: V,
		cell: H,
		byCell: H
	}),
	t.object({
		kind: t.literal("merc"),
		side: V,
		cell: H
	}),
	t.object({
		kind: t.literal("sword"),
		side: V,
		cell: H
	})
]), pe = t.object({
	kind: t.enum([
		"draft",
		"deploy",
		"bolster",
		"seize",
		"recruit",
		"move",
		"control",
		"attack",
		"tactic",
		"destroy",
		"round",
		"win",
		"deadlock"
	]),
	side: V,
	unit: B.optional(),
	unit2: B.optional(),
	n: t.int().optional()
}), me = t.object({
	side: V,
	unit: B,
	stack: t.int().min(1)
}), he = t.object({
	phase: t.enum([
		"draft",
		"play",
		"over"
	]),
	seats: t.tuple([t.string(), t.string()]),
	round: t.int().min(1),
	turn: V,
	initiative: V,
	initiativeClaimed: t.boolean(),
	draft: t.object({
		pool: t.array(B),
		picks: t.tuple([t.array(B), t.array(B)]),
		turn: V
	}).nullable(),
	armies: t.tuple([t.array(B), t.array(B)]),
	units: t.record(t.string(), me),
	control: t.record(t.string(), V),
	markersLeft: t.tuple([t.int().nonnegative(), t.int().nonnegative()]),
	supply: t.tuple([t.record(t.string(), t.int().nonnegative()), t.record(t.string(), t.int().nonnegative())]),
	bags: t.tuple([t.int().nonnegative(), t.int().nonnegative()]),
	handCounts: t.tuple([t.int().nonnegative(), t.int().nonnegative()]),
	discUp: t.tuple([t.array(le), t.array(le)]),
	discDownCounts: t.tuple([t.int().nonnegative(), t.int().nonnegative()]),
	pending: fe.nullable(),
	winner: V.nullable(),
	log: t.array(pe)
}), ge = t.object({
	hand: t.array(le),
	discDown: t.array(le)
}), _e = 3, G = (e) => ({ code: e }), K = (e, t) => {
	e.log = [...e.log.slice(-59), t];
}, ve = (e, t) => {
	let n = e.players.indexOf(t);
	return n < 0 ? -1 : e.sides[n];
}, q = (e, t) => e.players[e.sides.indexOf(t)];
function ye(t, n) {
	let r = t.bags[n];
	if (r.length === 0 && (r.push(...t.discUp[n], ...t.discDown[n]), t.discUp[n] = [], t.discDown[n] = [], r.length === 0)) return null;
	let i = e(t.seed, t.rngCursor, r.length);
	return t.rngCursor += 1, r.splice(i, 1)[0];
}
function be(e, t, n, r) {
	let i = [];
	for (let r = 0; r < n; r += 1) {
		let n = ye(e, t);
		if (n === null) break;
		e.hands[t].push(n), i.push(n);
	}
	return i.length > 0 && r.push({
		kind: "draw",
		rid: q(e, t),
		data: { count: i.length },
		for: [q(e, t)],
		secret: { coins: i }
	}), i;
}
function xe(e, t, n) {
	let r = [];
	for (let i of O) e.units[i.key] || (A.has(i.key) && e.control[i.key] === t || n === "scout" && (j.get(i.key) ?? []).some((n) => e.units[n]?.side === t)) && r.push(i.key);
	return r;
}
function J(e, t) {
	return (j.get(t) ?? []).filter((t) => !e.units[t]);
}
function Y(e, t, n) {
	let r = e.units[n];
	return !r || r.side !== t || r.unit === "archer" ? [] : (j.get(n) ?? []).filter((n) => {
		let i = e.units[n];
		return !(!i || i.side === t || i.unit === "knight" && r.stack < 2);
	});
}
function X(e, t, n) {
	return !!e.units[n] && e.units[n].side === t && A.has(n) && e.control[n] !== t;
}
function Se(e, t, n) {
	let r = e.units[t];
	r && (--r.stack, r.stack <= 0 && (delete e.units[t], K(e, {
		kind: "destroy",
		side: r.side,
		unit: r.unit
	}), n.push({
		kind: "destroy",
		rid: q(e, r.side),
		data: {
			cell: t,
			unit: r.unit
		}
	})));
}
function Ce(e, t, n, r, i) {
	if (e.winner !== null) return;
	let a = e.units[n];
	if (a && a.side === t) {
		if (a.unit === "warriorpriest" && r !== "move") {
			let n = e.hands[t].length;
			be(e, t, 1, i).length > 0 && (e.pending = {
				kind: "priest",
				side: t,
				coinIdx: n
			});
		} else a.unit === "swordsman" && r === "attack" ? J(e, n).length > 0 && (e.pending = {
			kind: "sword",
			side: t,
			cell: n
		}) : a.unit === "berserker" && a.stack >= 2 && (e.pending = {
			kind: "zerk",
			side: t,
			cell: n
		});
	}
}
function we(e, t, n, r, i) {
	let a = e.units[r];
	if (!a) return;
	let o = a.side;
	if (a.unit === "royalguard" && (e.supply[o].royalguard ?? 0) > 0) {
		e.pending = {
			kind: "rgdefend",
			side: o,
			cell: r,
			byCell: n
		};
		return;
	}
	let s = a.unit === "pikeman";
	Se(e, r, i), s && Se(e, n, i), Ce(e, t, n, "attack", i);
}
function Te(e, t, n, r) {
	for (; n.length > 0;) {
		let i = n[0], a = e.units[i.from];
		if (!a || a.side !== t) return G("games.warchest.errNoUnit");
		if ([
			i.move,
			i.attack,
			i.control
		].filter(Boolean).length !== 1) return G("games.warchest.errTactic");
		if (i.move) {
			if (!J(e, i.from).includes(i.move)) return G("games.warchest.errMove");
			e.units[i.move] = a, delete e.units[i.from], K(e, {
				kind: "move",
				side: t,
				unit: a.unit
			}), r.push({
				kind: "move",
				rid: q(e, t),
				data: {
					from: i.from,
					to: i.move,
					unit: a.unit,
					side: t
				}
			}), Ce(e, t, i.move, "move", r);
		} else if (i.attack) {
			let n = Ee(e, t, i.from, i.attack);
			if (n) return n;
			K(e, {
				kind: "attack",
				side: t,
				unit: a.unit,
				unit2: e.units[i.attack]?.unit
			}), r.push({
				kind: "attack",
				rid: q(e, t),
				data: {
					from: i.from,
					target: i.attack,
					unit: a.unit
				}
			}), we(e, t, i.from, i.attack, r);
		} else {
			if (!X(e, t, i.from)) return G("games.warchest.errControl");
			let n = De(e, t, i.from, r);
			if (n) return n;
			Ce(e, t, i.from, "control", r);
		}
		if (n.shift(), e.pending) return e.pending.kind === "rgdefend" && n.length > 0 && (e.deferredSubs = {
			side: t,
			list: [...n]
		}), null;
		if (e.winner !== null) return null;
	}
	return null;
}
function Ee(e, t, n, r) {
	let i = e.units[n];
	if (!i || i.side !== t) return G("games.warchest.errNoUnit");
	let a = e.units[r];
	return !a || a.side === t ? G("games.warchest.errCell") : a.unit === "knight" && i.stack < 2 ? G("games.warchest.errKnight") : null;
}
function De(e, t, n, r) {
	if (e.markersLeft[t] <= 0) return G("games.warchest.errControl");
	let i = e.control[n];
	return i !== void 0 && i !== t && (e.markersLeft[i] += 1), e.control[n] = t, --e.markersLeft[t], K(e, {
		kind: "control",
		side: t,
		unit: e.units[n]?.unit
	}), r.push({
		kind: "control",
		rid: q(e, t),
		data: { cell: n }
	}), e.markersLeft[t] === 0 && (e.winner = t, e.phase = "over", K(e, {
		kind: "win",
		side: t
	}), r.push({
		kind: "win",
		rid: q(e, t),
		data: { cell: n }
	})), null;
}
function Oe(e, t, n) {
	if (e.winner !== null || e.pending) return;
	if (e.deferredSubs) {
		let t = e.deferredSubs;
		if (e.deferredSubs = null, Te(e, t.side, t.list, n), e.pending || e.winner !== null) return;
	}
	let r = 1 - t;
	e.hands[r].length > 0 ? e.turn = r : e.hands[t].length > 0 ? e.turn = t : ke(e, n);
}
function ke(e, t) {
	e.round += 1, e.initiativeClaimed = !1, be(e, e.initiative, _e, t), be(e, 1 - e.initiative, _e, t), e.turn = e.initiative, K(e, {
		kind: "round",
		side: e.initiative,
		n: e.round
	}), e.hands[0].length === 0 && e.hands[1].length === 0 && (e.winner = e.markersLeft[0] === e.markersLeft[1] ? e.initiative : e.markersLeft[0] < e.markersLeft[1] ? 0 : 1, e.phase = "over", K(e, {
		kind: "deadlock",
		side: e.winner
	}));
}
function Ae(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function je(e, t) {
	for (let t of [0, 1]) {
		e.bags[t] = [...e.armies[t].flatMap((e) => [e, e]), R], e.supply[t] = Object.fromEntries(e.armies[t].map((e) => [e, z[e].coins - 2]));
		for (let n of O.filter((e) => e.startOf === t)) e.control[n.key] = t;
		e.markersLeft[t] = 4;
	}
	e.phase = "play", e.turn = e.initiative, e.round = 1, be(e, e.initiative, _e, t), be(e, 1 - e.initiative, _e, t);
}
function Me(t, n, r) {
	let i = {
		seed: r,
		rngCursor: 0
	}, a = e(r, i.rngCursor++, 2), o = e(r, i.rngCursor++, 2), s = {
		seed: r,
		rngCursor: i.rngCursor,
		players: [n[0], n[1]],
		sides: [a, 1 - a],
		phase: "play",
		draftPool: [],
		draftPicks: [[], []],
		draftFirst: 0,
		armies: [[], []],
		bags: [[], []],
		hands: [[], []],
		discUp: [[], []],
		discDown: [[], []],
		supply: [{}, {}],
		units: {},
		control: {},
		markersLeft: [4, 4],
		initiative: o,
		initiativeClaimed: !1,
		turn: o,
		round: 0,
		pending: null,
		deferredSubs: null,
		winner: null,
		log: []
	}, c = [];
	if (t.mode === "draft") s.draftPool = Ae(s, [...L]).slice(0, 8), s.draftFirst = e(s.seed, s.rngCursor++, 2), s.initiative = 1 - s.draftFirst, s.phase = "draft";
	else {
		if (t.mode === "tutorial") s.armies = [[...ce[0]], [...ce[1]]];
		else {
			let e = Ae(s, [...L]);
			s.armies = [e.slice(0, 4), e.slice(4, 8)];
		}
		je(s, c);
	}
	return {
		state: s,
		fx: c
	};
}
var Ne = (e) => {
	let t = e.draftPicks[0].length + e.draftPicks[1].length;
	return [
		e.draftFirst,
		1 - e.draftFirst,
		1 - e.draftFirst,
		e.draftFirst,
		e.draftFirst,
		1 - e.draftFirst,
		1 - e.draftFirst,
		e.draftFirst
	][t];
};
function Pe(e, t, n) {
	let r = ve(e, n.by);
	if (r < 0) return G("games.warchest.errTurn");
	if (e.phase === "over") return G("games.warchest.errOver");
	if (e.phase === "draft") {
		if (t.type !== "draft") return G("games.warchest.errDraft");
		if (Ne(e) !== r) return G("games.warchest.errTurn");
		if (!e.draftPool.includes(t.unit)) return G("games.warchest.errDraft");
		let i = structuredClone(e);
		i.draftPool.splice(i.draftPool.indexOf(t.unit), 1), i.draftPicks[r].push(t.unit), K(i, {
			kind: "draft",
			side: r,
			unit: t.unit
		});
		let a = [{
			kind: "draft",
			rid: n.by,
			data: { unit: t.unit }
		}];
		return i.draftPool.length === 0 && (i.armies = [i.draftPicks[0], i.draftPicks[1]], je(i, a)), {
			state: i,
			fx: a
		};
	}
	let i = e.pending;
	if (t.type === "rgDefend") {
		if (!i || i.kind !== "rgdefend" || i.side !== r) return G("games.warchest.errPending");
		let n = structuredClone(e), a = [], o = 1 - r;
		if (t.use) {
			if ((n.supply[r].royalguard ?? 0) <= 0) return G("games.warchest.errSupply");
			n.supply[r].royalguard = (n.supply[r].royalguard ?? 0) - 1;
		} else Se(n, i.cell, a);
		return n.pending = null, Ce(n, o, i.byCell, "attack", a), Oe(n, o, a), {
			state: n,
			fx: a
		};
	}
	if (t.type === "maneuver" || t.type === "endPending") {
		if (!i || i.side !== r || i.kind === "priest" || i.kind === "rgdefend") return G("games.warchest.errPending");
		let a = structuredClone(e), o = [];
		if (a.pending = null, t.type === "endPending") return Oe(a, r, o), {
			state: a,
			fx: o
		};
		let s = a.units[i.cell];
		if (!s || s.side !== r) return G("games.warchest.errNoUnit");
		if (i.kind === "zerk") {
			if (s.stack < 2) return G("games.warchest.errTactic");
			--s.stack;
		}
		let c = {
			from: i.cell,
			move: t.move,
			attack: t.attack,
			control: t.control
		};
		if (i.kind === "sword" && !t.move) return G("games.warchest.errTactic");
		if (i.kind === "sword" && t.move) {
			if (!J(a, i.cell).includes(t.move)) return G("games.warchest.errMove");
			a.units[t.move] = s, delete a.units[i.cell], K(a, {
				kind: "move",
				side: r,
				unit: s.unit
			}), o.push({
				kind: "move",
				rid: n.by,
				data: {
					from: i.cell,
					to: t.move,
					unit: s.unit,
					side: r
				}
			});
		} else {
			let e = Te(a, r, [c], o);
			if (e) return e;
		}
		return Oe(a, r, o), {
			state: a,
			fx: o
		};
	}
	if (t.type === "draft" || r !== e.turn) return G("games.warchest.errTurn");
	if (i) {
		if (i.kind !== "priest") return G("games.warchest.errPending");
		if (i.side !== r) return G("games.warchest.errTurn");
		if (t.hand !== i.coinIdx) return G("games.warchest.errHand");
	}
	let a = e.hands[r][t.hand];
	if (a === void 0) return G("games.warchest.errHand");
	let o = structuredClone(e);
	o.pending = null;
	let s = [], c = (e) => Object.values(o.units).filter((t) => t.side === r && t.unit === e);
	switch (t.type) {
		case "deploy":
			if (a === "royal") return G("games.warchest.errCoin");
			if (c(a).length >= se(a)) return G("games.warchest.errDup");
			if (!xe(o, r, a).includes(t.cell)) return G("games.warchest.errNoControl");
			o.hands[r].splice(t.hand, 1), o.units[t.cell] = {
				side: r,
				unit: a,
				stack: 1
			}, K(o, {
				kind: "deploy",
				side: r,
				unit: a
			}), s.push({
				kind: "deploy",
				rid: n.by,
				data: {
					cell: t.cell,
					unit: a,
					side: r
				}
			});
			break;
		case "bolster": {
			let e = o.units[t.cell];
			if (a === "royal" || !e || e.side !== r || e.unit !== a) return G("games.warchest.errCoin");
			o.hands[r].splice(t.hand, 1), e.stack += 1, K(o, {
				kind: "bolster",
				side: r,
				unit: a
			}), s.push({
				kind: "bolster",
				rid: n.by,
				data: {
					cell: t.cell,
					unit: a
				}
			});
			break;
		}
		case "seize": {
			if (e.initiative === r || e.initiativeClaimed) return G("games.warchest.errSeize");
			let [i] = o.hands[r].splice(t.hand, 1);
			o.discDown[r].push(i), o.initiative = r, o.initiativeClaimed = !0, K(o, {
				kind: "seize",
				side: r
			}), s.push({
				kind: "seize",
				rid: n.by
			});
			break;
		}
		case "recruit": {
			if ((o.supply[r][t.take] ?? 0) <= 0) return G("games.warchest.errSupply");
			let [e] = o.hands[r].splice(t.hand, 1);
			if (o.discDown[r].push(e), o.supply[r][t.take] = (o.supply[r][t.take] ?? 0) - 1, o.discUp[r].push(t.take), K(o, {
				kind: "recruit",
				side: r,
				unit: t.take
			}), s.push({
				kind: "recruit",
				rid: n.by,
				data: { unit: t.take }
			}), t.take === "mercenary") {
				let e = Object.keys(o.units).find((e) => o.units[e].side === r && o.units[e].unit === "mercenary");
				e && (o.pending = {
					kind: "merc",
					side: r,
					cell: e
				});
			}
			break;
		}
		case "pass": {
			let [e] = o.hands[r].splice(t.hand, 1);
			o.discDown[r].push(e);
			break;
		}
		case "move": {
			let e = o.units[t.from];
			if (!e || e.side !== r || e.unit !== a) return G("games.warchest.errCoin");
			if (!J(o, t.from).includes(t.to)) return G("games.warchest.errMove");
			o.hands[r].splice(t.hand, 1), o.discUp[r].push(a), o.units[t.to] = e, delete o.units[t.from], K(o, {
				kind: "move",
				side: r,
				unit: a
			}), s.push({
				kind: "move",
				rid: n.by,
				data: {
					from: t.from,
					to: t.to,
					unit: a,
					side: r
				}
			}), Ce(o, r, t.to, "move", s);
			break;
		}
		case "control": {
			let e = o.units[t.cell];
			if (!e || e.side !== r || e.unit !== a) return G("games.warchest.errCoin");
			if (!X(o, r, t.cell)) return G("games.warchest.errControl");
			o.hands[r].splice(t.hand, 1), o.discUp[r].push(a);
			let n = De(o, r, t.cell, s);
			if (n) return n;
			Ce(o, r, t.cell, "control", s);
			break;
		}
		case "attack": {
			let e = o.units[t.from];
			if (!e || e.side !== r || e.unit !== a) return G("games.warchest.errCoin");
			if (e.unit === "archer") return G("games.warchest.errArcher");
			if (N(t.from, t.target) !== 1) return G("games.warchest.errCell");
			let i = Ee(o, r, t.from, t.target);
			if (i) return i;
			o.hands[r].splice(t.hand, 1), o.discUp[r].push(a), K(o, {
				kind: "attack",
				side: r,
				unit: a,
				unit2: o.units[t.target]?.unit
			}), s.push({
				kind: "attack",
				rid: n.by,
				data: {
					from: t.from,
					target: t.target,
					unit: a
				}
			}), we(o, r, t.from, t.target, s);
			break;
		}
		case "tactic": {
			let e = o.units[t.from];
			if (!e || e.side !== r) return G("games.warchest.errNoUnit");
			if (a !== (e.unit === "royalguard" ? "royal" : e.unit)) return G("games.warchest.errCoin");
			if (!z[e.unit].tactic) return G("games.warchest.errTactic");
			let n = Fe(o, r, t, s);
			if (n) return n;
			o.hands[r].splice(t.hand, 1), o.discUp[r].push(a), K(o, {
				kind: "tactic",
				side: r,
				unit: e.unit
			});
			break;
		}
		default: return G("games.warchest.errHand");
	}
	return Oe(o, r, s), {
		state: o,
		fx: s
	};
}
function Fe(e, t, n, r) {
	let i = e.units[n.from], a = q(e, t);
	switch (i.unit) {
		case "royalguard": return !n.to || !J(e, n.from).includes(n.to) ? G("games.warchest.errMove") : (e.units[n.to] = i, delete e.units[n.from], r.push({
			kind: "move",
			rid: a,
			data: {
				from: n.from,
				to: n.to,
				unit: i.unit,
				side: t
			}
		}), null);
		case "lightcavalry": return !n.to || !n.via || n.to === n.from ? G("games.warchest.errTactic") : !J(e, n.from).includes(n.via) || !(j.get(n.via) ?? []).includes(n.to) || e.units[n.to] ? G("games.warchest.errMove") : (e.units[n.to] = i, delete e.units[n.from], r.push({
			kind: "move",
			rid: a,
			data: {
				from: n.from,
				to: n.to,
				unit: i.unit,
				side: t
			}
		}), null);
		case "cavalry": return !n.to || !n.target ? G("games.warchest.errTactic") : J(e, n.from).includes(n.to) ? (e.units[n.to] = i, delete e.units[n.from], r.push({
			kind: "move",
			rid: a,
			data: {
				from: n.from,
				to: n.to,
				unit: i.unit,
				side: t
			}
		}), N(n.to, n.target) === 1 ? Ee(e, t, n.to, n.target) || (r.push({
			kind: "attack",
			rid: a,
			data: {
				from: n.to,
				target: n.target,
				unit: i.unit
			}
		}), we(e, t, n.to, n.target, r), null) : G("games.warchest.errTactic")) : G("games.warchest.errMove");
		case "lancer": {
			if (!n.to || !n.target) return G("games.warchest.errTactic");
			let o = P(n.from, n.to);
			if (o === null || o > 2) return G("games.warchest.errTactic");
			let s = F(n.from, n.to);
			return !s || s.some((t) => e.units[t]) ? G("games.warchest.errMove") : (e.units[n.to] = i, delete e.units[n.from], r.push({
				kind: "move",
				rid: a,
				data: {
					from: n.from,
					to: n.to,
					unit: i.unit,
					side: t
				}
			}), N(n.to, n.target) === 1 ? Ee(e, t, n.to, n.target) || (r.push({
				kind: "attack",
				rid: a,
				data: {
					from: n.to,
					target: n.target,
					unit: i.unit
				}
			}), we(e, t, n.to, n.target, r), null) : G("games.warchest.errTactic"));
		}
		case "archer": return !n.target || N(n.from, n.target) !== 2 ? G("games.warchest.errTactic") : Ee(e, t, n.from, n.target) || (r.push({
			kind: "attack",
			rid: a,
			data: {
				from: n.from,
				target: n.target,
				unit: i.unit
			}
		}), we(e, t, n.from, n.target, r), null);
		case "crossbowman": {
			if (!n.target) return G("games.warchest.errTactic");
			let o = P(n.from, n.target);
			if (o === null || o < 2) return G("games.warchest.errTactic");
			let s = F(n.from, n.target);
			return s && s.some((t) => e.units[t]) ? G("games.warchest.errTactic") : Ee(e, t, n.from, n.target) || (r.push({
				kind: "attack",
				rid: a,
				data: {
					from: n.from,
					target: n.target,
					unit: i.unit
				}
			}), we(e, t, n.from, n.target, r), null);
		}
		case "marshall": {
			if (!n.ally || !n.target || n.ally === n.from || N(n.from, n.ally) > 2) return G("games.warchest.errTactic");
			let i = e.units[n.ally];
			return !i || i.side !== t ? G("games.warchest.errNoUnit") : i.unit === "archer" ? G("games.warchest.errArcher") : N(n.ally, n.target) === 1 ? Ee(e, t, n.ally, n.target) || (r.push({
				kind: "attack",
				rid: a,
				data: {
					from: n.ally,
					target: n.target,
					unit: i.unit
				}
			}), we(e, t, n.ally, n.target, r), null) : G("games.warchest.errTactic");
		}
		case "ensign": {
			if (!n.ally || !n.to || n.ally === n.from || N(n.from, n.ally) > 2 || N(n.from, n.to) > 2) return G("games.warchest.errTactic");
			let i = e.units[n.ally];
			return !i || i.side !== t ? G("games.warchest.errNoUnit") : J(e, n.ally).includes(n.to) ? (e.units[n.to] = i, delete e.units[n.ally], r.push({
				kind: "move",
				rid: a,
				data: {
					from: n.ally,
					to: n.to,
					unit: i.unit,
					side: t
				}
			}), null) : G("games.warchest.errMove");
		}
		case "footman": {
			let i = n.subs ?? [], a = Object.keys(e.units).filter((n) => e.units[n].side === t && e.units[n].unit === "footman");
			if (a.length === 0) return G("games.warchest.errNoUnit");
			let o = /* @__PURE__ */ new Set();
			for (let e of i) {
				if (!a.includes(e.from) || o.has(e.from)) return G("games.warchest.errTactic");
				o.add(e.from);
			}
			return Te(e, t, [...i], r);
		}
		default: return G("games.warchest.errTactic");
	}
}
function Ie(e, t) {
	let n = ve(e, t);
	return {
		public: {
			phase: e.phase,
			seats: [q(e, 0), q(e, 1)],
			round: Math.max(1, e.round),
			turn: e.turn,
			initiative: e.initiative,
			initiativeClaimed: e.initiativeClaimed,
			draft: e.phase === "draft" ? {
				pool: e.draftPool,
				picks: [e.draftPicks[0], e.draftPicks[1]],
				turn: Ne(e)
			} : null,
			armies: e.armies,
			units: e.units,
			control: e.control,
			markersLeft: e.markersLeft,
			supply: [e.supply[0], e.supply[1]],
			bags: [e.bags[0].length, e.bags[1].length],
			handCounts: [e.hands[0].length, e.hands[1].length],
			discUp: e.discUp,
			discDownCounts: [e.discDown[0].length, e.discDown[1].length],
			pending: e.pending,
			winner: e.winner,
			log: e.log
		},
		private: {
			hand: n === -1 ? [] : e.hands[n],
			discDown: n === -1 ? [] : e.discDown[n]
		}
	};
}
function Le(e) {
	if (e.winner === null) return { phase: e.phase };
	let t = q(e, e.winner), n = q(e, 1 - e.winner);
	return {
		phase: "done",
		winner: [t],
		ranking: [t, n],
		scores: {
			[t]: 6 - e.markersLeft[e.winner],
			[n]: 6 - e.markersLeft[1 - e.winner]
		}
	};
}
var Re = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: I,
	schemas: {
		action: W,
		publicView: he,
		privateView: ge,
		config: de
	},
	setup: Me,
	reduce: Pe,
	viewFor: Ie,
	status: Le
}, ze = {
	berserker: "M8 31 29 10 M19 8 32 21 M6 27 13 34",
	royalguard: "M20 5 31 10 29 25 20 34 11 25 9 10Z M20 9V29 M13 18H27",
	scout: "M6 27 20 8 34 27 M12 22H28 M20 8V33",
	knight: "M10 31 11 16 20 7 30 14 28 31Z M18 16H19",
	marshall: "M8 10 20 17 32 10 29 28 20 34 11 28Z M20 17V31",
	mercenary: "M20 5V35 M11 12C11 6 30 6 30 15S10 18 10 25 29 33 31 25",
	ensign: "M12 5V34 M13 7H31L26 15 31 23H13",
	footman: "M20 5V31 M12 18H28 M13 31H27",
	lancer: "M20 3V34 M13 11 20 3 27 11 M11 34H29",
	cavalry: "M8 30 17 8 30 13 25 22 32 30Z M16 17H22",
	archer: "M12 6C31 12 31 28 12 34 M10 7 23 20 10 33 M20 20H34",
	lightcavalry: "M7 27 18 8 30 14 23 22 33 29 M8 32H32",
	pikeman: "M20 4V34 M9 8 20 4 31 8 M13 33H27",
	warriorpriest: "M20 5V34 M9 15H31 M11 29Q20 36 29 29",
	swordsman: "M7 8 32 33 M33 8 8 33 M5 12 12 5 M28 5 35 12",
	crossbowman: "M6 12Q20 25 34 12 M20 11V34 M11 29H29 M8 7 6 12 M32 7 34 12",
	royal: "M6 13 12 27H28L34 13 26 19 20 8 14 19Z M12 31H28"
};
function Z({ coin: e, className: t = "" }) {
	return /* @__PURE__ */ p("svg", {
		className: t,
		width: "40",
		height: "40",
		viewBox: "0 0 40 40",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.7",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: /* @__PURE__ */ p("path", { d: ze[e] })
	});
}
//#endregion
//#region src/games/warchest/view-player.tsx
var Be = ["#1786aa", "#b7514b"], Ve = {
	draft: "games.warchest.log.draft",
	deploy: "games.warchest.log.deploy",
	bolster: "games.warchest.log.bolster",
	seize: "games.warchest.log.seize",
	recruit: "games.warchest.log.recruit",
	move: "games.warchest.log.move",
	control: "games.warchest.log.control",
	attack: "games.warchest.log.attack",
	tactic: "games.warchest.log.tactic",
	destroy: "games.warchest.log.destroy",
	round: "games.warchest.log.round",
	win: "games.warchest.log.win",
	deadlock: "games.warchest.log.deadlock"
};
function He(e, t, n) {
	let r = { name: n(t.side) };
	return t.unit && (r.unit = e(z[t.unit].nameKey)), t.unit2 && (r.unit2 = e(z[t.unit2].nameKey)), t.n !== void 0 && (r.n = t.n), e(Ve[t.kind], r);
}
function Ue(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ p(Ge, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var We = [];
function Ge({ pub: e, priv: t, members: n, myRid: r, send: a }) {
	let s = u(), c = +(e.seats.indexOf(r) === 1), l = 1 - c, f = e.seats[l], h = (t) => n.find((n) => n.rid === e.seats[t])?.name ?? "", g = h(l), _ = h(c), ee = t?.hand ?? We, v = e.winner === null && e.pending && e.pending.side === c ? e.pending : null, te = e.turn === c && e.winner === null && !e.pending, y = te || v?.kind === "priest", [b, ne] = o(null), [x, S] = o(null), [C, w] = o(null), [T, E] = o(null), [D, O] = o(null), [k, re] = o([]), [ie, j] = o(!1), [M, ae] = o(null), [N, oe] = o(!1), [P, F] = o(!1), I = b === null ? null : ee[b] ?? null, L = {
		units: e.units,
		control: e.control
	}, R = (t) => Object.keys(e.units).filter((n) => e.units[n].side === c && e.units[n].unit === t), ce = () => {
		S(null), w(null), E(null), O(null), re([]);
	}, B = (e) => {
		a(e), ne(null), ce();
	}, le = i(() => {
		if (I === null || !y) return [];
		let e = [];
		if (I !== "royal") {
			let t = I;
			R(t).length < se(t) && xe(L, c, t).length > 0 && e.push("deploy"), R(t).length > 0 && (e.push("bolster"), R(t).some((e) => J(L, e).length > 0) && e.push("move"), R(t).some((e) => Y(L, c, e).length > 0) && e.push("attack"), R(t).some((e) => X(L, c, e)) && e.push("control"), z[t].tactic && e.push("tactic"));
		} else R("royalguard").length > 0 && e.push("tactic");
		return e;
	}, [
		I,
		y,
		e.units,
		e.control,
		c
	]), V = i(() => {
		let t = /* @__PURE__ */ new Map();
		if (e.winner !== null) return t;
		if (v && (v.kind === "zerk" || v.kind === "merc" || v.kind === "sword")) {
			let n = v.cell;
			if (!e.units[n]) return t;
			if (v.kind !== "sword") {
				for (let e of Y(L, c, n)) t.set(e, "enemy");
				X(L, c, n) && t.set(n, "target");
			}
			for (let e of J(L, n)) t.set(e, "target");
			return t;
		}
		if (I === null || !x || !y) return t;
		if (x === "deploy" && I !== "royal") {
			for (let e of xe(L, c, I)) t.set(e, "target");
			return t;
		}
		let n = I === "royal" ? "royalguard" : I, r = R(n);
		if (x === "bolster") {
			for (let e of r) t.set(e, "target");
			return t;
		}
		if (x === "control") {
			for (let e of r) X(L, c, e) && t.set(e, "target");
			return t;
		}
		if (x === "move") {
			if (C === null) for (let e of r) J(L, e).length > 0 && t.set(e, "from");
			else for (let e of J(L, C)) t.set(e, "target");
			return t;
		}
		if (x === "attack") {
			if (C === null) for (let e of r) Y(L, c, e).length > 0 && t.set(e, "from");
			else for (let e of Y(L, c, C)) t.set(e, "enemy");
			return t;
		}
		return Ke(t, e, c, n, r, C, T, D, k), t;
	}, [
		v,
		I,
		x,
		C,
		T,
		D,
		k,
		y,
		e,
		c
	]), H = (t) => {
		if (v && (v.kind === "zerk" || v.kind === "merc" || v.kind === "sword")) {
			if (!V.has(t)) return;
			let n = v.cell;
			v.kind === "sword" ? a({
				type: "maneuver",
				move: t
			}) : t === n ? a({
				type: "maneuver",
				control: !0
			}) : e.units[t] ? a({
				type: "maneuver",
				attack: t
			}) : a({
				type: "maneuver",
				move: t
			});
			return;
		}
		if (e.winner !== null) return;
		if (I === null || !x || !y) {
			(e.units[t] || A.has(t)) && ae(t);
			return;
		}
		if (!V.has(t)) {
			(e.units[t] || A.has(t)) && ae(t);
			return;
		}
		let n = I === "royal" ? "royalguard" : I;
		switch (x) {
			case "deploy":
				B({
					type: "deploy",
					hand: b,
					cell: t
				});
				return;
			case "bolster":
				B({
					type: "bolster",
					hand: b,
					cell: t
				});
				return;
			case "control":
				B({
					type: "control",
					hand: b,
					cell: t
				});
				return;
			case "move":
				C === null ? w(t) : B({
					type: "move",
					hand: b,
					from: C,
					to: t
				});
				return;
			case "attack":
				C === null ? w(t) : B({
					type: "attack",
					hand: b,
					from: C,
					target: t
				});
				return;
			case "tactic":
				U(t, n);
				return;
		}
	}, U = (t, n) => {
		let r = R(n), i = b;
		switch (n) {
			case "royalguard":
				C === null ? w(t) : B({
					type: "tactic",
					hand: i,
					from: C,
					to: t
				});
				return;
			case "archer":
			case "crossbowman":
				C === null ? w(t) : B({
					type: "tactic",
					hand: i,
					from: C,
					target: t
				});
				return;
			case "lightcavalry":
				C === null ? w(t) : T === null ? E(t) : B({
					type: "tactic",
					hand: i,
					from: C,
					via: T,
					to: t
				});
				return;
			case "cavalry":
			case "lancer":
				C === null ? w(t) : T === null ? E(t) : B({
					type: "tactic",
					hand: i,
					from: C,
					to: T,
					target: t
				});
				return;
			case "marshall":
			case "ensign":
				D === null ? O(t) : B(n === "marshall" ? {
					type: "tactic",
					hand: i,
					from: r[0],
					ally: D,
					target: t
				} : {
					type: "tactic",
					hand: i,
					from: r[0],
					ally: D,
					to: t
				});
				return;
			case "footman": {
				let n = r.filter((e) => !k.some((t) => t.from === e));
				if (C === null) {
					n.includes(t) && w(t);
					return;
				}
				let i = t === C ? {
					from: C,
					control: !0
				} : e.units[t] ? {
					from: C,
					attack: t
				} : {
					from: C,
					move: t
				}, a = [...k, i];
				re(a), w(null);
				return;
			}
			default: return;
		}
	}, ue = () => {
		if (k.length === 0 || b === null) return;
		let e = R("footman")[0];
		B({
			type: "tactic",
			hand: b,
			from: e,
			subs: k
		});
	}, W, de;
	e.winner === null ? e.phase === "draft" ? W = e.draft?.turn === c ? s("games.warchest.draftPick") : s("games.warchest.waitTurn", { name: h(e.draft?.turn ?? l) }) : v ? (W = s({
		zerk: "games.warchest.pending.zerk",
		priest: "games.warchest.pending.priest",
		rgdefend: "games.warchest.pending.rgdefend",
		merc: "games.warchest.pending.merc",
		sword: "games.warchest.pending.sword"
	}[v.kind]), de = v.kind === "rgdefend" || v.kind === "priest" ? void 0 : s("games.warchest.pendingMay")) : W = e.pending ? s("games.warchest.waitTurn", { name: h(e.pending.side) }) : te ? s("games.warchest.promptTurn") : s("games.warchest.waitTurn", { name: h(e.turn) }) : W = s("games.warchest.ended");
	let fe = e.log[e.log.length - 1], pe = fe ? He(s, fe, h) : null, me = e.winner === null ? e.phase === "draft" || v ? W : y ? s(I === null ? "games.warchest.pickCoin" : x === null ? "games.warchest.chooseAction" : x === "deploy" || x === "bolster" || x === "control" ? "games.warchest.selectTarget" : C === null && D === null ? "games.warchest.selectUnit" : T === null && x === "tactic" && (I === "lightcavalry" || I === "cavalry" || I === "lancer") ? "games.warchest.selectPath" : "games.warchest.selectTarget") : W : s("games.warchest.ended");
	return /* @__PURE__ */ m("div", {
		className: "wc-scene",
		style: { "--wc-board-url": "url(./games/warchest/board.webp)" },
		children: [
			/* @__PURE__ */ p(d, {
				adaptive: !0,
				className: "wc-screen",
				scroll: !1,
				banner: /* @__PURE__ */ m("div", {
					className: "wc-top",
					children: [
						/* @__PURE__ */ p("div", {
							className: "wc-title",
							children: s("games.warchest.name")
						}),
						/* @__PURE__ */ m("div", {
							className: "wc-phase",
							children: [
								s("games.warchest.roundChip", { n: e.round }),
								" · ",
								W,
								de ? ` · ${de}` : ""
							]
						}),
						/* @__PURE__ */ p(Qe, {
							rid: f,
							mine: !1,
							side: l,
							label: g,
							active: e.turn === l,
							initiative: e.initiative === l,
							claimed: e.initiativeClaimed,
							markers: e.markersLeft[l],
							bag: e.bags[l],
							hand: e.handCounts[l]
						})
					]
				}),
				actionsHeight: "h-[205px]",
				actions: /* @__PURE__ */ m("div", {
					className: "wc-tray",
					children: [
						/* @__PURE__ */ p(Qe, {
							rid: r,
							mine: !0,
							side: c,
							label: _,
							active: e.turn === c,
							initiative: e.initiative === c,
							claimed: e.initiativeClaimed,
							markers: e.markersLeft[c],
							bag: e.bags[c],
							hand: ee.length
						}),
						e.phase === "draft" ? /* @__PURE__ */ m("div", {
							className: "wc-hand wc-draft-plate",
							children: [/* @__PURE__ */ p("span", { children: "✦" }), s("games.warchest.draftTray")]
						}) : /* @__PURE__ */ p($e, {
							hand: ee,
							sel: b,
							priestIdx: v?.kind === "priest" ? v.coinIdx : null,
							disabled: !y,
							onSelect: (e) => {
								ne(b === e ? null : e), ce();
							}
						}),
						/* @__PURE__ */ p("div", {
							className: "wc-command-label",
							children: s("games.warchest.command")
						}),
						/* @__PURE__ */ p(nt, {
							t: s,
							pending: v,
							acts: le,
							act: x,
							selCoin: I,
							acting: y,
							waitingText: W,
							footmanCount: k.length,
							canSeize: e.initiative !== c && !e.initiativeClaimed,
							canRecruit: Object.values(e.supply[c]).some((e) => e > 0),
							onAct: (e) => {
								S(x === e ? null : e), w(null), E(null), O(null), re([]);
							},
							onSeize: () => b !== null && B({
								type: "seize",
								hand: b
							}),
							onRecruit: () => j(!0),
							onPass: () => b !== null && B({
								type: "pass",
								hand: b
							}),
							onRg: (e) => a({
								type: "rgDefend",
								use: e
							}),
							onEndPending: () => a({ type: "endPending" }),
							onFootmanDone: ue
						})
					]
				}),
				children: e.phase === "draft" && e.draft ? /* @__PURE__ */ p(Ze, {
					pub: e,
					mySide: c,
					nameOf: h,
					send: a
				}) : /* @__PURE__ */ p(Ye, {
					pub: e,
					mySide: c,
					highlights: V,
					from: C,
					logLine: pe,
					stepText: me,
					onOpenLog: () => F(!0),
					onOpenArmy: () => oe(!0),
					onTap: H
				})
			}),
			/* @__PURE__ */ p(rt, {
				open: P,
				log: e.log,
				nameOf: h,
				onClose: () => F(!1)
			}),
			/* @__PURE__ */ p(it, {
				cell: M,
				pub: e,
				nameOf: h,
				onClose: () => ae(null)
			}),
			/* @__PURE__ */ p(at, {
				open: N,
				pub: e,
				priv: t,
				mySide: c,
				nameOf: h,
				onClose: () => oe(!1)
			}),
			/* @__PURE__ */ p(st, {
				open: ie,
				pub: e,
				mySide: c,
				onPick: (e) => {
					B({
						type: "recruit",
						hand: b,
						take: e
					}), j(!1);
				},
				onClose: () => j(!1)
			})
		]
	});
}
function Ke(e, t, n, r, i, a, o, s, c) {
	let l = {
		units: t.units,
		control: t.control
	}, u = (e) => {
		let r = t.units[e];
		return r && r.side !== n ? r : null;
	}, d = (e, n) => t.units[n]?.unit !== "knight" || e >= 2;
	switch (r) {
		case "royalguard":
			if (a === null) for (let t of i) e.set(t, "from");
			else for (let t of J(l, a)) e.set(t, "target");
			return;
		case "archer":
			if (a === null) for (let t of i) e.set(t, "from");
			else for (let [r, i] of Object.entries(t.units)) i.side !== n && N(a, r) === 2 && d(t.units[a].stack, r) && e.set(r, "enemy");
			return;
		case "crossbowman":
			if (a === null) for (let t of i) e.set(t, "from");
			else for (let [r, i] of Object.entries(t.units)) {
				if (i.side === n) continue;
				let o = P(a, r);
				if (o === null || o < 2) continue;
				let s = F(a, r);
				s && s.some((e) => t.units[e]) || d(t.units[a].stack, r) && e.set(r, "enemy");
			}
			return;
		case "lightcavalry":
			if (a === null) for (let t of i) e.set(t, "from");
			else if (o === null) for (let t of J(l, a)) e.set(t, "target");
			else for (let n of j.get(o) ?? []) n !== a && !t.units[n] && e.set(n, "target");
			return;
		case "cavalry":
			if (a === null) for (let n of i) J(l, n).some((e) => (j.get(e) ?? []).some((e) => u(e) && d(t.units[n].stack, e))) && e.set(n, "from");
			else if (o === null) for (let n of J(l, a)) (j.get(n) ?? []).some((e) => u(e) && d(t.units[a].stack, e)) && e.set(n, "target");
			else for (let n of j.get(o) ?? []) u(n) && d(t.units[a].stack, n) && e.set(n, "enemy");
			return;
		case "lancer":
			if (a === null) for (let t of i) e.set(t, "from");
			else if (o === null) for (let n of O) {
				let r = P(a, n.key);
				if (r === null || r > 2 || t.units[n.key]) continue;
				let i = F(a, n.key);
				i && !i.some((e) => t.units[e]) && (j.get(n.key) ?? []).some((e) => u(e) && d(t.units[a].stack, e)) && e.set(n.key, "target");
			}
			else for (let n of j.get(o) ?? []) u(n) && d(t.units[a].stack, n) && e.set(n, "enemy");
			return;
		case "marshall":
			if (s === null) for (let [r, a] of Object.entries(t.units)) a.side === n && a.unit !== "archer" && i.some((e) => N(e, r) <= 2) && (i.includes(r) || Y(l, n, r).length > 0 && e.set(r, "from"));
			else for (let t of Y(l, n, s)) e.set(t, "enemy");
			return;
		case "ensign":
			if (s === null) for (let [r, a] of Object.entries(t.units)) a.side !== n || i.includes(r) || i.some((e) => N(e, r) <= 2) && J(l, r).some((e) => i.some((t) => N(t, e) <= 2)) && e.set(r, "from");
			else {
				let t = i[0];
				for (let n of J(l, s)) N(t, n) <= 2 && e.set(n, "target");
			}
			return;
		case "footman": {
			let t = i.filter((e) => !c.some((t) => t.from === e));
			if (a === null) for (let r of t) {
				let t = J(l, r).length > 0, i = Y(l, n, r).length > 0, a = X(l, n, r);
				(t || i || a) && e.set(r, "from");
			}
			else {
				for (let t of J(l, a)) e.set(t, "target");
				for (let t of Y(l, n, a)) e.set(t, "enemy");
				X(l, n, a) && e.set(a, "target");
			}
			return;
		}
		default: return;
	}
}
var qe = 10, Je = Array.from({ length: 6 }, (e, t) => {
	let n = Math.PI / 180 * (60 * t);
	return `${(qe * Math.cos(n)).toFixed(2)},${(qe * Math.sin(n)).toFixed(2)}`;
}).join(" ");
function Ye({ pub: e, mySide: t, highlights: n, from: r, logLine: i, stepText: a, onOpenLog: o, onOpenArmy: s, onTap: c }) {
	let l = u(), d = t === 0 ? 180 : 0;
	return /* @__PURE__ */ m("div", {
		className: "wc-board",
		children: [/* @__PURE__ */ p("div", {
			className: "wc-board-map",
			children: /* @__PURE__ */ p("svg", {
				viewBox: "-11 -3 112 127",
				className: "wc-board-svg",
				role: "img",
				"aria-label": l("games.warchest.boardAria"),
				children: /* @__PURE__ */ p("g", {
					transform: `rotate(${d} 45 60.6)`,
					children: O.map((t) => /* @__PURE__ */ p(Xe, {
						cell: t,
						pub: e,
						rot: d,
						highlight: n.get(t.key) ?? null,
						selected: r === t.key,
						onTap: c
					}, t.key))
				})
			})
		}), /* @__PURE__ */ m("div", {
			className: "wc-ribbon",
			children: [
				/* @__PURE__ */ p("button", {
					type: "button",
					onClick: o,
					"aria-label": l("games.warchest.logAria"),
					title: i ?? l("games.warchest.logEmpty"),
					children: l("games.warchest.logShort")
				}),
				/* @__PURE__ */ p("span", {
					className: "wc-ribbon-text",
					children: a
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					onClick: s,
					"aria-label": l("games.warchest.armyAria"),
					children: l("games.warchest.armyShort")
				})
			]
		})]
	});
}
function Xe({ cell: e, pub: t, rot: n, highlight: r, selected: i, onTap: a }) {
	let { ref: o } = c(`cell:${e.key}`), s = o, l = t.units[e.key], u = t.control[e.key], d = A.has(e.key), h = r === "enemy" ? "wc-enemy" : r === "target" ? "wc-target" : r === "from" || i ? "wc-from" : d ? "wc-location" : "";
	return /* @__PURE__ */ m("g", {
		ref: s,
		transform: `translate(${e.x} ${e.y})`,
		onClick: () => a(e.key),
		className: "cursor-pointer",
		children: [
			/* @__PURE__ */ p("polygon", {
				points: Je,
				className: `wc-hex ${h}`,
				strokeLinejoin: "round"
			}),
			r && /* @__PURE__ */ p("polygon", {
				points: Je,
				fill: "none",
				stroke: r === "enemy" ? "#c44d4b" : "#158b91",
				strokeWidth: .6,
				strokeDasharray: r === "enemy" ? "2 1" : void 0,
				transform: "scale(0.84)"
			}),
			d && /* @__PURE__ */ m("g", {
				transform: `rotate(${n})`,
				children: [
					/* @__PURE__ */ p("circle", {
						r: 5.3,
						className: "wc-location-mark",
						opacity: u === void 0 ? .17 : .26
					}),
					/* @__PURE__ */ p("circle", {
						r: 3.8,
						fill: "none",
						stroke: "#6b9a5f",
						strokeWidth: .5
					}),
					/* @__PURE__ */ p("path", {
						d: "M0-3 1-1 3 0 1 1 0 3-1 1-3 0-1-1Z",
						fill: "#61945b"
					})
				]
			}),
			u !== void 0 && /* @__PURE__ */ p("g", {
				transform: `rotate(${n})`,
				children: /* @__PURE__ */ p("path", {
					d: "M4.2 3.1h3.8v4.6l-1.9 1-1.9-1Z",
					fill: Be[u],
					stroke: "#fff0ce",
					strokeWidth: .65
				})
			}),
			l && /* @__PURE__ */ m("g", {
				transform: `rotate(${n})`,
				children: [
					/* @__PURE__ */ p("circle", {
						cy: .3,
						r: 6.5,
						fill: "#684222",
						stroke: "#e5bd75",
						strokeWidth: .7
					}),
					/* @__PURE__ */ p("circle", {
						r: 5.6,
						fill: Be[l.side],
						className: "wc-unit-coin"
					}),
					/* @__PURE__ */ p("circle", {
						r: 4.7,
						className: "wc-unit-ring"
					}),
					/* @__PURE__ */ p("g", {
						transform: "translate(-4.3 -4.3) scale(.215)",
						className: "wc-unit-mark",
						children: /* @__PURE__ */ p(Z, { coin: l.unit })
					}),
					l.stack > 1 && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
						cx: -5.4,
						cy: 5.4,
						r: 2.7,
						fill: "#3d291c"
					}), /* @__PURE__ */ p("text", {
						x: -5.4,
						y: 6.6,
						textAnchor: "middle",
						fontSize: 4.4,
						fill: "#fff5d3",
						className: "font-mono",
						"aria-hidden": !0,
						children: l.stack
					})] })
				]
			}),
			r && /* @__PURE__ */ p("text", {
				x: "0",
				y: l ? -7.3 : 1.4,
				textAnchor: "middle",
				className: `wc-target-mark ${r === "enemy" ? "wc-attack" : ""}`,
				transform: `rotate(${n})`,
				children: r === "enemy" ? "×" : r === "from" ? "◆" : "+"
			})
		]
	});
}
function Ze({ pub: e, mySide: t, nameOf: n, send: r }) {
	let i = u(), a = e.draft, o = a.turn === t;
	return /* @__PURE__ */ m("div", {
		className: "wc-draft",
		children: [/* @__PURE__ */ p("div", {
			className: "wc-draft-grid",
			children: a.pool.map((e) => /* @__PURE__ */ m("button", {
				type: "button",
				disabled: !o,
				onClick: () => r({
					type: "draft",
					unit: e
				}),
				className: "wc-draft-card",
				children: [/* @__PURE__ */ p(Z, { coin: e }), /* @__PURE__ */ m("span", {
					className: "min-w-0",
					children: [/* @__PURE__ */ p("span", {
						className: "wc-draft-name block truncate text-sm font-bold",
						children: i(z[e].nameKey)
					}), /* @__PURE__ */ m("span", {
						className: "wc-draft-info block text-[10px] leading-tight opacity-70",
						children: [
							i("games.warchest.coinTotal", { n: z[e].coins }),
							" · ",
							i(z[e].infoKey)
						]
					})]
				})]
			}, e))
		}), [0, 1].map((e) => /* @__PURE__ */ m("div", {
			className: "wc-draft-picks",
			children: [/* @__PURE__ */ p("p", {
				className: "font-bold",
				children: n(e)
			}), /* @__PURE__ */ m("div", {
				className: "flex flex-wrap gap-1.5",
				children: [a.picks[e].length === 0 && /* @__PURE__ */ p("span", {
					className: "text-xs opacity-50",
					children: "—"
				}), a.picks[e].map((e) => /* @__PURE__ */ p("span", {
					className: "wc-sheet-card text-xs font-bold",
					children: i(z[e].nameKey)
				}, e))]
			})]
		}, e))]
	});
}
function Qe({ rid: e, mine: t, side: n, label: r, active: i, initiative: a, claimed: o, markers: s, bag: l, hand: d }) {
	let { ref: f } = c(`seat:${e}`), h = u();
	return /* @__PURE__ */ m("div", {
		ref: f,
		className: `wc-seat ${t ? "wc-seat--bottom" : "wc-seat--top"}`,
		children: [
			/* @__PURE__ */ m("span", {
				className: "wc-seat-name",
				style: { backgroundColor: Be[n] },
				children: [i ? "◆ " : "", r]
			}),
			/* @__PURE__ */ m("span", {
				className: "wc-progress",
				"aria-label": h("games.warchest.markerCount", { n: s }),
				children: [Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ p("i", { className: t < 6 - s ? "wc-filled" : "" }, t)), /* @__PURE__ */ p("b", {
					className: "font-mono tabular-nums",
					children: s
				})]
			}),
			/* @__PURE__ */ p("span", { className: "wc-seat-spacer" }),
			a && /* @__PURE__ */ p("span", {
				className: "wc-initiative",
				"aria-label": `${h("games.warchest.initiativeAria")} · ${h(o ? "games.warchest.initiativeSpent" : "games.warchest.initiativeReady")}`,
				title: h(o ? "games.warchest.initiativeSpent" : "games.warchest.initiativeReady"),
				children: o ? "◇" : "✦"
			}),
			/* @__PURE__ */ p("span", {
				className: "wc-seat-stat",
				title: h("games.warchest.bagCount", { n: l }),
				children: h("games.warchest.bagShort", { n: l })
			}),
			/* @__PURE__ */ p("span", {
				className: "wc-seat-stat",
				title: h("games.warchest.handCount", { n: d }),
				children: h("games.warchest.handShort", { n: d })
			})
		]
	});
}
function $e({ hand: e, sel: t, priestIdx: n, disabled: r, onSelect: i }) {
	let { ref: a } = c("hand"), o = u();
	return /* @__PURE__ */ m("div", {
		ref: a,
		className: "wc-hand",
		children: [e.length === 0 && /* @__PURE__ */ p("span", {
			className: "text-xs font-bold opacity-50",
			children: o("games.warchest.handEmpty")
		}), e.map((e, a) => {
			let s = !r && (n === null || a === n);
			return /* @__PURE__ */ p("button", {
				type: "button",
				disabled: !s,
				onClick: () => s && i(a),
				"aria-label": o(e === "royal" ? "games.warchest.royalCoin" : z[e].nameKey),
				className: `wc-coin ${e === "royal" ? "wc-coin--royal" : ""} ${t === a ? "wc-selected" : ""}`,
				children: /* @__PURE__ */ p(Z, { coin: e })
			}, a);
		})]
	});
}
var et = {
	deploy: "games.warchest.act.deploy",
	bolster: "games.warchest.act.bolster",
	move: "games.warchest.act.move",
	control: "games.warchest.act.control",
	attack: "games.warchest.act.attack",
	tactic: "games.warchest.act.tactic"
}, tt = {
	deploy: "⬡",
	bolster: "⛨",
	move: "➜",
	control: "⚑",
	attack: "⚔",
	tactic: "✶"
};
function nt({ t: e, pending: t, acts: n, act: r, selCoin: i, acting: a, waitingText: o, footmanCount: s, canSeize: c, canRecruit: l, onAct: u, onSeize: d, onRecruit: f, onPass: h, onRg: g, onEndPending: _, onFootmanDone: ee }) {
	return t?.kind === "rgdefend" ? /* @__PURE__ */ m("div", {
		className: "wc-tray-hint",
		children: [/* @__PURE__ */ p("button", {
			type: "button",
			onClick: () => g(!0),
			children: e("games.warchest.rgYes")
		}), /* @__PURE__ */ p("button", {
			type: "button",
			onClick: () => g(!1),
			children: e("games.warchest.rgNo")
		})]
	}) : t && t.kind !== "priest" ? /* @__PURE__ */ m("div", {
		className: "wc-tray-hint",
		children: [/* @__PURE__ */ p("span", {
			className: "text-xs font-bold opacity-70",
			children: e("games.warchest.maneuverHint")
		}), /* @__PURE__ */ p("button", {
			type: "button",
			onClick: _,
			children: e("games.warchest.act.skip")
		})]
	}) : r === "tactic" && s > 0 ? /* @__PURE__ */ m("div", {
		className: "wc-tray-hint",
		children: [/* @__PURE__ */ p("span", {
			className: "text-xs font-bold opacity-70",
			children: e("games.warchest.footmanProgress", { n: s })
		}), /* @__PURE__ */ p("button", {
			type: "button",
			onClick: ee,
			children: e("games.warchest.act.done")
		})]
	}) : i === null || !a ? /* @__PURE__ */ p("div", {
		className: "wc-tray-hint",
		children: /* @__PURE__ */ p("span", {
			className: "text-xs font-bold opacity-70",
			children: a ? e("games.warchest.pickCoin") : o
		})
	}) : /* @__PURE__ */ m("div", {
		className: "wc-actions",
		children: [
			n.map((t) => /* @__PURE__ */ m("button", {
				type: "button",
				onClick: () => u(t),
				className: `wc-action ${r === t ? "wc-action--active" : ""}`,
				children: [/* @__PURE__ */ p("span", {
					className: "wc-action-symbol",
					"aria-hidden": !0,
					children: tt[t]
				}), e(et[t])]
			}, t)),
			c && /* @__PURE__ */ m("button", {
				type: "button",
				onClick: d,
				className: "wc-action",
				children: [/* @__PURE__ */ p("span", {
					className: "wc-action-symbol",
					"aria-hidden": !0,
					children: "✦"
				}), e("games.warchest.act.seize")]
			}),
			l && /* @__PURE__ */ m("button", {
				type: "button",
				onClick: f,
				className: "wc-action",
				children: [/* @__PURE__ */ p("span", {
					className: "wc-action-symbol",
					"aria-hidden": !0,
					children: "✚"
				}), e("games.warchest.act.recruit")]
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				onClick: h,
				className: "wc-action wc-action--quiet",
				children: [/* @__PURE__ */ p("span", {
					className: "wc-action-symbol",
					"aria-hidden": !0,
					children: "⊘"
				}), e("games.warchest.act.pass")]
			})
		]
	});
}
function rt({ open: e, log: t, nameOf: n, onClose: r }) {
	let i = u();
	return /* @__PURE__ */ p(s, {
		open: e,
		onClose: r,
		label: i("games.warchest.logTitle"),
		children: /* @__PURE__ */ m("div", {
			className: "wc-sheet wc-log flex flex-col gap-1 px-1 py-1",
			children: [t.length === 0 && /* @__PURE__ */ p("p", {
				className: "text-xs opacity-60",
				children: i("games.warchest.logEmpty")
			}), [...t].reverse().map((e, t) => /* @__PURE__ */ p("p", {
				className: "wc-log-entry text-xs leading-snug",
				children: He(i, e, n)
			}, t))]
		})
	});
}
function it({ cell: e, pub: t, nameOf: n, onClose: r }) {
	let i = u(), a = e ? re(e) : void 0, o = e ? t.units[e] : void 0, c = e ? t.control[e] : void 0;
	return /* @__PURE__ */ p(s, {
		open: e !== null,
		onClose: r,
		label: o ? i(z[o.unit].nameKey) : a?.loc ? i("games.warchest.locTitle", { loc: a.loc }) : "",
		children: /* @__PURE__ */ m("div", {
			className: "wc-sheet flex flex-col gap-2 px-1 py-1 text-sm",
			children: [o && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("p", {
				className: "flex items-center gap-2 font-bold",
				children: [
					/* @__PURE__ */ p(Z, {
						coin: o.unit,
						className: "size-7"
					}),
					n(o.side),
					o.stack > 1 && /* @__PURE__ */ m("span", {
						className: "rounded bg-ink px-1.5 font-mono text-xs text-white tabular-nums",
						children: ["×", o.stack]
					})
				]
			}), /* @__PURE__ */ p("p", {
				className: "text-xs leading-snug opacity-80",
				children: i(z[o.unit].infoKey)
			})] }), a?.loc && /* @__PURE__ */ m("p", {
				className: "text-xs opacity-80",
				children: [
					"✥ ",
					i("games.warchest.locInfo"),
					c === void 0 ? ` · ${i("games.warchest.locNeutral")}` : ` · ${i("games.warchest.locControlled", { name: n(c) })}`
				]
			})]
		})
	});
}
function at({ open: e, pub: t, priv: n, mySide: r, nameOf: i, onClose: a }) {
	let o = u();
	return /* @__PURE__ */ p(s, {
		open: e,
		onClose: a,
		label: o("games.warchest.armyTitle"),
		children: /* @__PURE__ */ m("div", {
			className: "wc-sheet wc-army flex flex-col gap-3 px-1 py-1",
			children: [/* @__PURE__ */ m("p", {
				className: "wc-sheet-card text-xs font-bold",
				children: [
					o("games.warchest.initiativeHolder", { name: i(t.initiative) }),
					" · ",
					o(t.initiativeClaimed ? "games.warchest.initiativeSpent" : "games.warchest.initiativeReady")
				]
			}), [0, 1].map((e) => /* @__PURE__ */ m("div", { children: [
				/* @__PURE__ */ m("p", {
					className: "mb-1 text-sm font-black",
					children: [
						i(e),
						" · ",
						o("games.warchest.bagCount", { n: t.bags[e] })
					]
				}),
				/* @__PURE__ */ p("div", {
					className: "flex flex-col gap-1.5",
					children: t.armies[e].map((n) => /* @__PURE__ */ m("div", {
						className: "wc-sheet-card flex items-start gap-2",
						children: [/* @__PURE__ */ p(Z, {
							coin: n,
							className: "size-7 flex-none"
						}), /* @__PURE__ */ m("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ m("p", {
								className: "text-xs font-bold",
								children: [o(z[n].nameKey), /* @__PURE__ */ m("span", {
									className: "ml-1.5 font-mono opacity-60",
									children: [
										o("games.warchest.supplyCount", { n: t.supply[e][n] ?? 0 }),
										" / ",
										o("games.warchest.coinTotal", { n: z[n].coins })
									]
								})]
							}), /* @__PURE__ */ p("p", {
								className: "wc-unit-info text-[10px] leading-snug opacity-70",
								children: o(z[n].infoKey)
							})]
						})]
					}, n))
				}),
				/* @__PURE__ */ p("p", {
					className: "mt-2 text-xs font-bold",
					children: o("games.warchest.faceUpDiscard", { n: t.discUp[e].length })
				}),
				/* @__PURE__ */ p(ot, { coins: t.discUp[e] }),
				/* @__PURE__ */ p("p", {
					className: "mt-2 text-xs font-bold",
					children: o("games.warchest.faceDownDiscard", { n: t.discDownCounts[e] })
				}),
				e === r ? /* @__PURE__ */ p(ot, { coins: n?.discDown ?? [] }) : /* @__PURE__ */ p("p", {
					className: "text-xs opacity-70",
					children: o("games.warchest.hiddenDiscard")
				})
			] }, e))]
		})
	});
}
function ot({ coins: e }) {
	let t = u();
	return /* @__PURE__ */ p("div", {
		className: "wc-coin-list flex flex-wrap gap-1",
		children: e.length === 0 ? /* @__PURE__ */ p("span", {
			className: "text-xs opacity-50",
			children: "—"
		}) : e.map((e, n) => /* @__PURE__ */ m("span", {
			className: "wc-sheet-card inline-flex items-center gap-1 text-xs",
			children: [/* @__PURE__ */ p(Z, {
				coin: e,
				className: "size-4"
			}), t(e === "royal" ? "games.warchest.royalCoin" : z[e].nameKey)]
		}, `${e}-${n}`))
	});
}
function st({ open: e, pub: t, mySide: n, onPick: r, onClose: i }) {
	let a = u(), o = Object.keys(t.supply[n]).filter((e) => (t.supply[n][e] ?? 0) > 0);
	return /* @__PURE__ */ p(s, {
		open: e,
		onClose: i,
		label: a("games.warchest.recruitTitle"),
		children: /* @__PURE__ */ p("div", {
			className: "wc-sheet wc-recruit grid grid-cols-2 gap-2 px-1 py-1",
			children: o.map((e) => /* @__PURE__ */ m("button", {
				type: "button",
				onClick: () => r(e),
				className: "wc-sheet-card flex min-h-12 cursor-pointer items-center gap-2 text-left",
				children: [/* @__PURE__ */ p(Z, {
					coin: e,
					className: "size-8 flex-none"
				}), /* @__PURE__ */ m("span", {
					className: "min-w-0",
					children: [/* @__PURE__ */ p("span", {
						className: "block truncate text-sm font-bold",
						children: a(z[e].nameKey)
					}), /* @__PURE__ */ m("span", {
						className: "wc-supply-count block font-mono text-[10px] opacity-60",
						children: ["×", t.supply[n][e]]
					})]
				})]
			}, e))
		})
	});
}
//#endregion
//#region src/games/warchest/bot.ts
function ct(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Q = {
	cavalry: 9,
	lancer: 8,
	crossbowman: 8,
	archer: 7,
	knight: 7,
	swordsman: 6,
	pikeman: 6,
	berserker: 5,
	warriorpriest: 5,
	royalguard: 5,
	footman: 4,
	marshall: 4,
	ensign: 4,
	lightcavalry: 4,
	mercenary: 3,
	scout: 2
}, lt = O.filter((e) => e.loc !== void 0).map((e) => e.key);
function $(e, t, n) {
	let r = 99;
	for (let i of lt) e.control[i] !== t && (r = Math.min(r, N(n, i)));
	return r;
}
function ut(e, t, n) {
	let r = e.units[t], i = e.units[n];
	if (!r || !i) return 0;
	let a = 50 + Q[i.unit] * 2;
	return i.stack === 1 && (a += 80), i.unit === "pikeman" && (a -= r.stack === 1 ? 70 : 25), i.unit === "royalguard" && (e.supply[i.side].royalguard ?? 0) > 0 && (a -= i.stack === 1 ? 30 : 0), A.has(n) && e.control[n] === i.side && (a += 15), a;
}
function dt(e, t, n, r, i) {
	let a = {
		units: e.units,
		control: e.control
	}, o = Object.keys(e.units).filter((n) => e.units[n].side === t);
	if (r !== "royal") {
		let s = r;
		if (o.filter((t) => e.units[t].unit === s).length < se(s)) for (let r of xe(a, t, s)) {
			let a = $(e, t, r);
			i.push({
				action: {
					type: "deploy",
					hand: n,
					cell: r
				},
				score: 30 + Math.max(0, 10 - a) * 4 + Q[s]
			});
		}
		for (let r of o) {
			let a = e.units[r];
			if (a.unit !== s) continue;
			let o = a.stack === 1 ? 14 : 3;
			A.has(r) && (o += 4), (j.get(r) ?? []).some((n) => e.units[n] && e.units[n].side !== t) && (o += 4), i.push({
				action: {
					type: "bolster",
					hand: n,
					cell: r
				},
				score: o
			});
		}
	}
	for (let s of o) {
		let o = e.units[s];
		if (r === o.unit || r === "royal" && o.unit === "royalguard") {
			if (r !== "royal") {
				let r = $(e, t, s);
				for (let o of J(a, s)) {
					let a = $(e, t, o);
					i.push({
						action: {
							type: "move",
							hand: n,
							from: s,
							to: o
						},
						score: 25 + (r - a) * 15
					});
				}
				if (X(a, t, s)) {
					let r = e.control[s] === void 0 ? 0 : 30;
					i.push({
						action: {
							type: "control",
							hand: n,
							cell: s
						},
						score: e.markersLeft[t] === 1 ? 1e6 : 100 + r
					});
				}
				for (let r of Y(a, t, s)) i.push({
					action: {
						type: "attack",
						hand: n,
						from: s,
						target: r
					},
					score: ut(e, s, r)
				});
			}
			switch (o.unit) {
				case "archer":
					if (r !== "archer") break;
					for (let r of Object.keys(e.units)) {
						let a = e.units[r];
						a.side !== t && N(s, r) === 2 && (a.unit === "knight" && o.stack < 2 || i.push({
							action: {
								type: "tactic",
								hand: n,
								from: s,
								target: r
							},
							score: ut(e, s, r) + 5
						}));
					}
					break;
				case "crossbowman":
					if (r !== "crossbowman") break;
					for (let r of Object.keys(e.units)) {
						let a = e.units[r];
						if (a.side === t) continue;
						let c = P(s, r);
						if (c === null || c < 2) continue;
						let l = F(s, r);
						l && l.some((t) => e.units[t]) || a.unit === "knight" && o.stack < 2 || i.push({
							action: {
								type: "tactic",
								hand: n,
								from: s,
								target: r
							},
							score: ut(e, s, r) + 5
						});
					}
					break;
				case "cavalry":
					if (r !== "cavalry") break;
					for (let r of J(a, s)) for (let a of j.get(r) ?? []) {
						let c = e.units[a];
						if (!c || c.side === t || c.unit === "knight" && o.stack < 2) continue;
						let l = $(e, t, s) - $(e, t, r);
						i.push({
							action: {
								type: "tactic",
								hand: n,
								from: s,
								to: r,
								target: a
							},
							score: ut(e, r, a) + 10 + l * 6
						});
					}
					break;
				case "lancer":
					if (r !== "lancer") break;
					for (let r of O) {
						let a = P(s, r.key);
						if (a === null || a > 2 || e.units[r.key]) continue;
						let c = F(s, r.key);
						if (c && !c.some((t) => e.units[t])) for (let a of j.get(r.key) ?? []) {
							let c = e.units[a];
							if (!c || c.side === t || c.unit === "knight" && o.stack < 2) continue;
							let l = $(e, t, s) - $(e, t, r.key);
							i.push({
								action: {
									type: "tactic",
									hand: n,
									from: s,
									to: r.key,
									target: a
								},
								score: ut(e, r.key, a) + 10 + l * 6
							});
						}
					}
					break;
				case "royalguard":
					if (r !== "royal") break;
					for (let r of J(a, s)) {
						let a = $(e, t, s) - $(e, t, r);
						i.push({
							action: {
								type: "tactic",
								hand: n,
								from: s,
								to: r
							},
							score: 10 + a * 8
						});
					}
			}
		}
	}
	e.initiative !== t && !e.initiativeClaimed && i.push({
		action: {
			type: "seize",
			hand: n
		},
		score: 9 - (r === "royal" ? 2 : Q[r]) * .5
	});
	let s = Object.keys(e.supply[t]).filter((n) => (e.supply[t][n] ?? 0) > 0);
	if (s.length > 0) {
		let r = s.reduce((n, r) => {
			let i = (n) => Object.values(e.units).filter((e) => e.side === t && e.unit === n).length;
			return Q[r] - i(r) * 2 > Q[n] - i(n) * 2 ? r : n;
		});
		i.push({
			action: {
				type: "recruit",
				hand: n,
				take: r
			},
			score: 10
		});
	}
	i.push({
		action: {
			type: "pass",
			hand: n
		},
		score: 3 - (r === "royal" ? 2 : Q[r]) * .2
	});
}
function ft(e, t, n, r) {
	let i = {
		units: e.units,
		control: e.control
	}, a = [], o = e.units[n];
	if (!o) return a;
	if (r.includes("attack") && o.unit !== "archer") for (let r of Y(i, t, n)) a.push({
		action: {
			type: "maneuver",
			attack: r
		},
		score: ut(e, n, r)
	});
	if (r.includes("control") && X(i, t, n) && a.push({
		action: {
			type: "maneuver",
			control: !0
		},
		score: e.markersLeft[t] === 1 ? 1e6 : 100
	}), r.includes("move")) {
		let r = $(e, t, n);
		for (let o of J(i, n)) a.push({
			action: {
				type: "maneuver",
				move: o
			},
			score: 8 + (r - $(e, t, o)) * 8
		});
	}
	return a;
}
var pt = (e) => e.length === 0 ? null : e.reduce((e, t) => t.score > e.score ? t : e), mt = (e, t) => {
	let n = e.public, r = e.private, i = n.seats.indexOf(t.rid);
	if (i < 0 || !r || n.winner !== null) return null;
	let a = t.difficulty === "weak", o = (e) => e.length === 0 ? null : a ? ct(e) : pt(e);
	if (n.phase === "draft") return !n.draft || n.draft.turn !== i ? null : { action: {
		type: "draft",
		unit: a ? ct(n.draft.pool) : n.draft.pool.reduce((e, t) => Q[t] > Q[e] ? t : e)
	} };
	if (n.phase !== "play") return null;
	let s = n.pending;
	if (s && s.side === i) switch (s.kind) {
		case "rgdefend": return { action: {
			type: "rgDefend",
			use: a ? n.units[s.cell]?.stack === 1 : (n.units[s.cell]?.stack ?? 0) === 1
		} };
		case "priest": {
			let e = r.hand[s.coinIdx];
			if (e === void 0) return null;
			let t = [];
			dt(n, i, s.coinIdx, e, t);
			let c = o(t.filter((e) => e.action.type !== "pass"));
			return !c || !a && c.score < 8 ? { action: {
				type: "pass",
				hand: s.coinIdx
			} } : { action: c.action };
		}
		case "zerk": {
			let e = pt(ft(n, i, s.cell, ["attack", "control"]));
			return e && (a || e.score >= 100) ? { action: e.action } : { action: { type: "endPending" } };
		}
		case "merc": {
			let e = o(ft(n, i, s.cell, [
				"attack",
				"control",
				"move"
			]).filter((e) => e.score > 0));
			return e ? { action: e.action } : { action: { type: "endPending" } };
		}
		case "sword": {
			let e = o(ft(n, i, s.cell, ["move"]).filter((e) => e.score > 8));
			return e ? { action: e.action } : { action: { type: "endPending" } };
		}
	}
	if (s || n.turn !== i) return null;
	let c = [];
	if (r.hand.forEach((e, t) => dt(n, i, t, e, c)), c.length === 0) return null;
	let l = o(c);
	return l ? { action: l.action } : null;
}, ht = (e, t, n) => {
	let r = (e) => e ? n(z[e].nameKey) : "", i = (e) => r(e ? t.public.units[e]?.unit : void 0), a = (e) => {
		let n = t.private?.hand[e];
		return n && n !== "royal" ? r(n) : "";
	};
	switch (e.type) {
		case "draft": return n("games.warchest.hintDraft", { unit: r(e.unit) });
		case "deploy": return n("games.warchest.hintDeploy", { unit: a(e.hand) });
		case "bolster": return n("games.warchest.hintBolster", { unit: a(e.hand) });
		case "seize": return n("games.warchest.hintSeize");
		case "recruit": return n("games.warchest.hintRecruit", { unit: r(e.take) });
		case "pass": return n("games.warchest.hintPass");
		case "move": return n("games.warchest.hintMove", { unit: i(e.from) });
		case "control": return n("games.warchest.hintControl", { unit: i(e.cell) });
		case "attack": return n("games.warchest.hintAttack", {
			unit: i(e.from),
			unit2: i(e.target)
		});
		case "tactic": return n("games.warchest.hintTactic", { unit: i(e.from) });
		case "maneuver": return n("games.warchest.hintManeuver");
		case "endPending": return n("games.warchest.hintEndPending");
		case "rgDefend": return e.use ? n("games.warchest.hintRgYes") : n("games.warchest.hintRgNo");
	}
}, gt = (e) => e === "royal" || typeof e == "string" && e in z ? e : null, _t = (e, t) => t && t !== e.myRid ? `seat:${t}` : "hand", vt = (e) => e === 0 || e === 1 ? e : null;
function yt({ coin: e, side: t = null, size: n }) {
	let r = gt(e);
	return /* @__PURE__ */ p("span", {
		"aria-hidden": !0,
		className: `wc-coin wc-coin--fx ${t === 0 ? "wc-coin--side-0" : t === 1 ? "wc-coin--side-1" : ""}`,
		style: n === void 0 ? void 0 : {
			width: n,
			height: n
		},
		children: r && /* @__PURE__ */ p(Z, { coin: r })
	});
}
function bt(e) {
	let t = Math.min(e.w / 20, e.h / (10 * Math.sqrt(3))) * 13 || 42;
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - t) / 2,
		w: t,
		h: t
	};
}
var xt = (e) => Math.max(42, Math.min(96, e.h * .95)), St = (e) => Math.max(20, Math.min(52, bt(e).w * .55));
function Ct({ at: e, coin: t, side: n }) {
	let r = bt(e);
	return /* @__PURE__ */ p("div", {
		className: "wc-fx-land",
		style: {
			left: e.x + e.w / 2,
			top: e.y + e.h / 2,
			width: r.w,
			height: r.h
		},
		children: /* @__PURE__ */ p(yt, {
			coin: t,
			side: n,
			size: r.w
		})
	});
}
var wt = {
	draw(e, t) {
		let n = t.anchor(_t(t, e.rid));
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: 580
			})
		} : null;
	},
	draft(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || typeof n?.unit != "string" ? null : {
			ms: 900,
			node: /* @__PURE__ */ p(h, {
				at: r,
				ms: 850,
				children: /* @__PURE__ */ p(yt, {
					coin: n.unit,
					size: xt(r)
				})
			})
		};
	},
	deploy(e, t) {
		let n = e.data, r = typeof n?.cell == "string" ? t.anchor(`cell:${n.cell}`) : null;
		return r ? {
			ms: 340,
			node: /* @__PURE__ */ p(Ct, {
				at: r,
				coin: n?.unit,
				side: vt(n?.side)
			})
		} : null;
	},
	bolster(e, t) {
		let n = e.data, r = typeof n?.cell == "string" ? t.anchor(`cell:${n.cell}`) : null;
		return r ? {
			ms: 700,
			node: /* @__PURE__ */ p(_, {
				at: r,
				ms: 680
			})
		} : null;
	},
	move(e, t) {
		let n = e.data, r = typeof n?.from == "string" ? t.anchor(`cell:${n.from}`) : null, i = typeof n?.to == "string" ? t.anchor(`cell:${n.to}`) : null;
		if (!r || !i) return null;
		let a = bt(r), o = bt(i);
		return {
			ms: 380,
			node: /* @__PURE__ */ p(g, {
				from: a,
				to: o,
				ms: 360,
				children: /* @__PURE__ */ p(yt, {
					coin: n?.unit,
					side: vt(n?.side),
					size: a.w
				})
			})
		};
	},
	attack(e, t) {
		let n = e.data, r = typeof n?.target == "string" ? t.anchor(`cell:${n.target}`) : null;
		return r ? {
			ms: 900,
			node: /* @__PURE__ */ p(h, {
				at: r,
				ms: 850,
				children: /* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					className: "text-xl font-black text-red-700",
					style: { fontSize: St(r) },
					children: "✕"
				})
			})
		} : null;
	},
	control(e, t) {
		let n = e.data, r = typeof n?.cell == "string" ? t.anchor(`cell:${n.cell}`) : null;
		return r ? {
			ms: 900,
			node: /* @__PURE__ */ p(_, {
				at: r,
				ms: 880
			})
		} : null;
	},
	destroy(e, t) {
		let n = e.data, r = typeof n?.cell == "string" ? t.anchor(`cell:${n.cell}`) : null;
		return r ? {
			ms: 1e3,
			node: /* @__PURE__ */ p(h, {
				at: r,
				ms: 950,
				children: /* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					className: "text-xl font-black text-amber-950",
					style: { fontSize: St(r) },
					children: "◇"
				})
			})
		} : null;
	},
	seize(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ p(h, {
				at: n,
				ms: 760,
				children: /* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					className: "text-xl font-black text-amber-700",
					style: { fontSize: Math.max(20, Math.min(48, n.h * .6)) },
					children: "✦"
				})
			})
		} : null;
	},
	recruit(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return r ? {
			ms: 900,
			node: /* @__PURE__ */ p(h, {
				at: r,
				ms: 850,
				children: /* @__PURE__ */ p(yt, {
					coin: n?.unit,
					size: xt(r)
				})
			})
		} : null;
	},
	win(e, t) {
		let n = e.data, r = typeof n?.cell == "string" ? t.anchor(`cell:${n.cell}`) : null;
		return r ? {
			ms: 1400,
			node: /* @__PURE__ */ p(_, {
				at: r,
				ms: 1350
			})
		} : null;
	}
};
//#endregion
//#region src/games/warchest/endgame-review.tsx
function Tt({ board: e, renderResult: t, ...n }) {
	let s = u(), [c, l] = o(!0), [d, f] = o(null), h = a(null), g = a(null), _ = a(null);
	r(() => {
		if (!d) return;
		_.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let v = (e) => {
		f(null), l(e), requestAnimationFrame(() => (e ? h : g).current?.focus({ preventScroll: !0 }));
	}, b = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), ne = {
		...n,
		...b
	};
	return /* @__PURE__ */ m("div", {
		className: "warchest-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ p("div", {
				className: "warchest-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ p("div", {
				className: "warchest-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ m("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), v(!1));
					},
					className: "warchest-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ m("header", {
							className: "warchest-endgame-heading",
							children: [/* @__PURE__ */ m("div", {
								className: "warchest-endgame-brand",
								children: [/* @__PURE__ */ p("span", {
									"aria-hidden": "true",
									children: I.icon
								}), s(I.nameKey)]
							}), /* @__PURE__ */ p("button", {
								type: "button",
								ref: h,
								className: "btn-quiet",
								"aria-label": s("games.warchest.reviewHide"),
								title: s("games.warchest.reviewHide"),
								onClick: () => v(!1),
								children: /* @__PURE__ */ p(te, { size: 19 })
							})]
						}),
						/* @__PURE__ */ p("div", {
							className: "warchest-endgame-result",
							inert: d !== null,
							children: t(ne)
						}),
						d && /* @__PURE__ */ m("div", {
							className: "warchest-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ p("button", {
								type: "button",
								ref: _,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: s(d.label === "again" ? "games.warchest.reviewConfirmAgain" : "games.warchest.reviewConfirmLobby")
							}), /* @__PURE__ */ p("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), h.current?.focus({ preventScroll: !0 });
								},
								children: s("games.warchest.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "warchest-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ m("button", {
					type: "button",
					className: "btn-base",
					ref: g,
					onClick: () => v(!0),
					children: [
						/* @__PURE__ */ p(y, { size: 18 }),
						s("games.warchest.reviewShow"),
						/* @__PURE__ */ p(ee, { size: 18 })
					]
				})
			})
		]
	});
}
function Et({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: c, renderRowExtra: d, summary: h, navigation: g, content: _, afterRanking: ee, scoreUnit: y, rankOf: x }) {
	let S = u(), C = l((e) => e.locale), [w, T] = o({}), E = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? b(n, C) : e;
	}, D = (t, n) => x?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), O = e.ranking.some((t) => e.scores?.[t] !== void 0), k = (t, n) => /* @__PURE__ */ m("div", {
		className: "warchest-score-identity",
		children: [
			/* @__PURE__ */ m("span", {
				className: "warchest-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ p("span", {
					"aria-label": S("games.warchest.reviewWinner"),
					children: "♛ "
				}), O && D(t, n)]
			}),
			/* @__PURE__ */ m("span", {
				className: "warchest-score-name",
				children: [E(t), t === r && /* @__PURE__ */ p("small", { children: S("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ m("small", {
				className: "warchest-score-autopilot",
				children: [
					/* @__PURE__ */ p(v, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), A = (t) => e.ranking.map((n) => /* @__PURE__ */ p("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ m("div", {
		className: "warchest-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ p(ne, {}),
			g,
			/* @__PURE__ */ m("div", {
				className: "warchest-score-body",
				children: [
					h && /* @__PURE__ */ p("div", {
						className: "warchest-score-summary",
						children: h
					}),
					i !== void 0 && /* @__PURE__ */ p("p", {
						className: "warchest-score-hints",
						children: S("session.hint.usedCount", { n: i })
					}),
					_ ?? (c?.length ? /* @__PURE__ */ p("div", {
						className: "warchest-score-table-scroll",
						children: /* @__PURE__ */ m("table", {
							className: "warchest-score-table",
							"aria-label": S(I.nameKey),
							children: [
								/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { scope: "col" }), /* @__PURE__ */ p(f, { children: e.ranking.map((t, n) => /* @__PURE__ */ p("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: k(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ p("tbody", { children: c.map((e, t) => /* @__PURE__ */ m(n, { children: [/* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ m("button", {
										type: "button",
										"aria-expanded": !!w[t],
										onClick: () => T((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ p(te, { size: 15 }), e.label]
									}) : e.label
								}), A(e)] }), w[t] && e.details?.map((e, t) => /* @__PURE__ */ m("tr", {
									className: "warchest-score-sub",
									children: [/* @__PURE__ */ p("th", {
										scope: "row",
										children: e.label
									}), A(e)]
								}, t))] }, t)) }),
								O && /* @__PURE__ */ p("tfoot", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
									scope: "row",
									children: S("games.warchest.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ p("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ p("ol", {
						className: "warchest-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ m("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ m("div", {
								className: "warchest-score-rankline",
								children: [k(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ m("strong", {
									className: "warchest-score-points",
									children: [e.scores[t], y && /* @__PURE__ */ p("small", { children: y })]
								})]
							}), d?.(t)]
						}, t))
					})),
					ee,
					!!c?.length && d && /* @__PURE__ */ p("div", {
						className: "warchest-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ m("details", { children: [/* @__PURE__ */ p("summary", { children: E(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ m("footer", {
				className: "warchest-score-actions",
				children: [
					s && /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: S("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: S("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ p("p", { children: S("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/warchest/game-over.tsx
function Dt({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ p(Et, {
		hintCount: e,
		result: t,
		members: n,
		myRid: r,
		accent: I.accent,
		onPlayAgain: i,
		onBackToLobby: a
	});
}
function Ot(e) {
	return /* @__PURE__ */ p(Tt, {
		...e,
		board: /* @__PURE__ */ p(Ue, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ p(Dt, { ...e })
	});
}
//#endregion
//#region src/games/warchest/options.tsx
var kt = {
	random: "games.warchest.mode.random",
	draft: "games.warchest.mode.draft",
	tutorial: "games.warchest.mode.tutorial"
};
function At({ value: e, onChange: t }) {
	let n = u(), r = de.safeParse(e), i = r.success ? r.data : de.parse(void 0);
	return /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ p(S, {
			title: n("games.warchest.optMode"),
			columns: 3,
			children: [
				"random",
				"draft",
				"tutorial"
			].map((e) => /* @__PURE__ */ p(x, {
				name: "warchest-mode",
				value: e,
				checked: i.mode === e,
				label: n(kt[e]),
				accent: I.accent,
				onChange: () => t({
					...i,
					mode: e
				})
			}, e))
		}), /* @__PURE__ */ p("p", {
			className: "text-xs text-ink/60",
			children: n("games.warchest.optModeHint")
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/warchest/entry.tsx
var jt = {
	definition: Re,
	View: Ue,
	bot: mt,
	describe: ht,
	fx: wt,
	OverView: Ot,
	Options: At,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "战争之匣",
			desc: "双人袋构战棋:抽币用兵,部署兵种抢占位置点,放完最后一枚控制标记就获胜",
			rules: "目标:把自己的控制标记全部放上版图(占住位置点);放下最后一枚者立即获胜。\n准备:双方各带 4 个兵种(每个兵种 2 枚入袋、其余进供应堆)外加 1 枚皇家币入袋;双方起始各控制 2 个位置点。\n回合:双方轮流行动,每回合开始各从袋中抽 3 枚币(袋空把弃牌堆洗回)。\n双方轮流使用手中的硬币行动。一方用完手中硬币后，由另一方继续行动；双方都用完后，开始新回合，由持有先手标记的一方先行动。\n每步从手中选 1 枚币,三选一:\n· 放置(币面朝上):部署该兵种到己方控制且空的 1 个位置点;或加成己方同名单位(将硬币放入该单位的硬币堆中，堆叠单位更难被消灭)。\n面朝下弃置一枚硬币时，选择以下一项：\n· 夺取先手：本回合先手尚未转移，且你不是当前持有者时，可以取得先手标记。\n· 招募：从供应堆选择 1 枚硬币，公开后放入自己的弃牌堆。\n· 放弃：不执行其他操作。\n面朝上弃币进行机动：\n选择该币种的一个单位，执行移动1格、控制其所在位置点或攻击相邻敌方单位中的一项。具有战术的兵种也可以改为发动战术。\n战斗：受到攻击的单位须从自己的硬币堆顶部移除 1 枚硬币。该单位的硬币全部被移除时，单位离场。\n骑士只能被加成过的单位攻击;长枪兵受击时反伤攻击方。\n皇家卫队受击时,防守方可弃供应堆 1 枚皇家卫队币免伤。\n皇家币不能作为单位放到版图上。你可以用它发动皇家卫队的战术，使该单位移动1格；也可以将其背面朝上弃置，用来夺取先手、招募或放弃行动。",
			optMode: "开局方式",
			optModeHint: "随机:16 兵种各抽 4;轮抽:8 张候选按 1-2-2-2-1 轮流选,后选者拿先手;推荐:规则书首局固定阵",
			mode: {
				random: "随机阵容",
				draft: "轮抽阵容",
				tutorial: "首局推荐"
			},
			unit: {
				berserker: "狂战士",
				royalguard: "皇家卫队",
				scout: "侦察兵",
				knight: "骑士",
				marshall: "元帅",
				mercenary: "雇佣兵",
				ensign: "掌旗官",
				footman: "步兵",
				lancer: "长枪骑兵",
				cavalry: "骑兵",
				archer: "弓箭手",
				lightcavalry: "轻骑兵",
				pikeman: "长枪兵",
				warriorpriest: "战斗祭司",
				swordsman: "剑士",
				crossbowman: "弩手"
			},
			unitInfo: {
				berserker: "属性:机动后,可从堆上弃 1 枚币,让本单位立刻再做一次机动",
				royalguard: "战术(弃皇家币):移动 1 格。属性:受击时,可弃供应堆 1 枚皇家卫队币抵消",
				scout: "属性:可部署到任意友军单位的相邻空格(不限位置点)",
				knight: "属性:只能被加成过的单位(堆叠 ≥2)攻击",
				marshall: "战术:2 格内的 1 个友军单位立即进行一次普通攻击",
				mercenary: "属性:你招募雇佣兵币时,可让你已在场上的 1 个雇佣兵单位立刻免费机动一次",
				ensign: "战术:2 格内的 1 个友军单位普通移动到掌旗官 2 格内的格",
				footman: "可部署 2 个。战术:每个己方步兵各进行一次机动",
				lancer: "战术:直线移动 1-2 格,然后攻击落点相邻的 1 个敌单位",
				cavalry: "战术:移动 1 格,然后攻击落点相邻的 1 个敌单位",
				archer: "战术:攻击恰好 2 格外的 1 个敌单位(中间可有单位)。弓箭手不能普通攻击",
				lightcavalry: "战术:恰好移动 2 格(可转向)",
				pikeman: "属性:受击时,攻击方同时移除堆上 1 枚币",
				warriorpriest: "属性:攻击或控制后,抽 1 枚币并立刻使用它",
				swordsman: "属性:攻击后,可再移动 1 格",
				crossbowman: "战术:直线攻击 2 格及以远的 1 个敌单位,中间格不能有单位"
			},
			roundChip: "第 {{n}} 回合",
			command: "指挥",
			logShort: "战报",
			armyShort: "军备",
			chooseAction: "选择一项命令",
			selectUnit: "点选要行动的己方单位",
			selectPath: "点选行进格",
			selectTarget: "点选高亮目标",
			coinTotal: "总币 {{n}}",
			supplyCount: "供应 {{n}}",
			bagCount: "袋内 {{n}}",
			handCount: "手中 {{n}}",
			bagShort: "袋 {{n}}",
			handShort: "手 {{n}}",
			markerCount: "剩余控制标记 {{n}}",
			initiativeReady: "本轮先手尚未转移",
			initiativeSpent: "本轮先手已转移",
			initiativeHolder: "先手: {{name}}",
			faceUpDiscard: "正面弃币 {{n}}",
			faceDownDiscard: "背面弃币 {{n}}",
			hiddenDiscard: "币种不公开",
			promptTurn: "你的回合:选一枚币行动",
			pickCoin: "点选一枚手币",
			waitTurn: "等 {{name}} 行动…",
			ended: "对局结束",
			draftPick: "轮到你选兵种",
			draftTray: "为你的军团征召兵种",
			handEmpty: "手币已空",
			royalCoin: "皇家币",
			boardAria: "六角格版图",
			initiativeAria: "持有先手标记",
			act: {
				deploy: "部署",
				bolster: "加成",
				move: "移动",
				control: "控制",
				attack: "攻击",
				tactic: "战术",
				seize: "夺先手",
				recruit: "招募",
				pass: "跳过",
				skip: "跳过",
				done: "完成"
			},
			pending: {
				zerk: "狂战士:可弃堆上 1 枚币再机动一次",
				priest: "战斗祭司:使用刚抽到的币(最右侧)",
				rgdefend: "皇家卫队受击:是否弃供应币抵消?",
				merc: "雇佣兵:可免费机动一次",
				sword: "剑士:可再移动 1 格"
			},
			pendingMay: "可选效果,可跳过",
			maneuverHint: "点版图执行机动,或",
			footmanProgress: "已排 {{n}} 个步兵机动",
			rgYes: "弃供应币抵消",
			rgNo: "硬抗",
			recruitTitle: "招募:从供应堆选 1 枚",
			armyTitle: "双方军团",
			armyAria: "查看双方军团",
			logTitle: "对局记录",
			logAria: "对局日志",
			logEmpty: "还没有记录",
			locTitle: "位置点 {{loc}}",
			locInfo: "单位站上后可弃同型币控制",
			locControlled: "{{name}} 控制中",
			locNeutral: "无人控制",
			log: {
				draft: "{{name}} 选了 {{unit}}",
				deploy: "{{name}} 部署 {{unit}}",
				bolster: "{{name}} 加成 {{unit}}",
				seize: "{{name}} 夺走了先手标记",
				recruit: "{{name}} 招募 {{unit}}",
				move: "{{name}} 移动 {{unit}}",
				control: "{{name}} 控制了一个位置点({{unit}})",
				attack: "{{name}} 的 {{unit}} 攻击 {{unit2}}",
				tactic: "{{name}} 发动 {{unit}} 战术",
				destroy: "{{name}} 的 {{unit}} 被消灭",
				round: "—— 第 {{n}} 回合 ——",
				win: "{{name}} 放下最后一枚控制标记,获胜!",
				deadlock: "双方币尽:按控制标记判定,{{name}} 获胜"
			},
			hintDraft: "选 {{unit}}",
			hintDeploy: "部署 {{unit}} 到高亮位置点",
			hintBolster: "加成 {{unit}}",
			hintSeize: "弃币夺走先手标记",
			hintRecruit: "弃币招募 {{unit}}",
			hintPass: "弃币跳过",
			hintMove: "移动 {{unit}} 1 格",
			hintControl: "用 {{unit}} 控制所站位置点",
			hintAttack: "用 {{unit}} 攻击 {{unit2}}",
			hintTactic: "发动 {{unit}} 的战术",
			hintManeuver: "执行这次免费机动",
			hintEndPending: "放弃这次可选机动",
			hintRgYes: "弃供应币保住皇家卫队",
			hintRgNo: "硬抗这次攻击",
			errTurn: "还没轮到你",
			errOver: "对局已结束",
			errPending: "需先完成当前结算",
			errHand: "这枚币现在不能用",
			errCell: "无效的目标格",
			errNoUnit: "这里没有你的单位",
			errOccupied: "目标格已被占据",
			errNoControl: "只能部署到己方控制的空位置点",
			errDup: "该兵种在场数量已达上限",
			errKnight: "骑士只能被加成过的单位攻击",
			errSeize: "现在不能夺取先手",
			errSupply: "供应堆没有这种币",
			errTactic: "战术目标不合法",
			errCoin: "币与单位不匹配",
			errArcher: "弓箭手只能用战术攻击",
			errControl: "不能控制这个位置点",
			errMove: "不能移动到这里",
			errDraft: "现在不能选这张"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "War Chest",
			desc: "2-player bag-building tactics: draft coins, command units, seize locations — place your last control marker to win",
			rules: "Goal: place all of your control markers onto location points; placing your last marker wins immediately.\nSetup: each player brings 4 unit types (2 coins of each into your bag, the rest to your supply) plus 1 royal coin; each side starts controlling 2 locations.\nRounds: at the start of each round both players draw 3 coins from their bag (reshuffle discards when empty).\nTake turns spending one coin per action; when you run out, play passes; when both are out, a new round begins and the initiative holder acts first.\nOn your turn, spend one coin:\n· Face up — deploy: place that unit on an empty location you control; or bolster: add the coin under a matching unit (stacked units are harder to destroy).\nDiscard a coin face down to choose one action:\n· Seize initiative: Take the initiative marker if it has not changed hands this round and you do not already hold it.\n· Recruit: Take 1 coin from the supply and place it in your face-up discard pile.\n· Pass: Take no further action.\nDiscard a coin face up to maneuver:\nChoose one unit of that type to move 1 space, control its current location or attack an adjacent enemy unit. A unit with a tactic may use it instead.\nCombat: the defender removes 1 coin from its stack; a unit with no coins left is destroyed.\nKnights can only be attacked by bolstered units; pikemen deal a counter-hit to the attacker.\nWhen a Royal Guard is hit, its owner may discard a Royal Guard coin from supply to negate it.\nA Royal coin cannot be deployed as a unit. You may spend it to use the Royal Guard tactic and move that unit 1 space, or discard it face down to seize initiative, recruit, or pass.",
			optMode: "Setup mode",
			optModeHint: "Random: 4 of 16 units each; Draft: snake-pick from 8 (1-2-2-2-1), second picker gets initiative; Tutorial: fixed starter armies",
			mode: {
				random: "Random",
				draft: "Draft",
				tutorial: "Starter"
			},
			unit: {
				berserker: "Berserker",
				royalguard: "Royal Guard",
				scout: "Scout",
				knight: "Knight",
				marshall: "Marshal",
				mercenary: "Mercenary",
				ensign: "Ensign",
				footman: "Footman",
				lancer: "Lancer",
				cavalry: "Cavalry",
				archer: "Archer",
				lightcavalry: "Light Cavalry",
				pikeman: "Pikeman",
				warriorpriest: "Warrior Priest",
				swordsman: "Swordsman",
				crossbowman: "Crossbowman"
			},
			unitInfo: {
				berserker: "Attribute: after it maneuvers, you may discard 1 coin from its stack to maneuver it again",
				royalguard: "Tactic (discard a royal coin): move 1 space. Attribute: when hit, you may discard a Royal Guard coin from supply to negate it",
				scout: "Attribute: may deploy to any empty space adjacent to a friendly unit (not only locations)",
				knight: "Attribute: can only be attacked by bolstered units (stack of 2+)",
				marshall: "Tactic: a friendly unit within 2 spaces makes a normal attack",
				mercenary: "Attribute: when you recruit a Mercenary coin, one of your Mercenary units already on the board may immediately maneuver for free",
				ensign: "Tactic: a friendly unit within 2 spaces moves normally to a space within 2 of the Ensign",
				footman: "You may deploy 2. Tactic: each of your Footmen performs one maneuver",
				lancer: "Tactic: move 1-2 spaces in a straight line, then attack an enemy adjacent to the landing space",
				cavalry: "Tactic: move 1 space, then attack an enemy adjacent to the landing space",
				archer: "Tactic: attack an enemy exactly 2 spaces away (units may block). Archers cannot attack normally",
				lightcavalry: "Tactic: move exactly 2 spaces (may turn)",
				pikeman: "Attribute: when hit, the attacker also removes 1 coin from its stack",
				warriorpriest: "Attribute: after it attacks or controls, draw 1 coin and use it immediately",
				swordsman: "Attribute: after it attacks, it may move 1 space",
				crossbowman: "Tactic: attack an enemy 2+ spaces away in a straight line with no units in between"
			},
			roundChip: "Round {{n}}",
			command: "COMMAND",
			logShort: "Log",
			armyShort: "Army",
			chooseAction: "Choose a command",
			selectUnit: "Select your unit",
			selectPath: "Select a path space",
			selectTarget: "Select a highlighted target",
			coinTotal: "{{n}} total coins",
			supplyCount: "Supply {{n}}",
			bagCount: "Bag {{n}}",
			handCount: "Hand {{n}}",
			bagShort: "Bag {{n}}",
			handShort: "Hand {{n}}",
			markerCount: "{{n}} control markers left",
			initiativeReady: "Initiative has not changed this round",
			initiativeSpent: "Initiative has changed this round",
			initiativeHolder: "Initiative: {{name}}",
			faceUpDiscard: "Face-up discard {{n}}",
			faceDownDiscard: "Face-down discard {{n}}",
			hiddenDiscard: "Coin types hidden",
			promptTurn: "Your turn: pick a coin",
			pickCoin: "Pick a coin from your hand",
			waitTurn: "Waiting for {{name}}…",
			ended: "Game over",
			draftPick: "Your pick",
			draftTray: "Muster your army",
			handEmpty: "Hand empty",
			royalCoin: "Royal coin",
			boardAria: "Hex board",
			initiativeAria: "Holds initiative",
			act: {
				deploy: "Deploy",
				bolster: "Bolster",
				move: "Move",
				control: "Control",
				attack: "Attack",
				tactic: "Tactic",
				seize: "Seize",
				recruit: "Recruit",
				pass: "Pass",
				skip: "Skip",
				done: "Done"
			},
			pending: {
				zerk: "Berserker: may discard a stack coin to maneuver again",
				priest: "Warrior Priest: use the drawn coin (rightmost)",
				rgdefend: "Royal Guard hit: spend a supply coin to negate?",
				merc: "Mercenary: may maneuver for free",
				sword: "Swordsman: may move 1 space"
			},
			pendingMay: "Optional — may skip",
			maneuverHint: "Tap the board to maneuver, or",
			footmanProgress: "{{n}} footman maneuver(s) queued",
			rgYes: "Spend supply coin",
			rgNo: "Take the hit",
			recruitTitle: "Recruit: pick 1 from supply",
			armyTitle: "Both armies",
			armyAria: "View both armies",
			logTitle: "Game log",
			logAria: "Game log",
			logEmpty: "Nothing yet",
			locTitle: "Location {{loc}}",
			locInfo: "A unit here may spend a matching coin to control it",
			locControlled: "Controlled by {{name}}",
			locNeutral: "Uncontrolled",
			log: {
				draft: "{{name}} picked {{unit}}",
				deploy: "{{name}} deployed {{unit}}",
				bolster: "{{name}} bolstered {{unit}}",
				seize: "{{name}} seized the initiative",
				recruit: "{{name}} recruited {{unit}}",
				move: "{{name}} moved {{unit}}",
				control: "{{name}} controlled a location ({{unit}})",
				attack: "{{name}}'s {{unit}} attacked {{unit2}}",
				tactic: "{{name}} used {{unit}} tactic",
				destroy: "{{name}}'s {{unit}} was destroyed",
				round: "—— Round {{n}} ——",
				win: "{{name}} placed the last control marker and wins!",
				deadlock: "Both out of coins: {{name}} wins on control markers"
			},
			hintDraft: "Pick {{unit}}",
			hintDeploy: "Deploy {{unit}} to a highlighted location",
			hintBolster: "Bolster {{unit}}",
			hintSeize: "Discard to seize the initiative",
			hintRecruit: "Discard to recruit {{unit}}",
			hintPass: "Discard to pass",
			hintMove: "Move {{unit}} 1 space",
			hintControl: "Control the location with {{unit}}",
			hintAttack: "Attack {{unit2}} with {{unit}}",
			hintTactic: "Use {{unit}} tactic",
			hintManeuver: "Take the free maneuver",
			hintEndPending: "Skip the optional maneuver",
			hintRgYes: "Spend a supply coin to save the Royal Guard",
			hintRgNo: "Take the hit",
			errTurn: "Not your turn",
			errOver: "The game is over",
			errPending: "Resolve the current effect first",
			errHand: "That coin cannot be used now",
			errCell: "Invalid target space",
			errNoUnit: "No unit of yours there",
			errOccupied: "That space is occupied",
			errNoControl: "Deploy only to an empty location you control",
			errDup: "Unit limit on board reached",
			errKnight: "Knights can only be attacked by bolstered units",
			errSeize: "Cannot seize the initiative now",
			errSupply: "No such coin in supply",
			errTactic: "Invalid tactic target",
			errCoin: "Coin does not match the unit",
			errArcher: "Archers can only attack via tactic",
			errControl: "Cannot control this location",
			errMove: "Cannot move there",
			errDraft: "Cannot pick that now"
		}
	}
};
//#endregion
export { jt as default };
