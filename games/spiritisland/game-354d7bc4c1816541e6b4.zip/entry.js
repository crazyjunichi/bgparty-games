import { z as e } from "zod";
import { randomIntAt as t } from "@bgparty/sdk/engine/prng";
import { useCallback as n, useEffect as r, useLayoutEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconCheck as u, IconClose as d, IconEffect as f, IconExpand as p, IconInfo as m, IconLog as h, IconPile as ee, IconRecenter as te, IconZoomIn as g, IconZoomOut as _ } from "@bgparty/sdk/icons";
import { GameScreen as v } from "@bgparty/sdk/ui/game-screen";
import * as y from "three";
import { useThree as ne } from "@react-three/fiber";
import { ResilientCanvas as re } from "@bgparty/sdk/three/resilient-canvas";
import { useFxAnchor as ie, useFxAnchorsMaybe as ae } from "@bgparty/sdk/fx/anchors";
import { PLAYER_COLORS as oe } from "@bgparty/sdk/player-colors";
import { Fragment as b, jsx as x, jsxs as S } from "react/jsx-runtime";
import { createPortal as se } from "react-dom";
import { Floater as ce, FlySprite as le } from "@bgparty/sdk/fx/primitives";
//#region src/games/spiritisland/meta.ts
var ue = {
	id: "spiritisland",
	tier: "beta",
	mechanics: ["engine-building", "hand-management"],
	interactionTags: ["cooperative"],
	nameKey: "games.spiritisland.name",
	descKey: "games.spiritisland.desc",
	rulesKey: "games.spiritisland.rules",
	icon: "🌋",
	iconImg: "games/spiritisland.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/spiritisland/en.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#0f766e",
	releasedAt: "2026-10-13",
	search: {
		py: "ling ji dao",
		init: "ljd"
	},
	hotseat: "open",
	precacheAssets: []
}, C = e.string(), w = e.string(), de = e.object({
	type: e.enum([
		"explorer",
		"town",
		"city",
		"dahan",
		"presence"
	]),
	seat: e.string().optional(),
	from: e.string().optional()
}), fe = e.union([
	e.string(),
	e.array(e.string()),
	e.array(de),
	e.boolean(),
	e.number()
]), pe = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("pickSpirit"),
		spirit: C
	}),
	e.object({
		type: e.literal("growth"),
		group: e.int().min(0)
	}),
	e.object({
		type: e.literal("play"),
		cards: e.array(w)
	}),
	e.object({
		type: e.literal("answer"),
		value: fe
	}),
	e.object({ type: e.literal("pass") }),
	e.object({
		type: e.literal("tick"),
		now: e.number()
	})
]), me = e.object({
	id: e.string(),
	board: e.string(),
	n: e.int(),
	terrain: e.string(),
	adj: e.array(e.string()),
	coastal: e.boolean(),
	explorers: e.int().nonnegative(),
	towns: e.int().nonnegative(),
	cities: e.int().nonnegative(),
	dahan: e.int().nonnegative(),
	blight: e.int().nonnegative(),
	presence: e.record(e.string(), e.int().nonnegative()),
	defend: e.int().nonnegative(),
	skipRavage: e.boolean(),
	skipBuild: e.boolean(),
	skipExplore: e.boolean(),
	isolate: e.boolean()
}), he = e.object({
	spirit: e.string(),
	board: e.string(),
	energy: e.int(),
	energyIdx: e.int(),
	playsIdx: e.int(),
	energyPerTurn: e.int(),
	playsPerTurn: e.int(),
	elements: e.object({
		counts: e.record(e.string(), e.int().nonnegative()),
		any: e.int().nonnegative()
	}),
	fastCards: e.array(w),
	rangeBonus: e.int(),
	innateLevels: e.record(e.string(), e.int().nonnegative()),
	hand: e.array(w),
	discard: e.array(w),
	played: e.array(w),
	forgotten: e.array(w),
	dead: e.boolean()
}), ge = e.object({
	kind: e.enum([
		"land",
		"pieces",
		"cards",
		"yesno",
		"number",
		"spirit",
		"track",
		"growth",
		"play",
		"pickSpirit"
	]),
	seat: e.string(),
	why: e.string(),
	legal: e.array(e.string()).optional(),
	cards: e.array(e.string()).optional(),
	spirits: e.array(e.string()).optional(),
	count: e.int().optional(),
	upto: e.boolean().optional(),
	min: e.int().optional(),
	max: e.int().optional(),
	land: e.string().optional(),
	pieces: e.array(de).optional(),
	shadows: e.array(e.string()).optional()
}), T = e.object({
	players: e.array(e.string()),
	boards: e.array(e.string()),
	lands: e.array(me),
	spirits: e.record(e.string(), he),
	phase: e.enum([
		"pick",
		"growth",
		"play",
		"fast",
		"invader",
		"slow",
		"cleanup",
		"over"
	]),
	round: e.int().min(1),
	pending: ge.nullable(),
	current: e.object({
		seat: e.string(),
		source: e.string(),
		kind: e.string(),
		target: e.string().optional()
	}).nullable(),
	invaderStep: e.int(),
	resolution: e.object({
		land: e.string(),
		kind: e.string(),
		source: e.string()
	}).optional(),
	invader: e.object({
		deckCount: e.int().nonnegative(),
		discard: e.array(e.string()),
		ravage: e.string().nullable(),
		build: e.string().nullable(),
		explore: e.string().nullable()
	}),
	fear: e.object({
		earned: e.int().nonnegative(),
		poolMax: e.int().nonnegative(),
		deckCount: e.int().nonnegative(),
		pending: e.array(e.string()),
		resolvedCount: e.int().nonnegative()
	}),
	blight: e.object({
		pool: e.int().nonnegative(),
		card: e.string(),
		flipped: e.boolean()
	}),
	terror: e.int().min(1).max(3),
	growthDone: e.record(e.string(), e.boolean()),
	playDone: e.record(e.string(), e.boolean()),
	over: e.object({
		win: e.boolean(),
		reason: e.string()
	}).nullable(),
	log: e.array(e.object({
		by: e.string(),
		text: e.string()
	}))
}), _e = e.object({}), ve = [
	{
		id: "A",
		lands: [
			{
				n: 1,
				terrain: "Mountain",
				adj: [
					2,
					4,
					5,
					6
				],
				adjAll: [
					0,
					2,
					4,
					5,
					6
				],
				init: {}
			},
			{
				n: 2,
				terrain: "Wetland",
				adj: [
					1,
					3,
					4
				],
				adjAll: [
					0,
					1,
					3,
					4
				],
				init: {
					dahan: 1,
					cities: 1
				}
			},
			{
				n: 3,
				terrain: "Jungle",
				adj: [2, 4],
				adjAll: [
					0,
					2,
					4
				],
				init: { dahan: 2 }
			},
			{
				n: 4,
				terrain: "Sands",
				adj: [
					1,
					2,
					3,
					5
				],
				adjAll: [
					1,
					2,
					3,
					5
				],
				init: { blight: 1 }
			},
			{
				n: 5,
				terrain: "Wetland",
				adj: [
					1,
					4,
					6,
					7,
					8
				],
				adjAll: [
					1,
					4,
					6,
					7,
					8
				],
				init: {}
			},
			{
				n: 6,
				terrain: "Mountain",
				adj: [
					1,
					5,
					8
				],
				adjAll: [
					1,
					5,
					8
				],
				init: { dahan: 1 }
			},
			{
				n: 7,
				terrain: "Sands",
				adj: [5, 8],
				adjAll: [5, 8],
				init: { dahan: 2 }
			},
			{
				n: 8,
				terrain: "Jungle",
				adj: [
					5,
					6,
					7
				],
				adjAll: [
					5,
					6,
					7
				],
				init: { towns: 1 }
			}
		],
		sides: [
			{
				side: 0,
				s: 0,
				e: 2,
				land: 1
			},
			{
				side: 0,
				s: 2,
				e: 4,
				land: 6
			},
			{
				side: 0,
				s: 4,
				e: 7,
				land: 8
			},
			{
				side: 1,
				s: 0,
				e: 3,
				land: 8
			},
			{
				side: 1,
				s: 3,
				e: 7,
				land: 7
			},
			{
				side: 2,
				s: 0,
				e: 1,
				land: 7
			},
			{
				side: 2,
				s: 1,
				e: 2,
				land: 5
			},
			{
				side: 2,
				s: 2,
				e: 4,
				land: 4
			},
			{
				side: 2,
				s: 4,
				e: 7,
				land: 3
			}
		]
	},
	{
		id: "B",
		lands: [
			{
				n: 1,
				terrain: "Wetland",
				adj: [
					2,
					4,
					5,
					6
				],
				adjAll: [
					0,
					2,
					4,
					5,
					6
				],
				init: { dahan: 1 }
			},
			{
				n: 2,
				terrain: "Mountain",
				adj: [
					1,
					3,
					4
				],
				adjAll: [
					0,
					1,
					3,
					4
				],
				init: { cities: 1 }
			},
			{
				n: 3,
				terrain: "Sands",
				adj: [2, 4],
				adjAll: [
					0,
					2,
					4
				],
				init: { dahan: 2 }
			},
			{
				n: 4,
				terrain: "Jungle",
				adj: [
					1,
					2,
					3,
					5,
					7
				],
				adjAll: [
					1,
					2,
					3,
					5,
					7
				],
				init: { blight: 1 }
			},
			{
				n: 5,
				terrain: "Sands",
				adj: [
					1,
					4,
					6,
					7
				],
				adjAll: [
					1,
					4,
					6,
					7
				],
				init: {}
			},
			{
				n: 6,
				terrain: "Wetland",
				adj: [
					1,
					5,
					7,
					8
				],
				adjAll: [
					1,
					5,
					7,
					8
				],
				init: { towns: 1 }
			},
			{
				n: 7,
				terrain: "Mountain",
				adj: [
					4,
					5,
					6,
					8
				],
				adjAll: [
					4,
					5,
					6,
					8
				],
				init: { dahan: 1 }
			},
			{
				n: 8,
				terrain: "Jungle",
				adj: [6, 7],
				adjAll: [6, 7],
				init: { dahan: 2 }
			}
		],
		sides: [
			{
				side: 0,
				s: 0,
				e: 1,
				land: 1
			},
			{
				side: 0,
				s: 1,
				e: 4,
				land: 6
			},
			{
				side: 0,
				s: 4,
				e: 7,
				land: 8
			},
			{
				side: 1,
				s: 0,
				e: 3,
				land: 8
			},
			{
				side: 1,
				s: 3,
				e: 7,
				land: 7
			},
			{
				side: 2,
				s: 0,
				e: 1,
				land: 7
			},
			{
				side: 2,
				s: 1,
				e: 3,
				land: 4
			},
			{
				side: 2,
				s: 3,
				e: 7,
				land: 3
			}
		]
	},
	{
		id: "C",
		lands: [
			{
				n: 1,
				terrain: "Jungle",
				adj: [
					2,
					5,
					6
				],
				adjAll: [
					0,
					2,
					5,
					6
				],
				init: { dahan: 1 }
			},
			{
				n: 2,
				terrain: "Sands",
				adj: [
					1,
					3,
					4,
					5
				],
				adjAll: [
					0,
					1,
					3,
					4,
					5
				],
				init: { cities: 1 }
			},
			{
				n: 3,
				terrain: "Mountain",
				adj: [2, 4],
				adjAll: [
					0,
					2,
					4
				],
				init: { dahan: 2 }
			},
			{
				n: 4,
				terrain: "Jungle",
				adj: [
					2,
					3,
					5,
					7
				],
				adjAll: [
					2,
					3,
					5,
					7
				],
				init: {}
			},
			{
				n: 5,
				terrain: "Wetland",
				adj: [
					1,
					2,
					4,
					6,
					7
				],
				adjAll: [
					1,
					2,
					4,
					6,
					7
				],
				init: {
					dahan: 2,
					blight: 1
				}
			},
			{
				n: 6,
				terrain: "Sands",
				adj: [
					1,
					5,
					7,
					8
				],
				adjAll: [
					1,
					5,
					7,
					8
				],
				init: { dahan: 1 }
			},
			{
				n: 7,
				terrain: "Mountain",
				adj: [
					4,
					5,
					6,
					8
				],
				adjAll: [
					4,
					5,
					6,
					8
				],
				init: { towns: 1 }
			},
			{
				n: 8,
				terrain: "Wetland",
				adj: [6, 7],
				adjAll: [6, 7],
				init: {}
			}
		],
		sides: [
			{
				side: 0,
				s: 0,
				e: 2,
				land: 1
			},
			{
				side: 0,
				s: 2,
				e: 4,
				land: 6
			},
			{
				side: 0,
				s: 4,
				e: 7,
				land: 8
			},
			{
				side: 1,
				s: 0,
				e: 4,
				land: 8
			},
			{
				side: 1,
				s: 4,
				e: 6,
				land: 7
			},
			{
				side: 1,
				s: 6,
				e: 7,
				land: 4
			},
			{
				side: 2,
				s: 0,
				e: 4,
				land: 4
			},
			{
				side: 2,
				s: 4,
				e: 7,
				land: 3
			}
		]
	},
	{
		id: "D",
		lands: [
			{
				n: 1,
				terrain: "Wetland",
				adj: [
					2,
					5,
					7,
					8
				],
				adjAll: [
					0,
					2,
					5,
					7,
					8
				],
				init: { dahan: 2 }
			},
			{
				n: 2,
				terrain: "Jungle",
				adj: [
					1,
					3,
					4,
					5
				],
				adjAll: [
					0,
					1,
					3,
					4,
					5
				],
				init: {
					dahan: 1,
					cities: 1
				}
			},
			{
				n: 3,
				terrain: "Wetland",
				adj: [2, 4],
				adjAll: [
					0,
					2,
					4
				],
				init: {}
			},
			{
				n: 4,
				terrain: "Sands",
				adj: [
					2,
					3,
					5,
					6
				],
				adjAll: [
					2,
					3,
					5,
					6
				],
				init: {}
			},
			{
				n: 5,
				terrain: "Mountain",
				adj: [
					1,
					2,
					4,
					6,
					7
				],
				adjAll: [
					1,
					2,
					4,
					6,
					7
				],
				init: {
					dahan: 1,
					blight: 1
				}
			},
			{
				n: 6,
				terrain: "Jungle",
				adj: [
					4,
					5,
					7
				],
				adjAll: [
					4,
					5,
					7
				],
				init: {}
			},
			{
				n: 7,
				terrain: "Sands",
				adj: [
					1,
					5,
					6,
					8
				],
				adjAll: [
					1,
					5,
					6,
					8
				],
				init: {
					dahan: 2,
					towns: 1
				}
			},
			{
				n: 8,
				terrain: "Mountain",
				adj: [1, 7],
				adjAll: [1, 7],
				init: {}
			}
		],
		sides: [
			{
				side: 0,
				s: 0,
				e: 6,
				land: 1
			},
			{
				side: 0,
				s: 6,
				e: 7,
				land: 8
			},
			{
				side: 1,
				s: 0,
				e: 3,
				land: 8
			},
			{
				side: 1,
				s: 3,
				e: 6,
				land: 7
			},
			{
				side: 1,
				s: 6,
				e: 7,
				land: 6
			},
			{
				side: 2,
				s: 0,
				e: 2,
				land: 6
			},
			{
				side: 2,
				s: 2,
				e: 5,
				land: 4
			},
			{
				side: 2,
				s: 5,
				e: 7,
				land: 3
			}
		]
	}
], E = [
	{
		id: "aSpreadOfRampantGreen",
		complexity: "Moderate",
		energyTrack: [
			{ v: 0 },
			{ v: 1 },
			{ elem: ["plant"] },
			{ v: 2 },
			{ v: 2 },
			{ elem: ["plant"] },
			{ v: 3 }
		],
		playsTrack: [
			{ v: 1 },
			{ v: 1 },
			{ v: 2 },
			{ v: 2 },
			{ v: 3 },
			{ v: 4 }
		],
		growth: [
			[{ t: "reclaim" }, {
				t: "gainPower",
				n: 1
			}],
			[{
				t: "addPresence",
				range: 1
			}, {
				t: "cardPlay",
				n: 1
			}],
			[{
				t: "gainPower",
				n: 1
			}, {
				t: "energy",
				n: 3
			}]
		],
		innates: [{
			id: "creepersTearIntoMortar",
			speed: "slow",
			target: "AnyLand",
			range: 0,
			thresholds: [
				{ elems: {
					moon: 1,
					plant: 2
				} },
				{ elems: {
					moon: 2,
					plant: 3
				} },
				{ elems: {
					moon: 3,
					plant: 4
				} }
			]
		}, {
			id: "allEnvelopingGreen",
			speed: "fast",
			target: "AnyLand",
			range: 1,
			ss: !0,
			thresholds: [
				{ elems: {
					water: 1,
					plant: 3
				} },
				{ elems: {
					water: 2,
					plant: 4
				} },
				{ elems: {
					water: 3,
					earth: 1,
					plant: 5
				} }
			]
		}],
		specials: ["chokeTheLandWithGreen", "steadyRegeneration"],
		uniques: [
			"fieldsChokedWithGrowth",
			"giftOfProliferation",
			"overgrowInANight",
			"stemTheFlowOfFreshWater"
		],
		stats: {
			offense: 431,
			control: 319,
			fear: 170,
			defense: 750,
			utility: 376
		}
	},
	{
		id: "bringerOfDreamsAndNightmares",
		complexity: "High",
		energyTrack: [
			{ v: 2 },
			{ elem: ["air"] },
			{ v: 3 },
			{ elem: ["moon"] },
			{ v: 4 },
			{ elem: "any" },
			{ v: 5 }
		],
		playsTrack: [
			{ v: 2 },
			{ v: 2 },
			{ v: 2 },
			{ v: 3 },
			{ v: 3 },
			{ elem: "any" }
		],
		growth: [
			[{ t: "reclaim" }, {
				t: "gainPower",
				n: 1
			}],
			[{ t: "reclaim" }, {
				t: "addPresence",
				range: 0
			}],
			[{
				t: "gainPower",
				n: 1
			}, {
				t: "addPresence",
				range: 1
			}],
			[{
				t: "addPresenceDahanInvaders",
				range: 4
			}, {
				t: "energy",
				n: 2
			}]
		],
		innates: [{
			id: "spiritsMayYetDream",
			speed: "fast",
			target: "AnySpirit",
			thresholds: [{ elems: {
				moon: 2,
				air: 2
			} }, { elems: { moon: 3 } }]
		}, {
			id: "nightTerrors",
			speed: "fast",
			target: "LandWithInvaders",
			range: 0,
			thresholds: [
				{ elems: {
					moon: 1,
					air: 1
				} },
				{ elems: {
					moon: 2,
					air: 1,
					animal: 1
				} },
				{ elems: {
					moon: 3,
					air: 2,
					animal: 1
				} }
			]
		}],
		specials: ["toDreamAThousandDeaths"],
		uniques: [
			"callOnMidnightsDreams",
			"dreamsOfTheDahan",
			"predatoryNightmares",
			"dreadApparitions"
		],
		stats: {
			offense: 6,
			control: 269,
			fear: 761,
			defense: 238,
			utility: 231
		}
	},
	{
		id: "lightningsSwiftStrike",
		complexity: "Low",
		energyTrack: [
			{ v: 1 },
			{ v: 1 },
			{ v: 2 },
			{ v: 2 },
			{ v: 3 },
			{ v: 4 },
			{ v: 4 },
			{ v: 5 }
		],
		playsTrack: [
			{ v: 2 },
			{ v: 3 },
			{ v: 4 },
			{ v: 5 },
			{ v: 6 }
		],
		growth: [
			[
				{ t: "reclaim" },
				{
					t: "gainPower",
					n: 1
				},
				{
					t: "energy",
					n: 1
				}
			],
			[{
				t: "addPresence",
				range: 2
			}, {
				t: "addPresence",
				range: 0
			}],
			[{
				t: "addPresence",
				range: 1
			}, {
				t: "energy",
				n: 3
			}]
		],
		innates: [{
			id: "thunderingDestruction",
			speed: "slow",
			target: "AnyLand",
			range: 1,
			ss: !0,
			thresholds: [
				{ elems: {
					fire: 3,
					air: 2
				} },
				{ elems: {
					fire: 4,
					air: 3
				} },
				{ elems: {
					fire: 5,
					air: 4,
					water: 1
				} },
				{ elems: {
					fire: 5,
					air: 5,
					water: 2
				} }
			]
		}],
		specials: ["swiftnessOfLightning"],
		uniques: [
			"harbingersOfTheLightning",
			"lightningsBoon",
			"shatterHomesteads",
			"ragingStorm"
		],
		stats: {
			offense: 757,
			control: 234,
			fear: 359,
			defense: 54,
			utility: 274
		}
	},
	{
		id: "oceansHungryGrasp",
		complexity: "High",
		energyTrack: [
			{ v: 0 },
			{ elem: ["moon"] },
			{ elem: ["water"] },
			{ v: 1 },
			{ elem: ["earth"] },
			{ elem: ["water"] },
			{ v: 2 }
		],
		playsTrack: [
			{ v: 1 },
			{ v: 2 },
			{ v: 2 },
			{ v: 3 },
			{ v: 4 },
			{ v: 5 }
		],
		growth: [
			[
				{ t: "reclaim" },
				{
					t: "gainPower",
					n: 1
				},
				{ t: "gatherPresenceEachOcean" },
				{
					t: "energy",
					n: 2
				}
			],
			[
				{
					t: "addPresenceOcean",
					n: 1
				},
				{
					t: "addPresenceOcean",
					n: 1
				},
				{
					t: "energy",
					n: 1
				}
			],
			[
				{
					t: "gainPower",
					n: 1
				},
				{ t: "addPresenceCoastal" },
				{ t: "pushPresenceEachOcean" }
			]
		],
		innates: [{
			id: "poundShipsToSplinters",
			speed: "fast",
			target: "Coastal",
			range: 0,
			thresholds: [
				{ elems: {
					moon: 1,
					air: 1,
					water: 2
				} },
				{ elems: {
					moon: 2,
					air: 1,
					water: 3
				} },
				{ elems: {
					moon: 3,
					air: 2,
					water: 4
				} }
			]
		}, {
			id: "oceanBreaksTheShore",
			speed: "slow",
			target: "Coastal",
			range: 0,
			thresholds: [
				{ elems: {
					water: 2,
					earth: 1
				} },
				{ elems: {
					water: 3,
					earth: 2
				} },
				{ elems: {
					water: 4,
					earth: 3
				} }
			]
		}],
		specials: ["oceanInPlay", "drowning"],
		uniques: [
			"callOfTheDeeps",
			"swallowTheLandDwellers",
			"graspingTide",
			"tidalBoon"
		],
		stats: {
			offense: 701,
			control: 486,
			fear: 493,
			defense: 354,
			utility: 181
		}
	},
	{
		id: "riverSurgesInSunlight",
		complexity: "Low",
		energyTrack: [
			{ v: 1 },
			{ v: 2 },
			{ v: 2 },
			{ v: 3 },
			{ v: 4 },
			{ v: 4 },
			{ v: 5 }
		],
		playsTrack: [
			{ v: 1 },
			{ v: 2 },
			{ v: 2 },
			{ v: 3 },
			{ reclaim: !0 },
			{ v: 4 },
			{ v: 5 }
		],
		growth: [
			[
				{ t: "reclaim" },
				{
					t: "gainPower",
					n: 1
				},
				{
					t: "energy",
					n: 1
				}
			],
			[{
				t: "addPresence",
				range: 1
			}, {
				t: "addPresence",
				range: 1
			}],
			[{
				t: "gainPower",
				n: 1
			}, {
				t: "addPresence",
				range: 2
			}]
		],
		innates: [{
			id: "massiveFlooding",
			speed: "slow",
			target: "AnyLand",
			range: 1,
			ss: !0,
			thresholds: [
				{ elems: {
					sun: 1,
					water: 2
				} },
				{ elems: {
					sun: 2,
					water: 3
				} },
				{ elems: {
					sun: 3,
					water: 4,
					earth: 1
				} }
			]
		}],
		specials: ["riversDomain"],
		uniques: [
			"boonOfVigor",
			"flashFloods",
			"riversBounty",
			"washAway"
		],
		stats: {
			offense: 497,
			control: 717,
			fear: 69,
			defense: 64,
			utility: 497
		}
	},
	{
		id: "shadowsFlickerLikeFlame",
		complexity: "Low",
		energyTrack: [
			{ v: 0 },
			{ v: 1 },
			{ v: 3 },
			{ v: 4 },
			{ v: 5 },
			{ v: 6 }
		],
		playsTrack: [
			{ v: 1 },
			{ v: 2 },
			{ v: 3 },
			{ v: 3 },
			{ v: 4 },
			{ v: 5 }
		],
		growth: [
			[{ t: "reclaim" }, {
				t: "gainPower",
				n: 1
			}],
			[{
				t: "gainPower",
				n: 1
			}, {
				t: "addPresence",
				range: 1
			}],
			[{
				t: "addPresence",
				range: 3
			}, {
				t: "energy",
				n: 3
			}]
		],
		innates: [{
			id: "darknessSwallowsTheUnwary",
			speed: "fast",
			target: "AnyLand",
			range: 1,
			ss: !0,
			thresholds: [
				{ elems: {
					moon: 2,
					fire: 1
				} },
				{ elems: {
					moon: 3,
					fire: 2
				} },
				{ elems: {
					moon: 4,
					fire: 3,
					air: 2
				} }
			]
		}],
		specials: ["shadowsOfTheDahan"],
		uniques: [
			"concealingShadows",
			"cropsWitherAndFade",
			"favorsCalledDue",
			"mantleOfDread"
		],
		stats: {
			offense: 490,
			control: 374,
			fear: 747,
			defense: 51,
			utility: 37
		}
	},
	{
		id: "thunderspeaker",
		complexity: "Moderate",
		energyTrack: [
			{ v: 1 },
			{ elem: ["air"] },
			{ v: 2 },
			{ elem: ["fire"] },
			{ elem: ["sun"] },
			{ v: 3 }
		],
		playsTrack: [
			{ v: 1 },
			{ v: 2 },
			{ v: 2 },
			{ v: 3 },
			{ reclaim: !0 },
			{ v: 3 },
			{ v: 4 }
		],
		growth: [
			[
				{ t: "reclaim" },
				{
					t: "gainPower",
					n: 1
				},
				{
					t: "gainPower",
					n: 1
				}
			],
			[{
				t: "addPresenceDahan",
				range: 2
			}, {
				t: "addPresenceDahan",
				range: 1
			}],
			[{
				t: "addPresence",
				range: 1
			}, {
				t: "energy",
				n: 4
			}]
		],
		innates: [{
			id: "gatherTheWarriors",
			speed: "slow",
			target: "AnyLand",
			range: 1,
			thresholds: [{ elems: { air: 4 } }, { elems: { animal: 1 } }]
		}, {
			id: "leadTheFuriousAssault",
			speed: "slow",
			target: "AnyLand",
			range: 0,
			thresholds: [
				{ elems: { air: 4 } },
				{ elems: {
					sun: 2,
					fire: 1
				} },
				{ elems: {
					sun: 4,
					fire: 3
				} }
			]
		}],
		specials: ["allyOfTheDahan", "swornToVictory"],
		uniques: [
			"voiceOfThunder",
			"wordsOfWarning",
			"suddenAmbush",
			"manifestationOfPowerAndGlory"
		],
		stats: {
			offense: 592,
			control: 717,
			fear: 248,
			defense: 162,
			utility: 1
		}
	},
	{
		id: "vitalStrengthOfTheEarth",
		complexity: "Low",
		energyTrack: [
			{ v: 2 },
			{ v: 3 },
			{ v: 4 },
			{ v: 6 },
			{ v: 7 },
			{ v: 8 }
		],
		playsTrack: [
			{ v: 1 },
			{ v: 1 },
			{ v: 2 },
			{ v: 2 },
			{ v: 3 },
			{ v: 4 }
		],
		growth: [
			[{ t: "reclaim" }, {
				t: "addPresence",
				range: 2
			}],
			[{
				t: "gainPower",
				n: 1
			}, {
				t: "addPresence",
				range: 0
			}],
			[{
				t: "addPresence",
				range: 1
			}, {
				t: "energy",
				n: 2
			}]
		],
		innates: [{
			id: "giftOfStrength",
			speed: "fast",
			target: "AnySpirit",
			thresholds: [
				{ elems: {
					sun: 1,
					earth: 2,
					plant: 2
				} },
				{ elems: {
					sun: 2,
					earth: 3,
					plant: 2
				} },
				{ elems: {
					sun: 2,
					earth: 4,
					plant: 3
				} }
			]
		}],
		specials: ["earthsVitality"],
		uniques: [
			"aYearOfPerfectStillness",
			"guardTheHealingLand",
			"ritualsOfDestruction",
			"drawOfTheFruitfulEarth"
		],
		stats: {
			offense: 221,
			control: 273,
			fear: 110,
			defense: 761,
			utility: 273
		}
	}
], ye = [
	{
		id: "acceleratedRot",
		type: "major",
		cost: 4,
		elements: [
			"sun",
			"water",
			"plant"
		],
		speed: "slow",
		target: "JungleWetland",
		range: 2,
		thresholds: [{
			elems: {
				sun: 3,
				water: 2,
				plant: 3
			},
			text: "acceleratedRot.th0"
		}]
	},
	{
		id: "aYearOfPerfectStillness",
		type: "unique",
		cost: 3,
		elements: ["sun", "earth"],
		speed: "fast",
		target: "AnyLand",
		spirit: "vitalStrengthOfTheEarth",
		range: 1
	},
	{
		id: "blazingRenewal",
		type: "major",
		cost: 5,
		elements: [
			"fire",
			"earth",
			"plant"
		],
		speed: "fast",
		target: "AnySpirit",
		thresholds: [{
			elems: {
				fire: 3,
				earth: 3,
				plant: 2
			},
			text: "blazingRenewal.th0"
		}]
	},
	{
		id: "boonOfVigor",
		type: "unique",
		cost: 0,
		elements: [
			"sun",
			"water",
			"plant"
		],
		speed: "fast",
		target: "AnySpirit",
		spirit: "riverSurgesInSunlight"
	},
	{
		id: "callOfTheDahanWays",
		type: "minor",
		cost: 1,
		elements: [
			"moon",
			"water",
			"animal"
		],
		speed: "slow",
		target: "LandWithDahan",
		range: 1,
		thresholds: [{
			elems: { moon: 2 },
			text: "callOfTheDahanWays.th0"
		}]
	},
	{
		id: "callOfTheDeeps",
		type: "unique",
		cost: 0,
		elements: [
			"moon",
			"air",
			"water"
		],
		speed: "fast",
		target: "Coastal",
		spirit: "oceansHungryGrasp",
		range: 0
	},
	{
		id: "callOnMidnightsDreams",
		type: "unique",
		cost: 0,
		elements: ["moon", "animal"],
		speed: "fast",
		target: "AnyLand",
		spirit: "bringerOfDreamsAndNightmares",
		range: 0
	},
	{
		id: "callToBloodshed",
		type: "minor",
		cost: 1,
		elements: [
			"sun",
			"fire",
			"animal"
		],
		speed: "slow",
		target: "LandWithDahan",
		range: 1
	},
	{
		id: "callToIsolation",
		type: "minor",
		cost: 0,
		elements: [
			"sun",
			"air",
			"animal"
		],
		speed: "fast",
		target: "LandWithDahan",
		range: 1
	},
	{
		id: "callToMigrate",
		type: "minor",
		cost: 1,
		elements: [
			"fire",
			"air",
			"animal"
		],
		speed: "slow",
		target: "AnyLand",
		range: 1
	},
	{
		id: "callToTend",
		type: "minor",
		cost: 1,
		elements: [
			"water",
			"plant",
			"animal"
		],
		speed: "slow",
		target: "LandWithDahan",
		range: 1
	},
	{
		id: "cleansingFloods",
		type: "major",
		cost: 5,
		elements: ["sun", "water"],
		speed: "slow",
		target: "AnyLand",
		range: 1,
		rangeTerrain: ["Wetland"],
		thresholds: [{
			elems: { water: 4 },
			text: "cleansingFloods.th0"
		}]
	},
	{
		id: "concealingShadows",
		type: "unique",
		cost: 0,
		elements: ["moon", "air"],
		speed: "fast",
		target: "AnyLand",
		spirit: "shadowsFlickerLikeFlame",
		range: 0
	},
	{
		id: "cropsWitherAndFade",
		type: "unique",
		cost: 1,
		elements: [
			"moon",
			"fire",
			"plant"
		],
		speed: "slow",
		target: "AnyLand",
		spirit: "shadowsFlickerLikeFlame",
		range: 0
	},
	{
		id: "darkAndTangledWoods",
		type: "minor",
		cost: 1,
		elements: [
			"moon",
			"earth",
			"plant"
		],
		speed: "fast",
		target: "AnyLand",
		range: 1
	},
	{
		id: "delusionsOfDanger",
		type: "minor",
		cost: 1,
		elements: [
			"sun",
			"moon",
			"air"
		],
		speed: "fast",
		target: "AnyLand",
		range: 1
	},
	{
		id: "devouringAnts",
		type: "minor",
		cost: 1,
		elements: [
			"sun",
			"earth",
			"animal"
		],
		speed: "slow",
		target: "AnyLand",
		range: 1,
		ss: !0
	},
	{
		id: "dissolveTheBondsOfKinship",
		type: "major",
		cost: 4,
		elements: [
			"fire",
			"water",
			"animal"
		],
		speed: "slow",
		target: "AnyLand",
		range: 1,
		thresholds: [{
			elems: {
				fire: 2,
				water: 2,
				animal: 3
			},
			text: "dissolveTheBondsOfKinship.th0"
		}]
	},
	{
		id: "drawOfTheFruitfulEarth",
		type: "unique",
		cost: 1,
		elements: [
			"earth",
			"plant",
			"animal"
		],
		speed: "slow",
		target: "AnyLand",
		spirit: "vitalStrengthOfTheEarth",
		range: 1
	},
	{
		id: "dreadApparitions",
		type: "unique",
		cost: 2,
		elements: ["moon", "air"],
		speed: "fast",
		target: "LandWithInvaders",
		spirit: "bringerOfDreamsAndNightmares",
		range: 1
	},
	{
		id: "dreamsOfTheDahan",
		type: "unique",
		cost: 0,
		elements: ["moon", "air"],
		speed: "fast",
		target: "AnyLand",
		spirit: "bringerOfDreamsAndNightmares",
		range: 2
	},
	{
		id: "driftDownIntoSlumber",
		type: "minor",
		cost: 0,
		elements: [
			"air",
			"earth",
			"plant"
		],
		speed: "fast",
		target: "AnyLand",
		range: 2
	},
	{
		id: "drought",
		type: "minor",
		cost: 1,
		elements: [
			"sun",
			"fire",
			"earth"
		],
		speed: "slow",
		target: "AnyLand",
		range: 1,
		thresholds: [{
			elems: { sun: 3 },
			text: "drought.th0"
		}]
	},
	{
		id: "elementalBoon",
		type: "minor",
		cost: 1,
		elements: [],
		speed: "fast",
		target: "AnySpirit"
	},
	{
		id: "encompassingWard",
		type: "minor",
		cost: 1,
		elements: [
			"sun",
			"water",
			"earth"
		],
		speed: "fast",
		target: "AnySpirit"
	},
	{
		id: "enticingSplendor",
		type: "minor",
		cost: 0,
		elements: [
			"sun",
			"air",
			"plant"
		],
		speed: "fast",
		target: "LandWithNoBlight",
		range: 0
	},
	{
		id: "entrancingApparitions",
		type: "minor",
		cost: 1,
		elements: [
			"moon",
			"air",
			"water"
		],
		speed: "fast",
		target: "AnyLand",
		range: 1
	},
	{
		id: "entwinedPower",
		type: "major",
		cost: 2,
		elements: [
			"moon",
			"water",
			"plant"
		],
		speed: "fast",
		target: "AnotherSpirit",
		thresholds: [{
			elems: {
				water: 2,
				plant: 4
			},
			text: "entwinedPower.th0"
		}]
	},
	{
		id: "favorsCalledDue",
		type: "unique",
		cost: 1,
		elements: [
			"moon",
			"air",
			"animal"
		],
		speed: "slow",
		target: "AnyLand",
		spirit: "shadowsFlickerLikeFlame",
		range: 1
	},
	{
		id: "fieldsChokedWithGrowth",
		type: "unique",
		cost: 0,
		elements: [
			"sun",
			"water",
			"plant"
		],
		speed: "slow",
		target: "AnyLand",
		spirit: "aSpreadOfRampantGreen",
		range: 1
	},
	{
		id: "flashFloods",
		type: "unique",
		cost: 2,
		elements: ["sun", "water"],
		speed: "fast",
		target: "AnyLand",
		spirit: "riverSurgesInSunlight",
		range: 1
	},
	{
		id: "giftOfConstancy",
		type: "minor",
		cost: 0,
		elements: ["sun", "earth"],
		speed: "fast",
		target: "AnySpirit"
	},
	{
		id: "giftOfLivingEnergy",
		type: "minor",
		cost: 0,
		elements: [
			"sun",
			"fire",
			"plant"
		],
		speed: "fast",
		target: "AnySpirit"
	},
	{
		id: "giftOfPower",
		type: "minor",
		cost: 0,
		elements: [
			"moon",
			"water",
			"earth",
			"plant"
		],
		speed: "slow",
		target: "AnySpirit"
	},
	{
		id: "giftOfProliferation",
		type: "unique",
		cost: 1,
		elements: ["moon", "plant"],
		speed: "fast",
		target: "AnotherSpirit",
		spirit: "aSpreadOfRampantGreen"
	},
	{
		id: "gnawingRootbiters",
		type: "minor",
		cost: 0,
		elements: ["earth", "animal"],
		speed: "slow",
		target: "AnyLand",
		range: 1
	},
	{
		id: "graspingTide",
		type: "unique",
		cost: 1,
		elements: ["moon", "water"],
		speed: "fast",
		target: "Coastal",
		spirit: "oceansHungryGrasp",
		range: 1
	},
	{
		id: "guardTheHealingLand",
		type: "unique",
		cost: 3,
		elements: [
			"water",
			"earth",
			"plant"
		],
		speed: "fast",
		target: "AnyLand",
		spirit: "vitalStrengthOfTheEarth",
		range: 1,
		ss: !0
	},
	{
		id: "harbingersOfTheLightning",
		type: "unique",
		cost: 0,
		elements: ["fire", "air"],
		speed: "slow",
		target: "AnyLand",
		spirit: "lightningsSwiftStrike",
		range: 1
	},
	{
		id: "indomitableClaim",
		type: "major",
		cost: 4,
		elements: ["sun", "earth"],
		speed: "fast",
		target: "AnyLand",
		range: 1,
		thresholds: [{
			elems: {
				sun: 2,
				earth: 3
			},
			text: "indomitableClaim.th0"
		}]
	},
	{
		id: "infiniteVitality",
		type: "major",
		cost: 3,
		elements: [
			"earth",
			"plant",
			"animal"
		],
		speed: "fast",
		target: "AnyLand",
		range: 1,
		ss: !0,
		thresholds: [{
			elems: { earth: 4 },
			text: "infiniteVitality.th0"
		}]
	},
	{
		id: "landOfHauntsAndEmbers",
		type: "minor",
		cost: 0,
		elements: [
			"moon",
			"fire",
			"air"
		],
		speed: "fast",
		target: "AnyLand",
		range: 2
	},
	{
		id: "lightningsBoon",
		type: "unique",
		cost: 1,
		elements: ["fire", "air"],
		speed: "fast",
		target: "AnySpirit",
		spirit: "lightningsSwiftStrike"
	},
	{
		id: "lureOfTheUnknown",
		type: "minor",
		cost: 0,
		elements: [
			"moon",
			"fire",
			"air",
			"plant"
		],
		speed: "fast",
		target: "LandWithNoInvaders",
		range: 2
	},
	{
		id: "manifestationOfPowerAndGlory",
		type: "unique",
		cost: 3,
		elements: [
			"sun",
			"fire",
			"air"
		],
		speed: "slow",
		target: "LandWithDahan",
		spirit: "thunderspeaker",
		range: 0
	},
	{
		id: "mantleOfDread",
		type: "unique",
		cost: 1,
		elements: [
			"moon",
			"fire",
			"air"
		],
		speed: "slow",
		target: "AnySpirit",
		spirit: "shadowsFlickerLikeFlame"
	},
	{
		id: "mistsOfOblivion",
		type: "major",
		cost: 4,
		elements: [
			"moon",
			"air",
			"water"
		],
		speed: "slow",
		target: "AnyLand",
		range: 3,
		thresholds: [{
			elems: {
				moon: 2,
				air: 3,
				water: 2
			},
			text: "mistsOfOblivion.th0"
		}]
	},
	{
		id: "naturesResilience",
		type: "minor",
		cost: 1,
		elements: [
			"earth",
			"plant",
			"animal"
		],
		speed: "fast",
		target: "AnyLand",
		range: 1,
		ss: !0,
		thresholds: [{
			elems: { water: 2 },
			text: "naturesResilience.th0"
		}]
	},
	{
		id: "overgrowInANight",
		type: "unique",
		cost: 2,
		elements: ["moon", "plant"],
		speed: "fast",
		target: "AnyLand",
		spirit: "aSpreadOfRampantGreen",
		range: 1
	},
	{
		id: "paralyzingFright",
		type: "major",
		cost: 4,
		elements: ["air", "earth"],
		speed: "fast",
		target: "AnyLand",
		range: 1,
		ss: !0,
		thresholds: [{
			elems: {
				air: 2,
				earth: 3
			},
			text: "paralyzingFright.th0"
		}]
	},
	{
		id: "pillarOfLivingFlame",
		type: "major",
		cost: 5,
		elements: ["fire"],
		speed: "slow",
		target: "AnyLand",
		range: 2,
		ss: !0,
		thresholds: [{
			elems: { fire: 4 },
			text: "pillarOfLivingFlame.th0"
		}]
	},
	{
		id: "poisonedLand",
		type: "major",
		cost: 3,
		elements: [
			"earth",
			"plant",
			"animal"
		],
		speed: "slow",
		target: "AnyLand",
		range: 1,
		thresholds: [{
			elems: {
				earth: 3,
				plant: 2,
				animal: 2
			},
			text: "poisonedLand.th0"
		}]
	},
	{
		id: "powerstorm",
		type: "major",
		cost: 3,
		elements: [
			"sun",
			"fire",
			"air"
		],
		speed: "fast",
		target: "AnySpirit",
		thresholds: [{
			elems: {
				sun: 2,
				fire: 2,
				air: 3
			},
			text: "powerstorm.th0"
		}]
	},
	{
		id: "predatoryNightmares",
		type: "unique",
		cost: 2,
		elements: [
			"moon",
			"fire",
			"earth",
			"animal"
		],
		speed: "slow",
		target: "LandWithInvaders",
		spirit: "bringerOfDreamsAndNightmares",
		range: 1,
		ss: !0
	},
	{
		id: "pullBeneathTheHungryEarth",
		type: "minor",
		cost: 1,
		elements: [
			"moon",
			"water",
			"earth"
		],
		speed: "slow",
		target: "AnyLand",
		range: 1
	},
	{
		id: "purifyingFlame",
		type: "minor",
		cost: 1,
		elements: [
			"sun",
			"fire",
			"air",
			"plant"
		],
		speed: "slow",
		target: "AnyLand",
		range: 1,
		ss: !0
	},
	{
		id: "quickenTheEarthsStruggles",
		type: "minor",
		cost: 1,
		elements: [
			"moon",
			"fire",
			"earth",
			"animal"
		],
		speed: "fast",
		target: "AnyLand",
		range: 0,
		ss: !0
	},
	{
		id: "ragingStorm",
		type: "unique",
		cost: 3,
		elements: [
			"fire",
			"air",
			"water"
		],
		speed: "slow",
		target: "AnyLand",
		spirit: "lightningsSwiftStrike",
		range: 1
	},
	{
		id: "rainOfBlood",
		type: "minor",
		cost: 0,
		elements: [
			"air",
			"water",
			"animal"
		],
		speed: "slow",
		target: "LandWithInvaders",
		range: 1,
		ss: !0
	},
	{
		id: "reachingGrasp",
		type: "minor",
		cost: 0,
		elements: [
			"sun",
			"air",
			"water"
		],
		speed: "fast",
		target: "AnySpirit"
	},
	{
		id: "ritualsOfDestruction",
		type: "unique",
		cost: 3,
		elements: [
			"sun",
			"moon",
			"fire",
			"earth",
			"plant"
		],
		speed: "slow",
		target: "LandWithDahan",
		spirit: "vitalStrengthOfTheEarth",
		range: 1,
		ss: !0
	},
	{
		id: "riversBounty",
		type: "unique",
		cost: 0,
		elements: [
			"sun",
			"water",
			"animal"
		],
		speed: "slow",
		target: "AnyLand",
		spirit: "riverSurgesInSunlight",
		range: 0
	},
	{
		id: "rouseTheTreesAndStones",
		type: "minor",
		cost: 1,
		elements: [
			"fire",
			"earth",
			"plant"
		],
		speed: "slow",
		target: "LandWithNoBlight",
		range: 1,
		ss: !0
	},
	{
		id: "sapTheStrengthOfMultitudes",
		type: "minor",
		cost: 0,
		elements: ["water", "animal"],
		speed: "fast",
		target: "AnyLand",
		range: 0,
		thresholds: [{
			elems: { air: 1 },
			text: "sapTheStrengthOfMultitudes.th0"
		}]
	},
	{
		id: "savageMawbeasts",
		type: "minor",
		cost: 0,
		elements: ["fire", "animal"],
		speed: "slow",
		target: "AnyLand",
		range: 1,
		ss: !0,
		thresholds: [{
			elems: { animal: 3 },
			text: "savageMawbeasts.th0"
		}]
	},
	{
		id: "shadowsOfTheBurningForest",
		type: "minor",
		cost: 0,
		elements: [
			"moon",
			"fire",
			"plant"
		],
		speed: "slow",
		target: "LandWithInvaders",
		range: 0
	},
	{
		id: "shatterHomesteads",
		type: "unique",
		cost: 2,
		elements: ["fire", "air"],
		speed: "slow",
		target: "AnyLand",
		spirit: "lightningsSwiftStrike",
		range: 2,
		ss: !0
	},
	{
		id: "songOfSanctity",
		type: "minor",
		cost: 1,
		elements: [
			"sun",
			"water",
			"plant"
		],
		speed: "slow",
		target: "MountainJungle",
		range: 1
	},
	{
		id: "steamVents",
		type: "minor",
		cost: 1,
		elements: [
			"fire",
			"air",
			"water",
			"earth"
		],
		speed: "fast",
		target: "AnyLand",
		range: 0,
		thresholds: [{
			elems: { earth: 3 },
			text: "steamVents.th0"
		}]
	},
	{
		id: "stemTheFlowOfFreshWater",
		type: "unique",
		cost: 0,
		elements: ["water", "plant"],
		speed: "slow",
		target: "AnyLand",
		spirit: "aSpreadOfRampantGreen",
		range: 1,
		ss: !0
	},
	{
		id: "suddenAmbush",
		type: "unique",
		cost: 2,
		elements: [
			"fire",
			"air",
			"animal"
		],
		speed: "fast",
		target: "AnyLand",
		spirit: "thunderspeaker",
		range: 1
	},
	{
		id: "swallowTheLandDwellers",
		type: "unique",
		cost: 0,
		elements: ["water", "earth"],
		speed: "slow",
		target: "Coastal",
		spirit: "oceansHungryGrasp",
		range: 0
	},
	{
		id: "talonsOfLightning",
		type: "major",
		cost: 6,
		elements: ["fire", "air"],
		speed: "fast",
		target: "MountainWetland",
		range: 1,
		thresholds: [{
			elems: {
				fire: 3,
				air: 3
			},
			text: "talonsOfLightning.th0"
		}]
	},
	{
		id: "terrifyingNightmares",
		type: "major",
		cost: 4,
		elements: ["moon", "air"],
		speed: "fast",
		target: "AnyLand",
		range: 2,
		thresholds: [{
			elems: { moon: 4 },
			text: "terrifyingNightmares.th0"
		}]
	},
	{
		id: "theJungleHungers",
		type: "major",
		cost: 3,
		elements: ["moon", "plant"],
		speed: "slow",
		target: "AnyLand",
		range: 1,
		rangeTerrain: ["Jungle"],
		thresholds: [{
			elems: {
				moon: 2,
				plant: 3
			},
			text: "theJungleHungers.th0"
		}]
	},
	{
		id: "theLandThrashesInFuriousPain",
		type: "major",
		cost: 4,
		elements: [
			"moon",
			"fire",
			"earth"
		],
		speed: "slow",
		target: "LandWithBlight",
		range: 2,
		thresholds: [{
			elems: {
				moon: 3,
				earth: 3
			},
			text: "theLandThrashesInFuriousPain.th0"
		}]
	},
	{
		id: "theTreesAndStonesSpeakOfWar",
		type: "major",
		cost: 2,
		elements: [
			"sun",
			"earth",
			"plant"
		],
		speed: "fast",
		target: "LandWithDahan",
		range: 1,
		thresholds: [{
			elems: {
				sun: 2,
				earth: 2,
				plant: 2
			},
			text: "theTreesAndStonesSpeakOfWar.th0"
		}]
	},
	{
		id: "tidalBoon",
		type: "unique",
		cost: 1,
		elements: [
			"moon",
			"water",
			"earth"
		],
		speed: "slow",
		target: "AnotherSpirit",
		spirit: "oceansHungryGrasp"
	},
	{
		id: "tsunami",
		type: "major",
		cost: 6,
		elements: ["water", "earth"],
		speed: "slow",
		target: "Coastal",
		range: 2,
		ss: !0,
		thresholds: [{
			elems: {
				water: 3,
				earth: 2
			},
			text: "tsunami.th0"
		}]
	},
	{
		id: "uncannyMelting",
		type: "minor",
		cost: 1,
		elements: [
			"sun",
			"moon",
			"water"
		],
		speed: "slow",
		target: "AnyLand",
		range: 1,
		ss: !0
	},
	{
		id: "veilTheNightsHunt",
		type: "minor",
		cost: 1,
		elements: [
			"moon",
			"air",
			"animal"
		],
		speed: "fast",
		target: "LandWithDahan",
		range: 2
	},
	{
		id: "vengeanceOfTheDead",
		type: "major",
		cost: 3,
		elements: [
			"moon",
			"fire",
			"animal"
		],
		speed: "fast",
		target: "AnyLand",
		range: 3,
		thresholds: [{
			elems: { animal: 3 },
			text: "vengeanceOfTheDead.th0"
		}]
	},
	{
		id: "vigorOfTheBreakingDawn",
		type: "major",
		cost: 3,
		elements: ["sun", "animal"],
		speed: "fast",
		target: "LandWithDahan",
		range: 2,
		thresholds: [{
			elems: {
				sun: 3,
				animal: 2
			},
			text: "vigorOfTheBreakingDawn.th0"
		}]
	},
	{
		id: "visionsOfFieryDoom",
		type: "minor",
		cost: 1,
		elements: ["moon", "fire"],
		speed: "fast",
		target: "AnyLand",
		range: 0,
		thresholds: [{
			elems: { fire: 2 },
			text: "visionsOfFieryDoom.th0"
		}]
	},
	{
		id: "voiceOfThunder",
		type: "unique",
		cost: 0,
		elements: ["sun", "air"],
		speed: "slow",
		target: "AnyLand",
		spirit: "thunderspeaker",
		range: 1
	},
	{
		id: "voraciousGrowth",
		type: "minor",
		cost: 1,
		elements: ["water", "plant"],
		speed: "slow",
		target: "JungleWetland",
		range: 1,
		ss: !0
	},
	{
		id: "washAway",
		type: "unique",
		cost: 1,
		elements: ["water", "earth"],
		speed: "slow",
		target: "AnyLand",
		spirit: "riverSurgesInSunlight",
		range: 1
	},
	{
		id: "windsOfRustAndAtrophy",
		type: "major",
		cost: 3,
		elements: [
			"air",
			"water",
			"animal"
		],
		speed: "fast",
		target: "AnyLand",
		range: 3,
		ss: !0,
		thresholds: [{
			elems: {
				air: 3,
				water: 3,
				animal: 2
			},
			text: "windsOfRustAndAtrophy.th0"
		}]
	},
	{
		id: "wordsOfWarning",
		type: "unique",
		cost: 1,
		elements: [
			"sun",
			"air",
			"animal"
		],
		speed: "fast",
		target: "LandWithDahan",
		spirit: "thunderspeaker",
		range: 1
	},
	{
		id: "wrapInWingsOfSunlight",
		type: "major",
		cost: 3,
		elements: [
			"sun",
			"air",
			"animal"
		],
		speed: "fast",
		target: "AnyLand",
		range: 0,
		thresholds: [{
			elems: {
				sun: 2,
				air: 2,
				animal: 2
			},
			text: "wrapInWingsOfSunlight.th0"
		}]
	}
], be = [
	{
		id: "jungle1",
		stage: 1,
		terrains: ["Jungle"]
	},
	{
		id: "mountain1",
		stage: 1,
		terrains: ["Mountain"]
	},
	{
		id: "sands1",
		stage: 1,
		terrains: ["Sands"]
	},
	{
		id: "wetland1",
		stage: 1,
		terrains: ["Wetland"]
	},
	{
		id: "coastal2",
		stage: 2,
		terrains: ["Coastal"]
	},
	{
		id: "jungle2",
		stage: 2,
		terrains: ["Jungle"]
	},
	{
		id: "mountain2",
		stage: 2,
		terrains: ["Mountain"]
	},
	{
		id: "sands2",
		stage: 2,
		terrains: ["Sands"]
	},
	{
		id: "wetland2",
		stage: 2,
		terrains: ["Wetland"]
	},
	{
		id: "jungleSands3",
		stage: 3,
		terrains: ["Jungle", "Sands"]
	},
	{
		id: "jungleWetland3",
		stage: 3,
		terrains: ["Jungle", "Wetland"]
	},
	{
		id: "mountainJungle3",
		stage: 3,
		terrains: ["Mountain", "Jungle"]
	},
	{
		id: "mountainWetland3",
		stage: 3,
		terrains: ["Mountain", "Wetland"]
	},
	{
		id: "sandsMountain3",
		stage: 3,
		terrains: ["Sands", "Mountain"]
	},
	{
		id: "sandsWetland3",
		stage: 3,
		terrains: ["Sands", "Wetland"]
	}
], xe = {
	avoidTheDahan: {
		name: {
			zh: "避开达罕人",
			en: "Avoid the Dahan"
		},
		levels: [
			{
				zh: "跳过在至少有 2 个 {Dahan} 的格子的所有探索行动。",
				en: "Skip all Explore Actions in lands with at least 2 {Dahan}."
			},
			{
				zh: "跳过在 {Dahan} 多于 {Town}/{City} 的格子(含没有 {Town}/{City} 的格子)的所有建造行动。",
				en: "Skip all Build Actions in lands where {Dahan} outnumber {Town}/{City} (including lands with no {Town}/{City})."
			},
			{
				zh: "跳过在有 {Dahan} 的格子的建造行动。",
				en: "Skip Build Actions in lands with {Dahan}."
			}
		]
	},
	beliefTakesRoot: {
		name: {
			zh: "信仰生根",
			en: "Belief Takes Root"
		},
		levels: [
			{
				zh: "有 {Presence} 的格子防御 2。",
				en: "Lands with {Presence} have Defend 2."
			},
			{
				zh: "有 {Presence} 的格子防御 2;每个精灵在有入侵者的格子里,每有 1 个 {SacredSite} 获得 1 能量。",
				en: "Lands with {Presence} have Defend 2. Each Spirit gains 1 Energy per {SacredSite} they have in lands with Invaders."
			},
			{
				zh: "每名玩家选择 1 个不同的格子;在每个格子:每有 1 个 {Presence},移除至多 2 点生命的入侵者。",
				en: "Each player chooses a different land. In each: Remove up to 2 Health worth of Invaders per {Presence}."
			}
		]
	},
	dahanEnheartened: {
		name: {
			zh: "达罕人振奋",
			en: "Dahan Enheartened"
		},
		levels: [
			{
				zh: "每名玩家可以从有入侵者的格子推走 1 个 {Dahan},或向有入侵者的格子聚集 1 个 {Dahan}。",
				en: "Each player may Push 1 {Dahan} from a land with Invaders or Gather 1 {Dahan} into a land with Invaders."
			},
			{
				zh: "每名玩家选择 1 个不同的格子;在每个格子:聚集至多 2 个 {Dahan};若有 {Dahan} 在场,造成 1 点伤害。",
				en: "Each player chooses a different land. In each: Gather up to 2 {Dahan}. 1 Damage if {Dahan} are present."
			},
			{
				zh: "每名玩家选择 1 个不同的格子;在每个格子:聚集至多 2 个 {Dahan},每个 {Dahan} 造成 1 点伤害。",
				en: "Each player chooses a different land. In each: Gather up to 2 {Dahan}. 1 Damage per {Dahan}."
			}
		]
	},
	dahanOnTheirGuard: {
		name: {
			zh: "达罕人戒备",
			en: "Dahan On Their Guard"
		},
		levels: [
			{
				zh: "有 {Dahan} 的格子,每个 {Dahan} 提供防御 1。",
				en: "Lands with {Dahan} have Defend 1 per {Dahan}."
			},
			{
				zh: "有 {Dahan} 的格子防御 1,且每个 {Dahan} 再提供防御 1。",
				en: "Lands with {Dahan} have Defend 1 + Defend 1 per {Dahan}."
			},
			{
				zh: "有 {Dahan} 的格子,每个 {Dahan} 提供防御 2。",
				en: "Lands with {Dahan} have Defend 2 per {Dahan}."
			}
		]
	},
	dahanRaid: {
		name: {
			zh: "达罕突袭",
			en: "Dahan Raid"
		},
		levels: [
			{
				zh: "每名玩家选择 1 个不同的有 {Dahan} 的格子;在每个格子:造成 1 点伤害。",
				en: "Each player chooses a different land with {Dahan}. In each: 1 Damage."
			},
			{
				zh: "每名玩家选择 1 个不同的有 {Dahan} 的格子;在每个格子:每个 {Dahan} 造成 1 点伤害。",
				en: "Each player chooses a different land with {Dahan}. In each: 1 Damage per {Dahan} there."
			},
			{
				zh: "每名玩家选择 1 个不同的有 {Dahan} 的格子;在每个格子:每个 {Dahan} 造成 2 点伤害。",
				en: "Each player chooses a different land with {Dahan}. In each: 2 Damage per {Dahan} there."
			}
		]
	},
	emigrationAccelerates: {
		name: {
			zh: "移民加速",
			en: "Emigration Accelerates"
		},
		levels: [
			{
				zh: "每名玩家从 1 个沿海格移除 1 个 {Explorer}。",
				en: "Each player removes 1 {Explorer} from a Coastal land."
			},
			{
				zh: "每名玩家从 1 个沿海格移除 1 个 {Explorer}/{Town}。",
				en: "Each player removes 1 {Explorer}/{Town} from a Coastal land."
			},
			{
				zh: "每名玩家从任意格移除 1 个 {Explorer}/{Town}。",
				en: "Each player removes 1 {Explorer}/{Town} from any land."
			}
		]
	},
	fearOfTheUnseen: {
		name: {
			zh: "对未知之物的恐惧",
			en: "Fear of the Unseen"
		},
		levels: [
			{
				zh: "每名玩家从 1 个有 {SacredSite} 的格子移除 1 个 {Explorer}/{Town}。",
				en: "Each player Removes 1 {Explorer}/{Town} from a land with {SacredSite}."
			},
			{
				zh: "每名玩家从 1 个有 {Presence} 的格子移除 1 个 {Explorer}/{Town}。",
				en: "Each player Removes 1 {Explorer}/{Town} from a land with {Presence}."
			},
			{
				zh: "每名玩家从 1 个有 {Presence} 的格子移除 1 个 {Explorer}/{Town},或从 1 个有 {SacredSite} 的格子移除 1 个 {City}。",
				en: "Each player Removes 1 {Explorer}/{Town} from a land with {Presence}, or Removes 1 {City} from a land with {SacredSite}."
			}
		]
	},
	isolation: {
		name: {
			zh: "孤立无援",
			en: "Isolation"
		},
		levels: [
			{
				zh: "每名玩家从 1 个其是唯一入侵者的格子移除 1 个 {Explorer}/{Town}。",
				en: "Each player removes 1 {Explorer}/{Town} from a land where it is the only Invader."
			},
			{
				zh: "每名玩家从 1 个入侵者不超过 2 个的格子移除 1 个 {Explorer}/{Town}。",
				en: "Each player removes 1 {Explorer}/{Town} from a land with 2 or fewer Invaders."
			},
			{
				zh: "每名玩家从 1 个入侵者不超过 2 个的格子移除 1 个入侵者。",
				en: "Each player removes an Invader from a land with 2 or fewer Invaders."
			}
		]
	},
	overseasTradeSeemsSafer: {
		name: {
			zh: "海外贸易似乎更安全",
			en: "Overseas Trade Seems Safer"
		},
		levels: [
			{
				zh: "所有沿海格防御 3。",
				en: "Defend 3 in all Coastal lands."
			},
			{
				zh: "所有沿海格防御 6;跳过在沿海格会产生 {City} 的建造行动。",
				en: "Defend 6 in all Coastal lands. Skip Build Actions in Coastal lands that would add {City}."
			},
			{
				zh: "所有沿海格防御 9;跳过沿海格的所有建造行动。",
				en: "Defend 9 in all Coastal lands. Skip all Build Actions in Coastal lands."
			}
		]
	},
	retreat: {
		name: {
			zh: "撤退!",
			en: "Retreat!"
		},
		levels: [
			{
				zh: "每名玩家可以从 1 个内陆格推走至多 2 个 {Explorer}。",
				en: "Each player may Push up to 2 {Explorer} from an Inland land."
			},
			{
				zh: "每名玩家可以从 1 个内陆格推走至多 3 个 {Explorer}/{Town}。",
				en: "Each player may Push up to 3 {Explorer}/{Town} from an Inland land."
			},
			{
				zh: "每名玩家可以从 1 个格子推走任意数量的 {Explorer}/{Town}。",
				en: "Each player may Push any number of {Explorer}/{Town} from one land."
			}
		]
	},
	scapegoats: {
		name: {
			zh: "替罪羊",
			en: "Scapegoats"
		},
		levels: [
			{
				zh: "在每个有 {Town} 的格子:每个 {Town} 消灭 1 个 {Explorer}。",
				en: "In each land with {Town}: Destroy 1 {Explorer} per {Town}."
			},
			{
				zh: "在每个有 {Town}/{City} 的格子:每个 {Town} 消灭 1 个 {Explorer},每个 {City} 消灭 2 个 {Explorer}。",
				en: "In each land with {Town}/{City}: Destroy 1 {Explorer} per {Town} and 2 {Explorer} per {City}."
			},
			{
				zh: "在每个有 {Town}/{City} 的格子:消灭所有 {Explorer},每个 {City} 消灭 1 个 {Town}。",
				en: "In each land with {Town}/{City}: Destroy all {Explorer}. Destroy 1 {Town} per {City}."
			}
		]
	},
	seekSafety: {
		name: {
			zh: "寻求庇护",
			en: "Seek Safety"
		},
		levels: [
			{
				zh: "每名玩家可以将 1 个 {Explorer} 推入 1 个比来源格 {Town}/{City} 更多的格子。",
				en: "Each player may Push 1 {Explorer} into a land with more {Town}/{City} than the land it came from."
			},
			{
				zh: "每名玩家可以向有 {Town}/{City} 的格子聚集 1 个 {Explorer},或向有 {City} 的格子聚集 1 个 {Town}。",
				en: "Each player may Gather 1 {Explorer} into a land with {Town}/{City}, or Gather 1 {Town} into a land with {City}."
			},
			{
				zh: "每名玩家可以从 1 个没有 {City} 的格子移除至多 3 点生命的入侵者。",
				en: "Each player may Remove up to 3 Health worth of Invaders from a land without {City}."
			}
		]
	},
	tallTalesOfSavagery: {
		name: {
			zh: "野蛮的夸张传闻",
			en: "Tall Tales of Savagery"
		},
		levels: [
			{
				zh: "每名玩家从 1 个有 {Dahan} 的格子移除 1 个 {Explorer}。",
				en: "Each player Removes 1 {Explorer} from a land with {Dahan}."
			},
			{
				zh: "每名玩家从 1 个有 {Dahan} 的格子移除 2 个 {Explorer} 或 1 个 {Town}。",
				en: "Each player Removes 2 {Explorer} or 1 {Town} from a land with {Dahan}."
			},
			{
				zh: "在每个有 {Dahan} 的格子移除 2 个 {Explorer} 或 1 个 {Town};若在场 {Dahan} 至少有 2 个,再移除 1 个 {City}。",
				en: "In each land with {Dahan}, Remove 2 {Explorer} or 1 {Town}. If at least 2 {Dahan} are present, also Remove 1 {City}."
			}
		]
	},
	tradeSuffers: {
		name: {
			zh: "贸易受挫",
			en: "Trade Suffers"
		},
		levels: [
			{
				zh: "跳过在有 {City} 的格子的所有建造行动。",
				en: "Skip all Build Actions in lands with {City}."
			},
			{
				zh: "每名玩家可以在 1 个沿海格将 1 个 {Town} 降级。",
				en: "Each player may Downgrade 1 {Town} in a Coastal land."
			},
			{
				zh: "每名玩家可以在 1 个沿海格将 1 个 {Town}/{City} 降级。",
				en: "Each player may Downgrade 1 {Town}/{City} in a Coastal land."
			}
		]
	},
	waryOfTheInterior: {
		name: {
			zh: "警惕内陆",
			en: "Wary of the Interior"
		},
		levels: [
			{
				zh: "每名玩家从 1 个内陆格移除 1 个 {Explorer}。",
				en: "Each player Removes 1 {Explorer} from an Inland land."
			},
			{
				zh: "每名玩家从 1 个内陆格移除 1 个 {Explorer}/{Town}。",
				en: "Each player Removes 1 {Explorer}/{Town} from an Inland land."
			},
			{
				zh: "每名玩家从任意格移除 1 个 {Explorer}/{Town}。",
				en: "Each player Removes 1 {Explorer}/{Town} from any land."
			}
		]
	}
};
//#endregion
//#region src/games/spiritisland/state.ts
function Se(e) {
	let [t, n, r, i] = e;
	switch (e.length) {
		case 2: return [[`${t}2`, `${n}2`]];
		case 3: return [
			[`${t}1`, `${n}2`],
			[`${n}1`, `${r}2`],
			[`${r}1`, `${t}2`]
		];
		case 4: return [
			[`${t}1`, `${n}1`],
			[`${n}2`, `${r}0`],
			[`${r}1`, `${i}1`],
			[`${i}2`, `${t}0`]
		];
		default: return [];
	}
}
function Ce(e) {
	let t = {}, n = e.map((e) => ve.find((t) => t.id === e));
	for (let e of n) {
		let n = [...e.lands.map((e) => e.n), 0];
		for (let r of n) {
			let n = e.lands.find((e) => e.n === r), i = `${e.id}${r}`;
			t[i] = {
				id: i,
				board: e.id,
				n: r,
				terrain: r === 0 ? "Ocean" : n.terrain,
				adj: [],
				coastal: !1,
				explorers: n?.init.explorers ?? 0,
				towns: n?.init.towns ?? 0,
				cities: n?.init.cities ?? 0,
				dahan: n?.init.dahan ?? 0,
				blight: n?.init.blight ?? 0,
				presence: {},
				defend: 0,
				skipRavage: !1,
				skipBuild: !1,
				skipExplore: !1,
				isolate: !1,
				noBlight: !1,
				dahanGuard: !1,
				dahanSimul: !1
			};
		}
		for (let n of e.lands) for (let r of n.adjAll) t[`${e.id}${n.n}`].adj.push(`${e.id}${r}`);
		for (let n of e.lands.filter((e) => e.adjAll.includes(0))) t[`${e.id}0`].adj.push(`${e.id}${n.n}`);
	}
	for (let e of Object.values(t)) e.coastal = e.n !== 0 && e.adj.includes(`${e.board}0`);
	for (let [r, i] of Se(e)) {
		let e = r.slice(0, 1), a = Number(r.slice(1)), o = i.slice(0, 1), s = Number(i.slice(1)), c = n.find((t) => t.id === e).sides.filter((e) => e.side === a), l = n.find((e) => e.id === o).sides.filter((e) => e.side === s), u = (e, t, n) => {
			let r = e.filter((e) => e.s <= t && e.e >= t);
			return (n ? r[r.length - 1] : r[0])?.land;
		}, d = (e, n) => {
			t[e].adj.includes(n) || t[e].adj.push(n), t[n].adj.includes(e) || t[n].adj.push(e);
		}, f = u(c, 0, !1), p = u(l, 7, !1);
		f !== void 0 && p !== void 0 && d(`${e}${f}`, `${o}${p}`);
		for (let t = 1, n = 6; n >= 0; t += 1, --n) {
			let r = u(c, t, !1), i = u(l, n, !0);
			r !== void 0 && i !== void 0 && (r !== f && i !== p ? (f !== void 0 && d(`${e}${r}`, `${o}${p}`), p !== void 0 && d(`${e}${r}`, `${o}${i}`), f = r, p = i) : r === f ? i !== p && (f !== void 0 && d(`${e}${f}`, `${o}${i}`), p = i) : (p !== void 0 && d(`${e}${r}`, `${o}${p}`), f = r), f !== void 0 && p !== void 0 && d(`${e}${f}`, `${o}${p}`));
		}
	}
	return t;
}
function we(e, n) {
	let r = 0, i = (e) => {
		let i = [...e];
		for (let e = i.length - 1; e > 0; --e) {
			let a = t(n, r, e + 1);
			r += 1, [i[e], i[a]] = [i[a], i[e]];
		}
		return i;
	}, a = i([
		"A",
		"B",
		"C",
		"D"
	]).slice(0, e.length), o = Ce(a), s = be.filter((e) => e.stage === 1).map((e) => e.id), c = be.filter((e) => e.stage === 2).map((e) => e.id), l = [
		...i(i(be.filter((e) => e.stage === 3).map((e) => e.id)).slice(0, 3)),
		...i(c),
		...i(s)
	], u = i(Object.keys(xe)).slice(0, 9), d = ["downwardSpiral", "memoryFadesToDust"][t(n, r, 2)];
	return r += 1, {
		players: e,
		spiritOf: {},
		boards: a,
		lands: o,
		spirits: {},
		invader: {
			deck: l,
			discard: [],
			ravage: null,
			build: null,
			explore: null
		},
		minorDeck: i(ye.filter((e) => e.type === "minor").map((e) => e.id)),
		majorDeck: i(ye.filter((e) => e.type === "major").map((e) => e.id)),
		fear: {
			deck: u,
			earned: 0,
			poolMax: 4 * e.length,
			pending: [],
			resolving: null,
			resolved: []
		},
		blight: {
			pool: 2 * e.length + 1,
			card: d,
			flipped: !1
		},
		phase: "pick",
		round: 1,
		pending: {
			kind: "pickSpirit",
			seat: e[0],
			available: E.map((e) => e.id)
		},
		growthDone: {},
		playDone: {},
		queue: [],
		invaderStep: 0,
		chokeRavage: !1,
		chokeBuild: !1,
		terror: 1,
		over: null,
		dahanShield: !1,
		dreamConvert: !1,
		vengeance: [],
		vengeanceMute: !1,
		beatMs: 0,
		rngCursor: r,
		log: []
	};
}
function Te(e, t, n) {
	let r = E.find((e) => e.id === n);
	e.spiritOf[t] = n;
	let i = e.players.indexOf(t), a = e.boards[i];
	e.spirits[t] = {
		spirit: n,
		board: a,
		energy: 0,
		energyIdx: 0,
		playsIdx: 0,
		hand: [...r.uniques],
		discard: [],
		played: [],
		forgotten: [],
		bonusElems: [],
		playsBonus: 0,
		rangeBonus: 0,
		keepCard: 0,
		reclaimPending: 0,
		fastCards: [],
		destroyed: 0,
		drowned: 0,
		dead: !1
	}, De(e, t, n, a);
}
function Ee(e, t, n) {
	return Object.values(e.lands).filter((e) => e.board === t && e.terrain === n).sort((e, t) => t.n - e.n)[0].id;
}
function De(e, t, n, r) {
	let i = (n, r) => {
		e.lands[n].presence[t] = (e.lands[n].presence[t] ?? 0) + r;
	}, a = (t) => Ee(e, r, t), o = (t) => Object.values(e.lands).filter((e) => e.board === r && t(e)).sort((e, t) => t.n - e.n);
	switch (n) {
		case "lightningsSwiftStrike":
			i(a("Sands"), 2);
			break;
		case "bringerOfDreamsAndNightmares":
			i(a("Sands"), 2);
			break;
		case "riverSurgesInSunlight":
			i(a("Wetland"), 1);
			break;
		case "shadowsFlickerLikeFlame":
			i(a("Jungle"), 2), i(`${r}5`, 1);
			break;
		case "vitalStrengthOfTheEarth":
			i(a("Mountain"), 2), i(a("Jungle"), 1);
			break;
		case "aSpreadOfRampantGreen":
			i(a("Wetland"), 1), i((o((e) => e.terrain === "Jungle" && e.dahan === 0)[0] ?? o((e) => e.terrain === "Jungle")[0]).id, 1);
			break;
		case "thunderspeaker": {
			let e = o((e) => e.n !== 0 && e.dahan > 0).sort((e, t) => t.dahan - e.dahan || t.n - e.n).slice(0, 2);
			for (let t of e) i(t.id, 1);
			break;
		}
		case "oceansHungryGrasp": {
			i(`${r}0`, 1);
			let e = o((e) => e.coastal)[0];
			i(e.id, 1);
			break;
		}
	}
}
var D = Object.fromEntries(ye.map((e) => [e.id, e]));
//#endregion
//#region src/games/spiritisland/fx-events.ts
function O(e, t) {
	let n = e.queue[0], r = {
		...n ? {
			seat: n.seat,
			source: n.source
		} : {},
		...t
	};
	(e.visualEvents ??= []).push(r), t.land && (e.resolution = {
		land: t.land,
		kind: t.kind,
		source: r.source ?? ""
	});
}
function Oe(e) {
	let t = e.visualEvents ?? [];
	return delete e.visualEvents, e.over && (e.phase = "over", e.pending = null), {
		state: e,
		fx: t.length ? [{
			kind: "si:batch",
			data: { events: t }
		}] : []
	};
}
//#endregion
//#region src/games/spiritisland/effects.ts
function k(e) {
	return Object.values(e.lands);
}
function ke(e, t, n) {
	if (t === n) return 0;
	let r = /* @__PURE__ */ new Set([t]), i = [t], a = 0;
	for (; i.length;) {
		a += 1;
		let t = [];
		for (let n of i) for (let i of e.lands[n].adj) r.has(i) || (r.add(i), t.push(i));
		if (r.has(n)) return a;
		i = t;
	}
	return 99;
}
function Ae(e, t, n) {
	let r = e.spirits[t]?.spirit === "riverSurgesInSunlight";
	return k(e).filter((e) => (e.presence[t] ?? 0) >= (n ? 2 : 1) || n && r && e.terrain === "Wetland" && (e.presence[t] ?? 0) >= 1).map((e) => e.id);
}
var je = (e) => e.explorers + e.towns + e.cities > 0;
function Me(e, t, n) {
	switch (n) {
		case "AnyLand": return (e) => e.n !== 0;
		case "Coastal": return (e) => e.coastal;
		case "LandWithDahan": return (e) => e.n !== 0 && e.dahan > 0;
		case "LandWithInvaders": return (e) => e.n !== 0 && je(e);
		case "LandWithNoBlight": return (e) => e.n !== 0 && e.blight === 0;
		case "LandWithNoInvaders": return (e) => e.n !== 0 && !je(e);
		case "LandWithBlight": return (e) => e.n !== 0 && e.blight > 0;
		case "JungleWetland": return (e) => e.terrain === "Jungle" || e.terrain === "Wetland";
		case "MountainJungle": return (e) => e.terrain === "Mountain" || e.terrain === "Jungle";
		case "MountainWetland": return (e) => e.terrain === "Mountain" || e.terrain === "Wetland";
		case "JungleSands": return (e) => e.terrain === "Jungle" || e.terrain === "Sands";
		case "MountainSands": return (e) => e.terrain === "Mountain" || e.terrain === "Sands";
		case "SandsWetland": return (e) => e.terrain === "Sands" || e.terrain === "Wetland";
		default: return (e) => e.n !== 0;
	}
}
function Ne(e, t, n) {
	if (n.target === "AnySpirit" || n.target === "AnotherSpirit" || n.target === "None") return [];
	let r = Me(e, t, n.target), i = e.spirits[t]?.spirit === "oceansHungryGrasp" ? new Set(k(e).filter((e) => (e.presence[t] ?? 0) > 0).map((e) => e.board)) : null, a = (e) => !!i && e.n === 0 && i.has(e.board) && (n.target === "Coastal" || n.target === "AnyLand" || n.target === "JungleWetland" || n.target === "SandsWetland" || n.target === "MountainWetland");
	if (n.range === void 0 || n.range === null) return k(e).filter((e) => r(e) || a(e)).map((e) => e.id);
	let o = n.range + (e.spirits[t]?.rangeBonus ?? 0), s = Ae(e, t, !1), c = n.ss ? Ae(e, t, !0) : [];
	return k(e).filter((e) => r(e) || a(e)).filter((t) => [...s, ...c].some((n) => ke(e, n, t.id) <= o)).map((e) => e.id);
}
function Pe(e, t) {
	let n = e.spirits[t], r = {
		sun: 0,
		moon: 0,
		fire: 0,
		air: 0,
		water: 0,
		earth: 0,
		plant: 0,
		animal: 0
	}, i = 0, a = (e) => {
		if (e) {
			if (e === "any") i += 1;
			else for (let t of e) r[t] += 1;
		}
	};
	for (let e of n.played) a(D[e]?.elements);
	let o = Ie(e, t);
	for (let e of o.energyTrack.slice(0, n.energyIdx)) a(e.elem);
	for (let e of o.playsTrack.slice(0, n.playsIdx)) a(e.elem);
	for (let e of n.bonusElems) r[e] += 1;
	return {
		counts: r,
		any: i
	};
}
function Fe(e, t, n) {
	let { counts: r, any: i } = Pe(e, t), a = { ...r }, o = i, s = 0;
	for (let e of n) {
		let t = 0;
		for (let [n, r] of Object.entries(e.elems)) {
			let e = Math.min(a[n] ?? 0, r);
			a[n] = (a[n] ?? 0) - e, t += r - e;
		}
		if (t > o) break;
		o -= t, s += 1;
	}
	return s;
}
function Ie(e, t) {
	return E.find((n) => n.id === e.spirits[t].spirit);
}
function Le(e, t) {
	let n = e.spirits[t];
	return Ie(e, t).energyTrack[n.energyIdx]?.v ?? 0;
}
function Re(e, t) {
	let n = e.spirits[t];
	return (Ie(e, t).playsTrack[n.playsIdx]?.v ?? 0) + n.playsBonus;
}
function A(e, t, n, r) {
	if (t.ctx[n] !== void 0) return t.ctx[n];
	if (r.length === 0) return t.ctx[n] = "", "";
	e.pending ||= {
		kind: "land",
		seat: t.seat,
		why: `${t.source}:${n}`,
		key: n,
		legal: r
	};
}
function j(e, t, n) {
	if (t.ctx[n] !== void 0) return t.ctx[n];
	e.pending ||= {
		kind: "yesno",
		seat: t.seat,
		why: `${t.source}:${n}`,
		key: n
	};
}
function M(e, t, n, r, i, a = !1) {
	if (t.ctx[n] !== void 0) return t.ctx[n];
	if (!a && r.length <= i) return t.ctx[n] = r, r;
	!e.pending && r.length > 0 && (e.pending = {
		kind: "cards",
		seat: t.seat,
		why: `${t.source}:${n}`,
		key: n,
		cards: r,
		count: i,
		upto: a
	});
}
function N(e, t, n, r) {
	if (t.ctx[n] !== void 0) return t.ctx[n];
	if (r.length === 1) return t.ctx[n] = r[0], r[0];
	!e.pending && r.length > 0 && (e.pending = {
		kind: "spirit",
		seat: t.seat,
		why: `${t.source}:${n}`,
		key: n,
		spirits: r
	});
}
function ze(e, t, n) {
	if (t.ctx[n] !== void 0) return t.ctx[n];
	let r = e.spirits[t.seat], i = Ie(e, t.seat), a = i.energyTrack.length - r.energyIdx, o = i.playsTrack.length - r.playsIdx;
	if (a <= 0 && o <= 0) return t.ctx[n] = "energy", "energy";
	if (a <= 0) return t.ctx[n] = "plays", "plays";
	if (o <= 0) return t.ctx[n] = "energy", "energy";
	e.pending ||= {
		kind: "track",
		seat: t.seat,
		why: `${t.source}:${n}`,
		key: n
	};
}
function P(e, t, n, r, i, a, o) {
	if (t.ctx[n] !== void 0) return t.ctx[n];
	if (!o && i.length <= a) return t.ctx[n] = i, i;
	!e.pending && i.length > 0 && (e.pending = {
		kind: "pieces",
		seat: t.seat,
		why: `${t.source}:${n}`,
		key: n,
		land: r,
		legal: i,
		count: a,
		upto: o
	});
}
var Be = (e) => e === "city" ? 3 : e === "town" ? 2 : 1;
function F(e, t, n, r, i) {
	if (t.ctx[n] !== void 0) return t.ctx[n];
	let a = e.lands[r], o = [
		...Array(a.cities).fill({ type: "city" }),
		...Array(a.towns).fill({ type: "town" }),
		...Array(a.explorers).fill({ type: "explorer" })
	], s = o.reduce((e, t) => e + Be(t.type), 0);
	if (o.length === 0 || i <= 0) return t.ctx[n] = [], [];
	if (i >= s) return t.ctx[n] = o, o;
	if (new Set(o.map((e) => e.type)).size === 1) {
		let e = Math.floor(i / Be(o[0].type)), r = o.slice(0, e);
		return t.ctx[n] = r, r;
	}
	let c = i, l = 0;
	for (let e of [...o].sort((e, t) => Be(t.type) - Be(e.type))) Be(e.type) <= c && (c -= Be(e.type), l += 1);
	return P(e, t, n, r, o, l, !0);
}
function Ve(e, t) {
	for (t > 0 && O(e, {
		kind: "fear",
		n: t
	}), e.fear.earned += t; e.fear.earned >= e.fear.poolMax && e.fear.deck.length > 0;) {
		e.fear.earned -= e.fear.poolMax;
		let t = e.fear.deck.pop();
		e.fear.pending.push(t);
	}
	e.fear.deck.length === 0 && e.fear.earned >= 0 && e.fear.pending.length + e.fear.resolved.length >= 9 && !e.over && (e.over = {
		win: !0,
		reason: "fear"
	});
}
function I(e, t, n) {
	let r = e.lands[t], i = Ye(r, n);
	if (e.dreamConvert && n !== "dahan") {
		(n === "explorer" ? r.explorers : n === "town" ? r.towns : r.cities) > 0 && Ve(e, n === "city" ? 5 : n === "town" ? 2 : 0);
		return;
	}
	let a = !1;
	n === "explorer" && r.explorers > 0 ? (--r.explorers, a = !0) : n === "town" && r.towns > 0 ? (--r.towns, Ve(e, 1), a = !0) : n === "city" && r.cities > 0 ? (--r.cities, Ve(e, 2), a = !0) : n === "dahan" && r.dahan > 0 && (--r.dahan, a = !0), a && O(e, {
		kind: "destroy",
		land: t,
		piece: n,
		ordinal: i - 1
	}), a && n !== "explorer" && !e.vengeanceMute && e.vengeance.includes(t) && (e.vengeanceMute = !0, I(e, t, "explorer"), e.vengeanceMute = !1);
}
function L(e, t, n) {
	for (let r of n) I(e, t, r.type);
}
function He(e, t) {
	let n = e.lands[t];
	if (!n.noBlight) {
		if (n.blight > 0) {
			let t = n.adj.map((t) => e.lands[t]).filter((e) => e.n !== 0), r = t.filter((e) => e.blight === 0).sort((e, t) => e.id.localeCompare(t.id))[0] ?? t.sort((e, t) => e.id.localeCompare(t.id))[0];
			r && Ue(e, r.id);
		}
		Ue(e, t);
	}
}
function Ue(e, t) {
	if (e.blight.pool <= 0) {
		if (!e.blight.flipped) e.blight.flipped = !0, e.blight.pool = (e.blight.card === "downwardSpiral" ? 5 : 4) * e.players.length + 1;
		else if (!e.over) {
			e.over = {
				win: !1,
				reason: "blight"
			};
			return;
		}
	}
	if (e.blight.pool <= 0) return;
	--e.blight.pool;
	let n = e.lands[t];
	n.blight += 1, O(e, {
		kind: "place",
		land: t,
		piece: "blight",
		ordinal: n.blight - 1
	});
	for (let r of Object.keys(n.presence)) (n.presence[r] ?? 0) > 0 && We(e, t, r, 1);
}
function We(e, t, n, r) {
	let i = e.lands[t], a = i.presence[n] ?? 0;
	i.presence[n] = Math.max(0, a - r), a > 0 && O(e, {
		kind: "destroy",
		land: t,
		piece: `presence:${n}`,
		ordinal: a - 1,
		seat: n,
		n: Math.min(a, r)
	}), i.presence[n] === 0 && delete i.presence[n], e.spirits[n] && (e.spirits[n].destroyed += Math.min(a, r)), !k(e).some((e) => (e.presence[n] ?? 0) > 0) && !e.over && (e.spirits[n].dead = !0, e.over = {
		win: !1,
		reason: "presence"
	});
}
function Ge(e) {
	if (e.over) return;
	let t = 0, n = 0, r = 0;
	for (let i of k(e)) t += i.explorers + i.towns + i.cities, n += i.towns + i.cities, r += i.cities;
	(e.terror >= 3 && r === 0 || e.terror >= 2 && n === 0 || t === 0) && (e.over = {
		win: !0,
		reason: "invaders"
	});
}
var Ke = {};
function qe(e) {
	if (e.awaitingBeat) return;
	let t = 200;
	for (; e.queue.length > 0 && !e.pending && !e.over && t > 0;) {
		--t;
		let n = e.queue[0], r = Ke[n.source];
		if (!r) {
			e.queue.shift();
			continue;
		}
		e.dreamConvert = e.spirits[n.seat]?.spirit === "bringerOfDreamsAndNightmares" && (n.kind === "power" || n.kind === "innate");
		let i = e.visualEvents?.length ?? 0;
		if (r(e, n), e.dreamConvert = !1, e.awaitingBeat) return;
		if (!e.pending) {
			let t = Object.keys(n.ctx).some((e) => e.startsWith("done:")), r = (e.visualEvents?.length ?? 0) > i, a = typeof n.ctx.target == "string" ? n.ctx.target : typeof n.ctx.land == "string" ? n.ctx.land : void 0, o = e.visualEvents?.slice(i).some((e) => e.land);
			if ((!t || r) && O(e, {
				kind: "power",
				...a && !o ? { land: a } : {},
				seat: n.seat,
				source: n.source
			}), e.queue.shift(), Ge(e), !t || r) {
				e.awaitingBeat = !0;
				return;
			}
		}
	}
}
function R(e, t, n, r) {
	let i = `done:${n}`;
	if (t.ctx[i]) return !0;
	let a = typeof t.ctx.target == "string" ? t.ctx.target : typeof t.ctx.land == "string" ? t.ctx.land : void 0;
	return O(e, {
		kind: "power",
		...a ? { land: a } : {},
		seat: t.seat,
		source: t.source
	}), r(), t.ctx[i] = !0, e.awaitingBeat = !0, !1;
}
function z(e, t, n) {
	let r = `once:${t}`;
	e.ctx[r] || (n(), e.ctx[r] = !0);
}
function Je(e, t, n) {
	let r = Ne(e, t.seat, n), i = e.spirits[t.seat], a = i && !i.dead && i.spirit === "shadowsFlickerLikeFlame" && i.energy >= 1 ? k(e).filter((i) => i.dahan > 0 && !r.includes(i.id) && Me(e, t.seat, n.target)(i)).map((e) => e.id) : [];
	if (t.ctx.target !== void 0) {
		let e = t.ctx.target;
		return e && a.includes(e) && !t.ctx.shadowsPaid && (t.ctx.shadowsPaid = !0, --i.energy), e;
	}
	if (r.length === 0 && a.length === 0) return t.ctx.target = "", "";
	e.pending ||= {
		kind: "land",
		seat: t.seat,
		why: `${t.source}:target`,
		key: "target",
		legal: r,
		...a.length ? { shadows: a } : {}
	};
}
function Ye(e, t) {
	return t === "explorer" ? e.explorers : t === "town" ? e.towns : t === "city" ? e.cities : t === "dahan" ? e.dahan : 0;
}
function B(e, t, n, r) {
	let i = e.lands[t], a = {
		explorer: "explorers",
		town: "towns",
		city: "cities",
		dahan: "dahan"
	}[n], o = i[a], s = Math.max(0, o + r);
	i[a] = s;
	for (let i = 0; i < Math.abs(s - o); i++) O(e, {
		kind: r > 0 ? "place" : "remove",
		land: t,
		piece: n,
		ordinal: r > 0 ? o + i : o - i - 1
	});
}
function Xe(e, t, n, r, i) {
	let a = e.lands[t], o = e.lands[n];
	if (t === n) return;
	let s = r === "presence" && i ? (a.presence[i] ?? 0) - 1 : Ye(a, r) - 1;
	if (r === "presence" && i) {
		(a.presence[i] ?? 0) > 0 && (--a.presence[i], a.presence[i] === 0 && delete a.presence[i], o.presence[i] = (o.presence[i] ?? 0) + 1, O(e, {
			kind: "move",
			from: t,
			fromOrdinal: s,
			land: n,
			piece: `presence:${i}`,
			ordinal: o.presence[i] - 1,
			seat: i
		}));
		return;
	}
	if (!(Ye(a, r) <= 0)) {
		if (o.n === 0) {
			let i = Object.keys(o.presence).find((t) => e.spirits[t]?.spirit === "oceansHungryGrasp" && (o.presence[t] ?? 0) > 0);
			if (i && r !== "presence") {
				r === "explorer" ? (--a.explorers, e.spirits[i].drowned += 1) : r === "town" ? (--a.towns, Ve(e, 1), e.spirits[i].drowned += 2) : r === "city" ? (--a.cities, Ve(e, 2), e.spirits[i].drowned += 3) : r === "dahan" && --a.dahan, O(e, {
					kind: "move",
					from: t,
					fromOrdinal: s,
					land: n,
					piece: r,
					drowned: !0
				});
				return;
			}
		}
		r === "explorer" ? (--a.explorers, o.explorers += 1) : r === "town" ? (--a.towns, o.towns += 1) : r === "city" ? (--a.cities, o.cities += 1) : r === "dahan" && (--a.dahan, o.dahan += 1), O(e, {
			kind: "move",
			from: t,
			fromOrdinal: s,
			land: n,
			piece: r,
			ordinal: Ye(o, r) - 1
		});
	}
}
function V(e, t, n, r, i, a, o = !0) {
	let s = `${n}Pieces`, c = `${n}Dest`, l = t.ctx[s], u = t.ctx[c];
	if (l !== void 0 && u !== void 0) return u && l.some((e) => e.type === "dahan") && !Ze(e, t, `${n}Ally`, r, u) ? void 0 : u ? {
		pieces: l,
		dest: u
	} : {
		pieces: [],
		dest: ""
	};
	if (l === void 0) {
		let c = e.lands[r], l = i.flatMap((e) => Array(Ye(c, e)).fill({ type: e }));
		if (l.length === 0) return t.ctx[s] = [], {
			pieces: [],
			dest: ""
		};
		e.pending ||= {
			kind: "pieces",
			seat: t.seat,
			why: `${t.source}:${n}`,
			key: s,
			land: r,
			legal: l,
			count: a,
			upto: o
		};
		return;
	}
	if (l.length === 0) return {
		pieces: [],
		dest: ""
	};
	if (u === void 0) {
		e.pending ||= {
			kind: "land",
			seat: t.seat,
			why: `${t.source}:${n}:dest`,
			key: c,
			legal: e.lands[r].adj.filter((t) => e.lands[t].n !== 0)
		};
		return;
	}
}
function H(e, t, n, r, i) {
	for (let a of r) Xe(e, t, n, a.type, a.type === "presence" ? a.seat ?? i : void 0);
}
function Ze(e, t, n, r, i) {
	let a = `${n}Done`;
	if (t.ctx[a]) return !0;
	let o = e.players.find((t) => e.spirits[t]?.spirit === "thunderspeaker" && !e.spirits[t].dead);
	if (!(o && r !== i && e.lands[i].n !== 0 && (e.lands[r].presence[o] ?? 0) > 0)) return t.ctx[a] = !0, !0;
	let s = j(e, {
		...t,
		seat: o
	}, n);
	return s === void 0 ? (e.pending?.kind === "yesno" && (e.pending.why = `allyOfTheDahan:${r}:${i}`), !1) : (t.ctx[a] = !0, s && Xe(e, r, i, "presence", o), !0);
}
function U(e, t, n, r, i, a) {
	if (t.ctx[n] !== void 0) {
		let i = t.ctx[n], a = [...new Set(i.filter((e) => e.type === "dahan" && e.from).map((e) => e.from))];
		for (let i of a) if (!Ze(e, t, `${n}Ally:${i}`, i, r)) return;
		return i;
	}
	let o = e.lands[r].adj.flatMap((t) => i.flatMap((n) => Array(Ye(e.lands[t], n)).fill({
		type: n,
		from: t
	})));
	if (o.length === 0) return t.ctx[n] = [], [];
	e.pending ||= {
		kind: "pieces",
		seat: t.seat,
		why: `${t.source}:${n}`,
		key: n,
		land: r,
		legal: o,
		count: a,
		upto: !0
	};
}
function W(e, t, n) {
	for (let r of n) r.from && Xe(e, r.from, t, r.type, r.seat);
}
function Qe(e, t, n, r) {
	let i = e.spirits[t], a = Ie(e, t), o = n === "energy" ? a.energyTrack : a.playsTrack, s = n === "energy" ? "energyIdx" : "playsIdx";
	if (i[s] >= o.length) return;
	let c = o[i[s]];
	i[s] += 1, c?.reclaim && (i.hand.push(...i.discard), i.discard = []), e.lands[r].presence[t] = (e.lands[r].presence[t] ?? 0) + 1, O(e, {
		kind: "place",
		land: r,
		piece: `presence:${t}`,
		ordinal: e.lands[r].presence[t] - 1,
		seat: t
	});
}
function $e(e, t) {
	let n = e.lands[t];
	n.blight > 0 && (--n.blight, e.blight.pool += 1, O(e, {
		kind: "remove",
		land: t,
		piece: "blight",
		ordinal: n.blight
	}));
}
function et(e, t, n, r, i) {
	let a = e.lands[t], o = Ye(a, n);
	if (n === "explorer" && a.explorers > 0) --a.explorers;
	else if (n === "town" && a.towns > 0) --a.towns;
	else if (n === "city" && a.cities > 0) --a.cities;
	else if (n === "dahan" && a.dahan > 0) --a.dahan;
	else return;
	r === "explorer" ? a.explorers += 1 : r === "town" ? a.towns += 1 : r === "city" ? a.cities += 1 : r === "dahan" ? a.dahan += 1 : r === "presence" && i && (a.presence[i] = (a.presence[i] ?? 0) + 1), O(e, {
		kind: "remove",
		land: t,
		piece: n,
		ordinal: o - 1
	}), O(e, {
		kind: "place",
		land: t,
		piece: r === "presence" ? `presence:${i}` : r,
		ordinal: r === "presence" && i ? a.presence[i] - 1 : Ye(a, r) - 1
	});
}
//#endregion
//#region src/games/spiritisland/types.ts
var tt = [
	"sun",
	"moon",
	"fire",
	"air",
	"water",
	"earth",
	"plant",
	"animal"
], nt = (e) => D[e];
function G(e, t) {
	return Je(e, t, nt(t.source)) || null;
}
function K(e, t) {
	Ve(e, t);
}
var rt = {
	callOfTheDahanWays(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n], i = P(e, t, "rep", n, [...Array(r.explorers).fill({ type: "explorer" }), ...Array(r.towns).fill({ type: "town" })], 1, !1);
		i && z(t, "callOfTheDahanWays:0", () => {
			i.length && (I(e, n, i[0].type), B(e, n, "dahan", 1));
		});
	},
	callToBloodshed(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n];
		if (t.ctx.canChoose ??= r.dahan > 0 && r.adj.some((t) => e.lands[t].dahan > 0)) {
			let r = j(e, t, "mode");
			if (r === void 0) return;
			if (!r) {
				let r = U(e, t, "gather", n, ["dahan"], 3);
				!r || R(e, t, "callToBloodshed:0", () => {
					W(e, n, r);
				});
				return;
			}
		}
		if (r.dahan === 0) return;
		let i = F(e, t, "dmg", n, r.dahan);
		i && R(e, t, "callToBloodshed:1", () => {
			L(e, n, i);
		});
	},
	callToIsolation(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n];
		if (t.ctx.canPushInv ??= r.explorers + r.towns > 0 && r.dahan > 0) {
			let i = j(e, t, "mode");
			if (i === void 0) return;
			if (i) {
				let i = V(e, t, "push", n, ["explorer", "town"], r.dahan);
				!i || i.dest && R(e, t, "callToIsolation:2", () => {
					H(e, n, i.dest, i.pieces);
				});
				return;
			}
		}
		let i = V(e, t, "pushD", n, ["dahan"], 1);
		i && (!i.dest || R(e, t, "callToIsolation:3", () => {
			H(e, n, i.dest, i.pieces);
		}));
	},
	callToMigrate(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = U(e, t, "gather", n, ["dahan"], 3);
		if (!r || !R(e, t, "callToMigrate:4", () => {
			W(e, n, r);
		})) return;
		let i = V(e, t, "push", n, ["dahan"], 3);
		i && (!i.dest || R(e, t, "callToMigrate:5", () => {
			H(e, n, i.dest, i.pieces);
		}));
	},
	callToTend(e, t) {
		let n = G(e, t);
		if (!n) return;
		if (e.lands[n].blight > 0) {
			let r = j(e, t, "mode");
			if (r === void 0) return;
			if (r) {
				z(t, "callToTend:1", () => {
					$e(e, n);
				});
				return;
			}
		}
		let r = V(e, t, "push", n, ["dahan"], 3);
		r && (!r.dest || R(e, t, "callToTend:6", () => {
			H(e, n, r.dest, r.pieces);
		}));
	},
	darkAndTangledWoods(e, t) {
		let n = G(e, t);
		if (!n || !R(e, t, "darkAndTangledWoods:7", () => {
			K(e, 2);
		})) return;
		let r = e.lands[n].terrain;
		r !== "Mountain" && r !== "Jungle" || R(e, t, "darkAndTangledWoods:8", () => {
			e.lands[n].defend += 3;
		});
	},
	delusionsOfDanger(e, t) {
		let n = G(e, t);
		if (n) {
			if (e.lands[n].explorers > 0) {
				let r = j(e, t, "mode");
				if (r === void 0) return;
				if (r) {
					let r = V(e, t, "push", n, ["explorer"], 1, !1);
					!r || r.dest && R(e, t, "delusionsOfDanger:9", () => {
						H(e, n, r.dest, r.pieces);
					});
					return;
				}
			}
			R(e, t, "delusionsOfDanger:10", () => {
				K(e, 2);
			});
		}
	},
	devouringAnts(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n];
		if (!R(e, t, "devouringAnts:11", () => {
			K(e, 1);
		})) return;
		let i = r.terrain, a = F(e, t, "dmg", n, i === "Jungle" || i === "Sands" ? 2 : 1);
		a && R(e, t, "devouringAnts:12", () => {
			L(e, n, a);
		}) && z(t, "devouringAnts:2", () => {
			r.dahan > 0 && I(e, n, "dahan");
		});
	},
	driftDownIntoSlumber(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n].terrain;
		R(e, t, "driftDownIntoSlumber:13", () => {
			e.lands[n].defend += r === "Jungle" || r === "Sands" ? 4 : 1;
		});
	},
	drought(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n];
		z(t, "drought:3", () => {
			for (let t = 0; t < 3 && r.towns > 0; t += 1) I(e, n, "town");
		}), z(t, "drought:4", () => {
			He(e, n);
		}), (t.ctx.level ?? 0) >= 1 && r.cities > 0 && z(t, "drought:5", () => {
			I(e, n, "city");
		});
	},
	elementalBoon(e, t) {
		let n = N(e, t, "spirit", e.players.filter((t) => !e.spirits[t].dead));
		if (!n) return;
		let r = M(e, t, "elems", [...tt], 3);
		r && (z(t, "elementalBoon:6", () => {
			e.spirits[n].bonusElems.push(...r);
		}), z(t, "elementalBoon:7", () => {
			n !== t.seat && e.spirits[t.seat].bonusElems.push(...r);
		}));
	},
	encompassingWard(e, t) {
		let n = N(e, t, "spirit", e.players.filter((t) => !e.spirits[t].dead));
		n && z(t, "encompassingWard:8", () => {
			for (let t of Object.values(e.lands)) (t.presence[n] ?? 0) > 0 && (t.defend += 2);
		});
	},
	enticingSplendor(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = t.ctx.canInv ??= e.lands[n].adj.some((t) => e.lands[t].explorers + e.lands[t].towns > 0), i = t.ctx.canDahan ??= e.lands[n].adj.some((t) => e.lands[t].dahan > 0);
		if (r && i) {
			let r = j(e, t, "mode");
			if (r === void 0) return;
			if (r) {
				let r = U(e, t, "gather", n, ["explorer", "town"], 1);
				!r || R(e, t, "enticingSplendor:14", () => {
					W(e, n, r);
				});
				return;
			}
		} else if (r) {
			let r = U(e, t, "gather", n, ["explorer", "town"], 1);
			!r || R(e, t, "enticingSplendor:15", () => {
				W(e, n, r);
			});
			return;
		}
		let a = U(e, t, "gatherD", n, ["dahan"], 2);
		a && R(e, t, "enticingSplendor:16", () => {
			W(e, n, a);
		});
	},
	entrancingApparitions(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n];
		if (R(e, t, "entrancingApparitions:17", () => {
			r.defend += 2;
		}) && r.explorers + r.towns + r.cities === 0) {
			let r = U(e, t, "gather", n, ["explorer"], 2);
			if (!r || !R(e, t, "entrancingApparitions:18", () => {
				W(e, n, r);
			})) return;
		}
	},
	giftOfConstancy(e, t) {
		let n = N(e, t, "spirit", e.players.filter((t) => !e.spirits[t].dead));
		n && R(e, t, "giftOfConstancy:19", () => {
			e.spirits[n].energy += 2;
		}) && R(e, t, "giftOfConstancy:20", () => {
			e.spirits[n].keepCard += 1;
		}) && (n === t.seat || R(e, t, "giftOfConstancy:21", () => {
			e.spirits[t.seat].keepCard += 1;
		}));
	},
	giftOfLivingEnergy(e, t) {
		let n = N(e, t, "spirit", e.players.filter((t) => !e.spirits[t].dead));
		n && R(e, t, "giftOfLivingEnergy:22", () => {
			e.spirits[n].energy += 1;
		}) && (Object.values(e.lands).filter((e) => (e.presence[t.seat] ?? 0) >= 2).length >= 2 && !R(e, t, "giftOfLivingEnergy:23", () => {
			e.spirits[n].energy += 1;
		}) || n === t.seat || R(e, t, "giftOfLivingEnergy:24", () => {
			e.spirits[n].energy += 1;
		}));
	},
	giftOfPower(e, t) {
		let n = N(e, t, "spirit", e.players.filter((t) => !e.spirits[t].dead));
		if (!n) return;
		let r = t.ctx.drawn;
		if (!r && (r = e.minorDeck.splice(Math.max(0, e.minorDeck.length - 4)), t.ctx.drawn = r, r.length === 0)) return;
		let i = M(e, {
			...t,
			seat: n
		}, "keep", r, 1);
		i && z(t, "giftOfPower:10", () => {
			e.spirits[n].hand.push(...i);
		});
	},
	gnawingRootbiters(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = V(e, t, "push", n, ["town"], 2);
		r && (!r.dest || R(e, t, "gnawingRootbiters:25", () => {
			H(e, n, r.dest, r.pieces);
		}));
	},
	landOfHauntsAndEmbers(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n];
		if (!R(e, t, "landOfHauntsAndEmbers:26", () => {
			K(e, 2);
		})) return;
		let i = V(e, t, "push1", n, ["explorer", "town"], 2);
		if (i && (!i.dest || R(e, t, "landOfHauntsAndEmbers:27", () => {
			H(e, n, i.dest, i.pieces);
		}))) {
			if (r.blight > 0) {
				if (!R(e, t, "landOfHauntsAndEmbers:28", () => {
					K(e, 2);
				})) return;
				let r = V(e, t, "push2", n, ["explorer", "town"], 2);
				if (!r || r.dest && !R(e, t, "landOfHauntsAndEmbers:29", () => {
					H(e, n, r.dest, r.pieces);
				})) return;
			}
			z(t, "landOfHauntsAndEmbers:11", () => {
				He(e, n);
			});
		}
	},
	lureOfTheUnknown(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = U(e, t, "gather", n, ["explorer", "town"], 1);
		r && R(e, t, "lureOfTheUnknown:30", () => {
			W(e, n, r);
		});
	},
	naturesResilience(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n];
		if (r.blight > 0) {
			let r = j(e, t, "mode");
			if (r === void 0) return;
			if (r) {
				z(t, "naturesResilience:12", () => {
					$e(e, n);
				});
				return;
			}
		}
		R(e, t, "naturesResilience:31", () => {
			r.defend += 6;
		});
	},
	pullBeneathTheHungryEarth(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n], i = 0;
		if ((r.presence[t.seat] ?? 0) > 0) {
			if (!R(e, t, "pullBeneathTheHungryEarth:32", () => {
				K(e, 1);
			})) return;
			i += 1;
		}
		let a = r.terrain;
		(a === "Sands" || a === "Wetland") && (i += 1);
		let o = F(e, t, "dmg", n, i);
		o && R(e, t, "pullBeneathTheHungryEarth:33", () => {
			L(e, n, o);
		});
	},
	purifyingFlame(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n], i = r.terrain;
		if ((i === "Mountain" || i === "Sands") && r.blight > 0) {
			let r = j(e, t, "mode");
			if (r === void 0) return;
			if (r) {
				z(t, "purifyingFlame:13", () => {
					$e(e, n);
				});
				return;
			}
		}
		if (r.blight === 0) return;
		let a = F(e, t, "dmg", n, r.blight);
		a && R(e, t, "purifyingFlame:34", () => {
			L(e, n, a);
		});
	},
	quickenTheEarthsStruggles(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n];
		if (r.towns + r.cities > 0) {
			let n = j(e, t, "mode");
			n === void 0 || n || R(e, t, "quickenTheEarthsStruggles:35", () => {
				r.defend += 10;
			});
			return;
		}
		R(e, t, "quickenTheEarthsStruggles:36", () => {
			r.defend += 10;
		});
	},
	rainOfBlood(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n];
		R(e, t, "rainOfBlood:37", () => {
			K(e, r.towns + r.cities >= 2 ? 3 : 2);
		});
	},
	reachingGrasp(e, t) {
		let n = N(e, t, "spirit", e.players.filter((t) => !e.spirits[t].dead));
		n && z(t, "reachingGrasp:14", () => {
			e.spirits[n].rangeBonus += 2;
		});
	},
	rouseTheTreesAndStones(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = F(e, t, "dmg", n, 2);
		if (!r || !R(e, t, "rouseTheTreesAndStones:38", () => {
			L(e, n, r);
		})) return;
		let i = V(e, t, "push", n, ["explorer"], 1);
		i && (!i.dest || R(e, t, "rouseTheTreesAndStones:39", () => {
			H(e, n, i.dest, i.pieces);
		}));
	},
	sapTheStrengthOfMultitudes(e, t) {
		let n = G(e, t);
		n && R(e, t, "sapTheStrengthOfMultitudes:40", () => {
			e.lands[n].defend += 5;
		});
	},
	savageMawbeasts(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n].terrain, i = r === "Jungle" || r === "Wetland";
		if (i && !R(e, t, "savageMawbeasts:41", () => {
			K(e, 1);
		})) return;
		let a = F(e, t, "dmg", n, i ? 2 : 1);
		a && R(e, t, "savageMawbeasts:42", () => {
			L(e, n, a);
		});
	},
	shadowsOfTheBurningForest(e, t) {
		let n = G(e, t);
		if (!n || !R(e, t, "shadowsOfTheBurningForest:43", () => {
			K(e, 2);
		})) return;
		let r = e.lands[n].terrain;
		if (r === "Mountain" || r === "Jungle") {
			let r = V(e, t, "pushE", n, ["explorer"], 1);
			if (!r || r.dest && !R(e, t, "shadowsOfTheBurningForest:44", () => {
				H(e, n, r.dest, r.pieces);
			})) return;
			let i = V(e, t, "pushT", n, ["town"], 1);
			if (!i || i.dest && !R(e, t, "shadowsOfTheBurningForest:45", () => {
				H(e, n, i.dest, i.pieces);
			})) return;
		}
	},
	songOfSanctity(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n];
		if (t.ctx.canPush ??= r.explorers > 0) {
			let i = V(e, t, "push", n, ["explorer"], r.explorers, !1);
			if (!i || i.dest && !R(e, t, "songOfSanctity:46", () => {
				H(e, n, i.dest, i.pieces);
			})) return;
		} else z(t, "songOfSanctity:15", () => {
			r.blight > 0 && $e(e, n);
		});
	},
	steamVents(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n], i = P(e, t, "kill", n, [...Array(r.explorers).fill({ type: "explorer" }), ...Array(r.towns).fill({ type: "town" })], 1, !1);
		i && z(t, "steamVents:16", () => {
			i.length && I(e, n, i[0].type);
		});
	},
	uncannyMelting(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n];
		if (r.explorers + r.towns + r.cities > 0 && !R(e, t, "uncannyMelting:47", () => {
			K(e, 1);
		})) return;
		let i = r.terrain;
		z(t, "uncannyMelting:17", () => {
			(i === "Sands" || i === "Wetland") && r.blight > 0 && $e(e, n);
		});
	},
	veilTheNightsHunt(e, t) {
		let n = G(e, t);
		if (!n) return;
		let r = e.lands[n];
		if (t.ctx.canHunt ??= r.dahan > 0 && r.explorers + r.towns + r.cities > 0) {
			let i = j(e, t, "mode");
			if (i === void 0) return;
			if (i) {
				let i = F(e, t, "dmg", n, r.dahan);
				!i || R(e, t, "veilTheNightsHunt:48", () => {
					L(e, n, i);
				});
				return;
			}
		}
		let i = V(e, t, "push", n, ["dahan"], 3);
		i && (!i.dest || R(e, t, "veilTheNightsHunt:49", () => {
			H(e, n, i.dest, i.pieces);
		}));
	},
	visionsOfFieryDoom(e, t) {
		let n = G(e, t);
		if (!n || !R(e, t, "visionsOfFieryDoom:50", () => {
			K(e, 1);
		}) || (t.ctx.level ?? 0) >= 1 && !R(e, t, "visionsOfFieryDoom:51", () => {
			K(e, 1);
		})) return;
		let r = V(e, t, "push", n, ["explorer", "town"], 1);
		r && (!r.dest || R(e, t, "visionsOfFieryDoom:52", () => {
			H(e, n, r.dest, r.pieces);
		}));
	},
	voraciousGrowth(e, t) {
		let n = G(e, t);
		if (!n) return;
		if (e.lands[n].blight > 0) {
			let r = j(e, t, "mode");
			if (r === void 0) return;
			if (!r) {
				z(t, "voraciousGrowth:18", () => {
					$e(e, n);
				});
				return;
			}
		}
		let r = F(e, t, "dmg", n, 2);
		r && R(e, t, "voraciousGrowth:53", () => {
			L(e, n, r);
		});
	}
}, it = (e) => D[e];
function q(e, t) {
	return Je(e, t, it(t.source)) || null;
}
var J = (e, t) => Ve(e, t);
function at(e, t, n, r = !1) {
	let i = e.lands[t], a = n, o = 0;
	for (let [n, s] of [
		["city", 3],
		["town", 2],
		["explorer", 1]
	]) for (; a >= s;) {
		let c = i.cities + i.towns + i.explorers;
		if (r && (e.vengeanceMute = !0), I(e, t, n), e.vengeanceMute = !1, i.cities + i.towns + i.explorers === c) break;
		a -= s, o += 1;
	}
	return o;
}
function ot(e, t, n) {
	let r = e.lands[t], i = 0, a = (n, r) => {
		for (let a = 0; a < r; a += 1) I(e, t, n), i += 1;
	};
	return n >= 3 && a("city", r.cities), n >= 2 && a("town", r.towns), n >= 1 && a("explorer", r.explorers), i;
}
var st = (e, t) => {
	let n = e.lands[t];
	return n.explorers + n.towns + n.cities;
}, ct = {
	acceleratedRot(e, t) {
		let n = q(e, t);
		if (!n || !R(e, t, "acceleratedRot:0", () => {
			J(e, 2);
		})) return;
		let r = F(e, t, "dmg", n, 4);
		if (r && R(e, t, "acceleratedRot:1", () => {
			L(e, n, r);
		}) && (t.ctx.level ?? 0) >= 1) {
			let r = F(e, t, "dmg2", n, 5);
			if (!r || !R(e, t, "acceleratedRot:2", () => {
				L(e, n, r);
			})) return;
			z(t, "acceleratedRot:0", () => {
				$e(e, n);
			});
		}
	},
	blazingRenewal(e, t) {
		let n = N(e, t, "spirit", e.players.filter((t) => !e.spirits[t].dead));
		if (!n) return;
		let r = e.spirits[n], i = k(e).filter((e) => (e.presence[t.seat] ?? 0) > 0).map((e) => e.id), a = k(e).filter((t) => t.n !== 0 && i.some((n) => ke(e, n, t.id) <= 2)).map((e) => e.id), o = t.ctx.land ?? (r.destroyed > 0 ? A(e, t, "land", a) : "");
		if (o !== void 0 && o && R(e, t, "restore", () => {
			let i = Math.min(2, r.destroyed);
			t.ctx.added = i, r.destroyed -= i;
			let a = e.lands[o], s = a.presence[n] ?? 0;
			a.presence[n] = s + i;
			for (let t = 0; t < i; t++) O(e, {
				kind: "place",
				land: o,
				seat: n,
				piece: `presence:${n}`,
				ordinal: s + t
			});
		}) && !(t.ctx.added <= 0) && R(e, t, "townDamage", () => {
			let t = e.lands[o];
			for (let n = 0; n < t.towns; n++) I(e, o, "town");
		}) && (t.ctx.level ?? 0) >= 1) {
			let n = F(e, t, "dmg", o, 4);
			if (!n) return;
			L(e, o, n);
		}
	},
	cleansingFloods(e, t) {
		let n = q(e, t);
		if (!n) return;
		let r = F(e, t, "dmg", n, 4);
		if (r && R(e, t, "cleansingFloods:4", () => {
			L(e, n, r);
		}) && (z(t, "cleansingFloods:3", () => {
			$e(e, n);
		}), (t.ctx.level ?? 0) >= 1)) {
			let r = F(e, t, "dmg2", n, 10);
			if (!r || !R(e, t, "cleansingFloods:5", () => {
				L(e, n, r);
			})) return;
		}
	},
	dissolveTheBondsOfKinship(e, t) {
		let n = q(e, t);
		if (!n) return;
		let r = e.lands[n];
		if (!R(e, t, "replace", () => {
			r.cities > 0 && (B(e, n, "city", -1), B(e, n, "explorer", 2)), r.towns > 0 && (B(e, n, "town", -1), B(e, n, "explorer", 1)), r.dahan > 0 && (B(e, n, "dahan", -1), B(e, n, "explorer", 1));
		}) || (t.ctx.level ?? 0) >= 1 && !R(e, t, "mutualDamage", () => {
			let t = r.towns * 2 + r.cities * 3, i = r.explorers;
			B(e, n, "explorer", -t), at(e, n, i);
		})) return;
		let i = 50;
		for (; r.explorers > 0 && i > 0;) {
			--i;
			let t = r.adj.map((t) => e.lands[t]).filter((e) => e.n !== 0).sort((e, t) => e.explorers - t.explorers || e.id.localeCompare(t.id));
			if (!t.length) break;
			Xe(e, n, t[0].id, "explorer");
		}
	},
	entwinedPower(e, t) {
		let n = N(e, t, "spirit", e.players.filter((n) => !e.spirits[n].dead && n !== t.seat));
		if (!n) return;
		let r = t.ctx.drawn;
		if (!r && (r = e.minorDeck.splice(Math.max(0, e.minorDeck.length - 4)), t.ctx.drawn = r, r.length === 0)) return;
		let i = M(e, {
			...t,
			seat: n
		}, "keep", r, 1);
		if (!i) return;
		z(t, "entwinedPower:10", () => {
			e.spirits[n].hand.push(...i);
		});
		let a = M(e, t, "mine", r.filter((e) => !i.includes(e)), 1);
		if (a && (z(t, "entwinedPower:11", () => {
			e.spirits[t.seat].hand.push(...a);
		}), (t.ctx.level ?? 0) >= 1)) {
			if (!R(e, t, "entwinedPower:6", () => {
				e.spirits[n].energy += 3;
			}) || !R(e, t, "entwinedPower:7", () => {
				e.spirits[t.seat].energy += 3;
			})) return;
			let r = M(e, t, "gift", e.spirits[t.seat].hand, 1, !0);
			if (!r) return;
			z(t, "entwinedPower:12", () => {
				for (let i of r) e.spirits[t.seat].hand.splice(e.spirits[t.seat].hand.indexOf(i), 1), e.spirits[n].hand.push(i);
			});
		}
	},
	indomitableClaim(e, t) {
		let n = q(e, t);
		if (!n) return;
		let r = e.spirits[t.seat], i = Ie(e, t.seat), a = r.energyIdx < i.energyTrack.length ? "energy" : "plays", o = a === "energy" ? i.energyTrack : i.playsTrack, s = a === "energy" ? "energyIdx" : "playsIdx";
		if (z(t, "indomitablePresence", () => {
			r[s] < o.length && Qe(e, t.seat, a, n);
		}), R(e, t, "indomitableClaim:8", () => {
			e.lands[n].defend += 20;
		}) && (t.ctx.level ?? 0) >= 1) {
			if (st(e, n) > 0 && !R(e, t, "indomitableClaim:9", () => {
				J(e, 3);
			})) return;
			z(t, "indomitableClaim:14", () => {
				e.lands[n].skipRavage = !0;
			}), z(t, "indomitableClaim:15", () => {
				e.lands[n].skipBuild = !0;
			}), z(t, "indomitableClaim:16", () => {
				e.lands[n].skipExplore = !0;
			});
		}
	},
	infiniteVitality(e, t) {
		let n = q(e, t);
		if (!n) return;
		let r = e.lands[n];
		if (z(t, "infiniteVitality:17", () => {
			r.dahanGuard = !0;
		}), z(t, "infiniteVitality:18", () => {
			r.noBlight = !0;
		}), (t.ctx.level ?? 0) >= 1) {
			let i = A(e, t, "blight", [n, ...r.adj].filter((t) => e.lands[t].blight > 0));
			if (!i) return;
			z(t, "infiniteVitality:19", () => {
				$e(e, i);
			});
		}
	},
	mistsOfOblivion(e, t) {
		let n = q(e, t);
		if (!n) return;
		z(t, "mistsOfOblivion:20", () => {
			ot(e, n, 1);
		});
		let r = F(e, t, "dmg", n, 3);
		r && R(e, t, "mistsOfOblivion:10", () => {
			L(e, n, r);
		});
	},
	paralyzingFright(e, t) {
		let n = q(e, t);
		if (!n || !R(e, t, "paralyzingFright:11", () => {
			J(e, 4);
		})) return;
		let r = e.lands[n];
		z(t, "paralyzingFright:21", () => {
			r.skipRavage = !0;
		}), z(t, "paralyzingFright:22", () => {
			r.skipBuild = !0;
		}), z(t, "paralyzingFright:23", () => {
			r.skipExplore = !0;
		}), (t.ctx.level ?? 0) >= 1 && R(e, t, "paralyzingFright:12", () => {
			J(e, 4);
		});
	},
	pillarOfLivingFlame(e, t) {
		let n = q(e, t);
		if (!n || !R(e, t, "pillarOfLivingFlame:13", () => {
			J(e, 3);
		})) return;
		let r = F(e, t, "dmg", n, 5);
		if (!r || !R(e, t, "pillarOfLivingFlame:14", () => {
			L(e, n, r);
		})) return;
		let i = e.lands[n].terrain;
		if (z(t, "pillarOfLivingFlame:24", () => {
			(i === "Jungle" || i === "Wetland") && He(e, n);
		}), (t.ctx.level ?? 0) >= 1) {
			if (!R(e, t, "pillarOfLivingFlame:15", () => {
				J(e, 2);
			})) return;
			let r = F(e, t, "dmg2", n, 5);
			if (!r || !R(e, t, "pillarOfLivingFlame:16", () => {
				L(e, n, r);
			})) return;
		}
	},
	poisonedLand(e, t) {
		let n = q(e, t);
		if (!n || !R(e, t, "poisonedLand:17", () => {
			J(e, 1);
		})) return;
		let r = F(e, t, "dmg", n, 7);
		if (r && R(e, t, "poisonedLand:18", () => {
			L(e, n, r);
		}) && (t.ctx.level ?? 0) >= 1) {
			z(t, "poisonedLand:25", () => {
				He(e, n);
			});
			let r = e.lands[n];
			z(t, "poisonedLand:26", () => {
				for (let t = 0; t < r.dahan; t += 1) I(e, n, "dahan");
			});
			let i = r.blight;
			if (!R(e, t, "poisonedLand:19", () => {
				J(e, i);
			})) return;
			let a = F(e, t, "dmg2", n, 4 * i);
			if (!a || !R(e, t, "poisonedLand:20", () => {
				L(e, n, a);
			})) return;
		}
	},
	powerstorm(e, t) {
		let n = N(e, t, "spirit", e.players.filter((t) => !e.spirits[t].dead));
		if (!n) return;
		let r = e.spirits[n];
		if (!R(e, t, "powerstorm:21", () => {
			r.energy += 3;
		})) return;
		let i = (t.ctx.level ?? 0) >= 1 ? 2 : 1, a = r.played.filter((e) => e !== t.source), o = M(e, {
			...t,
			seat: n
		}, "rep", a, i, !0);
		o && z(t, "powerstorm:27", () => {
			for (let t of o) {
				let i = D[t]?.cost ?? 0;
				r.energy < i || (r.energy -= i, e.queue.push({
					seat: n,
					source: t,
					kind: "power",
					stepsLeft: 0,
					ctx: {}
				}));
			}
		});
	},
	talonsOfLightning(e, t) {
		let n = q(e, t);
		if (!n || !R(e, t, "talonsOfLightning:22", () => {
			J(e, 3);
		})) return;
		let r = F(e, t, "dmg", n, 5);
		r && R(e, t, "talonsOfLightning:23", () => {
			L(e, n, r);
		}) && (t.ctx.level ?? 0) >= 1 && z(t, "talonsOfLightning:28", () => {
			for (let t of e.lands[n].adj) I(e, t, "town");
		});
	},
	terrifyingNightmares(e, t) {
		let n = q(e, t);
		if (!n || !R(e, t, "terrifyingNightmares:24", () => {
			J(e, 2);
		})) return;
		let r = V(e, t, "push", n, ["explorer", "town"], 4);
		r && (!r.dest || R(e, t, "terrifyingNightmares:25", () => {
			H(e, n, r.dest, r.pieces);
		})) && (t.ctx.level ?? 0) >= 1 && R(e, t, "terrifyingNightmares:26", () => {
			J(e, 4);
		});
	},
	theJungleHungers(e, t) {
		let n = q(e, t);
		if (!n) return;
		let r = e.lands[n], i = t.ctx.level ?? 0;
		z(t, "theJungleHungers:29", () => {
			for (let t = 0; t < r.explorers; t += 1) I(e, n, "explorer");
		}), z(t, "theJungleHungers:30", () => {
			for (let t = 0; t < r.towns; t += 1) I(e, n, "town");
		}), z(t, "theJungleHungers:31", () => {
			if (i >= 1) I(e, n, "city");
			else for (let t = 0; t < r.dahan; t += 1) I(e, n, "dahan");
		});
	},
	theLandThrashesInFuriousPain(e, t) {
		let n = q(e, t);
		if (!n) return;
		let r = e.lands[n].blight, i = F(e, t, "dmg", n, 2 * r);
		if (i && R(e, t, "theLandThrashesInFuriousPain:27", () => {
			L(e, n, i);
		}) && (t.ctx.level ?? 0) >= 1) {
			let r = A(e, t, "again", e.lands[n].adj.filter((t) => e.lands[t].blight > 0));
			if (!r) return;
			z(t, "theLandThrashesInFuriousPain:32", () => {
				r && e.queue.push({
					seat: t.seat,
					source: t.source,
					kind: "power",
					stepsLeft: 0,
					ctx: {
						target: r,
						level: 0
					}
				});
			});
		}
	},
	theTreesAndStonesSpeakOfWar(e, t) {
		let n = q(e, t);
		if (!n) return;
		let r = e.lands[n], i = F(e, t, "dmg", n, r.dahan);
		if (i && R(e, t, "theTreesAndStonesSpeakOfWar:28", () => {
			L(e, n, i);
		}) && R(e, t, "theTreesAndStonesSpeakOfWar:29", () => {
			r.defend += 2 * r.dahan;
		}) && (t.ctx.level ?? 0) >= 1) {
			let r = V(e, t, "push", n, ["dahan"], 2);
			if (!r || r.dest && !R(e, t, "theTreesAndStonesSpeakOfWar:30", () => {
				H(e, n, r.dest, r.pieces);
			})) return;
		}
	},
	tsunami(e, t) {
		let n = q(e, t);
		if (!n || !R(e, t, "tsunami:31", () => {
			J(e, 2);
		})) return;
		let r = F(e, t, "dmg", n, 8);
		if (r && R(e, t, "tsunami:32", () => {
			L(e, n, r);
		}) && (t.ctx.level ?? 0) >= 1) {
			z(t, "tsunami:33", () => {
				I(e, n, "dahan");
			}), z(t, "tsunami:34", () => {
				I(e, n, "dahan");
			});
			let r = e.lands[n].board;
			z(t, "tsunami:35", () => {
				for (let t of k(e)) t.id !== n && t.board === r && t.coastal && t.n !== 0 && (J(e, 1), at(e, t.id, 4), I(e, t.id, "dahan"));
			});
		}
	},
	vengeanceOfTheDead(e, t) {
		let n = q(e, t);
		n && R(e, t, "vengeanceOfTheDead:33", () => {
			J(e, 3);
		}) && z(t, "vengeanceOfTheDead:36", () => {
			e.vengeance.includes(n) || e.vengeance.push(n);
		});
	},
	vigorOfTheBreakingDawn(e, t) {
		let n = q(e, t);
		if (!n) return;
		let r = F(e, t, "dmg", n, 2 * e.lands[n].dahan);
		if (r && R(e, t, "vigorOfTheBreakingDawn:34", () => {
			L(e, n, r);
		}) && (t.ctx.level ?? 0) >= 1) {
			let r = V(e, t, "push", n, ["dahan"], 2);
			if (!r) return;
			if (r.dest) {
				if (!R(e, t, "vigorOfTheBreakingDawn:35", () => {
					H(e, n, r.dest, r.pieces);
				})) return;
				let i = F(e, t, "dmg2", r.dest, 2 * e.lands[r.dest].dahan);
				if (!i || !R(e, t, "vigorOfTheBreakingDawn:36", () => {
					L(e, r.dest, i);
				})) return;
			}
		}
	},
	windsOfRustAndAtrophy(e, t) {
		let n = q(e, t);
		if (!n || !R(e, t, "windsOfRustAndAtrophy:37", () => {
			J(e, 1);
		}) || !R(e, t, "windsOfRustAndAtrophy:38", () => {
			e.lands[n].defend += 6;
		})) return;
		let r = e.lands[n];
		if (r.cities + r.towns > 0) {
			let i = P(e, t, "down", n, [...Array(r.towns).fill({ type: "town" }), ...Array(r.cities).fill({ type: "city" })], 1, !1);
			if (!i) return;
			z(t, "windsOfRustAndAtrophy:37", () => {
				i.length && (i[0].type === "city" ? (B(e, n, "city", -1), B(e, n, "town", 1)) : (B(e, n, "town", -1), B(e, n, "explorer", 1)));
			});
		}
		(t.ctx.level ?? 0) >= 1 && z(t, "windsOfRustAndAtrophy:38", () => {
			e.queue.push({
				seat: t.seat,
				source: t.source,
				kind: "power",
				stepsLeft: 0,
				ctx: { level: 0 }
			});
		});
	},
	wrapInWingsOfSunlight(e, t) {
		let n = q(e, t);
		if (!n) return;
		if ((t.ctx.level ?? 0) >= 1) {
			let r = U(e, t, "gather", n, ["dahan"], 3);
			if (!r || !R(e, t, "wrapInWingsOfSunlight:39", () => {
				W(e, n, r);
			})) return;
		}
		let r = e.lands[n], i = P(e, t, "move", n, Array(r.dahan).fill({ type: "dahan" }), 5, !0);
		if (i && i.length) {
			let r = A(e, t, "dest", k(e).filter((e) => e.n !== 0).map((e) => e.id));
			if (!r || !Ze(e, t, "moveAlly", n, r) || (z(t, "wrapInWingsOfSunlight:39", () => {
				for (let t = 0; t < i.length; t += 1) Xe(e, n, r, "dahan");
			}), !R(e, t, "wrapInWingsOfSunlight:40", () => {
				e.lands[r].defend += 5;
			}))) return;
		}
	}
}, lt = (e) => D[e];
function Y(e, t) {
	return Je(e, t, lt(t.source)) || null;
}
var X = (e, t) => Ve(e, t), ut = (e, t) => {
	let n = e.lands[t];
	return n.explorers + n.towns + n.cities;
};
function dt(e, t, n = "spirit") {
	return N(e, t, n, e.players.filter((t) => !e.spirits[t].dead));
}
var ft = {
	aYearOfPerfectStillness(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = e.lands[n];
		z(t, "aYearOfPerfectStillness:0", () => {
			r.skipRavage = !0;
		}), z(t, "aYearOfPerfectStillness:1", () => {
			r.skipBuild = !0;
		}), z(t, "aYearOfPerfectStillness:2", () => {
			r.skipExplore = !0;
		});
	},
	boonOfVigor(e, t) {
		let n = dt(e, t);
		n && R(e, t, "boonOfVigor:0", () => {
			e.spirits[n].energy += n === t.seat ? 1 : e.spirits[n].played.length;
		});
	},
	callOfTheDeeps(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = U(e, t, "gather", n, ["explorer"], 1);
		if (r && R(e, t, "callOfTheDeeps:1", () => {
			W(e, n, r);
		}) && e.lands[n].n === 0) {
			let r = U(e, t, "gather2", n, ["explorer"], 1);
			if (!r || !R(e, t, "callOfTheDeeps:2", () => {
				W(e, n, r);
			})) return;
		}
	},
	callOnMidnightsDreams(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = e.lands[n], i = r.dahan > 0, a = ut(e, n) > 0;
		if (i && a) {
			let n = j(e, t, "mode");
			if (n === void 0) return;
			if (!n) return R(e, t, "callOnMidnightsDreams:3", () => {
				X(e, 2);
			}), void 0;
		} else if (!i) return a && R(e, t, "callOnMidnightsDreams:4", () => {
			X(e, 2);
		}), void 0;
		let o = t.ctx.drawn;
		if (!o && (o = e.majorDeck.splice(Math.max(0, e.majorDeck.length - 4)), t.ctx.drawn = o, o.length === 0)) return;
		let s = M(e, t, "keep", o, 1);
		if (!s) return;
		let c = e.spirits[t.seat];
		z(t, "callOnMidnightsDreams:4", () => {
			c.hand.push(...s);
		});
		let l = M(e, t, "forget", [
			...c.hand,
			...c.discard,
			...c.played
		], 1);
		if (!l) return;
		let u = l[0];
		for (let e of [
			"hand",
			"discard",
			"played"
		]) {
			let t = c[e].indexOf(u);
			t >= 0 && c[e].splice(t, 1);
		}
		if (z(t, "callOnMidnightsDreams:5", () => {
			c.forgotten.push(u);
		}), u === t.source) {
			if (!R(e, t, "callOnMidnightsDreams:5", () => {
				c.energy += r.dahan;
			})) return;
			let n = D[s[0]]?.cost ?? 0;
			if (t.ctx.affordable ??= c.energy >= n) {
				if (!R(e, t, "callOnMidnightsDreams:6", () => {
					c.energy -= n;
				})) return;
				z(t, "callOnMidnightsDreams:6", () => {
					c.hand.splice(c.hand.indexOf(s[0]), 1);
				}), z(t, "callOnMidnightsDreams:7", () => {
					c.played.push(s[0]);
				}), z(t, "callOnMidnightsDreams:8", () => {
					e.queue.push({
						seat: t.seat,
						source: s[0],
						kind: "power",
						stepsLeft: 0,
						ctx: {}
					});
				});
			}
		}
	},
	concealingShadows(e, t) {
		R(e, t, "concealingShadows:7", () => {
			X(e, 1);
		}) && z(t, "concealingShadows:9", () => {
			e.dahanShield = !0;
		});
	},
	cropsWitherAndFade(e, t) {
		let n = Y(e, t);
		if (!n || !R(e, t, "cropsWitherAndFade:8", () => {
			X(e, 2);
		})) return;
		let r = e.lands[n];
		if (r.towns > 0 && r.cities > 0) {
			let r = j(e, t, "mode");
			if (r === void 0) return;
			z(t, "cropsWitherAndFade:10", () => {
				r ? et(e, n, "town", "explorer") : et(e, n, "city", "town");
			});
		} else z(t, "cropsWitherAndFade:11", () => {
			r.towns > 0 ? et(e, n, "town", "explorer") : r.cities > 0 && et(e, n, "city", "town");
		});
	},
	drawOfTheFruitfulEarth(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = U(e, t, "gatherE", n, ["explorer"], 2);
		if (!r || !R(e, t, "drawOfTheFruitfulEarth:9", () => {
			W(e, n, r);
		})) return;
		let i = U(e, t, "gatherD", n, ["dahan"], 2);
		i && R(e, t, "drawOfTheFruitfulEarth:10", () => {
			W(e, n, i);
		});
	},
	dreadApparitions(e, t) {
		let n = Y(e, t);
		n && R(e, t, "dreadApparitions:11", () => {
			e.lands[n].defend += 2;
		}) && R(e, t, "dreadApparitions:12", () => {
			X(e, 1);
		});
	},
	dreamsOfTheDahan(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = e.lands[n], i = t.ctx.canGather ??= r.adj.some((t) => e.lands[t].dahan > 0), a = t.ctx.canFear ??= r.towns + r.cities > 0 && r.dahan > 0;
		if (i && a) {
			let n = j(e, t, "mode");
			if (n === void 0) return;
			if (!n) return R(e, t, "dreamsOfTheDahan:13", () => {
				X(e, Math.min(3, r.dahan));
			}), void 0;
		} else if (!i) return a && R(e, t, "dreamsOfTheDahan:14", () => {
			X(e, Math.min(3, r.dahan));
		}), void 0;
		let o = U(e, t, "gather", n, ["dahan"], 2);
		o && R(e, t, "dreamsOfTheDahan:15", () => {
			W(e, n, o);
		});
	},
	favorsCalledDue(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = U(e, t, "gather", n, ["dahan"], 4);
		if (!r || !R(e, t, "favorsCalledDue:16", () => {
			W(e, n, r);
		})) return;
		let i = e.lands[n];
		ut(e, n) > 0 && i.dahan > ut(e, n) && R(e, t, "favorsCalledDue:17", () => {
			X(e, 3);
		});
	},
	fieldsChokedWithGrowth(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = e.lands[n], i = t.ctx.canTown ??= r.towns > 0, a = t.ctx.canDahan ??= r.dahan > 0;
		if (i && a) {
			let r = j(e, t, "mode");
			if (r === void 0) return;
			if (!r) {
				let r = V(e, t, "pushD", n, ["dahan"], 3);
				!r || r.dest && R(e, t, "fieldsChokedWithGrowth:18", () => {
					H(e, n, r.dest, r.pieces);
				});
				return;
			}
		} else if (!i) {
			let r = V(e, t, "pushD", n, ["dahan"], 3);
			!r || r.dest && R(e, t, "fieldsChokedWithGrowth:19", () => {
				H(e, n, r.dest, r.pieces);
			});
			return;
		}
		let o = V(e, t, "push", n, ["town"], 1, !1);
		o && (!o.dest || R(e, t, "fieldsChokedWithGrowth:20", () => {
			H(e, n, o.dest, o.pieces);
		}));
	},
	flashFloods(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = F(e, t, "dmg", n, e.lands[n].coastal ? 2 : 1);
		r && R(e, t, "flashFloods:21", () => {
			L(e, n, r);
		});
	},
	giftOfProliferation(e, t) {
		let n = N(e, t, "spirit", e.players.filter((n) => !e.spirits[n].dead && n !== t.seat));
		if (!n) return;
		let r = {
			...t,
			seat: n
		}, i = ze(e, r, "track");
		if (!i) return;
		let a = k(e).filter((e) => (e.presence[n] ?? 0) > 0).map((e) => e.id), o = A(e, r, "land", k(e).filter((e) => e.n !== 0 && a.some((t) => e.adj.includes(t) || e.id === t)).map((e) => e.id));
		o && Qe(e, n, i, o);
	},
	graspingTide(e, t) {
		let n = Y(e, t);
		n && R(e, t, "graspingTide:22", () => {
			X(e, 2);
		}) && R(e, t, "graspingTide:23", () => {
			e.lands[n].defend += 4;
		});
	},
	guardTheHealingLand(e, t) {
		let n = Y(e, t);
		n && (z(t, "guardTheHealingLand:12", () => {
			$e(e, n);
		}), R(e, t, "guardTheHealingLand:24", () => {
			e.lands[n].defend += 4;
		}));
	},
	harbingersOfTheLightning(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = V(e, t, "push", n, ["dahan"], 2);
		r && r.dest && (!R(e, t, "harbingersOfTheLightning:25", () => {
			H(e, n, r.dest, r.pieces);
		}) || r.pieces.length > 0 && e.lands[r.dest].towns + e.lands[r.dest].cities > 0 && R(e, t, "harbingersOfTheLightning:26", () => {
			X(e, 1);
		}));
	},
	lightningsBoon(e, t) {
		let n = dt(e, t);
		if (!n) return;
		let r = e.spirits[n], i = r.played.filter((e) => D[e]?.speed === "slow" && !r.fastCards.includes(e)), a = M(e, {
			...t,
			seat: n
		}, "fast", i, 2, !0);
		a && z(t, "lightningsBoon:13", () => {
			for (let t of a) r.fastCards.push(t), e.queue.push({
				seat: n,
				source: t,
				kind: "power",
				stepsLeft: 0,
				ctx: {}
			});
		});
	},
	manifestationOfPowerAndGlory(e, t) {
		let n = Y(e, t);
		if (!n || !R(e, t, "manifestationOfPowerAndGlory:27", () => {
			X(e, 1);
		})) return;
		let r = e.lands[n], i = F(e, t, "dmg", n, r.dahan * (r.presence[t.seat] ?? 0));
		i && R(e, t, "manifestationOfPowerAndGlory:28", () => {
			L(e, n, i);
		});
	},
	mantleOfDread(e, t) {
		let n = dt(e, t);
		if (!n || !R(e, t, "mantleOfDread:29", () => {
			X(e, 2);
		})) return;
		let r = k(e).filter((e) => (e.presence[n] ?? 0) > 0 && (e.explorers > 0 || e.towns > 0)).map((e) => e.id), i = {
			...t,
			seat: n
		}, a = A(e, i, "land", r);
		if (!a) return;
		let o = V(e, i, "pushE", a, ["explorer"], 1);
		if (!o || o.dest && !R(e, t, "mantleOfDread:30", () => {
			H(e, a, o.dest, o.pieces);
		})) return;
		let s = V(e, i, "pushT", a, ["town"], 1);
		s && (!s.dest || R(e, t, "mantleOfDread:31", () => {
			H(e, a, s.dest, s.pieces);
		}));
	},
	overgrowInANight(e, t) {
		let n = Y(e, t);
		if (!n) return;
		if ((e.lands[n].presence[t.seat] ?? 0) > 0 && ut(e, n) > 0) {
			let n = j(e, t, "mode");
			if (n === void 0) return;
			if (!n) return R(e, t, "overgrowInANight:32", () => {
				X(e, 3);
			}), void 0;
		}
		let r = ze(e, t, "track");
		r && Qe(e, t.seat, r, n);
	},
	predatoryNightmares(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = F(e, t, "dmg", n, 2);
		if (!r || !R(e, t, "predatoryNightmares:33", () => {
			L(e, n, r);
		})) return;
		let i = V(e, t, "push", n, ["dahan"], 2);
		i && (!i.dest || R(e, t, "predatoryNightmares:34", () => {
			H(e, n, i.dest, i.pieces);
		}));
	},
	ragingStorm(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = e.lands[n];
		z(t, "ragingStorm:14", () => {
			for (let t = 0; t < r.explorers; t += 1) I(e, n, "explorer");
		});
	},
	ritualsOfDestruction(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = e.lands[n].dahan >= 3, i = F(e, t, "dmg", n, r ? 5 : 2);
		i && R(e, t, "ritualsOfDestruction:35", () => {
			L(e, n, i);
		}) && (!r || R(e, t, "ritualsOfDestruction:36", () => {
			X(e, 2);
		}));
	},
	riversBounty(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = U(e, t, "gather", n, ["dahan"], 2);
		r && R(e, t, "riversBounty:37", () => {
			W(e, n, r);
		}) && e.lands[n].dahan >= 2 && (z(t, "riversBounty:15", () => {
			B(e, n, "dahan", 1);
		}), R(e, t, "riversBounty:38", () => {
			e.spirits[t.seat].energy += 1;
		}));
	},
	shatterHomesteads(e, t) {
		let n = Y(e, t);
		n && R(e, t, "shatterHomesteads:39", () => {
			X(e, 1);
		}) && z(t, "shatterHomesteads:16", () => {
			I(e, n, "town");
		});
	},
	stemTheFlowOfFreshWater(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = e.lands[n], i = r.terrain;
		z(t, "stemTheFlowOfFreshWater:17", () => {
			if (i === "Mountain" || i === "Sands") for (let t = 0; t < r.towns; t += 1) I(e, n, "town");
			else I(e, n, "town");
		});
	},
	suddenAmbush(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = U(e, t, "gather", n, ["dahan"], 1);
		if (!r || !R(e, t, "suddenAmbush:40", () => {
			W(e, n, r);
		})) return;
		let i = e.lands[n], a = Math.min(i.dahan, i.explorers);
		z(t, "suddenAmbush:18", () => {
			for (let t = 0; t < a; t += 1) I(e, n, "explorer");
		});
	},
	swallowTheLandDwellers(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = e.lands[n], i = e.spirits[t.seat];
		r.explorers > 0 && (B(e, n, "explorer", -1), i.drowned += 1), r.towns > 0 && (B(e, n, "town", -1), Ve(e, 1), i.drowned += 2), r.dahan > 0 && B(e, n, "dahan", -1);
	},
	tidalBoon(e, t) {
		let n = N(e, t, "spirit", e.players.filter((n) => !e.spirits[n].dead && n !== t.seat));
		if (!n || !R(e, t, "tidalBoon:42", () => {
			e.spirits[n].energy += 2;
		})) return;
		let r = k(e).filter((e) => (e.presence[n] ?? 0) > 0 && (e.towns > 0 || e.dahan > 0)).map((e) => e.id), i = {
			...t,
			seat: n
		}, a = A(e, i, "land", r);
		if (!a) return;
		let o = V(e, i, "pushT", a, ["town"], 1);
		if (!o || o.dest && !R(e, t, "tidalBoon:43", () => {
			H(e, a, o.dest, o.pieces);
		})) return;
		let s = V(e, i, "pushD", a, ["dahan"], 2);
		s && (!s.dest || R(e, t, "tidalBoon:44", () => {
			H(e, a, s.dest, s.pieces);
		}));
	},
	voiceOfThunder(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = e.lands[n], i = t.ctx.canPush ??= r.dahan > 0, a = t.ctx.canFear ??= ut(e, n) > 0;
		if (i && a) {
			let n = j(e, t, "mode");
			if (n === void 0) return;
			if (!n) return R(e, t, "voiceOfThunder:45", () => {
				X(e, 2);
			}), void 0;
		} else if (!i) return a && R(e, t, "voiceOfThunder:46", () => {
			X(e, 2);
		}), void 0;
		let o = V(e, t, "push", n, ["dahan"], 4);
		o && (!o.dest || R(e, t, "voiceOfThunder:47", () => {
			H(e, n, o.dest, o.pieces);
		}));
	},
	washAway(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = V(e, t, "push", n, ["explorer", "town"], 3);
		r && (!r.dest || R(e, t, "washAway:48", () => {
			H(e, n, r.dest, r.pieces);
		}));
	},
	wordsOfWarning(e, t) {
		let n = Y(e, t);
		if (!n) return;
		let r = e.lands[n];
		R(e, t, "wordsOfWarning:49", () => {
			r.defend += 3;
		}) && z(t, "wordsOfWarning:23", () => {
			r.dahanSimul = !0;
		});
	}
}, pt = Object.fromEntries(E.flatMap((e) => e.innates.map((e) => [e.id, e]))), Z = (e) => e.ctx.level ?? 0;
function mt(e, t) {
	let n = pt[t.source];
	return Je(e, t, n) || null;
}
var ht = (e, t) => Ve(e, t), gt = {
	creepersTearIntoMortar() {},
	allEnvelopingGreen(e, t) {
		let n = mt(e, t);
		n && R(e, t, "allEnvelopingGreen:0", () => {
			e.lands[n].defend += Z(t) >= 2 ? 4 : 2;
		}) && z(t, "allEnvelopingGreen:0", () => {
			Z(t) >= 3 && e.lands[n].blight > 0 && $e(e, n);
		});
	},
	spiritsMayYetDream(e, t) {
		if (Z(t) >= 2) {
			let n = N(e, t, "spirit", e.players.filter((t) => !e.spirits[t].dead));
			if (!n) return;
			let { counts: r } = Pe(e, n), i = Object.entries(r).sort((e, t) => t[1] - e[1])[0];
			z(t, "spiritsMayYetDream:1", () => {
				i && i[1] > 0 && e.spirits[n].bonusElems.push(i[0]);
			});
		}
	},
	nightTerrors(e, t) {
		mt(e, t) && R(e, t, "nightTerrors:1", () => {
			ht(e, [
				1,
				2,
				3
			][Math.min(Z(t), 3) - 1] ?? 0);
		});
	},
	thunderingDestruction(e, t) {
		let n = mt(e, t);
		if (!n) return;
		let r = Z(t), i = e.lands[n], a = P(e, t, "d1", n, [...Array(i.towns).fill("town"), ...r >= 2 ? Array(i.cities).fill("city") : []].map((e) => ({ type: e })), 1, !1);
		if (!a || !R(e, t, "d1Done", () => {
			for (let t of a) I(e, n, t.type);
		})) return;
		let o = (r) => {
			let i = e.lands[n], a = [...Array(i.towns).fill("town"), ...Array(i.cities).fill("city")].map((e) => ({ type: e })), o = P(e, t, r, n, a, 1, !1);
			return o ? R(e, t, `${r}Done`, () => {
				for (let t of o) I(e, n, t.type);
			}) : !1;
		};
		r >= 3 && !o("d2") || r >= 4 && o("d3");
	},
	poundShipsToSplinters(e, t) {
		mt(e, t) && R(e, t, "poundShipsToSplinters:2", () => {
			ht(e, [
				1,
				2,
				4
			][Math.min(Z(t), 3) - 1] ?? 0);
		});
	},
	oceanBreaksTheShore(e, t) {
		let n = mt(e, t);
		if (!n) return;
		let r = Z(t), i = e.spirits[t.seat], a = (r, a) => {
			let o = e.lands[n], s = [...Array(o.towns).fill("town"), ...a ? Array(o.cities).fill("city") : []].map((e) => ({ type: e })), c = P(e, t, r, n, s, 1, !1);
			return c ? R(e, t, `${r}Done`, () => {
				for (let t of c) i.drowned += t.type === "city" ? 3 : 2, I(e, n, t.type);
			}) : !1;
		};
		a("d1", r >= 2) && r >= 3 && a("d2", !0);
	},
	massiveFlooding(e, t) {
		let n = mt(e, t);
		if (!n) return;
		let r = Z(t);
		if (r >= 3) {
			let r = e.lands[n];
			z(t, "massiveFlooding:3", () => {
				for (let t = 0; t < r.explorers; t += 1) I(e, n, "explorer");
			}), z(t, "massiveFlooding:4", () => {
				for (let t = 0; t < r.towns; t += 1) I(e, n, "town");
			});
			return;
		}
		if (r >= 2) {
			let r = F(e, t, "dmg", n, 2);
			if (!r || !R(e, t, "massiveFlooding:3", () => {
				L(e, n, r);
			})) return;
			let i = V(e, t, "push", n, ["explorer", "town"], 3);
			!i || i.dest && R(e, t, "massiveFlooding:4", () => {
				H(e, n, i.dest, i.pieces);
			});
			return;
		}
		let i = V(e, t, "push", n, ["explorer", "town"], 1);
		i && (!i.dest || R(e, t, "massiveFlooding:5", () => {
			H(e, n, i.dest, i.pieces);
		}));
	},
	darknessSwallowsTheUnwary(e, t) {
		let n = mt(e, t);
		if (!n) return;
		let r = Z(t), i = U(e, t, "gather", n, ["explorer"], 1);
		if (i && R(e, t, "darknessSwallowsTheUnwary:6", () => {
			W(e, n, i);
		})) {
			if (r >= 2) {
				let r = e.lands[n], i = P(e, t, "kill", n, Array(r.explorers).fill({ type: "explorer" }), 2, !0);
				if (!i || (z(t, "darknessSwallowsTheUnwary:5", () => {
					for (let t of i) I(e, n, t.type);
				}), !R(e, t, "darknessSwallowsTheUnwary:7", () => {
					ht(e, i.length);
				}))) return;
			}
			if (r >= 3) {
				let r = F(e, t, "dmg", n, 3);
				if (!r || !R(e, t, "darknessSwallowsTheUnwary:8", () => {
					L(e, n, r);
				}) || !R(e, t, "darknessSwallowsTheUnwary:9", () => {
					ht(e, r.length);
				})) return;
			}
		}
	},
	gatherTheWarriors(e, t) {
		let n = mt(e, t);
		if (n && Z(t) >= 2) {
			let { counts: r } = Pe(e, t.seat), i = U(e, t, "gather", n, ["dahan"], r.air);
			if (!i || !R(e, t, "gatherTheWarriors:10", () => {
				W(e, n, i);
			})) return;
			let a = V(e, t, "push", n, ["dahan"], r.sun);
			if (!a || a.dest && !R(e, t, "gatherTheWarriors:11", () => {
				H(e, n, a.dest, a.pieces);
			})) return;
		}
	},
	leadTheFuriousAssault(e, t) {
		let n = mt(e, t);
		if (!n) return;
		let r = Z(t), i = e.lands[n];
		z(t, "leadTheFuriousAssault:6", () => {
			if (r >= 2) for (let t = 0; t < Math.floor(i.dahan / 2); t += 1) I(e, n, "town");
		}), z(t, "leadTheFuriousAssault:7", () => {
			if (r >= 3) for (let t = 0; t < Math.floor(i.dahan / 3); t += 1) I(e, n, "city");
		});
	},
	giftOfStrength(e, t) {
		let n = N(e, t, "spirit", e.players.filter((t) => !e.spirits[t].dead));
		if (!n) return;
		let r = [
			1,
			3,
			6
		][Math.min(Z(t), 3) - 1] ?? 1, i = e.spirits[n].played.filter((e) => (D[e]?.cost ?? 99) <= r);
		if (i.length === 0) return;
		let a = _t(e, t, n, i);
		a && z(t, "giftOfStrength:8", () => {
			for (let t of a) e.queue.push({
				seat: n,
				source: t,
				kind: "power",
				stepsLeft: 0,
				ctx: {}
			});
		});
	}
};
function _t(e, t, n, r) {
	if (t.ctx.rep !== void 0) return t.ctx.rep;
	if (r.length <= 1) return t.ctx.rep = r, r;
	e.pending ||= {
		kind: "cards",
		seat: n,
		why: `${t.source}:rep`,
		key: "rep",
		cards: r,
		count: 1,
		upto: !0
	};
}
//#endregion
//#region src/games/spiritisland/powers/fear.ts
var vt = (e, t) => {
	let n = e.lands[t];
	return n.explorers + n.towns + n.cities;
}, yt = (e, t, n) => (e.lands[t].presence[n] ?? 0) > 0;
function bt(e, t, n) {
	let r = e.players.filter((t) => !e.spirits[t].dead), i = t.ctx.idx ?? 0;
	for (; i < r.length;) {
		let a = r[i];
		if (!n(a, (e) => `${e}${i}`)) {
			t.ctx.idx = i;
			return;
		}
		i += 1, t.ctx.idx = i, e.awaitingBeat = !0;
		return;
	}
}
function Q(e, t) {
	return k(e).filter((e) => e.n !== 0 && t(e.id)).map((e) => e.id);
}
function xt(e, t, n, r) {
	bt(e, t, (i, a) => {
		let o = Q(e, (t) => n(t, i) && r.some((n) => St(e, t, n) > 0));
		if (o.length === 0 && !t.ctx[a("land")]) return !0;
		let s = A(e, {
			...t,
			seat: i
		}, a("land"), o);
		if (!s) return !1;
		let c = r.flatMap((t) => Array(St(e, s, t)).fill({ type: t })), l = P(e, {
			...t,
			seat: i
		}, a("piece"), s, c, 1, !1);
		return l ? (l.length && I(e, s, l[0].type), !0) : !1;
	});
}
function St(e, t, n) {
	let r = e.lands[t];
	return n === "explorer" ? r.explorers : n === "town" ? r.towns : n === "city" ? r.cities : n === "dahan" ? r.dahan : 0;
}
var Ct = {
	avoidTheDahan(e) {
		let t = e.terror;
		for (let n of k(e)) t === 1 && n.dahan >= 2 ? n.skipExplore = !0 : (t === 2 && n.dahan > n.towns + n.cities || t >= 3 && n.dahan > 0) && (n.skipBuild = !0);
	},
	beliefTakesRoot(e, t) {
		let n = e.terror;
		if (n === 1) {
			for (let t of k(e)) Object.keys(t.presence).length > 0 && (t.defend += 2);
			return;
		}
		if (n === 2) {
			for (let t of k(e)) Object.keys(t.presence).length > 0 && (t.defend += 2);
			for (let t of e.players) {
				let n = k(e).filter((n) => (n.presence[t] ?? 0) >= 2 && vt(e, n.id) > 0).length;
				e.spirits[t].energy += n;
			}
			return;
		}
		let r = t.ctx.used ?? [];
		bt(e, t, (n, i) => {
			let a = Q(e, (t) => !r.includes(t) && yt(e, t, n) && vt(e, t) > 0);
			if (a.length === 0 && !t.ctx[i("land")]) return !0;
			let o = A(e, {
				...t,
				seat: n
			}, i("land"), a);
			if (!o) return !1;
			r.includes(o) || r.push(o), t.ctx.used = r;
			let s = (e.lands[o].presence[n] ?? 0) * 2, c = F(e, {
				...t,
				seat: n
			}, i("dmg"), o, s);
			return c ? (L(e, o, c), !0) : !1;
		});
	},
	dahanEnheartened(e, t) {
		let n = e.terror;
		if (n === 1) {
			bt(e, t, (n, r) => {
				let i = Q(e, (t) => e.lands[t].dahan > 0 && vt(e, t) > 0), a = Q(e, (t) => vt(e, t) > 0 && e.lands[t].adj.some((t) => e.lands[t].dahan > 0));
				if (i.length === 0 && a.length === 0) return !0;
				let o = j(e, {
					...t,
					seat: n
				}, r("go"));
				if (o === void 0) return !1;
				if (!o) return !0;
				let s = [];
				i.length && s.push("push"), a.length && s.push("gather");
				let c = r("mode"), l = t.ctx[c];
				if (l === void 0) {
					if (s.length === 1) l = s[0], t.ctx[c] = l;
					else {
						let r = j(e, {
							...t,
							seat: n
						}, c);
						if (r === void 0) return !1;
						l = r ? "push" : "gather", t.ctx[c] = l;
					}
				}
				if (l === "push") {
					let a = A(e, {
						...t,
						seat: n
					}, r("from"), i);
					if (!a) return !1;
					let o = A(e, {
						...t,
						seat: n
					}, r("dest"), e.lands[a].adj.filter((t) => e.lands[t].n !== 0));
					if (!o) return !1;
					Xe(e, a, o, "dahan");
				} else {
					let i = A(e, {
						...t,
						seat: n
					}, r("to"), a);
					if (!i) return !1;
					let o = A(e, {
						...t,
						seat: n
					}, r("from"), e.lands[i].adj.filter((t) => e.lands[t].dahan > 0));
					if (!o) return !1;
					Xe(e, o, i, "dahan");
				}
				return !0;
			});
			return;
		}
		let r = t.ctx.used ?? [];
		bt(e, t, (i, a) => {
			let o = Q(e, (e) => !r.includes(e)), s = A(e, {
				...t,
				seat: i
			}, a("land"), o);
			if (!s) return !1;
			r.includes(s) || r.push(s), t.ctx.used = r;
			let c = e.lands[s].adj.filter((t) => e.lands[t].dahan > 0).flatMap((t) => Array(e.lands[t].dahan).fill({
				type: "dahan",
				from: t
			})), l = P(e, {
				...t,
				seat: i
			}, a("gather"), s, c, 2, !0);
			if (!l || !R(e, t, a("gatherDone"), () => {
				for (let t of l) t.from && Xe(e, t.from, s, "dahan");
			})) return !1;
			let u = e.lands[s].dahan;
			if (u > 0) {
				let r = n >= 3 ? u * 2 : 1, o = F(e, {
					...t,
					seat: i
				}, a("dmg"), s, r);
				if (!o) return !1;
				L(e, s, o);
			}
			return !0;
		});
	},
	dahanOnTheirGuard(e) {
		let t = e.terror;
		for (let n of k(e)) n.dahan !== 0 && (t === 1 ? n.defend += n.dahan : t === 2 ? n.defend += 1 + n.dahan : n.defend += n.dahan * 2);
	},
	dahanRaid(e, t) {
		let n = e.terror, r = t.ctx.used ?? [];
		bt(e, t, (i, a) => {
			let o = Q(e, (t) => !r.includes(t) && e.lands[t].dahan > 0 && vt(e, t) > 0);
			if (o.length === 0 && !t.ctx[a("land")]) return !0;
			let s = A(e, {
				...t,
				seat: i
			}, a("land"), o);
			if (!s) return !1;
			r.includes(s) || r.push(s), t.ctx.used = r;
			let c = e.lands[s].dahan, l = n === 1 ? 1 : n === 2 ? c : c * 2, u = F(e, {
				...t,
				seat: i
			}, a("dmg"), s, l);
			return u ? (L(e, s, u), !0) : !1;
		});
	},
	emigrationAccelerates(e, t) {
		let n = e.terror;
		xt(e, t, (t) => n >= 3 || e.lands[t].coastal, n === 1 ? ["explorer"] : ["explorer", "town"]);
	},
	fearOfTheUnseen(e, t) {
		let n = e.terror;
		xt(e, t, (t, r) => {
			let i = (e.lands[t].presence[r] ?? 0) >= 2, a = yt(e, t, r);
			return n === 1 ? i : a;
		}, n >= 3 ? [
			"explorer",
			"town",
			"city"
		] : ["explorer", "town"]);
	},
	isolation(e, t) {
		let n = e.terror;
		xt(e, t, (t) => n === 1 ? vt(e, t) === 1 : vt(e, t) <= 2, n >= 3 ? [
			"explorer",
			"town",
			"city"
		] : ["explorer", "town"]);
	},
	overseasTradeSeemsSafer(e) {
		let t = e.terror;
		for (let n of k(e)) n.coastal && (n.defend += t === 1 ? 3 : t === 2 ? 6 : 9, t >= 2 && (n.skipBuild = !0));
	},
	retreat(e, t) {
		let n = e.terror;
		bt(e, t, (r, i) => {
			let a = n === 1 ? ["explorer"] : ["explorer", "town"], o = Q(e, (t) => (n >= 3 || !e.lands[t].coastal) && a.some((n) => St(e, t, n) > 0));
			if (o.length === 0 && !t.ctx[i("land")]) return !0;
			let s = j(e, {
				...t,
				seat: r
			}, i("go"));
			if (s === void 0) return !1;
			if (!s) return !0;
			let c = A(e, {
				...t,
				seat: r
			}, i("land"), o);
			if (!c) return !1;
			let l = n === 1 ? 2 : n === 2 ? 3 : St(e, c, "explorer") + St(e, c, "town"), u = V(e, {
				...t,
				seat: r
			}, i("push"), c, a, l);
			return u ? (u.dest && H(e, c, u.dest, u.pieces), !0) : !1;
		});
	},
	scapegoats(e) {
		let t = e.terror;
		for (let n of k(e)) if (t === 1) {
			if (n.towns > 0) for (let t = 0; t < n.towns && n.explorers > 0; t += 1) I(e, n.id, "explorer");
		} else if (t === 2) {
			let t = n.towns + n.cities * 2;
			for (let r = 0; r < t && n.explorers > 0; r += 1) I(e, n.id, "explorer");
		} else {
			for (; n.explorers > 0;) I(e, n.id, "explorer");
			for (let t = 0; t < n.cities && n.towns > 0; t += 1) I(e, n.id, "town");
		}
	},
	seekSafety(e, t) {
		let n = e.terror;
		if (n === 1) {
			bt(e, t, (n, r) => {
				let i = Q(e, (t) => e.lands[t].explorers > 0 && e.lands[t].adj.some((n) => e.lands[n].n !== 0 && e.lands[n].towns + e.lands[n].cities > e.lands[t].towns + e.lands[t].cities));
				if (i.length === 0 && !t.ctx[r("land")]) return !0;
				let a = j(e, {
					...t,
					seat: n
				}, r("go"));
				if (a === void 0) return !1;
				if (!a) return !0;
				let o = A(e, {
					...t,
					seat: n
				}, r("from"), i);
				if (!o) return !1;
				let s = A(e, {
					...t,
					seat: n
				}, r("dest"), e.lands[o].adj.filter((t) => e.lands[t].n !== 0 && e.lands[t].towns + e.lands[t].cities > e.lands[o].towns + e.lands[o].cities));
				return s ? (Xe(e, o, s, "explorer"), !0) : !1;
			});
			return;
		}
		if (n === 2) {
			bt(e, t, (n, r) => {
				let i = Q(e, (t) => e.lands[t].towns + e.lands[t].cities > 0 && e.lands[t].adj.some((t) => e.lands[t].explorers > 0) || e.lands[t].cities > 0 && e.lands[t].adj.some((t) => e.lands[t].towns > 0));
				if (i.length === 0) return !0;
				let a = j(e, {
					...t,
					seat: n
				}, r("go"));
				if (a === void 0) return !1;
				if (!a) return !0;
				let o = A(e, {
					...t,
					seat: n
				}, r("dest"), i);
				if (!o) return !1;
				let s = e.lands[o].adj.flatMap((t) => {
					let n = [];
					return e.lands[o].towns + e.lands[o].cities > 0 && n.push(...Array(e.lands[t].explorers).fill({
						type: "explorer",
						from: t
					})), e.lands[o].cities > 0 && n.push(...Array(e.lands[t].towns).fill({
						type: "town",
						from: t
					})), n;
				}), c = P(e, {
					...t,
					seat: n
				}, r("piece"), o, s, 1, !1);
				if (!c) return !1;
				for (let t of c) t.from && Xe(e, t.from, o, t.type);
				return !0;
			});
			return;
		}
		bt(e, t, (n, r) => {
			let i = Q(e, (t) => e.lands[t].cities === 0 && vt(e, t) > 0);
			if (i.length === 0 && !t.ctx[r("land")]) return !0;
			let a = j(e, {
				...t,
				seat: n
			}, r("go"));
			if (a === void 0) return !1;
			if (!a) return !0;
			let o = A(e, {
				...t,
				seat: n
			}, r("land"), i);
			if (!o) return !1;
			let s = [...Array(e.lands[o].towns).fill({ type: "town" }), ...Array(e.lands[o].explorers).fill({ type: "explorer" })], c = P(e, {
				...t,
				seat: n
			}, r("piece"), o, s, 3, !0);
			if (!c) return !1;
			for (let t of c) I(e, o, t.type);
			return !0;
		});
	},
	tallTalesOfSavagery(e, t) {
		let n = e.terror;
		if (n >= 3) {
			for (let t of k(e)) t.dahan !== 0 && (t.explorers >= 2 ? (I(e, t.id, "explorer"), I(e, t.id, "explorer")) : t.towns > 0 ? I(e, t.id, "town") : t.explorers === 1 && I(e, t.id, "explorer"), t.dahan >= 2 && t.cities > 0 && I(e, t.id, "city"));
			return;
		}
		if (n === 1) {
			xt(e, t, (t) => e.lands[t].dahan > 0, ["explorer"]);
			return;
		}
		bt(e, t, (n, r) => {
			let i = Q(e, (t) => e.lands[t].dahan > 0 && (e.lands[t].explorers > 0 || e.lands[t].towns > 0));
			if (i.length === 0 && !t.ctx[r("land")]) return !0;
			let a = A(e, {
				...t,
				seat: n
			}, r("land"), i);
			if (!a) return !1;
			let o = e.lands[a];
			if (o.towns > 0 && o.explorers > 0) {
				let i = j(e, {
					...t,
					seat: n
				}, r("town"));
				if (i === void 0) return !1;
				if (i) return I(e, a, "town"), !0;
			} else if (o.towns > 0) return I(e, a, "town"), !0;
			return I(e, a, "explorer"), I(e, a, "explorer"), !0;
		});
	},
	tradeSuffers(e, t) {
		let n = e.terror;
		if (n === 1) {
			for (let t of k(e)) t.cities > 0 && (t.skipBuild = !0);
			return;
		}
		bt(e, t, (r, i) => {
			let a = n >= 3 ? ["town", "city"] : ["town"], o = Q(e, (t) => e.lands[t].coastal && a.some((n) => St(e, t, n) > 0));
			if (o.length === 0 && !t.ctx[i("land")]) return !0;
			let s = j(e, {
				...t,
				seat: r
			}, i("go"));
			if (s === void 0) return !1;
			if (!s) return !0;
			let c = A(e, {
				...t,
				seat: r
			}, i("land"), o);
			if (!c) return !1;
			let l = a.flatMap((t) => Array(St(e, c, t)).fill({ type: t })), u = P(e, {
				...t,
				seat: r
			}, i("piece"), c, l, 1, !1);
			if (!u) return !1;
			if (u.length) {
				let t = u[0].type;
				et(e, c, t, t === "city" ? "town" : "explorer");
			}
			return !0;
		});
	},
	waryOfTheInterior(e, t) {
		let n = e.terror;
		xt(e, t, (t) => n >= 3 || !e.lands[t].coastal, n === 1 ? ["explorer"] : ["explorer", "town"]);
	}
};
//#endregion
//#region src/games/spiritisland/powers/index.ts
for (let [e, t] of Object.entries({
	...rt,
	...ct,
	...ft
})) Ke[e] = (n, r) => {
	let i = D[e];
	i?.thresholds?.length && r.ctx.level === void 0 && (r.ctx.level = Fe(n, r.seat, i.thresholds)), t(n, r);
};
for (let [e, t] of Object.entries(gt)) Ke[e] = (n, r) => {
	let i = pt[e];
	i && r.ctx.level === void 0 && (r.ctx.level = Fe(n, r.seat, i.thresholds)), t(n, r);
};
for (let [e, t] of Object.entries(Ct)) Ke[`fear:${e}`] = t;
function wt(e, t, n) {
	return {
		state: we(t, n),
		fx: []
	};
}
function Tt(e) {
	e.pending = null;
	let t = e.invader.deck.pop();
	e.invader.explore = t, Ht(e, t), Et(e);
}
function Et(e) {
	e.phase = "growth", delete e.resolution;
	for (let t of e.players) {
		let n = e.spirits[t];
		if (n.energy += Le(e, t), n.spirit === "oceansHungryGrasp" && n.drowned > 0) {
			let t = e.players.length;
			n.energy += Math.floor(n.drowned / t), n.drowned %= t;
		}
		n.reclaimPending > 0 && (n.reclaimPending = 0, n.hand.push(...n.discard), n.discard = []);
	}
	e.growthDone = {}, e.pending = {
		kind: "growth",
		seat: e.players[0]
	};
}
function Dt(e) {
	e.phase = "play", delete e.resolution, e.playDone = {}, e.pending = {
		kind: "play",
		seat: e.players[0]
	};
}
function Ot(e) {
	let t = e.players.find((t) => !e.playDone[t] && !e.spirits[t].dead);
	if (t) {
		e.pending = {
			kind: "play",
			seat: t
		};
		return;
	}
	e.pending = null, e.phase = "fast", kt(e, "fast"), qe(e), At(e);
}
function kt(e, t) {
	for (let n of e.players) {
		let r = e.spirits[n];
		if (r.dead) continue;
		let i = Ie(e, n);
		if (t === "fast" && r.spirit === "lightningsSwiftStrike") {
			let t = Pe(e, n).counts.air;
			for (let e of r.played) {
				if (t <= 0) break;
				let n = D[e];
				n && n.speed === "slow" && !r.fastCards.includes(e) && (r.fastCards.push(e), --t);
			}
		}
		for (let r of i.innates) {
			let i = Fe(e, n, r.thresholds);
			i !== 0 && (r.speed === "slow" && (r.id === "gatherTheWarriors" || r.id === "leadTheFuriousAssault") ? "fast" : r.speed) === t && e.queue.push({
				seat: n,
				source: r.id,
				kind: "innate",
				stepsLeft: 0,
				ctx: { level: i }
			});
		}
		for (let i of r.played) {
			let a = D[i];
			if (!a) continue;
			let o = a.speed === "fast" || r.fastCards.includes(i);
			t === "fast" === o && e.queue.push({
				seat: n,
				source: i,
				kind: "power",
				stepsLeft: 0,
				ctx: {}
			});
		}
	}
}
function At(e) {
	let t = 10;
	for (; !e.over && !e.pending && !e.awaitingBeat && e.queue.length === 0 && t > 0;) {
		if (--t, e.phase === "fast") {
			e.phase = "invader", e.invaderStep = 0, e.beatMs = 900;
			return;
		}
		if (e.phase === "slow") {
			jt(e);
			continue;
		}
		if (e.phase === "cleanup") {
			Mt(e);
			continue;
		}
		if (e.phase === "growth" && Object.keys(e.growthDone).length >= e.players.filter((t) => !e.spirits[t].dead).length) {
			Dt(e);
			continue;
		}
		return;
	}
	e.over && (e.phase = "over", e.pending = null);
}
function jt(e) {
	e.phase = "cleanup";
	for (let t of e.players) e.spirits[t].keepCard > 0 && e.spirits[t].played.length > 0 && e.queue.push({
		seat: t,
		source: "cleanupKeep",
		kind: "growthOption",
		stepsLeft: 0,
		ctx: {}
	});
	qe(e);
}
function Mt(e) {
	for (let t of k(e)) t.defend = 0, t.skipRavage = !1, t.skipBuild = !1, t.skipExplore = !1, t.isolate = !1, t.noBlight = !1, t.dahanGuard = !1, t.dahanSimul = !1;
	e.dahanShield = !1, e.vengeance = [], e.vengeanceMute = !1, e.chokeRavage = !1, e.chokeBuild = !1;
	for (let t of e.players) {
		let n = e.spirits[t];
		n.discard.push(...n.played), n.played = [], n.bonusElems = [], n.playsBonus = 0, n.rangeBonus = 0, n.keepCard = 0, n.fastCards = [];
	}
	e.round += 1, Et(e);
}
function Nt(e, t) {
	let n = e.spirits[t.seat], r = M(e, t, "keep", n.played, n.keepCard, !0);
	if (r) for (let e of r) n.played.splice(n.played.indexOf(e), 1), n.hand.push(e);
}
function Pt(e) {
	switch (e.invaderStep) {
		case 0:
			e.blight.flipped && e.queue.push({
				seat: e.players[0],
				source: "blightFlipped",
				kind: "fear",
				stepsLeft: 0,
				ctx: {}
			}), e.invaderStep = 1, qe(e);
			break;
		case 1:
			if (!e.fear.resolving && e.fear.pending.length > 0) {
				let t = e.fear.pending.shift();
				e.fear.resolving = t, e.queue.push({
					seat: e.players[0],
					source: `fear:${t}`,
					kind: "fear",
					stepsLeft: 0,
					ctx: {}
				}), qe(e);
			}
			!e.pending && e.queue.length === 0 && e.fear.resolving && (e.fear.resolved.push(e.fear.resolving), e.fear.resolving = null, e.terror = Math.min(3, 1 + Math.floor(e.fear.resolved.length / 3)), Ge(e)), !e.pending && e.queue.length === 0 && !e.fear.resolving && e.fear.pending.length === 0 && (e.invaderStep = 2);
			break;
		case 2:
			if (!e.chokeRavage && (e.chokeRavage = !0, Lt(e, "ravage"), qe(e), e.pending || e.awaitingBeat || e.queue.length || e.over)) break;
			zt(e, "ravage") && (e.invaderStep = 3);
			break;
		case 3:
			if (!e.chokeBuild && (e.chokeBuild = !0, Lt(e, "build"), qe(e), e.pending || e.awaitingBeat || e.queue.length || e.over)) break;
			zt(e, "build") && (e.invaderStep = 4);
			break;
		case 4:
			zt(e, "explore") && (e.invaderStep = 5);
			break;
		case 5: {
			e.invader.ravage && e.invader.discard.push(e.invader.ravage), e.invader.ravage = e.invader.build, e.invader.build = e.invader.explore;
			let t = e.invader.deck.pop();
			if (!t) {
				e.over = {
					win: !1,
					reason: "time"
				}, e.phase = "over";
				return;
			}
			e.invader.explore = t, e.phase = "slow", kt(e, "slow"), qe(e), At(e);
			break;
		}
	}
	e.invaderCursor || Ge(e);
}
function Ft(e) {
	return be.find((t) => t.id === e);
}
function It(e, t, n) {
	let r = e.lands[t];
	return r.n === 0 ? !1 : n.includes(r.terrain) || n.includes("Coastal") && r.coastal;
}
function Lt(e, t) {
	let n = e.players.find((t) => e.spirits[t]?.spirit === "aSpreadOfRampantGreen" && !e.spirits[t].dead);
	if (!n) return;
	let r = t === "ravage" ? e.invader.ravage : e.invader.build;
	if (!r) return;
	let i = Ft(r).terrains;
	for (let r of k(e)) if (!(!It(e, r.id, i) || (r.presence[n] ?? 0) < 2)) {
		if (t === "ravage") {
			if (r.skipRavage || r.explorers + r.towns * 2 + r.cities * 3 <= 0) continue;
		} else if (r.skipBuild || r.explorers + r.towns + r.cities === 0) continue;
		e.queue.push({
			seat: n,
			source: "chokeTheLandWithGreen",
			kind: "special",
			stepsLeft: 0,
			ctx: {
				landId: r.id,
				mode: t
			}
		});
	}
}
function Rt(e, t) {
	let n = t.ctx.landId, r = t.ctx.mode, i = e.lands[n];
	if ((i.presence[t.seat] ?? 0) < 2 || r === "ravage" && (i.skipRavage || i.explorers + i.towns * 2 + i.cities * 3 <= 0) || r === "build" && (i.skipBuild || i.explorers + i.towns + i.cities === 0)) return;
	let a = j(e, t, "skip");
	if (a === void 0) {
		e.pending?.kind === "yesno" && (e.pending.why = `chokeTheLandWithGreen:${r}:${n}`);
		return;
	}
	a && (We(e, n, t.seat, 1), r === "ravage" ? i.skipRavage = !0 : i.skipBuild = !0);
}
function zt(e, t) {
	let n = e.invader[t];
	if (!n) return !0;
	let r = e.invaderCursor ??= {
		lands: k(e).filter((t) => It(e, t.id, Ft(n).terrains)).map((e) => e.id),
		index: 0,
		stage: "defend"
	}, i = r.lands[r.index];
	if (!i) return delete e.invaderCursor, !0;
	if (t === "ravage") {
		if (!Bt(e, i)) return !1;
	} else t === "build" ? Vt(e, i) : Ht(e, n, i);
	return r.index += 1, r.stage = "defend", r.index >= r.lands.length && (delete e.invaderCursor, !0);
}
function Bt(e, t) {
	let n = e.lands[t], r = e.invaderCursor, i = n.explorers + n.towns * 2 + n.cities * 3;
	if (r.stage === "defend") {
		if (n.skipRavage || i <= 0) return !0;
		let a = n.defend;
		for (let t of e.players) {
			let r = e.spirits[t];
			r && !r.dead && r.spirit === "vitalStrengthOfTheEarth" && (n.presence[t] ?? 0) >= 2 && (a += 3);
		}
		return r.effective = Math.max(0, i - a), r.stage = "ravage", O(e, {
			kind: "defend",
			land: t,
			n: a,
			source: "invader"
		}), !1;
	}
	if (r.stage === "ravage") {
		let i = r.effective ?? 0;
		i >= 2 && He(e, t);
		let a = e.dahanShield || n.dahanGuard ? 0 : Math.min(n.dahan, Math.floor(i / 2));
		r.killed = a, r.counter = (n.dahanSimul ? n.dahan : n.dahan - a) * 2;
		for (let r = 0; r < a; r++) O(e, {
			kind: "destroy",
			land: t,
			piece: "dahan",
			ordinal: n.dahan - 1 - r
		});
		return n.dahan -= a, r.stage = "counter", O(e, {
			kind: "ravage",
			land: t,
			n: i,
			source: "invader"
		}), !1;
	}
	let a = r.counter ?? 0;
	for (; a >= 3 && n.cities > 0;) I(e, t, "city"), a -= 3;
	for (; a >= 2 && n.towns > 0;) I(e, t, "town"), a -= 2;
	for (; a >= 1 && n.explorers > 0;) I(e, t, "explorer"), --a;
	O(e, {
		kind: "counter",
		land: t,
		n: r.counter ?? 0,
		source: "invader"
	});
	let o = r.killed ?? 0;
	if (o > 0) for (let r of e.players) {
		let i = e.spirits[r];
		if (i && !i.dead && i.spirit === "thunderspeaker") for (let i = 0; i < o; i += 1) {
			let i = [t, ...n.adj].filter((t) => (e.lands[t].presence[r] ?? 0) > 0);
			if (!i.length) break;
			if (We(e, i[0], r, 1), e.over) return !0;
		}
	}
	return !0;
}
function Vt(e, t) {
	let n = e.invader.build;
	if (!n) return;
	let r = Ft(n).terrains;
	for (let n of k(e)) t && n.id !== t || It(e, n.id, r) && !n.skipBuild && n.explorers + n.towns + n.cities !== 0 && (n.towns > n.cities ? (n.cities += 1, O(e, {
		kind: "place",
		land: n.id,
		piece: "city",
		ordinal: n.cities - 1,
		source: "build"
	})) : (n.towns += 1, O(e, {
		kind: "place",
		land: n.id,
		piece: "town",
		ordinal: n.towns - 1,
		source: "build"
	})));
}
function Ht(e, t, n) {
	let r = Ft(t).terrains;
	for (let t of k(e)) n && t.id !== n || !It(e, t.id, r) || t.skipExplore || t.isolate || (t.towns + t.cities > 0 || t.coastal || t.adj.some((t) => e.lands[t].towns + e.lands[t].cities > 0)) && (t.explorers += 1, O(e, {
		kind: "place",
		land: t.id,
		piece: "explorer",
		ordinal: t.explorers - 1,
		source: "explore"
	}));
}
function Ut(e, t) {
	let n = t.ctx.option, r = t.seat, i = e.spirits[r];
	switch (n.t) {
		case "reclaim":
			i.hand.push(...i.discard), i.discard = [];
			return;
		case "gainPower": {
			let n = t.ctx.drawn;
			if (!n && (n = e.minorDeck.splice(Math.max(0, e.minorDeck.length - 4)), t.ctx.drawn = n, n.length === 0)) return;
			let r = M(e, t, "keep", n, 1);
			if (!r) return;
			i.hand.push(...r);
			return;
		}
		case "energy":
			i.energy += n.n;
			return;
		case "cardPlay":
			i.playsBonus += n.n;
			return;
		case "addPresence":
		case "addPresenceDahan":
		case "addPresenceDahanInvaders":
		case "addPresenceCoastal":
		case "addPresenceOcean": {
			let a = t.ctx.fromTrack;
			if (a === void 0) {
				let n = +!!e.blight.flipped;
				if (i.spirit === "aSpreadOfRampantGreen" && i.destroyed > 0 && i.energy >= n) {
					let n = j(e, t, "useDestroyed");
					if (n === void 0) return;
					a = !n;
				} else a = !0;
				t.ctx.fromTrack = a;
			}
			let o = null;
			if (a) {
				let n = ze(e, t, "track");
				if (!n) return;
				o = n;
			}
			let s = (t) => {
				let r = e.lands[t];
				switch (n.t) {
					case "addPresenceDahan": return r.n !== 0 && r.dahan > 0;
					case "addPresenceDahanInvaders": return r.n !== 0 && (r.dahan > 0 || r.explorers + r.towns + r.cities > 0);
					case "addPresenceCoastal": return r.coastal;
					case "addPresenceOcean": return r.n === 0;
					default: return r.n !== 0;
				}
			}, c = "range" in n ? n.range : 1, l = k(e).filter((e) => (e.presence[r] ?? 0) > 0).map((e) => e.id), u = A(e, t, "land", k(e).filter((t) => s(t.id) && l.some((n) => ke(e, n, t.id) <= c)).map((e) => e.id));
			if (!u) return;
			o ? Qe(e, r, o, u) : (--i.destroyed, e.blight.flipped && --i.energy, e.lands[u].presence[r] = (e.lands[u].presence[r] ?? 0) + 1, O(e, {
				kind: "place",
				land: u,
				piece: `presence:${r}`,
				seat: r,
				ordinal: e.lands[u].presence[r] - 1
			}));
			return;
		}
		case "gatherPresenceEachOcean":
		case "pushPresenceEachOcean": {
			let i = n.t === "gatherPresenceEachOcean", a = t.ctx.oceans ??= k(e).filter((e) => e.n === 0 && (e.presence[r] ?? 0) > 0).map((e) => e.id), o = t.ctx.idx ?? 0;
			for (; o < a.length;) {
				let n = a[o], s = e.lands[n].adj, c = i ? s.filter((t) => (e.lands[t].presence[r] ?? 0) > 0) : s.filter((t) => e.lands[t].n !== 0);
				if (c.length === 0) {
					o += 1;
					continue;
				}
				let l = A(e, t, `ocean${o}`, c);
				if (!l) {
					t.ctx.idx = o;
					return;
				}
				Xe(e, i ? l : n, i ? n : l, "presence", r), o += 1, t.ctx.idx = o, e.awaitingBeat = !0;
				return;
			}
			return;
		}
		default: return;
	}
}
function Wt(e, t) {
	let n = e.players.filter((t) => !e.spirits[t].dead), r = t.ctx.idx ?? 0;
	for (; r < n.length;) {
		let i = n[r], a = k(e).filter((e) => (e.presence[i] ?? 0) > 0).map((e) => e.id);
		if (a.length === 0) {
			r += 1;
			continue;
		}
		if (e.blight.card === "downwardSpiral") {
			let n = `blight${r}`, o = A(e, {
				...t,
				seat: i
			}, n, a);
			if (!o) {
				t.ctx.idx = r;
				return;
			}
			We(e, o, i, 1);
		} else {
			let n = `forget${r}`, o = j(e, {
				...t,
				seat: i
			}, n);
			if (o === void 0) {
				t.ctx.idx = r;
				return;
			}
			if (o) {
				let n = e.spirits[i], a = [
					...n.hand,
					...n.discard,
					...n.played
				], o = `forgetCard${r}`, s = M(e, {
					...t,
					seat: i
				}, o, a, 1);
				if (!s) {
					t.ctx.idx = r;
					return;
				}
				let c = s[0];
				for (let e of [
					"hand",
					"discard",
					"played"
				]) {
					let t = n[e].indexOf(c);
					t >= 0 && n[e].splice(t, 1);
				}
				n.forgotten.push(c);
			} else {
				let n = `blight${r}`, o = A(e, {
					...t,
					seat: i
				}, n, a);
				if (!o) {
					t.ctx.idx = r;
					return;
				}
				We(e, o, i, 1);
			}
		}
		r += 1, t.ctx.idx = r, e.awaitingBeat = !0;
		return;
	}
}
Ke.growth = Ut, Ke.blightFlipped = Wt, Ke.cleanupKeep = Nt, Ke.chokeTheLandWithGreen = Rt;
function Gt(e, t, n) {
	if (t.type === "tick") {
		if (e.pending || e.over || !e.awaitingBeat && e.phase !== "invader") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return t.awaitingBeat = !1, delete t.resolution, t.queue.length > 0 ? qe(t) : t.phase === "invader" && Pt(t), At(t), Oe(t);
	}
	if (e.over) return {
		state: e,
		fx: []
	};
	switch (t.type) {
		case "pickSpirit": {
			let r = e.pending;
			if (r?.kind !== "pickSpirit" || r.seat !== n.by) return { code: "games.spiritisland.ui.errNotYourTurn" };
			if (!r.available.includes(t.spirit)) return { code: "games.spiritisland.ui.errBadSpirit" };
			let i = structuredClone(e);
			Te(i, n.by, t.spirit);
			let a = i.players[i.players.indexOf(n.by) + 1], o = E.map((e) => e.id).filter((e) => Object.values(i.spiritOf).includes(e));
			return a ? i.pending = {
				kind: "pickSpirit",
				seat: a,
				available: E.map((e) => e.id).filter((e) => !o.includes(e))
			} : Tt(i), Oe(i);
		}
		case "growth": {
			let r = e.pending;
			if (e.phase !== "growth" || r?.kind !== "growth" || r.seat !== n.by) return { code: "games.spiritisland.ui.errNotYourTurn" };
			let i = structuredClone(e), a = Ie(i, n.by);
			if (t.group < 0 || t.group >= a.growth.length) return { code: "games.spiritisland.ui.errBadGroup" };
			i.growthDone[n.by] = !0, i.pending = null;
			for (let e of a.growth[t.group]) i.queue.push({
				seat: n.by,
				source: "growth",
				kind: "growthOption",
				stepsLeft: 0,
				ctx: { option: e }
			});
			let o = i.players.find((e) => !i.growthDone[e] && !i.spirits[e].dead);
			return o ? i.pending = {
				kind: "growth",
				seat: o
			} : (qe(i), At(i)), Oe(i);
		}
		case "play": {
			let r = e.pending;
			if (e.phase !== "play" || r?.kind !== "play" || r.seat !== n.by) return { code: "games.spiritisland.ui.errNotYourTurn" };
			let i = structuredClone(e), a = i.spirits[n.by], o = t.cards;
			if (new Set(o).size !== o.length || !o.every((e) => a.hand.includes(e)) || o.length > Re(i, n.by)) return { code: "games.spiritisland.ui.errBadCards" };
			let s = o.reduce((e, t) => e + (D[t]?.cost ?? 0), 0);
			if (s > a.energy) return { code: "games.spiritisland.ui.errNoEnergy" };
			a.energy -= s;
			for (let e of o) a.hand.splice(a.hand.indexOf(e), 1), a.played.push(e);
			return O(i, {
				kind: "play",
				seat: n.by,
				n: o.length
			}), i.playDone[n.by] = !0, i.pending = null, Ot(i), Oe(i);
		}
		case "answer": {
			let r = e.pending;
			if (!r || r.seat !== n.by) return { code: "games.spiritisland.ui.errNotYourTurn" };
			if (r.kind === "growth" || r.kind === "play" || r.kind === "pickSpirit" || !Kt(e, r, t.value)) return { code: "games.spiritisland.ui.errBadAnswer" };
			let i = structuredClone(e), a = i.queue[0];
			return a ? (a.ctx[r.key] = t.value, i.pending = null, qe(i), At(i), Oe(i)) : { code: "games.spiritisland.ui.errBadAnswer" };
		}
		case "pass": {
			if (e.awaitingBeat || e.pending || e.queue.length === 0) return { code: "games.spiritisland.ui.errBadAnswer" };
			let t = e.queue[0];
			if (t.kind !== "innate" || t.seat !== n.by) return { code: "games.spiritisland.ui.errBadAnswer" };
			let r = structuredClone(e);
			return r.queue.shift(), qe(r), At(r), Oe(r);
		}
	}
}
function Kt(e, t, n) {
	switch (t.kind) {
		case "land": return typeof n == "string" && (t.legal.includes(n) || (t.shadows?.includes(n) ?? !1));
		case "spirit": return typeof n == "string" && t.spirits.includes(n);
		case "yesno": return typeof n == "boolean";
		case "track": return n === "energy" || n === "plays";
		case "number": return typeof n == "number" && Number.isInteger(n) && n >= t.min && n <= t.max;
		case "cards": return !Array.isArray(n) || !n.every((e) => typeof e == "string" && t.cards.includes(e)) || new Set(n).size !== n.length ? !1 : t.upto ? n.length <= t.count : n.length === Math.min(t.count, t.cards.length);
		case "pieces": {
			if (!Array.isArray(n)) return !1;
			let e = n;
			if (t.upto ? e.length > t.count : e.length !== Math.min(t.count, t.legal.length)) return !1;
			let r = /* @__PURE__ */ new Map();
			for (let e of t.legal) {
				let t = e.type + (e.seat ?? "");
				r.set(t, (r.get(t) ?? 0) + 1);
			}
			let i = /* @__PURE__ */ new Map();
			for (let t of e) {
				let e = t.type + (t.seat ?? "");
				if (i.set(e, (i.get(e) ?? 0) + 1), (i.get(e) ?? 0) > (r.get(e) ?? 0)) return !1;
			}
			return !0;
		}
		default: return !1;
	}
}
function qt(e) {
	let t = e.queue[0];
	return {
		public: {
			players: e.players,
			boards: e.boards,
			lands: Object.values(e.lands).map((e) => ({
				id: e.id,
				board: e.board,
				n: e.n,
				terrain: e.terrain,
				adj: e.adj,
				coastal: e.coastal,
				explorers: e.explorers,
				towns: e.towns,
				cities: e.cities,
				dahan: e.dahan,
				blight: e.blight,
				presence: e.presence,
				defend: e.defend,
				skipRavage: e.skipRavage,
				skipBuild: e.skipBuild,
				skipExplore: e.skipExplore,
				isolate: e.isolate
			})),
			spirits: Object.fromEntries(e.players.map((t) => {
				let n = e.spirits[t];
				return [t, n ? {
					spirit: n.spirit,
					board: n.board,
					energy: n.energy,
					energyIdx: n.energyIdx,
					playsIdx: n.playsIdx,
					energyPerTurn: Le(e, t),
					playsPerTurn: Re(e, t),
					elements: Pe(e, t),
					fastCards: n.fastCards,
					rangeBonus: n.rangeBonus,
					innateLevels: Object.fromEntries(Ie(e, t).innates.map((n) => [n.id, Fe(e, t, n.thresholds)])),
					hand: n.hand,
					discard: n.discard,
					played: n.played,
					forgotten: n.forgotten,
					dead: n.dead
				} : {
					spirit: "",
					board: "",
					energy: 0,
					energyIdx: 0,
					playsIdx: 0,
					energyPerTurn: 0,
					playsPerTurn: 0,
					elements: {
						counts: {},
						any: 0
					},
					fastCards: [],
					rangeBonus: 0,
					innateLevels: {},
					hand: [],
					discard: [],
					played: [],
					forgotten: [],
					dead: !1
				}];
			})),
			phase: e.phase,
			round: e.round,
			pending: e.pending ? {
				kind: e.pending.kind,
				seat: e.pending.seat,
				why: "why" in e.pending ? e.pending.why : "",
				..."legal" in e.pending && e.pending.kind !== "pieces" ? { legal: e.pending.legal } : {},
				...e.pending.kind === "land" && e.pending.shadows?.length ? { shadows: e.pending.shadows } : {},
				..."cards" in e.pending ? { cards: e.pending.cards } : {},
				..."spirits" in e.pending ? { spirits: e.pending.spirits } : {},
				..."count" in e.pending ? { count: e.pending.count } : {},
				..."upto" in e.pending ? { upto: e.pending.upto } : {},
				..."min" in e.pending ? { min: e.pending.min } : {},
				..."max" in e.pending ? { max: e.pending.max } : {},
				..."land" in e.pending ? { land: e.pending.land } : {},
				...e.pending.kind === "pieces" ? { pieces: e.pending.legal } : {},
				...e.pending.kind === "pickSpirit" ? { spirits: e.pending.available } : {}
			} : null,
			current: t ? {
				seat: t.seat,
				source: t.source,
				kind: t.kind,
				...typeof t.ctx.target == "string" ? { target: t.ctx.target } : {}
			} : null,
			invaderStep: e.invaderStep,
			...e.resolution ? { resolution: e.resolution } : {},
			invader: {
				deckCount: e.invader.deck.length,
				discard: e.invader.discard,
				ravage: e.invader.ravage,
				build: e.invader.build,
				explore: e.invader.explore
			},
			fear: {
				earned: e.fear.earned,
				poolMax: e.fear.poolMax,
				deckCount: e.fear.deck.length,
				pending: e.fear.pending,
				resolvedCount: e.fear.resolved.length
			},
			blight: {
				pool: e.blight.pool,
				card: e.blight.card,
				flipped: e.blight.flipped
			},
			terror: e.terror,
			growthDone: e.growthDone,
			playDone: e.playDone,
			over: e.over,
			log: e.log.slice(-30)
		},
		private: {}
	};
}
function Jt(e) {
	return e.over ? e.over.win ? {
		phase: "done",
		winner: [...e.players],
		ranking: [...e.players]
	} : {
		phase: "done",
		winner: [],
		ranking: [...e.players]
	} : { phase: e.phase };
}
function Yt(e) {
	return (e.awaitingBeat || e.phase === "invader") && !e.pending && !e.over ? 900 : null;
}
var Xt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: ue,
	schemas: {
		action: pe,
		publicView: T,
		privateView: _e
	},
	setup: wt,
	reduce: Gt,
	viewFor: qt,
	status: Jt,
	nextTickIn: Yt
}, Zt = {
	acceleratedRot: {
		name: {
			zh: "加速腐烂",
			en: "Accelerated Rot"
		},
		text: {
			zh: [
				"2 点{Fear}。",
				"4 点伤害。",
				"5 点伤害。移除 1 个 {Blight}。"
			],
			en: [
				"2 {Fear}.",
				"4 Damage.",
				"5 Damage. Remove 1 {Blight}."
			]
		}
	},
	aYearOfPerfectStillness: {
		name: {
			zh: "完美静止之年",
			en: "A Year of Perfect Stillness"
		},
		text: {
			zh: ["本回合入侵者跳过目标格的所有行动。"],
			en: ["Invaders skip all Actions in target land this turn."]
		}
	},
	blazingRenewal: {
		name: {
			zh: "烈焰焕新",
			en: "Blazing Renewal"
		},
		text: {
			zh: ["在你 {Presence} 的 {2Range} 内选择 1 个格子:目标精灵在该格放置 2 个其 {DestroyedPresenceNew};若放置了 {Presence},对每个 {Town}/{City} 造成 2 点伤害。", "若放置了 {Presence},造成 4 点伤害。"],
			en: ["In a single land within {2Range} of your {Presence}: target Spirit Adds 2 of their {DestroyedPresenceNew}. If any {Presence} was Added, 2 Damage to each {Town}/{City}.", "If any {Presence} was Added, 4 Damage."]
		}
	},
	boonOfVigor: {
		name: {
			zh: "活力恩赐",
			en: "Boon of Vigor"
		},
		text: {
			zh: ["若目标是你自己,获得 1 能量。", "若目标是其他精灵,其本回合每打出过 1 张威力牌,获得 1 能量。"],
			en: ["If you target yourself, gain 1 Energy.", "If you target another Spirit, they gain 1 Energy per Power Card they played this turn."]
		}
	},
	callOfTheDahanWays: {
		name: {
			zh: "达罕之道的呼唤",
			en: "Call of the Dahan Ways"
		},
		text: {
			zh: ["将 1 个 {Explorer} 替换为 1 个 {Dahan}。", "你可以改为将 1 个 {Town} 替换为 1 个 {Dahan}。"],
			en: ["Replace 1 {Explorer} with 1 {Dahan}.", "You may instead Replace 1 {Town} with 1 {Dahan}."]
		}
	},
	callOfTheDeeps: {
		name: {
			zh: "深渊的呼唤",
			en: "Call of the Deeps"
		},
		text: {
			zh: ["聚集 1 个 {Explorer}。", "若目标格是海洋,你可以再聚集 1 个 {Explorer}。"],
			en: ["Gather 1 {Explorer}.", "If target land is the Ocean, you may Gather another {Explorer}."]
		}
	},
	callOnMidnightsDreams: {
		name: {
			zh: "午夜之梦祈愿",
			en: "Call on Midnight's Dreams"
		},
		text: {
			zh: [
				"若目标格有 {Dahan},获得 1 张高级威力牌;若你遗忘本牌,获得等同于目标格 {Dahan} 数量的能量,并可以立即打出该高级威力牌(需支付费用)。",
				"{Or}",
				"若有入侵者在场,2 点{Fear}。"
			],
			en: [
				"If target land has {Dahan}, gain a Major Power. If you Forget this Power, gain Energy equal to {Dahan} and you may play the Major Power immediately, paying its cost.",
				"{Or}",
				"If Invaders are present, 2 {Fear}."
			]
		}
	},
	callToBloodshed: {
		name: {
			zh: "血战召唤",
			en: "Call to Bloodshed"
		},
		text: {
			zh: [
				"每个 {Dahan} 造成 1 点伤害。",
				"{Or}",
				"聚集至多 3 个 {Dahan}。"
			],
			en: [
				"1 Damage per {Dahan}.",
				"{Or}",
				"Gather up to 3 {Dahan}."
			]
		}
	},
	callToIsolation: {
		name: {
			zh: "隔绝召唤",
			en: "Call to Isolation"
		},
		text: {
			zh: [
				"每个 {Dahan} 推走 1 个 {Explorer}/{Town}。",
				"{Or}",
				"推走 1 个 {Dahan}。"
			],
			en: [
				"Push 1 {Explorer}/{Town} per {Dahan}.",
				"{Or}",
				"Push 1 {Dahan}."
			]
		}
	},
	callToMigrate: {
		name: {
			zh: "迁徙召唤",
			en: "Call to Migrate"
		},
		text: {
			zh: ["聚集至多 3 个 {Dahan}。", "推走至多 3 个 {Dahan}。"],
			en: ["Gather up to 3 {Dahan}.", "Push up to 3 {Dahan}."]
		}
	},
	callToTend: {
		name: {
			zh: "照料召唤",
			en: "Call to Tend"
		},
		text: {
			zh: [
				"移除 1 个 {Blight}。",
				"{Or}",
				"推走至多 3 个 {Dahan}。"
			],
			en: [
				"Remove 1 {Blight}.",
				"{Or}",
				"Push up to 3 {Dahan}."
			]
		}
	},
	cleansingFloods: {
		name: {
			zh: "涤净洪流",
			en: "Cleansing Floods"
		},
		text: {
			zh: [
				"4 点伤害。",
				"移除 1 个 {Blight}。",
				"10 点伤害。"
			],
			en: [
				"4 Damage.",
				"Remove 1 {Blight}.",
				"10 Damage."
			]
		}
	},
	concealingShadows: {
		name: {
			zh: "匿影藏形",
			en: "Concealing Shadows"
		},
		text: {
			zh: ["1 点{Fear}。", "本回合 {Dahan} 不受入侵者破坏造成的伤害。"],
			en: ["1 {Fear}.", "{Dahan} take no damage from Ravaging Invaders this turn."]
		}
	},
	cropsWitherAndFade: {
		name: {
			zh: "作物枯萎凋零",
			en: "Crops Wither and Fade"
		},
		text: {
			zh: [
				"2 点{Fear}。",
				"将 1 个 {Town} 替换为 1 个 {Explorer}。",
				"{Or}",
				"将 1 个 {City} 替换为 1 个 {Town}。"
			],
			en: [
				"2 {Fear}.",
				"Replace 1 {Town} with 1 {Explorer}.",
				"{Or}",
				"Replace 1 {City} with 1 {Town}."
			]
		}
	},
	darkAndTangledWoods: {
		name: {
			zh: "黑暗盘结的森林",
			en: "Dark and Tangled Woods"
		},
		text: {
			zh: ["2 点{Fear}。", "若目标格是 {MountainJungle},提供防御 3。"],
			en: ["2 {Fear}.", "If target land is {MountainJungle}, Defend 3."]
		}
	},
	delusionsOfDanger: {
		name: {
			zh: "险象妄想",
			en: "Delusions of Danger"
		},
		text: {
			zh: [
				"推走 1 个 {Explorer}。",
				"{Or}",
				"2 点{Fear}。"
			],
			en: [
				"Push 1 {Explorer}.",
				"{Or}",
				"2 {Fear}."
			]
		}
	},
	devouringAnts: {
		name: {
			zh: "噬人蚁群",
			en: "Devouring Ants"
		},
		text: {
			zh: [
				"1 点{Fear}。",
				"1 点伤害。",
				"消灭 1 个 {Dahan}。",
				"若目标格是 {JungleSands},额外 +1 点伤害。"
			],
			en: [
				"1 {Fear}.",
				"1 Damage.",
				"Destroy 1 {Dahan}.",
				"If target land is {JungleSands}, +1 Damage."
			]
		}
	},
	dissolveTheBondsOfKinship: {
		name: {
			zh: "瓦解亲情纽带",
			en: "Dissolve the Bonds of Kinship"
		},
		text: {
			zh: ["将 1 个 {City} 替换为 2 个 {Explorer};将 1 个 {Town} 替换为 1 个 {Explorer};将 1 个 {Dahan} 替换为 1 个 {Explorer}。将目标格的所有 {Explorer} 推走,分散到尽可能多的不同格子。", "推走之前,{Explorer} 与 {Town}/{City} 互相造成伤害。"],
			en: ["Replace 1 {City} with 2 {Explorer}. Replace 1 {Town} with 1 {Explorer}. Replace 1 {Dahan} with 1 {Explorer}. Push all {Explorer} from target land to as many different lands as possible.", "Before Pushing, {Explorer} and {Town}/{City} do damage to each other."]
		}
	},
	drawOfTheFruitfulEarth: {
		name: {
			zh: "丰饶大地的牵引",
			en: "Draw of the Fruitful Earth"
		},
		text: {
			zh: ["聚集至多 2 个 {Explorer}。", "聚集至多 2 个 {Dahan}。"],
			en: ["Gather up to 2 {Explorer}.", "Gather up to 2 {Dahan}."]
		}
	},
	dreadApparitions: {
		name: {
			zh: "骇人幻影",
			en: "Dread Apparitions"
		},
		text: {
			zh: [
				"当威力在目标格产生 {Fear} 时,每点 {Fear} 提供防御 1。",
				"1 点{Fear}。",
				"(「千死之梦」产生的 {Fear} 计入;消灭 {Town}/{City} 产生的 {Fear} 不计入。)"
			],
			en: [
				"When Powers generate {Fear} in target land, Defend 1 per {Fear}.",
				"1 {Fear}.",
				"({Fear} from To Dream a Thousand Deaths counts. {Fear} from destroying {Town}/{City} does not.)"
			]
		}
	},
	dreamsOfTheDahan: {
		name: {
			zh: "达罕之梦",
			en: "Dreams of the Dahan"
		},
		text: {
			zh: [
				"聚集至多 2 个 {Dahan}。",
				"{Or}",
				"若目标格有 {Town}/{City},每个 {Dahan} 产生 1 点{Fear}(至多 3 点{Fear})。"
			],
			en: [
				"Gather up to 2 {Dahan}.",
				"{Or}",
				"If target land has {Town}/{City}, 1 {Fear} for each {Dahan}, to a maximum of 3 {Fear}."
			]
		}
	},
	driftDownIntoSlumber: {
		name: {
			zh: "沉入安眠",
			en: "Drift Down into Slumber"
		},
		text: {
			zh: ["防御 1。", "若目标格是 {JungleSands},改为防御 4。"],
			en: ["Defend 1.", "If target land is {JungleSands}, instead, Defend 4."]
		}
	},
	drought: {
		name: {
			zh: "大旱",
			en: "Drought"
		},
		text: {
			zh: [
				"消灭 3 个 {Town}。",
				"对每个 {Town}/{City} 造成 1 点伤害。",
				"添加 1 个 {Blight}。",
				"消灭 1 个 {City}。"
			],
			en: [
				"Destroy 3 {Town}.",
				"1 Damage to each {Town}/{City}.",
				"Add 1 {Blight}.",
				"Destroy 1 {City}."
			]
		}
	},
	elementalBoon: {
		name: {
			zh: "元素恩赐",
			en: "Elemental Boon"
		},
		text: {
			zh: ["目标精灵获得其自选的 3 种不同元素。", "若目标是其他精灵,你也获得这些元素。"],
			en: ["Target Spirit gains 3 different Elements of their choice.", "If you target another Spirit, you also gain those Elements."]
		}
	},
	encompassingWard: {
		name: {
			zh: "环抱庇护",
			en: "Encompassing Ward"
		},
		text: {
			zh: ["目标精灵在其每个格子提供防御 2。"],
			en: ["Target Spirit provides Defend 2 in each of its lands."]
		}
	},
	enticingSplendor: {
		name: {
			zh: "诱目华彩",
			en: "Enticing Splendor"
		},
		text: {
			zh: [
				"聚集 1 个 {Explorer}/{Town}。",
				"{Or}",
				"聚集至多 2 个 {Dahan}。"
			],
			en: [
				"Gather 1 {Explorer}/{Town}.",
				"{Or}",
				"Gather up to 2 {Dahan}."
			]
		}
	},
	entrancingApparitions: {
		name: {
			zh: "摄魂幻影",
			en: "Entrancing Apparitions"
		},
		text: {
			zh: ["防御 2。", "若没有入侵者在场,聚集至多 2 个 {Explorer}。"],
			en: ["Defend 2.", "If there are no Invaders present, Gather up to 2 {Explorer}."]
		}
	},
	entwinedPower: {
		name: {
			zh: "纠缠之力",
			en: "Entwined Power"
		},
		text: {
			zh: ["你与目标精灵可以借用彼此的 {Presence} 来指定威力目标(仅限指定目标);目标精灵获得 1 张威力牌,你获得其未保留的威力牌中的 1 张。", "你与目标精灵各获得 3 能量,并可以互赠 1 张手牌。"],
			en: ["You and target Spirit may use each other's {Presence} to target Powers (only). Target Spirit gains a Power Card. You gain one of the Power Cards they did not keep.", "You and target Spirit each gain 3 Energy and may gift each other 1 Power Card from hand."]
		}
	},
	favorsCalledDue: {
		name: {
			zh: "人情清算",
			en: "Favors Called Due"
		},
		text: {
			zh: ["聚集至多 4 个 {Dahan}。", "若有入侵者在场,且 {Dahan} 的数量此刻多于入侵者,3 点{Fear}。"],
			en: ["Gather up to 4 {Dahan}.", "If Invaders are present and {Dahan} now outnumber them, 3 {Fear}."]
		}
	},
	fieldsChokedWithGrowth: {
		name: {
			zh: "蔓生壅塞的田野",
			en: "Fields Choked with Growth"
		},
		text: {
			zh: [
				"推走 1 个 {Town}。",
				"{Or}",
				"推走 3 个 {Dahan}。"
			],
			en: [
				"Push 1 {Town}.",
				"{Or}",
				"Push 3 {Dahan}."
			]
		}
	},
	flashFloods: {
		name: {
			zh: "骤发洪水",
			en: "Flash Floods"
		},
		text: {
			zh: ["1 点伤害。", "若目标格沿海,额外 +1 点伤害。"],
			en: ["1 Damage.", "If target land is Coastal, +1 Damage."]
		}
	},
	giftOfConstancy: {
		name: {
			zh: "恒心之礼",
			en: "Gift of Constancy"
		},
		text: {
			zh: [
				"目标精灵获得 2 能量。",
				"时光流逝阶段,目标精灵可以收回 1 张威力牌,而不弃置它。",
				"若目标是其他精灵,你也可以收回 1 张威力牌而不弃置。"
			],
			en: [
				"Target Spirit gains 2 Energy.",
				"During Time Passes, target Spirit may Reclaim 1 Power Card instead of discarding it.",
				"If you target another Spirit, you may also Reclaim 1 Power Card instead of discarding it."
			]
		}
	},
	giftOfLivingEnergy: {
		name: {
			zh: "生灵能量之礼",
			en: "Gift of Living Energy"
		},
		text: {
			zh: [
				"目标精灵获得 1 能量。",
				"若你有至少 2 个 {SacredSite},目标精灵获得 1 能量。",
				"若目标是其他精灵,其获得 1 能量。"
			],
			en: [
				"Target Spirit gains 1 Energy.",
				"If you have at least 2 {SacredSite}, target Spirit gains 1 Energy.",
				"If you target another Spirit, they gain 1 Energy."
			]
		}
	},
	giftOfPower: {
		name: {
			zh: "力量之礼",
			en: "Gift of Power"
		},
		text: {
			zh: ["目标精灵获得 1 张低级威力牌。"],
			en: ["Target Spirit gains a Minor Power Card."]
		}
	},
	giftOfProliferation: {
		name: {
			zh: "增殖之礼",
			en: "Gift of Proliferation"
		},
		text: {
			zh: ["目标精灵在距其 {Presence} {1Range} 内放置 1 个 {Presence}。"],
			en: ["Target Spirit adds 1 {Presence} up to {1Range} from their {Presence}."]
		}
	},
	gnawingRootbiters: {
		name: {
			zh: "啃根兽群",
			en: "Gnawing Rootbiters"
		},
		text: {
			zh: ["推走至多 2 个 {Town}。"],
			en: ["Push up to 2 {Town}."]
		}
	},
	graspingTide: {
		name: {
			zh: "攫人之潮",
			en: "Grasping Tide"
		},
		text: {
			zh: ["2 点{Fear}。", "防御 4。"],
			en: ["2 {Fear}.", "Defend 4."]
		}
	},
	guardTheHealingLand: {
		name: {
			zh: "守护疗愈之地",
			en: "Guard the Healing Land"
		},
		text: {
			zh: ["移除 1 个 {Blight}。", "防御 4。"],
			en: ["Remove {Blight}.", "Defend 4."]
		}
	},
	harbingersOfTheLightning: {
		name: {
			zh: "闪电先驱",
			en: "Harbingers of the Lightning"
		},
		text: {
			zh: ["推走至多 2 个 {Dahan}。", "若你将 {Dahan} 推入了有 {Town}/{City} 的格子,获得 1 点{Fear}。"],
			en: ["Push up to 2 {Dahan}.", "1 {Fear} if you pushed any {Dahan} into a land with {Town}/{City}."]
		}
	},
	indomitableClaim: {
		name: {
			zh: "不屈的宣示",
			en: "Indomitable Claim"
		},
		text: {
			zh: ["在目标格放置 1 个 {Presence},即使地形本不允许;防御 20。", "若有入侵者在场,3 点{Fear};跳过所有入侵者行动(目标格不进行破坏、建造与探索)。"],
			en: ["Add 1 {Presence} in target land even if you normally could not due to land type. Defend 20.", "3 {Fear} if Invaders are present. Skip all Invader Actions. (Do not Ravage, Build, or Explore in target land.)"]
		}
	},
	infiniteVitality: {
		name: {
			zh: "无穷活力",
			en: "Infinite Vitality"
		},
		text: {
			zh: [
				"{Dahan} 生命 +4(在目标格时)。",
				"无法添加 {Blight}(本应添加到目标格时,改为留在枯萎卡上)。",
				"{Dahan} 不会受伤或被消灭(在目标格时);从目标格或相邻格移除 1 个 {Blight}。"
			],
			en: [
				"{Dahan} have +4 Health (while in target land).",
				"{Blight} cannot be added. (When it would be added to target land, instead leave it on the Blight card.)",
				"{Dahan} cannot be Damaged and Destroyed (in target land). Remove 1 {Blight} from target or adjacent land."
			]
		}
	},
	landOfHauntsAndEmbers: {
		name: {
			zh: "鬼影与余烬之地",
			en: "Land of Haunts and Embers"
		},
		text: {
			zh: [
				"2 点{Fear};推走至多 2 个 {Explorer}/{Town}。",
				"若有 {Blight} 在场,2 点{Fear}并推走至多 2 个 {Explorer}/{Town}。",
				"添加 1 个 {Blight}。"
			],
			en: [
				"2 {Fear}. Push up to 2 {Explorer}/{Town}.",
				"If {Blight} is present, 2 {Fear} and Push up to 2 {Explorer}/{Town}.",
				"Add 1 {Blight}."
			]
		}
	},
	lightningsBoon: {
		name: {
			zh: "闪电恩泽",
			en: "Lightning's Boon"
		},
		text: {
			zh: ["目标精灵本回合可以将至多 2 张慢速威力当作快速威力使用。"],
			en: ["Target Spirit may use up to 2 慢速 Powers as if they were 快速 Powers this turn."]
		}
	},
	lureOfTheUnknown: {
		name: {
			zh: "未知的诱惑",
			en: "Lure of the Unknown"
		},
		text: {
			zh: ["聚集 1 个 {Explorer}/{Town}。"],
			en: ["Gather 1 {Explorer}/{Town}."]
		}
	},
	manifestationOfPowerAndGlory: {
		name: {
			zh: "力量与荣耀的显化",
			en: "Manifestation of Power and Glory"
		},
		text: {
			zh: ["1 点{Fear}。", "每个 {Dahan} 造成等同于你在目标格的 {Presence} 数量的伤害。"],
			en: ["1 {Fear}.", "Each {Dahan} deals Damage equal to the number of your {Presence} in target land."]
		}
	},
	mantleOfDread: {
		name: {
			zh: "恐惧披风",
			en: "Mantle of Dread"
		},
		text: {
			zh: ["2 点{Fear}。", "目标精灵可以从其一个格子推走 1 个 {Explorer} 和 1 个 {Town}。"],
			en: ["2 {Fear}.", "Target Spirit may Push 1 {Explorer} and 1 {Town} from one of their lands."]
		}
	},
	mistsOfOblivion: {
		name: {
			zh: "湮灭之雾",
			en: "Mists of Oblivion"
		},
		text: {
			zh: [
				"本威力每消灭 1 个 {Town}/{City},产生 1 点{Fear}(至多 4 点{Fear})。",
				"对每个入侵者造成 1 点伤害。",
				"3 点伤害。"
			],
			en: [
				"1 {Fear} per {Town}/{City} this Power Destroys (max 4 {Fear}).",
				"1 Damage to each Invader.",
				"3 Damage."
			]
		}
	},
	naturesResilience: {
		name: {
			zh: "自然的韧性",
			en: "Nature's Resilience"
		},
		text: {
			zh: ["防御 6。", "你可以改为移除 1 个 {Blight}。"],
			en: ["Defend 6.", "You may instead Remove 1 {Blight}."]
		}
	},
	overgrowInANight: {
		name: {
			zh: "一夜蔓生",
			en: "Overgrow in a Night"
		},
		text: {
			zh: [
				"放置 1 个 {Presence}。",
				"{Or}",
				"若目标格有你的 {Presence} 且有入侵者,3 点{Fear}。"
			],
			en: [
				"Add 1 {Presence}.",
				"{Or}",
				"If target land has your {Presence} and Invaders, 3 {Fear}."
			]
		}
	},
	paralyzingFright: {
		name: {
			zh: "麻痹恐惧",
			en: "Paralyzing Fright"
		},
		text: {
			zh: [
				"4 点{Fear}。",
				"跳过所有入侵者行动。",
				"(目标格不进行破坏、建造与探索。)",
				"4 点{Fear}。"
			],
			en: [
				"4 {Fear}.",
				"Skip all Invader Actions.",
				"(Do not Ravage, Build, or Explore in target land.)",
				"4 {Fear}."
			]
		}
	},
	pillarOfLivingFlame: {
		name: {
			zh: "活焰之柱",
			en: "Pillar of Living Flame"
		},
		text: {
			zh: [
				"3 点{Fear}。",
				"5 点伤害。",
				"若目标格是 {JungleWetland},添加 1 个 {Blight}。",
				"2 点{Fear}和 5 点伤害。"
			],
			en: [
				"3 {Fear}.",
				"5 Damage.",
				"If target land is {JungleWetland}, add 1 {Blight}.",
				"2 {Fear} and 5 Damage."
			]
		}
	},
	poisonedLand: {
		name: {
			zh: "毒化之地",
			en: "Poisoned Land"
		},
		text: {
			zh: [
				"1 点{Fear}。",
				"7 点伤害。",
				"添加 1 个 {Blight}。",
				"消灭所有 {Dahan}。",
				"每个 {Blight}(含刚添加的)产生 1 点{Fear}和 4 点伤害。"
			],
			en: [
				"1 {Fear}.",
				"7 Damage.",
				"Add 1 {Blight}",
				"Destroy all {Dahan}.",
				"For each {Blight} (including the one just added), 1 {Fear} and 4 Damage."
			]
		}
	},
	powerstorm: {
		name: {
			zh: "威力风暴",
			en: "Powerstorm"
		},
		text: {
			zh: [
				"目标精灵获得 3 能量。",
				"本回合一次,目标精灵可以重新支付费用,重复结算 1 张威力牌。",
				"目标精灵可以重新支付费用,重复结算至多 2 张其他威力牌。"
			],
			en: [
				"Target Spirit gains 3 Energy.",
				"Once this turn, target Spirit may Repeat a Power Card by paying its cost again.",
				"Target may Repeat up to 2 other Power Cards by paying their costs."
			]
		}
	},
	predatoryNightmares: {
		name: {
			zh: "掠食梦魇",
			en: "Predatory Nightmares"
		},
		text: {
			zh: [
				"2 点伤害。",
				"推走至多 2 个 {Dahan}。",
				"(当你的威力将消灭入侵者时,改为产生 {Fear} 并/或推走那些入侵者。)"
			],
			en: [
				"2 Damage.",
				"Push up to 2 {Dahan}.",
				"(When your Powers would destroy Invaders, instead they generate {Fear} and/or Push those Invaders.)"
			]
		}
	},
	pullBeneathTheHungryEarth: {
		name: {
			zh: "拖入饥土之下",
			en: "Pull Beneath the Hungry Earth"
		},
		text: {
			zh: ["若你的 {Presence} 在场,1 点{Fear}和 1 点伤害。", "若目标格是 {SandsWetland},1 点伤害。"],
			en: ["If your {Presence} is present, 1 {Fear} and 1 Damage.", "If target land is {SandsWetland}, 1 Damage."]
		}
	},
	purifyingFlame: {
		name: {
			zh: "净化之焰",
			en: "Purifying Flame"
		},
		text: {
			zh: ["每个 {Blight} 造成 1 点伤害。", "若目标格是 {MountainSands},你可以改为移除 1 个 {Blight}。"],
			en: ["1 Damage per {Blight}.", "If target is {MountainSands}, you may instead Remove 1 {Blight}."]
		}
	},
	quickenTheEarthsStruggles: {
		name: {
			zh: "加速大地的抗争",
			en: "Quicken the Earth's Struggles"
		},
		text: {
			zh: [
				"对每个 {Town}/{City} 造成 1 点伤害。",
				"{Or}",
				"防御 10。"
			],
			en: [
				"1 Damage to each {Town}/{City}.",
				"{Or}",
				"Defend 10."
			]
		}
	},
	ragingStorm: {
		name: {
			zh: "狂怒风暴",
			en: "Raging Storm"
		},
		text: {
			zh: ["对每个入侵者造成 1 点伤害。"],
			en: ["1 Damage to each Invader."]
		}
	},
	rainOfBlood: {
		name: {
			zh: "血雨",
			en: "Rain of Blood"
		},
		text: {
			zh: ["2 点{Fear}。", "若目标格有至少 2 个 {Town}/{City},额外 +1 点{Fear}。"],
			en: ["2 {Fear}.", "If target land has at least 2 {Town}/{City}, +1 {Fear}."]
		}
	},
	reachingGrasp: {
		name: {
			zh: "延展之握",
			en: "Reaching Grasp"
		},
		text: {
			zh: ["目标精灵的所有威力射程 {+2Range}。"],
			en: ["Target Spirit gets {+2Range} with all their Powers."]
		}
	},
	ritualsOfDestruction: {
		name: {
			zh: "毁灭仪式",
			en: "Rituals of Destruction"
		},
		text: {
			zh: ["2 点伤害。", "若目标格有至少 3 个 {Dahan},额外 +3 点伤害和 2 点{Fear}。"],
			en: ["2 Damage.", "If target land has at least 3 {Dahan}, +3 Damage and 2 {Fear}."]
		}
	},
	riversBounty: {
		name: {
			zh: "江河的馈赠",
			en: "River's Bounty"
		},
		text: {
			zh: ["聚集至多 2 个 {Dahan}。", "若此刻有至少 2 个 {Dahan},添加 1 个 {Dahan} 并获得 1 能量。"],
			en: ["Gather up to 2 {Dahan}.", "If there are now at least 2 {Dahan}, add 1 {Dahan} and gain 1 Energy."]
		}
	},
	rouseTheTreesAndStones: {
		name: {
			zh: "唤醒树与石",
			en: "Rouse the Trees and Stones"
		},
		text: {
			zh: ["2 点伤害。", "推走 1 个 {Explorer}。"],
			en: ["2 Damage.", "Push 1 {Explorer}."]
		}
	},
	sapTheStrengthOfMultitudes: {
		name: {
			zh: "汲取众人之力",
			en: "Sap the Strength of Multitudes"
		},
		text: {
			zh: ["防御 5。", "本威力的射程提升至 {1Range}。"],
			en: ["Defend 5.", "Increase this Power's Range to {1Range}."]
		}
	},
	savageMawbeasts: {
		name: {
			zh: "凶蛮巨口兽",
			en: "Savage Mawbeasts"
		},
		text: {
			zh: ["若目标格是 {JungleWetland},1 点{Fear}和 1 点伤害。", "1 点伤害。"],
			en: ["If target land is {JungleWetland}, 1 {Fear} and 1 Damage.", "1 Damage."]
		}
	},
	shadowsOfTheBurningForest: {
		name: {
			zh: "燃烧森林之影",
			en: "Shadows of the Burning Forest"
		},
		text: {
			zh: ["2 点{Fear}。", "若目标格是 {MountainJungle},推走 1 个 {Explorer} 和 1 个 {Town}。"],
			en: ["2 {Fear}.", "If target land is {MountainJungle}, Push 1 {Explorer} and 1 {Town}."]
		}
	},
	shatterHomesteads: {
		name: {
			zh: "粉碎家园",
			en: "Shatter Homesteads"
		},
		text: {
			zh: ["1 点{Fear}。", "消灭 1 个 {Town}。"],
			en: ["1 {Fear}.", "Destroy 1 {Town}."]
		}
	},
	songOfSanctity: {
		name: {
			zh: "圣洁之歌",
			en: "Song of Sanctity"
		},
		text: {
			zh: ["若有 {Explorer} 在场,推走所有 {Explorer}。", "否则,移除 1 个 {Blight}。"],
			en: ["If {Explorer} are present, Push all {Explorer}.", "Otherwise, remove 1 {Blight}."]
		}
	},
	steamVents: {
		name: {
			zh: "蒸汽喷口",
			en: "Steam Vents"
		},
		text: {
			zh: ["消灭 1 个 {Explorer}。", "你可以改为消灭 1 个 {Town}。"],
			en: ["Destroy 1 {Explorer}.", "You may instead Destroy 1 {Town}."]
		}
	},
	stemTheFlowOfFreshWater: {
		name: {
			zh: "阻断清流",
			en: "Stem the Flow of Fresh Water"
		},
		text: {
			zh: ["对 1 个 {Town}/{City} 造成 1 点伤害。", "若目标格是 {MountainSands},改为对每个 {Town}/{City} 造成 1 点伤害。"],
			en: ["1 Damage to 1 {Town}/{City}.", "If target land is {MountainSands}, instead, 1 Damage to each {Town}/{City}."]
		}
	},
	suddenAmbush: {
		name: {
			zh: "突发伏击",
			en: "Sudden Ambush"
		},
		text: {
			zh: ["你可以聚集 1 个 {Dahan}。", "每个 {Dahan} 消灭 1 个 {Explorer}。"],
			en: ["You may Gather 1 {Dahan}.", "Each {Dahan} destroys 1 {Explorer}."]
		}
	},
	swallowTheLandDwellers: {
		name: {
			zh: "吞噬陆居者",
			en: "Swallow the Land-Dwellers"
		},
		text: {
			zh: ["溺亡 1 个 {Explorer}、1 个 {Town} 和 1 个 {Dahan}。"],
			en: ["Drown 1 {Explorer}, 1 {Town}, and 1 {Dahan}."]
		}
	},
	talonsOfLightning: {
		name: {
			zh: "闪电之爪",
			en: "Talons of Lightning"
		},
		text: {
			zh: [
				"3 点{Fear}。",
				"5 点伤害。",
				"消灭每个相邻格中的 1 个 {Town};本威力的射程提升至 {3Range}。"
			],
			en: [
				"3 {Fear}.",
				"5 Damage.",
				"Destroy 1 {Town} in each adjacent land. Increase this Power's Range to {3Range}."
			]
		}
	},
	terrifyingNightmares: {
		name: {
			zh: "可怖梦魇",
			en: "Terrifying Nightmares"
		},
		text: {
			zh: [
				"2 点{Fear}。",
				"推走至多 4 个 {Explorer}/{Town}。",
				"4 点{Fear}。"
			],
			en: [
				"2 {Fear}.",
				"Push up to 4 {Explorer}/{Town}.",
				"4 {Fear}."
			]
		}
	},
	theJungleHungers: {
		name: {
			zh: "丛林的饥饿",
			en: "The Jungle Hungers"
		},
		text: {
			zh: [
				"消灭所有 {Explorer} 和所有 {Town}。",
				"消灭所有 {Dahan}。",
				"消灭 1 个 {City};不消灭任何 {Dahan}。"
			],
			en: [
				"Destroy all {Explorer} and all {Town}.",
				"Destroy all {Dahan}.",
				"Destroy 1 {City}. Do not destroy any {Dahan}."
			]
		}
	},
	theLandThrashesInFuriousPain: {
		name: {
			zh: "大地在狂痛中翻腾",
			en: "The Land Thrashes in Furious Pain"
		},
		text: {
			zh: [
				"每个 {Blight} 造成 2 点伤害。",
				"相邻格的每个 {Blight} 造成 1 点伤害(作用于目标格)。",
				"在一个相邻格重复结算本威力(无视射程与目标限制)。"
			],
			en: [
				"2 Damage per {Blight}.",
				"For each {Blight} in adjacent lands, 1 Damage (in target land).",
				"Repeat this Power in an adjacent land (ignoring Range and Target restrictions)."
			]
		}
	},
	theTreesAndStonesSpeakOfWar: {
		name: {
			zh: "树与石宣战",
			en: "The Trees and Stones Speak of War"
		},
		text: {
			zh: ["每个 {Dahan} 造成 1 点伤害,并提供防御 2。", "你可以推走至多 2 个 {Dahan},防御效果随之移动。"],
			en: ["For each {Dahan}, 1 Damage and Defend 2.", "You may Push up to 2 {Dahan}, moving the Defend effect with them."]
		}
	},
	tidalBoon: {
		name: {
			zh: "潮汐恩泽",
			en: "Tidal Boon"
		},
		text: {
			zh: ["目标精灵获得 2 能量,并可以从其一个格子推走 1 个 {Town} 和至多 2 个 {Dahan}。", "若 {Dahan} 被推入你的海洋,你可以将他们移至任意沿海格,而不溺亡。"],
			en: ["Target Spirit gains 2 Energy and may Push 1 {Town} and up to 2 {Dahan} from one of their lands.", "If {Dahan} are pushed into your Ocean, you may move them to any Coastal land instead of Drowning them."]
		}
	},
	tsunami: {
		name: {
			zh: "海啸",
			en: "Tsunami"
		},
		text: {
			zh: [
				"2 点{Fear}。",
				"8 点伤害。",
				"消灭 2 个 {Dahan}。",
				"同一板块的其他每个沿海格:1 点{Fear}、4 点伤害,并消灭 1 个 {Dahan}。"
			],
			en: [
				"2 {Fear}.",
				"8 Damage.",
				"Destroy 2 {Dahan}.",
				"In each other Coastal land on the same board: 1 {Fear}, 4 Damage, and Destroy 1 {Dahan}."
			]
		}
	},
	uncannyMelting: {
		name: {
			zh: "诡秘消融",
			en: "Uncanny Melting"
		},
		text: {
			zh: ["若有入侵者在场,1 点{Fear}。", "若目标格是 {SandsWetland},移除 1 个 {Blight}。"],
			en: ["If Invaders are present, 1 {Fear}.", "If target land is {SandsWetland}, Remove 1 {Blight}."]
		}
	},
	veilTheNightsHunt: {
		name: {
			zh: "掩护夜猎",
			en: "Veil the Night's Hunt"
		},
		text: {
			zh: [
				"为每个在场的 {Dahan} 各选择 1 个不同的入侵者;对每个被选中的入侵者造成 1 点伤害。",
				"{Or}",
				"推走至多 3 个 {Dahan}。"
			],
			en: [
				"For each {Dahan} present, choose a different Invader. 1 Damage to each of those Invaders.",
				"{Or}",
				"Push up to 3 {Dahan}."
			]
		}
	},
	vengeanceOfTheDead: {
		name: {
			zh: "亡者复仇",
			en: "Vengeance of the Dead"
		},
		text: {
			zh: [
				"3 点{Fear}。",
				"目标格的 {Town}/{City}/{Dahan} 被消灭后,每消灭 1 个造成 1 点伤害(本效果不能自我连锁)。",
				"本威力的伤害可以打到相邻格。"
			],
			en: [
				"3 {Fear}.",
				"After {Town}/{City}/{Dahan} are Destroyed in target land, 1 Damage per {Town}/{City}/{Dahan} Destroyed. (This cannot trigger itself.)",
				"Damage from this Power may be dealt in adjacent lands."
			]
		}
	},
	vigorOfTheBreakingDawn: {
		name: {
			zh: "破晓活力",
			en: "Vigor of the Breaking Dawn"
		},
		text: {
			zh: ["每个 {Dahan} 造成 2 点伤害。", "你可以推走至多 2 个 {Dahan};在推入了 {Dahan} 的格子,每个在场的 {Dahan} 造成 2 点伤害。"],
			en: ["2 Damage per {Dahan}.", "You may Push up to 2 {Dahan}. In lands you Pushed {Dahan} to, 2 Damage per {Dahan} present."]
		}
	},
	visionsOfFieryDoom: {
		name: {
			zh: "烈焰劫难的幻象",
			en: "Visions of Fiery Doom"
		},
		text: {
			zh: [
				"1 点{Fear}。",
				"推走 1 个 {Explorer}/{Town}。",
				"额外 +1 点{Fear}。"
			],
			en: [
				"1 {Fear}.",
				"Push 1 {Explorer}/{Town}.",
				"+1 {Fear}."
			]
		}
	},
	voiceOfThunder: {
		name: {
			zh: "雷霆之声",
			en: "Voice of Thunder"
		},
		text: {
			zh: [
				"推走至多 4 个 {Dahan}。",
				"{Or}",
				"若有入侵者在场,2 点{Fear}。"
			],
			en: [
				"Push up to 4 {Dahan}.",
				"{Or}",
				"If Invaders are present, 2 {Fear}."
			]
		}
	},
	voraciousGrowth: {
		name: {
			zh: "贪婪生长",
			en: "Voracious Growth"
		},
		text: {
			zh: [
				"2 点伤害。",
				"{Or}",
				"移除 1 个 {Blight}。"
			],
			en: [
				"2 Damage.",
				"{Or}",
				"Remove 1 {Blight}."
			]
		}
	},
	washAway: {
		name: {
			zh: "冲刷而去",
			en: "Wash Away"
		},
		text: {
			zh: ["推走至多 3 个 {Explorer}/{Town}。"],
			en: ["Push up to 3 {Explorer}/{Town}."]
		}
	},
	windsOfRustAndAtrophy: {
		name: {
			zh: "锈蚀与凋萎之风",
			en: "Winds of Rust and Atrophy"
		},
		text: {
			zh: [
				"1 点{Fear}和防御 6。",
				"将 1 个 {Town}/{City} 降级。",
				"重复结算本威力。"
			],
			en: [
				"1 {Fear} and Defend 6.",
				"Downgrade 1 {Town}/{City}.",
				"Repeat this Power."
			]
		}
	},
	wordsOfWarning: {
		name: {
			zh: "警示之言",
			en: "Words of Warning"
		},
		text: {
			zh: ["防御 3。", "破坏结算时,目标格的 {Dahan} 与入侵者同时造成伤害。"],
			en: ["Defend 3.", "During Ravage, {Dahan} in target land deal damage simultaneously with Invaders."]
		}
	},
	wrapInWingsOfSunlight: {
		name: {
			zh: "阳光之翼的裹挟",
			en: "Wrap in Wings of Sunlight"
		},
		text: {
			zh: [
				"将至多 5 个 {Dahan} 移至任意 1 个格子(可以移回目标格)。",
				"若你移动了至少 1 个 {Dahan},在该格提供防御 5。",
				"首先聚集至多 3 个 {Dahan}。"
			],
			en: [
				"Move up to 5 {Dahan} to any land (including back into target land).",
				"If you moved at least 1 {Dahan}, Defend 5 in that land.",
				"First, Gather up to 3 {Dahan}."
			]
		}
	}
}, Qt = {
	aSpreadOfRampantGreen: {
		name: {
			zh: "蔓延绿",
			en: "A Spread of Rampant Green"
		},
		setup: {
			zh: "在你的起始板块放置 2 个 {Presence}:1 个在编号最大的湿地,1 个在没有 {Dahan} 的丛林(若有多个这样的丛林,由你选择)。",
			en: "Put 2 {Presence} on your starting board: 1 in the highest-numbered Wetland, and 1 in the Jungle without any {Dahan}. (If there is more than 1 such Jungle, you may choose.)"
		},
		specials: {
			chokeTheLandWithGreen: {
				name: {
					zh: "绿意扼土",
					en: "Choke the Land with Green"
				},
				text: {
					zh: ["每当入侵者将在有你的 {SacredSite} 的格子破坏或建造时,你可以消灭你在该格的 1 个 {Presence} 来跳过该次行动。"],
					en: ["Whenever Invaders would Ravage or Build in a land with your {SacredSite}, you may skip it by destroying one of your {Presence} in that land."]
				}
			},
			steadyRegeneration: {
				name: {
					zh: "稳定再生",
					en: "Steady Regeneration"
				},
				text: {
					zh: ["通过成长放置 {Presence} 时,你可以改用你的 {DestroyedPresenceNew}。若岛屿健康,免费这样做;若岛屿已枯萎,每放置 1 个 {DestroyedPresenceNew} 需支付 1 能量。"],
					en: ["When adding {Presence} to the board via Growth, you may optionally use your {DestroyedPresenceNew}. If the island is Healthy, do so freely. If the island is Blighted, doing so costs 1 Energy per {DestroyedPresenceNew} you add."]
				}
			}
		},
		innates: {
			creepersTearIntoMortar: {
				name: {
					zh: "蔓藤撕碎灰泥",
					en: "Creepers Tear into Mortar"
				},
				levels: [
					{
						zh: "对 1 个 {Town}/{City} 造成 1 点伤害。",
						en: "1 Damage to 1 {Town}/{City}."
					},
					{
						zh: "重复结算本天赋。",
						en: "Repeat this Power."
					},
					{
						zh: "再重复结算一次本天赋。",
						en: "Repeat this Power again."
					}
				]
			},
			allEnvelopingGreen: {
				name: {
					zh: "无所不覆之绿",
					en: "All-Enveloping Green"
				},
				levels: [
					{
						zh: "防御 2。",
						en: "Defend 2."
					},
					{
						zh: "改为防御 4。",
						en: "Instead, Defend 4."
					},
					{
						zh: "并移除 1 个 {Blight}。",
						en: "Also, remove 1 {Blight}."
					}
				]
			}
		}
	},
	bringerOfDreamsAndNightmares: {
		name: {
			zh: "梦与梦魇的携行者",
			en: "Bringer of Dreams and Nightmares"
		},
		setup: {
			zh: "在你的起始板块编号最大的沙漠放置 2 个 {Presence}。",
			en: "Put 2 {Presence} on your starting board in the highest-numbered Sands."
		},
		specials: { toDreamAThousandDeaths: {
			name: {
				zh: "千死之梦",
				en: "To Dream a Thousand Deaths"
			},
			text: {
				zh: [
					"你的威力从不造成伤害,也不能消灭除你自己 {Presence} 以外的任何东西。",
					"当你的威力将消灭(或将造成足以消灭的伤害){Explorer}/{Town}/{City} 时,改为产生 0/2/5 点{Fear},并推走所有本应被消灭的 {Explorer}/{Town}。",
					"注:同一张威力不能多次消灭同一个入侵者;经由 {Dahan} 造成伤害的威力同样受此约束;伤害与消灭以外的效果照常生效。"
				],
				en: [
					"Your Powers never cause Damage, nor can they Destroy anything other than your own {Presence}.",
					"When your Powers would Destroy (or deal enough Damage to Destroy) {Explorer}/{Town}/{City}, generate 0/2/5 {Fear} instead. The Power Pushes all {Explorer}/{Town} it would destroy.",
					"Notes: A single Power cannot Destroy a given Invader more than once. Powers which cause Damage via {Dahan} are affected just like all others. All effects other than Damage/Destroy work as usual."
				]
			}
		} },
		innates: {
			spiritsMayYetDream: {
				name: {
					zh: "精灵尚可入梦",
					en: "Spirits May Yet Dream"
				},
				levels: [{
					zh: "将任意 1 张面朝下的恐惧牌翻为面朝上(它仍按正常方式获得与结算,但玩家能预先看到内容)。",
					en: "Turn any face-down Fear card face-up. (It's earned/resolved normally, but players can see what's coming.)"
				}, {
					zh: "目标精灵获得 1 种其已拥有至少 1 个的元素。",
					en: "Target Spirit gains an Element they have at least 1 of."
				}]
			},
			nightTerrors: {
				name: {
					zh: "夜惊",
					en: "Night Terrors"
				},
				levels: [
					{
						zh: "1 点{Fear}。",
						en: "1 {Fear}."
					},
					{
						zh: "额外 +1 点{Fear}。",
						en: "+1 {Fear}."
					},
					{
						zh: "额外 +1 点{Fear}。",
						en: "+1 {Fear}."
					}
				]
			}
		}
	},
	lightningsSwiftStrike: {
		name: {
			zh: "闪电迅击",
			en: "Lightning's Swift Strike"
		},
		setup: {
			zh: "在你的起始板块编号最大的沙漠放置 2 个 {Presence}。",
			en: "Put 2 {Presence} on your starting board in the highest-numbered Sands."
		},
		specials: { swiftnessOfLightning: {
			name: {
				zh: "闪电之迅",
				en: "Swiftness of Lightning"
			},
			text: {
				zh: ["你每有 1 个 {Air},就可以将 1 个慢速威力当作快速威力使用(威力牌或你的天赋)。"],
				en: ["For every {Air} you have, you may use 1 慢速 Power as if it were 快速. (Power Cards or your Innate Powers)"]
			}
		} },
		innates: { thunderingDestruction: {
			name: {
				zh: "雷霆之灭",
				en: "Thundering Destruction"
			},
			levels: [
				{
					zh: "消灭 1 个 {Town}。",
					en: "Destroy 1 {Town}."
				},
				{
					zh: "你可以改为消灭 1 个 {City}。",
					en: "You may instead destroy 1 {City}."
				},
				{
					zh: "并消灭 1 个 {Town}/{City}。",
					en: "Also, destroy 1 {Town}/{City}."
				},
				{
					zh: "并消灭 1 个 {Town}/{City}。",
					en: "Also, destroy 1 {Town}/{City}."
				}
			]
		} }
	},
	oceansHungryGrasp: {
		name: {
			zh: "汪洋饥攫",
			en: "Ocean's Hungry Grasp"
		},
		setup: {
			zh: "在你的起始板块放置 2 个 {Presence}:1 个在海洋,1 个在你选择的沿海格。",
			en: "Put 2 {Presence} on your starting board: 1 in the Ocean, and 1 in a Coastal land of your choice."
		},
		specials: {
			oceanInPlay: {
				name: {
					zh: "海洋入局",
					en: "Ocean in Play"
				},
				text: {
					zh: ["你可以将 {Presence} 放入或移入海洋,但不能放入或移入内陆格。在威力与 {Blight} 判定中,有你 {Presence} 的板块之海洋视为沿海湿地。任何被移入这些海洋的入侵者或 {Dahan} 都会溺亡。"],
					en: ["You may place/move {Presence} into Oceans, but may not place/move {Presence} into Inland lands. Oceans on boards with any of your {Presence} are treated as Coastal Wetlands for Powers and {Blight}. Any Invaders or {Dahan} moved to those Oceans are Drowned."]
				}
			},
			drowning: {
				name: {
					zh: "溺亡",
					en: "Drowning"
				},
				text: {
					zh: ["消灭溺亡的棋子,并将溺亡的入侵者放在此处。你随时可以用这些入侵者的 (X) 点生命兑换 1 能量,X 等于玩家数(无视对入侵者生命的修正)。"],
					en: ["Destroy Drowned pieces, placing Drowned Invaders here. At any time you may exchange (X) Health of these Invaders for 1 Energy, where X = number of players. (Ignore modifiers to Invader Health.)"]
				}
			}
		},
		innates: {
			poundShipsToSplinters: {
				name: {
					zh: "击船成屑",
					en: "Pound Ships to Splinters"
				},
				levels: [
					{
						zh: "1 点{Fear}。",
						en: "1 {Fear}."
					},
					{
						zh: "额外 +1 点{Fear}。",
						en: "+1 {Fear}."
					},
					{
						zh: "额外 +2 点{Fear}。",
						en: "+2 {Fear}."
					}
				]
			},
			oceanBreaksTheShore: {
				name: {
					zh: "汪洋碎岸",
					en: "Ocean Breaks the Shore"
				},
				levels: [
					{
						zh: "溺亡 1 个 {Town}。",
						en: "Drown 1 {Town}."
					},
					{
						zh: "你可以改为溺亡 1 个 {City}。",
						en: "You may instead Drown 1 {City}."
					},
					{
						zh: "并溺亡 1 个 {Town}/{City}。",
						en: "Also, Drown 1 {Town}/{City}."
					}
				]
			}
		}
	},
	riverSurgesInSunlight: {
		name: {
			zh: "阳光下奔涌的江河",
			en: "River Surges in Sunlight"
		},
		setup: {
			zh: "在你的起始板块编号最大的湿地放置 1 个 {Presence}。",
			en: "Put 1 {Presence} on your starting board in the highest-numbered Wetlands."
		},
		specials: { riversDomain: {
			name: {
				zh: "江河领域",
				en: "River's Domain"
			},
			text: {
				zh: ["你在湿地的 {Presence} 视为你的 {SacredSite}。"],
				en: ["Your {Presence} in Wetlands counts as your {SacredSite}."]
			}
		} },
		innates: { massiveFlooding: {
			name: {
				zh: "浩荡洪水",
				en: "Massive Flooding"
			},
			levels: [
				{
					zh: "推走 1 个 {Explorer}/{Town}。",
					en: "Push 1 {Explorer}/{Town}."
				},
				{
					zh: "改为造成 2 点伤害,并推走至多 3 个 {Explorer}/{Town}。",
					en: "Instead, 2 Damage. Push up to 3 {Explorer}/{Town}."
				},
				{
					zh: "改为对每个入侵者造成 2 点伤害。",
					en: "Instead, 2 Damage to each Invader."
				}
			]
		} }
	},
	shadowsFlickerLikeFlame: {
		name: {
			zh: "焰影摇曳",
			en: "Shadows Flicker Like Flame"
		},
		setup: {
			zh: "在你的起始板块放置 3 个 {Presence}:2 个在编号最大的丛林,1 个在 5 号格。",
			en: "Put 3 {Presence} on your starting board: 2 in the highest-numbered Jungle and 1 in land #5."
		},
		specials: { shadowsOfTheDahan: {
			name: {
				zh: "达罕之影",
				en: "Shadows of the Dahan"
			},
			text: {
				zh: ["你使用威力时,可以支付 1 能量,无视该威力的射程指定 1 个有 {Dahan} 的格子(威力牌或你的天赋)。"],
				en: ["Whenever you use a Power, you may pay 1 Energy to target a land with {Dahan} regardless of the Power's Range. (Power Cards or your Innate Powers)"]
			}
		} },
		innates: { darknessSwallowsTheUnwary: {
			name: {
				zh: "黑暗吞噬不察者",
				en: "Darkness Swallows the Unwary"
			},
			levels: [
				{
					zh: "聚集 1 个 {Explorer}。",
					en: "Gather 1 {Explorer}."
				},
				{
					zh: "消灭至多 2 个 {Explorer};每消灭 1 个 {Explorer},获得 1 点{Fear}。",
					en: "Destroy up to 2 {Explorer}. 1 {Fear} per {Explorer} destroyed."
				},
				{
					zh: "3 点伤害;伤害每消灭 1 个入侵者,获得 1 点{Fear}。",
					en: "3 Damage. 1 {Fear} per Invader destroyed by the Damage."
				}
			]
		} }
	},
	thunderspeaker: {
		name: {
			zh: "雷语者",
			en: "Thunderspeaker"
		},
		setup: {
			zh: "在你的起始板块 {Dahan} 最多的 2 个格子各放置 1 个 {Presence}。",
			en: "Put 2 {Presence} on your starting board: 1 in each of the 2 lands with the most {Dahan}."
		},
		specials: {
			allyOfTheDahan: {
				name: {
					zh: "达罕的盟友",
					en: "Ally of the Dahan"
				},
				text: {
					zh: ["你的 {Presence} 可以随 {Dahan} 一同移动(每当 1 个 {Dahan} 从你的一个格子移往另一个格子时,你可以让 1 个 {Presence} 随行)。"],
					en: ["Your {Presence} may move with {Dahan}. (Whenever a {Dahan} moves from 1 of your lands to another land, you may move 1 {Presence} along with it.)"]
				}
			},
			swornToVictory: {
				name: {
					zh: "誓约胜利",
					en: "Sworn to Victory"
				},
				text: {
					zh: ["入侵者在破坏中消灭 {Dahan} 后,每消灭 1 个 {Dahan},消灭你 {1Range} 内的 1 个 {Presence}。", "(先完整结算该格的破坏——包括可能因 {Blight} 损失 {Presence}、蔓延与反击——再结算本特殊规则消灭 {Presence} 的部分。)"],
					en: ["After Invaders destroy {Dahan} during a Ravage, for each destroyed {Dahan} Destroy 1 of your {Presence} within {1Range}.", "(Resolve the entire Ravage in that land – including, if relevant, losing {Presence} to {Blight}, cascading, and counterattack – before destroying {Presence} from this special rule.)"]
				}
			}
		},
		innates: {
			gatherTheWarriors: {
				name: {
					zh: "集结勇士",
					en: "Gather the Warriors"
				},
				levels: [{
					zh: "本天赋可以作为快速威力使用。",
					en: "This Power may be 快速."
				}, {
					zh: "你每有 1 个 {Air},聚集至多 1 个 {Dahan};你每有 1 个 {Sun},推走至多 1 个 {Dahan}。",
					en: "Gather up to 1 {Dahan} per {Air} you have. Push up to 1 {Dahan} per {Sun} you have."
				}]
			},
			leadTheFuriousAssault: {
				name: {
					zh: "率领狂怒突袭",
					en: "Lead the Furious Assault"
				},
				levels: [
					{
						zh: "本天赋可以作为快速威力使用。",
						en: "This power may be 快速."
					},
					{
						zh: "目标格每有 2 个 {Dahan},消灭 1 个 {Town}。",
						en: "Destroy 1 {Town} for every 2 {Dahan} in target land."
					},
					{
						zh: "目标格每有 3 个 {Dahan},消灭 1 个 {City}。",
						en: "Destroy 1 {City} for every 3 {Dahan} in target land."
					}
				]
			}
		}
	},
	vitalStrengthOfTheEarth: {
		name: {
			zh: "大地生命之力",
			en: "Vital Strength of the Earth"
		},
		setup: {
			zh: "在你的起始板块放置 3 个 {Presence}:2 个在编号最大的山地,1 个在编号最大的丛林。",
			en: "Put 3 {Presence} on your starting board: 2 in the highest-numbered Mountain, and 1 in the highest-numbered Jungle."
		},
		specials: { earthsVitality: {
			name: {
				zh: "大地活力",
				en: "Earth's Vitality"
			},
			text: {
				zh: ["你有 {SacredSite} 的每个格子防御 3。"],
				en: ["Defend 3 in every land where you have {SacredSite}."]
			}
		} },
		innates: { giftOfStrength: {
			name: {
				zh: "力量之赠",
				en: "Gift of Strength"
			},
			levels: [
				{
					zh: "每回合一次,目标精灵可以重复结算 1 张能量费用不高于 1 的威力牌。",
					en: "Once per turn, Target Spirit may Repeat 1 Power Card with Energy cost of 1 or less."
				},
				{
					zh: "改为能量费用不高于 3。",
					en: "Instead, the Energy cost limit is 3 or less."
				},
				{
					zh: "改为能量费用不高于 6。",
					en: "Instead, the Energy cost limit is 6 or less."
				}
			]
		} }
	}
}, $t = Object.fromEntries(ye.map((e) => [e.id, e])), en = Object.fromEntries(E.map((e) => [e.id, e])), tn = Qt, nn = () => c((e) => e.locale), rn = (e, t) => e?.[t] || e?.en || "", an = (e, t) => rn(Zt[e]?.name, t), on = (e, t) => rn(tn[e]?.name, t), sn = (e, t) => Zt[e]?.text[t]?.length ? Zt[e].text[t] : Zt[e]?.text.en ?? [], cn = (e, t) => e.find((e) => e.rid === t)?.name ?? "—", ln = (e, t) => oe[(e.find((e) => e.rid === t)?.colorIndex ?? 0) % oe.length].hex, un = (e) => `${e.round}:${e.phase}:${JSON.stringify(e.pending)}`, dn = {
	Mountain: "games.spiritisland.ui.terrainMountain",
	Jungle: "games.spiritisland.ui.terrainJungle",
	Sands: "games.spiritisland.ui.terrainSands",
	Wetland: "games.spiritisland.ui.terrainWetland",
	Ocean: "games.spiritisland.ui.terrainOcean"
}, fn = {
	explorer: "games.spiritisland.ui.pieceExplorer",
	town: "games.spiritisland.ui.pieceTown",
	city: "games.spiritisland.ui.pieceCity",
	dahan: "games.spiritisland.ui.pieceDahan",
	presence: "games.spiritisland.ui.piecePresence",
	blight: "games.spiritisland.ui.pieceBlight",
	energy: "games.spiritisland.ui.energy"
}, pn = {
	pick: "games.spiritisland.ui.pickSpirit",
	growth: "games.spiritisland.ui.growth",
	play: "games.spiritisland.ui.play",
	fast: "games.spiritisland.ui.fast",
	invader: "games.spiritisland.ui.invaderPhase",
	slow: "games.spiritisland.ui.slow",
	cleanup: "games.spiritisland.ui.cleanup",
	over: "games.spiritisland.ui.result"
}, mn = {
	sun: "games.spiritisland.ui.elementSun",
	moon: "games.spiritisland.ui.elementMoon",
	fire: "games.spiritisland.ui.elementFire",
	air: "games.spiritisland.ui.elementAir",
	water: "games.spiritisland.ui.elementWater",
	earth: "games.spiritisland.ui.elementEarth",
	plant: "games.spiritisland.ui.elementPlant",
	animal: "games.spiritisland.ui.elementAnimal",
	any: "games.spiritisland.ui.elementAny"
}, hn = {
	AnyLand: "games.spiritisland.ui.targetAnyLand",
	AnySpirit: "games.spiritisland.ui.targetAnySpirit",
	AnotherSpirit: "games.spiritisland.ui.targetAnotherSpirit",
	Coastal: "games.spiritisland.ui.coastalMark",
	LandWithDahan: "games.spiritisland.ui.targetDahan",
	LandWithInvaders: "games.spiritisland.ui.targetInvaders",
	LandWithNoBlight: "games.spiritisland.ui.targetNoBlight",
	LandWithNoInvaders: "games.spiritisland.ui.targetNoInvaders",
	LandWithBlight: "games.spiritisland.ui.targetBlight",
	JungleWetland: "games.spiritisland.ui.targetJungleWetland",
	MountainJungle: "games.spiritisland.ui.targetMountainJungle",
	MountainWetland: "games.spiritisland.ui.targetMountainWetland",
	None: "games.spiritisland.ui.targetSelf"
};
function gn(e, t) {
	switch (e.t) {
		case "reclaim": return t("games.spiritisland.ui.growthReclaim");
		case "gainPower": return t("games.spiritisland.ui.growthGain", { n: e.n });
		case "energy": return t("games.spiritisland.ui.growthEnergy", { n: e.n });
		case "cardPlay": return t("games.spiritisland.ui.growthPlay", { n: e.n });
		case "addPresence": return t("games.spiritisland.ui.goptAddPresence", { n: e.range });
		case "addPresenceDahan": return t("games.spiritisland.ui.goptAddPresenceDahan", { n: e.range });
		case "addPresenceDahanInvaders": return t("games.spiritisland.ui.goptAddPresenceDahanInvaders", { n: e.range });
		case "addPresenceCoastal": return t("games.spiritisland.ui.goptAddPresenceCoastal");
		case "addPresenceOcean": return t("games.spiritisland.ui.goptAddPresenceOcean");
		case "gatherPresenceEachOcean": return t("games.spiritisland.ui.goptGatherOcean");
		case "pushPresenceEachOcean": return t("games.spiritisland.ui.goptPushOcean");
		case "movePresence": return t("games.spiritisland.ui.growthMove", { n: e.n });
		case "gainElems": return e.elems.map((e) => t(mn[e])).join(" · ");
		case "discardCards": return t("games.spiritisland.ui.growthDiscard", { n: e.n });
		case "choice": return t("games.spiritisland.ui.chooseGrowth");
	}
}
function _n(e, t, n) {
	let r = !e.pending && e.resolution?.source || e.current?.source || e.pending?.why || "", i = r.startsWith("fear:") ? r.split(":")[1] : r.split(":")[0];
	if (i === "blightFlipped") return n(e.blight.card === "downwardSpiral" ? "games.spiritisland.ui.blightSpiral" : "games.spiritisland.ui.blightMemory");
	if ($t[i]) return an(i, t);
	if (xe[i]) return rn(xe[i].name, t);
	for (let e of Object.values(tn)) {
		if (e.innates[i]) return rn(e.innates[i].name, t);
		if (e.specials[i]) return rn(e.specials[i].name, t);
	}
	return n(pn[e.phase]);
}
function vn(e, t, n) {
	return (e.presence[t] ?? 0) >= (n === "riverSurgesInSunlight" && e.terrain === "Wetland" ? 1 : 2);
}
//#endregion
//#region src/games/spiritisland/island-layout.ts
var yn = {
	o0: [70, 10],
	p61: [285, 32],
	p86: [416, 60],
	o3: [504, 96],
	p78: [476, 281],
	o5: [431, 353],
	p57: [317, 345],
	p45: [269, 359],
	p34: [166, 342],
	o9: [61, 311],
	p23: [42, 250],
	p12: [55, 137],
	v124: [128, 122],
	v234: [125, 224],
	v145: [233, 181],
	v156: [267, 102],
	v568: [365, 161],
	v578: [352, 255],
	c10: [58, 28],
	c11: [64, 50],
	c12: [42, 78],
	c13: [56, 99],
	c14: [44, 118],
	c21: [47, 165],
	c22: [55, 190],
	c23: [36, 214],
	c24: [48, 237],
	c31: [34, 270],
	c32: [53, 281],
	c33: [41, 300],
	b16: [156, 18],
	b34: [233, 346],
	b47: [380, 350],
	b457: [278, 265],
	b567: [340, 185],
	b678: [423, 161],
	c125: [129, 128],
	c245: [220, 222],
	c234: [126, 272],
	c457: [333, 275],
	c47: [445, 322],
	c78: [465, 302],
	d18: [469, 84],
	d34: [124, 330],
	d46: [330, 350],
	d456: [295, 279],
	d567: [350, 204],
	d157: [274, 108],
	d178: [424, 116],
	d67: [445, 322]
}, bn = [
	"p12",
	"c14",
	"c13",
	"c12",
	"c11",
	"c10"
], xn = [
	"p23",
	"c24",
	"c23",
	"c22",
	"c21"
], Sn = [
	"o9",
	"c33",
	"c32",
	"c31"
], Cn = {
	A: [
		[
			"o0",
			"p61",
			"v156",
			"v145",
			"v124",
			...bn
		],
		[
			"p12",
			"v124",
			"v234",
			...xn
		],
		[
			"p23",
			"v234",
			"p34",
			...Sn
		],
		[
			"p34",
			"v234",
			"v124",
			"v145",
			"p45"
		],
		[
			"p45",
			"v145",
			"v156",
			"v568",
			"v578",
			"p57"
		],
		[
			"p61",
			"p86",
			"v568",
			"v156"
		],
		[
			"p57",
			"v578",
			"p78",
			"o5"
		],
		[
			"p86",
			"o3",
			"p78",
			"v578",
			"v568"
		]
	],
	B: [
		[
			"o0",
			"b16",
			"v156",
			"v145",
			"v124",
			...bn
		],
		[
			"p12",
			"v124",
			"v234",
			...xn
		],
		[
			"p23",
			"v234",
			"b34",
			...Sn
		],
		[
			"b34",
			"v234",
			"v124",
			"v145",
			"b457",
			"b47"
		],
		[
			"v145",
			"v156",
			"b567",
			"b457"
		],
		[
			"b16",
			"p86",
			"b678",
			"b567",
			"v156"
		],
		[
			"b47",
			"b457",
			"b567",
			"b678",
			"p78",
			"o5"
		],
		[
			"p86",
			"o3",
			"p78",
			"b678"
		]
	],
	C: [
		[
			"o0",
			"p61",
			"v156",
			"c125",
			...bn
		],
		[
			"p12",
			"c125",
			"c245",
			"c234",
			...xn
		],
		[
			"p23",
			"c234",
			"p34",
			...Sn
		],
		[
			"p34",
			"c234",
			"c245",
			"c457",
			"c47",
			"o5"
		],
		[
			"c125",
			"v156",
			"b567",
			"c457",
			"c245"
		],
		[
			"p61",
			"p86",
			"b678",
			"b567",
			"v156"
		],
		[
			"c47",
			"c457",
			"b567",
			"b678",
			"c78"
		],
		[
			"p86",
			"o3",
			"c78",
			"b678"
		]
	],
	D: [
		[
			"o0",
			"d18",
			"d178",
			"d157",
			"c125",
			...bn
		],
		[
			"p12",
			"c125",
			"c245",
			"v234",
			...xn
		],
		[
			"p23",
			"v234",
			"d34",
			...Sn
		],
		[
			"d34",
			"v234",
			"c245",
			"d456",
			"d46"
		],
		[
			"c125",
			"d157",
			"d567",
			"d456",
			"c245"
		],
		[
			"d46",
			"d456",
			"d567",
			"d67",
			"o5"
		],
		[
			"d67",
			"d567",
			"d157",
			"d178",
			"p78"
		],
		[
			"d18",
			"o3",
			"p78",
			"d178"
		]
	]
}, wn = {
	A: [
		[174, 83],
		[88, 189],
		[98, 286],
		[180, 244],
		[294, 212],
		[300, 95],
		[405, 300],
		[429, 191]
	],
	B: [
		[164, 77],
		[88, 189],
		[114, 291],
		[205, 267],
		[279, 180],
		[319, 92],
		[405, 280],
		[448, 174]
	],
	C: [
		[174, 83],
		[135, 193],
		[87, 290],
		[269, 297],
		[255, 196],
		[344, 99],
		[400, 230],
		[450, 170]
	],
	D: [
		[256, 64],
		[128, 186],
		[83, 286],
		[223, 281],
		[259, 203],
		[381, 305],
		[413, 223],
		[473, 137]
	]
}, Tn = ([e, t]) => [366 - t, e], En = {
	A: {
		p61: [0, 2],
		p86: [0, 4],
		p78: [1, 3],
		p57: [2, 1],
		p45: [2, 2],
		p34: [2, 4]
	},
	B: {
		b16: [0, 1],
		p86: [0, 4],
		p78: [1, 3],
		b47: [2, 1],
		b34: [2, 3]
	},
	C: {
		p61: [0, 2],
		p86: [0, 4],
		c78: [1, 4],
		c47: [1, 6],
		p34: [2, 4]
	},
	D: {
		d18: [0, 6],
		p78: [1, 3],
		d67: [1, 6],
		d46: [2, 2],
		d34: [2, 5]
	}
}, Dn = [
	["o0", "o3"],
	["o3", "o5"],
	["o5", "o9"]
];
function On(e, t) {
	let n = En[e][t];
	if (!n) return Tn(yn[t]);
	let [r, i] = Dn[n[0]].map((e) => yn[e]);
	return Tn([r[0] + (i[0] - r[0]) * n[1] / 7, r[1] + (i[1] - r[1]) * n[1] / 7]);
}
var kn = Object.fromEntries(ve.map((e) => [e.id, e.lands.map((t) => ({
	n: t.n,
	vertices: Cn[e.id][t.n - 1],
	points: Cn[e.id][t.n - 1].map((t) => On(e.id, t)),
	center: Tn(wn[e.id][t.n - 1]),
	terrain: t.terrain
}))]));
function An(e, t, n, r, i) {
	let a = t[0] - e[0], o = t[1] - e[1], s = n[0] - e[0], c = n[1] - e[1], l = a * c - o * s, u = (r[0] * c - i[0] * o) / l, d = (i[0] * a - r[0] * s) / l, f = (r[1] * c - i[1] * o) / l, p = (i[1] * a - r[1] * s) / l;
	return [
		u,
		f,
		d,
		p,
		-u * e[0] - d * e[1],
		-f * e[0] - p * e[1]
	];
}
function jn(e) {
	if (e.length >= 3) {
		let t = (t) => [320 * Math.cos(t * Math.PI * 2 / e.length), 320 * Math.sin(t * Math.PI * 2 / e.length)];
		return e.map((n, r) => {
			let i = e.length === 3 ? [
				"o5",
				"o3",
				"o9"
			] : r % 2 == 0 ? [
				"o3",
				"o5",
				"o0"
			] : [
				"o5",
				"o3",
				"o9"
			], a = e.length === 3 || r % 2 == 0 ? r : r - 1, o = e.length === 3 || r % 2 == 0 ? r - 1 : r;
			return {
				board: n,
				x: 0,
				y: 0,
				angle: 0,
				matrix: An(Tn(yn[i[0]]), Tn(yn[i[1]]), Tn(yn[i[2]]), t(a), t(o))
			};
		});
	}
	let t = e.length === 2 ? [[
		300,
		0,
		0
	], [
		2,
		-18,
		180
	]] : [[
		0,
		0,
		0
	]];
	return e.map((e, n) => ({
		board: e,
		x: t[n][0],
		y: t[n][1],
		angle: t[n][2]
	}));
}
function Mn(e, [t, n]) {
	if (e.matrix) {
		let [r, i, a, o, s, c] = e.matrix;
		return [r * t + a * n + s, i * t + o * n + c];
	}
	let r = e.angle * Math.PI / 180, i = t - 183, a = n - 255;
	return [e.x + 183 + i * Math.cos(r) - a * Math.sin(r), e.y + 255 + i * Math.sin(r) + a * Math.cos(r)];
}
//#endregion
//#region src/games/spiritisland/island-scene.ts
var Nn = .76, Pn = {
	Mountain: "#a6b5b7",
	Wetland: "#62b9b5",
	Jungle: "#76a666",
	Sands: "#eac27b"
}, Fn = (e, t, n) => `si:piece:${e}:${t}:${n}`;
function In(e, t) {
	let n = new Set(t.split("|"));
	for (let [t, r] of e.pieces) r.visible = !n.has(t);
}
function $(e, t, n, r, i, a) {
	let o = new y.Mesh(e, new y.MeshLambertMaterial({
		color: t,
		flatShading: !0
	}));
	return o.position.set(n, r, i), a.add(o), o;
}
function Ln(e, t, n, r, i, a) {
	let o = new y.Shape(e.map((e) => new y.Vector2(e.x, -e.z))), s = new y.ExtrudeGeometry(o, {
		depth: t,
		bevelEnabled: !1
	});
	s.rotateX(-Math.PI / 2);
	let c = new y.Mesh(s, [new y.MeshLambertMaterial({
		color: n,
		flatShading: !0
	}), new y.MeshLambertMaterial({
		color: r,
		flatShading: !0
	})]);
	c.position.y = i, a.add(c);
}
function Rn(e, t) {
	let n = new y.Group();
	if (e === "city") {
		for (let [e, t, r] of [
			[
				-.23,
				.03,
				.62
			],
			[
				.08,
				.03,
				.44
			],
			[
				.25,
				-.19,
				.31
			]
		]) {
			$(new y.BoxGeometry(.24, r, .26), "#f1dfb4", e, r / 2, t, n);
			let i = $(new y.ConeGeometry(.21, .18, 4), "#294f69", e, r + .09, t, n);
			i.rotation.y = Math.PI / 4;
		}
		$(new y.BoxGeometry(.68, .06, .58), "#bc9d70", 0, .03, 0, n);
	} else if (e === "town") for (let e of [-.17, .17]) {
		$(new y.BoxGeometry(.26, .23, .26), "#ecd7ad", e, .115, 0, n);
		let t = $(new y.ConeGeometry(.25, .2, 4), "#315369", e, .33, 0, n);
		t.rotation.y = Math.PI / 4;
	}
	else if (e === "explorer") $(new y.CylinderGeometry(.09, .16, .28, 5), "#f4e5c8", 0, .14, 0, n), $(new y.SphereGeometry(.1, 6, 4), "#2c5263", 0, .37, 0, n), $(new y.BoxGeometry(.028, .58, .028), "#694f39", .15, .29, 0, n);
	else if (e === "dahan") $(new y.CylinderGeometry(.18, .22, .16, 8), "#d88454", 0, .08, 0, n), $(new y.ConeGeometry(.26, .23, 8), "#f0b579", 0, .28, 0, n);
	else if (e === "blight") {
		let e = $(new y.OctahedronGeometry(.2, 0), "#55586c", 0, .17, 0, n);
		e.rotation.z = .3;
	} else {
		$(new y.CylinderGeometry(.23, .28, .12, 8), "#b98b4a", 0, .06, 0, n), $(new y.CylinderGeometry(.19, .22, .1, 8), "#f0cd78", 0, .16, 0, n);
		let e = $(new y.OctahedronGeometry(.22, 0), t, 0, .4, 0, n);
		e.scale.y = 1.3;
	}
	return n;
}
function zn(e, t) {
	let n = new y.Group();
	n.rotation.y = -.11;
	let r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map(), c = jn(e.boards), l = c.flatMap((e) => kn[e.board].flatMap((t) => t.points.map((t) => Mn(e, t)))), u = (Math.min(...l.map((e) => e[0])) + Math.max(...l.map((e) => e[0]))) / 2, d = (Math.min(...l.map((e) => e[1])) + Math.max(...l.map((e) => e[1]))) / 2, f = (e, t = Nn) => new y.Vector3((e[0] - u) / 60, t, (e[1] - d) / 60);
	for (let e of c) {
		let t = [];
		for (let a of kn[e.board]) {
			let o = a.points.map((t) => f(Mn(e, t))), s = f(Mn(e, a.center)), c = `${e.board}${a.n}`;
			if (r.set(c, s), i.set(c, o), t.push(...o), Ln(o, .19, "#65877a", "#234c59", -.12, n), Ln(o, .57, "#b3ba83", "#47776b", .05, n), Ln(o, .14, Pn[a.terrain], "#a8b47c", .62, n), n.add(new y.LineLoop(new y.BufferGeometry().setFromPoints(o.map((e) => new y.Vector3(e.x, .772, e.z))), new y.LineBasicMaterial({
				color: "#f4e7b4",
				transparent: !0,
				opacity: .8
			}))), a.terrain === "Mountain") for (let [e, t, r, i, a] of [
				[
					.1,
					-.42,
					.5,
					.85,
					"#6d8299"
				],
				[
					.56,
					-.21,
					.34,
					.58,
					"#718580"
				],
				[
					-.24,
					-.37,
					.26,
					.43,
					"#8198a2"
				]
			]) {
				let o = $(new y.ConeGeometry(r, i, 4), a, s.x + e, Nn + i / 2, s.z + t, n);
				o.rotation.y = .5;
				let c = $(new y.ConeGeometry(r * .3, i * .3, 4), "#e7e0c5", s.x + e, Nn + i * .85, s.z + t, n);
				c.rotation.y = .5;
			}
			if (a.terrain === "Jungle") for (let [e, t, r, i] of [
				[
					-.3,
					-.37,
					.28,
					"#366f62"
				],
				[
					.04,
					-.51,
					.34,
					"#2b796c"
				],
				[
					.39,
					-.37,
					.26,
					"#55916b"
				]
			]) {
				$(new y.CylinderGeometry(.055, .075, .32, 5), "#76674c", s.x + e, .92, s.z + t, n);
				let a = $(new y.IcosahedronGeometry(r, 0), i, s.x + e, 1.2, s.z + t, n);
				a.scale.y = 1.14;
			}
			if (a.terrain === "Wetland") {
				let e = new y.Shape();
				e.moveTo(-.51, -.4), e.quadraticCurveTo(-.36, -.1, -.04, .02), e.quadraticCurveTo(.12, .15, .35, .48), e.lineTo(.56, .39), e.quadraticCurveTo(.23, .02, .11, -.13), e.quadraticCurveTo(-.22, -.2, -.3, -.49), e.closePath();
				let t = new y.ExtrudeGeometry(e, {
					depth: .023,
					bevelEnabled: !1
				});
				t.rotateX(-Math.PI / 2), $(t, "#d0e6c5", s.x, .78, s.z, n);
			}
		}
		o.set(e.board, t), r.set(`${e.board}0`, f(Mn(e, [210, -28])));
	}
	let p = {
		city: [-.04, .13],
		town: [-.02, .05],
		explorer: [-.34, .35],
		dahan: [.4, .4],
		blight: [.34, -.05]
	};
	for (let i of e.lands) {
		let o = r.get(i.id);
		if (!o) continue;
		let c = {
			city: i.cities,
			town: i.towns,
			explorer: i.explorers,
			dahan: i.dahan,
			blight: i.blight
		};
		for (let t of e.players) c[`presence:${t}`] = i.presence[t] ?? 0;
		let l = 0;
		for (let [e, r] of Object.entries(c)) {
			let c = e.startsWith("presence:"), u = e.slice(9), d = c ? [-.35 + l++ * .35, .62] : p[e];
			for (let l = 0; l < 3; l++) {
				let f = new y.Vector3(o.x + d[0] + l * .25, Nn, o.z + d[1] + l * .12);
				if (s.set(Fn(i.id, e, l), f.clone().add(new y.Vector3(0, .2, 0))), l >= r) continue;
				let p = Rn(c ? "presence" : e, t[u] ?? "#4cb9ca");
				if (p.position.copy(f), p.name = Fn(i.id, e, l), c && r >= 2 && l === 0) {
					let e = $(new y.TorusGeometry(.34, .028, 5, 24), "#edcf89", 0, .12, 0, p);
					e.rotation.x = -Math.PI / 2;
				}
				n.add(p), a.set(Fn(i.id, e, l), p);
			}
		}
	}
	return n.updateMatrixWorld(!0), {
		root: n,
		points: r,
		polygons: i,
		pieces: a,
		slots: s,
		boards: o,
		dispose: () => n.traverse((e) => {
			if (e instanceof y.Mesh || e instanceof y.Line) {
				e.geometry.dispose();
				let t = Array.isArray(e.material) ? e.material : [e.material];
				for (let e of t) e.dispose();
			}
		})
	};
}
function Bn(e, t, n, r, i, a, o) {
	let s = (i ? t.boards.get(i) : null) ?? [...t.boards.values()].flat(), c = s.reduce((e, t) => e.add(t), new y.Vector3()).multiplyScalar(1 / Math.max(1, s.length));
	t.root.localToWorld(c), c.x += a.x, c.z += a.z, e.position.set(c.x, 12, c.z + 8.3), e.lookAt(c.x, .1, c.z), e.updateMatrixWorld(!0);
	let l = new y.Box3().setFromPoints(s.map((n) => t.root.localToWorld(n.clone()).applyMatrix4(e.matrixWorldInverse))).getSize(new y.Vector3()), u = n / r, d = Math.max(l.y * 1.36, l.x / u * 1.22) / o;
	e.left = -d * u / 2, e.right = d * u / 2, e.top = d / 2, e.bottom = -d / 2, e.updateProjectionMatrix();
}
function Vn(e, t, n, r, i) {
	let a = t.root.localToWorld(e.clone()).project(n);
	return {
		x: (a.x + 1) * r / 2,
		y: (1 - a.y) * i / 2
	};
}
function Hn(e, t, n, r, i = "") {
	e.root.updateMatrixWorld(!0);
	let a = new Set(i.split("|")), o = [];
	return e.root.traverse((e) => {
		if (!(e instanceof y.Mesh)) return;
		for (let t = e; t; t = t.parent) if (a.has(t.name) || !t.visible && !t.name.startsWith("si:piece:")) return;
		let i = e.geometry, s = i.getAttribute("position"), c = i.index, l = c ? c.count : s.count;
		for (let a = 0; a < l; a += 3) {
			let l = [
				0,
				1,
				2
			].map((t) => new y.Vector3().fromBufferAttribute(s, c ? c.getX(a + t) : a + t).applyMatrix4(e.matrixWorld)), u = l[1].clone().sub(l[0]).cross(l[2].clone().sub(l[0])).normalize(), d = l.reduce((e, t) => e.add(t), new y.Vector3()).multiplyScalar(1 / 3);
			if (u.dot(t.position.clone().sub(d)) <= 0) continue;
			let f = i.groups.find((e) => a >= e.start && a < e.start + e.count), p = (Array.isArray(e.material) ? e.material[f?.materialIndex ?? 0] : e.material).color.clone().multiplyScalar(.7 + .34 * Math.max(0, u.dot(new y.Vector3(-5, 9, 5).normalize()))).getHexString(), m = l.map((e) => e.project(t));
			o.push({
				z: m.reduce((e, t) => e + t.z, 0) / 3,
				svg: `<polygon points="${m.map((e) => `${(e.x + 1) * n / 2},${(1 - e.y) * r / 2}`).join(" ")}" fill="#${p}" stroke="#${p}" stroke-width=".25"/>`
			});
		}
	}), o.sort((e, t) => t.z - e.z).map((e) => e.svg).join("");
}
//#endregion
//#region src/games/spiritisland/pieces.tsx
var Un = {
	explorer: "M13 28L16 14H22L25 28ZM16 9A3 3 0 1 0 22 9A3 3 0 1 0 16 9M26 4V29M26 5H31V11H26",
	town: "M3 18L10 11L17 18V28H3ZM17 18L24 11L31 18V28H17ZM9 22H12V28M23 22H26V28",
	city: "M2 28V15H11V28ZM2 15L6 7L11 15M12 28V10H22V28ZM12 10L17 2L22 10M23 28V18H31V28ZM23 18L27 12L31 18",
	dahan: "M3 18L16 7L29 18ZM7 20V27H25V20Z",
	blight: "M16 2L23 11L30 16L23 24L16 31L9 24L2 16L9 11ZM16 2V31M2 16H30",
	energy: "M16 2L28 9V23L16 30L4 23V9ZM16 8L19 13L24 16L19 19L16 24L13 19L8 16L13 13Z"
};
function Wn({ name: e, size: t = 24 }) {
	let n = l();
	return /* @__PURE__ */ x("svg", {
		className: "si-piece-icon",
		width: t,
		height: t,
		viewBox: "0 0 34 34",
		role: "img",
		"aria-label": n(fn[e]),
		children: /* @__PURE__ */ x("path", {
			d: Un[e],
			fill: e === "blight" ? "#656177" : e === "dahan" ? "#e3a06b" : e === "energy" ? "#e9bd6b" : "#f0dfb4",
			stroke: e === "dahan" ? "#854c34" : "#294d62",
			strokeWidth: "1.6",
			strokeLinejoin: "round"
		})
	});
}
function Gn({ color: e, sacred: t = !1, size: n = 24, label: r }) {
	let i = l();
	return /* @__PURE__ */ x("span", {
		className: `si-presence ${t ? "si-sacred" : ""}`,
		style: {
			"--si-owner": e,
			width: n,
			height: n
		},
		role: "img",
		"aria-label": r ?? i(t ? "games.spiritisland.ui.sacredSite" : "games.spiritisland.ui.piecePresence"),
		children: /* @__PURE__ */ x("span", {})
	});
}
var Kn = {
	sun: "M8 1v2M8 13v2M1 8h2M13 8h2M3 3l1 1M12 12l1 1M3 13l1-1M12 4l1-1M11 8a3 3 0 1 1-6 0a3 3 0 1 1 6 0",
	moon: "M11 1a7 7 0 1 0 4 11A7 7 0 0 1 11 1Z",
	fire: "M9 1c0 5 6 6 4 11C10 17 2 14 3 9c1-3 3-3 4-6l1 5c2-2 1-5 1-7Z",
	air: "M1 5h8c5 0 5-5 1-4M1 8h13M1 11h8c5 0 5 5 1 4",
	water: "M8 1C6 5 3 7 3 10a5 5 0 0 0 10 0c0-3-3-5-5-9Z",
	earth: "m8 1 7 7-7 7-7-7Z M4 8h8",
	plant: "M13 1C4 1 1 5 3 10c4 4 10 0 10-9Z M3 14 7-9",
	animal: "M11 11a3 3 0 1 1-6 0a3 3 0 1 1 6 0M4 5a1 1 0 1 1-2 0a1 1 0 1 1 2 0M9 3a1 1 0 1 1-2 0a1 1 0 1 1 2 0M14 5a1 1 0 1 1-2 0a1 1 0 1 1 2 0",
	any: "m8 1 2 4 5 3-5 2-2 5-2-5-5-2 5-3Z"
};
function qn({ element: e, size: t = 16 }) {
	let n = l();
	return /* @__PURE__ */ x("svg", {
		className: `si-element si-element-${e}`,
		width: t,
		height: t,
		viewBox: "0 0 16 16",
		role: "img",
		"aria-label": n(mn[e]),
		children: /* @__PURE__ */ x("path", {
			d: Kn[e],
			fill: e === "air" || e === "sun" ? "none" : "currentColor",
			stroke: "currentColor",
			strokeWidth: "1.4",
			strokeLinecap: "round"
		})
	});
}
var Jn = {
	Explorer: "explorer",
	Town: "town",
	City: "city",
	Dahan: "dahan",
	Presence: "presence",
	Blight: "blight",
	Sun: "sun",
	Air: "air",
	Fear: "fear",
	SacredSite: "sacred",
	DestroyedPresenceNew: "destroyed"
}, Yn = {
	JungleSands: ["Jungle", "Sands"],
	JungleWetland: ["Jungle", "Wetland"],
	MountainJungle: ["Mountain", "Jungle"],
	MountainSands: ["Mountain", "Sands"],
	SandsWetland: ["Sands", "Wetland"]
};
function Xn({ text: e }) {
	let t = l();
	return /* @__PURE__ */ x(b, { children: e.split(/(\{[A-Za-z]+\})/).map((e, n) => {
		if (!e.startsWith("{")) return e;
		let r = e.slice(1, -1), i = Jn[r];
		return Un[i] ? /* @__PURE__ */ S("span", {
			className: "si-inline-piece",
			children: [/* @__PURE__ */ x(Wn, {
				name: i,
				size: 18
			}), t(fn[i])]
		}, n) : i === "presence" || i === "sacred" || i === "destroyed" ? /* @__PURE__ */ S("span", {
			className: "si-inline-piece",
			children: [/* @__PURE__ */ x(Gn, {
				color: "var(--si-presence)",
				size: 16,
				sacred: i === "sacred"
			}), t(i === "sacred" ? "games.spiritisland.ui.sacredSite" : i === "destroyed" ? "games.spiritisland.ui.destroyedPresence" : "games.spiritisland.ui.piecePresence")]
		}, n) : i === "sun" || i === "air" ? /* @__PURE__ */ S("span", {
			className: "si-inline-piece",
			children: [/* @__PURE__ */ x(qn, { element: i }), t(mn[i])]
		}, n) : i === "fear" ? /* @__PURE__ */ x("span", { children: t("games.spiritisland.ui.fearPool") }, n) : r === "Or" ? " / " : Yn[r] ? /* @__PURE__ */ x("span", { children: Yn[r].map((e) => t(dn[e])).join(" / ") }, n) : null;
	}) });
}
//#endregion
//#region src/games/spiritisland/island-3d.tsx
function Zn({ stamp: e }) {
	let t = ne((e) => e.invalidate);
	return i(() => t(), [t, e]), null;
}
function Qn({ model: e, camera: t, width: n, height: r, hidden: i }) {
	return /* @__PURE__ */ x("svg", {
		className: "si-vector-fallback",
		viewBox: `0 0 ${n} ${r}`,
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: Hn(e, t, n, r, i) }
	});
}
function $n({ pub: e, members: t, myRid: n, selected: c, onLand: u }) {
	let d = l(), f = o(null), p = o(null), m = ae();
	ie(null);
	let [h, ee] = s({
		w: 375,
		h: 449
	}), [v, ne] = s(e.spirits[n]?.board || e.boards[0] || null), [oe, se] = s({
		x: 0,
		z: 0,
		zoom: 1,
		manual: !1
	}), ce = o(/* @__PURE__ */ new Map()), le = o(!1), ue = a(() => Object.fromEntries(t.map((e) => [e.rid, ln(t, e.rid)])), [t]), C = a(() => zn(e, ue), [e, ue]), w = a(() => Object.assign(new y.OrthographicCamera(-4, 4, 5, -5, .1, 100), { manual: !0 }), []), de = v && e.boards.includes(v) ? v : e.boards[0];
	Bn(w, C, h.w, h.h, v === null ? null : de, oe, oe.zoom);
	let fe = "";
	for (let e of C.pieces.keys()) m?.isBusy(e) && (fe += e + "|");
	i(() => {
		In(C, fe), p.current?.invalidate();
	}, [C, fe]);
	let pe = (e) => Vn(e, C, w, h.w, h.h), me = e.pending?.seat === n, he = me && e.pending?.kind === "land" ? e.pending.legal ?? [] : [], ge = me && e.pending?.kind === "land" ? e.pending.shadows ?? [] : [], T = c ?? e.pending?.land ?? (e.pending ? e.current?.target : e.resolution?.land ?? e.current?.target), _e = e.lands.find((e) => e.id === T), ve = T ? C.points.get(T) : null;
	r(() => () => C.dispose(), [C]), r(() => {
		let e = f.current;
		if (!e) return;
		let t = new ResizeObserver(([e]) => ee({
			w: e.contentRect.width || 375,
			h: e.contentRect.height || 449
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let E = c?.[0] ?? (me && e.pending?.kind === "land" ? (he.find((e) => e.startsWith(de)) ?? he[0] ?? ge[0])?.[0] : T?.[0]);
	r(() => {
		if (oe.manual || !E || E === de || v === null) return;
		let e = requestAnimationFrame(() => ne(E));
		return () => cancelAnimationFrame(e);
	}, [
		E,
		de,
		v,
		oe.manual
	]), i(() => {
		if (!m) return;
		let e = /* @__PURE__ */ new Map();
		for (let [t, n] of C.points) e.set(`si:land:${t}`, n);
		for (let [t, n] of C.slots) e.set(t.replace("si:piece:", "si:slot:"), n);
		for (let t of C.pieces.keys()) e.set(t, C.slots.get(t));
		for (let [t, n] of e) m.registerProbe(t, () => {
			let e = f.current;
			if (!e) return null;
			let t = e.getBoundingClientRect(), r = Vn(n, C, w, t.width, t.height);
			return r.x < -20 || r.x > t.width + 20 || r.y < -20 || r.y > t.height + 20 ? null : {
				x: t.left + r.x - 17,
				y: t.top + r.y - 17,
				w: 34,
				h: 34
			};
		});
		return () => {
			for (let t of e.keys()) m.registerProbe(t, null);
		};
	}, [
		m,
		C,
		w
	]);
	let ye = JSON.stringify([
		e,
		h,
		oe,
		v,
		fe
	]);
	i(() => {
		p.current?.invalidate();
	}, [ye]);
	function be(e) {
		let t = ce.current.get(e.pointerId);
		if (!t) return;
		let n = {
			x: e.clientX,
			y: e.clientY,
			sx: t.sx,
			sy: t.sy
		}, r = [...ce.current.entries()].filter(([t]) => t !== e.pointerId);
		if (ce.current.set(e.pointerId, n), (r.length || Math.hypot(n.x - t.sx, n.y - t.sy) > 5) && (le.current = !0, e.currentTarget.setPointerCapture(e.pointerId)), le.current) {
			if (r.length) {
				let e = r[0][1], i = Math.hypot(t.x - e.x, t.y - e.y), a = Math.hypot(n.x - e.x, n.y - e.y);
				i > 10 && a > 10 && se((e) => ({
					...e,
					manual: !0,
					zoom: Math.max(.55, Math.min(3, e.zoom * a / i))
				}));
			} else se((e) => ({
				...e,
				manual: !0,
				x: e.x - (n.x - t.x) * .024 / e.zoom,
				z: e.z - (n.y - t.y) * .034 / e.zoom
			}));
		}
	}
	let xe = (e) => {
		ne(e), se({
			x: 0,
			z: 0,
			zoom: 1,
			manual: !0
		});
	}, Se = /* @__PURE__ */ x(Qn, {
		model: C,
		camera: w,
		width: h.w,
		height: h.h,
		hidden: fe
	});
	return /* @__PURE__ */ S("div", {
		className: "si-map si-sandbox",
		ref: f,
		children: [
			/* @__PURE__ */ x("div", { className: "si-sea-facets" }),
			/* @__PURE__ */ x("div", {
				className: "si-three-canvas",
				children: /* @__PURE__ */ S(re, {
					orthographic: !0,
					camera: w,
					frameloop: "demand",
					dpr: [1, 1.5],
					gl: {
						antialias: !0,
						alpha: !0,
						powerPreference: "low-power"
					},
					recoveryFallback: Se,
					onCreated: (e) => {
						p.current = e;
					},
					children: [
						/* @__PURE__ */ x("ambientLight", { intensity: 2 }),
						/* @__PURE__ */ x("directionalLight", {
							position: [
								-5,
								9,
								5
							],
							color: "#fff4da",
							intensity: 2.2
						}),
						/* @__PURE__ */ x("primitive", {
							object: C.root,
							dispose: null
						}),
						/* @__PURE__ */ x(Zn, { stamp: ye })
					]
				})
			}),
			/* @__PURE__ */ S("svg", {
				className: "si-island-svg",
				viewBox: `0 0 ${h.w} ${h.h}`,
				onPointerDown: (e) => {
					le.current = !1, ce.current.set(e.pointerId, {
						x: e.clientX,
						y: e.clientY,
						sx: e.clientX,
						sy: e.clientY
					});
				},
				onPointerMove: be,
				onPointerUp: (e) => {
					ce.current.delete(e.pointerId), e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId);
				},
				onPointerCancel: (e) => ce.current.delete(e.pointerId),
				children: [
					/* @__PURE__ */ x("defs", { children: /* @__PURE__ */ S("mask", {
						id: "si-focus-mask",
						children: [/* @__PURE__ */ x("rect", {
							width: h.w,
							height: h.h,
							fill: "white"
						}), T && C.polygons.has(T) && /* @__PURE__ */ x("polygon", {
							points: C.polygons.get(T).map((e) => {
								let t = pe(e);
								return `${t.x},${t.y}`;
							}).join(" "),
							fill: "black"
						})]
					}) }),
					T && /* @__PURE__ */ x("rect", {
						width: h.w,
						height: h.h,
						fill: "#071f2d",
						opacity: ".12",
						mask: "url(#si-focus-mask)",
						pointerEvents: "none"
					}),
					e.lands.map((e) => {
						let t = C.polygons.get(e.id), n = C.points.get(e.id);
						if (!n) return null;
						let r = pe(n), i = pe(n.clone().add(new y.Vector3(-.4, .06, -.5))), a = he.includes(e.id), o = ge.includes(e.id), s = T === e.id, c = t?.map((e) => {
							let t = pe(e);
							return `${t.x},${t.y}`;
						}).join(" "), l = () => {
							le.current || u(e.id);
						};
						return /* @__PURE__ */ S("g", { children: [c ? /* @__PURE__ */ x("polygon", {
							className: `si-land-hit ${a ? "si-land-legal" : ""} ${o ? "si-land-paid" : ""} ${s ? "si-land-selected" : ""}`,
							points: c,
							role: "button",
							tabIndex: 0,
							"aria-label": `${e.id} · ${d(dn[e.terrain])}`,
							onClick: l,
							onKeyDown: (t) => {
								(t.key === "Enter" || t.key === " ") && (t.preventDefault(), u(e.id));
							}
						}) : /* @__PURE__ */ S("g", {
							role: "button",
							tabIndex: 0,
							"aria-label": `${e.id} · ${d("games.spiritisland.ui.terrainOcean")}`,
							onClick: l,
							onKeyDown: (t) => {
								(t.key === "Enter" || t.key === " ") && (t.preventDefault(), u(e.id));
							},
							children: [/* @__PURE__ */ x("rect", {
								x: r.x - 28,
								y: r.y - 22,
								width: 56,
								height: 44,
								fill: s ? "#2c7581" : "#153f4b",
								stroke: a ? "#ffe4a3" : "#729992"
							}), /* @__PURE__ */ x("text", {
								x: r.x,
								y: r.y + 4,
								className: "si-land-number",
								textAnchor: "middle",
								children: e.id
							})]
						}), c && /* @__PURE__ */ S("g", {
							pointerEvents: "none",
							children: [
								/* @__PURE__ */ x("path", {
									d: `M${i.x - 7} ${i.y - 12}h14l5 5v14l-5 5h-14l-5-5v-14Z`,
									fill: s ? "#dfb66c" : "#234a58",
									stroke: "#e1d39f"
								}),
								/* @__PURE__ */ x("text", {
									x: i.x,
									y: i.y + 5,
									textAnchor: "middle",
									className: `si-land-number ${s ? "si-number-active" : ""}`,
									children: e.n
								}),
								e.defend > 0 && /* @__PURE__ */ S("text", {
									x: r.x + 15,
									y: r.y + 24,
									className: "si-land-status",
									children: ["◇ ", e.defend]
								}),
								(e.skipRavage || e.skipBuild || e.skipExplore || e.isolate) && /* @__PURE__ */ x("text", {
									x: r.x + 13,
									y: r.y + 38,
									className: "si-land-status",
									children: e.isolate ? "⊘" : "✓"
								}),
								Object.entries({
									explorer: e.explorers,
									town: e.towns,
									city: e.cities,
									dahan: e.dahan,
									blight: e.blight
								}).filter(([, e]) => e > 3).map(([e, t], n) => /* @__PURE__ */ S("text", {
									x: r.x + 12,
									y: r.y - 12 - n * 13,
									className: "si-count",
									children: [
										e === "city" ? "▥" : e === "town" ? "⌂" : e === "dahan" ? "◈" : e === "blight" ? "◆" : "⚑",
										" ×",
										t
									]
								}, e))
							]
						})] }, e.id);
					}),
					ve && /* @__PURE__ */ x("g", {
						className: "si-target-seal",
						pointerEvents: "none",
						children: (() => {
							let e = pe(ve.clone().add(new y.Vector3(.65, .08, .58)));
							return /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("path", {
								d: `M${e.x} ${e.y - 18}l7 6 10-2-2 10 6 4-6 7 2 10-10-2-7 6-7-6-10 2 2-10-6-7 6-4-2-10 10 2Z`,
								fill: "#a9ddcd",
								stroke: "#fce6a8"
							}), /* @__PURE__ */ x("text", {
								x: e.x,
								y: e.y + 5,
								textAnchor: "middle",
								className: "si-number-active",
								children: c ? "✓" : "◇"
							})] });
						})()
					}, T)
				]
			}),
			/* @__PURE__ */ S("div", {
				className: "si-board-tabs",
				children: [e.boards.map((e) => /* @__PURE__ */ S("button", {
					"aria-label": d("games.spiritisland.ui.focusBoard", { board: e }),
					"aria-pressed": v !== null && de === e,
					className: v !== null && de === e ? "si-chosen" : "",
					onClick: () => xe(e),
					children: [e, he.some((t) => t.startsWith(e)) && /* @__PURE__ */ x("span", { children: "◇" })]
				}, e)), e.boards.length > 1 && /* @__PURE__ */ x("button", {
					"aria-pressed": v === null,
					onClick: () => xe(null),
					children: d("games.spiritisland.ui.fullIsland")
				})]
			}),
			/* @__PURE__ */ S("div", {
				className: "si-map-tools",
				children: [
					/* @__PURE__ */ x("button", {
						"aria-label": d("games.spiritisland.ui.zoomIn"),
						onClick: () => se((e) => ({
							...e,
							manual: !0,
							zoom: Math.min(3, e.zoom * 1.2)
						})),
						children: /* @__PURE__ */ x(g, { size: 18 })
					}),
					/* @__PURE__ */ x("button", {
						"aria-label": d("games.spiritisland.ui.zoomOut"),
						onClick: () => se((e) => ({
							...e,
							manual: !0,
							zoom: Math.max(.55, e.zoom / 1.2)
						})),
						children: /* @__PURE__ */ x(_, { size: 18 })
					}),
					/* @__PURE__ */ x("button", {
						"aria-label": d("games.spiritisland.ui.recenter"),
						onClick: () => {
							ne(_e?.board ?? e.spirits[n]?.board ?? e.boards[0]), se({
								x: 0,
								z: 0,
								zoom: 1,
								manual: !1
							});
						},
						children: /* @__PURE__ */ x(te, { size: 18 })
					})
				]
			}),
			_e && /* @__PURE__ */ S("div", {
				className: "si-land-caption",
				children: [/* @__PURE__ */ S("strong", { children: [
					_e.id,
					" · ",
					d(dn[_e.terrain])
				] }), /* @__PURE__ */ S("span", { children: [
					/* @__PURE__ */ x(Wn, {
						name: "explorer",
						size: 16
					}),
					_e.explorers,
					" ",
					/* @__PURE__ */ x(Wn, {
						name: "town",
						size: 16
					}),
					_e.towns,
					" ",
					/* @__PURE__ */ x(Wn, {
						name: "city",
						size: 16
					}),
					_e.cities
				] })]
			})
		]
	});
}
//#endregion
//#region src/games/spiritisland/visual-themes.ts
var er = {
	acceleratedRot: "vines",
	aYearOfPerfectStillness: "ward",
	blazingRenewal: "flame",
	boonOfVigor: "boon",
	callOfTheDahanWays: "dahan",
	callOfTheDeeps: "tide",
	callOnMidnightsDreams: "nightmare",
	callToBloodshed: "dahan",
	callToIsolation: "dahan",
	callToMigrate: "dahan",
	callToTend: "dahan",
	cleansingFloods: "flood",
	concealingShadows: "shadow",
	cropsWitherAndFade: "flame",
	darkAndTangledWoods: "shadow",
	delusionsOfDanger: "nightmare",
	devouringAnts: "forest",
	dissolveTheBondsOfKinship: "dahan",
	drawOfTheFruitfulEarth: "earth",
	dreadApparitions: "nightmare",
	dreamsOfTheDahan: "nightmare",
	driftDownIntoSlumber: "nightmare",
	drought: "flame",
	elementalBoon: "boon",
	encompassingWard: "ward",
	enticingSplendor: "forest",
	entrancingApparitions: "nightmare",
	entwinedPower: "vines",
	favorsCalledDue: "shadow",
	fieldsChokedWithGrowth: "vines",
	flashFloods: "flood",
	giftOfConstancy: "boon",
	giftOfLivingEnergy: "boon",
	giftOfPower: "boon",
	giftOfProliferation: "vines",
	gnawingRootbiters: "forest",
	graspingTide: "tide",
	guardTheHealingLand: "ward",
	harbingersOfTheLightning: "storm",
	indomitableClaim: "earth",
	infiniteVitality: "ward",
	landOfHauntsAndEmbers: "flame",
	lightningsBoon: "storm",
	lureOfTheUnknown: "shadow",
	manifestationOfPowerAndGlory: "dahan",
	mantleOfDread: "shadow",
	mistsOfOblivion: "earth",
	naturesResilience: "ward",
	overgrowInANight: "vines",
	paralyzingFright: "nightmare",
	pillarOfLivingFlame: "flame",
	poisonedLand: "vines",
	powerstorm: "storm",
	predatoryNightmares: "nightmare",
	pullBeneathTheHungryEarth: "forest",
	purifyingFlame: "ward",
	quickenTheEarthsStruggles: "ward",
	ragingStorm: "storm",
	rainOfBlood: "storm",
	reachingGrasp: "ward",
	ritualsOfDestruction: "earth",
	riversBounty: "flood",
	rouseTheTreesAndStones: "earth",
	sapTheStrengthOfMultitudes: "flood",
	savageMawbeasts: "forest",
	shadowsOfTheBurningForest: "shadow",
	shatterHomesteads: "flame",
	songOfSanctity: "ward",
	steamVents: "earth",
	stemTheFlowOfFreshWater: "vines",
	suddenAmbush: "dahan",
	swallowTheLandDwellers: "tide",
	talonsOfLightning: "flame",
	terrifyingNightmares: "nightmare",
	theJungleHungers: "earth",
	theLandThrashesInFuriousPain: "earth",
	theTreesAndStonesSpeakOfWar: "storm",
	tidalBoon: "tide",
	tsunami: "tide",
	uncannyMelting: "flood",
	veilTheNightsHunt: "shadow",
	vengeanceOfTheDead: "nightmare",
	vigorOfTheBreakingDawn: "forest",
	visionsOfFieryDoom: "nightmare",
	voiceOfThunder: "storm",
	voraciousGrowth: "vines",
	washAway: "flood",
	windsOfRustAndAtrophy: "storm",
	wordsOfWarning: "dahan",
	wrapInWingsOfSunlight: "storm"
}, tr = (e) => er[e] ?? "boon", nr = [
	"M28 8L14 28H26L19 52L45 23H31Z",
	"M9 34L25 11L40 20L47 39L29 51L14 44ZM9 34L29 29L25 11M29 29L47 39M29 29L29 51",
	"M29 53V14M29 34L12 19M29 25L44 10M29 45L46 29M12 19V29H23M44 10H33V21",
	"M10 40L29 9L48 40ZM18 40L29 23L40 40M7 48H51M29 40V54",
	"M7 29Q27 8 50 29Q27 50 7 29ZM28 20V39M20 29H36",
	"M10 22Q22 4 39 17Q56 33 36 49Q14 56 10 34Q10 22 25 23Q41 22 38 37Q32 48 23 38",
	"M28 12Q48 23 27 36Q13 45 30 59M37 13Q52 26 35 37Q22 47 38 58",
	"M29 9L18 24L25 29L12 43L29 53L48 39L35 31L44 16ZM28 20L24 33L32 42"
], rr = [
	"#567ca2",
	"#b9a75e",
	"#5c9872",
	"#98865d",
	"#8573a0",
	"#377d97",
	"#38a6b2",
	"#ae7858"
], ir = {
	lightningsSwiftStrike: 0,
	vitalStrengthOfTheEarth: 1,
	aSpreadOfRampantGreen: 2,
	thunderspeaker: 3,
	bringerOfDreamsAndNightmares: 4,
	oceansHungryGrasp: 5,
	riverSurgesInSunlight: 6,
	shadowsFlickerLikeFlame: 7
};
function ar({ id: e, size: t = 64, color: n, broken: r = !1 }) {
	let i = ir[e ?? ""] ?? 0;
	return /* @__PURE__ */ S("svg", {
		className: `si-sigil${r ? " si-sigil-broken" : ""}`,
		width: t,
		height: t * 1.18,
		viewBox: "0 0 64 76",
		"aria-hidden": "true",
		style: { "--si-sigil-color": n ?? rr[i] },
		children: [
			/* @__PURE__ */ x("path", {
				d: "M10 10L32 2L54 10L58 53L32 72L6 53Z",
				fill: "var(--si-sigil-color)",
				stroke: "#cfaf65",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ x("path", {
				d: "M17 15L31 9L45 15L49 48L31 61L14 50Z",
				fill: "#113f53",
				fillOpacity: ".3",
				stroke: "#89c1b0"
			}),
			/* @__PURE__ */ x("path", {
				className: "si-sigil-mark",
				d: nr[i],
				fill: "none",
				stroke: "#f1d88d",
				strokeWidth: "3.2",
				strokeLinejoin: "round"
			}),
			r && /* @__PURE__ */ x("path", {
				d: "M31 4L27 23L36 37L28 55L32 71",
				fill: "none",
				stroke: "#0b2635",
				strokeWidth: "5"
			})
		]
	});
}
var or = {
	flood: "M-10 66Q9 24 42 43T92 26T174 29M-8 58Q22 42 32 23Q45 5 61 22M81 72Q104 53 136 61L165 48",
	tide: "M-5 67Q14 23 43 30Q74 35 55 51Q42 64 29 54M43 30Q96 0 116 39Q119 68 91 59M92 29Q140 20 166 56",
	storm: "M73 7L45 44H73L60 77L113 31H84ZM9 24L28 12L44 26M112 13L139 9L161 25",
	flame: "M19 73L41 29L54 50L74 8L95 51L113 31L141 73ZM57 73L77 40L99 73",
	nightmare: "M11 42Q79 3 151 42Q79 80 11 42ZM80 22L96 42L80 62L64 42ZM18 12L31 23M130 63L145 77",
	shadow: "M30 13L69 9L95 27L134 25L108 60L82 72L51 59L16 63ZM49 31L78 23L100 47L68 57Z",
	vines: "M14 80L73 9M38 51L16 27H44M58 29L110 10V35H76M32 62L99 57V77M94 59L149 28",
	forest: "M22 77V41M54 77V26M89 77V35M124 77V20M4 43L22 15L42 43ZM29 29L54 2L78 29ZM65 38L89 9L114 38ZM102 24L124 3L151 24Z",
	earth: "M10 69L51 13L94 69ZM64 69L111 5L160 69M26 69L51 40L75 69M86 69L112 30L136 69",
	dahan: "M6 56L32 33L58 56ZM19 58V71H44V58M59 45L85 21L111 45ZM72 47V70H98V47M112 60L137 36L163 60Z",
	ward: "M80 4L133 20L127 53L80 77L33 53L27 20ZM80 19L111 29L106 49L80 62L54 49L49 29Z",
	boon: "M79 7L91 28L116 40L91 52L79 75L66 52L43 40L66 28ZM10 19H27M18 11V27M132 62H151M141 53V71"
};
function sr({ id: e, theme: t }) {
	let n = t ?? tr(e ?? "");
	return /* @__PURE__ */ S("svg", {
		className: `si-power-motif si-motif-${n}`,
		viewBox: "0 0 160 82",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ x("path", {
				d: "M0 82V64L34 21L79 49L121 13L160 38V82Z",
				fill: "currentColor",
				opacity: ".18"
			}),
			/* @__PURE__ */ x("path", {
				d: or[n],
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "6",
				strokeLinecap: "square",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ x("path", {
				d: "M56 10L62 4L68 10L62 16Z",
				fill: "#edce80"
			})
		]
	});
}
//#endregion
//#region src/games/spiritisland/card.tsx
function cr({ id: e, selected: t = !1, accelerated: n = !1, onClick: r, onInfo: i }) {
	let a = l(), o = nn(), s = $t[e];
	return s ? /* @__PURE__ */ S("div", {
		className: `si-power ${r ? "si-power-pickable" : ""} ${t ? "si-selected" : ""}`,
		children: [/* @__PURE__ */ S("button", {
			className: "si-power-face",
			onClick: r ?? i,
			"aria-pressed": r ? t : void 0,
			"aria-label": an(e, o),
			children: [
				/* @__PURE__ */ x("strong", {
					className: "si-power-name",
					children: an(e, o)
				}),
				/* @__PURE__ */ x(sr, { id: e }),
				/* @__PURE__ */ x("span", {
					className: "si-cost",
					children: s.cost
				}),
				/* @__PURE__ */ S("span", {
					className: "si-power-symbols",
					children: [/* @__PURE__ */ x("span", {
						className: `si-speed si-speed-${n ? "fast" : s.speed}`,
						title: a(n ? "games.spiritisland.ui.accelerated" : s.speed === "fast" ? "games.spiritisland.ui.fastPower" : "games.spiritisland.ui.slowPower"),
						children: s.speed === "fast" || n ? /* @__PURE__ */ x(f, { size: 13 }) : /* @__PURE__ */ x("span", { children: "◷" })
					}), s.elements.map((e) => /* @__PURE__ */ x(qn, {
						element: e,
						size: 13
					}, e))]
				}),
				/* @__PURE__ */ S("span", {
					className: "si-power-range",
					children: [
						a("games.spiritisland.ui.range"),
						" ",
						s.range ?? "—",
						s.ss && " ◇"
					]
				}),
				/* @__PURE__ */ x("span", {
					className: "si-power-summary",
					children: /* @__PURE__ */ x(Xn, { text: sn(e, o)[0] ?? "" })
				}),
				t && /* @__PURE__ */ x("span", {
					className: "si-card-check",
					children: "✓"
				})
			]
		}), i && r && /* @__PURE__ */ x("button", {
			className: "si-card-info",
			"aria-label": `${a("games.spiritisland.ui.details")} · ${an(e, o)}`,
			onClick: (e) => {
				e.stopPropagation(), i();
			},
			children: /* @__PURE__ */ x(m, { size: 14 })
		})]
	}) : null;
}
function lr({ id: e, accelerated: t = !1, rangeBonus: n = 0 }) {
	let r = l(), i = nn(), a = $t[e];
	return a ? /* @__PURE__ */ S("div", {
		className: "si-power-detail",
		children: [
			/* @__PURE__ */ x(sr, { id: e }),
			/* @__PURE__ */ S("div", {
				className: "si-detail-stats",
				children: [
					/* @__PURE__ */ S("span", { children: [
						r("games.spiritisland.ui.energy"),
						" ",
						/* @__PURE__ */ x("b", { children: a.cost })
					] }),
					/* @__PURE__ */ x("span", { children: r(t || a.speed === "fast" ? "games.spiritisland.ui.fastPower" : "games.spiritisland.ui.slowPower") }),
					/* @__PURE__ */ S("span", { children: [
						r("games.spiritisland.ui.range"),
						" ",
						/* @__PURE__ */ x("b", { children: a.range === void 0 ? "—" : a.range + n }),
						a.ss && ` · ${r("games.spiritisland.ui.sacredSite")}`
					] })
				]
			}),
			/* @__PURE__ */ S("p", { children: [r(hn[a.target]), a.rangeTerrain && ` · ${a.rangeTerrain.map((e) => r(dn[e])).join(" / ")}`] }),
			/* @__PURE__ */ x("div", {
				className: "si-elements",
				children: a.elements.map((e) => /* @__PURE__ */ x(qn, { element: e }, e))
			}),
			sn(e, i).slice(0, sn(e, i).length - (a.thresholds?.length ?? 0)).map((e, t) => /* @__PURE__ */ x("p", { children: /* @__PURE__ */ x(Xn, { text: e }) }, t)),
			a.thresholds?.map((t, n) => /* @__PURE__ */ S("div", {
				className: "si-threshold",
				children: [/* @__PURE__ */ x("span", { children: Object.entries(t.elems).map(([e, t]) => /* @__PURE__ */ S("span", { children: [/* @__PURE__ */ x(qn, { element: e }), t] }, e)) }), /* @__PURE__ */ x("p", { children: /* @__PURE__ */ x(Xn, { text: sn(e, i)[sn(e, i).length - a.thresholds.length + n] ?? "" }) })]
			}, n))
		]
	}) : null;
}
//#endregion
//#region src/games/spiritisland/panels.tsx
function ur({ title: e, onClose: t, children: n }) {
	let i = l(), a = o(null);
	return r(() => {
		let e = document.activeElement;
		a.current?.querySelector("button")?.focus();
		let n = (e) => {
			if (e.key === "Escape" && (e.preventDefault(), t()), e.key === "Tab") {
				let t = Array.from(a.current?.querySelectorAll("button:not(:disabled),[tabindex=\"0\"]") ?? []), n = t[0], r = t.at(-1);
				e.shiftKey && document.activeElement === n ? (e.preventDefault(), r?.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
			}
		};
		return document.addEventListener("keydown", n), () => {
			document.removeEventListener("keydown", n), e?.focus();
		};
	}, [t]), se(/* @__PURE__ */ x("div", {
		className: "si-modal",
		onClick: t,
		children: /* @__PURE__ */ S("div", {
			className: "si-dialog",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			ref: a,
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ S("header", { children: [/* @__PURE__ */ x("h2", { children: e }), /* @__PURE__ */ x("button", {
				"aria-label": i("games.spiritisland.ui.close"),
				onClick: t,
				children: /* @__PURE__ */ x(d, { size: 22 })
			})] }), /* @__PURE__ */ x("div", {
				className: "si-dialog-content",
				tabIndex: 0,
				children: n
			})]
		})
	}), document.body);
}
function dr({ node: e }) {
	let t = l();
	return /* @__PURE__ */ S(b, { children: [
		e.v !== void 0 && e.v,
		e.elem === "any" ? /* @__PURE__ */ x(qn, { element: "any" }) : e.elem?.map((e) => /* @__PURE__ */ x(qn, { element: e }, e)),
		e.reclaim && /* @__PURE__ */ x("span", {
			title: t("games.spiritisland.ui.reclaimNode"),
			children: "↶"
		})
	] });
}
var fr = {
	Low: "games.spiritisland.ui.complexityLow",
	Moderate: "games.spiritisland.ui.complexityModerate",
	High: "games.spiritisland.ui.complexityHigh",
	"Very High": "games.spiritisland.ui.complexityVeryHigh"
};
function pr({ id: e, seat: t, pub: n, members: r }) {
	let i = l(), a = nn(), o = en[e], s = tn[e], c = t ? n.spirits[t] : void 0;
	if (!o || !s) return null;
	let u = t ? ln(r, t) : "var(--si-presence)";
	return /* @__PURE__ */ S(b, { children: [
		/* @__PURE__ */ S("div", {
			className: "si-spirit-hero",
			children: [/* @__PURE__ */ x(ar, {
				id: e,
				size: 112
			}), /* @__PURE__ */ S("div", { children: [
				/* @__PURE__ */ x("h2", { children: on(e, a) }),
				/* @__PURE__ */ x("small", { children: t ? cn(r, t) : i(fr[o.complexity]) }),
				o.specials.map((e) => /* @__PURE__ */ S("section", { children: [/* @__PURE__ */ x("h3", { children: rn(s.specials[e]?.name, a) }), (s.specials[e]?.text?.[a] ?? []).map((e, t) => /* @__PURE__ */ x("p", { children: /* @__PURE__ */ x(Xn, { text: e }) }, t))] }, e))
			] })]
		}),
		[[
			"energy",
			o.energyTrack,
			c?.energyIdx ?? 0,
			"games.spiritisland.ui.perTurn"
		], [
			"plays",
			o.playsTrack,
			c?.playsIdx ?? 0,
			"games.spiritisland.ui.cardPlays"
		]].map(([e, t, n, r]) => /* @__PURE__ */ S("section", {
			className: "si-track",
			children: [/* @__PURE__ */ S("h3", { children: [i(r), c && ` · ${e === "energy" ? c.energyPerTurn : c.playsPerTurn}`] }), /* @__PURE__ */ x("div", {
				className: "si-track-nodes",
				children: t.map((e, t) => /* @__PURE__ */ S("div", {
					className: `si-track-node ${t === n ? "si-track-current" : ""} ${t > n ? "si-track-covered" : ""}`,
					children: [/* @__PURE__ */ x("span", { children: t > n ? /* @__PURE__ */ x(Gn, {
						color: u,
						size: 22
					}) : /* @__PURE__ */ x(dr, { node: e }) }), /* @__PURE__ */ x("small", { children: t > n && /* @__PURE__ */ x(dr, { node: e }) })]
				}, t))
			})]
		}, e)),
		c && /* @__PURE__ */ S("div", {
			className: "si-element-pool",
			children: [
				Object.entries(c.elements.counts).filter(([, e]) => e > 0).map(([e, t]) => /* @__PURE__ */ S("span", { children: [/* @__PURE__ */ x(qn, { element: e }), /* @__PURE__ */ x("b", { children: t })] }, e)),
				c.elements.any > 0 && /* @__PURE__ */ S("span", { children: [/* @__PURE__ */ x(qn, { element: "any" }), c.elements.any] }),
				c.rangeBonus > 0 && /* @__PURE__ */ x("span", { children: i("games.spiritisland.ui.rangeBonus", { n: c.rangeBonus }) })
			]
		}),
		o.innates.map((e) => /* @__PURE__ */ S("section", {
			className: "si-innate",
			children: [
				/* @__PURE__ */ x("h3", { children: rn(s.innates[e.id]?.name, a) }),
				/* @__PURE__ */ S("small", { children: [
					i(e.speed === "fast" ? "games.spiritisland.ui.fastPower" : "games.spiritisland.ui.slowPower"),
					" ",
					"· ",
					i("games.spiritisland.ui.range"),
					" ",
					e.range ?? "—",
					e.ss && ` · ${i("games.spiritisland.ui.sacredSite")}`
				] }),
				e.thresholds.map((t, n) => /* @__PURE__ */ S("div", {
					className: `si-threshold ${n < (c?.innateLevels[e.id] ?? 0) ? "si-threshold-met" : ""}`,
					children: [/* @__PURE__ */ x("span", { children: Object.entries(t.elems).map(([e, t]) => /* @__PURE__ */ S("span", { children: [/* @__PURE__ */ x(qn, { element: e }), t] }, e)) }), /* @__PURE__ */ x("p", { children: /* @__PURE__ */ x(Xn, { text: rn(s.innates[e.id]?.levels[n], a) }) })]
				}, n))
			]
		}, e.id))
	] });
}
function mr({ pub: e, id: t, members: n, onFocus: r }) {
	let i = l(), a = nn(), o = e.lands.find((e) => e.id === t);
	if (!o) return null;
	let s = {
		explorer: o.explorers,
		town: o.towns,
		city: o.cities,
		dahan: o.dahan,
		blight: o.blight
	};
	return /* @__PURE__ */ S(b, { children: [
		/* @__PURE__ */ S("h3", { children: [
			o.id,
			" · ",
			i(dn[o.terrain]),
			o.coastal && ` · ${i("games.spiritisland.ui.coastalMark")}`
		] }),
		/* @__PURE__ */ x("div", {
			className: "si-land-counts",
			children: Object.entries(s).map(([e, t]) => /* @__PURE__ */ S("span", { children: [
				/* @__PURE__ */ x(Wn, {
					name: e,
					size: 38
				}),
				i(fn[e]),
				" ",
				/* @__PURE__ */ x("b", { children: t })
			] }, e))
		}),
		Object.entries(o.presence).filter(([, e]) => e).map(([t, r]) => /* @__PURE__ */ S("p", {
			className: "si-owner-line",
			children: [
				/* @__PURE__ */ x(Gn, {
					color: ln(n, t),
					sacred: vn(o, t, e.spirits[t]?.spirit)
				}),
				cn(n, t),
				" ·",
				" ",
				on(e.spirits[t]?.spirit, a),
				" ×",
				r
			]
		}, t)),
		o.defend > 0 && /* @__PURE__ */ x("p", { children: i("games.spiritisland.ui.defendMark", { n: o.defend }) }),
		o.skipRavage && /* @__PURE__ */ x("p", { children: i("games.spiritisland.ui.skipRavage") }),
		o.skipBuild && /* @__PURE__ */ x("p", { children: i("games.spiritisland.ui.skipBuild") }),
		o.skipExplore && /* @__PURE__ */ x("p", { children: i("games.spiritisland.ui.skipExplore") }),
		o.isolate && /* @__PURE__ */ x("p", { children: i("games.spiritisland.ui.isolated") }),
		/* @__PURE__ */ x("h3", { children: i("games.spiritisland.ui.adjacent") }),
		/* @__PURE__ */ x("div", {
			className: "si-inline-actions",
			children: o.adj.map((e) => /* @__PURE__ */ x("button", {
				className: "si-button",
				onClick: () => r?.(e),
				children: e
			}, e))
		})
	] });
}
function hr({ cards: e, onCard: t }) {
	let n = l();
	return /* @__PURE__ */ x("div", {
		className: "si-pile-cards",
		children: e.length ? e.map((e) => /* @__PURE__ */ x(cr, {
			id: e,
			onInfo: () => t(e)
		}, e)) : /* @__PURE__ */ x("p", { children: n("games.spiritisland.ui.noHand") })
	});
}
var gr = {
	ravage: "games.spiritisland.ui.invaderSlotRavage",
	build: "games.spiritisland.ui.invaderSlotBuild",
	explore: "games.spiritisland.ui.invaderSlotExplore"
};
function _r({ id: e, deck: t = 0 }) {
	let n = l(), r = be.find((t) => t.id === e);
	return /* @__PURE__ */ x("span", {
		className: `si-invader-card ${r ? "" : "si-card-back"}`,
		children: r ? /* @__PURE__ */ S(b, { children: [
			/* @__PURE__ */ x(sr, { theme: {
				Mountain: "earth",
				Jungle: "forest",
				Sands: "flame",
				Wetland: "flood",
				Coastal: "tide"
			}[r.terrains[0]] }),
			/* @__PURE__ */ x("span", { children: r.terrains.map((e) => n(e === "Coastal" ? "games.spiritisland.ui.coastalMark" : dn[e])).join(" / ") }),
			/* @__PURE__ */ x("b", { children: [
				"",
				"Ⅰ",
				"Ⅱ",
				"Ⅲ"
			][r.stage] })
		] }) : /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("span", { children: "◎" }), /* @__PURE__ */ x("b", { children: t || "—" })] })
	});
}
//#endregion
//#region src/games/spiritisland/choice-labels.ts
var vr = {
	callToBloodshed: ["games.spiritisland.ui.choiceDamage", "games.spiritisland.ui.choiceGatherDahan"],
	callToIsolation: ["games.spiritisland.ui.choicePushInvaders", "games.spiritisland.ui.choicePushDahan"],
	callToTend: ["games.spiritisland.ui.choiceRemoveBlight", "games.spiritisland.ui.choicePushDahan"],
	delusionsOfDanger: ["games.spiritisland.ui.choicePushExplorer", "games.spiritisland.ui.choiceFear"],
	enticingSplendor: ["games.spiritisland.ui.choiceGatherInvaders", "games.spiritisland.ui.choiceGatherDahan"],
	naturesResilience: ["games.spiritisland.ui.choiceRemoveBlight", "games.spiritisland.ui.choiceDefend"],
	purifyingFlame: ["games.spiritisland.ui.choiceRemoveBlight", "games.spiritisland.ui.choiceDamage"],
	quickenTheEarthsStruggles: ["games.spiritisland.ui.choiceDamage", "games.spiritisland.ui.choiceDefend"],
	veilTheNightsHunt: ["games.spiritisland.ui.choiceDamage", "games.spiritisland.ui.choicePushDahan"],
	voraciousGrowth: ["games.spiritisland.ui.choiceDamage", "games.spiritisland.ui.choiceRemoveBlight"],
	callOnMidnightsDreams: ["games.spiritisland.ui.choiceMajor", "games.spiritisland.ui.choiceFear"],
	cropsWitherAndFade: ["games.spiritisland.ui.choiceDowngradeTown", "games.spiritisland.ui.choiceDowngradeCity"],
	dreamsOfTheDahan: ["games.spiritisland.ui.choiceGatherDahan", "games.spiritisland.ui.choiceFear"],
	fieldsChokedWithGrowth: ["games.spiritisland.ui.choicePushTown", "games.spiritisland.ui.choicePushDahan"],
	overgrowInANight: ["games.spiritisland.ui.choicePresence", "games.spiritisland.ui.choiceFear"],
	voiceOfThunder: ["games.spiritisland.ui.choicePushDahan", "games.spiritisland.ui.choiceFear"]
};
function yr(e) {
	let t = e.pending?.why.split(":") ?? [];
	return t[0] === "blightFlipped" ? ["games.spiritisland.ui.choiceForget", "games.spiritisland.ui.choiceDestroyPresence"] : t[0] === "fear" ? t[1] === "dahanEnheartened" && t[2]?.startsWith("mode") ? ["games.spiritisland.ui.choicePushDahan", "games.spiritisland.ui.choiceGatherDahan"] : t[1] === "tallTalesOfSavagery" && t[2]?.startsWith("town") ? ["games.spiritisland.ui.choiceRemoveTown", "games.spiritisland.ui.choiceRemoveExplorers"] : ["games.spiritisland.ui.choiceApply", "games.spiritisland.ui.choiceSkip"] : vr[t[0]] ?? ["games.spiritisland.ui.yes", "games.spiritisland.ui.no"];
}
//#endregion
//#region src/games/spiritisland/view-player.tsx
function br(e) {
	return /* @__PURE__ */ x(xr, {
		...e,
		pub: e.public
	});
}
function xr({ pub: e, myRid: t, members: r, send: i }) {
	let a = l(), o = nn(), c = e.spirits[t], d = e.pending, f = d?.seat === t, p = un(e), [h, te] = s({
		key: p,
		cards: [],
		pieces: []
	}), g = h.key === p ? h : {
		key: p,
		cards: [],
		pieces: []
	}, [_, y] = s(null), [ne, re] = s("hand"), [ae, oe] = s(null), { ref: se } = ie(`si:seat:${t}`), ce = n(() => y(null), []), le = (e) => te({
		...g,
		cards: g.cards.includes(e) ? g.cards.filter((t) => t !== e) : [...g.cards, e]
	}), ue = g.cards.reduce((e, t) => e + ($t[t]?.cost ?? 0), 0), C = d?.count ?? 1, w = d?.cards ?? [], de = d?.pieces ?? [], fe = d?.kind === "play" ? g.cards.length <= (c?.playsPerTurn ?? 0) && ue <= (c?.energy ?? 0) : d?.upto ? g.cards.length <= C : g.cards.length === Math.min(C, w.length), pe = d?.upto ? g.pieces.length <= C : g.pieces.length === Math.min(C, de.length), me = e.lands.find((e) => e.id === g.land), he = g.spirit ?? d?.spirits?.[0], ge = g.number ?? d?.min ?? 0, T = (e) => {
		i(e), te({
			key: p,
			cards: [],
			pieces: []
		});
	}, _e = (e) => {
		f && d?.kind === "land" && (d.legal?.includes(e) || d.shadows?.includes(e)) ? te({
			...g,
			land: e
		}) : y({
			kind: "land",
			id: e
		});
	}, ve = _n(e, o, a), ye = /* @__PURE__ */ S("div", {
		className: "si-banner",
		children: [
			/* @__PURE__ */ S("div", {
				className: "si-phase",
				children: [/* @__PURE__ */ x("span", {
					className: "si-round",
					children: String(e.round).padStart(2, "0")
				}), /* @__PURE__ */ x("strong", { children: a(pn[e.phase]) })]
			}),
			/* @__PURE__ */ x("div", {
				className: "si-phase-track",
				children: [
					"growth",
					"play",
					"fast",
					"invader",
					"slow",
					"cleanup"
				].map((t) => /* @__PURE__ */ x("span", { className: e.phase === t ? "si-phase-current" : "" }, t))
			}),
			/* @__PURE__ */ x("div", {
				className: "si-players",
				ref: se,
				children: [t, ...e.players.filter((e) => e !== t)].filter((t) => e.players.includes(t)).map((n) => {
					let i = e.spirits[n], s = e.phase === "growth" ? e.growthDone[n] : e.phase === "play" && e.playDone[n];
					return /* @__PURE__ */ S("button", {
						className: `si-player ${n === t ? "si-player-me" : ""}`,
						onClick: () => i?.spirit && y({
							kind: "spirit",
							id: i.spirit,
							seat: n
						}),
						children: [/* @__PURE__ */ x(ar, {
							id: i?.spirit,
							size: n === t ? 61 : 30
						}), /* @__PURE__ */ S("span", { children: [
							/* @__PURE__ */ S("strong", { children: [cn(r, n), n === t && " · " + a("games.spiritisland.ui.you")] }),
							/* @__PURE__ */ x("small", { children: i?.spirit ? on(i.spirit, o) : a("games.spiritisland.ui.pickSpirit") }),
							/* @__PURE__ */ S("span", {
								className: "si-player-stats",
								children: [
									/* @__PURE__ */ x(Wn, {
										name: "energy",
										size: 16
									}),
									/* @__PURE__ */ x("b", { children: i?.energy ?? 0 }),
									/* @__PURE__ */ x("span", { children: "▯" }),
									/* @__PURE__ */ x("b", { children: i?.playsPerTurn ?? 0 }),
									s ? /* @__PURE__ */ x(u, { size: 15 }) : d?.seat === n ? /* @__PURE__ */ x("span", { className: "si-turn-dot" }) : null
								]
							})
						] })]
					}, n);
				})
			})
		]
	}), be = /* @__PURE__ */ S("div", {
		className: "si-public-bar",
		children: [/* @__PURE__ */ S("button", {
			className: "si-resources",
			onClick: () => y({ kind: "public" }),
			children: [
				/* @__PURE__ */ S("span", { children: [
					"◉",
					" ",
					/* @__PURE__ */ S("b", { children: [
						e.fear.earned,
						"/",
						e.fear.poolMax
					] }),
					/* @__PURE__ */ S("small", { children: [
						a("games.spiritisland.ui.terrorLevel"),
						" ",
						[
							"",
							"Ⅰ",
							"Ⅱ",
							"Ⅲ"
						][e.terror]
					] })
				] }),
				/* @__PURE__ */ x("span", {
					className: "si-fear-track",
					children: /* @__PURE__ */ x("i", { style: { width: `${e.fear.earned / e.fear.poolMax * 100}%` } })
				}),
				/* @__PURE__ */ S("span", { children: [
					/* @__PURE__ */ x(Wn, {
						name: "blight",
						size: 17
					}),
					a("games.spiritisland.ui.blightPool"),
					" ",
					/* @__PURE__ */ x("b", { children: e.blight.pool }),
					e.blight.flipped && " !"
				] })
			]
		}), [
			"ravage",
			"build",
			"explore"
		].map((t, n) => /* @__PURE__ */ S("button", {
			className: `si-invader-slot ${e.phase === "invader" && e.invaderStep === n + 2 ? "si-invader-active" : ""}`,
			onClick: () => y({ kind: "public" }),
			children: [/* @__PURE__ */ x("small", { children: a(gr[t]) }), /* @__PURE__ */ x(_r, {
				id: e.invader[t],
				deck: t === "explore" ? e.invader.deckCount : 0
			})]
		}, t))]
	}), Se = /* @__PURE__ */ S("div", {
		className: "si-waiting",
		children: [
			/* @__PURE__ */ x("strong", { children: e.current || d || e.resolution ? ve : a(pn[e.phase]) }),
			/* @__PURE__ */ x("span", { children: d ? `${cn(r, d.seat)} · ${a("games.spiritisland.ui.waiting")}` : a("games.spiritisland.ui.currentAction") }),
			c?.hand.slice(0, 2).map((e) => /* @__PURE__ */ x(cr, {
				id: e,
				onInfo: () => y({
					kind: "card",
					id: e
				})
			}, e))
		]
	});
	function Ce() {
		if (e.phase === "pick" && !f) return Se;
		if (e.phase === "pick") return /* @__PURE__ */ S("div", {
			className: "si-action-row",
			children: [/* @__PURE__ */ x("strong", { children: ae ? on(ae, o) : a("games.spiritisland.ui.spiritPick") }), /* @__PURE__ */ S("button", {
				className: "si-button si-primary",
				disabled: !f || !ae || !d?.spirits?.includes(ae),
				onClick: () => ae && T({
					type: "pickSpirit",
					spirit: ae
				}),
				children: [/* @__PURE__ */ x(u, { size: 17 }), a("games.spiritisland.ui.pickConfirm")]
			})]
		});
		if (!f || !d) return Se;
		switch (d.kind) {
			case "growth": return /* @__PURE__ */ x("div", {
				className: "si-hand-row",
				children: c?.hand.map((e) => /* @__PURE__ */ x(cr, {
					id: e,
					onInfo: () => y({
						kind: "card",
						id: e
					})
				}, e))
			});
			case "play": return /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ S("div", {
				className: "si-action-strip",
				children: [
					/* @__PURE__ */ S("button", {
						className: "si-text-button",
						onClick: () => y({
							kind: "pile",
							pile: "hand"
						}),
						children: [/* @__PURE__ */ x(ee, { size: 16 }), a("games.spiritisland.ui.hand")]
					}),
					/* @__PURE__ */ S("span", { children: [
						g.cards.length,
						"/",
						c?.playsPerTurn ?? 0,
						" · ",
						ue,
						"/",
						c?.energy ?? 0
					] }),
					/* @__PURE__ */ x("button", {
						className: "si-button si-primary",
						disabled: !fe,
						onClick: () => T({
							type: "play",
							cards: g.cards
						}),
						children: a("games.spiritisland.ui.confirm")
					})
				]
			}), /* @__PURE__ */ x("div", {
				className: "si-hand-row si-hand-select",
				children: c?.hand.map((e) => /* @__PURE__ */ x(cr, {
					id: e,
					selected: g.cards.includes(e),
					onClick: () => le(e),
					onInfo: () => y({
						kind: "card",
						id: e
					})
				}, e))
			})] });
			case "land": return /* @__PURE__ */ S("div", {
				className: "si-target-action",
				children: [$t[e.current?.source ?? ""] && /* @__PURE__ */ x(cr, {
					id: e.current.source,
					onInfo: () => y({
						kind: "card",
						id: e.current.source
					})
				}), /* @__PURE__ */ S("div", { children: [
					/* @__PURE__ */ x("strong", { children: me ? `${me.id} · ${a(dn[me.terrain])}` : a("games.spiritisland.ui.chooseLand") }),
					/* @__PURE__ */ x("small", { children: me?.coastal ? a("games.spiritisland.ui.coastalMark") : ve }),
					me && d.shadows?.includes(me.id) && !d.legal?.includes(me.id) && /* @__PURE__ */ x("small", {
						className: "si-pay-text",
						children: a("games.spiritisland.ui.shadowsPayMark")
					}),
					/* @__PURE__ */ S("div", {
						className: "si-inline-actions",
						children: [/* @__PURE__ */ x("button", {
							className: "si-button",
							disabled: !g.land,
							onClick: () => te({
								...g,
								land: void 0
							}),
							children: a("games.spiritisland.ui.cancel")
						}), /* @__PURE__ */ S("button", {
							className: "si-button si-primary",
							disabled: !g.land,
							onClick: () => T({
								type: "answer",
								value: g.land
							}),
							children: [/* @__PURE__ */ x(u, { size: 17 }), a("games.spiritisland.ui.targetConfirm")]
						})]
					})
				] })]
			});
			case "cards": return /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ S("div", {
				className: "si-action-strip",
				children: [
					/* @__PURE__ */ x("strong", { children: a(d.why.includes("keep") ? "games.spiritisland.ui.gainPowerKeep" : d.why.includes("forget") ? "games.spiritisland.ui.forgetCard" : "games.spiritisland.ui.chooseCards") }),
					/* @__PURE__ */ S("span", { children: [
						g.cards.length,
						"/",
						C
					] }),
					/* @__PURE__ */ x("button", {
						className: "si-button si-primary",
						disabled: !fe,
						onClick: () => T({
							type: "answer",
							value: g.cards
						}),
						children: a("games.spiritisland.ui.confirm")
					})
				]
			}), /* @__PURE__ */ x("div", {
				className: "si-hand-row si-hand-select",
				children: w.map((e) => $t[e] ? /* @__PURE__ */ x(cr, {
					id: e,
					selected: g.cards.includes(e),
					onClick: () => le(e),
					onInfo: () => y({
						kind: "card",
						id: e
					})
				}, e) : /* @__PURE__ */ S("button", {
					className: `si-button si-element-choice ${g.cards.includes(e) ? "si-chosen" : ""}`,
					"aria-pressed": g.cards.includes(e),
					onClick: () => le(e),
					children: [/* @__PURE__ */ x(qn, { element: e }), a(mn[e])]
				}, e))
			})] });
			case "pieces": return /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ S("div", {
				className: "si-action-strip",
				children: [
					/* @__PURE__ */ x("strong", { children: a(d.upto ? "games.spiritisland.ui.chooseUpToPieces" : "games.spiritisland.ui.chooseExactPieces", { n: C }) }),
					/* @__PURE__ */ S("span", { children: [
						g.pieces.length,
						"/",
						C
					] }),
					/* @__PURE__ */ x("button", {
						className: "si-button si-primary",
						disabled: !pe,
						onClick: () => T({
							type: "answer",
							value: g.pieces.map((e) => de[e])
						}),
						children: a("games.spiritisland.ui.confirm")
					})
				]
			}), /* @__PURE__ */ x("div", {
				className: "si-choice-row",
				children: de.map((e, n) => /* @__PURE__ */ S("button", {
					className: `si-button ${g.pieces.includes(n) ? "si-chosen" : ""}`,
					"aria-pressed": g.pieces.includes(n),
					onClick: () => te({
						...g,
						pieces: g.pieces.includes(n) ? g.pieces.filter((e) => e !== n) : [...g.pieces, n]
					}),
					children: [
						e.type === "presence" ? /* @__PURE__ */ x(Gn, { color: ln(r, e.seat ?? t) }) : /* @__PURE__ */ x(Wn, {
							name: e.type,
							size: 27
						}),
						/* @__PURE__ */ S("span", { children: [a(fn[e.type]), /* @__PURE__ */ S("small", { children: [
							e.seat ? cn(r, e.seat) : "",
							" ",
							e.from ?? d.land
						] })] }),
						g.pieces.includes(n) && /* @__PURE__ */ x(u, { size: 14 })
					]
				}, n))
			})] });
			case "track": {
				let e = en[c?.spirit ?? ""];
				return /* @__PURE__ */ S("div", {
					className: "si-action-row",
					children: [/* @__PURE__ */ x("strong", { children: a("games.spiritisland.ui.selectTrack") }), ["energy", "plays"].map((n) => {
						let i = n === "energy" ? e?.energyTrack : e?.playsTrack, o = n === "energy" ? c?.energyIdx : c?.playsIdx, s = i?.[o ?? 0];
						return /* @__PURE__ */ S("button", {
							className: "si-button si-primary si-track-choice",
							disabled: (o ?? 0) >= (i?.length ?? 0),
							onClick: () => T({
								type: "answer",
								value: n
							}),
							children: [
								/* @__PURE__ */ x("span", { children: a(n === "energy" ? "games.spiritisland.ui.trackEnergy" : "games.spiritisland.ui.trackPlays") }),
								/* @__PURE__ */ x("span", {
									className: "si-track-preview",
									children: i?.map((e, n) => /* @__PURE__ */ S("span", {
										className: n < (o ?? 0) ? "si-track-uncovered" : n === (o ?? 0) ? "si-track-next" : "",
										children: [n >= (o ?? 0) && /* @__PURE__ */ x(Gn, {
											color: ln(r, t),
											size: 24
										}), /* @__PURE__ */ x("b", { children: /* @__PURE__ */ x(dr, { node: e }) })]
									}, n))
								}),
								s && /* @__PURE__ */ S("small", { children: [
									a("games.spiritisland.ui.nextNode"),
									" · ",
									/* @__PURE__ */ x(dr, { node: s })
								] })
							]
						}, n);
					})]
				});
			}
			case "spirit": return /* @__PURE__ */ S("div", {
				className: "si-action-row si-spirit-targets",
				children: [d.spirits?.map((t) => /* @__PURE__ */ S("button", {
					className: `si-button ${he === t ? "si-chosen" : ""}`,
					"aria-pressed": he === t,
					onClick: () => te({
						...g,
						spirit: t
					}),
					children: [/* @__PURE__ */ x(ar, {
						id: e.spirits[t].spirit,
						size: 42
					}), /* @__PURE__ */ S("span", { children: [cn(r, t), /* @__PURE__ */ x("small", { children: on(e.spirits[t].spirit, o) })] })]
				}, t)), /* @__PURE__ */ x("button", {
					className: "si-button si-primary",
					disabled: !he,
					onClick: () => T({
						type: "answer",
						value: he
					}),
					children: a("games.spiritisland.ui.confirm")
				})]
			});
			case "yesno": return /* @__PURE__ */ S("div", {
				className: "si-yesno",
				children: [/* @__PURE__ */ x("strong", { children: we() }), /* @__PURE__ */ S("div", {
					className: "si-inline-actions",
					children: [/* @__PURE__ */ x("button", {
						className: "si-button si-primary",
						onClick: () => T({
							type: "answer",
							value: !0
						}),
						children: a(yr(e)[0])
					}), /* @__PURE__ */ x("button", {
						className: "si-button",
						onClick: () => T({
							type: "answer",
							value: !1
						}),
						children: a(yr(e)[1])
					})]
				})]
			});
			case "number": return /* @__PURE__ */ S("div", {
				className: "si-action-row",
				children: [
					/* @__PURE__ */ x("strong", { children: a("games.spiritisland.ui.number") }),
					/* @__PURE__ */ x("button", {
						className: "si-button",
						"aria-label": a("games.spiritisland.ui.minus"),
						disabled: ge === (d.min ?? 0),
						onClick: () => te({
							...g,
							number: Math.max(d.min ?? 0, ge - 1)
						}),
						children: "−"
					}),
					/* @__PURE__ */ x("b", {
						className: "si-numeric",
						children: ge
					}),
					/* @__PURE__ */ x("button", {
						className: "si-button",
						"aria-label": a("games.spiritisland.ui.plus"),
						disabled: ge === (d.max ?? 0),
						onClick: () => te({
							...g,
							number: Math.min(d.max ?? 0, ge + 1)
						}),
						children: "+"
					}),
					/* @__PURE__ */ x("button", {
						className: "si-button si-primary",
						onClick: () => T({
							type: "answer",
							value: ge
						}),
						children: a("games.spiritisland.ui.confirm")
					})
				]
			});
			default: return Se;
		}
	}
	function we() {
		let e = d?.why.split(":") ?? [];
		return e[0] === "chokeTheLandWithGreen" ? `${e[2]} · ${a(e[1] === "ravage" ? "games.spiritisland.ui.whyChokeRavage" : "games.spiritisland.ui.whyChokeBuild")}` : e[0] === "allyOfTheDahan" ? `${e[1]} → ${e[2]} · ${a("games.spiritisland.ui.whyAllyFollow")}` : d?.why === "growth:useDestroyed" ? a("games.spiritisland.ui.whyUseDestroyed") : ve;
	}
	return /* @__PURE__ */ S("div", {
		className: `si-game si-phase-${e.phase}`,
		"data-choice": d?.kind,
		children: [/* @__PURE__ */ S(v, {
			adaptive: !0,
			banner: ye,
			scroll: !1,
			actionsHeight: "si-bottom",
			actions: /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("div", {
				className: "si-actions",
				children: Ce()
			}), be] }),
			children: [/* @__PURE__ */ x($n, {
				pub: e,
				members: r,
				myRid: t,
				selected: g.land,
				onLand: _e
			}), e.phase === "pick" ? /* @__PURE__ */ x("div", {
				className: "si-pick-grid",
				children: E.filter((t) => d?.spirits?.includes(t.id) || Object.values(e.spirits).some((e) => e.spirit === t.id)).map((e) => /* @__PURE__ */ S("div", {
					className: `si-pick-card ${ae === e.id ? "si-selected" : ""}`,
					children: [/* @__PURE__ */ S("button", {
						disabled: !f || !d?.spirits?.includes(e.id),
						onClick: () => oe(e.id),
						"aria-pressed": ae === e.id,
						children: [
							/* @__PURE__ */ x(ar, {
								id: e.id,
								size: 68
							}),
							/* @__PURE__ */ x("strong", { children: on(e.id, o) }),
							/* @__PURE__ */ x("small", { children: a(fr[e.complexity]) })
						]
					}), /* @__PURE__ */ x("button", {
						className: "si-pick-info",
						"aria-label": a("games.spiritisland.ui.details"),
						onClick: () => y({
							kind: "spirit",
							id: e.id
						}),
						children: /* @__PURE__ */ x(m, { size: 19 })
					})]
				}, e.id))
			}) : /* @__PURE__ */ S(b, { children: [
				f && d?.kind === "growth" ? /* @__PURE__ */ x("div", {
					className: "si-growth-options",
					children: en[c?.spirit ?? ""]?.growth.map((e, t) => /* @__PURE__ */ S("button", {
						onClick: () => T({
							type: "growth",
							group: t
						}),
						children: [/* @__PURE__ */ x("small", { children: String(t + 1).padStart(2, "0") }), e.map((e, t) => /* @__PURE__ */ x("span", { children: gn(e, a) }, t))]
					}, t))
				}) : /* @__PURE__ */ S("div", {
					className: "si-played-shelf",
					children: [(c?.played ?? []).map((e) => /* @__PURE__ */ x(cr, {
						id: e,
						accelerated: c?.fastCards.includes(e),
						onInfo: () => y({
							kind: "card",
							id: e
						})
					}, e)), c && /* @__PURE__ */ S("button", {
						className: "si-element-status",
						"aria-label": a("games.spiritisland.ui.innates"),
						onClick: () => y({
							kind: "spirit",
							id: c.spirit,
							seat: t
						}),
						children: [/* @__PURE__ */ S("span", { children: [tt.filter((e) => c.elements.counts[e] > 0).map((e) => /* @__PURE__ */ S("span", { children: [/* @__PURE__ */ x(qn, { element: e }), c.elements.counts[e]] }, e)), c.elements.any > 0 && /* @__PURE__ */ S("span", { children: [/* @__PURE__ */ x(qn, { element: "any" }), c.elements.any] })] }), /* @__PURE__ */ S("small", { children: [
							a("games.spiritisland.ui.innates"),
							" ",
							Object.values(c.innateLevels).map((e, t) => /* @__PURE__ */ x("b", { children: "●".repeat(e) || "○" }, t))
						] })]
					})]
				}),
				c && /* @__PURE__ */ S("button", {
					className: "si-pile-open",
					"aria-label": a("games.spiritisland.ui.hand"),
					onClick: () => y({
						kind: "pile",
						pile: "hand"
					}),
					children: [/* @__PURE__ */ x(ee, { size: 17 }), c.hand.length]
				}),
				e.players.length > 1 && /* @__PURE__ */ x("div", {
					className: "si-team-tags",
					children: e.players.filter((e) => e !== t).map((t) => {
						let n = e.spirits[t], i = e.phase === "growth" ? e.growthDone[t] : e.phase === "play" && e.playDone[t];
						return /* @__PURE__ */ S("button", {
							className: d?.seat === t ? "si-team-active" : "",
							onClick: () => n?.spirit && y({
								kind: "spirit",
								id: n.spirit,
								seat: t
							}),
							children: [
								/* @__PURE__ */ x(ar, {
									id: n?.spirit,
									size: 25
								}),
								/* @__PURE__ */ S("span", { children: [cn(r, t), /* @__PURE__ */ x("small", { children: n?.spirit ? on(n.spirit, o) : a("games.spiritisland.ui.pickSpirit") })] }),
								i && /* @__PURE__ */ x(u, { size: 13 })
							]
						}, t);
					})
				}),
				(d?.kind === "land" || d?.kind === "pieces" || e.current || e.resolution) && /* @__PURE__ */ S("div", {
					className: "si-current-power",
					children: [/* @__PURE__ */ x("strong", { children: ve }), (e.resolution?.land || e.current?.target) && /* @__PURE__ */ S("span", { children: [" → ", e.resolution?.land || e.current?.target] })]
				})
			] })]
		}), _ && /* @__PURE__ */ S(ur, {
			title: _.kind === "spirit" ? on(_.id, o) : _.kind === "card" ? an(_.id, o) : _.kind === "land" ? _.id : _.kind === "pile" ? a("games.spiritisland.ui.hand") : a("games.spiritisland.ui.overview"),
			onClose: ce,
			children: [
				_.kind === "spirit" && /* @__PURE__ */ x(pr, {
					id: _.id,
					seat: _.seat,
					pub: e,
					members: r
				}),
				_.kind === "card" && /* @__PURE__ */ x(lr, {
					id: _.id,
					accelerated: c?.fastCards.includes(_.id),
					rangeBonus: c?.rangeBonus
				}),
				_.kind === "land" && /* @__PURE__ */ x(mr, {
					pub: e,
					id: _.id,
					members: r,
					onFocus: (e) => y({
						kind: "land",
						id: e
					})
				}),
				_.kind === "pile" && /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("div", {
					className: "si-pile-tabs",
					children: [
						"hand",
						"discard",
						"played",
						"forgotten"
					].map((e) => /* @__PURE__ */ S("button", {
						className: `si-button ${ne === e ? "si-chosen" : ""}`,
						onClick: () => re(e),
						children: [
							a({
								hand: "games.spiritisland.ui.hand",
								discard: "games.spiritisland.ui.discard",
								played: "games.spiritisland.ui.played",
								forgotten: "games.spiritisland.ui.forgotten"
							}[e]),
							" ",
							c?.[e].length ?? 0
						]
					}, e))
				}), /* @__PURE__ */ x(hr, {
					cards: c?.[ne] ?? [],
					onCard: (e) => y({
						kind: "card",
						id: e
					})
				})] }),
				_.kind === "public" && /* @__PURE__ */ S(b, { children: [
					/* @__PURE__ */ S("h3", { children: [
						a("games.spiritisland.ui.terrorLevel"),
						" ",
						e.terror
					] }),
					/* @__PURE__ */ x("p", { children: a(e.terror === 1 ? "games.spiritisland.ui.terrorOne" : e.terror === 2 ? "games.spiritisland.ui.terrorTwo" : "games.spiritisland.ui.terrorThree") }),
					/* @__PURE__ */ S("p", { children: [
						a("games.spiritisland.ui.fearPool"),
						" ",
						e.fear.earned,
						"/",
						e.fear.poolMax,
						" · ",
						a("games.spiritisland.ui.fearDeck"),
						" ",
						e.fear.deckCount
					] }),
					/* @__PURE__ */ x("h3", { children: a("games.spiritisland.ui.fearPending") }),
					[.../* @__PURE__ */ new Set([...e.current?.source.startsWith("fear:") ? [e.current.source.split(":")[1]] : [], ...e.fear.pending])].map((t) => /* @__PURE__ */ S("section", { children: [/* @__PURE__ */ x("strong", { children: rn(xe[t]?.name, o) }), /* @__PURE__ */ x("p", { children: /* @__PURE__ */ x(Xn, { text: rn(xe[t]?.levels[e.terror - 1], o) }) })] }, t)),
					/* @__PURE__ */ S("h3", { children: [
						a(e.blight.flipped ? "games.spiritisland.ui.blighted" : "games.spiritisland.ui.healthy"),
						" ",
						"· ",
						e.blight.pool
					] }),
					e.blight.flipped && /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("strong", { children: a(e.blight.card === "downwardSpiral" ? "games.spiritisland.ui.blightSpiral" : "games.spiritisland.ui.blightMemory") }), /* @__PURE__ */ x("p", { children: a(e.blight.card === "downwardSpiral" ? "games.spiritisland.ui.blightSpiralRule" : "games.spiritisland.ui.blightMemoryRule") })] }),
					/* @__PURE__ */ x("div", {
						className: "si-public-cards",
						children: [
							"ravage",
							"build",
							"explore"
						].map((t) => /* @__PURE__ */ S("div", { children: [/* @__PURE__ */ x("h3", { children: a(gr[t]) }), /* @__PURE__ */ x(_r, {
							id: e.invader[t],
							deck: t === "explore" ? e.invader.deckCount : 0
						})] }, t))
					}),
					/* @__PURE__ */ S("p", { children: [
						a("games.spiritisland.ui.invaderDeck"),
						" ",
						e.invader.deckCount
					] }),
					/* @__PURE__ */ x("h3", { children: a("games.spiritisland.ui.log") }),
					e.log.length ? e.log.map((e, t) => /* @__PURE__ */ S("p", { children: [
						cn(r, e.by),
						" · ",
						e.text
					] }, t)) : /* @__PURE__ */ x("p", { children: a("games.spiritisland.ui.noLog") })
				] })
			]
		})]
	});
}
//#endregion
//#region src/games/spiritisland/bot.ts
var Sr = {
	city: 4,
	town: 3,
	explorer: 2,
	dahan: 1,
	presence: 0
}, Cr = /* @__PURE__ */ new Map();
function wr(e) {
	let t = Cr.get(e);
	if (t) return t;
	let n = [], r = Zt[e];
	if (r) n = r.text.en;
	else for (let t of Object.values(Qt)) {
		let r = t.innates?.[e];
		if (r) {
			n = r.levels.map((e) => e.en);
			break;
		}
	}
	let i = n.join(" "), a = [];
	return /Damage|Destroy|Drown/.test(i) && a.push("attack"), /Defend/.test(i) && a.push("defend"), /Remove 1 Blight|remove 1 Blight/.test(i) && a.push("blight"), /Push|Gather/.test(i) && a.push("move"), /Fear/.test(i) && a.push("fear"), Cr.set(e, a), a;
}
function Tr(e, t) {
	let n = t ? be.find((e) => e.id === t) : null;
	return n ? e.lands.filter((e) => e.n !== 0 && (n.terrains.includes(e.terrain) || n.terrains.includes("Coastal") && e.coastal)).reduce((e, t) => e + t.explorers + t.towns * 2 + t.cities * 3, 0) : 0;
}
function Er(e, t, n) {
	let r = e.lands.find((e) => e.id === n);
	if (!r) return 0;
	let i = wr(t), a = r.cities * 3 + r.towns * 2 + r.explorers;
	if (i.includes("defend") && !i.includes("attack")) {
		let n = (D[t]?.speed ?? "fast") === "slow" ? e.invader.build : e.invader.ravage, i = n ? be.find((e) => e.id === n) : null;
		return (i && (i.terrains.includes(r.terrain) || i.terrains.includes("Coastal") && r.coastal) ? 100 : 0) + a;
	}
	return i.includes("blight") && !i.includes("attack") ? r.blight * 10 + a * .1 : a;
}
function Dr(e, t, n, r) {
	let i = e.lands.find((e) => e.id === r);
	if (!i) return !1;
	let a = i.presence[t] ?? 0;
	if (a < 2) return !1;
	if (n === "ravage") {
		let e = Math.max(0, i.explorers + i.towns * 2 + i.cities * 3 - i.defend);
		return a >= 3 ? e >= 4 : e >= 6;
	}
	return a >= 3 && i.towns > 0 && i.towns <= i.cities;
}
function Or(e, t, n) {
	let r = e.spirits[t], i = n.split(":");
	return i[0] === "chokeTheLandWithGreen" ? Dr(e, t, i[1], i[2]) : i[0] === "allyOfTheDahan" || n !== "growth:useDestroyed" || !e.blight.flipped || (r?.energy ?? 0) >= 3;
}
var kr = (e, t) => {
	let n = e.public, r = n.spirits[t.rid], i = n.pending;
	if (n.phase === "pick" && i?.kind === "pickSpirit" && i.seat === t.rid) return { action: {
		type: "pickSpirit",
		spirit: [...i.spirits ?? []].sort((e, t) => {
			let n = (e) => ({
				Low: 0,
				Moderate: 1,
				High: 2,
				"Very High": 3
			})[E.find((t) => t.id === e)?.complexity ?? "Low"] ?? 0;
			return n(e) - n(t);
		})[0]
	} };
	if (!i || i.seat !== t.rid) return null;
	switch (i.kind) {
		case "growth": {
			let e = E.find((e) => e.id === r?.spirit);
			if (!e) return { action: {
				type: "growth",
				group: 0
			} };
			let t = 0, n = -1;
			return e.growth.forEach((e, i) => {
				let a = 0;
				for (let t of e) if (t.t.startsWith("addPresence")) a += 3;
				else if (t.t === "gainPower") a += r && r.hand.length <= 2 ? 3 : 2;
				else if (t.t === "energy") a += t.n * .5;
				else if (t.t === "reclaim") {
					let e = (r?.discard.length ?? 0) + (r?.played.length ?? 0);
					a += Math.min(3, .5 + e * .5) + (r && r.hand.length === 0 ? 3 : 0);
				} else t.t === "cardPlay" && (a += r && r.hand.length >= 2 ? 2 : .5);
				a > n && (n = a, t = i);
			}), { action: {
				type: "growth",
				group: t
			} };
		}
		case "play": {
			if (!r) return { action: {
				type: "play",
				cards: []
			} };
			let e = E.find((e) => e.id === r.spirit)?.playsTrack[r.playsIdx]?.v ?? 1, t = Tr(n, n.invader.ravage), i = Tr(n, n.invader.build), a = n.lands.some((e) => e.blight > 0), o = (e) => {
				let n = D[e];
				if (!n) return 0;
				let r = wr(e), o = n.cost + (n.speed === "fast" ? .5 : 0);
				return r.includes("defend") && (n.speed === "fast" ? t >= 4 : i >= 4) && (o += 2), a && r.includes("blight") && (o += 1), o;
			}, s = [...r.hand].sort((e, t) => {
				let n = D[e], r = D[t];
				return !n || !r ? 0 : n.speed === r.speed ? o(t) - o(e) : n.speed === "fast" ? -1 : 1;
			}), c = [], l = r.energy;
			for (let t of s) {
				if (c.length >= e) break;
				let n = D[t];
				n && n.cost <= l && (c.push(t), l -= n.cost);
			}
			return { action: {
				type: "play",
				cards: c
			} };
		}
		case "land": {
			let e = i.legal ?? [], r = i.why.split(":")[0], a = [...e.map((e) => ({
				id: e,
				score: Er(n, r, e)
			})), ...(i.shadows ?? []).map((e) => ({
				id: e,
				score: Er(n, r, e) - 3
			}))].sort((e, t) => t.score - e.score || e.id.localeCompare(t.id));
			return i.why.includes("blightFlipped") ? { action: {
				type: "answer",
				value: e.map((e) => ({
					id: e,
					n: n.lands.find((t) => t.id === e)?.presence[t.rid] ?? 0
				})).sort((e, t) => t.n - e.n)[0]?.id ?? e[0]
			} } : { action: {
				type: "answer",
				value: a[0]?.id ?? e[0]
			} };
		}
		case "pieces": {
			let e = [...i.pieces ?? []].sort((e, t) => (Sr[t.type] ?? 0) - (Sr[e.type] ?? 0)), t = Math.min(i.count ?? 1, e.length);
			return { action: {
				type: "answer",
				value: e.slice(0, t)
			} };
		}
		case "cards": {
			let e = i.cards ?? [], t = i.count ?? 1;
			return i.why.includes("keep") ? { action: {
				type: "answer",
				value: [...e].sort((e, t) => (D[t]?.cost ?? 0) - (D[e]?.cost ?? 0)).slice(0, t)
			} } : i.why.includes("forget") || i.why.includes("elems") ? { action: {
				type: "answer",
				value: e.slice(0, t)
			} } : { action: {
				type: "answer",
				value: e.slice(0, i.upto ? t : Math.min(t, e.length))
			} };
		}
		case "yesno": return { action: {
			type: "answer",
			value: Or(n, t.rid, i.why)
		} };
		case "number": return { action: {
			type: "answer",
			value: i.max ?? 0
		} };
		case "spirit": return { action: {
			type: "answer",
			value: (i.spirits ?? []).includes(t.rid) ? t.rid : (i.spirits ?? [])[0]
		} };
		case "track": {
			let e = E.find((e) => e.id === r?.spirit);
			if (e && r) {
				let t = e.energyTrack[r.energyIdx]?.v ?? 0, n = e.playsTrack[r.playsIdx]?.v ?? 0;
				return { action: {
					type: "answer",
					value: (e.energyTrack[r.energyIdx + 1]?.v ?? t) - t >= (e.playsTrack[r.playsIdx + 1]?.v ?? n) - n ? "energy" : "plays"
				} };
			}
			return { action: {
				type: "answer",
				value: "energy"
			} };
		}
		default: return null;
	}
};
//#endregion
//#region src/games/spiritisland/fx.tsx
function Ar({ from: e, to: t, ms: n, children: r }) {
	let a = o(null);
	i(() => {
		let r = a.current;
		if (!r) return;
		let i = e ?? t, o = t.x + t.w / 2 - i.x - i.w / 2, s = t.y + t.h / 2 - i.y - i.h / 2, c = r.animate([
			{
				transform: "translate(0,0) scale(1)",
				opacity: 1
			},
			{
				transform: `translate(${o}px,${s}px) scale(1)`,
				opacity: 1,
				offset: .65
			},
			{
				transform: `translate(${o}px,${s + 12}px) scale(.15)`,
				opacity: 0
			}
		], {
			duration: n,
			easing: "ease-in-out",
			fill: "both"
		});
		return () => c.cancel();
	}, [
		e,
		t,
		n
	]);
	let s = e ?? t;
	return /* @__PURE__ */ x("div", {
		ref: a,
		className: "si-fx",
		style: {
			position: "absolute",
			left: s.x + s.w / 2 - 16,
			top: s.y + s.h / 2 - 16,
			width: 32,
			height: 32
		},
		children: r
	});
}
function jr({ at: e, ms: t, kind: n, source: r, children: a }) {
	let s = o(null);
	return i(() => {
		let e = s.current;
		if (!e) return;
		let r = Array.from(e.querySelectorAll("[data-si-motion]")).map((e, r) => e.animate([
			{
				transform: n === "destroy" ? "scale(.7)" : "translateX(-14px) scale(.65)",
				opacity: 0
			},
			{
				transform: "translateX(0) scale(1)",
				opacity: 1,
				offset: .28
			},
			{
				transform: `translate(${(r % 3 - 1) * 16}px,${-8 - r * 3}px) scale(${n === "destroy" ? 1.8 : 1.18})`,
				opacity: 0
			}
		], {
			duration: t,
			easing: "cubic-bezier(.2,.7,.3,1)",
			fill: "both"
		}));
		return () => r.forEach((e) => e.cancel());
	}, [t, n]), /* @__PURE__ */ S("div", {
		ref: s,
		className: `si-fx si-fx-${n}`,
		style: {
			position: "absolute",
			left: e.x + e.w / 2 - 66,
			top: e.y + e.h / 2 - 47,
			width: 132,
			height: 94
		},
		children: [n === "power" ? /* @__PURE__ */ x("div", {
			"data-si-motion": "",
			children: /* @__PURE__ */ x(sr, { id: r })
		}) : /* @__PURE__ */ x("svg", {
			width: "132",
			height: "94",
			viewBox: "0 0 132 94",
			"aria-hidden": "true",
			children: n === "defend" ? /* @__PURE__ */ x("path", {
				"data-si-motion": "",
				d: "M66 8L106 25L99 58L66 81L33 58L26 25ZM66 22L92 34L86 52L66 66L46 52L40 34Z",
				fill: "#a9ddcd",
				stroke: "#ffdfa0",
				strokeWidth: "2"
			}) : /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("path", {
				"data-si-motion": "",
				d: "M16 48L45 40L58 17L70 39L104 33L89 52L111 70L77 65L63 81L51 64L22 70L35 54Z",
				fill: n === "ravage" ? "#db9262" : "#e2c891",
				fillOpacity: ".65",
				stroke: "#ffdfa0"
			}), [
				0,
				1,
				2,
				3,
				4,
				5
			].map((e) => /* @__PURE__ */ x("path", {
				"data-si-motion": "",
				d: `M${25 + e * 15} ${38 + e % 2 * 12}l5-9 7 6-5 9Z`,
				fill: e % 2 ? "#80c8bb" : "#f6d59a"
			}, e))] })
		}), a && /* @__PURE__ */ x("div", {
			"data-si-motion": "",
			style: {
				position: "absolute",
				left: 49,
				top: 29
			},
			children: a
		})]
	});
}
var Mr = { "si:batch"(e, t) {
	let n = e.data?.events;
	if (!n?.length) return null;
	let r = t.queued ? 180 : 830, i = [], a = [], o = /* @__PURE__ */ new Set();
	for (let [e, s] of n.entries()) {
		let n = s.land ? t.anchor(`si:land:${s.land}`) : null, c = s.piece && s.land && s.ordinal !== void 0 ? `si:piece:${s.land}:${s.piece}:${s.ordinal}` : "", l = c ? t.anchor(c) : null, u = s.seat ? t.anchor(`si:seat:${s.seat}`) : null, d = oe[(t.member(s.seat ?? "")?.colorIndex ?? 0) % oe.length].hex, f = s.piece?.startsWith("presence:") ? /* @__PURE__ */ x(Gn, {
			color: d,
			size: 30
		}) : s.piece ? /* @__PURE__ */ x(Wn, {
			name: s.piece,
			size: 32
		}) : null;
		if (s.kind === "move" || s.kind === "place") {
			let o = s.from ? t.anchor(`si:slot:${s.from}:${s.piece}:${s.fromOrdinal}`) ?? t.anchor(`si:land:${s.from}`) : u;
			s.drowned && n && f ? i.push(/* @__PURE__ */ x(Ar, {
				from: t.queued ? null : o,
				to: n,
				ms: r,
				children: f
			}, e)) : o && l && f && !t.queued ? (i.push(/* @__PURE__ */ x(le, {
				from: o,
				to: l,
				ms: r,
				children: f
			}, e)), a.push(c)) : n && f && i.push(/* @__PURE__ */ x(jr, {
				at: n,
				ms: r,
				kind: "place",
				children: f
			}, e));
		} else if ((s.kind === "destroy" || s.kind === "remove") && n) i.push(/* @__PURE__ */ x(jr, {
			at: t.anchor(`si:slot:${s.land}:${s.piece}:${s.ordinal}`) ?? n,
			ms: r,
			kind: "destroy",
			children: f
		}, e));
		else if (s.kind === "fear" && (n || u)) i.push(/* @__PURE__ */ x(ce, {
			at: n ?? u,
			ms: r,
			children: /* @__PURE__ */ S("span", {
				className: "si-fx si-fx-number",
				children: ["◉ +", s.n]
			})
		}, e));
		else if (s.kind === "play" && u) i.push(/* @__PURE__ */ x(jr, {
			at: u,
			ms: r,
			kind: "power",
			source: "boonOfVigor"
		}, e));
		else if (n || u) {
			let t = `${s.kind}:${s.land}:${s.source}`;
			if (o.has(t)) continue;
			o.add(t), i.push(/* @__PURE__ */ x(jr, {
				at: n ?? u,
				ms: r,
				kind: s.kind,
				source: s.source
			}, e)), s.n !== void 0 && i.push(/* @__PURE__ */ x(ce, {
				at: n ?? u,
				ms: r,
				children: /* @__PURE__ */ S("span", {
					className: "si-fx si-fx-number",
					children: [
						s.kind === "defend" ? "◇" : "↯",
						" ",
						s.n
					]
				})
			}, `n:${e}`));
		}
	}
	return i.length ? {
		ms: r,
		node: i,
		hide: t.queued ? [] : a
	} : null;
} };
//#endregion
//#region src/games/spiritisland/game-over.tsx
function Nr({ public: e, members: t, myRid: n, hintCount: r, onPlayAgain: i, onBackToLobby: a }) {
	let c = e, u = l(), [d, f] = s(null), [m, ee] = s(null), [te, g] = s(!0), _ = o(null), v = o(null), y = (e) => {
		f(null), g(e), requestAnimationFrame(() => (e ? v : _).current?.focus());
	}, ne = c.over?.reason, re = c.over?.win ? ne === "fear" ? "games.spiritisland.ui.winFear" : "games.spiritisland.ui.winInvaders" : ne === "presence" ? "games.spiritisland.ui.losePresenceFull" : ne === "blight" ? "games.spiritisland.ui.loseBlight" : "games.spiritisland.ui.loseTime";
	return /* @__PURE__ */ S("div", {
		className: "si-over",
		children: [
			/* @__PURE__ */ x($n, {
				pub: c,
				members: t,
				myRid: n,
				onLand: ee
			}),
			te && /* @__PURE__ */ S("div", {
				className: "si-over-result",
				children: [
					/* @__PURE__ */ x(ar, {
						id: c.spirits[n]?.spirit,
						size: 104,
						broken: !c.over?.win
					}),
					/* @__PURE__ */ x("h1", { children: u(c.over?.win ? "games.spiritisland.ui.win" : "games.spiritisland.ui.lose") }),
					/* @__PURE__ */ S("p", { children: [
						u(re),
						" · ",
						u("games.spiritisland.ui.round", { n: c.round })
					] }),
					r !== void 0 && /* @__PURE__ */ x("p", {
						className: "si-over-hints",
						children: u("session.hint.usedCount", { n: r })
					}),
					/* @__PURE__ */ x("button", {
						ref: v,
						type: "button",
						className: "si-button si-over-inspect",
						"aria-label": u("games.spiritisland.ui.viewIsland"),
						title: u("games.spiritisland.ui.viewIsland"),
						onClick: () => y(!1),
						children: /* @__PURE__ */ x(p, { size: 18 })
					})
				]
			}),
			te ? /* @__PURE__ */ S("div", {
				className: "si-over-actions",
				children: [
					i && /* @__PURE__ */ x("button", {
						className: `si-button si-primary ${d === "again" ? "danger-stripes" : ""}`,
						onClick: () => d === "again" ? i() : f("again"),
						children: u(d === "again" ? "games.spiritisland.ui.confirmAgain" : "games.spiritisland.ui.playAgain")
					}),
					a && /* @__PURE__ */ x("button", {
						className: `si-button ${d === "back" ? "danger-stripes" : ""}`,
						onClick: () => d === "back" ? a() : f("back"),
						children: u(d === "back" ? "games.spiritisland.ui.confirmBack" : "games.spiritisland.ui.backLobby")
					}),
					!i && !a && /* @__PURE__ */ x("span", { children: u("games.spiritisland.ui.waitHost") }),
					d && /* @__PURE__ */ x("button", {
						className: "si-button",
						onClick: () => f(null),
						children: u("games.spiritisland.ui.cancel")
					})
				]
			}) : /* @__PURE__ */ S("button", {
				ref: _,
				type: "button",
				className: "si-button si-over-result-toggle",
				onClick: () => y(!0),
				children: [/* @__PURE__ */ x(h, { size: 18 }), u("games.spiritisland.ui.viewResults")]
			}),
			m && /* @__PURE__ */ x(ur, {
				title: m,
				onClose: () => ee(null),
				children: /* @__PURE__ */ x(mr, {
					pub: c,
					id: m,
					members: t,
					onFocus: ee
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/spiritisland/entry.tsx
var Pr = {
	definition: Xt,
	View: br,
	bot: kr,
	fx: Mr,
	OverView: Nr,
	locales: {
		zh: {
			name: "灵迹岛",
			desc: "合作御敌:扮演岛屿精灵,用元素之力驱逐入侵的殖民者",
			rules: "目标:所有玩家合作扮演精灵,在入侵者占领岛屿前将其驱逐。\n胜利条件随恐怖等级提高而放宽：\n· 恐怖等级为一时，需要消灭全部入侵者。\n· 恐怖等级为二时，需要消灭全部村镇与城市。\n· 恐怖等级为三时，只需要消灭全部城市。\n准备:每名玩家选择一名精灵与一块版图,按版图印刷放置入侵者、达罕人与枯萎,再按精灵说明放置初始灵气。\n组建入侵者牌堆(第一阶段 4 张、第二阶段 5 张、第三阶段随机 3 张)与 9 张恐惧牌堆,枯萎池为玩家人数的两倍加一。\n流程:每个回合依次进行以下阶段。\n· 成长阶段:每人同时选择一组成长选项并执行,例如放置灵气、获得能量、获得威力牌或收回已打出的牌。\n· 出牌阶段:每人同时选择本回合打出的威力牌并支付能量,数量不超过灵气轨上露出的出牌数。\n· 快速阶段:按座次结算所有快速威力,以及元素达标后的快速天赋能力。\n· 入侵者阶段:先结算已集满的恐惧牌,再依次结算破坏、建造与探索,最后推进入侵者牌槽。\n· 慢速阶段:按座次结算所有慢速威力与慢速天赋能力。\n· 时光流逝:本回合打出的牌进入弃牌堆,所有本回合增益清除。\n破坏:入侵者的伤害先被防御抵免,之后每 2 点伤害消灭 1 个达罕人。\n地格受到 2 点或以上伤害时添加 1 个枯萎;若该格已有枯萎,再向相邻地格蔓延 1 个。\n破坏结算后存活的达罕人反击,每个达罕人对入侵者造成 2 点伤害。\n恐惧:消灭 1 个村镇获得 1 点恐惧,消灭 1 个城市获得 2 点恐惧。\n恐惧池为玩家人数的四倍;集满时清空并结算一张恐惧牌,效果按当前恐怖等级执行。\n威力:射程从你的灵气或圣地(你至少有 2 个灵气的地格)起量。\n获得低级威力牌时摸 4 张选 1 张;获得高级威力牌时同样摸 4 张选 1 张,再遗忘你的 1 张牌。\n发生以下任一情况时，所有玩家共同失败：\n· 任一精灵在岛上没有灵气。\n· 需要放置枯萎时，枯萎池已经耗尽，且枯萎卡已经翻面。\n· 需要抽取入侵者牌时，入侵者牌堆已经耗尽。",
			ui: {
				recenter: "定位当前目标",
				choiceDamage: "造成伤害",
				choiceGatherDahan: "聚集达罕人",
				choicePushDahan: "推出达罕人",
				choicePushInvaders: "推出入侵者",
				choiceRemoveBlight: "移除枯萎",
				choicePushExplorer: "推出探索者",
				choiceFear: "产生恐惧",
				choiceGatherInvaders: "聚集入侵者",
				choiceDefend: "提供防御",
				choiceMajor: "获得高级威力",
				choiceDowngradeTown: "村镇 → 探索者",
				choiceDowngradeCity: "城市 → 村镇",
				choicePushTown: "推出村镇",
				choicePresence: "放置灵气",
				choiceForget: "遗忘威力牌",
				choiceDestroyPresence: "消灭灵气",
				choiceApply: "发动效果",
				choiceSkip: "跳过效果",
				choiceRemoveTown: "移除村镇",
				choiceRemoveExplorers: "移除探索者",
				blightSpiral: "衰败螺旋",
				blightMemory: "记忆化为尘埃",
				blightSpiralRule: "每个入侵者阶段，每名精灵消灭自己的 1 个灵气。",
				blightMemoryRule: "每个入侵者阶段，每名精灵遗忘 1 张威力牌，或消灭自己的 1 个灵气。",
				you: "你",
				result: "对局结果",
				elementSun: "日",
				elementMoon: "月",
				elementFire: "火",
				elementAir: "风",
				elementWater: "水",
				elementEarth: "土",
				elementPlant: "植",
				elementAnimal: "兽",
				elementAny: "任意",
				targetAnyLand: "任意地格",
				targetAnySpirit: "任意精灵",
				targetAnotherSpirit: "其他精灵",
				targetDahan: "有达罕人",
				targetInvaders: "有入侵者",
				targetNoBlight: "没有枯萎",
				targetNoInvaders: "没有入侵者",
				targetBlight: "有枯萎",
				targetJungleWetland: "丛林 / 湿地",
				targetMountainJungle: "山地 / 丛林",
				targetMountainWetland: "山地 / 湿地",
				targetSelf: "自身",
				growthReclaim: "收回手牌",
				growthGain: "获得威力 ×{{n}}",
				growthEnergy: "能量 +{{n}}",
				growthPlay: "出牌 +{{n}}",
				growthMove: "移动灵气 ×{{n}}",
				growthDiscard: "弃牌 ×{{n}}",
				sacredSite: "圣地",
				destroyedPresence: "被消灭的灵气",
				close: "关闭",
				cancel: "取消",
				details: "详情",
				range: "射程",
				perTurn: "能量 / 回合",
				specialRules: "特殊规则",
				innates: "天赋",
				elements: "元素",
				nextNode: "揭示下一节点",
				fullIsland: "全岛",
				zoomIn: "放大",
				zoomOut: "缩小",
				focusBoard: "聚焦岛板 {{board}}",
				adjacent: "相邻地格",
				noPieces: "没有棋件",
				healthy: "健康岛屿",
				blighted: "枯萎岛屿",
				terrorOne: "消灭全部入侵者",
				terrorTwo: "消灭全部村镇与城市",
				terrorThree: "消灭全部城市",
				fearPending: "待结算恐惧牌",
				noLog: "暂无行动记录",
				log: "记录",
				ready: "已完成",
				waiting: "等待",
				active: "行动中",
				targetConfirm: "确定目标",
				selectCount: "已选 {{n}} / {{max}}",
				costTotal: "费用 {{n}} / {{max}}",
				fastPower: "快速威力",
				slowPower: "慢速威力",
				powerDetail: "威力详情",
				pickConfirm: "选择此精灵",
				complexityLow: "低难度",
				complexityModerate: "中等难度",
				complexityHigh: "高难度",
				complexityVeryHigh: "极高难度",
				skipRavage: "跳过破坏",
				skipBuild: "跳过建造",
				skipExplore: "跳过探索",
				isolated: "隔离",
				reclaimNode: "收回 1 张牌",
				rangeBonus: "射程 +{{n}}",
				accelerated: "已加速",
				winFear: "恐惧驱散了入侵者",
				winInvaders: "岛屿的威胁已被清除",
				losePresenceFull: "精灵的灵气被彻底抹除",
				playAgain: "再次守护岛屿",
				backLobby: "返回房间",
				viewIsland: "查看岛屿",
				viewResults: "查看结算",
				confirmAgain: "确定重开",
				confirmBack: "确定返回",
				waitHost: "等待主机继续",
				threshold: "元素门槛",
				noHand: "没有手牌",
				noLegal: "没有合法目标",
				chooseExactPieces: "选择 {{n}} 个目标",
				chooseUpToPieces: "选择至多 {{n}} 个目标",
				number: "选择数量",
				minus: "减少",
				plus: "增加",
				setup: "初始摆放",
				effects: "当前效果",
				overview: "公共桌板",
				pickSpirit: "选择精灵",
				growth: "成长阶段",
				play: "出牌阶段",
				fast: "快速阶段",
				slow: "慢速阶段",
				invaderPhase: "入侵者阶段",
				cleanup: "时光流逝",
				chooseGrowth: "选择一组成长选项",
				playCards: "选择要打出的牌",
				confirm: "确定",
				pass: "跳过",
				energy: "能量",
				cardPlays: "出牌数",
				hand: "手牌",
				discard: "弃牌堆",
				played: "已打出",
				forgotten: "已遗忘",
				fearPool: "恐惧",
				blightPool: "枯萎",
				invaderDeck: "入侵者牌堆",
				fearDeck: "恐惧牌堆",
				terrorLevel: "恐怖等级",
				stage: "阶段",
				win: "岛屿恢复了宁静,精灵们胜利了!",
				lose: "岛屿沦陷了……",
				losePresence: "的灵气被彻底抹除",
				loseBlight: "枯萎吞噬了整座岛屿",
				loseTime: "入侵者站稳了脚跟(牌堆耗尽)",
				errNotYourTurn: "现在轮不到你操作",
				errBadSpirit: "不能选择这名精灵",
				errBadGroup: "这组成长选项无效",
				errBadCards: "不能打出这些牌",
				errBadAnswer: "这个选择无效",
				errNoEnergy: "能量不足",
				chooseLand: "选择目标地格",
				choosePieces: "选择目标(至多 {{n}} 个)",
				chooseCards: "选择卡牌",
				yes: "是",
				no: "否",
				gainPowerKeep: "获得威力牌:选择要保留的 1 张",
				forgetCard: "选择要遗忘的 1 张牌",
				selectTrack: "选择从哪条轨道取灵气",
				trackEnergy: "能量轨",
				trackPlays: "出牌轨",
				currentAction: "正在结算",
				skipInnate: "跳过此天赋",
				waitOthers: "等待其他玩家……",
				goptReclaim: "收回所有已打出的牌",
				goptGainPower: "获得 1 张低级威力牌(摸 4 选 1)",
				goptEnergy: "获得 {{n}} 能量",
				goptCardPlay: "本回合多打出 1 张牌",
				goptAddPresence: "放置 1 个灵气(射程 {{n}})",
				goptAddPresenceDahan: "放置 1 个灵气到有达罕人的地格(射程 {{n}})",
				goptAddPresenceDahanInvaders: "放置 1 个灵气到有达罕人或入侵者的地格(射程 {{n}})",
				goptAddPresenceCoastal: "放置 1 个灵气到沿海地格",
				goptAddPresenceOcean: "放置 1 个灵气到海洋",
				goptGatherOcean: "每个有灵气的海洋从相邻格聚集 1 个灵气",
				goptPushOcean: "每个有灵气的海洋向相邻格推出 1 个灵气",
				terrainMountain: "山地",
				terrainJungle: "丛林",
				terrainSands: "沙地",
				terrainWetland: "湿地",
				terrainOcean: "海洋",
				pieceExplorer: "探索者",
				pieceTown: "村镇",
				pieceCity: "城市",
				pieceDahan: "达罕人",
				piecePresence: "灵气",
				pieceBlight: "枯萎",
				invaderSlotRavage: "破坏",
				invaderSlotBuild: "建造",
				invaderSlotExplore: "探索",
				land: "地格",
				coastalMark: "沿海",
				defendMark: "防御 {{n}}",
				round: "第 {{n}} 回合",
				yourTurn: "轮到你",
				spiritPick: "选择你的精灵",
				whyChokeRavage: "绿意扼土:消灭 1 个灵气,跳过本次破坏?",
				whyChokeBuild: "绿意扼土:消灭 1 个灵气,跳过本次建造?",
				whyAllyFollow: "达罕的盟友:让 1 个灵气随行?",
				whyUseDestroyed: "稳定再生:改用 1 个被消灭的灵气?",
				shadowsPayMark: "达罕之影:付 1 能量"
			}
		},
		en: {
			name: "Spirit Island",
			desc: "A cooperative game: play spirits of the island and drive out the invading colonizers",
			rules: "Goal: all players cooperate as Spirits of the island and drive the Invaders away.\nThe victory condition becomes easier as the Terror Level rises:\n· At Terror Level I, destroy every Invader.\n· At Terror Level II, destroy all Towns and Cities.\n· At Terror Level III, destroy all Cities.\nSetup: each player picks a Spirit and one island board. Place Invaders, Dahan and Blight as printed, then place starting Presence per the Spirit panel.\nBuild the Invader deck (4 Stage I, 5 Stage II, 3 random Stage III cards) and a Fear deck of 9 cards; the Blight pool is twice the player count plus one.\nPlay: each round proceeds through the following phases in order.\n· Spirit Phase: everyone simultaneously picks one Growth option group and resolves it, such as adding Presence, gaining Energy, gaining Power Cards or reclaiming played cards.\n· Play Phase: everyone simultaneously chooses Power Cards to play this turn and pays their Energy, up to the Card Plays shown on the Presence track.\n· Fast Phase: resolve all Fast powers in seat order, including Fast innate powers whose element thresholds are met.\n· Invader Phase: resolve earned Fear cards first, then Ravage, Build and Explore in order, and finally advance the Invader card slots.\n· Slow Phase: resolve all Slow powers and Slow innate powers in seat order.\n· Time Passes: played cards go to discard piles and all this-turn bonuses are cleared.\nRavage: Defense absorbs the damage first, then every 2 damage destroys 1 Dahan.\nA land taking 2 or more damage gains 1 Blight; if it already had Blight, 1 more Blight cascades into an adjacent land.\nAfter Ravage, surviving Dahan fight back, each dealing 2 damage to the Invaders.\nFear: destroying a Town earns 1 Fear and destroying a City earns 2 Fear.\nThe Fear pool is four times the player count; when it fills, clear it and resolve a Fear card at the current Terror Level.\nPowers: measure Range from your Presence or from a Sacred Site (a land with at least 2 of your Presence).\nWhen gaining a Minor Power draw 4 and keep 1; when gaining a Major Power also draw 4 and keep 1, then Forget one of your cards.\nDefeat: all players lose if any Spirit has no Presence left on the island, if Blight must be placed while the pool is empty and the Blight Card is already flipped, or if an Invader card must be drawn while the deck is empty.",
			ui: {
				recenter: "Recenter on target",
				choiceDamage: "Deal damage",
				choiceGatherDahan: "Gather Dahan",
				choicePushDahan: "Push Dahan",
				choicePushInvaders: "Push Invaders",
				choiceRemoveBlight: "Remove Blight",
				choicePushExplorer: "Push Explorer",
				choiceFear: "Generate Fear",
				choiceGatherInvaders: "Gather Invaders",
				choiceDefend: "Defend",
				choiceMajor: "Gain Major Power",
				choiceDowngradeTown: "Town → Explorer",
				choiceDowngradeCity: "City → Town",
				choicePushTown: "Push Town",
				choicePresence: "Add Presence",
				choiceForget: "Forget a Power",
				choiceDestroyPresence: "Destroy Presence",
				choiceApply: "Use effect",
				choiceSkip: "Skip effect",
				choiceRemoveTown: "Remove Town",
				choiceRemoveExplorers: "Remove Explorers",
				blightSpiral: "Downward Spiral",
				blightMemory: "Memory Fades to Dust",
				blightSpiralRule: "Each Invader Phase, each Spirit destroys 1 of their Presence.",
				blightMemoryRule: "Each Invader Phase, each Spirit forgets a Power or destroys 1 of their Presence.",
				you: "You",
				result: "Outcome",
				elementSun: "Sun",
				elementMoon: "Moon",
				elementFire: "Fire",
				elementAir: "Air",
				elementWater: "Water",
				elementEarth: "Earth",
				elementPlant: "Plant",
				elementAnimal: "Animal",
				elementAny: "Any",
				targetAnyLand: "Any land",
				targetAnySpirit: "Any Spirit",
				targetAnotherSpirit: "Another Spirit",
				targetDahan: "With Dahan",
				targetInvaders: "With Invaders",
				targetNoBlight: "Without Blight",
				targetNoInvaders: "Without Invaders",
				targetBlight: "With Blight",
				targetJungleWetland: "Jungle / Wetland",
				targetMountainJungle: "Mountain / Jungle",
				targetMountainWetland: "Mountain / Wetland",
				targetSelf: "Self",
				growthReclaim: "Reclaim cards",
				growthGain: "Gain power ×{{n}}",
				growthEnergy: "Energy +{{n}}",
				growthPlay: "Plays +{{n}}",
				growthMove: "Move Presence ×{{n}}",
				growthDiscard: "Discard ×{{n}}",
				sacredSite: "Sacred Site",
				destroyedPresence: "Destroyed Presence",
				close: "Close",
				cancel: "Cancel",
				details: "Details",
				range: "Range",
				perTurn: "Energy / turn",
				specialRules: "Special rules",
				innates: "Innate powers",
				elements: "Elements",
				nextNode: "Reveal next node",
				fullIsland: "Island",
				zoomIn: "Zoom in",
				zoomOut: "Zoom out",
				focusBoard: "Focus board {{board}}",
				adjacent: "Adjacent lands",
				noPieces: "No pieces",
				healthy: "Healthy island",
				blighted: "Blighted island",
				terrorOne: "Destroy all Invaders",
				terrorTwo: "Destroy all Towns and Cities",
				terrorThree: "Destroy all Cities",
				fearPending: "Earned Fear cards",
				noLog: "No recorded actions",
				log: "Records",
				ready: "Done",
				waiting: "Waiting",
				active: "Acting",
				targetConfirm: "Confirm target",
				selectCount: "Selected {{n}} / {{max}}",
				costTotal: "Cost {{n}} / {{max}}",
				fastPower: "Fast power",
				slowPower: "Slow power",
				powerDetail: "Power details",
				pickConfirm: "Choose this Spirit",
				complexityLow: "Low",
				complexityModerate: "Moderate",
				complexityHigh: "High",
				complexityVeryHigh: "Very High",
				skipRavage: "Skip Ravage",
				skipBuild: "Skip Build",
				skipExplore: "Skip Explore",
				isolated: "Isolated",
				reclaimNode: "Reclaim 1 card",
				rangeBonus: "Range +{{n}}",
				accelerated: "Made fast",
				winFear: "Fear drove the Invaders away",
				winInvaders: "The island is free of Invaders",
				losePresenceFull: "A Spirit lost all Presence",
				playAgain: "Play again",
				backLobby: "Back to lobby",
				viewIsland: "View island",
				viewResults: "View results",
				confirmAgain: "Confirm restart",
				confirmBack: "Confirm return",
				waitHost: "Waiting for the host",
				threshold: "Element threshold",
				noHand: "No cards in hand",
				noLegal: "No legal targets",
				chooseExactPieces: "Choose {{n}} pieces",
				chooseUpToPieces: "Choose up to {{n}} pieces",
				number: "Choose amount",
				minus: "Decrease",
				plus: "Increase",
				setup: "Setup",
				effects: "Current effect",
				overview: "Island status",
				pickSpirit: "Choose your Spirit",
				growth: "Spirit Phase",
				play: "Play Phase",
				fast: "Fast Phase",
				slow: "Slow Phase",
				invaderPhase: "Invader Phase",
				cleanup: "Time Passes",
				chooseGrowth: "Choose a Growth option group",
				playCards: "Choose cards to play",
				confirm: "Confirm",
				pass: "Skip",
				energy: "Energy",
				cardPlays: "Card Plays",
				hand: "Hand",
				discard: "Discard",
				played: "Played",
				forgotten: "Forgotten",
				fearPool: "Fear",
				blightPool: "Blight",
				invaderDeck: "Invader Deck",
				fearDeck: "Fear Deck",
				terrorLevel: "Terror Level",
				stage: "Stage",
				win: "The island is at peace. The Spirits win!",
				lose: "The island has fallen...",
				losePresence: "'s Presence was wiped out",
				loseBlight: "Blight consumed the whole island",
				loseTime: "The Invaders dug in for good (deck exhausted)",
				errNotYourTurn: "It is not your turn",
				errBadSpirit: "You cannot choose this Spirit",
				errBadGroup: "Invalid Growth option group",
				errBadCards: "You cannot play these cards",
				errBadAnswer: "Invalid choice",
				errNoEnergy: "Not enough Energy",
				chooseLand: "Choose a target land",
				choosePieces: "Choose targets (up to {{n}})",
				chooseCards: "Choose cards",
				yes: "Yes",
				no: "No",
				gainPowerKeep: "Gain a Power: choose 1 card to keep",
				forgetCard: "Choose 1 card to Forget",
				selectTrack: "Choose which track to take Presence from",
				trackEnergy: "Energy track",
				trackPlays: "Card Plays track",
				currentAction: "Resolving",
				skipInnate: "Skip this innate power",
				waitOthers: "Waiting for other players...",
				goptReclaim: "Reclaim all played cards",
				goptGainPower: "Gain 1 Minor Power (draw 4, keep 1)",
				goptEnergy: "Gain {{n}} Energy",
				goptCardPlay: "+1 Card Play this turn",
				goptAddPresence: "Add 1 Presence (range {{n}})",
				goptAddPresenceDahan: "Add 1 Presence to a land with Dahan (range {{n}})",
				goptAddPresenceDahanInvaders: "Add 1 Presence to a land with Dahan or Invaders (range {{n}})",
				goptAddPresenceCoastal: "Add 1 Presence to a Coastal land",
				goptAddPresenceOcean: "Add 1 Presence to an Ocean",
				goptGatherOcean: "Gather 1 Presence into each Ocean with your Presence",
				goptPushOcean: "Push 1 Presence from each Ocean with your Presence",
				terrainMountain: "Mountain",
				terrainJungle: "Jungle",
				terrainSands: "Sands",
				terrainWetland: "Wetland",
				terrainOcean: "Ocean",
				pieceExplorer: "Explorer",
				pieceTown: "Town",
				pieceCity: "City",
				pieceDahan: "Dahan",
				piecePresence: "Presence",
				pieceBlight: "Blight",
				invaderSlotRavage: "Ravage",
				invaderSlotBuild: "Build",
				invaderSlotExplore: "Explore",
				land: "Land",
				coastalMark: "Coastal",
				defendMark: "Defend {{n}}",
				round: "Round {{n}}",
				yourTurn: "Your turn",
				spiritPick: "Choose your Spirit",
				whyChokeRavage: "Choke the Land with Green: destroy 1 Presence to skip this Ravage?",
				whyChokeBuild: "Choke the Land with Green: destroy 1 Presence to skip this Build?",
				whyAllyFollow: "Ally of the Dahan: move 1 Presence along?",
				whyUseDestroyed: "Steady Regeneration: use 1 destroyed Presence instead?",
				shadowsPayMark: "Shadows of the Dahan: pay 1 Energy"
			}
		}
	}
};
//#endregion
export { Pr as default };
