import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { Texture as c } from "@bgparty/sdk/texture";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as d, seatName as f } from "@bgparty/sdk/ui/player-strip";
import { jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g } from "@bgparty/sdk/fx/primitives";
import { AVATARS as _ } from "@bgparty/sdk/avatars";
import { IconBot as v } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as y } from "@bgparty/sdk/player-colors";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as x, OptionSection as S } from "@bgparty/sdk/ui/game-options";
//#region src/games/jaipur/cards.ts
var C = [
	"diamond",
	"gold",
	"silver",
	"cloth",
	"spice",
	"leather"
], w = {
	diamond: 6,
	gold: 6,
	silver: 6,
	cloth: 8,
	spice: 8,
	leather: 10,
	camel: 11
}, T = {
	diamond: [
		7,
		7,
		5,
		5,
		5
	],
	gold: [
		6,
		6,
		5,
		5,
		5
	],
	silver: [
		5,
		5,
		5,
		5,
		5
	],
	cloth: [
		5,
		3,
		3,
		2,
		2,
		1,
		1
	],
	spice: [
		5,
		3,
		3,
		2,
		2,
		1,
		1
	],
	leather: [
		4,
		3,
		2,
		1,
		1,
		1,
		1,
		1,
		1
	]
}, E = {
	3: [
		1,
		1,
		2,
		2,
		2,
		3,
		3
	],
	4: [
		4,
		4,
		5,
		5,
		6,
		6
	],
	5: [
		8,
		8,
		9,
		10,
		10
	]
}, D = {
	diamond: 2,
	gold: 2,
	silver: 2,
	cloth: 1,
	spice: 1,
	leather: 1
}, O = {
	diamond: {
		bg: "#7dd3fc",
		fg: "#0c4a6e",
		emoji: "💎"
	},
	gold: {
		bg: "#fbbf24",
		fg: "#78350f",
		emoji: "🥇"
	},
	silver: {
		bg: "#e2e8f0",
		fg: "#475569",
		emoji: "🥈"
	},
	cloth: {
		bg: "#c084fc",
		fg: "#581c87",
		emoji: "🧵"
	},
	spice: {
		bg: "#fb923c",
		fg: "#7c2d12",
		emoji: "🌶️"
	},
	leather: {
		bg: "#b45309",
		fg: "#fef3c7",
		emoji: "👝"
	},
	camel: {
		bg: "#fcd9a8",
		fg: "#7c4a12",
		emoji: "🐪"
	}
};
function k() {
	let e = [];
	for (let t of Object.keys(w)) for (let n = 0; n < w[t]; n += 1) e.push(t);
	return e;
}
//#endregion
//#region src/games/jaipur/meta.ts
var A = {
	id: "jaipur",
	tier: "alpha",
	mechanics: ["set-collection", "hand-management"],
	interactionTags: [],
	nameKey: "games.jaipur.name",
	descKey: "games.jaipur.desc",
	rulesKey: "games.jaipur.rules",
	icon: "🐪",
	iconImg: "games/jaipur.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/jaipur/en.pdf" },
	precacheAssets: [
		"diamond.webp",
		"gold.webp",
		"silver.webp",
		"cloth.webp",
		"spice.webp",
		"leather.webp",
		"camel.webp"
	],
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#d97706",
	releasedAt: "2026-09-16",
	search: {
		py: "zhai pu er",
		init: "zpe"
	},
	hotseat: "cover"
}, j = t.enum([
	"diamond",
	"gold",
	"silver",
	"cloth",
	"spice",
	"leather"
]), M = t.union([j, t.literal("camel")]), N = t.string(), P = t.object({ match: t.enum(["single", "bestOf3"]).default("bestOf3") }).default({ match: "bestOf3" }), F = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("take"),
		index: t.int().nonnegative()
	}),
	t.object({ type: t.literal("takeCamels") }),
	t.object({
		type: t.literal("exchange"),
		take: t.array(t.int().nonnegative()).min(2),
		giveGoods: t.array(j),
		giveCamels: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("sell"),
		good: j,
		count: t.int().min(1)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), I = t.object({
	good: j,
	value: t.int()
}), L = t.object({
	tier: t.union([
		t.literal(3),
		t.literal(4),
		t.literal(5)
	]),
	value: t.int()
}), R = t.object({
	kind: t.literal("take"),
	rid: N,
	card: M,
	index: t.int().nonnegative()
}), z = t.object({
	kind: t.literal("takeCamels"),
	rid: N,
	count: t.int().min(1)
}), B = t.object({
	kind: t.literal("exchange"),
	rid: N,
	take: t.array(M),
	giveGoods: t.array(j),
	giveCamels: t.int().nonnegative()
}), ee = t.object({
	kind: t.literal("sell"),
	rid: N,
	good: j,
	count: t.int().min(1),
	tokens: t.array(t.int()),
	bonusTier: t.union([
		t.literal(3),
		t.literal(4),
		t.literal(5)
	]).nullable()
}), te = t.object({
	kind: t.literal("roundEnd"),
	reason: t.enum(["tokens", "deck"]),
	scores: t.record(N, t.int()),
	camelWinner: N.nullable(),
	winner: N.nullable()
}), ne = t.discriminatedUnion("kind", [
	R,
	z,
	B,
	ee,
	te
]), re = t.discriminatedUnion("kind", [
	R,
	z,
	B,
	ee,
	te,
	t.object({
		kind: t.literal("round"),
		n: t.int().min(1)
	})
]), ie = t.object({
	match: t.enum(["single", "bestOf3"]),
	round: t.int().min(1),
	phase: t.enum([
		"play",
		"roundEnd",
		"done"
	]),
	turn: N.nullable(),
	market: t.array(M),
	deckCount: t.int().nonnegative(),
	piles: t.record(j, t.array(t.int())),
	bonusPiles: t.object({
		b3: t.int().nonnegative(),
		b4: t.int().nonnegative(),
		b5: t.int().nonnegative()
	}),
	camelTokenLive: t.boolean(),
	players: t.array(t.object({
		rid: N,
		herd: t.int().nonnegative(),
		handCount: t.int().nonnegative(),
		goodsTokens: t.array(I),
		bonusCount: t.int().nonnegative(),
		seals: t.int().nonnegative()
	})),
	revealBonus: t.record(N, t.array(L)).nullable(),
	last: ne.nullable(),
	log: t.array(re)
}), ae = t.object({
	hand: t.array(j),
	bonus: t.array(L)
}), oe = 5200, V = (e, t) => e.players.find((e) => e !== t);
function H(t, n) {
	let r = t.rngCursor;
	for (let i = n.length - 1; i > 0; --i) {
		let a = e(t.seed, r, i + 1);
		r += 1, [n[i], n[a]] = [n[a], n[i]];
	}
	return t.rngCursor = r, n;
}
function se(e, t) {
	let n = k();
	n.splice(n.indexOf("camel"), 1), n.splice(n.indexOf("camel"), 1), n.splice(n.indexOf("camel"), 1);
	let r = H(e, n);
	e.market = [
		"camel",
		"camel",
		"camel",
		r.pop(),
		r.pop()
	], e.deck = r, e.hands = {}, e.herds = {};
	for (let t of e.players) {
		let n = r.splice(r.length - 5, 5);
		e.hands[t] = n.filter((e) => e !== "camel"), e.herds[t] = n.length - e.hands[t].length;
	}
	e.piles = Object.fromEntries(C.map((e) => [e, [...T[e]]])), e.bonusPiles = {
		3: H(e, [...E[3]]),
		4: H(e, [...E[4]]),
		5: H(e, [...E[5]])
	}, e.goodsTokens = Object.fromEntries(e.players.map((e) => [e, []])), e.bonusTokens = Object.fromEntries(e.players.map((e) => [e, []])), e.camelTokenTaken = !1, e.starter = t, e.turn = t;
}
function ce(e) {
	for (; e.market.length < 5 && e.deck.length > 0;) e.market.push(e.deck.pop());
}
function le(e, t, n) {
	return e.goodsTokens[t].reduce((e, t) => e + t.value, 0) + e.bonusTokens[t].reduce((e, t) => e + t.value, 0) + (n === t ? 5 : 0);
}
function ue(e, t) {
	let [n, r] = e.players, i = e.herds[n] === e.herds[r] ? null : e.herds[n] > e.herds[r] ? n : r;
	e.camelTokenTaken = !0;
	let a = Object.fromEntries(e.players.map((t) => [t, le(e, t, i)])), o = null;
	a[n] === a[r] ? e.bonusTokens[n].length === e.bonusTokens[r].length ? e.goodsTokens[n].length !== e.goodsTokens[r].length && (o = e.goodsTokens[n].length > e.goodsTokens[r].length ? n : r) : o = e.bonusTokens[n].length > e.bonusTokens[r].length ? n : r : o = a[n] > a[r] ? n : r, o && (e.seals[o] += 1);
	let s = {
		kind: "roundEnd",
		reason: t,
		scores: a,
		camelWinner: i,
		winner: o
	};
	e.last = s, e.log = [...e.log, s];
	let c = e.match === "single" ? 1 : 2;
	return e.phase = o !== null && e.seals[o] >= c ? "done" : "roundEnd", e.turn = null, e.phase === "roundEnd" && (e.beatMs = oe), [
		{
			kind: "roundEnd",
			data: { ...s }
		},
		...i ? [{
			kind: "camelToken",
			rid: i
		}] : [],
		...o ? [{
			kind: "seal",
			rid: o,
			...i ? { with: !0 } : {}
		}] : []
	];
}
function U(e) {
	return C.filter((t) => e.piles[t].length === 0).length >= 3 ? ue(e, "tokens") : (ce(e), e.market.length < 5 ? ue(e, "deck") : (e.turn = V(e, e.turn), []));
}
function de(t, n, r) {
	let i = {
		match: t.match,
		players: n,
		round: 1,
		phase: "play",
		starter: n[0],
		turn: null,
		deck: [],
		market: [],
		hands: {},
		herds: {},
		piles: {
			diamond: [],
			gold: [],
			silver: [],
			cloth: [],
			spice: [],
			leather: []
		},
		bonusPiles: {
			3: [],
			4: [],
			5: []
		},
		goodsTokens: {},
		bonusTokens: {},
		camelTokenTaken: !1,
		seals: Object.fromEntries(n.map((e) => [e, 0])),
		last: null,
		log: [{
			kind: "round",
			n: 1
		}],
		beatMs: 0,
		seed: r,
		rngCursor: 0
	};
	return se(i, n[e(r, i.rngCursor++, n.length)]), {
		state: i,
		fx: [{
			kind: "roundStart",
			data: { round: 1 }
		}]
	};
}
function fe(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "roundEnd") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = t.last?.kind === "roundEnd" ? t.last : null, r = n?.winner ? V(t, n.winner) : V(t, t.starter);
		return t.round += 1, t.phase = "play", t.last = null, t.log = [...t.log, {
			kind: "round",
			n: t.round
		}], t.beatMs = 0, se(t, r), {
			state: t,
			fx: [{
				kind: "roundStart",
				data: { round: t.round }
			}]
		};
	}
	if (e.phase !== "play" || e.turn !== n.by) return { code: "games.jaipur.errNotYourTurn" };
	let r = structuredClone(e), i = n.by;
	switch (t.type) {
		case "take": {
			let e = r.market[t.index];
			if (e === void 0 || e === "camel") return { code: "games.jaipur.errBadTake" };
			if (r.hands[i].length >= 7) return { code: "games.jaipur.errHandFull" };
			r.market.splice(t.index, 1), r.hands[i] = [...r.hands[i], e];
			let n = {
				kind: "take",
				rid: i,
				card: e,
				index: t.index
			};
			return r.last = n, r.log = [...r.log, n], {
				state: r,
				fx: [{
					kind: "take",
					rid: i,
					data: {
						card: e,
						index: t.index
					}
				}, ...U(r)]
			};
		}
		case "takeCamels": {
			let e = r.market.map((e, t) => e === "camel" ? t : -1).filter((e) => e >= 0);
			if (e.length === 0) return { code: "games.jaipur.errNoCamels" };
			r.market = r.market.filter((e) => e !== "camel"), r.herds[i] += e.length;
			let t = {
				kind: "takeCamels",
				rid: i,
				count: e.length
			};
			return r.last = t, r.log = [...r.log, t], {
				state: r,
				fx: [{
					kind: "takeCamels",
					rid: i,
					data: {
						count: e.length,
						indices: e
					}
				}, ...U(r)]
			};
		}
		case "exchange": {
			let e = t.take;
			if (new Set(e).size !== e.length || e.some((e) => e >= r.market.length)) return { code: "games.jaipur.errBadExchange" };
			let n = e.map((e) => r.market[e]);
			if (n.includes("camel") || t.giveGoods.length + t.giveCamels !== e.length || t.giveCamels > r.herds[i]) return { code: "games.jaipur.errBadExchange" };
			let a = new Set(n);
			if (t.giveGoods.some((e) => a.has(e))) return { code: "games.jaipur.errExchangeOverlap" };
			let o = [...r.hands[i]];
			for (let e of t.giveGoods) {
				let t = o.indexOf(e);
				if (t < 0) return { code: "games.jaipur.errBadExchange" };
				o.splice(t, 1);
			}
			if (o.length + n.length > 7) return { code: "games.jaipur.errHandFull" };
			r.market = r.market.filter((t, n) => !e.includes(n)).concat([...t.giveGoods, ...Array(t.giveCamels).fill("camel")]), r.hands[i] = [...o, ...n], r.herds[i] -= t.giveCamels;
			let s = {
				kind: "exchange",
				rid: i,
				take: n,
				giveGoods: t.giveGoods,
				giveCamels: t.giveCamels
			};
			return r.last = s, r.log = [...r.log, s], {
				state: r,
				fx: [{
					kind: "exchange",
					rid: i,
					data: {
						take: n,
						takeIndices: e,
						giveGoods: t.giveGoods,
						giveCamels: t.giveCamels
					}
				}, ...U(r)]
			};
		}
		case "sell": {
			if (r.hands[i].filter((e) => e === t.good).length < t.count) return { code: "games.jaipur.errBadSell" };
			if (t.count < D[t.good]) return { code: "games.jaipur.errSellMin" };
			let e = [...r.hands[i]];
			for (let n = 0; n < t.count; n += 1) e.splice(e.indexOf(t.good), 1);
			r.hands[i] = e;
			let n = r.piles[t.good].splice(0, Math.min(t.count, r.piles[t.good].length));
			r.goodsTokens[i] = [...r.goodsTokens[i], ...n.map((e) => ({
				good: t.good,
				value: e
			}))];
			let a = null;
			if (t.count >= 3) {
				let e = t.count >= 5 ? 5 : t.count >= 4 ? 4 : 3, n = r.bonusPiles[e].pop();
				n !== void 0 && (a = e, r.bonusTokens[i] = [...r.bonusTokens[i], {
					tier: e,
					value: n
				}]);
			}
			let o = {
				kind: "sell",
				rid: i,
				good: t.good,
				count: t.count,
				tokens: n,
				bonusTier: a
			};
			return r.last = o, r.log = [...r.log, o], {
				state: r,
				fx: [
					{
						kind: "sell",
						rid: i,
						data: {
							good: t.good,
							count: t.count,
							tokens: n,
							bonusTier: a
						}
					},
					...a === null ? [] : [{
						kind: "sellBonus",
						rid: i,
						for: [i],
						secret: {
							tier: a,
							value: r.bonusTokens[i][r.bonusTokens[i].length - 1].value
						}
					}],
					...U(r)
				]
			};
		}
		default: return { code: "games.jaipur.errNotYourTurn" };
	}
}
function pe(e, t) {
	let n = e.phase !== "play";
	return {
		public: {
			match: e.match,
			round: e.round,
			phase: e.phase,
			turn: e.turn,
			market: e.market,
			deckCount: e.deck.length,
			piles: e.piles,
			bonusPiles: {
				b3: e.bonusPiles[3].length,
				b4: e.bonusPiles[4].length,
				b5: e.bonusPiles[5].length
			},
			camelTokenLive: !e.camelTokenTaken,
			players: e.players.map((t) => ({
				rid: t,
				herd: e.herds[t],
				handCount: e.hands[t]?.length ?? 0,
				goodsTokens: e.goodsTokens[t],
				bonusCount: e.bonusTokens[t].length,
				seals: e.seals[t]
			})),
			revealBonus: n ? { ...e.bonusTokens } : null,
			last: e.last,
			log: e.log
		},
		private: {
			hand: e.hands[t] ?? [],
			bonus: e.bonusTokens[t] ?? []
		}
	};
}
function me(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.seals[n] - e.seals[t]), n = e.seals[t[0]];
	return {
		phase: "done",
		winner: n > 0 ? t.filter((t) => e.seals[t] === n) : [],
		ranking: t,
		scores: { ...e.seals }
	};
}
function he(e) {
	return e.phase === "roundEnd" ? e.beatMs : null;
}
var ge = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: A,
	schemas: {
		action: F,
		publicView: ie,
		privateView: ae,
		config: P
	},
	setup: de,
	reduce: fe,
	viewFor: pe,
	status: me,
	nextTickIn: he
}, W = {
	diamond: "games.jaipur.good.diamond",
	gold: "games.jaipur.good.gold",
	silver: "games.jaipur.good.silver",
	cloth: "games.jaipur.good.cloth",
	spice: "games.jaipur.good.spice",
	leather: "games.jaipur.good.leather",
	camel: "games.jaipur.good.camel"
}, _e = {
	diamond: "diamond.webp",
	gold: "gold.webp",
	silver: "silver.webp",
	cloth: "cloth.webp",
	spice: "spice.webp",
	leather: "leather.webp",
	camel: "camel.webp"
};
function G({ card: e, w: t = 54, h: n = 88 }) {
	let r = O[e], a = s(), [o, c] = i(!1);
	return /* @__PURE__ */ m("span", {
		className: "jaipur-card-face",
		style: {
			width: `var(--jaipur-card-width, ${t}px)`,
			height: `var(--jaipur-card-height, ${n}px)`,
			background: r.bg,
			color: r.fg
		},
		"aria-hidden": !0,
		children: [o ? /* @__PURE__ */ p("span", {
			className: "jaipur-card-fallback",
			style: { fontSize: `var(--jaipur-card-symbol, ${n * .42}px)` },
			children: r.emoji
		}) : /* @__PURE__ */ p("img", {
			src: `./games/jaipur/${_e[e]}`,
			alt: "",
			draggable: !1,
			onError: () => c(!0)
		}), /* @__PURE__ */ p("span", {
			className: "jaipur-card-caption",
			style: { fontSize: `var(--jaipur-card-font, ${t < 50 ? 9 : 10}px)` },
			children: a(W[e])
		})]
	});
}
function K({ card: e, value: t, size: n = 34, tone: r }) {
	let i = r ?? O[e];
	return /* @__PURE__ */ p("span", {
		className: "jaipur-token grid flex-none place-items-center rounded-full border-2 border-ink font-mono font-extrabold tabular-nums",
		style: {
			width: `var(--jaipur-token-size, ${n}px)`,
			height: `var(--jaipur-token-size, ${n}px)`,
			background: i.bg,
			color: i.fg,
			fontSize: `var(--jaipur-token-font, ${n * .45}px)`
		},
		"aria-hidden": !0,
		children: t ?? "?"
	});
}
function ve(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ p(be, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var q = {
	market: [],
	camelAll: !1,
	hand: [],
	herd: 0
};
function ye(e) {
	let t = r(null);
	return n(() => {
		let n = t.current;
		if (!n || e === "done") return;
		let r = n.querySelector(".jaipur-screen"), i = n.querySelector(".game-screen-layout"), a = n.querySelector(".jaipur-bank");
		if (!r || !i) return;
		let o = window.matchMedia("(orientation: landscape)"), s = [
			"--jaipur-top",
			"--jaipur-gap",
			"--jaipur-row-gap",
			"--jaipur-bank-width",
			"--jaipur-column-gap",
			"--jaipur-hand-height",
			"--jaipur-confirm-height",
			"--jaipur-body-height",
			"--jaipur-market-height",
			"--jaipur-hand-card-height",
			"--jaipur-strip-bank-height",
			"--jaipur-bank-coin-size"
		], c = () => {
			delete n.dataset.jaipurLayout, delete n.dataset.jaipurBank;
			for (let e of s) i.style.removeProperty(e);
		}, l = (e, t) => {
			let n = `${t.toFixed(4)}px`;
			i.style.getPropertyValue(e) !== n && i.style.setProperty(e, n);
		}, u = (e, t) => {
			n.dataset[e] !== t && (n.dataset[e] = t);
		}, d = (e, t, n) => Math.min(n, Math.max(e, t)), f = (e) => {
			let t = e - 28;
			return (t - 5 * d(6, t * .012, 16)) / 5.72 * 88 / 54;
		}, p = (e, t, n) => {
			let r = e - 20, i = d(4, r * .005, 8), a = t === 2 ? 4 : 7;
			return Math.min(215, (n - (t === 2 ? 32 : 24)) / t, (r - 104 - (a - 1) * i) / a * 64 / 44);
		}, m = () => {
			let { width: e, height: t } = r.getBoundingClientRect();
			if (!o.matches || e < 960 || t < 480) {
				c();
				return;
			}
			let n = d(88, t * 2 / 15 + 24, 124), i = d(8, t / 30 - 8, 16), s = i, m = Math.max(380, e * .32), h = d(12, e / 45 - 12, 20), g = t - n - i, _ = e - m - h, v = d(112, Math.min(t * 4 / 15 - 16, t * .24), 256), y = d(56, t * .08 + 16, 88), b = g - v - y - 2 * i, x = Math.min(f(_), b - 82), S = p(_, 1, v), C = S, w = "side", T = (e - 170) / 18, E = 160 + T, D = p(e, 1, Infinity), O = D + 24, k = g - E - O - 64 - 36, A = Math.min(f(e), k - 82);
			if (T >= 40 && A >= 88 && A >= x - .5 && D >= S * 1.25) w = "strip", s = 12, b = k, y = 64, v = O, C = D;
			else {
				let e = Math.min(b, f(_) + 82), t = Math.min(y, 64), n = g - e - t - 2 * i, r = p(_, 2, n);
				r > S + .5 && r > p(_, 1, n) + .5 && (w = "split", b = e, y = t, v = n, C = r);
			}
			u("jaipurLayout", w);
			for (let [e, t] of Object.entries({
				"--jaipur-top": n,
				"--jaipur-gap": i,
				"--jaipur-row-gap": s,
				"--jaipur-bank-width": m,
				"--jaipur-column-gap": h,
				"--jaipur-hand-height": v,
				"--jaipur-confirm-height": y,
				"--jaipur-body-height": g,
				"--jaipur-market-height": b,
				"--jaipur-hand-card-height": C,
				"--jaipur-strip-bank-height": E
			})) l(e, t);
			if (!a) return;
			let j = a.getBoundingClientRect(), M = getComputedStyle(a), N = (e) => Number.parseFloat(e) || 0, P = j.width - N(M.paddingLeft) - N(M.paddingRight) - N(M.borderLeftWidth) - N(M.borderRightWidth), F = j.height - N(M.paddingTop) - N(M.paddingBottom) - N(M.borderTopWidth) - N(M.borderBottomWidth);
			if (w === "strip") u("jaipurBank", "strip"), l("--jaipur-bank-coin-size", Math.max(0, (P - 150) / 18));
			else {
				let e = Math.min((P - 82) / 6, (F - 238) / 3), t = Math.min((P - 50) / 3, (F - 272) / 6);
				u("jaipurBank", t > e ? "three" : "six"), l("--jaipur-bank-coin-size", Math.max(0, t > e ? t : e));
			}
		}, h = new ResizeObserver(m);
		return h.observe(r), a && h.observe(a), o.addEventListener("change", m), m(), () => {
			h.disconnect(), o.removeEventListener("change", m), c();
		};
	}, [e]), t;
}
function be({ pub: e, priv: t, members: n, myRid: r, send: a }) {
	let o = s(), f = ye(e.phase), h = (e) => n.find((t) => t.rid === e)?.name ?? e, g = e.players.find((e) => e.rid === r), _ = t?.hand ?? [], v = e.phase === "play" && e.turn === r, [y, b] = i(q), x = `${e.phase}|${e.turn}|${e.market.join(".")}|${_.join(".")}|${g?.herd ?? 0}`, [S, C] = i(x);
	S !== x && (C(x), b(q));
	let w = new Set(y.market.map((t) => e.market[t])), T = (t) => {
		let n = e.market[t];
		return !v || !n ? !1 : n === "camel" ? y.camelAll || y.market.length === 0 && y.hand.length === 0 : y.market.includes(t) ? !0 : !y.hand.some((e) => _[e] === n) && !y.camelAll && (y.market.length > 0 || y.hand.length === 0);
	}, E = (e) => !v || y.camelAll ? !1 : y.hand.includes(e) ? !0 : y.market.length === 1 ? !1 : y.market.length >= 2 ? !w.has(_[e]) && y.hand.length + y.herd < y.market.length : y.hand.length === 0 || _[e] === _[y.hand[0]], O = (t) => {
		if (T(t)) {
			if (e.market[t] === "camel") {
				b((e) => ({
					...q,
					camelAll: !e.camelAll
				}));
				return;
			}
			b((e) => ({
				...e,
				camelAll: !1,
				market: e.market.includes(t) ? e.market.filter((e) => e !== t) : [...e.market, t]
			}));
		}
	}, k = (e) => {
		E(e) && b((t) => ({
			...t,
			camelAll: !1,
			hand: t.hand.includes(e) ? t.hand.filter((t) => t !== e) : [...t.hand, e]
		}));
	}, j = () => {
		!v || !g || g.herd === 0 || y.market.length < 2 || b((e) => ({
			...e,
			herd: e.herd >= Math.min(g.herd, e.market.length - e.hand.length) ? 0 : e.herd + 1
		}));
	}, M = null;
	if (v) {
		if (y.camelAll) M = { kind: "takeCamels" };
		else if (y.market.length === 1 && y.hand.length === 0 && y.herd === 0) M = {
			kind: "take",
			index: y.market[0],
			ok: _.length < 7
		};
		else if (y.market.length >= 2) {
			let t = new Set(y.market.map((t) => e.market[t])), n = y.hand.some((e) => t.has(_[e])), r = y.market.length;
			M = {
				kind: "exchange",
				ok: r === y.hand.length + y.herd && !n && _.length - y.hand.length + r <= 7,
				need: r
			};
		} else if (y.market.length === 0 && y.hand.length > 0 && y.herd === 0) {
			let e = new Set(y.hand.map((e) => _[e]));
			if (e.size === 1) {
				let t = [...e][0];
				M = {
					kind: "sell",
					good: t,
					count: y.hand.length,
					ok: y.hand.length >= D[t]
				};
			}
		}
	}
	let N = () => {
		M && (M.kind === "takeCamels" ? a({ type: "takeCamels" }) : M.kind === "take" && M.ok ? a({
			type: "take",
			index: M.index
		}) : M.kind === "exchange" && M.ok ? a({
			type: "exchange",
			take: [...y.market].sort((e, t) => e - t),
			giveGoods: y.hand.map((e) => _[e]),
			giveCamels: y.herd
		}) : M.kind === "sell" && M.ok && a({
			type: "sell",
			good: M.good,
			count: M.count
		}), b(q));
	}, P = e.last?.kind === "roundEnd" ? e.last : null, F = "info", I = "", L;
	e.phase === "roundEnd" && P ? (F = "done", I = P.winner ? o("games.jaipur.roundWin", { name: h(P.winner) }) : o("games.jaipur.roundTie"), L = o(P.reason === "tokens" ? "games.jaipur.endTokens" : "games.jaipur.endDeck")) : v ? (F = "accent", I = o("games.jaipur.turnYou")) : e.phase === "play" && e.turn && (I = o("games.jaipur.turnWait", { name: h(e.turn) }));
	let R = e.match === "bestOf3" ? o("games.jaipur.roundChip", { n: e.round }) : void 0, z = /* @__PURE__ */ new Set();
	y.market.forEach((t) => {
		let n = e.market[t];
		n && n !== "camel" && z.add(n);
	}), y.hand.forEach((e) => z.add(_[e]));
	let B = "";
	if (M?.kind === "takeCamels") B = o("games.jaipur.takeCamelsN", { n: e.market.filter((e) => e === "camel").length });
	else if (M?.kind === "take") B = M.ok ? o("games.jaipur.takeOne", { good: o(W[e.market[M.index]]) }) : o("games.jaipur.handFullErr");
	else if (M?.kind === "exchange") {
		let e = y.hand.length + y.herd;
		B = e === M.need ? M.ok ? o("games.jaipur.exchangeReady", {
			n: M.need,
			g: y.hand.length,
			c: y.herd
		}) : o("games.jaipur.handFullErr") : o("games.jaipur.exchangeNeed", { n: M.need - e });
	} else M?.kind === "sell" && (B = M.ok ? o("games.jaipur.sellN", {
		n: M.count,
		good: o(W[M.good])
	}) : o("games.jaipur.sellMinErr", { good: o(W[M.good]) }));
	return /* @__PURE__ */ p("div", {
		ref: f,
		className: "jaipur-view h-full min-h-0",
		"data-phase": e.phase,
		style: { "--jaipur-accent": A.accent },
		children: /* @__PURE__ */ p(l, {
			adaptive: !0,
			className: "jaipur-screen",
			scroll: !1,
			actionsHeight: "h-[154px] short:h-[90px]",
			banner: /* @__PURE__ */ m("div", {
				className: "jaipur-banner flex flex-col gap-2 short:flex-row short:items-center short:pr-12",
				children: [/* @__PURE__ */ p("div", {
					className: "jaipur-phase short:min-w-0 short:flex-1",
					children: /* @__PURE__ */ p(u, {
						tone: F,
						text: I,
						sub: L,
						chip: R,
						accent: A.accent
					})
				}), /* @__PURE__ */ p("div", {
					className: "jaipur-players short:w-[340px] short:flex-none",
					children: /* @__PURE__ */ p(d, {
						variant: "plate",
						members: n,
						myRid: r,
						anchorOf: (e) => `seat:${e}`,
						action: (t) => e.phase === "play" && t === e.turn ? "pending" : null,
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							if (!n) return null;
							let r = n.goodsTokens.reduce((e, t) => e + t.value, 0), i = (e, t, n) => /* @__PURE__ */ m("span", {
								className: "flex items-center gap-px",
								children: [/* @__PURE__ */ p("span", {
									"aria-hidden": !0,
									className: "text-[10px]",
									children: e
								}), t]
							}, n);
							return /* @__PURE__ */ m("span", {
								className: "jaipur-player-counts flex w-full flex-nowrap items-center justify-between gap-0.5 font-mono text-sm leading-4.5 font-extrabold tabular-nums whitespace-nowrap",
								children: [
									i("🃏", n.handCount, "h"),
									i("🐪", n.herd, "c"),
									i("🪙", r, "g"),
									n.bonusCount > 0 && i("🎁", n.bonusCount, "b"),
									i("🏅", n.seals, "s")
								]
							});
						}
					})
				})]
			}),
			overlay: M && /* @__PURE__ */ m("div", {
				className: "jaipur-confirm pointer-events-auto mx-2 mb-2 flex min-h-12 items-center gap-2 plate px-2 py-1.5",
				children: [
					/* @__PURE__ */ p("span", {
						className: "min-w-0 flex-1 text-xs leading-4 font-extrabold",
						role: "status",
						children: B
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet min-h-11 flex-none px-2 text-xs",
						onClick: () => b(q),
						children: o("games.jaipur.cancel")
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						disabled: "ok" in M && !M.ok,
						className: "btn-base min-h-11 flex-none px-3 text-xs text-white disabled:opacity-40",
						style: { background: A.accent },
						onClick: N,
						children: M.kind === "takeCamels" ? o("games.jaipur.takeCamels") : M.kind === "take" ? o("games.jaipur.take") : M.kind === "exchange" ? o("games.jaipur.exchange") : o("games.jaipur.sell")
					})
				]
			}),
			actions: /* @__PURE__ */ m("div", {
				className: "jaipur-hand-tray flex h-full min-h-0 flex-col gap-1 px-2 py-1 short:flex-row short:items-center short:gap-3",
				children: [
					/* @__PURE__ */ m("div", {
						className: "jaipur-herd-area flex h-11 flex-none items-center gap-2 short:h-full",
						children: [
							/* @__PURE__ */ p("span", {
								className: "section-label flex-none",
								children: o("games.jaipur.herd")
							}),
							/* @__PURE__ */ p(De, {
								count: g?.herd ?? 0,
								giving: y.herd,
								disabled: !v || y.market.length < 2 || y.hand.length >= y.market.length,
								onPick: j
							}),
							y.herd > 0 && /* @__PURE__ */ p("span", {
								className: "jaipur-herd-giving text-xs font-extrabold",
								style: { color: A.accent },
								children: o("games.jaipur.giveCamels", { n: y.herd })
							})
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "jaipur-hand-heading flex h-4 flex-none items-center justify-between short:hidden",
						children: [/* @__PURE__ */ p("span", {
							className: "section-label",
							children: o("games.jaipur.handTitle")
						}), /* @__PURE__ */ p("span", {
							className: "font-mono text-xs font-bold tabular-nums text-ink/65",
							children: o("games.jaipur.handCount", { n: _.length })
						})]
					}),
					/* @__PURE__ */ m("div", {
						className: "jaipur-hand-cards flex min-h-0 flex-1 items-start justify-center gap-1 overflow-x-auto pt-2 short:h-full short:items-center short:justify-start short:pt-0",
						children: [_.map((e, t) => /* @__PURE__ */ p("button", {
							type: "button",
							"aria-label": o(W[e]),
							"aria-pressed": y.hand.includes(t),
							disabled: !E(t),
							onClick: () => k(t),
							className: `jaipur-pick jaipur-hand-card ${y.hand.includes(t) ? "jaipur-pick--selected" : ""} ${v ? "" : "jaipur-pick--waiting"}`,
							children: /* @__PURE__ */ p(G, {
								card: e,
								w: 44,
								h: 64
							})
						}, `${e}${t}`)), _.length === 0 && /* @__PURE__ */ p("span", {
							className: "text-sm font-bold text-ink/60",
							children: o("games.jaipur.emptyHand")
						})]
					})
				]
			}),
			children: /* @__PURE__ */ m("div", {
				className: "jaipur-board relative h-full overflow-hidden rounded-2xl border-2 border-ink",
				children: [/* @__PURE__ */ p(c, {
					kind: "sheen",
					base: "var(--color-paper)",
					className: "absolute inset-0"
				}), /* @__PURE__ */ p("div", {
					className: "jaipur-board-scroll relative h-full overflow-y-auto p-2.5 pb-18",
					children: e.phase === "roundEnd" && P ? /* @__PURE__ */ p(Oe, {
						pub: e,
						end: P,
						nameOf: h
					}) : /* @__PURE__ */ m("div", {
						className: "jaipur-table flex min-h-full flex-col gap-3",
						children: [
							/* @__PURE__ */ m("div", {
								className: "jaipur-board-heading flex flex-none items-center justify-between gap-2",
								children: [/* @__PURE__ */ p("span", {
									className: "font-display text-base font-extrabold",
									children: o("games.jaipur.marketTitle")
								}), /* @__PURE__ */ p("span", {
									className: "text-[10px] font-extrabold tracking-widest",
									"aria-hidden": !0,
									children: o("games.jaipur.brand")
								})]
							}),
							/* @__PURE__ */ p(xe, {
								pub: e,
								sel: y,
								myTurn: v,
								pickable: T,
								onPick: O
							}),
							/* @__PURE__ */ p(we, {
								pub: e,
								focusGoods: z,
								selling: M?.kind === "sell" ? {
									good: M.good,
									count: M.count
								} : null
							})
						]
					})
				})]
			})
		})
	});
}
function xe({ pub: e, sel: t, myTurn: n, pickable: r, onPick: i }) {
	let o = s(), { ref: c } = a("market");
	return /* @__PURE__ */ m("div", {
		className: "jaipur-market-shelf flex-none",
		children: [/* @__PURE__ */ m("div", {
			className: "jaipur-market-row flex items-end justify-center gap-1.5",
			children: [/* @__PURE__ */ p(Ce, {
				count: e.deckCount,
				label: o("games.jaipur.deckAria", { n: e.deckCount })
			}), /* @__PURE__ */ p("div", {
				ref: c,
				className: "jaipur-market-cards flex items-end gap-1",
				children: [
					0,
					1,
					2,
					3,
					4
				].map((a) => /* @__PURE__ */ p(Se, {
					index: a,
					card: e.market[a] ?? null,
					picked: e.market[a] === "camel" ? t.camelAll : t.market.includes(a),
					pickable: r(a),
					waiting: !n,
					onPick: () => i(a)
				}, a))
			})]
		}), /* @__PURE__ */ p("p", {
			className: "jaipur-market-hint h-4 truncate text-center text-xs font-bold text-ink/70",
			children: t.market.length > 0 ? o("games.jaipur.marketSelected", { n: t.market.length }) : n ? t.hand.length > 0 ? o("games.jaipur.marketSellHint") : o("games.jaipur.marketHint") : o("games.jaipur.marketWaitHint")
		})]
	});
}
function Se({ index: e, card: t, picked: n, pickable: r, waiting: i, onPick: o }) {
	let c = s(), { ref: l } = a(`mslot:${e}`);
	return t ? /* @__PURE__ */ p("span", {
		ref: l,
		className: "inline-flex",
		children: /* @__PURE__ */ m("button", {
			type: "button",
			"aria-label": c(W[t]),
			"aria-pressed": n,
			disabled: !r,
			onClick: o,
			className: `jaipur-pick jaipur-market-card ${n ? "jaipur-pick--selected" : ""} ${i ? "jaipur-pick--waiting" : ""}`,
			children: [/* @__PURE__ */ p(G, { card: t }), n && /* @__PURE__ */ p("span", {
				className: "jaipur-pick-check",
				"aria-hidden": !0,
				children: "✓"
			})]
		})
	}) : /* @__PURE__ */ p("span", {
		ref: l,
		className: "jaipur-empty-slot grid flex-none place-items-center text-center text-xs font-bold text-ink/50",
		style: {
			width: "var(--jaipur-card-width, 54px)",
			height: "var(--jaipur-card-height, 88px)"
		},
		"aria-hidden": !0,
		children: c("games.jaipur.refillSlot")
	});
}
function Ce({ count: e, label: t }) {
	let { ref: n } = a("deck");
	return /* @__PURE__ */ m("div", {
		ref: n,
		className: "jaipur-deck relative flex-none",
		"aria-label": t,
		role: "img",
		children: [/* @__PURE__ */ p("span", {
			className: "jaipur-deck-back grid place-items-center",
			"aria-hidden": !0,
			children: "🐪"
		}), /* @__PURE__ */ p("span", {
			className: "jaipur-deck-count font-mono text-[10px] font-extrabold tabular-nums",
			"aria-hidden": !0,
			children: e
		})]
	});
}
function we({ pub: e, focusGoods: t, selling: n }) {
	let r = s(), { ref: i } = a("cameltoken"), o = n ? e.piles[n.good].slice(0, n.count).reduce((e, t) => e + t, 0) : 0, c = n && n.count >= 3 ? n.count >= 5 ? 5 : n.count === 4 ? 4 : 3 : null, l = c && e.bonusPiles[`b${c}`] > 0 ? c : null;
	return /* @__PURE__ */ p("div", {
		className: "jaipur-bank flex flex-none flex-col gap-2",
		children: /* @__PURE__ */ m("div", {
			className: "jaipur-bank-content flex flex-col gap-2",
			children: [
				/* @__PURE__ */ m("div", {
					className: "jaipur-bank-heading flex h-5 items-center justify-between",
					children: [/* @__PURE__ */ p("span", {
						className: "section-label",
						children: r("games.jaipur.priceTitle")
					}), /* @__PURE__ */ p("span", {
						className: "text-xs font-bold text-ink/65",
						children: r("games.jaipur.priceHint")
					})]
				}),
				/* @__PURE__ */ p("div", {
					className: "jaipur-price-grid grid grid-cols-6 gap-0.5 rounded-xl border border-ink/35 bg-surface p-1",
					children: C.map((n) => /* @__PURE__ */ p(Te, {
						good: n,
						pile: e.piles[n],
						focused: t.has(n)
					}, n))
				}),
				/* @__PURE__ */ p("p", {
					className: "jaipur-sale-preview h-4 truncate text-xs font-bold text-ink/75",
					children: n ? r("games.jaipur.salePreview", {
						n: o,
						tier: l ? `${l}+` : "—"
					}) : ""
				}),
				/* @__PURE__ */ m("div", {
					className: "jaipur-bank-heading flex h-5 items-center justify-between",
					children: [/* @__PURE__ */ p("span", {
						className: "section-label",
						children: r("games.jaipur.rewardTitle")
					}), /* @__PURE__ */ p("span", {
						className: "text-xs font-bold text-ink/65",
						children: r("games.jaipur.rewardHint")
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: "jaipur-reward-grid grid grid-cols-4 gap-1 rounded-xl border border-ink/35 bg-surface p-1.5",
					children: [[
						3,
						4,
						5
					].map((t) => {
						let n = t === 3 ? e.bonusPiles.b3 : t === 4 ? e.bonusPiles.b4 : e.bonusPiles.b5;
						return /* @__PURE__ */ p(Ee, {
							tier: t,
							left: n
						}, t);
					}), /* @__PURE__ */ m("span", {
						className: `jaipur-reward-item flex items-center justify-center gap-1 ${e.camelTokenLive ? "" : "opacity-35"}`,
						role: "img",
						"aria-label": r("games.jaipur.camelTokenAria"),
						children: [/* @__PURE__ */ p("span", {
							ref: i,
							className: "inline-flex",
							children: /* @__PURE__ */ p(K, {
								card: "camel",
								value: 5,
								size: 31
							})
						}), /* @__PURE__ */ p("span", {
							className: "text-[10px] font-extrabold",
							children: r("games.jaipur.camelShort")
						})]
					})]
				})
			]
		})
	});
}
function Te({ good: e, pile: t, focused: n }) {
	let r = s(), { ref: i } = a(`pile:${e}`);
	return /* @__PURE__ */ m("span", {
		className: `jaipur-price-rail flex min-w-0 flex-col items-center gap-0.5 rounded-lg py-1 ${n ? "jaipur-price-rail--focus" : ""}`,
		role: "img",
		"aria-label": r("games.jaipur.pileAria", {
			good: r(W[e]),
			v: t[0] ?? 0,
			n: t.length
		}),
		children: [
			/* @__PURE__ */ p("span", {
				className: "max-w-full truncate text-[10px] font-extrabold",
				children: r(W[e])
			}),
			/* @__PURE__ */ p("span", {
				className: "jaipur-price-values flex flex-col items-center gap-0.5",
				children: t.length ? t.slice(0, 3).map((t, n) => /* @__PURE__ */ p("span", {
					ref: n === 0 ? i : void 0,
					children: /* @__PURE__ */ p(K, {
						card: e,
						value: t,
						size: 25
					})
				}, n)) : /* @__PURE__ */ p("span", {
					ref: i,
					className: "jaipur-price-empty grid place-items-center text-center text-[10px] font-bold",
					children: r("games.jaipur.soldOut")
				})
			}),
			/* @__PURE__ */ m("span", {
				className: "font-mono text-[10px] font-bold tabular-nums",
				children: ["×", t.length]
			})
		]
	});
}
function Ee({ tier: e, left: t }) {
	let n = s(), { ref: r } = a(`bonus:${e}`);
	return /* @__PURE__ */ m("span", {
		className: `jaipur-reward-item flex items-center justify-center gap-1 ${t === 0 ? "opacity-35" : ""}`,
		role: "img",
		"aria-label": n("games.jaipur.bonusAria", {
			n: e,
			c: t
		}),
		children: [/* @__PURE__ */ m("span", {
			ref: r,
			className: "jaipur-bonus-token grid size-8 flex-none place-items-center rounded-full border-2 border-ink bg-ink font-mono text-xs font-extrabold text-surface",
			"aria-hidden": !0,
			children: [e, "+"]
		}), /* @__PURE__ */ m("span", {
			className: "font-mono text-[10px] font-bold text-ink/70 tabular-nums",
			"aria-hidden": !0,
			children: ["×", t]
		})]
	});
}
function De({ count: e, giving: t, disabled: n, onPick: r }) {
	let i = s();
	return /* @__PURE__ */ m("button", {
		type: "button",
		"aria-label": i("games.jaipur.herdAria", { n: e }),
		"aria-pressed": t > 0,
		disabled: n || e === 0,
		onClick: r,
		className: `jaipur-herd-button flex min-h-11 flex-none items-center gap-1 rounded-xl border-2 border-ink px-2 font-mono text-sm font-extrabold tabular-nums ${t > 0 ? "jaipur-herd-button--selected" : ""}`,
		style: {
			background: O.camel.bg,
			color: O.camel.fg
		},
		children: [
			/* @__PURE__ */ p("span", {
				"aria-hidden": !0,
				children: "🐪"
			}),
			" ×",
			e
		]
	});
}
function Oe({ pub: e, end: t, nameOf: i }) {
	let a = s(), o = r(null), c = e.players.map((n) => `${n.goodsTokens.length},${e.revealBonus?.[n.rid]?.length ?? 0},${+(t.camelWinner === n.rid)}`).join("|");
	return n(() => {
		let e = [...o.current?.querySelectorAll(".jaipur-ledger-bag") ?? []], t = () => {
			for (let t of e) {
				if (getComputedStyle(t).getPropertyValue("--jaipur-ledger-wide").trim() !== "1") {
					t.style.removeProperty("--jaipur-ledger-size");
					continue;
				}
				let e = (t.dataset.jaipurCounts ?? "").split(",").map(Number), n = 44;
				for (let r = Math.min(120, t.clientWidth); r >= 44; r--) {
					let i = Math.max(1, Math.floor((t.clientWidth + 6) / (r + 6)));
					if (104 + e.map((e) => Math.max(1, Math.ceil(e / i))).reduce((e, t) => e + t * r + (t - 1) * 6, 0) <= t.clientHeight) {
						n = r;
						break;
					}
				}
				let r = `${n}px`;
				t.style.getPropertyValue("--jaipur-ledger-size") !== r && t.style.setProperty("--jaipur-ledger-size", r);
			}
		}, n = new ResizeObserver(t);
		for (let t of e) n.observe(t);
		return t(), () => n.disconnect();
	}, [c]), /* @__PURE__ */ m("div", {
		ref: o,
		className: "jaipur-ledger",
		children: [
			/* @__PURE__ */ m("header", {
				className: "jaipur-ledger-heading",
				children: [/* @__PURE__ */ p("h2", { children: a("games.jaipur.ledgerRound", { n: e.round }) }), /* @__PURE__ */ p("span", { children: a(t.reason === "tokens" ? "games.jaipur.endTokens" : "games.jaipur.endDeck") })]
			}),
			/* @__PURE__ */ p("p", {
				className: "jaipur-ledger-camel",
				children: t.camelWinner ? a("games.jaipur.camelBonus", { name: i(t.camelWinner) }) : a("games.jaipur.camelTie")
			}),
			/* @__PURE__ */ p("div", {
				className: "jaipur-ledger-players",
				children: e.players.map((n) => {
					let r = e.revealBonus?.[n.rid] ?? [], o = t.camelWinner === n.rid ? 5 : 0, s = n.goodsTokens.reduce((e, t) => e + t.value, 0), c = r.reduce((e, t) => e + t.value, 0);
					return /* @__PURE__ */ m("section", {
						className: `jaipur-ledger-player ${t.winner === n.rid ? "jaipur-ledger-player--winner" : ""}`,
						"data-jaipur-total": t.scores[n.rid] ?? 0,
						"data-jaipur-computed": s + c + o,
						children: [/* @__PURE__ */ m("header", {
							className: "jaipur-ledger-person",
							children: [/* @__PURE__ */ m("strong", {
								title: i(n.rid),
								children: [i(n.rid), t.winner === n.rid && /* @__PURE__ */ p("span", {
									className: "jaipur-ledger-seal",
									"aria-label": a("games.jaipur.roundWinnerMark"),
									children: "🏅"
								})]
							}), /* @__PURE__ */ p("b", {
								className: "font-mono tabular-nums",
								children: a("games.jaipur.scoreTotal", { n: t.scores[n.rid] ?? 0 })
							})]
						}), /* @__PURE__ */ m("div", {
							className: "jaipur-ledger-bag",
							"data-jaipur-counts": `${n.goodsTokens.length},${r.length},${+!!o}`,
							children: [
								/* @__PURE__ */ m("section", {
									className: "jaipur-ledger-group",
									children: [/* @__PURE__ */ m("header", { children: [/* @__PURE__ */ p("h3", { children: a("games.jaipur.ledgerGoods") }), /* @__PURE__ */ p("b", {
										className: "font-mono tabular-nums",
										children: a("games.jaipur.scoreTotal", { n: s })
									})] }), /* @__PURE__ */ m("div", {
										className: "jaipur-ledger-coins",
										children: [n.goodsTokens.map((e, t) => /* @__PURE__ */ p("span", {
											className: "jaipur-ledger-token",
											role: "img",
											"aria-label": a("games.jaipur.ledgerGoodsToken", {
												good: a(W[e.good]),
												n: e.value
											}),
											children: /* @__PURE__ */ p(K, {
												card: e.good,
												value: e.value,
												size: 28
											})
										}, `${e.good}${t}`)), !n.goodsTokens.length && /* @__PURE__ */ p("span", {
											className: "jaipur-ledger-empty",
											children: "—"
										})]
									})]
								}),
								/* @__PURE__ */ m("section", {
									className: "jaipur-ledger-group",
									children: [/* @__PURE__ */ m("header", { children: [/* @__PURE__ */ p("h3", { children: a("games.jaipur.ledgerBonus") }), /* @__PURE__ */ p("b", {
										className: "font-mono tabular-nums",
										children: a("games.jaipur.scoreTotal", { n: c })
									})] }), /* @__PURE__ */ m("div", {
										className: "jaipur-ledger-coins",
										children: [r.map((e, t) => /* @__PURE__ */ m("span", {
											className: "jaipur-ledger-token",
											role: "img",
											"aria-label": a("games.jaipur.ledgerBonusToken", {
												tier: e.tier,
												n: e.value
											}),
											children: [/* @__PURE__ */ p(K, {
												card: "gold",
												value: e.value,
												size: 28,
												tone: {
													bg: "var(--color-ink)",
													fg: "var(--color-surface)"
												}
											}), /* @__PURE__ */ m("small", {
												className: "jaipur-ledger-tier",
												"aria-hidden": !0,
												children: [e.tier, "+"]
											})]
										}, `b${t}`)), !r.length && /* @__PURE__ */ p("span", {
											className: "jaipur-ledger-empty",
											children: "—"
										})]
									})]
								}),
								/* @__PURE__ */ m("section", {
									className: "jaipur-ledger-group",
									children: [/* @__PURE__ */ m("header", { children: [/* @__PURE__ */ p("h3", { children: a("games.jaipur.ledgerCamel") }), /* @__PURE__ */ p("b", {
										className: "font-mono tabular-nums",
										children: a("games.jaipur.scoreTotal", { n: o })
									})] }), /* @__PURE__ */ p("div", {
										className: "jaipur-ledger-coins",
										children: o ? /* @__PURE__ */ p("span", {
											className: "jaipur-ledger-token",
											role: "img",
											"aria-label": a("games.jaipur.camelTokenAria"),
											children: /* @__PURE__ */ p(K, {
												card: "camel",
												value: 5,
												size: 28
											})
										}) : /* @__PURE__ */ p("span", {
											className: "jaipur-ledger-empty",
											children: "—"
										})
									})]
								})
							]
						})]
					}, n.rid);
				})
			})
		]
	});
}
//#endregion
//#region src/games/jaipur/bot.ts
var ke = {
	3: 2,
	4: 5,
	5: 9.2
}, Ae = {
	camelValue: 2,
	bonusW: 1,
	pairOddFactor: .5,
	bigSaleW: .4,
	hurryW: .5
};
function J(e, t) {
	return e.piles[t][0] ?? 0;
}
function je(e, t, n, r) {
	let i = e.piles[t].slice(0, n).reduce((e, t) => e + t, 0);
	if (n >= 3) {
		let e = n >= 5 ? 5 : n >= 4 ? 4 : 3;
		i += r.bonusW * ke[e];
	}
	return i += r.bigSaleW * Math.max(0, n - 2), i;
}
function Me(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function Ne(e, t, n) {
	let r = e.public, i = e.private?.hand ?? [], a = r.players.find((e) => e.rid === t.rid);
	if (!a) return [];
	let o = [], s = C.filter((e) => r.piles[e].length === 0).length >= 2 ? 1 + n.hurryW : 1, c = {
		diamond: 0,
		gold: 0,
		silver: 0,
		cloth: 0,
		spice: 0,
		leather: 0
	};
	for (let e of i) c[e] += 1;
	for (let e of C) c[e] >= D[e] && o.push({
		action: {
			type: "sell",
			good: e,
			count: c[e]
		},
		score: je(r, e, c[e], n) * s
	});
	i.length < 7 && r.market.forEach((e, t) => {
		if (e === "camel") return;
		let i = c[e] % 2 == 1 || c[e] + 1 >= D[e] ? 1 : n.pairOddFactor;
		o.push({
			action: {
				type: "take",
				index: t
			},
			score: J(r, e) * i
		});
	});
	let l = r.market.filter((e) => e === "camel").length;
	l > 0 && o.push({
		action: { type: "takeCamels" },
		score: l * n.camelValue
	});
	let u = r.market.map((e, t) => ({
		c: e,
		index: t
	})).filter((e) => e.c !== "camel").sort((e, t) => J(r, t.c) - J(r, e.c)), d = [...i].sort((e, t) => J(r, e) - J(r, t));
	for (let e = 2; e <= Math.min(4, u.length); e += 1) {
		let t = u.slice(0, e), s = new Set(t.map((e) => e.c)), c = [];
		for (let t of d) {
			if (c.length >= e) break;
			s.has(t) || c.push(t);
		}
		let l = e - c.length;
		if (l > a.herd || i.length - c.length + e > 7) continue;
		let f = t.reduce((e, t) => e + J(r, t.c), 0), p = c.reduce((e, t) => e + J(r, t), 0) + l * n.camelValue;
		o.push({
			action: {
				type: "exchange",
				take: t.map((e) => e.index).sort((e, t) => e - t),
				giveGoods: c,
				giveCamels: l
			},
			score: f - p
		});
	}
	return o;
}
function Pe(e = Ae) {
	return (t, n) => {
		let r = t.public;
		if (r.phase !== "play" || r.turn !== n.rid) return null;
		let i = Ne(t, n, e);
		if (i.length === 0) return null;
		if (n.difficulty === "weak") return { action: Me(i).action };
		let a = i[0];
		for (let e of i) e.score > a.score && (a = e);
		return { action: a.action };
	};
}
var Fe = Pe(), Ie = {
	diamond: "games.jaipur.good.diamond",
	gold: "games.jaipur.good.gold",
	silver: "games.jaipur.good.silver",
	cloth: "games.jaipur.good.cloth",
	spice: "games.jaipur.good.spice",
	leather: "games.jaipur.good.leather"
}, Le = (e, t, n) => {
	if (e.type === "take") {
		let r = t.public.market[e.index];
		return !r || r === "camel" ? "" : n("games.jaipur.takeOne", { good: n(Ie[r]) });
	}
	return e.type === "takeCamels" ? n("games.jaipur.takeCamelsN", { n: t.public.market.filter((e) => e === "camel").length }) : e.type === "exchange" ? n("games.jaipur.exchangeN", { n: e.take.length }) : e.type === "sell" ? n("games.jaipur.sellN", {
		n: e.count,
		good: n(Ie[e.good])
	}) : "";
}, Y = {
	diamond: "钻石",
	gold: "黄金",
	silver: "白银",
	cloth: "布料",
	spice: "香料",
	leather: "皮革",
	camel: "骆驼"
}, Re = {
	needsAction: (e, t) => e.public.phase === "play" && e.public.turn === t.rid,
	describeView(e, t) {
		let n = e.public, r = [
			"规则:每回合四选一——take(拿市场 1 张货入牌)/takeCamels(拿市场全部骆驼进驼群)/exchange(用 ≥2 张货和/或骆驼换市场等量货)/sell(卖同一种货:钻/金/银至少 2 张,布/香料/皮革至少 1 张,按张数拿代币堆顶面值,卖 3/4/5 张以上另抽奖励代币)。手牌上限 7(骆驼不占)。三种货代币堆售罄或牌堆补不满市场时回合结算,代币总值高者拿卓越印章。",
			`市场: ${n.market.map((e, t) => `${t}:${e}(${Y[e]})`).join(" ")};牌堆剩 ${n.deckCount}`,
			`代币堆(栈顶先拿): ${Object.entries(n.piles).map(([e, t]) => `${e}(${Y[e]}):[${t.join(",")}]`).join(" ")}`,
			`奖励池: 3张档×${n.bonusPiles.b3}, 4张档×${n.bonusPiles.b4}, 5张档×${n.bonusPiles.b5};骆驼代币(+5)${n.camelTokenLive ? "还在" : "已被拿"}`
		];
		for (let e of n.players) {
			let n = e.rid === t.rid ? "你" : e.rid, i = e.goodsTokens.reduce((e, t) => e + t.value, 0);
			r.push(`${n}: 手牌 ${e.handCount} 张,驼群 ${e.herd},已拿代币面值和 ${i}(${e.goodsTokens.map((e) => `${Y[e.good]}${e.value}`).join(",") || "无"}),奖励代币 ${e.bonusCount} 张,印章 ${e.seals}`);
		}
		return r.push(`你的手牌: ${(e.private?.hand ?? []).map((e) => `${e}(${Y[e]})`).join(", ") || "(空)"}。轮到你行动。`), r.join("\n");
	},
	actionJsonSchema: { oneOf: [
		{
			type: "object",
			properties: {
				type: { const: "take" },
				index: {
					type: "integer",
					minimum: 0,
					description: "市场下标,不能指骆驼"
				}
			},
			required: ["type", "index"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "takeCamels" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "exchange" },
				take: {
					type: "array",
					items: {
						type: "integer",
						minimum: 0
					},
					minItems: 2,
					description: "市场下标数组(非骆驼)"
				},
				giveGoods: {
					type: "array",
					items: { enum: [
						"diamond",
						"gold",
						"silver",
						"cloth",
						"spice",
						"leather"
					] }
				},
				giveCamels: {
					type: "integer",
					minimum: 0
				}
			},
			required: [
				"type",
				"take",
				"giveGoods",
				"giveCamels"
			],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "sell" },
				good: { enum: [
					"diamond",
					"gold",
					"silver",
					"cloth",
					"spice",
					"leather"
				] },
				count: {
					type: "integer",
					minimum: 1
				}
			},
			required: [
				"type",
				"good",
				"count"
			],
			additionalProperties: !1
		}
	] },
	parseAction(e, t, n) {
		let r = F.safeParse(e);
		if (!r.success) return null;
		let i = r.data;
		if (i.type === "tick") return null;
		let a = t.public;
		if (a.phase !== "play" || a.turn !== n.rid) return null;
		let o = t.private?.hand ?? [], s = a.players.find((e) => e.rid === n.rid);
		if (!s) return null;
		switch (i.type) {
			case "take": return i.index < a.market.length && a.market[i.index] !== "camel" && o.length < 7 ? i : null;
			case "takeCamels": return a.market.includes("camel") ? i : null;
			case "exchange": {
				let e = [...new Set(i.take)];
				if (e.length !== i.take.length || e.some((e) => e >= a.market.length || a.market[e] === "camel") || i.giveGoods.length + i.giveCamels !== i.take.length || i.giveCamels > s.herd) return null;
				let t = [...o];
				for (let e of i.giveGoods) {
					let n = t.indexOf(e);
					if (n < 0) return null;
					t.splice(n, 1);
				}
				return t.length + i.take.length > 7 ? null : i;
			}
			case "sell": {
				if (o.filter((e) => e === i.good).length < i.count) return null;
				let e = i.good === "diamond" || i.good === "gold" || i.good === "silver" ? 2 : 1;
				return i.count >= e ? i : null;
			}
		}
	}
};
//#endregion
//#region src/games/jaipur/fx.tsx
function X(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function Z(e, t) {
	return e.anchor(`mslot:${t}`);
}
function Q(e) {
	let t = Math.min(e.w, e.h);
	return {
		...e,
		w: t,
		h: t
	};
}
function ze(e, t) {
	let n = Math.min(e.h, e.w * t.h / t.w), r = n * t.w / t.h;
	return {
		x: e.x + (e.w - r) / 2,
		y: e.y + (e.h - n) / 2,
		w: r,
		h: n
	};
}
function $({ card: e, box: t, target: n = t }) {
	let r = n.w > 0 ? t.w / n.w : 1, i = n.w > 55, a = i ? Math.min(32, Math.max(20, n.w * .18)) : 17, o = i ? Math.min(22, Math.max(13, n.w * .12)) : 10;
	return /* @__PURE__ */ p("span", {
		style: {
			display: "block",
			width: t.w,
			height: t.h,
			"--jaipur-card-width": `${t.w}px`,
			"--jaipur-card-height": `${t.h}px`,
			"--jaipur-card-font": `${o * r}px`,
			"--jaipur-caption-height": `${a * r}px`,
			"--jaipur-card-symbol": `${t.h * .42}px`,
			"--jaipur-card-border-width": `${2 * r}px`,
			"--jaipur-card-radius": `${5 * r}px`,
			"--jaipur-caption-border-width": `${r}px`
		},
		children: /* @__PURE__ */ p(G, {
			card: e,
			w: t.w,
			h: t.h
		})
	});
}
function Be({ card: e, value: t, box: n, bonus: r = !1 }) {
	return /* @__PURE__ */ p("span", {
		style: {
			display: "block",
			width: n.w,
			height: n.h,
			"--jaipur-token-size": `${n.w}px`,
			"--jaipur-token-font": `${n.w * .45}px`
		},
		children: /* @__PURE__ */ p(K, {
			card: e,
			value: t,
			size: n.w,
			tone: r ? {
				bg: "var(--color-ink)",
				fg: "var(--color-surface)"
			} : void 0
		})
	});
}
function Ve(e) {
	return Math.min(32, Math.max(14, e.w * .6));
}
function He(e) {
	return Array.isArray(e) ? e.filter((e) => typeof e == "string") : [];
}
var Ue = {
	take(e, t) {
		let n = e.data, r = X(t, e.rid);
		if (typeof n?.card != "string" || typeof n.index != "number" || !r) return null;
		let i = Z(t, n.index);
		return i ? {
			ms: 450,
			node: /* @__PURE__ */ p(g, {
				from: i,
				to: r,
				ms: 380,
				children: /* @__PURE__ */ p($, {
					card: n.card,
					box: i
				})
			})
		} : null;
	},
	takeCamels(e, t) {
		let n = e.data, r = X(t, e.rid), i = Array.isArray(n?.indices) ? n.indices.filter((e) => typeof e == "number") : [];
		if (!i.length || !r) return null;
		let a = i.map((e, n) => {
			let i = Z(t, e);
			return i ? /* @__PURE__ */ p(g, {
				from: i,
				to: r,
				ms: 360,
				delay: n * 90,
				children: /* @__PURE__ */ p($, {
					card: "camel",
					box: i
				})
			}, e) : null;
		}).filter(Boolean);
		return a.length ? {
			ms: 360 + i.length * 90,
			node: a
		} : null;
	},
	exchange(e, t) {
		let n = e.data, r = X(t, e.rid);
		if (!n || !r) return null;
		let i = He(n.take), a = Array.isArray(n.takeIndices) ? n.takeIndices.filter((e) => typeof e == "number") : [], o = He(n.giveGoods), s = typeof n.giveCamels == "number" ? n.giveCamels : 0, c = [];
		i.forEach((e, n) => {
			let i = Z(t, a[n] ?? n);
			i && c.push(/* @__PURE__ */ p(g, {
				from: i,
				to: r,
				ms: 380,
				delay: n * 60,
				children: /* @__PURE__ */ p($, {
					card: e,
					box: i
				})
			}, `t${n}`));
		});
		let l = [...o, ...Array(s).fill("camel")];
		return l.forEach((e, n) => {
			let a = t.anchor(`mslot:${5 - l.length + n}`);
			if (!a) return;
			let o = ze(r, a);
			c.push(/* @__PURE__ */ p(g, {
				from: o,
				to: a,
				ms: 380,
				delay: i.length * 60 + n * 60,
				children: /* @__PURE__ */ p($, {
					card: e,
					box: o,
					target: a
				})
			}, `g${n}`));
		}), c.length ? {
			ms: 380 + (i.length + l.length) * 60,
			node: c
		} : null;
	},
	sell(e, t) {
		let n = e.data, r = X(t, e.rid);
		if (typeof n?.good != "string" || !r) return null;
		let i = n.good, a = Array.isArray(n.tokens) ? n.tokens.filter((e) => typeof e == "number") : [], o = t.anchor(`pile:${i}`), s = o ? Q(o) : null, c = [];
		s && a.forEach((e, t) => {
			c.push(/* @__PURE__ */ p(g, {
				from: s,
				to: r,
				ms: 360,
				delay: t * 80,
				children: /* @__PURE__ */ p(Be, {
					card: i,
					value: e,
					box: s
				})
			}, `t${t}`));
		});
		let l = typeof n.bonusTier == "number" ? n.bonusTier : null, u = l ? t.anchor(`bonus:${l}`) : null, d = u ? Q(u) : null;
		return l && d && c.push(/* @__PURE__ */ p(g, {
			from: d,
			to: r,
			ms: 360,
			delay: a.length * 80,
			children: /* @__PURE__ */ p(Be, {
				card: "gold",
				value: null,
				box: d,
				bonus: !0
			})
		}, "bonus")), c.length ? {
			ms: 360 + a.length * 80 + (l ? 200 : 0),
			node: c
		} : null;
	},
	camelToken(e, t) {
		let n = X(t, e.rid), r = t.anchor("cameltoken"), i = r ? Q(r) : null;
		return !n || !i ? null : {
			ms: 800,
			node: [/* @__PURE__ */ p(g, {
				from: i,
				to: n,
				ms: 420,
				children: /* @__PURE__ */ p(Be, {
					card: "camel",
					value: 5,
					box: i
				})
			}, "camel"), /* @__PURE__ */ p(h, {
				at: n,
				ms: 800,
				delay: 380,
				children: /* @__PURE__ */ p("span", {
					style: {
						fontSize: Ve(n),
						lineHeight: 1.1
					},
					children: "+5"
				})
			}, "pts")]
		};
	},
	seal(e, t) {
		let n = X(t, e.rid);
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ p(h, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ p("span", {
					style: {
						fontSize: Ve(n),
						lineHeight: 1.1
					},
					children: "🏅+1"
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/jaipur/game-over.tsx
function We({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let c = t, u = s(), d = o((e) => e.locale), h = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? f(t, d) : e;
	}, g = c.last?.kind === "roundEnd" ? c.last : null;
	return /* @__PURE__ */ m("div", {
		className: "jaipur-over",
		style: { "--jaipur-accent": A.accent },
		children: [e.winner.length > 0 && /* @__PURE__ */ p(b, {}), /* @__PURE__ */ p(l, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ m("header", {
				className: "jaipur-over-heading",
				children: [/* @__PURE__ */ p("h1", { children: u("games.jaipur.matchResult") }), /* @__PURE__ */ p("p", { children: e.winner.length ? u("games.jaipur.matchWinner", { name: e.winner.map(h).join(" / ") }) : u("games.jaipur.matchTie") })]
			}),
			actionsHeight: "jaipur-over-actions-height",
			actions: i || a ? /* @__PURE__ */ m("div", {
				className: "jaipur-over-actions",
				children: [i && /* @__PURE__ */ p("button", {
					type: "button",
					onClick: i,
					children: u("session.result.playAgain")
				}), a && /* @__PURE__ */ p("button", {
					type: "button",
					onClick: a,
					children: u("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ p("p", {
				className: "jaipur-over-wait",
				children: u("session.result.waitHost")
			}),
			children: /* @__PURE__ */ m("div", {
				className: "jaipur-over-main",
				"data-has-ledger": !!g,
				children: [/* @__PURE__ */ p("ol", {
					className: "jaipur-over-ranking",
					"aria-label": u("games.jaipur.matchRanking"),
					children: e.ranking.map((t) => {
						let i = n.find((e) => e.rid === t), a = e.autopilot?.[t];
						return /* @__PURE__ */ m("li", {
							"data-winner": e.winner.includes(t),
							children: [
								/* @__PURE__ */ m("div", {
									className: "jaipur-over-person",
									children: [/* @__PURE__ */ p("span", {
										className: "jaipur-over-avatar",
										style: { background: y[(i?.colorIndex ?? 0) % y.length].hex },
										children: i && /* @__PURE__ */ p("img", {
											src: _[i.avatar % _.length],
											alt: "",
											draggable: !1
										})
									}), /* @__PURE__ */ m("span", {
										className: "jaipur-over-name",
										children: [/* @__PURE__ */ p("strong", {
											title: h(t),
											children: h(t)
										}), /* @__PURE__ */ m("span", {
											className: "jaipur-over-badges",
											children: [t === r && /* @__PURE__ */ p("span", { children: u("lobby.you") }), e.winner.includes(t) && /* @__PURE__ */ p("b", { children: u("games.jaipur.matchWinnerMark") })]
										})]
									})]
								}),
								/* @__PURE__ */ m("div", {
									className: "jaipur-over-seals",
									children: [/* @__PURE__ */ p("span", { children: u("games.jaipur.matchSeals") }), /* @__PURE__ */ p("b", {
										className: "font-mono tabular-nums",
										children: e.scores?.[t] ?? 0
									})]
								}),
								a !== void 0 && a > 0 && /* @__PURE__ */ m("span", {
									className: "jaipur-over-bot",
									children: [/* @__PURE__ */ p(v, { size: 18 }), u("session.autopilot.share", { n: Math.round(a * 100) })]
								})
							]
						}, t);
					})
				}), g && /* @__PURE__ */ p("div", {
					className: "jaipur-over-ledger",
					children: /* @__PURE__ */ p(Oe, {
						pub: c,
						end: g,
						nameOf: h
					})
				})]
			})
		})]
	});
}
//#endregion
//#region src/games/jaipur/options.tsx
var Ge = [{
	id: "bestOf3",
	labelKey: "games.jaipur.optBestOf3"
}, {
	id: "single",
	labelKey: "games.jaipur.optSingle"
}];
function Ke({ value: e, onChange: t }) {
	let n = s(), r = P.safeParse(e), i = r.success ? r.data : P.parse(void 0);
	return /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ p(S, {
			title: n("games.jaipur.optMatch"),
			children: Ge.map((e) => /* @__PURE__ */ p(x, {
				name: "jaipur-match",
				value: e.id,
				checked: i.match === e.id,
				label: n(e.labelKey),
				accent: A.accent,
				onChange: () => t({ match: e.id })
			}, e.id))
		}), /* @__PURE__ */ p("p", {
			className: "text-xs text-ink/70",
			children: n("games.jaipur.optMatchHint")
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/jaipur/entry.tsx
var qe = {
	definition: ge,
	View: ve,
	bot: Fe,
	describe: Le,
	llm: Re,
	fx: Ue,
	OverView: We,
	Options: Ke,
	locales: {
		zh: {
			name: "斋普尔",
			desc: "沙漠市集的双人交易对决:拿货、换货、收骆驼,瞅准时机卖高价",
			rules: "游戏目标：每局争取比对手获得更多卢比。赢得一局的玩家获得 1 枚卓越印章；率先集齐 2 枚印章的玩家赢得整场比赛。也可以选择只进行一局。\n游戏准备：在市场放置 3 张骆驼牌和 2 张其他牌。每名玩家获得 5 张手牌，并立即将手牌中的骆驼放到自己面前，组成驼队。\n回合行动：轮到你时，选择以下四种行动之一。\n· 领取货物：从市场领取 1 张货物牌，加入手牌；不能以此方式领取骆驼。手牌上限为 7 张，驼队中的骆驼不计入此上限。\n· 领取骆驼：将市场中的全部骆驼牌加入自己的驼队。\n· 交换货物：从市场领取至少 2 张货物牌，同时向市场归还等量的手牌货物或驼队中的骆驼。一次交换中，不能同时领取和归还同一种货物。\n· 出售货物：卖出任意数量的同种货物，并按面值从高到低领取等量的对应货物代币。出售钻石、黄金或白银时，一次必须卖出至少 2 张。\n出售奖励：一次出售三张、四张或至少五张同种货物时，额外暗抽一枚对应档位的奖励代币。\n回合结束:\n· 三种货物代币耗尽，或抽牌堆不足以补满市场时，本局立即结束。\n· 骆驼数量较多的玩家获得骆驼代币，价值为 5 卢比。双方骆驼数量相同时，均不能获得该代币。\n· 双方分别将自己持有的全部代币面值相加，总额较高的玩家赢得本局。总额相同时，依次比较奖励代币和货物代币的数量，较多的玩家获胜；若仍然相同，双方均不能获得卓越印章。\n· 下一局由上局败者先手。",
			roundChip: "第 {{n}} 局",
			brand: "JAIPUR",
			turnYou: "轮到你:拿牌或卖货",
			turnWait: "等 {{name}} 行动…",
			take: "拿取",
			takeOne: "拿 1 张{{good}}",
			takeCamels: "收编骆驼",
			takeCamelsN: "收编市场全部 {{n}} 只骆驼",
			exchange: "交换",
			exchangeN: "拿 {{n}} 张,归还等量手牌或骆驼",
			exchangeNeed: "还需归还 {{n}} 张手牌或骆驼",
			exchangeReady: "拿 {{n}} 张,交出手牌 {{g}} 张、骆驼 {{c}} 只",
			sell: "卖出",
			sellN: "卖出 {{n}} 张{{good}}",
			cancel: "取消",
			selectGive: "交换须归还 {{n}} 张:点手牌或驼队凑数",
			overlapErr: "同种货物不能又拿又还",
			handFullErr: "手牌已满 7 张",
			sellMinErr: "{{good}}每次至少卖 2 张",
			herd: "驼队",
			handTitle: "我的手牌",
			handCount: "{{n}} / 7",
			marketTitle: "沙漠市集",
			marketHint: "点货物拿牌;点骆驼收编整群",
			marketWaitHint: "等待当前商人交易",
			marketSellHint: "从手牌继续选同种货物卖出",
			marketSelected: "已选 {{n}} 张货物;选 2 张以上可交换",
			refillSlot: "补牌位",
			priceTitle: "货价",
			priceHint: "从上往下取",
			salePreview: "本次货物代币 {{n}} 卢比 · 奖励档 {{tier}}",
			soldOut: "售罄",
			rewardTitle: "交易奖励",
			rewardHint: "卖出 3 / 4 / 5 张可得",
			camelShort: "驼",
			roundLedger: "本局账本",
			ledgerRound: "第 {{n}} 局账本",
			ledgerGoods: "货物代币",
			ledgerBonus: "奖励代币",
			ledgerCamel: "骆驼代币",
			ledgerGoodsToken: "{{good}}代币：{{n}} 卢比",
			ledgerBonusToken: "{{tier}} 张档奖励代币：{{n}} 卢比",
			matchResult: "整场结果",
			matchWinner: "{{name}} 赢下整场",
			matchTie: "整场平局",
			matchRanking: "整场排名",
			matchWinnerMark: "整场胜者",
			matchSeals: "卓越印章",
			roundWinnerMark: "本局胜者",
			herdAria: "驼队有 {{n}} 只骆驼",
			giveCamels: "给 {{n}} 🐪",
			emptyHand: "手牌空了",
			deckAria: "牌堆还剩 {{n}} 张",
			pileAria: "{{good}}代币堆,顶面值 {{v}},剩 {{n}} 枚",
			bonusAria: "卖 {{n}} 张以上的奖励代币,剩 {{c}} 枚",
			camelTokenAria: "骆驼代币:回合结束时驼队多的一方得 5 卢比",
			endTokens: "三种货物售罄",
			endDeck: "牌堆耗尽",
			camelBonus: "骆驼最多:{{name}} +5",
			camelTie: "骆驼打平,无人得骆驼代币",
			roundWin: "{{name}} 赢下本局,获得卓越印章",
			roundTie: "本局平局,无人获得印章",
			scoreTotal: "{{n}} 卢比",
			optMatch: "赛制",
			optSingle: "单局定胜负",
			optBestOf3: "三局两胜(官方)",
			optMatchHint: "三局两胜:每局胜者得一枚卓越印章,先集齐 2 枚赢下整场",
			good: {
				diamond: "钻石",
				gold: "黄金",
				silver: "白银",
				cloth: "布匹",
				spice: "香料",
				leather: "皮革",
				camel: "骆驼"
			},
			errNotYourTurn: "现在轮不到你",
			errBadTake: "这张牌不能拿",
			errHandFull: "手牌已满 7 张",
			errNoCamels: "市场里没有骆驼",
			errBadExchange: "交换的数量或货物不对",
			errExchangeOverlap: "同种货物不能又拿又还",
			errBadSell: "手里没有这么多这种货",
			errSellMin: "这种贵货每次至少卖 2 张"
		},
		en: {
			name: "Jaipur",
			desc: "A two-player trading duel: take, trade and herd camels, then sell at the perfect moment",
			rules: "Goal: out-earn your rival in rupees each round. The round winner takes a Seal of Excellence; first to 2 seals wins the match (or play a single round).\nSetup: the market starts with 3 camels plus 2 cards; each player is dealt 5 cards and any camels in hand immediately form their herd.\nPlay (on your turn, choose one):\n· Take 1 goods card from the market into your hand. You cannot take a camel with this action. Your hand limit is 7 cards; camels in your herd do not count toward it.\n· Take ALL camels from the market into your herd.\n· Exchange: take at least 2 goods cards, returning the same number of hand goods or camels; a good type can’t be both taken and returned.\n· Sell: discard any number of one good type (at least 2 for diamonds, gold, silver) and take that many tokens, highest values first.\nSale bonus: selling three, four, or at least five cards of one good at once also earns one face-down bonus token of the corresponding tier.\nRound end:\n· The round ends immediately when three goods token piles run out or the deck can’t refill the market.\n· The player with more camels gains the camel token, worth 5 rupees. If both players have the same number of camels, neither gains the token.\n· Add the values of all your tokens. The player with the higher total wins the round. Break ties by the number of bonus tokens, then by the number of goods tokens. If the players are still tied, neither gains a Seal of Excellence.\n· The loser of a round starts the next one.",
			roundChip: "Round {{n}}",
			brand: "JAIPUR",
			turnYou: "Your turn: take or sell",
			turnWait: "Waiting for {{name}}…",
			take: "Take",
			takeOne: "Take 1 {{good}}",
			takeCamels: "Take camels",
			takeCamelsN: "Take all {{n}} camels in the market",
			exchange: "Exchange",
			exchangeN: "Take {{n}}, return the same number",
			exchangeNeed: "Return {{n}} more hand cards or camels",
			exchangeReady: "Take {{n}}; return {{g}} cards and {{c}} camels",
			sell: "Sell",
			sellN: "Sell {{n}} {{good}}",
			cancel: "Cancel",
			selectGive: "Exchange needs {{n}} returned: tap hand cards or your herd",
			overlapErr: "A good type can’t be both taken and returned",
			handFullErr: "Hand full (7 cards)",
			sellMinErr: "Sell at least 2 {{good}} each time",
			herd: "Herd",
			handTitle: "My hand",
			handCount: "{{n}} / 7",
			marketTitle: "Desert bazaar",
			marketHint: "Tap a good to take it, or a camel for the whole herd",
			marketWaitHint: "Waiting for the trader",
			marketSellHint: "Keep picking the same good from your hand to sell",
			marketSelected: "{{n}} goods picked; pick 2+ to exchange",
			refillSlot: "Refill",
			priceTitle: "Prices",
			priceHint: "Take from the top",
			salePreview: "{{n}} rupees in goods tokens · bonus tier {{tier}}",
			soldOut: "Sold out",
			rewardTitle: "Sale bonuses",
			rewardHint: "Sell 3 / 4 / 5 cards",
			camelShort: "Camel",
			roundLedger: "Round ledger",
			ledgerRound: "Round {{n}} ledger",
			ledgerGoods: "Goods tokens",
			ledgerBonus: "Bonus tokens",
			ledgerCamel: "Camel token",
			ledgerGoodsToken: "{{good}} token: {{n}} rupees",
			ledgerBonusToken: "{{tier}}-card bonus token: {{n}} rupees",
			matchResult: "Match result",
			matchWinner: "{{name}} wins the match",
			matchTie: "Match tied",
			matchRanking: "Match ranking",
			matchWinnerMark: "Match winner",
			matchSeals: "Seals of Excellence",
			roundWinnerMark: "Round winner",
			herdAria: "Herd has {{n}} camels",
			giveCamels: "Give {{n}} 🐪",
			emptyHand: "Hand empty",
			deckAria: "{{n}} cards left in the deck",
			pileAria: "{{good}} tokens, top value {{v}}, {{n}} left",
			bonusAria: "Bonus tokens for selling {{n}}+ cards, {{c}} left",
			camelTokenAria: "Camel token: the bigger herd earns 5 rupees at round end",
			endTokens: "Three goods sold out",
			endDeck: "Deck exhausted",
			camelBonus: "Most camels: {{name}} +5",
			camelTie: "Camel tie, no camel token",
			roundWin: "{{name}} wins the round and takes a Seal of Excellence",
			roundTie: "Round tied, no seal awarded",
			scoreTotal: "{{n}} rupees",
			optMatch: "Match",
			optSingle: "Single round",
			optBestOf3: "Best of 3 (official)",
			optMatchHint: "Best of 3: each round winner takes a Seal of Excellence; first to 2 seals wins",
			good: {
				diamond: "diamonds",
				gold: "gold",
				silver: "silver",
				cloth: "cloth",
				spice: "spice",
				leather: "leather",
				camel: "camel"
			},
			errNotYourTurn: "Not your turn",
			errBadTake: "That card can’t be taken",
			errHandFull: "Hand full (7 cards)",
			errNoCamels: "No camels in the market",
			errBadExchange: "Wrong cards or count for the exchange",
			errExchangeOverlap: "A good type can’t be both taken and returned",
			errBadSell: "You don’t hold that many",
			errSellMin: "Precious goods sell at least 2 each time"
		}
	}
};
//#endregion
export { qe as default };
