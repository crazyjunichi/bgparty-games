import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useRef as n, useState as r } from "react";
import { gameAssetUrl as i } from "@bgparty/sdk/assets";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { useFxAnchor as u } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as d } from "@bgparty/sdk/fx/delta-number";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g, PulseBox as ee } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as _ } from "@bgparty/sdk/confirm-button";
import { OptionCheckbox as te, OptionRadio as ne, OptionSection as re } from "@bgparty/sdk/ui/game-options";
//#region src/game/data.ts
var v = {
	source: "TTS 2954157721; base 2019, City of Crowns 2021, Tomesaga Paladins scenario; actual cards visually checked 2026-11-10",
	paladins: [
		{
			id: 1536,
			name: "Othon",
			attributes: [
				0,
				2,
				2,
				0
			],
			ability: "tradeSilver",
			workers: ["u", "u"],
			set: "base"
		},
		{
			id: 1537,
			name: "Roland",
			attributes: [
				0,
				0,
				4,
				0
			],
			ability: "recruitFree",
			workers: ["r", "w"],
			set: "base"
		},
		{
			id: 1538,
			name: "Samson",
			attributes: [
				2,
				0,
				2,
				0
			],
			ability: "developDiscount",
			workers: ["g", "w"],
			set: "base"
		},
		{
			id: 1539,
			name: "Anseis",
			attributes: [
				3,
				1,
				0,
				0
			],
			ability: "fortifyFree",
			workers: ["u", "g"],
			set: "base"
		},
		{
			id: 1540,
			name: "Berenger",
			attributes: [
				1,
				0,
				3,
				0
			],
			ability: "garrisonFree",
			workers: ["r", "u"],
			set: "base"
		},
		{
			id: 1541,
			name: "Engelier",
			attributes: [
				0,
				1,
				3,
				0
			],
			ability: "attackSilver",
			workers: ["r", "g"],
			set: "base"
		},
		{
			id: 1542,
			name: "Girard",
			attributes: [
				2,
				2,
				0,
				0
			],
			ability: "huntProvision",
			workers: ["g", "g"],
			set: "base"
		},
		{
			id: 1543,
			name: "Gerin",
			attributes: [
				1,
				3,
				0,
				0
			],
			ability: "convertFree",
			workers: ["b", "r"],
			set: "base"
		},
		{
			id: 1544,
			name: "Gelin",
			attributes: [
				4,
				0,
				0,
				0
			],
			ability: "conspireSilver",
			workers: ["u", "w"],
			set: "base"
		},
		{
			id: 1545,
			name: "Voire",
			attributes: [
				3,
				0,
				1,
				0
			],
			ability: "absolveFree",
			workers: ["b", "u"],
			set: "base"
		},
		{
			id: 1546,
			name: "Turpin",
			attributes: [
				0,
				3,
				1,
				0
			],
			ability: "commissionFree",
			workers: ["b", "g"],
			set: "base"
		},
		{
			id: 1547,
			name: "Olivier",
			attributes: [
				0,
				4,
				0,
				0
			],
			ability: "prayFree",
			workers: ["b", "b"],
			set: "base"
		},
		{
			id: 35700,
			name: "Fierrabras",
			attributes: [
				0,
				0,
				1,
				3
			],
			ability: "musterFree",
			workers: ["b", "g"],
			set: "city"
		},
		{
			id: 35701,
			name: "Astolfo",
			attributes: [
				1,
				0,
				0,
				3
			],
			ability: "none",
			workers: [
				"g",
				"r",
				"u",
				"b"
			],
			set: "city"
		},
		{
			id: 35702,
			name: "Maugris",
			attributes: [
				0,
				0,
				0,
				4
			],
			ability: "costDebt",
			workers: ["w", "w"],
			set: "city"
		},
		{
			id: 35703,
			name: "Renaud",
			attributes: [
				0,
				0,
				3,
				1
			],
			ability: "negotiateFree",
			workers: ["r", "u"],
			set: "city"
		},
		{
			id: 34900,
			name: "Turpin",
			attributes: [
				0,
				0,
				0,
				0
			],
			ability: "reuse",
			workers: [],
			set: "paladinPromo"
		},
		{
			id: 35e3,
			name: "Ogier",
			attributes: [
				0,
				3,
				0,
				0
			],
			ability: "silverDiscount",
			workers: ["b", "w"],
			set: "paladinPromo"
		},
		{
			id: 35100,
			name: "Huon",
			attributes: [
				3,
				0,
				0,
				0
			],
			ability: "suspicionProvision",
			workers: ["r", "r"],
			set: "paladinPromo"
		},
		{
			id: 35200,
			name: "Ganelon",
			attributes: [
				0,
				0,
				3,
				0
			],
			ability: "whiteWild",
			workers: ["w", "w"],
			set: "paladinPromo"
		}
	],
	townsfolk: [
		{
			id: 1726,
			name: "Defender",
			dismiss: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "provision",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "attack",
			reward: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1716,
			name: "Acolyte",
			dismiss: [{
				op: "removeSuspicion",
				n: 2
			}],
			immediate: [{
				op: "removeSuspicion",
				n: 1
			}],
			trigger: "commission",
			reward: [{
				op: "gain",
				resource: "tax",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1707,
			name: "Squire",
			dismiss: [{
				op: "gain",
				resource: "p",
				n: 1
			}],
			immediate: [],
			trigger: "inquisition",
			reward: [{
				op: "gain",
				resource: "strength",
				n: 1
			}],
			ability: "none",
			set: "base"
		},
		{
			id: 1702,
			name: "Peddler",
			dismiss: [{
				op: "gain",
				resource: "w",
				n: 2
			}],
			immediate: [],
			trigger: "inquisition",
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			ability: "two",
			set: "base"
		},
		{
			id: 1701,
			name: "Missionary",
			dismiss: [{
				op: "gain",
				resource: "g",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 1
			}],
			immediate: [{
				op: "removeSuspicion",
				n: 1
			}],
			trigger: "convert",
			reward: [{
				op: "gain",
				resource: "tax",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1700,
			name: "Missionary",
			dismiss: [{
				op: "gain",
				resource: "faith",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "convert",
			reward: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1710,
			name: "Watchman",
			dismiss: [{
				op: "gain",
				resource: "u",
				n: 1
			}],
			immediate: [{
				op: "removeSuspicion",
				n: 1
			}],
			trigger: "garrison",
			reward: [{
				op: "gain",
				resource: "tax",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1713,
			name: "Abbot",
			dismiss: [{
				op: "destroyDebt",
				n: 1
			}],
			immediate: [{
				op: "removeSuspicion",
				n: 1
			}],
			trigger: "absolve",
			reward: [{
				op: "gain",
				resource: "tax",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1711,
			name: "Abbot",
			dismiss: [{
				op: "gain",
				resource: "b",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 1
			}],
			immediate: [],
			trigger: "absolve",
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1718,
			name: "Architect",
			dismiss: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "provision",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "develop",
			reward: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1719,
			name: "Architect",
			dismiss: [{
				op: "gain",
				resource: "tax",
				n: 2
			}],
			immediate: [{
				op: "removeSuspicion",
				n: 1
			}],
			trigger: "develop",
			reward: [{
				op: "gain",
				resource: "tax",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1725,
			name: "Defender",
			dismiss: [{
				op: "gain",
				resource: "strength",
				n: 1
			}],
			immediate: [],
			trigger: "attack",
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1717,
			name: "Architect",
			dismiss: [{
				op: "gain",
				resource: "p",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "develop",
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1727,
			name: "Defender",
			dismiss: [{
				op: "gain",
				resource: "tax",
				n: 2
			}],
			immediate: [{
				op: "removeSuspicion",
				n: 1
			}],
			trigger: "attack",
			reward: [{
				op: "gain",
				resource: "tax",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1709,
			name: "Watchman",
			dismiss: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "provision",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			trigger: "garrison",
			reward: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1714,
			name: "Acolyte",
			dismiss: [{
				op: "gain",
				resource: "b",
				n: 1
			}],
			immediate: [],
			trigger: "commission",
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1708,
			name: "Watchman",
			dismiss: [{
				op: "gain",
				resource: "r",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 1
			}],
			immediate: [],
			trigger: "garrison",
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1721,
			name: "Conspirator",
			dismiss: [{
				op: "gain",
				resource: "p",
				n: 1
			}],
			immediate: [],
			trigger: "inquisition",
			reward: [{
				op: "removeSuspicion",
				n: 1
			}],
			ability: "always",
			set: "base"
		},
		{
			id: 1720,
			name: "Conspirator",
			dismiss: [{
				op: "removeSuspicion",
				n: 2
			}],
			immediate: [],
			trigger: "inquisition",
			reward: [{
				op: "removeSuspicion",
				n: 1
			}],
			ability: "always",
			set: "base"
		},
		{
			id: 1706,
			name: "Squire",
			dismiss: [{
				op: "gain",
				resource: "influence",
				n: 1
			}],
			immediate: [],
			trigger: "inquisition",
			reward: [{
				op: "gain",
				resource: "influence",
				n: 1
			}],
			ability: "none",
			set: "base"
		},
		{
			id: 1705,
			name: "Squire",
			dismiss: [{
				op: "gain",
				resource: "r",
				n: 1
			}],
			immediate: [],
			trigger: "inquisition",
			reward: [{
				op: "gain",
				resource: "faith",
				n: 1
			}],
			ability: "none",
			set: "base"
		},
		{
			id: 1704,
			name: "Peddler",
			dismiss: [{
				op: "removeSuspicion",
				n: 2
			}],
			immediate: [],
			trigger: "inquisition",
			reward: [{
				op: "gain",
				resource: "silver",
				n: 2
			}],
			ability: "two",
			set: "base"
		},
		{
			id: 1703,
			name: "Peddler",
			dismiss: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "provision",
				n: 1
			}],
			immediate: [],
			trigger: "inquisition",
			reward: [{
				op: "gain",
				resource: "provision",
				n: 2
			}],
			ability: "two",
			set: "base"
		},
		{
			id: 1728,
			name: "Gatekeeper",
			dismiss: [{
				op: "gain",
				resource: "u",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 1
			}],
			immediate: [],
			trigger: "fortify",
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1730,
			name: "Gatekeeper",
			dismiss: [{
				op: "gain",
				resource: "tax",
				n: 2
			}],
			immediate: [{
				op: "removeSuspicion",
				n: 1
			}],
			trigger: "fortify",
			reward: [{
				op: "gain",
				resource: "tax",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1729,
			name: "Gatekeeper",
			dismiss: [{
				op: "gain",
				resource: "g",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			trigger: "fortify",
			reward: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1723,
			name: "Debt Collector",
			dismiss: [{
				op: "destroyDebt",
				n: 1
			}],
			immediate: [],
			trigger: "repay",
			reward: [{
				op: "gain",
				resource: "r",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1722,
			name: "Debt Collector",
			dismiss: [{
				op: "gain",
				resource: "w",
				n: 2
			}],
			immediate: [],
			trigger: "repay",
			reward: [{
				op: "gain",
				resource: "u",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1724,
			name: "Debt Collector",
			dismiss: [{
				op: "removeSuspicion",
				n: 2
			}],
			immediate: [],
			trigger: "repay",
			reward: [{
				op: "gain",
				resource: "g",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1712,
			name: "Abbot",
			dismiss: [{ op: "pray" }],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "absolve",
			reward: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1715,
			name: "Acolyte",
			dismiss: [{ op: "pray" }],
			immediate: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			trigger: "commission",
			reward: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 1731,
			name: "Missionary",
			dismiss: [{ op: "pray" }],
			immediate: [],
			trigger: "convert",
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			ability: "",
			set: "base"
		},
		{
			id: 35900,
			name: "Strongman",
			dismiss: [{ op: "moveWorkshop" }],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "",
			reward: [],
			ability: "provisionBoostStrength",
			set: "promos"
		},
		{
			id: 27703,
			name: "Swindler",
			dismiss: [{
				op: "gain",
				resource: "tax",
				n: 1
			}, {
				op: "gain",
				resource: "provision",
				n: 1
			}],
			immediate: [{
				op: "removeSuspicion",
				n: 1
			}],
			trigger: "debt",
			reward: [{
				op: "gain",
				resource: "tax",
				n: 1
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 27701,
			name: "Swindler",
			dismiss: [{
				op: "gain",
				resource: "w",
				n: 2
			}],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "debt",
			reward: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 27702,
			name: "Swindler",
			dismiss: [{
				op: "gain",
				resource: "p",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			trigger: "debt",
			reward: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 27705,
			name: "Aristocrat",
			dismiss: [{ op: "pray" }],
			immediate: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			trigger: "favour",
			reward: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 27704,
			name: "Aristocrat",
			dismiss: [{
				op: "gain",
				resource: "r",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "favour",
			reward: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 27700,
			name: "Aristocrat",
			dismiss: [{
				op: "gain",
				resource: "b",
				n: 1
			}],
			immediate: [{
				op: "removeSuspicion",
				n: 1
			}],
			trigger: "favour",
			reward: [{
				op: "gain",
				resource: "tax",
				n: 1
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 36e3,
			name: "Pickpocket",
			dismiss: [{
				op: "gain",
				resource: "tax",
				n: 1
			}, {
				op: "gain",
				resource: "provision",
				n: 1
			}],
			immediate: [],
			trigger: "suspicion",
			reward: [{
				op: "gain",
				resource: "tax",
				n: 1
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 36100,
			name: "Swindler",
			dismiss: [{
				op: "destroyDebt",
				n: 1
			}],
			immediate: [],
			trigger: "debt",
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 36200,
			name: "Overseer",
			dismiss: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "provision",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "hire",
			reward: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 36300,
			name: "King Dan",
			dismiss: [{
				op: "destroyDebt",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			trigger: "dismiss",
			reward: [{
				op: "removeSuspicion",
				n: 1
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 36400,
			name: "Suzerain",
			dismiss: [{
				op: "gain",
				resource: "p",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			trigger: "zeroTax",
			reward: [{
				op: "gain",
				resource: "silver",
				n: 2
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 36500,
			name: "Ryan",
			dismiss: [{
				op: "gain",
				resource: "b",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 1
			}],
			immediate: [],
			trigger: "",
			reward: [],
			ability: "whiteAsClerics",
			set: "promos"
		},
		{
			id: 36600,
			name: "Kira",
			dismiss: [{
				op: "gain",
				resource: "g",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "",
			reward: [],
			ability: "whiteAsScouts",
			set: "promos"
		},
		{
			id: 36700,
			name: "Jeremy",
			dismiss: [{
				op: "gain",
				resource: "u",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			trigger: "",
			reward: [],
			ability: "whiteAsMerchants",
			set: "promos"
		},
		{
			id: 36800,
			name: "David",
			dismiss: [{
				op: "gain",
				resource: "r",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 1
			}],
			immediate: [],
			trigger: "",
			reward: [],
			ability: "whiteAsFighters",
			set: "promos"
		},
		{
			id: 36900,
			name: "Friar",
			dismiss: [{ op: "pray" }],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "",
			reward: [],
			ability: "provisionBoostFaith",
			set: "promos"
		},
		{
			id: 37e3,
			name: "Financier",
			dismiss: [{
				op: "gain",
				resource: "tax",
				n: 2
			}],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "",
			reward: [],
			ability: "provisionBoostInfluence",
			set: "promos"
		},
		{
			id: 37100,
			name: "Patron",
			dismiss: [{ op: "pray" }],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "pray",
			reward: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 37200,
			name: "Patron",
			dismiss: [{
				op: "gain",
				resource: "w",
				n: 2
			}],
			immediate: [],
			trigger: "pray",
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 37300,
			name: "Patron",
			dismiss: [{
				op: "gain",
				resource: "tax",
				n: 2
			}],
			immediate: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			trigger: "pray",
			reward: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			ability: "",
			set: "promos"
		},
		{
			id: 37805,
			name: "Outrider",
			dismiss: [{ op: "pray" }],
			immediate: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			trigger: "muster",
			reward: [{
				op: "gain",
				resource: "silver",
				n: 1
			}],
			ability: "",
			set: "city"
		},
		{
			id: 37802,
			name: "Squire",
			dismiss: [{
				op: "gain",
				resource: "diplomacy",
				n: 1
			}],
			immediate: [],
			trigger: "inquisition",
			reward: [{
				op: "gain",
				resource: "diplomacy",
				n: 1
			}],
			ability: "none",
			set: "city"
		},
		{
			id: 37804,
			name: "Chevalier",
			dismiss: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "provision",
				n: 1
			}],
			immediate: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			trigger: "enlist",
			reward: [{
				op: "gain",
				resource: "provision",
				n: 1
			}],
			ability: "",
			set: "city"
		},
		{
			id: 37803,
			name: "Chevalier",
			dismiss: [{ op: "moveWorkshop" }],
			immediate: [],
			trigger: "enlist",
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			ability: "",
			set: "city"
		},
		{
			id: 37806,
			name: "Outrider",
			dismiss: [{
				op: "gain",
				resource: "diplomacy",
				n: 1
			}],
			immediate: [],
			trigger: "muster",
			reward: [{
				op: "gain",
				resource: "tax",
				n: 1
			}],
			ability: "",
			set: "city"
		},
		{
			id: 37800,
			name: "Princess",
			dismiss: [{
				op: "gain",
				resource: "w",
				n: 2
			}],
			immediate: [],
			trigger: "pass",
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			ability: "",
			set: "compatible"
		},
		{
			id: 37801,
			name: "Princess",
			dismiss: [{ op: "moveWorkshop" }],
			immediate: [{
				op: "removeSuspicion",
				n: 1
			}],
			trigger: "pass",
			reward: [{
				op: "removeSuspicion",
				n: 1
			}, {
				op: "gain",
				resource: "tax",
				n: 1
			}],
			ability: "",
			set: "compatible"
		},
		{
			id: 37807,
			name: "Princess",
			dismiss: [{
				op: "destroyDebt",
				n: 1
			}],
			immediate: [],
			trigger: "pass",
			reward: [{
				op: "gain",
				resource: "silver",
				n: 1
			}, {
				op: "gain",
				resource: "provision",
				n: 1
			}],
			ability: "",
			set: "compatible"
		}
	],
	outsiders: [
		{
			id: 1609,
			name: "Marauder",
			nation: "viking",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "p",
				n: 1
			}],
			strength: 1,
			scoreText: "Score 1 VP per 4 Influence you have.",
			set: "base",
			score: {
				kind: "attribute",
				key: "influence",
				divisor: 4
			}
		},
		{
			id: 1602,
			name: "Warrior",
			nation: "byzantine",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "b",
				n: 1
			}],
			strength: 1,
			scoreText: "Score 1 VP per 4 Faith you have.",
			set: "base",
			score: {
				kind: "attribute",
				key: "faith",
				divisor: 4
			}
		},
		{
			id: 1626,
			name: "Warrior",
			nation: "saracen",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "provision",
				n: 2
			}],
			strength: 1,
			scoreText: "Score 1 VP per 4 Faith you have.",
			set: "base",
			score: {
				kind: "attribute",
				key: "faith",
				divisor: 4
			}
		},
		{
			id: 1633,
			name: "Marauder",
			nation: "byzantine",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 2
			}],
			strength: 1,
			scoreText: "Score 1 VP per 4 Influence you have.",
			set: "base",
			score: {
				kind: "attribute",
				key: "influence",
				divisor: 4
			}
		},
		{
			id: 1604,
			name: "Armourer",
			nation: "viking",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "gain",
					resource: "w",
					n: 1
				},
				{
					op: "gain",
					resource: "provision",
					n: 1
				}
			],
			strength: 1,
			scoreText: "Score 1 VP per 4 Strength you have.",
			set: "base",
			score: {
				kind: "attribute",
				key: "strength",
				divisor: 4
			}
		},
		{
			id: 1616,
			name: "Armourer",
			nation: "saracen",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "r",
				n: 1
			}],
			strength: 1,
			scoreText: "Score 1 VP per 4 Strength you have.",
			set: "base",
			score: {
				kind: "attribute",
				key: "strength",
				divisor: 4
			}
		},
		{
			id: 1631,
			name: "Hunter",
			nation: "byzantine",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "destroyDebt",
				n: 1
			}],
			strength: 1,
			scoreText: "Score 1 VP per 2 Townsfolk you have Recruited.",
			set: "base",
			score: {
				kind: "townsfolk",
				divisor: 2
			}
		},
		{
			id: 1620,
			name: "Hunter",
			nation: "saracen",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "removeSuspicion",
					n: 1
				},
				{
					op: "gain",
					resource: "r",
					n: 1
				}
			],
			strength: 1,
			scoreText: "Score 1 VP per 2 Townsfolk you have Recruited.",
			set: "base",
			score: {
				kind: "townsfolk",
				divisor: 2
			}
		},
		{
			id: 1627,
			name: "Adventurer",
			nation: "byzantine",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "gain",
					resource: "g",
					n: 1
				},
				{
					op: "gain",
					resource: "w",
					n: 1
				}
			],
			strength: 1,
			scoreText: "Score 1 VP for every 2 times you've taken the Commission action.",
			set: "base",
			score: {
				kind: "action",
				key: "commission",
				divisor: 2
			}
		},
		{
			id: 1603,
			name: "Adventurer",
			nation: "viking",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "gain",
					resource: "b",
					n: 1
				},
				{
					op: "gain",
					resource: "w",
					n: 1
				}
			],
			strength: 1,
			scoreText: "Score 1 VP for every 2 times you've taken the Commission action.",
			set: "base",
			score: {
				kind: "action",
				key: "commission",
				divisor: 2
			}
		},
		{
			id: 1614,
			name: "Vigilante",
			nation: "viking",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "destroyDebt",
				n: 1
			}],
			strength: 1,
			scoreText: "Score 1 VP for every 2 times you've taken the Absolve action.",
			set: "base",
			score: {
				kind: "action",
				key: "absolve",
				divisor: 2
			}
		},
		{
			id: 1601,
			name: "Vigilante",
			nation: "byzantine",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "removeSuspicion",
					n: 1
				},
				{
					op: "gain",
					resource: "b",
					n: 1
				}
			],
			strength: 1,
			scoreText: "Score 1 VP for every 2 times you've taken the Absolve action.",
			set: "base",
			score: {
				kind: "action",
				key: "absolve",
				divisor: 2
			}
		},
		{
			id: 1619,
			name: "Guardian",
			nation: "saracen",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 2
			}],
			strength: 1,
			scoreText: "Score 1 VP for every 2 times you've taken the Develop action.",
			set: "base",
			score: {
				kind: "action",
				key: "develop",
				divisor: 2
			}
		},
		{
			id: 1607,
			name: "Guardian",
			nation: "viking",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "gain",
					resource: "u",
					n: 1
				},
				{
					op: "gain",
					resource: "provision",
					n: 1
				}
			],
			strength: 1,
			scoreText: "Score 1 VP for every 2 times you've taken the Develop action.",
			set: "base",
			score: {
				kind: "action",
				key: "develop",
				divisor: 2
			}
		},
		{
			id: 1608,
			name: "Lookout",
			nation: "viking",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "u",
				n: 1
			}],
			strength: 1,
			scoreText: "Score 1 VP for every 2 times you've taken the Fortify action.",
			set: "base",
			score: {
				kind: "action",
				key: "fortify",
				divisor: 2
			}
		},
		{
			id: 1615,
			name: "Archer",
			nation: "saracen",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "gain",
					resource: "g",
					n: 1
				},
				{
					op: "gain",
					resource: "provision",
					n: 1
				}
			],
			strength: 1,
			scoreText: "Score 1 VP for every 2 times you've taken the Garrison action.",
			set: "base",
			score: {
				kind: "action",
				key: "garrison",
				divisor: 2
			}
		},
		{
			id: 1628,
			name: "Archer",
			nation: "byzantine",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "provision",
				n: 2
			}],
			strength: 1,
			scoreText: "Score 1 VP for every 2 times you've taken the Garrison action.",
			set: "base",
			score: {
				kind: "action",
				key: "garrison",
				divisor: 2
			}
		},
		{
			id: 1606,
			name: "Barbarian",
			nation: "viking",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "gain",
					resource: "tax",
					n: 1
				},
				{
					op: "gain",
					resource: "provision",
					n: 1
				}
			],
			strength: 2,
			scoreText: "Score 1 VP for every Saracen Outsider you have Attacked.",
			set: "base",
			score: {
				kind: "attackedNation",
				key: "saracen"
			}
		},
		{
			id: 1629,
			name: "Barbarian",
			nation: "byzantine",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "tax",
				n: 2
			}],
			strength: 2,
			scoreText: "Score 1 VP for every Saracen Outsider you have Attacked.",
			set: "base",
			score: {
				kind: "attackedNation",
				key: "saracen"
			}
		},
		{
			id: 1617,
			name: "Assassin",
			nation: "saracen",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "gain",
					resource: "w",
					n: 1
				},
				{
					op: "gain",
					resource: "provision",
					n: 1
				}
			],
			strength: 2,
			scoreText: "Score 1 VP for every Byzantine Outsider you have Attacked.",
			set: "base",
			score: {
				kind: "attackedNation",
				key: "byzantine"
			}
		},
		{
			id: 1605,
			name: "Assassin",
			nation: "viking",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "gain",
					resource: "r",
					n: 1
				},
				{
					op: "gain",
					resource: "w",
					n: 1
				}
			],
			strength: 2,
			scoreText: "Score 1 VP for every Byzantine Outsider you have Attacked.",
			set: "base",
			score: {
				kind: "attackedNation",
				key: "byzantine"
			}
		},
		{
			id: 1632,
			name: "Invader",
			nation: "byzantine",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 2
				},
				{
					op: "gain",
					resource: "tax",
					n: 1
				},
				{
					op: "gain",
					resource: "provision",
					n: 1
				}
			],
			strength: 2,
			scoreText: "Score 1 VP for every Viking Outsider you have Attacked.",
			set: "base",
			score: {
				kind: "attackedNation",
				key: "viking"
			}
		},
		{
			id: 1621,
			name: "Invader",
			nation: "saracen",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "gain",
					resource: "tax",
					n: 1
				},
				{
					op: "gain",
					resource: "provision",
					n: 1
				}
			],
			strength: 2,
			scoreText: "Score 1 VP for every Viking Outsider you have Attacked.",
			set: "base",
			score: {
				kind: "attackedNation",
				key: "viking"
			}
		},
		{
			id: 1625,
			name: "Traitor",
			nation: "saracen",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "destroyDebt",
				n: 1
			}],
			strength: 1,
			scoreText: "Lose 1 less VP per unpaid Debt.",
			set: "base",
			score: { kind: "traitor" }
		},
		{
			id: 1613,
			name: "Traitor",
			nation: "viking",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "p",
				n: 1
			}],
			strength: 1,
			scoreText: "Lose 1 less VP per unpaid Debt.",
			set: "base",
			score: { kind: "traitor" }
		},
		{
			id: 1600,
			name: "Protector",
			nation: "byzantine",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 2
			}],
			strength: 1,
			scoreText: "Gain 1 VP per repaid Debt.",
			set: "base",
			score: { kind: "paidDebt" }
		},
		{
			id: 1611,
			name: "Protector",
			nation: "viking",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "gain",
					resource: "w",
					n: 1
				},
				{
					op: "gain",
					resource: "provision",
					n: 1
				}
			],
			strength: 1,
			scoreText: "Gain 1 VP per repaid Debt.",
			set: "base",
			score: { kind: "paidDebt" }
		},
		{
			id: 1612,
			name: "Thief",
			nation: "viking",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "tax",
				n: 2
			}],
			strength: 1,
			scoreText: "Gain 1 VP per Suspicion you hold.",
			set: "base",
			score: { kind: "suspicion" }
		},
		{
			id: 1624,
			name: "Thief",
			nation: "saracen",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "p",
				n: 1
			}],
			strength: 1,
			scoreText: "Gain 1 VP per Suspicion you hold.",
			set: "base",
			score: { kind: "suspicion" }
		},
		{
			id: 1618,
			name: "Champion",
			nation: "saracen",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "removeSuspicion",
					n: 1
				},
				{
					op: "gain",
					resource: "u",
					n: 1
				}
			],
			strength: 1,
			scoreText: "Gain 1 VP plus 1 VP per King's Order you have completed.",
			set: "base",
			score: { kind: "orders" }
		},
		{
			id: 1630,
			name: "Champion",
			nation: "byzantine",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "removeSuspicion",
					n: 1
				},
				{
					op: "gain",
					resource: "g",
					n: 1
				}
			],
			strength: 1,
			scoreText: "Gain 1 VP plus 1 VP per King's Order you have completed.",
			set: "base",
			score: { kind: "orders" }
		},
		{
			id: 1635,
			name: "Mercenary",
			nation: "byzantine",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "tax",
				n: 2
			}],
			strength: 1,
			scoreText: "Gain 1 VP plus 1 VP for each Mercenary you have Converted (Outsiders with the name \"Mercenary\").",
			set: "base",
			score: { kind: "mercenary" }
		},
		{
			id: 1610,
			name: "Mercenary",
			nation: "viking",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 2
			}],
			strength: 1,
			scoreText: "Gain 1 VP plus 1 VP for each Mercenary you have Converted (Outsiders with the name \"Mercenary\").",
			set: "base",
			score: { kind: "mercenary" }
		},
		{
			id: 1623,
			name: "Mercenary",
			nation: "saracen",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "removeSuspicion",
					n: 1
				},
				{
					op: "gain",
					resource: "w",
					n: 1
				}
			],
			strength: 1,
			scoreText: "Gain 1 VP plus 1 VP for each Mercenary you have Converted (Outsiders with the name \"Mercenary\").",
			set: "base",
			score: { kind: "mercenary" }
		},
		{
			id: 1634,
			name: "Mercenary",
			nation: "byzantine",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "gain",
					resource: "w",
					n: 1
				},
				{
					op: "gain",
					resource: "provision",
					n: 1
				}
			],
			strength: 1,
			scoreText: "Gain 1 VP plus 1 VP for each Mercenary you have Converted (Outsiders with the name \"Mercenary\").",
			set: "base",
			score: { kind: "mercenary" }
		},
		{
			id: 1622,
			name: "Lookout",
			nation: "saracen",
			attack: [
				{
					op: "gain",
					resource: "influence",
					n: 1
				},
				{
					op: "gain",
					resource: "u",
					n: 1
				},
				{
					op: "gain",
					resource: "w",
					n: 1
				}
			],
			strength: 1,
			scoreText: "Score 1 VP for every 2 times you've taken the Fortify action.",
			set: "base",
			score: {
				kind: "action",
				key: "fortify",
				divisor: 2
			}
		},
		{
			id: 37400,
			name: "Hero",
			nation: "byzantine",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "p",
				n: 1
			}],
			strength: 1,
			scoreText: "Score 1 VP for every Byzantine Outsider you have Converted (including this one).",
			set: "promos",
			score: {
				kind: "convertedNation",
				key: "byzantine"
			}
		},
		{
			id: 37500,
			name: "Hero",
			nation: "saracen",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "g",
				n: 1
			}],
			strength: 1,
			scoreText: "Score 1 VP for every Saracen Outsider you have Converted (including this one).",
			set: "promos",
			score: {
				kind: "convertedNation",
				key: "saracen"
			}
		},
		{
			id: 37600,
			name: "Hero",
			nation: "viking",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 2
			}],
			strength: 1,
			scoreText: "Score 1 VP for every Viking Outsider you have Converted (including this one).",
			set: "promos",
			score: {
				kind: "convertedNation",
				key: "viking"
			}
		},
		{
			id: 35803,
			name: "Enforcer",
			nation: "viking",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "recruit",
				mode: "hire"
			}],
			strength: 1,
			scoreText: "Score 1 VP for every 2 times you've taken the Muster action.",
			set: "city",
			score: {
				kind: "action",
				key: "muster",
				divisor: 2
			}
		},
		{
			id: 35804,
			name: "Envoy",
			nation: "byzantine",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, { op: "pray" }],
			strength: 1,
			scoreText: "Score 1 VP per 4 Diplomacy you have.",
			set: "city",
			score: {
				kind: "attribute",
				key: "diplomacy",
				divisor: 4
			}
		},
		{
			id: 35805,
			name: "Rogue",
			nation: "viking",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, { op: "pray" }],
			strength: 1,
			scoreText: "Score 1 VP for every 2 Negotiate cards you have Enlisted.",
			set: "city",
			score: {
				kind: "enlisted",
				divisor: 2
			}
		},
		{
			id: 35802,
			name: "Enforcer",
			nation: "byzantine",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "recruit",
				mode: "dismiss"
			}],
			strength: 1,
			scoreText: "Score 1 VP for every 2 times you've taken the Muster action.",
			set: "city",
			score: {
				kind: "action",
				key: "muster",
				divisor: 2
			}
		},
		{
			id: 35800,
			name: "Envoy",
			nation: "saracen",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "recruit",
				mode: "dismiss"
			}],
			strength: 1,
			scoreText: "Score 1 VP per 4 Diplomacy you have.",
			set: "city",
			score: {
				kind: "attribute",
				key: "diplomacy",
				divisor: 4
			}
		},
		{
			id: 35801,
			name: "Rogue",
			nation: "saracen",
			attack: [{
				op: "gain",
				resource: "influence",
				n: 1
			}, {
				op: "gain",
				resource: "p",
				n: 1
			}],
			strength: 1,
			scoreText: "Score 1 VP for every 2 Negotiate cards you have Enlisted.",
			set: "city",
			score: {
				kind: "enlisted",
				divisor: 2
			}
		}
	],
	walls: [
		{
			id: 2912,
			strength: 2,
			vp: 0,
			reward: [],
			set: "base"
		},
		{
			id: 2923,
			strength: 2,
			vp: 0,
			reward: [],
			set: "base"
		},
		{
			id: 2907,
			strength: 1,
			vp: 2,
			reward: [],
			set: "base"
		},
		{
			id: 2908,
			strength: 1,
			vp: 2,
			reward: [],
			set: "base"
		},
		{
			id: 2909,
			strength: 1,
			vp: 0,
			reward: [{
				op: "choice",
				choices: [[{
					op: "repay",
					n: 1
				}], [{
					op: "gain",
					resource: "silver",
					n: 2
				}]]
			}],
			set: "base"
		},
		{
			id: 2910,
			strength: 1,
			vp: 0,
			reward: [{
				op: "choice",
				choices: [[{
					op: "repay",
					n: 1
				}], [{
					op: "gain",
					resource: "silver",
					n: 2
				}]]
			}],
			set: "base"
		},
		{
			id: 2911,
			strength: 1,
			vp: 0,
			reward: [{
				op: "choice",
				choices: [[{
					op: "repay",
					n: 1
				}], [{
					op: "gain",
					resource: "silver",
					n: 2
				}]]
			}],
			set: "base"
		},
		{
			id: 2917,
			strength: 1,
			vp: 0,
			reward: [{
				op: "gain",
				resource: "w",
				n: 3
			}],
			set: "base"
		},
		{
			id: 2922,
			strength: 1,
			vp: 0,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "b",
				n: 1
			}],
			set: "base"
		},
		{
			id: 2905,
			strength: 1,
			vp: 1,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			set: "base"
		},
		{
			id: 2906,
			strength: 1,
			vp: 1,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}],
			set: "base"
		},
		{
			id: 2918,
			strength: 1,
			vp: 0,
			reward: [{
				op: "gain",
				resource: "w",
				n: 2
			}],
			set: "base"
		},
		{
			id: 2920,
			strength: 1,
			vp: 0,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "u",
				n: 1
			}],
			set: "base"
		},
		{
			id: 2902,
			strength: 1,
			vp: 0,
			reward: [{
				op: "gain",
				resource: "r",
				n: 1
			}],
			set: "base"
		},
		{
			id: 2903,
			strength: 1,
			vp: 0,
			reward: [{
				op: "gain",
				resource: "b",
				n: 1
			}],
			set: "base"
		},
		{
			id: 2904,
			strength: 1,
			vp: 0,
			reward: [{
				op: "gain",
				resource: "g",
				n: 1
			}, {
				op: "gain",
				resource: "u",
				n: 1
			}],
			set: "base"
		},
		{
			id: 2913,
			strength: 1,
			vp: 0,
			reward: [{
				op: "choice",
				choices: [[{
					op: "removeSuspicion",
					n: 1
				}], [{
					op: "gain",
					resource: "silver",
					n: 2
				}]]
			}],
			set: "base"
		},
		{
			id: 2919,
			strength: 1,
			vp: 0,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "g",
				n: 1
			}],
			set: "base"
		},
		{
			id: 2921,
			strength: 1,
			vp: 0,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "r",
				n: 1
			}],
			set: "base"
		},
		{
			id: 2900,
			strength: 1,
			vp: 0,
			reward: [{
				op: "gain",
				resource: "g",
				n: 1
			}],
			set: "base"
		},
		{
			id: 2914,
			strength: 1,
			vp: 0,
			reward: [{
				op: "choice",
				choices: [[{
					op: "removeSuspicion",
					n: 1
				}], [{
					op: "gain",
					resource: "silver",
					n: 2
				}]]
			}],
			set: "base"
		},
		{
			id: 2901,
			strength: 1,
			vp: 0,
			reward: [{
				op: "gain",
				resource: "u",
				n: 1
			}],
			set: "base"
		},
		{
			id: 2915,
			strength: 1,
			vp: 0,
			reward: [{
				op: "choice",
				choices: [[{
					op: "removeSuspicion",
					n: 1
				}], [{
					op: "gain",
					resource: "silver",
					n: 2
				}]]
			}],
			set: "base"
		},
		{
			id: 2916,
			strength: 1,
			vp: 0,
			reward: [{
				op: "choice",
				choices: [[{
					op: "removeSuspicion",
					n: 1
				}], [{
					op: "gain",
					resource: "silver",
					n: 2
				}]]
			}],
			set: "base"
		},
		{
			id: 34600,
			strength: 1,
			vp: 0,
			reward: [{ op: "pray" }, {
				op: "gain",
				resource: "w",
				n: 1
			}],
			set: "wallPromo"
		}
	],
	favours: [
		{
			id: 2400,
			worker: "p",
			cost: null,
			price: 0,
			reward: [{
				op: "gain",
				resource: "w",
				n: 3
			}],
			set: "base"
		},
		{
			id: 2401,
			worker: "g",
			cost: null,
			price: 0,
			reward: [{
				op: "recruit",
				mode: "either"
			}],
			set: "base"
		},
		{
			id: 2402,
			worker: "p",
			cost: null,
			price: 0,
			reward: [{
				op: "attribute",
				city: !1
			}],
			set: "base"
		},
		{
			id: 2403,
			worker: "r",
			cost: "silver",
			price: 1,
			reward: [{
				op: "choice",
				choices: [[{
					op: "repay",
					n: 1
				}], [{
					op: "removeSuspicion",
					n: 2
				}]]
			}],
			set: "base"
		},
		{
			id: 2404,
			worker: "b",
			cost: null,
			price: 0,
			reward: [{
				op: "ordered",
				effects: [{
					op: "removeSuspicion",
					n: 1
				}, {
					op: "gain",
					resource: "tax",
					n: 2
				}]
			}],
			set: "base"
		},
		{
			id: 2405,
			worker: "a",
			cost: null,
			price: 0,
			reward: [{
				op: "gain",
				resource: "p",
				n: 2
			}],
			set: "base"
		},
		{
			id: 2406,
			worker: "a",
			cost: null,
			price: 0,
			reward: [{
				op: "gain",
				resource: "provision",
				n: 2
			}, {
				op: "gain",
				resource: "tax",
				n: 1
			}],
			set: "base"
		},
		{
			id: 2407,
			worker: "a",
			cost: "debt",
			price: 1,
			reward: [
				{
					op: "gain",
					resource: "g",
					n: 1
				},
				{
					op: "gain",
					resource: "u",
					n: 1
				},
				{
					op: "gain",
					resource: "r",
					n: 1
				}
			],
			set: "base"
		},
		{
			id: 2408,
			worker: "u",
			cost: "provision",
			price: 1,
			reward: [{
				op: "choice",
				choices: [[{ op: "develop" }], [{
					op: "gain",
					resource: "r",
					n: 1
				}, {
					op: "gain",
					resource: "b",
					n: 1
				}]]
			}],
			set: "base"
		},
		{
			id: 2409,
			worker: "a",
			cost: null,
			price: 0,
			reward: [{ op: "pray" }],
			set: "base"
		},
		{
			id: 34400,
			worker: "a",
			cost: null,
			price: 0,
			reward: [{
				op: "workerChoice",
				colors: [
					"g",
					"u",
					"r",
					"b"
				]
			}],
			set: "promos"
		},
		{
			id: 34800,
			worker: "a",
			cost: null,
			price: 0,
			reward: [{
				op: "gain",
				resource: "y",
				n: 1
			}],
			set: "vassals"
		},
		{
			id: 38200,
			worker: "r",
			cost: null,
			price: 0,
			reward: [
				{
					op: "gain",
					resource: "silver",
					n: 1
				},
				{
					op: "gain",
					resource: "provision",
					n: 1
				},
				{
					op: "gain",
					resource: "w",
					n: 1
				},
				{
					op: "removeSuspicion",
					n: 1
				}
			],
			set: "compatible"
		},
		{
			id: 38300,
			worker: "a",
			cost: null,
			price: 0,
			reward: [{
				op: "attribute",
				city: !0
			}, { op: "pass" }],
			set: "compatible"
		},
		{
			id: 38400,
			worker: "g",
			cost: null,
			price: 0,
			reward: [{
				op: "choice",
				choices: [[{ op: "moveWorkshop" }], [{
					op: "gain",
					resource: "w",
					n: 2
				}]]
			}],
			set: "compatible"
		},
		{
			id: 38500,
			worker: "a",
			cost: null,
			price: 0,
			reward: [{
				op: "choice",
				choices: [[{ op: "dismissOwn" }], [{
					op: "gain",
					resource: "silver",
					n: 2
				}]]
			}],
			set: "compatible"
		},
		{
			id: 38600,
			worker: "a",
			cost: null,
			price: 0,
			reward: [{
				op: "choice",
				choices: [[{ op: "dismissOwn" }], [{
					op: "gain",
					resource: "silver",
					n: 2
				}]]
			}],
			set: "city"
		},
		{
			id: 38700,
			worker: "u",
			cost: null,
			price: 0,
			reward: [{
				op: "choice",
				choices: [[{
					op: "destroyDebt",
					n: 1
				}], [{
					op: "gain",
					resource: "diplomacy",
					n: 1
				}]]
			}],
			set: "city"
		},
		{
			id: 38800,
			worker: "g",
			cost: null,
			price: 0,
			reward: [{
				op: "choice",
				choices: [[{ op: "moveWorkshop" }], [{
					op: "gain",
					resource: "w",
					n: 2
				}]]
			}],
			set: "city"
		},
		{
			id: 38900,
			worker: "r",
			cost: null,
			price: 0,
			reward: [
				{
					op: "gain",
					resource: "silver",
					n: 1
				},
				{
					op: "gain",
					resource: "provision",
					n: 1
				},
				{
					op: "gain",
					resource: "w",
					n: 1
				},
				{
					op: "removeSuspicion",
					n: 1
				}
			],
			set: "city"
		},
		{
			id: 39e3,
			worker: "a",
			cost: null,
			price: 0,
			reward: [{
				op: "attribute",
				city: !0
			}, { op: "pass" }],
			set: "city"
		}
	],
	orders: [
		{
			id: 2500,
			action: "absolve",
			minimum: 5,
			set: "base"
		},
		{
			id: 2501,
			action: "fortify",
			minimum: 5,
			set: "base"
		},
		{
			id: 2502,
			action: "convert",
			minimum: 5,
			set: "base"
		},
		{
			id: 2503,
			action: "commission",
			minimum: 5,
			set: "base"
		},
		{
			id: 2504,
			action: "attack",
			minimum: 5,
			set: "base"
		},
		{
			id: 2505,
			action: "garrison",
			minimum: 5,
			set: "base"
		},
		{
			id: 34300,
			action: "paidDebt",
			minimum: 4,
			set: "promos"
		},
		{
			id: 40800,
			action: "muster",
			minimum: 5,
			set: "city"
		},
		{
			id: 40900,
			action: "negotiate",
			minimum: 5,
			set: "city"
		},
		{
			id: 30700,
			attributes: {
				influence: 12,
				strength: 4
			},
			set: "coop"
		},
		{
			id: 30701,
			attributes: {
				faith: 12,
				influence: 4
			},
			set: "coop"
		},
		{
			id: 30702,
			attributes: {
				faith: 10,
				strength: 6
			},
			set: "coop"
		},
		{
			id: 30703,
			attributes: {
				influence: 10,
				faith: 6
			},
			set: "coop"
		},
		{
			id: 30704,
			attributes: {
				strength: 12,
				faith: 4
			},
			set: "coop"
		},
		{
			id: 30705,
			attributes: {
				strength: 10,
				influence: 6
			},
			set: "coop"
		},
		{
			id: 39300,
			attributes: {
				diplomacy: 10,
				influence: 6
			},
			set: "coopCity"
		},
		{
			id: 39400,
			attributes: {
				diplomacy: 8,
				influence: 8
			},
			set: "coopCity"
		},
		{
			id: 39500,
			attributes: {
				diplomacy: 12,
				strength: 4
			},
			set: "coopCity"
		}
	],
	muster: [
		{
			id: 37900,
			tier: 3,
			worker: "p",
			cost: null,
			price: 0,
			attribute: "influence",
			minimum: 6,
			reward: [{ op: "pray" }]
		},
		{
			id: 37901,
			tier: 3,
			worker: "a",
			cost: null,
			price: 0,
			attribute: "diplomacy",
			minimum: 7,
			reward: [{
				op: "gain",
				resource: "b",
				n: 1
			}]
		},
		{
			id: 37902,
			tier: 3,
			worker: "b",
			cost: null,
			price: 0,
			attribute: "influence",
			minimum: 9,
			reward: [{
				op: "choice",
				choices: [[{ op: "moveWorkshop" }], [{
					op: "gain",
					resource: "w",
					n: 2
				}]]
			}]
		},
		{
			id: 37903,
			tier: 3,
			worker: "u",
			cost: "silver",
			price: 2,
			attribute: "diplomacy",
			minimum: 9,
			reward: [{
				op: "destroyDebt",
				n: 2
			}]
		},
		{
			id: 37904,
			tier: 3,
			worker: "b",
			cost: null,
			price: 0,
			attribute: "diplomacy",
			minimum: 8,
			reward: [{
				op: "gain",
				resource: "faith",
				n: 1
			}]
		},
		{
			id: 37905,
			tier: 3,
			worker: "a",
			cost: "provision",
			price: 1,
			attribute: "strength",
			minimum: 7,
			reward: [{
				op: "choice",
				choices: [[{ op: "moveWorkshop" }], [{
					op: "gain",
					resource: "w",
					n: 2
				}]]
			}]
		},
		{
			id: 37906,
			tier: 3,
			worker: "u",
			cost: null,
			price: 0,
			attribute: "faith",
			minimum: 9,
			reward: [{
				op: "choice",
				choices: [[{ op: "dismissOwn" }], [{
					op: "gain",
					resource: "silver",
					n: 2
				}]]
			}]
		},
		{
			id: 37907,
			tier: 3,
			worker: "p",
			cost: null,
			price: 0,
			attribute: "faith",
			minimum: 8,
			reward: [{
				op: "choice",
				choices: [[{
					op: "repay",
					n: 1
				}], [{
					op: "gain",
					resource: "tax",
					n: 2
				}]]
			}]
		},
		{
			id: 37908,
			tier: 3,
			worker: "a",
			cost: null,
			price: 0,
			attribute: "strength",
			minimum: 8,
			reward: [{
				op: "gain",
				resource: "r",
				n: 1
			}]
		},
		{
			id: 37909,
			tier: 3,
			worker: "g",
			cost: "debt",
			price: 1,
			attribute: "strength",
			minimum: 9,
			reward: [{
				op: "choice",
				choices: [[{ op: "develop" }], [{
					op: "gain",
					resource: "w",
					n: 2
				}]]
			}]
		},
		{
			id: 37910,
			tier: 3,
			worker: "a",
			cost: null,
			price: 0,
			attribute: "influence",
			minimum: 7,
			reward: [{
				op: "gain",
				resource: "g",
				n: 1
			}]
		},
		{
			id: 37911,
			tier: 3,
			worker: "r",
			cost: null,
			price: 0,
			attribute: "diplomacy",
			minimum: 6,
			reward: [{
				op: "gain",
				resource: "strength",
				n: 1
			}]
		},
		{
			id: 38e3,
			tier: 2,
			worker: "a",
			cost: null,
			price: 0,
			attribute: "faith",
			minimum: 5,
			reward: [{
				op: "gain",
				resource: "p",
				n: 1
			}]
		},
		{
			id: 38001,
			tier: 2,
			worker: "r",
			cost: null,
			price: 0,
			attribute: "faith",
			minimum: 4,
			reward: [{ op: "pray" }]
		},
		{
			id: 38002,
			tier: 2,
			worker: "b",
			cost: "silver",
			price: 1,
			attribute: "influence",
			minimum: 4,
			reward: [{
				op: "gain",
				resource: "diplomacy",
				n: 1
			}]
		},
		{
			id: 38003,
			tier: 2,
			worker: "g",
			cost: null,
			price: 0,
			attribute: "strength",
			minimum: 5,
			reward: [{
				op: "recruit",
				mode: "dismiss"
			}]
		},
		{
			id: 38004,
			tier: 2,
			worker: "a",
			cost: "silver",
			price: 1,
			attribute: "influence",
			minimum: 2,
			reward: [{
				op: "choice",
				choices: [[{
					op: "repay",
					n: 1
				}], [{
					op: "removeSuspicion",
					n: 2
				}]]
			}]
		},
		{
			id: 38005,
			tier: 2,
			worker: "g",
			cost: null,
			price: 0,
			attribute: "influence",
			minimum: 5,
			reward: [{
				op: "choice",
				choices: [[{ op: "dismissOwn" }], [{
					op: "gain",
					resource: "silver",
					n: 2
				}]]
			}]
		},
		{
			id: 38006,
			tier: 2,
			worker: "u",
			cost: null,
			price: 0,
			attribute: "strength",
			minimum: 2,
			reward: [{
				op: "gain",
				resource: "tax",
				n: 2
			}]
		},
		{
			id: 38007,
			tier: 2,
			worker: "a",
			cost: null,
			price: 0,
			attribute: "influence",
			minimum: 3,
			reward: [{
				op: "gain",
				resource: "u",
				n: 1
			}]
		},
		{
			id: 38008,
			tier: 2,
			worker: "a",
			cost: null,
			price: 0,
			attribute: "strength",
			minimum: 3,
			reward: [{
				op: "gain",
				resource: "p",
				n: 1
			}]
		},
		{
			id: 38009,
			tier: 2,
			worker: "r",
			cost: "provision",
			price: 1,
			attribute: "diplomacy",
			minimum: 2,
			reward: [{
				op: "recruit",
				mode: "hire"
			}]
		},
		{
			id: 38010,
			tier: 2,
			worker: "b",
			cost: "provision",
			price: 1,
			attribute: "diplomacy",
			minimum: 2,
			reward: [{
				op: "removeSuspicion",
				n: 3
			}]
		},
		{
			id: 38011,
			tier: 2,
			worker: "u",
			cost: "silver",
			price: 1,
			attribute: "diplomacy",
			minimum: 4,
			reward: [{
				op: "gain",
				resource: "influence",
				n: 1
			}]
		},
		{
			id: 38100,
			tier: 1,
			worker: "u",
			cost: "provision",
			price: 1,
			attribute: "strength",
			minimum: 1,
			reward: [{
				op: "gain",
				resource: "diplomacy",
				n: 1
			}]
		},
		{
			id: 38101,
			tier: 1,
			worker: "g",
			cost: null,
			price: 0,
			attribute: "diplomacy",
			minimum: 0,
			reward: [{ op: "pray" }]
		},
		{
			id: 38102,
			tier: 1,
			worker: "b",
			cost: "debt",
			price: 1,
			attribute: "strength",
			minimum: 0,
			reward: [{
				op: "recruit",
				mode: "hire"
			}]
		},
		{
			id: 38103,
			tier: 1,
			worker: "a",
			cost: null,
			price: 0,
			attribute: "diplomacy",
			minimum: 1,
			reward: [{
				op: "gain",
				resource: "silver",
				n: 2
			}]
		},
		{
			id: 38104,
			tier: 1,
			worker: "r",
			cost: null,
			price: 0,
			attribute: "influence",
			minimum: 1,
			reward: [{
				op: "choice",
				choices: [[{
					op: "repay",
					n: 1
				}], [{
					op: "gain",
					resource: "tax",
					n: 2
				}]]
			}]
		},
		{
			id: 38105,
			tier: 1,
			worker: "a",
			cost: null,
			price: 0,
			attribute: "faith",
			minimum: 1,
			reward: [{
				op: "gain",
				resource: "p",
				n: 1
			}]
		}
	],
	negotiate: [
		{
			id: 35300,
			tier: 4,
			diplomacy: 8,
			action: "convert",
			boost: 5,
			attribute: "strength",
			minimum: 7,
			icons: ["cleric"]
		},
		{
			id: 35301,
			tier: 4,
			diplomacy: 8,
			action: "absolve",
			boost: 5,
			attribute: "faith",
			minimum: 7,
			icons: ["merchant"]
		},
		{
			id: 35302,
			tier: 4,
			diplomacy: 10,
			action: "attack",
			boost: 6,
			attribute: "influence",
			minimum: 10,
			icons: ["military"]
		},
		{
			id: 35303,
			tier: 4,
			diplomacy: 10,
			action: "convert",
			boost: 6,
			attribute: "strength",
			minimum: 10,
			icons: ["military"]
		},
		{
			id: 35304,
			tier: 4,
			diplomacy: 9,
			action: "fortify",
			boost: 5,
			attribute: "strength",
			minimum: 9,
			icons: ["farmer"]
		},
		{
			id: 35305,
			tier: 4,
			diplomacy: 9,
			action: "commission",
			boost: 5,
			attribute: "influence",
			minimum: 9,
			icons: ["farmer"]
		},
		{
			id: 35306,
			tier: 4,
			diplomacy: 9,
			action: "garrison",
			boost: 5,
			attribute: "faith",
			minimum: 9,
			icons: ["merchant"]
		},
		{
			id: 35307,
			tier: 4,
			diplomacy: 8,
			action: "attack",
			boost: 5,
			attribute: "influence",
			minimum: 7,
			icons: ["farmer"]
		},
		{
			id: 35308,
			tier: 4,
			diplomacy: 10,
			action: "absolve",
			boost: 6,
			attribute: "faith",
			minimum: 10,
			icons: ["cleric"]
		},
		{
			id: 35400,
			tier: 3,
			diplomacy: 7,
			action: "garrison",
			boost: 4,
			attribute: "faith",
			minimum: 6,
			icons: ["military"]
		},
		{
			id: 35401,
			tier: 3,
			diplomacy: 6,
			action: "attack",
			boost: 4,
			attribute: "influence",
			minimum: 5,
			icons: ["military"]
		},
		{
			id: 35402,
			tier: 3,
			diplomacy: 5,
			action: "commission",
			boost: 4,
			attribute: "influence",
			minimum: 3,
			icons: ["cleric", "farmer"]
		},
		{
			id: 35403,
			tier: 3,
			diplomacy: 5,
			action: "fortify",
			boost: 4,
			attribute: "strength",
			minimum: 4,
			icons: ["merchant", "farmer"]
		},
		{
			id: 35404,
			tier: 3,
			diplomacy: 6,
			action: "convert",
			boost: 3,
			attribute: "strength",
			minimum: 5,
			icons: ["cleric"]
		},
		{
			id: 35405,
			tier: 3,
			diplomacy: 5,
			action: "garrison",
			boost: 4,
			attribute: "faith",
			minimum: 4,
			icons: ["merchant", "military"]
		},
		{
			id: 35406,
			tier: 3,
			diplomacy: 7,
			action: "fortify",
			boost: 4,
			attribute: "strength",
			minimum: 6,
			icons: ["merchant"]
		},
		{
			id: 35407,
			tier: 3,
			diplomacy: 7,
			action: "commission",
			boost: 4,
			attribute: "influence",
			minimum: 6,
			icons: ["cleric"]
		},
		{
			id: 35500,
			tier: 2,
			diplomacy: 4,
			action: "attack",
			boost: 4,
			attribute: "influence",
			minimum: 4,
			icons: ["military", "farmer"]
		},
		{
			id: 35501,
			tier: 2,
			diplomacy: 3,
			action: "fortify",
			boost: 2,
			attribute: "strength",
			minimum: 3,
			icons: ["farmer"]
		},
		{
			id: 35502,
			tier: 2,
			diplomacy: 4,
			action: "convert",
			boost: 4,
			attribute: "strength",
			minimum: 3,
			icons: ["cleric", "military"]
		},
		{
			id: 35503,
			tier: 2,
			diplomacy: 2,
			action: "absolve",
			boost: 2,
			attribute: "faith",
			minimum: 2,
			icons: ["merchant"]
		},
		{
			id: 35504,
			tier: 2,
			diplomacy: 3,
			action: "garrison",
			boost: 3,
			attribute: "faith",
			minimum: 3,
			icons: ["merchant"]
		},
		{
			id: 35505,
			tier: 2,
			diplomacy: 4,
			action: "absolve",
			boost: 4,
			attribute: "faith",
			minimum: 3,
			icons: ["merchant", "cleric"]
		},
		{
			id: 35506,
			tier: 2,
			diplomacy: 2,
			action: "attack",
			boost: 3,
			attribute: "influence",
			minimum: 3,
			icons: ["military"]
		},
		{
			id: 35507,
			tier: 2,
			diplomacy: 3,
			action: "commission",
			boost: 2,
			attribute: "influence",
			minimum: 2,
			icons: ["farmer"]
		},
		{
			id: 35508,
			tier: 2,
			diplomacy: 2,
			action: "convert",
			boost: 2,
			attribute: "strength",
			minimum: 2,
			icons: ["cleric"]
		},
		{
			id: 35600,
			tier: 1,
			diplomacy: 0,
			action: "garrison",
			boost: 2,
			attribute: "faith",
			minimum: 1,
			icons: ["military"]
		},
		{
			id: 35601,
			tier: 1,
			diplomacy: 0,
			action: "fortify",
			boost: 1,
			attribute: "strength",
			minimum: 1,
			icons: ["farmer"]
		},
		{
			id: 35602,
			tier: 1,
			diplomacy: 0,
			action: "absolve",
			boost: 2,
			attribute: "faith",
			minimum: 2,
			icons: ["merchant"]
		},
		{
			id: 35603,
			tier: 1,
			diplomacy: 0,
			action: "commission",
			boost: 1,
			attribute: "influence",
			minimum: 1,
			icons: ["cleric"]
		}
	],
	regions: [
		{
			id: 0,
			region: 0,
			players: 2,
			reward: [{
				op: "recruit",
				mode: "hire"
			}]
		},
		{
			id: 1,
			region: 0,
			players: 2,
			reward: [{
				op: "gain",
				resource: "silver",
				n: 2
			}]
		},
		{
			id: 2,
			region: 0,
			players: 3,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}]
		},
		{
			id: 3,
			region: 0,
			players: 4,
			reward: [{
				op: "removeSuspicion",
				n: 1
			}]
		},
		{
			id: 4,
			region: 1,
			players: 2,
			reward: [{
				op: "recruit",
				mode: "hire"
			}]
		},
		{
			id: 5,
			region: 1,
			players: 2,
			reward: [{
				op: "gain",
				resource: "g",
				n: 1
			}]
		},
		{
			id: 6,
			region: 1,
			players: 2,
			reward: [{
				op: "gain",
				resource: "silver",
				n: 2
			}]
		},
		{
			id: 7,
			region: 1,
			players: 2,
			reward: [{
				op: "removeSuspicion",
				n: 1
			}]
		},
		{
			id: 8,
			region: 1,
			players: 3,
			reward: [{
				op: "gain",
				resource: "silver",
				n: 2
			}]
		},
		{
			id: 9,
			region: 1,
			players: 3,
			reward: [{
				op: "removeSuspicion",
				n: 1
			}]
		},
		{
			id: 10,
			region: 1,
			players: 4,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}]
		},
		{
			id: 11,
			region: 2,
			players: 2,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}]
		},
		{
			id: 12,
			region: 2,
			players: 2,
			reward: [{
				op: "gain",
				resource: "u",
				n: 1
			}]
		},
		{
			id: 13,
			region: 2,
			players: 2,
			reward: [{
				op: "gain",
				resource: "silver",
				n: 2
			}]
		},
		{
			id: 14,
			region: 2,
			players: 2,
			reward: [{ op: "pray" }]
		},
		{
			id: 15,
			region: 2,
			players: 2,
			reward: [{
				op: "gain",
				resource: "g",
				n: 1
			}]
		},
		{
			id: 16,
			region: 2,
			players: 2,
			reward: [{
				op: "gain",
				resource: "r",
				n: 1
			}]
		},
		{
			id: 17,
			region: 2,
			players: 3,
			reward: [{
				op: "recruit",
				mode: "hire"
			}]
		},
		{
			id: 18,
			region: 2,
			players: 3,
			reward: [{
				op: "repay",
				n: 1
			}]
		},
		{
			id: 19,
			region: 2,
			players: 4,
			reward: [{
				op: "gain",
				resource: "silver",
				n: 2
			}]
		},
		{
			id: 20,
			region: 3,
			players: 2,
			reward: [{ op: "pray" }]
		},
		{
			id: 21,
			region: 3,
			players: 2,
			reward: [{
				op: "gain",
				resource: "u",
				n: 1
			}]
		},
		{
			id: 22,
			region: 3,
			players: 2,
			reward: [{
				op: "gain",
				resource: "b",
				n: 1
			}]
		},
		{
			id: 23,
			region: 3,
			players: 2,
			reward: [{
				op: "repay",
				n: 1
			}]
		},
		{
			id: 24,
			region: 3,
			players: 2,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "g",
				n: 1
			}]
		},
		{
			id: 25,
			region: 3,
			players: 2,
			reward: [{
				op: "gain",
				resource: "silver",
				n: 2
			}]
		},
		{
			id: 26,
			region: 3,
			players: 3,
			reward: [{ op: "pray" }]
		},
		{
			id: 27,
			region: 3,
			players: 3,
			reward: [{
				op: "gain",
				resource: "silver",
				n: 2
			}]
		},
		{
			id: 28,
			region: 3,
			players: 4,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 1
			}]
		},
		{
			id: 29,
			region: 4,
			players: 2,
			reward: [{ op: "pray" }]
		},
		{
			id: 30,
			region: 4,
			players: 2,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "r",
				n: 1
			}]
		},
		{
			id: 31,
			region: 4,
			players: 2,
			reward: [{
				op: "repay",
				n: 1
			}]
		},
		{
			id: 32,
			region: 4,
			players: 2,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "u",
				n: 1
			}]
		},
		{
			id: 33,
			region: 4,
			players: 2,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "b",
				n: 1
			}]
		},
		{
			id: 34,
			region: 4,
			players: 3,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 1
			}]
		},
		{
			id: 35,
			region: 4,
			players: 4,
			reward: [{
				op: "repay",
				n: 1
			}]
		},
		{
			id: 36,
			region: 5,
			players: 2,
			reward: [{
				op: "repay",
				n: 1
			}]
		},
		{
			id: 37,
			region: 5,
			players: 3,
			reward: [{ op: "pray" }]
		},
		{
			id: 38,
			region: 5,
			players: 4,
			reward: [{
				op: "gain",
				resource: "w",
				n: 1
			}, {
				op: "gain",
				resource: "w",
				n: 1
			}]
		},
		{
			id: 39,
			region: 6,
			players: 2,
			reward: [{
				op: "gain",
				resource: "g",
				n: 1
			}, {
				op: "gain",
				resource: "u",
				n: 1
			}]
		},
		{
			id: 40,
			region: 6,
			players: 2,
			reward: [{
				op: "gain",
				resource: "faith",
				n: 1
			}]
		},
		{
			id: 41,
			region: 6,
			players: 3,
			reward: [{
				op: "repay",
				n: 1
			}]
		}
	],
	threats: [
		{
			id: 901,
			target: "Repay Debt.",
			penalty: "All players gain 1 Suspicion in turn order.",
			workersByPlayers: [
				3,
				4,
				5
			],
			set: "base"
		},
		{
			id: 909,
			target: "Develop.",
			penalty: "All players lose 1 Honour or lose 1 Worker (if possible).",
			workersByPlayers: [
				3,
				4,
				5
			],
			set: "base"
		},
		{
			id: 908,
			target: "Garisson.",
			penalty: "All players lose 1 Honour or remove 1 Workshop from their board (if possible).",
			workersByPlayers: [
				3,
				4,
				5
			],
			set: "base"
		},
		{
			id: 907,
			target: "Absolve.",
			penalty: "All players lose 1 Honour or 1 Faith.",
			workersByPlayers: [
				3,
				4,
				5
			],
			set: "base"
		},
		{
			id: 906,
			target: "Attack.",
			penalty: "All players lose 1 Honour or 1 Provision.",
			workersByPlayers: [
				3,
				4,
				5
			],
			set: "base"
		},
		{
			id: 900,
			target: "Recruit or Discard Townsfolk.",
			penalty: "All players gain 1 Debt.",
			workersByPlayers: [
				3,
				4,
				5
			],
			set: "base"
		},
		{
			id: 905,
			target: "Fortify.",
			penalty: "All players lose 1 Honour or 1 Strength.",
			workersByPlayers: [
				3,
				4,
				5
			],
			set: "base"
		},
		{
			id: 904,
			target: "Convert.",
			penalty: "All players lose 1 Honour or 1 Silver.",
			workersByPlayers: [
				3,
				4,
				5
			],
			set: "base"
		},
		{
			id: 903,
			target: "Commission.",
			penalty: "All players lose 1 Honour or 1 Influence.",
			workersByPlayers: [
				3,
				4,
				5
			],
			set: "base"
		},
		{
			id: 902,
			target: "Pray.",
			penalty: "All players gain 1 Suspicion in turn order.",
			workersByPlayers: [
				3,
				4,
				5
			],
			set: "base"
		},
		{
			id: 39100,
			target: "Enlist (not Entrust) Negotation cards.",
			penalty: "All players lose 1 Honour or destroy 1 of their Recruited Townsfolk.",
			workersByPlayers: [
				3,
				4,
				5
			],
			set: "city"
		},
		{
			id: 39200,
			target: "Muster.",
			penalty: "All players lose 1 Honour or 1 Diplomacy.",
			workersByPlayers: [
				3,
				4,
				5
			],
			set: "city"
		}
	],
	boards: {
		attributes: [
			0,
			0,
			1,
			1,
			3,
			5,
			6,
			6,
			9,
			11,
			13,
			16,
			20
		],
		wallMinimum: [
			0,
			1,
			3,
			5,
			7,
			8,
			9
		],
		jarMinimum: [
			0,
			1,
			3,
			5,
			7,
			8,
			9
		],
		monkFood: [
			1,
			1,
			1,
			2,
			2,
			3,
			3
		],
		outpostFood: [
			1,
			1,
			1,
			2,
			2,
			3,
			3
		],
		wallFood: [
			1,
			1,
			1,
			2,
			2,
			3,
			3
		],
		jarSilver: [
			1,
			2,
			2,
			2,
			3,
			3,
			3
		],
		convertSilver: [
			0,
			1,
			2,
			2,
			2,
			3,
			3
		],
		developWorkers: [
			"w",
			"w",
			"g",
			"g",
			"u",
			"u",
			"r",
			"b"
		],
		developVp: [
			0,
			0,
			0,
			0,
			0,
			0,
			1,
			3,
			6
		],
		monkVp: [
			0,
			0,
			0,
			0,
			0,
			2,
			5,
			9
		],
		outpostVp: [
			0,
			0,
			0,
			0,
			0,
			2,
			5,
			9
		],
		wallVp: [
			0,
			0,
			0,
			0,
			0,
			1,
			3,
			6
		],
		jarVp: [
			0,
			0,
			0,
			0,
			0,
			1,
			3,
			6
		],
		iconSetVp: [
			0,
			0,
			2,
			5,
			9
		],
		townSilver: [
			3,
			2,
			2,
			1,
			0
		],
		cityTownSilver: [
			3,
			3,
			2,
			2,
			1,
			0
		],
		cityTownDeckSilver: 3,
		negotiateSilver: [
			2,
			1,
			1
		],
		cityOutsiderFaith: [
			0,
			2,
			4,
			6,
			8,
			10,
			12
		],
		cityOutsiderStrength: [
			1,
			3,
			5,
			7,
			9,
			11,
			13
		]
	},
	taverns: [
		{
			id: 40711,
			workers: [
				"p",
				"p",
				"g",
				"r"
			],
			set: "base"
		},
		{
			id: 40716,
			workers: [
				"u",
				"u",
				"b",
				"b"
			],
			set: "base"
		},
		{
			id: 40713,
			workers: [
				"w",
				"p",
				"w",
				"b"
			],
			set: "base"
		},
		{
			id: 40717,
			workers: [
				"w",
				"g",
				"g",
				"g"
			],
			set: "base"
		},
		{
			id: 40712,
			workers: [
				"p",
				"p",
				"u",
				"r"
			],
			set: "base"
		},
		{
			id: 40715,
			workers: [
				"w",
				"p",
				"w",
				"r"
			],
			set: "base"
		},
		{
			id: 40720,
			workers: [
				"w",
				"w",
				"u",
				"u"
			],
			set: "base"
		},
		{
			id: 40723,
			workers: [
				"g",
				"g",
				"u",
				"r"
			],
			set: "base"
		},
		{
			id: 40719,
			workers: [
				"u",
				"r",
				"b",
				"b"
			],
			set: "base"
		},
		{
			id: 40708,
			workers: [
				"g",
				"u",
				"b",
				"b"
			],
			set: "base"
		},
		{
			id: 40714,
			workers: [
				"w",
				"w",
				"r",
				"r"
			],
			set: "base"
		},
		{
			id: 40718,
			workers: [
				"r",
				"b",
				"b",
				"b"
			],
			set: "base"
		},
		{
			id: 40709,
			workers: [
				"g",
				"r",
				"b",
				"b"
			],
			set: "base"
		},
		{
			id: 40703,
			workers: [
				"w",
				"w",
				"g",
				"b"
			],
			set: "base"
		},
		{
			id: 40707,
			workers: [
				"w",
				"u",
				"b",
				"b"
			],
			set: "base"
		},
		{
			id: 40710,
			workers: [
				"w",
				"p",
				"p",
				"r"
			],
			set: "base"
		},
		{
			id: 40721,
			workers: [
				"p",
				"g",
				"g",
				"b"
			],
			set: "base"
		},
		{
			id: 40722,
			workers: [
				"g",
				"g",
				"u",
				"u"
			],
			set: "base"
		},
		{
			id: 40702,
			workers: [
				"p",
				"g",
				"u",
				"r"
			],
			set: "base"
		},
		{
			id: 40706,
			workers: [
				"p",
				"g",
				"r",
				"r"
			],
			set: "base"
		},
		{
			id: 40705,
			workers: [
				"w",
				"p",
				"r",
				"r"
			],
			set: "base"
		},
		{
			id: 40704,
			workers: [
				"p",
				"u",
				"r",
				"r"
			],
			set: "base"
		},
		{
			id: 40700,
			workers: [
				"p",
				"g",
				"u",
				"u"
			],
			set: "base"
		},
		{
			id: 40701,
			workers: [
				"w",
				"g",
				"u",
				"u"
			],
			set: "base"
		},
		{
			id: 40605,
			workers: [
				"w",
				"y",
				"g",
				"g"
			],
			set: "vassals"
		},
		{
			id: 40607,
			workers: [
				"w",
				"y",
				"u",
				"u"
			],
			set: "vassals"
		},
		{
			id: 40606,
			workers: [
				"w",
				"y",
				"r",
				"r"
			],
			set: "vassals"
		},
		{
			id: 40600,
			workers: [
				"w",
				"y",
				"w",
				"b"
			],
			set: "vassals"
		},
		{
			id: 40604,
			workers: [
				"w",
				"y",
				"b",
				"b"
			],
			set: "vassals"
		},
		{
			id: 40601,
			workers: [
				"w",
				"y",
				"w",
				"g"
			],
			set: "vassals"
		},
		{
			id: 40602,
			workers: [
				"w",
				"y",
				"w",
				"r"
			],
			set: "vassals"
		},
		{
			id: 40603,
			workers: [
				"w",
				"y",
				"w",
				"u"
			],
			set: "vassals"
		},
		{
			id: 34500,
			workers: [
				"w",
				"p",
				"p",
				"p"
			],
			set: "tavernPromo"
		}
	],
	suspicion: {
		shared: [
			2701,
			2701,
			2700,
			2700,
			2700,
			2700,
			2700,
			2700,
			2700,
			2700,
			2701,
			2701,
			2701,
			2702,
			2702,
			2701,
			2702,
			2702,
			2702,
			2702,
			2702,
			2702,
			2702,
			2702
		],
		personal: [
			34700,
			2701,
			2700,
			2700,
			2700,
			2700,
			41500,
			41600,
			2702,
			2702,
			2702,
			2702,
			2702,
			2701,
			2701
		],
		cards: {
			2700: { tax: 0 },
			2701: { tax: 1 },
			2702: { tax: 2 },
			34700: {
				tax: 0,
				provision: 2
			},
			41500: {
				tax: 0,
				provision: 1
			},
			41600: {
				tax: 0,
				discard: !0
			}
		}
	},
	soloSchemes: [
		"order",
		"order",
		"order",
		"recruit",
		"pray",
		"conspire",
		"commission",
		"fortify",
		"garrison",
		"absolve",
		"attack",
		"convert"
	],
	soloSchemeIds: [
		2608,
		2604,
		2609,
		2605,
		2610,
		2606,
		2607,
		2603,
		2602,
		2600,
		2600,
		2600
	],
	coopStarting: [
		{
			id: 31900,
			action: "commission"
		},
		{
			id: 32e3,
			action: "garrison"
		},
		{
			id: 32100,
			action: "fortify"
		},
		{
			id: 32200,
			action: "absolve"
		}
	]
}, y = (e) => Object.fromEntries(e.map((e) => [e.id, e])), b = y(v.paladins), x = y(v.townsfolk), S = y(v.outsiders), C = y(v.walls), w = y(v.favours), T = y(v.orders), E = y(v.muster), D = y(v.negotiate), O = y(v.threats), k = {
	id: "paladinsofthewestkingdom",
	tier: "alpha",
	nameKey: "games.paladinsofthewestkingdom.name",
	descKey: "games.paladinsofthewestkingdom.desc",
	rulesKey: "games.paladinsofthewestkingdom.rules",
	icon: "🏰",
	iconImg: "games/paladinsofthewestkingdom.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	mechanics: ["worker-placement", "engine-building"],
	interactionTags: [],
	accent: "#327b64",
	hotseat: "cover",
	search: {
		py: "xi guo sheng qi shi",
		init: "xgsqs"
	},
	releasedAt: "2026-11-10T23:55:00+08:00"
}, A = [
	"w",
	"g",
	"u",
	"r",
	"b",
	"p",
	"y"
], j = [
	"influence",
	"faith",
	"strength",
	"diplomacy"
], M = [
	"commission",
	"fortify",
	"garrison",
	"absolve",
	"attack",
	"convert",
	"muster",
	"negotiate"
], N = {
	effect: 340,
	action: 620,
	round: 700,
	inquisition: 850
}, P = "$paladins-automa", ie = (e) => Math.max(0, Math.min(12, e)), F = (e, t) => e.counts[t] ?? 0, I = (e) => e === P;
function L(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.rngCursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function R(e, ...t) {
	e.queue.unshift(...t);
}
function z(e, t) {
	return t.map((t) => ({
		...t,
		rid: e
	}));
}
function B(e, t, n = 1) {
	return {
		op: "gain",
		rid: e,
		resource: t,
		n
	};
}
function V(e, t) {
	return {
		op: "trigger",
		rid: e,
		key: t
	};
}
function H(e, t, n, r, i = !1) {
	e.serial++, e.prompt = {
		rid: t,
		title: n,
		choices: r.map((t, n) => ({
			...t,
			id: `${e.serial}:${n}`
		})),
		cancel: i
	};
}
function ae(e, t, n, r = {}) {
	e.journal.push({
		rid: t,
		kind: n,
		...r
	}), e.journal.length > 40 && e.journal.shift();
}
function oe(e) {
	return e.paladin == null ? null : b[e.reused ?? e.paladin];
}
function se(e, t) {
	return oe(e)?.ability === t;
}
function ce(e, t, n = {}) {
	return e.attributes[t] + (oe(e)?.attributes[j.indexOf(t)] ?? 0) + (n[t] ?? 0);
}
function le(e, t) {
	return e.townsfolk.some((e) => x[e].ability === t);
}
function ue(e, t, n) {
	e.attributes[t] = ie(e.attributes[t] + n), e.stack = [...e.stack.filter((e) => e !== t), t];
}
function de(e) {
	return e.order.length <= 2 ? 5 : e.order.length === 3 ? 7 : 8;
}
function U(e, t) {
	return v.boards[e][t] ?? 0;
}
function fe(e, t, n) {
	let r = t.suspicion.splice(Math.max(0, t.suspicion.length - n), n);
	return (e.config.personalSuspicion ? t.personalDiscard : e.decks.suspicionDiscard).push(...r), r.length;
}
function pe(e, t) {
	let n = e.order.indexOf(t);
	for (let t = 1; t <= e.order.length; t++) {
		let r = e.order[(n + t) % e.order.length];
		if (!e.players[r].passed) return r;
	}
	return null;
}
function me(e, t) {
	return e.townsfolk.filter((e) => x[e].trigger === t);
}
function he(e, t, n, r) {
	let i = e.market[t], a = n === "left" ? Array.from({ length: r }, (e, t) => t) : Array.from({ length: r }, (e, t) => i.length - 1 - t);
	for (let e of a) i[e] = null;
	let o = i.filter((e) => e != null), s = Array.from({ length: i.length - o.length }, () => e.decks[t].shift() ?? null);
	e.market[t] = n === "right" ? [...s, ...o] : [...o, ...s];
}
//#endregion
//#region src/game/planning.ts
var ge = {
	commission: [
		"g",
		"a",
		"b"
	],
	fortify: [
		"u",
		"a",
		"g"
	],
	garrison: [
		"u",
		"a",
		"r"
	],
	absolve: [
		"b",
		"a",
		"u"
	],
	attack: [
		"g",
		"a",
		"r"
	],
	convert: [
		"r",
		"a",
		"b"
	],
	muster: [
		"b",
		"a",
		"g"
	],
	negotiate: [
		"r",
		"a",
		"u"
	]
}, _e = {
	commission: "faith",
	fortify: "influence",
	garrison: "strength",
	absolve: "influence",
	attack: "strength",
	convert: "faith"
}, ve = (e) => ({ [_e[D[e].action]]: D[e].boost }), ye = [
	[{
		op: "recruit",
		mode: "hire"
	}],
	[{
		op: "removeSuspicion",
		n: 1
	}],
	[{
		op: "repay",
		n: 1
	}],
	[{ op: "pray" }],
	[B("", "faith")],
	[B("", "w")],
	[{
		op: "removeSuspicion",
		n: 1
	}],
	[{
		op: "repay",
		n: 1
	}],
	[{ op: "pray" }],
	[B("", "provision", 2)]
];
function be(e, t, n, r, i) {
	let a = e.players[t];
	return n in ge ? ge[n].map((e, t) => a.workshops.some((e) => e.action === n && e.slot === t) ? "-" : e) : n === "develop" ? ["a", "a"] : n === "recruit" ? r === "hire" ? ["a", "r"] : ["a"] : n === "trade" ? r === "double" ? ["a", "u"] : ["a"] : n === "hunt" ? r === "double" ? ["a", "g"] : ["a"] : n === "pray" ? ["b"] : n === "honour" ? [a.honourWorker] : n === "favour" ? [w[i].worker] : n === "musterFavour" ? [E[i].worker] : ["a"];
}
function xe(e, t, n, r) {
	let i = e.players[t.rid];
	return I(i.rid) || r === "a" || n === r || n === "p" ? !0 : n === "y" ? r !== "p" : n === "w" ? se(i, "whiteWild") ? !0 : le(i, `whiteAs${{
		g: "Scouts",
		u: "Merchants",
		r: "Fighters",
		b: "Clerics"
	}[r]}`) : !1;
}
function Se(e) {
	return e.requirements.filter((e) => e !== "-");
}
function Ce(e, t, n = t.workers) {
	if (t.free) return [[]];
	let r = Se(t);
	if (n.length === r.length) return [n];
	let i = e.players[t.rid], a = [];
	for (let o of A) i.workers[o] <= n.filter((e) => e === o).length || !xe(e, t, o, r[n.length]) || a.push(...Ce(e, t, [...n, o]));
	return a;
}
function we(e, t) {
	return F(e.players[t.recipient ?? t.rid], t.action);
}
function Te(e, t) {
	let n = e.config.city ? v.boards.cityTownSilver : v.boards.townSilver, r = e.market.townsfolk.flatMap((e, r) => e == null ? [] : [{
		key: `town:${r}`,
		label: t.mode ?? "hire",
		card: e,
		index: r,
		mode: t.mode,
		silver: n[r],
		debtAllowed: r < 2
	}]);
	return e.config.city && e.decks.townsfolk[0] != null && r.push({
		key: "town:deck",
		label: t.mode ?? "hire",
		card: e.decks.townsfolk[0],
		index: -1,
		mode: t.mode,
		silver: 3,
		debtAllowed: !0
	}), r;
}
function Ee(e, t) {
	let n = e.players[t.recipient ?? t.rid], r = t.action, i = we(e, t);
	if (r === "recruit") return Te(e, t);
	if (r === "develop") return n.developed >= 8 && t.mode !== "extraWorkshop" ? [] : M.filter((t) => e.config.city || !["muster", "negotiate"].includes(t)).flatMap((e) => [0, 1].flatMap((t) => n.workshops.some((n) => n.action === e && n.slot === t) ? [] : [{
		key: `${e}:${t}`,
		label: e,
		action: e,
		index: t,
		silver: 4
	}]));
	if (r === "commission" || r === "garrison") return i >= 7 ? [] : v.regions.flatMap((t) => t.players > e.order.length || t.region === 6 && !e.config.city || e.regions[t.id] ? [] : [{
		key: `region:${t.id}`,
		label: r,
		index: t.id,
		attribute: r === "commission" ? "faith" : "strength",
		minimum: t.region * 2 + +(r === "garrison"),
		provision: U(r === "commission" ? "monkFood" : "outpostFood", i)
	}]);
	if (r === "fortify") return i >= 7 || !e.decks.walls.length ? [] : [{
		key: "wall",
		label: r,
		attribute: "influence",
		minimum: U("wallMinimum", i),
		provision: U("wallFood", i)
	}];
	if (r === "absolve") return i >= 7 ? [] : ye.flatMap((e, t) => n.jars.includes(t) ? [] : [{
		key: `jar:${t}`,
		label: r,
		index: t,
		attribute: "influence",
		minimum: U("jarMinimum", i),
		silver: U("jarSilver", i)
	}]);
	if (r === "attack" || r === "convert") {
		if (r === "convert" && i >= 7) return [];
		let t = e.market.outsiders.map((e, t) => ({
			card: e,
			i: t
		}));
		return e.config.city && t.push({
			card: e.decks.outsiders[0] ?? null,
			i: 6
		}), t.flatMap(({ card: e, i: t }) => e == null ? [] : [{
			key: `outsider:${t}`,
			label: r,
			card: e,
			index: t,
			attribute: r === "attack" ? "strength" : "faith",
			minimum: t * 2 + +(r === "attack"),
			silver: r === "convert" ? U("convertSilver", i) : 0
		}]);
	}
	if (r === "pray") return Object.entries(n.placed).filter(([, e]) => e.some((e) => e != null)).map(([e]) => ({
		key: e,
		label: e,
		silver: 2
	}));
	if (r === "favour") {
		let n = e.favours.indexOf(t.card), r = e.favourWorkers[n]?.length ?? 0;
		if (n < 0 || n >= e.round - 2 || r && !e.config.cooperative || r > e.players[t.rid].honour) return [];
		let i = w[t.card];
		return [{
			key: `favour:${n}`,
			label: "favour",
			card: i.id,
			index: n,
			silver: i.cost === "silver" ? i.price : 0,
			provision: i.cost === "provision" ? i.price : 0,
			mode: i.cost === "debt" ? "debt" : void 0
		}];
	}
	if (r === "musterFavour") {
		let n = E[t.card];
		return !e.muster.some((e) => e[0] === n.id) || (e.musterWorkers[n.id]?.length ?? 0) > 0 ? [] : [{
			key: `muster:${n.id}`,
			label: "musterFavour",
			card: n.id,
			silver: n.cost === "silver" ? n.price : 0,
			provision: n.cost === "provision" ? n.price : 0,
			mode: n.cost === "debt" ? "debt" : void 0
		}];
	}
	if (r === "muster") {
		let t = [];
		for (let n = 0; n < 4; n++) {
			let i = Math.abs(n - e.diplomat);
			if (i === 0) continue;
			let a = e.muster[n][0];
			a != null && t.push({
				key: `muster:${a}`,
				label: r,
				card: a,
				index: n,
				provision: i,
				attribute: E[a].attribute,
				minimum: E[a].minimum
			});
		}
		return t;
	}
	return r === "negotiate" ? [...e.market.negotiate.map((e, t) => ({
		card: e,
		i: t
	})), {
		card: e.decks.negotiate[0] ?? null,
		i: -1
	}].flatMap(({ card: e, i: t }) => {
		if (e == null) return [];
		let n = D[e], r = t < 0 ? 3 : [
			2,
			1,
			1
		][t];
		return [{
			key: `enlist:${t}`,
			label: "enlist",
			mode: "enlist",
			card: e,
			index: t,
			silver: r,
			debtAllowed: t < 0,
			attribute: n.attribute,
			minimum: n.minimum
		}, {
			key: `entrust:${t}`,
			label: "entrust",
			mode: "entrust",
			card: e,
			index: t,
			silver: r,
			debtAllowed: t < 0,
			attribute: "diplomacy",
			minimum: n.diplomacy
		}];
	}) : r === "order" ? e.orders.slice(0, Math.min(3, e.round)).flatMap((t, r) => {
		if (e.orderOwners[r]) return [];
		let i = T[t].attributes ?? {};
		return Object.entries(i).every(([t, r]) => ce(n, t) >= r + (e.round === 7 ? 2 : 0)) ? [{
			key: `order:${r}`,
			label: "order",
			card: t,
			index: r
		}] : [];
	}) : [{
		key: r,
		label: r,
		silver: +(r === "honour" && n.honourWorker !== "r"),
		provision: +(r === "honour" && n.honourWorker === "r")
	}];
}
function W(e, t, n) {
	let r = e.players[t.rid], i = t.action, a = t.free || I(r.rid), o = n.silver ?? 0, s = n.provision ?? 0, c = oe(r)?.ability;
	(c === "recruitFree" && i === "recruit" || c === "absolveFree" && i === "absolve" || c === "convertFree" && i === "convert" || c === "prayFree" && i === "pray" || c === "negotiateFree" && i === "negotiate") && (o = 0), c === "developDiscount" && i === "develop" && (o = Math.max(0, o - 2)), (c === "fortifyFree" && i === "fortify" || c === "commissionFree" && i === "commission" || c === "garrisonFree" && i === "garrison" || c === "musterFree" && i === "muster") && (s = 0), a && (o = 0, s = 0);
	let l = n.attribute ? Math.max(0, (n.minimum ?? 0) - ce(r, n.attribute, t.bonus)) : 0, u = n.attribute && le(r, `provisionBoost${n.attribute[0].toUpperCase()}${n.attribute.slice(1)}`) && !I(r.rid) ? Math.ceil(l / 2) : 0, d = [];
	for (let e = 0; e <= u; e++) {
		let u = Math.max(0, l - e * 2);
		if (u > 0 && (i !== "attack" || a)) continue;
		let f = Math.ceil(u / 2), p = o + f;
		c === "silverDiscount" && p > 0 && p--;
		let m = s + e, h = t.workers.filter((e) => e === "y").length;
		for (let e = 0; e <= h; e++) {
			let t = {
				silver: Math.max(0, p - e),
				provision: Math.max(0, m - (h - e)),
				debts: +(n.mode === "debt" && !a)
			};
			r.silver >= t.silver && r.provision >= t.provision && d.push(t), !a && n.debtAllowed && r.provision >= t.provision && d.push({
				silver: 0,
				provision: t.provision,
				debts: 1
			});
		}
		!a && c === "costDebt" && (p > 0 || m > 0) && d.push({
			silver: 0,
			provision: 0,
			debts: 1
		});
	}
	return d.filter((e, t) => !d.slice(0, t).some((t) => e.silver === t.silver && e.provision === t.provision && e.debts === t.debts));
}
function De(e, t) {
	return Ee(e, t).filter((n) => W(e, t, n).length && (n.mode !== "entrust" || Oe(e, t.rid, D[n.card].action, ve(n.card))));
}
function Oe(e, t, n, r, i) {
	let a = {
		rid: t,
		action: n,
		free: !0,
		requirements: [],
		workers: [],
		bonus: r,
		mode: i
	};
	return Ee(e, a).some((t) => W(e, a, t).length);
}
function ke(e, t) {
	return !t.free && ![
		"favour",
		"musterFavour",
		"order"
	].includes(t.action) && e.players[t.rid].placed[t.action]?.some((e) => e != null) ? !1 : Ce(e, t).some((n) => De(e, {
		...t,
		workers: n
	}).length > 0);
}
function Ae(e, t) {
	let n = [
		["develop"],
		["recruit", "dismiss"],
		["recruit", "hire"],
		["pray"],
		["trade"],
		["trade", "double"],
		["hunt"],
		["hunt", "double"],
		["conspire"],
		...M.filter((t) => e.config.city || !["muster", "negotiate"].includes(t)).map((e) => [e])
	];
	e.config.cooperative && n.push(["honour"], ["order"]);
	let r = n.map(([n, r]) => ({
		rid: t,
		action: n,
		mode: r,
		workers: [],
		requirements: be(e, t, n, r)
	}));
	return e.favours.slice(0, Math.max(0, e.round - 2)).forEach((n) => r.push({
		rid: t,
		action: "favour",
		card: n,
		workers: [],
		requirements: be(e, t, "favour", void 0, n)
	})), e.config.city && e.muster.forEach((n) => {
		let i = n[0];
		i != null && r.push({
			rid: t,
			action: "musterFavour",
			card: i,
			workers: [],
			requirements: be(e, t, "musterFavour", void 0, i)
		});
	}), r.filter((t) => e.config.cooperative && [
		"develop",
		"recruit",
		"pray",
		"trade",
		"hunt",
		"conspire",
		"honour"
	].includes(t.action) ? e.humans.some((n) => ke(e, {
		...t,
		recipient: n
	})) : ke(e, t));
}
function je(e, t) {
	if (e.plan = t, e.config.cooperative && !t.recipient && [
		"develop",
		"recruit",
		"pray",
		"trade",
		"hunt",
		"conspire",
		"honour"
	].includes(t.action) && !t.free) {
		H(e, t.rid, "chooseRecipient", e.humans.filter((n) => ke(e, {
			...t,
			recipient: n
		})).map((e) => ({
			label: "recipient",
			recipient: e,
			effects: [{
				op: "plan",
				plan: {
					...t,
					recipient: e
				}
			}]
		})), !0);
		return;
	}
	let n = Se(t);
	if (!t.free && t.workers.length < n.length) {
		let r = A.filter((r) => e.players[t.rid].workers[r] > t.workers.filter((e) => e === r).length && xe(e, t, r, n[t.workers.length])).filter((n) => Ce(e, t, [...t.workers, n]).some((n) => De(e, {
			...t,
			workers: n
		}).length > 0)).map((e) => ({
			label: "worker",
			worker: e,
			effects: [{
				op: "plan",
				plan: {
					...t,
					workers: [...t.workers, e]
				}
			}]
		}));
		H(e, t.rid, "assignWorkers", r, !t.free);
		return;
	}
	if (!t.target) {
		let n = De(e, t);
		if (n.length === 1 && n[0].card == null && n[0].index == null && !["pray", "develop"].includes(t.action)) {
			je(e, {
				...t,
				target: n[0]
			});
			return;
		}
		H(e, t.rid, "chooseTarget", n.map((n) => ({
			label: n.label,
			card: n.card,
			target: n.index,
			action: n.action ?? t.action,
			costs: W(e, t, n),
			attribute: n.attribute,
			minimum: n.minimum,
			effects: [{
				op: "plan",
				plan: {
					...t,
					target: n
				}
			}]
		})), !t.free), n.length === 0 && t.free && (e.prompt = null, e.plan = null);
		return;
	}
	if (!t.payment) {
		let n = W(e, t, t.target);
		if (n.length === 1) {
			je(e, {
				...t,
				payment: n[0]
			});
			return;
		}
		H(e, t.rid, "choosePayment", n.map((e) => ({
			label: "payment",
			...e,
			effects: [{
				op: "plan",
				plan: {
					...t,
					payment: e
				}
			}]
		})), !t.free);
		return;
	}
	e.plan = null, R(e, {
		op: "commitPlan",
		plan: t
	});
}
function Me(e, t) {
	let n = e.players[t.rid], r = e.players[t.recipient ?? t.rid], i = t.target, a = t.action, o = t.payment;
	n.silver -= o.silver, n.provision -= o.provision;
	let s = Array.from({ length: o.debts }, () => ({
		op: "debt",
		rid: n.rid
	}));
	if (!t.free && (t.workers.forEach((e) => n.workers[e]--), ![
		"favour",
		"musterFavour",
		"order"
	].includes(a))) {
		let e = 0;
		n.placed[a] = t.requirements.map((n) => n === "-" ? null : t.workers[e++]);
	}
	let c = [], l = r.rid;
	if (r.counts[a] = F(r, a) + 1, (a === "trade" || a === "hunt") && c.push(B(l, a === "trade" ? "silver" : "provision", (t.mode === "double" ? 3 : 1) + (se(r, a === "trade" ? "tradeSilver" : "huntProvision") ? 2 : 0))), a === "conspire" && (c.push(B(l, "p")), se(r, "conspireSilver") && c.push(B(l, "silver", 2))), a === "honour" && c.push(B(l, "honour"), {
		op: "removeSuspicion",
		rid: l,
		n: 1
	}), a === "recruit" && (i.index === -1 ? e.decks.townsfolk.shift() : e.market.townsfolk[i.index] = null, t.mode === "dismiss" ? c.push(...z(l, x[i.card].dismiss), V(l, "dismiss")) : (r.townsfolk.push(i.card), c.push(...z(l, x[i.card].immediate), V(l, "hire")))), a === "develop" && (r.workshops.push({
		action: i.action,
		slot: i.index
	}), r.placed[i.action] && (r.placed[i.action][i.index] = null), t.mode === "extraWorkshop" ? r.counts.develop-- : (c.push(B(l, v.boards.developWorkers[r.developed])), r.developed++)), a === "pray" && (r.placed[i.key] = (r.placed[i.key] ?? []).map(() => null)), (a === "commission" || a === "garrison") && (e.regions[i.index] = {
		rid: l,
		kind: a === "commission" ? "monk" : "outpost"
	}, c.push(B(l, a === "commission" ? "influence" : "faith"), ...z(l, v.regions[i.index].reward))), a === "fortify") {
		let t = e.decks.walls.shift();
		r.walls.push(t), c.push(B(l, "strength", C[t].strength), ...z(l, C[t].reward)), i.card = t;
	}
	if (a === "absolve" && (r.jars.push(i.index), c.push(B(l, "faith"), {
		op: "removeSuspicion",
		rid: l,
		n: 1
	}, ...I(l) ? [{
		op: r.debts.includes(!1) ? "repay" : "removeSuspicion",
		rid: l,
		n: 1
	}] : z(l, ye[i.index]))), (a === "attack" || a === "convert") && (i.index === 6 ? e.decks.outsiders.shift() : e.market.outsiders[i.index] = null, e.removedOutsiders++, a === "attack" ? (r.attacked.push(i.card), c.push(...z(l, S[i.card].attack)), se(r, "attackSilver") && c.push(B(l, "silver", 2))) : (r.converted.push(i.card), c.push(B(l, "strength", S[i.card].strength)))), a === "favour") {
		let r = i.index, a = e.favourWorkers[r].length;
		e.config.cooperative && (n.honour -= a), e.favourWorkers[r].push({
			rid: n.rid,
			worker: t.workers[0] ?? "w"
		}), c.push(...z(l, w[i.card].reward), V(l, "favour"));
	}
	if (a === "musterFavour" && (e.musterWorkers[i.card] = [{
		rid: l,
		worker: I(l) ? E[i.card].worker === "a" ? "w" : E[i.card].worker : t.workers[0] ?? "w"
	}], c.push(...z(l, E[i.card].reward))), a === "muster" && (e.diplomat = i.index, e.muster[i.index].shift(), r.muster.push(i.card), c.push(B(l, "diplomacy"), ...z(l, E[i.card].reward), ...(e.musterWorkers[i.card] ?? []).map((e) => B(l, e.worker))), delete e.musterWorkers[i.card]), a === "negotiate") {
		i.index === -1 ? e.decks.negotiate.shift() : e.market.negotiate[i.index] = null;
		let t = D[i.card];
		i.mode === "enlist" ? (r.enlisted.push(i.card), c.push(B(l, "diplomacy"), V(l, "enlist"), {
			op: "allies",
			rid: l
		})) : c.push({
			op: "freeAction",
			rid: l,
			key: t.action,
			plan: {
				rid: l,
				action: t.action,
				free: !0,
				workers: [],
				requirements: [],
				bonus: ve(i.card)
			}
		});
	}
	return a === "order" && (e.orderOwners[i.index] = l, c.push(...e.humans.map((e) => B(e, "honour")))), e.config.cooperative && a === r.coopStart && c.push(B(l, "honour")), c.push(V(l, a), {
		op: "threatAction",
		rid: l,
		key: a === "negotiate" && i.mode === "enlist" ? "enlist" : a
	}), t.free || c.push({
		op: "endTurn",
		rid: n.rid
	}), R(e, ...s, ...c), ae(e, n.rid, a, { card: i.card }), {
		kind: "action",
		rid: n.rid,
		data: {
			action: a,
			recipient: l,
			card: i.card ?? null,
			target: i.index ?? null,
			workers: t.workers,
			source: i.key
		}
	};
}
//#endregion
//#region src/game/scoring.ts
function Ne(e) {
	let t = {
		military: 0,
		farmer: 0,
		merchant: 0,
		cleric: 0
	};
	t[e.startingIcon]++;
	for (let n of e.enlisted) for (let e of D[n].icons) t[e]++;
	return t;
}
function Pe(e, t, n) {
	let r = T[n];
	return (r.action === "paidDebt" ? t.debts.filter(Boolean).length : r.action === "negotiate" ? t.enlisted.length : F(t, r.action ?? "")) >= (r.minimum ?? 5);
}
function Fe(e, t, n, r) {
	let i = S[n].score, a = 0;
	return i.kind === "attribute" && (a = Math.floor(t.attributes[i.key] / (i.divisor ?? 4))), i.kind === "action" && (a = Math.floor(F(t, i.key) / (i.divisor ?? 2))), i.kind === "townsfolk" && (a = Math.floor(t.townsfolk.length / 2)), i.kind === "attackedNation" && (a = t.attacked.filter((e) => S[e].nation === i.key).length), i.kind === "convertedNation" && (a = t.converted.filter((e) => S[e].nation === i.key).length), i.kind === "enlisted" && (a = Math.floor(t.enlisted.length / 2)), i.kind === "paidDebt" && (a = t.debts.filter(Boolean).length), i.kind === "suspicion" && (a = t.suspicion.length), i.kind === "orders" && (a = 1 + r), i.kind === "mercenary" && (a = 1 + t.converted.filter((e) => S[e].name === "Mercenary").length), i.kind === "traitor" && (a = t.debts.filter((e) => !e).length), t.rid === "$paladins-automa" ? Math.max(1, a) : a;
}
function Ie(e) {
	return Object.fromEntries(e.order.map((t) => {
		let n = e.players[t], r = e.config.cooperative ? {
			...n,
			attributes: Object.fromEntries(j.map((e) => [e, Math.min(n.attributes[e], n.honour)]))
		} : n, i = e.orders.filter((t, n) => e.config.cooperative ? e.orderOwners[n] != null : Pe(e, r, t)).length, a = e.orders.reduce((t, n, i) => t + (e.config.cooperative ? e.orderOwners[i] ? [
			4,
			6,
			8
		][i] : -[
			4,
			6,
			8
		][i] : Pe(e, r, n) ? [
			4,
			6,
			8
		][i] : 0), 0), o = j.slice(0, e.config.city ? 4 : 3).reduce((e, t) => e + U("attributes", r.attributes[t]), 0), s = Ne(r), c = e.config.city ? Array.from({ length: Math.max(...Object.values(s)) }, (e, t) => U("iconSetVp", Object.values(s).filter((e) => e > t).length)).reduce((e, t) => e + t, 0) : 0, l = {
			attributes: o,
			orders: a,
			secretOrder: r.secretOrder && Pe(e, r, r.secretOrder) ? 6 : 0,
			workshops: U("developVp", r.developed),
			monks: U("monkVp", F(r, "commission")),
			outposts: U("outpostVp", F(r, "garrison")),
			walls: U("wallVp", r.walls.length) + r.walls.reduce((e, t) => e + C[t].vp, 0),
			jars: U("jarVp", r.jars.length),
			converts: r.converted.reduce((t, n) => t + Fe(e, r, n, i), 0),
			debts: r.debts.reduce((e, t) => e + (t ? 1 : -3), 0),
			resources: Math.floor((r.silver + r.provision) / 3),
			muster: Math.floor(r.muster.length / 2),
			negotiation: c,
			threats: e.config.cooperative ? -3 * e.threats.reduce((e, t) => e + (t.revealRound <= 7 ? t.workers : 0), 0) : 0
		};
		return [t, {
			...l,
			total: Object.values(l).reduce((e, t) => e + t, 0)
		}];
	}));
}
var Le = (e) => e.humans.length * (e.config.city ? 80 : 70);
v.boards.iconSetVp;
//#endregion
//#region src/game/flow.ts
function Re(e) {
	e.round++, e.round > 1 && e.humans.length > 1 && (e.first = (e.first + 1) % e.order.length), e.phase = "paladin", e.active = e.order[e.first], e.removedOutsiders = 0, e.favourWorkers = e.favours.map(() => []), e.players[e.active].passed = !1;
	for (let t of Object.values(e.players)) t.passed = !1, t.paladin = null, t.reused = null;
	let t = e.humans.length + 1;
	e.decks.taverns.length < t && (e.decks.taverns = L(e, [...e.decks.taverns, ...e.tavernDiscard]), e.tavernDiscard = []), e.taverns = e.decks.taverns.splice(0, t);
	let n = [];
	if (e.order.includes("$paladins-automa")) {
		let t = e.players[P];
		if (t.workers = {
			w: e.round + 3 + t.allies.length,
			g: 0,
			u: 0,
			r: 0,
			b: 0,
			p: 0,
			y: 0
		}, t.placed = {}, e.round <= 3) {
			let n = T[e.orders[e.round - 1]].action;
			if (n && M.includes(n)) {
				let e = t.workshops.filter((e) => e.action === n).length;
				e < 2 && t.workshops.push({
					action: n,
					slot: e
				});
			}
		}
		e.round >= 3 && e.soloDiscard.push("favour");
	}
	for (let t of e.humans) {
		let r = e.players[t], i = e.config.city || e.config.paladinPromo ? 4 : 3;
		r.hand = r.paladinDeck.splice(0, i), n.push({
			op: "selectPaladin",
			rid: t
		});
	}
	n.push({ op: "revealPaladins" }), R(e, ...n), ae(e, "", "round", { n: e.round }), e.beat = N.round;
}
function ze(e, t) {
	let n = t.rid ?? e.active, r = e.players[n];
	if (t.op === "startRound") return Re(e), !0;
	if (t.op === "initialTown") return e.config.cooperative ? H(e, n, "startingTown", v.coopStarting.filter((t) => !Object.values(e.players).some((e) => e.coopStart === t.action)).map((e) => ({
		label: e.action,
		card: e.id,
		effects: [{
			op: "takeCoopStart",
			rid: n,
			key: e.action
		}]
	}))) : R(e, {
		op: "freeAction",
		rid: n,
		key: "recruit",
		mode: "hire"
	}), !0;
	if (t.op === "takeCoopStart") return r.coopStart = t.key, r.honourWorker = {
		commission: "u",
		garrison: "g",
		fortify: "b",
		absolve: "r"
	}[t.key], R(e, {
		op: "freeAction",
		rid: n,
		key: "recruit",
		mode: "hire"
	}), !0;
	if (t.op === "initialWorkshop") return R(e, {
		op: "freeAction",
		rid: n,
		key: "develop",
		mode: "extraWorkshop"
	}), !0;
	if (t.op === "finishSetup") return he(e, "townsfolk", "right", 0), R(e, { op: "startRound" }), !0;
	if (t.op === "selectPaladin") return e.active = n, H(e, n, "selectPaladin", r.hand.filter((e) => e !== 34900 || r.usedPaladins.some((e) => e !== 34900)).map((e) => ({
		label: "paladin",
		card: e,
		effects: [{
			op: "takePaladin",
			rid: n,
			card: e
		}]
	}))), !0;
	if (t.op === "takePaladin") return r.hand.splice(r.hand.indexOf(t.card), 1), r.paladin = t.card, t.card === 34900 ? H(e, n, "reusePaladin", [...new Set(r.usedPaladins)].filter((e) => e !== 34900).map((e) => ({
		label: "paladin",
		card: e,
		effects: [{
			op: "reusePaladin",
			rid: n,
			card: e
		}]
	}))) : R(e, {
		op: "paladinTop",
		rid: n
	}), !0;
	if (t.op === "reusePaladin") return r.reused = t.card, R(e, {
		op: "paladinTop",
		rid: n
	}), !0;
	if (t.op === "paladinTop") return H(e, n, "paladinTop", r.hand.map((e) => ({
		label: "paladin",
		card: e,
		effects: [{
			op: "keepPaladin",
			rid: n,
			card: e
		}]
	}))), !0;
	if (t.op === "keepPaladin") return r.hand.splice(r.hand.indexOf(t.card), 1), r.paladinDeck.unshift(t.card), r.hand.length > 1 ? H(e, n, "paladinRemove", r.hand.map((e) => ({
		label: "paladin",
		card: e,
		effects: [{
			op: "removePaladin",
			rid: n,
			card: e
		}]
	}))) : (r.paladinDeck.push(...r.hand), r.hand = []), !0;
	if (t.op === "removePaladin") return r.hand.splice(r.hand.indexOf(t.card), 1), r.paladinDeck.push(...r.hand), r.hand = [], !0;
	if (t.op === "revealPaladins") {
		e.phase = "tavern";
		let t = [...e.humans].sort((t, n) => (e.order.indexOf(t) - e.first + e.order.length) % e.order.length - (e.order.indexOf(n) - e.first + e.order.length) % e.order.length);
		return R(e, ...e.humans.flatMap((t) => b[e.players[t].reused ?? e.players[t].paladin].workers.map((e) => B(t, e))), ...t.map((e) => ({
			op: "tavern",
			rid: e
		})), { op: "beginPlay" }), !0;
	}
	if (t.op === "tavern") return e.active = n, H(e, n, "tavern", e.taverns.map((e) => ({
		label: "tavern",
		card: e,
		effects: [{
			op: "takeTavern",
			rid: n,
			card: e
		}]
	}))), !0;
	if (t.op === "takeTavern") return e.taverns.splice(e.taverns.indexOf(t.card), 1), e.tavernDiscard.push(t.card), R(e, ...v.taverns.find((e) => e.id === t.card).workers.map((e) => B(n, e))), !0;
	if (t.op === "beginPlay") {
		e.phase = "play";
		let t = [...e.taverns];
		return e.tavernDiscard.push(...t), e.taverns = [], R(e, ...t.flatMap((t) => e.order.includes("$paladins-automa") ? v.taverns.find((e) => e.id === t).workers.filter((e) => e === "p").map(() => ({
			op: "suspicion",
			rid: P
		})) : []), {
			op: "turn",
			rid: e.order[e.first]
		}), !0;
	}
	if (t.op === "turn") return e.active = n, I(n) ? (R(e, {
		op: "soloTurn",
		rid: n
	}), !0) : (H(e, n, "action", [...Ae(e, n).map((e) => ({
		label: e.mode === "hire" || e.mode === "dismiss" ? e.mode : e.action,
		action: e.action,
		card: e.card,
		n: e.mode === "double" ? 2 : 1,
		effects: [{
			op: "plan",
			plan: e
		}]
	})), {
		label: "pass",
		action: "pass",
		effects: [{
			op: "pass",
			rid: n
		}]
	}]), !0);
	if (t.op === "endTurn") {
		e.plan = null;
		let t = pe(e, n);
		return R(e, t ? {
			op: "turn",
			rid: t
		} : { op: "roundEnd" }), !0;
	}
	if (t.op === "roundEnd") {
		let t = [];
		if (e.config.cooperative) {
			let n = (e.round < 5 ? [
				3,
				4,
				4
			] : [
				4,
				5,
				6
			])[e.humans.length - 2];
			e.removedOutsiders < n && t.push(...e.humans.map((e) => B(e, "honour", -1)));
			let r = e.order.slice(e.first).concat(e.order.slice(0, e.first)).filter((t) => e.humans.includes(t));
			for (let n of e.threats.filter((t) => t.revealRound <= e.round && t.workers > 0)) t.push(...r.map((e) => ({
				op: "threatPenalty",
				rid: e,
				card: n.card
			})));
			e.config.coopDifficulty === "insane" && t.push({ op: "growThreats" });
		}
		return t.push({ op: "cleanup" }), R(e, ...t), !0;
	}
	if (t.op === "cleanup") {
		for (let t of Object.values(e.players)) t.paladin != null && t.usedPaladins.push(t.paladin), t.placed = {};
		return e.round === 7 ? (e.score = Ie(e), e.phase = "done", e.active = "", e.plan = null, ae(e, "", "done"), !0) : (he(e, "townsfolk", "right", e.order.includes("$paladins-automa") ? 2 : 1), he(e, "outsiders", "left", e.order.includes("$paladins-automa") ? 2 : 1), e.config.city && he(e, "negotiate", "right", e.order.includes("$paladins-automa") ? 2 : 1), R(e, { op: "startRound" }), !0);
	}
	if (t.op === "freeAction") {
		if (I(n)) return R(e, {
			...t,
			op: "soloFreeAction"
		}), !0;
		let r = t.key;
		return t.mode === "either" ? (H(e, n, "recruitMode", ["hire", "dismiss"].filter((t) => Oe(e, n, r, void 0, t)).map((e) => ({
			label: e,
			effects: [{
				...t,
				mode: e
			}]
		}))), e.prompt?.choices.length || (e.prompt = null)) : Oe(e, n, r, t.plan?.bonus, t.mode) && R(e, {
			op: "plan",
			plan: t.plan ?? {
				rid: n,
				action: r,
				mode: t.mode,
				free: !0,
				requirements: [],
				workers: []
			}
		}), !0;
	}
	return !1;
}
//#endregion
//#region src/game/solo.ts
function Be(e, t, n) {
	let r = e.players[P].marker, i = n === "town" ? [
		0,
		0,
		1,
		2,
		3,
		3,
		4,
		5,
		5
	] : n === "outsider" ? [
		0,
		1,
		1,
		2,
		3,
		3,
		4,
		5,
		0
	] : [
		0,
		0,
		0,
		0,
		0,
		1,
		2,
		3,
		4
	], a = e.config.city ? i[r] : r, o = n === "town" ? e.market.townsfolk.length : n === "outsider" ? 6 : 5;
	return [...t].sort((e, t) => {
		let r = (e) => e.index === -1 || n === "outsider" && e.index === 6 ? o + 1 : ((e.index ?? 0) - a + o) % o;
		return r(e) - r(t);
	});
}
function Ve(e, t) {
	let n = v.regions[t.index].reward;
	if (n.some((e) => e.op === "recruit")) return e.market.townsfolk.some((e) => e != null) || e.config.city && e.decks.townsfolk.length ? 0 : 100;
	if (n.some((e) => e.op === "repay")) return e.players["$paladins-automa"].debts.includes(!1) ? 1 : 100;
	if (n.some((e) => e.op === "pray")) return 2;
	let r = n.filter((e) => e.op === "gain" && [
		"w",
		"g",
		"u",
		"r",
		"b"
	].includes(e.resource)).reduce((e, t) => e + (t.n ?? 1), 0);
	return r >= 2 ? 3 : r === 1 ? 4 : n.some((e) => e.resource === "silver") ? 5 : n.some((e) => e.op === "removeSuspicion") ? 6 : 4;
}
function He(e, t) {
	let n = De(e, t), r = e.players[P];
	return t.action === "commission" || t.action === "garrison" ? n.filter((t) => Ve(e, t) < 100).sort((t, n) => Ve(e, t) - Ve(e, n) || t.index - n.index) : t.action === "recruit" ? Be(e, n, "town") : t.action === "attack" || t.action === "convert" ? Be(e, n, "outsider") : t.action === "favour" ? Be(e, n, "favour") : t.action === "absolve" ? n.slice(0, 1) : t.action === "muster" ? n.sort((e, t) => E[t.card].minimum - E[e.card].minimum || r.attributes[E[t.card].attribute] - r.attributes[E[e.card].attribute] || r.stack.indexOf(E[t.card].attribute) - r.stack.indexOf(E[e.card].attribute)) : t.action === "negotiate" ? n.sort((e, t) => (e.mode === "enlist" ? 0 : 1) - (t.mode === "enlist" ? 0 : 1) || (t.index ?? -1) - (e.index ?? -1)) : n;
}
function Ue(e, t, n = !1, r) {
	let i = e.players[P], a = be(e, P, t);
	if (!n && i.placed[t]?.some((e) => e != null)) return null;
	let o = n ? 0 : a.filter((e) => e !== "-").length;
	if (i.workers.w < o) return null;
	let s = r ?? {
		rid: "$paladins-automa",
		action: t,
		mode: t === "recruit" ? "dismiss" : void 0,
		requirements: a,
		workers: Array.from({ length: o }, () => "w"),
		free: n
	}, c = He(e, s)[0];
	return c ? {
		...s,
		target: c,
		payment: W(e, s, c)[0]
	} : null;
}
function We(e, t) {
	R(e, {
		op: "commitPlan",
		plan: t
	});
}
function Ge(e) {
	let t = e.players[P];
	if (!t.workers.w) {
		t.passed = !0, R(e, {
			op: "endTurn",
			rid: P
		});
		return;
	}
	Ke(e, [
		"recruit",
		"pray",
		"trade",
		"conspire",
		"rest"
	].find((e) => !t.placed[e]?.some((e) => e != null)));
}
function Ke(e, t) {
	let n = e.players[P];
	if (!n.workers.w || n.placed[t]?.some((e) => e != null) || t === "recruit" && !e.market.townsfolk.some((e) => e != null) && !(e.config.city && e.decks.townsfolk.length)) {
		qe(e, t);
		return;
	}
	n.workers.w--, n.placed[t] = ["w"], R(e, ...t === "recruit" ? [{
		op: "soloFreeRecruit",
		rid: P
	}] : t === "pray" ? [{
		op: "soloPray",
		rid: P
	}] : t === "trade" ? [B(P, "silver")] : t === "conspire" ? [{
		op: "suspicion",
		rid: P
	}, B(P, "w", 2)] : [{
		op: "soloRest",
		rid: P
	}], {
		op: "endTurn",
		rid: P
	});
}
function qe(e, t) {
	let n = e.players[P], r = [
		"recruit",
		"pray",
		"trade",
		"conspire",
		"rest"
	].find((r) => r !== t && !n.placed[r]?.some((e) => e != null) && (r !== "recruit" || e.market.townsfolk.some((e) => e != null) || e.config.city && e.decks.townsfolk.length));
	if (!n.workers.w || !r) {
		n.passed = !0, R(e, {
			op: "endTurn",
			rid: P
		});
		return;
	}
	Ke(e, r);
}
function Je(e, t, n) {
	let r = e.players[P];
	if (t.op === "soloTurn") {
		if (!r.workers.w) return r.passed = !0, R(e, {
			op: "endTurn",
			rid: P
		}), !0;
		let t = e.soloSchemes.shift();
		if (!t) return Ge(e), !0;
		if (e.soloDiscard.push(t), [
			"recruit",
			"pray",
			"conspire"
		].includes(t)) return Ke(e, t), !0;
		let n = null;
		if (t === "order") {
			let t = e.orders.slice(0, Math.min(e.round, 3)).filter((t) => !Pe(e, r, t)).reverse();
			t.length || (t = e.orders.slice(0, Math.min(e.round, 3)).reverse());
			for (let r of t) {
				let t = T[r].action;
				if (t && M.includes(t) && (n = Ue(e, t)), n) break;
			}
		} else if (t === "favour") {
			let t = e.favours.slice(0, Math.max(0, e.round - 2)).map((e, t) => ({
				card: e,
				index: t,
				key: String(t),
				label: "favour"
			}));
			for (let r of Be(e, t, "favour")) {
				if (e.favourWorkers[r.index].length) continue;
				let t = {
					rid: P,
					action: "favour",
					card: r.card,
					requirements: ["a"],
					workers: ["w"]
				}, i = De(e, t)[0];
				if (i) {
					n = {
						...t,
						target: i,
						payment: W(e, t, i)[0]
					};
					break;
				}
			}
			if (!n && e.config.city) {
				let t = r.marker < 4 ? r.marker : 0;
				for (let r = 0; r < 4; r++) {
					let i = e.muster[(t + r) % 4][0];
					if (i == null) continue;
					let a = {
						rid: P,
						action: "musterFavour",
						card: i,
						requirements: ["a"],
						workers: ["w"]
					}, o = De(e, a)[0];
					if (o) {
						n = {
							...a,
							target: o,
							payment: W(e, a, o)[0]
						};
						break;
					}
				}
			}
		} else n = Ue(e, t);
		return n ? We(e, n) : Ge(e), !0;
	}
	if (t.op === "soloFreeRecruit") {
		let t = Ue(e, "recruit", !0);
		return t && We(e, t), !0;
	}
	if (t.op === "soloFreeAction") {
		let n = Ue(e, t.plan?.action ?? t.key, !0, t.plan);
		return n && We(e, n), !0;
	}
	if (t.op === "soloPray") {
		let t = M.some((e) => r.placed[e]?.some((e) => e != null));
		for (let e of M) delete r.placed[e];
		return t || R(e, B(P, "w")), e.soloSchemes = L(e, [...e.soloSchemes, ...e.soloDiscard]), e.soloDiscard = [], !0;
	}
	return t.op === "soloMarker" ? (n(e, r, t.n ?? 1), !0) : t.op === "soloRest" ? (n(e, r, (1 + r.workers.w) * (e.config.city ? 2 : 1)), r.workers.w = 0, r.passed = !0, !0) : t.op === "soloDevelop";
}
function Ye(e) {
	if (e.prompt?.rid !== "$paladins-automa") return null;
	let t = e.prompt.choices[0];
	return e.prompt = null, t?.effects ?? [];
}
//#endregion
//#region src/game/resolution.ts
function Xe(e, t, n) {
	let r = e.config.city ? 9 : 5;
	for (let i = 0; i < n; i++) {
		if (t.marker++, t.marker < r) continue;
		t.marker = 0;
		let n = j.slice(0, e.config.city ? 4 : 3), i = Math.min(...n.map((e) => t.attributes[e]));
		ue(t, [...t.stack].reverse().find((e) => n.includes(e) && t.attributes[e] === i), 1);
	}
}
function Ze(e, t, n, r = !0) {
	let i = e.players[t], a = e.tax;
	e.tax = Math.max(0, e.tax - n), I(t) ? r && Xe(e, i, n * (e.config.city ? 2 : 1)) : i.silver += n, a > 0 && e.tax === 0 && e.inquisitionDepth === 0 && R(e, { op: "inquisition" });
}
function Qe(e, t, n) {
	let r = e.tax;
	e.tax = Math.max(0, e.tax - n), e.config.city && Xe(e, e.players[t], n), r > 0 && e.tax === 0 && !e.inquisitionDepth && R(e, { op: "inquisition" });
}
function $e(e, t) {
	if (t === -1) return e.suspicion.length >= 2;
	let n = x[t].ability;
	return n === "none" ? e.suspicion.length === 0 : n !== "two" || e.suspicion.length >= 2;
}
var et = {
	900: ["recruit"],
	901: ["repay"],
	902: ["pray"],
	903: ["commission"],
	904: ["convert"],
	905: ["fortify"],
	906: ["attack"],
	907: ["absolve"],
	908: ["garrison"],
	909: ["develop"],
	39100: ["enlist"],
	39200: ["muster"]
}, tt = {
	903: "influence",
	904: "silver",
	905: "strength",
	906: "provision",
	907: "faith",
	908: "workshop",
	909: "worker",
	39100: "townsfolk",
	39200: "diplomacy"
};
function nt(e, t, n, r) {
	let i = e.players[t];
	H(e, t, r, A.filter((e) => i.workers[e] > 0).map((e) => ({
		label: "worker",
		worker: e,
		effects: [{
			op: n,
			rid: t,
			resource: e
		}]
	})));
}
function rt(e, t) {
	let n = e.players[t];
	n.passed = !0;
	let r = {
		military: "r",
		farmer: "g",
		merchant: "u",
		cleric: "b"
	};
	R(e, V(t, "pass"), ...n.allies.map((e) => B(t, r[e])), ...e.queue.some((e) => e.op === "endTurn" && e.rid === t) ? [] : [{
		op: "endTurn",
		rid: t
	}]);
}
function it(e) {
	let t = e.queue.shift();
	if (!t) return null;
	let n = t.rid ?? e.active, r = e.players[n];
	if (e.beat = N.effect, t.op === "plan") return je(e, t.plan), null;
	if (t.op === "commitPlan") return e.beat = N.action, Me(e, t.plan);
	if (t.op === "gain") {
		let i = t.resource, a = t.n ?? 1;
		if (A.includes(i)) {
			if (i === "p" && a > 1) return R(e, B(n, "p"), B(n, "p", a - 1)), null;
			r.workers[I(n) ? "w" : i] += a, i === "p" && R(e, {
				op: "suspicion",
				rid: n
			});
		} else j.includes(i) ? ue(r, i, a) : i === "honour" ? r.honour = Math.max(0, Math.min(12, r.honour + a)) : i === "tax" ? Ze(e, n, a) : I(n) ? Xe(e, r, a * (e.config.city ? 2 : 1)) : i === "silver" ? r.silver += a : i === "provision" && (r.provision += a);
		return ae(e, n, "gain", {
			resource: i,
			n: a
		}), {
			kind: "gain",
			rid: n,
			data: {
				resource: i,
				n: a
			}
		};
	}
	if (t.op === "suspicion") {
		let i = e.config.personalSuspicion ? r.personalSuspicion : e.decks.suspicion, a = e.config.personalSuspicion ? r.personalDiscard : e.decks.suspicionDiscard;
		if (!i.length && a.length && (i.push(...L(e, a)), a.splice(0)), !i.length) return R(e, { op: "inquisition" }, t), null;
		let o = i.shift(), s = v.suspicion.cards[o];
		r.suspicion.push(o);
		let c = [B(n, "tax", s.tax), V(n, "suspicion")];
		return s.tax === 0 && c.push(V(n, "zeroTax")), s.provision && c.push(B(n, "provision", s.provision)), s.discard && c.push({
			op: "discardSpecificSuspicion",
			rid: n,
			card: o
		}), se(r, "suspicionProvision") && c.push(B(n, "provision")), R(e, ...c), ae(e, n, "suspicion", { card: o }), {
			kind: "suspicion",
			rid: n,
			data: { card: o }
		};
	}
	if (t.op === "discardSpecificSuspicion") {
		let n = r.suspicion.lastIndexOf(t.card);
		return n >= 0 && (r.suspicion.splice(n, 1), (e.config.personalSuspicion ? r.personalDiscard : e.decks.suspicionDiscard).push(t.card)), null;
	}
	if (t.op === "removeSuspicion") {
		let i = t.n ?? 1, a = fe(e, r, i);
		return I(n) && a < i && Qe(e, n, i - a), a ? {
			kind: "removeSuspicion",
			rid: n,
			data: { n: a }
		} : null;
	}
	if (t.op === "debt") return r.debts.push(!1), R(e, V(n, "debt")), ae(e, n, "debt"), {
		kind: "debt",
		rid: n
	};
	if (t.op === "repay") {
		let i = r.debts.indexOf(!1);
		return i >= 0 ? (r.debts[i] = !0, R(e, V(n, "repay"), {
			op: "threatAction",
			rid: n,
			key: "repay"
		}), (t.n ?? 1) > 1 && e.queue.unshift({
			...t,
			n: t.n - 1
		}), {
			kind: "repay",
			rid: n
		}) : (I(n) && Qe(e, n, t.n ?? 1), null);
	}
	if (t.op === "destroyDebt") {
		if (r.debts.length === 0) return I(n) && Qe(e, n, t.n ?? 1), null;
		let i = [!1, !0].filter((e) => r.debts.includes(e)).map((e) => ({
			label: e ? "paidDebt" : "unpaidDebt",
			effects: [{
				op: "removeDebt",
				rid: n,
				mode: e ? "paid" : "unpaid",
				n: t.n ?? 1
			}]
		}));
		return I(n) ? R(e, ...i[0].effects) : H(e, n, "destroyDebt", i), null;
	}
	if (t.op === "removeDebt") return r.debts.splice(r.debts.indexOf(t.mode === "paid"), 1), (t.n ?? 1) > 1 && R(e, {
		op: "destroyDebt",
		rid: n,
		n: t.n - 1
	}), {
		kind: "destroyDebt",
		rid: n
	};
	if (t.op === "inquisition") return e.inquisitionDepth++, R(e, ...e.order.map((t) => ({
		op: "inquisitionAbilities",
		rid: t,
		ids: [...me(e.players[t], "inquisition"), ...e.config.cooperative ? [-1] : []]
	})), { op: "inquisitionDebts" }), ae(e, "", "inquisition"), e.beat = N.inquisition, {
		kind: "inquisition",
		data: {}
	};
	if (t.op === "inquisitionAbilities" || t.op === "trigger") {
		let i = t.ids ?? me(r, t.key), a = t.op === "inquisitionAbilities" ? i.filter((e) => $e(r, e)) : i;
		if (!a.length) return null;
		let o = a.map((e) => ({
			label: e === -1 ? "loseHonour" : "townAbility",
			card: e < 0 ? void 0 : e,
			effects: [...e === -1 ? [B(n, "honour", -1)] : z(n, x[e].reward), {
				...t,
				ids: i.filter((t) => t !== e)
			}]
		}));
		return o.length === 1 || I(n) ? R(e, ...o[0].effects) : H(e, n, t.op === "inquisitionAbilities" ? "inquisitionAbilities" : "townAbilities", o), null;
	}
	if (t.op === "inquisitionDebts") {
		let t = Math.max(...e.order.map((t) => e.players[t].suspicion.length));
		return R(e, ...e.order.filter((n) => t > 0 && e.players[n].suspicion.length === t).flatMap((e) => [{
			op: "debt",
			rid: e
		}, {
			op: "removeSuspicion",
			rid: e,
			n: Math.floor(t / 2)
		}]), { op: "refillTax" }), null;
	}
	if (t.op === "refillTax") return e.tax = de(e), e.inquisitionDepth--, {
		kind: "refillTax",
		data: { n: e.tax }
	};
	if (t.op === "choice") {
		let r = (t.choices ?? []).map((e, t) => ({
			label: "reward",
			n: t,
			effects: z(n, e)
		}));
		return I(n) ? R(e, ...(r.find((e) => e.effects.some((e) => !["develop", "moveWorkshop"].includes(e.op))) ?? r[0]).effects) : H(e, n, "reward", r), null;
	}
	if (t.op === "ordered") {
		let r = t.effects ?? [];
		return I(n) ? R(e, ...z(n, r)) : H(e, n, "rewardOrder", [r, [...r].reverse()].map((e, t) => ({
			label: "rewardOrder",
			n: t,
			effects: z(n, e)
		}))), null;
	}
	if (t.op === "attribute" || t.op === "workerChoice") {
		let i = t.op === "attribute" ? j.slice(0, t.city && e.config.city ? 4 : 3) : t.colors ?? [];
		if (I(n)) {
			let t = [...r.stack].reverse().filter((e) => i.includes(e)).sort((e, t) => r.attributes[e] - r.attributes[t])[0];
			R(e, B(n, t ?? i[0]));
		} else H(e, n, t.op, i.map((e) => ({
			label: e,
			worker: t.op === "workerChoice" ? e : void 0,
			effects: [B(n, e)]
		})));
		return null;
	}
	if ([
		"recruit",
		"develop",
		"pray"
	].includes(t.op)) return I(n) ? R(e, {
		op: t.op === "recruit" ? "soloFreeRecruit" : t.op === "pray" ? "soloPray" : "soloDevelop",
		rid: n
	}) : R(e, {
		op: "freeAction",
		rid: n,
		key: t.op,
		mode: t.mode ?? (t.op === "recruit" ? "hire" : void 0)
	}), null;
	if (t.op === "moveWorkshop") return I(n) || !r.workshops.length || H(e, n, "moveWorkshop", r.workshops.map((e, t) => ({
		label: e.action,
		action: e.action,
		target: e.slot,
		effects: [{
			op: "moveWorkshopTarget",
			rid: n,
			n: t
		}]
	}))), null;
	if (t.op === "moveWorkshopTarget") return H(e, n, "workshopDestination", M.filter((t) => e.config.city || !["muster", "negotiate"].includes(t)).flatMap((e) => [0, 1].filter((t) => !r.workshops.some((n) => n.action === e && n.slot === t)).map((r) => ({
		label: e,
		action: e,
		target: r,
		effects: [{
			op: "moveWorkshopCommit",
			rid: n,
			key: e,
			target: r,
			n: t.n
		}]
	})))), null;
	if (t.op === "moveWorkshopCommit") return r.workshops[t.n] = {
		action: t.key,
		slot: t.target
	}, r.placed[t.key] && (r.placed[t.key][t.target] = null), {
		kind: "workshop",
		rid: n,
		data: {
			action: t.key,
			target: t.target
		}
	};
	if (t.op === "dismissOwn") return I(n) ? (R(e, {
		op: "soloFreeRecruit",
		rid: n
	}), null) : (r.townsfolk.length && H(e, n, "dismissOwn", r.townsfolk.map((e) => ({
		label: "dismiss",
		card: e,
		effects: [{
			op: "dismissOwnCommit",
			rid: n,
			card: e
		}]
	}))), null);
	if (t.op === "dismissOwnCommit") return r.townsfolk.splice(r.townsfolk.indexOf(t.card), 1), R(e, ...z(n, x[t.card].dismiss), V(n, "dismiss")), {
		kind: "dismiss",
		rid: n,
		data: { card: t.card }
	};
	if (t.op === "allies") {
		let t = Ne(r), i = Object.keys(t).filter((n) => t[n] >= 3 && !e.allies[n]);
		return i.length && H(e, n, "ally", i.map((e) => ({
			label: e,
			effects: [{
				op: "claimAlly",
				rid: n,
				key: e
			}, {
				op: "allies",
				rid: n
			}]
		}))), null;
	}
	if (t.op === "claimAlly") {
		let i = t.key;
		return e.allies[i] = n, r.allies.push(i), R(e, ...z(n, {
			military: [{
				op: "ordered",
				effects: [{
					op: "removeSuspicion",
					n: 1
				}, B(n, "tax", 2)]
			}],
			farmer: [B(n, "provision", 2)],
			merchant: [{
				op: "recruit",
				mode: "hire"
			}],
			cleric: [{
				op: "repay",
				n: 1
			}]
		}[i])), {
			kind: "ally",
			rid: n,
			data: { icon: i }
		};
	}
	if (t.op === "pass") return I(n) ? null : (r.placed = {}, e.plan = null, R(e, {
		op: "retainWorkers",
		rid: n
	}), null);
	if (t.op === "retainWorkers") return Object.values(r.workers).reduce((e, t) => e + t, 0) <= 3 ? rt(e, n) : nt(e, n, "discardExcessWorker", "retainWorkers"), null;
	if (t.op === "discardExcessWorker") return r.workers[t.resource]--, R(e, {
		op: "retainWorkers",
		rid: n
	}), null;
	if (t.op === "threatAction") {
		if (e.config.cooperative) for (let n of e.threats) n.revealRound <= e.round && n.workers > 0 && et[n.card]?.includes(t.key) && n.workers--;
		return null;
	}
	if (t.op === "growThreats") {
		for (let t of e.threats) t.revealRound <= e.round && t.workers > 0 && t.workers++;
		return null;
	}
	if (t.op === "threatPenalty") {
		if (t.card === 900 || t.card === 901 || t.card === 902) return R(e, {
			op: t.card === 900 ? "debt" : "suspicion",
			rid: n
		}), null;
		let i = tt[t.card], a = [];
		return r.honour > 0 && a.push({
			label: "loseHonour",
			effects: [B(n, "honour", -1)]
		}), (i === "worker" ? Object.values(r.workers).some((e) => e > 0) : i === "workshop" ? r.workshops.length > 0 : i === "townsfolk" ? r.townsfolk.length > 0 : i === "silver" ? r.silver > 0 : i === "provision" ? r.provision > 0 : r.attributes[i] > 0) && a.push({
			label: `lose:${i}`,
			effects: [{
				op: "threatLoss",
				rid: n,
				key: i
			}]
		}), a.length && H(e, n, "threatPenalty", a), null;
	}
	if (t.op === "threatLoss") return t.key === "worker" ? nt(e, n, "loseWorker", "loseWorker") : t.key === "workshop" ? H(e, n, "loseWorkshop", r.workshops.map((e, t) => ({
		label: e.action,
		action: e.action,
		target: e.slot,
		effects: [{
			op: "loseWorkshop",
			rid: n,
			n: t
		}]
	}))) : t.key === "townsfolk" ? H(e, n, "loseTownsfolk", r.townsfolk.map((e) => ({
		label: "townsfolk",
		card: e,
		effects: [{
			op: "loseTownsfolk",
			rid: n,
			card: e
		}]
	}))) : t.key === "silver" ? r.silver-- : t.key === "provision" ? r.provision-- : ue(r, t.key, -1), null;
	if (t.op === "loseWorker") return r.workers[t.resource]--, null;
	if (t.op === "loseWorkshop") return r.workshops.splice(t.n, 1), null;
	if (t.op === "loseTownsfolk") return r.townsfolk.splice(r.townsfolk.indexOf(t.card), 1), null;
	if (Je(e, t, Xe)) return null;
	if (ze(e, t)) return t.op === "startRound" || t.op === "cleanup" && e.phase === "done" ? {
		kind: t.op === "startRound" ? "round" : "done",
		data: { n: e.round }
	} : t.op === "revealPaladins" ? {
		kind: "reveal",
		data: { cards: e.humans.map((t) => ({
			rid: t,
			card: e.players[t].reused ?? e.players[t].paladin
		})) }
	} : null;
	throw Error(`Unknown Paladins effect: ${t.op}`);
}
//#endregion
//#region src/game/schema.ts
var at = t.object({
	city: t.boolean().default(!1),
	cooperative: t.boolean().default(!1),
	coopDifficulty: t.enum([
		"standard",
		"hard",
		"insane"
	]).default("standard"),
	soloDifficulty: t.enum([
		"easy",
		"standard",
		"hard",
		"insane"
	]).default("standard"),
	promos: t.boolean().default(!1),
	wallPromo: t.boolean().default(!1),
	suspicionPromo: t.boolean().default(!1),
	personalSuspicion: t.boolean().default(!1),
	tavernPromo: t.boolean().default(!1),
	vassals: t.boolean().default(!1),
	paladinPromo: t.boolean().default(!1),
	identicalPaladins: t.boolean().default(!1)
}).prefault({}), ot = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("choose"),
		id: t.string().min(1).max(80)
	}),
	t.object({ type: t.literal("cancel") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), G = t.int().nonnegative(), st = t.enum([
	"w",
	"g",
	"u",
	"r",
	"b",
	"p",
	"y"
]), ct = t.object({
	influence: G,
	faith: G,
	strength: G,
	diplomacy: G
}), lt = t.record(t.string(), t.int()), ut = t.object({
	rid: t.string(),
	attributes: ct,
	silver: G,
	provision: G,
	workers: t.object({
		w: G,
		g: G,
		u: G,
		r: G,
		b: G,
		p: G,
		y: G
	}),
	placed: t.record(t.string(), t.array(st.nullable())),
	workshops: t.array(t.object({
		action: t.string(),
		slot: G
	})),
	developed: G,
	counts: t.record(t.string(), G),
	townsfolk: t.array(G),
	attacked: t.array(G),
	converted: t.array(G),
	walls: t.array(G),
	jars: t.array(G),
	suspicion: t.array(G),
	debts: t.array(t.boolean()),
	honour: G,
	allies: t.array(t.string()),
	enlisted: t.array(G),
	muster: t.array(G),
	startingIcon: t.string(),
	paladin: G.nullable(),
	reused: G.nullable(),
	usedPaladins: t.array(G),
	passed: t.boolean(),
	coopStart: t.string(),
	honourWorker: st,
	marker: G
}), dt = t.object({
	id: t.string(),
	label: t.string(),
	card: G.optional(),
	action: t.string().optional(),
	worker: t.string().optional(),
	target: t.int().optional(),
	n: t.int().optional(),
	silver: G.optional(),
	provision: G.optional(),
	debts: G.optional(),
	recipient: t.string().optional(),
	costs: t.array(t.object({
		silver: G,
		provision: G,
		debts: G
	})).optional(),
	attribute: t.string().optional(),
	minimum: G.optional(),
	preview: t.array(t.object({
		kind: t.string(),
		resource: t.string().optional(),
		n: t.int().optional(),
		mode: t.string().optional()
	})).optional()
}), ft = t.object({
	config: at,
	order: t.array(t.string()),
	humans: t.array(t.string()),
	players: t.array(ut),
	phase: t.enum([
		"setup",
		"paladin",
		"tavern",
		"play",
		"done"
	]),
	active: t.string(),
	first: G,
	round: G,
	tax: G,
	resolving: t.boolean(),
	promptOwner: t.string().nullable(),
	promptTitle: t.string().nullable(),
	market: t.object({
		townsfolk: t.array(G.nullable()),
		outsiders: t.array(G.nullable()),
		negotiate: t.array(G.nullable())
	}),
	deckTops: t.object({
		townsfolk: G.nullable(),
		outsiders: G.nullable(),
		negotiate: G.nullable()
	}),
	taverns: t.array(G),
	regions: t.array(t.object({
		rid: t.string(),
		kind: t.enum(["monk", "outpost"])
	}).nullable()),
	orders: t.array(G),
	favours: t.array(G),
	orderOwners: t.array(t.string().nullable()),
	favourWorkers: t.array(t.array(t.object({
		rid: t.string(),
		worker: st
	}))),
	muster: t.array(t.array(G.nullable())),
	musterWorkers: t.record(t.string(), t.array(t.object({
		rid: t.string(),
		worker: st
	}))),
	diplomat: t.int(),
	allies: t.record(t.string(), t.string().nullable()),
	threats: t.array(t.object({
		card: G,
		workers: G,
		revealRound: G
	})),
	removedOutsiders: G,
	journal: t.array(t.object({
		rid: t.string(),
		kind: t.string(),
		card: G.optional(),
		resource: t.string().optional(),
		n: t.int().optional()
	})),
	score: t.record(t.string(), lt)
}), pt = t.object({
	hand: t.array(G),
	secretOrder: G.nullable(),
	selectedPaladin: G.nullable(),
	decision: t.object({
		title: t.string(),
		choices: t.array(dt),
		cancel: t.boolean()
	}).nullable(),
	plan: t.object({
		action: t.string(),
		workers: t.array(st),
		requirements: t.array(t.string())
	}).nullable()
});
//#endregion
//#region src/game/rules.ts
function mt(e) {
	return {
		rid: e,
		attributes: {
			influence: 0,
			faith: 0,
			strength: 0,
			diplomacy: 0
		},
		stack: [...j],
		silver: 3,
		provision: 1,
		workers: {
			w: 0,
			g: 0,
			u: 0,
			r: 0,
			b: 0,
			p: 0,
			y: 0
		},
		placed: {},
		workshops: [],
		developed: 0,
		counts: {},
		townsfolk: [],
		attacked: [],
		converted: [],
		walls: [],
		jars: [],
		suspicion: [],
		debts: [],
		honour: 12,
		allies: [],
		enlisted: [],
		muster: [],
		startingIcon: "military",
		paladin: null,
		reused: null,
		usedPaladins: [],
		passed: !1,
		paladinDeck: [],
		hand: [],
		personalSuspicion: [],
		personalDiscard: [],
		secretOrder: null,
		coopStart: "",
		honourWorker: "g",
		marker: 0
	};
}
function ht(t, n, r) {
	let i = at.parse(t);
	n.length < 2 && (i.cooperative = !1), !i.city && i.soloDifficulty === "insane" && (i.soloDifficulty = "hard");
	let a = n.length === 1 ? [...n, P] : [...n], o = {
		config: i,
		humans: [...n],
		order: a,
		players: Object.fromEntries(a.map((e) => [e, mt(e)])),
		phase: "setup",
		active: n[0],
		first: 0,
		round: 0,
		decks: {},
		market: {
			townsfolk: [],
			outsiders: [],
			negotiate: []
		},
		taverns: [],
		tavernDiscard: [],
		regions: v.regions.map(() => null),
		orders: [],
		favours: [],
		orderOwners: [
			null,
			null,
			null
		],
		favourWorkers: [],
		muster: [
			[],
			[],
			[],
			[]
		],
		musterWorkers: {},
		diplomat: 3,
		allies: {
			military: null,
			farmer: null,
			merchant: null,
			cleric: null
		},
		threats: [],
		removedOutsiders: 0,
		tax: 0,
		queue: [],
		prompt: null,
		plan: null,
		serial: 0,
		seed: r,
		rngCursor: 0,
		beat: N.effect,
		inquisitionDepth: 0,
		soloSchemes: [],
		soloDiscard: [],
		journal: [],
		score: {}
	};
	o.tax = de(o);
	let s = (e) => e === "base" || e === "city" && i.city || e === "promos" && i.promos;
	o.decks.townsfolk = L(o, v.townsfolk.filter((e) => s(e.set) || e.set === "compatible" && (i.city || i.promos)).map((e) => e.id)), o.decks.outsiders = L(o, v.outsiders.filter((e) => s(e.set)).map((e) => e.id)), o.decks.walls = L(o, v.walls.filter((e) => e.set === "base" || i.wallPromo).map((e) => e.id)), o.decks.taverns = L(o, v.taverns.filter((e) => e.set === "base" || e.set === "vassals" && i.vassals || e.set === "tavernPromo" && i.tavernPromo).map((e) => e.id)), o.decks.suspicion = L(o, [...v.suspicion.shared, ...i.suspicionPromo ? [34700] : []]), o.decks.suspicionDiscard = [];
	let c = v.orders.filter((e) => i.cooperative ? e.set === "coop" || i.city && e.set === "coopCity" : e.set === "base" || i.city && e.set === "city" || i.promos && e.set === "promos").map((e) => e.id), l = L(o, c);
	if (o.orders = l.splice(0, 3), i.city && !i.cooperative) for (let e of n) o.players[e].secretOrder = l.shift() ?? null;
	if (o.favours = L(o, v.favours.filter((e) => e.set === "base" || e.set === "city" && i.city || e.set === "compatible" && i.promos && !i.city || e.set === "promos" && i.promos || e.set === "vassals" && i.vassals).map((e) => e.id)).slice(0, 5), o.favourWorkers = o.favours.map(() => []), o.market.townsfolk = o.decks.townsfolk.splice(0, i.city ? 6 : 5), o.market.outsiders = o.decks.outsiders.splice(0, 6), o.decks.negotiate = [], i.city) {
		for (let e = 1; e <= 3; e++) {
			let t = L(o, v.muster.filter((t) => t.tier === e).map((e) => e.id));
			e === 1 && (t = t.slice(0, 4)), e === 2 && a.length < 3 && (t = t.slice(0, t.length - 4)), t.forEach((e, t) => o.muster[t % 4].push(e));
		}
		for (let e = 1; e <= 4; e++) {
			let t = L(o, v.negotiate.filter((t) => t.tier === e).map((e) => e.id));
			e === 1 && (o.market.negotiate = t.splice(0, 3)), (e === 2 && a.length < 3 || e === 3 && a.length < 4) && (t = t.slice(0, t.length - 2)), o.decks.negotiate.push(...t);
		}
	}
	let u = L(o, [
		"military",
		"farmer",
		"merchant",
		"cleric"
	]), d = L(o, [
		"g",
		"u",
		"r",
		"b"
	]), f = v.paladins.filter((e) => e.set === "base" || e.set === "city" && i.city || e.set === "paladinPromo" && i.paladinPromo).map((e) => e.id), p = L(o, f);
	if (a.forEach((e, t) => {
		let n = o.players[e];
		n.startingIcon = u[t], n.honourWorker = d[t], e !== "$paladins-automa" && (n.paladinDeck = i.identicalPaladins ? [...p] : L(o, f)), n.personalSuspicion = L(o, v.suspicion.personal.filter((e) => e !== 34700 || i.suspicionPromo));
	}), n.length === 1) {
		let e = o.players[P];
		e.silver = 0, e.provision = 0, e.attributes = i.city ? {
			influence: 0,
			faith: 1,
			strength: 2,
			diplomacy: 3
		} : e.attributes;
		let t = i.city ? {
			easy: 2,
			standard: 4,
			hard: 6,
			insane: 8
		}[i.soloDifficulty] : {
			easy: 1,
			standard: 3,
			hard: 5,
			insane: 5
		}[i.soloDifficulty], n = c.filter((e) => M.includes(T[e].action)), r = i.soloDifficulty === "insane" ? [...M] : L(o, n).slice(0, t).map((e) => T[e].action);
		for (let t of r) e.workshops.push({
			action: t,
			slot: 0
		});
		o.soloSchemes = L(o, [...v.soloSchemes, ...i.city ? ["muster", "negotiate"] : []]);
	} else o.first = e(o.seed, o.rngCursor++, n.length);
	if (i.cooperative) {
		let e = L(o, v.threats.filter((e) => e.set === "base" || i.city).map((e) => e.id)), t = 0;
		for (let r = 2; r <= 6; r++) {
			let a = i.coopDifficulty !== "standard" && r >= 4 ? 2 : 1;
			for (let i = 0; i < a; i++) o.threats.push({
				card: e[t++],
				workers: n.length + 1,
				revealRound: r
			});
		}
	}
	return o.queue = [...Array.from({ length: n.length }, (e, t) => n[(o.first - 1 - t + n.length * 2) % n.length]).flatMap((e) => [{
		op: "initialTown",
		rid: e
	}, ...i.city ? [{
		op: "initialWorkshop",
		rid: e
	}] : []]), { op: "finishSetup" }], {
		state: o,
		fx: []
	};
}
function gt(e, t, n) {
	if (e.phase === "done") return { code: "games.paladinsofthewestkingdom.errFinished" };
	if (t.type === "tick") {
		if (e.prompt && e.prompt.rid !== "$paladins-automa" || !e.queue.length && !e.prompt) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = Ye(t);
		n && R(t, ...n);
		let r = it(t);
		return {
			state: t,
			fx: r ? [r] : []
		};
	}
	if (!e.prompt || e.prompt.rid !== n.by) return { code: "games.paladinsofthewestkingdom.errTurn" };
	if (t.type === "cancel") {
		if (!e.prompt.cancel) return { code: "games.paladinsofthewestkingdom.errChoice" };
		let t = structuredClone(e);
		return t.prompt = null, t.plan = null, R(t, {
			op: "turn",
			rid: n.by
		}), {
			state: t,
			fx: []
		};
	}
	let r = e.prompt.choices.find((e) => e.id === t.id);
	if (!r) return { code: "games.paladinsofthewestkingdom.errChoice" };
	let i = structuredClone(e);
	i.prompt = null, R(i, ...r.effects);
	let a = it(i);
	return {
		state: i,
		fx: a ? [a] : []
	};
}
function _t(e, t) {
	let n = e.players[t], r = e.prompt?.rid === t ? e.prompt : null, i = e.order.map((t) => {
		let n = ut.parse(e.players[t]);
		return e.phase === "paladin" && (n.paladin = null, n.reused = null), n;
	});
	return {
		public: {
			config: e.config,
			order: e.order,
			humans: e.humans,
			players: i,
			phase: e.phase,
			active: e.active,
			first: e.first,
			round: e.round,
			tax: e.tax,
			resolving: !e.prompt && e.queue.length > 0,
			promptOwner: e.prompt?.rid ?? null,
			promptTitle: e.prompt?.title ?? null,
			market: e.market,
			deckTops: {
				townsfolk: e.config.city ? e.decks.townsfolk[0] ?? null : null,
				outsiders: e.config.city ? e.decks.outsiders[0] ?? null : null,
				negotiate: e.config.city ? e.decks.negotiate[0] ?? null : null
			},
			taverns: e.taverns,
			regions: e.regions,
			orders: e.orders.slice(0, Math.min(3, e.round)),
			favours: e.favours.slice(0, Math.max(0, e.round - 2)),
			orderOwners: e.orderOwners.slice(0, Math.min(3, e.round)),
			favourWorkers: e.favourWorkers.slice(0, Math.max(0, e.round - 2)),
			muster: e.config.city ? e.muster.map((e) => [e[0] ?? null]) : [],
			musterWorkers: e.musterWorkers,
			diplomat: e.diplomat,
			allies: e.allies,
			threats: e.threats.filter((t) => t.revealRound <= e.round),
			removedOutsiders: e.removedOutsiders,
			journal: e.journal,
			score: e.score
		},
		private: {
			hand: n?.hand ?? [],
			secretOrder: n?.secretOrder ?? null,
			selectedPaladin: n?.paladin ?? null,
			decision: r ? {
				title: r.title,
				cancel: r.cancel ?? !1,
				choices: r.choices.map(({ effects: e, ...n }) => ({
					...n,
					preview: ["reward", "rewardOrder"].includes(r.title) ? e.filter((e) => !e.rid || e.rid === t).map((e) => ({
						kind: e.op,
						resource: e.resource,
						n: e.n,
						mode: e.mode
					})) : void 0
				}))
			} : null,
			plan: e.plan?.rid === t ? {
				action: e.plan.action,
				workers: e.plan.workers,
				requirements: e.plan.requirements
			} : null
		}
	};
}
function vt(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.order.map((t) => [t, e.score[t].total]));
	if (e.config.cooperative) return {
		phase: "done",
		scores: t,
		winner: e.humans.reduce((e, n) => e + t[n], 0) >= Le(e) ? e.humans : [],
		ranking: e.humans
	};
	let n = (n, r) => t[r] - t[n] || e.score[r].orders - e.score[n].orders || e.players[n].suspicion.length - e.players[r].suspicion.length, r = [...e.order].sort(n);
	return {
		phase: "done",
		scores: t,
		winner: r.filter((e) => n(e, r[0]) === 0),
		ranking: r
	};
}
var yt = {
	meta: k,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ot,
		publicView: ft,
		privateView: pt,
		config: at
	},
	setup: ht,
	reduce: gt,
	viewFor: _t,
	status: vt,
	nextTickIn: (e) => e.phase !== "done" && (e.prompt?.rid === "$paladins-automa" || !e.prompt && e.queue.length > 0) ? e.beat : null
}, bt = {
	name: "Paladins of the West Kingdom",
	desc: "Gather workers and build your legacy over seven rounds.",
	hintChoice: "Choose this action, then assign workers and select a highlighted target.",
	townNoSuspicion: "Triggers only when you have no Suspicion cards.",
	errFinished: "This game has ended.",
	errTurn: "Please wait for your decision.",
	errChoice: "That option is no longer available. Choose again.",
	rules: "Build your town, commission monks, garrison outposts, raise walls and deal with outsiders. The game lasts seven rounds. In competitive play, the highest final score wins. Break ties by points from King’s Orders, then by fewer Suspicion cards. Players still tied share victory.\n\nSetup and rounds\n· Begin with 3 Silver and 1 Provision. Hire one available Townsfolk for free. With City of Crowns, also place an extra Workshop and receive a private King’s Order.\n· Each round, choose one Paladin from the cards drawn, put one unchosen card on top of your deck, and put the remainder underneath. With City of Crowns or the extra Paladins, draw four and permanently remove one of the unchosen cards.\n· Your Paladin provides workers, a temporary Attribute bonus and an ability for this round. Then choose a Tavern card and gain its workers. Temporary bonuses never count towards final Attribute scores.\n· Starting with the first player, take one action per turn. Choose the action, assign workers to its spaces, select its target and pay. You may cancel before payment.\n· Labourers fill transparent worker spaces. Scouts, Merchants, Fighters and Clerics fill their own colour or transparent spaces. Criminals are wild. Every Criminal gained immediately gives you one Suspicion card and its printed Tax.\n· Workers already occupying an action prevent you from using it again that round. Pray clears an action. Workshops replace worker spaces, reducing the workers required. A new Workshop may replace an occupied worker, which returns to the supply.\n\nLeft-side actions:\n· Develop: place two workers and pay 4 Silver. Move your next Workshop to either of the first two spaces of a right-side action and gain the worker revealed beneath it. You have eight Workshops to develop.\n· Recruit: place one worker and pay the market cost to dismiss a Townsfolk for its top-right reward. Alternatively, place two workers, including a Fighter, pay the cost and hire the Townsfolk for its immediate reward and ongoing ability. The two leftmost market cards may be taken for a Debt instead of Silver. Do not immediately refill an empty market position.\n· Pray: place a Cleric and pay 2 Silver. Return every worker on one other action to the supply. A free Pray needs no worker or Silver and may clear Pray itself.\n· Hunt or Trade: place one worker to gain 1 Provision or 1 Silver respectively. Place two together to gain 3 instead. The second worker must be a Scout for Hunt or a Merchant for Trade. You cannot add the second worker on a later turn.\n· Conspire: place one worker to gain a Criminal, then resolve its Suspicion.\n\nRight-side actions:\n· Commission: meet the region’s Faith requirement, pay the Provisions printed below your next Monk and place it in an available region space. Gain 1 Influence and the space’s reward.\n· Fortify: meet your next wall position’s Influence requirement and pay its Provisions. Draw a Wall, gain its Strength and resolve its reward.\n· Garrison: meet the region’s Strength requirement, pay your next Outpost’s Provisions and place it. Gain 1 Faith and the space’s reward. Monks and Outposts compete for the same region spaces. Player-count restrictions apply.\n· Absolve: meet your next Jar position’s Influence requirement and pay its Silver. Choose an unused Jar reward. Also gain 1 Faith and remove 1 Suspicion. You can Absolve seven times.\n· Attack: target an Outsider within your Strength, gain its attack rewards and keep it as a trophy. Each additional Silver reduces this attack’s Strength requirement by 2.\n· Convert: meet the Outsider’s Faith requirement, pay the Silver below your next conversion position and keep the card. Gain its printed Strength. Each Converted Outsider scores according to its own condition.\n· King’s Favours appear one per round from round three. Place the required worker, pay the printed cost and resolve the reward. In competitive play each Favour can be used once per round. Free actions need no workers or normal costs, but still require enough Attributes and available pieces or targets.\n\nSuspicion, Tax and Debt\n· The Tax supply holds 5, 7 or 8 Silver according to player count. If Tax runs short, gain the remainder from the general supply. Taking the last Tax immediately triggers an Inquisition; refill Tax afterwards.\n· During an Inquisition, resolve your Townsfolk abilities in your chosen order. All players tied for the most Suspicion, provided they have at least one, then gain an unpaid Debt and remove half their Suspicion, rounded down.\n· Each unpaid Debt loses 3 VP. Repaying flips a Debt; each repaid Debt scores 1 VP. Destroying removes the Debt entirely.\n· You may pass for the round. Clear your action spaces and retain up to three unused workers, choosing which excess workers to return. After everyone passes, refresh the markets and begin the next round. Discard the rightmost Townsfolk and leftmost Outsider first; in solo play discard two from each end instead.\n\nCity of Crowns:\n· Diplomacy is a fourth Attribute and uses the same scoring table. Townsfolk and Outsider draw-pile tops are faceup targets. A Townsfolk from its draw pile costs 3 Silver or one Debt.\n· Muster: move the Diplomat to another pile, paying 1–3 Provisions for the straight-line distance. Meet the top card’s Attribute requirement and collect it. Gain 1 Diplomacy, its bottom reward and any worker resting on the card. You cannot collect from the Diplomat’s current pile. Only each pile’s top card is visible.\n· You may instead place the required worker on a visible Muster card, pay its printed cost and gain its bottom reward. Each card holds one worker, which stays until the card is collected.\n· Negotiate: pay 1 or 2 Silver for a market card, or 3 Silver or one Debt for the draw-pile top. To Entrust, meet its upper-left Diplomacy requirement, then take its upper-right action for free with the printed temporary Attribute bonus. You cannot boost that Attack using Silver. To Enlist, meet its lower-left Attribute requirement, collect the card and gain 1 Diplomacy.\n· The first player with three matching noble icons claims that Ally and its immediate reward. Allies also grant their matching worker after you pass each round. Your board’s preprinted icon counts towards sets and Allies.\n· Score 1 VP per two Muster cards. Each set of one, two, three or four different noble icons scores 0, 2, 5 or 9 VP. Multiple sets score separately. A completed secret King’s Order scores 6 VP.\n\nTomesaga cooperative scenario\n· For two to four players. Choose a Starting Townsfolk and its matching Honour overlay, then hire a market Townsfolk for free as usual. Honour starts at 12. Your Starting Townsfolk grants Honour for its specified action. During each Inquisition, lose 1 Honour if you have at least two Suspicion.\n· When using a left-side action, you may pay its workers and costs but give the reward to another player. Use the acting player’s discounts and the receiving player’s Paladin and Townsfolk reward abilities.\n· Cooperative King’s Orders require Attribute thresholds. Spend an action and any one worker to complete an available Order while meeting its requirements, including temporary bonuses. Everyone gains 1 Honour. In round seven, each required Attribute rises by 2. Uncompleted Orders lose their printed VP for every player.\n· King’s Favours may be used repeatedly in a round, but the acting player loses 1 Honour for each worker already on the card.\n· Attack or Convert enough Outsiders each round: in rounds 1–4, two, three and four players need 3, 4 and 4 cards; in rounds 5–7 they need 4, 5 and 6. Otherwise everyone loses 1 Honour. New Threats appear in rounds 2–6. Perform their specified action to remove one worker; remove a Threat once it has no workers. Resolve all active Threat penalties at round end.\n· At scoring, cap every Attribute at your Honour. Every remaining Threat worker loses 3 VP for every player. Combine scores: reach 70 VP per player, or 80 with City of Crowns, to win together. Hard mode adds Threats in rounds 4–6. Insane includes Hard and returns one worker to each unresolved Threat at each round end.\n\nPromos and solo play\n· Promo groups can be enabled separately. Vassals fill non-Criminal worker requirements and each reduces the action’s Silver or Provision cost by one. Allocate multiple reductions without reducing any cost below zero. Personal Suspicion uses a separate deck for each player.\n· Solo play uses the official AI. It attempts its Scheme action; if unable, it tries Recruit, Pray, Trade, Conspire and Rest in that order. It ignores Silver and Provision costs and treats worker colours alike, but gaining Criminals still gives Suspicion. Pray clears right-side workers and shuffles all Schemes. It starts each round with the round number plus three workers, plus one per Ally. Resources advance its resource track instead; with City each resource advances two spaces. Each of its Converted Outsiders scores at least 1 VP.\n\nFinal scoring:\n· Score permanent Attributes, the three public King’s Orders, Workshops, Monks, Outposts, Walls, Jars, Converted Outsiders and Debts. Use the printed quantity thresholds. Each three remaining Silver and Provisions combined scores 1 VP.\n· Attribute values 0–12 score 0, 0, 1, 1, 3, 5, 6, 6, 9, 11, 13, 16 and 20 VP. The three King’s Orders score 4, 6 and 8 VP.\n· Six, seven and eight Develops score 1, 3 and 6 VP. Five, six and seven Monks or Outposts score 2, 5 and 9 VP. Five, six and seven Walls or Jars score 1, 3 and 6 VP. Add VP printed on Wall cards separately. Inspect Converted Outsiders for their individual scoring conditions.",
	labels: {
		unoccupied: "Unoccupied",
		baseCost: "Base cost",
		trackComplete: "No spaces left",
		faithByRegion: "Faith requirement depends on the region.",
		strengthByRegion: "Strength requirement depends on the region.",
		attackByTarget: "Strength depends on the Outsider; Silver can make up a shortfall.",
		faithByOutsider: "Faith requirement depends on the Outsider.",
		recruitByTarget: "Cost depends on the Townsfolk.",
		musterByTarget: "Requirement depends on the Muster card; pay Provisions for distance moved.",
		negotiateByTarget: "Requirement and cost depend on the Noble.",
		orderByTarget: "Requirements are on the Order; add 2 to each in round seven.",
		reviewBoard: "Review the kingdom",
		showResult: "Show the chronicle",
		scoreBreakdown: "Scoring",
		honourScoring: "Honour caps Attributes for scoring. The estate retains its actual end-of-game Attribute values.",
		workshop: "Workshop",
		recruitMode: "Choose how to Recruit",
		payment: "Payment",
		either: "Hire or dismiss",
		extraWorkshop: "Additional Workshop",
		"lose:influence": "Lose 1 Influence",
		"lose:faith": "Lose 1 Faith",
		"lose:strength": "Lose 1 Strength",
		"lose:diplomacy": "Lose 1 Diplomacy",
		"lose:silver": "Lose 1 Silver",
		"lose:provision": "Lose 1 Provision",
		"lose:worker": "Lose 1 available worker",
		"lose:workshop": "Remove 1 Workshop",
		"lose:townsfolk": "Lose 1 Townsfolk",
		threatTarget900: "Hire or dismiss Townsfolk",
		threatTarget901: "Repay Debt",
		threatTarget902: "Pray",
		threatTarget903: "Commission",
		threatTarget904: "Convert",
		threatTarget905: "Fortify",
		threatTarget906: "Attack",
		threatTarget907: "Absolve",
		threatTarget908: "Garrison",
		threatTarget909: "Develop",
		threatTarget39100: "Enlist a Noble",
		threatTarget39200: "Muster",
		threatPenalty900: "Each player gains 1 Debt.",
		threatPenalty901: "Each player gains 1 Suspicion in turn order.",
		threatPenalty902: "Each player gains 1 Suspicion in turn order.",
		threatPenalty903: "Each player loses 1 Honour or 1 Influence.",
		threatPenalty904: "Each player loses 1 Honour or 1 Silver.",
		threatPenalty905: "Each player loses 1 Honour or 1 Strength.",
		threatPenalty906: "Each player loses 1 Honour or 1 Provision.",
		threatPenalty907: "Each player loses 1 Honour or 1 Faith.",
		threatPenalty908: "Each player loses 1 Honour or removes 1 Workshop.",
		threatPenalty909: "Each player loses 1 Honour or 1 available worker.",
		threatPenalty39100: "Each player loses 1 Honour or 1 Townsfolk.",
		threatPenalty39200: "Each player loses 1 Honour or 1 Diplomacy.",
		influence: "Influence",
		faith: "Faith",
		strength: "Strength",
		diplomacy: "Diplomacy",
		silver: "Silver",
		provision: "Provisions",
		tax: "Tax",
		honour: "Honour",
		w: "Labourer",
		g: "Scout",
		u: "Merchant",
		r: "Fighter",
		b: "Cleric",
		p: "Criminal",
		y: "Vassal",
		a: "Any worker",
		commission: "Commission",
		fortify: "Fortify",
		garrison: "Garrison",
		absolve: "Absolve",
		attack: "Attack",
		convert: "Convert",
		muster: "Muster",
		negotiate: "Negotiate",
		develop: "Develop",
		recruit: "Recruit",
		pray: "Pray",
		trade: "Trade",
		hunt: "Hunt",
		conspire: "Conspire",
		favour: "King’s Favour",
		musterFavour: "Muster favour",
		order: "King’s Order",
		hire: "Hire",
		dismiss: "Dismiss",
		enlist: "Enlist",
		entrust: "Entrust",
		pass: "Pass this round",
		cancel: "Cancel",
		confirm: "Confirm",
		close: "Close",
		inspect: "Inspect",
		action: "Choose an action",
		assignWorkers: "Assign workers",
		chooseTarget: "Choose a target",
		choosePayment: "Choose payment",
		chooseRecipient: "Choose who receives the reward",
		selectPaladin: "Choose this round’s Paladin",
		reusePaladin: "Choose a used Paladin",
		paladinTop: "Choose the next Paladin",
		paladinRemove: "Choose a Paladin to remove",
		tavern: "Choose Tavern workers",
		startingTown: "Choose a Starting Townsfolk",
		reward: "Choose a reward",
		rewardOrder: "Choose reward order",
		inquisitionAbilities: "Resolve Inquisition abilities",
		townAbilities: "Choose an ability to resolve first",
		destroyDebt: "Choose a Debt to destroy",
		paidDebt: "Repaid Debt",
		unpaidDebt: "Unpaid Debt",
		retainWorkers: "Return workers until at most three remain",
		workerChoice: "Choose a worker",
		attribute: "Choose an Attribute",
		moveWorkshop: "Choose a Workshop to move",
		workshopDestination: "Choose its destination",
		dismissOwn: "Choose a Townsfolk to dismiss",
		ally: "Choose an Ally",
		threatPenalty: "Resolve a Threat penalty",
		loseHonour: "Lose 1 Honour",
		loseWorker: "Choose a worker to lose",
		loseWorkshop: "Choose a Workshop to lose",
		loseTownsfolk: "Choose a Townsfolk to lose",
		military: "Military",
		farmer: "Farmer",
		merchant: "Merchant",
		cleric: "Cleric",
		monk: "Monk",
		outpost: "Outpost",
		wall: "Wall",
		jar: "Jar",
		townsfolk: "Townsfolk",
		outsiders: "Outsiders",
		paladin: "Paladin",
		suspicion: "Suspicion",
		drawSuspicion: "Gained a Suspicion card",
		debts: "Debts",
		workers: "Workers",
		workshops: "Workshops",
		allies: "Allies",
		threats: "Threats",
		gain: "Gain",
		removeSuspicion: "Remove Suspicion",
		repay: "Repay Debt",
		debt: "Gain Debt",
		worker: "Worker",
		townAbility: "Townsfolk ability",
		recipient: "Recipient",
		taxPool: "Tax supply",
		round: "Round",
		waiting: "Waiting",
		resolving: "Resolving",
		done: "Finished",
		setup: "Setup",
		play: "Actions",
		board: "Kingdom",
		estate: "Estate",
		chronicle: "Chronicle",
		kingOrders: "The King’s Orders",
		kingFavours: "The King’s Favours",
		market: "Town and frontier",
		empty: "Empty",
		occupied: "Occupied",
		available: "Available",
		selected: "Selected",
		notRevealed: "Unrevealed",
		deck: "Draw-pile top",
		discount: "Discount",
		cost: "Cost",
		requires: "Requires",
		rewardNow: "Immediate reward",
		ongoing: "Ongoing ability",
		convertScore: "Conversion scoring",
		attackReward: "Attack reward",
		leftSlot: "Left space",
		middleSlot: "Middle space",
		rightSlot: "Right space",
		free: "Free",
		noWorkers: "No available workers",
		noCards: "No cards yet",
		viewEstate: "View estate",
		yourTurn: "Your turn",
		automa: "Official AI",
		fallbackName: "Guest",
		base: "Base game",
		city: "City of Crowns",
		cooperative: "Tomesaga co-op",
		promos: "Standard promos",
		wallPromo: "Wall promo",
		suspicionPromo: "Suspicion promo",
		personalSuspicion: "Personal Suspicion decks",
		tavernPromo: "Tavern promo",
		vassals: "Vassals",
		paladinPromo: "Extra Paladins",
		identicalPaladins: "Identical Paladin order",
		soloDifficulty: "Solo difficulty",
		coopDifficulty: "Co-op difficulty",
		easy: "Easy",
		standard: "Standard",
		hard: "Hard",
		insane: "Insane",
		components: "Optional components",
		modes: "Game modes",
		attributes: "Attributes",
		orders: "Public Orders",
		secretOrder: "Secret Order",
		monks: "Monks",
		outposts: "Outposts",
		walls: "Walls",
		jars: "Jars",
		converts: "Converts",
		resources: "Remaining resources",
		negotiation: "Noble sets",
		total: "Total",
		victory: "A legacy secured",
		defeat: "An unfinished legacy",
		result: "Chronicle of the kingdom",
		playAgain: "Play again",
		backToLobby: "Back to lobby",
		waitHost: "Waiting for the host",
		points: "VP",
		roundStart: "New round",
		inquisition: "Inquisition",
		refillTax: "Tax replenished",
		reveal: "Paladins revealed"
	},
	templates: {
		startingAbility: "Gain 1 Honour whenever you complete a {{action}} action.",
		round: "Round {{n}} / 7",
		waiting: "Waiting for {{name}}",
		amount: "{{n}} {{name}}",
		minimum: "{{name}} ≥ {{n}}",
		cost: "Pay {{items}}",
		payDebt: "or gain 1 Debt",
		per: "1 VP per {{n}} {{name}}",
		perCard: "1 VP per {{name}}",
		once: "1 VP, plus 1 per completed King’s Order",
		mercenary: "1 VP, plus 1 per Converted Mercenary",
		traitor: "Lose 1 fewer VP per unpaid Debt",
		restriction: "Available with {{n}} players",
		owns: "{{name}}’s estate",
		progress: "{{n}} / {{total}}",
		move: "Move {{n}} spaces",
		victoryGoal: "Combined score {{n}} / {{goal}}",
		slot: "{{name}} · {{slot}}",
		flavour: "Watch with faith. Defend with strength.",
		abilityTrigger: "Whenever you {{action}}: {{reward}}",
		inquisitionTrigger: "During an Inquisition: {{reward}}",
		suspicionTrigger: "Whenever you gain a Suspicion card: {{reward}}",
		zeroTaxTrigger: "Whenever you draw a Suspicion card showing 0 tax: {{reward}}",
		private: "Only you can see this",
		confirmChoice: "Choose {{name}}"
	},
	abilities: {
		none: "No additional ability.",
		tradeSilver: "Gain 2 extra Silver when Trading.",
		recruitFree: "Pay no Silver to hire or dismiss Townsfolk.",
		developDiscount: "Pay 2 fewer Silver to Develop.",
		fortifyFree: "Pay no Provisions to Fortify.",
		garrisonFree: "Pay no Provisions to Garrison.",
		attackSilver: "Gain 2 extra Silver for each Attack.",
		huntProvision: "Gain 2 extra Provisions when Hunting.",
		convertFree: "Pay no Silver to Convert.",
		conspireSilver: "Gain 2 extra Silver when Conspiring.",
		absolveFree: "Pay no Silver to Absolve.",
		commissionFree: "Pay no Provisions to Commission.",
		prayFree: "Pay no Silver to Pray.",
		musterFree: "Pay no Provisions to Muster.",
		costDebt: "Gain a Debt instead of paying all Silver and Provision costs for this action.",
		negotiateFree: "Pay no Silver to Negotiate.",
		reuse: "Reuse a previously used Paladin.",
		silverDiscount: "Pay 1 fewer Silver for each action.",
		suspicionProvision: "Gain 1 Provision whenever you gain Suspicion.",
		whiteWild: "Labourers can replace any worker type.",
		whiteAsClerics: "Labourers may act as Clerics.",
		whiteAsScouts: "Labourers may act as Scouts.",
		whiteAsMerchants: "Labourers may act as Merchants.",
		whiteAsFighters: "Labourers may act as Fighters.",
		provisionBoostStrength: "Pay 1 Provision for each temporary +2 Strength.",
		provisionBoostFaith: "Pay 1 Provision for each temporary +2 Faith.",
		provisionBoostInfluence: "Pay 1 Provision for each temporary +2 Influence.",
		provisionBoostDiplomacy: "Pay 1 Provision for each temporary +2 Diplomacy.",
		always: "Triggers at every Inquisition.",
		two: "Triggers with at least two Suspicion."
	},
	names: {
		byzantine: "Byzantine",
		viking: "Viking",
		saracen: "Saracen"
	}
}, xt = {
	name: "西国圣骑士",
	desc: "召集工人、发展城镇，在七轮中建立你的西国功业。",
	hintChoice: "选择这项行动，并按盘面高亮完成工人与目标的选择。",
	townNoSuspicion: "仅在没有嫌疑牌时触发。",
	errFinished: "本局已经结束。",
	errTurn: "请等待轮到你选择。",
	errChoice: "该选项已不可用，请重新选择。",
	rules: "你将派遣不同职业的工人，发展城镇、部署僧侣与哨站、修筑城墙，并处理不断增长的外敌和嫌疑。游戏共进行七轮。标准模式中，最终胜利分最高的玩家获胜；平分时依次比较王令得分和嫌疑数量，王令得分较高、嫌疑较少者优先，仍相同时共同获胜。\n\n准备与每轮流程:\n· 每人起始拥有3枚银币和1份粮食，并免费招募一名镇民。City of Crowns还让每人放置一间额外工坊，并获得一张只供自己查看的秘密王令。\n· 每轮先查看圣骑士候选牌，选择本轮使用的一张，再把一张放回牌库顶，其余放回牌库底。启用额外圣骑士或City of Crowns时，每轮查看四张，并永久移除其中一张未选牌。\n· 圣骑士提供本轮属性加成、工人和能力。随后从酒馆中选择一张牌，获得该牌上的工人。圣骑士的属性加成只在本轮行动时使用，不计入终局属性得分。\n· 从起始玩家开始，大家轮流执行一次行动。轮到你时，先选择行动，再按槽位依次分配工人，选择目标并支付费用。你可以在支付前取消，重新选择行动。\n· 白色劳工只能填入通用槽位。绿色斥候、蓝色商人、红色战士和黑色教士可填入对应职业槽或通用槽。紫色罪犯可代替任意职业；每获得一名罪犯，立即抽取一张嫌疑牌并收取牌示税款。\n· 同一行动区已有工人时，本轮不能再次使用该区。祈祷可清空一个行动区，使它重新可用。工坊占据的槽位不再需要工人；发展工坊时可以覆盖已放置的工人，被覆盖工人返回供应区。\n\n左侧行动:\n· 发展：放置两名任意工人并支付4枚银币，把一间工坊放到右侧行动区前两个槽位中的任意空位，并获得工坊原位置印示的工人。八间工坊全部使用后不能继续发展。\n· 招募：放置一名任意工人并支付目标镇民下方费用，遣走该镇民，获得其右上角奖励；或者同时放置两名工人，其中至少一名为战士，支付费用后把镇民加入自己的队伍，获得即时奖励与持续能力。最左侧两张镇民可以用一张债务代替银币费用。镇民不会在被取走后立即补充。\n· 祈祷：放置一名教士并支付2枚银币，将自己另一个行动区内的全部工人返回供应区。免费祈祷不要求放工人或付银币，也可以清空祈祷区。\n· 狩猎与交易：放置一名任意工人，分别获得1份粮食或1枚银币；若同时放置第二名符合要求的工人，分别获得3份粮食或3枚银币。狩猎的第二名必须为斥候，交易的第二名必须为商人。不能分两次补放工人。\n· 共谋：放置一名任意工人，获得一名罪犯，并立即处理由此获得的嫌疑牌。\n\n右侧行动:\n· 派遣：满足目标地区的信仰要求，支付当前僧侣下方标示的粮食，放置一名僧侣。你获得1点影响力和目标格的奖励。\n· 筑墙：满足下一处城墙位置的影响力要求，支付标示粮食，抽取一张城墙牌并放置，获得牌上的力量和奖励。\n· 驻防：满足目标地区的力量要求，支付当前哨站下方标示粮食，放置一个哨站。你获得1点信仰和目标格的奖励。僧侣与哨站共用地区空位；标有人数限制的位置仅在达到该人数时开放。\n· 赦罪：满足下一个罐位的影响力要求并支付标示银币，选择一个尚未使用的罐子奖励。你还获得1点信仰并移除一张嫌疑。最多赦罪七次。\n· 攻击：选择力量要求可达的外敌，获得其攻击奖励并把牌收为战利品。每支付1枚额外银币，可让本次攻击的力量要求降低2点。\n· 感化：满足目标外敌的信仰要求，支付下一个感化位置的银币费用，把外敌收为感化者，并获得牌示力量。每张感化者按牌面条件单独计分。\n· 皇家恩惠从第三轮开始逐轮开放。放置一名符合牌面要求的工人、支付牌示费用后执行奖励。标准模式中，每张恩惠每轮只能使用一次。免费行动无需放置工人或支付通常费用，但仍须满足属性要求、组件数量和目标限制。\n\n嫌疑、税款与债务:\n· 税池数量随人数为5、7或8枚。收税不足时，仍从总供应区获得足额银币。税池最后一枚银币被取走后，立即进行审讯，再恢复税池。\n· 审讯时，先按你选择的顺序结算镇民能力。随后，持有最多嫌疑且至少持有一张嫌疑的所有玩家各获得一张未偿债务，并移除自己嫌疑数量的一半，向下取整。\n· 未偿债务在终局每张扣除3分。偿还债务会把它翻面，每张已偿债务获得1分。销毁债务则将该牌移出自己的区域，不再计分。\n· 你可以放弃本轮。放弃时清空行动区，最多保留三名未使用的工人；超过时须自行选择弃回供应区。所有人放弃后，镇民、外敌和已启用的贵族市场按原版方向整理补牌，再开始下一轮。通常丢弃最右一张镇民和最左一张外敌；单人模式各丢弃两张。\n\nCity of Crowns:\n· 外交成为第四项属性，按同一属性表计分。镇民和外敌牌库顶始终可见且可选；镇民牌库顶费用为3枚银币或一张债务。\n· 集结：把外交官移到另外一堆集结牌，按移动的一至三格距离支付粮食，满足该堆顶牌的属性要求后收取该牌。你获得1点外交、牌底奖励，以及牌上已放置的工人。当前外交官所在堆不能收取。只显示各堆顶牌。\n· 你也可以像使用皇家恩惠一样，在任一可见集结牌上放置符合要求的工人并执行牌底奖励。每张牌只能有一名工人；该工人在集结牌被收取前一直留在牌上。\n· 交涉：支付贵族卡下方的1或2枚银币；选择牌库顶时支付3枚银币或获得一张债务。你可以委托或征召。委托须满足贵族左上角外交要求，免费执行右上角行动，并获得该行动的临时属性加成；不得用银币补足攻击要求。征召须满足左下角属性要求，收取贵族卡并获得1点外交。\n· 最先集齐三枚相同贵族图标的玩家获得对应盟友及即时奖励。每轮放弃后，盟友还提供对应职业的工人。玩家版图预印的一枚图标参与图标计分和盟友判定。\n· 每两张集结牌获得1分。每组一至四种不同贵族图标分别获得0、2、5、9分，可以组成多组。秘密王令完成时额外获得6分。\n\nTomesaga合作场景:\n· 仅供两至四人使用。每人先选择一张起始镇民及对应荣誉行动覆盖片，再照常免费招募市场镇民。荣誉从12开始；起始镇民指定行动可增加荣誉。审讯时，持有至少两张嫌疑者各失去1点荣誉。\n· 执行左侧行动时，你可支付工人与费用，让一名其他玩家获得该行动的奖励。费用减免使用执行者的能力，行动奖励使用接收者的圣骑士和镇民能力。\n· 合作王令改为属性门槛。满足门槛时，用一次行动放置一名任意工人，完成该王令，所有人增加1点荣誉。第七轮每项所需属性再提高2点。未完成的王令会使每人失去其印示分数。\n· 皇家恩惠允许重复使用，但须失去等同于该牌已有工人数的荣誉。\n· 每轮须攻击或感化足够外敌：前四轮，两、三、四人分别需要3、4、4张；后三轮分别需要4、5、6张。不足时所有人失去1点荣誉。第二至第六轮会揭示新的威胁；完成牌示行动可移除其一名工人，清空后解除该威胁。每轮结束依次结算未解除威胁的惩罚。\n· 终局时，各项属性高于荣誉的部分不计分。每名残留威胁工人使每人扣3分。基础版合作总分须达到每人70分，City of Crowns须达到每人80分，才能共同获胜。困难模式在第四至第六轮各增加一张威胁；极难模式还在每轮结束给未解除威胁补回一名工人。\n\n宣传组件与单人模式:\n· 各组宣传组件可分别开关。附庸可填入非罪犯限定的工人槽，每枚参与行动的附庸可减免1枚银币或1份粮食；多枚附庸由你分配减免，不能超过实际费用。个人嫌疑牌库为每人独立的嫌疑牌组。\n· 单人模式对抗官方AI。AI按计划牌尝试行动，无法执行时依次尝试招募、祈祷、交易、共谋和休息；AI忽略银币与粮食费用，所有工人视为同类，获得罪犯仍抽嫌疑。祈祷清空右侧行动区并洗回所有计划牌。AI每轮获得“轮数加三”名工人，并由资源轨代替资源收入；City中每份资源推进两格。AI感化者每张至少获得1分。\n\n终局计分:\n· 依次计算永久属性、三张公开王令、工坊、僧侣、哨站、城墙、罐子、感化者和债务。各组件按玩家版图印示的数量档位得分；每三份剩余银币和粮食合计再获得1分。\n· 属性从0至12的得分依次为0、0、1、1、3、5、6、6、9、11、13、16、20分。三张王令依次为4、6、8分。\n· 发展六、七、八次分别获得1、3、6分；派遣或驻防五、六、七次分别获得2、5、9分；五、六、七张城墙或罐子分别获得1、3、6分，城墙牌额外印分另算。感化者的具体条件可随时点牌查看。",
	labels: {
		unoccupied: "未占用",
		baseCost: "基础费用",
		trackComplete: "已无可用位置",
		faithByRegion: "信仰要求见目标地区。",
		strengthByRegion: "力量要求见目标地区。",
		attackByTarget: "力量要求见外敌；可用银币补足。",
		faithByOutsider: "信仰要求见外敌。",
		recruitByTarget: "费用见目标镇民。",
		musterByTarget: "属性要求见集结牌，粮食按移动距离支付。",
		negotiateByTarget: "属性要求与费用见目标贵族。",
		orderByTarget: "属性要求见王令；第七轮每项增加2。",
		reviewBoard: "回看王国",
		showResult: "查看功业簿",
		scoreBreakdown: "计分明细",
		honourScoring: "荣誉限制用于计分的属性值。回看领地时仍显示游戏结束时的实际属性。",
		workshop: "工坊",
		recruitMode: "选择招募方式",
		payment: "支付",
		either: "招募或遣走",
		extraWorkshop: "额外工坊",
		"lose:influence": "失去1点影响力",
		"lose:faith": "失去1点信仰",
		"lose:strength": "失去1点力量",
		"lose:diplomacy": "失去1点外交",
		"lose:silver": "失去1枚银币",
		"lose:provision": "失去1份粮食",
		"lose:worker": "失去1名工人",
		"lose:workshop": "移除1座工坊",
		"lose:townsfolk": "失去1名镇民",
		threatTarget900: "招募或遣走镇民",
		threatTarget901: "偿还债务",
		threatTarget902: "祈祷",
		threatTarget903: "派遣",
		threatTarget904: "感化",
		threatTarget905: "筑墙",
		threatTarget906: "攻击",
		threatTarget907: "赦罪",
		threatTarget908: "驻防",
		threatTarget909: "发展",
		threatTarget39100: "征召贵族",
		threatTarget39200: "集结",
		threatPenalty900: "每位玩家获得1张债务。",
		threatPenalty901: "每位玩家依次获得1张嫌疑。",
		threatPenalty902: "每位玩家依次获得1张嫌疑。",
		threatPenalty903: "每位玩家失去1点荣誉或1点影响力。",
		threatPenalty904: "每位玩家失去1点荣誉或1枚银币。",
		threatPenalty905: "每位玩家失去1点荣誉或1点力量。",
		threatPenalty906: "每位玩家失去1点荣誉或1份粮食。",
		threatPenalty907: "每位玩家失去1点荣誉或1点信仰。",
		threatPenalty908: "每位玩家失去1点荣誉或移除1座工坊。",
		threatPenalty909: "每位玩家失去1点荣誉或失去1名待命工人。",
		threatPenalty39100: "每位玩家失去1点荣誉或失去1名镇民。",
		threatPenalty39200: "每位玩家失去1点荣誉或1点外交。",
		influence: "影响力",
		faith: "信仰",
		strength: "力量",
		diplomacy: "外交",
		silver: "银币",
		provision: "粮食",
		tax: "税款",
		w: "劳工",
		g: "斥候",
		u: "商人",
		r: "战士",
		b: "教士",
		p: "罪犯",
		y: "附庸",
		a: "任意工人",
		commission: "派遣",
		fortify: "筑墙",
		garrison: "驻防",
		absolve: "赦罪",
		attack: "攻击",
		convert: "感化",
		muster: "集结",
		negotiate: "交涉",
		develop: "发展",
		recruit: "招募",
		pray: "祈祷",
		trade: "交易",
		hunt: "狩猎",
		conspire: "共谋",
		honour: "荣誉",
		favour: "皇家恩惠",
		musterFavour: "集结恩惠",
		order: "王令",
		hire: "招为镇民",
		dismiss: "遣走",
		enlist: "征召",
		entrust: "委托",
		pass: "放弃本轮",
		cancel: "取消",
		confirm: "确认",
		close: "关闭",
		inspect: "查看",
		action: "选择行动",
		assignWorkers: "分配工人",
		chooseTarget: "选择目标",
		choosePayment: "选择支付方式",
		chooseRecipient: "选择奖励接收者",
		selectPaladin: "选择本轮圣骑士",
		reusePaladin: "选择重用的圣骑士",
		paladinTop: "选择放回牌库顶的圣骑士",
		paladinRemove: "选择永久移除的圣骑士",
		tavern: "选择酒馆工人",
		startingTown: "选择合作起始镇民",
		reward: "选择奖励",
		rewardOrder: "选择奖励结算顺序",
		inquisitionAbilities: "结算审讯能力",
		townAbilities: "选择先结算的镇民能力",
		destroyDebt: "选择销毁的债务",
		paidDebt: "已偿债务",
		unpaidDebt: "未偿债务",
		retainWorkers: "选择弃回的工人，最多保留三名",
		workerChoice: "选择工人",
		attribute: "选择增加的属性",
		moveWorkshop: "选择要移动的工坊",
		workshopDestination: "选择工坊的新位置",
		dismissOwn: "选择要遣走的镇民",
		ally: "选择盟友",
		threatPenalty: "处理威胁惩罚",
		loseHonour: "失去1点荣誉",
		loseWorker: "选择失去的工人",
		loseWorkshop: "选择移除的工坊",
		loseTownsfolk: "选择失去的镇民",
		military: "军事",
		farmer: "农民",
		merchant: "商人",
		cleric: "教士",
		monk: "僧侣",
		outpost: "哨站",
		wall: "城墙",
		jar: "罐子",
		townsfolk: "镇民",
		outsiders: "外敌",
		paladin: "圣骑士",
		suspicion: "嫌疑",
		drawSuspicion: "获得嫌疑牌",
		debts: "债务",
		workers: "工人",
		workshops: "工坊",
		allies: "盟友",
		threats: "威胁",
		gain: "获得",
		removeSuspicion: "移除嫌疑",
		repay: "偿还债务",
		debt: "获得债务",
		worker: "工人",
		townAbility: "镇民能力",
		recipient: "接收者",
		taxPool: "税池",
		round: "轮",
		waiting: "等待",
		resolving: "结算中",
		done: "终局",
		setup: "准备",
		play: "行动",
		board: "王国",
		estate: "领地",
		chronicle: "纪事",
		kingOrders: "国王的命令",
		kingFavours: "国王的恩惠",
		market: "城镇与边境",
		empty: "空位",
		occupied: "已占用",
		available: "可用",
		selected: "已选择",
		notRevealed: "尚未揭示",
		deck: "牌库顶",
		discount: "减免",
		cost: "费用",
		requires: "要求",
		rewardNow: "即时奖励",
		ongoing: "持续能力",
		convertScore: "感化计分",
		attackReward: "攻击奖励",
		leftSlot: "左槽",
		middleSlot: "中槽",
		rightSlot: "右槽",
		free: "免费",
		noWorkers: "没有待命工人",
		noCards: "暂无卡牌",
		viewEstate: "查看领地",
		yourTurn: "轮到你",
		automa: "官方AI",
		fallbackName: "访客",
		base: "基础版",
		city: "City of Crowns",
		cooperative: "Tomesaga合作",
		promos: "标准宣传牌",
		wallPromo: "城墙宣传牌",
		suspicionPromo: "嫌疑宣传牌",
		personalSuspicion: "个人嫌疑牌库",
		tavernPromo: "酒馆宣传牌",
		vassals: "附庸",
		paladinPromo: "额外圣骑士",
		identicalPaladins: "相同圣骑士牌序",
		soloDifficulty: "单人难度",
		coopDifficulty: "合作难度",
		easy: "简单",
		standard: "标准",
		hard: "困难",
		insane: "极难",
		components: "可选组件",
		modes: "游戏模式",
		attributes: "属性",
		orders: "公开王令",
		secretOrder: "秘密王令",
		monks: "僧侣",
		outposts: "哨站",
		walls: "城墙",
		jars: "罐子",
		converts: "感化者",
		resources: "剩余资源",
		negotiation: "贵族图标",
		total: "总分",
		victory: "功业达成",
		defeat: "功业未竟",
		result: "王国功业簿",
		playAgain: "再来一局",
		backToLobby: "返回大厅",
		waitHost: "等待房主开始下一局",
		points: "分",
		roundStart: "新一轮",
		inquisition: "审讯",
		refillTax: "恢复税池",
		reveal: "圣骑士就位"
	},
	templates: {
		startingAbility: "每次完成{{action}}行动后，获得1点荣誉。",
		round: "第 {{n}} / 7 轮",
		waiting: "等待{{name}}",
		amount: "{{n}} {{name}}",
		minimum: "{{name}} ≥ {{n}}",
		cost: "支付 {{items}}",
		payDebt: "或获得1张债务",
		per: "每{{n}}{{name}}得1分",
		perCard: "每张{{name}}得1分",
		once: "1分，加每张已完成王令1分",
		mercenary: "1分，加每名已感化雇佣兵1分",
		traitor: "每张未偿债务少扣1分",
		restriction: "{{n}}人起可用",
		owns: "{{name}}的领地",
		progress: "{{n}} / {{total}}",
		move: "移动{{n}}格",
		victoryGoal: "合作总分 {{n}} / {{goal}}",
		slot: "{{name}} · {{slot}}",
		flavour: "以信仰守望，以力量卫国。",
		abilityTrigger: "每次{{action}}时：{{reward}}",
		inquisitionTrigger: "审讯时：{{reward}}",
		suspicionTrigger: "每次获得一张嫌疑牌时：{{reward}}",
		zeroTaxTrigger: "每次抽到印有0税款的嫌疑牌时：{{reward}}",
		private: "仅自己可见",
		confirmChoice: "选择{{name}}"
	},
	abilities: {
		none: "没有额外能力。",
		tradeSilver: "交易额外获得2枚银币。",
		recruitFree: "招募或遣走镇民不付银币。",
		developDiscount: "发展少付2枚银币。",
		fortifyFree: "筑墙不付粮食。",
		garrisonFree: "驻防不付粮食。",
		attackSilver: "每次攻击额外获得2枚银币。",
		huntProvision: "狩猎额外获得2份粮食。",
		convertFree: "感化不付银币。",
		conspireSilver: "共谋额外获得2枚银币。",
		absolveFree: "赦罪不付银币。",
		commissionFree: "派遣不付粮食。",
		prayFree: "祈祷不付银币。",
		musterFree: "集结不付粮食。",
		costDebt: "可获得一张债务，代替本次行动全部银币和粮食费用。",
		negotiateFree: "交涉不付银币。",
		reuse: "重用一名已经使用过的圣骑士。",
		silverDiscount: "每次行动少付1枚银币。",
		suspicionProvision: "每获得一张嫌疑，获得1份粮食。",
		whiteWild: "劳工可以代替任意职业工人。",
		whiteAsClerics: "劳工可代替教士。",
		whiteAsScouts: "劳工可代替斥候。",
		whiteAsMerchants: "劳工可代替商人。",
		whiteAsFighters: "劳工可代替战士。",
		provisionBoostStrength: "每支付1份粮食，本次力量增加2点。",
		provisionBoostFaith: "每支付1份粮食，本次信仰增加2点。",
		provisionBoostInfluence: "每支付1份粮食，本次影响力增加2点。",
		provisionBoostDiplomacy: "每支付1份粮食，本次外交增加2点。",
		always: "每次审讯均可触发。",
		two: "持有至少两张嫌疑时触发。"
	},
	names: {
		Missionary: "传教士",
		Peddler: "小贩",
		Squire: "侍从",
		Watchman: "守望者",
		Abbot: "修院长",
		Acolyte: "辅祭",
		Architect: "建筑师",
		Conspirator: "密谋者",
		"Debt Collector": "收债人",
		Defender: "守卫",
		Gatekeeper: "守门人",
		Princess: "公主",
		Chevalier: "骑士",
		Outrider: "先遣骑手",
		Strongman: "大力士",
		Aristocrat: "贵族",
		Swindler: "骗子",
		Pickpocket: "扒手",
		Overseer: "监工",
		"King Dan": "King Dan",
		Suzerain: "领主",
		Ryan: "Ryan",
		Kira: "Kira",
		Jeremy: "Jeremy",
		David: "David",
		Friar: "修士",
		Financier: "财务官",
		Patron: "赞助人",
		Protector: "护卫",
		Vigilante: "义警",
		Warrior: "武士",
		Adventurer: "冒险者",
		Armourer: "铸甲师",
		Assassin: "刺客",
		Barbarian: "蛮兵",
		Guardian: "守护者",
		Lookout: "瞭望者",
		Marauder: "掠夺者",
		Mercenary: "雇佣兵",
		Thief: "盗贼",
		Traitor: "叛徒",
		Archer: "弓箭手",
		Champion: "勇士",
		Hunter: "猎人",
		Invader: "入侵者",
		Envoy: "使者",
		Rogue: "游荡者",
		Enforcer: "执法者",
		Hero: "英雄",
		byzantine: "拜占庭",
		viking: "维京",
		saracen: "撒拉逊"
	}
};
//#endregion
//#region src/game/components.tsx
function K() {
	let e = s((e) => e.locale) === "zh" ? xt : bt;
	return {
		raw: e,
		label: (t) => e.labels[t] ?? t,
		name: (t) => e.names[t] ?? t,
		f: (t, n = {}) => e.templates[t].replace(/\{\{(\w+)\}\}/g, (e, t) => String(n[t] ?? ""))
	};
}
var St = {
	w: "#efe7d4",
	g: "#639548",
	u: "#4b86af",
	r: "#b8513e",
	b: "#373935",
	p: "#8d58a3",
	y: "#cda43f",
	strength: "#b34f3f",
	faith: "#444d48",
	influence: "#4a81ad",
	diplomacy: "#ded8c4",
	honour: "#c0a04f"
};
function q({ kind: e, size: t = 25, color: n }) {
	let r = n ?? St[e] ?? "#c9aa6b";
	return /* @__PURE__ */ p("svg", {
		width: t,
		height: t,
		viewBox: "0 0 32 36",
		className: "pw-glyph",
		"aria-hidden": !0,
		children: [
			"w",
			"g",
			"u",
			"r",
			"b",
			"p",
			"y",
			"a",
			"worker"
		].includes(e) ? /* @__PURE__ */ m(f, { children: [
			/* @__PURE__ */ p("path", {
				d: "M10 2h12v6l6 6-4 5-3-3v18H11V16l-3 3-4-5 6-6Z",
				fill: e === "a" ? "#899182" : r,
				stroke: "#f4e7c5",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ p("path", {
				d: "M14 21h4M14 25h4",
				stroke: "#302c26",
				strokeWidth: "1.3",
				opacity: ".55"
			}),
			e === "a" && /* @__PURE__ */ p("path", {
				d: "m14 10 3-3 2 4-4 4",
				fill: "none",
				stroke: "white",
				strokeWidth: "2"
			})
		] }) : [
			"influence",
			"faith",
			"strength",
			"diplomacy",
			"honour"
		].includes(e) ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", {
			d: "M5 2h22v30l-11-6-11 6Z",
			fill: r,
			stroke: "#f4e9d2",
			strokeWidth: "1.4"
		}), /* @__PURE__ */ p("path", {
			d: e === "strength" ? "m12 9 8 12m0-12-8 12" : e === "faith" ? "M16 8v14m-5-10h10" : e === "influence" ? "M10 21V11l4 3 3-6 3 6 3-3v10Z" : e === "diplomacy" ? "m10 14 6-5 6 5-6 7Z" : "m16 8 2 5 5 1-4 4 1 6-4-3-4 3 1-6-4-4 5-1Z",
			stroke: e === "diplomacy" ? "#555c55" : "#fff2cf",
			strokeWidth: "2",
			fill: "none"
		})] }) : e === "silver" || e === "tax" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
			cx: "16",
			cy: "18",
			r: "12",
			fill: e === "tax" ? "#b86a46" : "#bdb7a4",
			stroke: "#f1dfb5",
			strokeWidth: "2"
		}), /* @__PURE__ */ p("path", {
			d: "m11 25 4-15 5 16M9 18h14",
			stroke: "#645945",
			fill: "none",
			strokeWidth: "1.6"
		})] }) : e === "provision" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", {
			d: "m11 4 10 1-2 7c10 5 10 18 2 20H11c-9-2-8-15 2-20Z",
			fill: "#987047",
			stroke: "#eddbb7",
			strokeWidth: "1.6"
		}), /* @__PURE__ */ p("path", {
			d: "M11 13h11M15 15l-2 10",
			stroke: "#503c2c",
			strokeWidth: "2"
		})] }) : e === "monk" || e === "monks" ? /* @__PURE__ */ p("path", {
			d: "M10 11c-2-10 14-10 12 0l-2 6 7 15H5l7-15Z",
			fill: r,
			stroke: "#f8e9c5",
			strokeWidth: "1.5"
		}) : e === "outpost" || e === "outposts" || e === "workshop" || e === "workshops" ? /* @__PURE__ */ p("path", {
			d: "m3 17 13-13 13 13-4 1v14H7V18Z",
			fill: r,
			stroke: "#f7e8c6",
			strokeWidth: "1.5"
		}) : e === "jar" || e === "jars" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", {
			d: "M11 3h10v4l6 5v15l-6 6H11l-6-6V12l6-5Z",
			fill: "#878b82",
			stroke: "#eadfb9",
			strokeWidth: "1.5"
		}), /* @__PURE__ */ p("path", {
			d: "M11 8h10M9 15v10l4 4h6l4-4V15",
			fill: "none",
			stroke: "#c9ccbd",
			strokeWidth: "1.5"
		})] }) : e === "wall" || e === "walls" ? /* @__PURE__ */ p("path", {
			d: "M4 32V9h5V3h5v6h5V3h5v6h4v23Z",
			fill: "#85877b",
			stroke: "#e9debe",
			strokeWidth: "1.5"
		}) : e === "military" ? /* @__PURE__ */ m("g", {
			stroke: "#bd5743",
			strokeWidth: "3",
			strokeLinejoin: "round",
			children: [/* @__PURE__ */ p("path", {
				d: "m7 3 18 23-4 3L4 6Zm18 0L7 26l4 3L28 6Z",
				fill: "#eee1ba"
			}), /* @__PURE__ */ p("path", {
				d: "m3 24 10 8m6 0 10-8",
				stroke: "#e0bd72"
			})]
		}) : e === "farmer" ? /* @__PURE__ */ m("g", {
			fill: "none",
			strokeLinecap: "round",
			children: [/* @__PURE__ */ p("path", {
				d: "m8 31 15-24M5 9l21 20",
				stroke: "#dfc391",
				strokeWidth: "3"
			}), /* @__PURE__ */ p("path", {
				d: "m17 4 12 7M3 4v7l7 5 5-5V4",
				stroke: "#79a85b",
				strokeWidth: "3"
			})]
		}) : e === "merchant" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", {
			d: "m11 4 10 1-3 7c12 5 12 18 3 20H10C1 29 2 16 14 12Z",
			fill: "#4e8caf",
			stroke: "#eeddb5",
			strokeWidth: "1.5"
		}), /* @__PURE__ */ p("path", {
			d: "M10 13h12m-5 5v10m-5-7h10",
			stroke: "#e7d5a9",
			strokeWidth: "2"
		})] }) : e === "cleric" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", {
			d: "M12 3h8v9h9v8h-9v13h-8V20H3v-8h9Z",
			fill: "#777e77",
			stroke: "#eee1bd",
			strokeWidth: "1.5"
		}), /* @__PURE__ */ p("path", {
			d: "M16 7v22M7 16h18",
			stroke: "#c2c7b7",
			strokeWidth: "1.5"
		})] }) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", {
			d: "M6 2h20v31H6Z",
			fill: e === "suspicion" ? "#78518a" : "#5c6156",
			stroke: "#e7ddc1",
			strokeWidth: "1.5"
		}), /* @__PURE__ */ p("path", {
			d: e === "suspicion" ? "m11 12 10 10m0-10L11 22" : "M11 12h10m-10 6h10m-10 6h6",
			stroke: "#f4e5c7",
			strokeWidth: e === "suspicion" ? 4 : 2
		})] })
	});
}
function J({ kind: e, n: t, text: n = !0 }) {
	let r = K();
	return /* @__PURE__ */ m("span", {
		className: "pw-token",
		title: r.label(e),
		children: [
			/* @__PURE__ */ p(q, { kind: e }),
			t != null && /* @__PURE__ */ p(d, { value: t }),
			/* @__PURE__ */ p("span", {
				className: n ? "pw-token-label" : "sr-only",
				children: r.label(e)
			})
		]
	});
}
function Y({ on: e = !0 }) {
	return e ? /* @__PURE__ */ p("svg", {
		className: "pw-march",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ p("rect", {
			x: "2",
			y: "2",
			width: "calc(100% - 4px)",
			height: "calc(100% - 4px)",
			rx: "5"
		})
	}) : null;
}
function X({ name: e, children: t, className: n = "", style: r }) {
	let { ref: i, hidden: a } = u(e);
	return /* @__PURE__ */ p("div", {
		ref: i,
		className: n,
		style: {
			...r,
			visibility: a ? "hidden" : void 0
		},
		children: t
	});
}
function Ct({ name: e, children: t, className: n = "" }) {
	let { ref: r, hidden: i } = u(e);
	return /* @__PURE__ */ p("span", {
		ref: r,
		className: n,
		style: { visibility: i ? "hidden" : void 0 },
		children: t
	});
}
function Z({ effects: e }) {
	let t = K();
	return /* @__PURE__ */ p("span", {
		className: "pw-effects",
		children: e.map((e, n) => e.op === "gain" ? /* @__PURE__ */ p(J, {
			kind: e.resource,
			n: e.n ?? 1
		}, n) : e.op === "choice" ? /* @__PURE__ */ p("span", {
			className: "pw-effect-choice",
			children: e.choices?.map((e, t) => /* @__PURE__ */ m("span", { children: [t > 0 && " / ", /* @__PURE__ */ p(Z, { effects: e })] }, t))
		}, n) : e.op === "ordered" ? /* @__PURE__ */ p(Z, { effects: e.effects ?? [] }, n) : /* @__PURE__ */ m("span", {
			className: "pw-effect-word",
			children: [
				t.label(e.op),
				e.n && e.n > 1 ? ` ×${e.n}` : "",
				e.mode ? " · " + t.label(e.mode) : ""
			]
		}, n))
	});
}
function wt(e, t) {
	let n = b[e] ?? x[e] ?? S[e];
	return n ? t.name(n.name) : T[e] ? t.label("order") : E[e] ? t.label("muster") : D[e] ? t.label("negotiate") : w[e] ? t.label("favour") : C[e] ? t.label("wall") : O[e] ? t.label("threats") : v.taverns.some((t) => t.id === e) ? t.label("tavern") : t.label("townsfolk");
}
function Tt({ id: e }) {
	let t = K(), n = S[e].score, r = n.kind === "attackedNation" || n.kind === "convertedNation" ? t.name(n.key) : t.label(n.key ?? (n.kind === "enlisted" ? "enlist" : n.kind === "paidDebt" ? "paidDebt" : n.kind === "townsfolk" ? "townsfolk" : n.kind === "suspicion" ? "suspicion" : n.kind)), i = n.kind === "traitor" ? t.f("traitor") : n.kind === "orders" ? t.f("once") : n.kind === "mercenary" ? t.f("mercenary") : t.f(n.divisor ? "per" : "perCard", {
		n: n.divisor ?? 1,
		name: r
	});
	return /* @__PURE__ */ m("span", {
		className: "pw-score-rule",
		children: [
			n.kind === "attackedNation" && t.label("attack") + " · ",
			n.kind === "convertedNation" && t.label("convert") + " · ",
			i
		]
	});
}
function Et({ id: e, detail: t = !1 }) {
	let n = K(), r = b[e], a = x[e], o = S[e], s = w[e], c = E[e], l = D[e], u = T[e], d = C[e], h = v.taverns.find((t) => t.id === e), g = v.coopStarting.find((t) => t.id === e);
	return /* @__PURE__ */ m("div", {
		className: `pw-card-face ${r || a || o ? "pw-character" : ""} ${r ? "pw-paladin" : o ? "pw-outsider" : a ? "pw-town" : ""}`,
		children: [
			(r || a || o) && /* @__PURE__ */ p("img", {
				className: "pw-portrait",
				src: i(`games/paladinsofthewestkingdom/${e}.webp`),
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ p("strong", {
				className: "pw-card-name",
				children: wt(e, n)
			}),
			g && /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ m("div", {
					className: "pw-card-group",
					children: [/* @__PURE__ */ p(J, {
						kind: "honour",
						n: 1
					}), /* @__PURE__ */ p("strong", { children: n.label(g.action) })]
				}),
				/* @__PURE__ */ p("p", {
					className: "pw-card-text",
					children: n.f("startingAbility", { action: n.label(g.action) })
				}),
				/* @__PURE__ */ m("div", {
					className: "pw-card-group",
					children: [/* @__PURE__ */ p(J, { kind: {
						commission: "u",
						garrison: "g",
						fortify: "b",
						absolve: "r"
					}[g.action] }), /* @__PURE__ */ p("span", { children: n.label("honour") })]
				})
			] }),
			r && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("div", {
				className: "pw-card-group",
				children: [/* @__PURE__ */ p("div", {
					className: "pw-effects",
					children: r.workers.map((e, n) => /* @__PURE__ */ p(J, {
						kind: e,
						text: t
					}, n))
				}), r.attributes.map((e, t) => e > 0 && /* @__PURE__ */ p(J, {
					kind: [
						"influence",
						"faith",
						"strength",
						"diplomacy"
					][t],
					n: e
				}, t))]
			}), /* @__PURE__ */ p("p", {
				className: "pw-card-text",
				children: n.raw.abilities[r.ability]
			})] }),
			a && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("div", {
				className: "pw-card-group",
				children: [/* @__PURE__ */ p("small", { children: n.label("dismiss") }), /* @__PURE__ */ p(Z, { effects: a.dismiss })]
			}), /* @__PURE__ */ m("div", {
				className: "pw-card-group pw-ongoing",
				children: [
					/* @__PURE__ */ p("small", { children: n.label("hire") }),
					a.immediate.length > 0 && /* @__PURE__ */ p(Z, { effects: a.immediate }),
					/* @__PURE__ */ p("span", {
						className: "pw-card-text",
						children: a.trigger ? n.f(a.trigger === "inquisition" ? "inquisitionTrigger" : a.trigger === "suspicion" ? "suspicionTrigger" : a.trigger === "zeroTax" ? "zeroTaxTrigger" : "abilityTrigger", {
							action: n.label(a.trigger),
							reward: ""
						}) : ""
					}),
					a.reward.length > 0 && /* @__PURE__ */ p(Z, { effects: a.reward }),
					/* @__PURE__ */ p("span", {
						className: "pw-card-text",
						children: a.ability === "none" ? n.raw.townNoSuspicion : n.raw.abilities[a.ability]
					})
				]
			})] }),
			o && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("div", {
				className: "pw-card-group",
				children: [/* @__PURE__ */ m("small", { children: [
					n.label("attack"),
					" · ",
					n.name(o.nation)
				] }), /* @__PURE__ */ p(Z, { effects: o.attack })]
			}), /* @__PURE__ */ m("div", {
				className: "pw-card-group pw-ongoing",
				children: [
					/* @__PURE__ */ p("small", { children: n.label("convert") }),
					/* @__PURE__ */ p(J, {
						kind: "strength",
						n: o.strength
					}),
					/* @__PURE__ */ p(Tt, { id: e })
				]
			})] }),
			(s || c) && /* @__PURE__ */ m(f, { children: [
				c && /* @__PURE__ */ p("div", {
					className: "pw-card-group",
					children: /* @__PURE__ */ p(J, {
						kind: c.attribute,
						n: c.minimum
					})
				}),
				/* @__PURE__ */ m("div", {
					className: "pw-card-group",
					children: [/* @__PURE__ */ p(J, { kind: (s ?? c).worker }), (s ?? c).cost && /* @__PURE__ */ p(J, {
						kind: (s ?? c).cost,
						n: (s ?? c).price
					})]
				}),
				/* @__PURE__ */ p("div", {
					className: "pw-card-group pw-ongoing",
					children: /* @__PURE__ */ p(Z, { effects: (s ?? c).reward })
				})
			] }),
			l && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("div", {
				className: "pw-card-group",
				children: [
					/* @__PURE__ */ p("small", { children: n.label("entrust") }),
					/* @__PURE__ */ p(J, {
						kind: "diplomacy",
						n: l.diplomacy
					}),
					/* @__PURE__ */ m("span", { children: [
						n.label(l.action),
						" +",
						l.boost
					] })
				]
			}), /* @__PURE__ */ m("div", {
				className: "pw-card-group pw-ongoing",
				children: [
					/* @__PURE__ */ p("small", { children: n.label("enlist") }),
					/* @__PURE__ */ p(J, {
						kind: l.attribute,
						n: l.minimum
					}),
					/* @__PURE__ */ p("div", { children: l.icons.map((e, t) => /* @__PURE__ */ m("span", {
						className: "pw-noble-icon",
						children: [/* @__PURE__ */ p(q, { kind: e }), n.label(e)]
					}, t)) }),
					/* @__PURE__ */ p(J, {
						kind: "diplomacy",
						n: 1
					})
				]
			})] }),
			u && /* @__PURE__ */ m("div", {
				className: "pw-card-group",
				children: [u.action ? /* @__PURE__ */ m("span", { children: [
					n.label(u.action),
					" ≥ ",
					u.minimum
				] }) : Object.entries(u.attributes ?? {}).map(([e, t]) => /* @__PURE__ */ p(J, {
					kind: e,
					n: t
				}, e)), " "]
			}),
			d && /* @__PURE__ */ m("div", {
				className: "pw-card-group",
				children: [
					/* @__PURE__ */ p(J, {
						kind: "strength",
						n: d.strength
					}),
					/* @__PURE__ */ p(Z, { effects: d.reward }),
					d.vp > 0 && /* @__PURE__ */ m("span", { children: [
						d.vp,
						" ",
						n.label("points")
					] })
				]
			}),
			h && /* @__PURE__ */ p("div", {
				className: "pw-tavern-workers",
				children: h.workers.map((e, t) => /* @__PURE__ */ p(J, { kind: e }, t))
			})
		]
	});
}
//#endregion
//#region src/game/scenery.tsx
function Dt() {
	return /* @__PURE__ */ m("svg", {
		className: "pw-scenery",
		viewBox: "0 0 1600 1100",
		preserveAspectRatio: "xMidYMin slice",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ m("defs", { children: [
				/* @__PURE__ */ m("linearGradient", {
					id: "pw-field",
					x2: "0",
					y2: "1",
					children: [/* @__PURE__ */ p("stop", { stopColor: "#72854d" }), /* @__PURE__ */ p("stop", {
						offset: "1",
						stopColor: "#334f35"
					})]
				}),
				/* @__PURE__ */ m("linearGradient", {
					id: "pw-river",
					x2: "1",
					y2: "1",
					children: [/* @__PURE__ */ p("stop", { stopColor: "#83aeb1" }), /* @__PURE__ */ p("stop", {
						offset: "1",
						stopColor: "#376a7c"
					})]
				}),
				/* @__PURE__ */ m("linearGradient", {
					id: "pw-stone",
					x2: "0",
					y2: "1",
					children: [/* @__PURE__ */ p("stop", { stopColor: "#aaa58a" }), /* @__PURE__ */ p("stop", {
						offset: "1",
						stopColor: "#666e5c"
					})]
				})
			] }),
			/* @__PURE__ */ p("path", {
				fill: "url(#pw-field)",
				d: "M0 0h1600v1100H0z"
			}),
			/* @__PURE__ */ p("path", {
				fill: "#9b9e60",
				opacity: ".48",
				d: "M0 82 330 20l370 125 400-110 500 112V0H0Z"
			}),
			/* @__PURE__ */ p("path", {
				fill: "#b6ae6d",
				opacity: ".27",
				d: "m0 370 390-176 414 141-296 200ZM900 218l370-108 330 126v209Z"
			}),
			/* @__PURE__ */ p("path", {
				fill: "#223e2b",
				opacity: ".3",
				d: "m0 535 508-6 396 170-330 278L0 792Zm1080-100 520-88v359l-284 95-389-176Z"
			}),
			/* @__PURE__ */ p("path", {
				d: "M1600 80C1280 52 1290 216 1070 243S650 180 566 347s164 158 70 312S227 706 282 896s233 156 266 204",
				fill: "none",
				stroke: "#b2b583",
				strokeWidth: "44"
			}),
			/* @__PURE__ */ p("path", {
				d: "M1600 80C1280 52 1290 216 1070 243S650 180 566 347s164 158 70 312S227 706 282 896s233 156 266 204",
				fill: "none",
				stroke: "url(#pw-river)",
				strokeWidth: "31"
			}),
			/* @__PURE__ */ p("path", {
				d: "M1590 74c-280-14-306 159-520 163S663 178 578 349",
				fill: "none",
				stroke: "#c2dbca",
				strokeWidth: "3",
				opacity: ".46"
			}),
			/* @__PURE__ */ p("g", {
				fill: "none",
				stroke: "#c5bd80",
				strokeWidth: "2",
				opacity: ".22",
				children: /* @__PURE__ */ p("path", { d: "m0 156 252-54 240 95M0 173l250-54 215 91M0 190l249-54 190 87M822 372l300-81 288 154M843 394l275-74 278 146M866 416l247-65 270 136M0 745l224 88M0 767l230 87M0 790l240 88M1080 910l230-96 290 83M1095 935l218-94 287 83M1110 960l206-94 284 83" })
			}),
			/* @__PURE__ */ m("g", {
				transform: "translate(1080 28)",
				stroke: "#4c5847",
				strokeWidth: "3",
				children: [
					/* @__PURE__ */ p("path", {
						d: "M-120 112h500v34h-500Z",
						fill: "#455d3d",
						stroke: "none"
					}),
					/* @__PURE__ */ p("path", {
						d: "M-80 80h390v50H-80Z",
						fill: "url(#pw-stone)"
					}),
					/* @__PURE__ */ p("path", {
						d: "M-80 84V38h15v13h16V38h15v13h16V38h15v46m185 0V38h15v13h16V38h15v13h16V38h15v46",
						fill: "url(#pw-stone)"
					}),
					/* @__PURE__ */ p("path", {
						d: "M18 126V39h76v87M130 126V18h76v108M228 126V45h66v81",
						fill: "url(#pw-stone)"
					}),
					/* @__PURE__ */ p("path", {
						d: "m6 40 50-33 50 33Zm112-21 50-37 50 37Zm98 27 45-31 45 31Z",
						fill: "#6c4934"
					}),
					/* @__PURE__ */ p("path", {
						d: "M47 125V98q10-20 20 0v27M158 125V94q10-20 20 0v31M250 125V102q10-17 20 0v23",
						fill: "#354535"
					}),
					/* @__PURE__ */ p("path", {
						d: "M45 60h9v15h-9Zm115-17h10v20h-10Zm90 21h8v15h-8Z",
						fill: "#e0c17c",
						stroke: "none"
					}),
					/* @__PURE__ */ p("path", {
						d: "M169-16V-43l32 11-32 7",
						fill: "#a84d3b"
					})
				]
			}),
			/* @__PURE__ */ p("g", {
				fill: "#2e4e32",
				stroke: "#223c28",
				strokeWidth: "2",
				children: [
					[70, 300],
					[110, 320],
					[146, 293],
					[380, 665],
					[416, 687],
					[1280, 450],
					[1320, 468],
					[1370, 430],
					[1440, 780],
					[1490, 800],
					[800, 914]
				].map(([e, t], n) => /* @__PURE__ */ m("g", {
					transform: `translate(${e} ${t})`,
					children: [
						/* @__PURE__ */ p("path", {
							d: "M0 5v35",
							stroke: "#756741",
							strokeWidth: "6"
						}),
						/* @__PURE__ */ p("path", { d: "M-18 20q-25-20-6-36-6-25 17-23 18-18 30 3 28 0 24 24 16 24-12 34Z" }),
						/* @__PURE__ */ p("path", {
							d: "M-13-10q15-18 29-5",
							fill: "none",
							stroke: "#80905a",
							opacity: ".65"
						})
					]
				}, n))
			}),
			/* @__PURE__ */ p("path", {
				d: "m646 376 28 29 37-9-24-31Z",
				fill: "#ac9a72",
				stroke: "#4d5744",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ p("path", {
				d: "m656 378 26 20m-16-27 28 23",
				stroke: "#d0bd8d",
				strokeWidth: "3"
			})
		]
	});
}
//#endregion
//#region src/game/view-player.tsx
function Ot(e) {
	return /* @__PURE__ */ p(kt, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function kt({ pub: e, priv: t, members: s, myRid: u, send: d, readOnly: h = !1 }) {
	let g = K(), ee = c(), _ = n(null), te = n(null), [ne, re] = r({
		owner: u,
		rid: u
	}), [y, C] = r(null), w = ne.owner === u && e.order.includes(ne.rid) ? ne.rid : u, T = e.players.find((e) => e.rid === w) ?? e.players[0], E = e.players.find((e) => e.rid === u), D = h ? null : t?.decision, O = D?.choices ?? [], k = D?.title, A = (t) => t === "$paladins-automa" ? g.label("automa") : s.find((e) => e.rid === t)?.name || ee(o[(s.find((e) => e.rid === t)?.colorIndex ?? e.order.indexOf(t)) % o.length].nameKey), j = (t) => o[(s.find((e) => e.rid === t)?.colorIndex ?? Math.max(0, e.order.indexOf(t))) % o.length].hex, N = (e) => d({
		type: "choose",
		id: e.id
	}), P = (e) => O.filter((t) => t.card === e), ie = D ? g.label(k) : e.resolving ? g.label("resolving") : e.promptOwner ? g.f("waiting", { name: A(e.promptOwner) }) : g.label(e.phase), F = [
		"action",
		"assignWorkers",
		"retainWorkers",
		"loseWorker",
		"workerChoice",
		"chooseTarget",
		"moveWorkshop",
		"workshopDestination",
		"chooseRecipient"
	].includes(k ?? "");
	function I(e) {
		return /* @__PURE__ */ m("span", {
			className: "pw-target-info",
			children: [
				e.attribute && /* @__PURE__ */ p(J, {
					kind: e.attribute,
					n: e.minimum ?? 0
				}),
				" ",
				e.costs?.map((e, t) => /* @__PURE__ */ m("span", { children: [
					t > 0 && " / ",
					e.silver > 0 && /* @__PURE__ */ p(J, {
						kind: "silver",
						n: e.silver
					}),
					" ",
					e.provision > 0 && /* @__PURE__ */ p(J, {
						kind: "provision",
						n: e.provision
					}),
					" ",
					e.debts > 0 && /* @__PURE__ */ p(J, {
						kind: "debts",
						n: e.debts
					}),
					" ",
					!e.silver && !e.provision && !e.debts && g.label("free")
				] }, t))
			]
		});
	}
	function L(e) {
		return e.label === "payment" ? /* @__PURE__ */ m(f, { children: [
			/* @__PURE__ */ p(J, {
				kind: "silver",
				n: e.silver ?? 0
			}),
			/* @__PURE__ */ p(J, {
				kind: "provision",
				n: e.provision ?? 0
			}),
			(e.debts ?? 0) > 0 && /* @__PURE__ */ p(J, {
				kind: "debts",
				n: e.debts
			})
		] }) : e.preview ? /* @__PURE__ */ p(Z, { effects: e.preview.map((e) => ({
			...e,
			op: e.kind
		})) }) : e.recipient ? A(e.recipient) : /* @__PURE__ */ m(f, { children: [g.label(e.label), e.n === 2 && ["trade", "hunt"].includes(e.action ?? "") ? " ×3" : ""] });
	}
	function R(e, t, n) {
		if (e == null) return /* @__PURE__ */ p(X, {
			name: n ?? "empty",
			children: /* @__PURE__ */ p("div", {
				className: "pw-empty-card",
				"aria-label": g.label("empty"),
				children: /* @__PURE__ */ p("span", { children: "◇" })
			})
		});
		let r = P(e), i = !!(b[e] || x[e] || S[e]);
		return /* @__PURE__ */ m("div", {
			className: `pw-card-slot ${i ? "pw-character-slot" : ""}`,
			children: [
				/* @__PURE__ */ m(X, {
					name: n ?? `card:${e}`,
					className: "pw-card",
					style: { "--pw-owner": j(u) },
					children: [/* @__PURE__ */ m("button", {
						type: "button",
						className: "pw-card-pick",
						"aria-label": r.length === 1 ? g.f("confirmChoice", { name: wt(e, g) }) : wt(e, g),
						onClick: () => r.length === 1 ? N(r[0]) : C({
							owner: u,
							card: e
						}),
						children: [/* @__PURE__ */ p(Et, { id: e }), /* @__PURE__ */ p(Y, { on: r.length > 0 })]
					}), /* @__PURE__ */ p("button", {
						type: "button",
						className: "pw-inspect",
						"aria-label": g.label("inspect") + " " + wt(e, g),
						onClick: () => C({
							owner: u,
							card: e
						}),
						children: "＋"
					})]
				}),
				t && /* @__PURE__ */ p("div", {
					className: "pw-card-foot",
					children: t
				}),
				r.length === 1 && r[0].costs && /* @__PURE__ */ p("div", {
					className: "pw-card-foot",
					children: I(r[0])
				}),
				r.length > 1 && /* @__PURE__ */ p("div", {
					className: "pw-card-choices",
					children: r.map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => N(e),
						children: [L(e), I(e)]
					}, e.id))
				})
			]
		}, e);
	}
	function z(e) {
		let n = t?.plan?.action, r = M.includes(e), i = k === "action" ? O.filter((t) => t.action === e && !t.card) : [], a = k === "chooseTarget" && n === "pray" ? O.filter((t) => t.label === e) : [], o = k === "moveWorkshop" ? O.filter((t) => t.action === e) : [], s = T.placed[e] ?? [], c = r ? ge[e] : e === "develop" ? ["a", "a"] : e === "recruit" ? ["a", "r"] : e === "hunt" ? ["a", "g"] : e === "trade" ? ["a", "u"] : e === "pray" ? ["b"] : e === "honour" ? [T.honourWorker] : ["a"], l = T.counts[e] ?? 0, d = {
			commission: {
				cost: "provision",
				values: v.boards.monkFood
			},
			garrison: {
				cost: "provision",
				values: v.boards.outpostFood
			},
			fortify: {
				cost: "provision",
				values: v.boards.wallFood,
				minimum: v.boards.wallMinimum
			},
			absolve: {
				cost: "silver",
				values: v.boards.jarSilver,
				minimum: v.boards.jarMinimum
			},
			convert: {
				cost: "silver",
				values: v.boards.convertSilver
			}
		}[e], h = d?.values[l] ?? (e === "develop" ? 4 : e === "pray" ? 2 : e === "honour" ? 1 : void 0), ee = d?.cost ?? (e === "honour" && T.honourWorker === "r" ? "provision" : "silver"), _ = {
			commission: "faithByRegion",
			garrison: "strengthByRegion",
			attack: "attackByTarget",
			convert: "faithByOutsider",
			recruit: "recruitByTarget",
			muster: "musterByTarget",
			negotiate: "negotiateByTarget",
			order: "orderByTarget"
		};
		return /* @__PURE__ */ m(X, {
			name: `action:${T.rid}:${e}`,
			className: `pw-action ${r ? "pw-action-right" : ""} ${n === e ? "pw-action-selected" : ""}`,
			children: [
				/* @__PURE__ */ m("div", {
					className: "pw-action-head",
					children: [/* @__PURE__ */ p("strong", { children: g.label(e) }), (T.counts[e] ?? 0) > 0 && /* @__PURE__ */ p("span", {
						className: "pw-action-count",
						children: T.counts[e]
					})]
				}),
				e !== "order" && /* @__PURE__ */ p("span", {
					className: `pw-action-occupancy ${s.some(Boolean) ? "pw-action-occupied" : ""}`,
					children: g.label(s.some(Boolean) ? "occupied" : "unoccupied")
				}),
				/* @__PURE__ */ p("div", {
					className: "pw-worker-spaces",
					children: c.map((t, r) => {
						let i = T.workshops.some((t) => t.action === e && t.slot === r), a = (k === "chooseTarget" && n === "develop" || k === "workshopDestination") && T.rid === u ? O.find((t) => t.action === e && t.target === r) : void 0, c = o.find((e) => e.target === r), l = a ?? c, d = r - T.workshops.filter((t) => t.action === e && t.slot < r).length, f = i ? null : s[r], h = g.f("slot", {
							name: g.label(e),
							slot: g.label([
								"leftSlot",
								"middleSlot",
								"rightSlot"
							][r])
						}), ee = i ? g.label("workshop") : e === "order" ? "" : g.label(f ? "occupied" : "unoccupied");
						return /* @__PURE__ */ p(X, {
							name: i ? `workshop-slot:${T.rid}:${e}:${r}` : `worker-slot:${T.rid}:${e}:${d}`,
							children: /* @__PURE__ */ m("button", {
								type: "button",
								className: `pw-worker-space ${f ? "pw-worker-occupied" : ""}`,
								disabled: !l,
								"aria-label": [h, ee].filter(Boolean).join(" · "),
								onClick: () => l && N(l),
								children: [
									/* @__PURE__ */ p(q, {
										kind: i ? "workshop" : f ?? t,
										color: i ? j(T.rid) : void 0
									}),
									f && /* @__PURE__ */ p("span", {
										className: "pw-worker-mark",
										"aria-hidden": !0,
										children: "✓"
									}),
									/* @__PURE__ */ p(Y, { on: !!l })
								]
							})
						}, r);
					})
				}),
				r && /* @__PURE__ */ p("div", {
					className: "pw-action-progress",
					children: /* @__PURE__ */ p(J, {
						kind: e === "commission" ? "monk" : e === "garrison" ? "outpost" : e === "fortify" ? "wall" : e === "absolve" ? "jar" : e === "attack" ? "strength" : e === "convert" ? "faith" : "diplomacy",
						n: l
					})
				}),
				(d || h != null || _[e]) && /* @__PURE__ */ p("div", {
					className: "pw-action-requirements",
					children: d && l >= d.values.length ? /* @__PURE__ */ p("span", { children: g.label("trackComplete") }) : /* @__PURE__ */ m(f, { children: [
						d?.minimum && /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("span", { children: g.label("requires") }), /* @__PURE__ */ p(J, {
							kind: "influence",
							n: d.minimum[l]
						})] }),
						h != null && /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("span", { children: g.label("baseCost") }), /* @__PURE__ */ p(J, {
							kind: ee,
							n: h
						})] }),
						_[e] && /* @__PURE__ */ p("span", { children: g.label(_[e]) })
					] })
				}),
				T.rid === u && /* @__PURE__ */ p("div", {
					className: "pw-action-choices",
					children: [...i, ...a].map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => N(e),
						children: [L(e), /* @__PURE__ */ p(Y, {})]
					}, e.id))
				}),
				n === e && k === "assignWorkers" && T.rid === u && /* @__PURE__ */ m("div", {
					className: "pw-assigned",
					children: [t?.plan?.workers.map((e, t) => /* @__PURE__ */ p(q, { kind: e }, t)), /* @__PURE__ */ p("span", { children: "…" })]
				})
			]
		}, e);
	}
	let B = k && [
		"selectPaladin",
		"reusePaladin",
		"paladinTop",
		"paladinRemove",
		"tavern",
		"startingTown"
	].includes(k);
	return /* @__PURE__ */ p("div", {
		className: "pw-root",
		children: /* @__PURE__ */ m(l, {
			adaptive: !0,
			scroll: !1,
			actionsHeight: "pw-footer-height",
			banner: /* @__PURE__ */ m("header", {
				className: "pw-banner",
				children: [/* @__PURE__ */ m("div", {
					className: "pw-round",
					children: [/* @__PURE__ */ p("b", { children: g.f("round", { n: e.round }) }), /* @__PURE__ */ p("span", {
						className: "pw-phase",
						role: "status",
						children: ie
					})]
				}), /* @__PURE__ */ p("nav", {
					className: "pw-players",
					"aria-label": g.label("viewEstate"),
					children: e.players.map((t) => {
						let n = s.find((e) => e.rid === t.rid), r = j(t.rid);
						return /* @__PURE__ */ p(X, {
							name: `seat:${t.rid}`,
							className: "pw-seat-anchor",
							children: /* @__PURE__ */ m("button", {
								type: "button",
								className: `pw-seat ${w === t.rid ? "pw-seat-viewed" : ""}`,
								style: { "--pw-seat-color": r },
								"aria-pressed": w === t.rid,
								onClick: () => re({
									owner: u,
									rid: t.rid
								}),
								children: [
									/* @__PURE__ */ p("img", {
										src: i(a[(n?.avatar ?? e.order.indexOf(t.rid)) % a.length]),
										alt: ""
									}),
									/* @__PURE__ */ m("span", {
										className: "pw-seat-info",
										children: [/* @__PURE__ */ p("strong", { children: A(t.rid) }), /* @__PURE__ */ p("span", {
											className: "pw-seat-attrs",
											children: [
												"influence",
												"faith",
												"strength",
												...e.config.city ? ["diplomacy"] : []
											].map((e) => /* @__PURE__ */ p(J, {
												kind: e,
												n: t.attributes[e],
												text: !1
											}, e))
										})]
									}),
									e.active === t.rid && /* @__PURE__ */ p("span", { className: "pw-active-dot" })
								]
							})
						}, t.rid);
					})
				})]
			}),
			actions: /* @__PURE__ */ m("footer", {
				className: "pw-footer",
				children: [/* @__PURE__ */ m("div", {
					className: "pw-footer-line",
					children: [/* @__PURE__ */ p("span", { children: ie }), /* @__PURE__ */ m("nav", { children: [
						/* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => _.current?.scrollIntoView({
								behavior: "smooth",
								block: "start"
							}),
							children: g.label("board")
						}),
						/* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => te.current?.scrollIntoView({
								behavior: "smooth",
								block: "start"
							}),
							children: g.label("estate")
						}),
						D?.cancel && /* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => d({ type: "cancel" }),
							children: g.label("cancel")
						}),
						k === "action" && /* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => N(O.find((e) => e.label === "pass")),
							children: g.label("pass")
						})
					] })]
				}), /* @__PURE__ */ p(X, {
					name: `stock:${u}`,
					className: "pw-stock",
					children: E && Object.entries(E.workers).map(([e, t]) => {
						let n = k === "assignWorkers" || k === "retainWorkers" || k === "loseWorker" || k === "workerChoice" ? O.find((t) => t.worker === e) : void 0;
						return /* @__PURE__ */ m("button", {
							type: "button",
							disabled: !n,
							onClick: () => n && N(n),
							"aria-label": g.f("amount", {
								n: t,
								name: g.label(e)
							}),
							children: [
								/* @__PURE__ */ p(Ct, {
									name: `stock-worker:${u}:${e}`,
									className: "pw-stock-worker",
									children: /* @__PURE__ */ p(q, { kind: e })
								}),
								/* @__PURE__ */ p("b", { children: t }),
								/* @__PURE__ */ p("span", { children: g.label(e) }),
								/* @__PURE__ */ p(Y, { on: !!n })
							]
						}, e);
					})
				})]
			}),
			children: [
				/* @__PURE__ */ m("div", {
					className: "pw-world",
					children: [
						/* @__PURE__ */ p(Dt, {}),
						B && /* @__PURE__ */ m("section", {
							className: "pw-private-draft",
							children: [/* @__PURE__ */ p("h2", { children: ie }), /* @__PURE__ */ p("div", {
								className: "pw-draft-row",
								children: O.map((e) => e.card == null ? /* @__PURE__ */ p("button", {
									onClick: () => N(e),
									children: L(e)
								}, e.id) : /* @__PURE__ */ p("div", { children: R(e.card) }, e.id))
							})]
						}),
						/* @__PURE__ */ m("div", {
							className: "pw-table-grid",
							children: [/* @__PURE__ */ m("div", {
								className: "pw-kingdom",
								ref: _,
								children: [
									/* @__PURE__ */ m("section", {
										className: "pw-market",
										children: [/* @__PURE__ */ p("h2", { children: g.label("townsfolk") }), /* @__PURE__ */ m("div", {
											className: "pw-card-row",
											children: [e.market.townsfolk.map((t, n) => /* @__PURE__ */ p("div", { children: R(t, /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(J, {
												kind: "silver",
												n: (e.config.city ? v.boards.cityTownSilver : v.boards.townSilver)[n]
											}), n < 2 && /* @__PURE__ */ p(q, {
												kind: "debts",
												size: 20
											})] }), `town:${n}`) }, n)), e.config.city && /* @__PURE__ */ p("div", { children: R(e.deckTops.townsfolk, /* @__PURE__ */ m(f, { children: [
												/* @__PURE__ */ p("span", { children: g.label("deck") }),
												/* @__PURE__ */ p(J, {
													kind: "silver",
													n: 3
												}),
												/* @__PURE__ */ p(q, {
													kind: "debts",
													size: 20
												})
											] }), "town:deck") })]
										})]
									}),
									/* @__PURE__ */ m("section", {
										className: "pw-royal",
										children: [/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("h2", { children: g.label("kingOrders") }), /* @__PURE__ */ p("div", {
											className: "pw-orders",
											children: [
												0,
												1,
												2
											].map((t) => /* @__PURE__ */ p("div", {
												className: "pw-order",
												children: e.orders[t] ? R(e.orders[t], /* @__PURE__ */ m("span", { children: [
													[
														4,
														6,
														8
													][t],
													" ",
													g.label("points"),
													e.orderOwners[t] ? " · " + A(e.orderOwners[t]) : ""
												] })) : /* @__PURE__ */ m("div", {
													className: "pw-sealed",
													children: [/* @__PURE__ */ p(q, {
														kind: "honour",
														size: 35
													}), /* @__PURE__ */ p("span", { children: t + 1 })]
												})
											}, t))
										})] }), /* @__PURE__ */ m(X, {
											name: "tax",
											className: "pw-tax",
											children: [/* @__PURE__ */ p(J, {
												kind: "tax",
												n: e.tax
											}), /* @__PURE__ */ p("small", { children: g.label("taxPool") })]
										})]
									}),
									/* @__PURE__ */ m("section", {
										className: "pw-regions",
										children: [/* @__PURE__ */ p("h2", { children: g.label("board") }), /* @__PURE__ */ p("div", {
											className: "pw-region-columns",
											children: Array.from({ length: e.config.city ? 7 : 6 }, (n, r) => /* @__PURE__ */ m("div", {
												className: "pw-region",
												children: [/* @__PURE__ */ m("div", {
													className: "pw-battlement",
													children: [/* @__PURE__ */ p(J, {
														kind: "faith",
														n: r * 2
													}), /* @__PURE__ */ p(J, {
														kind: "strength",
														n: r * 2 + 1
													})]
												}), /* @__PURE__ */ p("div", {
													className: "pw-region-spaces",
													children: v.regions.filter((t) => t.region === r && t.players <= e.order.length).map((n) => {
														let i = e.regions[n.id], a = k === "chooseTarget" && ["commission", "garrison"].includes(t?.plan?.action ?? "") ? O.find((e) => e.target === n.id) : void 0;
														return /* @__PURE__ */ p(X, {
															name: `region:${n.id}`,
															children: /* @__PURE__ */ m("button", {
																type: "button",
																className: "pw-region-space",
																disabled: !a,
																onClick: () => a && N(a),
																"aria-label": g.label(t?.plan?.action ?? "commission") + " " + r + " · " + n.id,
																children: [i ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(q, {
																	kind: i.kind,
																	color: j(i.rid)
																}), /* @__PURE__ */ p("small", { children: A(i.rid) })] }) : /* @__PURE__ */ p(Z, { effects: n.reward }), /* @__PURE__ */ p(Y, { on: !!a })]
															})
														}, n.id);
													})
												})]
											}, r))
										})]
									}),
									/* @__PURE__ */ m("section", { children: [/* @__PURE__ */ p("h2", { children: g.label("outsiders") }), /* @__PURE__ */ m("div", {
										className: "pw-card-row",
										children: [e.market.outsiders.map((e, t) => /* @__PURE__ */ p("div", { children: R(e, /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(J, {
											kind: "strength",
											n: t * 2 + 1
										}), /* @__PURE__ */ p(J, {
											kind: "faith",
											n: t * 2
										})] }), `outsider:${t}`) }, t)), e.config.city && /* @__PURE__ */ p("div", { children: R(e.deckTops.outsiders, /* @__PURE__ */ m(f, { children: [
											/* @__PURE__ */ p("span", { children: g.label("deck") }),
											/* @__PURE__ */ p(J, {
												kind: "strength",
												n: 13
											}),
											/* @__PURE__ */ p(J, {
												kind: "faith",
												n: 12
											})
										] }), "outsider:deck") })]
									})] }),
									/* @__PURE__ */ m("section", { children: [/* @__PURE__ */ p("h2", { children: g.label("kingFavours") }), /* @__PURE__ */ p("div", {
										className: "pw-card-row pw-favour-row",
										children: e.favours.map((t, n) => /* @__PURE__ */ p("div", { children: R(t, /* @__PURE__ */ p("span", { children: e.favourWorkers[n]?.map((e) => A(e.rid)).join(" · ") || g.label("available") })) }, t))
									})] }),
									e.config.city && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("section", { children: [/* @__PURE__ */ p("h2", { children: g.label("muster") }), /* @__PURE__ */ p("div", {
										className: "pw-card-row",
										children: e.muster.map((t, n) => /* @__PURE__ */ p("div", {
											className: e.diplomat === n ? "pw-diplomat" : "",
											children: R(t[0] ?? null, /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", { children: e.diplomat === n ? g.label("diplomacy") : g.f("move", { n: Math.abs(e.diplomat - n) }) }), t[0] != null && (e.musterWorkers[t[0]] ?? []).map((e) => /* @__PURE__ */ p(q, { kind: e.worker }, e.rid))] }))
										}, n))
									})] }), /* @__PURE__ */ m("section", { children: [/* @__PURE__ */ p("h2", { children: g.label("negotiate") }), /* @__PURE__ */ m("div", {
										className: "pw-card-row",
										children: [e.market.negotiate.map((e, t) => /* @__PURE__ */ p("div", { children: R(e, /* @__PURE__ */ p(J, {
											kind: "silver",
											n: [
												2,
												1,
												1
											][t]
										}), `negotiate:${t}`) }, t)), /* @__PURE__ */ p("div", { children: R(e.deckTops.negotiate, /* @__PURE__ */ m(f, { children: [
											/* @__PURE__ */ p("span", { children: g.label("deck") }),
											/* @__PURE__ */ p(J, {
												kind: "silver",
												n: 3
											}),
											/* @__PURE__ */ p(q, { kind: "debts" })
										] }), "negotiate:deck") })]
									})] })] }),
									e.config.cooperative && /* @__PURE__ */ m("section", { children: [/* @__PURE__ */ p("h2", { children: g.label("threats") }), /* @__PURE__ */ p("div", {
										className: "pw-threats",
										children: e.threats.map((e) => /* @__PURE__ */ m("div", {
											className: "pw-threat",
											children: [
												/* @__PURE__ */ p("b", { children: g.label("threatTarget" + e.card) }),
												/* @__PURE__ */ p(J, {
													kind: "worker",
													n: e.workers
												}),
												/* @__PURE__ */ p("span", { children: g.label("threatPenalty" + e.card) })
											]
										}, e.card))
									})] })
								]
							}), /* @__PURE__ */ m("div", {
								className: "pw-estate",
								ref: te,
								children: [
									/* @__PURE__ */ p("h2", { children: g.f("owns", { name: A(T.rid) }) }),
									/* @__PURE__ */ m("div", {
										className: `pw-estate-overview ${T.paladin == null ? "pw-without-paladin" : ""}`,
										children: [
											T.paladin != null && /* @__PURE__ */ p("div", {
												className: "pw-chosen-paladin",
												children: R(T.reused ?? T.paladin)
											}),
											/* @__PURE__ */ m("div", {
												className: "pw-estate-ledger",
												children: [/* @__PURE__ */ p("div", {
													className: "pw-estate-resources",
													children: [
														"silver",
														"provision",
														"suspicion",
														"debts",
														...e.config.cooperative ? ["honour"] : []
													].map((e) => /* @__PURE__ */ p(X, {
														name: `resource:${T.rid}:${e}`,
														children: /* @__PURE__ */ p(J, {
															kind: e,
															n: e === "suspicion" ? T.suspicion.length : e === "debts" ? T.debts.filter((e) => !e).length : T[e]
														})
													}, e))
												}), /* @__PURE__ */ p("div", {
													className: "pw-attribute-track",
													children: [
														"influence",
														"faith",
														"strength",
														...e.config.city ? ["diplomacy"] : []
													].map((e) => /* @__PURE__ */ m(X, {
														name: `resource:${T.rid}:${e}`,
														className: "pw-attribute",
														children: [
															/* @__PURE__ */ p(J, {
																kind: e,
																n: T.attributes[e]
															}),
															/* @__PURE__ */ p("div", {
																className: "pw-track",
																children: /* @__PURE__ */ p("i", { style: {
																	width: `${T.attributes[e] / 12 * 100}%`,
																	background: At[e]
																} })
															}),
															T.paladin != null && (b[T.reused ?? T.paladin].attributes[[
																"influence",
																"faith",
																"strength",
																"diplomacy"
															].indexOf(e)] ?? 0) > 0 && /* @__PURE__ */ m("small", { children: ["+", b[T.reused ?? T.paladin].attributes[[
																"influence",
																"faith",
																"strength",
																"diplomacy"
															].indexOf(e)]] })
														]
													}, e))
												})]
											}),
											/* @__PURE__ */ m("section", {
												className: "pw-jars",
												children: [/* @__PURE__ */ p("h3", { children: g.label("jars") }), /* @__PURE__ */ p("div", { children: ye.map((e, n) => {
													let r = k === "chooseTarget" && t?.plan?.action === "absolve" && T.rid === u ? O.find((e) => e.target === n) : void 0;
													return /* @__PURE__ */ p(X, {
														name: `jar:${T.rid}:${n}`,
														children: /* @__PURE__ */ m("button", {
															type: "button",
															disabled: !r,
															onClick: () => r && N(r),
															className: T.jars.includes(n) ? "pw-jar-used" : "",
															"aria-label": g.label("jar") + " " + (n + 1),
															children: [
																/* @__PURE__ */ p(q, {
																	kind: "jar",
																	size: 35
																}),
																/* @__PURE__ */ p(Z, { effects: e }),
																/* @__PURE__ */ p(Y, { on: !!r })
															]
														})
													}, n);
												}) })]
											})
										]
									}),
									/* @__PURE__ */ m("div", {
										className: "pw-estate-actions",
										children: [/* @__PURE__ */ p("div", {
											className: "pw-left-actions",
											children: [
												"develop",
												"recruit",
												"pray",
												"hunt",
												"trade",
												"conspire",
												...e.config.cooperative ? ["honour", "order"] : []
											].map(z)
										}), /* @__PURE__ */ p("div", {
											className: "pw-right-actions",
											children: M.filter((t) => e.config.city || !["muster", "negotiate"].includes(t)).map(z)
										})]
									}),
									T.rid === u && t?.secretOrder && /* @__PURE__ */ m("div", {
										className: "pw-secret",
										children: [/* @__PURE__ */ m("h3", { children: [
											g.label("secretOrder"),
											" · ",
											g.f("private")
										] }), R(t.secretOrder, void 0, "secretOrder")]
									}),
									/* @__PURE__ */ m("section", { children: [/* @__PURE__ */ p("h3", { children: g.label("townsfolk") }), /* @__PURE__ */ p("div", {
										className: "pw-owned-cards",
										children: T.townsfolk.map((e) => R(e))
									})] }),
									/* @__PURE__ */ m("section", { children: [/* @__PURE__ */ p("h3", { children: g.label("converts") }), /* @__PURE__ */ p("div", {
										className: "pw-owned-cards",
										children: T.converted.map((e) => R(e))
									})] }),
									/* @__PURE__ */ m("section", { children: [/* @__PURE__ */ p("h3", { children: g.label("walls") }), /* @__PURE__ */ p("div", {
										className: "pw-owned-cards",
										children: T.walls.map((e) => R(e))
									})] }),
									e.config.city && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("section", { children: [/* @__PURE__ */ p("h3", { children: g.label("enlist") }), /* @__PURE__ */ p("div", {
										className: "pw-owned-cards",
										children: T.enlisted.map((e) => R(e))
									})] }), /* @__PURE__ */ m("section", { children: [/* @__PURE__ */ p("h3", { children: g.label("muster") }), /* @__PURE__ */ p("div", {
										className: "pw-owned-cards",
										children: T.muster.map((e) => R(e))
									})] })] }),
									/* @__PURE__ */ m("section", {
										className: "pw-journal",
										children: [/* @__PURE__ */ p("h3", { children: g.label("chronicle") }), e.journal.slice(-10).reverse().map((e, t) => /* @__PURE__ */ m("p", { children: [
											e.rid ? A(e.rid) + " · " : "",
											g.label(e.kind === "suspicion" ? "drawSuspicion" : e.kind),
											e.card != null && e.kind !== "suspicion" ? " · " + wt(e.card, g) : "",
											e.resource ? " · " + g.label(e.resource) : "",
											e.n == null ? "" : " " + e.n
										] }, t))]
									})
								]
							})]
						})
					]
				}),
				D && !B && (!F || k === "chooseRecipient") && /* @__PURE__ */ m("div", {
					className: "pw-decision-overlay",
					children: [/* @__PURE__ */ p("h2", { children: ie }), /* @__PURE__ */ p("div", { children: O.map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => N(e),
						children: [
							e.card && /* @__PURE__ */ p(Et, { id: e.card }),
							/* @__PURE__ */ p("span", { children: L(e) }),
							/* @__PURE__ */ p(Y, {})
						]
					}, e.id)) })]
				}),
				y?.owner === u && /* @__PURE__ */ p("div", {
					className: "pw-modal-backdrop",
					onClick: () => C(null),
					children: /* @__PURE__ */ m("section", {
						className: "pw-inspection",
						role: "dialog",
						"aria-modal": "true",
						"aria-label": wt(y.card, g),
						onClick: (e) => e.stopPropagation(),
						children: [
							/* @__PURE__ */ m("button", {
								type: "button",
								className: "pw-close",
								onClick: () => C(null),
								children: [g.label("close"), " ×"]
							}),
							/* @__PURE__ */ p(Et, {
								id: y.card,
								detail: !0
							}),
							P(y.card).map((e) => /* @__PURE__ */ p("button", {
								type: "button",
								className: "pw-confirm",
								onClick: () => {
									N(e), C(null);
								},
								children: L(e)
							}, e.id))
						]
					})
				})
			]
		})
	});
}
var At = {
	influence: "#4d82aa",
	faith: "#4b534d",
	strength: "#b45846",
	diplomacy: "#e4dcc6"
}, jt = {
	economy: 1,
	engine: 1.6,
	goal: 2,
	diversity: .5,
	wildcard: 1
};
function Mt(e, t) {
	return e.counts[t] ?? 0;
}
function Q(e, t, n) {
	if (t === "silver" || t === "tax") return e.silver < 2 ? 1.5 : e.silver < 5 ? .95 : .35;
	if (t === "provision") return e.provision < 2 ? 1.65 : e.provision < 4 ? 1 : .35;
	if (t in e.workers) return t === "p" ? 1.9 : t === "w" ? 1.4 : 1.8;
	if (t === "honour") return e.honour >= 12 ? 0 : n > 5 ? 2 : 1.1;
	if (t in e.attributes) {
		let r = e.attributes[t];
		return r >= 12 ? 0 : v.boards.attributes[r + 1] - v.boards.attributes[r] + (8 - n) * .23;
	}
	return 0;
}
function $(e, t, n) {
	return e.reduce((e, r) => e + (r.op === "gain" ? Q(t, r.resource, n) * (r.n ?? 1) : r.op === "repay" || r.op === "destroyDebt" ? t.debts.includes(!1) ? 4 : 0 : r.op === "debt" ? -3 : r.op === "removeSuspicion" ? Math.min(t.suspicion.length, r.n ?? 1) * .9 : r.op === "pray" ? Object.values(t.placed).some((e) => e.some((e) => e != null)) ? 2.5 : 0 : r.op === "recruit" ? (8 - n) * .7 + 2 : r.op === "develop" ? (8 - n) * .7 + 1 : r.op === "choice" ? Math.max(...(r.choices ?? []).map((e) => $(e, t, n))) : r.op === "ordered" ? $(r.effects ?? [], t, n) : r.op === "attribute" ? 2 : r.op === "workerChoice" ? 1.8 : 0), 0);
}
function Nt(e, t, n, r, i = 1) {
	let a = e.round, o = Mt(t, n), s = [...e.orders, ...(e.config.city, [])].filter((e) => T[e].action === n && o < (T[e].minimum ?? 5)).reduce((t, n) => t + (o >= 4 ? 3.5 : 1.1) * ([
		4,
		6,
		8
	][e.orders.indexOf(n)] ?? 6) / 6, 0) * r.goal, c = Q(t, n === "commission" ? "influence" : n === "garrison" || n === "absolve" ? "faith" : n === "fortify" || n === "convert" ? "strength" : "diplomacy", a), l = t.workshops.filter((e) => e.action === n).length;
	return (n === "develop" ? (8 - a) * .85 * r.engine + .7 : n === "hire" ? (8 - a) * .65 * r.engine + 1.7 : n === "dismiss" ? 3.4 : n === "trade" ? (i === 2 ? 3 : 1) * Q(t, "silver", a) * r.economy : n === "hunt" ? (i === 2 ? 3 : 1) * Q(t, "provision", a) * r.economy : n === "conspire" ? 2.9 - t.suspicion.length * .16 : n === "pray" ? Math.max(0, ...Object.keys(t.placed).filter((e) => t.placed[e].some((e) => e != null) && e !== "pray").map((e) => 1.8 + t.workshops.filter((t) => t.action === e).length * .65)) : n === "honour" ? Q(t, "honour", a) + Math.min(t.suspicion.length, 1) * .8 : n === "order" ? 12 : n === "attack" ? 4.4 + c : n === "convert" ? 4 + c + (a >= 5 ? 1.2 : 0) : n === "absolve" ? 3.1 + c + Math.min(2, t.suspicion.length) * .7 + (t.debts.includes(!1) ? 1.5 : 0) : n === "negotiate" ? 4.4 + c : n === "muster" ? 4 + c : 3.3 + c + (o >= 4 ? 1.5 : 0)) + s + l * .5 + (o < 2 ? r.diversity * .4 : 0);
}
function Pt(e, t, n, r, i = jt) {
	let a = e.players.find((e) => e.rid === n), o = t.decision.title, s = e.round;
	if (o === "choosePayment") return -(r.silver ?? 0) * Q(a, "silver", s) - (r.provision ?? 0) * Q(a, "provision", s) - (r.debts ?? 0) * 3.2;
	if (r.label === "pass") return -20;
	if (r.worker) {
		let e = a.workers[r.worker];
		return -(r.worker === "p" || r.worker === "y" ? 2.2 * i.wildcard : r.worker === "w" ? .25 : .6 + .7 / e);
	}
	if (o === "chooseRecipient") return +(r.recipient === n);
	if (o === "selectPaladin" || o === "reusePaladin" || o === "paladinTop" || o === "paladinRemove") {
		let e = b[r.card], t = e.workers.reduce((e, t) => e + Q(a, t, s), 0) + e.attributes.reduce((e, t, n) => e + t * (a.attributes[[
			"influence",
			"faith",
			"strength",
			"diplomacy"
		][n]] < 5 ? .7 : .3), 0);
		return o === "paladinRemove" ? -t : t;
	}
	if (o === "tavern") return v.taverns.find((e) => e.id === r.card).workers.reduce((e, t) => e + Q(a, t, s), 0);
	if (o === "action") {
		if (r.action === "favour") return $(w[r.card].reward, a, s) + .4;
		if (r.action === "musterFavour") return $(E[r.card].reward, a, s) + .4;
		let n = r.label === "hire" || r.label === "dismiss" ? r.label : r.action, o = n === "hire" || n === "develop" ? 2 : n in ge ? 3 - a.workshops.filter((e) => e.action === n).length : r.n ?? 1;
		return Nt(e, a, n, i, r.n) / Math.max(1, o) + (t.secretOrder && T[t.secretOrder].action === n ? i.goal * .8 : 0);
	}
	if (r.card != null) {
		let n = x[r.card], c = S[r.card], l = E[r.card], u = D[r.card];
		if (n) {
			let t = r.label === "dismiss" || o === "dismissOwn" ? $(n.dismiss, a, s) : $(n.immediate, a, s) + $(n.reward, a, s) * (8 - s) * i.engine * .7 + (n.ability ? 1.7 : 0), c = e.market.townsfolk.indexOf(r.card), l = e.config.city ? v.boards.cityTownSilver : v.boards.townSilver;
			return t - (c >= 0 ? l[c] : 3) * .2;
		}
		if (c) return r.action === "attack" ? $(c.attack, a, s) : 2 + $([{
			op: "gain",
			resource: "strength",
			n: c.strength
		}], a, s) + (c.score.kind === "orders" ? 2 : 0);
		if (l) return $(l.reward, a, s) + (t.plan?.action === "muster" ? 1.5 : 0);
		if (u) return r.label === "entrust" ? Nt(e, a, u.action, i) + u.boost * .3 : 2.5 + u.icons.reduce((e, t) => e + (a.enlisted.some((e) => D[e].icons.includes(t)) ? 1 : 1.7), 0);
	}
	return o === "chooseTarget" && t.plan?.action === "develop" || o === "workshopDestination" ? Nt(e, a, r.label, i) + (r.target === 0 ? .3 : 0) : o === "chooseTarget" && r.action === "absolve" ? r.target === 2 || r.target === 7 ? a.debts.includes(!1) ? 5 : 0 : r.target === 4 ? 3 : r.target === 5 ? 2 : 1 : o === "chooseTarget" && ["commission", "garrison"].includes(r.action) ? $(v.regions[r.target].reward, a, s) : o === "chooseTarget" && r.action === "pray" ? Nt(e, a, r.label, i) : o === "destroyDebt" ? r.label === "unpaidDebt" ? 3 : -1 : o === "threatPenalty" ? r.label === "loseHonour" ? a.honour > Math.max(...Object.values(a.attributes)) ? 2 : -2 : 0 : o === "reward" ? $((r.preview ?? []).map((e) => ({
		...e,
		op: e.kind
	})), a, s) : r.label in a.attributes ? Q(a, r.label, s) : 0;
}
function Ft(e = jt) {
	return (t, n) => {
		let r = t.private, i = t.public;
		if (!r?.decision || i.promptOwner !== n.rid) return null;
		let a = r.decision.choices;
		return a.length ? { action: {
			type: "choose",
			id: (n.difficulty === "weak" ? a[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % a.length] : [...a].sort((t, a) => Pt(i, r, n.rid, a, e) - Pt(i, r, n.rid, t, e))[0]).id
		} } : null;
	};
}
var It = Ft();
//#endregion
//#region src/game/fx.tsx
function Lt({ kind: e, n: t }) {
	let n = K();
	return /* @__PURE__ */ m("span", {
		className: "pw-fx-label",
		children: [t != null && (t > 0 ? "+" : "") + t + " ", n.label(e)]
	});
}
var Rt = {
	action(e, t) {
		let n = e.data, r = t.anchor(`action:${e.rid}:${n.action}`) ?? t.anchor(`seat:${e.rid}`), i = t.anchor(`stock:${e.rid}`) ?? t.anchor(`seat:${e.rid}`), a = n.card == null ? null : t.anchor(`card:${n.card}`), o = t.anchor(n.source), s = n.target != null && ["commission", "garrison"].includes(n.action) ? t.anchor(`region:${n.target}`) : null, c = t.queued ? 180 : N.action, l = n.workers.map((r, a) => {
			let o = t.anchor(`stock-worker:${e.rid}:${r}`) ?? i, s = t.anchor(`worker-slot:${e.rid}:${n.action}:${a}`);
			return o && s ? /* @__PURE__ */ p(g, {
				from: o,
				to: {
					x: s.x + (s.w - 25) / 2,
					y: s.y + (s.h - 30) / 2,
					w: 25,
					h: 30
				},
				ms: c * .8,
				children: /* @__PURE__ */ p("div", {
					style: {
						width: 25,
						height: 30,
						display: "grid",
						placeItems: "center"
					},
					children: /* @__PURE__ */ p(q, { kind: r })
				})
			}, a) : null;
		});
		return {
			ms: c,
			node: /* @__PURE__ */ m(f, { children: [
				l,
				r && /* @__PURE__ */ p(ee, {
					at: r,
					ms: c
				}),
				" ",
				s && /* @__PURE__ */ p(ee, {
					at: s,
					ms: c
				}),
				" ",
				a && o && /* @__PURE__ */ p(g, {
					from: o,
					to: a,
					ms: c * .9,
					children: /* @__PURE__ */ p("div", {
						className: "pw-fx-card",
						style: { width: o.w },
						children: /* @__PURE__ */ p(Et, { id: n.card })
					})
				})
			] }),
			hide: a && o && !t.queued ? [`card:${n.card}`] : []
		};
	},
	gain(e, t) {
		let n = e.data, r = t.anchor(`resource:${e.rid}:${n.resource}`) ?? t.anchor(`stock:${e.rid}`) ?? t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: N.effect,
			node: /* @__PURE__ */ p(h, {
				at: r,
				ms: N.effect,
				children: /* @__PURE__ */ p(Lt, {
					kind: n.resource,
					n: n.n
				})
			})
		} : null;
	},
	inquisition(e, t) {
		let n = t.anchor("tax");
		return n ? {
			ms: N.inquisition,
			node: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(ee, {
				at: n,
				ms: N.inquisition
			}), /* @__PURE__ */ p(h, {
				at: n,
				ms: N.inquisition,
				children: /* @__PURE__ */ p(Lt, { kind: "inquisition" })
			})] })
		} : null;
	},
	refillTax(e, t) {
		let n = t.anchor("tax");
		return n ? {
			ms: N.effect,
			node: /* @__PURE__ */ p(h, {
				at: n,
				ms: N.effect,
				children: /* @__PURE__ */ p(Lt, {
					kind: "tax",
					n: e.data.n
				})
			})
		} : null;
	},
	round(e, t) {
		let n = t.anchor("tax");
		return n ? {
			ms: N.round,
			node: /* @__PURE__ */ p(h, {
				at: n,
				ms: N.round,
				children: /* @__PURE__ */ p(Lt, { kind: "roundStart" })
			})
		} : null;
	}
};
for (let e of [
	"suspicion",
	"removeSuspicion",
	"debt",
	"repay",
	"destroyDebt",
	"workshop",
	"dismiss",
	"ally",
	"reveal",
	"done"
]) Rt[e] = (t, n) => {
	let r = n.anchor(`seat:${t.rid}`) ?? n.anchor("tax");
	return r ? {
		ms: N.effect,
		node: /* @__PURE__ */ p(h, {
			at: r,
			ms: N.effect,
			children: /* @__PURE__ */ p(Lt, { kind: e })
		})
	} : null;
};
//#endregion
//#region src/game/game-over.tsx
function zt(e) {
	let t = e.public, n = K(), s = c(), [l, u] = r(!0), d = (r) => r === "$paladins-automa" ? n.label("automa") : e.members.find((e) => e.rid === r)?.name || s(o[(e.members.find((e) => e.rid === r)?.colorIndex ?? Math.max(0, t.order.indexOf(r))) % o.length].nameKey), f = [
		"attributes",
		"orders",
		...t.config.city ? ["secretOrder"] : [],
		"workshops",
		"monks",
		"outposts",
		"walls",
		"jars",
		"converts",
		"debts",
		"resources",
		...t.config.city ? ["muster", "negotiation"] : [],
		...t.config.cooperative ? ["threats"] : [],
		"total"
	], h = t.humans.reduce((e, n) => e + (t.score[n]?.total ?? 0), 0);
	return /* @__PURE__ */ m("div", {
		className: "pw-root pw-over",
		children: [
			/* @__PURE__ */ p("div", {
				className: "pw-over-board",
				"aria-hidden": l,
				inert: l,
				children: /* @__PURE__ */ p(kt, {
					...e,
					pub: t,
					priv: e.private,
					send: () => {},
					readOnly: !0
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "pw-result-shade",
				style: { display: l ? void 0 : "none" },
				children: /* @__PURE__ */ m("section", {
					className: "pw-result",
					children: [
						/* @__PURE__ */ m("header", {
							className: "pw-result-heading",
							children: [
								/* @__PURE__ */ p(q, {
									kind: "honour",
									size: 45
								}),
								/* @__PURE__ */ p("h1", { children: n.label("result") }),
								/* @__PURE__ */ p("p", { children: t.config.cooperative ? n.f("victoryGoal", {
									n: h,
									goal: Le(t)
								}) : e.result.winner.map(d).join(" · ") }),
								t.config.cooperative && /* @__PURE__ */ p("strong", { children: n.label(e.result.winner.length ? "victory" : "defeat") }),
								/* @__PURE__ */ p("button", {
									type: "button",
									onClick: () => u(!1),
									children: n.label("reviewBoard")
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							className: "pw-result-scroll",
							children: [/* @__PURE__ */ m("table", {
								className: "pw-score-table",
								children: [/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { children: n.label("scoreBreakdown") }), e.result.ranking.map((n) => {
									let r = e.members.find((e) => e.rid === n);
									return /* @__PURE__ */ m("th", { children: [/* @__PURE__ */ p("img", {
										src: i(a[(r?.avatar ?? Math.max(0, t.order.indexOf(n))) % a.length]),
										alt: ""
									}), /* @__PURE__ */ p("strong", { children: d(n) })] }, n);
								})] }) }), /* @__PURE__ */ p("tbody", { children: f.map((r) => /* @__PURE__ */ m("tr", {
									className: r === "total" ? "pw-score-total" : "",
									children: [/* @__PURE__ */ p("th", { children: n.label(r) }), e.result.ranking.map((e) => /* @__PURE__ */ p("td", { children: t.score[e]?.[r] ?? 0 }, e))]
								}, r)) })]
							}), t.config.cooperative && /* @__PURE__ */ p("p", {
								className: "pw-score-note",
								children: n.label("honourScoring")
							})]
						}),
						/* @__PURE__ */ m("footer", {
							className: "pw-result-actions",
							children: [
								e.onPlayAgain && /* @__PURE__ */ p(_, {
									label: n.label("playAgain"),
									confirmLabel: n.label("confirm"),
									onConfirm: e.onPlayAgain
								}),
								" ",
								e.onBackToLobby && /* @__PURE__ */ p(_, {
									label: n.label("backToLobby"),
									confirmLabel: n.label("confirm"),
									onConfirm: e.onBackToLobby
								}),
								" ",
								!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ p("p", { children: n.label("waitHost") })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: "pw-result-reopen",
				style: { display: l ? "none" : void 0 },
				onClick: () => u(!0),
				children: n.label("showResult")
			})
		]
	});
}
//#endregion
//#region src/game/options.tsx
function Bt({ value: e, onChange: t }) {
	let n = at.parse(e ?? {}), r = K();
	return /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ p(re, {
				title: r.label("modes"),
				children: ["city", "cooperative"].map((e) => /* @__PURE__ */ p(te, {
					name: e,
					value: e,
					checked: n[e],
					label: r.label(e),
					onChange: () => t({
						...n,
						[e]: !n[e]
					})
				}, e))
			}),
			/* @__PURE__ */ p(re, {
				title: r.label("components"),
				children: [
					"promos",
					"wallPromo",
					"suspicionPromo",
					"personalSuspicion",
					"tavernPromo",
					"vassals",
					"paladinPromo",
					"identicalPaladins"
				].map((e) => /* @__PURE__ */ p(te, {
					name: e,
					value: e,
					checked: n[e],
					label: r.label(e),
					onChange: () => t({
						...n,
						[e]: !n[e]
					})
				}, e))
			}),
			["soloDifficulty", "coopDifficulty"].map((e) => /* @__PURE__ */ p(re, {
				title: r.label(e),
				children: [
					"easy",
					"standard",
					"hard",
					"insane"
				].filter((t) => e === "soloDifficulty" || t !== "easy").map((i) => /* @__PURE__ */ p(ne, {
					name: e,
					value: i,
					checked: n[e] === i,
					label: r.label(i),
					onChange: () => t({
						...n,
						[e]: i
					})
				}, i))
			}, e))
		]
	});
}
//#endregion
//#region src/index.tsx
var Vt = {
	definition: yt,
	View: Ot,
	bot: It,
	fx: Rt,
	OverView: zt,
	Options: Bt,
	locales: {
		zh: xt,
		en: bt
	}
};
//#endregion
export { Vt as default };
