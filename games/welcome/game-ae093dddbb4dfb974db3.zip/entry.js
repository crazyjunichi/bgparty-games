import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { ConfirmButton as a } from "@bgparty/sdk/confirm-button";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useT as s } from "@bgparty/sdk/i18n";
import { PhaseBanner as c } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as l } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { gridCell as d } from "@bgparty/sdk/sheet-geometry";
import { SheetText as f, SheetView as p } from "@bgparty/sdk/sheet-view";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Floater as _, FlySprite as v, PulseBox as y } from "@bgparty/sdk/fx/primitives";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
//#region src/games/welcome/data.ts
var x = [
	10,
	11,
	12
], S = [
	[
		2,
		6,
		7
	],
	[
		0,
		3,
		7
	],
	[
		1,
		5,
		10
	]
], C = [
	[
		0,
		2,
		4,
		10
	],
	[
		0,
		2,
		4,
		6,
		14
	],
	[
		0,
		2,
		4,
		6,
		8,
		18
	]
], w = [
	0,
	3,
	6,
	9,
	13,
	17,
	21,
	26,
	31,
	36
], T = [
	[1, 3],
	[
		2,
		3,
		4
	],
	[
		3,
		4,
		5,
		6
	],
	[
		4,
		5,
		6,
		7,
		8
	],
	[
		5,
		6,
		7,
		8,
		10
	],
	[
		6,
		7,
		8,
		10,
		12
	]
], E = [
	0,
	1,
	3,
	6,
	9,
	12,
	16,
	20,
	24,
	28
], D = [
	0,
	3,
	5
], O = [
	7,
	4,
	1
], k = Object.entries({
	estate: [
		1,
		2,
		4,
		5,
		5,
		6,
		7,
		7,
		8,
		8,
		9,
		9,
		10,
		11,
		11,
		12,
		14,
		15
	],
	landscaper: [
		1,
		2,
		4,
		5,
		5,
		6,
		7,
		7,
		8,
		8,
		9,
		9,
		10,
		11,
		11,
		12,
		14,
		15
	],
	surveyor: [
		1,
		2,
		3,
		5,
		5,
		6,
		6,
		7,
		8,
		8,
		9,
		10,
		10,
		11,
		11,
		13,
		14,
		15
	],
	pool: [
		3,
		4,
		6,
		7,
		8,
		9,
		10,
		12,
		13
	],
	temp: [
		3,
		4,
		6,
		7,
		8,
		9,
		10,
		12,
		13
	],
	bis: [
		3,
		4,
		6,
		7,
		8,
		9,
		10,
		12,
		13
	]
}).flatMap(([e, t]) => t.map((t) => ({
	num: t,
	effect: e
}))), A = [
	{
		id: "p1a",
		tier: 1,
		sizes: [
			1,
			1,
			1,
			1,
			1,
			1
		],
		project: 8,
		approved: 4
	},
	{
		id: "p1b",
		tier: 1,
		sizes: [
			2,
			2,
			2,
			2
		],
		project: 8,
		approved: 4
	},
	{
		id: "p1c",
		tier: 1,
		sizes: [
			3,
			3,
			3
		],
		project: 8,
		approved: 4
	},
	{
		id: "p1d",
		tier: 1,
		sizes: [4, 4],
		project: 6,
		approved: 3
	},
	{
		id: "p1e",
		tier: 1,
		sizes: [5, 5],
		project: 8,
		approved: 4
	},
	{
		id: "p1f",
		tier: 1,
		sizes: [6, 6],
		project: 10,
		approved: 6
	},
	{
		id: "p2a",
		tier: 2,
		sizes: [
			1,
			1,
			1,
			6
		],
		project: 11,
		approved: 6
	},
	{
		id: "p2b",
		tier: 2,
		sizes: [3, 6],
		project: 8,
		approved: 4
	},
	{
		id: "p2c",
		tier: 2,
		sizes: [
			2,
			2,
			5
		],
		project: 10,
		approved: 6
	},
	{
		id: "p2d",
		tier: 2,
		sizes: [
			3,
			3,
			4
		],
		project: 12,
		approved: 7
	},
	{
		id: "p2e",
		tier: 2,
		sizes: [4, 5],
		project: 9,
		approved: 5
	},
	{
		id: "p2f",
		tier: 2,
		sizes: [
			1,
			1,
			1,
			4
		],
		project: 9,
		approved: 5
	},
	{
		id: "p3a",
		tier: 3,
		sizes: [
			1,
			2,
			6
		],
		project: 12,
		approved: 7
	},
	{
		id: "p3b",
		tier: 3,
		sizes: [
			1,
			4,
			5
		],
		project: 13,
		approved: 7
	},
	{
		id: "p3c",
		tier: 3,
		sizes: [3, 4],
		project: 7,
		approved: 3
	},
	{
		id: "p3d",
		tier: 3,
		sizes: [2, 5],
		project: 7,
		approved: 3
	},
	{
		id: "p3e",
		tier: 3,
		sizes: [
			1,
			2,
			2,
			3
		],
		project: 11,
		approved: 6
	},
	{
		id: "p3f",
		tier: 3,
		sizes: [
			2,
			3,
			5
		],
		project: 13,
		approved: 7
	}
], j = {
	id: "welcome",
	tier: "released",
	mechanics: ["roll-and-write"],
	interactionTags: [],
	nameKey: "games.welcome.name",
	descKey: "games.welcome.desc",
	rulesKey: "games.welcome.rules",
	icon: "🏡",
	iconImg: "games/welcome.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/welcome/en.pdf" },
	minPlayers: 2,
	maxPlayers: 10,
	bestPlayers: [3, 4],
	accent: "#0d9488",
	releasedAt: "2026-09-15",
	search: {
		py: "huan ying lai dao",
		init: "hyld"
	},
	hotseat: "cover"
}, M = t.enum([
	"surveyor",
	"estate",
	"landscaper",
	"pool",
	"temp",
	"bis"
]), ee = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("fence"),
		street: t.int().min(0).max(2),
		gap: t.int().min(0).max(10)
	}),
	t.object({
		type: t.literal("promote"),
		col: t.int().min(0).max(5)
	}),
	t.object({ type: t.literal("park") }),
	t.object({ type: t.literal("pool") }),
	t.object({
		type: t.literal("temp"),
		delta: t.int().min(-2).max(2)
	}),
	t.object({ type: t.literal("bis") })
]), te = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		offer: t.int().min(0).max(2),
		street: t.int().min(0).max(2),
		house: t.int().min(0).max(11),
		effect: ee.nullable()
	}),
	t.object({ type: t.literal("refuse") }),
	t.object({
		type: t.literal("claimPlan"),
		plan: t.int().min(0).max(2)
	}),
	t.object({ type: t.literal("reshuffle") })
]), N = t.array(t.int().min(0).max(17).nullable()), P = t.array(t.boolean()), ne = t.object({
	houses: t.tuple([
		N,
		N,
		N
	]),
	bisAt: t.tuple([
		P,
		P,
		P
	]),
	fences: t.tuple([
		P,
		P,
		P
	]),
	used: t.tuple([
		P,
		P,
		P
	]),
	parks: t.tuple([
		t.int(),
		t.int(),
		t.int()
	]),
	pools: t.int(),
	temps: t.int(),
	promo: t.tuple([
		t.int(),
		t.int(),
		t.int(),
		t.int(),
		t.int(),
		t.int()
	]),
	bis: t.int(),
	refusals: t.int(),
	planScores: t.tuple([
		t.int().nullable(),
		t.int().nullable(),
		t.int().nullable()
	])
}), re = t.object({
	plans: t.int(),
	parks: t.int(),
	pools: t.int(),
	temps: t.int(),
	estates: t.int(),
	bis: t.int(),
	refusals: t.int(),
	total: t.int()
}), ie = t.object({
	offers: t.tuple([
		t.object({
			num: t.int(),
			effect: M
		}),
		t.object({
			num: t.int(),
			effect: M
		}),
		t.object({
			num: t.int(),
			effect: M
		})
	]),
	plans: t.tuple([
		t.object({
			id: t.string(),
			approved: t.boolean()
		}),
		t.object({
			id: t.string(),
			approved: t.boolean()
		}),
		t.object({
			id: t.string(),
			approved: t.boolean()
		})
	]),
	round: t.int().min(1),
	phase: t.enum(["play", "done"]),
	pendingReshuffle: t.boolean(),
	players: t.array(t.object({
		rid: t.string(),
		submitted: t.boolean(),
		built: t.int(),
		refusals: t.int(),
		plansDone: t.int()
	})),
	final: t.array(t.object({
		rid: t.string(),
		score: re
	})).nullable()
}), F = t.object({
	sheet: ne,
	claimable: t.tuple([
		t.boolean(),
		t.boolean(),
		t.boolean()
	]),
	canReshuffle: t.boolean()
});
//#endregion
//#region src/games/welcome/rules.ts
function ae() {
	return {
		houses: x.map((e) => Array(e).fill(null)),
		bisAt: x.map((e) => Array(e).fill(!1)),
		fences: x.map((e) => Array(e - 1).fill(!1)),
		used: x.map((e) => Array(e).fill(!1)),
		parks: [
			0,
			0,
			0
		],
		pools: 0,
		temps: 0,
		promo: [
			0,
			0,
			0,
			0,
			0,
			0
		],
		bis: 0,
		refusals: 0,
		planScores: [
			null,
			null,
			null
		]
	};
}
function I(e) {
	let t = [];
	for (let n = 0; n < 3; n++) {
		let r = x[n], i = 0;
		for (let a = 0; a < r; a++) {
			if (a < r - 1 && !e.fences[n][a]) continue;
			let o = !0, s = !1;
			for (let t = i; t <= a; t++) e.houses[n][t] === null && (o = !1), e.used[n][t] && (s = !0);
			t.push({
				street: n,
				start: i,
				size: a + 1 - i,
				complete: o,
				used: s
			}), i = a + 1;
		}
	}
	return t;
}
function L(e, t, n) {
	for (let r of [n - 1, n + 1]) {
		if (r < 0 || r >= x[t] || e.fences[t][Math.min(r, n)]) continue;
		let i = e.houses[t][r];
		if (i !== null) return {
			num: i,
			from: r
		};
	}
	return null;
}
function R(e, t, n, r, i) {
	let a = e.houses[t];
	if (n < 0 || n >= a.length || a[n] !== null) return !1;
	for (let e = 0; e < n; e++) {
		let t = a[e];
		if (t !== null && (t > r || t === r && i !== e)) return !1;
	}
	for (let e = n + 1; e < a.length; e++) {
		let t = a[e];
		if (t !== null && (t < r || t === r && i !== e)) return !1;
	}
	return !0;
}
var oe = {
	surveyor: "fence",
	estate: "promote",
	landscaper: "park",
	pool: "pool",
	temp: "temp",
	bis: "bis"
};
function se(e) {
	return [
		0,
		1,
		2
	].map((t) => ({
		num: k[e.deck[e.pos + t]].num,
		effect: k[e.deck[e.pos - 3 + t]].effect
	}));
}
function ce(t, n) {
	let r = Array.from({ length: k.length }, (e, t) => t);
	for (let i = r.length - 1; i > 0; --i) {
		let a = e(t, n, i + 1);
		n += 1, [r[i], r[a]] = [r[a], r[i]];
	}
	return {
		deck: r,
		cursor: n
	};
}
function le(t, n, r) {
	let i = 0, a = [];
	for (let t of [
		1,
		2,
		3
	]) {
		let n = A.filter((e) => e.tier === t), o = n[e(r, i, n.length)];
		i += 1, a.push({
			id: o.id,
			approved: !1,
			firstRound: null
		});
	}
	let { deck: o, cursor: s } = ce(r, i), c = {};
	for (let e of n) c[e] = ae();
	return {
		state: {
			players: n,
			rngCursor: s,
			deck: o,
			pos: 3,
			plans: a,
			sheets: c,
			submitted: [],
			reshuffleOk: [],
			pendingReshuffle: !1,
			phase: "play",
			round: 1,
			tempsAward: null
		},
		fx: [{ kind: "flip" }]
	};
}
function z(e) {
	e.phase === "play" && e.players.some((t) => {
		let n = e.sheets[t];
		return n.refusals >= 3 || n.planScores.every((e) => e !== null) || n.houses.every((e) => e.every((e) => e !== null));
	}) && (e.phase = "done", e.tempsAward = ue(e));
}
function ue(e) {
	let t = [...new Set(e.players.map((t) => e.sheets[t].temps))].filter((e) => e > 0).sort((e, t) => t - e), n = {};
	for (let r of e.players) {
		let i = t.indexOf(e.sheets[r].temps);
		n[r] = i >= 0 && i < O.length ? O[i] : 0;
	}
	return n;
}
function B(e) {
	if (e.phase !== "play" || e.submitted.length < e.players.length) return [];
	if (e.submitted = [], e.reshuffleOk = [], e.round += 1, e.pendingReshuffle || e.pos + 3 + 2 >= k.length) {
		let { deck: t, cursor: n } = ce(de(e), e.rngCursor);
		return e.deck = t, e.rngCursor = n, e.pos = 3, e.pendingReshuffle = !1, [{
			kind: "flip",
			data: { reshuffled: !0 }
		}];
	}
	return e.pos += 3, [{ kind: "flip" }];
}
function de(t) {
	return e(t.rngCursor, t.rngCursor, 2147483647) ^ t.round * 2654435761 | 0;
}
function V(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of I(e)) t.complete && !t.used && t.size <= 6 && n.set(t.size, (n.get(t.size) ?? 0) + 1);
	for (let e of t) {
		let t = n.get(e) ?? 0;
		if (t === 0) return !1;
		n.set(e, t - 1);
	}
	return !0;
}
function fe(e, t) {
	for (let n of t) {
		let t = I(e).find((e) => e.complete && !e.used && e.size === n);
		if (!t) return;
		for (let n = t.start; n < t.start + t.size; n++) e.used[t.street][n] = !0;
	}
}
function H(e) {
	return { code: e };
}
function pe(e, t, n) {
	if (e.phase !== "play") return H("games.welcome.errGameOver");
	let r = e.sheets[n.by];
	if (!r) return H("games.welcome.errNotYourTurn");
	if (t.type === "reshuffle") {
		if (!e.reshuffleOk.includes(n.by) || e.pendingReshuffle) return H("games.welcome.errNoReshuffle");
		let t = structuredClone(e);
		return t.pendingReshuffle = !0, {
			state: t,
			fx: [{
				kind: "reshuffle",
				rid: n.by
			}]
		};
	}
	if (t.type === "claimPlan") {
		let i = e.plans[t.plan], a = A.find((e) => e.id === i.id);
		if (!a) return H("games.welcome.errPlanNotMet");
		if (r.planScores[t.plan] !== null) return H("games.welcome.errPlanClaimed");
		if (!V(r, a.sizes)) return H("games.welcome.errPlanNotMet");
		let o = structuredClone(e), s = o.sheets[n.by], c = o.plans[t.plan].firstRound === null, l = c || o.plans[t.plan].firstRound === o.round ? a.project : a.approved;
		return fe(s, a.sizes), s.planScores[t.plan] = l, c && (o.plans[t.plan].firstRound = o.round, o.plans[t.plan].approved = !0, o.reshuffleOk.includes(n.by) || o.reshuffleOk.push(n.by)), z(o), {
			state: o,
			fx: [{
				kind: "plan",
				rid: n.by,
				data: {
					plan: t.plan,
					points: l,
					first: c
				}
			}]
		};
	}
	if (e.submitted.includes(n.by)) return H("games.welcome.errAlreadySubmitted");
	if (t.type === "refuse") {
		let t = structuredClone(e);
		t.sheets[n.by].refusals += 1, t.submitted.push(n.by);
		let r = [{
			kind: "refuse",
			rid: n.by
		}];
		return z(t), r.push(...B(t)), {
			state: t,
			fx: r
		};
	}
	let i = se(e)[t.offer];
	if (t.effect !== null && t.effect.type !== oe[i.effect]) return H("games.welcome.errBadEffect");
	let a = i.num, o = null;
	if (t.effect?.type === "bis") {
		if (r.bis >= E.length) return H("games.welcome.errTrackFull");
		let e = L(r, t.street, t.house);
		if (!e) return H("games.welcome.errNoBisNeighbor");
		a = e.num, o = e.from;
	} else if (t.effect?.type === "temp") {
		if (r.temps >= 11) return H("games.welcome.errTrackFull");
		if (a = i.num + t.effect.delta, a < 0 || a > 17) return H("games.welcome.errBadDelta");
	}
	if (!R(r, t.street, t.house, a, o)) return H("games.welcome.errBadHouse");
	if (t.effect?.type === "fence") {
		let e = x[t.effect.street], { gap: n, street: i } = t.effect;
		if (n < 0 || n >= e - 1 || r.fences[i][n]) return H("games.welcome.errBadFence");
		let a = r.houses[i][n];
		if (a !== null && a === r.houses[i][n + 1]) return H("games.welcome.errBadFence");
		if (r.used[i][n] && r.used[i][n + 1]) return H("games.welcome.errFenceBlocked");
	} else if (t.effect?.type === "promote") {
		if (r.promo[t.effect.col] >= T[t.effect.col].length) return H("games.welcome.errColFull");
	} else if (t.effect?.type === "park" && r.parks[t.street] >= C[t.street].length) return H("games.welcome.errParkFull");
	let s = structuredClone(e), c = s.sheets[n.by];
	c.houses[t.street][t.house] = a, o !== null && (c.bisAt[t.street][t.house] = !0);
	let l = t.effect;
	l?.type === "fence" ? c.fences[l.street][l.gap] = !0 : l?.type === "promote" ? c.promo[l.col] += 1 : l?.type === "park" ? c.parks[t.street] += 1 : l?.type === "temp" ? c.temps += 1 : l?.type === "bis" ? c.bis += 1 : l?.type === "pool" && S[t.street].includes(t.house) && (c.pools += 1), s.submitted.push(n.by);
	let u = [{
		kind: "write",
		rid: n.by,
		data: {
			street: t.street,
			house: t.house,
			num: a,
			bis: o !== null,
			effect: l?.type ?? null
		}
	}];
	return z(s), u.push(...B(s)), {
		state: s,
		fx: u
	};
}
function U(e, t) {
	let n = e.planScores.reduce((e, t) => e + (t ?? 0), 0), r = e.parks.reduce((e, t, n) => e + C[n][Math.min(t, C[n].length - 1)], 0), i = w[Math.min(e.pools, w.length - 1)], a = 0;
	for (let t of I(e)) {
		if (!t.complete || t.size > 6) continue;
		let n = T[t.size - 1];
		a += n[Math.min(e.promo[t.size - 1], n.length - 1)];
	}
	let o = E[Math.min(e.bis, E.length - 1)], s = e.refusals === 0 ? 0 : D[e.refusals - 1], c = n + r + i + t + a - o - s;
	return {
		plans: n,
		parks: r,
		pools: i,
		temps: t,
		estates: a,
		bis: o,
		refusals: s,
		total: c
	};
}
function me(e, t) {
	let n = e.sheets[t];
	return {
		public: {
			offers: se(e),
			plans: e.plans.map((e) => ({
				id: e.id,
				approved: e.approved
			})),
			round: e.round,
			phase: e.phase,
			pendingReshuffle: e.pendingReshuffle,
			players: e.players.map((t) => {
				let n = e.sheets[t];
				return {
					rid: t,
					submitted: e.submitted.includes(t),
					built: n.houses.reduce((e, t) => e + t.filter((e) => e !== null).length, 0),
					refusals: n.refusals,
					plansDone: n.planScores.filter((e) => e !== null).length
				};
			}),
			final: e.phase === "done" ? e.players.map((t) => ({
				rid: t,
				score: U(e.sheets[t], e.tempsAward?.[t] ?? 0)
			})) : null
		},
		private: n ? {
			sheet: n,
			claimable: e.plans.map((e, t) => {
				if (n.planScores[t] !== null) return !1;
				let r = A.find((t) => t.id === e.id);
				return r ? V(n, r.sizes) : !1;
			}),
			canReshuffle: e.reshuffleOk.includes(t) && !e.pendingReshuffle
		} : void 0
	};
}
function he(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.players.map((t) => {
		let n = U(e.sheets[t], e.tempsAward?.[t] ?? 0).total, r = [
			0,
			0,
			0,
			0,
			0,
			0
		], i = 0;
		for (let n of I(e.sheets[t])) !n.complete || n.size > 6 || (i += 1, r[n.size - 1] += 1);
		return {
			rid: t,
			total: n,
			estateCount: i,
			sizeCounts: r
		};
	});
	t.sort((e, t) => {
		if (e.total !== t.total) return t.total - e.total;
		if (e.estateCount !== t.estateCount) return t.estateCount - e.estateCount;
		for (let n = 0; n < 6; n++) if (e.sizeCounts[n] !== t.sizeCounts[n]) return t.sizeCounts[n] - e.sizeCounts[n];
		return 0;
	});
	let n = t[0];
	return {
		phase: "done",
		winner: t.filter((e) => e.total === n.total && e.estateCount === n.estateCount && e.sizeCounts.every((e, t) => e === n.sizeCounts[t])).map((e) => e.rid),
		ranking: t.map((e) => e.rid),
		scores: Object.fromEntries(t.map((e) => [e.rid, e.total]))
	};
}
var ge = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: j,
	schemas: {
		action: te,
		publicView: ie,
		privateView: F
	},
	setup: le,
	reduce: pe,
	viewFor: me,
	status: he
}, _e = 1254, ve = 1254, W = [
	{
		x: 307,
		y: 136,
		w: 56,
		h: 88,
		pitch: 84.4,
		count: 10
	},
	{
		x: 223,
		y: 377,
		w: 56,
		h: 90,
		pitch: 84.5,
		count: 11
	},
	{
		x: 137,
		y: 625,
		w: 57,
		h: 88,
		pitch: 84.9,
		count: 12
	}
], ye = [
	13,
	14,
	12
];
function G(e, t) {
	let n = d(W[e], t);
	return S[e].includes(t) ? {
		...n,
		y: n.y + ye[e]
	} : n;
}
function K(e, t) {
	let n = W[e], r = d(n, t);
	return {
		x: r.x + r.w,
		y: r.y + 6,
		w: n.pitch - r.w,
		h: r.h - 12
	};
}
var be = [
	[
		{
			cx: 1015.5,
			cy: 59,
			r: 19
		},
		{
			cx: 1060,
			cy: 59,
			r: 19
		},
		{
			cx: 1103,
			cy: 59,
			r: 19
		},
		{
			cx: 1147,
			cy: 59,
			r: 19
		}
	],
	[
		{
			cx: 978,
			cy: 301,
			r: 18.5
		},
		{
			cx: 1021.5,
			cy: 301,
			r: 18.5
		},
		{
			cx: 1063.5,
			cy: 301,
			r: 18.5
		},
		{
			cx: 1106.5,
			cy: 301,
			r: 18.5
		},
		{
			cx: 1150,
			cy: 301,
			r: 18.5
		}
	],
	[
		{
			cx: 934,
			cy: 544,
			r: 19
		},
		{
			cx: 978.5,
			cy: 544,
			r: 19
		},
		{
			cx: 1022,
			cy: 544,
			r: 19
		},
		{
			cx: 1063.5,
			cy: 544,
			r: 19
		},
		{
			cx: 1106.5,
			cy: 544,
			r: 19
		},
		{
			cx: 1150,
			cy: 544,
			r: 19
		}
	]
], xe = [
	[{
		x: 565,
		y: 988,
		w: 30,
		h: 30
	}, {
		x: 565,
		y: 1024,
		w: 30,
		h: 29
	}],
	[
		{
			x: 623,
			y: 970,
			w: 29,
			h: 29
		},
		{
			x: 623,
			y: 1005,
			w: 29,
			h: 30
		},
		{
			x: 623,
			y: 1042,
			w: 29,
			h: 29
		}
	],
	[
		{
			x: 677,
			y: 948,
			w: 30,
			h: 31
		},
		{
			x: 677,
			y: 984,
			w: 30,
			h: 30
		},
		{
			x: 677,
			y: 1021,
			w: 30,
			h: 30
		},
		{
			x: 677,
			y: 1057,
			w: 30,
			h: 30
		}
	],
	[
		{
			x: 735,
			y: 930,
			w: 30,
			h: 29
		},
		{
			x: 735,
			y: 966,
			w: 30,
			h: 29
		},
		{
			x: 735,
			y: 1001,
			w: 30,
			h: 30
		},
		{
			x: 735,
			y: 1036,
			w: 30,
			h: 30
		},
		{
			x: 735,
			y: 1070,
			w: 30,
			h: 30
		}
	],
	[
		{
			x: 794,
			y: 909,
			w: 29,
			h: 30
		},
		{
			x: 794,
			y: 946,
			w: 29,
			h: 30
		},
		{
			x: 794,
			y: 982,
			w: 29,
			h: 28
		},
		{
			x: 805,
			y: 1017,
			w: 30,
			h: 30
		},
		{
			x: 794,
			y: 1053,
			w: 36,
			h: 31
		}
	],
	[
		{
			x: 850,
			y: 890,
			w: 30,
			h: 30
		},
		{
			x: 850,
			y: 926,
			w: 30,
			h: 29
		},
		{
			x: 850,
			y: 962,
			w: 30,
			h: 30
		},
		{
			x: 850,
			y: 998,
			w: 30,
			h: 30
		},
		{
			x: 850,
			y: 1034,
			w: 30,
			h: 30
		}
	]
], Se = [
	{
		x: 279,
		y: 935,
		w: 30,
		h: 32
	},
	{
		x: 319,
		y: 935,
		w: 30,
		h: 32
	},
	{
		x: 279,
		y: 974,
		w: 30,
		h: 31
	},
	{
		x: 319,
		y: 974,
		w: 30,
		h: 31
	},
	{
		x: 279,
		y: 1016,
		w: 30,
		h: 31
	},
	{
		x: 319,
		y: 1016,
		w: 30,
		h: 31
	},
	{
		x: 279,
		y: 1058,
		w: 30,
		h: 31
	},
	{
		x: 319,
		y: 1058,
		w: 30,
		h: 31
	},
	{
		x: 279,
		y: 1099,
		w: 30,
		h: 31
	},
	{
		x: 319,
		y: 1099,
		w: 30,
		h: 31
	}
], Ce = [
	{
		x: 952,
		y: 894,
		w: 31,
		h: 31
	},
	{
		x: 999,
		y: 894,
		w: 30,
		h: 31
	},
	{
		x: 952,
		y: 945,
		w: 31,
		h: 31
	},
	{
		x: 999,
		y: 945,
		w: 30,
		h: 31
	},
	{
		x: 952,
		y: 997,
		w: 31,
		h: 31
	},
	{
		x: 999,
		y: 997,
		w: 30,
		h: 31
	},
	{
		x: 952,
		y: 1048,
		w: 31,
		h: 31
	},
	{
		x: 999,
		y: 1048,
		w: 30,
		h: 31
	},
	{
		x: 952,
		y: 1098,
		w: 31,
		h: 31
	},
	{
		x: 999,
		y: 1098,
		w: 30,
		h: 31
	}
], we = [
	{
		x: 400,
		y: 848,
		w: 35,
		h: 37
	},
	{
		x: 456,
		y: 848,
		w: 33,
		h: 36
	},
	{
		x: 426,
		y: 874,
		w: 38,
		h: 40
	},
	{
		x: 404,
		y: 912,
		w: 33,
		h: 33
	},
	{
		x: 454,
		y: 912,
		w: 31,
		h: 33
	},
	{
		x: 430,
		y: 937,
		w: 31,
		h: 33
	},
	{
		x: 405,
		y: 962,
		w: 32,
		h: 33
	},
	{
		x: 454,
		y: 962,
		w: 31,
		h: 33
	},
	{
		x: 429,
		y: 987,
		w: 32,
		h: 33
	},
	{
		x: 405,
		y: 1012,
		w: 32,
		h: 33
	},
	{
		x: 454,
		y: 1012,
		w: 32,
		h: 33
	}
], Te = [
	{
		x: 1086,
		y: 908,
		w: 36,
		h: 41
	},
	{
		x: 1086,
		y: 958,
		w: 36,
		h: 41
	},
	{
		x: 1086,
		y: 1009,
		w: 36,
		h: 41
	}
], q = {
	plans: {
		x: 71,
		y: 1176,
		w: 44,
		h: 46
	},
	parks: {
		x: 175,
		y: 1176,
		w: 44,
		h: 46
	},
	pools: {
		x: 287,
		y: 1176,
		w: 44,
		h: 46
	},
	temps: {
		x: 422,
		y: 1176,
		w: 45,
		h: 46
	},
	estates: {
		x: 551,
		y: 1176,
		w: 44,
		h: 46
	},
	bis: {
		x: 970,
		y: 1176,
		w: 44,
		h: 46
	},
	refusals: {
		x: 1081,
		y: 1176,
		w: 44,
		h: 46
	},
	total: {
		x: 1165,
		y: 1169,
		w: 52,
		h: 57
	}
}, Ee = {
	x: 55,
	y: 180,
	w: 210,
	h: 50
};
//#endregion
//#region src/games/welcome/sheet-view.tsx
function J({ r: e, danger: t }) {
	let n = e.w * .18, r = e.h * .18;
	return /* @__PURE__ */ g("g", {
		stroke: t ? "var(--color-danger-ink)" : "var(--color-ink)",
		strokeWidth: 8,
		strokeLinecap: "round",
		pointerEvents: "none",
		children: [/* @__PURE__ */ h("line", {
			x1: e.x + n,
			y1: e.y + r,
			x2: e.x + e.w - n,
			y2: e.y + e.h - r
		}), /* @__PURE__ */ h("line", {
			x1: e.x + e.w - n,
			y1: e.y + r,
			x2: e.x + n,
			y2: e.y + e.h - r
		})]
	});
}
function Y({ r: e, text: t, danger: n }) {
	return /* @__PURE__ */ h("text", {
		x: e.x + e.w / 2,
		y: e.y + e.h / 2,
		textAnchor: "middle",
		dominantBaseline: "central",
		fontSize: e.h * .55,
		fontWeight: 800,
		fill: n ? "var(--color-danger-ink)" : "var(--color-ink)",
		stroke: "#ffffff",
		strokeWidth: e.h * .09,
		paintOrder: "stroke",
		pointerEvents: "none",
		children: t
	});
}
function De({ r: e, preview: t }) {
	return /* @__PURE__ */ h("rect", {
		x: e.x + e.w / 2 - 7,
		y: e.y,
		width: 14,
		height: e.h,
		rx: 6,
		fill: "#ffffff",
		fillOpacity: t ? .55 : .95,
		stroke: "var(--color-ink)",
		strokeWidth: t ? 4 : 3,
		strokeDasharray: t ? "10 8" : void 0,
		pointerEvents: "none"
	});
}
function Oe(e) {
	let t = xe[e], n = Math.min(...t.map((e) => e.x)) - 10, r = Math.min(...t.map((e) => e.y)) - 58;
	return {
		x: n,
		y: r,
		w: Math.max(...t.map((e) => e.x + e.w)) + 10 - n,
		h: Math.max(...t.map((e) => e.y + e.h)) + 10 - r
	};
}
function ke({ c: e }) {
	let t = Oe(e);
	return /* @__PURE__ */ h("rect", {
		x: t.x,
		y: t.y,
		width: t.w,
		height: t.h,
		rx: 16,
		fill: "#7dd3fc",
		fillOpacity: .4,
		stroke: "#0284c7",
		strokeWidth: 5,
		strokeDasharray: "12 8",
		pointerEvents: "none"
	});
}
function Ae({ sheet: e, eligible: t, onTapEligible: a, readOnly: o, fitKey: s, staged: c, stagedNum: l, stagedFence: u, stagedCol: d, name: m, final: _ }) {
	let v = r(null), [y, b] = i("");
	return n(() => {
		let e = v.current;
		if (!e) return;
		let t = !0, n = new ResizeObserver(([e]) => {
			let n = Math.round(e.contentRect.width), r = Math.round(e.contentRect.height);
			if (!n || !r) return;
			let i = `${n}x${r}`;
			queueMicrotask(() => {
				t && b((e) => e === i ? e : i);
			});
		});
		return n.observe(e), () => {
			t = !1, n.disconnect();
		};
	}, []), /* @__PURE__ */ h("div", {
		ref: v,
		className: "welcome-sheet",
		children: /* @__PURE__ */ g(p, {
			image: "games/welcome/sheet.webp",
			sheetW: _e,
			sheetH: ve,
			eligible: t,
			onTapEligible: a,
			readOnly: o,
			fitKey: `${s}:${y}`,
			children: [
				m ? /* @__PURE__ */ h(f, {
					r: Ee,
					text: m
				}) : null,
				e.houses.map((t, n) => t.map((t, r) => {
					if (t === null) return null;
					let i = G(n, r);
					return /* @__PURE__ */ g("g", { children: [
						e.used[n][r] && /* @__PURE__ */ h("rect", {
							x: i.x - 4,
							y: i.y - 4,
							width: i.w + 8,
							height: i.h + 8,
							rx: 10,
							fill: "var(--color-surface)",
							fillOpacity: .55,
							pointerEvents: "none"
						}),
						/* @__PURE__ */ h(f, {
							r: i,
							text: String(t)
						}),
						e.bisAt[n][r] && /* @__PURE__ */ h("text", {
							x: i.x + i.w + 2,
							y: i.y + 12,
							textAnchor: "start",
							fontSize: 17,
							fontWeight: 800,
							fill: "var(--color-ink)",
							stroke: "#ffffff",
							strokeWidth: 4,
							paintOrder: "stroke",
							pointerEvents: "none",
							children: "bis"
						})
					] }, `h${n}:${r}`);
				})),
				e.fences.map((e, t) => e.map((e, n) => e ? /* @__PURE__ */ h(De, { r: K(t, n) }, `f${t}:${n}`) : null)),
				u && !e.fences[u.s][u.g] && /* @__PURE__ */ h(De, {
					r: K(u.s, u.g),
					preview: !0
				}),
				e.parks.map((e, t) => Array.from({ length: e }, (e, n) => {
					let r = be[t][n];
					return r ? /* @__PURE__ */ h(J, { r: {
						x: r.cx - r.r,
						y: r.cy - r.r,
						w: r.r * 2,
						h: r.r * 2
					} }, `p${t}:${n}`) : null;
				})),
				Array.from({ length: e.pools }, (e, t) => /* @__PURE__ */ h(J, { r: Se[t] }, `pool${t}`)),
				Array.from({ length: e.temps }, (e, t) => /* @__PURE__ */ h(J, { r: we[t] }, `temp${t}`)),
				e.promo.map((e, t) => Array.from({ length: e }, (e, n) => /* @__PURE__ */ h(J, { r: xe[t][n] }, `e${t}:${n}`))),
				Array.from({ length: e.bis }, (e, t) => /* @__PURE__ */ h(J, { r: Ce[t] }, `bis${t}`)),
				Array.from({ length: e.refusals }, (e, t) => /* @__PURE__ */ h(J, {
					r: Te[t],
					danger: !0
				}, `ref${t}`)),
				c && e.houses[c.s][c.i] === null && /* @__PURE__ */ g("g", {
					pointerEvents: "none",
					children: [/* @__PURE__ */ h("rect", {
						x: G(c.s, c.i).x - 5,
						y: G(c.s, c.i).y - 5,
						width: G(c.s, c.i).w + 10,
						height: G(c.s, c.i).h + 10,
						rx: 12,
						fill: j.accent,
						fillOpacity: .45,
						stroke: j.accent,
						strokeWidth: 5
					}), l != null && /* @__PURE__ */ h(f, {
						r: G(c.s, c.i),
						text: String(l)
					})]
				}),
				d != null && /* @__PURE__ */ h(ke, { c: d }),
				_ && /* @__PURE__ */ g("g", {
					pointerEvents: "none",
					children: [
						/* @__PURE__ */ h(Y, {
							r: q.plans,
							text: String(_.plans)
						}),
						/* @__PURE__ */ h(Y, {
							r: q.parks,
							text: String(_.parks)
						}),
						/* @__PURE__ */ h(Y, {
							r: q.pools,
							text: String(_.pools)
						}),
						/* @__PURE__ */ h(Y, {
							r: q.temps,
							text: String(_.temps)
						}),
						/* @__PURE__ */ h(Y, {
							r: q.estates,
							text: String(_.estates)
						}),
						/* @__PURE__ */ h(Y, {
							r: q.bis,
							text: String(_.bis),
							danger: !0
						}),
						/* @__PURE__ */ h(Y, {
							r: q.refusals,
							text: String(_.refusals),
							danger: !0
						}),
						/* @__PURE__ */ h(Y, {
							r: q.total,
							text: String(_.total)
						})
					]
				})
			]
		})
	});
}
function je(e, t) {
	return {
		key: `h:${e}:${t}`,
		rect: G(e, t)
	};
}
function Me(e, t) {
	return {
		key: `f:${e}:${t}`,
		rect: K(e, t)
	};
}
function Ne(e) {
	return {
		key: `e:${e}`,
		rect: Oe(e)
	};
}
//#endregion
//#region src/games/welcome/view-player.tsx
var Pe = {
	surveyor: "📐",
	estate: "📈",
	landscaper: "🌳",
	pool: "🏊",
	temp: "👷",
	bis: "👯"
}, Fe = {
	surveyor: "games.welcome.effSurveyor",
	estate: "games.welcome.effEstate",
	landscaper: "games.welcome.effLandscaper",
	pool: "games.welcome.effPool",
	temp: "games.welcome.effTemp",
	bis: "games.welcome.effBis"
}, Ie = {
	surveyor: "bg-amber-500",
	estate: "bg-violet-500",
	landscaper: "bg-green-600",
	pool: "bg-cyan-500",
	temp: "bg-orange-500",
	bis: "bg-pink-500"
}, Le = {
	surveyor: "games.welcome.hintFence",
	estate: "games.welcome.hintPromote",
	landscaper: "games.welcome.hintPark",
	pool: "games.welcome.hintPool",
	temp: "games.welcome.hintTemp",
	bis: "games.welcome.hintBis"
}, X = {
	offer: null,
	house: null,
	delta: 0,
	fence: null,
	col: null,
	bisOn: !1
};
function Re(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ h(ze, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ze({ pub: e, priv: t, members: n, myRid: r, send: o }) {
	let d = s(), f = t?.sheet, p = e.players.find((e) => e.rid === r)?.submitted ?? !0, _ = e.phase === "play" && !p && !!f, [v, y] = i({
		...X,
		round: 0
	}), b = v.round === e.round ? v : {
		...X,
		round: e.round
	}, S = (t) => y({
		...t,
		round: e.round
	}), w = b.offer === null ? null : e.offers[b.offer], D = (e, t) => {
		if (!w || !f) return null;
		if (w.effect === "bis" && b.bisOn) {
			if (f.bis >= E.length) return null;
			let n = L(f, e, t);
			return n && R(f, e, t, n.num, n.from) ? { num: n.num } : null;
		}
		let n = w.effect === "temp" ? w.num + b.delta : w.num;
		return n < 0 || n > 17 ? null : R(f, e, t, n, null) ? { num: n } : null;
	}, O = b.house ? D(b.house.s, b.house.i)?.num ?? null : null, k = () => {
		if (!w || !f || !b.house) return null;
		switch (w.effect) {
			case "surveyor": return b.fence ? {
				type: "fence",
				street: b.fence.s,
				gap: b.fence.g
			} : null;
			case "estate": return b.col === null ? null : {
				type: "promote",
				col: b.col
			};
			case "landscaper": return f.parks[b.house.s] < C[b.house.s].length ? { type: "park" } : null;
			case "pool": return { type: "pool" };
			case "temp": return f.temps < 11 ? {
				type: "temp",
				delta: b.delta
			} : null;
			case "bis": return b.bisOn ? { type: "bis" } : null;
		}
	}, A = () => {
		b.offer !== null && b.house && O !== null && o({
			type: "play",
			offer: b.offer,
			street: b.house.s,
			house: b.house.i,
			effect: k()
		});
	}, M;
	_ && w && f && (M = [], x.forEach((e, t) => {
		let n = f.houses[t];
		for (let r = 0; r < e; r++) n[r] === null && D(t, r) && M.push(je(t, r));
		if (w.effect === "surveyor") for (let r = 0; r < e - 1; r++) !f.fences[t][r] && !(f.used[t][r] && f.used[t][r + 1]) && (n[r] === null || n[r] !== n[r + 1]) && M.push(Me(t, r));
	}), w.effect === "estate" && T.forEach((e, t) => {
		f.promo[t] < e.length && M.push(Ne(t));
	}));
	let ee = (e) => {
		let [t, n, r] = e.split(":");
		if (t === "h") S({
			...b,
			house: {
				s: Number(n),
				i: Number(r)
			}
		});
		else if (t === "f") {
			let e = {
				s: Number(n),
				g: Number(r)
			};
			S({
				...b,
				fence: b.fence?.s === e.s && b.fence.g === e.g ? null : e
			});
		} else if (t === "e") {
			let e = Number(n);
			S({
				...b,
				col: b.col === e ? null : e
			});
		}
	}, te = e.phase === "done" ? e.final?.find((e) => e.rid === r)?.score ?? null : null, N = "info", P = d("games.welcome.waitingOthers");
	return _ && (N = "accent", P = d("games.welcome.chooseOffer")), /* @__PURE__ */ h(u, {
		adaptive: !0,
		scroll: !1,
		className: "welcome-screen",
		banner: /* @__PURE__ */ g("div", {
			className: "welcome-heading",
			children: [/* @__PURE__ */ h(c, {
				tone: N,
				text: P,
				chip: d("games.welcome.round", { n: e.round }),
				accent: j.accent
			}), /* @__PURE__ */ h("div", {
				className: "welcome-players",
				children: /* @__PURE__ */ h(l, {
					variant: "plate",
					scroll: !0,
					members: n,
					myRid: r,
					anchorOf: (e) => `seat:${e}`,
					action: (t) => {
						if (e.phase !== "play") return null;
						let n = e.players.find((e) => e.rid === t);
						return n ? n.submitted ? "done" : "pending" : null;
					},
					status: (t) => {
						let n = e.players.find((e) => e.rid === t);
						return n ? /* @__PURE__ */ g("span", {
							className: "flex items-center gap-1.5 text-xs leading-4.5 font-bold",
							children: [/* @__PURE__ */ g("span", {
								className: "flex items-center gap-0.5",
								children: [/* @__PURE__ */ h("span", {
									"aria-hidden": !0,
									children: "🏠"
								}), /* @__PURE__ */ h("span", {
									className: "font-mono tabular-nums",
									children: n.built
								})]
							}), n.refusals > 0 && /* @__PURE__ */ g("span", {
								className: "flex items-center gap-0.5 text-danger-ink",
								children: [/* @__PURE__ */ h("span", {
									"aria-hidden": !0,
									children: "🚫"
								}), /* @__PURE__ */ h("span", {
									className: "font-mono tabular-nums",
									children: n.refusals
								})]
							})]
						}) : null;
					}
				})
			})]
		}),
		children: /* @__PURE__ */ g("div", {
			className: "welcome-table",
			children: [/* @__PURE__ */ g("aside", {
				className: "welcome-side",
				children: [/* @__PURE__ */ g("div", {
					className: "welcome-market",
					children: [/* @__PURE__ */ h("div", {
						className: "welcome-plans",
						children: e.plans.map((n, r) => /* @__PURE__ */ h(Be, {
							plan: n,
							index: r,
							myScore: f?.planScores[r] ?? null,
							claimable: t?.claimable[r] ?? !1,
							round: e.round,
							onClaim: () => o({
								type: "claimPlan",
								plan: r
							})
						}, n.id))
					}), /* @__PURE__ */ h(Ve, {
						pub: e,
						selected: b.offer,
						disabled: !_,
						onPick: (e) => S({
							...X,
							offer: e
						})
					})]
				}), /* @__PURE__ */ g("div", {
					className: "welcome-actions",
					children: [/* @__PURE__ */ h("div", {
						className: "welcome-effect-slot",
						children: _ && w && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("div", {
							className: "welcome-effect-hint",
							children: [/* @__PURE__ */ h("span", {
								"aria-hidden": !0,
								className: `welcome-effect-icon text-white ${Ie[w.effect]}`,
								children: Pe[w.effect]
							}), /* @__PURE__ */ h("span", { children: d(Le[w.effect]) })]
						}), /* @__PURE__ */ g("div", {
							className: "welcome-effect-options",
							children: [w.effect === "temp" && [
								-2,
								-1,
								0,
								1,
								2
							].map((e) => /* @__PURE__ */ h("button", {
								type: "button",
								"aria-pressed": b.delta === e,
								onClick: () => S({
									...b,
									delta: e
								}),
								className: `min-h-11 min-w-11 rounded-lg border-2 font-mono tabular-nums ${b.delta === e ? "border-ink bg-orange-500 text-white" : "border-ink/30 bg-surface"}`,
								children: e > 0 ? `+${e}` : e
							}, e)), w.effect === "bis" && /* @__PURE__ */ h("button", {
								type: "button",
								"aria-pressed": b.bisOn,
								onClick: () => S({
									...b,
									bisOn: !b.bisOn,
									house: null
								}),
								className: `min-h-11 rounded-lg border-2 px-2 ${b.bisOn ? "border-ink bg-pink-500 text-white" : "border-ink/30 bg-surface"}`,
								children: d("games.welcome.effBis")
							})]
						})] })
					}), /* @__PURE__ */ g("div", {
						className: "welcome-primary-actions",
						children: [/* @__PURE__ */ h("button", {
							type: "button",
							disabled: !_ || O === null,
							onClick: A,
							className: "welcome-confirm btn-base min-h-12 min-w-0 flex-1 text-white disabled:opacity-40",
							style: { background: j.accent },
							children: O === null ? d("games.welcome.chooseOffer") : d("games.welcome.confirmPlay", { num: O })
						}), _ && /* @__PURE__ */ h(a, {
							label: d("games.welcome.refuse"),
							confirmLabel: d("games.welcome.refuseConfirm"),
							onConfirm: () => o({ type: "refuse" }),
							className: "welcome-refuse min-h-12 flex-none text-danger-ink"
						})]
					})]
				})]
			}), /* @__PURE__ */ g("div", {
				className: "welcome-paper frame",
				role: "img",
				"aria-label": d("games.welcome.mySheet"),
				children: [f && /* @__PURE__ */ h(Ae, {
					sheet: f,
					eligible: M,
					onTapEligible: M ? ee : void 0,
					fitKey: "sheet",
					staged: b.house,
					stagedNum: O,
					stagedFence: w?.effect === "surveyor" ? b.fence : null,
					stagedCol: w?.effect === "estate" ? b.col : null,
					name: n.find((e) => e.rid === r)?.name,
					final: te
				}), (t?.canReshuffle || e.pendingReshuffle) && e.phase === "play" && /* @__PURE__ */ h("button", {
					type: "button",
					disabled: !t?.canReshuffle || e.pendingReshuffle,
					onClick: () => o({ type: "reshuffle" }),
					className: "welcome-reshuffle btn-quiet",
					children: e.pendingReshuffle ? d("games.welcome.reshufflePending") : `🔄 ${d("games.welcome.reshuffle")}`
				})]
			})]
		})
	});
}
function Be({ plan: e, index: t, myScore: n, claimable: r, round: i, onClaim: a }) {
	let c = s(), { ref: l } = o(`plan:${t}`), u = A.find((t) => t.id === e.id);
	if (!u) return null;
	let d = e.approved ? u.approved : u.project;
	return /* @__PURE__ */ g("div", {
		ref: l,
		className: `welcome-plan flex min-w-0 flex-1 flex-col items-center gap-1 rounded-xl border-2 px-1 py-1.5 ${n === null ? r ? "border-ink bg-teal-50" : "border-ink/40 bg-teal-50" : "border-ink/20 bg-teal-50/60"}`,
		style: r ? { boxShadow: `0 0 0 2px ${j.accent}` } : void 0,
		children: [
			/* @__PURE__ */ g("span", {
				className: "welcome-plan-tier rounded-full bg-teal-700 px-1.5 text-[11px] leading-4 font-extrabold text-white",
				children: ["n°", u.tier]
			}),
			/* @__PURE__ */ h("span", {
				className: "welcome-plan-estates flex flex-wrap items-end justify-center gap-x-1.5 gap-y-0.5",
				"aria-hidden": !0,
				children: u.sizes.map((e, t) => /* @__PURE__ */ h("span", {
					className: "flex gap-px",
					children: Array.from({ length: e }, (e, t) => /* @__PURE__ */ h("span", { className: "welcome-plan-house size-2 rounded-[3px] bg-teal-600" }, t))
				}, t))
			}),
			/* @__PURE__ */ g("span", {
				className: "welcome-plan-points flex items-baseline gap-1 font-mono text-xs leading-4 font-extrabold tabular-nums",
				children: [/* @__PURE__ */ h("span", {
					className: e.approved ? "opacity-40 line-through" : "",
					children: u.project
				}), /* @__PURE__ */ h("span", {
					className: e.approved ? "" : "opacity-40",
					children: u.approved
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: "welcome-plan-result",
				children: n === null ? r ? /* @__PURE__ */ h("button", {
					type: "button",
					onClick: a,
					className: "min-h-11 rounded-lg border-2 border-ink px-1.5 text-xs font-extrabold text-white",
					style: { background: j.accent },
					"aria-label": `${c("games.welcome.claim", { n: d })} (${c("games.welcome.round", { n: i })})`,
					children: c("games.welcome.claim", { n: d })
				}) : e.approved ? /* @__PURE__ */ h("span", {
					className: "text-[11px] leading-3.5 font-bold opacity-60",
					children: c("games.welcome.planApproved", { n: u.approved })
				}) : null : /* @__PURE__ */ g("span", {
					className: "rounded-full bg-ink px-2 font-display text-[11px] leading-4.5 font-bold text-white",
					children: ["+", n]
				})
			})
		]
	});
}
function Ve({ pub: e, selected: t, disabled: n, onPick: r }) {
	let i = s(), { ref: a } = o("offers");
	return /* @__PURE__ */ h("div", {
		ref: a,
		className: "welcome-offers",
		children: e.offers.map((a, o) => /* @__PURE__ */ h(He, {
			offer: a,
			index: o,
			selected: t === o,
			disabled: n,
			onPick: () => r(o),
			t: i
		}, `${e.round}-${o}`))
	});
}
function He({ offer: e, index: t, selected: n, disabled: r, onPick: i, t: a }) {
	let { ref: s } = o(`offer:${t}`);
	return /* @__PURE__ */ g("button", {
		ref: s,
		type: "button",
		disabled: r,
		onClick: i,
		"aria-label": a("games.welcome.offerAria", {
			num: e.num,
			effect: a(Fe[e.effect])
		}),
		"aria-pressed": n,
		className: `welcome-offer card-flip-in flex min-h-16 min-w-0 flex-1 items-center justify-between gap-1 rounded-2xl border-3 px-2.5 text-white transition-transform active:translate-y-0.5 disabled:opacity-60 ${Ie[e.effect]} ${n ? "border-ink" : "border-ink/40"}`,
		style: n ? { boxShadow: `3px 3px 0 ${j.accent}` } : void 0,
		children: [/* @__PURE__ */ h("span", {
			className: "welcome-offer-number font-mono text-3xl leading-none font-extrabold tabular-nums",
			children: e.num
		}), /* @__PURE__ */ g("span", {
			className: "welcome-offer-effect flex flex-col items-center gap-0.5",
			children: [/* @__PURE__ */ h("span", {
				"aria-hidden": !0,
				className: "welcome-offer-icon grid size-7 place-items-center rounded-full bg-surface text-sm",
				children: Pe[e.effect]
			}), /* @__PURE__ */ h("span", {
				className: "welcome-offer-label text-[11px] leading-3 font-bold text-white/85",
				children: a(Fe[e.effect])
			})]
		})]
	});
}
//#endregion
//#region src/games/welcome/bot.ts
function Ue(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Z = (e) => ({
	houses: e.houses.map((e) => [...e]),
	bisAt: e.bisAt.map((e) => [...e]),
	fences: e.fences.map((e) => [...e]),
	used: e.used.map((e) => [...e]),
	parks: [...e.parks],
	pools: e.pools,
	temps: e.temps,
	promo: [...e.promo],
	bis: e.bis,
	refusals: e.refusals,
	planScores: [...e.planScores]
});
function We(e, t, n, r) {
	let i = e.houses[t], a = 0, o = 18, s = -1, c = i.length;
	for (let e = n - 1; e >= 0; --e) if (i[e] !== null) {
		a = i[e], s = e;
		break;
	}
	for (let e = n + 1; e < i.length; e += 1) if (i[e] !== null) {
		o = i[e], c = e;
		break;
	}
	let l = r - a - 1 - (n - s - 1), u = o - r - 1 - (c - n - 1), d = -.3 * Math.abs(l - u);
	return (l < 0 || u < 0) && (d -= 6), l === 0 && u === 0 && (n - s - 1 > 0 || c - n - 1 > 0) && (d += 1), d;
}
var Ge = (e, t) => T[t - 1][Math.min(e.promo[t - 1], T[t - 1].length - 1)];
function Q(e, t) {
	let n = 0;
	for (let r of t) {
		let t = /* @__PURE__ */ new Map();
		for (let n of I(e)) n.complete && !n.used && n.size <= 6 && t.set(n.size, (t.get(n.size) ?? 0) + 1);
		let i = 0;
		for (let e of [...r.sizes].sort((e, t) => t - e)) {
			let n = t.get(e) ?? 0;
			n > 0 && (t.set(e, n - 1), i += 1);
		}
		n += i / r.sizes.length * r.project;
	}
	return n;
}
function $(e, t, n) {
	let r = 0;
	for (let i of t) !i.complete || i.size > 6 || e.some((e) => e.street === i.street && e.start === i.start && e.complete) || (r += Ge(n, i.size));
	return r;
}
function Ke(e, t) {
	let n = null;
	for (let r = 0; r < 3; r++) {
		let i = x[r];
		for (let a = 0; a < i - 1; a++) {
			if (e.fences[r][a] || e.used[r][a] && e.used[r][a + 1]) continue;
			let o = e.houses[r][a];
			if (o !== null && o === e.houses[r][a + 1]) continue;
			let s = a;
			for (; s > 0 && !e.fences[r][s - 1];) --s;
			let c = a + 1;
			for (; c < i - 1 && !e.fences[r][c];) c += 1;
			let l = (n, i) => {
				let a = i - n + 1, o = !0;
				for (let t = n; t <= i; t++) e.houses[r][t] === null && (o = !1);
				return o && a <= 6 ? Ge(e, a) : t.has(a) && a <= 6 ? 3 : 0;
			}, u = l(s, a) + l(a + 1, c);
			u > 0 && (n === null || u > n.value) && (n = {
				act: {
					type: "fence",
					street: r,
					gap: a
				},
				value: u
			});
		}
	}
	return n;
}
function qe(e) {
	let t = null;
	for (let n = 0; n < 6; n++) {
		let r = T[n];
		if (e.promo[n] >= r.length - 1) continue;
		let i = r[e.promo[n] + 1] - r[e.promo[n]];
		if (i <= 0) continue;
		let a = I(e).filter((e) => e.complete && e.size === n + 1).length, o = i * (a > 0 ? a : .3);
		(t === null || o > t.value) && (t = {
			act: {
				type: "promote",
				col: n
			},
			value: o
		});
	}
	return t;
}
var Je = (e, t) => {
	let n = e.public, r = e.private;
	if (!r || n.phase !== "play") return null;
	let i = n.players.find((e) => e.rid === t.rid);
	if (!i) return null;
	let a = r.claimable.map((e, t) => e ? t : -1).filter((e) => e >= 0);
	if (a.length > 0) return { action: {
		type: "claimPlan",
		plan: a.reduce((e, t) => {
			let r = A.find((t) => t.id === n.plans[e].id);
			return (A.find((e) => e.id === n.plans[t].id)?.project ?? 0) > (r?.project ?? 0) ? t : e;
		})
	} };
	if (i.submitted) return null;
	let o = r.sheet, s = n.plans.map((e, t) => ({
		def: A.find((t) => t.id === e.id),
		claimed: o.planScores[t] !== null
	})).filter((e) => !e.claimed && e.def).map((e) => e.def), c = new Set(s.flatMap((e) => e.sizes)), l = I(o), u = Q(o, s), d = [];
	if (n.offers.forEach((e, t) => {
		for (let n = 0; n < 3; n++) for (let r = 0; r < x[n]; r++) {
			if (e.effect === "bis") {
				if (o.bis >= E.length - 1) continue;
				let e = L(o, n, r);
				if (!e || !R(o, n, r, e.num, e.from)) continue;
				let i = E[o.bis + 1] - E[o.bis], a = Z(o);
				a.houses[n][r] = e.num;
				let c = $(l, I(a), o), f = Q(a, s) - u, p = 1 + We(o, n, r, e.num) + c + .7 * f - i;
				d.push({
					action: {
						type: "play",
						offer: t,
						street: n,
						house: r,
						effect: { type: "bis" }
					},
					score: p
				});
				continue;
			}
			let i = e.effect === "temp" && o.temps < 11 ? [
				-2,
				-1,
				0,
				1,
				2
			].map((t) => e.num + t).filter((e) => e >= 0 && e <= 17) : [e.num], a = null;
			for (let t of i) {
				if (!R(o, n, r, t, null)) continue;
				let i = We(o, n, r, t), c = Z(o);
				c.houses[n][r] = t;
				let d = $(l, I(c), o), f = Q(c, s) - u, p = i + d + .7 * f;
				(a === null || p > a.fit + a.gain + .7 * a.progDelta) && (a = {
					num: t,
					delta: t - e.num,
					fit: i,
					after: c,
					gain: d,
					progDelta: f
				});
			}
			if (a === null) continue;
			let f = a, p = null, m = 0;
			switch (e.effect) {
				case "pool":
					S[n].includes(r) && (p = { type: "pool" }, m = w[Math.min(o.pools + 1, w.length - 1)] - w[Math.min(o.pools, w.length - 1)]);
					break;
				case "landscaper":
					if (o.parks[n] < C[n].length) {
						let e = C[n][Math.min(o.parks[n] + 1, C[n].length - 1)] - C[n][Math.min(o.parks[n], C[n].length - 1)];
						e > 0 && (p = { type: "park" }, m = e);
					}
					break;
				case "estate": {
					let e = qe(f.after);
					e && (p = e.act, m = e.value);
					break;
				}
				case "surveyor": {
					let e = Ke(f.after, c);
					e && (p = e.act, m = e.value);
					break;
				}
				case "temp": o.temps < 11 && (p = {
					type: "temp",
					delta: f.delta
				}, m = .8);
			}
			let h = 1 + f.fit + f.gain + .7 * f.progDelta + m;
			d.push({
				action: {
					type: "play",
					offer: t,
					street: n,
					house: r,
					effect: p
				},
				score: h
			});
		}
	}), d.length === 0) return { action: { type: "refuse" } };
	if (t.difficulty === "weak") return { action: Ue(d).action };
	let f = Math.max(...d.map((e) => e.score));
	return { action: Ue(d.filter((e) => e.score === f)).action };
}, Ye = (e, t, n) => {
	if (e.type === "claimPlan") return n("games.welcome.hintClaimPlan", { n: e.plan + 1 });
	if (e.type === "refuse") return n("games.welcome.refuse");
	if (e.type !== "play") return "";
	let r = t.public.offers[e.offer].num, i = n("games.welcome.hintWhere", {
		street: n("games.welcome.streetAria", { n: e.street + 1 }),
		house: n("games.welcome.houseAria", { n: e.house + 1 })
	}), a = e.effect, o = "";
	if (a !== null) switch (a.type) {
		case "fence":
			o = n("games.welcome.hintEffFence", {
				street: n("games.welcome.streetAria", { n: a.street + 1 }),
				n: a.gap + 1
			});
			break;
		case "promote":
			o = n("games.welcome.hintEffPromote", { n: a.col + 1 });
			break;
		case "park":
			o = n("games.welcome.hintEffPark");
			break;
		case "pool":
			o = n("games.welcome.hintEffPool");
			break;
		case "temp":
			o = n("games.welcome.hintEffTemp", { n: r + a.delta });
			break;
		case "bis": o = n("games.welcome.hintEffBis");
	}
	return n("games.welcome.hintPlay", {
		num: r,
		where: i,
		eff: o
	});
};
//#endregion
//#region src/games/welcome/fx.tsx
function Xe({ num: e, bis: t }) {
	return /* @__PURE__ */ g("span", {
		className: "grid size-8 place-items-center rounded-full border-2 border-ink font-mono text-sm font-extrabold text-white tabular-nums",
		style: { background: j.accent },
		children: [e, t && /* @__PURE__ */ h("sup", {
			className: "-mr-1 text-[9px]",
			children: "bis"
		})]
	});
}
var Ze = {
	flip(e, t) {
		let n = e.data?.reshuffled === !0, r = t.anchor("offers");
		return n && r ? {
			ms: 700,
			node: /* @__PURE__ */ h(_, {
				at: r,
				ms: 700,
				children: /* @__PURE__ */ h("span", {
					"aria-hidden": !0,
					className: "text-xl",
					children: "🔄"
				})
			})
		} : {
			ms: 350,
			node: null
		};
	},
	write(e, t) {
		let n = e.data;
		if (typeof n?.street != "number" || typeof n.house != "number" || typeof n.num != "number") return null;
		let r = e.rid ? t.anchor(`seat:${e.rid}`) : null, i = t.anchor(`house:${n.street}:${n.house}`), a = /* @__PURE__ */ h(Xe, {
			num: n.num,
			bis: n.bis === !0
		});
		return i && r ? {
			ms: 450,
			node: /* @__PURE__ */ h(v, {
				from: r,
				to: i,
				ms: 380,
				children: a
			}),
			hide: [`house:${n.street}:${n.house}`]
		} : r ? {
			ms: 800,
			node: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(y, {
				at: r,
				ms: 500
			}), /* @__PURE__ */ h(_, {
				at: r,
				ms: 800,
				children: a
			})] })
		} : null;
	},
	refuse(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ h(_, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ h("span", {
					className: "grid size-7 place-items-center rounded-full border-2 border-ink bg-danger-soft font-mono text-sm font-extrabold text-danger-ink",
					children: "✕"
				})
			})
		} : null;
	},
	plan(e, t) {
		let n = e.data;
		if (typeof n?.plan != "number" || typeof n.points != "number") return null;
		let r = t.anchor(`plan:${n.plan}`), i = e.rid ? t.anchor(`seat:${e.rid}`) : null, a = r ?? i;
		return a ? {
			ms: 900,
			node: /* @__PURE__ */ g(m, { children: [r && /* @__PURE__ */ h(y, {
				at: r,
				ms: 600
			}), /* @__PURE__ */ h(_, {
				at: a,
				ms: 900,
				children: /* @__PURE__ */ g("span", {
					className: "rounded-full border-2 border-ink px-1.5 font-mono text-sm font-extrabold text-white tabular-nums",
					style: { background: j.accent },
					children: ["+", n.points]
				})
			})] })
		} : null;
	},
	reshuffle(e, t) {
		let n = t.anchor("offers");
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ h(y, {
				at: n,
				ms: 500
			})
		} : null;
	}
}, Qe = [
	{
		key: "games.welcome.catPlans",
		field: "plans",
		icon: "🏙️"
	},
	{
		key: "games.welcome.catParks",
		field: "parks",
		icon: "🌳"
	},
	{
		key: "games.welcome.catPools",
		field: "pools",
		icon: "🏊"
	},
	{
		key: "games.welcome.catTemps",
		field: "temps",
		icon: "👷"
	},
	{
		key: "games.welcome.catEstates",
		field: "estates",
		icon: "🏡"
	}
], $e = [{
	key: "games.welcome.catBis",
	field: "bis",
	icon: "👯"
}, {
	key: "games.welcome.catRefusals",
	field: "refusals",
	icon: "🚫"
}];
function et({ result: e, public: t, private: n, members: r, myRid: i, onPlayAgain: a, onBackToLobby: o }) {
	let c = s(), l = t, u = (e) => r.find((t) => t.rid === e)?.name ?? e, d = a ?? o, f = n === void 0 ? null : F.safeParse(n), p = f?.success ? f.data.sheet : null, m = l.final?.find((e) => e.rid === i)?.score ?? null;
	return /* @__PURE__ */ g("div", {
		className: "welcome-final relative",
		style: { "--welcome-accent": j.accent },
		children: [
			e.winner.length > 0 && /* @__PURE__ */ h(b, {}),
			/* @__PURE__ */ g("h1", {
				className: "welcome-final-title flex items-center justify-center gap-2 text-center font-display font-extrabold",
				children: [/* @__PURE__ */ h("span", {
					"aria-hidden": !0,
					children: j.icon
				}), c("session.result.title")]
			}),
			/* @__PURE__ */ g("div", {
				className: "welcome-final-main",
				"data-has-sheet": !!p,
				children: [/* @__PURE__ */ h("div", {
					className: "welcome-final-ranking",
					children: e.ranking.map((t, n) => {
						let r = l.final?.find((e) => e.rid === t);
						if (!r) return null;
						let i = r.score, a = e.winner.includes(t);
						return /* @__PURE__ */ g("section", {
							"data-winner": a,
							className: "welcome-final-card frame flex flex-col gap-1 p-2.5",
							children: [/* @__PURE__ */ g("header", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ h("span", {
										"aria-hidden": !0,
										className: `w-5 flex-none text-center ${a ? "" : "invisible"}`,
										children: "🏆"
									}),
									/* @__PURE__ */ g("span", {
										className: "welcome-final-name min-w-0 flex-1 truncate font-extrabold",
										title: u(t),
										children: [
											n + 1,
											". ",
											u(t)
										]
									}),
									/* @__PURE__ */ g("span", {
										className: "welcome-final-score flex-none font-mono font-extrabold tabular-nums",
										children: [i.total, /* @__PURE__ */ h("span", {
											className: "ml-1 text-[11px] font-bold opacity-50",
											children: c("games.welcome.total")
										})]
									})
								]
							}), /* @__PURE__ */ g("ul", {
								className: "welcome-final-categories",
								children: [Qe.map((e) => /* @__PURE__ */ g("li", {
									"aria-label": `${c(e.key)} ${i[e.field]}`,
									className: `welcome-final-category flex items-center justify-center gap-0.5 rounded-md border border-ink/30 px-0.5 leading-5 font-bold ${i[e.field] === 0 ? "opacity-35" : ""}`,
									children: [/* @__PURE__ */ h("span", {
										"aria-hidden": !0,
										children: e.icon
									}), /* @__PURE__ */ g("span", {
										className: "font-mono tabular-nums",
										children: ["+", i[e.field]]
									})]
								}, e.field)), $e.map((e) => /* @__PURE__ */ g("li", {
									"aria-label": `${c(e.key)} -${i[e.field]}`,
									className: `welcome-final-category flex items-center justify-center gap-0.5 rounded-md border border-ink/30 px-0.5 leading-5 font-bold ${i[e.field] === 0 ? "opacity-35" : "text-danger-ink"}`,
									children: [/* @__PURE__ */ h("span", {
										"aria-hidden": !0,
										children: e.icon
									}), /* @__PURE__ */ g("span", {
										className: "font-mono tabular-nums",
										children: ["-", i[e.field]]
									})]
								}, e.field))]
							})]
						}, t);
					})
				}), p && /* @__PURE__ */ g("section", {
					className: "welcome-final-detail",
					children: [/* @__PURE__ */ h("h2", {
						className: "section-label",
						children: c("games.welcome.mySheet")
					}), /* @__PURE__ */ h("div", {
						className: "welcome-final-paper frame",
						role: "img",
						"aria-label": c("games.welcome.mySheet"),
						children: /* @__PURE__ */ h(Ae, {
							sheet: p,
							readOnly: !0,
							fitKey: "over",
							name: u(i),
							final: m
						})
					})]
				})]
			}),
			d ? /* @__PURE__ */ g("div", {
				className: "welcome-final-actions safe-b pb-1",
				children: [a && /* @__PURE__ */ h("button", {
					className: "btn-base w-full cursor-pointer text-white",
					style: { background: j.accent },
					onClick: a,
					children: c("session.result.playAgain")
				}), o && /* @__PURE__ */ h("button", {
					className: "btn-quiet w-full cursor-pointer",
					onClick: o,
					children: c("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ h("p", {
				className: "welcome-final-wait safe-b pb-1 text-sm font-bold opacity-70",
				children: c("session.result.waitHost")
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/welcome/entry.tsx
var tt = {
	definition: ge,
	View: Re,
	bot: Je,
	describe: Ye,
	fx: Ze,
	OverView: et,
	locales: {
		zh: {
			name: "欢迎来到",
			desc: "翻牌填号造小镇:圈庄园、修公园泳池,抢头名完成城市计划",
			rules: "目标:有人第 3 次拒建、完成全部 3 张计划卡或建满全部房子时,游戏立即结束,总分最高者获胜。\n流程(每回合):\n· 亮出三组「房号 + 效果」,所有人同时各选一组。\n· 把房号填进自己三条街的空房:同一条街从左到右必须严格递增,不重号。\n· 随后可使用所选组合的效果。\n效果一览:\n· 测量员:在两栋房子之间建栅栏;栅栏围出 1~6 栋相连房子且全部填有号码,就是一个庄园。\n· 房产经纪:划掉增值轨上的一格,提升某一尺寸庄园的价值。\n· 园艺师:在本街划掉一格公园。\n· 泳池商:房号填进泳池房即建好泳池。\n· 临时工:可把房号上调或下调至多 2,并在临时工轨上划掉一格;终局时划格数排前三的玩家得分。\n· Bis:把相邻房子的号码复制到紧邻的空房,但终局要扣分。\n城市计划:\n· 凑齐计划卡要求的庄园组合可领分:首个完成者得高分,之后完成的得低分。\n· 首个完成者可以选择重洗整副牌。",
			round: "第 {{n}} 轮",
			chooseOffer: "选一组「号码 + 效果」,再点一栋空房",
			waitingOthers: "已提交,等其他人…",
			offerAria: "号码 {{num}},效果 {{effect}}",
			effSurveyor: "测量员",
			effEstate: "房产经纪",
			effLandscaper: "园艺师",
			effPool: "泳池商",
			effTemp: "临时工",
			effBis: "Bis 复制",
			hintFence: "栅栏:点两栋房之间的缝隙放下栅栏",
			hintPromote: "增值:点一列庄园尺寸划掉一格",
			hintPark: "园艺:自动划掉本街一格公园",
			hintPool: "泳池:填进泳池房即自动建成",
			hintTemp: "临时工:先选 ±0/1/2 定最终号码",
			hintBis: "Bis:点贴着已有号码的空房复制",
			skipEffect: "跳过效果",
			confirmPlay: "确认 {{num}} 号",
			refuse: "拒建",
			refuseConfirm: "确认拒建?将划掉一格许可轨",
			claim: "完成 +{{n}}",
			planApproved: "已批准,之后完成得 {{n}} 分",
			reshuffle: "重洗整副牌",
			reshufflePending: "本回合结束后重洗",
			parks: "公园",
			pools: "泳池",
			temps: "临时工",
			estates: "庄园",
			bisTrack: "Bis",
			refusals: "拒建",
			mySheet: "我的计分纸",
			streetAria: "第 {{n}} 街",
			houseAria: "第 {{n}} 栋",
			catPlans: "城市计划",
			catParks: "公园",
			catPools: "泳池",
			catTemps: "临时工",
			catEstates: "庄园",
			catBis: "Bis 罚分",
			catRefusals: "拒建罚分",
			total: "总分",
			errGameOver: "对局已结束",
			errNotYourTurn: "你不在本局中",
			errAlreadySubmitted: "本回合已提交",
			errBadEffect: "效果与所选组合不符",
			errBadHouse: "这栋房子填不了这个号",
			errBadFence: "这里建不了栅栏",
			errFenceBlocked: "被计划卡占用的庄园不能再分割",
			errColFull: "这列已划满",
			errParkFull: "这条街的公园划满了",
			errBadDelta: "临时工只能 ±2,且号码要在 0–17",
			errNoBisNeighbor: "Bis 必须贴着已有号码(中间无栅栏)",
			errTrackFull: "这条轨已划满",
			errPlanClaimed: "你已领过这张计划卡",
			errPlanNotMet: "庄园组合还不满足这张计划卡",
			errNoReshuffle: "现在不能重洗",
			hintClaimPlan: "领取第 {{n}} 张城市计划",
			hintPlay: "把 {{num}} 写进{{where}}{{eff}}",
			hintWhere: "{{street}}{{house}}",
			hintEffFence: ",并在{{street}}第 {{n}} 栋右侧建栅栏",
			hintEffPromote: ",并给 {{n}} 房庄园增值",
			hintEffPark: ",并划掉一格公园",
			hintEffPool: ",并建好泳池",
			hintEffTemp: ",用临时工把号码调成 {{n}}",
			hintEffBis: ",并 Bis 复制邻号"
		},
		en: {
			name: "Welcome To…",
			desc: "Flip-and-write town building: fence estates, build parks & pools, race for city plans",
			rules: "Goal: the game ends immediately when someone takes a 3rd permit refusal, completes all 3 plans, or fills every house; the highest total wins.\nEach round:\n· Three “house number + effect” combos are revealed, and everyone picks one at the same time.\n· Write the number in an empty house on your three streets: each street must be strictly ascending left to right, with no duplicates.\n· You may then use the picked combo’s effect.\nEffects:\n· Surveyor: build a fence between two houses; a fenced-in run of 1–6 connected houses, all numbered, is an estate.\n· Real Estate Agent: cross off a box on the value track to raise the value of one estate size.\n· Landscaper: cross off a park box on that street.\n· Pool Manufacturer: writing in a pool house builds its pool.\n· Temp Agency: adjust the number up or down by up to 2 and cross off a box on its track; the top three temp counts score at the end.\n· Bis: copy an adjacent house’s number into a touching empty house, but it costs points at the end.\nCity plans:\n· Complete a plan’s required estates to score it: the first completer earns the higher points, later completers the lower.\n· The first completer may reshuffle the deck.",
			round: "Round {{n}}",
			chooseOffer: "Pick a \"number + effect\" combo, then tap an empty house",
			waitingOthers: "Submitted, waiting for others…",
			offerAria: "Number {{num}}, effect {{effect}}",
			effSurveyor: "Surveyor",
			effEstate: "Real Estate Agent",
			effLandscaper: "Landscaper",
			effPool: "Pool Manufacturer",
			effTemp: "Temp Agency",
			effBis: "Bis",
			hintFence: "Fence: tap the gap between two houses to place a fence",
			hintPromote: "Promote: tap an estate-size column to cross off a box",
			hintPark: "Landscaper: crosses off a park box on this street",
			hintPool: "Pool: built automatically in a pool house",
			hintTemp: "Temp: pick ±0/1/2 for the final number",
			hintBis: "Bis: tap an empty house next to an existing number",
			skipEffect: "Skip effect",
			confirmPlay: "Confirm {{num}}",
			refuse: "Refuse",
			refuseConfirm: "Really refuse? Crosses off a permit box",
			claim: "Complete +{{n}}",
			planApproved: "Approved — now worth {{n}} pts",
			reshuffle: "Reshuffle the deck",
			reshufflePending: "Reshuffles after this round",
			parks: "Parks",
			pools: "Pools",
			temps: "Temps",
			estates: "Estates",
			bisTrack: "Bis",
			refusals: "Permits",
			mySheet: "My scoresheet",
			streetAria: "Street {{n}}",
			houseAria: "House {{n}}",
			catPlans: "City plans",
			catParks: "Parks",
			catPools: "Pools",
			catTemps: "Temps",
			catEstates: "Estates",
			catBis: "Bis penalty",
			catRefusals: "Permit refusals",
			total: "Total",
			errGameOver: "The game is over",
			errNotYourTurn: "You are not in this game",
			errAlreadySubmitted: "Already submitted this round",
			errBadEffect: "Effect does not match the chosen combo",
			errBadHouse: "This house cannot take that number",
			errBadFence: "Cannot build a fence here",
			errFenceBlocked: "An estate used for a plan cannot be subdivided",
			errColFull: "This column is full",
			errParkFull: "No park boxes left on this street",
			errBadDelta: "Temps allow only ±2, and numbers stay 0–17",
			errNoBisNeighbor: "Bis must touch an existing number (no fence between)",
			errTrackFull: "This track is full",
			errPlanClaimed: "You already scored this plan",
			errPlanNotMet: "Your estates do not meet this plan yet",
			errNoReshuffle: "Cannot reshuffle now",
			hintClaimPlan: "Claim city plan {{n}}",
			hintPlay: "Write {{num}} at {{where}}{{eff}}",
			hintWhere: "{{street}} {{house}}",
			hintEffFence: ", and fence right of house {{n}} on {{street}}",
			hintEffPromote: ", and promote size-{{n}} estates",
			hintEffPark: ", and cross off a park box",
			hintEffPool: ", and build the pool",
			hintEffTemp: ", temp agency: make it {{n}}",
			hintEffBis: ", and Bis a neighbouring number"
		}
	}
};
//#endregion
export { tt as default };
