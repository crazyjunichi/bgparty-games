import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { useT as o } from "@bgparty/sdk/i18n";
import { useFxAnchor as s, useFxAnchorsMaybe as c } from "@bgparty/sdk/fx/anchors";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { useFrame as f, useLoader as p, useThree as m } from "@react-three/fiber";
import { ResilientCanvas as h } from "@bgparty/sdk/three/resilient-canvas";
import { BufferGeometry as g, CanvasTexture as _, CatmullRomCurve3 as v, DoubleSide as y, ExtrudeGeometry as b, Float32BufferAttribute as x, PlaneGeometry as S, RepeatWrapping as C, SRGBColorSpace as ee, Shape as te, TextureLoader as w, Vector3 as T } from "three";
import { usePrefersReducedMotion as ne } from "@bgparty/sdk/fx/use-reduced-motion";
import { Fragment as E, jsx as D, jsxs as O } from "react/jsx-runtime";
import { Flash as k, Floater as A, PulseBox as j } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as re } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as M, OptionSection as N } from "@bgparty/sdk/ui/game-options";
//#region src/games/heat/data.ts
var P = {
	usa: {
		spaces: 69,
		laps: 2,
		heat: 6,
		stress: 3,
		corners: [
			{
				at: 12,
				limit: 7
			},
			{
				at: 33,
				limit: 3
			},
			{
				at: 49,
				limit: 3
			},
			{
				at: 57,
				limit: 2
			}
		],
		pts: [
			[941, 151],
			[998, 166],
			[1040, 199],
			[1073, 241],
			[1088, 292],
			[1107, 344],
			[1119, 386],
			[1131, 437],
			[1143, 485],
			[1152, 534],
			[1155, 579],
			[1146, 642],
			[1119, 690],
			[1070, 730],
			[1016, 745],
			[965, 745],
			[914, 745],
			[862, 745],
			[811, 745],
			[766, 742],
			[715, 742],
			[663, 745],
			[615, 744],
			[569, 748],
			[518, 745],
			[473, 744],
			[416, 741],
			[374, 739],
			[320, 742],
			[274, 739],
			[223, 745],
			[175, 751],
			[109, 745],
			[75, 690],
			[96, 627],
			[145, 603],
			[202, 588],
			[253, 561],
			[283, 516],
			[311, 464],
			[326, 422],
			[338, 374],
			[353, 326],
			[371, 280],
			[389, 232],
			[416, 187],
			[446, 142],
			[473, 99],
			[531, 69],
			[591, 84],
			[621, 142],
			[597, 196],
			[561, 244],
			[531, 295],
			[501, 341],
			[479, 389],
			[452, 431],
			[455, 504],
			[522, 491],
			[558, 443],
			[579, 398],
			[609, 359],
			[636, 317],
			[669, 277],
			[699, 235],
			[736, 199],
			[775, 163],
			[832, 145],
			[883, 142]
		]
	},
	ita: {
		spaces: 54,
		laps: 3,
		heat: 6,
		stress: 3,
		corners: [
			{
				at: 10,
				limit: 5
			},
			{
				at: 19,
				limit: 2
			},
			{
				at: 26,
				limit: 3
			}
		],
		pts: [
			[962, 350],
			[965, 395],
			[959, 449],
			[950, 501],
			[908, 552],
			[877, 585],
			[841, 615],
			[805, 651],
			[769, 684],
			[727, 709],
			[663, 718],
			[615, 684],
			[594, 633],
			[579, 582],
			[570, 549],
			[555, 491],
			[546, 449],
			[540, 401],
			[528, 350],
			[464, 317],
			[431, 362],
			[452, 428],
			[464, 488],
			[482, 549],
			[491, 597],
			[491, 654],
			[452, 706],
			[383, 696],
			[347, 651],
			[338, 603],
			[326, 552],
			[317, 513],
			[305, 461],
			[295, 413],
			[283, 371],
			[274, 323],
			[274, 265],
			[286, 220],
			[317, 166],
			[347, 130],
			[395, 96],
			[440, 75],
			[488, 60],
			[543, 57],
			[591, 54],
			[642, 54],
			[699, 63],
			[745, 69],
			[802, 90],
			[847, 121],
			[883, 163],
			[911, 199],
			[932, 247],
			[947, 295]
		]
	},
	fra: {
		spaces: 60,
		laps: 2,
		heat: 6,
		stress: 3,
		corners: [
			{
				at: 12,
				limit: 5
			},
			{
				at: 20,
				limit: 2
			},
			{
				at: 27,
				limit: 4
			},
			{
				at: 39,
				limit: 3
			},
			{
				at: 47,
				limit: 4
			}
		],
		pts: [
			[567, 712],
			[513, 700],
			[470, 690],
			[419, 672],
			[371, 645],
			[326, 615],
			[289, 579],
			[259, 543],
			[223, 507],
			[196, 467],
			[154, 434],
			[109, 392],
			[109, 323],
			[142, 271],
			[193, 253],
			[250, 241],
			[295, 229],
			[347, 208],
			[395, 187],
			[443, 139],
			[507, 136],
			[516, 208],
			[473, 253],
			[443, 292],
			[404, 332],
			[380, 377],
			[365, 446],
			[395, 497],
			[446, 528],
			[507, 519],
			[555, 497],
			[597, 461],
			[636, 425],
			[663, 389],
			[693, 344],
			[712, 295],
			[736, 247],
			[721, 187],
			[739, 121],
			[790, 90],
			[844, 103],
			[886, 157],
			[892, 214],
			[914, 259],
			[974, 302],
			[1019, 314],
			[1079, 332],
			[1110, 392],
			[1104, 440],
			[1055, 497],
			[1022, 525],
			[980, 552],
			[944, 585],
			[905, 618],
			[865, 651],
			[820, 666],
			[775, 687],
			[721, 703],
			[672, 712],
			[624, 712]
		]
	},
	gbr: {
		spaces: 63,
		laps: 2,
		heat: 6,
		stress: 3,
		corners: [
			{
				at: 15,
				limit: 10
			},
			{
				at: 30,
				limit: 6
			},
			{
				at: 37,
				limit: 5
			},
			{
				at: 43,
				limit: 4
			},
			{
				at: 49,
				limit: 3
			}
		],
		pts: [
			[371, 127],
			[419, 88],
			[470, 61],
			[525, 52],
			[570, 55],
			[618, 52],
			[666, 52],
			[718, 52],
			[760, 52],
			[814, 52],
			[850, 55],
			[905, 58],
			[950, 55],
			[1001, 55],
			[1052, 64],
			[1101, 97],
			[1134, 145],
			[1140, 199],
			[1140, 251],
			[1134, 299],
			[1125, 350],
			[1116, 398],
			[1107, 444],
			[1091, 486],
			[1073, 534],
			[1046, 579],
			[1019, 618],
			[989, 658],
			[953, 694],
			[898, 724],
			[844, 715],
			[793, 667],
			[790, 612],
			[802, 555],
			[817, 513],
			[841, 456],
			[856, 401],
			[814, 353],
			[766, 344],
			[696, 374],
			[657, 401],
			[606, 398],
			[537, 416],
			[507, 465],
			[528, 528],
			[585, 558],
			[630, 561],
			[688, 591],
			[718, 646],
			[657, 673],
			[591, 652],
			[558, 636],
			[501, 609],
			[461, 585],
			[413, 558],
			[371, 525],
			[338, 480],
			[317, 434],
			[308, 380],
			[302, 332],
			[311, 281],
			[329, 223],
			[341, 187]
		]
	}
}, ie = [
	"usa",
	"ita",
	"fra",
	"gbr"
], ae = [
	"G",
	"R",
	"Y",
	"B"
], oe = {
	G: "#16a34a",
	R: "#dc2626",
	Y: "#eab308",
	B: "#2563eb",
	W: "#d6d3d1",
	K: "#292524"
}, se = [
	{
		W: [11, 0],
		B: [13, 1],
		Y: [14, 1],
		K: [15, 2],
		R: [18, 3],
		G: [19, 3]
	},
	{
		W: [16, 2],
		B: [12, 1],
		Y: [17, 2],
		K: [14, 1],
		R: [15, 2],
		G: [18, 3]
	},
	{
		W: [13, 1],
		B: [14, 1],
		Y: [15, 2],
		K: [17, 2],
		R: [11, 0],
		G: [10, 0]
	},
	{
		W: [17, 2],
		B: [15, 2],
		Y: [18, 3],
		K: [10, 0],
		R: [16, 2],
		G: [11, 0]
	},
	{
		W: [18, 3],
		B: [10, 0],
		Y: [12, 1],
		K: [19, 3],
		R: [14, 1],
		G: [13, 1]
	},
	{
		W: [12, 1],
		B: [17, 2],
		Y: [19, 3],
		K: [13, 1],
		R: [10, 0],
		G: [16, 2]
	},
	{
		W: [19, 3],
		B: [16, 2],
		Y: [13, 1],
		K: [18, 3],
		R: [17, 2],
		G: [12, 1]
	},
	{
		W: [14, 1],
		B: [18, 3],
		Y: [11, 0],
		K: [16, 2],
		R: [13, 1],
		G: [15, 2]
	},
	{
		W: [15, 2],
		B: [11, 0],
		Y: [10, 0],
		K: [12, 1],
		R: [19, 3],
		G: [17, 2]
	},
	{
		W: [10, 0],
		B: [19, 3],
		Y: [16, 2],
		K: [11, 0],
		R: [12, 1],
		G: [14, 1]
	}
], ce = [
	0,
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9
], F = {
	id: "heat",
	tier: "beta",
	mechanics: ["race", "hand-management"],
	interactionTags: [],
	nameKey: "games.heat.name",
	descKey: "games.heat.desc",
	rulesKey: "games.heat.rules",
	icon: "🏎️",
	iconImg: "games/heat.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/heat/en.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [5, 6],
	accent: "#dc2626",
	releasedAt: "2026-09-25",
	search: {
		py: "re li kuang biao",
		init: "rlkb"
	},
	hotseat: "cover"
}, le = t.enum([
	"usa",
	"ita",
	"fra",
	"gbr"
]), ue = t.enum([
	"off",
	"basic",
	"all"
]), de = t.object({
	track: le.catch("usa"),
	garage: ue.catch("off"),
	legends: t.int().min(0).max(4).catch(0)
}).catch({
	track: "usa",
	garage: "off",
	legends: 0
}), fe = t.enum([
	"s1",
	"s2",
	"s3",
	"s4",
	"c0",
	"f5",
	"xh",
	"st",
	"h"
]), I = t.union([fe, t.string().regex(/^u\d+$/)]), pe = t.int().min(1).max(4), me = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draft"),
		card: I
	}),
	t.object({
		type: t.literal("plan"),
		gear: pe,
		cards: t.array(I).max(4)
	}),
	t.object({
		type: t.literal("choice"),
		values: t.array(t.int().min(1).max(8)).max(4)
	}),
	t.object({
		type: t.literal("react"),
		boost: t.boolean(),
		adrSpeed: t.boolean(),
		cool: t.int().min(0).max(8),
		stressOut: t.array(I).max(3).default([]),
		salvage: t.array(I).max(4).default([]),
		refresh: t.array(I).max(4).default([]),
		direct: t.array(I).max(4).default([]),
		accel: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("slip"),
		take: t.boolean()
	}),
	t.object({
		type: t.literal("discard"),
		cards: t.array(I)
	})
]), he = t.string(), ge = t.object({
	rid: he,
	step: t.enum([
		"choice",
		"react",
		"slip",
		"discard"
	]),
	speed: t.int(),
	cooldownLeft: t.int().min(0),
	boostUsed: t.boolean(),
	adr: t.boolean(),
	adrSpeedUsed: t.boolean(),
	flips: t.int().min(0),
	limitAdj: t.int(),
	slipBonus: t.int().min(0),
	stressLeft: t.int().min(0),
	salvageLeft: t.int().min(0),
	accelAvail: t.boolean(),
	choiceIdx: t.array(t.int().min(0))
}), L = t.object({
	pos: t.int(),
	spot: t.int().min(0).max(1),
	gear: pe,
	engine: t.int().min(0),
	deckCount: t.int().min(0),
	handCount: t.int().min(0),
	discardTop: I.nullable(),
	play: t.array(I),
	planned: t.boolean(),
	finished: t.boolean(),
	spunOut: t.boolean(),
	lastSpeed: t.int().min(0),
	hasAdr: t.boolean()
}), _e = t.object({
	poolCount: t.int().min(0),
	market: t.array(I),
	round: t.int().min(0).max(2),
	order: t.array(he),
	idx: t.int().min(0),
	picks: t.record(t.string(), t.array(I))
}), ve = t.object({
	pos: t.int(),
	spot: t.int().min(0).max(1),
	finished: t.boolean(),
	color: t.enum([
		"W",
		"B",
		"Y",
		"K",
		"R",
		"G"
	])
}), R = t.object({
	track: le,
	round: t.int().min(1),
	phase: t.enum([
		"draft",
		"plan",
		"resolve",
		"done"
	]),
	cars: t.record(t.string(), L),
	legends: t.record(t.string(), ve),
	legendCard: t.int().min(0).max(9).nullable(),
	order: t.array(he),
	turn: t.int().min(0),
	current: ge.nullable(),
	draft: _e.nullable(),
	hall: t.array(he),
	log: t.array(t.object({
		k: t.string(),
		rid: he.optional(),
		n: t.int().optional()
	}))
}), ye = t.object({
	hand: t.array(I),
	myPlanned: t.object({
		gear: pe,
		cards: t.array(I)
	}).nullable(),
	discard: t.array(I)
}), be = {
	u0: {
		no: 5,
		cat: "body",
		v: 5,
		stress: 1
	},
	u1: {
		no: 4,
		cat: "body",
		v: 3,
		stress: 2
	},
	u2: {
		no: 3,
		cat: "4wd",
		plus: 1,
		cool: 3
	},
	u3: {
		no: 2,
		cat: "4wd",
		plus: 2
	},
	u4: {
		no: 1,
		cat: "4wd",
		v: 4
	},
	u5: {
		no: 30,
		cat: "rpm",
		adv: !0,
		v: 1,
		heat: 1,
		slip: 3
	},
	u6: {
		no: 29,
		cat: "rpm",
		adv: !0,
		plus: 1,
		slip: 3
	},
	u7: {
		no: 28,
		cat: "gas",
		adv: !0,
		v: 1,
		direct: !0,
		accel: !0
	},
	u8: {
		no: 27,
		cat: "gas",
		adv: !0,
		v: 4,
		direct: !0,
		heat: 1,
		cool: 1
	},
	u9: {
		no: 26,
		cat: "gas",
		adv: !0,
		v: 3,
		direct: !0,
		scrap: 3
	},
	u10: {
		no: 10,
		cat: "brakes",
		choice: [1, 5]
	},
	u11: {
		no: 9,
		cat: "brakes",
		choice: [2, 4]
	},
	u12: {
		no: 8,
		cat: "brakes",
		choice: [1, 3]
	},
	u13: {
		no: 7,
		cat: "brakes",
		choice: [
			1,
			2,
			3,
			4
		],
		heat: 1
	},
	u14: {
		no: 6,
		cat: "body",
		v: 1,
		stress: 3
	},
	u15: {
		no: 35,
		cat: "susp",
		adv: !0,
		v: 1,
		refresh: !0,
		slip: 2
	},
	u16: {
		no: 34,
		cat: "susp",
		adv: !0,
		v: 4,
		refresh: !0
	},
	u17: {
		no: 33,
		cat: "susp",
		adv: !0,
		v: 2,
		refresh: !0,
		cool: 1
	},
	u18: {
		no: 32,
		cat: "susp",
		adv: !0,
		v: 2,
		refresh: !0,
		stress: 1
	},
	u19: {
		no: 31,
		cat: "rpm",
		adv: !0,
		choice: [1, 2],
		slip: 1
	},
	u20: {
		no: 15,
		cat: "rpm",
		v: 2,
		slip: 2
	},
	u21: {
		no: 14,
		cat: "rpm",
		v: 1,
		slip: 2
	},
	u22: {
		no: 13,
		cat: "cooling",
		v: 3,
		cool: 1
	},
	u23: {
		no: 12,
		cat: "cooling",
		v: 1,
		cool: 2
	},
	u24: {
		no: 11,
		cat: "cooling",
		v: 6,
		heat: 1,
		cool: 1
	},
	u25: {
		no: 40,
		cat: "tires",
		adv: !0,
		plus: 1,
		limit: -1,
		slip: 1,
		cool: 1
	},
	u26: {
		no: 39,
		cat: "tires",
		adv: !0,
		v: 3,
		limit: -1,
		cool: 2
	},
	u27: {
		no: 38,
		cat: "tires",
		adv: !0,
		v: 2,
		scrap: 2,
		limit: 1
	},
	u28: {
		no: 37,
		cat: "tires",
		adv: !0,
		v: 1,
		scrap: 2,
		limit: 1
	},
	u29: {
		no: 36,
		cat: "tires",
		adv: !0,
		v: 2,
		limit: -1,
		cool: 3
	},
	u30: {
		no: 20,
		cat: "body",
		adv: !0,
		v: 2,
		stress: 1,
		slip: 1
	},
	u31: {
		no: 19,
		cat: "body",
		adv: !0,
		v: 2,
		stress: 1,
		cool: 1,
		scrap: 2
	},
	u32: {
		no: 18,
		cat: "body",
		adv: !0,
		v: 6,
		stress: 3,
		heat: 1
	},
	u33: {
		no: 17,
		cat: "xheat",
		xheat: !0
	},
	u34: {
		no: 16,
		cat: "rpm",
		v: 3,
		slip: 2
	},
	u35: {
		no: 45,
		cat: "wings",
		adv: !0,
		v: 3,
		heat: 1,
		scrap: 7,
		limit: 2
	},
	u36: {
		no: 44,
		cat: "wings",
		adv: !0,
		v: 4,
		heat: 1,
		scrap: 7,
		limit: 2
	},
	u37: {
		no: 43,
		cat: "turbo",
		adv: !0,
		v: 8,
		heat: 1,
		scrap: 6
	},
	u38: {
		no: 42,
		cat: "turbo",
		adv: !0,
		v: 7,
		heat: 2,
		cool: 3
	},
	u39: {
		no: 41,
		cat: "tires",
		adv: !0,
		plus: 2,
		limit: 2
	},
	u40: {
		no: 25,
		cat: "gas",
		adv: !0,
		v: 2,
		direct: !0,
		scrap: 1
	},
	u41: {
		no: 24,
		cat: "gas",
		adv: !0,
		v: 1,
		direct: !0,
		scrap: 1
	},
	u42: {
		no: 23,
		cat: "fuel",
		adv: !0,
		plus: 1,
		salvage: 2,
		cool: 1
	},
	u43: {
		no: 22,
		cat: "fuel",
		adv: !0,
		v: 2,
		salvage: 2
	},
	u44: {
		no: 21,
		cat: "cooling",
		adv: !0,
		v: 4,
		scrap: 2,
		cool: 1
	},
	u46: {
		no: 47,
		cat: "4wd",
		adv: !0,
		plus: 1,
		accel: !0
	},
	u47: {
		no: 46,
		cat: "wings",
		adv: !0,
		v: 6,
		heat: 2,
		limit: 3
	}
}, xe = [
	"u0",
	"u1",
	"u2",
	"u4",
	"u10",
	"u11",
	"u12",
	"u13",
	"u14",
	"u20",
	"u21",
	"u22",
	"u23",
	"u24",
	"u33",
	"u34",
	"u3"
], Se = ["u3", "u46"], Ce = /* @__PURE__ */ "u5.u6.u7.u8.u9.u15.u16.u17.u18.u19.u25.u26.u27.u28.u29.u30.u31.u32.u33.u35.u36.u37.u38.u39.u40.u41.u42.u43.u44.u47".split("."), we = xe.flatMap((e) => [e, e]), Te = [...Se, ...Ce.flatMap((e) => [e, e])], Ee = [...we, ...Te], z = (e) => e.startsWith("u"), B = (e) => be[e], De = [
	"s1",
	"s1",
	"s1",
	"s2",
	"s2",
	"s2",
	"s3",
	"s3",
	"s3",
	"s4",
	"s4",
	"s4",
	"c0",
	"f5",
	"xh",
	"st",
	"st",
	"st"
], Oe = [
	"s1",
	"s1",
	"s1",
	"s2",
	"s2",
	"s2",
	"s3",
	"s3",
	"s3",
	"s4",
	"s4",
	"s4",
	"st",
	"st",
	"st"
], V = 7;
function H(e) {
	return e === "c0" ? 0 : e === "f5" ? 5 : e.startsWith("s") && e !== "st" ? Number(e[1]) : null;
}
var ke = (e) => e.length === 2 && e[0] === "s" && e !== "st", Ae = (e) => e === "h" || e === "xh", je = (e) => e === "st", Me = (e) => e === "xh" || z(e) && !!B(e).xheat, U = (e) => !Ae(e) && !Me(e), Ne = (e) => !Ae(e) && !je(e) && !Me(e), W = (e) => P[e.track], Pe = (e) => W(e).spaces * W(e).laps;
function G(t, n, r) {
	let i = [...t], a = r;
	for (let t = i.length - 1; t > 0; --t) {
		let r = e(n, a, t + 1);
		a += 1, [i[t], i[r]] = [i[r], i[t]];
	}
	return {
		deck: i,
		cursor: a
	};
}
var K = (e, t) => t in e.legends, q = (e) => [...e.players, ...Object.keys(e.legends)], J = (e, t) => K(e, t) ? e.legends[t].pos : e.cars[t].pos, Fe = (e, t) => K(e, t) ? e.legends[t].spot : e.cars[t].spot, Ie = (e, t) => K(e, t) ? e.legends[t].finished : e.cars[t].finished;
function Y(e, t) {
	e.log.push(t), e.log.length > 40 && (e.log = e.log.slice(-40));
}
function X(e, t, n) {
	let r = q(e), i = n;
	for (; i > 0 && r.filter((n) => n !== t && J(e, n) === i).length >= 2;) --i;
	let a = +!!new Set(r.filter((n) => n !== t && J(e, n) === i).map((t) => Fe(e, t))).has(0);
	K(e, t) ? (e.legends[t].pos = i, e.legends[t].spot = a) : (e.cars[t].pos = i, e.cars[t].spot = a);
}
function Le(e, t, n) {
	let r = W(e).spaces, i = Pe(e), a = [];
	for (let o of W(e).corners) for (let e = 0;; e += 1) {
		let s = o.at + e * r;
		if (s > n) break;
		s > t && s <= i && a.push({
			x: s,
			limit: o.limit
		});
	}
	return a.sort((e, t) => e.x - t.x);
}
function Re(e, t, n) {
	let r = q(e), i = n - 1;
	for (; i > 0 && r.filter((n) => n !== t && J(e, n) === i).length >= 2;) --i;
	return i;
}
function ze(e, t) {
	for (;;) {
		if (t.deck.length === 0) {
			let n = G(t.discard, e.seed, e.rngCursor);
			if (t.deck = n.deck, t.discard = [], e.rngCursor = n.cursor, t.deck.length === 0) return "s1";
		}
		let n = t.deck.pop();
		if (ke(n)) return n;
		t.discard.push(n);
	}
}
function Be(e, t, n) {
	for (let r = 0; r < n; r += 1) {
		if (t.deck.length === 0) {
			let n = G(t.discard, e.seed, e.rngCursor);
			if (t.deck = n.deck, t.discard = [], e.rngCursor = n.cursor, t.deck.length === 0) return;
		}
		t.discard.push(t.deck.pop());
	}
}
function Ve(e, t) {
	for (; t.hand.length < V;) {
		if (t.deck.length === 0) {
			let n = G(t.discard, e.seed, e.rngCursor);
			if (t.deck = n.deck, t.discard = [], e.rngCursor = n.cursor, t.deck.length === 0) break;
		}
		t.hand.push(t.deck.pop());
	}
}
function He(e) {
	return q(e).filter((t) => !Ie(e, t)).sort((t, n) => J(e, n) - J(e, t) || Fe(e, t) - Fe(e, n));
}
function Ue(e, t, n) {
	return t >= n - (e.players.length + Object.keys(e.legends).length >= 5 ? 2 : 1);
}
function We(e) {
	let t = e.cur, n = e.cars[t.rid];
	n.lastSpeed = t.speed;
	let r = n.pos;
	return X(e, t.rid, r + t.speed), t.checkedTo = n.pos, Y(e, {
		k: "move",
		rid: t.rid,
		n: t.speed
	}), [{
		kind: "move",
		rid: t.rid,
		data: {
			from: r,
			to: n.pos,
			speed: t.speed
		}
	}];
}
function Ge(e, t) {
	let n = e.legends[t];
	if (e.legendCard === null) {
		if (e.legendDeck.length === 0) {
			let t = G(ce, e.seed, e.rngCursor);
			e.legendDeck = t.deck, e.rngCursor = t.cursor;
		}
		e.legendCard = e.legendDeck.pop(), Y(e, {
			k: "legendCard",
			n: e.legendCard
		});
	}
	let [r, i] = se[e.legendCard][n.color], a = W(e).spaces, o = W(e).corners.map((e) => ({
		x: e.at + (Math.floor((n.pos - e.at) / a) + 1) * a,
		limit: e.limit
	})).filter((e) => e.x > n.pos).sort((e, t) => e.x - t.x), s = o[0], c = o[1], l = n.pos, u;
	return u = l >= s.x - 7 && l < s.x ? Math.min(l + s.limit + i, c.x - 1) : l + r < s.x ? l + r : s.x - 1 - i, X(e, t, u), Y(e, {
		k: "move",
		rid: t,
		n: n.pos - l
	}), [{
		kind: "move",
		rid: t,
		data: {
			from: l,
			to: n.pos,
			speed: n.pos - l
		}
	}];
}
function Ke(e) {
	let t = e.order[e.turn];
	if (K(e, t)) return [...Ge(e, t), ...Ye(e)];
	let n = e.cars[t], r = 0, i = 0, a = 0, o = 0, s = 0, c = 0, l = 0, u = !1, d = [], f = n.play;
	n.play = [];
	for (let p of f) {
		if (je(p)) {
			n.play.push(p);
			let t = ze(e, n);
			n.play.push(t), r += H(t), i += 1;
			continue;
		}
		if (!z(p)) {
			n.play.push(p), r += H(p);
			continue;
		}
		let f = B(p);
		if (f.heat) {
			if (n.engine >= f.heat) {
				n.engine -= f.heat;
				for (let e = 0; e < f.heat; e += 1) n.discard.push("h");
			} else {
				n.discard.push(p);
				let a = ze(e, n);
				n.play.push(a), r += H(a), i += 1, Y(e, {
					k: "heatFail",
					rid: t
				});
				continue;
			}
		}
		if (n.play.push(p), f.scrap && Be(e, n, f.scrap), f.plus) for (let t = 0; t < f.plus; t += 1) {
			let t = ze(e, n);
			n.play.push(t), r += H(t), i += 1;
		}
		f.choice ? d.push(n.play.length - 1) : f.v !== void 0 && (r += f.v), f.limit && (a += f.limit), o += f.slip ?? 0, s += f.stress ?? 0, c += f.salvage ?? 0, l += f.cool ?? 0, f.accel && (u = !0);
	}
	let p = Ue(e, e.turn, e.order.length);
	return e.cur = {
		rid: t,
		step: d.length > 0 ? "choice" : "react",
		from: n.pos,
		speed: r,
		cooldownLeft: (n.gear === 1 ? 3 : +(n.gear === 2)) + +!!p + l,
		boostUsed: !1,
		adr: p,
		adrSpeedUsed: !1,
		checkedTo: n.pos,
		flips: i,
		limitAdj: a,
		slipBonus: o,
		stressLeft: s,
		salvageLeft: c,
		accelAvail: u,
		choiceIdx: d
	}, d.length > 0 ? [] : We(e);
}
function qe(e) {
	let t = e.cur, n = e.cars[t.rid], r = [], i = !0;
	for (let a of Le(e, t.from, t.checkedTo)) {
		let o = i ? a.limit + t.limitAdj : a.limit;
		i = !1;
		let s = t.speed - o;
		if (s <= 0) continue;
		let c = Math.min(s, n.engine);
		n.engine -= c;
		for (let e = 0; e < c; e += 1) n.discard.push("h");
		if (c < s) {
			let i = Re(e, t.rid, a.x), o = q(e), s = new Set(o.filter((n) => n !== t.rid && J(e, n) === i).map((t) => Fe(e, t)));
			n.pos = i, n.spot = +!!s.has(0);
			let c = n.gear <= 2 ? 1 : 2;
			for (let e = 0; e < c; e += 1) n.hand.push("st");
			n.gear = 1, n.spunOut = !0, Y(e, {
				k: "spin",
				rid: t.rid
			}), r.push({
				kind: "spin",
				rid: t.rid,
				data: { to: i }
			});
			break;
		}
		Y(e, {
			k: "pay",
			rid: t.rid,
			n: c
		});
	}
	return r;
}
function Je(e, t, n = 2) {
	let r = e.cars[t];
	return r.finished || r.pos + n >= Pe(e) ? !1 : q(e).some((n) => n !== t && (J(e, n) === r.pos || J(e, n) === r.pos + 1));
}
function Ye(e) {
	if (e.turn += 1, e.turn < e.order.length) return Ke(e);
	let t = q(e).filter((t) => !Ie(e, t) && J(e, t) >= Pe(e));
	t.sort((t, n) => J(e, n) - J(e, t) || Fe(e, t) - Fe(e, n));
	let n = [];
	for (let n of t) K(e, n) ? e.legends[n].finished = !0 : e.cars[n].finished = !0, e.hall.push(n), Y(e, {
		k: "finish",
		rid: n
	});
	if (t.length && n.push({
		kind: "finish",
		data: { rids: t }
	}), e.players.every((t) => e.cars[t].finished)) return e.phase = "done", n;
	e.phase = "plan", e.round += 1, e.planned = {}, e.legendCard = null;
	for (let t of e.players) e.cars[t].spunOut = !1;
	return n;
}
function Xe(e) {
	let t = e.cur, n = e.cars[t.rid];
	return n.discard.push(...n.play), n.play = [], Ve(e, n), e.cur = null, Ye(e);
}
function Ze(e) {
	return e.phase = "resolve", e.order = He(e), e.turn = 0, [{ kind: "reveal" }, ...Ke(e)];
}
function Qe(e, t, n) {
	let r = P[e.track], i = 0, a = {}, o = {}, s = Array.from({ length: e.legends }, (e, t) => `l${t}`), c = G([...t, ...s], n, i), l = c.deck;
	i = c.cursor;
	let u = e.garage;
	l.forEach((e, t) => {
		let c = s.indexOf(e);
		if (c >= 0) {
			o[e] = {
				pos: r.spaces - 1 - Math.floor(t / 2),
				spot: t % 2,
				finished: !1,
				color: ae[c]
			};
			return;
		}
		if (u === "off") {
			let o = G(De, n, i);
			i = o.cursor;
			let s = o.deck, c = s.splice(s.length - V);
			a[e] = {
				pos: r.spaces - 1 - Math.floor(t / 2),
				spot: t % 2,
				gear: 1,
				engine: r.heat - 1,
				deck: s,
				hand: c,
				discard: [],
				play: [],
				finished: !1,
				spunOut: !1,
				lastSpeed: 0
			};
		} else a[e] = {
			pos: r.spaces - 1 - Math.floor(t / 2),
			spot: t % 2,
			gear: 1,
			engine: r.heat,
			deck: [],
			hand: [],
			discard: [],
			play: [],
			finished: !1,
			spunOut: !1,
			lastSpeed: 0
		};
	});
	let d = null;
	if (u !== "off") {
		let e = G(u === "basic" ? we : Ee, n, i);
		i = e.cursor;
		let r = e.deck, a = l.filter((e) => t.includes(e));
		d = {
			pool: r,
			market: r.splice(0, t.length + 3),
			round: 0,
			order: [...a].reverse(),
			idx: 0,
			picks: Object.fromEntries(t.map((e) => [e, []]))
		};
	}
	let f = [];
	if (s.length) {
		let e = G(ce, n, i);
		i = e.cursor, f = e.deck;
	}
	let p = {
		players: t,
		track: e.track,
		garage: u,
		seed: n,
		round: 1,
		phase: d ? "draft" : "plan",
		cars: a,
		planned: {},
		order: [],
		turn: 0,
		cur: null,
		draft: d,
		gridOrder: l,
		legends: o,
		legendDeck: f,
		legendCard: null,
		hall: [],
		rngCursor: i,
		log: []
	};
	return d ? {
		state: p,
		fx: []
	} : {
		state: p,
		fx: t.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: { count: V },
			for: [e],
			secret: { cards: a[e].hand },
			...t > 0 ? { with: !0 } : {}
		}))
	};
}
function $e(e) {
	let t = e.draft;
	for (let n of e.players) {
		let r = e.cars[n], i = t.picks[n], a = G([...Oe, ...i], e.seed, e.rngCursor);
		e.rngCursor = a.cursor, r.deck = a.deck, r.engine = W(e).heat, Ve(e, r);
	}
	return e.draft = null, e.phase = "plan", Y(e, { k: "raceStart" }), e.players.map((t, n) => ({
		kind: "deal",
		rid: t,
		data: { count: V },
		for: [t],
		secret: { cards: e.cars[t].hand },
		...n > 0 ? { with: !0 } : {}
	}));
}
var Z = (e) => ({ code: e });
function et(e, t, n) {
	if (t.type === "draft") {
		let r = e.draft;
		if (e.phase !== "draft" || !r || r.order[r.idx] !== n.by) return Z("games.heat.errNotYourTurn");
		if (!r.market.includes(t.card)) return Z("games.heat.errBadCards");
		let i = structuredClone(e), a = i.draft;
		a.market.splice(a.market.indexOf(t.card), 1), a.picks[n.by].push(t.card), a.idx += 1;
		let o = [{
			kind: "draftPick",
			rid: n.by,
			data: {
				card: t.card,
				round: a.round
			}
		}];
		if (a.idx >= a.order.length) {
			if (a.round >= 2) return {
				state: i,
				fx: [...o, ...$e(i)]
			};
			a.round += 1, a.market = a.pool.splice(0, i.players.length + 3);
			let e = i.gridOrder.filter((e) => i.players.includes(e));
			a.order = a.round === 1 ? e : [...e].reverse(), a.idx = 0;
		}
		return {
			state: i,
			fx: o
		};
	}
	if (t.type === "plan") {
		if (e.phase !== "plan" || n.by in e.planned) return Z("games.heat.errNotYourTurn");
		let r = e.cars[n.by];
		if (!r || r.finished) return Z("games.heat.errNotYourTurn");
		let i = Math.abs(t.gear - r.gear);
		if (i > 2) return Z("games.heat.errBadGear");
		if (i === 2 && r.engine < 1) return Z("games.heat.errNoHeat");
		let a = [...r.hand], o = Math.min(t.gear, a.filter(U).length);
		if (t.cards.length !== o) return Z("games.heat.errBadCards");
		for (let e of t.cards) {
			let t = a.indexOf(e);
			if (t < 0 || !U(e)) return Z("games.heat.errBadCards");
			a.splice(t, 1);
		}
		let s = structuredClone(e), c = s.cars[n.by];
		i === 2 && (--c.engine, c.discard.push("h"), Y(s, {
			k: "shift2",
			rid: n.by
		})), c.gear = t.gear, c.hand = a, c.play = [...t.cards], s.planned[n.by] = !0;
		let l = s.players.filter((e) => !s.cars[e].finished).length;
		return Object.keys(s.planned).length === l ? {
			state: s,
			fx: Ze(s)
		} : {
			state: s,
			fx: []
		};
	}
	let r = e.cur;
	if (!r || e.phase !== "resolve" || r.rid !== n.by) return Z("games.heat.errNotYourTurn");
	if (t.type === "choice") {
		if (r.step !== "choice") return Z("games.heat.errBadStep");
		let i = e.cars[n.by];
		if (t.values.length !== r.choiceIdx.length) return Z("games.heat.errBadCards");
		for (let e = 0; e < r.choiceIdx.length; e += 1) {
			let n = i.play[r.choiceIdx[e]];
			if (!(z(n) ? B(n) : null)?.choice?.includes(t.values[e])) return Z("games.heat.errBadCards");
		}
		let a = structuredClone(e), o = a.cur;
		for (let e of t.values) o.speed += e;
		let s = We(a);
		return o.step = "react", {
			state: a,
			fx: s
		};
	}
	if (t.type === "react") {
		if (r.step !== "react") return Z("games.heat.errBadStep");
		let i = e.cars[n.by];
		if (t.adrSpeed && (!r.adr || r.adrSpeedUsed)) return Z("games.heat.errBadStep");
		if (t.boost && (r.boostUsed || i.engine < 1)) return Z("games.heat.errNoHeat");
		if (t.accel && !r.accelAvail) return Z("games.heat.errBadStep");
		let a = t.direct.reduce((e, t) => e + (z(t) ? B(t).cool ?? 0 : 0), 0), o = i.hand.filter(Ae).length;
		if (t.cool > r.cooldownLeft + a || t.cool > o) return Z("games.heat.errBadCool");
		if (t.stressOut.length > r.stressLeft) return Z("games.heat.errBadCards");
		{
			let e = [...i.hand];
			for (let n of t.stressOut) {
				let t = e.indexOf(n);
				if (t < 0 || !je(n)) return Z("games.heat.errBadCards");
				e.splice(t, 1);
			}
			for (let n of t.direct) {
				let t = e.indexOf(n);
				if (t < 0 || !z(n) || !B(n).direct) return Z("games.heat.errBadCards");
				e.splice(t, 1);
			}
		}
		if (t.salvage.length > r.salvageLeft) return Z("games.heat.errBadCards");
		{
			let e = [...i.discard];
			for (let n of t.salvage) {
				let t = e.indexOf(n);
				if (t < 0) return Z("games.heat.errBadCards");
				e.splice(t, 1);
			}
		}
		{
			let e = [...i.play];
			for (let n of t.refresh) {
				let t = e.indexOf(n);
				if (t < 0 || !z(n) || !B(n).refresh) return Z("games.heat.errBadCards");
				e.splice(t, 1);
			}
		}
		let s = structuredClone(e), c = s.cars[n.by], l = s.cur, u = [];
		if (t.adrSpeed && (l.adrSpeedUsed = !0, l.speed += 1, X(s, n.by, c.pos + 1)), t.boost) {
			l.boostUsed = !0, --c.engine, c.discard.push("h");
			let e = ze(s, c), t = H(e);
			l.speed += t, l.flips += 1, c.play.push(e), X(s, n.by, c.pos + t), Y(s, {
				k: "boost",
				rid: n.by,
				n: t
			}), u.push({
				kind: "boost",
				rid: n.by,
				data: { v: t }
			});
		}
		for (let e of t.direct) {
			c.hand.splice(c.hand.indexOf(e), 1);
			let t = B(e), r = t.v ?? 0;
			if (t.heat) {
				if (c.engine >= t.heat) {
					c.engine -= t.heat;
					for (let e = 0; e < t.heat; e += 1) c.discard.push("h");
				} else {
					c.discard.push(e);
					let t = ze(s, c);
					c.play.push(t), r = H(t), l.flips += 1, Y(s, {
						k: "heatFail",
						rid: n.by
					}), l.speed += r;
					let i = c.pos;
					X(s, n.by, i + r), u.push({
						kind: "move",
						rid: n.by,
						data: {
							from: i,
							to: c.pos,
							speed: r
						}
					});
					continue;
				}
			}
			c.play.push(e), t.scrap && Be(s, c, t.scrap), t.limit && (l.limitAdj += t.limit), l.slipBonus += t.slip ?? 0, l.stressLeft += t.stress ?? 0, l.salvageLeft += t.salvage ?? 0, l.cooldownLeft += t.cool ?? 0, t.accel && (l.accelAvail = !0), l.speed += r;
			let i = c.pos;
			X(s, n.by, i + r), Y(s, {
				k: "direct",
				rid: n.by,
				n: r
			}), u.push({
				kind: "move",
				rid: n.by,
				data: {
					from: i,
					to: c.pos,
					speed: r
				}
			});
		}
		if (t.accel && l.flips > 0) {
			l.speed += l.flips;
			let e = c.pos;
			X(s, n.by, e + l.flips), Y(s, {
				k: "accel",
				rid: n.by,
				n: l.flips
			}), u.push({
				kind: "move",
				rid: n.by,
				data: {
					from: e,
					to: c.pos,
					speed: l.flips
				}
			});
		}
		if (t.cool > 0) {
			let e = t.cool;
			c.hand = c.hand.filter((t) => e > 0 && Ae(t) ? (--e, !1) : !0), c.engine += t.cool, Y(s, {
				k: "cool",
				rid: n.by,
				n: t.cool
			});
		}
		for (let e of t.stressOut) c.hand.splice(c.hand.indexOf(e), 1), c.discard.push(e);
		if (t.stressOut.length && Y(s, {
			k: "stressOut",
			rid: n.by,
			n: t.stressOut.length
		}), t.salvage.length) {
			for (let e of t.salvage) c.discard.splice(c.discard.indexOf(e), 1), c.deck.push(e);
			let e = G(c.deck, s.seed, s.rngCursor);
			c.deck = e.deck, s.rngCursor = e.cursor, Y(s, {
				k: "salvage",
				rid: n.by,
				n: t.salvage.length
			});
		}
		for (let e of t.refresh) c.play.splice(c.play.indexOf(e), 1), c.deck.push(e);
		return c.lastSpeed = l.speed, l.checkedTo = c.pos, l.step = Je(s, n.by, 2 + l.slipBonus) ? "slip" : "discard", l.step === "discard" && u.push(...qe(s)), {
			state: s,
			fx: u
		};
	}
	if (t.type === "slip") {
		if (r.step !== "slip") return Z("games.heat.errBadStep");
		let i = structuredClone(e), a = [];
		if (t.take) {
			let e = i.cars[n.by], t = e.pos;
			X(i, n.by, t + 2 + i.cur.slipBonus), Y(i, {
				k: "slip",
				rid: n.by
			}), a.push({
				kind: "slip",
				rid: n.by,
				data: {
					from: t,
					to: e.pos
				}
			});
		}
		return i.cur.step = "discard", a.push(...qe(i)), {
			state: i,
			fx: a
		};
	}
	if (r.step !== "discard") return Z("games.heat.errBadStep");
	{
		let r = [...e.cars[n.by].hand];
		for (let e of t.cards) {
			let t = r.indexOf(e);
			if (t < 0 || !Ne(e)) return Z("games.heat.errBadCards");
			r.splice(t, 1);
		}
		let i = structuredClone(e), a = i.cars[n.by];
		return a.hand = r, a.discard.push(...t.cards), {
			state: i,
			fx: Xe(i)
		};
	}
}
function tt(e, t) {
	let n = {};
	for (let t of e.players) {
		let r = e.cars[t];
		n[t] = {
			pos: r.pos,
			spot: r.spot,
			gear: r.gear,
			engine: r.engine,
			deckCount: r.deck.length,
			handCount: r.hand.length,
			discardTop: r.discard.length ? r.discard[r.discard.length - 1] : null,
			play: e.phase === "plan" ? [] : [...r.play],
			planned: t in e.planned,
			finished: r.finished,
			spunOut: r.spunOut,
			lastSpeed: r.lastSpeed,
			hasAdr: e.cur?.rid === t && e.cur.adr
		};
	}
	let r = e.cars[t];
	return {
		public: {
			track: e.track,
			round: e.round,
			phase: e.phase,
			cars: n,
			legends: Object.fromEntries(Object.entries(e.legends).map(([e, t]) => [e, {
				pos: t.pos,
				spot: t.spot,
				finished: t.finished,
				color: t.color
			}])),
			legendCard: e.legendCard,
			order: e.order,
			turn: e.turn,
			current: e.cur ? {
				rid: e.cur.rid,
				step: e.cur.step,
				speed: e.cur.speed,
				cooldownLeft: e.cur.cooldownLeft,
				boostUsed: e.cur.boostUsed,
				adr: e.cur.adr,
				adrSpeedUsed: e.cur.adrSpeedUsed,
				flips: e.cur.flips,
				limitAdj: e.cur.limitAdj,
				slipBonus: e.cur.slipBonus,
				stressLeft: e.cur.stressLeft,
				salvageLeft: e.cur.salvageLeft,
				accelAvail: e.cur.accelAvail,
				choiceIdx: [...e.cur.choiceIdx]
			} : null,
			draft: e.draft ? {
				poolCount: e.draft.pool.length,
				market: [...e.draft.market],
				round: e.draft.round,
				order: [...e.draft.order],
				idx: e.draft.idx,
				picks: Object.fromEntries(e.players.map((t) => [t, [...e.draft.picks[t] ?? []]]))
			} : null,
			hall: e.hall,
			log: e.log
		},
		private: {
			hand: r?.hand ?? [],
			myPlanned: r && e.phase === "plan" && t in e.planned ? {
				gear: r.gear,
				cards: [...r.play]
			} : null,
			discard: r ? [...r.discard] : []
		}
	};
}
function nt(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.keys(e.legends).filter((t) => !e.legends[t].finished);
	t.sort((t, n) => e.legends[n].pos - e.legends[t].pos);
	let n = [...e.hall, ...t], r = {};
	for (let t of e.players) r[t] = e.cars[t].pos;
	for (let t of Object.keys(e.legends)) r[t] = e.legends[t].pos;
	return {
		phase: "done",
		winner: [e.hall[0]],
		ranking: n,
		scores: r
	};
}
var rt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: F,
	schemas: {
		action: me,
		publicView: R,
		privateView: ye,
		config: de
	},
	setup: Qe,
	reduce: et,
	viewFor: tt,
	status: nt
};
//#endregion
//#region src/games/heat/board3d.tsx
function it() {
	try {
		let e = document.createElement("canvas");
		return !!(e.getContext("webgl2") ?? e.getContext("webgl"));
	} catch {
		return !1;
	}
}
function Q(e, t, n = 0) {
	let r = (t % e.track.spaces + e.track.spaces) % e.track.spaces / e.track.spaces, i = e.curve.getPoint(r), a = e.curve.getTangent(r).normalize(), o = new T(-a.z, 0, a.x);
	return {
		p: i.addScaledVector(o, n * .3),
		tangent: a,
		side: o
	};
}
function at(e, t, n) {
	let r = [], i = [], a = e.track.spaces * 8;
	for (let o = 0; o < a; o++) {
		let s = o / a, c = (o + 1) / a, l = e.curve.getPoint(s), u = e.curve.getPoint(c), d = e.curve.getTangent(s).normalize(), f = e.curve.getTangent(c).normalize(), p = new T(-d.z, 0, d.x), m = new T(-f.z, 0, f.x), h = l.clone().addScaledVector(p, -t / 2), g = l.clone().addScaledVector(p, t / 2), _ = u.clone().addScaledVector(m, -t / 2), v = u.clone().addScaledVector(m, t / 2);
		r.push(h.x, n, h.z, g.x, n, g.z, _.x, n, _.z), r.push(g.x, n, g.z, v.x, n, v.z, _.x, n, _.z), i.push(0, s * 12, 1, s * 12, 0, c * 12), i.push(1, s * 12, 1, c * 12, 0, c * 12);
	}
	let o = new g();
	return o.setAttribute("position", new x(r, 3)), o.setAttribute("uv", new x(i, 2)), o.computeVertexNormals(), o;
}
function ot() {
	let e = document.createElement("canvas");
	e.width = e.height = 256;
	let t = e.getContext("2d");
	t.fillStyle = "#b9bdbe", t.fillRect(0, 0, 256, 256);
	for (let e = 0; e < 5200; e++) {
		let n = (e * 101 + e * e * 17) % 256, r = (e * 233 + e * e * 19) % 256;
		t.fillStyle = e % 4 ? "#a4a9ab" : "#d4d5d2", t.globalAlpha = e % 5 ? .25 : .48, t.fillRect(n, r, e % 7 ? 1 : 2, 1);
	}
	t.globalAlpha = 1;
	let n = new _(e);
	return n.colorSpace = ee, n.wrapS = n.wrapT = C, n.anisotropy = 4, n;
}
function st() {
	let e = document.createElement("canvas");
	e.width = e.height = 128;
	let t = e.getContext("2d"), n = t.createRadialGradient(64, 64, 5, 64, 64, 63);
	return n.addColorStop(0, "rgba(12, 14, 15, 0.58)"), n.addColorStop(.38, "rgba(12, 14, 15, 0.34)"), n.addColorStop(1, "rgba(12, 14, 15, 0)"), t.fillStyle = n, t.fillRect(0, 0, 128, 128), new _(e);
}
function ct(e, t, n, r, i, a, o) {
	let s = e.curve.getPoint(n), c = e.curve.getPoint(r), l = e.curve.getTangent(n).normalize(), u = e.curve.getTangent(r).normalize(), d = new T(-l.z, 0, l.x), f = new T(-u.z, 0, u.x), p = s.clone().addScaledVector(d, i - a / 2), m = s.clone().addScaledVector(d, i + a / 2), h = c.clone().addScaledVector(f, i - a / 2), g = c.clone().addScaledVector(f, i + a / 2);
	t.push(p.x, o, p.z, m.x, o, m.z, h.x, o, h.z), t.push(m.x, o, m.z, g.x, o, g.z, h.x, o, h.z);
}
function lt(e) {
	let t = new g();
	return t.setAttribute("position", new x(e, 3)), t;
}
function ut({ course: e }) {
	let t = r(() => ot(), []);
	n(() => () => t.dispose(), [t]);
	let i = r(() => {
		let t = [], n = [], r = [], i = [], a = [], o = e.track.spaces;
		for (let r = 0; r < o * 4; r++) {
			let i = r / (o * 4), a = (r + .96) / (o * 4);
			for (let o of [-1, 1]) ct(e, r % 2 ? t : n, i, a, o * .77, .12, .07);
		}
		for (let t = 0; t < o * 2; t += 2) ct(e, r, (t + .15) / (o * 2), (t + .85) / (o * 2), 0, .023, .07);
		for (let t = 0; t < o * 2; t++) {
			let n = (t + .05) / (o * 2), r = (t + .85) / (o * 2);
			ct(e, i, n, r, -.3, .045, .064), ct(e, i, n, r, .3, .045, .064);
		}
		for (let t = 0; t < o; t++) {
			let { p: n, side: r } = Q(e, t + .5), i = n.clone().addScaledVector(r, -.69), o = n.clone().addScaledVector(r, .69);
			a.push(i.x, .071, i.z, o.x, .071, o.z);
		}
		return {
			base: at(e, 1.91, .024),
			shoulder: at(e, 1.77, .037),
			asphalt: at(e, 1.55, .048),
			red: lt(t),
			cream: lt(n),
			middle: lt(r),
			tire: lt(i),
			grid: lt(a)
		};
	}, [e]);
	return /* @__PURE__ */ O(E, { children: [
		/* @__PURE__ */ D("mesh", {
			geometry: i.base,
			children: /* @__PURE__ */ D("meshBasicMaterial", {
				color: "#3b3027",
				side: y
			})
		}),
		/* @__PURE__ */ D("mesh", {
			geometry: i.shoulder,
			children: /* @__PURE__ */ D("meshBasicMaterial", {
				color: "#f2dfbd",
				side: y
			})
		}),
		/* @__PURE__ */ D("mesh", {
			geometry: i.asphalt,
			children: /* @__PURE__ */ D("meshStandardMaterial", {
				color: "#5b6266",
				map: t,
				roughness: 1,
				metalness: .02,
				side: y
			})
		}),
		/* @__PURE__ */ D("mesh", {
			geometry: i.red,
			children: /* @__PURE__ */ D("meshBasicMaterial", {
				color: "#d74733",
				side: y
			})
		}),
		/* @__PURE__ */ D("mesh", {
			geometry: i.cream,
			children: /* @__PURE__ */ D("meshBasicMaterial", {
				color: "#fff1d8",
				side: y
			})
		}),
		/* @__PURE__ */ D("mesh", {
			geometry: i.tire,
			children: /* @__PURE__ */ D("meshBasicMaterial", {
				color: "#171c20",
				transparent: !0,
				opacity: .42,
				side: y
			})
		}),
		/* @__PURE__ */ D("mesh", {
			geometry: i.middle,
			children: /* @__PURE__ */ D("meshBasicMaterial", {
				color: "#f4ddae",
				side: y
			})
		}),
		/* @__PURE__ */ D("lineSegments", {
			geometry: i.grid,
			children: /* @__PURE__ */ D("lineBasicMaterial", {
				color: "#cbd1d0",
				transparent: !0,
				opacity: .48
			})
		})
	] });
}
var dt = {
	usa: {
		edge: "#a95e39",
		rock: "#ad6347",
		plants: ["#6d8058", "#899565"],
		relief: .75
	},
	ita: {
		edge: "#b99b6d",
		rock: "#b78261",
		plants: ["#47745b", "#69906b"],
		relief: .58
	},
	fra: {
		edge: "#9faa71",
		rock: "#b99b71",
		plants: ["#577f52", "#7a9a5c"],
		relief: .35
	},
	gbr: {
		edge: "#55785e",
		rock: "#83918b",
		plants: ["#315a48", "#52745b"],
		relief: .45
	}
};
function ft({ course: e, trackId: t }) {
	let i = p(w, `./games/heat/terrain-${t}.webp`), a = r(() => {
		let e = i.clone();
		return e.colorSpace = ee, e.anisotropy = 8, e.needsUpdate = !0, e;
	}, [i]), o = r(() => {
		let n = new S(53.33, 35.56, 100, 68);
		n.rotateX(-Math.PI / 2);
		let r = n.getAttribute("position"), i = e.curve.getPoints(e.track.spaces * 5);
		for (let e = 0; e < r.count; e++) {
			let n = r.getX(e), a = r.getZ(e), o = Infinity;
			for (let e of i) o = Math.min(o, (n - e.x) ** 2 + (a - e.z) ** 2);
			let s = Math.max(0, Math.min(1, (Math.sqrt(o) - 1.4) / 3.5)), c = .48 + .24 * Math.sin(n * .48 + a * .18) + .22 * Math.cos(a * .62 - n * .14);
			r.setY(e, -.08 + s * dt[t].relief * Math.max(0, c));
		}
		return n.computeVertexNormals(), n;
	}, [e, t]);
	return n(() => () => {
		o.dispose(), a.dispose();
	}, [o, a]), /* @__PURE__ */ D("mesh", {
		geometry: o,
		children: /* @__PURE__ */ D("meshStandardMaterial", {
			map: a,
			roughness: 1,
			metalness: 0
		})
	});
}
function pt(e) {
	let t = document.createElement("canvas");
	t.width = t.height = 128;
	let n = t.getContext("2d");
	return n.fillStyle = "#fff9e9", n.strokeStyle = "#292622", n.lineWidth = 9, n.beginPath(), n.arc(64, 64, 50, 0, Math.PI * 2), n.fill(), n.stroke(), n.fillStyle = "#292622", n.font = "900 68px system-ui", n.textAlign = "center", n.textBaseline = "middle", n.fillText(e, 64, 65), new _(t);
}
function mt({ course: e, at: t, limit: n }) {
	let i = r(() => pt(String(n)), [n]), { p: a, side: o } = Q(e, t), s = a.addScaledVector(o, 1.5);
	return /* @__PURE__ */ O("group", {
		position: [
			s.x,
			0,
			s.z
		],
		children: [/* @__PURE__ */ O("mesh", {
			position: [
				0,
				.42,
				0
			],
			children: [/* @__PURE__ */ D("cylinderGeometry", { args: [
				.035,
				.035,
				.84,
				6
			] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#4b4034" })]
		}), /* @__PURE__ */ D("sprite", {
			position: [
				0,
				1.03,
				0
			],
			scale: [
				.82,
				.82,
				1
			],
			children: /* @__PURE__ */ D("spriteMaterial", {
				map: i,
				transparent: !0,
				depthTest: !1
			})
		})]
	});
}
function ht(e, t, n) {
	let r = new te();
	e.forEach(([e, t], n) => n === 0 ? r.moveTo(e, -t) : r.lineTo(e, -t)), r.closePath();
	let i = new b(r, {
		depth: n,
		steps: 1,
		bevelEnabled: !0,
		bevelThickness: .018,
		bevelSize: .018,
		bevelSegments: 1
	});
	return i.rotateX(-Math.PI / 2), i.translate(0, t, 0), i;
}
var gt = ht([
	[-.24, -.47],
	[.24, -.47],
	[.28, -.21],
	[.19, .08],
	[.13, .49],
	[0, .57],
	[-.13, .49],
	[-.19, .08],
	[-.28, -.21]
], .03, .15), _t = ht([
	[-.07, .1],
	[.07, .1],
	[.07, .47],
	[0, .53],
	[-.07, .47]
], .201, .009);
function vt({ course: e, car: t, reduced: r, positions: a, shadow: o }) {
	let { hidden: c } = s(`car:${t.rid}`), { invalidate: u } = m(), d = i(null), p = i({
		pos: t.pos,
		spot: t.spot
	}), h = t.hex ?? l[t.colorIndex % l.length].hex;
	n(() => {
		u();
	}, [
		t.pos,
		t.spot,
		c,
		u
	]), n(() => () => {
		a.delete(t.rid);
	}, [t.rid, a]), f((n, i) => {
		let o = p.current, s = r ? 1 : 1 - Math.exp(-Math.min(i, .05) * 8);
		o.pos += (t.pos - o.pos) * s, o.spot += (t.spot - o.spot) * s, a.set(t.rid, {
			pos: o.pos,
			spot: o.spot
		});
		let { p: c, tangent: l } = Q(e, o.pos, o.spot === 0 ? -1 : o.spot === 1 ? 1 : (o.spot - .5) * 2);
		d.current && (d.current.position.set(c.x, .18, c.z), d.current.rotation.y = Math.atan2(l.x, l.z)), (Math.abs(t.pos - o.pos) > .01 || Math.abs(t.spot - o.spot) > .01) && u();
	});
	let g = Q(e, t.pos, t.spot === 0 ? -1 : 1);
	return /* @__PURE__ */ O("group", {
		ref: d,
		visible: !c,
		position: [
			g.p.x,
			.18,
			g.p.z
		],
		rotation: [
			0,
			Math.atan2(g.tangent.x, g.tangent.z),
			0
		],
		children: [
			/* @__PURE__ */ O("mesh", {
				position: [
					0,
					-.105,
					0
				],
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ D("planeGeometry", { args: [1.34, 1.95] }), /* @__PURE__ */ D("meshBasicMaterial", {
					map: o,
					transparent: !0,
					depthWrite: !1
				})]
			}),
			t.active && /* @__PURE__ */ O("mesh", {
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				position: [
					0,
					-.101,
					0
				],
				children: [/* @__PURE__ */ D("ringGeometry", { args: [
					.46,
					.52,
					32
				] }), /* @__PURE__ */ D("meshBasicMaterial", {
					color: "#f8d15b",
					side: y
				})]
			}),
			/* @__PURE__ */ D("mesh", {
				geometry: gt,
				children: /* @__PURE__ */ D("meshStandardMaterial", {
					color: h,
					flatShading: !0,
					roughness: .33,
					metalness: .12,
					transparent: !0,
					opacity: t.finished ? .6 : 1
				})
			}),
			/* @__PURE__ */ D("mesh", {
				geometry: _t,
				children: /* @__PURE__ */ D("meshBasicMaterial", { color: "#fff2d4" })
			}),
			[-1, 1].map((e) => /* @__PURE__ */ O("group", { children: [
				/* @__PURE__ */ O("mesh", {
					position: [
						e * .25,
						.12,
						-.18
					],
					children: [/* @__PURE__ */ D("boxGeometry", { args: [
						.18,
						.12,
						.35
					] }), /* @__PURE__ */ D("meshStandardMaterial", {
						color: h,
						flatShading: !0,
						roughness: .33,
						metalness: .12
					})]
				}),
				/* @__PURE__ */ O("mesh", {
					position: [
						e * .3,
						.04,
						.2
					],
					rotation: [
						0,
						e * .25,
						0
					],
					children: [/* @__PURE__ */ D("boxGeometry", { args: [
						.27,
						.035,
						.035
					] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#303336" })]
				}),
				/* @__PURE__ */ O("mesh", {
					position: [
						e * .3,
						.07,
						-.27
					],
					rotation: [
						0,
						-e * .2,
						0
					],
					children: [/* @__PURE__ */ D("boxGeometry", { args: [
						.22,
						.035,
						.035
					] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#303336" })]
				}),
				[-1, 1].map((t) => /* @__PURE__ */ O("group", {
					position: [
						e * .36,
						.05,
						t * .32
					],
					rotation: [
						0,
						0,
						Math.PI / 2
					],
					children: [/* @__PURE__ */ O("mesh", { children: [/* @__PURE__ */ D("cylinderGeometry", { args: [
						.125,
						.125,
						.15,
						10
					] }), /* @__PURE__ */ D("meshStandardMaterial", {
						color: "#171a1b",
						flatShading: !0,
						roughness: 1
					})] }), /* @__PURE__ */ O("mesh", {
						position: [
							0,
							e * .083,
							0
						],
						children: [/* @__PURE__ */ D("cylinderGeometry", { args: [
							.057,
							.057,
							.006,
							10
						] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#c9bba0" })]
					})]
				}, t))
			] }, e)),
			/* @__PURE__ */ O("mesh", {
				position: [
					0,
					.2,
					-.12
				],
				scale: [
					1,
					.4,
					1.3
				],
				children: [/* @__PURE__ */ D("sphereGeometry", { args: [
					.18,
					10,
					6
				] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#20272b" })]
			}),
			/* @__PURE__ */ O("mesh", {
				position: [
					0,
					.26,
					-.14
				],
				children: [/* @__PURE__ */ D("sphereGeometry", { args: [
					.105,
					10,
					8
				] }), /* @__PURE__ */ D("meshStandardMaterial", {
					color: "#f7e5bd",
					flatShading: !0,
					roughness: .7
				})]
			}),
			/* @__PURE__ */ O("mesh", {
				position: [
					0,
					.29,
					-.065
				],
				scale: [
					1,
					.5,
					.55
				],
				children: [/* @__PURE__ */ D("sphereGeometry", { args: [
					.09,
					10,
					6
				] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#27343a" })]
			}),
			/* @__PURE__ */ O("mesh", {
				position: [
					0,
					.075,
					.47
				],
				children: [/* @__PURE__ */ D("boxGeometry", { args: [
					.78,
					.055,
					.12
				] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#25282a" })]
			}),
			/* @__PURE__ */ O("mesh", {
				position: [
					0,
					.108,
					.47
				],
				children: [/* @__PURE__ */ D("boxGeometry", { args: [
					.68,
					.015,
					.095
				] }), /* @__PURE__ */ D("meshStandardMaterial", {
					color: h,
					roughness: .3,
					metalness: .12
				})]
			}),
			[-1, 1].map((e) => /* @__PURE__ */ O("mesh", {
				position: [
					e * .31,
					.105,
					.47
				],
				children: [/* @__PURE__ */ D("boxGeometry", { args: [
					.13,
					.04,
					.13
				] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#fff0d2" })]
			}, e)),
			/* @__PURE__ */ O("mesh", {
				position: [
					0,
					.31,
					-.47
				],
				children: [/* @__PURE__ */ D("boxGeometry", { args: [
					.74,
					.075,
					.13
				] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#282b2b" })]
			}),
			/* @__PURE__ */ O("mesh", {
				position: [
					0,
					.354,
					-.47
				],
				children: [/* @__PURE__ */ D("boxGeometry", { args: [
					.68,
					.012,
					.09
				] }), /* @__PURE__ */ D("meshStandardMaterial", {
					color: h,
					roughness: .3,
					metalness: .12
				})]
			})
		]
	});
}
function yt({ course: e, space: t }) {
	let { p: n, tangent: r, side: i } = Q(e, t), a = n.addScaledVector(i, -2.6);
	return /* @__PURE__ */ O("group", {
		position: [
			a.x,
			0,
			a.z
		],
		rotation: [
			0,
			Math.atan2(r.x, r.z),
			0
		],
		scale: .7,
		children: [
			/* @__PURE__ */ O("mesh", {
				position: [
					0,
					.1,
					0
				],
				children: [/* @__PURE__ */ D("boxGeometry", { args: [
					1.8,
					.2,
					2.8
				] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#514b42" })]
			}),
			[
				0,
				1,
				2
			].map((e) => /* @__PURE__ */ O("group", {
				position: [
					-.42 + e * .37,
					.27 + e * .18,
					0
				],
				children: [/* @__PURE__ */ O("mesh", { children: [/* @__PURE__ */ D("boxGeometry", { args: [
					.38,
					.17,
					2.75
				] }), /* @__PURE__ */ D("meshBasicMaterial", { color: e % 2 ? "#dbd1bb" : "#f5e9cf" })] }), [
					-1.05,
					-.52,
					0,
					.52,
					1.05
				].map((t, n) => /* @__PURE__ */ O("mesh", {
					position: [
						0,
						.17,
						t
					],
					children: [/* @__PURE__ */ D("icosahedronGeometry", { args: [.12, 0] }), /* @__PURE__ */ D("meshBasicMaterial", { color: [
						"#b74b34",
						"#3d7182",
						"#e0aa49",
						"#668263",
						"#d5d0bb"
					][(e + n) % 5] })]
				}, n))]
			}, e)),
			/* @__PURE__ */ O("mesh", {
				position: [
					.3,
					1.27,
					0
				],
				rotation: [
					0,
					0,
					-.12
				],
				children: [/* @__PURE__ */ D("boxGeometry", { args: [
					1.95,
					.12,
					3.05
				] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#efe0bf" })]
			}),
			/* @__PURE__ */ O("mesh", {
				position: [
					.3,
					1.34,
					0
				],
				rotation: [
					0,
					0,
					-.12
				],
				children: [/* @__PURE__ */ D("boxGeometry", { args: [
					.22,
					.02,
					3.08
				] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#c74332" })]
			})
		]
	});
}
function bt({ course: e, start: t }) {
	let n = r(() => Array.from({ length: 10 }, (n, r) => {
		let i = Q(e, t + r).p.addScaledVector(Q(e, t + r).side, -1.14), a = Q(e, t + r + .9).p.addScaledVector(Q(e, t + r + .9).side, -1.14), o = a.x - i.x, s = a.z - i.z;
		return {
			x: (i.x + a.x) / 2,
			z: (i.z + a.z) / 2,
			yaw: Math.atan2(o, s),
			length: Math.hypot(o, s),
			post: i
		};
	}), [e, t]);
	return /* @__PURE__ */ D(E, { children: n.map((e, t) => /* @__PURE__ */ O("group", { children: [
		/* @__PURE__ */ O("mesh", {
			position: [
				e.x,
				.27,
				e.z
			],
			rotation: [
				0,
				e.yaw,
				0
			],
			children: [/* @__PURE__ */ D("boxGeometry", { args: [
				.09,
				.13,
				e.length
			] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#e9e0c8" })]
		}),
		/* @__PURE__ */ O("mesh", {
			position: [
				e.x,
				.31,
				e.z
			],
			rotation: [
				0,
				e.yaw,
				0
			],
			children: [/* @__PURE__ */ D("boxGeometry", { args: [
				.095,
				.03,
				e.length
			] }), /* @__PURE__ */ D("meshBasicMaterial", { color: t % 3 ? "#c53d2f" : "#30343a" })]
		}),
		/* @__PURE__ */ O("mesh", {
			position: [
				e.post.x,
				.15,
				e.post.z
			],
			children: [/* @__PURE__ */ D("boxGeometry", { args: [
				.1,
				.3,
				.1
			] }), /* @__PURE__ */ D("meshBasicMaterial", { color: "#6b665e" })]
		})
	] }, t)) });
}
function xt({ course: e, trackId: t }) {
	let n = dt[t], i = r(() => Array.from({ length: 30 }, (t, n) => {
		let { p: r, side: i } = Q(e, (n * 7 + 2) % e.track.spaces);
		return {
			pos: r.addScaledVector(i, (n % 2 ? 1 : -1) * (2.5 + n % 4 * .7)),
			size: .16 + n % 3 * .1
		};
	}), [e]);
	return /* @__PURE__ */ O(E, { children: [
		/* @__PURE__ */ D(bt, {
			course: e,
			start: 5
		}),
		/* @__PURE__ */ D(bt, {
			course: e,
			start: Math.floor(e.track.spaces / 2)
		}),
		/* @__PURE__ */ D(yt, {
			course: e,
			space: 11
		}),
		/* @__PURE__ */ D(yt, {
			course: e,
			space: Math.floor(e.track.spaces / 2) + 6
		}),
		i.map((e, t) => /* @__PURE__ */ O("mesh", {
			position: [
				e.pos.x,
				e.size * .5,
				e.pos.z
			],
			scale: [
				1.5,
				.75,
				1
			],
			children: [/* @__PURE__ */ D("icosahedronGeometry", { args: [e.size, 0] }), /* @__PURE__ */ D("meshBasicMaterial", { color: t % 3 ? n.rock : n.edge })]
		}, t)),
		Array.from({ length: 5 }, (r, i) => {
			let { p: a, side: o } = Q(e, (i * 11 + 8) % e.track.spaces), s = a.addScaledVector(o, i % 2 ? 3.5 : -3.5);
			return /* @__PURE__ */ O("group", {
				position: [
					s.x,
					0,
					s.z
				],
				scale: .85 + i % 2 * .2,
				children: [/* @__PURE__ */ O("mesh", {
					position: [
						0,
						.36,
						0
					],
					children: [/* @__PURE__ */ D("cylinderGeometry", { args: [
						.1,
						.15,
						.72,
						6
					] }), /* @__PURE__ */ D("meshStandardMaterial", {
						color: n.plants[0],
						flatShading: !0,
						roughness: 1
					})]
				}), t === "usa" ? /* @__PURE__ */ O(E, { children: [/* @__PURE__ */ O("mesh", {
					position: [
						.18,
						.48,
						0
					],
					rotation: [
						0,
						0,
						-.7
					],
					children: [/* @__PURE__ */ D("cylinderGeometry", { args: [
						.07,
						.07,
						.44,
						6
					] }), /* @__PURE__ */ D("meshBasicMaterial", { color: n.plants[1] })]
				}), /* @__PURE__ */ O("mesh", {
					position: [
						.32,
						.66,
						0
					],
					children: [/* @__PURE__ */ D("cylinderGeometry", { args: [
						.06,
						.06,
						.35,
						6
					] }), /* @__PURE__ */ D("meshBasicMaterial", { color: n.plants[1] })]
				})] }) : /* @__PURE__ */ O(E, { children: [/* @__PURE__ */ O("mesh", {
					position: [
						0,
						.76,
						0
					],
					children: [/* @__PURE__ */ D("coneGeometry", { args: [
						t === "ita" ? .13 : .2,
						t === "ita" ? .85 : .35,
						6
					] }), /* @__PURE__ */ D("meshBasicMaterial", { color: n.plants[0] })]
				}), /* @__PURE__ */ O("mesh", {
					position: [
						.18,
						.37,
						0
					],
					rotation: [
						0,
						0,
						-.8
					],
					children: [/* @__PURE__ */ D("cylinderGeometry", { args: [
						.06,
						.07,
						.38,
						6
					] }), /* @__PURE__ */ D("meshBasicMaterial", { color: n.plants[1] })]
				})] })]
			}, i);
		})
	] });
}
function St(e, t, n, r, i, a, o) {
	let s = new T(Infinity, Infinity, Infinity), c = new T(-Infinity, -Infinity, -Infinity);
	for (let t of e) s.min(t), c.max(t);
	let l = o?.clone() ?? s.add(c).multiplyScalar(.5), u = t.clone().negate(), d = new T().crossVectors(u, new T(0, 1, 0)).normalize(), f = new T().crossVectors(d, u).normalize(), p = Math.tan(44 * Math.PI / 360), m = p * Math.max(.35, n / Math.max(1, r)), h = a;
	for (let n of e) {
		let e = n.clone().sub(l);
		h = Math.max(h, e.dot(t) + i * Math.max(Math.abs(e.dot(d)) / m, Math.abs(e.dot(f)) / p));
	}
	return {
		pos: l.clone().addScaledVector(t, h),
		look: l
	};
}
function Ct({ course: e, cars: t, mode: a, focusPos: o, ownPos: s, bendAt: c, reset: l, reduced: u, rigRef: d }) {
	let { camera: p, gl: h, size: g, invalidate: _ } = m(), v = i(new T()), y = i(!1), b = i(null), x = i(new T());
	n(() => {
		b.current = null, _();
	}, [
		a,
		l,
		_
	]), n(() => {
		let e = () => {
			if (b.current) return b.current;
			let e = p.position.clone().sub(v.current), t = Math.max(1, e.length());
			x.current.copy(v.current);
			let n = Math.atan2(e.x, e.z);
			return b.current = {
				target: v.current.clone(),
				azimuth: n,
				polar: Math.acos(Math.max(-1, Math.min(1, e.y / t))),
				distance: t,
				heading: n
			}, b.current;
		};
		return d.current = {
			camera: p,
			canvas: h.domElement,
			rotate: (t, n) => {
				let r = e();
				r.azimuth -= t * .006, r.polar = Math.max(.14, Math.min(1.32, r.polar - n * .006)), _();
			},
			pan: (t, n) => {
				let r = e(), i = r.distance * 2 * Math.tan(44 * Math.PI / 360) / Math.max(1, g.height), a = new T(1, 0, 0).applyQuaternion(p.quaternion).setY(0).normalize(), o = new T(0, 1, 0).applyQuaternion(p.quaternion).setY(0).normalize();
				r.target.addScaledVector(a, -t * i).addScaledVector(o, n * i), _();
			},
			zoom: (t) => {
				let n = e();
				n.distance = Math.max(3.5, Math.min(85, n.distance / t)), _();
			}
		}, () => {
			d.current = null;
		};
	}, [
		p,
		h,
		_,
		d,
		g.height
	]);
	let S = r(() => {
		if (a === "overview") return St(Array.from({ length: e.track.spaces * 2 }, (t, n) => [Q(e, n / 2, -4).p, Q(e, n / 2, 4).p]).flat(), new T(0, 1, .001).normalize(), g.width, g.height, 1.42, 25);
		let { tangent: n, side: r } = Q(e, a === "bend" ? s : o), i = a === "bend" ? n.clone().multiplyScalar(-1).addScaledVector(r, .14).setY(.68).normalize() : n.clone().multiplyScalar(-.66).addScaledVector(r, .32).setY(1.55).normalize(), l = [];
		if (a === "car") {
			for (let n of t) l.push(Q(e, n.pos, n.spot === 0 ? -1 : 1).p.setY(.5));
			for (let t = 0; t <= 5; t++) l.push(Q(e, o + t).p.setY(.2));
		} else {
			let t = ((c - s) % e.track.spaces + e.track.spaces) % e.track.spaces || e.track.spaces;
			for (let n = 0; n <= Math.ceil(t); n += Math.max(1, Math.floor(t / 10))) l.push(Q(e, s + Math.min(n, t)).p.setY(.2));
			l.push(Q(e, s, -1).p.setY(.5), Q(e, s, 1).p.setY(.5)), l.push(Q(e, c, -1).p.setY(.2), Q(e, c, 1).p.setY(.2));
			let n = Q(e, c);
			l.push(n.p.addScaledVector(n.side, 1.5).setY(1.45));
		}
		let u = g.height < 260 ? 1.52 : 1.37;
		if (a === "car") {
			let t = Q(e, o + 1.5).p.setY(.32);
			return St(l, i, g.width, g.height, u, 10.5, t);
		}
		let d = Q(e, s).p.addScaledVector(n, 1.4).setY(.32);
		return St(l, i, g.width, g.height, u, 11, d);
	}, [
		e,
		t,
		a,
		o,
		s,
		c,
		g.width,
		g.height
	]);
	return n(() => {
		_();
	}, [S, _]), f((e, t) => {
		let n = b.current;
		if (n) {
			let e = u ? 1 : 1 - Math.exp(-Math.min(t, .05) * 8), r = x.current.clone();
			x.current.lerp(S.look, e), n.target.add(x.current.clone().sub(r));
			let i = S.pos.clone().sub(S.look), a = Math.atan2(i.x, i.z), o = Math.atan2(Math.sin(a - n.heading), Math.cos(a - n.heading));
			n.azimuth += o * e, n.heading += o * e;
			let s = Math.sin(n.polar);
			p.position.set(n.target.x + n.distance * s * Math.sin(n.azimuth), n.target.y + n.distance * Math.cos(n.polar), n.target.z + n.distance * s * Math.cos(n.azimuth)), v.current.copy(n.target), p.lookAt(v.current), (x.current.distanceToSquared(S.look) > 5e-4 || Math.abs(o) > .001) && _();
			return;
		}
		let r = !y.current || u ? 1 : 1 - Math.exp(-Math.min(t, .05) * 8);
		p.position.lerp(S.pos, r), v.current.lerp(S.look, r), y.current = !0, p.lookAt(v.current), (p.position.distanceToSquared(S.pos) > 5e-4 || v.current.distanceToSquared(S.look) > 5e-4) && _();
	}), null;
}
var $ = new T(), wt = new T();
function Tt({ trackId: e, track: t, cars: s, mode: l, focusRid: u, ownRid: d, bendAt: f, reset: p }) {
	let m = o(), g = dt[e], _ = ne(), y = r(() => st(), []);
	n(() => () => y.dispose(), [y]);
	let b = c(), x = i(null), [S] = a(() => ({
		track: t,
		curve: new v(t.pts.map(([e, t]) => new T((e - 600) / 45, 0, (t - 400) / 45)), !0, "catmullrom", .25)
	})), [C] = a(() => /* @__PURE__ */ new Map()), ee = s.find((e) => e.rid === u)?.pos ?? s[0]?.pos ?? 0, te = s.find((e) => e.rid === d)?.pos ?? ee, w = i(/* @__PURE__ */ new Map()), E = (e) => {
		e.currentTarget.setPointerCapture(e.pointerId), w.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, k = (e) => {
		let t = w.current.get(e.pointerId);
		if (!t) return;
		let n = {
			x: e.clientX,
			y: e.clientY
		};
		if (w.current.size === 1) x.current?.rotate(n.x - t.x, n.y - t.y);
		else {
			let r = [...w.current.entries()].find(([t]) => t !== e.pointerId)?.[1];
			if (r) {
				x.current?.pan((n.x - t.x) / 2, (n.y - t.y) / 2);
				let e = Math.hypot(t.x - r.x, t.y - r.y), i = Math.hypot(n.x - r.x, n.y - r.y);
				e > 4 && i > 4 && x.current?.zoom(i / e);
			}
		}
		w.current.set(e.pointerId, n);
	}, A = (e) => {
		w.current.delete(e.pointerId), e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId);
	}, j = s.map((e) => e.rid).join("|");
	return n(() => {
		if (!b) return;
		let e = j ? j.split("|") : [], t = (e) => {
			let t = x.current, n = s.find((t) => t.rid === e);
			if (!t || !n) return null;
			let r = C.get(e), { p: i } = Q(S, r?.pos ?? n.pos, r ? (r.spot - .5) * 2 : n.spot === 0 ? -1 : 1);
			if ($.set(i.x, .45, i.z).project(t.camera), wt.set(i.x + .7, .45, i.z).project(t.camera), $.z < -1 || $.z > 1 || Math.abs($.x) > 1 || Math.abs($.y) > 1) return null;
			let a = t.canvas.getBoundingClientRect(), o = Math.max(8, Math.abs(wt.x - $.x) * a.width / 2);
			return {
				x: a.left + ($.x + 1) * a.width / 2 - o,
				y: a.top + (1 - $.y) * a.height / 2 - o,
				w: o * 2,
				h: o * 2
			};
		};
		for (let n of e) b.registerProbe(`car:${n}`, () => t(n));
		return () => {
			for (let t of e) b.registerProbe(`car:${t}`, null);
		};
	}, [
		b,
		j,
		s,
		S,
		C
	]), /* @__PURE__ */ D("div", {
		className: "heat-board-3d",
		onPointerDown: E,
		onPointerMove: k,
		onPointerUp: A,
		onPointerCancel: A,
		children: /* @__PURE__ */ O(h, {
			recoveryFallback: /* @__PURE__ */ D("div", {
				className: "grid size-full place-items-center bg-ink px-6 text-center text-sm font-bold text-white",
				role: "status",
				children: m("games.heat.graphicsUnavailable")
			}),
			dpr: [1, 2],
			frameloop: "demand",
			camera: {
				fov: 44,
				near: .1,
				far: 170
			},
			gl: {
				antialias: !0,
				powerPreference: "low-power"
			},
			children: [
				/* @__PURE__ */ D("color", {
					attach: "background",
					args: [g.edge]
				}),
				/* @__PURE__ */ D("ambientLight", { intensity: .22 }),
				/* @__PURE__ */ D("hemisphereLight", { args: [
					"#fff0d6",
					"#806d65",
					.75
				] }),
				/* @__PURE__ */ D("directionalLight", {
					position: [
						-6,
						9,
						5
					],
					intensity: 2.15,
					color: "#ffe7bd"
				}),
				/* @__PURE__ */ D("directionalLight", {
					position: [
						6,
						3,
						-5
					],
					intensity: .38,
					color: "#c7e0ed"
				}),
				/* @__PURE__ */ O("mesh", {
					rotation: [
						-Math.PI / 2,
						0,
						0
					],
					position: [
						0,
						-.22,
						0
					],
					children: [/* @__PURE__ */ D("planeGeometry", { args: [180, 180] }), /* @__PURE__ */ D("meshBasicMaterial", { color: g.edge })]
				}),
				/* @__PURE__ */ D(ft, {
					course: S,
					trackId: e
				}),
				/* @__PURE__ */ D(ut, { course: S }),
				/* @__PURE__ */ D(xt, {
					course: S,
					trackId: e
				}),
				t.corners.map((e) => /* @__PURE__ */ D(mt, {
					course: S,
					at: e.at,
					limit: e.limit
				}, e.at)),
				s.map((e) => /* @__PURE__ */ D(vt, {
					course: S,
					car: e,
					reduced: _,
					positions: C,
					shadow: y
				}, e.rid)),
				/* @__PURE__ */ D(Ct, {
					course: S,
					cars: s,
					mode: l,
					focusPos: ee,
					ownPos: te,
					bendAt: f,
					reset: p,
					reduced: _,
					rigRef: x
				})
			]
		})
	});
}
//#endregion
//#region src/games/heat/card.tsx
var Et = {
	s1: {
		main: "1",
		sub: "",
		cls: "bg-surface border-ink text-ink"
	},
	s2: {
		main: "2",
		sub: "",
		cls: "bg-surface border-ink text-ink"
	},
	s3: {
		main: "3",
		sub: "",
		cls: "bg-surface border-ink text-ink"
	},
	s4: {
		main: "4",
		sub: "",
		cls: "bg-surface border-ink text-ink"
	},
	c0: {
		main: "0",
		sub: "COAST",
		cls: "bg-info-soft border-info text-info-ink"
	},
	f5: {
		main: "5",
		sub: "FULL",
		cls: "bg-warn-soft border-warn text-warn-ink"
	},
	xh: {
		main: "🔥",
		sub: "+HEAT",
		cls: "bg-danger-soft border-danger text-danger-ink"
	},
	st: {
		main: "?",
		sub: "STRESS",
		cls: "bg-warn-soft border-warn text-warn-ink border-dashed"
	},
	h: {
		main: "🔥",
		sub: "HEAT",
		cls: "bg-danger-soft border-danger text-danger-ink"
	}
}, Dt = {
	"4wd": "🛞",
	body: "🚗",
	brakes: "🛑",
	cooling: "❄️",
	fuel: "⛽",
	gas: "👟",
	rpm: "💨",
	susp: "♻️",
	tires: "🍩",
	turbo: "💥",
	wings: "🪽",
	xheat: "🔥"
};
function Ot(e) {
	let t = [];
	return e.heat && t.push(`🔥${e.heat}`), e.scrap && t.push(`🗑️${e.scrap}`), e.limit && t.push(`⏱️${e.limit > 0 ? "+" : ""}${e.limit}`), e.cool && t.push(`❄️${e.cool}`), e.stress && t.push(`🧘${e.stress}`), e.slip && t.push(`💨${e.slip}`), e.salvage && t.push(`🎣${e.salvage}`), e.refresh && t.push("♻️"), e.direct && t.push("👆"), e.accel && t.push("⚡"), t;
}
function kt({ card: e, selected: t, dimmed: n, big: r }) {
	if (z(e)) {
		let i = B(e), a = i.xheat ? "🔥" : i.v === void 0 ? i.choice ? i.choice.join("|") : i.plus ? "+".repeat(i.plus) : "?" : String(i.v);
		return /* @__PURE__ */ O("span", {
			"data-card": e,
			"data-selected": t ? "true" : void 0,
			className: `heat-card ${r ? "heat-card-big" : ""} relative grid ${r ? "h-28 w-20" : "h-20 w-14"} flex-none select-none place-items-center rounded-md border-2 border-ink bg-surface text-ink shadow-[2px_2px_0_var(--color-ink)] transition-transform ${t ? "-translate-y-2" : ""} ${n ? "opacity-40" : ""}`,
			children: [
				/* @__PURE__ */ D("span", {
					className: `heat-card-icon absolute top-0.5 left-1 ${r ? "text-xs" : "text-[9px]"} leading-none`,
					children: Dt[i.cat]
				}),
				i.adv && /* @__PURE__ */ D("span", {
					className: `heat-card-advanced absolute top-0.5 right-1 ${r ? "text-[10px]" : "text-[7px]"} leading-none opacity-70`,
					children: "⚙️"
				}),
				/* @__PURE__ */ D("span", {
					className: "flex flex-col items-center leading-none",
					children: /* @__PURE__ */ D("span", {
						className: `heat-card-value ${i.choice ? "heat-card-choice" : ""} font-display font-black tabular-nums ${r ? "text-3xl" : i.choice ? "text-lg" : "text-2xl"}`,
						children: a
					})
				}),
				/* @__PURE__ */ D("span", {
					className: `heat-card-chips absolute inset-x-0 bottom-0.5 flex flex-wrap items-center justify-center px-0.5 ${r ? "text-[10px]" : "text-[7px]"} leading-tight`,
					children: Ot(i).map((e, t) => /* @__PURE__ */ D("span", { children: e }, t))
				})
			]
		});
	}
	let i = Et[e];
	return /* @__PURE__ */ D("span", {
		"data-card": e,
		"data-selected": t ? "true" : void 0,
		className: `heat-card ${r ? "heat-card-big" : ""} grid ${r ? "h-28 w-20" : "h-20 w-14"} flex-none select-none place-items-center rounded-md border-2 shadow-[2px_2px_0_var(--color-ink)] transition-transform ${i.cls} ${t ? "-translate-y-2" : ""} ${n ? "opacity-40" : ""}`,
		children: /* @__PURE__ */ O("span", {
			className: "flex flex-col items-center leading-none",
			children: [/* @__PURE__ */ D("span", {
				className: `heat-card-value font-display font-black ${e === "xh" || e === "h" ? "text-2xl" : r ? "text-4xl" : "text-3xl"}`,
				children: i.main
			}), i.sub && /* @__PURE__ */ D("span", {
				className: "heat-card-caption mt-1 text-[8px] font-extrabold tracking-wide",
				children: i.sub
			})]
		})
	});
}
//#endregion
//#region src/games/heat/view-player.tsx
function At(e) {
	let t = e.public, n = e.private;
	return t.phase === "draft" && t.draft ? /* @__PURE__ */ D(d, {
		adaptive: !0,
		className: "heat-layout",
		scroll: !1,
		children: /* @__PURE__ */ D(Pt, {
			pub: t,
			members: e.members,
			myRid: e.myRid,
			send: e.send
		})
	}) : /* @__PURE__ */ D(d, {
		adaptive: !0,
		className: "heat-layout",
		scroll: !1,
		children: /* @__PURE__ */ D(Ft, {
			pub: t,
			priv: n,
			members: e.members,
			myRid: e.myRid,
			send: e.send
		})
	});
}
var jt = {
	usa: "games.heat.trackUsa",
	ita: "games.heat.trackIta",
	fra: "games.heat.trackFra",
	gbr: "games.heat.trackGbr"
}, Mt = {
	G: "games.heat.legendG",
	R: "games.heat.legendR",
	Y: "games.heat.legendY",
	B: "games.heat.legendB",
	W: "games.heat.legendW",
	K: "games.heat.legendK"
};
function Nt({ car: e, rank: t, mine: n, planned: r, gear: i, engine: a }) {
	let c = o(), { ref: u, hidden: d } = s(e.icon ? null : `seat:${e.rid}`), f = e.hex ?? l[e.colorIndex % l.length].hex;
	return /* @__PURE__ */ O("div", {
		ref: u,
		className: `heat-driver ${n ? "heat-driver-mine" : ""}`,
		style: {
			"--heat-team": f,
			visibility: d ? "hidden" : void 0
		},
		children: [
			/* @__PURE__ */ O("span", {
				className: "heat-driver-rank",
				children: ["P", t]
			}),
			/* @__PURE__ */ D("strong", {
				title: e.name,
				children: e.name
			}),
			/* @__PURE__ */ D("small", { children: e.finished ? c("games.heat.finished") : r === null ? c("games.heat.legendDriver") : r ? c("games.heat.driverReady") : i === void 0 ? "" : `${c("games.heat.gearLabel", { n: i })} · ${c("games.heat.engineHeat", { n: a ?? 0 })}` }),
			/* @__PURE__ */ D("span", {
				className: `heat-driver-signal ${r === !1 ? "heat-driver-signal-wait" : ""}`,
				"aria-hidden": "true"
			})
		]
	});
}
function Pt({ pub: e, members: t, myRid: n, send: r }) {
	let i = o(), a = e.draft, s = (e) => t.find((t) => t.rid === e)?.name ?? e, c = a.order[a.idx], d = c === n;
	return /* @__PURE__ */ O("div", {
		className: "heat-draft heat-screen flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ O("header", {
				className: "heat-mast",
				children: [/* @__PURE__ */ O("div", {
					className: "heat-brand",
					children: ["HEAT", /* @__PURE__ */ O("small", { children: [
						i("games.heat.name"),
						" ",
						/* @__PURE__ */ D("b", { children: "·" }),
						" ",
						i("games.heat.garageHeader")
					] })]
				}), /* @__PURE__ */ O("div", {
					className: "heat-race-badge",
					children: [
						/* @__PURE__ */ D("span", {
							className: "heat-race-flag",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ D("span", { children: i("games.heat.draftRoundShort") }),
						/* @__PURE__ */ D("strong", { children: String(a.round + 1).padStart(2, "0") })
					]
				})]
			}),
			/* @__PURE__ */ D(u, {
				tone: d ? "accent" : "info",
				text: d ? i("games.heat.draftYourPick") : i("games.heat.draftWaiting", { name: s(c) }),
				chip: i("games.heat.draftRound", { n: a.round + 1 }),
				accent: F.accent
			}),
			/* @__PURE__ */ D("div", {
				className: "heat-draft-order flex items-center justify-center gap-1.5 overflow-x-auto px-1",
				children: a.order.map((e, n) => {
					let r = t.find((t) => t.rid === e), i = l[(r?.colorIndex ?? 0) % l.length].hex, o = n < a.idx;
					return /* @__PURE__ */ O("span", {
						className: `plate flex items-center gap-1 px-2 py-1 text-xs font-extrabold whitespace-nowrap ${n === a.idx ? "ring-2 ring-ink" : ""} ${o ? "opacity-50" : ""}`,
						children: [
							/* @__PURE__ */ D("span", {
								className: "inline-block size-2.5 rounded-full border border-ink",
								style: { background: i }
							}),
							s(e),
							/* @__PURE__ */ O("span", {
								className: "font-mono tabular-nums opacity-70",
								children: [(a.picks[e] ?? []).length, "/3"]
							})
						]
					}, e);
				})
			}),
			/* @__PURE__ */ O("div", {
				className: "heat-draft-market min-h-0 flex-1 overflow-y-auto p-2",
				children: [/* @__PURE__ */ D("div", {
					className: "heat-draft-market-grid mx-auto grid w-max grid-cols-3 gap-2.5 py-1",
					children: a.market.map((e, t) => /* @__PURE__ */ D("button", {
						type: "button",
						disabled: !d,
						onClick: () => r({
							type: "draft",
							card: e
						}),
						className: "flex-none disabled:opacity-90",
						children: /* @__PURE__ */ D(kt, {
							card: e,
							big: !0
						})
					}, `${e}-${t}`))
				}), /* @__PURE__ */ D("p", {
					className: "pt-1 text-center text-[11px] font-bold opacity-60",
					children: i("games.heat.draftPool", { n: a.poolCount })
				})]
			}),
			/* @__PURE__ */ O("div", {
				className: "heat-draft-picks safe-b pb-1",
				children: [/* @__PURE__ */ D("p", {
					className: "section-label px-1 pb-1",
					children: i("games.heat.draftMyPicks")
				}), /* @__PURE__ */ O("div", {
					className: "heat-draft-pick-row flex h-24 items-center gap-1.5 overflow-x-auto px-2",
					children: [(a.picks[n] ?? []).map((e, t) => /* @__PURE__ */ D(kt, { card: e }, t)), (a.picks[n] ?? []).length === 0 && /* @__PURE__ */ D("span", {
						className: "text-xs font-bold opacity-40",
						children: "—"
					})]
				})]
			})
		]
	});
}
function Ft({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let s = o(), c = P[e.track], l = (e) => n.find((t) => t.rid === e)?.name ?? e, u = e.cars[r], d = e.current, f = d?.rid === r, [p, m] = a(0), [h, g] = a([]), [_, v] = a(0), [y, b] = a(!1), [x, S] = a(!1), [C, ee] = a([]), [te, w] = a([]), [T, ne] = a([]), [k, A] = a([]), [j, re] = a(!1), [M, N] = a(null), [ie, ae] = a([]), [ce, le] = a("car"), [ue, de] = a(!1), [fe, I] = a(0), [pe] = a(it), me = `${e.round}:${e.phase}:${d?.rid ?? ""}:${d?.step ?? ""}`, [he, ge] = a(me);
	he !== me && (ge(me), m(0), g([]), v(0), b(!1), S(!1), ee([]), w([]), ne([]), A([]), re(!1), N(null), ae([]));
	let L = t?.hand ?? [], _e = t?.discard ?? [], ve = u?.play ?? [], R = u?.planned ?? !1, ye = L.map((e, t) => U(e) ? t : -1).filter((e) => e >= 0), be = p || u?.gear || 1, xe = u && !u.finished ? c.corners.reduce((e, t) => {
		let n = ((t.at - u.pos) % c.spaces + c.spaces) % c.spaces || c.spaces;
		return !e || n < e.dist ? {
			dist: n,
			limit: t.limit
		} : e;
	}, null) : null, Se = Math.min(be, ye.length), Ce = u ? Math.abs(be - u.gear) === 2 : !1, we = e.phase === "plan" && !R && Ce, Te = L.filter((e) => e === "h" || e === "xh").length, Ee = C.reduce((e, t) => e + (z(L[t]) ? B(L[t]).cool ?? 0 : 0), 0), De = d ? Math.min(d.cooldownLeft + Ee, Te) : 0, Oe = ve.map((e, t) => z(e) && B(e).refresh ? t : -1).filter((e) => e >= 0), V;
	V = u?.finished ? s("games.heat.finished") : e.phase === "plan" ? R ? s("games.heat.planWaiting") : s("games.heat.planPrompt", { n: Se }) : f ? s("games.heat.yourMove") : d ? s("games.heat.waitingMove", { name: l(d.rid) }) : s("games.heat.resolving");
	let H = [...n.filter((t) => e.cars[t.rid]).map((t) => ({
		rid: t.rid,
		pos: e.cars[t.rid].pos,
		spot: e.cars[t.rid].spot,
		colorIndex: t.colorIndex,
		avatar: t.avatar,
		name: t.name,
		active: d?.rid === t.rid || e.phase === "plan" && t.rid === r,
		finished: e.cars[t.rid].finished,
		spunOut: e.cars[t.rid].spunOut
	})), ...Object.entries(e.legends).map(([e, t]) => ({
		rid: e,
		pos: t.pos,
		spot: t.spot,
		colorIndex: 0,
		hex: oe[t.color],
		name: s(Mt[t.color]),
		icon: "🏎️",
		active: !1,
		finished: t.finished,
		spunOut: !1
	}))], ke = [...H].sort((t, n) => {
		let r = e.hall.indexOf(t.rid), i = e.hall.indexOf(n.rid);
		return r >= 0 || i >= 0 ? r < 0 ? 1 : i < 0 ? -1 : r - i : n.pos - t.pos || t.spot - n.spot;
	}), Ae = e.phase === "resolve" && d ? d.rid : e.cars[r] ? r : H[0]?.rid ?? null, je = H.find((e) => e.rid === Ae)?.pos ?? 0, Me = u?.pos ?? je, W = c.corners.reduce((e, t) => {
		let n = ((t.at - Me) % c.spaces + c.spaces) % c.spaces || c.spaces;
		return n < e.distance ? {
			at: t.at,
			distance: n
		} : e;
	}, {
		at: c.corners[0]?.at ?? 0,
		distance: Infinity
	}).at, Pe = Math.min(c.laps, Math.floor((u?.pos ?? 0) / c.spaces) + 1), G = h.reduce((e, t) => {
		let n = L[t];
		if (n?.startsWith("s") && n !== "st") return e + Number(n.slice(1));
		if (n === "f5") return e + 5;
		if (n && z(n)) {
			let t = B(n);
			return e + (t.v ?? t.choice?.[0] ?? 0);
		}
		return e;
	}, 0), K = h.some((e) => {
		let t = L[e];
		return t === "st" || t && z(t) && (!!B(t).choice || !!B(t).plus);
	}), q = (t) => {
		if (e.phase === "plan" && !R) {
			if (!U(L[t])) return;
			g((e) => e.includes(t) ? e.filter((e) => e !== t) : e.length < Se ? [...e, t] : [...e.slice(1), t]);
		} else if (f && d?.step === "react") {
			let e = L[t];
			z(e) && B(e).direct ? ee((e) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t]) : e === "st" && d.stressLeft > 0 && w((e) => e.includes(t) ? e.filter((e) => e !== t) : e.length < d.stressLeft ? [...e, t] : e);
		} else if (f && d?.step === "discard") {
			if (!Ne(L[t])) return;
			g((e) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t]);
		}
	}, J = (e) => f && d?.step === "react" && (z(e) && !!B(e).direct || e === "st" && d.stressLeft > 0);
	return /* @__PURE__ */ O("div", {
		className: "heat-screen heat-race relative flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ O("header", {
				className: "heat-mast",
				children: [/* @__PURE__ */ O("div", {
					className: "heat-brand",
					children: ["HEAT", /* @__PURE__ */ O("small", { children: [
						s("games.heat.name"),
						" ",
						/* @__PURE__ */ D("b", { children: "·" }),
						" ",
						s(jt[e.track])
					] })]
				}), /* @__PURE__ */ O("div", {
					className: "heat-race-badge",
					children: [
						/* @__PURE__ */ D("span", {
							className: "heat-race-flag",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ D("span", { children: s("games.heat.roundShort") }),
						/* @__PURE__ */ D("strong", { children: String(e.round).padStart(2, "0") })
					]
				})]
			}),
			/* @__PURE__ */ D("section", {
				className: "heat-standings",
				"aria-label": s("games.heat.standings"),
				children: ke.map((t, n) => {
					let i = e.cars[t.rid];
					return /* @__PURE__ */ D(Nt, {
						car: t,
						rank: n + 1,
						mine: t.rid === r,
						planned: i ? e.phase === "plan" ? i.planned : d?.rid === t.rid : null,
						gear: i?.gear,
						engine: i?.engine
					}, t.rid);
				})
			}),
			/* @__PURE__ */ D("div", {
				className: "heat-phase-tabs",
				"aria-label": s("games.heat.phase"),
				children: [
					"plan",
					"resolve",
					"done"
				].map((t, n) => /* @__PURE__ */ O("div", {
					className: e.phase === t ? "heat-phase-on" : "",
					children: [/* @__PURE__ */ D("span", { children: String(n + 1).padStart(2, "0") }), s(t === "plan" ? "games.heat.phasePlan" : t === "resolve" ? "games.heat.phaseRace" : "games.heat.phaseFinish")]
				}, t))
			}),
			/* @__PURE__ */ O("div", {
				className: "heat-arena relative min-h-0 flex-1 overflow-hidden",
				children: [
					/* @__PURE__ */ D("div", {
						className: "heat-scene",
						children: pe ? /* @__PURE__ */ D(Tt, {
							trackId: e.track,
							track: c,
							cars: H,
							mode: ce,
							focusRid: Ae,
							ownRid: r,
							bendAt: W,
							reset: fe
						}, e.track) : /* @__PURE__ */ D("div", {
							className: "grid size-full place-items-center bg-ink px-6 text-center text-sm font-bold text-white",
							role: "status",
							children: s("games.heat.graphicsUnavailable")
						})
					}),
					/* @__PURE__ */ O("div", {
						className: "heat-arena-head",
						children: [/* @__PURE__ */ O("span", {
							className: "heat-course",
							children: [/* @__PURE__ */ D("b", { children: e.track.toUpperCase() }), s("games.heat.laps", { n: `${Pe}/${c.laps}` })]
						}), xe && /* @__PURE__ */ O("span", {
							className: "heat-limit",
							children: [
								/* @__PURE__ */ D("span", { children: s("games.heat.nextCorner") }),
								/* @__PURE__ */ D("strong", { children: xe.limit }),
								/* @__PURE__ */ D("small", { children: s("games.heat.cornerDistance", { n: xe.dist }) })
							]
						})]
					}),
					e.legendCard !== null && /* @__PURE__ */ O("div", {
						className: "heat-legend pointer-events-none absolute top-14 right-2 z-10 px-2 py-1.5",
						children: [/* @__PURE__ */ D("p", {
							className: "section-label pb-1",
							children: s("games.heat.legendCardTitle")
						}), [...new Set(Object.values(e.legends).map((e) => e.color))].map((t) => {
							let [n, r] = se[e.legendCard][t];
							return /* @__PURE__ */ O("p", {
								className: "flex items-center gap-1 font-mono text-xs font-black tabular-nums",
								children: [
									/* @__PURE__ */ D("span", {
										className: "inline-block size-2.5 rounded-full border border-ink",
										style: { background: oe[t] }
									}),
									n,
									"·◇",
									r
								]
							}, t);
						})]
					}),
					(we || xe) && /* @__PURE__ */ D("div", {
						className: "pointer-events-none absolute bottom-16 left-2 z-10 flex flex-col items-start gap-1.5",
						children: we && /* @__PURE__ */ D("span", {
							className: "rounded-lg border-2 border-warn bg-warn-soft px-1.5 py-0.5 text-[11px] font-extrabold text-warn-ink",
							children: s("games.heat.gearShift2")
						})
					}),
					/* @__PURE__ */ O("div", {
						className: "heat-scene-caption",
						children: [/* @__PURE__ */ D("span", {
							"aria-hidden": "true",
							children: "●"
						}), V]
					}),
					pe && /* @__PURE__ */ O("div", {
						className: "heat-camera-control",
						children: [ue && /* @__PURE__ */ D("nav", {
							className: "heat-camera-menu",
							"aria-label": s("games.heat.camera"),
							children: [
								"car",
								"bend",
								"overview"
							].map((e, t) => /* @__PURE__ */ O("button", {
								type: "button",
								className: ce === e ? "heat-camera-on" : "",
								"aria-current": ce === e ? "true" : void 0,
								onClick: () => {
									le(e), I((e) => e + 1), de(!1);
								},
								children: [/* @__PURE__ */ O("small", { children: ["0", t + 1] }), /* @__PURE__ */ D("strong", { children: s(e === "car" ? "games.heat.cameraFollow" : e === "bend" ? "games.heat.cameraBend" : "games.heat.cameraOverview") })]
							}, e))
						}), /* @__PURE__ */ O("button", {
							className: "heat-camera-trigger",
							type: "button",
							"aria-label": s("games.heat.camera"),
							"aria-expanded": ue,
							onClick: () => de((e) => !e),
							children: [/* @__PURE__ */ D("small", { children: "CAM" }), /* @__PURE__ */ O("strong", { children: ["0", [
								"car",
								"bend",
								"overview"
							].indexOf(ce) + 1] })]
						})]
					})
				]
			}),
			/* @__PURE__ */ O("div", {
				className: "heat-dashboard safe-b flex flex-col gap-1.5 pb-1",
				children: [
					/* @__PURE__ */ O("div", {
						className: "heat-dashboard-top flex h-12 items-center justify-center gap-2",
						children: [/* @__PURE__ */ O("div", {
							className: "heat-gear-panel",
							children: [/* @__PURE__ */ O("span", {
								className: "heat-gear-label",
								children: ["GEAR", /* @__PURE__ */ D("small", { children: s("games.heat.gearShort") })]
							}), e.phase === "plan" && !R && u ? [
								1,
								2,
								3,
								4
							].map((e) => {
								let t = Math.abs(e - u.gear), n = t > 2 || t === 2 && u.engine < 1;
								return /* @__PURE__ */ D("button", {
									type: "button",
									disabled: n,
									"aria-label": s("games.heat.gearLabel", { n: e }),
									onClick: () => {
										m(e), g((t) => t.slice(0, Math.min(e, ye.length)));
									},
									className: `btn-base min-h-11 min-w-11 font-mono text-lg font-black tabular-nums disabled:opacity-30 ${be === e ? "" : "btn-quiet"}`,
									style: be === e ? { background: F.accent } : void 0,
									children: e
								}, e);
							}) : d ? /* @__PURE__ */ O("span", {
								className: "plate px-3 py-1 text-sm font-extrabold",
								children: [
									s("games.heat.speedLabel", { n: d.speed }),
									d.limitAdj !== 0 && /* @__PURE__ */ O("span", {
										className: "ml-1 font-mono tabular-nums",
										children: [
											"⏱️",
											d.limitAdj > 0 ? "+" : "",
											d.limitAdj
										]
									}),
									d.slipBonus > 0 && /* @__PURE__ */ O("span", {
										className: "ml-1 font-mono tabular-nums",
										children: ["💨+", d.slipBonus]
									}),
									d.adr && !d.adrSpeedUsed && d.rid === r ? ` · ${s("games.heat.adrSpeed")}` : ""
								]
							}) : /* @__PURE__ */ O("span", {
								className: "plate px-3 py-1 text-sm font-bold opacity-70",
								children: [
									s(jt[e.track]),
									" · ",
									s("games.heat.laps", { n: c.laps })
								]
							})]
						}), /* @__PURE__ */ O("div", {
							className: "heat-gauge",
							children: [
								/* @__PURE__ */ D("span", { children: s("games.heat.engineShort") }),
								/* @__PURE__ */ O("strong", { children: [u?.engine ?? 0, /* @__PURE__ */ O("small", { children: ["/", c.heat] })] }),
								/* @__PURE__ */ D("div", {
									className: "heat-meter",
									"aria-hidden": "true",
									children: Array.from({ length: c.heat }, (e, t) => /* @__PURE__ */ D("i", { className: t < (u?.engine ?? 0) ? "heat-meter-lit" : "" }, t))
								})
							]
						})]
					}),
					/* @__PURE__ */ O("div", {
						className: "heat-hand-head",
						children: [
							/* @__PURE__ */ D("span", { children: s("games.heat.handLabel") }),
							/* @__PURE__ */ D("span", { children: e.phase === "plan" && !R ? `${s("games.heat.speedPreview")} ${K ? "≥" : ""}${G}` : d ? s("games.heat.speedLabel", { n: d.speed }) : V }),
							/* @__PURE__ */ D("span", {
								className: "heat-card-slots",
								children: Array.from({ length: Math.max(1, Se) }, (e, t) => /* @__PURE__ */ D("i", {
									className: t < h.length ? "heat-slot-filled" : "",
									children: t < h.length ? t + 1 : "+"
								}, t))
							})
						]
					}),
					/* @__PURE__ */ D("div", {
						className: "heat-hand h-24 overflow-x-auto",
						children: /* @__PURE__ */ D("div", {
							className: "heat-hand-cards mx-auto flex h-full w-max items-center gap-1.5 px-2 pt-2",
							children: e.phase === "plan" && R && t?.myPlanned ? t.myPlanned.cards.map((e, t) => /* @__PURE__ */ D(kt, { card: e }, t)) : L.map((t, n) => {
								let r = e.phase === "plan" && !R && U(t) || f && d?.step === "discard" && Ne(t) || J(t), i = h.includes(n) || C.includes(n) || te.includes(n);
								return /* @__PURE__ */ D("button", {
									type: "button",
									disabled: !r,
									onClick: () => q(n),
									className: "flex-none",
									children: /* @__PURE__ */ D(kt, {
										card: t,
										selected: i,
										dimmed: !r && (e.phase === "plan" || d?.step === "discard" || d?.step === "react")
									})
								}, n);
							})
						})
					}),
					/* @__PURE__ */ D("div", {
						className: "heat-actions h-12 overflow-x-auto",
						children: /* @__PURE__ */ O("div", {
							className: "heat-action-content mx-auto flex h-full w-max items-center justify-center gap-2 px-2",
							children: [
								e.phase === "plan" && !R && u && /* @__PURE__ */ O("button", {
									type: "button",
									disabled: h.length !== Se,
									onClick: () => i({
										type: "plan",
										gear: be,
										cards: h.map((e) => L[e])
									}),
									className: "heat-primary btn-base min-h-12 px-6 text-base font-extrabold text-white disabled:opacity-40",
									style: { background: F.accent },
									children: [s("games.heat.planSubmit"), /* @__PURE__ */ O("span", {
										className: "ml-1 font-mono tabular-nums",
										children: [
											h.length,
											"/",
											Se
										]
									})]
								}),
								f && d?.step === "choice" && /* @__PURE__ */ O(E, { children: [d.choiceIdx.map((e, t) => {
									let n = ve[e], r = z(n) ? B(n).choice ?? [] : [];
									return /* @__PURE__ */ O("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ D("span", {
											className: "text-base",
											children: z(n) ? Dt[B(n).cat] : ""
										}), r.map((e) => /* @__PURE__ */ D("button", {
											type: "button",
											onClick: () => ae(d.choiceIdx.map((n, r) => r === t ? e : ie[r] ?? null)),
											className: `btn-base min-h-11 min-w-11 font-mono text-base font-black tabular-nums ${ie[t] === e ? "text-white" : "btn-quiet"}`,
											style: ie[t] === e ? { background: F.accent } : void 0,
											children: e
										}, e))]
									}, t);
								}), /* @__PURE__ */ D("button", {
									type: "button",
									disabled: d.choiceIdx.some((e, t) => ie[t] == null),
									onClick: () => i({
										type: "choice",
										values: d.choiceIdx.map((e, t) => ie[t] ?? 1)
									}),
									className: "heat-primary btn-base min-h-12 px-5 text-base font-extrabold text-white disabled:opacity-40",
									style: { background: F.accent },
									children: s("games.heat.choiceConfirm")
								})] }),
								f && d?.step === "react" && /* @__PURE__ */ O(E, { children: [
									/* @__PURE__ */ O("span", {
										className: "flex items-center gap-1",
										children: [
											/* @__PURE__ */ D("button", {
												type: "button",
												"aria-label": "-",
												disabled: _ <= 0,
												onClick: () => v(_ - 1),
												className: "btn-base btn-quiet min-h-11 min-w-11 text-lg font-black",
												children: "−"
											}),
											/* @__PURE__ */ O("span", {
												className: "plate min-w-16 px-2 py-1 text-center text-sm font-extrabold",
												children: [s("games.heat.cooldown", { n: _ }), /* @__PURE__ */ O("span", {
													className: "opacity-60",
													children: ["/", De]
												})]
											}),
											/* @__PURE__ */ D("button", {
												type: "button",
												"aria-label": "+",
												disabled: _ >= De,
												onClick: () => v(_ + 1),
												className: "btn-base btn-quiet min-h-11 min-w-11 text-lg font-black",
												children: "+"
											})
										]
									}),
									/* @__PURE__ */ O("button", {
										type: "button",
										disabled: (u?.engine ?? 0) < 1 || d.boostUsed,
										onClick: () => b(!y),
										className: `btn-base min-h-11 px-3 text-sm font-extrabold disabled:opacity-30 ${y ? "text-white" : "btn-quiet"}`,
										style: y ? { background: F.accent } : void 0,
										children: ["🚀 ", s("games.heat.boost")]
									}),
									d.adr && !d.adrSpeedUsed && /* @__PURE__ */ D("button", {
										type: "button",
										onClick: () => S(!x),
										className: `btn-base min-h-11 px-3 text-sm font-extrabold ${x ? "text-white" : "btn-quiet"}`,
										style: x ? { background: F.accent } : void 0,
										children: s("games.heat.adrSpeed")
									}),
									d.accelAvail && d.flips > 0 && /* @__PURE__ */ O("button", {
										type: "button",
										onClick: () => re(!j),
										className: `btn-base min-h-11 px-3 text-sm font-extrabold ${j ? "text-white" : "btn-quiet"}`,
										style: j ? { background: F.accent } : void 0,
										children: ["⚡+", d.flips]
									}),
									d.salvageLeft > 0 && /* @__PURE__ */ O("button", {
										type: "button",
										onClick: () => N(M === "salvage" ? null : "salvage"),
										className: `btn-base min-h-11 px-3 text-sm font-extrabold ${T.length ? "text-white" : "btn-quiet"}`,
										style: T.length ? { background: F.accent } : void 0,
										children: [
											"🎣",
											T.length > 0 ? `${T.length}/` : "",
											d.salvageLeft
										]
									}),
									Oe.length > 0 && /* @__PURE__ */ O("button", {
										type: "button",
										onClick: () => N(M === "refresh" ? null : "refresh"),
										className: `btn-base min-h-11 px-3 text-sm font-extrabold ${k.length ? "text-white" : "btn-quiet"}`,
										style: k.length ? { background: F.accent } : void 0,
										children: ["♻️", k.length > 0 ? k.length : ""]
									}),
									/* @__PURE__ */ D("button", {
										type: "button",
										onClick: () => i({
											type: "react",
											boost: y,
											adrSpeed: x,
											cool: _,
											stressOut: te.map((e) => L[e]),
											salvage: T.map((e) => _e[e]),
											refresh: k.map((e) => ve[e]),
											direct: C.map((e) => L[e]),
											accel: j
										}),
										className: "heat-primary btn-base min-h-12 px-5 text-base font-extrabold text-white",
										style: { background: F.accent },
										children: s("games.heat.reactConfirm")
									})
								] }),
								f && d?.step === "slip" && /* @__PURE__ */ O(E, { children: [
									/* @__PURE__ */ D("span", {
										className: "plate px-3 py-1 text-sm font-extrabold",
										children: s("games.heat.slipPrompt", { n: 2 + d.slipBonus })
									}),
									/* @__PURE__ */ D("button", {
										type: "button",
										onClick: () => i({
											type: "slip",
											take: !0
										}),
										className: "heat-primary btn-base min-h-12 px-5 text-base font-extrabold text-white",
										style: { background: F.accent },
										children: s("games.heat.slipTake")
									}),
									/* @__PURE__ */ D("button", {
										type: "button",
										onClick: () => i({
											type: "slip",
											take: !1
										}),
										className: "btn-base btn-quiet min-h-12 px-5 text-base font-extrabold",
										children: s("games.heat.slipSkip")
									})
								] }),
								f && d?.step === "discard" && /* @__PURE__ */ O(E, { children: [/* @__PURE__ */ D("span", {
									className: "plate px-3 py-1 text-sm font-bold",
									children: s("games.heat.discardPrompt")
								}), /* @__PURE__ */ O("button", {
									type: "button",
									onClick: () => i({
										type: "discard",
										cards: h.map((e) => L[e])
									}),
									className: "heat-primary btn-base min-h-12 px-5 text-base font-extrabold text-white",
									style: { background: F.accent },
									children: [s("games.heat.discardConfirm"), h.length > 0 && /* @__PURE__ */ O("span", {
										className: "ml-1 font-mono tabular-nums",
										children: ["-", h.length]
									})]
								})] })
							]
						})
					})
				]
			}),
			M && f && d?.step === "react" && /* @__PURE__ */ O("div", {
				className: "heat-selection-overlay card absolute inset-x-2 bottom-2 z-20 p-2",
				children: [
					/* @__PURE__ */ D("p", {
						className: "section-label pb-1.5",
						children: s(M === "salvage" ? "games.heat.salvageTitle" : "games.heat.refreshTitle")
					}),
					/* @__PURE__ */ D("div", {
						className: "heat-selection-cards flex max-h-40 flex-wrap items-center gap-1.5 overflow-y-auto",
						children: M === "salvage" ? _e.map((e, t) => /* @__PURE__ */ D("button", {
							type: "button",
							onClick: () => ne((e) => e.includes(t) ? e.filter((e) => e !== t) : e.length < (d?.salvageLeft ?? 0) ? [...e, t] : e),
							className: "flex-none",
							children: /* @__PURE__ */ D(kt, {
								card: e,
								selected: T.includes(t)
							})
						}, t)) : Oe.map((e) => /* @__PURE__ */ D("button", {
							type: "button",
							onClick: () => A((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]),
							className: "flex-none",
							children: /* @__PURE__ */ D(kt, {
								card: ve[e],
								selected: k.includes(e)
							})
						}, e))
					}),
					/* @__PURE__ */ D("button", {
						type: "button",
						onClick: () => N(null),
						className: "btn-base btn-quiet mt-2 min-h-11 w-full text-sm font-extrabold",
						children: s("games.heat.overlayDone")
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/heat/bot.ts
function It(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function Lt(e, t) {
	let n = P[e.track], r = n.spaces * n.laps, i = null;
	for (let e of n.corners) for (let a = 0;; a += 1) {
		let o = e.at + a * n.spaces;
		if (o > r) break;
		o > t && (!i || o - t < i.dist) && (i = {
			dist: o - t,
			limit: e.limit
		});
	}
	return i;
}
var Rt = (e, t) => {
	if (e === "st") return t;
	let n = H(e);
	if (n !== null) return n;
	if (z(e)) {
		let t = B(e);
		if (t.v !== void 0) return t.v;
		if (t.choice) return Math.max(...t.choice);
		if (t.plus) return 2.5 * t.plus;
	}
	return 0;
}, zt = (e) => {
	let t = B(e);
	return t.xheat ? 2 : (t.v ?? (t.choice ? Math.max(...t.choice) : t.plus ? 2.5 * t.plus : 0)) + (t.cool ?? 0) * .8 + (t.stress ?? 0) * .7 + (t.slip ?? 0) * .4 + (t.salvage ?? 0) * .3 + (t.limit ? Math.abs(t.limit) * .5 : 0) + +!!t.refresh + (t.direct ? .5 : 0) + (t.accel ? .6 : 0) - (t.heat ?? 0) * 1.2 - (t.scrap ?? 0) * .4;
}, Bt = (e, t) => {
	let { public: n, private: r } = e;
	if (!r) return null;
	let i = n.cars[t.rid];
	if (!i || i.finished || n.phase === "done") return null;
	let a = t.difficulty === "weak", o = r.hand;
	if (n.phase === "draft") {
		let e = n.draft;
		return !e || e.order[e.idx] !== t.rid ? null : a ? { action: {
			type: "draft",
			card: It(e.market)
		} } : { action: {
			type: "draft",
			card: e.market.reduce((e, t) => zt(t) > zt(e) ? t : e)
		} };
	}
	let s = o.map((e, t) => U(e) ? t : -1).filter((e) => e >= 0);
	if (n.phase === "plan") {
		if (i.planned) return null;
		let e = [
			1,
			2,
			3,
			4
		].filter((e) => {
			let t = Math.abs(e - i.gear);
			return t <= 2 && (t < 2 || i.engine >= 1);
		});
		if (a) {
			let t = It(e), n = Math.min(t, s.length);
			return { action: {
				type: "plan",
				gear: t,
				cards: [...s].sort(() => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 3 - 1).slice(0, n).map((e) => o[e])
			} };
		}
		let t = Lt(n, i.pos), r = P[n.track].spaces * P[n.track].laps - i.pos, c;
		c = r <= 10 ? r : t && t.dist <= 9 ? t.limit + Math.min(2, Math.max(0, i.engine - 1)) : 11;
		let l = e[0], u = -1e9;
		for (let n of e) {
			let e = Math.min(n, s.length), r = s.map((e) => Rt(o[e], 2.5)).sort((e, t) => t - e).slice(0, e).reduce((e, t) => e + t, 0), a = Math.abs(n - i.gear) === 2 ? 3 : Math.abs(n - i.gear), d = -Math.abs(r - c) * 4 - a - (t && t.dist <= r && r > t.limit ? (r - t.limit) * 2 : 0);
			d > u && (u = d, l = n);
		}
		let d = Math.min(l, s.length), f = t && t.dist <= 6 ? 4 : 2.5, p = s.slice(0, d), m = 1e9, h = (e, t, n) => {
			if (t === 0) {
				let e = n.reduce((e, t) => e + Rt(o[t], f), 0), t = n.some((e) => o[e] === "st") ? f === 4 ? .4 : -.4 : 0, r = Math.abs(e - c) + t;
				r < m && (m = r, p = [...n]);
				return;
			}
			for (let r = e; r <= s.length - t; r += 1) h(r + 1, t - 1, [...n, s[r]]);
		};
		return h(0, d, []), { action: {
			type: "plan",
			gear: l,
			cards: p.map((e) => o[e])
		} };
	}
	let c = n.current;
	if (!c || c.rid !== t.rid) return null;
	if (c.step === "choice") {
		let e = Lt(n, i.pos), t = c.speed;
		return { action: {
			type: "choice",
			values: c.choiceIdx.map((n) => {
				let r = i.play[n], o = z(r) ? B(r).choice ?? [1] : [1];
				if (a || !e) {
					let e = a ? It(o) : Math.max(...o);
					return t += e, e;
				}
				let s = [...o].sort((e, t) => t - e), c = s[s.length - 1];
				for (let n of s) {
					let r = t + n;
					if (!(e.dist <= r) || r <= e.limit || r - e.limit <= i.engine) {
						c = n;
						break;
					}
				}
				return t += c, c;
			})
		} };
	}
	if (c.step === "react") {
		let e = Lt(n, i.pos), t = o.filter((e) => e === "h" || e === "xh").length, s = c.speed, l = [];
		if (!a) for (let t of o) {
			if (!z(t)) continue;
			let n = B(t);
			if (!n.direct) continue;
			let r = n.v ?? 0, a = s + r;
			(!(e && e.dist <= a) || a <= e.limit || a - e.limit <= Math.max(0, i.engine - (n.heat ?? 0))) && (l.push(t), s = a);
		}
		let u = l.reduce((e, t) => e + (B(t).cool ?? 0), 0), d = a ? 0 : Math.min(c.cooldownLeft + u, t), f = !1, p = !1, m = !1, h = [], g = [], _ = [];
		if (!a) {
			let t = P[n.track].spaces * P[n.track].laps, a = i.engine >= 1 && !c.boostUsed, l = !(e && e.dist <= s + 4) || s + 2 <= e.limit + i.engine - 1;
			f = a && (i.pos + s + 4 >= t || l && i.engine >= 3);
			let u = e && e.dist <= s + 1;
			p = c.adr && !c.adrSpeedUsed && (!u || s + 1 <= e.limit + i.engine), m = c.accelAvail && c.flips >= 2 && (!e || e.dist > s + c.flips || s + c.flips <= e.limit + i.engine), h = o.filter((e) => e === "st").slice(0, c.stressLeft), c.salvageLeft > 0 && (g = [...r.discard].filter((e) => e !== "h" && e !== "xh" && !(z(e) && B(e).xheat)).sort((e, t) => Rt(t, 2.5) - Rt(e, 2.5)).slice(0, c.salvageLeft)), _ = i.play.filter((e) => z(e) && B(e).refresh && Rt(e, 2.5) >= 3);
		}
		return { action: {
			type: "react",
			boost: f,
			adrSpeed: p,
			cool: d,
			stressOut: h,
			salvage: g,
			refresh: _,
			direct: l,
			accel: m
		} };
	}
	if (c.step === "slip") return { action: {
		type: "slip",
		take: !0
	} };
	if (a) return { action: {
		type: "discard",
		cards: []
	} };
	let l = Lt(n, i.pos);
	return { action: {
		type: "discard",
		cards: !l || l.dist > 4 ? o.filter((e) => e === "c0").slice(0, 1) : []
	} };
}, Vt = (e) => e.data?.speed ?? 0, Ht = {
	deal: (e, t) => {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ D(j, {
				at: n,
				ms: 600
			})
		} : null;
	},
	move: (e, t) => {
		let n = e.rid ? t.anchor(`car:${e.rid}`) : null;
		if (!n) return null;
		let r = Vt(e), i = e.rid ? l[(t.member(e.rid)?.colorIndex ?? 0) % l.length].hex : "#1c1917";
		return {
			ms: 700,
			node: /* @__PURE__ */ O(E, { children: [/* @__PURE__ */ D(A, {
				at: n,
				ms: 700,
				children: /* @__PURE__ */ O("span", {
					style: { color: i },
					children: ["+", r]
				})
			}), /* @__PURE__ */ D(j, {
				at: n,
				ms: 700
			})] })
		};
	},
	boost: (e, t) => {
		let n = e.rid ? t.anchor(`car:${e.rid}`) : null;
		if (!n) return null;
		let r = e.data?.v ?? 0;
		return {
			ms: 700,
			node: /* @__PURE__ */ O(A, {
				at: n,
				ms: 700,
				children: ["🚀+", r]
			})
		};
	},
	slip: (e, t) => {
		let n = e.rid ? t.anchor(`car:${e.rid}`) : null;
		if (!n) return null;
		let r = e.data, i = (r?.to ?? 0) - (r?.from ?? 0);
		return {
			ms: 600,
			node: /* @__PURE__ */ O(A, {
				at: n,
				ms: 600,
				children: ["💨+", i]
			})
		};
	},
	draftPick: (e, t) => {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ D(j, {
				at: n,
				ms: 600
			})
		} : null;
	},
	spin: (e, t) => {
		let n = e.rid ? t.anchor(`car:${e.rid}`) : null;
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ O(E, { children: [/* @__PURE__ */ D(k, {
				ms: 900,
				className: "bg-danger"
			}), /* @__PURE__ */ D(A, {
				at: n,
				ms: 900,
				children: "💫"
			})] })
		} : null;
	},
	finish: (e, t) => {
		let n = (e.data?.rids ?? []).map((e) => t.anchor(`car:${e}`)).filter((e) => e !== null);
		return n.length ? {
			ms: 1200,
			node: n.map((e, t) => /* @__PURE__ */ D(A, {
				at: e,
				ms: 1200,
				children: "🏁"
			}, t))
		} : null;
	}
}, Ut = {
	G: "games.heat.legendG",
	R: "games.heat.legendR",
	Y: "games.heat.legendY",
	B: "games.heat.legendB",
	W: "games.heat.legendW",
	K: "games.heat.legendK"
}, Wt = {
	G: 6,
	R: 5,
	Y: 3,
	B: 0,
	W: 9,
	K: 7
};
function Gt(e) {
	let t = o(), n = e.public, r = Object.entries(n.legends).map(([e, n]) => ({
		rid: e,
		name: t(Ut[n.color]),
		colorIndex: Wt[n.color],
		avatar: 0,
		online: !0
	}));
	return /* @__PURE__ */ D("div", {
		className: "heat-over",
		children: /* @__PURE__ */ D(re, {
			...e,
			members: [...e.members, ...r],
			accent: F.accent
		})
	});
}
//#endregion
//#region src/games/heat/options.tsx
var Kt = {
	usa: "games.heat.trackUsa",
	ita: "games.heat.trackIta",
	fra: "games.heat.trackFra",
	gbr: "games.heat.trackGbr"
}, qt = {
	off: "games.heat.garageOff",
	basic: "games.heat.garageBasic",
	all: "games.heat.garageAll"
};
function Jt({ value: e, onChange: t }) {
	let n = o(), r = de.safeParse(e), i = r.success ? r.data : de.parse(void 0);
	return /* @__PURE__ */ O("div", {
		className: "heat-options flex flex-col gap-2",
		children: [
			/* @__PURE__ */ D(N, {
				title: n("games.heat.trackLabel"),
				children: ie.map((e) => {
					let r = P[e], a = i.track === e;
					return /* @__PURE__ */ O("label", {
						className: "relative min-w-0 cursor-pointer overflow-hidden rounded-lg border-2 border-ink/35 bg-surface focus-within:outline-3 focus-within:outline-offset-2 focus-within:outline-info",
						style: a ? { borderColor: F.accent } : void 0,
						children: [
							/* @__PURE__ */ D("input", {
								className: "sr-only",
								type: "radio",
								name: "heat-track",
								value: e,
								checked: a,
								onChange: () => t({
									...i,
									track: e
								})
							}),
							/* @__PURE__ */ D("img", {
								className: "block aspect-3/2 w-full object-cover",
								src: `./games/heat/track-preview-${e}.webp`,
								alt: ""
							}),
							a && /* @__PURE__ */ D("span", {
								"aria-hidden": !0,
								className: "absolute right-2 top-2 grid size-6 place-items-center rounded-full border border-white bg-ink text-sm font-black text-white shadow-md",
								children: "✓"
							}),
							/* @__PURE__ */ O("span", {
								className: "block min-w-0 px-2 py-1.5",
								children: [/* @__PURE__ */ D("span", {
									className: "block text-sm font-bold leading-tight",
									children: n(Kt[e])
								}), /* @__PURE__ */ O("span", {
									className: "mt-0.5 block text-xs leading-tight text-ink/65",
									children: [
										n("games.heat.laps", { n: r.laps }),
										" · ",
										n("games.heat.heatPool", { n: r.heat })
									]
								})]
							})
						]
					}, e);
				})
			}),
			/* @__PURE__ */ D(N, {
				title: n("games.heat.garageLabel"),
				columns: 3,
				children: [
					"off",
					"basic",
					"all"
				].map((e) => /* @__PURE__ */ D(M, {
					name: "heat-garage",
					value: e,
					checked: i.garage === e,
					label: n(qt[e]),
					accent: F.accent,
					onChange: () => t({
						...i,
						garage: e
					})
				}, e))
			}),
			/* @__PURE__ */ D(N, {
				title: n("games.heat.legendsLabel"),
				columns: 3,
				children: [
					0,
					1,
					2,
					3,
					4
				].map((e) => /* @__PURE__ */ D(M, {
					name: "heat-legends",
					value: String(e),
					checked: i.legends === e,
					label: e === 0 ? n("games.heat.legendsOff") : `${e} 🏎️`,
					accent: F.accent,
					onChange: () => t({
						...i,
						legends: e
					})
				}, e))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/heat/entry.tsx
var Yt = {
	definition: rt,
	View: At,
	bot: Bt,
	fx: Ht,
	OverView: Gt,
	Options: Jt,
	locales: {
		zh: {
			name: "热力狂飙",
			desc: "换挡冲刺,管理引擎热量,过弯别超速",
			rules: "目标:最先完成规定圈数者胜;若多辆赛车在同一回合冲过终点线，超出终点线较远的赛车排名靠前；若仍并列，则更靠近赛车线的赛车排名靠前。\n准备:\n· 选择赛道(长度、圈数与弯道限速各异),按随机杆位在起点线后的发车格落位。\n· 每名玩家获得 18 张牌：速度值为1、2、3、4的基础速度牌各三张，滑行牌(速度值0)、全速牌(速度值5)及备用热量牌各一张，以及三张压力牌。\n· 每名玩家抽取 7 张起始手牌。\n· 引擎中放入(赛道热量数减一)张热量牌,最后一张以备用热量牌代替、混入牌库。\n· 备用热量牌打出时按速度值 0 计算,冷却进引擎后与普通热量无异。\n流程:每回合全员同时行动,之后按车位从前到后逐车结算。\n· 规划:换挡并暗打出等于档位数的牌;升降一档免费,连换两档须先从引擎支付 1 点热量。\n· 亮牌结算:全员亮牌;压力牌逐张翻出牌库顶牌,直到翻出速度值为1至4的基础速度牌，并用该牌的数值确定压力牌的速度。\n· 翻牌时翻出的其他牌进弃牌堆;按总速前进,落点满员逐格后退。\n· 反应:末位车手获得 1 点肾上腺素速度;1 档可冷却 3 点、2 档可冷却 1 点。\n· 冷却即将等量热量牌从手牌放回引擎;也可支付 1 点热量翻牌库顶牌推进。\n· 滑流:你的落点格有他车、或紧随他车之后一格时,可再前进 2 格。\n· 滑流不计弯道超速、不触发弯道检查,也不可滑过终点线。\n· 弃牌:可弃任意手牌;热量与压力牌不可弃。补牌阶段补至 7 张。\n弯道:每越过一条弯线,超出限速的部分须从引擎支付等量热量。\n· 无法支付所需热量时，赛车立即打滑：退回弯线前第一个空位,按当前档位获得 1-2 张压力牌,降回 1 档。\n结束:全部车手冲线后按冲线名次结算。\n改装(Garage,可选):\n· 开赛前进行 3 轮蛇形选秀(车尾、车头、车尾依次先选),每轮市场为人数加 3 张。\n· 每轮选秀后弃掉市场余卡并换新;每人选 3 张升级卡,替换起手升级后洗入牌库。\n· 起手升级指滑行、全速、备用热量三张。\n· 升级卡符号:🔥 打出时必须支付 1 点热量(无法支付时弃置此卡，改为翻牌确定速度)。\n· 🗑️ 打出时从牌库顶弃掉所示张数。\n· ⏱️ 本回合第一条弯线限速按所示增减。\n· ❄️ 打出后可冷却所示点数。\n· 🧘 反应步可弃掉所示张数的压力牌。\n· 💨 滑流距离增加所示格数。\n· 🎣 从弃牌堆取回所示张数的牌洗回牌库。\n· ♻️ 可将此卡放回牌库顶。\n· 👆 反应步可从手牌直接打出。\n· ⚡ 本回合每翻一张牌,速度加 1。\n· 因压力牌、推进或⚡效果而翻牌时，只有速度值为1至4的基础速度牌能够确定速度；翻出的升级卡直接弃置。\n传奇车手(Legends,可选):\n· 由牌堆自动驾驶的虚拟对手,与玩家一起随机混入发车格。\n· 每回合第一辆传奇车行动时,揭示一张全员共用的传奇卡。\n· 传奇车已经越过传奇线时，按下一处弯道的限速加上传奇卡菱形数值的结果前进；一次移动不能跨越两条弯线。传奇线位于弯道前7格。\n· 传奇车尚未越过传奇线时，按顶速前进；如果将越过弯线，则停在弯道前编号与菱形数值相同的格子，编号范围为0至3。\n· 传奇车不参与滑流、不耗热、不冷却;判定末位肾上腺素时计入车数,但自身不受益。\n· 传奇牌堆抽空时立即重洗。",
			round: "第 {{n}} 回合",
			roundShort: "回合",
			draftRoundShort: "轮次",
			garageHeader: "维修区",
			standings: "车手名次",
			driverReady: "已提交",
			legendDriver: "传奇车手",
			phase: "赛事阶段",
			phasePlan: "规划",
			phaseRace: "行动",
			phaseFinish: "冲线",
			nextCorner: "下一弯",
			cornerDistance: "距离 {{n}} 格",
			camera: "切换镜头",
			cameraFollow: "跟车",
			cameraBend: "下一弯",
			cameraOverview: "总览",
			graphicsUnavailable: "当前设备无法显示 3D 赛道，请使用支持 WebGL 的浏览器。",
			handLabel: "手牌",
			speedPreview: "预计速度",
			trackUsa: "美国",
			trackIta: "意大利",
			trackFra: "法国",
			trackGbr: "英国",
			laps: "{{n}} 圈",
			heatPool: "热量 {{n}}",
			trackLabel: "赛道",
			garageLabel: "改装(Garage)",
			garageOff: "关闭",
			garageBasic: "基础卡池",
			garageAll: "全卡池",
			legendsLabel: "传奇车手(Legends)",
			legendsOff: "关",
			legendCardTitle: "本轮传奇卡",
			legendG: "传奇·绿",
			legendR: "传奇·红",
			legendY: "传奇·黄",
			legendB: "传奇·蓝",
			legendW: "传奇·白",
			legendK: "传奇·黑",
			draftRound: "选秀 {{n}}/3",
			draftYourPick: "轮到你:选一张升级卡",
			draftWaiting: "等 {{name}} 选卡…",
			draftPool: "牌池剩 {{n}} 张",
			draftMyPicks: "我的改装",
			planPrompt: "换挡并打出 {{n}} 张牌",
			planPickCards: "选择 {{n}} 张牌打出",
			planSubmit: "确认打出",
			planWaiting: "已打出,等其他车手…",
			gearLabel: "{{n}} 档",
			gearShort: "档位",
			engineShort: "引擎热量",
			gearShift2: "连换两档:支付 1 点热量",
			resolving: "结算中…",
			yourMove: "轮到你行动",
			waitingMove: "等 {{name}} 行动…",
			cooldown: "冷却 {{n}}",
			boost: "推进",
			boostDone: "已推进 {{n}} 格",
			adrSpeed: "肾上腺素速度加 1",
			reactConfirm: "完成行动",
			choiceConfirm: "确认数值",
			salvageTitle: "从弃牌堆取回卡牌(洗回牌库)",
			refreshTitle: "放回牌库顶的卡",
			overlayDone: "选好了",
			slipPrompt: "滑流前进 {{n}} 格?",
			slipTake: "滑流",
			slipSkip: "不滑",
			discardPrompt: "可弃掉不要的手牌",
			discardConfirm: "结束回合",
			speedLabel: "速度 {{n}}",
			cornerDist: "距弯 {{n}} · 限速 {{limit}}",
			spinOut: "打滑!",
			finished: "已冲线",
			engineHeat: "引擎 {{n}}",
			deckCount: "牌库 {{n}}",
			logMove: "{{name}} 前进 {{n}} 格",
			logPay: "{{name}} 过弯支付 {{n}} 热量",
			logSpin: "{{name}} 超速打滑",
			logSlip: "{{name}} 滑流前进 2 格",
			logBoost: "{{name}} 推进 {{n}} 格",
			logCool: "{{name}} 冷却 {{n}} 点热量",
			logShift2: "{{name}} 连换两档",
			logFinish: "{{name}} 冲线",
			errNotYourTurn: "现在轮不到你",
			errBadGear: "不能这样换挡",
			errNoHeat: "引擎热量不足",
			errBadCards: "不能打出/弃掉这些牌",
			errBadStep: "当前不能进行此操作",
			errBadCool: "冷却量超出限制"
		},
		en: {
			name: "Heat",
			desc: "Shift gears, manage engine heat, mind the corners",
			rules: "Goal: first to complete the required laps wins; same-round finishers rank by distance past the line, then by racing-line position.\nSetup:\n· Pick a track (length, laps and corner speed limits differ); cars fill grid slots behind the start line in a random pole order.\n· Each deck has 18 cards: three each of speeds 1-4, Coast (0), Full Send (5), an Extra Heat, and three Stress cards.\n· Draw a starting hand of 7.\n· Your engine holds (the track’s Heat minus one) Heat cards; the last one enters the deck as the Extra Heat card.\n· Extra Heat plays as speed 0, and becomes ordinary Heat once cooled into the engine.\nPlay: everyone acts at once each round, then cars resolve from front to back.\n· Plan: shift gears and play face-down as many cards as your gear; shifting one gear is free, shifting two first costs 1 Heat from the engine.\n· Reveal: all cards flip; each Stress card flips the top of your deck until a basic 1-4 speed card sets its value.\n· Any other cards flipped this way go to the discard; move your total speed, and full landing spaces drop you back.\n· React: the rearmost driver gains 1 adrenaline speed; in gear 1 you may cool 3, in gear 2 cool 1.\n· Cooling returns that many Heat cards from hand to the engine; you may also pay 1 Heat to flip the top card and move (Boost).\n· Slipstream: if your landing space holds another car, or sits directly behind one, you may move 2 more spaces.\n· Slipstream never counts for corner speeding, never triggers corner checks, and may not cross the finish line.\n· Discard: discard any cards you like (Heat and Stress cannot be discarded); then draw back up to 7.\nCorners: for each corner line you cross, pay Heat from the engine equal to your excess speed.\n· If you cannot pay, you spin out: drop to the first open space before the line, take 1-2 Stress cards by gear, and reset to gear 1.\nEnd: once every driver has finished, rank by finishing order.\nGarage (optional):\n· Before the race, draft upgrades in 3 snake rounds (back marker, then leader, then back marker picks first); each market has as many cards as players plus 3.\n· Leftover market cards are discarded and refreshed between rounds; your 3 drafted cards replace the starting upgrades and are shuffled into your deck.\n· The starting upgrades are Coast, Full Send and Extra Heat.\n· Upgrade symbols: 🔥 must pay 1 Heat when played (if you cannot, discard it and flip for a value instead).\n· 🗑️ discard the shown number of cards from the top of your deck.\n· ⏱️ adjust the first corner’s speed limit this round by the shown amount.\n· ❄️ cool the shown amount after playing.\n· 🧘 during React you may discard the shown number of Stress cards.\n· 💨 Increase your slipstream distance by the number of spaces shown.\n· 🎣 take the shown number of cards from your discard and shuffle them into your deck.\n· ♻️ return this card to the top of your deck.\n· 👆 during React you may play it directly from hand.\n· ⚡ this turn, gain 1 speed for each card flipped.\n· Flipping (Stress/Boost/⚡) only counts basic 1-4 speed cards; flipped upgrades are discarded.\nLegends (optional):\n· Legends are rivals controlled by a deck. Randomly place them in the starting grid together with the players.\n· When the first Legend moves each round, one shared Legends card is revealed.\n· If a Legend is past the Legends Line, located seven spaces before the corner, move it by the upcoming corner’s speed limit plus the card’s diamond value. A Legend never crosses two corner lines in one move.\n· If a Legend has not passed the Legends Line, move it at top speed. If this would cross the corner line, stop it on the numbered space before the corner matching the diamond value, from 0 to 3.\n· Legends never slipstream, use Heat, or cool down; they count toward the field for adrenaline but gain no benefit themselves.\n· The Legends deck reshuffles as soon as it runs out.",
			round: "Round {{n}}",
			roundShort: "ROUND",
			draftRoundShort: "PICK",
			garageHeader: "GARAGE",
			standings: "Driver standings",
			driverReady: "Ready",
			legendDriver: "Legend",
			phase: "Race phase",
			phasePlan: "Plan",
			phaseRace: "Drive",
			phaseFinish: "Finish",
			nextCorner: "Next bend",
			cornerDistance: "{{n}} spaces",
			camera: "Switch camera",
			cameraFollow: "Follow",
			cameraBend: "Next bend",
			cameraOverview: "Overview",
			graphicsUnavailable: "This device cannot display the 3D track. Use a browser with WebGL support.",
			handLabel: "Hand",
			speedPreview: "Est. speed",
			trackUsa: "USA",
			trackIta: "Italy",
			trackFra: "France",
			trackGbr: "Great Britain",
			laps: "{{n}} laps",
			heatPool: "Heat {{n}}",
			trackLabel: "Track",
			garageLabel: "Garage",
			garageOff: "Off",
			garageBasic: "Basic pool",
			garageAll: "Full pool",
			legendsLabel: "Legends",
			legendsOff: "Off",
			legendCardTitle: "Legends card",
			legendG: "Legend Green",
			legendR: "Legend Red",
			legendY: "Legend Yellow",
			legendB: "Legend Blue",
			legendW: "Legend White",
			legendK: "Legend Black",
			draftRound: "Draft {{n}}/3",
			draftYourPick: "Your pick: take an upgrade",
			draftWaiting: "Waiting for {{name}} to pick…",
			draftPool: "{{n}} left in the pool",
			draftMyPicks: "My upgrades",
			planPrompt: "Shift gears and choose {{n}} to play",
			planPickCards: "Pick {{n}} cards to play",
			planSubmit: "Confirm",
			planWaiting: "Played — waiting for others…",
			gearLabel: "Gear {{n}}",
			gearShort: "Gear",
			engineShort: "Engine heat",
			gearShift2: "Double shift: pay 1 Heat",
			resolving: "Resolving…",
			yourMove: "Your move",
			waitingMove: "Waiting for {{name}}…",
			cooldown: "Cool {{n}}",
			boost: "Boost",
			boostDone: "Boosted {{n}}",
			adrSpeed: "Adrenaline: 1 extra speed",
			reactConfirm: "Done",
			choiceConfirm: "Set values",
			salvageTitle: "Take cards back from your discard (shuffle into deck)",
			refreshTitle: "Return to the top of your deck",
			overlayDone: "Done",
			slipPrompt: "Slipstream {{n}} spaces?",
			slipTake: "Slipstream",
			slipSkip: "Skip",
			discardPrompt: "Discard any cards you like",
			discardConfirm: "End turn",
			speedLabel: "Speed {{n}}",
			cornerDist: "Corner in {{n}} · limit {{limit}}",
			spinOut: "Spin out!",
			finished: "Finished",
			engineHeat: "Engine {{n}}",
			deckCount: "Deck {{n}}",
			logMove: "{{name}} moved {{n}}",
			logPay: "{{name}} paid {{n}} Heat in a corner",
			logSpin: "{{name}} spun out",
			logSlip: "{{name}} slipstreamed 2 spaces",
			logBoost: "{{name}} boosted {{n}}",
			logCool: "{{name}} cooled {{n}} Heat",
			logShift2: "{{name}} double-shifted",
			logFinish: "{{name}} finished",
			errNotYourTurn: "Not your move right now",
			errBadGear: "Cannot shift like that",
			errNoHeat: "Not enough Heat in the engine",
			errBadCards: "Cannot play/discard those cards",
			errBadStep: "Not allowed right now",
			errBadCool: "Cooling above the limit"
		}
	}
};
//#endregion
export { Yt as default };
