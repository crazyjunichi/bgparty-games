import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { Fragment as l, jsx as u, jsxs as d } from "react/jsx-runtime";
import { Confetti as f } from "@bgparty/sdk/ui/confetti";
import { GameOverScreen as p } from "@bgparty/sdk/ui/game-over-screen";
import { seatName as m } from "@bgparty/sdk/ui/player-strip";
//#region src/games/hanamikoji/cards.ts
var h = [
	2,
	2,
	2,
	3,
	3,
	4,
	5
], g = [
	"secret",
	"discard",
	"gift",
	"competition"
], _ = [
	"#cb7891",
	"#b9504b",
	"#c9a351",
	"#5a8d69",
	"#4f6081",
	"#8d75a0",
	"#4a9690"
];
function v() {
	return h.flatMap((e, t) => Array(e).fill(t));
}
//#endregion
//#region src/games/hanamikoji/meta.ts
var y = {
	id: "hanamikoji",
	tier: "beta",
	mechanics: ["hand-management", "area-control"],
	interactionTags: [],
	nameKey: "games.hanamikoji.name",
	descKey: "games.hanamikoji.desc",
	rulesKey: "games.hanamikoji.rules",
	icon: "🌸",
	iconImg: "games/hanamikoji.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/hanamikoji/en.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#8d344a",
	releasedAt: "2026-09-30",
	search: {
		py: "hua jian xiao lu",
		init: "hjxl"
	},
	hotseat: "cover"
}, b = t.int().min(0).max(6), x = t.string(), S = t.enum([
	"secret",
	"discard",
	"gift",
	"competition"
]), C = t.tuple([t.int().nonnegative(), t.int().nonnegative()]), w = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("secret"),
		index: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("discard"),
		indices: C
	}),
	t.object({
		type: t.literal("gift"),
		indices: t.tuple([
			t.int().nonnegative(),
			t.int().nonnegative(),
			t.int().nonnegative()
		])
	}),
	t.object({
		type: t.literal("competition"),
		groups: t.tuple([C, C])
	}),
	t.object({
		type: t.literal("chooseGift"),
		choice: t.int().min(0).max(2)
	}),
	t.object({
		type: t.literal("chooseCompetition"),
		group: t.int().min(0).max(1)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), T = t.discriminatedUnion("kind", [t.object({
	kind: t.literal("gift"),
	by: x,
	cards: t.tuple([
		b,
		b,
		b
	])
}), t.object({
	kind: t.literal("competition"),
	by: x,
	groups: t.tuple([t.tuple([b, b]), t.tuple([b, b])])
})]), E = t.object({
	players: t.tuple([x, x]),
	round: t.int().min(1),
	phase: t.enum([
		"play",
		"offer",
		"reveal",
		"score",
		"check",
		"roundEnd",
		"done"
	]),
	turn: x.nullable(),
	deckCount: t.int().nonnegative(),
	handCounts: t.record(x, t.int().nonnegative()),
	used: t.record(x, t.array(S)),
	markers: t.array(x.nullable()).length(7),
	placed: t.record(x, t.array(t.int().nonnegative()).length(7)),
	pending: T.nullable(),
	revealed: t.record(x, b.nullable()).nullable(),
	scoreIndex: t.int().min(0).max(7),
	scores: t.record(x, t.int().nonnegative()),
	geishaCounts: t.record(x, t.int().nonnegative()),
	winner: x.nullable()
}), D = t.object({
	hand: t.array(b),
	secret: b.nullable(),
	discarded: t.array(b)
}), O = {
	reveal: 1e3,
	score: 620,
	check: 700,
	roundEnd: 2200
}, k = (e, t) => e.players[0] === t ? e.players[1] : e.players[0];
function A(t, n) {
	for (let r = n.length - 1; r > 0; --r) {
		let i = e(t.seed, t.rngCursor, r + 1);
		t.rngCursor += 1, [n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function j(e, t) {
	e.turn = t;
	let n = e.deck.pop();
	return n === void 0 ? [] : (e.hands[t].push(n), [{
		kind: "draw",
		rid: t,
		for: [t],
		secret: { card: n }
	}]);
}
function M(e) {
	let t = A(e, v());
	e.removed = t.pop() ?? null, e.hands = Object.fromEntries(e.players.map((e) => [e, []]));
	for (let n = 0; n < 6; n += 1) for (let n of e.players) e.hands[n].push(t.pop());
	return e.deck = t, e.secret = Object.fromEntries(e.players.map((e) => [e, null])), e.discarded = Object.fromEntries(e.players.map((e) => [e, []])), e.used = Object.fromEntries(e.players.map((e) => [e, []])), e.placed = Object.fromEntries(e.players.map((e) => [e, Array(7).fill(0)])), e.pending = null, e.revealed = null, e.scoreIndex = 0, e.winner = null, e.phase = "play", [{
		kind: "roundStart",
		data: { round: e.round }
	}, ...j(e, e.first)];
}
function N(e) {
	let t = Object.fromEntries(e.players.map((e) => [e, 0])), n = Object.fromEntries(e.players.map((e) => [e, 0]));
	return e.markers.forEach((e, r) => {
		e && (t[e] += h[r], n[e] += 1);
	}), {
		scores: t,
		counts: n
	};
}
function P(e, t) {
	return e.players.every((t) => e.used[t].length === g.length) ? (e.phase = "reveal", e.turn = null, []) : j(e, k(e, t));
}
function F(e, t, n) {
	let r = e.hands[t];
	if (new Set(n).size !== n.length || n.some((e) => e < 0 || e >= r.length)) return null;
	let i = n.map((e) => r[e]), a = new Set(n);
	return e.hands[t] = r.filter((e, t) => !a.has(t)), i;
}
function I(t, n, r) {
	let i = {
		players: n,
		round: 1,
		first: n[e(r, 0, 2)],
		phase: "play",
		turn: null,
		deck: [],
		removed: null,
		hands: {},
		secret: {},
		discarded: {},
		used: {},
		placed: {},
		markers: Array(7).fill(null),
		pending: null,
		revealed: null,
		scoreIndex: 0,
		winner: null,
		seed: r,
		rngCursor: 1
	};
	return {
		state: i,
		fx: M(i)
	};
}
function L(e, t, n) {
	if (t.type === "tick") {
		if (![
			"reveal",
			"score",
			"check",
			"roundEnd"
		].includes(e.phase)) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		if (t.phase === "reveal") {
			let e = {};
			for (let n of t.players) {
				let r = t.secret[n];
				e[n] = r, r !== null && (t.placed[n][r] += 1);
			}
			return t.revealed = e, t.phase = "score", {
				state: t,
				fx: [{
					kind: "reveal",
					data: { revealed: e }
				}]
			};
		}
		if (t.phase === "score") {
			let e = t.scoreIndex, n = t.markers[e], r = t.placed[t.players[0]][e], i = t.placed[t.players[1]][e];
			return r > i && (t.markers[e] = t.players[0]), i > r && (t.markers[e] = t.players[1]), t.scoreIndex += 1, t.scoreIndex === 7 && (t.phase = "check"), {
				state: t,
				fx: [{
					kind: "scoreGeisha",
					data: {
						index: e,
						before: n,
						after: t.markers[e]
					}
				}]
			};
		}
		if (t.phase === "check") {
			let { scores: e, counts: n } = N(t);
			return t.winner = t.players.find((t) => e[t] >= 11) ?? t.players.find((e) => n[e] >= 4) ?? null, t.phase = t.winner ? "done" : "roundEnd", {
				state: t,
				fx: [{
					kind: "roundEnd",
					data: {
						round: t.round,
						winner: t.winner,
						scores: e
					}
				}]
			};
		}
		return t.round += 1, t.first = k(t, t.first), {
			state: t,
			fx: M(t)
		};
	}
	if (e.phase === "offer") {
		let r = e.pending;
		if (!r || n.by !== k(e, r.by)) return { code: "games.hanamikoji.errNotYourTurn" };
		let i = structuredClone(e), a = i.pending, o = a.by, s = n.by;
		if (a.kind === "gift" && t.type === "chooseGift") a.cards.forEach((e, n) => {
			i.placed[n === t.choice ? s : o][e] += 1;
		});
		else if (a.kind === "competition" && t.type === "chooseCompetition") a.groups.forEach((e, n) => e.forEach((e) => {
			i.placed[n === t.group ? s : o][e] += 1;
		}));
		else return { code: "games.hanamikoji.errWrongPhase" };
		return i.pending = null, i.phase = "play", {
			state: i,
			fx: [{
				kind: "offerResolved",
				data: {
					actor: o,
					chooser: s
				}
			}, ...P(i, o)]
		};
	}
	if (e.phase !== "play") return { code: "games.hanamikoji.errWrongPhase" };
	if (n.by !== e.turn) return { code: "games.hanamikoji.errNotYourTurn" };
	if (t.type === "chooseGift" || t.type === "chooseCompetition") return { code: "games.hanamikoji.errWrongPhase" };
	if (e.used[n.by].includes(t.type)) return { code: "games.hanamikoji.errActionUsed" };
	let r = structuredClone(e), i = n.by, a = t.type, o;
	o = t.type === "secret" ? [t.index] : t.type === "discard" || t.type === "gift" ? t.indices : t.groups.flat();
	let s = F(r, i, o);
	return s ? (r.used[i].push(a), t.type === "secret" ? (r.secret[i] = s[0], {
		state: r,
		fx: [{
			kind: "secret",
			rid: i
		}, ...P(r, i)]
	}) : t.type === "discard" ? (r.discarded[i] = s, {
		state: r,
		fx: [{
			kind: "discard",
			rid: i
		}, ...P(r, i)]
	}) : t.type === "gift" ? (r.pending = {
		kind: "gift",
		by: i,
		cards: s
	}, r.phase = "offer", r.turn = k(r, i), {
		state: r,
		fx: [{
			kind: "offer",
			rid: i,
			data: {
				kind: "gift",
				cards: s
			}
		}]
	}) : (r.pending = {
		kind: "competition",
		by: i,
		groups: [[s[0], s[1]], [s[2], s[3]]]
	}, r.phase = "offer", r.turn = k(r, i), {
		state: r,
		fx: [{
			kind: "offer",
			rid: i,
			data: {
				kind: "competition",
				cards: s
			}
		}]
	})) : { code: "games.hanamikoji.errBadCards" };
}
function R(e, t) {
	let { scores: n, counts: r } = N(e);
	return {
		public: {
			players: e.players,
			round: e.round,
			phase: e.phase,
			turn: e.turn,
			deckCount: e.deck.length,
			handCounts: Object.fromEntries(e.players.map((t) => [t, e.hands[t].length])),
			used: e.used,
			markers: e.markers,
			placed: e.placed,
			pending: e.pending,
			revealed: e.revealed,
			scoreIndex: e.scoreIndex,
			scores: n,
			geishaCounts: r,
			winner: e.winner
		},
		private: {
			hand: e.hands[t],
			secret: e.secret[t],
			discarded: e.discarded[t]
		}
	};
}
function z(e) {
	return e.phase !== "done" || !e.winner ? { phase: e.phase } : {
		phase: e.phase,
		winner: [e.winner],
		ranking: [e.winner, k(e, e.winner)],
		scores: N(e).scores
	};
}
function ee(e) {
	return e.phase === "reveal" ? O.reveal : e.phase === "score" ? O.score : e.phase === "check" ? O.check : e.phase === "roundEnd" ? O.roundEnd : null;
}
var te = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: y,
	schemas: {
		action: w,
		publicView: E,
		privateView: D
	},
	setup: I,
	reduce: L,
	viewFor: R,
	status: z,
	nextTickIn: ee
}, B = {
	secret: "games.hanamikoji.action.secret",
	discard: "games.hanamikoji.action.discard",
	gift: "games.hanamikoji.action.gift",
	competition: "games.hanamikoji.action.competition"
}, ne = {
	secret: "games.hanamikoji.submitSecret",
	discard: "games.hanamikoji.submitDiscard",
	gift: "games.hanamikoji.submitGift",
	competition: "games.hanamikoji.submitCompetition"
}, V = {
	secret: 1,
	discard: 2,
	gift: 3,
	competition: 4
};
function H({ card: e, selected: t, onClick: n, label: r, groupLabel: i, anchorName: o }) {
	let { ref: s } = a(o ?? null), c = /* @__PURE__ */ d(l, { children: [
		/* @__PURE__ */ u("span", {
			className: "hm-item-color",
			style: { background: _[e] }
		}),
		/* @__PURE__ */ u("span", {
			className: "hm-item-flower",
			style: { color: _[e] },
			children: "✿"
		}),
		/* @__PURE__ */ u("span", {
			className: "hm-item-value",
			children: h[e]
		}),
		t && /* @__PURE__ */ u("span", {
			className: "hm-item-seal",
			children: i ?? "✓"
		})
	] });
	return n ? /* @__PURE__ */ u("button", {
		ref: s,
		type: "button",
		className: `hm-item ${t ? "hm-item--selected" : ""}`,
		onClick: n,
		"aria-label": r,
		"aria-pressed": t,
		children: c
	}) : /* @__PURE__ */ u("span", {
		ref: s,
		className: `hm-item ${t ? "hm-item--selected" : ""}`,
		children: c
	});
}
function U({ i: e, pub: t, myRid: n, t: r, fx: i = !0 }) {
	let o = t.players.find((e) => e !== n), s = t.markers[e], { ref: c } = a(i ? `hm-owner:${e}:${s ?? "neutral"}` : null), { ref: l } = a(i ? `hm-count:${n}:${e}` : null), { ref: f } = a(i ? `hm-count:${o}:${e}` : null), p = t.phase === "score" || t.phase === "check" ? t.scoreIndex - 1 : -1, m = s === n ? r("games.hanamikoji.mineSeal") : s === o ? r("games.hanamikoji.opponentSeal") : "·";
	return /* @__PURE__ */ d("div", {
		className: `hm-geisha ${p === e ? "hm-geisha--scoring" : ""}`,
		style: { "--hm-tone": _[e] },
		children: [
			/* @__PURE__ */ d("div", {
				className: "hm-geisha-top",
				children: [/* @__PURE__ */ d("span", {
					className: "hm-geisha-value",
					children: [h[e], /* @__PURE__ */ u("small", { children: r("games.hanamikoji.pointShort") })]
				}), /* @__PURE__ */ u("span", {
					ref: c,
					className: `hm-owner ${s === n ? "hm-owner--mine" : s === o ? "hm-owner--rival" : ""}`,
					"aria-label": s === n ? r("games.hanamikoji.you") : s === o ? r("games.hanamikoji.opponent") : void 0,
					children: m
				})]
			}),
			/* @__PURE__ */ u("img", {
				className: "hm-geisha-art",
				src: `games/hanamikoji/portrait-${e}.webp`,
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ d("div", {
				className: "hm-geisha-count hm-geisha-count--rival",
				children: [/* @__PURE__ */ u("span", { children: r("games.hanamikoji.opponentSeal") }), /* @__PURE__ */ u("strong", {
					ref: f,
					children: t.placed[o][e]
				})]
			}),
			/* @__PURE__ */ d("div", {
				className: "hm-geisha-count hm-geisha-count--mine",
				children: [/* @__PURE__ */ u("span", { children: r("games.hanamikoji.mineSeal") }), /* @__PURE__ */ u("strong", {
					ref: l,
					children: t.placed[n][e]
				})]
			})
		]
	});
}
function W(e) {
	let t = e.public, n = e.private, r = `${t.round}|${t.phase}|${t.turn}|${n?.hand.join(",") ?? ""}|${t.pending?.kind ?? ""}`;
	return /* @__PURE__ */ u(re, {
		pub: t,
		priv: n,
		myRid: e.myRid,
		send: e.send
	}, r);
}
function re({ pub: e, priv: t, myRid: n, send: r }) {
	let a = s(), o = e.players.find((e) => e !== n), f = e.phase === "play" && e.turn === n, p = e.phase === "offer" && e.turn === n, [m, _] = i(null), [v, y] = i([]), [b, x] = i([]), [S, C] = i(null), [w, T] = i(!1), E = t?.hand ?? [], D = [
		"reveal",
		"score",
		"check",
		"roundEnd",
		"done"
	].includes(e.phase), O = t?.secret != null || (t?.discarded.length ?? 0) > 0, k = m ? V[m] : 0, A = m === "competition" && v.length === 4, j = (t) => {
		f && !e.used[n].includes(t) && (_(t), y([]), x([]));
	}, M = (e) => {
		if (f && m) {
			if (A) {
				if (!v.includes(e)) return;
				x((t) => t.includes(e) ? t.filter((t) => t !== e) : t.length < 2 ? [...t, e] : t);
				return;
			}
			y((t) => t.includes(e) ? t.filter((t) => t !== e) : t.length < k ? [...t, e] : t);
		}
	}, N = () => {
		if (p && e.pending && S !== null) {
			r(e.pending.kind === "gift" ? {
				type: "chooseGift",
				choice: S
			} : {
				type: "chooseCompetition",
				group: S
			});
			return;
		}
		if (!f || !m || v.length !== k) return;
		let t;
		if (m === "secret") t = {
			type: "secret",
			index: v[0]
		};
		else if (m === "discard") t = {
			type: "discard",
			indices: v
		};
		else if (m === "gift") t = {
			type: "gift",
			indices: v
		};
		else {
			if (b.length !== 2) return;
			t = {
				type: "competition",
				groups: [b, v.filter((e) => !b.includes(e))]
			};
		}
		r(t);
	}, P;
	P = e.phase === "offer" ? a(p ? e.pending?.kind === "gift" ? "games.hanamikoji.chooseGift" : "games.hanamikoji.chooseCompetition" : "games.hanamikoji.waitOffer") : e.phase === "play" ? a(f ? "games.hanamikoji.turnYou" : "games.hanamikoji.turnWait") : e.phase === "reveal" ? a("games.hanamikoji.revealPhase") : e.phase === "score" || e.phase === "check" ? a("games.hanamikoji.scorePhase") : a(e.phase === "done" ? "games.hanamikoji.done" : "games.hanamikoji.roundEnd");
	let F = /* @__PURE__ */ d("div", {
		className: "hm-header",
		children: [
			/* @__PURE__ */ d("div", {
				className: "hm-title-row",
				children: [
					/* @__PURE__ */ u("h2", { children: a("games.hanamikoji.name") }),
					/* @__PURE__ */ u("button", {
						type: "button",
						className: "hm-archive-link",
						disabled: !O,
						onClick: () => T(!0),
						children: a("games.hanamikoji.archiveTitle")
					}),
					/* @__PURE__ */ u("span", {
						className: "hm-round",
						children: a("games.hanamikoji.round", { n: e.round })
					})
				]
			}),
			/* @__PURE__ */ d("div", {
				className: "hm-notice",
				children: [/* @__PURE__ */ u("strong", { children: P }), /* @__PURE__ */ u("span", { children: a("games.hanamikoji.deckLeft", { n: e.deckCount }) })]
			}),
			/* @__PURE__ */ u("div", {
				className: "hm-scores",
				children: [n, o].map((t) => /* @__PURE__ */ d("div", {
					className: "hm-score",
					children: [/* @__PURE__ */ u("b", {
						className: t === n ? "hm-score-seal hm-score-seal--mine" : "hm-score-seal hm-score-seal--rival",
						children: a(t === n ? "games.hanamikoji.mineSeal" : "games.hanamikoji.opponentSeal")
					}), /* @__PURE__ */ d("span", { children: [/* @__PURE__ */ u("strong", { children: a(t === n ? "games.hanamikoji.you" : "games.hanamikoji.opponent") }), /* @__PURE__ */ d("small", { children: [
						a("games.hanamikoji.pointCount", { n: e.scores[t] }),
						" · ",
						a("games.hanamikoji.geishaCount", { n: e.geishaCounts[t] })
					] })] })]
				}, t))
			})
		]
	}), I = e.pending, L = p && I, R, z = !1;
	return L ? (R = a(I.kind === "gift" ? "games.hanamikoji.confirmGift" : "games.hanamikoji.confirmCompetition"), z = S !== null) : f && m ? (R = a(ne[m]), z = v.length === k && (m !== "competition" || b.length === 2)) : R = f ? a("games.hanamikoji.chooseAction") : P, /* @__PURE__ */ d("div", {
		className: "hm-scene",
		style: { backgroundImage: "linear-gradient(#26151b22, #26151b33), url('games/hanamikoji/tabletop.webp')" },
		children: [/* @__PURE__ */ u(c, {
			adaptive: !0,
			className: "hm-adaptive",
			banner: F,
			actionsHeight: "hm-actions-height",
			actions: /* @__PURE__ */ d("button", {
				type: "button",
				className: "hm-submit",
				disabled: !z,
				onClick: N,
				children: [R, /* @__PURE__ */ u("span", {
					"aria-hidden": !0,
					children: "→"
				})]
			}),
			scroll: !1,
			children: /* @__PURE__ */ d("div", {
				className: "hm-main",
				children: [/* @__PURE__ */ d("section", {
					className: "hm-table",
					"aria-label": a("games.hanamikoji.tableTitle"),
					children: [/* @__PURE__ */ d("div", {
						className: "hm-section-label",
						children: [/* @__PURE__ */ u("span", { children: a("games.hanamikoji.tableTitle") }), /* @__PURE__ */ u("small", { children: a("games.hanamikoji.tableHint") })]
					}), /* @__PURE__ */ d("div", {
						className: "hm-geisha-rows",
						children: [/* @__PURE__ */ u("div", {
							className: "hm-geisha-row",
							children: [
								0,
								1,
								2,
								3
							].map((t) => /* @__PURE__ */ u(U, {
								i: t,
								pub: e,
								myRid: n,
								t: a
							}, t))
						}), /* @__PURE__ */ u("div", {
							className: "hm-geisha-row",
							children: [
								4,
								5,
								6
							].map((t) => /* @__PURE__ */ u(U, {
								i: t,
								pub: e,
								myRid: n,
								t: a
							}, t))
						})]
					})]
				}), /* @__PURE__ */ d("div", {
					className: "hm-side",
					children: [/* @__PURE__ */ d("section", {
						className: "hm-actions",
						"aria-label": a("games.hanamikoji.actionTitle"),
						children: [/* @__PURE__ */ d("div", {
							className: "hm-section-label",
							children: [/* @__PURE__ */ u("span", { children: a("games.hanamikoji.actionTitle") }), /* @__PURE__ */ u("small", { children: a("games.hanamikoji.actionHint") })]
						}), /* @__PURE__ */ u("div", {
							className: "hm-action-row",
							children: g.map((t) => /* @__PURE__ */ d("button", {
								type: "button",
								className: `hm-action ${e.used[n].includes(t) ? "hm-action--used" : ""} ${m === t ? "hm-action--active" : ""}`,
								disabled: !f || e.used[n].includes(t),
								onClick: () => j(t),
								"aria-pressed": m === t,
								children: [/* @__PURE__ */ u("b", { children: V[t] }), /* @__PURE__ */ u("span", { children: a(B[t]) })]
							}, t))
						})]
					}), /* @__PURE__ */ d("section", {
						className: "hm-hand",
						children: [/* @__PURE__ */ d("div", {
							className: "hm-section-label",
							children: [/* @__PURE__ */ u("span", { children: a(D ? "games.hanamikoji.secretArea" : L ? "games.hanamikoji.offerTitle" : "games.hanamikoji.hand") }), !D && /* @__PURE__ */ u("small", { children: L ? a(I.kind === "gift" ? "games.hanamikoji.offerHintGift" : "games.hanamikoji.offerHintCompetition") : a("games.hanamikoji.handCount", { n: E.length }) })]
						}), D ? /* @__PURE__ */ u("div", {
							className: "hm-reveal-row",
							children: e.players.map((t) => {
								let r = e.revealed?.[t];
								return /* @__PURE__ */ d("div", {
									className: "hm-reveal-slot",
									children: [/* @__PURE__ */ u("span", { children: a(t === n ? "games.hanamikoji.you" : "games.hanamikoji.opponent") }), r == null ? /* @__PURE__ */ u("span", {
										className: "hm-item hm-item--back",
										role: "img",
										"aria-label": a("games.hanamikoji.hidden"),
										children: /* @__PURE__ */ u("span", {
											"aria-hidden": !0,
											children: "✿"
										})
									}) : /* @__PURE__ */ u(H, {
										card: r,
										anchorName: `hm-revealed:${t}:${r}`
									})]
								}, t);
							})
						}) : L ? I.kind === "gift" ? /* @__PURE__ */ u("div", {
							className: "hm-item-row hm-item-row--offer",
							children: I.cards.map((e, t) => /* @__PURE__ */ u(H, {
								card: e,
								selected: S === t,
								onClick: () => C(t),
								label: `${a("games.hanamikoji.chooseGift")} ${t + 1}`
							}, t))
						}) : /* @__PURE__ */ u("div", {
							className: "hm-pair-row",
							children: I.groups.map((e, t) => /* @__PURE__ */ d("button", {
								type: "button",
								className: `hm-pair ${S === t ? "hm-pair--selected" : ""}`,
								onClick: () => C(t),
								children: [/* @__PURE__ */ u("span", { children: a(t === 0 ? "games.hanamikoji.groupA" : "games.hanamikoji.groupB") }), /* @__PURE__ */ u("span", {
									className: "hm-pair-cards",
									children: e.map((e, t) => /* @__PURE__ */ u(H, { card: e }, t))
								})]
							}, t))
						}) : /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("div", {
							className: "hm-item-row",
							"data-count": E.length,
							children: E.map((e, t) => /* @__PURE__ */ u(H, {
								card: e,
								selected: v.includes(t),
								groupLabel: A && v.includes(t) ? b.includes(t) ? "1" : b.length === 2 ? "2" : "?" : void 0,
								onClick: f && m ? () => M(t) : void 0,
								label: `${a("games.hanamikoji.hand")} ${t + 1}`
							}, t))
						}), /* @__PURE__ */ u("div", {
							className: "hm-hand-help",
							children: A ? /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("span", { children: a("games.hanamikoji.chooseGroups") }), /* @__PURE__ */ u("button", {
								type: "button",
								onClick: () => {
									y([]), x([]);
								},
								children: a("games.hanamikoji.resetSelection")
							})] }) : f && m ? a("games.hanamikoji.selected", {
								n: v.length,
								need: k
							}) : t?.secret == null ? "" : `${a("games.hanamikoji.secretArea")}: ${h[t.secret]}`
						})] })]
					})]
				})]
			})
		}), w && /* @__PURE__ */ u("div", {
			className: "hm-archive-shade",
			children: /* @__PURE__ */ d("div", {
				className: "hm-archive-sheet",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": a("games.hanamikoji.archiveTitle"),
				children: [
					/* @__PURE__ */ d("div", {
						className: "hm-archive-head",
						children: [/* @__PURE__ */ u("h3", { children: a("games.hanamikoji.archiveTitle") }), /* @__PURE__ */ u("button", {
							type: "button",
							onClick: () => T(!1),
							"aria-label": a("games.hanamikoji.closeArchive"),
							children: "×"
						})]
					}),
					t?.secret != null && /* @__PURE__ */ d("div", {
						className: "hm-archive-section",
						children: [/* @__PURE__ */ u("span", { children: a("games.hanamikoji.secretArea") }), /* @__PURE__ */ u(H, { card: t.secret })]
					}),
					(t?.discarded.length ?? 0) > 0 && /* @__PURE__ */ d("div", {
						className: "hm-archive-section",
						children: [/* @__PURE__ */ u("span", { children: a("games.hanamikoji.discardedArea") }), /* @__PURE__ */ u("div", {
							className: "hm-archive-cards",
							children: t?.discarded.map((e, t) => /* @__PURE__ */ u(H, { card: e }, t))
						})]
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/games/hanamikoji/bot.ts
function G(e) {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e;
}
function K(e, t, n) {
	let r = e.players.find((e) => e !== t), i = e.placed[t][n] - e.placed[r][n], a = e.markers[n], o = i < -1 ? .35 : i === -1 ? .9 : i === 0 ? a === r ? 1.6 : 1.35 : i === 1 ? .75 : .3;
	return h[n] * o;
}
function q(e, t) {
	let n = [];
	function r(i, a) {
		if (a.length === t) {
			n.push(a);
			return;
		}
		for (let n = i; n <= e.length - (t - a.length); n += 1) r(n + 1, [...a, e[n]]);
	}
	return r(0, []), n;
}
function J(e, t) {
	let n = [...e], r = [];
	for (let e = 0; e < t; e += 1) r.push(n.splice(G(n.length), 1)[0]);
	return r;
}
var Y = (e, t) => {
	let n = e.public, r = t.rid;
	if (n.phase === "offer" && n.turn === r && n.pending) {
		if (n.pending.kind === "gift") {
			let e = n.pending.cards.map((e) => K(n, r, e));
			return { action: {
				type: "chooseGift",
				choice: t.difficulty === "weak" ? G(3) : e.indexOf(Math.max(...e))
			} };
		}
		let e = n.pending.groups.map((e) => e.reduce((e, t) => e + K(n, r, t), 0));
		return { action: {
			type: "chooseCompetition",
			group: t.difficulty === "weak" ? G(2) : e.indexOf(Math.max(...e))
		} };
	}
	if (n.phase !== "play" || n.turn !== r) return null;
	let i = e.private?.hand ?? [], a = [
		"discard",
		"secret",
		"gift",
		"competition"
	].filter((e) => !n.used[r].includes(e));
	if (!a.length) return null;
	let o = t.difficulty === "weak" ? a[G(a.length)] : a[0], s = i.map((e, t) => t), c = n.players.find((e) => e !== r);
	if (o === "secret") return { action: {
		type: "secret",
		index: t.difficulty === "weak" ? G(i.length) : s.reduce((e, t) => K(n, r, i[t]) > K(n, r, i[e]) ? t : e, 0)
	} };
	if (o === "discard") return { action: {
		type: "discard",
		indices: t.difficulty === "weak" ? J(s, 2) : [...s].sort((e, t) => K(n, r, i[e]) - K(n, r, i[t])).slice(0, 2)
	} };
	if (o === "gift") {
		if (t.difficulty === "weak") return { action: {
			type: "gift",
			indices: J(s, 3)
		} };
		let e = s.slice(0, 3), a = -Infinity;
		for (let t of q(s, 3)) {
			let o = Math.min(...t.map((e) => t.filter((t) => t !== e).reduce((e, t) => e + K(n, r, i[t]), 0) - K(n, c, i[e])));
			o > a && (a = o, e = t);
		}
		return { action: {
			type: "gift",
			indices: e
		} };
	}
	if (t.difficulty === "weak") {
		let e = J(s, 4);
		return { action: {
			type: "competition",
			groups: [[e[0], e[1]], [e[2], e[3]]]
		} };
	}
	let l = [s.slice(0, 2), s.slice(2, 4)], u = -Infinity;
	for (let e of q(s, 4)) for (let t of q(e, 2)) {
		let a = e.filter((e) => !t.includes(e)), o = a.reduce((e, t) => e + K(n, r, i[t]), 0) - t.reduce((e, t) => e + K(n, c, i[t]), 0), s = t.reduce((e, t) => e + K(n, r, i[t]), 0) - a.reduce((e, t) => e + K(n, c, i[t]), 0), d = Math.min(o, s);
		d > u && (u = d, l = [t, a]);
	}
	return { action: {
		type: "competition",
		groups: [l[0], l[1]]
	} };
}, X = Math.floor(O.score * .8);
function ie({ boxes: e }) {
	let t = r(null);
	return n(() => {
		let e = t.current;
		if (!e) return;
		let n = Array.from(e.children).map((e) => e.animate([
			{ opacity: 0 },
			{
				opacity: .95,
				offset: .3
			},
			{
				opacity: .3,
				offset: .6
			},
			{ opacity: 0 }
		], {
			duration: X,
			easing: "ease-out",
			fill: "both"
		})), r = () => {
			n.forEach((e) => e.cancel()), e.style.visibility = "hidden";
		}, i = e.parentElement, a = i?.getBoundingClientRect(), o = new ResizeObserver((e) => {
			a && e.some((e) => Math.abs(e.contentRect.width - a.width) > .5 || Math.abs(e.contentRect.height - a.height) > .5) && r();
		});
		return i && o.observe(i), window.addEventListener("resize", r), window.visualViewport?.addEventListener("resize", r), () => {
			n.forEach((e) => e.cancel()), o.disconnect(), window.removeEventListener("resize", r), window.visualViewport?.removeEventListener("resize", r);
		};
	}, [e]), /* @__PURE__ */ u("div", {
		ref: t,
		className: "absolute inset-0",
		children: e.map((e, t) => /* @__PURE__ */ u("div", {
			className: "absolute",
			style: {
				left: e.x,
				top: e.y,
				width: e.w,
				height: e.h,
				border: "2px solid #f3d082",
				boxShadow: "0 0 0 1px #8d344a",
				borderRadius: 3,
				opacity: 0
			}
		}, t))
	});
}
function Z(e) {
	return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}
function ae(e) {
	return typeof e == "number" && Number.isInteger(e) && e >= 0 && e <= 6;
}
function Q(e) {
	return e === null || typeof e == "string" && e.length > 0;
}
function $(e, t) {
	if (e.queued > 0 || t.length === 0) return null;
	let n = [];
	for (let r of new Set(t)) {
		let t = e.anchor(r);
		if (!t || ![
			t.x,
			t.y,
			t.w,
			t.h
		].every(Number.isFinite) || t.w <= 0 || t.h <= 0) return null;
		n.push(t);
	}
	return {
		ms: X,
		node: /* @__PURE__ */ u(ie, { boxes: n })
	};
}
var oe = {
	reveal(e, t) {
		let n = Z(Z(e.data)?.revealed);
		if (!n || Object.keys(n).length !== 2) return null;
		let r = [];
		for (let [e, t] of Object.entries(n)) {
			if (!e) return null;
			if (t !== null) {
				if (!ae(t)) return null;
				r.push(`hm-revealed:${e}:${t}`, `hm-count:${e}:${t}`);
			}
		}
		return $(t, r);
	},
	scoreGeisha(e, t) {
		let n = Z(e.data), r = n?.index;
		return typeof r != "number" || !Number.isInteger(r) || r < 0 || r > 6 || !Q(n?.before) || !Q(n?.after) ? null : $(t, [`hm-owner:${r}:${n.after ?? "neutral"}`]);
	}
};
//#endregion
//#region src/games/hanamikoji/game-over.tsx
function se({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let c = s(), l = o((e) => e.locale), h = /* @__PURE__ */ u(p, {
		result: e,
		members: n,
		myRid: r,
		accent: y.accent,
		onPlayAgain: i,
		onBackToLobby: a
	}), g = E.safeParse(t);
	if (!g.success) return h;
	let _ = g.data;
	if (_.phase !== "done" || !_.winner || !_.players.includes(_.winner) || e.ranking.length !== 2 || new Set(e.ranking).size !== 2 || e.ranking.some((e) => !_.players.includes(e))) return h;
	let v = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? m(t, l) : e;
	}, b = i ?? a, x = _.players.flatMap((e) => {
		let t = _.revealed?.[e];
		return t == null ? [] : [{
			rid: e,
			card: t
		}];
	});
	return /* @__PURE__ */ d("div", {
		className: "hm-over",
		style: { backgroundImage: "linear-gradient(#26151b22, #26151b33), url('games/hanamikoji/tabletop.webp')" },
		children: [e.winner.length > 0 && /* @__PURE__ */ u(f, {}), /* @__PURE__ */ d("div", {
			className: "hm-over-layout",
			children: [
				/* @__PURE__ */ d("h1", {
					className: "hm-over-title",
					children: [
						/* @__PURE__ */ u("span", {
							"aria-hidden": !0,
							children: y.icon
						}),
						c("session.result.title"),
						/* @__PURE__ */ u("span", {
							className: "hm-over-round",
							children: c("games.hanamikoji.round", { n: _.round })
						})
					]
				}),
				/* @__PURE__ */ d("div", {
					className: "hm-over-content",
					children: [/* @__PURE__ */ d("section", {
						className: "hm-over-table",
						"aria-label": c("games.hanamikoji.tableTitle"),
						children: [/* @__PURE__ */ u("div", {
							className: "hm-section-label",
							children: /* @__PURE__ */ u("span", { children: c("games.hanamikoji.tableTitle") })
						}), /* @__PURE__ */ u("div", {
							className: "hm-over-geishas",
							children: _.markers.map((e, t) => /* @__PURE__ */ u(U, {
								i: t,
								pub: _,
								myRid: r,
								t: c,
								fx: !1
							}, t))
						})]
					}), /* @__PURE__ */ d("div", {
						className: "hm-over-summary",
						children: [e.ranking.map((t, n) => /* @__PURE__ */ d("section", {
							className: "hm-over-player",
							"data-won": e.winner.includes(t),
							children: [
								/* @__PURE__ */ d("header", { children: [
									e.winner.includes(t) && /* @__PURE__ */ u("span", {
										"aria-hidden": !0,
										children: "🏆"
									}),
									/* @__PURE__ */ d("strong", { children: [
										n + 1,
										". ",
										v(t)
									] }),
									t === r && /* @__PURE__ */ u("small", { children: c("games.hanamikoji.you") })
								] }),
								/* @__PURE__ */ d("div", {
									className: "hm-over-points",
									children: [/* @__PURE__ */ u("strong", { children: c("games.hanamikoji.pointCount", { n: e.scores?.[t] ?? _.scores[t] }) }), /* @__PURE__ */ u("span", { children: c("games.hanamikoji.geishaCount", { n: _.geishaCounts[t] }) })]
								}),
								(e.autopilot?.[t] ?? 0) > 0 && /* @__PURE__ */ u("span", {
									className: "hm-over-autopilot",
									children: c("session.autopilot.share", { n: Math.round((e.autopilot?.[t] ?? 0) * 100) })
								})
							]
						}, t)), x.length > 0 && /* @__PURE__ */ d("section", {
							className: "hm-over-secret",
							children: [/* @__PURE__ */ u("h2", { children: c("games.hanamikoji.secretArea") }), /* @__PURE__ */ u("div", {
								className: "hm-over-revealed",
								children: x.map(({ rid: e, card: t }) => /* @__PURE__ */ d("div", {
									className: "hm-reveal-slot",
									children: [/* @__PURE__ */ u("span", { children: v(e) }), /* @__PURE__ */ u(H, { card: t })]
								}, e))
							})]
						})]
					})]
				}),
				b ? /* @__PURE__ */ d("div", {
					className: "hm-over-controls safe-b",
					children: [i && /* @__PURE__ */ u("button", {
						type: "button",
						onClick: i,
						children: c("session.result.playAgain")
					}), a && /* @__PURE__ */ u("button", {
						type: "button",
						onClick: a,
						children: c("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ u("p", {
					className: "hm-over-wait safe-b",
					children: c("session.result.waitHost")
				})
			]
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/hanamikoji/entry.tsx
var ce = {
	definition: te,
	View: W,
	bot: Y,
	fx: oe,
	OverView: se,
	locales: {
		zh: {
			name: "花见小路",
			desc: "在七位艺伎之间争取支持的双人卡牌对决",
			rules: "目标:\n· 每轮争取艺伎的支持;取得至少 4 位艺伎或 11 点魅力值时获胜。\n准备:\n· 七位艺伎的魅力值依次为 2、2、2、3、3、4、5;对应物品牌共 21 张。\n· 每轮暗中移除 1 张物品牌,双方各获得 6 张,其余 8 张形成牌堆。\n流程:\n· 双方轮流摸 1 张牌,再使用一枚尚未用过的行动牌;每种行动每轮各用一次。\n· 密藏:从手牌暗放 1 张,轮末揭开并计入己方。\n· 弃置:从手牌暗放 2 张,本轮不计分。\n· 赠礼:亮出 3 张手牌,对手选 1 张归自己,其余 2 张归你。\n· 竞争:亮出 4 张手牌并分成两组,对手选一组归自己,另一组归你。\n结算:\n· 双方揭开密藏牌,逐位比较各自获得的对应物品牌数量;较多的一方获得该艺伎。\n· 双方数量相同时,该艺伎的归属标记留在原处。\n· 若无人达成胜利条件,归属标记保留,全部 21 张牌重新洗牌,并交换先手。\n· 一方获得 4 位艺伎、另一方同时获得至少 11 点时,11 点的一方获胜。",
			round: "第 {{n}} 轮",
			turnYou: "轮到你 · 选择行动",
			turnWait: "等待对手行动",
			chooseGift: "从赠礼中选择 1 张",
			chooseCompetition: "从竞争中选择 1 组",
			waitOffer: "等待对手选择",
			revealPhase: "揭开密藏牌",
			scorePhase: "正在结算七位艺伎",
			roundEnd: "本轮结束",
			done: "对局结束",
			you: "我方",
			opponent: "对手",
			mineSeal: "我",
			opponentSeal: "对",
			pointCount: "{{n}} 点",
			pointShort: "点",
			geishaCount: "{{n}} 席",
			tableTitle: "七位艺伎",
			tableHint: "圆章表示归属 · 数字表示本轮出牌",
			actionTitle: "四枚行动牌",
			actionHint: "每轮各用一次",
			hand: "我的手牌",
			handCount: "{{n}} 张",
			offerTitle: "对手展示的牌",
			offerHintGift: "选 1 张归你,其余归对手",
			offerHintCompetition: "选 1 组归你,另一组归对手",
			selected: "已选 {{n}} / {{need}} 张",
			resetSelection: "重选",
			chooseAction: "先选择一枚行动牌",
			chooseHand: "从手牌选择 {{n}} 张",
			chooseGroups: "先选 4 张,再点牌分成两组",
			groupA: "第一组",
			groupB: "第二组",
			groupSize: "{{n}} / 2 张",
			submitSecret: "封存这 1 张",
			submitDiscard: "弃置这 2 张",
			submitGift: "展示这 3 张",
			submitCompetition: "展示这两组",
			confirmGift: "确认领取这张",
			confirmCompetition: "确认领取这组",
			secretArea: "密藏牌",
			discardedArea: "弃置牌",
			archiveTitle: "封存牌",
			closeArchive: "关闭封存牌",
			hidden: "背面",
			deckLeft: "牌堆剩 {{n}} 张",
			action: {
				secret: "密藏",
				discard: "弃置",
				gift: "赠礼",
				competition: "竞争"
			},
			errNotYourTurn: "现在轮不到你",
			errWrongPhase: "当前不能执行这个行动",
			errActionUsed: "这枚行动牌本轮已使用",
			errBadCards: "请选择正确数量且不重复的手牌"
		},
		en: {
			name: "Hanamikoji",
			desc: "A two-player card duel for the favor of seven geisha",
			rules: "Goal:\n· Win the favor of at least 4 geisha or 11 Charm Points at the end of a round.\nSetup:\n· The seven geisha are worth 2, 2, 2, 3, 3, 4 and 5 points; there are 21 matching Item Cards.\n· Remove 1 Item Card unseen each round, deal 6 to each player and leave 8 in the deck.\nPlay:\n· Take turns drawing 1 card, then use one unused Action Marker; each action is used once per round.\n· Secret: place 1 hand card face down; reveal it at round end and score it for yourself.\n· Trade-off: place 2 hand cards face down; neither scores this round.\n· Gift: reveal 3 hand cards; your rival takes 1 and you take the other 2.\n· Competition: reveal 4 hand cards in two pairs; your rival takes one pair and you take the other.\nScoring:\n· Reveal both Secret cards and compare matching Item Cards beside each geisha; the side with more wins her favor.\n· On a tie, the Victory Marker stays where it was.\n· If nobody wins, keep the markers, reshuffle all 21 cards and alternate the starting player.\n· If one player controls 4 geisha while the other has at least 11 points, the 11-point player wins.",
			round: "Round {{n}}",
			turnYou: "Your turn · choose an action",
			turnWait: "Waiting for your rival",
			chooseGift: "Choose 1 card from the gift",
			chooseCompetition: "Choose 1 competition pair",
			waitOffer: "Waiting for your rival to choose",
			revealPhase: "Revealing Secret cards",
			scorePhase: "Scoring the seven geisha",
			roundEnd: "Round complete",
			done: "Game over",
			you: "You",
			opponent: "Rival",
			mineSeal: "Me",
			opponentSeal: "R",
			pointCount: "{{n}} points",
			pointShort: "pt",
			geishaCount: "{{n}} geisha",
			tableTitle: "Seven geisha",
			tableHint: "Seals show favor · numbers show cards this round",
			actionTitle: "Four action markers",
			actionHint: "Use each once per round",
			hand: "Your hand",
			handCount: "{{n}} cards",
			offerTitle: "Cards offered by your rival",
			offerHintGift: "Take 1 card; your rival keeps the rest",
			offerHintCompetition: "Take 1 pair; your rival keeps the other",
			selected: "{{n}} / {{need}} selected",
			resetSelection: "Reset",
			chooseAction: "Choose an action marker first",
			chooseHand: "Choose {{n}} hand cards",
			chooseGroups: "Choose 4 cards, then divide them into two pairs",
			groupA: "Pair A",
			groupB: "Pair B",
			groupSize: "{{n}} / 2 cards",
			submitSecret: "Seal this card",
			submitDiscard: "Discard these 2",
			submitGift: "Offer these 3",
			submitCompetition: "Offer these pairs",
			confirmGift: "Take this card",
			confirmCompetition: "Take this pair",
			secretArea: "Secret card",
			discardedArea: "Trade-off cards",
			archiveTitle: "Set-aside cards",
			closeArchive: "Close set-aside cards",
			hidden: "Face down",
			deckLeft: "{{n}} cards in deck",
			action: {
				secret: "Secret",
				discard: "Trade-off",
				gift: "Gift",
				competition: "Competition"
			},
			errNotYourTurn: "It is not your turn",
			errWrongPhase: "This action is not available now",
			errActionUsed: "This action was already used this round",
			errBadCards: "Choose the correct number of distinct cards"
		}
	}
};
//#endregion
export { ce as default };
