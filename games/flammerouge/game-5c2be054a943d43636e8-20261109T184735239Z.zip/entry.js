import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { seatName as f } from "@bgparty/sdk/ui/player-strip";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { SheetFxProbe as g, SheetView as _ } from "@bgparty/sdk/sheet-view";
import { Floater as v, PulseBox as y } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as b, OptionSection as x } from "@bgparty/sdk/ui/game-options";
//#region src/games/flammerouge/data.ts
var S = [
	{
		name: "Avenue Corso Paseo",
		tiles: "abcdefghijklmnopqrstu"
	},
	{
		name: "Ronde van Wevelgem",
		tiles: "abcmgfteqonLPjkIDHrSu"
	},
	{
		name: "La Classicissima",
		tiles: "AebQRNHPcgikDFsLojmtu"
	},
	{
		name: "Ballons Centrale",
		tiles: "AnLHgceqtrMBiopjDFkSu"
	},
	{
		name: "Firenze–Milano",
		tiles: "abcgiDHqntmKOLrepJsfu"
	},
	{
		name: "La Haut Montagne",
		tiles: "abcfimetKGLHJsdopRQNU"
	}
], C = ["rouleur", "sprinteur"], w = {
	rouleur: [
		3,
		4,
		5,
		6,
		7
	],
	sprinteur: [
		2,
		3,
		4,
		5,
		9
	]
}, T = "abcdflmnu", E = {
	A: "ffffff",
	B: "ddddff",
	C: "fffuuu",
	D: "uuuuud",
	E: "uu",
	F: "dddfff",
	G: "uu",
	H: "dd",
	I: "ff",
	J: "ff",
	K: "uu",
	L: "uuuddd",
	M: "ffuuuu",
	N: "uuuuuu",
	O: "uu",
	P: "dd",
	Q: "uu",
	R: "uu",
	S: "ff",
	T: "ff",
	U: "uuffff"
};
function D(e) {
	return [...e].flatMap((e) => [...E[e] ?? "f".repeat(T.includes(e) ? 6 : 2)].map((t, n) => ({
		tile: e,
		offset: n,
		terrain: t === "u" ? "up" : t === "d" ? "down" : "flat"
	})));
}
var O = (e, t) => `${e}:${t}`, k = {
	id: "flammerouge",
	tier: "alpha",
	mechanics: [
		"race",
		"hand-management",
		"action-programming"
	],
	interactionTags: [],
	nameKey: "games.flammerouge.name",
	descKey: "games.flammerouge.desc",
	rulesKey: "games.flammerouge.rules",
	icon: "🚴",
	iconImg: "games/flammerouge.webp",
	rulesUrl: { en: "https://tesera.ru/images/items/992848/Flamme_Rouge_rulebook_2016-04-27.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#a52b25",
	releasedAt: "2026-11-10T02:20:00+08:00",
	search: {
		py: "chi yan ji su",
		init: "cyjs"
	},
	hotseat: "cover",
	botDelayMs: 450
}, A = t.enum(["rouleur", "sprinteur"]), j = t.string().refine((e) => e.length === 21 && e[0].toLowerCase() === "a" && e[20].toLowerCase() === "u" && [...e.toLowerCase()].sort().join("") === "abcdefghijklmnopqrstu"), M = t.object({
	stage: t.int().min(0).max(6).default(0),
	custom: j.default("abcdefghijklmnopqrstu"),
	handicap: t.int().min(0).max(2).default(0)
}).prefault({}), N = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		kind: A,
		position: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("draw"),
		kind: A
	}),
	t.object({
		type: t.literal("play"),
		index: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), P = t.object({
	value: t.int().min(2).max(9),
	exhaustion: t.boolean()
}), F = t.object({
	key: t.string(),
	rid: t.string(),
	kind: A,
	position: t.int().min(-1),
	lane: t.int().min(0).max(1)
}), I = t.object({
	round: t.int(),
	type: t.enum([
		"move",
		"slip",
		"exhaustion"
	]),
	keys: t.array(t.string()),
	from: t.array(t.int()),
	to: t.array(t.int()),
	value: t.int().optional()
}), L = t.object({
	players: t.array(t.string()),
	stage: t.int(),
	tiles: t.string(),
	round: t.int(),
	phase: t.enum([
		"setup",
		"energy",
		"reveal",
		"move",
		"slip",
		"exhaustion",
		"done"
	]),
	actor: t.string().nullable(),
	riders: t.array(F),
	ready: t.record(t.string(), t.boolean()),
	revealed: t.record(t.string(), P.nullable()),
	decks: t.record(t.string(), t.object({
		draw: t.int(),
		recycled: t.int(),
		removed: t.int(),
		fatigue: t.int()
	})),
	queue: t.array(t.string()),
	event: I.nullable(),
	log: t.array(I)
}), R = t.object({
	active: A.nullable(),
	hand: t.array(P),
	selected: t.object({
		rouleur: P.nullable(),
		sprinteur: P.nullable()
	}),
	completed: t.array(A),
	recycled: t.object({
		rouleur: t.array(P),
		sprinteur: t.array(P)
	})
}), z = {
	reveal: 1150,
	move: 760,
	slip: 850,
	exhaustion: 1e3
}, B = () => ({
	value: 2,
	exhaustion: !0
});
function ee(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.rngCursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var te = () => ({
	active: null,
	hand: [],
	completed: [],
	selected: {
		rouleur: null,
		sprinteur: null
	}
});
function ne(e, t, n) {
	let r = M.parse(e), i = {
		players: [...t],
		stage: r.stage,
		tiles: r.stage === 6 ? r.custom : S[r.stage].tiles,
		seed: n,
		rngCursor: 0,
		round: 1,
		phase: "setup",
		riders: [],
		decks: {},
		selections: {},
		queue: [],
		slipIndex: 0,
		event: null,
		log: [],
		beatMs: 0
	};
	for (let e of t) {
		i.selections[e] = te();
		for (let t of C) {
			let n = O(e, t);
			i.riders.push({
				rid: e,
				kind: t,
				key: n,
				position: -1,
				lane: 0
			}), i.decks[n] = {
				draw: ee(i, [...w[t].flatMap((e) => Array.from({ length: 3 }, () => ({
					value: e,
					exhaustion: !1
				}))), ...Array.from({ length: r.handicap }, B)]),
				recycled: [],
				removed: 0,
				fatigue: r.handicap
			};
		}
	}
	return { state: i };
}
var V = (e) => [...e].sort((e, t) => t.position - e.position || e.lane - t.lane);
function H(e, t, n) {
	let r = n[e]?.terrain === "down" ? Math.max(5, t) : t, i = Array.from({ length: r + 1 }, (e, t) => t).find((t) => n[e + t]?.terrain === "up");
	return i !== void 0 && (r = i <= 5 ? Math.min(r, 5) : Math.min(r, i - 1)), e + r;
}
function re(e, t, n) {
	for (; e.riders.some((e) => e.key !== t.key && e.position === n && e.lane === 0) && e.riders.some((e) => e.key !== t.key && e.position === n && e.lane === 1);) n--;
	t.position = n, t.lane = +!!e.riders.some((e) => e.key !== t.key && e.position === n && e.lane === 0);
}
function ie(e, t) {
	let n = [];
	for (let r of [...e.riders].sort((e, t) => e.position - t.position || e.lane - t.lane)) {
		let e = n.at(-1);
		e && r.position <= e.at(-1).position + 1 && t[r.position]?.terrain !== "up" && t[e.at(-1).position]?.terrain !== "up" ? e.push(r) : n.push([r]);
	}
	return n;
}
function U(e, t) {
	let n = {
		...t,
		round: e.round
	};
	return e.event = n, e.log.push(n), {
		kind: t.type,
		data: n
	};
}
function ae(e) {
	let t = D(e.tiles);
	if (e.phase === "reveal" && (e.phase = "move"), e.phase === "move") {
		let n = e.queue.shift();
		if (n) {
			let r = e.riders.find((e) => e.key === n), i = r.position, a = e.selections[r.rid].selected[r.kind];
			return a && (e.decks[n].removed++, re(e, r, H(i, a.value, t))), e.beatMs = z.move, e.queue.length === 0 && (e.phase = "slip", e.slipIndex = 0), [U(e, {
				type: "move",
				keys: [n],
				from: [i],
				to: [r.position],
				value: a?.value ?? 0
			})];
		}
		e.phase = "slip";
	}
	if (e.phase === "slip") {
		let n = ie(e, t);
		for (; e.slipIndex < n.length - 1;) {
			let r = n[e.slipIndex], i = n[e.slipIndex + 1], a = r.at(-1), o = i[0];
			if (o.position - a.position === 2 && !r.some((e) => t[e.position]?.terrain === "up") && t[o.position]?.terrain !== "up") {
				let t = r.map((e) => e.position);
				for (let e of r) e.position++;
				return e.beatMs = z.slip, [U(e, {
					type: "slip",
					keys: r.map((e) => e.key),
					from: t,
					to: r.map((e) => e.position)
				})];
			}
			e.slipIndex++;
		}
		e.phase = "exhaustion";
		let r = e.riders.filter((t) => !e.riders.some((e) => e.position === t.position + 1));
		for (let t of r) e.decks[t.key].recycled.push(B()), e.decks[t.key].fatigue++;
		return e.beatMs = z.exhaustion, [U(e, {
			type: "exhaustion",
			keys: r.map((e) => e.key),
			from: [],
			to: []
		})];
	}
	if (e.phase === "exhaustion") {
		if (e.riders.some((e) => e.position >= 74)) e.phase = "done";
		else {
			e.round++, e.phase = "energy", e.event = null;
			for (let t of e.players) e.selections[t] = te();
		}
	}
	return [];
}
function oe(e) {
	return e.phase === "setup" ? e.players.find((t) => e.riders.some((e) => e.rid === t && e.position < 0)) ?? null : null;
}
function se(e, t, n) {
	if (t.type === "tick") {
		if (n.by !== "$engine") return { code: "games.flammerouge.errAction" };
		if (![
			"reveal",
			"move",
			"slip",
			"exhaustion"
		].includes(e.phase)) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return {
			state: t,
			fx: ae(t)
		};
	}
	if (!e.players.includes(n.by)) return { code: "games.flammerouge.errAction" };
	if (t.type === "place") {
		let r = e.riders.find((e) => e.rid === n.by && e.kind === t.kind);
		if (oe(e) !== n.by || !r || r.position >= 0 || e.riders.filter((e) => e.position === t.position).length >= 2) return { code: "games.flammerouge.errPlace" };
		let i = structuredClone(e);
		return re(i, i.riders.find((e) => e.key === W(n.by, t.kind)), t.position), i.riders.every((e) => e.position >= 0) && (i.phase = "energy"), {
			state: i,
			fx: []
		};
	}
	if (e.phase !== "energy") return { code: "games.flammerouge.errAction" };
	let r = e.selections[n.by];
	if (t.type === "draw") {
		if (r.active || r.completed.includes(t.kind)) return { code: "games.flammerouge.errAction" };
		let i = structuredClone(e), a = i.selections[n.by], o = i.decks[W(n.by, t.kind)];
		for (a.active = t.kind; a.hand.length < 4 && o.draw.length + o.recycled.length > 0;) o.draw.length || (o.draw = ee(i, o.recycled), o.recycled = []), a.hand.push(o.draw.shift());
		return a.hand.length || (a.completed.push(t.kind), a.active = null), ce(i), {
			state: i,
			fx: []
		};
	}
	if (!r.active || !r.hand[t.index]) return { code: "games.flammerouge.errCard" };
	let i = structuredClone(e), a = i.selections[n.by], o = a.active;
	return a.selected[o] = a.hand[t.index], i.decks[W(n.by, o)].recycled.push(...a.hand.filter((e, n) => n !== t.index)), a.completed.push(o), a.active = null, a.hand = [], ce(i), {
		state: i,
		fx: i.phase === "reveal" ? [{
			kind: "reveal",
			data: {}
		}] : []
	};
}
var W = O;
function ce(e) {
	e.players.every((t) => e.selections[t].completed.length === 2) && (e.phase = "reveal", e.queue = V(e.riders).map((e) => e.key), e.beatMs = z.reveal);
}
function le(e, t) {
	let n = e.selections[t], r = e.phase !== "energy" && e.phase !== "setup";
	return {
		public: {
			players: e.players,
			stage: e.stage,
			tiles: e.tiles,
			round: e.round,
			phase: e.phase,
			actor: oe(e),
			riders: e.riders,
			ready: Object.fromEntries(e.players.map((t) => [t, e.selections[t].completed.length === 2])),
			revealed: r ? Object.fromEntries(e.riders.map((t) => [t.key, e.selections[t.rid].selected[t.kind]])) : {},
			decks: Object.fromEntries(Object.entries(e.decks).map(([e, t]) => [e, {
				draw: t.draw.length,
				recycled: t.recycled.length,
				removed: t.removed,
				fatigue: t.fatigue
			}])),
			queue: e.queue,
			event: e.event,
			log: e.log
		},
		private: {
			active: n?.active ?? null,
			hand: n?.hand ?? [],
			selected: n?.selected ?? {
				rouleur: null,
				sprinteur: null
			},
			completed: n?.completed ?? [],
			recycled: {
				rouleur: e.decks[W(t, "rouleur")]?.recycled ?? [],
				sprinteur: e.decks[W(t, "sprinteur")]?.recycled ?? []
			}
		}
	};
}
var ue = {
	meta: k,
	saveCompatibility: { version: "1" },
	schemas: {
		action: N,
		publicView: L,
		privateView: R,
		config: M
	},
	setup: ne,
	reduce: se,
	viewFor: le,
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = V(e.riders), n = [...new Set(t.map((e) => e.rid))];
		return {
			phase: "done",
			winner: [n[0]],
			ranking: n,
			scores: Object.fromEntries(n.map((e) => [e, t.find((t) => t.rid === e).position - 74 + 1]))
		};
	},
	nextTickIn: (e) => [
		"reveal",
		"move",
		"slip",
		"exhaustion"
	].includes(e.phase) ? e.beatMs : null
}, G = {
	rouleur: "games.flammerouge.rouleur",
	sprinteur: "games.flammerouge.sprinteur"
};
function K({ kind: e }) {
	return /* @__PURE__ */ m("span", {
		className: "fr-kind",
		"data-kind": e,
		"aria-hidden": !0,
		children: e === "rouleur" ? "R" : "S"
	});
}
function q({ kind: e, size: t = 38 }) {
	return /* @__PURE__ */ h("svg", {
		width: t,
		height: t * .8,
		viewBox: "0 0 60 48",
		fill: "none",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ m("circle", {
				cx: "13",
				cy: "35",
				r: "10",
				stroke: "currentColor",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "47",
				cy: "35",
				r: "10",
				stroke: "currentColor",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ m("path", {
				d: "M13 35 24 18 32 35H13L37 22 47 35M24 18H18M37 22 39 14H46",
				stroke: "currentColor",
				strokeWidth: "2.5",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ m("path", {
				d: e === "rouleur" ? "M34 12 25 17 30 25 23 35M27 17 38 18" : "M35 10 27 16 32 23 24 34M27 16 40 18",
				stroke: "currentColor",
				strokeWidth: "5",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ m("circle", {
				cx: e === "rouleur" ? 36 : 37,
				cy: "6",
				r: "5",
				fill: "currentColor"
			})
		]
	});
}
function J({ card: e, kind: t, selected: n = !1, style: r }) {
	return /* @__PURE__ */ h("div", {
		className: "fr-card",
		"data-exhaustion": e.exhaustion,
		"data-selected": n,
		style: r,
		children: [
			/* @__PURE__ */ m("img", {
				className: "fr-card-art",
				src: `games/flammerouge/${t}.webp`,
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ m("b", {
				className: "fr-value fr-value-left",
				children: e.value
			}),
			/* @__PURE__ */ m("b", {
				className: "fr-value fr-value-right",
				children: e.value
			}),
			/* @__PURE__ */ h("span", {
				className: "fr-card-bottom",
				children: [
					/* @__PURE__ */ m(K, { kind: t }),
					e.exhaustion && /* @__PURE__ */ m("span", {
						className: "fr-fatigue-mark",
						"aria-hidden": !0,
						children: "≈"
					}),
					/* @__PURE__ */ m(K, { kind: t })
				]
			})
		]
	});
}
//#endregion
//#region src/games/flammerouge/track-layout.ts
var Y = 1260, X = 960, Z = 75, Q = Math.PI * Z, de = (4 * X + 3 * Q) / 84;
function $(e, t) {
	let n = (e + .5) * de;
	for (let e = 0; e < 4; e++) {
		let r = e % 2 == 0 ? 1 : -1, i = 105 + e * 150;
		if (n <= X || e === 3) return {
			x: r === 1 ? 150 + n : 1110 - n,
			y: i + (t === void 0 ? 0 : (t === 0 ? 19 : -19) * r),
			angle: r === 1 ? 0 : 180
		};
		if (n -= X, n <= Q) {
			let e = -Math.PI / 2 + n / Z, a = Z + (t === void 0 ? 0 : (t === 0 ? -19 : 19) * r);
			return {
				x: r === 1 ? 1110 + a * Math.cos(e) : 150 - a * Math.cos(e),
				y: i + Z + a * Math.sin(e),
				angle: r === 1 ? e * 180 / Math.PI + 90 : 90 - e * 180 / Math.PI
			};
		}
		n -= Q;
	}
	return {
		x: 150,
		y: 555,
		angle: 180
	};
}
function fe(e, t) {
	let n = $(e - .48), r = $(e + .48), i = (e) => ({
		x: -Math.sin(e * Math.PI / 180),
		y: Math.cos(e * Math.PI / 180)
	}), a = i(n.angle), o = i(r.angle), s = t === void 0 || t === 1 ? -37 : 0, c = t === void 0 || t === 0 ? 37 : 0;
	return [
		[n.x + a.x * s, n.y + a.y * s],
		[r.x + o.x * s, r.y + o.y * s],
		[r.x + o.x * c, r.y + o.y * c],
		[n.x + a.x * c, n.y + a.y * c]
	].map((e) => e.join(",")).join(" ");
}
var pe = "M150 105 H1110 A75 75 0 0 1 1110 255 H150 A75 75 0 0 0 150 405 H1110 A75 75 0 0 1 1110 555 H150";
//#endregion
//#region src/games/flammerouge/board.tsx
function me({ rider: e, members: t, duration: i, probes: o }) {
	let s = l(), d = c((e) => e.locale), _ = t.find((t) => t.rid === e.rid), v = r(null), y = r({
		position: e.position,
		lane: e.lane
	});
	if (n(() => {
		let t = y.current;
		if (y.current = {
			position: e.position,
			lane: e.lane
		}, t.position < 0 || t.position === e.position && t.lane === e.lane || !v.current || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		let n = Math.max(8, Math.abs(e.position - t.position) * 6), r = Array.from({ length: n + 1 }, (r, i) => {
			let a = i / n, o = $(t.position + (e.position - t.position) * a, a < .5 ? t.lane : e.lane);
			return {
				transform: `translate(${o.x}px, ${o.y}px)`,
				offset: a
			};
		}), a = v.current.animate(r, {
			duration: i - 90,
			easing: "ease-in-out"
		});
		return () => a.cancel();
	}, [
		e.position,
		e.lane,
		i
	]), e.position < 0) return null;
	let b = $(e.position, e.lane), x = u[(_?.colorIndex ?? 0) % u.length], S = _ ? f(_, d) : s(x.nameKey);
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("g", {
		ref: v,
		style: { transform: `translate(${b.x}px, ${b.y}px)` },
		"data-rider": e.key,
		children: [
			/* @__PURE__ */ m("title", { children: s("games.flammerouge.pickRider", {
				name: S,
				kind: s(G[e.kind])
			}) }),
			/* @__PURE__ */ m("circle", {
				r: "17",
				fill: x.hex,
				stroke: "#f8f0d9",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ m("image", {
				href: a[(_?.avatar ?? 0) % a.length],
				x: "-13",
				y: "-13",
				width: "26",
				height: "26"
			}),
			e.kind === "rouleur" ? /* @__PURE__ */ m("circle", {
				cx: "11",
				cy: "12",
				r: "8",
				fill: "#32654c",
				stroke: "#fff4d9"
			}) : /* @__PURE__ */ m("rect", {
				x: "3",
				y: "4",
				width: "16",
				height: "16",
				rx: "2",
				fill: "#486e7a",
				stroke: "#fff4d9"
			}),
			/* @__PURE__ */ m("text", {
				x: "11",
				y: "16",
				textAnchor: "middle",
				fontSize: "12",
				fontFamily: "Georgia",
				fontWeight: "bold",
				fill: "white",
				children: e.kind === "rouleur" ? "R" : "S"
			})
		]
	}), o && /* @__PURE__ */ m(g, {
		name: `rider:${e.key}`,
		r: {
			x: b.x - 17,
			y: b.y - 17,
			w: 34,
			h: 34
		}
	})] });
}
function he({ pub: e, members: t, selectedPosition: n, placing: r, onPlace: i, probes: a = !1 }) {
	let o = l(), s = D(e.tiles);
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("defs", { children: /* @__PURE__ */ m("pattern", {
			id: a ? "fr-grass-main" : "fr-grass-detail",
			width: "35",
			height: "27",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ m("path", {
				d: "m8 20 2-5 2 5m14-12 2-4 2 4",
				stroke: "#7d946d",
				opacity: ".18",
				fill: "none"
			})
		}) }),
		/* @__PURE__ */ m("rect", {
			width: Y,
			height: 680,
			rx: "16",
			fill: "#acb998"
		}),
		/* @__PURE__ */ m("rect", {
			width: Y,
			height: 680,
			fill: `url(#${a ? "fr-grass-main" : "fr-grass-detail"})`
		}),
		/* @__PURE__ */ m("path", {
			d: pe,
			fill: "none",
			stroke: "#6b795b",
			strokeWidth: "94"
		}),
		/* @__PURE__ */ m("path", {
			d: pe,
			fill: "none",
			stroke: "#555c58",
			strokeWidth: "76"
		}),
		Array.from({ length: 84 }, (t, a) => {
			let c = s[a], l = c?.terrain ?? "flat", u = $(a), d = e.riders.filter((e) => e.position === a).length, f = r && a < 5 && d < 2, p = l === "up" ? "#c65342" : l === "down" ? "#7fb8ce" : a < 6 || a >= 72 && a < 78 ? "#d5b951" : "#c3c6b5";
			return /* @__PURE__ */ h("g", { children: [
				/* @__PURE__ */ m("polygon", {
					points: fe(a),
					fill: a < 6 || a >= 72 && a < 78 ? "#bca95118" : "#ffffff03",
					stroke: p,
					strokeWidth: "2.3"
				}),
				/* @__PURE__ */ h("g", {
					transform: `translate(${u.x} ${u.y}) rotate(${u.angle})`,
					pointerEvents: "none",
					children: [
						/* @__PURE__ */ m("path", {
							d: "M-12 0H12",
							stroke: "#d4d1ba",
							strokeWidth: "1"
						}),
						/* @__PURE__ */ m("path", {
							d: "M-22 31H22M-22 35H22",
							stroke: p,
							strokeWidth: "1.7"
						}),
						c?.offset === 0 && /* @__PURE__ */ m("text", {
							x: "0",
							y: "-43",
							fontFamily: "Georgia",
							fontSize: "18",
							fontWeight: "bold",
							fill: "#3e4c36",
							textAnchor: "middle",
							transform: u.angle > 90 && u.angle < 270 ? "rotate(180 0 -48)" : void 0,
							children: c.tile
						})
					]
				}),
				f && /* @__PURE__ */ m("polygon", {
					className: "fr-legal",
					points: fe(a),
					fill: n === a ? "#f3dd7899" : "#f3dd7835",
					stroke: "#f6edc9",
					strokeWidth: "4",
					strokeDasharray: "9 5",
					children: /* @__PURE__ */ m("animate", {
						attributeName: "stroke-dashoffset",
						from: "0",
						to: "-28",
						dur: ".8s",
						repeatCount: "indefinite"
					})
				}),
				f && /* @__PURE__ */ m("polygon", {
					points: fe(a),
					fill: "transparent",
					role: "button",
					tabIndex: 0,
					"aria-label": o("games.flammerouge.selectCell", { n: a + 1 }),
					onClick: () => i(a),
					onKeyDown: (e) => {
						(e.key === "Enter" || e.key === " ") && (e.preventDefault(), i(a));
					}
				})
			] }, a);
		}),
		[{
			at: 5,
			finish: !1
		}, {
			at: 74,
			finish: !0
		}].map(({ at: e, finish: t }) => {
			let n = $(e - .5);
			return /* @__PURE__ */ h("g", {
				transform: `translate(${n.x} ${n.y}) rotate(${n.angle})`,
				children: [
					/* @__PURE__ */ m("path", {
						d: "M0 -38V38",
						stroke: t ? "#f9f2d9" : "#ead168",
						strokeWidth: "9"
					}),
					/* @__PURE__ */ m("path", {
						d: "M0 -38V38",
						stroke: "#383b36",
						strokeWidth: "9",
						strokeDasharray: "7 7"
					}),
					/* @__PURE__ */ m("path", {
						d: "M0 -48V-89L42 -81 0 -67",
						fill: t ? "#a82d27" : "#e5bc54",
						stroke: "#514c39",
						strokeWidth: "2"
					})
				]
			}, e);
		}),
		s.map((e, t) => {
			if (e.terrain === "flat" || t > 0 && s[t - 1].terrain === e.terrain) return null;
			let n = $(t), r = n.y + (n.angle > 90 && n.angle < 270 ? 60 : -60);
			return /* @__PURE__ */ h("g", {
				transform: `translate(${n.x} ${r})`,
				children: [
					/* @__PURE__ */ m("title", { children: o(e.terrain === "up" ? "games.flammerouge.up" : "games.flammerouge.down") }),
					e.terrain === "up" ? /* @__PURE__ */ m("circle", {
						r: "16",
						fill: "#f6efd6",
						stroke: "#ac362d",
						strokeWidth: "4"
					}) : /* @__PURE__ */ m("rect", {
						x: "-16",
						y: "-16",
						width: "32",
						height: "32",
						fill: "#f6efd6",
						stroke: "#42829b",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ m("text", {
						y: "6",
						textAnchor: "middle",
						fontSize: "21",
						fontFamily: "Georgia",
						fontWeight: "bold",
						fill: "#343831",
						children: "5"
					})
				]
			}, t);
		}),
		/* @__PURE__ */ m("text", {
			x: "630",
			y: "197",
			textAnchor: "middle",
			fontFamily: "Georgia",
			fontSize: "27",
			letterSpacing: "3",
			fill: "#43533d",
			children: e.stage < 6 ? S[e.stage].name.toUpperCase() : o("games.flammerouge.custom")
		}),
		/* @__PURE__ */ h("g", {
			transform: "translate(595 322)",
			fill: "#8d2f28",
			children: [/* @__PURE__ */ m("path", { d: "M0 0V46M2 0 60 12 2 31" }), /* @__PURE__ */ m("text", {
				x: "75",
				y: "30",
				fontSize: "21",
				fontFamily: "Georgia",
				letterSpacing: "2",
				children: "FLAMME ROUGE"
			})]
		}),
		e.riders.map((n) => /* @__PURE__ */ m(me, {
			rider: n,
			members: t,
			probes: a,
			duration: e.event?.type === "slip" ? z.slip : z.move
		}, n.key))
	] });
}
function ge({ pub: e, members: t, fitKey: n, selectedPosition: r, placing: i, onPlace: a, detailPosition: o }) {
	let s = $(o), c = i ? Array.from({ length: 5 }, (e, t) => t).filter((t) => e.riders.filter((e) => e.position === t).length < 2).map((e) => {
		let t = $(e);
		return {
			key: String(e),
			rect: {
				x: t.x - de * .48,
				y: t.y - 37,
				w: de * .96,
				h: 74
			}
		};
	}) : [];
	return /* @__PURE__ */ h("div", {
		className: "fr-board",
		"data-scene": "race-track",
		children: [/* @__PURE__ */ m("div", {
			className: "fr-overview",
			children: /* @__PURE__ */ m(_, {
				sheetW: Y,
				sheetH: 680,
				fitKey: n,
				clampToSheet: !0,
				eligible: c,
				onTapEligible: (e) => a(Number(e)),
				highlight: "off",
				children: /* @__PURE__ */ m(he, {
					pub: e,
					members: t,
					selectedPosition: r,
					placing: i,
					onPlace: a,
					probes: !0
				})
			})
		}), /* @__PURE__ */ m("svg", {
			className: "fr-detail-road",
			viewBox: `${s.x - 205} ${s.y - 78} 410 156`,
			children: /* @__PURE__ */ m(he, {
				pub: e,
				members: t,
				selectedPosition: r,
				placing: i,
				onPlace: a
			})
		})]
	});
}
//#endregion
//#region src/games/flammerouge/view-player.tsx
function _e(e) {
	return /* @__PURE__ */ m(ve, {
		pub: e.public,
		priv: e.private,
		...e
	});
}
function ve({ pub: e, priv: t, members: n, myRid: r, send: a, readOnly: s = !1 }) {
	let g = l(), _ = c((e) => e.locale), [v, y] = i(0), [b, x] = i(3), [w, T] = i(null), E = `${r}:${e.round}:${e.phase}:${t?.active ?? ""}`, [D, O] = i({
		scope: E,
		index: null,
		position: null,
		kind: null
	}), k = e.riders.filter((e) => e.rid === r), A = D.scope === E && D.kind && k.some((e) => e.kind === D.kind && e.position < 0) ? D.kind : k.find((e) => e.position < 0)?.kind ?? "rouleur", j = D.scope === E && D.index !== null && t?.hand[D.index] ? D.index : null, M = D.scope === E && D.position !== null && e.riders.filter((e) => e.position === D.position).length < 2 ? D.position : null, N = !s && e.phase === "setup" && e.actor === r, P = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? f(t, _) : g(u[0].nameKey);
	}, F = (e) => O({
		scope: E,
		index: j,
		position: M,
		kind: A,
		...e
	}), I = (e) => {
		F({ position: e }), x(e);
	}, L = e.phase === "setup" ? N ? g("games.flammerouge.placePrompt", { kind: g(G[A]) }) : g("games.flammerouge.placeWaiting", { name: P(e.actor ?? "") }) : e.phase === "energy" ? t?.completed.length === 2 ? g("games.flammerouge.waiting") : t?.active ? g("games.flammerouge.chooseCard", { kind: g(G[t.active]) }) : g("games.flammerouge.chooseRider") : g({
		reveal: "games.flammerouge.reveal",
		move: "games.flammerouge.moving",
		slip: "games.flammerouge.slip",
		exhaustion: "games.flammerouge.fatigue",
		done: "games.flammerouge.done"
	}[e.phase]), R = (t) => {
		let n = e.riders.find((e) => e.key === t.keys[0]);
		return t.type === "move" && n ? g("games.flammerouge.moveLog", {
			name: P(n.rid),
			kind: g(G[n.kind]),
			card: t.value ?? 0,
			n: t.to[0] - t.from[0]
		}) : t.type === "slip" ? g("games.flammerouge.slipLog", { n: t.keys.length }) : g("games.flammerouge.fatigueLog", { n: t.keys.length });
	}, z = !s && e.phase === "energy" && !!t?.active, B = w !== null && (!s || w === "log");
	return /* @__PURE__ */ h(d, {
		adaptive: !0,
		className: "fr-root",
		scroll: !1,
		actionsHeight: "fr-action-height",
		banner: /* @__PURE__ */ h("header", {
			className: "fr-header",
			children: [
				/* @__PURE__ */ h("div", {
					className: "fr-masthead",
					children: [
						/* @__PURE__ */ m("h1", { children: g("games.flammerouge.name") }),
						/* @__PURE__ */ m("span", { children: g("games.flammerouge.round", { n: e.round }) }),
						/* @__PURE__ */ m("button", {
							onClick: () => T("log"),
							children: g("games.flammerouge.log")
						})
					]
				}),
				/* @__PURE__ */ m("p", {
					className: "fr-prompt",
					"aria-live": "polite",
					children: L
				}),
				/* @__PURE__ */ m("div", {
					className: "fr-teams",
					children: e.players.map((t) => /* @__PURE__ */ m(ye, {
						rid: t,
						pub: e,
						members: n,
						mine: r === t
					}, t))
				})
			]
		}),
		actions: /* @__PURE__ */ m("div", {
			className: "fr-actions",
			children: N ? /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("div", {
					className: "fr-rider-choice",
					children: k.filter((e) => e.position < 0).map((e) => /* @__PURE__ */ h("button", {
						"data-selected": A === e.kind,
						onClick: () => F({ kind: e.kind }),
						children: [
							/* @__PURE__ */ m(q, {
								kind: e.kind,
								size: 32
							}),
							/* @__PURE__ */ m(K, { kind: e.kind }),
							/* @__PURE__ */ m("span", { children: g(G[e.kind]) })
						]
					}, e.key))
				}),
				/* @__PURE__ */ h("div", {
					className: "fr-start-display",
					children: [/* @__PURE__ */ m(q, {
						kind: A,
						size: 70
					}), /* @__PURE__ */ m("span", { children: M === null ? g("games.flammerouge.placePrompt", { kind: g(G[A]) }) : g("games.flammerouge.placeCell", {
						kind: g(G[A]),
						n: M + 1
					}) })]
				}),
				/* @__PURE__ */ m("div", {
					className: "fr-confirm",
					children: /* @__PURE__ */ m("button", {
						className: "fr-primary",
						disabled: M === null,
						onClick: () => M !== null && a({
							type: "place",
							kind: A,
							position: M
						}),
						children: g("games.flammerouge.confirmPlace")
					})
				})
			] }) : z ? /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ h("div", {
					className: "fr-hand-label",
					children: [
						/* @__PURE__ */ m(K, { kind: t.active }),
						/* @__PURE__ */ m("strong", { children: g(G[t.active]) }),
						/* @__PURE__ */ m("button", {
							onClick: () => T("decks"),
							children: g("games.flammerouge.recycled")
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: "fr-hand",
					children: t.hand.map((e, n) => /* @__PURE__ */ m("button", {
						className: "fr-card-button",
						"data-selected": j === n,
						onClick: () => F({ index: j === n ? null : n }),
						"aria-pressed": j === n,
						"aria-label": g("games.flammerouge.playAria", {
							kind: g(e.exhaustion ? "games.flammerouge.exhaustion" : "games.flammerouge.energy"),
							n: e.value
						}),
						children: /* @__PURE__ */ m(J, {
							card: e,
							kind: t.active,
							selected: j === n
						})
					}, `${E}:${n}`))
				}),
				/* @__PURE__ */ m("div", {
					className: "fr-confirm",
					children: /* @__PURE__ */ m("button", {
						className: "fr-primary",
						disabled: j === null,
						onClick: () => j !== null && a({
							type: "play",
							index: j
						}),
						children: g("games.flammerouge.play")
					})
				})
			] }) : /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ h("div", {
					className: "fr-hand-label",
					children: [/* @__PURE__ */ m("span", { children: e.stage < 6 ? S[e.stage].name : g("games.flammerouge.custom") }), !s && /* @__PURE__ */ m("button", {
						onClick: () => T("decks"),
						children: g("games.flammerouge.recycled")
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: "fr-deck-row",
					children: C.map((n) => {
						let r = k.find((e) => e.kind === n), i = t?.selected[n], o = !s && e.phase === "energy" && t && !t.completed.includes(n);
						return /* @__PURE__ */ h("button", {
							className: "fr-deck",
							disabled: !o,
							onClick: () => {
								r && x(Math.max(0, r.position)), a({
									type: "draw",
									kind: n
								});
							},
							"aria-label": g("games.flammerouge.hintDraw", { kind: g(G[n]) }),
							children: [/* @__PURE__ */ m("div", {
								className: "fr-deck-art",
								children: i ? /* @__PURE__ */ m(J, {
									card: i,
									kind: n
								}) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(q, {
									kind: n,
									size: 50
								}), /* @__PURE__ */ m(K, { kind: n })] })
							}), /* @__PURE__ */ h("div", { children: [
								/* @__PURE__ */ m("strong", { children: g(G[n]) }),
								/* @__PURE__ */ m("span", { children: o ? g("games.flammerouge.draw") : i ? g("games.flammerouge.selected") : L }),
								r && /* @__PURE__ */ h("small", { children: [
									g("games.flammerouge.deck"),
									" ",
									e.decks[r.key].draw,
									" · ",
									g("games.flammerouge.recycled"),
									" ",
									e.decks[r.key].recycled
								] })
							] })]
						}, n);
					})
				}),
				/* @__PURE__ */ m("p", {
					className: "fr-resolution-text",
					children: e.event ? R(e.event) : e.phase === "energy" && t?.completed.length === 2 ? g("games.flammerouge.waiting") : ""
				})
			] })
		}),
		children: [/* @__PURE__ */ h("div", {
			className: "fr-scene",
			children: [/* @__PURE__ */ m(ge, {
				pub: e,
				members: n,
				fitKey: `${e.tiles}:${v}`,
				selectedPosition: M,
				placing: N,
				onPlace: I,
				detailPosition: b
			}), /* @__PURE__ */ h("div", {
				className: "fr-map-controls",
				children: [
					/* @__PURE__ */ m("button", {
						onClick: () => {
							y(v + 1), x(3);
						},
						children: g("games.flammerouge.overview")
					}),
					/* @__PURE__ */ m("button", {
						onClick: () => x(Math.max(0, ...k.map((e) => e.position))),
						children: g("games.flammerouge.focus")
					}),
					/* @__PURE__ */ h("span", {
						className: "fr-terrain-legend",
						children: [
							/* @__PURE__ */ m("i", {
								className: "fr-up",
								children: "5"
							}),
							/* @__PURE__ */ m("span", { children: g("games.flammerouge.up") }),
							/* @__PURE__ */ m("i", {
								className: "fr-down",
								children: "5"
							}),
							/* @__PURE__ */ m("span", { children: g("games.flammerouge.down") })
						]
					})
				]
			})]
		}), /* @__PURE__ */ m(o, {
			open: B,
			onClose: () => T(null),
			label: g(w === "log" ? "games.flammerouge.log" : "games.flammerouge.details"),
			title: g(w === "log" ? "games.flammerouge.log" : "games.flammerouge.details"),
			children: /* @__PURE__ */ m("div", {
				className: "fr-panel",
				children: w === "log" ? /* @__PURE__ */ m("ol", {
					className: "fr-log",
					children: e.log.map((e, t) => /* @__PURE__ */ h("li", { children: [/* @__PURE__ */ m("small", { children: g("games.flammerouge.round", { n: e.round }) }), /* @__PURE__ */ m("span", { children: R(e) })] }, t))
				}) : C.map((n) => /* @__PURE__ */ h("section", { children: [
					/* @__PURE__ */ h("h3", { children: [/* @__PURE__ */ m(K, { kind: n }), g(G[n])] }),
					/* @__PURE__ */ m("div", {
						className: "fr-deck-stats",
						children: k.filter((e) => e.kind === n).map((t) => /* @__PURE__ */ h("span", { children: [
							g("games.flammerouge.deck"),
							" ",
							e.decks[t.key].draw,
							" · ",
							g("games.flammerouge.removed"),
							" ",
							e.decks[t.key].removed,
							" · ",
							g("games.flammerouge.fatigueCount"),
							" ",
							e.decks[t.key].fatigue
						] }, t.key))
					}),
					/* @__PURE__ */ m("h4", { children: g("games.flammerouge.recycled") }),
					/* @__PURE__ */ h("div", {
						className: "fr-mini-cards",
						children: [t?.recycled[n].map((e, t) => /* @__PURE__ */ m(J, {
							card: e,
							kind: n
						}, t)), !t?.recycled[n].length && /* @__PURE__ */ m("span", { children: g("games.flammerouge.noCards") })]
					}),
					/* @__PURE__ */ m("h4", { children: g("games.flammerouge.selected") }),
					t?.selected[n] ? /* @__PURE__ */ m("div", {
						className: "fr-mini-cards",
						children: /* @__PURE__ */ m(J, {
							card: t.selected[n],
							kind: n
						})
					}) : /* @__PURE__ */ m("span", { children: g("games.flammerouge.noCards") })
				] }, `${r}:${n}`))
			})
		})]
	});
}
function ye({ rid: e, pub: t, members: n, mine: r }) {
	let i = l(), o = c((e) => e.locale), d = n.find((t) => t.rid === e), p = u[(d?.colorIndex ?? 0) % u.length], { ref: g } = s(`team:${e}`);
	return /* @__PURE__ */ h("div", {
		ref: g,
		className: "fr-team",
		"data-mine": r,
		style: { "--fr-team-color": p.hex },
		children: [
			/* @__PURE__ */ m("img", {
				src: a[(d?.avatar ?? 0) % a.length],
				alt: ""
			}),
			/* @__PURE__ */ h("div", {
				className: "fr-team-info",
				children: [/* @__PURE__ */ m("strong", { children: d ? f(d, o) : i(p.nameKey) }), /* @__PURE__ */ m("div", { children: t.riders.filter((t) => t.rid === e).map((e) => /* @__PURE__ */ h("span", { children: [
					/* @__PURE__ */ m(K, { kind: e.kind }),
					e.position < 0 ? "—" : 74 - e.position > 0 ? /* @__PURE__ */ m("span", {
						title: i("games.flammerouge.position", { n: 74 - e.position }),
						children: 74 - e.position
					}) : /* @__PURE__ */ h("span", {
						title: i("games.flammerouge.crossed", { n: e.position - 74 + 1 }),
						children: ["+", e.position - 74 + 1]
					}),
					t.revealed[e.key] && /* @__PURE__ */ m("b", {
						className: "fr-revealed",
						children: t.revealed[e.key].value
					})
				] }, e.key)) })]
			}),
			/* @__PURE__ */ m("small", { children: t.phase === "energy" ? t.ready[e] ? "✓" : "…" : "" })
		]
	});
}
//#endregion
//#region src/games/flammerouge/bot.ts
var be = {
	conservation: .65,
	exhaustion: 0,
	drafting: .5
};
function xe(e = be) {
	return ({ public: t, private: n }, r) => {
		let i = t.riders.filter((e) => e.rid === r.rid);
		if (t.phase === "setup" && t.actor === r.rid) {
			let e = i.find((e) => e.position < 0), n = [
				4,
				3,
				2,
				1,
				0
			].find((e) => t.riders.filter((t) => t.position === e).length < 2);
			return e && n !== void 0 ? { action: {
				type: "place",
				kind: e.kind,
				position: n
			} } : null;
		}
		if (t.phase !== "energy" || !n || n.completed.length === 2) return null;
		if (!n.active) {
			let e = C.filter((e) => !n.completed.includes(e)).sort((e, t) => (i.find((t) => t.kind === e)?.position ?? 0) - (i.find((e) => e.kind === t)?.position ?? 0))[0];
			return e ? { action: {
				type: "draw",
				kind: e
			} } : null;
		}
		if (!n.hand.length) return null;
		if (r.difficulty === "weak") return { action: {
			type: "play",
			index: 0
		} };
		let a = D(t.tiles), o = i.find((e) => e.kind === n.active), s = 74 - o.position, c = s < 12 ? 0 : Math.min(1, s / 40), l = (i) => {
			let s = n.hand[i], l = H(o.position, s.value, a), u = 0;
			if (a[l]?.terrain !== "up") for (let e of t.riders) {
				if (e.key === o.key) continue;
				let t = e.rid === r.rid ? n.selected[e.kind]?.value : void 0, i = H(e.position, t ?? 5, a);
				i - l === 2 && a[i]?.terrain !== "up" && (u = 1);
			}
			return l - o.position - e.conservation * c * s.value + e.exhaustion * Number(s.exhaustion) + e.drafting * u;
		};
		return { action: {
			type: "play",
			index: n.hand.map((e, t) => t).sort((e, t) => l(t) - l(e) || n.hand[e].value - n.hand[t].value || e - t)[0]
		} };
	};
}
var Se = xe(), Ce = {
	reveal(e, t) {
		let n = t.anchor(`team:${t.myRid}`);
		return n ? {
			ms: z.reveal - 100,
			node: /* @__PURE__ */ m(y, {
				at: n,
				ms: z.reveal - 100
			})
		} : null;
	},
	move(e, t) {
		let n = e.data, r = t.anchor(`rider:${n.keys[0]}`);
		return r ? {
			ms: z.move - 100,
			node: /* @__PURE__ */ m(v, {
				at: r,
				ms: z.move - 100,
				children: /* @__PURE__ */ h("span", {
					className: "fr-fx-distance",
					children: ["+", n.to[0] - n.from[0]]
				})
			})
		} : null;
	},
	slip(e, t) {
		let n = e.data;
		return {
			ms: z.slip - 100,
			node: n.keys.map((e) => {
				let n = t.anchor(`rider:${e}`);
				return n ? /* @__PURE__ */ m(v, {
					at: n,
					ms: z.slip - 100,
					children: /* @__PURE__ */ m("span", {
						className: "fr-fx-slip",
						children: "↠ +1"
					})
				}, e) : null;
			})
		};
	},
	exhaustion(e, t) {
		let n = e.data;
		return {
			ms: z.exhaustion - 100,
			node: n.keys.map((e) => {
				let n = t.anchor(`rider:${e}`);
				return n ? /* @__PURE__ */ m(v, {
					at: n,
					ms: z.exhaustion - 100,
					children: /* @__PURE__ */ m("span", {
						className: "fr-fx-fatigue",
						children: "≈ +1"
					})
				}, e) : null;
			})
		};
	}
};
//#endregion
//#region src/games/flammerouge/game-over.tsx
function we(e) {
	let t = l(), n = c((e) => e.locale), [r, o] = i(!0), s = e.public, d = V(s.riders), g = e.members.find((t) => t.rid === e.result.winner[0]);
	return /* @__PURE__ */ h("div", {
		className: "fr-result-root",
		children: [/* @__PURE__ */ m(ve, {
			...e,
			pub: s,
			readOnly: !0,
			send: () => {}
		}), r ? /* @__PURE__ */ m("div", {
			className: "fr-result-shade",
			children: /* @__PURE__ */ h("article", {
				className: "fr-result-paper",
				children: [
					/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ m("span", { children: "FLAMME ROUGE" }), /* @__PURE__ */ m("button", {
						onClick: () => o(!1),
						children: t("games.flammerouge.finalTrack")
					})] }),
					/* @__PURE__ */ m("h1", { children: t("games.flammerouge.result") }),
					/* @__PURE__ */ m("h2", { children: t("games.flammerouge.winner", { name: g ? f(g, n) : t(u[0].nameKey) }) }),
					/* @__PURE__ */ m("ol", { children: e.result.ranking.map((r, i) => {
						let o = e.members.find((e) => e.rid === r), s = d.find((e) => e.rid === r), c = u[(o?.colorIndex ?? 0) % u.length], l = s.position - 74 + 1;
						return /* @__PURE__ */ h("li", {
							style: { "--fr-team-color": c.hex },
							children: [
								/* @__PURE__ */ m("b", {
									className: "fr-rank",
									children: i + 1
								}),
								/* @__PURE__ */ m("img", {
									src: a[(o?.avatar ?? 0) % a.length],
									alt: ""
								}),
								/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("strong", { children: o ? f(o, n) : t(c.nameKey) }), /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(K, { kind: s.kind }), t("games.flammerouge.bestRider", { kind: t(G[s.kind]) })] })] }),
								/* @__PURE__ */ m("b", { children: t(l > 0 ? "games.flammerouge.crossed" : "games.flammerouge.position", { n: l > 0 ? l : 74 - s.position }) })
							]
						}, r);
					}) }),
					/* @__PURE__ */ m("footer", { children: e.onPlayAgain || e.onBackToLobby ? /* @__PURE__ */ h(p, { children: [e.onPlayAgain && /* @__PURE__ */ m("button", {
						className: "fr-primary",
						onClick: e.onPlayAgain,
						children: t("session.result.playAgain")
					}), e.onBackToLobby && /* @__PURE__ */ m("button", {
						onClick: e.onBackToLobby,
						children: t("session.result.backToLobby")
					})] }) : /* @__PURE__ */ m("span", { children: t("session.result.waitHost") }) })
				]
			})
		}) : /* @__PURE__ */ m("button", {
			className: "fr-show-result fr-primary",
			onClick: () => o(!0),
			children: t("games.flammerouge.result")
		})]
	});
}
//#endregion
//#region src/games/flammerouge/options.tsx
function Te({ value: e, onChange: t }) {
	let n = l(), r = M.parse(e), [a, o] = i(r.custom), s = M.safeParse({
		...r,
		custom: a
	}).success;
	return /* @__PURE__ */ h("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ m(x, {
				title: n("games.flammerouge.optStage"),
				children: [...S.map((e, t) => ({
					label: e.name,
					i: t
				})), {
					label: n("games.flammerouge.custom"),
					i: 6
				}].map(({ label: e, i: n }) => /* @__PURE__ */ m(b, {
					name: "fr-stage",
					value: String(n),
					label: e,
					checked: r.stage === n,
					accent: "#a52b25",
					onChange: () => t({
						...r,
						stage: n
					})
				}, n))
			}),
			r.stage === 6 && /* @__PURE__ */ h("label", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ m("strong", { children: n("games.flammerouge.customLabel") }),
					/* @__PURE__ */ m("input", {
						value: a,
						maxLength: 21,
						className: "rounded border-2 p-2 font-mono",
						onChange: (e) => {
							let n = e.target.value;
							o(n);
							let i = M.safeParse({
								...r,
								custom: n
							});
							i.success && t(i.data);
						}
					}),
					/* @__PURE__ */ m("small", { children: n(s ? "games.flammerouge.customHint" : "games.flammerouge.invalidTrack") })
				]
			}),
			/* @__PURE__ */ m(x, {
				title: n("games.flammerouge.optHandicap"),
				children: [
					0,
					1,
					2
				].map((e) => /* @__PURE__ */ m(b, {
					name: "fr-handicap",
					value: String(e),
					checked: r.handicap === e,
					label: e === 0 ? n("games.flammerouge.none") : n("games.flammerouge.handicap", { n: e }),
					accent: "#a52b25",
					onChange: () => t({
						...r,
						handicap: e
					})
				}, e))
			})
		]
	});
}
//#endregion
//#region src/games/flammerouge/guide.tsx
function Ee() {
	let e = l();
	return /* @__PURE__ */ h("div", {
		style: {
			color: "#302d25",
			fontFamily: "system-ui",
			padding: "12px 0"
		},
		children: [
			/* @__PURE__ */ m("h3", {
				style: {
					fontWeight: 800,
					marginBottom: 8
				},
				children: e("games.flammerouge.guideTitle")
			}),
			/* @__PURE__ */ m("svg", {
				viewBox: "0 0 600 180",
				style: {
					width: "100%",
					height: "auto",
					background: "#e5dfcb",
					borderRadius: 5
				},
				role: "img",
				"aria-label": e("games.flammerouge.guideAria"),
				children: [0, 1].map((e) => /* @__PURE__ */ h("g", {
					transform: `translate(30 ${e * 85 + 18})`,
					children: [
						Array.from({ length: 9 }, (e, t) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("rect", {
							x: t * 60,
							width: "59",
							height: "55",
							fill: "#59605a",
							stroke: "#f9f2dc"
						}), /* @__PURE__ */ m("path", {
							d: `M${t * 60 + 12} 27H${t * 60 + 46}`,
							stroke: "#e6e2cd",
							strokeDasharray: "8 5"
						})] }, t)),
						(e === 0 ? [
							0,
							2,
							4
						] : [
							2,
							3,
							4
						]).map((e, t) => /* @__PURE__ */ h("g", {
							transform: `translate(${e * 60 + 30} 39)`,
							children: [
								/* @__PURE__ */ m("circle", {
									r: "12",
									fill: [
										"#2563eb",
										"#ea580c",
										"#7c3aed"
									][t],
									stroke: "#faf3d9",
									strokeWidth: "2"
								}),
								/* @__PURE__ */ m("circle", {
									cy: "-3",
									r: "4",
									fill: "#faf3d9"
								}),
								/* @__PURE__ */ m("path", {
									d: "M-7 8Q0 -6 7 8",
									fill: "#faf3d9"
								})
							]
						}, t)),
						/* @__PURE__ */ m("path", {
							d: "M500 -5H535L527 -11M535 -5 527 1",
							fill: "none",
							stroke: "#9c332a",
							strokeWidth: "3"
						})
					]
				}, e))
			}),
			/* @__PURE__ */ m("p", {
				style: {
					fontSize: 14,
					lineHeight: 1.7,
					margin: "10px 0 20px"
				},
				children: e("games.flammerouge.guideSlip")
			}),
			/* @__PURE__ */ m("p", {
				style: {
					fontSize: 14,
					lineHeight: 1.7
				},
				children: e("games.flammerouge.guideLanes")
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/flammerouge/entry.tsx
var De = {
	definition: ue,
	View: _e,
	bot: Se,
	fx: Ce,
	OverView: we,
	Options: Te,
	Guide: Ee,
	locales: {
		zh: {
			name: "赤焰极速",
			desc: "安排双车手的体力与尾流，在最后一公里发起冲刺。",
			rules: "目标：\n每位玩家控制一名全能车手和一名冲刺车手。任意车手越过终点线后，完成当轮全部移动、尾流及疲劳结算；冲过终点最远的车手所属玩家获胜。同格时，右车道的车手领先。每支车队按较靠前的车手排名。\n准备：\n· 选择一条赛道。六条推荐赛道来自基础版；自选赛道须使用 a 至 u 共 21 块板块各一次，以 a 开始、u 结束。大写字母表示另一面，红边是上坡，蓝边是下坡；I、J、S、T 的大写面仍为平路。数字化版图保留格序及地形，弯曲形状仅为展示。\n· 每名车手拥有独立的 15 张能量牌。全能车手的数值为 3、4、5、6、7，冲刺车手为 2、3、4、5、9，每个数值各有 3 张。疲劳牌的数值为 2。可选让步设置会在开局时给所有车手各加入 1 或 2 张疲劳牌。\n· 从首席开始，依座位顺序各自放置两名车手。每名车手必须位于起跑线前的 5 格之一。每格有两条车道；空格先占右车道，右车道有人时占左车道。\n每轮选牌：\n· 所有人同时行动。先选择一名尚未选牌的车手，抽取其牌堆顶的 4 张牌，点击一张牌，再确认暗置。其他 3 张牌放入该车手的回收区。随后才能为另一名车手重复此过程，不得提前查看另一名车手的牌。\n· 抽牌堆耗尽时，洗混回收区，继续抽到 4 张；两区合计不足 4 张时，全部抽出。可以随时查看自己的回收区及本轮已选牌，不能查看暗牌堆或他人的暗牌。极端情况下无牌可抽的车手本轮不移动。\n· 所有车手选牌完毕后，一起亮牌。已打出的能量牌和疲劳牌均只使用一次，然后移出游戏。\n移动：\n· 按移动开始前的车手位置从前到后依次行动，同格时右车道先行动。每名车手按牌值前进，可以穿过其他车手。\n· 落点的两条车道均有人时，退到后方最近有空车道的格；空格必须先占右车道。换道不额外消耗步数。\n· 如果车手起点、途中或落点在上坡，本次最多前进 5 格。如果第 6 步或之后才会进入上坡，则停在上坡前最近有空车道的格。\n· 如果车手从下坡开始移动，本张牌至少提供 5 格移动；途中碰到上坡时，上坡限制仍然生效。\n尾流和疲劳：\n· 没有空格隔开的车手构成一个车群。从最后的车群开始，若它与前群之间恰好空出 1 格，后群整体前进 1 格并合并。合并后的车群可再次获得尾流，因此同轮可能多次前进。\n· 上坡上的车手不能提供或接受尾流。处理尾流时，以这些车手为界分别检查前后的车手；同群中已到达平路或下坡的车手仍可获得尾流，上坡车手留在原位。前群最后一格在上坡时，不能为后群提供尾流。下坡照常处理。\n· 尾流结束后，前方一格完全无人的每名车手各获得 1 张疲劳牌，放入自己的回收区。前方格仅有一条空车道时，不会因此获得疲劳牌。上坡上的车手照常获得疲劳。\n结束：\n完成整轮结算后检查终点。只要至少一名车手已经越线，就按前述胜利条件结束比赛；否则开始下一轮。终点后的道路延伸用于比较同轮冲线距离，不会提前停止其他车手。",
			rouleur: "全能车手",
			sprinteur: "冲刺车手",
			energy: "能量牌",
			exhaustion: "疲劳牌",
			round: "第 {{n}} 轮",
			chooseRider: "选择一名车手抽牌",
			chooseCard: "为{{kind}}选择一张牌",
			placePrompt: "放置你的{{kind}}",
			placeWaiting: "等待{{name}}放置车手",
			placeCell: "将{{kind}}放入起跑格 {{n}}",
			selectCell: "选择起跑格 {{n}}",
			pickRider: "{{name}}的{{kind}}",
			waiting: "两名车手已就绪，等待其他车队。",
			reveal: "亮出能量牌",
			moving: "车手正在前进",
			slip: "结算尾流",
			fatigue: "分配疲劳牌",
			done: "比赛结束",
			play: "暗置这张牌",
			playAria: "选择数值 {{n}} 的{{kind}}",
			cancel: "取消选择",
			ready: "已就绪",
			thinking: "正在选牌",
			draw: "抽取能量牌",
			selected: "本轮暗置",
			deck: "抽牌堆",
			recycled: "回收区",
			removed: "已用牌",
			fatigueCount: "获得疲劳",
			count: "{{n}} 张",
			noCards: "无牌",
			noHand: "请先选择一名车手。",
			flat: "平路",
			up: "上坡 · 最多 5 格",
			down: "下坡起步 · 至少 5 格",
			position: "距终点 {{n}} 格",
			crossed: "越过终点 {{n}} 格",
			unplaced: "尚未出发",
			overview: "全赛道",
			focus: "查看我的车手",
			log: "比赛记录",
			details: "车手详情",
			moveLog: "{{name}}的{{kind}}打出 {{card}}，前进 {{n}} 格。",
			slipLog: "{{n}} 名车手通过尾流前进 1 格。",
			fatigueLog: "{{n}} 名车手各获得 1 张疲劳牌。",
			result: "冲线快报",
			winner: "{{name}}赢得比赛",
			finalTrack: "查看终盘",
			ranking: "车队排名",
			bestRider: "领先车手：{{kind}}",
			optStage: "赛道",
			custom: "自选赛道",
			customLabel: "板块顺序",
			customHint: "用 a 至 u 各一次，以 a 开始、u 结束。大写表示翻面。",
			invalidTrack: "请检查 21 块板块是否各用一次，并以 a 开始、u 结束。",
			optHandicap: "开局让步",
			handicap: "每名车手加 {{n}} 张疲劳牌",
			none: "不加入疲劳牌",
			errAction: "现在无法执行这个行动。",
			errCard: "请选择当前手牌中的一张牌。",
			errPlace: "请选择起跑线前有空车道的格。",
			hintDraw: "为{{kind}}抽取能量牌。",
			hintPlay: "为{{kind}}暗置数值 {{n}} 的牌。",
			hintPlace: "把{{kind}}放在起跑格 {{n}}。",
			route: "赛道地形",
			tile: "板块 {{tile}}",
			confirmPlace: "确认放置",
			guideTitle: "连续尾流示例",
			guideAria: "三个车群各间隔一个空格，后群依次并入前群。",
			guideSlip: "图中向右前进。蓝色车手先通过尾流并入橙色车手，再一起并入紫色车手；蓝色共前进 2 格，橙色前进 1 格，紫色不动。",
			guideLanes: "下方车道是本例的右车道。空格先占右车道；同格时，右车道车手领先。图形标识仅为规则示意，不代表实际玩家。"
		},
		en: {
			name: "Flamme Rouge",
			desc: "Manage two riders, save energy in the slipstream, and sprint for the line.",
			rules: "Goal:\nControl a Rouleur and a Sprinteur. When any rider crosses the finish, complete all movement, slipstreaming and exhaustion for that round. The team whose rider finishes furthest ahead wins; the right lane wins a same-square tie. Rank each team by its leading rider.\nSetup:\n· Choose one of the six base-game stages, or a custom sequence containing every tile a–u exactly once, starting with a and ending with u. Capitals select the reverse face. Red edges mark ascents and blue edges mark descents; capital I, J, S and T remain flat. The digital route preserves square order and terrain; its curves are presentational.\n· Each rider has a separate 15-card energy deck. A Rouleur has three each of 3, 4, 5, 6 and 7; a Sprinteur has three each of 2, 3, 4, 5 and 9. Exhaustion cards have value 2. The optional handicap adds one or two exhaustion cards to every rider at setup.\n· Starting with the first seat, each player places both riders in seat order. Choose any of the five squares behind the start line. A square has two lanes. Use the right lane in an empty square and the left lane when the right is occupied.\nEnergy phase:\n· Everyone acts simultaneously. Choose one rider who has not selected a card, draw the top four cards, select one and confirm it face down. Recycle the other three. Only then repeat for your other rider; you cannot see the second hand before committing the first.\n· When the draw deck runs out, shuffle recycled cards and keep drawing to four. If fewer than four remain in both piles, draw them all. You may inspect your own recycled and selected cards, never a hidden deck or an opponent’s hidden card. In the exceptional case of no cards remaining, that rider does not move this round.\n· Reveal all selected cards together. Every played energy or exhaustion card is used once, then removed from the game.\nMovement:\n· Move riders from front to back according to their positions at the start of movement. The right lane moves first within a square. Advance by the card value; riders can pass through other riders.\n· If both destination lanes are occupied, stop at the nearest square behind it with a free lane. Always enter the right lane of an empty square. Changing lanes costs no movement.\n· Starting on, entering or crossing an ascent limits movement to five squares. If the sixth or a later step would first enter an ascent, stop at the last free lane before it.\n· Starting on a descent makes the card worth at least five movement. An ascent encountered on the route still applies its limit.\nSlipstream and exhaustion:\n· Riders with no empty square between them form a pack. Starting with the rearmost pack, if exactly one empty square separates it from the next pack, move the rear pack forward one square and merge. Check the merged pack again; a rider can slipstream several times in one round.\n· Riders on ascents neither give nor receive slipstream. Treat them as boundaries when checking the riders ahead and behind: riders from the same pack who have reached flat road or a descent can still slipstream, leaving the uphill riders in place. An uphill rearmost square cannot provide slipstream to the pack behind. Descents work normally.\n· After slipstreaming, each rider with a completely empty square immediately ahead receives one exhaustion card in their recycled pile. A single empty lane does not cause exhaustion. Ascending riders receive exhaustion normally.\nFinish:\nCheck the finish after completing the round. If anyone has crossed, resolve the winner as above. Otherwise start a new round. Road beyond the finish measures the finishing distance; crossing never cancels the other riders’ movement.",
			rouleur: "Rouleur",
			sprinteur: "Sprinteur",
			energy: "Energy",
			exhaustion: "Exhaustion",
			round: "Round {{n}}",
			chooseRider: "Choose a rider to draw",
			chooseCard: "Choose a card for your {{kind}}",
			placePrompt: "Place your {{kind}}",
			placeWaiting: "Waiting for {{name}} to place riders",
			placeCell: "Place {{kind}} in starting square {{n}}",
			selectCell: "Select starting square {{n}}",
			pickRider: "{{name}}’s {{kind}}",
			waiting: "Both riders are ready. Waiting for the other teams.",
			reveal: "Reveal energy cards",
			moving: "Riders are advancing",
			slip: "Resolving slipstream",
			fatigue: "Assigning exhaustion",
			done: "Race finished",
			play: "Commit this card",
			playAria: "Select {{kind}} with value {{n}}",
			cancel: "Cancel selection",
			ready: "Ready",
			thinking: "Choosing cards",
			draw: "Draw energy cards",
			selected: "Committed this round",
			deck: "Draw pile",
			recycled: "Recycled",
			removed: "Played",
			fatigueCount: "Exhaustion gained",
			count: "{{n}} cards",
			noCards: "No cards",
			noHand: "Choose a rider first.",
			flat: "Flat",
			up: "Ascent · maximum 5",
			down: "Descent start · minimum 5",
			position: "{{n}} squares to finish",
			crossed: "{{n}} squares past finish",
			unplaced: "Not placed",
			overview: "Full track",
			focus: "Find my riders",
			log: "Race log",
			details: "Rider details",
			moveLog: "{{name}}’s {{kind}} played {{card}} and moved {{n}} squares.",
			slipLog: "{{n}} riders slipstreamed one square.",
			fatigueLog: "{{n}} riders each received one exhaustion card.",
			result: "Finish-line edition",
			winner: "{{name}} wins the race",
			finalTrack: "View final track",
			ranking: "Team classification",
			bestRider: "Leading rider: {{kind}}",
			optStage: "Stage",
			custom: "Custom stage",
			customLabel: "Tile sequence",
			customHint: "Use a–u once each, starting with a and ending with u. Capitals flip tiles.",
			invalidTrack: "Use all 21 tiles once, starting with a and ending with u.",
			optHandicap: "Starting handicap",
			handicap: "{{n}} exhaustion cards per rider",
			none: "No extra exhaustion",
			errAction: "That action is not available now.",
			errCard: "Choose a card from your current hand.",
			errPlace: "Choose a free lane behind the start line.",
			hintDraw: "Draw energy cards for your {{kind}}.",
			hintPlay: "Commit value {{n}} for your {{kind}}.",
			hintPlace: "Place your {{kind}} in starting square {{n}}.",
			route: "Route terrain",
			tile: "Tile {{tile}}",
			confirmPlace: "Confirm placement",
			guideTitle: "Chained slipstream example",
			guideAria: "Three packs with one empty square between each merge from rear to front.",
			guideSlip: "The riders travel right. Blue first joins orange, then both join purple. Blue advances two squares, orange advances one and purple stays in place.",
			guideLanes: "The lower lane is the right lane in this example. Enter the right lane of an empty square; a right-lane rider leads a same-square tie. These generic figures illustrate the rule and do not identify actual players."
		}
	}
};
//#endregion
export { De as default };
