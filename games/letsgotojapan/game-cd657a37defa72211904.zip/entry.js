import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { playTurn as u, useSoundEdge as d } from "@bgparty/sdk/sfx";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { seatName as p } from "@bgparty/sdk/ui/player-strip";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { IconBack as _, IconBot as v, IconExpand as y, IconLog as ee } from "@bgparty/sdk/icons";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
//#region \0bgparty-json:D:/Other/BG/BGParty/src/games/letsgotojapan/cards-data.json.mjs
var x = await fetch("games/letsgotojapan/data/cards-data.json").then((e) => e.json()), S = {
	"Visit an anime museum": "参观动漫博物馆",
	"Zojoji Temple": "增上寺",
	"Sensoji Temple and Nakamise": "浅草寺与仲见世",
	"Meiji Jingu Shrine": "明治神宫",
	"Gotokuji Temple": "豪德寺",
	"Department stores in Ginza": "银座百货商店",
	"Shopping in Shibuya": "涩谷购物",
	"See the Hachiko statue": "看看忠犬八公像",
	"Watch Sumo": "观看相扑",
	"Go to a baseball game": "观看棒球赛",
	"Tokyo metropolitan govt. building": "东京都厅展望台",
	"Tokyo Tower": "东京塔",
	"Miyashita Park": "宫下公园",
	"Imperial Palace Gardens": "皇居东御苑",
	"Visit a rescue cat cafe": "探访救助猫咖啡馆",
	"Board game store in Akihabara": "秋叶原桌游店",
	"Be an Otaku in Akihabara": "漫游秋叶原",
	"Ueno Park": "上野公园",
	"Shinjuku Gyoen Park": "新宿御苑",
	"Gachapon vending machines": "扭蛋机",
	"Sushi at the Tsukiji Market": "筑地市场寿司",
	"Get yakitori in Omoide Yokocho": "思出横丁烤鸡肉串",
	"Stay in a capsule hotel": "入住胶囊旅馆",
	"Tokyo Station": "东京站",
	"Tokyo National Museum": "东京国立博物馆",
	"Get a new outfit in Harajuku": "原宿换装",
	"Get crepes in Harajuku": "原宿可丽饼",
	Ikebukuro: "池袋",
	Daikanyama: "代官山",
	"Go to a themed cafe": "主题咖啡馆",
	"See a Kabuki show": "欣赏歌舞伎",
	"Stay at a really nice hotel": "入住豪华酒店",
	"Dine at a top restaurant": "顶级餐厅用餐",
	"Monjayaki in Tsukishima": "月岛文字烧",
	"Conveyor belt sushi": "回转寿司",
	"Nezu Shrine": "根津神社",
	"Todoroki Valley Park": "等等力溪谷公园",
	"Kanda Shrine": "神田明神",
	"Get food from a Konbini": "便利店美食",
	"Grab some street food": "品尝街头小吃",
	"Soba and Tempura": "荞麦面与天妇罗",
	"Attend a festival": "参加祭典",
	"Take a hike outside of town": "郊外徒步",
	"See some cherry blossoms": "赏樱",
	"Eat ramen at the best place!": "品尝招牌拉面",
	"Visit a small Shrine": "探访小神社",
	"Photo sticker booth": "拍大头贴",
	"Buy a gift in an interesting shop": "特色小店选礼物",
	"Take a cooking class": "参加料理课",
	"See a concert": "欣赏音乐会",
	"Ginkakuji Temple": "银阁寺",
	"Tofukuji Temple": "东福寺",
	"Ryoanji Temple": "龙安寺",
	"Kinkakuji Temple": "金阁寺",
	"Kiyomizudera Temple": "清水寺",
	"Nanzenji Temple": "南禅寺",
	"Fushimi Inari Shrine": "伏见稻荷大社",
	"Yasaka Shrine": "八坂神社",
	"Heian Shrine": "平安神宫",
	"Tea ceremony": "茶道体验",
	"Kyoto Tower": "京都塔",
	"Monkey Park": "猴子公园",
	"Manga Museum": "京都国际漫画博物馆",
	"Sannenzaka slope": "三年坂",
	"Take an Ikebana class": "花道课程",
	"Geisha show at Gion Corner": "祇园角艺伎演出",
	"Kyoto Imperial Palace": "京都御所",
	"Philosopher’s path": "哲学之道",
	"Kyoto Railway Museum": "京都铁道博物馆",
	"Nishiki Market": "锦市场",
	"Kyoto Handicraft Center": "京都手工艺中心",
	"Otagi Nenbutsuji Temple": "爱宕念佛寺",
	"Temple lodging": "寺院住宿",
	"Arashiyama bamboo grove": "岚山竹林",
	"Stay at a ryokan": "入住日式旅馆",
	"Stay at a machiya": "町家住宿",
	"Nijo Castle": "二条城",
	"Ponto-cho": "先斗町",
	"Tour Shugakuin Villa": "参观修学院离宫",
	"Higashiyama District": "东山区",
	"Tenryuji Temple": "天龙寺",
	"Kokedera Temple": "苔寺",
	Onsen: "温泉",
	"Tour the sake district": "清酒酿造街区",
	"Shopping arcades": "商店街",
	"Flea Market": "跳蚤市场",
	"Kyoto National Museum": "京都国立博物馆",
	"Take a drumming class": "和太鼓课程",
	"Visit a small shrine": "探访小神社"
}, C = [
	"shrine",
	"food",
	"nature",
	"shopping",
	"unique",
	"happy1",
	"happy2",
	"stress1",
	"stress2"
], w = C.slice(0, 5), T = [
	"shrine",
	"food",
	"nature",
	"shopping",
	"unique",
	"happy2"
], E = x, D = Object.fromEntries(E.map((e) => [e.id, e]));
function O(e, t) {
	return t === "zh" ? S[e.titleEn] ?? e.titleEn : e.titleEn;
}
//#endregion
//#region src/games/letsgotojapan/meta.ts
var k = {
	id: "letsgotojapan",
	tier: "beta",
	mechanics: ["drafting", "set-collection"],
	interactionTags: [],
	nameKey: "games.letsgotojapan.name",
	descKey: "games.letsgotojapan.desc",
	rulesKey: "games.letsgotojapan.rules",
	icon: "⛩️",
	iconImg: "games/letsgotojapan.webp",
	rulesUrl: { en: "https://www.alderac.com/wp-content/uploads/2025/04/LetsGoToJapan_BaseGame_Rulebook_Optimized.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3],
	accent: "#c84932",
	releasedAt: "2026-09-30",
	search: {
		py: "lai qu ri ben",
		init: "lqrb"
	},
	hotseat: "cover"
}, A = t.enum(["tokyo", "kyoto"]), j = t.int().min(0).max(5), M = t.int().min(0).max(3), N = t.string().regex(/^(tokyo|kyoto)-([1-9]|[1-7]\d|80)$/), te = t.enum([
	"shrine",
	"food",
	"nature",
	"shopping",
	"unique"
]), P = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		card: N,
		day: j,
		index: M
	}),
	t.object({
		type: t.literal("walk"),
		discard: N,
		city: A,
		day: j,
		index: M
	}),
	t.object({
		type: t.literal("useResearch"),
		tokyo: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("discardResearch"),
		cards: t.tuple([
			N,
			N,
			N
		])
	}),
	t.object({
		type: t.literal("dayBonus"),
		choice: t.enum([
			"mood",
			"research",
			"wild",
			"luxury",
			"extraWalk"
		]),
		city: A.optional(),
		index: M.optional()
	}),
	t.object({
		type: t.literal("pass"),
		cards: t.array(N).min(1).max(2)
	}),
	t.object({
		type: t.literal("chooseFinalCity"),
		city: A
	}),
	t.object({
		type: t.literal("setCity"),
		day: j,
		index: M,
		city: A
	}),
	t.object({
		type: t.literal("setTrain"),
		day: j,
		index: M,
		kind: t.enum([
			"start",
			"luxury",
			"regular"
		])
	}),
	t.object({ type: t.literal("confirmRoute") }),
	t.object({
		type: t.literal("chooseWalk"),
		activate: t.boolean()
	}),
	t.object({
		type: t.literal("useWild"),
		experience: te
	}),
	t.object({ type: t.literal("resolveHighlight") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), ne = t.object({
	shrine: t.int().nonnegative(),
	food: t.int().nonnegative(),
	nature: t.int().nonnegative(),
	shopping: t.int().nonnegative(),
	unique: t.int().nonnegative(),
	happy1: t.int().nonnegative(),
	happy2: t.int().nonnegative(),
	stress1: t.int().nonnegative(),
	stress2: t.int().nonnegative(),
	walk: t.int().nonnegative(),
	train: t.int().nonnegative()
}), re = t.object({
	id: N.nullable(),
	backCity: A,
	generic: t.boolean(),
	assignedCity: A,
	walk: t.boolean(),
	revealed: t.boolean(),
	kept: t.boolean()
}), ie = t.object({
	rid: t.string(),
	days: t.array(t.array(re)).length(6),
	played: t.int().nonnegative(),
	passed: t.boolean(),
	handCount: t.int().nonnegative(),
	incomingCount: t.int().nonnegative(),
	pendingBonusDay: j.nullable(),
	researchPending: t.boolean(),
	finalChoicePending: t.boolean(),
	research: t.int().nonnegative(),
	wild: t.int().nonnegative(),
	luxury: t.int().nonnegative(),
	mood: t.int().min(-2).max(2),
	happy: t.int().min(0).max(3),
	stress: t.int().min(0).max(3),
	icons: ne,
	experience: t.object({
		shrine: t.int(),
		food: t.int(),
		nature: t.int(),
		shopping: t.int(),
		unique: t.int()
	}),
	dayScore: t.array(t.int()).length(6),
	trainScore: t.int(),
	finalScore: t.int().nullable(),
	routeConfirmed: t.boolean(),
	trainChoices: t.record(t.string(), t.enum([
		"start",
		"luxury",
		"regular"
	]))
}), ae = t.object({
	round: t.int().min(1).max(13),
	phase: t.enum([
		"plan",
		"route",
		"trip",
		"done"
	]),
	roundPlay: t.int().min(1).max(2),
	direction: t.enum(["left", "right"]),
	favorable: t.array(t.enum([
		"shrine",
		"food",
		"nature",
		"shopping",
		"unique",
		"happy2"
	])).length(6),
	players: t.array(ie),
	trip: t.object({
		day: j,
		rid: t.string(),
		slot: t.int().min(0).max(4),
		step: t.enum([
			"train",
			"card",
			"highlight",
			"next"
		]),
		waitingWalk: t.boolean(),
		waitingHighlight: t.boolean()
	}).nullable(),
	lastEvent: t.object({
		kind: t.string(),
		rid: t.string().nullable(),
		day: j.nullable(),
		card: N.nullable(),
		points: t.int().nullable()
	}).nullable()
}), oe = t.object({
	hand: t.array(N),
	researchDrawn: t.array(N)
});
//#endregion
//#region src/games/letsgotojapan/score.ts
function se() {
	return Object.fromEntries([
		...C,
		"walk",
		"train"
	].map((e) => [e, 0]));
}
function F() {
	return Object.fromEntries(w.map((e) => [e, 0]));
}
function I(e, t) {
	for (let n = 0; n < Math.abs(t); n += 1) e.mood += Math.sign(t), e.mood >= 3 ? (e.mood = 0, e.happy = Math.min(3, e.happy + 1)) : e.mood <= -3 && (e.mood = 0, e.stress = Math.min(3, e.stress + 1));
}
function L(e, t, n = 1) {
	e.icons[t] += n, w.includes(t) ? e.experience[t] += n : t === "happy1" || t === "happy2" ? I(e, n) : (t === "stress1" || t === "stress2") && I(e, -n);
}
function ce(e, t, n) {
	e.dayScore[n] += t.base;
	for (let n of C) {
		let r = t.icons[n] ?? 0;
		r && L(e, n, r);
	}
}
function le(e, t) {
	--e.wild, L(e, t);
}
function ue(e, t) {
	for (let [n, r] of Object.entries(t.requirement.atLeast)) if ((e.icons[n] ?? 0) < r) return !1;
	for (let n of t.requirement.zero ?? []) if (e.icons[n] !== 0) return !1;
	return !0;
}
function de(e, t, n) {
	let r = t.reward.points;
	if (r.kind === "fixed") return r.value;
	let i = r.per.map((t) => t === "tokyoDays" ? n.tokyo : t === "kyotoDays" ? n.kyoto : e.icons[t]), a = Math.min(...i), o = r.rate * a;
	return r.kind === "fixedPlusPer" ? r.value + o : o;
}
function fe(e, t) {
	for (let [n, r] of Object.entries(t)) r && (n === "wild" ? e.wild += r : L(e, n, r));
}
function R(e) {
	return e >= 12 ? 15 : e >= 10 ? 12 : e >= 7 ? 8 : e >= 4 ? 4 : 0;
}
var z = [
	0,
	5,
	12,
	20
], B = [
	0,
	-3,
	-8,
	-15
];
function V(e) {
	let t = e.dayScore.reduce((e, t) => e + t, 0), n = w.reduce((t, n) => t + R(e.experience[n]), 0);
	return t + e.trainScore + n + z[e.happy] + B[e.stress] + e.research;
}
var pe = [
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	2,
	1,
	1,
	1,
	1
], H = (e) => ({ code: e });
function U(t, n) {
	for (let r = t.length - 1; r > 0; --r) {
		let i = e(n.seed, n.rngCursor++, r + 1);
		[t[r], t[i]] = [t[i], t[r]];
	}
}
function W(e, t) {
	if (e.decks[t].length === 0) {
		let n = e.discard.filter((e) => D[e].city === t);
		if (n.length === 0) return null;
		e.discard = e.discard.filter((e) => D[e].city !== t), U(n, e), e.decks[t] = n;
	}
	return e.decks[t].pop() ?? null;
}
function G(e, t, n) {
	let r = [];
	for (let i = 0; i < n; i += 1) {
		let n = W(e, t);
		if (!n) return null;
		r.push(n);
	}
	return r;
}
function me() {
	return {
		days: Array.from({ length: 6 }, () => []),
		hand: [],
		incoming: [],
		finalPile: [],
		played: 0,
		passed: !1,
		pendingBonusDay: null,
		researchDrawn: [],
		finalChoicePending: !1,
		research: 0,
		wild: 0,
		luxury: 0,
		mood: 0,
		happy: 0,
		stress: 0,
		icons: se(),
		experience: F(),
		dayScore: [
			,
			,
			,
			,
			,
			,
		].fill(0),
		trainScore: 0,
		routeConfirmed: !1,
		trainChoices: {},
		finalScore: null
	};
}
function he(e, t) {
	e.round = t;
	let n = [
		5,
		7,
		9,
		10,
		12
	].includes(t);
	for (let r of e.players) {
		let i = e.ps[r];
		if (i.played = 0, i.passed = !1, i.pendingBonusDay = null, i.researchDrawn = [], i.finalChoicePending = t === 13, t === 13) i.finalPile = i.incoming, i.incoming = [], i.hand = [];
		else if (n) i.hand = i.incoming, i.incoming = [];
		else {
			let n = t === 6 || t === 8 ? 2 : 1;
			i.hand = [...G(e, "tokyo", n) ?? [], ...G(e, "kyoto", n) ?? []];
		}
	}
	e.lastEvent = {
		kind: "round",
		rid: null,
		day: null,
		card: null,
		points: null
	};
}
function ge(e, t, n) {
	let r = {
		players: t,
		phase: "plan",
		round: 1,
		decks: {
			tokyo: E.filter((e) => e.city === "tokyo").map((e) => e.id),
			kyoto: E.filter((e) => e.city === "kyoto").map((e) => e.id)
		},
		discard: [],
		favorable: [...T],
		ps: {},
		trip: null,
		lastEvent: null,
		rngCursor: 0,
		seed: n,
		beatMs: 650
	};
	U(r.decks.tokyo, r), U(r.decks.kyoto, r), U(r.favorable, r);
	for (let e of t) r.ps[e] = me();
	return he(r, 1), {
		state: r,
		fx: t.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: {
				round: 1,
				count: 2
			},
			for: [e],
			secret: { cards: r.ps[e].hand },
			...t > 0 ? { with: !0 } : {}
		}))
	};
}
function _e(e, t) {
	let n = e.ps[t];
	return e.phase === "plan" && !!n && !n.passed && !n.finalChoicePending && n.researchDrawn.length === 0 && n.pendingBonusDay === null;
}
function ve(e, t, n) {
	let r = e.favorable[n];
	return e.ps[t].days[n].reduce((e, t) => e + (t.walk ? 0 : D[t.id].icons[r] ?? 0), 0);
}
function ye(e, t, n, r, i, a, o) {
	let s = e.ps[t], c = {
		id: n,
		backCity: o,
		assignedCity: o,
		walk: a,
		revealed: !a,
		kept: !1
	};
	s.days[r].splice(i, 0, c), s.played += 1, s.days[r].length === 3 && ve(e, t, r) > 0 && (s.pendingBonusDay = r);
}
function be(e, t) {
	return `${e}:${t}`;
}
function xe(e) {
	let t = [], n = null;
	for (let r = 0; r < 6; r += 1) for (let i = 0; i < e.days[r].length; i += 1) {
		let a = e.days[r][i];
		n && n.assignedCity !== a.assignedCity && t.push(be(r, i)), n = a;
	}
	return t;
}
function Se(e, t) {
	let n = {
		tokyo: 0,
		kyoto: 0
	};
	for (let r = 0; r <= t; r += 1) {
		let t = e.days[r];
		t.length && t.every((e) => e.assignedCity === t[0].assignedCity) && (n[t[0].assignedCity] += 1);
	}
	return n;
}
function Ce(e, t, n) {
	if (n > 0) return e.days[t][n - 1];
	for (let n = t - 1; n >= 0; --n) {
		let t = e.days[n];
		if (t.length) return t[t.length - 1];
	}
	return null;
}
function we(e) {
	let t = e.trip;
	if (!t) return null;
	let n = e.players[t.seat], r = e.ps[n];
	return {
		cursor: t,
		rid: n,
		p: r,
		card: r.days[t.day][t.slot] ?? null
	};
}
function K(e) {
	let t = we(e);
	if (!t) return [];
	let { cursor: n, rid: r, p: i, card: a } = t, o = n.day;
	if (n.step === "train") {
		if (!a) return n.step = "highlight", [];
		let t = Ce(i, o, n.slot);
		if (t && t.assignedCity !== a.assignedCity) {
			let t = i.trainChoices[be(o, n.slot)] ?? "regular";
			return L(i, "train"), t === "luxury" ? (i.trainScore += 2, I(i, 1)) : t === "regular" && (i.trainScore -= 2), n.step = "card", e.beatMs = 850, e.lastEvent = {
				kind: "train",
				rid: r,
				day: o,
				card: null,
				points: t === "luxury" ? 2 : t === "regular" ? -2 : 0
			}, [{
				kind: "train",
				rid: r,
				data: {
					day: o,
					index: n.slot,
					token: t
				}
			}];
		}
		n.step = "card";
	}
	if (n.step === "card" && a) {
		if (a.walk && !a.revealed) return a.revealed = !0, n.waitingWalk = !0, e.lastEvent = {
			kind: "revealWalk",
			rid: r,
			day: o,
			card: a.id,
			points: null
		}, [{
			kind: "revealWalk",
			rid: r,
			data: {
				day: o,
				index: n.slot,
				card: a.id
			}
		}];
		a.walk && a.kept ? (i.dayScore[o] += 1, I(i, 1), L(i, "walk")) : (ce(i, D[a.id], o), a.walk && L(i, "walk"));
		let t = a.walk && a.kept ? 1 : D[a.id].base;
		return n.slot += 1, n.step = n.slot >= i.days[o].length ? "highlight" : "train", e.beatMs = 750, e.lastEvent = {
			kind: "card",
			rid: r,
			day: o,
			card: a.walk && a.kept ? null : a.id,
			points: t
		}, [{
			kind: "card",
			rid: r,
			data: {
				day: o,
				index: n.slot - 1,
				card: a.walk && a.kept ? null : a.id,
				points: t
			}
		}];
	}
	if (n.step === "next") {
		if (n.seat += 1, n.seat >= e.players.length && (n.seat = 0, n.day += 1), n.day >= 6) {
			for (let t of e.players) e.ps[t].finalScore = V(e.ps[t]);
			return e.phase = "done", e.trip = null, e.lastEvent = {
				kind: "done",
				rid: null,
				day: null,
				card: null,
				points: null
			}, [{
				kind: "tripDone",
				data: {}
			}];
		}
		return n.slot = 0, n.step = "train", e.beatMs = 450, e.lastEvent = {
			kind: "nextDay",
			rid: e.players[n.seat],
			day: n.day,
			card: null,
			points: null
		}, [{
			kind: "nextDay",
			data: {
				day: n.day,
				rid: e.players[n.seat]
			}
		}];
	}
	return [];
}
function q(e, t, n) {
	let r = n.by;
	if (t.type === "tick") {
		if (e.phase !== "trip" || !e.trip || e.trip.waitingWalk || e.trip.step === "highlight") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return {
			state: t,
			fx: K(t)
		};
	}
	if (!e.ps[r]) return H("games.letsgotojapan.errTurn");
	let i = structuredClone(e), a = i.ps[r];
	if (t.type === "chooseFinalCity") {
		if (i.phase !== "plan" || i.round !== 13 || !a.finalChoicePending) return H("games.letsgotojapan.errTurn");
		let e = W(i, t.city);
		return e ? (a.hand = [e, ...a.finalPile], a.finalPile = [], a.finalChoicePending = !1, {
			state: i,
			fx: [{
				kind: "finalDraw",
				rid: r,
				data: { city: t.city },
				for: [r],
				secret: { cards: a.hand }
			}]
		}) : H("games.letsgotojapan.errDeck");
	}
	if (t.type === "place" || t.type === "walk") {
		if (!_e(i, r) || a.played >= pe[i.round - 1]) return H("games.letsgotojapan.errTurn");
		let e = t.type === "place" ? t.card : t.discard;
		if (!a.hand.includes(e)) return H("games.letsgotojapan.errCard");
		if (a.days[t.day].length >= 3 || t.index > a.days[t.day].length) return H("games.letsgotojapan.errDay");
		if (a.hand.splice(a.hand.indexOf(e), 1), t.type === "place") return ye(i, r, e, t.day, t.index, !1, D[e].city), i.lastEvent = {
			kind: "place",
			rid: r,
			day: t.day,
			card: e,
			points: null
		}, {
			state: i,
			fx: [{
				kind: "place",
				rid: r,
				data: {
					day: t.day,
					index: t.index,
					card: e
				}
			}]
		};
		i.discard.push(e);
		let n = W(i, t.city);
		return n ? (ye(i, r, n, t.day, t.index, !0, t.city), a.research += 1, i.lastEvent = {
			kind: "walk",
			rid: r,
			day: t.day,
			card: null,
			points: null
		}, {
			state: i,
			fx: [{
				kind: "walk",
				rid: r,
				data: {
					day: t.day,
					index: t.index,
					city: t.city
				}
			}]
		}) : H("games.letsgotojapan.errDeck");
	}
	if (t.type === "useResearch") {
		if (!_e(i, r) || a.research < 1) return H("games.letsgotojapan.errResearch");
		let e = G(i, "tokyo", t.tokyo), n = G(i, "kyoto", 3 - t.tokyo);
		return !e || !n ? H("games.letsgotojapan.errDeck") : (--a.research, a.researchDrawn = [...e, ...n], a.hand.push(...a.researchDrawn), {
			state: i,
			fx: [{
				kind: "research",
				rid: r,
				data: { count: 3 },
				for: [r],
				secret: { cards: a.researchDrawn }
			}]
		});
	}
	if (t.type === "discardResearch") {
		if (i.phase !== "plan" || a.researchDrawn.length !== 3 || a.passed) return H("games.letsgotojapan.errResearch");
		let e = [...t.cards];
		if (new Set(e).size !== 3 || e.some((e) => !a.hand.includes(e))) return H("games.letsgotojapan.errCard");
		for (let t of e) a.hand.splice(a.hand.indexOf(t), 1);
		return i.discard.push(...e), a.researchDrawn = [], {
			state: i,
			fx: [{
				kind: "researchDiscard",
				rid: r,
				data: { count: 3 }
			}]
		};
	}
	if (t.type === "dayBonus") {
		let e = a.pendingBonusDay;
		if (i.phase !== "plan" || a.passed || e === null || a.researchDrawn.length || ve(i, r, e) < (t.choice === "mood" ? 1 : t.choice === "research" || t.choice === "wild" ? 2 : 3)) return H("games.letsgotojapan.errBonus");
		if (t.choice === "mood") I(a, 1);
		else if (t.choice === "research") a.research += 2;
		else if (t.choice === "wild") a.wild += 1;
		else if (t.choice === "luxury") a.luxury += 1;
		else {
			if (!t.city || t.index === void 0 || t.index > 3) return H("games.letsgotojapan.errBonus");
			let n = W(i, t.city);
			if (!n) return H("games.letsgotojapan.errDeck");
			a.days[e].splice(t.index, 0, {
				id: n,
				backCity: t.city,
				assignedCity: t.city,
				walk: !0,
				revealed: !1,
				kept: !1
			});
		}
		return a.pendingBonusDay = null, i.lastEvent = {
			kind: "dayBonus",
			rid: r,
			day: e,
			card: null,
			points: null
		}, {
			state: i,
			fx: [{
				kind: "dayBonus",
				rid: r,
				data: {
					day: e,
					choice: t.choice
				}
			}]
		};
	}
	if (t.type === "pass") {
		let n = pe[i.round - 1];
		if (!_e(i, r) || a.played !== n || t.cards.length !== n || a.hand.length !== n) return H("games.letsgotojapan.errPass");
		if (new Set(t.cards).size !== n || t.cards.some((e) => !a.hand.includes(e))) return H("games.letsgotojapan.errCard");
		let o = i.players.indexOf(r), s = i.players[(o + (i.round <= 7 ? 1 : i.players.length - 1)) % i.players.length];
		if (i.ps[s].incoming.push(...t.cards), a.hand = [], a.passed = !0, i.players.every((e) => i.ps[e].passed)) {
			if (i.round === 13) {
				for (let e of i.players) i.discard.push(...i.ps[e].incoming, ...i.ps[e].finalPile), i.ps[e].incoming = [], i.ps[e].finalPile = [];
				i.phase = "route", i.lastEvent = {
					kind: "route",
					rid: null,
					day: null,
					card: null,
					points: null
				};
			} else he(i, i.round + 1);
		}
		return {
			state: i,
			fx: [{
				kind: "pass",
				rid: r,
				data: {
					count: n,
					direction: e.round <= 7 ? "left" : "right"
				}
			}]
		};
	}
	if (t.type === "setCity") {
		if (i.phase !== "route" || a.routeConfirmed) return H("games.letsgotojapan.errRoute");
		let e = a.days[t.day][t.index];
		return !e || e.walk || !D[e.id].generic ? H("games.letsgotojapan.errCard") : (e.assignedCity = t.city, a.trainChoices = {}, {
			state: i,
			fx: []
		});
	}
	if (t.type === "setTrain") {
		if (i.phase !== "route" || a.routeConfirmed) return H("games.letsgotojapan.errRoute");
		let e = be(t.day, t.index);
		if (!xe(a).includes(e)) return H("games.letsgotojapan.errRoute");
		if (t.kind === "start") for (let e of Object.keys(a.trainChoices)) a.trainChoices[e] === "start" && delete a.trainChoices[e];
		return a.trainChoices[e] = t.kind, Object.values(a.trainChoices).filter((e) => e === "luxury").length > a.luxury ? H("games.letsgotojapan.errTrain") : {
			state: i,
			fx: []
		};
	}
	if (t.type === "confirmRoute") {
		if (i.phase !== "route" || a.routeConfirmed) return H("games.letsgotojapan.errRoute");
		let e = xe(a);
		return e.length && e.filter((e) => a.trainChoices[e] === "start").length !== 1 ? H("games.letsgotojapan.errTrain") : (a.routeConfirmed = !0, i.players.every((e) => i.ps[e].routeConfirmed) && (i.phase = "trip", i.trip = {
			day: 0,
			seat: 0,
			slot: 0,
			step: "train",
			waitingWalk: !1
		}, i.beatMs = 650), {
			state: i,
			fx: [{
				kind: "routeReady",
				rid: r,
				data: {}
			}]
		});
	}
	let o = we(i);
	if (t.type === "chooseWalk") return i.phase !== "trip" || !o || o.rid !== r || !o.cursor.waitingWalk || !o.card?.walk ? H("games.letsgotojapan.errTurn") : (o.card.kept = !t.activate, o.cursor.waitingWalk = !1, i.beatMs = 500, {
		state: i,
		fx: [{
			kind: "walkChoice",
			rid: r,
			data: {
				day: o.cursor.day,
				activate: t.activate
			}
		}]
	});
	if (t.type === "useWild") return i.phase !== "trip" || !o || o.rid !== r || o.cursor.step !== "highlight" || a.wild < 1 ? H("games.letsgotojapan.errWild") : (le(a, t.experience), {
		state: i,
		fx: [{
			kind: "useWild",
			rid: r,
			data: { experience: t.experience }
		}]
	});
	if (t.type === "resolveHighlight") {
		if (i.phase !== "trip" || !o || o.rid !== r || o.cursor.step !== "highlight") return H("games.letsgotojapan.errTurn");
		let e = o.cursor.day, t = a.days[e].at(-1), n = 0;
		if (t?.walk && t.kept) n = 2;
		else if (t) {
			let r = D[t.id];
			ue(a, r) && (n = de(a, r, Se(a, e)), fe(a, r.reward.grants));
		}
		return a.dayScore[e] += n, o.cursor.step = "next", i.beatMs = 900, i.lastEvent = {
			kind: "highlight",
			rid: r,
			day: e,
			card: t?.walk && t.kept ? null : t?.id ?? null,
			points: n
		}, {
			state: i,
			fx: [{
				kind: "highlight",
				rid: r,
				data: {
					day: e,
					points: n
				}
			}]
		};
	}
	return H("games.letsgotojapan.errTurn");
}
function J(e, t) {
	return {
		public: {
			round: e.round,
			phase: e.phase,
			roundPlay: pe[e.round - 1],
			direction: e.round <= 7 ? "left" : "right",
			favorable: e.favorable,
			players: e.players.map((t) => {
				let n = e.ps[t];
				return {
					rid: t,
					days: n.days.map((e) => e.map((e) => ({
						id: e.walk && !e.revealed ? null : e.id,
						backCity: e.backCity,
						generic: !e.walk && D[e.id].generic,
						assignedCity: e.assignedCity,
						walk: e.walk,
						revealed: e.revealed,
						kept: e.kept
					}))),
					played: n.played,
					passed: n.passed,
					handCount: n.hand.length,
					incomingCount: n.incoming.length + n.finalPile.length,
					pendingBonusDay: n.pendingBonusDay,
					researchPending: n.researchDrawn.length > 0,
					finalChoicePending: n.finalChoicePending,
					research: n.research,
					wild: n.wild,
					luxury: n.luxury,
					mood: n.mood,
					happy: n.happy,
					stress: n.stress,
					icons: n.icons,
					experience: n.experience,
					dayScore: n.dayScore,
					trainScore: n.trainScore,
					finalScore: n.finalScore,
					routeConfirmed: n.routeConfirmed,
					trainChoices: n.trainChoices
				};
			}),
			trip: e.trip ? {
				day: e.trip.day,
				rid: e.players[e.trip.seat],
				slot: e.trip.slot,
				step: e.trip.step,
				waitingWalk: e.trip.waitingWalk,
				waitingHighlight: e.trip.step === "highlight"
			} : null,
			lastEvent: e.lastEvent
		},
		private: {
			hand: e.ps[t]?.hand ?? [],
			researchDrawn: e.ps[t]?.researchDrawn ?? []
		}
	};
}
function Te(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t) => [t, e.ps[t].finalScore ?? V(e.ps[t])])), n = [...e.players].sort((e, n) => t[n] - t[e]), r = t[n[0]];
	return {
		phase: "done",
		winner: n.filter((e) => t[e] === r),
		ranking: n,
		scores: t
	};
}
function Ee(e) {
	return e.phase === "trip" && e.trip && !e.trip.waitingWalk && e.trip.step !== "highlight" ? e.beatMs : null;
}
var Y = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: k,
	schemas: {
		action: P,
		publicView: ae,
		privateView: oe
	},
	setup: ge,
	reduce: q,
	viewFor: J,
	status: Te,
	nextTickIn: Ee
}, De = {
	"Arashiyama bamboo grove": "games/letsgotojapan/live/8898c9ae1f66.webp",
	"Attend a festival": "games/letsgotojapan/live/3f3e8c595f43.webp",
	"Be an Otaku in Akihabara": "games/letsgotojapan/live/90b5a695e089.webp",
	"Board game store in Akihabara": "games/letsgotojapan/live/733cbb3c8fea.webp",
	"Buy a gift in an interesting shop": "games/letsgotojapan/live/3cbd6333c09a.webp",
	"Conveyor belt sushi": "games/letsgotojapan/live/851645aab51b.webp",
	Daikanyama: "games/letsgotojapan/live/d5bbe2d2cf3e.webp",
	"Department stores in Ginza": "games/letsgotojapan/live/81179226fac0.webp",
	"Dine at a top restaurant": "games/letsgotojapan/live/e662b48fce18.webp",
	"Eat ramen at the best place!": "games/letsgotojapan/live/5676c6461913.webp",
	"Flea Market": "games/letsgotojapan/live/636247a5fd97.webp",
	"Fushimi Inari Shrine": "games/letsgotojapan/live/49b42f4a0933.webp",
	"Gachapon vending machines": "games/letsgotojapan/live/015353d9f92c.webp",
	"Geisha show at Gion Corner": "games/letsgotojapan/live/cc7e29b2f6fd.webp",
	"Get a new outfit in Harajuku": "games/letsgotojapan/live/303216c27ff8.webp",
	"Get crepes in Harajuku": "games/letsgotojapan/live/a0bb1e781b7c.webp",
	"Get food from a Konbini": "games/letsgotojapan/live/76acffe46028.webp",
	"Get yakitori in Omoide Yokocho": "games/letsgotojapan/live/2d1469c0470c.webp",
	"Ginkakuji Temple": "games/letsgotojapan/live/1df908a73bd9.webp",
	"Go to a baseball game": "games/letsgotojapan/live/f8a9241535cc.webp",
	"Go to a themed cafe": "games/letsgotojapan/live/66f35213db48.webp",
	"Gotokuji Temple": "games/letsgotojapan/live/cb6e7d292796.webp",
	"Grab some street food": "games/letsgotojapan/live/4e3b451bc445.webp",
	"Heian Shrine": "games/letsgotojapan/live/b1f92b1668a9.webp",
	"Higashiyama District": "games/letsgotojapan/live/4644313017ea.webp",
	Ikebukuro: "games/letsgotojapan/live/ca85287d3978.webp",
	"Imperial Palace Gardens": "games/letsgotojapan/live/328089ab9479.webp",
	"Kanda Shrine": "games/letsgotojapan/live/ed5ca20b6e51.webp",
	"Kinkakuji Temple": "games/letsgotojapan/live/f0b4f8998b53.webp",
	"Kiyomizudera Temple": "games/letsgotojapan/live/2a1d145b9448.webp",
	"Kokedera Temple": "games/letsgotojapan/live/3796e033d2a6.webp",
	"Kyoto Handicraft Center": "games/letsgotojapan/live/a628b98f7af3.webp",
	"Kyoto Imperial Palace": "games/letsgotojapan/live/89d03f86f29a.webp",
	"Kyoto National Museum": "games/letsgotojapan/live/58b644c608d6.webp",
	"Kyoto Railway Museum": "games/letsgotojapan/live/d8986008da06.webp",
	"Kyoto Tower": "games/letsgotojapan/live/c4afaf6ca5eb.webp",
	"Manga Museum": "games/letsgotojapan/live/7759dbb17846.webp",
	"Meiji Jingu Shrine": "games/letsgotojapan/live/62b6362ffe9a.webp",
	"Miyashita Park": "games/letsgotojapan/live/77b96b68f665.webp",
	"Monjayaki in Tsukishima": "games/letsgotojapan/live/443a522136a2.webp",
	"Monkey Park": "games/letsgotojapan/live/eb522b51fccf.webp",
	"Nanzenji Temple": "games/letsgotojapan/live/73262bba40cc.webp",
	"Nezu Shrine": "games/letsgotojapan/live/d02306726fca.webp",
	"Nijo Castle": "games/letsgotojapan/live/20b91dd08050.webp",
	"Nishiki Market": "games/letsgotojapan/live/281534794e85.webp",
	Onsen: "games/letsgotojapan/live/9e4232a22b33.webp",
	"Otagi Nenbutsuji Temple": "games/letsgotojapan/live/719218eda47a.webp",
	"Philosopher’s path": "games/letsgotojapan/live/c57eb9fbbf52.webp",
	"Photo sticker booth": "games/letsgotojapan/live/a75459f24763.webp",
	"Ponto-cho": "games/letsgotojapan/live/9784625656ad.webp",
	"Ryoanji Temple": "games/letsgotojapan/live/48f87495729e.webp",
	"Sannenzaka slope": "games/letsgotojapan/live/f0559eaf774f.webp",
	"See a Kabuki show": "games/letsgotojapan/live/d8daaa2c221a.webp",
	"See a concert": "games/letsgotojapan/live/f48d28c7a73b.webp",
	"See some cherry blossoms": "games/letsgotojapan/live/ec6fe4a19d29.webp",
	"See the Hachiko statue": "games/letsgotojapan/live/5a14278e490f.webp",
	"Sensoji Temple and Nakamise": "games/letsgotojapan/live/d679da83e27c.webp",
	"Shinjuku Gyoen Park": "games/letsgotojapan/live/508aaa7f6f62.webp",
	"Shopping arcades": "games/letsgotojapan/live/0f55c08bcf50.webp",
	"Shopping in Shibuya": "games/letsgotojapan/live/5f0530b9499a.webp",
	"Soba and Tempura": "games/letsgotojapan/live/bb005dd413f9.webp",
	"Stay at a machiya": "games/letsgotojapan/live/4eee52d35af7.webp",
	"Stay at a really nice hotel": "games/letsgotojapan/live/37875a39c2d1.webp",
	"Stay at a ryokan": "games/letsgotojapan/live/f43398d60129.webp",
	"Stay in a capsule hotel": "games/letsgotojapan/live/2ea695a0a832.webp",
	"Sushi at the Tsukiji Market": "games/letsgotojapan/live/ed60d198b7ce.webp",
	"Take a cooking class": "games/letsgotojapan/live/4df2922fe99d.webp",
	"Take a drumming class": "games/letsgotojapan/live/92a3540309f9.webp",
	"Take a hike outside of town": "games/letsgotojapan/live/927d009f4f9a.webp",
	"Take an Ikebana class": "games/letsgotojapan/live/9929310593d8.webp",
	"Tea ceremony": "games/letsgotojapan/live/7818dbdfd342.webp",
	"Temple lodging": "games/letsgotojapan/live/9a1908c0ac9b.webp",
	"Tenryuji Temple": "games/letsgotojapan/live/64a32b01069e.webp",
	"Todoroki Valley Park": "games/letsgotojapan/live/5be9482efc25.webp",
	"Tofukuji Temple": "games/letsgotojapan/live/22899c848522.webp",
	"Tokyo National Museum": "games/letsgotojapan/live/d22c0a8cd440.webp",
	"Tokyo Station": "games/letsgotojapan/live/73a21fb7b028.webp",
	"Tokyo Tower": "games/letsgotojapan/live/0066b1744fde.webp",
	"Tokyo metropolitan govt. building": "games/letsgotojapan/live/0ccdd64bcf3a.webp",
	"Tour Shugakuin Villa": "games/letsgotojapan/live/21cefbc58deb.webp",
	"Tour the sake district": "games/letsgotojapan/live/163627fc7b0e.webp",
	"Ueno Park": "games/letsgotojapan/live/ee49b991559b.webp",
	"Visit a rescue cat cafe": "games/letsgotojapan/live/5c600bf86d15.webp",
	"Visit a small Shrine": "games/letsgotojapan/live/14b7d80f863b.webp",
	"Visit a small shrine": "games/letsgotojapan/live/14b7d80f863b.webp",
	"Visit an anime museum": "games/letsgotojapan/live/ced158b4171e.webp",
	"Watch Sumo": "games/letsgotojapan/live/2372e12ccb54.webp",
	"Yasaka Shrine": "games/letsgotojapan/live/1226377fe030.webp",
	"Zojoji Temple": "games/letsgotojapan/live/eb0a04dde088.webp"
}, Oe = {
	shrine: "var(--color-jp-shrine)",
	food: "var(--color-jp-food)",
	nature: "var(--color-jp-nature)",
	shopping: "var(--color-jp-shopping)",
	unique: "var(--color-jp-unique)",
	happy1: "var(--color-jp-happy)",
	happy2: "var(--color-jp-happy-light)",
	stress1: "var(--color-jp-stress)",
	stress2: "var(--color-jp-stress-light)"
};
function X({ kind: e, size: t = 24, className: n, label: r }) {
	let i = e === "happy1" || e === "happy2" || e === "stress1" || e === "stress2", a = e === "shrine" || e === "food" || e === "nature" || e === "shopping" || e === "unique", o = e in Oe ? Oe[e] : "var(--color-jp-teal)";
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 32 32",
		width: t,
		height: t,
		className: n,
		role: r ? "img" : void 0,
		"aria-label": r,
		"aria-hidden": !r || void 0,
		fill: "none",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			a && /* @__PURE__ */ h("circle", {
				cx: "16",
				cy: "16",
				r: "13",
				fill: "var(--color-jp-paper)",
				stroke: o,
				strokeWidth: "3"
			}),
			e === "shrine" && /* @__PURE__ */ g("g", {
				stroke: o,
				strokeWidth: "2.7",
				children: [/* @__PURE__ */ h("path", { d: "M7 10h18M9 14h14M11 14v10M21 14v10M8 24h16" }), /* @__PURE__ */ h("path", { d: "M9 10l2-2h10l2 2" })]
			}),
			e === "food" && /* @__PURE__ */ g("g", {
				stroke: o,
				strokeWidth: "2.4",
				children: [
					/* @__PURE__ */ h("path", { d: "M8 9l15 14M24 9L9 23" }),
					/* @__PURE__ */ h("path", { d: "M9 18c1 6 13 6 14 0" }),
					/* @__PURE__ */ h("path", { d: "M10 13l3-3M19 10l3 3" })
				]
			}),
			e === "nature" && /* @__PURE__ */ g("g", {
				stroke: o,
				strokeWidth: "1.8",
				children: [
					/* @__PURE__ */ h("ellipse", {
						cx: "16",
						cy: "10.5",
						rx: "3.3",
						ry: "5"
					}),
					/* @__PURE__ */ h("ellipse", {
						cx: "21.2",
						cy: "14.2",
						rx: "3.3",
						ry: "5",
						transform: "rotate(72 21.2 14.2)"
					}),
					/* @__PURE__ */ h("ellipse", {
						cx: "19.2",
						cy: "20.2",
						rx: "3.3",
						ry: "5",
						transform: "rotate(144 19.2 20.2)"
					}),
					/* @__PURE__ */ h("ellipse", {
						cx: "12.8",
						cy: "20.2",
						rx: "3.3",
						ry: "5",
						transform: "rotate(216 12.8 20.2)"
					}),
					/* @__PURE__ */ h("ellipse", {
						cx: "10.8",
						cy: "14.2",
						rx: "3.3",
						ry: "5",
						transform: "rotate(288 10.8 14.2)"
					}),
					/* @__PURE__ */ h("circle", {
						cx: "16",
						cy: "16",
						r: "2",
						fill: o,
						stroke: "none"
					})
				]
			}),
			e === "shopping" && /* @__PURE__ */ g("g", {
				stroke: o,
				strokeWidth: "2.4",
				children: [
					/* @__PURE__ */ h("path", { d: "M10 13h12l1 12H9l1-12Z" }),
					/* @__PURE__ */ h("path", { d: "M12.5 13V10a3.5 3.5 0 0 1 7 0v3" }),
					/* @__PURE__ */ h("path", {
						d: "M13 19c1-2 2-1 3 0 1-1 2-2 3 0 1 2-3 4-3 4s-4-2-3-4Z",
						fill: o,
						stroke: "none"
					})
				]
			}),
			e === "unique" && /* @__PURE__ */ g("g", {
				stroke: o,
				strokeWidth: "2.2",
				children: [
					/* @__PURE__ */ h("path", { d: "M8 10c0-2 3-3 8-3s8 2 8 8-4 8-8 8c-1 0-2 0-3-.3L8 26l1-6c-1-1-1-3-1-5v-5Z" }),
					/* @__PURE__ */ h("circle", {
						cx: "12",
						cy: "15",
						r: "1.3",
						fill: o,
						stroke: "none"
					}),
					/* @__PURE__ */ h("circle", {
						cx: "16",
						cy: "15",
						r: "1.3",
						fill: o,
						stroke: "none"
					}),
					/* @__PURE__ */ h("circle", {
						cx: "20",
						cy: "15",
						r: "1.3",
						fill: o,
						stroke: "none"
					})
				]
			}),
			i && /* @__PURE__ */ h("path", {
				d: e.startsWith("happy") ? "M4 5h19l6 11-6 11H4l5-11L4 5Z" : "M28 5H9L3 16l6 11h19l-5-11 5-11Z",
				fill: o,
				stroke: "var(--color-jp-ink)",
				strokeWidth: "2"
			}),
			(e === "happy1" || e === "stress1") && /* @__PURE__ */ h("text", {
				x: "16",
				y: "22",
				textAnchor: "middle",
				fontSize: "19",
				fontWeight: "900",
				fill: "var(--color-jp-ink)",
				children: "¥"
			}),
			(e === "happy2" || e === "stress2") && /* @__PURE__ */ h("path", {
				d: "M18 5 9 17h7l-2 10 9-13h-7l2-9Z",
				fill: "var(--color-jp-ink)"
			}),
			e === "research" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("rect", {
					x: "5",
					y: "4",
					width: "22",
					height: "24",
					rx: "3",
					fill: "#b7834c",
					stroke: "var(--color-jp-ink)",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("path", {
					d: "M10 9h12v15H10z",
					fill: "#f4dfae"
				}),
				/* @__PURE__ */ h("path", {
					d: "M12 14h8M12 18h6",
					stroke: "#715038",
					strokeWidth: "1.6"
				})
			] }),
			e === "wild" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", {
					d: "M16 16V3a13 13 0 0 1 12.4 9Z",
					fill: "var(--color-jp-coral)"
				}),
				/* @__PURE__ */ h("path", {
					d: "M16 16 28.4 12A13 13 0 0 1 24 25Z",
					fill: "var(--color-jp-yellow)"
				}),
				/* @__PURE__ */ h("path", {
					d: "M16 16 24 25A13 13 0 0 1 8 25Z",
					fill: "var(--color-jp-happy)"
				}),
				/* @__PURE__ */ h("path", {
					d: "M16 16 8 25A13 13 0 0 1 3.6 12Z",
					fill: "var(--color-jp-blue)"
				}),
				/* @__PURE__ */ h("path", {
					d: "M16 16 3.6 12A13 13 0 0 1 16 3Z",
					fill: "var(--color-jp-pink)"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "16",
					cy: "16",
					r: "13",
					stroke: "var(--color-jp-ink)",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "16",
					cy: "16",
					r: "3.2",
					fill: "var(--color-jp-paper)"
				})
			] }),
			(e === "luxury" || e === "train") && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("rect", {
					x: "3",
					y: "7",
					width: "26",
					height: "18",
					rx: "3",
					fill: e === "luxury" ? "var(--color-jp-yellow)" : "var(--color-jp-blue)",
					stroke: "var(--color-jp-ink)",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("path", {
					d: "M8 11h16v7H8z",
					fill: "var(--color-jp-paper)"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "9",
					cy: "22",
					r: "2",
					fill: "var(--color-jp-ink)"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "23",
					cy: "22",
					r: "2",
					fill: "var(--color-jp-ink)"
				})
			] }),
			e === "walk" && /* @__PURE__ */ g("g", {
				fill: "var(--color-jp-teal)",
				stroke: "var(--color-jp-ink)",
				strokeWidth: "1.2",
				children: [/* @__PURE__ */ h("ellipse", {
					cx: "10",
					cy: "20",
					rx: "4",
					ry: "7",
					transform: "rotate(-25 10 20)"
				}), /* @__PURE__ */ h("ellipse", {
					cx: "22",
					cy: "13",
					rx: "4",
					ry: "7",
					transform: "rotate(25 22 13)"
				})]
			}),
			e === "points" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", {
					d: "M7 24V13l3-5 4 3 3-5 4 5 4-3 3 5v11c0 4-5 6-11 6S7 28 7 24Z",
					fill: "var(--color-jp-paper)",
					stroke: "var(--color-jp-ink)",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("path", {
					d: "M12 18h.1M22 18h.1",
					stroke: "var(--color-jp-ink)",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ h("path", {
					d: "M14 22c2 2 4 2 6 0",
					stroke: "var(--color-jp-ink)",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ h("path", {
					d: "M25 15l4-5v10",
					stroke: "var(--color-jp-ink)",
					strokeWidth: "2"
				})
			] })
		]
	});
}
//#endregion
//#region src/games/letsgotojapan/card.tsx
var Z = {
	shrine: "games.letsgotojapan.iconShrine",
	food: "games.letsgotojapan.iconFood",
	nature: "games.letsgotojapan.iconNature",
	shopping: "games.letsgotojapan.iconShopping",
	unique: "games.letsgotojapan.iconUnique",
	happy1: "games.letsgotojapan.iconHappy1",
	happy2: "games.letsgotojapan.iconHappy2",
	stress1: "games.letsgotojapan.iconStress1",
	stress2: "games.letsgotojapan.iconStress2",
	research: "games.letsgotojapan.research",
	wild: "games.letsgotojapan.wild",
	luxury: "games.letsgotojapan.luxury",
	train: "games.letsgotojapan.train",
	walk: "games.letsgotojapan.walk",
	points: "games.letsgotojapan.totalScore"
};
function ke({ card: e, size: t }) {
	let n = c(), r = t === "full" ? 22 : t === "hand" ? 17 : t === "side" ? 15 : 13;
	return /* @__PURE__ */ h("span", {
		className: "jp-card-icons jp-card-scroll flex min-w-0 items-center gap-0.5 overflow-x-auto",
		children: C.flatMap((t) => Array.from({ length: e.icons[t] ?? 0 }, (e, i) => /* @__PURE__ */ h(X, {
			kind: t,
			size: r,
			label: n(Z[t]),
			className: "flex-none"
		}, `${t}-${i}`)))
	});
}
function Ae({ kind: e, count: t, zero: n, size: r }) {
	let i = c();
	return /* @__PURE__ */ g("span", {
		className: `jp-card-count inline-flex flex-none items-center gap-0.5 whitespace-nowrap rounded-sm bg-jp-paper/80 px-0.5 font-extrabold leading-none text-jp-ink ${r === "full" ? "text-xs" : "text-[10px]"}`,
		children: [/* @__PURE__ */ h(X, {
			kind: e,
			size: r === "full" ? 18 : 12,
			label: i(Z[e])
		}), n ? "=0" : `≥${t}`]
	});
}
function je({ card: e, size: t }) {
	let n = c(), r = Object.entries(e.requirement.atLeast);
	return /* @__PURE__ */ g("div", {
		className: "jp-card-requirement jp-card-scroll flex min-h-0 flex-1 items-center gap-0.5 overflow-x-auto rounded-sm bg-jp-mint px-1",
		children: [
			/* @__PURE__ */ h("span", {
				className: `flex-none font-extrabold leading-none text-jp-ink ${t === "full" ? "text-xs" : "text-[10px]"}`,
				children: n(t === "full" ? "games.letsgotojapan.requirement" : "games.letsgotojapan.requirementShort")
			}),
			r.length === 0 && !e.requirement.zero?.length ? /* @__PURE__ */ h("span", {
				className: "text-[10px] text-jp-ink",
				children: "—"
			}) : null,
			r.map(([e, n]) => /* @__PURE__ */ h(Ae, {
				kind: e,
				count: n,
				size: t
			}, e)),
			e.requirement.zero?.map((e) => /* @__PURE__ */ h(Ae, {
				kind: e,
				count: 0,
				zero: !0,
				size: t
			}, e))
		]
	});
}
function Me({ card: e, size: t, color: n }) {
	let r = c(), i = e.reward.points, a = Object.entries(e.reward.grants), o = i.kind === "fixed" ? [] : i.per, s = t === "full" ? 18 : 12;
	return /* @__PURE__ */ g("div", {
		className: `jp-card-reward jp-card-scroll flex min-h-0 flex-1 items-center gap-1 overflow-x-auto rounded-sm px-1 font-extrabold leading-none text-jp-ink ${t === "full" ? "text-xs" : "text-[10px]"}`,
		style: { background: n },
		children: [/* @__PURE__ */ h("span", {
			className: "flex-none",
			children: r(t === "full" ? "games.letsgotojapan.highlight" : "games.letsgotojapan.highlightShort")
		}), /* @__PURE__ */ g("span", {
			className: "flex flex-none items-center gap-0.5 whitespace-nowrap",
			children: [
				i.kind !== "per" && /* @__PURE__ */ h("span", { children: r("games.letsgotojapan.pointsFixed", { n: i.value }) }),
				i.kind === "fixedPlusPer" && /* @__PURE__ */ h("span", { children: "+" }),
				i.kind !== "fixed" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", { children: r(t === "full" ? "games.letsgotojapan.pointsPer" : "games.letsgotojapan.pointsPerShort", { n: i.rate }) }), o.map((e) => e === "tokyoDays" || e === "kyotoDays" ? /* @__PURE__ */ h("span", { children: r(e === "tokyoDays" ? "games.letsgotojapan.tokyoDays" : "games.letsgotojapan.kyotoDays") }, e) : /* @__PURE__ */ h(X, {
					kind: e,
					size: s,
					label: r(Z[e])
				}, e))] }),
				a.map(([e, t]) => /* @__PURE__ */ g("span", {
					className: "inline-flex items-center gap-0.5",
					children: [
						"+",
						/* @__PURE__ */ h(X, {
							kind: e,
							size: s,
							label: r(Z[e])
						}),
						t > 1 ? t : null
					]
				}, e))
			]
		})]
	});
}
function Q({ id: e, size: t, elevated: n = !1, selected: r = !1, active: i = !1, assignedCity: a }) {
	let l = c(), u = s((e) => e.locale), [d, f] = o(!1), p = D[e];
	if (!p) return null;
	let m = p.generic ? "var(--color-jp-yellow)" : p.city === "tokyo" ? "var(--color-jp-blue)" : "var(--color-jp-pink)", _ = De[p.titleEn], v = O(p, u), y = p.generic ? l("games.letsgotojapan.generic") : l(p.city === "tokyo" ? "games.letsgotojapan.tokyo" : "games.letsgotojapan.kyoto");
	return /* @__PURE__ */ g("div", {
		className: `jp-card jp-card-${t} relative flex min-w-0 flex-col overflow-hidden rounded-md border-2 border-jp-ink bg-jp-paper text-jp-ink ${t === "hand" ? "h-27 w-68 flex-none" : t === "full" ? "h-44 w-full max-w-[28rem]" : "h-full w-full"} ${n ? "shadow-[2px_2px_0_var(--color-jp-ink)]" : ""} ${r ? "-translate-y-1.5 ring-2 ring-jp-coral" : ""} ${i ? "outline-3 outline-offset-1 outline-jp-coral" : ""}`,
		style: { borderColor: r ? "var(--color-jp-coral)" : void 0 },
		children: [/* @__PURE__ */ g("span", {
			className: `jp-card-heading flex flex-none items-center justify-between gap-1 px-1.5 font-extrabold ${t === "full" ? "h-7 text-sm" : t === "board" ? "h-5 text-[10px] wide:h-[18px]" : "h-5 text-[10px]"}`,
			style: { background: m },
			children: [/* @__PURE__ */ g("span", {
				className: "min-w-0 truncate",
				children: [
					y,
					" · ",
					v
				]
			}), /* @__PURE__ */ g("span", {
				className: "flex flex-none items-center gap-0.5 rounded bg-jp-paper/90 px-1 font-mono text-[10px] tabular-nums",
				children: [p.base, /* @__PURE__ */ h(X, {
					kind: "points",
					size: t === "full" ? 17 : 13
				})]
			})]
		}), /* @__PURE__ */ g("div", {
			className: `jp-card-body flex min-h-0 flex-1 gap-1 p-1 ${t === "board" ? "wide:p-0.5" : ""}`,
			children: [_ && !d ? /* @__PURE__ */ h("img", {
				src: _,
				alt: "",
				draggable: !1,
				onError: () => f(!0),
				className: `h-full flex-none rounded-sm object-cover ${t === "full" ? "w-[35%]" : t === "board" ? "w-[27%]" : "w-[31%]"}`
			}) : /* @__PURE__ */ h("div", { className: `h-full flex-none rounded-sm bg-jp-sand ${t === "full" ? "w-[35%]" : t === "board" ? "w-[27%]" : "w-[31%]"}` }), /* @__PURE__ */ g("div", {
				className: `flex min-h-0 min-w-0 flex-1 flex-col gap-0.5 ${t === "board" ? "wide:gap-px" : ""}`,
				children: [
					/* @__PURE__ */ g("div", {
						className: `flex flex-none items-center gap-1 overflow-hidden text-jp-ink ${t === "full" ? "h-6" : t === "board" ? "h-4 wide:h-3" : "h-4"}`,
						children: [/* @__PURE__ */ h(ke, {
							card: p,
							size: t
						}), a && p.generic && /* @__PURE__ */ h("span", {
							className: "ml-auto flex-none text-[9px] font-extrabold",
							children: l(a === "tokyo" ? "games.letsgotojapan.tokyo" : "games.letsgotojapan.kyoto")
						})]
					}),
					/* @__PURE__ */ h(je, {
						card: p,
						size: t
					}),
					/* @__PURE__ */ h(Me, {
						card: p,
						size: t,
						color: m
					})
				]
			})]
		})]
	});
}
function Ne({ city: e, walk: t = !1, kept: n = !1, size: r = "board" }) {
	let i = c();
	return /* @__PURE__ */ g("span", {
		className: `relative grid place-items-center overflow-hidden rounded-md border-2 border-jp-ink text-jp-ink ${r === "hand" ? "h-27 w-68" : "h-full w-full"}`,
		style: { background: e === "tokyo" ? "var(--color-jp-blue)" : "var(--color-jp-pink)" },
		children: [/* @__PURE__ */ h("span", {
			"aria-hidden": !0,
			className: "absolute inset-1 rounded border border-jp-paper/80 jp-waves"
		}), /* @__PURE__ */ g("span", {
			className: "relative flex flex-col items-center gap-1 rounded-md bg-jp-paper/85 px-2 py-1 text-center text-[10px] font-extrabold",
			children: [/* @__PURE__ */ h(X, {
				kind: t ? "walk" : "train",
				size: r === "board" ? 19 : 25
			}), i(t ? n ? "games.letsgotojapan.keepWalk" : "games.letsgotojapan.walk" : e === "tokyo" ? "games.letsgotojapan.tokyo" : "games.letsgotojapan.kyoto")]
		})]
	});
}
//#endregion
//#region src/games/letsgotojapan/view-player.tsx
var Pe = [
	"games.letsgotojapan.monday",
	"games.letsgotojapan.tuesday",
	"games.letsgotojapan.wednesday",
	"games.letsgotojapan.thursday",
	"games.letsgotojapan.friday",
	"games.letsgotojapan.saturday"
];
function Fe(e) {
	let t = [], n = null;
	for (let r = 0; r < 6; r += 1) e.days[r].forEach((e, i) => {
		n && n.assignedCity !== e.assignedCity && t.push({
			day: r,
			index: i,
			key: `${r}:${i}`
		}), n = e;
	});
	return t;
}
function Ie(e, t, n) {
	return e.days[t].reduce((e, t) => e + (t.id && !t.walk ? D[t.id].icons[n] ?? 0 : 0), 0);
}
function Le({ p: e, round: t, playNeed: n }) {
	let r = c(), i = s((e) => e.locale), a = [
		-2,
		-1,
		0,
		1,
		2
	], o = [
		{
			kind: "research",
			n: e.research,
			key: "games.letsgotojapan.research"
		},
		{
			kind: "wild",
			n: e.wild,
			key: "games.letsgotojapan.wild"
		},
		{
			kind: "luxury",
			n: e.luxury,
			key: "games.letsgotojapan.luxury"
		}
	];
	return /* @__PURE__ */ g("div", {
		className: "jp-status h-19 wide:h-8 rounded-lg border-2 border-jp-ink bg-jp-paper px-1.5 text-jp-ink",
		children: [
			/* @__PURE__ */ g("div", {
				className: "flex h-6 wide:h-full items-center gap-1 overflow-hidden whitespace-nowrap",
				children: [
					/* @__PURE__ */ h("span", {
						className: "mr-1 text-sm font-extrabold wide:text-xs",
						children: r("games.letsgotojapan.itinerary")
					}),
					/* @__PURE__ */ h("span", {
						className: "rounded-full bg-jp-coral px-1.5 py-0.5 font-mono text-[10px] font-extrabold text-white tabular-nums",
						children: r("games.letsgotojapan.roundProgress", {
							n: e.played,
							total: n
						})
					}),
					/* @__PURE__ */ h("span", { className: "wide:hidden flex-1" }),
					/* @__PURE__ */ h("span", {
						className: "hidden wide:flex items-center gap-1",
						children: w.map((t) => /* @__PURE__ */ g("span", {
							className: "flex items-center",
							children: [/* @__PURE__ */ h(X, {
								kind: t,
								size: 17,
								label: r(Z[t])
							}), /* @__PURE__ */ h("span", {
								className: "font-mono text-[10px] font-bold tabular-nums",
								children: e.experience[t]
							})]
						}, t))
					}),
					/* @__PURE__ */ g("span", {
						className: "hidden wide:flex items-center gap-0.5",
						children: [
							a.map((t) => /* @__PURE__ */ h("span", {
								className: `grid size-3.5 place-items-center rounded-sm ${t === e.mood ? "bg-jp-ink text-white" : t < 0 ? "bg-jp-pink" : "bg-jp-mint"}`,
								children: t === e.mood ? "•" : null
							}, t)),
							/* @__PURE__ */ g("span", {
								className: "ml-1 text-[10px] font-bold",
								children: [
									r("games.letsgotojapan.mood"),
									" ",
									e.mood
								]
							}),
							/* @__PURE__ */ g("span", {
								className: "text-[10px] font-bold",
								children: [
									r("games.letsgotojapan.stress"),
									" ",
									e.stress
								]
							}),
							/* @__PURE__ */ g("span", {
								className: "text-[10px] font-bold",
								children: [
									r("games.letsgotojapan.happiness"),
									" ",
									e.happy
								]
							})
						]
					}),
					o.map(({ kind: e, n: t, key: n }) => /* @__PURE__ */ g("span", {
						className: "inline-flex items-center gap-0.5 text-[10px] font-bold",
						children: [
							/* @__PURE__ */ h(X, {
								kind: e,
								size: 14,
								label: r(n)
							}),
							/* @__PURE__ */ h("span", {
								className: i === "en" ? "sr-only" : "wide:hidden",
								children: r(n)
							}),
							/* @__PURE__ */ h("span", {
								className: "font-mono tabular-nums",
								children: t
							})
						]
					}, e)),
					/* @__PURE__ */ h("span", {
						className: "hidden wide:block text-[10px] font-bold",
						children: r("games.letsgotojapan.round", { n: t })
					})
				]
			}),
			/* @__PURE__ */ h("div", {
				className: "wide:hidden flex h-6 items-center justify-between border-t border-jp-ink/20",
				children: w.map((t) => /* @__PURE__ */ g("span", {
					className: "flex items-center gap-0.5",
					children: [/* @__PURE__ */ h(X, {
						kind: t,
						size: 20,
						label: r(Z[t])
					}), /* @__PURE__ */ h("span", {
						className: "font-mono text-xs font-extrabold tabular-nums",
						children: e.experience[t]
					})]
				}, t))
			}),
			/* @__PURE__ */ g("div", {
				className: "wide:hidden flex h-5 items-center justify-between gap-1 text-[9px] font-bold",
				children: [
					/* @__PURE__ */ g("span", {
						className: "text-jp-stress",
						children: [
							r("games.letsgotojapan.stress"),
							" ",
							e.stress
						]
					}),
					/* @__PURE__ */ h("span", {
						className: "flex items-center gap-0.5",
						children: a.map((t) => /* @__PURE__ */ h("span", {
							className: `grid h-4 w-5 place-items-center rounded-sm ${t === e.mood ? "bg-jp-ink text-white" : t < 0 ? "bg-jp-pink" : "bg-jp-mint"}`,
							children: t === e.mood ? "•" : null
						}, t))
					}),
					/* @__PURE__ */ g("span", { children: [
						r("games.letsgotojapan.mood"),
						" ",
						e.mood
					] }),
					/* @__PURE__ */ g("span", {
						className: "text-jp-happy",
						children: [
							r("games.letsgotojapan.happiness"),
							" ",
							e.happy
						]
					})
				]
			})
		]
	});
}
function Re({ p: e }) {
	let t = c(), n = w.reduce((t, n) => t + R(e.experience[n]), 0), r = z[e.happy] + B[e.stress], i = [
		{
			key: "games.letsgotojapan.scoreTrain",
			value: e.trainScore
		},
		{
			key: "games.letsgotojapan.scoreMood",
			value: r
		},
		{
			key: "games.letsgotojapan.scoreExperience",
			value: n
		},
		{
			key: "games.letsgotojapan.scoreResearch",
			value: e.research
		}
	];
	return /* @__PURE__ */ h("div", {
		className: "jp-final-summary jp-paper-dots h-full min-h-0 overflow-y-auto p-1.5 text-jp-ink",
		children: /* @__PURE__ */ g("div", {
			className: "mx-auto flex max-w-2xl flex-col gap-2",
			children: [
				/* @__PURE__ */ g("div", {
					className: "flex min-h-11 items-center justify-between rounded-lg border-2 border-jp-ink bg-jp-coral px-3 font-extrabold text-white",
					children: [/* @__PURE__ */ h("span", { children: t("games.letsgotojapan.scoreSummary") }), /* @__PURE__ */ h("span", {
						className: "font-mono text-xl tabular-nums",
						children: e.finalScore ?? 0
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: "grid grid-cols-3 gap-1.5 wide:grid-cols-6",
					children: Pe.map((n, r) => /* @__PURE__ */ g("div", {
						className: "flex min-h-14 flex-col items-center justify-center rounded-md border-2 border-jp-ink bg-jp-paper font-bold wide:min-h-11",
						children: [/* @__PURE__ */ h("span", {
							className: "text-[10px]",
							children: t(n)
						}), /* @__PURE__ */ h("span", {
							className: "font-mono text-lg font-black tabular-nums",
							children: e.dayScore[r]
						})]
					}, n))
				}),
				/* @__PURE__ */ h("div", {
					className: "grid grid-cols-2 gap-1.5 wide:grid-cols-4",
					children: i.map(({ key: e, value: n }) => /* @__PURE__ */ g("div", {
						className: "flex min-h-14 items-center justify-between rounded-md border-2 border-jp-ink bg-jp-mint px-2 wide:min-h-11",
						children: [/* @__PURE__ */ h("span", {
							className: "text-xs font-bold",
							children: t(e)
						}), /* @__PURE__ */ h("span", {
							className: "font-mono text-lg font-black tabular-nums",
							children: n
						})]
					}, e))
				}),
				/* @__PURE__ */ h("div", {
					className: "flex min-h-11 items-center justify-around rounded-md border-2 border-jp-ink bg-jp-paper px-1",
					children: w.map((n) => /* @__PURE__ */ g("span", {
						className: "flex items-center gap-0.5",
						children: [/* @__PURE__ */ h(X, {
							kind: n,
							size: 21,
							label: t(Z[n])
						}), /* @__PURE__ */ h("span", {
							className: "font-mono text-xs font-extrabold tabular-nums",
							children: e.experience[n]
						})]
					}, n))
				})
			]
		})
	});
}
function ze({ pub: e, p: t, day: r, selected: i, previewCard: a, previewWalk: o, previewCity: s, editable: l, onDay: u, onInsert: d, onDetails: f, onTrain: p, onCity: m, boundaries: _, trainAllowed: v }) {
	let y = c(), ee = t.days[r], b = ee.map((e, t) => ({
		planned: e,
		preview: !1,
		originalIndex: t
	}));
	if (i?.day === r && a) {
		let e = D[a];
		b.splice(i.index, 0, {
			planned: {
				id: o ? null : a,
				backCity: o ? s : e.city,
				assignedCity: o ? s : e.city,
				generic: e.generic && !o,
				walk: o,
				revealed: !o,
				kept: !1
			},
			preview: !0,
			originalIndex: i.index
		});
	}
	let x = e.favorable[r], S = Ie(t, r, x), C = l && e.phase === "plan" && !t.passed && !t.researchPending && t.pendingBonusDay === null && !t.finalChoicePending && ee.length < 3, w = e.trip?.rid === t.rid && e.trip.day === r ? e.trip.slot : -1, T = (e) => C && (i?.day !== r || i.index !== e) && /* @__PURE__ */ g("button", {
		type: "button",
		"aria-label": y("games.letsgotojapan.insertAt", { n: e + 1 }),
		onClick: () => d(r, e),
		className: "jp-insert flex min-h-9 w-full flex-none items-center justify-center gap-1 rounded-md border-2 border-jp-teal bg-jp-mint text-[11px] font-extrabold wide:min-h-8",
		children: [/* @__PURE__ */ h("span", {
			className: "text-base leading-none",
			children: "+"
		}), y("games.letsgotojapan.insertHere")]
	});
	return /* @__PURE__ */ g("section", {
		className: "jp-day-frame relative flex h-fit min-h-0 flex-col overflow-hidden rounded-lg border-2 border-jp-ink p-1.5 text-jp-ink wide:h-full wide:p-1",
		children: [
			/* @__PURE__ */ g("button", {
				type: "button",
				onClick: () => u(r),
				className: "jp-day-heading flex h-11 flex-none items-center gap-1 rounded-md bg-jp-coral px-2 text-left text-white wide:h-7 wide:px-1",
				children: [
					/* @__PURE__ */ h("span", {
						className: "text-lg font-black wide:text-xs",
						children: y(Pe[r])
					}),
					/* @__PURE__ */ h(X, {
						kind: x,
						size: 22,
						label: y(Z[x])
					}),
					/* @__PURE__ */ g("span", {
						className: "ml-auto font-mono text-xs font-bold tabular-nums",
						children: [ee.length, "/3"]
					})
				]
			}),
			/* @__PURE__ */ g("div", {
				className: "flex h-5 flex-none items-center justify-between text-[10px] font-bold wide:hidden",
				children: [/* @__PURE__ */ g("span", { children: [
					y("games.letsgotojapan.favorable"),
					" ",
					S,
					"/3"
				] }), /* @__PURE__ */ g("span", { children: [
					t.dayScore[r],
					" ",
					y("games.letsgotojapan.totalScore")
				] })]
			}),
			/* @__PURE__ */ h("div", {
				className: "jp-day-flow pt-1 wide:min-h-0 wide:flex-1 wide:overflow-y-auto",
				children: /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1 wide:gap-0.5",
					children: [T(0), b.map(({ planned: i, preview: a, originalIndex: o }, s) => {
						let c = _.find((e) => e.day === r && e.index === s);
						return /* @__PURE__ */ g(n, { children: [/* @__PURE__ */ g("div", {
							className: `jp-day-card relative h-[4.75rem] flex-none wide:h-16 ${a ? "ring-2 ring-jp-coral" : ""}`,
							children: [
								i.id ? /* @__PURE__ */ h("button", {
									type: "button",
									onClick: () => f(i.id),
									className: "h-full w-full text-left",
									children: /* @__PURE__ */ h(Q, {
										id: i.id,
										size: "board",
										assignedCity: i.assignedCity,
										active: w === s
									})
								}) : /* @__PURE__ */ h(Ne, {
									city: i.backCity,
									walk: i.walk,
									kept: i.kept,
									size: "board"
								}),
								c && v && /* @__PURE__ */ g("button", {
									type: "button",
									onClick: () => p(c),
									className: "absolute -top-2 right-0 z-10 flex min-h-11 items-center gap-0.5 rounded-md border-2 border-jp-ink bg-jp-paper px-1 text-[9px] font-bold",
									children: [/* @__PURE__ */ h(X, {
										kind: "train",
										size: 17
									}), y(t.trainChoices[c.key] === "start" ? "games.letsgotojapan.trainStart" : t.trainChoices[c.key] === "luxury" ? "games.letsgotojapan.trainLuxury" : "games.letsgotojapan.trainRegular")]
								}),
								e.phase === "route" && v && i.generic && /* @__PURE__ */ g("button", {
									type: "button",
									onClick: () => m(r, s, i.assignedCity === "tokyo" ? "kyoto" : "tokyo"),
									className: "absolute right-0 bottom-0 z-10 min-h-11 rounded-md border-2 border-jp-ink bg-jp-yellow px-1 text-[10px] font-bold",
									children: [y(i.assignedCity === "tokyo" ? "games.letsgotojapan.tokyo" : "games.letsgotojapan.kyoto"), " ⇄"]
								})
							]
						}), !a && T(o + 1)] }, `${r}-${s}-${a ? "preview" : "card"}`);
					})]
				})
			})
		]
	});
}
function $({ title: e, onClose: t, children: n }) {
	let r = c();
	return /* @__PURE__ */ h("div", {
		className: "absolute inset-0 z-20 grid place-items-center bg-jp-ink/60 p-2",
		children: /* @__PURE__ */ g("div", {
			className: "jp-overlay-panel flex max-h-full w-full max-w-md flex-col overflow-hidden rounded-xl border-2 border-jp-ink bg-jp-paper p-2 shadow-[4px_4px_0_var(--color-jp-ink)] wide:max-w-xl",
			children: [/* @__PURE__ */ g("div", {
				className: "flex min-h-11 flex-none items-center justify-between gap-2 border-b border-jp-ink/25 pb-1",
				children: [/* @__PURE__ */ h("h2", {
					className: "text-sm font-extrabold text-jp-ink",
					children: e
				}), t && /* @__PURE__ */ h("button", {
					type: "button",
					onClick: t,
					className: "min-h-11 rounded-md border border-jp-ink bg-jp-sand px-3 text-xs font-bold",
					children: r("games.letsgotojapan.cancel")
				})]
			}), /* @__PURE__ */ h("div", {
				className: "min-h-0 flex-1 overflow-y-auto pt-2",
				children: n
			})]
		})
	});
}
function Be(e) {
	let t = e.public, n = e.private, i = c(), _ = s((e) => e.locale), [v, y] = o({
		owner: e.myRid,
		rid: e.myRid
	}), ee = v.owner === e.myRid ? v.rid : e.myRid, b = (t) => y({
		owner: e.myRid,
		rid: t
	}), [x, S] = o(0), C = a(null), [T, E] = o(null), [O, k] = o(null), [A, j] = o(!1), [M, N] = o("tokyo"), [te, P] = o("none"), [ne, re] = o(null), [ie, ae] = o(null), [oe, se] = o(2), [F, I] = o([]), [L, ce] = o(!1), [le, ue] = o("tokyo"), [de, fe] = o(3), R = t.players.find((t) => t.rid === e.myRid), z = t.phase === "trip" && t.trip ? t.trip.rid : ee, B = t.players.find((e) => e.rid === z) ?? R, V = t.phase === "trip" && t.trip ? t.trip.day : x;
	r(() => {
		window.matchMedia("(orientation: landscape)").matches && (C.current?.children[V])?.scrollIntoView({
			behavior: "smooth",
			block: "nearest",
			inline: "start"
		});
	}, [V]);
	let H = n?.hand ?? [], U = T && H.includes(T) ? T : null, W = !!R && t.phase === "plan" && !R.passed && !R.finalChoicePending && !R.researchPending && R.pendingBonusDay === null, G = !!R && R.played >= t.roundPlay, me = (e) => {
		S(e), W && !G && U && R && k(R.days[e].length < 3 ? {
			day: e,
			index: 0
		} : null);
	}, he = W && !G && !!U && !!O, ge = W && !R?.passed || !!R && t.phase === "route" && !R.routeConfirmed || t.phase === "trip" && t.trip?.rid === e.myRid && (t.trip.waitingWalk || t.trip.waitingHighlight);
	if (d(ge, u), !R || !B) return null;
	let _e = Fe(B), ve = Fe(R), ye = ve.filter((e) => R.trainChoices[e.key] === "start").length, be = ve.filter((e) => R.trainChoices[e.key] === "luxury").length, xe = ve.length === 0 || ye === 1, Se = R.pendingBonusDay, Ce = Se === null ? 0 : Ie(R, Se, t.favorable[Se]), we = R.finalChoicePending ? "finalCity" : R.researchPending ? "researchDiscard" : Se === null ? t.phase === "trip" && t.trip?.rid === e.myRid && t.trip.waitingWalk ? "walkChoice" : t.phase === "trip" && t.trip?.rid === e.myRid && t.trip.waitingHighlight ? "highlight" : "none" : "bonus", K = we === "none" ? te : we, q = () => {
		P("none"), re(null), ae(null);
	}, J = (t) => e.send(t), Te = () => {
		U && O && he && (J(A ? {
			type: "walk",
			discard: U,
			city: M,
			day: O.day,
			index: O.index
		} : {
			type: "place",
			card: U,
			day: O.day,
			index: O.index
		}), E(null), k(null), j(!1));
	}, Ee = i(t.phase === "plan" ? "games.letsgotojapan.phasePlan" : t.phase === "route" ? "games.letsgotojapan.phaseRoute" : t.phase === "trip" ? "games.letsgotojapan.phaseTrip" : "games.letsgotojapan.phaseDone"), Y = null;
	if (K === "details" && ne) {
		let n = D[ne];
		Y = /* @__PURE__ */ g($, {
			title: i("games.letsgotojapan.cardDetails"),
			onClose: q,
			children: [/* @__PURE__ */ h("div", {
				className: "flex justify-center",
				children: /* @__PURE__ */ h(Q, {
					id: ne,
					size: "full"
				})
			}), t.phase === "route" && n.generic && B.rid === e.myRid && /* @__PURE__ */ h("div", {
				className: "mt-2 flex gap-2",
				children: ["tokyo", "kyoto"].map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => {
						for (let t = 0; t < 6; t += 1) {
							let n = R.days[t].findIndex((e) => e.id === ne);
							if (n >= 0) {
								J({
									type: "setCity",
									day: t,
									index: n,
									city: e
								});
								break;
							}
						}
						q();
					},
					className: "min-h-11 flex-1 rounded-md border-2 border-jp-ink bg-jp-yellow text-xs font-bold",
					children: i(e === "tokyo" ? "games.letsgotojapan.tokyo" : "games.letsgotojapan.kyoto")
				}, e))
			})]
		});
	} else if (K === "research") Y = /* @__PURE__ */ g($, {
		title: i("games.letsgotojapan.researchDraw"),
		onClose: q,
		children: [
			/* @__PURE__ */ h("p", {
				className: "mb-2 text-xs font-bold text-jp-ink",
				children: i("games.letsgotojapan.researchChoose", { n: oe })
			}),
			/* @__PURE__ */ h("div", {
				className: "grid grid-cols-4 gap-1",
				children: [
					0,
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => se(e),
					className: `min-h-11 rounded-md border-2 border-jp-ink font-mono font-extrabold ${oe === e ? "bg-jp-coral text-white" : "bg-jp-mint"}`,
					children: e
				}, e))
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => {
					J({
						type: "useResearch",
						tokyo: oe
					}), q();
				},
				className: "mt-3 min-h-12 w-full rounded-md border-2 border-jp-ink bg-jp-coral font-bold text-white",
				children: i("games.letsgotojapan.researchDraw")
			})
		]
	});
	else if (K === "walk") Y = /* @__PURE__ */ h($, {
		title: i("games.letsgotojapan.chooseWalkCity"),
		onClose: q,
		children: /* @__PURE__ */ h("div", {
			className: "flex gap-2",
			children: ["tokyo", "kyoto"].map((e) => /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => {
					N(e), j(!0), q();
				},
				className: `min-h-12 flex-1 rounded-md border-2 border-jp-ink font-bold ${e === "tokyo" ? "bg-jp-blue" : "bg-jp-pink"}`,
				children: i(e === "tokyo" ? "games.letsgotojapan.tokyo" : "games.letsgotojapan.kyoto")
			}, e))
		})
	});
	else if (K === "researchDiscard") Y = /* @__PURE__ */ g($, {
		title: i("games.letsgotojapan.researchDiscard"),
		children: [/* @__PURE__ */ h("div", {
			className: "flex flex-wrap justify-center gap-2",
			children: H.map((e) => /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => I((t) => t.includes(e) ? t.filter((t) => t !== e) : t.length < 3 ? [...t, e] : t),
				"aria-pressed": F.includes(e),
				className: F.includes(e) ? "rounded-md ring-3 ring-jp-coral" : "rounded-md",
				children: /* @__PURE__ */ h(Q, {
					id: e,
					size: "hand"
				})
			}, e))
		}), /* @__PURE__ */ g("button", {
			type: "button",
			disabled: F.length !== 3,
			onClick: () => {
				J({
					type: "discardResearch",
					cards: [
						F[0],
						F[1],
						F[2]
					]
				}), I([]);
			},
			className: "mt-3 min-h-12 w-full rounded-md border-2 border-jp-ink bg-jp-coral font-bold text-white disabled:opacity-40",
			children: [
				i("games.letsgotojapan.researchDiscard"),
				" (",
				F.length,
				"/3)"
			]
		})]
	});
	else if (K === "finalCity") Y = /* @__PURE__ */ h($, {
		title: i("games.letsgotojapan.chooseFinalCity"),
		children: /* @__PURE__ */ h("div", {
			className: "flex gap-2",
			children: ["tokyo", "kyoto"].map((e) => /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => J({
					type: "chooseFinalCity",
					city: e
				}),
				className: `min-h-12 flex-1 rounded-md border-2 border-jp-ink font-bold ${e === "tokyo" ? "bg-jp-blue" : "bg-jp-pink"}`,
				children: i(e === "tokyo" ? "games.letsgotojapan.tokyo" : "games.letsgotojapan.kyoto")
			}, e))
		})
	});
	else if (K === "bonus" && Se !== null) {
		let e = (e) => J({
			type: "dayBonus",
			choice: e
		});
		Y = /* @__PURE__ */ h($, {
			title: i("games.letsgotojapan.bonusPrompt", { n: Ce }),
			children: L ? /* @__PURE__ */ g("div", {
				className: "space-y-2 text-jp-ink",
				children: [
					/* @__PURE__ */ h("p", {
						className: "text-xs font-bold",
						children: i("games.letsgotojapan.chooseWalkCity")
					}),
					/* @__PURE__ */ h("div", {
						className: "flex gap-2",
						children: ["tokyo", "kyoto"].map((e) => /* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => ue(e),
							className: `min-h-11 flex-1 rounded-md border-2 border-jp-ink font-bold ${le === e ? "bg-jp-coral text-white" : "bg-jp-paper"}`,
							children: i(e === "tokyo" ? "games.letsgotojapan.tokyo" : "games.letsgotojapan.kyoto")
						}, e))
					}),
					/* @__PURE__ */ h("p", {
						className: "text-xs font-bold",
						children: i("games.letsgotojapan.chooseSlot")
					}),
					/* @__PURE__ */ h("div", {
						className: "flex gap-1",
						children: [
							0,
							1,
							2,
							3
						].map((e) => /* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => fe(e),
							className: `min-h-11 flex-1 rounded-md border-2 border-jp-ink font-mono font-bold ${de === e ? "bg-jp-coral text-white" : "bg-jp-paper"}`,
							children: e + 1
						}, e))
					}),
					/* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => {
							J({
								type: "dayBonus",
								choice: "extraWalk",
								city: le,
								index: de
							}), ce(!1);
						},
						className: "min-h-12 w-full rounded-md border-2 border-jp-ink bg-jp-coral font-bold text-white",
						children: i("games.letsgotojapan.bonusExtraWalk")
					})
				]
			}) : /* @__PURE__ */ g("div", {
				className: "grid gap-1.5",
				children: [
					/* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => e("mood"),
						className: "min-h-11 rounded-md border-2 border-jp-ink bg-jp-mint font-bold",
						children: i("games.letsgotojapan.bonusMood")
					}),
					Ce >= 2 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => e("research"),
						className: "min-h-11 rounded-md border-2 border-jp-ink bg-jp-mint font-bold",
						children: i("games.letsgotojapan.bonusResearch")
					}), /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => e("wild"),
						className: "min-h-11 rounded-md border-2 border-jp-ink bg-jp-mint font-bold",
						children: i("games.letsgotojapan.bonusWild")
					})] }),
					Ce >= 3 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => e("luxury"),
						className: "min-h-11 rounded-md border-2 border-jp-ink bg-jp-mint font-bold",
						children: i("games.letsgotojapan.bonusLuxury")
					}), /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => ce(!0),
						className: "min-h-11 rounded-md border-2 border-jp-ink bg-jp-mint font-bold",
						children: i("games.letsgotojapan.bonusExtraWalk")
					})] })
				]
			})
		});
	} else if (K === "train" && ie) Y = /* @__PURE__ */ h($, {
		title: i("games.letsgotojapan.chooseTrain"),
		onClose: q,
		children: /* @__PURE__ */ h("div", {
			className: "grid gap-2",
			children: [
				"start",
				"regular",
				"luxury"
			].map((e) => /* @__PURE__ */ g("button", {
				type: "button",
				disabled: e === "luxury" && be >= R.luxury && R.trainChoices[ie.key] !== "luxury",
				onClick: () => {
					J({
						type: "setTrain",
						day: ie.day,
						index: ie.index,
						kind: e
					}), q();
				},
				className: "flex min-h-11 items-center gap-2 rounded-md border-2 border-jp-ink bg-jp-mint px-3 font-bold disabled:opacity-40",
				children: [/* @__PURE__ */ h(X, {
					kind: e === "luxury" ? "luxury" : "train",
					size: 24
				}), i(e === "start" ? "games.letsgotojapan.trainStart" : e === "luxury" ? "games.letsgotojapan.trainLuxury" : "games.letsgotojapan.trainRegular")]
			}, e))
		})
	});
	else if (K === "walkChoice" && t.trip) {
		let e = R.days[t.trip.day][t.trip.slot];
		Y = /* @__PURE__ */ g($, {
			title: i("games.letsgotojapan.walkRevealed"),
			children: [e?.id && /* @__PURE__ */ h("div", {
				className: "flex justify-center",
				children: /* @__PURE__ */ h(Q, {
					id: e.id,
					size: "full"
				})
			}), /* @__PURE__ */ g("div", {
				className: "mt-2 flex gap-2",
				children: [/* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => J({
						type: "chooseWalk",
						activate: !0
					}),
					className: "min-h-12 flex-1 rounded-md border-2 border-jp-ink bg-jp-coral px-1 font-bold text-white",
					children: i("games.letsgotojapan.activateWalk")
				}), /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => J({
						type: "chooseWalk",
						activate: !1
					}),
					className: "min-h-12 flex-1 rounded-md border-2 border-jp-ink bg-jp-mint px-1 font-bold",
					children: i("games.letsgotojapan.keepWalk")
				})]
			})]
		});
	} else if (K === "highlight" && t.trip) {
		let e = R.days[t.trip.day].at(-1);
		Y = /* @__PURE__ */ g($, {
			title: i("games.letsgotojapan.resolveHighlight"),
			children: [
				e?.id && /* @__PURE__ */ h("div", {
					className: "flex justify-center",
					children: /* @__PURE__ */ h(Q, {
						id: e.id,
						size: "full"
					})
				}),
				e?.walk && e.kept && /* @__PURE__ */ h("p", {
					className: "py-2 text-center text-sm font-bold text-jp-ink",
					children: i("games.letsgotojapan.keepWalk")
				}),
				R.wild > 0 && /* @__PURE__ */ g("div", {
					className: "mt-2",
					children: [/* @__PURE__ */ h("p", {
						className: "mb-1 text-xs font-bold text-jp-ink",
						children: i("games.letsgotojapan.useWild")
					}), /* @__PURE__ */ h("div", {
						className: "flex justify-between gap-1",
						children: w.map((e) => /* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => J({
								type: "useWild",
								experience: e
							}),
							className: "grid min-h-11 flex-1 place-items-center rounded-md border-2 border-jp-ink bg-jp-mint",
							children: /* @__PURE__ */ h(X, {
								kind: e,
								size: 24,
								label: i(Z[e])
							})
						}, e))
					})]
				}),
				/* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => J({ type: "resolveHighlight" }),
					className: "mt-2 min-h-12 w-full rounded-md border-2 border-jp-ink bg-jp-coral font-bold text-white",
					children: i("games.letsgotojapan.resolveHighlight")
				})
			]
		});
	}
	let De = /* @__PURE__ */ g("div", {
		className: "jp-controls flex h-full min-h-0 flex-col rounded-t-lg border-t-2 border-jp-ink bg-jp-yellow p-1.5 text-jp-ink wide:rounded-lg wide:border-2",
		children: [
			t.phase === "plan" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ g("div", {
					className: "flex h-5 flex-none items-center justify-between text-xs font-extrabold",
					children: [/* @__PURE__ */ g("span", { children: [
						i("games.letsgotojapan.hand"),
						" ",
						A ? `· ${i("games.letsgotojapan.walk")}` : ""
					] }), /* @__PURE__ */ h("span", {
						className: "font-mono tabular-nums",
						children: H.length
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: "jp-hand flex min-h-0 flex-1 items-center gap-1.5 overflow-x-auto overflow-y-hidden px-1 wide:flex-col wide:items-stretch wide:overflow-x-hidden wide:overflow-y-auto wide:py-1",
					children: H.map((t) => /* @__PURE__ */ g("button", {
						type: "button",
						disabled: !W || G,
						"aria-pressed": U === t,
						onClick: () => {
							let n = R.days[x].length < 3 ? x : R.days.findIndex((e) => e.length < 3);
							E(t), k(n >= 0 ? {
								day: n,
								index: 0
							} : null), n >= 0 && S(n), b(e.myRid);
						},
						className: "flex-none rounded-md text-left disabled:opacity-60 wide:h-21 wide:w-full",
						children: [/* @__PURE__ */ h("div", {
							className: "wide:hidden",
							children: /* @__PURE__ */ h(Q, {
								id: t,
								size: "hand",
								selected: U === t,
								elevated: !0
							})
						}), /* @__PURE__ */ h("div", {
							className: "hidden h-full wide:block",
							children: /* @__PURE__ */ h(Q, {
								id: t,
								size: "side",
								selected: U === t,
								elevated: !0
							})
						})]
					}, t))
				}),
				/* @__PURE__ */ g("div", {
					className: "jp-control-buttons flex min-h-12 flex-none items-center gap-1",
					children: [
						/* @__PURE__ */ g("button", {
							type: "button",
							disabled: !W || R.research < 1,
							onClick: () => P("research"),
							className: "min-h-11 rounded-md border-2 border-jp-ink bg-jp-paper px-2 text-xs font-bold disabled:opacity-40 wide:px-1 wide:text-[10px]",
							children: [/* @__PURE__ */ h(X, {
								kind: "research",
								size: 17
							}), i("games.letsgotojapan.research")]
						}),
						/* @__PURE__ */ g("button", {
							type: "button",
							disabled: !W || G,
							onClick: () => P("walk"),
							className: `min-h-11 rounded-md border-2 border-jp-ink px-2 text-xs font-bold disabled:opacity-40 wide:px-1 wide:text-[10px] ${A ? "bg-jp-coral text-white" : "bg-jp-paper"}`,
							children: [/* @__PURE__ */ h(X, {
								kind: "walk",
								size: 17
							}), i("games.letsgotojapan.walk")]
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							disabled: G ? !W || H.length !== t.roundPlay : !he,
							onClick: G ? () => J({
								type: "pass",
								cards: H
							}) : Te,
							className: "min-h-12 min-w-0 flex-1 rounded-md border-2 border-jp-ink bg-jp-coral px-2 text-xs font-extrabold text-white disabled:opacity-40 wide:px-1 wide:text-[10px]",
							children: i(G ? "games.letsgotojapan.passCards" : A ? "games.letsgotojapan.discardForWalk" : "games.letsgotojapan.confirmPlace")
						})
					]
				})
			] }),
			t.phase === "route" && /* @__PURE__ */ g("div", {
				className: "flex h-full w-full flex-col justify-center gap-2 px-2",
				children: [
					/* @__PURE__ */ h("p", {
						className: "text-center text-sm font-bold",
						children: R.routeConfirmed ? i("games.letsgotojapan.waitingOthers") : i("games.letsgotojapan.routeHint")
					}),
					/* @__PURE__ */ g("p", {
						className: "text-center font-mono text-xs font-bold tabular-nums",
						children: [
							ve.length,
							" ",
							i("games.letsgotojapan.train"),
							" · ",
							ye,
							" ",
							i("games.letsgotojapan.trainStart")
						]
					}),
					/* @__PURE__ */ h("button", {
						type: "button",
						disabled: R.routeConfirmed || !xe,
						onClick: () => J({ type: "confirmRoute" }),
						className: "min-h-12 rounded-md border-2 border-jp-ink bg-jp-coral px-4 font-bold text-white disabled:opacity-40",
						children: i("games.letsgotojapan.confirmRoute")
					})
				]
			}),
			t.phase === "trip" && /* @__PURE__ */ g("div", {
				className: "flex h-full w-full flex-col justify-center gap-2 px-2",
				children: [/* @__PURE__ */ h("p", {
					className: "text-center text-sm font-bold",
					children: t.trip ? `${i(Pe[t.trip.day])} · ${e.members.find((e) => e.rid === t.trip?.rid)?.name ?? t.trip.rid}` : i("games.letsgotojapan.phaseTrip")
				}), /* @__PURE__ */ h("p", {
					className: "text-center text-xs font-bold",
					children: t.lastEvent?.points !== null && t.lastEvent?.points !== void 0 ? `${t.lastEvent.points} ${i("games.letsgotojapan.totalScore")}` : i("games.letsgotojapan.waitingOthers")
				})]
			}),
			t.phase === "done" && /* @__PURE__ */ g("div", {
				className: "h-full w-full overflow-y-auto",
				children: [/* @__PURE__ */ h("div", {
					className: "grid w-full auto-rows-[4rem] grid-cols-2 gap-1.5 wide:auto-rows-[3rem]",
					children: t.players.map((t) => {
						let n = e.members.find((e) => e.rid === t.rid);
						return /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => b(t.rid),
							className: `flex min-h-11 items-center justify-between rounded-md border-2 border-jp-ink px-2 text-xs font-bold ${B.rid === t.rid ? "bg-jp-coral text-white" : "bg-jp-paper"}`,
							children: [/* @__PURE__ */ h("span", {
								className: "truncate",
								children: n ? p(n, _) : t.rid
							}), /* @__PURE__ */ h("span", {
								className: "font-mono text-lg font-black tabular-nums",
								children: t.finalScore ?? 0
							})]
						}, t.rid);
					})
				}), /* @__PURE__ */ g("details", {
					className: "mt-2",
					children: [/* @__PURE__ */ h("summary", {
						className: "flex min-h-11 cursor-pointer items-center px-2 font-bold",
						children: i("games.letsgotojapan.scoreSummary")
					}), /* @__PURE__ */ h(Re, { p: B })]
				})]
			})
		]
	});
	return /* @__PURE__ */ h(f, {
		adaptive: !0,
		className: "jp-adaptive",
		banner: /* @__PURE__ */ g("div", {
			className: "flex flex-col gap-1",
			children: [
				/* @__PURE__ */ g("div", {
					className: "jp-heading jp-waves flex h-14 items-center gap-2 border-b-4 border-jp-yellow bg-jp-teal pl-2 pr-14 text-white wide:h-12",
					children: [
						/* @__PURE__ */ h("span", {
							className: "grid size-10 flex-none place-items-center rounded-lg bg-jp-paper",
							children: /* @__PURE__ */ h(X, {
								kind: "shrine",
								size: 30
							})
						}),
						/* @__PURE__ */ g("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ h("p", {
								className: _ === "en" ? "truncate text-base font-black" : "truncate text-lg font-black",
								children: i("games.letsgotojapan.name")
							}), /* @__PURE__ */ h("p", {
								className: "truncate text-[10px] font-bold",
								children: Ee
							})]
						}),
						/* @__PURE__ */ h("span", {
							className: "flex-none rounded-full bg-jp-coral px-2 py-1 font-mono text-xs font-extrabold tabular-nums",
							children: i("games.letsgotojapan.round", { n: t.round })
						})
					]
				}),
				/* @__PURE__ */ h("div", {
					className: "jp-members flex h-11 flex-none gap-1 overflow-x-auto px-1 wide:hidden",
					children: e.members.map((e) => {
						let n = t.players.find((t) => t.rid === e.rid), r = l[e.colorIndex % l.length].hex;
						return /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => b(e.rid),
							className: `flex min-h-11 flex-none items-center gap-1 rounded-full border border-jp-ink bg-jp-paper px-1.5 text-[10px] font-bold text-jp-ink ${B.rid === e.rid ? "ring-2 ring-jp-coral" : ""}`,
							children: [
								/* @__PURE__ */ h("span", {
									className: "size-3 rounded-full border border-jp-ink",
									style: { background: r }
								}),
								p(e, _),
								n?.passed ? "✓" : ""
							]
						}, e.rid);
					})
				}),
				/* @__PURE__ */ h(Le, {
					p: R,
					round: t.round,
					playNeed: pe[t.round - 1]
				})
			]
		}),
		scroll: !1,
		children: /* @__PURE__ */ g("div", {
			className: "jp-workspace",
			children: [/* @__PURE__ */ g("div", {
				className: "jp-board-shell relative h-full min-h-0",
				children: [/* @__PURE__ */ h("div", {
					className: "jp-table jp-paper-dots flex h-full min-h-0 gap-1.5 p-1.5",
					children: /* @__PURE__ */ g("div", {
						className: "flex min-h-0 min-w-0 flex-1 flex-col gap-1",
						children: [/* @__PURE__ */ h("div", {
							className: "jp-day-index grid h-16 flex-none grid-cols-6 gap-1 wide:h-7",
							children: Pe.map((e, n) => /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => me(n),
								className: `flex min-w-0 flex-col items-center justify-center rounded-md border-2 border-jp-ink text-[10px] font-extrabold text-jp-ink wide:flex-row wide:gap-1 wide:text-[9px] ${V === n ? "bg-jp-coral text-white" : "bg-jp-paper"}`,
								children: [
									/* @__PURE__ */ h("span", { children: i(e).slice(0, 2) }),
									/* @__PURE__ */ h(X, {
										kind: t.favorable[n],
										size: 20,
										className: "wide:hidden"
									}),
									/* @__PURE__ */ g("span", {
										className: "font-mono tabular-nums",
										children: [B.days[n].length, "/3"]
									})
								]
							}, e))
						}), /* @__PURE__ */ h("div", {
							ref: C,
							className: "jp-days min-h-0 flex-1 overflow-y-auto wide:flex wide:gap-1.5 wide:overflow-x-auto wide:overflow-y-hidden",
							children: Pe.map((n, r) => /* @__PURE__ */ h("div", {
								className: `jp-day-slot ${r === V ? "h-fit" : "hidden"} wide:block wide:h-full wide:w-66 wide:flex-none`,
								children: /* @__PURE__ */ h(ze, {
									pub: t,
									p: B,
									day: r,
									selected: O,
									previewCard: B.rid === e.myRid ? U : null,
									previewWalk: A,
									previewCity: M,
									editable: B.rid === e.myRid && W && !G && !!U,
									boundaries: _e,
									trainAllowed: B.rid === e.myRid && t.phase === "route" && !R.routeConfirmed,
									onDay: me,
									onInsert: (e, t) => {
										me(e), k({
											day: e,
											index: t
										});
									},
									onDetails: (e) => {
										re(e), P("details");
									},
									onTrain: (e) => {
										ae(e), P("train");
									},
									onCity: (e, t, n) => J({
										type: "setCity",
										day: e,
										index: t,
										city: n
									})
								})
							}, r))
						})]
					})
				}), Y]
			}), /* @__PURE__ */ h("aside", {
				className: "jp-control-column",
				children: De
			})]
		})
	});
}
//#endregion
//#region src/games/letsgotojapan/bot.ts
function Ve(e) {
	return {
		icons: se(),
		experience: F(),
		mood: e.mood,
		happy: e.happy,
		stress: e.stress,
		wild: e.wild,
		research: e.research,
		dayScore: [
			,
			,
			,
			,
			,
			,
		].fill(0),
		trainScore: 0
	};
}
function He(e) {
	let t = [
		[0, 0],
		[4, 4],
		[7, 8],
		[10, 12],
		[12, 15]
	];
	if (e >= 12) return 15;
	for (let n = 1; n < t.length; n += 1) {
		let [r, i] = t[n];
		if (e <= r) {
			let [a, o] = t[n - 1];
			return o + (i - o) * (e - a) / (r - a);
		}
	}
	return 15;
}
function Ue(e) {
	let t = [], n = null;
	return e.forEach((e, r) => e.forEach((e, i) => {
		n && n.assignedCity !== e.assignedCity && t.push({
			day: r,
			index: i,
			key: `${r}:${i}`
		}), n = e;
	})), t;
}
function We(e, t) {
	let n = {
		tokyo: 0,
		kyoto: 0
	};
	for (let r = 0; r <= t; r += 1) {
		let t = e[r];
		t.length && t.every((e) => e.assignedCity === t[0].assignedCity) && (n[t[0].assignedCity] += 1);
	}
	return n;
}
function Ge(e, t) {
	let n = D[t].requirement;
	if ((n.zero ?? []).some((t) => e.icons[t] > 0)) return 0;
	let r = Object.entries(n.atLeast).reduce((t, [n, r]) => t + Math.max(0, r - e.icons[n]), 0);
	return r === 0 ? 1 : Math.max(0, .55 - r * .2);
}
function Ke(e, t, n) {
	let r = Ve(t), i = Ue(e).length;
	r.trainScore = -2 * Math.max(0, i - 1 - t.luxury) + 2 * Math.min(t.luxury, Math.max(0, i - 1));
	let a = null, o = 0;
	e.forEach((t, i) => {
		if (t.forEach((e) => {
			a && a.assignedCity !== e.assignedCity && L(r, "train"), e.id === null ? (r.dayScore[i] += 2, I(r, 1), L(r, "walk")) : (ce(r, D[e.id], i), e.walk && L(r, "walk")), a = e;
		}), t.length >= 3) {
			let a = n.favorable[i], s = t.reduce((e, t) => e + (t.walk || !t.id ? 0 : D[t.id].icons[a] ?? 0), 0);
			o += s >= 3 ? 4 : s >= 2 ? 2.5 : s >= 1 ? 1.5 : 0;
			let c = t.at(-1);
			if (c?.id) {
				let t = D[c.id], n = Ge(r, c.id), a = de(r, t, We(e, i));
				o += n * (a + Object.values(t.reward.grants).reduce((e, t) => e + t, 0)), ue(r, t) && fe(r, t.reward.grants);
			}
		}
	});
	let s = w.reduce((e, t) => e + He(r.experience[t]), 0);
	return r.dayScore.reduce((e, t) => e + t, 0) + r.trainScore + s + z[r.happy] + B[r.stress] + r.mood * .8 + r.research + o;
}
function qe(e) {
	let t = D[e], n = Object.entries(t.icons).reduce((e, [t, n]) => e + n * (w.includes(t) ? 1.2 : t.startsWith("happy") ? 1 : -.8), 0);
	return t.base + n + (t.reward.points.kind === "fixed" ? t.reward.points.value * .1 : 0);
}
function Je(e) {
	let t = e.find((e) => e.length < 3)?.at(-1);
	if (t) return t.assignedCity;
	let n = e.flat().reduce((e, t) => ({
		...e,
		[t.assignedCity]: e[t.assignedCity] + 1
	}), {
		tokyo: 0,
		kyoto: 0
	});
	return n.tokyo >= n.kyoto ? "tokyo" : "kyoto";
}
function Ye(e, t, n, r) {
	if (r) {
		let e = t.days.findIndex((e) => e.length < 3);
		return e < 0 || !n.length ? null : {
			type: "place",
			card: n[0],
			day: e,
			index: t.days[e].length
		};
	}
	let i = { current: null }, a = (n, r, a, o, s = 0) => {
		let c = t.days.map((e) => [...e]);
		c[a].splice(o, 0, r);
		let l = Ke(c, t, e) + s;
		(!i.current || l > i.current.value) && (i.current = {
			action: n,
			value: l
		});
	};
	for (let e of n) {
		let n = D[e];
		for (let r = 0; r < 6; r += 1) {
			let i = t.days[r];
			if (!(i.length >= 3)) for (let t = 0; t <= i.length; t += 1) a({
				type: "place",
				card: e,
				day: r,
				index: t
			}, {
				id: e,
				backCity: n.city,
				assignedCity: n.city,
				generic: n.generic,
				walk: !1,
				revealed: !0,
				kept: !1
			}, r, t);
		}
	}
	let o = [...n].sort((e, t) => qe(e) - qe(t))[0];
	if (o && D[o].base <= 2 && e.round <= 11 && t.research < 3) for (let e of ["tokyo", "kyoto"]) for (let n = 0; n < 6; n += 1) {
		let r = t.days[n];
		if (!(r.length >= 3)) for (let t = 0; t <= r.length; t += 1) a({
			type: "walk",
			discard: o,
			city: e,
			day: n,
			index: t
		}, {
			id: null,
			backCity: e,
			assignedCity: e,
			generic: !1,
			walk: !0,
			revealed: !1,
			kept: !1
		}, n, t, .4);
	}
	return i.current?.action ?? null;
}
function Xe(e) {
	if (e.routeConfirmed) return null;
	let t = Ue(e.days).length, n = { current: null };
	if (e.days.forEach((r, i) => r.forEach((r, a) => {
		if (!r.generic) return;
		let o = r.assignedCity === "tokyo" ? "kyoto" : "tokyo", s = e.days.map((e) => [...e]);
		s[i][a] = {
			...r,
			assignedCity: o
		};
		let c = Ue(s).length;
		c < t && (!n.current || c < n.current.changes) && (n.current = {
			day: i,
			index: a,
			city: o,
			changes: c
		});
	})), n.current) return {
		type: "setCity",
		day: n.current.day,
		index: n.current.index,
		city: n.current.city
	};
	let r = Ue(e.days);
	if (!r.length) return { type: "confirmRoute" };
	if (!r.some((t) => e.trainChoices[t.key] === "start")) {
		let e = r[0];
		return {
			type: "setTrain",
			day: e.day,
			index: e.index,
			kind: "start"
		};
	}
	if (r.filter((t) => e.trainChoices[t.key] === "luxury").length < e.luxury) {
		let t = r.find((t) => !e.trainChoices[t.key]);
		if (t) return {
			type: "setTrain",
			day: t.day,
			index: t.index,
			kind: "luxury"
		};
	}
	return { type: "confirmRoute" };
}
function Ze(e, t) {
	let n = t.trip;
	if (!n || !e.wild) return null;
	let r = e.days[n.day].at(-1), i = r?.id ? D[r.id].requirement : null, a = i && Object.entries(i.atLeast).filter(([t, n]) => (e.icons[t] ?? 0) < n);
	return a?.length && a.every(([t, n]) => w.includes(t) && n - e.icons[t] <= e.wild) ? a[0][0] : n.day < 5 ? null : [...w].sort((t, n) => He(e.experience[n] + 1) - He(e.experience[n]) - (He(e.experience[t] + 1) - He(e.experience[t])))[0];
}
var Qe = (e, t) => {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid);
	if (!r || n.phase === "done") return null;
	let i = e.private?.hand ?? [], a = t.difficulty === "weak";
	if (n.phase === "plan") {
		if (r.passed) return null;
		if (r.finalChoicePending) return { action: {
			type: "chooseFinalCity",
			city: Je(r.days)
		} };
		if (r.researchPending) {
			let e = [...i].sort((e, t) => qe(e) - qe(t)).slice(0, 3);
			return e.length === 3 ? { action: {
				type: "discardResearch",
				cards: [
					e[0],
					e[1],
					e[2]
				]
			} } : null;
		}
		if (r.pendingBonusDay !== null) {
			let e = r.pendingBonusDay, t = r.days[e].reduce((t, r) => t + (r.walk || !r.id ? 0 : D[r.id].icons[n.favorable[e]] ?? 0), 0);
			return !a && t >= 3 ? Ue(r.days).length > r.luxury + 1 ? { action: {
				type: "dayBonus",
				choice: "luxury"
			} } : { action: {
				type: "dayBonus",
				choice: "extraWalk",
				city: r.days[e][1]?.assignedCity ?? r.days[e][2]?.assignedCity ?? "tokyo",
				index: 2
			} } : !a && t >= 2 && n.round <= 9 && r.research < 2 ? { action: {
				type: "dayBonus",
				choice: "research"
			} } : !a && t >= 2 ? { action: {
				type: "dayBonus",
				choice: "wild"
			} } : { action: {
				type: "dayBonus",
				choice: "mood"
			} };
		}
		if (r.played >= n.roundPlay) return i.length === n.roundPlay ? { action: {
			type: "pass",
			cards: i
		} } : null;
		let e = t.memory ?? {};
		if (!a && r.research >= 2 && n.round < 13 && e.researchRound !== n.round && i.length >= 2 && Math.max(...i.map((e) => qe(e))) < 4) return {
			action: {
				type: "useResearch",
				tokyo: 2
			},
			memory: {
				...e,
				researchRound: n.round
			}
		};
		let o = Ye(n, r, i, a);
		return o ? { action: o } : null;
	}
	if (n.phase === "route") {
		let e = Xe(r);
		return e ? { action: e } : null;
	}
	if (n.trip?.rid !== t.rid) return null;
	if (n.trip.waitingWalk) {
		let e = r.days[n.trip.day][n.trip.slot], t = e?.id ? D[e.id] : null, i = t ? qe(t.id) : 0;
		return { action: {
			type: "chooseWalk",
			activate: a ? !0 : i >= (n.trip.slot === r.days[n.trip.day].length - 1 ? 3 : 2)
		} };
	}
	if (n.trip.waitingHighlight) {
		let e = a ? null : Ze(r, n);
		return { action: e ? {
			type: "useWild",
			experience: e
		} : { type: "resolveHighlight" } };
	}
	return null;
};
//#endregion
//#region src/games/letsgotojapan/endgame-review.tsx
function $e({ board: e, renderResult: t, ...n }) {
	let s = c(), [l, u] = o(!0), [d, f] = o(null), p = a(null), m = a(null), v = a(null);
	r(() => {
		if (!d) return;
		v.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let b = (e) => {
		f(null), u(e), requestAnimationFrame(() => (e ? p : m).current?.focus({ preventScroll: !0 }));
	}, x = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), S = {
		...n,
		...x
	};
	return /* @__PURE__ */ g("div", {
		className: "letsgotojapan-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ h("div", {
				className: "letsgotojapan-endgame-board",
				inert: l,
				children: e
			}),
			/* @__PURE__ */ h("div", {
				className: "letsgotojapan-endgame-overlay",
				hidden: !l,
				children: /* @__PURE__ */ g("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), b(!1));
					},
					className: "letsgotojapan-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ g("header", {
							className: "letsgotojapan-endgame-heading",
							children: [/* @__PURE__ */ g("div", {
								className: "letsgotojapan-endgame-brand",
								children: [/* @__PURE__ */ h("span", {
									"aria-hidden": "true",
									children: k.icon
								}), s(k.nameKey)]
							}), /* @__PURE__ */ h("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": s("games.letsgotojapan.reviewHide"),
								title: s("games.letsgotojapan.reviewHide"),
								onClick: () => b(!1),
								children: /* @__PURE__ */ h(y, { size: 19 })
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: "letsgotojapan-endgame-result",
							inert: d !== null,
							children: t(S)
						}),
						d && /* @__PURE__ */ g("div", {
							className: "letsgotojapan-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ h("button", {
								type: "button",
								ref: v,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: s(d.label === "again" ? "games.letsgotojapan.reviewConfirmAgain" : "games.letsgotojapan.reviewConfirmLobby")
							}), /* @__PURE__ */ h("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: s("games.letsgotojapan.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "letsgotojapan-endgame-toolbar",
				hidden: l,
				children: /* @__PURE__ */ g("button", {
					type: "button",
					className: "btn-base",
					ref: m,
					onClick: () => b(!0),
					children: [
						/* @__PURE__ */ h(ee, { size: 18 }),
						s("games.letsgotojapan.reviewShow"),
						/* @__PURE__ */ h(_, { size: 18 })
					]
				})
			})
		]
	});
}
function et({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: l, rows: u, renderRowExtra: d, summary: f, navigation: _, content: ee, afterRanking: x, scoreUnit: S, rankOf: C }) {
	let w = c(), T = s((e) => e.locale), [E, D] = o({}), O = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? p(n, T) : e;
	}, A = (t, n) => C?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), j = e.ranking.some((t) => e.scores?.[t] !== void 0), M = (t, n) => /* @__PURE__ */ g("div", {
		className: "letsgotojapan-score-identity",
		children: [
			/* @__PURE__ */ g("span", {
				className: "letsgotojapan-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ h("span", {
					"aria-label": w("games.letsgotojapan.reviewWinner"),
					children: "♛ "
				}), j && A(t, n)]
			}),
			/* @__PURE__ */ g("span", {
				className: "letsgotojapan-score-name",
				children: [O(t), t === r && /* @__PURE__ */ h("small", { children: w("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ g("small", {
				className: "letsgotojapan-score-autopilot",
				children: [
					/* @__PURE__ */ h(v, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), N = (t) => e.ranking.map((n) => /* @__PURE__ */ h("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ g("div", {
		className: "letsgotojapan-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ h(b, {}),
			_,
			/* @__PURE__ */ g("div", {
				className: "letsgotojapan-score-body",
				children: [
					f && /* @__PURE__ */ h("div", {
						className: "letsgotojapan-score-summary",
						children: f
					}),
					i !== void 0 && /* @__PURE__ */ h("p", {
						className: "letsgotojapan-score-hints",
						children: w("session.hint.usedCount", { n: i })
					}),
					ee ?? (u?.length ? /* @__PURE__ */ h("div", {
						className: "letsgotojapan-score-table-scroll",
						children: /* @__PURE__ */ g("table", {
							className: "letsgotojapan-score-table",
							"aria-label": w(k.nameKey),
							children: [
								/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { scope: "col" }), /* @__PURE__ */ h(m, { children: e.ranking.map((t, n) => /* @__PURE__ */ h("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: M(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ h("tbody", { children: u.map((e, t) => /* @__PURE__ */ g(n, { children: [/* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ g("button", {
										type: "button",
										"aria-expanded": !!E[t],
										onClick: () => D((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ h(y, { size: 15 }), e.label]
									}) : e.label
								}), N(e)] }), E[t] && e.details?.map((e, t) => /* @__PURE__ */ g("tr", {
									className: "letsgotojapan-score-sub",
									children: [/* @__PURE__ */ h("th", {
										scope: "row",
										children: e.label
									}), N(e)]
								}, t))] }, t)) }),
								j && /* @__PURE__ */ h("tfoot", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "row",
									children: w("games.letsgotojapan.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ h("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ h("ol", {
						className: "letsgotojapan-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ g("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ g("div", {
								className: "letsgotojapan-score-rankline",
								children: [M(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ g("strong", {
									className: "letsgotojapan-score-points",
									children: [e.scores[t], S && /* @__PURE__ */ h("small", { children: S })]
								})]
							}), d?.(t)]
						}, t))
					})),
					x,
					!!u?.length && d && /* @__PURE__ */ h("div", {
						className: "letsgotojapan-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ g("details", { children: [/* @__PURE__ */ h("summary", { children: O(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ g("footer", {
				className: "letsgotojapan-score-actions",
				children: [
					l && /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-quiet",
						onClick: l,
						children: w("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: w("session.result.playAgain")
					}),
					!a && !l && /* @__PURE__ */ h("p", { children: w("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/letsgotojapan/endgame-scores.tsx
function tt(e) {
	let t = c(), n = e.public, r = (e) => n.players.find((t) => t.rid === e), i = [
		"games.letsgotojapan.monday",
		"games.letsgotojapan.tuesday",
		"games.letsgotojapan.wednesday",
		"games.letsgotojapan.thursday",
		"games.letsgotojapan.friday",
		"games.letsgotojapan.saturday"
	], a = (e) => {
		let t = r(e);
		return t && t.finalScore !== null ? [
			t.trainScore,
			z[t.happy] + B[t.stress],
			w.reduce((e, n) => e + R(t.experience[n]), 0),
			t.research
		] : [];
	}, o = [...i.map((e, n) => ({
		label: t(e),
		value: (e) => r(e)?.dayScore[n] ?? "—"
	})), ...[
		"games.letsgotojapan.scoreTrain",
		"games.letsgotojapan.scoreMood",
		"games.letsgotojapan.scoreExperience",
		"games.letsgotojapan.scoreResearch"
	].map((e, n) => ({
		label: t(e),
		value: (e) => a(e)[n] ?? "—"
	}))], s = {
		shrine: "games.letsgotojapan.iconShrine",
		food: "games.letsgotojapan.iconFood",
		nature: "games.letsgotojapan.iconNature",
		shopping: "games.letsgotojapan.iconShopping",
		unique: "games.letsgotojapan.iconUnique"
	};
	return /* @__PURE__ */ h(et, {
		...e,
		rows: o,
		renderRowExtra: (e) => /* @__PURE__ */ h("div", {
			className: "flex flex-wrap gap-3",
			children: w.map((n) => /* @__PURE__ */ g("span", {
				className: "inline-flex items-center gap-1",
				children: [/* @__PURE__ */ h(X, {
					kind: n,
					size: 20,
					label: t(s[n])
				}), r(e)?.experience[n] ?? "—"]
			}, n))
		})
	});
}
//#endregion
//#region src/games/letsgotojapan/game-over.tsx
function nt(e) {
	return /* @__PURE__ */ h(tt, { ...e });
}
function rt(e) {
	return /* @__PURE__ */ h($e, {
		...e,
		board: /* @__PURE__ */ h(Be, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ h(nt, { ...e })
	});
}
//#endregion
//#region src/games/letsgotojapan/game-over-row.tsx
var it = [
	"games.letsgotojapan.monday",
	"games.letsgotojapan.tuesday",
	"games.letsgotojapan.wednesday",
	"games.letsgotojapan.thursday",
	"games.letsgotojapan.friday",
	"games.letsgotojapan.saturday"
], at = {
	shrine: "games.letsgotojapan.iconShrine",
	food: "games.letsgotojapan.iconFood",
	nature: "games.letsgotojapan.iconNature",
	shopping: "games.letsgotojapan.iconShopping",
	unique: "games.letsgotojapan.iconUnique"
};
function ot({ public: e, rid: t }) {
	let n = c(), r = e.players.find((e) => e.rid === t);
	if (!r || r.finalScore === null) return null;
	let i = z[r.happy] + B[r.stress], a = w.reduce((e, t) => e + R(r.experience[t]), 0), o = [
		{
			key: "games.letsgotojapan.scoreTrain",
			value: r.trainScore
		},
		{
			key: "games.letsgotojapan.scoreMood",
			value: i
		},
		{
			key: "games.letsgotojapan.scoreExperience",
			value: a
		},
		{
			key: "games.letsgotojapan.scoreResearch",
			value: r.research
		}
	];
	return /* @__PURE__ */ g("div", {
		className: "jp-over-row mt-2 border-t border-jp-ink/20 pt-1.5 text-jp-ink",
		children: [
			/* @__PURE__ */ h("div", {
				className: "grid grid-cols-6 gap-0.5",
				children: it.map((e, t) => /* @__PURE__ */ g("span", {
					className: "flex min-w-0 flex-col items-center rounded bg-jp-paper text-[10px] font-bold",
					children: [/* @__PURE__ */ h("span", { children: n(e).slice(0, 2) }), /* @__PURE__ */ h("span", {
						className: "font-mono text-xs tabular-nums",
						children: r.dayScore[t]
					})]
				}, e))
			}),
			/* @__PURE__ */ h("div", {
				className: "mt-1 grid grid-cols-4 gap-0.5",
				children: o.map(({ key: e, value: t }) => /* @__PURE__ */ g("span", {
					className: "flex min-w-0 flex-col items-center rounded bg-jp-mint px-0.5 text-center text-[9px] font-bold",
					children: [/* @__PURE__ */ h("span", {
						className: "truncate",
						children: n(e)
					}), /* @__PURE__ */ h("span", {
						className: "font-mono text-xs tabular-nums",
						children: t
					})]
				}, e))
			}),
			/* @__PURE__ */ h("div", {
				className: "mt-1 flex justify-around",
				children: w.map((e) => /* @__PURE__ */ g("span", {
					className: "flex items-center gap-0.5 font-mono text-[10px] font-bold tabular-nums",
					children: [/* @__PURE__ */ h(X, {
						kind: e,
						size: 15,
						label: n(at[e])
					}), r.experience[e]]
				}, e))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/letsgotojapan/entry.tsx
var st = {
	definition: Y,
	View: Be,
	bot: Qe,
	OverView: rt,
	RowView: ot,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "来去日本",
			desc: "规划东京与京都的六日旅程，记录最难忘的旅行",
			rules: "目标:\n· 规划东京与京都的六日行程，以旅行总分争胜。\n准备:\n· 基础版有 160 张活动卡，两座城市各 80 张。\n· 每人有六日行程板，每日可放 3 张活动卡。\n· 随机排列六枚有利条件，所有玩家使用同一顺序。\n规划:\n· 共进行 13 轮，前 4 轮各放 1 张、传 1 张。\n· 中间 5 轮各放 2 张、传 2 张。\n· 最后 4 轮各放 1 张、传 1 张。\n· 前 7 轮向左传牌；第 8 轮起向右传牌。\n· 传来的牌背面朝上，直到指定轮次才能查看。\n· 每张牌可插入某日任意空位，放下后不可移动。\n· 第 3 张牌放入当天时，按有利图标选择日奖励。\n· 研究标记可抽 3 张牌，随后立即弃置 3 张。\n· 散步会弃置一张手牌，放入未知牌并获得研究标记。\n旅行:\n· 规划结束后，为每次城市切换安排列车标记。\n· 从周一到周六，逐张激活活动并结算当日亮点。\n· 遇到散步牌时，翻看后选择激活或保留背面。\n· 万能标记可在亮点结算前推进一类体验。\n结束:\n· 合计六日、列车、心情、体验及剩余研究分数。\n· 总分最高者获胜；同分玩家共享胜利。",
			phasePlan: "规划行程",
			phaseRoute: "安排列车",
			phaseTrip: "开启旅行",
			phaseDone: "旅行结束",
			round: "第 {{n}} / 13 轮",
			playNeed: "本轮放置 {{n}} 张",
			passLeft: "向左传",
			passRight: "向右传",
			tokyo: "东京",
			kyoto: "京都",
			generic: "通用活动",
			walk: "散步",
			monday: "周一",
			tuesday: "周二",
			wednesday: "周三",
			thursday: "周四",
			friday: "周五",
			saturday: "周六",
			itinerary: "六日行程",
			hand: "手牌",
			favorable: "有利条件",
			highlight: "当日亮点",
			basePoints: "基础 {{n}} 分",
			bonusPoints: "奖励 {{n}} 分",
			cardsPlaced: "已安排 {{n}} / 3",
			roundProgress: "本轮 {{n}}/{{total}}",
			insertAt: "插入第 {{n}} 位",
			cancel: "取消",
			cardDetails: "活动卡详情",
			chooseSlot: "选择插入位置",
			chooseTrain: "选择列车标记",
			tokyoDays: "东京整日",
			kyotoDays: "京都整日",
			iconShrine: "寺社",
			iconFood: "美食",
			iconNature: "自然",
			iconShopping: "购物",
			iconUnique: "奇遇",
			iconHappy1: "省钱愉悦",
			iconHappy2: "放松愉悦",
			iconStress1: "花费压力",
			iconStress2: "辛劳压力",
			research: "研究",
			wild: "万能",
			luxury: "豪华列车",
			mood: "心情",
			happiness: "快乐",
			stress: "压力",
			experience: "体验",
			train: "列车",
			dayScore: "当日得分",
			totalScore: "总分",
			pickCard: "选择一张手牌",
			insertHere: "插入这里",
			confirmPlace: "放入行程",
			chooseWalkCity: "选择散步牌堆",
			discardForWalk: "弃牌散步",
			researchDraw: "使用研究标记",
			researchChoose: "抽东京牌 {{n}} 张，其余抽京都牌",
			researchDiscard: "立即弃置 3 张牌",
			passCards: "传出剩余手牌",
			waitingOthers: "等待其他玩家…",
			alreadyPassed: "已传牌",
			chooseFinalCity: "先选最后一次抽牌的城市",
			bonusPrompt: "该日有 {{n}} 个有利图标，选择 1 项奖励",
			bonusMood: "心情前进 1 格",
			bonusResearch: "获得 2 个研究标记",
			bonusWild: "获得 1 个万能标记",
			bonusLuxury: "获得 1 枚豪华列车",
			bonusExtraWalk: "增加一次散步",
			chooseCity: "选择计作的城市",
			trainStart: "起始列车",
			trainLuxury: "豪华列车",
			trainRegular: "普通列车",
			routeHint: "为每次城市切换指定列车",
			confirmRoute: "确认列车安排",
			walkRevealed: "散步发现了这张牌",
			activateWalk: "激活这项活动",
			keepWalk: "保留背面收益",
			resolveHighlight: "结算当日亮点",
			useWild: "使用万能标记",
			requirement: "达成条件",
			requirementShort: "条件",
			reward: "获得奖励",
			highlightShort: "亮点",
			notMet: "未达成",
			pointsPer: "每组 {{n}} 分",
			pointsPerShort: "{{n}} 分/组",
			pointsFixed: "{{n}} 分",
			scoreSummary: "旅行结算",
			scoreTrain: "列车",
			scoreMood: "心情",
			scoreExperience: "体验",
			scoreResearch: "研究",
			errTurn: "现在不能执行此操作",
			errCard: "这张牌不可使用",
			errDay: "这个日期没有空位",
			errDeck: "该牌堆已无可抽的牌",
			errResearch: "现在不能使用或弃置研究牌",
			errBonus: "这项日奖励不可选择",
			errPass: "必须先安排本轮活动，再传出剩余牌",
			errRoute: "列车位置或城市选择无效",
			errTrain: "起始或豪华列车数量不符",
			errWild: "现在不能使用万能标记"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Let's Go! To Japan",
			desc: "Plan six days in Tokyo and Kyoto and make the trip your own",
			rules: "Goal:\n· Plan six days in Tokyo and Kyoto and earn the most points.\nSetup:\n· The base deck has 160 Activity cards, 80 per city.\n· Each player has six days with 3 Activity spaces per day.\n· Shuffle the six Favorable Conditions; all players share their order.\nPlanning:\n· Play 13 rounds; in the first 4, play 1 card and pass 1.\n· In the middle 5 rounds, play 2 cards and pass 2.\n· In the last 4 rounds, play 1 card and pass 1.\n· Pass left for 7 rounds, then right from round 8 onward.\n· Passed cards stay face down until their draw round.\n· Insert a card in any open day position; it cannot move later.\n· On a day’s 3rd card, choose a bonus for matching icons.\n· A Research token draws 3 cards; immediately discard 3.\n· A Walk discards a hand card, adds an unknown card and gains Research.\nTrip:\n· After planning, assign a Train token to every city switch.\n· Activate cards Monday to Saturday, then score each day’s Highlight.\n· At a Walk, reveal the card and choose to activate it or keep it down.\n· A Wild token advances one Experience before a Highlight.\nEnd:\n· Sum days, trains, mood, experience and unused Research.\n· Highest score wins; tied players share the win.",
			phasePlan: "Plan the trip",
			phaseRoute: "Assign trains",
			phaseTrip: "Take the trip",
			phaseDone: "Trip complete",
			round: "Round {{n}} / 13",
			playNeed: "Place {{n}} cards",
			passLeft: "Pass left",
			passRight: "Pass right",
			tokyo: "Tokyo",
			kyoto: "Kyoto",
			generic: "Generic activity",
			walk: "Walk",
			monday: "Monday",
			tuesday: "Tuesday",
			wednesday: "Wednesday",
			thursday: "Thursday",
			friday: "Friday",
			saturday: "Saturday",
			itinerary: "Six-day itinerary",
			hand: "Hand",
			favorable: "Favorable Condition",
			highlight: "Highlight of the Day",
			basePoints: "{{n}} base points",
			bonusPoints: "{{n}} bonus points",
			cardsPlaced: "{{n}} / 3 placed",
			roundProgress: "This round {{n}}/{{total}}",
			insertAt: "Insert at position {{n}}",
			cancel: "Cancel",
			cardDetails: "Activity card details",
			chooseSlot: "Choose an insertion position",
			chooseTrain: "Choose a Train token",
			tokyoDays: "Tokyo only days",
			kyotoDays: "Kyoto only days",
			iconShrine: "Shrines",
			iconFood: "Food",
			iconNature: "Nature",
			iconShopping: "Shopping",
			iconUnique: "Unique",
			iconHappy1: "Bargain joy",
			iconHappy2: "Relaxing joy",
			iconStress1: "Cost stress",
			iconStress2: "Strenuous stress",
			research: "Research",
			wild: "Wild",
			luxury: "Luxury Train",
			mood: "Mood",
			happiness: "Happiness",
			stress: "Stress",
			experience: "Experience",
			train: "Train",
			dayScore: "Day score",
			totalScore: "Total score",
			pickCard: "Choose a hand card",
			insertHere: "Insert here",
			confirmPlace: "Add to itinerary",
			chooseWalkCity: "Choose a Walk deck",
			discardForWalk: "Discard for a Walk",
			researchDraw: "Spend Research",
			researchChoose: "Draw {{n}} Tokyo cards and the rest from Kyoto",
			researchDiscard: "Immediately discard 3 cards",
			passCards: "Pass your remaining cards",
			waitingOthers: "Waiting for other players…",
			alreadyPassed: "Cards passed",
			chooseFinalCity: "Choose your final draw city first",
			bonusPrompt: "{{n}} matching icons: choose one Day Bonus",
			bonusMood: "Move Mood right 1",
			bonusResearch: "Gain 2 Research tokens",
			bonusWild: "Gain 1 Wild token",
			bonusLuxury: "Gain 1 Luxury Train",
			bonusExtraWalk: "Add an Extra Walk",
			chooseCity: "Choose its city",
			trainStart: "Starting Train",
			trainLuxury: "Luxury Train",
			trainRegular: "Regular Train",
			routeHint: "Assign a train to each city switch",
			confirmRoute: "Confirm trains",
			walkRevealed: "Your Walk revealed this card",
			activateWalk: "Activate this activity",
			keepWalk: "Keep it face down",
			resolveHighlight: "Score the day’s Highlight",
			useWild: "Spend a Wild token",
			requirement: "Requirement met",
			requirementShort: "Need",
			reward: "Reward",
			highlightShort: "Bonus",
			notMet: "Not met",
			pointsPer: "{{n}} per set",
			pointsPerShort: "{{n}}/set",
			pointsFixed: "{{n}} points",
			scoreSummary: "Trip scoring",
			scoreTrain: "Trains",
			scoreMood: "Mood",
			scoreExperience: "Experience",
			scoreResearch: "Research",
			errTurn: "This action is not available now",
			errCard: "That card cannot be used",
			errDay: "That day has no open position",
			errDeck: "There are no cards left to draw there",
			errResearch: "Research cannot be used or discarded now",
			errBonus: "That Day Bonus is unavailable",
			errPass: "Plan this round’s activities before passing",
			errRoute: "Invalid train position or city choice",
			errTrain: "Starting or Luxury Train count is invalid",
			errWild: "A Wild token cannot be used now"
		}
	}
};
//#endregion
export { st as default };
