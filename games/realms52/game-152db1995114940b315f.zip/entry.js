import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { useWakeLock as l } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { IconBack as m, IconBot as h, IconExpand as g, IconLog as _ } from "@bgparty/sdk/icons";
import { seatName as v } from "@bgparty/sdk/ui/player-strip";
import { Confetti as y } from "@bgparty/sdk/ui/confetti";
//#region src/games/realms52/data.ts
var b = [
	0,
	1,
	2,
	3
], x = (e) => e % 13 + 1, S = (e) => Math.floor(e / 13), ee = () => Array.from({ length: 52 }, (e, t) => t), C = (e, t) => x(e) === x(t) ? S(e) < S(t) : x(e) > x(t), w = (e) => Object.fromEntries(e), T = {
	m1: {
		id: "m1",
		startRoom: "start",
		bossRoom: "boss",
		hpTrack: w([
			[24, "wound"],
			[16, "wound"],
			[8, "wound"],
			[20, "parry"],
			[14, "parry"],
			[10, "parry"],
			[4, "parry"],
			[22, "refresh1"],
			[12, "refresh1"],
			[6, "refresh1"],
			[18, "refresh2"],
			[2, "refresh2"]
		]),
		enemies: {
			0: {
				name: "goblin",
				acts: {
					0: { effs: [{
						k: "attack",
						v: "X"
					}] },
					1: { effs: [{
						k: "attack",
						v: 5,
						ifDealt: [{ k: "exhaustHighestReady" }]
					}] },
					2: { effs: [{
						k: "exhaustAllLt",
						n: 8
					}] },
					3: {
						instant: !0,
						effs: [{
							k: "destroy",
							v: 1
						}]
					}
				}
			},
			1: {
				name: "ghoul",
				acts: {
					0: { effs: [{
						k: "attack",
						v: "X",
						ifNoDefend: [{
							k: "heal",
							v: 2
						}]
					}] },
					1: { effs: [{
						k: "attack",
						v: 7,
						onlySuits: [0, 1]
					}] },
					2: { effs: [{
						k: "heal",
						v: "X+5",
						cond: "unhurt"
					}] },
					3: {
						instant: !0,
						effs: [{
							k: "heal",
							v: 6
						}]
					}
				}
			},
			2: {
				name: "lizard",
				acts: {
					0: { effs: [{
						k: "attack",
						v: "X+5"
					}] },
					1: { effs: [{
						k: "attack",
						v: "X",
						perfectBlockBacklash: "X"
					}] },
					2: { effs: [{
						k: "heal",
						v: "2X",
						cond: "unhurt"
					}] },
					3: { effs: [{
						k: "block",
						v: 5,
						then: [{
							k: "attack",
							v: "X",
							cond: "unhurt"
						}]
					}] }
				}
			},
			3: {
				name: "wight",
				autoWound: !0,
				acts: {
					0: { effs: [{
						k: "attack",
						v: "X"
					}] },
					1: { effs: [{
						k: "attack",
						v: 8,
						singleEquipOnly: !0
					}] },
					2: { effs: [{
						k: "block",
						v: 8,
						then: [{
							k: "exhaustHighestReady",
							cond: "unhurt"
						}]
					}] },
					3: {
						instant: !0,
						effs: [{
							k: "destroy",
							v: "woundCount"
						}]
					}
				}
			}
		},
		rooms: [
			{
				id: "start",
				kind: "start"
			},
			{
				id: "library",
				kind: "keep",
				draw: 3,
				slots: ["item"]
			},
			{
				id: "cloaked",
				kind: "event",
				table: {
					0: "item",
					1: "equip",
					2: "wound",
					3: "loot"
				}
			},
			{
				id: "merchant",
				kind: "merchant",
				max: 2
			},
			{
				id: "statue",
				kind: "challenge",
				filter: "face",
				tiers: [
					{
						min: 27,
						rewards: 4
					},
					{
						min: 14,
						rewards: 2
					},
					{
						min: 0,
						wounds: 1
					}
				]
			},
			{
				id: "stairs",
				kind: "challenge",
				filter: "red",
				tiers: [
					{
						min: 21,
						rewards: 3
					},
					{
						min: 11,
						rewards: 1
					},
					{
						min: 0,
						wounds: 1
					}
				]
			},
			{
				id: "springW",
				kind: "spring"
			},
			{
				id: "springE",
				kind: "spring"
			},
			{
				id: "springS",
				kind: "spring"
			},
			{
				id: "chest",
				kind: "event",
				table: {
					0: "loot",
					1: "wound",
					2: "loot2",
					3: "wound2"
				}
			},
			{
				id: "vision",
				kind: "event",
				table: {
					0: "loot",
					1: "item",
					2: "enemyA",
					3: "wound"
				}
			},
			{
				id: "wounded",
				kind: "event",
				table: {
					0: "wound",
					1: "loot",
					2: "item",
					3: "equip"
				}
			},
			{
				id: "wall",
				kind: "challenge",
				filter: "even",
				tiers: [
					{
						min: 13,
						rewards: 2
					},
					{
						min: 7,
						rewards: 1
					},
					{
						min: 0,
						wounds: 1
					}
				]
			},
			{
				id: "flood",
				kind: "challenge",
				filter: "black",
				tiers: [
					{
						min: 14,
						rewards: 2
					},
					{
						min: 7,
						rewards: 1
					},
					{
						min: 0,
						wounds: 1
					}
				]
			},
			{
				id: "goblin",
				kind: "keep",
				draw: 3,
				slots: ["loot", "item"]
			},
			{
				id: "lizard",
				kind: "keep",
				draw: 3,
				slots: ["loot", "item"]
			},
			{
				id: "stash",
				kind: "keep",
				draw: 3,
				slots: ["loot"]
			},
			{
				id: "traveller",
				kind: "merchant",
				max: 1
			},
			{
				id: "jailer",
				kind: "enemy",
				rank: "B",
				extraReward: 1
			},
			{
				id: "boss",
				kind: "boss"
			}
		],
		edges: [
			{
				a: "start",
				b: "library",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "start",
				b: "cloaked",
				doors: [{
					t: "cost",
					n: 4
				}],
				directed: !0
			},
			{
				a: "library",
				b: "wounded",
				doors: [{
					t: "cost",
					n: 5
				}],
				directed: !0
			},
			{
				a: "library",
				b: "traveller",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "wounded",
				b: "stairs",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "wounded",
				b: "springS",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "stairs",
				b: "springW",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "stairs",
				b: "lizard",
				doors: [{
					t: "cost",
					n: 8
				}],
				directed: !0
			},
			{
				a: "springW",
				b: "statue",
				doors: [{ t: "free" }],
				directed: !0
			},
			{
				a: "statue",
				b: "merchant",
				doors: [{
					t: "cost",
					n: 10
				}],
				directed: !0
			},
			{
				a: "statue",
				b: "vision",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "lizard",
				b: "vision",
				doors: [{
					t: "cost",
					n: 9
				}],
				directed: !0
			},
			{
				a: "lizard",
				b: "vision",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "merchant",
				b: "chest",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "vision",
				b: "chest",
				doors: [{
					t: "cost",
					n: 10
				}],
				directed: !0
			},
			{
				a: "vision",
				b: "goblin",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "chest",
				b: "boss",
				doors: [{ t: "free" }],
				directed: !0
			},
			{
				a: "goblin",
				b: "boss",
				doors: [{ t: "free" }],
				directed: !0
			},
			{
				a: "springE",
				b: "goblin",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "springE",
				b: "vision",
				doors: [{
					t: "cost",
					n: 9
				}],
				directed: !0
			},
			{
				a: "wall",
				b: "springE",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "wall",
				b: "lizard",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "wall",
				b: "springS",
				doors: [{
					t: "cost",
					n: 10
				}],
				directed: !0
			},
			{
				a: "springS",
				b: "lizard",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "springS",
				b: "jailer",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "cloaked",
				b: "flood",
				doors: [{
					t: "cost",
					n: 5
				}],
				directed: !0
			},
			{
				a: "cloaked",
				b: "stash",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "flood",
				b: "traveller",
				doors: [{
					t: "cost",
					n: 7
				}],
				directed: !0
			},
			{
				a: "flood",
				b: "jailer",
				doors: [{ t: "free" }],
				directed: !0
			},
			{
				a: "traveller",
				b: "springS",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "stash",
				b: "jailer",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "stash",
				b: "jailer",
				doors: [{
					t: "cost",
					n: 6
				}],
				directed: !0
			},
			{
				a: "jailer",
				b: "wall",
				doors: [{
					t: "cost",
					n: 7
				}],
				directed: !0
			}
		]
	},
	m2: {
		id: "m2",
		startRoom: "start",
		bossRoom: "boss",
		hpTrack: w([
			[20, "dim"],
			[12, "dim"],
			[4, "dim"],
			[16, "wound"],
			[8, "wound"],
			[18, "refresh1"],
			[14, "refresh1"],
			[6, "refresh2"],
			[24, "parry"],
			[22, "parry"],
			[10, "parry"],
			[2, "parry"]
		]),
		enemies: {
			0: {
				name: "wolf",
				acts: {
					0: {
						instant: "hidden",
						effs: [{
							k: "attack",
							v: "X"
						}]
					},
					1: { effs: [{
						k: "attack",
						v: "5+2W"
					}] },
					2: { effs: [{
						k: "block",
						v: 5,
						then: [{
							k: "heal",
							v: "X",
							cond: "unhurt"
						}]
					}] },
					3: { effs: [{ k: "exhaustOne" }, {
						k: "attack",
						v: 5
					}] }
				}
			},
			1: {
				name: "bear",
				acts: {
					0: { effs: [{
						k: "attack",
						v: "X"
					}] },
					1: { effs: [{
						k: "attack",
						v: "2X"
					}] },
					2: { effs: [{
						k: "block",
						v: 10,
						then: [{
							k: "attack",
							v: 10
						}]
					}] },
					3: {
						instant: !0,
						effs: [{
							k: "exhaustHighestReady",
							discardIfHidden: !0
						}]
					}
				}
			},
			2: {
				name: "viper",
				acts: {
					0: { effs: [{
						k: "attack",
						v: 6,
						repeatIfWound: !0
					}] },
					1: { effs: [{
						k: "woundPlayer",
						n: 1,
						cond: "hidden"
					}] },
					2: { effs: [{
						k: "destroy",
						v: 1,
						hiddenV: 3
					}] },
					3: {
						instant: !0,
						effs: [{
							k: "destroy",
							v: 1
						}]
					}
				}
			},
			3: {
				name: "willowisp",
				acts: {
					0: { effs: [{
						k: "attack",
						v: 8,
						unblockableIf: "hidden"
					}] },
					1: { effs: [{
						k: "attack",
						v: 6,
						ifUnabsorbed: [{ k: "discardTorch" }]
					}] },
					2: {
						instant: !0,
						effs: [{ k: "dimTorch" }]
					},
					3: { effs: [{
						k: "attack",
						v: "X",
						ifUnabsorbed: [{
							k: "heal",
							v: "unabsorbed"
						}]
					}] }
				}
			}
		},
		rooms: [
			{
				id: "start",
				kind: "start"
			},
			{
				id: "tombA",
				kind: "challenge",
				filter: "any",
				tiers: [
					{
						min: 21,
						rewards: 3
					},
					{
						min: 14,
						rewards: 1
					},
					{
						min: 7,
						wounds: 1
					},
					{
						min: 0,
						wounds: 2
					}
				]
			},
			{
				id: "tombB",
				kind: "challenge",
				filter: "any",
				tiers: [
					{
						min: 18,
						rewards: 2
					},
					{
						min: 11,
						loot: 1
					},
					{
						min: 0,
						wounds: 1
					}
				]
			},
			{
				id: "tombC",
				kind: "challenge",
				filter: "any",
				tiers: [
					{
						min: 15,
						rewards: 1
					},
					{
						min: 9,
						items: 1
					},
					{
						min: 0,
						wounds: 1
					}
				]
			},
			{
				id: "strangerN",
				kind: "stranger",
				rank: "C"
			},
			{
				id: "strangerC",
				kind: "stranger",
				rank: "B"
			},
			{
				id: "strangerS",
				kind: "stranger",
				rank: "A"
			},
			{
				id: "cairnC",
				kind: "cairn",
				suit: 0
			},
			{
				id: "cairnD",
				kind: "cairn",
				suit: 3
			},
			{
				id: "cairnS",
				kind: "cairn",
				suit: 1
			},
			{
				id: "cairnH",
				kind: "cairn",
				suit: 2
			},
			{
				id: "shrineE",
				kind: "shrine"
			},
			{
				id: "shrineW",
				kind: "shrine"
			},
			{
				id: "warrior",
				kind: "keep",
				draw: 3,
				slots: ["equip"]
			},
			{
				id: "witch",
				kind: "keep",
				draw: 2,
				slots: ["item", "item"]
			},
			{
				id: "chest2",
				kind: "keep",
				draw: 3,
				slots: ["loot"]
			},
			{
				id: "sapling",
				kind: "sapling"
			},
			{
				id: "springW",
				kind: "spring"
			},
			{
				id: "springS",
				kind: "spring"
			},
			{
				id: "boss",
				kind: "boss"
			}
		],
		edges: [
			{
				a: "start",
				b: "sapling",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "tombC",
				b: "start",
				doors: [{
					t: "cost",
					n: 3
				}],
				directed: !0
			},
			{
				a: "strangerS",
				b: "start",
				doors: [{
					t: "torch",
					n: 5
				}],
				directed: !0
			},
			{
				a: "strangerS",
				b: "sapling",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "sapling",
				b: "cairnH",
				doors: [{
					t: "cost",
					n: 5
				}],
				directed: !0
			},
			{
				a: "cairnH",
				b: "strangerS",
				doors: [{
					t: "cost",
					n: 6
				}],
				directed: !0
			},
			{
				a: "cairnH",
				b: "chest2",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "chest2",
				b: "shrineW",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "shrineW",
				b: "tombB",
				doors: [{
					t: "cost",
					n: 8
				}],
				directed: !0
			},
			{
				a: "tombB",
				b: "springW",
				doors: [{
					t: "torch",
					n: 10
				}],
				directed: !0
			},
			{
				a: "tombB",
				b: "cairnD",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "cairnD",
				b: "springW",
				doors: [{
					t: "torch",
					n: 10
				}, {
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "springW",
				b: "tombA",
				doors: [{
					t: "cost",
					n: 11
				}],
				directed: !0
			},
			{
				a: "tombA",
				b: "strangerN",
				doors: [{
					t: "cost",
					n: 11
				}],
				directed: !0
			},
			{
				a: "tombA",
				b: "boss",
				doors: [{ t: "free" }],
				directed: !0
			},
			{
				a: "boss",
				b: "cairnC",
				doors: [{ t: "free" }],
				directed: !0
			},
			{
				a: "springW",
				b: "strangerN",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "strangerN",
				b: "cairnC",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "strangerN",
				b: "shrineE",
				doors: [{
					t: "cost",
					n: 10
				}],
				directed: !0
			},
			{
				a: "cairnC",
				b: "shrineE",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "cairnC",
				b: "warrior",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "warrior",
				b: "shrineE",
				doors: [{
					t: "torch",
					n: 10
				}],
				directed: !0
			},
			{
				a: "warrior",
				b: "witch",
				doors: [{
					t: "cost",
					n: 10
				}],
				directed: !0
			},
			{
				a: "witch",
				b: "cairnS",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "witch",
				b: "springS",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "springS",
				b: "cairnS",
				doors: [{
					t: "torch",
					n: 7
				}],
				directed: !0
			},
			{
				a: "strangerC",
				b: "springS",
				doors: [{
					t: "cost",
					n: 8
				}],
				directed: !0
			},
			{
				a: "springS",
				b: "strangerS",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "strangerS",
				b: "cairnS",
				doors: [{
					t: "cost",
					n: 7
				}],
				directed: !0
			},
			{
				a: "cairnS",
				b: "tombC",
				doors: [{
					t: "enemy",
					rank: "A"
				}],
				directed: !0
			},
			{
				a: "strangerS",
				b: "tombC",
				doors: [{
					t: "cost",
					n: 5
				}],
				directed: !0
			},
			{
				a: "shrineE",
				b: "strangerC",
				doors: [{
					t: "torch",
					n: 10
				}],
				directed: !0
			},
			{
				a: "cairnD",
				b: "shrineE",
				doors: [{
					t: "torch",
					n: 10
				}],
				directed: !0
			},
			{
				a: "cairnD",
				b: "strangerC",
				doors: [{
					t: "torch",
					n: 10
				}],
				directed: !0
			},
			{
				a: "shrineW",
				b: "cairnD",
				doors: [{
					t: "enemy",
					rank: "B"
				}],
				directed: !0
			},
			{
				a: "strangerC",
				b: "shrineW",
				doors: [{
					t: "torch",
					n: 9
				}],
				directed: !0
			},
			{
				a: "shrineW",
				b: "springS",
				doors: [{
					t: "torch",
					n: 8
				}],
				directed: !0
			},
			{
				a: "chest2",
				b: "strangerS",
				doors: [{
					t: "torch",
					n: 6
				}],
				directed: !0
			},
			{
				a: "shrineE",
				b: "witch",
				doors: [{
					t: "torch",
					n: 10
				}],
				directed: !0
			}
		]
	},
	m3: {
		id: "m3",
		startRoom: "start",
		bossRoom: "boss",
		hpTrack: w([
			[24, "parry"],
			[22, "clockUp"],
			[20, "wound"],
			[18, "refresh1"],
			[16, "clockDown"],
			[14, "refresh1"],
			[12, "clockUp"],
			[10, "parry"],
			[8, "clockUp"],
			[5, "wound"],
			[4, "refresh2"]
		]),
		enemies: {
			0: {
				name: "gnome",
				acts: {
					0: { effs: [{
						k: "attack",
						v: "X"
					}, {
						k: "windup",
						cond: "xLt8"
					}] },
					1: { effs: [{
						k: "block",
						v: "X"
					}, {
						k: "windup",
						cond: "xLt8"
					}] },
					2: { effs: [{ k: "drawWindup" }] },
					3: {
						instant: !0,
						effs: [{
							k: "windup",
							then: [{
								k: "attack",
								v: "windupSum"
							}]
						}]
					}
				}
			},
			1: {
				name: "golem",
				acts: {
					0: { effs: [{
						k: "attack",
						v: "X"
					}, {
						k: "windup",
						cond: "unhurt"
					}] },
					1: { effs: [{
						k: "attack",
						v: "2X"
					}] },
					2: { effs: [{
						k: "windup",
						then: [{
							k: "exhaustAllLt",
							n: "windupSum"
						}]
					}] },
					3: {
						instant: !0,
						effs: [{ k: "exhaustHighestReady" }, {
							k: "attack",
							v: 8
						}]
					}
				}
			},
			2: {
				name: "knight",
				acts: {
					0: { effs: [{
						k: "attack",
						v: "X"
					}] },
					1: { effs: [{
						k: "block",
						v: "X"
					}, {
						k: "windup",
						cond: "unhurt"
					}] },
					2: { effs: [{
						k: "windup",
						then: [{
							k: "destroy",
							v: "windupCount"
						}]
					}] },
					3: { effs: [{
						k: "windup",
						then: [{
							k: "heal",
							v: "windupSum"
						}]
					}] }
				}
			},
			3: {
				name: "bellringer",
				acts: {
					0: { effs: [{
						k: "attack",
						v: "X"
					}, {
						k: "clock",
						n: 1,
						cond: "unhurt"
					}] },
					1: { effs: [{
						k: "attack",
						v: "clock"
					}] },
					2: {
						instant: !0,
						effs: [{
							k: "clock",
							n: 1,
							cond: "clockLtX"
						}]
					},
					3: { effs: [{
						k: "heal",
						v: "clock"
					}] }
				}
			}
		},
		rooms: [
			{
				id: "start",
				kind: "start"
			},
			{
				id: "gearC",
				kind: "gear",
				suit: 0
			},
			{
				id: "gearD",
				kind: "gear",
				suit: 3
			},
			{
				id: "gearH",
				kind: "gear",
				suit: 2
			},
			{
				id: "gearS",
				kind: "gear",
				suit: 1
			},
			{
				id: "rats",
				kind: "discardClock",
				pool: "item",
				clockDelta: -3
			},
			{
				id: "pendTL",
				kind: "pendulum",
				tiers: [
					{
						min: 15,
						wounds: 2
					},
					{
						min: 8,
						rewards: 1
					},
					{
						min: 0,
						rewards: 3
					}
				]
			},
			{
				id: "pendML",
				kind: "pendulum",
				tiers: [
					{
						min: 23,
						wounds: 1
					},
					{
						min: 16,
						loot: 1
					},
					{
						min: 0,
						rewards: 1
					}
				]
			},
			{
				id: "pendMR",
				kind: "pendulum",
				tiers: [
					{
						min: 19,
						wounds: 1
					},
					{
						min: 12,
						items: 1
					},
					{
						min: 0,
						rewards: 2
					}
				]
			},
			{
				id: "scrap",
				kind: "keep",
				draw: 3,
				slots: ["equip"]
			},
			{
				id: "escapement",
				kind: "discardClock",
				pool: "equip",
				clockDelta: -3
			},
			{
				id: "collector",
				kind: "collector"
			},
			{
				id: "bigHand",
				kind: "enemy",
				rank: "C",
				clockOnWin: -3
			},
			{
				id: "smallHand",
				kind: "enemy",
				rank: "B",
				clockOnWin: -2
			},
			{
				id: "magic",
				kind: "discardClock",
				pool: "any",
				clockDelta: -2
			},
			{
				id: "note",
				kind: "keep",
				draw: 3,
				slots: ["item"]
			},
			{
				id: "springL",
				kind: "spring"
			},
			{
				id: "springR",
				kind: "spring"
			},
			{
				id: "boss",
				kind: "boss"
			}
		],
		edges: [
			{
				a: "gearC",
				b: "rats",
				doors: [{
					t: "enemy",
					rank: "A"
				}]
			},
			{
				a: "rats",
				b: "gearD",
				doors: [{ t: "twist" }]
			},
			{
				a: "gearC",
				b: "pendTL",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "gearC",
				b: "springL",
				doors: [{ t: "free" }]
			},
			{
				a: "gearD",
				b: "scrap",
				doors: [{ t: "twist" }]
			},
			{
				a: "springL",
				b: "pendTL",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "springL",
				b: "pendML",
				doors: [{ t: "twist" }]
			},
			{
				a: "pendTL",
				b: "scrap",
				doors: [{ t: "twist" }]
			},
			{
				a: "pendTL",
				b: "boss",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "scrap",
				b: "gearD",
				doors: [{
					t: "enemy",
					rank: "A"
				}]
			},
			{
				a: "scrap",
				b: "springR",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "springR",
				b: "bigHand",
				doors: [{ t: "twist" }]
			},
			{
				a: "pendML",
				b: "escapement",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "springL",
				b: "gearH",
				doors: [{ t: "twist" }, {
					t: "enemy",
					rank: "A"
				}]
			},
			{
				a: "escapement",
				b: "collector",
				doors: [{ t: "twist" }]
			},
			{
				a: "boss",
				b: "collector",
				doors: [{ t: "twist" }]
			},
			{
				a: "collector",
				b: "bigHand",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "escapement",
				b: "gearH",
				doors: [{ t: "twist" }]
			},
			{
				a: "bigHand",
				b: "gearS",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "bigHand",
				b: "gearS",
				doors: [{ t: "twist" }, {
					t: "enemy",
					rank: "A"
				}]
			},
			{
				a: "pendMR",
				b: "gearS",
				doors: [{ t: "twist" }]
			},
			{
				a: "gearH",
				b: "pendMR",
				doors: [{
					t: "enemy",
					rank: "A"
				}]
			},
			{
				a: "gearH",
				b: "smallHand",
				doors: [{ t: "twist" }]
			},
			{
				a: "gearH",
				b: "magic",
				doors: [{ t: "twist" }]
			},
			{
				a: "smallHand",
				b: "gearS",
				doors: [{
					t: "enemy",
					rank: "A"
				}]
			},
			{
				a: "smallHand",
				b: "start",
				doors: [{ t: "twist" }, {
					t: "enemy",
					rank: "A"
				}]
			},
			{
				a: "gearS",
				b: "note",
				doors: [{
					t: "enemy",
					rank: "A"
				}]
			},
			{
				a: "gearS",
				b: "start",
				doors: [{ t: "twist" }]
			},
			{
				a: "magic",
				b: "start",
				doors: [{
					t: "enemy",
					rank: "A"
				}]
			}
		]
	},
	m4: {
		id: "m4",
		startRoom: "start",
		bossRoom: "boss",
		hpTrack: w([
			[23, "refresh1"],
			[20, "wound"],
			[18, "parry"],
			[15, "flood"],
			[13, "refresh1"],
			[10, "parry"],
			[8, "wound"],
			[5, "refresh2"],
			[2, "wound"]
		]),
		enemies: {
			0: {
				name: "gargoyle",
				acts: {
					0: { effs: [{
						k: "attack",
						v: "X",
						floodedAdd: 5
					}] },
					1: { effs: [{
						k: "block",
						v: "X",
						floodedAdd: 5
					}] },
					2: {
						instant: !0,
						effs: [{
							k: "destroy",
							v: 1,
							floodedAdd: 1
						}]
					},
					3: { effs: [{
						k: "heal",
						v: "X",
						floodedAdd: 5
					}] }
				}
			},
			1: {
				name: "monk",
				acts: {
					0: {
						instant: "flooded",
						effs: [{
							k: "attack",
							v: 10
						}]
					},
					1: {
						instant: "flooded",
						effs: [{ k: "exhaustHighestReady" }]
					},
					2: {
						instant: "flooded",
						effs: [{
							k: "destroy",
							v: 1
						}]
					},
					3: {
						instant: "flooded",
						effs: [{
							k: "heal",
							v: "X"
						}]
					}
				}
			},
			2: {
				name: "angel",
				acts: {
					0: { effs: [{
						k: "attack",
						v: "X+3C"
					}] },
					1: { effs: [{
						k: "block",
						v: "X+3C"
					}] },
					2: { effs: [{
						k: "destroy",
						v: "candles"
					}] },
					3: {
						instant: !0,
						effs: [{ k: "extinguishHighestCandle" }]
					}
				}
			},
			3: {
				name: "nixie",
				acts: {
					0: { effs: [{
						k: "attack",
						v: "3+F"
					}] },
					1: { effs: [{
						k: "block",
						v: "3+F"
					}] },
					2: { effs: [{
						k: "block",
						v: "X",
						then: [{
							k: "flood",
							cond: "unhurt"
						}]
					}] },
					3: {
						instant: !0,
						effs: [{
							k: "heal",
							v: "F"
						}]
					}
				}
			}
		},
		rooms: [
			{
				id: "start",
				kind: "start"
			},
			{
				id: "boss",
				kind: "boss"
			},
			{
				id: "apse",
				kind: "pickTake",
				draw: 5,
				take: 2,
				mode: "lowest",
				floodedMode: "highest",
				to: "reward"
			},
			{
				id: "choirBB",
				kind: "choir"
			},
			{
				id: "choirAA",
				kind: "choir"
			},
			{
				id: "chapelH",
				kind: "chapel",
				suit: 2
			},
			{
				id: "chapelS",
				kind: "chapel",
				suit: 1
			},
			{
				id: "chapelD",
				kind: "chapel",
				suit: 3
			},
			{
				id: "chapelC",
				kind: "chapel",
				suit: 0
			},
			{
				id: "spring",
				kind: "spring"
			},
			{
				id: "grin",
				kind: "enemy",
				rank: "C",
				shuffleOnWin: [4, 8]
			},
			{
				id: "roar",
				kind: "enemy",
				rank: "B",
				shuffleOnWin: [2, 4]
			},
			{
				id: "cloister",
				kind: "cloister"
			},
			{
				id: "transeptW",
				kind: "transept",
				refresh: [1, 2]
			},
			{
				id: "transeptE",
				kind: "transept",
				refresh: [1, 2]
			},
			{
				id: "nave",
				kind: "pickTake",
				draw: 3,
				take: 1,
				mode: "lowest",
				floodedMode: "highest",
				to: "loot"
			},
			{
				id: "hall",
				kind: "pickTake",
				draw: 3,
				take: 1,
				mode: "lowest",
				floodedMode: "highest",
				to: "equip"
			}
		],
		edges: [
			{
				a: "start",
				b: "hall",
				doors: [{
					t: "enemy",
					rank: "A"
				}]
			},
			{
				a: "start",
				b: "nave",
				doors: [{
					t: "enemy",
					rank: "A"
				}]
			},
			{
				a: "start",
				b: "chapelC",
				doors: [{
					t: "cost",
					n: 2
				}]
			},
			{
				a: "hall",
				b: "transeptW",
				doors: [
					{
						t: "enemy",
						rank: "A"
					},
					{
						t: "enemy",
						rank: "B"
					},
					{
						t: "cost",
						n: 3
					}
				]
			},
			{
				a: "transeptW",
				b: "chapelD",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "transeptW",
				b: "transeptE",
				doors: [{
					t: "cost",
					n: 6
				}]
			},
			{
				a: "transeptW",
				b: "roar",
				doors: [{
					t: "cost",
					n: 5
				}]
			},
			{
				a: "roar",
				b: "nave",
				doors: [{
					t: "enemy",
					rank: "A"
				}]
			},
			{
				a: "transeptE",
				b: "nave",
				doors: [{
					t: "cost",
					n: 5
				}]
			},
			{
				a: "nave",
				b: "chapelC",
				doors: [{
					t: "enemy",
					rank: "A"
				}]
			},
			{
				a: "chapelC",
				b: "choirAA",
				doors: [{
					t: "cost",
					n: 12
				}]
			},
			{
				a: "transeptE",
				b: "choirAA",
				doors: [{
					t: "cost",
					n: 7
				}]
			},
			{
				a: "transeptE",
				b: "chapelS",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "choirAA",
				b: "chapelS",
				doors: [{
					t: "cost",
					n: 8
				}]
			},
			{
				a: "choirAA",
				b: "grin",
				doors: [{
					t: "enemy",
					rank: "C"
				}]
			},
			{
				a: "chapelS",
				b: "grin",
				doors: [{ t: "free" }]
			},
			{
				a: "chapelS",
				b: "cloister",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "cloister",
				b: "spring",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "cloister",
				b: "chapelD",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "chapelD",
				b: "apse",
				doors: [{
					t: "cost",
					n: 24
				}]
			},
			{
				a: "spring",
				b: "apse",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "spring",
				b: "choirBB",
				doors: [{
					t: "cost",
					n: 10
				}]
			},
			{
				a: "apse",
				b: "choirBB",
				doors: [{
					t: "cost",
					n: 12
				}]
			},
			{
				a: "choirBB",
				b: "chapelH",
				doors: [{
					t: "cost",
					n: 12
				}]
			},
			{
				a: "chapelH",
				b: "grin",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			},
			{
				a: "chapelH",
				b: "boss",
				doors: [{
					t: "cost",
					n: 13
				}]
			},
			{
				a: "apse",
				b: "boss",
				doors: [{
					t: "enemy",
					rank: "B"
				}]
			}
		]
	}
}, E = {
	start: null,
	boss: "all",
	apse: 3,
	choirBB: 0,
	choirAA: 0,
	nave: 0,
	cloister: 0,
	chapelC: 3,
	transeptW: 3,
	spring: 3,
	chapelH: 2,
	transeptE: 2,
	hall: 2,
	grin: 1,
	chapelS: 1,
	roar: 1,
	chapelD: 1
}, D = {
	barbarian: {
		id: "barbarian",
		wounds: 25
	},
	seer: {
		id: "seer",
		wounds: 20
	},
	fallen: {
		id: "fallen",
		wounds: 35,
		itemOverride: 2
	},
	druid: {
		id: "druid",
		wounds: 25
	},
	hunter: {
		id: "hunter",
		wounds: 25,
		itemOverride: 1
	},
	tinkerer: {
		id: "tinkerer",
		wounds: 20,
		itemOverride: 0
	},
	alchemist: {
		id: "alchemist",
		wounds: 20
	},
	rogue: {
		id: "rogue",
		wounds: 25,
		itemOverride: 1
	}
}, O = Object.keys(D), k = [
	"m1",
	"m2",
	"m3",
	"m4"
], te = {
	id: "realms52",
	tier: "beta",
	mechanics: ["hand-management"],
	interactionTags: [],
	nameKey: "games.realms52.name",
	descKey: "games.realms52.desc",
	rulesKey: "games.realms52.rules",
	icon: "🗡️",
	iconImg: "games/realms52.webp",
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#b8860b",
	releasedAt: "2026-10-02",
	search: {
		py: "wu shi er ge wang guo mao xian",
		init: "wsegwgmx"
	},
	hotseat: "off"
}, A = t.number().int().min(0).max(51), j = t.union([
	t.literal(0),
	t.literal(1),
	t.literal(2),
	t.literal(3)
]), M = t.enum([
	"m1",
	"m2",
	"m3",
	"m4"
]), N = t.enum([
	"barbarian",
	"seer",
	"fallen",
	"druid",
	"hunter",
	"tinkerer",
	"alchemist",
	"rogue"
]), P = t.object({
	map: M.catch("m1"),
	char: N.catch("barbarian")
}).default({
	map: "m1",
	char: "barbarian"
}), F = t.discriminatedUnion("t", [
	t.object({
		t: t.literal("move"),
		to: t.string(),
		pay: t.array(t.array(A)).optional(),
		focus: t.tuple([A, t.union([t.literal(-1), t.literal(1)])]).optional(),
		via: t.number().int().min(0).optional()
	}),
	t.object({ t: t.literal("stay") }),
	t.object({ t: t.literal("reveal") }),
	t.object({
		t: t.literal("attack"),
		equip: A,
		extras: t.array(A).optional(),
		bloodRage: A.optional(),
		focus: t.tuple([A, t.union([t.literal(-1), t.literal(1)])]).optional()
	}),
	t.object({
		t: t.literal("defend"),
		equips: t.array(A),
		focus: t.tuple([A, t.union([t.literal(-1), t.literal(1)])]).optional()
	}),
	t.object({ t: t.literal("rest") }),
	t.object({
		t: t.literal("useItem"),
		card: A,
		params: t.object({
			equip: A.optional(),
			rank: t.number().int().min(1).max(13).optional(),
			suit: j.optional(),
			wound: A.optional(),
			ready: A.optional(),
			exhausted: A.optional()
		}).optional()
	}),
	t.object({
		t: t.literal("brew"),
		mix: t.array(A).min(1).max(3),
		dilute: A.optional(),
		fieldNotes: A.optional(),
		keep: A.optional()
	}),
	t.object({
		t: t.literal("ability"),
		id: t.enum([
			"shapeshift",
			"throwAxe",
			"scavenge",
			"bladeReady"
		]),
		card: A.optional()
	}),
	t.object({
		t: t.literal("choose"),
		option: t.number().int().min(0)
	}),
	t.object({
		t: t.literal("pick"),
		cards: t.array(A),
		pool: t.enum(["equip", "loot"]).optional()
	}),
	t.object({
		t: t.literal("challenge"),
		equips: t.array(A),
		focus: t.tuple([A, t.union([t.literal(-1), t.literal(1)])]).optional()
	}),
	t.object({
		t: t.literal("setTorch"),
		card: A
	})
]), I = t.object({
	t: t.enum([
		"cost",
		"enemy",
		"torch",
		"twist",
		"free"
	]),
	n: t.number().optional(),
	rank: t.enum([
		"A",
		"B",
		"C"
	]).optional()
}), L = t.object({ kind: t.string() }).loose(), ne = t.object({
	enemySuit: j,
	rank: t.enum([
		"A",
		"B",
		"C"
	]),
	x: t.number(),
	hp: t.number(),
	maxHp: t.number(),
	reward: A.nullable(),
	extraRewards: t.array(A),
	battleCard: A.nullable(),
	defended: t.number(),
	blocked: t.number(),
	hurt: t.boolean(),
	acted: t.boolean(),
	parried: t.boolean(),
	rounds: t.number(),
	hidden: t.boolean(),
	boss: t.boolean(),
	windup: t.array(A),
	battleLog: t.array(A),
	used: t.array(t.string())
}).loose(), re = t.object({
	mapId: M,
	char: N,
	room: t.string(),
	phase: t.enum([
		"play",
		"won",
		"lost"
	]),
	loseReason: t.string().nullable(),
	deckCount: t.number(),
	discardCount: t.number(),
	equipment: t.array(t.object({
		card: A,
		bonus: t.number().nullable(),
		exhausted: t.boolean(),
		ovrRank: t.number().nullable(),
		ovrSuit: j.nullable()
	})),
	items: t.array(A),
	loot: t.array(A),
	wounds: t.array(A),
	woundsExhausted: t.array(A),
	torch: t.object({
		card: A,
		dimmed: t.boolean()
	}).nullable(),
	bounty: t.array(A),
	clock: t.number(),
	flooded: t.array(t.string()),
	floodCount: t.record(t.string(), t.number()),
	candles: t.array(t.string()),
	form: j.nullable(),
	collection: t.array(A),
	combat: ne.nullable(),
	pending: L.nullable(),
	flags: t.record(t.string(), t.boolean()),
	moves: t.array(t.object({
		to: t.string(),
		doors: t.array(I),
		floodedPath: t.boolean()
	})),
	score: t.object({
		items: t.number(),
		loot: t.number(),
		bounty: t.number(),
		candles: t.number(),
		total: t.number()
	}).nullable(),
	log: t.array(t.object({
		k: t.string(),
		p: t.record(t.string(), t.union([t.string(), t.number()])).optional()
	}))
}), ie = t.object({}), R = (e) => ({ code: e }), z = (e) => `games.realms52.${e}`, B = (e) => T[e.mapId], V = (e, t) => B(e).rooms.find((e) => e.id === t), H = (e) => e.ovrRank ?? x(e.card) + (e.bonus ?? 0), U = (e) => e.ovrSuit ?? S(e.card), ae = (e) => [...e.wounds, ...e.woundsExhausted].reduce((e, t) => e + x(t), 0), oe = (e) => e.torch && !e.torch.dimmed ? x(e.torch.card) : 0, W = (e, t) => e.flooded.includes(t);
function se(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function G(e, t, n) {
	e.log.push({
		k: t,
		p: n
	}), e.log.length > 40 && e.log.shift();
}
function ce(e, t) {
	e.phase === "play" && (e.phase = "lost", e.loseReason = t, e.combat = null, e.pending = null, e.queue = null, G(e, z("log.lose"), { reason: t }));
}
function le(e) {
	return e.phase !== "play" || ae(e) >= D[e.char].wounds && (ce(e, "wounds"), !0);
}
function K(e, t, n, r) {
	if (e.mapId !== "m3" || n === 0) return !1;
	let i = e.clock + n;
	return i > 12 ? (e.clock = 12, q(e, t, {
		t: "woundDirect",
		then: r
	}), !0) : (e.clock = Math.max(1, i), !1);
}
function ue(e, t, n, r, i = []) {
	for (; i.length < n;) {
		let t = e.deck.pop();
		if (t === void 0) {
			ce(e, "deck");
			return;
		}
		if (x(t) === 1) {
			e.discard.push(t), G(e, z("log.curse"), { suit: "♣♠♥♦"[S(t)] }), e.pending = {
				kind: "curse",
				suit: S(t),
				after: {
					drawn: i,
					need: n,
					use: r
				}
			};
			return;
		}
		i.push(t);
	}
	de(e, t, i, r);
}
function de(e, t, n, r) {
	if (r.t !== "battle" && r.t !== "windupDraw" && e.char !== "alchemist" && e.items.some((e) => S(e) === 3)) {
		e.pending = {
			kind: "confirmDraw",
			cards: n,
			use: r
		};
		return;
	}
	_e(e, t, n, r);
}
function q(e, t, n, r = 1) {
	ue(e, t, r, n);
}
function J(e, t) {
	let n = e.combat;
	switch (t) {
		case "X": return n ? n.bossKind === "clockmaker" ? n.x + e.clock : n.x : 0;
		case "2X": return J(e, "X") * 2;
		case "X+5": return J(e, "X") + 5;
		case "clock": return e.clock;
		case "windupSum": return n ? n.windup.reduce((e, t) => e + x(t), 0) : 0;
		case "windupCount": return n ? n.windup.length : 0;
		case "woundCount": return e.wounds.length + e.woundsExhausted.length;
		case "candles": return e.candles.length;
		case "unabsorbed": return n?.unabsorbed ?? 0;
		case "5+2W": return 5 + 2 * (e.wounds.length + e.woundsExhausted.length);
		case "X+3C": return J(e, "X") + 3 * e.candles.length;
		case "3+F": return 3 + e.flooded.length;
		case "F": return e.flooded.length;
		default: return t;
	}
}
function fe(e, t) {
	if (!t) return !0;
	let n = e.combat;
	switch (t) {
		case "hidden": return !!n?.hidden;
		case "unhurt": return !!n && !n.hurt;
		case "flooded": return W(e, e.room);
		case "xLt8": return !!n && n.x < 8;
		case "clockLtX": return !!n && e.clock < n.x;
		case "dealt": return !!n?.dealt;
	}
}
function pe(e, t, n) {
	if (e.char === "druid" && e.form !== null && (e.form = null), e.char === "fallen") for (let t of e.equipment) t.exhausted = !1;
	if (!le(e)) {
		if (e.char === "hunter" && e.equipment.some((e) => e.exhausted)) {
			e.pending = {
				kind: "pickRefresh",
				n: 1,
				resume: n
			};
			return;
		}
		X(e, t, n);
	}
}
function Y(e, t, n) {
	q(e, t, {
		t: "woundDirect",
		then: n
	});
}
function X(e, t, n) {
	if (e.phase === "play") switch (n.t) {
		case "none": return;
		case "room": return Z(e, t);
		case "resolveRoom": return De(e, t);
		case "move":
			Te(e, t, n.to, n.doors, n.doorIdx, n.pay, n.focus);
			return;
		case "drawBattle": return Me(e, t);
		case "enemyPhase": return Ie(e, t, n.effs, n.resume);
		case "roundEnd": return Ve(e);
		case "afterAttack": return Be(e, t);
		case "afterDmg": return Re(e, t, n.eff, n.absorbed, n.resume);
		case "repeatAttack": return Le(e, t, {
			...n.eff,
			repeatIfWound: void 0
		}, n.resume);
		case "win": return He(e, t, n.step);
		case "bossWin":
			e.phase = "won", G(e, z("log.win"));
			return;
		case "queue": return me(e, t);
		case "chain":
			e.pending = n.p;
			return;
		case "rewards":
			if (n.queue.length === 0) return X(e, t, n.resume);
			e.pending = {
				kind: "reward",
				card: n.queue[0],
				queue: n.queue.slice(1),
				resume: n.resume
			};
			return;
		case "placeNext":
			if (n.cards.length === 0) return X(e, t, n.resume);
			ge(e, t, n.cards[0], n.slot, {
				t: "placeNext",
				cards: n.cards.slice(1),
				slot: n.slot,
				resume: n.resume
			});
			return;
		case "curseAfter": return at(e, t, n.after);
		case "transeptMove": return e.deferFlood = !0, Z(e, t);
		case "choir2": return ke(e, t, n.room, { t: "room" });
	}
}
function me(e, t) {
	let n = e.queue;
	if (!n || n.jobs.length === 0) {
		let r = n?.resume ?? { t: "room" };
		e.queue = null, X(e, t, r);
		return;
	}
	let r = n.jobs.shift(), i = { t: "queue" };
	switch (r.t) {
		case "wound": return Y(e, t, i);
		case "loot": return q(e, t, {
			t: "gain",
			slot: "loot",
			then: i
		});
		case "item": return q(e, t, {
			t: "gain",
			slot: "item",
			then: i
		});
		case "equip": return q(e, t, {
			t: "gain",
			slot: "equip",
			then: i
		});
		case "reward": return q(e, t, {
			t: "reward",
			queue: [],
			resume: i
		});
		case "shuffleDiscard": {
			let n = e.discard.splice(-r.n);
			return e.deck = se(e, [...e.deck, ...n]), me(e, t);
		}
		case "clock": return K(e, t, r.n, i) ? void 0 : me(e, t);
	}
}
function he(e, t, n, r) {
	e.queue = {
		jobs: n,
		resume: r
	}, me(e, t);
}
function ge(e, t, n, r, i) {
	if (r === "item") {
		e.items.push(n), X(e, t, i);
		return;
	}
	if (r === "torch") {
		e.torch && e.discard.push(e.torch.card), e.torch = {
			card: n,
			dimmed: !1
		}, X(e, t, i);
		return;
	}
	if (r === "loot") {
		if (e.char === "druid" && e.form === 0) {
			q(e, t, {
				t: "mole",
				orig: n,
				then: i
			});
			return;
		}
		e.loot.push(n), X(e, t, i);
		return;
	}
	if (e.equipment.push({
		card: n,
		bonus: null,
		exhausted: !1,
		ovrRank: null,
		ovrSuit: null
	}), e.char === "tinkerer" && x(n) <= 7 && e.equipment.some((e) => e.card !== n && e.bonus === null)) {
		e.pending = {
			kind: "fuse",
			card: n,
			resume: i
		};
		return;
	}
	X(e, t, i);
}
function _e(e, t, n, r) {
	let i = r.then ?? { t: "none" };
	switch (r.t) {
		case "event": return ve(e, t, n[0], r.room, i);
		case "wound": {
			let a = n[0];
			x(a) <= r.damage ? (e.wounds.push(a), pe(e, t, i)) : (e.discard.push(a), X(e, t, i));
			return;
		}
		case "woundDirect":
			e.wounds.push(n[0]), pe(e, t, i);
			return;
		case "encounter": return je(e, t, n, r);
		case "flood": return xe(e, t, n[0], i);
		case "twist":
			e.pending = {
				kind: "twist",
				card: n[0],
				cost: x(n[0]),
				costSuit: S(n[0]),
				to: r.to,
				doors: r.doors,
				doorIdx: r.doorIdx,
				pay: r.pay,
				focus: r.focus
			};
			return;
		case "table": return ye(e, t, n[0], r.room, i);
		case "reward":
			e.pending = {
				kind: "reward",
				card: n[0],
				queue: r.queue,
				resume: r.resume
			};
			return;
		case "gain": return ge(e, t, n[0], r.slot, i);
		case "keep":
			e.pending = {
				kind: "keep",
				cards: n,
				slots: r.slots,
				step: 0,
				resume: r.resume
			};
			return;
		case "pickTake": {
			let i = [...n].sort((e, t) => C(e, t) ? -1 : 1), a = r.mode === "lowest" ? i.slice(-r.take) : i.slice(0, r.take), o = n.filter((e) => !a.includes(e));
			e.deck.unshift(...o), r.to === "reward" ? X(e, t, {
				t: "rewards",
				queue: a,
				resume: r.resume
			}) : X(e, t, {
				t: "placeNext",
				cards: a,
				slot: r.to,
				resume: r.resume
			});
			return;
		}
		case "battle": return Pe(e, t, n[0]);
		case "windupDraw":
			e.combat?.windup.push(n[0]), X(e, t, i);
			return;
		case "extraReward":
			e.combat?.extraRewards.push(n[0]), X(e, t, i);
			return;
		case "mole":
			e.pending = {
				kind: "molePick",
				cards: [r.orig, n[0]],
				resume: i
			};
			return;
	}
}
function ve(e, t, n, r, i) {
	let a = V(e, r);
	if (a.kind !== "event") return;
	let o = a.table[S(n)];
	if (o === "enemyA") {
		Ae(e, "A", {
			after: i,
			enemyCard: n,
			noReward: !0,
			room: r
		});
		return;
	}
	e.discard.push(n);
	let s = [];
	switch (o) {
		case "item":
			s.push({ t: "item" });
			break;
		case "equip":
			s.push({ t: "equip" });
			break;
		case "loot":
			s.push({ t: "loot" });
			break;
		case "loot2":
			s.push({ t: "loot" }, { t: "loot" });
			break;
		case "wound":
			s.push({ t: "wound" });
			break;
		case "wound2": s.push({ t: "wound" }, { t: "wound" });
	}
	he(e, t, s, i);
}
function ye(e, t, n, r, i) {
	let a = V(e, r), o = (e.mapId === "m2" ? oe(e) : e.clock) + x(n);
	e.discard.push(n), be(e, t, (a.kind === "challenge" || a.kind === "pendulum" ? a.tiers : []).find((e) => o >= e.min) ?? { min: 0 }, i);
}
function be(e, t, n, r) {
	let i = [];
	for (let e = 0; e < (n.wounds ?? 0); e++) i.push({ t: "wound" });
	for (let e = 0; e < (n.rewards ?? 0); e++) i.push({ t: "reward" });
	for (let e = 0; e < (n.loot ?? 0); e++) i.push({ t: "loot" });
	for (let e = 0; e < (n.items ?? 0); e++) i.push({ t: "item" });
	he(e, t, i, r);
}
function xe(e, t, n, r) {
	let i = B(e), a = S(n);
	if (e.deck.unshift(n), !i.rooms.some((t) => t.kind === "chapel" && t.suit === a && e.candles.includes(t.id))) {
		let t = Se(e), n = null;
		for (let r of i.edges) for (let [i, o] of [[r.a, r.b], [r.b, r.a]]) {
			if (!e.flooded.includes(i) || e.flooded.includes(o)) continue;
			let r = E[o];
			(r === "all" || r === a) && (n === null || (t.get(o) ?? 99) < (t.get(n) ?? 99)) && (n = o);
		}
		n && (n === i.bossRoom && (e.floodCount[n] = (e.floodCount[n] ?? 0) + 1), e.flooded.includes(n) || e.flooded.push(n), G(e, z("log.flood"), { room: n }));
	}
	X(e, t, r);
}
function Se(e) {
	let t = B(e), n = /* @__PURE__ */ new Map([[t.startRoom, 0]]), r = [t.startRoom];
	for (; r.length;) {
		let e = r.shift();
		for (let i of t.edges) {
			let t = i.a === e ? i.b : i.b === e ? i.a : null;
			t && !n.has(t) && (n.set(t, n.get(e) + 1), r.push(t));
		}
	}
	return n;
}
function Z(e, t) {
	if (e.phase === "play" && (e.poison = null, e.flags.bladeReady = !1, e.mapId === "m4")) {
		if (e.deferFlood) {
			e.deferFlood = !1;
			return;
		}
		if (W(e, e.room)) {
			let t = e.deck.pop();
			t !== void 0 && e.discard.push(t);
		}
		q(e, t, {
			t: "flood",
			then: { t: "none" }
		});
	}
}
function Ce(e, t) {
	let n = [];
	for (let r of B(e).edges) r.a === t ? n.push({
		to: r.b,
		doors: r.doors
	}) : r.b === t && !r.directed && n.push({
		to: r.a,
		doors: r.doors
	});
	return n;
}
function we(e, t, n, r, i, a) {
	if (e.combat || e.pending || e.queue) return R(z("errBusy"));
	let o = Ce(e, e.room).filter((e) => e.to === n), s = a === void 0 ? o[0] : o[a];
	return s ? Te(e, t, n, s.doors, 0, r, i) : R(z("errNoPath"));
}
function Te(e, t, n, r, i, a, o) {
	let s = e.mapId === "m4" && W(e, e.room) && W(e, n), c = e.moveFree || s, l = r.slice(0, i).filter((e) => e.t === "cost").length;
	for (let s = i; s < r.length; s++) {
		let i = r[s];
		if (!(c || i.t === "free") && (i.t !== "cost" || e.form !== 3)) {
			if (i.t === "torch") {
				if (oe(e) >= i.n) continue;
				return R(z("errTorch"));
			}
			if (i.t === "cost") {
				let t = a[l++] ?? [], n = Ee(e, t, i.n, o);
				if (n) return n;
				for (let n of t) e.equipment.find((e) => e.card === n).exhausted = !0;
				continue;
			}
			if (i.t === "twist") {
				if (e.form === 3) continue;
				return q(e, t, {
					t: "twist",
					to: n,
					doors: r,
					doorIdx: s,
					pay: a,
					focus: o
				}), null;
			}
			if (i.t === "enemy") return q(e, t, {
				t: "encounter",
				rank: i.rank,
				stranger: !1,
				extra: 0,
				after: {
					t: "move",
					to: n,
					doors: r,
					doorIdx: s + 1,
					pay: a,
					focus: o
				}
			}, e.char === "hunter" ? 3 : 2), null;
		}
	}
	return e.moveFree = !1, e.room = n, e.flags.focusTravel = !1, e.flags.wanderlust ? (e.flags.wanderlust = !1, q(e, t, {
		t: "gain",
		slot: "loot",
		then: { t: "resolveRoom" }
	}), null) : (De(e, t), null);
}
function Ee(e, t, n, r) {
	let i = 0;
	for (let n of t) {
		let t = e.equipment.find((e) => e.card === n);
		if (!t || t.exhausted) return R(z("errPay"));
		i += H(t);
	}
	if (r && t.includes(r[0])) {
		if (e.char !== "seer" || e.flags.focusTravel || H(e.equipment.find((e) => e.card === r[0])) + r[1] < 1) return R(z("errFocus"));
		i += r[1], e.flags.focusTravel = !0;
	}
	return i < n ? R(z("errPay")) : (e.char === "seer" && i === n && t.length > 0 && (e.flags.wanderlust = !0), null);
}
function De(e, t) {
	let n = V(e, e.room), r = { t: "room" }, i = (i, a, o = !1) => q(e, t, {
		t: "encounter",
		rank: i,
		after: r,
		stranger: !1,
		extra: a,
		room: n.id,
		boss: o
	}, e.char === "hunter" ? 3 : 2);
	switch (n.kind) {
		case "start": return Z(e, t);
		case "spring":
			e.pending = {
				kind: "spring",
				maxHeal: e.mapId === "m4" && W(e, e.room) ? 2 : 1,
				resume: r
			};
			return;
		case "keep": return q(e, t, {
			t: "keep",
			slots: Oe(n),
			resume: r
		}, n.draw);
		case "event": return q(e, t, {
			t: "event",
			room: n.id,
			then: r
		});
		case "challenge":
			e.pending = {
				kind: "challenge",
				room: n.id,
				resume: r
			};
			return;
		case "merchant":
			e.pending = {
				kind: "merchant",
				left: n.max,
				resume: r
			};
			return;
		case "enemy": return i(n.rank, n.extraReward ?? 0);
		case "stranger":
			q(e, t, {
				t: "encounter",
				rank: n.rank,
				after: r,
				stranger: !0,
				extra: 0,
				room: n.id
			}, 3);
			return;
		case "cairn":
			if (![
				...e.equipment.map((e) => e.card),
				...e.items,
				...e.loot
			].some((e) => S(e) === n.suit)) return Z(e, t);
			e.pending = {
				kind: "cairn",
				suit: n.suit,
				resume: r
			};
			return;
		case "shrine":
			e.torch &&= (e.loot.push(e.torch.card), null), q(e, t, {
				t: "gain",
				slot: "torch",
				then: r
			});
			return;
		case "sapling": return q(e, t, {
			t: "keep",
			slots: ["torch"],
			resume: r
		}, 3);
		case "gear": {
			let i = [];
			n.suit === 0 ? i.push({ t: "item" }) : n.suit === 3 ? i.push({ t: "equip" }) : n.suit === 2 ? i.push({ t: "loot" }) : i.push({
				t: "shuffleDiscard",
				n: 5
			}), he(e, t, [{
				t: "clock",
				n: 1
			}, ...i], r);
			return;
		}
		case "pendulum": return q(e, t, {
			t: "table",
			room: n.id,
			then: r
		});
		case "discardClock":
			e.pending = {
				kind: "discardClock",
				pool: n.pool,
				clockDelta: n.clockDelta,
				resume: r
			};
			return;
		case "collector":
			if (e.items.length === 0) return Z(e, t);
			e.pending = {
				kind: "collector",
				resume: r
			};
			return;
		case "chapel": {
			if (e.candles.includes(n.id)) return Z(e, t);
			let i = W(e, n.id);
			if (!(i || [
				...e.equipment.map((e) => e.card),
				...e.items,
				...e.loot
			].some((e) => S(e) === n.suit))) return Z(e, t);
			e.pending = {
				kind: "chapel",
				room: n.id,
				free: i,
				resume: r
			};
			return;
		}
		case "transept":
			e.pending = {
				kind: "transept1",
				room: n.id,
				resume: r
			};
			return;
		case "pickTake": {
			let i = W(e, n.id) ? n.floodedMode : n.mode;
			q(e, t, {
				t: "pickTake",
				take: n.take,
				mode: i,
				to: n.to,
				resume: r
			}, n.draw);
			return;
		}
		case "choir": {
			let i = W(e, e.room) ? 1 : 2;
			ke(e, t, n.id, r, i);
			return;
		}
		case "cloister":
			q(e, t, {
				t: "gain",
				slot: "item",
				then: W(e, e.room) ? {
					t: "chain",
					p: {
						kind: "cloister",
						left: 2,
						resume: r
					}
				} : r
			});
			return;
		case "boss": return i("C", 0, !0);
	}
}
function Oe(e) {
	return e.slots;
}
function ke(e, t, n, r, i = 1) {
	q(e, t, {
		t: "encounter",
		rank: "B",
		after: i > 1 ? {
			t: "choir2",
			room: n
		} : r,
		stranger: !1,
		extra: 0,
		room: n
	}, e.char === "hunter" ? 3 : 2);
}
function Ae(e, t, n) {
	let r = n.enemyCard, i = x(r), a = i + {
		A: 5,
		B: 10,
		C: 15
	}[t];
	e.combat = {
		enemySuit: S(r),
		rank: t,
		x: i,
		hp: a,
		maxHp: a,
		enemyCard: r,
		reward: n.rewardCard ?? null,
		extraRewards: [],
		battleCard: null,
		defended: 0,
		blocked: 0,
		unabsorbed: 0,
		hurt: !1,
		acted: !1,
		defendUsed: !1,
		dealt: !1,
		parried: !1,
		instantResolved: !1,
		rounds: 0,
		hidden: !1,
		boss: n.boss ?? !1,
		bossKind: n.boss ? {
			m1: "warden",
			m2: "nightshade",
			m3: "clockmaker",
			m4: "priest"
		}[e.mapId] : null,
		windup: [],
		battleLog: [],
		used: [],
		armadilloUsed: !1,
		lastAttackRank: null,
		after: n.after,
		roomFight: n.room ?? null,
		noReward: n.noReward ?? !1
	}, G(e, z("log.combat"), {
		enemy: S(r),
		rank: t
	});
}
function je(e, t, n, r) {
	if (r.stranger) {
		let [t, i, a] = [...n].sort((e, t) => C(e, t) ? -1 : 1);
		e.bounty.push(i), Ae(e, r.rank, {
			after: r.after,
			enemyCard: t,
			rewardCard: a,
			room: r.room
		});
		return;
	}
	if (n.length === 3) {
		e.pending = {
			kind: "hunterBottom",
			cards: n,
			use: r
		};
		return;
	}
	let [i, a] = n, o = C(i, a) ? i : a, s = C(i, a) ? a : i;
	Ae(e, r.rank, {
		after: r.after,
		enemyCard: o,
		rewardCard: s,
		room: r.room,
		boss: r.boss
	}), r.extra > 0 && q(e, t, {
		t: "extraReward",
		then: { t: "none" }
	}, r.extra);
}
function Me(e, t) {
	let n = e.combat;
	if (n.bossKind === "warden" && e.equipment.some((e) => !e.exhausted)) {
		e.pending = {
			kind: "pickExhaust",
			n: 1,
			resume: { t: "drawBattle" }
		};
		return;
	}
	n.bossKind === "nightshade" && e.torch && Ne(e), q(e, t, { t: "battle" });
}
function Ne(e) {
	e.torch && (e.torch.dimmed ? (e.discard.push(e.torch.card), e.torch = null) : e.torch.dimmed = !0);
}
function Pe(e, t, n) {
	let r = e.combat;
	r.battleCard = n, r.rounds++, r.defended = 0, r.blocked = 0, r.hurt = !1, r.acted = !1, r.defendUsed = !1, r.dealt = !1, r.parried = !1, r.instantResolved = !1, r.hidden = e.mapId === "m2" && x(n) > oe(e);
	let i = B(e).enemies[r.enemySuit].acts[S(n)], a = i.instant === !0 || i.instant === "flooded" && W(e, e.room) || i.instant === "hidden" && r.hidden;
	for (let t of i.effs) t.k === "block" && fe(e, t.cond) && (r.blocked += J(e, t.v) + (t.floodedAdd && W(e, e.room) ? t.floodedAdd : 0));
	a && (r.instantResolved = !0, Ie(e, t, i.effs.flatMap((e) => e.k === "block" ? [e, ...e.then ?? []] : [e]), { t: "none" }), e.pending || e.phase !== "play") || r.used.includes("scavenge") && !r.acted && (r.acted = !0, Fe(e, t));
}
function Fe(e, t) {
	let n = e.combat;
	if (n.parried || n.instantResolved) {
		Ve(e);
		return;
	}
	Ie(e, t, B(e).enemies[n.enemySuit].acts[S(n.battleCard)].effs.flatMap((e) => e.k === "block" ? e.then ?? [] : [e]), { t: "roundEnd" });
}
function Ie(e, t, n, r) {
	for (let i = 0; i < n.length; i++) {
		let a = n[i];
		if (!fe(e, a.cond)) continue;
		let o = i + 1 < n.length ? {
			t: "enemyPhase",
			effs: n.slice(i + 1),
			resume: r
		} : r, s = W(e, e.room);
		switch (a.k) {
			case "attack":
				Le(e, t, a, o);
				return;
			case "block": break;
			case "heal": {
				let t = e.combat;
				t.hp = Math.min(30, t.hp + J(e, a.v) + (a.floodedAdd && s ? a.floodedAdd : 0));
				break;
			}
			case "destroy": {
				let t = J(e, a.v) + (a.floodedAdd && s ? a.floodedAdd : 0);
				a.hiddenV !== void 0 && e.combat.hidden && (t = J(e, a.hiddenV));
				for (let n = 0; n < t; n++) {
					let t = e.deck.pop();
					t !== void 0 && e.discard.push(t);
				}
				break;
			}
			case "exhaustHighestReady": {
				let t = e.equipment.filter((e) => !e.exhausted);
				if (t.length) {
					let n = t.reduce((e, t) => H(e) >= H(t) ? e : t);
					a.discardIfHidden && e.combat.hidden ? (e.equipment = e.equipment.filter((e) => e !== n), e.discard.push(n.card)) : n.exhausted = !0;
				}
				break;
			}
			case "exhaustOne":
				if (e.equipment.some((e) => !e.exhausted)) {
					e.pending = {
						kind: "pickExhaust",
						n: 1,
						resume: o
					};
					return;
				}
				break;
			case "exhaustAllLt": {
				let t = a.n === "windupSum" ? J(e, "windupSum") : a.n;
				for (let n of e.equipment) !n.exhausted && H(n) < t && (n.exhausted = !0);
				break;
			}
			case "woundPlayer":
				a.n > 1 ? (e.queue = {
					jobs: Array.from({ length: a.n - 1 }, () => ({ t: "wound" })),
					resume: o
				}, Y(e, t, { t: "queue" })) : Y(e, t, o);
				return;
			case "dimTorch":
				Ne(e);
				break;
			case "discardTorch":
				e.torch &&= (e.discard.push(e.torch.card), null);
				break;
			case "clock":
				if (K(e, t, a.n, o)) return;
				break;
			case "windup":
				if (e.combat.battleCard !== null && !e.combat.windup.includes(e.combat.battleCard) && e.combat.windup.push(e.combat.battleCard), a.then) {
					Ie(e, t, a.then, o);
					return;
				}
				break;
			case "drawWindup":
				q(e, t, {
					t: "windupDraw",
					then: o
				});
				return;
			case "flood":
				q(e, t, {
					t: "flood",
					then: o
				});
				return;
			case "extinguishHighestCandle": if (e.candles.length) {
				let t = Se(e), n = e.candles.reduce((e, n) => (t.get(e) ?? 0) >= (t.get(n) ?? 0) ? e : n);
				e.candles = e.candles.filter((e) => e !== n);
			}
		}
	}
	X(e, t, r);
}
function Le(e, t, n, r) {
	let i = e.combat;
	if (e.char === "druid" && e.form === 2 && !i.armadilloUsed) {
		i.armadilloUsed = !0, X(e, t, r);
		return;
	}
	let a = J(e, n.v) + (n.floodedAdd && W(e, e.room) ? n.floodedAdd : 0), o = a, s = 0;
	if (!(n.unblockableIf && fe(e, n.unblockableIf)) && i.defended > 0) {
		if (n.perfectBlockBacklash !== void 0 && i.defended === a) {
			ze(e, t, J(e, n.perfectBlockBacklash), !1, r);
			return;
		}
		s = Math.min(i.defended, o), o -= s;
	}
	if (i.unabsorbed = o, e.char === "barbarian" && i.defendUsed && s === a && a > 0 && !i.used.includes("riposte")) {
		i.used.push("riposte");
		let a = {
			t: "afterDmg",
			eff: n,
			absorbed: s,
			resume: r
		}, o = e.equipment.some((e) => e.exhausted) ? {
			t: "chain",
			p: {
				kind: "pickRefresh",
				n: 1,
				resume: a
			}
		} : a;
		Ye(e, t, 5 - i.blocked, o);
		return;
	}
	let c = (n.repeatIfWound ?? !1) && e.wounds.length + e.woundsExhausted.length > 0 ? {
		t: "repeatAttack",
		eff: n,
		resume: {
			t: "afterDmg",
			eff: n,
			absorbed: s,
			resume: r
		}
	} : {
		t: "afterDmg",
		eff: n,
		absorbed: s,
		resume: r
	};
	if (o > 0) {
		i.dealt = !0, ze(e, t, o, B(e).enemies[i.enemySuit].autoWound ?? !1, c);
		return;
	}
	X(e, t, c);
}
function Re(e, t, n, r, i) {
	let a = e.combat;
	if (a && e.phase === "play") {
		if (n.ifDealt && a.dealt) {
			Ie(e, t, n.ifDealt, i);
			return;
		}
		if (n.ifNoDefend && !a.defendUsed) {
			Ie(e, t, n.ifNoDefend, i);
			return;
		}
		if (n.ifUnabsorbed && a.unabsorbed > 0) {
			Ie(e, t, n.ifUnabsorbed, i);
			return;
		}
		X(e, t, i);
	}
}
function ze(e, t, n, r, i) {
	r ? Y(e, t, i) : q(e, t, {
		t: "wound",
		damage: n,
		then: i
	});
}
function Be(e, t) {
	let n = e.combat;
	if (n && e.phase === "play") {
		if (n.hp <= 0) {
			He(e, t, "collect");
			return;
		}
		Fe(e, t);
	}
}
function Ve(e) {
	let t = e.combat;
	if (t && e.phase === "play") {
		if (t.bossKind === "priest") {
			let t = e.floodCount[B(e).bossRoom] ?? 0;
			for (let n = 0; n < t; n++) {
				let t = e.deck.pop();
				t !== void 0 && e.discard.push(t);
			}
		}
		t.battleCard !== null && (t.battleLog.push(t.battleCard), t.windup.includes(t.battleCard) || e.discard.push(t.battleCard), t.battleCard = null), e.flags.focusCombat = !1;
	}
}
function He(e, t, n) {
	let r = e.combat;
	switch (n) {
		case "collect":
			if (e.char === "hunter" && !e.collection.some((e) => x(e) === x(r.enemyCard))) {
				e.pending = {
					kind: "collect",
					card: r.enemyCard,
					resume: {
						t: "win",
						step: "scavenge"
					}
				};
				return;
			}
			return He(e, t, "scavenge");
		case "scavenge":
			if (e.char === "alchemist" && r.battleLog.length > 0) {
				e.pending = {
					kind: "scavengePick",
					resume: {
						t: "win",
						step: "rewards"
					}
				};
				return;
			}
			return He(e, t, "rewards");
		case "rewards": {
			let n = [];
			if (!r.noReward && r.reward !== null && n.push(r.reward), n.push(...r.extraRewards), n.length) {
				e.pending = {
					kind: "reward",
					card: n[0],
					queue: n.slice(1),
					resume: {
						t: "win",
						step: "final"
					}
				};
				return;
			}
			return He(e, t, "final");
		}
		case "final": return Ue(e, t);
	}
}
function Ue(e, t) {
	let n = e.combat, r = n.after;
	e.discard.push(...n.windup);
	let i = e.collection.includes(n.enemyCard), a = e.char === "barbarian" && n.rounds <= 2 || e.char === "rogue" && n.lastAttackRank !== null && n.lastAttackRank <= 5, o = n.roomFight ? V(e, n.roomFight) : null, s = [];
	o?.kind === "enemy" && (o.clockOnWin && s.push({
		t: "clock",
		n: o.clockOnWin
	}), o.shuffleOnWin && s.push({
		t: "shuffleDiscard",
		n: W(e, e.room) ? o.shuffleOnWin[1] : o.shuffleOnWin[0]
	})), G(e, z("log.kill"), { enemy: n.enemySuit });
	let c = n.boss, l = n.enemyCard;
	if (e.combat = null, a && !i ? ge(e, t, l, "loot", { t: "none" }) : i || e.discard.push(l), e.phase !== "play") return;
	s.length && !c && (e.queue = {
		jobs: s,
		resume: r
	});
	let u = c ? { t: "bossWin" } : s.length ? { t: "queue" } : r;
	e.pending ? e.pending.resume = u : X(e, t, u);
}
function We(e, t, n) {
	let r = T[e.map], i = {
		host: t[0],
		seed: n,
		cursor: 0,
		mapId: e.map,
		char: e.char,
		phase: "play",
		loseReason: null,
		deck: [],
		discard: [],
		room: r.startRoom,
		equipment: [],
		items: [],
		loot: [],
		wounds: [],
		woundsExhausted: [],
		torch: null,
		bounty: [],
		clock: e.map === "m3" ? 8 : 0,
		flooded: e.map === "m4" ? [r.startRoom] : [],
		floodCount: {},
		candles: [],
		form: null,
		collection: [],
		combat: null,
		pending: null,
		queue: null,
		flags: {},
		moveFree: !1,
		deferFlood: !1,
		poison: null,
		log: []
	}, a = se(i, ee()), o = [], s = () => {
		let e = a.pop();
		for (; x(e) === 1;) o.push(e), e = a.pop();
		return e;
	};
	i.items = [s(), s()];
	let c = 0;
	for (; c < 20;) {
		let e = s();
		i.equipment.push({
			card: e,
			bonus: null,
			exhausted: !1,
			ovrRank: null,
			ovrSuit: null
		}), c += x(e);
	}
	if (a = se(i, [...a, ...o]), i.deck = a, e.char === "fallen") {
		let e = [], t = i.deck.pop();
		for (; x(t) === 1;) e.push(t), t = i.deck.pop();
		e.length && (i.deck = se(i, [...i.deck, ...e])), i.wounds = [t];
	}
	return {
		state: i,
		fx: []
	};
}
function Ge(e, t, n) {
	if (n.by !== e.host) return R(z("errNotPlayer"));
	if (e.phase !== "play") return R(z("errOver"));
	let r = structuredClone(e), i = [];
	return Ke(r, t, i) || {
		state: r,
		fx: i
	};
}
function Ke(e, t, n) {
	switch (t.t) {
		case "move": return we(e, n, t.to, t.pay ?? [], t.focus, t.via);
		case "stay": return e.pending || e.combat || e.queue ? R(z("errBusy")) : (Z(e, n), null);
		case "setTorch": {
			if (e.mapId !== "m2" || e.pending) return R(z("errBusy"));
			let n = e.equipment.find((e) => e.card === t.card);
			return n ? (e.torch && e.discard.push(e.torch.card), e.torch = {
				card: n.card,
				dimmed: n.exhausted
			}, e.equipment = e.equipment.filter((e) => e !== n), null) : R(z("errNoCard"));
		}
		case "reveal": {
			let t = e.combat;
			return !t || t.battleCard !== null || e.pending ? R(z("errNoCombat")) : (Me(e, n), null);
		}
		case "attack": return qe(e, t, n);
		case "defend": return Je(e, t, n);
		case "rest": {
			let t = e.combat;
			if (!t || t.battleCard === null || t.acted || e.pending) return R(z("errNoCombat"));
			for (let t of e.equipment) t.exhausted = !1;
			return t.acted = !0, Fe(e, n), null;
		}
		case "useItem": return Xe(e, t, n);
		case "brew": return Qe(e, t, n);
		case "ability": return $e(e, t, n);
		case "choose": return tt(e, t.option, n);
		case "pick": return nt(e, t.cards, t.pool, n);
		case "challenge": return et(e, t, n);
	}
}
function qe(e, t, n) {
	let r = e.combat;
	if (!r || r.battleCard === null || r.acted || e.pending) return R(z("errNoCombat"));
	let i = e.equipment.find((e) => e.card === t.equip);
	if (!i || i.exhausted) return R(z("errExhausted"));
	let a = H(i);
	if (t.focus) {
		if (e.char !== "seer" || e.flags.focusCombat || t.focus[0] !== t.equip || a + t.focus[1] < 1) return R(z("errFocus"));
		a += t.focus[1], e.flags.focusCombat = !0;
	}
	e.char === "druid" && e.form === 1 && (a += 5);
	let o = a;
	for (let n of t.extras ?? []) {
		if (e.char !== "rogue") return R(z("errAbility"));
		let t = e.equipment.find((e) => e.card === n);
		if (!t || t.exhausted || t === i) return R(z("errAbility"));
		t.exhausted = !0, a += 2;
	}
	if (t.bloodRage !== void 0) {
		if (e.char !== "fallen" || r.used.includes("bloodRage") || r.rank === "C" || !e.wounds.includes(t.bloodRage)) return R(z("errAbility"));
		e.wounds = e.wounds.filter((e) => e !== t.bloodRage), e.woundsExhausted.push(t.bloodRage), a *= 2, r.used.push("bloodRage");
	}
	return e.poison && e.poison.card === t.equip && (a += e.poison.amount, e.poison = null), i.exhausted = !0, r.lastAttackRank = o, r.acted = !0, Ye(e, n, a - r.blocked, { t: "afterAttack" }), null;
}
function Je(e, t, n) {
	let r = e.combat;
	if (!r || r.battleCard === null || r.acted || e.pending) return R(z("errNoCombat"));
	let i = B(e).enemies[r.enemySuit].acts[S(r.battleCard)].effs.find((e) => e.k === "attack"), a = 0, o = /* @__PURE__ */ new Set();
	for (let n of t.equips) {
		let t = e.equipment.find((e) => e.card === n);
		if (!t || t.exhausted || o.has(n)) return R(z("errExhausted"));
		if (i?.onlySuits && !i.onlySuits.includes(U(t))) return R(z("errDefendSuit"));
		o.add(n), a += H(t);
	}
	if (i?.singleEquipOnly && t.equips.length > 1) return R(z("errDefendSuit"));
	let s = t.focus;
	if (s) {
		if (e.char !== "seer" || e.flags.focusCombat || !o.has(s[0]) || H(e.equipment.find((e) => e.card === s[0])) + s[1] < 1) return R(z("errFocus"));
		a += s[1], e.flags.focusCombat = !0;
	}
	for (let n of t.equips) e.equipment.find((e) => e.card === n).exhausted = !0;
	return r.defended = a, r.defendUsed = !0, r.acted = !0, Fe(e, n), null;
}
function Ye(e, t, n, r) {
	let i = e.combat;
	n > 0 && (i.hurt = !0), i.hp = Math.max(0, i.hp - n);
	let a = { t: "afterAttack" }, o = n > 0 ? B(e).hpTrack[i.hp] : void 0;
	if (o) switch (o) {
		case "wound":
			Y(e, t, a);
			return;
		case "parry":
			i.parried = !0;
			break;
		case "refresh1":
		case "refresh2": {
			let t = o === "refresh1" ? 1 : 2;
			if (e.equipment.some((e) => e.exhausted)) {
				e.pending = {
					kind: "pickRefresh",
					n: t,
					resume: a
				};
				return;
			}
			break;
		}
		case "dim":
			Ne(e);
			break;
		case "clockUp":
			if (K(e, t, 1, a)) return;
			break;
		case "clockDown":
			if (K(e, t, -1, a)) return;
			break;
		case "flood":
			q(e, t, {
				t: "flood",
				then: a
			});
			return;
	}
	X(e, t, r);
}
function Xe(e, t, n) {
	if (e.pending) return R(z("errBusy"));
	let r = e.items.indexOf(t.card);
	if (r < 0) return R(z("errNoCard"));
	let i = S(t.card), a = () => {
		e.items.splice(r, 1), e.discard.push(t.card);
	};
	switch (i) {
		case 0:
			if (a(), e.char === "tinkerer") q(e, n, {
				t: "pickTake",
				take: 1,
				mode: "lowest",
				to: "equip",
				resume: { t: "none" }
			}, 3);
			else {
				for (let t of e.equipment) t.exhausted = !1;
				Ze(e);
			}
			return null;
		case 1: {
			if (e.char === "hunter") return a(), e.moveFree = !0, Ze(e), null;
			if (e.char === "rogue") {
				let n = e.equipment.find((e) => e.card === t.params?.ready && !e.exhausted), r = e.equipment.find((e) => e.card === t.params?.exhausted && e.exhausted);
				return !n || !r ? R(z("errNoCard")) : (a(), e.poison = {
					card: n.card,
					amount: H(r)
				}, Ze(e), null);
			}
			let n = e.equipment.find((e) => e.card === t.params?.equip);
			return !n || t.params?.rank === void 0 && t.params?.suit === void 0 ? R(z("errNoCard")) : (a(), t.params?.rank !== void 0 && (n.ovrRank = t.params.rank), t.params?.suit !== void 0 && (n.ovrSuit = t.params.suit), Ze(e), null);
		}
		case 2: {
			if (e.char === "fallen") return a(), q(e, n, {
				t: "woundDirect",
				then: {
					t: "chain",
					p: {
						kind: "dragonBlood",
						resume: { t: "none" }
					}
				}
			}), null;
			let r = e.wounds.find((e) => e === t.params?.wound);
			return r === void 0 ? R(z("errNoCard")) : (a(), e.wounds = e.wounds.filter((e) => e !== r), e.discard.push(r), Ze(e), null);
		}
		case 3: return R(z("errCrystal"));
	}
}
function Ze(e) {
	e.char === "tinkerer" && e.equipment.some((e) => e.exhausted) && (e.pending = {
		kind: "pickRefresh",
		n: 1,
		resume: { t: "none" }
	});
}
function Qe(e, t, n) {
	if (e.char !== "alchemist" || e.pending) return R(z("errBusy"));
	for (let n of t.mix) if (!e.items.includes(n)) return R(z("errNoCard"));
	let r = t.mix.map((e) => S(e)), i = r.filter((e) => e === 3).length, a = r.filter((e) => e !== 3);
	if (a.length > 0 && new Set(a).size > 1) return R(z("errBrew"));
	if (t.dilute !== void 0) {
		let n = e.equipment.find((e) => e.card === t.dilute);
		if (!n || n.exhausted || U(n) !== 3) return R(z("errAbility"));
		n.exhausted = !0;
	}
	if (t.fieldNotes !== void 0) {
		let n = e.equipment.find((e) => e.card === t.fieldNotes);
		if (!n || n.exhausted || U(n) !== 1) return R(z("errAbility"));
		n.exhausted = !0;
	}
	if (t.keep !== void 0 && !t.mix.includes(t.keep)) return R(z("errBrew"));
	let o = a.length ? a[0] : null, s = a.length;
	if (a.length === 0) {
		if (i < 3) return l(), Ze(e), null;
		o = 2, s = 3;
	} else i > 0 && (s = Math.min(3, a.length * (i + 1)));
	l();
	let c = { t: "none" };
	switch (o) {
		case 0: {
			if (!e.combat || e.combat.battleCard === null || e.combat.acted) return R(z("errNoCombat"));
			let t = [
				0,
				3,
				6,
				15
			][s];
			return e.combat.acted = !0, Ye(e, n, t, { t: "afterAttack" }), null;
		}
		case 1: {
			let t = s >= 2 ? 2 : 1, r = e.equipment.some((e) => e.exhausted);
			return s >= 3 ? he(e, n, [{ t: "equip" }], r ? {
				t: "chain",
				p: {
					kind: "pickRefresh",
					n: t,
					resume: c
				}
			} : c) : r && (e.pending = {
				kind: "pickRefresh",
				n: t,
				resume: c
			}), null;
		}
		case 2: {
			let t = s >= 3 ? 2 : 1, r = s >= 3 ? 6 : s >= 2 ? 3 : 0;
			r > 0 && (e.queue = {
				jobs: [{
					t: "shuffleDiscard",
					n: r
				}],
				resume: c
			});
			let i = r > 0 ? { t: "queue" } : c;
			return e.wounds.length ? e.pending = {
				kind: "pickWound",
				max: t,
				resume: i
			} : r > 0 && X(e, n, { t: "queue" }), null;
		}
		default: return null;
	}
	function l() {
		for (let n of t.mix) {
			if (n === t.keep) continue;
			let r = e.items.indexOf(n);
			r >= 0 && (e.items.splice(r, 1), e.discard.push(n));
		}
		if (t.keep !== void 0 && t.fieldNotes !== void 0) {
			let n = e.items.indexOf(t.keep);
			n >= 0 && (e.items.splice(n, 1), e.loot.push(t.keep));
		}
	}
}
function $e(e, t, n) {
	if (e.pending) return R(z("errBusy"));
	switch (t.id) {
		case "shapeshift": {
			if (e.char !== "druid") return R(z("errAbility"));
			let n = e.equipment.find((e) => e.card === t.card);
			return !n || n.exhausted ? R(z("errExhausted")) : (n.exhausted = !0, e.form = U(n), null);
		}
		case "throwAxe": {
			let r = e.combat;
			if (e.char !== "barbarian" || !r || r.battleCard === null || r.acted || r.rank === "C" || r.used.includes("throwAxe")) return R(z("errAbility"));
			let i = e.equipment.find((e) => e.card === t.card);
			return !i || i.exhausted || U(i) !== 1 ? R(z("errAbility")) : (r.used.push("throwAxe"), r.acted = !0, e.equipment = e.equipment.filter((e) => e !== i), e.discard.push(i.card), Ye(e, n, H(i) * 2 - r.blocked, { t: "afterAttack" }), null);
		}
		case "scavenge": {
			let t = e.combat;
			return e.char !== "tinkerer" || !t || t.battleCard !== null || t.used.includes("scavenge") || e.discard.length === 0 ? R(z("errAbility")) : (t.used.push("scavenge"), e.loot.push(e.discard.pop()), null);
		}
		case "bladeReady": {
			if (e.char === "rogue" || e.combat || e.flags.bladeReady) return R(z("errAbility"));
			let n = e.equipment.find((e) => e.card === t.card);
			return !n || !n.exhausted || H(n) > 5 ? R(z("errAbility")) : (n.exhausted = !1, e.flags.bladeReady = !0, null);
		}
	}
}
function et(e, t, n) {
	let r = e.pending;
	if (r?.kind !== "challenge") return R(z("errNoPending"));
	let i = V(e, r.room);
	if (i.kind !== "challenge") return R(z("errNoPending"));
	let a = 0, o = /* @__PURE__ */ new Set();
	for (let n of t.equips) {
		let t = e.equipment.find((e) => e.card === n);
		if (!t || t.exhausted || o.has(n)) return R(z("errExhausted"));
		o.add(n);
		let r = H(t), s = U(t);
		switch (i.filter) {
			case "face":
				if (r < 11) return R(z("errFilter"));
				break;
			case "red":
				if (s !== 2 && s !== 3) return R(z("errFilter"));
				break;
			case "even":
				if (r % 2 != 0) return R(z("errFilter"));
				break;
			case "black": if (s !== 0 && s !== 1) return R(z("errFilter"));
		}
		a += r;
	}
	let s = t.focus;
	if (s) {
		if (e.char !== "seer" || e.flags.focusTravel || !o.has(s[0]) || H(e.equipment.find((e) => e.card === s[0])) + s[1] < 1) return R(z("errFocus"));
		a += s[1], e.flags.focusTravel = !0;
	}
	for (let n of t.equips) e.equipment.find((e) => e.card === n).exhausted = !0;
	return e.pending = null, be(e, n, i.tiers.find((e) => a >= e.min) ?? { min: 0 }, r.resume), null;
}
function tt(e, t, n) {
	let r = e.pending;
	if (!r) return R(z("errNoPending"));
	switch (r.kind) {
		case "reward": {
			if (t < 0 || t > 2) return R(z("errChoice"));
			let i = t === 0 ? "item" : t === 1 ? "equip" : "loot";
			return e.pending = null, ge(e, n, r.card, i, {
				t: "rewards",
				queue: r.queue,
				resume: r.resume
			}), null;
		}
		case "spring":
			if (t === 0) {
				e.pending = null;
				for (let t of e.equipment) t.exhausted = !1;
				return X(e, n, r.resume), null;
			}
			return t !== 1 || !e.wounds.length ? R(z("errChoice")) : (e.pending = {
				kind: "pickWound",
				max: r.maxHeal,
				resume: r.resume
			}, null);
		case "curse":
			if (t === 1) {
				let t = e.items.find((e) => S(e) === 2);
				return e.char === "fallen" || t === void 0 ? R(z("errChoice")) : (e.items = e.items.filter((e) => e !== t), e.discard.push(t), e.pending = null, at(e, n, r.after), null);
			}
			return t === 0 ? (e.pending = null, it(e, n, r.suit, r.after), null) : R(z("errChoice"));
		case "confirmDraw":
			if (t === 0) return e.pending = null, _e(e, n, r.cards, r.use), null;
			if (t === 1) {
				let t = e.equipment.find((e) => U(e) === 3);
				if (e.char !== "seer" || !t || r.cards.length !== 1) return R(z("errChoice"));
				e.equipment = e.equipment.filter((e) => e !== t), e.discard.push(t.card), e.deck.unshift(...r.cards);
				let n = [];
				for (let t = 0; t < 3; t++) {
					let t = e.deck.pop();
					if (t === void 0) return ce(e, "deck"), null;
					if (x(t) === 1) return e.discard.push(t), e.deck.unshift(...n), e.pending = {
						kind: "curse",
						suit: S(t),
						after: null
					}, null;
					n.push(t);
				}
				return e.pending = {
					kind: "seerPick",
					top3: n,
					use: r.use
				}, null;
			}
			return R(z("errChoice"));
		case "twist": {
			if (t !== 0) return R(z("errChoice"));
			e.pending = null, e.discard.push(r.card);
			let i = B(e).rooms.find((e) => e.kind === "gear" && e.suit === r.costSuit);
			return e.moveFree = !1, i && (e.room = i.id), G(e, z("log.lost")), De(e, n), null;
		}
		case "collect": return e.pending = null, t === 1 && e.collection.push(r.card), X(e, n, r.resume), null;
		case "scavengePick": return t === 0 ? (e.pending = null, X(e, n, r.resume), null) : R(z("errChoice"));
		case "molePick": return t < 0 || t > 1 ? R(z("errChoice")) : (e.pending = null, e.loot.push(r.cards[t]), e.discard.push(r.cards[1 - t]), X(e, n, r.resume), null);
		case "fuse": return t === 0 ? (e.pending = null, X(e, n, r.resume), null) : R(z("errChoice"));
		case "cairn":
		case "collector":
		case "discardClock": return t === 0 ? (e.pending = null, X(e, n, r.resume), null) : R(z("errChoice"));
		case "chapel": return t === 1 && r.free ? (e.pending = null, e.candles.push(r.room), G(e, z("log.candle"), { room: r.room }), X(e, n, r.resume), null) : t === 0 ? (e.pending = null, X(e, n, r.resume), null) : R(z("errChoice"));
		case "merchant": return t === 0 ? (e.pending = null, X(e, n, r.resume), null) : R(z("errChoice"));
		case "transept1": {
			let n = V(e, r.room);
			if (n.kind !== "transept") return R(z("errNoPending"));
			let i = W(e, r.room), a = {
				kind: "transept2",
				resume: r.resume
			}, o = {
				t: "chain",
				p: a
			};
			if (e.pending = null, r.room === "transeptW" && t === 0) return e.pending = e.wounds.length ? {
				kind: "pickWound",
				max: 1,
				resume: o
			} : a, null;
			if (t > 1) return R(z("errChoice"));
			let s = i ? n.refresh[1] : n.refresh[0];
			return e.pending = e.equipment.some((e) => e.exhausted) ? {
				kind: "pickRefresh",
				n: s,
				resume: o
			} : a, null;
		}
		case "transept2":
			if (t === 2) return e.pending = null, X(e, n, r.resume), null;
			if (t === 1) return e.pending = null, q(e, n, {
				t: "wound",
				damage: 1,
				then: { t: "transeptMove" }
			}), null;
			if (t === 0) {
				let t = W(e, e.room) ? 1 : 2;
				return e.equipment.filter((e) => !e.exhausted).length < t ? R(z("errChoice")) : (e.pending = {
					kind: "pickExhaust",
					n: t,
					resume: { t: "transeptMove" }
				}, null);
			}
			return R(z("errChoice"));
		case "cloister": return t === 0 ? (e.pending = null, X(e, n, r.resume), null) : t === 1 ? (e.pending = null, q(e, n, {
			t: "gain",
			slot: "item",
			then: r.left - 1 > 0 ? {
				t: "chain",
				p: {
					kind: "cloister",
					left: r.left - 1,
					resume: r.resume
				}
			} : r.resume
		}), null) : R(z("errChoice"));
		default: return R(z("errNoPending"));
	}
}
function nt(e, t, n, r) {
	let i = e.pending;
	if (!i) return R(z("errNoPending"));
	switch (i.kind) {
		case "confirmDraw": {
			if (t.length !== 1 || !i.cards.includes(t[0])) return R(z("errChoice"));
			let n = e.items.find((e) => S(e) === 3);
			if (n === void 0 || e.char === "alchemist") return R(z("errCrystal"));
			e.items = e.items.filter((e) => e !== n), e.discard.push(n), e.discard.push(t[0]), e.pending = null;
			let a = i.cards.filter((e) => e !== t[0]), o = e.deck.pop();
			return o === void 0 ? (ce(e, "deck"), null) : x(o) === 1 ? (e.discard.push(o), e.pending = {
				kind: "curse",
				suit: S(o),
				after: {
					drawn: a,
					need: a.length + 1,
					use: i.use
				}
			}, null) : (de(e, r, [...a, o], i.use), null);
		}
		case "keep": {
			if (t.length !== 1 || !i.cards.includes(t[0])) return R(z("errChoice"));
			let n = t[0], a = i.slots[i.step], o = i.cards.filter((e) => e !== n);
			return e.pending = null, i.step + 1 < i.slots.length ? ge(e, r, n, a, {
				t: "chain",
				p: {
					kind: "keep",
					cards: o,
					slots: i.slots,
					step: i.step + 1,
					resume: i.resume
				}
			}) : (e.deck.unshift(...o), ge(e, r, n, a, i.resume)), null;
		}
		case "merchant":
			if (t.length !== 1 || !n) return R(z("errChoice"));
			if (n === "equip") {
				let n = e.equipment.find((e) => e.card === t[0]);
				if (!n) return R(z("errNoCard"));
				e.equipment = e.equipment.filter((e) => e !== n), e.loot.push(n.card);
			} else {
				if (!e.loot.includes(t[0])) return R(z("errNoCard"));
				e.loot = e.loot.filter((e) => e !== t[0]), e.equipment.push({
					card: t[0],
					bonus: null,
					exhausted: !1,
					ovrRank: null,
					ovrSuit: null
				});
			}
			return i.left--, i.left <= 0 && (e.pending = null, X(e, r, i.resume)), null;
		case "cairn": {
			if (t.length !== 1) return R(z("errChoice"));
			if (!rt(e, t[0], i.suit)) return R(z("errNoCard"));
			e.discard.push(t[0]), e.pending = null;
			let n = e.discard.splice(-5);
			return e.deck = se(e, [...e.deck, ...n]), X(e, r, i.resume), null;
		}
		case "collector":
			for (let n of t) {
				let t = e.items.indexOf(n);
				if (t < 0) return R(z("errNoCard"));
				e.items.splice(t, 1), e.loot.push(n);
			}
			return e.pending = null, X(e, r, i.resume), null;
		case "discardClock": return t.length === 1 ? rt(e, t[0], void 0, i.pool) ? (e.discard.push(t[0]), e.pending = null, K(e, r, i.clockDelta, i.resume) || X(e, r, i.resume), null) : R(z("errNoCard")) : R(z("errChoice"));
		case "chapel": {
			let n = V(e, i.room), a = n.kind === "chapel" ? n.suit : void 0;
			if (!i.free) {
				if (t.length !== 1) return R(z("errChoice"));
				if (!rt(e, t[0], a)) return R(z("errNoCard"));
				e.discard.push(t[0]);
			}
			return e.pending = null, e.candles.push(i.room), G(e, z("log.candle"), { room: i.room }), X(e, r, i.resume), null;
		}
		case "pickExhaust":
			if (t.length > i.n) return R(z("errChoice"));
			for (let n of t) {
				let t = e.equipment.find((e) => e.card === n);
				if (!t || t.exhausted) return R(z("errExhausted"));
			}
			if (t.length < i.n && e.equipment.filter((e) => !e.exhausted).length > t.length) return R(z("errChoice"));
			for (let n of t) e.equipment.find((e) => e.card === n).exhausted = !0;
			return e.pending = null, X(e, r, i.resume), null;
		case "pickRefresh":
			if (t.length > i.n) return R(z("errChoice"));
			for (let n of t) {
				let t = e.equipment.find((e) => e.card === n);
				if (!t || !t.exhausted) return R(z("errExhausted"));
			}
			for (let n of t) e.equipment.find((e) => e.card === n).exhausted = !1;
			return e.pending = null, X(e, r, i.resume), null;
		case "pickWound":
			if (t.length > i.max || t.length === 0) return R(z("errChoice"));
			for (let n of t) if (!e.wounds.includes(n)) return R(z("errNoCard"));
			for (let n of t) e.wounds = e.wounds.filter((e) => e !== n), e.discard.push(n);
			return e.pending = null, X(e, r, i.resume), null;
		case "pickDiscard": return t.length === 1 ? (i.pool === "equip" ? (() => {
			let n = e.equipment.find((e) => e.card === t[0]);
			return n ? (e.equipment = e.equipment.filter((e) => e !== n), !0) : !1;
		})() : e.items.includes(t[0]) && (e.items = e.items.filter((e) => e !== t[0]), 1)) ? (e.discard.push(t[0]), e.pending = null, at(e, r, i.after), null) : R(z("errNoCard")) : R(z("errChoice"));
		case "cursePickLoot": {
			if (t.length !== 1) return R(z("errChoice"));
			let n = Math.max(...e.loot.map(x));
			return !e.loot.includes(t[0]) || x(t[0]) !== n ? R(z("errNoCard")) : (e.loot = e.loot.filter((e) => e !== t[0]), e.discard.push(t[0]), e.pending = null, at(e, r, i.after), null);
		}
		case "cursePickSuit": {
			if (t.length !== 1) return R(z("errChoice"));
			let n = S(t[0]);
			if (!i.suits.includes(n) || !e.equipment.some((e) => e.card === t[0])) return R(z("errChoice"));
			for (let t of e.equipment) U(t) === n && (t.exhausted = !0);
			return e.pending = null, at(e, r, i.after), null;
		}
		case "twist": {
			let n = 0;
			for (let r of t) {
				let t = e.equipment.find((e) => e.card === r);
				if (!t || t.exhausted) return R(z("errExhausted"));
				n += H(t);
			}
			if (n < i.cost) return R(z("errPay"));
			for (let n of t) e.equipment.find((e) => e.card === n).exhausted = !0;
			e.pending = null, e.discard.push(i.card);
			let a = {
				t: "move",
				to: i.to,
				doors: i.doors,
				doorIdx: i.doorIdx + 1,
				pay: i.pay,
				focus: i.focus
			};
			return K(e, r, -1, a) || X(e, r, a), null;
		}
		case "dragonBlood":
			if (t.length !== 2) return R(z("errChoice"));
			for (let n of t) if (!e.wounds.includes(n) && !e.woundsExhausted.includes(n)) return R(z("errNoCard"));
			for (let n of t) e.wounds = e.wounds.filter((e) => e !== n), e.woundsExhausted = e.woundsExhausted.filter((e) => e !== n), e.discard.push(n);
			return e.pending = null, Ze(e), e.pending || X(e, r, i.resume), null;
		case "fuse": {
			if (t.length !== 1) return R(z("errChoice"));
			let n = e.equipment.find((e) => e.card === t[0]), a = e.equipment.find((e) => e.card === i.card);
			return !n || !a || n === a || n.bonus !== null ? R(z("errChoice")) : (n.bonus = H(a), e.equipment = e.equipment.filter((e) => e !== a), e.pending = null, X(e, r, i.resume), null);
		}
		case "scavengePick": {
			if (t.length !== 1) return R(z("errChoice"));
			let n = e.combat;
			return !n || !n.battleLog.includes(t[0]) ? R(z("errNoCard")) : (n.battleLog = n.battleLog.filter((e) => e !== t[0]), e.discard = e.discard.filter((e) => e !== t[0]), e.items.push(t[0]), e.pending = null, X(e, r, i.resume), null);
		}
		case "seerPick": return t.length !== 1 || !i.top3.includes(t[0]) ? R(z("errChoice")) : (e.pending = null, e.deck.unshift(...i.top3.filter((e) => e !== t[0])), de(e, r, [t[0]], i.use), null);
		case "hunterBottom": return t.length !== 1 || !i.cards.includes(t[0]) ? R(z("errChoice")) : (e.pending = null, e.deck.unshift(t[0]), _e(e, r, i.cards.filter((e) => e !== t[0]), i.use), null);
		default: return R(z("errNoPending"));
	}
}
function rt(e, t, n, r) {
	if (n !== void 0 && S(t) !== n) return !1;
	if (r !== "equip" && e.items.includes(t)) return e.items = e.items.filter((e) => e !== t), !0;
	if (r !== "item") {
		let n = e.equipment.find((e) => e.card === t);
		if (n) return e.equipment = e.equipment.filter((e) => e !== n), !0;
	}
	return r === void 0 && e.loot.includes(t) ? (e.loot = e.loot.filter((e) => e !== t), !0) : !1;
}
function it(e, t, n, r) {
	let i = () => at(e, t, r), a = {
		t: "curseAfter",
		after: r
	};
	switch (e.mapId) {
		case "m1":
			if (n === 0) {
				if (e.equipment.length) {
					e.pending = {
						kind: "pickDiscard",
						pool: "equip",
						after: r
					};
					return;
				}
			} else if (n === 1) {
				Y(e, t, a);
				return;
			} else if (n === 3) {
				if (e.items.length) {
					e.pending = {
						kind: "pickDiscard",
						pool: "items",
						after: r
					};
					return;
				}
			} else if (e.loot.length) {
				let t = Math.max(...e.loot.map(x)), n = e.loot.filter((e) => x(e) === t);
				if (n.length === 1) e.loot = e.loot.filter((e) => e !== n[0]), e.discard.push(n[0]);
				else {
					e.pending = {
						kind: "cursePickLoot",
						after: r
					};
					return;
				}
			}
			i();
			return;
		case "m2":
			if (n === 0) e.torch &&= (e.discard.push(e.torch.card), null);
			else if (n === 1) {
				if (e.equipment.some((e) => !e.exhausted)) {
					e.pending = {
						kind: "pickExhaust",
						n: 2,
						resume: a
					};
					return;
				}
			} else if (n === 3) {
				let t = e.loot.filter((e) => x(e) >= 11);
				e.loot = e.loot.filter((e) => x(e) < 11), e.discard.push(...t);
			} else {
				Y(e, t, a);
				return;
			}
			i();
			return;
		case "m3":
			if (n === 0) {
				if (K(e, t, 2, a)) return;
			} else if (n === 1) {
				let t = b.map((t) => e.equipment.filter((e) => U(e) === t).length), n = Math.max(...t);
				if (n > 0) {
					let i = b.filter((e) => t[e] === n);
					if (i.length === 1) for (let t of e.equipment) U(t) === i[0] && (t.exhausted = !0);
					else {
						e.pending = {
							kind: "cursePickSuit",
							suits: i,
							after: r
						};
						return;
					}
				}
			} else if (n === 3) {
				if (e.loot.length) {
					let t = e.loot.map(x), n = Math.max(...t), r = Math.min(...t), i = e.loot.filter((e) => x(e) === n || x(e) === r);
					n === r ? (e.discard.push(i[0]), e.loot = e.loot.filter((e) => e !== i[0])) : (e.discard.push(...i), e.loot = e.loot.filter((e) => x(e) !== n && x(e) !== r));
				}
			} else {
				Y(e, t, a);
				return;
			}
			i();
			return;
		case "m4":
			if (n === 0) {
				q(e, t, {
					t: "flood",
					then: a
				});
				return;
			}
			if (n === 1) {
				if (e.equipment.length) {
					let t = Math.max(...e.equipment.map(H)), n = e.equipment.filter((e) => H(e) === t);
					e.equipment = e.equipment.filter((e) => H(e) !== t), e.discard.push(...n.map((e) => e.card));
				}
			} else if (n === 3) {
				if (e.candles.length) {
					let t = Se(e), n = e.candles.reduce((e, n) => (t.get(e) ?? 0) <= (t.get(n) ?? 0) ? e : n);
					e.candles = e.candles.filter((e) => e !== n);
				}
			} else {
				ze(e, t, 1, !1, a);
				return;
			}
			i();
			return;
	}
}
function at(e, t, n) {
	n && ue(e, t, n.need, n.use, n.drawn);
}
function ot(e) {
	let t = e.items.length * 2, n = [...e.loot];
	e.char === "fallen" && (n = [
		...n,
		...e.wounds,
		...e.woundsExhausted
	]);
	let r = n.reduce((e, t) => e + x(t), 0);
	r += e.collection.reduce((e, t) => e + x(t) * 2, 0);
	let i = e.mapId === "m2" ? e.bounty.reduce((e, t) => e + x(t), 0) * e.bounty.length : 0, a = e.mapId === "m4" ? e.candles.length * 5 : 0;
	return {
		items: t,
		loot: r,
		bounty: i,
		candles: a,
		total: t + r + i + a
	};
}
function st(e) {
	let t = e, n = t.phase === "play" && !t.combat && !t.pending ? Ce(t, t.room).map((e) => ({
		to: e.to,
		doors: e.doors.map((e) => ({
			t: e.t,
			n: "n" in e ? e.n : void 0,
			rank: "rank" in e ? e.rank : void 0
		})),
		floodedPath: t.mapId === "m4" && W(t, t.room) && W(t, e.to)
	})) : [];
	return {
		public: {
			mapId: t.mapId,
			char: t.char,
			room: t.room,
			phase: t.phase,
			loseReason: t.loseReason,
			deckCount: t.deck.length,
			discardCount: t.discard.length,
			equipment: t.equipment.map((e) => ({
				card: e.card,
				bonus: e.bonus,
				exhausted: e.exhausted,
				ovrRank: e.ovrRank,
				ovrSuit: e.ovrSuit
			})),
			items: t.items,
			loot: t.loot,
			wounds: t.wounds,
			woundsExhausted: t.woundsExhausted,
			torch: t.torch,
			bounty: t.bounty,
			clock: t.clock,
			flooded: t.flooded,
			floodCount: t.floodCount,
			candles: t.candles,
			form: t.form,
			collection: t.collection,
			combat: t.combat ? {
				enemySuit: t.combat.enemySuit,
				rank: t.combat.rank,
				x: t.combat.x,
				hp: t.combat.hp,
				maxHp: t.combat.maxHp,
				reward: t.combat.reward,
				extraRewards: t.combat.extraRewards,
				battleCard: t.combat.battleCard,
				defended: t.combat.defended,
				blocked: t.combat.blocked,
				hurt: t.combat.hurt,
				acted: t.combat.acted,
				parried: t.combat.parried,
				rounds: t.combat.rounds,
				hidden: t.combat.hidden,
				boss: t.combat.boss,
				windup: t.combat.windup,
				battleLog: t.combat.battleLog,
				used: t.combat.used
			} : null,
			pending: t.pending,
			flags: t.flags,
			moves: n,
			score: t.phase === "play" ? null : ot(t),
			log: t.log.slice(-20)
		},
		private: {}
	};
}
function ct(e) {
	return e.phase === "won" ? {
		phase: "done",
		winner: [e.host],
		ranking: [e.host],
		scores: { [e.host]: ot(e).total }
	} : e.phase === "lost" ? {
		phase: "done",
		winner: [],
		ranking: [e.host],
		scores: { [e.host]: ot(e).total }
	} : { phase: "play" };
}
var lt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: te,
	schemas: {
		action: F,
		publicView: re,
		privateView: ie,
		config: P
	},
	setup: We,
	reduce: Ge,
	viewFor: st,
	status: ct
}, Q = {
	width: 1e3,
	height: 960
}, ut = {
	m1: {
		boss: [500, 85],
		chest: [330, 175],
		goblin: [670, 175],
		merchant: [170, 275],
		vision: [500, 290],
		springE: [830, 310],
		statue: [165, 405],
		lizard: [485, 420],
		wall: [825, 445],
		springW: [85, 515],
		stairs: [310, 515],
		springS: [675, 555],
		wounded: [285, 635],
		traveller: [80, 665],
		jailer: [830, 665],
		library: [305, 770],
		flood: [455, 695],
		stash: [690, 765],
		cloaked: [510, 815],
		start: [475, 885]
	},
	m2: {
		boss: [470, 80],
		cairnC: [640, 160],
		tombA: [280, 160],
		strangerN: [460, 245],
		warrior: [815, 250],
		shrineE: [645, 340],
		springW: [245, 330],
		cairnD: [395, 405],
		tombB: [130, 425],
		strangerC: [600, 490],
		witch: [825, 425],
		shrineW: [240, 540],
		chest2: [120, 660],
		cairnH: [285, 735],
		springS: [640, 605],
		cairnS: [820, 610],
		strangerS: [500, 745],
		tombC: [780, 750],
		sapling: [355, 840],
		start: [575, 875]
	},
	m3: {
		boss: [455, 95],
		pendTL: [230, 160],
		collector: [650, 175],
		springL: [140, 320],
		scrap: [395, 285],
		bigHand: [795, 290],
		gearC: [95, 460],
		rats: [250, 455],
		gearD: [400, 420],
		escapement: [540, 540],
		gearS: [845, 460],
		pendML: [255, 595],
		gearH: [515, 685],
		pendMR: [730, 600],
		smallHand: [830, 720],
		magic: [520, 810],
		note: [925, 590],
		springR: [630, 405],
		start: [760, 850]
	},
	m4: {
		boss: [490, 80],
		apse: [290, 165],
		chapelH: [710, 165],
		choirBB: [470, 260],
		spring: [195, 310],
		grin: [835, 315],
		chapelD: [175, 445],
		cloister: [375, 410],
		chapelS: [735, 440],
		choirAA: [675, 565],
		transeptW: [255, 570],
		transeptE: [470, 630],
		roar: [160, 675],
		nave: [690, 720],
		hall: [320, 765],
		chapelC: [855, 800],
		start: [565, 875]
	}
}, dt = {
	start: "◆",
	boss: "✦",
	spring: "✚",
	enemy: "⚔",
	stranger: "⚔",
	gear: "⚙",
	chapel: "✧",
	event: "✦",
	keep: "▤",
	merchant: "◇",
	challenge: "◈",
	pendulum: "◷",
	cairn: "♜",
	shrine: "✧",
	sapling: "♣",
	collector: "◇",
	transept: "✚",
	pickTake: "▤",
	choir: "♫",
	cloister: "▤",
	discardClock: "◷"
}, ft = (e, t) => t ? "≈" : e.map((e) => e.t === "cost" ? String(e.n) : e.t === "enemy" ? e.rank : e.t === "torch" ? `♨${e.n}` : e.t === "twist" ? "↝" : "·").join(" · "), pt = (e) => Array.from(e).length > 11 ? `${Array.from(e).slice(0, 10).join("")}…` : e;
function mt({ view: e, selected: t, roomName: n, onSelect: s, overviewLabel: c, focusLabel: l }) {
	let u = T[e.mapId], d = ut[e.mapId], m = a(null), h = a(/* @__PURE__ */ new Map()), g = a(!1), _ = a(0), [v, y] = o({
		width: 360,
		height: 400
	}), [b, x] = o(!1), [S, ee] = o({
		x: 0,
		y: 0
	});
	r(() => {
		let e = m.current;
		if (!e) return;
		let t = new ResizeObserver(([e]) => y({
			width: e.contentRect.width,
			height: e.contentRect.height
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let C = d[e.room], w = t ? d[t.to] : null, E = [C, ...[...new Set(e.moves.map((e) => e.to))].map((e) => d[e])], D = {
		x: (Math.min(...E.map((e) => e[0])) + Math.max(...E.map((e) => e[0]))) / 2,
		y: (Math.min(...E.map((e) => e[1])) + Math.max(...E.map((e) => e[1]))) / 2
	}, O = w ? {
		x: (C[0] + w[0]) / 2 + S.x,
		y: (C[1] + w[1]) / 2 + S.y
	} : {
		x: D.x + S.x,
		y: D.y + S.y
	}, k = Math.max(.7, v.width / Math.max(1, v.height)), te = Math.max(...E.map((e) => e[0])) - Math.min(...E.map((e) => e[0])), A = Math.max(...E.map((e) => e[1])) - Math.min(...E.map((e) => e[1])), j = v.width >= 560 && v.height >= 300 ? Math.max(380, A + 150, (te + 180) / k, v.height / 1.9) : k > 1.3 ? 250 : 540, M = b ? Math.max(Q.height + 48, (Q.width + 48) / k) : j, N = b ? M * k : j * k, P = b ? (Q.width - N) / 2 : Math.min(Math.max(O.x, 0), Q.width) - N / 2, F = b ? (Q.height - M) / 2 : Math.min(Math.max(O.y, 0), Q.height) - M / 2, I = i(() => {
		let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
		u.edges.forEach((e) => {
			let n = [e.a, e.b].sort().join("|");
			t.set(n, (t.get(n) ?? 0) + 1);
		});
		let r = /* @__PURE__ */ new Map();
		return u.edges.map((i, a) => {
			let o = [i.a, i.b].sort().join("|"), s = n.get(o) ?? 0;
			n.set(o, s + 1);
			let c = (s - ((t.get(o) ?? 1) - 1) / 2) * 32, l = i.a === e.room || !i.directed && i.b === e.room, u = i.a === e.room ? i.b : i.a, f = l ? r.get(u) ?? 0 : -1;
			l && r.set(u, f + 1);
			let p = l ? e.moves.filter((e) => e.to === u)[f] : void 0, m = d[i.a], h = d[i.b], g = h[0] - m[0], _ = h[1] - m[1], v = Math.hypot(g, _) || 1, y = -_ / v, b = g / v, x = (m[0] + h[0]) / 2 + y * c, S = (m[1] + h[1]) / 2 + b * c;
			return {
				edge: i,
				index: a,
				via: f,
				to: u,
				move: p,
				midX: x,
				midY: S,
				path: `M ${m[0]} ${m[1]} Q ${x} ${S} ${h[0]} ${h[1]}`
			};
		});
	}, [
		u,
		d,
		e.room,
		e.moves
	]), L = (e, t) => {
		g.current || s({
			to: e,
			via: t
		});
	};
	return /* @__PURE__ */ p("div", {
		className: `r52-map r52-map--${e.mapId}`,
		ref: m,
		style: e.mapId === "m1" ? { backgroundImage: "url(./games/realms52-board.webp)" } : void 0,
		children: [/* @__PURE__ */ p("svg", {
			viewBox: `${P} ${F} ${N} ${M}`,
			"aria-label": n(e.room),
			onPointerDown: (e) => {
				h.current.set(e.pointerId, {
					x: e.clientX,
					y: e.clientY,
					startX: e.clientX,
					startY: e.clientY
				}), g.current = !1;
			},
			onPointerMove: (e) => {
				let t = h.current.get(e.pointerId);
				if (!t) return;
				let n = e.clientX - t.x, r = e.clientY - t.y;
				h.current.set(e.pointerId, {
					...t,
					x: e.clientX,
					y: e.clientY
				});
				let i = [...h.current.values()];
				if (i.length > 1) {
					let e = Math.hypot(i[0].x - i[1].x, i[0].y - i[1].y);
					_.current && Math.abs(e - _.current) > 16 && (x(e < _.current), g.current = !0), _.current = e;
				} else !b && Math.hypot(e.clientX - t.startX, e.clientY - t.startY) > 6 && (ee((e) => ({
					x: e.x - n * N / v.width,
					y: e.y - r * M / v.height
				})), g.current = !0);
			},
			onPointerUp: (e) => {
				h.current.delete(e.pointerId), _.current = 0, window.setTimeout(() => {
					g.current = !1;
				}, 0);
			},
			onPointerCancel: (e) => {
				h.current.delete(e.pointerId), _.current = 0;
			},
			onWheel: (e) => {
				e.deltaY !== 0 && x(e.deltaY > 0);
			},
			children: [
				/* @__PURE__ */ f("defs", { children: /* @__PURE__ */ f("marker", {
					id: `r52-arrow-${e.mapId}`,
					markerWidth: "8",
					markerHeight: "8",
					refX: "5",
					refY: "4",
					orient: "auto",
					markerUnits: "userSpaceOnUse",
					children: /* @__PURE__ */ f("path", {
						d: "M 0 0 L 8 4 L 0 8 Z",
						fill: "var(--color-cryptid-ink)"
					})
				}) }),
				b ? /* @__PURE__ */ f("rect", {
					x: "0",
					y: "0",
					width: Q.width,
					height: Q.height,
					rx: "20",
					className: "r52-map-floor"
				}) : null,
				I.filter((e) => b || e.move).map((r) => {
					let i = !!r.move, a = t?.to === r.to && t.via === r.via && i, o = ft(r.edge.doors, !!r.move?.floodedPath), s = Math.max(40, o.length * 15 + 16);
					return /* @__PURE__ */ p("g", {
						className: `r52-route ${i ? "is-legal" : ""} ${a ? "is-picked" : ""}`,
						children: [
							/* @__PURE__ */ f("path", {
								d: r.path,
								className: "r52-route-bed"
							}),
							/* @__PURE__ */ f("path", {
								d: r.path,
								className: "r52-route-line",
								markerEnd: r.edge.directed ? `url(#r52-arrow-${e.mapId})` : void 0
							}),
							i ? /* @__PURE__ */ f("path", {
								d: r.path,
								className: "r52-route-hit",
								onClick: () => L(r.to, r.via)
							}) : null,
							/* @__PURE__ */ p("g", {
								transform: `translate(${r.midX}, ${r.midY})`,
								className: i ? "r52-gate is-legal" : "r52-gate",
								role: i ? "button" : void 0,
								tabIndex: i ? 0 : void 0,
								"aria-label": i ? `${n(r.to)} ${o}` : void 0,
								onClick: i ? () => L(r.to, r.via) : void 0,
								onKeyDown: i ? (e) => {
									(e.key === "Enter" || e.key === " ") && (e.preventDefault(), L(r.to, r.via));
								} : void 0,
								children: [/* @__PURE__ */ f("rect", {
									x: -s / 2,
									y: "-21",
									width: s,
									height: "42",
									rx: "10"
								}), /* @__PURE__ */ f("text", {
									textAnchor: "middle",
									dominantBaseline: "middle",
									children: o
								})]
							})
						]
					}, r.index);
				}),
				u.rooms.filter((t) => b || t.id === e.room || I.some((e) => e.move && e.to === t.id)).map((r) => {
					let i = d[r.id], a = r.id === e.room, o = I.some((e) => e.move && e.to === r.id), s = t?.to === r.id, c = e.flooded.includes(r.id), l = e.candles.includes(r.id);
					return /* @__PURE__ */ p("g", {
						transform: `translate(${i[0]}, ${i[1]})`,
						className: `r52-room ${a ? "is-current" : ""} ${o ? "is-reachable" : ""} ${s ? "is-picked" : ""} ${c ? "is-flooded" : ""}`,
						role: o ? "button" : void 0,
						tabIndex: o ? 0 : void 0,
						"aria-label": n(r.id),
						onClick: o ? () => {
							let e = I.find((e) => e.move && e.to === r.id);
							e && L(e.to, e.via);
						} : void 0,
						onKeyDown: o ? (e) => {
							if (e.key === "Enter" || e.key === " ") {
								e.preventDefault();
								let t = I.find((e) => e.move && e.to === r.id);
								t && L(t.to, t.via);
							}
						} : void 0,
						children: [
							/* @__PURE__ */ f("title", { children: n(r.id) }),
							/* @__PURE__ */ f("rect", {
								x: "-66",
								y: "-34",
								width: "132",
								height: "68",
								rx: r.kind === "start" ? 30 : 9
							}),
							/* @__PURE__ */ f("circle", {
								cx: "-45",
								cy: "-12",
								r: "14",
								className: "r52-room-mark"
							}),
							/* @__PURE__ */ f("text", {
								x: "-45",
								y: "-11",
								className: "r52-room-glyph",
								dominantBaseline: "middle",
								textAnchor: "middle",
								children: dt[r.kind] ?? "◆"
							}),
							/* @__PURE__ */ f("text", {
								x: "0",
								y: "11",
								className: "r52-room-name",
								textAnchor: "middle",
								children: pt(n(r.id))
							}),
							a ? /* @__PURE__ */ p("g", {
								className: "r52-token",
								children: [/* @__PURE__ */ f("circle", {
									cx: "51",
									cy: "-27",
									r: "18"
								}), /* @__PURE__ */ f("text", {
									x: "51",
									y: "-27",
									dominantBaseline: "middle",
									textAnchor: "middle",
									children: "●"
								})]
							}) : null,
							l ? /* @__PURE__ */ f("text", {
								x: "51",
								y: "-23",
								className: "r52-room-state",
								textAnchor: "middle",
								children: "✧"
							}) : null,
							c ? /* @__PURE__ */ f("text", {
								x: "48",
								y: "29",
								className: "r52-room-state",
								textAnchor: "middle",
								children: "≈"
							}) : null
						]
					}, r.id);
				})
			]
		}), /* @__PURE__ */ p("div", {
			className: "r52-map-controls",
			children: [/* @__PURE__ */ f("button", {
				type: "button",
				className: "btn-quiet",
				onClick: () => x((e) => !e),
				children: b ? l : c
			}), /* @__PURE__ */ f("button", {
				type: "button",
				className: "btn-quiet",
				onClick: () => {
					x(!1), ee({
						x: 0,
						y: 0
					});
				},
				"aria-label": l,
				children: "◎"
			})]
		})]
	});
}
//#endregion
//#region src/games/realms52/view-player.tsx
var ht = [
	"♣",
	"♠",
	"♥",
	"♦"
], gt = [
	"",
	"A",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"10",
	"J",
	"Q",
	"K"
], $ = (e) => `${ht[S(e)]}${gt[x(e)]}`, _t = (e) => S(e) >= 2, vt = {
	m1: {
		start: "games.realms52.rM1Start",
		library: "games.realms52.rM1Library",
		cloaked: "games.realms52.rM1Cloaked",
		merchant: "games.realms52.rM1Merchant",
		statue: "games.realms52.rM1Statue",
		stairs: "games.realms52.rM1Stairs",
		springW: "games.realms52.rM1SpringW",
		springE: "games.realms52.rM1SpringE",
		springS: "games.realms52.rM1SpringS",
		chest: "games.realms52.rM1Chest",
		vision: "games.realms52.rM1Vision",
		wounded: "games.realms52.rM1Wounded",
		wall: "games.realms52.rM1Wall",
		flood: "games.realms52.rM1Flood",
		goblin: "games.realms52.rM1Goblin",
		lizard: "games.realms52.rM1Lizard",
		stash: "games.realms52.rM1Stash",
		traveller: "games.realms52.rM1Traveller",
		jailer: "games.realms52.rM1Jailer",
		boss: "games.realms52.rM1Boss"
	},
	m2: {
		start: "games.realms52.rM2Start",
		tombA: "games.realms52.rM2TombA",
		tombB: "games.realms52.rM2TombB",
		tombC: "games.realms52.rM2TombC",
		strangerN: "games.realms52.rM2StrangerN",
		strangerC: "games.realms52.rM2StrangerC",
		strangerS: "games.realms52.rM2StrangerS",
		cairnC: "games.realms52.rM2CairnC",
		cairnD: "games.realms52.rM2CairnD",
		cairnS: "games.realms52.rM2CairnS",
		cairnH: "games.realms52.rM2CairnH",
		shrineE: "games.realms52.rM2ShrineE",
		shrineW: "games.realms52.rM2ShrineW",
		warrior: "games.realms52.rM2Warrior",
		witch: "games.realms52.rM2Witch",
		chest2: "games.realms52.rM2Chest2",
		sapling: "games.realms52.rM2Sapling",
		springW: "games.realms52.rM2SpringW",
		springS: "games.realms52.rM2SpringS",
		boss: "games.realms52.rM2Boss"
	},
	m3: {
		start: "games.realms52.rM3Start",
		gearC: "games.realms52.rM3GearC",
		gearD: "games.realms52.rM3GearD",
		gearH: "games.realms52.rM3GearH",
		gearS: "games.realms52.rM3GearS",
		rats: "games.realms52.rM3Rats",
		pendTL: "games.realms52.rM3PendTL",
		pendML: "games.realms52.rM3PendML",
		pendMR: "games.realms52.rM3PendMR",
		scrap: "games.realms52.rM3Scrap",
		escapement: "games.realms52.rM3Escapement",
		collector: "games.realms52.rM3Collector",
		bigHand: "games.realms52.rM3BigHand",
		smallHand: "games.realms52.rM3SmallHand",
		magic: "games.realms52.rM3Magic",
		note: "games.realms52.rM3Note",
		springL: "games.realms52.rM3SpringL",
		springR: "games.realms52.rM3SpringR",
		boss: "games.realms52.rM3Boss"
	},
	m4: {
		start: "games.realms52.rM4Start",
		boss: "games.realms52.rM4Boss",
		apse: "games.realms52.rM4Apse",
		choirBB: "games.realms52.rM4ChoirBB",
		choirAA: "games.realms52.rM4ChoirAA",
		chapelH: "games.realms52.rM4ChapelH",
		chapelS: "games.realms52.rM4ChapelS",
		chapelD: "games.realms52.rM4ChapelD",
		chapelC: "games.realms52.rM4ChapelC",
		spring: "games.realms52.rM4Spring",
		grin: "games.realms52.rM4Grin",
		roar: "games.realms52.rM4Roar",
		cloister: "games.realms52.rM4Cloister",
		transeptW: "games.realms52.rM4TranseptW",
		transeptE: "games.realms52.rM4TranseptE",
		nave: "games.realms52.rM4Nave",
		hall: "games.realms52.rM4Hall"
	}
}, yt = {
	goblin: "games.realms52.eGoblin",
	ghoul: "games.realms52.eGhoul",
	lizard: "games.realms52.eLizard",
	wight: "games.realms52.eWight",
	wolf: "games.realms52.eWolf",
	bear: "games.realms52.eBear",
	viper: "games.realms52.eViper",
	willowisp: "games.realms52.eWillowisp",
	gnome: "games.realms52.eGnome",
	golem: "games.realms52.eGolem",
	knight: "games.realms52.eKnight",
	bellringer: "games.realms52.eBellringer",
	gargoyle: "games.realms52.eGargoyle",
	monk: "games.realms52.eMonk",
	angel: "games.realms52.eAngel",
	nixie: "games.realms52.eNixie"
}, bt = {
	0: "games.realms52.formC",
	1: "games.realms52.formS",
	2: "games.realms52.formH",
	3: "games.realms52.formD"
}, xt = {
	item: "games.realms52.slotItem",
	equip: "games.realms52.slotEquip",
	loot: "games.realms52.slotLoot",
	torch: "games.realms52.slotTorch"
}, St = {
	wound: "games.realms52.trackWound",
	parry: "games.realms52.trackParry",
	refresh1: "games.realms52.trackRefresh1",
	refresh2: "games.realms52.trackRefresh2",
	dim: "games.realms52.trackDim",
	clockUp: "games.realms52.trackClockUp",
	clockDown: "games.realms52.trackClockDown",
	flood: "games.realms52.trackFlood"
};
function Ct(e) {
	l();
	let t = c(), n = e.public, r = (t) => e.send(t), [i, a] = o({ k: "none" }), [s, m] = o([]), [h, g] = o(null), [_, v] = o("equipment"), [y, b] = o(null), [ee, C] = o(!1), w = e.review ? null : n.pending, E = () => {
		a({ k: "none" }), m([]), g(null), b(null);
	}, O = `${n.room}|${n.combat ? "c" : ""}${n.combat?.battleCard ?? ""}|${w?.kind ?? ""}|${n.phase}`, [k, te] = o(O);
	k !== O && (te(O), E(), w?.kind === "pickWound" || w?.kind === "dragonBlood" ? v("wounds") : w?.kind === "collector" ? v("items") : w?.kind === "cursePickLoot" ? v("loot") : v("equipment"));
	let A = (e) => t(vt[n.mapId][e] ?? "games.realms52.rM1Start"), j = (e) => t(yt[T[n.mapId].enemies[e].name]), M = [...n.wounds, ...n.woundsExhausted].reduce((e, t) => e + x(t), 0), N = D[n.char].wounds, P = (e) => {
		let t = n.equipment.find((t) => t.card === e);
		return t ? t.ovrRank ?? x(t.card) + (t.bonus ?? 0) : x(e);
	}, F = (e, t = 99) => m((n) => n.includes(e) ? n.filter((t) => t !== e) : n.length < t ? [...n, e] : n), I = (e, t) => /* @__PURE__ */ p("button", {
		type: "button",
		onClick: t.onClick,
		disabled: t.disabled || !t.onClick,
		className: `r52-playing-card min-h-11 ${t.selected ? "is-selected" : ""} ${t.dimmed ? "is-exhausted" : ""} ${_t(e) ? "is-red" : ""}`,
		children: [/* @__PURE__ */ f("strong", { children: $(e) }), t.extra ? /* @__PURE__ */ f("small", { children: t.extra }) : null]
	}, e), L = s.reduce((e, t) => e + P(t), 0), ne = (e) => {
		let t = n.equipment.find((t) => t.card === e);
		if (t) switch (i.k) {
			case "movePay":
			case "challenge":
				!t.exhausted && (i.k !== "movePay" || !i.pay.flat().includes(e)) && F(e);
				return;
			case "attack":
				if (t.exhausted) return;
				i.main === void 0 ? a({
					...i,
					main: e
				}) : e === i.main ? a({
					...i,
					main: void 0
				}) : n.char === "rogue" && a({
					...i,
					extras: i.extras.includes(e) ? i.extras.filter((t) => t !== e) : [...i.extras, e]
				});
				return;
			case "defend":
				t.exhausted || F(e);
				return;
			case "cloak":
				a({
					...i,
					target: e
				});
				return;
			case "poison":
				t.exhausted ? a({
					...i,
					exhaustedCard: e
				}) : a({
					...i,
					ready: e
				});
				return;
			case "shapeshift":
				t.exhausted || (r({
					t: "ability",
					id: "shapeshift",
					card: e
				}), E());
				return;
			case "throwAxe":
				!t.exhausted && S(t.card) === 1 && (r({
					t: "ability",
					id: "throwAxe",
					card: e
				}), E());
				return;
			case "bladeReady":
				t.exhausted && P(e) <= 5 && (r({
					t: "ability",
					id: "bladeReady",
					card: e
				}), E());
				return;
			case "setTorch":
				r({
					t: "setTorch",
					card: e
				}), E();
				return;
			case "brew": {
				if (t.exhausted) return;
				let n = S(t.card);
				n === 3 ? a({
					...i,
					dilute: i.dilute === e ? void 0 : e
				}) : n === 1 && a({
					...i,
					fieldNotes: i.fieldNotes === e ? void 0 : e
				});
				return;
			}
			default: return;
		}
	}, re = /* @__PURE__ */ p("div", {
		className: "r52-top",
		children: [
			/* @__PURE__ */ p("div", {
				className: "r52-top-title",
				children: [/* @__PURE__ */ f("strong", { children: t(`games.realms52.mM${n.mapId[1]}`) }), n.mapId === "m2" ? /* @__PURE__ */ p("span", { children: [
					n.torch?.dimmed ? t("games.realms52.torchDimmed") : t("games.realms52.torch"),
					" ",
					n.torch ? $(n.torch.card) : "—"
				] }) : n.mapId === "m3" ? /* @__PURE__ */ p("span", { children: [
					t("games.realms52.clock"),
					" ",
					n.clock
				] }) : n.mapId === "m4" ? /* @__PURE__ */ p("span", { children: [
					t("games.realms52.candles"),
					" ",
					n.candles.length
				] }) : null]
			}),
			/* @__PURE__ */ p("div", {
				className: "r52-stat",
				children: [/* @__PURE__ */ f("small", { children: t("games.realms52.currentRoom") }), /* @__PURE__ */ f("strong", { children: A(n.room) })]
			}),
			/* @__PURE__ */ p("div", {
				className: "r52-stat",
				children: [/* @__PURE__ */ f("small", { children: t("games.realms52.wounds") }), /* @__PURE__ */ p("strong", {
					className: "font-mono tabular-nums",
					children: [
						M,
						"/",
						N
					]
				})]
			}),
			/* @__PURE__ */ p("div", {
				className: "r52-stat",
				children: [/* @__PURE__ */ f("small", { children: t("games.realms52.deck") }), /* @__PURE__ */ f("strong", {
					className: "font-mono tabular-nums",
					children: n.deckCount
				})]
			})
		]
	}), ie = /* @__PURE__ */ f("div", {
		className: "text-xs opacity-80",
		children: n.log.slice(-6).map((e, n) => {
			let r = { ...e.p ?? {} };
			return typeof r.room == "string" && (r.room = A(r.room)), typeof r.enemy == "number" && (r.enemy = j(r.enemy)), r.reason === "wounds" && (r.reason = t("games.realms52.loseWounds")), r.reason === "deck" && (r.reason = t("games.realms52.loseDeck")), /* @__PURE__ */ f("div", { children: t(e.k, r) }, n);
		})
	});
	if (n.phase !== "play" && !e.review) {
		let e = n.score;
		return /* @__PURE__ */ f("div", {
			className: "r52-screen h-full min-h-0 p-1",
			children: /* @__PURE__ */ f(u, {
				adaptive: !0,
				className: "r52-layout",
				banner: re,
				scroll: !1,
				children: /* @__PURE__ */ p("div", {
					className: "r52-end",
					children: [
						/* @__PURE__ */ f("div", {
							className: "r52-end-medal",
							"aria-hidden": "true",
							children: n.phase === "won" ? "✦" : "◆"
						}),
						/* @__PURE__ */ f("h2", {
							className: "font-display text-2xl font-extrabold",
							children: t(n.phase === "won" ? "games.realms52.winTitle" : "games.realms52.loseTitle")
						}),
						n.loseReason ? /* @__PURE__ */ f("div", {
							className: "plate px-3 py-2 text-sm",
							children: t(n.loseReason === "wounds" ? "games.realms52.loseWounds" : "games.realms52.loseDeck")
						}) : null,
						e ? /* @__PURE__ */ p("div", {
							className: "r52-end-score",
							children: [
								/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("span", { children: t("games.realms52.scoreItems") }), /* @__PURE__ */ f("strong", { children: e.items })] }),
								/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("span", { children: t("games.realms52.scoreLoot") }), /* @__PURE__ */ f("strong", { children: e.loot })] }),
								n.mapId === "m2" ? /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("span", { children: t("games.realms52.scoreBounty") }), /* @__PURE__ */ f("strong", { children: e.bounty })] }) : null,
								n.mapId === "m4" ? /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("span", { children: t("games.realms52.scoreCandles") }), /* @__PURE__ */ f("strong", { children: e.candles })] }) : null,
								/* @__PURE__ */ p("div", {
									className: "r52-end-total",
									children: [/* @__PURE__ */ f("span", { children: t("games.realms52.scoreTotal") }), /* @__PURE__ */ f("strong", { children: e.total })]
								})
							]
						}) : null,
						/* @__PURE__ */ f("div", {
							className: "r52-end-log",
							children: ie
						})
					]
				})
			})
		});
	}
	let R = () => {
		if (!w) return null;
		let e = (e, t, n = !1) => /* @__PURE__ */ f("button", {
			type: "button",
			onClick: () => {
				r({
					t: "choose",
					option: e
				}), E();
			},
			className: n ? "btn-base min-h-11 px-3" : "btn-quiet min-h-11 px-3",
			children: t
		}, t), a = (e) => /* @__PURE__ */ f("div", {
			className: "flex flex-wrap gap-1",
			children: e.map((e) => I(e, { onClick: () => {
				r({
					t: "pick",
					cards: [e]
				}), E();
			} }))
		}), o = (e, n) => /* @__PURE__ */ p("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ f("button", {
				type: "button",
				disabled: s.length === 0 || s.length > e,
				onClick: () => {
					r({
						t: "pick",
						cards: s
					}), E();
				},
				className: "btn-base min-h-11 px-3",
				children: t(n, { n: e })
			}), /* @__PURE__ */ p("span", {
				className: "text-xs",
				children: [
					s.length,
					"/",
					e
				]
			})]
		});
		switch (w.kind) {
			case "reward": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pReward")
				}), /* @__PURE__ */ p("div", {
					className: "flex items-center gap-2",
					children: [
						I(w.card, {}),
						e(0, t("games.realms52.slotItem")),
						e(1, t("games.realms52.slotEquip")),
						e(2, t("games.realms52.slotLoot"))
					]
				})]
			});
			case "keep": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pKeep", { slot: t(xt[w.slots[w.step]]) })
				}), a(w.cards)]
			});
			case "spring": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pSpring")
				}), /* @__PURE__ */ p("div", {
					className: "flex gap-2",
					children: [e(0, t("games.realms52.springRefresh"), !0), e(1, t("games.realms52.springHeal"))]
				})]
			});
			case "curse": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pCurse", { suit: ht[w.suit] })
				}), /* @__PURE__ */ p("div", {
					className: "flex gap-2",
					children: [e(0, t("games.realms52.curseAccept"), !0), e(1, t("games.realms52.cursePotion"))]
				})]
			});
			case "confirmDraw": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pConfirmDraw")
				}), /* @__PURE__ */ p("div", {
					className: "flex flex-wrap items-center gap-1",
					children: [
						w.cards.map((e) => I(e, { onClick: () => {
							r({
								t: "pick",
								cards: [e]
							}), E();
						} })),
						e(0, t("games.realms52.crystalKeep"), !0),
						n.char === "seer" && w.cards.length === 1 ? e(1, t("games.realms52.pSeer")) : null
					]
				})]
			});
			case "twist": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [
					/* @__PURE__ */ f("div", {
						className: "text-sm font-bold",
						children: t("games.realms52.pTwist", { cost: w.cost })
					}),
					/* @__PURE__ */ p("div", {
						className: "text-xs",
						children: [
							t("games.realms52.twistPay"),
							": ",
							L,
							" / ",
							w.cost
						]
					}),
					/* @__PURE__ */ p("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ f("button", {
							type: "button",
							disabled: L < w.cost,
							onClick: () => {
								r({
									t: "pick",
									cards: s
								}), E();
							},
							className: "btn-base min-h-11 px-3",
							children: t("games.realms52.twistPay")
						}), e(0, t("games.realms52.twistLost"))]
					})
				]
			});
			case "merchant": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [
					/* @__PURE__ */ f("div", {
						className: "text-sm font-bold",
						children: t("games.realms52.pMerchant", { n: w.left })
					}),
					/* @__PURE__ */ p("div", {
						className: "text-xs",
						children: [
							t("games.realms52.merchantE2L"),
							": ",
							t("games.realms52.equipment"),
							" / ",
							t("games.realms52.merchantL2E"),
							": ",
							t("games.realms52.loot")
						]
					}),
					e(0, t("games.realms52.merchantDone"), !0)
				]
			});
			case "challenge": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pChallenge")
				}), /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base min-h-11 px-3",
					onClick: () => {
						let e = i.k === "challenge" && i.focusDir !== 0 && s.length ? [s[0], i.focusDir] : void 0;
						r({
							t: "challenge",
							equips: s,
							focus: e
						}), E();
					},
					children: [
						t("games.realms52.challengeSubmit"),
						" (",
						L,
						")"
					]
				})]
			});
			case "cairn": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pCairn", { suit: ht[w.suit] })
				}), e(0, t("games.realms52.skip"))]
			});
			case "collector": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pCollector")
				}), /* @__PURE__ */ p("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ f("button", {
						type: "button",
						disabled: s.length === 0,
						onClick: () => {
							r({
								t: "pick",
								cards: s
							}), E();
						},
						className: "btn-base min-h-11 px-3",
						children: t("games.realms52.confirm")
					}), e(0, t("games.realms52.skip"))]
				})]
			});
			case "discardClock": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pDiscardClock", { delta: w.clockDelta })
				}), e(0, t("games.realms52.skip"))]
			});
			case "chapel": {
				let r = T[n.mapId].rooms.find((e) => e.id === w.room), i = r && r.kind === "chapel" ? r.suit : 0;
				return /* @__PURE__ */ p("div", {
					className: "card flex flex-col gap-2 p-3",
					children: [/* @__PURE__ */ f("div", {
						className: "text-sm font-bold",
						children: t(w.free ? "games.realms52.pChapelFree" : "games.realms52.pChapel", { suit: ht[i] })
					}), /* @__PURE__ */ p("div", {
						className: "flex gap-2",
						children: [w.free ? e(1, t("games.realms52.chapelLight"), !0) : null, e(0, t("games.realms52.skip"))]
					})]
				});
			}
			case "pickExhaust": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pPickExhaust", { n: w.n })
				}), o(w.n, "games.realms52.confirm")]
			});
			case "pickRefresh": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pPickRefresh", { n: w.n })
				}), o(w.n, "games.realms52.confirm")]
			});
			case "pickWound": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pPickWound", { n: w.max })
				}), o(w.max, "games.realms52.confirm")]
			});
			case "transept1": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t(w.room === "transeptW" ? "games.realms52.pTranseptW" : "games.realms52.pTranseptE")
				}), /* @__PURE__ */ p("div", {
					className: "flex gap-2",
					children: [w.room === "transeptW" ? e(0, t("games.realms52.springHeal")) : null, e(1, t("games.realms52.springRefresh"), !0)]
				})]
			});
			case "transept2": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pTransept2")
				}), /* @__PURE__ */ p("div", {
					className: "flex flex-wrap gap-2",
					children: [
						e(0, t("games.realms52.transeptExhaust")),
						e(1, t("games.realms52.transeptHurt")),
						e(2, t("games.realms52.transeptStay"), !0)
					]
				})]
			});
			case "dragonBlood": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pDragonBlood")
				}), /* @__PURE__ */ p("button", {
					type: "button",
					disabled: s.length !== 2,
					onClick: () => {
						r({
							t: "pick",
							cards: s
						}), E();
					},
					className: "btn-base min-h-11 px-3",
					children: [
						t("games.realms52.confirm"),
						" (",
						s.length,
						"/2)"
					]
				})]
			});
			case "fuse": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pFuse")
				}), /* @__PURE__ */ p("div", {
					className: "flex items-center gap-2",
					children: [I(w.card, {}), e(0, t("games.realms52.fuseSkip"))]
				})]
			});
			case "collect": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pCollect")
				}), /* @__PURE__ */ p("div", {
					className: "flex items-center gap-2",
					children: [
						I(w.card, {}),
						e(1, t("games.realms52.collectYes"), !0),
						e(0, t("games.realms52.collectNo"))
					]
				})]
			});
			case "scavengePick": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [
					/* @__PURE__ */ f("div", {
						className: "text-sm font-bold",
						children: t("games.realms52.pScavenge")
					}),
					a(n.combat?.battleLog ?? []),
					e(0, t("games.realms52.scavengeSkip"))
				]
			});
			case "molePick": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pMole")
				}), /* @__PURE__ */ f("div", {
					className: "flex gap-2",
					children: (w.cards ?? []).map((e, t) => I(e, { onClick: () => {
						r({
							t: "choose",
							option: t
						}), E();
					} }))
				})]
			});
			case "seerPick": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pSeer")
				}), a(w.top3)]
			});
			case "hunterBottom": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pHunterBottom")
				}), a(w.cards)]
			});
			case "cloister": return /* @__PURE__ */ p("div", {
				className: "card flex flex-col gap-2 p-3",
				children: [/* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pCloister")
				}), /* @__PURE__ */ p("div", {
					className: "flex gap-2",
					children: [e(1, t("games.realms52.cloisterAgain"), !0), e(0, t("games.realms52.skip"))]
				})]
			});
			case "cursePickLoot":
			case "cursePickSuit":
			case "pickDiscard": return /* @__PURE__ */ f("div", {
				className: "card flex flex-col gap-2 p-3",
				children: /* @__PURE__ */ f("div", {
					className: "text-sm font-bold",
					children: t("games.realms52.pCurse", { suit: "" })
				})
			});
			default: return null;
		}
	}, z = () => {
		let e = n.combat;
		if (!e) return null;
		let o = i.k === "attack" && i.main !== void 0 ? (P(i.main) + i.focusDir + (n.char === "druid" && n.form === 1 ? 5 : 0) + i.extras.length * 2) * (i.bloodRage === void 0 ? 1 : 2) : 0, c = Math.max(0, o - e.blocked), l = Math.max(0, e.hp - c);
		return /* @__PURE__ */ p("div", {
			className: "r52-combat-card card flex flex-col gap-2 p-3",
			children: [
				/* @__PURE__ */ p("div", {
					className: "r52-combat-stage",
					children: [/* @__PURE__ */ p("div", {
						className: "r52-enemy-emblem",
						"aria-hidden": "true",
						children: [/* @__PURE__ */ f("span", { children: ht[e.enemySuit] }), /* @__PURE__ */ f("small", { children: e.rank })]
					}), /* @__PURE__ */ p("div", {
						className: "r52-combat-readout",
						children: [
							/* @__PURE__ */ p("strong", { children: [j(e.enemySuit), e.boss ? ` · ${t("games.realms52.bossFight")}` : ""] }),
							/* @__PURE__ */ f("span", {
								className: "font-mono tabular-nums",
								children: t("games.realms52.enemyHp", {
									hp: e.hp,
									max: e.maxHp
								})
							}),
							/* @__PURE__ */ f("div", {
								className: "h-6 overflow-hidden rounded border-2 border-cryptid-ink bg-cryptid-paper",
								role: "progressbar",
								"aria-valuenow": e.hp,
								"aria-valuemin": 0,
								"aria-valuemax": e.maxHp,
								children: /* @__PURE__ */ f("div", {
									className: "h-full bg-cryptid-gold transition-[width] duration-150",
									style: { width: `${Math.max(0, e.hp / e.maxHp * 100)}%` }
								})
							}),
							/* @__PURE__ */ p("div", {
								className: "flex flex-wrap gap-1 text-xs",
								children: [
									e.hidden ? /* @__PURE__ */ f("span", {
										className: "plate px-1",
										children: t("games.realms52.enemyHidden")
									}) : null,
									e.blocked > 0 ? /* @__PURE__ */ f("span", {
										className: "plate px-1",
										children: t("games.realms52.enemyBlocked", { n: e.blocked })
									}) : null,
									e.defended > 0 ? /* @__PURE__ */ f("span", {
										className: "plate px-1",
										children: t("games.realms52.youDefended", { n: e.defended })
									}) : null,
									e.windup.length ? /* @__PURE__ */ p("span", {
										className: "plate px-1",
										children: [
											t("games.realms52.windupZone"),
											": ",
											e.windup.map($).join(" ")
										]
									}) : null
								]
							})
						]
					})]
				}),
				/* @__PURE__ */ p("div", {
					className: "r52-battle-strip",
					children: [/* @__PURE__ */ f("span", { children: t("games.realms52.battleCard") }), e.battleCard === null ? /* @__PURE__ */ f("div", {
						className: "r52-card-back",
						children: "✦"
					}) : I(e.battleCard, {})]
				}),
				i.k === "attack" && i.main !== void 0 ? /* @__PURE__ */ p("div", {
					className: "plate px-2 py-1 text-xs font-bold",
					children: [t(n.char === "rogue" ? "games.realms52.attackPreviewBase" : "games.realms52.attackPreview", {
						damage: c,
						hp: l
					}), T[n.mapId].hpTrack[l] && n.char !== "rogue" ? ` · ${t("games.realms52.trackEffect")}: ${t(St[T[n.mapId].hpTrack[l]])}` : ""]
				}) : null,
				i.k === "defend" ? /* @__PURE__ */ f("div", {
					className: "plate px-2 py-1 text-xs font-bold",
					children: t("games.realms52.defendPreview", { n: L + (i.focusDir !== 0 && s.length ? i.focusDir : 0) })
				}) : null,
				/* @__PURE__ */ f("div", {
					className: "r52-combat-actions flex flex-wrap gap-2",
					children: e.battleCard === null ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-base min-h-12 px-4",
						onClick: () => r({ t: "reveal" }),
						children: t("games.realms52.reveal")
					}), n.char === "tinkerer" && !e.used.includes("scavenge") && n.discardCount > 0 ? /* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-quiet min-h-12 px-3",
						onClick: () => r({
							t: "ability",
							id: "scavenge"
						}),
						children: t("games.realms52.abScavenge")
					}) : null] }) : e.acted ? null : /* @__PURE__ */ p(d, { children: [
						/* @__PURE__ */ f("button", {
							type: "button",
							className: i.k === "attack" ? "btn-base min-h-12 px-4" : "btn-quiet min-h-12 px-4",
							onClick: () => {
								E(), v("equipment"), a({
									k: "attack",
									extras: [],
									focusDir: 0
								});
							},
							children: t("games.realms52.attack")
						}),
						/* @__PURE__ */ f("button", {
							type: "button",
							className: i.k === "defend" ? "btn-base min-h-12 px-4" : "btn-quiet min-h-12 px-4",
							onClick: () => {
								E(), v("equipment"), a({
									k: "defend",
									focusDir: 0
								});
							},
							children: t("games.realms52.defend")
						}),
						/* @__PURE__ */ f("button", {
							type: "button",
							className: "btn-quiet min-h-12 px-4",
							onClick: () => r({ t: "rest" }),
							children: t("games.realms52.rest")
						}),
						n.char === "barbarian" && e.rank !== "C" && !e.used.includes("throwAxe") ? /* @__PURE__ */ f("button", {
							type: "button",
							className: i.k === "throwAxe" ? "btn-base min-h-12 px-4" : "btn-quiet min-h-12 px-4",
							onClick: () => {
								E(), v("equipment"), a({ k: "throwAxe" });
							},
							children: t("games.realms52.abThrowAxe")
						}) : null
					] })
				}),
				i.k === "attack" ? /* @__PURE__ */ p("div", {
					className: "flex flex-col gap-1 text-xs",
					children: [
						/* @__PURE__ */ p("div", { children: [t("games.realms52.attackPick"), n.char === "rogue" ? ` · ${t("games.realms52.comboExtras")}` : ""] }),
						n.char === "fallen" && e.rank !== "C" && !e.used.includes("bloodRage") && n.wounds.length ? /* @__PURE__ */ p("label", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ f("input", {
								type: "checkbox",
								checked: i.bloodRage !== void 0,
								onChange: (e) => a({
									...i,
									bloodRage: e.target.checked ? n.wounds[0] : void 0
								})
							}), t("games.realms52.bloodRage")]
						}) : null,
						n.char === "seer" && i.main !== void 0 && !n.flags.focusCombat ? /* @__PURE__ */ p("div", {
							className: "flex gap-1",
							children: [[
								-1,
								0,
								1
							].map((e) => /* @__PURE__ */ f("button", {
								type: "button",
								className: i.focusDir === e ? "btn-base min-h-11 px-2" : "btn-quiet min-h-11 px-2",
								onClick: () => a({
									...i,
									focusDir: e
								}),
								children: e === 0 ? "±0" : e > 0 ? "+1" : "-1"
							}, e)), /* @__PURE__ */ f("span", { children: t("games.realms52.focusLabel") })]
						}) : null,
						/* @__PURE__ */ f("button", {
							type: "button",
							className: "btn-base min-h-12 px-4",
							disabled: i.main === void 0,
							onClick: () => {
								r({
									t: "attack",
									equip: i.main,
									extras: i.extras.length ? i.extras : void 0,
									bloodRage: i.bloodRage,
									focus: i.focusDir !== 0 && i.main !== void 0 ? [i.main, i.focusDir] : void 0
								}), E();
							},
							children: t("games.realms52.attack")
						})
					]
				}) : null,
				i.k === "defend" ? /* @__PURE__ */ p("div", {
					className: "flex flex-col gap-1 text-xs",
					children: [
						/* @__PURE__ */ p("div", { children: [
							t("games.realms52.defendPick"),
							" (",
							L,
							")"
						] }),
						n.char === "seer" && s.length && !n.flags.focusCombat ? /* @__PURE__ */ p("div", {
							className: "flex gap-1",
							children: [[
								-1,
								0,
								1
							].map((e) => /* @__PURE__ */ f("button", {
								type: "button",
								className: i.focusDir === e ? "btn-base min-h-11 px-2" : "btn-quiet min-h-11 px-2",
								onClick: () => a({
									...i,
									focusDir: e
								}),
								children: e === 0 ? "±0" : e > 0 ? "+1" : "-1"
							}, e)), /* @__PURE__ */ f("span", { children: t("games.realms52.focusLabel") })]
						}) : null,
						/* @__PURE__ */ f("button", {
							type: "button",
							className: "btn-base min-h-12 px-4",
							onClick: () => {
								let e = i.focusDir !== 0 && s.length ? [s[0], i.focusDir] : void 0;
								r({
									t: "defend",
									equips: s,
									focus: e
								}), E();
							},
							children: t("games.realms52.defend")
						})
					]
				}) : null
			]
		});
	}, B = (e) => {
		let t = n.moves.filter((t) => t.to === e.to)[e.via];
		if (!t) return;
		g(e), m([]), b(null), v("equipment");
		let r = !t.floodedPath && n.form !== 3 && t.doors.some((e) => e.t === "cost");
		a(r ? {
			k: "movePay",
			to: e.to,
			via: e.via,
			costCount: t.doors.filter((e) => e.t === "cost").length,
			pay: []
		} : { k: "none" });
	}, V = () => {
		if (n.combat || w || !h) return null;
		let e = n.moves.filter((e) => e.to === h.to)[h.via];
		if (!e) return null;
		let o = e.doors.filter((e) => e.t === "cost"), c = i.k === "movePay" ? i.pay.length : 0, l = o[c]?.n ?? 0, u = L + (i.k === "movePay" && i.focus && s.includes(i.focus[0]) ? i.focus[1] : 0), d = e.floodedPath ? [t("games.realms52.floodedPath")] : e.doors.map((e) => e.t === "cost" ? t("games.realms52.doorCost", { n: e.n }) : e.t === "enemy" ? t("games.realms52.doorEnemy", { rank: e.rank }) : e.t === "torch" ? t("games.realms52.doorTorch", { n: e.n }) : e.t === "twist" ? t("games.realms52.doorTwist") : t("games.realms52.doorFree"));
		return /* @__PURE__ */ p("div", {
			className: "r52-move-preview card flex flex-col gap-1 p-2",
			children: [
				/* @__PURE__ */ p("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ f("strong", {
							className: "min-w-0 flex-1 truncate text-sm",
							children: A(h.to)
						}),
						/* @__PURE__ */ p("span", {
							className: "truncate text-xs font-bold",
							children: [d.join(" · "), o.length > 1 ? ` · ${c + 1}/${o.length}` : ""]
						}),
						/* @__PURE__ */ f("button", {
							type: "button",
							className: "btn-quiet min-h-11 min-w-11",
							onClick: E,
							children: "✕"
						})
					]
				}),
				i.k === "movePay" && n.char === "seer" && s.length ? /* @__PURE__ */ p("div", {
					className: "flex gap-1 text-xs",
					children: [[-1, 1].map((e) => /* @__PURE__ */ f("button", {
						type: "button",
						className: i.focus?.[0] === s[0] && i.focus?.[1] === e ? "btn-base min-h-11 px-2" : "btn-quiet min-h-11 px-2",
						onClick: () => a({
							...i,
							focus: i.focus?.[1] === e ? void 0 : [s[0], e]
						}),
						children: e > 0 ? "+1" : "-1"
					}, e)), /* @__PURE__ */ f("span", { children: t("games.realms52.focusLabel") })]
				}) : null,
				/* @__PURE__ */ p("div", {
					className: "flex items-center gap-2",
					children: [i.k === "movePay" ? /* @__PURE__ */ f("div", {
						className: "plate min-w-0 flex-1 truncate px-2 py-2 font-mono text-xs font-bold tabular-nums",
						children: t("games.realms52.payPreview", {
							n: u,
							cost: l
						})
					}) : /* @__PURE__ */ f("span", {
						className: "min-w-0 flex-1 truncate text-xs",
						children: t("games.realms52.moveHere")
					}), /* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-base min-h-12 px-4",
						disabled: i.k === "movePay" && (s.length === 0 || u < l),
						onClick: () => {
							if (i.k === "movePay") {
								let e = [...i.pay, s];
								if (e.length < o.length) {
									m([]), a({
										...i,
										pay: e
									});
									return;
								}
								r({
									t: "move",
									to: h.to,
									pay: e,
									focus: i.focus,
									via: h.via
								});
							} else r({
								t: "move",
								to: h.to,
								pay: [],
								via: h.via
							});
							E();
						},
						children: t("games.realms52.moveHere")
					})]
				})
			]
		});
	}, H = (e) => {
		let t = S(e);
		return t === 0 ? n.char === "tinkerer" ? "games.realms52.itemCTinkerer" : "games.realms52.itemC" : t === 1 ? n.char === "hunter" ? "games.realms52.itemSHunter" : n.char === "rogue" ? "games.realms52.itemSRogue" : "games.realms52.itemS" : t === 2 ? n.char === "fallen" ? "games.realms52.itemHFallen" : "games.realms52.itemH" : n.char === "alchemist" ? "games.realms52.itemDAlchemist" : "games.realms52.itemD";
	}, U = (e) => {
		let t = S(e);
		return t === 0 ? n.char === "tinkerer" ? "games.realms52.itemCTinkererDesc" : "games.realms52.itemCDesc" : t === 1 ? n.char === "hunter" ? "games.realms52.itemSHunterDesc" : n.char === "rogue" ? "games.realms52.itemSRogueDesc" : "games.realms52.itemSDesc" : t === 2 ? n.char === "fallen" ? "games.realms52.itemHFallenDesc" : "games.realms52.itemHDesc" : n.char === "alchemist" ? "games.realms52.itemDAlchemistDesc" : "games.realms52.itemDDesc";
	}, ae = (e) => {
		let t = S(e);
		return t === 0 ? n.char === "tinkerer" ? "games.realms52.itemCTinkererDetail" : "games.realms52.itemCDetail" : t === 1 ? n.char === "hunter" ? "games.realms52.itemSHunterDetail" : n.char === "rogue" ? "games.realms52.itemSRogueDetail" : "games.realms52.itemSDetail" : t === 2 ? n.char === "fallen" ? "games.realms52.itemHFallenDetail" : "games.realms52.itemHDetail" : n.char === "alchemist" ? "games.realms52.itemDAlchemistDetail" : "games.realms52.itemDDetail";
	}, oe = (e) => {
		let t = S(e);
		if (i.k === "brew") {
			a({
				...i,
				mix: i.mix.includes(e) ? i.mix.filter((t) => t !== e) : i.mix.length < 3 ? [...i.mix, e] : i.mix
			});
			return;
		}
		if (w?.kind === "collector") {
			F(e);
			return;
		}
		if (w?.kind === "pickDiscard" && w.pool === "items") {
			r({
				t: "pick",
				cards: [e]
			}), E();
			return;
		}
		if (w?.kind === "discardClock" && (w.pool === "item" || w.pool === "any")) {
			r({
				t: "pick",
				cards: [e]
			}), E();
			return;
		}
		if (w?.kind === "cairn" && S(e) === w.suit) {
			r({
				t: "pick",
				cards: [e]
			}), E();
			return;
		}
		if (w?.kind === "chapel" && !w.free) {
			r({
				t: "pick",
				cards: [e]
			}), E();
			return;
		}
		if (!w && t !== 3) {
			if (t === 1 && n.char !== "hunter" && n.char !== "rogue") {
				E(), v("equipment"), a({
					k: "cloak",
					item: e
				});
				return;
			}
			if (t === 1 && n.char === "rogue") {
				E(), v("equipment"), a({
					k: "poison",
					item: e
				});
				return;
			}
			if (t === 2 && n.char !== "fallen") {
				E(), a({
					k: "itemH",
					item: e
				}), v("wounds");
				return;
			}
			r({
				t: "useItem",
				card: e
			});
		}
	}, W = (e) => /* @__PURE__ */ p("button", {
		type: "button",
		className: `r52-playing-card r52-item-card ${_t(e) ? "is-red" : ""} ${i.k === "brew" && i.mix.includes(e) ? "is-selected" : ""}`,
		onClick: () => w || i.k === "brew" ? oe(e) : b(e),
		children: [/* @__PURE__ */ p("strong", { children: [
			$(e),
			" · ",
			t(H(e))
		] }), /* @__PURE__ */ f("span", { children: t(U(e)) })]
	}, e), se = (e) => {
		if (w?.kind === "merchant") {
			r({
				t: "pick",
				cards: [e],
				pool: "loot"
			});
			return;
		}
		if (w?.kind === "cursePickLoot") {
			r({
				t: "pick",
				cards: [e]
			}), E();
			return;
		}
		if (w?.kind === "cairn" && S(e) === w.suit) {
			r({
				t: "pick",
				cards: [e]
			}), E();
			return;
		}
		if (w?.kind === "chapel" && !w.free) {
			r({
				t: "pick",
				cards: [e]
			}), E();
			return;
		}
		if (w?.kind === "discardClock" && w.pool === "any") {
			r({
				t: "pick",
				cards: [e]
			}), E();
			return;
		}
	}, G = (e) => {
		if (w?.kind === "merchant") {
			r({
				t: "pick",
				cards: [e],
				pool: "equip"
			});
			return;
		}
		if (w?.kind === "pickExhaust") {
			let t = n.equipment.find((t) => t.card === e);
			t && !t.exhausted && F(e, w.n);
			return;
		}
		if (w?.kind === "pickRefresh") {
			n.equipment.find((t) => t.card === e)?.exhausted && F(e, w.n);
			return;
		}
		if (w?.kind === "pickDiscard" && w.pool === "equip") {
			r({
				t: "pick",
				cards: [e]
			}), E();
			return;
		}
		if (w?.kind === "cursePickSuit") {
			r({
				t: "pick",
				cards: [e]
			}), E();
			return;
		}
		if (w?.kind === "fuse") {
			e !== w.card && (r({
				t: "pick",
				cards: [e]
			}), E());
			return;
		}
		if (w?.kind === "twist") {
			let t = n.equipment.find((t) => t.card === e);
			t && !t.exhausted && F(e);
			return;
		}
		if (w?.kind === "challenge") {
			let t = n.equipment.find((t) => t.card === e);
			t && !t.exhausted && (F(e), i.k !== "challenge" && a({
				k: "challenge",
				focusDir: 0
			}));
			return;
		}
		if (w?.kind === "cairn" && S(e) === w.suit) {
			r({
				t: "pick",
				cards: [e]
			}), E();
			return;
		}
		if (w?.kind === "chapel" && !w.free) {
			r({
				t: "pick",
				cards: [e]
			}), E();
			return;
		}
		if (w?.kind === "discardClock" && (w.pool === "equip" || w.pool === "any")) {
			r({
				t: "pick",
				cards: [e]
			}), E();
			return;
		}
		w || ne(e);
	}, ce = (e) => {
		if (w?.kind === "pickWound") {
			F(e, w.max);
			return;
		}
		if (w?.kind === "dragonBlood") {
			F(e, 2);
			return;
		}
		if (i.k === "itemH") {
			r({
				t: "useItem",
				card: i.item,
				params: { wound: e }
			}), E();
			return;
		}
		if (i.k === "attack" && n.char === "fallen") {
			a({
				...i,
				bloodRage: i.bloodRage === e ? void 0 : e
			});
			return;
		}
	}, le = () => i.k === "cloak" ? /* @__PURE__ */ p("div", {
		className: "card flex flex-col gap-2 p-3 text-sm",
		children: [/* @__PURE__ */ f("div", { children: t("games.realms52.itemSDesc") }), /* @__PURE__ */ p("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ p("select", {
					className: "min-h-11 rounded border-2 border-ink bg-white px-2",
					value: i.rank ?? "",
					onChange: (e) => a({
						...i,
						rank: e.target.value ? Number(e.target.value) : void 0,
						suit: void 0
					}),
					children: [/* @__PURE__ */ f("option", {
						value: "",
						children: "—"
					}), Array.from({ length: 13 }, (e, t) => /* @__PURE__ */ f("option", {
						value: t + 1,
						children: gt[t + 1]
					}, t + 1))]
				}),
				/* @__PURE__ */ p("select", {
					className: "min-h-11 rounded border-2 border-ink bg-white px-2",
					value: i.suit ?? "",
					onChange: (e) => a({
						...i,
						suit: e.target.value === "" ? void 0 : Number(e.target.value),
						rank: void 0
					}),
					children: [/* @__PURE__ */ f("option", {
						value: "",
						children: "—"
					}), ht.map((e, t) => /* @__PURE__ */ f("option", {
						value: t,
						children: e
					}, t))]
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "btn-base min-h-11 px-3",
					disabled: i.target === void 0 || i.rank === void 0 && i.suit === void 0,
					onClick: () => {
						r({
							t: "useItem",
							card: i.item,
							params: {
								equip: i.target,
								rank: i.rank,
								suit: i.suit
							}
						}), E();
					},
					children: t("games.realms52.confirm")
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "btn-quiet min-h-11 px-3",
					onClick: E,
					children: "✕"
				})
			]
		})]
	}) : i.k === "poison" ? /* @__PURE__ */ p("div", {
		className: "card flex flex-col gap-2 p-3 text-sm",
		children: [/* @__PURE__ */ f("div", { children: t("games.realms52.itemSRogueDesc") }), /* @__PURE__ */ p("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ f("button", {
				type: "button",
				className: "btn-base min-h-11 px-3",
				disabled: !i.ready || !i.exhaustedCard,
				onClick: () => {
					r({
						t: "useItem",
						card: i.item,
						params: {
							ready: i.ready,
							exhausted: i.exhaustedCard
						}
					}), E();
				},
				children: t("games.realms52.confirm")
			}), /* @__PURE__ */ f("button", {
				type: "button",
				className: "btn-quiet min-h-11 px-3",
				onClick: E,
				children: "✕"
			})]
		})]
	}) : i.k === "itemH" ? /* @__PURE__ */ p("div", {
		className: "card flex items-center gap-2 p-3 text-sm",
		children: [/* @__PURE__ */ f("span", { children: t("games.realms52.itemHDesc") }), /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-quiet min-h-11 px-3",
			onClick: E,
			children: "✕"
		})]
	}) : i.k === "brew" ? /* @__PURE__ */ p("div", {
		className: "card flex flex-col gap-2 p-3 text-sm",
		children: [/* @__PURE__ */ p("div", { children: [
			t("games.realms52.brew"),
			": ",
			i.mix.map($).join(" ")
		] }), /* @__PURE__ */ p("div", {
			className: "flex flex-wrap gap-2",
			children: [
				i.dilute && i.mix.length ? /* @__PURE__ */ p("label", {
					className: "flex items-center gap-1 text-xs",
					children: [t("games.realms52.slotItem"), /* @__PURE__ */ p("select", {
						className: "min-h-11 rounded border-2 border-ink bg-white px-2",
						value: i.keep ?? "",
						onChange: (e) => a({
							...i,
							keep: e.target.value === "" ? void 0 : Number(e.target.value)
						}),
						children: [/* @__PURE__ */ f("option", {
							value: "",
							children: "—"
						}), i.mix.map((e) => /* @__PURE__ */ f("option", {
							value: e,
							children: $(e)
						}, e))]
					})]
				}) : null,
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "btn-base min-h-11 px-3",
					disabled: i.mix.length === 0,
					onClick: () => {
						r({
							t: "brew",
							mix: i.mix,
							dilute: i.dilute,
							fieldNotes: i.fieldNotes,
							keep: i.dilute ? i.keep : void 0
						}), E();
					},
					children: t("games.realms52.confirm")
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "btn-quiet min-h-11 px-3",
					onClick: E,
					children: "✕"
				})
			]
		})]
	}) : null, K = {
		equipment: n.equipment.length,
		items: n.items.length,
		loot: n.loot.length,
		wounds: n.wounds.length + n.woundsExhausted.length
	}, ue = {
		equipment: "games.realms52.equipment",
		items: "games.realms52.items",
		loot: "games.realms52.loot",
		wounds: "games.realms52.wounds"
	}, de = _ === "equipment" ? n.equipment.map((n) => {
		let r = n.ovrSuit ?? S(n.card), a = s.includes(n.card) || i.k === "attack" && (i.main === n.card || i.extras.includes(n.card));
		return /* @__PURE__ */ p("button", {
			type: "button",
			disabled: e.review,
			onClick: () => G(n.card),
			className: `r52-playing-card ${r >= 2 ? "is-red" : ""} ${a ? "is-selected" : ""} ${n.exhausted || i.k === "movePay" && i.pay.flat().includes(n.card) ? "is-exhausted" : ""}`,
			"aria-pressed": a,
			children: [/* @__PURE__ */ p("strong", { children: [
				ht[r],
				" ",
				P(n.card)
			] }), /* @__PURE__ */ p("small", { children: [n.bonus ? `+${n.bonus} · ` : "", n.exhausted ? t("games.realms52.exhausted") : t("games.realms52.equipment")] })]
		}, n.card);
	}) : _ === "items" ? n.items.map(W) : _ === "loot" ? n.loot.map((t) => I(t, {
		disabled: e.review,
		onClick: () => se(t)
	})) : [...n.wounds, ...n.woundsExhausted].map((t) => I(t, {
		disabled: e.review,
		onClick: () => ce(t),
		selected: s.includes(t),
		dimmed: n.woundsExhausted.includes(t)
	})), q = y === null ? null : /* @__PURE__ */ p("div", {
		className: "card flex flex-col gap-2 p-3",
		children: [
			/* @__PURE__ */ p("strong", { children: [
				$(y),
				" · ",
				t(H(y))
			] }),
			/* @__PURE__ */ f("p", {
				className: "text-sm",
				children: t(ae(y))
			}),
			/* @__PURE__ */ p("div", {
				className: "flex gap-2",
				children: [S(y) !== 3 && !e.review ? /* @__PURE__ */ f("button", {
					type: "button",
					className: "btn-base min-h-11 px-3",
					onClick: () => {
						let e = y;
						b(null), oe(e);
					},
					children: t("games.realms52.useItem")
				}) : null, /* @__PURE__ */ f("button", {
					type: "button",
					className: "btn-quiet min-h-11 px-3",
					onClick: () => b(null),
					children: t("games.realms52.confirm")
				})]
			})
		]
	}), J = w ? R() : q ?? (ee ? /* @__PURE__ */ p("div", {
		className: "card max-h-60 overflow-y-auto p-3",
		children: [ie, /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-quiet mt-2 min-h-11 px-3",
			onClick: () => C(!1),
			children: t("games.realms52.confirm")
		})]
	}) : e.review ? null : le() ?? V());
	return /* @__PURE__ */ f("div", {
		className: "r52-screen h-full min-h-0 p-1",
		children: /* @__PURE__ */ f(u, {
			adaptive: !0,
			className: "r52-layout",
			banner: re,
			scroll: !1,
			children: /* @__PURE__ */ p("div", {
				className: "r52-workspace",
				children: [/* @__PURE__ */ p("div", {
					className: "r52-board",
					children: [n.combat ? null : /* @__PURE__ */ f("div", {
						className: "r52-board-title",
						children: /* @__PURE__ */ f("span", { children: t(`games.realms52.boardM${n.mapId[1]}`) })
					}), n.combat && !e.review ? /* @__PURE__ */ f("div", {
						className: "r52-combat",
						children: z()
					}) : /* @__PURE__ */ f(mt, {
						view: n,
						selected: h,
						roomName: A,
						onSelect: e.review ? g : B,
						overviewLabel: t("games.realms52.overview"),
						focusLabel: t("games.realms52.focusMap")
					})]
				}), /* @__PURE__ */ p("div", {
					className: "r52-controls",
					children: [J ? /* @__PURE__ */ f("div", {
						className: "r52-overlay",
						children: J
					}) : null, /* @__PURE__ */ p("div", {
						className: "r52-tray",
						children: [
							/* @__PURE__ */ f("div", {
								className: "r52-tray-tabs",
								role: "tablist",
								"aria-label": t("games.realms52.inventory"),
								children: [
									"equipment",
									"items",
									"loot",
									"wounds"
								].map((e) => /* @__PURE__ */ p("button", {
									type: "button",
									role: "tab",
									"aria-selected": _ === e,
									onClick: () => v(e),
									children: [
										t(ue[e]),
										" ",
										K[e]
									]
								}, e))
							}),
							/* @__PURE__ */ f("div", {
								className: "r52-tray-cards",
								children: de.length ? de : /* @__PURE__ */ f("div", {
									className: "r52-empty-slot",
									children: t("games.realms52.emptySlot", { slot: t(ue[_]) })
								})
							}),
							/* @__PURE__ */ p("div", {
								className: "r52-tray-actions",
								children: [
									!e.review && !w && !n.combat ? /* @__PURE__ */ f("button", {
										type: "button",
										className: "btn-base bg-cryptid-gold",
										onClick: () => r({ t: "stay" }),
										children: t("games.realms52.transeptStay")
									}) : null,
									!e.review && !w && !n.combat && n.mapId === "m2" ? /* @__PURE__ */ f("button", {
										type: "button",
										className: "btn-quiet",
										onClick: () => {
											E(), v("equipment"), a({ k: "setTorch" });
										},
										children: t("games.realms52.slotTorch")
									}) : null,
									!e.review && !w && !n.combat && n.char === "druid" ? /* @__PURE__ */ f("button", {
										type: "button",
										className: "btn-quiet",
										onClick: () => {
											E(), v("equipment"), a({ k: "shapeshift" });
										},
										children: t("games.realms52.abShapeshift")
									}) : null,
									!e.review && !w && !n.combat && n.char === "rogue" ? /* @__PURE__ */ f("button", {
										type: "button",
										className: "btn-quiet",
										onClick: () => {
											E(), v("equipment"), a({ k: "bladeReady" });
										},
										children: t("games.realms52.abBladeReady")
									}) : null,
									!e.review && !w && n.char === "alchemist" ? /* @__PURE__ */ f("button", {
										type: "button",
										className: "btn-quiet",
										onClick: () => {
											E(), v("items"), a({
												k: "brew",
												mix: []
											});
										},
										children: t("games.realms52.brew")
									}) : null,
									n.form === null ? null : /* @__PURE__ */ f("span", {
										className: "plate px-2 py-2 text-xs font-bold",
										children: t(bt[n.form])
									}),
									n.bounty.length ? /* @__PURE__ */ p("span", {
										className: "plate px-2 py-2 text-xs font-bold",
										children: [
											t("games.realms52.bounty"),
											" ",
											n.bounty.map($).join(" ")
										]
									}) : null,
									n.collection.length ? /* @__PURE__ */ p("span", {
										className: "plate px-2 py-2 text-xs font-bold",
										children: [
											t("games.realms52.collection"),
											" ",
											n.collection.map($).join(" ")
										]
									}) : null,
									/* @__PURE__ */ p("button", {
										type: "button",
										className: "btn-quiet",
										onClick: () => C(!0),
										children: [
											t("games.realms52.deck"),
											" ",
											n.deckCount,
											" · ",
											t("games.realms52.discardPile"),
											" ",
											n.discardCount
										]
									})
								]
							})
						]
					})]
				})]
			})
		})
	});
}
//#endregion
//#region src/games/realms52/endgame-review.tsx
function wt({ board: e, renderResult: t, ...n }) {
	let s = c(), [l, u] = o(!0), [d, h] = o(null), v = a(null), y = a(null), b = a(null);
	r(() => {
		if (!d) return;
		b.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => h(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let x = (e) => {
		h(null), u(e), requestAnimationFrame(() => (e ? v : y).current?.focus({ preventScroll: !0 }));
	}, S = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => h({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => h({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => h({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), ee = {
		...n,
		...S
	};
	return /* @__PURE__ */ p("div", {
		className: "realms52-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ f("div", {
				className: "realms52-endgame-board",
				inert: l,
				children: e
			}),
			/* @__PURE__ */ f("div", {
				className: "realms52-endgame-overlay",
				hidden: !l,
				children: /* @__PURE__ */ p("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), x(!1));
					},
					className: "realms52-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ p("header", {
							className: "realms52-endgame-heading",
							children: [/* @__PURE__ */ p("div", {
								className: "realms52-endgame-brand",
								children: [/* @__PURE__ */ f("span", {
									"aria-hidden": "true",
									children: te.icon
								}), s(te.nameKey)]
							}), /* @__PURE__ */ f("button", {
								type: "button",
								ref: v,
								className: "btn-quiet",
								"aria-label": s("games.realms52.reviewHide"),
								title: s("games.realms52.reviewHide"),
								onClick: () => x(!1),
								children: /* @__PURE__ */ f(g, { size: 19 })
							})]
						}),
						/* @__PURE__ */ f("div", {
							className: "realms52-endgame-result",
							inert: d !== null,
							children: t(ee)
						}),
						d && /* @__PURE__ */ p("div", {
							className: "realms52-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || h(null);
							},
							children: [/* @__PURE__ */ f("button", {
								type: "button",
								ref: b,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									h(null), e();
								},
								children: s(d.label === "again" ? "games.realms52.reviewConfirmAgain" : "games.realms52.reviewConfirmLobby")
							}), /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									h(null), v.current?.focus({ preventScroll: !0 });
								},
								children: s("games.realms52.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "realms52-endgame-toolbar",
				hidden: l,
				children: /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base",
					ref: y,
					onClick: () => x(!0),
					children: [
						/* @__PURE__ */ f(_, { size: 18 }),
						s("games.realms52.reviewShow"),
						/* @__PURE__ */ f(m, { size: 18 })
					]
				})
			})
		]
	});
}
function Tt({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: l, rows: u, renderRowExtra: m, summary: _, navigation: b, content: x, afterRanking: S, scoreUnit: ee, rankOf: C }) {
	let w = c(), T = s((e) => e.locale), [E, D] = o({}), O = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? v(n, T) : e;
	}, k = (t, n) => C?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), A = e.ranking.some((t) => e.scores?.[t] !== void 0), j = (t, n) => /* @__PURE__ */ p("div", {
		className: "realms52-score-identity",
		children: [
			/* @__PURE__ */ p("span", {
				className: "realms52-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ f("span", {
					"aria-label": w("games.realms52.reviewWinner"),
					children: "♛ "
				}), A && k(t, n)]
			}),
			/* @__PURE__ */ p("span", {
				className: "realms52-score-name",
				children: [O(t), t === r && /* @__PURE__ */ f("small", { children: w("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ p("small", {
				className: "realms52-score-autopilot",
				children: [
					/* @__PURE__ */ f(h, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), M = (t) => e.ranking.map((n) => /* @__PURE__ */ f("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ p("div", {
		className: "realms52-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ f(y, {}),
			b,
			/* @__PURE__ */ p("div", {
				className: "realms52-score-body",
				children: [
					_ && /* @__PURE__ */ f("div", {
						className: "realms52-score-summary",
						children: _
					}),
					i !== void 0 && /* @__PURE__ */ f("p", {
						className: "realms52-score-hints",
						children: w("session.hint.usedCount", { n: i })
					}),
					x ?? (u?.length ? /* @__PURE__ */ f("div", {
						className: "realms52-score-table-scroll",
						children: /* @__PURE__ */ p("table", {
							className: "realms52-score-table",
							"aria-label": w(te.nameKey),
							children: [
								/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { scope: "col" }), /* @__PURE__ */ f(d, { children: e.ranking.map((t, n) => /* @__PURE__ */ f("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: j(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ f("tbody", { children: u.map((e, t) => /* @__PURE__ */ p(n, { children: [/* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ p("button", {
										type: "button",
										"aria-expanded": !!E[t],
										onClick: () => D((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ f(g, { size: 15 }), e.label]
									}) : e.label
								}), M(e)] }), E[t] && e.details?.map((e, t) => /* @__PURE__ */ p("tr", {
									className: "realms52-score-sub",
									children: [/* @__PURE__ */ f("th", {
										scope: "row",
										children: e.label
									}), M(e)]
								}, t))] }, t)) }),
								A && /* @__PURE__ */ f("tfoot", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
									scope: "row",
									children: w("games.realms52.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ f("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ f("ol", {
						className: "realms52-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ p("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ p("div", {
								className: "realms52-score-rankline",
								children: [j(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ p("strong", {
									className: "realms52-score-points",
									children: [e.scores[t], ee && /* @__PURE__ */ f("small", { children: ee })]
								})]
							}), m?.(t)]
						}, t))
					})),
					S,
					!!u?.length && m && /* @__PURE__ */ f("div", {
						className: "realms52-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ p("details", { children: [/* @__PURE__ */ f("summary", { children: O(e) }), m(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ p("footer", {
				className: "realms52-score-actions",
				children: [
					l && /* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-quiet",
						onClick: l,
						children: w("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: w("session.result.playAgain")
					}),
					!a && !l && /* @__PURE__ */ f("p", { children: w("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/realms52/endgame-scores.tsx
function Et(e) {
	let t = c(), n = e.public, r = [
		["items", "games.realms52.scoreItems"],
		["loot", "games.realms52.scoreLoot"],
		...n.mapId === "m2" ? [["bounty", "games.realms52.scoreBounty"]] : [],
		...n.mapId === "m4" ? [["candles", "games.realms52.scoreCandles"]] : []
	], i = n.score ? r.map(([e, r]) => ({
		label: t(r),
		value: () => n.score?.[e] ?? "—"
	})) : [];
	return /* @__PURE__ */ f(Tt, {
		...e,
		renderRowExtra: void 0,
		rows: i,
		summary: n.loseReason && /* @__PURE__ */ f("p", { children: t(n.loseReason === "wounds" ? "games.realms52.loseWounds" : "games.realms52.loseDeck") })
	});
}
//#endregion
//#region src/games/realms52/game-over.tsx
function Dt(e) {
	return /* @__PURE__ */ f(Et, { ...e });
}
function Ot(e) {
	return /* @__PURE__ */ f(wt, {
		...e,
		board: /* @__PURE__ */ f(Ct, {
			review: !0,
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ f(Dt, { ...e })
	});
}
//#endregion
//#region src/games/realms52/options.tsx
var kt = {
	m1: "games.realms52.mM1",
	m2: "games.realms52.mM2",
	m3: "games.realms52.mM3",
	m4: "games.realms52.mM4"
}, At = {
	m1: "games.realms52.mM1Desc",
	m2: "games.realms52.mM2Desc",
	m3: "games.realms52.mM3Desc",
	m4: "games.realms52.mM4Desc"
}, jt = {
	barbarian: "games.realms52.cBarbarian",
	seer: "games.realms52.cSeer",
	fallen: "games.realms52.cFallen",
	druid: "games.realms52.cDruid",
	hunter: "games.realms52.cHunter",
	tinkerer: "games.realms52.cTinkerer",
	alchemist: "games.realms52.cAlchemist",
	rogue: "games.realms52.cRogue"
}, Mt = {
	barbarian: "games.realms52.cBarbarianDesc",
	seer: "games.realms52.cSeerDesc",
	fallen: "games.realms52.cFallenDesc",
	druid: "games.realms52.cDruidDesc",
	hunter: "games.realms52.cHunterDesc",
	tinkerer: "games.realms52.cTinkererDesc",
	alchemist: "games.realms52.cAlchemistDesc",
	rogue: "games.realms52.cRogueDesc"
}, Nt = {
	barbarian: "⚔",
	seer: "◉",
	fallen: "◆",
	druid: "✦",
	hunter: "◎",
	tinkerer: "⚙",
	alchemist: "✚",
	rogue: "◇"
}, Pt = {
	m1: "bg-cryptid-mat",
	m2: "bg-cryptid-soft",
	m3: "bg-wz-cream",
	m4: "bg-cn-blue-pale"
};
function Ft({ id: e }) {
	let t = T[e], n = ut[e];
	return /* @__PURE__ */ p("svg", {
		viewBox: `0 0 ${Q.width} ${Q.height}`,
		"aria-hidden": "true",
		className: `h-24 w-full rounded-md border-2 border-cryptid-ink p-1 ${Pt[e]}`,
		children: [t.edges.map((e, t) => /* @__PURE__ */ f("line", {
			x1: n[e.a][0],
			y1: n[e.a][1],
			x2: n[e.b][0],
			y2: n[e.b][1],
			stroke: "var(--color-cryptid-ink)",
			strokeWidth: "14",
			opacity: ".65"
		}, t)), t.rooms.map((e) => /* @__PURE__ */ f("circle", {
			cx: n[e.id][0],
			cy: n[e.id][1],
			r: e.kind === "boss" ? 36 : e.kind === "start" ? 32 : 23,
			fill: e.kind === "boss" ? "var(--color-cryptid-gold)" : "var(--color-surface)",
			stroke: "var(--color-cryptid-ink)",
			strokeWidth: "9"
		}, e.id))]
	});
}
function It({ value: e, onChange: t }) {
	let n = c(), r = P.safeParse(e), i = r.success ? r.data : P.parse(void 0);
	return /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-4 text-cryptid-ink",
		children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("div", {
			className: "section-label",
			children: n("games.realms52.optMap")
		}), /* @__PURE__ */ f("div", {
			className: "grid grid-cols-2 gap-2",
			children: k.map((e) => /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => t({
					...i,
					map: e
				}),
				className: `card relative min-h-12 px-2 py-2 text-left ${i.map === e ? "border-cryptid-gold bg-cryptid-paper" : "bg-surface"}`,
				"data-selected": i.map === e,
				"aria-pressed": i.map === e,
				children: [
					/* @__PURE__ */ f(Ft, { id: e }),
					i.map === e && /* @__PURE__ */ f("i", {
						"aria-hidden": !0,
						className: "absolute right-2 top-2 grid size-5 place-items-center rounded-full border-2 border-ink bg-surface",
						children: /* @__PURE__ */ f("span", { className: "size-2 rounded-full bg-ink" })
					}),
					/* @__PURE__ */ f("div", {
						className: "mt-1 text-sm font-bold",
						children: n(kt[e])
					}),
					/* @__PURE__ */ f("div", {
						className: "text-xs opacity-75",
						children: n(At[e])
					})
				]
			}, e))
		})] }), /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("div", {
			className: "section-label",
			children: n("games.realms52.optChar")
		}), /* @__PURE__ */ f("div", {
			className: "grid grid-cols-2 gap-2",
			children: O.map((e) => /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => t({
					...i,
					char: e
				}),
				className: `card relative min-h-12 px-3 py-2 text-left ${i.char === e ? "border-cryptid-gold bg-cryptid-paper" : "bg-surface"}`,
				"data-selected": i.char === e,
				"aria-pressed": i.char === e,
				children: [
					/* @__PURE__ */ p("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ f("span", {
							className: "flex size-10 shrink-0 items-center justify-center rounded-full border-2 border-cryptid-ink bg-cryptid-gold text-xl",
							"aria-hidden": "true",
							children: Nt[e]
						}), /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("div", {
							className: "text-sm font-bold",
							children: n(jt[e])
						}), /* @__PURE__ */ p("div", {
							className: "text-xs font-mono",
							children: [D[e].wounds, " HP"]
						})] })]
					}),
					i.char === e && /* @__PURE__ */ f("i", {
						"aria-hidden": !0,
						className: "absolute right-2 top-2 grid size-5 place-items-center rounded-full border-2 border-ink bg-surface",
						children: /* @__PURE__ */ f("span", { className: "size-2 rounded-full bg-ink" })
					}),
					/* @__PURE__ */ f("div", {
						className: "mt-1 text-xs opacity-75",
						children: n(Mt[e])
					})
				]
			}, e))
		})] })]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/realms52/entry.tsx
var Lt = {
	definition: lt,
	View: Ct,
	OverView: Ot,
	Options: It,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "52个王国:冒险",
			desc: "纯单人地城爬行:一副扑克牌闯荡四张地图,击败首领并带走战利品",
			rules: "目标:深入地城击败首领,并尽可能多地带走战利品;创伤牌等级合计达到生命上限,或需要抽牌时牌库已空,则冒险失败。\n准备:先抽 2 张牌作为物品,再逐张抽牌作为装备,直到装备等级合计达到 20;期间抽到的 A 先搁置,最后全部洗回牌库。\n回合流程:\n· 沿走廊移动到相邻房间,然后结算该房间的效果。\n· 数字门需耗尽等级合计足够的就绪装备,字母门需先击败对应等级的敌人。\n· 火炬门需要火炬等级达标,扭曲走廊抽牌决定费用。\n战斗:抽 2 张牌,等级高者是敌人(花色决定种类),另 1 张是奖励牌;平局按 ♣>♠>♥>♦ 决胜。\n· 每个战斗回合揭示 1 张战斗卡,敌人的格挡先生效。\n· 然后你选择攻击、防御、使用角色技能或休息,最后敌人按战斗卡花色行动。\n攻击:耗尽 1 张就绪装备,造成其等级点伤害;敌人生命标记的落点若印有符号,立即结算该符号。\n防御:耗尽任意数量就绪装备,按等级合计减免本回合受到的伤害。\n受到伤害时抽牌判定:抽到的牌等级不超过伤害值,则成为创伤牌;幽灵类敌人造成的伤害直接成为创伤。\n奖励牌三选一放置:作为物品、装备或战利品。\n物品效果:\n· ♣ 力量药水:重置全部装备。\n· ♠ 欺骗斗篷:改变 1 张装备的等级或花色。\n· ♥ 治疗药水:弃 1 张创伤,或抵消一次诅咒。\n· ♦ 幸运水晶:将刚抽到的牌换为重新抽 1 张。\n无论何时抽到 A,立即承受当前地图对应的诅咒效果,然后补抽 1 张。\n计分:每张物品 2 分,战利品按等级计分;永恒午夜森林的赏金、沉没的大教堂的蜡烛另有加分。",
			optMap: "地图",
			optChar: "角色",
			mM1: "永恒游荡之魂的陵墓",
			mM2: "永恒午夜森林",
			mM3: "钟表匠的迷宫",
			mM4: "沉没的大教堂",
			boardM1: "地城 01 · 陵墓下层",
			boardM2: "地城 02 · 午夜林径",
			boardM3: "地城 03 · 钟表迷宫",
			boardM4: "地城 04 · 沉没回廊",
			mM1Desc: "基础地城,诅咒会夺走你的装备与战利品",
			mM2Desc: "火炬照亮前路,敌人在黑暗中隐藏",
			mM3Desc: "时钟步步紧逼,扭曲走廊通向未知",
			mM4Desc: "洪水每回合蔓延,点燃蜡烛守护小教堂",
			cBarbarian: "野蛮人",
			cSeer: "先知",
			cFallen: "堕落骑士",
			cDruid: "德鲁伊",
			cHunter: "猎人",
			cTinkerer: "修补匠",
			cAlchemist: "炼金术士",
			cRogue: "盗贼",
			cBarbarianDesc: "生命 25。致命反击、投掷战斧、狂乱",
			cSeerDesc: "生命 20。转移焦点、精神操控、旅行癖",
			cFallenDesc: "生命 35,开局带 1 创伤。龙血、血怒、路径洞察、战斗伤痕",
			cDruidDesc: "生命 25。变形者:鼹鼠、巨熊、犰狳、飞鹰四种形态",
			cHunterDesc: "生命 25。伪装药水、敏锐目光、生存本能、战利品收藏",
			cTinkererDesc: "生命 20。备用零件、制造、心灵手巧、搜寻",
			cAlchemistDesc: "生命 20。以物品为配料调药,稀释、实地记录、搜刮",
			cRogueDesc: "生命 25。毒药涂层、连击、利刃待发、偷袭",
			equipment: "装备",
			items: "物品",
			loot: "战利品",
			wounds: "创伤",
			deck: "牌库",
			discardPile: "弃牌堆",
			torch: "火炬",
			torchDimmed: "火炬(已变暗)",
			bounty: "赏金",
			clock: "时钟",
			candles: "蜡烛",
			collection: "收藏",
			form: "形态",
			formC: "鼹鼠形态",
			formS: "巨熊形态",
			formH: "犰狳形态",
			formD: "飞鹰形态",
			exhausted: "已耗尽",
			woundSum: "创伤 {{n}} / {{max}}",
			currentRoom: "当前位置",
			inventory: "牌架",
			emptySlot: "尚无{{slot}}",
			overview: "全图",
			focusMap: "回到当前位置",
			payPreview: "装备合计 {{n}} / 门槛 {{cost}}",
			doorCost: "费用 {{n}}",
			doorEnemy: "{{rank}} 级敌人",
			doorTorch: "火炬 ≥ {{n}}",
			doorTwist: "扭曲走廊",
			doorFree: "畅通",
			floodedPath: "走廊被淹,无视通行要求",
			moveHere: "移动",
			reveal: "揭示战斗卡",
			battleCard: "战斗卡",
			attack: "攻击",
			defend: "防御",
			rest: "休息",
			enemyHp: "敌人生命 {{hp}} / {{max}}",
			enemyHidden: "敌人处于隐藏状态",
			enemyBlocked: "敌人格挡 {{n}}",
			youDefended: "已防御 {{n}}",
			windupZone: "发条区",
			bossFight: "首领战",
			attackPick: "选择 1 张就绪装备攻击",
			defendPick: "选择任意就绪装备防御",
			comboExtras: "连击:可追加耗尽装备,每件 +2 伤害",
			bloodRage: "血怒:耗尽 1 张创伤使伤害翻倍",
			focusLabel: "转移焦点:该装备等级 ±1",
			attackPreview: "预计伤害 {{damage}} · 敌人生命落点 {{hp}}",
			attackPreviewBase: "基础伤害 {{damage}} · 毒药涂层加值未计入",
			defendPreview: "预计防御 {{n}}",
			trackEffect: "落点效果",
			trackWound: "获得创伤",
			trackParry: "敌人招架",
			trackRefresh1: "重置 1 件装备",
			trackRefresh2: "重置 2 件装备",
			trackDim: "火炬变暗",
			trackClockUp: "时钟 +1",
			trackClockDown: "时钟 -1",
			trackFlood: "洪水蔓延",
			useItem: "使用",
			itemC: "力量药水",
			itemS: "欺骗斗篷",
			itemH: "治疗药水",
			itemD: "幸运水晶",
			itemCDesc: "重置全部装备",
			itemSDesc: "改变 1 张装备的等级或花色",
			itemHDesc: "弃 1 张创伤,或抵消一次诅咒",
			itemDDesc: "抽牌确认时,换掉刚抽到的牌",
			itemDAlchemist: "幸运水晶·配料",
			itemDAlchemistDesc: "调药时可替代其他花色配料",
			itemCTinkerer: "备用零件",
			itemCTinkererDesc: "抽 3 张牌,取等级最低的 1 张作为装备",
			itemSHunter: "伪装药水",
			itemSHunterDesc: "下一次移动无视走廊的通行要求",
			itemSRogue: "毒药涂层",
			itemSRogueDesc: "1 张就绪装备等级临时增加,加值等于 1 张已耗尽装备的等级",
			itemHFallen: "龙血",
			itemHFallenDesc: "受 1 点创伤后,弃掉 2 张创伤",
			itemCDetail: "弃掉此物品，重置全部已耗尽装备。",
			itemCTinkererDetail: "弃掉此物品，抽 3 张牌，将等级最低的 1 张作为装备；使用后若有已耗尽装备，还可重置 1 件。",
			itemSDetail: "弃掉此物品，选 1 件装备，将其等级设为 A 至 K 中任意一级，或改成任意花色。",
			itemSHunterDetail: "弃掉此物品，下一次移动可无视走廊的通行要求。",
			itemSRogueDetail: "弃掉此物品，选 1 件就绪装备和 1 件已耗尽装备；本回合用前者攻击时，额外造成后者有效等级的伤害。",
			itemHDetail: "弃掉此物品并弃掉 1 张创伤；遇到诅咒时，也可在诅咒选择中用它抵消。",
			itemHFallenDetail: "弃掉此物品，先承受 1 张创伤，再选 2 张创伤弃掉；新增创伤可能使冒险立即失败。",
			itemDDetail: "仅在抽牌确认窗口使用：弃掉此物品与刚抽到的 1 张牌，再抽 1 张替换。",
			itemDAlchemistDetail: "炼金术士不能直接用幸运水晶换牌。调药时，它可作为其他花色配料，提升药剂等级。",
			brew: "调药",
			abShapeshift: "变形",
			abThrowAxe: "投掷战斧",
			abScavenge: "搜寻",
			abBladeReady: "利刃待发",
			pReward: "选择奖励牌的去向",
			slotItem: "作为物品",
			slotEquip: "作为装备",
			slotLoot: "作为战利品",
			slotTorch: "作为火炬",
			pKeep: "选择 1 张保留,{{slot}}",
			pSpring: "泉水:重置全部装备,或弃掉创伤",
			springRefresh: "重置全部装备",
			springHeal: "弃掉创伤",
			pCurse: "触发诅咒 {{suit}},要承受效果,还是用治疗药水抵消?",
			curseAccept: "承受诅咒",
			cursePotion: "用治疗药水抵消",
			pConfirmDraw: "抽到了牌,要用幸运水晶换掉其中 1 张吗?",
			crystalKeep: "保留",
			pTwist: "扭曲走廊的费用是 {{cost}}(按抽到的牌)",
			twistPay: "耗尽装备支付",
			twistLost: "付不起,迷路",
			pMerchant: "商人:在装备与战利品之间互移(还可操作 {{n}} 次)",
			merchantE2L: "装备 → 战利品",
			merchantL2E: "战利品 → 装备",
			merchantDone: "结束交易",
			pChallenge: "挑战:耗尽符合条件的就绪装备,按等级合计领奖",
			challengeSubmit: "提交挑战",
			pCairn: "石冢:弃 1 张 {{suit}} 花色的牌,将弃牌堆顶 5 张洗回牌库",
			pCollector: "好奇的收藏家:将任意物品移为战利品",
			pDiscardClock: "弃 1 张牌,使时钟 {{delta}}",
			pChapel: "小教堂:弃 1 张 {{suit}} 花色的牌,点燃蜡烛",
			pChapelFree: "小教堂已被淹没,可以免费点燃蜡烛",
			chapelLight: "点燃蜡烛",
			pPickExhaust: "选择 {{n}} 张就绪装备耗尽",
			pPickRefresh: "选择最多 {{n}} 张已耗尽的装备重置",
			pPickWound: "选择最多 {{n}} 张创伤弃掉",
			pTranseptW: "西耳堂:弃 1 张创伤,或重置 1 件装备",
			pTranseptE: "东耳堂:重置装备",
			pTransept2: "要再移动一次吗?",
			transeptExhaust: "耗尽装备再移动",
			transeptHurt: "受 1 点伤害再移动",
			transeptStay: "停留",
			pDragonBlood: "龙血生效:选择 2 张创伤弃掉",
			pFuse: "制造:要将新装备融合到一张已有的装备上吗?",
			fuseSkip: "不融合",
			pCollect: "战利品收藏:要收藏这张敌人牌吗?",
			collectYes: "收藏",
			collectNo: "不收藏",
			pScavenge: "搜刮:选择 1 张本场战斗的敌人战斗卡作为物品",
			scavengeSkip: "不搜刮",
			pMole: "鼹鼠形态:选择 1 张作为战利品",
			pSeer: "精神操控:从牌库顶 3 张中选择 1 张替换",
			pHunterBottom: "敏锐目光:选择 1 张放到牌库底",
			pCloister: "回廊:要再抽 1 张物品吗?",
			cloisterAgain: "再抽 1 张",
			skip: "跳过",
			confirm: "确定",
			errBusy: "当前还有未处理完的事件",
			errNoPath: "无法移动到该房间",
			errTorch: "火炬等级不足,无法通过",
			errPay: "支付的装备未就绪,或等级合计不足",
			errFocus: "转移焦点现在不可用",
			errNotPlayer: "这不是你的对局",
			errOver: "本局已结束",
			errNoCard: "没有这张牌",
			errCrystal: "幸运水晶现在不可用",
			errBrew: "配料组合不符合调药规则",
			errAbility: "该技能现在不可用",
			errNoCombat: "现在不能执行这个战斗行动",
			errExhausted: "该装备已耗尽或不存在",
			errDefendSuit: "这张装备不能用于此次防御",
			errNoPending: "现在没有待处理的选择",
			errChoice: "无效的选择",
			log: {
				curse: "触发诅咒 {{suit}}",
				lose: "冒险失败:{{reason}}",
				flood: "{{room}} 被洪水淹没",
				combat: "遭遇敌人:{{enemy}}({{rank}} 级)",
				kill: "击败了 {{enemy}}",
				lost: "在扭曲走廊迷路,被传送到齿轮室",
				win: "击败首领,凯旋而归",
				candle: "{{room}} 的蜡烛被点燃"
			},
			loseWounds: "创伤过重",
			loseDeck: "牌库耗尽",
			winTitle: "凯旋而归",
			loseTitle: "冒险失败",
			scoreItems: "物品",
			scoreLoot: "战利品",
			scoreBounty: "赏金",
			scoreCandles: "蜡烛",
			scoreTotal: "总分",
			rM1Start: "起点",
			rM1Library: "图书馆",
			rM1Cloaked: "戴斗篷的身影",
			rM1Merchant: "商人",
			rM1Statue: "旋转雕像",
			rM1Stairs: "移动楼梯",
			rM1SpringW: "泉水·西",
			rM1SpringE: "泉水·东",
			rM1SpringS: "泉水·南",
			rM1Chest: "发光宝箱",
			rM1Vision: "奇异幻象",
			rM1Wounded: "受伤生物",
			rM1Wall: "残破城墙",
			rM1Flood: "洪水房间",
			rM1Goblin: "哥布林宝藏",
			rM1Lizard: "蜥蜴巢穴",
			rM1Stash: "战利品藏匿点",
			rM1Traveller: "旅行者",
			rM1Jailer: "狱卒",
			rM1Boss: "看守者(首领)",
			rM2Start: "起点",
			rM2TombA: "古墓·甲",
			rM2TombB: "古墓·乙",
			rM2TombC: "古墓·丙",
			rM2StrangerN: "神秘人·北",
			rM2StrangerC: "神秘人·中",
			rM2StrangerS: "神秘人·南",
			rM2CairnC: "石冢 ♣",
			rM2CairnD: "石冢 ♦",
			rM2CairnS: "石冢 ♠",
			rM2CairnH: "石冢 ♥",
			rM2ShrineE: "神龛·东",
			rM2ShrineW: "神龛·西",
			rM2Warrior: "战士之墓",
			rM2Witch: "女巫小屋",
			rM2Chest2: "埋藏的箱子",
			rM2Sapling: "幼树",
			rM2SpringW: "泉水·西",
			rM2SpringS: "泉水·南",
			rM2Boss: "夜之幻影(首领)",
			rM3Start: "起点",
			rM3GearC: "石齿轮",
			rM3GearD: "玻璃齿轮",
			rM3GearH: "黄金齿轮",
			rM3GearS: "铁齿轮",
			rM3Rats: "老鼠的巢穴",
			rM3PendTL: "摆锤·左上",
			rM3PendML: "摆锤·左下",
			rM3PendMR: "摆锤·右",
			rM3Scrap: "金属碎片",
			rM3Escapement: "擒纵装置",
			rM3Collector: "好奇的收藏家",
			rM3BigHand: "大手",
			rM3SmallHand: "小手",
			rM3Magic: "魔法装置",
			rM3Note: "囚犯的便条",
			rM3SpringL: "泉水·左",
			rM3SpringR: "泉水·右",
			rM3Boss: "钟表匠(首领)",
			rM4Start: "起点",
			rM4Boss: "被淹没的祭司(首领)",
			rM4Apse: "后殿",
			rM4ChoirBB: "失落唱诗班·上",
			rM4ChoirAA: "失落唱诗班·右",
			rM4ChapelH: "小教堂 ♥",
			rM4ChapelS: "小教堂 ♠",
			rM4ChapelD: "小教堂 ♦",
			rM4ChapelC: "小教堂 ♣",
			rM4Spring: "泉水",
			rM4Grin: "露齿笑雕像",
			rM4Roar: "咆哮雕像",
			rM4Cloister: "回廊",
			rM4TranseptW: "西耳堂",
			rM4TranseptE: "东耳堂",
			rM4Nave: "中殿",
			rM4Hall: "前厅",
			eGoblin: "哥布林",
			eGhoul: "食尸鬼",
			eLizard: "蜥蜴",
			eWight: "幽灵",
			eWolf: "狼",
			eBear: "熊",
			eViper: "毒蛇",
			eWillowisp: "鬼火",
			eGnome: "发条侏儒",
			eGolem: "发条魔像",
			eKnight: "发条骑士",
			eBellringer: "敲钟人",
			eGargoyle: "石像鬼",
			eMonk: "默僧",
			eAngel: "堕落天使",
			eNixie: "水妖"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "52 Realms: Adventures",
			desc: "A solo dungeon crawl: four maps, one deck of cards, slay the boss and keep the loot",
			rules: "Goal: delve deep, defeat the boss, and get out with as much loot as you can. You lose if your wound ranks reach your health total, or if you must draw from an empty deck.\nSetup: draw 2 cards as items, then draw equipment until your equipment ranks total 20; set aside any Aces and shuffle them back in at the end.\nEach turn:\n· Move along a corridor to an adjacent room, then resolve the room you enter.\n· Numbered gates require exhausting ready equipment of sufficient total rank; lettered gates require defeating a guardian of that rank.\n· Torch gates require torch level, and twisted corridors draw a card to set the cost.\nCombat: draw 2 cards — the higher one is the enemy (its suit sets the type), the other is the reward; ties break ♣>♠>♥>♦.\n· Each combat round, reveal a battle card: enemy block applies first.\n· Then you attack, defend, use a character skill, or rest, and the enemy acts by the suit of its battle card.\nAttack: exhaust 1 ready equipment to deal its rank in damage; symbols on the space where the enemy health marker lands trigger immediately.\nDefend: exhaust any number of ready equipment to reduce incoming damage by their total rank.\nWhen you take damage, draw a card: if its rank does not exceed the damage, it becomes a wound; wounds from wraiths are automatic.\nPlace each reward card in one of three places: as an item, equipment, or loot.\nItem effects:\n· ♣ strength potion: refresh all equipment.\n· ♠ cloak of deception: change the rank or suit of 1 equipment.\n· ♥ healing potion: discard 1 wound, or cancel a curse.\n· ♦ lucky crystal: redraw a card you just drew.\nWhenever you draw an Ace, immediately suffer the curse of the current map, then draw a replacement.\nScoring: 2 points per item, loot scores its rank; the Forest of the Eternal Midnight scores bounty, and the Sunken Cathedral scores candles.",
			optMap: "Map",
			optChar: "Character",
			mM1: "Tomb of the Eternally Wandering Soul",
			mM2: "Forest of the Eternal Midnight",
			mM3: "Clockmaker's Maze",
			mM4: "The Sunken Cathedral",
			boardM1: "Dungeon 01 · Lower tomb",
			boardM2: "Dungeon 02 · Midnight paths",
			boardM3: "Dungeon 03 · Clock maze",
			boardM4: "Dungeon 04 · Sunken cloister",
			mM1Desc: "A basic dungeon; curses strip your equipment and loot",
			mM2Desc: "A torch lights your way while enemies hide in the dark",
			mM3Desc: "The clock ticks on, and twisted corridors lead nowhere certain",
			mM4Desc: "The flood spreads every turn; light candles to guard the chapels",
			cBarbarian: "Barbarian",
			cSeer: "Seer",
			cFallen: "Fallen Knight",
			cDruid: "Druid",
			cHunter: "Hunter",
			cTinkerer: "Tinkerer",
			cAlchemist: "Alchemist",
			cRogue: "Rogue",
			cBarbarianDesc: "Health 25. Deadly riposte, throwing axe, frenzy",
			cSeerDesc: "Health 20. Focus shift, mind control, wanderlust",
			cFallenDesc: "Health 35, starts with 1 wound. Dragon blood, blood rage, path insight, battle scars",
			cDruidDesc: "Health 25. Shapeshifter: mole, bear, armadillo and eagle forms",
			cHunterDesc: "Health 25. Camouflage potion, keen eye, survival instinct, trophy collection",
			cTinkererDesc: "Health 20. Spare parts, fabrication, deft hands, scavenge",
			cAlchemistDesc: "Health 20. Brews potions from item ingredients; dilution, field notes, scavenge",
			cRogueDesc: "Health 25. Poison coating, combo, ready blade, sneak attack",
			equipment: "Equipment",
			items: "Items",
			loot: "Loot",
			wounds: "Wounds",
			deck: "Deck",
			discardPile: "Discard",
			torch: "Torch",
			torchDimmed: "Torch (dimmed)",
			bounty: "Bounty",
			clock: "Clock",
			candles: "Candles",
			collection: "Collection",
			form: "Form",
			formC: "Mole form",
			formS: "Bear form",
			formH: "Armadillo form",
			formD: "Eagle form",
			exhausted: "Exhausted",
			woundSum: "Wounds {{n}} / {{max}}",
			currentRoom: "Current room",
			inventory: "Card tray",
			emptySlot: "No {{slot}} yet",
			overview: "Full map",
			focusMap: "My location",
			payPreview: "Equipment {{n}} / gate {{cost}}",
			doorCost: "Cost {{n}}",
			doorEnemy: "Rank {{rank}} enemy",
			doorTorch: "Torch ≥ {{n}}",
			doorTwist: "Twisted corridor",
			doorFree: "Free",
			floodedPath: "Corridor flooded; requirements waived",
			moveHere: "Move",
			reveal: "Reveal battle card",
			battleCard: "Battle card",
			attack: "Attack",
			defend: "Defend",
			rest: "Rest",
			enemyHp: "Enemy HP {{hp}} / {{max}}",
			enemyHidden: "The enemy is hidden",
			enemyBlocked: "Enemy blocks {{n}}",
			youDefended: "Defended {{n}}",
			windupZone: "Windup zone",
			bossFight: "Boss fight",
			attackPick: "Pick 1 ready equipment to attack",
			defendPick: "Pick any ready equipment to defend",
			comboExtras: "Combo: exhaust extra equipment for +2 damage each",
			bloodRage: "Blood rage: exhaust 1 wound to double damage",
			focusLabel: "Focus shift: treat this equipment rank as ±1",
			attackPreview: "Expected damage {{damage}} · enemy HP lands on {{hp}}",
			attackPreviewBase: "Base damage {{damage}} · poison coating bonus not included",
			defendPreview: "Expected defense {{n}}",
			trackEffect: "Landing effect",
			trackWound: "Gain a wound",
			trackParry: "Enemy parries",
			trackRefresh1: "Refresh 1 equipment",
			trackRefresh2: "Refresh 2 equipment",
			trackDim: "Torch dims",
			trackClockUp: "Clock +1",
			trackClockDown: "Clock -1",
			trackFlood: "Flood spreads",
			useItem: "Use",
			itemC: "Strength potion",
			itemS: "Cloak of deception",
			itemH: "Healing potion",
			itemD: "Lucky crystal",
			itemCDesc: "Refresh all equipment",
			itemSDesc: "Change the rank or suit of 1 equipment",
			itemHDesc: "Discard 1 wound, or cancel a curse",
			itemDDesc: "Swap a card you just drew for a new draw",
			itemDAlchemist: "Lucky crystal ingredient",
			itemDAlchemistDesc: "Substitutes for another suit when brewing",
			itemCTinkerer: "Spare parts",
			itemCTinkererDesc: "Draw 3 cards and keep the lowest as equipment",
			itemSHunter: "Camouflage potion",
			itemSHunterDesc: "Your next move ignores corridor requirements",
			itemSRogue: "Poison coating",
			itemSRogueDesc: "A ready equipment temporarily gains rank equal to an exhausted one",
			itemHFallen: "Dragon blood",
			itemHFallenDesc: "Take 1 wound, then discard 2 wounds",
			itemCDetail: "Discard this item to refresh all exhausted equipment.",
			itemCTinkererDetail: "Discard this item, draw 3 cards, and keep the lowest rank as equipment. After use, you may also refresh 1 exhausted equipment.",
			itemSDetail: "Discard this item and choose 1 equipment. Set its rank to any value from Ace to King, or change it to any suit.",
			itemSHunterDetail: "Discard this item. Your next move ignores the corridor requirements.",
			itemSRogueDetail: "Discard this item and choose a ready and an exhausted equipment. If you attack with the ready one this turn, add the exhausted one’s effective rank to the damage.",
			itemHDetail: "Discard this item and discard 1 wound. During a curse choice, it can instead cancel that curse.",
			itemHFallenDetail: "Discard this item, take 1 wound, then choose 2 wounds to discard. The new wound can immediately end your run.",
			itemDDetail: "Only usable when confirming a draw: discard this item and 1 newly drawn card, then draw a replacement.",
			itemDAlchemistDetail: "Alchemists cannot use a lucky crystal to redraw. While brewing, it can substitute for another suit and raise the brew level.",
			brew: "Brew",
			abShapeshift: "Shapeshift",
			abThrowAxe: "Throwing axe",
			abScavenge: "Scavenge",
			abBladeReady: "Ready blade",
			pReward: "Choose where the reward card goes",
			slotItem: "As item",
			slotEquip: "As equipment",
			slotLoot: "As loot",
			slotTorch: "As torch",
			pKeep: "Pick 1 card to keep {{slot}}",
			pSpring: "Spring: refresh all equipment, or discard wounds",
			springRefresh: "Refresh all equipment",
			springHeal: "Discard wounds",
			pCurse: "Curse {{suit}}: suffer it, or cancel with a healing potion?",
			curseAccept: "Suffer the curse",
			cursePotion: "Cancel with potion",
			pConfirmDraw: "Cards drawn. Use a lucky crystal to redraw one of them?",
			crystalKeep: "Keep",
			pTwist: "The twisted corridor costs {{cost}} (from the drawn card)",
			twistPay: "Exhaust equipment to pay",
			twistLost: "Cannot pay — get lost",
			pMerchant: "Merchant: move cards between equipment and loot ({{n}} left)",
			merchantE2L: "Equipment → loot",
			merchantL2E: "Loot → equipment",
			merchantDone: "Done trading",
			pChallenge: "Challenge: exhaust matching ready equipment; the total rank sets your reward",
			challengeSubmit: "Submit challenge",
			pCairn: "Cairn: discard a {{suit}} card to shuffle the top 5 discards back into the deck",
			pCollector: "The Collector: move any items to loot",
			pDiscardClock: "Discard 1 card to shift the clock by {{delta}}",
			pChapel: "Chapel: discard a {{suit}} card to light a candle",
			pChapelFree: "The chapel is flooded; you may light a candle for free",
			chapelLight: "Light candle",
			pPickExhaust: "Exhaust {{n}} ready equipment",
			pPickRefresh: "Refresh up to {{n}} exhausted equipment",
			pPickWound: "Discard up to {{n}} wounds",
			pTranseptW: "West transept: discard 1 wound, or refresh 1 equipment",
			pTranseptE: "East transept: refresh equipment",
			pTransept2: "Move again?",
			transeptExhaust: "Exhaust equipment to move",
			transeptHurt: "Take 1 damage to move",
			transeptStay: "Stay",
			pDragonBlood: "Dragon blood: discard 2 wounds",
			pFuse: "Fabricate: fuse the new equipment onto an existing one?",
			fuseSkip: "Do not fuse",
			pCollect: "Trophy collection: collect this enemy card?",
			collectYes: "Collect",
			collectNo: "Skip",
			pScavenge: "Scavenge: pick 1 enemy battle card from this fight as an item",
			scavengeSkip: "Skip",
			pMole: "Mole form: pick 1 card as loot",
			pSeer: "Mind control: pick 1 of the top 3 cards as the replacement",
			pHunterBottom: "Keen eye: pick 1 card for the bottom of the deck",
			pCloister: "Cloister: draw another item?",
			cloisterAgain: "Draw again",
			skip: "Skip",
			confirm: "Confirm",
			errBusy: "There is still an unresolved event",
			errNoPath: "You cannot move to that room",
			errTorch: "Torch level too low to pass",
			errPay: "Payment equipment is exhausted or falls short",
			errFocus: "Focus shift is unavailable now",
			errNotPlayer: "This is not your game",
			errOver: "This run has ended",
			errNoCard: "No such card",
			errCrystal: "Lucky crystal cannot be used now",
			errBrew: "Invalid ingredient mix",
			errAbility: "That skill is unavailable now",
			errNoCombat: "That combat action is unavailable now",
			errExhausted: "That equipment is exhausted or missing",
			errDefendSuit: "That equipment cannot defend this attack",
			errNoPending: "Nothing is waiting for a choice",
			errChoice: "Invalid choice",
			log: {
				curse: "Curse triggered {{suit}}",
				lose: "Run failed: {{reason}}",
				flood: "{{room}} has flooded",
				combat: "Enemy encountered: {{enemy}} (rank {{rank}})",
				kill: "Defeated {{enemy}}",
				lost: "Lost in a twisted corridor; teleported to a gear room",
				win: "Boss defeated. You made it out.",
				candle: "A candle is lit in {{room}}"
			},
			loseWounds: "Succumbed to wounds",
			loseDeck: "The deck ran out",
			winTitle: "Triumphant return",
			loseTitle: "The run has failed",
			scoreItems: "Items",
			scoreLoot: "Loot",
			scoreBounty: "Bounty",
			scoreCandles: "Candles",
			scoreTotal: "Total",
			rM1Start: "Start",
			rM1Library: "Library",
			rM1Cloaked: "Cloaked Figure",
			rM1Merchant: "Merchant",
			rM1Statue: "Revolving Statue",
			rM1Stairs: "Shifting Stairs",
			rM1SpringW: "Spring (West)",
			rM1SpringE: "Spring (East)",
			rM1SpringS: "Spring (South)",
			rM1Chest: "Glowing Chest",
			rM1Vision: "Strange Vision",
			rM1Wounded: "Wounded Creature",
			rM1Wall: "Broken Wall",
			rM1Flood: "Flooded Room",
			rM1Goblin: "Goblin Hoard",
			rM1Lizard: "Lizard's Den",
			rM1Stash: "Loot Stash",
			rM1Traveller: "Traveller",
			rM1Jailer: "Jailer",
			rM1Boss: "The Warden (Boss)",
			rM2Start: "Start",
			rM2TombA: "Tomb A",
			rM2TombB: "Tomb B",
			rM2TombC: "Tomb C",
			rM2StrangerN: "Stranger (North)",
			rM2StrangerC: "Stranger (Center)",
			rM2StrangerS: "Stranger (South)",
			rM2CairnC: "Cairn ♣",
			rM2CairnD: "Cairn ♦",
			rM2CairnS: "Cairn ♠",
			rM2CairnH: "Cairn ♥",
			rM2ShrineE: "Shrine (East)",
			rM2ShrineW: "Shrine (West)",
			rM2Warrior: "Warrior's Tomb",
			rM2Witch: "Witch's Hut",
			rM2Chest2: "Buried Chest",
			rM2Sapling: "Sapling",
			rM2SpringW: "Spring (West)",
			rM2SpringS: "Spring (South)",
			rM2Boss: "The Nightshade (Boss)",
			rM3Start: "Start",
			rM3GearC: "Stone Gear",
			rM3GearD: "Glass Gear",
			rM3GearH: "Golden Gear",
			rM3GearS: "Iron Gear",
			rM3Rats: "Rats' Nest",
			rM3PendTL: "Pendulum (Top Left)",
			rM3PendML: "Pendulum (Mid Left)",
			rM3PendMR: "Pendulum (Mid Right)",
			rM3Scrap: "Scrap Metal",
			rM3Escapement: "Escapement",
			rM3Collector: "The Collector",
			rM3BigHand: "The Big Hand",
			rM3SmallHand: "The Small Hand",
			rM3Magic: "Magic Device",
			rM3Note: "Prisoner's Note",
			rM3SpringL: "Spring (Left)",
			rM3SpringR: "Spring (Right)",
			rM3Boss: "The Clockmaker (Boss)",
			rM4Start: "Start",
			rM4Boss: "The Drowned Priest (Boss)",
			rM4Apse: "Apse",
			rM4ChoirBB: "Lost Choir (North)",
			rM4ChoirAA: "Lost Choir (East)",
			rM4ChapelH: "Chapel ♥",
			rM4ChapelS: "Chapel ♠",
			rM4ChapelD: "Chapel ♦",
			rM4ChapelC: "Chapel ♣",
			rM4Spring: "Spring",
			rM4Grin: "Grinning Statue",
			rM4Roar: "Roaring Statue",
			rM4Cloister: "Cloister",
			rM4TranseptW: "West Transept",
			rM4TranseptE: "East Transept",
			rM4Nave: "Nave",
			rM4Hall: "Vestibule",
			eGoblin: "Goblin",
			eGhoul: "Ghoul",
			eLizard: "Lizard",
			eWight: "Wight",
			eWolf: "Wolf",
			eBear: "Bear",
			eViper: "Viper",
			eWillowisp: "Will-o'-wisp",
			eGnome: "Clockwork Gnome",
			eGolem: "Clockwork Golem",
			eKnight: "Clockwork Knight",
			eBellringer: "Bell Ringer",
			eGargoyle: "Gargoyle",
			eMonk: "Silent Monk",
			eAngel: "Fallen Angel",
			eNixie: "Nixie"
		}
	}
};
//#endregion
export { Lt as default };
