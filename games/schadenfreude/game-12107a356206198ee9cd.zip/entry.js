import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as i, useT as a } from "@bgparty/sdk/i18n";
import { IconLog as o } from "@bgparty/sdk/icons";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { LogSheet as c } from "@bgparty/sdk/ui/log-sheet";
import { seatName as l } from "@bgparty/sdk/ui/player-strip";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { Floater as p, FlySprite as m } from "@bgparty/sdk/fx/primitives";
//#region src/games/schadenfreude/data.ts
var h = [
	-3,
	-2,
	-1,
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9
], g = (e) => e < 48 ? Math.floor(e / 12) : 4, _ = (e) => e < 48 ? h[e % 12] : e === 48 ? 0 : 10, v = (e) => e >= 48, y = [
	"games.schadenfreude.sword",
	"games.schadenfreude.flag",
	"games.schadenfreude.shield",
	"games.schadenfreude.helm",
	"games.schadenfreude.knight"
];
function b(e) {
	return Array.from({ length: 50 }, (e, t) => t).filter((t) => e !== 3 || v(t) || ![
		-2,
		-1,
		9
	].includes(_(t)));
}
var x = (e) => e.reduce((e, t) => e + _(t), 0);
function S(e, t) {
	let n = [...e], r = [];
	for (let e of t) {
		let t = n.findIndex((t) => _(t) === _(e));
		t < 0 ? n.push(e) : r.push(...n.splice(t, 1), e);
	}
	return {
		kept: n.sort((e, t) => _(e) - _(t)),
		removed: r
	};
}
var C = (e) => {
	let t = e.find((e) => !v(e.card));
	return t ? g(t.card) : null;
};
function w(e, t) {
	let n = C(t);
	return n === null || !e.some((e) => g(e) === n) ? [...e] : e.filter((e) => v(e) || g(e) === n);
}
function T(e) {
	let t = C(e), n = e.filter((e) => v(e.card) || g(e.card) === t).sort((e, t) => _(t.card) - _(e.card)), r = n[Math.min(1, n.length - 1)], i = e.filter((e) => e.rid === r.rid || !v(e.card) && g(e.card) !== t).map((e) => e.card);
	return {
		winner: r.rid,
		taken: i,
		discarded: e.filter((e) => !i.includes(e.card)).map((e) => e.card)
	};
}
function E(e, t) {
	let n = e.filter((e) => t[e] <= 40), r = [...new Set(n.map((e) => t[e]))].sort((e, t) => t - e).flatMap((e) => {
		let r = n.filter((n) => t[n] === e);
		return r.length === 1 ? r : [];
	}).slice(0, 1);
	return {
		winner: r,
		ranking: [...r, ...e.filter((e) => !r.includes(e)).sort((e, n) => Number(t[e] > 40) - Number(t[n] > 40) || (t[e] > 40 ? t[e] - t[n] : t[n] - t[e]))],
		scores: t
	};
}
//#endregion
//#region src/games/schadenfreude/meta.ts
var D = {
	id: "schadenfreude",
	tier: "alpha",
	mechanics: ["trick-taking", "set-collection"],
	interactionTags: [],
	nameKey: "games.schadenfreude.name",
	descKey: "games.schadenfreude.desc",
	rulesKey: "games.schadenfreude.rules",
	icon: "⚔️",
	iconImg: "games/schadenfreude.webp",
	minPlayers: 3,
	maxPlayers: 5,
	bestPlayers: [4, 5],
	accent: "#526387",
	search: {
		py: "xingzailehuo",
		init: "xzlh"
	},
	hotseat: "cover",
	releasedAt: "2026-11-04T20:24:00+08:00",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/2503518493550323942/63025C382921E1C016350041249B8E0B934BEA24/" }
}, O = t.int().min(0).max(49), k = t.record(t.string(), t.int()), A = t.object({
	rid: t.string(),
	card: O
}), j = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		card: O
	}),
	t.object({ type: t.literal("next") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), M = t.object({
	phase: t.enum([
		"deal",
		"play",
		"reveal",
		"collect",
		"score",
		"roundOver",
		"done"
	]),
	round: t.int().positive(),
	trickNumber: t.int().positive(),
	turn: t.string(),
	leader: t.string(),
	trick: t.array(A),
	lastTrick: t.array(A),
	lastWinner: t.string().nullable(),
	lastTaken: t.array(O),
	lastRemoved: t.array(O),
	lead: t.int().nullable(),
	players: t.array(t.object({
		rid: t.string(),
		score: t.int().nonnegative(),
		handCount: t.int().nonnegative(),
		pile: t.array(O),
		ready: t.boolean()
	})),
	seen: t.array(O),
	voids: t.record(t.string(), t.array(t.int())),
	rounds: t.array(t.object({
		round: t.int(),
		points: k,
		totals: k
	})),
	log: t.array(t.object({
		kind: t.enum(["trick", "round"]),
		round: t.int(),
		number: t.int(),
		rid: t.string(),
		cards: t.array(O),
		removed: t.array(O),
		points: k
	}))
}), N = t.object({
	hand: t.array(O),
	legal: t.array(O),
	needsAction: t.boolean()
}), P = {
	deal: 650,
	play: 350,
	reveal: 950,
	collect: 750,
	score: 1200
}, F = (e) => Object.fromEntries(e.map((e) => [e, []]));
function I(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function L(e) {
	let t = I(e, b(e.players.length)), n = e.players.length === 5 ? 10 : 12;
	return e.hands = Object.fromEntries(e.players.map((e, r) => [e, t.slice(r * n, (r + 1) * n).sort((e, t) => e - t)])), e.unused = t.slice(n * e.players.length), e.piles = F(e.players), e.discarded = [], e.seen = [], e.voids = F(e.players), e.trick = [], e.lastTrick = [], e.lastWinner = null, e.lastTaken = [], e.lastRemoved = [], e.ready = [], e.trickNumber = 1, e.turn = e.leader, e.phase = "deal", e.players.map((t) => ({
		kind: "deal",
		rid: t,
		data: { count: n },
		for: [t],
		secret: { cards: e.hands[t] },
		with: !0
	}));
}
function R(e) {
	if (e.phase === "deal") return e.phase = "play", [];
	if (e.phase === "reveal") {
		let t = T(e.trick), n = S(e.piles[t.winner], t.taken);
		return e.lastTrick = e.trick, e.lastWinner = t.winner, e.lastTaken = t.taken, e.lastRemoved = n.removed, e.piles[t.winner] = n.kept, e.discarded.push(...t.discarded, ...n.removed), e.trick = [], e.log.push({
			kind: "trick",
			round: e.round,
			number: e.trickNumber,
			rid: t.winner,
			cards: t.taken,
			removed: n.removed,
			points: {}
		}), e.phase = "collect", e.leader = t.winner, [{
			kind: "collect",
			rid: t.winner,
			data: {
				plays: e.lastTrick,
				taken: t.taken,
				removed: n.removed
			}
		}];
	}
	if (e.phase === "collect") {
		if (e.players.some((t) => e.hands[t].length)) return e.trickNumber++, e.turn = e.leader, e.phase = "play", [];
		let t = Object.fromEntries(e.players.map((t) => [t, x(e.piles[t])]));
		return e.players.forEach((n) => {
			e.scores[n] = Math.max(0, e.scores[n] + t[n]);
		}), e.rounds.push({
			round: e.round,
			points: t,
			totals: { ...e.scores }
		}), e.log.push({
			kind: "round",
			round: e.round,
			number: e.trickNumber,
			rid: "",
			cards: [],
			removed: [],
			points: t
		}), e.phase = "score", [{
			kind: "score",
			data: { points: t }
		}];
	}
	return e.phase === "score" && (e.phase = e.players.some((t) => e.scores[t] > 40) ? "done" : "roundOver"), [];
}
var z = {
	meta: D,
	schemas: {
		action: j,
		publicView: M,
		privateView: N
	},
	saveCompatibility: { version: "1" },
	setup(t, n, r) {
		let i = n[e(r, 0, n.length)], a = {
			players: [...n],
			seed: r,
			cursor: 1,
			phase: "deal",
			round: 1,
			trickNumber: 1,
			turn: i,
			leader: i,
			roundLeader: i,
			hands: {},
			piles: {},
			scores: Object.fromEntries(n.map((e) => [e, 0])),
			trick: [],
			lastTrick: [],
			lastWinner: null,
			lastTaken: [],
			lastRemoved: [],
			discarded: [],
			unused: [],
			seen: [],
			voids: {},
			ready: [],
			rounds: [],
			log: []
		};
		return {
			state: a,
			fx: L(a)
		};
	},
	reduce(e, t, n) {
		let r = structuredClone(e);
		if (t.type === "tick") return n.by === "$engine" ? {
			state: r,
			fx: R(r)
		} : { code: "games.schadenfreude.errTurn" };
		if (!r.players.includes(n.by) || r.phase === "done") return { code: "games.schadenfreude.errTurn" };
		if (t.type === "next") {
			if (r.phase !== "roundOver" || r.ready.includes(n.by)) return { code: "games.schadenfreude.errTurn" };
			if (r.ready.push(n.by), r.ready.length < r.players.length) return { state: r };
			let e = Math.min(...Object.values(r.scores)), t = r.players.indexOf(r.roundLeader);
			return r.leader = Array.from({ length: r.players.length }, (e, n) => r.players[(t + n + 1) % r.players.length]).find((t) => r.scores[t] === e), r.roundLeader = r.leader, r.round++, {
				state: r,
				fx: L(r)
			};
		}
		if (r.phase !== "play" || r.turn !== n.by) return { code: "games.schadenfreude.errTurn" };
		if (!r.hands[n.by].includes(t.card)) return { code: "games.schadenfreude.errCard" };
		if (!w(r.hands[n.by], r.trick).includes(t.card)) return { code: "games.schadenfreude.errFollow" };
		let i = C(r.trick);
		i !== null && !v(t.card) && g(t.card) !== i && !r.voids[n.by].includes(i) && r.voids[n.by].push(i), r.hands[n.by] = r.hands[n.by].filter((e) => e !== t.card), r.seen.push(t.card), r.trick.push({
			rid: n.by,
			card: t.card
		});
		let a = [{
			kind: "play",
			rid: n.by,
			data: { card: t.card }
		}];
		return r.trick.length === r.players.length ? (r.phase = "reveal", r.lastWinner = T(r.trick).winner) : r.turn = r.players[(r.players.indexOf(n.by) + 1) % r.players.length], {
			state: r,
			fx: a
		};
	},
	nextTickIn(e) {
		return e.phase === "deal" ? P.deal : e.phase === "reveal" ? P.reveal : e.phase === "collect" ? P.collect : e.phase === "score" ? P.score : null;
	},
	viewFor(e, t) {
		return {
			public: {
				phase: e.phase,
				round: e.round,
				trickNumber: e.trickNumber,
				turn: e.turn,
				leader: e.leader,
				trick: e.trick,
				lastTrick: e.lastTrick,
				lastWinner: e.lastWinner,
				lastTaken: e.lastTaken,
				lastRemoved: e.lastRemoved,
				lead: C(e.trick),
				players: e.players.map((t) => ({
					rid: t,
					score: e.scores[t],
					handCount: e.hands[t].length,
					pile: e.piles[t],
					ready: e.ready.includes(t)
				})),
				seen: e.seen,
				voids: e.voids,
				rounds: e.rounds,
				log: e.log
			},
			...e.players.includes(t) ? { private: {
				hand: e.hands[t],
				legal: e.phase === "play" && e.turn === t ? w(e.hands[t], e.trick) : [],
				needsAction: e.phase === "play" && e.turn === t || e.phase === "roundOver" && !e.ready.includes(t)
			} } : {}
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: e.phase,
			...E(e.players, e.scores)
		} : { phase: e.phase };
	}
}, B = (e) => `games/schadenfreude/cards/${e}.svg`;
function V({ id: e, anchor: t, legal: n = !1, selected: i = !1, onClick: o }) {
	let { ref: s, hidden: c } = r(t ?? null), l = a();
	return /* @__PURE__ */ f("button", {
		type: "button",
		ref: s,
		className: `sf-card${n ? " sf-card--legal" : ""}${i ? " sf-card--selected" : ""}`,
		style: { visibility: c ? "hidden" : void 0 },
		disabled: !o,
		onClick: o,
		"aria-pressed": o ? i : void 0,
		"aria-label": l("games.schadenfreude.card", {
			suit: l(y[g(e)]),
			n: _(e)
		}),
		children: [/* @__PURE__ */ d("img", {
			src: B(e),
			alt: "",
			draggable: !1
		}), n && /* @__PURE__ */ d("svg", {
			className: "sf-march",
			viewBox: "0 0 100 144",
			preserveAspectRatio: "none",
			"aria-hidden": !0,
			children: /* @__PURE__ */ d("rect", {
				x: "1.5",
				y: "1.5",
				width: "97",
				height: "141",
				rx: "4",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2",
				strokeDasharray: "5 4",
				children: /* @__PURE__ */ d("animate", {
					attributeName: "stroke-dashoffset",
					from: "0",
					to: "-18",
					dur: "1s",
					repeatCount: "indefinite"
				})
			})
		})]
	});
}
//#endregion
//#region src/games/schadenfreude/score-table.tsx
function H({ pub: e, nameOf: t }) {
	let n = a();
	return /* @__PURE__ */ d("div", {
		className: "sf-score-scroll",
		children: /* @__PURE__ */ f("table", {
			className: "sf-score-table",
			children: [
				/* @__PURE__ */ d("thead", { children: /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: n("games.schadenfreude.scoreRound") }), e.players.map((e) => /* @__PURE__ */ d("th", {
					title: t(e.rid),
					children: t(e.rid)
				}, e.rid))] }) }),
				/* @__PURE__ */ d("tbody", { children: e.rounds.map((t) => /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: t.round }), e.players.map((e) => /* @__PURE__ */ f("td", { children: [t.points[e.rid] > 0 ? "+" : "", t.points[e.rid]] }, e.rid))] }, t.round)) }),
				/* @__PURE__ */ d("tfoot", { children: /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: n("games.schadenfreude.finalTotal") }), e.players.map((e) => /* @__PURE__ */ d("td", { children: e.score }, e.rid))] }) })
			]
		})
	});
}
//#endregion
//#region src/games/schadenfreude/view-player.tsx
function U({ public: e, private: t, members: p, myRid: m, send: h }) {
	let g = e, v = t, b = a(), S = i((e) => e.locale), C = (e) => {
		let t = p.find((t) => t.rid === e);
		return t ? l(t, S) : e;
	}, [w, T] = n(null), [E, D] = n(!1), [O, k] = n(null), A = w?.round === g.round && w.trick === g.trickNumber && v?.legal.includes(w.card) ? w.card : null, { ref: j } = r("table"), { ref: M } = r("discard"), N = g.phase === "play" && g.turn === m, P = g.phase === "deal" ? b("games.schadenfreude.dealing") : g.phase === "reveal" ? b("games.schadenfreude.reveal", { name: C(g.lastWinner ?? "") }) : g.phase === "collect" ? b("games.schadenfreude.collecting", { name: C(g.lastWinner ?? "") }) : g.phase === "score" ? b("games.schadenfreude.scoring") : g.phase === "roundOver" ? b("games.schadenfreude.roundOver") : N ? b("games.schadenfreude.turnYou") : b("games.schadenfreude.turnWait", { name: C(g.turn) }), F = g.phase === "collect" ? g.lastTrick : g.trick, I = g.phase === "collect" ? g.lastTrick.find((e) => e.card < 48)?.card : void 0, L = I === void 0 ? g.lead : Math.floor(I / 12), R = g.players.find((e) => e.rid === m);
	return /* @__PURE__ */ d("div", {
		className: "sf-root",
		children: /* @__PURE__ */ f(s, {
			adaptive: !0,
			scroll: !1,
			className: "sf-screen",
			banner: /* @__PURE__ */ f("div", {
				className: "sf-head",
				children: [/* @__PURE__ */ f("div", {
					className: "sf-heading",
					children: [/* @__PURE__ */ f("span", { children: [
						b("games.schadenfreude.round", { n: g.round }),
						" · ",
						b("games.schadenfreude.trick", { n: g.trickNumber })
					] }), /* @__PURE__ */ d("button", {
						type: "button",
						onClick: () => D(!0),
						"aria-label": b("common.log.title"),
						children: /* @__PURE__ */ d(o, { size: 18 })
					})]
				}), /* @__PURE__ */ d("div", {
					className: "sf-status",
					role: "status",
					children: P
				})]
			}),
			actionsHeight: "sf-actions-height",
			actions: /* @__PURE__ */ f("div", {
				className: "sf-hand-area",
				children: [
					/* @__PURE__ */ f("div", {
						className: "sf-hand-title",
						children: [b("games.schadenfreude.hand"), /* @__PURE__ */ d("span", { children: b("games.schadenfreude.handCount", { n: v?.hand.length ?? 0 }) })]
					}),
					/* @__PURE__ */ d("div", {
						className: "sf-hand",
						children: v?.hand.map((e) => /* @__PURE__ */ d(V, {
							id: e,
							anchor: `hand:${e}`,
							legal: N && v.legal.includes(e),
							selected: A === e,
							onClick: N && v.legal.includes(e) ? () => T(A === e ? null : {
								round: g.round,
								trick: g.trickNumber,
								card: e
							}) : void 0
						}, e))
					}),
					/* @__PURE__ */ d("div", {
						className: "sf-decision",
						children: g.phase === "roundOver" ? /* @__PURE__ */ d("button", {
							className: "sf-primary",
							type: "button",
							disabled: !v?.needsAction,
							onClick: () => h({ type: "next" }),
							children: b(R?.ready ? "games.schadenfreude.waiting" : "games.schadenfreude.next")
						}) : /* @__PURE__ */ d("button", {
							className: "sf-primary",
							type: "button",
							disabled: A === null || !N,
							onClick: () => {
								A !== null && (h({
									type: "play",
									card: A
								}), T(null));
							},
							children: b("games.schadenfreude.play")
						})
					})
				]
			}),
			children: [
				/* @__PURE__ */ f("div", {
					className: "sf-main",
					ref: j,
					children: [/* @__PURE__ */ d("div", {
						className: "sf-seats",
						style: { "--sf-players": g.players.length },
						children: g.players.map((e) => /* @__PURE__ */ d(W, {
							player: e,
							name: C(e.rid),
							turn: g.phase === "play" && e.rid === g.turn,
							mine: e.rid === m,
							onPile: () => k(e.rid)
						}, e.rid))
					}), /* @__PURE__ */ f("div", {
						className: "sf-arena",
						children: [
							/* @__PURE__ */ d("div", {
								className: "sf-suit-line",
								children: F.length ? b(L === null ? "games.schadenfreude.wildLead" : "games.schadenfreude.lead", { suit: L === null ? "" : b(y[L]) }) : b("games.schadenfreude.leadBy", { name: C(g.leader) })
							}),
							/* @__PURE__ */ d("div", {
								className: "sf-trick",
								style: { "--sf-players": g.players.length },
								children: g.players.map((e) => {
									let t = F.find((t) => t.rid === e.rid);
									return /* @__PURE__ */ f("div", {
										className: `sf-play-slot${g.phase === "reveal" && g.lastWinner === e.rid ? " sf-play-slot--winner" : ""}`,
										children: [/* @__PURE__ */ d("span", {
											className: "sf-slot-name",
											title: C(e.rid),
											children: C(e.rid)
										}), /* @__PURE__ */ d("div", {
											className: "sf-table-card",
											style: { visibility: g.phase === "collect" ? "hidden" : void 0 },
											children: t ? /* @__PURE__ */ d(V, {
												id: t.card,
												anchor: `trick:${e.rid}`
											}) : /* @__PURE__ */ d("span", { className: "sf-card-space" })
										})]
									}, e.rid);
								})
							}),
							/* @__PURE__ */ d("div", {
								className: "sf-discard",
								ref: M,
								"aria-hidden": !0,
								children: "◇"
							}),
							(g.phase === "score" || g.phase === "roundOver") && /* @__PURE__ */ f("div", {
								className: "sf-round-overlay",
								children: [/* @__PURE__ */ d("h2", { children: b("games.schadenfreude.scoreTitle") }), /* @__PURE__ */ d(H, {
									pub: g,
									nameOf: C
								})]
							})
						]
					})]
				}),
				E && /* @__PURE__ */ d("div", {
					className: "sf-log",
					children: /* @__PURE__ */ d(c, {
						log: g.log,
						onClose: () => D(!1),
						line: (e) => e.kind === "trick" ? /* @__PURE__ */ f(u, { children: [b("games.schadenfreude.logTrick", {
							r: e.round,
							n: e.number,
							name: C(e.rid),
							cards: e.cards.map(_).join(", ")
						}), e.removed.length > 0 && /* @__PURE__ */ f("span", { children: [" · ", b("games.schadenfreude.logRemoved", { cards: e.removed.map(_).join(", ") })] })] }) : b("games.schadenfreude.logRound", {
							r: e.round,
							scores: g.players.map((t) => `${C(t.rid)} ${e.points[t.rid] > 0 ? "+" : ""}${e.points[t.rid]}`).join(" · ")
						})
					})
				}),
				O && /* @__PURE__ */ d("div", {
					className: "sf-modal",
					onClick: () => k(null),
					children: /* @__PURE__ */ f("section", {
						onClick: (e) => e.stopPropagation(),
						children: [/* @__PURE__ */ f("header", { children: [/* @__PURE__ */ f("h2", { children: [
							C(O),
							" · ",
							b("games.schadenfreude.pile", { n: x(g.players.find((e) => e.rid === O)?.pile ?? []) })
						] }), /* @__PURE__ */ d("button", {
							type: "button",
							"aria-label": b("common.qr.close"),
							onClick: () => k(null),
							children: "×"
						})] }), /* @__PURE__ */ d("div", {
							className: "sf-pile-detail",
							children: g.players.find((e) => e.rid === O)?.pile.map((e) => /* @__PURE__ */ d(V, { id: e }, e))
						})]
					})
				})
			]
		})
	});
}
function W({ player: e, name: t, turn: n, mine: i, onPile: o }) {
	let s = a(), { ref: c } = r(`seat:${e.rid}`), { ref: l } = r(`score:${e.rid}`), { ref: u, hidden: p } = r(`pile:${e.rid}`);
	return /* @__PURE__ */ f("div", {
		ref: c,
		className: `sf-seat${n ? " sf-seat--turn" : ""}${i ? " sf-seat--mine" : ""}`,
		children: [
			/* @__PURE__ */ f("div", {
				className: "sf-seat-name",
				title: t,
				children: [t, e.ready && /* @__PURE__ */ d("span", {
					"aria-label": s("games.schadenfreude.ready"),
					children: " ✓"
				})]
			}),
			/* @__PURE__ */ f("div", {
				className: "sf-total",
				children: [/* @__PURE__ */ d("span", {
					ref: l,
					children: e.score
				}), /* @__PURE__ */ d("small", { children: "/ 40" })]
			}),
			/* @__PURE__ */ d("div", {
				className: "sf-meter",
				children: /* @__PURE__ */ d("i", { style: { width: `${Math.min(100, e.score / 40 * 100)}%` } })
			}),
			/* @__PURE__ */ f("button", {
				type: "button",
				className: "sf-pile-button",
				onClick: o,
				"aria-label": `${t} · ${s("games.schadenfreude.pile", { n: x(e.pile) })}`,
				children: [/* @__PURE__ */ d("span", { children: s("games.schadenfreude.pile", { n: x(e.pile) }) }), /* @__PURE__ */ d("div", {
					ref: u,
					className: "sf-pile",
					style: { visibility: p ? "hidden" : void 0 },
					children: e.pile.map((e) => /* @__PURE__ */ d("span", {
						className: `sf-pip sf-suit-${Math.floor(e / 12)}`,
						title: String(_(e)),
						children: _(e)
					}, e))
				})]
			}),
			/* @__PURE__ */ d("small", {
				className: "sf-seat-count",
				children: s("games.schadenfreude.handCount", { n: e.handCount })
			})
		]
	});
}
//#endregion
//#region src/games/schadenfreude/bot.ts
var G = {
	samples: 8,
	bustPenalty: 75,
	opponentWeight: .3
};
function K(e) {
	let t = 2166136261;
	for (let n of e) t = Math.imul(t ^ n.charCodeAt(0), 16777619);
	return t >>> 0;
}
function q(e) {
	let t = e || 1;
	return () => (t ^= t << 13, t ^= t >>> 17, t ^= t << 5, (t >>> 0) / 4294967296);
}
function J(e, t, n, r, i) {
	let a = Object.fromEntries(e.players.map((e) => [e.rid, Math.max(0, e.score + x(e.rid === n ? S(e.pile, r).kept : e.pile))]));
	if (e.players.every((n) => n.handCount <= (n.rid === t ? 1 : +!e.trick.some((e) => e.rid === n.rid))) && Object.values(a).some((e) => e > 40)) return E(e.players.map((e) => e.rid), a).winner.includes(t) ? 160 : -i.bustPenalty;
	let o = (e) => e <= 40 ? e : 40 - i.bustPenalty - (e - 40) * 4;
	return o(a[t]) - i.opponentWeight * Math.max(...e.players.filter((e) => e.rid !== t).map((e) => o(a[e.rid])));
}
function Y(e, t, n, r) {
	let i = t.legal, a = b(e.players.length).filter((n) => !e.seen.includes(n) && !t.hand.includes(n)), o = K(`${n}:${e.round}:${e.trickNumber}:${e.seen.join(",")}:${t.hand.join(",")}`), s = i[0], c = -Infinity;
	for (let t of i) {
		let i = q(o), l = Math.max(1, r.samples), u = 0;
		for (let o = 0; o < l; o++) {
			let o = [...a], s = [...e.trick, {
				rid: n,
				card: t
			}], c = e.players.findIndex((e) => e.rid === n);
			for (; s.length < e.players.length;) {
				c = (c + 1) % e.players.length;
				let t = e.players[c], n = e.voids[t.rid] ?? [], r = o.filter((e) => v(e) || !n.includes(g(e))), a = [], l = [...r];
				for (let e = 0; e < Math.min(t.handCount, r.length); e++) a.push(...l.splice(Math.floor(i() * l.length), 1));
				let u = w(a, s), d = u[Math.floor(i() * u.length)] ?? o[0];
				s.push({
					rid: t.rid,
					card: d
				}), o.splice(o.indexOf(d), 1);
			}
			let l = T(s);
			u += J(e, n, l.winner, l.taken, r);
		}
		let d = u / l;
		d > c && (s = t, c = d);
	}
	return s;
}
function X(e = G) {
	return (t, n) => {
		let r = t.public, i = t.private;
		return i?.needsAction ? r.phase === "roundOver" ? { action: { type: "next" } } : i.legal.length ? { action: {
			type: "play",
			card: n.difficulty === "weak" ? i.legal[Math.floor(Math.random() * i.legal.length)] : Y(r, i, n.rid, e)
		} } : null : null;
	};
}
var Z = X(), Q = (e, t, n) => e.type === "next" ? n("games.schadenfreude.next") : e.type === "play" ? n("games.schadenfreude.hintPlay", {
	suit: n(y[g(e.card)]),
	n: _(e.card)
}) : "";
//#endregion
//#region src/games/schadenfreude/fx.tsx
function $({ card: e, box: t }) {
	return /* @__PURE__ */ d("img", {
		src: B(e),
		alt: "",
		style: {
			display: "block",
			width: t.w,
			height: t.h,
			objectFit: "contain",
			borderRadius: 4
		}
	});
}
var ee = {
	deal(e, t) {
		let n = e.secret?.cards, r = t.anchor("table");
		if (!n || !r) return null;
		let i = [], a = [];
		for (let [e, o] of n.entries()) {
			let n = t.anchor(`hand:${o}`);
			if (!n) continue;
			let s = {
				x: r.x + r.w / 2 - n.w / 2,
				y: r.y + r.h / 2 - n.h / 2,
				w: n.w,
				h: n.h
			};
			i.push(`hand:${o}`), a.push(/* @__PURE__ */ d(m, {
				from: s,
				to: n,
				ms: 320,
				delay: e * 20,
				children: /* @__PURE__ */ d($, {
					card: o,
					box: s
				})
			}, o));
		}
		return {
			ms: P.deal - 50,
			hide: i,
			node: a
		};
	},
	play(e, t) {
		let n = e.data.card, r = t.anchor(`trick:${e.rid}`), i = t.anchor(`seat:${e.rid}`);
		if (!r || !i) return null;
		let a = {
			x: i.x + i.w / 2 - r.w / 2,
			y: i.y + i.h / 2 - r.h / 2,
			w: r.w,
			h: r.h
		};
		return {
			ms: P.play,
			hide: [`trick:${e.rid}`],
			node: /* @__PURE__ */ d(m, {
				from: a,
				to: r,
				ms: P.play - 30,
				children: /* @__PURE__ */ d($, {
					card: n,
					box: a
				})
			})
		};
	},
	collect(e, t) {
		let n = e.data, r = t.anchor(`pile:${e.rid}`), i = t.anchor("discard");
		return !r || !i ? null : {
			ms: P.collect - 30,
			hide: [`pile:${e.rid}`],
			node: /* @__PURE__ */ f(u, { children: [n.plays.map((e, a) => {
				let o = t.anchor(`trick:${e.rid}`);
				if (!o) return null;
				let s = n.taken.includes(e.card) ? r : i, c = {
					x: s.x + s.w / 2 - 12,
					y: s.y + s.h / 2 - 18,
					w: 24,
					h: 36
				};
				return /* @__PURE__ */ d(m, {
					from: o,
					to: c,
					ms: P.collect - 180,
					delay: a * 20,
					children: /* @__PURE__ */ d($, {
						card: e.card,
						box: o
					})
				}, e.rid);
			}), n.removed.length > 0 && /* @__PURE__ */ d(p, {
				at: r,
				ms: P.collect - 60,
				delay: 80,
				children: /* @__PURE__ */ d("span", {
					style: {
						color: "#f4d49a",
						fontSize: 24,
						textDecoration: "line-through",
						background: "#1a1c22",
						padding: "2px 8px"
					},
					children: n.removed.map(_).join(" · ")
				})
			})] })
		};
	},
	score(e, t) {
		let n = e.data.points;
		return {
			ms: P.score - 100,
			node: Object.entries(n).map(([e, n]) => {
				let r = t.anchor(`score:${e}`);
				return r ? /* @__PURE__ */ d(p, {
					at: r,
					ms: P.score - 150,
					children: /* @__PURE__ */ f("span", {
						style: {
							color: "#f4d49a",
							fontSize: 28
						},
						children: [n > 0 ? "+" : "", n]
					})
				}, e) : null;
			})
		};
	}
};
//#endregion
//#region src/games/schadenfreude/game-over.tsx
function te({ public: e, result: t, members: n, myRid: r, hintCount: o, onPlayAgain: s, onBackToLobby: c }) {
	let p = e, m = a(), h = i((e) => e.locale), g = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? l(t, h) : e;
	};
	return /* @__PURE__ */ f("div", {
		className: "sf-root sf-over",
		children: [
			/* @__PURE__ */ f("header", {
				className: "sf-over-heading",
				children: [
					/* @__PURE__ */ d("span", { children: m("games.schadenfreude.name") }),
					/* @__PURE__ */ d("h1", { children: m("games.schadenfreude.finalTitle") }),
					!t.winner.length && /* @__PURE__ */ d("p", { children: m("games.schadenfreude.noWinner") }),
					o !== void 0 && /* @__PURE__ */ d("p", { children: m("session.hint.usedCount", { n: o }) })
				]
			}),
			/* @__PURE__ */ f("main", {
				className: "sf-over-main",
				children: [/* @__PURE__ */ d("div", {
					className: "sf-results",
					children: t.ranking.map((e) => {
						let n = p.players.find((t) => t.rid === e), i = t.winner.includes(e), a = p.players.some((t) => t.rid !== e && t.score === n.score);
						return /* @__PURE__ */ f("section", {
							className: `sf-result${i ? " sf-result--winner" : ""}`,
							children: [/* @__PURE__ */ d("img", {
								src: B(i ? 49 : 48),
								alt: ""
							}), /* @__PURE__ */ f("div", { children: [
								/* @__PURE__ */ f("h2", { children: [g(e), r === e && /* @__PURE__ */ f("small", { children: [" · ", m("lobby.you")] })] }),
								/* @__PURE__ */ f("strong", { children: [n.score, /* @__PURE__ */ d("small", { children: " / 40" })] }),
								/* @__PURE__ */ d("p", { children: m(i ? "games.schadenfreude.winner" : n.score > 40 ? "games.schadenfreude.bust" : a ? "games.schadenfreude.tied" : "games.schadenfreude.eliminated") }),
								t.autopilot?.[e] !== void 0 && /* @__PURE__ */ d("small", { children: m("session.autopilot.share", { n: Math.round(t.autopilot[e] * 100) }) })
							] })]
						}, e);
					})
				}), /* @__PURE__ */ f("section", {
					className: "sf-over-scores",
					children: [/* @__PURE__ */ d("h2", { children: m("games.schadenfreude.scoreTitle") }), /* @__PURE__ */ d(H, {
						pub: p,
						nameOf: g
					})]
				})]
			}),
			/* @__PURE__ */ d("footer", {
				className: "sf-over-actions",
				children: s || c ? /* @__PURE__ */ f(u, { children: [s && /* @__PURE__ */ d("button", {
					type: "button",
					className: "sf-primary",
					onClick: s,
					children: m("session.result.playAgain")
				}), c && /* @__PURE__ */ d("button", {
					type: "button",
					className: "sf-secondary",
					onClick: c,
					children: m("session.result.backToLobby")
				})] }) : /* @__PURE__ */ d("p", { children: m("session.result.waitHost") })
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/schadenfreude/entry.tsx
var ne = {
	definition: z,
	View: U,
	bot: Z,
	describe: Q,
	fx: ee,
	OverView: te,
	locales: {
		zh: {
			name: "幸灾乐祸",
			desc: "第二高者赢墩，收牌抵消，争取不超过40分的唯一高分",
			rules: "目标：有人累计超过40分时结束，未超过40分的玩家中，分数最高且没有与别人并列者获胜。\n准备：\n· 50张牌包括蓝剑、绿旗、紫盾、红盔四种花色，每色为−3、−2、−1和1至9，另有0和10两张万能骑士。\n· 三人时移除各花色的−2、−1和9，使用38张牌，每人发12张，余下2张不用。四人使用全部50张，每人发12张，余下2张不用。五人每人发10张。\n出牌：\n· 首轮随机选一人领出，之后顺时针每人出一张。有领出花色时，必须出该花色或万能骑士；没有该花色时，可以出任意牌，不强制出万能骑士。万能骑士领出时，第一张普通牌决定本墩花色。\n· 万能骑士视为本墩花色。该花色中第二高的牌赢墩；只有一张符合条件时，该牌赢墩。赢家下一墩领出。\n收集：\n· 赢家只收自己打出的牌，以及所有未跟本墩花色的普通牌，其余牌弃置。收集区向所有人公开。\n· 收集区中点数相同的牌两两抵消，与花色无关；三张保留一张，四张全部抵消。\n轮末：\n· 打完手牌后，将收集区剩余牌的点数总和加入累计分；累计分低于0时按0计算。\n· 没有人超过40分时，重新洗牌开始下一轮，累计最低分者领出；最低分并列时，从上轮领出者的下一位起选第一位最低分玩家。\n结束：\n· 恰好40分不触发结束。有人严格超过40分时，所有超过40分的人失去胜利资格。其余人从最高分起比较，该分数有多人并列时，这些人均不能获胜，继续比较下一档，首个独占该分数的人获胜。若所有有效分数均并列，或所有人均超过40分，则无人获胜。",
			sword: "蓝剑",
			flag: "绿旗",
			shield: "紫盾",
			helm: "红盔",
			knight: "万能骑士",
			round: "第 {{n}} 轮",
			trick: "第 {{n}} 墩",
			turnYou: "轮到你出牌",
			turnWait: "等待 {{name}} 出牌",
			dealing: "发牌中",
			reveal: "{{name}} 赢墩",
			collecting: "{{name}} 收牌",
			scoring: "本轮计分",
			roundOver: "本轮结束",
			lead: "本墩花色：{{suit}}",
			wildLead: "首张普通牌决定花色",
			leadBy: "{{name}} 领出",
			card: "{{suit}} {{n}}",
			hand: "你的手牌",
			play: "出牌",
			next: "进入下一轮",
			ready: "已准备",
			waiting: "等待其他玩家",
			total: "累计分",
			pile: "本轮 {{n}} 分",
			emptyPile: "尚未收牌",
			handCount: "余牌 {{n}} 张",
			scoreTitle: "逐轮得分",
			scoreRound: "轮次",
			finalTitle: "骑士的终局",
			winner: "获胜",
			noWinner: "本局无人获胜",
			bust: "超过40分",
			tied: "分数并列",
			eliminated: "未获胜",
			finalTotal: "总分",
			logTrick: "第 {{r}} 轮第 {{n}} 墩：{{name}} 收取 {{cards}}",
			logRemoved: "抵消 {{cards}}",
			logRound: "第 {{r}} 轮：{{scores}}",
			errTurn: "当前不能执行此操作",
			errCard: "这张牌不在你的手牌中",
			errFollow: "你有本墩花色，须出同花色或万能骑士",
			hintPlay: "打出{{suit}} {{n}}"
		},
		en: {
			name: "Schadenfreude",
			desc: "Second highest takes the trick. Cancel pairs and aim for a unique high score under 41.",
			rules: "Goal: when anyone exceeds 40 points, win with the highest unshared score of 40 or less.\nSetup:\n· There are 50 cards: blue swords, green flags, purple shields and red helms, each with −3, −2, −1 and 1–9; plus wild knights 0 and 10.\n· With 3 players, remove −2, −1 and 9 from each suit, leaving 38 cards. Deal 12 each and set 2 aside. With 4 players, use all 50, deal 12 each and set 2 aside. With 5 players, deal 10 each.\nPlay:\n· A random player leads the first round. Play one card each in clockwise order. If you have the led suit, play that suit or a wild knight. If you have none, play any card; a wild is not compulsory. When a wild leads, the first non-wild card sets the suit.\n· Wilds count as the led suit. The second highest card of that suit wins; if only one card qualifies, it wins. The winner leads the next trick.\nCollect:\n· The winner collects their own card and all non-wild cards that did not follow suit. Discard the rest. Score piles are public.\n· Equal ranks in a score pile cancel in pairs, regardless of suit: three leave one, four cancel entirely.\nRound end:\n· Once all hands are empty, add the ranks left in each score pile to that player’s total. A total below 0 becomes 0.\n· If no one exceeds 40, reshuffle for another round. The lowest total leads; on a tie, choose the first tied player clockwise after the previous round’s leader.\nGame end:\n· Exactly 40 does not end the game. If anyone exceeds 40, all players over 40 are eliminated. Compare remaining scores from highest to lowest. If a score is shared, none of those players can win; check the next score. The first unshared score wins. If all eligible scores are shared, or everyone exceeds 40, there is no winner.",
			sword: "Blue sword",
			flag: "Green flag",
			shield: "Purple shield",
			helm: "Red helm",
			knight: "Wild knight",
			round: "Round {{n}}",
			trick: "Trick {{n}}",
			turnYou: "Your turn",
			turnWait: "Waiting for {{name}}",
			dealing: "Dealing",
			reveal: "{{name}} wins the trick",
			collecting: "{{name}} collects",
			scoring: "Scoring the round",
			roundOver: "Round complete",
			lead: "Led suit: {{suit}}",
			wildLead: "First non-wild sets the suit",
			leadBy: "{{name}} leads",
			card: "{{suit}} {{n}}",
			hand: "Your hand",
			play: "Play",
			next: "Next round",
			ready: "Ready",
			waiting: "Waiting for other players",
			total: "Total",
			pile: "Round: {{n}}",
			emptyPile: "No cards collected",
			handCount: "Cards left: {{n}}",
			scoreTitle: "Round scores",
			scoreRound: "Round",
			finalTitle: "The knights’ reckoning",
			winner: "Winner",
			noWinner: "No winner this game",
			bust: "Over 40",
			tied: "Shared score",
			eliminated: "Did not win",
			finalTotal: "Total",
			logTrick: "Round {{r}}, trick {{n}}: {{name}} collects {{cards}}",
			logRemoved: "Canceled: {{cards}}",
			logRound: "Round {{r}}: {{scores}}",
			errTurn: "This action is not available now",
			errCard: "That card is not in your hand",
			errFollow: "You have the led suit; play it or a wild knight",
			hintPlay: "Play {{suit}} {{n}}"
		}
	}
};
//#endregion
export { ne as default };
