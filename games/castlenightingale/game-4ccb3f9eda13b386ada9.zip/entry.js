import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { GameScreen as a } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as o } from "@bgparty/sdk/ui/phase-banner";
import { SheetView as s } from "@bgparty/sdk/sheet-view";
import { Fragment as c, jsx as l, jsxs as u } from "react/jsx-runtime";
import { useT as d } from "@bgparty/sdk/i18n";
import { OptionRadio as f, OptionSection as p } from "@bgparty/sdk/ui/game-options";
//#region src/games/castlenightingale/data.ts
var m = [
	"G",
	"P",
	"Y",
	"B",
	"R",
	"T"
], h = {
	G: "#a2b57a",
	P: "#d99bad",
	Y: "#eac66b",
	B: "#74b7cd",
	R: "#db8967",
	T: "#18294c"
}, g = {
	samurai: [
		{
			move: 3,
			effect: "draw",
			count: 1
		},
		{
			move: 2,
			effect: "close",
			count: 1
		},
		{
			move: 1,
			effect: "draw",
			count: 1
		},
		{
			move: 3,
			effect: "vases",
			count: 1
		},
		{
			move: 2,
			effect: "draw",
			count: 1
		},
		{
			move: 2,
			effect: "shift",
			count: 1
		},
		{
			move: 2,
			effect: "vases",
			count: 2
		},
		{
			move: 1,
			effect: "discard",
			count: 1
		},
		{
			move: 1,
			effect: "close",
			count: 1
		},
		{
			move: 4,
			effect: "none",
			count: 0
		}
	],
	ninja: [
		{
			move: 3,
			effect: "shift",
			count: 1
		},
		{
			move: 4,
			effect: "open",
			count: 1
		},
		{
			move: 5,
			effect: "shift",
			count: 1
		},
		{
			move: 3,
			effect: "draw",
			count: 1
		},
		{
			move: 2,
			effect: "none",
			count: 0
		},
		{
			move: 4,
			effect: "vases",
			count: 2
		},
		{
			move: 4,
			effect: "draw",
			count: 1
		},
		{
			move: 3,
			effect: "discard",
			count: 1
		},
		{
			move: 5,
			effect: "draw",
			count: 1
		},
		{
			move: 3,
			effect: "vases",
			count: 1
		}
	]
}, _ = {
	A: [
		[
			"BRYYY",
			"BRTBB",
			"GGGGG",
			"RYYTP",
			"RRRPP"
		],
		[
			"RRPBG",
			"YYPBG",
			"PPPBR",
			"GTYBR",
			"GGYBT"
		],
		[
			"GPYYY",
			"GPYTY",
			"RRRRR",
			"BBTPP",
			"BBGGP"
		],
		[
			"BBBPP",
			"YYYYY",
			"BBRGG",
			"BRRTG",
			"TRPPG"
		]
	],
	B: [
		[
			"GGTPP",
			"GBBBY",
			"TPPYY",
			"YBBTY",
			"YYYGG"
		],
		[
			"GPPRB",
			"GGRRB",
			"RRTGB",
			"RPPGG",
			"BBBBG"
		],
		[
			"TPYYT",
			"RPGGR",
			"RPGPR",
			"GYGPR",
			"GYYPT"
		],
		[
			"PBBRR",
			"PBRRP",
			"RTYYP",
			"RBBBP",
			"RYYYP"
		]
	]
}, v = [
	[12],
	[
		1,
		15,
		19
	],
	[16],
	[
		2,
		10,
		22
	]
], y = (e, t) => e >= 5 && e <= 6 && t >= 5 && t <= 6;
function b(e, t, n) {
	let r = [
		[2, 0],
		[7, 2],
		[5, 7],
		[0, 5]
	], i = [], a = [];
	for (let o = 0; o < 4; o++) {
		let s = t[o];
		for (let t = 0; t < 5; t++) for (let c = 0; c < 5; c++) {
			let l = c, u = t;
			for (let e = 0; e < n[o]; e++) [l, u] = [4 - u, l];
			l += r[o][0], u += r[o][1];
			let d = u * 12 + l;
			i.push({
				id: d,
				x: l,
				y: u,
				floor: o,
				color: _[e][s][t][c],
				zone: -1,
				outer: !1
			}), (e === "A" ? [
				2,
				10,
				14,
				22
			] : v[s]).includes(t * 5 + c) && a.push(d);
		}
	}
	let o = new Map(i.map((e) => [e.id, e])), s = new Set(i.map((e) => `${e.x},${e.y}`)), c = 0;
	for (let e of i) {
		if (e.outer = [
			[0, 1],
			[0, -1],
			[1, 0],
			[-1, 0]
		].some(([t, n]) => !s.has(`${e.x + t},${e.y + n}`) && !y(e.x + t, e.y + n)), e.zone >= 0 || (e.zone = c++, e.color === "T")) continue;
		let t = [e];
		for (; t.length;) {
			let n = t.pop();
			for (let r of i) r.zone < 0 && r.color === e.color && Math.abs(r.x - n.x) + Math.abs(r.y - n.y) === 1 && (r.zone = e.zone, t.push(r));
		}
	}
	return {
		cells: i,
		stars: a.filter((t) => e === "B" || o.get(t).outer)
	};
}
function x(e, t) {
	let n = e.find((e) => e.id === t);
	return n ? e.filter((e) => Math.abs(e.x - n.x) + Math.abs(e.y - n.y) === 1).map((e) => e.id) : [];
}
function S(e, t, n = !1, r = !0) {
	let i = e.find((e) => e.id === t)?.zone, a = t === 144 ? [] : e.filter((e) => e.zone === i), o = /* @__PURE__ */ new Set();
	for (let t of a) for (let n of x(e, t.id)) {
		let t = e.find((e) => e.id === n);
		t.zone !== i && o.add(t.zone);
	}
	if (t === 144) for (let t of e) [
		[0, 1],
		[0, -1],
		[1, 0],
		[-1, 0]
	].some(([e, n]) => y(t.x + e, t.y + n)) && o.add(t.zone);
	let s = e.filter((e) => o.has(e.zone)).map((e) => e.id);
	return n && r && a.some((e) => [
		[0, 1],
		[0, -1],
		[1, 0],
		[-1, 0]
	].some(([t, n]) => y(e.x + t, e.y + n))) && s.push(144), s;
}
//#endregion
//#region src/games/castlenightingale/meta.ts
var C = {
	id: "castlenightingale",
	tier: "alpha",
	nameKey: "games.castlenightingale.name",
	descKey: "games.castlenightingale.desc",
	rulesKey: "games.castlenightingale.rules",
	icon: "🏯",
	iconImg: "games/castlenightingale.webp",
	rulesUrl: { en: "https://sandcastle-games.com/assets/PDFs/CastleNightingaleRulesEN20250909.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	mechanics: [
		"grid-movement",
		"deduction",
		"action-programming"
	],
	interactionTags: [],
	accent: "#c2964f",
	releasedAt: "2026-11-06T18:00:00+08:00",
	search: {
		py: "ye ying cheng castle nightingale chateau rossignol",
		init: "yyc"
	},
	hotseat: "cover",
	botDelayMs: 550
}, w = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("plan"),
		card: t.int().min(0).max(9),
		tiles: t.array(t.int().min(0).max(5)).max(2)
	}),
	t.object({
		type: t.literal("pick"),
		kind: t.enum([
			"cell",
			"vase",
			"door",
			"card"
		]),
		id: t.int().min(0).max(144)
	}),
	t.object({
		type: t.literal("equipment"),
		id: t.int().min(0).max(6),
		mode: t.enum([
			"use",
			"jump",
			"plus",
			"minus"
		]),
		target: t.int().min(0).max(144).optional()
	}),
	t.object({ type: t.literal("continue") })
]), T = t.object({
	side: t.enum(["A", "B"]).catch("A"),
	randomLayout: t.boolean().catch(!1),
	ninjaSeat: t.int().min(0).max(1).catch(0)
}).default({
	side: "A",
	randomLayout: !1,
	ninjaSeat: 0
}), E = t.enum([
	"setupDoors",
	"setupPawn",
	"sPlan",
	"nPlan",
	"nStart",
	"nMove",
	"singS",
	"singN",
	"sMove",
	"task",
	"cricket",
	"nEnd",
	"sEnd",
	"done"
]), D = t.enum([
	"G",
	"P",
	"Y",
	"B",
	"R",
	"T"
]), O = t.object({
	id: t.int(),
	x: t.int(),
	y: t.int(),
	floor: t.int(),
	color: D,
	zone: t.int(),
	outer: t.boolean()
}), k = t.object({
	id: t.int(),
	cell: t.int().nullable(),
	holder: t.enum([
		"board",
		"bank",
		"current",
		"lost"
	]),
	relic: t.boolean().nullable()
}), A = t.object({
	phase: E,
	turn: t.string().nullable(),
	round: t.int(),
	ninjaRid: t.string(),
	samuraiRid: t.string(),
	side: t.enum(["A", "B"]),
	cells: t.array(O),
	closed: t.array(t.int()),
	samurai: t.int().nullable(),
	ninja: t.int().nullable(),
	footprints: t.array(t.int()),
	left: t.int(),
	caught: t.int(),
	vases: t.array(k),
	previous: t.array(t.int()),
	alarm: t.array(t.int()).nullable(),
	cards: t.object({
		ninja: t.int().nullable(),
		samurai: t.int().nullable()
	}),
	discard: t.object({
		ninja: t.array(t.int()),
		samurai: t.array(t.int())
	}),
	handCounts: t.object({
		ninja: t.int(),
		samurai: t.int()
	}),
	equipmentCounts: t.object({
		ninja: t.int(),
		samurai: t.int()
	}),
	task: t.object({
		kind: t.string(),
		role: t.enum(["ninja", "samurai"]),
		remaining: t.int(),
		selected: t.int().nullable()
	}).nullable(),
	lastEvent: t.object({
		seq: t.int(),
		kind: t.string(),
		from: t.int().nullable(),
		to: t.int().nullable()
	}),
	winner: t.enum(["ninja", "samurai"]).nullable(),
	usedEquipment: t.array(t.object({
		role: t.enum(["ninja", "samurai"]),
		id: t.int()
	}))
}), j = t.object({
	role: t.enum(["ninja", "samurai"]),
	hand: t.array(t.int()),
	equipment: t.array(t.int()),
	programmed: t.int().nullable(),
	legal: t.array(w),
	knownVases: t.array(t.object({
		id: t.int(),
		relic: t.boolean()
	})),
	glimpsedTiles: t.array(t.int()),
	selectedTiles: t.array(t.int()),
	relics: t.int()
}), ee = ["ninja", "samurai"], M = (e) => e === "ninja" ? "samurai" : "ninja", N = (e, t) => t === "ninja" ? e.ninjaRid : e.samuraiRid, P = (e, t) => t === e.ninjaRid ? "ninja" : t === e.samuraiRid ? "samurai" : null, F = (e, t) => e.cells.find((e) => e.id === t), I = (e) => e.cells.filter((e) => e.color === "T").map((e) => e.id), L = (e) => I(e).filter((t) => !e.closed.includes(t)), R = (e, t, n = 1, r = null) => ({
	kind: e,
	role: t,
	remaining: n,
	selected: r,
	used: []
}), z = (e, t, n = null, r = null) => {
	e.lastEvent = {
		seq: e.lastEvent.seq + 1,
		kind: t,
		from: n,
		to: r
	};
};
function B(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.rng++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function V(e, t) {
	let n = e.equipmentDeck[t].shift();
	n !== void 0 && e.equipment[t].push(n);
}
function H(e, t) {
	e.deck[t].length || (e.deck[t] = B(e, e.discard[t]), e.discard[t] = []);
	let n = e.deck[t].shift();
	n !== void 0 && e.hand[t].push(n);
}
function te(e, t, n, r = !0) {
	e.equipment[t].splice(e.equipment[t].indexOf(n), 1), r && e.usedEquipment.push({
		role: t,
		id: n
	});
}
function ne(e) {
	return e.phase === "done" ? null : e.phase === "task" ? e.taskQueue[0]?.role ?? null : [
		"nPlan",
		"nStart",
		"nMove",
		"singN",
		"nEnd",
		"cricket"
	].includes(e.phase) ? "ninja" : "samurai";
}
function re(e, t) {
	return e.cells.filter((n) => n.floor === t && n.color !== "T" && n.id !== e.samurai && n.id !== e.ninja && !e.footprints.includes(n.id) && !e.vases.some((e) => e.holder === "board" && e.cell === n.id)).map((e) => e.id);
}
function U(e, t = !1) {
	let n = F(e, e.cursor);
	if (!n) return [];
	let r = x(e.cells, n.id);
	return n.color === "T" && !e.closed.includes(n.id) && r.push(...L(e)), t && (r = e.cells.filter((t) => (t.x === n.x && Math.abs(t.y - n.y) === 2 || t.y === n.y && Math.abs(t.x - n.x) === 2) && e.cells.some((e) => e.x === (t.x + n.x) / 2 && e.y === (t.y + n.y) / 2)).map((e) => e.id)), e.claws && n.outer && !t && r.push(...e.cells.filter((e) => e.outer && e.color !== n.color).map((e) => e.id)), [...new Set(r)].filter((t) => t !== e.samurai && !e.visited.includes(t));
}
function ie(e, t) {
	let n = (e, t) => t.map((t) => ({
		type: "pick",
		kind: e,
		id: t
	}));
	if (t.kind === "peek" || t.kind === "relocate") return n("vase", e.vases.filter((e) => e.holder === "board" && !t.used.includes(e.id)).map((e) => e.id));
	if (t.kind === "place" || t.kind === "recover") return n("cell", re(e, F(e, e.samurai).floor));
	if (t.kind === "close") return n("door", L(e));
	if (t.kind === "open" || t.kind === "shift" && t.selected === null) return n("door", e.closed.filter((t) => t !== e.samurai));
	if (t.kind === "shift") return n("door", L(e));
	if (t.kind === "reopen") {
		let r = e.closed.filter((n) => n !== e.samurai && !t.used.includes(F(e, n).floor));
		return n("door", r.length ? r : e.closed.filter((t) => t !== e.samurai));
	}
	return [];
}
function ae(e, t) {
	let n = P(e, t);
	if (!n || ne(e) !== n) return [];
	let r = [], i = (e, t) => {
		for (let n of t) r.push({
			type: "pick",
			kind: e,
			id: n
		});
	};
	if (e.phase === "setupDoors" && i("door", L(e)), e.phase === "setupPawn" && i("cell", e.cells.filter((t) => t.color !== "T" && !e.vases.some((e) => e.cell === t.id)).map((e) => e.id)), e.phase === "sPlan") {
		let t = m.map((e, t) => t).filter((t) => !e.previous.includes(t));
		for (let n of e.hand.samurai) for (let i of t) if (!e.pair) r.push({
			type: "plan",
			card: n,
			tiles: [i]
		});
		else for (let e of t.filter((e) => e > i)) r.push({
			type: "plan",
			card: n,
			tiles: [i, e]
		});
	}
	if (e.phase === "nPlan") for (let t of e.hand.ninja) r.push({
		type: "plan",
		card: t,
		tiles: []
	});
	e.phase === "nStart" && i("cell", e.ninja === null ? e.footprints.length ? e.footprints : L(e).filter((t) => t !== e.samurai) : [e.ninja]), e.phase === "nMove" && i("cell", U(e)), (e.phase === "sMove" || e.phase === "cricket") && i("cell", S(e.cells, e.samurai, e.keys, e.left > 1)), e.phase === "task" && r.push(...ie(e, e.taskQueue[0])), [
		"singS",
		"singN",
		"nEnd",
		"sEnd"
	].includes(e.phase) && r.push({ type: "continue" }), e.phase === "nMove" && !U(e).length && !e.equipment.ninja.some(() => !e.jumped && U(e, !0).length) && r.push({ type: "continue" });
	for (let t of e.equipment[n]) {
		let i = (e) => r.push({
			type: "equipment",
			id: t,
			mode: "use",
			...e === void 0 ? {} : { target: e }
		});
		if (n === "ninja") {
			if (t === 0 && e.phase === "nPlan" && m.length - e.previous.length - e.tiles.length >= 2 && i(), [
				1,
				2,
				3
			].includes(t) && [
				"nStart",
				"nMove",
				"singS",
				"singN",
				"task"
			].includes(e.phase) && i(), t === 4 && e.phase === "nMove" && e.footprints.includes(e.cursor) && F(e, e.cursor)?.outer && !e.claws && i(), t === 5 && e.phase === "singN" && i(), t === 6 && e.phase === "nEnd") for (let t of [...e.discard.ninja, e.chosen.ninja]) i(t);
			if (e.phase === "nMove" && !e.jumped) for (let n of U(e, !0)) r.push({
				type: "equipment",
				id: t,
				mode: "jump",
				target: n
			});
		} else {
			if (t === 0 && e.phase === "singS" && e.vases.some((e) => e.holder === "bank" || e.holder === "current") && i(), t === 1 && e.phase === "sMove" && !e.keys && i(), t === 2 && e.phase === "sPlan" && e.previous.length && i(), t === 3 && ["sMove", "sEnd"].includes(e.phase) && e.ninja !== null && F(e, e.samurai)?.floor === F(e, e.ninja)?.floor && i(), t === 4 && e.phase === "sPlan" && !e.pair && i(), t === 5 && e.phase === "sPlan" && e.footprints.length > 1) for (let t of e.footprints) i(t);
			if (t === 6 && e.phase === "sEnd") for (let t of [...e.discard.samurai, e.chosen.samurai]) i(t);
			e.phase === "sMove" && !e.adjusted && (r.push({
				type: "equipment",
				id: t,
				mode: "plus"
			}), e.left > 0 && e.samurai !== 144 && r.push({
				type: "equipment",
				id: t,
				mode: "minus"
			}));
		}
	}
	return r;
}
function oe(t, n) {
	let r = g[n][t.chosen[n]];
	if (r.effect === "draw") return V(t, n), [];
	if (r.effect === "discard") {
		let r = M(n), i = t.equipment[r];
		return i.length && i.splice(e(t.seed, t.rng++, i.length), 1), [];
	}
	return r.effect === "none" ? [] : [R(r.effect === "vases" ? n === "ninja" ? "peek" : "relocate" : r.effect, n, r.count)];
}
function W(e) {
	e.phase = "sMove", e.alarmRevealed = !0, e.samuraiRevealed = !0, e.left = e.skipMove ? 0 : g.samurai[e.chosen.samurai].move, z(e, "reveal");
}
function G(e, t, n) {
	e.taskQueue.push(...t), e.resume = n, e.phase = "task";
}
function K(e, t) {
	let n = [];
	e.capturedTurn || (e.caught++, e.capturedTurn = !0, z(e, "capture", e.ninja, e.samurai), e.ninja = null, e.footprints = [], n.push(...e.vases.filter((e) => e.holder === "current").map((e) => R("recover", "samurai", 1, e.id)))), t && !e.taskQueue.some((e) => e.kind === "reopen") && n.push(R("reopen", "samurai", 4)), n.length && (e.phase === "task" ? e.taskQueue.unshift(...n) : G(e, n, e.phase));
}
function se(e) {
	e.ninja !== null && F(e, e.ninja)?.zone === F(e, e.samurai)?.zone && K(e, !1), e.closed.length === I(e).length && K(e, !0);
}
function ce(e, t) {
	let n = e.samurai;
	e.samurai = t, e.left--, z(e, "samuraiMove", n, t), F(e, t)?.color === "T" && !e.closed.includes(t) && e.closed.push(t), se(e);
}
function q(e, t) {
	let n = e.cursor;
	e.cursor = t, e.visited.push(t), e.footprints.push(t), e.left--, e.claws = !1, z(e, "ninjaMove", n, t);
	for (let n of e.vases.filter((e) => e.holder === "board" && e.cell === t)) n.holder = "current", n.cell = null, e.known.ninja.includes(n.id) || e.known.ninja.push(n.id);
	e.smoke && (e.ninja = t), !e.smoke && e.tiles.some((n) => m[n] === F(e, t)?.color) && (e.ninja = t, e.footprints = [], e.alarmRevealed = !0, e.phase = "singS", z(e, "alarm", n, t));
}
function le(e) {
	e.footprints = e.footprints.filter((t) => t !== e.samurai);
	let t = e.vases.find((t) => t.holder === "board" && t.cell === e.samurai), n = [];
	t && (e.known.samurai.includes(t.id) || e.known.samurai.push(t.id), n.push(R("place", "samurai", 1, t.id))), e.skipAction || n.push(R("effect", "samurai")), G(e, n, "nEnd");
}
function J(e, t, n) {
	e.discard[t].push(e.chosen[t]), n === void 0 ? H(e, t) : (e.discard[t].splice(e.discard[t].indexOf(n), 1), e.hand[t].push(n));
}
function ue(e) {
	for (let t of e.vases) t.holder === "current" && (t.holder = "bank");
	if (e.caught >= 3 ? e.winner = "samurai" : e.vases.filter((e) => e.holder === "bank" && e.relic).length >= 5 && (e.winner = "ninja"), e.winner) {
		e.phase = "done", z(e, "victory");
		return;
	}
	e.previous = [...e.tiles], e.tiles = [], e.alarmRevealed = !1, e.samuraiRevealed = !1, e.chosen = {
		ninja: null,
		samurai: null
	}, e.round++, e.phase = "sPlan", e.left = 0, e.glimpse = [], e.capturedTurn = !1, e.skipMove = !1, e.skipAction = !1, e.keys = !1, e.adjusted = !1, e.jumped = !1, e.claws = !1, e.smoke = !1, e.pair = !1;
}
function de(e) {
	for (let t = 0; t < 30; t++) {
		if (e.phase === "task") {
			let t = e.taskQueue[0];
			if (!t) {
				e.phase = e.resume;
				continue;
			}
			if (t.kind === "effect") {
				e.taskQueue.shift(), e.taskQueue.unshift(...oe(e, t.role));
				continue;
			}
			if (t.remaining <= 0 || !ie(e, t).length) {
				e.taskQueue.shift();
				continue;
			}
		}
		if (e.capturedTurn && [
			"nStart",
			"nMove",
			"cricket",
			"singN",
			"singS"
		].includes(e.phase)) {
			W(e);
			continue;
		}
		if (e.phase === "nMove" && e.left <= 0) {
			e.ninja = e.smoke ? e.cursor : null, e.smoke && (e.footprints = []), W(e);
			continue;
		}
		if (e.phase === "sMove" && e.left <= 0) {
			le(e);
			continue;
		}
		if (e.phase === "cricket" && e.left <= 0) {
			e.phase = e.cricketReturn, e.left = e.cricketLeft;
			continue;
		}
		if (e.phase === "singS" && (!e.equipment.samurai.includes(0) || !e.vases.some((e) => e.holder === "bank" || e.holder === "current"))) {
			e.phase = "singN";
			continue;
		}
		if (e.phase === "singN" && !e.equipment.ninja.includes(5)) {
			W(e);
			continue;
		}
		return;
	}
}
function fe(e, t) {
	let n = e.taskQueue[0], r = t.id;
	if (n.kind === "peek") e.known.ninja.includes(r) || e.known.ninja.push(r), n.used.push(r), n.remaining--, z(e, "peek");
	else if (n.kind === "relocate") e.known.samurai.includes(r) || e.known.samurai.push(r), n.selected = r, n.kind = "place";
	else if (n.kind === "place" || n.kind === "recover") {
		let t = e.vases.find((e) => e.id === n.selected), i = t.cell;
		t.cell = r, t.holder = "board", z(e, "vaseMove", i, r), n.used.push(t.id), n.remaining--, n.selected = null, n.kind === "place" && (n.kind = "relocate");
	} else n.kind === "shift" && n.selected === null ? n.selected = r : n.kind === "shift" ? (e.closed = e.closed.filter((e) => e !== n.selected), e.closed.push(r), n.remaining--, z(e, "door", n.selected, r)) : n.kind === "open" || n.kind === "reopen" ? (e.closed = e.closed.filter((e) => e !== r), n.remaining--, n.used.push(F(e, r).floor), z(e, "door", r)) : n.kind === "close" && (e.closed.push(r), n.remaining--, z(e, "door", null, r));
	n.remaining <= 0 && e.taskQueue.shift(), se(e);
}
function pe(t, n, r) {
	if (te(t, r, n.id, n.mode === "use"), z(t, "equipment"), n.mode === "jump") {
		t.jumped = !0, q(t, n.target);
		return;
	}
	if (n.mode === "plus" || n.mode === "minus") {
		t.adjusted = !0, t.left += n.mode === "plus" ? 1 : -1;
		return;
	}
	if (r === "ninja") n.id === 0 && (t.glimpse = B(t, m.map((e, t) => t).filter((e) => !t.previous.includes(e) && !t.tiles.includes(e))).slice(0, 2)), n.id === 1 && (t.skipAction = !0), n.id === 2 && (t.skipMove = !0), n.id === 3 && (t.cricketReturn = t.phase, t.cricketLeft = t.left, t.phase = "cricket", t.left = 2), n.id === 4 && (t.claws = !0), n.id === 5 && (t.smoke = !0, t.phase = "nMove"), n.id === 6 && (J(t, "ninja", n.target), t.phase = "sEnd");
	else {
		if (n.id === 0) {
			let n = t.vases.filter((e) => e.holder === "bank" || e.holder === "current"), r = n[e(t.seed, t.rng++, n.length)];
			r.holder = "lost", r.cell = null, t.phase = "singN";
		}
		n.id === 1 && (t.keys = !0), n.id === 2 && (t.previous = []), n.id === 3 && K(t, !1), n.id === 4 && (t.pair = !0), n.id === 5 && (t.footprints = [n.target]), n.id === 6 && (J(t, "samurai", n.target), ue(t));
	}
}
var me = {
	meta: C,
	saveCompatibility: { version: "1" },
	schemas: {
		action: w,
		publicView: A,
		privateView: j,
		config: T
	},
	setup(t, n, r) {
		let i = {
			players: [...n],
			ninjaRid: n[t.ninjaSeat],
			samuraiRid: n[1 - t.ninjaSeat],
			seed: r,
			rng: 0,
			config: t,
			cells: [],
			vases: [],
			closed: [],
			samurai: null,
			ninja: null,
			phase: "setupDoors",
			round: 1,
			left: 0,
			footprints: [],
			visited: [],
			cursor: null,
			caught: 0,
			capturedTurn: !1,
			chosen: {
				ninja: null,
				samurai: null
			},
			tiles: [],
			previous: [],
			alarmRevealed: !1,
			samuraiRevealed: !1,
			hand: {
				ninja: [],
				samurai: []
			},
			deck: {
				ninja: [],
				samurai: []
			},
			discard: {
				ninja: [],
				samurai: []
			},
			equipment: {
				ninja: [],
				samurai: []
			},
			equipmentDeck: {
				ninja: [],
				samurai: []
			},
			usedEquipment: [],
			known: {
				ninja: [],
				samurai: []
			},
			glimpse: [],
			taskQueue: [],
			resume: "nEnd",
			cricketReturn: "nStart",
			cricketLeft: 0,
			skipMove: !1,
			skipAction: !1,
			keys: !1,
			adjusted: !1,
			jumped: !1,
			claws: !1,
			smoke: !1,
			pair: !1,
			winner: null,
			lastEvent: {
				seq: 0,
				kind: "setup",
				from: null,
				to: null
			}
		}, a = t.randomLayout ? B(i, [
			0,
			1,
			2,
			3
		]) : [
			0,
			1,
			2,
			3
		], o = t.randomLayout ? a.map(() => e(r, i.rng++, 4)) : [
			0,
			1,
			2,
			3
		], s = b(t.side, a, o);
		i.cells = s.cells;
		let c = B(i, [
			!0,
			!0,
			!0,
			!0,
			!0,
			!0,
			!1,
			!1
		]);
		i.vases = s.stars.map((e, t) => ({
			id: t,
			cell: e,
			relic: c[t],
			holder: "board"
		}));
		for (let e of ee) {
			i.deck[e] = B(i, Array.from({ length: 10 }, (e, t) => t)), i.equipmentDeck[e] = B(i, Array.from({ length: 7 }, (e, t) => t));
			for (let t = 0; t < 3; t++) H(i, e);
			V(i, e);
		}
		return { state: i };
	},
	reduce(e, t, n) {
		if (!ae(e, n.by).some((e) => JSON.stringify(e) === JSON.stringify(t))) return { code: "games.castlenightingale.invalid" };
		let r = structuredClone(e), i = P(r, n.by);
		return t.type === "equipment" ? pe(r, t, i) : t.type === "plan" ? (r.chosen[i] = t.card, r.hand[i].splice(r.hand[i].indexOf(t.card), 1), z(r, "program"), i === "samurai" ? (r.tiles = [...t.tiles], r.phase = "nPlan") : (G(r, oe(r, "ninja"), "nStart"), z(r, "reveal"))) : t.type === "continue" ? r.phase === "singS" ? r.phase = "singN" : r.phase === "singN" ? W(r) : r.phase === "nMove" ? (r.left = 0, r.ninja = r.smoke ? r.cursor : null) : r.phase === "nEnd" ? (J(r, "ninja"), r.phase = "sEnd") : r.phase === "sEnd" && (J(r, "samurai"), ue(r)) : r.phase === "task" ? fe(r, t) : r.phase === "setupDoors" ? (r.closed.push(t.id), z(r, "door", null, t.id), r.closed.length === 2 && (r.phase = "setupPawn")) : r.phase === "setupPawn" ? (r.samurai = t.id, r.phase = "sPlan", z(r, "samuraiMove", null, t.id)) : r.phase === "nStart" ? (r.ninja = t.id, r.cursor = t.id, r.visited = [t.id], r.footprints = [], r.phase = "nMove", r.left = g.ninja[r.chosen.ninja].move, z(r, "enter", null, t.id)) : r.phase === "nMove" ? q(r, t.id) : (r.phase === "sMove" || r.phase === "cricket") && ce(r, t.id), de(r), { state: r };
	},
	viewFor(e, t) {
		let n = P(e, t), r = ne(e), i = e.taskQueue[0], a = ![
			"setupDoors",
			"setupPawn",
			"sPlan",
			"nPlan"
		].includes(e.phase);
		return {
			public: {
				phase: e.phase,
				turn: r ? N(e, r) : null,
				round: e.round,
				ninjaRid: e.ninjaRid,
				samuraiRid: e.samuraiRid,
				side: e.config.side,
				cells: structuredClone(e.cells),
				closed: [...e.closed],
				samurai: e.samurai,
				ninja: e.ninja,
				footprints: [...e.footprints],
				left: e.left,
				caught: e.caught,
				vases: e.vases.map((t) => ({
					...t,
					relic: e.winner ? t.relic : null
				})),
				previous: [...e.previous],
				alarm: e.alarmRevealed ? [...e.tiles] : null,
				cards: {
					ninja: a ? e.chosen.ninja : null,
					samurai: e.samuraiRevealed ? e.chosen.samurai : null
				},
				discard: structuredClone(e.discard),
				handCounts: {
					ninja: e.hand.ninja.length,
					samurai: e.hand.samurai.length
				},
				equipmentCounts: {
					ninja: e.equipment.ninja.length,
					samurai: e.equipment.samurai.length
				},
				task: e.phase === "task" && i ? {
					kind: i.kind,
					role: i.role,
					remaining: i.remaining,
					selected: i.selected
				} : null,
				lastEvent: { ...e.lastEvent },
				winner: e.winner,
				usedEquipment: structuredClone(e.usedEquipment)
			},
			...n ? { private: {
				role: n,
				hand: [...e.hand[n]],
				equipment: [...e.equipment[n]],
				programmed: e.chosen[n],
				legal: ae(e, t),
				knownVases: e.known[n].map((t) => ({
					id: t,
					relic: e.vases.find((e) => e.id === t).relic
				})),
				glimpsedTiles: n === "ninja" ? [...e.glimpse] : [],
				selectedTiles: n === "samurai" ? [...e.tiles] : [],
				relics: n === "ninja" ? e.vases.filter((e) => (e.holder === "bank" || e.holder === "current") && e.relic).length : 0
			} } : {}
		};
	},
	status(e) {
		if (!e.winner) return { phase: e.phase };
		let t = N(e, e.winner);
		return {
			phase: "done",
			winner: [t],
			ranking: [t, N(e, M(e.winner))]
		};
	}
};
//#endregion
//#region src/games/castlenightingale/icons.tsx
function he({ color: e }) {
	return e === "T" ? /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("rect", {
		x: "-12",
		y: "-13",
		width: "24",
		height: "26",
		fill: "#0d1831",
		stroke: "#7a87b8",
		strokeWidth: "3"
	}), /* @__PURE__ */ l("path", {
		d: "M-8 9 8 9",
		stroke: "#6e80b2",
		strokeWidth: "2"
	})] }) : e === "G" ? /* @__PURE__ */ u("g", {
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.4",
		children: [[
			0,
			90,
			180,
			270
		].map((e) => /* @__PURE__ */ l("path", {
			transform: `rotate(${e})`,
			d: "M0-14 4-8 1-4 0 0-1-4-4-8Z M0-11V-3"
		}, e)), /* @__PURE__ */ l("path", { d: "M-5-5 5 5 M5-5-5 5" })]
	}) : e === "P" ? /* @__PURE__ */ l(c, { children: [
		0,
		120,
		240
	].map((e) => /* @__PURE__ */ l("path", {
		transform: `rotate(${e})`,
		d: "M0-1C-11-4-11-13-3-13 5-13 11-5 10 3 7-3 3-7 0-5-2-3-2-1 0-1Z",
		fill: "currentColor"
	}, e)) }) : e === "Y" ? /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ l("circle", {
			r: "11",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ l("circle", {
			r: "7",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ l("path", {
			d: "M-2-5H2V5H-2Z",
			fill: "currentColor"
		})
	] }) : e === "B" ? /* @__PURE__ */ l("path", {
		d: "M0-13 13 0 0 13-13 0Z M0-8 8 0 0 8-8 0Z M-13 0H13 M0-13V13",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.5"
	}) : /* @__PURE__ */ l("path", {
		d: "M-8-8H8V8H-8Z M0-12 12 0 0 12-12 0Z",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.5"
	});
}
function Y({ kind: e, role: t = "samurai" }) {
	return /* @__PURE__ */ l("svg", {
		viewBox: "-20 -20 40 40",
		x: "-20",
		y: "-20",
		width: "40",
		height: "40",
		className: "cn-icon",
		"aria-hidden": "true",
		children: e === "vase" ? /* @__PURE__ */ u(c, { children: [
			/* @__PURE__ */ l("path", {
				d: "M-8-15H8L5-8C19 2 16 15 0 17-16 15-19 2-5-8Z",
				fill: "#d47c39",
				stroke: "#ffe4a1",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ l("ellipse", {
				cy: "-14",
				rx: "8",
				ry: "3",
				fill: "#153248"
			}),
			/* @__PURE__ */ l("path", {
				d: "M-10 4 0 10 10 4",
				fill: "none",
				stroke: "#ffe4a1",
				strokeWidth: "2"
			})
		] }) : e === "foot" ? /* @__PURE__ */ u("g", {
			fill: "currentColor",
			transform: "rotate(-25)",
			children: [
				/* @__PURE__ */ l("ellipse", {
					cy: "5",
					rx: "7",
					ry: "9"
				}),
				/* @__PURE__ */ l("ellipse", {
					cx: "-9",
					cy: "-5",
					rx: "3",
					ry: "4"
				}),
				/* @__PURE__ */ l("ellipse", {
					cx: "-3",
					cy: "-10",
					rx: "3",
					ry: "4"
				}),
				/* @__PURE__ */ l("ellipse", {
					cx: "4",
					cy: "-10",
					rx: "3",
					ry: "4"
				}),
				/* @__PURE__ */ l("ellipse", {
					cx: "10",
					cy: "-5",
					rx: "3",
					ry: "4"
				})
			]
		}) : e === "ninja" || e === "samurai" ? /* @__PURE__ */ u(c, { children: [
			/* @__PURE__ */ l("path", {
				d: "M-14-8-12-18-4-13H4L12-18 14-8 15 9 9 16H-9L-15 9Z",
				fill: e === "ninja" ? "#203559" : "#b4472d",
				stroke: "#f8d58c",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ l("path", {
				d: "M-12-4Q0 1 12-4L9 5H-9Z",
				fill: "#0b1824"
			}),
			/* @__PURE__ */ l("path", {
				d: "M-8 0-3 2 M3 2 8 0",
				stroke: "#d6ef89",
				strokeWidth: "3"
			}),
			e === "samurai" && /* @__PURE__ */ l("path", {
				d: "M-17-17-10-10 0-13 10-10 17-17 M0-19V-11",
				fill: "none",
				stroke: "#eabc5c",
				strokeWidth: "4"
			})
		] }) : e === "relic" ? /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("path", {
			d: "M-7 12-6-3-10-9-4-9-3-15 3-15 4-9 10-9 6-3 7 12Z",
			fill: "#edc76c",
			stroke: "#fff0bd",
			strokeWidth: "2"
		}), /* @__PURE__ */ l("path", {
			d: "M-11 15H11",
			stroke: "#edc76c",
			strokeWidth: "4"
		})] }) : e === "eye" ? /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("path", {
			d: "M-17 0Q0-18 17 0 0 18-17 0",
			fill: "#f6e5b3"
		}), /* @__PURE__ */ l("circle", {
			r: "7",
			fill: "#153448"
		})] }) : e === "door" ? /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("rect", {
			x: "-13",
			y: "-15",
			width: "26",
			height: "30",
			rx: "2",
			fill: "#805733",
			stroke: "#edc787",
			strokeWidth: "2"
		}), /* @__PURE__ */ l("path", {
			d: "M-9-8H9 M-9 8H9 M-4-13V13 M4-13V13",
			stroke: "#292c2c",
			strokeWidth: "2"
		})] }) : e === "move" ? /* @__PURE__ */ l("path", {
			d: "M-17-7H2V-15L18 0 2 15V7H-17Z",
			fill: "currentColor"
		}) : /* @__PURE__ */ u(c, { children: [
			/* @__PURE__ */ l("circle", {
				cx: "-4",
				cy: "-2",
				r: "13",
				fill: t === "ninja" ? "#203559" : "#b4472d",
				stroke: "#eabc5c",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ l("path", {
				d: "M-12-5-11-12-5-8-1-8 4-12 5-5 4 6H-11Z",
				fill: "none",
				stroke: "#f8d58c",
				strokeWidth: "1.7"
			}),
			/* @__PURE__ */ l("path", {
				d: "M-10-3-6-1 M-3-1 1-3",
				stroke: "#f8d58c",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ l("path", {
				d: e === "draw" ? "M8 17V2H3L12-8 20 2H15V17Z" : "M8-17V-2H3L12 8 20-2H15V-17Z",
				fill: "#e8a447",
				stroke: "#f5d98a",
				strokeWidth: "1"
			})
		] })
	});
}
//#endregion
//#region src/games/castlenightingale/text.ts
var ge = {
	name: "games.castlenightingale.name",
	desc: "games.castlenightingale.desc",
	ninja: "games.castlenightingale.ninja",
	samurai: "games.castlenightingale.samurai",
	round: "games.castlenightingale.round",
	caught: "games.castlenightingale.caught",
	relics: "games.castlenightingale.relics",
	stolen: "games.castlenightingale.stolen",
	wait: "games.castlenightingale.wait",
	continue: "games.castlenightingale.continue",
	confirm: "games.castlenightingale.confirm",
	cancel: "games.castlenightingale.cancel",
	cardSelect: "games.castlenightingale.cardSelect",
	hand: "games.castlenightingale.hand",
	discardPiles: "games.castlenightingale.discardPiles",
	discardPile: "games.castlenightingale.discardPile",
	equipment: "games.castlenightingale.equipment",
	use: "games.castlenightingale.use",
	jump: "games.castlenightingale.jump",
	plus: "games.castlenightingale.plus",
	minus: "games.castlenightingale.minus",
	G: "games.castlenightingale.G",
	P: "games.castlenightingale.P",
	Y: "games.castlenightingale.Y",
	B: "games.castlenightingale.B",
	R: "games.castlenightingale.R",
	T: "games.castlenightingale.T",
	setupDoors: "games.castlenightingale.setupDoors",
	setupPawn: "games.castlenightingale.setupPawn",
	sPlan: "games.castlenightingale.sPlan",
	nPlan: "games.castlenightingale.nPlan",
	nStart: "games.castlenightingale.nStart",
	nMove: "games.castlenightingale.nMove",
	sMove: "games.castlenightingale.sMove",
	singS: "games.castlenightingale.singS",
	singN: "games.castlenightingale.singN",
	cricket: "games.castlenightingale.cricket",
	nEnd: "games.castlenightingale.nEnd",
	sEnd: "games.castlenightingale.sEnd",
	done: "games.castlenightingale.done",
	peek: "games.castlenightingale.peek",
	relocate: "games.castlenightingale.relocate",
	place: "games.castlenightingale.place",
	recover: "games.castlenightingale.recover",
	shift: "games.castlenightingale.shift",
	open: "games.castlenightingale.open",
	close: "games.castlenightingale.close",
	reopen: "games.castlenightingale.reopen",
	draw: "games.castlenightingale.draw",
	discard: "games.castlenightingale.discard",
	none: "games.castlenightingale.none",
	vasesN: "games.castlenightingale.vasesN",
	vasesS: "games.castlenightingale.vasesS",
	cardMoveN: "games.castlenightingale.cardMoveN",
	cardMoveS: "games.castlenightingale.cardMoveS",
	ne0: "games.castlenightingale.ne0",
	ne1: "games.castlenightingale.ne1",
	ne2: "games.castlenightingale.ne2",
	ne3: "games.castlenightingale.ne3",
	ne4: "games.castlenightingale.ne4",
	ne5: "games.castlenightingale.ne5",
	ne6: "games.castlenightingale.ne6",
	nd0: "games.castlenightingale.nd0",
	nd1: "games.castlenightingale.nd1",
	nd2: "games.castlenightingale.nd2",
	nd3: "games.castlenightingale.nd3",
	nd4: "games.castlenightingale.nd4",
	nd5: "games.castlenightingale.nd5",
	nd6: "games.castlenightingale.nd6",
	se0: "games.castlenightingale.se0",
	se1: "games.castlenightingale.se1",
	se2: "games.castlenightingale.se2",
	se3: "games.castlenightingale.se3",
	se4: "games.castlenightingale.se4",
	se5: "games.castlenightingale.se5",
	se6: "games.castlenightingale.se6",
	sd0: "games.castlenightingale.sd0",
	sd1: "games.castlenightingale.sd1",
	sd2: "games.castlenightingale.sd2",
	sd3: "games.castlenightingale.sd3",
	sd4: "games.castlenightingale.sd4",
	sd5: "games.castlenightingale.sd5",
	sd6: "games.castlenightingale.sd6",
	safe: "games.castlenightingale.safe",
	alarm: "games.castlenightingale.alarm",
	unknown: "games.castlenightingale.unknown",
	glimpse: "games.castlenightingale.glimpse",
	empty: "games.castlenightingale.empty",
	relic: "games.castlenightingale.relic",
	vase: "games.castlenightingale.vase",
	cell: "games.castlenightingale.cell",
	garden: "games.castlenightingale.garden",
	zoom: "games.castlenightingale.zoom",
	yourRole: "games.castlenightingale.yourRole",
	opponent: "games.castlenightingale.opponent",
	chosen: "games.castlenightingale.chosen",
	returnCard: "games.castlenightingale.returnCard",
	optSide: "games.castlenightingale.optSide",
	sideA: "games.castlenightingale.sideA",
	sideB: "games.castlenightingale.sideB",
	layout: "games.castlenightingale.layout",
	fixed: "games.castlenightingale.fixed",
	random: "games.castlenightingale.random",
	seat: "games.castlenightingale.seat",
	first: "games.castlenightingale.first",
	second: "games.castlenightingale.second",
	winner: "games.castlenightingale.winner",
	ninjaWin: "games.castlenightingale.ninjaWin",
	samuraiWin: "games.castlenightingale.samuraiWin",
	again: "games.castlenightingale.again",
	lobby: "games.castlenightingale.lobby",
	review: "games.castlenightingale.review",
	hideBoard: "games.castlenightingale.hideBoard",
	hostWait: "games.castlenightingale.hostWait",
	invalid: "games.castlenightingale.invalid",
	capturedEvent: "games.castlenightingale.capturedEvent",
	alarmEvent: "games.castlenightingale.alarmEvent",
	closedCount: "games.castlenightingale.closedCount",
	noEquipment: "games.castlenightingale.noEquipment",
	rules: "games.castlenightingale.rules"
};
function X() {
	let e = d();
	return (t, n) => e(ge[t], n);
}
//#endregion
//#region src/games/castlenightingale/board.tsx
function _e({ pub: e, priv: t, actions: a = [], onAction: o = () => {} }) {
	let c = X(), [d, f] = i(0), p = r(null), [m, g] = i("");
	n(() => {
		let e = new ResizeObserver((e) => {
			let t = e[0].contentRect;
			g(`${Math.round(t.width)}:${Math.round(t.height)}`);
		});
		return e.observe(p.current), () => e.disconnect();
	}, []);
	let _ = (e) => e === 144 ? {
		x: 255,
		y: 255,
		w: 90,
		h: 90
	} : {
		x: e % 12 * 48 + 14,
		y: Math.floor(e / 12) * 48 + 14,
		w: 44,
		h: 44
	}, v = a.flatMap((t, n) => {
		let r = t.type === "pick" ? t.kind === "vase" ? e.vases.find((e) => e.id === t.id)?.cell : t.id : t.type === "equipment" ? t.target : null;
		return r == null ? [] : [{
			key: String(n),
			rect: _(r)
		}];
	}), y = (t) => e.vases.find((e) => e.cell === t && e.holder === "board"), b = (n) => e.vases.find((e) => e.id === n)?.relic ?? t?.knownVases.find((e) => e.id === n)?.relic;
	return /* @__PURE__ */ u("div", {
		className: "cn-board-wrap",
		ref: p,
		children: [/* @__PURE__ */ l("button", {
			className: "cn-fit",
			onClick: () => f((e) => e + 1),
			children: c("zoom")
		}), /* @__PURE__ */ u(s, {
			sheetW: 600,
			sheetH: 600,
			fitKey: `${m}:${d}`,
			clampToSheet: !0,
			highlight: "inset",
			eligible: v,
			onTapEligible: (e) => o(a[Number(e)]),
			children: [
				/* @__PURE__ */ l("defs", { children: /* @__PURE__ */ l("pattern", {
					id: "cn-wood",
					width: "48",
					height: "12",
					patternUnits: "userSpaceOnUse",
					children: /* @__PURE__ */ l("path", {
						d: "M0 3H48M4 7H38M12 10H44",
						stroke: "#6a4723",
						strokeWidth: ".8",
						opacity: ".15"
					})
				}) }),
				/* @__PURE__ */ l("rect", {
					x: "253",
					y: "253",
					width: "94",
					height: "94",
					rx: "4",
					fill: "#203d38",
					stroke: "#ac8d59",
					strokeWidth: "7"
				}),
				/* @__PURE__ */ l("path", {
					d: "M265 279Q290 268 331 285M264 308Q291 291 331 315",
					fill: "none",
					stroke: "#65816a",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ l("ellipse", {
					cx: "300",
					cy: "304",
					rx: "12",
					ry: "7",
					fill: "#617b7a"
				}),
				/* @__PURE__ */ l("ellipse", {
					cx: "284",
					cy: "284",
					rx: "10",
					ry: "8",
					fill: "#a0ad9b"
				}),
				/* @__PURE__ */ l("text", {
					x: "300",
					y: "337",
					textAnchor: "middle",
					fill: "#e0d5b4",
					fontSize: "11",
					children: c("garden")
				}),
				e.cells.map((t) => {
					let n = _(t.id), r = y(t.id), i = e.footprints.indexOf(t.id), a = e.closed.includes(t.id), o = b(r?.id ?? -1);
					return /* @__PURE__ */ u("g", { children: [
						/* @__PURE__ */ l("title", { children: c("cell", {
							color: c(t.color),
							x: t.x + 1,
							y: t.y + 1
						}) }),
						/* @__PURE__ */ l("rect", {
							x: n.x - 2,
							y: n.y - 2,
							width: "48",
							height: "48",
							fill: "#573b2a"
						}),
						/* @__PURE__ */ l("rect", {
							x: n.x,
							y: n.y,
							width: n.w,
							height: n.h,
							fill: h[t.color],
							stroke: "#e9c37f",
							strokeWidth: "1"
						}),
						/* @__PURE__ */ l("rect", {
							x: n.x,
							y: n.y,
							width: n.w,
							height: n.h,
							fill: "url(#cn-wood)"
						}),
						/* @__PURE__ */ l("g", {
							transform: `translate(${n.x + 22} ${n.y + 22})`,
							color: t.color === "T" ? "#91a1c4" : "#725128",
							opacity: ".5",
							children: /* @__PURE__ */ l(he, { color: t.color })
						}),
						a && /* @__PURE__ */ u("g", {
							className: "cn-appear",
							transform: `translate(${n.x + 4} ${n.y + 4})`,
							children: [/* @__PURE__ */ l("rect", {
								width: "36",
								height: "36",
								rx: "2",
								fill: "#895936",
								stroke: "#e9c08b",
								strokeWidth: "2"
							}), /* @__PURE__ */ l("path", {
								d: "M3 9H33M3 27H33M12 2V34M24 2V34",
								stroke: "#382b26",
								strokeWidth: "3"
							})]
						}),
						i >= 0 && /* @__PURE__ */ u("g", {
							className: "cn-appear",
							transform: `translate(${n.x + 6} ${n.y + 4})`,
							children: [/* @__PURE__ */ l("circle", {
								cx: "16",
								cy: "18",
								r: "17",
								fill: "#faeac0",
								opacity: ".92"
							}), /* @__PURE__ */ l("svg", {
								x: "3",
								y: "4",
								width: "26",
								height: "26",
								viewBox: "-20 -20 40 40",
								color: "#293d55",
								children: /* @__PURE__ */ l(Y, { kind: "foot" })
							})]
						}),
						r && /* @__PURE__ */ u("g", {
							className: "cn-appear",
							transform: `translate(${n.x + 2} ${n.y + 2})`,
							children: [
								/* @__PURE__ */ l("svg", {
									width: "40",
									height: "40",
									viewBox: "-20 -20 40 40",
									children: /* @__PURE__ */ l(Y, { kind: o === !0 ? "relic" : "vase" })
								}),
								/* @__PURE__ */ l("circle", {
									cx: "33",
									cy: "8",
									r: "8",
									fill: "#fff1ca"
								}),
								/* @__PURE__ */ l("text", {
									x: "33",
									y: "11",
									textAnchor: "middle",
									fontSize: "9",
									fill: "#293040",
									fontWeight: "700",
									children: r.id + 1
								}),
								o === !1 && /* @__PURE__ */ l("text", {
									x: "20",
									y: "34",
									textAnchor: "middle",
									fontSize: "9",
									fill: "#fff",
									children: "∅"
								})
							]
						}),
						(e.samurai === t.id || e.ninja === t.id) && /* @__PURE__ */ u("g", {
							className: "cn-appear",
							transform: `translate(${n.x} ${n.y})`,
							children: [/* @__PURE__ */ l("circle", {
								cx: "22",
								cy: "22",
								r: "21",
								fill: "#0a1424",
								stroke: e.samurai === t.id ? "#f6be6c" : "#99cfe0",
								strokeWidth: "2"
							}), /* @__PURE__ */ l("svg", {
								x: "2",
								y: "2",
								width: "40",
								height: "40",
								viewBox: "-20 -20 40 40",
								children: /* @__PURE__ */ l(Y, { kind: e.samurai === t.id ? "samurai" : "ninja" })
							})]
						})
					] }, t.id);
				}),
				e.samurai === 144 && /* @__PURE__ */ l("svg", {
					x: "280",
					y: "280",
					width: "40",
					height: "40",
					viewBox: "-20 -20 40 40",
					children: /* @__PURE__ */ l(Y, { kind: "samurai" })
				})
			]
		})]
	});
}
//#endregion
//#region src/games/castlenightingale/cards.tsx
function Z({ role: e, id: t, selected: n = !1 }) {
	let r = X(), i = g[e][t], a = i.effect === "vases" ? r(e === "ninja" ? "vasesN" : "vasesS", { n: i.count }) : r(i.effect);
	return /* @__PURE__ */ u("span", {
		className: `cn-card ${e} ${n ? "selected" : ""}`,
		children: [
			/* @__PURE__ */ l("img", {
				src: `games/castlenightingale/${e}-${t}.webp`,
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ l("span", {
				className: "cn-card-number",
				children: t + 1
			}),
			/* @__PURE__ */ u("span", {
				className: "cn-card-move",
				children: [/* @__PURE__ */ l(Y, { kind: e === "ninja" ? "foot" : "move" }), /* @__PURE__ */ l("strong", { children: i.move })]
			}),
			/* @__PURE__ */ u("span", {
				className: "cn-card-effect",
				children: [i.effect !== "none" && /* @__PURE__ */ l(Y, {
					role: i.effect === "discard" ? e === "ninja" ? "samurai" : "ninja" : e,
					kind: i.effect === "vases" ? "eye" : [
						"open",
						"close",
						"shift"
					].includes(i.effect) ? "door" : i.effect === "discard" ? "discard" : "draw"
				}), /* @__PURE__ */ l("span", { children: a })]
			})
		]
	});
}
//#endregion
//#region src/games/castlenightingale/view-player.tsx
var ve = (e, t) => `${e === "ninja" ? "n" : "s"}e${t}`, ye = (e, t) => `${e === "ninja" ? "n" : "s"}d${t}`;
function be(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ l(xe, {
		...e,
		pub: t,
		priv: n
	});
}
function Q({ i: e, selected: t = !1, onClick: n }) {
	let r = X(), i = m[e];
	return /* @__PURE__ */ l("button", {
		className: `cn-color ${t ? "selected" : ""}`,
		title: r(i),
		"aria-label": r(i),
		"aria-pressed": t,
		disabled: !n,
		onClick: n,
		style: { background: h[i] },
		children: /* @__PURE__ */ l("svg", {
			viewBox: "-20 -20 40 40",
			"aria-hidden": "true",
			children: /* @__PURE__ */ l(he, { color: i })
		})
	});
}
function xe({ pub: e, priv: t, members: n, myRid: r, send: s }) {
	let d = X(), [f, p] = i(null), [h, g] = i([]), [_, v] = i(null), y = `${r}:${t?.role}:${e.ninjaRid}:${e.samuraiRid}:${e.turn}:${e.round}:${e.phase}:${e.task?.kind}:${e.task?.remaining}:${e.task?.selected}`, [b, x] = i(y);
	b !== y && (x(y), p(null), g([]), v(null));
	let S = e.turn === r, C = t?.role ?? "ninja", w = t?.legal ?? [], T = (e) => n.find((t) => t.rid === e)?.name ?? d("opponent"), E = w.filter((e) => e.type === "plan"), D = E[0]?.tiles.length ?? 0, O = E.find((e) => e.card === f && [...e.tiles].sort().join() === [...h].sort().join()), k = w.filter((e) => e.type === "equipment" && e.id === _), A = k.filter((e) => e.target !== void 0), j = A.filter((e) => e.mode === "jump" || C === "samurai" && e.id === 5), ee = _ === null ? w.filter((e) => e.type === "pick") : j, M = e.phase === "task" ? d(e.task?.kind ?? "continue", { n: e.task?.remaining ?? 0 }) : d(e.phase, { n: e.left }), N = (e) => {
		s(e), v(null);
	};
	return /* @__PURE__ */ l("div", {
		className: "cn-screen",
		children: /* @__PURE__ */ l(a, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ u("div", {
				className: "cn-banner",
				children: [
					/* @__PURE__ */ u("div", {
						className: "cn-top",
						children: [/* @__PURE__ */ l("span", {
							className: "cn-brand",
							children: d("name")
						}), /* @__PURE__ */ l("span", { children: d("round", { n: e.round }) })]
					}),
					/* @__PURE__ */ u("div", {
						className: "cn-players",
						children: [/* @__PURE__ */ u("div", {
							className: e.turn === e.ninjaRid ? "active" : "",
							children: [/* @__PURE__ */ l(Y, { kind: "ninja" }), /* @__PURE__ */ u("span", { children: [T(e.ninjaRid), /* @__PURE__ */ u("small", { children: [d("stolen", { n: e.vases.filter((e) => ["bank", "current"].includes(e.holder)).length }), C === "ninja" && t ? ` · ${d("relics", { n: t.relics })}` : ""] })] })]
						}), /* @__PURE__ */ u("div", {
							className: e.turn === e.samuraiRid ? "active" : "",
							children: [/* @__PURE__ */ l(Y, { kind: "samurai" }), /* @__PURE__ */ u("span", { children: [T(e.samuraiRid), /* @__PURE__ */ l("small", { children: d("caught", { n: e.caught }) })] })]
						})]
					}),
					/* @__PURE__ */ l(o, {
						tone: S ? "accent" : "info",
						accent: "#b48948",
						text: S ? M : d("wait", { name: T(e.turn ?? "") })
					})
				]
			}),
			children: /* @__PURE__ */ u("div", {
				className: "cn-layout",
				children: [/* @__PURE__ */ l(_e, {
					pub: e,
					priv: t,
					actions: S ? ee : [],
					onAction: N
				}), /* @__PURE__ */ u("aside", {
					className: "cn-scroll",
					children: [
						/* @__PURE__ */ u("div", {
							className: "cn-tile-row",
							children: [
								/* @__PURE__ */ l("span", { children: d("safe") }),
								/* @__PURE__ */ l("div", { children: e.previous.map((e) => /* @__PURE__ */ l(Q, { i: e }, e)) }),
								/* @__PURE__ */ l("span", { children: d("closedCount", { n: e.closed.length }) })
							]
						}),
						/* @__PURE__ */ u("div", {
							className: "cn-tile-row",
							children: [/* @__PURE__ */ l("span", { children: d("alarm") }), /* @__PURE__ */ u("div", { children: [(e.alarm ?? (C === "samurai" ? t?.selectedTiles : []) ?? []).map((e) => /* @__PURE__ */ l(Q, { i: e }, e)), e.alarm === null && !(C === "samurai" && t?.selectedTiles.length) && /* @__PURE__ */ l("span", {
								className: "cn-secret",
								children: "?"
							})] })]
						}),
						!!t?.glimpsedTiles.length && /* @__PURE__ */ u("div", {
							className: "cn-tile-row",
							children: [/* @__PURE__ */ l("span", { children: d("glimpse") }), /* @__PURE__ */ l("div", { children: t.glimpsedTiles.map((e) => /* @__PURE__ */ l(Q, { i: e }, e)) })]
						}),
						S && E.length > 0 && /* @__PURE__ */ u(c, { children: [
							D > 0 && /* @__PURE__ */ l("div", {
								className: "cn-colors",
								children: m.map((e, t) => /* @__PURE__ */ l(Q, {
									i: t,
									selected: h.includes(t),
									onClick: E.some((e) => e.tiles.includes(t)) ? () => g((e) => e.includes(t) ? e.filter((e) => e !== t) : [...e.slice(-(D - 1 || 99)), t].slice(-D)) : void 0
								}, t))
							}),
							/* @__PURE__ */ l("div", {
								className: "cn-hand",
								children: t?.hand.map((e) => /* @__PURE__ */ l("button", {
									"aria-label": d("cardSelect", { n: e + 1 }),
									"aria-pressed": f === e,
									onClick: () => p(f === e ? null : e),
									children: /* @__PURE__ */ l(Z, {
										role: C,
										id: e,
										selected: f === e
									})
								}, e))
							}),
							/* @__PURE__ */ l("button", {
								className: "cn-primary",
								disabled: !O,
								onClick: () => O && N(O),
								children: d("confirm")
							})
						] }),
						E.length === 0 && /* @__PURE__ */ l("div", {
							className: "cn-revealed",
							children: ["ninja", "samurai"].map((n) => {
								let r = e.cards[n] ?? (C === n ? t?.programmed : null);
								return /* @__PURE__ */ u("div", { children: [/* @__PURE__ */ l("span", { children: d(n) }), r == null ? /* @__PURE__ */ l("div", {
									className: `cn-card-back ${n}`,
									children: /* @__PURE__ */ l(Y, { kind: n })
								}) : /* @__PURE__ */ l(Z, {
									role: n,
									id: r
								})] }, n);
							})
						}),
						/* @__PURE__ */ u("div", {
							className: "cn-equipment",
							children: [/* @__PURE__ */ u("div", {
								className: "cn-label",
								children: [d("equipment"), /* @__PURE__ */ l("small", { children: t ? d("yourRole", { role: d(C) }) : "" })]
							}), /* @__PURE__ */ u("div", {
								className: "cn-eq-list",
								children: [t?.equipment.map((e) => /* @__PURE__ */ l("button", {
									className: _ === e ? "selected" : "",
									onClick: () => v(_ === e ? null : e),
									children: d(ve(C, e))
								}, e)), t?.equipment.length === 0 && /* @__PURE__ */ l("span", { children: d("noEquipment") })]
							})]
						}),
						_ !== null && /* @__PURE__ */ u("div", {
							className: "cn-eq-detail",
							children: [
								/* @__PURE__ */ l("strong", { children: d(ve(C, _)) }),
								/* @__PURE__ */ l("p", { children: d(ye(C, _)) }),
								/* @__PURE__ */ u("div", {
									className: "cn-eq-actions",
									children: [
										k.filter((e) => e.target === void 0).map((e) => /* @__PURE__ */ l("button", {
											onClick: () => N(e),
											children: d(e.mode === "use" ? "use" : e.mode)
										}, e.mode)),
										!!k.filter((e) => e.mode === "jump").length && /* @__PURE__ */ l("p", { children: d("jump") }),
										/* @__PURE__ */ l("div", {
											className: "cn-card-archive",
											children: A.filter((e) => e.mode === "use" && e.id === 6).map((e) => /* @__PURE__ */ u("button", {
												"aria-label": d("returnCard", { n: e.target + 1 }),
												onClick: () => N(e),
												children: [/* @__PURE__ */ l(Z, {
													role: C,
													id: e.target
												}), /* @__PURE__ */ l("span", { children: d("returnCard", { n: e.target + 1 }) })]
											}, e.target))
										}),
										/* @__PURE__ */ l("button", {
											onClick: () => v(null),
											children: d("cancel")
										})
									]
								})
							]
						}),
						S && w.some((e) => e.type === "continue") && /* @__PURE__ */ l("button", {
							className: "cn-primary",
							onClick: () => N({ type: "continue" }),
							children: d("continue")
						}),
						/* @__PURE__ */ l("div", {
							className: "cn-loot",
							children: e.vases.filter((e) => e.holder !== "board").map((e) => {
								let n = e.relic ?? t?.knownVases.find((t) => t.id === e.id)?.relic;
								return /* @__PURE__ */ u("span", {
									className: e.holder === "lost" ? "lost" : "",
									title: d(n === !0 ? "relic" : n === !1 ? "empty" : "unknown"),
									children: [/* @__PURE__ */ l(Y, { kind: n === !0 ? "relic" : "vase" }), /* @__PURE__ */ u("small", { children: [e.id + 1, e.holder === "current" ? " •" : ""] })]
								}, e.id);
							})
						}),
						/* @__PURE__ */ u("details", {
							className: "cn-discards",
							children: [/* @__PURE__ */ l("summary", { children: d("discardPiles") }), ["ninja", "samurai"].map((t) => /* @__PURE__ */ u("section", { children: [/* @__PURE__ */ u("div", {
								className: "cn-label",
								children: [
									d(t),
									" · ",
									d("discardPile", { n: e.discard[t].length })
								]
							}), /* @__PURE__ */ l("div", {
								className: "cn-card-archive",
								children: e.discard[t].map((e) => /* @__PURE__ */ l(Z, {
									role: t,
									id: e
								}, e))
							})] }, t))]
						})
					]
				})]
			})
		})
	});
}
//#endregion
//#region src/games/castlenightingale/bot.ts
var $ = (e, t, n, r = !1) => {
	if (n.includes(t)) return 0;
	let i = /* @__PURE__ */ new Set([t]), a = [[t, 0]];
	for (let t = 0; t < a.length; t++) {
		let [o, s] = a[t];
		for (let t of r ? S(e, o) : x(e, o)) if (!i.has(t)) {
			if (n.includes(t)) return s + 1;
			i.add(t), a.push([t, s + 1]);
		}
	}
	return 30;
};
function Se(e, t, n, r = !0) {
	let i = t.legal;
	if (!i.length) return null;
	let a = e.cells, o = (e) => a.find((t) => t.id === e), s = new Map(t.knownVases.map((e) => [e.id, e.relic])), c = e.vases.filter((e) => e.holder === "board" && s.get(e.id) !== !1), l = c.map((e) => e.cell), u = [...e.previous, ...t.glimpsedTiles], d = o(e.ninja)?.zone, f = a.filter((e) => e.zone === d).map((e) => e.id), p = a.filter((t) => t.color === "T" && !e.closed.includes(t.id)).map((e) => e.id), h = (t) => {
		let n = o(t), i = c.find((e) => e.cell === t);
		return (i ? s.get(i.id) === !0 ? 30 : 21 : 0) - $(a, t, l) * 2.4 + (r && u.includes(m.indexOf(n.color)) ? 9 : 0) - (n.zone === o(e.samurai)?.zone ? 5 : 0);
	}, _ = (i) => {
		let c = n() * .6;
		if (i.type === "continue") return c + 1;
		if (i.type === "plan") {
			let n = g[t.role][i.card];
			if (c += n.move * (t.role === "ninja" ? 2.5 : 1.5), c += n.effect === "draw" ? 3 : n.effect === "vases" ? n.count * 2 : n.effect === "close" ? 7 : n.effect === "open" ? e.closed.length * 1.5 : 0, t.role === "samurai") for (let t of i.tiles) {
				let n = m[t], r = e.ninja === null ? e.footprints.length ? e.footprints : p : [e.ninja];
				c += a.filter((e) => e.color === n).reduce((e, t) => e + r.reduce((e, n) => e + (Math.abs(t.x - o(n).x) + Math.abs(t.y - o(n).y) < 4 ? .3 : 0), 0), 0), c += l.filter((e) => o(e)?.color === n).length * 2;
			}
			return c;
		}
		if (i.type === "equipment") return i.mode === "jump" ? c + h(i.target) - 14 : i.mode === "plus" ? c - 3 : i.mode === "minus" ? c - 5 : t.role === "ninja" ? c + [
			3,
			7,
			9,
			2,
			3,
			20,
			-2
		][i.id] : c + [
			8,
			-1,
			3,
			1e3,
			12,
			8,
			-2
		][i.id];
		if (e.phase === "setupDoors") return c - $(a, i.id, l);
		if (e.phase === "setupPawn") return c - $(a, i.id, p, !0);
		if (e.phase === "nStart" || e.phase === "nMove") {
			if (c += h(i.id), r && e.left > 1) {
				let t = x(a, i.id).filter((t) => t !== e.samurai && !e.footprints.includes(t));
				t.length ? c += Math.max(...t.map(h)) * .55 : c -= 9;
			}
			return c;
		}
		if (e.phase === "sMove" || e.phase === "cricket") return e.phase === "cricket" ? c - $(a, i.id, l) - (o(i.id)?.zone === d ? 1e3 : 0) : i.id === 144 ? c - 5 : (e.ninja !== null && (c += o(i.id)?.zone === d ? 1e3 : -$(a, i.id, f, !0) * 15), c += p.includes(i.id) ? r ? 24 : 10 : 0, r && (c -= $(a, i.id, p, !0) * 2), e.left === 1 && e.footprints.includes(i.id) && (c += 5), c);
		if (e.phase === "task") {
			let t = e.task?.kind;
			return t === "peek" || t === "relocate" ? c + (s.has(i.id) ? -20 : 10) : t === "place" || t === "recover" ? c + (e.ninja === null ? 0 : $(a, i.id, [e.ninja])) - (e.previous.includes(m.indexOf(o(i.id).color)) ? 3 : 0) : t === "open" || t === "reopen" || t === "close" ? c - $(a, i.id, l) : c;
		}
		return c;
	}, v = i[0], y = -Infinity;
	for (let e of i) {
		let t = _(e);
		t > y && (v = e, y = t);
	}
	return v;
}
var Ce = (e, t) => {
	let n = e.private;
	if (!n?.legal.length) return null;
	let r = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967296, i = t.difficulty === "weak" ? n.legal[Math.floor(r() * n.legal.length)] : Se(e.public, n, r, !1);
	return i ? { action: i } : null;
};
//#endregion
//#region src/games/castlenightingale/game-over.tsx
function we({ public: e, members: t, onPlayAgain: n, onBackToLobby: r }) {
	let a = e, o = X(), [s, c] = i(!1), d = a.winner ?? "samurai", f = d === "ninja" ? a.ninjaRid : a.samuraiRid;
	return /* @__PURE__ */ l("div", {
		className: "cn-ending cn-screen",
		children: /* @__PURE__ */ u("div", {
			className: "cn-result",
			children: [
				/* @__PURE__ */ l("div", {
					className: "cn-crest",
					children: /* @__PURE__ */ l(Y, { kind: d })
				}),
				/* @__PURE__ */ u("p", { children: [
					o("name"),
					" · ",
					o("round", { n: a.round })
				] }),
				/* @__PURE__ */ l("h1", { children: o("winner", { role: o(d) }) }),
				/* @__PURE__ */ l("h2", { children: t.find((e) => e.rid === f)?.name }),
				/* @__PURE__ */ l("p", { children: o(d === "ninja" ? "ninjaWin" : "samuraiWin") }),
				/* @__PURE__ */ u("div", {
					className: "cn-result-counts",
					children: [/* @__PURE__ */ l("span", { children: o("caught", { n: a.caught }) }), /* @__PURE__ */ l("span", { children: o("relics", { n: a.vases.filter((e) => e.holder === "bank" && e.relic).length }) })]
				}),
				/* @__PURE__ */ l("div", {
					className: "cn-loot",
					children: a.vases.map((e) => /* @__PURE__ */ u("span", {
						className: e.holder === "lost" ? "lost" : "",
						children: [/* @__PURE__ */ l(Y, { kind: e.relic ? "relic" : "vase" }), /* @__PURE__ */ u("small", { children: [
							e.id + 1,
							" · ",
							o(e.relic ? "relic" : "empty")
						] })]
					}, e.id))
				}),
				/* @__PURE__ */ l("button", {
					onClick: () => c((e) => !e),
					children: o(s ? "hideBoard" : "review")
				}),
				s && /* @__PURE__ */ l("div", {
					className: "cn-final-board",
					children: /* @__PURE__ */ l(_e, { pub: a })
				}),
				/* @__PURE__ */ u("div", {
					className: "cn-result-actions",
					children: [
						n && /* @__PURE__ */ l("button", {
							className: "cn-primary",
							onClick: n,
							children: o("again")
						}),
						r && /* @__PURE__ */ l("button", {
							onClick: r,
							children: o("lobby")
						}),
						!n && /* @__PURE__ */ l("p", { children: o("hostWait") })
					]
				})
			]
		})
	});
}
//#endregion
//#region src/games/castlenightingale/options.tsx
function Te({ value: e, onChange: t }) {
	let n = X(), r = T.parse(e ?? {});
	return /* @__PURE__ */ u("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ l(p, {
				title: n("optSide"),
				children: ["A", "B"].map((e) => /* @__PURE__ */ l(f, {
					name: "cn-side",
					value: e,
					checked: r.side === e,
					label: n(e === "A" ? "sideA" : "sideB"),
					onChange: () => t({
						...r,
						side: e
					})
				}, e))
			}),
			/* @__PURE__ */ l(p, {
				title: n("layout"),
				children: [!1, !0].map((e) => /* @__PURE__ */ l(f, {
					name: "cn-layout",
					value: String(e),
					checked: r.randomLayout === e,
					label: n(e ? "random" : "fixed"),
					onChange: () => t({
						...r,
						randomLayout: e
					})
				}, String(e)))
			}),
			/* @__PURE__ */ l(p, {
				title: n("seat"),
				children: [0, 1].map((e) => /* @__PURE__ */ l(f, {
					name: "cn-seat",
					value: String(e),
					checked: r.ninjaSeat === e,
					label: n(e === 0 ? "first" : "second"),
					onChange: () => t({
						...r,
						ninjaSeat: e
					})
				}, e))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/castlenightingale/entry.tsx
var Ee = {
	definition: me,
	View: be,
	bot: Ce,
	OverView: we,
	Options: Te,
	locales: {
		zh: {
			name: "夜莺城",
			desc: "忍者循影盗宝，武士循声追踪的双人非对称对决。",
			ninja: "忍者",
			samurai: "武士",
			round: "第 {{n}} 轮",
			caught: "捕获 {{n}}／3",
			relics: "神像 {{n}}／5",
			stolen: "已盗花瓶 {{n}}",
			wait: "等待{{name}}行动",
			continue: "继续",
			confirm: "确认编程",
			cancel: "取消选择",
			cardSelect: "选择行动牌 {{n}}",
			hand: "行动牌",
			discardPiles: "查看双方弃牌堆",
			discardPile: "弃牌 {{n}} 张",
			equipment: "装备",
			use: "使用装备",
			jump: "弃置并跳跃",
			plus: "弃置并增加 1 次移动",
			minus: "弃置并减少 1 次移动",
			G: "绿地板",
			P: "粉地板",
			Y: "黄地板",
			B: "蓝地板",
			R: "赭地板",
			T: "暗门",
			setupDoors: "选择 2 处暗门并封闭",
			setupPawn: "选择武士的起始格",
			sPlan: "选择行动牌与夜莺地板",
			nPlan: "选择忍者行动牌",
			nStart: "选择本轮的出发位置",
			nMove: "放置脚步：还须移动 {{n}} 格",
			sMove: "移动武士：还须经过 {{n}} 个色区",
			singS: "地板鸣响：可使用碎瓶",
			singN: "已被发现：可使用烟雾弹",
			cricket: "蟋蟀引路：移动武士 {{n}} 个色区",
			nEnd: "忍者补牌，或使用城堡地图",
			sEnd: "武士补牌，或使用城堡地图",
			done: "对局结束",
			peek: "选择花瓶，查看其内容（还剩 {{n}} 个）",
			relocate: "选择要移走的花瓶（还剩 {{n}} 个）",
			place: "将花瓶放在武士所在板块的空地板格",
			recover: "将本轮没收的花瓶放回武士所在板块",
			shift: "先选择可开启的暗门，再选择另一处封闭",
			open: "选择暗门并开启",
			close: "选择暗门并封闭",
			reopen: "各板块开启一处暗门，避开武士（还剩 {{n}} 处）",
			draw: "抽取 1 件装备",
			discard: "随机弃置对手 1 件装备",
			none: "没有附加行动",
			vasesN: "查看 {{n}} 个花瓶",
			vasesS: "移动并查看 {{n}} 个花瓶",
			cardMoveN: "移动 {{n}} 格",
			cardMoveS: "移动 {{n}} 个色区",
			ne0: "望远镜",
			ne1: "手里剑",
			ne2: "撒菱",
			ne3: "蟋蟀",
			ne4: "攀爬爪",
			ne5: "烟雾弹",
			ne6: "城堡地图",
			nd0: "武士编程后，查看其手中随机 2 枚夜莺板块。",
			nd1: "取消武士本轮行动牌的附加行动。",
			nd2: "取消武士本轮行动牌的移动。",
			nd3: "将武士从当前位置移动 2 个色区。",
			nd4: "从城堡外缘出发，下一步可到任一不同颜色的外缘格。",
			nd5: "地板鸣响后完成剩余移动，忍者留在最后一格并移除全部脚步。",
			nd6: "补牌时，从弃牌堆取回 1 张行动牌。",
			se0: "碎瓶",
			se1: "钥匙",
			se2: "军事战术",
			se3: "捕网",
			se4: "夜莺成双",
			se5: "提灯",
			se6: "城堡地图",
			sd0: "地板鸣响时，随机永久弃置忍者已盗取的 1 个花瓶，不查看内容。",
			sd1: "本轮可将花园作为 1 个色区穿越，但不能停在花园。",
			sd2: "编程前取回上轮使用的夜莺板块。",
			sd3: "捕获同一板块上已现身的忍者，无距离限制。",
			sd4: "本轮编程时使用 2 枚夜莺板块。",
			sd5: "移除所有脚步，仅保留你选定的 1 处作为忍者起点。",
			sd6: "补牌时，从弃牌堆取回 1 张行动牌。",
			safe: "上轮地板（本轮安全）",
			alarm: "夜莺地板",
			unknown: "暗置",
			glimpse: "已确认未选的地板",
			empty: "空瓶",
			relic: "神像",
			vase: "花瓶 {{n}}",
			cell: "{{color}}，第 {{x}} 列第 {{y}} 行",
			garden: "花园",
			zoom: "全景",
			yourRole: "你的身份：{{role}}",
			opponent: "对手",
			chosen: "已选",
			returnCard: "取回行动牌 {{n}}",
			optSide: "地板版本",
			sideA: "A 面（入门）",
			sideB: "B 面",
			layout: "板块布局",
			fixed: "标准布局",
			random: "随机排列与旋转",
			seat: "忍者座位",
			first: "第 1 位玩家",
			second: "第 2 位玩家",
			winner: "{{role}}获胜",
			ninjaWin: "五尊神像已被带出夜莺城。",
			samuraiWin: "三名忍者均已被武士捕获。",
			again: "再来一局",
			lobby: "返回大厅",
			review: "回看终盘",
			hideBoard: "收起终盘",
			hostWait: "等待主机开始下一局",
			invalid: "此时无法执行该行动。",
			capturedEvent: "忍者被捕获",
			alarmEvent: "夜莺地板鸣响",
			closedCount: "封闭暗门 {{n}}／8",
			noEquipment: "没有装备",
			rules: "目标：\n忍者需要盗得5个含有神像的花瓶；武士需要捕获全部3名忍者。8 个花瓶中有 6 尊神像、2 个空瓶，内容保密。双方胜利条件在轮末检查。\n准备：\n四块地板围绕不可通行的花园组成城堡。可选 A／B 面及随机排列。武士先封闭 2 处暗门，再放置在没有花瓶或暗门的地板格。双方各有 10 张行动牌、7 件一次性装备，起手各 3 张牌和 1 件装备。\n流程：\n武士先秘密选择行动牌与 1 枚夜莺板块，忍者随后选择行动牌。上轮的夜莺板块本轮不能选择。忍者先亮牌执行附加行动，再完成全部移动；武士随后亮牌，先完成移动，再执行附加行动。只要能够执行牌上的行动，就必须执行。\n忍者：\n场上没有忍者与脚步时，从任一未封闭暗门进入；只有脚步时，任选脚步作为起点并清除旧脚步；忍者已现身则从原格出发。每步正交走 1 格，不重复经过格子，不经过武士或花园。在开启暗门上可用 1 步到另一开启暗门。踏上花瓶立即盗取并查看，须与此前轮次盗取的花瓶分开。\n踏上本轮夜莺颜色的地板或暗门时，立即停止、现身并清除脚步。未触发则移除忍者，保留全部脚步，下轮可从其中任一处重新出发。每轮可以将1件装备背面朝下弃置，跳过正交相邻的 1 格。\n武士：\n每步进入相邻的不同色区，并可停在该区任一格；相连同色格组成一整区，每个暗门单独算 1 区。进入开启暗门立即封闭。每轮可以将1件装备背面朝下弃置，将移动总数增加或减少 1。\n进入已现身忍者所在色区，或封闭全部 8 处暗门，便捕获忍者。只没收本轮盗取的花瓶，放到武士所在板块的空地板格；此前轮次盗取的花瓶保留。因全门封闭捕获时，各板块开启一门，不开启武士脚下的门；该板块无其他门则从别板块多开一门。移动结束时移除脚下脚步，查看并移动脚下花瓶到同板块空格。\n装备与轮末：\n装备在注明的时机使用并永久弃置。\n· 望远镜查看未选颜色。\n· 手里剑取消武士牌上的附加行动。\n· 撒菱取消武士牌上的移动。\n· 蟋蟀移动武士 2 区。\n· 攀爬爪连接不同色外缘。\n· 烟雾弹允许被发现后走完且留在末格。\n· 碎瓶随机移除已盗花瓶。\n· 钥匙可穿越但不停在花园。\n· 军事战术取回上轮颜色。\n· 捕网捕获同板块可见忍者。\n· 夜莺成双改选 2 色。\n· 提灯只保留一处脚步。\n双方城堡地图可在补牌时改取回弃牌。\n双方弃置本轮行动牌并各抽 1 张，牌堆用尽时，将弃牌堆洗混，组成新的牌堆。检查五尊神像或三次捕获，未结束便开始下一轮。"
		},
		en: {
			name: "Castle Nightingale",
			desc: "A duel of stealth and anticipation between treasure-seeking ninjas and a vigilant samurai.",
			ninja: "Ninja",
			samurai: "Samurai",
			round: "Turn {{n}}",
			caught: "Captured {{n}}/3",
			relics: "Relics {{n}}/5",
			stolen: "Stolen vases {{n}}",
			wait: "Waiting for {{name}}",
			continue: "Continue",
			confirm: "Commit plan",
			cancel: "Cancel",
			cardSelect: "Select action card {{n}}",
			hand: "Action cards",
			discardPiles: "View both discard piles",
			discardPile: "{{n}} discarded cards",
			equipment: "Equipment",
			use: "Use equipment",
			jump: "Discard to jump",
			plus: "Discard for +1 movement",
			minus: "Discard for −1 movement",
			G: "Green floor",
			P: "Pink floor",
			Y: "Yellow floor",
			B: "Blue floor",
			R: "Orange floor",
			T: "Secret passage",
			setupDoors: "Close 2 secret passages",
			setupPawn: "Place the samurai on a starting space",
			sPlan: "Choose an action card and a nightingale tile",
			nPlan: "Choose a ninja action card",
			nStart: "Choose a starting space for this turn",
			nMove: "Place footprints: {{n}} moves remaining",
			sMove: "Move the samurai: {{n}} zones remaining",
			singS: "The floor sings: Broken Vase may be used",
			singN: "Detected: Smoke Bombs may be used",
			cricket: "Cricket: move the samurai through {{n}} zones",
			nEnd: "Refill the ninja hand, or use Castle Map",
			sEnd: "Refill the samurai hand, or use Castle Map",
			done: "Game over",
			peek: "Inspect a vase ({{n}} remaining)",
			relocate: "Choose a vase to relocate ({{n}} remaining)",
			place: "Place the vase on a free floor space on the samurai’s board",
			recover: "Return a confiscated vase to the samurai’s board",
			shift: "Select a closed passage to open, then another passage to close",
			open: "Open a secret passage",
			close: "Close a secret passage",
			reopen: "Reopen passages across the four boards, avoiding the samurai ({{n}} remaining)",
			draw: "Draw 1 equipment token",
			discard: "Randomly discard 1 opposing equipment token",
			none: "No additional action",
			vasesN: "Inspect {{n}} vases",
			vasesS: "Inspect and relocate {{n}} vases",
			cardMoveN: "Move {{n}} spaces",
			cardMoveS: "Move {{n}} zones",
			ne0: "Telescope",
			ne1: "Shuriken",
			ne2: "Makibishi",
			ne3: "Cricket",
			ne4: "Climbing Claws",
			ne5: "Smoke Bombs",
			ne6: "Castle Map",
			nd0: "After the samurai programs, inspect 2 random nightingale tiles remaining in their hand.",
			nd1: "Cancel the action on the samurai’s card this turn.",
			nd2: "Cancel the movement on the samurai’s card this turn.",
			nd3: "Move the samurai through 2 zones from their current position.",
			nd4: "From an outer edge, place the next footprint on any differently colored outer-edge space.",
			nd5: "After detection, complete the remaining movement, leave the ninja on the final space, and remove all footprints.",
			nd6: "Instead of drawing, reclaim 1 action card from your discard pile.",
			se0: "Broken Vase",
			se1: "Keys",
			se2: "Military Tactics",
			se3: "Net",
			se4: "Nightingale Pair",
			se5: "Lantern",
			se6: "Castle Map",
			sd0: "When the floor sings, permanently discard 1 randomly chosen stolen vase without inspecting it.",
			sd1: "Cross the garden as 1 zone this turn; movement cannot end there.",
			sd2: "Before programming, reclaim the nightingale tile used last turn.",
			sd3: "Capture a visible ninja on the same floor board at any distance.",
			sd4: "Program 2 nightingale tiles this turn.",
			sd5: "Remove all footprints except 1 chosen starting space.",
			sd6: "Instead of drawing, reclaim 1 action card from your discard pile.",
			safe: "Previous tile (safe this turn)",
			alarm: "Nightingale floor",
			unknown: "Hidden",
			glimpse: "Tiles confirmed not selected",
			empty: "Empty vase",
			relic: "Relic",
			vase: "Vase {{n}}",
			cell: "{{color}}, column {{x}}, row {{y}}",
			garden: "Garden",
			zoom: "Fit board",
			yourRole: "You are the {{role}}",
			opponent: "Opponent",
			chosen: "Selected",
			returnCard: "Reclaim action card {{n}}",
			optSide: "Floor side",
			sideA: "Side A (introductory)",
			sideB: "Side B",
			layout: "Board layout",
			fixed: "Standard layout",
			random: "Random arrangement and rotation",
			seat: "Ninja seat",
			first: "Player 1",
			second: "Player 2",
			winner: "{{role}} victory",
			ninjaWin: "Five sacred relics have been carried out of the castle.",
			samuraiWin: "The samurai has captured all three ninjas.",
			again: "Play again",
			lobby: "Back to lobby",
			review: "Review final board",
			hideBoard: "Hide final board",
			hostWait: "Waiting for the host to start another game",
			invalid: "This action is not available now.",
			capturedEvent: "Ninja captured",
			alarmEvent: "The nightingale floor sings",
			closedCount: "Closed passages {{n}}/8",
			noEquipment: "No equipment",
			rules: "Goal:\nThe ninjas win with 5 vases containing relics. The samurai wins by capturing all 3 ninjas. Of the 8 vases, 6 contain relics and 2 are empty. Contents stay secret. Victory is checked at the end of a turn.\nSetup:\nArrange four floor boards around the inaccessible garden. Choose side A or B and optionally randomize their order and rotation. The samurai closes 2 passages and starts on a floor space without a vase or passage. Each side has 10 action cards, 7 single-use equipment tokens, and starts with 3 cards and 1 equipment token.\nTurn:\nThe samurai secretly programs a card and 1 nightingale tile, then the ninja programs a card. Last turn’s nightingale tile is unavailable this turn. The ninja reveals and performs the card’s action before completing all movement. The samurai then reveals, completes movement, and performs the card’s action. You must perform the card’s action whenever you can legally do so.\nNinja:\nWith no ninja or footprints, enter at any open passage. With only footprints, replace any footprint with the ninja and remove all old footprints. A visible ninja starts from its current space. Move orthogonally one space at a time, without revisiting spaces or crossing the samurai or garden. From an open passage, one move may lead to any other open passage. Immediately steal and inspect a vase entered; keep this turn’s loot separate.\nStepping onto this turn’s nightingale color or selected passage tile stops movement, reveals the ninja, and clears footprints. Otherwise remove the ninja and keep all footprints; any of them may be next turn’s starting point. Once per turn, secretly discard equipment to jump over one orthogonally adjacent space.\nSamurai:\nEach move enters an adjacent different colored zone, ending on any space in it. Connected matching floor spaces form one zone; every passage is its own zone. Immediately close any open passage entered. Once per turn, secretly discard equipment to adjust total movement by +1 or −1.\nEntering the zone of a visible ninja, or closing all 8 passages, captures a ninja. Confiscate only vases stolen this turn and place them on free floor spaces on the samurai’s board. Earlier loot remains stolen. After an all-passages capture, open one passage per board, never under the samurai; if a board has no other passage, open an additional one elsewhere. At movement’s end remove a footprint under the samurai and inspect and relocate a vase there to a free floor space on the same board.\nEquipment and turn end:\nUse equipment at its stated time, then permanently discard it.\n· Telescope reveals unused tiles.\n· Shuriken cancels the action on the samurai’s card.\n· Makibishi cancels the movement on the samurai’s card.\n· Cricket moves the samurai 2 zones.\n· Climbing Claws connect differently colored outer edges.\n· Smoke Bombs finish interrupted movement and leave the ninja visible at its final space.\n· Broken Vase randomly removes stolen loot.\n· Keys cross the garden but cannot stop there.\n· Military Tactics recovers the previous tile.\n· Net captures a visible ninja on the same board.\n· Nightingale Pair programs 2 colors.\n· Lantern leaves only one footprint.\nEither Castle Map reclaims a discarded card instead of drawing.\nDiscard the played cards and draw 1 card each, shuffling the discard pile when needed. Check for five relics or three captures; otherwise begin another turn."
		}
	}
};
//#endregion
export { Ee as default };
