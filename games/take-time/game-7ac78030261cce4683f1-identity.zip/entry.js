import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { gameAssetUrl as r } from "@bgparty/sdk/assets";
import { useFxAnchor as i } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { IconClose as s } from "@bgparty/sdk/icons";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { seatName as l } from "@bgparty/sdk/ui/player-strip";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { FlySprite as p } from "@bgparty/sdk/fx/primitives";
import { OptionCheckbox as m, OptionRadio as h, OptionSection as g, OptionSwitch as _ } from "@bgparty/sdk/ui/game-options";
//#region src/games/take-time/data.ts
var v = Array.from({ length: 24 }, (e, t) => ({
	id: t,
	suit: t < 12 ? "solar" : "lunar",
	value: t % 12 + 1
})), y = (e, t, n = {}, r = {}) => ({
	chapter: e,
	test: t,
	segments: Array.from({ length: 6 }, (e, t) => n[t] ?? {}),
	...r
}), b = (e) => ({ forbidden: e }), x = [
	y(1, 1, {
		0: {
			count: 1,
			solar: 1,
			lunar: 0
		},
		5: { count: 3 }
	}, { unlimited: !0 }),
	y(1, 2, {
		2: { range: [8, 12] },
		3: { count: 3 }
	}, { unlimited: !0 }),
	y(1, 3, {
		2: { plays: [1] },
		1: { plays: [2] },
		5: { range: [20, 30] }
	}, { unlimited: !0 }),
	y(1, 4, {
		0: { closest: 9 },
		3: {
			count: 2,
			solar: 1,
			lunar: 1
		}
	}),
	y(2, 1, {
		0: b([
			1,
			2,
			3
		]),
		1: b([
			1,
			2,
			3
		]),
		2: b([
			1,
			2,
			3
		])
	}),
	y(2, 2, {
		2: b([
			7,
			8,
			9
		]),
		3: b([
			7,
			8,
			9
		])
	}),
	y(2, 3, {
		0: b([
			1,
			2,
			3
		]),
		2: b([
			4,
			5,
			6
		]),
		3: b([
			7,
			8,
			9
		]),
		5: b([
			10,
			11,
			12
		])
	}),
	y(2, 4, {}, { noFaceUp: !0 }),
	y(3, 1, {
		1: { extreme: "high" },
		3: { closest: 20 }
	}),
	y(3, 2, {
		2: { extreme: "low" },
		5: { extreme: "low" },
		3: { last: !0 }
	}),
	y(3, 3, {
		0: { extreme: "high" },
		2: { extreme: "low" },
		3: { plays: [1, 2] }
	}),
	y(3, 4, {
		0: { extreme: "lunarHigh" },
		2: {
			count: 2,
			solar: 2,
			lunar: 0
		},
		3: { closest: 6 },
		4: { extreme: "solarLow" }
	}),
	y(4, 1, {
		1: { plays: [1] },
		4: { count: 1 }
	}, { handRule: "high" }),
	y(4, 2, {
		0: { extreme: "high" },
		5: { plays: [1] }
	}, { handRule: "low" }),
	y(4, 3, {
		0: b([
			1,
			2,
			3
		]),
		2: b([
			1,
			2,
			3
		]),
		4: b([
			1,
			2,
			3
		])
	}, { handRule: "left" }),
	y(4, 4, {
		2: { closest: 12 },
		3: { extreme: "low" },
		4: { extreme: "high" }
	}, { handRule: "left" }),
	y(5, 1, {}, { pairs: !0 }),
	y(5, 2, {
		5: { extreme: "low" },
		3: { closest: 15 }
	}, { pairs: !0 }),
	y(5, 3, {
		0: { extreme: "high" },
		5: { extreme: "low" }
	}, { pairs: !0 }),
	y(5, 4, {
		4: { plays: [2] },
		1: { plays: [3] },
		2: {
			solar: 1,
			lunar: 1
		},
		3: {
			solar: 1,
			lunar: 1
		}
	}, { pairs: !0 }),
	y(6, 1, { 2: { extreme: "high" } }, {
		pairs: !0,
		difference: !0
	}),
	y(6, 2, {
		4: {
			solar: 1,
			lunar: 1
		},
		3: b([
			1,
			2,
			3
		])
	}, {
		pairs: !0,
		difference: !0
	}),
	y(6, 3, {
		1: { closest: 12 },
		4: { plays: [2, 3] }
	}, {
		pairs: !0,
		difference: !0
	}),
	y(6, 4, {
		0: { extreme: "solarLow" },
		3: { extreme: "lunarHigh" },
		1: { closest: 24 }
	}, {
		pairs: !0,
		difference: !0
	}),
	y(7, 1, {
		0: { draw: !0 },
		2: b([
			7,
			8,
			9
		]),
		3: b([
			7,
			8,
			9
		])
	}),
	y(7, 2, {
		2: { draw: !0 },
		5: { draw: !0 },
		3: { last: !0 }
	}),
	y(7, 3, {
		4: { draw: !0 },
		5: {
			count: 4,
			solar: 2,
			lunar: 2
		},
		3: {
			extreme: "solarLow",
			alsoExtreme: "lunarHigh"
		}
	}),
	y(7, 4, {
		0: { draw: !0 },
		2: { draw: !0 },
		4: { draw: !0 }
	}),
	y(8, 1, {
		5: { rotate: 1 },
		1: { blocked: !0 },
		3: { range: [16, 20] }
	}),
	y(8, 2, {
		0: { rotate: 1 },
		3: { rotate: 1 },
		1: { blocked: !0 },
		2: { blocked: !0 },
		5: { blocked: !0 }
	}),
	y(8, 3, {
		3: { rotate: 1 },
		4: { rotate: 1 },
		5: { rotate: 1 },
		0: { count: 2 },
		2: { count: 1 }
	}),
	y(8, 4, {
		0: { rotate: 1 },
		1: { rotate: 1 },
		4: { rotate: -1 },
		5: { rotate: -1 }
	}),
	y(9, 1, { 3: { extreme: "high" } }, { edges: [{
		a: 2,
		b: 3,
		min: 9
	}] }),
	y(9, 2, {}, { edges: Array.from({ length: 6 }, (e, t) => ({
		a: t,
		b: (t + 1) % 6,
		min: 2
	})) }),
	y(9, 3, {
		0: { extreme: "low" },
		3: { extreme: "low" }
	}, { edges: [{
		a: 0,
		b: 1,
		equal: !0
	}, {
		a: 3,
		b: 4,
		equal: !0
	}] }),
	y(9, 4, {}, { spread: 4 }),
	y(10, 1, {}, { firstHand: 5 }),
	y(10, 2, { 1: { count: 2 } }, { firstHand: 4 }),
	y(10, 3, {
		1: { plays: [1] },
		4: { last: !0 }
	}, { firstHand: 3 }),
	y(10, 4, {}, {
		firstHand: 1,
		second: 2
	})
], S = (e) => e.chapter >= 3 && e.chapter <= 9 && (e.chapter !== 8 || e.test !== 4), C = (e) => (e % 6 + 6) % 6, w = (e, t) => (e !== 3 || t.chapter !== 4) && (e !== 6 || t.chapter !== 8), T = {
	id: "take-time",
	tier: "alpha",
	mechanics: ["deduction", "hand-management"],
	interactionTags: ["cooperative"],
	nameKey: "games.take-time.name",
	descKey: "games.take-time.desc",
	rulesKey: "games.take-time.rules",
	icon: "🕰️",
	iconImg: "games/take-time.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	rulesUrl: {
		zh: "https://cdn.svc.asmodee.net/production-libelludv2/uploads/2026/08/TT_RULES_CNS_20250408_compressed.pdf",
		en: "https://cdn.svc.asmodee.net/production-libelludv2/uploads/2026/07/TT_RULES_PRINT_MASTER_EN_compressed.pdf"
	},
	accent: "#b49350",
	releasedAt: "2026-11-04T00:15:00+08:00",
	search: {
		py: "shi xu mi ju zhang wo shi ke take time",
		init: "sxmj zwsk"
	},
	hotseat: "cover"
}, E = t.int().min(0).max(5), D = t.object({
	id: t.int().min(0).max(23),
	suit: t.enum(["solar", "lunar"]),
	value: t.int().min(1).max(12)
}), O = t.object({
	clock: t.int().min(0).max(39).default(0),
	rebirth: t.boolean().default(!1),
	variants: t.array(t.int().min(1).max(6)).default([])
}).default({
	clock: 0,
	rebirth: !1,
	variants: []
}), k = t.discriminatedUnion("type", [
	t.object({ type: t.literal("ready") }),
	t.object({ type: t.literal("redeal") }),
	t.object({
		type: t.literal("hand"),
		segment: E
	}),
	t.object({
		type: t.literal("second"),
		segment: E
	}),
	t.object({
		type: t.literal("play"),
		card: t.int().min(0).max(23),
		segment: E,
		faceUp: t.boolean()
	}),
	t.object({
		type: t.literal("give"),
		card: t.int().min(0).max(23),
		faceUp: t.boolean()
	}),
	t.object({
		type: t.literal("place"),
		segment: E
	}),
	t.object({ type: t.literal("judge") }),
	t.object({ type: t.literal("retry") }),
	t.object({
		type: t.literal("continue"),
		clock: t.int().min(0).max(39)
	}),
	t.object({ type: t.literal("finish") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), A = t.object({
	kind: t.enum([
		"empty",
		"order",
		"limit",
		"count",
		"color",
		"range",
		"closest",
		"extreme",
		"forbidden",
		"plays",
		"last",
		"edge",
		"spread",
		"first"
	]),
	segment: t.int().min(-1).max(5)
}), j = t.object({
	id: t.int(),
	suit: t.enum(["solar", "lunar"]),
	value: t.number().nullable(),
	by: t.string(),
	placer: t.string(),
	order: t.int(),
	faceUp: t.boolean(),
	revealed: t.boolean()
}), M = t.object({
	phase: t.enum([
		"discussion",
		"placement",
		"reveal",
		"assess",
		"result",
		"done"
	]),
	clock: t.int(),
	rotation: t.int(),
	hand: E,
	second: E,
	players: t.array(t.object({
		rid: t.string(),
		ready: t.boolean(),
		hand: t.array(t.enum(["solar", "lunar"])),
		reserve: t.int(),
		reserveSuits: t.array(t.enum(["solar", "lunar"])),
		played: t.int()
	})),
	turn: t.string().nullable(),
	leader: t.string(),
	board: t.array(t.array(j)),
	faceUpLeft: t.int(),
	bonus: t.int(),
	deckCount: t.int(),
	canRedeal: t.boolean(),
	pending: t.object({
		by: t.string(),
		receiver: t.string(),
		suit: t.enum(["solar", "lunar"]),
		value: t.number().nullable(),
		faceUp: t.boolean()
	}).nullable(),
	progress: t.array(t.enum([
		"untried",
		"passed",
		"regret"
	])),
	attempts: t.array(t.int()),
	variants: t.array(t.int()),
	rebirth: t.boolean(),
	issues: t.array(A),
	sums: t.array(t.number().nullable()),
	metrics: t.array(t.number().nullable()),
	success: t.boolean().nullable(),
	revealedCount: t.int()
}), N = t.object({
	hand: t.array(D),
	ownPlaced: t.array(t.object({
		order: t.int(),
		value: t.int()
	})),
	playable: t.array(t.int())
}), P = (e) => e.board.flat().length;
function F(e) {
	if (e.phase !== "discussion" || e.ready.length) return !1;
	let t = [...Object.values(e.hands).flat(), ...Object.values(e.reserve).flat()], n = x[e.clock].segments, r = (e) => Math.max(n.reduce((t, n) => t + (e === "solar" ? n.solar ?? 0 : n.lunar ?? 0), 0), +!!n.some((t) => e === "solar" ? t.extreme === "solarLow" : t.extreme === "lunarHigh" || t.alsoExtreme === "lunarHigh"));
	return ["solar", "lunar"].some((e) => t.filter((t) => t.suit === e).length < r(e));
}
var I = (e) => x[e.clock].noFaceUp ? 0 : Math.max(0, e.players.length + e.bonus - (e.variants.includes(5) ? 2 : 0)), L = (e, t, n) => {
	let r = x[t].handRule;
	if (r === "left") return e.slice(0, 1);
	if (r === "high" || r === "low") {
		let t = (r === "high" ? Math.max : Math.min)(...e.map((e) => e.value));
		return e.filter((e) => e.value === t);
	}
	return n.includes(3) && e.some((e) => e.suit === "solar") ? e.filter((e) => e.suit === "solar") : e;
}, R = (e, t, n, r) => Array.from({ length: 6 }, (e, t) => t).filter((i) => !x[e].segments[C(i - t)].blocked && (x[e].second === void 0 && !r.includes(6) || i !== n && i !== C(n + 3)));
function z(e, t) {
	return e.map((e) => e.map((n) => t.includes(1) && e.length > 1 && n.value >= 10 ? n.value - 10 : n.value));
}
function B(e, t, n, r, i) {
	let a = x[e], o = z(t, i), s = o.map((e) => e.reduce((e, t) => e + t, 0)), c = a.difference ? o.map((e) => e.length ? Math.max(...e) - Math.min(...e) : 0) : s, l = [], u = (e, t) => {
		l.some((n) => n.kind === e && n.segment === t) || l.push({
			kind: e,
			segment: t
		});
	}, d = S(a) ? r : C(n), f = t.flatMap((e, t) => e.map((e, n) => ({
		...e,
		value: o[t][n],
		segment: t
	}))), p = a.segments.flatMap((e, t) => e.extreme === "low" ? [C(t + n)] : []), m = p.map((e) => Math.min(...o[e])), h = f.map((e) => e.value).sort((e, t) => e - t).slice(0, 2), g = (e, t) => {
		let n = f.filter((t) => e === "solarLow" ? t.suit === "solar" : e !== "lunarHigh" || t.suit === "lunar");
		if (!n.length) {
			u("extreme", t);
			return;
		}
		if (e === "low" && p.length === 2) {
			let e = [...m].sort((e, t) => e - t);
			(!o[t].length || e.some((e, t) => e !== h[t])) && u("extreme", t);
			return;
		}
		let r = (e === "high" || e === "lunarHigh" ? Math.max : Math.min)(...n.map((e) => e.value));
		n.some((e) => e.segment === t && e.value === r) || u("extreme", t);
	};
	for (let e = 0; e < 6; e++) {
		let r = t[e], i = a.segments[C(e - n)];
		r.length || u("empty", e), !a.unlimited && c[e] > 24 && u("limit", e), (a.pairs && r.length !== 2 || i.count !== void 0 && r.length !== i.count) && u("count", e), (i.solar !== void 0 && r.filter((e) => e.suit === "solar").length !== i.solar || i.lunar !== void 0 && r.filter((e) => e.suit === "lunar").length !== i.lunar) && u("color", e), i.range && (s[e] < i.range[0] || s[e] > i.range[1]) && u("range", e), i.closest !== void 0 && s.some((t) => Math.abs(t - i.closest) < Math.abs(s[e] - i.closest)) && u("closest", e), i.extreme && g(i.extreme, e), i.alsoExtreme && g(i.alsoExtreme, e), i.forbidden && o[e].some((e) => i.forbidden.includes(e)) && u("forbidden", e), i.plays?.some((e) => !r.some((t) => t.order === e)) && u("plays", e), i.last && !r.some((e) => e.order === f.length) && u("last", e), e < 5 && c[C(d + e)] > c[C(d + e + 1)] && u("order", C(d + e + 1));
	}
	for (let e of a.edges ?? []) {
		let t = C(e.a + n), r = C(e.b + n), i = Math.abs(s[t] - s[r]);
		(e.equal ? i !== 0 : i < e.min) && u("edge", t);
	}
	let _ = Math.max(...s) - Math.min(...s);
	if ((a.spread !== void 0 && _ > a.spread || i.includes(2) && _ > 12) && u("spread", -1), a.firstHand !== void 0) {
		let e = C(a.firstHand + n);
		for (let t = 0; t < 5; t++) {
			let n = C(e + t), r = C(e + t + 1);
			(!o[n].length || !o[r].length || o[n][0] > o[r][0]) && u("first", r);
		}
	}
	return {
		issues: l,
		sums: s,
		metrics: c
	};
}
function V(t) {
	let n = v.map((e) => ({ ...e }));
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	t.hands = {}, t.reserve = {}, t.played = {}, t.ready = [], t.turn = null;
	let r = t.players.length, i = 12 / r;
	return t.players.forEach((e, a) => {
		let o = n.slice(a * i, (a + 1) * i);
		t.hands[e] = o.slice(0, r === 2 ? 4 : i), t.reserve[e] = r === 2 ? o.slice(4) : [], t.played[e] = 0;
	}), t.deck = n.slice(12), t.board = Array.from({ length: 6 }, () => []), t.faceUpUsed = 0, t.phase = "discussion", t.rotation = 0, t.hand = 0, t.second = x[t.clock].second ?? 0, t.revealOrder = [], t.revealedCount = 0, t.issues = [], t.success = null, t.pending = null, t.variants = t.config.rebirth ? [...new Set(t.config.variants)].filter((e) => w(e, x[t.clock])) : [], t.players.map((e, n) => ({
		kind: "deal",
		rid: e,
		data: { suits: t.hands[e].map((e) => e.suit) },
		...n > 0 ? { with: !0 } : {}
	}));
}
function H(e, t, n) {
	let r = O.parse(e), i = {
		players: t,
		seed: n,
		cursor: 0,
		config: r,
		phase: "discussion",
		clock: r.clock,
		rotation: 0,
		hand: 0,
		second: 0,
		hands: {},
		reserve: {},
		ready: [],
		played: {},
		turn: null,
		board: [],
		deck: [],
		faceUpUsed: 0,
		bonus: 0,
		pending: null,
		progress: Array.from({ length: 40 }, () => "untried"),
		attempts: Array(40).fill(0),
		variants: [],
		revealOrder: [],
		revealedCount: 0,
		issues: [],
		success: null
	};
	return {
		state: i,
		fx: V(i)
	};
}
function U(e) {
	e.phase = "reveal", e.turn = null, e.revealOrder = [];
	let t = S(x[e.clock]) ? e.hand : e.rotation;
	for (let n = 0; n < 6; n++) {
		let r = C(t + n);
		e.board[r].forEach((t) => e.revealOrder.push({
			segment: r,
			order: t.order
		}));
	}
}
function W(e, t, n, r, i, a) {
	let o = x[e.clock].segments[C(n - e.rotation)], s = P(e) + 1;
	e.board[n].push({
		...r,
		by: t,
		placer: a,
		order: s,
		faceUp: i,
		revealed: i
	}), e.played[t]++, i && e.faceUpUsed++;
	let c = [{
		kind: "play",
		rid: a,
		data: {
			segment: n,
			order: s,
			suit: r.suit,
			value: i ? r.value : null,
			gifted: t !== a
		}
	}];
	if (o.draw && e.deck.length) {
		let n = e.deck.shift();
		e.hands[t].push(n), c.push({
			kind: "draw",
			rid: t,
			data: { suit: n.suit },
			for: [t],
			secret: { id: n.id },
			with: !0
		});
	}
	if (e.players.length === 2 && e.players.every((t) => e.played[t] >= 2) && e.players.some((t) => e.reserve[t].length)) for (let t of e.players) {
		let n = e.reserve[t];
		e.hands[t].push(...n), e.reserve[t] = [], c.push({
			kind: "reserve",
			rid: t,
			data: { suits: n.map((e) => e.suit) },
			for: [t],
			secret: { ids: n.map((e) => e.id) },
			with: !0
		});
	}
	if (o.rotate && (e.rotation += o.rotate, c.push({
		kind: "rotate",
		data: { rotation: e.rotation },
		with: !0
	})), (x[e.clock].second !== void 0 || e.variants.includes(6)) && (e.second = C(e.second + 1)), e.pending = null, e.players.every((t) => e.hands[t].length === 0)) U(e);
	else {
		let n = e.players.indexOf(t);
		for (let t = 1; t <= e.players.length; t++) {
			let r = e.players[(n + t) % e.players.length];
			if (e.hands[r].length) {
				e.turn = r;
				break;
			}
		}
	}
	return c;
}
var G = () => ({ code: "games.take-time.errAction" });
function K(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "reveal") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = t.revealOrder[t.revealedCount];
		if (n) {
			let e = t.board[n.segment].find((e) => e.order === n.order);
			return e.revealed = !0, t.revealedCount++, t.revealedCount === t.revealOrder.length && (t.phase = "assess"), {
				state: t,
				fx: [{
					kind: "reveal",
					data: {
						segment: n.segment,
						order: e.order,
						value: e.value,
						suit: e.suit
					}
				}]
			};
		}
		return t.phase = "assess", {
			state: t,
			fx: []
		};
	}
	if (!e.players.includes(n.by) || e.phase === "done") return G();
	let r = structuredClone(e), i = x[r.clock];
	if (t.type === "hand") {
		if (!S(i) || !(r.phase === "discussion" && !r.ready.includes(n.by) || r.phase === "assess")) return G();
		r.hand = t.segment;
	} else if (t.type === "second") {
		if (r.phase !== "discussion" || r.ready.includes(n.by) || !r.variants.includes(6)) return G();
		r.second = t.segment;
	} else if (t.type === "redeal") return n.by !== r.players[0] || !F(r) ? G() : {
		state: r,
		fx: V(r)
	};
	else if (t.type === "ready") {
		if (r.phase !== "discussion" || r.ready.includes(n.by)) return G();
		r.ready.push(n.by), r.ready.length === r.players.length && (r.phase = "placement");
	} else if (t.type === "play" || t.type === "give") {
		if (r.phase !== "placement" || r.pending || r.turn !== null && r.turn !== n.by || t.type === "give" !== r.variants.includes(4)) return G();
		let e = L(r.hands[n.by], r.clock, r.variants).find((e) => e.id === t.card);
		return !e || t.faceUp && (P(r) === 0 || r.faceUpUsed >= I(r)) || t.type === "play" && !R(r.clock, r.rotation, r.second, r.variants).includes(t.segment) ? G() : (r.hands[n.by] = r.hands[n.by].filter((t) => t.id !== e.id), t.type === "give" ? (r.pending = {
			by: n.by,
			receiver: r.players[(r.players.indexOf(n.by) + 1) % r.players.length],
			card: e,
			faceUp: t.faceUp
		}, {
			state: r,
			fx: [{
				kind: "give",
				rid: n.by,
				data: {
					suit: e.suit,
					value: t.faceUp ? e.value : null
				}
			}]
		}) : {
			state: r,
			fx: W(r, n.by, t.segment, e, t.faceUp, n.by)
		});
	} else if (t.type === "place") return r.phase !== "placement" || !r.pending || r.pending.receiver !== n.by || !R(r.clock, r.rotation, r.second, r.variants).includes(t.segment) ? G() : {
		state: r,
		fx: W(r, r.pending.by, t.segment, r.pending.card, r.pending.faceUp, n.by)
	};
	else if (t.type === "judge") {
		if (r.phase !== "assess" || n.by !== r.players[0]) return G();
		r.issues = B(r.clock, r.board, r.rotation, r.hand, r.variants).issues, r.success = r.issues.length === 0, r.attempts[r.clock]++, r.success ? (r.progress[r.clock] = "passed", r.bonus = 0) : (r.progress[r.clock] !== "passed" && (r.progress[r.clock] = "regret"), r.bonus = Math.min(3, r.bonus + 1)), r.phase = "result";
	} else if (t.type === "retry") return r.phase !== "result" || n.by !== r.players[0] ? G() : {
		state: r,
		fx: V(r)
	};
	else if (t.type === "continue") return r.phase !== "result" || n.by !== r.players[0] ? G() : (r.clock = t.clock, r.bonus = 0, {
		state: r,
		fx: V(r)
	});
	else if (t.type === "finish") {
		if (r.phase !== "result" || n.by !== r.players[0]) return G();
		r.phase = "done";
	}
	return {
		state: r,
		fx: []
	};
}
function q(e, t) {
	let n = B(e.clock, e.board, e.rotation, e.hand, e.variants), r = e.phase === "assess" || e.phase === "result" || e.phase === "done", i = e.ready.includes(t);
	return {
		public: {
			phase: e.phase,
			clock: e.clock,
			rotation: e.rotation,
			hand: S(x[e.clock]) ? e.hand : C(e.rotation),
			second: e.second,
			players: e.players.map((t) => ({
				rid: t,
				ready: e.ready.includes(t),
				hand: e.hands[t].map((e) => e.suit),
				reserve: e.reserve[t].length,
				reserveSuits: e.reserve[t].map((e) => e.suit),
				played: e.played[t]
			})),
			turn: e.turn,
			leader: e.players[0],
			board: e.board.map((e) => e.map((e) => ({
				id: e.order,
				suit: e.suit,
				value: e.revealed ? e.value : null,
				by: e.by,
				placer: e.placer,
				order: e.order,
				faceUp: e.faceUp,
				revealed: e.revealed
			}))),
			faceUpLeft: I(e) - e.faceUpUsed,
			bonus: e.bonus,
			deckCount: e.deck.length,
			canRedeal: F(e),
			pending: e.pending ? {
				by: e.pending.by,
				receiver: e.pending.receiver,
				suit: e.pending.card.suit,
				value: e.pending.faceUp ? e.pending.card.value : null,
				faceUp: e.pending.faceUp
			} : null,
			progress: e.progress,
			attempts: e.attempts,
			variants: e.variants,
			rebirth: e.config.rebirth,
			issues: r ? n.issues : [],
			sums: r ? n.sums : [
				,
				,
				,
				,
				,
				,
			].fill(null),
			metrics: r ? n.metrics : [
				,
				,
				,
				,
				,
				,
			].fill(null),
			success: e.success,
			revealedCount: e.revealedCount
		},
		private: {
			hand: i ? e.hands[t] ?? [] : [],
			ownPlaced: e.board.flat().filter((e) => e.by === t).map((e) => ({
				order: e.order,
				value: e.value
			})),
			playable: i ? L(e.hands[t] ?? [], e.clock, e.variants).map((e) => e.id) : []
		}
	};
}
var J = {
	meta: T,
	saveCompatibility: { version: "1" },
	schemas: {
		config: O,
		action: k,
		publicView: M,
		privateView: N
	},
	setup: H,
	reduce: K,
	viewFor: q,
	status: (e) => e.phase === "done" ? {
		phase: "done",
		winner: e.success ? e.players : [],
		ranking: [...e.players]
	} : { phase: e.phase },
	nextTickIn: (e) => e.phase === "reveal" ? 620 : null
};
//#endregion
//#region src/games/take-time/card.tsx
function Y({ suit: e, value: t, style: n }) {
	return /* @__PURE__ */ d("span", {
		className: "tt-card",
		"data-suit": e,
		"data-back": t == null,
		style: n,
		children: /* @__PURE__ */ d("img", {
			src: r(`games/take-time/card-${e}-${t ?? "back"}.svg`),
			alt: "",
			draggable: !1
		})
	});
}
//#endregion
//#region src/games/take-time/text.ts
var X = [
	"games.take-time.variant1",
	"games.take-time.variant2",
	"games.take-time.variant3",
	"games.take-time.variant4",
	"games.take-time.variant5",
	"games.take-time.variant6"
], ee = {
	empty: "games.take-time.issueEmpty",
	order: "games.take-time.issueOrder",
	limit: "games.take-time.issueLimit",
	count: "games.take-time.issueCount",
	color: "games.take-time.issueColor",
	range: "games.take-time.issueRange",
	closest: "games.take-time.issueClosest",
	extreme: "games.take-time.issueExtreme",
	forbidden: "games.take-time.issueForbidden",
	plays: "games.take-time.issuePlays",
	last: "games.take-time.issueLast",
	edge: "games.take-time.issueEdge",
	spread: "games.take-time.issueSpread",
	first: "games.take-time.issueFirst"
};
//#endregion
//#region src/games/take-time/rule-details.tsx
function te({ rule: e, twoLow: t }) {
	let n = o(), r = [];
	return e.count !== void 0 && r.push(n("games.take-time.countRule", { n: e.count })), e.solar !== void 0 && r.push(n("games.take-time.solarRule", { n: e.solar })), e.lunar !== void 0 && r.push(n("games.take-time.lunarRule", { n: e.lunar })), e.range && r.push(n("games.take-time.rangeRule", {
		a: e.range[0],
		b: e.range[1]
	})), e.closest !== void 0 && r.push(n("games.take-time.closestRule", { n: e.closest })), e.extreme === "high" && r.push(n("games.take-time.highRule")), e.extreme === "low" && r.push(n(t ? "games.take-time.twoLowRule" : "games.take-time.lowRule")), e.extreme === "solarLow" && r.push(n("games.take-time.solarLowRule")), (e.extreme === "lunarHigh" || e.alsoExtreme === "lunarHigh") && r.push(n("games.take-time.lunarHighRule")), e.forbidden && r.push(n("games.take-time.forbidRule", { n: e.forbidden.join(", ") })), e.plays?.forEach((e) => r.push(n("games.take-time.playRule", { n: e }))), e.last && r.push(n("games.take-time.lastRule")), e.draw && r.push(n("games.take-time.drawRule")), e.rotate && r.push(n(e.rotate === 1 ? "games.take-time.clockwise" : "games.take-time.counterclockwise")), e.blocked && r.push(n("games.take-time.blockedRule")), /* @__PURE__ */ d("ul", { children: (r.length ? r : [n("games.take-time.emptyRule")]).map((e) => /* @__PURE__ */ d("li", { children: e }, e)) });
}
function ne({ pub: e }) {
	let t = o(), n = x[e.clock], r = n.segments.filter((e) => e.extreme === "low").length === 2;
	return /* @__PURE__ */ f("div", {
		className: "tt-rule-details",
		children: [
			/* @__PURE__ */ f("p", { children: [
				t("games.take-time.baseRule"),
				" ",
				t(n.unlimited ? "games.take-time.unlimitedRule" : "games.take-time.capRule")
			] }),
			n.pairs && /* @__PURE__ */ d("p", { children: t("games.take-time.pairsRule") }),
			n.difference && /* @__PURE__ */ d("p", { children: t("games.take-time.differenceRule") }),
			n.handRule && /* @__PURE__ */ d("p", { children: t(n.handRule === "high" ? "games.take-time.highHand" : n.handRule === "low" ? "games.take-time.lowHand" : "games.take-time.leftHand") }),
			n.noFaceUp && /* @__PURE__ */ d("p", { children: t("games.take-time.noFaceRule") }),
			n.edges?.map((n, r) => /* @__PURE__ */ d("p", { children: t(n.equal ? "games.take-time.equalRule" : "games.take-time.edgeRule", {
				a: C(n.a + e.rotation) + 1,
				b: C(n.b + e.rotation) + 1,
				n: n.min ?? 0
			}) }, r)),
			n.spread !== void 0 && /* @__PURE__ */ d("p", { children: t("games.take-time.spreadRule", { n: n.spread }) }),
			n.firstHand !== void 0 && /* @__PURE__ */ d("p", { children: t("games.take-time.firstRule", { n: n.firstHand + 1 }) }),
			Array.from({ length: 6 }, (i, a) => /* @__PURE__ */ f("section", { children: [/* @__PURE__ */ d("h3", { children: t("games.take-time.segment", { n: a + 1 }) }), /* @__PURE__ */ d(te, {
				rule: n.segments[C(a - e.rotation)],
				twoLow: r
			})] }, a)),
			e.rebirth && /* @__PURE__ */ f("section", { children: [/* @__PURE__ */ d("h3", { children: t("games.take-time.rebirthActive") }), e.variants.length ? /* @__PURE__ */ d("ul", { children: e.variants.map((e) => /* @__PURE__ */ d("li", { children: t(X[e - 1]) }, e)) }) : /* @__PURE__ */ d("p", { children: t("games.take-time.none") })] })
		]
	});
}
//#endregion
//#region src/games/take-time/view-player.tsx
function re({ card: e, ownValue: t, name: n, inspect: r }) {
	let a = o(), { ref: s, hidden: c } = i(`tt-play:${e.order}`);
	return /* @__PURE__ */ f("button", {
		type: "button",
		className: "tt-table-card",
		ref: s,
		style: { visibility: c ? "hidden" : void 0 },
		"data-revealed": e.revealed,
		"aria-label": a("games.take-time.playedBy", {
			name: n,
			n: e.order
		}),
		onClick: (i) => {
			i.stopPropagation(), r(`${a("games.take-time.playedBy", {
				name: n,
				n: e.order
			})} · ${e.value == null ? t === void 0 ? a("games.take-time.hidden") : a("games.take-time.ownCard", { n: t }) : a("games.take-time.value", { n: e.value })}`);
		},
		children: [/* @__PURE__ */ d(Y, {
			suit: e.suit,
			value: e.value
		}), /* @__PURE__ */ d("small", { children: e.order })]
	});
}
function ie({ pub: e, index: t, legal: n, active: r, onChoose: a, nameOf: s, priv: c, inspect: l }) {
	let u = o(), { ref: p } = i(`tt-segment:${t}`), m = t * Math.PI / 3;
	return /* @__PURE__ */ f("div", {
		ref: p,
		className: "tt-pocket",
		"data-legal": n,
		"data-hand": e.hand === t,
		"data-problem": e.issues.some((e) => e.segment === t),
		style: {
			left: `${50 + 39 * Math.sin(m)}%`,
			top: `${50 - 39 * Math.cos(m)}%`
		},
		children: [
			n && /* @__PURE__ */ d("svg", {
				className: "tt-target-ring",
				viewBox: "0 0 100 100",
				preserveAspectRatio: "none",
				"aria-hidden": "true",
				children: /* @__PURE__ */ d("rect", {
					x: "1",
					y: "1",
					width: "98",
					height: "98",
					rx: "9",
					fill: "none",
					stroke: "#ffe4a0",
					strokeWidth: "2",
					vectorEffect: "non-scaling-stroke",
					strokeDasharray: "7 5",
					children: /* @__PURE__ */ d("animate", {
						attributeName: "stroke-dashoffset",
						from: "0",
						to: "-24",
						dur: "1.2s",
						repeatCount: "indefinite"
					})
				})
			}),
			/* @__PURE__ */ f("button", {
				type: "button",
				className: "tt-pocket-target",
				onClick: a,
				disabled: r && !n,
				"aria-label": u("games.take-time.segment", { n: t + 1 }),
				children: [
					/* @__PURE__ */ d("b", { children: t + 1 }),
					e.hand === t && /* @__PURE__ */ d("span", {
						className: "tt-hand-mark",
						"aria-label": u("games.take-time.handHere"),
						children: "➤"
					}),
					(x[e.clock].second !== void 0 || e.variants.includes(6)) && (t === e.second || t === C(e.second + 3)) && /* @__PURE__ */ d("span", {
						className: "tt-second-mark",
						"aria-label": u("games.take-time.secondHere"),
						children: "×"
					}),
					e.sums[t] != null && /* @__PURE__ */ d("strong", { children: e.metrics[t] })
				]
			}),
			/* @__PURE__ */ d("div", {
				className: "tt-pile",
				children: e.board[t].map((e) => /* @__PURE__ */ d(re, {
					card: e,
					ownValue: c?.ownPlaced.find((t) => t.order === e.order)?.value,
					name: s(e.by),
					inspect: l
				}, e.order))
			})
		]
	});
}
function ae({ p: e, name: t, current: n }) {
	let { ref: r } = i(`tt-seat:${e.rid}`), a = o(), s = (e) => a("games.take-time.cardBack", { suit: a(e === "solar" ? "games.take-time.solar" : "games.take-time.lunar") });
	return /* @__PURE__ */ f("div", {
		ref: r,
		className: "tt-seat",
		"data-current": n,
		children: [
			/* @__PURE__ */ d("strong", { children: t }),
			/* @__PURE__ */ d("span", {
				className: "tt-seat-cards",
				children: e.hand.map((e, t) => /* @__PURE__ */ d("i", {
					"data-suit": e,
					role: "img",
					"aria-label": s(e)
				}, t))
			}),
			e.reserve > 0 && /* @__PURE__ */ f("span", {
				className: "tt-seat-reserve",
				role: "group",
				"aria-label": a("games.take-time.reserve", { n: e.reserve }),
				children: [/* @__PURE__ */ d("small", { children: a("games.take-time.reserve", { n: e.reserve }) }), /* @__PURE__ */ d("span", {
					className: "tt-seat-cards",
					children: e.reserveSuits.map((e, t) => /* @__PURE__ */ d("i", {
						"data-suit": e,
						role: "img",
						"aria-label": s(e)
					}, t))
				})]
			})
		]
	});
}
function oe({ card: e, selected: t, disabled: n, onSelect: r }) {
	let { ref: a, hidden: s } = i(`tt-hand-card:${e.id}`), c = o();
	return /* @__PURE__ */ d("button", {
		type: "button",
		ref: a,
		style: { visibility: s ? "hidden" : void 0 },
		"data-selected": t,
		disabled: n,
		"aria-label": c("games.take-time.cardLabel", {
			suit: c(e.suit === "solar" ? "games.take-time.solar" : "games.take-time.lunar"),
			n: e.value
		}),
		onClick: r,
		children: /* @__PURE__ */ d(Y, {
			suit: e.suit,
			value: e.value
		})
	});
}
function Z(e) {
	return /* @__PURE__ */ d(Q, { ...e });
}
function Q({ public: e, private: t, members: p, myRid: m, send: h }) {
	let g = e, _ = t, v = o(), y = a((e) => e.locale), [b, C] = n(null), [w, T] = n(!1), [E, D] = n(!1), [O, k] = n(!1), [A, j] = n(null), [M, N] = n(null), { ref: P } = i("tt-hand"), { ref: F } = i("tt-deck"), { ref: I } = i("tt-pending"), L = (e) => {
		let t = p.find((t) => t.rid === e);
		return t ? l(t, y) : e;
	}, z = x[g.clock], B = g.players.find((e) => e.rid === m), V = g.leader === m, H = g.phase === "placement" && !g.pending && (g.turn === null || g.turn === m), U = g.pending?.receiver === m, W = b?.clock === g.clock ? _?.hand.find((e) => e.id === b.card) : void 0, G = S(z) && (g.phase === "discussion" && !B?.ready || g.phase === "assess"), K = G && M === "hand", q = g.phase === "discussion" && !B?.ready && g.variants.includes(6) && M === "second", J = !!(W && H && !g.variants.includes(4) || U || K || q), X = R(g.clock, g.rotation, g.second, g.variants), te = (e) => {
		K ? (h({
			type: "hand",
			segment: e
		}), N(null)) : q ? (h({
			type: "second",
			segment: e
		}), N(null)) : U ? h({
			type: "place",
			segment: e
		}) : H && W && !g.variants.includes(4) ? (h({
			type: "play",
			card: W.id,
			segment: e,
			faceUp: w && g.faceUpLeft > 0 && g.board.flat().length > 0
		}), C(null)) : D(!0);
	}, re = g.phase === "discussion" ? v(B?.ready ? "games.take-time.readyWait" : "games.take-time.discussion") : g.phase === "reveal" ? v("games.take-time.reveal") : g.phase === "assess" ? v("games.take-time.assess") : g.phase === "result" ? v(g.success ? "games.take-time.pass" : "games.take-time.fail") : g.phase === "done" ? v("games.take-time.resultSaved") : g.pending ? v(U ? "games.take-time.receive" : "games.take-time.waitReceive", { name: L(g.pending.receiver) }) : g.turn === null ? v("games.take-time.first") : H ? v("games.take-time.placement") : v("games.take-time.waitTurn", { name: L(g.turn) }), Z = g.progress.findIndex((e, t) => t > g.clock && e === "untried"), Q = (e) => N(M === e ? null : e);
	return /* @__PURE__ */ f(c, {
		adaptive: !0,
		scroll: !1,
		className: "tt-screen",
		banner: /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ f("header", {
			className: "tt-header",
			children: [
				/* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("small", { children: "TAKE TIME" }), /* @__PURE__ */ f("h1", { children: [
					z.chapter,
					".",
					z.test
				] })] }),
				/* @__PURE__ */ d("span", { children: v("games.take-time.faceUp", { n: g.faceUpLeft }) }),
				g.bonus > 0 && /* @__PURE__ */ d("span", { children: v("games.take-time.bonus", { n: g.bonus }) }),
				/* @__PURE__ */ d("button", {
					type: "button",
					onClick: () => k(!0),
					children: v("games.take-time.journey")
				}),
				/* @__PURE__ */ d("button", {
					type: "button",
					onClick: () => D(!0),
					children: v("games.take-time.rulesTitle")
				})
			]
		}), /* @__PURE__ */ d("div", {
			className: "tt-seats",
			children: g.players.map((e) => /* @__PURE__ */ d(ae, {
				p: e,
				name: L(e.rid),
				current: e.rid === g.turn || e.rid === g.pending?.receiver
			}, e.rid))
		})] }),
		children: [/* @__PURE__ */ f("div", {
			className: "tt-layout",
			children: [/* @__PURE__ */ d("main", {
				className: "tt-stage",
				children: /* @__PURE__ */ f("div", {
					className: "tt-clock-scene",
					children: [
						/* @__PURE__ */ d("img", {
							className: "tt-clock-art",
							src: r(`games/take-time/clock-${g.clock + 1}.svg`),
							alt: "",
							draggable: !1,
							style: { transform: `rotate(${g.rotation * 60}deg)` }
						}),
						Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ d(ie, {
							pub: g,
							index: t,
							legal: J && (K || q || X.includes(t)),
							active: J,
							onChoose: () => te(t),
							priv: _,
							nameOf: L,
							inspect: j
						}, t)),
						/* @__PURE__ */ d("div", {
							ref: F,
							className: "tt-deck",
							children: /* @__PURE__ */ d("span", { children: g.deckCount })
						})
					]
				})
			}), /* @__PURE__ */ f("aside", {
				className: "tt-workbench",
				children: [
					/* @__PURE__ */ d("div", {
						className: "tt-phase",
						"aria-live": "polite",
						children: re
					}),
					/* @__PURE__ */ f("div", {
						className: "tt-hand-tools",
						children: [G && /* @__PURE__ */ d("button", {
							type: "button",
							"data-selected": K,
							onClick: () => Q("hand"),
							children: v("games.take-time.handChoice")
						}), g.phase === "discussion" && !B?.ready && g.variants.includes(6) && /* @__PURE__ */ d("button", {
							type: "button",
							"data-selected": q,
							onClick: () => Q("second"),
							children: v("games.take-time.secondChoice")
						})]
					}),
					/* @__PURE__ */ f("div", {
						className: "tt-hand",
						ref: P,
						children: [_?.hand.map((e) => /* @__PURE__ */ d(oe, {
							card: e,
							selected: W?.id === e.id,
							disabled: !H || !_.playable.includes(e.id),
							onSelect: () => C(W?.id === e.id ? null : {
								clock: g.clock,
								card: e.id
							})
						}, e.id)), g.phase === "discussion" && !B?.ready && B?.hand.map((e, t) => /* @__PURE__ */ d(Y, { suit: e }, t))]
					}),
					/* @__PURE__ */ d("div", {
						ref: I,
						className: "tt-received",
						children: g.pending && /* @__PURE__ */ d(Y, {
							suit: g.pending.suit,
							value: g.pending.value
						})
					}),
					/* @__PURE__ */ f("div", {
						className: "tt-actions",
						children: [
							g.canRedeal && V && /* @__PURE__ */ d("button", {
								type: "button",
								onClick: () => h({ type: "redeal" }),
								children: v("games.take-time.redeal")
							}),
							g.phase === "discussion" && !B?.ready && /* @__PURE__ */ d("button", {
								type: "button",
								className: "tt-primary",
								onClick: () => h({ type: "ready" }),
								children: v("games.take-time.ready")
							}),
							H && /* @__PURE__ */ f("label", {
								className: "tt-faceup",
								children: [/* @__PURE__ */ d("input", {
									type: "checkbox",
									checked: w && g.faceUpLeft > 0 && g.board.flat().length > 0,
									disabled: g.faceUpLeft <= 0 || g.board.flat().length === 0,
									onChange: (e) => T(e.target.checked)
								}), v("games.take-time.faceUpToggle")]
							}),
							H && g.variants.includes(4) && /* @__PURE__ */ d("button", {
								type: "button",
								className: "tt-primary",
								disabled: !W,
								onClick: () => {
									W && (h({
										type: "give",
										card: W.id,
										faceUp: w && g.faceUpLeft > 0 && g.board.flat().length > 0
									}), C(null));
								},
								children: v("games.take-time.give")
							}),
							g.phase === "assess" && V && /* @__PURE__ */ d("button", {
								type: "button",
								className: "tt-primary",
								onClick: () => h({ type: "judge" }),
								children: v("games.take-time.judge")
							}),
							g.phase === "result" && V && /* @__PURE__ */ f(u, { children: [
								/* @__PURE__ */ d("button", {
									type: "button",
									className: "tt-primary",
									onClick: () => h({ type: "retry" }),
									children: v("games.take-time.retry")
								}),
								Z >= 0 && /* @__PURE__ */ d("button", {
									type: "button",
									onClick: () => h({
										type: "continue",
										clock: Z
									}),
									children: v("games.take-time.next")
								}),
								/* @__PURE__ */ d("button", {
									type: "button",
									onClick: () => h({ type: "finish" }),
									children: v("games.take-time.finish")
								})
							] })
						]
					}),
					(g.phase === "assess" || g.phase === "result") && g.issues.length > 0 && /* @__PURE__ */ d("ul", {
						className: "tt-issues",
						children: g.issues.map((e, t) => /* @__PURE__ */ d("li", { children: v("games.take-time.problem", {
							where: e.segment < 0 ? v("games.take-time.whole") : v("games.take-time.segment", { n: e.segment + 1 }),
							rule: v(ee[e.kind])
						}) }, t))
					})
				]
			})]
		}), (E || O || A) && /* @__PURE__ */ d("div", {
			className: "tt-dialog-shade",
			onClick: () => {
				D(!1), k(!1), j(null);
			},
			children: /* @__PURE__ */ f("section", {
				className: "tt-dialog",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": v(E ? "games.take-time.rulesTitle" : O ? "games.take-time.journey" : "games.take-time.inspect"),
				onClick: (e) => e.stopPropagation(),
				children: [/* @__PURE__ */ d("button", {
					type: "button",
					className: "tt-dialog-close",
					"aria-label": v("games.take-time.close"),
					onClick: () => {
						D(!1), k(!1), j(null);
					},
					children: /* @__PURE__ */ d(s, { size: 20 })
				}), E ? /* @__PURE__ */ d(ne, { pub: g }) : O ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("h2", { children: v("games.take-time.passed", { n: g.progress.filter((e) => e === "passed").length }) }), /* @__PURE__ */ d("div", {
					className: "tt-journey-grid",
					children: x.map((e, t) => /* @__PURE__ */ f("button", {
						type: "button",
						"data-progress": g.progress[t],
						disabled: g.phase !== "result" || !V,
						onClick: () => {
							h({
								type: "continue",
								clock: t
							}), k(!1);
						},
						"aria-label": `${e.chapter}.${e.test} · ${g.progress[t] === "passed" ? v("games.take-time.pass") : g.progress[t] === "regret" ? v("games.take-time.fail") : v("games.take-time.untried")}`,
						children: [
							e.chapter,
							".",
							e.test
						]
					}, t))
				})] }) : /* @__PURE__ */ d("p", { children: A })]
			})
		})]
	});
}
//#endregion
//#region src/games/take-time/bot.ts
var se = {
	order: 1,
	overflow: 14,
	count: 18,
	empty: 18,
	special: 12,
	balance: 1.5
};
function ce(e) {
	let t = Math.floor(2 ** 32 / e) * e, n;
	do
		n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (n >= t);
	return n % e;
}
function le(e, t) {
	let n = new Map(t.ownPlaced.map((e) => [e.order, e.value]));
	return e.board.map((e) => e.map((e) => ({
		...e,
		value: e.value ?? n.get(e.order) ?? 6.5
	})));
}
function $(e, t, n, r, i) {
	let a = x[e.clock], o = le(e, t).map((e) => [...e]), s = a.segments[C(r - e.rotation)], c = o[r].length, l = e.board.flat().length + 1;
	o[r].push({
		...n,
		by: "",
		placer: "",
		order: l,
		faceUp: !1,
		revealed: !1
	});
	let u = o.map((e) => e.reduce((e, t) => e + t.value, 0)), d = e.hand, f = C(r - d), p = 3 + f * 3.7, m = -Math.abs(u[r] - p) * i.order;
	c === 0 && (m += i.empty * (l > 7 ? 2 : 1)), !a.unlimited && u[r] > 24 && (m -= (u[r] - 24) * i.overflow), a.pairs && c >= 2 && (m -= i.count * (c - 1)), s.count !== void 0 && (m -= Math.max(0, c + 1 - s.count) * i.count), s.solar !== void 0 && n.suit === "solar" && o[r].filter((e) => e.suit === "solar").length > s.solar && (m -= i.count), s.lunar !== void 0 && n.suit === "lunar" && o[r].filter((e) => e.suit === "lunar").length > s.lunar && (m -= i.count), s.forbidden?.includes(n.value) && (m -= i.special * 4), s.plays?.includes(l) && (m += i.special * 5), a.segments.some((t, n) => n !== C(r - e.rotation) && t.plays?.includes(l)) && (m -= i.special * 5), s.last && e.players.reduce((e, t) => e + t.hand.length, 0) === 1 && !(s.draw && e.deckCount > 0) && (m += i.special * 5), s.range && (m -= Math.max(0, u[r] - s.range[1]) * i.special), s.closest !== void 0 && (m -= Math.abs(u[r] - s.closest) * i.balance), (s.extreme === "high" || s.extreme === "lunarHigh" && n.suit === "lunar" || s.alsoExtreme === "lunarHigh" && n.suit === "lunar") && (m += (n.value - 6.5) * i.special), (s.extreme === "low" || s.extreme === "solarLow" && n.suit === "solar") && (m += (6.5 - n.value) * i.special), a.difference && c === 1 && (m -= Math.abs(Math.abs(o[r][0].value - n.value) - f * 1.7) * i.order * 2);
	let h = C(r - 1), g = C(r + 1);
	return f > 0 && o[h].length && u[r] < u[h] && (m -= (u[h] - u[r]) * i.balance), f < 5 && o[g].length && u[r] > u[g] + 8 && (m -= (u[r] - u[g] - 8) * i.balance), m;
}
function ue(e = se) {
	return ({ public: t, private: n }, r) => {
		if (!n || t.phase === "done" || t.phase === "reveal") return null;
		if (t.phase === "discussion") return t.players.find((e) => e.rid === r.rid)?.ready ? null : { action: { type: "ready" } };
		if (t.phase === "assess") {
			if (r.rid !== t.leader) return null;
			if (S(x[t.clock])) {
				let e = le(t, n), r = Array.from({ length: 6 }, (n, r) => B(t.clock, e, t.rotation, r, t.variants).issues.length), i = r.indexOf(Math.min(...r));
				if (r[i] < r[t.hand]) return { action: {
					type: "hand",
					segment: i
				} };
			}
			return { action: { type: "judge" } };
		}
		if (t.phase === "result") return r.rid === t.leader ? { action: { type: "finish" } } : null;
		if (t.pending && t.pending.receiver !== r.rid || !t.pending && t.turn !== null && t.turn !== r.rid) return null;
		let i = R(t.clock, t.rotation, t.second, t.variants);
		if (t.pending) {
			let a = {
				id: -1,
				suit: t.pending.suit,
				value: t.pending.value ?? 6.5
			}, o = [...i].sort((r, i) => $(t, n, a, i, e) - $(t, n, a, r, e));
			return { action: {
				type: "place",
				segment: r.difficulty === "weak" ? i[ce(i.length)] : o[0]
			} };
		}
		let a = n.hand.filter((e) => n.playable.includes(e.id));
		if (!a.length) return null;
		let o = a.flatMap((r) => i.map((i) => ({
			card: r,
			segment: i,
			score: $(t, n, r, i, e)
		}))).sort((e, t) => t.score - e.score), s = r.difficulty === "weak" ? o[ce(o.length)] : o[0], c = t.faceUpLeft > 0 && t.board.flat().length > 0 && (s.card.value <= 3 || s.card.value >= 10 || t.players.reduce((e, t) => e + t.hand.length, 0) <= t.faceUpLeft);
		return { action: t.variants.includes(4) ? {
			type: "give",
			card: s.card.id,
			faceUp: c
		} : {
			type: "play",
			card: s.card.id,
			segment: s.segment,
			faceUp: c
		} };
	};
}
var de = ue(), fe = {
	play(e, t) {
		let n = e.data, r = t.anchor(n.gifted ? "tt-pending" : e.rid === t.myRid ? "tt-hand" : `tt-seat:${e.rid}`), i = t.anchor(`tt-play:${n.order}`);
		if (!r || !i) return null;
		let a = {
			x: r.x + r.w / 2 - i.w / 2,
			y: r.y + r.h / 2 - i.h / 2,
			w: i.w,
			h: i.h
		};
		return {
			ms: 450,
			hide: [`tt-play:${n.order}`],
			node: /* @__PURE__ */ d(p, {
				from: a,
				to: i,
				ms: 390,
				children: /* @__PURE__ */ d(Y, {
					suit: n.suit,
					value: n.value,
					style: { width: i.w }
				})
			})
		};
	},
	reveal() {
		return {
			ms: 620,
			node: null
		};
	},
	rotate() {
		return {
			ms: 480,
			node: null
		};
	},
	draw(e, t) {
		let n = e.data, r = e.secret, i = e.rid === t.myRid && r ? `tt-hand-card:${r.id}` : `tt-seat:${e.rid}`, a = t.anchor("tt-deck"), o = t.anchor(i);
		if (!a || !o) return null;
		let s = e.rid === t.myRid, c = s ? o.w : 30, l = s ? o.h : 10050 / 240, u = {
			x: o.x + o.w / 2 - c / 2,
			y: o.y + o.h / 2 - l / 2,
			w: c,
			h: l
		};
		return {
			ms: 430,
			hide: r && s ? [i] : [],
			node: /* @__PURE__ */ d(p, {
				from: {
					...a,
					w: c,
					h: l
				},
				to: u,
				ms: 380,
				children: /* @__PURE__ */ d(Y, {
					suit: n.suit,
					style: { width: c }
				})
			})
		};
	},
	reserve(e, t) {
		let n = e.data, r = e.secret, i = t.anchor(`tt-seat:${e.rid}`);
		if (!i) return null;
		let a = [];
		return {
			ms: 480,
			hide: a,
			node: n.suits.map((n, o) => {
				let s = e.rid === t.myRid && r ? `tt-hand-card:${r.ids[o]}` : `tt-seat:${e.rid}`, c = t.anchor(s);
				if (!c) return null;
				r && e.rid === t.myRid && a.push(s);
				let l = e.rid === t.myRid ? c.w : 30, u = l * 335 / 240;
				return /* @__PURE__ */ d(p, {
					from: {
						...i,
						w: l,
						h: u
					},
					to: {
						...c,
						w: l,
						h: u
					},
					ms: 340,
					delay: o * 70,
					children: /* @__PURE__ */ d(Y, {
						suit: n,
						style: { width: l }
					})
				}, o);
			})
		};
	},
	give(e, t) {
		let n = e.data, r = t.anchor(e.rid === t.myRid ? "tt-hand" : `tt-seat:${e.rid}`), i = t.anchor("tt-pending");
		return !r || !i ? null : {
			ms: 400,
			hide: ["tt-pending"],
			node: /* @__PURE__ */ d(p, {
				from: {
					x: r.x + r.w / 2 - i.w / 2,
					y: r.y + r.h / 2 - i.h / 2,
					w: i.w,
					h: i.h
				},
				to: i,
				ms: 350,
				children: /* @__PURE__ */ d(Y, {
					suit: n.suit,
					value: n.value,
					style: { width: i.w }
				})
			})
		};
	},
	deal(e, t) {
		let n = e.data, r = t.anchor("tt-deck"), i = t.anchor(`tt-seat:${e.rid}`);
		return !r || !i ? null : {
			ms: 450 + n.suits.length * 40,
			node: n.suits.map((e, t) => /* @__PURE__ */ d(p, {
				from: {
					...r,
					w: 25,
					h: 38
				},
				to: {
					...i,
					w: 25,
					h: 38
				},
				ms: 350,
				delay: t * 40,
				children: /* @__PURE__ */ d(Y, {
					suit: e,
					style: { width: 25 }
				})
			}, t))
		};
	}
};
//#endregion
//#region src/games/take-time/game-over.tsx
function pe(e) {
	let t = o(), r = a((e) => e.locale), i = e.public, [c, p] = n(!0), m = i.progress.filter((e) => e === "passed").length, [h, g] = n(null);
	return /* @__PURE__ */ f("div", {
		className: "tt-ending-root",
		children: [/* @__PURE__ */ d(Q, {
			public: i,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}), c ? /* @__PURE__ */ f("section", {
			className: "tt-ending",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": t("games.take-time.resultTitle"),
			children: [
				/* @__PURE__ */ d("button", {
					type: "button",
					className: "tt-ending-close",
					"aria-label": t("games.take-time.returnBoard"),
					onClick: () => p(!1),
					children: /* @__PURE__ */ d(s, { size: 20 })
				}),
				/* @__PURE__ */ d("h1", { children: t("games.take-time.resultTitle") }),
				/* @__PURE__ */ d("p", { children: t(m === 40 ? "games.take-time.resultComplete" : "games.take-time.resultSaved") }),
				/* @__PURE__ */ f("div", {
					className: "tt-ending-body",
					tabIndex: 0,
					children: [/* @__PURE__ */ d("div", {
						className: "tt-journey-grid",
						children: x.map((e, n) => /* @__PURE__ */ f("span", {
							"data-progress": i.progress[n],
							title: i.progress[n] === "passed" ? t("games.take-time.pass") : i.progress[n] === "regret" ? t("games.take-time.fail") : t("games.take-time.untried"),
							children: [
								e.chapter,
								".",
								e.test
							]
						}, n))
					}), /* @__PURE__ */ f("div", {
						className: "tt-ending-people",
						children: [
							/* @__PURE__ */ d("h2", { children: t("games.take-time.passed", { n: m }) }),
							/* @__PURE__ */ d("p", { children: t("games.take-time.regrets", { n: i.progress.filter((e) => e === "regret").length }) }),
							/* @__PURE__ */ d("ul", { children: e.members.filter((e) => i.players.some((t) => t.rid === e.rid)).map((n) => /* @__PURE__ */ f("li", { children: [l(n, r), (e.result.autopilot?.[n.rid] ?? 0) > 0 && /* @__PURE__ */ f("small", { children: [" · ", t("session.autopilot.share", { n: Math.round(e.result.autopilot[n.rid] * 100) })] })] }, n.rid)) }),
							e.hintCount !== void 0 && e.hintCount > 0 && /* @__PURE__ */ d("p", { children: t("session.hint.usedCount", { n: e.hintCount }) })
						]
					})]
				}),
				/* @__PURE__ */ f("div", {
					className: "tt-end-controls",
					children: [h ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("button", {
						type: "button",
						onClick: () => {
							let t = h === "again" ? e.onPlayAgain : e.onBackToLobby;
							g(null), t?.();
						},
						children: t(h === "again" ? "games.take-time.confirmAgain" : "games.take-time.confirmLobby")
					}), /* @__PURE__ */ d("button", {
						type: "button",
						onClick: () => g(null),
						children: t("games.take-time.cancel")
					})] }) : /* @__PURE__ */ f(u, { children: [e.onPlayAgain && /* @__PURE__ */ d("button", {
						type: "button",
						onClick: () => g("again"),
						children: t("session.result.playAgain")
					}), e.onBackToLobby && /* @__PURE__ */ d("button", {
						type: "button",
						onClick: () => g("lobby"),
						children: t("session.result.backToLobby")
					})] }), !e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ d("p", { children: t("session.result.waitHost") })]
				})
			]
		}) : /* @__PURE__ */ d("button", {
			type: "button",
			className: "tt-result-restore",
			onClick: () => p(!0),
			children: t("games.take-time.showResult")
		})]
	});
}
//#endregion
//#region src/games/take-time/options.tsx
function me({ value: e, onChange: t }) {
	let n = o(), r = O.safeParse(e), i = r.success ? r.data : O.parse(void 0);
	return /* @__PURE__ */ f("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ d(g, {
				title: n("games.take-time.startClock"),
				columns: 3,
				children: x.map((e, n) => /* @__PURE__ */ d(h, {
					name: "tt-clock",
					value: String(n),
					checked: i.clock === n,
					label: `${e.chapter}.${e.test}`,
					onChange: () => t({
						...i,
						clock: n
					})
				}, n))
			}),
			/* @__PURE__ */ d(_, {
				checked: i.rebirth,
				label: n("games.take-time.rebirth"),
				hint: n("games.take-time.rebirthHint"),
				onChange: () => t({
					...i,
					rebirth: !i.rebirth
				})
			}),
			i.rebirth && /* @__PURE__ */ d(g, {
				title: n("games.take-time.rebirthActive"),
				children: X.map((e, r) => /* @__PURE__ */ d(m, {
					name: "tt-variant",
					value: String(r + 1),
					checked: i.variants.includes(r + 1),
					label: n(e),
					onChange: () => t({
						...i,
						variants: i.variants.includes(r + 1) ? i.variants.filter((e) => e !== r + 1) : [...i.variants, r + 1]
					})
				}, e))
			}),
			i.rebirth && /* @__PURE__ */ d("p", {
				className: "text-sm",
				children: n("games.take-time.variant4Hint")
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/take-time/entry.tsx
var he = {
	definition: J,
	View: Z,
	bot: de,
	fx: fe,
	OverView: pe,
	Options: me,
	locales: {
		zh: {
			name: "时序谜局",
			desc: "以无声的默契，将时间排成一圈。40个合作挑战与重生变体。",
			rules: "目标:\n共同完成六扇区时钟的挑战。基本盒有10章、每章4关，可连续挑战，也可在结果页结束本次旅程；进度随对局记录保存。首次游玩从1.1开始。\n准备:\n太阳牌与月亮牌各有1至12，共24张。洗牌后发出12张：4人各3张，3人各4张；2人各6张，先拿起4张，另外2张作为储备，只能看牌背颜色，不能先看数值。\n讨论:\n先看时钟、规则与手牌背面的颜色，讨论策略，不能看数值，也不能约定与游戏动作无关的暗号。按“拿起手牌”后可以看自己的牌，但不能再参与讨论。第三章起可在讨论时选择时针；8.4与第十章使用盘面固定时针。\n放牌:\n所有人准备后，任意玩家自行先出一张盖牌，之后严格按座位顺时针轮流出1张。放牌阶段禁止交流。每人只能看自己的手牌及自己打出的盖牌；其他盖牌的颜色、出牌者与顺序公开。2、3、4人分别共用2、3、4次亮牌，首张必须盖下。在第2.4关中，禁止将卡牌正面朝上打出。2人双方各出2张后，各自的2张储备同时加入手牌。\n结算:\n所有手牌用完后，从时针起逐区、逐张揭牌。每区至少1张，从时针起顺时针总值不得下降，且每区不超过24；1.1至1.3取消24上限。所有额外条件也必须满足。第三至第九章的自由时针在全部揭牌后可重新选择，再确认结果。\n章节条件:\n盘面规则图示可在“挑战规则”中查阅文字。张数与指定颜色组合必须精确匹配。点数最高或最低的卡牌可以有多张并列；两区最低牌条件要求两区各持有一张最低牌，其他区不能有低于这两张中较高者的牌。准星表示本区总值最接近该数值，允许并列。1/2/3表示全桌对应序号的出牌，红色末张表示全桌最后一张。\n· 第四章：按本人当前最高、最低或左起第一张出牌，固定顺序不能重排；2人补入储备放在右侧。\n· 第五章：每个扇区必须恰好放置2张牌。\n· 第六章：每个扇区必须恰好放置2张牌。比较扇区顺序时，使用两张牌的点数差值；其他图示仍使用点数总和。\n· 第七章：在标有抽牌效果的扇区打出卡牌后，立即从尚未发出的牌堆中抽取1张牌；牌堆为空时不抽牌。轮到手牌已经用完的玩家时，跳过该玩家。\n· 第八章：按图示转盘，所有牌堆留在物理原位，自由时针留原位，8.4印刷时针随盘转；禁止区不能直接放牌。\n· 第九章：检查相邻总值差或全盘总值差。\n· 第十章：除了总值顺序，还从细指针起比较每区第一张牌的值；10.4双向秒针起指2、5区，每回合顺时针转1区，指向区不能放牌。\n失败与旅程:\n失败后可重试，增加1个奖励，最多3个，每个奖励在下一次尝试增加1次亮牌；成功或换关清空奖励。跳过的关进入遗憾袖套，可以在结果页回访。全部40关通过才完成全旅程；结果页显示真实通过和未完成情况。\n重生:\n建议在尝试过全部 40 关后，再在开局选项中启用重生。以下六项变体可以组合使用，默认均关闭：\n· 多牌扇区的数值变化：结算时，10、11、12 分别视为 0、1、2。所有结算条件均使用变化后的数值，手牌的出牌限制仍使用原数值。\n· 总和差值限制：所有扇区总和中的最高值与最低值之差不得超过 12。\n· 优先打出太阳牌：手中有太阳牌时，必须先打出太阳牌。此变体不能用于第四章。\n· 向左侧传牌：交给左侧玩家 1 张牌，由对方选择放置位置。给牌者决定正面或背面朝上放置，背面朝上的牌不能偷看。第七章触发的抽牌归给牌者。\n· 减少亮牌次数：可用的亮牌次数减少 2 次。\n· 双向秒针：讨论时选择双向秒针，其指向的两个相对扇区不能放牌；每回合将秒针转动 1 个扇区。此变体不能用于第八章。\n不兼容的变体会在对应章节自动停用，当前规则中会显示实际生效的变体。",
			challenge: "{{chapter}}.{{test}}",
			rulesTitle: "挑战规则",
			journey: "旅程",
			faceUp: "亮牌 {{n}}",
			bonus: "奖励 {{n}}",
			solar: "太阳牌",
			lunar: "月亮牌",
			segment: "扇区 {{n}}",
			value: "数值 {{n}}",
			cardLabel: "{{suit}} {{n}}",
			cardBack: "{{suit}}背面",
			hidden: "盖牌",
			reserve: "储备 {{n}}",
			discussion: "先讨论策略，再拿起手牌",
			ready: "拿起手牌",
			readyWait: "已拿起手牌，请保持安静",
			placement: "选一张牌，再点放置的扇区",
			first: "任意玩家先出一张盖牌",
			waitTurn: "等待 {{name}} 出牌",
			reveal: "逐张揭牌",
			assess: "核对时针与挑战条件",
			give: "交给左邻",
			receive: "请选择收到牌的落点",
			waitReceive: "等待 {{name}} 放牌",
			faceUpToggle: "亮牌",
			judge: "确认结果",
			retry: "再次尝试",
			next: "下一关",
			finish: "结束本次旅程",
			pass: "挑战通过",
			fail: "尚未通过",
			passed: "已通过 {{n}} / 40",
			regrets: "遗憾 {{n}}",
			untried: "未尝试",
			resultTitle: "时间的旅程",
			resultComplete: "40个时钟，全部完成",
			resultSaved: "本次旅程已结束",
			returnBoard: "回看时钟",
			showResult: "查看旅程",
			handChoice: "选择时针起点",
			secondChoice: "选择双向秒针起点",
			handHere: "时针起点",
			secondHere: "禁止落牌",
			inspect: "查看扇区",
			close: "关闭",
			ownCard: "你打出的牌：{{n}}",
			order: "第 {{n}} 张",
			playedBy: "{{name}} · 第 {{n}} 张",
			total: "总值 {{n}}",
			difference: "差值 {{n}}",
			emptyRule: "至少1张，按时针顺序排列",
			countRule: "恰好 {{n}} 张",
			solarRule: "太阳牌 {{n}} 张",
			lunarRule: "月亮牌 {{n}} 张",
			rangeRule: "总值 {{a}} 至 {{b}}",
			closestRule: "总值最接近 {{n}}",
			highRule: "包含全桌最高牌",
			lowRule: "包含全桌最低牌",
			twoLowRule: "两区各持有全桌两张最低牌之一",
			solarLowRule: "包含最低太阳牌",
			lunarHighRule: "包含最高月亮牌",
			forbidRule: "不得有数值 {{n}}",
			playRule: "包含全桌第 {{n}} 张牌",
			lastRule: "包含全桌最后一张",
			drawRule: "落牌后抽1张",
			clockwise: "落牌后顺时针转1区",
			counterclockwise: "落牌后逆时针转1区",
			blockedRule: "禁止直接落牌",
			baseRule: "从时针起，六区总值不下降，每区至少1张。",
			capRule: "每区不超过24。",
			unlimitedRule: "本关没有24上限。",
			pairsRule: "每区恰好2张。",
			differenceRule: "比较每区两张牌的差值，其他条件仍看总和。",
			highHand: "每次必须出本人最高牌。",
			lowHand: "每次必须出本人最低牌。",
			leftHand: "手牌顺序固定，每次出最左侧一张。",
			noFaceRule: "本关禁止亮牌，包括奖励额度。",
			edgeRule: "扇区 {{a}} 与 {{b}} 的总值差至少为 {{n}}。",
			equalRule: "扇区 {{a}} 与 {{b}} 的总值相等。",
			spreadRule: "六区总值最高与最低相差不超过 {{n}}。",
			firstRule: "从细指针扇区 {{n}} 起，每区第一张牌的数值不下降。",
			issueEmpty: "缺少牌",
			issueOrder: "数值顺序",
			issueLimit: "超过24",
			issueCount: "张数",
			issueColor: "颜色组合",
			issueRange: "总值范围",
			issueClosest: "最接近数值",
			issueExtreme: "最高或最低牌",
			issueForbidden: "禁止数值",
			issuePlays: "出牌次序",
			issueLast: "最后一张",
			issueEdge: "相邻差值",
			issueSpread: "全盘差值",
			issueFirst: "首牌顺序",
			problem: "{{where}}：{{rule}}",
			whole: "全盘",
			startClock: "开始挑战",
			rebirth: "重生",
			rebirthHint: "供已经尝试过全部40关的玩家启用。",
			variant1: "十位归零",
			variant2: "总值差不超过12",
			variant3: "太阳牌优先",
			variant4: "交给左邻放牌",
			variant5: "减少2次亮牌",
			variant6: "双向秒针",
			rebirthActive: "生效变体",
			none: "无",
			variant4Hint: "第四章停用太阳牌优先；第八章停用重生双向秒针。",
			confirmAgain: "确认开始新旅程",
			confirmLobby: "确认返回大厅",
			cancel: "取消",
			redeal: "颜色不足，重新发牌",
			peek: "查看自己的盖牌",
			errAction: "当前无法执行这个动作，请检查回合、牌张和目标。"
		},
		en: {
			name: "Take Time",
			desc: "Build a circle of time through silent cooperation. 40 tests and Rebirth variants.",
			rules: "Goal:\nCooperate to pass a six-segment clock. The base game has 10 chapters of 4 tests. Continue for as many tests as you like, or finish your session after a result; progress stays in the match record. Start at 1.1 for your first game.\nSetup:\nThe deck contains Solar and Lunar cards numbered 1–12 each. Shuffle all 24 and deal 12: 3 each with four players, 4 each with three, or 6 each with two. With two players, pick up only 4; leave 2 as reserves, with their card-back colors visible but values hidden.\nDiscussion:\nReview the clock and card-back colors, without looking at values. Discuss a strategy, but do not devise signals unrelated to game actions. After choosing “Pick up cards”, you may see your hand but cannot participate in discussion. From Chapter 3, choose a Clock Hand during discussion; 8.4 and Chapter 10 use printed hands.\nPlacement:\nAfter everyone is ready, any player may begin independently with one facedown card. Continue clockwise by seat, one card per turn, without communication. You may review your own hand and your own facedown cards, but no other hidden cards. Colors, owners and play order are public. The group shares 2, 3 or 4 faceup placements with 2, 3 or 4 players; the first card must be facedown. Test 2.4 forbids all faceup play. With two players, both reserves enter their owners’ hands after both have played two cards.\nResolution:\nAfter all hands are empty, reveal cards individually, segment by segment, clockwise from the Hand. Every segment needs at least one card, and values must not decrease clockwise from the Hand. Each segment must be at most 24, except in 1.1–1.3. Meet every additional condition. With the movable Hand in Chapters 3–9, you may adjust its starting segment after all cards have been revealed, then confirm the result.\nChapter conditions:\nUse “Test rules” for descriptions of the clock symbols. Exact counts and color combinations must match. Highest/lowest cards permit ties. If two segments require the lowest cards, each must hold one of them; no card in any other segment may be lower than the higher of those two cards. A target means the closest segment sum to that value, allowing ties. 1/2/3 identify the group’s first, second or third play; the red final-card symbol identifies the last play.\n· Chapter 4 requires your current highest, lowest or leftmost card; fixed hand order cannot be changed and two-player reserves are appended on the right.\n· Chapter 5 requires exactly two cards per segment.\n· Chapter 6 also requires pairs, but compares the differences between each pair; other conditions still use sums.\n· Chapter 7 draw segments immediately draw a card from the undealt deck, if available; skip empty-handed seats.\n· In Chapter 8 the clock rotates as indicated, while piles stay at their physical locations. The movable Hand stays put; 8.4’s printed Hand rotates with its clock. Blocked segments cannot receive direct placements.\n· Chapter 9 compares adjacent sums or the overall sum range.\n· Chapter 10 additionally compares each segment’s first card, starting from the slender Hand. In 10.4 the Second Hand initially blocks segments 2 and 5, then moves clockwise one segment after every turn.\nFailure and journey:\nAfter failure, retry with one extra Bonus token, up to three. Each adds one faceup placement to subsequent attempts. Passing or changing clocks clears bonuses. Skipped tests enter the Sleeve of Regrets and can be revisited from the result page. Passing all 40 completes the journey; the interface distinguishes passed, unfinished and untried tests.\nRebirth:\nRebirth is recommended only after attempting all 40 tests. Enable it in the options. All six variants can be combined and are off by default:\n· Changed values: In segments with multiple cards, values 10, 11 and 12 become 0, 1 and 2 for every resolution rule. Hand restrictions still use printed values.\n· Limited range: The difference between the highest and lowest segment sums must not exceed 12.\n· Solar first: Play a Solar card first if able. This variant is unavailable in Chapter 4.\n· Give a card: Give one card to your left neighbor to place. The giver chooses face up or face down. Facedown gifts cannot be inspected, and Chapter 7 draws go to the giver.\n· Fewer faceup cards: Reduce the faceup allowance by 2.\n· Second Hand: Choose a Second Hand during discussion. It blocks opposite segments and advances clockwise after every turn. This variant is unavailable in Chapter 8.\nIncompatible variants are disabled for their chapters. The current rules show which variants are active.",
			challenge: "{{chapter}}.{{test}}",
			rulesTitle: "Test rules",
			journey: "Journey",
			faceUp: "Faceup {{n}}",
			bonus: "Bonus {{n}}",
			solar: "Solar",
			lunar: "Lunar",
			segment: "Segment {{n}}",
			value: "Value {{n}}",
			cardLabel: "{{suit}} {{n}}",
			cardBack: "{{suit}} card back",
			hidden: "Facedown",
			reserve: "Reserve {{n}}",
			discussion: "Discuss your strategy, then pick up your cards",
			ready: "Pick up cards",
			readyWait: "Cards picked up. Remain silent",
			placement: "Choose a card, then a segment",
			first: "Any player may begin facedown",
			waitTurn: "Waiting for {{name}}",
			reveal: "Revealing cards",
			assess: "Check the Hand and test conditions",
			give: "Give to the left",
			receive: "Place the received card",
			waitReceive: "Waiting for {{name}} to place",
			faceUpToggle: "Faceup",
			judge: "Confirm result",
			retry: "Try again",
			next: "Next test",
			finish: "Finish this journey",
			pass: "Test passed",
			fail: "Not yet passed",
			passed: "Passed {{n}} / 40",
			regrets: "Regrets {{n}}",
			untried: "Untried",
			resultTitle: "A journey through time",
			resultComplete: "All 40 clocks completed",
			resultSaved: "This journey has ended",
			returnBoard: "Review clock",
			showResult: "View journey",
			handChoice: "Choose the Clock Hand",
			secondChoice: "Choose the Second Hand",
			handHere: "Clock Hand",
			secondHere: "Placement blocked",
			inspect: "Inspect segment",
			close: "Close",
			ownCard: "Your played card: {{n}}",
			order: "Play {{n}}",
			playedBy: "{{name}} · Play {{n}}",
			total: "Sum {{n}}",
			difference: "Difference {{n}}",
			emptyRule: "At least one card; follow the Clock Hand order",
			countRule: "Exactly {{n}} cards",
			solarRule: "{{n}} Solar cards",
			lunarRule: "{{n}} Lunar cards",
			rangeRule: "Sum from {{a}} to {{b}}",
			closestRule: "Sum closest to {{n}}",
			highRule: "Contains a highest card",
			lowRule: "Contains a lowest card",
			twoLowRule: "The two segments each hold one of the two lowest cards",
			solarLowRule: "Contains the lowest Solar",
			lunarHighRule: "Contains the highest Lunar",
			forbidRule: "No values {{n}}",
			playRule: "Contains play {{n}}",
			lastRule: "Contains the final play",
			drawRule: "Draw one after placement",
			clockwise: "Rotate one segment clockwise",
			counterclockwise: "Rotate one segment counterclockwise",
			blockedRule: "No direct placements",
			baseRule: "Clockwise from the Hand, sums must not decrease. At least one card per segment.",
			capRule: "Each segment at most 24.",
			unlimitedRule: "No 24 limit for this test.",
			pairsRule: "Exactly two cards per segment.",
			differenceRule: "Compare each pair’s difference; other conditions use sums.",
			highHand: "Always play your highest card.",
			lowHand: "Always play your lowest card.",
			leftHand: "Keep hand order; always play the leftmost card.",
			noFaceRule: "No faceup cards, including bonuses.",
			edgeRule: "Sums of segments {{a}} and {{b}} differ by at least {{n}}.",
			equalRule: "Segments {{a}} and {{b}} have equal sums.",
			spreadRule: "Highest and lowest segment sums differ by at most {{n}}.",
			firstRule: "From slender Hand segment {{n}}, first-card values must not decrease.",
			issueEmpty: "Missing cards",
			issueOrder: "Value order",
			issueLimit: "Over 24",
			issueCount: "Card count",
			issueColor: "Color combination",
			issueRange: "Sum range",
			issueClosest: "Closest sum",
			issueExtreme: "Highest or lowest card",
			issueForbidden: "Forbidden value",
			issuePlays: "Play order",
			issueLast: "Final card",
			issueEdge: "Adjacent difference",
			issueSpread: "Overall range",
			issueFirst: "First-card order",
			problem: "{{where}}: {{rule}}",
			whole: "Whole clock",
			startClock: "Starting test",
			rebirth: "Rebirth",
			rebirthHint: "For players who have attempted all 40 tests.",
			variant1: "Tens become zero",
			variant2: "Sum range at most 12",
			variant3: "Solar first",
			variant4: "Neighbor places",
			variant5: "Two fewer faceup cards",
			variant6: "Second Hand",
			rebirthActive: "Active variants",
			none: "None",
			variant4Hint: "Solar first is disabled in Chapter 4; Rebirth Second Hand is disabled in Chapter 8.",
			confirmAgain: "Start a new journey?",
			confirmLobby: "Return to lobby?",
			cancel: "Cancel",
			redeal: "Missing required colour: redeal",
			peek: "Inspect your facedown card",
			errAction: "That action is unavailable. Check the turn, card and target."
		}
	}
};
//#endregion
export { he as default };
