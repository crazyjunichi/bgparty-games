import { z as e } from "zod";
import { randomIntAt as t } from "@bgparty/sdk/engine/prng";
import { botAvatarOf as n, isBotRid as r } from "@bgparty/sdk/lobby";
import { PLAYER_COLORS as i } from "@bgparty/sdk/player-colors";
import { Fragment as a, useEffect as o, useLayoutEffect as s, useRef as c, useState as l } from "react";
import { avatarNameAt as u, useI18nSettings as d, useT as f } from "@bgparty/sdk/i18n";
import { AVATARS as p } from "@bgparty/sdk/avatars";
import { useFxAnchor as m } from "@bgparty/sdk/fx/anchors";
import { IconClose as h, IconPlayers as g } from "@bgparty/sdk/icons";
import { PhaseBanner as _ } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { Fragment as v, jsx as y, jsxs as b } from "react/jsx-runtime";
import { Flash as te, Floater as ne, FlySprite as re, PulseBox as ie } from "@bgparty/sdk/fx/primitives";
import { Confetti as x } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as S, OptionSection as C, OptionSwitch as w } from "@bgparty/sdk/ui/game-options";
import { createPortal as T } from "react-dom";
import { GameMenuAction as ae } from "@bgparty/sdk/game-menu";
//#region src/games/sanguosha/meta.ts
var oe = {
	id: "sanguosha",
	tier: "released",
	mechanics: ["hand-management"],
	interactionTags: ["hidden-roles", "team-based"],
	nameKey: "games.sanguosha.name",
	descKey: "games.sanguosha.desc",
	rulesKey: "games.sanguosha.rules",
	icon: "⚔️",
	iconImg: "games/sanguosha.webp",
	rulesUrl: { zh: "https://rules.bgparty.uuppi.com/sanguosha/zh.pdf" },
	minPlayers: 4,
	maxPlayers: 8,
	bestPlayers: [8],
	accent: "#b45309",
	releasedAt: "2026-10-01",
	search: {
		py: "san guo sha",
		init: "sgs"
	},
	hotseat: "cover"
}, se = e.int().min(0).max(7), ce = e.int().nonnegative(), le = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("pick-general"),
		generalId: e.string()
	}),
	e.object({
		type: e.literal("play"),
		cardIds: e.array(ce).min(1).max(2),
		target: se.optional(),
		as: e.string().optional()
	}),
	e.object({
		type: e.literal("respond"),
		cardId: ce.optional(),
		as: e.string().optional()
	}),
	e.object({
		type: e.literal("skill"),
		skill: e.string(),
		cardIds: e.array(ce).optional(),
		targets: e.array(se).optional()
	}),
	e.object({
		type: e.literal("choose"),
		cardIds: e.array(ce).optional(),
		seat: se.optional(),
		seats: e.array(se).optional(),
		option: e.string().optional()
	}),
	e.object({ type: e.literal("pass") }),
	e.object({
		type: e.literal("tick"),
		now: e.number()
	})
]), ue = e.object({
	junzheng: e.boolean().default(!1),
	wind: e.boolean().default(!0),
	fire: e.boolean().default(!0),
	forest: e.boolean().default(!0),
	mountain: e.boolean().default(!0),
	yj2011: e.boolean().default(!0),
	yj2012: e.boolean().default(!0),
	yj2013: e.boolean().default(!0),
	yj2014: e.boolean().default(!0),
	yj2015: e.boolean().default(!0),
	yj2016: e.boolean().default(!0),
	yj2017: e.boolean().default(!0),
	jie: e.boolean().default(!0),
	identity: e.enum([
		"random",
		"lord",
		"loyalist",
		"renegade",
		"rebel"
	]).default("random")
}).default({
	junzheng: !1,
	wind: !0,
	fire: !0,
	forest: !0,
	mountain: !0,
	yj2011: !0,
	yj2012: !0,
	yj2013: !0,
	yj2014: !0,
	yj2015: !0,
	yj2016: !0,
	yj2017: !0,
	jie: !0,
	identity: "random"
}), de = {
	junzheng: !1,
	wind: !0,
	fire: !0,
	forest: !0,
	mountain: !0,
	yj2011: !0,
	yj2012: !0,
	yj2013: !0,
	yj2014: !0,
	yj2015: !0,
	yj2016: !0,
	yj2017: !0,
	jie: !0,
	identity: "random"
}, fe = e.enum([
	"spade",
	"heart",
	"club",
	"diamond"
]), E = e.object({
	id: ce,
	name: e.string(),
	suit: fe,
	point: e.int().min(1).max(13)
}), pe = e.enum([
	"lord",
	"loyalist",
	"rebel",
	"renegade"
]), me = e.object({
	rid: e.string(),
	generalId: e.string().nullable(),
	identity: pe.nullable(),
	hp: e.int(),
	maxHp: e.int(),
	handCount: e.int().nonnegative(),
	equips: e.object({
		weapon: E.nullable(),
		armor: E.nullable(),
		off_horse: E.nullable(),
		def_horse: E.nullable()
	}),
	judges: e.array(E),
	chained: e.boolean(),
	turnedOver: e.boolean(),
	zishou: e.boolean(),
	chuang: e.array(E),
	tian: e.array(E),
	marks: e.record(e.string(), e.int()),
	moshi: e.array(E),
	alive: e.boolean()
}), he = e.object({
	kind: e.string(),
	asking: e.array(se),
	ctx: e.record(e.string(), e.unknown())
}), ge = e.object({
	seat: se,
	phase: e.enum([
		"judge",
		"draw",
		"play",
		"discard",
		"end"
	]),
	slashUsed: e.int().nonnegative()
}), _e = e.object({
	kind: e.string(),
	seat: se.optional(),
	card: e.string().optional(),
	cards: e.array(E.omit({ id: !0 })).optional(),
	target: se.optional(),
	n: e.int().optional(),
	from: se.optional(),
	reason: e.string().optional()
}), ve = e.object({
	card: E,
	name: e.string(),
	from: se
}), ye = e.object({
	from: se,
	targets: e.array(se)
}), be = e.object({
	seat: se,
	name: e.string(),
	result: e.enum(["hit", "miss"]).nullable()
}), xe = e.object({
	phase: e.enum([
		"select",
		"reveal",
		"battle",
		"over"
	]),
	seats: e.array(me),
	deckCount: e.int().nonnegative(),
	discardTop: E.nullable(),
	discardCount: e.int().nonnegative(),
	turn: ge.nullable(),
	pending: he.nullable(),
	tableCard: ve.nullable(),
	targeting: ye.nullable(),
	judging: be.nullable(),
	log: e.array(_e),
	logBase: e.int().nonnegative()
}), Se = e.object({
	candidates: e.array(e.string()).optional(),
	playable: e.record(e.string(), e.object({
		needTarget: e.boolean(),
		targets: e.array(se)
	})).optional(),
	skills: e.array(e.object({
		id: e.string(),
		minCards: e.int().nonnegative(),
		maxCards: e.int().nonnegative(),
		minTargets: e.int().nonnegative(),
		maxTargets: e.int().nonnegative(),
		targets: e.array(se),
		suits: e.array(fe).optional(),
		names: e.array(e.string()).optional(),
		sameSuit: e.boolean().optional(),
		allowEquip: e.boolean().optional(),
		allowTian: e.boolean().optional(),
		classes: e.array(e.enum([
			"basic",
			"trick",
			"equip"
		])).optional()
	})).optional(),
	canPass: e.boolean().optional(),
	serpentSlash: e.object({ targets: e.array(se) }).optional(),
	respondable: e.array(e.object({
		cardId: ce,
		as: e.string().optional()
	})).optional(),
	choosableCards: e.array(ce).optional(),
	choosableSeats: e.array(se).optional(),
	choosableOptions: e.array(e.string()).optional(),
	knownCards: e.array(e.object({
		id: ce,
		name: e.string().nullable(),
		suit: fe.nullable(),
		point: e.int().min(1).max(13).nullable()
	})).optional()
}), Ce = e.object({
	identity: pe,
	hand: e.array(E),
	act: Se
}), we = "spade", Te = "heart", Ee = "club", De = "diamond";
function D(e, t, n) {
	return n.map((n) => ({
		name: e,
		suit: t,
		point: n
	}));
}
var Oe = [
	...D("slash", we, [
		7,
		8,
		8,
		9,
		9,
		10,
		10
	]),
	...D("slash", Ee, [
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		8,
		9,
		9,
		10,
		10,
		11,
		11
	]),
	...D("slash", Te, [
		10,
		10,
		11
	]),
	...D("slash", De, [
		6,
		7,
		8,
		9,
		10,
		13
	]),
	...D("jink", Te, [
		2,
		2,
		13
	]),
	...D("jink", De, [
		2,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11,
		11
	]),
	...D("peach", Te, [
		3,
		4,
		6,
		7,
		8,
		9,
		12
	]),
	...D("peach", De, [12]),
	{
		name: "crossbow",
		suit: Ee,
		point: 1
	},
	{
		name: "crossbow",
		suit: De,
		point: 1
	},
	{
		name: "double_sword",
		suit: we,
		point: 2
	},
	{
		name: "qinggang_sword",
		suit: we,
		point: 6
	},
	{
		name: "blade",
		suit: we,
		point: 5
	},
	{
		name: "spear",
		suit: we,
		point: 12
	},
	{
		name: "axe",
		suit: De,
		point: 5
	},
	{
		name: "halberd",
		suit: De,
		point: 12
	},
	{
		name: "kylin_bow",
		suit: Te,
		point: 5
	},
	{
		name: "eight_diagram",
		suit: we,
		point: 2
	},
	{
		name: "eight_diagram",
		suit: Ee,
		point: 2
	},
	{
		name: "jueying",
		suit: we,
		point: 5
	},
	{
		name: "dilu",
		suit: Ee,
		point: 5
	},
	{
		name: "zhuahuangfeidian",
		suit: Te,
		point: 13
	},
	{
		name: "chitu",
		suit: Te,
		point: 5
	},
	{
		name: "dayuan",
		suit: we,
		point: 13
	},
	{
		name: "zixing",
		suit: De,
		point: 13
	},
	...D("amazing_grace", Te, [3, 4]),
	{
		name: "god_salvation",
		suit: Te,
		point: 1
	},
	...D("savage_assault", we, [7, 13]),
	{
		name: "savage_assault",
		suit: Ee,
		point: 7
	},
	{
		name: "archery_attack",
		suit: Te,
		point: 1
	},
	...D("duel", we, [1]),
	...D("duel", Ee, [1]),
	...D("duel", De, [1]),
	...D("ex_nihilo", Te, [
		7,
		8,
		9,
		11
	]),
	...D("snatch", we, [
		3,
		4,
		11
	]),
	...D("snatch", De, [3, 4]),
	...D("dismantlement", we, [
		3,
		4,
		12
	]),
	...D("dismantlement", Ee, [3, 4]),
	{
		name: "dismantlement",
		suit: Te,
		point: 12
	},
	...D("collateral", Ee, [12, 13]),
	...D("nullification", we, [11]),
	...D("nullification", Ee, [12, 13]),
	...D("indulgence", we, [6]),
	...D("indulgence", Ee, [6]),
	...D("indulgence", Te, [6]),
	{
		name: "lightning",
		suit: we,
		point: 1
	},
	{
		name: "ice_sword",
		suit: we,
		point: 2
	},
	{
		name: "renwang_shield",
		suit: Ee,
		point: 2
	},
	{
		name: "lightning",
		suit: Te,
		point: 12
	},
	{
		name: "nullification",
		suit: De,
		point: 12
	}
], ke = [
	{
		name: "guding_blade",
		suit: we,
		point: 1
	},
	{
		name: "vine",
		suit: we,
		point: 2
	},
	{
		name: "analeptic",
		suit: we,
		point: 3
	},
	...D("thunder_slash", we, [
		4,
		5,
		6,
		7,
		8
	]),
	{
		name: "analeptic",
		suit: we,
		point: 9
	},
	{
		name: "supply_shortage",
		suit: we,
		point: 10
	},
	...D("iron_chain", we, [11, 12]),
	{
		name: "nullification",
		suit: we,
		point: 13
	},
	{
		name: "silver_lion",
		suit: Ee,
		point: 1
	},
	{
		name: "vine",
		suit: Ee,
		point: 2
	},
	{
		name: "analeptic",
		suit: Ee,
		point: 3
	},
	{
		name: "supply_shortage",
		suit: Ee,
		point: 4
	},
	...D("thunder_slash", Ee, [
		5,
		6,
		7,
		8
	]),
	{
		name: "analeptic",
		suit: Ee,
		point: 9
	},
	...D("iron_chain", Ee, [
		10,
		11,
		12,
		13
	]),
	{
		name: "nullification",
		suit: Te,
		point: 1
	},
	...D("fire_attack", Te, [2, 3]),
	{
		name: "fire_slash",
		suit: Te,
		point: 4
	},
	...D("peach", Te, [5, 6]),
	{
		name: "fire_slash",
		suit: Te,
		point: 7
	},
	...D("jink", Te, [8, 9]),
	{
		name: "fire_slash",
		suit: Te,
		point: 10
	},
	...D("jink", Te, [11, 12]),
	{
		name: "nullification",
		suit: Te,
		point: 13
	},
	{
		name: "fan",
		suit: De,
		point: 1
	},
	...D("peach", De, [2, 3]),
	...D("fire_slash", De, [4, 5]),
	...D("jink", De, [
		6,
		7,
		8
	]),
	{
		name: "analeptic",
		suit: De,
		point: 9
	},
	...D("jink", De, [10, 11]),
	{
		name: "fire_attack",
		suit: De,
		point: 12
	},
	{
		name: "hualiu",
		suit: De,
		point: 13
	}
], Ae = {
	crossbow: 1,
	double_sword: 2,
	qinggang_sword: 2,
	blade: 3,
	spear: 3,
	axe: 3,
	halberd: 4,
	kylin_bow: 5,
	ice_sword: 2,
	guding_blade: 2,
	fan: 4
}, je = {
	slash: "basic",
	fire_slash: "basic",
	thunder_slash: "basic",
	jink: "basic",
	peach: "basic",
	analeptic: "basic",
	duel: "trick",
	savage_assault: "trick",
	archery_attack: "trick",
	amazing_grace: "trick",
	god_salvation: "trick",
	ex_nihilo: "trick",
	snatch: "trick",
	dismantlement: "trick",
	collateral: "trick",
	nullification: "trick",
	fire_attack: "trick",
	iron_chain: "trick",
	indulgence: "trick",
	lightning: "trick",
	supply_shortage: "trick",
	crossbow: "equip",
	double_sword: "equip",
	qinggang_sword: "equip",
	blade: "equip",
	spear: "equip",
	axe: "equip",
	halberd: "equip",
	kylin_bow: "equip",
	ice_sword: "equip",
	guding_blade: "equip",
	fan: "equip",
	eight_diagram: "equip",
	renwang_shield: "equip",
	vine: "equip",
	silver_lion: "equip",
	jueying: "equip",
	dilu: "equip",
	zhuahuangfeidian: "equip",
	chitu: "equip",
	dayuan: "equip",
	zixing: "equip",
	hualiu: "equip"
}, Me = /* @__PURE__ */ new Set([
	"indulgence",
	"lightning",
	"supply_shortage"
]);
function O(e) {
	return je[e];
}
function k(e) {
	return e in Ae ? "weapon" : e === "eight_diagram" || e === "renwang_shield" || e === "vine" || e === "silver_lion" ? "armor" : e === "chitu" || e === "dayuan" || e === "zixing" ? "off_horse" : e === "jueying" || e === "dilu" || e === "zhuahuangfeidian" || e === "hualiu" ? "def_horse" : null;
}
function A(e) {
	return e === "slash" || e === "fire_slash" || e === "thunder_slash";
}
//#endregion
//#region src/games/sanguosha/generals.ts
function j(e, t, n, r, i) {
	return {
		id: e,
		faction: t,
		hp: n,
		skills: r,
		female: i?.female,
		lordSkill: i?.lordSkill
	};
}
function Ne(e, t) {
	return t.map((t) => ({
		...t,
		pack: e
	}));
}
var M = {
	re_caocao: j("re_caocao", "wei", 4, ["re_jianxiong", "hujia"], { lordSkill: "hujia" }),
	re_simayi: j("re_simayi", "wei", 3, ["fankui", "re_guicai"]),
	re_xiahoudun: j("re_xiahoudun", "wei", 4, ["re_ganglie", "qingjian"]),
	re_zhangliao: j("re_zhangliao", "wei", 4, ["re_tuxi"]),
	re_xuchu: j("re_xuchu", "wei", 4, ["re_luoyi"]),
	re_guojia: j("re_guojia", "wei", 3, ["tiandu", "yiji"]),
	re_zhenji: j("re_zhenji", "wei", 3, ["re_luoshen", "qingguo"], { female: !0 }),
	re_liubei: j("re_liubei", "shu", 4, ["re_rende", "jijiang"], { lordSkill: "jijiang" }),
	re_guanyu: j("re_guanyu", "shu", 4, ["re_wusheng", "re_yijue"]),
	re_zhangfei: j("re_zhangfei", "shu", 4, ["re_paoxiao", "re_tishen"]),
	re_zhugeliang: j("re_zhugeliang", "shu", 3, ["re_guanxing", "kongcheng"]),
	re_zhaoyun: j("re_zhaoyun", "shu", 4, ["re_longdan", "re_yajiao"]),
	re_machao: j("re_machao", "shu", 4, ["mashu", "re_tieji"]),
	re_huangyueying: j("re_huangyueying", "shu", 3, ["jizhi", "re_qicai"], { female: !0 }),
	re_sunquan: j("re_sunquan", "wu", 4, ["re_zhiheng", "re_jiuyuan"], { lordSkill: "re_jiuyuan" }),
	re_ganning: j("re_ganning", "wu", 4, ["re_qixi", "fenwei"]),
	re_lvmeng: j("re_lvmeng", "wu", 4, [
		"keji",
		"re_qinxue",
		"botu"
	]),
	re_huanggai: j("re_huanggai", "wu", 4, ["kurou", "zhaxiang"]),
	re_zhouyu: j("re_zhouyu", "wu", 3, ["yingzi", "fanjian"]),
	re_daqiao: j("re_daqiao", "wu", 3, ["guose", "liuli"], { female: !0 }),
	re_luxun: j("re_luxun", "wu", 3, ["qianxun", "lianying"]),
	re_sunshangxiang: j("re_sunshangxiang", "wu", 3, ["re_jieyin", "xiaoji"], { female: !0 }),
	re_huatuo: j("re_huatuo", "qun", 3, ["qingnang", "re_jijiu"]),
	re_lvbu: j("re_lvbu", "qun", 5, ["wushuang", "re_liyu"]),
	re_diaochan: j("re_diaochan", "qun", 3, ["re_lijian", "re_biyue"], { female: !0 }),
	re_xiahouyuan: j("re_xiahouyuan", "wei", 4, ["re_shensu", "shebian"]),
	re_caoren: j("re_caoren", "wei", 4, ["re_jushou", "re_jiewei"]),
	re_huangzhong: j("re_huangzhong", "shu", 4, ["re_liegong", "moshi"]),
	re_weiyan: j("re_weiyan", "shu", 4, ["re_kuanggu", "qimou"]),
	re_xiaoqiao: j("re_xiaoqiao", "wu", 3, [
		"re_tianxiang",
		"re_hongyan",
		"piaoling"
	], { female: !0 }),
	re_zhoutai: j("re_zhoutai", "wu", 4, ["buqu", "fenji"]),
	re_zhangjiao: j("re_zhangjiao", "qun", 3, [
		"re_leiji",
		"re_guidao",
		"re_huangtian"
	], { lordSkill: "re_huangtian" }),
	re_dianwei: j("re_dianwei", "wei", 4, ["re_qiangxi", "ninge"]),
	re_xunyu: j("re_xunyu", "wei", 3, ["quhu", "re_jieming"]),
	re_pangtong: j("re_pangtong", "shu", 3, ["re_lianhuan", "re_niepan"]),
	re_wolong: j("re_wolong", "shu", 3, [
		"re_huoji",
		"re_kanpo",
		"bazhen",
		"cangzhuo"
	]),
	re_taishici: j("re_taishici", "wu", 4, ["tianyi", "hanzhan"]),
	re_yuanshao: j("re_yuanshao", "qun", 4, ["re_luanji", "re_xueyi"], { lordSkill: "re_xueyi" }),
	re_yanliangwenchou: j("re_yanliangwenchou", "qun", 4, ["re_shuangxiong"]),
	re_pangde: j("re_pangde", "qun", 4, ["mashu", "jianchu"]),
	re_xuhuang: j("re_xuhuang", "wei", 4, ["re_duanliang", "jiezi"]),
	re_caopi: j("re_caopi", "wei", 3, [
		"re_xingshang",
		"re_fangzhu",
		"songwei"
	], { lordSkill: "songwei" }),
	re_menghuo: j("re_menghuo", "shu", 4, ["huoshou", "re_zaiqi"]),
	re_zhurong: j("re_zhurong", "shu", 4, [
		"juxiang",
		"lieren",
		"changbiao"
	], { female: !0 }),
	re_sunjian: j("re_sunjian", "wu", 4, ["yinghun", "wulie"]),
	re_lusu: j("re_lusu", "wu", 3, ["haoshi", "dimeng"]),
	re_dongzhuo: j("re_dongzhuo", "qun", 8, [
		"re_jiuchi",
		"roulin",
		"benghuai",
		"re_baonue"
	], { lordSkill: "re_baonue" }),
	re_jiaxu: j("re_jiaxu", "qun", 3, [
		"re_wansha",
		"re_luanwu",
		"re_weimu"
	]),
	re_zhanghe: j("re_zhanghe", "wei", 4, ["re_qiaobian"]),
	re_dengai: j("re_dengai", "wei", 4, ["re_tuntian", "re_zaoxian"]),
	re_jiangwei: j("re_jiangwei", "shu", 4, ["re_tiaoxin", "re_zhiji"]),
	re_liushan: j("re_liushan", "shu", 3, [
		"xiangle",
		"re_fangquan",
		"re_ruoyu"
	], { lordSkill: "re_ruoyu" }),
	re_sunce: j("re_sunce", "wu", 4, [
		"re_jiang",
		"re_hunzi",
		"re_zhiba"
	], { lordSkill: "re_zhiba" }),
	re_erzhang: j("re_erzhang", "wu", 3, ["re_zhijian", "re_guzheng"]),
	re_caiwenji: j("re_caiwenji", "qun", 3, ["re_beige", "duanchang"], { female: !0 })
}, Pe = [
	...Ne("standard", [
		j("caocao", "wei", 4, ["jianxiong", "hujia"], { lordSkill: "hujia" }),
		j("simayi", "wei", 3, ["fankui", "guicai"]),
		j("xiahoudun", "wei", 4, ["ganglie"]),
		j("zhangliao", "wei", 4, ["tuxi"]),
		j("xuchu", "wei", 4, ["luoyi"]),
		j("guojia", "wei", 3, ["tiandu", "yiji"]),
		j("zhenji", "wei", 3, ["luoshen", "qingguo"], { female: !0 }),
		j("liubei", "shu", 4, ["rende", "jijiang"], { lordSkill: "jijiang" }),
		j("guanyu", "shu", 4, ["wusheng", "yijue"]),
		j("zhangfei", "shu", 4, ["paoxiao", "tishen"]),
		j("zhugeliang", "shu", 3, ["guanxing", "kongcheng"]),
		j("zhaoyun", "shu", 4, ["longdan", "yajiao"]),
		j("machao", "shu", 4, ["mashu", "tieji"]),
		j("huangyueying", "shu", 3, ["jizhi", "qicai"], { female: !0 }),
		j("sunquan", "wu", 4, ["zhiheng", "jiuyuan"], { lordSkill: "jiuyuan" }),
		j("ganning", "wu", 4, ["qixi", "fenwei"]),
		j("lvmeng", "wu", 4, ["keji", "qinxue"]),
		j("huanggai", "wu", 4, ["kurou", "zhaxiang"]),
		j("zhouyu", "wu", 3, ["yingzi", "fanjian"]),
		j("daqiao", "wu", 3, ["guose", "liuli"], { female: !0 }),
		j("luxun", "wu", 3, ["qianxun", "lianying"]),
		j("sunshangxiang", "wu", 3, ["jieyin", "xiaoji"], { female: !0 }),
		j("huatuo", "qun", 3, ["chuli", "jijiu"]),
		j("lvbu", "qun", 5, ["wushuang", "liyu"]),
		j("diaochan", "qun", 3, ["lijian", "biyue"], { female: !0 })
	]),
	...Ne("wind", [
		j("xiahouyuan", "wei", 4, ["shensu"]),
		j("caoren", "wei", 4, ["jushou", "jiewei"]),
		j("huangzhong", "shu", 4, ["liegong"]),
		j("weiyan", "shu", 4, ["kuanggu"]),
		j("xiaoqiao", "wu", 3, ["tianxiang", "hongyan"], { female: !0 }),
		j("zhoutai", "wu", 4, ["buqu", "fenji"]),
		j("zhangjiao", "qun", 3, [
			"leiji",
			"guidao",
			"huangtian"
		], { lordSkill: "huangtian" }),
		j("yuji", "qun", 3, ["guhuo"])
	]),
	...Ne("fire", [
		j("dianwei", "wei", 4, ["qiangxi"]),
		j("xunyu", "wei", 3, ["quhu", "jieming"]),
		j("pangtong", "shu", 3, ["lianhuan", "niepan"]),
		j("wolong", "shu", 3, [
			"huoji",
			"kanpo",
			"bazhen"
		]),
		j("taishici", "wu", 4, ["tianyi"]),
		j("yuanshao", "qun", 4, ["luanji", "xueyi"], { lordSkill: "xueyi" }),
		j("yanliangwenchou", "qun", 4, ["shuangxiong"]),
		j("pangde", "qun", 4, ["mashu", "mengjin"])
	]),
	...Ne("forest", [
		j("xuhuang", "wei", 4, ["duanliang"]),
		j("caopi", "wei", 3, [
			"xingshang",
			"fangzhu",
			"songwei"
		], { lordSkill: "songwei" }),
		j("menghuo", "shu", 4, ["huoshou", "zaiqi"]),
		j("zhurong", "shu", 4, ["juxiang", "lieren"], { female: !0 }),
		j("sunjian", "wu", 4, ["yinghun"]),
		j("lusu", "wu", 3, ["haoshi", "dimeng"]),
		j("dongzhuo", "qun", 8, [
			"jiuchi",
			"roulin",
			"benghuai",
			"baonue"
		], { lordSkill: "baonue" }),
		j("jiaxu", "qun", 3, [
			"wansha",
			"luanwu",
			"weimu"
		])
	]),
	...Ne("mountain", [
		j("zhanghe", "wei", 4, ["qiaobian"]),
		j("dengai", "wei", 4, ["tuntian", "zaoxian"]),
		j("jiangwei", "shu", 4, ["tiaoxin", "zhiji"]),
		j("liushan", "shu", 3, [
			"xiangle",
			"fangquan",
			"ruoyu"
		], { lordSkill: "ruoyu" }),
		j("sunce", "wu", 4, [
			"jiang",
			"hunzi",
			"zhiba"
		], { lordSkill: "zhiba" }),
		j("erzhang", "wu", 3, ["zhijian", "guzheng"]),
		j("zuoci", "qun", 3, ["huashen", "xinsheng"]),
		j("caiwenji", "qun", 3, ["beige", "duanchang"], { female: !0 })
	]),
	...Ne("standard", [
		M.re_caocao,
		M.re_simayi,
		M.re_xiahoudun,
		M.re_zhangliao,
		M.re_xuchu,
		M.re_guojia,
		M.re_zhenji,
		M.re_liubei,
		M.re_guanyu,
		M.re_zhangfei,
		M.re_zhugeliang,
		M.re_zhaoyun,
		M.re_machao,
		M.re_huangyueying,
		M.re_sunquan,
		M.re_ganning,
		M.re_lvmeng,
		M.re_huanggai,
		M.re_zhouyu,
		M.re_daqiao,
		M.re_luxun,
		M.re_sunshangxiang,
		M.re_huatuo,
		M.re_lvbu,
		M.re_diaochan
	]),
	...Ne("wind", [
		M.re_xiahouyuan,
		M.re_caoren,
		M.re_huangzhong,
		M.re_weiyan,
		M.re_xiaoqiao,
		M.re_zhoutai,
		M.re_zhangjiao
	]),
	...Ne("fire", [
		M.re_dianwei,
		M.re_xunyu,
		M.re_pangtong,
		M.re_wolong,
		M.re_taishici,
		M.re_yuanshao,
		M.re_yanliangwenchou,
		M.re_pangde
	]),
	...Ne("forest", [
		M.re_xuhuang,
		M.re_caopi,
		M.re_menghuo,
		M.re_zhurong,
		M.re_sunjian,
		M.re_lusu,
		M.re_dongzhuo,
		M.re_jiaxu
	]),
	...Ne("mountain", [
		M.re_zhanghe,
		M.re_dengai,
		M.re_jiangwei,
		M.re_liushan,
		M.re_sunce,
		M.re_erzhang,
		M.re_caiwenji
	]),
	...Ne("yj2011", [
		j("caozhi", "wei", 3, ["luoying", "jiushi"]),
		j("yujin", "wei", 4, ["rezhenjun"]),
		j("zhangchunhua", "wei", 3, ["jueqing", "shangshi"], { female: !0 }),
		j("xin_fazheng", "shu", 3, ["xinxuanhuo", "xinenyuan"]),
		j("xin_masu", "shu", 3, ["olsanyao", "rezhiman"]),
		j("xin_xushu", "shu", 3, ["xinwuyan", "xinjujian"]),
		j("xusheng", "wu", 4, ["xinpojun"]),
		j("lingtong", "wu", 4, ["xuanfeng"]),
		j("wuguotai", "wu", 3, ["ganlu", "buyi"], { female: !0 }),
		j("chengong", "qun", 3, ["mingce", "zhichi"]),
		j("gaoshun", "qun", 4, ["xinxianzhen", "jinjiu"])
	]),
	...Ne("yj2012", [
		j("wangyi", "wei", 3, ["zhenlie", "miji"], { female: !0 }),
		j("xunyou", "wei", 3, ["qice", "zhiyu"]),
		j("zhonghui", "wei", 4, ["quanji", "zili"]),
		j("old_madai", "shu", 4, ["mashu", "qianxi"]),
		j("liaohua", "shu", 4, ["dangxian", "fuli"]),
		j("guanzhang", "shu", 4, ["fuhun"]),
		j("bulianshi", "wu", 3, ["old_anxu", "zhuiyi"], { female: !0 }),
		j("handang", "wu", 4, ["gongji", "jiefan"]),
		j("chengpu", "wu", 4, ["lihuo", "chunlao"]),
		j("liubiao", "qun", 3, ["rezishou", "zongshi"]),
		j("caozhang", "wei", 4, ["new_jiangchi"])
	]),
	...Ne("yj2013", [
		j("manchong", "wei", 3, ["junxing", "yuce"]),
		j("guohuai", "wei", 3, ["rejingce"]),
		j("caochong", "wei", 3, ["chengxiang", "renxin"]),
		j("guanping", "shu", 4, ["longyin"]),
		j("liufeng", "shu", 4, ["xiansi"]),
		j("jianyong", "shu", 3, ["qiaoshui", "jyzongshi"]),
		j("yufan", "wu", 3, ["zhiyan", "zongxuan"]),
		j("panzhangmazhong", "wu", 4, ["duodao", "anjian"]),
		j("zhuran", "wu", 4, ["danshou"]),
		j("xin_liru", "qun", 3, [
			"xinjuece",
			"xinmieji",
			"xinfencheng"
		]),
		j("fuhuanghou", "qun", 3, ["qiuyuan", "zhuikong"], { female: !0 })
	]),
	...Ne("yj2014", [
		j("hanhaoshihuan", "wei", 3, ["shenduan", "yonglve"]),
		j("chenqun", "wei", 3, ["pindi", "faen"]),
		j("caozhen", "wei", 4, ["xinsidi"]),
		j("zhangsong", "shu", 3, ["qiangzhi", "xiantu"]),
		j("wuyi", "shu", 4, ["olbenxi"]),
		j("zhoucang", "shu", 4, ["xinzhongyong"]),
		j("zhuhuan", "wu", 4, ["fenli", "pingkou"]),
		j("guyong", "wu", 3, ["shenxing", "olbingyi"]),
		j("sunluban", "wu", 3, ["chanhui", "jiaojin"], { female: !0 }),
		j("yj_jushou", "qun", 3, ["jianying", "shibei"]),
		j("caifuren", "qun", 3, ["qieting", "xianzhou"], { female: !0 })
	]),
	...Ne("yj2015", [
		j("caoxiu", "wei", 4, ["qianju", "qingxi"]),
		j("caorui", "wei", 3, [
			"huituo",
			"mingjian",
			"xingshuai"
		], { lordSkill: "xingshuai" }),
		j("zhongyao", "wei", 3, ["huomo", "zuoding"]),
		j("xiahoushi", "shu", 3, ["qiaoshi", "yanyu"], { female: !0 }),
		j("liuchen", "shu", 4, ["zhanjue", "qinwang"], { lordSkill: "qinwang" }),
		j("zhangyi", "shu", 4, ["wurong", "shizhi"]),
		j("zhuzhi", "wu", 4, ["xinanguo"]),
		j("quancong", "wu", 4, ["yaoming"]),
		j("sunxiu", "wu", 3, [
			"yanzhu",
			"xingxue",
			"xinzhaofu"
		], { lordSkill: "xinzhaofu" }),
		j("gongsunyuan", "qun", 4, ["huaiyi"]),
		j("guotufengji", "qun", 3, ["jigong", "shifei"])
	]),
	...Ne("yj2016", [
		j("guohuanghou", "wei", 3, ["jiaozhao", "danxin"], { female: !0 }),
		j("sunziliufang", "wei", 3, ["guizao", "jiyu"]),
		j("huanghao", "shu", 3, ["qinqing", "huisheng"]),
		j("liyan", "shu", 3, ["dcduliang", "fulin"]),
		j("sundeng", "wu", 4, ["kuangbi"]),
		j("cenhun", "wu", 4, ["jishe", "lianhuo"]),
		j("zhangrang", "qun", 3, ["taoluan"]),
		j("liuyu", "qun", 2, ["zhige", "zongzuo"])
	]),
	...Ne("yj2017", [
		j("xinxianying", "wei", 3, ["zhongjian", "caishi"], { female: !0 }),
		j("jikang", "wei", 3, ["qingxian", "juexiang"]),
		j("wuxian", "shu", 3, ["fumian", "daiyan"], { female: !0 }),
		j("qinmi", "shu", 3, [
			"jianzheng",
			"zhuandui",
			"tianbian"
		]),
		j("xuezong", "wu", 3, ["funan", "xinjiexun"]),
		j("xushi", "wu", 3, ["wengua", "fuzhu"], { female: !0 }),
		j("caojie", "qun", 3, ["shouxi", "huimin"], { female: !0 }),
		j("caiyong", "qun", 3, ["bizhuan", "tongbo"])
	])
], Fe = new Map(Pe.map((e) => [e.id, e]));
//#endregion
//#region src/games/sanguosha/rules/slash.ts
function N(e, t) {
	return Y(e, t, "kongcheng") && e.hands[t].length === 0;
}
function Ie(e, t, n, r, i) {
	let a = n.ana ?? 0, o = n.cardId ?? null, s = n.ylFrom;
	s != null && e.seats[s].alive && (H(e, s, 1), L(e, {
		kind: "yonglve-draw",
		seat: s
	}));
	let c = n.from;
	c != null && e.seats[c]?.alive && Y(e, c, "re_paoxiao") && (e.seats[c].marks.pao = (e.seats[c].marks.pao ?? 0) + 1, L(e, {
		kind: "skill",
		seat: c,
		card: "paoxiao"
	}));
	let l = n.from;
	return n.aoe == null && e.seats[l]?.alive && Y(e, l, "xinzhongyong") && e.queue.unshift({
		k: "zy-check",
		from: l,
		target: t,
		cardId: o,
		jinkId: i
	}), wv(e, n.from, t, n.cardName), Tv(e, n.from, t, n.cardName, a, o, n.plus ?? 0), Sv(e, t, r);
}
function Le(e, t, n, r, i, a, o, s, c) {
	let l = s ? { lihuo: !0 } : {}, u = {
		k: "slash-target",
		from: t,
		target: a,
		cardName: n,
		suit: r,
		cardId: i,
		ana: o,
		...l
	}, d = +!!e.seats[t].flags.tianyiWin;
	e.seats[t].flags.qsAdd && (d += 1, delete e.seats[t].flags.qsAdd);
	let f = e.seats[t].equips.weapon;
	if (f != null && e.cards[f].name === "halberd" && e.hands[t].length === 0 && (d += 2), n === "fire_slash" && Y(e, t, "lihuo") && (d += 1), !e.seats[t].flags.fmRedUsed && G(e, i)) {
		let n = e.seats[t].flags.fmRedN ?? 0;
		n > 0 && (d += n, e.seats[t].flags.fmRedUsed = !0);
	}
	let p = e.seats[t].flags.xianzhen, m = p != null && p !== a && e.seats[p].alive && !N(e, p), h = d > 0 ? z(e).filter((n) => n !== t && n !== a && !N(e, n)) : [];
	if (!m && h.length === 0) {
		if (!e.seats[t].flags.chDone && Y(e, t, "chanhui")) {
			let n = z(e).filter((n) => n !== t && n !== a && V(e, t, n) <= Bv(e, t) && !N(e, n));
			if (n.length > 0) return e.seats[t].flags.chDone = !0, e.pending = {
				kind: "skill-ask",
				seats: [t],
				ctx: {
					skill: "chanhui",
					data: {
						candidates: n,
						target: a,
						resume: u
					}
				}
			}, F(e, t, 1), {
				state: e,
				fx: c
			};
		}
		if (Y(e, t, "olbenxi") && z(e).every((n) => n === t || V(e, t, n) <= 1)) return e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "olbenxi",
				options: [
					"bx-both",
					"bx-pierce",
					"bx-nullify"
				],
				noPass: !0,
				data: { resume: u }
			}
		}, F(e, t, 1), {
			state: e,
			fx: c
		};
	}
	return h.length > 0 ? (e.queue.unshift(u), e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "tianyi-extra",
			min: 0,
			max: d,
			data: {
				candidates: h,
				cardName: n,
				suit: r,
				cardId: i,
				ana: o,
				...l
			}
		}
	}, F(e, t, 1), {
		state: e,
		fx: c
	}) : m && h.length === 0 ? (e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "xianzhen-add",
			data: {
				from: t,
				target: a,
				xz: p,
				cardName: n,
				suit: r,
				cardId: i,
				ana: o,
				...l
			}
		}
	}, F(e, t, 1), {
		state: e,
		fx: c
	}) : (e.queue.unshift(u), F(e, t, 1), Z(e, c), {
		state: e,
		fx: c
	});
}
function Re(e, t, n, r) {
	let i = Zv(e, n, r);
	i != null && L(e, {
		kind: "shifei-discard",
		seat: t,
		target: n,
		cards: R(e, [i])
	});
}
function ze(e, t, n) {
	let r = e.seats[t].flags;
	return !!(r.sidiRed && G(e, n) || r.sidiBlack && qv(e, n));
}
function Be(e, t) {
	let n = Bv(e, t.target);
	return z(e).filter((r) => r !== t.target && r !== t.from && V(e, t.target, r) <= n && !N(e, r));
}
function Ve(e, t, n) {
	if (!e.seats[t.target].alive || !e.seats[t.from].alive) return;
	let r = Y(e, t.from, "wushuang") ? 2 : 1;
	r === 1 && (Y(e, t.from, "roulin") && Xv(e, t.target) || Y(e, t.target, "roulin") && Xv(e, t.from)) && (r = 2);
	let i = Y(e, t.from, "zhaxiang") && !!e.seats[t.from].flags.zhaxiangRed && (t.suit === "heart" || t.suit === "diamond");
	e.pending = {
		kind: "jink",
		seats: [t.target],
		ctx: {
			from: t.from,
			cardName: t.cardName,
			suit: t.suit,
			cardId: t.cardId,
			need: r,
			count: 0,
			noJink: n || i || !!t.noJink,
			ana: t.ana ?? 0,
			plus: t.plus ?? 0,
			...t.lihuo ? { lihuo: !0 } : {},
			...t.fuhun ? { fuhun: !0 } : {},
			...t.ylFrom == null ? {} : { ylFrom: t.ylFrom },
			...t.bxPierce ? { bxPierce: !0 } : {}
		}
	};
}
function He(e, t, n) {
	if (Y(e, t.target, "liuli") && e.hands[t.target].length > 0 && Be(e, t).length > 0) {
		e.pending = {
			kind: "skill-ask",
			seats: [t.target],
			ctx: {
				skill: "liuli",
				data: { info: t }
			}
		};
		return;
	}
	Ue(e, t, n);
}
function Ue(e, t, n) {
	let r = e.seats[t.from].equips.weapon;
	if (r != null && e.cards[r].name === "double_sword" && e.seats[t.from].alive && e.seats[t.target].alive && Xv(e, t.from) !== Xv(e, t.target)) {
		if (e.hands[t.target].length === 0) {
			let r = H(e, t.from, 1);
			n.push({
				kind: "draw",
				rid: e.seats[t.from].rid,
				data: {
					seat: t.from,
					n: r.length
				},
				for: [e.seats[t.from].rid],
				secret: { cards: r }
			}), L(e, {
				kind: "skill-draw",
				seat: t.from,
				card: "double_sword",
				n: r.length
			}), e.beatMs = J.draw, P(e, t.from, r), We(e, t, n);
			return;
		}
		e.pending = {
			kind: "skill-ask",
			seats: [t.from],
			ctx: {
				skill: "double_sword",
				target: t.target,
				data: { info: t }
			}
		};
		return;
	}
	We(e, t, n);
}
function We(e, t, n) {
	qe(e, t, n) || Ge(e, t);
}
function Ge(e, t) {
	let n = Y(e, t.from, "re_tieji");
	if ((n || Y(e, t.from, "tieji")) && e.seats[t.target].alive) {
		e.pending = {
			kind: "skill-ask",
			seats: [t.from],
			ctx: {
				skill: n ? "re_tieji" : "tieji",
				data: { info: t }
			}
		};
		return;
	}
	Ke(e, t, !1);
}
function Ke(e, t, n) {
	if (!n && (Y(e, t.from, "liegong") || Y(e, t.from, "re_liegong")) && e.turn?.seat === t.from && e.turn.phase === "play" && e.seats[t.target].alive) {
		if (Y(e, t.from, "re_liegong")) e.hands[t.target].length <= e.hands[t.from].length && (t.noJink = !0), e.seats[t.target].hp >= e.seats[t.from].hp && (t.plus = (t.plus ?? 0) + 1), (t.noJink || t.plus) && (L(e, {
			kind: "skill",
			seat: t.from,
			card: "liegong"
		}), e.beatMs = J.play);
		else {
			let n = e.hands[t.target].length;
			if (n >= e.seats[t.from].hp || n <= Bv(e, t.from)) {
				e.pending = {
					kind: "skill-ask",
					seats: [t.from],
					ctx: {
						skill: "liegong",
						data: { info: t }
					}
				};
				return;
			}
		}
	}
	Ve(e, t, n);
}
function qe(e, t, n) {
	let r = e.seats[t.from].equips.weapon, i = r != null && e.cards[r].name === "qinggang_sword" || e.seats[t.from].flags.xianzhen === t.target || !!t.bxPierce, a = ty(e, t.target, i), o = t.suit === "spade" || t.suit === "club";
	return a === "renwang_shield" && o ? (L(e, {
		kind: "armor-null",
		seat: t.target,
		card: "renwang_shield"
	}), n.push({
		kind: "dodge",
		rid: e.seats[t.target].rid,
		data: {
			seat: t.target,
			by: "renwang_shield"
		}
	}), e.beatMs = J.respond, !0) : a === "vine" && t.cardName === "slash" && (L(e, {
		kind: "armor-null",
		seat: t.target,
		card: "vine"
	}), n.push({
		kind: "dodge",
		rid: e.seats[t.target].rid,
		data: {
			seat: t.target,
			by: "vine"
		}
	}), e.beatMs = J.respond, !0);
}
function Je(e, t) {
	if (!Y(e, t.target, "xiangle") || !e.seats[t.from].alive) return !1;
	let n = e.hands[t.from].filter((t) => O(e.cards[t].name) === "basic");
	return n.length === 0 ? (L(e, {
		kind: "xiangle-null",
		seat: t.target
	}), e.beatMs = J.respond, !0) : (e.pending = {
		kind: "skill-cards",
		seats: [t.from],
		ctx: {
			skill: "xiangle",
			min: 0,
			max: 1,
			data: {
				pool: n,
				info: t
			}
		}
	}, !0);
}
//#endregion
//#region src/games/sanguosha/rules/trick.ts
function Ye(e, t) {
	return e.hands[t].some((n) => e.cards[n].name === "nullification" || hy(e, t, n).includes("nullification")) || K(e, t).some((n) => hy(e, t, n).includes("nullification"));
}
function Xe(e, t, n) {
	return Y(e, t, "weimu") && qv(e, n);
}
function Ze(e, t) {
	let n = z(e).find((t) => Y(e, t, "huoshou"));
	return n != null && n !== t ? n : t;
}
function Qe(e, t, n, r, i) {
	e.pending = {
		kind: "nullification",
		seats: B(e, t).filter((t) => Ye(e, t)),
		ctx: {
			trick: n,
			chain: 0,
			from: t,
			target: r,
			resume: i
		}
	}, e.pending.seats.length === 0 && (e.pending = null, e.queue.unshift(i));
}
function $e(e, t, n) {
	let r = t.from, i = t.target;
	if (i != null && e.seats[i].alive && e.seats[i].flags.zhichi && !Me.has(t.name)) {
		L(e, {
			kind: "skill",
			seat: i,
			card: "zhichi"
		});
		return;
	}
	if (!t.zlDone && !Me.has(t.name) && i != null && e.seats[i].alive && Dy(e, i, r, {
		...t,
		zlDone: !0
	})) return;
	if (!t.bzDone && i != null && i !== r && e.seats[i].alive && Y(e, i, "bizhuan") && t.suit === "spade" && e.seats[i].shu.length < 4) {
		e.queue.unshift({
			...t,
			bzDone: !0
		}), e.pending = {
			kind: "skill-ask",
			seats: [i],
			ctx: {
				skill: "bizhuan",
				data: {}
			}
		};
		return;
	}
	let a = i ?? (t.name === "lightning" ? r : null);
	if (!t.qx && t.name !== "god_salvation" && a != null && e.seats[a].alive && Y(e, a, "qianxun") && e.hands[a].length > 0 && (t.name === "indulgence" || t.name === "lightning" || t.name === "supply_shortage" || r !== a)) {
		e.pending = {
			kind: "skill-ask",
			seats: [a],
			ctx: {
				skill: "qianxun",
				data: { ev: t }
			}
		};
		return;
	}
	switch (t.name) {
		case "ex_nihilo": {
			let t = H(e, r, 2);
			e.beatMs = J.draw, n.push({
				kind: "draw",
				rid: e.seats[r].rid,
				data: {
					seat: r,
					n: 2
				},
				for: [e.seats[r].rid],
				secret: { cards: t }
			}), L(e, {
				kind: "draw",
				seat: r,
				n: 2
			}), P(e, r, t);
			return;
		}
		case "snatch":
		case "dismantlement": {
			if (i == null || !e.seats[i].alive) return;
			let a = et(e, i, t.name);
			if (a.length === 0) return;
			if (a.length === 1) {
				tt(e, r, i, t.name, a[0], n);
				return;
			}
			e.pending = {
				kind: "pick-zone",
				seats: [r],
				ctx: {
					trick: t.name,
					from: r,
					target: i
				}
			};
			return;
		}
		case "duel": {
			if (i == null || !e.seats[i].alive) return;
			let a = Y(e, r, "wushuang") ? 2 : 1;
			e.pending = {
				kind: "slash-response",
				seats: [i],
				ctx: {
					from: r,
					duel: { other: r },
					need: a,
					count: 0,
					cardId: t.cardId,
					...t.zj == null ? {} : { zj: t.zj }
				}
			}, L(e, {
				kind: "duel",
				seat: r,
				target: i
			}), vv(e, i, n);
			return;
		}
		case "collateral":
			if (i == null || !e.seats[i].alive || e.seats[i].equips.weapon == null) return;
			e.pending = {
				kind: "collateral-target",
				seats: [r],
				ctx: {
					from: r,
					a: i
				}
			};
			return;
		case "indulgence":
		case "lightning":
		case "supply_shortage": {
			let a = i ?? r;
			if (!e.seats[a].alive || t.cardId == null) return;
			e.seats[a].judges.push(t.cardId), e.judgeNames[t.cardId] = t.name, e.beatMs = J.equip, n.push({
				kind: "place-judge",
				data: {
					seat: a,
					card: t.cardId,
					name: t.name
				}
			}), L(e, {
				kind: "place-judge",
				seat: a,
				from: r,
				card: t.name
			});
			return;
		}
		case "iron_chain":
			if (!e.seats[r].alive) return;
			e.pending = {
				kind: "skill-seats",
				seats: [r],
				ctx: {
					skill: "iron_chain",
					min: 1,
					max: 2,
					data: { candidates: z(e) }
				}
			};
			return;
		case "fire_attack":
			if (i == null || !e.seats[i].alive || !e.seats[r].alive || e.hands[i].length === 0) return;
			if (Y(e, r, "re_huoji")) {
				let a = e.hands[i][Nv(e, e.hands[i].length)];
				n.push({
					kind: "reveal",
					rid: e.seats[i].rid,
					data: {
						seat: i,
						card: a
					}
				}), L(e, {
					kind: "fire-show",
					seat: i,
					cards: R(e, [a])
				});
				let o = G(e, a), s = e.hands[r].filter((t) => G(e, t) === o);
				s.length > 0 && (e.pending = {
					kind: "skill-cards",
					seats: [r],
					ctx: {
						skill: "fire_attack-discard",
						min: 0,
						max: 1,
						data: {
							target: i,
							pool: s,
							cardId: t.cardId
						}
					}
				});
				return;
			}
			e.pending = {
				kind: "skill-cards",
				seats: [i],
				ctx: {
					skill: "fire_attack-show",
					min: 1,
					max: 1,
					data: {
						from: r,
						cardId: t.cardId
					}
				}
			};
			return;
		case "god_salvation":
			if (i == null || !e.seats[i].alive) return;
			e.seats[i].hp < e.seats[i].maxHp && (e.seats[i].hp += 1, X(e, i), n.push({
				kind: "recover",
				rid: e.seats[i].rid,
				data: {
					seat: i,
					n: 1
				}
			}), e.beatMs = J.recover, L(e, {
				kind: "god-salvation",
				seat: i
			}));
			return;
		default: return;
	}
}
function et(e, t, n, r = !0) {
	let i = e.seats[t], a = [];
	e.hands[t].length > 0 && a.push("hand");
	let o = n === "dismantlement" && (Y(e, t, "qicai") || Y(e, t, "re_qicai")), s = Y(e, t, "re_qicai") ? ["armor"] : ["weapon", "armor"];
	for (let e of [
		"weapon",
		"armor",
		"off_horse",
		"def_horse"
	]) i.equips[e] != null && !(o && s.includes(e)) && a.push(e);
	return r && i.judges.forEach((e, t) => a.push(`judge:${t}`)), a;
}
function tt(e, t, n, r, i, a) {
	let o = e.seats[n], s, c = !1;
	if (i === "hand") {
		if (e.hands[n].length === 0) return null;
		s = e.hands[n][Nv(e, e.hands[n].length)], W(e, n, s);
	} else if (i.startsWith("judge:")) {
		let t = Number(i.slice(6));
		s = o.judges[t] ?? null, s != null && (o.judges.splice(t, 1), delete e.judgeNames[s]);
	} else {
		let e = i;
		s = o.equips[e], o.equips[e] = null, c = s != null;
	}
	return s == null ? null : (r === "snatch" ? (e.hands[t].push(s), a.push({
		kind: "take",
		rid: e.seats[t].rid,
		data: {
			from: n,
			seat: t
		},
		for: [e.seats[t].rid],
		secret: { card: s }
	}), L(e, {
		kind: "snatch",
		seat: t,
		target: n,
		cards: i === "hand" ? void 0 : R(e, [s])
	})) : (U(e, [s]), a.push({
		kind: "discard",
		rid: o.rid,
		data: {
			seat: n,
			n: 1,
			cards: [s]
		}
	}), L(e, {
		kind: "dismantle",
		seat: t,
		target: n,
		cards: R(e, [s])
	}), pv(e, [s], a, n), dv(e, [s], n)), c && I(e, n, s, a), i === "hand" && Cv(e, n), i === "hand" && cv(e, n), e.beatMs = J.play, s);
}
//#endregion
//#region src/games/sanguosha/rules/judge.ts
function nt(e, t, n, r, i) {
	e.deck.length === 0 && e.discard.length > 0 && (e.deck = Pv(e, e.discard), e.discard = []);
	let a = e.deck.shift();
	if (a == null) return !1;
	let o = e.cards[a];
	i.push({
		kind: "judge",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: a,
			name: o.name,
			suit: o.suit,
			point: o.point,
			for: n
		}
	}), L(e, {
		kind: "judge-reveal",
		seat: t,
		card: n === "leiji-jie" ? "leiji" : n === "beige-jie" ? "beige" : n,
		cards: R(e, [a])
	}), e.beatMs = J.judge;
	let s = B(e, t).filter((t) => (Y(e, t, "guicai") || Y(e, t, "re_guicai")) && (e.hands[t].length > 0 || Y(e, t, "re_guicai") && K(e, t).length > 0) || (Y(e, t, "guidao") || Y(e, t, "re_guidao")) && e.hands[t].some((t) => qv(e, t)));
	return s.length > 0 ? (e.pending = {
		kind: "guicai",
		seats: s,
		ctx: {
			judgeCard: a,
			purpose: n,
			data: r,
			seat: t
		}
	}, !0) : (e.queue.unshift({
		k: "judge-effect",
		purpose: n,
		seat: t,
		judgeCard: a,
		data: r
	}), !1);
}
function rt(e, t, n) {
	Y(e, t, "tiandu") ? (e.hands[t].push(n), L(e, {
		kind: "tiandu",
		seat: t
	})) : (U(e, [n]), pv(e, [n], null, t));
}
function it(e, t, n) {
	let { purpose: r, seat: i, judgeCard: a, data: o } = t, s = e.cards[a];
	switch (r) {
		case "indulgence": {
			let t = fy(e, i, a) !== "heart";
			return (e.seats[i].marks.sishu ?? 0) > 0 && (t = !t), U(e, [o.trickCard]), rt(e, i, a), t && (e.skipPlay = !0), e.judging = {
				seat: i,
				name: "indulgence",
				result: t ? "hit" : "miss"
			}, L(e, {
				kind: "judge-result",
				seat: i,
				card: "indulgence",
				cards: R(e, [a]),
				n: +!!t
			}), !1;
		}
		case "supply_shortage": {
			let t = fy(e, i, a) !== "club";
			return U(e, [o.trickCard]), rt(e, i, a), t && (e.skipDraw = !0), e.judging = {
				seat: i,
				name: "supply_shortage",
				result: t ? "hit" : "miss"
			}, L(e, {
				kind: "judge-result",
				seat: i,
				card: "supply_shortage",
				cards: R(e, [a]),
				n: +!!t
			}), !1;
		}
		case "lightning": {
			let t = o.trickCard, r = fy(e, i, a) === "spade" && s.point >= 2 && s.point <= 9;
			if (e.judging = {
				seat: i,
				name: "lightning",
				result: r ? "hit" : "miss"
			}, L(e, {
				kind: "judge-result",
				seat: i,
				card: "lightning",
				cards: R(e, [a]),
				n: +!!r
			}), r) U(e, [t]), rt(e, i, a), e.queue.unshift({
				k: "damage",
				source: null,
				target: i,
				amount: 3,
				nature: "thunder",
				reason: "lightning",
				cardId: t
			});
			else {
				rt(e, i, a);
				let r = B(e, i).slice(1).find((t) => !e.seats[t].judges.some((t) => uy(e, t) === "lightning"));
				r == null ? U(e, [t]) : (e.seats[r].judges.push(t), n.push({
					kind: "move",
					data: {
						seat: r,
						name: "lightning"
					}
				}), L(e, {
					kind: "lightning-move",
					seat: r
				}));
			}
			return !1;
		}
		case "eight_diagram": {
			let t = o.jinkCtx;
			rt(e, i, a);
			let r = py(e, i, a);
			return L(e, {
				kind: "judge-result",
				seat: i,
				card: "eight_diagram",
				cards: R(e, [a]),
				n: +!!r
			}), r ? (n.push({
				kind: "dodge",
				rid: e.seats[i].rid,
				data: {
					seat: i,
					by: "eight_diagram"
				}
			}), L(e, {
				kind: "jink",
				seat: i
			}), t.count = (t.count ?? 0) + 1, t.count < (t.need ?? 1) ? (e.pending = {
				kind: "jink",
				seats: [i],
				ctx: t
			}, !0) : (wv(e, t.from, i, t.cardName), Tv(e, t.from, i, t.cardName, t.ana ?? 0, t.cardId ?? null), !!Sv(e, i, n))) : (e.pending = {
				kind: "jink",
				seats: [i],
				ctx: {
					...t,
					baguaUsed: !0
				}
			}, !0);
		}
		case "ganglie": {
			let t = o.source;
			return t == null || !e.seats[t].alive ? (rt(e, i, a), !1) : Y(e, i, "re_ganglie") ? (rt(e, i, a), L(e, {
				kind: "judge-result",
				seat: i,
				card: "ganglie",
				cards: R(e, [a])
			}), py(e, i, a) ? (e.queue.unshift({
				k: "damage",
				source: i,
				target: t,
				amount: 1,
				nature: "normal",
				reason: "ganglie",
				cardId: null
			}), !1) : et(e, t, "dismantlement").length !== 0 && (e.pending = {
				kind: "pick-zone",
				seats: [i],
				ctx: {
					trick: "dismantlement",
					from: i,
					target: t,
					via: "ganglie",
					allowJudge: !1,
					chain: o.chain
				}
			}, !0)) : (rt(e, i, a), L(e, {
				kind: "judge-result",
				seat: i,
				card: "ganglie",
				cards: R(e, [a]),
				n: fy(e, i, a) === "heart" ? 0 : 1
			}), fy(e, i, a) === "heart" ? !1 : e.hands[t].length < 2 ? (e.queue.unshift({
				k: "damage",
				source: i,
				target: t,
				amount: 1,
				nature: "normal",
				reason: "ganglie",
				cardId: null
			}), !1) : (e.pending = {
				kind: "skill-ask",
				seats: [t],
				ctx: {
					skill: "ganglie-choice",
					options: ["gl-discard", "gl-damage"],
					noPass: !0,
					data: {
						from: i,
						chain: o.chain
					}
				}
			}, !0));
		}
		case "huituo": {
			rt(e, i, a), L(e, {
				kind: "judge-result",
				seat: i,
				card: "huituo",
				cards: R(e, [a])
			});
			let t = o.x ?? 1;
			if (py(e, i, a)) e.seats[i].alive && e.seats[i].hp < e.seats[i].maxHp && (e.seats[i].hp += 1, n.push({
				kind: "recover",
				rid: e.seats[i].rid,
				data: {
					seat: i,
					n: 1
				}
			}), L(e, {
				kind: "recover",
				seat: i,
				n: 1
			}), e.beatMs = J.recover, X(e, i));
			else if (e.seats[i].alive) {
				let r = H(e, i, t);
				if (n.push({
					kind: "draw",
					rid: e.seats[i].rid,
					data: {
						seat: i,
						n: r.length
					},
					for: [e.seats[i].rid],
					secret: { cards: r }
				}), L(e, {
					kind: "skill-draw",
					seat: i,
					card: "huituo",
					n: r.length
				}), e.beatMs = J.draw, P(e, i, r), e.pending) return !0;
			}
			let r = o.liyu;
			return r && e.seats[r.target].alive && e.seats[r.source].alive && fx(e, r.target) ? (Ay(e, r), !0) : !1;
		}
		case "tieji": {
			rt(e, i, a), L(e, {
				kind: "judge-result",
				seat: i,
				card: "tieji",
				cards: R(e, [a])
			});
			let t = o.info, n = t.target;
			if (!e.seats[n].alive) return !1;
			let r = fy(e, i, a), s = [...e.hands[n], ...K(e, n)].filter((t) => dy(e, n, t) === r);
			return Y(e, t.from, "re_tieji") ? s.length > 0 ? (e.pending = {
				kind: "skill-cards",
				seats: [n],
				ctx: {
					skill: "tieji-give",
					min: 0,
					max: 1,
					data: {
						info: t,
						suit: r,
						pool: s,
						to: t.from
					}
				}
			}, !0) : (t.noJink = !0, t.plus = (t.plus ?? 0) + 1, Ke(e, t, !0), e.pending != null) : s.length > 0 ? (e.pending = {
				kind: "skill-cards",
				seats: [n],
				ctx: {
					skill: "tieji-discard",
					min: 0,
					max: 1,
					data: {
						info: t,
						suit: r,
						pool: s
					}
				}
			}, !0) : (Ke(e, t, !0), e.pending != null);
		}
		case "shuangxiong": {
			e.hands[i].push(a), n.push({
				kind: "draw",
				rid: e.seats[i].rid,
				data: {
					seat: i,
					n: 1
				},
				for: [e.seats[i].rid],
				secret: { cards: [a] }
			});
			let t = G(e, a);
			return e.seats[i].flags[t ? "shuangxiongRed" : "shuangxiongBlack"] = !0, L(e, {
				kind: t ? "shuangxiong-red" : "shuangxiong-black",
				seat: i,
				cards: R(e, [a])
			}), !1;
		}
		case "luoshen": return py(e, i, a) ? (rt(e, i, a), !1) : (e.hands[i].push(a), Y(e, i, "re_luoshen") && e.seats[i].luoshen.push(a), L(e, {
			kind: "luoshen",
			seat: i,
			cards: R(e, [a])
		}), n.push({
			kind: "draw",
			rid: e.seats[i].rid,
			data: {
				seat: i,
				n: 1
			},
			for: [e.seats[i].rid],
			secret: { cards: [a] }
		}), nt(e, i, "luoshen", {}, n));
		case "leiji": {
			rt(e, i, a), L(e, {
				kind: "judge-result",
				seat: i,
				card: "leiji",
				cards: R(e, [a])
			});
			let t = o.source;
			return !py(e, i, a) && e.seats[t].alive && e.seats[i].alive && (e.seats[t].hp < e.seats[t].maxHp && (e.seats[t].hp += 1, n.push({
				kind: "recover",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					n: 1
				}
			}), L(e, {
				kind: "recover",
				seat: t,
				n: 1
			}), X(e, t)), e.queue.unshift({
				k: "damage",
				source: t,
				target: i,
				amount: 1,
				nature: "thunder",
				reason: "leiji",
				cardId: null
			})), !1;
		}
		case "baonue": {
			let t = o.lord, r = Y(e, t, "re_baonue");
			return r || rt(e, i, a), L(e, {
				kind: "judge-result",
				seat: i,
				card: "baonue",
				cards: R(e, [a])
			}), fy(e, i, a) === "spade" && e.seats[t].alive ? (r && (e.hands[t].push(a), n.push({
				kind: "take",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					from: -1
				},
				for: [e.seats[t].rid],
				secret: { card: a }
			})), e.seats[t].hp < e.seats[t].maxHp && (e.seats[t].hp += 1, n.push({
				kind: "recover",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					n: 1
				}
			}), L(e, {
				kind: "baonue",
				seat: t
			}), e.beatMs = J.recover)) : r && U(e, [a]), !1;
		}
		case "leiji-jie": {
			rt(e, i, a), L(e, {
				kind: "judge-result",
				seat: i,
				card: "leiji",
				cards: R(e, [a])
			});
			let t = o.source;
			if (!e.seats[t].alive) return !1;
			let r = fy(e, i, a);
			return r === "spade" ? (e.pending = {
				kind: "skill-seats",
				seats: [t],
				ctx: {
					skill: "leiji-jie-spade",
					min: 0,
					max: 1,
					data: { candidates: z(e) }
				}
			}, !0) : r === "club" && (e.seats[t].hp < e.seats[t].maxHp && (e.seats[t].hp += 1, n.push({
				kind: "recover",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					n: 1
				}
			}), L(e, {
				kind: "recover",
				seat: t,
				n: 1
			}), X(e, t)), e.pending = {
				kind: "skill-seats",
				seats: [t],
				ctx: {
					skill: "leiji-jie-club",
					min: 0,
					max: 1,
					data: { candidates: z(e) }
				}
			}, !0);
		}
		case "beige-jie": {
			let t = o.ev, n = o.by;
			L(e, {
				kind: "judge-result",
				seat: i,
				card: "beige",
				cards: R(e, [a])
			});
			let r = [...e.hands[n], ...K(e, n)];
			return !e.seats[n].alive || r.length === 0 ? (rt(e, i, a), e.queue.unshift({
				k: "beige-next",
				ev: t
			}), !1) : (e.pending = {
				kind: "skill-cards",
				seats: [n],
				ctx: {
					skill: "beige-jie-discard",
					min: 0,
					max: 1,
					data: {
						pool: r,
						ev: t,
						judgeCard: a,
						js: fy(e, i, a),
						jp: s.point
					}
				}
			}, !0);
		}
		case "piaoling": return L(e, {
			kind: "judge-result",
			seat: i,
			card: "piaoling",
			cards: R(e, [a])
		}), fy(e, i, a) === "heart" && e.seats[i].alive ? (e.pending = {
			kind: "skill-ask",
			seats: [i],
			ctx: {
				skill: "piaoling-choice",
				options: ["give", "top"],
				noPass: !0,
				data: { judgeCard: a }
			}
		}, !0) : (rt(e, i, a), !1);
		case "tuntian": return fy(e, i, a) === "heart" ? (rt(e, i, a), L(e, {
			kind: "judge-result",
			seat: i,
			card: "tuntian",
			cards: R(e, [a])
		})) : (e.seats[i].tian.push(a), n.push({
			kind: "move",
			data: {
				seat: i,
				name: "tuntian"
			}
		}), L(e, {
			kind: "tuntian",
			seat: i,
			cards: R(e, [a])
		}), e.beatMs = J.judge), !1;
		case "beige": {
			let t = o.ev;
			e.queue.unshift({
				k: "beige-next",
				ev: t
			}), rt(e, i, a), L(e, {
				kind: "judge-result",
				seat: i,
				card: "beige",
				cards: R(e, [a])
			});
			let r = t.source, s = fy(e, i, a);
			if (s === "heart") {
				let r = t.target;
				return e.seats[r].alive && e.seats[r].hp < e.seats[r].maxHp && (e.seats[r].hp += 1, n.push({
					kind: "recover",
					rid: e.seats[r].rid,
					data: {
						seat: r,
						n: 1
					}
				}), L(e, {
					kind: "recover",
					seat: r,
					n: 1
				}), X(e, r), e.beatMs = J.recover), !1;
			}
			if (s === "diamond") {
				let r = t.target;
				if (e.seats[r].alive) {
					let t = H(e, r, 2);
					n.push({
						kind: "draw",
						rid: e.seats[r].rid,
						data: {
							seat: r,
							n: t.length
						},
						for: [e.seats[r].rid],
						secret: { cards: t }
					}), L(e, {
						kind: "skill-draw",
						seat: r,
						card: "beige",
						n: t.length
					}), e.beatMs = J.draw;
				}
				return !1;
			}
			if (r == null || !e.seats[r].alive) return !1;
			if (s === "spade") return Jv(e, r, n), e.pending != null;
			let c = [...e.hands[r], ...K(e, r)];
			return c.length !== 0 && (e.pending = {
				kind: "skill-cards",
				seats: [r],
				ctx: {
					skill: "beige-drop",
					min: Math.min(2, c.length),
					max: Math.min(2, c.length),
					data: { pool: c }
				}
			}, !0);
		}
		default: return U(e, [a]), !1;
	}
}
//#endregion
//#region src/games/sanguosha/rules/setup.ts
var at = {
	4: [
		"lord",
		"loyalist",
		"rebel",
		"renegade"
	],
	5: [
		"lord",
		"loyalist",
		"rebel",
		"rebel",
		"renegade"
	],
	6: [
		"lord",
		"loyalist",
		"rebel",
		"rebel",
		"rebel",
		"renegade"
	],
	7: [
		"lord",
		"loyalist",
		"loyalist",
		"rebel",
		"rebel",
		"rebel",
		"renegade"
	],
	8: [
		"lord",
		"loyalist",
		"loyalist",
		"rebel",
		"rebel",
		"rebel",
		"rebel",
		"renegade"
	]
};
function ot(e, t, n) {
	let i = {
		...de,
		...e
	}, a = t.length, o = {
		seed: n,
		rngCursor: 0,
		players: [...t],
		seats: [],
		hands: t.map(() => []),
		cards: {},
		deck: [],
		discard: [],
		candidates: {},
		turn: null,
		skipPlay: !1,
		skipDraw: !1,
		queue: [],
		pending: null,
		beatMs: 0,
		round: 0,
		deathOrder: [],
		over: null,
		extraTurn: null,
		extraAnchor: null,
		lastDiscard: null,
		judgeNames: {},
		judging: null,
		tableCard: null,
		targeting: null,
		revealAll: !1,
		log: [],
		logTotal: 0
	}, s = ["lord", ...Pv(o, (at[a] ?? at[8]).filter((e) => e !== "lord"))], c = i.identity !== "random" && t.slice(1).every(r) ? i.identity : null, l = t;
	if (c && c !== "lord") {
		let e = Pv(o, s.flatMap((e, t) => e === c ? [t] : []))[0];
		l = t.map((n, r) => r === 0 ? t[e] : r === e ? t[0] : n), o.players = [...l];
	}
	let u = Pv(o, Pe.filter((e) => sy(e.pack, i) && oy(e) && !e.id.startsWith("re_")).map((e) => i.jie && Fe.has(`re_${e.id}`) ? `re_${e.id}` : e.id)), d = u.filter((e) => Pe.find((t) => t.id === e)?.lordSkill != null).slice(0, 3), f = [...d, ...u.filter((e) => !d.includes(e)).slice(0, 5 - d.length)], p = u.filter((e) => !f.includes(e));
	for (let e = 0; e < a; e++) o.candidates[e] = e === 0 ? f : p.slice((e - 1) * 3, e * 3);
	let m = i.junzheng ? [...Oe, ...ke] : Oe, h = Pv(o, m.map((e, t) => t));
	return h.forEach((e, t) => {
		o.cards[t] = m[e];
	}), o.deck = h.map((e, t) => t), o.seats = l.map((e, t) => ({
		rid: e,
		generalId: null,
		identity: s[t],
		revealed: s[t] === "lord",
		hp: 0,
		maxHp: 0,
		equips: {
			weapon: null,
			armor: null,
			off_horse: null,
			def_horse: null
		},
		judges: [],
		chained: !1,
		turnedOver: !1,
		chuang: [],
		tian: [],
		marks: {},
		moshi: [],
		pojun: [],
		quan: [],
		chun: [],
		ni: [],
		qbSeen: [],
		luoshen: [],
		alive: !0,
		skills: [],
		limitedUsed: [],
		qianxun: [],
		kb: [],
		kbFrom: [],
		shu: [],
		funanBan: [],
		flags: {},
		lastEndHp: 0
	})), o.pending = {
		kind: "general-select",
		seats: [0],
		ctx: {}
	}, L(o, { kind: "setup" }), { state: o };
}
function st(e) {
	let t = z(e), n = t.map((t) => e.seats[t].identity);
	if (!n.includes("lord")) {
		e.over = t.length === 1 && n[0] === "renegade" ? { winner: "renegade" } : { winner: "rebel" };
		return;
	}
	!n.includes("rebel") && !n.includes("renegade") && (e.over = { winner: "lord" });
}
function ct(e, t, n, r) {
	my(e);
	let i = e.seats[t];
	i.alive = !1, i.revealed = !0, e.deathOrder.push(t), n != null && e.seats[n].flags.xtBy != null && (e.seats[n].flags.xtKilled = !0), r.push({
		kind: "death",
		rid: i.rid,
		data: {
			seat: t,
			identity: i.identity
		}
	}), L(e, {
		kind: "death",
		seat: t
	});
	let a = [
		i.equips.weapon,
		i.equips.armor,
		i.equips.off_horse,
		i.equips.def_horse
	].filter((e) => e != null), o = z(e).find((n) => n !== t && (Y(e, n, "xingshang") || Y(e, n, "re_xingshang")));
	if (o != null) {
		let n = [...e.hands[t], ...a];
		Y(e, o, "re_xingshang") ? (e.queue.unshift({
			k: "xingshang-jie",
			seat: o,
			dead: t,
			cards: n
		}), e.hands[t] = []) : n.length > 0 && (e.hands[o].push(...n), r.push({
			kind: "give",
			rid: e.seats[o].rid,
			data: {
				from: t,
				to: o,
				n: n.length
			},
			for: [e.seats[o].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "xingshang",
			seat: o,
			target: t,
			n: n.length
		})), U(e, [
			...i.judges,
			...i.chuang,
			...i.tian,
			...i.pojun,
			...i.quan,
			...i.chun,
			...i.ni,
			...i.kb,
			...i.shu
		]);
	} else U(e, [
		...e.hands[t],
		...a,
		...i.judges,
		...i.chuang,
		...i.tian,
		...i.pojun,
		...i.quan,
		...i.chun,
		...i.ni,
		...i.kb,
		...i.shu
	]);
	for (let t of i.judges) delete e.judgeNames[t];
	if (e.hands[t] = [], i.equips = {
		weapon: null,
		armor: null,
		off_horse: null,
		def_horse: null
	}, i.judges = [], i.chuang = [], i.tian = [], i.pojun = [], i.quan = [], i.chun = [], i.ni = [], i.kb = [], i.kbFrom = [], i.shu = [], n != null && e.seats[n].alive) {
		if (i.identity === "rebel") {
			let t = H(e, n, 3);
			r.push({
				kind: "draw",
				rid: e.seats[n].rid,
				data: {
					seat: n,
					n: t.length
				}
			}), L(e, {
				kind: "reward",
				seat: n,
				n: t.length
			}), P(e, n, t);
		} else if (i.identity === "loyalist" && e.seats[n].identity === "lord") {
			let t = e.seats[n], i = [...e.hands[n], ...[
				t.equips.weapon,
				t.equips.armor,
				t.equips.off_horse,
				t.equips.def_horse
			].filter((e) => e != null)];
			U(e, i), e.hands[n] = [], t.equips = {
				weapon: null,
				armor: null,
				off_horse: null,
				def_horse: null
			}, r.push({
				kind: "discard",
				rid: t.rid,
				data: {
					seat: n,
					n: i.length
				}
			}), L(e, {
				kind: "punish",
				seat: n
			});
		}
	}
	n != null && i.skills.includes("duanchang") && (e.seats[n].skills = [], L(e, {
		kind: "duanchang",
		seat: t,
		target: n
	}));
	let s = $v(e, t);
	if (!z(e).some((t) => $v(e, t) === s)) for (let t of z(e)) {
		let n = e.seats[t];
		n.skills.includes("zongzuo") && (n.maxHp = Math.max(1, n.maxHp - 1), n.hp = Math.min(n.hp, n.maxHp), L(e, {
			kind: "skill",
			seat: t,
			card: "zongzuo"
		}));
	}
	if (st(e), !e.over && i.skills.includes("zhuiyi")) {
		let r = z(e).filter((e) => e !== t && e !== n);
		r.length > 0 && (e.pending = {
			kind: "skill-seats",
			seats: [t],
			ctx: {
				skill: "zhuiyi-target",
				min: 0,
				max: 1,
				data: { candidates: r }
			}
		});
	}
	if (!e.over && i.skills.includes("juexiang")) {
		if (n != null && e.seats[n].alive) {
			let i = K(e, n);
			for (let t of [
				"weapon",
				"armor",
				"off_horse",
				"def_horse"
			]) e.seats[n].equips[t] = null;
			if (i.length > 0) {
				U(e, i), r.push({
					kind: "discard",
					rid: e.seats[n].rid,
					data: {
						seat: n,
						n: i.length,
						cards: i
					}
				}), L(e, {
					kind: "skill",
					seat: t,
					card: "juexiang"
				});
				for (let t of i) I(e, n, t, r);
			}
			Ly(e, n, 1, r);
		}
		let i = z(e).filter((e) => e !== t);
		i.length > 0 && (e.pending = {
			kind: "skill-seats",
			seats: [t],
			ctx: {
				skill: "juexiang-target",
				min: 0,
				max: 1,
				data: { candidates: i }
			}
		});
	}
}
//#endregion
//#region src/games/sanguosha/rules/skills/core.ts
var lt = (e, t, n, r) => {
	let i = [...e.hands[t], ...K(e, t)];
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "axe-discard",
			min: 2,
			max: 2,
			data: {
				pool: i,
				target: r.target,
				cardName: r.cardName,
				ana: r.ana,
				cardId: r.cardId
			}
		}
	};
}, ut = (e, t, n, r) => {
	let i = e.hands[t].filter((n) => A(e.cards[n].name) || hy(e, t, n).includes("slash"));
	i.length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "green_dragon-slash",
			min: 1,
			max: 1,
			data: {
				pool: i,
				target: r.target
			}
		}
	});
}, dt = (e, t, n, r, i) => {
	let a = e.seats[t], o = r.info;
	if (e.seats[o.target].alive) {
		if (e.hands[o.target].length === 0) {
			let n = H(e, t, 1);
			i.push({
				kind: "draw",
				rid: a.rid,
				data: {
					seat: t,
					n: n.length
				},
				for: [a.rid],
				secret: { cards: n }
			}), L(e, {
				kind: "skill-draw",
				seat: t,
				card: "double_sword",
				n: n.length
			}), e.beatMs = J.draw, P(e, t, n), We(e, o, i);
			return;
		}
		e.pending = {
			kind: "skill-ask",
			seats: [o.target],
			ctx: {
				skill: "double_sword-choice",
				options: ["ds-discard", "ds-draw"],
				noPass: !0,
				from: o.from,
				data: { info: o }
			}
		};
	}
}, ft = (e, t) => {
	let n = e.seats[t];
	n.flags.skipJudgeOnce = !0, e.skipDraw = !0, e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "shensu-slash",
			min: 1,
			max: 1,
			data: { candidates: Dv(e, t) }
		}
	};
}, pt = (e, t) => {
	let n = Ov(e, t);
	if (n.length === 0) {
		e.queue.unshift({ k: "play-phase" });
		return;
	}
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "shensu2-discard",
			min: 1,
			max: 1,
			data: { pool: n }
		}
	};
}, mt = (e, t, n, r) => {
	let i = r.target;
	e.seats[i].alive && et(e, i, "dismantlement", !1).length > 0 && (e.pending = {
		kind: "pick-zone",
		seats: [t],
		ctx: {
			trick: "dismantlement",
			from: t,
			target: i,
			allowJudge: !1,
			iceLeft: 1
		}
	});
}, ht = (e, t) => {
	let n = e.seats[t];
	n.flags.skipDiscardOnce = !0, n.flags.shensu3Flip = !0, e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "shensu-slash",
			min: 1,
			max: 1,
			data: {
				candidates: Dv(e, t),
				shensu3: !0
			}
		}
	};
}, gt = (e, t, n, r) => {
	let i = r.from, a = (r.candidates ?? []).filter((t) => e.seats[t].alive && e.seats[i].alive && V(e, i, t) <= Bv(e, i) && !N(e, t));
	a.length !== 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "zy-slash-target",
			min: 1,
			max: 1,
			data: { candidates: a }
		}
	});
}, _t = (e, t, n, r, i) => {
	We(e, r.info, i);
}, vt = (e) => {
	e.queue.unshift({ k: "play-phase" });
}, yt = (e, t, n, r, i) => {
	Py(e, r.ev, i), e.beatMs = J.damage;
}, bt = {
	axe: lt,
	green_dragon: ut,
	double_sword: dt,
	shensu1: ft,
	shensu2: pt,
	ice_sword: mt,
	shensu3: ht,
	"zy-slash": gt
}, xt = {
	double_sword: _t,
	shensu2: vt,
	ice_sword: yt
}, St = (e, t, n, r, i) => {
	let a = i.filter((t) => e.hands[t].length > 0);
	return a.length > 0 ? {
		minCards: 0,
		maxCards: 0,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, Ct = (e, t, n, r, i) => {
	if (n.tian.length === 0) return null;
	let a = i.filter((n) => V(e, t, n) <= 1 && et(e, n, "snatch").length > 0);
	return a.length > 0 ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: a,
		allowTian: !0
	} : null;
}, wt = (e) => ({
	minCards: 0,
	maxCards: 0,
	minTargets: 1,
	maxTargets: 1,
	targets: z(e)
}), Tt = (e, t, n) => n.quan.length > 0 ? {
	minCards: 0,
	maxCards: 0,
	minTargets: 0,
	maxTargets: 0,
	targets: []
} : null, Et = (e, t, n, r, i, a, o) => {
	let s = i[0];
	o.push({
		kind: "reveal-hand",
		rid: e.seats[t].rid,
		data: {
			target: s,
			cards: [...e.hands[s]]
		},
		for: [e.seats[t].rid]
	});
	let c = e.hands[s].filter((t) => e.cards[t].suit === "heart");
	return L(e, {
		kind: "gongxin",
		seat: t,
		target: s
	}), c.length > 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "gongxin",
			min: 1,
			max: 1,
			data: {
				pool: c,
				target: s
			}
		}
	}), {
		state: e,
		fx: o
	};
}, Dt = (e, t, n, r, i, a, o) => {
	let s = e.seats[t].quan.shift();
	return U(e, [s]), L(e, {
		kind: "paiyi",
		seat: t,
		cards: R(e, [s])
	}), e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "paiyi-target",
			min: 1,
			max: 1,
			data: { candidates: z(e) }
		}
	}, {
		state: e,
		fx: o
	};
}, Ot = (e, t, n, r, i, a, o) => {
	let s = i[0], c = e.seats[s];
	if (c.ni.length < 2) return q("games.sanguosha.error.badSkill");
	let l = c.ni.splice(0, 2);
	return U(e, l), e.turn.slashUsed += 1, e.seats[t].flags.slashInPlay = !0, L(e, {
		kind: "xiansi2",
		seat: t,
		target: s,
		cards: R(e, l)
	}), e.beatMs = J.play, e.queue.unshift({
		k: "slash-target",
		from: t,
		target: s,
		cardName: "slash",
		suit: null,
		cardId: null
	}), Z(e, o), {
		state: e,
		fx: o
	};
}, kt = (e, t, n, r, i, a, o) => {
	let s = i[0];
	return e.seats[s].marks.sishu = (e.seats[s].marks.sishu ?? 0) + 1, L(e, {
		kind: "sishu",
		seat: t,
		target: s
	}), e.beatMs = J.play, {
		state: e,
		fx: o
	};
}, At = (e, t, n, r, i, a, o) => {
	let s = i[0], c = r[0];
	return e.seats[t].tian.splice(e.seats[t].tian.indexOf(c), 1), U(e, [c]), Fv(e, c, "snatch", t, [s]), o.push({
		kind: "play",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: c,
			name: "snatch"
		}
	}), L(e, {
		kind: "use",
		seat: t,
		card: "snatch",
		target: s
	}), e.beatMs = J.play, xv(e, t, o), Qe(e, t, "snatch", s, {
		k: "trick-effect",
		name: "snatch",
		from: t,
		target: s,
		cardId: null,
		suit: e.cards[c].suit
	}), Z(e, o), {
		state: e,
		fx: o
	};
}, jt = {
	gongxin: St,
	jixi: Ct,
	sishu: wt,
	paiyi: Tt
}, Mt = {
	gongxin: Et,
	paiyi: Dt,
	xiansi2: Ot,
	sishu: kt,
	jixi: At
}, Nt = (e, t, n, r, i, a, o, s) => {
	let c = i.info;
	if (n.option === "ds-discard") return e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "ds-drop",
			min: 1,
			max: 1,
			data: { info: c }
		}
	}, {
		state: e,
		fx: s
	};
	let l = H(e, c.from, 1);
	return s.push({
		kind: "draw",
		rid: e.seats[c.from].rid,
		data: {
			seat: c.from,
			n: l.length
		},
		for: [e.seats[c.from].rid],
		secret: { cards: l }
	}), L(e, {
		kind: "skill-draw",
		seat: c.from,
		card: "double_sword",
		n: l.length
	}), e.beatMs = J.draw, P(e, c.from, l), We(e, c, s), {
		state: e,
		fx: s
	};
}, Pt = (e, t, n, r, i, a, o, s) => {
	if (L(e, {
		kind: "skill",
		seat: i.from ?? t,
		card: "xinjujian"
	}), n.option === "jj-draw") {
		let n = H(e, t, 2);
		s.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "xinjujian",
			n: n.length
		}), e.beatMs = J.draw;
	} else n.option === "jj-recover" ? (e.seats[t].hp < e.seats[t].maxHp && (e.seats[t].hp += 1, s.push({
		kind: "recover",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: t,
		n: 1
	}), X(e, t)), e.beatMs = J.recover) : (e.seats[t].chained && (e.seats[t].chained = !1, s.push({
		kind: "unchain",
		data: { seat: t }
	}), L(e, {
		kind: "unchain",
		seat: t
	})), e.seats[t].turnedOver && Jv(e, t, s));
	return e.pending || Z(e, s), {
		state: e,
		fx: s
	};
}, Ft = (e, t, n, r, i, a, o, s) => {
	let c = i.from, l = i.rest;
	if (n.option === "fc-damage") return l.length > 0 && e.queue.unshift({
		k: "fencheng-step",
		seats: l,
		prev: 0,
		from: c
	}), e.queue.unshift({
		k: "damage",
		source: c,
		target: t,
		amount: 2,
		nature: "fire",
		reason: "xinfencheng",
		cardId: null
	}), Z(e, s), {
		state: e,
		fx: s
	};
	let u = [...e.hands[t], ...K(e, t)], d = i.need;
	return u.length < d ? q("games.sanguosha.error.badChoose") : (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "fencheng-discard",
			min: d,
			max: u.length,
			data: {
				pool: u,
				rest: l,
				from: c
			}
		}
	}, {
		state: e,
		fx: s
	});
}, It = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.target;
	for (let t of ["off_horse", "def_horse"]) e.seats[u].equips[t] === l && (e.seats[u].equips[t] = null);
	U(e, [l]), I(e, u, l, c), L(e, {
		kind: "kylin",
		seat: t,
		target: u
	}), e.beatMs = J.discard;
}, Lt = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	return W(e, t, l), U(e, [l]), F(e, t, 1), L(e, {
		kind: "skill",
		seat: t,
		card: "double_sword"
	}), L(e, {
		kind: "discard",
		seat: t,
		n: 1,
		cards: R(e, [l])
	}), We(e, r.info, c), e.pending || Z(e, c), {
		state: e,
		fx: c
	};
}, Rt = (e, t, n, r, i, a, o, s, c) => {
	let l = 0;
	for (let n of i) if (W(e, t, n)) l += 1;
	else {
		for (let r of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[r] === n && (e.seats[t].equips[r] = null);
		I(e, t, n, c);
	}
	U(e, i), F(e, t, l);
	let u = r.target, d = r.cardName, f = d === "fire_slash" ? "fire" : d === "thunder_slash" ? "thunder" : "normal";
	L(e, {
		kind: "axe-hit",
		seat: t,
		target: u,
		cards: R(e, i)
	}), e.queue.unshift({
		k: "damage",
		source: t,
		target: u,
		amount: 1 + (r.ana ?? 0) + (r.plus ?? 0),
		nature: f,
		reason: "slash",
		cardId: r.cardId ?? null,
		ana: r.ana ?? 0
	}), e.beatMs = J.discard;
}, zt = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = A(e.cards[l].name), d = !u && hy(e, t, l).includes("slash");
	if (!u && !d) return q("games.sanguosha.error.noCard");
	W(e, t, l), U(e, [l]), Iv(e, l, "slash", t), c.push({
		kind: "respond-slash",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: l,
			name: e.cards[l].name,
			table: !0
		}
	});
	let f = r.target;
	return L(e, {
		kind: "use",
		seat: t,
		card: "slash",
		target: f,
		cards: R(e, [l])
	}), e.queue.unshift({
		k: "slash-target",
		from: t,
		target: f,
		cardName: u ? e.cards[l].name : "slash",
		suit: dy(e, t, l),
		cardId: l,
		ana: 0
	}), F(e, t, 1), bv(e, t, l, c), Z(e, c), {
		state: e,
		fx: c
	};
}, Bt = (e, t, n, r, i) => {
	let a = r.target;
	W(e, a, i[0]), U(e, [i[0]]), L(e, {
		kind: "gongxin-drop",
		seat: t,
		target: a,
		cards: R(e, [i[0]])
	}), cv(e, a);
}, Vt = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.from;
	if (c.push({
		kind: "reveal",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: l
		}
	}), L(e, {
		kind: "fire-attack-show",
		seat: t,
		target: u,
		cards: R(e, [l])
	}), !e.seats[u].alive) return;
	let d = dy(e, t, l), f = e.hands[u].filter((t) => dy(e, u, t) === d);
	f.length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [u],
		ctx: {
			skill: "fire_attack-discard",
			min: 0,
			max: 1,
			data: {
				target: t,
				pool: f,
				cardId: r.cardId
			}
		}
	});
}, Ht = (e, t, n, r, i) => {
	if (i.length === 1) {
		let n = i[0];
		W(e, t, n), U(e, [n]), F(e, t, 1);
		let a = r.target;
		L(e, {
			kind: "fire-attack",
			seat: t,
			target: a,
			cards: R(e, [n])
		}), e.queue.unshift({
			k: "damage",
			source: t,
			target: a,
			amount: 1,
			nature: "fire",
			reason: "fire_attack",
			cardId: r.cardId ?? null
		});
	}
}, Ut = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (W(e, t, l)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === l && (e.seats[t].equips[n] = null);
		I(e, t, l, c);
	}
	U(e, [l]), L(e, {
		kind: "discard",
		seat: t,
		n: 1,
		cards: R(e, [l])
	});
	let u = Dv(e, t);
	u.length > 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "shensu-slash",
			min: 1,
			max: 1,
			data: { candidates: u }
		}
	});
}, Wt = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	W(e, t, l), U(e, [l]), F(e, t, 1), pv(e, [l], c, t), dv(e, [l], t), L(e, {
		kind: "discard-skill",
		seat: t,
		card: "xinjujian",
		cards: R(e, [l])
	}), e.beatMs = J.discard;
	let u = z(e).filter((e) => e !== t);
	u.length > 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "jujian-target",
			min: 1,
			max: 1,
			data: { candidates: u }
		}
	});
}, Gt = (e, t, n, r, i, a, o, s, c) => {
	let l = r.holder, u = i[0];
	W(e, t, u), e.hands[l].push(u), c.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: l,
			n: 1
		},
		for: [e.seats[t].rid, e.seats[l].rid],
		secret: { cards: [u] }
	}), L(e, {
		kind: "enyuan-give",
		seat: t,
		target: l
	}), F(e, t, 1), gv(e, l, t, r.amountLeft ?? 0, r.liyu ?? null);
}, Kt = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from, u = 0;
	for (let t of i) if (W(e, l, t)) u += 1;
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[l].equips[n] === t && (e.seats[l].equips[n] = null);
		I(e, l, t, c);
	}
	e.hands[t].push(...i), c.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: l,
			to: t,
			n: i.length
		},
		for: [e.seats[t].rid],
		secret: { cards: i }
	}), L(e, {
		kind: "xuanhuo-take",
		seat: t,
		target: l,
		n: i.length
	}), u > 0 && F(e, l, u), hv(e, t, l, i.length, c), e.beatMs = J.draw;
}, qt = (e, t, n, r, i, a, o, s, c) => {
	let l = r.fz;
	if (i.length === 0) {
		_v(e, l, t, c), e.beatMs = J.draw;
		return;
	}
	let u = i[0], d = A(e.cards[u].name), f = !d && hy(e, t, u).includes("slash");
	if (!d && !f) return q("games.sanguosha.error.noCard");
	W(e, t, u), U(e, [u]), Iv(e, u, "slash", t), c.push({
		kind: "respond-slash",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: u,
			name: e.cards[u].name,
			table: !0
		}
	});
	let p = r.victim;
	L(e, {
		kind: "use",
		seat: t,
		card: "slash",
		target: p,
		cards: R(e, [u])
	}), e.queue.unshift({
		k: "slash-target",
		from: t,
		target: p,
		cardName: d ? e.cards[u].name : "slash",
		suit: dy(e, t, u),
		cardId: u,
		ana: 0
	}), F(e, t, 1), bv(e, t, u, c);
}, Jt = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	return W(e, t, l), U(e, [l]), pv(e, [l], c, t), dv(e, [l], t), F(e, t, 1), L(e, {
		kind: "mieji-discard",
		seat: t,
		n: 1,
		cards: R(e, [l])
	}), e.beatMs = J.discard, Z(e, c), {
		state: e,
		fx: c
	};
}, Yt = (e, t, n, r, i, a, o, s, c) => (Qv(e, t, i, c), L(e, {
	kind: "mieji-discard",
	seat: t,
	n: 2,
	cards: R(e, i)
}), e.beatMs = J.discard, e.pending || Z(e, c), {
	state: e,
	fx: c
}), Xt = (e, t, n, r, i, a, o, s, c) => {
	Qv(e, t, i, c), L(e, {
		kind: "fencheng-discard",
		seat: t,
		n: i.length,
		cards: R(e, i)
	}), e.beatMs = J.discard;
	let l = r.rest;
	return l.length > 0 && e.queue.unshift({
		k: "fencheng-step",
		seats: l,
		prev: i.length,
		from: r.from
	}), e.pending || Z(e, c), {
		state: e,
		fx: c
	};
}, Zt = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.target;
	Qv(e, t, [l], c), e.seats[u].alive && (G(e, l) ? e.seats[u].flags.sidiRed = !0 : e.seats[u].flags.sidiBlack = !0, e.seats[u].flags.sidiBy = t + 1), L(e, {
		kind: "xinsidi",
		seat: t,
		target: u,
		cards: R(e, [l])
	}), e.beatMs = J.discard;
}, Qt = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	mv(e, t, r.target, l, c);
}, $t = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (W(e, t, l)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === l && (e.seats[t].equips[n] = null);
		I(e, t, l, c);
	}
	e.deck.unshift(l), L(e, {
		kind: "xx-put",
		seat: t
	});
	let u = r.targets, d = r.idx;
	d + 1 < u.length && e.queue.unshift({
		k: "xx-step",
		targets: u,
		idx: d + 1
	});
}, en = (e, t, n, r, i, a, o, s, c) => {
	for (let t of i) e.seats[t].chained = !e.seats[t].chained, c.push({
		kind: e.seats[t].chained ? "chain" : "unchain",
		data: { seat: t }
	}), L(e, {
		kind: e.seats[t].chained ? "chain" : "unchain",
		seat: t
	}), e.seats[t].chained && fv(e, t);
	e.beatMs = J.play;
}, tn = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	L(e, {
		kind: "skill",
		seat: t,
		card: "xinxuanhuo"
	});
	let u = H(e, l, 2);
	c.push({
		kind: "draw",
		rid: e.seats[l].rid,
		data: {
			seat: l,
			n: u.length
		},
		for: [e.seats[l].rid],
		secret: { cards: u }
	}), L(e, {
		kind: "skill-draw",
		seat: l,
		card: "xinxuanhuo",
		n: u.length
	}), e.beatMs = J.draw;
	let d = z(e).filter((t) => t !== l && !N(e, t) && V(e, l, t) <= Bv(e, l)), f = e.hands[l].filter((t) => A(e.cards[t].name) || hy(e, l, t).includes("slash"));
	if (d.length === 0 || f.length === 0) {
		_v(e, t, l, c);
		return;
	}
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "xuanhuo-victim",
			min: 1,
			max: 1,
			data: {
				candidates: d,
				a: l
			}
		}
	};
}, nn = (e, t, n, r, i, a, o, s, c) => {
	let l = r.a, u = e.hands[l].filter((t) => A(e.cards[t].name) || hy(e, l, t).includes("slash"));
	if (!e.seats[l].alive || u.length === 0) {
		_v(e, t, l, c);
		return;
	}
	e.pending = {
		kind: "skill-cards",
		seats: [l],
		ctx: {
			skill: "xuanhuo-slash",
			min: 0,
			max: 1,
			data: {
				pool: u,
				fz: t,
				victim: i[0]
			}
		}
	};
}, rn = (e, t, n, r, i) => {
	let a = i[0], o = e.seats[a], s = [
		"jj-draw",
		...o.hp < o.maxHp ? ["jj-recover"] : [],
		...o.turnedOver || o.chained ? ["jj-reset"] : []
	];
	e.pending = {
		kind: "skill-ask",
		seats: [a],
		ctx: {
			skill: "jujian-choice",
			options: s,
			noPass: !0,
			data: { from: t }
		}
	};
}, an = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = H(e, l, 2);
	c.push({
		kind: "draw",
		rid: e.seats[l].rid,
		data: {
			seat: l,
			n: u.length
		},
		for: [e.seats[l].rid],
		secret: { cards: u }
	}), L(e, {
		kind: "skill-draw",
		seat: l,
		card: "paiyi",
		n: u.length
	}), e.beatMs = J.draw, P(e, l, u), e.hands[l].length > e.hands[t].length && e.queue.unshift({
		k: "damage",
		source: t,
		target: l,
		amount: 1,
		nature: "normal",
		reason: "skill",
		cardId: null
	});
}, on = (e, t, n, r, i, a, o, s, c) => {
	let [l, u] = i;
	if (e.hands[l].length === e.hands[u].length) return q("games.sanguosha.error.badTarget");
	let d = e.hands[l].length < e.hands[u].length ? l : u, f = d === l ? u : l;
	if (e.hands[f].length > 0) {
		let n = e.hands[f][Nv(e, e.hands[f].length)];
		if (W(e, f, n), e.hands[d].push(n), F(e, f, 1), c.push({
			kind: "give",
			rid: e.seats[f].rid,
			data: {
				from: f,
				to: d,
				n: 1
			},
			for: [e.seats[f].rid, e.seats[d].rid],
			secret: { cards: [n] }
		}), c.push({
			kind: "reveal",
			rid: e.seats[d].rid,
			data: {
				seat: d,
				card: n
			}
		}), L(e, {
			kind: "anxu",
			seat: t,
			target: d,
			cards: R(e, [n])
		}), dy(e, d, n) !== "spade") {
			let n = H(e, t, 1);
			c.push({
				kind: "draw",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					n: n.length
				},
				for: [e.seats[t].rid],
				secret: { cards: n }
			}), L(e, {
				kind: "skill-draw",
				seat: t,
				card: "old_anxu",
				n: n.length
			});
		}
		e.beatMs = J.draw;
	}
}, sn = (e, t, n, r, i) => {
	let a = i[0];
	e.seats[a].alive && e.hands[a].length === 0 && (L(e, {
		kind: "xinjuece",
		seat: t,
		target: a
	}), e.queue.unshift({
		k: "damage",
		source: t,
		target: a,
		amount: 1,
		nature: "normal",
		reason: "xinjuece",
		cardId: null
	}), e.beatMs = J.play);
}, cn = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.pool.filter((t) => e.discard.includes(t));
	if (e.seats[l].alive && u.length !== 0) {
		if (u.length > 1) return e.pending = {
			kind: "skill-cards",
			seats: [t],
			ctx: {
				skill: "zy-card",
				min: 1,
				max: 1,
				data: {
					pool: u,
					target: l
				}
			}
		}, {
			state: e,
			fx: c
		};
		mv(e, t, l, u[0], c);
	}
}, ln = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	L(e, {
		kind: "zy-slash",
		seat: t,
		target: l
	}), c.push({
		kind: "play",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			name: "slash"
		}
	}), e.queue.unshift({
		k: "slash-target",
		from: t,
		target: l,
		cardName: "slash",
		suit: null,
		cardId: null
	}), e.beatMs = J.play;
}, un = (e, t, n, r, i, a, o, s, c) => {
	let l = H(e, t, 1);
	c.push({
		kind: "draw",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: l.length
		},
		for: [e.seats[t].rid],
		secret: { cards: l }
	});
	for (let t of i) {
		if (!e.seats[t].alive) continue;
		let n = H(e, t, 1);
		c.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), P(e, t, n);
	}
	P(e, t, l), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "olbingyi",
		n: 1
	}), e.beatMs = J.draw;
}, dn = {
	"double_sword-choice": Nt,
	"jujian-choice": Pt,
	"fencheng-step": Ft
}, fn = {
	kylin_bow: It,
	"ds-drop": Lt,
	"axe-discard": Rt,
	"green_dragon-slash": zt,
	gongxin: Bt,
	"fire_attack-show": Vt,
	"fire_attack-discard": Ht,
	"shensu2-discard": Ut,
	"jujian-cost": Wt,
	"enyuan-give": Gt,
	"xuanhuo-take": Kt,
	"xuanhuo-slash": qt,
	"mieji-trick": Jt,
	"mieji-drop2": Yt,
	"fencheng-discard": Xt,
	"sidi-discard": Zt,
	"zy-card": Qt,
	"xx-put": $t
}, pn = {
	iron_chain: en,
	"xuanhuo-target": tn,
	"xuanhuo-victim": nn,
	"jujian-target": rn,
	"paiyi-target": an,
	"anxu-targets": on,
	"juece-target": sn,
	"zy-target": cn,
	"zy-slash-target": ln,
	"bingyi-targets": un
}, mn = (e, t, n, r, i) => {
	let a = Bv(e, t), o = i.filter((n) => V(e, t, n) <= a), s = e.hands[t].some((t) => k(e.cards[t].name) === "weapon") || n.equips.weapon != null;
	return o.length > 0 && (s || n.hp > 0) ? {
		minCards: 0,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: o,
		allowEquip: !0
	} : null;
}, hn = (e, t, n, r, i) => {
	if (Number(n.flags.qxN ?? 0) >= 2) return null;
	let a = Number(n.flags.qxT ?? 0), o = i.filter((e) => !(a & 1 << e)), s = e.hands[t].some((t) => k(e.cards[t].name) === "weapon") || n.equips.weapon != null;
	return o.length > 0 && (s || n.hp > 0) ? {
		minCards: 0,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: o,
		allowEquip: !0
	} : null;
}, gn = (e, t, n, r, i, a, o) => {
	let s = i[0], c = n === "re_qiangxi";
	if (c && (e.seats[t].flags.qxN = (e.seats[t].flags.qxN ?? 0) + 1, e.seats[t].flags.qxT = Number(e.seats[t].flags.qxT ?? 0) | 1 << s), r.length === 1) {
		let n = r[0];
		if (k(e.cards[n].name) !== "weapon") return q("games.sanguosha.error.badSkill");
		W(e, t, n) || (e.seats[t].equips.weapon = null, I(e, t, n, o)), U(e, [n]), F(e, t, 1);
	} else if (c) return e.queue.unshift({
		k: "damage",
		source: t,
		target: s,
		amount: 1,
		nature: "normal",
		reason: "qiangxi",
		cardId: null
	}), e.queue.unshift({
		k: "damage",
		source: null,
		target: t,
		amount: 1,
		nature: "normal",
		reason: "qiangxi",
		cardId: null
	}), L(e, {
		kind: "qiangxi",
		seat: t,
		target: s
	}), e.beatMs = J.play, Z(e, o), {
		state: e,
		fx: o
	};
	else Ly(e, t, 1, o);
	return L(e, {
		kind: "qiangxi",
		seat: t,
		target: s
	}), e.queue.unshift({
		k: "damage",
		source: t,
		target: s,
		amount: 1,
		nature: "normal",
		reason: "qiangxi",
		cardId: null
	}), e.beatMs = J.play, e.pending || Z(e, o), {
		state: e,
		fx: o
	};
}, _n = (e, t, n, r, i, a, o, s, c) => {
	if (i.length === 0) return;
	let l = i[0], u = r.target, d = !1;
	for (let t of [
		"weapon",
		"armor",
		"off_horse",
		"def_horse"
	]) if (e.seats[u].equips[t] === l) {
		e.seats[u].equips[t] = null, U(e, [l]), I(e, u, l, c), d = !0;
		break;
	}
	if (!d) {
		let t = e.seats[u].judges.indexOf(l);
		t >= 0 && (e.seats[u].judges.splice(t, 1), delete e.judgeNames[l], U(e, [l]), d = !0);
	}
	d && (L(e, {
		kind: "discard-skill",
		seat: t,
		target: u,
		cards: R(e, [l])
	}), e.beatMs = J.discard);
}, vn = {
	qiangxi: mn,
	re_qiangxi: hn
}, yn = {
	qiangxi: gn,
	re_qiangxi: gn
}, bn = { ninge: _n }, xn = (e, t, n, r) => {
	let i = r.target;
	e.seats[i].alive && et(e, i, "dismantlement", !1).length > 0 && (e.pending = {
		kind: "pick-zone",
		seats: [t],
		ctx: {
			trick: "dismantlement",
			from: t,
			target: i,
			allowJudge: !1
		}
	});
}, Sn = (e, t, n, r) => {
	let i = r.info;
	e.seats[i.target].alive && et(e, i.target, "dismantlement", !1).length > 0 && (e.pending = {
		kind: "pick-zone",
		seats: [t],
		ctx: {
			trick: "dismantlement",
			from: t,
			target: i.target,
			allowJudge: !1,
			via: "jianchu",
			info: i
		}
	});
}, Cn = (e, t, n, r) => {
	let i = r.info;
	e.queue.unshift({
		k: "slash-target",
		from: i.from,
		target: i.target,
		cardName: i.cardName,
		suit: i.suit,
		cardId: i.cardId,
		ana: i.ana,
		noJink: i.noJink,
		plus: i.plus,
		jcDone: !0
	});
}, wn = {
	mengjin: xn,
	jianchu: Sn
}, Tn = { jianchu: Cn }, En = (e, t, n, r, i) => {
	let a = e.seats[t], o = n === "re_niepan";
	a.limitedUsed.push(n);
	let s = [...e.hands[t], ...a.judges];
	for (let t of a.judges) delete e.judgeNames[t];
	for (let n of [
		"weapon",
		"armor",
		"off_horse",
		"def_horse"
	]) {
		let r = a.equips[n];
		r != null && (s.push(r), a.equips[n] = null, I(e, t, r, i));
	}
	e.hands[t] = [], a.judges = [], U(e, s), a.turnedOver && (a.turnedOver = !1, i.push({
		kind: "turn-over",
		data: {
			seat: t,
			down: !1
		}
	}), L(e, {
		kind: "turn-back",
		seat: t
	}));
	let c = H(e, t, 3);
	if (i.push({
		kind: "draw",
		rid: a.rid,
		data: {
			seat: t,
			n: c.length
		},
		for: [a.rid],
		secret: { cards: c }
	}), a.hp = Math.min(3, a.maxHp), i.push({
		kind: "recover",
		rid: a.rid,
		data: {
			seat: t,
			n: 3,
			by: "niepan"
		}
	}), L(e, {
		kind: "niepan",
		seat: t
	}), e.beatMs = J.recover, my(e), o) {
		e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "niepan-pick",
				options: [
					"bazhen",
					"re_huoji",
					"re_kanpo"
				],
				noPass: !0,
				data: {
					dmg: r.dmg,
					zx: r.zx
				}
			}
		};
		return;
	}
	let l = r.dmg;
	l && e.queue.unshift(l);
	let u = r.zx;
	u && u > 0 && Iy(e, t, u);
}, Dn = (e, t, n, r) => {
	e.pending = {
		kind: "peach-save",
		seats: B(e, t),
		ctx: {
			target: t,
			source: r.source ?? null,
			...r.dmg ? { dmg: r.dmg } : {},
			...r.zx ? { zx: r.zx } : {}
		}
	};
}, On = (e, t, n, r, i, a, o, s) => {
	e.seats[t].skills.push(n.option), L(e, {
		kind: "niepan-skill",
		seat: t,
		card: n.option
	});
	let c = i.dmg;
	c && e.queue.unshift(c);
	let l = i.zx;
	return l && l > 0 && Iy(e, t, l), e.pending || Z(e, s), {
		state: e,
		fx: s
	};
}, kn = {
	niepan: En,
	re_niepan: En
}, An = {
	niepan: Dn,
	re_niepan: Dn
}, jn = { "niepan-pick": On }, Mn = (e, t, n, r, i) => {
	let a = i.filter((t) => e.hands[t].length > 0);
	return r >= 1 && a.length > 0 ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, Nn = (e, t, n, r, i, a, o) => (e.pending = {
	kind: "skill-cards",
	seats: [i[0]],
	ctx: {
		skill: "tianyi",
		min: 1,
		max: 1,
		data: {
			from: t,
			myCard: r[0]
		}
	}
}, {
	state: e,
	fx: o
}), Pn = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from, u = Z_(e, l, t, r.myCard, Q_(e, l, t) ?? i[0], "tianyi", c);
	e.seats[l].flags[u ? "tianyiWin" : "tianyiLose"] = !0, L(e, {
		kind: u ? "tianyi-win" : "tianyi-lose",
		seat: l
	}), e.beatMs = J.play;
}, Fn = (e, t, n, r, i) => {
	i.forEach((n, i) => {
		e.targeting?.from === t && (e.targeting.targets = [.../* @__PURE__ */ new Set([...e.targeting.targets, n])]);
		let a = {
			k: "slash-target",
			from: t,
			target: n,
			cardName: r.cardName,
			suit: r.suit,
			cardId: r.cardId,
			ana: r.ana ?? 0,
			...r.lihuo == null ? {} : { lihuo: !0 }
		};
		e.queue.splice(1 + i, 0, a), L(e, {
			kind: "tianyi-extra",
			seat: t,
			target: n
		});
	});
}, In = { tianyi: Mn }, Ln = { tianyi: Nn }, Rn = { tianyi: Pn }, zn = { "tianyi-extra": Fn }, Bn = (e, t, n, r) => {
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "jieming",
			min: 1,
			max: 1,
			data: {
				...r,
				re: n === "re_jieming",
				candidates: z(e)
			}
		}
	};
}, Vn = (e, t, n, r, i) => {
	let a = i.filter((t) => e.seats[t].hp > n.hp && e.hands[t].length > 0);
	return r >= 1 && a.length > 0 ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, Hn = (e, t, n, r, i, a, o) => (e.pending = {
	kind: "skill-cards",
	seats: [i[0]],
	ctx: {
		skill: "quhu",
		min: 1,
		max: 1,
		data: {
			from: t,
			myCard: r[0]
		}
	}
}, {
	state: e,
	fx: o
}), Un = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from;
	if (Z_(e, l, t, r.myCard, Q_(e, l, t) ?? i[0], "quhu", c)) {
		let n = px(e, t, !1);
		if (n.length === 0) {
			L(e, {
				kind: "quhu-nowolf",
				seat: t
			});
			return;
		}
		e.pending = {
			kind: "skill-seats",
			seats: [l],
			ctx: {
				skill: "quhu-damage",
				min: 1,
				max: 1,
				data: {
					candidates: n,
					source: t
				}
			}
		};
	} else e.queue.unshift({
		k: "damage",
		source: t,
		target: l,
		amount: 1,
		nature: "normal",
		reason: "quhu",
		cardId: null
	});
}, Wn = (e, t, n, r, i) => {
	for (let n of i) W(e, t, n);
	U(e, i), F(e, t, i.length), L(e, {
		kind: "discard",
		seat: t,
		n: i.length,
		cards: R(e, i)
	}), e.beatMs = J.discard;
}, Gn = (e, t, n, r, i) => {
	let a = r.source;
	e.queue.unshift({
		k: "damage",
		source: a,
		target: i[0],
		amount: 1,
		nature: "normal",
		reason: "quhu",
		cardId: null
	}), e.beatMs = J.play;
}, Kn = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = Math.min(e.seats[l].maxHp, 5);
	if (r.re === !0) {
		let i = H(e, l, u);
		c.push({
			kind: "draw",
			rid: e.seats[l].rid,
			data: {
				seat: l,
				n: i.length
			},
			for: [e.seats[l].rid],
			secret: { cards: i }
		}), L(e, {
			kind: "jieming",
			seat: t,
			target: l,
			n: i.length
		}), e.beatMs = J.draw;
		let a = e.hands[l].length - u;
		if (a > 0) {
			e.queue.unshift({
				k: "jieming-next",
				seat: t,
				data: r
			}), e.pending = {
				kind: "skill-cards",
				seats: [l],
				ctx: {
					skill: "jieming-drop",
					min: a,
					max: a,
					data: {}
				}
			};
			return;
		}
		$_(e, t, n, r);
		return;
	}
	let d = u - e.hands[l].length;
	if (d > 0) {
		let n = H(e, l, d);
		c.push({
			kind: "draw",
			rid: e.seats[l].rid,
			data: {
				seat: l,
				n: n.length
			},
			for: [e.seats[l].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "jieming",
			seat: t,
			target: l,
			n: n.length
		}), e.beatMs = J.draw;
	} else L(e, {
		kind: "jieming",
		seat: t,
		target: l,
		n: 0
	});
	$_(e, t, n, r);
}, qn = {
	jieming: Bn,
	re_jieming: Bn
}, Jn = { quhu: Vn }, Yn = { quhu: Hn }, Xn = {
	quhu: Un,
	"jieming-drop": Wn
}, Zn = {
	"quhu-damage": Gn,
	jieming: Kn
}, Qn = (e, t, n, r, i) => {
	nt(e, t, "shuangxiong", {}, i);
}, $n = (e, t, n, r, i, a, o, s, c) => {
	if (i.length === 1) {
		let n = i[0];
		Qv(e, t, [n], c);
		let r = G(e, n);
		e.seats[t].flags[r ? "shuangxiongRed" : "shuangxiongBlack"] = !0, L(e, {
			kind: r ? "shuangxiong-red" : "shuangxiong-black",
			seat: t,
			cards: R(e, [n])
		}), e.beatMs = J.discard;
	}
	Db(e, t);
}, er = { shuangxiong: Qn }, tr = { "shuangxiong-jie": $n }, nr = (e, t) => {
	let n = /* @__PURE__ */ new Map();
	for (let r of e.hands[t]) {
		let t = e.cards[r].suit;
		n.set(t, (n.get(t) ?? 0) + 1);
	}
	return [...n.values()].some((e) => e >= 2) ? {
		minCards: 2,
		maxCards: 2,
		minTargets: 0,
		maxTargets: 0,
		targets: [],
		sameSuit: !0
	} : null;
}, rr = (e, t, n) => n.identity === "lord" && (n.marks.yi ?? 0) > 0 ? {
	minCards: 0,
	maxCards: 0,
	minTargets: 0,
	maxTargets: 0,
	targets: []
} : null, ir = (e, t, n, r, i, a, o) => {
	for (let n of r) W(e, t, n);
	U(e, r), Fv(e, r[0], "archery_attack", t, Lv(e, t, "archery_attack", null)), o.push({
		kind: "play",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: r[0],
			name: "archery_attack"
		}
	}), L(e, {
		kind: "use",
		seat: t,
		card: "archery_attack"
	}), L(e, {
		kind: "luanji",
		seat: t
	}), e.beatMs = J.play, xv(e, t, o), F(e, t, 2);
	let s = B(e, t).filter((e) => e !== t), c = z(e).find((t) => Y(e, t, "fenwei") && !e.seats[t].limitedUsed.includes("fenwei")), l = {
		suit: e.cards[r[0]].suit,
		cardId: null
	};
	return n === "re_luanji" && s.length >= 2 ? (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "luanji-reduce",
			min: 0,
			max: 1,
			data: {
				candidates: s,
				allTargets: s,
				info: l
			}
		}
	}, {
		state: e,
		fx: o
	}) : c != null && s.length >= 2 ? (e.pending = {
		kind: "skill-ask",
		seats: [c],
		ctx: {
			skill: "fenwei",
			data: {
				name: "archery_attack",
				from: t,
				targets: s,
				...l
			}
		}
	}, {
		state: e,
		fx: o
	}) : (nv(e, "archery_attack", t, [], o, l), Z(e, o), {
		state: e,
		fx: o
	});
}, ar = (e, t, n, r, i, a, o) => {
	e.seats[t].marks.yi = (e.seats[t].marks.yi ?? 0) - 1;
	let s = H(e, t, 1);
	return o.push({
		kind: "draw",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: s.length
		},
		for: [e.seats[t].rid],
		secret: { cards: s }
	}), L(e, {
		kind: "xueyi",
		seat: t,
		n: s.length
	}), e.beatMs = J.draw, P(e, t, s), {
		state: e,
		fx: o
	};
}, or = (e, t, n, r, i, a, o, s, c) => {
	let l = r.allTargets.filter((t) => !i.includes(t) && e.seats[t].alive), u = r.info, d = z(e).find((t) => Y(e, t, "fenwei") && !e.seats[t].limitedUsed.includes("fenwei"));
	if (d != null && l.length >= 2) {
		e.pending = {
			kind: "skill-ask",
			seats: [d],
			ctx: {
				skill: "fenwei",
				data: {
					name: "archery_attack",
					from: t,
					targets: l,
					...u
				}
			}
		};
		return;
	}
	nv(e, "archery_attack", t, r.allTargets.filter((e) => i.includes(e)), c, u);
}, sr = {
	luanji: nr,
	re_luanji: nr,
	re_xueyi: rr
}, cr = {
	luanji: ir,
	re_luanji: ir,
	re_xueyi: ar
}, lr = { "luanji-reduce": or }, ur = {
	...wn,
	...kn,
	...qn,
	...er
}, dr = {
	...Tn,
	...An
}, fr = {
	...vn,
	...In,
	...Jn,
	...sr
}, pr = {
	...yn,
	...Ln,
	...Yn,
	...cr
}, mr = { ...jn }, hr = {
	...bn,
	...Rn,
	...Xn,
	...tr
}, gr = {
	...zn,
	...Zn,
	...lr
}, _r = (e, t, n, r) => {
	let i = z(e).filter((e) => e !== t);
	i.length !== 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "fangzhu",
			min: 1,
			max: 1,
			data: {
				...r,
				re: n === "re_fangzhu",
				candidates: i
			}
		}
	});
}, vr = (e, t, n, r, i) => {
	let a = r.lord;
	if (e.seats[a].alive) {
		let n = H(e, a, 1);
		i.push({
			kind: "draw",
			rid: e.seats[a].rid,
			data: {
				seat: a,
				n: 1
			},
			for: [e.seats[a].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "songwei",
			seat: a,
			target: t
		}), e.beatMs = J.draw;
	}
}, yr = (e, t, n, r) => {
	U(e, r.cards ?? []);
}, br = (e, t, n, r, i, a, o, s) => {
	let c = i.cards ?? [];
	return n.option === "xs-obtain" && c.length > 0 ? (e.hands[t].push(...c), s.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: i.dead,
			to: t,
			n: c.length
		},
		for: [e.seats[t].rid],
		secret: { cards: c }
	}), L(e, {
		kind: "xingshang",
		seat: t,
		target: i.dead,
		n: c.length
	})) : (U(e, c), e.seats[t].hp < e.seats[t].maxHp && (e.seats[t].hp += 1, s.push({
		kind: "recover",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: t,
		n: 1
	}), X(e, t))), Z(e, s), {
		state: e,
		fx: s
	};
}, xr = (e, t, n, r, i, a, o, s) => {
	let c = i.x, l = i.from;
	if (n.option === "drop-lose") return e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "fangzhu-drop",
			min: Math.min(c, e.hands[t].length + K(e, t).length),
			max: c,
			data: {
				pool: [...e.hands[t], ...K(e, t)],
				from: l,
				chain: i.chain
			}
		}
	}, {
		state: e,
		fx: s
	};
	if (c > 0) {
		let n = H(e, t, c);
		s.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		});
	}
	return L(e, {
		kind: "fangzhu",
		seat: l,
		target: t,
		n: c
	}), Jv(e, t, s), e.queue.unshift({
		k: "fangzhu-next",
		seat: l,
		data: i.chain ?? {}
	}), e.pending || Z(e, s), {
		state: e,
		fx: s
	};
}, Sr = (e, t, n, r, i, a, o, s, c) => {
	let l = [], u = 0;
	for (let n of i) if (e.hands[t].includes(n)) W(e, t, n), u += 1;
	else {
		for (let r of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[r] === n && (e.seats[t].equips[r] = null);
		l.push(n);
	}
	U(e, i), u > 0 && F(e, t, u);
	for (let n of l) I(e, t, n, c);
	L(e, {
		kind: "discard",
		seat: t,
		n: i.length,
		cards: R(e, i)
	}), e.beatMs = J.discard, e.queue.unshift({
		k: "fangzhu-next",
		seat: r.from,
		data: r.chain ?? {}
	}), Ly(e, t, 1, c);
}, Cr = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = e.seats[t].maxHp - e.seats[t].hp;
	if (r.re === !0) {
		let n = e.hands[l].length + K(e, l).length;
		e.pending = {
			kind: "skill-ask",
			seats: [l],
			ctx: {
				skill: "fangzhu-choice",
				options: u > 0 && n >= u ? ["draw-flip", "drop-lose"] : ["draw-flip"],
				noPass: !0,
				data: {
					from: t,
					x: u,
					chain: r
				}
			}
		};
		return;
	}
	if (L(e, {
		kind: "fangzhu",
		seat: t,
		target: l,
		n: u
	}), u > 0) {
		let t = H(e, l, u);
		c.push({
			kind: "draw",
			rid: e.seats[l].rid,
			data: {
				seat: l,
				n: t.length
			},
			for: [e.seats[l].rid],
			secret: { cards: t }
		});
	}
	Jv(e, l, c), e.queue.unshift({
		k: "fangzhu-next",
		seat: t,
		data: r
	});
}, wr = {
	fangzhu: _r,
	re_fangzhu: _r,
	songwei: vr
}, Tr = { "xingshang-jie": yr }, Er = {
	"xingshang-jie": br,
	"fangzhu-choice": xr
}, Dr = { "fangzhu-drop": Sr }, Or = { fangzhu: Cr }, kr = (e, t, n, r, i) => {
	nt(e, t, "baonue", r, i);
}, Ar = (e, t, n, r, i, a, o, s) => (L(e, {
	kind: "skill",
	seat: t,
	card: r
}), n.option === "maxhp" ? (--e.seats[t].maxHp, e.seats[t].hp = Math.min(e.seats[t].hp, e.seats[t].maxHp), L(e, {
	kind: "benghuai-max",
	seat: t
}), e.beatMs = J.damage) : Ly(e, t, 1, s), e.pending || Z(e, s), {
	state: e,
	fx: s
}), jr = { baonue: kr }, Mr = { benghuai: Ar }, Nr = (e, t) => {
	let n = z(e).filter((n) => n !== t && !N(e, n));
	n.length > 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "luanwu-jie-target",
			min: 1,
			max: 1,
			data: { candidates: n }
		}
	});
}, Pr = (e, t, n, r, i) => n.limitedUsed.includes("luanwu") || n.limitedUsed.includes("re_luanwu") || i.length === 0 ? null : {
	minCards: 0,
	maxCards: 0,
	minTargets: 0,
	maxTargets: 0,
	targets: []
}, Fr = (e, t, n, r, i, a, o) => (e.seats[t].limitedUsed.push(n), e.queue.unshift({
	k: "luanwu-step",
	seats: B(e, t).filter((e) => e !== t),
	from: t
}), Z(e, o), {
	state: e,
	fx: o
}), Ir = (e, t, n, r, i, a, o, s, c) => {
	let l = z(e).filter((n) => n !== t && !N(e, n));
	if (i.length === 0 || l.length === 0) {
		Ly(e, t, 1, c);
		return;
	}
	let u = Math.min(...l.map((n) => V(e, t, n))), d = l.filter((n) => V(e, t, n) === u);
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "luanwu-target",
			min: 1,
			max: 1,
			data: {
				candidates: d,
				card: i[0]
			}
		}
	};
}, Lr = (e, t, n, r, i, a, o, s, c) => {
	c.push({
		kind: "play",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			name: "slash"
		}
	}), e.queue.unshift({
		k: "slash-target",
		from: t,
		target: i[0],
		cardName: "slash",
		suit: null,
		cardId: null
	});
}, Rr = (e, t, n, r, i, a, o, s, c) => {
	let l = r.card;
	W(e, t, l), U(e, [l]);
	let u = e.cards[l].name;
	Fv(e, l, u, t, [i[0]]), c.push({
		kind: "play",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: l,
			name: u
		}
	}), L(e, {
		kind: "use",
		seat: t,
		card: u,
		target: i[0],
		cards: R(e, [l])
	}), G(e, l) && vv(e, t, c), F(e, t, 1), e.queue.unshift({
		k: "slash-target",
		from: t,
		target: i[0],
		cardName: u,
		suit: e.cards[l].suit,
		cardId: l
	});
}, zr = { "luanwu-jie": Nr }, Br = {
	luanwu: Pr,
	re_luanwu: Pr
}, Vr = {
	luanwu: Fr,
	re_luanwu: Fr
}, Hr = { "luanwu-slash": Ir }, Ur = {
	"luanwu-jie-target": Lr,
	"luanwu-target": Rr
}, Wr = (e, t, n, r, i) => {
	let a = e.seats[t];
	a.flags.haoshiDrawn = !0;
	let o = H(e, t, 4 + +!!Y(e, t, "yingzi"));
	i.push({
		kind: "draw",
		rid: a.rid,
		data: {
			seat: t,
			n: o.length
		},
		for: [a.rid],
		secret: { cards: o }
	}), L(e, {
		kind: "draw",
		seat: t,
		n: o.length
	}), e.beatMs = J.draw, Db(e, t);
}, Gr = (e, t, n, r, i) => i.length >= 2 ? {
	minCards: 0,
	maxCards: r,
	minTargets: 2,
	maxTargets: 2,
	targets: i
} : null, Kr = (e, t, n, r, i, a, o) => {
	let [s, c] = i;
	for (let n of r) W(e, t, n);
	U(e, r);
	let l = e.hands[s], u = e.hands[c];
	return e.hands[s] = u, e.hands[c] = l, o.push({
		kind: "give",
		rid: e.seats[s].rid,
		data: {
			from: s,
			to: c,
			n: l.length
		},
		for: [e.seats[s].rid, e.seats[c].rid],
		secret: { cards: l }
	}), o.push({
		kind: "give",
		rid: e.seats[c].rid,
		data: {
			from: c,
			to: s,
			n: u.length
		},
		for: [e.seats[s].rid, e.seats[c].rid],
		secret: { cards: u }
	}), L(e, {
		kind: "dimeng",
		seat: t,
		target: s,
		n: r.length
	}), e.beatMs = J.play, F(e, t, r.length), F(e, s, l.length), F(e, c, u.length), {
		state: e,
		fx: o
	};
}, qr = (e, t, n, r, i, a, o, s, c) => {
	let l = r.target;
	for (let n of i) W(e, t, n);
	e.hands[l].push(...i), c.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: l,
			n: i.length
		},
		for: [e.seats[t].rid, e.seats[l].rid],
		secret: { cards: i }
	}), L(e, {
		kind: "haoshi",
		seat: t,
		target: l,
		n: i.length
	});
}, Jr = (e, t, n, r, i) => {
	let a = Math.floor(e.hands[t].length / 2);
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "haoshi-give",
			min: a,
			max: a,
			data: { target: i[0] }
		}
	};
}, Yr = { haoshi: Wr }, Xr = { dimeng: Gr }, Zr = { dimeng: Kr }, Qr = { "haoshi-give": qr }, $r = { haoshi: Jr }, ei = (e, t, n, r, i) => {
	let a = e.seats[t], o = a.maxHp - a.hp, s = [];
	for (let t = 0; t < o; t++) {
		e.deck.length === 0 && e.discard.length > 0 && (e.deck = Pv(e, e.discard), e.discard = []);
		let t = e.deck.shift();
		if (t == null) break;
		s.push(t);
	}
	if (s.length === 0) return;
	let c = s.filter((t) => e.cards[t].suit === "heart"), l = s.filter((t) => e.cards[t].suit !== "heart");
	for (let e of s) i.push({
		kind: "reveal",
		rid: a.rid,
		data: {
			seat: t,
			card: e
		}
	});
	e.hands[t].push(...l), l.length > 0 && i.push({
		kind: "draw",
		rid: a.rid,
		data: {
			seat: t,
			n: l.length
		},
		for: [a.rid],
		secret: { cards: l }
	}), c.length > 0 && (U(e, c), a.hp = Math.min(a.maxHp, a.hp + c.length), i.push({
		kind: "recover",
		rid: a.rid,
		data: {
			seat: t,
			n: c.length
		}
	}), X(e, t)), L(e, {
		kind: "zaiqi",
		seat: t,
		n: c.length
	}), e.beatMs = J.recover;
}, ti = (e, t, n, r, i, a, o, s) => {
	let c = i.lord;
	if (n.option === "heal" && e.seats[c].alive && e.seats[c].hp < e.seats[c].maxHp) e.seats[c].hp += 1, s.push({
		kind: "recover",
		rid: e.seats[c].rid,
		data: {
			seat: c,
			n: 1
		}
	}), L(e, {
		kind: "zaiqi",
		seat: c,
		target: t
	}), X(e, c), e.beatMs = J.recover;
	else {
		let n = H(e, t, 1);
		s.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "zaiqi",
			n: 1
		}), e.beatMs = J.draw;
	}
	return Z(e, s), {
		state: e,
		fx: s
	};
}, ni = (e, t, n, r, i) => {
	let a = i.map((e) => ({
		seat: e,
		skill: "zaiqi-jie-choice",
		options: ["draw", "heal"],
		noPass: !0,
		data: { lord: t }
	}));
	a.length > 0 && e.queue.unshift({
		k: "trigger-queue",
		list: a
	});
}, ri = { zaiqi: ei }, ii = { "zaiqi-jie-choice": ti }, ai = { "zaiqi-jie": ni }, oi = (e, t) => {
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "yinghun",
			min: 1,
			max: 1,
			data: { candidates: z(e).filter((e) => e !== t) }
		}
	};
}, si = (e, t, n, r, i, a, o, s) => {
	let c = i.target, l = e.seats[t].maxHp - e.seats[t].hp;
	if (!e.seats[c].alive) return Z(e, s), {
		state: e,
		fx: s
	};
	L(e, {
		kind: "yinghun",
		seat: t,
		target: c,
		n: l
	});
	let u = n.option === "draw-one" ? 1 : l, d = n.option === "draw-one" ? l : 1, f = H(e, c, u);
	s.push({
		kind: "draw",
		rid: e.seats[c].rid,
		data: {
			seat: c,
			n: f.length
		},
		for: [e.seats[c].rid],
		secret: { cards: f }
	});
	let p = Math.min(d, e.hands[c].length);
	return p > 0 ? (e.pending = {
		kind: "discard",
		seats: [c],
		ctx: {
			count: p,
			skill: "yinghun"
		}
	}, {
		state: e,
		fx: s
	}) : (Z(e, s), {
		state: e,
		fx: s
	});
}, ci = (e, t, n, r, i, a, o, s) => {
	let c = parseInt(n.option, 10);
	if (!Number.isInteger(c) || c < 1) return q("games.sanguosha.error.badChoose");
	e.seats[t].limitedUsed.push("wulie");
	let l = z(e).filter((e) => e !== t);
	return l.length < c ? q("games.sanguosha.error.badChoose") : (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "wulie-targets",
			min: c,
			max: c,
			data: {
				candidates: l,
				x: c
			}
		}
	}, {
		state: e,
		fx: s
	});
}, li = (e, t, n, r, i) => {
	let a = e.seats[t].maxHp - e.seats[t].hp;
	e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "yinghun-mode",
			options: ["draw-one", "draw-x"],
			data: {
				target: i[0],
				x: a
			}
		}
	};
}, ui = (e, t, n, r, i, a, o, s, c) => {
	let l = r.x;
	for (let t of i) e.seats[t].marks.lie = (e.seats[t].marks.lie ?? 0) + 1;
	L(e, {
		kind: "wulie",
		seat: t,
		n: l
	}), Ly(e, t, l, c);
}, di = { yinghun: oi }, fi = {
	"yinghun-mode": si,
	"wulie-x": ci
}, pi = {
	yinghun: li,
	"wulie-targets": ui
}, mi = (e, t) => {
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "jiezi",
			min: 1,
			max: 1,
			data: { candidates: z(e) }
		}
	};
}, hi = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = Math.min(...z(e).map((t) => e.hands[t].length));
	if (e.hands[l].length === u && !(e.seats[l].marks.zi ?? 0)) e.seats[l].marks.zi = 1, L(e, {
		kind: "jiezi-mark",
		seat: t,
		target: l
	});
	else {
		let t = H(e, l, 1);
		c.push({
			kind: "draw",
			rid: e.seats[l].rid,
			data: {
				seat: l,
				n: t.length
			},
			for: [e.seats[l].rid],
			secret: { cards: t }
		}), L(e, {
			kind: "skill-draw",
			seat: l,
			card: "jiezi",
			n: t.length
		});
	}
}, gi = { "jiezi-mark": mi }, _i = { jiezi: hi }, vi = (e, t, n, r) => {
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "lieren",
			min: 0,
			max: 1,
			data: {
				pool: [...e.hands[t]],
				target: r.target
			}
		}
	};
}, yi = (e, t, n, r, i) => {
	if (n.flags.tianyiLose || n.flags.xianzhenLose || n.flags.jcNoSlash || e.turn == null || e.turn.seat !== t || e.turn.slashUsed >= Hv(e, t)) return null;
	let a = i.filter((t) => !N(e, t));
	return r >= 1 && a.length > 0 ? {
		minCards: 1,
		maxCards: r,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, bi = (e, t, n, r, i, a, o) => {
	let s = i[0];
	for (let n of r) W(e, t, n);
	return U(e, r), e.seats[t].flags.cbPending = r.length, Fv(e, r[0], "slash", t, [s]), o.push({
		kind: "play",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: r[0],
			name: "slash"
		}
	}), L(e, {
		kind: "use",
		seat: t,
		card: "slash",
		target: s,
		cards: R(e, r)
	}), e.beatMs = J.play, F(e, t, r.length), e.turn.slashUsed += 1, e.queue.unshift({
		k: "slash-target",
		from: t,
		target: s,
		cardName: "slash",
		suit: null,
		cardId: null
	}), Z(e, o), {
		state: e,
		fx: o
	};
}, xi = (e, t, n, r, i) => {
	if (i.length === 0) return;
	let a = r.target;
	e.seats[a].alive && e.hands[a].length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [a],
		ctx: {
			skill: "lieren-target",
			min: 1,
			max: 1,
			data: {
				pool: [...e.hands[a]],
				from: t,
				myCard: i[0]
			}
		}
	});
}, Si = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from;
	if (Z_(e, l, t, r.myCard, Q_(e, l, t) ?? i[0], "lieren", c) && e.seats[l].alive && fx(e, t)) {
		let n, r = !1;
		if (e.hands[t].length > 0) n = e.hands[t][Nv(e, e.hands[t].length)], W(e, t, n), r = !0;
		else if (n = K(e, t)[0], n != null) {
			for (let r of [
				"weapon",
				"armor",
				"off_horse",
				"def_horse"
			]) e.seats[t].equips[r] === n && (e.seats[t].equips[r] = null);
			I(e, t, n, c);
		}
		n != null && (e.hands[l].push(n), L(e, {
			kind: "lieren-take",
			seat: l,
			target: t
		})), r && (Cv(e, t), cv(e, t));
	}
}, Ci = { lieren: vi }, wi = { changbiao: yi }, Ti = { changbiao: bi }, Ei = {
	lieren: xi,
	"lieren-target": Si
}, Di = {
	...wr,
	...jr,
	...zr,
	...Yr,
	...ri,
	...di,
	...gi,
	...Ci
}, Oi = { ...Tr }, ki = {
	...Br,
	...Xr,
	...wi
}, Ai = {
	...Vr,
	...Zr,
	...Ti
}, ji = {
	...Er,
	...Mr,
	...ii,
	...fi
}, Mi = {
	...Dr,
	...Hr,
	...Qr,
	...Ei
}, Ni = {
	...Or,
	...Ur,
	...$r,
	...ai,
	...pi,
	..._i
}, Pi = (e, t, n, r, i) => {
	let a = r.ev;
	if (n === "re_beige") {
		if (!e.seats[a.target].alive || !fx(e, t)) {
			e.queue.unshift({
				k: "beige-next",
				ev: a
			});
			return;
		}
		nt(e, a.target, "beige-jie", {
			ev: a,
			by: t
		}, i);
		return;
	}
	let o = [...e.hands[t], ...K(e, t)];
	if (o.length === 0) {
		e.queue.unshift({
			k: "beige-next",
			ev: a
		});
		return;
	}
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "beige-discard",
			min: 1,
			max: 1,
			data: {
				pool: o,
				ev: a
			}
		}
	};
}, Fi = (e, t, n, r) => {
	e.queue.unshift({
		k: "beige-next",
		ev: r.ev
	});
}, Ii = (e, t, n, r, i, a, o, s, c) => {
	let l = r.ev, u = i[0];
	if (W(e, t, u)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === u && (e.seats[t].equips[n] = null);
		I(e, t, u, c);
	}
	U(e, [u]), L(e, {
		kind: "beige",
		seat: t,
		target: l.target
	}), e.beatMs = J.play, e.seats[l.target].alive ? nt(e, l.target, "beige", { ev: l }, c) : e.queue.unshift({
		k: "beige-next",
		ev: l
	});
}, Li = (e, t, n, r, i, a, o, s, c) => {
	let l = 0;
	for (let n of i) if (W(e, t, n)) l += 1;
	else {
		for (let r of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[r] === n && (e.seats[t].equips[r] = null);
		I(e, t, n, c);
	}
	U(e, i), F(e, t, l), L(e, {
		kind: "discard",
		seat: t,
		n: i.length,
		cards: R(e, i)
	}), e.beatMs = J.discard;
}, Ri = (e, t, n, r, i, a, o, s, c) => {
	let l = r.ev, u = r.judgeCard, d = r.js, f = r.jp;
	if (e.queue.unshift({
		k: "beige-next",
		ev: l
	}), i.length === 0) {
		rt(e, l.target, u);
		return;
	}
	let p = i[0];
	if (W(e, t, p)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === p && (e.seats[t].equips[n] = null);
		I(e, t, p, c);
	}
	if (U(e, [p]), L(e, {
		kind: "beige",
		seat: t,
		target: l.target
	}), e.beatMs = J.play, d === "heart") {
		let t = l.target;
		e.seats[t].alive && e.seats[t].hp < e.seats[t].maxHp && (e.seats[t].hp += 1, c.push({
			kind: "recover",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: 1
			}
		}), L(e, {
			kind: "recover",
			seat: t,
			n: 1
		}), X(e, t));
	} else if (d === "diamond") {
		let t = l.target;
		if (e.seats[t].alive) {
			let n = H(e, t, 2);
			c.push({
				kind: "draw",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					n: n.length
				},
				for: [e.seats[t].rid],
				secret: { cards: n }
			}), L(e, {
				kind: "skill-draw",
				seat: t,
				card: "beige",
				n: n.length
			});
		}
	} else if (l.source != null && e.seats[l.source].alive) {
		if (d === "spade") Jv(e, l.source, c);
		else {
			let t = [...e.hands[l.source], ...K(e, l.source)];
			t.length > 0 && (e.queue.unshift({
				k: "beige-next",
				ev: l
			}), e.pending = {
				kind: "skill-cards",
				seats: [l.source],
				ctx: {
					skill: "beige-drop",
					min: Math.min(2, t.length),
					max: Math.min(2, t.length),
					data: { pool: t }
				}
			});
		}
	}
	e.cards[p].point === f && e.discard.includes(p) && (e.discard = e.discard.filter((e) => e !== p), e.hands[t].push(p), c.push({
		kind: "take",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			from: -1
		},
		for: [e.seats[t].rid],
		secret: { card: p }
	})), e.cards[p].suit === d ? (e.hands[t].push(u), c.push({
		kind: "take",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			from: -1
		},
		for: [e.seats[t].rid],
		secret: { card: u }
	})) : rt(e, l.target, u);
}, zi = {
	beige: Pi,
	re_beige: Pi
}, Bi = {
	beige: Fi,
	re_beige: Fi
}, Vi = {
	"beige-discard": Ii,
	"beige-drop": Li,
	"beige-jie-discard": Ri
}, Hi = { tuntian: (e, t, n, r, i) => {
	nt(e, t, "tuntian", {}, i);
} }, Ui = (e, t, n, r, i) => {
	if (e.hands[t].filter((t) => k(e.cards[t].name) != null).length === 0) return null;
	let a = i.filter((t) => {
		let n = e.seats[t].equips;
		return n.weapon == null || n.armor == null || n.off_horse == null || n.def_horse == null;
	});
	return a.length > 0 ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, Wi = (e, t, n, r, i) => e.hands[t].filter((t) => k(e.cards[t].name) != null).length === 0 || i.length === 0 ? null : {
	minCards: 1,
	maxCards: 1,
	minTargets: 1,
	maxTargets: 1,
	targets: i
}, Gi = (e, t, n, r, i, a, o) => {
	let s = i[0], c = r[0], l = k(e.cards[c].name), u = e.seats[s].equips[l];
	if (u != null) {
		if (n !== "re_zhijian") return q("games.sanguosha.error.badSkill");
		e.seats[s].equips[l] = null, U(e, [u]), I(e, s, u, o);
	}
	W(e, t, c), e.seats[s].equips[l] = c, o.push({
		kind: "equip",
		rid: e.seats[s].rid,
		data: {
			seat: s,
			card: c,
			name: e.cards[c].name,
			slot: l
		}
	}), L(e, {
		kind: "zhijian",
		seat: t,
		target: s
	}), e.beatMs = J.equip, F(e, t, 1);
	let d = H(e, t, 1);
	return o.push({
		kind: "draw",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: d.length
		},
		for: [e.seats[t].rid],
		secret: { cards: d }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "zhijian",
		n: d.length
	}), P(e, t, d), {
		state: e,
		fx: o
	};
}, Ki = (e, t, n, r, i, a, o, s, c) => {
	let l = r.pool, u = r.seat, d = i[0];
	d != null && l.includes(d) && e.discard.includes(d) && e.seats[u].alive && (e.discard = e.discard.filter((e) => e !== d), e.hands[u].push(d), c.push({
		kind: "take",
		rid: e.seats[u].rid,
		data: { seat: u },
		for: [e.seats[u].rid],
		secret: { card: d }
	}), L(e, {
		kind: "guzheng-back",
		seat: t,
		target: u,
		cards: R(e, [d])
	}));
	let f = l.filter((t) => t !== d && e.discard.includes(t));
	f.length > 0 && (e.discard = e.discard.filter((e) => !f.includes(e)), e.hands[t].push(...f), c.push({
		kind: "take",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: f.length
		},
		for: [e.seats[t].rid],
		secret: { cards: f }
	}), L(e, {
		kind: "guzheng",
		seat: t,
		n: f.length,
		cards: R(e, f)
	}), e.beatMs = J.draw, P(e, t, f));
}, qi = {
	zhijian: Ui,
	re_zhijian: Wi
}, Ji = {
	zhijian: Gi,
	re_zhijian: Gi
}, Yi = { guzheng: Ki }, Xi = (e, t, n, r, i) => {
	let a = i.filter((n) => V(e, n, t) <= Bv(e, n));
	return a.length > 0 ? {
		minCards: 0,
		maxCards: 0,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, Zi = (e, t, n, r, i, a, o) => {
	e.seats[t].flags.tx2 && (e.seats[t].flags.txU = !0);
	let s = i[0], c = e.hands[s].filter((t) => A(e.cards[t].name) || hy(e, s, t).includes("slash"));
	return c.length > 0 && !N(e, t) ? (e.pending = {
		kind: "skill-cards",
		seats: [s],
		ctx: {
			skill: "tiaoxin-slash",
			min: 0,
			max: 1,
			data: {
				pool: c,
				from: t
			}
		}
	}, {
		state: e,
		fx: o
	}) : (Y(e, t, "re_tiaoxin") && (e.seats[t].flags.tx2 = !0), et(e, s, "dismantlement", !1).length > 0 && (e.pending = {
		kind: "pick-zone",
		seats: [t],
		ctx: {
			trick: "dismantlement",
			from: t,
			target: s,
			allowJudge: !1
		}
	}), {
		state: e,
		fx: o
	});
}, Qi = (e, t, n, r, i, a, o, s) => {
	if (L(e, {
		kind: "skill",
		seat: t,
		card: r
	}), n.option === "recover") e.seats[t].hp += 1, s.push({
		kind: "recover",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: t,
		n: 1
	}), X(e, t);
	else {
		let n = H(e, t, 2);
		s.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "zhiji",
			n: n.length
		});
	}
	return e.beatMs = J.recover, Z(e, s), {
		state: e,
		fx: s
	};
}, $i = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from;
	if (i.length === 1) {
		let n = i[0];
		W(e, t, n), U(e, [n]);
		let r = A(e.cards[n].name) ? e.cards[n].name : "slash";
		Fv(e, n, r, t, [l]), c.push({
			kind: "play",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				card: n,
				name: r
			}
		}), L(e, {
			kind: "use",
			seat: t,
			card: r,
			target: l,
			cards: R(e, [n])
		}), G(e, n) && vv(e, t, c), F(e, t, 1), Y(e, l, "re_tiaoxin") && e.queue.unshift({
			k: "tiaoxin-check",
			from: l,
			target: t,
			dmg0: e.turn?.dmg[l] ?? 0
		}), e.queue.unshift({
			k: "slash-target",
			from: t,
			target: l,
			cardName: r,
			suit: e.cards[n].suit,
			cardId: n
		}), e.beatMs = J.play;
	} else Y(e, l, "re_tiaoxin") && (e.seats[l].flags.tx2 = !0), e.seats[l].alive && et(e, t, "dismantlement", !1).length > 0 && (e.pending = {
		kind: "pick-zone",
		seats: [l],
		ctx: {
			trick: "dismantlement",
			from: l,
			target: t,
			allowJudge: !1
		}
	});
}, ea = {
	tiaoxin: Xi,
	re_tiaoxin: Xi
}, ta = {
	tiaoxin: Zi,
	re_tiaoxin: Zi
}, na = { zhiji: Qi }, ra = { "tiaoxin-slash": $i }, ia = (e, t) => {
	let n = e.seats[t];
	n.flags.fangquanSkip = !0, e.skipPlay = !0;
}, aa = () => {}, oa = (e, t, n, r, i, a, o, s, c) => {
	let l = r.info;
	i.length === 1 ? (W(e, t, i[0]), U(e, i), L(e, {
		kind: "xiangle",
		seat: t,
		target: l.target
	}), F(e, t, 1), He(e, l, c)) : (L(e, {
		kind: "xiangle-null",
		seat: l.target
	}), e.beatMs = J.respond);
}, sa = (e, t, n, r, i) => {
	if (i.length === 0) return;
	let a = i[0];
	W(e, t, a), U(e, [a]), L(e, {
		kind: "discard",
		seat: t,
		n: 1,
		cards: R(e, [a])
	}), F(e, t, 1), e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "fangquan-target",
			min: 1,
			max: 1,
			data: { candidates: z(e).filter((e) => e !== t) }
		}
	};
}, ca = (e, t, n, r, i) => {
	e.extraTurn = i[0], L(e, {
		kind: "fangquan",
		seat: t,
		target: i[0]
	});
}, la = { fangquan: ia }, ua = { fangquan: aa }, da = {
	xiangle: oa,
	fangquan: sa
}, fa = { "fangquan-target": ca }, pa = (e, t, n, r, i) => {
	let a = e.seats[t], o = r.cards.filter((t) => e.discard.includes(t));
	o.length > 0 && (e.discard = e.discard.filter((e) => !o.includes(e)), e.hands[t].push(...o), i.push({
		kind: "take",
		rid: a.rid,
		data: {
			seat: t,
			n: o.length
		},
		for: [a.rid],
		secret: { cards: o }
	}), L(e, {
		kind: "zhiba-obtain",
		seat: t,
		n: o.length
	}), e.beatMs = J.draw);
}, ma = (e, t, n, r, i) => {
	let a = e.seats[t], o = r.card, s = e.discard.indexOf(o);
	s >= 0 && (e.discard.splice(s, 1), e.hands[t].push(o), i.push({
		kind: "take",
		rid: a.rid,
		data: {
			seat: t,
			n: 1
		},
		for: [a.rid],
		secret: { cards: [o] }
	}), L(e, {
		kind: "jiang-obtain",
		seat: t,
		cards: R(e, [o])
	})), Ly(e, t, 1, i);
}, ha = (e, t, n, r, i, a, o) => {
	let s = i[0], c = e.seats[s].identity === "lord" && Y(e, s, "re_zhiba");
	return e.pending = {
		kind: "skill-cards",
		seats: [s],
		ctx: {
			skill: "zhiba",
			min: +!c,
			max: 1,
			data: {
				from: t,
				myCard: r[0]
			}
		}
	}, {
		state: e,
		fx: o
	};
}, ga = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from;
	if (i.length === 0) {
		L(e, {
			kind: "zhiba-refuse",
			seat: t,
			target: l
		});
		return;
	}
	let u = Q_(e, l, t) ?? i[0], d = Z_(e, l, t, r.myCard, u, "zhiba", c), f = [r.myCard, i[0]].filter((t) => e.discard.includes(t)), p = e.seats.findIndex((e) => e.identity === "lord"), m = X_(e, t, u) > X_(e, l, r.myCard), h = l === p ? m ? -1 : l : d ? -1 : t;
	h >= 0 && f.length > 0 && (e.pending = {
		kind: "skill-ask",
		seats: [h],
		ctx: {
			skill: "zhiba-obtain",
			data: { cards: f }
		}
	});
}, _a = {
	"zhiba-obtain": pa,
	"jiang-obtain": ma
}, va = { zhiba: ha }, ya = { zhiba: ga }, ba = (e, t, n, r, i) => {
	if (i.length === 1) {
		let r = i[0];
		W(e, t, r), U(e, [r]), L(e, {
			kind: "qiaobian",
			seat: t
		}), F(e, t, 1), e.beatMs = J.play, n === "qiaobian-judge" ? e.seats[t].flags.skipJudgeOnce = !0 : n === "qiaobian-draw" ? (e.skipDraw = !0, e.seats[t].flags.qbDrawSkip = !0) : n === "qiaobian-play" ? (e.skipPlay = !0, e.seats[t].flags.qbPlaySkip = !0) : e.seats[t].flags.qbDiscardSkip = !0;
	}
}, xa = (e, t, n, r, i) => {
	if (i.length === 1) {
		let n = i[0], r = -1;
		for (let t of z(e)) if (K(e, t).includes(n) || e.seats[t].judges.includes(n)) {
			r = t;
			break;
		}
		if (r >= 0) {
			let i = Av(e, r, n);
			i.length > 0 && (e.pending = {
				kind: "skill-seats",
				seats: [t],
				ctx: {
					skill: "qiaobian-move",
					min: 1,
					max: 1,
					data: {
						card: n,
						owner: r,
						candidates: i
					}
				}
			});
		}
	}
}, Sa = (e, t, n, r, i, a, o, s, c) => {
	let l = 0, u = [];
	for (let n of i) {
		if (e.hands[n].length === 0) continue;
		let r = e.hands[n][Nv(e, e.hands[n].length)];
		W(e, n, r), e.hands[t].push(r), u.push(r), l += 1, Cv(e, n), cv(e, n);
	}
	l > 0 && (c.push({
		kind: "take",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: l
		},
		for: [e.seats[t].rid],
		secret: { cards: u }
	}), L(e, {
		kind: "qiaobian-draw",
		seat: t,
		n: l
	}), e.beatMs = J.draw, P(e, t, u));
}, Ca = (e, t, n, r, i, a, o, s, c) => {
	let l = r.card, u = r.owner, d = i[0], f = k(e.cards[l].name);
	if (f != null) e.seats[u].equips[f] = null, I(e, u, l, c), e.seats[d].equips[f] = l;
	else {
		let t = e.seats[u].judges.indexOf(l);
		t >= 0 && e.seats[u].judges.splice(t, 1), e.seats[d].judges.push(l);
	}
	c.push({
		kind: "move",
		data: {
			seat: d,
			name: e.cards[l].name
		}
	}), L(e, {
		kind: "qiaobian-move",
		seat: t,
		target: d,
		cards: R(e, [l])
	}), e.beatMs = J.equip;
}, wa = {
	"qiaobian-judge": ba,
	"qiaobian-draw": ba,
	"qiaobian-play": ba,
	"qiaobian-discard": ba,
	"qiaobian-field": xa
}, Ta = {
	"qiaobian-draw": Sa,
	"qiaobian-move": Ca
}, Ea = {
	...zi,
	...Hi,
	...la,
	..._a
}, Da = {
	...Bi,
	...ua
}, Oa = {
	...qi,
	...ea
}, ka = {
	...Ji,
	...ta,
	...va
}, Aa = { ...na }, ja = {
	...Vi,
	...Yi,
	...ra,
	...da,
	...ya,
	...wa
}, Ma = {
	...fa,
	...Ta
}, Na = (e, t, n, r, i) => {
	Eb(e, t, i);
}, Pa = (e, t, n, r) => {
	let i = r.liyu;
	i && e.seats[i.target].alive && e.seats[i.source].alive && fx(e, i.target) && Ay(e, i);
}, Fa = (e, t, n, r, i, a, o, s) => {
	if (n.option === "recover" && e.seats[t].hp < e.seats[t].maxHp) e.seats[t].hp += 1, s.push({
		kind: "recover",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: t,
		n: 1
	}), X(e, t);
	else {
		let n = H(e, t, 2);
		s.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: r === "qinxue-jie" ? "qinxue" : "hunzi",
			n: n.length
		});
	}
	return e.beatMs = J.recover, Z(e, s), {
		state: e,
		fx: s
	};
}, Ia = {
	luoyi: Na,
	tuxi: Na,
	shuangxiong: Na,
	zaiqi: Na,
	haoshi: Na,
	jianxiong: Pa,
	fankui: Pa,
	ganglie: Pa,
	yiji: Pa,
	jieming: Pa,
	fangzhu: Pa,
	zhiyu: Pa,
	quanji: Pa,
	chengxiang: Pa,
	duodao: Pa,
	yuce: Pa,
	huituo: Pa
}, La = {
	"qinxue-jie": Fa,
	"hunzi-bonus": Fa
}, Ra = () => {}, za = (e, t, n, r, i, a, o, s) => {
	if (L(e, {
		kind: "skill",
		seat: t,
		card: r
	}), n.option === "obtain") {
		let n = i.cardId, r = e.discard.indexOf(n);
		r >= 0 && (e.discard.splice(r, 1), e.hands[t].push(n), s.push({
			kind: "take",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				from: -1
			},
			for: [e.seats[t].rid],
			secret: { card: n }
		}));
	} else H(e, t, 1);
	return L(e, {
		kind: "skill-draw",
		seat: t,
		card: r,
		n: 1
	}), $_(e, t, r, i) || Z(e, s), {
		state: e,
		fx: s
	};
}, Ba = { jianxiong: Ra }, Va = { jianxiong: za }, Ha = (e, t, n, r) => {
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "liuli",
			min: 1,
			max: 1,
			data: r
		}
	};
}, Ua = (e, t, n, r, i) => {
	Ue(e, r.info, i);
}, Wa = (e, t, n, r, i) => {
	if (e.hands[t].filter((t) => e.cards[t].suit === "diamond").length === 0) return null;
	let a = i.filter((t) => !e.seats[t].judges.some((t) => uy(e, t) === "indulgence")), o = z(e).filter((t) => e.seats[t].judges.some((t) => uy(e, t) === "indulgence")), s = [.../* @__PURE__ */ new Set([...a, ...o])];
	return s.length > 0 ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: s,
		suits: ["diamond"]
	} : null;
}, Ga = (e, t, n, r, i, a, o) => {
	let s = i[0], c = r[0];
	W(e, t, c);
	let l = e.seats[s].judges.find((t) => uy(e, t) === "indulgence");
	if (l != null) {
		U(e, [c]), e.seats[s].judges = e.seats[s].judges.filter((e) => e !== l), delete e.judgeNames[l], U(e, [l]);
		let n = H(e, t, 1);
		o.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: 1
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "guose-break",
			seat: t,
			target: s
		}), P(e, t, n);
	} else {
		L(e, {
			kind: "guose-play",
			seat: t,
			target: s
		}), e.queue.unshift({
			k: "trick-effect",
			name: "indulgence",
			from: t,
			target: s,
			cardId: c
		});
		let n = H(e, t, 1);
		o.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: 1
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), P(e, t, n);
	}
	return e.beatMs = J.play, F(e, t, 1), Z(e, o), {
		state: e,
		fx: o
	};
}, Ka = (e, t, n, r, i) => {
	W(e, t, i[0]), U(e, [i[0]]), L(e, {
		kind: "skill",
		seat: t,
		card: "liuli"
	}), F(e, t, 1);
	let a = r.info, o = Be(e, a);
	if (o.length === 0) {
		Ge(e, a);
		return;
	}
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "liuli-target",
			min: 1,
			max: 1,
			data: {
				candidates: o,
				info: a
			}
		}
	};
}, qa = (e, t, n, r, i, a, o, s, c) => {
	let l = {
		...r.info,
		target: i[0]
	};
	L(e, {
		kind: "liuli",
		seat: t,
		target: i[0]
	}), Ue(e, l, c);
}, Ja = { liuli: Ha }, Ya = { liuli: Ua }, Xa = { guose: Wa }, Za = { guose: Ga }, Qa = { liuli: Ka }, $a = { "liuli-target": qa }, eo = (e, t, n, r, i, a) => {
	let o = i.filter(a);
	return r >= 1 && o.length >= 2 ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 2,
		maxTargets: 2,
		targets: o
	} : null;
}, to = (e, t, n, r, i, a, o) => {
	W(e, t, r[0]), U(e, [r[0]]);
	let [s, c] = i;
	return n === "re_lijian" ? e.queue.unshift({
		k: "trick-effect",
		name: "duel",
		from: s,
		target: c,
		cardId: null
	}) : Qe(e, s, "duel", c, {
		k: "trick-effect",
		name: "duel",
		from: s,
		target: c,
		cardId: null
	}), vv(e, s, o), F(e, t, 1), e.pending || Z(e, o), {
		state: e,
		fx: o
	};
}, no = {
	lijian: eo,
	re_lijian: eo
}, ro = {
	lijian: to,
	re_lijian: to
}, io = (e, t, n, r) => {
	let i = r.targets;
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "fenwei",
			min: 1,
			max: i.length,
			data: {
				...r,
				candidates: i
			}
		}
	};
}, ao = (e, t, n, r, i) => {
	nv(e, r.name, r.from, [], i, {
		suit: r.suit ?? null,
		cardId: r.cardId ?? null
	});
}, oo = (e, t, n, r, i, a, o, s, c) => {
	e.seats[t].limitedUsed.push("fenwei"), L(e, {
		kind: "skill",
		seat: t,
		card: "fenwei"
	}), nv(e, r.name, r.from, i, c, {
		suit: r.suit ?? null,
		cardId: r.cardId ?? null
	});
}, so = { fenwei: io }, co = { fenwei: ao }, lo = { fenwei: oo }, uo = (e, t, n, r, i) => {
	let a = r.target;
	e.seats[a].alive && e.seats[a].hp < e.seats[a].maxHp && (e.seats[a].hp += 1, i.push({
		kind: "recover",
		rid: e.seats[a].rid,
		data: {
			seat: a,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: a,
		n: 1
	}), X(e, a));
}, fo = (e, t, n, r, i) => {
	let a = i.filter((t) => e.hands[t].length > 0);
	return r >= 1 && a.length > 0 ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, po = (e, t, n, r, i, a, o) => {
	let s = i[0];
	return n === "re_yijue" ? (W(e, t, r[0]), U(e, [r[0]]), F(e, t, 1), e.pending = {
		kind: "skill-cards",
		seats: [s],
		ctx: {
			skill: "yijue-jie-show",
			min: 1,
			max: 1,
			data: {
				from: t,
				pool: [...e.hands[s]]
			}
		}
	}, {
		state: e,
		fx: o
	}) : (e.pending = {
		kind: "skill-cards",
		seats: [s],
		ctx: {
			skill: "yijue",
			min: 1,
			max: 1,
			data: {
				from: t,
				myCard: r[0]
			}
		}
	}, {
		state: e,
		fx: o
	});
}, mo = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from;
	Z_(e, l, t, r.myCard, Q_(e, l, t) ?? i[0], "yijue", c) ? (e.seats[t].flags.sealed = !0, e.seats[t].flags.noHand = !0, L(e, {
		kind: "yijue-seal",
		seat: l,
		target: t
	})) : e.pending = {
		kind: "skill-ask",
		seats: [l],
		ctx: {
			skill: "yijue-heal",
			data: { target: t }
		}
	};
}, ho = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from, u = i[0];
	c.push({
		kind: "reveal",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: u
		}
	}), L(e, {
		kind: "yijue-show",
		seat: t,
		cards: R(e, [u])
	}), qv(e, u) ? (e.seats[t].flags.sealed = !0, e.seats[t].flags.noHand = !0, e.seats[t].flags.yijueBy = l, L(e, {
		kind: "yijue-seal",
		seat: l,
		target: t
	})) : e.seats[l].alive && (W(e, t, u), e.hands[l].push(u), c.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: l,
			n: 1
		},
		for: [e.seats[t].rid, e.seats[l].rid],
		secret: { cards: [u] }
	}), F(e, t, 1), e.seats[t].hp < e.seats[t].maxHp && (e.pending = {
		kind: "skill-ask",
		seats: [l],
		ctx: {
			skill: "yijue-heal",
			data: { target: t }
		}
	}));
}, go = { "yijue-heal": uo }, _o = {
	yijue: fo,
	re_yijue: fo
}, vo = {
	yijue: po,
	re_yijue: po
}, yo = {
	yijue: mo,
	"yijue-jie-show": ho
}, bo = (e, t, n, r, i) => {
	let a = e.seats[t], o = H(e, t, 2);
	i.push({
		kind: "draw",
		rid: a.rid,
		data: {
			seat: t,
			n: 2
		},
		for: [a.rid],
		secret: { cards: o }
	}), L(e, {
		kind: "draw",
		seat: t,
		n: o.length
	}), e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "yiji",
			min: 0,
			max: 2,
			data: r
		}
	};
}, xo = (e, t, n, r, i) => {
	if (i.length > 0) {
		let n = z(e).filter((e) => e !== t);
		e.pending = {
			kind: "skill-seats",
			seats: [t],
			ctx: {
				skill: "yiji-give",
				min: 1,
				max: 1,
				data: {
					...r,
					give: i,
					candidates: n
				}
			}
		};
		return;
	}
	$_(e, t, n, r);
}, So = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.give, d = u[0];
	W(e, t, d), e.hands[l].push(d), c.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: l,
			n: 1
		},
		for: [e.seats[t].rid, e.seats[l].rid],
		secret: { cards: [d] }
	}), L(e, {
		kind: "yiji-give",
		seat: t,
		target: l,
		n: 1
	}), cv(e, t);
	let f = u.slice(1);
	if (f.length > 0) {
		let n = z(e).filter((e) => e !== t);
		e.pending = {
			kind: "skill-seats",
			seats: [t],
			ctx: {
				skill: "yiji-give",
				min: 1,
				max: 1,
				data: {
					...r,
					give: f,
					candidates: n
				}
			}
		};
		return;
	}
	$_(e, t, "yiji", r);
}, Co = { yiji: bo }, wo = { yiji: xo }, To = { "yiji-give": So }, Eo = (e, t, n, r) => r >= 1 ? {
	minCards: 1,
	maxCards: 1,
	minTargets: 0,
	maxTargets: 0,
	targets: []
} : null, Do = (e, t, n, r, i, a, o) => (W(e, t, r[0]), U(e, [r[0]]), Ly(e, t, 1, o), F(e, t, 1), {
	state: e,
	fx: o
}), Oo = { kurou: Eo }, ko = { kurou: Do }, Ao = (e, t, n, r, i) => {
	let a = i.filter((t) => fx(e, t));
	return r >= 1 && a.length >= 1 ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: Math.min(3, a.length),
		targets: a
	} : null;
}, jo = (e, t, n, r) => {
	if (n.flags.qnBlack) return null;
	let i = z(e).filter((t) => e.seats[t].hp < e.seats[t].maxHp && !n.flags[`qn:${t}`]);
	return r >= 1 && i.length > 0 ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: i
	} : null;
}, Mo = (e, t, n, r, i, a, o) => {
	W(e, t, r[0]), U(e, [r[0]]), e.cards[r[0]].suit === "spade" && H(e, t, 1);
	for (let t of i) {
		let n, r = !1;
		if (e.hands[t].length > 0) n = e.hands[t][Nv(e, e.hands[t].length)], W(e, t, n), r = !0;
		else if (n = K(e, t)[0], n != null) {
			for (let r of [
				"weapon",
				"armor",
				"off_horse",
				"def_horse"
			]) e.seats[t].equips[r] === n && (e.seats[t].equips[r] = null);
			I(e, t, n, o);
		}
		n != null && (U(e, [n]), r && cv(e, t), e.cards[n].suit === "spade" && H(e, t, 1));
	}
	return L(e, {
		kind: "chuli",
		seat: t,
		n: i.length
	}), e.beatMs = J.play, F(e, t, 1), {
		state: e,
		fx: o
	};
}, No = (e, t, n, r, i, a, o) => {
	let s = i[0], c = r[0];
	return W(e, t, c), U(e, [c]), F(e, t, 1), e.seats[t].flags[`qn:${s}`] = !0, qv(e, c) && (e.seats[t].flags.qnBlack = !0), e.seats[s].hp += 1, o.push({
		kind: "recover",
		rid: e.seats[s].rid,
		data: {
			seat: s,
			n: 1
		}
	}), L(e, {
		kind: "qingnang",
		seat: t,
		target: s
	}), X(e, s), e.beatMs = J.recover, {
		state: e,
		fx: o
	};
}, Po = {
	chuli: Ao,
	qingnang: jo
}, Fo = {
	chuli: Mo,
	qingnang: No
}, Io = (e, t, n, r, i) => r >= 1 ? {
	minCards: 1,
	maxCards: r,
	minTargets: 1,
	maxTargets: 1,
	targets: i
} : null, Lo = (e, t, n, r, i) => {
	let a = i.filter((e) => !n.flags[`rd:${e}`]);
	return r >= 1 && a.length > 0 ? {
		minCards: 1,
		maxCards: r,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, Ro = (e, t, n, r, i, a, o) => {
	let s = i[0];
	for (let n of r) W(e, t, n);
	e.hands[s].push(...r);
	let c = e.seats[t].flags;
	if (c.rendeGiven = (c.rendeGiven ?? 0) + r.length, L(e, {
		kind: "rende",
		seat: t,
		target: s,
		n: r.length
	}), o.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: s,
			n: r.length
		},
		for: [e.seats[t].rid, e.seats[s].rid],
		secret: { cards: r }
	}), hv(e, s, t, r.length, o), n === "re_rende") {
		if (c[`rd:${s}`] = !0, c.rendeGiven >= 2 && !c.rendeHealed) {
			c.rendeHealed = !0;
			let n = [], i = e.turn != null && e.turn.slashUsed < Hv(e, t), a = Bv(e, t), s = z(e).filter((n) => n !== t && !N(e, n) && V(e, t, n) <= a);
			if (i && s.length > 0 && n.push("slash"), e.seats[t].hp < e.seats[t].maxHp && n.push("peach"), c.analepticUsed || n.push("analeptic"), n.length > 0) return e.pending = {
				kind: "skill-ask",
				seats: [t],
				ctx: {
					skill: "rende-basic",
					options: n,
					data: {}
				}
			}, F(e, t, r.length), {
				state: e,
				fx: o
			};
		}
	} else c.rendeGiven >= 2 && !c.rendeHealed && e.seats[t].hp < e.seats[t].maxHp && (c.rendeHealed = !0, e.seats[t].hp += 1, o.push({
		kind: "recover",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: t,
		n: 1
	}));
	return e.beatMs = J.recover, F(e, t, r.length), {
		state: e,
		fx: o
	};
}, zo = (e, t, n, r, i, a, o, s) => {
	if (L(e, {
		kind: "skill",
		seat: t,
		card: "rende"
	}), n.option === "slash") {
		let n = Bv(e, t), r = z(e).filter((r) => r !== t && !N(e, r) && V(e, t, r) <= n);
		return r.length === 0 || e.turn == null || e.turn.slashUsed >= Hv(e, t) ? (Z(e, s), {
			state: e,
			fx: s
		}) : (e.pending = {
			kind: "skill-seats",
			seats: [t],
			ctx: {
				skill: "rende-slash",
				min: 1,
				max: 1,
				data: { candidates: r }
			}
		}, {
			state: e,
			fx: s
		});
	}
	return n.option === "peach" && e.seats[t].hp < e.seats[t].maxHp ? (e.seats[t].hp += 1, s.push({
		kind: "recover",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: t,
		n: 1
	}), X(e, t)) : n.option === "analeptic" && !e.seats[t].flags.analepticUsed && (e.seats[t].flags.analeptic = !0, e.seats[t].flags.analepticUsed = !0, L(e, {
		kind: "analeptic",
		seat: t
	})), e.beatMs = J.recover, Z(e, s), {
		state: e,
		fx: s
	};
}, Bo = (e, t, n, r, i, a, o, s, c) => {
	c.push({
		kind: "play",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			name: "slash"
		}
	}), L(e, {
		kind: "use",
		seat: t,
		card: "slash",
		target: i[0]
	}), e.turn.slashUsed += 1, e.seats[t].flags.slashInPlay = !0, e.queue.unshift({
		k: "slash-target",
		from: t,
		target: i[0],
		cardName: "slash",
		suit: null,
		cardId: null
	});
}, Vo = {
	rende: Io,
	re_rende: Lo
}, Ho = {
	rende: Ro,
	re_rende: Ro
}, Uo = { "rende-basic": zo }, Wo = { "rende-slash": Bo }, Go = (e, t, n, r) => {
	let i = e.seats[t], a = r.ev, o = e.hands[t].length;
	i.qianxun.push(...e.hands[t]), L(e, {
		kind: "qianxun",
		seat: t,
		n: o
	}), e.hands[t] = [], F(e, t, o), e.queue.unshift({
		...a,
		qx: !0
	});
}, Ko = (e, t, n, r) => {
	e.queue.unshift({
		...r.ev,
		qx: !0
	});
}, qo = (e, t, n, r, i) => {
	for (let t of i) H(e, t, 1);
	L(e, {
		kind: "lianying",
		seat: t,
		n: i.length
	});
}, Jo = { qianxun: Go }, Yo = { qianxun: Ko }, Xo = { lianying: qo }, Zo = (e, t, n, r, i) => {
	if (n === "re_liyu") {
		let n = r.target;
		e.seats[n].alive && et(e, n, "snatch").length > 0 && (e.pending = {
			kind: "pick-zone",
			seats: [t],
			ctx: {
				trick: "snatch",
				from: t,
				target: n,
				via: "liyu-jie"
			}
		});
		return;
	}
	let a = r.source, o, s = !1;
	if (e.hands[t].length > 0) o = e.hands[t][Nv(e, e.hands[t].length)], W(e, t, o), s = !0;
	else if (o = K(e, t)[0], o != null) {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === o && (e.seats[t].equips[n] = null);
		I(e, t, o, i);
	}
	o != null && (e.hands[a].push(o), L(e, {
		kind: "liyu-take",
		seat: a,
		target: t
	})), s && (Cv(e, t), cv(e, t));
	let c = z(e).filter((n) => n !== a && n !== t && !N(e, n));
	c.length > 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "liyu",
			min: 1,
			max: 1,
			data: {
				candidates: c,
				source: a
			}
		}
	});
}, Qo = (e, t, n, r, i, a, o, s, c) => {
	let l = r.source;
	return Qe(e, l, "duel", i[0], {
		k: "trick-effect",
		name: "duel",
		from: l,
		target: i[0],
		cardId: null
	}), vv(e, l, c), e.pending || Z(e, c), {
		state: e,
		fx: c
	};
}, $o = {
	liyu: Zo,
	re_liyu: Zo
}, es = { liyu: Qo }, ts = { botu: (e, t) => {
	let n = e.seats[t];
	n.marks.botuN = (n.marks.botuR === e.round ? n.marks.botuN ?? 0 : 0) + 1, n.marks.botuR = e.round, e.extraTurn = t;
} }, ns = (e, t, n, r, i) => {
	let a = r.info;
	e.seats[a.target].flags.sealed = !0, nt(e, t, "tieji", { info: a }, i);
}, rs = (e, t, n, r) => {
	Ke(e, r.info, !1);
}, is = (e, t, n, r, i, a, o, s, c) => {
	let l = r.info;
	if (i.length === 1) {
		let n = i[0];
		if (!W(e, t, n)) {
			for (let r of [
				"weapon",
				"armor",
				"off_horse",
				"def_horse"
			]) e.seats[t].equips[r] === n && (e.seats[t].equips[r] = null);
			I(e, t, n, c);
		}
		U(e, [n]), Ke(e, l, !1);
	} else Ke(e, l, !0);
}, as = (e, t, n, r, i, a, o, s, c) => {
	let l = r.info;
	if (i.length === 1) {
		let n = i[0], a = r.to;
		if (W(e, t, n)) F(e, t, 1);
		else {
			for (let r of [
				"weapon",
				"armor",
				"off_horse",
				"def_horse"
			]) e.seats[t].equips[r] === n && (e.seats[t].equips[r] = null);
			I(e, t, n, c);
		}
		e.hands[a].push(n), c.push({
			kind: "give",
			rid: e.seats[t].rid,
			data: {
				from: t,
				to: a,
				n: 1
			},
			for: [e.seats[t].rid, e.seats[a].rid],
			secret: { cards: [n] }
		}), L(e, {
			kind: "tieji-give",
			seat: t,
			target: a
		}), Ke(e, l, !1);
	} else l.noJink = !0, l.plus = (l.plus ?? 0) + 1, Ke(e, l, !0);
}, os = {
	tieji: ns,
	re_tieji: ns
}, ss = {
	tieji: rs,
	re_tieji: rs
}, cs = {
	"tieji-discard": is,
	"tieji-give": as
}, ls = { fankui: (e, t, n, r) => {
	let i = r.source;
	if (i != null && e.seats[i].alive && et(e, i, "snatch", !1).length > 0) {
		e.pending = {
			kind: "pick-zone",
			seats: [t],
			ctx: {
				trick: "snatch",
				from: t,
				target: i,
				allowJudge: !1,
				chain: {
					seat: t,
					skill: "fankui",
					data: r
				}
			}
		};
		return;
	}
	$_(e, t, "fankui", r);
} }, us = (e, t, n, r) => {
	let i = r + K(e, t).length;
	return i >= 1 ? {
		minCards: 1,
		maxCards: i,
		minTargets: 0,
		maxTargets: 0,
		targets: [],
		allowEquip: !0
	} : null;
}, ds = (e, t, n, r, i, a, o) => {
	let s = n === "re_zhiheng" && e.hands[t].length > 0 && e.hands[t].every((e) => r.includes(e));
	for (let n of r) if (e.hands[t].includes(n)) W(e, t, n);
	else {
		for (let r of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[r] === n && (e.seats[t].equips[r] = null);
		I(e, t, n, o);
	}
	U(e, r);
	let c = H(e, t, r.length + +!!s);
	return o.push({
		kind: "draw",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: c.length
		},
		for: [e.seats[t].rid],
		secret: { cards: c }
	}), L(e, {
		kind: "zhiheng",
		seat: t,
		n: r.length
	}), e.beatMs = J.draw, P(e, t, c), {
		state: e,
		fx: o
	};
}, fs = (e, t, n, r, i, a, o, s) => {
	let c = i.lord;
	if (L(e, {
		kind: "skill",
		seat: t,
		card: "jiuyuan"
	}), n.option === "lord" && e.seats[c].alive) {
		e.seats[c].hp < e.seats[c].maxHp && (e.seats[c].hp += 1, s.push({
			kind: "recover",
			rid: e.seats[c].rid,
			data: {
				seat: c,
				n: 1
			}
		}), L(e, {
			kind: "recover",
			seat: c,
			n: 1
		}), X(e, c));
		let n = H(e, t, 1);
		s.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "jiuyuan",
			n: 1
		});
	} else e.seats[t].hp < e.seats[t].maxHp && (e.seats[t].hp += 1, s.push({
		kind: "recover",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: t,
		n: 1
	}), X(e, t));
	return e.beatMs = J.recover, Z(e, s), {
		state: e,
		fx: s
	};
}, ps = {
	zhiheng: us,
	re_zhiheng: us
}, ms = {
	zhiheng: ds,
	re_zhiheng: ds
}, hs = { "jiuyuan-choice": fs }, gs = (e, t, n, r, i, a) => {
	let o = i.filter((t) => a(t) && e.seats[t].hp < e.seats[t].maxHp);
	return r >= 2 && o.length > 0 ? {
		minCards: 2,
		maxCards: 2,
		minTargets: 1,
		maxTargets: 1,
		targets: o
	} : null;
}, _s = (e, t, n, r, i, a) => {
	let o = i.filter((n) => a(n) && (r >= 1 || K(e, t).some((t) => e.seats[n].equips[k(e.cards[t].name)] == null)));
	return o.length > 0 && (r >= 1 || K(e, t).length > 0) ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: o,
		allowEquip: !0
	} : null;
}, vs = (e, t, n, r, i, a, o) => {
	let s = i[0];
	if (n === "re_jieyin") {
		let n = r[0];
		if (e.hands[t].includes(n)) W(e, t, n), U(e, [n]), F(e, t, 1);
		else {
			let r = k(e.cards[n].name);
			if (r == null || e.seats[t].equips[r] !== n || e.seats[s].equips[r] != null) return q("games.sanguosha.error.badSkill");
			e.seats[t].equips[r] = null, I(e, t, n, o), e.seats[s].equips[r] = n, o.push({
				kind: "equip",
				rid: e.seats[s].rid,
				data: {
					seat: s,
					card: n,
					name: e.cards[n].name,
					slot: r
				}
			});
		}
		L(e, {
			kind: "jieyin",
			seat: t,
			target: s
		});
		let i = e.seats[t].hp, a = e.seats[s].hp;
		if (i >= a) {
			let n = H(e, t, 1);
			o.push({
				kind: "draw",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					n: n.length
				},
				for: [e.seats[t].rid],
				secret: { cards: n }
			});
		}
		if (a >= i) {
			let t = H(e, s, 1);
			o.push({
				kind: "draw",
				rid: e.seats[s].rid,
				data: {
					seat: s,
					n: t.length
				},
				for: [e.seats[s].rid],
				secret: { cards: t }
			});
		}
		return i < a && e.seats[t].hp < e.seats[t].maxHp && (e.seats[t].hp += 1, o.push({
			kind: "recover",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: 1
			}
		}), X(e, t)), a < i && e.seats[s].hp < e.seats[s].maxHp && (e.seats[s].hp += 1, o.push({
			kind: "recover",
			rid: e.seats[s].rid,
			data: {
				seat: s,
				n: 1
			}
		}), X(e, s)), e.beatMs = J.recover, {
			state: e,
			fx: o
		};
	}
	for (let n of r) W(e, t, n);
	U(e, r);
	let c = e.seats[t].hp < e.seats[t].maxHp, l = e.seats[s].hp < e.seats[s].maxHp;
	return c && (e.seats[t].hp += 1), l && (e.seats[s].hp += 1), X(e, t), X(e, s), c && o.push({
		kind: "recover",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: 1
		}
	}), l && o.push({
		kind: "recover",
		rid: e.seats[s].rid,
		data: {
			seat: s,
			n: 1
		}
	}), L(e, {
		kind: "jieyin",
		seat: t,
		target: s
	}), e.beatMs = J.recover, F(e, t, 2), {
		state: e,
		fx: o
	};
}, ys = {
	jieyin: gs,
	re_jieyin: _s
}, bs = {
	jieyin: vs,
	re_jieyin: vs
}, xs = (e, t, n, r, i) => {
	let a = r.source;
	a != null && e.seats[a].alive && nt(e, t, "ganglie", {
		source: a,
		chain: {
			seat: t,
			skill: "ganglie",
			data: r
		}
	}, i);
}, Ss = (e, t, n, r) => {
	let i = r.got.filter((n) => e.hands[t].includes(n));
	i.length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "qingjian",
			min: 1,
			max: i.length,
			data: { pool: i }
		}
	});
}, Cs = (e, t, n, r, i, a, o, s) => {
	let c = i.from, l = i.chain;
	return n.option === "gl-discard" ? (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "ganglie-drop",
			min: 2,
			max: 2,
			data: { chain: l }
		}
	}, {
		state: e,
		fx: s
	}) : (L(e, {
		kind: "skill",
		seat: c,
		card: "ganglie"
	}), e.queue.unshift({
		k: "damage",
		source: c,
		target: t,
		amount: 1,
		nature: "normal",
		reason: "ganglie",
		cardId: null
	}), l && $_(e, l.seat, l.skill, l.data) || Z(e, s), {
		state: e,
		fx: s
	});
}, ws = (e, t, n, r, i, a, o, s, c) => {
	for (let n of i) W(e, t, n);
	U(e, i), F(e, t, i.length), L(e, {
		kind: "ganglie-drop",
		seat: t,
		cards: R(e, i)
	});
	let l = r.chain;
	return l && $_(e, l.seat, l.skill, l.data) || Z(e, c), {
		state: e,
		fx: c
	};
}, Ts = (e, t, n, r, i) => {
	let a = z(e).filter((e) => e !== t);
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "qingjian",
			min: 1,
			max: 1,
			data: {
				give: i,
				candidates: a
			}
		}
	};
}, Es = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.give;
	for (let n of u) W(e, t, n);
	e.hands[l].push(...u), c.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: l,
			n: u.length
		},
		for: [e.seats[t].rid, e.seats[l].rid],
		secret: { cards: u }
	}), L(e, {
		kind: "qingjian",
		seat: t,
		target: l,
		n: u.length
	}), cv(e, t);
}, Ds = {
	ganglie: xs,
	re_ganglie: xs,
	qingjian: Ss
}, Os = { "ganglie-choice": Cs }, ks = {
	"ganglie-drop": ws,
	qingjian: Ts
}, As = { qingjian: Es }, js = (e, t, n, r, i) => {
	let a = e.seats[t];
	a.flags.luoyi = !0, n === "re_luoyi" && (a.marks.luoyiJie = 1);
	let o = [];
	for (let n = 0; n < 3; n++) {
		e.deck.length === 0 && e.discard.length > 0 && (e.deck = Pv(e, e.discard), e.discard = []);
		let n = e.deck.shift();
		if (n == null) break;
		O(e.cards[n].name) === "basic" || e.cards[n].name === "duel" || k(e.cards[n].name) === "weapon" ? (e.hands[t].push(n), o.push(n)) : U(e, [n]);
	}
	i.push({
		kind: "draw",
		rid: a.rid,
		data: {
			seat: t,
			n: o.length
		},
		for: [a.rid],
		secret: { cards: o }
	}), L(e, {
		kind: "luoyi",
		seat: t,
		n: o.length
	}), e.beatMs = J.draw;
}, Ms = {
	luoyi: js,
	re_luoyi: js
}, Ns = (e, t, n, r, i) => {
	let a = e.seats[t];
	a.limitedUsed.push(n);
	let o = n === "re_tishen" ? a.maxHp : a.lastEndHp, s = o - a.hp;
	a.hp = Math.min(a.maxHp, o), i.push({
		kind: "recover",
		rid: a.rid,
		data: {
			seat: t,
			n: s
		}
	}), s > 0 && H(e, t, s), L(e, {
		kind: "recover",
		seat: t,
		n: s
	}), X(e, t), e.beatMs = J.recover;
}, Ps = {
	tishen: Ns,
	re_tishen: Ns
}, Fs = (e, t, n, r, i) => {
	let a = z(e).filter((r) => r !== t && e.hands[r].length > 0 && (n === "re_tuxi" || e.hands[r].length >= e.hands[t].length));
	if (a.length === 0) {
		Eb(e, t, i);
		return;
	}
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: n,
			min: 1,
			max: 2,
			data: { candidates: a }
		}
	};
}, Is = (e, t, n, r, i, a, o, s, c) => {
	let l = 0;
	for (let n of i) {
		if (e.hands[n].length === 0) continue;
		let r = e.hands[n][Nv(e, e.hands[n].length)];
		W(e, n, r), e.hands[t].push(r), l += 1, Cv(e, n), cv(e, n);
	}
	e.seats[t].flags.tuxiN = l, L(e, {
		kind: "tuxi",
		seat: t,
		n: l
	}), c.push({
		kind: "draw",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: l
		},
		for: [e.seats[t].rid],
		secret: { cards: [] }
	}), Eb(e, t, c);
}, Ls = {
	tuxi: Fs,
	re_tuxi: Fs
}, Rs = {
	tuxi: Is,
	re_tuxi: Is
}, zs = {
	"yajiao-give": (e, t, n, r, i, a, o, s, c) => {
		let l = r.card, u = i[0];
		e.hands[u].push(l), c.push({
			kind: "give",
			rid: e.seats[t].rid,
			data: {
				from: t,
				to: u,
				n: 1
			},
			for: [e.seats[u].rid],
			secret: { cards: [l] }
		}), L(e, {
			kind: "yajiao-gain",
			seat: u,
			cards: R(e, [l])
		});
	},
	"yajiao-drop": (e, t, n, r, i) => {
		i.length === 1 && (e.pending = {
			kind: "pick-zone",
			seats: [t],
			ctx: {
				trick: "dismantlement",
				from: t,
				target: i[0],
				allowJudge: !0
			}
		});
	}
}, Bs = (e, t, n, r, i) => {
	nt(e, t, "luoshen", {}, i);
}, Vs = {
	luoshen: Bs,
	re_luoshen: Bs
}, Hs = (e, t, n, r, i) => r >= 1 && i.length > 0 ? {
	minCards: 1,
	maxCards: 1,
	minTargets: 1,
	maxTargets: 1,
	targets: i
} : null, Us = (e, t, n, r, i, a, o) => {
	let s = i[0], c = r[0];
	return W(e, t, c), e.hands[s].push(c), o.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: s,
			n: 1
		},
		for: [e.seats[t].rid, e.seats[s].rid],
		secret: { cards: [c] }
	}), e.pending = {
		kind: "skill-ask",
		seats: [s],
		ctx: {
			skill: "fanjian-discard",
			options: ["show-discard", "lose-hp"],
			data: {
				suit: e.cards[c].suit,
				from: t
			}
		}
	}, {
		state: e,
		fx: o
	};
}, Ws = (e, t, n, r, i, a, o, s) => {
	if (i.from, n.option === "show-discard") {
		let n = i.suit;
		s.push({
			kind: "reveal-hand",
			rid: e.seats[t].rid,
			data: {
				target: t,
				cards: [...e.hands[t]]
			}
		});
		let r = e.hands[t].filter((t) => e.cards[t].suit === n);
		for (let n of r) W(e, t, n);
		U(e, r), L(e, {
			kind: "fanjian-drop",
			seat: t,
			n: r.length,
			cards: R(e, r)
		}), F(e, t, r.length);
	} else Ly(e, t, 1, s);
	return e.pending || Z(e, s), {
		state: e,
		fx: s
	};
}, Gs = { fanjian: Hs }, Ks = { fanjian: Us }, qs = { "fanjian-discard": Ws }, Js = (e, t, n) => {
	let r = n === "re_guanxing" ? z(e).length < 4 ? 3 : 5 : Math.min(5, z(e).length), i = [];
	for (let t = 0; t < r; t++) {
		e.deck.length === 0 && e.discard.length > 0 && (e.deck = Pv(e, e.discard), e.discard = []);
		let t = e.deck.shift();
		if (t == null) break;
		i.push(t);
	}
	i.length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: n,
			min: 0,
			max: i.length,
			data: { pool: i }
		}
	});
}, Ys = (e, t, n, r, i) => {
	let a = r.pool, o = i, s = a.filter((e) => !o.includes(e));
	e.deck.unshift(...s), e.deck.push(...o), n === "re_guanxing" && a.length > 0 && o.length === a.length && (e.seats[t].flags.guanxingAgain = !0), L(e, {
		kind: "skill",
		seat: t,
		card: "guanxing"
	});
}, Xs = {
	guanxing: Js,
	re_guanxing: Js
}, Zs = {
	guanxing: Ys,
	re_guanxing: Ys
}, Qs = {
	...Ba,
	...Ja,
	...so,
	...go,
	...Co,
	...Jo,
	...$o,
	...ts,
	...os,
	...ls,
	...Ds,
	...Ms,
	...Ps,
	...Ls,
	...Vs,
	...Xs
}, $s = {
	...Ia,
	...Ya,
	...co,
	...Yo,
	...ss
}, ec = {
	...Xa,
	...no,
	..._o,
	...Oo,
	...Po,
	...Vo,
	...ps,
	...ys,
	...Gs
}, tc = {
	...Za,
	...ro,
	...vo,
	...ko,
	...Fo,
	...Ho,
	...ms,
	...bs,
	...Ks
}, nc = {
	...La,
	...Va,
	...Uo,
	...hs,
	...Os,
	...qs
}, rc = {
	...Qa,
	...yo,
	...wo,
	...cs,
	...ks,
	...Zs
}, ic = {
	...$a,
	...lo,
	...To,
	...Wo,
	...Xo,
	...es,
	...As,
	...Rs,
	...zs
}, ac = (e, t, n, r, i) => {
	let a = e.seats[t];
	if (n === "re_jushou") {
		let n = H(e, t, 4);
		i.push({
			kind: "draw",
			rid: a.rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [a.rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "jushou",
			n: n.length
		}), e.beatMs = J.draw, e.hands[t].length > 0 ? e.pending = {
			kind: "skill-cards",
			seats: [t],
			ctx: {
				skill: "jushou-discard",
				min: 1,
				max: 1,
				data: { pool: [...e.hands[t]] }
			}
		} : Jv(e, t, i);
		return;
	}
	let o = H(e, t, 1);
	i.push({
		kind: "draw",
		rid: a.rid,
		data: {
			seat: t,
			n: 1
		},
		for: [a.rid],
		secret: { cards: o }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "jushou",
		n: 1
	}), e.beatMs = J.draw, Jv(e, t, i);
}, oc = (e, t, n, r, i) => {
	let a = e.seats[t], o = H(e, t, 1);
	i.push({
		kind: "draw",
		rid: a.rid,
		data: {
			seat: t,
			n: 1
		},
		for: [a.rid],
		secret: { cards: o }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "jiewei",
		n: 1
	}), e.beatMs = J.draw;
	let s = jv(e, t);
	s.length > 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "jiewei-use",
			min: 0,
			max: 1,
			data: { pool: s }
		}
	});
}, sc = (e, t) => {
	let n = [...e.hands[t], ...K(e, t)];
	n.length !== 0 && kv(e).length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "jiewei-jie-discard",
			min: 1,
			max: 1,
			data: { pool: n }
		}
	});
}, cc = (e, t, n, r, i, a, o, s, c) => {
	if (i.length === 0) return;
	let l = i[0], u = e.cards[l].name;
	if (k(u) != null) {
		W(e, t, l);
		let n = k(u), r = e.seats[t].equips[n];
		r != null && (U(e, [r]), I(e, t, r, c)), e.seats[t].equips[n] = l, c.push({
			kind: "equip",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				card: l,
				name: u,
				slot: n
			}
		}), L(e, {
			kind: "equip",
			seat: t,
			card: u,
			cards: R(e, [l])
		}), e.beatMs = J.equip, F(e, t, 1), e.queue.unshift({
			k: "jiewei-follow",
			seat: t,
			cls: "equip"
		});
		return;
	}
	let d = dx(e, t, l);
	if (d != null) {
		if (d.length > 0) {
			e.pending = {
				kind: "skill-seats",
				seats: [t],
				ctx: {
					skill: "jiewei-target",
					min: 1,
					max: 1,
					data: {
						candidates: d,
						card: l
					}
				}
			};
			return;
		}
		Mv(e, t, l, null, c);
	}
}, lc = (e, t, n, r, i, a, o, s, c) => {
	if (i.length === 0) return;
	let l = i[0], u = !1;
	for (let t = 0; t < e.seats.length && !u; t++) {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) if (e.seats[t].equips[n] === l) {
			e.seats[t].equips[n] = null, U(e, [l]), I(e, t, l, c), u = !0;
			break;
		}
		let n = e.seats[t].judges.indexOf(l);
		!u && n >= 0 && (e.seats[t].judges.splice(n, 1), delete e.judgeNames[l], U(e, [l]), u = !0);
	}
	u && (L(e, {
		kind: "jiewei-drop",
		seat: t,
		cards: R(e, [l])
	}), e.beatMs = J.play);
}, uc = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (W(e, t, l)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === l && (e.seats[t].equips[n] = null);
		I(e, t, l, c);
	}
	U(e, [l]), L(e, {
		kind: "discard-skill",
		seat: t,
		card: "jiewei",
		cards: R(e, [l])
	}), e.beatMs = J.discard;
	let u = kv(e);
	u.length > 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "qiaobian-field",
			min: 1,
			max: 1,
			data: { pool: u }
		}
	});
}, dc = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	W(e, t, l), F(e, t, 1);
	let u = k(e.cards[l].name);
	if (u != null) {
		let n = e.seats[t].equips[u];
		n != null && (U(e, [n]), I(e, t, n, c)), e.seats[t].equips[u] = l, c.push({
			kind: "equip",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				card: l,
				name: e.cards[l].name,
				slot: u
			}
		}), L(e, {
			kind: "equip",
			seat: t,
			card: e.cards[l].name,
			cards: R(e, [l])
		});
	} else U(e, [l]), L(e, {
		kind: "discard-skill",
		seat: t,
		card: "jushou",
		cards: R(e, [l])
	});
	e.beatMs = J.equip, Jv(e, t, c);
}, fc = (e, t, n, r, i, a, o, s, c) => {
	Mv(e, t, r.card, i[0], c);
}, pc = {
	jushou: ac,
	re_jushou: ac,
	jiewei: oc,
	"jiewei-jie": sc
}, mc = {
	"jiewei-use": cc,
	"jiewei-discard": lc,
	"jiewei-jie-discard": uc,
	"jushou-discard": dc
}, hc = { "jiewei-target": fc }, gc = (e, t, n, r) => {
	Ve(e, r.info, !0);
}, _c = (e, t, n, r) => {
	Ve(e, r.info, !1);
}, vc = { liegong: gc }, yc = { liegong: _c }, bc = (e, t, n, r, i) => {
	Oy(e, r.ev, i, !1, !0);
}, xc = (e, t, n) => n.limitedUsed.includes("qimou") ? null : {
	minCards: 0,
	maxCards: 0,
	minTargets: 0,
	maxTargets: 0,
	targets: []
}, Sc = (e, t, n, r, i, a, o) => {
	let s = Array.from({ length: e.seats[t].hp }, (e, t) => String(t + 1));
	return e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "qimou-x",
			options: s,
			noPass: !0,
			data: {}
		}
	}, {
		state: e,
		fx: o
	};
}, Cc = (e, t, n, r, i, a, o, s) => {
	if (L(e, {
		kind: "skill",
		seat: t,
		card: "kuanggu"
	}), n.option === "recover" && e.seats[t].hp < e.seats[t].maxHp) e.seats[t].hp += 1, s.push({
		kind: "recover",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: t,
		n: 1
	}), X(e, t), e.beatMs = J.recover;
	else {
		let n = H(e, t, 1);
		s.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "kuanggu",
			n: 1
		}), e.beatMs = J.draw;
	}
	return Oy(e, i.ev, s, !1, !0) || Z(e, s), {
		state: e,
		fx: s
	};
}, wc = (e, t, n, r, i, a, o, s) => {
	let c = parseInt(n.option, 10);
	return !Number.isInteger(c) || c < 1 ? q("games.sanguosha.error.badChoose") : (e.seats[t].limitedUsed.push("qimou"), L(e, {
		kind: "skill",
		seat: t,
		card: "qimou",
		n: c
	}), e.seats[t].flags.qimouX = c, e.queue.unshift({
		k: "qimou-draw",
		seat: t,
		n: c
	}), Ly(e, t, c, s), e.pending || Z(e, s), {
		state: e,
		fx: s
	});
}, Tc = { kuanggu: bc }, Ec = { qimou: xc }, Dc = { qimou: Sc }, Oc = {
	kuanggu: Cc,
	"qimou-x": wc
}, kc = (e, t) => {
	let n = Yv(e);
	n.length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "shebian-move",
			min: 1,
			max: 1,
			data: { pool: n }
		}
	});
}, Ac = (e, t, n, r, i) => {
	if (i.length === 1) {
		let n = i[0], r = -1;
		for (let t of z(e)) if (K(e, t).includes(n)) {
			r = t;
			break;
		}
		if (r >= 0) {
			let i = Av(e, r, n);
			i.length > 0 && (e.pending = {
				kind: "skill-seats",
				seats: [t],
				ctx: {
					skill: "qiaobian-move",
					min: 1,
					max: 1,
					data: {
						card: n,
						owner: r,
						candidates: i
					}
				}
			});
		}
	}
}, jc = (e, t, n, r, i, a, o, s, c) => {
	r.shensu3 && Jv(e, t, c), c.push({
		kind: "play",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			name: "slash"
		}
	}), e.queue.unshift({
		k: "slash-target",
		from: t,
		target: i[0],
		cardName: "slash",
		suit: null,
		cardId: null
	});
}, Mc = { shebian: kc }, Nc = { "shebian-move": Ac }, Pc = { "shensu-slash": jc }, Fc = (e, t, n, r, i) => {
	let a = e.hands[t].filter((n) => dy(e, t, n) === "heart");
	if (n === "re_tianxiang" && a.push(...K(e, t).filter((n) => dy(e, t, n) === "heart")), a.length === 0) {
		Fy(e, r.ev, i), e.beatMs = J.damage;
		return;
	}
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "tianxiang-discard",
			min: 1,
			max: 1,
			data: {
				ev: r.ev,
				pool: a
			}
		}
	};
}, Ic = (e, t, n, r, i) => {
	nt(e, t, "piaoling", {}, i);
}, Lc = (e, t, n, r, i) => {
	Fy(e, r.ev, i), e.beatMs = J.damage;
}, Rc = (e, t, n, r, i, a, o, s) => {
	let c = i.judgeCard;
	return n.option === "top" ? (e.deck.unshift(c), L(e, {
		kind: "piaoling-top",
		seat: t
	}), Z(e, s), {
		state: e,
		fx: s
	}) : (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "piaoling-give",
			min: 1,
			max: 1,
			data: {
				candidates: z(e),
				judgeCard: c
			}
		}
	}, {
		state: e,
		fx: s
	});
}, zc = (e, t, n, r, i, a, o, s) => {
	let c = i.ev, l = i.t;
	if (L(e, {
		kind: "tianxiang",
		seat: t,
		target: l
	}), n.option === "losehp" && e.seats[l].alive) {
		let t = i.card;
		return t != null && e.discard.includes(t) && (e.discard.splice(e.discard.indexOf(t), 1), e.hands[l].push(t), s.push({
			kind: "take",
			rid: e.seats[l].rid,
			data: {
				seat: l,
				n: 1
			},
			for: [e.seats[l].rid],
			secret: { cards: [t] }
		})), Ly(e, l, 1, s), e.pending || Z(e, s), {
			state: e,
			fx: s
		};
	}
	return e.queue.unshift({
		k: "tianxiang-draw",
		seat: l
	}), e.queue.unshift({
		k: "damage",
		source: c.source,
		target: l,
		amount: c.amount,
		nature: c.nature,
		reason: c.reason,
		cardId: c.cardId
	}), Z(e, s), {
		state: e,
		fx: s
	};
}, Bc = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (e.hands[t].includes(l)) W(e, t, l), U(e, [l]), F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === l && (e.seats[t].equips[n] = null);
		U(e, [l]), I(e, t, l, c);
	}
	L(e, {
		kind: "skill",
		seat: t,
		card: "tianxiang"
	});
	let u = z(e).filter((e) => e !== t);
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "tianxiang-target",
			min: 1,
			max: 1,
			data: {
				ev: r.ev,
				candidates: u,
				card: l
			}
		}
	};
}, Vc = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	Qv(e, t, [l], c), L(e, {
		kind: "discard-skill",
		seat: t,
		card: "piaoling",
		cards: R(e, [l])
	}), e.beatMs = J.discard;
}, Hc = (e, t, n, r, i) => {
	let a = r.ev, o = i[0];
	if (Y(e, t, "re_tianxiang")) {
		e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "tianxiang-mode",
				options: ["transfer", "losehp"],
				noPass: !0,
				data: {
					ev: a,
					t: o,
					card: r.card
				}
			}
		};
		return;
	}
	L(e, {
		kind: "tianxiang",
		seat: t,
		target: o
	}), e.queue.unshift({
		k: "tianxiang-draw",
		seat: o
	}), e.queue.unshift({
		k: "damage",
		source: a.source,
		target: o,
		amount: a.amount,
		nature: a.nature,
		reason: a.reason,
		cardId: a.cardId
	});
}, Uc = (e, t, n, r, i, a, o, s, c) => {
	let l = r.judgeCard, u = i[0];
	e.hands[u].push(l), c.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: u,
			n: 1
		},
		for: [e.seats[t].rid, e.seats[u].rid],
		secret: { cards: [l] }
	}), L(e, {
		kind: "piaoling-give",
		seat: t,
		target: u,
		cards: R(e, [l])
	}), u === t && (e.hands[t].length > 0 || K(e, t).length > 0) && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "piaoling-discard",
			min: 1,
			max: 1,
			data: { pool: [...e.hands[t], ...K(e, t)] }
		}
	});
}, Wc = {
	tianxiang: Fc,
	re_tianxiang: Fc,
	piaoling: Ic
}, Gc = {
	tianxiang: Lc,
	re_tianxiang: Lc
}, Kc = {
	"piaoling-choice": Rc,
	"tianxiang-mode": zc
}, qc = {
	"tianxiang-discard": Bc,
	"piaoling-discard": Vc
}, Jc = {
	"tianxiang-target": Hc,
	"piaoling-give": Uc
}, Yc = (e, t) => {
	let n = z(e).filter((e) => e !== t);
	n.length !== 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "leiji",
			min: 1,
			max: 1,
			data: { candidates: n }
		}
	});
}, Xc = (e, t, n, r, i, a, o) => {
	let s = i[0], c = r[0];
	return W(e, t, c), e.hands[s].push(c), L(e, {
		kind: "huangtian",
		seat: t,
		target: s
	}), o.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: s,
			n: 1
		},
		for: [e.seats[t].rid, e.seats[s].rid],
		secret: { cards: [c] }
	}), e.beatMs = J.play, F(e, t, 1), {
		state: e,
		fx: o
	};
}, Zc = (e, t, n, r, i, a, o, s, c) => {
	nt(e, i[0], "leiji", { source: t }, c);
}, Qc = (e, t, n, r, i) => {
	i.length === 1 && (e.queue.unshift({
		k: "damage",
		source: t,
		target: i[0],
		amount: 2,
		nature: "thunder",
		reason: "leiji",
		cardId: null
	}), e.beatMs = J.play);
}, $c = (e, t, n, r, i) => {
	i.length === 1 && (e.queue.unshift({
		k: "damage",
		source: t,
		target: i[0],
		amount: 1,
		nature: "thunder",
		reason: "leiji",
		cardId: null
	}), e.beatMs = J.play);
}, el = { leiji: Yc }, tl = { huangtian: Xc }, nl = {
	leiji: Zc,
	"leiji-jie-spade": Qc,
	"leiji-jie-club": $c
}, rl = { fenji: (e, t, n, r, i) => {
	let a = r.victim;
	e.queue.unshift({
		k: "fenji-draw",
		seat: a
	}), Ly(e, t, 1, i);
} }, il = {
	...pc,
	...vc,
	...Mc,
	...Wc,
	...el,
	...rl
}, al = {
	...yc,
	...Tc,
	...Gc
}, ol = { ...Ec }, sl = {
	...Dc,
	...tl
}, cl = {
	...Oc,
	...Kc
}, ll = {
	...mc,
	...Nc,
	...qc
}, ul = {
	...hc,
	...Pc,
	...Jc,
	...nl
}, dl = (e, t, n, r, i) => i.some((t) => i.some((n) => t !== n && e.hands[t].length !== e.hands[n].length)) ? {
	minCards: 0,
	maxCards: 0,
	minTargets: 0,
	maxTargets: 0,
	targets: []
} : null, fl = (e, t, n, r, i, a, o) => (e.pending = {
	kind: "skill-seats",
	seats: [t],
	ctx: {
		skill: "anxu-targets",
		min: 2,
		max: 2,
		data: { candidates: z(e).filter((e) => e !== t) }
	}
}, {
	state: e,
	fx: o
}), pl = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (l == null) return;
	let u = H(e, l, 3);
	c.push({
		kind: "draw",
		rid: e.seats[l].rid,
		data: {
			seat: l,
			n: u.length
		},
		for: [e.seats[l].rid],
		secret: { cards: u }
	}), L(e, {
		kind: "zhuiyi",
		seat: t,
		target: l
	}), e.seats[l].hp < e.seats[l].maxHp && (e.seats[l].hp += 1, c.push({
		kind: "recover",
		rid: e.seats[l].rid,
		data: {
			seat: l,
			n: 1,
			by: "zhuiyi"
		}
	}), L(e, {
		kind: "recover",
		seat: l,
		n: 1
	})), e.beatMs = J.recover;
}, ml = { old_anxu: dl }, hl = { old_anxu: fl }, gl = { "zhuiyi-target": pl }, _l = (e, t, n, r, i) => !n.limitedUsed.includes("xianzhou") && K(e, t).length > 0 && i.length > 0 ? {
	minCards: 0,
	maxCards: 0,
	minTargets: 1,
	maxTargets: 1,
	targets: i
} : null, vl = (e, t, n, r, i, a, o) => {
	let s = i[0];
	e.seats[t].limitedUsed.push("xianzhou");
	let c = K(e, t), l = c.length;
	for (let n of c) {
		for (let r of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[r] === n && (e.seats[t].equips[r] = null);
		I(e, t, n, o), e.hands[s].push(n);
	}
	o.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: s,
			n: l
		},
		for: [e.seats[t].rid, e.seats[s].rid],
		secret: { cards: c }
	}), L(e, {
		kind: "xianzhou-give",
		seat: t,
		target: s,
		n: l
	}), hv(e, s, t, l, o), e.beatMs = J.play;
	let u = Bv(e, s), d = z(e).some((t) => t !== s && V(e, s, t) <= u);
	return e.pending = {
		kind: "skill-ask",
		seats: [s],
		ctx: {
			skill: "xianzhou-choice",
			options: d ? ["xz-heal", "xz-damage"] : ["xz-heal"],
			noPass: !0,
			data: {
				from: t,
				x: l
			}
		}
	}, {
		state: e,
		fx: o
	};
}, yl = (e, t, n, r, i, a, o, s) => {
	let c = i.target;
	if (n.option === "qt-move") {
		let n = (i.movable ?? []).filter((n) => e.seats[c].alive && K(e, c).includes(n) && e.seats[t].equips[k(e.cards[n].name)] == null);
		if (n.length > 0) return e.pending = {
			kind: "skill-cards",
			seats: [t],
			ctx: {
				skill: "qieting-move",
				min: 1,
				max: 1,
				data: {
					pool: n,
					target: c
				}
			}
		}, {
			state: e,
			fx: s
		};
	}
	let l = H(e, t, 1);
	return s.push({
		kind: "draw",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: l.length
		},
		for: [e.seats[t].rid],
		secret: { cards: l }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "qieting",
		n: l.length
	}), e.beatMs = J.draw, P(e, t, l), Z(e, s), {
		state: e,
		fx: s
	};
}, bl = (e, t, n, r, i, a, o, s) => {
	let c = i.from, l = i.x;
	if (n.option === "xz-heal") {
		if (e.seats[c].alive) {
			let n = Math.min(l, e.seats[c].maxHp - e.seats[c].hp);
			n > 0 && (e.seats[c].hp += n, s.push({
				kind: "recover",
				rid: e.seats[c].rid,
				data: {
					seat: c,
					n,
					by: t
				}
			}), e.beatMs = J.recover);
		}
		return L(e, {
			kind: "xianzhou",
			seat: t,
			target: c,
			n: l
		}), Z(e, s), {
			state: e,
			fx: s
		};
	}
	let u = Bv(e, t), d = z(e).filter((n) => n !== t && V(e, t, n) <= u);
	return d.length === 0 ? (Z(e, s), {
		state: e,
		fx: s
	}) : (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "xianzhou-targets",
			min: 1,
			max: Math.min(l, d.length),
			data: { candidates: d }
		}
	}, {
		state: e,
		fx: s
	});
}, xl = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.target, d = k(e.cards[l].name);
	d != null && e.seats[u].alive && e.seats[u].equips[d] === l && e.seats[t].equips[d] == null && (e.seats[u].equips[d] = null, e.seats[t].equips[d] = l, I(e, u, l, c), c.push({
		kind: "equip",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: l,
			name: e.cards[l].name,
			slot: d
		}
	}), L(e, {
		kind: "qieting-move",
		seat: t,
		target: u,
		cards: R(e, [l])
	}), e.beatMs = J.equip);
}, Sl = (e, t, n, r, i) => {
	i.length > 0 && L(e, {
		kind: "xianzhou-damage",
		seat: t,
		n: i.length
	});
	for (let n = i.length - 1; n >= 0; n--) e.queue.unshift({
		k: "damage",
		source: t,
		target: i[n],
		amount: 1,
		nature: "normal",
		reason: "xianzhou",
		cardId: null
	});
	e.beatMs = J.play;
}, Cl = { xianzhou: _l }, wl = { xianzhou: vl }, Tl = {
	qieting: yl,
	"xianzhou-choice": bl
}, El = { "qieting-move": xl }, Dl = { "xianzhou-targets": Sl }, Ol = (e, t, n, r, i) => {
	if (e.deck.length === 0) {
		if (e.discard.length === 0) return;
		e.deck = Pv(e, e.discard), e.discard = [];
	}
	let a = e.deck.shift();
	e.seats[t].shu.push(a), i.push({
		kind: "reveal",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: a
		}
	}), L(e, {
		kind: "bizhuan",
		seat: t,
		cards: R(e, [a])
	}), e.beatMs = J.draw;
}, kl = (e, t) => {
	let n = Math.min(4, e.seats[t].shu.length, e.hands[t].length);
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "tongbo-swap",
			min: 0,
			max: n,
			data: {}
		}
	};
}, Al = (e, t, n, r, i) => {
	i.length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "tongbo-take",
			min: i.length,
			max: i.length,
			data: {
				give: i,
				pool: [...e.seats[t].shu]
			}
		}
	});
}, jl = (e, t, n, r, i, a, o, s, c) => {
	let l = r.give, u = e.seats[t];
	for (let n of l) W(e, t, n), u.shu.push(n);
	for (let n of i) {
		let r = u.shu.indexOf(n);
		r >= 0 && u.shu.splice(r, 1), e.hands[t].push(n);
	}
	c.push({
		kind: "give",
		rid: u.rid,
		data: {
			from: t,
			to: t,
			n: l.length
		},
		for: [u.rid],
		secret: { cards: l }
	});
	for (let e of i) c.push({
		kind: "reveal",
		rid: u.rid,
		data: {
			seat: t,
			card: e
		}
	});
	L(e, {
		kind: "tongbo",
		seat: t,
		cards: R(e, [...l, ...i])
	}), e.beatMs = J.play;
	let d = new Set(u.shu.map((t) => e.cards[t].suit));
	u.shu.length >= 4 && d.size >= 4 && e.queue.unshift({
		k: "tongbo-step",
		seat: t,
		cards: [...u.shu],
		idx: 0
	});
}, Ml = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.cardId;
	if (l == null) return;
	let d = e.seats[t], f = d.shu.indexOf(u);
	f >= 0 && d.shu.splice(f, 1), e.hands[l].push(u), c.push({
		kind: "give",
		rid: d.rid,
		data: {
			from: t,
			to: l,
			n: 1
		},
		for: [d.rid, e.seats[l].rid],
		secret: { cards: [u] }
	}), L(e, {
		kind: "tongbo-give",
		seat: t,
		target: l,
		cards: R(e, [u])
	}), e.queue.unshift({
		k: "tongbo-step",
		seat: t,
		cards: r.cards,
		idx: (r.idx ?? 0) + 1
	});
}, Nl = {
	bizhuan: Ol,
	tongbo: kl
}, Pl = {
	"tongbo-swap": Al,
	"tongbo-take": jl
}, Fl = { "tongbo-give": Ml }, Il = (e, t, n, r, i) => {
	let a = e.seats[t], o = [];
	for (let t = 0; t < 4; t++) {
		if (e.deck.length === 0) {
			if (e.discard.length === 0) break;
			e.deck = Pv(e, e.discard), e.discard = [];
		}
		let t = e.deck.shift();
		if (t == null) break;
		o.push(t);
	}
	if (o.length !== 0) {
		for (let e of o) i.push({
			kind: "reveal",
			rid: a.rid,
			data: {
				seat: t,
				card: e
			}
		});
		L(e, {
			kind: "chengxiang",
			seat: t,
			n: o.length,
			cards: R(e, o)
		}), e.beatMs = J.draw, e.pending = {
			kind: "skill-cards",
			seats: [t],
			ctx: {
				skill: "chengxiang-take",
				min: 0,
				max: o.length,
				data: {
					pool: o,
					chain: {
						seat: t,
						skill: "chengxiang",
						data: r
					}
				}
			}
		};
	}
}, Ll = (e, t, n, r, i) => {
	let a = [...e.hands[t].filter((t) => O(e.cards[t].name) === "equip"), ...K(e, t)];
	if (a.length === 0) {
		Fy(e, r.ev, i);
		return;
	}
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "renxin-discard",
			min: 1,
			max: 1,
			data: {
				pool: a,
				ev: r.ev
			}
		}
	};
}, Rl = (e, t, n, r, i) => {
	Fy(e, r.ev, i), e.beatMs = J.damage;
}, zl = (e, t, n, r, i, a, o, s, c) => {
	if (i.reduce((t, n) => t + e.cards[n].point, 0) > 13) return q("games.sanguosha.error.badChoose");
	let l = r.pool.filter((e) => !i.includes(e));
	i.length > 0 && (e.hands[t].push(...i), c.push({
		kind: "take",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: i.length
		},
		for: [e.seats[t].rid],
		secret: { cards: i }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "chengxiang",
		n: i.length
	}), e.beatMs = J.draw), l.length > 0 && U(e, l);
	let u = r.chain;
	return u && (u.data.amountLeft = 1, $_(e, u.seat, u.skill, u.data)) || Z(e, c), {
		state: e,
		fx: c
	};
}, Bl = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (W(e, t, l)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === l && (e.seats[t].equips[n] = null);
		I(e, t, l, c);
	}
	return U(e, [l]), pv(e, [l], c, t), dv(e, [l], t), Jv(e, t, c), L(e, {
		kind: "renxin",
		seat: t
	}), e.beatMs = J.play, e.pending || Z(e, c), {
		state: e,
		fx: c
	};
}, Vl = {
	chengxiang: Il,
	renxin: Ll
}, Hl = { renxin: Rl }, Ul = {
	"chengxiang-take": zl,
	"renxin-discard": Bl
}, Wl = (e, t, n, r, i, a, o, s) => {
	let c = i, l = n.option, u = Ey(e).indexOf(l);
	if (u < 0) return q("games.sanguosha.error.badChoose");
	e.seats[t].marks.shouxi = (e.seats[t].marks.shouxi ?? 0) | 1 << u, L(e, {
		kind: "shouxi",
		seat: t,
		card: l,
		target: c.from
	}), e.beatMs = J.play;
	let d = e.seats[c.from].alive ? [...e.hands[c.from], ...K(e, c.from)].filter((t) => e.cards[t].name === l) : [];
	return d.length > 0 ? (e.pending = {
		kind: "skill-cards",
		seats: [c.from],
		ctx: {
			skill: "shouxi-discard",
			min: 0,
			max: 1,
			data: {
				pool: d,
				resume: c.resume,
				target: t
			}
		}
	}, Z(e, s), {
		state: e,
		fx: s
	}) : (L(e, {
		kind: "shouxi-null",
		seat: t,
		target: c.from
	}), Z(e, s), {
		state: e,
		fx: s
	});
}, Gl = (e, t, n, r) => {
	e.queue.unshift(r.resume);
}, Kl = (e, t, n, r, i, a, o, s, c) => {
	let l = r;
	if (i.length === 0) {
		L(e, {
			kind: "shouxi-null",
			seat: l.target,
			target: t
		});
		return;
	}
	Qv(e, t, i, c), L(e, {
		kind: "discard",
		seat: t,
		n: i.length,
		cards: R(e, i)
	}), e.beatMs = J.discard, e.queue.unshift(l.resume), e.seats[l.target].alive && et(e, l.target, "snatch").length > 0 && (e.pending = {
		kind: "pick-zone",
		seats: [t],
		ctx: {
			trick: "snatch",
			from: t,
			target: l.target
		}
	});
}, ql = (e, t, n, r, i) => {
	let a = z(e).filter((t) => e.hands[t].length < e.seats[t].hp);
	if (a.length === 0) return;
	let o = H(e, t, a.length);
	i.push({
		kind: "draw",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: o.length
		},
		for: [e.seats[t].rid],
		secret: { cards: o }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: n,
		n: o.length
	}), e.beatMs = J.draw;
	let s = Math.min(o.length, e.hands[t].length);
	s !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "huimin-show",
			min: s,
			max: s,
			data: { needy: a }
		}
	});
}, Jl = (e, t, n, r, i, a, o, s, c) => {
	for (let n of i) W(e, t, n);
	for (let n of i) c.push({
		kind: "reveal",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: n
		}
	});
	L(e, {
		kind: "huimin-show",
		seat: t,
		cards: R(e, i)
	}), e.beatMs = J.play, F(e, t, i.length), e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "huimin-start",
			min: 1,
			max: 1,
			data: {
				candidates: r.needy,
				shown: i,
				needy: r.needy
			}
		}
	};
}, Yl = (e, t, n, r, i) => {
	let a = i[0];
	if (a == null) return;
	let o = r.needy, s = B(e, a).filter((t) => o.includes(t) && e.seats[t].alive);
	e.queue.unshift({
		k: "huimin-pick",
		seats: s,
		idx: 0,
		shown: r.shown
	});
}, Xl = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (l == null) return;
	e.hands[t].push(l), c.push({
		kind: "take",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: 1
		},
		for: [e.seats[t].rid],
		secret: { cards: [l] }
	}), L(e, {
		kind: "huimin-take",
		seat: t,
		cards: R(e, [l])
	}), e.beatMs = J.play;
	let u = (r.pool ?? []).filter((e) => e !== l);
	e.queue.unshift({
		k: "huimin-pick",
		seats: r.seats,
		idx: (r.idx ?? 0) + 1,
		shown: u
	});
}, Zl = { huimin: ql }, Ql = { shouxi: Gl }, $l = { shouxi: Wl }, eu = {
	"shouxi-discard": Kl,
	"huimin-show": Jl,
	"huimin-take": Xl
}, tu = { "huimin-start": Yl }, nu = (e, t, n, r) => {
	let i = z(e);
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "huituo-target",
			min: 1,
			max: 1,
			data: {
				candidates: i,
				amount: r.amountLeft,
				liyu: r.liyu ?? null
			}
		}
	};
}, ru = (e, t, n, r, i) => {
	let a = r.lord;
	e.seats[a].alive && (e.seats[a].hp += 1, i.push({
		kind: "recover",
		rid: e.seats[a].rid,
		data: {
			seat: a,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: a,
		n: 1
	}), e.beatMs = J.recover), r.yes.push(t), My(e, r, i);
}, iu = (e, t, n, r, i) => {
	My(e, r, i);
}, au = (e, t, n, r, i) => r >= 1 && i.length > 0 ? {
	minCards: r,
	maxCards: r,
	minTargets: 1,
	maxTargets: 1,
	targets: i
} : null, ou = (e, t, n, r, i, a, o) => {
	let s = i[0];
	for (let n of r) W(e, t, n);
	return e.hands[s].push(...r), o.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: s,
			n: r.length
		},
		for: [e.seats[t].rid, e.seats[s].rid],
		secret: { cards: r }
	}), L(e, {
		kind: "mingjian",
		seat: t,
		target: s,
		n: r.length
	}), e.seats[s].flags.mjBuff = !0, e.beatMs = J.play, F(e, t, r.length), hv(e, s, t, r.length, o), {
		state: e,
		fx: o
	};
}, su = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	e.seats[l].alive && nt(e, l, "huituo", {
		x: r.amount ?? 1,
		liyu: r.liyu ?? null
	}, c);
}, cu = {
	huituo: nu,
	xingshuai: ru
}, lu = { xingshuai: iu }, uu = { mingjian: au }, du = { mingjian: ou }, fu = { "huituo-target": su }, pu = (e, t, n, r, i, a, o, s) => {
	let c = i.ev, l = i.x;
	return L(e, {
		kind: "skill",
		seat: c.source,
		card: "qingxi"
	}), n.option === "qx-discard" ? e.hands[t].length < l ? q("games.sanguosha.error.badChoose") : (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "qingxi-discard",
			min: l,
			max: l,
			data: {
				ev: c,
				pool: [...e.hands[t]]
			}
		}
	}, {
		state: e,
		fx: s
	}) : (c.amount += 1, L(e, {
		kind: "qingxi-plus",
		seat: c.source,
		target: t
	}), Py(e, c, s), e.beatMs = J.damage, e.pending || Z(e, s), {
		state: e,
		fx: s
	});
}, mu = (e, t, n, r, i, a, o, s, c) => {
	let l = r.ev;
	Qv(e, t, i, c);
	let u = l.source, d = e.seats[u].equips.weapon;
	return d != null && e.seats[u].alive && (e.seats[u].equips.weapon = null, U(e, [d]), I(e, u, d, c)), L(e, {
		kind: "qingxi-discard",
		seat: t,
		n: i.length,
		cards: R(e, [...i, ...d == null ? [] : [d]])
	}), e.beatMs = J.discard, Py(e, l, c), e.pending || Z(e, c), {
		state: e,
		fx: c
	};
}, hu = { qingxi: pu }, gu = { "qingxi-discard": mu }, _u = { new_jiangchi: (e, t, n, r, i, a, o, s) => (L(e, {
	kind: "skill",
	seat: t,
	card: "new_jiangchi"
}), n.option === "jc-more" ? (e.seats[t].flags.jcMore = !0, e.seats[t].flags.jcNoSlash = !0) : (e.seats[t].flags.jcLess = !0, e.seats[t].flags.jcBuff = !0), Z(e, s), {
	state: e,
	fx: s
}) }, vu = { xinsidi: (e, t, n, r) => {
	let i = r.pool.filter((n) => e.hands[t].includes(n) || K(e, t).includes(n));
	i.length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "sidi-discard",
			min: 1,
			max: 1,
			data: {
				pool: i,
				target: r.target
			}
		}
	});
} }, yu = (e, t) => Uv(e, t) > 0 ? {
	minCards: 0,
	maxCards: 0,
	minTargets: 0,
	maxTargets: 0,
	targets: []
} : null, bu = (e, t, n, r, i, a, o) => {
	let s = H(e, t, 1);
	return e.seats[t].flags.jishe = (e.seats[t].flags.jishe ?? 0) + 1, o.push({
		kind: "draw",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: s.length
		},
		for: [e.seats[t].rid],
		secret: { cards: s }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "jishe",
		n: s.length
	}), e.beatMs = J.draw, {
		state: e,
		fx: o
	};
}, xu = (e, t, n, r, i, a, o, s, c) => {
	if (i.length > 0) {
		L(e, {
			kind: "skill",
			seat: t,
			card: "jishe"
		});
		for (let t of i) e.seats[t].alive && !e.seats[t].chained && ny(e, t, c);
		e.beatMs = J.play;
	}
}, Su = { jishe: yu }, Cu = { jishe: bu }, wu = { "jishe-chain": xu }, Tu = (e, t, n) => !n.turnedOver && !n.flags.analepticUsed ? {
	minCards: 0,
	maxCards: 0,
	minTargets: 0,
	maxTargets: 0,
	targets: []
} : null, Eu = (e, t, n, r, i, a, o) => (Jv(e, t, o), e.seats[t].flags.analeptic = !0, e.seats[t].flags.analepticUsed = !0, L(e, {
	kind: "analeptic",
	seat: t
}), e.beatMs = J.play, e.pending, {
	state: e,
	fx: o
}), Du = { jiushi: Tu }, Ou = { jiushi: Eu }, ku = (e, t, n, r, i) => (e.hands[t].some((t) => A(e.cards[t].name) || k(e.cards[t].name) != null) || K(e, t).length > 0) && i.length > 0 ? {
	minCards: 1,
	maxCards: 1,
	minTargets: 1,
	maxTargets: 1,
	targets: i,
	allowEquip: !0
} : null, Au = (e, t, n, r, i, a, o) => {
	let s = i[0], c = r[0];
	if (W(e, t, c)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === c && (e.seats[t].equips[n] = null);
		I(e, t, c, o);
	}
	e.hands[s].push(c), o.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: s,
			n: 1
		},
		for: [e.seats[t].rid, e.seats[s].rid],
		secret: { cards: [c] }
	}), L(e, {
		kind: "mingce",
		seat: t,
		target: s
	}), hv(e, s, t, 1, o);
	let l = px(e, s), u = l.length > 0 ? ["mc-slash", "mc-draw"] : ["mc-draw"];
	return e.pending = {
		kind: "skill-ask",
		seats: [s],
		ctx: {
			skill: "mingce-choice",
			options: u,
			noPass: !0,
			from: t,
			data: {
				giver: t,
				victims: l
			}
		}
	}, {
		state: e,
		fx: o
	};
}, ju = (e, t, n, r, i, a, o, s) => {
	let c = i.giver;
	if (n.option === "mc-slash" && e.seats[c].alive) {
		let n = i.victims.filter((t) => e.seats[t].alive && !N(e, t));
		if (n.length > 0) return e.pending = {
			kind: "skill-seats",
			seats: [c],
			ctx: {
				skill: "mingce-victim",
				min: 1,
				max: 1,
				data: {
					candidates: n,
					from: t
				}
			}
		}, {
			state: e,
			fx: s
		};
	}
	let l = H(e, t, 1);
	return s.push({
		kind: "draw",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: l.length
		},
		for: [e.seats[t].rid],
		secret: { cards: l }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "mingce",
		n: l.length
	}), e.beatMs = J.draw, Z(e, s), {
		state: e,
		fx: s
	};
}, Mu = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from, u = i[0];
	e.seats[l].alive && (L(e, {
		kind: "skill",
		seat: l,
		card: "mingce"
	}), c.push({
		kind: "play",
		rid: e.seats[l].rid,
		data: {
			seat: l,
			name: "slash"
		}
	}), L(e, {
		kind: "use",
		seat: l,
		card: "slash",
		target: u
	}), e.queue.unshift({
		k: "slash-target",
		from: l,
		target: u,
		cardName: "slash",
		suit: null,
		cardId: null
	}));
}, Nu = { mingce: ku }, Pu = { mingce: Au }, Fu = { "mingce-choice": ju }, Iu = { "mingce-victim": Mu }, Lu = (e, t, n, r, i) => {
	let a = e.seats[t], o = r.target;
	if (a.chun.length === 0 || !e.seats[o].alive) {
		jy(e, o, {
			source: r.source ?? null,
			chunDone: !0,
			...r.dmg ? { dmg: r.dmg } : {},
			...r.zx ? { zx: r.zx } : {}
		}, i);
		return;
	}
	if (U(e, [a.chun.shift()]), e.seats[o].hp += 1, i.push({
		kind: "recover",
		rid: e.seats[o].rid,
		data: {
			seat: o,
			n: 1,
			by: "chunlao"
		}
	}), L(e, {
		kind: "chunlao-save",
		seat: t,
		target: o
	}), e.beatMs = J.recover, my(e), e.seats[o].hp <= 0) {
		jy(e, o, {
			source: r.source ?? null,
			chunDone: !0,
			...r.dmg ? { dmg: r.dmg } : {},
			...r.zx ? { zx: r.zx } : {}
		}, i);
		return;
	}
	X(e, o);
	let s = r.dmg;
	s && e.queue.unshift(s);
	let c = r.zx;
	c && c > 0 && Iy(e, o, c);
}, Ru = (e, t, n, r, i) => {
	jy(e, r.target, {
		source: r.source ?? null,
		chunDone: !0,
		...r.dmg ? { dmg: r.dmg } : {},
		...r.zx ? { zx: r.zx } : {}
	}, i);
}, zu = (e, t, n, r, i) => {
	for (let n of i) W(e, t, n), e.seats[t].chun.push(n);
	i.length > 0 && (F(e, t, i.length), L(e, {
		kind: "chunlao-put",
		seat: t,
		n: i.length,
		cards: R(e, i)
	}), e.beatMs = J.play);
}, Bu = { "chunlao-save": Lu }, Vu = { "chunlao-save": Ru }, Hu = { "chunlao-put": zu }, Uu = (e, t, n, r, i) => {
	let a = r.target;
	if (!e.seats[a].alive) return;
	let o = H(e, a, 1);
	i.push({
		kind: "draw",
		rid: e.seats[a].rid,
		data: {
			seat: a,
			n: o.length
		},
		for: [e.seats[a].rid],
		secret: { cards: o }
	}), L(e, {
		kind: "skill-draw",
		seat: a,
		card: "faen",
		n: o.length
	}), e.beatMs = J.draw, P(e, a, o);
}, Wu = (e, t, n, r, i) => {
	let a = n.flags.pindiTy ?? 0, o = n.flags.pindiT ?? 0, s = [
		"basic",
		"trick",
		"equip"
	].filter((e) => (a & {
		basic: 1,
		trick: 2,
		equip: 4
	}[e]) === 0), c = [...e.hands[t], ...K(e, t)].filter((t) => s.includes(O(e.cards[t].name))), l = i.filter((e) => !(o >> e & 1));
	return c.length > 0 && l.length > 0 ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: l,
		allowEquip: !0,
		classes: [...s]
	} : null;
}, Gu = (e, t, n, r, i, a, o) => {
	let s = i[0], c = r[0], l = {
		basic: 1,
		trick: 2,
		equip: 4
	}[O(e.cards[c].name)], u = (e.seats[t].flags.pindiN ?? 0) + 1;
	e.seats[t].flags.pindiTy = (e.seats[t].flags.pindiTy ?? 0) | l, e.seats[t].flags.pindiT = (e.seats[t].flags.pindiT ?? 0) | 1 << s, e.seats[t].flags.pindiN = u, Qv(e, t, [c], o), L(e, {
		kind: "pindi",
		seat: t,
		target: s,
		cards: R(e, [c])
	}), e.beatMs = J.discard, e.seats[s].alive && e.seats[s].hp < e.seats[s].maxHp && ny(e, t, o);
	let d = e.seats[s].alive ? [...e.hands[s], ...K(e, s)] : [];
	return e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "pindi-choice",
			options: d.length > 0 ? ["pd-draw", "pd-discard"] : ["pd-draw"],
			noPass: !0,
			data: {
				target: s,
				x: u
			}
		}
	}, {
		state: e,
		fx: o
	};
}, Ku = (e, t, n, r, i, a, o, s) => {
	let c = i.target, l = i.x;
	if (!e.seats[c].alive) return Z(e, s), {
		state: e,
		fx: s
	};
	if (n.option === "pd-draw") {
		let t = H(e, c, l);
		s.push({
			kind: "draw",
			rid: e.seats[c].rid,
			data: {
				seat: c,
				n: t.length
			},
			for: [e.seats[c].rid],
			secret: { cards: t }
		}), L(e, {
			kind: "skill-draw",
			seat: c,
			card: "pindi",
			n: t.length
		}), e.beatMs = J.draw, P(e, c, t);
	} else {
		let t = [...e.hands[c], ...K(e, c)], n = Math.min(l, t.length);
		if (n > 0) return e.pending = {
			kind: "skill-cards",
			seats: [c],
			ctx: {
				skill: "pindi-discard",
				min: n,
				max: n,
				data: { pool: t }
			}
		}, {
			state: e,
			fx: s
		};
	}
	return Z(e, s), {
		state: e,
		fx: s
	};
}, qu = (e, t, n, r, i, a, o, s, c) => {
	Qv(e, t, i, c), L(e, {
		kind: "pindi-discard",
		seat: t,
		n: i.length,
		cards: R(e, i)
	}), e.beatMs = J.discard;
}, Ju = { faen: Uu }, Yu = { pindi: Wu }, Xu = { pindi: Gu }, Zu = { "pindi-choice": Ku }, Qu = { "pindi-discard": qu }, $u = (e, t, n, r) => {
	let i = r.candidates.filter((t) => e.seats[t].alive);
	if (i.length === 0) {
		e.queue.unshift(r.resume);
		return;
	}
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "qiuyuan-target",
			min: 1,
			max: 1,
			data: {
				candidates: i,
				resume: r.resume,
				info: r.info
			}
		}
	};
}, ed = (e, t, n, r) => {
	e.hands[t].length !== 0 && e.hands[r.target].length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "zhuikong-pick",
			min: 1,
			max: 1,
			data: {
				pool: [...e.hands[t]],
				target: r.target
			}
		}
	});
}, td = (e, t, n, r) => {
	e.queue.unshift(r.resume);
}, nd = (e, t, n, r, i, a, o, s) => {
	let c = i.info;
	if (L(e, {
		kind: "skill",
		seat: c.target,
		card: "qiuyuan"
	}), n.option === "qy-give") {
		let n = e.hands[t].filter((t) => e.cards[t].name === "jink");
		return n.length === 0 ? q("games.sanguosha.error.badChoose") : (e.pending = {
			kind: "skill-cards",
			seats: [t],
			ctx: {
				skill: "qiuyuan-jink",
				min: 1,
				max: 1,
				data: {
					pool: n,
					giveTo: c.target,
					resume: i.resume
				}
			}
		}, {
			state: e,
			fx: s
		});
	}
	return e.queue.unshift(i.resume), e.queue.unshift({
		k: "slash-target",
		from: c.from,
		target: t,
		cardName: c.cardName,
		suit: c.suit,
		cardId: c.cardId,
		ana: c.ana,
		qyDone: !0
	}), L(e, {
		kind: "qiuyuan-become",
		seat: t,
		target: c.target
	}), Z(e, s), {
		state: e,
		fx: s
	};
}, rd = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.giveTo;
	return W(e, t, l), e.hands[u].push(l), c.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: u,
			n: 1
		},
		for: [e.seats[t].rid, e.seats[u].rid],
		secret: { cards: [l] }
	}), L(e, {
		kind: "qiuyuan-give",
		seat: t,
		target: u,
		cards: R(e, [l])
	}), F(e, t, 1), e.beatMs = J.play, e.queue.unshift(r.resume), Z(e, c), {
		state: e,
		fx: c
	};
}, id = (e, t, n, r, i, a, o, s, c) => (e.pending = {
	kind: "skill-cards",
	seats: [r.target],
	ctx: {
		skill: "zhuikong-respond",
		min: 1,
		max: 1,
		data: {
			from: t,
			myCard: i[0]
		}
	}
}, {
	state: e,
	fx: c
}), ad = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from;
	return Z_(e, l, t, r.myCard, Q_(e, l, t) ?? i[0], "zhuikong", c) ? (e.seats[t].flags.zkSelf = !0, L(e, {
		kind: "zhuikong-win",
		seat: l,
		target: t
	})) : (e.seats[t].flags.zkNear = l + 1, L(e, {
		kind: "zhuikong-lose",
		seat: l,
		target: t
	})), e.beatMs = J.play, Z(e, c), {
		state: e,
		fx: c
	};
}, od = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = e.hands[l].some((t) => e.cards[t].name === "jink") ? ["qy-give", "qy-target"] : ["qy-target"];
	return e.pending = {
		kind: "skill-ask",
		seats: [l],
		ctx: {
			skill: "qiuyuan-choice",
			options: u,
			noPass: !0,
			data: {
				target: l,
				info: r.info,
				resume: r.resume
			}
		}
	}, {
		state: e,
		fx: c
	};
}, sd = {
	qiuyuan: $u,
	zhuikong: ed
}, cd = { qiuyuan: td }, ld = { "qiuyuan-choice": nd }, ud = {
	"qiuyuan-jink": rd,
	"zhuikong-pick": id,
	"zhuikong-respond": ad
}, dd = { "qiuyuan-target": od }, fd = (e, t, n, r, i) => {
	let a = i.filter((t) => e.hands[t].length > 0);
	return r >= 1 && a.length > 0 ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, pd = (e, t, n, r, i, a, o) => (e.pending = {
	kind: "skill-cards",
	seats: [i[0]],
	ctx: {
		skill: "xinxianzhen",
		min: 1,
		max: 1,
		data: {
			from: t,
			myCard: r[0]
		}
	}
}, {
	state: e,
	fx: o
}), md = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from;
	Z_(e, l, t, r.myCard, Q_(e, l, t) ?? i[0], "xinxianzhen", c) ? (e.seats[l].flags.xianzhen = t, L(e, {
		kind: "xianzhen-win",
		seat: l,
		target: t
	})) : (e.seats[l].flags.xianzhenLose = !0, L(e, {
		kind: "xianzhen-lose",
		seat: l
	})), e.beatMs = J.play;
}, hd = { xinxianzhen: fd }, gd = (e, t, n, r) => {
	let i = r.xz, a = {
		from: r.from,
		cardName: r.cardName,
		suit: r.suit,
		cardId: r.cardId,
		ana: r.ana,
		...r.lihuo ? { lihuo: !0 } : {}
	};
	e.seats[i].alive && !N(e, i) && (e.queue.unshift({
		k: "slash-target",
		...a,
		target: i
	}), L(e, {
		kind: "tianyi-extra",
		seat: r.from,
		target: i
	})), e.queue.unshift({
		k: "slash-target",
		...a,
		target: r.target
	});
}, _d = (e, t, n, r) => {
	e.queue.unshift({
		k: "slash-target",
		from: r.from,
		target: r.target,
		cardName: r.cardName,
		suit: r.suit,
		cardId: r.cardId,
		ana: r.ana,
		...r.lihuo ? { lihuo: !0 } : {}
	});
}, vd = (e, t, n, r) => {
	let i = r.xz, a = r.name, o = r.from, s = r.target, c = r.cardId;
	e.seats[i].alive && !N(e, i) && (e.queue.unshift({
		k: "trick-nullify",
		name: a,
		from: o,
		target: i,
		cardId: c
	}), L(e, {
		kind: "tianyi-extra",
		seat: o,
		target: i
	})), Qe(e, o, a, s, {
		k: "trick-effect",
		name: a,
		from: o,
		target: s,
		cardId: c
	});
}, yd = (e, t, n, r) => {
	let i = r.name, a = r.from, o = r.target;
	Qe(e, a, i, o, {
		k: "trick-effect",
		name: i,
		from: a,
		target: o,
		cardId: r.cardId
	});
}, bd = {
	"xianzhen-add": gd,
	"xianzhen-add-trick": vd
}, xd = {
	"xianzhen-add": _d,
	"xianzhen-add-trick": yd
}, Sd = { xinxianzhen: pd }, Cd = { xinxianzhen: md }, wd = (e, t, n, r) => r >= 1 ? {
	minCards: 0,
	maxCards: 0,
	minTargets: 0,
	maxTargets: 0,
	targets: []
} : null, Td = (e, t, n, r, i, a, o) => {
	o.push({
		kind: "reveal-hand",
		rid: e.seats[t].rid,
		data: {
			target: t,
			cards: [...e.hands[t]]
		}
	}), L(e, {
		kind: "huaiyi-show",
		seat: t,
		n: e.hands[t].length
	});
	let s = e.hands[t].filter((t) => G(e, t)).length, c = e.hands[t].length - s;
	return e.beatMs = J.play, e.hands[t].length <= 1 || s === 0 || c === 0 || (e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "huaiyi-color",
			options: ["hy-red", "hy-black"],
			noPass: !0,
			data: {}
		}
	}), {
		state: e,
		fx: o
	};
}, Ed = (e, t, n, r, i, a, o, s) => {
	let c = n.option === "hy-red" ? "red" : "black", l = e.hands[t].filter((t) => (G(e, t) ? "red" : "black") === c);
	for (let n of l) W(e, t, n);
	U(e, l), L(e, {
		kind: "huaiyi-drop",
		seat: t,
		n: l.length,
		cards: R(e, l)
	}), e.beatMs = J.discard, F(e, t, l.length);
	let u = z(e).filter((n) => n !== t && (e.hands[n].length > 0 || K(e, n).length > 0));
	return l.length > 0 && u.length > 0 ? (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "huaiyi-targets",
			min: 1,
			max: l.length,
			data: { candidates: u }
		}
	}, {
		state: e,
		fx: s
	}) : (e.pending || Z(e, s), {
		state: e,
		fx: s
	});
}, Dd = (e, t, n, r, i, a, o, s, c) => {
	let l = 0;
	for (let n of i) {
		if (!e.seats[n].alive) continue;
		let r = [...e.hands[n], ...K(e, n)];
		if (r.length === 0) continue;
		let i = r[Nv(e, r.length)];
		if (W(e, n, i)) F(e, n, 1);
		else {
			for (let t of [
				"weapon",
				"armor",
				"off_horse",
				"def_horse"
			]) e.seats[n].equips[t] === i && (e.seats[n].equips[t] = null);
			I(e, n, i, c);
		}
		e.hands[t].push(i), c.push({
			kind: "take",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				from: n
			},
			for: [e.seats[t].rid, e.seats[n].rid],
			secret: { card: i }
		}), l += 1;
	}
	L(e, {
		kind: "huaiyi-gain",
		seat: t,
		n: l
	}), e.beatMs = J.play, l >= 2 && Ly(e, t, 1, c);
}, Od = { huaiyi: wd }, kd = { huaiyi: Td }, Ad = { "huaiyi-color": Ed }, jd = { "huaiyi-targets": Dd }, Md = (e, t, n, r) => {
	let i = [...e.hands[t], ...K(e, t)];
	i.length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "longyin-discard",
			min: 1,
			max: 1,
			data: {
				pool: i,
				from: r.from,
				red: r.red
			}
		}
	});
}, Nd = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (W(e, t, l)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === l && (e.seats[t].equips[n] = null);
		I(e, t, l, c);
	}
	if (U(e, [l]), pv(e, [l], c, t), dv(e, [l], t), e.turn != null && e.turn.slashUsed > 0 && --e.turn.slashUsed, L(e, {
		kind: "longyin",
		seat: t,
		target: r.from
	}), r.red === !0) {
		let n = H(e, t, 1);
		c.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "longyin",
			n: n.length
		});
	}
	return e.beatMs = J.play, Z(e, c), {
		state: e,
		fx: c
	};
}, Pd = { longyin: Md }, Fd = { "longyin-discard": Nd }, Id = { rejingce: (e, t, n, r, i) => {
	let a = e.seats[t], o = r.x ?? 0;
	if (o > 0) {
		let n = H(e, t, o);
		i.push({
			kind: "draw",
			rid: a.rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [a.rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "rejingce",
			n: n.length
		}), e.beatMs = J.draw;
	}
} }, Ld = (e, t, n, r, i) => {
	if (r < 1) return null;
	if ((e.seats[t].marks.xindanxin ?? 0) >= 2) return {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: [t]
	};
	if (i.length === 0) return null;
	let a = Math.min(...i.map((n) => V(e, t, n)));
	return {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: i.filter((n) => V(e, t, n) === a)
	};
}, Rd = (e, t, n, r, i, a, o) => {
	let s = r[0], c = i[0];
	return o.push({
		kind: "reveal",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: s
		}
	}), e.beatMs = J.play, e.pending = {
		kind: "skill-ask",
		seats: [c],
		ctx: {
			skill: "jiaozhao-name",
			options: xy(e, t),
			noPass: !0,
			data: {
				holder: t,
				cardId: s
			}
		}
	}, {
		state: e,
		fx: o
	};
}, zd = (e, t, n, r, i, a, o, s) => {
	let c = i.holder, l = i.cardId, u = by.indexOf(n.option);
	return u < 0 ? q("games.sanguosha.error.badChoose") : (e.seats[c].alive && e.hands[c].includes(l) && (e.seats[c].flags.jzCard = l, e.seats[c].flags.jzName = u + 1, L(e, {
		kind: "skill",
		seat: c,
		card: "jiaozhao"
	})), Z(e, s), {
		state: e,
		fx: s
	});
}, Bd = (e, t, n, r, i, a, o, s) => (L(e, {
	kind: "skill",
	seat: t,
	card: r
}), n.option === "dx-modify" ? e.seats[t].marks.xindanxin = (e.seats[t].marks.xindanxin ?? 0) + 1 : (H(e, t, 1), L(e, {
	kind: "skill-draw",
	seat: t,
	card: r,
	n: 1
}), e.beatMs = J.draw), $_(e, t, r, i) || Z(e, s), {
	state: e,
	fx: s
}), Vd = (e, t, n, r) => {
	$_(e, t, n, r);
}, Hd = { jiaozhao: Ld }, Ud = { jiaozhao: Rd }, Wd = {
	"jiaozhao-name": zd,
	danxin: Bd
}, Gd = { danxin: Vd }, Kd = (e, t, n, r, i) => {
	let a = e.seats[t], o = H(e, t, 2);
	i.push({
		kind: "draw",
		rid: a.rid,
		data: {
			seat: t,
			n: o.length
		},
		for: [a.rid],
		secret: { cards: o }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "jigong",
		n: o.length
	}), a.flags.jigong = !0, a.flags.jgongDmg = 0, e.beatMs = J.draw;
}, qd = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.jinkCtx;
	if (c.push({
		kind: "dodge",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			by: "shifei"
		}
	}), L(e, {
		kind: "jink",
		seat: t,
		card: "jink"
	}), e.beatMs = J.respond, _y(e, t, "jink"), Re(e, t, l, c), u.count = (u.count ?? 0) + 1, u.count < (u.need ?? 1)) return e.pending = {
		kind: "jink",
		seats: [t],
		ctx: u
	}, {
		state: e,
		fx: c
	};
	if (Ie(e, t, u, c, null)) return {
		state: e,
		fx: c
	};
}, Jd = { jigong: Kd }, Yd = { "shifei-target": qd }, Xd = (e, t, n, r, i) => {
	let a = e.seats[t], o = [...e.hands[t]];
	i.push({
		kind: "reveal-hand",
		rid: a.rid,
		data: {
			target: t,
			cards: o
		}
	}), L(e, {
		kind: "olbingyi",
		seat: t,
		cards: R(e, o)
	});
	let s = o.filter((t) => G(e, t)).length;
	(s === 0 || s === o.length) && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "bingyi-targets",
			min: 0,
			max: o.length,
			data: { candidates: z(e).filter((e) => e !== t) }
		}
	});
}, Zd = (e, t, n, r) => r + K(e, t).length >= 2 ? {
	minCards: 2,
	maxCards: 2,
	minTargets: 0,
	maxTargets: 0,
	targets: [],
	allowEquip: !0
} : null, Qd = (e, t, n, r, i, a, o) => {
	Qv(e, t, r, o);
	let s = H(e, t, 1);
	return o.push({
		kind: "draw",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: s.length
		},
		for: [e.seats[t].rid],
		secret: { cards: s }
	}), L(e, {
		kind: "shenxing",
		seat: t,
		cards: R(e, r)
	}), e.beatMs = J.draw, P(e, t, s), {
		state: e,
		fx: o
	};
}, $d = { olbingyi: Xd }, ef = { shenxing: Zd }, tf = { shenxing: Qd }, nf = (e, t, n, r) => r + K(e, t).length >= 1 ? {
	minCards: 0,
	maxCards: 0,
	minTargets: 0,
	maxTargets: 0,
	targets: []
} : null, rf = (e, t, n) => n.limitedUsed.includes("jiefan") ? null : {
	minCards: 0,
	maxCards: 0,
	minTargets: 1,
	maxTargets: 1,
	targets: z(e)
}, af = (e, t, n, r, i, a, o) => {
	let s = [...e.hands[t], ...K(e, t)];
	return e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "gongji-discard",
			min: 1,
			max: 1,
			data: { pool: s }
		}
	}, {
		state: e,
		fx: o
	};
}, of = (e, t, n, r, i, a, o) => {
	e.seats[t].limitedUsed.push("jiefan");
	let s = i[0];
	L(e, {
		kind: "jiefan",
		seat: t,
		target: s
	});
	let c = B(e, t).filter((t) => V(e, t, s) <= Bv(e, t));
	return e.queue.unshift({
		k: "jiefan-step",
		seats: c,
		target: s,
		from: t
	}), Z(e, o), {
		state: e,
		fx: o
	};
}, sf = (e, t, n, r, i, a, o, s) => {
	let c = i.target, l = i.rest, u = () => e.queue.unshift({
		k: "jiefan-step",
		seats: l,
		target: c,
		from: i.from
	});
	if (n.option === "jf-discard") return e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "jiefan-discard",
			min: 1,
			max: 1,
			data: {
				pool: i.weapons,
				target: c,
				rest: l,
				from: i.from
			}
		}
	}, {
		state: e,
		fx: s
	};
	if (e.seats[c].alive) {
		let t = H(e, c, 1);
		s.push({
			kind: "draw",
			rid: e.seats[c].rid,
			data: {
				seat: c,
				n: t.length
			},
			for: [e.seats[c].rid],
			secret: { cards: t }
		}), L(e, {
			kind: "skill-draw",
			seat: c,
			card: "jiefan",
			n: t.length
		}), e.beatMs = J.draw;
	}
	return u(), Z(e, s), {
		state: e,
		fx: s
	};
}, cf = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	W(e, t, l) ? F(e, t, 1) : (e.seats[t].equips.weapon === l && (e.seats[t].equips.weapon = null), I(e, t, l, c)), U(e, [l]), pv(e, [l], c, t), dv(e, [l], t), L(e, {
		kind: "discard-skill",
		seat: t,
		card: "jiefan",
		cards: R(e, [l])
	}), e.beatMs = J.discard, e.queue.unshift({
		k: "jiefan-step",
		seats: r.rest,
		target: r.target,
		from: r.from
	});
}, lf = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = !W(e, t, l);
	if (!u) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === l && (e.seats[t].equips[n] = null);
		I(e, t, l, c);
	}
	if (U(e, [l]), pv(e, [l], c, t), dv(e, [l], t), e.seats[t].flags.gongjiRange = !0, L(e, {
		kind: "discard-skill",
		seat: t,
		card: "gongji",
		cards: R(e, [l])
	}), e.beatMs = J.discard, u) {
		let n = z(e).filter((n) => n !== t && fx(e, n));
		n.length > 0 && (e.pending = {
			kind: "skill-seats",
			seats: [t],
			ctx: {
				skill: "gongji-target",
				min: 1,
				max: 1,
				data: { candidates: n }
			}
		});
	}
}, uf = (e, t, n, r, i, a, o, s, c) => {
	let l = Zv(e, i[0], c);
	l != null && L(e, {
		kind: "discard",
		seat: i[0],
		n: 1,
		cards: R(e, [l])
	});
}, df = {
	gongji: nf,
	jiefan: rf
}, ff = {
	gongji: af,
	jiefan: of
}, pf = { "jiefan-step": sf }, mf = {
	"jiefan-discard": cf,
	"gongji-discard": lf
}, hf = { "gongji-target": uf }, gf = (e, t, n, r, i) => {
	let a = r.target;
	if (!e.seats[a].alive) return;
	let o = e.seats[a].judges[0];
	o != null && (e.seats[a].judges.shift(), U(e, [o]), L(e, {
		kind: "yonglve",
		seat: t,
		target: a,
		cards: R(e, [o])
	}), dv(e, [o], a), pv(e, [o], i, a), e.queue.unshift({
		k: "slash-target",
		from: t,
		target: a,
		cardName: "slash",
		suit: null,
		cardId: null,
		ylFrom: t
	}));
}, _f = (e, t, n, r) => {
	let i = r.cards.filter((t) => e.discard.includes(t));
	i.length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "shenduan-pick",
			min: 1,
			max: 1,
			data: {
				pool: i,
				candidates: r.candidates
			}
		}
	});
}, vf = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (!e.discard.includes(l)) return;
	let u = r.candidates.filter((t) => e.seats[t].alive && !e.seats[t].judges.some((t) => uy(e, t) === "supply_shortage"));
	if (u.length !== 0) return e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "shenduan-target",
			min: 1,
			max: 1,
			data: {
				candidates: u,
				cardId: l
			}
		}
	}, {
		state: e,
		fx: c
	};
}, yf = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.cardId, d = e.discard.indexOf(u);
	d < 0 || !e.seats[l].alive || e.seats[l].judges.some((t) => uy(e, t) === "supply_shortage") || (e.discard.splice(d, 1), e.seats[l].judges.push(u), e.judgeNames[u] = "supply_shortage", c.push({
		kind: "place-judge",
		data: {
			seat: l,
			card: u,
			name: "supply_shortage"
		}
	}), L(e, {
		kind: "shenduan",
		seat: t,
		target: l,
		cards: R(e, [u])
	}), e.beatMs = J.play);
}, bf = {
	yonglve: gf,
	shenduan: _f
}, xf = { "shenduan-pick": vf }, Sf = { "shenduan-target": yf }, Cf = (e, t, n, r, i, a, o, s, c) => {
	if (i.length === 0) return;
	L(e, {
		kind: "skill",
		seat: t,
		card: "qinqing"
	});
	let l = e.seats.findIndex((e) => e.identity === "lord");
	for (let t of i) {
		if (!e.seats[t].alive) continue;
		let n = Zv(e, t, c);
		n != null && L(e, {
			kind: "discard",
			seat: t,
			n: 1,
			cards: R(e, [n])
		});
		let r = H(e, t, 1);
		r.length > 0 && c.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: r.length
			},
			for: [e.seats[t].rid],
			secret: { cards: r }
		});
	}
	let u = l >= 0 ? e.hands[l].length : 0, d = i.filter((t) => e.seats[t].alive && e.hands[t].length > u).length;
	if (d > 0) {
		let n = H(e, t, d);
		c.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "qinqing",
			n: n.length
		});
	}
	e.beatMs = J.draw;
}, wf = (e, t, n, r, i, a, o, s, c) => {
	let l = r.ev, u = l.source;
	if (u == null || !e.seats[u].alive) {
		Py(e, l, c, !0, !0);
		return;
	}
	for (let n of i) c.push({
		kind: "reveal",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: n
		}
	});
	L(e, {
		kind: "skill",
		seat: t,
		card: "huisheng",
		n: i.length
	}), e.beatMs = J.play;
	let d = e.hands[u].length + K(e, u).length >= i.length ? ["hs-take", "hs-discard"] : ["hs-take"];
	return e.pending = {
		kind: "skill-ask",
		seats: [u],
		ctx: {
			skill: "huisheng",
			options: d,
			noPass: !0,
			data: {
				ev: l,
				shown: i,
				offerer: t
			}
		}
	}, {
		state: e,
		fx: c
	};
}, Tf = (e, t, n, r, i, a, o, s) => {
	let c = i.shown, l = i.offerer, u = i.ev;
	if (n.option === "hs-discard") {
		let n = [...e.hands[t], ...K(e, t)];
		return e.pending = {
			kind: "skill-cards",
			seats: [t],
			ctx: {
				skill: "huisheng-pay",
				min: c.length,
				max: c.length,
				data: {
					ev: u,
					offerer: l,
					pool: n
				}
			}
		}, {
			state: e,
			fx: s
		};
	}
	return e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "huisheng-pick",
			min: 1,
			max: 1,
			data: {
				ev: u,
				offerer: l,
				pool: c
			}
		}
	}, {
		state: e,
		fx: s
	};
}, Ef = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.offerer;
	e.hands[u].includes(l) && (W(e, u, l), e.hands[t].push(l), F(e, u, 1), c.push({
		kind: "take",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			from: u
		},
		for: [e.seats[t].rid, e.seats[u].rid],
		secret: { card: l }
	}), hv(e, t, u, 1, c)), e.seats[u].marks.hsBan = (e.seats[u].marks.hsBan ?? 0) | 1 << t, L(e, {
		kind: "skill",
		seat: u,
		card: "huisheng"
	}), e.beatMs = J.play;
}, Df = (e, t, n, r, i, a, o, s, c) => {
	Qv(e, t, i, c), e.beatMs = J.discard;
	let l = r.ev;
	Py(e, l, c, !0, !0);
}, Of = { qinqing: Cf }, kf = {
	"huisheng-offer": wf,
	"huisheng-pick": Ef,
	"huisheng-pay": Df
}, Af = { huisheng: Tf }, jf = (e, t) => {
	let n = z(e).filter((n) => n !== t && e.hands[n].length > 0);
	n.length !== 0 && e.hands[t].length !== 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "qiaoshui-target",
			min: 1,
			max: 1,
			data: { candidates: n }
		}
	});
}, Mf = (e, t, n, r, i, a, o, s, c) => (e.pending = {
	kind: "skill-cards",
	seats: [r.target],
	ctx: {
		skill: "qiaoshui-respond",
		min: 1,
		max: 1,
		data: {
			from: t,
			myCard: i[0]
		}
	}
}, {
	state: e,
	fx: c
}), Nf = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from;
	return Z_(e, l, t, r.myCard, Q_(e, l, t) ?? i[0], "qiaoshui", c) ? (e.seats[l].flags.qsAdd = !0, L(e, {
		kind: "qiaoshui-win",
		seat: l
	})) : (e.seats[l].flags.qsNoTrick = !0, L(e, {
		kind: "qiaoshui-lose",
		seat: l
	})), e.beatMs = J.play, Z(e, c), {
		state: e,
		fx: c
	};
}, Pf = (e, t, n, r, i, a, o, s, c) => (e.pending = {
	kind: "skill-cards",
	seats: [t],
	ctx: {
		skill: "qiaoshui-pick",
		min: 1,
		max: 1,
		data: {
			pool: [...e.hands[t]],
			target: i[0]
		}
	}
}, {
	state: e,
	fx: c
}), Ff = { qiaoshui: jf }, If = {
	"qiaoshui-pick": Mf,
	"qiaoshui-respond": Nf
}, Lf = { "qiaoshui-target": Pf };
//#endregion
//#region src/games/sanguosha/rules/skills/yijiang/jikang.ts
function Rf(e, t) {
	return K(e, t).length;
}
function zf(e, t, n, r, i, a) {
	if (Qv(e, t, n, i), a) for (let n of r) e.seats[t].marks.cyAll = (e.seats[t].marks.cyAll ?? 0) | 1 << n;
	let o = Rf(e, t);
	for (let t of r) {
		if (!e.seats[t].alive) continue;
		let n = Rf(e, t);
		if (o > n) e.seats[t].hp < e.seats[t].maxHp && (e.seats[t].hp += 1, i.push({
			kind: "recover",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: 1
			}
		}), L(e, {
			kind: "recover",
			seat: t,
			n: 1
		}));
		else if (o === n) {
			let n = H(e, t, 1);
			i.push({
				kind: "draw",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					n: n.length
				},
				for: [e.seats[t].rid],
				secret: { cards: n }
			}), L(e, {
				kind: "draw",
				seat: t,
				n: n.length
			});
		} else Ly(e, t, 1, i);
	}
	if (n.length === e.seats[t].hp) {
		let n = H(e, t, 1);
		i.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "qingxian",
			n: n.length
		});
	}
	e.beatMs = J.play;
}
var Bf = (e, t, n, r, i) => {
	let a = Math.min(n.hp, r);
	return a >= 1 && i.length > 0 ? {
		minCards: 1,
		maxCards: a,
		minTargets: 1,
		maxTargets: a,
		targets: i
	} : null;
}, Vf = (e, t, n, r, i, a, o) => r.length === i.length ? (L(e, {
	kind: "skill",
	seat: t,
	card: "qingxian"
}), zf(e, t, r, i, o, !1), {
	state: e,
	fx: o
}) : q("games.sanguosha.error.badChoose"), Hf = (e, t, n, r, i) => {
	let a = n.marks.cyAll ?? 0, o = i.filter((e) => !(a & 1 << e)), s = Math.min(n.hp, r);
	return s >= 1 && o.length > 0 ? {
		minCards: 1,
		maxCards: s,
		minTargets: 1,
		maxTargets: s,
		targets: o
	} : null;
}, Uf = (e, t, n, r, i, a, o) => {
	if (r.length !== i.length) return q("games.sanguosha.error.badChoose");
	let s = e.seats[t].marks.cyAll ?? 0;
	return i.some((e) => !!(s & 1 << e)) ? q("games.sanguosha.error.badChoose") : (L(e, {
		kind: "skill",
		seat: t,
		card: "canyun"
	}), zf(e, t, r, i, o, !0), {
		state: e,
		fx: o
	});
}, Wf = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (l == null) return;
	e.seats[l].skills.includes("canyun") || e.seats[l].skills.push("canyun"), L(e, {
		kind: "skill",
		seat: t,
		card: n,
		target: l
	});
	let u = [];
	for (let t of z(e)) {
		for (let n of K(e, t)) e.cards[n].suit === "club" && u.push({
			seat: t,
			card: n,
			judge: !1
		});
		for (let n of e.seats[t].judges) e.cards[n].suit === "club" && u.push({
			seat: t,
			card: n,
			judge: !0
		});
	}
	if (u.length > 0) {
		let t = u[Nv(e, u.length)];
		if (t.judge) {
			let n = e.seats[t.seat].judges.indexOf(t.card);
			n >= 0 && e.seats[t.seat].judges.splice(n, 1), delete e.judgeNames[t.card];
		} else {
			let n = e.seats[t.seat].equips;
			for (let e of [
				"weapon",
				"armor",
				"off_horse",
				"def_horse"
			]) n[e] === t.card && (n[e] = null);
			I(e, t.seat, t.card, c);
		}
		U(e, [t.card]), c.push({
			kind: "discard",
			rid: e.seats[t.seat].rid,
			data: {
				seat: t.seat,
				n: 1,
				cards: [t.card]
			}
		}), L(e, {
			kind: "discard",
			seat: t.seat,
			n: 1,
			cards: R(e, [t.card])
		}), e.beatMs = J.discard;
	}
	e.seats[l].skills.includes("juexiang") || e.seats[l].skills.push("juexiang");
}, Gf = {
	qingxian: Bf,
	canyun: Hf
}, Kf = {
	qingxian: Vf,
	canyun: Uf
}, qf = { "juexiang-target": Wf }, Jf = (e, t, n, r, i) => {
	let a = e.seats[t];
	a.limitedUsed.push("fuli");
	let o = Math.min(ey(e), a.maxHp);
	a.hp < o && (a.hp = o, i.push({
		kind: "recover",
		rid: a.rid,
		data: {
			seat: t,
			n: o,
			by: "fuli"
		}
	})), L(e, {
		kind: "fuli",
		seat: t,
		n: o
	}), a.turnedOver || Jv(e, t, i), e.beatMs = J.recover, my(e);
	let s = r.dmg;
	s && e.queue.unshift(s);
	let c = r.zx;
	c && c > 0 && Iy(e, t, c);
}, Yf = (e, t, n, r, i) => {
	jy(e, t, {
		source: r.source ?? null,
		fuliDone: !0,
		...r.dmg ? { dmg: r.dmg } : {},
		...r.zx ? { zx: r.zx } : {}
	}, i);
}, Xf = { fuli: Jf }, Zf = { fuli: Yf }, Qf = (e, t) => {
	let n = z(e).filter((n) => n !== t && (e.hands[n].length > 0 || K(e, n).length > 0));
	n.length !== 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "xuanfeng-target",
			min: 1,
			max: 2,
			data: { candidates: n }
		}
	});
}, $f = (e, t, n, r, i, a, o, s, c) => {
	let l = i.length === 1 ? 2 : 1;
	for (let n of i) {
		let r = 0, i = [];
		for (let t = 0; t < l; t++) {
			let t = [...e.hands[n], ...K(e, n)];
			if (t.length === 0) break;
			let a = t[Nv(e, t.length)];
			if (W(e, n, a)) r += 1;
			else {
				for (let t of [
					"weapon",
					"armor",
					"off_horse",
					"def_horse"
				]) e.seats[n].equips[t] === a && (e.seats[n].equips[t] = null);
				I(e, n, a, c);
			}
			U(e, [a]), pv(e, [a], c, n), dv(e, [a], n), i.push(a);
		}
		i.length > 0 && L(e, {
			kind: "xuanfeng",
			seat: t,
			target: n,
			n: i.length,
			cards: R(e, i)
		}), r > 0 && F(e, n, r);
	}
	e.beatMs = J.discard;
}, ep = { xuanfeng: Qf }, tp = { "xuanfeng-target": $f }, np = (e, t, n, r, i) => {
	let a = i.filter((t) => e.hands[t].length > 0);
	return a.length > 0 ? {
		minCards: 0,
		maxCards: 0,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, rp = (e, t, n, r, i, a, o) => {
	let s = i[0];
	if (e.hands[s].length > 0) {
		let n = e.hands[s][Nv(e, e.hands[s].length)];
		W(e, s, n), e.hands[t].push(n), F(e, s, 1), o.push({
			kind: "take",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				from: s
			},
			for: [e.seats[t].rid, e.seats[s].rid],
			secret: { card: n }
		}), hv(e, t, s, 1, o);
	}
	return e.beatMs = J.play, e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "dcduliang",
			options: ["dl-view", "dl-next"],
			noPass: !0,
			data: { target: s }
		}
	}, {
		state: e,
		fx: o
	};
}, ip = (e, t, n, r, i, a, o, s) => {
	let c = i.target;
	if (L(e, {
		kind: "skill",
		seat: t,
		card: r
	}), n.option === "dl-next") return e.seats[c].marks.duliang = 1, Z(e, s), {
		state: e,
		fx: s
	};
	e.deck.length === 0 && e.discard.length > 0 && (e.deck = Pv(e, e.discard), e.discard = []);
	let l = e.deck.splice(0, Math.min(2, e.deck.length));
	if (l.length > 0) {
		s.push({
			kind: "reveal",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				cards: l
			}
		}), L(e, {
			kind: "skill-show",
			seat: t,
			card: r,
			cards: R(e, l)
		});
		let n = l.filter((t) => O(e.cards[t].name) === "basic"), i = l.filter((t) => O(e.cards[t].name) !== "basic");
		n.length > 0 && e.seats[c].alive && (e.hands[c].push(...n), s.push({
			kind: "take",
			rid: e.seats[c].rid,
			data: {
				seat: c,
				from: -1
			},
			for: [e.seats[c].rid],
			secret: { cards: n }
		})), i.length > 0 && e.deck.unshift(...i), e.beatMs = J.draw;
	}
	return Z(e, s), {
		state: e,
		fx: s
	};
}, ap = { dcduliang: np }, op = { dcduliang: rp }, sp = { dcduliang: ip }, cp = { rezishou: (e, t, n, r) => {
	let i = e.seats[t];
	i.flags.zishouN = r.n, i.flags.zishou = !0;
} }, lp = (e, t, n, r, i) => {
	if (r === 0 || n.flags.zjOff) return null;
	let a = i.filter((t) => !N(e, t));
	return a.length > 0 ? {
		minCards: r,
		maxCards: r,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, up = (e, t, n, r, i, a, o) => {
	let s = i[0];
	for (let n of r) W(e, t, n);
	return U(e, r), L(e, {
		kind: "zhanjue",
		seat: t,
		target: s,
		n: r.length
	}), e.seats[t].flags.zjHurt = 0, e.beatMs = J.play, F(e, t, r.length), pv(e, r, o, t), e.queue.unshift({
		k: "zj-draw",
		seat: t
	}), Qe(e, t, "duel", s, {
		k: "trick-effect",
		name: "duel",
		from: t,
		target: s,
		cardId: null,
		zj: t
	}), e.pending || Z(e, o), {
		state: e,
		fx: o
	};
}, dp = (e, t, n, r, i, a, o, s, c) => (Qv(e, t, i, c), e.pending = {
	kind: "lord-call",
	seats: B(e, t).filter((n) => n !== t && $v(e, n) === "shu"),
	ctx: {
		lord: t,
		need: "slash",
		resume: r.resume,
		qinwang: !0
	}
}, {
	state: e,
	fx: c
}), fp = { zhanjue: lp }, pp = { zhanjue: up }, mp = { "qinwang-discard": dp }, hp = (e, t) => {
	let n = z(e).filter((n) => n !== t && e.hands[n].length + K(e, n).length > 0);
	n.length !== 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "xiansi-pick",
			min: 1,
			max: 2,
			data: { candidates: n }
		}
	});
}, gp = (e, t, n, r, i, a, o, s, c) => {
	for (let n of i) {
		if (!e.seats[n].alive) continue;
		let r = [...e.hands[n], ...K(e, n)];
		if (r.length === 0) continue;
		let i = r[Nv(e, r.length)];
		if (W(e, n, i)) F(e, n, 1);
		else {
			for (let t of [
				"weapon",
				"armor",
				"off_horse",
				"def_horse"
			]) e.seats[n].equips[t] === i && (e.seats[n].equips[t] = null);
			I(e, n, i, c);
		}
		e.seats[t].ni.push(i), L(e, {
			kind: "xiansi",
			seat: t,
			target: n,
			n: e.seats[t].ni.length
		});
	}
	e.beatMs = J.play;
}, _p = { xiansi: hp }, vp = { "xiansi-pick": gp }, yp = (e, t, n, r, i) => {
	if (r <= n.hp) return null;
	let a = i.filter((n) => V(e, n, t) <= Bv(e, n));
	return a.length > 0 ? {
		minCards: 0,
		maxCards: 0,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, bp = (e, t, n, r, i, a, o) => {
	let s = i[0], c = e.hands[s].some((t) => A(e.cards[t].name)) && px(e, s).length > 0, l = K(e, s).length > 0, u = [...c ? ["zg-slash"] : [], ...l ? ["zg-give"] : []];
	return u.length === 0 || (e.pending = {
		kind: "skill-ask",
		seats: [s],
		ctx: {
			skill: "zhige",
			options: u,
			noPass: !0,
			data: { from: t }
		}
	}), {
		state: e,
		fx: o
	};
}, xp = (e, t, n, r, i, a, o, s) => {
	let c = i.from;
	return n.option === "zg-give" ? (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "zg-equip",
			min: 1,
			max: 1,
			data: {
				from: c,
				pool: K(e, t)
			}
		}
	}, {
		state: e,
		fx: s
	}) : (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "zg-slash-card",
			min: 1,
			max: 1,
			data: {
				from: c,
				pool: e.hands[t].filter((t) => A(e.cards[t].name))
			}
		}
	}, {
		state: e,
		fx: s
	});
}, Sp = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (!e.hands[t].includes(l) || !A(e.cards[l].name)) return;
	W(e, t, l), U(e, [l]), F(e, t, 1), Iv(e, l, e.cards[l].name, t), e.beatMs = J.play;
	let u = px(e, t);
	if (u.length !== 0) return e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "zg-slash-target",
			min: 1,
			max: 1,
			data: {
				candidates: u,
				cardId: l
			}
		}
	}, {
		state: e,
		fx: c
	};
}, Cp = (e, t, n, r, i) => {
	let a = i[0], o = r.cardId;
	e.seats[t].alive && e.seats[a].alive && e.queue.unshift({
		k: "slash-target",
		from: t,
		target: a,
		cardName: e.cards[o].name,
		suit: dy(e, t, o),
		cardId: o,
		ana: 0
	});
}, wp = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from, u = i[0], d = k(e.cards[u].name);
	d != null && e.seats[t].equips[d] === u && (e.seats[t].equips[d] = null, e.hands[l].push(u), I(e, t, u, c), c.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: l,
			n: 1
		},
		for: [e.seats[t].rid, e.seats[l].rid],
		secret: { cards: [u] }
	}), hv(e, l, t, 1, c), e.beatMs = J.play);
}, Tp = { zhige: yp }, Ep = { zhige: bp }, Dp = { zhige: xp }, Op = {
	"zg-slash-card": Sp,
	"zg-equip": wp
}, kp = { "zg-slash-target": Cp }, Ap = (e, t, n, r) => {
	if (e.hands[t].length === 0) {
		$_(e, t, "yuce", r);
		return;
	}
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "yuce-show",
			min: 1,
			max: 1,
			data: {
				pool: [...e.hands[t]],
				chain: {
					seat: t,
					skill: "yuce",
					data: r
				}
			}
		}
	};
}, jp = (e, t, n, r, i) => r >= 1 && i.length > 0 ? {
	minCards: 1,
	maxCards: r,
	minTargets: 1,
	maxTargets: 1,
	targets: i
} : null, Mp = (e, t, n, r, i, a, o) => {
	let s = i[0];
	Qv(e, t, r, o);
	let c = r.map((t) => O(e.cards[t].name));
	if (L(e, {
		kind: "junxing",
		seat: t,
		target: s,
		n: r.length
	}), e.beatMs = J.play, !e.seats[s].alive) return {
		state: e,
		fx: o
	};
	let l = e.hands[s].some((t) => !c.includes(O(e.cards[t].name))) ? ["jx-discard", "jx-flip"] : ["jx-flip"];
	return e.pending = {
		kind: "skill-ask",
		seats: [s],
		ctx: {
			skill: "junxing-choice",
			options: l,
			noPass: !0,
			data: {
				x: r.length,
				classes: c,
				from: t
			}
		}
	}, {
		state: e,
		fx: o
	};
}, Np = (e, t, n, r, i, a, o, s) => {
	if (L(e, {
		kind: "skill",
		seat: i.from ?? t,
		card: "junxing"
	}), n.option === "jx-flip") {
		Jv(e, t, s);
		let n = i.x ?? 0;
		if (n > 0) {
			let r = H(e, t, n);
			s.push({
				kind: "draw",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					n: r.length
				},
				for: [e.seats[t].rid],
				secret: { cards: r }
			}), L(e, {
				kind: "skill-draw",
				seat: t,
				card: "junxing",
				n: r.length
			}), e.beatMs = J.draw;
		}
		return L(e, {
			kind: "junxing-flip",
			seat: t
		}), e.pending || Z(e, s), {
			state: e,
			fx: s
		};
	}
	let c = i.classes, l = e.hands[t].filter((t) => !c.includes(O(e.cards[t].name)));
	return l.length === 0 ? q("games.sanguosha.error.badChoose") : (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "junxing-discard",
			min: 1,
			max: 1,
			data: { pool: l }
		}
	}, {
		state: e,
		fx: s
	});
}, Pp = (e, t, n, r, i, a, o, s) => {
	let c = i.chain;
	if (n.option === "yc-recover") return e.seats[c.seat].alive && e.seats[c.seat].hp < e.seats[c.seat].maxHp && (e.seats[c.seat].hp += 1, s.push({
		kind: "recover",
		rid: e.seats[c.seat].rid,
		data: {
			seat: c.seat,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: c.seat,
		n: 1
	}), e.beatMs = J.recover), $_(e, c.seat, c.skill, c.data) || Z(e, s), {
		state: e,
		fx: s
	};
	let l = i.shownClass, u = e.hands[t].filter((t) => O(e.cards[t].name) !== l);
	return u.length === 0 ? ($_(e, c.seat, c.skill, c.data) || Z(e, s), {
		state: e,
		fx: s
	}) : (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "yuce-source-discard",
			min: 1,
			max: 1,
			data: {
				pool: u,
				chain: c
			}
		}
	}, {
		state: e,
		fx: s
	});
}, Fp = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	return W(e, t, l), U(e, [l]), pv(e, [l], c, t), dv(e, [l], t), F(e, t, 1), L(e, {
		kind: "junxing-discard",
		seat: t,
		cards: R(e, [l])
	}), e.beatMs = J.discard, Z(e, c), {
		state: e,
		fx: c
	};
}, Ip = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	c.push({
		kind: "reveal",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: l
		}
	}), L(e, {
		kind: "yuce-show",
		seat: t,
		cards: R(e, [l])
	});
	let u = r.chain, d = u.data.source ?? null, f = O(e.cards[l].name);
	if (d == null || !e.seats[d].alive) return $_(e, u.seat, u.skill, u.data) || Z(e, c), {
		state: e,
		fx: c
	};
	let p = e.hands[d].some((t) => O(e.cards[t].name) !== f), m = e.seats[t].hp < e.seats[t].maxHp, h = [...p ? ["yc-discard"] : [], ...m ? ["yc-recover"] : []];
	return h.length === 0 ? ($_(e, u.seat, u.skill, u.data) || Z(e, c), {
		state: e,
		fx: c
	}) : (e.pending = {
		kind: "skill-ask",
		seats: [d],
		ctx: {
			skill: "yuce-source",
			options: h,
			noPass: !0,
			data: {
				shownClass: f,
				chain: u
			}
		}
	}, {
		state: e,
		fx: c
	});
}, Lp = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	W(e, t, l), U(e, [l]), pv(e, [l], c, t), dv(e, [l], t), F(e, t, 1), L(e, {
		kind: "yuce-discard",
		seat: t,
		cards: R(e, [l])
	}), e.beatMs = J.discard;
	let u = r.chain;
	return $_(e, u.seat, u.skill, u.data) || Z(e, c), {
		state: e,
		fx: c
	};
}, Rp = { yuce: Ap }, zp = { junxing: jp }, Bp = { junxing: Mp }, Vp = {
	"junxing-choice": Np,
	"yuce-source": Pp
}, Hp = {
	"junxing-discard": Fp,
	"yuce-show": Ip,
	"yuce-source-discard": Lp
}, Up = (e, t, n, r, i) => {
	let a = e.seats[t], o = H(e, t, 1);
	i.push({
		kind: "draw",
		rid: a.rid,
		data: {
			seat: t,
			n: o.length
		},
		for: [a.rid],
		secret: { cards: o }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "qianxi",
		n: o.length
	}), e.beatMs = J.draw, P(e, t, o);
	let s = [...e.hands[t], ...K(e, t)];
	s.length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "qianxi-discard",
			min: 1,
			max: 1,
			data: { pool: s }
		}
	});
}, Wp = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (W(e, t, l)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === l && (e.seats[t].equips[n] = null);
		I(e, t, l, c);
	}
	U(e, [l]), pv(e, [l], c, t), dv(e, [l], t), L(e, {
		kind: "discard-skill",
		seat: t,
		card: "qianxi",
		cards: R(e, [l])
	}), e.beatMs = J.discard;
	let u = G(e, l) ? "red" : "black", d = z(e).filter((n) => n !== t && V(e, t, n) <= 1);
	d.length > 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "qianxi-target",
			min: 1,
			max: 1,
			data: {
				candidates: d,
				color: u
			}
		}
	});
}, Gp = (e, t, n, r, i) => {
	e.seats[i[0]].flags.qianxiRed = r.color === "red", L(e, {
		kind: "qianxi",
		seat: t,
		target: i[0]
	});
}, Kp = { qianxi: Up }, qp = { "qianxi-discard": Wp }, Jp = { "qianxi-target": Gp }, Yp = (e, t, n, r) => {
	let i = [...e.hands[t], ...K(e, t)];
	if (i.length === 0) {
		$_(e, t, "duodao", r);
		return;
	}
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "duodao-discard",
			min: 1,
			max: 1,
			data: {
				pool: i,
				source: r.source,
				chain: {
					seat: t,
					skill: "duodao",
					data: r
				}
			}
		}
	};
}, Xp = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (W(e, t, l)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === l && (e.seats[t].equips[n] = null);
		I(e, t, l, c);
	}
	U(e, [l]), pv(e, [l], c, t), dv(e, [l], t);
	let u = r.source;
	if (e.seats[u].alive && e.seats[u].equips.weapon != null) {
		let n = e.seats[u].equips.weapon;
		e.seats[u].equips.weapon = null, e.hands[t].push(n), I(e, u, n, c), c.push({
			kind: "take",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				from: u
			},
			for: [e.seats[t].rid],
			secret: { card: n }
		}), L(e, {
			kind: "duodao",
			seat: t,
			target: u,
			cards: R(e, [n])
		});
	}
	e.beatMs = J.play;
	let d = r.chain;
	return d && (d.data.amountLeft = 1, $_(e, d.seat, d.skill, d.data)) || Z(e, c), {
		state: e,
		fx: c
	};
}, Zp = { duodao: Yp }, Qp = { "duodao-discard": Xp }, $p = (e, t, n, r, i, a, o, s, c) => {
	let l = r;
	if (i.length === 0) return Le(e, l.from, l.cardName, l.suit, l.cardId, l.target, l.ana, l.lihuo, c);
	let u = i[0];
	W(e, t, u), e.deck.unshift(u), c.push({
		kind: "reveal",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: u
		}
	}), L(e, {
		kind: "jianzheng",
		seat: t,
		target: l.from
	}), e.beatMs = J.play, F(e, t, 1), (l.suit === "heart" || l.suit === "diamond") && e.queue.unshift({
		k: "slash-target",
		from: l.from,
		target: t,
		cardName: l.cardName,
		suit: l.suit,
		cardId: l.cardId,
		ana: l.ana,
		...l.lihuo ? { lihuo: !0 } : {}
	});
}, em = (e, t, n, r) => {
	if (Y(e, t, "tianbian") && e.deck.length > 0) {
		e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "tianbian-choice",
				options: ["tb-hand", "tb-top"],
				noPass: !0,
				data: r
			}
		};
		return;
	}
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "zhuandui-card",
			min: 1,
			max: 1,
			data: r
		}
	};
}, tm = (e, t, n, r) => {
	e.queue.unshift(r.resume);
}, nm = (e, t, n, r, i, a, o, s) => {
	let c = i;
	if (n.option === "tb-top") {
		let n = e.deck.shift();
		return s.push({
			kind: "reveal",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				card: n
			}
		}), L(e, {
			kind: "skill",
			seat: t,
			card: "tianbian"
		}), e.beatMs = J.play, e.pending = {
			kind: "skill-cards",
			seats: [c.from === t ? c.target : c.from],
			ctx: {
				skill: "zhuandui-respond",
				min: 1,
				max: 1,
				data: {
					...c,
					holder: t,
					myCard: n
				}
			}
		}, Z(e, s), {
			state: e,
			fx: s
		};
	}
	return e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "zhuandui-card",
			min: 1,
			max: 1,
			data: c
		}
	}, Z(e, s), {
		state: e,
		fx: s
	};
}, rm = (e, t, n, r, i) => {
	let a = r;
	e.pending = {
		kind: "skill-cards",
		seats: [a.from === t ? a.target : a.from],
		ctx: {
			skill: "zhuandui-respond",
			min: 1,
			max: 1,
			data: {
				...a,
				holder: t,
				myCard: i[0]
			}
		}
	};
}, im = (e, t, n, r, i, a, o, s, c) => {
	let l = r, u = Q_(e, l.holder, t) ?? i[0];
	Z_(e, l.holder, t, l.myCard, u, "zhuandui", c) ? l.holder === l.from ? e.queue.unshift({
		...l.resume,
		noJink: !0
	}) : L(e, {
		kind: "skill",
		seat: l.holder,
		card: "zhuandui"
	}) : e.queue.unshift(l.resume);
}, am = { zhuandui: em }, om = { zhuandui: tm }, sm = { "tianbian-choice": nm }, cm = {
	jianzheng: $p,
	"zhuandui-card": rm,
	"zhuandui-respond": im
}, lm = { "yaoming-target": (e, t, n, r, i, a, o, s, c) => {
	if (i.length === 1 && e.seats[i[0]].alive) {
		let n = i[0];
		if (e.seats[t].flags.ymDone = !0, L(e, {
			kind: "skill",
			seat: t,
			card: "yaoming"
		}), e.hands[n].length < e.hands[t].length) {
			let t = H(e, n, 1);
			c.push({
				kind: "draw",
				rid: e.seats[n].rid,
				data: {
					seat: n,
					n: t.length
				},
				for: [e.seats[n].rid],
				secret: { cards: t }
			}), L(e, {
				kind: "skill-draw",
				seat: n,
				card: "yaoming",
				n: t.length
			}), e.beatMs = J.draw;
		} else if (e.hands[n].length > 0) {
			let r = e.hands[n][Nv(e, e.hands[n].length)];
			W(e, n, r), U(e, [r]), c.push({
				kind: "discard",
				rid: e.seats[n].rid,
				data: {
					seat: n,
					n: 1,
					cards: [r]
				}
			}), L(e, {
				kind: "yaoming-drop",
				seat: t,
				target: n,
				cards: R(e, [r])
			}), e.beatMs = J.discard, F(e, n, 1), pv(e, [r], c, n), dv(e, [r], n);
		}
	}
} }, um = (e, t, n, r, i) => {
	let a = i.filter((t) => e.hands[t].length + K(e, t).length > 0);
	return a.length > 0 ? {
		minCards: 0,
		maxCards: 0,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, dm = (e, t, n, r, i, a, o) => {
	let s = i[0], c = [...e.hands[s], ...K(e, s)];
	return e.pending = {
		kind: "skill-cards",
		seats: [s],
		ctx: {
			skill: "kuangbi-put",
			min: 1,
			max: Math.min(3, c.length),
			data: {
				from: t,
				pool: c
			}
		}
	}, {
		state: e,
		fx: o
	};
}, fm = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from;
	if (e.seats[l].alive) {
		for (let n of i) {
			if (W(e, t, n)) F(e, t, 1);
			else {
				for (let r of [
					"weapon",
					"armor",
					"off_horse",
					"def_horse"
				]) e.seats[t].equips[r] === n && (e.seats[t].equips[r] = null);
				I(e, t, n, c);
			}
			e.seats[l].kb.push(n), e.seats[l].kbFrom.push(t);
		}
		c.push({
			kind: "give",
			rid: e.seats[t].rid,
			data: {
				from: t,
				to: l,
				n: i.length
			},
			for: [e.seats[t].rid, e.seats[l].rid],
			secret: { cards: i }
		}), hv(e, l, t, i.length, c), L(e, {
			kind: "skill",
			seat: l,
			card: "kuangbi",
			n: i.length
		}), e.beatMs = J.play;
	}
}, pm = { kuangbi: um }, mm = { kuangbi: dm }, hm = { "kuangbi-put": fm }, gm = (e, t, n, r, i) => {
	let a = r.ev, o = [...e.hands[t], ...K(e, t)].filter((t) => O(e.cards[t].name) === "equip");
	if (o.length === 0) {
		Fy(e, {
			k: "damage",
			...a
		}, i);
		return;
	}
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "jiaojin-discard",
			min: 1,
			max: 1,
			data: {
				pool: o,
				ev: a
			}
		}
	};
}, _m = (e, t, n, r) => {
	let i = r.candidates.filter((t) => e.seats[t].alive);
	if (i.length === 0) {
		e.queue.unshift(r.resume);
		return;
	}
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "chanhui-pick",
			min: 1,
			max: 1,
			data: {
				candidates: i,
				target: r.target,
				resume: r.resume
			}
		}
	};
}, vm = (e, t, n, r, i) => {
	Fy(e, r.ev, i), e.beatMs = J.damage;
}, ym = (e, t, n, r) => {
	e.queue.unshift(r.resume);
}, bm = (e, t, n, r, i, a, o, s) => {
	let c = i.resume, l = i.from;
	return n.option === "ch-give" && e.hands[t].length > 0 ? (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "chanhui-give",
			min: 1,
			max: 1,
			data: {
				pool: [...e.hands[t]],
				to: l,
				resume: {
					...c,
					from: t
				}
			}
		}
	}, {
		state: e,
		fx: s
	}) : (L(e, {
		kind: "chanhui-extra",
		seat: l,
		target: t
	}), e.queue.unshift({
		...c,
		target: t
	}), e.queue.unshift(c), Z(e, s), {
		state: e,
		fx: s
	});
}, xm = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	Qv(e, t, [l], c), L(e, {
		kind: "jiaojin",
		seat: t,
		cards: R(e, [l])
	});
	let u = r.ev;
	u.amount > 1 && Fy(e, {
		...u,
		amount: u.amount - 1
	}, c), e.beatMs = J.damage;
}, Sm = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.to;
	W(e, t, l) && (F(e, t, 1), e.hands[u].push(l), c.push({
		kind: "take",
		rid: e.seats[u].rid,
		data: {
			seat: u,
			from: t
		},
		for: [e.seats[u].rid, e.seats[t].rid],
		secret: { card: l }
	}), L(e, {
		kind: "chanhui-give",
		seat: t,
		target: u
	})), e.queue.unshift(r.resume);
}, Cm = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (!e.seats[l].alive) {
		e.queue.unshift(r.resume);
		return;
	}
	let u = e.hands[l].length > 0 ? ["ch-give", "ch-target"] : ["ch-target"];
	return L(e, {
		kind: "chanhui",
		seat: t,
		target: l
	}), e.pending = {
		kind: "skill-ask",
		seats: [l],
		ctx: {
			skill: "chanhui-choice",
			options: u,
			noPass: !0,
			data: {
				from: t,
				target: r.target,
				resume: r.resume
			}
		}
	}, {
		state: e,
		fx: c
	};
}, wm = {
	jiaojin: gm,
	chanhui: _m
}, Tm = {
	jiaojin: vm,
	chanhui: ym
}, Em = { "chanhui-choice": bm }, Dm = {
	"jiaojin-discard": xm,
	"chanhui-give": Sm
}, Om = { "chanhui-pick": Cm }, km = (e, t, n, r, i) => {
	let a = i.filter((t) => e.hands[t].length + K(e, t).length > 0);
	return a.length > 0 ? {
		minCards: 0,
		maxCards: 0,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, Am = (e, t, n, r, i) => !n.limitedUsed.includes("xinzhaofu") && i.length > 0 ? {
	minCards: 0,
	maxCards: 0,
	minTargets: 1,
	maxTargets: Math.min(2, i.length),
	targets: i
} : null, jm = (e, t, n, r, i, a, o) => {
	let s = i[0];
	return K(e, s).length > 0 ? (e.pending = {
		kind: "skill-ask",
		seats: [s],
		ctx: {
			skill: "yanzhu-choice",
			options: ["yz-give", "yz-discard"],
			noPass: !0,
			data: { from: t }
		}
	}, {
		state: e,
		fx: o
	}) : (e.pending = {
		kind: "skill-cards",
		seats: [s],
		ctx: {
			skill: "yanzhu-discard",
			min: 1,
			max: 1,
			data: { pool: [...e.hands[s], ...K(e, s)] }
		}
	}, {
		state: e,
		fx: o
	});
}, Mm = (e, t, n, r, i, a, o) => {
	e.seats[t].limitedUsed.push("xinzhaofu");
	for (let n of i) e.seats[n].marks.zhaofu = t + 1, L(e, {
		kind: "xinzhaofu",
		seat: t,
		target: n
	});
	return e.beatMs = J.play, {
		state: e,
		fx: o
	};
}, Nm = (e, t, n, r, i, a, o, s) => {
	let c = i.from;
	if (L(e, {
		kind: "skill",
		seat: c,
		card: "yanzhu"
	}), n.option === "yz-give") {
		let n = K(e, t);
		for (let r of n) {
			let n = k(e.cards[r].name);
			n != null && (e.seats[t].equips[n] = null), e.hands[c].push(r), s.push({
				kind: "take",
				rid: e.seats[c].rid,
				data: {
					from: t,
					seat: c
				},
				for: [e.seats[c].rid],
				secret: { card: r }
			}), I(e, t, r, s);
		}
		L(e, {
			kind: "yanzhu-give",
			seat: t,
			target: c,
			n: n.length
		});
		let r = e.seats[c].skills.indexOf("yanzhu");
		return r >= 0 && e.seats[c].skills.splice(r, 1), e.pending || Z(e, s), {
			state: e,
			fx: s
		};
	}
	let l = [...e.hands[t], ...K(e, t)];
	return l.length === 0 ? (Z(e, s), {
		state: e,
		fx: s
	}) : (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "yanzhu-discard",
			min: 1,
			max: 1,
			data: { pool: l }
		}
	}, {
		state: e,
		fx: s
	});
}, Pm = (e, t, n, r, i, a, o, s, c) => {
	Qv(e, t, i, c), L(e, {
		kind: "yanzhu-discard",
		seat: t,
		cards: R(e, i)
	}), e.beatMs = J.discard;
}, Fm = (e, t, n, r, i) => {
	if (i.length > 0) {
		L(e, {
			kind: "skill",
			seat: t,
			card: "xingxue"
		});
		let n = B(e, t).filter((e) => i.includes(e));
		e.queue.unshift({
			k: "xx-step",
			targets: n,
			idx: 0
		});
	}
}, Im = {
	yanzhu: km,
	xinzhaofu: Am
}, Lm = {
	yanzhu: jm,
	xinzhaofu: Mm
}, Rm = { "yanzhu-choice": Nm }, zm = { "yanzhu-discard": Pm }, Bm = { "xingxue-targets": Fm }, Vm = (e, t, n, r, i) => {
	let a = n.flags.jyTargets ?? 0, o = i.filter((t) => !(a >> t & 1) && e.hands[t].length > 0);
	return o.length > 0 ? {
		minCards: 0,
		maxCards: 0,
		minTargets: 1,
		maxTargets: 1,
		targets: o
	} : null;
}, Hm = (e, t, n, r, i, a, o) => {
	let s = i[0];
	return e.pending = {
		kind: "skill-cards",
		seats: [s],
		ctx: {
			skill: "jiyu-discard",
			min: 1,
			max: 1,
			data: {
				from: t,
				pool: [...e.hands[s]]
			}
		}
	}, {
		state: e,
		fx: o
	};
}, Um = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from, u = i[0];
	if (!e.hands[t].includes(u)) return;
	let d = e.cards[u].suit;
	Qv(e, t, [u], c), L(e, {
		kind: "skill",
		seat: l,
		card: "jiyu",
		target: t
	}), L(e, {
		kind: "discard",
		seat: t,
		n: 1,
		cards: R(e, [u])
	});
	let f = e.seats[l].flags;
	f.jyTargets = (f.jyTargets ?? 0) | 1 << t, f.jySuits = (f.jySuits ?? 0) | {
		spade: 1,
		heart: 2,
		diamond: 4,
		club: 8
	}[d], e.beatMs = J.discard, d === "spade" && (Jv(e, l, c), Ly(e, t, 1, c));
}, Wm = (e, t, n, r, i, a, o, s) => (L(e, {
	kind: "skill",
	seat: t,
	card: r
}), n.option === "gz-recover" ? (e.seats[t].hp += 1, s.push({
	kind: "recover",
	rid: e.seats[t].rid,
	data: {
		seat: t,
		n: 1
	}
}), L(e, {
	kind: "recover",
	seat: t,
	n: 1
}), e.beatMs = J.recover) : (H(e, t, 1), L(e, {
	kind: "skill-draw",
	seat: t,
	card: r,
	n: 1
}), e.beatMs = J.draw), Z(e, s), {
	state: e,
	fx: s
}), Gm = { jiyu: Vm }, Km = { jiyu: Hm }, qm = { "jiyu-discard": Um }, Jm = { guizao: Wm }, Ym = (e, t, n, r, i) => {
	let a = e.seats[t], o = r.resume.from;
	if (Ly(e, t, 1, i), !e.pending && a.alive) {
		if (o != null && e.seats[o].alive && o !== t) {
			let n = Zv(e, o, i);
			n != null && L(e, {
				kind: "zhenlie",
				seat: t,
				target: o,
				cards: R(e, [n])
			});
		}
		e.beatMs = J.damage;
	}
}, Xm = (e, t, n, r) => {
	e.queue.unshift(r.resume);
}, Zm = (e, t, n, r, i) => {
	i.length > 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "miji-target",
			min: 1,
			max: 1,
			data: {
				candidates: z(e).filter((e) => e !== t),
				cards: i
			}
		}
	});
}, Qm = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.cards;
	for (let n of u) W(e, t, n);
	e.hands[l].push(...u), c.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: l,
			n: u.length
		},
		for: [e.seats[t].rid, e.seats[l].rid],
		secret: { cards: u }
	}), L(e, {
		kind: "miji-give",
		seat: t,
		target: l,
		n: u.length
	}), F(e, t, u.length);
}, $m = { zhenlie: Ym }, eh = { zhenlie: Xm }, th = { "miji-give": Zm }, nh = { "miji-target": Qm }, rh = (e, t, n, r, i) => {
	let a = r.target, o = {
		source: r.source ?? null,
		buyiDone: !0,
		...r.dmg ? { dmg: r.dmg } : {},
		...r.zx ? { zx: r.zx } : {}
	};
	if (!e.seats[a].alive || e.seats[a].hp > 0 || e.hands[a].length === 0) {
		jy(e, a, o, i);
		return;
	}
	let s = e.hands[a][Nv(e, e.hands[a].length)];
	if (i.push({
		kind: "reveal",
		rid: e.seats[a].rid,
		data: {
			seat: a,
			card: s
		}
	}), L(e, {
		kind: "buyi",
		seat: t,
		target: a,
		cards: R(e, [s])
	}), e.beatMs = J.judge, O(e.cards[s].name) !== "basic" && (W(e, a, s), U(e, [s]), pv(e, [s], i, a), dv(e, [s], a), F(e, a, 1), e.seats[a].hp += 1, i.push({
		kind: "recover",
		rid: e.seats[a].rid,
		data: {
			seat: a,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: a,
		n: 1
	}), e.beatMs = J.recover, e.seats[a].hp >= 1)) {
		my(e), o.dmg && e.queue.unshift(o.dmg), o.zx && o.zx > 0 && Iy(e, a, o.zx);
		return;
	}
	jy(e, a, o, i);
}, ih = (e, t, n, r, i) => {
	jy(e, r.target, {
		source: r.source ?? null,
		buyiDone: !0,
		...r.dmg ? { dmg: r.dmg } : {},
		...r.zx ? { zx: r.zx } : {}
	}, i);
}, ah = (e) => z(e).length >= 2 ? {
	minCards: 0,
	maxCards: 0,
	minTargets: 2,
	maxTargets: 2,
	targets: z(e)
} : null, oh = (e, t, n, r, i, a, o) => {
	let [s, c] = i, l = K(e, s), u = K(e, c);
	e.seats[s].equips = {
		weapon: null,
		armor: null,
		off_horse: null,
		def_horse: null
	}, e.seats[c].equips = {
		weapon: null,
		armor: null,
		off_horse: null,
		def_horse: null
	};
	for (let t of u) e.seats[s].equips[k(e.cards[t].name)] = t;
	for (let t of l) e.seats[c].equips[k(e.cards[t].name)] = t;
	L(e, {
		kind: "ganlu",
		seat: t,
		target: s,
		n: l.length + u.length
	}), o.push({
		kind: "move",
		data: {
			seat: s,
			name: "ganlu"
		}
	}), o.push({
		kind: "move",
		data: {
			seat: c,
			name: "ganlu"
		}
	}), e.beatMs = J.play;
	for (let t of l) I(e, s, t, o);
	for (let t of u) I(e, c, t, o);
	return e.pending || Z(e, o), {
		state: e,
		fx: o
	};
}, sh = { buyi: rh }, ch = { buyi: ih }, lh = { ganlu: ah }, uh = { ganlu: oh }, dh = { olbenxi: (e, t, n, r, i, a, o, s) => {
	let c = i.resume;
	return L(e, {
		kind: "olbenxi",
		seat: t
	}), e.queue.unshift({
		...c,
		bxPierce: n.option !== "bx-nullify",
		noJink: n.option !== "bx-pierce"
	}), Z(e, s), {
		state: e,
		fx: s
	};
} }, fh = (e, t, n, r, i, a, o, s) => {
	let c = n.option === "fm-draw" ? 1 : 2, l = e.seats[t].marks.fmLast ?? 0, u = l !== 0 && l !== c ? 2 : 1;
	e.seats[t].marks.fmLast = c;
	let d = e.seats[t].flags;
	return c === 1 ? d.fmDrawN = u : (d.fmRedN = u, d.fmRedUsed = !1), L(e, {
		kind: "skill",
		seat: t,
		card: r
	}), Z(e, s), {
		state: e,
		fx: s
	};
}, ph = (e, t) => {
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "daiyan-target",
			min: 1,
			max: 1,
			data: { candidates: z(e).filter((e) => e !== t) }
		}
	};
}, mh = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (l == null) return;
	L(e, {
		kind: "skill",
		seat: t,
		card: "daiyan",
		target: l
	});
	let u = e.deck.findIndex((t) => e.cards[t].suit === "heart" && O(e.cards[t].name) === "basic");
	if (u >= 0) {
		let t = e.deck[u];
		e.deck.splice(u, 1), e.hands[l].push(t), c.push({
			kind: "take",
			rid: e.seats[l].rid,
			data: {
				seat: l,
				from: -1,
				n: 1
			},
			for: [e.seats[l].rid],
			secret: { cards: [t] }
		}), L(e, {
			kind: "skill-draw",
			seat: l,
			card: "daiyan",
			n: 1
		}), e.beatMs = J.draw;
	}
	(e.seats[t].marks.dyLast ?? 0) === l + 1 && Ly(e, l, 1, c), e.seats[t].marks.dyLast = l + 1;
}, hh = { daiyan: ph }, gh = { fumian: fh }, _h = { "daiyan-target": mh }, vh = (e, t, n, r, i) => {
	let a = r.target;
	for (let n of [t, a]) {
		if (!e.seats[n].alive) continue;
		let t = H(e, n, 1);
		i.push({
			kind: "draw",
			rid: e.seats[n].rid,
			data: {
				seat: n,
				n: t.length
			},
			for: [e.seats[n].rid],
			secret: { cards: t }
		});
	}
	L(e, {
		kind: "skill-draw",
		seat: t,
		card: "qiaoshi",
		n: 1
	}), e.beatMs = J.draw;
}, yh = (e, t, n, r, i, a, o, s, c) => {
	if (i.length === 1 && e.seats[i[0]].alive) {
		L(e, {
			kind: "skill",
			seat: t,
			card: "yanyu"
		});
		let n = H(e, i[0], 2);
		c.push({
			kind: "draw",
			rid: e.seats[i[0]].rid,
			data: {
				seat: i[0],
				n: n.length
			},
			for: [e.seats[i[0]].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: i[0],
			card: "yanyu",
			n: n.length
		}), e.beatMs = J.draw;
	}
}, bh = { qiaoshi: vh }, xh = { "yanyu-target": yh }, Sh = (e, t) => {
	let n = e.seats[t];
	n.flags.xhSkip = !0;
	let r = z(e).filter((e) => e !== t);
	r.length !== 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "xuanhuo-target",
			min: 1,
			max: 1,
			data: { candidates: r }
		}
	});
}, Ch = (e, t, n, r, i, a, o, s) => {
	let c = i.holder, l = i.amountLeft - 1, u = i.liyu ?? null;
	return L(e, {
		kind: "skill",
		seat: c,
		card: "xinenyuan"
	}), n.option === "ey-give" ? (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "enyuan-give",
			min: 1,
			max: 1,
			data: {
				holder: c,
				amountLeft: l,
				liyu: u
			}
		}
	}, {
		state: e,
		fx: s
	}) : (Ly(e, t, 1, s), e.pending || gv(e, c, t, l, u) || Z(e, s), {
		state: e,
		fx: s
	});
}, wh = (e, t, n, r, i, a, o, s) => {
	let c = i.holder, l = i.source, u = i.amountLeft, d = i.liyu ?? null;
	L(e, {
		kind: "skill",
		seat: c,
		card: "xinenyuan"
	});
	let f = e.hands[l].length > 0 ? ["ey-give", "ey-losehp"] : ["ey-losehp"];
	return e.pending = {
		kind: "skill-ask",
		seats: [l],
		ctx: {
			skill: "xinenyuan",
			options: f,
			noPass: !0,
			from: c,
			data: {
				holder: c,
				amountLeft: u,
				liyu: d
			}
		}
	}, {
		state: e,
		fx: s
	};
}, Th = (e, t, n, r) => {
	let i = r.holder, a = r.source;
	gv(e, i, a, r.amountLeft - 1, r.liyu ?? null);
}, Eh = { xinxuanhuo: Sh }, Dh = { "xinenyuan-ask": Th }, Oh = {
	xinenyuan: Ch,
	"xinenyuan-ask": wh
}, kh = (e, t) => {
	let n = z(e).filter((n) => n !== t && e.hands[n].length === 0);
	n.length !== 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "juece-target",
			min: 1,
			max: 1,
			data: { candidates: n }
		}
	});
}, Ah = (e, t, n, r, i) => {
	let a = e.hands[t].filter((t) => O(e.cards[t].name) === "trick" && !G(e, t)), o = i.filter((t) => e.hands[t].length > 0);
	return a.length > 0 && o.length > 0 ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: o,
		suits: ["spade", "club"],
		classes: ["trick"]
	} : null;
}, jh = (e, t, n, r, i) => !n.limitedUsed.includes("xinfencheng") && i.length > 0 ? {
	minCards: 0,
	maxCards: 0,
	minTargets: 0,
	maxTargets: 0,
	targets: []
} : null, Mh = (e, t, n, r, i, a, o) => {
	let s = i[0], c = r[0];
	if (W(e, t, c), e.deck.unshift(c), o.push({
		kind: "reveal",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: c
		}
	}), L(e, {
		kind: "xinmieji",
		seat: t,
		target: s,
		cards: R(e, [c])
	}), e.beatMs = J.play, F(e, t, 1), !e.seats[s].alive || e.hands[s].length === 0) return {
		state: e,
		fx: o
	};
	let l = e.hands[s].some((t) => O(e.cards[t].name) === "trick"), u = e.hands[s].filter((t) => O(e.cards[t].name) !== "trick").length + K(e, s).filter((t) => O(e.cards[t].name) !== "trick").length, d = [...l ? ["mj-trick"] : [], ...u >= 2 ? ["mj-drop2"] : []];
	return d.length === 0 || (e.pending = {
		kind: "skill-ask",
		seats: [s],
		ctx: {
			skill: "xinmieji-choice",
			options: d,
			noPass: !0,
			data: {}
		}
	}), {
		state: e,
		fx: o
	};
}, Nh = (e, t, n, r, i, a, o) => {
	e.seats[t].limitedUsed.push("xinfencheng"), L(e, {
		kind: "xinfencheng",
		seat: t
	});
	let s = B(e, t).filter((n) => n !== t && e.seats[n].alive);
	return e.queue.unshift({
		k: "fencheng-step",
		seats: s,
		prev: 0,
		from: t
	}), e.beatMs = J.play, Z(e, o), {
		state: e,
		fx: o
	};
}, Ph = (e, t, n, r, i, a, o, s) => {
	if (n.option === "mj-trick") {
		let n = e.hands[t].filter((t) => O(e.cards[t].name) === "trick");
		return n.length === 0 ? q("games.sanguosha.error.badChoose") : (e.pending = {
			kind: "skill-cards",
			seats: [t],
			ctx: {
				skill: "mieji-trick",
				min: 1,
				max: 1,
				data: { pool: n }
			}
		}, {
			state: e,
			fx: s
		});
	}
	let c = [...e.hands[t].filter((t) => O(e.cards[t].name) !== "trick"), ...K(e, t).filter((t) => O(e.cards[t].name) !== "trick")];
	return c.length < 2 ? q("games.sanguosha.error.badChoose") : (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "mieji-drop2",
			min: 2,
			max: 2,
			data: { pool: c }
		}
	}, {
		state: e,
		fx: s
	});
}, Fh = { xinjuece: kh }, Ih = {
	xinmieji: Ah,
	xinfencheng: jh
}, Lh = {
	xinmieji: Mh,
	xinfencheng: Nh
}, Rh = { "xinmieji-choice": Ph }, zh = (e, t, n, r, i) => {
	let a = r.target, o = et(e, a, "snatch");
	if (o.length === 0 || !e.seats[a].alive) {
		Py(e, r.ev, i, !0);
		return;
	}
	if (o.length === 1) {
		tt(e, t, a, "snatch", o[0], i);
		return;
	}
	e.pending = {
		kind: "pick-zone",
		seats: [t],
		ctx: {
			trick: "snatch",
			from: t,
			target: a
		}
	};
}, Bh = (e, t, n, r, i) => {
	Py(e, r.ev, i, !0), e.beatMs = J.damage;
}, Vh = (e, t, n, r) => {
	let i = Math.max(...z(e).map((t) => e.seats[t].hp)), a = Math.max(...z(e).map((t) => e.hands[t].length)), o = /* @__PURE__ */ new Set();
	if (!n.flags["sy:hp"]) for (let t of z(e)) e.seats[t].hp === i && o.add(t);
	if (!n.flags["sy:hand"]) for (let t of z(e)) e.hands[t].length === a && o.add(t);
	return r >= 1 && o.size > 0 ? {
		minCards: 1,
		maxCards: 1,
		minTargets: 1,
		maxTargets: 1,
		targets: [...o]
	} : null;
}, Hh = (e, t, n, r, i, a, o) => {
	let s = i[0];
	for (let n of r) W(e, t, n);
	U(e, r), o.push({
		kind: "discard",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: r.length,
			cards: r
		}
	});
	let c = Math.max(...z(e).map((t) => e.seats[t].hp));
	return !e.seats[t].flags["sy:hp"] && e.seats[s].hp === c ? e.seats[t].flags["sy:hp"] = !0 : e.seats[t].flags["sy:hand"] = !0, F(e, t, r.length), pv(e, r, o, t), dv(e, r, t), e.queue.unshift({
		k: "damage",
		source: t,
		target: s,
		amount: 1,
		nature: "normal",
		reason: "sanyao",
		cardId: null
	}), e.beatMs = J.play, Z(e, o), {
		state: e,
		fx: o
	};
}, Uh = { rezhiman: zh }, Wh = { rezhiman: Bh }, Gh = { olsanyao: Vh }, Kh = { olsanyao: Hh }, qh = { xinjujian: (e, t) => {
	let n = e.hands[t].filter((t) => O(e.cards[t].name) !== "basic");
	n.length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "jujian-cost",
			min: 1,
			max: 1,
			data: { pool: n }
		}
	});
} }, Jh = (e, t, n, r, i, a, o, s) => {
	let c = e.seats[t].flags;
	return n.option === "cs-less" ? (c.csLess = !0, c.csSelf = !0) : n.option === "cs-limit" ? (c.csLimit = !0, c.csTarget = !0) : (c.csMore = !0, c.csBan = !0), L(e, {
		kind: "skill",
		seat: t,
		card: r
	}), Z(e, s), {
		state: e,
		fx: s
	};
}, Yh = (e, t, n, r, i) => {
	if (n.flags.csBan) return null;
	let a = i.filter((t) => e.hands[t].length > 0), o = n.flags.csSelf ? Math.min(2, r) : 1;
	return r >= 1 && a.length > 0 ? {
		minCards: 1,
		maxCards: o,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, Xh = (e, t, n, r, i, a, o) => {
	let s = i[0];
	for (let n of r) o.push({
		kind: "reveal",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: n
		}
	});
	L(e, {
		kind: "zhongjian-show",
		seat: t,
		cards: R(e, r)
	});
	let c = Math.min(e.seats[t].flags.csTarget ? 4 : 3, e.hands[s].length), l = Pv(e, [...e.hands[s]]).slice(0, c);
	for (let t of l) o.push({
		kind: "reveal",
		rid: e.seats[s].rid,
		data: {
			seat: s,
			card: t
		}
	});
	L(e, {
		kind: "zhongjian-show",
		seat: s,
		cards: R(e, l)
	}), e.beatMs = J.play;
	let u = new Set(r.map((t) => e.cards[t].suit)), d = new Set(r.map((t) => e.cards[t].point)), f = 0, p = !1, m = 0;
	for (let t of l) {
		let n = e.cards[t];
		u.has(n.suit) && (f += 1), d.has(n.point) && (p = !0), !u.has(n.suit) && !d.has(n.point) && (m += 1);
	}
	if (f > 0) {
		let n = H(e, t, f);
		o.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "zhongjian",
			n: n.length
		}), e.beatMs = J.draw;
	}
	p && e.queue.unshift({
		k: "damage",
		source: t,
		target: s,
		amount: 1,
		nature: "normal",
		reason: "zhongjian",
		cardId: null
	});
	let h = Math.min(m, e.hands[t].length);
	return h > 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "zhongjian-drop",
			min: h,
			max: h,
			data: {}
		}
	}), {
		state: e,
		fx: o
	};
}, Zh = (e, t, n, r, i, a, o, s, c) => {
	for (let n of i) {
		let r = e.hands[t].indexOf(n);
		r >= 0 && e.hands[t].splice(r, 1);
	}
	e.discard.push(...i), c.push({
		kind: "discard",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: i.length,
			cards: i
		}
	}), L(e, {
		kind: "discard",
		seat: t,
		n: i.length,
		cards: R(e, i)
	}), e.beatMs = J.discard;
}, Qh = { caishi: Jh }, $h = { zhongjian: Yh }, eg = { zhongjian: Xh }, tg = { "zhongjian-drop": Zh }, ng = (e, t, n, r, i) => {
	let a = r.responder, o = r.myCard, s = r.theirCard, c = (e.seats[t].marks.funanUp ?? 0) === 1;
	L(e, {
		kind: "funan",
		seat: t,
		target: a
	}), !c && e.discard.includes(o) && e.seats[a].alive && (e.discard = e.discard.filter((e) => e !== o), e.hands[a].push(o), e.seats[a].funanBan.push(o), i.push({
		kind: "take",
		rid: e.seats[a].rid,
		data: {
			seat: a,
			from: -1
		},
		for: [e.seats[a].rid],
		secret: { card: o }
	})), e.discard.includes(s) && (e.discard = e.discard.filter((e) => e !== s), e.hands[t].push(s), i.push({
		kind: "take",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			from: -1
		},
		for: [e.seats[t].rid],
		secret: { card: s }
	})), e.beatMs = J.play;
}, rg = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (l == null) return;
	let u = 0;
	for (let t of z(e)) {
		for (let n of K(e, t)) e.cards[n].suit === "diamond" && (u += 1);
		for (let n of e.seats[t].judges) e.cards[n].suit === "diamond" && (u += 1);
	}
	if (L(e, {
		kind: "skill",
		seat: t,
		card: n,
		target: l
	}), u > 0 && e.seats[l].alive) {
		let t = H(e, l, u);
		c.push({
			kind: "draw",
			rid: e.seats[l].rid,
			data: {
				seat: l,
				n: t.length
			},
			for: [e.seats[l].rid],
			secret: { cards: t }
		}), L(e, {
			kind: "skill-draw",
			seat: l,
			card: "xinjiexun",
			n: t.length
		}), e.beatMs = J.draw;
	}
	let d = e.seats[t].marks.xinjiexun ?? 0;
	if (e.seats[t].marks.xinjiexun = d + 1, d <= 0 || !e.seats[l].alive) return;
	let f = [...e.hands[l], ...K(e, l)];
	if (f.length <= d) {
		Qv(e, l, f, c), L(e, {
			kind: "discard",
			seat: l,
			n: f.length,
			cards: R(e, f)
		}), e.seats[t].marks.xinjiexun = 0, e.seats[t].marks.funanUp = 1;
		return;
	}
	e.pending = {
		kind: "skill-cards",
		seats: [l],
		ctx: {
			skill: "xinjiexun-discard",
			min: d,
			max: d,
			data: {
				pool: f,
				holder: t
			}
		}
	};
}, ig = (e, t, n, r, i, a, o, s, c) => {
	if (Qv(e, t, i, c), L(e, {
		kind: "discard",
		seat: t,
		n: i.length,
		cards: R(e, i)
	}), e.beatMs = J.discard, e.hands[t].length === 0 && K(e, t).length === 0) {
		let n = r.holder ?? t;
		e.seats[n].marks.xinjiexun = 0, e.seats[n].marks.funanUp = 1;
	}
}, ag = { funan: ng }, og = { xinjiexun: rg }, sg = { "xinjiexun-discard": ig }, cg = (e, t, n, r, i) => {
	let a = e.seats[t], o = H(e, t, 1);
	i.push({
		kind: "draw",
		rid: a.rid,
		data: {
			seat: t,
			n: o.length
		},
		for: [a.rid],
		secret: { cards: o }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "zhiyu",
		n: o.length
	}), e.beatMs = J.draw, P(e, t, o);
	let s = e.hands[t];
	for (let e of s) i.push({
		kind: "reveal",
		rid: a.rid,
		data: {
			seat: t,
			card: e
		}
	});
	L(e, {
		kind: "zhiyu-show",
		seat: t,
		n: s.length
	});
	let c = r.source;
	if (s.length > 0 && s.every((t) => G(e, t) === G(e, s[0])) && c != null && e.seats[c].alive && e.hands[c].length + K(e, c).length > 0) {
		e.pending = {
			kind: "skill-cards",
			seats: [c],
			ctx: {
				skill: "zhiyu-discard",
				min: 1,
				max: 1,
				data: {
					pool: [...e.hands[c], ...K(e, c)],
					chain: {
						seat: t,
						skill: "zhiyu",
						data: r
					}
				}
			}
		};
		return;
	}
	$_(e, t, "zhiyu", r);
}, lg = (e, t, n, r) => r >= 1 && mx(e, t).length > 0 ? {
	minCards: 0,
	maxCards: 0,
	minTargets: 0,
	maxTargets: 0,
	targets: []
} : null, ug = (e, t, n, r, i, a, o) => {
	let s = mx(e, t);
	return e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "qice-pick",
			options: s,
			noPass: !0,
			data: { tricks: s }
		}
	}, {
		state: e,
		fx: o
	};
}, dg = (e, t, n, r, i, a, o, s) => {
	let c = n.option;
	if (!i.tricks.includes(c)) return q("games.sanguosha.error.badChoose");
	L(e, {
		kind: "skill",
		seat: t,
		card: "qice"
	});
	let l = [...e.hands[t]];
	for (let n of l) W(e, t, n);
	if (U(e, l), F(e, t, l.length), s.push({
		kind: "play",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			name: c
		}
	}), L(e, {
		kind: "use",
		seat: t,
		card: c,
		cards: R(e, l)
	}), e.seats[t].flags.usedTrick = !0, c === "duel" && vv(e, t, s), c === "ex_nihilo") return Qe(e, t, c, null, {
		k: "trick-effect",
		name: c,
		from: t,
		target: null,
		cardId: null
	}), e.pending || Z(e, s), {
		state: e,
		fx: s
	};
	if (c === "savage_assault" || c === "archery_attack" || c === "god_salvation" || c === "amazing_grace") {
		let n = B(e, t).filter((e) => e !== t), r = z(e).find((t) => Y(e, t, "fenwei") && !e.seats[t].limitedUsed.includes("fenwei"));
		return r != null && n.length >= 2 ? (e.pending = {
			kind: "skill-ask",
			seats: [r],
			ctx: {
				skill: "fenwei",
				data: {
					name: c,
					from: t,
					targets: n,
					suit: null,
					cardId: null
				}
			}
		}, {
			state: e,
			fx: s
		}) : (nv(e, c, t, [], s, {
			suit: null,
			cardId: null
		}), Z(e, s), {
			state: e,
			fx: s
		});
	}
	let u = z(e).filter((e) => e !== t), d = Y(e, t, "qicai"), f;
	return f = c === "duel" ? u.filter((t) => !N(e, t)) : c === "fire_attack" ? u.filter((t) => e.hands[t].length > 0) : c === "snatch" ? u.filter((n) => (d || V(e, t, n) <= 1) && et(e, n, "snatch").length > 0) : c === "dismantlement" ? u.filter((t) => et(e, t, "dismantlement").length > 0) : u.filter((t) => e.seats[t].equips.weapon != null && px(e, t).length > 0), f.length === 0 ? (Z(e, s), {
		state: e,
		fx: s
	}) : (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "qice-target",
			min: 1,
			max: 1,
			data: {
				candidates: f,
				name: c
			}
		}
	}, {
		state: e,
		fx: s
	});
}, fg = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (W(e, t, l)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === l && (e.seats[t].equips[n] = null);
		I(e, t, l, c);
	}
	U(e, [l]), pv(e, [l], c, t), dv(e, [l], t), L(e, {
		kind: "discard-skill",
		seat: t,
		card: "zhiyu",
		cards: R(e, [l])
	}), e.beatMs = J.discard;
	let u = r.chain;
	if (u && $_(e, u.seat, u.skill, u.data)) return {
		state: e,
		fx: c
	};
}, pg = (e, t, n, r, i) => {
	let a = r.name, o = i[0];
	L(e, {
		kind: "use",
		seat: t,
		card: a,
		target: o
	}), Qe(e, t, a, o, {
		k: "trick-effect",
		name: a,
		from: t,
		target: o,
		cardId: null
	});
}, mg = { zhiyu: cg }, hg = { qice: lg }, gg = { qice: ug }, _g = { "qice-pick": dg }, vg = { "zhiyu-discard": fg }, yg = { "qice-target": pg }, bg = (e, t, n, r, i) => {
	let a = r.target, o = r.info, s = e.seats[a], c = Math.min(s.hp, e.hands[a].length + K(e, a).length), l = 0, u = [];
	for (let t of [
		"weapon",
		"armor",
		"off_horse",
		"def_horse"
	]) {
		if (u.length >= c) break;
		let n = s.equips[t];
		n != null && (s.equips[t] = null, u.push(n), I(e, a, n, i));
	}
	for (; u.length < c && e.hands[a].length > 0;) {
		let t = e.hands[a][Nv(e, e.hands[a].length)];
		W(e, a, t), u.push(t), l += 1;
	}
	s.pojun.push(...u), l > 0 && F(e, a, l), i.push({
		kind: "move",
		data: {
			seat: a,
			name: "pojun"
		}
	}), L(e, {
		kind: "pojun",
		seat: t,
		target: a,
		n: u.length
	}), e.queue.unshift({
		k: "slash-target",
		from: o.from,
		target: o.target,
		cardName: o.cardName,
		suit: o.suit,
		cardId: o.cardId,
		ana: o.ana,
		noJink: o.noJink,
		plus: o.plus,
		jcDone: !0,
		pjDone: !0
	});
}, xg = (e, t, n, r) => {
	let i = r.info;
	e.queue.unshift({
		k: "slash-target",
		from: i.from,
		target: i.target,
		cardName: i.cardName,
		suit: i.suit,
		cardId: i.cardId,
		ana: i.ana,
		noJink: i.noJink,
		plus: i.plus,
		jcDone: !0,
		pjDone: !0
	});
}, Sg = { xinpojun: bg }, Cg = { xinpojun: xg }, wg = (e, t, n, r, i, a, o) => {
	let s = i[0], c = r[0];
	return W(e, t, c), e.hands[s].push(c), o.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: s,
			n: 1
		},
		for: [e.seats[t].rid, e.seats[s].rid],
		secret: { cards: [c] }
	}), L(e, {
		kind: "wengua",
		seat: t,
		target: s
	}), e.seats[s].flags.wgDone = !0, e.pending = {
		kind: "skill-ask",
		seats: [s],
		ctx: {
			skill: "wengua-place",
			options: ["wg-top", "wg-bottom"],
			noPass: !0,
			data: {
				card: c,
				from: t
			}
		}
	}, {
		state: e,
		fx: o
	};
}, Tg = (e, t, n, r, i, a, o, s) => {
	let c = i.card, l = i.from;
	W(e, t, c);
	let u, d;
	return n.option === "wg-top" ? (e.deck.unshift(c), u = Kv(e, t, 1), d = Kv(e, l, 1)) : (e.deck.push(c), u = H(e, t, 1), d = H(e, l, 1)), s.push({
		kind: "reveal",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: c
		}
	}), s.push({
		kind: "draw",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: u.length
		},
		for: [e.seats[t].rid],
		secret: { cards: u }
	}), e.seats[l].alive && d.length > 0 && s.push({
		kind: "draw",
		rid: e.seats[l].rid,
		data: {
			seat: l,
			n: d.length
		},
		for: [e.seats[l].rid],
		secret: { cards: d }
	}), L(e, {
		kind: "skill",
		seat: t,
		card: r
	}), e.beatMs = J.draw, Z(e, s), {
		state: e,
		fx: s
	};
}, Eg = (e, t, n, r) => {
	let i = r.target, a = e.deck.filter((t) => A(e.cards[t].name));
	e.deck = e.deck.filter((t) => !A(e.cards[t].name)), L(e, {
		kind: "fuzhu",
		seat: t,
		target: i
	}), e.queue.unshift({
		k: "fuzhu-step",
		from: t,
		target: i,
		slashes: a,
		idx: 0
	});
}, Dg = { wengua: wg }, Og = { "wengua-place": Tg }, kg = { fuzhu: Eg }, Ag = (e, t) => {
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "zhiyan-target",
			min: 1,
			max: 1,
			data: { candidates: z(e) }
		}
	};
}, jg = (e, t, n, r) => {
	let i = r.cards.filter((t) => e.discard.includes(t));
	i.length !== 0 && (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "zongxuan-put",
			min: 0,
			max: i.length,
			data: { pool: i }
		}
	});
}, Mg = (e, t, n, r, i, a, o, s, c) => {
	for (let t of [...i].reverse()) e.discard = e.discard.filter((e) => e !== t), e.deck.unshift(t);
	return L(e, {
		kind: "zongxuan",
		seat: t,
		n: i.length
	}), e.beatMs = J.play, Z(e, c), {
		state: e,
		fx: c
	};
}, Ng = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (!e.seats[l].alive) return;
	let u = H(e, l, 1);
	if (u.length === 0) return;
	let d = u[0];
	c.push({
		kind: "draw",
		rid: e.seats[l].rid,
		data: {
			seat: l,
			n: 1
		},
		for: [e.seats[l].rid],
		secret: { cards: u }
	}), c.push({
		kind: "reveal",
		rid: e.seats[l].rid,
		data: {
			seat: l,
			card: d
		}
	}), L(e, {
		kind: "zhiyan",
		seat: t,
		target: l,
		cards: R(e, [d])
	}), e.beatMs = J.draw;
	let f = k(e.cards[d].name);
	if (f != null) {
		W(e, l, d);
		let t = e.seats[l].equips[f];
		t != null && (U(e, [t]), I(e, l, t, c)), e.seats[l].equips[f] = d, c.push({
			kind: "equip",
			rid: e.seats[l].rid,
			data: {
				seat: l,
				card: d,
				name: e.cards[d].name,
				slot: f
			}
		}), e.seats[l].hp < e.seats[l].maxHp && (e.seats[l].hp += 1, c.push({
			kind: "recover",
			rid: e.seats[l].rid,
			data: {
				seat: l,
				n: 1
			}
		}), L(e, {
			kind: "recover",
			seat: l,
			n: 1
		})), e.beatMs = J.equip;
	}
}, Pg = {
	zhiyan: Ag,
	zongxuan: jg
}, Fg = { "zongxuan-put": Mg }, Ig = { "zhiyan-target": Ng }, Lg = (e, t) => {
	let n = z(e).filter((t) => e.hands[t].length + K(e, t).length > 0);
	n.length !== 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "rezhenjun-target",
			min: 1,
			max: 1,
			data: { candidates: n }
		}
	});
}, Rg = (e, t, n, r, i, a, o, s) => {
	let c = i.y, l = i.target;
	if (L(e, {
		kind: "skill",
		seat: t,
		card: "rezhenjun"
	}), n.option === "zj-draw") {
		if (e.seats[l].alive) {
			let t = H(e, l, c);
			s.push({
				kind: "draw",
				rid: e.seats[l].rid,
				data: {
					seat: l,
					n: t.length
				},
				for: [e.seats[l].rid],
				secret: { cards: t }
			}), L(e, {
				kind: "skill-draw",
				seat: l,
				card: "rezhenjun",
				n: t.length
			}), e.beatMs = J.draw;
		}
		return Z(e, s), {
			state: e,
			fx: s
		};
	}
	let u = [...e.hands[t], ...K(e, t)], d = Math.min(c, u.length);
	return d <= 0 ? (Z(e, s), {
		state: e,
		fx: s
	}) : (e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "rezhenjun-drop",
			min: d,
			max: d,
			data: { pool: u }
		}
	}, {
		state: e,
		fx: s
	});
}, zg = (e, t, n, r, i, a, o, s, c) => {
	let l = 0;
	for (let n of i) if (W(e, t, n)) l += 1;
	else {
		for (let r of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[r] === n && (e.seats[t].equips[r] = null);
		I(e, t, n, c);
	}
	U(e, i), l > 0 && F(e, t, l), L(e, {
		kind: "discard-skill",
		seat: t,
		card: "rezhenjun",
		cards: R(e, i)
	}), e.beatMs = J.discard;
}, Bg = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = Math.max(1, e.hands[l].length - e.seats[l].hp), d = 0, f = 0, p = 0, m = [];
	for (; f < u && e.hands[l].length > 0;) {
		let t = e.hands[l][Nv(e, e.hands[l].length)];
		W(e, l, t), U(e, [t]), pv(e, [t], c, l), dv(e, [t], l), k(e.cards[t].name) ?? (d += 1), f += 1, p += 1, m.push(t);
	}
	for (; f < u;) {
		let t = K(e, l);
		if (t.length === 0) break;
		let n = t[Nv(e, t.length)];
		for (let t of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[l].equips[t] === n && (e.seats[l].equips[t] = null);
		U(e, [n]), I(e, l, n, c), pv(e, [n], c, l), dv(e, [n], l), f += 1, m.push(n);
	}
	p > 0 && F(e, l, p), f !== 0 && (L(e, {
		kind: "rezhenjun",
		seat: t,
		target: l,
		n: f,
		cards: R(e, m)
	}), e.beatMs = J.discard, d > 0 && (e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "rezhenjun-choice",
			options: ["zj-discard", "zj-draw"],
			noPass: !0,
			data: {
				y: d,
				target: l
			}
		}
	}));
}, Vg = { rezhenjun: Lg }, Hg = { "rezhenjun-choice": Rg }, Ug = { "rezhenjun-drop": zg }, Wg = { "rezhenjun-target": Bg }, Gg = { shangshi: (e, t, n, r, i) => {
	let a = e.seats[t], o = a.maxHp - a.hp, s = Math.max(0, o - e.hands[t].length);
	if (s > 0) {
		let n = H(e, t, s);
		i.push({
			kind: "draw",
			rid: a.rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [a.rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "shangshi",
			n: n.length
		}), e.beatMs = J.draw;
	}
} }, Kg = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.name;
	if (!e.seats[l].alive) return;
	let d = O(A(u) ? "slash" : u), f = [...e.hands[l], ...K(e, l)].filter((t) => O(e.cards[t].name) !== d);
	if (f.length === 0) {
		Ly(e, t, 1, c), e.seats[t].flags.tlOff = !0, L(e, {
			kind: "skill",
			seat: t,
			card: "taoluan"
		});
		return;
	}
	return e.pending = {
		kind: "skill-cards",
		seats: [l],
		ctx: {
			skill: "taoluan-give",
			min: 0,
			max: 1,
			data: {
				from: t,
				name: u,
				pool: f
			}
		}
	}, {
		state: e,
		fx: c
	};
}, qg = (e, t, n, r, i, a, o, s, c) => {
	let l = r.from;
	if (i.length === 0) {
		Ly(e, l, 1, c), e.seats[l].flags.tlOff = !0, L(e, {
			kind: "skill",
			seat: l,
			card: "taoluan"
		});
		return;
	}
	let u = i[0];
	if (e.seats[l].alive) {
		if (W(e, t, u)) F(e, t, 1);
		else {
			for (let n of [
				"weapon",
				"armor",
				"off_horse",
				"def_horse"
			]) e.seats[t].equips[n] === u && (e.seats[t].equips[n] = null);
			I(e, t, u, c);
		}
		e.hands[l].push(u), c.push({
			kind: "give",
			rid: e.seats[t].rid,
			data: {
				from: t,
				to: l,
				n: 1
			},
			for: [e.seats[t].rid, e.seats[l].rid],
			secret: { cards: [u] }
		}), hv(e, l, t, 1, c), L(e, {
			kind: "skill",
			seat: l,
			card: "taoluan"
		}), e.beatMs = J.play;
	}
}, Jg = { "taoluan-target": Kg }, Yg = { "taoluan-give": qg }, Xg = (e, t, n, r, i) => {
	let a = e.seats[t], o = H(e, t, 2);
	i.push({
		kind: "draw",
		rid: a.rid,
		data: {
			seat: t,
			n: o.length
		},
		for: [a.rid],
		secret: { cards: o }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "xiantu",
		n: o.length
	}), e.beatMs = J.draw, P(e, t, o);
	let s = [...e.hands[t], ...K(e, t)];
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "xiantu-give",
			min: 2,
			max: 2,
			data: {
				pool: s,
				target: r.target
			}
		}
	};
}, Zg = (e, t) => {
	let n = z(e).filter((n) => n !== t && e.hands[n].length > 0);
	n.length !== 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "qiangzhi-target",
			min: 1,
			max: 1,
			data: { candidates: n }
		}
	});
}, Qg = (e, t, n, r, i, a, o, s, c) => {
	let l = r.target;
	if (!e.seats[l].alive) return;
	let u = 0;
	for (let n of i) {
		if (W(e, t, n)) u += 1;
		else {
			for (let r of [
				"weapon",
				"armor",
				"off_horse",
				"def_horse"
			]) e.seats[t].equips[r] === n && (e.seats[t].equips[r] = null);
			I(e, t, n, c);
		}
		e.hands[l].push(n);
	}
	F(e, t, u), e.seats[l].flags.xtBy = t + 1, c.push({
		kind: "take",
		rid: e.seats[l].rid,
		data: {
			seat: l,
			from: t,
			n: i.length
		},
		for: [e.seats[l].rid, e.seats[t].rid],
		secret: { cards: i }
	}), L(e, {
		kind: "xiantu",
		seat: t,
		target: l,
		n: i.length
	}), hv(e, l, t, i.length, c);
}, $g = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	if (!e.seats[l].alive || e.hands[l].length === 0) return;
	let u = e.hands[l][Nv(e, e.hands[l].length)];
	e.seats[t].flags.qzType = {
		basic: 1,
		trick: 2,
		equip: 4
	}[O(e.cards[u].name)], c.push({
		kind: "reveal-hand",
		rid: e.seats[l].rid,
		data: {
			target: l,
			cards: [u]
		}
	}), L(e, {
		kind: "qiangzhi",
		seat: t,
		target: l,
		cards: R(e, [u])
	}), e.beatMs = J.play;
}, e_ = {
	xiantu: Xg,
	qiangzhi: Zg
}, t_ = { "xiantu-give": Qg }, n_ = { "qiangzhi-target": $g }, r_ = (e, t, n, r, i) => {
	let a = i.filter((t) => e.hands[t].length > 0);
	return r >= 1 && a.length > 0 ? {
		minCards: 0,
		maxCards: 0,
		minTargets: 1,
		maxTargets: 1,
		targets: a
	} : null;
}, i_ = (e, t, n, r, i, a, o) => (e.pending = {
	kind: "skill-cards",
	seats: [t],
	ctx: {
		skill: "wurong-pick",
		min: 1,
		max: 1,
		data: {
			target: i[0],
			pool: [...e.hands[t]]
		}
	}
}, {
	state: e,
	fx: o
}), a_ = (e, t, n, r, i, a, o, s, c) => {
	let l = r.target;
	if (e.seats[l].alive && e.hands[l].length !== 0) return e.pending = {
		kind: "skill-cards",
		seats: [l],
		ctx: {
			skill: "wurong-pick2",
			min: 1,
			max: 1,
			data: {
				me: t,
				c1: i[0],
				pool: [...e.hands[l]]
			}
		}
	}, {
		state: e,
		fx: c
	};
}, o_ = (e, t, n, r, i, a, o, s, c) => {
	let l = r.me, u = r.c1, d = i[0];
	if (!e.seats[l].alive || !e.hands[l].includes(u) || !e.hands[t].includes(d)) return;
	c.push({
		kind: "reveal",
		rid: e.seats[l].rid,
		data: {
			seat: l,
			card: u
		}
	}), c.push({
		kind: "reveal",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: d
		}
	}), L(e, {
		kind: "wurong-show",
		seat: l,
		target: t,
		cards: R(e, [u, d])
	});
	let f = A(e.cards[u].name), p = e.cards[d].name === "jink";
	if (e.beatMs = J.play, f && !p) {
		W(e, l, u), U(e, [u]), F(e, l, 1), e.queue.unshift({
			k: "damage",
			source: l,
			target: t,
			amount: 1,
			nature: "normal",
			reason: "wurong",
			cardId: null
		});
		return;
	}
	if (!f && p) {
		W(e, l, u), U(e, [u]), F(e, l, 1);
		let n = [...e.hands[t], ...K(e, t)];
		if (n.length > 0) {
			let r = n[Nv(e, n.length)];
			if (W(e, t, r)) F(e, t, 1);
			else {
				for (let n of [
					"weapon",
					"armor",
					"off_horse",
					"def_horse"
				]) e.seats[t].equips[n] === r && (e.seats[t].equips[n] = null);
				I(e, t, r, c);
			}
			e.hands[l].push(r), c.push({
				kind: "take",
				rid: e.seats[l].rid,
				data: {
					seat: l,
					from: t
				},
				for: [e.seats[l].rid, e.seats[t].rid],
				secret: { card: r }
			}), L(e, {
				kind: "wurong-gain",
				seat: l,
				target: t
			});
		}
	}
}, s_ = { wurong: r_ }, c_ = { wurong: i_ }, l_ = {
	"wurong-pick": a_,
	"wurong-pick2": o_
}, u_ = (e, t, n, r, i) => {
	let a = e.seats[t], o = H(e, t, 1);
	if (i.push({
		kind: "draw",
		rid: a.rid,
		data: {
			seat: t,
			n: o.length
		},
		for: [a.rid],
		secret: { cards: o }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "quanji",
		n: o.length
	}), e.beatMs = J.draw, P(e, t, o), e.hands[t].length > 0) {
		e.pending = {
			kind: "skill-cards",
			seats: [t],
			ctx: {
				skill: "quanji-put",
				min: 1,
				max: 1,
				data: { chain: {
					seat: t,
					skill: "quanji",
					data: r
				} }
			}
		};
		return;
	}
	$_(e, t, "quanji", r);
}, d_ = (e, t, n, r, i, a, o, s) => {
	if (n.option === "recover" && e.seats[t].hp < e.seats[t].maxHp) e.seats[t].hp += 1, s.push({
		kind: "recover",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: t,
		n: 1
	}), e.beatMs = J.recover;
	else {
		let n = H(e, t, 2);
		s.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "paiyi",
			n: n.length
		}), e.beatMs = J.draw, P(e, t, n);
	}
	return Z(e, s), {
		state: e,
		fx: s
	};
}, f_ = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0];
	W(e, t, l), e.seats[t].quan.push(l), F(e, t, 1), L(e, {
		kind: "quanji-put",
		seat: t,
		cards: R(e, [l])
	});
	let u = r.chain;
	if (u && $_(e, u.seat, u.skill, u.data)) return {
		state: e,
		fx: c
	};
}, p_ = { quanji: u_ }, m_ = { zili: d_ }, h_ = { "quanji-put": f_ }, g_ = { "zuoding-target": (e, t, n, r, i, a, o, s, c) => {
	if (i.length === 1 && e.seats[i[0]].alive) {
		L(e, {
			kind: "skill",
			seat: t,
			card: "zuoding"
		});
		let n = H(e, i[0], 1);
		c.push({
			kind: "draw",
			rid: e.seats[i[0]].rid,
			data: {
				seat: i[0],
				n: n.length
			},
			for: [e.seats[i[0]].rid],
			secret: { cards: n }
		}), L(e, {
			kind: "skill-draw",
			seat: i[0],
			card: "zuoding",
			n: n.length
		}), e.beatMs = J.draw;
	}
} }, __ = { xinzhongyong: (e, t, n, r) => {
	let i = [r.cardId, r.jinkId].filter((t) => t != null && e.discard.includes(t)), a = z(e).filter((e) => e !== t && e !== r.target);
	i.length !== 0 && a.length !== 0 && (e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "zy-target",
			min: 1,
			max: 1,
			data: {
				candidates: a,
				pool: i
			}
		}
	});
} }, v_ = (e, t) => {
	e.skipDraw = !0, L(e, {
		kind: "fenli",
		seat: t
	});
}, y_ = (e, t) => {
	e.seats[t].flags.flSkipPlay = !0, L(e, {
		kind: "fenli",
		seat: t
	});
}, b_ = (e, t) => {
	e.seats[t].flags.flSkipDiscard = !0, L(e, {
		kind: "fenli",
		seat: t
	});
}, x_ = (e, t, n, r) => {
	let i = r.x;
	e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "pingkou-targets",
			min: 0,
			max: i,
			data: { candidates: z(e).filter((e) => e !== t) }
		}
	};
}, S_ = (e, t, n, r, i) => {
	i.length > 0 && L(e, {
		kind: "pingkou",
		seat: t,
		n: i.length
	});
	for (let n = i.length - 1; n >= 0; n--) e.queue.unshift({
		k: "damage",
		source: t,
		target: i[n],
		amount: 1,
		nature: "normal",
		reason: "pingkou",
		cardId: null
	});
	e.beatMs = J.play;
}, C_ = {
	"fenli-draw": v_,
	"fenli-play": y_,
	"fenli-discard": b_,
	pingkou: x_
}, w_ = { "pingkou-targets": S_ }, T_ = (e, t, n, r, i) => {
	let a = Number(n.flags.danshouN ?? 0) + 1;
	if (r + K(e, t).length < a) return null;
	let o = Bv(e, t), s = i.filter((n) => V(e, t, n) <= o && (a > 2 || e.hands[n].length + K(e, n).length > 0));
	return s.length > 0 ? {
		minCards: a,
		maxCards: a,
		minTargets: 1,
		maxTargets: 1,
		targets: s,
		allowEquip: !0
	} : null;
}, E_ = (e, t, n, r, i, a, o) => {
	let s = i[0], c = r.length;
	if (e.seats[t].flags.danshouN = c, Qv(e, t, r, o), L(e, {
		kind: "danshou",
		seat: t,
		target: s,
		n: c
	}), e.beatMs = J.play, c === 1) {
		let t = Zv(e, s, o);
		t != null && L(e, {
			kind: "discard",
			seat: s,
			n: 1,
			cards: R(e, [t])
		});
	} else if (c === 2) {
		if (e.seats[s].alive && (e.hands[s].length > 0 || K(e, s).length > 0)) return e.pending = {
			kind: "skill-cards",
			seats: [s],
			ctx: {
				skill: "danshou-give",
				min: 1,
				max: 1,
				data: {
					pool: [...e.hands[s], ...K(e, s)],
					giveTo: t
				}
			}
		}, {
			state: e,
			fx: o
		};
	} else if (c === 3) return e.queue.unshift({
		k: "damage",
		source: t,
		target: s,
		amount: 1,
		nature: "normal",
		reason: "danshou",
		cardId: null
	}), Z(e, o), {
		state: e,
		fx: o
	};
	else {
		let n = H(e, t, 2);
		o.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: n.length
			},
			for: [e.seats[t].rid],
			secret: { cards: n }
		});
		let r = H(e, s, 2);
		o.push({
			kind: "draw",
			rid: e.seats[s].rid,
			data: {
				seat: s,
				n: r.length
			},
			for: [e.seats[s].rid],
			secret: { cards: r }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "danshou",
			n: n.length
		}), e.beatMs = J.draw;
	}
	return {
		state: e,
		fx: o
	};
}, D_ = (e, t, n, r, i, a, o, s, c) => {
	let l = i[0], u = r.giveTo;
	if (W(e, t, l)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === l && (e.seats[t].equips[n] = null);
		I(e, t, l, c);
	}
	return e.hands[u].push(l), c.push({
		kind: "give",
		rid: e.seats[t].rid,
		data: {
			from: t,
			to: u,
			n: 1
		},
		for: [e.seats[t].rid, e.seats[u].rid],
		secret: { cards: [l] }
	}), L(e, {
		kind: "danshou-give",
		seat: t,
		target: u,
		cards: R(e, [l])
	}), e.beatMs = J.play, Z(e, c), {
		state: e,
		fx: c
	};
}, O_ = { danshou: T_ }, k_ = { danshou: E_ }, A_ = { "danshou-give": D_ }, j_ = (e, t, n, r, i) => i.length > 0 ? {
	minCards: 0,
	maxCards: 0,
	minTargets: 1,
	maxTargets: 1,
	targets: i
} : null, M_ = (e, t, n, r, i, a, o) => {
	let s = i[0], c = [
		[(t) => z(e).every((n) => n === t || e.hands[n].length >= e.hands[t].length), (t) => {
			let n = H(e, t, 1);
			o.push({
				kind: "draw",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					n: n.length
				},
				for: [e.seats[t].rid],
				secret: { cards: n }
			}), L(e, {
				kind: "skill-draw",
				seat: t,
				card: "xinanguo",
				n: n.length
			});
		}],
		[(t) => e.seats[t].hp < e.seats[t].maxHp && z(e).every((n) => n === t || e.seats[n].hp >= e.seats[t].hp), (t) => {
			e.seats[t].hp += 1, o.push({
				kind: "recover",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					n: 1
				}
			}), L(e, {
				kind: "recover",
				seat: t,
				n: 1
			}), X(e, t);
		}],
		[(t) => z(e).every((n) => n === t || K(e, n).length >= K(e, t).length), (t) => {
			let n = e.deck.filter((n) => {
				let r = k(e.cards[n].name);
				return r != null && e.seats[t].equips[r] == null;
			});
			if (n.length === 0) return;
			let r = n[Nv(e, n.length)];
			e.deck = e.deck.filter((e) => e !== r);
			let i = k(e.cards[r].name);
			e.seats[t].equips[i] = r, o.push({
				kind: "equip",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					card: r,
					name: e.cards[r].name,
					slot: i
				}
			}), L(e, {
				kind: "equip",
				seat: t,
				card: e.cards[r].name,
				cards: R(e, [r])
			});
		}]
	], l = [];
	for (let [t, n] of c) e.seats[s].alive && t(s) ? n(s) : l.push([t, n]);
	for (let [n, r] of l) e.seats[t].alive && n(t) && r(t);
	return e.beatMs = J.play, {
		state: e,
		fx: o
	};
}, N_ = { xinanguo: j_ }, P_ = { xinanguo: M_ }, F_ = {
	...Nl,
	...Vl,
	...Zl,
	...cu,
	...vu,
	...Bu,
	...Ju,
	...sd,
	...bd,
	...Pd,
	...Id,
	...Jd,
	...$d,
	...bf,
	...Ff,
	...Xf,
	...ep,
	...cp,
	..._p,
	...Rp,
	...Kp,
	...Zp,
	...am,
	...wm,
	...$m,
	...sh,
	...hh,
	...bh,
	...Eh,
	...Fh,
	...Uh,
	...qh,
	...ag,
	...mg,
	...Sg,
	...kg,
	...Pg,
	...Vg,
	...Gg,
	...e_,
	...p_,
	...__,
	...C_
}, I_ = {
	...Hl,
	...Ql,
	...lu,
	...Vu,
	...cd,
	...xd,
	...Gd,
	...Zf,
	...om,
	...Tm,
	...eh,
	...ch,
	...Dh,
	...Wh,
	...Cg
}, L_ = {
	...ml,
	...Cl,
	...uu,
	...Du,
	...Su,
	...Nu,
	...Yu,
	...hd,
	...Od,
	...Hd,
	...ef,
	...df,
	...Gf,
	...fp,
	...ap,
	...Tp,
	...zp,
	...pm,
	...Im,
	...Gm,
	...lh,
	...Ih,
	...Gh,
	...$h,
	...hg,
	...s_,
	...O_,
	...N_
}, R_ = {
	...hl,
	...wl,
	...du,
	...Ou,
	...Cu,
	...Pu,
	...Xu,
	...Sd,
	...kd,
	...Ud,
	...tf,
	...ff,
	...Kf,
	...pp,
	...op,
	...Ep,
	...Bp,
	...mm,
	...Lm,
	...Km,
	...uh,
	...Lh,
	...Kh,
	...eg,
	...gg,
	...Dg,
	...c_,
	...k_,
	...P_
}, z_ = {
	...Tl,
	...$l,
	...hu,
	..._u,
	...Fu,
	...Zu,
	...ld,
	...Ad,
	...Wd,
	...pf,
	...Af,
	...sp,
	...Dp,
	...Vp,
	...sm,
	...Em,
	...Rm,
	...Jm,
	...gh,
	...dh,
	...Oh,
	...Rh,
	...Qh,
	..._g,
	...Og,
	...Hg,
	...m_
}, B_ = {
	...El,
	...Pl,
	...Ul,
	...eu,
	...gu,
	...Hu,
	...Qu,
	...ud,
	...Cd,
	...Fd,
	...mf,
	...xf,
	...kf,
	...If,
	...mp,
	...Op,
	...Hp,
	...qp,
	...Qp,
	...cm,
	...hm,
	...Dm,
	...zm,
	...qm,
	...th,
	...tg,
	...sg,
	...vg,
	...Fg,
	...Ug,
	...Yg,
	...t_,
	...l_,
	...h_,
	...A_
}, V_ = {
	...gl,
	...Dl,
	...Fl,
	...tu,
	...fu,
	...wu,
	...Iu,
	...dd,
	...jd,
	...Yd,
	...hf,
	...Sf,
	...Of,
	...Lf,
	...qf,
	...tp,
	...vp,
	...kp,
	...Jp,
	...lm,
	...Om,
	...Bm,
	...nh,
	..._h,
	...xh,
	...og,
	...yg,
	...Ig,
	...Wg,
	...Jg,
	...n_,
	...g_,
	...w_
}, H_ = {
	...bt,
	...ur,
	...Di,
	...Ea,
	...Qs,
	...il,
	...F_
}, U_ = {
	...xt,
	...dr,
	...Oi,
	...Da,
	...$s,
	...al,
	...I_
}, W_ = {
	...jt,
	...fr,
	...ki,
	...Oa,
	...ec,
	...ol,
	...L_
}, G_ = {
	...Mt,
	...pr,
	...Ai,
	...ka,
	...tc,
	...sl,
	...R_
}, K_ = {
	...dn,
	...mr,
	...ji,
	...Aa,
	...nc,
	...cl,
	...z_
}, q_ = {
	...fn,
	...hr,
	...Mi,
	...ja,
	...rc,
	...ll,
	...B_
}, J_ = {
	...pn,
	...gr,
	...Ni,
	...Ma,
	...ic,
	...ul,
	...V_
};
for (let e of [
	H_,
	U_,
	W_,
	G_,
	K_,
	q_,
	J_
]) for (let t of Object.keys(e)) {
	if (t.startsWith("re_")) continue;
	let n = `re_${t}`;
	n in e || (e[n] = e[t]);
}
//#endregion
//#region src/games/sanguosha/rules/skill-ask.ts
function Y_(e, t, n) {
	e.pending = {
		kind: "skill-ask",
		seats: [t.seat],
		ctx: {
			skill: t.skill,
			data: t.data,
			...t.options ? { options: t.options } : {},
			...t.noPass ? { noPass: !0 } : {}
		}
	};
}
function X_(e, t, n) {
	return Y(e, t, "tianbian") && e.cards[n].suit === "heart" ? 13 : e.cards[n].point;
}
function Z_(e, t, n, r, i, a, o) {
	let s = e.hands[t].includes(r), c = e.hands[n].includes(i);
	s && W(e, t, r), c && W(e, n, i), U(e, [r, i]), o.push({
		kind: "reveal",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: r
		}
	}), o.push({
		kind: "reveal",
		rid: e.seats[n].rid,
		data: {
			seat: n,
			card: i
		}
	}), L(e, {
		kind: a,
		seat: t,
		target: n
	}), F(e, n, 1), cv(e, t);
	let l = Y(e, t, "hanzhan") ? t : Y(e, n, "hanzhan") ? n : -1;
	if (l >= 0) {
		let t = [r, i].filter((t) => e.discard.includes(t) && A(e.cards[t].name));
		if (t.length > 0) {
			let n = t.reduce((t, n) => e.cards[t].point >= e.cards[n].point ? t : n);
			e.discard = e.discard.filter((e) => e !== n), e.hands[l].push(n), o.push({
				kind: "take",
				rid: e.seats[l].rid,
				data: {
					seat: l,
					from: -1
				},
				for: [e.seats[l].rid],
				secret: { card: n }
			}), L(e, {
				kind: "hanzhan",
				seat: l,
				cards: R(e, [n])
			});
		}
	}
	let u = X_(e, t, r) > X_(e, n, i);
	if (Y(e, t, "jyzongshi")) {
		let n = u ? i : r;
		e.discard.includes(n) && (e.discard = e.discard.filter((e) => e !== n), e.hands[t].push(n), o.push({
			kind: "take",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				from: -1
			},
			for: [e.seats[t].rid],
			secret: { card: n }
		}), L(e, {
			kind: "jyzongshi",
			seat: t,
			cards: R(e, [n])
		}));
	}
	if (Y(e, n, "jyzongshi")) {
		let a = X_(e, n, i) > X_(e, t, r) ? r : i;
		e.discard.includes(a) && (e.discard = e.discard.filter((e) => e !== a), e.hands[n].push(a), o.push({
			kind: "take",
			rid: e.seats[n].rid,
			data: {
				seat: n,
				from: -1
			},
			for: [e.seats[n].rid],
			secret: { card: a }
		}), L(e, {
			kind: "jyzongshi",
			seat: n,
			cards: R(e, [a])
		}));
	}
	return u;
}
function Q_(e, t, n) {
	let r = Y(e, t, "hanzhan") ? t : Y(e, n, "hanzhan") ? n : -1;
	return r < 0 || e.hands[n].length === 0 ? null : (L(e, {
		kind: "skill",
		seat: r,
		card: "hanzhan"
	}), e.hands[n][Nv(e, e.hands[n].length)]);
}
function $_(e, t, n, r) {
	let i = r.amountLeft - 1;
	if (i > 0) return ky(e, t, n, {
		...r,
		amountLeft: i
	}), !0;
	let a = r.liyu;
	return a && e.seats[a.target].alive && e.seats[a.source].alive && fx(e, a.target) ? (Ay(e, a), !0) : !1;
}
function ev(e, t, n, r, i) {
	L(e, {
		kind: "skill",
		seat: t,
		card: n
	}), H_[n]?.(e, t, n, r, i);
}
function tv(e, t, n, r, i) {
	U_[n]?.(e, t, n, r, i);
}
//#endregion
//#region src/games/sanguosha/rules/pending.ts
function nv(e, t, n, r, i, a) {
	if (t === "savage_assault" || t === "archery_attack") {
		let i = a?.suit ?? null, o = a?.cardId ?? null;
		t === "savage_assault" && a?.cardId != null && e.queue.unshift({
			k: "savage-end",
			cardId: a.cardId,
			from: n
		});
		let s = B(e, n).filter((e) => e !== n);
		for (let a = s.length - 1; a >= 0; a--) e.queue.unshift({
			k: "aoe-nullify",
			name: t,
			from: n,
			target: s[a],
			immune: r,
			suit: i,
			cardId: o
		});
		return;
	}
	if (t === "god_salvation") {
		let t = B(e, n).filter((t) => e.seats[t].alive);
		for (let i = t.length - 1; i >= 0; i--) e.queue.unshift({
			k: "god-salvation-one",
			from: n,
			target: t[i],
			immune: r
		});
		return;
	}
	let o = B(e, n).filter((t) => e.seats[t].alive && !r.includes(t));
	e.queue.unshift({
		k: "amazing-step",
		from: n,
		pool: null,
		takers: o,
		taken: {},
		cardId: a?.cardId ?? null
	});
}
function rv(e, t, n, r) {
	let i = e.pending;
	if (!i.seats.includes(t) || !i.simultaneous && i.seats[0] !== t) return q("games.sanguosha.error.notYourAsk");
	if (n.type === "respond" && n.cardId != null && e.seats[t].flags.noHand) return q("games.sanguosha.error.badRespond");
	if (n.type === "respond" && n.cardId != null && e.hands[t].includes(n.cardId)) {
		let r = e.seats[t].flags.qianxiRed;
		if (r != null && r === G(e, n.cardId)) return q("games.sanguosha.error.badRespond");
	}
	if (n.type === "respond" && n.cardId != null && ze(e, t, n.cardId) || n.type === "respond" && n.cardId != null && e.seats[t].funanBan.includes(n.cardId)) return q("games.sanguosha.error.badRespond");
	switch (i.kind) {
		case "jink":
			if (n.type === "respond" && n.cardId != null) return i.ctx.noJink || !e.hands[t].includes(n.cardId) || n.as == null && e.cards[n.cardId].name === "jink" && Y(e, t, "shizhi") && e.seats[t].hp === 1 || !(n.as == null ? e.cards[n.cardId].name === "jink" : n.as === "jink" && hy(e, t, n.cardId).includes("jink")) ? q("games.sanguosha.error.badRespond") : (W(e, t, n.cardId), vy(e, t, n.cardId, n.as) ? (yy(e, n.cardId), L(e, {
				kind: "huomo",
				seat: t
			})) : U(e, [n.cardId]), _y(e, t, "jink"), Iv(e, n.cardId, "jink", t), r.push({
				kind: "dodge",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					card: n.cardId,
					name: e.cards[n.cardId].name,
					table: !0
				}
			}), L(e, {
				kind: "jink",
				seat: t,
				card: n.as ?? "jink",
				cards: R(e, [n.cardId])
			}), e.beatMs = J.respond, F(e, t, 1), bv(e, t, n.cardId, r), i.ctx.count = i.ctx.count + 1, i.ctx.count < i.ctx.need || (e.pending = null, i.ctx.cardId != null && e.queue.unshift({
				k: "funan-check",
				holder: i.ctx.from,
				responder: t,
				myCard: i.ctx.cardId,
				theirCard: n.cardId
			}), Ie(e, t, i.ctx, r, n.cardId)) || Z(e, r), {
				state: e,
				fx: r
			});
			if (n.type === "choose" && n.option === "shifei") {
				if (i.ctx.noJink || i.ctx.sfUsed || e.turn == null || !Y(e, t, "shifei")) return q("games.sanguosha.error.badRespond");
				L(e, {
					kind: "skill",
					seat: t,
					card: "shifei"
				});
				let n = e.turn.seat;
				H(e, n, 1), L(e, {
					kind: "skill-draw",
					seat: n,
					card: "shifei",
					n: 1
				});
				let a = Math.max(...z(e).map((t) => e.hands[t].length)), o = z(e).filter((t) => e.hands[t].length === a);
				if (o.length === 1 && o[0] === n) return i.ctx.sfUsed = !0, {
					state: e,
					fx: r
				};
				let s = { ...i.ctx };
				return r.push({
					kind: "dodge",
					rid: e.seats[t].rid,
					data: {
						seat: t,
						by: "shifei"
					}
				}), L(e, {
					kind: "jink",
					seat: t,
					card: "jink"
				}), e.beatMs = J.respond, _y(e, t, "jink"), o.length === 1 ? (Re(e, t, o[0], r), e.pending = null, s.count = (s.count ?? 0) + 1, s.count < s.need ? (e.pending = {
					kind: "jink",
					seats: [t],
					ctx: s
				}, {
					state: e,
					fx: r
				}) : (Ie(e, t, s, r, null) || Z(e, r), {
					state: e,
					fx: r
				})) : (e.pending = {
					kind: "skill-seats",
					seats: [t],
					ctx: {
						skill: "shifei-target",
						min: 1,
						max: 1,
						data: {
							candidates: o,
							jinkCtx: s
						}
					}
				}, {
					state: e,
					fx: r
				});
			}
			if (n.type === "choose" && n.option === "eight_diagram") {
				if (i.ctx.noJink) return q("games.sanguosha.error.badRespond");
				let n = i.ctx.cardName == null ? null : e.seats[i.ctx.from]?.equips.weapon;
				return ty(e, t, n != null && e.cards[n].name === "qinggang_sword" || !!i.ctx.bxPierce) !== "eight_diagram" || i.ctx.baguaUsed ? q("games.sanguosha.error.badRespond") : (e.pending = null, L(e, {
					kind: "judge",
					seat: t,
					card: "eight_diagram"
				}), nt(e, t, "eight_diagram", { jinkCtx: i.ctx }, r) || Z(e, r), {
					state: e,
					fx: r
				});
			}
			if (n.type === "choose" && n.option === "hujia") {
				if (!Y(e, t, "hujia")) return q("games.sanguosha.error.badRespond");
				let n = B(e, t).filter((n) => n !== t && $v(e, n) === "wei");
				return n.length === 0 ? q("games.sanguosha.error.badRespond") : (e.pending = {
					kind: "lord-call",
					seats: n,
					ctx: {
						lord: t,
						need: "jink",
						resume: i.ctx
					}
				}, {
					state: e,
					fx: r
				});
			}
			if (n.type === "pass" || n.type === "respond" && n.cardId == null) {
				e.pending = null;
				let n = i.ctx.from, a = i.ctx.cardName, o = i.ctx.ana ?? 0, s = i.ctx.plus ?? 0, c = a === "fire_slash" ? "fire" : a === "thunder_slash" ? "thunder" : "normal", l = i.ctx.aoe ?? "slash";
				return e.queue.unshift({
					k: "damage",
					source: n,
					target: t,
					amount: 1 + o + s,
					nature: c,
					reason: l,
					cardId: i.ctx.cardId ?? null,
					ana: o,
					...i.ctx.lihuo == null ? {} : { lihuo: !0 },
					...i.ctx.fuhun == null ? {} : { fuhun: !0 },
					...i.ctx.bxPierce ? { pierce: !0 } : {}
				}), Z(e, r), {
					state: e,
					fx: r
				};
			}
			return q("games.sanguosha.error.badRespond");
		case "slash-response":
			if (n.type === "respond" && n.cardId != null) {
				let a = e.hands[t].includes(n.cardId), o = !a && n.as === "slash" && K(e, t).includes(n.cardId);
				if (!a && !o || e.seats[t].flags.jcNoSlash || n.as != null && vy(e, t, n.cardId, n.as) || !(n.as == null ? A(e.cards[n.cardId].name) : n.as === "slash" && hy(e, t, n.cardId).includes("slash"))) return q("games.sanguosha.error.badRespond");
				if (a) W(e, t, n.cardId);
				else {
					for (let r of [
						"weapon",
						"armor",
						"off_horse",
						"def_horse"
					]) e.seats[t].equips[r] === n.cardId && (e.seats[t].equips[r] = null);
					I(e, t, n.cardId, r);
				}
				U(e, [n.cardId]), e.turn?.seat === t && e.turn.phase === "play" && (e.seats[t].flags.slashInPlay = !0), Iv(e, n.cardId, "slash", t), r.push({
					kind: "respond-slash",
					rid: e.seats[t].rid,
					data: {
						seat: t,
						card: n.cardId,
						name: e.cards[n.cardId].name,
						table: !0
					}
				}), L(e, {
					kind: "respond-slash",
					seat: t,
					card: n.as ?? e.cards[n.cardId].name,
					cards: R(e, [n.cardId])
				}), e.beatMs = J.respond, a && F(e, t, 1), bv(e, t, n.cardId, r);
				let s = dy(e, t, n.cardId);
				if ((s === "heart" || s === "diamond") && vv(e, t, r), i.ctx.duel) {
					if (i.ctx.count = i.ctx.count + 1, i.ctx.count < (i.ctx.need ?? 1)) return {
						state: e,
						fx: r
					};
					let a = i.ctx.duel.other, o = Y(e, t, "wushuang") ? 2 : 1;
					return !i.ctx.fnDone && i.ctx.cardId != null && e.queue.unshift({
						k: "funan-check",
						holder: i.ctx.from,
						responder: t,
						myCard: i.ctx.cardId,
						theirCard: n.cardId
					}), e.pending = {
						kind: "slash-response",
						seats: [a],
						ctx: {
							from: i.ctx.from,
							duel: { other: t },
							need: o,
							count: 0,
							cardId: i.ctx.cardId,
							fnDone: !0,
							...i.ctx.zj == null ? {} : { zj: i.ctx.zj }
						}
					}, {
						state: e,
						fx: r
					};
				}
				if (i.ctx.collateral) {
					let { a, b: o } = i.ctx.collateral;
					return e.pending = null, e.queue.unshift({
						k: "slash-target",
						from: a,
						target: o,
						cardName: n.as ?? e.cards[n.cardId].name,
						suit: dy(e, t, n.cardId),
						cardId: n.cardId
					}), Z(e, r), {
						state: e,
						fx: r
					};
				}
				return e.pending = null, i.ctx.cardId != null && e.queue.unshift({
					k: "funan-check",
					holder: i.ctx.from,
					responder: t,
					myCard: i.ctx.cardId,
					theirCard: n.cardId
				}), Z(e, r), {
					state: e,
					fx: r
				};
			}
			if (n.type === "choose" && n.option === "jijiang") {
				if (!Y(e, t, "jijiang")) return q("games.sanguosha.error.badRespond");
				let n = B(e, t).filter((n) => n !== t && $v(e, n) === "shu");
				return n.length === 0 ? q("games.sanguosha.error.badRespond") : (e.pending = {
					kind: "lord-call",
					seats: n,
					ctx: {
						lord: t,
						need: "slash",
						resume: i.ctx
					}
				}, {
					state: e,
					fx: r
				});
			}
			if (n.type === "choose" && n.option === "qinwang") {
				if (!Y(e, t, "qinwang")) return q("games.sanguosha.error.badRespond");
				let n = B(e, t).filter((n) => n !== t && $v(e, n) === "shu"), a = [...e.hands[t], ...K(e, t)];
				return n.length === 0 || a.length === 0 ? q("games.sanguosha.error.badRespond") : (L(e, {
					kind: "skill",
					seat: t,
					card: "qinwang"
				}), e.pending = {
					kind: "skill-cards",
					seats: [t],
					ctx: {
						skill: "qinwang-discard",
						min: 1,
						max: 1,
						data: {
							pool: a,
							resume: i.ctx
						}
					}
				}, {
					state: e,
					fx: r
				});
			}
			if (n.type === "pass" || n.type === "respond" && n.cardId == null) {
				if (i.ctx.duel) {
					let n = i.ctx.duel.other;
					return e.pending = null, e.queue.unshift({
						k: "damage",
						source: n,
						target: t,
						amount: 1,
						nature: "normal",
						reason: "duel",
						cardId: i.ctx.cardId ?? null,
						...i.ctx.zj == null ? {} : { zj: i.ctx.zj }
					}), Z(e, r), {
						state: e,
						fx: r
					};
				}
				if (i.ctx.collateral) {
					let { a: t } = i.ctx.collateral, n = i.ctx.from;
					e.pending = null;
					let a = e.seats[t].equips.weapon;
					return a != null && e.seats[n].alive && (e.seats[t].equips.weapon = null, e.hands[n].push(a), r.push({
						kind: "take",
						rid: e.seats[n].rid,
						data: {
							from: t,
							seat: n
						},
						for: [e.seats[n].rid, e.seats[t].rid],
						secret: { card: a }
					}), L(e, {
						kind: "collateral-take",
						seat: n,
						target: t,
						cards: R(e, [a])
					}), I(e, t, a, r)), Z(e, r), {
						state: e,
						fx: r
					};
				}
				return e.pending = null, e.queue.unshift({
					k: "damage",
					source: Ze(e, i.ctx.from),
					target: t,
					amount: 1,
					nature: "normal",
					reason: "savage_assault",
					cardId: i.ctx.cardId ?? null
				}), Z(e, r), {
					state: e,
					fx: r
				};
			}
			return q("games.sanguosha.error.badRespond");
		case "nullification":
			if (n.type === "respond" && n.cardId != null) {
				let a = e.cards[n.cardId]?.name === "nullification" || n.as === "nullification" && hy(e, t, n.cardId).includes("nullification"), o = e.hands[t].includes(n.cardId), s = !o && n.as === "nullification" && K(e, t).includes(n.cardId);
				if (!o && !s || !a) return q("games.sanguosha.error.badRespond");
				if (o) W(e, t, n.cardId);
				else {
					for (let r of [
						"weapon",
						"armor",
						"off_horse",
						"def_horse"
					]) e.seats[t].equips[r] === n.cardId && (e.seats[t].equips[r] = null);
					I(e, t, n.cardId, r);
				}
				U(e, [n.cardId]), i.ctx.chain = i.ctx.chain + 1, Iv(e, n.cardId, "nullification", t), r.push({
					kind: "nullify",
					rid: e.seats[t].rid,
					data: {
						seat: t,
						chain: i.ctx.chain,
						name: e.cards[n.cardId].name,
						table: !0
					}
				}), L(e, {
					kind: "nullify",
					seat: t
				}), xv(e, t, r), o && F(e, t, 1), bv(e, t, n.cardId, r);
				let c = i.ctx.resume;
				return c?.cardId != null && e.queue.unshift({
					k: "funan-check",
					holder: i.ctx.from,
					responder: t,
					myCard: c.cardId,
					theirCard: n.cardId
				}), Y(e, t, "re_kanpo") || (i.seats = B(e, (t + 1) % e.seats.length).filter((t) => Ye(e, t)), e.beatMs = J.respond, i.seats.length === 0) ? iv(e, r) : {
					state: e,
					fx: r
				};
			}
			return n.type === "pass" || n.type === "respond" && n.cardId == null ? (i.seats = i.seats.filter((e) => e !== t), i.seats.length > 0 ? { state: e } : iv(e, r)) : q("games.sanguosha.error.badRespond");
		case "peach-save": {
			let a = i.ctx.target;
			if (n.type === "respond" && n.cardId != null) {
				let o = e.hands[t].includes(n.cardId), s = !o && K(e, t).includes(n.cardId);
				if (!o && !s || !(n.as == null ? e.cards[n.cardId].name === "peach" || e.cards[n.cardId].name === "analeptic" && t === a && !Y(e, t, "jinjiu") : n.as === "peach" && hy(e, t, n.cardId).includes("peach") || n.as === "analeptic" && t === a && !Y(e, t, "jinjiu") && hy(e, t, n.cardId).includes("analeptic")) || e.turn && (Y(e, e.turn.seat, "wansha") || Y(e, e.turn.seat, "re_wansha")) && (Y(e, e.turn.seat, "re_wansha") ? t !== a : t !== a && t !== e.turn.seat)) return q("games.sanguosha.error.badRespond");
				if (o) W(e, t, n.cardId);
				else {
					for (let r of [
						"weapon",
						"armor",
						"off_horse",
						"def_horse"
					]) e.seats[t].equips[r] === n.cardId && (e.seats[t].equips[r] = null);
					I(e, t, n.cardId, r);
				}
				if (n.as != null && vy(e, t, n.cardId, n.as) ? (yy(e, n.cardId), L(e, {
					kind: "huomo",
					seat: t
				})) : U(e, [n.cardId]), _y(e, t, n.as ?? e.cards[n.cardId].name), e.seats[a].hp += 1, Iv(e, n.cardId, n.as ?? e.cards[n.cardId].name, t), t !== a && Y(e, a, "jiuyuan") && $v(e, t) === "wu" && (e.seats[a].hp += 1), r.push({
					kind: "recover",
					rid: e.seats[a].rid,
					data: {
						seat: a,
						n: 1,
						by: t,
						name: e.cards[n.cardId].name,
						table: !0
					}
				}), L(e, {
					kind: "peach-save",
					seat: t,
					target: a
				}), e.beatMs = J.recover, X(e, a), F(e, t, 1), bv(e, t, n.cardId, r), e.seats[a].hp >= 1) {
					e.pending = null, my(e);
					let t = i.ctx.dmg;
					t && e.queue.unshift(t);
					let n = i.ctx.zx;
					return n && n > 0 && Iy(e, a, n), Z(e, r), {
						state: e,
						fx: r
					};
				}
				return i.seats = i.seats.filter((e) => e !== t), i.seats.length === 0 && (e.pending = null, ct(e, a, i.ctx.source ?? null, r)), {
					state: e,
					fx: r
				};
			}
			if (n.type === "choose" && n.option === "jiushi") {
				if (t !== a || !Y(e, t, "jiushi") || e.seats[t].turnedOver) return q("games.sanguosha.error.badRespond");
				if (Jv(e, t, r), e.seats[a].hp += 1, L(e, {
					kind: "skill",
					seat: t,
					card: "jiushi"
				}), e.beatMs = J.recover, X(e, a), e.seats[a].hp >= 1) {
					e.pending = null, my(e);
					let t = i.ctx.dmg;
					t && e.queue.unshift(t);
					let n = i.ctx.zx;
					return n && n > 0 && Iy(e, a, n), Z(e, r), {
						state: e,
						fx: r
					};
				}
				return i.seats = i.seats.filter((e) => e !== t), i.seats.length === 0 && (e.pending = null, ct(e, a, i.ctx.source ?? null, r)), {
					state: e,
					fx: r
				};
			}
			return n.type === "pass" || n.type === "respond" && n.cardId == null ? (i.seats = i.seats.filter((e) => e !== t), i.seats.length > 0 ? { state: e } : (e.pending = null, ct(e, a, i.ctx.source ?? null, r), Z(e, r), {
				state: e,
				fx: r
			})) : q("games.sanguosha.error.badRespond");
		}
		case "amazing-pick": {
			if (n.type !== "choose" || n.cardIds?.length !== 1) return q("games.sanguosha.error.badChoose");
			let a = i.ctx.revealed, o = i.ctx.taken, s = n.cardIds[0];
			return !a.includes(s) || o[s] != null ? q("games.sanguosha.error.badChoose") : (o[s] = t, e.hands[t].push(s), e.pending = null, r.push({
				kind: "take",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					from: -1
				},
				for: [e.seats[t].rid],
				secret: { card: s }
			}), L(e, {
				kind: "amazing-take",
				seat: t,
				cards: R(e, [s])
			}), e.beatMs = J.draw, P(e, t, [s]), e.pending || Z(e, r), {
				state: e,
				fx: r
			});
		}
		case "pick-zone": {
			if (n.type !== "choose" || !n.option) return q("games.sanguosha.error.badChoose");
			let t = i.ctx.target, a = i.ctx.trick, o = i.ctx.from;
			if (!et(e, t, a, i.ctx.allowJudge ?? !0).includes(n.option)) return q("games.sanguosha.error.badChoose");
			let s = i.ctx.chain, c = i.ctx.via;
			e.pending = null;
			let l = tt(e, o, t, a, n.option, r);
			if (c === "jianchu" && l != null) {
				let n = i.ctx.info;
				return O(e.cards[l].name) === "basic" ? n.cardId != null && e.discard.includes(n.cardId) && (e.discard = e.discard.filter((e) => e !== n.cardId), e.hands[t].push(n.cardId), r.push({
					kind: "take",
					rid: e.seats[t].rid,
					data: {
						seat: t,
						from: -1
					},
					for: [e.seats[t].rid],
					secret: { card: n.cardId }
				})) : (n.noJink = !0, e.seats[o].flags.jianchuSlash = (e.seats[o].flags.jianchuSlash ?? 0) + 1), e.queue.unshift({
					k: "slash-target",
					from: n.from,
					target: n.target,
					cardName: n.cardName,
					suit: n.suit,
					cardId: n.cardId,
					ana: n.ana,
					noJink: n.noJink,
					plus: n.plus,
					jcDone: !0
				}), Z(e, r), {
					state: e,
					fx: r
				};
			}
			if (c === "liyu-jie" && l != null) {
				if (k(e.cards[l].name) != null) {
					let n = z(e).filter((n) => n !== o && n !== t && !N(e, n));
					if (n.length > 0) return e.pending = {
						kind: "skill-seats",
						seats: [o],
						ctx: {
							skill: "liyu",
							min: 1,
							max: 1,
							data: {
								candidates: n,
								source: o
							}
						}
					}, {
						state: e,
						fx: r
					};
				} else if (e.seats[t].alive) {
					let n = H(e, t, 1);
					r.push({
						kind: "draw",
						rid: e.seats[t].rid,
						data: {
							seat: t,
							n: 1
						},
						for: [e.seats[t].rid],
						secret: { cards: n }
					}), L(e, {
						kind: "skill-draw",
						seat: t,
						card: "liyu",
						n: 1
					});
				}
				return Z(e, r), {
					state: e,
					fx: r
				};
			}
			let u = i.ctx.iceLeft;
			return u && e.seats[t].alive && et(e, t, a, !1).length > 0 ? (e.pending = {
				kind: "pick-zone",
				seats: [o],
				ctx: {
					trick: a,
					from: o,
					target: t,
					allowJudge: !1,
					iceLeft: u - 1
				}
			}, {
				state: e,
				fx: r
			}) : (s && $_(e, s.seat, s.skill, s.data) || Z(e, r), {
				state: e,
				fx: r
			});
		}
		case "collateral-target": {
			if (n.type !== "choose" || n.seat == null) return q("games.sanguosha.error.badChoose");
			let t = i.ctx.a;
			return px(e, t).includes(n.seat) ? (e.pending = {
				kind: "slash-response",
				seats: [t],
				ctx: {
					from: i.ctx.from,
					collateral: {
						a: t,
						b: n.seat
					}
				}
			}, {
				state: e,
				fx: r
			}) : q("games.sanguosha.error.badTarget");
		}
		case "discard": {
			if (n.type !== "choose" || !n.cardIds) return q("games.sanguosha.error.badChoose");
			let a = i.ctx.count;
			if (n.cardIds.length !== a) return q("games.sanguosha.error.badChoose");
			if (!n.cardIds.every((n) => e.hands[t].includes(n))) return q("games.sanguosha.error.noCard");
			for (let r of n.cardIds) W(e, t, r);
			if (U(e, n.cardIds), e.pending = null, e.turn != null && e.turn.phase === "discard" && e.turn.seat === t && (e.lastDiscard = {
				seat: t,
				cards: [...n.cardIds]
			}), e.turn != null && e.turn.phase === "discard" && e.turn.seat === t && Y(e, t, "guizao")) {
				let r = e.seats[t].flags;
				r.gzN = (r.gzN ?? 0) + n.cardIds.length;
				for (let t of n.cardIds) r.gzSuits = (r.gzSuits ?? 0) | {
					spade: 1,
					heart: 2,
					diamond: 4,
					club: 8
				}[e.cards[t].suit];
			}
			return r.push({
				kind: "discard",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					n: n.cardIds.length,
					cards: n.cardIds
				}
			}), L(e, {
				kind: "discard",
				seat: t,
				n: n.cardIds.length,
				cards: R(e, n.cardIds)
			}), e.beatMs = J.discard, F(e, t, n.cardIds.length), Y(e, t, "re_tuntian") && n.cardIds.some((t) => e.cards[t].name === "slash") && cv(e, t, !0), pv(e, n.cardIds, r, t), dv(e, n.cardIds, t), e.turn != null && e.turn.phase === "discard" && e.turn.seat === t && n.cardIds.length >= 2 && uv(e, t), Z(e, r), {
				state: e,
				fx: r
			};
		}
		case "skill-ask": {
			let a = i.ctx.skill, o = i.ctx.data ?? {};
			if (n.type === "pass" || n.type === "choose" && n.option === "pass") return i.ctx.noPass ? q("games.sanguosha.error.badChoose") : (e.pending = null, tv(e, t, a, o, r), e.pending || Z(e, r), {
				state: e,
				fx: r
			});
			if (n.type === "choose" && n.option) {
				let s = i.ctx.options;
				if (s && !s.includes(n.option)) return q("games.sanguosha.error.badChoose");
				e.pending = null;
				let c = K_[a];
				if (c) {
					let l = c(e, t, n, a, o, s, i, r);
					if (l) return l;
				}
				return n.option === "use" ? (ev(e, t, a, o, r), e.pending || Z(e, r), {
					state: e,
					fx: r
				}) : q("games.sanguosha.error.badChoose");
			}
			return q("games.sanguosha.error.badRespond");
		}
		case "skill-cards": {
			let a = i.ctx.skill, o = i.ctx.data ?? {}, s = i.ctx.min, c = i.ctx.max, l = n.type === "pass" && s === 0 ? [] : n.type === "choose" ? n.cardIds ?? null : null;
			if (!l || l.length < s || l.length > c) return q("games.sanguosha.error.badChoose");
			let u = o.pool ?? e.hands[t];
			if (!l.every((e) => u.includes(e))) return q("games.sanguosha.error.noCard");
			let d = l;
			e.pending = null;
			let f = q_[a];
			return f ? f(e, t, a, o, d, u, s, c, r) || (e.pending || Z(e, r), {
				state: e,
				fx: r
			}) : q("games.sanguosha.error.badChoose");
		}
		case "skill-seats": {
			let a = i.ctx.skill, o = i.ctx.data ?? {}, s = i.ctx.min, c = i.ctx.max, l = n.type === "pass" && s === 0 ? [] : n.type === "choose" ? n.seats ?? null : null;
			if (!l || l.length < s || l.length > c) return q("games.sanguosha.error.badChoose");
			let u = o.candidates ?? z(e).filter((e) => e !== t);
			if (!l.every((e) => u.includes(e))) return q("games.sanguosha.error.badTarget");
			e.pending = null;
			let d = J_[a];
			return d ? d(e, t, a, o, l, u, s, c, r) || (e.pending || Z(e, r), {
				state: e,
				fx: r
			}) : q("games.sanguosha.error.badChoose");
		}
		case "lord-call": {
			let a = i.ctx.lord, o = i.ctx.need, s = i.ctx.resume;
			if (n.type === "respond" && n.cardId != null) {
				if (!e.hands[t].includes(n.cardId) || o === "slash" && n.as != null && vy(e, t, n.cardId, n.as) || o === "jink" && n.as == null && e.cards[n.cardId].name === "jink" && Y(e, t, "shizhi") && e.seats[t].hp === 1 || !(o === "jink" ? n.as == null ? e.cards[n.cardId].name === "jink" : n.as === "jink" && hy(e, t, n.cardId).includes("jink") : n.as == null ? A(e.cards[n.cardId].name) : n.as === "slash" && hy(e, t, n.cardId).includes("slash"))) return q("games.sanguosha.error.badRespond");
				if (W(e, t, n.cardId), U(e, [n.cardId]), F(e, t, 1), bv(e, t, n.cardId, r), o === "jink") return r.push({
					kind: "dodge",
					rid: e.seats[a].rid,
					data: {
						seat: a,
						card: n.cardId,
						by: t,
						name: e.cards[n.cardId].name
					}
				}), L(e, {
					kind: "lord-call",
					seat: t,
					target: a
				}), L(e, {
					kind: "jink",
					seat: a,
					card: "jink",
					cards: R(e, [n.cardId])
				}), e.beatMs = J.respond, s.count = (s.count ?? 0) + 1, s.count < (s.need ?? 1) ? (e.pending = {
					kind: "jink",
					seats: [a],
					ctx: s
				}, {
					state: e,
					fx: r
				}) : (e.pending = null, Z(e, r), {
					state: e,
					fx: r
				});
				if (r.push({
					kind: "respond-slash",
					rid: e.seats[a].rid,
					data: {
						seat: a,
						by: t,
						card: n.cardId,
						name: e.cards[n.cardId].name
					}
				}), L(e, {
					kind: "lord-call",
					seat: t,
					target: a
				}), L(e, {
					kind: "respond-slash",
					seat: a,
					card: n.as ?? e.cards[n.cardId].name,
					cards: R(e, [n.cardId])
				}), e.beatMs = J.respond, i.ctx.qinwang === !0 && (H(e, t, 1), L(e, {
					kind: "skill-draw",
					seat: t,
					card: "qinwang",
					n: 1
				})), s.duel) {
					let t = s.duel.other;
					if (s.count += 1, s.count < (s.need ?? 1)) return e.pending = {
						kind: "slash-response",
						seats: [a],
						ctx: s
					}, {
						state: e,
						fx: r
					};
					let n = Y(e, a, "wushuang") ? 2 : 1;
					return e.pending = {
						kind: "slash-response",
						seats: [t],
						ctx: {
							from: s.from,
							duel: { other: a },
							need: n,
							count: 0,
							cardId: s.cardId,
							...s.zj == null ? {} : { zj: s.zj }
						}
					}, {
						state: e,
						fx: r
					};
				}
				if (s.collateral) {
					let { a: i, b: a } = s.collateral;
					return e.pending = null, e.queue.unshift({
						k: "slash-target",
						from: i,
						target: a,
						cardName: n.as ?? e.cards[n.cardId].name,
						suit: dy(e, t, n.cardId),
						cardId: n.cardId
					}), Z(e, r), {
						state: e,
						fx: r
					};
				}
				return e.pending = null, Z(e, r), {
					state: e,
					fx: r
				};
			}
			return n.type === "pass" || n.type === "respond" && n.cardId == null ? (i.seats = i.seats.filter((e) => e !== t), i.seats.length > 0 ? { state: e } : (e.pending = {
				kind: o === "jink" ? "jink" : "slash-response",
				seats: [a],
				ctx: s
			}, {
				state: e,
				fx: r
			})) : q("games.sanguosha.error.badRespond");
		}
		case "guicai":
			if (n.type === "respond" && n.cardId != null) {
				let a = !e.hands[t].includes(n.cardId);
				if (a && !(Y(e, t, "re_guicai") && K(e, t).includes(n.cardId))) return q("games.sanguosha.error.badRespond");
				let o = !Y(e, t, "guicai") && !Y(e, t, "re_guicai");
				if (o && !qv(e, n.cardId)) return q("games.sanguosha.error.badRespond");
				if (a) {
					for (let r of [
						"weapon",
						"armor",
						"off_horse",
						"def_horse"
					]) e.seats[t].equips[r] === n.cardId && (e.seats[t].equips[r] = null);
					I(e, t, n.cardId, r);
				} else W(e, t, n.cardId), F(e, t, 1), bv(e, t, n.cardId, r);
				let s = i.ctx.judgeCard;
				if (o ? e.hands[t].push(s) : U(e, [s]), o && Y(e, t, "re_guidao") && e.cards[n.cardId].suit === "spade" && e.cards[n.cardId].point >= 2 && e.cards[n.cardId].point <= 9) {
					let n = H(e, t, 1);
					r.push({
						kind: "draw",
						rid: e.seats[t].rid,
						data: {
							seat: t,
							n: n.length
						},
						for: [e.seats[t].rid],
						secret: { cards: n }
					}), L(e, {
						kind: "skill-draw",
						seat: t,
						card: "guidao",
						n: 1
					});
				}
				e.pending = null, r.push({
					kind: "judge",
					rid: e.seats[t].rid,
					data: {
						seat: t,
						from: t,
						card: n.cardId,
						name: e.cards[n.cardId].name,
						suit: e.cards[n.cardId].suit,
						point: e.cards[n.cardId].point,
						for: o ? "guidao" : "guicai"
					}
				}), L(e, {
					kind: o ? "guidao" : "guicai",
					seat: t,
					cards: R(e, [n.cardId])
				}), e.beatMs = J.judge;
				let c = [...i.ctx.acted ?? [], t], l = i.ctx.seat, u = B(e, l).filter((t) => !c.includes(t) && ((Y(e, t, "guicai") || Y(e, t, "re_guicai")) && (e.hands[t].length > 0 || Y(e, t, "re_guicai") && K(e, t).length > 0) || (Y(e, t, "guidao") || Y(e, t, "re_guidao")) && e.hands[t].some((t) => qv(e, t))));
				return u.length > 0 ? (e.pending = {
					kind: "guicai",
					seats: u,
					ctx: {
						judgeCard: n.cardId,
						purpose: i.ctx.purpose,
						data: i.ctx.data,
						seat: l,
						acted: c
					}
				}, {
					state: e,
					fx: r
				}) : (e.queue.unshift({
					k: "judge-effect",
					purpose: i.ctx.purpose,
					seat: l,
					judgeCard: n.cardId,
					data: i.ctx.data
				}), Z(e, r), {
					state: e,
					fx: r
				});
			}
			return n.type === "pass" || n.type === "respond" && n.cardId == null ? (i.ctx.acted = [...i.ctx.acted ?? [], t], i.seats = i.seats.filter((e) => e !== t), i.seats.length > 0 ? { state: e } : (e.pending = null, e.queue.unshift({
				k: "judge-effect",
				purpose: i.ctx.purpose,
				seat: i.ctx.seat,
				judgeCard: i.ctx.judgeCard,
				data: i.ctx.data
			}), Z(e, r), {
				state: e,
				fx: r
			})) : q("games.sanguosha.error.badRespond");
		default: return q("games.sanguosha.error.badRespond");
	}
}
function iv(e, t) {
	let n = e.pending, r = n.ctx.chain, i = n.ctx.resume;
	return e.pending = null, r % 2 == 1 ? (L(e, {
		kind: "nullified",
		card: n.ctx.trick
	}), t.push({
		kind: "nullified",
		data: { trick: n.ctx.trick }
	}), e.beatMs = J.respond, i.k === "judge-now" && (U(e, [i.cardId]), e.judging = null, t.push({
		kind: "discard",
		data: {
			seat: i.seat,
			n: 1
		}
	}))) : e.queue.unshift(i), Z(e, t), {
		state: e,
		fx: t
	};
}
//#endregion
//#region src/games/sanguosha/rules/triggers.ts
function av(e, t, n) {
	let r = e.seats[n].marks.zhaofu;
	return r != null && $v(e, t) === "wu" && t !== r - 1;
}
function ov(e, t, n) {
	if (!e.seats[t].alive || $v(e, t) !== "wei" || py(e, t, n)) return !1;
	let r = z(e).find((n) => n !== t && Y(e, n, "songwei"));
	return r != null && (e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "songwei",
			data: { lord: r }
		}
	}, !0);
}
function P(e, t, n) {
	if (!Y(e, t, "qingjian") || n.length === 0 || e.turn?.seat === t && e.turn.phase === "draw") return !1;
	let r = n.filter((n) => e.hands[t].includes(n));
	return r.length !== 0 && (e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "qingjian",
			data: { got: r }
		}
	}, !0);
}
function sv(e, t, n) {
	!Y(e, t, "lianying") || e.hands[t].length > 0 || n <= 0 || e.queue.unshift({
		k: "lianying",
		seat: t,
		lost: n
	});
}
function cv(e, t, n = !1) {
	(Y(e, t, "tuntian") || Y(e, t, "re_tuntian")) && (e.turn == null || e.turn.seat !== t || n && Y(e, t, "re_tuntian")) && e.queue.unshift({
		k: "tuntian-check",
		seat: t,
		slash: n || void 0
	});
}
function F(e, t, n) {
	sv(e, t, n), cv(e, t), lv(e, t);
}
function lv(e, t) {
	if (!e.seats[t].alive || !Y(e, t, "shangshi")) return;
	let n = e.seats[t].maxHp - e.seats[t].hp;
	n <= 0 || e.hands[t].length >= n || e.queue.unshift({
		k: "shangshi-check",
		seat: t
	});
}
function uv(e, t) {
	e.seats[t].alive && Y(e, t, "xuanfeng") && z(e).some((n) => n !== t && (e.hands[n].length > 0 || K(e, n).length > 0)) && (e.queue.some((e) => e.k === "xuanfeng-ask" && e.seat === t) || e.queue.unshift({
		k: "xuanfeng-ask",
		seat: t
	}));
}
function dv(e, t, n) {
	if (n == null || !e.seats[n].alive) return;
	let r = t.filter((t) => e.discard.includes(t));
	if (e.turn != null && Y(e, n, "olbingyi") && e.hands[n].length > 0) {
		let t = {
			judge: 1,
			draw: 2,
			play: 4,
			discard: 8,
			end: 16
		}[e.turn.phase];
		(e.seats[n].flags.byP ?? 0) & t || e.queue.unshift({
			k: "bingyi-ask",
			seat: n
		});
	}
	if (Y(e, n, "shenduan")) {
		let t = r.filter((t) => qv(e, t) && O(e.cards[t].name) === "basic");
		t.length > 0 && e.queue.unshift({
			k: "shenduan-ask",
			seat: n,
			cards: t
		});
	}
	Y(e, n, "zongxuan") && r.length > 0 && e.queue.unshift({
		k: "zongxuan-ask",
		seat: n,
		cards: r
	});
}
function fv(e, t) {
	if (!e.seats[t].alive) return;
	let n = z(e).filter((t) => Y(e, t, "faen"));
	for (let r = n.length - 1; r >= 0; r--) e.queue.unshift({
		k: "faen-ask",
		seat: n[r],
		target: t
	});
}
function pv(e, t, n, r) {
	let i = z(e).find((t) => Y(e, t, "luoying"));
	if (i == null || i === r) return;
	let a = t.filter((t) => e.discard.includes(t) && e.cards[t].suit === "club");
	a.length !== 0 && (e.discard = e.discard.filter((e) => !a.includes(e)), e.hands[i].push(...a), n && n.push({
		kind: "take",
		rid: e.seats[i].rid,
		data: {
			seat: i,
			n: a.length
		},
		for: [e.seats[i].rid],
		secret: { cards: a }
	}), L(e, {
		kind: "luoying",
		seat: i,
		n: a.length,
		cards: R(e, a)
	}));
}
function mv(e, t, n, r, i) {
	let a = e.discard.indexOf(r);
	if (!(a < 0 || !e.seats[n].alive) && (e.discard.splice(a, 1), e.hands[n].push(r), i.push({
		kind: "take",
		rid: e.seats[n].rid,
		data: {
			seat: n,
			from: -1
		},
		for: [e.seats[n].rid],
		secret: { card: r }
	}), L(e, {
		kind: "xinzhongyong",
		seat: t,
		target: n,
		cards: R(e, [r])
	}), e.beatMs = J.play, G(e, r) && e.seats[t].alive)) {
		let r = z(e).filter((r) => r !== n && r !== t && V(e, t, r) <= Bv(e, t) && !N(e, r));
		r.length > 0 && (e.pending = {
			kind: "skill-ask",
			seats: [n],
			ctx: {
				skill: "zy-slash",
				data: {
					from: t,
					candidates: r
				}
			}
		});
	}
}
function hv(e, t, n, r, i) {
	if (r < 2 || t === n || !e.seats[t].alive || !e.seats[n].alive || !Y(e, t, "xinenyuan")) return;
	let a = H(e, n, 1);
	i.push({
		kind: "draw",
		rid: e.seats[n].rid,
		data: {
			seat: n,
			n: a.length
		},
		for: [e.seats[n].rid],
		secret: { cards: a }
	}), L(e, {
		kind: "skill-draw",
		seat: n,
		card: "xinenyuan",
		n: a.length
	});
}
function gv(e, t, n, r, i) {
	return r > 0 && e.seats[n].alive && e.seats[t].alive ? (e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "xinenyuan-ask",
			from: n,
			data: {
				holder: t,
				source: n,
				amountLeft: r,
				liyu: i
			}
		}
	}, !0) : i && e.seats[i.target].alive && e.seats[i.source].alive && fx(e, i.target) ? (Ay(e, i), !0) : !1;
}
function _v(e, t, n, r) {
	if (!e.seats[t].alive || !e.seats[n].alive) return;
	let i = [...e.hands[n], ...K(e, n)];
	if (i.length === 0) return;
	let a = Math.min(2, i.length);
	e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "xuanhuo-take",
			min: a,
			max: a,
			data: {
				pool: i,
				from: n,
				blind: [...e.hands[n]]
			}
		}
	};
}
function vv(e, t, n) {
	if (!(Y(e, t, "jiang") || Y(e, t, "re_jiang")) || !e.seats[t].alive) return;
	let r = H(e, t, 1);
	n.push({
		kind: "draw",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: r.length
		},
		for: [e.seats[t].rid],
		secret: { cards: r }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "jiang",
		n: r.length
	}), e.beatMs = J.draw;
}
function yv(e, t) {
	Y(e, t, "xiaoji") && e.seats[t].alive && L(e, {
		kind: "skill-draw",
		seat: t,
		card: "xiaoji",
		n: H(e, t, 2).length
	});
}
function I(e, t, n, r) {
	let i = e.seats[t];
	i.alive && e.cards[n].name === "silver_lion" && i.hp < i.maxHp && (i.hp += 1, r.push({
		kind: "recover",
		rid: i.rid,
		data: {
			seat: t,
			n: 1
		}
	}), L(e, {
		kind: "silver-lion",
		seat: t
	}), X(e, t)), yv(e, t), cv(e, t), uv(e, t);
	let a = k(e.cards[n].name);
	a !== "weapon" && a != null && e.seats[t].moshi.length > 0 && e.queue.unshift({
		k: "moshi-check",
		seat: t
	});
}
function bv(e, t, n, r) {
	if (!Y(e, t, "yajiao") && !Y(e, t, "re_yajiao") || e.turn?.seat === t) return;
	e.deck.length === 0 && e.discard.length > 0 && (e.deck = Pv(e, e.discard), e.discard = []);
	let i = e.deck.shift();
	if (i != null) {
		if (r.push({
			kind: "reveal",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				card: i
			}
		}), Y(e, t, "re_yajiao")) {
			e.queue.unshift({
				k: "yajiao-jie",
				seat: t,
				lost: n,
				top: i
			});
			return;
		}
		O(e.cards[i].name) === O(e.cards[n].name) ? (e.hands[t].push(i), L(e, {
			kind: "yajiao-gain",
			seat: t,
			cards: R(e, [i])
		})) : (U(e, [i]), L(e, {
			kind: "yajiao-drop",
			seat: t,
			cards: R(e, [i])
		}));
	}
}
function xv(e, t, n) {
	if (!Y(e, t, "jizhi")) return;
	let r = H(e, t, 1);
	n.push({
		kind: "draw",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			n: 1
		},
		for: [e.seats[t].rid],
		secret: { cards: r }
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: "jizhi",
		n: 1
	});
}
function Sv(e, t, n) {
	return !Y(e, t, "leiji") && !Y(e, t, "re_leiji") || !z(e).some((e) => e !== t) ? !1 : Y(e, t, "re_leiji") ? nt(e, t, "leiji-jie", { source: t }, n) : (e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "leiji",
			data: {}
		}
	}, !0);
}
function Cv(e, t) {
	z(e).some((t) => Y(e, t, "fenji") && e.seats[t].hp > 0) && e.queue.unshift({
		k: "fenji-ask",
		victim: t
	});
}
function wv(e, t, n, r) {
	r != null && A(r) && Y(e, t, "mengjin") && e.queue.unshift({
		k: "mengjin-check",
		from: t,
		target: n
	});
}
function Tv(e, t, n, r, i = 0, a = null, o = 0) {
	if (r == null || !A(r)) return;
	let s = e.seats[t].equips.weapon;
	s == null || e.cards[s].name !== "axe" && e.cards[s].name !== "blade" || e.queue.unshift({
		k: "axe-check",
		from: t,
		target: n,
		cardName: r,
		ana: i,
		cardId: a,
		plus: o
	});
}
function Ev(e, t, n) {
	let r = e.seats[t].equips.weapon;
	return r == null || e.cards[r].name !== "blade" || !e.seats[t].alive || !e.seats[n].alive || !e.hands[t].some((n) => A(e.cards[n].name) || hy(e, t, n).includes("slash")) ? !1 : (e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "green_dragon",
			data: { target: n }
		}
	}, !0);
}
function Dv(e, t) {
	return z(e).filter((n) => n !== t && !N(e, n));
}
function Ov(e, t) {
	return [...e.hands[t].filter((t) => k(e.cards[t].name) != null), ...K(e, t)];
}
function kv(e) {
	let t = [];
	for (let n of z(e)) t.push(...K(e, n), ...e.seats[n].judges);
	return t;
}
function Av(e, t, n) {
	let r = k(e.cards[n].name);
	return z(e).filter((i) => i === t ? !1 : r == null ? !e.seats[i].judges.some((t) => uy(e, t) === uy(e, n)) : e.seats[i].equips[r] == null);
}
function jv(e, t) {
	return e.hands[t].filter((n) => {
		let r = e.cards[n].name, i = k(r) != null, a = O(r) === "trick" && r !== "nullification";
		return (i || a) && dx(e, t, n) != null;
	});
}
function Mv(e, t, n, r, i) {
	let a = e.cards[n].name;
	if (W(e, t, n), Me.has(a) || U(e, [n]), Fv(e, n, a, t, Lv(e, t, a, r)), i.push({
		kind: "play",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: n,
			name: a
		}
	}), L(e, {
		kind: "use",
		seat: t,
		card: a,
		target: r ?? void 0,
		cards: R(e, [n])
	}), e.beatMs = J.play, Me.has(a) || xv(e, t, i), F(e, t, 1), e.queue.unshift({
		k: "jiewei-follow",
		seat: t,
		cls: "trick"
	}), a === "savage_assault" || a === "archery_attack" || a === "god_salvation" || a === "amazing_grace") {
		let r = B(e, t).filter((e) => e !== t), o = z(e).find((t) => Y(e, t, "fenwei") && !e.seats[t].limitedUsed.includes("fenwei"));
		if (o != null && r.length >= 2) {
			e.pending = {
				kind: "skill-ask",
				seats: [o],
				ctx: {
					skill: "fenwei",
					data: {
						name: a,
						from: t,
						targets: r,
						suit: e.cards[n].suit,
						cardId: n
					}
				}
			};
			return;
		}
		nv(e, a, t, [], i, {
			suit: e.cards[n].suit,
			cardId: n
		});
		return;
	}
	if (Me.has(a)) {
		e.queue.unshift({
			k: "trick-effect",
			name: a,
			from: t,
			target: r,
			cardId: n,
			suit: e.cards[n].suit
		});
		return;
	}
	Qe(e, t, a, r, {
		k: "trick-effect",
		name: a,
		from: t,
		target: r,
		cardId: null,
		suit: e.cards[n].suit
	});
}
//#endregion
//#region src/games/sanguosha/rules/util.ts
function Nv(e, n) {
	let r = t(e.seed, e.rngCursor, n);
	return e.rngCursor += 1, r;
}
function Pv(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = Nv(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function L(e, t) {
	e.log.push(t), e.logTotal += 1;
}
function R(e, t) {
	return t.map((t) => ({ ...e.cards[t] }));
}
function Fv(e, t, n, r, i) {
	e.tableCard = {
		id: t,
		name: n,
		from: r
	}, e.targeting = i.length > 0 ? {
		from: r,
		targets: i
	} : null, e.queue.unshift({ k: "clear-table" });
}
function Iv(e, t, n, r) {
	e.tableCard = {
		id: t,
		name: n,
		from: r
	}, e.queue.unshift({ k: "clear-table" });
}
function Lv(e, t, n, r) {
	return r == null ? n === "savage_assault" || n === "archery_attack" || n === "god_salvation" || n === "amazing_grace" ? z(e).filter((e) => e !== t) : [] : [r];
}
function z(e) {
	return e.seats.map((e, t) => e.alive ? t : -1).filter((e) => e >= 0);
}
function Rv(e) {
	return {
		seat: e,
		phase: "judge",
		slashUsed: 0,
		red: 0,
		suits: [],
		dmg: {},
		dmgCards: {}
	};
}
function zv(e, t) {
	Y(e, t, "dangxian") && (e.queue.push({ k: "play-phase" }), L(e, {
		kind: "skill",
		seat: t,
		card: "dangxian"
	})), e.queue.push({ k: "phase-start" }, { k: "judge-scan" }, { k: "draw-phase" }, { k: "play-phase" }, { k: "discard-phase" }, { k: "end-phase" }, { k: "turn-end" });
}
function B(e, t) {
	let n = e.seats.length, r = [];
	for (let i = 0; i < n; i++) {
		let a = (t + i) % n;
		e.seats[a].alive && r.push(a);
	}
	return r;
}
function V(e, t, n) {
	if (t === n) return 0;
	if (e.seats[t].flags.xianzhen === n || e.seats[t].flags.zkNear === n + 1) return 1;
	let r = z(e), i = r.indexOf(t), a = r.indexOf(n);
	if (i < 0 || a < 0) return Infinity;
	let o = Math.abs(i - a), s = Math.min(o, r.length - o);
	return e.seats[n].equips.def_horse != null && (s += 1), e.seats[t].equips.off_horse != null && --s, Y(e, t, "mashu") && --s, Y(e, t, "qianju") && (s -= e.seats[t].maxHp - e.seats[t].hp), (Y(e, t, "tuntian") || Y(e, t, "re_tuntian")) && (s -= e.seats[t].tian.length), s -= e.seats[t].flags.qimouX ?? 0, e.turn?.seat === t && (s -= e.seats[t].flags.benxiN ?? 0), Math.max(1, s);
}
function Bv(e, t) {
	if (e.seats[t].flags.gongjiRange) return Infinity;
	let n = e.seats[t].equips.weapon;
	return n == null ? 1 : Ae[e.cards[n].name] ?? 1;
}
function Vv(e, t) {
	let n = e.seats[t].equips.weapon;
	return !!(n != null && e.cards[n].name === "crossbow" || Y(e, t, "paoxiao") || Y(e, t, "re_paoxiao"));
}
function Hv(e, t) {
	if (Vv(e, t)) return Infinity;
	let n = e.seats[t].flags;
	return 1 + (n.zhaxiangSlash ?? 0) + +!!n.tianyiWin + (n.jianchuSlash ?? 0) + (n.qimouX ?? 0) + +!!n.jcBuff + +!!n.mjBuff;
}
function Uv(e, t) {
	let n = e.seats[t];
	if (Y(e, t, "buqu") && n.chuang.length > 0) return n.chuang.length;
	let r = Y(e, t, "re_hongyan") && K(e, t).some((n) => dy(e, t, n) === "heart"), i = Y(e, t, "yingzi") || r ? n.maxHp : Math.max(0, n.hp);
	return Y(e, t, "re_xueyi") ? i += n.marks.yi ?? 0 : Y(e, t, "xueyi") && (i += 2 * z(e).filter((n) => n !== t && $v(e, n) === "qun").length), Y(e, t, "zongshi") && (i += ey(e)), i += n.quan.length, i += Wv(n.flags.jgSuits ?? 0), n.flags.mjBuff && (i += 1), i -= n.flags.jishe ?? 0, i += n.shu.length, n.flags.csLimit && --i, e.turn?.seat === t && n.flags.jigong ? n.flags.jgongDmg ?? 0 : i;
}
function Wv(e) {
	let t = 0;
	for (let n = 0; n < 4; n++) e & 1 << n && (t += 1);
	return t;
}
function Gv(e, t) {
	let n = e.seats[t], r = e.hands[t];
	return Y(e, t, "re_luoshen") && n.luoshen.length > 0 && (r = r.filter((e) => !n.luoshen.includes(e))), Y(e, t, "cangzhuo") && !n.flags.usedTrick && (r = r.filter((t) => O(e.cards[t].name) !== "trick")), n.flags.xianzhenLose && (r = r.filter((t) => !A(e.cards[t].name))), Y(e, t, "fulin") && e.turn != null && e.turn.seat === t && e.turn.gained && (r = r.filter((t) => !e.turn.gained.includes(t))), r.length;
}
function H(e, t, n) {
	let r = [];
	for (let i = 0; i < n; i++) {
		if (e.deck.length === 0) {
			if (e.discard.length === 0) break;
			e.deck = Pv(e, e.discard), e.discard = [];
		}
		let n = e.deck.shift();
		e.hands[t].push(n), r.push(n);
	}
	return e.turn != null && e.turn.seat === t && r.length > 0 && (e.turn.gained ??= []).push(...r), r;
}
function Kv(e, t, n) {
	let r = [];
	for (let i = 0; i < n; i++) {
		if (e.deck.length === 0) {
			if (e.discard.length === 0) break;
			e.deck = Pv(e, e.discard), e.discard = [];
		}
		let n = e.deck.pop();
		e.hands[t].push(n), r.push(n);
	}
	return e.turn != null && e.turn.seat === t && r.length > 0 && (e.turn.gained ??= []).push(...r), r;
}
function U(e, t) {
	if (e.discard.push(...t), e.turn != null) for (let n of t) {
		let t = e.cards[n].suit;
		e.turn.suits.includes(t) || e.turn.suits.push(t), (t === "heart" || t === "diamond") && (e.turn.red += 1);
	}
}
function W(e, t, n) {
	let r = e.hands[t].indexOf(n);
	return r < 0 ? !1 : (e.hands[t].splice(r, 1), !0);
}
function G(e, t) {
	let n = e.cards[t].suit;
	return n === "heart" || n === "diamond";
}
function qv(e, t) {
	let n = e.cards[t].suit;
	return n === "spade" || n === "club";
}
function Jv(e, t, n) {
	let r = e.seats[t];
	if (r.turnedOver = !r.turnedOver, n.push({
		kind: "turn-over",
		data: {
			seat: t,
			down: r.turnedOver
		}
	}), L(e, {
		kind: r.turnedOver ? "turn-over" : "turn-back",
		seat: t
	}), r.turnedOver || fv(e, t), r.alive) {
		if (Y(e, t, "shebian") && Yv(e).length > 0) {
			e.pending = {
				kind: "skill-ask",
				seats: [t],
				ctx: {
					skill: "shebian",
					data: {}
				}
			};
			return;
		}
		if (Y(e, t, "re_jiewei")) {
			!r.turnedOver && (e.hands[t].length > 0 || K(e, t).length > 0) && kv(e).length > 0 && (e.pending = {
				kind: "skill-ask",
				seats: [t],
				ctx: {
					skill: "jiewei-jie",
					data: {}
				}
			});
			return;
		}
		Y(e, t, "jiewei") && (e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "jiewei",
				data: {}
			}
		});
	}
}
function Yv(e) {
	let t = [];
	for (let n of z(e)) t.push(...K(e, n));
	return t;
}
function K(e, t) {
	let n = e.seats[t].equips;
	return [
		n.weapon,
		n.armor,
		n.off_horse,
		n.def_horse
	].filter((e) => e != null);
}
function Xv(e, t) {
	let n = e.seats[t].generalId;
	return n != null && !!Fe.get(n)?.female;
}
function Zv(e, t, n) {
	let r = [...e.hands[t], ...K(e, t)];
	if (r.length === 0) return null;
	let i = r[Nv(e, r.length)];
	if (W(e, t, i)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === i && (e.seats[t].equips[n] = null);
		I(e, t, i, n);
	}
	return U(e, [i]), pv(e, [i], n, t), dv(e, [i], t), i;
}
function Qv(e, t, n, r) {
	for (let i of n) if (W(e, t, i)) F(e, t, 1);
	else {
		for (let n of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[n] === i && (e.seats[t].equips[n] = null);
		I(e, t, i, r);
	}
	U(e, n), pv(e, n, r, t), dv(e, n, t);
}
function $v(e, t) {
	let n = e.seats[t].generalId;
	return n ? Fe.get(n)?.faction ?? null : null;
}
function ey(e) {
	return new Set(z(e).map((t) => $v(e, t)).filter((e) => e != null)).size;
}
function ty(e, t, n) {
	if (n) return null;
	let r = e.seats[t].equips.armor;
	return r == null ? Y(e, t, "bazhen") ? "eight_diagram" : null : e.cards[r].name;
}
function ny(e, t, n) {
	e.seats[t].chained || (e.seats[t].chained = !0, n.push({
		kind: "chain",
		data: { seat: t }
	}), L(e, {
		kind: "chain",
		seat: t
	}), fv(e, t));
}
function ry(e, t) {
	return e.players.indexOf(t);
}
function q(e) {
	return { code: e };
}
//#endregion
//#region src/games/sanguosha/rules/registry.ts
var J = {
	play: 700,
	respond: 500,
	draw: 450,
	discard: 450,
	equip: 550,
	damage: 900,
	recover: 550,
	judge: 1e3,
	death: 1400,
	move: 700,
	reveal: 2600
}, iy = /* @__PURE__ */ new Set(/* @__PURE__ */ "mashu.qicai.kongcheng.wushuang.jiuyuan.zhaxiang.yingzi.kuanggu.hongyan.buqu.bazhen.xueyi.huoshou.juxiang.wansha.weimu.benghuai.roulin.xiangle.duanchang.paoxiao.moshi.ninge.jueqing.xinwuyan.zhichi.jinjiu.dangxian.zongshi.re_qicai.re_jiuyuan.re_hongyan.re_xueyi.re_wansha.re_weimu.re_paoxiao".split(".")), ay = /* @__PURE__ */ new Set(/* @__PURE__ */ "jianxiong.hujia.fankui.guicai.ganglie.qingjian.tuxi.luoyi.tiandu.yiji.luoshen.qingguo.rende.jijiang.wusheng.yijue.paoxiao.tishen.guanxing.kongcheng.longdan.yajiao.mashu.tieji.jizhi.qicai.zhiheng.jiuyuan.qixi.fenwei.keji.qinxue.kurou.zhaxiang.yingzi.fanjian.guose.liuli.qianxun.lianying.jieyin.xiaoji.chuli.jijiu.wushuang.liyu.lijian.biyue.gongxin.shensu.jushou.jiewei.liegong.kuanggu.tianxiang.hongyan.buqu.fenji.leiji.guidao.huangtian.qiangxi.quhu.jieming.lianhuan.niepan.huoji.kanpo.bazhen.tianyi.luanji.xueyi.shuangxiong.mengjin.duanliang.xingshang.fangzhu.songwei.huoshou.zaiqi.juxiang.lieren.yinghun.haoshi.dimeng.jiuchi.roulin.benghuai.baonue.wansha.luanwu.weimu.qiaobian.tuntian.zaoxian.jixi.tiaoxin.zhiji.xiangle.fangquan.ruoyu.jiang.hunzi.zhiba.zhijian.guzheng.beige.duanchang.botu.qingnang.shebian.moshi.qimou.piaoling.ninge.cangzhuo.hanzhan.jianchu.jiezi.wulie.changbiao.sishu.re_jianxiong.re_guicai.re_ganglie.re_tuxi.re_luoyi.re_luoshen.re_rende.re_wusheng.re_yijue.re_paoxiao.re_tishen.re_guanxing.re_longdan.re_yajiao.re_tieji.re_qicai.re_zhiheng.re_jiuyuan.re_qixi.re_qinxue.re_jieyin.re_jijiu.re_liyu.re_lijian.re_biyue.re_shensu.re_jushou.re_jiewei.re_liegong.re_kuanggu.re_tianxiang.re_hongyan.re_leiji.re_guidao.re_huangtian.re_qiangxi.re_jieming.re_lianhuan.re_niepan.re_huoji.re_kanpo.re_luanji.re_xueyi.re_shuangxiong.re_duanliang.re_xingshang.re_fangzhu.re_zaiqi.re_jiuchi.re_baonue.re_wansha.re_luanwu.re_weimu.re_qiaobian.re_tuntian.re_zaoxian.re_tiaoxin.re_zhiji.re_fangquan.re_ruoyu.re_jiang.re_hunzi.re_zhiba.re_zhijian.re_guzheng.re_beige.luoying.jiushi.rezhenjun.jueqing.shangshi.xinxuanhuo.xinenyuan.olsanyao.rezhiman.xinwuyan.xinjujian.xinpojun.xuanfeng.ganlu.buyi.mingce.zhichi.xinxianzhen.jinjiu.zhenlie.miji.qice.zhiyu.quanji.zili.paiyi.qianxi.dangxian.fuli.fuhun.old_anxu.zhuiyi.gongji.jiefan.lihuo.chunlao.rezishou.zongshi.new_jiangchi.rejingce.chengxiang.renxin.danshou.zhiyan.zongxuan.qiuyuan.zhuikong.qiaoshui.jyzongshi.xiansi.junxing.yuce.duodao.anjian.longyin.xinjuece.xinmieji.xinfencheng.shenduan.yonglve.pindi.faen.xinsidi.qiangzhi.xiantu.olbenxi.xinzhongyong.fenli.pingkou.shenxing.olbingyi.chanhui.jiaojin.jianying.shibei.qieting.xianzhou.qianju.qingxi.huituo.mingjian.xingshuai.huomo.zuoding.qiaoshi.yanyu.zhanjue.qinwang.wurong.shizhi.xinanguo.yaoming.yanzhu.xingxue.xinzhaofu.huaiyi.jigong.shifei.jiaozhao.danxin.guizao.jiyu.qinqing.huisheng.dcduliang.fulin.kuangbi.jishe.lianhuo.taoluan.zhige.zongzuo.zhongjian.caishi.qingxian.juexiang.canyun.fumian.daiyan.jianzheng.zhuandui.tianbian.funan.xinjiexun.wengua.fuzhu.shouxi.huimin.bizhuan.tongbo".split("."));
function oy(e) {
	return e.skills.every((e) => ay.has(e)) && (!e.lordSkill || ay.has(e.lordSkill));
}
function sy(e, t) {
	return e === "standard" || t[e];
}
function Y(e, t, n) {
	let r = e.seats[t], i = r.skills.includes(n) || r.flags.fuhunBuff === !0 && (n === "wusheng" || n === "paoxiao");
	return !(!r.alive || !i || r.generalId != null && Fe.get(r.generalId)?.lordSkill === n && r.identity !== "lord" || r.flags.sealed && !iy.has(n) || r.flags.wanshaSeal && !iy.has(n));
}
function cy(e, t, n) {
	return Y(e, t, n) || Y(e, t, `re_${n}`);
}
function ly(e, t, n) {
	if (Y(e, t, n)) return n;
	let r = `re_${n}`;
	return Y(e, t, r) ? r : null;
}
function uy(e, t) {
	return e.judgeNames[t] ?? e.cards[t].name;
}
function dy(e, t, n) {
	let r = e.cards[n].suit;
	return r === "spade" && (Y(e, t, "hongyan") || Y(e, t, "re_hongyan")) ? "heart" : r;
}
function fy(e, t, n) {
	let r = e.cards[n].suit;
	return r === "spade" && (Y(e, t, "hongyan") || Y(e, t, "re_hongyan")) ? "heart" : r;
}
function py(e, t, n) {
	let r = fy(e, t, n);
	return r === "heart" || r === "diamond";
}
function X(e, t) {
	let n = e.seats[t];
	n.hp > 0 && n.chuang.length > 0 && (U(e, n.chuang), n.chuang = [], L(e, {
		kind: "buqu-clear",
		seat: t
	}));
}
function my(e) {
	for (let t of e.seats) t.flags.wanshaSeal && delete t.flags.wanshaSeal;
}
function hy(e, t, n) {
	let r = [], i = e.cards[n], a = e.turn != null && e.turn.seat === t, o = e.hands[t].includes(n), s = (n) => Y(e, t, n);
	if (G(e, n) && (o && s("wusheng") || s("re_wusheng")) && r.push("slash"), o && (s("longdan") || s("re_longdan")) && (A(i.name) && r.push("jink"), i.name === "jink" && r.push("slash"), s("re_longdan") && (i.name === "analeptic" && r.push("peach"), i.name === "peach" && r.push("analeptic"))), s("qingguo") && qv(e, n) && o && r.push("jink"), qv(e, n) && (o && s("qixi") || s("re_qixi")) && r.push("dismantlement"), G(e, n) && !a && (o && s("jijiu") || s("re_jijiu")) && r.push("peach"), G(e, n) && (o && s("huoji") || s("re_huoji")) && r.push("fire_attack"), qv(e, n) && (o && s("kanpo") || s("re_kanpo")) && r.push("nullification"), i.suit === "club" && (o && s("lianhuan") || s("re_lianhuan")) && r.push("iron_chain"), !o && s("re_jiewei") && r.push("nullification"), o && e.seats[t].flags.shuangxiongRed && qv(e, n) && r.push("duel"), o && e.seats[t].flags.shuangxiongBlack && G(e, n) && r.push("duel"), qv(e, n) && O(i.name) !== "trick" && (o && s("duanliang") || s("re_duanliang")) && r.push("supply_shortage"), (s("jiuchi") || s("re_jiuchi")) && i.suit === "spade" && o && r.push("analeptic"), Y(e, t, "jinjiu") && i.name === "analeptic" && o && r.push("slash"), Y(e, t, "shizhi") && e.seats[t].hp === 1 && i.name === "jink" && o && r.push("slash"), Y(e, t, "huomo") && o && qv(e, n) && O(i.name) !== "basic") {
		let n = e.seats[t].flags.hmUsed ?? 0;
		n & 1 || r.push("slash"), n & 2 || r.push("jink"), n & 4 || r.push("peach"), n & 8 || r.push("analeptic");
	}
	return r;
}
var gy = {
	slash: 1,
	jink: 2,
	peach: 4,
	analeptic: 8
};
function _y(e, t, n) {
	let r = gy[A(n) ? "slash" : n];
	r != null && (e.seats[t].flags.hmUsed = (e.seats[t].flags.hmUsed ?? 0) | r);
}
function vy(e, t, n, r) {
	return r != null && gy[r] != null && Y(e, t, "huomo") && qv(e, n) && O(e.cards[n].name) !== "basic";
}
function yy(e, t) {
	e.deck.unshift(t);
}
var by = [
	"slash",
	"fire_slash",
	"thunder_slash",
	"peach",
	"analeptic",
	"duel",
	"savage_assault",
	"archery_attack",
	"amazing_grace",
	"god_salvation",
	"ex_nihilo",
	"snatch",
	"dismantlement",
	"collateral",
	"fire_attack"
];
function xy(e, t) {
	return (e.seats[t].marks.xindanxin ?? 0) >= 1 ? by : by.slice(0, 5);
}
function Sy(e, t) {
	let n = e.seats[t].flags.jzName ?? 0;
	return n > 0 ? by[n - 1] : null;
}
var Cy = [
	"slash",
	"peach",
	"analeptic",
	"duel",
	"savage_assault",
	"archery_attack",
	"amazing_grace",
	"god_salvation",
	"ex_nihilo",
	"snatch",
	"dismantlement",
	"collateral",
	"fire_attack",
	"iron_chain"
];
function wy(e, t) {
	let n = e.seats[t].marks.tl ?? 0;
	return Cy.filter((e, t) => !(n >> t & 1));
}
function Ty(e, t, n) {
	let r = A(n) ? "slash" : n, i = Cy.indexOf(r);
	i >= 0 && (e.seats[t].marks.tl = (e.seats[t].marks.tl ?? 0) | 1 << i);
}
function Ey(e) {
	let t = [];
	for (let n of Object.values(e.cards)) {
		let e = O(n.name);
		(e === "basic" || e === "trick") && !t.includes(n.name) && t.push(n.name);
	}
	return t;
}
//#endregion
//#region src/games/sanguosha/rules/damage.ts
function Dy(e, t, n, r) {
	return n === t || !e.seats[n].alive || !Y(e, t, "zhenlie") ? !1 : (e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: "zhenlie",
			data: { resume: r }
		}
	}, !0);
}
function Oy(e, t, n, r = !1, i = !1, a = !1) {
	let o = t.target, s = t.source;
	if (e.turn != null && e.turn.seat !== o && e.seats[o].alive && Y(e, o, "zhichi") && !e.seats[o].flags.zhichi && (e.seats[o].flags.zhichi = !0, L(e, {
		kind: "skill",
		seat: o,
		card: "zhichi"
	})), e.seats[o].alive && e.seats[o].turnedOver && Y(e, o, "jiushi") && t.wasDown === !0 && (Jv(e, o, n), e.pending)) return !0;
	if (t.reason === "slash" && s != null && s !== o && e.seats[s].alive && Y(e, s, "moshi") && t.cardId != null && e.discard.includes(t.cardId) && (e.seats[o].equips.armor != null || e.seats[o].equips.off_horse != null || e.seats[o].equips.def_horse != null) && (e.discard = e.discard.filter((e) => e !== t.cardId), e.seats[o].moshi.push(t.cardId), n.push({
		kind: "move",
		data: {
			seat: o,
			name: "moshi"
		}
	}), L(e, {
		kind: "moshi-put",
		seat: s,
		target: o,
		cards: R(e, [t.cardId])
	})), !i && s != null && s !== o && e.seats[s].alive && Y(e, s, "re_kuanggu") && V(e, s, o) <= 1) {
		let n = [];
		return e.seats[s].hp < e.seats[s].maxHp && n.push("recover"), n.push("draw"), e.pending = {
			kind: "skill-ask",
			seats: [s],
			ctx: {
				skill: "kuanggu",
				options: n,
				data: { ev: t }
			}
		}, !0;
	}
	if (!i && s != null && s !== o && e.seats[s].alive && Y(e, s, "kuanggu") && V(e, s, o) <= 1 && e.seats[s].hp < e.seats[s].maxHp && (e.seats[s].hp += 1, n.push({
		kind: "recover",
		rid: e.seats[s].rid,
		data: {
			seat: s,
			n: 1
		}
	}), L(e, {
		kind: "recover",
		seat: s,
		n: 1
	}), e.beatMs = J.recover, X(e, s)), !e.seats[o].alive) return !1;
	if (!r && t.reason === "slash") {
		let n = z(e).find((t) => (Y(e, t, "beige") || Y(e, t, "re_beige")) && e.hands[t].length + K(e, t).length > 0);
		if (n != null) return e.queue.unshift({
			k: "beige-next",
			ev: t
		}), e.pending = {
			kind: "skill-ask",
			seats: [n],
			ctx: {
				skill: Y(e, n, "re_beige") ? "re_beige" : "beige",
				data: { ev: t }
			}
		}, !0;
	}
	if (!a && s != null) {
		let n = [o, s].find((t) => e.seats[t].alive && Y(e, t, "yaoming") && !e.seats[t].flags.ymDone && z(e).some((n) => n !== t && e.hands[n].length !== e.hands[t].length));
		if (n != null) return e.queue.unshift({
			k: "yaoming-next",
			ev: t
		}), e.pending = {
			kind: "skill-seats",
			seats: [n],
			ctx: {
				skill: "yaoming-target",
				min: 0,
				max: 1,
				data: { candidates: z(e).filter((t) => t !== n && e.hands[t].length !== e.hands[n].length) }
			}
		}, !0;
	}
	if (s != null && e.seats[s].alive && $v(e, s) === "qun" && z(e).some((t) => t !== s && cy(e, t, "baonue")) && e.queue.unshift({
		k: "baonue-check",
		source: s
	}), e.seats[o].alive && Y(e, o, "shibei")) {
		if (e.seats[o].flags.sbHurt) {
			if (L(e, {
				kind: "shibei-lose",
				seat: o
			}), Ly(e, o, 1, n), e.pending) return !0;
		} else e.seats[o].flags.sbHurt = !0, e.seats[o].hp < e.seats[o].maxHp && (e.seats[o].hp += 1, n.push({
			kind: "recover",
			rid: e.seats[o].rid,
			data: {
				seat: o,
				n: 1
			}
		}), e.beatMs = J.recover), L(e, {
			kind: "shibei-recover",
			seat: o
		});
	}
	t.reason === "slash" && s != null && s !== o && e.seats[s].alive && Y(e, s, "xinzhongyong") && e.queue.unshift({
		k: "zy-check",
		from: s,
		target: o,
		cardId: t.cardId,
		jinkId: null
	});
	let c = s == null ? null : e.seats[s].equips.weapon;
	t.reason === "slash" && s != null && s !== o && e.seats[s].alive && c != null && e.cards[c].name === "kylin_bow" && (e.seats[o].equips.off_horse != null || e.seats[o].equips.def_horse != null) && e.queue.unshift({
		k: "kylin-check",
		from: s,
		target: o
	}), t.reason === "slash" && s != null && s !== o && e.seats[s].alive && Y(e, s, "lieren") && e.hands[s].length > 0 && e.hands[o].length > 0 && e.queue.unshift({
		k: "lieren-check",
		from: s,
		target: o
	});
	let l = [
		"jianxiong",
		"re_jianxiong",
		"fankui",
		"ganglie",
		"re_ganglie",
		"yiji",
		"jieming",
		"re_jieming",
		"fangzhu",
		"re_fangzhu",
		"zhiyu",
		"quanji",
		"chengxiang",
		"duodao",
		"yuce",
		"huituo",
		"danxin"
	].find((n) => Y(e, o, n) ? n === "duodao" ? t.reason === "slash" && s != null && s !== o && e.seats[s].alive && e.seats[s].equips.weapon != null && fx(e, o) : n !== "yuce" || e.hands[o].length > 0 && s != null && s !== o && e.seats[s].alive : !1), u = t.source != null && t.source !== o && e.seats[t.source].alive && (Y(e, t.source, "liyu") || Y(e, t.source, "re_liyu")) && t.reason === "slash" && fx(e, o) ? {
		source: t.source,
		target: o
	} : null;
	return s != null && s !== o && e.seats[o].alive && Y(e, o, "xinenyuan") && e.seats[s].alive && gv(e, o, s, t.amount, u) ? !0 : l ? ky(e, o, l, {
		amountLeft: t.amount,
		source: t.source,
		cardId: t.cardId,
		liyu: u
	}) : u ? (Ay(e, u), !0) : !1;
}
function ky(e, t, n, r) {
	if (n === "danxin" && (e.seats[t].marks.xindanxin ?? 0) >= 2) return H(e, t, 1), L(e, {
		kind: "skill",
		seat: t,
		card: n
	}), L(e, {
		kind: "skill-draw",
		seat: t,
		card: n,
		n: 1
	}), e.beatMs = J.draw, $_(e, t, n, r);
	if (n === "danxin") return e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: n,
			options: ["dx-draw", "dx-modify"],
			data: r
		}
	}, !0;
	if (n === "jianxiong" || n === "re_jianxiong") {
		let i = r.cardId;
		if (n === "re_jianxiong") return i != null && e.discard.includes(i) && (e.discard = e.discard.filter((e) => e !== i), e.hands[t].push(i)), H(e, t, 1), L(e, {
			kind: "skill",
			seat: t,
			card: n
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: n,
			n: 1
		}), e.beatMs = J.draw, $_(e, t, n, r);
		let a = i != null && e.discard.includes(i) ? ["obtain", "draw"] : ["draw"];
		return e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: n,
				options: a,
				data: r
			}
		}, !0;
	}
	return e.pending = {
		kind: "skill-ask",
		seats: [t],
		ctx: {
			skill: n,
			data: r
		}
	}, !0;
}
function Ay(e, t) {
	let n = Y(e, t.source, "re_liyu");
	e.pending = {
		kind: "skill-ask",
		seats: [n ? t.source : t.target],
		ctx: {
			skill: n ? "re_liyu" : "liyu",
			data: {
				source: t.source,
				target: t.target
			}
		}
	};
}
function jy(e, t, n, r) {
	if (e.turn != null && Y(e, e.turn.seat, "re_wansha")) for (let n of z(e)) n !== t && (e.seats[n].flags.wanshaSeal = !0);
	if (!n.buyiDone) {
		let r = z(e).find((t) => Y(e, t, "buyi"));
		if (r != null && e.hands[t].length > 0) {
			e.pending = {
				kind: "skill-ask",
				seats: [r],
				ctx: {
					skill: "buyi",
					data: {
						target: t,
						source: n.source,
						...n.dmg ? { dmg: n.dmg } : {},
						...n.zx ? { zx: n.zx } : {}
					}
				}
			};
			return;
		}
	}
	let i = Y(e, t, "re_niepan") ? "re_niepan" : Y(e, t, "niepan") ? "niepan" : null;
	if (i != null && !e.seats[t].limitedUsed.includes(i)) {
		e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: i,
				data: {
					source: n.source,
					...n.dmg ? { dmg: n.dmg } : {},
					...n.zx ? { zx: n.zx } : {}
				}
			}
		};
		return;
	}
	if (!n.fuliDone && Y(e, t, "fuli") && !e.seats[t].limitedUsed.includes("fuli")) {
		e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "fuli",
				data: {
					source: n.source,
					...n.dmg ? { dmg: n.dmg } : {},
					...n.zx ? { zx: n.zx } : {}
				}
			}
		};
		return;
	}
	if (!n.chunDone) {
		let r = z(e).find((t) => Y(e, t, "chunlao") && e.seats[t].chun.length > 0);
		if (r != null) {
			e.pending = {
				kind: "skill-ask",
				seats: [r],
				ctx: {
					skill: "chunlao-save",
					data: {
						target: t,
						source: n.source,
						...n.dmg ? { dmg: n.dmg } : {},
						...n.zx ? { zx: n.zx } : {}
					}
				}
			};
			return;
		}
	}
	if (Y(e, t, "buqu")) {
		e.deck.length === 0 && e.discard.length > 0 && (e.deck = Pv(e, e.discard), e.discard = []);
		let i = e.deck.shift();
		if (i != null) {
			r.push({
				kind: "reveal",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					card: i
				}
			}), e.beatMs = J.judge;
			let a = e.seats[t].chuang.some((t) => e.cards[t].point === e.cards[i].point);
			if (L(e, {
				kind: "buqu-check",
				seat: t,
				cards: R(e, [...e.seats[t].chuang, i]),
				n: +!a
			}), a) U(e, [i]);
			else {
				e.seats[t].chuang.push(i), e.seats[t].hp = 1, r.push({
					kind: "recover",
					rid: e.seats[t].rid,
					data: {
						seat: t,
						n: 1,
						by: "buqu"
					}
				}), my(e), n.dmg && e.queue.unshift(n.dmg), n.zx && n.zx > 0 && Iy(e, t, n.zx);
				return;
			}
		}
	}
	if (Y(e, t, "xingshuai") && !e.seats[t].limitedUsed.includes("xingshuai")) {
		let r = z(e).filter((n) => n !== t && $v(e, n) === "wei");
		if (r.length > 0) {
			e.seats[t].limitedUsed.push("xingshuai"), L(e, {
				kind: "skill",
				seat: t,
				card: "xingshuai"
			}), e.pending = {
				kind: "skill-ask",
				seats: [r[0]],
				ctx: {
					skill: "xingshuai",
					data: {
						lord: t,
						helpers: r,
						idx: 0,
						yes: [],
						source: n.source,
						...n.dmg ? { dmg: n.dmg } : {},
						...n.zx ? { zx: n.zx } : {}
					}
				}
			};
			return;
		}
	}
	e.pending = {
		kind: "peach-save",
		seats: B(e, t),
		ctx: {
			target: t,
			source: n.source,
			...n.dmg ? { dmg: n.dmg } : {},
			...n.zx ? { zx: n.zx } : {}
		}
	};
}
function My(e, t, n) {
	let r = t.helpers, i = t.idx, a = t.yes;
	if (i + 1 < r.length) {
		e.pending = {
			kind: "skill-ask",
			seats: [r[i + 1]],
			ctx: {
				skill: "xingshuai",
				data: {
					...t,
					idx: i + 1
				}
			}
		};
		return;
	}
	let o = t.lord;
	e.queue.unshift({
		k: "xs-done",
		lord: o,
		source: t.source ?? null,
		...t.dmg == null ? {} : { dmg: t.dmg },
		...t.zx == null ? {} : { zx: t.zx }
	});
	for (let t = a.length - 1; t >= 0; t--) e.queue.unshift({
		k: "damage",
		source: null,
		target: a[t],
		amount: 1,
		nature: "normal",
		reason: "xingshuai",
		cardId: null
	});
}
function Ny(e, t, n) {
	if (e.seats[t.target].alive) {
		if (t.source != null && t.source !== t.target && e.seats[t.source].alive && e.seats[t.source].flags.zishou) {
			L(e, {
				kind: "skill",
				seat: t.source,
				card: "rezishou"
			});
			return;
		}
		if (t.reason === "slash" && t.source != null && t.source !== t.target && e.seats[t.source].alive) {
			let n = e.seats[t.source].equips.weapon;
			if (n != null && e.cards[n].name === "ice_sword" && et(e, t.target, "dismantlement", !1).length > 0) {
				e.pending = {
					kind: "skill-ask",
					seats: [t.source],
					ctx: {
						skill: "ice_sword",
						data: {
							target: t.target,
							ev: t
						}
					}
				};
				return;
			}
		}
		if (t.reason === "slash" && t.source != null && t.source !== t.target && e.seats[t.source].alive && Y(e, t.source, "qingxi")) {
			let n = e.seats[t.source].equips.weapon;
			if (n != null) {
				let r = Ae[e.cards[n].name] ?? 1;
				if (e.hands[t.target].length >= r) {
					e.pending = {
						kind: "skill-ask",
						seats: [t.target],
						ctx: {
							skill: "qingxi",
							options: ["qx-discard", "qx-plus"],
							noPass: !0,
							data: {
								ev: t,
								x: r
							}
						}
					};
					return;
				}
				t.amount += 1, L(e, {
					kind: "qingxi-plus",
					seat: t.source,
					target: t.target
				});
			}
		}
		Py(e, t, n);
	}
}
function Py(e, t, n, r = !1, i = !1) {
	if (!e.seats[t.target].alive) return;
	if (!r && t.source != null && t.source !== t.target && e.seats[t.source].alive && Y(e, t.source, "rezhiman") && et(e, t.target, "snatch").length > 0) {
		e.pending = {
			kind: "skill-ask",
			seats: [t.source],
			ctx: {
				skill: "rezhiman",
				data: {
					target: t.target,
					ev: t
				}
			}
		};
		return;
	}
	if (!i && t.source != null && t.source !== t.target && e.seats[t.source].alive && Y(e, t.target, "huisheng") && e.hands[t.target].length > 0 && !((e.seats[t.target].marks.hsBan ?? 0) & 1 << t.source)) {
		e.pending = {
			kind: "skill-cards",
			seats: [t.target],
			ctx: {
				skill: "huisheng-offer",
				min: 1,
				max: e.hands[t.target].length,
				data: { ev: t }
			}
		};
		return;
	}
	let a = Y(e, t.target, "re_tianxiang") ? "re_tianxiang" : Y(e, t.target, "tianxiang") ? "tianxiang" : null;
	if (a != null) {
		let n = e.hands[t.target].filter((n) => dy(e, t.target, n) === "heart");
		if (a === "re_tianxiang" && n.push(...K(e, t.target).filter((n) => dy(e, t.target, n) === "heart")), n.length > 0 && z(e).some((e) => e !== t.target)) {
			e.pending = {
				kind: "skill-ask",
				seats: [t.target],
				ctx: {
					skill: a,
					data: { ev: t }
				}
			};
			return;
		}
	}
	if (e.seats[t.target].hp === 1) {
		let n = z(e).find((n) => n !== t.target && Y(e, n, "renxin") && K(e, n).length + e.hands[n].filter((t) => O(e.cards[t].name) === "equip").length > 0);
		if (n != null) {
			e.pending = {
				kind: "skill-ask",
				seats: [n],
				ctx: {
					skill: "renxin",
					data: { ev: t }
				}
			};
			return;
		}
	}
	if (t.source != null && t.source !== t.target && e.seats[t.source].alive && !Xv(e, t.source) && Y(e, t.target, "jiaojin") && [...e.hands[t.target], ...K(e, t.target)].filter((t) => O(e.cards[t].name) === "equip").length > 0) {
		e.pending = {
			kind: "skill-ask",
			seats: [t.target],
			ctx: {
				skill: "jiaojin",
				data: { ev: t }
			}
		};
		return;
	}
	Fy(e, t, n);
}
function Fy(e, t, n) {
	let r = e.seats[t.target];
	if (!r.alive) return;
	let i = t.amount;
	if (t.source != null && e.seats[t.source].alive && Y(e, t.source, "jueqing")) {
		L(e, {
			kind: "skill",
			seat: t.source,
			card: "jueqing"
		}), Ly(e, t.target, i, n);
		return;
	}
	if ((t.reason === "duel" || t.cardId != null && O(e.cards[t.cardId].name) === "trick") && (t.source != null && e.seats[t.source].alive && Y(e, t.source, "xinwuyan") || Y(e, t.target, "xinwuyan"))) {
		L(e, {
			kind: "skill",
			seat: Y(e, t.target, "xinwuyan") ? t.target : t.source,
			card: "xinwuyan"
		});
		return;
	}
	if ((r.marks.lie ?? 0) > 0) {
		r.marks.lie = (r.marks.lie ?? 0) - 1, L(e, {
			kind: "skill",
			seat: t.target,
			card: "wulie"
		});
		return;
	}
	if (Y(e, t.target, "re_weimu") && e.turn != null && e.turn.seat === t.target) {
		let a = H(e, t.target, 2 * i);
		a.length > 0 && (e.beatMs = J.draw, n.push({
			kind: "draw",
			rid: r.rid,
			data: {
				seat: t.target,
				n: a.length
			},
			for: [r.rid],
			secret: { cards: a }
		}), P(e, t.target, a)), L(e, {
			kind: "skill",
			seat: t.target,
			card: "weimu"
		});
		return;
	}
	if (t.source != null && t.reason === "slash" && (e.seats[t.source].marks.pao ?? 0) > 0) {
		let n = e.seats[t.source].marks.pao ?? 0;
		e.seats[t.source].marks.pao = 0, i += n, L(e, {
			kind: "skill",
			seat: t.source,
			card: "paoxiao",
			n
		});
	}
	if (t.source != null && t.reason === "slash" && r.flags.yijueBy === t.source && t.cardId != null && dy(e, t.source, t.cardId) === "heart" && (i += 1), t.source != null && (t.reason === "slash" || t.reason === "duel") && (e.seats[t.source].flags.luoyi || (e.seats[t.source].marks.luoyiJie ?? 0) > 0) && (i += 1), t.source != null && t.reason === "slash" && e.hands[t.target].length === 0) {
		let n = e.seats[t.source].equips.weapon;
		n != null && e.cards[n].name === "guding_blade" && (i += 1);
	}
	t.source != null && t.reason === "slash" && Y(e, t.source, "anjian") && V(e, t.target, t.source) > Bv(e, t.target) && (i += 1);
	let a = t.source == null ? null : e.seats[t.source].equips.weapon, o = t.reason === "slash" && (a != null && e.cards[a].name === "qinggang_sword" || t.source != null && e.seats[t.source].flags.xianzhen === t.target || !!t.pierce), s = r.equips.armor != null && !o ? e.cards[r.equips.armor].name : null;
	if (s === "vine" && t.nature === "fire" && (i += 1), t.nature === "fire" && r.chained && t.reason !== "chain" && Y(e, t.target, "lianhuo") && (i += 1, L(e, {
		kind: "skill",
		seat: t.target,
		card: "lianhuo"
	})), s === "silver_lion" && i > 1 && (i = 1), r.hp -= i, n.push({
		kind: "damage",
		rid: r.rid,
		data: {
			seat: t.target,
			n: i,
			nature: t.nature,
			source: t.source
		}
	}), L(e, {
		kind: "damage",
		seat: t.target,
		n: i,
		from: t.source ?? void 0,
		reason: t.reason
	}), t.source != null && e.turn != null && e.turn.seat === t.source && e.turn.phase === "play" && e.seats[t.source].flags.jigong) {
		let n = e.seats[t.source].flags;
		n.jgongDmg = (n.jgongDmg ?? 0) + i;
	}
	if (t.zj != null && (e.seats[t.zj].flags.zjHurt = (e.seats[t.zj].flags.zjHurt ?? 0) | 1 << t.target), lv(e, t.target), t.lihuo && t.source != null && e.seats[t.source].alive && (L(e, {
		kind: "skill",
		seat: t.source,
		card: "lihuo"
	}), Ly(e, t.source, 1, n)), t.fuhun && t.source != null && e.seats[t.source].alive && !e.seats[t.source].flags.fuhunBuff && (e.seats[t.source].flags.fuhunBuff = !0, L(e, {
		kind: "skill",
		seat: t.source,
		card: "fuhun"
	})), e.turn != null && (e.turn.dmg[t.target] = (e.turn.dmg[t.target] ?? 0) + 1, t.cardId != null && (e.turn.dmgCards[t.target] ??= []).push(t.cardId), e.turn.dmg[t.target] === 2 && z(e).some((n) => (n === t.target || n === t.source) && Y(e, n, "ninge")) && e.queue.unshift({
		k: "ninge-check",
		victim: t.target
	}), t.source != null && t.reason === "slash" && e.seats[t.source].flags.cbPending && (e.seats[t.source].flags.cbHit = e.seats[t.source].flags.cbPending, delete e.seats[t.source].flags.cbPending), t.source != null && t.ana && e.turn.seat === t.source && Y(e, t.source, "re_jiuchi") && (e.seats[t.source].flags.benghuaiOff = !0)), t.nature !== "normal" && r.chained && (r.chained = !1, n.push({
		kind: "unchain",
		data: { seat: t.target }
	}), L(e, {
		kind: "unchain",
		seat: t.target
	})), t.nature !== "normal" && t.reason !== "chain") {
		let n = B(e, t.target).filter((n) => n !== t.target && e.seats[n].chained && e.seats[n].alive);
		for (let r = n.length - 1; r >= 0; r--) e.queue.unshift({
			k: "damage",
			source: t.source,
			target: n[r],
			amount: i,
			nature: t.nature,
			reason: "chain",
			cardId: null
		});
	}
	let c = {
		k: "after-damage",
		source: t.source,
		target: t.target,
		amount: i,
		reason: t.reason,
		cardId: t.cardId,
		suit: t.cardId == null ? null : e.cards[t.cardId].suit,
		wasDown: r.turnedOver
	};
	r.hp <= 0 ? jy(e, t.target, {
		source: t.source,
		dmg: c
	}, n) : e.queue.unshift(c);
}
function Iy(e, t, n) {
	if (L(e, {
		kind: "skill-draw",
		seat: t,
		card: "zhaxiang",
		n: H(e, t, 3 * n).length
	}), e.turn?.seat === t) {
		let r = e.seats[t].flags;
		r.zhaxiangSlash = (r.zhaxiangSlash ?? 0) + n, r.zhaxiangRed = !0;
	}
}
function Ly(e, t, n, r) {
	let i = e.seats[t];
	i.hp -= n, r.push({
		kind: "damage",
		rid: i.rid,
		data: {
			seat: t,
			n,
			nature: "normal",
			source: null
		}
	}), L(e, {
		kind: "lose-hp",
		seat: t,
		n
	}), lv(e, t), i.hp <= 0 ? jy(e, t, {
		source: null,
		zx: Y(e, t, "zhaxiang") ? n : 0
	}, r) : Y(e, t, "zhaxiang") && Iy(e, t, n);
}
//#endregion
//#region src/games/sanguosha/rules/advance/combat.ts
function Ry(e, t, n) {
	let r = e.seats[t.target];
	if (!r.alive || !e.seats[t.from].alive) return;
	let i = {
		from: t.from,
		target: t.target,
		cardName: t.cardName,
		suit: t.suit,
		cardId: t.cardId,
		ana: t.ana,
		noJink: t.noJink,
		plus: t.plus,
		...t.lihuo ? { lihuo: !0 } : {},
		...t.fuhun ? { fuhun: !0 } : {},
		...t.ylFrom == null ? {} : { ylFrom: t.ylFrom },
		...t.bxPierce ? { bxPierce: !0 } : {}
	};
	if (L(e, {
		kind: "slash",
		seat: t.from,
		target: t.target
	}), n.push({
		kind: "slash",
		rid: e.seats[t.from].rid,
		data: {
			from: t.from,
			target: t.target,
			name: t.cardName
		}
	}), e.beatMs = J.play, r.flags.zhichi) {
		L(e, {
			kind: "skill",
			seat: t.target,
			card: "zhichi"
		});
		return;
	}
	if (!t.zlDone && Dy(e, t.target, t.from, {
		...t,
		zlDone: !0
	})) return "stop";
	if (!t.zdDone && t.from !== t.target) {
		let n = Y(e, t.from, "zhuandui") ? t.from : Y(e, t.target, "zhuandui") ? t.target : -1;
		if (n >= 0 && e.seats[n].alive && e.hands[t.from].length > 0 && e.hands[t.target].length > 0) return e.pending = {
			kind: "skill-ask",
			seats: [n],
			ctx: {
				skill: "zhuandui",
				data: {
					from: t.from,
					target: t.target,
					resume: {
						...t,
						zdDone: !0
					}
				}
			}
		}, "stop";
	}
	if (!t.sxDone && Y(e, t.target, "shouxi")) {
		let n = r.marks.shouxi ?? 0, i = Ey(e).filter((e, t) => !(n & 1 << t));
		if (i.length > 0) return e.pending = {
			kind: "skill-ask",
			seats: [t.target],
			ctx: {
				skill: "shouxi",
				options: i,
				data: {
					from: t.from,
					resume: {
						...t,
						sxDone: !0
					}
				}
			}
		}, "stop";
	}
	if (!t.bzDone && t.target !== t.from && Y(e, t.target, "bizhuan") && t.suit === "spade" && e.seats[t.target].shu.length < 4) return e.queue.unshift({
		...t,
		bzDone: !0
	}), e.pending = {
		kind: "skill-ask",
		seats: [t.target],
		ctx: {
			skill: "bizhuan",
			data: {}
		}
	}, "stop";
	if (!t.qyDone && Y(e, t.target, "qiuyuan") && A(t.cardName)) {
		let n = Bv(e, t.from), r = z(e).filter((r) => r !== t.target && r !== t.from && V(e, t.from, r) <= n && !N(e, r));
		if (r.length > 0) return e.pending = {
			kind: "skill-ask",
			seats: [t.target],
			ctx: {
				skill: "qiuyuan",
				data: {
					candidates: r,
					resume: {
						...t,
						qyDone: !0
					},
					info: i
				}
			}
		}, "stop";
	}
	if ((t.suit === "heart" || t.suit === "diamond") && A(t.cardName) && vv(e, t.target, n), !t.jcDone && Y(e, t.from, "jianchu") && fx(e, t.target)) return e.pending = {
		kind: "skill-ask",
		seats: [t.from],
		ctx: {
			skill: "jianchu",
			data: {
				info: i,
				target: t.target
			}
		}
	}, "stop";
	if (!t.pjDone && e.turn != null && e.turn.seat === t.from && e.turn.phase === "play" && Y(e, t.from, "xinpojun") && fx(e, t.target)) return e.pending = {
		kind: "skill-ask",
		seats: [t.from],
		ctx: {
			skill: "xinpojun",
			data: {
				info: i,
				target: t.target
			}
		}
	}, "stop";
	if (Je(e, i) || (He(e, i, n), e.pending)) return "stop";
}
function zy(e, t) {
	e.seats[t.target].alive && !t.immune.includes(t.target) && (t.name !== "savage_assault" || !Y(e, t.target, "huoshou") && !Y(e, t.target, "juxiang")) && (t.suit == null || t.suit !== "spade" && t.suit !== "club" || !Y(e, t.target, "weimu")) && Qe(e, t.from, t.name, t.target, {
		k: "aoe-target",
		name: t.name,
		from: t.from,
		target: t.target,
		suit: t.suit,
		cardId: t.cardId
	});
}
function By(e, t) {
	let n = e.seats[t.target];
	if (n.alive) {
		if (n.flags.zhichi) {
			L(e, {
				kind: "skill",
				seat: t.target,
				card: "zhichi"
			});
			return;
		}
		if (!t.zlDone && Dy(e, t.target, t.from, {
			...t,
			zlDone: !0
		})) return "stop";
		if (!t.bzDone && t.target !== t.from && Y(e, t.target, "bizhuan") && t.suit === "spade" && n.shu.length < 4) return e.queue.unshift({
			...t,
			bzDone: !0
		}), e.pending = {
			kind: "skill-ask",
			seats: [t.target],
			ctx: {
				skill: "bizhuan",
				data: {}
			}
		}, "stop";
		if (n.equips.armor != null && e.cards[n.equips.armor].name === "vine") {
			L(e, {
				kind: "nullified",
				seat: t.target,
				card: t.name
			});
			return;
		}
		return e.pending = {
			kind: t.name === "savage_assault" ? "slash-response" : "jink",
			seats: [t.target],
			ctx: {
				from: t.from,
				aoe: t.name,
				need: 1,
				count: 0,
				cardId: t.cardId
			}
		}, "stop";
	}
}
function Vy(e, t, n) {
	let r = z(e).find((n) => n !== t.from && Y(e, n, "juxiang"));
	if (r != null && e.discard.includes(t.cardId)) return e.discard = e.discard.filter((e) => e !== t.cardId), e.hands[r].push(t.cardId), n.push({
		kind: "take",
		rid: e.seats[r].rid,
		data: { seat: r },
		for: [e.seats[r].rid],
		secret: { card: t.cardId }
	}), L(e, {
		kind: "juxiang",
		seat: r
	}), e.beatMs = J.draw, "stop";
}
function Hy(e, t) {
	if (e.seats[t.from].alive && e.seats[t.target].alive && e.hands[t.from].length !== 0 && e.hands[t.target].length !== 0) return e.pending = {
		kind: "skill-ask",
		seats: [t.from],
		ctx: {
			skill: "lieren",
			data: { target: t.target }
		}
	}, "stop";
}
function Uy(e, t, n) {
	if (!e.seats[t.from].alive || !e.seats[t.target].alive) return;
	let r = e.seats[t.from].equips.weapon;
	if (r == null || e.cards[r].name !== "kylin_bow") return;
	let i = ["off_horse", "def_horse"].filter((n) => e.seats[t.target].equips[n] != null);
	if (i.length !== 0) {
		if (i.length === 1) {
			let r = e.seats[t.target].equips[i[0]];
			e.seats[t.target].equips[i[0]] = null, U(e, [r]), I(e, t.target, r, n), L(e, {
				kind: "kylin",
				seat: t.from,
				target: t.target
			}), e.beatMs = J.discard;
			return;
		}
		return e.pending = {
			kind: "skill-cards",
			seats: [t.from],
			ctx: {
				skill: "kylin_bow",
				min: 1,
				max: 1,
				data: {
					pool: i.map((n) => e.seats[t.target].equips[n]),
					target: t.target
				}
			}
		}, "stop";
	}
}
function Wy(e, t) {
	if ($_(e, t.seat, "fangzhu", t.data)) return "stop";
}
function Gy(e, t, n) {
	let [r, ...i] = t.seats;
	if (i.length > 0 ? e.queue.unshift({
		k: "luanwu-step",
		seats: i,
		from: t.from
	}) : e.seats[t.from].alive && Y(e, t.from, "re_luanwu") && e.queue.unshift({
		k: "luanwu-end",
		from: t.from
	}), r == null || !e.seats[r].alive) return;
	let a = e.hands[r].filter((t) => A(e.cards[t].name));
	return a.length === 0 ? (Ly(e, r, 1, n), e.pending ? "stop" : void 0) : (e.pending = {
		kind: "skill-cards",
		seats: [r],
		ctx: {
			skill: "luanwu-slash",
			min: 0,
			max: 1,
			data: { pool: a }
		}
	}, "stop");
}
function Ky(e, t, n) {
	if (Oy(e, t.ev, n, !0)) return "stop";
}
function qy(e, t, n) {
	if (Oy(e, t.ev, n, !0, !1, !0)) return "stop";
}
function Jy(e, t, n) {
	let r = t.seat;
	if (e.seats[r].alive) {
		let t = H(e, r, 1);
		n.push({
			kind: "draw",
			rid: e.seats[r].rid,
			data: {
				seat: r,
				n: t.length
			},
			for: [e.seats[r].rid],
			secret: { cards: t }
		}), L(e, {
			kind: "skill-draw",
			seat: r,
			card: "zhanjue",
			n: t.length
		}), e.beatMs = J.draw;
	}
	let i = e.seats[r].flags.zjHurt ?? 0;
	for (let t of z(e)) {
		if (t === r || !(i & 1 << t)) continue;
		let a = H(e, t, 1);
		n.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: a.length
			},
			for: [e.seats[t].rid],
			secret: { cards: a }
		}), L(e, {
			kind: "skill-draw",
			seat: t,
			card: "zhanjue",
			n: a.length
		});
	}
	e.seats[r].flags.zjHurt = 0;
	let a = (e.seats[r].flags.zjDraw ?? 0) + 1;
	e.seats[r].flags.zjDraw = a, a >= 2 && (e.seats[r].flags.zjOff = !0);
}
function Yy(e, t) {
	if (e.seats[t.lord].alive && e.seats[t.lord].hp <= 0) return e.pending = {
		kind: "peach-save",
		seats: B(e, t.lord),
		ctx: {
			target: t.lord,
			source: t.source,
			...t.dmg ? { dmg: t.dmg } : {},
			...t.zx == null ? {} : { zx: t.zx }
		}
	}, "stop";
	if (e.seats[t.lord].alive && (my(e), t.dmg && e.queue.unshift(t.dmg), t.zx != null && t.zx > 0 && Iy(e, t.lord, t.zx), e.pending)) return "stop";
}
function Xy(e, t) {
	if (!e.seats[t.target].alive || t.idx >= t.slashes.length || t.idx >= e.players.length) {
		t.idx < t.slashes.length && (e.deck = Pv(e, [...e.deck, ...t.slashes.slice(t.idx)]), L(e, {
			kind: "fuzhu-end",
			seat: t.from
		}));
		return;
	}
	let n = t.slashes[t.idx];
	return U(e, [n]), e.queue.unshift({
		k: "fuzhu-step",
		from: t.from,
		target: t.target,
		slashes: t.slashes,
		idx: t.idx + 1
	}), e.queue.unshift({
		k: "slash-target",
		from: t.from,
		target: t.target,
		cardName: e.cards[n].name,
		suit: e.cards[n].suit,
		cardId: n
	}), "next";
}
function Zy(e, t) {
	let n = t.from;
	if (e.seats[n].alive && !((e.turn?.dmg[n] ?? 0) > t.dmg0) && (e.seats[n].flags.tx2 = !0, e.seats[t.target].alive && et(e, t.target, "dismantlement", !1).length > 0)) return e.pending = {
		kind: "pick-zone",
		seats: [n],
		ctx: {
			trick: "dismantlement",
			from: n,
			target: t.target,
			allowJudge: !1
		}
	}, "stop";
}
function Qy(e, t, n) {
	if ($e(e, t, n), e.pending || e.beatMs > 0) return "stop";
}
function $y(e, t) {
	e.seats[t.target].alive && !t.immune.includes(t.target) && Qe(e, t.from, "god_salvation", t.target, {
		k: "trick-effect",
		name: "god_salvation",
		from: t.from,
		target: t.target,
		cardId: null
	});
}
function eb(e, t) {
	if (e.seats[t.target].alive) {
		if (t.cardId != null) {
			let n = e.cards[t.cardId]?.suit;
			if ((n === "spade" || n === "club") && Y(e, t.target, "weimu")) return;
		}
		Qe(e, t.from, t.name, t.target, {
			k: "trick-effect",
			name: t.name,
			from: t.from,
			target: t.target,
			cardId: t.cardId
		});
	}
}
function tb(e, t, n) {
	if (t.pool == null) {
		let r = z(e).length, i = [];
		for (let t = 0; t < r; t++) {
			e.deck.length === 0 && e.discard.length > 0 && (e.deck = Pv(e, e.discard), e.discard = []);
			let t = e.deck.shift();
			if (t == null) break;
			i.push(t);
		}
		return e.queue.unshift({
			k: "amazing-step",
			from: t.from,
			pool: i,
			takers: t.takers,
			taken: t.taken,
			cardId: t.cardId
		}), e.beatMs = J.play, n.push({
			kind: "amazing",
			data: { revealed: i }
		}), L(e, {
			kind: "amazing",
			seat: t.from,
			cards: R(e, i)
		}), "stop";
	}
	let r = t.takers[0];
	if (r == null || !e.seats[r].alive) {
		let n = t.takers.slice(1);
		n.length > 0 ? e.queue.unshift({
			k: "amazing-step",
			from: t.from,
			pool: t.pool,
			takers: n,
			taken: t.taken,
			cardId: t.cardId
		}) : U(e, t.pool.filter((e) => t.taken[e] == null));
		return;
	}
	Qe(e, t.from, "amazing_grace", r, {
		k: "amazing-deal",
		from: t.from,
		pool: t.pool,
		takers: t.takers,
		taken: t.taken
	});
}
function nb(e, t) {
	let [n, ...r] = t.takers, i = t.pool.filter((e) => t.taken[e] == null);
	if (n == null || !e.seats[n].alive || i.length === 0) {
		if (n != null && e.seats[n].alive && r.length > 0) {
			e.queue.unshift({
				k: "amazing-step",
				from: t.from,
				pool: t.pool,
				takers: r,
				taken: t.taken,
				cardId: null
			});
			return;
		}
		U(e, i);
		return;
	}
	return e.queue.unshift({
		k: "amazing-step",
		from: t.from,
		pool: t.pool,
		takers: r,
		taken: t.taken,
		cardId: null
	}), e.pending = {
		kind: "amazing-pick",
		seats: [n],
		ctx: {
			revealed: t.pool,
			taken: t.taken
		}
	}, "stop";
}
function rb(e, t, n) {
	return Ny(e, t, n), e.beatMs = J.damage, "stop";
}
function ib(e, t, n) {
	if (Oy(e, t, n)) return "stop";
}
function ab(e, t, n) {
	let r = e.seats[t.seat];
	if (r.alive) {
		let i = r.maxHp - r.hp;
		if (i > 0) {
			let a = H(e, t.seat, i);
			return n.push({
				kind: "draw",
				rid: r.rid,
				data: {
					seat: t.seat,
					n: a.length
				},
				for: [r.rid],
				secret: { cards: a }
			}), L(e, {
				kind: "tianxiang-draw",
				seat: t.seat,
				n: a.length
			}), e.beatMs = J.draw, P(e, t.seat, a), "stop";
		}
	}
}
function ob(e, t) {
	if (e.seats[t.seat].alive && Y(e, t.seat, "longyin") && e.turn != null && e.turn.phase === "play" && e.seats[t.from].alive && (e.hands[t.seat].length !== 0 || K(e, t.seat).length !== 0)) return e.pending = {
		kind: "skill-ask",
		seats: [t.seat],
		ctx: {
			skill: "longyin",
			data: {
				from: t.from,
				red: t.red
			}
		}
	}, "stop";
}
function sb(e, t) {
	let n = t.from;
	if (!e.seats[n].alive || !Y(e, n, "xinzhongyong")) return;
	let r = [];
	t.cardId != null && e.discard.includes(t.cardId) && r.push(t.cardId), t.jinkId != null && t.jinkId !== t.cardId && e.discard.includes(t.jinkId) && r.push(t.jinkId);
	let i = z(e).filter((e) => e !== n && e !== t.target);
	if (r.length !== 0 && i.length !== 0) return e.pending = {
		kind: "skill-ask",
		seats: [n],
		ctx: {
			skill: "xinzhongyong",
			data: {
				pool: r,
				candidates: i
			}
		}
	}, "stop";
}
function cb(e, t) {
	let n = t.seats.filter((t) => e.seats[t].alive);
	if (n.length === 0 || !e.seats[t.from].alive) return;
	let r = n[0], i = t.prev + 1, a = e.hands[r].length + K(e, r).length >= i ? ["fc-discard", "fc-damage"] : ["fc-damage"];
	return e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "fencheng-step",
			options: a,
			noPass: !0,
			data: {
				rest: n.slice(1),
				need: i,
				x: i,
				from: t.from
			}
		}
	}, "stop";
}
function lb(e, t, n) {
	let r = t.seats.filter((t) => e.seats[t].alive);
	if (r.length === 0 || !e.seats[t.target].alive) return;
	let i = r[0], a = r.slice(1), o = [...e.hands[i].filter((t) => k(e.cards[t].name) === "weapon"), ...e.seats[i].equips.weapon == null ? [] : [e.seats[i].equips.weapon]];
	if (o.length === 0) {
		let r = H(e, t.target, 1);
		return n.push({
			kind: "draw",
			rid: e.seats[t.target].rid,
			data: {
				seat: t.target,
				n: r.length
			},
			for: [e.seats[t.target].rid],
			secret: { cards: r }
		}), L(e, {
			kind: "skill-draw",
			seat: t.target,
			card: "jiefan",
			n: r.length
		}), e.beatMs = J.draw, e.queue.unshift({
			k: "jiefan-step",
			seats: a,
			target: t.target,
			from: t.from
		}), "stop";
	}
	return e.pending = {
		kind: "skill-ask",
		seats: [i],
		ctx: {
			skill: "jiefan-step",
			options: ["jf-discard", "jf-draw"],
			data: {
				target: t.target,
				from: t.from,
				rest: a,
				weapons: o
			}
		}
	}, "stop";
}
function ub(e, t) {
	if (e.seats[t.from].alive && e.seats[t.target].alive && Y(e, t.from, "mengjin") && fx(e, t.target)) return e.pending = {
		kind: "skill-ask",
		seats: [t.from],
		ctx: {
			skill: "mengjin",
			data: { target: t.target }
		}
	}, "stop";
}
function db(e, t) {
	if (!e.seats[t.from].alive || !e.seats[t.target].alive) return;
	let n = e.seats[t.from].equips.weapon, r = n == null ? null : e.cards[n].name;
	if (r === "axe") return e.hands[t.from].length + K(e, t.from).length >= 2 ? (e.pending = {
		kind: "skill-ask",
		seats: [t.from],
		ctx: {
			skill: "axe",
			data: {
				target: t.target,
				cardName: t.cardName,
				ana: t.ana,
				cardId: t.cardId,
				plus: t.plus ?? 0
			}
		}
	}, "stop") : void 0;
	if (r === "blade" && Ev(e, t.from, t.target)) return "stop";
}
function fb(e, t) {
	if (e.seats[t.from].alive && Y(e, t.from, "re_luanwu") && !z(e).every((n) => n === t.from || N(e, n))) return e.pending = {
		kind: "skill-ask",
		seats: [t.from],
		ctx: {
			skill: "luanwu-jie",
			data: {}
		}
	}, "stop";
}
function pb(e, t) {
	if ($_(e, t.seat, "jieming", t.data)) return "stop";
}
//#endregion
//#region src/games/sanguosha/rules/advance/phase.ts
function mb(e, t, n) {
	e.revealAll = !1;
	for (let t of z(e)) H(e, t, 4);
	let r = e.seats.findIndex((e) => e.identity === "lord");
	e.turn = Rv(r), e.round = 1;
	for (let t of z(e)) {
		let n = e.seats[t];
		if (n.skills.includes("re_xueyi") && n.identity === "lord" && (n.marks.yi = 2 * z(e).filter((t) => $v(e, t) === "qun").length, L(e, {
			kind: "skill",
			seat: t,
			card: "re_xueyi",
			n: n.marks.yi
		})), n.skills.includes("re_qiaobian") && (n.marks.bian = 2), n.skills.includes("zongzuo")) {
			let r = ey(e);
			n.maxHp += r, n.hp += r, L(e, {
				kind: "skill",
				seat: t,
				card: "zongzuo",
				n: r
			});
		}
	}
	zv(e, r), n.push({
		kind: "deal",
		data: { n: 4 }
	}), L(e, {
		kind: "deal",
		n: 4
	});
}
function hb(e) {
	let t = e.turn.seat;
	if (e.turn.phase = "judge", e.seats[t].flags.skipJudgeOnce) return;
	let n = e.seats[t];
	if (n.judges.length > 0 && !N(e, t)) {
		for (let r of z(e)) if (r !== t && Y(e, r, "yonglve") && !((n.flags.ylDone ?? 0) & 1 << r) && !(V(e, r, t) > Bv(e, r))) return n.flags.ylDone = (n.flags.ylDone ?? 0) | 1 << r, e.queue.unshift({ k: "judge-scan" }), e.pending = {
			kind: "skill-ask",
			seats: [r],
			ctx: {
				skill: "yonglve",
				data: { target: t }
			}
		}, "stop";
	}
	let r = e.seats[t];
	if (!r.flags.qbJudge && cy(e, t, "qiaobian") && e.hands[t].length > 0 && r.judges.length > 0) return r.flags.qbJudge = !0, e.queue.unshift({ k: "judge-scan" }), e.pending = {
		kind: "skill-cards",
		seats: [t],
		ctx: {
			skill: "qiaobian-judge",
			min: 0,
			max: 1,
			data: {}
		}
	}, "stop";
	let i = [...e.seats[t].judges].reverse();
	for (let t of i) e.queue.unshift({
		k: "judge-one",
		cardId: t
	});
}
function gb(e, t) {
	let n = e.turn.seat, r = e.seats[n], i = r.judges.indexOf(t.cardId);
	if (i < 0) return;
	r.judges.splice(i, 1);
	let a = uy(e, t.cardId);
	if (delete e.judgeNames[t.cardId], e.judging = {
		seat: n,
		name: a,
		result: null
	}, L(e, {
		kind: "judge",
		seat: n,
		card: a
	}), Qe(e, n, a, n, {
		k: "judge-now",
		seat: n,
		cardId: t.cardId,
		trickName: a
	}), e.pending) return "stop";
}
function _b(e, t, n) {
	if (e.judging = {
		seat: t.seat,
		name: t.trickName,
		result: null
	}, nt(e, t.seat, t.trickName, { trickCard: t.cardId }, n)) return "stop";
}
function vb(e, t, n) {
	if (it(e, t, n) || (e.judging && (e.beatMs = J.judge), ov(e, t.seat, t.judgeCard))) return "stop";
}
function yb(e, t, n) {
	let r = e.turn.seat, i = e.seats[r];
	if (delete i.marks.luoyiJie, i.kb.length > 0) {
		let t = i.kb;
		e.hands[r].push(...t), L(e, {
			kind: "skill",
			seat: r,
			card: "kuangbi",
			n: t.length
		});
		let n = /* @__PURE__ */ new Map();
		for (let e of i.kbFrom) n.set(e, (n.get(e) ?? 0) + 1);
		for (let [t, r] of n) e.seats[t].alive && (H(e, t, r), L(e, {
			kind: "draw",
			seat: t,
			n: r
		}));
		i.kb = [], i.kbFrom = [];
	}
	if (i.skills.includes("qinxue") && !i.limitedUsed.includes("qinxue") && e.hands[r].length - i.hp >= (e.seats.length >= 7 ? 2 : 3)) return i.limitedUsed.push("qinxue"), --i.maxHp, i.hp = Math.min(i.hp, i.maxHp), i.skills.push("gongxin"), L(e, {
		kind: "awaken",
		seat: r,
		card: "qinxue"
	}), n.push({
		kind: "skill",
		rid: i.rid,
		data: {
			seat: r,
			skill: "qinxue"
		}
	}), e.beatMs = J.recover, "stop";
	if (i.skills.includes("re_qinxue") && !i.limitedUsed.includes("re_qinxue") && e.hands[r].length - i.hp >= 2) return i.limitedUsed.push("re_qinxue"), --i.maxHp, i.hp = Math.min(i.hp, i.maxHp), i.skills.push("gongxin"), L(e, {
		kind: "awaken",
		seat: r,
		card: "re_qinxue"
	}), n.push({
		kind: "skill",
		rid: i.rid,
		data: {
			seat: r,
			skill: "re_qinxue"
		}
	}), e.beatMs = J.recover, e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "qinxue-jie",
			options: ["recover", "draw2"],
			noPass: !0,
			data: {}
		}
	}, "stop";
	if ((i.skills.includes("zaoxian") || i.skills.includes("re_zaoxian")) && !i.limitedUsed.includes("zaoxian") && !i.limitedUsed.includes("re_zaoxian") && i.tian.length >= 3) {
		let t = i.skills.includes("re_zaoxian");
		return i.limitedUsed.push(t ? "re_zaoxian" : "zaoxian"), --i.maxHp, i.hp = Math.min(i.hp, i.maxHp), i.skills.push("jixi"), L(e, {
			kind: "awaken",
			seat: r,
			card: "zaoxian"
		}), n.push({
			kind: "skill",
			rid: i.rid,
			data: {
				seat: r,
				skill: "zaoxian"
			}
		}), t && (e.extraTurn = r), e.beatMs = J.recover, "stop";
	}
	if ((i.skills.includes("hunzi") || i.skills.includes("re_hunzi")) && !i.limitedUsed.includes("hunzi") && !i.limitedUsed.includes("re_hunzi") && i.hp === 1) {
		let t = i.skills.includes("re_hunzi");
		return i.limitedUsed.push(t ? "re_hunzi" : "hunzi"), --i.maxHp, i.hp = Math.min(i.hp, i.maxHp), i.skills.push("yingzi", "yinghun"), L(e, {
			kind: "awaken",
			seat: r,
			card: "hunzi"
		}), n.push({
			kind: "skill",
			rid: i.rid,
			data: {
				seat: r,
				skill: "hunzi"
			}
		}), t && (i.flags.hunziTurn = !0), e.beatMs = J.recover, "stop";
	}
	if ((i.skills.includes("ruoyu") || i.skills.includes("re_ruoyu")) && i.identity === "lord" && !i.limitedUsed.includes("ruoyu") && !i.limitedUsed.includes("re_ruoyu") && i.hp === Math.min(...z(e).map((t) => e.seats[t].hp))) {
		let t = i.skills.includes("re_ruoyu");
		return i.limitedUsed.push(t ? "re_ruoyu" : "ruoyu"), i.maxHp += 1, i.hp = t ? Math.max(i.hp, 3) : i.hp + 1, i.skills.push("jijiang"), t && i.skills.push("sishu"), L(e, {
			kind: "awaken",
			seat: r,
			card: "ruoyu"
		}), n.push({
			kind: "skill",
			rid: i.rid,
			data: {
				seat: r,
				skill: "ruoyu"
			}
		}), e.beatMs = J.recover, "stop";
	}
	if ((i.skills.includes("zhiji") || i.skills.includes("re_zhiji")) && !i.limitedUsed.includes("zhiji") && !i.limitedUsed.includes("re_zhiji") && e.hands[r].length === 0) {
		if (i.limitedUsed.push(i.skills.includes("re_zhiji") ? "re_zhiji" : "zhiji"), --i.maxHp, i.hp = Math.min(i.hp, i.maxHp), i.skills.push("guanxing"), L(e, {
			kind: "awaken",
			seat: r,
			card: "zhiji"
		}), n.push({
			kind: "skill",
			rid: i.rid,
			data: {
				seat: r,
				skill: "zhiji"
			}
		}), i.hp < i.maxHp) return e.pending = {
			kind: "skill-ask",
			seats: [r],
			ctx: {
				skill: "zhiji",
				options: ["recover", "draw2"],
				noPass: !0,
				data: {}
			}
		}, "stop";
		let t = H(e, r, 2);
		return n.push({
			kind: "draw",
			rid: i.rid,
			data: {
				seat: r,
				n: t.length
			},
			for: [i.rid],
			secret: { cards: t }
		}), L(e, {
			kind: "skill-draw",
			seat: r,
			card: "zhiji",
			n: t.length
		}), e.beatMs = J.recover, "stop";
	}
	if (i.skills.includes("tishen") && !i.limitedUsed.includes("tishen") && i.hp < i.lastEndHp) return e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "tishen",
			data: {}
		}
	}, "stop";
	if (i.skills.includes("re_tishen") && !i.limitedUsed.includes("re_tishen") && i.hp < i.maxHp) return e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "re_tishen",
			data: {}
		}
	}, "stop";
	if (i.skills.includes("zili") && !i.limitedUsed.includes("zili") && i.quan.length >= 3) return i.limitedUsed.push("zili"), --i.maxHp, i.hp = Math.min(i.hp, i.maxHp), i.skills.push("paiyi"), L(e, {
		kind: "awaken",
		seat: r,
		card: "zili"
	}), n.push({
		kind: "skill",
		rid: i.rid,
		data: {
			seat: r,
			skill: "zili"
		}
	}), e.beatMs = J.recover, e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "zili",
			options: i.hp < i.maxHp ? ["recover", "draw2"] : ["draw2"],
			noPass: !0,
			data: {}
		}
	}, "stop";
	let a = [];
	(Y(e, r, "shensu") || Y(e, r, "re_shensu")) && Dv(e, r).length > 0 && a.push({
		seat: r,
		skill: "shensu1",
		data: {}
	}), Y(e, r, "guanxing") && a.push({
		seat: r,
		skill: "guanxing",
		data: {}
	}), Y(e, r, "re_guanxing") && a.push({
		seat: r,
		skill: "re_guanxing",
		data: {}
	}), Y(e, r, "luoshen") && a.push({
		seat: r,
		skill: "luoshen",
		data: {}
	}), Y(e, r, "re_luoshen") && a.push({
		seat: r,
		skill: "re_luoshen",
		data: {}
	}), Y(e, r, "yinghun") && i.hp < i.maxHp && z(e).some((e) => e !== r) && a.push({
		seat: r,
		skill: "yinghun",
		data: {}
	}), Y(e, r, "rezhenjun") && z(e).some((t) => e.hands[t].length + K(e, t).length > 0) && a.push({
		seat: r,
		skill: "rezhenjun",
		data: {}
	}), Y(e, r, "qianxi") && z(e).some((t) => t !== r && V(e, r, t) <= 1) && a.push({
		seat: r,
		skill: "qianxi",
		data: {}
	}), Y(e, r, "xiansi") && z(e).some((t) => t !== r && e.hands[t].length + K(e, t).length > 0) && a.push({
		seat: r,
		skill: "xiansi",
		data: {}
	});
	for (let t of z(e)) t !== r && Y(e, t, "zhuikong") && e.seats[t].hp < e.seats[t].maxHp && e.hands[t].length > 0 && e.hands[r].length > 0 && a.push({
		seat: t,
		skill: "zhuikong",
		data: { target: r }
	});
	Y(e, r, "fumian") && a.push({
		seat: r,
		skill: "fumian",
		options: ["fm-draw", "fm-red"],
		data: {}
	}), a.length > 0 && e.queue.unshift({
		k: "trigger-queue",
		list: a
	});
}
function bb(e, t, n) {
	let [r, ...i] = t.list;
	if (r != null && e.seats[r.seat].alive) return i.length > 0 && e.queue.unshift({
		k: "trigger-queue",
		list: i
	}), Y_(e, r, n), "stop";
}
function xb(e, t, n) {
	e.turn.phase = "draw";
	let r = e.turn.seat;
	if (!e.seats[r].alive) return;
	if (!e.seats[r].flags.flDrawDone && !e.skipDraw && Y(e, r, "fenli") && z(e).every((t) => t === r || e.hands[r].length >= e.hands[t].length)) return e.seats[r].flags.flDrawDone = !0, e.queue.unshift({ k: "draw-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "fenli-draw",
			data: {}
		}
	}, "stop";
	if (!e.seats[r].flags.qbDraw && !e.skipDraw && cy(e, r, "qiaobian") && e.hands[r].length > 0 && z(e).some((t) => t !== r && e.hands[t].length > 0)) return e.seats[r].flags.qbDraw = !0, e.queue.unshift({ k: "draw-phase" }), e.pending = {
		kind: "skill-cards",
		seats: [r],
		ctx: {
			skill: "qiaobian-draw",
			min: 0,
			max: 1,
			data: {}
		}
	}, "stop";
	if (!e.seats[r].flags.xhDone && !e.skipDraw && Y(e, r, "xinxuanhuo") && z(e).some((e) => e !== r)) return e.seats[r].flags.xhDone = !0, e.queue.unshift({ k: "draw-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "xinxuanhuo",
			data: {}
		}
	}, "stop";
	if (e.seats[r].flags.xhSkip) {
		e.seats[r].flags.xhSkip = !1;
		return;
	}
	let i = e.skipDraw;
	if (e.skipDraw = !1, i) {
		if (e.seats[r].flags.flSkip = (e.seats[r].flags.flSkip ?? 0) | 1, e.seats[r].flags.qbDrawSkip) {
			e.seats[r].flags.qbDrawSkip = !1;
			let t = z(e).filter((t) => t !== r && e.hands[t].length > 0);
			return t.length > 0 ? (e.pending = {
				kind: "skill-seats",
				seats: [r],
				ctx: {
					skill: "qiaobian-draw",
					min: 0,
					max: 2,
					candidates: t,
					data: {}
				}
			}, "stop") : void 0;
		}
		let t = z(e).find((t) => Y(e, t, "jiezi"));
		return t == null ? void 0 : (e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "jiezi-mark",
				data: {}
			}
		}, "stop");
	}
	if (e.seats[r].flags.jieziExtra) {
		e.seats[r].flags.jieziExtra = !1;
		let t = H(e, r, 2 + +!!Y(e, r, "yingzi"));
		return e.beatMs = J.draw, n.push({
			kind: "draw",
			rid: e.seats[r].rid,
			data: {
				seat: r,
				n: t.length
			},
			for: [e.seats[r].rid],
			secret: { cards: t }
		}), L(e, {
			kind: "draw",
			seat: r,
			n: t.length
		}), "stop";
	}
	let a = [];
	if (Y(e, r, "luoyi") && a.push({
		seat: r,
		skill: "luoyi",
		data: {}
	}), Y(e, r, "re_luoyi") && a.push({
		seat: r,
		skill: "re_luoyi",
		data: {}
	}), Y(e, r, "tuxi") && a.push({
		seat: r,
		skill: "tuxi",
		data: {}
	}), Y(e, r, "re_tuxi") && a.push({
		seat: r,
		skill: "re_tuxi",
		data: {}
	}), Y(e, r, "shuangxiong") && a.push({
		seat: r,
		skill: "shuangxiong",
		data: {}
	}), Y(e, r, "zaiqi") && e.seats[r].hp < e.seats[r].maxHp && a.push({
		seat: r,
		skill: "zaiqi",
		data: {}
	}), Y(e, r, "haoshi") && a.push({
		seat: r,
		skill: "haoshi",
		data: {}
	}), a.length > 0) {
		e.queue.unshift({
			k: "trigger-queue",
			list: a
		});
		return;
	}
	if (!e.seats[r].flags.zsAsked && Y(e, r, "rezishou") && ey(e) > 0) return e.seats[r].flags.zsAsked = !0, e.queue.unshift({ k: "draw-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "rezishou",
			data: { n: ey(e) }
		}
	}, "stop";
	if (!e.seats[r].flags.jcAsked && Y(e, r, "new_jiangchi")) return e.seats[r].flags.jcAsked = !0, e.queue.unshift({ k: "draw-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "new_jiangchi",
			options: ["jc-more", "jc-less"],
			data: {}
		}
	}, "stop";
	if (!e.seats[r].flags.csAsked && Y(e, r, "caishi")) return e.seats[r].flags.csAsked = !0, e.queue.unshift({ k: "draw-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "caishi",
			options: [
				"cs-less",
				"cs-limit",
				"cs-more"
			],
			data: {}
		}
	}, "stop";
	let o = H(e, r, 2 + +!!Y(e, r, "yingzi") + (e.seats[r].flags.zishouN ?? 0) + +!!e.seats[r].flags.jcMore - +!!e.seats[r].flags.jcLess + (e.seats[r].marks.duliang ?? 0) - +!!e.seats[r].flags.csLess + (e.seats[r].flags.csMore ? 2 : 0) + (e.seats[r].flags.fmDrawN ?? 0));
	return delete e.seats[r].marks.duliang, e.beatMs = J.draw, n.push({
		kind: "draw",
		rid: e.seats[r].rid,
		data: {
			seat: r,
			n: o.length
		},
		for: [e.seats[r].rid],
		secret: { cards: o }
	}), L(e, {
		kind: "draw",
		seat: r,
		n: o.length
	}), (e.seats[r].marks.zi ?? 0) > 0 && z(e).some((t) => Y(e, t, "jiezi")) && e.queue.unshift({
		k: "jiezi-extra-draw",
		seat: r
	}), Y(e, r, "re_shuangxiong") && (e.hands[r].length > 0 || K(e, r).length > 0) ? (e.pending = {
		kind: "skill-cards",
		seats: [r],
		ctx: {
			skill: "shuangxiong-jie",
			min: 0,
			max: 1,
			data: { pool: [...e.hands[r], ...K(e, r)] }
		}
	}, "stop") : (Db(e, r) || Y(e, r, "tongbo") && e.seats[r].shu.length > 0 && e.hands[r].length > 0 && (e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "tongbo",
			data: {}
		}
	}), "stop");
}
function Sb(e) {
	let t = e.turn.seat;
	if (e.seats[t].alive) {
		if (e.seats[t].flags.flSkipPlay) {
			delete e.seats[t].flags.flSkipPlay, e.seats[t].flags.flSkip = (e.seats[t].flags.flSkip ?? 0) | 2;
			return;
		}
		if (e.skipPlay) {
			if (e.skipPlay = !1, e.seats[t].flags.flSkip = (e.seats[t].flags.flSkip ?? 0) | 2, e.seats[t].flags.qbPlaySkip) {
				e.seats[t].flags.qbPlaySkip = !1;
				let n = kv(e);
				if (n.length > 0) return e.pending = {
					kind: "skill-cards",
					seats: [t],
					ctx: {
						skill: "qiaobian-field",
						min: 0,
						max: 1,
						data: { pool: n }
					}
				}, "stop";
			}
			return;
		}
		if (!e.seats[t].flags.qbPlay && cy(e, t, "qiaobian") && e.hands[t].length > 0 && kv(e).length > 0) return e.seats[t].flags.qbPlay = !0, e.queue.unshift({ k: "play-phase" }), e.pending = {
			kind: "skill-cards",
			seats: [t],
			ctx: {
				skill: "qiaobian-play",
				min: 0,
				max: 1,
				data: {}
			}
		}, "stop";
		if (!e.seats[t].flags.fangquanDone && (Y(e, t, "fangquan") || Y(e, t, "re_fangquan")) && e.hands[t].length > 0 && z(e).some((e) => e !== t)) return e.seats[t].flags.fangquanDone = !0, e.queue.unshift({ k: "play-phase" }), e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "fangquan",
				data: {}
			}
		}, "stop";
		if (!e.seats[t].flags.shensu2Done && (Y(e, t, "shensu") || Y(e, t, "re_shensu")) && Ov(e, t).length > 0 && Dv(e, t).length > 0) return e.seats[t].flags.shensu2Done = !0, e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "shensu2",
				data: {}
			}
		}, "stop";
		if (!e.seats[t].flags.qsDone && Y(e, t, "qiaoshui") && e.hands[t].length > 0 && z(e).some((n) => n !== t && e.hands[n].length > 0)) return e.seats[t].flags.qsDone = !0, e.queue.unshift({ k: "play-phase" }), e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "qiaoshui",
				data: {}
			}
		}, "stop";
		if (e.seats[t].alive) for (let n of z(e)) {
			if (n === t || !Y(e, n, "xinsidi")) continue;
			let r = e.seats[t].flags;
			if ((r.sdDone ?? 0) & 1 << n) continue;
			let i = new Set(K(e, n).map((t) => G(e, t) ? "red" : "black"));
			if (i.size === 0) continue;
			let a = [...e.hands[n], ...K(e, n)].filter((t) => O(e.cards[t].name) !== "basic" && i.has(G(e, t) ? "red" : "black"));
			if (a.length !== 0) return r.sdDone = (r.sdDone ?? 0) | 1 << n, e.queue.unshift({ k: "play-phase" }), e.pending = {
				kind: "skill-ask",
				seats: [n],
				ctx: {
					skill: "xinsidi",
					data: {
						target: t,
						pool: a
					}
				}
			}, "stop";
		}
		if (e.seats[t].alive) for (let n of z(e)) {
			if (n === t || !Y(e, n, "xiantu")) continue;
			let r = e.seats[t].flags;
			if (!((r.xtDone ?? 0) & 1 << n)) return r.xtDone = (r.xtDone ?? 0) | 1 << n, e.queue.unshift({ k: "play-phase" }), e.pending = {
				kind: "skill-ask",
				seats: [n],
				ctx: {
					skill: "xiantu",
					data: { target: t }
				}
			}, "stop";
		}
		if (!e.seats[t].flags.qzDone && Y(e, t, "qiangzhi") && z(e).some((n) => n !== t && e.hands[n].length > 0)) return e.seats[t].flags.qzDone = !0, e.queue.unshift({ k: "play-phase" }), e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "qiangzhi",
				data: {}
			}
		}, "stop";
		if (!e.seats[t].flags.flPlayDone && Y(e, t, "fenli") && z(e).every((n) => n === t || e.seats[t].hp >= e.seats[n].hp)) return e.seats[t].flags.flPlayDone = !0, e.queue.unshift({ k: "play-phase" }), e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "fenli-play",
				data: {}
			}
		}, "stop";
		if (!e.seats[t].flags.jgAsked && Y(e, t, "jigong")) return e.seats[t].flags.jgAsked = !0, e.queue.unshift({ k: "play-phase" }), e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "jigong",
				data: {}
			}
		}, "stop";
		e.seats[t].flags.jgTypes = 0, e.seats[t].flags.jyLast = 0, delete e.seats[t].flags.jzCard, delete e.seats[t].flags.jzName;
		for (let t of e.seats) delete t.flags.wgDone;
		return e.turn.phase = "play", "stop";
	}
}
function Cb(e, t, n) {
	e.turn.phase = "discard";
	let r = e.turn.seat;
	if (!e.seats[r].alive) return;
	if (e.lastDiscard = null, !e.seats[r].flags.sidiDone2 && e.seats[r].flags.sidiBy != null && e.turn.slashUsed === 0) {
		e.seats[r].flags.sidiDone2 = !0;
		let t = e.seats[r].flags.sidiBy - 1;
		if (t >= 0 && e.seats[t].alive && !N(e, r)) return e.queue.unshift({ k: "discard-phase" }), e.queue.unshift({
			k: "slash-target",
			from: t,
			target: r,
			cardName: "slash",
			suit: null,
			cardId: null
		}), L(e, {
			kind: "sidi-slash",
			seat: t,
			target: r
		}), "next";
	}
	let i = e.seats[r].flags.xtBy;
	if (i != null) {
		delete e.seats[r].flags.xtBy;
		let t = i - 1;
		if (!e.seats[r].flags.xtKilled && e.seats[t].alive) return e.queue.unshift({ k: "discard-phase" }), L(e, {
			kind: "xiantu-hurt",
			seat: t
		}), Ly(e, t, 1, n), "next";
	}
	if (!e.seats[r].flags.flDiscardDone && Y(e, r, "fenli")) {
		let t = K(e, r).length;
		if (t > 0 && z(e).every((n) => n === r || K(e, n).length <= t)) return e.seats[r].flags.flDiscardDone = !0, e.queue.unshift({ k: "discard-phase" }), e.pending = {
			kind: "skill-ask",
			seats: [r],
			ctx: {
				skill: "fenli-discard",
				data: {}
			}
		}, "stop";
	}
	if (e.seats[r].flags.flSkipDiscard) {
		delete e.seats[r].flags.flSkipDiscard, e.seats[r].flags.flSkip = (e.seats[r].flags.flSkip ?? 0) | 4;
		return;
	}
	if (!e.seats[r].flags.qbDiscard && cy(e, r, "qiaobian") && e.hands[r].length > 0) return e.seats[r].flags.qbDiscard = !0, e.queue.unshift({ k: "discard-phase" }), e.pending = {
		kind: "skill-cards",
		seats: [r],
		ctx: {
			skill: "qiaobian-discard",
			min: 0,
			max: 1,
			data: {}
		}
	}, "stop";
	if (e.seats[r].flags.qbDiscardSkip) return;
	if (!e.seats[r].flags.shensu3Done && Y(e, r, "re_shensu") && Dv(e, r).length > 0) return e.seats[r].flags.shensu3Done = !0, e.queue.unshift({ k: "discard-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "shensu3",
			data: {}
		}
	}, "stop";
	if (e.seats[r].flags.skipDiscardOnce) return;
	if (Y(e, r, "re_fangquan") && e.seats[r].flags.fangquanSkip && !e.seats[r].flags.fangquanGiven && e.hands[r].length > 0 && z(e).some((e) => e !== r)) return e.seats[r].flags.fangquanGiven = !0, e.queue.unshift({ k: "discard-phase" }), e.pending = {
		kind: "skill-cards",
		seats: [r],
		ctx: {
			skill: "fangquan",
			min: 0,
			max: 1,
			data: { jie: !0 }
		}
	}, "stop";
	if (!e.seats[r].flags.jgDone && Y(e, r, "rejingce")) {
		e.seats[r].flags.jgDone = !0;
		let t = Wv(e.seats[r].flags.jgTypes ?? 0);
		if (t > 0) return e.queue.unshift({ k: "discard-phase" }), e.pending = {
			kind: "skill-ask",
			seats: [r],
			ctx: {
				skill: "rejingce",
				data: { x: t }
			}
		}, "stop";
	}
	if (!e.seats[r].flags.yyDone && Y(e, r, "yanyu") && (e.seats[r].flags.yyCount ?? 0) >= 2) {
		e.seats[r].flags.yyDone = !0;
		let t = z(e).filter((t) => !Xv(e, t));
		if (t.length > 0) return e.queue.unshift({ k: "discard-phase" }), e.pending = {
			kind: "skill-seats",
			seats: [r],
			ctx: {
				skill: "yanyu-target",
				min: 0,
				max: 1,
				data: { candidates: t }
			}
		}, "stop";
	}
	if (Y(e, r, "keji") && !e.seats[r].flags.slashInPlay) {
		L(e, {
			kind: "skill",
			seat: r,
			card: "keji"
		});
		return;
	}
	let a = Gv(e, r) - Uv(e, r);
	if (a > 0) return e.pending = {
		kind: "discard",
		seats: [r],
		ctx: { count: a }
	}, "stop";
}
function wb(e, t, n) {
	e.turn.phase = "end";
	let r = e.turn.seat, i = e.seats[r];
	if (!i.alive) return;
	for (let t of z(e)) t !== r && Y(e, t, "qiaoshi") && ((i.flags.qsAsked ?? 0) & 1 << t || e.hands[t].length === e.hands[r].length && (i.flags.qsAsked = (i.flags.qsAsked ?? 0) | 1 << t, e.queue.unshift({ k: "end-phase" }), e.queue.unshift({
		k: "qiaoshi-ask",
		seat: t,
		target: r
	})));
	if (!i.flags.mijiDone && Y(e, r, "miji") && i.hp < i.maxHp) {
		i.flags.mijiDone = !0;
		let t = i.maxHp - i.hp, a = H(e, r, t);
		return n.push({
			kind: "draw",
			rid: i.rid,
			data: {
				seat: r,
				n: a.length
			},
			for: [i.rid],
			secret: { cards: a }
		}), L(e, {
			kind: "skill-draw",
			seat: r,
			card: "miji",
			n: a.length
		}), e.beatMs = J.draw, e.queue.unshift({ k: "end-phase" }), a.length > 0 && e.hands[r].length > 0 && z(e).some((e) => e !== r) && (e.pending = {
			kind: "skill-cards",
			seats: [r],
			ctx: {
				skill: "miji-give",
				min: 0,
				max: Math.min(t, e.hands[r].length),
				data: {}
			}
		}), "stop";
	}
	if (!i.flags.zyDone && Y(e, r, "zhiyan")) return i.flags.zyDone = !0, e.queue.unshift({ k: "end-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "zhiyan",
			data: {}
		}
	}, "stop";
	if (!i.flags.dyDone && Y(e, r, "daiyan") && z(e).some((e) => e !== r) && e.deck.some((t) => e.cards[t].suit === "heart" && O(e.cards[t].name) === "basic")) return i.flags.dyDone = !0, e.queue.unshift({ k: "end-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "daiyan",
			data: {}
		}
	}, "stop";
	if (!i.flags.xjDone && Y(e, r, "xinjiexun") && z(e).some((e) => e !== r) && (z(e).reduce((t, n) => t + [...K(e, n), ...e.seats[n].judges].filter((t) => e.cards[t].suit === "diamond").length, 0) > 0 || (i.marks.xinjiexun ?? 0) > 0)) return i.flags.xjDone = !0, e.queue.unshift({ k: "end-phase" }), e.pending = {
		kind: "skill-seats",
		seats: [r],
		ctx: {
			skill: "xinjiexun",
			min: 1,
			max: 1,
			data: { candidates: z(e).filter((e) => e !== r) }
		}
	}, "stop";
	if (!i.flags.hmDone && Y(e, r, "huimin") && z(e).filter((t) => e.hands[t].length < e.seats[t].hp).length > 0) return i.flags.hmDone = !0, e.queue.unshift({ k: "end-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "huimin",
			data: {}
		}
	}, "stop";
	if (!i.flags.fzAsked && !Xv(e, r)) {
		let t = z(e).find((t) => t !== r && Y(e, t, "fuzhu") && e.deck.length <= e.seats[t].hp * 10 && e.deck.some((t) => A(e.cards[t].name)));
		if (t != null) return i.flags.fzAsked = !0, e.queue.unshift({ k: "end-phase" }), e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "fuzhu",
				data: { target: r }
			}
		}, "stop";
	}
	if (!i.flags.gzDone && Y(e, r, "guizao")) {
		i.flags.gzDone = !0;
		let t = i.flags.gzN ?? 0;
		if (t >= 2 && Wv(i.flags.gzSuits ?? 0) === t) {
			e.queue.unshift({ k: "end-phase" });
			let t = i.hp < i.maxHp ? ["gz-draw", "gz-recover"] : ["gz-draw"];
			return e.pending = {
				kind: "skill-ask",
				seats: [r],
				ctx: {
					skill: "guizao",
					options: t,
					data: {}
				}
			}, "stop";
		}
	}
	if (!i.flags.qqDone && Y(e, r, "qinqing")) {
		i.flags.qqDone = !0;
		let t = e.seats.findIndex((e) => e.identity === "lord"), n = z(e).filter((n) => n !== r && n !== t && V(e, n, t) <= Bv(e, n) && (e.hands[n].length > 0 || K(e, n).length > 0));
		if (n.length > 0) return e.queue.unshift({ k: "end-phase" }), e.pending = {
			kind: "skill-seats",
			seats: [r],
			ctx: {
				skill: "qinqing",
				min: 0,
				max: n.length,
				data: { candidates: n }
			}
		}, "stop";
	}
	if (!i.flags.jsDone && Y(e, r, "jishe") && e.hands[r].length === 0) {
		i.flags.jsDone = !0;
		let t = z(e).filter((t) => t !== r && !e.seats[t].chained);
		if (t.length > 0 && i.hp > 0) return e.queue.unshift({ k: "end-phase" }), e.pending = {
			kind: "skill-seats",
			seats: [r],
			ctx: {
				skill: "jishe-chain",
				min: 0,
				max: Math.min(i.hp, t.length),
				data: { candidates: t }
			}
		}, "stop";
	}
	if (!i.flags.xxDone && Y(e, r, "xingxue")) {
		i.flags.xxDone = !0;
		let t = i.skills.includes("yanzhu") ? i.hp : i.maxHp;
		if (t >= 1 && z(e).length > 0) return e.queue.unshift({ k: "end-phase" }), e.pending = {
			kind: "skill-seats",
			seats: [r],
			ctx: {
				skill: "xingxue-targets",
				min: 1,
				max: Math.min(t, z(e).length),
				data: { candidates: z(e) }
			}
		}, "stop";
	}
	if (!i.flags.jueceDone && Y(e, r, "xinjuece") && z(e).some((t) => t !== r && e.hands[t].length === 0)) return i.flags.jueceDone = !0, e.queue.unshift({ k: "end-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "xinjuece",
			data: {}
		}
	}, "stop";
	if (!i.flags.chunlaoAsked && Y(e, r, "chunlao") && i.chun.length === 0 && e.hands[r].some((t) => A(e.cards[t].name))) return i.flags.chunlaoAsked = !0, e.queue.unshift({ k: "end-phase" }), e.pending = {
		kind: "skill-cards",
		seats: [r],
		ctx: {
			skill: "chunlao-put",
			min: 0,
			max: e.hands[r].filter((t) => A(e.cards[t].name)).length,
			data: { pool: e.hands[r].filter((t) => A(e.cards[t].name)) }
		}
	}, "stop";
	if (i.skills.includes("re_zhiji") && !i.limitedUsed.includes("re_zhiji") && e.hands[r].length === 0) {
		if (i.limitedUsed.push("re_zhiji"), --i.maxHp, i.hp = Math.min(i.hp, i.maxHp), i.skills.push("guanxing"), L(e, {
			kind: "awaken",
			seat: r,
			card: "zhiji"
		}), n.push({
			kind: "skill",
			rid: i.rid,
			data: {
				seat: r,
				skill: "zhiji"
			}
		}), i.hp < i.maxHp) return e.queue.unshift({ k: "end-phase" }), e.pending = {
			kind: "skill-ask",
			seats: [r],
			ctx: {
				skill: "zhiji",
				options: ["recover", "draw2"],
				noPass: !0,
				data: {}
			}
		}, "stop";
		let t = H(e, r, 2);
		return n.push({
			kind: "draw",
			rid: i.rid,
			data: {
				seat: r,
				n: t.length
			},
			for: [i.rid],
			secret: { cards: t }
		}), L(e, {
			kind: "skill-draw",
			seat: r,
			card: "zhiji",
			n: t.length
		}), e.beatMs = J.recover, e.queue.unshift({ k: "end-phase" }), "stop";
	}
	if (i.skills.includes("re_qinxue") && !i.limitedUsed.includes("re_qinxue") && e.hands[r].length - i.hp >= 2) return i.limitedUsed.push("re_qinxue"), --i.maxHp, i.hp = Math.min(i.hp, i.maxHp), i.skills.push("gongxin"), L(e, {
		kind: "awaken",
		seat: r,
		card: "qinxue"
	}), n.push({
		kind: "skill",
		rid: i.rid,
		data: {
			seat: r,
			skill: "qinxue"
		}
	}), e.queue.unshift({ k: "end-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "qinxue-jie",
			options: ["recover", "draw2"],
			noPass: !0,
			data: {}
		}
	}, "stop";
	if (i.flags.hunziTurn) return i.flags.hunziTurn = !1, e.queue.unshift({ k: "end-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "hunzi-bonus",
			options: ["draw2", "recover"],
			noPass: !0,
			data: {}
		}
	}, "stop";
	if (Y(e, r, "fangquan") && i.flags.fangquanSkip && !i.flags.fangquanGiven && e.hands[r].length > 0 && z(e).some((e) => e !== r)) return i.flags.fangquanGiven = !0, e.queue.unshift({ k: "end-phase" }), e.pending = {
		kind: "skill-cards",
		seats: [r],
		ctx: {
			skill: "fangquan",
			min: 1,
			max: 1,
			data: {}
		}
	}, "stop";
	if (!i.flags.zaiqiDone && Y(e, r, "re_zaiqi") && (e.turn?.red ?? 0) > 0) {
		i.flags.zaiqiDone = !0;
		let t = Math.min(e.turn.red, z(e).length);
		return e.queue.unshift({ k: "end-phase" }), e.pending = {
			kind: "skill-seats",
			seats: [r],
			ctx: {
				skill: "zaiqi-jie",
				min: 0,
				max: t,
				data: { candidates: z(e) }
			}
		}, "stop";
	}
	if (!i.flags.wulieDone && Y(e, r, "wulie") && !i.limitedUsed.includes("wulie") && i.hp > 1 && z(e).some((e) => e !== r)) return i.flags.wulieDone = !0, e.queue.unshift({ k: "end-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "wulie-x",
			options: Array.from({ length: i.hp - 1 }, (e, t) => `${t + 1}`),
			data: {}
		}
	}, "stop";
	if (Y(e, r, "piaoling") && !i.flags.piaolingDone) return i.flags.piaolingDone = !0, e.queue.unshift({ k: "end-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "piaoling",
			data: {}
		}
	}, "stop";
	if (Y(e, r, "re_shuangxiong")) {
		let t = (e.turn?.dmgCards[r] ?? []).filter((t) => e.discard.includes(t));
		if (t.length > 0) return e.discard = e.discard.filter((e) => !t.includes(e)), e.hands[r].push(...t), n.push({
			kind: "take",
			rid: i.rid,
			data: {
				seat: r,
				n: t.length
			},
			for: [i.rid],
			secret: { cards: t }
		}), L(e, {
			kind: "skill",
			seat: r,
			card: "shuangxiong",
			n: t.length
		}), e.beatMs = J.draw, e.queue.unshift({ k: "end-phase" }), "stop";
	}
	if (i.flags.guanxingAgain) return i.flags.guanxingAgain = !1, e.queue.unshift({ k: "end-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "guanxing",
			data: {}
		}
	}, "stop";
	let a = e.lastDiscard;
	if (a != null) {
		e.lastDiscard = null;
		let t = z(e).find((t) => t !== a.seat && (Y(e, t, "guzheng") || Y(e, t, "re_guzheng")));
		if (t != null) {
			let n = a.cards.filter((t) => e.discard.includes(t));
			if (n.length >= (Y(e, t, "re_guzheng") ? 2 : 1)) return e.queue.unshift({ k: "end-phase" }), e.pending = {
				kind: "skill-cards",
				seats: [t],
				ctx: {
					skill: "guzheng",
					min: 0,
					max: 1,
					data: {
						pool: n,
						seat: a.seat
					}
				}
			}, "stop";
		}
	}
	if (!i.flags.benghuaiDone && Y(e, r, "benghuai") && !i.flags.benghuaiOff) {
		let t = Math.min(...z(e).map((t) => e.seats[t].hp));
		if (i.hp > t) return i.flags.benghuaiDone = !0, e.queue.unshift({ k: "end-phase" }), e.pending = {
			kind: "skill-ask",
			seats: [r],
			ctx: {
				skill: "benghuai",
				options: i.maxHp > 1 ? ["hp", "maxhp"] : ["hp"],
				noPass: !0,
				data: {}
			}
		}, "stop";
	}
	let o = !1;
	if (Y(e, r, "biyue") || Y(e, r, "re_biyue")) {
		let t = H(e, r, Y(e, r, "re_biyue") && e.hands[r].length === 0 ? 2 : 1);
		n.push({
			kind: "draw",
			rid: i.rid,
			data: {
				seat: r,
				n: t.length
			},
			for: [i.rid],
			secret: { cards: t }
		}), L(e, {
			kind: "skill-draw",
			seat: r,
			card: "biyue",
			n: t.length
		}), o = !0;
	}
	if (Y(e, r, "re_qiaobian") && !i.qbSeen.includes(e.hands[r].length) && (i.qbSeen.push(e.hands[r].length), i.marks.bian = (i.marks.bian ?? 0) + 1, L(e, {
		kind: "skill",
		seat: r,
		card: "qiaobian",
		n: i.marks.bian
	})), Y(e, r, "xinjujian") && !i.flags.jjDone && e.hands[r].some((t) => O(e.cards[t].name) !== "basic") && z(e).some((e) => e !== r)) return i.flags.jjDone = !0, e.queue.unshift({ k: "end-phase" }), e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: "xinjujian",
			data: {}
		}
	}, "stop";
	let s = ly(e, r, "jushou");
	if (s != null && !i.turnedOver) return e.pending = {
		kind: "skill-ask",
		seats: [r],
		ctx: {
			skill: s,
			data: {}
		}
	}, "stop";
	if (o) return e.beatMs = J.draw, "stop";
}
function Tb(e, t, n) {
	let r = e.turn.seat;
	{
		let t = e.seats[r], n = Wv(t.flags.flSkip ?? 0);
		if (t.alive && !t.flags.pkDone && Y(e, r, "pingkou") && n > 0 && z(e).some((e) => e !== r)) return t.flags.pkDone = !0, e.queue.unshift({ k: "turn-end" }), e.pending = {
			kind: "skill-ask",
			seats: [r],
			ctx: {
				skill: "pingkou",
				data: { x: n }
			}
		}, "stop";
	}
	{
		let t = e.seats[r];
		if (t.alive && !t.flags.qtAsked && (t.flags.qtAsked = !0, !t.flags.qtUsed)) {
			let t = z(e).filter((t) => t !== r && Y(e, t, "qieting"));
			if (t.length > 0) {
				e.queue.unshift({ k: "turn-end" });
				for (let n = t.length - 1; n >= 0; n--) e.queue.unshift({
					k: "qieting-ask",
					seat: t[n],
					target: r
				});
				return "next";
			}
		}
	}
	{
		let t = e.seats[r];
		if (t.alive && !t.flags.botuAsked && Y(e, r, "botu") && (e.turn?.suits.length ?? 0) >= 4 && (t.marks.botuR === e.round ? t.marks.botuN ?? 0 : 0) < Math.min(3, z(e).length)) return t.flags.botuAsked = !0, e.queue.unshift({ k: "turn-end" }), e.pending = {
			kind: "skill-ask",
			seats: [r],
			ctx: {
				skill: "botu",
				data: {}
			}
		}, "stop";
	}
	for (let t of e.seats) {
		if (t.qianxun.length > 0) {
			let n = e.seats.indexOf(t);
			e.hands[n].push(...t.qianxun), L(e, {
				kind: "qianxun-back",
				seat: n,
				n: t.qianxun.length
			}), t.qianxun = [];
		}
		if (t.pojun.length > 0) {
			let n = e.seats.indexOf(t);
			e.hands[n].push(...t.pojun), L(e, {
				kind: "pojun-back",
				seat: n,
				n: t.pojun.length
			}), t.pojun = [];
		}
	}
	let i = e.seats[r];
	i.lastEndHp = i.hp, i.flags = {}, i.luoshen = [];
	for (let t of e.seats) delete t.marks.pao;
	for (let t of e.seats) delete t.flags.sealed, delete t.flags.noHand, delete t.flags.zhichi, delete t.flags.qianxiRed, delete t.flags.sbHurt, delete t.flags.ymDone, delete t.flags.hmUsed, t.funanBan = [];
	let a = e.extraAnchor;
	e.extraAnchor = null;
	let o = e.extraTurn;
	if (e.extraTurn = null, o != null && e.seats[o].alive) {
		e.extraAnchor = a ?? r, o !== r && e.seats[o].turnedOver && Jv(e, o, n), e.turn = Rv(o), zv(e, o), L(e, {
			kind: "turn",
			seat: o
		});
		return;
	}
	let s = a ?? r, c = B(e, s), l = 0, u = c[1] ?? c[0], d = [];
	for (; e.seats[u].turnedOver && l < c.length;) e.seats[u].turnedOver = !1, L(e, {
		kind: "turn-back",
		seat: u
	}), n.push({
		kind: "turn-over",
		data: {
			seat: u,
			down: !1
		}
	}), Y(e, u, "shebian") && Yv(e).length > 0 && d.push({
		seat: u,
		skill: "shebian",
		data: {}
	}), Y(e, u, "jiewei") ? d.push({
		seat: u,
		skill: "jiewei",
		data: {}
	}) : Y(e, u, "re_jiewei") && (e.hands[u].length > 0 || K(e, u).length > 0) && kv(e).length > 0 && d.push({
		seat: u,
		skill: "jiewei-jie",
		data: {}
	}), l += 1, u = c[(1 + l) % c.length];
	u <= s && (e.round += 1), e.turn = Rv(u), zv(e, u), d.length > 0 && e.queue.unshift({
		k: "trigger-queue",
		list: d
	}), L(e, {
		kind: "turn",
		seat: u
	});
}
function Eb(e, t, n) {
	if (e.seats[t].flags.jieziExtra) {
		e.seats[t].flags.jieziExtra = !1;
		let r = H(e, t, 2 + +!!Y(e, t, "yingzi"));
		n.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: r.length
			},
			for: [e.seats[t].rid],
			secret: { cards: r }
		}), L(e, {
			kind: "draw",
			seat: t,
			n: r.length
		}), e.beatMs = J.draw;
		return;
	}
	let r = e.seats[t].flags.tuxiN ?? 0, i = 2 + +!!Y(e, t, "yingzi") - r;
	if (i > 0) {
		let r = H(e, t, i);
		n.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: r.length
			},
			for: [e.seats[t].rid],
			secret: { cards: r }
		}), L(e, {
			kind: "draw",
			seat: t,
			n: r.length
		}), e.beatMs = J.draw;
	}
	if ((e.seats[t].marks.zi ?? 0) > 0 && z(e).some((t) => Y(e, t, "jiezi")) && e.queue.unshift({
		k: "jiezi-extra-draw",
		seat: t
	}), Y(e, t, "re_shuangxiong") && (e.hands[t].length > 0 || K(e, t).length > 0)) {
		e.pending = {
			kind: "skill-cards",
			seats: [t],
			ctx: {
				skill: "shuangxiong-jie",
				min: 0,
				max: 1,
				data: { pool: [...e.hands[t], ...K(e, t)] }
			}
		};
		return;
	}
	Db(e, t);
}
function Db(e, t) {
	let n = !!e.seats[t].flags.haoshiDrawn;
	if (delete e.seats[t].flags.haoshiDrawn, !n || e.hands[t].length < 5) return !1;
	let r = z(e).filter((e) => e !== t);
	if (r.length === 0) return !1;
	let i = Math.min(...r.map((t) => e.hands[t].length)), a = r.filter((t) => e.hands[t].length === i);
	return e.pending = {
		kind: "skill-seats",
		seats: [t],
		ctx: {
			skill: "haoshi",
			min: 1,
			max: 1,
			data: { candidates: a }
		}
	}, !0;
}
//#endregion
//#region src/games/sanguosha/rules/advance/skill-beats.ts
function Ob(e, t) {
	if (e.seats[t.seat].alive && e.hands[t.seat].length === 0 && Y(e, t.seat, "lianying")) return e.pending = {
		kind: "skill-seats",
		seats: [t.seat],
		ctx: {
			skill: "lianying",
			min: 0,
			max: t.lost,
			data: { candidates: z(e) }
		}
	}, e.beatMs = J.respond, "stop";
}
function kb(e, t) {
	let n = e.seats[t.seat], r = n.maxHp - n.hp;
	if (n.alive && Y(e, t.seat, "shangshi") && r > 0 && e.hands[t.seat].length < r) return e.pending = {
		kind: "skill-ask",
		seats: [t.seat],
		ctx: {
			skill: "shangshi",
			data: {}
		}
	}, "stop";
}
function Ab(e, t) {
	let n = z(e).filter((n) => n !== t.seat && (e.hands[n].length > 0 || K(e, n).length > 0));
	if (e.seats[t.seat].alive && Y(e, t.seat, "xuanfeng") && n.length > 0) return e.pending = {
		kind: "skill-ask",
		seats: [t.seat],
		ctx: {
			skill: "xuanfeng",
			data: {}
		}
	}, "stop";
}
function jb(e, t) {
	let n = z(e).find((n) => n !== t.source && (Y(e, n, "baonue") || Y(e, n, "re_baonue")));
	if (e.seats[t.source].alive && $v(e, t.source) === "qun" && n != null) return e.pending = {
		kind: "skill-ask",
		seats: [Y(e, n, "re_baonue") ? n : t.source],
		ctx: {
			skill: "baonue",
			data: { lord: n }
		}
	}, "stop";
}
function Mb(e, t) {
	let n = t.slash ? e.turn != null && e.turn.seat === t.seat : e.turn == null || e.turn.seat !== t.seat;
	if (e.seats[t.seat].alive && n && cy(e, t.seat, "tuntian")) return e.pending = {
		kind: "skill-ask",
		seats: [t.seat],
		ctx: {
			skill: "tuntian",
			data: {}
		}
	}, "stop";
}
function Nb(e, t) {
	if (e.seats[t.seat].alive && e.seats[t.target].alive && e.hands[t.seat].length === e.hands[t.target].length) return e.pending = {
		kind: "skill-ask",
		seats: [t.seat],
		ctx: {
			skill: "qiaoshi",
			data: { target: t.target }
		}
	}, "stop";
}
function Pb(e, t) {
	if (e.turn != null && e.turn.seat === t.user && e.turn.phase === "play" && Object.keys(e.turn.dmg).length === 0) {
		let n = z(e).find((n) => n !== t.user && Y(e, n, "zuoding"));
		if (n != null && e.seats[t.target].alive) return e.pending = {
			kind: "skill-seats",
			seats: [n],
			ctx: {
				skill: "zuoding-target",
				min: 0,
				max: 1,
				data: { candidates: [t.target] }
			}
		}, "stop";
	}
}
function Fb(e, t) {
	if (e.seats[t.seat].alive && Y(e, t.seat, "bizhuan") && e.seats[t.seat].shu.length < 4) return e.pending = {
		kind: "skill-ask",
		seats: [t.seat],
		ctx: {
			skill: "bizhuan",
			data: {}
		}
	}, "stop";
}
function Ib(e, t) {
	if (e.seats[t.holder].alive && t.holder !== t.responder && e.seats[t.responder].alive && Y(e, t.holder, "funan") && e.discard.includes(t.myCard) && e.discard.includes(t.theirCard)) return e.pending = {
		kind: "skill-ask",
		seats: [t.holder],
		ctx: {
			skill: "funan",
			data: {
				responder: t.responder,
				myCard: t.myCard,
				theirCard: t.theirCard
			}
		}
	}, "stop";
}
function Lb(e, t) {
	let n = t.cards[t.idx];
	if (n == null || !e.seats[t.seat].alive) return;
	let r = z(e).filter((e) => e !== t.seat);
	return r.length === 0 || !e.seats[t.seat].shu.includes(n) ? (t.idx + 1 < t.cards.length && e.queue.unshift({
		k: "tongbo-step",
		seat: t.seat,
		cards: t.cards,
		idx: t.idx + 1
	}), "next") : (e.pending = {
		kind: "skill-seats",
		seats: [t.seat],
		ctx: {
			skill: "tongbo-give",
			min: 1,
			max: 1,
			data: {
				candidates: r,
				cardId: n,
				cards: t.cards,
				idx: t.idx
			}
		}
	}, "stop");
}
function Rb(e, t) {
	if (t.idx >= t.seats.length) {
		t.shown.length > 0 && U(e, t.shown);
		return;
	}
	let n = t.seats[t.idx];
	return !e.seats[n].alive || t.shown.length === 0 ? (e.queue.unshift({
		k: "huimin-pick",
		seats: t.seats,
		idx: t.idx + 1,
		shown: t.shown
	}), "next") : (e.pending = {
		kind: "skill-cards",
		seats: [n],
		ctx: {
			skill: "huimin-take",
			min: 1,
			max: 1,
			data: {
				pool: [...t.shown],
				seats: t.seats,
				idx: t.idx
			}
		}
	}, "stop");
}
function zb(e, t, n) {
	let r = z(e).find((t) => Y(e, t, "ninge"));
	if (r == null || !e.seats[t.victim].alive) return;
	let i = H(e, r, 1);
	n.push({
		kind: "draw",
		rid: e.seats[r].rid,
		data: {
			seat: r,
			n: i.length
		},
		for: [e.seats[r].rid],
		secret: { cards: i }
	}), L(e, {
		kind: "skill-draw",
		seat: r,
		card: "ninge",
		n: i.length
	}), e.beatMs = J.draw, P(e, r, i);
	let a = [...K(e, t.victim), ...e.seats[t.victim].judges];
	if (a.length > 0) return e.pending = {
		kind: "skill-cards",
		seats: [r],
		ctx: {
			skill: "ninge",
			min: 1,
			max: 1,
			data: {
				pool: a,
				target: t.victim
			}
		}
	}, "stop";
}
function Bb(e, t) {
	let n = e.seats[t.seat];
	if (!n.alive) {
		U(e, t.cards);
		return;
	}
	let r = [];
	if (t.cards.length > 0 && r.push("xs-obtain"), n.hp < n.maxHp && r.push("recover"), r.length === 0) {
		U(e, t.cards);
		return;
	}
	return e.pending = {
		kind: "skill-ask",
		seats: [t.seat],
		ctx: {
			skill: "xingshang-jie",
			options: r,
			data: {
				cards: t.cards,
				dead: t.dead
			}
		}
	}, "stop";
}
function Vb(e, t) {
	if (!e.seats[t.seat].alive) return;
	if (O(e.cards[t.lost].name) === O(e.cards[t.top].name)) return e.pending = {
		kind: "skill-seats",
		seats: [t.seat],
		ctx: {
			skill: "yajiao-give",
			min: 1,
			max: 1,
			data: {
				card: t.top,
				candidates: z(e)
			}
		}
	}, "stop";
	U(e, [t.top]), L(e, {
		kind: "yajiao-drop",
		seat: t.seat,
		cards: R(e, [t.top])
	});
	let n = z(e).filter((n) => n !== t.seat && V(e, n, t.seat) <= Bv(e, n) && et(e, n, "dismantlement", !0).length > 0);
	if (n.length > 0) return e.pending = {
		kind: "skill-seats",
		seats: [t.seat],
		ctx: {
			skill: "yajiao-drop",
			min: 0,
			max: 1,
			data: { candidates: n }
		}
	}, "stop";
}
function Hb(e, t) {
	let n = z(e).find((t) => Y(e, t, "re_jiang")), r = e.turn?.seat;
	if (n != null && r != null && !e.seats[r].flags.jiangGot && e.discard.includes(t.cardId)) return e.seats[r].flags.jiangGot = !0, e.pending = {
		kind: "skill-ask",
		seats: [n],
		ctx: {
			skill: "jiang-obtain",
			data: { card: t.cardId }
		}
	}, "stop";
}
function Ub(e, t, n) {
	let r = t.seat;
	if (e.seats[r].moshi.length === 0) return;
	let i = z(e).find((t) => t !== r && Y(e, t, "moshi"));
	if (i == null) return;
	let a = e.seats[r].moshi.splice(0);
	e.hands[i].push(...a), n.push({
		kind: "take",
		rid: e.seats[i].rid,
		data: {
			seat: i,
			n: a.length
		},
		for: [e.seats[i].rid],
		secret: { cards: a }
	}), L(e, {
		kind: "moshi",
		seat: i,
		target: r,
		n: a.length
	}), e.beatMs = J.draw;
}
function Wb(e, t) {
	let n = e.seats[t.seat];
	!n.alive || (n.marks.zi ?? 0) <= 0 || (n.marks.zi = 0, n.flags.jieziExtra = !0, L(e, {
		kind: "jiezi",
		seat: z(e).find((t) => Y(e, t, "jiezi")) ?? t.seat,
		target: t.seat
	}), e.queue.unshift({ k: "draw-phase" }));
}
function Gb(e, t) {
	let n = t.cards.filter((t) => e.discard.includes(t));
	if (e.seats[t.seat].alive && n.length !== 0) return e.pending = {
		kind: "skill-ask",
		seats: [t.seat],
		ctx: {
			skill: "zongxuan",
			data: { cards: n }
		}
	}, "stop";
}
function Kb(e, t) {
	let n = t.cards.filter((t) => e.discard.includes(t) && qv(e, t) && O(e.cards[t].name) === "basic"), r = z(e).filter((n) => n !== t.seat && !e.seats[n].judges.some((t) => uy(e, t) === "supply_shortage"));
	if (e.seats[t.seat].alive && n.length !== 0 && r.length !== 0) return e.pending = {
		kind: "skill-ask",
		seats: [t.seat],
		ctx: {
			skill: "shenduan",
			data: {
				cards: n,
				candidates: r
			}
		}
	}, "stop";
}
function qb(e, t) {
	let n = t.seat;
	if (!e.seats[n].alive || !Y(e, n, "olbingyi") || e.hands[n].length === 0 || e.turn == null) return;
	let r = {
		judge: 1,
		draw: 2,
		play: 4,
		discard: 8,
		end: 16
	}[e.turn.phase], i = e.seats[n].flags.byP ?? 0;
	if ((i & r) === 0) return e.seats[n].flags.byP = i | r, e.pending = {
		kind: "skill-ask",
		seats: [n],
		ctx: {
			skill: "olbingyi",
			data: {}
		}
	}, "stop";
}
function Jb(e, t) {
	if (e.seats[t.seat].alive && e.seats[t.target].alive) return e.pending = {
		kind: "skill-ask",
		seats: [t.seat],
		ctx: {
			skill: "faen",
			data: { target: t.target }
		}
	}, "stop";
}
function Yb(e, t) {
	if (!e.seats[t.seat].alive || !e.seats[t.target].alive) return;
	let n = K(e, t.target).filter((n) => {
		let r = k(e.cards[n].name);
		return r != null && e.seats[t.seat].equips[r] == null;
	}), r = n.length > 0 ? ["qt-move", "qt-draw"] : ["qt-draw"];
	return e.pending = {
		kind: "skill-ask",
		seats: [t.seat],
		ctx: {
			skill: "qieting",
			options: r,
			data: {
				target: t.target,
				movable: n
			}
		}
	}, "stop";
}
function Xb(e, t) {
	let n = z(e).find((t) => Y(e, t, "fenji") && e.seats[t].hp > 0);
	if (n != null && e.seats[t.victim].alive) return e.pending = {
		kind: "skill-ask",
		seats: [n],
		ctx: {
			skill: "fenji",
			data: { victim: t.victim }
		}
	}, "stop";
}
function Zb(e, t, n) {
	if (e.seats[t.seat].alive) {
		let r = H(e, t.seat, 2);
		return n.push({
			kind: "draw",
			rid: e.seats[t.seat].rid,
			data: {
				seat: t.seat,
				n: r.length
			},
			for: [e.seats[t.seat].rid],
			secret: { cards: r }
		}), L(e, {
			kind: "skill-draw",
			seat: t.seat,
			card: "fenji",
			n: r.length
		}), e.beatMs = J.draw, P(e, t.seat, r), "stop";
	}
}
function Qb(e, t, n) {
	if (e.seats[t.seat].alive) {
		let r = H(e, t.seat, t.n);
		n.push({
			kind: "draw",
			rid: e.seats[t.seat].rid,
			data: {
				seat: t.seat,
				n: r.length
			},
			for: [e.seats[t.seat].rid],
			secret: { cards: r }
		}), L(e, {
			kind: "skill-draw",
			seat: t.seat,
			card: "qimou",
			n: r.length
		}), e.beatMs = J.draw, P(e, t.seat, r);
	}
}
function $b(e, t) {
	let n = [];
	for (let r = 0; r < e.seats.length; r++) if (e.seats[r].alive) {
		if (t.cls === "trick") n.push(...e.seats[r].judges);
		else {
			let i = r !== t.seat && (Y(e, r, "qicai") || Y(e, r, "re_qicai"));
			for (let t of [
				"weapon",
				"armor",
				"off_horse",
				"def_horse"
			]) {
				let a = e.seats[r].equips[t], o = i && (Y(e, r, "re_qicai") ? t === "armor" : t === "weapon" || t === "armor");
				a != null && !o && n.push(a);
			}
		}
	}
	if (n.length !== 0 && e.seats[t.seat].alive) return e.pending = {
		kind: "skill-cards",
		seats: [t.seat],
		ctx: {
			skill: "jiewei-discard",
			min: 0,
			max: 1,
			data: { pool: n }
		}
	}, "stop";
}
function ex(e, t) {
	if (e.seats[t.seat].alive && z(e).some((e) => e !== t.seat)) return e.pending = {
		kind: "skill-seats",
		seats: [t.seat],
		ctx: {
			skill: "taoluan-target",
			min: 1,
			max: 1,
			data: {
				candidates: z(e).filter((e) => e !== t.seat),
				name: t.name
			}
		}
	}, "stop";
}
function tx(e, t, n) {
	let r = t.targets[t.idx], i = () => {
		t.idx + 1 < t.targets.length && e.queue.unshift({
			k: "xx-step",
			targets: t.targets,
			idx: t.idx + 1
		});
	};
	if (r == null || !e.seats[r].alive) return i(), "next";
	let a = H(e, r, 1);
	return n.push({
		kind: "draw",
		rid: e.seats[r].rid,
		data: {
			seat: r,
			n: a.length
		},
		for: [e.seats[r].rid],
		secret: { cards: a }
	}), L(e, {
		kind: "skill-draw",
		seat: r,
		card: "xingxue",
		n: a.length
	}), e.beatMs = J.draw, e.hands[r].length + K(e, r).length > 0 ? (e.pending = {
		kind: "skill-cards",
		seats: [r],
		ctx: {
			skill: "xx-put",
			min: 1,
			max: 1,
			data: {
				pool: [...e.hands[r], ...K(e, r)],
				targets: t.targets,
				idx: t.idx
			}
		}
	}, "stop") : (i(), "next");
}
//#endregion
//#region src/games/sanguosha/rules/advance/index.ts
function nx(e, t) {
	if (!e.turn || e.turn.phase !== "play" || e.turn.seat !== t || e.pending) return !1;
	let n = e.queue[0];
	return n != null && (n.k === "discard-phase" || n.k === "end-phase" || n.k === "turn-end" || n.k === "phase-start");
}
var rx = {
	"clear-table": (e) => {
		e.tableCard = null, e.targeting = null;
	},
	"game-start": mb,
	"judge-scan": hb,
	"judge-one": gb,
	"judge-now": _b,
	"judge-effect": vb,
	"phase-start": yb,
	"trigger-queue": bb,
	"draw-phase": xb,
	"play-phase": Sb,
	"discard-phase": Cb,
	"end-phase": wb,
	"turn-end": Tb,
	"slash-target": Ry,
	"aoe-nullify": zy,
	"aoe-target": By,
	"savage-end": Vy,
	"trick-effect": Qy,
	"trick-nullify": eb,
	"god-salvation-one": $y,
	"amazing-step": tb,
	"amazing-deal": nb,
	damage: rb,
	"after-damage": ib,
	"tianxiang-draw": ab,
	"mengjin-check": ub,
	"axe-check": db,
	"lieren-check": Hy,
	"kylin-check": Uy,
	"fangzhu-next": Wy,
	"jieming-next": pb,
	"luanwu-step": Gy,
	"luanwu-end": fb,
	"fencheng-step": cb,
	"jiefan-step": lb,
	"fuzhu-step": Xy,
	"xs-done": Yy,
	"beige-next": Ky,
	"yaoming-next": qy,
	"longyin-ask": ob,
	"zy-check": sb,
	"tiaoxin-check": Zy,
	"zj-draw": Jy,
	lianying: Ob,
	"shangshi-check": kb,
	"xuanfeng-ask": Ab,
	"baonue-check": jb,
	"tuntian-check": Mb,
	"qiaoshi-ask": Nb,
	"zuoding-check": Pb,
	"bizhuan-ask": Fb,
	"funan-check": Ib,
	"tongbo-step": Lb,
	"huimin-pick": Rb,
	"ninge-check": zb,
	"xingshang-jie": Bb,
	"yajiao-jie": Vb,
	"jiang-check": Hb,
	"moshi-check": Ub,
	"jiezi-extra-draw": Wb,
	"zongxuan-ask": Gb,
	"shenduan-ask": Kb,
	"bingyi-ask": qb,
	"faen-ask": Jb,
	"qieting-ask": Yb,
	"fenji-ask": Xb,
	"fenji-draw": Zb,
	"qimou-draw": Qb,
	"jiewei-follow": $b,
	"taoluan-after": ex,
	"xx-step": tx
};
function Z(e, t) {
	let n = 0, r = e.beatMs;
	for (; !e.pending && !e.over && n++ < 500;) {
		let n = e.queue[0];
		if (!n) {
			e.tableCard = null, e.targeting = null;
			return;
		}
		if (n.k === "clear-table" && (e.beatMs > 0 || r > 0)) {
			e.beatMs === 0 && (e.beatMs = r);
			return;
		}
		if (e.turn?.phase === "play" && e.seats[e.turn.seat].alive && (n.k === "discard-phase" || n.k === "end-phase" || n.k === "turn-end")) {
			e.beatMs = 0, e.tableCard = null, e.targeting = null;
			return;
		}
		e.queue.shift(), e.beatMs = 0, n.k !== "judge-effect" && (e.judging = null);
		let i = rx[n.k](e, n, t);
		if (i === "stop" || i !== "next" && e.beatMs > 0) return;
	}
}
//#endregion
//#region src/games/sanguosha/rules/phase-skills.ts
var ix = /* @__PURE__ */ "rende.zhiheng.kurou.chuli.qingnang.fanjian.jieyin.lijian.yijue.guose.gongxin.huangtian.qiangxi.quhu.tianyi.luanji.dimeng.luanwu.tiaoxin.zhijian.zhiba.jixi.qimou.changbiao.sishu.xueyi.jiushi.olsanyao.mingce.ganlu.xinxianzhen.qice.paiyi.old_anxu.gongji.jiefan.danshou.junxing.xinmieji.xinfencheng.xiansi2.pindi.shenxing.xianzhou.mingjian.zhanjue.wurong.xinanguo.yanzhu.xinzhaofu.huaiyi.jiaozhao.jiyu.dcduliang.kuangbi.jishe.zhige.zhongjian.qingxian.canyun.wengua.re_rende.re_zhiheng.re_jieyin.re_lijian.re_yijue.re_qiangxi.re_luanji.re_luanwu.re_tiaoxin.re_zhijian.re_xueyi".split("."), ax = /* @__PURE__ */ new Set([
	"rende",
	"re_rende",
	"luanji",
	"re_luanji",
	"zhijian",
	"re_zhijian",
	"jixi",
	"qingnang",
	"danshou",
	"pindi",
	"shenxing",
	"zhanjue",
	"jiyu",
	"jishe"
]), ox = /* @__PURE__ */ new Set([
	"quhu",
	"tianyi",
	"yijue",
	"xinxianzhen",
	"zhiba"
]);
function sx(e, t, n) {
	return !!e.seats[t].flags[`sk:${n}`];
}
function cx(e, t, n) {
	let r = e.seats[t];
	if (n === "huangtian") {
		if (!r.alive || r.flags.noHand || sx(e, t, n)) return null;
		let i = e.seats.findIndex((e) => e.identity === "lord");
		return i < 0 || i === t || !e.seats[i].alive || Fe.get(r.generalId ?? "")?.faction !== "qun" || !Y(e, i, "huangtian") && !Y(e, i, "re_huangtian") ? null : Y(e, i, "re_huangtian") ? e.hands[t].some((t) => e.cards[t].name === "jink" || e.cards[t].suit === "spade") ? {
			minCards: 1,
			maxCards: 1,
			minTargets: 1,
			maxTargets: 1,
			targets: [i],
			names: ["jink"],
			suits: ["spade"],
			orSuits: !0
		} : null : e.hands[t].some((t) => e.cards[t].name === "jink" || e.cards[t].name === "lightning") ? {
			minCards: 1,
			maxCards: 1,
			minTargets: 1,
			maxTargets: 1,
			targets: [i],
			names: ["jink", "lightning"]
		} : null;
	}
	if (n === "zhiba") {
		if (!r.alive || r.flags.noHand || sx(e, t, n)) return null;
		let i = e.seats.findIndex((e) => e.identity === "lord");
		if (i < 0 || !e.seats[i].alive || !Y(e, i, "zhiba") && !Y(e, i, "re_zhiba")) return null;
		let a = Y(e, i, "re_zhiba");
		if (t === i) {
			if (!a || e.hands[t].length === 0) return null;
			let n = z(e).filter((n) => n !== t && Fe.get(e.seats[n].generalId ?? "")?.faction === "wu" && e.hands[n].length > 0);
			return n.length > 0 ? {
				minCards: 1,
				maxCards: 1,
				minTargets: 1,
				maxTargets: 1,
				targets: n
			} : null;
		}
		return Fe.get(r.generalId ?? "")?.faction !== "wu" || e.hands[t].length === 0 || e.hands[i].length === 0 ? null : {
			minCards: 1,
			maxCards: 1,
			minTargets: 1,
			maxTargets: 1,
			targets: [i]
		};
	}
	if (n === "xiansi2") {
		if (!r.alive || r.flags.noHand || r.flags.tianyiLose || r.flags.xianzhenLose || r.flags.jcNoSlash || e.turn == null || e.turn.seat !== t || e.turn.slashUsed >= Hv(e, t)) return null;
		let n = Bv(e, t), i = z(e).filter((r) => r !== t && Y(e, r, "xiansi") && e.seats[r].ni.length >= 2 && V(e, t, r) <= n && !N(e, r));
		return i.length > 0 ? {
			minCards: 0,
			maxCards: 0,
			minTargets: 1,
			maxTargets: 1,
			targets: i
		} : null;
	}
	if (n === "wengua") {
		if (!r.alive || r.flags.noHand || e.hands[t].length === 0) return null;
		let n = e.seats.findIndex((n, r) => r !== t && n.alive && Y(e, r, "wengua") && !n.flags.wgDone);
		return n < 0 ? null : {
			minCards: 1,
			maxCards: 1,
			minTargets: 1,
			maxTargets: 1,
			targets: [n]
		};
	}
	if (!r.alive || r.flags.noHand || !Y(e, t, n) || !ax.has(n) && sx(e, t, n) && !((n === "re_tiaoxin" ? r.flags.tx2 && !r.flags.txU : n === "re_qiangxi" && Number(r.flags.qxN ?? 0) < 2) || n === "olsanyao" && !(r.flags["sy:hp"] && r.flags["sy:hand"]))) return null;
	let i = e.hands[t].length, a = z(e).filter((e) => e !== t), o = (t) => {
		let n = e.seats[t].generalId;
		return n != null && !Fe.get(n)?.female;
	}, s = W_[n];
	return s ? s(e, t, r, i, a, o) : null;
}
function lx(e, t, n, r) {
	let i = n.skill, a = i === "re_huangtian" ? "huangtian" : i === "re_zhiba" ? "zhiba" : i;
	if (!ix.includes(a) || a !== "huangtian" && a !== "zhiba" && a !== "xiansi2" && a !== "wengua" && !Y(e, t, a)) return q("games.sanguosha.error.badSkill");
	let o = cx(e, t, a);
	if (!o) return q("games.sanguosha.error.badSkill");
	let s = n.cardIds ?? [], c = n.targets ?? [];
	if (s.length < o.minCards || s.length > o.maxCards || c.length < o.minTargets || c.length > o.maxTargets) return q("games.sanguosha.error.badSkill");
	if (!s.every((n) => e.hands[t].includes(n) || o.allowEquip === !0 && K(e, t).includes(n) || o.allowTian === !0 && e.seats[t].tian.includes(n))) return q("games.sanguosha.error.noCard");
	if (o.suits && !o.orSuits && !s.every((t) => o.suits.includes(e.cards[t].suit)) || o.names && !o.orSuits && !s.every((t) => o.names.includes(e.cards[t].name)) || o.orSuits && !s.every((t) => o.names.includes(e.cards[t].name) || o.suits.includes(e.cards[t].suit)) || o.sameSuit && s.length === 2 && e.cards[s[0]].suit !== e.cards[s[1]].suit || o.classes && !s.every((t) => o.classes.includes(O(e.cards[t].name)))) return q("games.sanguosha.error.badSkill");
	if (!c.every((e) => o.targets.includes(e))) return q("games.sanguosha.error.badTarget");
	if (a === "dimeng" && s.length !== Math.abs(e.hands[c[0]].length - e.hands[c[1]].length)) return q("games.sanguosha.error.badSkill");
	if (a === "zhijian" || a === "re_zhijian") {
		let n = k(e.cards[s[0]].name);
		if (n == null || !e.hands[t].includes(s[0]) || a !== "re_zhijian" && e.seats[c[0]].equips[n] != null) return q("games.sanguosha.error.badSkill");
	}
	if (a === "xinmieji" && O(e.cards[s[0]].name) !== "trick" || a === "mingce" && !(A(e.cards[s[0]].name) || k(e.cards[s[0]].name) != null) || a === "ganlu" && Math.abs(K(e, c[0]).length - K(e, c[1]).length) > e.seats[t].maxHp - e.seats[t].hp) return q("games.sanguosha.error.badSkill");
	ax.has(a) || (e.seats[t].flags[`sk:${a}`] = !0), L(e, {
		kind: "skill",
		seat: t,
		card: a,
		...s.length > 0 && !ox.has(a) ? { cards: R(e, s) } : {}
	});
	let l = a === "luanwu" || a === "re_luanwu" ? z(e).filter((e) => e !== t) : c;
	l.length > 0 && a !== "jixi" && (e.targeting = {
		from: t,
		targets: l
	}, e.queue.unshift({ k: "clear-table" }), e.beatMs = J.play);
	let u = G_[a];
	return u ? u(e, t, a, s, c, o, r) : q("games.sanguosha.error.badSkill");
}
//#endregion
//#region src/games/sanguosha/rules/play.ts
function ux(e, t, n, r) {
	if (hy(e, t, n).includes(r)) return !0;
	if (r === "fire_slash" && e.cards[n].name === "slash") {
		let n = e.seats[t].equips.weapon;
		if (n != null && e.cards[n].name === "fan" || Y(e, t, "lihuo")) return !0;
	}
	return !!(e.seats[t].flags.jzCard === n && Sy(e, t) === r || Y(e, t, "taoluan") && !e.seats[t].flags.tlOff && e.hands[t].includes(n) && wy(e, t).includes(r));
}
function dx(e, t, n, r) {
	let i = e.cards[n], a = e.seats[t];
	if (!a.alive || a.flags.noHand) return null;
	let o = a.flags.qianxiRed;
	if (o != null && e.hands[t].includes(n) && o === G(e, n) || ze(e, t, n) || a.funanBan.includes(n)) return null;
	let s = a.flags.jySuits;
	if (s && e.hands[t].includes(n) && (s & {
		spade: 1,
		heart: 2,
		diamond: 4,
		club: 8
	}[i.suit]) !== 0) return null;
	let c = r === "recast" ? "iron_chain" : r ?? i.name;
	if (r != null && r !== "recast" && !ux(e, t, n, c)) return null;
	let l = r != null && a.flags.jzCard === n && Sy(e, t) === c, u = r != null && Y(e, t, "taoluan") && !a.flags.tlOff && e.hands[t].includes(n) && wy(e, t).includes(c), d = i.suit === "club" && (e.hands[t].includes(n) && Y(e, t, "lianhuan") || Y(e, t, "re_lianhuan"));
	if (r === "recast" && i.name !== "iron_chain" && !d && !(Y(e, t, "yanyu") && A(i.name))) return null;
	let f = O(c);
	if (a.flags.zkSelf && r !== "recast" && (A(c) || f === "trick" && c !== "ex_nihilo" && c !== "lightning") || a.flags.qsNoTrick && f === "trick") return null;
	if (f === "equip" && r == null) return [];
	if (c === "peach") return a.hp < a.maxHp ? [] : null;
	if (c === "jink" || c === "nullification") return null;
	if (A(c)) {
		if (a.flags.tianyiLose || a.flags.xianzhenLose || a.flags.jcNoSlash) return null;
		if (e.turn.slashUsed >= Hv(e, t)) {
			let t = a.flags.xianzhen;
			return t == null || !e.seats[t].alive || N(e, t) ? null : [t];
		}
		let r = Y(e, t, "zhaxiang") && !!a.flags.zhaxiangRed && G(e, n), o = Y(e, t, "re_wusheng") && i.suit === "diamond", s = r || o || !!a.flags.tianyiWin || !!a.flags.jcBuff, c = Bv(e, t), l = Y(e, t, "re_liegong") ? i.point : 0, u = z(e).filter((n) => n !== t && (s || av(e, t, n) || V(e, t, n) <= c || l > 0 && V(e, t, n) <= l) && !N(e, n));
		return u.length > 0 ? u : null;
	}
	let p = z(e).filter((e) => e !== t), m = Y(e, t, "qicai") || Y(e, t, "re_qicai"), h = (t) => t.filter((t) => !Xe(e, t, n)), g = (e) => e.length > 0 ? e : null;
	switch (c) {
		case "analeptic": return Y(e, t, "jinjiu") || a.flags.analepticUsed && !Y(e, t, "re_jiuchi") ? null : [];
		case "iron_chain": return [];
		case "fire_attack": return g(h(p.filter((t) => e.hands[t].length > 0)));
		case "supply_shortage": {
			let n = Y(e, t, "duanliang") || Y(e, t, "re_duanliang") ? 2 : 1;
			return g(h(p.filter((r) => (m || V(e, t, r) <= n) && !e.seats[r].judges.some((t) => uy(e, t) === "supply_shortage"))));
		}
		case "ex_nihilo":
		case "savage_assault":
		case "archery_attack":
		case "god_salvation":
		case "amazing_grace": return r == null || l || u ? [] : null;
		case "duel": return g(h(p.filter((t) => !N(e, t))));
		case "snatch": return r == null || l || u ? g(h(p.filter((n) => (m || V(e, t, n) <= 1) && et(e, n, "snatch").length > 0))) : null;
		case "dismantlement": return g(h(p.filter((t) => et(e, t, "dismantlement").length > 0)));
		case "collateral": return r == null || l || u ? g(h(p.filter((t) => e.seats[t].equips.weapon != null && px(e, t).length > 0))) : null;
		case "indulgence": return r == null ? g(h(p.filter((t) => !e.seats[t].judges.some((t) => uy(e, t) === "indulgence")))) : null;
		case "lightning": return r == null ? e.seats[t].judges.some((t) => uy(e, t) === "lightning") ? null : [] : null;
		default: return null;
	}
}
function fx(e, t) {
	let n = e.seats[t];
	return e.hands[t].length > 0 || n.judges.length > 0 || Object.values(n.equips).some((e) => e != null);
}
function px(e, t, n = !0) {
	let r = Bv(e, t);
	return z(e).filter((i) => i !== t && V(e, t, i) <= r && (!n || !N(e, i)));
}
function mx(e, t) {
	let n = [
		"ex_nihilo",
		"savage_assault",
		"archery_attack",
		"god_salvation",
		"amazing_grace"
	], r = z(e).filter((e) => e !== t), i = Y(e, t, "qicai");
	return r.some((t) => et(e, t, "dismantlement").length > 0) && n.push("dismantlement"), r.some((n) => (i || V(e, t, n) <= 1) && et(e, n, "snatch").length > 0) && n.push("snatch"), r.some((t) => !N(e, t)) && n.push("duel"), r.some((t) => e.hands[t].length > 0) && n.push("fire_attack"), r.some((t) => e.seats[t].equips.weapon != null && px(e, t).length > 0) && n.push("collateral"), n;
}
function hx(e, t, n) {
	let r = structuredClone(e), i = [];
	if (t.type === "tick") return r.over || r.pending ? { state: r } : (r.beatMs = 0, Z(r, i), {
		state: r,
		fx: i
	});
	let a = ry(r, n.by);
	if (a < 0) return q("common.error.notPlaying");
	if (r.over) return q("common.error.gameOver");
	if (r.pending?.kind === "general-select") return t.type === "pick-general" ? gx(r, a, t.generalId, i) : q("games.sanguosha.error.notYourAsk");
	if (r.pending) return rv(r, a, t, i);
	if (!nx(r, a)) return q("games.sanguosha.error.notYourTurn");
	if (t.type === "pass") {
		let e = r.seats[a].flags.cbHit;
		if (typeof e == "number" && e > 0) {
			delete r.seats[a].flags.cbHit;
			let t = H(r, a, e);
			i.push({
				kind: "draw",
				rid: r.seats[a].rid,
				data: {
					seat: a,
					n: t.length
				},
				for: [r.seats[a].rid],
				secret: { cards: t }
			}), L(r, {
				kind: "skill-draw",
				seat: a,
				card: "changbiao",
				n: t.length
			});
		}
		return r.turn.phase = "discard", Z(r, i), {
			state: r,
			fx: i
		};
	}
	return t.type === "skill" ? lx(r, a, t, i) : t.type === "play" ? t.cardIds.length === 2 ? t.as === "slash" ? _x(r, a, [t.cardIds[0], t.cardIds[1]], t.target ?? null, i) : q("games.sanguosha.error.notPlayable") : vx(r, a, t.cardIds[0], t.target ?? null, t.as, i) : q("games.sanguosha.error.notYourTurn");
}
function gx(e, t, n, r) {
	let i = e.pending;
	if (!i.seats.includes(t)) return q("games.sanguosha.error.notYourAsk");
	if (!e.candidates[t]?.includes(n)) return q("games.sanguosha.error.badGeneral");
	let a = Fe.get(n);
	if (!a) return q("games.sanguosha.error.badGeneral");
	let o = e.seats[t];
	return o.generalId = n, o.maxHp = a.hp + +(o.identity === "lord"), o.hp = o.maxHp, o.lastEndHp = o.hp, o.skills = [...a.skills], i.seats = i.seats.filter((e) => e !== t), L(e, {
		kind: "pick",
		seat: t,
		card: n
	}), o.identity === "lord" ? (i.seats = e.seats.map((e, t) => t).filter((e) => e !== t), i.simultaneous = !0, {
		state: e,
		fx: r
	}) : (i.seats.length === 0 && (e.pending = null, e.revealAll = !0, e.beatMs = J.reveal, e.queue.push({ k: "game-start" })), {
		state: e,
		fx: r
	});
}
function _x(e, t, n, r, i) {
	let a = e.seats[t], o = a.equips.weapon, s = o != null && e.cards[o].name === "spear", c = Y(e, t, "fuhun");
	if (!s && !c || a.flags.noHand || a.flags.tianyiLose) return q("games.sanguosha.error.notPlayable");
	if (n[0] === n[1] || !n.every((n) => e.hands[t].includes(n))) return q("games.sanguosha.error.noCard");
	if (e.turn.slashUsed >= Hv(e, t)) return q("games.sanguosha.error.notPlayable");
	let l = !!a.flags.tianyiWin || !!a.flags.jcBuff, u = Bv(e, t), d = z(e).filter((n) => n !== t && (l || av(e, t, n) || V(e, t, n) <= u) && !N(e, n));
	if (r == null || !d.includes(r)) return q("games.sanguosha.error.badTarget");
	for (let r of n) W(e, t, r);
	if (U(e, n), e.turn.slashUsed += 1, a.flags.slashInPlay = !0, e.turn.seat === t && e.turn.phase === "play") {
		let r = z(e).find((t) => Y(e, t, "longyin") && (e.hands[t].length > 0 || K(e, t).length > 0));
		r != null && e.queue.unshift({
			k: "longyin-ask",
			seat: r,
			from: t,
			red: G(e, n[0]) && G(e, n[1])
		});
	}
	let f = +!!a.flags.analeptic;
	delete a.flags.analeptic;
	let p = e.cards[n[0]].suit === e.cards[n[1]].suit ? e.cards[n[0]].suit : null;
	return i.push({
		kind: "play",
		rid: a.rid,
		data: {
			seat: t,
			card: n[0],
			name: "slash"
		}
	}), L(e, {
		kind: "use",
		seat: t,
		card: "slash",
		target: r,
		cards: R(e, n)
	}), (p === "heart" || p === "diamond") && vv(e, t, i), e.queue.unshift({
		k: "slash-target",
		from: t,
		target: r,
		cardName: "slash",
		suit: p,
		cardId: null,
		ana: f,
		...c ? { fuhun: !0 } : {}
	}), F(e, t, 2), Z(e, i), {
		state: e,
		fx: i
	};
}
function vx(e, t, n, r, i, a) {
	let o = !e.hands[t].includes(n), s = i === "recast" && K(e, t).includes(n) && e.cards[n].suit === "club" && Y(e, t, "re_lianhuan");
	if (o && !(s || i != null && K(e, t).includes(n) && hy(e, t, n).includes(i))) return q("games.sanguosha.error.noCard");
	let c = dx(e, t, n, i);
	if (c == null) return q("games.sanguosha.error.notPlayable");
	if (c.length > 0) {
		if (r == null || !c.includes(r)) return q("games.sanguosha.error.badTarget");
	} else r = null;
	let l = e.cards[n], u = i != null && i !== "recast" ? i : l.name;
	i !== "recast" && _y(e, t, u);
	let d = vy(e, t, n, i);
	if (O(u) === "trick" && (e.seats[t].flags.usedTrick = !0), e.turn != null && e.turn.seat === t && i !== "recast" && Y(e, t, "rejingce")) {
		let n = {
			spade: 1,
			heart: 2,
			diamond: 4,
			club: 8
		}[l.suit];
		if (e.seats[t].flags.jgSuits = (e.seats[t].flags.jgSuits ?? 0) | n, e.turn.phase === "play") {
			let n = {
				basic: 1,
				trick: 2,
				equip: 4
			}[O(u)];
			e.seats[t].flags.jgTypes = (e.seats[t].flags.jgTypes ?? 0) | n;
		}
	}
	if (o) {
		for (let r of [
			"weapon",
			"armor",
			"off_horse",
			"def_horse"
		]) e.seats[t].equips[r] === n && (e.seats[t].equips[r] = null);
		I(e, t, n, a);
	} else W(e, t, n);
	if (e.turn != null && e.turn.seat === t && i !== "recast" && (Y(e, t, "olbenxi") && (e.seats[t].flags.benxiN = (e.seats[t].flags.benxiN ?? 0) + 1), (r != null && r !== t || u === "savage_assault" || u === "archery_attack" || u === "god_salvation" || u === "amazing_grace") && (e.seats[t].flags.qtUsed = !0), e.turn.phase === "play")) {
		let n = e.seats[t].flags.qzType;
		if (n != null && Y(e, t, "qiangzhi") && (n & {
			basic: 1,
			trick: 2,
			equip: 4
		}[O(u)]) !== 0 && (H(e, t, 1), L(e, {
			kind: "qiangzhi-draw",
			seat: t
		})), Y(e, t, "jianying")) {
			let n = {
				spade: 1,
				heart: 2,
				diamond: 4,
				club: 8
			}[l.suit], r = e.seats[t].flags.jyLast;
			r != null && r !== 0 && (r >> 4 === n || (r & 15) === l.point) && (H(e, t, 1), L(e, {
				kind: "jianying",
				seat: t
			})), e.seats[t].flags.jyLast = n * 16 + l.point;
		}
	}
	if (i !== "recast" && l.suit === "spade" && r != null && e.turn != null && e.turn.seat === t && e.turn.phase === "play" && z(e).some((n) => n !== t && Y(e, n, "zuoding")) && e.queue.unshift({
		k: "zuoding-check",
		user: t,
		target: r,
		cardId: n
	}), i !== "recast" && l.suit === "spade" && Y(e, t, "bizhuan") && e.seats[t].shu.length < 4 && e.queue.unshift({
		k: "bizhuan-ask",
		seat: t
	}), i != null && i !== "recast" && Y(e, t, "taoluan") && !e.seats[t].flags.tlOff && wy(e, t).includes(A(u) ? "slash" : u) && (Ty(e, t, u), e.queue.unshift({
		k: "taoluan-after",
		seat: t,
		name: u
	})), i !== "recast" && Fv(e, n, u, t, Lv(e, t, u, r)), i == null) {
		let r = k(l.name);
		if (r) {
			let i = e.seats[t].equips[r];
			return i != null && (U(e, [i]), I(e, t, i, a)), e.seats[t].equips[r] = n, a.push({
				kind: "equip",
				rid: e.seats[t].rid,
				data: {
					seat: t,
					card: n,
					name: l.name,
					slot: r
				}
			}), L(e, {
				kind: "equip",
				seat: t,
				card: l.name,
				cards: R(e, [n])
			}), e.beatMs = J.equip, o || F(e, t, 1), {
				state: e,
				fx: a
			};
		}
	}
	if (u === "peach") {
		d ? (yy(e, n), L(e, {
			kind: "huomo",
			seat: t
		})) : U(e, [n]);
		let r = e.seats.findIndex((e) => e.identity === "lord");
		return e.turn?.seat === t && r >= 0 && r !== t && e.seats[r].alive && Y(e, r, "re_jiuyuan") && $v(e, t) === "wu" && e.seats[t].hp >= e.seats[r].hp ? (e.pending = {
			kind: "skill-ask",
			seats: [t],
			ctx: {
				skill: "jiuyuan-choice",
				options: ["self", "lord"],
				noPass: !0,
				data: { lord: r }
			}
		}, o || F(e, t, 1), {
			state: e,
			fx: a
		}) : (e.seats[t].hp += 1, a.push({
			kind: "recover",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: 1,
				by: t,
				name: l.name,
				table: !0
			}
		}), L(e, {
			kind: "peach",
			seat: t,
			cards: R(e, [n])
		}), e.beatMs = J.recover, o || F(e, t, 1), {
			state: e,
			fx: a
		});
	}
	if (u === "analeptic") return d ? (yy(e, n), L(e, {
		kind: "huomo",
		seat: t
	})) : U(e, [n]), e.seats[t].flags.analeptic = !0, e.seats[t].flags.analepticUsed = !0, a.push({
		kind: "play",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: n,
			name: u
		}
	}), L(e, {
		kind: "analeptic",
		seat: t,
		cards: R(e, [n])
	}), e.beatMs = J.play, o || F(e, t, 1), {
		state: e,
		fx: a
	};
	if (i === "recast") {
		U(e, [n]), A(l.name) && Y(e, t, "yanyu") && (e.seats[t].flags.yyCount = (e.seats[t].flags.yyCount ?? 0) + 1);
		let r = H(e, t, 1);
		return a.push({
			kind: "draw",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				n: 1
			},
			for: [e.seats[t].rid],
			secret: { cards: r }
		}), L(e, {
			kind: "recast",
			seat: t,
			card: l.name,
			cards: R(e, [n])
		}), e.beatMs = J.draw, o || F(e, t, 1), P(e, t, r), {
			state: e,
			fx: a
		};
	}
	if (A(u)) {
		if (d ? (yy(e, n), L(e, {
			kind: "huomo",
			seat: t
		})) : U(e, [n]), e.turn.seat === t && e.turn.phase === "play") {
			let r = z(e).find((t) => Y(e, t, "longyin") && (e.hands[t].length > 0 || K(e, t).length > 0));
			r != null && e.queue.unshift({
				k: "longyin-ask",
				seat: r,
				from: t,
				red: G(e, n)
			});
		}
		G(e, n) && e.queue.unshift({
			k: "jiang-check",
			cardId: n
		}), e.turn.slashUsed += 1, e.seats[t].flags.xianzhen === r && --e.turn.slashUsed, e.seats[t].flags.slashInPlay = !0;
		let i = +!!e.seats[t].flags.analeptic;
		delete e.seats[t].flags.analeptic, a.push({
			kind: "play",
			rid: e.seats[t].rid,
			data: {
				seat: t,
				card: n,
				name: u
			}
		}), L(e, {
			kind: "use",
			seat: t,
			card: u,
			target: r ?? void 0,
			cards: R(e, [n])
		}), G(e, n) && vv(e, t, a);
		let s = u === "fire_slash" && l.name === "slash" && Y(e, t, "lihuo") && (e.seats[t].equips.weapon == null || e.cards[e.seats[t].equips.weapon].name !== "fan"), c = z(e).find((n) => n !== t && n !== r && Y(e, n, "jianzheng") && e.hands[n].length > 0 && V(e, t, n) <= Bv(e, t));
		return c == null ? Le(e, t, u, l.suit, n, r, i, s, a) : (e.pending = {
			kind: "skill-cards",
			seats: [c],
			ctx: {
				skill: "jianzheng",
				min: 0,
				max: 1,
				data: {
					from: t,
					target: r,
					cardName: u,
					suit: l.suit,
					cardId: n,
					ana: i,
					lihuo: s
				}
			}
		}, o || F(e, t, 1), {
			state: e,
			fx: a
		});
	}
	switch (Me.has(u) || U(e, [n]), a.push({
		kind: "play",
		rid: e.seats[t].rid,
		data: {
			seat: t,
			card: n,
			name: u
		}
	}), L(e, {
		kind: "use",
		seat: t,
		card: u,
		target: r ?? void 0,
		cards: R(e, [n])
	}), e.beatMs = J.play, Me.has(u) || xv(e, t, a), u === "duel" && (vv(e, t, a), e.queue.unshift({
		k: "jiang-check",
		cardId: n
	})), o || F(e, t, 1), u) {
		case "savage_assault":
		case "archery_attack":
		case "god_salvation":
		case "amazing_grace": {
			let r = B(e, t).filter((e) => e !== t), i = z(e).find((t) => Y(e, t, "fenwei") && !e.seats[t].limitedUsed.includes("fenwei")), o = {
				suit: e.cards[n].suit,
				cardId: n
			};
			if (i != null && r.length >= 2) return e.pending = {
				kind: "skill-ask",
				seats: [i],
				ctx: {
					skill: "fenwei",
					data: {
						name: u,
						from: t,
						targets: r,
						...o
					}
				}
			}, {
				state: e,
				fx: a
			};
			nv(e, u, t, [], a, o);
			break;
		}
		case "indulgence":
		case "lightning":
		case "supply_shortage":
			if (e.queue.unshift({
				k: "trick-effect",
				name: u,
				from: t,
				target: r,
				cardId: n
			}), u === "lightning" && Y(e, t, "re_leiji") && Sv(e, t, a)) return {
				state: e,
				fx: a
			};
			break;
		default: {
			let i = e.seats[t].flags.xianzhen;
			if (r != null && i != null && i !== r && e.seats[i].alive && !N(e, i)) return e.pending = {
				kind: "skill-ask",
				seats: [t],
				ctx: {
					skill: "xianzhen-add-trick",
					data: {
						from: t,
						target: r,
						xz: i,
						name: u,
						cardId: n
					}
				}
			}, {
				state: e,
				fx: a
			};
			Qe(e, t, u, r, {
				k: "trick-effect",
				name: u,
				from: t,
				target: r,
				cardId: n
			});
			break;
		}
	}
	return Z(e, a), {
		state: e,
		fx: a
	};
}
//#endregion
//#region src/games/sanguosha/rules/view.ts
function yx(e, t) {
	let n = e.cards[t];
	return {
		id: t,
		name: n.name,
		suit: n.suit,
		point: n.point
	};
}
function bx(e) {
	let t = e.pending, n = { ...t.ctx };
	if (delete n.resume, delete n.dmg, n.data && typeof n.data == "object") {
		let e = { ...n.data };
		if (delete e.pool, delete e.ev, delete e.info, delete e.chain, delete e.give, delete e.myCard, t.ctx.skill === "qianxun" && n.data != null) {
			let t = n.data.ev;
			t != null && (e.ev = {
				name: t.name,
				from: t.from
			});
		}
		if (t.ctx.skill === "xiangle" && n.data != null) {
			let t = n.data.info;
			t != null && (e.info = { target: t.target });
		}
		if (t.ctx.skill === "beige-jie-discard" && n.data != null) {
			let t = n.data.ev;
			t != null && (e.ev = { target: t.target });
		}
		n.data = e;
	}
	return t.kind === "amazing-pick" && (n.revealed = t.ctx.revealed.map((t) => yx(e, t))), n;
}
function xx(e, t, n) {
	let r = ry(e, t), i = n?.fullLog ? e.log : e.log.slice(-40), a = e.pending?.kind === "general-select", o = {
		phase: e.over ? "over" : a ? "select" : e.revealAll ? "reveal" : "battle",
		seats: e.seats.map((t, n) => ({
			rid: t.rid,
			generalId: a && t.identity !== "lord" && n !== r ? null : t.generalId,
			identity: e.over !== null || t.revealed ? t.identity : null,
			hp: t.hp,
			maxHp: t.maxHp,
			handCount: e.hands[ry(e, t.rid)].length,
			equips: {
				weapon: t.equips.weapon == null ? null : yx(e, t.equips.weapon),
				armor: t.equips.armor == null ? null : yx(e, t.equips.armor),
				off_horse: t.equips.off_horse == null ? null : yx(e, t.equips.off_horse),
				def_horse: t.equips.def_horse == null ? null : yx(e, t.equips.def_horse)
			},
			judges: t.judges.map((t) => ({
				...yx(e, t),
				name: uy(e, t)
			})),
			chained: t.chained,
			turnedOver: t.turnedOver,
			zishou: t.flags.zishou === !0,
			chuang: t.chuang.map((t) => yx(e, t)),
			tian: t.tian.map((t) => yx(e, t)),
			marks: t.pojun.length > 0 || t.quan.length > 0 || t.chun.length > 0 || t.ni.length > 0 || t.kb.length > 0 ? {
				...t.marks,
				...t.pojun.length > 0 ? { pojun: t.pojun.length } : {},
				...t.quan.length > 0 ? { quan: t.quan.length } : {},
				...t.chun.length > 0 ? { chun: t.chun.length } : {},
				...t.ni.length > 0 ? { ni: t.ni.length } : {},
				...t.kb.length > 0 ? { kb: t.kb.length } : {}
			} : t.marks,
			moshi: t.moshi.map((t) => yx(e, t)),
			alive: t.alive
		})),
		deckCount: e.deck.length,
		discardTop: e.discard.length > 0 ? yx(e, e.discard[e.discard.length - 1]) : null,
		discardCount: e.discard.length,
		turn: e.turn,
		pending: e.pending ? {
			kind: e.pending.kind,
			asking: e.pending.simultaneous ? e.pending.seats : e.pending.seats.slice(0, 1),
			ctx: bx(e)
		} : null,
		tableCard: e.tableCard ? {
			card: yx(e, e.tableCard.id),
			name: e.tableCard.name,
			from: e.tableCard.from
		} : null,
		targeting: e.targeting,
		judging: e.judging,
		log: i,
		logBase: e.logTotal - i.length
	}, s = {};
	if (e.pending?.kind === "general-select" && e.pending.seats.includes(r)) s.candidates = e.candidates[r];
	else if (e.pending && (e.pending.simultaneous ? e.pending.seats.includes(r) : e.pending.seats[0] === r)) {
		let t = e.pending, n = (t) => {
			let n = [];
			if (e.seats[r].flags.noHand) return n;
			let i = e.seats[r].flags.qianxiRed;
			for (let a of e.hands[r]) (i == null || i !== G(e, a)) && (ze(e, r, a) || e.seats[r].funanBan.includes(a) || t === "slash" && e.seats[r].flags.jcNoSlash || t === "slash" && vy(e, r, a, "slash") || t === "jink" && e.cards[a].name === "jink" && Y(e, r, "shizhi") && e.seats[r].hp === 1 || (e.cards[a].name === t || t === "slash" && A(e.cards[a].name) ? n.push({ cardId: a }) : hy(e, r, a).includes(t) && n.push({
				cardId: a,
				as: t
			})));
			for (let i of K(e, r)) hy(e, r, i).includes(t) && n.push({
				cardId: i,
				as: t
			});
			return n;
		};
		switch (t.kind) {
			case "jink": {
				t.ctx.noJink || (s.respondable = n("jink"));
				let i = [], a = t.ctx.cardName == null ? null : e.seats[t.ctx.from]?.equips.weapon, o = a != null && e.cards[a].name === "qinggang_sword" || !!t.ctx.bxPierce;
				!t.ctx.noJink && ty(e, r, o) === "eight_diagram" && !t.ctx.baguaUsed && i.push("eight_diagram"), Y(e, r, "hujia") && B(e, r).some((t) => t !== r && $v(e, t) === "wei") && i.push("hujia"), !t.ctx.noJink && !t.ctx.sfUsed && e.turn != null && Y(e, r, "shifei") && i.push("shifei"), i.length > 0 && (s.choosableOptions = i), s.canPass = !0;
				break;
			}
			case "slash-response":
				s.respondable = n("slash"), Y(e, r, "jijiang") && B(e, r).some((t) => t !== r && $v(e, t) === "shu") && (s.choosableOptions = ["jijiang"]), Y(e, r, "qinwang") && e.hands[r].length + K(e, r).length > 0 && B(e, r).some((t) => t !== r && $v(e, t) === "shu") && (s.choosableOptions = [...s.choosableOptions ?? [], "qinwang"]), s.canPass = !0;
				break;
			case "nullification":
				s.respondable = n("nullification"), s.canPass = !0;
				break;
			case "peach-save":
				if (s.respondable = n("peach"), t.ctx.target === r) {
					for (let t of e.hands[r]) ze(e, r, t) || e.seats[r].funanBan.includes(t) || (e.cards[t].name === "analeptic" ? Y(e, r, "jinjiu") || s.respondable.push({ cardId: t }) : hy(e, r, t).includes("analeptic") && s.respondable.push({
						cardId: t,
						as: "analeptic"
					}));
					!e.seats[r].turnedOver && Y(e, r, "jiushi") && (s.choosableOptions = ["jiushi"]);
				}
				e.turn && (Y(e, e.turn.seat, "wansha") || Y(e, e.turn.seat, "re_wansha")) && (Y(e, e.turn.seat, "re_wansha") ? r !== t.ctx.target : r !== t.ctx.target && r !== e.turn.seat) && (s.respondable = []), s.canPass = !0;
				break;
			case "amazing-pick": {
				let n = t.ctx.taken ?? {};
				s.choosableCards = t.ctx.revealed.filter((e) => n[e] == null), s.knownCards = t.ctx.revealed.map((t) => yx(e, t));
				break;
			}
			case "pick-zone": {
				let n = t.ctx.allowJudge ?? !0;
				s.choosableOptions = et(e, t.ctx.target, t.ctx.trick, n);
				break;
			}
			case "collateral-target":
				s.choosableSeats = px(e, t.ctx.a);
				break;
			case "discard":
				s.choosableCards = [...e.hands[r]];
				break;
			case "skill-ask":
				s.choosableOptions = t.ctx.options ?? ["use"], s.canPass = !t.ctx.noPass;
				break;
			case "skill-cards": {
				let n = t.ctx.data ?? {};
				if (s.choosableCards = [...n.pool ?? e.hands[r]], n.pool) {
					let t = new Set(n.blind ?? []);
					s.knownCards = n.pool.map((n) => t.has(n) ? {
						id: n,
						name: null,
						suit: null,
						point: null
					} : yx(e, n));
				}
				t.ctx.min === 0 && (s.canPass = !0);
				break;
			}
			case "skill-seats":
				s.choosableSeats = [...(t.ctx.data ?? {}).candidates ?? z(e).filter((e) => e !== r)], t.ctx.min === 0 && (s.canPass = !0);
				break;
			case "lord-call":
				s.respondable = n(t.ctx.need), s.canPass = !0;
				break;
			case "guicai": {
				let t = Y(e, r, "guicai") || Y(e, r, "re_guicai"), n = e.seats[r].flags.noHand ? [] : t ? e.hands[r] : e.hands[r].filter((t) => qv(e, t)), i = Y(e, r, "re_guicai") ? K(e, r) : [];
				s.respondable = [...n, ...i].map((e) => ({ cardId: e })), s.canPass = !0;
				break;
			}
		}
	} else if (nx(e, r)) {
		let t = {};
		for (let n of e.hands[r]) {
			let i = dx(e, r, n);
			i != null && (t[String(n)] = {
				needTarget: i.length > 0,
				targets: i
			});
			for (let i of hy(e, r, n)) {
				let a = dx(e, r, n, i);
				a != null && (t[`${n}@${i}`] = {
					needTarget: a.length > 0,
					targets: a
				});
			}
			if (e.seats[r].flags.jzCard === n) {
				let i = Sy(e, r);
				if (i != null) {
					let a = dx(e, r, n, i);
					a != null && (t[`${n}@${i}`] = {
						needTarget: a.length > 0,
						targets: a
					});
				}
			}
			if (Y(e, r, "taoluan") && !e.seats[r].flags.tlOff) for (let i of wy(e, r)) {
				let a = dx(e, r, n, i);
				a != null && (t[`${n}@${i}`] = {
					needTarget: a.length > 0,
					targets: a
				});
			}
			if (e.cards[n].name === "slash") {
				let i = dx(e, r, n, "fire_slash");
				i != null && (t[`${n}@fire_slash`] = {
					needTarget: i.length > 0,
					targets: i
				});
			}
			(e.cards[n].name === "iron_chain" || (Y(e, r, "lianhuan") || Y(e, r, "re_lianhuan")) && e.cards[n].suit === "club" || Y(e, r, "yanyu") && A(e.cards[n].name)) && dx(e, r, n, "recast") != null && (t[`${n}@recast`] = {
				needTarget: !1,
				targets: []
			});
		}
		for (let n of K(e, r)) {
			for (let i of hy(e, r, n)) {
				let a = dx(e, r, n, i);
				a != null && (t[`${n}@${i}`] = {
					needTarget: a.length > 0,
					targets: a
				});
			}
			Y(e, r, "re_lianhuan") && e.cards[n].suit === "club" && dx(e, r, n, "recast") != null && (t[`${n}@recast`] = {
				needTarget: !1,
				targets: []
			});
		}
		s.playable = t;
		let n = e.seats[r].equips.weapon;
		if ((n != null && e.cards[n].name === "spear" || Y(e, r, "fuhun")) && e.hands[r].length >= 2 && !e.seats[r].flags.noHand && !e.seats[r].flags.tianyiLose && e.turn.slashUsed < Hv(e, r)) {
			let t = !!e.seats[r].flags.tianyiWin || !!e.seats[r].flags.jcBuff, n = Bv(e, r);
			s.serpentSlash = { targets: z(e).filter((i) => i !== r && (t || av(e, r, i) || V(e, r, i) <= n) && !N(e, i)) };
		}
		let i = [];
		for (let t of ix) {
			let n = cx(e, r, t);
			n && i.push({
				id: t,
				minCards: n.minCards,
				maxCards: n.maxCards,
				minTargets: n.minTargets,
				maxTargets: n.maxTargets,
				targets: n.targets,
				...n.suits ? { suits: n.suits } : {},
				...n.names ? { names: n.names } : {},
				...n.sameSuit ? { sameSuit: !0 } : {},
				...n.allowEquip ? { allowEquip: !0 } : {},
				...n.allowTian ? { allowTian: !0 } : {},
				...n.classes ? { classes: n.classes } : {}
			});
		}
		i.length > 0 && (s.skills = i), s.canPass = !0;
	}
	return {
		public: o,
		private: {
			identity: e.seats[r].identity,
			hand: e.hands[r].map((t) => yx(e, t)),
			act: s
		}
	};
}
function Sx(e) {
	if (!e.over) return { phase: e.pending?.kind === "general-select" ? "select" : e.revealAll ? "reveal" : "battle" };
	let t = (e) => e === "lord" || e === "loyalist" ? "lord" : e, n = e.over.winner;
	return {
		phase: "over",
		winner: e.seats.filter((e) => t(e.identity) === n).map((e) => e.rid),
		ranking: [
			...e.seats.map((e, t) => t).filter((r) => t(e.seats[r].identity) === n && e.seats[r].alive),
			...e.seats.map((e, t) => t).filter((r) => !(t(e.seats[r].identity) === n && e.seats[r].alive) && e.seats[r].alive),
			...[...e.deathOrder].reverse()
		].map((t) => e.seats[t].rid)
	};
}
function Cx(e) {
	return e.over || e.pending ? null : e.queue.length > 0 && e.beatMs > 0 ? e.beatMs : null;
}
//#endregion
//#region src/games/sanguosha/rules/index.ts
var wx = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: oe,
	schemas: {
		action: le,
		publicView: xe,
		privateView: Ce,
		config: ue
	},
	setup: ot,
	reduce: hx,
	viewFor: xx,
	viewForBot: (e, t) => xx(e, t, { fullLog: !0 }),
	status: Sx,
	nextTickIn: Cx
}, Tx = {
	axe: "games.sanguosha.card.axe",
	green_dragon: "games.sanguosha.card.blade",
	double_sword: "games.sanguosha.card.double_sword",
	"double_sword-choice": "games.sanguosha.card.double_sword",
	ice_sword: "games.sanguosha.card.ice_sword",
	"ganglie-choice": "games.sanguosha.skill.ganglie",
	jianxiong: "games.sanguosha.skill.jianxiong",
	hujia: "games.sanguosha.skill.hujia",
	fankui: "games.sanguosha.skill.fankui",
	guicai: "games.sanguosha.skill.guicai",
	ganglie: "games.sanguosha.skill.ganglie",
	qingjian: "games.sanguosha.skill.qingjian",
	tuxi: "games.sanguosha.skill.tuxi",
	luoyi: "games.sanguosha.skill.luoyi",
	tiandu: "games.sanguosha.skill.tiandu",
	yiji: "games.sanguosha.skill.yiji",
	luoshen: "games.sanguosha.skill.luoshen",
	qingguo: "games.sanguosha.skill.qingguo",
	rende: "games.sanguosha.skill.rende",
	jijiang: "games.sanguosha.skill.jijiang",
	wusheng: "games.sanguosha.skill.wusheng",
	yijue: "games.sanguosha.skill.yijue",
	paoxiao: "games.sanguosha.skill.paoxiao",
	tishen: "games.sanguosha.skill.tishen",
	guanxing: "games.sanguosha.skill.guanxing",
	kongcheng: "games.sanguosha.skill.kongcheng",
	longdan: "games.sanguosha.skill.longdan",
	yajiao: "games.sanguosha.skill.yajiao",
	mashu: "games.sanguosha.skill.mashu",
	tieji: "games.sanguosha.skill.tieji",
	jizhi: "games.sanguosha.skill.jizhi",
	qicai: "games.sanguosha.skill.qicai",
	zhiheng: "games.sanguosha.skill.zhiheng",
	jiuyuan: "games.sanguosha.skill.jiuyuan",
	qixi: "games.sanguosha.skill.qixi",
	fenwei: "games.sanguosha.skill.fenwei",
	keji: "games.sanguosha.skill.keji",
	qinxue: "games.sanguosha.skill.qinxue",
	kurou: "games.sanguosha.skill.kurou",
	zhaxiang: "games.sanguosha.skill.zhaxiang",
	yingzi: "games.sanguosha.skill.yingzi",
	fanjian: "games.sanguosha.skill.fanjian",
	guose: "games.sanguosha.skill.guose",
	liuli: "games.sanguosha.skill.liuli",
	qianxun: "games.sanguosha.skill.qianxun",
	lianying: "games.sanguosha.skill.lianying",
	jieyin: "games.sanguosha.skill.jieyin",
	xiaoji: "games.sanguosha.skill.xiaoji",
	chuli: "games.sanguosha.skill.chuli",
	jijiu: "games.sanguosha.skill.jijiu",
	wushuang: "games.sanguosha.skill.wushuang",
	liyu: "games.sanguosha.skill.liyu",
	lijian: "games.sanguosha.skill.lijian",
	biyue: "games.sanguosha.skill.biyue",
	gongxin: "games.sanguosha.skill.gongxin",
	shensu: "games.sanguosha.skill.shensu",
	jushou: "games.sanguosha.skill.jushou",
	jiewei: "games.sanguosha.skill.jiewei",
	liegong: "games.sanguosha.skill.liegong",
	kuanggu: "games.sanguosha.skill.kuanggu",
	tianxiang: "games.sanguosha.skill.tianxiang",
	hongyan: "games.sanguosha.skill.hongyan",
	buqu: "games.sanguosha.skill.buqu",
	fenji: "games.sanguosha.skill.fenji",
	leiji: "games.sanguosha.skill.leiji",
	guidao: "games.sanguosha.skill.guidao",
	huangtian: "games.sanguosha.skill.huangtian",
	qiangxi: "games.sanguosha.skill.qiangxi",
	quhu: "games.sanguosha.skill.quhu",
	jieming: "games.sanguosha.skill.jieming",
	lianhuan: "games.sanguosha.skill.lianhuan",
	niepan: "games.sanguosha.skill.niepan",
	huoji: "games.sanguosha.skill.huoji",
	kanpo: "games.sanguosha.skill.kanpo",
	bazhen: "games.sanguosha.skill.bazhen",
	tianyi: "games.sanguosha.skill.tianyi",
	luanji: "games.sanguosha.skill.luanji",
	xueyi: "games.sanguosha.skill.xueyi",
	shuangxiong: "games.sanguosha.skill.shuangxiong",
	mengjin: "games.sanguosha.skill.mengjin",
	duanliang: "games.sanguosha.skill.duanliang",
	xingshang: "games.sanguosha.skill.xingshang",
	fangzhu: "games.sanguosha.skill.fangzhu",
	songwei: "games.sanguosha.skill.songwei",
	huoshou: "games.sanguosha.skill.huoshou",
	zaiqi: "games.sanguosha.skill.zaiqi",
	juxiang: "games.sanguosha.skill.juxiang",
	lieren: "games.sanguosha.skill.lieren",
	"lieren-target": "games.sanguosha.skill.lieren",
	yinghun: "games.sanguosha.skill.yinghun",
	"yinghun-mode": "games.sanguosha.skill.yinghun",
	haoshi: "games.sanguosha.skill.haoshi",
	"haoshi-give": "games.sanguosha.skill.haoshi",
	dimeng: "games.sanguosha.skill.dimeng",
	jiuchi: "games.sanguosha.skill.jiuchi",
	roulin: "games.sanguosha.skill.roulin",
	benghuai: "games.sanguosha.skill.benghuai",
	baonue: "games.sanguosha.skill.baonue",
	wansha: "games.sanguosha.skill.wansha",
	luanwu: "games.sanguosha.skill.luanwu",
	"luanwu-slash": "games.sanguosha.skill.luanwu",
	"luanwu-target": "games.sanguosha.skill.luanwu",
	weimu: "games.sanguosha.skill.weimu",
	qiaobian: "games.sanguosha.skill.qiaobian",
	"qiaobian-judge": "games.sanguosha.skill.qiaobian",
	"qiaobian-draw": "games.sanguosha.skill.qiaobian",
	"qiaobian-play": "games.sanguosha.skill.qiaobian",
	"qiaobian-discard": "games.sanguosha.skill.qiaobian",
	"qiaobian-field": "games.sanguosha.skill.qiaobian",
	"qiaobian-move": "games.sanguosha.skill.qiaobian",
	tuntian: "games.sanguosha.skill.tuntian",
	zaoxian: "games.sanguosha.skill.zaoxian",
	jixi: "games.sanguosha.skill.jixi",
	tiaoxin: "games.sanguosha.skill.tiaoxin",
	"tiaoxin-slash": "games.sanguosha.skill.tiaoxin",
	zhiji: "games.sanguosha.skill.zhiji",
	xiangle: "games.sanguosha.skill.xiangle",
	fangquan: "games.sanguosha.skill.fangquan",
	"fangquan-target": "games.sanguosha.skill.fangquan",
	ruoyu: "games.sanguosha.skill.ruoyu",
	jiang: "games.sanguosha.skill.jiang",
	hunzi: "games.sanguosha.skill.hunzi",
	zhiba: "games.sanguosha.skill.zhiba",
	"zhiba-obtain": "games.sanguosha.skill.zhiba",
	zhijian: "games.sanguosha.skill.zhijian",
	guzheng: "games.sanguosha.skill.guzheng",
	beige: "games.sanguosha.skill.beige",
	"beige-discard": "games.sanguosha.skill.beige",
	"beige-drop": "games.sanguosha.skill.beige",
	"beige-jie-discard": "games.sanguosha.skill.beige",
	duanchang: "games.sanguosha.skill.duanchang",
	botu: "games.sanguosha.skill.botu",
	qingnang: "games.sanguosha.skill.qingnang",
	shebian: "games.sanguosha.skill.shebian",
	"shebian-move": "games.sanguosha.skill.shebian",
	moshi: "games.sanguosha.skill.moshi",
	qimou: "games.sanguosha.skill.qimou",
	"qimou-x": "games.sanguosha.skill.qimou",
	piaoling: "games.sanguosha.skill.piaoling",
	"piaoling-choice": "games.sanguosha.skill.piaoling",
	"piaoling-discard": "games.sanguosha.skill.piaoling",
	"piaoling-give": "games.sanguosha.skill.piaoling",
	ninge: "games.sanguosha.skill.ninge",
	cangzhuo: "games.sanguosha.skill.cangzhuo",
	hanzhan: "games.sanguosha.skill.hanzhan",
	jianchu: "games.sanguosha.skill.jianchu",
	jiezi: "games.sanguosha.skill.jiezi",
	"jiezi-mark": "games.sanguosha.skill.jiezi",
	wulie: "games.sanguosha.skill.wulie",
	"wulie-x": "games.sanguosha.skill.wulie",
	"wulie-targets": "games.sanguosha.skill.wulie",
	changbiao: "games.sanguosha.skill.changbiao",
	sishu: "games.sanguosha.skill.sishu",
	"tieji-give": "games.sanguosha.skill.tieji",
	"tieji-discard": "games.sanguosha.skill.tieji",
	"jiewei-jie": "games.sanguosha.skill.jiewei",
	"jiewei-jie-discard": "games.sanguosha.skill.jiewei",
	"jiewei-use": "games.sanguosha.skill.jiewei",
	"jiewei-target": "games.sanguosha.skill.jiewei",
	"jiewei-discard": "games.sanguosha.skill.jiewei",
	"jushou-discard": "games.sanguosha.skill.jushou",
	"leiji-jie-spade": "games.sanguosha.skill.leiji",
	"leiji-jie-club": "games.sanguosha.skill.leiji",
	"qinxue-jie": "games.sanguosha.skill.qinxue",
	"hunzi-bonus": "games.sanguosha.skill.hunzi",
	"zaiqi-jie": "games.sanguosha.skill.zaiqi",
	"zaiqi-jie-choice": "games.sanguosha.skill.zaiqi",
	"xingshang-jie": "games.sanguosha.skill.xingshang",
	"yajiao-give": "games.sanguosha.skill.yajiao",
	"yajiao-drop": "games.sanguosha.skill.yajiao",
	"luanwu-jie": "games.sanguosha.skill.luanwu",
	"luanwu-jie-target": "games.sanguosha.skill.luanwu",
	"jiang-obtain": "games.sanguosha.skill.jiang",
	"rende-basic": "games.sanguosha.skill.rende",
	"rende-slash": "games.sanguosha.skill.rende",
	"yijue-jie-show": "games.sanguosha.skill.yijue",
	"yijue-heal": "games.sanguosha.skill.yijue",
	"luanji-reduce": "games.sanguosha.skill.luanji",
	"jiuyuan-choice": "games.sanguosha.skill.jiuyuan",
	"niepan-pick": "games.sanguosha.skill.niepan",
	"tianxiang-discard": "games.sanguosha.skill.tianxiang",
	"tianxiang-mode": "games.sanguosha.skill.tianxiang",
	"tianxiang-target": "games.sanguosha.skill.tianxiang",
	"jieming-drop": "games.sanguosha.skill.jieming",
	"fangzhu-choice": "games.sanguosha.skill.fangzhu",
	"fangzhu-drop": "games.sanguosha.skill.fangzhu",
	"shuangxiong-jie": "games.sanguosha.skill.shuangxiong",
	re_jianxiong: "games.sanguosha.skill.jianxiong",
	re_guicai: "games.sanguosha.skill.guicai",
	re_ganglie: "games.sanguosha.skill.ganglie",
	re_tuxi: "games.sanguosha.skill.tuxi",
	re_luoyi: "games.sanguosha.skill.luoyi",
	re_luoshen: "games.sanguosha.skill.luoshen",
	re_rende: "games.sanguosha.skill.rende",
	re_wusheng: "games.sanguosha.skill.wusheng",
	re_yijue: "games.sanguosha.skill.yijue",
	re_paoxiao: "games.sanguosha.skill.paoxiao",
	re_tishen: "games.sanguosha.skill.tishen",
	re_guanxing: "games.sanguosha.skill.guanxing",
	re_longdan: "games.sanguosha.skill.longdan",
	re_yajiao: "games.sanguosha.skill.yajiao",
	re_tieji: "games.sanguosha.skill.tieji",
	re_qicai: "games.sanguosha.skill.qicai",
	re_zhiheng: "games.sanguosha.skill.zhiheng",
	re_jiuyuan: "games.sanguosha.skill.jiuyuan",
	re_qixi: "games.sanguosha.skill.qixi",
	re_qinxue: "games.sanguosha.skill.qinxue",
	re_jieyin: "games.sanguosha.skill.jieyin",
	re_jijiu: "games.sanguosha.skill.jijiu",
	re_liyu: "games.sanguosha.skill.liyu",
	re_lijian: "games.sanguosha.skill.lijian",
	re_biyue: "games.sanguosha.skill.biyue",
	re_shensu: "games.sanguosha.skill.shensu",
	re_jushou: "games.sanguosha.skill.jushou",
	re_jiewei: "games.sanguosha.skill.jiewei",
	re_liegong: "games.sanguosha.skill.liegong",
	re_kuanggu: "games.sanguosha.skill.kuanggu",
	re_tianxiang: "games.sanguosha.skill.tianxiang",
	re_hongyan: "games.sanguosha.skill.hongyan",
	re_leiji: "games.sanguosha.skill.leiji",
	re_guidao: "games.sanguosha.skill.guidao",
	re_huangtian: "games.sanguosha.skill.huangtian",
	re_qiangxi: "games.sanguosha.skill.qiangxi",
	re_jieming: "games.sanguosha.skill.jieming",
	re_lianhuan: "games.sanguosha.skill.lianhuan",
	re_niepan: "games.sanguosha.skill.niepan",
	re_huoji: "games.sanguosha.skill.huoji",
	re_kanpo: "games.sanguosha.skill.kanpo",
	re_luanji: "games.sanguosha.skill.luanji",
	re_xueyi: "games.sanguosha.skill.xueyi",
	re_shuangxiong: "games.sanguosha.skill.shuangxiong",
	re_duanliang: "games.sanguosha.skill.duanliang",
	re_xingshang: "games.sanguosha.skill.xingshang",
	re_fangzhu: "games.sanguosha.skill.fangzhu",
	re_zaiqi: "games.sanguosha.skill.zaiqi",
	re_jiuchi: "games.sanguosha.skill.jiuchi",
	re_baonue: "games.sanguosha.skill.baonue",
	re_wansha: "games.sanguosha.skill.wansha",
	re_luanwu: "games.sanguosha.skill.luanwu",
	re_weimu: "games.sanguosha.skill.weimu",
	re_qiaobian: "games.sanguosha.skill.qiaobian",
	re_tuntian: "games.sanguosha.skill.tuntian",
	re_zaoxian: "games.sanguosha.skill.zaoxian",
	re_tiaoxin: "games.sanguosha.skill.tiaoxin",
	re_zhiji: "games.sanguosha.skill.zhiji",
	re_fangquan: "games.sanguosha.skill.fangquan",
	re_ruoyu: "games.sanguosha.skill.ruoyu",
	re_jiang: "games.sanguosha.skill.jiang",
	re_hunzi: "games.sanguosha.skill.hunzi",
	re_zhiba: "games.sanguosha.skill.zhiba",
	re_zhijian: "games.sanguosha.skill.zhijian",
	re_guzheng: "games.sanguosha.skill.guzheng",
	re_beige: "games.sanguosha.skill.beige",
	shensu1: "games.sanguosha.skill.shensu",
	shensu2: "games.sanguosha.skill.shensu",
	shensu3: "games.sanguosha.skill.shensu",
	"shensu-slash": "games.sanguosha.skill.shensu",
	"shensu2-discard": "games.sanguosha.skill.shensu",
	"ganglie-drop": "games.sanguosha.skill.ganglie",
	"fanjian-discard": "games.sanguosha.skill.fanjian",
	"yiji-give": "games.sanguosha.skill.yiji",
	"liuli-target": "games.sanguosha.skill.liuli",
	"quhu-damage": "games.sanguosha.skill.quhu",
	"tianyi-extra": "games.sanguosha.skill.tianyi",
	"axe-discard": "games.sanguosha.card.axe",
	"ds-drop": "games.sanguosha.card.double_sword",
	luoying: "games.sanguosha.skill.luoying",
	jiushi: "games.sanguosha.skill.jiushi",
	rezhenjun: "games.sanguosha.skill.rezhenjun",
	"rezhenjun-target": "games.sanguosha.skill.rezhenjun",
	"rezhenjun-choice": "games.sanguosha.skill.rezhenjun",
	"rezhenjun-drop": "games.sanguosha.skill.rezhenjun",
	jueqing: "games.sanguosha.skill.jueqing",
	shangshi: "games.sanguosha.skill.shangshi",
	xinxuanhuo: "games.sanguosha.skill.xinxuanhuo",
	"xuanhuo-target": "games.sanguosha.skill.xinxuanhuo",
	"xuanhuo-victim": "games.sanguosha.skill.xinxuanhuo",
	"xuanhuo-slash": "games.sanguosha.skill.xinxuanhuo",
	xinenyuan: "games.sanguosha.skill.xinenyuan",
	"enyuan-give": "games.sanguosha.skill.xinenyuan",
	"xinenyuan-ask": "games.sanguosha.skill.xinenyuan",
	olsanyao: "games.sanguosha.skill.olsanyao",
	rezhiman: "games.sanguosha.skill.rezhiman",
	xinwuyan: "games.sanguosha.skill.xinwuyan",
	xinjujian: "games.sanguosha.skill.xinjujian",
	"jujian-cost": "games.sanguosha.skill.xinjujian",
	"jujian-target": "games.sanguosha.skill.xinjujian",
	"jujian-choice": "games.sanguosha.skill.xinjujian",
	xinpojun: "games.sanguosha.skill.xinpojun",
	xuanfeng: "games.sanguosha.skill.xuanfeng",
	"xuanfeng-target": "games.sanguosha.skill.xuanfeng",
	ganlu: "games.sanguosha.skill.ganlu",
	buyi: "games.sanguosha.skill.buyi",
	mingce: "games.sanguosha.skill.mingce",
	"mingce-choice": "games.sanguosha.skill.mingce",
	"mingce-victim": "games.sanguosha.skill.mingce",
	zhichi: "games.sanguosha.skill.zhichi",
	xinxianzhen: "games.sanguosha.skill.xinxianzhen",
	"xianzhen-add": "games.sanguosha.skill.xinxianzhen",
	"xianzhen-add-trick": "games.sanguosha.skill.xinxianzhen",
	jinjiu: "games.sanguosha.skill.jinjiu",
	zhenlie: "games.sanguosha.skill.zhenlie",
	miji: "games.sanguosha.skill.miji",
	"miji-give": "games.sanguosha.skill.miji",
	"miji-target": "games.sanguosha.skill.miji",
	qice: "games.sanguosha.skill.qice",
	"qice-pick": "games.sanguosha.skill.qice",
	"qice-target": "games.sanguosha.skill.qice",
	zhiyu: "games.sanguosha.skill.zhiyu",
	"zhiyu-discard": "games.sanguosha.skill.zhiyu",
	quanji: "games.sanguosha.skill.quanji",
	"quanji-put": "games.sanguosha.skill.quanji",
	zili: "games.sanguosha.skill.zili",
	paiyi: "games.sanguosha.skill.paiyi",
	"paiyi-target": "games.sanguosha.skill.paiyi",
	qianxi: "games.sanguosha.skill.qianxi",
	"qianxi-discard": "games.sanguosha.skill.qianxi",
	"qianxi-target": "games.sanguosha.skill.qianxi",
	dangxian: "games.sanguosha.skill.dangxian",
	fuli: "games.sanguosha.skill.fuli",
	fuhun: "games.sanguosha.skill.fuhun",
	old_anxu: "games.sanguosha.skill.old_anxu",
	"anxu-targets": "games.sanguosha.skill.old_anxu",
	zhuiyi: "games.sanguosha.skill.zhuiyi",
	"zhuiyi-target": "games.sanguosha.skill.zhuiyi",
	gongji: "games.sanguosha.skill.gongji",
	"gongji-discard": "games.sanguosha.skill.gongji",
	"gongji-target": "games.sanguosha.skill.gongji",
	jiefan: "games.sanguosha.skill.jiefan",
	"jiefan-step": "games.sanguosha.skill.jiefan",
	"jiefan-discard": "games.sanguosha.skill.jiefan",
	lihuo: "games.sanguosha.skill.lihuo",
	chunlao: "games.sanguosha.skill.chunlao",
	"chunlao-put": "games.sanguosha.skill.chunlao",
	"chunlao-save": "games.sanguosha.skill.chunlao",
	rezishou: "games.sanguosha.skill.rezishou",
	zongshi: "games.sanguosha.skill.zongshi",
	new_jiangchi: "games.sanguosha.skill.new_jiangchi",
	rejingce: "games.sanguosha.skill.rejingce",
	chengxiang: "games.sanguosha.skill.chengxiang",
	"chengxiang-take": "games.sanguosha.skill.chengxiang",
	renxin: "games.sanguosha.skill.renxin",
	"renxin-discard": "games.sanguosha.skill.renxin",
	danshou: "games.sanguosha.skill.danshou",
	"danshou-give": "games.sanguosha.skill.danshou",
	zhiyan: "games.sanguosha.skill.zhiyan",
	"zhiyan-target": "games.sanguosha.skill.zhiyan",
	zongxuan: "games.sanguosha.skill.zongxuan",
	"zongxuan-put": "games.sanguosha.skill.zongxuan",
	qiuyuan: "games.sanguosha.skill.qiuyuan",
	"qiuyuan-target": "games.sanguosha.skill.qiuyuan",
	"qiuyuan-choice": "games.sanguosha.skill.qiuyuan",
	"qiuyuan-jink": "games.sanguosha.skill.qiuyuan",
	zhuikong: "games.sanguosha.skill.zhuikong",
	"zhuikong-pick": "games.sanguosha.skill.zhuikong",
	"zhuikong-respond": "games.sanguosha.skill.zhuikong",
	qiaoshui: "games.sanguosha.skill.qiaoshui",
	"qiaoshui-target": "games.sanguosha.skill.qiaoshui",
	"qiaoshui-pick": "games.sanguosha.skill.qiaoshui",
	"qiaoshui-respond": "games.sanguosha.skill.qiaoshui",
	jyzongshi: "games.sanguosha.skill.jyzongshi",
	xiansi: "games.sanguosha.skill.xiansi",
	"xiansi-pick": "games.sanguosha.skill.xiansi",
	xiansi2: "games.sanguosha.skill.xiansi2",
	junxing: "games.sanguosha.skill.junxing",
	"junxing-choice": "games.sanguosha.skill.junxing",
	"junxing-discard": "games.sanguosha.skill.junxing",
	yuce: "games.sanguosha.skill.yuce",
	"yuce-show": "games.sanguosha.skill.yuce",
	"yuce-source": "games.sanguosha.skill.yuce",
	"yuce-source-discard": "games.sanguosha.skill.yuce",
	duodao: "games.sanguosha.skill.duodao",
	"duodao-discard": "games.sanguosha.skill.duodao",
	anjian: "games.sanguosha.skill.anjian",
	longyin: "games.sanguosha.skill.longyin",
	"longyin-discard": "games.sanguosha.skill.longyin",
	xinjuece: "games.sanguosha.skill.xinjuece",
	"juece-target": "games.sanguosha.skill.xinjuece",
	xinmieji: "games.sanguosha.skill.xinmieji",
	"xinmieji-choice": "games.sanguosha.skill.xinmieji",
	"mieji-trick": "games.sanguosha.skill.xinmieji",
	"mieji-drop2": "games.sanguosha.skill.xinmieji",
	xinfencheng: "games.sanguosha.skill.xinfencheng",
	"fencheng-step": "games.sanguosha.skill.xinfencheng",
	"fencheng-discard": "games.sanguosha.skill.xinfencheng",
	shenduan: "games.sanguosha.skill.shenduan",
	"shenduan-pick": "games.sanguosha.skill.shenduan",
	"shenduan-target": "games.sanguosha.skill.shenduan",
	yonglve: "games.sanguosha.skill.yonglve",
	pindi: "games.sanguosha.skill.pindi",
	"pindi-choice": "games.sanguosha.skill.pindi",
	"pindi-discard": "games.sanguosha.skill.pindi",
	faen: "games.sanguosha.skill.faen",
	xinsidi: "games.sanguosha.skill.xinsidi",
	"sidi-discard": "games.sanguosha.skill.xinsidi",
	qiangzhi: "games.sanguosha.skill.qiangzhi",
	"qiangzhi-target": "games.sanguosha.skill.qiangzhi",
	xiantu: "games.sanguosha.skill.xiantu",
	"xiantu-give": "games.sanguosha.skill.xiantu",
	olbenxi: "games.sanguosha.skill.olbenxi",
	xinzhongyong: "games.sanguosha.skill.xinzhongyong",
	"zy-target": "games.sanguosha.skill.xinzhongyong",
	"zy-card": "games.sanguosha.skill.xinzhongyong",
	"zy-slash": "games.sanguosha.skill.xinzhongyong",
	"zy-slash-target": "games.sanguosha.skill.xinzhongyong",
	chanhui: "games.sanguosha.skill.chanhui",
	"chanhui-pick": "games.sanguosha.skill.chanhui",
	"chanhui-choice": "games.sanguosha.skill.chanhui",
	"chanhui-give": "games.sanguosha.skill.chanhui",
	jiaojin: "games.sanguosha.skill.jiaojin",
	"jiaojin-discard": "games.sanguosha.skill.jiaojin",
	fenli: "games.sanguosha.skill.fenli",
	"fenli-draw": "games.sanguosha.skill.fenli",
	"fenli-play": "games.sanguosha.skill.fenli",
	"fenli-discard": "games.sanguosha.skill.fenli",
	pingkou: "games.sanguosha.skill.pingkou",
	"pingkou-targets": "games.sanguosha.skill.pingkou",
	shenxing: "games.sanguosha.skill.shenxing",
	olbingyi: "games.sanguosha.skill.olbingyi",
	"bingyi-targets": "games.sanguosha.skill.olbingyi",
	jianying: "games.sanguosha.skill.jianying",
	shibei: "games.sanguosha.skill.shibei",
	qieting: "games.sanguosha.skill.qieting",
	"qieting-move": "games.sanguosha.skill.qieting",
	xianzhou: "games.sanguosha.skill.xianzhou",
	"xianzhou-choice": "games.sanguosha.skill.xianzhou",
	"xianzhou-targets": "games.sanguosha.skill.xianzhou",
	qianju: "games.sanguosha.skill.qianju",
	qingxi: "games.sanguosha.skill.qingxi",
	"qingxi-discard": "games.sanguosha.skill.qingxi",
	huituo: "games.sanguosha.skill.huituo",
	"huituo-target": "games.sanguosha.skill.huituo",
	mingjian: "games.sanguosha.skill.mingjian",
	xingshuai: "games.sanguosha.skill.xingshuai",
	huomo: "games.sanguosha.skill.huomo",
	zuoding: "games.sanguosha.skill.zuoding",
	"zuoding-target": "games.sanguosha.skill.zuoding",
	qiaoshi: "games.sanguosha.skill.qiaoshi",
	yanyu: "games.sanguosha.skill.yanyu",
	"yanyu-target": "games.sanguosha.skill.yanyu",
	zhanjue: "games.sanguosha.skill.zhanjue",
	qinwang: "games.sanguosha.skill.qinwang",
	"qinwang-discard": "games.sanguosha.skill.qinwang",
	wurong: "games.sanguosha.skill.wurong",
	"wurong-pick": "games.sanguosha.skill.wurong",
	"wurong-pick2": "games.sanguosha.skill.wurong",
	shizhi: "games.sanguosha.skill.shizhi",
	xinanguo: "games.sanguosha.skill.xinanguo",
	yaoming: "games.sanguosha.skill.yaoming",
	"yaoming-target": "games.sanguosha.skill.yaoming",
	yanzhu: "games.sanguosha.skill.yanzhu",
	"yanzhu-choice": "games.sanguosha.skill.yanzhu",
	"yanzhu-discard": "games.sanguosha.skill.yanzhu",
	xingxue: "games.sanguosha.skill.xingxue",
	"xingxue-targets": "games.sanguosha.skill.xingxue",
	"xx-put": "games.sanguosha.skill.xingxue",
	xinzhaofu: "games.sanguosha.skill.xinzhaofu",
	huaiyi: "games.sanguosha.skill.huaiyi",
	"huaiyi-color": "games.sanguosha.skill.huaiyi",
	"huaiyi-targets": "games.sanguosha.skill.huaiyi",
	jigong: "games.sanguosha.skill.jigong",
	shifei: "games.sanguosha.skill.shifei",
	"shifei-target": "games.sanguosha.skill.shifei",
	jiaozhao: "games.sanguosha.skill.jiaozhao",
	"jiaozhao-name": "games.sanguosha.skill.jiaozhao",
	danxin: "games.sanguosha.skill.danxin",
	guizao: "games.sanguosha.skill.guizao",
	jiyu: "games.sanguosha.skill.jiyu",
	"jiyu-discard": "games.sanguosha.skill.jiyu",
	qinqing: "games.sanguosha.skill.qinqing",
	huisheng: "games.sanguosha.skill.huisheng",
	"huisheng-offer": "games.sanguosha.skill.huisheng",
	"huisheng-pick": "games.sanguosha.skill.huisheng",
	"huisheng-pay": "games.sanguosha.skill.huisheng",
	dcduliang: "games.sanguosha.skill.dcduliang",
	fulin: "games.sanguosha.skill.fulin",
	kuangbi: "games.sanguosha.skill.kuangbi",
	"kuangbi-put": "games.sanguosha.skill.kuangbi",
	jishe: "games.sanguosha.skill.jishe",
	"jishe-chain": "games.sanguosha.skill.jishe",
	lianhuo: "games.sanguosha.skill.lianhuo",
	taoluan: "games.sanguosha.skill.taoluan",
	"taoluan-target": "games.sanguosha.skill.taoluan",
	"taoluan-give": "games.sanguosha.skill.taoluan",
	zhige: "games.sanguosha.skill.zhige",
	"zg-slash-card": "games.sanguosha.skill.zhige",
	"zg-slash-target": "games.sanguosha.skill.zhige",
	"zg-equip": "games.sanguosha.skill.zhige",
	zongzuo: "games.sanguosha.skill.zongzuo",
	zhongjian: "games.sanguosha.skill.zhongjian",
	"zhongjian-drop": "games.sanguosha.skill.zhongjian",
	caishi: "games.sanguosha.skill.caishi",
	qingxian: "games.sanguosha.skill.qingxian",
	canyun: "games.sanguosha.skill.canyun",
	juexiang: "games.sanguosha.skill.juexiang",
	"juexiang-target": "games.sanguosha.skill.juexiang",
	fumian: "games.sanguosha.skill.fumian",
	daiyan: "games.sanguosha.skill.daiyan",
	"daiyan-target": "games.sanguosha.skill.daiyan",
	jianzheng: "games.sanguosha.skill.jianzheng",
	zhuandui: "games.sanguosha.skill.zhuandui",
	"zhuandui-card": "games.sanguosha.skill.zhuandui",
	"zhuandui-respond": "games.sanguosha.skill.zhuandui",
	tianbian: "games.sanguosha.skill.tianbian",
	"tianbian-choice": "games.sanguosha.skill.tianbian",
	funan: "games.sanguosha.skill.funan",
	xinjiexun: "games.sanguosha.skill.xinjiexun",
	"xinjiexun-discard": "games.sanguosha.skill.xinjiexun",
	wengua: "games.sanguosha.skill.wengua",
	"wengua-place": "games.sanguosha.skill.wengua",
	fuzhu: "games.sanguosha.skill.fuzhu",
	shouxi: "games.sanguosha.skill.shouxi",
	"shouxi-discard": "games.sanguosha.skill.shouxi",
	huimin: "games.sanguosha.skill.huimin",
	"huimin-show": "games.sanguosha.skill.huimin",
	"huimin-start": "games.sanguosha.skill.huimin",
	"huimin-take": "games.sanguosha.skill.huimin",
	bizhuan: "games.sanguosha.skill.bizhuan",
	tongbo: "games.sanguosha.skill.tongbo",
	"tongbo-swap": "games.sanguosha.skill.tongbo",
	"tongbo-take": "games.sanguosha.skill.tongbo",
	"tongbo-give": "games.sanguosha.skill.tongbo"
}, Ex = {
	green_dragon: "games.sanguosha.cardDesc.blade",
	ds: "games.sanguosha.cardDesc.double_sword",
	xuanhuo: "games.sanguosha.skillDesc.xinxuanhuo",
	mieji: "games.sanguosha.skillDesc.xinmieji",
	enyuan: "games.sanguosha.skillDesc.xinenyuan",
	fencheng: "games.sanguosha.skillDesc.xinfencheng",
	zg: "games.sanguosha.skillDesc.zhige",
	xx: "games.sanguosha.skillDesc.xingxue",
	zy: "games.sanguosha.skillDesc.xinzhongyong",
	sidi: "games.sanguosha.skillDesc.xinsidi",
	juece: "games.sanguosha.skillDesc.xinjuece",
	jujian: "games.sanguosha.skillDesc.xinjujian",
	anxu: "games.sanguosha.skillDesc.old_anxu",
	bingyi: "games.sanguosha.skillDesc.olbingyi",
	jianxiong: "games.sanguosha.skillDesc.jianxiong",
	hujia: "games.sanguosha.skillDesc.hujia",
	fankui: "games.sanguosha.skillDesc.fankui",
	guicai: "games.sanguosha.skillDesc.guicai",
	ganglie: "games.sanguosha.skillDesc.ganglie",
	qingjian: "games.sanguosha.skillDesc.qingjian",
	tuxi: "games.sanguosha.skillDesc.tuxi",
	luoyi: "games.sanguosha.skillDesc.luoyi",
	tiandu: "games.sanguosha.skillDesc.tiandu",
	yiji: "games.sanguosha.skillDesc.yiji",
	luoshen: "games.sanguosha.skillDesc.luoshen",
	qingguo: "games.sanguosha.skillDesc.qingguo",
	rende: "games.sanguosha.skillDesc.rende",
	jijiang: "games.sanguosha.skillDesc.jijiang",
	wusheng: "games.sanguosha.skillDesc.wusheng",
	yijue: "games.sanguosha.skillDesc.yijue",
	paoxiao: "games.sanguosha.skillDesc.paoxiao",
	tishen: "games.sanguosha.skillDesc.tishen",
	guanxing: "games.sanguosha.skillDesc.guanxing",
	kongcheng: "games.sanguosha.skillDesc.kongcheng",
	longdan: "games.sanguosha.skillDesc.longdan",
	yajiao: "games.sanguosha.skillDesc.yajiao",
	mashu: "games.sanguosha.skillDesc.mashu",
	tieji: "games.sanguosha.skillDesc.tieji",
	jizhi: "games.sanguosha.skillDesc.jizhi",
	qicai: "games.sanguosha.skillDesc.qicai",
	zhiheng: "games.sanguosha.skillDesc.zhiheng",
	jiuyuan: "games.sanguosha.skillDesc.jiuyuan",
	qixi: "games.sanguosha.skillDesc.qixi",
	fenwei: "games.sanguosha.skillDesc.fenwei",
	keji: "games.sanguosha.skillDesc.keji",
	qinxue: "games.sanguosha.skillDesc.qinxue",
	kurou: "games.sanguosha.skillDesc.kurou",
	zhaxiang: "games.sanguosha.skillDesc.zhaxiang",
	yingzi: "games.sanguosha.skillDesc.yingzi",
	fanjian: "games.sanguosha.skillDesc.fanjian",
	guose: "games.sanguosha.skillDesc.guose",
	liuli: "games.sanguosha.skillDesc.liuli",
	qianxun: "games.sanguosha.skillDesc.qianxun",
	lianying: "games.sanguosha.skillDesc.lianying",
	jieyin: "games.sanguosha.skillDesc.jieyin",
	xiaoji: "games.sanguosha.skillDesc.xiaoji",
	chuli: "games.sanguosha.skillDesc.chuli",
	jijiu: "games.sanguosha.skillDesc.jijiu",
	wushuang: "games.sanguosha.skillDesc.wushuang",
	liyu: "games.sanguosha.skillDesc.liyu",
	lijian: "games.sanguosha.skillDesc.lijian",
	biyue: "games.sanguosha.skillDesc.biyue",
	gongxin: "games.sanguosha.skillDesc.gongxin",
	shensu: "games.sanguosha.skillDesc.shensu",
	jushou: "games.sanguosha.skillDesc.jushou",
	jiewei: "games.sanguosha.skillDesc.jiewei",
	liegong: "games.sanguosha.skillDesc.liegong",
	kuanggu: "games.sanguosha.skillDesc.kuanggu",
	tianxiang: "games.sanguosha.skillDesc.tianxiang",
	hongyan: "games.sanguosha.skillDesc.hongyan",
	buqu: "games.sanguosha.skillDesc.buqu",
	fenji: "games.sanguosha.skillDesc.fenji",
	leiji: "games.sanguosha.skillDesc.leiji",
	guidao: "games.sanguosha.skillDesc.guidao",
	huangtian: "games.sanguosha.skillDesc.huangtian",
	qiangxi: "games.sanguosha.skillDesc.qiangxi",
	quhu: "games.sanguosha.skillDesc.quhu",
	jieming: "games.sanguosha.skillDesc.jieming",
	lianhuan: "games.sanguosha.skillDesc.lianhuan",
	niepan: "games.sanguosha.skillDesc.niepan",
	huoji: "games.sanguosha.skillDesc.huoji",
	kanpo: "games.sanguosha.skillDesc.kanpo",
	bazhen: "games.sanguosha.skillDesc.bazhen",
	tianyi: "games.sanguosha.skillDesc.tianyi",
	luanji: "games.sanguosha.skillDesc.luanji",
	xueyi: "games.sanguosha.skillDesc.xueyi",
	shuangxiong: "games.sanguosha.skillDesc.shuangxiong",
	mengjin: "games.sanguosha.skillDesc.mengjin",
	duanliang: "games.sanguosha.skillDesc.duanliang",
	xingshang: "games.sanguosha.skillDesc.xingshang",
	fangzhu: "games.sanguosha.skillDesc.fangzhu",
	songwei: "games.sanguosha.skillDesc.songwei",
	huoshou: "games.sanguosha.skillDesc.huoshou",
	zaiqi: "games.sanguosha.skillDesc.zaiqi",
	juxiang: "games.sanguosha.skillDesc.juxiang",
	lieren: "games.sanguosha.skillDesc.lieren",
	yinghun: "games.sanguosha.skillDesc.yinghun",
	haoshi: "games.sanguosha.skillDesc.haoshi",
	dimeng: "games.sanguosha.skillDesc.dimeng",
	jiuchi: "games.sanguosha.skillDesc.jiuchi",
	roulin: "games.sanguosha.skillDesc.roulin",
	benghuai: "games.sanguosha.skillDesc.benghuai",
	baonue: "games.sanguosha.skillDesc.baonue",
	wansha: "games.sanguosha.skillDesc.wansha",
	luanwu: "games.sanguosha.skillDesc.luanwu",
	weimu: "games.sanguosha.skillDesc.weimu",
	qiaobian: "games.sanguosha.skillDesc.qiaobian",
	tuntian: "games.sanguosha.skillDesc.tuntian",
	zaoxian: "games.sanguosha.skillDesc.zaoxian",
	jixi: "games.sanguosha.skillDesc.jixi",
	tiaoxin: "games.sanguosha.skillDesc.tiaoxin",
	zhiji: "games.sanguosha.skillDesc.zhiji",
	xiangle: "games.sanguosha.skillDesc.xiangle",
	fangquan: "games.sanguosha.skillDesc.fangquan",
	ruoyu: "games.sanguosha.skillDesc.ruoyu",
	jiang: "games.sanguosha.skillDesc.jiang",
	hunzi: "games.sanguosha.skillDesc.hunzi",
	zhiba: "games.sanguosha.skillDesc.zhiba",
	zhijian: "games.sanguosha.skillDesc.zhijian",
	guzheng: "games.sanguosha.skillDesc.guzheng",
	beige: "games.sanguosha.skillDesc.beige",
	duanchang: "games.sanguosha.skillDesc.duanchang",
	botu: "games.sanguosha.skillDesc.botu",
	qingnang: "games.sanguosha.skillDesc.qingnang",
	shebian: "games.sanguosha.skillDesc.shebian",
	moshi: "games.sanguosha.skillDesc.moshi",
	qimou: "games.sanguosha.skillDesc.qimou",
	piaoling: "games.sanguosha.skillDesc.piaoling",
	ninge: "games.sanguosha.skillDesc.ninge",
	cangzhuo: "games.sanguosha.skillDesc.cangzhuo",
	hanzhan: "games.sanguosha.skillDesc.hanzhan",
	jianchu: "games.sanguosha.skillDesc.jianchu",
	jiezi: "games.sanguosha.skillDesc.jiezi",
	wulie: "games.sanguosha.skillDesc.wulie",
	changbiao: "games.sanguosha.skillDesc.changbiao",
	sishu: "games.sanguosha.skillDesc.sishu",
	luoying: "games.sanguosha.skillDesc.luoying",
	jiushi: "games.sanguosha.skillDesc.jiushi",
	rezhenjun: "games.sanguosha.skillDesc.rezhenjun",
	jueqing: "games.sanguosha.skillDesc.jueqing",
	shangshi: "games.sanguosha.skillDesc.shangshi",
	xinxuanhuo: "games.sanguosha.skillDesc.xinxuanhuo",
	xinenyuan: "games.sanguosha.skillDesc.xinenyuan",
	olsanyao: "games.sanguosha.skillDesc.olsanyao",
	rezhiman: "games.sanguosha.skillDesc.rezhiman",
	xinwuyan: "games.sanguosha.skillDesc.xinwuyan",
	xinjujian: "games.sanguosha.skillDesc.xinjujian",
	xinpojun: "games.sanguosha.skillDesc.xinpojun",
	xuanfeng: "games.sanguosha.skillDesc.xuanfeng",
	ganlu: "games.sanguosha.skillDesc.ganlu",
	buyi: "games.sanguosha.skillDesc.buyi",
	mingce: "games.sanguosha.skillDesc.mingce",
	zhichi: "games.sanguosha.skillDesc.zhichi",
	xinxianzhen: "games.sanguosha.skillDesc.xinxianzhen",
	jinjiu: "games.sanguosha.skillDesc.jinjiu",
	zhenlie: "games.sanguosha.skillDesc.zhenlie",
	miji: "games.sanguosha.skillDesc.miji",
	qice: "games.sanguosha.skillDesc.qice",
	zhiyu: "games.sanguosha.skillDesc.zhiyu",
	quanji: "games.sanguosha.skillDesc.quanji",
	zili: "games.sanguosha.skillDesc.zili",
	paiyi: "games.sanguosha.skillDesc.paiyi",
	qianxi: "games.sanguosha.skillDesc.qianxi",
	dangxian: "games.sanguosha.skillDesc.dangxian",
	fuli: "games.sanguosha.skillDesc.fuli",
	fuhun: "games.sanguosha.skillDesc.fuhun",
	old_anxu: "games.sanguosha.skillDesc.old_anxu",
	zhuiyi: "games.sanguosha.skillDesc.zhuiyi",
	gongji: "games.sanguosha.skillDesc.gongji",
	jiefan: "games.sanguosha.skillDesc.jiefan",
	lihuo: "games.sanguosha.skillDesc.lihuo",
	chunlao: "games.sanguosha.skillDesc.chunlao",
	rezishou: "games.sanguosha.skillDesc.rezishou",
	zongshi: "games.sanguosha.skillDesc.zongshi",
	new_jiangchi: "games.sanguosha.skillDesc.new_jiangchi",
	rejingce: "games.sanguosha.skillDesc.rejingce",
	chengxiang: "games.sanguosha.skillDesc.chengxiang",
	renxin: "games.sanguosha.skillDesc.renxin",
	danshou: "games.sanguosha.skillDesc.danshou",
	zhiyan: "games.sanguosha.skillDesc.zhiyan",
	zongxuan: "games.sanguosha.skillDesc.zongxuan",
	qiuyuan: "games.sanguosha.skillDesc.qiuyuan",
	zhuikong: "games.sanguosha.skillDesc.zhuikong",
	qiaoshui: "games.sanguosha.skillDesc.qiaoshui",
	jyzongshi: "games.sanguosha.skillDesc.jyzongshi",
	xiansi: "games.sanguosha.skillDesc.xiansi",
	xiansi2: "games.sanguosha.skillDesc.xiansi2",
	junxing: "games.sanguosha.skillDesc.junxing",
	yuce: "games.sanguosha.skillDesc.yuce",
	duodao: "games.sanguosha.skillDesc.duodao",
	anjian: "games.sanguosha.skillDesc.anjian",
	longyin: "games.sanguosha.skillDesc.longyin",
	xinjuece: "games.sanguosha.skillDesc.xinjuece",
	xinmieji: "games.sanguosha.skillDesc.xinmieji",
	xinfencheng: "games.sanguosha.skillDesc.xinfencheng",
	shenduan: "games.sanguosha.skillDesc.shenduan",
	yonglve: "games.sanguosha.skillDesc.yonglve",
	pindi: "games.sanguosha.skillDesc.pindi",
	faen: "games.sanguosha.skillDesc.faen",
	xinsidi: "games.sanguosha.skillDesc.xinsidi",
	qiangzhi: "games.sanguosha.skillDesc.qiangzhi",
	xiantu: "games.sanguosha.skillDesc.xiantu",
	olbenxi: "games.sanguosha.skillDesc.olbenxi",
	xinzhongyong: "games.sanguosha.skillDesc.xinzhongyong",
	chanhui: "games.sanguosha.skillDesc.chanhui",
	jiaojin: "games.sanguosha.skillDesc.jiaojin",
	fenli: "games.sanguosha.skillDesc.fenli",
	pingkou: "games.sanguosha.skillDesc.pingkou",
	shenxing: "games.sanguosha.skillDesc.shenxing",
	olbingyi: "games.sanguosha.skillDesc.olbingyi",
	jianying: "games.sanguosha.skillDesc.jianying",
	shibei: "games.sanguosha.skillDesc.shibei",
	qieting: "games.sanguosha.skillDesc.qieting",
	xianzhou: "games.sanguosha.skillDesc.xianzhou",
	qianju: "games.sanguosha.skillDesc.qianju",
	qingxi: "games.sanguosha.skillDesc.qingxi",
	huituo: "games.sanguosha.skillDesc.huituo",
	mingjian: "games.sanguosha.skillDesc.mingjian",
	xingshuai: "games.sanguosha.skillDesc.xingshuai",
	huomo: "games.sanguosha.skillDesc.huomo",
	zuoding: "games.sanguosha.skillDesc.zuoding",
	qiaoshi: "games.sanguosha.skillDesc.qiaoshi",
	yanyu: "games.sanguosha.skillDesc.yanyu",
	zhanjue: "games.sanguosha.skillDesc.zhanjue",
	qinwang: "games.sanguosha.skillDesc.qinwang",
	wurong: "games.sanguosha.skillDesc.wurong",
	shizhi: "games.sanguosha.skillDesc.shizhi",
	xinanguo: "games.sanguosha.skillDesc.xinanguo",
	yaoming: "games.sanguosha.skillDesc.yaoming",
	yanzhu: "games.sanguosha.skillDesc.yanzhu",
	xingxue: "games.sanguosha.skillDesc.xingxue",
	xinzhaofu: "games.sanguosha.skillDesc.xinzhaofu",
	huaiyi: "games.sanguosha.skillDesc.huaiyi",
	jigong: "games.sanguosha.skillDesc.jigong",
	shifei: "games.sanguosha.skillDesc.shifei",
	jiaozhao: "games.sanguosha.skillDesc.jiaozhao",
	danxin: "games.sanguosha.skillDesc.danxin",
	guizao: "games.sanguosha.skillDesc.guizao",
	jiyu: "games.sanguosha.skillDesc.jiyu",
	qinqing: "games.sanguosha.skillDesc.qinqing",
	huisheng: "games.sanguosha.skillDesc.huisheng",
	dcduliang: "games.sanguosha.skillDesc.dcduliang",
	fulin: "games.sanguosha.skillDesc.fulin",
	kuangbi: "games.sanguosha.skillDesc.kuangbi",
	jishe: "games.sanguosha.skillDesc.jishe",
	lianhuo: "games.sanguosha.skillDesc.lianhuo",
	taoluan: "games.sanguosha.skillDesc.taoluan",
	zhige: "games.sanguosha.skillDesc.zhige",
	zongzuo: "games.sanguosha.skillDesc.zongzuo",
	zhongjian: "games.sanguosha.skillDesc.zhongjian",
	caishi: "games.sanguosha.skillDesc.caishi",
	qingxian: "games.sanguosha.skillDesc.qingxian",
	canyun: "games.sanguosha.skillDesc.canyun",
	juexiang: "games.sanguosha.skillDesc.juexiang",
	fumian: "games.sanguosha.skillDesc.fumian",
	daiyan: "games.sanguosha.skillDesc.daiyan",
	jianzheng: "games.sanguosha.skillDesc.jianzheng",
	zhuandui: "games.sanguosha.skillDesc.zhuandui",
	tianbian: "games.sanguosha.skillDesc.tianbian",
	funan: "games.sanguosha.skillDesc.funan",
	xinjiexun: "games.sanguosha.skillDesc.xinjiexun",
	wengua: "games.sanguosha.skillDesc.wengua",
	fuzhu: "games.sanguosha.skillDesc.fuzhu",
	shouxi: "games.sanguosha.skillDesc.shouxi",
	huimin: "games.sanguosha.skillDesc.huimin",
	bizhuan: "games.sanguosha.skillDesc.bizhuan",
	tongbo: "games.sanguosha.skillDesc.tongbo",
	re_jianxiong: "games.sanguosha.skillDesc.re_jianxiong",
	re_guicai: "games.sanguosha.skillDesc.re_guicai",
	re_ganglie: "games.sanguosha.skillDesc.re_ganglie",
	re_tuxi: "games.sanguosha.skillDesc.re_tuxi",
	re_luoyi: "games.sanguosha.skillDesc.re_luoyi",
	re_luoshen: "games.sanguosha.skillDesc.re_luoshen",
	re_rende: "games.sanguosha.skillDesc.re_rende",
	re_wusheng: "games.sanguosha.skillDesc.re_wusheng",
	re_yijue: "games.sanguosha.skillDesc.re_yijue",
	re_paoxiao: "games.sanguosha.skillDesc.re_paoxiao",
	re_tishen: "games.sanguosha.skillDesc.re_tishen",
	re_guanxing: "games.sanguosha.skillDesc.re_guanxing",
	re_longdan: "games.sanguosha.skillDesc.re_longdan",
	re_yajiao: "games.sanguosha.skillDesc.re_yajiao",
	re_tieji: "games.sanguosha.skillDesc.re_tieji",
	re_qicai: "games.sanguosha.skillDesc.re_qicai",
	re_zhiheng: "games.sanguosha.skillDesc.re_zhiheng",
	re_jiuyuan: "games.sanguosha.skillDesc.re_jiuyuan",
	re_qixi: "games.sanguosha.skillDesc.re_qixi",
	re_qinxue: "games.sanguosha.skillDesc.re_qinxue",
	re_jieyin: "games.sanguosha.skillDesc.re_jieyin",
	re_jijiu: "games.sanguosha.skillDesc.re_jijiu",
	re_liyu: "games.sanguosha.skillDesc.re_liyu",
	re_lijian: "games.sanguosha.skillDesc.re_lijian",
	re_biyue: "games.sanguosha.skillDesc.re_biyue",
	re_shensu: "games.sanguosha.skillDesc.re_shensu",
	re_jushou: "games.sanguosha.skillDesc.re_jushou",
	re_jiewei: "games.sanguosha.skillDesc.re_jiewei",
	re_liegong: "games.sanguosha.skillDesc.re_liegong",
	re_kuanggu: "games.sanguosha.skillDesc.re_kuanggu",
	re_tianxiang: "games.sanguosha.skillDesc.re_tianxiang",
	re_hongyan: "games.sanguosha.skillDesc.re_hongyan",
	re_leiji: "games.sanguosha.skillDesc.re_leiji",
	re_guidao: "games.sanguosha.skillDesc.re_guidao",
	re_huangtian: "games.sanguosha.skillDesc.re_huangtian",
	re_qiangxi: "games.sanguosha.skillDesc.re_qiangxi",
	re_jieming: "games.sanguosha.skillDesc.re_jieming",
	re_lianhuan: "games.sanguosha.skillDesc.re_lianhuan",
	re_niepan: "games.sanguosha.skillDesc.re_niepan",
	re_huoji: "games.sanguosha.skillDesc.re_huoji",
	re_kanpo: "games.sanguosha.skillDesc.re_kanpo",
	re_luanji: "games.sanguosha.skillDesc.re_luanji",
	re_xueyi: "games.sanguosha.skillDesc.re_xueyi",
	re_shuangxiong: "games.sanguosha.skillDesc.re_shuangxiong",
	re_duanliang: "games.sanguosha.skillDesc.re_duanliang",
	re_xingshang: "games.sanguosha.skillDesc.re_xingshang",
	re_fangzhu: "games.sanguosha.skillDesc.re_fangzhu",
	re_zaiqi: "games.sanguosha.skillDesc.re_zaiqi",
	re_jiuchi: "games.sanguosha.skillDesc.re_jiuchi",
	re_baonue: "games.sanguosha.skillDesc.re_baonue",
	re_wansha: "games.sanguosha.skillDesc.re_wansha",
	re_luanwu: "games.sanguosha.skillDesc.re_luanwu",
	re_weimu: "games.sanguosha.skillDesc.re_weimu",
	re_qiaobian: "games.sanguosha.skillDesc.re_qiaobian",
	re_tuntian: "games.sanguosha.skillDesc.re_tuntian",
	re_zaoxian: "games.sanguosha.skillDesc.re_zaoxian",
	re_tiaoxin: "games.sanguosha.skillDesc.re_tiaoxin",
	re_zhiji: "games.sanguosha.skillDesc.re_zhiji",
	re_fangquan: "games.sanguosha.skillDesc.re_fangquan",
	re_ruoyu: "games.sanguosha.skillDesc.re_ruoyu",
	re_jiang: "games.sanguosha.skillDesc.re_jiang",
	re_hunzi: "games.sanguosha.skillDesc.re_hunzi",
	re_zhiba: "games.sanguosha.skillDesc.re_zhiba",
	re_zhijian: "games.sanguosha.skillDesc.re_zhijian",
	re_guzheng: "games.sanguosha.skillDesc.re_guzheng",
	re_beige: "games.sanguosha.skillDesc.re_beige"
}, Dx = {
	slash: "games.sanguosha.card.slash",
	jink: "games.sanguosha.card.jink",
	peach: "games.sanguosha.card.peach",
	duel: "games.sanguosha.card.duel",
	savage_assault: "games.sanguosha.card.savage_assault",
	archery_attack: "games.sanguosha.card.archery_attack",
	amazing_grace: "games.sanguosha.card.amazing_grace",
	god_salvation: "games.sanguosha.card.god_salvation",
	ex_nihilo: "games.sanguosha.card.ex_nihilo",
	snatch: "games.sanguosha.card.snatch",
	dismantlement: "games.sanguosha.card.dismantlement",
	collateral: "games.sanguosha.card.collateral",
	nullification: "games.sanguosha.card.nullification",
	indulgence: "games.sanguosha.card.indulgence",
	lightning: "games.sanguosha.card.lightning",
	crossbow: "games.sanguosha.card.crossbow",
	double_sword: "games.sanguosha.card.double_sword",
	qinggang_sword: "games.sanguosha.card.qinggang_sword",
	blade: "games.sanguosha.card.blade",
	spear: "games.sanguosha.card.spear",
	axe: "games.sanguosha.card.axe",
	halberd: "games.sanguosha.card.halberd",
	kylin_bow: "games.sanguosha.card.kylin_bow",
	ice_sword: "games.sanguosha.card.ice_sword",
	eight_diagram: "games.sanguosha.card.eight_diagram",
	renwang_shield: "games.sanguosha.card.renwang_shield",
	jueying: "games.sanguosha.card.jueying",
	dilu: "games.sanguosha.card.dilu",
	zhuahuangfeidian: "games.sanguosha.card.zhuahuangfeidian",
	chitu: "games.sanguosha.card.chitu",
	dayuan: "games.sanguosha.card.dayuan",
	zixing: "games.sanguosha.card.zixing",
	fire_slash: "games.sanguosha.card.fire_slash",
	thunder_slash: "games.sanguosha.card.thunder_slash",
	analeptic: "games.sanguosha.card.analeptic",
	fire_attack: "games.sanguosha.card.fire_attack",
	iron_chain: "games.sanguosha.card.iron_chain",
	supply_shortage: "games.sanguosha.card.supply_shortage",
	guding_blade: "games.sanguosha.card.guding_blade",
	fan: "games.sanguosha.card.fan",
	vine: "games.sanguosha.card.vine",
	silver_lion: "games.sanguosha.card.silver_lion",
	hualiu: "games.sanguosha.card.hualiu"
}, Ox = {
	crossbow: "games.sanguosha.cardDesc.crossbow",
	double_sword: "games.sanguosha.cardDesc.double_sword",
	qinggang_sword: "games.sanguosha.cardDesc.qinggang_sword",
	blade: "games.sanguosha.cardDesc.blade",
	spear: "games.sanguosha.cardDesc.spear",
	axe: "games.sanguosha.cardDesc.axe",
	halberd: "games.sanguosha.cardDesc.halberd",
	kylin_bow: "games.sanguosha.cardDesc.kylin_bow",
	ice_sword: "games.sanguosha.cardDesc.ice_sword",
	guding_blade: "games.sanguosha.cardDesc.guding_blade",
	fan: "games.sanguosha.cardDesc.fan",
	eight_diagram: "games.sanguosha.cardDesc.eight_diagram",
	renwang_shield: "games.sanguosha.cardDesc.renwang_shield",
	vine: "games.sanguosha.cardDesc.vine",
	silver_lion: "games.sanguosha.cardDesc.silver_lion",
	jueying: "games.sanguosha.cardDesc.defHorse",
	dilu: "games.sanguosha.cardDesc.defHorse",
	zhuahuangfeidian: "games.sanguosha.cardDesc.defHorse",
	hualiu: "games.sanguosha.cardDesc.defHorse",
	chitu: "games.sanguosha.cardDesc.offHorse",
	dayuan: "games.sanguosha.cardDesc.offHorse",
	zixing: "games.sanguosha.cardDesc.offHorse",
	indulgence: "games.sanguosha.cardDesc.indulgence",
	supply_shortage: "games.sanguosha.cardDesc.supply_shortage",
	lightning: "games.sanguosha.cardDesc.lightning"
}, kx = {
	caocao: "games.sanguosha.general.caocao",
	simayi: "games.sanguosha.general.simayi",
	xiahoudun: "games.sanguosha.general.xiahoudun",
	zhangliao: "games.sanguosha.general.zhangliao",
	xuchu: "games.sanguosha.general.xuchu",
	guojia: "games.sanguosha.general.guojia",
	zhenji: "games.sanguosha.general.zhenji",
	liubei: "games.sanguosha.general.liubei",
	guanyu: "games.sanguosha.general.guanyu",
	zhangfei: "games.sanguosha.general.zhangfei",
	zhugeliang: "games.sanguosha.general.zhugeliang",
	zhaoyun: "games.sanguosha.general.zhaoyun",
	machao: "games.sanguosha.general.machao",
	huangyueying: "games.sanguosha.general.huangyueying",
	sunquan: "games.sanguosha.general.sunquan",
	ganning: "games.sanguosha.general.ganning",
	lvmeng: "games.sanguosha.general.lvmeng",
	huanggai: "games.sanguosha.general.huanggai",
	zhouyu: "games.sanguosha.general.zhouyu",
	daqiao: "games.sanguosha.general.daqiao",
	luxun: "games.sanguosha.general.luxun",
	sunshangxiang: "games.sanguosha.general.sunshangxiang",
	huatuo: "games.sanguosha.general.huatuo",
	lvbu: "games.sanguosha.general.lvbu",
	diaochan: "games.sanguosha.general.diaochan",
	xiahouyuan: "games.sanguosha.general.xiahouyuan",
	caoren: "games.sanguosha.general.caoren",
	huangzhong: "games.sanguosha.general.huangzhong",
	weiyan: "games.sanguosha.general.weiyan",
	xiaoqiao: "games.sanguosha.general.xiaoqiao",
	zhoutai: "games.sanguosha.general.zhoutai",
	zhangjiao: "games.sanguosha.general.zhangjiao",
	yuji: "games.sanguosha.general.yuji",
	dianwei: "games.sanguosha.general.dianwei",
	xunyu: "games.sanguosha.general.xunyu",
	pangtong: "games.sanguosha.general.pangtong",
	wolong: "games.sanguosha.general.wolong",
	taishici: "games.sanguosha.general.taishici",
	yuanshao: "games.sanguosha.general.yuanshao",
	yanliangwenchou: "games.sanguosha.general.yanliangwenchou",
	pangde: "games.sanguosha.general.pangde",
	xuhuang: "games.sanguosha.general.xuhuang",
	caopi: "games.sanguosha.general.caopi",
	menghuo: "games.sanguosha.general.menghuo",
	zhurong: "games.sanguosha.general.zhurong",
	sunjian: "games.sanguosha.general.sunjian",
	lusu: "games.sanguosha.general.lusu",
	dongzhuo: "games.sanguosha.general.dongzhuo",
	jiaxu: "games.sanguosha.general.jiaxu",
	zhanghe: "games.sanguosha.general.zhanghe",
	dengai: "games.sanguosha.general.dengai",
	jiangwei: "games.sanguosha.general.jiangwei",
	liushan: "games.sanguosha.general.liushan",
	sunce: "games.sanguosha.general.sunce",
	erzhang: "games.sanguosha.general.erzhang",
	zuoci: "games.sanguosha.general.zuoci",
	caiwenji: "games.sanguosha.general.caiwenji",
	caozhi: "games.sanguosha.general.caozhi",
	yujin: "games.sanguosha.general.yujin",
	zhangchunhua: "games.sanguosha.general.zhangchunhua",
	xin_fazheng: "games.sanguosha.general.xin_fazheng",
	xin_masu: "games.sanguosha.general.xin_masu",
	xin_xushu: "games.sanguosha.general.xin_xushu",
	xusheng: "games.sanguosha.general.xusheng",
	lingtong: "games.sanguosha.general.lingtong",
	wuguotai: "games.sanguosha.general.wuguotai",
	chengong: "games.sanguosha.general.chengong",
	gaoshun: "games.sanguosha.general.gaoshun",
	wangyi: "games.sanguosha.general.wangyi",
	xunyou: "games.sanguosha.general.xunyou",
	zhonghui: "games.sanguosha.general.zhonghui",
	old_madai: "games.sanguosha.general.old_madai",
	liaohua: "games.sanguosha.general.liaohua",
	guanzhang: "games.sanguosha.general.guanzhang",
	bulianshi: "games.sanguosha.general.bulianshi",
	handang: "games.sanguosha.general.handang",
	chengpu: "games.sanguosha.general.chengpu",
	liubiao: "games.sanguosha.general.liubiao",
	caozhang: "games.sanguosha.general.caozhang",
	manchong: "games.sanguosha.general.manchong",
	guohuai: "games.sanguosha.general.guohuai",
	caochong: "games.sanguosha.general.caochong",
	guanping: "games.sanguosha.general.guanping",
	liufeng: "games.sanguosha.general.liufeng",
	jianyong: "games.sanguosha.general.jianyong",
	yufan: "games.sanguosha.general.yufan",
	panzhangmazhong: "games.sanguosha.general.panzhangmazhong",
	zhuran: "games.sanguosha.general.zhuran",
	xin_liru: "games.sanguosha.general.xin_liru",
	fuhuanghou: "games.sanguosha.general.fuhuanghou",
	hanhaoshihuan: "games.sanguosha.general.hanhaoshihuan",
	chenqun: "games.sanguosha.general.chenqun",
	caozhen: "games.sanguosha.general.caozhen",
	zhangsong: "games.sanguosha.general.zhangsong",
	wuyi: "games.sanguosha.general.wuyi",
	zhoucang: "games.sanguosha.general.zhoucang",
	zhuhuan: "games.sanguosha.general.zhuhuan",
	guyong: "games.sanguosha.general.guyong",
	sunluban: "games.sanguosha.general.sunluban",
	yj_jushou: "games.sanguosha.general.yj_jushou",
	caifuren: "games.sanguosha.general.caifuren",
	caoxiu: "games.sanguosha.general.caoxiu",
	caorui: "games.sanguosha.general.caorui",
	zhongyao: "games.sanguosha.general.zhongyao",
	xiahoushi: "games.sanguosha.general.xiahoushi",
	liuchen: "games.sanguosha.general.liuchen",
	zhangyi: "games.sanguosha.general.zhangyi",
	zhuzhi: "games.sanguosha.general.zhuzhi",
	quancong: "games.sanguosha.general.quancong",
	sunxiu: "games.sanguosha.general.sunxiu",
	gongsunyuan: "games.sanguosha.general.gongsunyuan",
	guotufengji: "games.sanguosha.general.guotufengji",
	guohuanghou: "games.sanguosha.general.guohuanghou",
	sunziliufang: "games.sanguosha.general.sunziliufang",
	huanghao: "games.sanguosha.general.huanghao",
	liyan: "games.sanguosha.general.liyan",
	sundeng: "games.sanguosha.general.sundeng",
	cenhun: "games.sanguosha.general.cenhun",
	zhangrang: "games.sanguosha.general.zhangrang",
	liuyu: "games.sanguosha.general.liuyu",
	xinxianying: "games.sanguosha.general.xinxianying",
	jikang: "games.sanguosha.general.jikang",
	wuxian: "games.sanguosha.general.wuxian",
	qinmi: "games.sanguosha.general.qinmi",
	xuezong: "games.sanguosha.general.xuezong",
	xushi: "games.sanguosha.general.xushi",
	caojie: "games.sanguosha.general.caojie",
	caiyong: "games.sanguosha.general.caiyong",
	re_caocao: "games.sanguosha.general.re_caocao",
	re_simayi: "games.sanguosha.general.re_simayi",
	re_xiahoudun: "games.sanguosha.general.re_xiahoudun",
	re_zhangliao: "games.sanguosha.general.re_zhangliao",
	re_xuchu: "games.sanguosha.general.re_xuchu",
	re_guojia: "games.sanguosha.general.re_guojia",
	re_zhenji: "games.sanguosha.general.re_zhenji",
	re_liubei: "games.sanguosha.general.re_liubei",
	re_guanyu: "games.sanguosha.general.re_guanyu",
	re_zhangfei: "games.sanguosha.general.re_zhangfei",
	re_zhugeliang: "games.sanguosha.general.re_zhugeliang",
	re_zhaoyun: "games.sanguosha.general.re_zhaoyun",
	re_machao: "games.sanguosha.general.re_machao",
	re_huangyueying: "games.sanguosha.general.re_huangyueying",
	re_sunquan: "games.sanguosha.general.re_sunquan",
	re_ganning: "games.sanguosha.general.re_ganning",
	re_lvmeng: "games.sanguosha.general.re_lvmeng",
	re_huanggai: "games.sanguosha.general.re_huanggai",
	re_zhouyu: "games.sanguosha.general.re_zhouyu",
	re_daqiao: "games.sanguosha.general.re_daqiao",
	re_luxun: "games.sanguosha.general.re_luxun",
	re_sunshangxiang: "games.sanguosha.general.re_sunshangxiang",
	re_huatuo: "games.sanguosha.general.re_huatuo",
	re_lvbu: "games.sanguosha.general.re_lvbu",
	re_diaochan: "games.sanguosha.general.re_diaochan",
	re_xiahouyuan: "games.sanguosha.general.re_xiahouyuan",
	re_caoren: "games.sanguosha.general.re_caoren",
	re_huangzhong: "games.sanguosha.general.re_huangzhong",
	re_weiyan: "games.sanguosha.general.re_weiyan",
	re_xiaoqiao: "games.sanguosha.general.re_xiaoqiao",
	re_zhoutai: "games.sanguosha.general.re_zhoutai",
	re_zhangjiao: "games.sanguosha.general.re_zhangjiao",
	re_dianwei: "games.sanguosha.general.re_dianwei",
	re_xunyu: "games.sanguosha.general.re_xunyu",
	re_pangtong: "games.sanguosha.general.re_pangtong",
	re_wolong: "games.sanguosha.general.re_wolong",
	re_taishici: "games.sanguosha.general.re_taishici",
	re_yuanshao: "games.sanguosha.general.re_yuanshao",
	re_yanliangwenchou: "games.sanguosha.general.re_yanliangwenchou",
	re_pangde: "games.sanguosha.general.re_pangde",
	re_xuhuang: "games.sanguosha.general.re_xuhuang",
	re_caopi: "games.sanguosha.general.re_caopi",
	re_menghuo: "games.sanguosha.general.re_menghuo",
	re_zhurong: "games.sanguosha.general.re_zhurong",
	re_sunjian: "games.sanguosha.general.re_sunjian",
	re_lusu: "games.sanguosha.general.re_lusu",
	re_dongzhuo: "games.sanguosha.general.re_dongzhuo",
	re_jiaxu: "games.sanguosha.general.re_jiaxu",
	re_zhanghe: "games.sanguosha.general.re_zhanghe",
	re_dengai: "games.sanguosha.general.re_dengai",
	re_jiangwei: "games.sanguosha.general.re_jiangwei",
	re_liushan: "games.sanguosha.general.re_liushan",
	re_sunce: "games.sanguosha.general.re_sunce",
	re_erzhang: "games.sanguosha.general.re_erzhang",
	re_caiwenji: "games.sanguosha.general.re_caiwenji"
}, Ax = {
	wei: {
		bg: "#3b82f6",
		key: "games.sanguosha.factionWei"
	},
	shu: {
		bg: "#dc2626",
		key: "games.sanguosha.factionShu"
	},
	wu: {
		bg: "#16a34a",
		key: "games.sanguosha.factionWu"
	},
	qun: {
		bg: "#a16207",
		key: "games.sanguosha.factionQun"
	}
}, jx = {
	lord: "games.sanguosha.identityLord",
	loyalist: "games.sanguosha.identityLoyalist",
	rebel: "games.sanguosha.identityRebel",
	renegade: "games.sanguosha.identityRenegade"
}, Mx = {
	judge: "games.sanguosha.phaseJudge",
	draw: "games.sanguosha.phaseDraw",
	play: "games.sanguosha.phasePlay",
	discard: "games.sanguosha.phaseDiscard",
	end: "games.sanguosha.phaseEnd"
}, Nx = {
	spade: "♠",
	heart: "♥",
	club: "♣",
	diamond: "♦"
}, Px = {
	standard: "games.sanguosha.packStandard",
	wind: "games.sanguosha.packWind",
	fire: "games.sanguosha.packFire",
	forest: "games.sanguosha.packForest",
	mountain: "games.sanguosha.packMountain",
	yj2011: "games.sanguosha.packYj2011",
	yj2012: "games.sanguosha.packYj2012",
	yj2013: "games.sanguosha.packYj2013",
	yj2014: "games.sanguosha.packYj2014",
	yj2015: "games.sanguosha.packYj2015",
	yj2016: "games.sanguosha.packYj2016",
	yj2017: "games.sanguosha.packYj2017"
}, Fx = [
	"wei",
	"shu",
	"wu",
	"qun"
], Ix = [
	"standard",
	"wind",
	"fire",
	"forest",
	"mountain",
	"yj2011",
	"yj2012",
	"yj2013",
	"yj2014",
	"yj2015",
	"yj2016",
	"yj2017"
];
function Lx(e) {
	return e === 1 ? "A" : e === 11 ? "J" : e === 12 ? "Q" : e === 13 ? "K" : String(e);
}
function Rx(e, t, n) {
	return e.includes(t) ? e.filter((e) => e !== t) : n === 1 ? [t] : e.length < n ? [...e, t] : e;
}
var zx = {
	setup: "games.sanguosha.log.setup",
	turn: "games.sanguosha.log.turn",
	pick: "games.sanguosha.log.pick",
	deal: "games.sanguosha.log.deal",
	draw: "games.sanguosha.log.draw",
	equip: "games.sanguosha.log.equip",
	use: "games.sanguosha.log.use",
	slash: "games.sanguosha.log.slash",
	jink: "games.sanguosha.log.jink",
	judge: "games.sanguosha.log.judge",
	"lightning-move": "games.sanguosha.log.lightningMove",
	damage: "games.sanguosha.log.damage",
	recover: "games.sanguosha.log.recover",
	death: "games.sanguosha.log.death",
	reward: "games.sanguosha.log.reward",
	punish: "games.sanguosha.log.punish",
	nullify: "games.sanguosha.log.nullify",
	nullified: "games.sanguosha.log.nullified",
	"armor-null": "games.sanguosha.log.armorNull",
	duel: "games.sanguosha.log.duel",
	"respond-slash": "games.sanguosha.log.respondSlash",
	amazing: "games.sanguosha.log.amazing",
	"amazing-take": "games.sanguosha.log.amazingTake",
	snatch: "games.sanguosha.log.snatch",
	dismantle: "games.sanguosha.log.dismantle",
	"collateral-take": "games.sanguosha.log.collateralTake",
	"place-judge": "games.sanguosha.log.placeJudge",
	"god-salvation": "games.sanguosha.log.godSalvation",
	peach: "games.sanguosha.log.peach",
	"peach-save": "games.sanguosha.log.peachSave",
	discard: "games.sanguosha.log.discard",
	"judge-result": "games.sanguosha.log.judgeResult",
	"judge-reveal": "games.sanguosha.log.judgeReveal",
	"lose-hp": "games.sanguosha.log.loseHp",
	skill: "games.sanguosha.log.skill",
	"skill-draw": "games.sanguosha.log.skillDraw",
	"axe-hit": "games.sanguosha.log.axeHit",
	awaken: "games.sanguosha.log.awaken",
	tiandu: "games.sanguosha.log.tiandu",
	luoshen: "games.sanguosha.log.luoshen",
	luoyi: "games.sanguosha.log.luoyi",
	qianxun: "games.sanguosha.log.qianxun",
	"qianxun-back": "games.sanguosha.log.qianxunBack",
	"yajiao-gain": "games.sanguosha.log.yajiaoGain",
	"yajiao-drop": "games.sanguosha.log.yajiaoDrop",
	"jizhi-gain": "games.sanguosha.log.jizhiGain",
	"jizhi-drop": "games.sanguosha.log.jizhiDrop",
	rende: "games.sanguosha.log.rende",
	zhiheng: "games.sanguosha.log.zhiheng",
	chuli: "games.sanguosha.log.chuli",
	jieyin: "games.sanguosha.log.jieyin",
	"guose-break": "games.sanguosha.log.guoseBreak",
	"guose-play": "games.sanguosha.log.guosePlay",
	gongxin: "games.sanguosha.log.gongxin",
	"gongxin-drop": "games.sanguosha.log.gongxinDrop",
	"liyu-take": "games.sanguosha.log.liyuTake",
	yijue: "games.sanguosha.log.yijue",
	"yijue-seal": "games.sanguosha.log.yijueSeal",
	"yiji-gain": "games.sanguosha.log.yijiGain",
	"yiji-give": "games.sanguosha.log.yijiGive",
	kylin: "games.sanguosha.log.kylin",
	"ganglie-drop": "games.sanguosha.log.ganglieDrop",
	qingjian: "games.sanguosha.log.qingjian",
	liuli: "games.sanguosha.log.liuli",
	tuxi: "games.sanguosha.log.tuxi",
	lianying: "games.sanguosha.log.lianying",
	"lord-call": "games.sanguosha.log.lordCall",
	guicai: "games.sanguosha.log.guicai",
	"fanjian-drop": "games.sanguosha.log.fanjianDrop",
	analeptic: "games.sanguosha.log.analeptic",
	recast: "games.sanguosha.log.recast",
	chain: "games.sanguosha.log.chain",
	unchain: "games.sanguosha.log.unchain",
	"fire-attack": "games.sanguosha.log.fireAttack",
	"fire-attack-show": "games.sanguosha.log.fireAttackShow",
	"silver-lion": "games.sanguosha.log.silverLion",
	"turn-over": "games.sanguosha.log.turnOver",
	"turn-back": "games.sanguosha.log.turnBack",
	buqu: "games.sanguosha.log.buqu",
	"buqu-fail": "games.sanguosha.log.buquFail",
	"buqu-clear": "games.sanguosha.log.buquClear",
	tianxiang: "games.sanguosha.log.tianxiang",
	"tianxiang-draw": "games.sanguosha.log.tianxiangDraw",
	guidao: "games.sanguosha.log.guidao",
	huangtian: "games.sanguosha.log.huangtian",
	"jiewei-drop": "games.sanguosha.log.jieweiDrop",
	qiangxi: "games.sanguosha.log.qiangxi",
	quhu: "games.sanguosha.log.quhu",
	"quhu-nowolf": "games.sanguosha.log.quhuNowolf",
	tianyi: "games.sanguosha.log.tianyi",
	"tianyi-win": "games.sanguosha.log.tianyiWin",
	"tianyi-lose": "games.sanguosha.log.tianyiLose",
	"tianyi-extra": "games.sanguosha.log.tianyiExtra",
	"shuangxiong-red": "games.sanguosha.log.shuangxiongRed",
	"shuangxiong-black": "games.sanguosha.log.shuangxiongBlack",
	niepan: "games.sanguosha.log.niepan",
	jieming: "games.sanguosha.log.jieming",
	luanji: "games.sanguosha.log.luanji",
	xingshang: "games.sanguosha.log.xingshang",
	fangzhu: "games.sanguosha.log.fangzhu",
	songwei: "games.sanguosha.log.songwei",
	zaiqi: "games.sanguosha.log.zaiqi",
	lieren: "games.sanguosha.log.lieren",
	"lieren-take": "games.sanguosha.log.lierenTake",
	haoshi: "games.sanguosha.log.haoshi",
	dimeng: "games.sanguosha.log.dimeng",
	baonue: "games.sanguosha.log.baonue",
	"benghuai-max": "games.sanguosha.log.benghuaiMax",
	juxiang: "games.sanguosha.log.juxiang",
	yinghun: "games.sanguosha.log.yinghun",
	tuntian: "games.sanguosha.log.tuntian",
	qiaobian: "games.sanguosha.log.qiaobian",
	"qiaobian-draw": "games.sanguosha.log.qiaobianDraw",
	"qiaobian-move": "games.sanguosha.log.qiaobianMove",
	zhijian: "games.sanguosha.log.zhijian",
	guzheng: "games.sanguosha.log.guzheng",
	"guzheng-back": "games.sanguosha.log.guzhengBack",
	beige: "games.sanguosha.log.beige",
	duanchang: "games.sanguosha.log.duanchang",
	fangquan: "games.sanguosha.log.fangquan",
	xiangle: "games.sanguosha.log.xiangle",
	"xiangle-null": "games.sanguosha.log.xiangleNull",
	"zhiba-obtain": "games.sanguosha.log.zhibaObtain",
	zhiba: "games.sanguosha.log.zhiba",
	"jiang-obtain": "games.sanguosha.log.jiangObtain",
	moshi: "games.sanguosha.log.moshi",
	jiezi: "games.sanguosha.log.jiezi",
	"jiezi-mark": "games.sanguosha.log.jieziMark",
	hanzhan: "games.sanguosha.log.hanzhan",
	qingnang: "games.sanguosha.log.qingnang",
	sishu: "games.sanguosha.log.sishu",
	wulie: "games.sanguosha.log.wulie",
	"piaoling-top": "games.sanguosha.log.piaolingTop",
	"piaoling-give": "games.sanguosha.log.piaolingGive",
	luoying: "games.sanguosha.log.luoying",
	pojun: "games.sanguosha.log.pojun",
	"pojun-back": "games.sanguosha.log.pojunBack",
	buyi: "games.sanguosha.log.buyi",
	ganlu: "games.sanguosha.log.ganlu",
	mingce: "games.sanguosha.log.mingce",
	"xuanhuo-take": "games.sanguosha.log.xuanhuoTake",
	"xianzhen-win": "games.sanguosha.log.xianzhenWin",
	"xianzhen-lose": "games.sanguosha.log.xianzhenLose",
	"enyuan-give": "games.sanguosha.log.enyuanGive",
	rezhenjun: "games.sanguosha.log.rezhenjun",
	xuanfeng: "games.sanguosha.log.xuanfeng",
	zhenlie: "games.sanguosha.log.zhenlie",
	fuli: "games.sanguosha.log.fuli",
	"zhiyu-show": "games.sanguosha.log.zhiyu-show",
	jiefan: "games.sanguosha.log.jiefan",
	"chunlao-put": "games.sanguosha.log.chunlao-put",
	"quanji-put": "games.sanguosha.log.quanji-put",
	qianxi: "games.sanguosha.log.qianxi",
	"miji-give": "games.sanguosha.log.miji-give",
	anxu: "games.sanguosha.log.anxu",
	zhuiyi: "games.sanguosha.log.zhuiyi",
	chengxiang: "games.sanguosha.log.chengxiang",
	renxin: "games.sanguosha.log.renxin",
	"qiuyuan-give": "games.sanguosha.log.qiuyuan-give",
	"qiuyuan-become": "games.sanguosha.log.qiuyuan-become",
	"zhuikong-win": "games.sanguosha.log.zhuikong-win",
	"zhuikong-lose": "games.sanguosha.log.zhuikong-lose",
	"qiaoshui-win": "games.sanguosha.log.qiaoshui-win",
	"qiaoshui-lose": "games.sanguosha.log.qiaoshui-lose",
	jyzongshi: "games.sanguosha.log.jyzongshi",
	xiansi: "games.sanguosha.log.xiansi",
	xiansi2: "games.sanguosha.log.xiansi2",
	zhiyan: "games.sanguosha.log.zhiyan",
	danshou: "games.sanguosha.log.danshou",
	"danshou-give": "games.sanguosha.log.danshou-give",
	junxing: "games.sanguosha.log.junxing",
	"junxing-flip": "games.sanguosha.log.junxing-flip",
	"junxing-discard": "games.sanguosha.log.junxing-discard",
	"yuce-show": "games.sanguosha.log.yuce-show",
	"yuce-discard": "games.sanguosha.log.yuce-discard",
	duodao: "games.sanguosha.log.duodao",
	longyin: "games.sanguosha.log.longyin",
	zongxuan: "games.sanguosha.log.zongxuan",
	xinjuece: "games.sanguosha.log.xinjuece",
	xinmieji: "games.sanguosha.log.xinmieji",
	"mieji-discard": "games.sanguosha.log.mieji-discard",
	xinfencheng: "games.sanguosha.log.xinfencheng",
	"fencheng-discard": "games.sanguosha.log.fencheng-discard",
	shenduan: "games.sanguosha.log.shenduan",
	yonglve: "games.sanguosha.log.yonglve",
	"yonglve-draw": "games.sanguosha.log.yonglve-draw",
	pindi: "games.sanguosha.log.pindi",
	"pindi-discard": "games.sanguosha.log.pindi-discard",
	xinsidi: "games.sanguosha.log.xinsidi",
	"sidi-slash": "games.sanguosha.log.sidi-slash",
	qiangzhi: "games.sanguosha.log.qiangzhi",
	"qiangzhi-draw": "games.sanguosha.log.qiangzhi-draw",
	xiantu: "games.sanguosha.log.xiantu",
	"xiantu-hurt": "games.sanguosha.log.xiantu-hurt",
	olbenxi: "games.sanguosha.log.olbenxi",
	xinzhongyong: "games.sanguosha.log.xinzhongyong",
	"zy-slash": "games.sanguosha.log.zy-slash",
	chanhui: "games.sanguosha.log.chanhui",
	"chanhui-extra": "games.sanguosha.log.chanhui-extra",
	"chanhui-give": "games.sanguosha.log.chanhui-give",
	jiaojin: "games.sanguosha.log.jiaojin",
	fenli: "games.sanguosha.log.fenli",
	pingkou: "games.sanguosha.log.pingkou",
	shenxing: "games.sanguosha.log.shenxing",
	olbingyi: "games.sanguosha.log.olbingyi",
	jianying: "games.sanguosha.log.jianying",
	"shibei-recover": "games.sanguosha.log.shibei-recover",
	"shibei-lose": "games.sanguosha.log.shibei-lose",
	"qieting-move": "games.sanguosha.log.qieting-move",
	xianzhou: "games.sanguosha.log.xianzhou",
	"xianzhou-give": "games.sanguosha.log.xianzhou-give",
	"xianzhou-damage": "games.sanguosha.log.xianzhou-damage",
	"qingxi-plus": "games.sanguosha.log.qingxi-plus",
	"qingxi-discard": "games.sanguosha.log.qingxi-discard",
	"yanzhu-give": "games.sanguosha.log.yanzhu-give",
	"yanzhu-discard": "games.sanguosha.log.yanzhu-discard",
	"huaiyi-show": "games.sanguosha.log.huaiyi-show",
	"huaiyi-drop": "games.sanguosha.log.huaiyi-drop",
	"huaiyi-gain": "games.sanguosha.log.huaiyi-gain",
	"wurong-show": "games.sanguosha.log.wurong-show",
	"wurong-gain": "games.sanguosha.log.wurong-gain",
	"xx-put": "games.sanguosha.log.xx-put",
	mingjian: "games.sanguosha.log.mingjian",
	zhanjue: "games.sanguosha.log.zhanjue",
	xinzhaofu: "games.sanguosha.log.xinzhaofu",
	"yaoming-drop": "games.sanguosha.log.yaoming-drop",
	"shifei-discard": "games.sanguosha.log.shifei-discard",
	"zhongjian-show": "games.sanguosha.log.zhongjian-show",
	jianzheng: "games.sanguosha.log.jianzheng",
	zhuandui: "games.sanguosha.log.zhuandui",
	funan: "games.sanguosha.log.funan",
	fuzhu: "games.sanguosha.log.fuzhu",
	"fuzhu-end": "games.sanguosha.log.fuzhu-end",
	shouxi: "games.sanguosha.log.shouxi",
	"shouxi-null": "games.sanguosha.log.shouxi-null",
	"huimin-show": "games.sanguosha.log.huimin-show",
	"huimin-take": "games.sanguosha.log.huimin-take",
	bizhuan: "games.sanguosha.log.bizhuan",
	tongbo: "games.sanguosha.log.tongbo",
	"tongbo-give": "games.sanguosha.log.tongbo-give",
	wengua: "games.sanguosha.log.wengua"
}, Bx = {
	skill: "games.sanguosha.log.detailSkill",
	amazing: "games.sanguosha.log.detailAmazing",
	"amazing-take": "games.sanguosha.log.detailAmazingTake",
	snatch: "games.sanguosha.log.detailSnatch",
	dismantle: "games.sanguosha.log.detailDismantle",
	"collateral-take": "games.sanguosha.log.detailCollateralTake",
	discard: "games.sanguosha.log.detailDiscard",
	"yajiao-gain": "games.sanguosha.log.detailYajiaoGain",
	"yajiao-drop": "games.sanguosha.log.detailYajiaoDrop",
	"jizhi-gain": "games.sanguosha.log.detailJizhiGain",
	"jizhi-drop": "games.sanguosha.log.detailJizhiDrop",
	"gongxin-drop": "games.sanguosha.log.detailGongxinDrop",
	"fire-attack-show": "games.sanguosha.log.detailFireAttackShow",
	guicai: "games.sanguosha.log.detailGuicai",
	guidao: "games.sanguosha.log.detailGuidao",
	"jiewei-drop": "games.sanguosha.log.detailJieweiDrop",
	"qiaobian-move": "games.sanguosha.log.detailQiaobianMove",
	guzheng: "games.sanguosha.log.detailGuzheng",
	"guzheng-back": "games.sanguosha.log.detailGuzhengBack",
	"axe-hit": "games.sanguosha.log.detailAxeHit",
	"fire-attack": "games.sanguosha.log.detailFireAttack",
	"ganglie-drop": "games.sanguosha.log.detailGanglieDrop",
	"fanjian-drop": "games.sanguosha.log.detailFanjianDrop",
	xuanfeng: "games.sanguosha.log.detailXuanfeng",
	rezhenjun: "games.sanguosha.log.detailRezhenjun",
	zhenlie: "games.sanguosha.log.detailZhenlie",
	"qingxi-discard": "games.sanguosha.log.detailQingxiDiscard",
	"huaiyi-drop": "games.sanguosha.log.detailHuaiyiDrop",
	"yaoming-drop": "games.sanguosha.log.detailYaomingDrop",
	"junxing-discard": "games.sanguosha.log.detailJunxingDiscard",
	"yuce-discard": "games.sanguosha.log.detailYuceDiscard",
	"mieji-discard": "games.sanguosha.log.detailMiejiDiscard",
	"fencheng-discard": "games.sanguosha.log.detailFenchengDiscard",
	"pindi-discard": "games.sanguosha.log.detailPindiDiscard",
	"shifei-discard": "games.sanguosha.log.detailShifeiDiscard"
}, Vx = {
	pao: "games.sanguosha.markPao",
	yi: "games.sanguosha.markYi",
	bian: "games.sanguosha.markBian",
	lie: "games.sanguosha.markLie",
	zi: "games.sanguosha.markZi",
	sishu: "games.sanguosha.markSishu",
	pojun: "games.sanguosha.markPojun",
	quan: "games.sanguosha.markQuan",
	chun: "games.sanguosha.markChun",
	ni: "games.sanguosha.markNi"
};
function Hx(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ y(Ux, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Ux({ pub: e, priv: t, members: n, myRid: r, send: a }) {
	let o = f(), s = (t) => n.find((n) => n.rid === e.seats[t]?.rid)?.name ?? o(i[0].nameKey), u = (t) => {
		let n = e.seats[t]?.generalId;
		return n ? o(kx[n]) : s(t);
	}, d = (t) => n.find((n) => n.rid === e.seats[t]?.rid)?.avatar ?? 0, p = e.seats.findIndex((e) => e.rid === r), g = t?.act ?? {}, { ref: v } = m("deck"), { ref: te } = m("discard"), { ref: ne } = m("table"), { ref: re, hidden: ie } = m("played"), [x, S] = l(null), [C, w] = l(null), [T, ae] = l(null), [se, ce] = l(null), [le, ue] = l(!1), [de, fe] = l([]), [E, pe] = l([]), [me, he] = l(!1), [ge, _e] = l(null), [ve, ye] = l(null), [be, xe] = l({}), [Se, Ce] = l(null), [we, Te] = l(!1), [Ee, De] = l(!1), [D, Oe] = l(null), ke = c(null), [Ae, je] = l({
		total: 0,
		entries: []
	}), Me = e.logBase + e.log.length, O = Ae.entries;
	Me < Ae.total ? (O = e.log, je({
		total: Me,
		entries: e.log
	})) : Me > Ae.total && (O = [...Ae.entries, ...e.log.slice(Math.max(Ae.total - e.logBase, 0))], je({
		total: Me,
		entries: O
	}));
	let k = [], A = 0;
	for (let t = e.log.length - 1; t >= 0 && A < 3; t--) {
		let n = e.log[t], r = n.kind === "buqu-check" ? 3 : 1;
		if (A + r > 3) break;
		k.push(n), A += r;
	}
	let j = `${e.turn?.seat ?? -1}|${e.turn?.phase ?? ""}|${e.pending?.kind ?? ""}|${e.pending?.asking.join(",") ?? ""}`, [Ne, M] = l(j);
	Ne !== j && (M(j), S(null), w(null), ae(null), ce(null), ue(!1), fe([]), pe([]), Ce(null), Te(!1), Oe(null));
	let Pe = e.pending !== null && e.pending.asking.includes(p), Fe = Pe ? e.pending : null, N = se ? (g.skills ?? []).find((e) => e.id === se) : void 0, Ie = Fe?.kind === "skill-seats" || Fe?.kind === "collateral-target" ? g.choosableSeats ?? [] : [], Le = Ie.length > 0 ? Ie : N ? N.targets : le ? g.serpentSlash?.targets ?? [] : x === null ? [] : g.playable?.[C ? `${x}@${C}` : String(x)]?.targets ?? [], Re = (e) => {
		if (Fe?.kind === "collateral-target") {
			a({
				type: "choose",
				seat: e
			});
			return;
		}
		if (Fe?.kind === "skill-seats") {
			let t = Fe.ctx.max ?? 1;
			pe((n) => Rx(n, e, t));
			return;
		}
		if (N) {
			fe((t) => Rx(t, e, N.maxTargets));
			return;
		}
		ae((t) => t === e ? null : e);
	}, ze = (e) => {
		if (ve?.seat === e) {
			ye(null);
			return;
		}
		let t = ke.current, n = t?.querySelector(`[data-sgs-seat="${e}"]`);
		if (!t || !n) return;
		let r = t.getBoundingClientRect(), i = n.getBoundingClientRect(), a = i.top - r.top + i.height / 2 > r.height / 2;
		ye({
			seat: e,
			left: i.left - r.left + i.width / 2,
			top: a ? i.top - r.top - 6 : i.bottom - r.top + 6,
			above: a
		});
	}, Be = () => {
		if (x === null) return;
		let e = g.playable?.[C ? `${x}@${C}` : String(x)];
		e && (e.needTarget && T === null || (a({
			type: "play",
			cardIds: [x],
			...T === null ? {} : { target: T },
			...C ? { as: C } : {}
		}), S(null), w(null), ae(null)));
	}, Ve = () => {
		N && (E.length < N.minCards || E.length > N.maxCards || de.length < N.minTargets || de.length > N.maxTargets || (a({
			type: "skill",
			skill: N.id,
			cardIds: E,
			targets: de
		}), ce(null), fe([]), pe([])));
	}, He = () => {
		E.length === 2 && T !== null && (a({
			type: "play",
			cardIds: E,
			target: T
		}), ue(!1), ae(null), pe([]));
	}, Ue = "info", We = "";
	if (e.phase === "over") Ue = "done", We = "";
	else if (e.pending) {
		let t = e.pending, n = u(t.asking[0] ?? 0), r = {
			jink: "games.sanguosha.waitingJink",
			"slash-response": "games.sanguosha.waitingSlash",
			"peach-save": "games.sanguosha.waitingPeach",
			nullification: "games.sanguosha.waitingNullification",
			discard: "games.sanguosha.waitingDiscard",
			"amazing-pick": "games.sanguosha.waitingPick",
			"pick-zone": "games.sanguosha.waitingPick",
			"collateral-target": "games.sanguosha.waitingPick",
			"skill-ask": "games.sanguosha.waitingSkill",
			"skill-cards": "games.sanguosha.waitingSkill",
			"skill-seats": "games.sanguosha.waitingSkill",
			"lord-call": "games.sanguosha.waitingSkill",
			guicai: "games.sanguosha.waitingSkill"
		};
		if (Pe) {
			Ue = "accent";
			let e = {
				jink: "games.sanguosha.respondJink",
				"slash-response": "games.sanguosha.respondSlash",
				"peach-save": "games.sanguosha.respondPeach",
				nullification: "games.sanguosha.respondNullification",
				discard: "games.sanguosha.discardPrompt",
				"amazing-pick": "games.sanguosha.amazingPick",
				"pick-zone": "games.sanguosha.pickZone",
				"collateral-target": "games.sanguosha.collateralPick"
			};
			if (t.kind === "skill-ask") {
				let e = t.ctx.skill;
				We = o(Tx[e] ?? "games.sanguosha.waitingSkill");
			} else if (t.kind === "lord-call") We = o(t.ctx.need === "jink" ? "games.sanguosha.lordCallJink" : "games.sanguosha.lordCallSlash");
			else if (t.kind === "guicai") We = o("games.sanguosha.guicaiPrompt");
			else if (t.kind === "skill-cards") {
				let e = t.ctx.min ?? 0, n = t.ctx.max ?? 0;
				We = o(e === n ? "games.sanguosha.skillPickCards" : "games.sanguosha.skillPickCardsUpTo", { n });
			} else if (t.kind === "skill-seats") {
				let e = t.ctx.min ?? 0, n = t.ctx.max ?? 0;
				We = o(e === n ? "games.sanguosha.skillPickSeats" : "games.sanguosha.skillPickSeatsUpTo", { n });
			} else We = o(e[t.kind] ?? "games.sanguosha.waitingPick", { n: t.ctx.count ?? 0 });
		} else We = o(r[t.kind] ?? "games.sanguosha.waitingPick", { name: n });
	} else e.turn?.seat === p && e.turn.phase === "play" ? (Ue = "accent", We = o("games.sanguosha.playPrompt")) : e.turn && (We = o("games.sanguosha.waitingTurn", { name: u(e.turn.seat) }));
	let Ge = e.pending?.kind === "amazing-pick" ? o("games.sanguosha.amazingChip") : e.turn ? o(Mx[e.turn.phase]) : void 0, Ke = e.pending?.kind === "amazing-pick" ? e.pending.ctx.revealed ?? [] : [], qe = e.pending?.kind === "amazing-pick" ? e.pending.ctx.taken ?? {} ?? {} : {}, Je = e.tableCard, Ye = e.seats.map((e, t) => t).sort((t, n) => (t - p + e.seats.length) % e.seats.length - (n - p + e.seats.length) % e.seats.length);
	if (e.phase === "select" || e.phase === "reveal") {
		let n = e.phase === "reveal", r = g.candidates ?? [], i = r.includes(Se ?? "") ? Se : r[0] ?? null;
		return /* @__PURE__ */ y("div", {
			className: "sgs-stage",
			children: /* @__PURE__ */ b(ee, {
				adaptive: !0,
				banner: /* @__PURE__ */ y("div", {
					className: "sgs-banner",
					children: /* @__PURE__ */ y(_, {
						tone: "info",
						text: o("games.sanguosha.selectChoosing"),
						chip: o(n ? "games.sanguosha.revealSub" : r.length > 0 ? t?.identity === "lord" ? "games.sanguosha.selectFiveOne" : "games.sanguosha.selectThreeOne" : "games.sanguosha.selectPending")
					})
				}),
				scroll: !1,
				actionsHeight: "sgs-actions-height h-[186px] short:h-28",
				actions: /* @__PURE__ */ y("div", {
					className: "sgs-action-shelf",
					children: !n && /* @__PURE__ */ y(Kx, {
						candidates: r,
						selected: i,
						onSelect: (e) => {
							Ce(e), Te(!0);
						},
						onOpenRoster: () => De(!0)
					})
				}),
				children: [/* @__PURE__ */ y(Gx, {
					pub: e,
					priv: t,
					mySeat: p,
					nameOf: s,
					avatarOf: d,
					candidates: r,
					selected: i,
					reveal: n,
					detailOpen: we,
					onCloseDetail: () => Te(!1),
					onConfirm: () => {
						i && (a({
							type: "pick-general",
							generalId: i
						}), Te(!1));
					}
				}), Ee && /* @__PURE__ */ y(Jx, { onClose: () => De(!1) })]
			})
		});
	}
	return /* @__PURE__ */ y("div", {
		className: "sgs-stage",
		children: /* @__PURE__ */ y(ee, {
			adaptive: !0,
			banner: /* @__PURE__ */ y("div", {
				className: "sgs-banner",
				children: /* @__PURE__ */ y(_, {
					tone: Ue,
					text: We,
					chip: Ge,
					accent: oe.accent
				})
			}),
			actionsHeight: "sgs-actions-height h-[186px] short:h-28",
			actions: /* @__PURE__ */ y("div", {
				className: "sgs-action-shelf",
				children: t && /* @__PURE__ */ y(gS, {
					pub: e,
					priv: t,
					mySeat: p,
					nameOf: u,
					pending: Fe,
					card: x,
					setCard: S,
					asMode: C,
					setAsMode: w,
					target: T,
					setTarget: ae,
					skillSel: se,
					setSkillSel: ce,
					serpentMode: le,
					setSerpentMode: ue,
					targets: de,
					picked: E,
					setPicked: pe,
					confirmPlay: Be,
					confirmSkill: Ve,
					confirmSerpent: He,
					onInfo: Oe,
					send: a
				})
			}),
			children: /* @__PURE__ */ b("div", {
				ref: ke,
				className: "sgs-board",
				children: [
					/* @__PURE__ */ y(Wx, {}),
					/* @__PURE__ */ y(Zx, {
						boardRef: ke,
						targeting: e.targeting
					}),
					/* @__PURE__ */ y("ul", {
						className: "sgs-seats",
						children: Ye.map((n) => /* @__PURE__ */ y(rS, {
							pub: e,
							seat: n,
							name: s(n),
							avatar: d(n),
							position: Xx((n - p + e.seats.length) % e.seats.length, e.seats.length),
							relative: (n - p + e.seats.length) % e.seats.length,
							count: e.seats.length,
							self: n === p,
							identity: n === p ? t?.identity ?? null : null,
							guess: n === p || e.seats[n].identity ? null : be[n] ?? null,
							judging: e.judging?.seat === n ? e.judging : null,
							waitIcon: tS(e, n),
							picking: Le.includes(n),
							picked: Fe?.kind === "skill-seats" ? E.includes(n) : N ? de.includes(n) : T === n,
							onPick: () => Re(n),
							onInspect: () => _e(n),
							canGuess: n !== p && !e.seats[n].identity,
							onQuickGuess: () => ze(n)
						}, e.seats[n].rid))
					}),
					/* @__PURE__ */ b("div", {
						className: "sgs-battlefield",
						ref: ne,
						children: [/* @__PURE__ */ b("div", {
							className: `sgs-battlefield-top ${Ke.length > 0 ? "sgs-battlefield-top-hidden" : ""}`,
							children: [/* @__PURE__ */ b("span", {
								ref: v,
								className: "sgs-pile sgs-pile-deck",
								"aria-label": o("games.sanguosha.deckCount", { n: e.deckCount }),
								children: [/* @__PURE__ */ y("span", {
									className: "sgs-card-back",
									children: "◇"
								}), /* @__PURE__ */ y("b", { children: o("games.sanguosha.deckCount", { n: e.deckCount }) })]
							}), /* @__PURE__ */ b("span", {
								className: "sgs-pile sgs-pile-discard",
								ref: te,
								"aria-label": o("games.sanguosha.discardCount", { n: e.discardCount }),
								children: [e.discardTop ? /* @__PURE__ */ y(sS, { card: e.discardTop }) : /* @__PURE__ */ y("span", { className: "sgs-empty-card" }), /* @__PURE__ */ y("b", { children: o("games.sanguosha.discardCount", { n: e.discardCount }) })]
							})]
						}), Ke.length > 0 ? /* @__PURE__ */ b("div", {
							className: "sgs-amazing-well",
							children: [/* @__PURE__ */ y("span", {
								className: "sgs-amazing-label",
								children: o("games.sanguosha.amazingLabel", { n: Ke.length })
							}), /* @__PURE__ */ y("div", {
								className: "sgs-amazing-grid",
								"aria-label": o("games.sanguosha.amazingPick"),
								children: Ke.map((e) => {
									let t = qe[e.id];
									return t == null ? /* @__PURE__ */ y(cS, {
										card: e,
										selected: E[0] === e.id,
										onClick: Pe ? () => pe([e.id]) : void 0
									}, e.id) : /* @__PURE__ */ b("span", {
										className: "sgs-amazing-taken",
										children: [/* @__PURE__ */ y(cS, { card: e }), /* @__PURE__ */ y("b", { children: u(t) })]
									}, e.id);
								})
							})]
						}) : Je ? /* @__PURE__ */ b("div", {
							ref: re,
							className: "sgs-played-card",
							style: ie ? { visibility: "hidden" } : void 0,
							children: [/* @__PURE__ */ y(cS, { card: {
								...Je.card,
								name: Je.name
							} }), /* @__PURE__ */ y("span", {
								className: "sgs-played-by",
								children: u(Je.from)
							})]
						}, `${Je.card.id}-${Je.from}`) : /* @__PURE__ */ y("div", {
							className: "sgs-table-empty",
							"aria-hidden": "true",
							children: "◆"
						})]
					}),
					/* @__PURE__ */ b("button", {
						type: "button",
						className: "sgs-log-preview",
						onClick: () => he(!0),
						"aria-label": o("games.sanguosha.viewAllLog"),
						children: [/* @__PURE__ */ y("ul", { children: k.map((e, t) => /* @__PURE__ */ y(yS, {
							entry: e,
							nameOf: u
						}, t)) }), /* @__PURE__ */ y("span", { children: o("games.sanguosha.viewAllShort") })]
					}),
					me && /* @__PURE__ */ y("div", {
						className: "sgs-panel-shade",
						onClick: () => he(!1),
						children: /* @__PURE__ */ b("section", {
							className: "sgs-log-panel",
							onClick: (e) => e.stopPropagation(),
							children: [/* @__PURE__ */ y("button", {
								type: "button",
								className: "sgs-panel-close",
								onClick: () => he(!1),
								"aria-label": o("games.sanguosha.close"),
								children: /* @__PURE__ */ y(h, { className: "size-4" })
							}), /* @__PURE__ */ y("ul", { children: O.slice().reverse().map((e, t) => /* @__PURE__ */ y(yS, {
								entry: e,
								nameOf: u
							}, t)) })]
						})
					}),
					Fe?.kind === "nullification" && t && /* @__PURE__ */ y(hS, {
						pub: e,
						priv: t,
						displayOf: u,
						send: a
					}),
					D && /* @__PURE__ */ y(pS, {
						info: D,
						onClose: () => Oe(null)
					}),
					ve && /* @__PURE__ */ y(fS, {
						anchor: ve,
						value: be[ve.seat] ?? null,
						onPick: (e) => {
							xe((t) => {
								let n = { ...t };
								return e ? n[ve.seat] = e : delete n[ve.seat], n;
							}), ye(null);
						}
					}),
					ge !== null && /* @__PURE__ */ y(iS, {
						pub: e,
						seat: ge,
						name: u(ge),
						self: ge === p,
						guess: be[ge] ?? null,
						onGuess: (e) => xe((t) => {
							let n = { ...t };
							return e ? n[ge] = e : delete n[ge], n;
						}),
						onClose: () => _e(null)
					})
				]
			})
		})
	});
}
function Wx() {
	return /* @__PURE__ */ b("svg", {
		className: "sgs-board-ornament",
		viewBox: "0 0 359 538",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ y("path", {
				d: "M16 15h17v5h-8v6h-9m327-11h-17v5h8v6h9M16 520h17v-5h-8v-6h-9m327 11h-17v-5h8v-6h9",
				className: "sgs-board-corner"
			}),
			/* @__PURE__ */ y("path", {
				d: "M16 35c17-9 34-9 51 0m225 0c17-9 34-9 51 0M16 500c17 9 34 9 51 0m225 0c17 9 34 9 51 0",
				className: "sgs-board-flourish"
			}),
			/* @__PURE__ */ y("path", {
				d: "M108 143C130 126 222 126 246 143M108 392C131 409 224 409 246 392M104 180C87 231 87 311 104 358M254 180C271 231 271 311 254 358",
				className: "sgs-board-dots"
			})
		]
	});
}
function Gx({ pub: e, priv: t, mySeat: n, nameOf: r, avatarOf: i, candidates: a, selected: o, reveal: s = !1, detailOpen: c, onCloseDetail: l, onConfirm: u }) {
	let d = f(), p = e.seats.findIndex((e) => e.identity === "lord"), m = e.seats[p]?.generalId, h = a.length > 0, g = s ? "games.sanguosha.revealCenter" : h ? t?.identity === "lord" ? "games.sanguosha.selectLordCenter" : "games.sanguosha.selectOtherCenter" : m ? "games.sanguosha.selectWaitOthersCenter" : "games.sanguosha.selectWaitLordCenter", _ = s ? "games.sanguosha.revealSub" : h ? t?.identity === "lord" ? "games.sanguosha.selectFiveOne" : "games.sanguosha.selectThreeOne" : "games.sanguosha.selectPending", ee = e.seats.map((e, t) => t).sort((t, r) => (t - n + e.seats.length) % e.seats.length - (r - n + e.seats.length) % e.seats.length);
	return /* @__PURE__ */ b("div", {
		className: "sgs-board sgs-select-board",
		children: [
			/* @__PURE__ */ y(Wx, {}),
			/* @__PURE__ */ b("div", {
				className: "sgs-battlefield sgs-select-battlefield",
				children: [
					/* @__PURE__ */ y("span", {
						className: "sgs-pile sgs-pile-deck",
						"aria-hidden": "true",
						children: /* @__PURE__ */ y("span", {
							className: "sgs-card-back",
							children: "◇"
						})
					}),
					/* @__PURE__ */ y("span", {
						className: "sgs-pile sgs-pile-discard sgs-select-discard",
						"aria-hidden": "true",
						children: /* @__PURE__ */ y("span", { className: "sgs-empty-card" })
					}),
					/* @__PURE__ */ b("div", {
						className: "sgs-select-center",
						role: "status",
						children: [/* @__PURE__ */ y("strong", { children: d(g) }), /* @__PURE__ */ y("span", { children: d(_) })]
					})
				]
			}),
			/* @__PURE__ */ y("ul", {
				className: "sgs-seats",
				children: ee.map((a) => {
					let o = e.seats[a], s = n < 0 ? a : (a - n + e.seats.length) % e.seats.length, c = a === n;
					return /* @__PURE__ */ y(rS, {
						pub: e,
						seat: a,
						name: r(a),
						avatar: i(a),
						position: Xx(s, e.seats.length),
						relative: s,
						count: e.seats.length,
						self: c,
						identity: c ? t?.identity ?? null : null,
						selectMode: !0
					}, o.rid);
				})
			}),
			c && o && /* @__PURE__ */ y(qx, {
				id: o,
				lord: t?.identity === "lord",
				onClose: l,
				onConfirm: u
			})
		]
	});
}
function Kx({ candidates: e, selected: t, onSelect: n, onOpenRoster: r }) {
	let i = f();
	return /* @__PURE__ */ b("div", {
		className: "sgs-select-actions",
		children: [/* @__PURE__ */ b("div", {
			className: "sgs-select-actions-head",
			children: [/* @__PURE__ */ y("span", {
				className: "sgs-select-actions-label",
				children: i("games.sanguosha.selectCandidates")
			}), /* @__PURE__ */ y("button", {
				type: "button",
				className: "sgs-roster-open",
				onClick: r,
				children: i("games.sanguosha.allGenerals")
			})]
		}), /* @__PURE__ */ y("div", {
			className: "sgs-select-candidates",
			children: e.length === 0 ? Array.from({ length: 3 }, (e, t) => /* @__PURE__ */ y("span", {
				className: "sgs-select-card-back",
				"aria-hidden": "true",
				children: i("games.sanguosha.selectGeneralBack")
			}, t)) : e.map((e) => {
				let r = Fe.get(e);
				if (!r) return null;
				let a = Ax[r.faction], o = e === t;
				return /* @__PURE__ */ b("button", {
					type: "button",
					className: `sgs-select-candidate ${o ? "sgs-select-candidate-chosen" : ""}`,
					"aria-pressed": o,
					"aria-label": i("games.sanguosha.selectCandidateAria", { name: i(kx[e]) }),
					onClick: () => n(e),
					children: [
						/* @__PURE__ */ y("span", {
							className: "sgs-select-faction",
							style: { background: a.bg },
							children: i(a.key)
						}),
						/* @__PURE__ */ y("strong", { children: i(kx[e]) }),
						/* @__PURE__ */ y(aS, {
							hp: r.hp,
							max: r.hp
						})
					]
				}, e);
			})
		})]
	});
}
function qx({ id: e, lord: t, onClose: n, onConfirm: r }) {
	let i = f(), a = Fe.get(e);
	if (!a) return null;
	let o = Ax[a.faction];
	return /* @__PURE__ */ y("div", {
		className: "sgs-select-detail-shade",
		onClick: n,
		children: /* @__PURE__ */ b("section", {
			className: "sgs-select-detail",
			onClick: (e) => e.stopPropagation(),
			"aria-label": i(kx[e]),
			children: [
				/* @__PURE__ */ b("div", {
					className: "sgs-select-detail-heading",
					style: { borderColor: o.bg },
					children: [/* @__PURE__ */ y("span", {
						className: "sgs-select-faction",
						style: { background: o.bg },
						children: i(o.key)
					}), /* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y("strong", { children: i(kx[e]) }), /* @__PURE__ */ y("span", { children: i(t ? "games.sanguosha.selectHpLord" : "games.sanguosha.selectHp", { n: a.hp }) })] })]
				}),
				/* @__PURE__ */ y("div", {
					className: "sgs-select-detail-skills",
					children: a.skills.map((e) => /* @__PURE__ */ b("div", {
						className: "sgs-select-detail-skill",
						children: [/* @__PURE__ */ b("strong", { children: [i(Tx[e]), a.lordSkill === e && /* @__PURE__ */ b("span", { children: [" · ", i("games.sanguosha.selectLordSkill")] })] }), /* @__PURE__ */ y("p", { children: i(Ex[e]) })]
					}, e))
				}),
				/* @__PURE__ */ y("button", {
					type: "button",
					className: "sgs-select-detail-close",
					onClick: r,
					children: i("games.sanguosha.confirm")
				})
			]
		})
	});
}
function Jx({ onClose: e }) {
	let t = f(), [n, r] = l(null), [i, a] = l(null), o = Fx.filter((e) => !n || e === n).map((e) => ({
		faction: e,
		list: Pe.filter((t) => t.faction === e && oy(t) && (!i || t.pack === i))
	})).filter(({ list: e }) => e.length > 0);
	return /* @__PURE__ */ y("div", {
		className: "sgs-roster-shade",
		onClick: e,
		children: /* @__PURE__ */ b("section", {
			className: "sgs-roster-sheet",
			role: "dialog",
			"aria-label": t("games.sanguosha.allGeneralsTitle"),
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ b("div", {
					className: "sgs-roster-head",
					children: [/* @__PURE__ */ y("strong", { children: t("games.sanguosha.allGeneralsTitle") }), /* @__PURE__ */ y("button", {
						type: "button",
						className: "sgs-panel-close sgs-roster-close",
						onClick: e,
						"aria-label": t("games.sanguosha.close"),
						children: /* @__PURE__ */ y(h, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ b("div", {
					className: "sgs-roster-filters",
					children: [/* @__PURE__ */ b("div", {
						className: "sgs-roster-filter-row",
						role: "group",
						"aria-label": t("games.sanguosha.rosterFilterFaction"),
						children: [/* @__PURE__ */ y("span", {
							className: "sgs-roster-filter-label",
							children: t("games.sanguosha.rosterFilterFaction")
						}), /* @__PURE__ */ b("div", {
							className: "sgs-roster-filter-chips",
							children: [/* @__PURE__ */ y("button", {
								type: "button",
								className: `sgs-roster-chip ${n ? "" : "sgs-roster-chip-active"}`,
								"aria-pressed": !n,
								onClick: () => r(null),
								children: t("games.sanguosha.rosterFilterAll")
							}), Fx.map((e) => {
								let i = Ax[e], a = n === e;
								return /* @__PURE__ */ y("button", {
									type: "button",
									className: `sgs-roster-chip ${a ? "sgs-roster-chip-active" : ""}`,
									style: a ? {
										borderColor: i.bg,
										background: i.bg
									} : void 0,
									"aria-pressed": a,
									onClick: () => r(e),
									children: t(i.key)
								}, e);
							})]
						})]
					}), /* @__PURE__ */ b("div", {
						className: "sgs-roster-filter-row",
						role: "group",
						"aria-label": t("games.sanguosha.rosterFilterPack"),
						children: [/* @__PURE__ */ y("span", {
							className: "sgs-roster-filter-label",
							children: t("games.sanguosha.rosterFilterPack")
						}), /* @__PURE__ */ b("div", {
							className: "sgs-roster-filter-chips",
							children: [/* @__PURE__ */ y("button", {
								type: "button",
								className: `sgs-roster-chip ${i ? "" : "sgs-roster-chip-active"}`,
								"aria-pressed": !i,
								onClick: () => a(null),
								children: t("games.sanguosha.rosterFilterAll")
							}), Ix.map((e) => {
								let n = i === e;
								return /* @__PURE__ */ y("button", {
									type: "button",
									className: `sgs-roster-chip ${n ? "sgs-roster-chip-active" : ""}`,
									"aria-pressed": n,
									onClick: () => a(e),
									children: t(Px[e])
								}, e);
							})]
						})]
					})]
				}),
				/* @__PURE__ */ b("div", {
					className: "sgs-roster-scroll",
					children: [o.length === 0 && /* @__PURE__ */ y("p", {
						className: "sgs-roster-empty",
						children: t("games.sanguosha.rosterFilterEmpty")
					}), o.map(({ faction: e, list: n }) => {
						let r = Ax[e];
						return /* @__PURE__ */ b("section", {
							className: "sgs-roster-group",
							children: [/* @__PURE__ */ b("h3", {
								className: "sgs-roster-faction",
								children: [/* @__PURE__ */ y("span", {
									className: "sgs-select-faction",
									style: { background: r.bg },
									children: t(r.key)
								}), t("games.sanguosha.allGeneralsCount", { n: n.length })]
							}), /* @__PURE__ */ b("table", {
								className: "sgs-roster-table",
								children: [/* @__PURE__ */ y("thead", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", { children: t("games.sanguosha.rosterColGeneral") }), /* @__PURE__ */ y("th", { children: t("games.sanguosha.rosterColSkills") })] }) }), /* @__PURE__ */ y("tbody", { children: n.map((e) => /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ b("td", {
									className: "sgs-roster-name",
									children: [
										/* @__PURE__ */ b("span", {
											className: "sgs-roster-name-line",
											children: [t(kx[e.id]), e.female && /* @__PURE__ */ y("span", {
												className: "sgs-roster-female",
												title: t("games.sanguosha.genderFemale"),
												children: "♀"
											})]
										}),
										/* @__PURE__ */ y(aS, {
											hp: e.hp,
											max: e.hp
										}),
										/* @__PURE__ */ y("span", {
											className: "sgs-roster-pack",
											children: t(Px[e.pack])
										})
									]
								}), /* @__PURE__ */ y("td", { children: e.skills.map((n) => /* @__PURE__ */ b("div", {
									className: "sgs-roster-skill",
									children: [/* @__PURE__ */ b("strong", { children: [t(Tx[n]), e.lordSkill === n && /* @__PURE__ */ b("span", {
										className: "sgs-roster-lord",
										children: [" · ", t("games.sanguosha.selectLordSkill")]
									})] }), /* @__PURE__ */ y("p", { children: t(Ex[n]) })]
								}, n)) })] }, e.id)) })]
							})]
						}, e);
					})]
				}, `${n ?? "all"}-${i ?? "all"}`)
			]
		})
	});
}
function Yx(e, t) {
	return {
		4: [
			[50, 88],
			[14, 30],
			[50, 13],
			[86, 30]
		],
		5: [
			[50, 88],
			[17, 63],
			[24, 17],
			[76, 17],
			[83, 63]
		],
		6: [
			[50, 88],
			[17, 69],
			[17, 24],
			[50, 14],
			[83, 24],
			[83, 69]
		],
		7: [
			[50, 88],
			[17, 70],
			[17, 31],
			[36, 14],
			[64, 14],
			[83, 31],
			[83, 70]
		],
		8: [
			[50, 88],
			[17, 69],
			[17, 44],
			[17, 15],
			[50, 15],
			[83, 15],
			[83, 44],
			[83, 69]
		]
	}[t]?.[e] ?? [50, 88];
}
function Xx(e, t) {
	return t === 8 ? [
		[80, 88],
		[15, 69],
		[15, 44],
		[20, 15],
		[50, 15],
		[80, 15],
		[85, 44],
		[85, 69]
	][e] : Yx(e, t);
}
function Zx({ boardRef: e, targeting: t }) {
	let [n, r] = l({
		width: 1,
		height: 1,
		paths: []
	});
	return s(() => {
		let n = e.current;
		if (!n || !t) {
			r({
				width: 1,
				height: 1,
				paths: []
			});
			return;
		}
		let i = () => {
			let e = n.getBoundingClientRect(), i = n.querySelector(`[data-sgs-seat="${t.from}"]`);
			if (!i) return;
			let a = i.getBoundingClientRect(), o = a.left + a.width / 2 - e.left, s = a.top + a.height / 2 - e.top, c = t.targets.flatMap((t, r) => {
				let i = n.querySelector(`[data-sgs-seat="${t}"]`);
				if (!i) return [];
				let a = i.getBoundingClientRect(), c = a.left + a.width / 2 - e.left, l = a.top + a.height / 2 - e.top, u = c - o, d = l - s, f = Math.hypot(u, d);
				if (f < 1) return [];
				let p = Math.min(24, f * .08) * (r % 2 == 0 ? 1 : -1), m = (o + c) / 2 - d / f * p, h = (s + l) / 2 + u / f * p, g = Math.hypot(c - m, l - h), _ = (c - m) / g, ee = (l - h) / g, v = c - 17 * _, y = l - 17 * ee, b = -8 * ee, te = 8 * _;
				return [{
					seat: t,
					d: `M ${o} ${s} Q ${m} ${h} ${c} ${l}`,
					arrow: `M ${c} ${l} L ${v + b} ${y + te} L ${v - b} ${y - te} Z`
				}];
			});
			r({
				width: e.width,
				height: e.height,
				paths: c
			});
		};
		i();
		let a = new ResizeObserver(i);
		return a.observe(n), n.querySelectorAll("[data-sgs-seat]").forEach((e) => a.observe(e)), () => a.disconnect();
	}, [e, t]), !t || n.paths.length === 0 ? null : /* @__PURE__ */ b("svg", {
		className: "sgs-target-lines",
		viewBox: `0 0 ${n.width} ${n.height}`,
		"aria-hidden": "true",
		preserveAspectRatio: "none",
		children: [
			/* @__PURE__ */ y("g", {
				className: "sgs-target-shade",
				children: n.paths.map(({ seat: e, d: t }) => /* @__PURE__ */ y("path", { d: t }, e))
			}),
			/* @__PURE__ */ y("g", {
				className: "sgs-target-dashes",
				children: n.paths.map(({ seat: e, d: t }) => /* @__PURE__ */ y("path", { d: t }, e))
			}),
			/* @__PURE__ */ y("g", {
				className: "sgs-target-arrows",
				children: n.paths.map(({ seat: e, arrow: t }) => /* @__PURE__ */ y("path", { d: t }, e))
			})
		]
	});
}
var Qx = {
	indulgence: "games.sanguosha.judgeIconIndulgence",
	supply_shortage: "games.sanguosha.judgeIconSupply",
	lightning: "games.sanguosha.judgeIconLightning"
}, $x = {
	loyalist: "games.sanguosha.guessMarkLoyalist",
	rebel: "games.sanguosha.guessMarkRebel",
	renegade: "games.sanguosha.guessMarkRenegade"
}, eS = {
	jink: "🛡️",
	"slash-response": "🗡️",
	"peach-save": "🍑",
	nullification: "🚫"
};
function tS(e, t) {
	let n = e.pending;
	return !n || !n.asking.includes(t) ? null : n.kind === "lord-call" ? n.ctx.need === "jink" ? "🛡️" : "🗡️" : eS[n.kind] ?? "…";
}
function nS(e) {
	let t = 0;
	for (let n of e) t += n.codePointAt(0) > 11903 ? 1 : .55;
	return Math.max(t, 1);
}
function rS({ pub: e, seat: t, name: n, avatar: r, picking: i = !1, picked: a = !1, onPick: s, self: u = !1, identity: d = null, guess: h = null, judging: g = null, waitIcon: _ = null, selectMode: ee = !1, position: te, relative: ne, count: re, onInspect: ie, canGuess: x = !1, onQuickGuess: S }) {
	let C = f(), w = e.seats[t], T = w.generalId ? Fe.get(w.generalId) : null, ae = e.turn?.seat === t, oe = d ?? w.identity, se = c(w.hp), [ce, le] = l(0);
	o(() => {
		let e = se.current - w.hp;
		if (se.current = w.hp, e <= 0) return;
		le(e);
		let t = window.setTimeout(() => le(0), 1150);
		return () => window.clearTimeout(t);
	}, [w.hp]);
	let { ref: ue } = m(`seat:${t}`), de = /* @__PURE__ */ b(v, { children: [
		w.turnedOver && w.alive && /* @__PURE__ */ y("span", {
			className: "sgs-flip-cover",
			children: C("games.sanguosha.turnedOverMark")
		}),
		(T || ee && oe === "lord") && /* @__PURE__ */ y("span", {
			className: "sgs-seat-faction-bar",
			style: { background: T ? Ax[T.faction].bg : "#c54837" },
			"aria-hidden": "true"
		}),
		(w.judges.length > 0 || g) && /* @__PURE__ */ b("span", {
			className: "sgs-judge-icons",
			"aria-hidden": "true",
			children: [w.judges.map((e) => /* @__PURE__ */ y("span", {
				className: "sgs-judge-icon",
				children: C(Qx[e.name] ?? Dx[e.name])
			}, e.id)), g && /* @__PURE__ */ y("span", {
				className: `sgs-judge-icon sgs-judge-icon-live ${g.result === "hit" ? "sgs-judge-icon-hit" : ""} ${g.result === "miss" ? "sgs-judge-icon-miss" : ""}`,
				children: C(Qx[g.name] ?? Dx[g.name])
			})]
		})
	] }), fe = /* @__PURE__ */ b(v, { children: [
		x && /* @__PURE__ */ y("span", {
			className: "sgs-guess-mark",
			children: h && $x[h] ? C($x[h]) : C("games.sanguosha.guessUnknown")
		}),
		/* @__PURE__ */ y("span", {
			className: "sgs-seat-label",
			children: oe ? `${n} · ${C(jx[oe])}` : n
		}),
		/* @__PURE__ */ y("img", {
			className: "sgs-seat-avatar",
			src: p[r % p.length],
			alt: "",
			draggable: !1
		})
	] }), E = /* @__PURE__ */ b(v, { children: [
		/* @__PURE__ */ b("span", {
			className: "sgs-seat-main",
			children: [/* @__PURE__ */ y("span", {
				className: "sgs-general-name",
				style: { "--sgs-name-units": nS(T ? C(kx[T.id]) : n) },
				children: T ? C(kx[T.id]) : n
			}), /* @__PURE__ */ y("span", {
				className: "sgs-hand-count",
				"aria-label": ee ? void 0 : C("games.sanguosha.handCount", { n: w.handCount }),
				children: ee ? "—" : w.handCount
			})]
		}),
		/* @__PURE__ */ b("span", {
			className: "sgs-seat-health",
			children: [ee && !T ? /* @__PURE__ */ y("span", {
				className: "sgs-select-pending",
				children: C("games.sanguosha.selectPending")
			}) : /* @__PURE__ */ y(aS, {
				hp: ee && T ? T.hp : w.hp,
				max: ee && T ? T.hp : w.maxHp
			}), /* @__PURE__ */ b("span", {
				className: "sgs-seat-flags",
				children: [
					w.chained && /* @__PURE__ */ y("span", {
						title: C("games.sanguosha.chainedMark"),
						children: "⛓"
					}),
					w.chuang.length > 0 && /* @__PURE__ */ y("span", {
						title: C("games.sanguosha.chuangMark", { n: w.chuang.length }),
						children: C("games.sanguosha.chuangMark", { n: w.chuang.length })
					}),
					w.tian.length > 0 && /* @__PURE__ */ y("span", {
						title: C("games.sanguosha.tianMark", { n: w.tian.length }),
						children: C("games.sanguosha.tianMark", { n: w.tian.length })
					}),
					Object.entries(w.marks).filter(([e, t]) => t > 0 && Vx[e]).map(([e, t]) => /* @__PURE__ */ y("span", {
						title: C(Vx[e], { n: t }),
						children: C(Vx[e], { n: t })
					}, e)),
					w.moshi.length > 0 && /* @__PURE__ */ y("span", {
						title: C("games.sanguosha.moshiMark", { n: w.moshi.length }),
						children: C("games.sanguosha.moshiMark", { n: w.moshi.length })
					})
				]
			})]
		}),
		!w.alive && /* @__PURE__ */ y("span", {
			className: "sgs-dead-mark",
			children: C("games.sanguosha.deadMark")
		}),
		/* @__PURE__ */ b("span", {
			className: `sgs-equip-row ${w.equips.weapon ? "sgs-equip-filled" : "sgs-equip-empty"}`,
			children: [/* @__PURE__ */ y("svg", {
				className: "sgs-equip-icon",
				viewBox: "0 0 16 16",
				"aria-hidden": "true",
				children: /* @__PURE__ */ y("path", { d: "m3 12 9-9m-7 10 9-9M2 8l5 5m-5 0 3 1 1-3" })
			}), /* @__PURE__ */ y("span", { children: w.equips.weapon ? C(Dx[w.equips.weapon.name]) : "\xA0" })]
		}),
		/* @__PURE__ */ b("span", {
			className: `sgs-equip-row ${w.equips.armor ? "sgs-equip-filled" : "sgs-equip-empty"}`,
			children: [/* @__PURE__ */ y("svg", {
				className: "sgs-equip-icon",
				viewBox: "0 0 16 16",
				"aria-hidden": "true",
				children: /* @__PURE__ */ y("path", { d: "M3 2h10v5c0 3-2 5-5 7-3-2-5-4-5-7V2Z" })
			}), /* @__PURE__ */ y("span", { children: w.equips.armor ? C(Dx[w.equips.armor.name]) : "\xA0" })]
		}),
		/* @__PURE__ */ b("span", {
			className: "sgs-horse-row",
			children: [/* @__PURE__ */ y("span", {
				className: w.equips.def_horse ? "sgs-equip-filled" : "sgs-equip-empty",
				children: w.equips.def_horse ? C(Dx[w.equips.def_horse.name]) : "\xA0"
			}), /* @__PURE__ */ y("span", {
				className: w.equips.off_horse ? "sgs-equip-filled" : "sgs-equip-empty",
				children: w.equips.off_horse ? C(Dx[w.equips.off_horse.name]) : "\xA0"
			})]
		})
	] }), pe = /* @__PURE__ */ y(v, { children: _ && /* @__PURE__ */ y("span", {
		className: "sgs-wait-badge",
		"aria-hidden": "true",
		children: _
	}) }), me = /* @__PURE__ */ b(v, { children: [
		de,
		/* @__PURE__ */ y("span", {
			className: "sgs-seat-top",
			children: fe
		}),
		E,
		pe
	] }), he = `sgs-seat ${u ? "sgs-seat-self" : ""} ${ae ? "sgs-seat-turn" : ""} ${a ? "sgs-seat-picked" : ""} ${i ? "sgs-seat-picking" : ""} ${_ ? "sgs-seat-waiting" : ""} ${w.alive ? "" : "sgs-seat-dead"}`, ge = `${n} · ${T ? C(kx[T.id]) : n}`, _e = `sgs-seat-shell${ce > 0 ? " sgs-seat-damaged" : ""}`, ve = ce > 0 ? /* @__PURE__ */ b("span", {
		className: "sgs-damage-float",
		role: "status",
		children: ["−", ce]
	}) : null;
	return !ee && !i ? /* @__PURE__ */ y("li", {
		className: "sgs-seat-position",
		style: {
			left: `${te[0]}%`,
			top: `${te[1]}%`,
			"--sgs-wide-left": `${ne * 100 / re}%`,
			"--sgs-wide-top": `${20 + 4.5 * Math.abs(ne - re / 2) ** 2}%`,
			"--sgs-wide-width": `${85 / re}%`
		},
		"data-sgs-seat": t,
		children: /* @__PURE__ */ b("div", {
			className: _e,
			children: [/* @__PURE__ */ b("div", {
				ref: ue,
				className: he,
				children: [
					de,
					/* @__PURE__ */ y("button", {
						type: "button",
						className: "sgs-seat-top",
						"aria-label": x ? `${n} · ${C("games.sanguosha.guessTitle")}` : ge,
						onClick: x && S ? S : ie,
						children: fe
					}),
					/* @__PURE__ */ y("button", {
						type: "button",
						className: "sgs-seat-rest",
						"aria-label": ge,
						onClick: ie,
						children: E
					}),
					pe
				]
			}), ve]
		})
	}) : /* @__PURE__ */ y("li", {
		className: "sgs-seat-position",
		style: {
			left: `${te[0]}%`,
			top: `${te[1]}%`,
			"--sgs-wide-left": `${ne * 100 / re}%`,
			"--sgs-wide-top": `${20 + 4.5 * Math.abs(ne - re / 2) ** 2}%`,
			"--sgs-wide-width": `${85 / re}%`
		},
		"data-sgs-seat": t,
		children: /* @__PURE__ */ b("div", {
			className: _e,
			children: [/* @__PURE__ */ y("button", {
				type: "button",
				ref: ue,
				"aria-label": ge,
				"aria-pressed": a,
				disabled: ee,
				onClick: i && s ? s : ie,
				className: he,
				children: me
			}), ve]
		})
	});
}
function iS({ pub: e, seat: t, name: n, self: r, guess: i, onGuess: a, onClose: o }) {
	let s = f(), c = e.seats[t], u = c.generalId ? Fe.get(c.generalId) : null, [d, p] = l(null), m = Object.values(c.equips).filter((e) => e !== null), g = !r && c.identity === null;
	return /* @__PURE__ */ y("div", {
		className: "sgs-panel-shade",
		onClick: o,
		children: /* @__PURE__ */ b("section", {
			className: "sgs-inspect-panel",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ y("button", {
					type: "button",
					className: "sgs-panel-close",
					onClick: o,
					"aria-label": s("games.sanguosha.close"),
					children: /* @__PURE__ */ y(h, { className: "size-4" })
				}),
				/* @__PURE__ */ b("strong", { children: [u ? s(kx[u.id]) : n, u && u.id.startsWith("re_") && /* @__PURE__ */ y("em", {
					className: "sgs-inspect-jie",
					children: s("games.sanguosha.jieTag")
				})] }),
				u && /* @__PURE__ */ y("div", {
					className: "sgs-inspect-skills",
					children: u.skills.map((e) => /* @__PURE__ */ b("div", {
						className: "sgs-select-detail-skill",
						children: [/* @__PURE__ */ y("strong", { children: s(Tx[e]) }), /* @__PURE__ */ y("p", { children: s(Ex[e]) })]
					}, e))
				}),
				g && /* @__PURE__ */ b("div", {
					className: "sgs-guess-row",
					role: "group",
					"aria-label": s("games.sanguosha.guessTitle"),
					children: [/* @__PURE__ */ y("span", { children: s("games.sanguosha.guessTitle") }), [
						"loyalist",
						"rebel",
						"renegade",
						null
					].map((e) => /* @__PURE__ */ y("button", {
						type: "button",
						"aria-pressed": i === e,
						onClick: () => a(e),
						className: `sgs-guess-option ${i === e ? "sgs-guess-option-on" : ""}`,
						children: s(e ? jx[e] : "games.sanguosha.guessUnknown")
					}, e ?? "none"))]
				}),
				(m.length > 0 || c.judges.length > 0) && /* @__PURE__ */ b("div", {
					className: "sgs-inspect-cards",
					children: [m.map((e) => /* @__PURE__ */ y(cS, {
						card: e,
						onClick: () => p(e)
					}, e.id)), c.judges.map((e) => /* @__PURE__ */ y(cS, {
						card: e,
						onClick: Ox[e.name] ? () => p(e) : void 0
					}, e.id))]
				}),
				d && /* @__PURE__ */ y("div", {
					className: "sgs-equip-info-shade",
					onClick: () => p(null),
					children: /* @__PURE__ */ b("div", {
						className: "sgs-equip-info",
						onClick: (e) => e.stopPropagation(),
						children: [
							/* @__PURE__ */ y(cS, { card: d }),
							/* @__PURE__ */ b("div", {
								className: "sgs-equip-info-text",
								children: [/* @__PURE__ */ y("strong", { children: s(Dx[d.name]) }), /* @__PURE__ */ y("p", { children: s(Ox[d.name] ?? "games.sanguosha.skillTodo") })]
							}),
							/* @__PURE__ */ y("button", {
								type: "button",
								className: "sgs-panel-close",
								onClick: () => p(null),
								"aria-label": s("games.sanguosha.close"),
								children: /* @__PURE__ */ y(h, { className: "size-4" })
							})
						]
					})
				})
			]
		})
	});
}
function aS({ hp: e, max: t }) {
	return /* @__PURE__ */ y("span", {
		"aria-label": `${e}/${t}`,
		className: "sgs-hp-pips",
		children: Array.from({ length: t }, (t, n) => /* @__PURE__ */ y("span", {
			className: n < e ? "sgs-hp-full" : "sgs-hp-empty",
			"aria-hidden": "true",
			children: "♥"
		}, n))
	});
}
function oS(e) {
	return e.length === 1 ? "nlarge" : e.length === 2 ? "nmedium" : "nsmall";
}
function sS({ card: e }) {
	let t = f()(Dx[e.name]);
	return /* @__PURE__ */ b("span", {
		className: `sgs-face sgs-small-card sgs-card-${O(e.name)} sgs-card-name-${e.name} sgs-face-${oS(t)}`,
		children: [
			/* @__PURE__ */ b("span", {
				className: `sgs-face-corner ${e.suit === "heart" || e.suit === "diamond" ? "sgs-suit-red" : ""}`,
				children: [Nx[e.suit], Lx(e.point)]
			}),
			/* @__PURE__ */ y("strong", {
				className: "sgs-face-name",
				children: t
			}),
			/* @__PURE__ */ y("span", {
				className: "sgs-face-band",
				"aria-hidden": "true"
			})
		]
	});
}
function cS({ card: e, selected: t = !1, onClick: n }) {
	let r = f(), i = O(e.name), a = r(Dx[e.name]), o = /* @__PURE__ */ b(v, { children: [
		/* @__PURE__ */ b("span", {
			className: `sgs-face-corner ${e.suit === "heart" || e.suit === "diamond" ? "sgs-suit-red" : ""}`,
			children: [Nx[e.suit], Lx(e.point)]
		}),
		/* @__PURE__ */ y("strong", {
			className: "sgs-face-name",
			children: a
		}),
		/* @__PURE__ */ y("span", {
			className: "sgs-face-band",
			"aria-hidden": "true"
		})
	] }), s = `sgs-face sgs-table-card sgs-card-${i} sgs-card-name-${e.name} sgs-face-${oS(a)} ${t ? "sgs-table-card-selected" : ""}`;
	return n ? /* @__PURE__ */ y("button", {
		type: "button",
		className: s,
		"aria-pressed": t,
		onClick: n,
		children: o
	}) : /* @__PURE__ */ y("div", {
		className: s,
		children: o
	});
}
var lS = {
	equip: "games.sanguosha.zoneTagEquip",
	judge: "games.sanguosha.zoneTagJudge",
	tian: "games.sanguosha.zoneTagTian",
	shown: "games.sanguosha.zoneTagShown"
};
function uS({ card: e, selected: t, disabled: n, tag: r, zone: i, onClick: a }) {
	let o = f()(Dx[e.name]), s = O(e.name), c = e.suit === "heart" || e.suit === "diamond", { ref: l, hidden: u } = m(`hand:${e.id}`);
	return /* @__PURE__ */ b("button", {
		ref: l,
		type: "button",
		disabled: n,
		"aria-pressed": t,
		"aria-label": o,
		onClick: a,
		className: `sgs-face sgs-hand-card sgs-card-${s} sgs-card-name-${e.name} sgs-face-${oS(o)} ${t ? "sgs-hand-card-selected" : ""} ${u ? "invisible" : ""}`,
		children: [
			/* @__PURE__ */ b("span", {
				className: `sgs-face-corner ${c ? "sgs-suit-red" : ""}`,
				children: [Nx[e.suit], Lx(e.point)]
			}),
			/* @__PURE__ */ y("strong", {
				className: "sgs-face-name",
				children: o
			}),
			/* @__PURE__ */ y("span", {
				className: "sgs-face-band",
				"aria-hidden": "true"
			}),
			i && /* @__PURE__ */ y("span", {
				className: "sgs-hand-zone",
				children: i
			}),
			r && /* @__PURE__ */ y("span", {
				className: "absolute -top-2 left-1/2 -translate-x-1/2 rounded bg-ink px-1 text-[10px] leading-4 whitespace-nowrap text-surface",
				children: r
			})
		]
	});
}
function dS(e, t) {
	if (!e.includes("")) return e;
	let n = [], r = /\uE000(\d+)\uE001/g, i = 0;
	for (let o = r.exec(e); o !== null; o = r.exec(e)) {
		o.index > i && n.push(e.slice(i, o.index));
		let s = t[Number(o[1])];
		s != null && n.push(/* @__PURE__ */ y(a, { children: s }, o.index)), i = r.lastIndex;
	}
	return i < e.length && n.push(e.slice(i)), n;
}
function fS({ anchor: e, value: t, onPick: n }) {
	let r = f(), i = c(null);
	return s(() => {
		let t = i.current, n = t?.offsetParent;
		if (!t || !(n instanceof HTMLElement)) return;
		let r = t.offsetWidth / 2, a = Math.min(Math.max(e.left, r + 6), n.clientWidth - r - 6);
		a !== e.left && (t.style.left = `${a}px`);
	}, [e.left]), /* @__PURE__ */ y("section", {
		ref: i,
		className: `sgs-guess-pop ${e.above ? "sgs-guess-pop-above" : ""}`,
		style: {
			left: e.left,
			top: e.top
		},
		role: "group",
		"aria-label": r("games.sanguosha.guessTitle"),
		children: [
			"loyalist",
			"rebel",
			"renegade",
			null
		].map((e) => /* @__PURE__ */ y("button", {
			type: "button",
			"aria-pressed": t === e,
			onClick: () => n(e),
			className: `sgs-guess-option ${t === e ? "sgs-guess-option-on" : ""}`,
			children: r(e ? jx[e] : "games.sanguosha.guessUnknown")
		}, e ?? "none"))
	});
}
function pS({ info: e, onClose: t }) {
	let n = f();
	return /* @__PURE__ */ y("div", {
		className: "sgs-panel-shade",
		onClick: t,
		children: /* @__PURE__ */ b("section", {
			className: "sgs-inspect-panel",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ y("button", {
					type: "button",
					className: "sgs-panel-close",
					onClick: t,
					"aria-label": n("games.sanguosha.close"),
					children: /* @__PURE__ */ y(h, { className: "size-4" })
				}),
				/* @__PURE__ */ y("strong", { children: e.title }),
				/* @__PURE__ */ y("div", {
					className: "sgs-select-detail-skill",
					children: /* @__PURE__ */ y("p", { children: e.desc })
				})
			]
		})
	});
}
function mS({ title: e, controls: t, children: n }) {
	return /* @__PURE__ */ b("div", {
		className: "flex h-full flex-col px-2",
		children: [/* @__PURE__ */ b("div", {
			className: "sgs-action-title",
			children: [/* @__PURE__ */ y("div", {
				className: "sgs-action-hint",
				children: e
			}), t && /* @__PURE__ */ y("div", {
				className: "sgs-action-controls",
				children: t
			})]
		}), /* @__PURE__ */ y("div", {
			className: "flex min-h-0 flex-1 flex-col justify-center",
			children: n
		})]
	});
}
function hS({ pub: e, priv: t, displayOf: n, send: r }) {
	let i = f(), a = e.pending, o = a.ctx.trick, s = typeof a.ctx.from == "number" ? a.ctx.from : null, c = typeof a.ctx.target == "number" ? a.ctx.target : null, l = /* @__PURE__ */ new Map();
	for (let e of t.act.respondable ?? []) l.has(e.cardId) || l.set(e.cardId, e);
	let u = t.hand.filter((e) => l.has(e.id)), d = o in Dx ? i(Dx[o]) : o, p = Ox[o] ? i(Ox[o]) : null;
	return /* @__PURE__ */ y("div", {
		className: "sgs-nullify-shade",
		children: /* @__PURE__ */ b("div", {
			className: "sgs-nullify-panel",
			role: "alertdialog",
			"aria-label": i("games.sanguosha.respondNullification"),
			children: [
				/* @__PURE__ */ y("p", { children: c !== null && c !== s ? i("games.sanguosha.nullifyAskTarget", {
					name: s === null ? "" : n(s),
					target: n(c),
					card: d
				}) : i("games.sanguosha.nullifyAsk", {
					name: s === null ? "" : n(s),
					card: d
				}) }),
				p && /* @__PURE__ */ y("p", {
					className: "sgs-nullify-desc",
					children: p
				}),
				u.length > 0 && /* @__PURE__ */ y("div", {
					className: "sgs-nullify-cards",
					children: u.map((e) => {
						let t = l.get(e.id);
						return /* @__PURE__ */ y(uS, {
							card: e,
							selected: !1,
							disabled: !1,
							tag: t.as ? i("games.sanguosha.convertTag", { card: i(Dx[t.as]) }) : void 0,
							onClick: () => r({
								type: "respond",
								cardId: e.id,
								...t.as ? { as: t.as } : {}
							})
						}, e.id);
					})
				}),
				/* @__PURE__ */ y("button", {
					type: "button",
					onClick: () => r({ type: "respond" }),
					className: "btn-base min-h-11 px-6",
					children: i("games.sanguosha.noNullify")
				})
			]
		})
	});
}
function gS({ pub: e, priv: t, mySeat: n, nameOf: r, pending: i, card: a, setCard: o, asMode: s, setAsMode: c, target: l, setTarget: u, skillSel: d, setSkillSel: p, serpentMode: m, setSerpentMode: h, targets: g, picked: _, setPicked: ee, confirmPlay: te, confirmSkill: ne, confirmSerpent: re, onInfo: ie, send: x }) {
	let S = f(), C = t.act, w = t.hand, T = (e) => {
		let t = e;
		for (; t !== null;) {
			let e = Ex[t] ?? Ox[t], n = Tx[t] ?? Dx[t];
			if (e && n) return {
				title: S(n),
				desc: S(e)
			};
			let r = t.lastIndexOf("-"), i = t.replace(/\d+$/, "");
			t = r > 0 ? t.slice(0, r) : i === t ? null : i;
		}
		return null;
	}, ae = (e) => {
		let t = Tx[e] ?? Dx[e];
		if (!t) return null;
		let n = T(e), r = S(t);
		return n ? /* @__PURE__ */ y("button", {
			type: "button",
			onClick: () => ie(n),
			children: r
		}) : r;
	}, se = (e, t) => /* @__PURE__ */ y("div", {
		className: "sgs-hand-scroll",
		children: /* @__PURE__ */ b("div", {
			className: "flex min-w-0 flex-nowrap items-end gap-1 overflow-x-auto pt-2 scrollbar-none short:pt-[5px]",
			children: [w.map(e), t]
		})
	}), ce = se((e) => /* @__PURE__ */ y(uS, {
		card: e,
		selected: !1,
		disabled: !0,
		onClick: () => {}
	}, e.id)), le = (t) => {
		if (w.some((e) => e.id === t)) return null;
		for (let n of e.seats) {
			if (Object.values(n.equips).some((e) => e?.id === t)) return S(lS.equip);
			if (n.judges.some((e) => e.id === t)) return S(lS.judge);
			if (n.tian.some((e) => e.id === t)) return S(lS.tian);
		}
		return S(lS.shown);
	};
	if (i?.kind === "amazing-pick") return /* @__PURE__ */ y(mS, {
		title: S("games.sanguosha.amazingPick"),
		controls: /* @__PURE__ */ y("button", {
			type: "button",
			disabled: _.length !== 1,
			onClick: () => x({
				type: "choose",
				cardIds: _
			}),
			className: "btn-base min-h-11 px-6",
			style: { background: oe.accent },
			children: S("games.sanguosha.confirm")
		}),
		children: ce
	});
	if (i?.kind === "pick-zone") {
		let t = C.choosableOptions ?? [], n = typeof i.ctx.target == "number" ? e.seats[i.ctx.target] : void 0, r = {
			hand: "games.sanguosha.zoneHand",
			weapon: "games.sanguosha.zoneWeapon",
			armor: "games.sanguosha.zoneArmor",
			off_horse: "games.sanguosha.zoneOffHorse",
			def_horse: "games.sanguosha.zoneDefHorse"
		};
		return /* @__PURE__ */ y(mS, {
			title: S("games.sanguosha.pickZone"),
			children: /* @__PURE__ */ y("div", {
				className: "flex flex-wrap content-center items-center justify-center gap-2 overflow-y-auto px-2 scrollbar-none",
				children: t.map((e) => {
					let t = e === "weapon" || e === "armor" || e === "off_horse" || e === "def_horse" ? e : null, i = t ? n?.equips[t] : null, a = e.startsWith("judge:") ? Number(e.slice(6)) : -1, o = a >= 0 ? n?.judges[a] : void 0, s = i ? S(Dx[i.name]) : o ? S(Dx[o.name]) : a >= 0 ? S("games.sanguosha.zoneJudge", { n: a + 1 }) : S(r[e]);
					return /* @__PURE__ */ y("button", {
						type: "button",
						onClick: () => x({
							type: "choose",
							option: e
						}),
						"aria-label": t && i ? `${S(r[e])} · ${s}` : s,
						className: "btn-base min-h-11 px-4",
						style: { background: oe.accent },
						children: s
					}, e);
				})
			})
		});
	}
	if (i?.kind === "collateral-target") {
		let e = C.choosableSeats ?? [];
		return /* @__PURE__ */ y(mS, {
			title: S("games.sanguosha.collateralPick"),
			children: /* @__PURE__ */ y("div", {
				className: "flex flex-wrap content-center items-center justify-center gap-2 overflow-y-auto px-2 scrollbar-none",
				children: e.map((e) => /* @__PURE__ */ y("button", {
					type: "button",
					onClick: () => x({
						type: "choose",
						seat: e
					}),
					className: "btn-base min-h-11 px-4",
					style: { background: oe.accent },
					children: r(e)
				}, e))
			})
		});
	}
	if (i?.kind === "discard") {
		let e = i.ctx.count ?? 0, t = (t) => ee(Rx(_, t, e));
		return /* @__PURE__ */ y(mS, {
			title: S("games.sanguosha.discardPrompt", { n: e }),
			controls: /* @__PURE__ */ y("button", {
				type: "button",
				disabled: _.length !== e,
				onClick: () => x({
					type: "choose",
					cardIds: _
				}),
				className: "btn-base min-h-11 px-6",
				style: { background: oe.accent },
				children: S("games.sanguosha.confirm")
			}),
			children: se((e) => /* @__PURE__ */ y(uS, {
				card: e,
				selected: _.includes(e.id),
				disabled: !1,
				onClick: () => t(e.id)
			}, e.id))
		});
	}
	if (i?.kind === "skill-ask") {
		let e = C.choosableOptions ?? [], t = {
			use: "games.sanguosha.skillUse",
			obtain: "games.sanguosha.optionObtain",
			"xs-obtain": "games.sanguosha.optionXsObtain",
			draw: "games.sanguosha.optionDraw",
			"show-discard": "games.sanguosha.optionShowDiscard",
			"lose-hp": "games.sanguosha.optionLoseHp",
			maxhp: "games.sanguosha.optionLoseMaxHp",
			"draw-one": "games.sanguosha.optionDrawOne",
			"draw-x": "games.sanguosha.optionDrawX",
			recover: "games.sanguosha.optionRecover",
			draw2: "games.sanguosha.optionDrawTwo",
			"gl-discard": "games.sanguosha.optionGlDiscard",
			"gl-damage": "games.sanguosha.optionGlDamage",
			"ds-discard": "games.sanguosha.optionDsDiscard",
			"ds-draw": "games.sanguosha.optionDsDraw",
			transfer: "games.sanguosha.optionTransfer",
			losehp: "games.sanguosha.optionLoseHpTake",
			"draw-flip": "games.sanguosha.optionDrawFlip",
			"drop-lose": "games.sanguosha.optionDropLose",
			give: "games.sanguosha.optionGiveRole",
			top: "games.sanguosha.optionTopDeck",
			self: "games.sanguosha.optionSelfRecover",
			lord: "games.sanguosha.optionLordRecover",
			heal: "games.sanguosha.optionHealOther",
			bazhen: "games.sanguosha.skill.bazhen",
			huoji: "games.sanguosha.skill.huoji",
			kanpo: "games.sanguosha.skill.kanpo",
			slash: "games.sanguosha.card.slash",
			peach: "games.sanguosha.card.peach",
			analeptic: "games.sanguosha.card.analeptic",
			"zj-discard": "games.sanguosha.optionZjDiscard",
			"zj-draw": "games.sanguosha.optionZjDraw",
			"ey-give": "games.sanguosha.optionEyGive",
			"ey-losehp": "games.sanguosha.optionEyLosehp",
			"mc-slash": "games.sanguosha.optionMcSlash",
			"mc-draw": "games.sanguosha.optionMcDraw",
			"jj-draw": "games.sanguosha.optionJjDraw",
			"jj-recover": "games.sanguosha.optionJjRecover",
			"jj-reset": "games.sanguosha.optionJjReset",
			"jc-more": "games.sanguosha.optionJcMore",
			"jc-less": "games.sanguosha.optionJcLess",
			"jf-discard": "games.sanguosha.optionJfDiscard",
			"jf-draw": "games.sanguosha.optionJfDraw",
			"qy-give": "games.sanguosha.optionQyGive",
			"qy-target": "games.sanguosha.optionQyTarget",
			"yc-discard": "games.sanguosha.optionYcDiscard",
			"yc-recover": "games.sanguosha.optionYcRecover",
			"jx-discard": "games.sanguosha.optionJxDiscard",
			"jx-flip": "games.sanguosha.optionJxFlip",
			"mj-trick": "games.sanguosha.optionMjTrick",
			"mj-drop2": "games.sanguosha.optionMjDrop2",
			"fc-discard": "games.sanguosha.optionFcDiscard",
			"fc-damage": "games.sanguosha.optionFcDamage",
			"pd-draw": "games.sanguosha.optionPdDraw",
			"pd-discard": "games.sanguosha.optionPdDiscard",
			"bx-both": "games.sanguosha.optionBxBoth",
			"bx-pierce": "games.sanguosha.optionBxPierce",
			"bx-nullify": "games.sanguosha.optionBxNullify",
			"ch-give": "games.sanguosha.optionChGive",
			"ch-target": "games.sanguosha.optionChTarget",
			"qt-move": "games.sanguosha.optionQtMove",
			"qt-draw": "games.sanguosha.optionQtDraw",
			"xz-heal": "games.sanguosha.optionXzHeal",
			"xz-damage": "games.sanguosha.optionXzDamage",
			"qx-discard": "games.sanguosha.optionQxDiscard",
			"qx-plus": "games.sanguosha.optionQxPlus",
			"yz-give": "games.sanguosha.optionYzGive",
			"yz-discard": "games.sanguosha.optionYzDiscard",
			"hy-red": "games.sanguosha.optionHyRed",
			"hy-black": "games.sanguosha.optionHyBlack",
			"dx-draw": "games.sanguosha.optionDxDraw",
			"dx-modify": "games.sanguosha.optionDxModify",
			"hs-take": "games.sanguosha.optionHsTake",
			"hs-discard": "games.sanguosha.optionHsDiscard",
			"dl-view": "games.sanguosha.optionDlView",
			"dl-next": "games.sanguosha.optionDlNext",
			"gz-draw": "games.sanguosha.optionGzDraw",
			"gz-recover": "games.sanguosha.optionGzRecover",
			"zg-slash": "games.sanguosha.optionZgSlash",
			"zg-give": "games.sanguosha.optionZgGive",
			"cs-less": "games.sanguosha.optionCsLess",
			"cs-limit": "games.sanguosha.optionCsLimit",
			"cs-more": "games.sanguosha.optionCsMore",
			"fm-draw": "games.sanguosha.optionFmDraw",
			"fm-red": "games.sanguosha.optionFmRed",
			"tb-hand": "games.sanguosha.optionTbHand",
			"tb-top": "games.sanguosha.optionTbTop",
			"wg-top": "games.sanguosha.optionWgTop",
			"wg-bottom": "games.sanguosha.optionWgBottom",
			jink: "games.sanguosha.card.jink",
			nullification: "games.sanguosha.card.nullification",
			indulgence: "games.sanguosha.card.indulgence",
			lightning: "games.sanguosha.card.lightning",
			supply_shortage: "games.sanguosha.card.supply_shortage",
			fire_slash: "games.sanguosha.card.fire_slash",
			thunder_slash: "games.sanguosha.card.thunder_slash",
			iron_chain: "games.sanguosha.card.iron_chain",
			qinwang: "games.sanguosha.skill.qinwang",
			shifei: "games.sanguosha.skill.shifei",
			ex_nihilo: "games.sanguosha.card.ex_nihilo",
			savage_assault: "games.sanguosha.card.savage_assault",
			archery_attack: "games.sanguosha.card.archery_attack",
			god_salvation: "games.sanguosha.card.god_salvation",
			amazing_grace: "games.sanguosha.card.amazing_grace",
			snatch: "games.sanguosha.card.snatch",
			dismantlement: "games.sanguosha.card.dismantlement",
			duel: "games.sanguosha.card.duel",
			fire_attack: "games.sanguosha.card.fire_attack",
			collateral: "games.sanguosha.card.collateral"
		}, n = (e) => /^\d+$/.test(e) ? e : S(t[e] ?? "games.sanguosha.skillUse", { n: r }), r = i.ctx.data?.x ?? 0, a = i.ctx.skill;
		return /* @__PURE__ */ y(mS, {
			title: ae(a) ?? S("games.sanguosha.waitingSkill"),
			controls: /* @__PURE__ */ b(v, { children: [e.map((e) => /* @__PURE__ */ y("button", {
				type: "button",
				onClick: () => x({
					type: "choose",
					option: e
				}),
				className: "btn-base min-h-11 px-4",
				style: { background: oe.accent },
				children: n(e)
			}, e)), C.canPass && /* @__PURE__ */ y("button", {
				type: "button",
				onClick: () => x({ type: "pass" }),
				className: "btn-quiet min-h-11 px-4",
				children: S("games.sanguosha.skillDecline")
			})] }),
			children: ce
		});
	}
	if (i?.kind === "skill-cards") {
		let e = i.ctx.min ?? 0, t = i.ctx.max ?? 1, n = new Map((C.knownCards ?? []).map((e) => [e.id, e])), r = (e) => w.find((t) => t.id === e) ?? n.get(e), a = C.choosableCards ?? [], o = (e) => ee(Rx(_, e, t)), s = ae(i.ctx.skill);
		return /* @__PURE__ */ y(mS, {
			title: /* @__PURE__ */ b(v, { children: [
				s,
				s ? "\xA0\xA0" : "",
				S(e === t ? "games.sanguosha.skillPickCards" : "games.sanguosha.skillPickCardsUpTo", { n: t })
			] }),
			controls: /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("button", {
				type: "button",
				disabled: _.length < e || _.length > t,
				onClick: () => x({
					type: "choose",
					cardIds: _
				}),
				className: "btn-base min-h-11 px-5",
				style: { background: oe.accent },
				children: S("games.sanguosha.confirm")
			}), C.canPass && /* @__PURE__ */ y("button", {
				type: "button",
				onClick: () => x({ type: "pass" }),
				className: "btn-quiet min-h-11 px-4",
				children: S("games.sanguosha.skillDecline")
			})] }),
			children: /* @__PURE__ */ y("div", {
				className: "sgs-hand-scroll",
				children: /* @__PURE__ */ y("div", {
					className: "flex min-w-0 flex-nowrap items-end gap-1 overflow-x-auto pt-2 scrollbar-none short:pt-[5px]",
					children: a.map((e) => {
						let t = r(e);
						return t == null ? null : t.name == null ? /* @__PURE__ */ y("button", {
							type: "button",
							"aria-pressed": _.includes(e),
							"aria-label": S("games.sanguosha.cardBack"),
							onClick: () => o(e),
							className: `sgs-hand-card sgs-hand-card-backface ${_.includes(e) ? "sgs-hand-card-selected" : ""}`,
							children: /* @__PURE__ */ y("span", {
								"aria-hidden": "true",
								children: "◇"
							})
						}, e) : /* @__PURE__ */ y(uS, {
							card: t,
							selected: _.includes(e),
							disabled: !1,
							zone: le(e) ?? void 0,
							onClick: () => o(e)
						}, e);
					})
				})
			})
		});
	}
	if (i?.kind === "skill-seats") {
		let e = i.ctx.min ?? 0, t = i.ctx.max ?? 1, n = C.choosableSeats ?? [], a = (e) => ee(Rx(_, e, t)), o = ae(i.ctx.skill);
		return /* @__PURE__ */ y(mS, {
			title: /* @__PURE__ */ b(v, { children: [
				o,
				o ? "\xA0\xA0" : "",
				S(e === t ? "games.sanguosha.skillPickSeats" : "games.sanguosha.skillPickSeatsUpTo", { n: t })
			] }),
			controls: /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("button", {
				type: "button",
				disabled: _.length < e || _.length > t,
				onClick: () => x({
					type: "choose",
					seats: _
				}),
				className: "btn-base min-h-11 px-5",
				style: { background: oe.accent },
				children: S("games.sanguosha.confirm")
			}), C.canPass && /* @__PURE__ */ y("button", {
				type: "button",
				onClick: () => x({ type: "pass" }),
				className: "btn-quiet min-h-11 px-4",
				children: S("games.sanguosha.skillDecline")
			})] }),
			children: /* @__PURE__ */ y("div", {
				className: "flex flex-wrap content-center items-center justify-center gap-2 overflow-y-auto px-2 scrollbar-none",
				children: n.map((e) => /* @__PURE__ */ y("button", {
					type: "button",
					"aria-pressed": _.includes(e),
					onClick: () => a(e),
					className: `btn-base min-h-11 px-4 ${_.includes(e) ? "" : "opacity-60"}`,
					style: { background: oe.accent },
					children: r(e)
				}, e))
			})
		});
	}
	let ue = {
		jink: "games.sanguosha.respondJink",
		"slash-response": "games.sanguosha.respondSlash",
		"peach-save": "games.sanguosha.respondPeach"
	};
	if (i && (i.kind === "jink" || i.kind === "slash-response" || i.kind === "peach-save" || i.kind === "lord-call" || i.kind === "guicai")) {
		let e = /* @__PURE__ */ new Map();
		for (let t of C.respondable ?? []) e.has(t.cardId) || e.set(t.cardId, t);
		let t = C.choosableOptions ?? [], n = typeof i.ctx.from == "number" ? i.ctx.from : null, a;
		if (i.kind === "lord-call") a = dS(S(i.ctx.need === "jink" ? "games.sanguosha.lordCallJink" : "games.sanguosha.lordCallSlash"), [ae(i.ctx.need === "jink" ? "hujia" : "jijiang")]);
		else if (i.kind === "guicai") a = S("games.sanguosha.guicaiPrompt");
		else if (i.kind === "jink") {
			let e = i.ctx.cardName;
			a = n !== null && e ? dS(S("games.sanguosha.respondJinkFrom", { name: r(n) }), [ae(e)]) : S(ue[i.kind]);
		} else if (i.kind === "slash-response") {
			let e = i.ctx.aoe, t = i.ctx.collateral;
			a = e && n !== null ? dS(S("games.sanguosha.respondSlashAoe", { name: r(n) }), [ae(e)]) : i.ctx.duel && n !== null ? dS(S("games.sanguosha.respondSlashDuel", { name: r(n) }), [ae("duel")]) : t && n !== null ? dS(S("games.sanguosha.respondSlashCollateral", {
				name: r(n),
				target: r(t.b)
			}), [ae("collateral")]) : S(ue[i.kind]);
		} else if (i.kind === "peach-save") {
			let e = typeof i.ctx.target == "number" ? i.ctx.target : null;
			a = e === null ? S(ue[i.kind]) : S("games.sanguosha.respondPeachFrom", { name: r(e) });
		} else a = S(ue[i.kind]);
		return /* @__PURE__ */ y(mS, {
			title: a,
			controls: /* @__PURE__ */ b(v, { children: [
				t.includes("eight_diagram") && /* @__PURE__ */ y("button", {
					type: "button",
					onClick: () => x({
						type: "choose",
						option: "eight_diagram"
					}),
					className: "btn-base min-h-11 flex-none px-3",
					style: { background: oe.accent },
					children: S("games.sanguosha.useEightDiagram")
				}),
				t.includes("hujia") && /* @__PURE__ */ y("button", {
					type: "button",
					onClick: () => x({
						type: "choose",
						option: "hujia"
					}),
					className: "btn-base min-h-11 flex-none px-3",
					style: { background: oe.accent },
					children: S("games.sanguosha.skill.hujia")
				}),
				t.includes("jijiang") && /* @__PURE__ */ y("button", {
					type: "button",
					onClick: () => x({
						type: "choose",
						option: "jijiang"
					}),
					className: "btn-base min-h-11 flex-none px-3",
					style: { background: oe.accent },
					children: S("games.sanguosha.skill.jijiang")
				}),
				t.includes("jiushi") && /* @__PURE__ */ y("button", {
					type: "button",
					onClick: () => x({
						type: "choose",
						option: "jiushi"
					}),
					className: "btn-base min-h-11 flex-none px-3",
					style: { background: oe.accent },
					children: S("games.sanguosha.skill.jiushi")
				}),
				/* @__PURE__ */ y("button", {
					type: "button",
					onClick: () => x({ type: "respond" }),
					className: "btn-quiet min-h-11 flex-none px-4",
					children: S("games.sanguosha.passRespond")
				})
			] }),
			children: se((t) => {
				let n = e.get(t.id);
				return /* @__PURE__ */ y(uS, {
					card: t,
					selected: !1,
					disabled: !n,
					tag: n?.as ? S("games.sanguosha.convertTag", { card: S(Dx[n.as]) }) : void 0,
					onClick: () => n && x({
						type: "respond",
						cardId: t.id,
						...n.as ? { as: n.as } : {}
					})
				}, t.id);
			})
		});
	}
	let de = e.turn?.seat === n && e.turn.phase === "play" && !e.pending, fe = a === null ? [] : Object.keys(C.playable ?? {}).filter((e) => e.startsWith(`${a}@`)).map((e) => e.slice(e.indexOf("@") + 1)), E = d ? (C.skills ?? []).find((e) => e.id === d) : void 0, pe = () => {
		o(null), c(null), u(null), p(null), h(!1), ee([]);
	}, me = de ? (C.skills ?? []).length > 0 || C.serpentSlash ? /* @__PURE__ */ b("div", {
		className: "flex min-w-0 flex-nowrap items-center gap-1.5 overflow-x-auto scrollbar-none",
		children: [(C.skills ?? []).map((e) => /* @__PURE__ */ y("button", {
			type: "button",
			"aria-pressed": d === e.id,
			title: S(Ex[e.id]),
			onClick: () => {
				p(d === e.id ? null : e.id), o(null), c(null), h(!1), ee([]);
			},
			className: `btn-quiet min-h-11 flex-none px-3 text-xs ${d === e.id ? "ring-2 ring-ink" : ""}`,
			children: S(Tx[e.id])
		}, e.id)), C.serpentSlash && /* @__PURE__ */ y("button", {
			type: "button",
			"aria-pressed": m,
			title: S("games.sanguosha.cardDesc.spear"),
			onClick: () => {
				h(!m), p(null), o(null), c(null), ee([]), u(null);
			},
			className: `btn-quiet min-h-11 flex-none px-3 text-xs ${m ? "ring-2 ring-ink" : ""}`,
			children: S("games.sanguosha.card.spear")
		})]
	}) : S("games.sanguosha.playPrompt") : S("games.sanguosha.myHand");
	return /* @__PURE__ */ y(mS, {
		title: me,
		controls: de ? /* @__PURE__ */ b(v, { children: [
			(a !== null || d !== null || m) && /* @__PURE__ */ y("button", {
				type: "button",
				onClick: pe,
				className: "btn-quiet min-h-11 flex-none px-3",
				children: S("games.sanguosha.cancelSelection")
			}),
			m && /* @__PURE__ */ y("button", {
				type: "button",
				disabled: _.length !== 2 || l === null,
				onClick: re,
				className: "btn-base min-h-11 flex-none px-5",
				style: { background: oe.accent },
				children: S("games.sanguosha.serpentSlash")
			}),
			a !== null && !E && fe.length > 0 && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("button", {
				type: "button",
				"aria-pressed": s === null,
				onClick: () => c(null),
				className: `btn-quiet min-h-11 flex-none px-2 text-xs ${s === null ? "ring-2 ring-ink" : ""}`,
				children: S(Dx[w.find((e) => e.id === a)?.name ?? "slash"])
			}), fe.map((e) => /* @__PURE__ */ y("button", {
				type: "button",
				"aria-pressed": s === e,
				onClick: () => c(e),
				className: `btn-quiet min-h-11 flex-none px-2 text-xs font-semibold ${s === e ? "ring-2 ring-ink" : ""}`,
				style: s === e ? void 0 : { color: oe.accent },
				children: e === "recast" ? S("games.sanguosha.recastTag") : S("games.sanguosha.convertTag", { card: S(Dx[e]) })
			}, e))] }),
			a !== null && !E && /* @__PURE__ */ y("button", {
				type: "button",
				disabled: (C.playable?.[s ? `${a}@${s}` : String(a)]?.needTarget ?? !1) && l === null,
				onClick: te,
				className: "btn-base min-h-11 flex-none px-5",
				style: { background: oe.accent },
				children: S("games.sanguosha.confirm")
			}),
			E && /* @__PURE__ */ y("button", {
				type: "button",
				disabled: _.length < E.minCards || g.length < E.minTargets,
				onClick: ne,
				className: "btn-base min-h-11 flex-none px-5",
				style: { background: oe.accent },
				children: S("games.sanguosha.confirm")
			}),
			a === null && !E && !m && /* @__PURE__ */ y("button", {
				type: "button",
				onClick: () => x({ type: "pass" }),
				className: "btn-quiet min-h-11 flex-none px-4",
				children: S("games.sanguosha.endPlay")
			})
		] }) : void 0,
		children: se((e) => {
			let t = C.playable?.[String(e.id)] !== void 0 || _S(C, e.id).length > 0;
			if (m) {
				let t = (e) => ee(Rx(_, e, 2));
				return /* @__PURE__ */ y(uS, {
					card: e,
					selected: _.includes(e.id),
					disabled: !de,
					onClick: () => t(e.id)
				}, e.id);
			}
			if (E) {
				let t = !E.suits || E.suits.includes(e.suit), n = !E.names || E.names.includes(e.name), r = !E.classes || E.classes.includes(O(e.name)), i = E.id !== "qiangxi" || k(e.name) === "weapon", a = !E.sameSuit || _.length === 0 || w.some((t) => _.includes(t.id) && t.suit === e.suit), o = (e) => ee(Rx(_, e, E.maxCards));
				return /* @__PURE__ */ y(uS, {
					card: e,
					selected: _.includes(e.id),
					disabled: E.maxCards === 0 || E.allowTian === !0 || !t || !n || !r || !i || !a,
					onClick: () => o(e.id)
				}, e.id);
			}
			return /* @__PURE__ */ y(uS, {
				card: e,
				selected: a === e.id,
				disabled: !de || !t,
				onClick: () => {
					o(a === e.id ? null : e.id), c(null);
				}
			}, e.id);
		}, /* @__PURE__ */ b(v, { children: [
			!E && !m && de && [
				"weapon",
				"armor",
				"off_horse",
				"def_horse"
			].map((t) => {
				let r = e.seats[n]?.equips[t];
				return !r || _S(C, r.id).length === 0 ? null : /* @__PURE__ */ y(uS, {
					card: r,
					selected: a === r.id,
					disabled: !1,
					zone: S(lS.equip),
					onClick: () => {
						o(a === r.id ? null : r.id), c(null);
					}
				}, r.id);
			}),
			E?.allowEquip && [
				"weapon",
				"armor",
				"off_horse",
				"def_horse"
			].map((t) => {
				let r = e.seats[n]?.equips[t];
				if (!r) return null;
				let i = (E.id !== "qiangxi" || t === "weapon") && (!E.classes || E.classes.includes("equip")), a = (e) => ee(Rx(_, e, E.maxCards));
				return /* @__PURE__ */ y(uS, {
					card: r,
					selected: _.includes(r.id),
					disabled: !i,
					zone: S(lS.equip),
					onClick: () => a(r.id)
				}, r.id);
			}),
			E?.allowTian && (e.seats[n]?.tian ?? []).map((e) => {
				let t = (e) => ee(Rx(_, e, E.maxCards));
				return /* @__PURE__ */ y(uS, {
					card: e,
					selected: _.includes(e.id),
					disabled: !1,
					zone: S(lS.tian),
					onClick: () => t(e.id)
				}, e.id);
			})
		] }))
	});
}
function _S(e, t) {
	return Object.keys(e.playable ?? {}).filter((e) => e.startsWith(`${t}@`)).map((e) => e.slice(e.indexOf("@") + 1));
}
function vS(e) {
	if (!e.includes("")) return e;
	let t = [], n = e, r = 0;
	for (;;) {
		let e = n.indexOf("");
		if (e < 0) {
			t.push(n);
			break;
		}
		let i = n.indexOf("", e + 1);
		if (e > 0 && t.push(n.slice(0, e)), t.push(/* @__PURE__ */ y("span", {
			className: "sgs-suit-red",
			children: n.slice(e + 1, i < 0 ? void 0 : i)
		}, r++)), i < 0) break;
		n = n.slice(i + 1);
	}
	return t;
}
function yS({ entry: e, nameOf: t }) {
	let n = f(), { kind: r, seat: i, card: a, cards: o, target: s, n: c } = e, l = zx[r], u = a && a in Dx ? n(Dx[a]) : a && a in Tx ? n(Tx[a]) : a ?? "", d = (e) => {
		let t = `${Nx[e.suit]}${Lx(e.point)} ${n(Dx[e.name])}`;
		return e.suit === "heart" || e.suit === "diamond" ? `\uE000${t}\uE001` : t;
	}, p = o?.map(d).join("、");
	if (r === "buqu-check" && o?.length) {
		let e = i === void 0 ? "" : t(i), r = o.slice(0, -1).map(d).join("、") || n("games.sanguosha.log.buquNoWounds"), a = d(o[o.length - 1]), s = "text-xs leading-4.5 text-ink/70";
		return /* @__PURE__ */ b(v, { children: [
			/* @__PURE__ */ y("li", {
				className: s,
				children: vS(n("games.sanguosha.log.buquExisting", {
					name: e,
					cards: r
				}))
			}),
			/* @__PURE__ */ y("li", {
				className: s,
				children: vS(n("games.sanguosha.log.buquReveal", { cards: a }))
			}),
			/* @__PURE__ */ y("li", {
				className: s,
				children: n(c === 1 ? "games.sanguosha.log.buquSuccessResult" : "games.sanguosha.log.buquFailResult")
			})
		] });
	}
	if (!l) return null;
	let m = p ? Bx[r] : void 0, h = (r === "judge-result" ? c === 1 ? "games.sanguosha.log.judgeResultHit" : c === 0 ? "games.sanguosha.log.judgeResultMiss" : "games.sanguosha.log.judgeResult" : null) ?? m ?? (r === "use" && s === void 0 ? "games.sanguosha.log.useNoTarget" : l), g = a != null && o != null && o.some((e) => e.name !== a) ? r === "use" ? s === void 0 ? "games.sanguosha.log.useConvertedNoTarget" : "games.sanguosha.log.useConverted" : r === "respond-slash" ? "games.sanguosha.log.respondSlashConverted" : r === "jink" ? "games.sanguosha.log.jinkConverted" : null : null, _ = g ?? h, ee = r === "judge-result" || r === "judge-reveal" || r === "skill" ? u : g == null ? p ?? u : u;
	return /* @__PURE__ */ y("li", {
		className: "text-xs leading-4.5 text-ink/70",
		children: vS(n(_, {
			name: i === void 0 ? "" : t(i),
			target: s === void 0 ? "" : t(s),
			card: ee,
			cards: p ?? "",
			n: c ?? 0
		}))
	});
}
//#endregion
//#region src/games/sanguosha/bot/core.ts
var bS = {
	peach: 9,
	ex_nihilo: 8,
	nullification: 7,
	jink: 7,
	indulgence: 6,
	snatch: 6,
	analeptic: 6,
	slash: 6,
	fire_slash: 6,
	thunder_slash: 6,
	dismantlement: 5,
	supply_shortage: 5,
	savage_assault: 5,
	archery_attack: 5,
	god_salvation: 4,
	duel: 4,
	amazing_grace: 4,
	collateral: 4,
	fire_attack: 3,
	iron_chain: 2,
	lightning: 2,
	eight_diagram: 6,
	renwang_shield: 5,
	vine: 5,
	silver_lion: 4,
	jueying: 3,
	dilu: 3,
	zhuahuangfeidian: 3,
	chitu: 3,
	dayuan: 3,
	zixing: 3,
	hualiu: 3
};
function Q(e) {
	let t = Ae[e.name];
	return t == null ? bS[e.name] ?? 3 : 3 + t;
}
function xS(e) {
	return [...e].sort((e, t) => Q(e) - Q(t) || t.point - e.point);
}
var SS = /* @__PURE__ */ new Set([
	"amazing-take",
	"fire-attack-show",
	"fire-show"
]);
function CS(e, t) {
	let n = (e) => `${e.name}|${e.suit}|${e.point}`, r = /* @__PURE__ */ new Map();
	for (let i of e.log) if (i.cards?.length) {
		if (SS.has(i.kind)) {
			if (i.seat === t) for (let e of i.cards) r.set(n(e), e);
			continue;
		}
		for (let e of i.cards) r.delete(n(e));
	}
	let i = [...r.values()], a = e.seats[t]?.handCount ?? 0;
	return i.length > a ? i.slice(i.length - a) : i;
}
var wS = /* @__PURE__ */ new Set([
	"slash",
	"duel",
	"chain",
	"ganglie",
	"fire_attack",
	"savage_assault",
	"archery_attack",
	"quhu"
]);
function TS(e, t, n) {
	let r = e.seats.findIndex((e) => e.identity === "lord"), i = /* @__PURE__ */ new Map(), a = (e, t) => i.set(e, (i.get(e) ?? 0) + t), o = n === "rebel", s = /* @__PURE__ */ new Set(), c = (n, i) => {
		if (n === i) return;
		if (i === r) {
			a(n, o ? -2 : 2);
			return;
		}
		let c = e.seats[i]?.identity;
		if (c === "loyalist") {
			a(n, o ? -2 : 2);
			return;
		}
		if (c === "rebel") {
			a(n, o ? 2 : -2);
			return;
		}
		i === t && !s.has(n) && (s.add(n), a(n, 1));
	};
	for (let t of e.log) switch (t.kind) {
		case "slash":
		case "duel":
			t.seat != null && t.target != null && c(t.seat, t.target);
			break;
		case "snatch":
		case "dismantle":
			t.seat != null && t.target != null && !t.cards?.some((e) => OS.has(e.name)) && c(t.seat, t.target);
			break;
		case "use":
			t.card === "fire_attack" && t.seat != null && t.target != null && c(t.seat, t.target);
			break;
		case "place-judge":
			t.from != null && t.seat != null && c(t.from, t.seat);
			break;
		case "damage": t.from != null && t.seat != null && t.reason != null && !wS.has(t.reason) && c(t.from, t.seat);
	}
	return i;
}
function $(e, t, n, r) {
	if (n === t) return -3;
	let i = e.public.seats[n];
	if (!i?.alive) return 0;
	let a = e.private.identity, o = i.identity, s = e.public.seats.findIndex((e) => e.identity === "lord");
	if (a === "rebel") return o === "lord" || o === "loyalist" ? 3 : o === "rebel" ? -3 : n === s ? 3 : 0;
	if (a === "renegade" && !e.public.seats.some((e) => e.alive && e.identity === "rebel")) {
		let n = e.public.seats.filter((e, n) => e.alive && n !== t).length;
		return o === "lord" ? n <= 1 ? 3 : -3 : 2;
	}
	if (o === "rebel") return 3;
	if (o === "lord" || o === "loyalist") return -3;
	if (o === "renegade") return a === "renegade" ? 0 : 2;
	let c = (at[e.public.seats.length] ?? at[8]).filter((e) => e === "rebel").length;
	return e.public.seats.filter((e) => !e.alive && e.identity === "rebel").length >= c ? 2 : Math.max(-2, Math.min(2, r.get(n) ?? 0));
}
function ES(e, t, n, r) {
	let i = null, a = 1;
	for (let o of n) {
		let n = $(e, t, o, r);
		n > a && (a = n, i = o);
	}
	return i;
}
function DS(e, t, n, r) {
	let i = null, a = 0;
	for (let o of n) {
		let n = $(e, t, o, r);
		n < a && (a = n, i = o);
	}
	return i;
}
var OS = /* @__PURE__ */ new Set([
	"indulgence",
	"supply_shortage",
	"lightning"
]), kS = /* @__PURE__ */ new Set([
	"caocao",
	"simayi",
	"xiahoudun",
	"guojia",
	"xunyu",
	"caopi",
	"xiaoqiao",
	"caiwenji"
]);
function AS(e, t, n, r, i) {
	let a = e.public.seats[n];
	if (!a?.alive) return -99;
	let o = 0;
	if (a.hp <= 1 && (o += 2), a.generalId != null && kS.has(a.generalId) && (o -= a.hp <= 1 ? 1 : 3), i && a.chained) for (let [i, a] of e.public.seats.entries()) {
		if (i === n || !a.alive || !a.chained) continue;
		let s = i === t ? -3 : $(e, t, i, r);
		if (s < 0) return -99;
		s > 0 && (o += 2);
	}
	return o;
}
function jS(e, t, n, r, i, a) {
	let o = e.public.seats[n];
	if (!o?.alive) return !1;
	if (e.public.seats[t].equips.weapon?.name !== "qinggang_sword") {
		let e = o.equips.armor?.name;
		if (e === "vine" && r === "slash" || e === "renwang_shield" && i) return !1;
	}
	return !(o.generalId === "liushan" && !a);
}
function MS(e) {
	for (let t = e.log.length - 1; t >= 0; t--) {
		let n = e.log[t];
		if (n.kind === "damage" && n.seat != null) return n.seat;
	}
	return null;
}
//#endregion
//#region src/games/sanguosha/bot/play.ts
function NS(e) {
	let t = e.public.pending.ctx.count ?? 0;
	return {
		type: "choose",
		cardIds: xS(e.private.hand).slice(0, t).map((e) => e.id)
	};
}
function PS(e) {
	let t = e.public.pending, n = t.ctx.revealed ?? [], r = t.ctx.taken ?? {}, i = n.filter((e) => r[e.id] == null);
	return i.length ? {
		type: "choose",
		cardIds: [[...i].sort((e, t) => Q(t) - Q(e))[0].id]
	} : null;
}
var FS = /* @__PURE__ */ new Set([
	"sunshangxiang",
	"re_sunshangxiang",
	"lingtong",
	"re_lingtong"
]);
function IS(e, t, n) {
	let r = e.private.act.choosableOptions ?? [];
	if (!r.length) return null;
	let i = e.public.pending.ctx.target, a = i == null ? void 0 : e.public.seats[i];
	if (a && i != null && (i === t || $(e, t, i, n) < 0)) {
		let e = a.judges.findIndex((e) => OS.has(e.name));
		if (e >= 0 && r.includes(`judge:${e}`)) return {
			type: "choose",
			option: `judge:${e}`
		};
	}
	if (a && i != null && i !== t) {
		if (r.includes("hand") && CS(e.public, i).some((e) => e.name === "peach" || e.name === "nullification") || a.hp <= 2 && a.handCount > 0 && r.includes("hand")) return {
			type: "choose",
			option: "hand"
		};
		let t = a.equips.armor?.name === "silver_lion" && a.hp < a.maxHp, n = a.generalId != null && FS.has(a.generalId), o = [
			"armor",
			"weapon",
			"off_horse",
			"def_horse"
		].filter((e) => r.includes(e) && !(t && e === "armor"));
		if (!n) {
			for (let e of [...o, "hand"]) if (r.includes(e)) return {
				type: "choose",
				option: e
			};
		} else if (r.includes("hand")) return {
			type: "choose",
			option: "hand"
		};
		for (let e of o) return {
			type: "choose",
			option: e
		};
	} else for (let e of [
		"armor",
		"weapon",
		"off_horse",
		"def_horse",
		"hand"
	]) if (r.includes(e)) return {
		type: "choose",
		option: e
	};
	return {
		type: "choose",
		option: r.find((e) => !e.startsWith("judge:")) ?? r[0]
	};
}
function LS(e) {
	let t = e.indexOf("@");
	return t < 0 ? {
		id: Number(e),
		as: null
	} : {
		id: Number(e.slice(0, t)),
		as: e.slice(t + 1)
	};
}
function RS(e, t, n) {
	let r = e.private.act, i = e.public, a = e.private.hand, o = r.playable ?? {}, s = Object.entries(o).map(([e, t]) => {
		let { id: n, as: r } = LS(e), i = a.find((e) => e.id === n);
		return i ? {
			key: e,
			info: t,
			card: i,
			as: r,
			name: r === "recast" ? "recast" : r ?? i.name
		} : null;
	}), c = (e) => s.find((t) => t != null && e(t)) ?? null, l = i.seats.map((e, t) => t).filter((e) => e !== t && i.seats[e].alive), u = (r) => ES(e, t, r, n), d = l.filter((r) => $(e, t, r, n) >= 2).length, f = l.filter((r) => $(e, t, r, n) < 0).length, p = a.length > i.seats[t].hp, m = i.seats[t]?.zishou === !0, h = /* @__PURE__ */ new Map(), g = (e) => {
		let t = h.get(e);
		return t || h.set(e, t = CS(i, e)), t;
	}, _ = (r) => r.filter((r) => $(e, t, r, n) >= 0).sort((e, t) => (n.get(t) ?? 0) - (n.get(e) ?? 0) || i.seats[e].hp - i.seats[t].hp)[0] ?? null, ee = i.seats[t]?.equips, v = c((e) => !e.as && O(e.card.name) === "equip" && !e.info.needTarget && k(e.card.name) != null && ee?.[k(e.card.name)] == null);
	if (v) return {
		type: "play",
		cardIds: [v.card.id]
	};
	if (i.seats[t] && i.seats[t].hp < i.seats[t].maxHp) {
		let e = c((e) => e.name === "peach" && !e.info.needTarget);
		if (e) return {
			type: "play",
			cardIds: [e.card.id],
			...e.as ? { as: e.as } : {}
		};
	}
	let y = c((e) => e.name === "ex_nihilo" && !e.info.needTarget);
	if (y) return {
		type: "play",
		cardIds: [y.card.id],
		...y.as ? { as: y.as } : {}
	};
	let b = (r) => r.filter((r) => $(e, t, r, n) < 0 && i.seats[r].judges.some((e) => OS.has(e.name))).sort((r, i) => $(e, t, r, n) - $(e, t, i, n))[0] ?? null;
	for (let e of ["snatch", "dismantlement"]) {
		let t = c((t) => t.name === e && t.info.needTarget);
		if (!t) continue;
		let n = b(t.info.targets) ?? u(t.info.targets) ?? (e === "dismantlement" && p ? _(t.info.targets) : null);
		if (n != null) return {
			type: "play",
			cardIds: [t.card.id],
			target: n,
			...t.as ? { as: t.as } : {}
		};
	}
	let te = c((e) => e.name === "duel" && e.info.needTarget);
	if (te && !m) {
		let r = a.filter((e) => A(e.name)).length, o = te.info.targets.filter((r) => $(e, t, r, n) >= 2).filter((e) => i.seats[e].handCount <= 1 || r >= 2).filter((e) => r >= 2 || !g(e).some((e) => A(e.name))).filter((r) => AS(e, t, r, n, !1) >= 0).sort((r, i) => $(e, t, i, n) - $(e, t, r, n))[0];
		if (o != null) return {
			type: "play",
			cardIds: [te.card.id],
			target: o,
			...te.as ? { as: te.as } : {}
		};
	}
	let ne = null, re = -1;
	for (let r of s) {
		if (!r || !A(r.name) || !r.info.needTarget || m) continue;
		let o = r.card.suit === "spade" || r.card.suit === "club", s = a.some((e) => e.id !== r.card.id && O(e.name) === "basic");
		for (let a of r.info.targets) {
			if (!jS(e, t, a, r.name, o, s)) continue;
			let c = $(e, t, a, n);
			if (c < 0 || c < 2 && !p) continue;
			let l = AS(e, t, a, n, r.name !== "slash");
			if (l <= -90) continue;
			let u = g(a).some((e) => e.name === "jink"), d = (c >= 2 ? 100 + c : 50 + (n.get(a) ?? 0) - i.seats[a].hp) + l * 20 - (u ? 30 : 0);
			d > re && (re = d, ne = {
				e: r,
				t: a,
				confirmed: c >= 2
			});
		}
	}
	if (ne) {
		let e = ne.confirmed ? c((e) => e.name === "analeptic" && !e.info.needTarget) : null;
		return e ? {
			type: "play",
			cardIds: [e.card.id],
			...e.as ? { as: e.as } : {}
		} : {
			type: "play",
			cardIds: [ne.e.card.id],
			target: ne.t,
			...ne.e.as ? { as: ne.e.as } : {}
		};
	}
	let ie = r.serpentSlash;
	if (ie && !m && a.length >= 2) {
		let r = xS(a).slice(0, 2), i = r.every((e) => e.suit === "spade" || e.suit === "club"), o = a.some((e) => !r.some((t) => t.id === e.id) && O(e.name) === "basic"), s = ie.targets.filter((n) => jS(e, t, n, "slash", i, o)).filter((r) => $(e, t, r, n) >= 2 || p && $(e, t, r, n) >= 0).filter((r) => AS(e, t, r, n, !1) >= 0).sort((r, i) => $(e, t, i, n) - $(e, t, r, n))[0];
		if (s != null) return {
			type: "play",
			cardIds: r.map((e) => e.id),
			target: s,
			as: "slash"
		};
	}
	for (let e of ["savage_assault", "archery_attack"]) {
		let t = c((t) => t.name === e && !t.info.needTarget);
		if (t && !m && d >= 2 && d > f) return {
			type: "play",
			cardIds: [t.card.id],
			...t.as ? { as: t.as } : {}
		};
	}
	let x = c((e) => e.name === "god_salvation" && !e.info.needTarget);
	if (x) {
		let r = l.filter((r) => $(e, t, r, n) < 0 && i.seats[r].hp < i.seats[r].maxHp).length + +(i.seats[t].hp < i.seats[t].maxHp);
		if (r > l.filter((r) => $(e, t, r, n) >= 2 && i.seats[r].hp < i.seats[r].maxHp).length && r > 0) return {
			type: "play",
			cardIds: [x.card.id],
			...x.as ? { as: x.as } : {}
		};
	}
	for (let e of ["indulgence", "supply_shortage"]) {
		let t = c((t) => t.name === e && t.info.needTarget);
		if (t) {
			let e = u(t.info.targets);
			if (e != null) return {
				type: "play",
				cardIds: [t.card.id],
				target: e,
				...t.as ? { as: t.as } : {}
			};
		}
	}
	let S = c((e) => e.name === "collateral" && e.info.needTarget);
	if (S) {
		let r = S.info.targets.filter((r) => $(e, t, r, n) >= 2 && i.seats[r].equips.weapon != null)[0];
		if (r != null) return {
			type: "play",
			cardIds: [S.card.id],
			target: r,
			...S.as ? { as: S.as } : {}
		};
	}
	let C = c((e) => e.name === "fire_attack" && e.info.needTarget);
	if (C && !m) {
		let r = (e) => {
			let t = g(e);
			return t.length > 0 && t.length >= i.seats[e].handCount && t.every((e) => a.some((t) => t.suit === e.suit));
		}, o = C.info.targets.filter((r) => $(e, t, r, n) >= 2 && i.seats[r].handCount > 0).filter((r) => AS(e, t, r, n, !0) >= 0).sort((i, a) => Number(r(a)) - Number(r(i)) || AS(e, t, a, n, !0) - AS(e, t, i, n, !0))[0];
		if (o != null) return {
			type: "play",
			cardIds: [C.card.id],
			target: o,
			...C.as ? { as: C.as } : {}
		};
	}
	let w = c((e) => e.name === "amazing_grace" && !e.info.needTarget);
	if (w && a.length <= 2) return {
		type: "play",
		cardIds: [w.card.id],
		...w.as ? { as: w.as } : {}
	};
	let T = c((e) => e.name === "iron_chain" && e.info.needTarget);
	if (T) {
		let r = T.info.targets.filter((r) => $(e, t, r, n) >= 2 && !i.seats[r].chained);
		if (r.length >= 1 && d >= 2) return {
			type: "play",
			cardIds: [T.card.id],
			target: r[0],
			...T.as ? { as: T.as } : {}
		};
	}
	let ae = c((e) => e.name === "recast" && !e.info.needTarget);
	return ae && a.length > i.seats[t].hp ? {
		type: "play",
		cardIds: [ae.card.id],
		as: "recast"
	} : zS(e, t, n) || (r.canPass ? { type: "pass" } : null);
}
function zS(e, t, n) {
	let r = e.private.act, i = e.public, a = e.private.hand, o = r.skills ?? [], s = (e) => o.find((t) => t.id === e || t.id === `re_${e}`), c = xS(a), l = i.seats.map((e, t) => t).filter((e) => e !== t && i.seats[e].alive), u = s("zhiheng");
	if (u) {
		let e = /* @__PURE__ */ new Set();
		for (let t of [
			"jink",
			"slash",
			"peach"
		]) {
			let n = a.find((n) => n.name === t && !e.has(n.id));
			n && e.add(n.id);
		}
		let t = c.filter((t) => !e.has(t.id) && Q(t) <= 4).map((e) => e.id);
		if (t.length >= 1) return {
			type: "skill",
			skill: u.id,
			cardIds: t,
			targets: []
		};
	}
	let d = s("rende");
	if (d && a.length >= 3) {
		let r = DS(e, t, d.targets, n);
		if (r != null && (i.seats[t].hp < i.seats[t].maxHp || a.length >= 5)) return {
			type: "skill",
			skill: d.id,
			cardIds: c.slice(0, 2).map((e) => e.id),
			targets: [r]
		};
	}
	let f = s("lijian");
	if (f && f.targets.length >= 2 && c.length >= (f.minCards || 1)) {
		let r = f.targets.filter((r) => $(e, t, r, n) >= 2);
		if (r.length >= 2) return {
			type: "skill",
			skill: f.id,
			cardIds: c.slice(0, f.minCards).map((e) => e.id),
			targets: r.slice(0, 2)
		};
	}
	let p = s("jieyin");
	if (p && a.length >= p.minCards + 1) {
		let r = p.targets.filter((r) => $(e, t, r, n) < 0 && i.seats[r].hp < i.seats[r].maxHp)[0];
		if (r != null && i.seats[t].hp < i.seats[t].maxHp) return {
			type: "skill",
			skill: p.id,
			cardIds: c.slice(0, p.minCards).map((e) => e.id),
			targets: [r]
		};
	}
	if (s("kurou") && i.seats[t].hp >= 3 && a.length <= 2 && a.length >= 1) return {
		type: "skill",
		skill: "kurou",
		cardIds: [c[0].id],
		targets: []
	};
	let m = s("tiaoxin");
	if (m) {
		let r = m.targets.filter((r) => $(e, t, r, n) >= 2).sort((e, t) => i.seats[e].handCount - i.seats[t].handCount)[0];
		if (r != null) return {
			type: "skill",
			skill: m.id,
			cardIds: [],
			targets: [r]
		};
	}
	let h = s("jixi");
	if (h) {
		let r = ES(e, t, h.targets, n), a = i.seats[t]?.tian ?? [];
		if (r != null && a.length > 0) return {
			type: "skill",
			skill: "jixi",
			cardIds: [a[0].id],
			targets: [r]
		};
	}
	let g = s("zhijian");
	if (g) for (let r of a) {
		let a = k(r.name);
		if (!a) continue;
		let o = g.targets.find((r) => $(e, t, r, n) <= 0 && i.seats[r].equips[a] == null);
		if (o != null) return {
			type: "skill",
			skill: g.id,
			cardIds: [r.id],
			targets: [o]
		};
	}
	let _ = s("qiangxi");
	if (_) {
		let r = a.find((e) => k(e.name) === "weapon"), i = ES(e, t, _.targets, n);
		if (r && i != null) return {
			type: "skill",
			skill: _.id,
			cardIds: [r.id],
			targets: [i]
		};
	}
	let ee = s("luanji");
	if (ee && l.filter((r) => $(e, t, r, n) >= 2).length >= 2) {
		let e = /* @__PURE__ */ new Map();
		for (let t of c) e.set(t.suit, [...e.get(t.suit) ?? [], t]);
		for (let t of e.values()) if (t.length >= 2 && Q(t[0]) <= 4 && Q(t[1]) <= 4) return {
			type: "skill",
			skill: ee.id,
			cardIds: [t[0].id, t[1].id],
			targets: []
		};
	}
	let v = s("zhiba");
	if (v && v.targets.length > 0 && c.length > 0) return {
		type: "skill",
		skill: "zhiba",
		cardIds: [c[0].id],
		targets: v.targets.slice(0, 1)
	};
	let y = s("gongxin");
	if (y) {
		let r = y.targets.filter((r) => $(e, t, r, n) >= 2 && i.seats[r].handCount > 0).sort((e, t) => i.seats[t].handCount - i.seats[e].handCount)[0];
		if (r != null) return {
			type: "skill",
			skill: "gongxin",
			cardIds: [],
			targets: [r]
		};
	}
	let b = s("huangtian");
	if (b && b.targets.length > 0) {
		let r = b.targets[0];
		if ($(e, t, r, n) < 0) {
			let e = c.find((e) => (b.names ?? []).includes(e.name));
			if (e) return {
				type: "skill",
				skill: "huangtian",
				cardIds: [e.id],
				targets: [r]
			};
		}
	}
	let te = s("fanjian");
	if (te && c.length > 0) {
		let r = ES(e, t, te.targets, n);
		if (r != null) return {
			type: "skill",
			skill: "fanjian",
			cardIds: [c[0].id],
			targets: [r]
		};
	}
	let ne = s("yijue");
	if (ne && c.length > 0) {
		let r = ne.targets.filter((r) => $(e, t, r, n) >= 2).sort((e, t) => i.seats[e].hp - i.seats[t].hp)[0];
		if (r != null) return {
			type: "skill",
			skill: ne.id,
			cardIds: [c[0].id],
			targets: [r]
		};
	}
	let re = s("tianyi");
	if (re && a.some((e) => A(e.name))) {
		let r = [...a].sort((e, t) => t.point - e.point)[0], i = re.targets.filter((r) => $(e, t, r, n) >= 2)[0];
		if (r.point >= 11 && i != null) return {
			type: "skill",
			skill: "tianyi",
			cardIds: [r.id],
			targets: [i]
		};
	}
	let ie = s("quhu");
	if (ie && l.filter((r) => $(e, t, r, n) >= 2).length >= 2) {
		let r = [...a].sort((e, t) => t.point - e.point)[0], o = ie.targets.filter((r) => $(e, t, r, n) >= 2).sort((e, t) => i.seats[e].handCount - i.seats[t].handCount)[0];
		if (r.point >= 11 && o != null) return {
			type: "skill",
			skill: "quhu",
			cardIds: [r.id],
			targets: [o]
		};
	}
	if (ie && i.seats[t].hp >= 3) {
		let r = (e) => i.seats[e].maxHp - i.seats[e].handCount >= 2, o = ie.targets.filter((r) => $(e, t, r, n) < 0)[0], s = [...a].sort((e, t) => e.point - t.point)[0];
		if (o != null && s != null && s.point <= 5 && (r(t) || l.some((i) => $(e, t, i, n) < 0 && r(i)))) return {
			type: "skill",
			skill: "quhu",
			cardIds: [s.id],
			targets: [o]
		};
	}
	let x = s("dimeng");
	if (x) {
		let r = x.targets.filter((r) => $(e, t, r, n) >= 2).sort((e, t) => i.seats[t].handCount - i.seats[e].handCount)[0], a = x.targets.filter((r) => $(e, t, r, n) < 0).sort((e, t) => i.seats[e].handCount - i.seats[t].handCount)[0];
		if (r != null && a != null) {
			let e = i.seats[r].handCount - i.seats[a].handCount, t = c.filter((e) => Q(e) <= 4);
			if (e >= 2 && t.length >= e) return {
				type: "skill",
				skill: "dimeng",
				cardIds: t.slice(0, e).map((e) => e.id),
				targets: [r, a]
			};
		}
	}
	let S = s("luanwu");
	if (S) {
		let r = l.filter((r) => $(e, t, r, n) >= 2);
		if (r.length >= 2 && r.some((e) => i.seats[e].hp <= 2)) return {
			type: "skill",
			skill: S.id,
			cardIds: [],
			targets: []
		};
	}
	let C = s("chuli");
	if (C && c.length > 0) {
		let r = C.targets.filter((r) => $(e, t, r, n) >= 2).slice(0, C.maxTargets), i = c.find((e) => e.suit === "spade") ?? c[0];
		if (r.length >= 1 && Q(i) <= 4) return {
			type: "skill",
			skill: "chuli",
			cardIds: [i.id],
			targets: r
		};
	}
	let w = s("qingnang");
	if (w && c.length > 0) {
		let r = w.targets.filter((r) => i.seats[r].hp < i.seats[r].maxHp && (r === t || $(e, t, r, n) < 0)).sort((r, i) => $(e, t, r, n) - $(e, t, i, n))[0];
		if (r != null) return {
			type: "skill",
			skill: "qingnang",
			cardIds: [c[0].id],
			targets: [r]
		};
	}
	let T = s("sishu");
	if (T) {
		let r = ES(e, t, T.targets, n);
		if (r != null) return {
			type: "skill",
			skill: "sishu",
			cardIds: [],
			targets: [r]
		};
	}
	if (s("qimou") && i.seats[t].hp >= 3 && l.some((r) => $(e, t, r, n) >= 2)) return {
		type: "skill",
		skill: "qimou",
		cardIds: [],
		targets: []
	};
	let ae = s("changbiao");
	if (ae && c.length >= Math.max(2, ae.minCards)) {
		let r = ES(e, t, ae.targets, n);
		if (r != null) return {
			type: "skill",
			skill: "changbiao",
			cardIds: c.slice(0, Math.max(2, ae.minCards)).map((e) => e.id),
			targets: [r]
		};
	}
	let oe = s("olsanyao");
	if (oe && c.length > 1) {
		let r = ES(e, t, oe.targets, n);
		if (r != null && Q(c[0]) <= 4) return {
			type: "skill",
			skill: "olsanyao",
			cardIds: [c[0].id],
			targets: [r]
		};
	}
	let se = s("mingce");
	if (se) {
		let r = DS(e, t, se.targets, n), i = a.find((e) => A(e.name)) ?? c.find((e) => k(e.name) != null);
		if (r != null && i != null && l.some((r) => $(e, t, r, n) >= 2)) return {
			type: "skill",
			skill: "mingce",
			cardIds: [i.id],
			targets: [r]
		};
	}
	let ce = s("ganlu");
	if (ce) {
		let r = (e) => Object.values(i.seats[e].equips).filter(Boolean).length, a = i.seats[t].maxHp - i.seats[t].hp, o = ce.targets.filter((r) => $(e, t, r, n) >= 2).sort((e, t) => r(t) - r(e))[0], s = ce.targets.filter((r) => r !== o && (r === t || $(e, t, r, n) < 0)).sort((e, t) => r(e) - r(t))[0];
		if (o != null && s != null && r(o) - r(s) >= 2 && r(o) - r(s) <= a) return {
			type: "skill",
			skill: "ganlu",
			cardIds: [],
			targets: [s, o]
		};
	}
	let le = s("xinxianzhen");
	if (le && a.some((e) => A(e.name))) {
		let r = [...a].sort((e, t) => t.point - e.point)[0], o = le.targets.filter((r) => $(e, t, r, n) >= 2).sort((e, t) => i.seats[e].hp - i.seats[t].hp)[0];
		if (r.point >= 12 && o != null) return {
			type: "skill",
			skill: "xinxianzhen",
			cardIds: [r.id],
			targets: [o]
		};
	}
	if (s("qice") && a.length >= 2 && a.every((e) => Q(e) <= 3)) return {
		type: "skill",
		skill: "qice",
		cardIds: [],
		targets: []
	};
	if (s("paiyi")) return {
		type: "skill",
		skill: "paiyi",
		cardIds: [],
		targets: []
	};
	if (s("old_anxu")) return {
		type: "skill",
		skill: "old_anxu",
		cardIds: [],
		targets: []
	};
	if (s("gongji") && c.length > 0 && Q(c[0]) <= 4) return {
		type: "skill",
		skill: "gongji",
		cardIds: [],
		targets: []
	};
	let ue = s("jiefan");
	if (ue) {
		let r = ue.targets.filter((r) => (r === t || $(e, t, r, n) < 0) && i.seats[r].hp <= 1).sort((e, t) => i.seats[e].hp - i.seats[t].hp)[0];
		if (r != null) return {
			type: "skill",
			skill: "jiefan",
			cardIds: [],
			targets: [r]
		};
	}
	let de = s("danshou");
	if (de && de.minCards === 1 && c.length > 0 && Q(c[0]) <= 3) {
		let r = ES(e, t, de.targets, n);
		if (r != null) return {
			type: "skill",
			skill: "danshou",
			cardIds: [c[0].id],
			targets: [r]
		};
	}
	let fe = s("junxing");
	if (fe && c.length > 0 && Q(c[0]) <= 4) {
		let r = fe.targets.filter((r) => $(e, t, r, n) >= 2).sort((e, t) => i.seats[e].handCount - i.seats[t].handCount)[0];
		if (r != null) return {
			type: "skill",
			skill: "junxing",
			cardIds: [c[0].id],
			targets: [r]
		};
	}
	let E = s("xinmieji");
	if (E) {
		let r = c.find((e) => O(e.name) === "trick" && (e.suit === "spade" || e.suit === "club")), i = ES(e, t, E.targets, n);
		if (r && i != null) return {
			type: "skill",
			skill: "xinmieji",
			cardIds: [r.id],
			targets: [i]
		};
	}
	if (s("xinfencheng")) {
		let r = l.filter((r) => $(e, t, r, n) >= 2).length, i = l.filter((r) => $(e, t, r, n) < 0).length;
		if (r >= 2 && r >= i + 2) return {
			type: "skill",
			skill: "xinfencheng",
			cardIds: [],
			targets: []
		};
	}
	let pe = s("xiansi2");
	if (pe) {
		let r = ES(e, t, pe.targets, n);
		if (r != null) return {
			type: "skill",
			skill: "xiansi2",
			cardIds: [],
			targets: [r]
		};
	}
	let me = s("pindi");
	if (me && c.length > 0 && Q(c[0]) <= 4) {
		let r = DS(e, t, me.targets, n);
		if (r != null) return {
			type: "skill",
			skill: "pindi",
			cardIds: [c[0].id],
			targets: [r]
		};
	}
	if (s("shenxing") && c.length >= 2 && Q(c[0]) <= 3 && Q(c[1]) <= 3) return {
		type: "skill",
		skill: "shenxing",
		cardIds: [c[0].id, c[1].id],
		targets: []
	};
	let he = s("xianzhou");
	if (he) {
		let r = Object.values(i.seats[t].equips).filter((e) => e != null).length, a = he.targets.filter((r) => $(e, t, r, n) < 0 && i.seats[r].hp < i.seats[r].maxHp).sort((e, t) => i.seats[e].hp - i.seats[t].hp)[0];
		if (r >= 2 && a != null) return {
			type: "skill",
			skill: "xianzhou",
			cardIds: [],
			targets: [a]
		};
	}
	let ge = s("mingjian");
	if (ge && a.length >= 1 && a.length <= 3) {
		let r = DS(e, t, ge.targets, n);
		if (r != null) return {
			type: "skill",
			skill: "mingjian",
			cardIds: a.map((e) => e.id),
			targets: [r]
		};
	}
	let _e = s("zhanjue");
	if (_e && a.length > 0 && a.every((e) => Q(e) <= 4)) {
		let r = ES(e, t, _e.targets, n);
		if (r != null) return {
			type: "skill",
			skill: "zhanjue",
			cardIds: a.map((e) => e.id),
			targets: [r]
		};
	}
	let ve = s("wurong");
	if (ve) {
		let r = ES(e, t, ve.targets, n);
		if (r != null) return {
			type: "skill",
			skill: "wurong",
			cardIds: [],
			targets: [r]
		};
	}
	let ye = s("xinanguo");
	if (ye) {
		let r = ye.targets.filter((r) => $(e, t, r, n) < 0 && i.seats[r].hp < i.seats[r].maxHp).sort((e, t) => i.seats[e].hp - i.seats[t].hp)[0] ?? DS(e, t, ye.targets, n);
		if (r != null) return {
			type: "skill",
			skill: "xinanguo",
			cardIds: [],
			targets: [r]
		};
	}
	let be = s("yanzhu");
	if (be) {
		let r = ES(e, t, be.targets, n);
		if (r != null) return {
			type: "skill",
			skill: "yanzhu",
			cardIds: [],
			targets: [r]
		};
	}
	let xe = s("xinzhaofu");
	if (xe) {
		let r = xe.targets.filter((r) => $(e, t, r, n) >= 2).slice(0, xe.maxTargets);
		if (r.length >= 1) return {
			type: "skill",
			skill: "xinzhaofu",
			cardIds: [],
			targets: r
		};
	}
	if (s("huaiyi") && a.length >= 2) {
		let e = (e) => e.suit === "heart" || e.suit === "diamond", t = a.filter(e), n = a.filter((t) => !e(t)), r = t.length > 0 && n.length > 0 ? t.reduce((e, t) => e + Q(t), 0) <= n.reduce((e, t) => e + Q(t), 0) ? t : n : null;
		if (r != null && r.every((e) => Q(e) <= 4)) return {
			type: "skill",
			skill: "huaiyi",
			cardIds: [],
			targets: []
		};
	}
	let Se = s("jiaozhao");
	if (Se && Se.targets.length > 0 && a.length >= 1) {
		let r = (i.seats[t].marks?.xindanxin ?? 0) >= 2, a = DS(e, t, Se.targets, n), o = r && Se.targets.includes(t) ? t : a;
		if (o != null && c.length > 0) return {
			type: "skill",
			skill: "jiaozhao",
			cardIds: [c[0].id],
			targets: [o]
		};
	}
	let Ce = s("jiyu");
	if (Ce) {
		let r = ES(e, t, Ce.targets, n);
		if (r != null && i.seats[r].handCount > 0) return {
			type: "skill",
			skill: "jiyu",
			cardIds: [],
			targets: [r]
		};
	}
	let we = s("dcduliang");
	if (we) {
		let r = we.targets.filter((r) => $(e, t, r, n) >= 2 && i.seats[r].handCount > 0).sort((e, t) => i.seats[t].handCount - i.seats[e].handCount)[0];
		if (r != null) return {
			type: "skill",
			skill: "dcduliang",
			cardIds: [],
			targets: [r]
		};
	}
	let Te = s("kuangbi");
	if (Te) {
		let r = Te.targets.filter((r) => $(e, t, r, n) >= 2).sort((e, t) => i.seats[t].handCount - i.seats[e].handCount)[0];
		if (r != null) return {
			type: "skill",
			skill: "kuangbi",
			cardIds: [],
			targets: [r]
		};
	}
	if (s("jishe") && a.length <= 2) return {
		type: "skill",
		skill: "jishe",
		cardIds: [],
		targets: []
	};
	let Ee = s("zhige");
	if (Ee) {
		let r = ES(e, t, Ee.targets, n);
		if (r != null) return {
			type: "skill",
			skill: "zhige",
			cardIds: [],
			targets: [r]
		};
	}
	let De = s("zhongjian");
	if (De && c.length > 0) {
		let r = ES(e, t, De.targets, n);
		if (r != null && i.seats[r].handCount > 0) return {
			type: "skill",
			skill: "zhongjian",
			cardIds: [c[0].id],
			targets: [r]
		};
	}
	for (let r of ["qingxian", "canyun"]) {
		let a = s(r);
		if (!a || c.length === 0) continue;
		let o = a.targets.filter((r) => $(e, t, r, n) < 0 && i.seats[r].hp < i.seats[r].maxHp);
		if (o.length > 0) return {
			type: "skill",
			skill: a.id,
			cardIds: [c[0].id],
			targets: [o[0]]
		};
	}
	let D = s("wengua");
	if (D && c.length > 0) {
		let r = D.targets[0];
		if (r != null && $(e, t, r, n) < 0) return {
			type: "skill",
			skill: "wengua",
			cardIds: [c[0].id],
			targets: [r]
		};
	}
	return null;
}
//#endregion
//#region src/games/sanguosha/bot/respond.ts
function BS(e, t, n) {
	let r = e.public.pending, i = e.private.act, a = i.respondable ?? [];
	switch (r.kind) {
		case "jink": {
			let t = r.ctx.from;
			if (t != null && e.public.seats[t]?.zishou) return { type: "respond" };
			if ((i.choosableOptions ?? []).includes("eight_diagram")) return {
				type: "choose",
				option: "eight_diagram"
			};
			if (!a.length) return { type: "respond" };
			let n = a.find((e) => !e.as) ?? a[0];
			return {
				type: "respond",
				cardId: n.cardId,
				...n.as ? { as: n.as } : {}
			};
		}
		case "slash-response": {
			let i = r.ctx.collateral;
			if (i && $(e, t, i.b, n) < 0) return { type: "respond" };
			let o = r.ctx.from;
			return o != null && e.public.seats[o]?.zishou && r.ctx.duel == null || !a.length ? { type: "respond" } : {
				type: "respond",
				cardId: a[0].cardId,
				...a[0].as ? { as: a[0].as } : {}
			};
		}
		case "peach-save": {
			let o = r.ctx.target;
			if (o === t && a.length === 0 && (i.choosableOptions ?? []).includes("jiushi")) return {
				type: "choose",
				option: "jiushi"
			};
			let s = $(e, t, o, n);
			if (!(o === t || s < 0 || e.private.identity === "rebel" && s <= 0 && e.public.seats[o]?.identity !== "lord") || !a.length) return { type: "respond" };
			let c = e.public.seats.length, l = (() => {
				for (let r = 1; r < c; r++) {
					let i = (t + r) % c;
					if (i === o) break;
					if (e.public.seats[i].alive && $(e, t, i, n) < 0 && CS(e.public, i).some((e) => e.name === "peach")) return !0;
				}
				return !1;
			})();
			if (o !== t && l) return { type: "respond" };
			let u = a.find((e) => !e.as) ?? a[0];
			return {
				type: "respond",
				cardId: u.cardId,
				...u.as ? { as: u.as } : {}
			};
		}
		case "nullification": {
			let i = r.ctx.trick, o = r.ctx.target, s = r.ctx.from, c = r.ctx.chain ?? 0, l = /* @__PURE__ */ new Set([
				"snatch",
				"dismantlement",
				"duel",
				"collateral",
				"fire_attack",
				"indulgence",
				"supply_shortage",
				"savage_assault",
				"archery_attack",
				"lightning",
				"iron_chain"
			]), u = {
				indulgence: 8,
				lightning: 7,
				snatch: 6
			};
			if (!a.length) return { type: "respond" };
			let d = o == null ? 1 : $(e, t, o, n), f = $(e, t, s, n), p = o === s && (i === "indulgence" || i === "supply_shortage" || i === "lightning"), m = a.find((e) => !e.as) ?? a[0];
			if (c % 2 == 0) {
				if (o != null && l.has(i) && (p ? d < 0 : d < 0 && f >= 0)) return {
					type: "respond",
					cardId: m.cardId,
					...m.as ? { as: m.as } : {}
				};
			} else if (o != null && (p || f < 0) && d > 0 && (u[i] ?? 0) >= 6) return {
				type: "respond",
				cardId: m.cardId,
				...m.as ? { as: m.as } : {}
			};
			return { type: "respond" };
		}
		case "lord-call": return $(e, t, e.public.seats.findIndex((e) => e.identity === "lord"), n) < 0 && a.length ? {
			type: "respond",
			cardId: a[0].cardId,
			...a[0].as ? { as: a[0].as } : {}
		} : { type: "respond" };
		case "guicai": return { type: "respond" };
		default: return null;
	}
}
function VS(e, t, n) {
	let r = e.public.pending, i = r.ctx.skill, a = i.startsWith("re_") ? i.slice(3) : i, o = r.ctx.data ?? {}, s = e.public.seats, c = s.some((r, i) => $(e, t, i, n) >= 2), l = () => ({
		type: "choose",
		option: "use"
	});
	switch (a) {
		case "tuntian":
		case "leiji":
		case "niepan":
		case "jiewei": return c || a !== "leiji" ? l() : null;
		case "yiji":
		case "jieming": return l();
		case "jianxiong": return {
			type: "choose",
			option: r.ctx.options?.includes("obtain") ? "obtain" : "draw"
		};
		case "fangzhu": return c ? l() : null;
		case "luoshen":
		case "guanxing": return l();
		case "yinghun": return DS(e, t, s.map((e, t) => t).filter((e) => e !== t && s[e].alive), n) == null ? null : l();
		case "tieji":
		case "liegong": return l();
		case "shensu1": {
			let r = s[t].judges.some((e) => e.name === "indulgence" || e.name === "supply_shortage"), i = s.some((r, i) => i !== t && r.alive && r.hp <= 1 && $(e, t, i, n) >= 2);
			return r || i ? l() : null;
		}
		case "shensu2": return s.some((r, i) => i !== t && r.alive && r.hp <= 1 && $(e, t, i, n) >= 2) ? l() : null;
		case "qianxun": {
			let r = o.ev ?? {}, i = r.name, a = r.from;
			return i === "fire_attack" || (i === "snatch" || i === "dismantlement") && a != null && $(e, t, a, n) > 0 && e.private.hand.length >= 3 ? l() : null;
		}
		case "fangquan": {
			let r = DS(e, t, s.map((e, t) => t).filter((e) => e !== t && s[e].alive), n);
			return e.private.hand.length <= 2 && r != null ? l() : null;
		}
		case "fenji": {
			let r = o.victim;
			return r != null && (r === t || $(e, t, r, n) < 0) && s[t].hp >= 2 ? l() : null;
		}
		case "fenwei": {
			let r = o.name, i = o.from, a = o.targets ?? [];
			return i == null || $(e, t, i, n) <= 0 ? null : r === "savage_assault" || r === "archery_attack" ? a.some((r) => $(e, t, r, n) < 0) ? l() : null : (r === "god_salvation" || r === "amazing_grace") && a.some((r) => $(e, t, r, n) >= 2) ? l() : null;
		}
		case "liyu": {
			let r = o.source;
			return r != null && $(e, t, r, n) < 0 ? l() : null;
		}
		case "fanjian-discard": {
			let n = o.suit;
			return {
				type: "choose",
				option: e.private.hand.filter((e) => e.suit === n).length <= 1 || s[t].hp <= 1 ? "show-discard" : "lose-hp"
			};
		}
		case "fankui":
		case "ganglie":
		case "lieren":
		case "mengjin": {
			let r = o.from ?? o.source ?? null;
			return r == null || $(e, t, r, n) > 0 ? l() : null;
		}
		case "axe": {
			let r = o.target;
			return r == null || $(e, t, r, n) < 2 ? null : s[r].hp <= 2 || e.private.hand.length >= 4 ? l() : null;
		}
		case "beige": {
			let r = MS(e.public);
			return r != null && $(e, t, r, n) <= 0 ? l() : null;
		}
		case "tianxiang": {
			let n = e.private.hand;
			return c && s[t].hp > 1 && n.some((e) => e.suit === "heart") ? l() : null;
		}
		case "baonue": {
			let r = s.findIndex((e) => e.generalId === "dongzhuo" || e.generalId === "re_dongzhuo");
			return r >= 0 && $(e, t, r, n) < 0 ? l() : null;
		}
		case "songwei": {
			let r = s.findIndex((e) => e.generalId === "caopi" || e.generalId === "re_caopi");
			return r >= 0 && $(e, t, r, n) < 0 ? l() : null;
		}
		case "liuli": {
			let r = null;
			for (let n = e.public.log.length - 1; n >= 0; n--) {
				let i = e.public.log[n];
				if (i.kind === "slash" && i.seat != null && i.target === t) {
					r = i.seat;
					break;
				}
			}
			let i = s[t].equips.weapon?.name, a = (i == null ? void 0 : Ae[i]) ?? 1, o = s.map((e, t) => e.alive ? t : -1).filter((e) => e >= 0), c = o.indexOf(t);
			return o.some((i) => {
				if (i === t || i === r) return !1;
				let l = Math.abs(o.indexOf(i) - c), u = Math.min(l, o.length - l);
				return s[i].equips.def_horse != null && (u += 1), s[t].equips.off_horse != null && --u, Math.max(1, u) <= a && $(e, t, i, n) > 0;
			}) ? l() : null;
		}
		case "qingjian": return DS(e, t, s.map((e, t) => t).filter((e) => e !== t && s[e].alive), n) == null ? null : l();
		case "jushou": return s[t].handCount <= 2 || s[t].hp >= 3 ? l() : null;
		case "tishen": return s[t].hp < s[t].maxHp ? l() : null;
		case "zhiji": return {
			type: "choose",
			option: s[t].hp <= 1 ? "recover" : "draw2"
		};
		case "benghuai": return {
			type: "choose",
			option: s[t].maxHp > 3 ? "maxhp" : "hp"
		};
		case "yinghun-mode": return {
			type: "choose",
			option: "draw-x"
		};
		case "yijue-heal": {
			let r = o.target;
			return r != null && $(e, t, r, n) < 0 ? l() : null;
		}
		case "zhiba-obtain": return l();
		case "ganglie-choice": {
			let n = e.private.hand;
			return s[t].hp > 2 || n.length < 2 ? {
				type: "choose",
				option: "gl-damage"
			} : {
				type: "choose",
				option: "gl-discard"
			};
		}
		case "haoshi": {
			if (s[t].handCount + 4 < 5) return l();
			let r = s.map((e, t) => ({
				s: e,
				i: t
			})).filter((e) => e.i !== t && e.s.alive);
			if (r.length === 0) return l();
			let i = Math.min(...r.map((e) => e.s.handCount));
			return r.some((r) => r.s.handCount === i && $(e, t, r.i, n) < 0) ? l() : null;
		}
		case "double_sword": {
			let i = r.ctx.target;
			return i != null && $(e, t, i, n) > 0 ? l() : null;
		}
		case "double_sword-choice": {
			let i = r.ctx.from;
			return i != null && $(e, t, i, n) <= 0 ? {
				type: "choose",
				option: "ds-draw"
			} : {
				type: "choose",
				option: "ds-discard"
			};
		}
		case "ice_sword": {
			let r = o.target;
			return r == null || $(e, t, r, n) < 2 || s[r].hp <= 1 ? null : l();
		}
		case "kuanggu": return {
			type: "choose",
			option: s[t].hp < s[t].maxHp ? "recover" : "draw"
		};
		case "botu":
		case "piaoling":
		case "jiezi-mark":
		case "shebian":
		case "jiewei-jie": return l();
		case "luanwu-jie": return c ? l() : null;
		case "jiang-obtain": return s[t].hp >= 3 ? l() : null;
		case "xingshang-jie": {
			let e = r.ctx.options ?? [], n = o.cards ?? [];
			return e.includes("xs-obtain") && (n.length >= 2 || s[t].hp > 1) ? {
				type: "choose",
				option: "xs-obtain"
			} : {
				type: "choose",
				option: e.includes("recover") ? "recover" : e[0]
			};
		}
		case "qinxue-jie":
		case "hunzi-bonus": return {
			type: "choose",
			option: s[t].hp <= 1 ? "recover" : "draw2"
		};
		case "jiuyuan-choice": {
			let i = o.lord, a = r.ctx.options ?? [];
			return {
				type: "choose",
				option: i != null && $(e, t, i, n) < 0 ? "lord" : a[0] ?? "self"
			};
		}
		case "tianxiang-mode": {
			let r = o.t;
			if (r == null) return {
				type: "choose",
				option: "transfer"
			};
			let i = s[r].maxHp - s[r].hp;
			return {
				type: "choose",
				option: $(e, t, r, n) > 0 && i >= 2 ? "losehp" : "transfer"
			};
		}
		case "fangzhu-choice": {
			let i = r.ctx.options ?? [], a = o.from, c = o.x ?? 0;
			if (i.includes("drop-lose") && a != null && $(e, t, a, n) >= 0) {
				let e = s[t].handCount + Object.values(s[t].equips).filter(Boolean).length;
				if (c <= 2 && s[t].hp >= 2 && e >= c) return {
					type: "choose",
					option: "drop-lose"
				};
			}
			return {
				type: "choose",
				option: "draw-flip"
			};
		}
		case "niepan-pick": return {
			type: "choose",
			option: "bazhen"
		};
		case "piaoling-choice": return {
			type: "choose",
			option: DS(e, t, s.map((e, t) => t).filter((e) => s[e].alive), n) == null ? "top" : "give"
		};
		case "zaiqi-jie-choice": {
			let r = o.lord;
			return {
				type: "choose",
				option: r != null && $(e, t, r, n) < 0 && s[r].hp < s[r].maxHp ? "heal" : "draw"
			};
		}
		case "shensu3": return s.some((r, i) => i !== t && r.alive && r.hp <= 1 && $(e, t, i, n) >= 2) ? l() : null;
		case "qimou-x": return {
			type: "choose",
			option: s[t].hp >= 4 ? "2" : "1"
		};
		case "wulie-x": return s[t].hp >= 3 ? {
			type: "choose",
			option: "1"
		} : null;
		case "rende-basic": {
			let e = r.ctx.options ?? [];
			return e.includes("peach") ? {
				type: "choose",
				option: "peach"
			} : e.includes("slash") && c ? {
				type: "choose",
				option: "slash"
			} : e.length > 0 ? {
				type: "choose",
				option: e[0]
			} : null;
		}
		case "green_dragon": {
			let r = o.target;
			return r == null || $(e, t, r, n) < 2 ? null : l();
		}
		case "shangshi": return l();
		case "buyi": {
			let r = o.target;
			return r != null && (r === t || $(e, t, r, n) < 0) ? l() : null;
		}
		case "xinpojun": {
			let r = o.target;
			return r != null && $(e, t, r, n) >= 2 ? l() : null;
		}
		case "rezhenjun": return s.some((r, i) => i !== t && r.alive && $(e, t, i, n) >= 2 && r.handCount > r.hp) ? l() : null;
		case "xuanfeng": return c ? l() : null;
		case "xinxuanhuo":
		case "xinjujian": return DS(e, t, s.map((e, t) => t).filter((e) => e !== t && s[e].alive), n) == null ? null : l();
		case "xinenyuan-ask": {
			let r = o.source;
			return r != null && $(e, t, r, n) >= 2 ? l() : null;
		}
		case "xinenyuan": return {
			type: "choose",
			option: (r.ctx.options ?? []).includes("ey-give") ? "ey-give" : "ey-losehp"
		};
		case "mingce-choice": return {
			type: "choose",
			option: "mc-draw"
		};
		case "jujian-choice": {
			let e = s[t];
			return e.turnedOver || e.chained ? {
				type: "choose",
				option: "jj-reset"
			} : e.hp < e.maxHp && e.hp <= 2 ? {
				type: "choose",
				option: "jj-recover"
			} : {
				type: "choose",
				option: "jj-draw"
			};
		}
		case "rezhenjun-choice": {
			let t = o.y ?? 0;
			return {
				type: "choose",
				option: e.private.hand.length >= t ? "zj-discard" : "zj-draw"
			};
		}
		case "zhenlie": {
			let r = (o.resume ?? {}).from;
			return r != null && $(e, t, r, n) > 0 && s[t].hp >= 2 ? l() : null;
		}
		case "qianxi": return l();
		case "rezishou": {
			let r = e.private.hand.some((e) => A(e.name) || e.name === "duel" || e.name === "fire_attack" || e.name === "savage_assault" || e.name === "archery_attack"), i = e.public.seats.some((r, i) => r.alive && i !== t && $(e, t, i, n) >= 2);
			return r && i ? null : l();
		}
		case "fuli": return l();
		case "chunlao-save": {
			let r = o.target;
			return r != null && (r === t || $(e, t, r, n) < 0) ? l() : null;
		}
		case "zhiyu":
		case "quanji": return l();
		case "new_jiangchi": return {
			type: "choose",
			option: e.private.hand.some((e) => A(e.name)) ? "jc-less" : "jc-more"
		};
		case "zili": return {
			type: "choose",
			option: s[t].hp < s[t].maxHp && s[t].hp <= 2 ? "recover" : "draw2"
		};
		case "qice-pick": {
			let i = r.ctx.options ?? [], a = s.filter((r, i) => i !== t && r.alive && $(e, t, i, n) >= 2).length, o = s.filter((r, i) => i !== t && r.alive && $(e, t, i, n) < 0).length;
			return {
				type: "choose",
				option: i.includes("ex_nihilo") ? "ex_nihilo" : a > o && i.includes("savage_assault") ? "savage_assault" : a > o && i.includes("archery_attack") ? "archery_attack" : i.includes("dismantlement") ? "dismantlement" : i[0]
			};
		}
		case "jiefan-step": {
			let r = o.target;
			return r != null && (r === t || $(e, t, r, n) < 0) ? {
				type: "choose",
				option: "jf-draw"
			} : null;
		}
		case "rejingce":
		case "chengxiang":
		case "yuce":
		case "zongxuan": return l();
		case "renxin": {
			let r = (o.ev ?? {}).target;
			return r != null && (r === t || $(e, t, r, n) < 0) ? l() : null;
		}
		case "qiuyuan": {
			let r = (o.info ?? {}).from;
			return r != null && $(e, t, r, n) > 0 ? l() : null;
		}
		case "qiuyuan-choice": return {
			type: "choose",
			option: (r.ctx.options ?? []).includes("qy-give") ? "qy-give" : "qy-target"
		};
		case "zhuikong": {
			let r = o.target;
			return r != null && $(e, t, r, n) >= 2 && e.private.hand.some((e) => e.point >= 10) ? l() : null;
		}
		case "qiaoshui": {
			let t = e.private.hand;
			return !t.some((e) => O(e.name) === "trick") || t.some((e) => e.point >= 10) ? l() : null;
		}
		case "xiansi": return l();
		case "zhiyan":
		case "xinjuece": return l();
		case "duodao": {
			let r = o.source;
			return r != null && $(e, t, r, n) > 0 ? l() : null;
		}
		case "longyin": {
			let r = o.from;
			return r != null && (r === t || $(e, t, r, n) < 0) ? l() : null;
		}
		case "junxing-choice": {
			let e = r.ctx.options ?? [];
			return s[t].turnedOver ? {
				type: "choose",
				option: "jx-flip"
			} : {
				type: "choose",
				option: e.includes("jx-discard") ? "jx-discard" : "jx-flip"
			};
		}
		case "xinmieji-choice": {
			let t = r.ctx.options ?? [], n = e.private.hand.find((e) => O(e.name) === "trick" && Q(e) <= 5);
			return t.includes("mj-trick") && n ? {
				type: "choose",
				option: "mj-trick"
			} : {
				type: "choose",
				option: t.includes("mj-drop2") ? "mj-drop2" : t[0]
			};
		}
		case "fencheng-step": {
			let e = o.need ?? 1;
			return {
				type: "choose",
				option: (r.ctx.options ?? []).includes("fc-discard") && (e <= 2 || s[t].hp <= 2) ? "fc-discard" : "fc-damage"
			};
		}
		case "yuce-source": {
			let i = (o.chain ?? {}).seat, a = r.ctx.options ?? [];
			return i != null && (i === t || $(e, t, i, n) < 0) ? {
				type: "choose",
				option: a.includes("yc-recover") ? "yc-recover" : a[0]
			} : {
				type: "choose",
				option: a.includes("yc-discard") ? "yc-discard" : a[0]
			};
		}
		case "yonglve": {
			let r = o.target;
			return r != null && $(e, t, r, n) >= 2 ? l() : null;
		}
		case "shenduan": return (o.candidates ?? []).some((r) => $(e, t, r, n) >= 2) ? l() : null;
		case "faen": {
			let r = o.target;
			return r != null && (r === t || $(e, t, r, n) < 0) ? l() : null;
		}
		case "olbingyi": {
			let t = new Set(e.private.hand.map((e) => e.suit === "heart" || e.suit === "diamond" ? "r" : "b"));
			return e.private.hand.length > 0 && t.size === 1 ? l() : null;
		}
		case "xinsidi": {
			let r = o.target;
			return r != null && $(e, t, r, n) >= 2 ? l() : null;
		}
		case "qiangzhi": return l();
		case "xiantu": {
			let r = o.target;
			return r != null && $(e, t, r, n) < 0 ? l() : null;
		}
		case "fenli-draw": return e.private.hand.length >= 3 ? l() : null;
		case "fenli-play": return e.private.hand.some((e) => [
			"slash",
			"duel",
			"fire_attack",
			"savage_assault",
			"archery_attack"
		].includes(e.name)) ? null : l();
		case "fenli-discard": return l();
		case "pingkou": return c ? l() : null;
		case "olbenxi": return {
			type: "choose",
			option: "bx-both"
		};
		case "chanhui": return (o.candidates ?? []).some((r) => $(e, t, r, n) >= 2) ? l() : null;
		case "chanhui-choice": {
			let i = r.ctx.options ?? [], a = o.from;
			return a != null && $(e, t, a, n) < 0 && i.includes("ch-give") ? {
				type: "choose",
				option: "ch-give"
			} : {
				type: "choose",
				option: i.includes("ch-target") ? "ch-target" : i[0]
			};
		}
		case "jiaojin": return ((o.ev ?? {}).amount ?? 1) >= 2 || s[t].hp <= 2 ? l() : null;
		case "xinzhongyong": return (o.candidates ?? []).some((r) => r === t || $(e, t, r, n) < 0) ? l() : null;
		case "zy-slash": return (o.candidates ?? []).some((r) => $(e, t, r, n) >= 2) ? l() : null;
		case "qieting": {
			let i = r.ctx.options ?? [], a = o.target;
			return a != null && $(e, t, a, n) >= 2 && i.includes("qt-move") ? {
				type: "choose",
				option: "qt-move"
			} : {
				type: "choose",
				option: "qt-draw"
			};
		}
		case "pindi-choice": {
			let i = r.ctx.options ?? [], a = o.target;
			return a != null && $(e, t, a, n) >= 2 && i.includes("pd-discard") ? {
				type: "choose",
				option: "pd-discard"
			} : {
				type: "choose",
				option: "pd-draw"
			};
		}
		case "xianzhou-choice": {
			let e = r.ctx.options ?? [];
			return s[t].hp < s[t].maxHp || !e.includes("xz-damage") ? {
				type: "choose",
				option: "xz-heal"
			} : {
				type: "choose",
				option: "xz-damage"
			};
		}
		case "qingxi": {
			let n = o.x ?? 1;
			return s[t].hp <= 1 || n <= 2 && e.private.hand.length >= n + 2 ? {
				type: "choose",
				option: "qx-discard"
			} : {
				type: "choose",
				option: "qx-plus"
			};
		}
		case "yanzhu-choice": {
			let e = Object.values(s[t].equips).filter((e) => e != null).length, n = r.ctx.options ?? [];
			return e < 3 && n.includes("yz-give") ? {
				type: "choose",
				option: "yz-give"
			} : {
				type: "choose",
				option: "yz-discard"
			};
		}
		case "huaiyi-color": {
			let t = r.ctx.options ?? [], n = (t) => e.private.hand.filter((e) => (e.suit === "heart" || e.suit === "diamond") === t).reduce((e, t) => e + Q(t), 0);
			return {
				type: "choose",
				option: n(!0) <= n(!1) && t.includes("hy-red") ? "hy-red" : "hy-black"
			};
		}
		case "jigong": {
			let t = e.private.hand.filter((e) => O(e.name) !== "equip").length, n = e.private.hand.some((e) => e.name === "peach");
			return t <= 2 && !n ? l() : null;
		}
		case "huituo": return l();
		case "qiaoshi": {
			let r = o.target;
			return r == null || $(e, t, r, n) <= 0 ? l() : null;
		}
		case "xingshuai": {
			let r = o.lord;
			return r != null && $(e, t, r, n) < 0 ? l() : null;
		}
		case "danxin": return {
			type: "choose",
			option: "dx-draw"
		};
		case "guizao": {
			let e = r.ctx.options ?? [];
			return s[t].hp < s[t].maxHp && e.includes("gz-recover") ? {
				type: "choose",
				option: "gz-recover"
			} : {
				type: "choose",
				option: "gz-draw"
			};
		}
		case "huisheng": {
			let i = o.offerer, a = r.ctx.options ?? [];
			return i != null && $(e, t, i, n) < 0 ? {
				type: "choose",
				option: "hs-take"
			} : a.includes("hs-discard") ? {
				type: "choose",
				option: "hs-discard"
			} : {
				type: "choose",
				option: "hs-take"
			};
		}
		case "jiaozhao-name": {
			let i = r.ctx.options ?? [], a = o.holder, s = a != null && $(e, t, a, n) > 0 ? "peach" : "slash";
			return {
				type: "choose",
				option: i.includes(s) ? s : i[0]
			};
		}
		case "zhige": {
			let i = r.ctx.options ?? [], a = o.from;
			return a != null && $(e, t, a, n) > 0 ? {
				type: "choose",
				option: i.includes("zg-slash") ? "zg-slash" : i[0]
			} : {
				type: "choose",
				option: i.includes("zg-give") ? "zg-give" : i[0]
			};
		}
		case "dcduliang": {
			let r = o.target;
			return r != null && $(e, t, r, n) < 0 ? {
				type: "choose",
				option: "dl-view"
			} : {
				type: "choose",
				option: "dl-next"
			};
		}
		case "caishi": {
			let t = r.ctx.options ?? [];
			return e.private.hand.length <= 1 && t.includes("cs-more") ? {
				type: "choose",
				option: "cs-more"
			} : {
				type: "choose",
				option: t.includes("cs-less") ? "cs-less" : t[0]
			};
		}
		case "fumian": {
			let t = r.ctx.options ?? [];
			return e.private.hand.some((e) => A(e.name) && (e.suit === "heart" || e.suit === "diamond")) && c && t.includes("fm-red") ? {
				type: "choose",
				option: "fm-red"
			} : {
				type: "choose",
				option: t.includes("fm-draw") ? "fm-draw" : t[0]
			};
		}
		case "zhuandui": {
			let r = o.from, i = o.target;
			return r == null || i == null ? null : $(e, t, t === r ? i : r, n) > 0 ? l() : null;
		}
		case "tianbian-choice": return {
			type: "choose",
			option: e.private.hand.some((e) => e.suit === "heart") ? "tb-hand" : "tb-top"
		};
		case "funan": {
			let r = o.responder;
			return r != null && $(e, t, r, n) > 0 ? l() : null;
		}
		case "fuzhu": {
			let r = o.target;
			return r != null && $(e, t, r, n) >= 2 ? l() : null;
		}
		case "huimin":
		case "bizhuan":
		case "tongbo": return l();
		case "shouxi": {
			let e = r.ctx.options ?? [];
			return {
				type: "choose",
				option: e.includes("peach") ? "peach" : e[0]
			};
		}
		case "wengua-place": return {
			type: "choose",
			option: "wg-bottom"
		};
		default: return null;
	}
}
//#endregion
//#region src/games/sanguosha/bot/skill-cards.ts
function HS(e, t, n) {
	let r = e.private.hand, i = t.map((e) => r.find((t) => t.id === e)).filter((e) => e != null);
	return i.length ? (i.sort((e, t) => t.point - e.point), (n ? i[0] : i[i.length - 1]).id) : t[0];
}
var US = (e) => new Map((e.knownCards ?? []).filter((e) => e.name != null).map((e) => [e.id, e]));
function WS(e, t, n) {
	let r = e.public.pending, i = e.private.act, a = r.ctx.skill, o = a?.startsWith("re_") ? a.slice(3) : a, s = r.ctx.data ?? {}, c = i.choosableCards ?? [], l = r.ctx.min ?? 0, u = e.private.hand, d = e.public.seats[t]?.equips, f = d ? Object.values(d).filter((e) => e != null) : [], p = xS([...u, ...f].filter((e) => c.includes(e.id))), m = (e) => ({
		type: "choose",
		cardIds: p.slice(0, e).map((e) => e.id)
	});
	switch (o) {
		case "tianyi":
		case "lieren":
		case "xinxianzhen": return {
			type: "choose",
			cardIds: [HS(e, c, !0)]
		};
		case "zhiba": return {
			type: "choose",
			cardIds: [HS(e, c, !0)]
		};
		case "quhu": {
			let r = s.from;
			if (r == null || $(e, t, r, n) >= 0) return {
				type: "choose",
				cardIds: [HS(e, c, !0)]
			};
			let i = e.public.seats;
			return {
				type: "choose",
				cardIds: [HS(e, c, i[r].hp >= 2 && i.some((i, a) => i.alive && (a === r || $(e, t, a, n) < 0) && i.maxHp - i.handCount >= 2))]
			};
		}
		case "gongxin": {
			let e = US(i), t = xS(c.map((t) => e.get(t)).filter((e) => e != null && e.suit === "heart"));
			return t.length > 0 ? {
				type: "choose",
				cardIds: [t[0].id]
			} : null;
		}
		case "yijue": return {
			type: "choose",
			cardIds: [c.map((e) => u.find((t) => t.id === e)).filter((e) => e != null && (e.suit === "heart" || e.suit === "diamond")).sort((e, t) => e.point - t.point)[0]?.id ?? c[0]]
		};
		case "yijue-jie-show": return {
			type: "choose",
			cardIds: [c.map((e) => u.find((t) => t.id === e)).filter((e) => e != null && (e.suit === "heart" || e.suit === "diamond")).sort((e, t) => e.point - t.point)[0]?.id ?? c[0]]
		};
		case "tieji-give": {
			let r = s.to;
			return r != null && $(e, t, r, n) < 0 ? {
				type: "choose",
				cardIds: []
			} : p.length > 0 ? m(1) : {
				type: "choose",
				cardIds: []
			};
		}
		case "shuangxiong-jie": return u.length >= 3 && p.length > 0 ? m(1) : {
			type: "choose",
			cardIds: []
		};
		case "ninge": {
			let r = s.target;
			if (r == null || c.length === 0) return {
				type: "choose",
				cardIds: []
			};
			if ($(e, t, r, n) >= 2) return {
				type: "choose",
				cardIds: [c[0]]
			};
			let i = e.public.seats[r].judges.map((e) => e.id);
			return {
				type: "choose",
				cardIds: [c.find((e) => i.includes(e)) ?? c[0]]
			};
		}
		case "beige-jie-discard": {
			let r = (s.ev ?? {}).target;
			return r != null && $(e, t, r, n) <= 0 && p.length > 0 ? m(1) : {
				type: "choose",
				cardIds: []
			};
		}
		case "guanxing": return {
			type: "choose",
			cardIds: c
		};
		case "yiji": {
			let e = Math.min(2, p.length);
			return e > 0 ? m(e) : {
				type: "choose",
				cardIds: []
			};
		}
		case "luanwu-slash": {
			let n = u.find((e) => c.includes(e.id) && A(e.name));
			return n && (e.public.seats[t].hp <= 2 || u.filter((e) => A(e.name)).length > 1) ? {
				type: "choose",
				cardIds: [n.id]
			} : {
				type: "choose",
				cardIds: []
			};
		}
		case "fire_attack-discard": {
			let r = s.target;
			return r != null && $(e, t, r, n) >= 2 && p.length > 0 ? m(1) : {
				type: "choose",
				cardIds: []
			};
		}
		case "tieji-discard": {
			let n = e.public.seats[t].equips.armor, r = n?.name === "eight_diagram" || u.some((e) => e.name === "jink"), i = p.filter((e) => e.name !== "jink" && e.id !== n?.id);
			return r && i.length > 0 ? {
				type: "choose",
				cardIds: [i[0].id]
			} : {
				type: "choose",
				cardIds: []
			};
		}
		case "guzheng": {
			let r = s.seat, i = r != null && (r === t || $(e, t, r, n) < 0);
			return c.length > 0 && (i || c.length > 1) ? {
				type: "choose",
				cardIds: [c[0]]
			} : {
				type: "choose",
				cardIds: []
			};
		}
		case "jiewei-use": {
			let n = u.filter((e) => c.includes(e.id)), r = n.find((n) => {
				let r = k(n.name);
				return r != null && e.public.seats[t].equips[r] == null;
			}) ?? n.find((e) => e.name === "ex_nihilo");
			return r ? {
				type: "choose",
				cardIds: [r.id]
			} : {
				type: "choose",
				cardIds: []
			};
		}
		case "jiewei-discard": {
			let r = null, i = null;
			for (let a of c) for (let [o, s] of e.public.seats.entries()) s.alive && (r == null && (o === t || $(e, t, o, n) < 0) && s.judges.some((e) => e.id === a) && (r = a), i == null && $(e, t, o, n) >= 2 && Object.values(s.equips).some((e) => e?.id === a) && (i = a));
			let a = r ?? i;
			return a == null ? {
				type: "choose",
				cardIds: []
			} : {
				type: "choose",
				cardIds: [a]
			};
		}
		case "tiaoxin-slash": {
			let r = s.from, i = u.find((e) => c.includes(e.id));
			return r != null && $(e, t, r, n) > 0 && i ? {
				type: "choose",
				cardIds: [i.id]
			} : {
				type: "choose",
				cardIds: []
			};
		}
		case "xiangle": {
			let r = (s.info ?? {}).target, i = p.find((e) => O(e.name) === "basic");
			return i && r != null && $(e, t, r, n) >= 2 ? {
				type: "choose",
				cardIds: [i.id]
			} : {
				type: "choose",
				cardIds: []
			};
		}
		case "qiaobian-judge":
		case "qiaobian-discard": return m(1);
		case "xuanhuo-slash": {
			let r = s.victim;
			return r != null && $(e, t, r, n) >= 2 && c.length > 0 ? {
				type: "choose",
				cardIds: [c[0]]
			} : {
				type: "choose",
				cardIds: []
			};
		}
		case "xuanhuo-take": {
			let e = US(i), t = c.filter((t) => e.has(t)).sort((t, n) => Q(e.get(n)) - Q(e.get(t))), n = c.filter((t) => !e.has(t));
			return {
				type: "choose",
				cardIds: [...t, ...n].slice(0, l)
			};
		}
		case "qiaobian-draw": return e.public.seats.filter((r, i) => i !== t && r.alive && $(e, t, i, n) >= 2 && r.handCount > 0).length >= 2 ? m(1) : {
			type: "choose",
			cardIds: []
		};
		case "chengxiang-take": {
			let e = US(i), t = c.map((t) => e.get(t)).filter((e) => e != null);
			t.sort((e, t) => Q(t) - Q(e));
			let n = [], r = 0;
			for (let e of t) r + e.point <= 13 && (n.push(e.id), r += e.point);
			return {
				type: "choose",
				cardIds: n
			};
		}
		case "renxin-discard":
		case "longyin-discard":
		case "duodao-discard":
		case "junxing-discard":
		case "mieji-trick":
		case "yuce-source-discard": return p.length > 0 ? m(1) : {
			type: "choose",
			cardIds: []
		};
		case "mieji-drop2": return p.length >= 2 ? m(2) : c.length >= 2 ? {
			type: "choose",
			cardIds: c.slice(0, 2)
		} : null;
		case "qiuyuan-jink": return c.length > 0 ? {
			type: "choose",
			cardIds: [c[0]]
		} : {
			type: "choose",
			cardIds: []
		};
		case "zhuikong-pick":
		case "qiaoshui-pick": return {
			type: "choose",
			cardIds: [HS(e, c, !0)]
		};
		case "zhuikong-respond":
		case "qiaoshui-respond": {
			let r = s.from;
			return {
				type: "choose",
				cardIds: [HS(e, c, r == null || $(e, t, r, n) > 0)]
			};
		}
		case "danshou-give": return p.length > 0 ? m(1) : {
			type: "choose",
			cardIds: [c[0]]
		};
		case "zongxuan-put": {
			let e = US(i);
			return {
				type: "choose",
				cardIds: c.filter((t) => {
					let n = e.get(t);
					return n != null && Q(n) >= 5;
				})
			};
		}
		case "yuce-show": return {
			type: "choose",
			cardIds: [(p.find((e) => O(e.name) === "basic") ?? p[0])?.id ?? c[0]]
		};
		case "fencheng-discard": return p.length >= l ? m(l) : c.length >= l ? {
			type: "choose",
			cardIds: c.slice(0, l)
		} : null;
		case "shenduan-pick": return c.length > 0 ? {
			type: "choose",
			cardIds: [c[0]]
		} : {
			type: "choose",
			cardIds: []
		};
		case "sidi-discard":
		case "chanhui-give":
		case "jiaojin-discard": return p.length > 0 ? m(1) : c.length > 0 ? {
			type: "choose",
			cardIds: [c[0]]
		} : null;
		case "xiantu-give": return p.length >= 2 ? m(2) : {
			type: "choose",
			cardIds: c.slice(0, 2)
		};
		case "pindi-discard": return p.length >= l ? m(l) : {
			type: "choose",
			cardIds: c.slice(0, l)
		};
		case "qieting-move": {
			let e = US(i);
			return {
				type: "choose",
				cardIds: [c.map((t) => e.get(t)).filter((e) => e != null).sort((e, t) => Q(t) - Q(e))[0]?.id ?? c[0]]
			};
		}
		case "zy-card": {
			let e = US(i);
			return {
				type: "choose",
				cardIds: [c.map((t) => e.get(t)).find((e) => e != null && (e.suit === "heart" || e.suit === "diamond"))?.id ?? c[0]]
			};
		}
		case "wurong-pick": {
			let e = c.map((e) => u.find((t) => t.id === e)).find((e) => e != null && A(e.name));
			return {
				type: "choose",
				cardIds: [e ? e.id : p[0]?.id ?? c[0]]
			};
		}
		case "wurong-pick2": {
			let e = c.map((e) => u.find((t) => t.id === e)).find((e) => e != null && e.name === "jink");
			return {
				type: "choose",
				cardIds: [e ? e.id : p[0]?.id ?? c[0]]
			};
		}
		case "huisheng-offer": return p.length >= l ? m(l) : {
			type: "choose",
			cardIds: c.slice(0, l)
		};
		case "huisheng-pick": {
			let e = US(i);
			return {
				type: "choose",
				cardIds: [c.map((t) => e.get(t)).filter((e) => e != null).sort((e, t) => Q(t) - Q(e))[0]?.id ?? c[0]]
			};
		}
		case "huisheng-pay":
		case "jiyu-discard": return p.length >= l ? m(l) : {
			type: "choose",
			cardIds: c.slice(0, l)
		};
		case "kuangbi-put": {
			let i = s.from, a = i != null && $(e, t, i, n) < 0 ? Math.min(3, r.ctx.max ?? 1) : 1;
			return p.length >= a ? m(a) : {
				type: "choose",
				cardIds: c.slice(0, Math.max(1, Math.min(a, c.length)))
			};
		}
		case "taoluan-give": {
			let r = s.from;
			return r != null && $(e, t, r, n) > 0 ? {
				type: "choose",
				cardIds: []
			} : p.length > 0 ? m(1) : c.length > 0 ? {
				type: "choose",
				cardIds: [c[0]]
			} : {
				type: "choose",
				cardIds: []
			};
		}
		case "zg-slash-card": return {
			type: "choose",
			cardIds: [c.map((e) => u.find((t) => t.id === e)).filter((e) => e != null).sort((e, t) => Q(e) - Q(t))[0]?.id ?? c[0]]
		};
		case "zg-equip": return p.length > 0 ? m(1) : {
			type: "choose",
			cardIds: [c[0]]
		};
		case "jianzheng": {
			let r = s.from;
			if (r == null || $(e, t, r, n) <= 0) return {
				type: "choose",
				cardIds: []
			};
			let i = s.suit;
			return (i === "heart" || i === "diamond") && e.private.hand.length <= 1 ? {
				type: "choose",
				cardIds: []
			} : p.length > 0 ? m(1) : {
				type: "choose",
				cardIds: []
			};
		}
		case "zhuandui-card": return {
			type: "choose",
			cardIds: [HS(e, c, !0)]
		};
		case "zhuandui-respond": {
			let r = s.holder;
			return {
				type: "choose",
				cardIds: [HS(e, c, r == null || $(e, t, r, n) > 0)]
			};
		}
		case "zhongjian-drop":
		case "xinjiexun-discard": return p.length >= l ? m(l) : {
			type: "choose",
			cardIds: c.slice(0, l)
		};
		case "shouxi-discard": {
			let r = s.target;
			return r != null && $(e, t, r, n) <= 0 ? {
				type: "choose",
				cardIds: []
			} : p.length > 0 ? m(1) : {
				type: "choose",
				cardIds: []
			};
		}
		case "huimin-show": return p.length >= l ? m(l) : {
			type: "choose",
			cardIds: c.slice(0, l)
		};
		case "huimin-take": {
			let e = US(i);
			return {
				type: "choose",
				cardIds: [c.map((t) => e.get(t)).filter((e) => e != null).sort((e, t) => Q(t) - Q(e))[0]?.id ?? c[0]]
			};
		}
		case "tongbo-swap": return e.private.hand.length >= 3 && p.length > 0 ? m(1) : {
			type: "choose",
			cardIds: []
		};
		case "tongbo-take": return {
			type: "choose",
			cardIds: c.slice(0, l)
		};
		default: return l === 0 ? {
			type: "choose",
			cardIds: []
		} : p.length < l ? c.length >= l ? {
			type: "choose",
			cardIds: c.slice(0, l)
		} : null : m(l);
	}
}
//#endregion
//#region src/games/sanguosha/bot/skill-seats.ts
function GS(e, t, n) {
	let r = e.public.pending, i = e.private.act, a = r.ctx.skill, o = a?.startsWith("re_") ? a.slice(3) : a, s = i.choosableSeats ?? [], c = r.ctx.min ?? 0, l = r.ctx.max ?? 1;
	if (!s.length) return c === 0 ? { type: "pass" } : null;
	let u = ES(e, t, s, n), d = DS(e, t, s, n), f = [...s].sort((t, n) => e.public.seats[n].handCount - e.public.seats[t].handCount);
	switch (o) {
		case "zhuiyi-target": return d == null ? { type: "pass" } : {
			type: "choose",
			seats: [d]
		};
		case "lianying":
		case "yiji":
		case "yiji-give":
		case "qingjian":
		case "haoshi":
		case "yajiao-give":
		case "jiezi":
		case "jujian-target":
		case "xuanhuo-target":
		case "miji-target": return d == null ? c === 0 ? { type: "pass" } : {
			type: "choose",
			seats: [s[0]]
		} : {
			type: "choose",
			seats: [d]
		};
		case "rezhenjun-target": {
			let r = f.filter((r) => $(e, t, r, n) >= 2 && e.public.seats[r].handCount > e.public.seats[r].hp);
			return r.length > 0 ? {
				type: "choose",
				seats: [r[0]]
			} : u == null ? {
				type: "choose",
				seats: [s.includes(t) ? t : s[0]]
			} : {
				type: "choose",
				seats: [u]
			};
		}
		case "xuanfeng-target": {
			let r = f.filter((r) => $(e, t, r, n) >= 2).slice(0, l);
			return r.length >= c ? {
				type: "choose",
				seats: r
			} : {
				type: "choose",
				seats: s.slice(0, c)
			};
		}
		case "piaoling-give": return d == null ? s.includes(t) ? {
			type: "choose",
			seats: [t]
		} : {
			type: "choose",
			seats: [s[0]]
		} : {
			type: "choose",
			seats: [d]
		};
		case "wulie-targets": {
			let i = (r.ctx.data ?? {}).x ?? Math.max(1, c);
			return {
				type: "choose",
				seats: [...s].sort((r, i) => $(e, t, r, n) - $(e, t, i, n)).slice(0, i)
			};
		}
		case "zaiqi-jie": {
			let r = s.filter((r) => r === t || $(e, t, r, n) < 0).slice(0, l);
			return r.length > 0 ? {
				type: "choose",
				seats: r
			} : c === 0 ? { type: "pass" } : {
				type: "choose",
				seats: s.slice(0, c)
			};
		}
		case "jieming": {
			let t = (t) => e.public.seats[t].maxHp - e.public.seats[t].handCount;
			return {
				type: "choose",
				seats: [[...s].sort((e, n) => t(n) - t(e))[0]]
			};
		}
		case "leiji":
		case "leiji-jie-spade":
		case "leiji-jie-club":
		case "tianxiang-target":
		case "jiewei-target":
		case "shensu-slash":
		case "tianyi-extra":
		case "liyu":
		case "quhu-damage":
		case "yajiao-drop":
		case "luanwu-jie-target":
		case "rende-slash": return u == null ? c === 0 ? { type: "pass" } : {
			type: "choose",
			seats: [s[0]]
		} : {
			type: "choose",
			seats: [u]
		};
		case "fangzhu": {
			let r = e.public.seats[t].maxHp - e.public.seats[t].hp, i = s.filter((r) => $(e, t, r, n) < 0);
			if (r >= 2 && i.length > 0) {
				let t = i.filter((t) => e.public.seats[t].turnedOver), n = t.length > 0 ? t : i;
				return n.sort((t, n) => e.public.seats[t].handCount - e.public.seats[n].handCount), {
					type: "choose",
					seats: [n[0]]
				};
			}
			let a = ES(e, t, s.filter((t) => !e.public.seats[t].turnedOver), n);
			return a == null ? {
				type: "choose",
				seats: [u ?? s[0]]
			} : {
				type: "choose",
				seats: [a]
			};
		}
		case "yinghun": return d == null ? {
			type: "choose",
			seats: [s[0]]
		} : {
			type: "choose",
			seats: [d]
		};
		case "fangquan-target": return d == null ? {
			type: "choose",
			seats: [s[0]]
		} : {
			type: "choose",
			seats: [d]
		};
		case "fenwei": {
			let i = (r.ctx.data ?? {}).name, a = i === "savage_assault" || i === "archery_attack", o = s.filter((r) => a ? r === t || $(e, t, r, n) < 0 : $(e, t, r, n) >= 2);
			return o.length >= Math.max(1, c) ? {
				type: "choose",
				seats: o.slice(0, l)
			} : c === 0 ? { type: "pass" } : {
				type: "choose",
				seats: s.slice(0, c)
			};
		}
		case "liuli-target": return {
			type: "choose",
			seats: [[...s].sort((r, i) => $(e, t, i, n) - $(e, t, r, n))[0]]
		};
		case "tuxi":
		case "qiaobian-draw": {
			let r = f.filter((r) => $(e, t, r, n) >= 2 && e.public.seats[r].handCount > 0).slice(0, l);
			return r.length >= c ? {
				type: "choose",
				seats: r
			} : c === 0 ? { type: "pass" } : {
				type: "choose",
				seats: f.slice(0, c)
			};
		}
		case "luanwu-target": return {
			type: "choose",
			seats: [u ?? s[0]]
		};
		case "anxu-targets": {
			let t = [...s].sort((t, n) => e.public.seats[t].handCount - e.public.seats[n].handCount);
			return {
				type: "choose",
				seats: [t[0], t[t.length - 1]]
			};
		}
		case "paiyi-target": return s.includes(t) ? {
			type: "choose",
			seats: [t]
		} : d == null ? {
			type: "choose",
			seats: [s[0]]
		} : {
			type: "choose",
			seats: [d]
		};
		case "qiaobian-move": {
			let i = r.ctx.data?.owner;
			return i != null && $(e, t, i, n) >= 2 && s.includes(t) ? {
				type: "choose",
				seats: [t]
			} : u == null ? {
				type: "choose",
				seats: [s[0]]
			} : {
				type: "choose",
				seats: [u]
			};
		}
		case "qiuyuan-target": return d == null ? {
			type: "choose",
			seats: [[...s].sort((t, n) => e.public.seats[t].hp - e.public.seats[n].hp)[0]]
		} : {
			type: "choose",
			seats: [d]
		};
		case "qiaoshui-target":
		case "juece-target": return u == null ? {
			type: "choose",
			seats: [s[0]]
		} : {
			type: "choose",
			seats: [u]
		};
		case "xiansi-pick": {
			let r = f.filter((r) => $(e, t, r, n) >= 2).slice(0, l);
			return r.length >= c ? {
				type: "choose",
				seats: r
			} : {
				type: "choose",
				seats: f.slice(0, c)
			};
		}
		case "zhiyan-target": return d == null ? {
			type: "choose",
			seats: [s.includes(t) ? t : s[0]]
		} : {
			type: "choose",
			seats: [d]
		};
		case "qiangzhi-target":
		case "shenduan-target": return {
			type: "choose",
			seats: [f.find((r) => $(e, t, r, n) >= 2) ?? u ?? s[0]]
		};
		case "zy-target": return d == null ? c === 0 ? { type: "pass" } : {
			type: "choose",
			seats: [s[0]]
		} : {
			type: "choose",
			seats: [d]
		};
		case "zy-slash-target":
		case "chanhui-pick": return u == null ? c === 0 ? { type: "pass" } : {
			type: "choose",
			seats: [s[0]]
		} : {
			type: "choose",
			seats: [u]
		};
		case "pingkou-targets":
		case "xianzhou-targets": {
			let r = s.filter((r) => $(e, t, r, n) >= 2).slice(0, l);
			return r.length >= c ? {
				type: "choose",
				seats: r
			} : c === 0 ? { type: "pass" } : {
				type: "choose",
				seats: s.slice(0, c)
			};
		}
		case "bingyi-targets": {
			let r = s.filter((r) => r !== t && $(e, t, r, n) < 0).slice(0, l);
			return r.length > 0 ? {
				type: "choose",
				seats: r
			} : c === 0 ? { type: "pass" } : {
				type: "choose",
				seats: s.slice(0, c)
			};
		}
		case "huituo-target": {
			let r = s.filter((r) => (r === t || $(e, t, r, n) < 0) && e.public.seats[r].hp < e.public.seats[r].maxHp).sort((r, i) => $(e, t, r, n) - $(e, t, i, n));
			return r.length > 0 ? {
				type: "choose",
				seats: [r[0]]
			} : s.includes(t) ? {
				type: "choose",
				seats: [t]
			} : d == null ? {
				type: "choose",
				seats: [s[0]]
			} : {
				type: "choose",
				seats: [d]
			};
		}
		case "yanyu-target": return d == null ? c === 0 ? { type: "pass" } : {
			type: "choose",
			seats: [s[0]]
		} : {
			type: "choose",
			seats: [d]
		};
		case "zuoding-target": return s[0] != null && (s[0] === t || $(e, t, s[0], n) < 0) ? {
			type: "choose",
			seats: [s[0]]
		} : c === 0 ? { type: "pass" } : {
			type: "choose",
			seats: [s[0]]
		};
		case "yaoming-target": {
			let r = e.public.seats[t].handCount, i = f.find((i) => $(e, t, i, n) >= 2 && e.public.seats[i].handCount > r);
			if (i != null) return {
				type: "choose",
				seats: [i]
			};
			let a = [...s].sort((t, n) => e.public.seats[t].handCount - e.public.seats[n].handCount).find((i) => $(e, t, i, n) < 0 && e.public.seats[i].handCount < r);
			return a == null ? c === 0 ? { type: "pass" } : {
				type: "choose",
				seats: [s[0]]
			} : {
				type: "choose",
				seats: [a]
			};
		}
		case "xingxue-targets": {
			let r = s.filter((r) => r === t || $(e, t, r, n) < 0).slice(0, l);
			return r.length >= c ? {
				type: "choose",
				seats: r
			} : {
				type: "choose",
				seats: s.slice(0, c)
			};
		}
		case "huaiyi-targets": {
			let r = s.filter((r) => $(e, t, r, n) >= 2).slice(0, l);
			return r.length >= c ? {
				type: "choose",
				seats: r
			} : c === 0 ? { type: "pass" } : {
				type: "choose",
				seats: s.slice(0, c)
			};
		}
		case "taoluan-target": {
			let r = f.find((r) => $(e, t, r, n) < 0 && e.public.seats[r].handCount > 0);
			return r == null ? {
				type: "choose",
				seats: [[...s].sort((t, n) => e.public.seats[t].handCount - e.public.seats[n].handCount).find((r) => $(e, t, r, n) >= 2) ?? u ?? s[0]]
			} : {
				type: "choose",
				seats: [r]
			};
		}
		case "qinqing": {
			let r = f.filter((r) => $(e, t, r, n) >= 2).slice(0, l);
			return r.length > 0 ? {
				type: "choose",
				seats: r
			} : c === 0 ? { type: "pass" } : {
				type: "choose",
				seats: s.slice(0, c)
			};
		}
		case "jishe-chain": {
			let r = s.filter((r) => $(e, t, r, n) >= 2).slice(0, l);
			return r.length > 0 ? {
				type: "choose",
				seats: r
			} : c === 0 ? { type: "pass" } : {
				type: "choose",
				seats: s.slice(0, c)
			};
		}
		case "zg-slash-target": return u == null ? {
			type: "choose",
			seats: [s[0]]
		} : {
			type: "choose",
			seats: [u]
		};
		case "juexiang-target": return d == null ? c === 0 ? { type: "pass" } : {
			type: "choose",
			seats: [s[0]]
		} : {
			type: "choose",
			seats: [d]
		};
		case "daiyan-target": {
			let r = (e.public.seats[t].marks?.dyLast ?? 0) - 1, i = s.filter((e) => e !== r);
			return {
				type: "choose",
				seats: [DS(e, t, i.length > 0 ? i : s, n) ?? s[0]]
			};
		}
		case "xinjiexun": return (e.public.seats[t].marks?.xinjiexun ?? 0) === 0 && d != null ? {
			type: "choose",
			seats: [d]
		} : {
			type: "choose",
			seats: [f.find((r) => $(e, t, r, n) >= 2) ?? u ?? s[0]]
		};
		case "huimin-start":
		case "tongbo-give": return d == null ? {
			type: "choose",
			seats: [s[0]]
		} : {
			type: "choose",
			seats: [d]
		};
		default: return u == null ? c === 0 ? { type: "pass" } : {
			type: "choose",
			seats: s.slice(0, c)
		} : {
			type: "choose",
			seats: [u]
		};
	}
}
//#endregion
//#region src/games/sanguosha/bot/index.ts
var KS = (e, t) => {
	let n = e.public, r = e.private, i = {
		public: n,
		private: r
	}, a = n.seats.findIndex((e) => e.rid === t.rid);
	if (a < 0) return null;
	let o = r.act, s = TS(n, a, r.identity), c = (e) => ({ action: e });
	if (!n.seats[a]?.alive) {
		let e = n.pending;
		if (e && e.asking.includes(a) && e.kind === "skill-seats") {
			let e = GS({
				public: n,
				private: r
			}, a, s);
			return e ? c(e) : null;
		}
		return null;
	}
	if (o.candidates) return c({
		type: "pick-general",
		generalId: o.candidates[0]
	});
	let l = n.pending;
	if (l && l.asking.includes(a)) switch (l.kind) {
		case "jink":
		case "slash-response":
		case "peach-save":
		case "nullification":
		case "lord-call":
		case "guicai": {
			let e = BS(i, a, s);
			if (e) return c(e);
			break;
		}
		case "skill-ask": {
			let e = VS(i, a, s);
			return e ? c(e) : o.canPass ? c({ type: "pass" }) : null;
		}
		case "skill-cards": {
			let e = WS(i, a, s);
			return e ? c(e) : o.canPass ? c({ type: "pass" }) : null;
		}
		case "skill-seats": {
			let e = GS(i, a, s);
			return e ? c(e) : o.canPass ? c({ type: "pass" }) : null;
		}
		case "discard": return c(NS(i));
		case "amazing-pick": {
			let e = PS(i);
			if (e) return c(e);
			break;
		}
		case "pick-zone": {
			let e = IS(i, a, s);
			if (e) return c(e);
			break;
		}
		case "collateral-target": {
			let e = o.choosableSeats ?? [], t = ES(i, a, e, s);
			if (t != null) return c({
				type: "choose",
				seat: t
			});
			if (e.length) return c({
				type: "choose",
				seat: e[0]
			});
			break;
		}
		default: return o.canPass ? c({ type: "pass" }) : null;
	}
	if (n.turn?.seat === a && n.turn.phase === "play" && !n.pending) {
		let e = RS(i, a, s);
		if (e) return c(e);
	}
	return null;
}, qS = 56, JS = 80;
function YS({ name: e, suit: t, point: n, box: r }) {
	let i = f(), a = e in Dx, o = a ? i(Dx[e]) : e, s = o.length === 1 ? "nlarge" : o.length === 2 ? "nmedium" : "nsmall", c = t === "heart" || t === "diamond", l = n == null ? "" : n === 1 ? "A" : n === 11 ? "J" : n === 12 ? "Q" : n === 13 ? "K" : `${n}`;
	return /* @__PURE__ */ b("span", {
		style: {
			width: r.w,
			height: r.h,
			"--sgs-fx-scale": r.w / qS
		},
		className: `sgs-face sgs-face-fx sgs-card-${a ? O(e) : "trick"} sgs-card-name-${e} sgs-face-${s}`,
		children: [
			/* @__PURE__ */ b("span", {
				className: `sgs-face-corner ${c ? "sgs-suit-red" : ""}`,
				children: [t ? {
					spade: "♠",
					heart: "♥",
					club: "♣",
					diamond: "♦"
				}[t] : "", l]
			}),
			/* @__PURE__ */ y("strong", {
				className: "sgs-face-name",
				children: o
			}),
			/* @__PURE__ */ y("span", {
				className: "sgs-face-band",
				"aria-hidden": "true"
			})
		]
	});
}
function XS() {
	return /* @__PURE__ */ y("span", { className: "sgs-face sgs-face-fx sgs-face-backfx" });
}
function ZS(e, t) {
	return typeof t == "number" ? e.anchor(`seat:${t}`) : null;
}
function QS(e, t = qS, n = JS) {
	let r = e.anchor("played");
	if (r) return {
		...r,
		h: r.w * (r.w < 50 ? 48 / 40 : 102 / 68)
	};
	let i = e.anchor("table");
	return i ? {
		x: i.x + i.w / 2 - t / 2,
		y: i.y + i.h / 2 - n / 2,
		w: t,
		h: n
	} : null;
}
function $S(e) {
	let t = e.anchor("deck");
	return t ? {
		x: t.x + t.w / 2 - qS / 2,
		y: t.y + t.h / 2 - JS / 2,
		w: qS,
		h: JS
	} : QS(e);
}
function eC(e, t) {
	return t?.table === !0 && e.queued === 0 ? ["played"] : void 0;
}
function tC(e) {
	return e.queued > 0 ? void 0 : ["played"];
}
function nC(e, t, n, r = 360) {
	return {
		ms: r + n * 50,
		node: Array.from({ length: n }, (n, i) => /* @__PURE__ */ y(re, {
			from: e,
			to: t,
			ms: r,
			delay: i * 50,
			children: /* @__PURE__ */ y(XS, {})
		}, i))
	};
}
function rC({ at: e, text: t, tone: n }) {
	return /* @__PURE__ */ y(ne, {
		at: e,
		ms: 900,
		children: /* @__PURE__ */ y("span", {
			className: `text-base ${n === "damage" ? "text-rose-600" : "text-emerald-600"}`,
			children: t
		})
	});
}
var iC = {
	deal(e, t) {
		let n = t.anchor("table");
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ y(ie, {
				at: n,
				ms: 500
			})
		} : null;
	},
	draw(e, t) {
		let n = e.data, r = e.secret, i = $S(t);
		if (!i) return null;
		if (r && Array.isArray(r.cards)) {
			let e = [], n = [];
			for (let [a, o] of r.cards.entries()) {
				let r = t.anchor(`hand:${o}`);
				r && (n.push(`hand:${o}`), e.push(/* @__PURE__ */ y(re, {
					from: i,
					to: r,
					ms: 340,
					delay: a * 50,
					children: /* @__PURE__ */ y(XS, {})
				}, o)));
			}
			return e.length ? {
				ms: 340 + e.length * 50,
				node: e,
				hide: n
			} : null;
		}
		let a = ZS(t, n?.seat);
		return a ? nC(i, a, typeof n?.n == "number" ? Math.min(n.n, 8) : 2) : null;
	},
	play(e, t) {
		let n = e.data, r = ZS(t, n?.seat), i = QS(t);
		return !r || !i || typeof n?.name != "string" ? null : {
			ms: 400,
			node: /* @__PURE__ */ y(re, {
				from: r,
				to: i,
				ms: 380,
				children: /* @__PURE__ */ y(YS, {
					name: n.name,
					box: i
				})
			}),
			hide: tC(t)
		};
	},
	slash(e, t) {
		let n = e.data, r = ZS(t, n?.target);
		return r ? {
			ms: 500,
			node: /* @__PURE__ */ y(ie, {
				at: r,
				ms: 500
			})
		} : null;
	},
	dodge(e, t) {
		let n = e.data, r = ZS(t, n?.seat);
		if (!r) return null;
		let i = typeof n?.name == "string" ? n.name : null, a = ZS(t, n?.by) ?? r, o = i ? QS(t) : null;
		return {
			ms: 700,
			node: /* @__PURE__ */ b(v, { children: [i && o && /* @__PURE__ */ y(re, {
				from: a,
				to: o,
				ms: 340,
				children: /* @__PURE__ */ y(YS, {
					name: i,
					box: o
				})
			}), /* @__PURE__ */ y(ne, {
				at: r,
				ms: i ? 400 : 650,
				delay: i ? 250 : 0,
				children: "🛡️"
			})] }),
			hide: i ? eC(t, n) : void 0
		};
	},
	"respond-slash"(e, t) {
		let n = e.data, r = ZS(t, n?.seat);
		if (!r) return null;
		let i = typeof n?.name == "string" ? n.name : null, a = ZS(t, n?.by) ?? r, o = i ? QS(t) : null;
		return {
			ms: 700,
			node: /* @__PURE__ */ b(v, { children: [i && o && /* @__PURE__ */ y(re, {
				from: a,
				to: o,
				ms: 340,
				children: /* @__PURE__ */ y(YS, {
					name: i,
					box: o
				})
			}), /* @__PURE__ */ y(ne, {
				at: r,
				ms: i ? 400 : 650,
				delay: i ? 250 : 0,
				children: "🗡️"
			})] }),
			hide: i ? eC(t, n) : void 0
		};
	},
	damage(e, t) {
		let n = e.data, r = ZS(t, n?.seat), i = typeof n?.n == "number" ? n.n : 1;
		if (!r) return null;
		let a = n?.nature === "fire" ? "🔥" : n?.nature === "thunder" ? "⚡" : "";
		return {
			ms: 900,
			node: /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(rC, {
				at: r,
				text: `${a}-${i}`,
				tone: "damage"
			}), i >= 2 && /* @__PURE__ */ y(te, {
				ms: 500,
				className: "bg-rose-500"
			})] })
		};
	},
	recover(e, t) {
		let n = e.data, r = ZS(t, n?.seat), i = typeof n?.n == "number" ? n.n : 1;
		if (!r) return null;
		let a = typeof n?.name == "string" ? n.name : null, o = a ? ZS(t, n?.by) : null, s = o ? QS(t) : null;
		return {
			ms: 900,
			node: /* @__PURE__ */ b(v, { children: [a && o && s && /* @__PURE__ */ y(re, {
				from: o,
				to: s,
				ms: 340,
				children: /* @__PURE__ */ y(YS, {
					name: a,
					box: s
				})
			}), /* @__PURE__ */ y(rC, {
				at: r,
				text: `+${i}`,
				tone: "recover"
			})] }),
			hide: a ? eC(t, n) : void 0
		};
	},
	death(e, t) {
		let n = ZS(t, e.data?.seat);
		return n ? {
			ms: 1200,
			node: /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(ne, {
				at: n,
				ms: 1100,
				children: "💀"
			}), /* @__PURE__ */ y(te, {
				ms: 700,
				className: "bg-rose-500"
			})] })
		} : null;
	},
	judge(e, t) {
		let n = e.data, r = typeof n?.from == "number" ? ZS(t, n.from) : $S(t), i = QS(t);
		if (!r || !i || typeof n?.name != "string") return null;
		let a = typeof n.suit == "string" ? n.suit : void 0, o = typeof n.point == "number" ? n.point : void 0;
		return {
			ms: 800,
			node: /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(re, {
				from: r,
				to: i,
				ms: 420,
				children: /* @__PURE__ */ y(YS, {
					name: n.name,
					suit: a,
					point: o,
					box: i
				})
			}), /* @__PURE__ */ y(ie, {
				at: i,
				ms: 500,
				delay: 420
			})] })
		};
	},
	give(e, t) {
		let n = e.data, r = ZS(t, n?.from), i = ZS(t, n?.to);
		return !r || !i ? null : nC(r, i, typeof n?.n == "number" ? Math.min(n.n, 8) : 1);
	},
	take(e, t) {
		let n = e.data, r = ZS(t, n?.seat);
		if (!r) return null;
		let i = typeof n?.from == "number" && n.from >= 0 ? ZS(t, n.from) : t.anchor("discard") ?? QS(t);
		return i ? nC(i, r, typeof n?.n == "number" ? Math.min(n.n, 8) : 1) : null;
	},
	discard(e, t) {
		let n = e.data, r = ZS(t, n?.seat), i = t.anchor("discard"), a = i ? {
			x: i.x + i.w / 2 - qS / 2,
			y: i.y + i.h / 2 - JS / 2,
			w: qS,
			h: JS
		} : QS(t);
		return !r || !a ? null : nC(r, a, typeof n?.n == "number" ? Math.min(n.n, 8) : 1);
	},
	equip(e, t) {
		let n = e.data, r = ZS(t, n?.seat);
		if (!r || typeof n?.name != "string") return null;
		let i = QS(t);
		return {
			ms: 800,
			node: /* @__PURE__ */ b(v, { children: [
				i && /* @__PURE__ */ y(re, {
					from: r,
					to: i,
					ms: 340,
					children: /* @__PURE__ */ y(YS, {
						name: n.name,
						box: i
					})
				}),
				/* @__PURE__ */ y(ne, {
					at: r,
					ms: 650,
					delay: 340,
					children: /* @__PURE__ */ y(aC, { name: n.name })
				}),
				/* @__PURE__ */ y(ie, {
					at: r,
					ms: 500,
					delay: 340
				})
			] }),
			hide: tC(t)
		};
	},
	move(e, t) {
		let n = e.data, r = ZS(t, n?.seat);
		return !r || typeof n?.name != "string" ? null : {
			ms: 700,
			node: /* @__PURE__ */ y(ne, {
				at: r,
				ms: 650,
				children: /* @__PURE__ */ y(aC, { name: n.name })
			})
		};
	},
	"place-judge"(e, t) {
		let n = e.data, r = QS(t), i = ZS(t, n?.seat);
		return !r || !i || typeof n?.name != "string" ? null : {
			ms: 450,
			node: /* @__PURE__ */ y(re, {
				from: r,
				to: i,
				ms: 400,
				children: /* @__PURE__ */ y(YS, {
					name: n.name,
					box: r
				})
			})
		};
	},
	reveal(e, t) {
		let n = ZS(t, e.data?.seat);
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ y(ie, {
				at: n,
				ms: 500
			})
		} : null;
	},
	"turn-over"(e, t) {
		let n = ZS(t, e.data?.seat);
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ y(ne, {
				at: n,
				ms: 650,
				children: "🔄"
			})
		} : null;
	},
	unchain(e, t) {
		let n = ZS(t, e.data?.seat);
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ y(ne, {
				at: n,
				ms: 550,
				children: "🔓"
			})
		} : null;
	},
	nullify(e, t) {
		let n = e.data, r = ZS(t, n?.seat);
		if (!r) return null;
		let i = typeof n?.name == "string" ? n.name : null, a = i ? QS(t) : null;
		return {
			ms: 700,
			node: /* @__PURE__ */ b(v, { children: [i && a && /* @__PURE__ */ y(re, {
				from: r,
				to: a,
				ms: 340,
				children: /* @__PURE__ */ y(YS, {
					name: i,
					box: a
				})
			}), /* @__PURE__ */ y(ne, {
				at: r,
				ms: i ? 400 : 650,
				delay: i ? 250 : 0,
				children: "🚫"
			})] }),
			hide: i ? eC(t, n) : void 0
		};
	},
	nullified(e, t) {
		let n = t.anchor("table");
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ y(ie, {
				at: n,
				ms: 500
			})
		} : null;
	},
	skill(e, t) {
		let n = ZS(t, e.data?.seat);
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ y(ne, {
				at: n,
				ms: 850,
				children: "🌟"
			})
		} : null;
	}
};
function aC({ name: e }) {
	let t = f();
	return /* @__PURE__ */ y("span", {
		className: "rounded border border-ink bg-surface px-1.5 text-xs leading-5 font-extrabold",
		children: e in Dx ? t(Dx[e]) : e
	});
}
//#endregion
//#region src/games/sanguosha/game-over.tsx
var oC = {
	lord: "games.sanguosha.identityLord",
	loyalist: "games.sanguosha.identityLoyalist",
	rebel: "games.sanguosha.identityRebel",
	renegade: "games.sanguosha.identityRenegade"
}, sC = {
	wei: "games.sanguosha.factionWei",
	shu: "games.sanguosha.factionShu",
	wu: "games.sanguosha.factionWu",
	qun: "games.sanguosha.factionQun"
}, cC = {
	lord: "games.sanguosha.overLordWin",
	rebel: "games.sanguosha.overRebelWin",
	renegade: "games.sanguosha.overRenegadeWin"
};
function lC(e) {
	return e === "lord" || e === "loyalist" ? "lord" : e;
}
function uC({ seats: e, title: t, members: r, myRid: i, locale: a }) {
	let o = f();
	return /* @__PURE__ */ b("section", {
		className: "sgs-over-group",
		children: [/* @__PURE__ */ b("div", {
			className: "sgs-over-group-head",
			children: [
				/* @__PURE__ */ b("h2", { children: [o(t), /* @__PURE__ */ y("small", { children: o("games.sanguosha.overPlayerCount", { n: e.length }) })] }),
				/* @__PURE__ */ y("span", {
					className: "sgs-over-col-label",
					children: o("games.sanguosha.overIdentity")
				}),
				/* @__PURE__ */ y("span", {
					className: "sgs-over-col-label",
					children: o("games.sanguosha.overFaction")
				}),
				/* @__PURE__ */ y("span", { "aria-hidden": !0 })
			]
		}), /* @__PURE__ */ y("ol", {
			className: "sgs-over-rows",
			children: e.map(({ seat: e }) => {
				let t = r.find((t) => t.rid === e.rid), s = e.generalId ? Fe.get(e.generalId) : void 0, c = e.generalId ? kx[e.generalId] : void 0, l = t ? n(t.rid) === null ? t.name : u(a, t.avatar) : e.rid, d = e.rid === i ? o("lobby.you") : l;
				return /* @__PURE__ */ b("li", {
					className: "sgs-over-row",
					children: [
						/* @__PURE__ */ y("span", {
							className: `sgs-over-faction-edge sgs-over-faction-${s?.faction ?? "none"}`,
							"aria-hidden": !0
						}),
						/* @__PURE__ */ y("span", {
							className: "sgs-over-seat",
							children: /* @__PURE__ */ y("img", {
								src: p[(t?.avatar ?? 0) % p.length],
								alt: "",
								draggable: !1,
								style: {
									width: "1.75em",
									height: "1.75em",
									maxWidth: "100%",
									maxHeight: "100%",
									display: "block",
									objectFit: "contain",
									pointerEvents: "none",
									borderRadius: "inherit"
								}
							})
						}),
						/* @__PURE__ */ b("span", {
							className: "sgs-over-person",
							children: [/* @__PURE__ */ b("span", {
								className: "sgs-over-person-main",
								children: [/* @__PURE__ */ y("strong", { children: c ? o(c) : l }), t && /* @__PURE__ */ y("img", {
									src: p[t.avatar % p.length],
									alt: "",
									draggable: !1
								})]
							}), /* @__PURE__ */ y("span", {
								className: "sgs-over-player",
								children: d
							})]
						}),
						/* @__PURE__ */ y("span", {
							className: `sgs-over-role sgs-over-role-${e.identity ?? "unknown"}`,
							children: e.identity ? o(oC[e.identity]) : "？"
						}),
						/* @__PURE__ */ y("span", {
							className: `sgs-over-faction sgs-over-faction-${s?.faction ?? "none"}`,
							children: s ? o(sC[s.faction]) : "—"
						}),
						/* @__PURE__ */ y("span", {
							className: "sgs-over-dead",
							children: !e.alive && o("games.sanguosha.deadMark")
						})
					]
				}, e.rid);
			})
		})]
	});
}
function dC({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let o = f(), s = d((e) => e.locale), c = t, l = new Set(e.winner), u = lC(c.seats.find((e) => l.has(e.rid))?.identity ?? null), p = c.seats.map((e, t) => ({
		seat: e,
		number: t + 1
	})), m = p.filter(({ seat: e }) => l.has(e.rid)), h = p.filter(({ seat: e }) => !l.has(e.rid)), g = !!i;
	return /* @__PURE__ */ b("div", {
		className: "sgs-over",
		lang: s,
		children: [
			l.has(r) && /* @__PURE__ */ y(x, {}),
			/* @__PURE__ */ b("main", {
				className: "sgs-over-board",
				children: [
					/* @__PURE__ */ b("svg", {
						className: "sgs-over-board-ornament",
						viewBox: "0 0 100 100",
						preserveAspectRatio: "none",
						"aria-hidden": "true",
						children: [
							/* @__PURE__ */ y("path", { d: "M4 3h5v1H6v2H4M96 3h-5v1h3v2h2M4 97h5v-1H6v-2H4M96 97h-5v-1h3v-2h2" }),
							/* @__PURE__ */ y("path", { d: "M5 7c6-2 10-2 15 0M95 7c-6-2-10-2-15 0M5 93c6 2 10 2 15 0M95 93c-6 2-10 2-15 0" }),
							/* @__PURE__ */ y("path", { d: "M36 97h10l4 1 4-1h10" })
						]
					}),
					/* @__PURE__ */ b("div", {
						className: "sgs-over-banner",
						children: [
							/* @__PURE__ */ b("svg", {
								className: "sgs-over-banner-ornament",
								viewBox: "0 0 327 123",
								preserveAspectRatio: "none",
								"aria-hidden": "true",
								children: [/* @__PURE__ */ y("path", { d: "M14 18h18l-9 7zM295 18h18l-9 7zM14 105h18l-9-7zM295 105h18l-9-7z" }), /* @__PURE__ */ y("path", { d: "M15 63h58m181 0h58M23 70h41m199 0h41" })]
							}),
							/* @__PURE__ */ y("span", {
								className: "sgs-over-banner-kicker",
								children: o("games.sanguosha.overFinal")
							}),
							/* @__PURE__ */ y("h1", {
								className: "font-display",
								children: o(u ? cC[u] : "session.result.title")
							}),
							/* @__PURE__ */ y("span", {
								className: "sgs-over-banner-flourish",
								"aria-hidden": !0
							})
						]
					}),
					/* @__PURE__ */ b("div", {
						className: "sgs-over-scroll",
						children: [/* @__PURE__ */ y(uC, {
							seats: m,
							title: "games.sanguosha.overWinners",
							members: n,
							myRid: r,
							locale: s
						}), /* @__PURE__ */ y(uC, {
							seats: h,
							title: "games.sanguosha.overLosers",
							members: n,
							myRid: r,
							locale: s
						})]
					})
				]
			}),
			/* @__PURE__ */ b("div", {
				className: "sgs-over-actions",
				children: [
					i && /* @__PURE__ */ y("button", {
						type: "button",
						className: "sgs-over-play-again font-display",
						style: { backgroundColor: oe.accent },
						onClick: i,
						children: o("session.result.playAgain")
					}),
					!g && /* @__PURE__ */ y("p", {
						className: "sgs-over-wait",
						children: o("session.result.waitHost")
					}),
					a && /* @__PURE__ */ y("button", {
						type: "button",
						className: "sgs-over-back font-display",
						onClick: a,
						children: o(g ? "session.result.backToLobby" : "games.sanguosha.overLeave")
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/sanguosha/options.tsx
var fC = [
	{
		field: "wind",
		nameKey: "games.sanguosha.optWind",
		hintKey: "games.sanguosha.optWindHint"
	},
	{
		field: "fire",
		nameKey: "games.sanguosha.optFire",
		hintKey: "games.sanguosha.optFireHint"
	},
	{
		field: "forest",
		nameKey: "games.sanguosha.optForest",
		hintKey: "games.sanguosha.optForestHint"
	},
	{
		field: "mountain",
		nameKey: "games.sanguosha.optMountain",
		hintKey: "games.sanguosha.optMountainHint"
	},
	{
		field: "yj2011",
		nameKey: "games.sanguosha.optYj2011",
		hintKey: "games.sanguosha.optYj2011Hint"
	},
	{
		field: "yj2012",
		nameKey: "games.sanguosha.optYj2012",
		hintKey: "games.sanguosha.optYj2012Hint"
	},
	{
		field: "yj2013",
		nameKey: "games.sanguosha.optYj2013",
		hintKey: "games.sanguosha.optYj2013Hint"
	},
	{
		field: "yj2014",
		nameKey: "games.sanguosha.optYj2014",
		hintKey: "games.sanguosha.optYj2014Hint"
	},
	{
		field: "yj2015",
		nameKey: "games.sanguosha.optYj2015",
		hintKey: "games.sanguosha.optYj2015Hint"
	},
	{
		field: "yj2016",
		nameKey: "games.sanguosha.optYj2016",
		hintKey: "games.sanguosha.optYj2016Hint"
	},
	{
		field: "yj2017",
		nameKey: "games.sanguosha.optYj2017",
		hintKey: "games.sanguosha.optYj2017Hint"
	},
	{
		field: "jie",
		nameKey: "games.sanguosha.optJie",
		hintKey: "games.sanguosha.optJieHint"
	}
], pC = [{
	field: "junzheng",
	nameKey: "games.sanguosha.optJunzheng",
	hintKey: "games.sanguosha.optJunzhengHint"
}], mC = [
	{
		id: "random",
		key: "games.sanguosha.idRandom"
	},
	{
		id: "lord",
		key: "games.sanguosha.identityLord"
	},
	{
		id: "loyalist",
		key: "games.sanguosha.identityLoyalist"
	},
	{
		id: "renegade",
		key: "games.sanguosha.identityRenegade"
	},
	{
		id: "rebel",
		key: "games.sanguosha.identityRebel"
	}
];
function hC({ value: e, onChange: t, offline: n }) {
	let r = f(), i = ue.safeParse(e), a = i.success ? i.data : de, o = (e) => e.map((e) => {
		let n = a[e.field];
		return /* @__PURE__ */ y(w, {
			checked: n,
			label: r(e.nameKey),
			hint: r(e.hintKey),
			accent: oe.accent,
			onChange: () => t({
				...a,
				[e.field]: !n
			})
		}, e.field);
	});
	return /* @__PURE__ */ b("div", {
		className: "flex flex-col gap-2",
		children: [
			n && /* @__PURE__ */ y(C, {
				title: r("games.sanguosha.optIdentity"),
				children: mC.map((e) => /* @__PURE__ */ y(S, {
					name: "sanguosha-identity",
					value: e.id,
					checked: a.identity === e.id,
					label: r(e.key),
					accent: oe.accent,
					onChange: () => t({
						...a,
						identity: e.id
					})
				}, e.id))
			}),
			/* @__PURE__ */ y("p", {
				className: "section-label",
				children: r("games.sanguosha.optPacks")
			}),
			o(fC),
			/* @__PURE__ */ y("p", {
				className: "section-label",
				children: r("games.sanguosha.optDeck")
			}),
			o(pC)
		]
	});
}
//#endregion
//#region src/games/sanguosha/menu-items.tsx
function gC({ close: e }) {
	let t = f(), [n, r] = l(!1);
	return /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(ae, {
		icon: /* @__PURE__ */ y(g, { size: 18 }),
		label: t("games.sanguosha.allGenerals"),
		onClick: () => {
			e(), r(!0);
		}
	}), n && T(/* @__PURE__ */ y(Jx, { onClose: () => r(!1) }), document.body)] });
}
//#endregion
//#region .bgparty/cache/pack-entry/sanguosha/entry.tsx
var _C = {
	definition: wx,
	View: Hx,
	bot: KS,
	fx: iC,
	OverView: dC,
	Options: hC,
	MenuItems: gC,
	locales: {
		zh: {
			name: "三国杀",
			desc: "主忠反内身份局,杀闪攻防与锦囊博弈",
			rules: "目标：各身份的获胜条件如下。\n· 主公与忠臣：消灭所有反贼和内奸。\n· 反贼：杀死主公。\n· 内奸：在只剩自己与主公时，杀死主公。\n准备:\n· 按人数分发身份牌,只有主公亮出身份;主公先从五张武将牌中选一张,随后其他人同时各从三张中选一张。\n· 主公的体力上限增加一点。每人抽取四张起始手牌，由主公先行动。\n流程(每个回合依次进行):\n· 判定阶段:依次判定判定区里的延时锦囊,后放置的先判定。\n· 摸牌阶段:从牌堆摸两张牌。\n· 出牌阶段:可以使用手牌。【杀】每回合限用一次,只能攻击范围内的角色;【闪】只能在响应【杀】时打出。\n· 弃牌阶段:手牌数超过当前体力值时,须弃置至等于体力值。\n结算:\n· 【杀】未被【闪】抵消时,目标受到一点伤害;体力降到零进入濒死,所有角色可以依次打出【桃】营救。\n· 杀死反贼的角色摸三张牌;主公杀死忠臣须弃置所有手牌和装备。\n· 装备牌提供攻击范围或防御效果;延时锦囊【乐不思蜀】使目标跳过出牌阶段,【闪电】判定黑桃二至九时造成三点伤害。",
			identityLord: "主公",
			identityLoyalist: "忠臣",
			identityRebel: "反贼",
			identityRenegade: "内奸",
			overFinal: "终局",
			overLordWin: "主忠胜利",
			overRebelWin: "反贼胜利",
			overRenegadeWin: "内奸胜利",
			overWinners: "胜利方",
			overLosers: "失败方",
			overPlayerCount: "{{n}} 人",
			overIdentity: "身份",
			overFaction: "势力",
			overLeave: "离开本局",
			phaseJudge: "判定阶段",
			phaseDraw: "摸牌阶段",
			phasePlay: "出牌阶段",
			phaseDiscard: "弃牌阶段",
			phaseEnd: "结束阶段",
			selectGeneralTitle: "选择你的武将",
			selectGeneralWaiting: "等待其他人选择武将…",
			lordPickFirst: "你是主公,从五名武将中选择",
			selectLordCenter: "主公定将",
			selectOtherCenter: "选将",
			selectWaitLordCenter: "候主公",
			selectWaitOthersCenter: "候众将",
			selectFiveOne: "五选一",
			selectThreeOne: "三选一",
			selectPending: "待选",
			selectChoosing: "选将中",
			selectSelf: "我",
			selectSeatAria: "{{n}}号位，{{name}}",
			seatNumber: "{{n}} 号位",
			selectCandidates: "候选武将",
			selectGeneralBack: "将",
			selectCandidateAria: "查看{{name}}",
			revealCenter: "亮将",
			revealSub: "对局即将开始",
			selectHpLord: "体力 {{n}}+1",
			selectHp: "体力 {{n}}",
			selectLordSkill: "主公技",
			allGenerals: "全部武将",
			allGeneralsTitle: "武将一览",
			allGeneralsCount: "共 {{n}} 将",
			rosterColGeneral: "武将",
			rosterColSkills: "技能",
			rosterFilterFaction: "势力",
			rosterFilterPack: "出处",
			rosterFilterAll: "全部",
			rosterFilterEmpty: "没有符合筛选条件的武将",
			genderFemale: "女性",
			packStandard: "标准",
			packWind: "风",
			packFire: "火",
			packForest: "林",
			packMountain: "山",
			packYj2011: "一将成名2011",
			packYj2012: "一将成名2012",
			packYj2013: "一将成名2013",
			packYj2014: "一将成名2014",
			packYj2015: "一将成名2015",
			packYj2016: "原创设计2016",
			packYj2017: "原创设计2017",
			factionWei: "魏",
			factionShu: "蜀",
			factionWu: "吴",
			factionQun: "群",
			yourTurn: "你的回合",
			playPrompt: "出牌阶段:点选手牌使用,或结束出牌",
			endPlay: "结束出牌",
			waitingTurn: "等待 {{name}} 行动…",
			myIdentity: "我的身份:{{name}}",
			deckCount: "牌堆 {{n}}",
			cardBack: "牌背",
			discardCount: "弃牌堆 {{n}}",
			round: "第 {{n}} 轮",
			respondJink: "打出一张【闪】",
			respondJinkFrom: "{{name}} 的0,打出【闪】响应",
			respondSlash: "打出一张【杀】",
			respondSlashAoe: "{{name}} 的0,打出【杀】响应",
			respondSlashDuel: "{{name}} 对你发起0,打出【杀】响应",
			respondSlashCollateral: "{{name}} 的0:向 {{target}} 打出【杀】",
			respondPeach: "打出一张【桃】营救",
			respondPeachFrom: "{{name}} 濒死,打出【桃】营救",
			respondNullification: "打出【无懈可击】",
			nullifyAsk: "是否对 {{name}} 的【{{card}}】打出无懈可击?",
			nullifyAskTarget: "是否对 {{name}} 对 {{target}} 使用的【{{card}}】打出无懈可击?",
			noNullify: "不打出",
			passRespond: "不出",
			useEightDiagram: "发动八卦阵判定",
			amazingPick: "从亮出的牌中选一张",
			amazingChip: "选牌中",
			amazingLabel: "五谷丰登 · {{n}} 张亮牌",
			pickZone: "选择目标的一个区域",
			zoneHand: "手牌(随机一张)",
			zoneWeapon: "武器",
			zoneArmor: "防具",
			zoneOffHorse: "进攻坐骑",
			zoneDefHorse: "防御坐骑",
			zoneJudge: "判定区第 {{n}} 张",
			zoneTagEquip: "装备",
			zoneTagJudge: "判定区",
			zoneTagTian: "田",
			zoneTagShown: "亮牌",
			collateralPick: "选择被借刀者攻击的目标",
			discardPrompt: "弃置 {{n}} 张手牌",
			confirm: "确定",
			cancelSelection: "取消",
			waitingJink: "等待 {{name}} 出闪…",
			waitingSlash: "等待 {{name}} 出杀…",
			waitingPeach: "{{name}} 濒死,等待营救…",
			waitingNullification: "等待无懈可击…",
			waitingDiscard: "等待 {{name}} 弃牌…",
			waitingPick: "等待 {{name}} 选牌…",
			handCount: "手牌 {{n}}",
			myHand: "你的手牌",
			swipeHand: "左右滑动查看 →",
			viewAllLog: "查看全部记录",
			viewAllShort: "全部 ›",
			close: "收起",
			deadMark: "阵亡",
			skillTodo: "技能将在后续版本开放",
			guessTitle: "猜测身份",
			guessUnknown: "?",
			guessMarkLoyalist: "忠",
			guessMarkRebel: "反",
			guessMarkRenegade: "内",
			judgeIconIndulgence: "乐",
			judgeIconSupply: "兵",
			judgeIconLightning: "闪",
			waitingSkill: "等待 {{name}} 处理技能结算…",
			skillUse: "发动",
			skillDecline: "不发动",
			skillPickCards: "选择 {{n}} 张牌",
			skillPickCardsUpTo: "选择至多 {{n}} 张牌",
			skillPickSeats: "选择 {{n}} 名角色",
			skillPickSeatsUpTo: "选择至多 {{n}} 名角色",
			lordCallJink: "主公发动0,你可以打出一张【闪】",
			lordCallSlash: "主公发动0,你可以打出一张【杀】",
			guicaiPrompt: "打出一张手牌代替判定牌",
			optionObtain: "获得造成伤害的牌",
			optionXsObtain: "获得其所有牌",
			optionDraw: "摸一张牌",
			optionShowDiscard: "展示手牌并弃置同花色牌",
			optionLoseHp: "失去一点体力",
			optionLoseMaxHp: "减一点体力上限",
			optionDrawOne: "令其摸一张牌,弃置 {{n}} 张牌",
			optionDrawX: "令其摸 {{n}} 张牌,弃置一张牌",
			convertTag: "当{{card}}",
			recastTag: "重铸",
			chainedMark: "连环",
			turnedOverMark: "翻面",
			chuangMark: "创 {{n}}",
			tianMark: "田 {{n}}",
			markPao: "咆 {{n}}",
			markYi: "裔 {{n}}",
			markBian: "变 {{n}}",
			markLie: "烈 {{n}}",
			markZi: "辎 {{n}}",
			markSishu: "思蜀",
			moshiMark: "矢 {{n}}",
			jieTag: "界",
			optionRecover: "回复一点体力",
			optionDrawTwo: "摸两张牌",
			optionGlDiscard: "弃置两张手牌",
			optionGlDamage: "受到一点伤害",
			optionDsDiscard: "弃置一张手牌",
			optionDsDraw: "令其摸一张牌",
			optionTransfer: "将此伤害转移给其,其摸牌",
			optionLoseHpTake: "令其失去一点体力并获得你弃置的牌",
			optionDrawFlip: "摸 {{n}} 张牌并将武将牌翻面",
			optionDropLose: "弃置 {{n}} 张牌并失去一点体力",
			optionGiveRole: "将判定牌交给一名角色",
			optionTopDeck: "将判定牌置于牌堆顶",
			optionSelfRecover: "自己回复一点体力",
			optionLordRecover: "改为令主公回复一点体力,你摸一张牌",
			optionHealOther: "令其回复一点体力",
			optionZjDiscard: "弃置等量的牌",
			optionZjDraw: "令其摸等量的牌",
			optionEyGive: "交给其一张手牌",
			optionEyLosehp: "失去一点体力",
			optionMcSlash: "视为对指定角色使用【杀】",
			optionMcDraw: "摸一张牌",
			optionJjDraw: "摸两张牌",
			optionJjRecover: "回复一点体力",
			optionJjReset: "翻回正面并重置",
			markPojun: "破 {{n}}",
			markQuan: "权 {{n}}",
			markChun: "醇 {{n}}",
			optionJcMore: "多摸一张牌,本回合不能用【杀】",
			optionJcLess: "少摸一张牌,【杀】无距离且多用一张",
			optionJfDiscard: "弃置一张武器牌",
			optionJfDraw: "令其摸一张牌",
			optionQyGive: "交给其一张【闪】",
			optionQyTarget: "成为此【杀】的额外目标",
			optionYcDiscard: "弃置一张类别不同的手牌",
			optionYcRecover: "令其回复一点体力",
			optionJxDiscard: "弃置一张类别不同的手牌",
			optionJxFlip: "翻面并摸 {{n}} 张牌",
			optionMjTrick: "交给其一张锦囊牌",
			optionMjDrop2: "弃置两张非锦囊牌",
			optionFcDiscard: "弃置至少 {{n}} 张牌",
			optionFcDamage: "受到两点火焰伤害",
			optionPdDraw: "令其摸 {{n}} 张牌",
			optionPdDiscard: "令其弃置 {{n}} 张牌",
			optionBxBoth: "无视防具且不可被响应",
			optionBxPierce: "无视防具",
			optionBxNullify: "不可被响应",
			optionChGive: "交给其一张牌,成为此【杀】的使用者",
			optionChTarget: "成为此【杀】的额外目标",
			optionQtMove: "将其一张装备牌置入你的装备区",
			optionQtDraw: "摸一张牌",
			optionXzHeal: "回复 {{n}} 点体力",
			optionXzDamage: "对攻击范围内至多 {{n}} 名角色各造成一点伤害",
			optionQxDiscard: "弃置 {{n}} 张手牌并弃置其武器",
			optionQxPlus: "令此伤害加一",
			optionYzGive: "将装备区所有牌交给其,其失去【宴诛】",
			optionYzDiscard: "弃置一张牌",
			optionHyRed: "弃置所有红色手牌",
			optionHyBlack: "弃置所有黑色手牌",
			optionDxDraw: "摸一张牌",
			optionDxModify: "获得一枚「殚心」,修改【矫诏】",
			optionHsTake: "获得其中一张牌,防止此伤害",
			optionHsDiscard: "弃置等量的牌",
			optionDlView: "令其观看牌堆顶的两张牌并获得其中的基本牌",
			optionDlNext: "令其下个摸牌阶段多摸一张牌",
			optionGzDraw: "摸一张牌",
			optionGzRecover: "回复一点体力",
			optionZgSlash: "视为使用一张【杀】",
			optionZgGive: "交给其一张装备牌",
			optionCsLess: "少摸一张牌,【忠鉴】可展示自己至多两张牌",
			optionCsLimit: "手牌上限减一,【忠鉴】多展示对方一张牌",
			optionCsMore: "多摸两张牌,本回合不能发动【忠鉴】",
			optionFmDraw: "摸牌阶段多摸一张牌",
			optionFmRed: "红色【杀】可多指定一个目标",
			optionTbHand: "用手牌拼点",
			optionTbTop: "用牌堆顶的牌拼点(天辩)",
			optionWgTop: "置于牌堆顶",
			optionWgBottom: "置于牌堆底",
			markNi: "逆 {{n}}",
			serpentSlash: "丈八蛇矛:两张手牌当【杀】",
			optPacks: "扩展将池",
			optWind: "风包",
			optWindHint: "夏侯渊、黄忠、小乔、张角 等八将",
			optFire: "火包",
			optFireHint: "典韦、荀彧、庞统、袁绍 等八将",
			optForest: "林包",
			optForestHint: "曹丕、孟获、董卓、贾诩 等八将",
			optMountain: "山包",
			optMountainHint: "邓艾、姜维、孙策、蔡文姬 等八将",
			optYj2011: "一将成名 2011",
			optYj2011Hint: "曹植、张春华、徐盛、陈宫 等十一将",
			optYj2012: "一将成名 2012",
			optYj2012Hint: "王异、钟会、步练师、刘表 等十一将",
			optYj2013: "一将成名 2013",
			optYj2013Hint: "曹冲、满宠、朱然、伏皇后 等十一将",
			optYj2014: "一将成名 2014",
			optYj2014Hint: "张松、曹真、孙鲁班、沮授 等十一将",
			optYj2015: "一将成名 2015",
			optYj2015Hint: "曹叡、夏侯氏、刘谌、孙休 等十一将",
			optYj2016: "原创设计 2016",
			optYj2016Hint: "郭皇后、黄皓、张让、刘虞 等八将",
			optYj2017: "原创设计 2017",
			optYj2017Hint: "辛宪英、嵇康、秦宓、蔡邕 等八将",
			optJie: "界限突破",
			optJieHint: "有界版的武将整员替换为界版入池(界曹操等)",
			optDeck: "牌堆",
			optJunzheng: "军争篇",
			optJunzhengHint: "混入军争五十二张:属性杀、酒、铁索连环等",
			optIdentity: "身份",
			idRandom: "随机",
			winLord: "主公方胜利",
			winRebel: "反贼胜利",
			winRenegade: "内奸胜利",
			log: {
				setup: "对局开始,分发身份与武将",
				turn: "—— {{name}} 的回合 ——",
				pick: "{{name}} 选择了武将",
				deal: "每人摸四张起始手牌",
				draw: "{{name}} 摸 {{n}} 张牌",
				equip: "{{name}} 装备 {{card}}",
				use: "{{name}} 对 {{target}} 使用 {{card}}",
				useNoTarget: "{{name}} 使用 {{card}}",
				useConverted: "{{name}} 对 {{target}} 使用 {{card}}(原牌 {{cards}})",
				useConvertedNoTarget: "{{name}} 使用 {{card}}(原牌 {{cards}})",
				slash: "{{name}} 杀 {{target}}",
				jink: "{{name}} 打出闪",
				jinkConverted: "{{name}} 打出 {{card}}(原牌 {{cards}})",
				judge: "{{name}} 的 {{card}} 开始判定",
				judgeReveal: "{{name}} 的 {{card}} 判定亮出 {{cards}}",
				judgeResult: "{{name}} 的 {{card}} 判定：{{cards}}",
				judgeResultHit: "{{name}} 的 {{card}} 判定生效：{{cards}}",
				judgeResultMiss: "{{name}} 的 {{card}} 判定未生效：{{cards}}",
				lightningMove: "闪电移至 {{name}} 的判定区",
				damage: "{{name}} 受到 {{n}} 点伤害",
				recover: "{{name}} 回复一点体力",
				death: "{{name}} 阵亡",
				reward: "{{name}} 击杀反贼,摸三张牌",
				punish: "{{name}} 误杀忠臣,弃置所有牌",
				nullify: "{{name}} 打出无懈可击",
				nullified: "{{card}} 被无懈可击抵消",
				armorNull: "{{name}} 的 {{card}} 挡下了【杀】",
				axeHit: "{{name}} 弃置两张牌,杀依然对 {{target}} 生效",
				duel: "{{name}} 与 {{target}} 决斗",
				respondSlash: "{{name}} 打出杀",
				respondSlashConverted: "{{name}} 打出 {{card}}(原牌 {{cards}})",
				amazing: "{{name}} 使用五谷丰登",
				amazingTake: "{{name}} 拿走一张牌",
				snatch: "{{name}} 顺手牵羊 {{target}}",
				dismantle: "{{name}} 过河拆桥 {{target}}",
				collateralTake: "{{name}} 获得借刀的武器",
				placeJudge: "{{card}} 置入 {{name}} 的判定区",
				godSalvation: "{{name}} 因桃园结义回复一点体力",
				peach: "{{name}} 使用桃",
				peachSave: "{{name}} 用桃救起 {{target}}",
				discard: "{{name}} 弃置 {{n}} 张牌",
				loseHp: "{{name}} 失去 {{n}} 点体力",
				skill: "{{name}} 发动技能【{{card}}】",
				detailSkill: "{{name}} 发动技能【{{card}}】:{{cards}}",
				skillDraw: "{{name}} 因技能摸 {{n}} 张牌",
				awaken: "{{name}} 觉醒",
				tiandu: "{{name}} 发动天妒,获得判定牌",
				luoshen: "{{name}} 洛神获得判定牌",
				luoyi: "{{name}} 裸衣获得 {{n}} 张牌",
				qianxun: "{{name}} 将 {{n}} 张手牌扣置于武将牌旁",
				qianxunBack: "{{name}} 取回扣置的牌",
				yajiaoGain: "{{name}} 涯角获得亮出的牌",
				yajiaoDrop: "{{name}} 涯角亮出的牌被弃置",
				jizhiGain: "{{name}} 集智获得亮出的牌",
				jizhiDrop: "{{name}} 集智亮出的基本牌被弃置",
				rende: "{{name}} 将 {{n}} 张牌交给 {{target}}",
				zhiheng: "{{name}} 制衡 {{n}} 张牌",
				chuli: "{{name}} 除疠 {{n}} 名角色",
				jieyin: "{{name}} 与 {{target}} 结姻",
				guoseBreak: "{{name}} 弃置 {{target}} 的乐不思蜀",
				guosePlay: "{{name}} 将方块牌当乐不思蜀对 {{target}} 使用",
				gongxin: "{{name}} 观看 {{target}} 的手牌",
				gongxinDrop: "{{name}} 弃置 {{target}} 的一张红桃牌",
				liyuTake: "{{name}} 获得 {{target}} 的一张牌",
				yijue: "{{name}} 与 {{target}} 拼点",
				yijueSeal: "{{name}} 义绝获胜,{{target}} 被封印",
				yijiGain: "{{name}} 将 {{n}} 张遗计牌交给 {{target}}",
				yijiGive: "{{name}} 将一张遗计牌交给 {{target}}",
				kylin: "{{name}} 弃置 {{target}} 的一匹马(麒麟弓)",
				ganglieDrop: "{{name}} 弃置两张手牌,免受刚烈伤害",
				qingjian: "{{name}} 将 {{n}} 张牌交给 {{target}}",
				liuli: "{{name}} 流离转移杀给 {{target}}",
				tuxi: "{{name}} 突袭获得 {{n}} 张牌",
				lianying: "{{name}} 连营,令 {{n}} 名角色各摸一张牌",
				lordCall: "{{name}} 为 {{target}} 代打出手牌",
				guicai: "{{name}} 打出一张手牌代替判定牌",
				fanjianDrop: "{{name}} 弃置 {{n}} 张同花色手牌",
				analeptic: "{{name}} 饮酒",
				recast: "{{name}} 重铸 {{card}}",
				chain: "{{name}} 进入连环状态",
				unchain: "{{name}} 解除连环状态",
				fireAttack: "{{name}} 火攻 {{target}}",
				fireAttackShow: "{{name}} 展示一张手牌",
				silverLion: "{{name}} 的白银狮子发动,回复一点体力",
				turnOver: "{{name}} 将武将牌翻面",
				turnBack: "{{name}} 将武将牌翻回正面",
				buquNoWounds: "无",
				buquExisting: "{{name}} 已有「创」：{{cards}}",
				buquReveal: "不屈翻出：{{cards}}",
				buquSuccessResult: "不屈成功：新牌成为「创」，体力回复至1点",
				buquFailResult: "不屈失败：点数与已有「创」重复，继续求桃",
				buqu: "{{name}} 不屈生效,获得一个「创」并回复至一点体力",
				buquFail: "{{name}} 不屈失败,亮出的牌与「创」点数相同",
				buquClear: "{{name}} 体力回复,移去所有「创」",
				tianxiang: "{{name}} 天香将伤害转移给 {{target}}",
				tianxiangDraw: "{{name}} 天香摸 {{n}} 张牌",
				guidao: "{{name}} 打出一张黑色手牌替换判定牌并获得原判定牌",
				huangtian: "{{name}} 将一张牌交给主公 {{target}}",
				jieweiDrop: "{{name}} 解围弃置场上一张同类别的牌",
				qiangxi: "{{name}} 对 {{target}} 发动强袭",
				quhu: "{{name}} 与 {{target}} 拼点",
				quhuNowolf: "{{name}} 驱虎获胜,但被驱虎者攻击范围内没有可伤害的角色",
				tianyi: "{{name}} 与 {{target}} 拼点",
				tianyiWin: "{{name}} 天义获胜,本回合【杀】次数上限加一、无距离限制且可多指定一个目标",
				tianyiLose: "{{name}} 天义未获胜,本回合不能使用【杀】",
				tianyiExtra: "{{name}} 为【杀】额外指定目标 {{target}}",
				shuangxiongRed: "{{name}} 发动双雄,判定为红色,本回合可将黑色手牌当【决斗】使用",
				shuangxiongBlack: "{{name}} 发动双雄,判定为黑色,本回合可将红色手牌当【决斗】使用",
				niepan: "{{name}} 发动涅槃,弃置区域内所有牌,摸三张牌并将体力回复至三点",
				jieming: "{{name}} 令 {{target}} 将手牌补至体力上限(摸 {{n}} 张)",
				luanji: "{{name}} 乱击:将两张同花色手牌当【万箭齐发】使用",
				xingshang: "{{name}} 行殇,获得 {{target}} 的所有牌({{n}} 张)",
				fangzhu: "{{name}} 放逐 {{target}}:摸 {{n}} 张牌并翻面",
				songwei: "{{target}} 颂威,令 {{name}} 摸一张牌",
				zaiqi: "{{name}} 再起,亮出牌堆顶牌,弃置其中 {{n}} 张红桃并回复等量体力",
				lieren: "{{name}} 与 {{target}} 拼点",
				lierenTake: "{{name}} 烈刃获胜,获得 {{target}} 的一张牌",
				haoshi: "{{name}} 好施,将 {{n}} 张手牌交给 {{target}}",
				dimeng: "{{name}} 缔盟,弃置 {{n}} 张牌并交换 {{target}} 与另一名角色的手牌",
				baonue: "{{name}} 暴虐判定为黑桃,董卓回复一点体力",
				benghuaiMax: "{{name}} 崩坏,减一点体力上限",
				juxiang: "{{name}} 巨象,获得南蛮入侵",
				yinghun: "{{name}} 对 {{target}} 发动英魂(已损失 {{n}} 点体力)",
				tuntian: "{{name}} 屯田,判定牌置于武将牌上称为「田」",
				qiaobian: "{{name}} 巧变,弃置一张手牌跳过一个阶段",
				qiaobianDraw: "{{name}} 巧变,获得 {{n}} 名角色各一张手牌",
				qiaobianMove: "{{name}} 巧变,将场上一张牌移动给 {{target}}",
				zhijian: "{{name}} 直谏,将装备牌置入 {{target}} 的装备区并摸一张牌",
				guzheng: "{{name}} 固政,获得弃牌堆中的 {{n}} 张牌",
				guzhengBack: "{{name}} 固政,令 {{target}} 收回一张牌",
				beige: "{{name}} 悲歌,弃置一张牌令 {{target}} 判定",
				duanchang: "{{target}} 断肠,失去所有技能(杀死 {{name}} 的代价)",
				fangquan: "{{name}} 放权,{{target}} 将获得一个额外回合",
				xiangle: "{{name}} 为享乐弃置一张基本牌",
				xiangleNull: "{{name}} 享乐生效,此杀无效",
				zhibaObtain: "{{name}} 制霸,获得拼点的两张牌({{n}} 张)",
				zhiba: "{{name}} 与 {{target}} 拼点(制霸)",
				detailAmazing: "{{name}} 五谷亮出：{{cards}}",
				detailAmazingTake: "{{name}} 五谷取走：{{cards}}",
				detailSnatch: "{{name}} 牵走 {{target}} 的 {{cards}}",
				detailDismantle: "{{name}} 拆 {{target}}：{{cards}}",
				detailCollateralTake: "{{name}} 借刀取得：{{cards}}",
				detailDiscard: "{{name}} 弃置：{{cards}}",
				detailYajiaoGain: "{{name}} 涯角获得：{{cards}}",
				detailYajiaoDrop: "{{name}} 涯角弃置：{{cards}}",
				detailJizhiGain: "{{name}} 集智获得：{{cards}}",
				detailJizhiDrop: "{{name}} 集智弃置：{{cards}}",
				detailGongxinDrop: "{{name}} 攻心弃置 {{target}} 的 {{cards}}",
				detailFireAttackShow: "{{name}} 火攻展示：{{cards}}",
				detailGuicai: "{{name}} 鬼才改判：{{cards}}",
				detailGuidao: "{{name}} 鬼道改判：{{cards}}",
				detailJieweiDrop: "{{name}} 解围弃置：{{cards}}",
				detailQiaobianMove: "{{name}} 巧变移给 {{target}}：{{cards}}",
				detailGuzheng: "{{name}} 固政获得：{{cards}}",
				detailGuzhengBack: "{{name}} 固政令 {{target}} 收回：{{cards}}",
				detailAxeHit: "{{name}} 弃置 {{cards}},杀依然对 {{target}} 生效",
				detailFireAttack: "{{name}} 弃置 {{cards}},火攻对 {{target}} 造成火焰伤害",
				detailGanglieDrop: "{{name}} 弃置 {{cards}},免受刚烈伤害",
				detailFanjianDrop: "{{name}} 弃置同花色手牌:{{cards}}",
				detailXuanfeng: "{{name}} 旋风,弃置 {{target}} 的 {{cards}}",
				detailRezhenjun: "{{name}} 镇军,弃置 {{target}} 的 {{cards}}",
				detailZhenlie: "{{name}} 贞烈,失去一点体力并弃置来源的 {{cards}}",
				detailQingxiDiscard: "{{name}} 倾袭,弃置 {{cards}}",
				detailHuaiyiDrop: "{{name}} 怀异,弃置同色手牌:{{cards}}",
				detailYaomingDrop: "{{name}} 邀名,弃置 {{target}} 的 {{cards}}",
				detailJunxingDiscard: "{{name}} 弃置 {{cards}}(类别均不同)",
				detailYuceDiscard: "{{name}} 弃置 {{cards}}(类别不同)",
				detailMiejiDiscard: "{{name}} 因灭计弃置:{{cards}}",
				detailFenchengDiscard: "{{name}} 焚城,弃置 {{cards}}",
				detailPindiDiscard: "{{name}} 品第,弃置 {{cards}}",
				detailShifeiDiscard: "{{name}} 饰非,弃置 {{target}} 的 {{cards}}",
				jiangObtain: "{{name}} 失去一点体力,获得 {{cards}}",
				moshi: "{{name}} 收回 {{target}} 的 {{n}} 张没矢牌",
				jiezi: "{{name}} 截辎,{{target}} 获得一个额外的摸牌阶段",
				jieziMark: "{{name}} 截辎,{{target}} 获得一枚「辎」",
				hanzhan: "{{name}} 酣战,获得 {{cards}}",
				qingnang: "{{name}} 青囊,令 {{target}} 回复一点体力",
				sishu: "{{name}} 思蜀,{{target}} 的【乐不思蜀】判定效果反转",
				wulie: "{{name}} 武烈,令 {{n}} 名角色各获得一枚「烈」",
				piaolingTop: "{{name}} 飘零,将判定牌置于牌堆顶",
				piaolingGive: "{{name}} 飘零,将 {{cards}} 交给 {{target}}",
				luoying: "{{name}} 落英,获得 {{n}} 张梅花牌",
				pojun: "{{name}} 破军,将 {{n}} 张牌扣置于 {{target}} 的武将牌旁",
				pojunBack: "{{name}} 取回破军扣置的 {{n}} 张牌",
				buyi: "{{name}} 补益,展示 {{target}} 的手牌:{{cards}}",
				ganlu: "{{name}} 甘露,交换两名角色的装备区(共 {{n}} 张)",
				mingce: "{{name}} 明策,将一张牌交给 {{target}}",
				xuanhuoTake: "{{name}} 眩惑,获得 {{target}} 的 {{n}} 张牌",
				xianzhenWin: "{{name}} 陷阵获胜,本回合对 {{target}} 无距离限制且无视防具",
				xianzhenLose: "{{name}} 陷阵未获胜,本回合不能使用【杀】",
				enyuanGive: "{{name}} 恩怨,将一张手牌交给 {{target}}",
				rezhenjun: "{{name}} 镇军,弃置 {{target}} 的 {{n}} 张牌",
				xuanfeng: "{{name}} 旋风,弃置 {{target}} 的 {{n}} 张牌",
				zhenlie: "{{name}} 贞烈,失去一点体力并弃置来源一张牌",
				fuli: "{{name}} 伏枥,回复至 {{n}} 点体力并翻面",
				"zhiyu-show": "{{name}} 智愚,摸一张牌并展示 {{n}} 张手牌",
				jiefan: "{{name}} 解烦,指定 {{target}}",
				"chunlao-put": "{{name}} 醇醪,将 {{n}} 张【杀】置为「醇」",
				"quanji-put": "{{name}} 权计,将 {{cards}} 置为「权」",
				qianxi: "{{name}} 潜袭,{{target}} 本回合不能使用或打出该颜色手牌",
				"miji-give": "{{name}} 秘计,将 {{n}} 张牌交给 {{target}}",
				anxu: "{{name}} 安恤,{{target}} 获得 {{cards}}",
				zhuiyi: "{{name}} 追忆,{{target}} 摸三张牌并回复一点体力",
				chengxiang: "{{name}} 称象,亮出牌堆顶 {{n}} 张牌",
				renxin: "{{name}} 仁心,弃置一张装备牌并翻面,防止此伤害",
				"qiuyuan-give": "{{name}} 将一张【闪】交给 {{target}}",
				"qiuyuan-become": "{{name}} 成为此【杀】的额外目标",
				"zhuikong-win": "{{name}} 惴恐获胜,{{target}} 本回合不能指定其他角色为目标",
				"zhuikong-lose": "{{name}} 惴恐未获胜,与 {{target}} 的距离本回合视为一",
				"qiaoshui-win": "{{name}} 巧说获胜,本回合下一张【杀】可多指定一个目标",
				"qiaoshui-lose": "{{name}} 巧说未获胜,本回合不能使用锦囊牌",
				jyzongshi: "{{name}} 纵适,获得拼点牌 {{cards}}",
				xiansi: "{{name}} 陷嗣,将 {{target}} 的一张牌置为「逆」(现有 {{n}} 张)",
				xiansi2: "{{name}} 移去两张「逆」,视为对 {{target}} 使用【杀】",
				zhiyan: "{{name}} 直言,{{target}} 摸一张牌并展示:{{cards}}",
				danshou: "{{name}} 胆守,弃置 {{n}} 张牌并指定 {{target}}",
				"danshou-give": "{{name}} 将 {{cards}} 交给 {{target}}",
				junxing: "{{name}} 峻刑,弃置 {{n}} 张牌并指定 {{target}}",
				"junxing-flip": "{{name}} 翻面",
				"junxing-discard": "{{name}} 弃置一张类别均不同的手牌",
				"yuce-show": "{{name}} 御策,展示 {{cards}}",
				"yuce-discard": "{{name}} 弃置一张类别不同的手牌",
				duodao: "{{name}} 夺刀,获得 {{target}} 的武器 {{cards}}",
				longyin: "{{name}} 龙吟,令 {{target}} 的【杀】不计入次数",
				zongxuan: "{{name}} 纵玄,将 {{n}} 张牌置于牌堆顶",
				xinjuece: "{{name}} 绝策,对 {{target}} 造成一点伤害",
				xinmieji: "{{name}} 灭计,将 {{cards}} 置于牌堆顶并指定 {{target}}",
				xinfencheng: "{{name}} 焚城,全场依次弃牌或受火焰伤害",
				"fencheng-discard": "{{name}} 焚城,弃置 {{n}} 张牌",
				"mieji-discard": "{{name}} 因灭计弃置 {{n}} 张牌",
				shenduan: "{{name}} 慎断,将 {{cards}} 当【兵粮寸断】对 {{target}} 使用",
				yonglve: "{{name}} 勇略,弃置 {{target}} 判定区的 {{cards}}",
				"yonglve-draw": "{{name}} 勇略,摸一张牌",
				pindi: "{{name}} 品第,弃置 {{cards}} 并指定 {{target}}",
				"pindi-discard": "{{name}} 品第,弃置 {{n}} 张牌",
				xinsidi: "{{name}} 司敌,弃置 {{cards}} 并标记 {{target}}",
				"sidi-slash": "{{name}} 司敌,视为对 {{target}} 使用一张【杀】",
				qiangzhi: "{{name}} 强识,展示 {{target}} 的手牌 {{cards}}",
				"qiangzhi-draw": "{{name}} 强识,摸一张牌",
				xiantu: "{{name}} 献图,将 {{n}} 张牌交给 {{target}}",
				"xiantu-hurt": "{{name}} 献图,目标本回合未杀死过角色,失去一点体力",
				olbenxi: "{{name}} 奔袭,此牌无视防具且不可被响应",
				xinzhongyong: "{{name}} 忠勇,将 {{cards}} 交给 {{target}}",
				"zy-slash": "{{name}} 忠勇,对 {{target}} 使用一张【杀】",
				chanhui: "{{name}} 谮毁,令 {{target}} 选择交牌或成为额外目标",
				"chanhui-extra": "{{name}} 谮毁,{{target}} 成为此【杀】的额外目标",
				"chanhui-give": "{{name}} 谮毁,交给 {{target}} 一张牌",
				jiaojin: "{{name}} 骄矜,弃置 {{cards}} 令此伤害减一",
				fenli: "{{name}} 奋励,跳过一个阶段",
				pingkou: "{{name}} 平寇,对 {{n}} 名角色各造成一点伤害",
				shenxing: "{{name}} 慎行,弃置 {{cards}} 并摸一张牌",
				olbingyi: "{{name}} 秉壹,展示手牌 {{cards}}",
				jianying: "{{name}} 渐营,摸一张牌",
				"shibei-recover": "{{name}} 矢北,回复一点体力",
				"shibei-lose": "{{name}} 矢北,失去一点体力",
				"qieting-move": "{{name}} 窃听,将 {{target}} 的装备 {{cards}} 移动到自己装备区",
				xianzhou: "{{name}} 献州,{{target}} 回复 {{n}} 点体力",
				"xianzhou-give": "{{name}} 献州,将 {{n}} 张装备牌交给 {{target}}",
				"xianzhou-damage": "{{name}} 献州,对 {{n}} 名角色各造成一点伤害",
				"qingxi-plus": "{{name}} 倾袭,{{target}} 令此伤害加一",
				"qingxi-discard": "{{name}} 倾袭,弃置 {{n}} 张手牌并弃置 {{target}} 的武器",
				"yanzhu-give": "{{name}} 将装备区所有牌交给 {{target}},{{target}} 失去技能【宴诛】",
				"yanzhu-discard": "{{name}} 宴诛,弃置一张牌",
				"huaiyi-show": "{{name}} 怀异,展示所有手牌",
				"huaiyi-drop": "{{name}} 怀异,弃置 {{n}} 张同色手牌",
				"huaiyi-gain": "{{name}} 怀异,获得 {{n}} 名角色的各一张牌",
				"wurong-show": "{{name}} 与 {{target}} 同时展示手牌:{{cards}}",
				"wurong-gain": "{{name}} 怃戎,获得 {{target}} 的一张牌",
				"xx-put": "{{name}} 兴学,将一张牌置于牌堆顶",
				mingjian: "{{name}} 明鉴,将所有手牌交给 {{target}}",
				zhanjue: "{{name}} 战绝,将所有手牌当【决斗】对 {{target}} 使用",
				xinzhaofu: "{{name}} 诏缚,令 {{target}} 视为在所有其他吴势力角色的攻击范围内",
				"yaoming-drop": "{{name}} 邀名,随机弃置 {{target}} 的一张手牌",
				"shifei-discard": "{{name}} 饰非,弃置 {{target}} 的一张牌",
				"zhongjian-show": "{{name}} 展示 {{cards}}",
				jianzheng: "{{name}} 谏征,将此【杀】取消,并将一张手牌置于牌堆顶",
				zhuandui: "{{name}} 与 {{target}} 拼点",
				funan: "{{name}} 复难,与 {{target}} 交换响应的牌",
				fuzhu: "{{name}} 对 {{target}} 发动伏诛",
				"fuzhu-end": "{{name}} 将剩余的【杀】洗回牌堆",
				shouxi: "{{name}} 守玺,声明 {{card}}",
				"shouxi-null": "{{name}} 守玺生效,{{target}} 的【杀】对其无效",
				"huimin-show": "{{name}} 惠民,展示 {{cards}}",
				"huimin-take": "{{name}} 获得 {{cards}}",
				bizhuan: "{{name}} 笔札,将 {{cards}} 置为「书」",
				tongbo: "{{name}} 通博,交换 {{cards}}",
				"tongbo-give": "{{name}} 将「书」{{cards}} 交给 {{target}}",
				wengua: "{{name}} 与 {{target}} 问卦"
			},
			cardDesc: {
				crossbow: "攻击范围一。出牌阶段可以使用任意数量的【杀】。",
				double_sword: "攻击范围二。使用【杀】指定异性角色为目标后,令其选择:弃置一张手牌,或令你摸一张牌。",
				qinggang_sword: "攻击范围二。使用【杀】无视目标的防具。",
				blade: "攻击范围三。使用的【杀】被【闪】抵消后,可以对同一目标再使用一张【杀】。",
				spear: "攻击范围三。可以将两张手牌当【杀】使用。",
				axe: "攻击范围三。使用的【杀】被【闪】抵消后,可以弃置两张牌,令此【杀】依然造成伤害。",
				halberd: "攻击范围四。使用的【杀】是最后一张手牌时,可以额外指定至多两名目标。",
				kylin_bow: "攻击范围五。使用【杀】对目标造成伤害后,可以弃置其一匹马。",
				ice_sword: "攻击范围二。使用【杀】造成伤害时,可以防止此伤害,改为依次弃置目标两张牌。",
				guding_blade: "攻击范围二。使用【杀】对没有手牌的目标造成伤害时,此伤害加一。",
				fan: "攻击范围四。可以将普通【杀】当火【杀】使用。",
				eight_diagram: "需要打出【闪】时,可以进行一次判定:结果为红色,视为打出了【闪】。",
				renwang_shield: "黑色【杀】对你无效。",
				vine: "普通【杀】对你无效;你受到火焰伤害时,此伤害加一。",
				silver_lion: "你受到大于一点的伤害时,将伤害减至一点;失去此装备时,回复一点体力。",
				defHorse: "其他角色计算与你的距离时加一。",
				offHorse: "你计算与其他角色的距离时减一。",
				indulgence: "延时锦囊。判定阶段进行判定:结果不为红桃,跳过本回合出牌阶段。",
				supply_shortage: "延时锦囊。判定阶段进行判定:结果不为梅花,跳过本回合摸牌阶段。",
				lightning: "延时锦囊。判定阶段进行判定:结果为黑桃二至九,受到三点雷电伤害;否则移至下家的判定区。"
			},
			error: {
				notYourTurn: "现在不是你的出牌阶段",
				notYourAsk: "现在不需要你响应",
				noCard: "这张牌不在你手里",
				notPlayable: "这张牌现在不能使用",
				badTarget: "目标不合法",
				badGeneral: "这名武将不在候选中",
				badRespond: "不能用这张牌响应",
				badChoose: "选择不合法",
				badSkill: "技能现在不能发动"
			},
			card: {
				slash: "杀",
				jink: "闪",
				peach: "桃",
				duel: "决斗",
				savage_assault: "南蛮入侵",
				archery_attack: "万箭齐发",
				amazing_grace: "五谷丰登",
				god_salvation: "桃园结义",
				ex_nihilo: "无中生有",
				snatch: "顺手牵羊",
				dismantlement: "过河拆桥",
				collateral: "借刀杀人",
				nullification: "无懈可击",
				indulgence: "乐不思蜀",
				lightning: "闪电",
				crossbow: "诸葛连弩",
				double_sword: "雌雄双股剑",
				qinggang_sword: "青釭剑",
				blade: "青龙偃月刀",
				spear: "丈八蛇矛",
				axe: "贯石斧",
				halberd: "方天画戟",
				kylin_bow: "麒麟弓",
				ice_sword: "寒冰剑",
				eight_diagram: "八卦阵",
				renwang_shield: "仁王盾",
				jueying: "绝影+1",
				dilu: "的卢+1",
				zhuahuangfeidian: "爪黄飞电+1",
				chitu: "赤兔-1",
				dayuan: "大宛-1",
				zixing: "紫骍-1",
				fire_slash: "火杀",
				thunder_slash: "雷杀",
				analeptic: "酒",
				fire_attack: "火攻",
				iron_chain: "铁索连环",
				supply_shortage: "兵粮寸断",
				guding_blade: "古锭刀",
				fan: "朱雀羽扇",
				vine: "藤甲",
				silver_lion: "白银狮子",
				hualiu: "骅骝+1"
			},
			general: {
				caocao: "曹操",
				simayi: "司马懿",
				xiahoudun: "夏侯惇",
				zhangliao: "张辽",
				xuchu: "许褚",
				guojia: "郭嘉",
				zhenji: "甄姬",
				liubei: "刘备",
				guanyu: "关羽",
				zhangfei: "张飞",
				zhugeliang: "诸葛亮",
				zhaoyun: "赵云",
				machao: "马超",
				huangyueying: "黄月英",
				sunquan: "孙权",
				ganning: "甘宁",
				lvmeng: "吕蒙",
				huanggai: "黄盖",
				zhouyu: "周瑜",
				daqiao: "大乔",
				luxun: "陆逊",
				sunshangxiang: "孙尚香",
				huatuo: "华佗",
				lvbu: "吕布",
				diaochan: "貂蝉",
				xiahouyuan: "夏侯渊",
				caoren: "曹仁",
				huangzhong: "黄忠",
				weiyan: "魏延",
				xiaoqiao: "小乔",
				zhoutai: "周泰",
				zhangjiao: "张角",
				yuji: "于吉",
				dianwei: "典韦",
				xunyu: "荀彧",
				pangtong: "庞统",
				wolong: "卧龙诸葛",
				taishici: "太史慈",
				yuanshao: "袁绍",
				yanliangwenchou: "颜良文丑",
				pangde: "庞德",
				xuhuang: "徐晃",
				caopi: "曹丕",
				menghuo: "孟获",
				zhurong: "祝融",
				sunjian: "孙坚",
				lusu: "鲁肃",
				dongzhuo: "董卓",
				jiaxu: "贾诩",
				zhanghe: "张郃",
				dengai: "邓艾",
				jiangwei: "姜维",
				liushan: "刘禅",
				sunce: "孙策",
				erzhang: "张昭张纮",
				zuoci: "左慈",
				caiwenji: "蔡文姬",
				caozhi: "曹植",
				yujin: "于禁",
				zhangchunhua: "张春华",
				xin_fazheng: "法正",
				xin_masu: "马谡",
				xin_xushu: "徐庶",
				xusheng: "徐盛",
				lingtong: "凌统",
				wuguotai: "吴国太",
				chengong: "陈宫",
				gaoshun: "高顺",
				wangyi: "王异",
				xunyou: "荀攸",
				zhonghui: "钟会",
				old_madai: "马岱",
				liaohua: "廖化",
				guanzhang: "关兴张苞",
				bulianshi: "步练师",
				handang: "韩当",
				chengpu: "程普",
				liubiao: "刘表",
				caozhang: "曹彰",
				manchong: "满宠",
				guohuai: "郭淮",
				caochong: "曹冲",
				guanping: "关平",
				liufeng: "刘封",
				jianyong: "简雍",
				yufan: "虞翻",
				panzhangmazhong: "潘璋马忠",
				zhuran: "朱然",
				xin_liru: "李儒",
				fuhuanghou: "伏寿",
				hanhaoshihuan: "韩浩史涣",
				chenqun: "陈群",
				caozhen: "曹真",
				zhangsong: "张松",
				wuyi: "吴懿",
				zhoucang: "周仓",
				zhuhuan: "朱桓",
				guyong: "顾雍",
				sunluban: "孙鲁班",
				yj_jushou: "沮授",
				caifuren: "蔡夫人",
				caoxiu: "曹休",
				caorui: "曹叡",
				zhongyao: "钟繇",
				xiahoushi: "夏侯氏",
				liuchen: "刘谌",
				zhangyi: "张嶷",
				zhuzhi: "朱治",
				quancong: "全琮",
				sunxiu: "孙休",
				gongsunyuan: "公孙渊",
				guotufengji: "郭图逢纪",
				guohuanghou: "郭皇后",
				sunziliufang: "孙资刘放",
				huanghao: "黄皓",
				liyan: "李严",
				sundeng: "孙登",
				cenhun: "岑昏",
				zhangrang: "张让",
				liuyu: "刘虞",
				xinxianying: "辛宪英",
				jikang: "嵇康",
				wuxian: "吴苋",
				qinmi: "秦宓",
				xuezong: "薛综",
				xushi: "徐氏",
				caojie: "曹节",
				caiyong: "蔡邕",
				re_caocao: "曹操",
				re_simayi: "司马懿",
				re_xiahoudun: "夏侯惇",
				re_zhangliao: "张辽",
				re_xuchu: "许褚",
				re_guojia: "郭嘉",
				re_zhenji: "甄姬",
				re_liubei: "刘备",
				re_guanyu: "关羽",
				re_zhangfei: "张飞",
				re_zhugeliang: "诸葛亮",
				re_zhaoyun: "赵云",
				re_machao: "马超",
				re_huangyueying: "黄月英",
				re_sunquan: "孙权",
				re_ganning: "甘宁",
				re_lvmeng: "吕蒙",
				re_huanggai: "黄盖",
				re_zhouyu: "周瑜",
				re_daqiao: "大乔",
				re_luxun: "陆逊",
				re_sunshangxiang: "孙尚香",
				re_huatuo: "华佗",
				re_lvbu: "吕布",
				re_diaochan: "貂蝉",
				re_xiahouyuan: "夏侯渊",
				re_caoren: "曹仁",
				re_huangzhong: "黄忠",
				re_weiyan: "魏延",
				re_xiaoqiao: "小乔",
				re_zhoutai: "周泰",
				re_zhangjiao: "张角",
				re_dianwei: "典韦",
				re_xunyu: "荀彧",
				re_pangtong: "庞统",
				re_wolong: "卧龙诸葛",
				re_taishici: "太史慈",
				re_yuanshao: "袁绍",
				re_yanliangwenchou: "颜良文丑",
				re_pangde: "庞德",
				re_xuhuang: "徐晃",
				re_caopi: "曹丕",
				re_menghuo: "孟获",
				re_zhurong: "祝融",
				re_sunjian: "孙坚",
				re_lusu: "鲁肃",
				re_dongzhuo: "董卓",
				re_jiaxu: "贾诩",
				re_zhanghe: "张郃",
				re_dengai: "邓艾",
				re_jiangwei: "姜维",
				re_liushan: "刘禅",
				re_sunce: "孙策",
				re_erzhang: "张昭张纮",
				re_caiwenji: "蔡文姬"
			},
			skill: {
				jianxiong: "奸雄",
				hujia: "护驾",
				fankui: "反馈",
				guicai: "鬼才",
				ganglie: "刚烈",
				qingjian: "清俭",
				tuxi: "突袭",
				luoyi: "裸衣",
				tiandu: "天妒",
				yiji: "遗计",
				luoshen: "洛神",
				qingguo: "倾国",
				rende: "仁德",
				jijiang: "激将",
				wusheng: "武圣",
				yijue: "义绝",
				paoxiao: "咆哮",
				tishen: "替身",
				guanxing: "观星",
				kongcheng: "空城",
				longdan: "龙胆",
				yajiao: "涯角",
				mashu: "马术",
				tieji: "铁骑",
				jizhi: "集智",
				qicai: "奇才",
				zhiheng: "制衡",
				jiuyuan: "救援",
				qixi: "奇袭",
				fenwei: "奋威",
				keji: "克己",
				qinxue: "勤学",
				kurou: "苦肉",
				zhaxiang: "诈降",
				yingzi: "英姿",
				fanjian: "反间",
				guose: "国色",
				liuli: "流离",
				qianxun: "谦逊",
				lianying: "连营",
				jieyin: "结姻",
				xiaoji: "枭姬",
				chuli: "除疠",
				jijiu: "急救",
				wushuang: "无双",
				liyu: "利驭",
				lijian: "离间",
				biyue: "闭月",
				gongxin: "攻心",
				shensu: "神速",
				jushou: "据守",
				jiewei: "解围",
				liegong: "烈弓",
				kuanggu: "狂骨",
				tianxiang: "天香",
				hongyan: "红颜",
				buqu: "不屈",
				fenji: "奋激",
				leiji: "雷击",
				guidao: "鬼道",
				huangtian: "黄天",
				qiangxi: "强袭",
				quhu: "驱虎",
				jieming: "节命",
				lianhuan: "连环",
				niepan: "涅槃",
				huoji: "火计",
				kanpo: "看破",
				bazhen: "八阵",
				tianyi: "天义",
				luanji: "乱击",
				xueyi: "血裔",
				shuangxiong: "双雄",
				mengjin: "猛进",
				duanliang: "断粮",
				xingshang: "行殇",
				fangzhu: "放逐",
				songwei: "颂威",
				huoshou: "祸首",
				zaiqi: "再起",
				juxiang: "巨象",
				lieren: "烈刃",
				yinghun: "英魂",
				haoshi: "好施",
				dimeng: "缔盟",
				jiuchi: "酒池",
				roulin: "肉林",
				benghuai: "崩坏",
				baonue: "暴虐",
				wansha: "完杀",
				luanwu: "乱武",
				weimu: "帷幕",
				qiaobian: "巧变",
				tuntian: "屯田",
				zaoxian: "凿险",
				jixi: "急袭",
				tiaoxin: "挑衅",
				zhiji: "志继",
				xiangle: "享乐",
				fangquan: "放权",
				ruoyu: "若愚",
				jiang: "激昂",
				hunzi: "魂姿",
				zhiba: "制霸",
				zhijian: "直谏",
				guzheng: "固政",
				beige: "悲歌",
				duanchang: "断肠",
				botu: "博图",
				qingnang: "青囊",
				shebian: "设变",
				moshi: "没矢",
				qimou: "奇谋",
				piaoling: "飘零",
				ninge: "狞恶",
				cangzhuo: "藏拙",
				hanzhan: "酣战",
				jianchu: "鞬出",
				jiezi: "截辎",
				wulie: "武烈",
				changbiao: "长标",
				sishu: "思蜀",
				luoying: "落英",
				jiushi: "酒诗",
				rezhenjun: "镇军",
				jueqing: "绝情",
				shangshi: "伤逝",
				xinxuanhuo: "眩惑",
				xinenyuan: "恩怨",
				olsanyao: "散谣",
				rezhiman: "制蛮",
				xinwuyan: "无言",
				xinjujian: "举荐",
				xinpojun: "破军",
				xuanfeng: "旋风",
				ganlu: "甘露",
				buyi: "补益",
				mingce: "明策",
				zhichi: "智迟",
				xinxianzhen: "陷阵",
				jinjiu: "禁酒",
				zhenlie: "贞烈",
				miji: "秘计",
				qice: "奇策",
				zhiyu: "智愚",
				quanji: "权计",
				zili: "自立",
				paiyi: "排异",
				qianxi: "潜袭",
				dangxian: "当先",
				fuli: "伏枥",
				fuhun: "父魂",
				old_anxu: "安恤",
				zhuiyi: "追忆",
				gongji: "弓骑",
				jiefan: "解烦",
				lihuo: "疠火",
				chunlao: "醇醪",
				rezishou: "自守",
				zongshi: "宗室",
				new_jiangchi: "将驰",
				rejingce: "精策",
				chengxiang: "称象",
				renxin: "仁心",
				danshou: "胆守",
				zhiyan: "直言",
				zongxuan: "纵玄",
				qiuyuan: "求援",
				zhuikong: "惴恐",
				qiaoshui: "巧说",
				jyzongshi: "纵适",
				xiansi: "陷嗣",
				xiansi2: "陷嗣",
				junxing: "峻刑",
				yuce: "御策",
				duodao: "夺刀",
				anjian: "暗箭",
				longyin: "龙吟",
				xinjuece: "绝策",
				xinmieji: "灭计",
				xinfencheng: "焚城",
				shenduan: "慎断",
				yonglve: "勇略",
				pindi: "品第",
				faen: "法恩",
				xinsidi: "司敌",
				qiangzhi: "强识",
				xiantu: "献图",
				olbenxi: "奔袭",
				xinzhongyong: "忠勇",
				chanhui: "谮毁",
				jiaojin: "骄矜",
				fenli: "奋励",
				pingkou: "平寇",
				shenxing: "慎行",
				olbingyi: "秉壹",
				qieting: "窃听",
				xianzhou: "献州",
				jianying: "渐营",
				shibei: "矢北",
				qianju: "千驹",
				qingxi: "倾袭",
				huituo: "恢拓",
				mingjian: "明鉴",
				xingshuai: "兴衰",
				huomo: "活墨",
				zuoding: "佐定",
				qiaoshi: "樵拾",
				yanyu: "燕语",
				zhanjue: "战绝",
				qinwang: "勤王",
				wurong: "怃戎",
				shizhi: "矢志",
				xinanguo: "安国",
				yaoming: "邀名",
				yanzhu: "宴诛",
				xingxue: "兴学",
				xinzhaofu: "诏缚",
				huaiyi: "怀异",
				jigong: "急攻",
				shifei: "饰非",
				jiaozhao: "矫诏",
				danxin: "殚心",
				guizao: "瑰藻",
				jiyu: "讥谀",
				qinqing: "寝情",
				huisheng: "贿生",
				dcduliang: "督粮",
				fulin: "腹鳞",
				kuangbi: "匡弼",
				jishe: "极奢",
				lianhuo: "链祸",
				taoluan: "滔乱",
				zhige: "止戈",
				zongzuo: "宗祚",
				zhongjian: "忠鉴",
				caishi: "才识",
				qingxian: "清弦",
				canyun: "残韵",
				juexiang: "绝响",
				fumian: "福绵",
				daiyan: "怠宴",
				jianzheng: "谏征",
				zhuandui: "专对",
				tianbian: "天辩",
				funan: "复难",
				xinjiexun: "诫训",
				wengua: "问卦",
				fuzhu: "伏诛",
				shouxi: "守玺",
				huimin: "惠民",
				bizhuan: "笔札",
				tongbo: "通博"
			},
			skillDesc: {
				jianxiong: "当你受到一点伤害后,你可以获得对你造成伤害的牌。",
				hujia: "主公技。当你需要打出一张【闪】时,你可以令其他魏势力角色依次选择是否打出一张【闪】,若有角色打出,视为你打出之。",
				fankui: "每当你受到一点伤害后,你可以获得伤害来源的一张牌。",
				guicai: "当一名角色的判定牌生效前,你可以打出一张手牌代替之。",
				ganglie: "当你受到一点伤害后,你可以判定:若结果不为红桃,伤害来源选择一项——弃置两张手牌,或受到你造成的一点伤害。",
				qingjian: "当你于摸牌阶段外获得手牌后,你可以将其中任意张牌交给一名其他角色。",
				tuxi: "摸牌阶段,你可以改为获得至多两名手牌数不小于你的其他角色各一张手牌。",
				luoyi: "摸牌阶段,你可以改为亮出牌堆顶的三张牌,获得其中的基本牌、武器牌与【决斗】;本回合你的【杀】与【决斗】造成的伤害加一。",
				tiandu: "当你的判定牌生效后,你获得之。",
				yiji: "当你受到一点伤害后,你可以摸两张牌,然后可以将至多两张手牌交给其他角色。",
				luoshen: "准备阶段,你可以判定:若结果为黑色,你获得之并重复此流程,直到结果为红色。",
				qingguo: "你可以将一张黑色手牌当【闪】使用或打出。",
				rende: "出牌阶段,你可以将任意张手牌交给一名其他角色;你本阶段首次累计给出至少两张牌后,你回复一点体力。",
				jijiang: "主公技。当你需要打出一张【杀】时,你可以令其他蜀势力角色依次选择是否打出一张【杀】,若有角色打出,视为你打出之。",
				wusheng: "你可以将一张红色牌当【杀】使用或打出。",
				yijue: "出牌阶段限一次,你可以与一名其他角色拼点:若你赢,其本回合不能使用或打出手牌、非锁定技失效;若你没赢,你可以令其回复一点体力。",
				paoxiao: "锁定技。你使用【杀】无次数限制。",
				tishen: "限定技。准备阶段,你可以将体力回复至你上个回合结束时的值,然后摸等量的牌。",
				guanxing: "准备阶段,你可以观看牌堆顶的五张牌(存活角色小于四时改为三张),将其中任意张牌置于牌堆底、其余按原顺序置于牌堆顶。",
				kongcheng: "锁定技。若你没有手牌,你不能成为【杀】或【决斗】的目标。",
				longdan: "你可以将一张【杀】当【闪】、【闪】当【杀】使用或打出。",
				yajiao: "当你于回合外使用或打出手牌后,你可以亮出牌堆顶的一张牌:若类别相同,你可以将之交给一名角色;若类别不同,你弃置之。",
				mashu: "锁定技。你计算与其他角色的距离减一。",
				tieji: "当你使用【杀】指定目标后,你可以判定:除非其弃置一张与判定牌花色相同的牌,否则其不能使用【闪】响应此【杀】。",
				jizhi: "当你使用锦囊牌时,你可以摸一张牌。",
				qicai: "锁定技。你使用锦囊牌无距离限制。",
				zhiheng: "出牌阶段限一次,你可以弃置任意张牌并摸等量的牌。",
				jiuyuan: "主公技。锁定技。其他吴势力角色对你使用【桃】时,你额外回复一点体力。",
				qixi: "你可以将一张黑色手牌当【过河拆桥】使用。",
				fenwei: "限定技。当一张多目标锦囊牌指定目标后,你可以令其中任意名角色不受此牌影响。",
				keji: "若你于本回合出牌阶段内未使用或打出过【杀】,你跳过弃牌阶段。",
				qinxue: "觉醒技。准备阶段或结束阶段,若你的手牌数减体力值不小于三(七人及以上局改为不小于二),你减一点体力上限,然后获得技能「攻心」。",
				kurou: "出牌阶段限一次,你可以弃置一张手牌,然后失去一点体力。",
				zhaxiang: "锁定技。每当你失去一点体力后,你摸三张牌;若此时为你的回合,本回合你使用【杀】的次数上限加一,你使用红色【杀】无距离限制且不能被【闪】响应。",
				yingzi: "摸牌阶段,你多摸一张牌;你的手牌上限等于体力上限。",
				fanjian: "出牌阶段限一次,你可以将一张手牌交给一名其他角色,然后其选择一项:展示所有手牌并弃置其中同花色的牌;或失去一点体力。",
				guose: "出牌阶段限一次,你可以将一张方块牌当【乐不思蜀】使用,或弃置一张方块牌并弃置场上的一张【乐不思蜀】,然后摸一张牌。",
				liuli: "当你成为【杀】的目标时,你可以弃置一张牌,将此【杀】转移给你攻击范围内的另一名角色(不能是此【杀】的使用者)。",
				qianxun: "当你成为延时锦囊牌或其他角色使用的锦囊牌的唯一目标时,你可以将所有手牌扣置于武将牌旁,回合结束时取回。",
				lianying: "当你失去最后的手牌后,你可以令至多 X 名角色各摸一张牌(X 为你此次失去的手牌数)。",
				jieyin: "出牌阶段限一次,你可以弃置两张手牌并选择一名已受伤的男性角色,你与其各回复一点体力。",
				xiaoji: "当你失去装备区的牌后,你摸两张牌。",
				chuli: "出牌阶段限一次,你可以弃置一张牌并选择至多三名有牌的其他角色,弃置你与这些角色各一张牌;以此法弃置黑桃牌的角色摸一张牌。",
				jijiu: "你的回合外,你可以将一张红色手牌当【桃】使用。",
				wushuang: "锁定技。你使用【杀】时,目标须连续打出两张【闪】才能抵消;与你决斗的角色每次须连续打出两张【杀】。",
				liyu: "当你使用【杀】对其他角色造成伤害后,其可以令你获得其一张牌,然后其指定另一名角色,视为你对该角色使用一张【决斗】。",
				lijian: "出牌阶段限一次,你可以弃置一张牌并选择两名男性角色,视为前者对后者使用一张【决斗】。",
				biyue: "结束阶段,你可以摸一张牌。",
				gongxin: "出牌阶段限一次,你可以观看一名其他角色的手牌,然后弃置其中一张红桃牌。",
				shensu: "你可以选择至多两项:跳过判定阶段与摸牌阶段;跳过出牌阶段并弃置一张装备牌。每选择一项,视为你对一名其他角色使用一张无距离限制的【杀】。",
				jushou: "结束阶段,你可以摸一张牌并将武将牌翻面。",
				jiewei: "你可以将装备区里的牌当【无懈可击】使用。",
				liegong: "你使用【杀】指定目标后,若其手牌数不小于你的体力值或不大于你的攻击范围,你可以令其不能使用【闪】响应此【杀】。",
				kuanggu: "锁定技。当你对距离一以内的一名角色造成一点伤害后,你回复一点体力。",
				tianxiang: "当你受到伤害时,你可以弃置一张红桃手牌并选择一名其他角色,将此伤害转移给其,然后其摸 X 张牌(X 为其已损失的体力值)。",
				hongyan: "锁定技。你的黑桃牌视为红桃牌。",
				buqu: "锁定技。当你处于濒死状态时,你亮出牌堆顶的一张牌:若其点数与你武将牌上的「创」均不同,你将之置于武将牌上(称为「创」)并将体力回复至一点;否则进入濒死结算。你的手牌上限等于「创」的数量。",
				fenji: "当一名角色的手牌被其他角色弃置或获得后,你可以失去一点体力,令其摸两张牌。",
				leiji: "当你使用或打出【闪】时,你可以令一名角色判定:若结果为黑色,其受到你造成的一点雷电伤害,然后你回复一点体力。",
				guidao: "当一名角色的判定牌生效前,你可以打出一张黑色手牌替换之并获得原判定牌。",
				huangtian: "主公技。其他群势力角色的出牌阶段限一次,其可以将一张【闪】或黑桃手牌交给你。",
				qiangxi: "出牌阶段限一次,你可以弃置一张武器牌或失去一点体力,然后对攻击范围内的一名其他角色造成一点伤害。",
				quhu: "出牌阶段限一次,你可以与一名体力值大于你的角色拼点:若你赢,其对其攻击范围内一名由你选择的角色造成一点伤害;若你没赢,其对你造成一点伤害。",
				jieming: "当你受到一点伤害后,你可以令一名角色将手牌摸至 X 张(X 为其体力上限且至多为五)。",
				lianhuan: "你可以将一张梅花手牌当【铁索连环】使用或重铸。",
				niepan: "限定技。当你处于濒死状态时,你可以弃置你区域内的所有牌并将武将牌翻回正面,摸三张牌并将体力回复至三点。",
				huoji: "你可以将一张红色牌当【火攻】使用。",
				kanpo: "你可以将一张黑色牌当【无懈可击】使用。",
				bazhen: "锁定技。若你的装备区里没有防具牌,你视为装备着【八卦阵】。",
				tianyi: "出牌阶段限一次,你可以与一名其他角色拼点:若你赢,本回合你使用【杀】的次数上限加一、无距离限制且可以额外指定一个目标;若你没赢,本回合你不能使用【杀】。",
				luanji: "出牌阶段,你可以将两张花色相同的手牌当【万箭齐发】使用。",
				xueyi: "主公技。锁定技。你的手牌上限加 X(X 为其他群势力角色数的两倍)。",
				shuangxiong: "摸牌阶段,你可以改为判定并获得判定牌,然后本回合你可以将与判定牌颜色不同的一张手牌当【决斗】使用。",
				mengjin: "当你使用的【杀】被目标角色使用的【闪】抵消时,你可以弃置其一张牌。",
				duanliang: "你可以将一张黑色基本牌或黑色装备牌当【兵粮寸断】使用。",
				xingshang: "当其他角色死亡时,你可以获得其所有牌。",
				fangzhu: "当你受到伤害后,你可以令一名其他角色摸 X 张牌并将其武将牌翻面(X 为你已损失的体力值)。",
				songwei: "主公技。其他魏势力角色的判定牌生效后,若结果为黑色,其可以令你摸一张牌。",
				huoshou: "锁定技。【南蛮入侵】对你无效;当其他角色使用【南蛮入侵】造成伤害时,伤害来源改为你。",
				zaiqi: "摸牌阶段,若你已受伤,你可以改为亮出牌堆顶的 X 张牌(X 为你已损失的体力值):你回复等同于其中红桃牌数量的体力,然后获得其余的牌。",
				juxiang: "锁定技。【南蛮入侵】对你无效;当其他角色使用的未转化的【南蛮入侵】结算结束后,你获得之。",
				lieren: "当你使用【杀】对一名角色造成伤害后,你可以与其拼点:若你赢,你获得其一张牌。",
				yinghun: "准备阶段,若你已受伤,你可以选择一名其他角色并选择一项:令其摸一张牌并弃置 X 张牌;或令其摸 X 张牌并弃置一张牌(X 为你已损失的体力值)。",
				haoshi: "摸牌阶段,你多摸两张牌;摸牌后若你的手牌数不少于五,你将一半的手牌(向下取整)交给手牌最少的一名其他角色。",
				dimeng: "出牌阶段限一次,你可以弃置 X 张牌并选择两名其他角色,令他们交换手牌(X 为这两名角色手牌数之差)。",
				jiuchi: "你可以将一张黑桃手牌当【酒】使用。",
				roulin: "锁定技。你对女性角色使用【杀】、或女性角色对你使用【杀】时,目标须连续打出两张【闪】才能抵消。",
				benghuai: "结束阶段,若你的体力值不是全场最少,你选择一项:失去一点体力;或减一点体力上限。",
				baonue: "主公技。当其他群势力角色造成伤害后,你可以判定:若结果为黑桃,你回复一点体力。",
				wansha: "锁定技。你的回合内,只有处于濒死状态的角色才能使用【桃】或【酒】。",
				luanwu: "限定技。出牌阶段,你可以令所有其他角色依次选择:对距离最近的一名角色使用一张【杀】,或失去一点体力。",
				weimu: "锁定技。你不能成为黑色锦囊牌的目标。",
				qiaobian: "你可以弃置一张手牌并跳过你的一个阶段(判定/摸牌/出牌/弃牌,回合开始与结束阶段除外)。若你以此法跳过摸牌阶段,你可以获得至多两名其他角色各一张手牌;若你以此法跳过出牌阶段,你可以将场上的一张牌移动到另一名角色区域内的相应位置。",
				tuntian: "当你于回合外失去牌后,你可以判定:若结果不为红桃,将判定牌置于你的武将牌上,称为「田」。你计算与其他角色的距离减去「田」的数量。",
				zaoxian: "觉醒技。准备阶段,若「田」的数量不少于三张,你减一点体力上限,获得技能「急袭」。",
				jixi: "出牌阶段,你可以将一张「田」当【顺手牵羊】使用。",
				tiaoxin: "出牌阶段限一次,你可以令攻击范围内有你的一名其他角色选择:对你使用一张【杀】,或令你弃置其一张牌。",
				zhiji: "觉醒技。准备阶段,若你没有手牌,你减一点体力上限,回复一点体力或摸两张牌,然后获得技能「观星」。",
				xiangle: "锁定技。当你成为【杀】的目标后,来源须选择:弃置一张基本牌,或此【杀】对你无效。",
				fangquan: "出牌阶段,你可以跳过此阶段;若如此做,弃牌阶段开始时,你可以弃置一张手牌,令一名其他角色获得一个额外的回合。",
				ruoyu: "主公技,觉醒技。准备阶段,若你的体力值为全场最少,你增加一点体力上限并回复一点体力,然后获得技能「激将」。",
				jiang: "当你使用【决斗】或红色【杀】指定目标后,或成为【决斗】或红色【杀】的目标后,你可以摸一张牌。",
				hunzi: "觉醒技。准备阶段,若你的体力值为一点,你减一点体力上限,获得技能「英姿」和「英魂」。",
				zhiba: "主公技。其他吴势力角色的出牌阶段限一次,其可以与你拼点(你可以拒绝);若其没赢,你获得两张拼点牌。",
				zhijian: "出牌阶段,你可以将手牌中的一张装备牌置入一名其他角色的空装备槽,然后摸一张牌。",
				guzheng: "其他角色的弃牌阶段结束时,若其本阶段弃置了至少一张牌,你可以令其获得其中一张牌,然后你获得其余的牌。",
				beige: "当一名角色受到【杀】造成的伤害后,你可以弃置一张牌并令其判定:红桃,其回复一点体力;方块,其摸两张牌;黑桃,伤害来源翻面;梅花,伤害来源弃置两张牌。",
				duanchang: "锁定技。当你死亡时,杀死你的角色失去所有技能。",
				botu: "每轮限 X 次(X 为存活角色数且至多为三)。回合结束时,若本回合置入弃牌堆的牌包含至少四种花色,你可以获得一个额外的回合。",
				qingnang: "出牌阶段,你可以弃置一张手牌,令一名本回合未成为过【青囊】目标的角色回复一点体力;若你弃置的是黑色牌,本回合你不能再发动【青囊】。",
				shebian: "当你的武将牌翻面后,你可以移动场上一张装备牌。",
				moshi: "锁定技。你使用【杀】对目标角色造成伤害后,若其装备区有防具牌或坐骑牌,你将此【杀】置于其武将牌上;其失去防具牌或坐骑牌后,你获得其武将牌上的这些牌。",
				qimou: "限定技。出牌阶段,你可以失去任意点体力并摸等量的牌,然后直到回合结束,你计算与其他角色的距离减 X,且你使用【杀】的次数上限加 X(X 为你失去的体力值)。",
				piaoling: "结束阶段,你可以判定:若结果为红桃,你选择一项——将判定牌交给一名角色(若交给自己,你弃置一张牌);或将之置于牌堆顶。",
				ninge: "锁定技。当一名角色于一回合内第二次受到伤害后,若该角色或伤害来源是你,你摸一张牌,然后弃置其装备区或判定区的一张牌。",
				cangzhuo: "弃牌阶段,若你本回合未使用过锦囊牌,你的锦囊牌不计入手牌上限。",
				hanzhan: "当你发起拼点或成为拼点目标时,你可以令对方的拼点牌改为随机一张;拼点结束后,你可以获得本次拼点牌中点数最大的【杀】。",
				jianchu: "当你使用【杀】指定目标后,你可以弃置其一张牌:若不为基本牌,此【杀】不可被【闪】响应且本回合你使用【杀】的次数上限加一;若为基本牌,其获得此【杀】。",
				jiezi: "当其他角色跳过摸牌阶段后,你可以选择一名角色:若其手牌数为全场最少且没有「辎」,其获得一枚「辎」;否则其摸一张牌。有「辎」的角色摸牌阶段结束时,你移去其「辎」,令其获得一个额外的摸牌阶段。",
				wulie: "限定技。结束阶段,你可以失去任意点体力并选择等量的其他角色,这些角色各获得一枚「烈」;有「烈」的角色受到伤害时,移去一枚「烈」并防止此伤害。",
				changbiao: "出牌阶段限一次,你可以将任意张手牌当【杀】使用(无距离限制);若此【杀】造成伤害,出牌阶段结束时你摸 X 张牌(X 为此【杀】的实体牌数)。",
				sishu: "出牌阶段限一次,你可以选择一名角色:本局游戏内其【乐不思蜀】的判定效果反转。",
				luoying: "当其他角色的梅花牌因弃置或判定进入弃牌堆后,你获得这些牌。",
				jiushi: "出牌阶段,若你的武将牌正面朝上,你可以翻面并视为使用一张【酒】;当你受到伤害后,若你的武将牌背面朝上,你翻回正面;当你处于濒死状态时,若你的武将牌正面朝上,你可以翻面并回复一点体力。",
				rezhenjun: "准备阶段,你可以弃置一名角色 X 张牌(X 为其手牌数与体力值之差,且至少为一),然后选择一项:你弃置等同于其中非装备牌数量的牌;或令其摸等量的牌。",
				jueqing: "锁定技。你造成的伤害均视为失去体力。",
				shangshi: "当你的手牌数小于你已损失的体力值时,你可以将手牌摸至你已损失的体力值。",
				xinxuanhuo: "摸牌阶段,你可以改为令一名其他角色摸两张牌,然后除非其对其攻击范围内由你选择的另一名角色使用一张【杀】,否则你获得其两张牌。",
				xinenyuan: "当你一次性获得一名其他角色至少两张牌后,你令其摸一张牌;当你受到一点伤害后,来源须选择:交给你一张手牌,或失去一点体力。",
				olsanyao: "出牌阶段各限一次,你可以弃置一张牌,对体力值最大的一名角色或手牌数最多的一名角色造成一点伤害。",
				rezhiman: "当你对其他角色造成伤害时,你可以防止此伤害,获得其区域内的一张牌。",
				xinwuyan: "锁定技。你造成的锦囊牌伤害无效;其他角色造成的锦囊牌伤害对你无效。",
				xinjujian: "结束阶段,你可以弃置一张非基本手牌,令一名其他角色选择一项:摸两张牌;回复一点体力;或翻回正面并重置(解除连环状态)。",
				xinpojun: "出牌阶段,当你使用【杀】指定目标后,你可以将至多 X 张牌扣置于其武将牌旁(X 为其体力值);当前回合结束后,其取回这些牌。",
				xuanfeng: "当你失去装备区的牌后,或于弃牌阶段弃置至少两张牌后,你可以依次弃置一至两名其他角色的共计两张牌。",
				ganlu: "出牌阶段限一次,你可以交换两名角色的装备区,装备数之差不能超过你已损失的体力值。",
				buyi: "当一名角色进入濒死状态时,你可以随机展示其一张手牌:若不为基本牌,其弃置之并回复一点体力。",
				mingce: "出牌阶段限一次,你可以将一张【杀】或装备牌交给一名其他角色,然后其选择一项:视为对其攻击范围内由你指定的一名角色使用一张【杀】;或摸一张牌。",
				zhichi: "锁定技。当你于回合外受到伤害后,直到当前回合结束,【杀】与普通锦囊牌对你无效。",
				xinxianzhen: "出牌阶段限一次,你可以与一名角色拼点:若你赢,本回合你对其使用牌无距离限制且无视其防具,你对其使用【杀】不计次数,且你使用【杀】时可以额外指定其为目标;若你没赢,本回合你不能使用【杀】且你的【杀】不计入手牌上限。",
				jinjiu: "锁定技。你的【酒】均视为【杀】。",
				zhenlie: "当你成为其他角色使用的【杀】或普通锦囊牌的目标后,你可以失去一点体力令此牌对你无效,然后弃置来源一张牌(随机)。",
				miji: "结束阶段,若你已受伤,你可以摸 X 张牌(X 为你已损失的体力值),然后可以将至多等量的手牌交给一名其他角色。",
				qice: "出牌阶段限一次,你可以将所有手牌当任意一张普通锦囊牌使用(目标须合法)。",
				zhiyu: "当你受到伤害后,你可以摸一张牌并展示所有手牌;若颜色均相同,来源弃置一张牌。",
				quanji: "当你受到一点伤害后,你可以摸一张牌并将一张手牌置于你的武将牌上称为「权」;你的手牌上限加 X(X 为「权」数)。",
				zili: "觉醒技。准备阶段,若「权」数不小于三,你选择一项:回复一点体力或摸两张牌,然后减一点体力上限并获得技能【排异】。",
				paiyi: "出牌阶段限一次,你可以移去一张「权」,令一名角色摸两张牌;若其手牌数大于你,你对其造成一点伤害。",
				qianxi: "准备阶段,你可以摸一张牌并弃置一张牌,然后令距离一的一名角色本回合不能使用或打出与你弃置牌同颜色的手牌。",
				dangxian: "锁定技。回合开始时,你获得一个额外的出牌阶段。",
				fuli: "限定技。当你处于濒死状态时,你可以将体力回复至存活势力数(至多为上限),然后翻面。",
				fuhun: "你可以将两张手牌当【杀】使用或打出;出牌阶段你以此法使用的【杀】造成伤害后,你本回合获得【武圣】与【咆哮】。",
				old_anxu: "出牌阶段限一次,你可以选择两名手牌数不同的其他角色:手牌少的角色随机获得手牌多的角色一张手牌并展示,若不为黑桃,你摸一张牌。",
				zhuiyi: "当你死亡时,你可以令一名其他角色(杀死你的角色除外)摸三张牌并回复一点体力。",
				gongji: "出牌阶段限一次,你可以弃置一张牌,本回合你的攻击范围无限;若弃置的是装备牌,你可以弃置一名其他角色一张牌(随机)。",
				jiefan: "限定技。出牌阶段,你可以选择一名角色:攻击范围内含其的角色依次选择弃置一张武器牌或令其摸一张牌。",
				lihuo: "你使用普通【杀】时可以改为火【杀】;你以此法使用的火【杀】可以额外指定一名目标,且此【杀】造成伤害后你失去一点体力。",
				chunlao: "结束阶段,若你的武将牌上没有「醇」,你可以将至少一张【杀】置为「醇」;当一名角色处于濒死状态时,你可以移去一张「醇」,令其回复一点体力。",
				rezishou: "摸牌阶段,你可以多摸 X 张牌(X 为存活势力数);若如此做,本回合你防止你对其他角色造成的伤害。",
				zongshi: "锁定技。你的手牌上限加 X(X 为存活势力数)。",
				new_jiangchi: "摸牌阶段,你可以选择一项:多摸一张牌,本回合不能使用或打出【杀】;或少摸一张牌,本回合使用【杀】无距离限制且次数上限加一。",
				rejingce: "出牌阶段结束时,你可以摸 X 张牌(X 为你本阶段使用过牌的类别数);锁定技,你的手牌上限加 X(X 为你本回合使用过牌的花色数)。",
				chengxiang: "当你受到一点伤害后,你可以亮出牌堆顶的四张牌,获得其中点数之和不大于十三的任意张牌。",
				renxin: "当一名体力值为一的角色受到伤害时,你可以弃置一张装备牌并翻面,防止此伤害。",
				danshou: "出牌阶段,你可以弃置 X 张牌并选择攻击范围内一名有牌的角色(X 为本阶段此前发动次数加一):X 为一时其随机弃置一张牌,为二时其交给你一张牌,为三时你对其造成一点伤害,不小于四时你与其各摸两张牌。",
				zhiyan: "结束阶段,你可以令一名角色摸一张牌并展示之:若为装备牌,其使用之并回复一点体力。",
				zongxuan: "当你的牌因弃置而进入弃牌堆后,你可以将其中任意张牌置于牌堆顶(先选的牌更靠近牌堆顶)。",
				qiuyuan: "当你成为【杀】的目标时,你可以令来源攻击范围内的一名其他角色选择:交给你一张【闪】,或成为此【杀】的额外目标。",
				zhuikong: "其他角色的准备阶段,若你已受伤,你可以与其拼点:若你赢,其本回合使用牌不能指定其他角色为目标;若你没赢,其至你的距离本回合视为一。",
				qiaoshui: "出牌阶段限一次,你可以与一名其他角色拼点:若你赢,本回合你使用的下一张【杀】可以额外指定一个目标;若你没赢,本回合你不能使用锦囊牌。",
				jyzongshi: "锁定技。拼点结算后,若你赢,你获得对方的拼点牌;若你没赢,你收回自己的拼点牌。",
				xiansi: "准备阶段,你可以将一至两名有牌的其他角色各一张牌置于你的武将牌上,称为「逆」;其他角色出牌阶段可以移去两张「逆」,视为对你使用一张【杀】(计入次数且有距离限制)。",
				xiansi2: "出牌阶段,你可以移去刘封的两张「逆」,视为对其使用一张【杀】(计入次数且有距离限制)。",
				junxing: "出牌阶段限一次,你可以弃置至少一张手牌并令一名其他角色选择:弃置一张与你弃置的牌类别均不同的手牌,或翻面并摸 X 张牌(X 为你弃置的牌数)。",
				yuce: "当你受到一点伤害后,你可以展示一张手牌:来源须弃置一张类别不同的手牌,否则你回复一点体力。",
				duodao: "当你受到【杀】造成的一点伤害后,你可以弃置一张牌,获得来源装备区的武器牌。",
				anjian: "锁定技。你使用【杀】对目标造成伤害时,若你不在其攻击范围内,此伤害加一。",
				longyin: "当一名角色于出牌阶段使用【杀】后,你可以弃置一张牌,令此【杀】不计入次数;若此【杀】为红色,你摸一张牌。",
				xinjuece: "结束阶段,你可以对一名没有手牌的角色造成一点伤害。",
				xinmieji: "出牌阶段限一次,你可以将一张黑色锦囊牌置于牌堆顶,令一名有手牌的其他角色选择:交给你一张锦囊牌,或弃置两张非锦囊牌。",
				xinfencheng: "限定技。出牌阶段,你可以令所有其他角色依次选择:弃置至少 X 张牌(X 为此前因此技能弃置的牌数加一),或受到你造成的两点火焰伤害。",
				shenduan: "当你的黑色基本牌因弃置而进入弃牌堆后,你可以将其中一张当【兵粮寸断】对一名判定区没有【兵粮寸断】的其他角色使用。",
				yonglve: "其他角色的判定阶段开始时,若其在你的攻击范围内,你可以弃置其判定区里的一张牌,然后视为你对其使用一张【杀】;若此【杀】被【闪】抵消,你摸一张牌。",
				pindi: "出牌阶段,你可以弃置一张牌并选择一名其他角色(不能选择本回合已选择过的角色,不能弃置本回合已弃置过的类别),令其摸 X 张牌或弃置 X 张牌(X 为你本回合发动此技能的次数);若其已受伤,你横置。",
				faen: "当一名角色翻至正面向上或横置后,你可以令其摸一张牌。",
				xinsidi: "其他角色的出牌阶段开始时,你可以弃置一张与你装备区牌颜色相同的非基本牌:其本回合不能使用或打出该颜色的牌;若其本回合未使用过【杀】,其弃牌阶段结束时,视为你对其使用一张【杀】。",
				qiangzhi: "出牌阶段开始时,你可以随机展示一名其他角色的一张手牌:本回合你使用与该牌类别相同的牌时,摸一张牌。",
				xiantu: "其他角色的出牌阶段开始时,你可以摸两张牌并交给其两张牌;本回合结束时,若其本回合未杀死过角色,你失去一点体力。",
				olbenxi: "锁定技。你于回合内每使用一张牌,本回合你计算与其他角色的距离便减一;当你使用仅指定一个目标的【杀】时,若你与其他所有角色的距离均不大于一,你选择:此牌无视防具、不可被【闪】响应,或两者兼备。",
				xinzhongyong: "当你使用的【杀】结算完毕后,你可以将此【杀】或目标响应打出的【闪】交给目标以外的一名角色;若其获得红色牌,其可以对你攻击范围内的一名角色使用一张【杀】。",
				chanhui: "每回合限一次。当你使用【杀】指定唯一目标后,你可以令你攻击范围内一名可以成为此【杀】目标的其他角色选择:交给你一张牌并成为此【杀】的使用者,或也成为此【杀】的目标。",
				jiaojin: "当你受到男性角色造成的伤害时,若你有装备牌,你可以弃置一张装备牌,令此伤害减一。",
				fenli: "若你的手牌数为全场最多,你可以跳过摸牌阶段;若你的体力值为全场最多,你可以跳过出牌阶段;若你的装备区牌数为全场最多且至少有一件,你可以跳过弃牌阶段。",
				pingkou: "回合结束时,你可以对至多 X 名其他角色各造成一点伤害(X 为你本回合跳过的阶段数)。",
				shenxing: "出牌阶段,你可以弃置两张牌并摸一张牌。",
				olbingyi: "当你的牌因弃置而进入弃牌堆后,你可以展示所有手牌;若颜色均相同,你与至多 X 名其他角色各摸一张牌(X 为你的手牌数)。",
				qieting: "其他角色的回合结束时,若其本回合未使用过指定其他角色为目标的牌,你可以选择一项:将其装备区的一张牌置入你的装备区,或摸一张牌。",
				xianzhou: "限定技。出牌阶段,你可以将装备区所有牌交给一名其他角色,然后其选择:回复 X 点体力,或对其攻击范围内至多 X 名角色各造成一点伤害(X 为你交给其的牌数)。",
				jianying: "你于出牌阶段内使用牌时,若此牌与你本阶段使用的上一张牌花色或点数相同,你可以摸一张牌。",
				shibei: "锁定技。你受到伤害后,若为你本回合第一次受到伤害,你回复一点体力,否则你失去一点体力。",
				qianju: "锁定技。若你已受伤,你计算与其他角色的距离减 X(X 为你已损失的体力值)。",
				qingxi: "当你使用【杀】对目标角色造成伤害时,若你的装备区里有武器牌,你可以令其选择:弃置 X 张手牌并弃置你的此武器牌(X 为此武器牌的攻击范围),或令此伤害加一。",
				huituo: "当你受到伤害后,你可以令一名角色判定:红色,其回复一点体力;黑色,其摸 X 张牌(X 为此次伤害的伤害点数)。",
				mingjian: "出牌阶段限一次。你可以将所有手牌交给一名其他角色,然后直到其下个回合结束,其手牌上限加一、使用【杀】的次数上限加一。",
				xingshuai: "主公技。限定技。当你进入濒死状态时,其他魏势力角色可以依次令你回复一点体力,然后这些角色依次受到一点伤害。",
				huomo: "当你需要使用一张本回合内未使用过的基本牌时,你可以将一张黑色非基本牌置于牌堆顶,视为使用之。",
				zuoding: "当其他角色于其出牌阶段内使用黑桃牌指定目标后,若本回合内没有角色受到过伤害,你可以令其中一名目标角色摸一张牌。",
				qiaoshi: "其他角色的结束阶段开始时,若你的手牌数与其相等,你可以与其各摸一张牌。",
				yanyu: "出牌阶段,你可以重铸【杀】;出牌阶段结束时,若你于此阶段以此法重铸了至少两张【杀】,你可以令一名男性角色摸两张牌。",
				zhanjue: "出牌阶段,你可以将所有手牌当【决斗】使用;此【决斗】结算后,你与以此法受到伤害的角色各摸一张牌;若你于同一阶段内以此法摸了两张或更多的牌,此技能于本回合内失效。",
				qinwang: "主公技。当你需要使用或打出一张【杀】时,你可以弃置一张牌,然后视为你发动了【激将】;若有角色响应,该角色打出【杀】时摸一张牌。",
				wurong: "出牌阶段限一次。你可以与一名有手牌的其他角色同时展示一张手牌:若你展示的是【杀】且其展示的不是【闪】,你弃置此【杀】并对其造成一点伤害;若你展示的不是【杀】且其展示的是【闪】,你弃置你展示的牌并获得其一张牌。",
				shizhi: "锁定技。当你的体力值为一时,你的【闪】均视为【杀】。",
				xinanguo: "出牌阶段限一次。你可以选择一名其他角色:若其手牌数为全场最少,其摸一张牌;若其体力值为全场最低且已受伤,其回复一点体力;若其装备区内牌数为全场最少,其随机使用一张装备牌。然后若其未执行的效果你满足条件,你执行之。",
				yaoming: "每回合限一次。当你造成或受到伤害后,你可以选择一名手牌数与你不同的角色:其手牌数多于你,你随机弃置其一张手牌;少于你,其摸一张牌。",
				yanzhu: "出牌阶段限一次。你可以令一名有牌的其他角色选择:将其装备区里的所有牌交给你,然后你失去技能【宴诛】;或弃置一张牌。",
				xingxue: "结束阶段开始时,你可以令至多 X 名角色依次各摸一张牌并将一张牌置于牌堆顶(X 为你的体力值;若你已失去技能【宴诛】,改为你的体力上限)。",
				xinzhaofu: "主公技。限定技。出牌阶段,你可以选择至多两名其他角色:这些角色视为在所有其他吴势力角色的攻击范围内。",
				huaiyi: "出牌阶段限一次。你可以展示所有手牌:若颜色不全部相同,你选择一种颜色并弃置该颜色的所有手牌,然后获得至多 X 名其他角色的各一张牌(X 为你以此法弃置的牌数);若你以此法获得的牌不少于两张,你失去一点体力。",
				jigong: "出牌阶段开始时,你可以摸两张牌;若如此做,你本回合的手牌上限改为你此阶段造成的伤害点数之和。",
				shifei: "当你需要使用或打出【闪】时,你可以令当前回合角色摸一张牌;然后若其手牌数不为全场唯一最多,你弃置手牌数最多的一名角色的一张牌,视为你使用或打出了一张【闪】。",
				jiaozhao: "出牌阶段限一次。你可以展示一张手牌并选择距离你最近的一名其他角色,令其声明一张基本牌的牌名;本阶段内,你可以将此牌当声明的牌使用(以此法对自己使用【桃】【酒】不受目标限制)。",
				danxin: "当你受到伤害后,你可以摸一张牌,或获得一枚「殚心」。你有至少一枚「殚心」后,【矫诏】可声明的牌名扩展至普通锦囊牌;有至少两枚后,【矫诏】改为你自行声明牌名,且你受到伤害后直接摸一张牌。",
				guizao: "结束阶段,若你于弃牌阶段弃置了至少两张花色各不相同的手牌,你可以选择一项:摸一张牌,或回复一点体力。",
				jiyu: "出牌阶段,你可以令一名本阶段未成为过【讥谀】目标的有手牌的其他角色弃置一张手牌;若此牌为黑桃,你翻面,其失去一点体力。本回合内,你不能使用与以此法弃置的牌花色相同的手牌。",
				qinqing: "结束阶段,你可以选择任意名攻击范围内含有主公且有手牌的非主公角色,依次弃置这些角色各一张手牌并令其各摸一张牌,然后你摸 X 张牌(X 为其中手牌数多于主公的角色数)。",
				huisheng: "当你受到其他角色造成的伤害时,你可以展示至少一张手牌,令来源选择:获得其中一张牌并防止此伤害(此后你不能再对其发动【贿生】),或弃置与展示牌等量的牌。",
				dcduliang: "出牌阶段限一次。你可以随机获得一名其他角色的一张手牌,然后选择一项:令其观看牌堆顶的两张牌并获得其中的基本牌;或令其下个摸牌阶段多摸一张牌。",
				fulin: "锁定技。你于回合内获得的牌不计入手牌上限。",
				kuangbi: "出牌阶段限一次。你可以令一名有牌的其他角色将至多三张牌扣置于你的武将牌上;你的下个准备阶段,你获得这些牌,然后其摸等量的牌。",
				jishe: "出牌阶段,若你的手牌上限大于零,你可以摸一张牌,然后本回合你的手牌上限减一。结束阶段,若你没有手牌,你可以横置至多 X 名其他角色(X 为你的体力值)。",
				lianhuo: "锁定技。当你处于连环状态受到火焰伤害时,若此伤害并非连环传导,此伤害加一。",
				taoluan: "出牌阶段,你可以将一张手牌当一张本局游戏未以此法使用过的基本牌或普通锦囊牌使用;此牌结算后,你令一名其他角色选择:交给你一张与该牌类别不同的牌,或令你失去一点体力且本回合【滔乱】失效。",
				zhige: "出牌阶段限一次。若你的手牌数大于体力值,你可以选择一名攻击范围内含有你的其他角色,令其选择:视为使用一张【杀】,或将一张装备牌交给你。",
				zongzuo: "锁定技。游戏开始时,你增加 X 点体力上限并回复 X 点体力(X 为存活势力数);一名角色死亡后,若其势力没有存活角色,你减一点体力上限。",
				zhongjian: "出牌阶段限一次。你可以展示一张手牌并选择一名有手牌的其他角色,随机展示其至多三张手牌:每有一张花色与你展示的牌相同,你摸一张牌;若有点数相同的,你对其造成一点伤害;每有一张花色与点数均不同,你弃置一张牌。",
				caishi: "摸牌阶段,你可以选择一项:少摸一张牌,本回合【忠鉴】可展示自己至多两张牌;手牌上限减一,本回合【忠鉴】多展示对方一张牌;多摸两张牌,本回合不能发动【忠鉴】。",
				qingxian: "出牌阶段限一次。你可以弃置至多 X 张手牌(X 为你的体力值)并选择等量的其他角色:装备数小于你的回复一点体力,等于你的摸一张牌,大于你的失去一点体力。若你弃置的牌数等于体力值,你摸一张牌。",
				canyun: "出牌阶段限一次。你可以弃置至多 X 张手牌(X 为你的体力值)并选择等量的本回合未被【残韵】选择过的其他角色,结算同【清弦】。",
				juexiang: "当你死亡时,你可以令一名其他角色获得【残韵】,随机弃置场上一张梅花牌,然后其获得【绝响】。",
				fumian: "准备阶段,你可以选择一项:本回合摸牌阶段多摸一张牌;或本回合你使用红色【杀】可多指定一个目标。若与你上回合的选择不同,数值改为二。",
				daiyan: "结束阶段,你可以令一名其他角色获得牌堆中第一张红桃基本牌。若其与你上回合【怠宴】选择的角色相同,其失去一点体力。",
				jianzheng: "当一名角色使用【杀】指定你为目标后,你可以将一张手牌置于牌堆顶,取消此【杀】的全部目标;若此【杀】为红色,你成为此【杀】的目标。",
				zhuandui: "当你使用【杀】指定目标后,或你成为【杀】的目标后,你可以与另一方拼点:若你赢,你为此【杀】来源时其不可被【闪】响应,你为目标时此【杀】对你无效。",
				tianbian: "你拼点时,可以改为用牌堆顶的一张牌拼点;你的红桃拼点牌点数视为 K。",
				funan: "其他角色响应你使用的牌而使用或打出牌后,你可以与其交换这两张牌(其本回合不能使用或打出获得的牌)。【诫训】重置后,改为你获得其牌而不交给其你的牌。",
				xinjiexun: "结束阶段,你可以令一名其他角色摸等同于场上方块牌数的牌,然后其弃置 X 张牌(X 为本技能此前发动次数)。若其因此弃置了所有牌,次数清零且【复难】升级。",
				wengua: "其他角色的出牌阶段限一次,其可以交给你一张牌,你将此牌置于牌堆顶或牌堆底,然后你与其从另一端各摸一张牌。",
				fuzhu: "一名男性角色的结束阶段,若牌堆剩余牌数不大于你体力值的十倍,你可以对其依次使用牌堆中的所有【杀】(至多等同于游戏人数张,无视距离),然后将剩余的牌洗回牌堆。",
				shouxi: "当你成为【杀】的目标后,你可以声明一种本局未声明过的基本牌或锦囊牌牌名:来源须弃置一张同名手牌或装备牌,否则此【杀】对你无效;若其弃置,其获得你的一张牌。",
				huimin: "结束阶段,你可以摸 X 张牌(X 为手牌数小于体力值的角色数),然后展示等量手牌,由你选择的一名此类角色开始,这些角色按座次各获得其中一张。",
				bizhuan: "当你使用牌后,或你成为【杀】或普通锦囊牌的目标后,你可以摸一张牌并置为「书」(至多四张)。你的手牌上限增加「书」的数量。",
				tongbo: "摸牌阶段结束时,你可以将至多四张手牌与等量「书」交换。若你的「书」凑齐四种花色,你将所有「书」依次交给其他角色。",
				re_jianxiong: "当你受到一点伤害后,你可以获得对你造成伤害的牌并摸一张牌。",
				re_guicai: "当一名角色的判定牌生效前,你可以打出一张牌代替之。",
				re_ganglie: "当你受到一点伤害后,你可以判定:红色,你对伤害来源造成一点伤害;黑色,你弃置伤害来源的一张牌。",
				re_tuxi: "摸牌阶段,你可以改为获得至多两名其他角色各一张手牌。",
				re_luoyi: "摸牌阶段,你可以改为亮出牌堆顶的三张牌,获得其中的基本牌、武器牌与【决斗】,然后直到你的下回合开始,你的【杀】与【决斗】造成的伤害加一。",
				re_luoshen: "准备阶段,你可以判定:若结果为黑色,你获得之并重复此流程,直到结果为红色。你以此法获得的牌本回合不计入手牌上限。",
				re_rende: "出牌阶段,你可以将任意张手牌交给一名其他角色(每名角色每阶段限一次);你本阶段首次累计给出至少两张牌后,可以视为使用一张基本牌。",
				re_wusheng: "你可以将一张红色牌当【杀】使用或打出;你使用方块【杀】无距离限制。",
				re_yijue: "出牌阶段限一次,你可以弃置一张牌并令一名有手牌的其他角色展示一张手牌:若为黑色,其本回合不能使用或打出手牌、非锁定技失效,且你对其使用红桃【杀】造成的伤害加一;若为红色,你可以获得此牌并可以令其回复一点体力。",
				re_paoxiao: "锁定技。你使用【杀】无次数限制;你的【杀】被【闪】抵消后,你获得一枚「咆」;你因【杀】造成伤害时,弃置所有「咆」并令此伤害加 X(X 为「咆」数),回合结束时弃置所有「咆」。",
				re_tishen: "限定技。准备阶段,你可以将体力回复至上限,然后摸等量的牌。",
				re_guanxing: "准备阶段,你可以观看牌堆顶的五张牌(存活角色小于四时改为三张),将其中任意张牌置于牌堆底、其余按原顺序置于牌堆顶;若全部置于牌堆底,结束阶段你可以再发动一次。",
				re_longdan: "你可以将一张【杀】当【闪】、【闪】当【杀】、【酒】当【桃】、【桃】当【酒】使用或打出。",
				re_yajiao: "当你于回合外使用或打出手牌后,你可以亮出牌堆顶的一张牌:若类别相同,你可以将之交给一名角色;若类别不同,你弃置之,然后可以弃置攻击范围内有你的一名角色区域里的一张牌。",
				re_tieji: "当你使用【杀】指定目标后,你可以令其非锁定技于本回合失效并判定:除非其交给你一张与判定牌花色相同的牌,否则其不能使用【闪】响应此【杀】且此【杀】伤害加一。",
				re_qicai: "锁定技。你使用锦囊牌无距离限制;其他角色不能弃置你装备区的防具。",
				re_zhiheng: "出牌阶段限一次,你可以弃置任意张手牌并摸等量的牌;若你以此法弃置了所有手牌,你多摸一张牌。",
				re_jiuyuan: "主公技。其他吴势力角色于其回合内回复体力时,若其体力值不小于你,其可以改为令你回复一点体力,然后其摸一张牌。",
				re_qixi: "你可以将一张黑色牌当【过河拆桥】使用。",
				re_qinxue: "觉醒技。准备阶段或结束阶段,若你的手牌数减体力值不小于二,你减一点体力上限,回复一点体力或摸两张牌,然后获得技能「攻心」。",
				re_jieyin: "出牌阶段限一次,你可以弃置一张手牌,或将装备区一张装备牌置入一名男性角色的装备区(对应槽位须为空),然后体力值较高的一方摸一张牌、较低的一方回复一点体力(相等则双方各摸一张牌)。",
				re_jijiu: "你的回合外,你可以将一张红色牌当【桃】使用。",
				re_liyu: "当你使用【杀】对其他角色造成伤害后,你可以获得其区域里的一张牌:若不为装备牌,其摸一张牌;若为装备牌,你视为对另一名角色使用一张【决斗】。",
				re_lijian: "出牌阶段限一次,你可以弃置一张牌并选择两名男性角色,视为前者对后者使用一张【决斗】(不可被【无懈可击】响应)。",
				re_biyue: "结束阶段,你可以摸一张牌;若你没有手牌,改为摸两张牌。",
				re_shensu: "你可以选择至多三项:跳过判定阶段与摸牌阶段;跳过出牌阶段并弃置一张装备牌;跳过弃牌阶段并将武将牌翻面。每选择一项,视为你对一名其他角色使用一张无距离限制的【杀】。",
				re_jushou: "结束阶段,你可以翻面并摸四张牌,然后弃置一张手牌;若以此法弃置的是装备牌,改为使用之。",
				re_jiewei: "你可以将装备区里的牌当【无懈可击】使用;当你的武将牌翻回正面时,你可以弃置一张牌,然后移动场上一张牌。",
				re_liegong: "你使用【杀】可以指定距离不超过此【杀】点数的角色为目标;你使用【杀】指定目标后,若其手牌数不大于你的手牌数,此【杀】不可被【闪】响应;若其体力值不小于你的体力值,此【杀】伤害加一。",
				re_kuanggu: "当你对距离一以内的一名角色造成一点伤害后,你可以回复一点体力或摸一张牌。",
				re_tianxiang: "当你受到伤害时,你可以弃置一张红桃牌并选择一名其他角色,然后选择一项:将此伤害转移给其,然后其摸 X 张牌(X 为其已损失的体力值);或令其失去一点体力并获得你弃置的牌。",
				re_hongyan: "锁定技。你的黑桃牌视为红桃牌;若你装备区有红桃牌,你的手牌上限视为体力上限。",
				re_leiji: "当你使用或打出【闪】时,你可以判定:黑桃,你可以对一名角色造成两点雷电伤害;梅花,你回复一点体力并可以对一名角色造成一点雷电伤害。",
				re_guidao: "当一名角色的判定牌生效前,你可以打出一张黑色手牌替换之并获得原判定牌;若你打出的牌为黑桃二至九,你摸一张牌。",
				re_huangtian: "主公技。其他群势力角色的出牌阶段限一次,其可以将一张【闪】或黑桃手牌交给你。",
				re_qiangxi: "出牌阶段限两次,你可以弃置一张武器牌或受到一点无来源伤害,然后对一名其他角色造成一点伤害。",
				re_jieming: "当你受到一点伤害后,你可以令一名角色摸 X 张牌,然后若其手牌数大于 X,其将手牌弃置至 X 张(X 为其体力上限且至多为五)。",
				re_lianhuan: "你可以将一张梅花牌当【铁索连环】使用或重铸。",
				re_niepan: "限定技。当你处于濒死状态时,你可以弃置你区域内的所有牌并将武将牌翻回正面,摸三张牌并将体力回复至三点,然后选择获得「八阵」「火计」「看破」之一。",
				re_huoji: "你可以将一张红色牌当【火攻】使用;你使用【火攻】时,目标随机展示一张手牌,你可以弃置一张与之颜色相同的手牌,对其造成一点火焰伤害。",
				re_kanpo: "你可以将一张黑色牌当【无懈可击】使用;你使用的【无懈可击】不可被响应。",
				re_luanji: "出牌阶段,你可以将两张花色相同的手牌当【万箭齐发】使用;你使用【万箭齐发】指定目标后,你可以减少一个目标。",
				re_xueyi: "主公技。锁定技。游戏开始时,你获得 X 枚「裔」(X 为群势力角色数的两倍);出牌阶段限一次,你可以移去一枚「裔」并摸一张牌;你的手牌上限加 Y(Y 为「裔」数)。",
				re_shuangxiong: "摸牌阶段,你可以改为弃置一张牌,然后本回合你可以将与弃置牌颜色不同的一张手牌当【决斗】使用;结束阶段,你获得弃牌堆中本回合对你造成过伤害的牌。",
				re_duanliang: "你可以将一张黑色基本牌或黑色装备牌当【兵粮寸断】使用;你使用【兵粮寸断】的距离限制为二。",
				re_xingshang: "当其他角色死亡时,你可以选择一项:获得其所有牌;或回复一点体力。",
				re_fangzhu: "当你受到伤害后,你可以令一名其他角色选择一项:摸 X 张牌并将武将牌翻面;或弃置 X 张牌并失去一点体力(X 为你已损失的体力值)。",
				re_zaiqi: "结束阶段,你可以令至多 X 名角色各选择一项:摸一张牌;或令你回复一点体力(X 为本回合进入过弃牌堆的红色牌数)。",
				re_jiuchi: "你可以将一张黑桃手牌当【酒】使用;你使用【酒】无次数限制;你于回合内使用带【酒】效果的【杀】造成伤害后,你的「崩坏」本回合失效。",
				re_baonue: "主公技。当其他群势力角色造成伤害后,你可以判定:若结果为黑桃,你回复一点体力并获得判定牌。",
				re_wansha: "锁定技。你的回合内,只有处于濒死状态的角色才能使用【桃】或【酒】;当有角色于你的回合内进入濒死状态时,其他角色的非锁定技失效直到此濒死结算结束。",
				re_luanwu: "限定技。出牌阶段,你可以令所有其他角色依次选择:对距离最近的一名角色使用一张【杀】,或失去一点体力;结算完成后,你可以视为使用一张无距离限制的【杀】。",
				re_weimu: "锁定技。你不能成为黑色锦囊牌的目标;当你于回合内受到伤害时,你防止此伤害并摸 X 张牌(X 为伤害值的两倍)。",
				re_qiaobian: "你可以弃置一张手牌并跳过你的一个阶段(判定/摸牌/出牌/弃牌,回合开始与结束阶段除外)。若你以此法跳过摸牌阶段,你可以获得至多两名其他角色各一张手牌;若你以此法跳过出牌阶段,你可以将场上的一张牌移动到另一名角色区域内的相应位置。",
				re_tuntian: "当你于回合外失去牌后,或于回合内因弃置而失去【杀】后,你可以判定:若结果不为红桃,将判定牌置于你的武将牌上,称为「田」。你计算与其他角色的距离减去「田」的数量。",
				re_zaoxian: "觉醒技。准备阶段,若「田」的数量不少于三张,你减一点体力上限,获得技能「急袭」,并于此回合结束后进行一个额外的回合。",
				re_tiaoxin: "出牌阶段限一次,你可以令攻击范围内有你的一名其他角色选择:对你使用一张【杀】,或令你弃置其一张牌;若其未以【杀】对你造成伤害,本阶段【挑衅】改为限两次。",
				re_zhiji: "觉醒技。准备阶段或结束阶段,若你没有手牌,你减一点体力上限,回复一点体力或摸两张牌,然后获得技能「观星」。",
				re_fangquan: "出牌阶段,你可以跳过此阶段;若如此做,弃牌阶段开始时,你可以弃置一张手牌,令一名其他角色获得一个额外的回合。",
				re_ruoyu: "主公技,觉醒技。准备阶段,若你的体力值为全场最少,你增加一点体力上限并将体力回复至三点,然后获得技能「思蜀」和「激将」。",
				re_jiang: "当你使用【决斗】或红色【杀】指定目标后,或成为【决斗】或红色【杀】的目标后,你可以摸一张牌;每回合首次有【决斗】或红色【杀】因弃置进入弃牌堆后,你可以失去一点体力并获得之。",
				re_hunzi: "觉醒技。准备阶段,若你的体力值为一点,你减一点体力上限,获得技能「英姿」和「英魂」;本回合结束阶段,你摸两张牌或回复一点体力。",
				re_zhiba: "主公技。其他吴势力角色的出牌阶段限一次,其可以与你拼点(你可以拒绝);你的出牌阶段限一次,你可以与一名吴势力角色拼点,若其没赢,你获得两张拼点牌。",
				re_zhijian: "出牌阶段,你可以将手牌中的一张装备牌置入一名其他角色的装备区(可替换原装备),然后摸一张牌。",
				re_guzheng: "每阶段限一次,当其他角色的至少两张牌因弃置进入弃牌堆后,你可以令其获得其中一张牌,然后你获得其余的牌。",
				re_beige: "当一名角色受到【杀】造成的伤害后,你可以令其判定,然后弃置一张牌:红桃,其回复一点体力;方块,其摸两张牌;黑桃,伤害来源翻面;梅花,伤害来源弃置两张牌。若你弃置的牌与判定牌点数相同,你获得弃置的牌;花色相同,你获得判定牌。"
			}
		},
		en: {
			name: "Legends of the Three Kingdoms",
			desc: "Hidden-role battle of Slash, Dodge and trick cards",
			rules: "Goal: Each role has a different victory condition.\n· The Lord and Loyalists must eliminate all Rebels and the Renegade.\n· The Rebels win by killing the Lord.\n· The Renegade must kill the Lord when no one else remains.\nSetup:\n· Deal identity cards by player count; only the Lord is revealed. The Lord picks 1 of 5 generals first; then all others choose simultaneously from 3 each.\n· Increase the Lord’s maximum HP by 1. Everyone draws 4 cards; the Lord acts first.\nPlay (each turn in order):\n· Judge phase: resolve delayed tricks in your judge area, last placed first.\n· Draw phase: draw 2 cards.\n· Play phase: play cards from hand. [Slash] is limited to once per turn and only within attack range; [Dodge] can only be played in response to [Slash].\n· Discard phase: discard down to your current HP.\nResolution:\n· An uncountered [Slash] deals 1 damage; at 0 HP a player is dying and everyone may play [Peach] to save them in turn.\n· Killing a Rebel draws you 3 cards; if the Lord kills a Loyalist, the Lord discards all hand and equipped cards.\n· Equipment grants attack range or protection; [Indulgence] skips the target's play phase, [Lightning] deals 3 damage on a spade 2-9 judgment.",
			identityLord: "Lord",
			identityLoyalist: "Loyalist",
			identityRebel: "Rebel",
			identityRenegade: "Renegade",
			overFinal: "Final",
			overLordWin: "Lord & Loyalists win",
			overRebelWin: "Rebels win",
			overRenegadeWin: "Renegade wins",
			overWinners: "Winners",
			overLosers: "Defeated",
			overPlayerCount: "{{n}} players",
			overIdentity: "Role",
			overFaction: "Faction",
			overLeave: "Leave game",
			phaseJudge: "Judge phase",
			phaseDraw: "Draw phase",
			phasePlay: "Play phase",
			phaseDiscard: "Discard phase",
			phaseEnd: "End phase",
			selectGeneralTitle: "Choose your general",
			selectGeneralWaiting: "Waiting for others to pick generals…",
			lordPickFirst: "You are the Lord — pick 1 of 5",
			selectLordCenter: "Lord picks",
			selectOtherCenter: "Pick a general",
			selectWaitLordCenter: "Waiting for Lord",
			selectWaitOthersCenter: "Waiting for players",
			selectFiveOne: "1 of 5",
			selectThreeOne: "1 of 3",
			selectPending: "Waiting",
			selectChoosing: "Picking",
			selectSelf: "Me",
			selectSeatAria: "Seat {{n}}, {{name}}",
			seatNumber: "Seat {{n}}",
			selectCandidates: "Generals",
			selectGeneralBack: "G",
			selectCandidateAria: "View {{name}}",
			revealCenter: "Reveal",
			revealSub: "Battle begins…",
			selectHpLord: "HP {{n}}+1",
			selectHp: "HP {{n}}",
			selectLordSkill: "Lord skill",
			allGenerals: "All generals",
			allGeneralsTitle: "General roster",
			allGeneralsCount: "{{n}} generals",
			rosterColGeneral: "General",
			rosterColSkills: "Skills",
			rosterFilterFaction: "Faction",
			rosterFilterPack: "Pack",
			rosterFilterAll: "All",
			rosterFilterEmpty: "No generals match the filters",
			genderFemale: "Female",
			packStandard: "Base",
			packWind: "Wind",
			packFire: "Fire",
			packForest: "Forest",
			packMountain: "Mountain",
			packYj2011: "Yijiang 2011",
			packYj2012: "Yijiang 2012",
			packYj2013: "Yijiang 2013",
			packYj2014: "Yijiang 2014",
			packYj2015: "Yijiang 2015",
			packYj2016: "Original Design 2016",
			packYj2017: "Original Design 2017",
			factionWei: "Wei",
			factionShu: "Shu",
			factionWu: "Wu",
			factionQun: "Qun",
			yourTurn: "Your turn",
			playPrompt: "Play phase: tap a card to use it, or end",
			endPlay: "End play",
			waitingTurn: "Waiting for {{name}}…",
			myIdentity: "You are: {{name}}",
			deckCount: "Deck {{n}}",
			cardBack: "Card back",
			discardCount: "Discard {{n}}",
			round: "Round {{n}}",
			respondJink: "Play a [Dodge]",
			respondJinkFrom: "{{name}} used 0 — play a [Dodge]",
			respondSlash: "Play a [Slash]",
			respondSlashAoe: "{{name}} used 0 — play a [Slash]",
			respondSlashDuel: "{{name}} duels you with 0 — play a [Slash]",
			respondSlashCollateral: "{{name}} used 0: play a [Slash] on {{target}}",
			respondPeach: "Play a [Peach] to save",
			respondPeachFrom: "{{name}} is dying — play a [Peach] to save",
			respondNullification: "Play [Nullification]",
			nullifyAsk: "Play Nullification on {{name}}'s [{{card}}]?",
			nullifyAskTarget: "Play Nullification on [{{card}}] used by {{name}} on {{target}}?",
			noNullify: "Don't play",
			passRespond: "Pass",
			useEightDiagram: "Use Eight Diagram judgment",
			amazingPick: "Pick one of the revealed cards",
			amazingChip: "Choosing",
			amazingLabel: "Harvest · {{n}} revealed",
			pickZone: "Pick an area of the target",
			zoneHand: "Hand (random)",
			zoneWeapon: "Weapon",
			zoneArmor: "Armor",
			zoneOffHorse: "Offensive horse",
			zoneDefHorse: "Defensive horse",
			zoneJudge: "Judge area #{{n}}",
			zoneTagEquip: "Equip",
			zoneTagJudge: "Judge",
			zoneTagTian: "Field",
			zoneTagShown: "Shown",
			collateralPick: "Pick the victim of the borrowed blade",
			discardPrompt: "Discard {{n}} cards",
			confirm: "Confirm",
			cancelSelection: "Cancel",
			waitingJink: "Waiting for {{name}} to dodge…",
			waitingSlash: "Waiting for {{name}} to slash…",
			waitingPeach: "{{name}} is dying — waiting for rescue…",
			waitingNullification: "Waiting for nullification…",
			waitingDiscard: "Waiting for {{name}} to discard…",
			waitingPick: "Waiting for {{name}} to pick…",
			handCount: "Hand {{n}}",
			myHand: "Your hand",
			swipeHand: "Swipe to see more →",
			viewAllLog: "View all records",
			viewAllShort: "All ›",
			close: "Close",
			deadMark: "Dead",
			skillTodo: "Skills arrive in a later version",
			guessTitle: "Guess identity",
			guessUnknown: "?",
			guessMarkLoyalist: "L",
			guessMarkRebel: "R",
			guessMarkRenegade: "I",
			judgeIconIndulgence: "乐",
			judgeIconSupply: "兵",
			judgeIconLightning: "闪",
			waitingSkill: "Waiting for {{name}} to resolve a skill…",
			skillUse: "Activate",
			skillDecline: "Decline",
			skillPickCards: "Pick {{n}} card(s)",
			skillPickCardsUpTo: "Pick up to {{n}} card(s)",
			skillPickSeats: "Pick {{n}} player(s)",
			skillPickSeatsUpTo: "Pick up to {{n}} player(s)",
			lordCallJink: "The Lord invokes 0 — you may play a [Dodge]",
			lordCallSlash: "The Lord invokes 0 — you may play a [Slash]",
			guicaiPrompt: "Play a hand card to replace the judgment card",
			optionObtain: "Take the card that hurt you",
			optionXsObtain: "Take all of their cards",
			optionDraw: "Draw a card",
			optionShowDiscard: "Reveal hand and discard matching suit",
			optionLoseHp: "Lose 1 HP",
			optionLoseMaxHp: "Lose 1 max HP",
			optionDrawOne: "They draw 1 card, discard {{n}} cards",
			optionDrawX: "They draw {{n}} cards, discard 1 card",
			convertTag: "as {{card}}",
			recastTag: "Recast",
			chainedMark: "Chained",
			turnedOverMark: "Flipped",
			chuangMark: "Wound {{n}}",
			tianMark: "Field {{n}}",
			markPao: "Roar {{n}}",
			markYi: "Kin {{n}}",
			markBian: "Shift {{n}}",
			markLie: "Valor {{n}}",
			markZi: "Supply {{n}}",
			markSishu: "Shu-bound",
			moshiMark: "Arrows {{n}}",
			jieTag: "RE",
			optionRecover: "Recover 1 HP",
			optionDrawTwo: "Draw 2 cards",
			optionGlDiscard: "Discard 2 hand cards",
			optionGlDamage: "Take 1 damage",
			optionDsDiscard: "Discard 1 hand card",
			optionDsDraw: "Let them draw a card",
			optionTransfer: "Redirect the damage to them; they draw cards",
			optionLoseHpTake: "They lose 1 HP and take your discarded card",
			optionDrawFlip: "They draw {{n}} cards and flip over",
			optionDropLose: "They discard {{n}} cards and lose 1 HP",
			optionGiveRole: "Give the judgment card to a player",
			optionTopDeck: "Put the judgment card on the deck top",
			optionSelfRecover: "You recover 1 HP",
			optionLordRecover: "The Lord recovers 1 HP instead; you draw a card",
			optionHealOther: "Let them recover 1 HP",
			optionZjDiscard: "Discard the same number of cards",
			optionZjDraw: "Let them draw the same number of cards",
			optionEyGive: "Give them a hand card",
			optionEyLosehp: "Lose 1 HP",
			optionMcSlash: "Use a virtual [Slash] on the chosen player",
			optionMcDraw: "Draw a card",
			optionJjDraw: "Draw 2 cards",
			optionJjRecover: "Recover 1 HP",
			optionJjReset: "Flip face-up and reset (unchain)",
			markPojun: "Po {{n}}",
			markQuan: "Quan {{n}}",
			markChun: "Chun {{n}}",
			optionJcMore: "Draw 1 extra card; cannot use [Slash] this turn",
			optionJcLess: "Draw 1 fewer card; [Slash] ignores distance, +1 quota",
			optionJfDiscard: "Discard a weapon",
			optionJfDraw: "Let them draw a card",
			optionQyGive: "Give them a [Jink]",
			optionQyTarget: "Become an extra target of this [Slash]",
			optionYcDiscard: "Discard a hand card of a different class",
			optionYcRecover: "Let them recover 1 HP",
			optionJxDiscard: "Discard a hand card of a different class",
			optionJxFlip: "Flip over and draw {{n}} cards",
			optionMjTrick: "Give them a trick card",
			optionMjDrop2: "Discard 2 non-trick cards",
			optionFcDiscard: "Discard at least {{n}} cards",
			optionFcDamage: "Take 2 fire damage",
			optionPdDraw: "They draw {{n}} cards",
			optionPdDiscard: "They discard {{n}} cards",
			optionBxBoth: "Ignore armor and cannot be responded to",
			optionBxPierce: "Ignore armor",
			optionBxNullify: "Cannot be responded to",
			optionChGive: "Give them a card and become the user of this [Slash]",
			optionChTarget: "Become an extra target of this [Slash]",
			optionQtMove: "Move one of their equip cards to your zone",
			optionQtDraw: "Draw a card",
			optionXzHeal: "Recover {{n}} HP",
			optionXzDamage: "Deal 1 damage each to up to {{n}} characters in your attack range",
			optionQxDiscard: "Discard {{n}} hand cards and discard their weapon",
			optionQxPlus: "Increase this damage by 1",
			optionYzGive: "Give them all your equipped cards; they lose [Feast Doom]",
			optionYzDiscard: "Discard a card",
			optionHyRed: "Discard all red hand cards",
			optionHyBlack: "Discard all black hand cards",
			optionDxDraw: "Draw a card",
			optionDxModify: "Gain a Danxin mark to modify [Imperial Edict]",
			optionHsTake: "Take one shown card and prevent this damage",
			optionHsDiscard: "Discard an equal number of cards",
			optionDlView: "They view the top 2 deck cards and gain the basic ones",
			optionDlNext: "They draw an extra card next draw phase",
			optionGzDraw: "Draw a card",
			optionGzRecover: "Recover 1 HP",
			optionZgSlash: "Use a virtual [Slash]",
			optionZgGive: "Give them an equip card",
			optionCsLess: "Draw 1 less; [Loyal Insight] may show up to 2 of your cards",
			optionCsLimit: "Hand limit -1; [Loyal Insight] shows 1 more of their cards",
			optionCsMore: "Draw 2 more; no [Loyal Insight] this turn",
			optionFmDraw: "Draw 1 more in draw phase",
			optionFmRed: "Red [Slash] may target 1 more player",
			optionTbHand: "Pindian with a hand card",
			optionTbTop: "Pindian with the deck top card (Heavenly Debate)",
			optionWgTop: "Put on deck top",
			optionWgBottom: "Put on deck bottom",
			markNi: "Ni {{n}}",
			serpentSlash: "Serpent Spear: use 2 hand cards as [Slash]",
			optPacks: "Expansion generals",
			optWind: "Wind Pack",
			optWindHint: "8 generals incl. Xiahou Yuan, Huang Zhong, Xiao Qiao, Zhang Jiao",
			optFire: "Fire Pack",
			optFireHint: "8 generals incl. Dian Wei, Xun Yu, Pang Tong, Yuan Shao",
			optForest: "Forest Pack",
			optForestHint: "8 generals incl. Cao Pi, Meng Huo, Dong Zhuo, Jia Xu",
			optMountain: "Mountain Pack",
			optMountainHint: "8 generals incl. Deng Ai, Jiang Wei, Sun Ce, Cai Wenji",
			optYj2011: "Yijiang 2011",
			optYj2011Hint: "11 generals incl. Cao Zhi, Zhang Chunhua, Xu Sheng, Chen Gong",
			optYj2012: "Yijiang 2012",
			optYj2012Hint: "11 generals incl. Wang Yi, Zhong Hui, Bu Lianshi, Liu Biao",
			optYj2013: "Yijiang 2013",
			optYj2013Hint: "11 generals incl. Cao Chong, Man Chong, Zhu Ran, Empress Fu",
			optYj2014: "Yijiang 2014",
			optYj2014Hint: "11 generals incl. Zhang Song, Cao Zhen, Sun Luban, Ju Shou",
			optYj2015: "Yijiang 2015",
			optYj2015Hint: "11 generals incl. Cao Rui, Xiahou Shi, Liu Chen, Sun Xiu",
			optYj2016: "Original Design 2016",
			optYj2016Hint: "8 generals incl. Empress Guo, Huang Hao, Zhang Rang, Liu Yu",
			optYj2017: "Original Design 2017",
			optYj2017Hint: "8 generals incl. Xin Xianying, Ji Kang, Qin Mi, Cai Yong",
			optJie: "Breakthrough (RE)",
			optJieHint: "Generals with RE versions are replaced by their breakthrough counterparts",
			optDeck: "Deck",
			optJunzheng: "Maneuvering",
			optJunzhengHint: "Adds 52 cards: elemental slashes, Analeptic, Iron Chain and more",
			optIdentity: "Identity",
			idRandom: "Random",
			winLord: "Lord & Loyalists win",
			winRebel: "Rebels win",
			winRenegade: "Renegade wins",
			log: {
				setup: "Game starts — identities and generals dealt",
				turn: "—— {{name}}'s turn ——",
				pick: "{{name}} picked a general",
				deal: "Everyone draws four starting cards",
				draw: "{{name}} draws {{n}} card(s)",
				equip: "{{name}} equips {{card}}",
				use: "{{name}} uses {{card}} on {{target}}",
				useNoTarget: "{{name}} uses {{card}}",
				useConverted: "{{name}} uses {{card}} on {{target}} (from {{cards}})",
				useConvertedNoTarget: "{{name}} uses {{card}} (from {{cards}})",
				slash: "{{name}} slashes {{target}}",
				jink: "{{name}} plays a Dodge",
				jinkConverted: "{{name}} plays {{card}} (from {{cards}})",
				judge: "{{name}}'s {{card}} judgment begins",
				judgeReveal: "{{name}}'s {{card}} judgment reveals {{cards}}",
				judgeResult: "{{name}}'s {{card}} judgment: {{cards}}",
				judgeResultHit: "{{name}}'s {{card}} judgment hits: {{cards}}",
				judgeResultMiss: "{{name}}'s {{card}} judgment misses: {{cards}}",
				lightningMove: "Lightning moves to {{name}}'s judge area",
				damage: "{{name}} takes {{n}} damage",
				recover: "{{name}} recovers 1 HP",
				death: "{{name}} is dead",
				reward: "{{name}} killed a Rebel and draws three cards",
				punish: "{{name}} killed a Loyalist and discards everything",
				nullify: "{{name}} plays Nullification",
				nullified: "{{card}} is nullified",
				armorNull: "{{name}}'s {{card}} blocks the Slash",
				axeHit: "{{name}} discards 2 cards; the Slash still hits {{target}}",
				duel: "{{name}} duels {{target}}",
				respondSlash: "{{name}} plays a Slash",
				respondSlashConverted: "{{name}} plays {{card}} (from {{cards}})",
				amazing: "{{name}} uses Amazing Grace",
				amazingTake: "{{name}} takes a card",
				snatch: "{{name}} snatches from {{target}}",
				dismantle: "{{name}} dismantles {{target}}",
				collateralTake: "{{name}} takes the borrowed weapon",
				placeJudge: "{{card}} is placed in {{name}}'s judge area",
				godSalvation: "{{name}} recovers 1 HP from God Salvation",
				peach: "{{name}} uses a Peach",
				peachSave: "{{name}} saves {{target}} with a Peach",
				discard: "{{name}} discards {{n}} card(s)",
				loseHp: "{{name}} loses {{n}} HP",
				skill: "{{name}} activates {{card}}",
				detailSkill: "{{name}} activates {{card}}: {{cards}}",
				skillDraw: "{{name}} draws {{n}} card(s) from a skill",
				awaken: "{{name}} awakens",
				tiandu: "{{name}}'s Jealous Heaven takes the judgment card",
				luoshen: "{{name}} takes the black judgment card (Goddess Luo)",
				luoyi: "{{name}} gains {{n}} card(s) from Berserk",
				qianxun: "{{name}} sets {{n}} hand card(s) aside (Humility)",
				qianxunBack: "{{name}} takes back the set-aside cards",
				yajiaoGain: "{{name}} keeps the revealed card (Last Stand)",
				yajiaoDrop: "{{name}}'s revealed card is discarded (Last Stand)",
				jizhiGain: "{{name}} keeps the revealed card (Quick Wit)",
				jizhiDrop: "{{name}}'s revealed basic card is discarded (Quick Wit)",
				rende: "{{name}} gives {{n}} card(s) to {{target}}",
				zhiheng: "{{name}} rebalances {{n}} card(s)",
				chuli: "{{name}} purges {{n}} player(s)",
				jieyin: "{{name}} performs Matrimony with {{target}}",
				guoseBreak: "{{name}} removes {{target}}'s Indulgence",
				guosePlay: "{{name}} plays a diamond as Indulgence on {{target}}",
				gongxin: "{{name}} reads {{target}}'s hand",
				gongxinDrop: "{{name}} discards a heart from {{target}}",
				liyuTake: "{{name}} takes a card from {{target}}",
				yijue: "{{name}} duels points with {{target}}",
				yijueSeal: "{{name}} wins Honor Bound — {{target}} is sealed",
				yijiGain: "{{name}} gives {{n}} Legacy card(s) to {{target}}",
				yijiGive: "{{name}} gives a Legacy card to {{target}}",
				kylin: "{{name}} discards one of {{target}}'s horses (Kylin Bow)",
				ganglieDrop: "{{name}} discards 2 hand cards to avoid Unyielding damage",
				qingjian: "{{name}} gives {{n}} card(s) to {{target}} (Frugality)",
				liuli: "{{name}} diverts the Slash to {{target}}",
				tuxi: "{{name}} raids {{n}} card(s)",
				lianying: "{{name}} lets {{n}} player(s) each draw a card (Linked Camps)",
				lordCall: "{{name}} plays a card for {{target}}",
				guicai: "{{name}} replaces the judgment card",
				fanjianDrop: "{{name}} discards {{n}} same-suit hand card(s)",
				analeptic: "{{name}} drinks an Analeptic",
				recast: "{{name}} recasts {{card}}",
				chain: "{{name}} is chained",
				unchain: "{{name}} is unchained",
				fireAttack: "{{name}} fire-attacks {{target}}",
				fireAttackShow: "{{name}} reveals a hand card",
				silverLion: "{{name}}'s Silver Lion heals 1 HP",
				turnOver: "{{name}} flips their general card face-down",
				turnBack: "{{name}} flips their general card face-up",
				buquNoWounds: "none",
				buquExisting: "{{name}}'s existing Wounds: {{cards}}",
				buquReveal: "Undying reveals: {{cards}}",
				buquSuccessResult: "Undying succeeds: the revealed card becomes a Wound; HP returns to 1",
				buquFailResult: "Undying fails: its rank matches a Wound; Peach rescue follows",
				buqu: "{{name}}'s Undying triggers: gains a Wound and returns to 1 HP",
				buquFail: "{{name}}'s Undying fails: revealed card matches a Wound's rank",
				buquClear: "{{name}} healed up; all Wounds removed",
				tianxiang: "{{name}} redirects the damage to {{target}} (Heavenly Scent)",
				tianxiangDraw: "{{name}} draws {{n}} card(s) from Heavenly Scent",
				guidao: "{{name}} plays a black card to replace the judgement and keeps the original",
				huangtian: "{{name}} gives a card to the lord {{target}}",
				jieweiDrop: "{{name}} discards an on-board card of the same kind (Break Siege)",
				qiangxi: "{{name}} uses Power Strike on {{target}}",
				quhu: "{{name}} duels points with {{target}}",
				quhuNowolf: "{{name}} wins the Drive Tiger duel, but no one in the victim’s range can be damaged",
				tianyi: "{{name}} duels points with {{target}}",
				tianyiWin: "{{name}} wins Heavenly Justice: Slash limit +1, no distance limit, one extra target this turn",
				tianyiLose: "{{name}} loses Heavenly Justice and cannot use Slash this turn",
				tianyiExtra: "{{name}} names {{target}} as an extra Slash target",
				shuangxiongRed: "{{name}} uses Dual Heroes: red judgment, black hand cards count as Duel this turn",
				shuangxiongBlack: "{{name}} uses Dual Heroes: black judgment, red hand cards count as Duel this turn",
				niepan: "{{name}} uses Nirvana: discards all cards in their area, draws 3 and heals to 3",
				jieming: "{{name}} has {{target}} draw up to their max HP ({{n}} cards)",
				luanji: "{{name}} uses Random Fire: two same-suit hand cards as [Archery Attack]",
				xingshang: "{{name}} uses Mourning: takes all {{n}} cards of {{target}}",
				fangzhu: "{{name}} exiles {{target}}: draws {{n}} cards and flips over",
				songwei: "{{target}} invokes Majesty: {{name}} draws a card",
				zaiqi: "{{name}} uses Rise Again: reveals deck-top cards, discards {{n}} hearts and heals that much",
				lieren: "{{name}} duels points with {{target}}",
				lierenTake: "{{name}} wins Fierce Blade and takes a card from {{target}}",
				haoshi: "{{name}} uses Generosity: gives {{n}} hand cards to {{target}}",
				dimeng: "{{name}} uses Alliance: discards {{n}} cards and swaps the hands of {{target}} and another player",
				baonue: "Tyranny judgment is a spade: {{name}} recovers 1 HP",
				benghuaiMax: "{{name}} suffers Collapse: loses 1 max HP",
				juxiang: "{{name}} takes the Savage Assault via Giant Elephant",
				yinghun: "{{name}} uses Heroic Soul on {{target}} ({{n}} HP lost)",
				tuntian: "{{name}} uses Field Cultivation; the judgement card is placed on the general as a Field",
				qiaobian: "{{name}} uses Ingenuity, discarding a hand card to skip a phase",
				qiaobianDraw: "{{name}} uses Ingenuity, taking one hand card from each of {{n}} players",
				qiaobianMove: "{{name}} uses Ingenuity, moving a field card to {{target}}",
				zhijian: "{{name}} uses Frank Counsel, placing an equipment into {{target}}'s area and drawing a card",
				guzheng: "{{name}} uses Firm Administration, taking {{n}} cards from the discard pile",
				guzhengBack: "{{name}} uses Firm Administration, letting {{target}} take back a card",
				beige: "{{name}} uses Lament, discarding a card to let {{target}} judge",
				duanchang: "{{target}} is Heartbroken and loses all skills (the price of killing {{name}})",
				fangquan: "{{name}} uses Delegation; {{target}} gets an extra turn",
				xiangle: "{{name}} discards a basic card for Indulgence",
				xiangleNull: "{{name}}'s Indulgence nullifies the Slash",
				zhibaObtain: "{{name}} uses Hegemony, taking the two pindian cards ({{n}})",
				zhiba: "{{name}} pindians with {{target}} (Hegemony)",
				detailAmazing: "{{name}} reveals for Amazing Grace: {{cards}}",
				detailAmazingTake: "{{name}} takes from Amazing Grace: {{cards}}",
				detailSnatch: "{{name}} snatches {{cards}} from {{target}}",
				detailDismantle: "{{name}} dismantles {{target}}: {{cards}}",
				detailCollateralTake: "{{name}} takes the borrowed weapon: {{cards}}",
				detailDiscard: "{{name}} discards: {{cards}}",
				detailYajiaoGain: "{{name}} gains with Last Stand: {{cards}}",
				detailYajiaoDrop: "{{name}} discards with Last Stand: {{cards}}",
				detailJizhiGain: "{{name}} gains with Quick Wit: {{cards}}",
				detailJizhiDrop: "{{name}} discards with Quick Wit: {{cards}}",
				detailGongxinDrop: "{{name}} discards {{target}}'s {{cards}} with Heart Probe",
				detailFireAttackShow: "{{name}} reveals for Fire Attack: {{cards}}",
				detailGuicai: "{{name}} replaces the judgment with {{cards}}",
				detailGuidao: "{{name}} replaces the judgment with {{cards}}",
				detailJieweiDrop: "{{name}} discards with Break Siege: {{cards}}",
				detailQiaobianMove: "{{name}} moves {{cards}} to {{target}} with Ingenuity",
				detailGuzheng: "{{name}} takes from the discard pile: {{cards}}",
				detailGuzhengBack: "{{name}} lets {{target}} take back {{cards}}",
				detailAxeHit: "{{name}} discards {{cards}}; the Slash still hits {{target}}",
				detailFireAttack: "{{name}} discards {{cards}}; Fire Attack hits {{target}} for fire damage",
				detailGanglieDrop: "{{name}} discards {{cards}} to avoid Unyielding damage",
				detailFanjianDrop: "{{name}} discards same-suit hand cards: {{cards}}",
				detailXuanfeng: "{{name}} uses Whirlwind: discards {{cards}} of {{target}}",
				detailRezhenjun: "{{name}} uses Suppress Army: discards {{cards}} of {{target}}",
				detailZhenlie: "{{name}} uses Chaste Valor: loses 1 HP and discards {{cards}} from the source",
				detailQingxiDiscard: "{{name}} discards for Raid: {{cards}}",
				detailHuaiyiDrop: "{{name}} uses Hidden Grudge: discards same-color hand cards: {{cards}}",
				detailYaomingDrop: "{{name}} uses Claim Fame: discards {{cards}} of {{target}}",
				detailJunxingDiscard: "{{name}} discards {{cards}} (all of different classes)",
				detailYuceDiscard: "{{name}} discards {{cards}} (different class)",
				detailMiejiDiscard: "{{name}} discards for Plot: {{cards}}",
				detailFenchengDiscard: "{{name}} discards for Burn the City: {{cards}}",
				detailPindiDiscard: "{{name}} discards for Rank: {{cards}}",
				detailShifeiDiscard: "{{name}} uses Cover Up: discards {{cards}} of {{target}}",
				jiangObtain: "{{name}} loses 1 HP and takes {{cards}}",
				moshi: "{{name}} takes back the {{n}} Stray Arrow card(s) from {{target}}",
				jiezi: "{{name}} uses Intercept Supplies: {{target}} gets an extra draw phase",
				jieziMark: "{{name}} uses Intercept Supplies: {{target}} gains a Supply mark",
				hanzhan: "{{name}} takes {{cards}} with Fierce Contest",
				qingnang: "{{name}} uses Green Pouch: {{target}} recovers 1 HP",
				sishu: "{{name}} uses Longing for Shu: {{target}}'s [Indulgence] judgments are reversed",
				wulie: "{{name}} uses Fierce Valor: {{n}} player(s) each gain a Valor mark",
				piaolingTop: "{{name}} uses Drifting: the judgment card goes to the deck top",
				piaolingGive: "{{name}} uses Drifting: gives {{cards}} to {{target}}",
				luoying: "{{name}} uses Falling Petals: takes {{n}} club card(s)",
				pojun: "{{name}} uses Army Breaker: sets {{n}} card(s) aside next to {{target}}",
				pojunBack: "{{name}} takes back {{n}} card(s) set aside by Army Breaker",
				buyi: "{{name}} uses Aid: reveals a hand card of {{target}}: {{cards}}",
				ganlu: "{{name}} uses Sweet Dew: swaps two players' equipment ({{n}} cards total)",
				mingce: "{{name}} uses Bright Plan: gives a card to {{target}}",
				xuanhuoTake: "{{name}} uses Dazzle: takes {{n}} card(s) from {{target}}",
				xianzhenWin: "{{name}} wins Breaking Formation: no distance limit and ignores {{target}}'s armor this turn",
				xianzhenLose: "{{name}} loses Breaking Formation: cannot use [Slash] this turn",
				enyuanGive: "{{name}} gives a hand card to {{target}} (Grudge)",
				rezhenjun: "{{name}} uses Suppress Army: discards {{n}} card(s) of {{target}}",
				xuanfeng: "{{name}} uses Whirlwind: discards {{n}} card(s) of {{target}}",
				zhenlie: "{{name}} uses Chaste Valor: loses 1 HP and discards a card of the source",
				fuli: "{{name}} uses Dormant Dragon: recovers to {{n}} HP and flips over",
				"zhiyu-show": "{{name}} uses Feigned Folly: draws a card and reveals {{n}} hand card(s)",
				jiefan: "{{name}} uses Lift the Siege on {{target}}",
				"chunlao-put": "{{name}} uses Strong Brew: sets {{n}} [Slash] aside as \"Brew\"",
				"quanji-put": "{{name}} uses Power Scheme: sets {{cards}} aside as \"Power\"",
				qianxi: "{{name}} uses Ambush: {{target}} cannot use or play hand cards of that color this turn",
				"miji-give": "{{name}} uses Secret Plan: gives {{n}} card(s) to {{target}}",
				anxu: "{{name}} uses Consolation: {{target}} obtains {{cards}}",
				zhuiyi: "{{name}} uses Remembrance: {{target}} draws 3 cards and recovers 1 HP",
				chengxiang: "{{name}} uses Weighing: reveals the top {{n}} cards of the deck",
				renxin: "{{name}} uses Kindness: discards an equip card and flips over to prevent the damage",
				"qiuyuan-give": "{{name}} gives a [Jink] to {{target}}",
				"qiuyuan-become": "{{name}} becomes an extra target of this [Slash]",
				"zhuikong-win": "{{name}} wins the Frighten duel: {{target}} cannot target others this turn",
				"zhuikong-lose": "{{name}} loses the Frighten duel: distance to {{target}} counts as 1 this turn",
				"qiaoshui-win": "{{name}} wins the Persuasion duel: the next [Slash] this turn may target +1",
				"qiaoshui-lose": "{{name}} loses the Persuasion duel: no trick cards this turn",
				jyzongshi: "{{name}} uses Indulgence: takes the duel card {{cards}}",
				xiansi: "{{name}} uses Framing: puts a card of {{target}} as Ni ({{n}} total)",
				xiansi2: "{{name}} removes 2 Ni, using [Slash] on {{target}}",
				zhiyan: "{{name}} uses Frankness: {{target}} draws and reveals {{cards}}",
				danshou: "{{name}} uses Bold Defense: discards {{n}} cards targeting {{target}}",
				"danshou-give": "{{name}} gives {{cards}} to {{target}}",
				junxing: "{{name}} uses Harsh Punishment: discards {{n}} cards targeting {{target}}",
				"junxing-flip": "{{name}} flips over",
				"junxing-discard": "{{name}} discards a hand card of a different class",
				"yuce-show": "{{name}} uses Countermeasure: shows {{cards}}",
				"yuce-discard": "{{name}} discards a card of a different class",
				duodao: "{{name}} uses Seize Blade: takes {{target}}'s weapon {{cards}}",
				longyin: "{{name}} uses Dragon Chant: {{target}}'s [Slash] does not count",
				zongxuan: "{{name}} uses Unfettered: puts {{n}} cards on the deck top",
				xinjuece: "{{name}} uses Final Plan: deals 1 damage to {{target}}",
				xinmieji: "{{name}} uses Plot: puts {{cards}} on the deck top targeting {{target}}",
				xinfencheng: "{{name}} uses Burn the City: all others discard or take fire damage",
				"fencheng-discard": "{{name}} discards {{n}} cards for Burn the City",
				"mieji-discard": "{{name}} discards {{n}} card(s) for Plot",
				shenduan: "{{name}} uses Prudent Judgment: uses {{cards}} as [Supply Shortage] on {{target}}",
				yonglve: "{{name}} uses Valor: discards {{cards}} from {{target}}'s judgment zone",
				"yonglve-draw": "{{name}} draws a card from Valor",
				pindi: "{{name}} uses Rank: discards {{cards}} and targets {{target}}",
				"pindi-discard": "{{name}} discards {{n}} cards for Rank",
				xinsidi: "{{name}} uses Scout Enemy: discards {{cards}} and marks {{target}}",
				"sidi-slash": "{{name}} uses Scout Enemy: uses a virtual [Slash] on {{target}}",
				qiangzhi: "{{name}} uses Insight: reveals {{target}}'s hand card {{cards}}",
				"qiangzhi-draw": "{{name}} draws a card from Insight",
				xiantu: "{{name}} uses Present Map: gives {{n}} cards to {{target}}",
				"xiantu-hurt": "{{name}} loses 1 HP from Present Map (target killed no one)",
				olbenxi: "{{name}} uses Rush: this card ignores armor and cannot be responded to",
				xinzhongyong: "{{name}} uses Loyal Valor: gives {{cards}} to {{target}}",
				"zy-slash": "{{name}} uses a [Slash] on {{target}} from Loyal Valor",
				chanhui: "{{name}} uses Slander: makes {{target}} give a card or become an extra target",
				"chanhui-extra": "{{name}} becomes an extra target of the [Slash] (Slander)",
				"chanhui-give": "{{name}} gives a card to {{target}} (Slander)",
				jiaojin: "{{name}} uses Pride: discards {{cards}} to reduce the damage by 1",
				fenli: "{{name}} uses Zeal: skips a phase",
				pingkou: "{{name}} uses Pacify: deals 1 damage to {{n}} characters",
				shenxing: "{{name}} uses Prudence: discards {{cards}} and draws a card",
				olbingyi: "{{name}} uses Unity: reveals hand {{cards}}",
				jianying: "{{name}} draws a card from Growing Camp",
				"shibei-recover": "{{name}} recovers 1 HP from Stubborn North",
				"shibei-lose": "{{name}} loses 1 HP from Stubborn North",
				"qieting-move": "{{name}} uses Eavesdrop: moves {{target}}'s equip {{cards}} to own zone",
				xianzhou: "{{name}} uses Offer Province: {{target}} recovers {{n}} HP",
				"xianzhou-give": "{{name}} gives {{n}} equip cards to {{target}} (Offer Province)",
				"xianzhou-damage": "{{name}} deals 1 damage to {{n}} characters (Offer Province)",
				"qingxi-plus": "{{name}}'s Raid: {{target}} increases this damage by 1",
				"qingxi-discard": "{{name}}'s Raid: {{target}} discards {{n}} hand cards and discards the weapon",
				"yanzhu-give": "{{name}} gives all equipped cards to {{target}}; {{target}} loses [Feast Doom]",
				"yanzhu-discard": "{{name}} discards a card (Feast Doom)",
				"huaiyi-show": "{{name}} reveals all hand cards (Hidden Grudge)",
				"huaiyi-drop": "{{name}} discards {{n}} hand cards of one color (Hidden Grudge)",
				"huaiyi-gain": "{{name}} takes a card from each of {{n}} characters (Hidden Grudge)",
				"wurong-show": "{{name}} and {{target}} reveal hand cards: {{cards}}",
				"wurong-gain": "{{name}} takes a card from {{target}} (Soothing Blade)",
				"xx-put": "{{name}} puts a card on top of the deck (Promote Learning)",
				mingjian: "{{name}} gives all hand cards to {{target}} (Clear Mirror)",
				zhanjue: "{{name}} uses all hand cards as [Duel] on {{target}} (Desperate Duel)",
				xinzhaofu: "{{name}}'s Edict Bind: {{target}} counts as in range of all other Wu characters",
				"yaoming-drop": "{{name}}'s Claim Fame: randomly discards a hand card from {{target}}",
				"shifei-discard": "{{name}} uses Cover Up: discards a card of {{target}}",
				"zhongjian-show": "{{name}} shows {{cards}}",
				jianzheng: "{{name}}'s Admonition: cancels the [Slash] and puts a hand card on deck top",
				zhuandui: "{{name}} pindians with {{target}}",
				funan: "{{name}}'s Repeated Challenge: swaps the response cards with {{target}}",
				fuzhu: "{{name}} unleashes Ambush on {{target}}",
				"fuzhu-end": "{{name}} shuffles the remaining [Slash] back into the deck",
				shouxi: "{{name}}'s Seal Guard declares {{card}}",
				"shouxi-null": "{{name}}'s Seal Guard: {{target}}'s [Slash] is nullified",
				"huimin-show": "{{name}}'s Benevolence shows {{cards}}",
				"huimin-take": "{{name}} takes {{cards}}",
				bizhuan: "{{name}}'s Writing puts {{cards}} as a Book",
				tongbo: "{{name}}'s Extensive Learning swaps {{cards}}",
				"tongbo-give": "{{name}} gives a Book {{cards}} to {{target}}",
				wengua: "{{name}} consults the hexagram with {{target}}"
			},
			cardDesc: {
				crossbow: "Range 1. You may use any number of [Slash] in your play phase.",
				double_sword: "Range 2. After your [Slash] targets an opposite-gender hero, they choose: discard a hand card, or let you draw a card.",
				qinggang_sword: "Range 2. Your [Slash] ignores the target's armor.",
				blade: "Range 3. After your [Slash] is dodged, you may use another [Slash] on the same target.",
				spear: "Range 3. You may use two hand cards as a [Slash].",
				axe: "Range 3. After your [Slash] is dodged, you may discard two cards to make it still deal damage.",
				halberd: "Range 4. If your [Slash] is your last hand card, it may target up to two extra heroes.",
				kylin_bow: "Range 5. After your [Slash] damages the target, you may discard one of their horses.",
				ice_sword: "Range 2. When your [Slash] would deal damage, you may prevent it and discard two of the target's cards instead.",
				guding_blade: "Range 2. Your [Slash] deals +1 damage to a target with no hand cards.",
				fan: "Range 4. You may use a normal [Slash] as a Fire [Slash].",
				eight_diagram: "When you need to play a [Dodge], you may judge: on red, count as having played one.",
				renwang_shield: "Black [Slash] cards have no effect on you.",
				vine: "Normal [Slash] cards have no effect on you; fire damage you take is increased by 1.",
				silver_lion: "Damage greater than 1 is reduced to 1; when you lose this armor, recover 1 HP.",
				defHorse: "Others count their distance to you as +1.",
				offHorse: "You count your distance to others as -1.",
				indulgence: "Delayed trick. Judged in the judgment phase: unless it is a heart, skip the play phase this turn.",
				supply_shortage: "Delayed trick. Judged in the judgment phase: unless it is a club, skip the draw phase this turn.",
				lightning: "Delayed trick. Judged in the judgment phase: on a spade 2-9, take 3 thunder damage; otherwise it moves to the next hero's judge area."
			},
			error: {
				notYourTurn: "Not your play phase",
				notYourAsk: "No response needed from you",
				noCard: "That card is not in your hand",
				notPlayable: "Cannot play that card now",
				badTarget: "Invalid target",
				badGeneral: "That general is not a candidate",
				badRespond: "Cannot respond with that card",
				badChoose: "Invalid choice",
				badSkill: "That skill cannot be activated now"
			},
			card: {
				slash: "Slash",
				jink: "Dodge",
				peach: "Peach",
				duel: "Duel",
				savage_assault: "Savage Assault",
				archery_attack: "Archery Attack",
				amazing_grace: "Amazing Grace",
				god_salvation: "God Salvation",
				ex_nihilo: "Ex Nihilo",
				snatch: "Snatch",
				dismantlement: "Dismantlement",
				collateral: "Collateral",
				nullification: "Nullification",
				indulgence: "Indulgence",
				lightning: "Lightning",
				crossbow: "Crossbow",
				double_sword: "Double Sword",
				qinggang_sword: "Qinggang Sword",
				blade: "Green Dragon Blade",
				spear: "Serpent Spear",
				axe: "Stone-piercing Axe",
				halberd: "Sky Halberd",
				kylin_bow: "Kylin Bow",
				ice_sword: "Ice Sword",
				eight_diagram: "Eight Diagram",
				renwang_shield: "Renwang Shield",
				jueying: "Jueying +1",
				dilu: "Dilu +1",
				zhuahuangfeidian: "Yellow Lightning +1",
				chitu: "Red Hare -1",
				dayuan: "Dayuan -1",
				zixing: "Zixing -1",
				fire_slash: "Fire Slash",
				thunder_slash: "Thunder Slash",
				analeptic: "Analeptic",
				fire_attack: "Fire Attack",
				iron_chain: "Iron Chain",
				supply_shortage: "Supply Shortage",
				guding_blade: "Guding Blade",
				fan: "Zhuque Fan",
				vine: "Vine Armor",
				silver_lion: "Silver Lion",
				hualiu: "Hualiu +1"
			},
			general: {
				caocao: "Cao Cao",
				simayi: "Sima Yi",
				xiahoudun: "Xiahou Dun",
				zhangliao: "Zhang Liao",
				xuchu: "Xu Chu",
				guojia: "Guo Jia",
				zhenji: "Zhen Ji",
				liubei: "Liu Bei",
				guanyu: "Guan Yu",
				zhangfei: "Zhang Fei",
				zhugeliang: "Zhuge Liang",
				zhaoyun: "Zhao Yun",
				machao: "Ma Chao",
				huangyueying: "Huang Yueying",
				sunquan: "Sun Quan",
				ganning: "Gan Ning",
				lvmeng: "Lü Meng",
				huanggai: "Huang Gai",
				zhouyu: "Zhou Yu",
				daqiao: "Da Qiao",
				luxun: "Lu Xun",
				sunshangxiang: "Sun Shangxiang",
				huatuo: "Hua Tuo",
				lvbu: "Lü Bu",
				diaochan: "Diao Chan",
				xiahouyuan: "Xiahou Yuan",
				caoren: "Cao Ren",
				huangzhong: "Huang Zhong",
				weiyan: "Wei Yan",
				xiaoqiao: "Xiao Qiao",
				zhoutai: "Zhou Tai",
				zhangjiao: "Zhang Jiao",
				yuji: "Yu Ji",
				dianwei: "Dian Wei",
				xunyu: "Xun Yu",
				pangtong: "Pang Tong",
				wolong: "Wolong Zhuge",
				taishici: "Taishi Ci",
				yuanshao: "Yuan Shao",
				yanliangwenchou: "Yanliang & Wenchou",
				pangde: "Pang De",
				xuhuang: "Xu Huang",
				caopi: "Cao Pi",
				menghuo: "Meng Huo",
				zhurong: "Zhu Rong",
				sunjian: "Sun Jian",
				lusu: "Lu Su",
				dongzhuo: "Dong Zhuo",
				jiaxu: "Jia Xu",
				zhanghe: "Zhang He",
				dengai: "Deng Ai",
				jiangwei: "Jiang Wei",
				liushan: "Liu Shan",
				sunce: "Sun Ce",
				erzhang: "Zhang Zhao & Hong",
				zuoci: "Zuo Ci",
				caiwenji: "Cai Wenji",
				caozhi: "Cao Zhi",
				yujin: "Yu Jin",
				zhangchunhua: "Zhang Chunhua",
				xin_fazheng: "Fa Zheng",
				xin_masu: "Ma Su",
				xin_xushu: "Xu Shu",
				xusheng: "Xu Sheng",
				lingtong: "Ling Tong",
				wuguotai: "Wu Guotai",
				chengong: "Chen Gong",
				gaoshun: "Gao Shun",
				wangyi: "Wang Yi",
				xunyou: "Xun You",
				zhonghui: "Zhong Hui",
				old_madai: "Ma Dai",
				liaohua: "Liao Hua",
				guanzhang: "Guanxing & Zhangbao",
				bulianshi: "Bu Lianshi",
				handang: "Han Dang",
				chengpu: "Cheng Pu",
				liubiao: "Liu Biao",
				caozhang: "Cao Zhang",
				manchong: "Man Chong",
				guohuai: "Guo Huai",
				caochong: "Cao Chong",
				guanping: "Guan Ping",
				liufeng: "Liu Feng",
				jianyong: "Jian Yong",
				yufan: "Yu Fan",
				panzhangmazhong: "Panzhang & Mazhong",
				zhuran: "Zhu Ran",
				xin_liru: "Li Ru",
				fuhuanghou: "Fu Shou",
				hanhaoshihuan: "Hanhao & Shihuan",
				chenqun: "Chen Qun",
				caozhen: "Cao Zhen",
				zhangsong: "Zhang Song",
				wuyi: "Wu Yi",
				zhoucang: "Zhou Cang",
				zhuhuan: "Zhu Huan",
				guyong: "Gu Yong",
				sunluban: "Sun Luban",
				yj_jushou: "Ju Shou",
				caifuren: "Lady Cai",
				caoxiu: "Cao Xiu",
				caorui: "Cao Rui",
				zhongyao: "Zhong Yao",
				xiahoushi: "Xiahou Shi",
				liuchen: "Liu Chen",
				zhangyi: "Zhang Ni",
				zhuzhi: "Zhu Zhi",
				quancong: "Quan Cong",
				sunxiu: "Sun Xiu",
				gongsunyuan: "Gongsun Yuan",
				guotufengji: "Guotu & Fengji",
				guohuanghou: "Empress Guo",
				sunziliufang: "Sunzi & Liufang",
				huanghao: "Huang Hao",
				liyan: "Li Yan",
				sundeng: "Sun Deng",
				cenhun: "Cen Hun",
				zhangrang: "Zhang Rang",
				liuyu: "Liu Yu",
				xinxianying: "Xin Xianying",
				jikang: "Ji Kang",
				wuxian: "Wu Xian",
				qinmi: "Qin Mi",
				xuezong: "Xue Zong",
				xushi: "Xu Shi",
				caojie: "Cao Jie",
				caiyong: "Cai Yong",
				re_caocao: "Cao Cao",
				re_simayi: "Sima Yi",
				re_xiahoudun: "Xiahou Dun",
				re_zhangliao: "Zhang Liao",
				re_xuchu: "Xu Chu",
				re_guojia: "Guo Jia",
				re_zhenji: "Zhen Ji",
				re_liubei: "Liu Bei",
				re_guanyu: "Guan Yu",
				re_zhangfei: "Zhang Fei",
				re_zhugeliang: "Zhuge Liang",
				re_zhaoyun: "Zhao Yun",
				re_machao: "Ma Chao",
				re_huangyueying: "Huang Yueying",
				re_sunquan: "Sun Quan",
				re_ganning: "Gan Ning",
				re_lvmeng: "Lü Meng",
				re_huanggai: "Huang Gai",
				re_zhouyu: "Zhou Yu",
				re_daqiao: "Da Qiao",
				re_luxun: "Lu Xun",
				re_sunshangxiang: "Sun Shangxiang",
				re_huatuo: "Hua Tuo",
				re_lvbu: "Lü Bu",
				re_diaochan: "Diao Chan",
				re_xiahouyuan: "Xiahou Yuan",
				re_caoren: "Cao Ren",
				re_huangzhong: "Huang Zhong",
				re_weiyan: "Wei Yan",
				re_xiaoqiao: "Xiao Qiao",
				re_zhoutai: "Zhou Tai",
				re_zhangjiao: "Zhang Jiao",
				re_dianwei: "Dian Wei",
				re_xunyu: "Xun Yu",
				re_pangtong: "Pang Tong",
				re_wolong: "Wolong Zhuge",
				re_taishici: "Taishi Ci",
				re_yuanshao: "Yuan Shao",
				re_yanliangwenchou: "Yanliang & Wenchou",
				re_pangde: "Pang De",
				re_xuhuang: "Xu Huang",
				re_caopi: "Cao Pi",
				re_menghuo: "Meng Huo",
				re_zhurong: "Zhu Rong",
				re_sunjian: "Sun Jian",
				re_lusu: "Lu Su",
				re_dongzhuo: "Dong Zhuo",
				re_jiaxu: "Jia Xu",
				re_zhanghe: "Zhang He",
				re_dengai: "Deng Ai",
				re_jiangwei: "Jiang Wei",
				re_liushan: "Liu Shan",
				re_sunce: "Sun Ce",
				re_erzhang: "Zhang Zhao & Hong",
				re_caiwenji: "Cai Wenji"
			},
			skill: {
				jianxiong: "Villainous Hero",
				hujia: "Royal Escort",
				fankui: "Retaliation",
				guicai: "Fate Twist",
				ganglie: "Unyielding",
				qingjian: "Frugality",
				tuxi: "Raid",
				luoyi: "Berserk",
				tiandu: "Jealous Heaven",
				yiji: "Legacy",
				luoshen: "Goddess Luo",
				qingguo: "Allure",
				rende: "Benevolence",
				jijiang: "Call to Arms",
				wusheng: "Warrior Saint",
				yijue: "Honor Bound",
				paoxiao: "Roar",
				tishen: "Substitute",
				guanxing: "Stargazing",
				kongcheng: "Empty Fort",
				longdan: "Dragon's Guts",
				yajiao: "Last Stand",
				mashu: "Horsemanship",
				tieji: "Iron Cavalry",
				jizhi: "Quick Wit",
				qicai: "Prodigy",
				zhiheng: "Rebalance",
				jiuyuan: "Rescue",
				qixi: "Ambush",
				fenwei: "Majesty",
				keji: "Self-restraint",
				qinxue: "Diligence",
				kurou: "Ruse of Injury",
				zhaxiang: "Feigned Surrender",
				yingzi: "Heroic Poise",
				fanjian: "Double Agent",
				guose: "Country's Charm",
				liuli: "Diversion",
				qianxun: "Humility",
				lianying: "Linked Camps",
				jieyin: "Matrimony",
				xiaoji: "Heroine",
				chuli: "Purge",
				jijiu: "First Aid",
				wushuang: "Peerless",
				liyu: "Ruthless Pursuit",
				lijian: "Sow Discord",
				biyue: "Moon Veil",
				gongxin: "Read Mind",
				shensu: "Godspeed",
				jushou: "Hold Fast",
				jiewei: "Break Siege",
				liegong: "Fierce Bow",
				kuanggu: "Savage Feast",
				tianxiang: "Heavenly Scent",
				hongyan: "Rosy Cheeks",
				buqu: "Undying",
				fenji: "Rally",
				leiji: "Thunder Strike",
				guidao: "Dark Path",
				huangtian: "Yellow Sky",
				qiangxi: "Power Strike",
				quhu: "Drive Tiger",
				jieming: "Moral Support",
				lianhuan: "Chain Links",
				niepan: "Nirvana",
				huoji: "Fire Attack",
				kanpo: "See Through",
				bazhen: "Eight Formations",
				tianyi: "Heavenly Justice",
				luanji: "Random Fire",
				xueyi: "Bloodline",
				shuangxiong: "Dual Heroes",
				mengjin: "Fierce Advance",
				duanliang: "Supply Cut",
				xingshang: "Mourning",
				fangzhu: "Exile",
				songwei: "Majesty",
				huoshou: "Chief Culprit",
				zaiqi: "Rise Again",
				juxiang: "Giant Elephant",
				lieren: "Fierce Blade",
				yinghun: "Heroic Soul",
				haoshi: "Generosity",
				dimeng: "Alliance",
				jiuchi: "Wine Pool",
				roulin: "Flesh Forest",
				benghuai: "Collapse",
				baonue: "Tyranny",
				wansha: "Lethal Trap",
				luanwu: "Chaos",
				weimu: "Veil",
				qiaobian: "Ingenuity",
				tuntian: "Field Cultivation",
				zaoxian: "Forge Ahead",
				jixi: "Swift Raid",
				tiaoxin: "Provoke",
				zhiji: "Inherit Will",
				xiangle: "Indulgence",
				fangquan: "Delegation",
				ruoyu: "Feigned Folly",
				jiang: "Ardor",
				hunzi: "Soul of Fire",
				zhiba: "Hegemony",
				zhijian: "Frank Counsel",
				guzheng: "Firm Administration",
				beige: "Lament",
				duanchang: "Heartbreak",
				botu: "Grand Schemes",
				qingnang: "Green Pouch",
				shebian: "Adaptation",
				moshi: "Stray Arrows",
				qimou: "Brilliant Scheme",
				piaoling: "Drifting",
				ninge: "Ferocity",
				cangzhuo: "Hiding Talent",
				hanzhan: "Fierce Contest",
				jianchu: "Quiver Shot",
				jiezi: "Intercept Supplies",
				wulie: "Fierce Valor",
				changbiao: "Long Spears",
				sishu: "Longing for Shu",
				luoying: "Falling Petals",
				jiushi: "Wine Poem",
				rezhenjun: "Suppress Army",
				jueqing: "Ruthless",
				shangshi: "Mourning",
				xinxuanhuo: "Dazzle",
				xinenyuan: "Grudge",
				olsanyao: "Rumors",
				rezhiman: "Subdue",
				xinwuyan: "Speechless",
				xinjujian: "Recommend",
				xinpojun: "Army Breaker",
				xuanfeng: "Whirlwind",
				ganlu: "Sweet Dew",
				buyi: "Aid",
				mingce: "Bright Plan",
				zhichi: "Slow Wit",
				xinxianzhen: "Breaking Formation",
				jinjiu: "Teetotaler",
				zhenlie: "Chaste Valor",
				miji: "Secret Plan",
				qice: "Brilliant Scheme",
				zhiyu: "Feigned Folly",
				quanji: "Power Scheme",
				zili: "Self-Reliance",
				paiyi: "Expel",
				qianxi: "Ambush",
				dangxian: "Vanguard",
				fuli: "Dormant Dragon",
				fuhun: "Father's Soul",
				old_anxu: "Consolation",
				zhuiyi: "Remembrance",
				gongji: "Bow Cavalry",
				jiefan: "Lift the Siege",
				lihuo: "Pestilence Fire",
				chunlao: "Strong Brew",
				rezishou: "Self-Defense",
				zongshi: "Imperial Clan",
				new_jiangchi: "Gallop",
				rejingce: "Precision",
				chengxiang: "Weighing",
				renxin: "Kindness",
				danshou: "Bold Defense",
				zhiyan: "Frankness",
				zongxuan: "Unfettered",
				qiuyuan: "Plea",
				zhuikong: "Frighten",
				qiaoshui: "Persuasion",
				jyzongshi: "Leniency",
				xiansi: "Framing",
				xiansi2: "Framing",
				junxing: "Harsh Punishment",
				yuce: "Countermeasure",
				duodao: "Seize Blade",
				anjian: "Sneak Arrow",
				longyin: "Dragon Chant",
				xinjuece: "Final Plan",
				xinmieji: "Plot",
				xinfencheng: "Burn the City",
				shenduan: "Prudent Judgment",
				yonglve: "Valor",
				pindi: "Rank",
				faen: "Grace of Law",
				xinsidi: "Scout Enemy",
				qiangzhi: "Insight",
				xiantu: "Present Map",
				olbenxi: "Rush",
				xinzhongyong: "Loyal Valor",
				chanhui: "Slander",
				jiaojin: "Pride",
				fenli: "Zeal",
				pingkou: "Pacify",
				shenxing: "Prudence",
				olbingyi: "Unity",
				qieting: "Eavesdrop",
				xianzhou: "Offer Province",
				jianying: "Growing Camp",
				shibei: "Stubborn North",
				qianju: "Swift Steed",
				qingxi: "Raid",
				huituo: "Restoration",
				mingjian: "Clear Mirror",
				xingshuai: "Rise and Fall",
				huomo: "Living Ink",
				zuoding: "Assist Edict",
				qiaoshi: "Gather Firewood",
				yanyu: "Swallow Words",
				zhanjue: "Desperate Duel",
				qinwang: "Rally the King",
				wurong: "Soothing Blade",
				shizhi: "Resolute",
				xinanguo: "Stabilize State",
				yaoming: "Claim Fame",
				yanzhu: "Feast Doom",
				xingxue: "Promote Learning",
				xinzhaofu: "Edict Bind",
				huaiyi: "Hidden Grudge",
				jigong: "Blitz",
				shifei: "Cover Up",
				jiaozhao: "Imperial Edict",
				danxin: "Utmost Devotion",
				guizao: "Flowery Draft",
				jiyu: "Mockery",
				qinqing: "Bedroom Whispers",
				huisheng: "Bribe for Life",
				dcduliang: "Grain Supervision",
				fulin: "Hidden Scales",
				kuangbi: "Loyal Aid",
				jishe: "Extravagance",
				lianhuo: "Chain Disaster",
				taoluan: "Turmoil",
				zhige: "Cease War",
				zongzuo: "Ancestral Seat",
				zhongjian: "Loyal Insight",
				caishi: "Brilliance",
				qingxian: "Clear Strings",
				canyun: "Lingering Melody",
				juexiang: "Swan Song",
				fumian: "Lasting Bliss",
				daiyan: "Idle Feast",
				jianzheng: "Admonition",
				zhuandui: "Singled Out",
				tianbian: "Heavenly Debate",
				funan: "Repeated Challenge",
				xinjiexun: "Admonishing Lesson",
				wengua: "Hexagram Query",
				fuzhu: "Ambush",
				shouxi: "Seal Guard",
				huimin: "Benevolence",
				bizhuan: "Writing",
				tongbo: "Extensive Learning"
			},
			skillDesc: {
				jianxiong: "After you take 1 damage, you may take the card that dealt the damage.",
				hujia: "Lord skill. When you need to play a [Dodge], you may ask other Wei players in turn; if one plays a [Dodge], it counts as yours.",
				fankui: "After each point of damage you take, you may take a card from the source.",
				guicai: "Before a judgment card takes effect, you may play a hand card to replace it.",
				ganglie: "After you take 1 damage, you may judge: if not hearts, the source chooses one — discard 2 hand cards, or take 1 damage from you.",
				qingjian: "After you gain hand cards outside your draw phase, you may give any of them to another player.",
				tuxi: "Draw phase: you may instead take one hand card each from up to two other players whose hand size is no less than yours.",
				luoyi: "Draw phase: you may instead reveal the top 3 cards and take the basic cards, weapons and [Duel]s among them; this turn, your [Slash] and [Duel] deal +1 damage.",
				tiandu: "After your judgment card takes effect, you take it.",
				yiji: "After you take 1 damage, you may draw 2 cards, then may give up to 2 hand cards to other players.",
				luoshen: "Start of turn: you may judge repeatedly — on black, take the card and judge again; stop on red.",
				qingguo: "You may use a black hand card as a [Dodge].",
				rende: "Play phase: you may give any number of hand cards to another player; the first time your total given this phase reaches two, you recover 1 HP.",
				jijiang: "Lord skill. When you need to play a [Slash], you may ask other Shu players in turn; if one plays a [Slash], it counts as yours.",
				wusheng: "You may use a red card as a [Slash].",
				yijue: "Once per play phase: pindian with another player — if you win, they cannot use or play hand cards and their non-locked skills fail this turn; if you lose, you may let them recover 1 HP.",
				paoxiao: "Locked. Your [Slash] has no use limit.",
				tishen: "Limited. Start of turn: you may restore your HP to its value at the end of your previous turn, then draw that many cards.",
				guanxing: "Start of turn: look at the top five cards (three if fewer than four players are alive); put any of them on the deck bottom and the rest back on top in their original order.",
				kongcheng: "Locked. While you have no hand cards, you cannot be the target of [Slash] or [Duel].",
				longdan: "You may use a [Slash] as a [Dodge] and a [Dodge] as a [Slash].",
				yajiao: "When you use or play a hand card outside your turn, reveal the deck top: if its category matches, you may give it to a player; otherwise discard it.",
				mashu: "Locked. Your distance to others is reduced by one.",
				tieji: "When your [Slash] targets a player, you may judge: unless they discard a card of the same suit as the judgment, they cannot dodge this [Slash].",
				jizhi: "When you use a trick card, you may draw a card.",
				qicai: "Locked. Your trick cards have no distance limit.",
				zhiheng: "Once per play phase: discard any number of cards and draw the same number.",
				jiuyuan: "Lord skill. Locked. When another Wu player uses a [Peach] on you, you recover 1 extra HP.",
				qixi: "You may use a black hand card as [Dismantlement].",
				fenwei: "Limited. After a multi-target trick card names its targets, you may make any of them unaffected by it.",
				keji: "If you neither used nor played a [Slash] during your play phase this turn, skip your discard phase.",
				qinxue: "Awakening. Start or end phase: if your hand size minus HP is at least three (at least two in games of seven or more players), lose 1 max HP, then gain \"Read Mind\".",
				kurou: "Once per play phase: discard a hand card to lose 1 HP.",
				zhaxiang: "Locked. After each HP you lose, draw 3 cards; during your turn also gain one extra [Slash] use, and your red [Slash] has no range limit and cannot be dodged.",
				yingzi: "Draw one extra card in draw phase; your hand limit equals your max HP.",
				fanjian: "Once per play phase: give a hand card to another player, who chooses: reveal their hand and discard all cards of that suit; or lose 1 HP.",
				guose: "Once per play phase: use a diamond card as [Indulgence], or discard a diamond card to remove an [Indulgence] in play; then draw a card.",
				liuli: "When you become the target of a [Slash], you may discard a card to redirect it to another player within your attack range (not the user).",
				qianxun: "When you become the only target of a delayed trick or a trick used by another player, you may set aside all hand cards and take them back at end of turn.",
				lianying: "After you lose your last hand card, you may have up to X players each draw a card (X = cards lost).",
				jieyin: "Once per play phase: discard 2 hand cards and choose a wounded male player; you and they each recover 1 HP.",
				xiaoji: "After you lose a card from your equipment area, draw 2 cards.",
				chuli: "Once per play phase: discard a card and choose up to three other players with cards; discard one card from each of you and them. Anyone whose discarded card is a spade draws a card.",
				jijiu: "Outside your turn, you may use a red hand card as a [Peach].",
				wushuang: "Locked. Your [Slash] needs two [Dodge]s to cancel; whoever duels you must play two [Slash]es each time.",
				liyu: "After your [Slash] damages another player, they may let you take one of their cards, then they name another player and you use a [Duel] on that player.",
				lijian: "Once per play phase: discard a card and choose two male players; the first duels the second.",
				biyue: "End phase: draw a card.",
				gongxin: "Once per play phase: look at another player's hand and discard a heart card from it.",
				shensu: "Choose up to two: skip your judge and draw phases; skip your play phase and discard an equipment. For each choice, you use a range-unlimited [Slash] on another player.",
				jushou: "End phase: you may draw a card and flip over.",
				jiewei: "You may use cards in your equipment area as [Nullification].",
				liegong: "When your [Slash] targets a player, if their hand size is no less than your HP or no greater than your attack range, you may make it undodgeable.",
				kuanggu: "Locked. After you deal 1 damage to a player within distance 1, you recover 1 HP.",
				tianxiang: "When you take damage, you may discard a heart hand card and choose another player: redirect the damage to them, then they draw X cards (X = their lost HP).",
				hongyan: "Locked. Your spade cards count as hearts.",
				buqu: "Compulsory. When dying, reveal the top deck card: if its rank differs from all Wounds on your general card, put it on your general card as a Wound and return to 1 HP; otherwise the dying procedure continues. Your hand limit equals your Wound count.",
				fenji: "After a player's hand card is discarded or taken by another player, you may lose 1 HP to let them draw 2 cards.",
				leiji: "When you use or play a [Dodge], you may have a player judge: on black, they take 1 thunder damage from you, then you recover 1 HP.",
				guidao: "Before a judgment card takes effect, you may play a black hand card to replace it and take the original.",
				huangtian: "Lord skill. Once per play phase, another Qun player may give you a [Dodge] or a spade hand card.",
				qiangxi: "Once per play phase: discard a weapon or lose 1 HP, then deal 1 damage to another player within your attack range.",
				quhu: "Once per play phase, duel points with a player whose HP is greater than yours: if you win, they deal 1 damage to a player of your choice in their attack range; if you lose, they deal 1 damage to you.",
				jieming: "After you take 1 damage, you may have a player draw until they have X hand cards (X = their max HP, at most five).",
				lianhuan: "You may use a club hand card as [Iron Chain] or recast it.",
				niepan: "Limited. When dying: you may discard all cards in your area, flip your general card face-up, draw 3 cards and heal to 3 HP.",
				huoji: "You may use a red card as [Fire Attack].",
				kanpo: "You may use a black card as [Nullification].",
				bazhen: "Locked. If you have no armor equipped, you count as having [Eight Diagrams] equipped.",
				tianyi: "Once per play phase, duel points with another player: if you win, this turn your Slash limit is +1, your Slashes have no distance limit and may name one extra target; if you lose, you cannot use Slash this turn.",
				luanji: "Play phase: you may use two hand cards of the same suit as [Archery Attack].",
				xueyi: "Lord skill. Locked. Your hand limit is +X (X = twice the number of other Qun players).",
				shuangxiong: "Draw phase: you may instead judge and take the judgment card; this turn you may use a hand card of the opposite color to it as [Duel].",
				mengjin: "When your Slash is cancelled by the target’s Dodge, you may discard a card from that player.",
				duanliang: "You may use a black basic or black equip card as [Supply Shortage].",
				xingshang: "When another player dies, you may take all of their cards.",
				fangzhu: "After you take damage, you may have another player draw X cards and flip over (X = your lost HP).",
				songwei: "Lord skill. After another Wei player’s judgment card takes effect, if it is black, they may let you draw a card.",
				huoshou: "Locked. [Savage Assault] has no effect on you; when another player’s [Savage Assault] deals damage, you become the damage source.",
				zaiqi: "Draw phase: if you are wounded, you may instead reveal the top X cards (X = your lost HP): recover 1 HP per hearts card among them, then take the rest.",
				juxiang: "Locked. [Savage Assault] has no effect on you; after another player’s non-converted [Savage Assault] finishes resolving, you take it.",
				lieren: "After your Slash deals damage to a player, you may duel points with them: if you win, take one of their cards.",
				yinghun: "Start phase, if you are wounded, you may choose another player and one mode: they draw 1 card and discard X cards; or they draw X cards and discard 1 card (X is your lost HP).",
				haoshi: "Draw phase: draw 2 extra cards; afterwards, if you have at least 5 hand cards, give half of them (rounded down) to another player with the fewest hand cards.",
				dimeng: "Once per play phase, you may discard X cards and choose two other players; they swap hands (X is the difference of their hand counts).",
				jiuchi: "You may use a spade hand card as [Analeptic].",
				roulin: "Locked. When you use Slash on a female player, or a female player uses Slash on you, the target must play two Dodges to cancel it.",
				benghuai: "End phase, if your HP is not the lowest among all players, choose one: lose 1 HP, or lose 1 max HP.",
				baonue: "Lord skill. After another Qun player deals damage, you may judge: on a spade, you recover 1 HP.",
				wansha: "Locked. During your turn, only a dying player may use [Peach] or [Analeptic].",
				luanwu: "Limited. Play phase: every other player in turn either uses a [Slash] on a nearest player, or loses 1 HP.",
				weimu: "Locked. You cannot be targeted by black trick cards.",
				qiaobian: "You may discard a hand card to skip one of your phases (judge/draw/play/discard). If you skip draw phase this way, you may take one hand card each from up to two other players; if you skip play phase, you may move a field card to another player's corresponding area.",
				tuntian: "After you lose cards outside your turn, you may judge: if not hearts, place the judgment card on your general as a Field. Your distance to other players is reduced by the number of Fields.",
				zaoxian: "Awakening. Start phase: if you have at least 3 Fields, lose 1 max HP and gain \"Swift Raid\".",
				jixi: "Play phase: you may use a Field as [Snatch].",
				tiaoxin: "Once per play phase: choose a player whose attack range includes you — they either use a [Slash] on you, or you discard one of their cards.",
				zhiji: "Awakening. Start phase: if you have no hand cards, lose 1 max HP, recover 1 HP or draw 2 cards, then gain \"Stargazing\".",
				xiangle: "Locked. After you become the target of a [Slash], the source must discard a basic card, or the [Slash] has no effect on you.",
				fangquan: "Play phase: you may skip this phase; if you do, at the start of your discard phase you may discard a hand card to give another player an extra turn.",
				ruoyu: "Lord skill, awakening. Start phase: if your HP is the lowest, gain 1 max HP and recover 1 HP, then gain \"Call to Arms\".",
				jiang: "When your [Duel] or red [Slash] names a target, or you become the target of one, you may draw a card.",
				hunzi: "Awakening. Start phase: if your HP is 1, lose 1 max HP and gain \"Heroic Poise\" and \"Heroic Soul\".",
				zhiba: "Lord skill. Once per play phase, another Wu player may pindian with you (you may refuse); if they don't win, you take both pindian cards.",
				zhijian: "Play phase: you may place an equipment from your hand into another player's empty equipment slot, then draw a card.",
				guzheng: "When another player's discard phase ends, if they discarded at least one card this phase, you may let them take one of those cards, then you take the rest.",
				beige: "After a player takes damage from a [Slash], you may discard a card and let them judge: hearts, they recover 1 HP; diamonds, they draw 2 cards; spades, the source flips over; clubs, the source discards 2 cards.",
				duanchang: "Locked. When you die, the player who killed you loses all skills.",
				botu: "Up to X times per round (X = living players, at most three). At end of turn, if cards of at least four suits entered the discard pile this turn, you may take an extra turn.",
				qingnang: "Play phase: you may discard a hand card to let a player who has not been a Green Pouch target this turn recover 1 HP; if the discarded card is black, you cannot use Green Pouch again this turn.",
				shebian: "After your general card is flipped, you may move an equipment card on the field.",
				moshi: "Locked. After your [Slash] damages its target, if they have armor or horses equipped, put that [Slash] on their general card; when they lose an armor or horse, you take those cards from their general card.",
				qimou: "Limited. Play phase: you may lose any amount of HP and draw that many cards; until end of turn, your distance to others is -X and your [Slash] limit is +X (X = HP lost).",
				piaoling: "End phase: you may judge; on hearts, choose one — give the judgment card to a player (if yourself, discard a card); or put it on the deck top.",
				ninge: "Locked. After a player takes damage for the second time in a turn, if that player or the source is you, draw a card, then discard a card from their equipment or judge area.",
				cangzhuo: "Discard phase: if you used no trick cards this turn, your trick cards do not count toward your hand limit.",
				hanzhan: "When you initiate or become the target of a pindian, you may make the opponent's pindian card a random hand card; after the pindian, you may take the highest-rank [Slash] among the pindian cards.",
				jianchu: "When your [Slash] targets a player, you may discard one of their cards: if it is not basic, this [Slash] cannot be dodged and your [Slash] limit is +1 this turn; if basic, they take this [Slash].",
				jiezi: "After another player skips their draw phase, you may choose a player: if they have the fewest hand cards and no Supply mark, they gain one; otherwise they draw a card. When a player with a Supply mark ends their draw phase, you remove it and they get an extra draw phase.",
				wulie: "Limited. End phase: you may lose any amount of HP and choose that many other players; each gains a Valor mark. When a marked player would take damage, they remove a mark to prevent it.",
				changbiao: "Once per play phase: use any number of hand cards as a [Slash] (no distance limit); if it deals damage, draw X cards at end of the play phase (X = the number of cards used as this [Slash]).",
				sishu: "Once per play phase: choose a player — for the rest of the game, the judgment effect of their [Indulgence] is reversed.",
				luoying: "When another player's club cards enter the discard pile by being discarded or judged, you take them.",
				jiushi: "Play phase: if face-up, you may flip face-down to use a virtual [Analeptic]. After you take damage, if face-down, you flip face-up. While dying, if face-up, you may flip face-down to recover 1 HP.",
				rezhenjun: "Start phase: you may discard X cards from a player (X = their hand size minus their HP, at least 1), then choose: you discard as many cards as the number of non-equipment cards among them; or they draw that many cards.",
				jueqing: "Locked. All damage you deal is treated as HP loss.",
				shangshi: "When your hand size is less than your lost HP, you may draw up to your lost HP.",
				xinxuanhuo: "Draw phase: you may instead let another player draw 2 cards, then unless they use a [Slash] on a player you choose within their attack range, you take 2 of their cards.",
				xinenyuan: "After you gain 2+ cards from another player at once, they draw a card. After you take 1 damage, the source must choose: give you a hand card, or lose 1 HP.",
				olsanyao: "Once each per play phase: discard a card to deal 1 damage to a player with the most HP, or to a player with the most hand cards.",
				rezhiman: "When you deal damage to another player, you may prevent it and take a card from their zones instead.",
				xinwuyan: "Locked. Trick damage you deal is nullified; trick damage dealt to you is nullified.",
				xinjujian: "End phase: you may discard a non-basic hand card and choose another player, who chooses: draw 2 cards; recover 1 HP; or flip face-up and reset (unchain).",
				xinpojun: "Play phase: after your [Slash] targets a player, you may set aside up to X of their cards next to their general (X = their HP); they take them back at the end of the current turn.",
				xuanfeng: "After you lose an equipped card, or discard 2+ cards in your discard phase, you may discard 2 cards total from 1-2 other players.",
				ganlu: "Once per play phase: swap the equipment areas of two players; the difference in equipment count must not exceed your lost HP.",
				buyi: "When a player enters dying, you may reveal a random hand card of theirs: if it is not basic, they discard it and recover 1 HP.",
				mingce: "Once per play phase: give a [Slash] or equipment card to another player, who then chooses: use a virtual [Slash] on a player in their attack range that you name; or draw a card.",
				zhichi: "Locked. After you take damage outside your turn, [Slash] and non-delayed tricks have no effect on you until the end of the current turn.",
				xinxianzhen: "Once per play phase: point-duel a player. If you win, this turn your cards against them ignore distance and their armor, your [Slash] against them costs no quota, and your [Slash] may also target them. If you lose, you cannot use [Slash] this turn and your [Slash] cards don't count toward your hand limit.",
				jinjiu: "Locked. Your [Analeptic] cards are treated as [Slash].",
				zhenlie: "After you become the target of another player's [Slash] or non-delayed trick, you may lose 1 HP to make it ineffective on you, then discard a card of the source (random).",
				miji: "At the end phase, if you are wounded, you may draw X cards (X = lost HP), then give up to that many hand cards to another player.",
				qice: "Once per play phase: you may use all your hand cards (at least 1) as any non-delayed trick (targets must be legal).",
				zhiyu: "After you take damage, you may draw a card and reveal all your hand cards; if they share one color, the source discards a card.",
				quanji: "After each point of damage you take, you may draw a card and set a hand card aside as \"Power\"; your hand limit +X (X = \"Power\" count).",
				zili: "Awakening. At the start phase, if you have 3+ \"Power\", choose: recover 1 HP or draw 2 cards, then reduce max HP by 1 and gain [Expel].",
				paiyi: "Once per play phase: remove a \"Power\" to make a player draw 2 cards; if their hand exceeds yours, deal 1 damage to them.",
				qianxi: "At the start phase, you may draw a card and discard a card, then make a player at distance 1 unable to use or play hand cards of the discarded color this turn.",
				dangxian: "Locked. At the start of your turn, you take an extra play phase.",
				fuli: "Limited. When you are dying, you may recover to the number of living factions (capped at max HP), then flip over.",
				fuhun: "You may use or play two hand cards as a [Slash]; if a [Slash] used this way in your play phase deals damage, you gain [Saint of War] and [Roar] this turn.",
				old_anxu: "Once per play phase: choose two other players with different hand counts; the one with fewer randomly takes a hand card from the other and reveals it; if it is not spades, you draw a card.",
				zhuiyi: "When you die, you may make another player (except your killer) draw 3 cards and recover 1 HP.",
				gongji: "Once per play phase: discard a card to gain unlimited attack range this turn; if it was an equipment, you may discard a card of another player (random).",
				jiefan: "Limited. In your play phase, choose a player: each player whose attack range includes them chooses to discard a weapon or let them draw a card.",
				lihuo: "You may use a normal [Slash] as a fire [Slash]; such a fire [Slash] may target an extra player, and after it deals damage you lose 1 HP.",
				chunlao: "At the end phase, if you have no \"Brew\", you may set 1+ [Slash] aside as \"Brew\"; when a player is dying, you may remove a \"Brew\" to make them recover 1 HP.",
				rezishou: "In the draw phase, you may draw X extra cards (X = living factions); if you do, damage you deal to other players is prevented this turn.",
				zongshi: "Locked. Your hand limit +X (X = living factions).",
				new_jiangchi: "In the draw phase, choose: draw 1 extra card but cannot use or play [Slash] this turn; or draw 1 fewer card, and your [Slash] ignores distance with +1 quota this turn.",
				rejingce: "At the end of your play phase, you may draw X cards (X = number of card classes you used this phase). Locked: your hand limit +X (X = number of suits you used this turn).",
				chengxiang: "After you take 1 damage, you may reveal the top 4 cards of the deck and take any of them whose points sum to 13 or less.",
				renxin: "When a character with 1 HP takes damage, you may discard an equip card and flip over to prevent that damage.",
				danshou: "In the play phase, you may discard X cards and choose a character in your attack range who has cards (X = times used this phase + 1): if X is 1 they discard a random card; if 2 they give you a card; if 3 you deal 1 damage to them; if 4 or more, both of you draw 2 cards.",
				zhiyan: "At the end phase, you may make a character draw and reveal a card: if it is an equip card, they equip it and recover 1 HP.",
				zongxuan: "After your cards enter the discard pile by being discarded, you may put any of them on the top of the deck (cards chosen first end up nearer the top).",
				qiuyuan: "When you become the target of a [Slash], you may make another character in the source's attack range choose: give you a [Jink], or become an extra target of this [Slash].",
				zhuikong: "At another character's start phase, if you are wounded, you may duel them by points: if you win, their cards cannot target others this turn; if you lose, their distance to you counts as 1 this turn.",
				qiaoshui: "Once per play phase, you may duel another character by points: if you win, your next [Slash] this turn may target +1 character; if you lose, you cannot use trick cards this turn.",
				jyzongshi: "Locked: after a points duel, if you win you take the opponent's duel card; if you lose, you take back your own.",
				xiansi: "At the start phase, you may put one card each from 1-2 other characters who have cards onto your general card as Ni; in their play phase, other characters may remove 2 Ni to use a [Slash] on you (counts toward quota, distance applies).",
				xiansi2: "In your play phase, you may remove 2 of Liu Feng's Ni to use a [Slash] on him (counts toward quota, distance applies).",
				junxing: "Once per play phase, you may discard 1 or more hand cards and make another character choose: discard a hand card of a class different from all of yours, or flip over and draw X cards (X = cards you discarded).",
				yuce: "After you take 1 damage, you may show a hand card: the source must discard a hand card of a different class, or you recover 1 HP.",
				duodao: "After you take 1 damage from a [Slash], you may discard a card to take the source's weapon.",
				anjian: "Locked: when your [Slash] deals damage to a target whose attack range doesn't reach you, the damage +1.",
				longyin: "After a character uses a [Slash] in their play phase, you may discard a card so that [Slash] doesn't count toward quota; if it was red, you draw a card.",
				xinjuece: "At the end phase, you may deal 1 damage to a character who has no hand cards.",
				xinmieji: "Once per play phase, you may put a black trick card on the top of the deck and make another character with hand cards choose: give you a trick card, or discard 2 non-trick cards.",
				xinfencheng: "Limited: in the play phase, make every other character in turn choose: discard at least X cards (X = cards discarded so far for this skill + 1), or take 2 fire damage from you.",
				shenduan: "After your black basic card enters the discard pile by being discarded, you may use one of them as [Supply Shortage] on another character without [Supply Shortage] in their judgment zone.",
				yonglve: "At the start of another character's judgment phase, if they are in your attack range, you may discard a card from their judgment zone, then you are treated as using a [Slash] on them; if it is cancelled by a [Jink], you draw a card.",
				pindi: "Play phase: you may discard a card and choose another character (not one already chosen this turn, not a type already discarded this turn): they draw X cards or discard X cards (X = times this skill was used this turn); if they are wounded, you become chained.",
				faen: "After a character flips face-up or becomes chained, you may have them draw a card.",
				xinsidi: "At the start of another character's play phase, you may discard a non-basic card of the same color as one of your equipped cards: they cannot use or play cards of that color this turn; if they used no [Slash] this turn, at the end of their discard phase you are treated as using a [Slash] on them.",
				qiangzhi: "At the start of the play phase, you may reveal a random hand card of another character: this turn, whenever you use a card of the same type, you draw a card.",
				xiantu: "At the start of another character's play phase, you may draw 2 cards and give them 2 cards; at the end of the turn, if they killed no one this turn, you lose 1 HP.",
				olbenxi: "Locked: each time you use a card in your turn, your distance to others is reduced by 1 this turn; when you use a [Slash] with a single target and your distance to all others is no more than 1, choose: this card ignores armor, cannot be responded to by [Jink], or both.",
				xinzhongyong: "After your [Slash] resolves, you may give that [Slash] or the [Jink] played in response to a character other than the target; if they receive a red card, they may use a [Slash] on a character in your attack range.",
				chanhui: "Once per turn: after your [Slash] targets a single character, you may make another character in your attack range who could be a target choose: give you a card and become the user of the [Slash], or also become a target.",
				jiaojin: "When you take damage from a male character, if you have equip cards, you may discard an equip card to reduce the damage by 1.",
				fenli: "If you have the most hand cards, you may skip the draw phase; if you have the most HP, you may skip the play phase; if you have the most equip cards (at least one), you may skip the discard phase.",
				pingkou: "At the end of your turn, you may deal 1 damage each to up to X other characters (X = phases you skipped this turn).",
				shenxing: "Play phase: you may discard 2 cards and draw a card.",
				olbingyi: "After your cards enter the discard pile by being discarded, you may reveal all your hand cards; if they share one color, you and up to X other characters each draw a card (X = your hand card count).",
				qieting: "At the end of another character's turn, if they used no cards targeting other characters this turn, choose: move an equip card from their zone to yours, or draw a card.",
				xianzhou: "Limited: in the play phase, give all your equipped cards to another character, then they choose: recover X HP, or deal 1 damage each to up to X characters in their attack range (X = cards given).",
				jianying: "In the play phase, when you use a card with the same suit or point as the previous card you used this phase, you may draw a card.",
				shibei: "Locked: after you take damage, if it is the first damage you took this turn, recover 1 HP; otherwise, lose 1 HP.",
				qianju: "Locked: while you are wounded, your distance to other characters is reduced by X (X = your lost HP).",
				qingxi: "When your [Slash] deals damage to a target, if you have a weapon equipped, you may make them choose: discard X hand cards (X = the weapon's range) and discard your weapon, or increase this damage by 1.",
				huituo: "After you take damage, you may make a character judge: on red, they recover 1 HP; on black, they draw X cards (X = the damage taken).",
				mingjian: "Once per play phase: give all your hand cards to another character; until the end of their next turn, their hand limit +1 and [Slash] quota +1.",
				xingshuai: "Lord skill, limited: when you enter dying, each other Wei character in turn may make you recover 1 HP; those who do then take 1 damage each.",
				huomo: "When you need to use a basic card you have not used this turn, you may put a black non-basic card on the top of the deck to use it.",
				zuoding: "After another character uses a spade card to target someone in their play phase, if no one has taken damage this turn, you may make one of the targets draw a card.",
				qiaoshi: "At the start of another character's end phase, if your hand count equals theirs, you and they each draw a card.",
				yanyu: "In the play phase, you may recast [Slash]; at the end of your play phase, if you recast at least two [Slash] this way, you may make a male character draw two cards.",
				zhanjue: "In the play phase, you may use all your hand cards as [Duel]; after it resolves, you and anyone damaged by it each draw a card; if you drew two or more cards this way in one phase, this skill is disabled until the end of the turn.",
				qinwang: "Lord skill: when you need to use or play a [Slash], you may discard a card to be treated as having used [Call for Help]; whoever answers draws a card when playing the [Slash].",
				wurong: "Once per play phase: you and another character with hand cards each reveal a hand card simultaneously; if yours is [Slash] and theirs isn't [Jink], discard that [Slash] and deal 1 damage to them; if yours isn't [Slash] and theirs is [Jink], discard your revealed card and take one of their cards.",
				shizhi: "Locked: while your HP is 1, your [Jink] count as [Slash].",
				xinanguo: "Once per play phase: choose another character — if their hand count is the fewest, they draw a card; if their HP is the lowest and they are wounded, they recover 1 HP; if their equip count is the fewest, they use a random equip card; then you perform any of these effects they skipped that you qualify for.",
				yaoming: "Once per turn, after you deal or take damage, you may choose a character whose hand count differs from yours: if they have more, randomly discard one of their hand cards; if fewer, they draw a card.",
				yanzhu: "Once per play phase: make another character with cards choose: give you all their equipped cards, then you lose [Feast Doom]; or discard a card.",
				xingxue: "At the start of your end phase, you may make up to X characters each draw a card and put a card on top of the deck in turn (X = your HP; if you have lost [Feast Doom], your max HP instead).",
				xinzhaofu: "Lord skill, limited: in the play phase, choose up to two other characters; they count as in range of all other Wu characters.",
				huaiyi: "Once per play phase: reveal all your hand cards; if they aren't all one color, choose a color and discard all hand cards of it, then take a card from each of up to X other characters (X = cards discarded); if you took at least two cards, lose 1 HP.",
				jigong: "At the start of your play phase, you may draw two cards; if you do, your hand limit this turn becomes the total damage you dealt this phase.",
				shifei: "When you need to use or play a [Jink], you may make the current character draw a card; then if their hand count is not uniquely the highest, discard a card from a character with the most hand cards, and you are treated as having used or played a [Jink].",
				jiaozhao: "Once per play phase: reveal a hand card and choose the nearest other character; they name a basic card, and this phase you may use the revealed card as that card (using [Peach]/[Analeptic] on yourself this way ignores target restrictions).",
				danxin: "After you take damage, you may draw a card, or gain a Danxin mark. With at least one mark, [Imperial Edict] may also name normal trick cards; with at least two, you name the card yourself, and after taking damage you draw a card directly.",
				guizao: "In your end phase, if you discarded at least two hand cards of all different suits in your discard phase, choose one: draw a card, or recover 1 HP.",
				jiyu: "In the play phase, make another character with hand cards (not yet targeted this phase) discard a hand card; if it is a spade, you flip over and they lose 1 HP. This turn you cannot use hand cards of the discarded suit.",
				qinqing: "In your end phase, choose any number of non-lord characters with hand cards whose attack range includes the lord; discard a hand card from each and make each draw a card, then you draw X cards (X = how many of them have more hand cards than the lord).",
				huisheng: "When you take damage from another character, you may show at least one hand card; the source chooses: take one of the shown cards and prevent the damage (you can never use this skill on them again), or discard an equal number of cards.",
				dcduliang: "Once per play phase: take a random hand card from another character, then choose: they view the deck's top two cards and gain the basic ones; or they draw an extra card in their next draw phase.",
				fulin: "Locked: cards you gain during your turn do not count toward your hand limit.",
				kuangbi: "Once per play phase: make another character with cards put up to three cards on your general card; at your next preparation phase, you gain them and they draw the same number of cards.",
				jishe: "In the play phase, if your hand limit is above zero, you may draw a card and reduce your hand limit by 1 this turn. In your end phase, if you have no hand cards, you may chain up to X other characters (X = your HP).",
				lianhuo: "Locked: fire damage you take while chained is increased by 1 if it was not transmitted through the chain.",
				taoluan: "In the play phase, you may use a hand card as a basic or normal trick card not yet used this way this game; after it resolves, make another character choose: give you a card of a different class, or you lose 1 HP and [Turmoil] is disabled this turn.",
				zhige: "Once per play phase, if your hand count exceeds your HP, choose another character whose attack range includes you; they choose: use a virtual [Slash], or give you an equip card.",
				zongzuo: "Locked: at game start, gain X max HP and recover X HP (X = number of living factions); after a character dies, if their faction has no living members, reduce your max HP by 1.",
				zhongjian: "Once per play phase: show a hand card and choose another character with hand cards, then randomly show up to 3 of their hand cards. For each shown card matching your card in suit, draw a card; if any matches in rank, deal 1 damage to them; for each shown card matching neither suit nor rank, discard a card.",
				caishi: "Draw phase: choose one — draw 1 less, and [Loyal Insight] may show up to 2 of your cards this turn; hand limit -1, and [Loyal Insight] shows 1 more of their cards this turn; draw 2 more, and you cannot use [Loyal Insight] this turn.",
				qingxian: "Once per play phase: discard up to X hand cards (X = your HP) and choose that many other characters. Those with fewer equips than you recover 1 HP, equal draw a card, more lose 1 HP. If you discarded exactly X cards, draw a card.",
				canyun: "Once per play phase: same as [Clear Strings], but you cannot choose characters already chosen by [Lingering Melody] this turn.",
				juexiang: "When you die, you may let another character gain [Lingering Melody]; randomly discard a club card on the field, then they gain [Swan Song].",
				fumian: "Preparation phase: choose one — draw 1 more card in your draw phase this turn; or your red [Slash] may target 1 more player this turn. If different from your choice last turn, the number becomes 2.",
				daiyan: "End phase: you may let another character gain the first hearts basic card in the deck. If they are the same character you chose last turn, they lose 1 HP.",
				jianzheng: "After a character targets you with a [Slash], you may put a hand card on deck top to cancel all its targets; if that [Slash] is red, you become its target.",
				zhuandui: "After your [Slash] targets a character, or after you become the target of a [Slash], you may pindian with the other side: if you win, the [Slash] cannot be responded to (as source) or is nullified against you (as target).",
				tianbian: "When you pindian, you may use the deck top card instead; your hearts pindian cards count as rank K.",
				funan: "After another character responds to your card by using or playing a card, you may swap the two cards (they cannot use or play the gained card this turn). After [Admonishing Lesson] resets, you only take their card without giving yours.",
				xinjiexun: "End phase: you may let another character draw cards equal to the number of diamond cards on the field, then they discard X cards (X = times this skill was used before). If they discard all their cards this way, the count resets and [Repeated Challenge] upgrades.",
				wengua: "Once per play phase, another character may give you a card; you put it on deck top or bottom, then you and they each draw a card from the other end.",
				fuzhu: "At a male character's end phase, if the remaining deck is no more than 10x your HP, you may use all [Slash] in the deck on them in turn (up to the player count, ignoring distance), then shuffle the rest back.",
				shouxi: "After you become the target of a [Slash], you may declare a basic or trick card name not yet declared: the source must discard a card of that name, otherwise the [Slash] is nullified; if they discard, they take one of your cards.",
				huimin: "End phase: you may draw X cards (X = number of characters whose hand size is below their HP), then show that many hand cards; starting from one such character you choose, each of them takes one in seat order.",
				bizhuan: "After you use a card, or after you become the target of a [Slash] or normal trick card, you may draw a card and put it as a Book (up to 4). Your hand limit increases by the number of Books.",
				tongbo: "After your draw phase, you may swap up to 4 hand cards with as many Books. If your Books cover all four suits, give all Books to other characters in turn.",
				re_jianxiong: "After you take 1 damage, you may take the card that dealt the damage and draw a card.",
				re_guicai: "Before a judgment card takes effect, you may play a card to replace it.",
				re_ganglie: "After you take 1 damage, you may judge: red, you deal 1 damage to the source; black, you discard a card from the source.",
				re_tuxi: "Draw phase: you may instead take one hand card each from up to two other players.",
				re_luoyi: "Draw phase: you may instead reveal the top 3 cards and take the basic cards, weapons and [Duel]s among them; until your next turn begins, your [Slash] and [Duel] deal +1 damage.",
				re_luoshen: "Start of turn: you may judge repeatedly — on black, take the card and judge again; stop on red. Cards gained this way do not count toward your hand limit this turn.",
				re_rende: "Play phase: you may give any number of hand cards to another player (each player at most once per phase); the first time your total given this phase reaches two, you may use a basic card.",
				re_wusheng: "You may use a red card as a [Slash]; your diamond [Slash] has no distance limit.",
				re_yijue: "Once per play phase: discard a card and have another player with hand cards reveal one — if black, they cannot use or play hand cards, their non-locked skills fail this turn, and your heart [Slash] deals +1 damage to them; if red, you may take it and may let them recover 1 HP.",
				re_paoxiao: "Locked. Your [Slash] has no use limit. When your [Slash] is canceled by a [Dodge], gain a Roar mark; when your [Slash] deals damage, remove all Roar marks and the damage is +X (X = marks removed). Remove all Roar marks at end of turn.",
				re_tishen: "Limited. Start of turn: you may restore your HP to its maximum, then draw that many cards.",
				re_guanxing: "Start of turn: look at the top five cards (three if fewer than four players are alive); put any of them on the deck bottom and the rest back on top in their original order; if all went to the bottom, you may activate this again at end phase.",
				re_longdan: "You may use a [Slash] as a [Dodge], a [Dodge] as a [Slash], an [Analeptic] as a [Peach], and a [Peach] as an [Analeptic].",
				re_yajiao: "When you use or play a hand card outside your turn, reveal the deck top: if its category matches, you may give it to a player; otherwise discard it, then you may discard a card from the area of a player whose attack range includes you.",
				re_tieji: "When your [Slash] targets a player, you may seal their non-locked skills this turn and judge: unless they give you a card of the same suit as the judgment, they cannot dodge this [Slash] and it deals +1 damage.",
				re_qicai: "Locked. Your trick cards have no distance limit; others cannot discard armor from your equipment area.",
				re_zhiheng: "Once per play phase: discard any number of hand cards and draw the same number; if you discarded all your hand cards this way, draw one extra.",
				re_jiuyuan: "Lord skill. When another Wu player would recover HP during their turn, if their HP is no less than yours, they may instead let you recover 1 HP, then they draw a card.",
				re_qixi: "You may use a black card as [Dismantlement].",
				re_qinxue: "Awakening. Start or end phase: if your hand size minus HP is at least two, lose 1 max HP, recover 1 HP or draw 2 cards, then gain \"Read Mind\".",
				re_jieyin: "Once per play phase: choose a male player and discard a hand card, or move an equipment from your equipment area into their equipment area (the slot must be empty); then the side with more HP draws a card and the side with less HP recovers 1 HP (on a tie, both draw a card).",
				re_jijiu: "Outside your turn, you may use a red card as a [Peach].",
				re_liyu: "After your [Slash] damages another player, you may take a card from their area: if it is not equipment, they draw a card; if it is equipment, you use a [Duel] on another player.",
				re_lijian: "Once per play phase: discard a card and choose two male players; the first duels the second (the [Duel] cannot be nullified).",
				re_biyue: "End phase: draw a card; if you have no hand cards, draw 2 cards instead.",
				re_shensu: "Choose up to three: skip your judge and draw phases; skip your play phase and discard an equipment; skip your discard phase and flip over. For each choice, you use a range-unlimited [Slash] on another player.",
				re_jushou: "End phase: you may flip over and draw 4 cards, then discard a hand card; if the discarded card is equipment, use it instead.",
				re_jiewei: "You may use cards in your equipment area as [Nullification]; when your general card flips face-up, you may discard a card, then move a field card.",
				re_liegong: "Your [Slash] may target players within a distance no greater than its rank. When your [Slash] targets a player: if their hand size is no greater than yours, it cannot be dodged; if their HP is no less than yours, it deals +1 damage.",
				re_kuanggu: "After you deal 1 damage to a player within distance 1, you may recover 1 HP or draw a card.",
				re_tianxiang: "When you take damage, you may discard a heart card and choose another player, then choose one: redirect the damage to them, then they draw X cards (X = their lost HP); or they lose 1 HP and take your discarded card.",
				re_hongyan: "Locked. Your spade cards count as hearts; if you have a heart card in your equipment area, your hand limit equals your max HP.",
				re_leiji: "When you use or play a [Dodge], you may judge: spade, you may deal 2 thunder damage to a player; club, you recover 1 HP and may deal 1 thunder damage to a player.",
				re_guidao: "Before a judgment card takes effect, you may play a black hand card to replace it and take the original; if your played card is a spade 2-9, draw a card.",
				re_huangtian: "Lord skill. Once per play phase, another Qun player may give you a [Dodge] or a spade hand card.",
				re_qiangxi: "Twice per play phase: discard a weapon or take 1 sourceless damage, then deal 1 damage to another player.",
				re_jieming: "After you take 1 damage, you may have a player draw X cards; if their hand size then exceeds X, they discard down to X (X = their max HP, at most five).",
				re_lianhuan: "You may use a club card as [Iron Chain] or recast it.",
				re_niepan: "Limited. When dying: you may discard all cards in your area, flip your general card face-up, draw 3 cards and heal to 3 HP, then gain one of \"Eight Formations\", \"Fire Attack\" or \"See Through\".",
				re_huoji: "You may use a red card as [Fire Attack]; when you use [Fire Attack], the target reveals a random hand card and you may discard a hand card of the same color to deal 1 fire damage to them.",
				re_kanpo: "You may use a black card as [Nullification]; your [Nullification] cannot be responded to.",
				re_luanji: "Play phase: you may use two hand cards of the same suit as [Archery Attack]; after your [Archery Attack] names its targets, you may remove one target.",
				re_xueyi: "Lord skill. Locked. At game start you gain X Bloodline marks (X = twice the number of Qun players); once per play phase you may remove a mark to draw a card; your hand limit is +Y (Y = your marks).",
				re_shuangxiong: "Draw phase: you may instead discard a card; this turn you may use a hand card of the opposite color as [Duel]. End phase: take from the discard pile the cards that damaged you this turn.",
				re_duanliang: "You may use a black basic or black equip card as [Supply Shortage]; your [Supply Shortage] has a distance limit of 2.",
				re_xingshang: "When another player dies, you may choose one: take all of their cards; or recover 1 HP.",
				re_fangzhu: "After you take damage, you may have another player choose one: draw X cards and flip over; or discard X cards and lose 1 HP (X = your lost HP).",
				re_zaiqi: "End phase: you may have up to X players each choose one: draw a card; or let you recover 1 HP (X = red cards that entered the discard pile this turn).",
				re_jiuchi: "You may use a spade hand card as [Analeptic]; your [Analeptic] has no use limit; after your [Slash] boosted by [Analeptic] deals damage during your turn, your Collapse has no effect this turn.",
				re_baonue: "Lord skill. After another Qun player deals damage, you may judge: on a spade, you recover 1 HP and take the judgment card.",
				re_wansha: "Locked. During your turn, only a dying player may use [Peach] or [Analeptic]; when a player enters dying during your turn, other players' non-locked skills fail until the dying resolves.",
				re_luanwu: "Limited. Play phase: every other player in turn either uses a [Slash] on a nearest player, or loses 1 HP; afterwards you may use a range-unlimited [Slash].",
				re_weimu: "Locked. You cannot be targeted by black trick cards; when you take damage during your turn, prevent it and draw X cards (X = twice the damage).",
				re_qiaobian: "You may discard a hand card to skip one of your phases (judge/draw/play/discard). If you skip draw phase this way, you may take one hand card each from up to two other players; if you skip play phase, you may move a field card to another player's corresponding area.",
				re_tuntian: "After you lose cards outside your turn, or lose a [Slash] to discard during your turn, you may judge: if not hearts, place the judgment card on your general as a Field. Your distance to other players is reduced by the number of Fields.",
				re_zaoxian: "Awakening. Start phase: if you have at least 3 Fields, lose 1 max HP, gain \"Swift Raid\", and take an extra turn after this turn.",
				re_tiaoxin: "Once per play phase: choose a player whose attack range includes you — they either use a [Slash] on you, or you discard one of their cards; if their [Slash] did not damage you, Provoke becomes twice per phase this turn.",
				re_zhiji: "Awakening. Start or end phase: if you have no hand cards, lose 1 max HP, recover 1 HP or draw 2 cards, then gain \"Stargazing\".",
				re_fangquan: "Play phase: you may skip this phase; if you do, at the start of your discard phase you may discard a hand card to give another player an extra turn.",
				re_ruoyu: "Lord skill, awakening. Start phase: if your HP is the lowest, gain 1 max HP and heal to 3 HP, then gain \"Longing for Shu\" and \"Call to Arms\".",
				re_jiang: "When your [Duel] or red [Slash] names a target, or you become the target of one, you may draw a card; the first time each turn a [Duel] or red [Slash] enters the discard pile by being discarded, you may lose 1 HP to take it.",
				re_hunzi: "Awakening. Start phase: if your HP is 1, lose 1 max HP and gain \"Heroic Poise\" and \"Heroic Soul\"; at end phase this turn, draw 2 cards or recover 1 HP.",
				re_zhiba: "Lord skill. Once per play phase, another Wu player may pindian with you (you may refuse); once per your play phase, you may pindian with a Wu player — if they don't win, you take both pindian cards.",
				re_zhijian: "Play phase: you may place an equipment from your hand into another player's equipment area (may replace), then draw a card.",
				re_guzheng: "Once per phase: after at least two of another player's cards enter the discard pile by being discarded, you may let them take one of them, then you take the rest.",
				re_beige: "After a player takes damage from a [Slash], you may let them judge, then discard a card: hearts, they recover 1 HP; diamonds, they draw 2 cards; spades, the source flips over; clubs, the source discards 2 cards. If your discarded card matches the judgment's rank, you take your discarded card back; if the suit matches, you take the judgment card."
			}
		}
	}
};
//#endregion
export { _C as default };
