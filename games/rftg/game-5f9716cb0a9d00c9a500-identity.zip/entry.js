import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, createContext as r, useContext as i, useEffect as a, useId as o, useMemo as s, useRef as c, useState as l } from "react";
import { createPortal as u } from "react-dom";
import { useFxAnchor as d } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as f } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as p, useT as m } from "@bgparty/sdk/i18n";
import { PhaseBanner as h } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as g, seatName as _ } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { Fragment as v, jsx as y, jsxs as b } from "react/jsx-runtime";
import { IconBack as x, IconBot as te, IconClose as ne, IconExpand as re, IconLog as S } from "@bgparty/sdk/icons";
import { Floater as C, FlySprite as w, PulseBox as T } from "@bgparty/sdk/fx/primitives";
import { Confetti as E } from "@bgparty/sdk/ui/confetti";
import { PLAYER_COLORS as D } from "@bgparty/sdk/player-colors";
//#region src/games/rftg/data.ts
var O = [
	{
		id: "old-earth",
		en: "Old Earth",
		type: "world",
		cost: 3,
		vp: 2,
		start: "blue",
		powers: [{
			phase: 4,
			codes: ["TRADE_ANY"],
			value: 1,
			times: 0
		}, {
			phase: 4,
			codes: ["CONSUME_ANY", "GET_VP"],
			value: 1,
			times: 2
		}],
		count: 1
	},
	{
		id: "epsilon-eridani",
		en: "Epsilon Eridani",
		type: "world",
		cost: 2,
		vp: 1,
		start: "red",
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 1,
			times: 0
		}, {
			phase: 4,
			codes: [
				"CONSUME_ANY",
				"GET_CARD",
				"GET_VP"
			],
			value: 1,
			times: 1
		}],
		count: 1
	},
	{
		id: "alpha-centauri",
		en: "Alpha Centauri",
		type: "world",
		cost: 2,
		vp: 0,
		good: "RARE",
		start: "blue",
		windfall: !0,
		powers: [{
			phase: 3,
			codes: ["REDUCE", "RARE"],
			value: 1,
			times: 0
		}, {
			phase: 3,
			codes: ["EXTRA_MILITARY", "RARE"],
			value: 1,
			times: 0
		}],
		count: 1
	},
	{
		id: "new-sparta",
		en: "New Sparta",
		type: "world",
		cost: 2,
		vp: 1,
		start: "red",
		military: !0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 2,
			times: 0
		}],
		count: 1
	},
	{
		id: "earth-s-lost-colony",
		en: "Earth's Lost Colony",
		type: "world",
		cost: 2,
		vp: 1,
		good: "NOVELTY",
		start: "blue",
		powers: [{
			phase: 4,
			codes: ["CONSUME_ANY", "GET_VP"],
			value: 1,
			times: 1
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "rebel-fuel-cache",
		en: "Rebel Fuel Cache",
		type: "world",
		cost: 1,
		vp: 1,
		good: "RARE",
		military: !0,
		windfall: !0,
		rebel: !0,
		powers: [],
		count: 1
	},
	{
		id: "public-works",
		en: "Public Works",
		type: "dev",
		cost: 1,
		vp: 1,
		powers: [{
			phase: 2,
			codes: ["DRAW_AFTER"],
			value: 1,
			times: 0
		}, {
			phase: 4,
			codes: ["CONSUME_ANY", "GET_VP"],
			value: 1,
			times: 1
		}],
		count: 2
	},
	{
		id: "gem-world",
		en: "Gem World",
		type: "world",
		cost: 2,
		vp: 1,
		good: "NOVELTY",
		powers: [{
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}, {
			phase: 5,
			codes: ["DRAW_IF"],
			value: 1,
			times: 0
		}],
		count: 1
	},
	{
		id: "colony-ship",
		en: "Colony Ship",
		type: "dev",
		cost: 2,
		vp: 1,
		powers: [{
			phase: 3,
			codes: ["DISCARD", "REDUCE_ZERO"],
			value: 0,
			times: 0
		}],
		count: 2
	},
	{
		id: "comet-zone",
		en: "Comet Zone",
		type: "world",
		cost: 3,
		vp: 2,
		good: "RARE",
		powers: [{
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}, {
			phase: 5,
			codes: ["DRAW_IF"],
			value: 1,
			times: 0
		}],
		count: 1
	},
	{
		id: "expedition-force",
		en: "Expedition Force",
		type: "dev",
		cost: 1,
		vp: 1,
		powers: [{
			phase: 1,
			codes: ["DRAW"],
			value: 1,
			times: 0
		}, {
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 1,
			times: 0
		}],
		count: 2
	},
	{
		id: "mining-robots",
		en: "Mining Robots",
		type: "dev",
		cost: 2,
		vp: 1,
		powers: [{
			phase: 3,
			codes: ["REDUCE", "RARE"],
			value: 1,
			times: 0
		}, {
			phase: 5,
			codes: ["WINDFALL_RARE"],
			value: 0,
			times: 0
		}],
		count: 2
	},
	{
		id: "rebel-miners",
		en: "Rebel Miners",
		type: "world",
		cost: 2,
		vp: 1,
		good: "RARE",
		military: !0,
		rebel: !0,
		powers: [{
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "export-duties",
		en: "Export Duties",
		type: "dev",
		cost: 1,
		vp: 1,
		powers: [{
			phase: 4,
			codes: ["TRADE_ANY"],
			value: 1,
			times: 0
		}],
		count: 2
	},
	{
		id: "former-penal-colony",
		en: "Former Penal Colony",
		type: "world",
		cost: 2,
		vp: 1,
		good: "NOVELTY",
		military: !0,
		windfall: !0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 1,
			times: 0
		}],
		count: 1
	},
	{
		id: "malevolent-lifeforms",
		en: "Malevolent Lifeforms",
		type: "world",
		cost: 4,
		vp: 2,
		good: "GENE",
		military: !0,
		powers: [{
			phase: 1,
			codes: ["DRAW"],
			value: 1,
			times: 0
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "new-military-tactics",
		en: "New Military Tactics",
		type: "dev",
		cost: 1,
		vp: 1,
		powers: [{
			phase: 3,
			codes: ["DISCARD", "EXTRA_MILITARY"],
			value: 3,
			times: 0
		}],
		count: 2
	},
	{
		id: "space-marines",
		en: "Space Marines",
		type: "dev",
		cost: 2,
		vp: 1,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 2,
			times: 0
		}],
		count: 2
	},
	{
		id: "contact-specialist",
		en: "Contact Specialist",
		type: "dev",
		cost: 1,
		vp: 1,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: -1,
			times: 0
		}, {
			phase: 3,
			codes: ["PAY_MILITARY"],
			value: 1,
			times: 0
		}],
		count: 2
	},
	{
		id: "avian-uplift-race",
		en: "Avian Uplift Race",
		type: "world",
		cost: 2,
		vp: 2,
		good: "GENE",
		military: !0,
		windfall: !0,
		powers: [],
		count: 1
	},
	{
		id: "spice-world",
		en: "Spice World",
		type: "world",
		cost: 2,
		vp: 1,
		good: "NOVELTY",
		powers: [{
			phase: 4,
			codes: ["TRADE_NOVELTY"],
			value: 2,
			times: 0
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "lost-species-ark-world",
		en: "Lost Species Ark World",
		type: "world",
		cost: 5,
		vp: 3,
		good: "GENE",
		powers: [{
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}, {
			phase: 5,
			codes: ["DRAW_IF"],
			value: 2,
			times: 0
		}],
		count: 1
	},
	{
		id: "new-vinland",
		en: "New Vinland",
		type: "world",
		cost: 2,
		vp: 1,
		good: "NOVELTY",
		powers: [{
			phase: 4,
			codes: ["CONSUME_ANY", "GET_2_CARD"],
			value: 1,
			times: 1
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "artist-colony",
		en: "Artist Colony",
		type: "world",
		cost: 1,
		vp: 1,
		good: "NOVELTY",
		powers: [{
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "alien-robotic-factory",
		en: "Alien Robotic Factory",
		type: "world",
		cost: 6,
		vp: 5,
		good: "ALIEN",
		alien: !0,
		powers: [{
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "plague-world",
		en: "Plague World",
		type: "world",
		cost: 3,
		vp: 0,
		good: "GENE",
		powers: [{
			phase: 4,
			codes: [
				"CONSUME_GENE",
				"GET_CARD",
				"GET_VP"
			],
			value: 1,
			times: 1
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "distant-world",
		en: "Distant World",
		type: "world",
		cost: 4,
		vp: 2,
		good: "GENE",
		powers: [{
			phase: 4,
			codes: ["TRADE_NOVELTY"],
			value: 3,
			times: 0
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "rebel-outpost",
		en: "Rebel Outpost",
		type: "world",
		cost: 5,
		vp: 5,
		military: !0,
		rebel: !0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 1,
			times: 0
		}],
		count: 1
	},
	{
		id: "rebel-warrior-race",
		en: "Rebel Warrior Race",
		type: "world",
		cost: 3,
		vp: 2,
		good: "GENE",
		military: !0,
		windfall: !0,
		rebel: !0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 1,
			times: 0
		}],
		count: 1
	},
	{
		id: "rebel-underground",
		en: "Rebel Underground",
		type: "world",
		cost: 3,
		vp: 4,
		military: !0,
		rebel: !0,
		powers: [{
			phase: 5,
			codes: ["DRAW"],
			value: 1,
			times: 0
		}],
		count: 1
	},
	{
		id: "new-survivalists",
		en: "New Survivalists",
		type: "world",
		cost: 1,
		vp: 1,
		good: "NOVELTY",
		military: !0,
		powers: [{
			phase: 4,
			codes: ["CONSUME_NOVELTY", "GET_CARD"],
			value: 1,
			times: 1
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "outlaw-world",
		en: "Outlaw World",
		type: "world",
		cost: 1,
		vp: 1,
		military: !0,
		powers: [{
			phase: 4,
			codes: [
				"CONSUME_ANY",
				"GET_CARD",
				"GET_VP"
			],
			value: 1,
			times: 1
		}],
		count: 1
	},
	{
		id: "lost-alien-battle-fleet",
		en: "Lost Alien Battle Fleet",
		type: "world",
		cost: 6,
		vp: 4,
		good: "ALIEN",
		military: !0,
		alien: !0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 3,
			times: 0
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "diversified-economy",
		en: "Diversified Economy",
		type: "dev",
		cost: 4,
		vp: 2,
		powers: [{
			phase: 4,
			codes: ["CONSUME_3_DIFF", "GET_VP"],
			value: 3,
			times: 1
		}, {
			phase: 5,
			codes: ["DRAW_DIFFERENT"],
			value: 1,
			times: 0
		}],
		count: 2
	},
	{
		id: "consumer-markets",
		en: "Consumer Markets",
		type: "dev",
		cost: 5,
		vp: 3,
		powers: [{
			phase: 4,
			codes: ["CONSUME_NOVELTY", "GET_VP"],
			value: 1,
			times: 3
		}, {
			phase: 5,
			codes: ["DRAW_EACH_NOVELTY"],
			value: 1,
			times: 0
		}],
		count: 2
	},
	{
		id: "mining-conglomerate",
		en: "Mining Conglomerate",
		type: "dev",
		cost: 3,
		vp: 2,
		powers: [
			{
				phase: 4,
				codes: ["TRADE_RARE"],
				value: 1,
				times: 0
			},
			{
				phase: 4,
				codes: ["CONSUME_RARE", "GET_VP"],
				value: 1,
				times: 2
			},
			{
				phase: 5,
				codes: ["DRAW_MOST_RARE"],
				value: 2,
				times: 0
			}
		],
		count: 2
	},
	{
		id: "research-labs",
		en: "Research Labs",
		type: "dev",
		cost: 4,
		vp: 2,
		powers: [
			{
				phase: 1,
				codes: ["KEEP"],
				value: 1,
				times: 0
			},
			{
				phase: 4,
				codes: ["CONSUME_GENE", "GET_VP"],
				value: 1,
				times: 1
			},
			{
				phase: 5,
				codes: ["DRAW_EACH_ALIEN"],
				value: 1,
				times: 0
			}
		],
		count: 2
	},
	{
		id: "deficit-spending",
		en: "Deficit Spending",
		type: "dev",
		cost: 2,
		vp: 1,
		powers: [{
			phase: 4,
			codes: ["DISCARD_HAND", "GET_VP"],
			value: 1,
			times: 2
		}],
		count: 2
	},
	{
		id: "investment-credits",
		en: "Investment Credits",
		type: "dev",
		cost: 1,
		vp: 1,
		powers: [{
			phase: 2,
			codes: ["REDUCE"],
			value: 1,
			times: 0
		}],
		count: 2
	},
	{
		id: "pan-galactic-league",
		en: "Pan-Galactic League",
		type: "dev",
		cost: 6,
		vp: 0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: -1,
			times: 0
		}, {
			phase: 5,
			codes: ["DRAW_WORLD_GENE"],
			value: 1,
			times: 0
		}],
		vpBonus: [
			{
				vp: 2,
				type: "GENE_PRODUCTION"
			},
			{
				vp: 2,
				type: "GENE_WINDFALL"
			},
			{
				vp: 1,
				type: "MILITARY"
			},
			{
				vp: 3,
				type: "NAME",
				name: "contact-specialist"
			}
		],
		count: 1
	},
	{
		id: "mining-league",
		en: "Mining League",
		type: "dev",
		cost: 6,
		vp: 0,
		powers: [{
			phase: 4,
			codes: [
				"CONSUME_RARE",
				"CONSUME_TWO",
				"GET_VP"
			],
			value: 3,
			times: 1
		}, {
			phase: 5,
			codes: ["WINDFALL_RARE"],
			value: 0,
			times: 0
		}],
		vpBonus: [
			{
				vp: 2,
				type: "RARE_PRODUCTION"
			},
			{
				vp: 1,
				type: "RARE_WINDFALL"
			},
			{
				vp: 2,
				type: "NAME",
				name: "mining-robots"
			},
			{
				vp: 2,
				type: "NAME",
				name: "mining-conglomerate"
			}
		],
		count: 1
	},
	{
		id: "free-trade-association",
		en: "Free Trade Association",
		type: "dev",
		cost: 6,
		vp: 0,
		powers: [{
			phase: 4,
			codes: [
				"CONSUME_NOVELTY",
				"GET_CARD",
				"GET_VP"
			],
			value: 1,
			times: 3
		}, {
			phase: 5,
			codes: ["WINDFALL_NOVELTY"],
			value: 0,
			times: 0
		}],
		vpBonus: [
			{
				vp: 2,
				type: "NOVELTY_PRODUCTION"
			},
			{
				vp: 1,
				type: "NOVELTY_WINDFALL"
			},
			{
				vp: 2,
				type: "NAME",
				name: "consumer-markets"
			},
			{
				vp: 2,
				type: "NAME",
				name: "expanding-colony"
			}
		],
		count: 1
	},
	{
		id: "alien-tech-institute",
		en: "Alien Tech Institute",
		type: "dev",
		cost: 6,
		vp: 0,
		alien: !0,
		powers: [{
			phase: 3,
			codes: ["REDUCE", "ALIEN"],
			value: 2,
			times: 0
		}, {
			phase: 3,
			codes: ["EXTRA_MILITARY", "ALIEN"],
			value: 2,
			times: 0
		}],
		vpBonus: [
			{
				vp: 3,
				type: "ALIEN_PRODUCTION"
			},
			{
				vp: 2,
				type: "ALIEN_WINDFALL"
			},
			{
				vp: 2,
				type: "ALIEN_FLAG"
			}
		],
		count: 1
	},
	{
		id: "galactic-survey-seti",
		en: "Galactic Survey: SETI",
		type: "dev",
		cost: 6,
		vp: 0,
		powers: [{
			phase: 1,
			codes: ["DRAW"],
			value: 2,
			times: 0
		}],
		vpBonus: [
			{
				vp: 1,
				type: "DEVEL_EXPLORE"
			},
			{
				vp: 2,
				type: "WORLD_EXPLORE"
			},
			{
				vp: 1,
				type: "WORLD"
			}
		],
		count: 1
	},
	{
		id: "galactic-federation",
		en: "Galactic Federation",
		type: "dev",
		cost: 6,
		vp: 0,
		powers: [{
			phase: 2,
			codes: ["REDUCE"],
			value: 2,
			times: 0
		}],
		vpBonus: [{
			vp: 2,
			type: "SIX_DEVEL"
		}, {
			vp: 1,
			type: "DEVEL"
		}],
		count: 1
	},
	{
		id: "refugee-world",
		en: "Refugee World",
		type: "world",
		cost: 0,
		vp: 1,
		good: "NOVELTY",
		windfall: !0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: -1,
			times: 0
		}],
		count: 1
	},
	{
		id: "empath-world",
		en: "Empath World",
		type: "world",
		cost: 1,
		vp: 1,
		good: "GENE",
		windfall: !0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: -1,
			times: 0
		}],
		count: 1
	},
	{
		id: "galactic-resort",
		en: "Galactic Resort",
		type: "world",
		cost: 3,
		vp: 2,
		good: "NOVELTY",
		windfall: !0,
		powers: [{
			phase: 4,
			codes: [
				"CONSUME_ANY",
				"GET_CARD",
				"GET_VP"
			],
			value: 1,
			times: 1
		}],
		count: 1
	},
	{
		id: "pre-sentient-race",
		en: "Pre-Sentient Race",
		type: "world",
		cost: 2,
		vp: 1,
		good: "GENE",
		windfall: !0,
		powers: [],
		count: 1
	},
	{
		id: "deserted-alien-outpost",
		en: "Deserted Alien Outpost",
		type: "world",
		cost: 4,
		vp: 3,
		good: "ALIEN",
		windfall: !0,
		alien: !0,
		powers: [],
		count: 1
	},
	{
		id: "deserted-alien-colony",
		en: "Deserted Alien Colony",
		type: "world",
		cost: 5,
		vp: 4,
		good: "ALIEN",
		windfall: !0,
		alien: !0,
		powers: [],
		count: 1
	},
	{
		id: "galactic-engineers",
		en: "Galactic Engineers",
		type: "world",
		cost: 2,
		vp: 1,
		powers: [{
			phase: 4,
			codes: ["TRADE_ANY"],
			value: 1,
			times: 0
		}, {
			phase: 5,
			codes: ["WINDFALL_ANY"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "black-market-trading-world",
		en: "Black Market Trading World",
		type: "world",
		cost: 3,
		vp: 2,
		powers: [{
			phase: 4,
			codes: ["TRADE_ACTION", "TRADE_NO_BONUS"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "merchant-world",
		en: "Merchant World",
		type: "world",
		cost: 4,
		vp: 2,
		powers: [{
			phase: 4,
			codes: ["TRADE_ANY"],
			value: 2,
			times: 0
		}, {
			phase: 4,
			codes: ["DISCARD_HAND", "GET_VP"],
			value: 1,
			times: 2
		}],
		count: 1
	},
	{
		id: "tourist-world",
		en: "Tourist World",
		type: "world",
		cost: 4,
		vp: 2,
		powers: [{
			phase: 4,
			codes: [
				"CONSUME_ANY",
				"CONSUME_TWO",
				"GET_VP"
			],
			value: 3,
			times: 1
		}],
		count: 1
	},
	{
		id: "galactic-trendsetters",
		en: "Galactic Trendsetters",
		type: "world",
		cost: 5,
		vp: 3,
		powers: [{
			phase: 4,
			codes: ["CONSUME_ANY", "GET_VP"],
			value: 2,
			times: 1
		}],
		count: 1
	},
	{
		id: "alien-rosetta-stone-world",
		en: "Alien Rosetta Stone World",
		type: "world",
		cost: 3,
		vp: 3,
		alien: !0,
		powers: [
			{
				phase: 3,
				codes: ["REDUCE", "ALIEN"],
				value: 2,
				times: 0
			},
			{
				phase: 3,
				codes: ["EXTRA_MILITARY", "ALIEN"],
				value: 2,
				times: 0
			},
			{
				phase: 5,
				codes: ["WINDFALL_ALIEN"],
				value: 0,
				times: 0
			}
		],
		count: 1
	},
	{
		id: "star-nomad-lair",
		en: "Star Nomad Lair",
		type: "world",
		cost: 1,
		vp: 1,
		good: "NOVELTY",
		military: !0,
		windfall: !0,
		powers: [{
			phase: 1,
			codes: ["DRAW"],
			value: 1,
			times: 0
		}, {
			phase: 4,
			codes: ["TRADE_THIS"],
			value: 1,
			times: 0
		}],
		count: 1
	},
	{
		id: "the-last-of-the-uplift-gnarssh",
		en: "The Last of the Uplift Gnarssh",
		type: "world",
		cost: 1,
		vp: 0,
		good: "GENE",
		military: !0,
		windfall: !0,
		powers: [],
		count: 1
	},
	{
		id: "alien-robot-sentry",
		en: "Alien Robot Sentry",
		type: "world",
		cost: 2,
		vp: 2,
		good: "ALIEN",
		military: !0,
		windfall: !0,
		alien: !0,
		powers: [],
		count: 1
	},
	{
		id: "pirate-world",
		en: "Pirate World",
		type: "world",
		cost: 3,
		vp: 2,
		good: "NOVELTY",
		military: !0,
		windfall: !0,
		powers: [{
			phase: 4,
			codes: ["TRADE_THIS"],
			value: 3,
			times: 0
		}],
		count: 1
	},
	{
		id: "reptilian-uplift-race",
		en: "Reptilian Uplift Race",
		type: "world",
		cost: 2,
		vp: 2,
		good: "GENE",
		military: !0,
		windfall: !0,
		powers: [],
		count: 1
	},
	{
		id: "lost-alien-warship",
		en: "Lost Alien Warship",
		type: "world",
		cost: 5,
		vp: 3,
		good: "ALIEN",
		military: !0,
		windfall: !0,
		alien: !0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 2,
			times: 0
		}],
		count: 1
	},
	{
		id: "alien-robot-scout-ship",
		en: "Alien Robot Scout Ship",
		type: "world",
		cost: 4,
		vp: 2,
		good: "ALIEN",
		military: !0,
		windfall: !0,
		alien: !0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 1,
			times: 0
		}],
		count: 1
	},
	{
		id: "runaway-robots",
		en: "Runaway Robots",
		type: "world",
		cost: 1,
		vp: 1,
		good: "RARE",
		military: !0,
		windfall: !0,
		powers: [{
			phase: 5,
			codes: ["DRAW_IF"],
			value: 1,
			times: 0
		}],
		count: 1
	},
	{
		id: "interstellar-bank",
		en: "Interstellar Bank",
		type: "dev",
		cost: 2,
		vp: 1,
		powers: [{
			phase: 2,
			codes: ["DRAW"],
			value: 1,
			times: 0
		}],
		count: 2
	},
	{
		id: "terraforming-robots",
		en: "Terraforming Robots",
		type: "dev",
		cost: 3,
		vp: 2,
		powers: [{
			phase: 3,
			codes: ["DRAW_AFTER"],
			value: 1,
			times: 0
		}, {
			phase: 4,
			codes: [
				"CONSUME_RARE",
				"GET_CARD",
				"GET_VP"
			],
			value: 1,
			times: 1
		}],
		count: 2
	},
	{
		id: "drop-ships",
		en: "Drop Ships",
		type: "dev",
		cost: 4,
		vp: 2,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 3,
			times: 0
		}],
		count: 2
	},
	{
		id: "new-galactic-order",
		en: "New Galactic Order",
		type: "dev",
		cost: 6,
		vp: 0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 2,
			times: 0
		}],
		vpBonus: [{
			vp: 1,
			type: "TOTAL_MILITARY"
		}],
		count: 1
	},
	{
		id: "asteroid-belt",
		en: "Asteroid Belt",
		type: "world",
		cost: 2,
		vp: 1,
		good: "RARE",
		windfall: !0,
		powers: [],
		count: 1
	},
	{
		id: "merchant-guild",
		en: "Merchant Guild",
		type: "dev",
		cost: 6,
		vp: 0,
		powers: [{
			phase: 5,
			codes: ["DRAW"],
			value: 2,
			times: 0
		}],
		vpBonus: [
			{
				vp: 2,
				type: "NOVELTY_PRODUCTION"
			},
			{
				vp: 2,
				type: "RARE_PRODUCTION"
			},
			{
				vp: 2,
				type: "GENE_PRODUCTION"
			},
			{
				vp: 2,
				type: "ALIEN_PRODUCTION"
			}
		],
		count: 1
	},
	{
		id: "secluded-world",
		en: "Secluded World",
		type: "world",
		cost: 1,
		vp: 1,
		good: "NOVELTY",
		powers: [{
			phase: 4,
			codes: ["CONSUME_ANY", "GET_CARD"],
			value: 1,
			times: 1
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "imperium-armaments-world",
		en: "Imperium Armaments World",
		type: "world",
		cost: 4,
		vp: 2,
		good: "RARE",
		imperium: !0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 1,
			times: 0
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "terraformed-world",
		en: "Terraformed World",
		type: "world",
		cost: 5,
		vp: 5,
		powers: [{
			phase: 4,
			codes: ["CONSUME_ANY", "GET_VP"],
			value: 1,
			times: 1
		}],
		count: 1
	},
	{
		id: "replicant-robots",
		en: "Replicant Robots",
		type: "dev",
		cost: 4,
		vp: 2,
		powers: [{
			phase: 3,
			codes: ["REDUCE"],
			value: 2,
			times: 0
		}],
		count: 2
	},
	{
		id: "pilgrimage-world",
		en: "Pilgrimage World",
		type: "world",
		cost: 0,
		vp: 2,
		powers: [{
			phase: 4,
			codes: ["CONSUME_ALL", "GET_VP"],
			value: 1,
			times: 1
		}],
		count: 1
	},
	{
		id: "rebel-homeworld",
		en: "Rebel Homeworld",
		type: "world",
		cost: 7,
		vp: 7,
		military: !0,
		rebel: !0,
		powers: [],
		count: 1
	},
	{
		id: "new-economy",
		en: "New Economy",
		type: "dev",
		cost: 6,
		vp: 0,
		powers: [{
			phase: 4,
			codes: ["DRAW"],
			value: 1,
			times: 0
		}],
		vpBonus: [{
			vp: 2,
			type: "DEVEL_CONSUME"
		}, {
			vp: 1,
			type: "WORLD_CONSUME"
		}],
		count: 1
	},
	{
		id: "radioactive-world",
		en: "Radioactive World",
		type: "world",
		cost: 2,
		vp: 1,
		good: "RARE",
		windfall: !0,
		powers: [],
		count: 1
	},
	{
		id: "aquatic-uplift-race",
		en: "Aquatic Uplift Race",
		type: "world",
		cost: 2,
		vp: 2,
		good: "GENE",
		military: !0,
		windfall: !0,
		powers: [],
		count: 1
	},
	{
		id: "genetics-lab",
		en: "Genetics Lab",
		type: "dev",
		cost: 2,
		vp: 1,
		powers: [{
			phase: 4,
			codes: ["TRADE_GENE"],
			value: 1,
			times: 0
		}, {
			phase: 5,
			codes: ["WINDFALL_GENE"],
			value: 0,
			times: 0
		}],
		count: 2
	},
	{
		id: "bio-hazard-mining-world",
		en: "Bio-Hazard Mining World",
		type: "world",
		cost: 3,
		vp: 2,
		good: "RARE",
		powers: [{
			phase: 4,
			codes: ["TRADE_GENE"],
			value: 2,
			times: 0
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "deserted-alien-library",
		en: "Deserted Alien Library",
		type: "world",
		cost: 6,
		vp: 5,
		good: "ALIEN",
		windfall: !0,
		alien: !0,
		powers: [],
		count: 1
	},
	{
		id: "destroyed-world",
		en: "Destroyed World",
		type: "world",
		cost: 1,
		vp: 0,
		good: "RARE",
		windfall: !0,
		powers: [],
		count: 1
	},
	{
		id: "galactic-renaissance",
		en: "Galactic Renaissance",
		type: "dev",
		cost: 6,
		vp: 0,
		powers: [{
			phase: 1,
			codes: ["DRAW"],
			value: 2,
			times: 0
		}, {
			phase: 1,
			codes: ["KEEP"],
			value: 1,
			times: 0
		}],
		vpBonus: [
			{
				vp: 1,
				type: "THREE_VP"
			},
			{
				vp: 3,
				type: "NAME",
				name: "research-labs"
			},
			{
				vp: 3,
				type: "NAME",
				name: "galactic-trendsetters"
			},
			{
				vp: 3,
				type: "NAME",
				name: "artist-colony"
			}
		],
		count: 1
	},
	{
		id: "blaster-gem-mines",
		en: "Blaster Gem Mines",
		type: "world",
		cost: 3,
		vp: 2,
		good: "RARE",
		windfall: !0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY"],
			value: 1,
			times: 0
		}],
		count: 1
	},
	{
		id: "gambling-world",
		en: "Gambling World",
		type: "world",
		cost: 1,
		vp: 1,
		powers: [{
			phase: 4,
			codes: ["CONSUME_ANY", "GET_VP"],
			value: 1,
			times: 1
		}, {
			phase: 4,
			codes: ["DRAW_LUCKY"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "expanding-colony",
		en: "Expanding Colony",
		type: "world",
		cost: 1,
		vp: 1,
		powers: [{
			phase: 4,
			codes: ["CONSUME_ANY", "GET_VP"],
			value: 1,
			times: 1
		}, {
			phase: 5,
			codes: ["WINDFALL_NOVELTY"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "space-port",
		en: "Space Port",
		type: "world",
		cost: 2,
		vp: 1,
		good: "NOVELTY",
		powers: [{
			phase: 4,
			codes: ["TRADE_RARE"],
			value: 2,
			times: 0
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "prosperous-world",
		en: "Prosperous World",
		type: "world",
		cost: 3,
		vp: 2,
		good: "NOVELTY",
		powers: [{
			phase: 4,
			codes: ["CONSUME_ANY", "GET_VP"],
			value: 1,
			times: 1
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "new-earth",
		en: "New Earth",
		type: "world",
		cost: 5,
		vp: 3,
		good: "RARE",
		powers: [{
			phase: 4,
			codes: [
				"CONSUME_ANY",
				"GET_CARD",
				"GET_VP"
			],
			value: 1,
			times: 1
		}, {
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}],
		count: 1
	},
	{
		id: "rebel-base",
		en: "Rebel Base",
		type: "world",
		cost: 6,
		vp: 6,
		military: !0,
		rebel: !0,
		powers: [],
		count: 1
	},
	{
		id: "galactic-imperium",
		en: "Galactic Imperium",
		type: "dev",
		cost: 6,
		vp: 0,
		imperium: !0,
		powers: [{
			phase: 3,
			codes: ["EXTRA_MILITARY", "AGAINST_REBEL"],
			value: 4,
			times: 0
		}],
		vpBonus: [{
			vp: 2,
			type: "REBEL_MILITARY"
		}, {
			vp: 1,
			type: "MILITARY"
		}],
		count: 1
	},
	{
		id: "trade-league",
		en: "Trade League",
		type: "dev",
		cost: 6,
		vp: 0,
		powers: [{
			phase: 4,
			codes: ["TRADE_ANY"],
			value: 1,
			times: 0
		}, {
			phase: 4,
			codes: ["TRADE_ACTION"],
			value: 0,
			times: 0
		}],
		vpBonus: [{
			vp: 2,
			type: "DEVEL_TRADE"
		}, {
			vp: 1,
			type: "WORLD_TRADE"
		}],
		count: 1
	},
	{
		id: "mining-world",
		en: "Mining World",
		type: "world",
		cost: 3,
		vp: 2,
		good: "RARE",
		powers: [{
			phase: 5,
			codes: ["PRODUCE"],
			value: 0,
			times: 0
		}, {
			phase: 5,
			codes: ["DRAW_IF"],
			value: 1,
			times: 0
		}],
		count: 1
	}
], k = new Map(O.map((e) => [e.id, e]));
function A(e) {
	let t = k.get(e);
	if (!t) throw Error(`unknown card ${e}`);
	return t;
}
var ie = O.filter((e) => e.start), j = {
	id: "rftg",
	tier: "alpha",
	mechanics: ["engine-building", "hand-management"],
	interactionTags: [],
	nameKey: "games.rftg.name",
	descKey: "games.rftg.desc",
	rulesKey: "games.rftg.rules",
	icon: "🌌",
	iconImg: "games/rftg.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/rftg/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#7c3aed",
	releasedAt: "2026-09-17",
	search: {
		py: "yin he jing zhu",
		init: "yhjz"
	},
	hotseat: "cover"
}, ae = [
	"explore5",
	"explore11",
	"develop",
	"settle",
	"trade",
	"consume2x",
	"produce"
], M = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("openingDiscard"),
		drop: t.array(t.int()).length(2)
	}),
	t.object({
		type: t.literal("chooseAction"),
		action: t.enum(ae)
	}),
	t.object({
		type: t.literal("exploreKeep"),
		keep: t.array(t.int()).min(1).max(10)
	}),
	t.object({
		type: t.literal("selectDev"),
		inst: t.int().nullable()
	}),
	t.object({
		type: t.literal("selectWorld"),
		inst: t.int().nullable(),
		mode: t.enum([
			"pay",
			"conquer",
			"colonyShip"
		]).optional(),
		nmt: t.int().min(0).max(4).optional()
	}),
	t.object({
		type: t.literal("pay"),
		cards: t.array(t.int()).max(30)
	}),
	t.object({
		type: t.literal("tradeGood"),
		world: t.int()
	}),
	t.object({ type: t.literal("tradeSkip") }),
	t.object({
		type: t.literal("consume"),
		power: t.string(),
		goods: t.array(t.int()).max(10).optional(),
		handCards: t.array(t.int()).max(2).optional(),
		lucky: t.int().min(1).max(7).optional()
	}),
	t.object({ type: t.literal("consumeAuto") }),
	t.object({ type: t.literal("consumeDone") }),
	t.object({
		type: t.literal("producePick"),
		world: t.int()
	}),
	t.object({
		type: t.literal("discardDown"),
		drop: t.array(t.int()).min(1).max(30)
	})
]), N = t.string(), oe = t.enum(ae), se = t.object({
	inst: t.int(),
	def: t.string(),
	hasGood: t.boolean(),
	activeAfter: t.int()
}), P = t.object({
	inst: t.int(),
	def: t.string(),
	mode: t.enum([
		"pay",
		"conquer",
		"colonyShip"
	]).nullable(),
	cost: t.int().nullable()
}), F = t.object({
	phase: t.enum([
		"opening",
		"select",
		"explore",
		"develop",
		"settle",
		"consume",
		"produce",
		"discard",
		"done"
	]),
	round: t.int().min(1),
	phaseCounter: t.int(),
	vpPool: t.int(),
	deckCount: t.int().nonnegative(),
	discardCount: t.int().nonnegative(),
	players: t.array(t.object({
		rid: N,
		handCount: t.int().nonnegative(),
		vp: t.int().nonnegative(),
		tableau: t.array(se)
	})),
	locked: t.array(N),
	revealed: t.record(N, oe).nullable(),
	waiting: t.array(N),
	placements: t.record(N, P.nullable()).nullable(),
	consumeMeta: t.object({
		traders: t.array(N),
		x2: t.array(N)
	}).nullable(),
	finalScores: t.record(N, t.object({
		cards: t.int(),
		chips: t.int(),
		six: t.int(),
		total: t.int()
	})).nullable()
}), ce = t.object({
	inst: t.int(),
	def: t.string()
}), le = t.object({
	mode: t.enum([
		"pay",
		"conquer",
		"colonyShip"
	]),
	cost: t.int().nonnegative(),
	nmt: t.int().nonnegative()
}), ue = t.object({
	id: t.string(),
	def: t.string(),
	usable: t.boolean()
}), de = t.object({
	hand: t.array(ce),
	explorePool: t.array(ce).nullable(),
	exploreKeepN: t.int().nullable(),
	devCosts: t.record(t.string(), t.int()).nullable(),
	settleOpts: t.record(t.string(), t.array(le)).nullable(),
	payDue: t.object({
		inst: t.int(),
		def: t.string(),
		cost: t.int()
	}).nullable(),
	consume: t.object({
		powers: t.array(ue),
		mustAct: t.boolean(),
		mustTrade: t.boolean(),
		x2: t.boolean(),
		luckyPending: t.boolean()
	}).nullable(),
	producePicks: t.array(t.object({ kinds: t.array(t.string()) })),
	mustDiscard: t.int().nonnegative(),
	myAction: oe.nullable(),
	myPlacement: P.nullable()
}), I = { code: "games.rftg.errPhase" }, L = { code: "games.rftg.errCard" }, R = { code: "games.rftg.errCount" }, z = { code: "games.rftg.errIllegal" };
function B(e, t) {
	return A(e.instances[t]);
}
function V(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rng, n + 1);
		t.rng += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function H(e, t) {
	let n = [];
	for (; n.length < t;) {
		if (e.deck.length === 0) {
			if (e.discardPile.length === 0) break;
			e.deck = V(e, e.discardPile), e.discardPile = [];
		}
		n.push(e.deck.pop());
	}
	return n;
}
function fe(e, t, n) {
	n <= 0 || (e.vps[t] += n, e.vpPool -= n, e.vpPool <= 0 && (e.vpExhausted = !0));
}
function U(e, t, n) {
	let r = [];
	for (let i of e.tableau[t] ?? []) {
		if (i.activeAfter >= e.phaseCounter) continue;
		let t = B(e, i.inst);
		t.powers.forEach((e, a) => {
			e.phase === n && r.push({
				inst: i.inst,
				d: t,
				idx: a,
				codes: e.codes,
				value: e.value,
				times: e.times
			});
		});
	}
	return r;
}
function pe(e, t, n, r) {
	return U(e, t, n).some((e) => e.codes.includes(r));
}
function me(e, t, n) {
	let r = n.cost;
	e.actions[t] === "develop" && --r;
	for (let n of U(e, t, 2)) n.codes.includes("REDUCE") && (r -= n.value);
	return Math.max(0, r);
}
function he(e, t) {
	return pe(e, t, 3, "PAY_MILITARY");
}
function ge(e, t) {
	return U(e, t, 3).filter((e) => e.codes.includes("REDUCE_ZERO")).length;
}
function _e(e, t) {
	return U(e, t, 3).filter((e) => e.codes.includes("DISCARD") && e.codes.includes("EXTRA_MILITARY")).length;
}
function ve(e, t, n, r) {
	let i = 3 * r;
	for (let r of U(e, t, 3)) r.codes.includes("EXTRA_MILITARY") && !r.codes.includes("DISCARD") && (r.codes.includes("RARE") && n.good !== "RARE" || (!r.codes.includes("ALIEN") || n.alien) && (!r.codes.includes("AGAINST_REBEL") || n.rebel) && (i += r.value));
	return i;
}
function ye(e, t, n) {
	let r = 0;
	for (let i of U(e, t, 3)) i.codes.includes("REDUCE") && (i.codes.includes("RARE") && n.good !== "RARE" || (!i.codes.includes("ALIEN") || n.alien) && (r += i.value));
	return r;
}
function be(e, t, n) {
	if (n.type !== "world") return [];
	let r = [], i = ge(e, t) > 0, a = he(e, t), o = ye(e, t, n);
	if (!n.military) r.push({
		mode: "pay",
		cost: Math.max(0, n.cost - o),
		nmt: 0
	}), i && !(n.alien && n.good) && r.push({
		mode: "colonyShip",
		cost: 0,
		nmt: 0
	});
	else {
		let s = 0;
		for (; ve(e, t, n, s) < n.cost && s < _e(e, t);) s += 1;
		ve(e, t, n, s) >= n.cost && r.push({
			mode: "conquer",
			cost: 0,
			nmt: s
		}), a && !n.alien && (r.push({
			mode: "pay",
			cost: Math.max(0, n.cost - 1 - o),
			nmt: 0
		}), i && r.push({
			mode: "colonyShip",
			cost: 0,
			nmt: 0
		}));
	}
	return r;
}
function xe(e, t, n, r) {
	let i = B(e, n), a = {
		inst: n,
		good: null,
		activeAfter: e.phaseCounter
	};
	if (e.tableau[t].push(a), i.windfall) {
		let t = H(e, 1);
		t.length > 0 && (a.good = t[0]);
	}
	r.push({
		kind: "place",
		rid: t,
		data: {
			inst: n,
			def: i.id
		}
	});
	let o = i.type === "dev" ? 2 : 3, s = 0;
	for (let n of U(e, t, o)) n.codes.includes("DRAW_AFTER") && (s += n.value);
	s > 0 && W(e, t, s, r);
}
function W(e, t, n, r) {
	let i = H(e, n);
	i.length !== 0 && (e.hands[t].push(...i), r.push({
		kind: "draw",
		rid: t,
		data: { n: i.length },
		for: [t],
		secret: { cards: i.map((t) => ({
			inst: t,
			def: e.instances[t]
		})) }
	}));
}
function Se(e, t, n, r, i) {
	if (n.good !== null) return;
	let a = B(e, n.inst);
	if (!a.good) return;
	let o = H(e, 1);
	o.length !== 0 && (n.good = o[0], i.push(a.good), r.push({
		kind: "produce",
		rid: t,
		data: {
			inst: n.inst,
			good: a.good
		}
	}));
}
var Ce = [
	"explore",
	"develop",
	"settle",
	"consume",
	"produce"
];
function we(e) {
	switch (e) {
		case "explore5":
		case "explore11": return "explore";
		case "develop": return "develop";
		case "settle": return "settle";
		case "trade":
		case "consume2x": return "consume";
		case "produce": return "produce";
	}
}
function Te(e, t, n) {
	switch (e.phase = t, e.phaseCounter += 1, t) {
		case "explore": {
			let t = {}, n = {};
			for (let r of e.players) {
				let i = 2, a = 1;
				e.actions[r] === "explore5" && (i += 5), e.actions[r] === "explore11" && (i += 1, a += 1);
				for (let t of U(e, r, 1)) t.codes.includes("DRAW") && (i += t.value), t.codes.includes("KEEP") && (a += t.value);
				t[r] = H(e, i), n[r] = Math.min(a, t[r].length);
			}
			e.explore = {
				pool: t,
				keepN: n
			};
			break;
		}
		case "develop":
			for (let t of e.players) {
				let r = 0;
				for (let n of U(e, t, 2)) n.codes.includes("DRAW") && (r += n.value);
				r > 0 && W(e, t, r, n);
			}
			e.develop = {
				sel: {},
				revealed: !1,
				paying: {},
				placements: {}
			};
			break;
		case "settle":
			e.settle = {
				sel: {},
				revealed: !1,
				paying: {},
				placements: {}
			};
			break;
		case "consume": {
			for (let t of e.players) {
				let r = 0;
				for (let n of U(e, t, 4)) n.codes.includes("DRAW") && !n.codes.includes("DRAW_LUCKY") && (r += n.value);
				r > 0 && W(e, t, r, n);
			}
			let t = e.players.filter((t) => e.actions[t] === "trade" && K(e, t).length > 0), r = e.players.filter((t) => e.actions[t] === "consume2x"), i = {};
			for (let t of e.players) i[t] = [];
			e.consume = {
				traders: t,
				x2: r,
				used: i,
				done: []
			};
			break;
		}
		case "produce": {
			let t = {}, r = {};
			for (let i of e.players) {
				t[i] = [];
				for (let r of e.tableau[i]) {
					let a = B(e, r.inst);
					if (r.good !== null || !a.powers.some((e) => e.phase === 5 && e.codes.includes("PRODUCE")) || r.activeAfter >= e.phaseCounter) continue;
					let o = t[i].length;
					if (Se(e, i, r, n, t[i]), t[i].length > o) {
						let t = 0;
						for (let n of U(e, i, 5)) n.inst === r.inst && n.codes.includes("DRAW_IF") && (t += n.value);
						t > 0 && W(e, i, t, n);
					}
				}
				let a = 0;
				for (let t of U(e, i, 5)) t.codes.includes("DRAW") && (a += t.value), t.codes.includes("DRAW_WORLD_GENE") && (a += e.tableau[i].filter((t) => B(e, t.inst).good === "GENE").length * t.value);
				a > 0 && W(e, i, a, n);
				let o = [];
				e.actions[i] === "produce" && o.push({ kinds: "ANY" });
				for (let t of U(e, i, 5)) {
					let e = t.codes.find((e) => e.startsWith("WINDFALL_"));
					e && o.push({ kinds: e === "WINDFALL_ANY" ? "ANY" : [e.slice(9)] });
				}
				r[i] = Ee(e, i, o);
			}
			e.produce = {
				picks: r,
				produced: t
			}, De(e, n);
			break;
		}
	}
}
function Ee(e, t, n) {
	let r = [], i = e.tableau[t].filter((t) => t.good === null && B(e, t.inst).windfall), a = /* @__PURE__ */ new Set();
	for (let t of n) {
		let n = i.find((n) => !a.has(n.inst) && (t.kinds === "ANY" || t.kinds.includes(B(e, n.inst).good)));
		n && (a.add(n.inst), r.push(t));
	}
	return r;
}
function De(e, t) {
	let n = e.produce;
	if (n && Object.values(n.picks).every((e) => e.length === 0)) {
		for (let r of e.players) {
			let i = 0;
			for (let t of U(e, r, 5)) if (t.codes.includes("DRAW_EACH_NOVELTY") && (i += n.produced[r].filter((e) => e === "NOVELTY").length * t.value), t.codes.includes("DRAW_EACH_ALIEN") && (i += n.produced[r].filter((e) => e === "ALIEN").length * t.value), t.codes.includes("DRAW_DIFFERENT") && (i += new Set(n.produced[r]).size * t.value), t.codes.includes("DRAW_MOST_RARE")) {
				let a = n.produced[r].filter((e) => e === "RARE").length, o = e.players.every((e) => e === r || n.produced[e].filter((e) => e === "RARE").length < a);
				a > 0 && o && (i += t.value);
			}
			i > 0 && W(e, r, i, t);
		}
		e.produce = null, G(e, t);
	}
}
function G(e, t) {
	e.explore = null, e.develop = null, e.settle = null, e.consume = null;
	let n = e.queue.shift();
	if (n) {
		Te(e, n, t);
		return;
	}
	e.discarding = e.players.filter((t) => e.hands[t].length > 10), e.phase = "discard", e.discarding.length === 0 && Oe(e);
}
function Oe(e) {
	if (Math.max(...e.players.map((t) => e.tableau[t].length)) >= 12 || e.vpExhausted) {
		e.phase = "done";
		return;
	}
	e.round += 1, e.actions = {}, e.phase = "select";
}
function K(e, t) {
	let n = [];
	for (let r of e.tableau[t]) {
		if (r.good === null) continue;
		let t = B(e, r.inst).good;
		t && n.push({
			world: r.inst,
			inst: r.good,
			kind: t
		});
	}
	return n;
}
var ke = {
	NOVELTY: 2,
	RARE: 3,
	GENE: 4,
	ALIEN: 5
};
function Ae(e, t, n, r, i) {
	let a = 0;
	if (i) return 0;
	for (let i of U(e, t, 4)) (i.codes.includes("TRADE_ANY") || i.codes.includes(`TRADE_${n}`) || i.codes.includes("TRADE_THIS") && i.inst === r) && (a += i.value);
	return a;
}
function je(e, t) {
	let n = [];
	for (let r of U(e, t, 4)) {
		let e = r.codes, t = `${r.inst}:${r.idx}`, i = [
			"NOVELTY",
			"RARE",
			"GENE"
		].find((t) => e.includes(`CONSUME_${t}`)) ?? null;
		e.includes("CONSUME_3_DIFF") ? n.push({
			id: t,
			d: r.d,
			kind: "threeDiff",
			goodKind: null,
			value: r.value,
			times: 1,
			noBonus: !1,
			optional: !1
		}) : e.includes("CONSUME_ALL") ? n.push({
			id: t,
			d: r.d,
			kind: "all",
			goodKind: null,
			value: r.value,
			times: 0,
			noBonus: !1,
			optional: !1
		}) : e.includes("CONSUME_TWO") ? n.push({
			id: t,
			d: r.d,
			kind: "two",
			goodKind: i,
			value: r.value,
			times: r.times,
			noBonus: !1,
			optional: !1
		}) : e.includes("CONSUME_ANY") ? n.push({
			id: t,
			d: r.d,
			kind: "any",
			goodKind: null,
			value: r.value,
			times: r.times,
			noBonus: !1,
			optional: !1
		}) : i ? n.push({
			id: t,
			d: r.d,
			kind: "kind",
			goodKind: i,
			value: r.value,
			times: r.times,
			noBonus: !1,
			optional: !1
		}) : e.includes("DISCARD_HAND") ? n.push({
			id: t,
			d: r.d,
			kind: "hand",
			goodKind: null,
			value: r.value,
			times: r.times,
			noBonus: !0,
			optional: !0
		}) : e.includes("DRAW_LUCKY") ? n.push({
			id: t,
			d: r.d,
			kind: "lucky",
			goodKind: null,
			value: 0,
			times: 0,
			noBonus: !1,
			optional: !1
		}) : e.includes("TRADE_ACTION") && n.push({
			id: t,
			d: r.d,
			kind: "tradeAction",
			goodKind: null,
			value: 0,
			times: 0,
			noBonus: e.includes("TRADE_NO_BONUS"),
			optional: !1
		});
	}
	return n;
}
function Me(e, t, n) {
	let r = K(e, t);
	switch (n.kind) {
		case "any": return r.length >= 1;
		case "kind": return r.some((e) => e.kind === n.goodKind);
		case "two": return r.filter((e) => !n.goodKind || e.kind === n.goodKind).length >= 2;
		case "threeDiff": return new Set(r.map((e) => e.kind)).size >= 3;
		case "all": return r.length >= 2;
		case "hand": return e.hands[t].length > 0;
		case "lucky": return !0;
		case "tradeAction": return r.length >= 1;
	}
}
function Ne(e, t) {
	let n = e.consume;
	return n.traders.includes(t) ? !0 : je(e, t).some((r) => !r.optional && !n.used[t].includes(r.id) && Me(e, t, r));
}
function Pe(e, t, n, r, i, a, o) {
	let s = e.consume, c = je(e, t).find((e) => e.id === n);
	if (!c || s.used[t].includes(n) || !Me(e, t, c)) return z;
	let l = K(e, t), u = s.x2.includes(t) ? 2 : 1, d = (n) => {
		for (let r of n) {
			let n = e.tableau[t].find((e) => e.inst === r);
			if (!n || n.good === null) throw Error("goods validated by caller");
			e.discardPile.push(n.good), n.good = null;
		}
		o.push({
			kind: "consume",
			rid: t,
			data: { worlds: n }
		});
	};
	switch (c.kind) {
		case "any":
		case "kind": {
			let n = l.filter((e) => c.kind === "any" || e.kind === c.goodKind), i = Math.min(c.times, n.length);
			if (r.length !== i) return R;
			if (r.map((e) => l.find((t) => t.world === e)).some((e) => !e || c.kind === "kind" && e.kind !== c.goodKind)) return L;
			d(r), Fe(e, t, c, r.length, u, o);
			break;
		}
		case "two": {
			let n = l.filter((e) => !c.goodKind || e.kind === c.goodKind);
			if (r.length !== 2) return R;
			if (r.map((e) => l.find((t) => t.world === e)).some((e) => !e || c.goodKind && e.kind !== c.goodKind)) return L;
			if (n.length < 2) return z;
			d(r), Fe(e, t, c, 1, u, o);
			break;
		}
		case "threeDiff": {
			if (r.length !== 3) return R;
			let n = r.map((e) => l.find((t) => t.world === e));
			if (n.some((e) => !e)) return L;
			if (new Set(n.map((e) => e.kind)).size !== 3) return z;
			d(r), Fe(e, t, c, 1, u, o);
			break;
		}
		case "all":
			if (r.length !== l.length) return R;
			d(r), Fe(e, t, c, Math.max(0, r.length - 1), u, o);
			break;
		case "hand": {
			let n = i ?? [];
			if (n.length > c.times) return R;
			if (n.some((n) => !e.hands[t].includes(n))) return L;
			e.hands[t] = e.hands[t].filter((e) => !n.includes(e)), e.discardPile.push(...n), fe(e, t, c.value * n.length), o.push({
				kind: "consumeHand",
				rid: t,
				data: { n: n.length }
			});
			break;
		}
		case "lucky": {
			if (a === void 0) return R;
			let n = H(e, 1);
			if (n.length > 0) {
				let r = B(e, n[0]), i = r.cost === a;
				i ? e.hands[t].push(n[0]) : e.discardPile.push(n[0]), o.push({
					kind: "lucky",
					rid: t,
					data: {
						inst: n[0],
						def: r.id,
						guess: a,
						hit: i
					}
				});
			}
			break;
		}
		case "tradeAction": {
			if (r.length !== 1) return R;
			let n = l.find((e) => e.world === r[0]);
			if (!n) return L;
			let i = ke[n.kind] + Ae(e, t, n.kind, n.world, c.noBonus);
			d(r), W(e, t, i, o);
			break;
		}
	}
	return s.used[t].push(n), null;
}
function Fe(e, t, n, r, i, a) {
	let o = B(e, Number(n.id.split(":")[0])).powers[Number(n.id.split(":")[1])];
	o.codes.includes("GET_VP") && fe(e, t, n.value * r * i);
	let s = 0;
	o.codes.includes("GET_2_CARD") ? s = 2 * n.value * r : o.codes.includes("GET_CARD") && (s = n.value * r), s > 0 && W(e, t, s, a);
}
function Ie(e, t, n) {
	let r = [];
	for (let e of O) for (let t = 0; t < e.count; t += 1) r.push(e.id);
	let i = {
		players: t,
		seed: n,
		rng: 0,
		round: 1,
		phaseCounter: 0,
		phase: "opening",
		instances: r,
		deck: [],
		discardPile: [],
		vpPool: 12 * t.length,
		vpExhausted: !1,
		hands: {},
		tableau: {},
		vps: {},
		openingDone: [],
		actions: {},
		queue: [],
		explore: null,
		develop: null,
		settle: null,
		consume: null,
		produce: null,
		discarding: []
	}, a = V(i, ie.map((e) => r.indexOf(e.id))), o = [];
	t.forEach((e, t) => {
		let n = a[t];
		i.tableau[e] = [{
			inst: n,
			good: null,
			activeAfter: -1
		}], i.hands[e] = [], i.vps[e] = 0, o.push({
			kind: "startWorld",
			rid: e,
			data: {
				inst: n,
				def: r[n]
			},
			...t > 0 ? { with: !0 } : {}
		});
	});
	let s = new Set(a.slice(0, t.length));
	i.deck = V(i, r.map((e, t) => t).filter((e) => !s.has(e))), t.forEach((e) => {
		i.hands[e] = H(i, 6);
	});
	for (let e of t) {
		let t = i.tableau[e][0];
		if (B(i, t.inst).id === "alpha-centauri") {
			let e = H(i, 1);
			e.length > 0 && (t.good = e[0]);
		}
	}
	return o.push(...t.map((e, t) => ({
		kind: "deal",
		rid: e,
		data: { n: 6 },
		for: [e],
		secret: { cards: i.hands[e].map((e) => ({
			inst: e,
			def: r[e]
		})) },
		...t > 0 ? { with: !0 } : {}
	}))), {
		state: i,
		fx: o
	};
}
function Le() {
	return I;
}
function Re(e, t, n) {
	let r = structuredClone(e), i = [], a = n.by;
	if (!r.players.includes(a) || r.phase === "done") return I;
	switch (t.type) {
		case "openingDiscard": return r.phase !== "opening" || r.openingDone.includes(a) ? I : t.drop.length !== 2 || new Set(t.drop).size !== 2 ? R : t.drop.every((e) => r.hands[a].includes(e)) ? (r.hands[a] = r.hands[a].filter((e) => !t.drop.includes(e)), r.discardPile.push(...t.drop), r.openingDone.push(a), r.openingDone.length === r.players.length && (r.phase = "select"), {
			state: r,
			fx: i
		}) : L;
		case "chooseAction":
			if (r.phase !== "select" || r.actions[a]) return I;
			if (r.actions[a] = t.action, Object.keys(r.actions).length === r.players.length) {
				let e = new Set(Object.values(r.actions).map(we));
				r.queue = Ce.filter((t) => e.has(t)), G(r, i);
			}
			return {
				state: r,
				fx: i
			};
		case "exploreKeep": {
			if (r.phase !== "explore" || !r.explore || !(a in r.explore.pool)) return I;
			let e = r.explore.pool[a], n = r.explore.keepN[a];
			return t.keep.length !== n || new Set(t.keep).size !== n ? R : t.keep.every((t) => e.includes(t)) ? (r.hands[a].push(...t.keep), i.push({
				kind: "draw",
				rid: a,
				data: { n: t.keep.length },
				for: [a],
				secret: { cards: t.keep.map((e) => ({
					inst: e,
					def: r.instances[e]
				})) }
			}), r.discardPile.push(...e.filter((e) => !t.keep.includes(e))), delete r.explore.pool[a], Object.keys(r.explore.pool).length === 0 && G(r, i), {
				state: r,
				fx: i
			}) : L;
		}
		case "selectDev":
			if (r.phase !== "develop" || !r.develop || r.develop.revealed || a in r.develop.sel) return I;
			if (t.inst === null) r.develop.sel[a] = {
				inst: -1,
				mode: null,
				nmt: 0
			};
			else {
				let e = t.inst;
				if (!r.hands[a].includes(e)) return L;
				let n = B(r, e);
				if (n.type !== "dev" || r.tableau[a].some((e) => B(r, e.inst).id === n.id) || me(r, a, n) > r.hands[a].length - 1) return z;
				r.develop.sel[a] = {
					inst: e,
					mode: "pay",
					nmt: 0
				}, r.hands[a] = r.hands[a].filter((t) => t !== e);
			}
			return Object.keys(r.develop.sel).length === r.players.length && (ze(r, r.develop, 2, i), Object.keys(r.develop.paying).length === 0 && G(r, i)), {
				state: r,
				fx: i
			};
		case "selectWorld":
			if (r.phase !== "settle" || !r.settle || r.settle.revealed || a in r.settle.sel) return I;
			if (t.inst === null) r.settle.sel[a] = {
				inst: -1,
				mode: null,
				nmt: 0
			};
			else {
				let e = t.inst;
				if (!r.hands[a].includes(e)) return L;
				let n = be(r, a, B(r, e)), i = t.nmt ?? 0, o = n.find((e) => e.mode === t.mode && (e.mode !== "conquer" || e.nmt === i));
				if (!o || o.mode === "pay" && o.cost > r.hands[a].length - 1) return z;
				r.settle.sel[a] = {
					inst: e,
					mode: o.mode,
					nmt: o.nmt
				}, r.hands[a] = r.hands[a].filter((t) => t !== e);
			}
			return Object.keys(r.settle.sel).length === r.players.length && (ze(r, r.settle, 3, i), Object.keys(r.settle.paying).length === 0 && G(r, i)), {
				state: r,
				fx: i
			};
		case "pay": {
			let e = r.phase === "develop" ? r.develop : r.phase === "settle" ? r.settle : null;
			if (!e || !e.revealed || !(a in e.paying)) return I;
			let n = e.paying[a];
			if (t.cards.length !== n.cost || new Set(t.cards).size !== n.cost) return R;
			if (!t.cards.every((e) => r.hands[a].includes(e))) return L;
			r.hands[a] = r.hands[a].filter((e) => !t.cards.includes(e)), r.discardPile.push(...t.cards);
			let o = e.sel[a];
			if (o.mode === "colonyShip" && Be(r, a, "colony-ship", i), o.nmt > 0) for (let e = 0; e < o.nmt; e += 1) Be(r, a, "new-military-tactics", i);
			return xe(r, a, n.inst, i), delete e.paying[a], r.phase === "settle" && r.actions[a] === "settle" && W(r, a, 1, i), e.revealed && Object.keys(e.paying).length === 0 && G(r, i), {
				state: r,
				fx: i
			};
		}
		case "tradeGood": {
			if (r.phase !== "consume" || !r.consume || !r.consume.traders.includes(a)) return I;
			let e = r.tableau[a].find((e) => e.inst === t.world);
			if (!e || e.good === null) return L;
			let n = B(r, e.inst).good, o = ke[n] + Ae(r, a, n, e.inst, !1);
			return r.discardPile.push(e.good), e.good = null, i.push({
				kind: "trade",
				rid: a,
				data: {
					world: e.inst,
					good: n,
					n: o
				}
			}), W(r, a, o, i), r.consume.traders = r.consume.traders.filter((e) => e !== a), q(r, i), {
				state: r,
				fx: i
			};
		}
		case "tradeSkip": return r.phase !== "consume" || !r.consume ? I : K(r, a).length > 0 ? z : r.consume.traders.includes(a) ? (r.consume.traders = r.consume.traders.filter((e) => e !== a), q(r, i), {
			state: r,
			fx: i
		}) : I;
		case "consume": return r.phase !== "consume" || !r.consume || r.consume.traders.includes(a) ? I : Pe(r, a, t.power, t.goods ?? [], t.handCards, t.lucky, i) || (q(r, i), {
			state: r,
			fx: i
		});
		case "consumeAuto": return r.phase !== "consume" || !r.consume || r.consume.traders.includes(a) ? I : (Ve(r, a, i), q(r, i), {
			state: r,
			fx: i
		});
		case "consumeDone": return r.phase !== "consume" || !r.consume || r.consume.done.includes(a) ? I : Ne(r, a) ? z : (r.consume.done.push(a), q(r, i), {
			state: r,
			fx: i
		});
		case "producePick": {
			if (r.phase !== "produce" || !r.produce || !r.produce.picks[a]?.length) return I;
			let e = r.produce.picks[a][0], n = r.tableau[a].find((e) => e.inst === t.world);
			if (!n || n.good !== null) return L;
			let o = B(r, n.inst);
			return !o.windfall || e.kinds !== "ANY" && !e.kinds.includes(o.good) ? z : (Se(r, a, n, i, r.produce.produced[a]), r.produce.picks[a] = Ee(r, a, r.produce.picks[a].slice(1)), De(r, i), {
				state: r,
				fx: i
			});
		}
		case "discardDown": {
			if (r.phase !== "discard" || !r.discarding.includes(a)) return I;
			let e = r.hands[a].length - 10;
			return t.drop.length !== e || new Set(t.drop).size !== e ? R : t.drop.every((e) => r.hands[a].includes(e)) ? (r.hands[a] = r.hands[a].filter((e) => !t.drop.includes(e)), r.discardPile.push(...t.drop), r.discarding = r.discarding.filter((e) => e !== a), r.discarding.length === 0 && Oe(r), {
				state: r,
				fx: i
			}) : L;
		}
	}
	return Le();
}
function ze(e, t, n, r) {
	t.revealed = !0;
	for (let i of e.players) {
		let a = t.sel[i];
		if (a.inst < 0) {
			t.placements[i] = null;
			continue;
		}
		let o = B(e, a.inst), s = a.mode === "pay" ? n === 2 ? me(e, i, o) : Math.max(0, o.cost - (he(e, i) && o.military ? 1 : 0) - ye(e, i, o)) : 0;
		t.placements[i] = a, t.paying[i] = {
			inst: a.inst,
			cost: s
		}, r.push({
			kind: "reveal",
			rid: i,
			data: {
				inst: a.inst,
				def: o.id,
				mode: a.mode
			}
		});
	}
}
function Be(e, t, n, r) {
	let i = e.tableau[t].findIndex((t) => B(e, t.inst).id === n && t.activeAfter < e.phaseCounter);
	if (i < 0) return;
	let [a] = e.tableau[t].splice(i, 1);
	a.good !== null && e.discardPile.push(a.good), e.discardPile.push(a.inst), r.push({
		kind: "discardTableau",
		rid: t,
		data: {
			inst: a.inst,
			def: n
		}
	});
}
function q(e, t) {
	let n = e.consume;
	n.done.length === e.players.length && n.traders.length === 0 && G(e, t);
}
function Ve(e, t, n) {
	let r = e.consume;
	for (let i = 0; i < 40; i += 1) {
		let i = je(e, t).filter((n) => !n.optional && !r.used[t].includes(n.id) && Me(e, t, n));
		if (i.length === 0) return;
		let a = K(e, t), o = r.x2.includes(t) ? 2 : 1, s = i.map((t) => {
			let n = 0, r = 0, i = 0, s = B(e, Number(t.id.split(":")[0])).powers[Number(t.id.split(":")[1])], c = s.codes.includes("GET_VP"), l = s.codes.includes("GET_CARD") || s.codes.includes("GET_2_CARD");
			switch (t.kind) {
				case "any":
				case "kind":
					i = Math.min(t.times, a.filter((e) => t.kind === "any" || e.kind === t.goodKind).length), n = c ? t.value * i * o : 0, r = l ? t.value * i : 0;
					break;
				case "two":
				case "threeDiff":
					i = t.kind === "two" ? 2 : 3, n = c ? t.value * o : 0;
					break;
				case "all":
					i = a.length, n = c ? t.value * (a.length - 1) * o : 0;
					break;
				case "lucky":
					r = .5;
					break;
				case "tradeAction": r = 5, i = 1;
			}
			return {
				cp: t,
				score: n * 10 + r - i
			};
		});
		s.sort((e, t) => t.score - e.score);
		let c = s[0].cp, l = {
			NOVELTY: 0,
			RARE: 1,
			GENE: 2,
			ALIEN: 3
		}, u = [...K(e, t)].sort((e, t) => l[e.kind] - l[t.kind]), d = [];
		switch (c.kind) {
			case "any":
				d = u.slice(0, Math.min(c.times, u.length)).map((e) => e.world);
				break;
			case "kind":
				d = u.filter((e) => e.kind === c.goodKind).slice(0, c.times).map((e) => e.world);
				break;
			case "two":
				d = u.filter((e) => !c.goodKind || e.kind === c.goodKind).slice(0, 2).map((e) => e.world);
				break;
			case "threeDiff": {
				let e = /* @__PURE__ */ new Set();
				for (let t of u) if (e.has(t.kind) || (e.add(t.kind), d.push(t.world)), d.length === 3) break;
				break;
			}
			case "all":
				d = u.map((e) => e.world);
				break;
			case "tradeAction":
				d = [u[0].world];
				break;
			default: d = [];
		}
		if (c.kind === "lucky") {
			let r = /* @__PURE__ */ new Map();
			for (let t of e.deck) {
				let n = B(e, t).cost;
				r.set(n, (r.get(n) ?? 0) + 1);
			}
			let i = 4, a = -1;
			for (let [e, t] of r) t > a && e >= 1 && e <= 7 && (i = e, a = t);
			Pe(e, t, c.id, [], void 0, i, n);
		} else Pe(e, t, c.id, d, void 0, void 0, n);
	}
}
function He(e, t) {
	let n = Object.keys(e.actions), r = n.length === e.players.length, i = [];
	switch (e.phase) {
		case "opening":
			i.push(...e.players.filter((t) => !e.openingDone.includes(t)));
			break;
		case "select":
			i.push(...e.players.filter((t) => !(t in e.actions)));
			break;
		case "explore":
			e.explore && i.push(...Object.keys(e.explore.pool));
			break;
		case "develop":
		case "settle": {
			let t = e.phase === "develop" ? e.develop : e.settle;
			t && !t.revealed && i.push(...e.players.filter((e) => !(e in t.sel))), t?.revealed && i.push(...Object.keys(t.paying));
			break;
		}
		case "consume":
			e.consume && i.push(...e.players.filter((t) => !e.consume.done.includes(t)));
			break;
		case "produce":
			e.produce && i.push(...Object.entries(e.produce.picks).filter(([, e]) => e.length > 0).map(([e]) => e));
			break;
		case "discard": i.push(...e.discarding);
	}
	let a = e.phase === "develop" ? e.develop : e.phase === "settle" ? e.settle : null, o = a?.revealed ? Object.fromEntries(e.players.map((t) => {
		let n = a.placements[t];
		return [t, n && n.inst >= 0 ? {
			inst: n.inst,
			def: e.instances[n.inst],
			mode: n.mode,
			cost: a.paying[t]?.cost ?? null
		} : null];
	})) : null, s = {
		phase: e.phase,
		round: e.round,
		phaseCounter: e.phaseCounter,
		vpPool: Math.max(0, e.vpPool),
		deckCount: e.deck.length,
		discardCount: e.discardPile.length,
		players: e.players.map((t) => ({
			rid: t,
			handCount: e.hands[t].length,
			vp: e.vps[t],
			tableau: e.tableau[t].map((t) => ({
				inst: t.inst,
				def: e.instances[t.inst],
				hasGood: t.good !== null,
				activeAfter: t.activeAfter
			}))
		})),
		locked: e.phase === "select" || r ? n : [],
		revealed: r && e.phase !== "select" ? null : r ? { ...e.actions } : null,
		waiting: i,
		placements: o,
		consumeMeta: e.consume ? {
			traders: [...e.consume.traders],
			x2: [...e.consume.x2]
		} : null,
		finalScores: e.phase === "done" ? Object.fromEntries(e.players.map((t) => [t, Ke(e, t)])) : null
	};
	r && (s.revealed = { ...e.actions });
	let c = e.phase === "opening" && !e.openingDone.includes(t), l = e.explore?.pool[t] ?? null, u = null, d = null;
	if (e.phase === "develop" && e.develop && !e.develop.revealed && !(t in e.develop.sel)) {
		u = {};
		let n = new Set(e.tableau[t].map((t) => B(e, t.inst).id));
		for (let r of e.hands[t]) {
			let i = B(e, r);
			i.type === "dev" && !n.has(i.id) && (u[String(r)] = me(e, t, i));
		}
	}
	if (e.phase === "settle" && e.settle && !e.settle.revealed && !(t in e.settle.sel)) {
		d = {};
		for (let n of e.hands[t]) {
			let r = be(e, t, B(e, n));
			r.length > 0 && (d[String(n)] = r);
		}
	}
	let f = a?.revealed && a.paying[t] ? {
		inst: a.paying[t].inst,
		def: e.instances[a.paying[t].inst],
		cost: a.paying[t].cost
	} : null, p = null;
	if (e.phase === "consume" && e.consume) {
		let n = e.consume;
		p = {
			powers: je(e, t).map((r) => ({
				id: r.id,
				def: r.d.id,
				usable: !n.used[t].includes(r.id) && Me(e, t, r)
			})),
			mustAct: Ne(e, t),
			mustTrade: n.traders.includes(t),
			x2: n.x2.includes(t),
			luckyPending: !1
		};
	}
	let m = {
		hand: e.hands[t].map((t) => ({
			inst: t,
			def: e.instances[t]
		})),
		explorePool: l ? l.map((t) => ({
			inst: t,
			def: e.instances[t]
		})) : null,
		exploreKeepN: l ? e.explore.keepN[t] ?? null : null,
		devCosts: u,
		settleOpts: d,
		payDue: f,
		consume: p,
		producePicks: e.produce?.picks[t]?.map((e) => ({ kinds: e.kinds === "ANY" ? [
			"NOVELTY",
			"RARE",
			"GENE",
			"ALIEN"
		] : e.kinds })) ?? [],
		mustDiscard: c ? 2 : e.phase === "discard" && e.discarding.includes(t) ? e.hands[t].length - 10 : 0,
		myAction: e.actions[t] ?? null,
		myPlacement: null
	};
	if (a && t in a.sel) {
		let n = a.sel[t];
		m.myPlacement = n.inst >= 0 ? {
			inst: n.inst,
			def: e.instances[n.inst],
			mode: n.mode,
			cost: null
		} : null;
	}
	return {
		public: s,
		private: m
	};
}
function Ue(e, t, n) {
	if (!n.vpBonus) return 0;
	let r = 0;
	for (let i of e.tableau[t]) {
		let t = B(e, i.inst), a = 0;
		for (let e of n.vpBonus) e.type !== "THREE_VP" && e.type !== "TOTAL_MILITARY" && Ge(e, t) && (a = Math.max(a, e.vp));
		r += a;
	}
	let i = 0;
	for (let r of n.vpBonus) r.type === "THREE_VP" && (i += Math.floor(e.vps[t] / 3) * r.vp), r.type === "TOTAL_MILITARY" && (i += We(e, t) * r.vp);
	return r + i;
}
function We(e, t) {
	let n = 0;
	for (let r of e.tableau[t]) for (let t of B(e, r.inst).powers) t.phase === 3 && t.codes.includes("EXTRA_MILITARY") && !t.codes.includes("DISCARD") && (t.codes.includes("RARE") || t.codes.includes("ALIEN") || t.codes.includes("AGAINST_REBEL") || (n += t.value));
	return Math.max(0, n);
}
function Ge(e, t) {
	switch (e.type) {
		case "NAME": return t.id === e.name;
		case "NOVELTY_PRODUCTION":
		case "RARE_PRODUCTION":
		case "GENE_PRODUCTION":
		case "ALIEN_PRODUCTION": return t.type === "world" && !t.windfall && t.good === e.type.replace("_PRODUCTION", "");
		case "NOVELTY_WINDFALL":
		case "RARE_WINDFALL":
		case "GENE_WINDFALL":
		case "ALIEN_WINDFALL": return t.type === "world" && !!t.windfall && t.good === e.type.replace("_WINDFALL", "");
		case "MILITARY": return t.type === "world" && !!t.military;
		case "REBEL_MILITARY": return t.type === "world" && !!t.military && !!t.rebel;
		case "SIX_DEVEL": return t.type === "dev" && t.cost === 6;
		case "DEVEL": return t.type === "dev";
		case "WORLD": return t.type === "world";
		case "ALIEN_FLAG": return !!t.alien;
		case "DEVEL_EXPLORE": return t.type === "dev" && t.powers.some((e) => e.phase === 1);
		case "WORLD_EXPLORE": return t.type === "world" && t.powers.some((e) => e.phase === 1);
		case "DEVEL_CONSUME": return t.type === "dev" && t.powers.some((e) => e.phase === 4 && !e.codes.every((e) => e.startsWith("TRADE_")));
		case "WORLD_CONSUME": return t.type === "world" && t.powers.some((e) => e.phase === 4 && !e.codes.every((e) => e.startsWith("TRADE_")));
		case "DEVEL_TRADE": return t.type === "dev" && t.powers.some((e) => e.phase === 4 && e.codes.some((e) => e.startsWith("TRADE_")));
		case "WORLD_TRADE": return t.type === "world" && t.powers.some((e) => e.phase === 4 && e.codes.some((e) => e.startsWith("TRADE_")));
		default: return !1;
	}
}
function Ke(e, t) {
	let n = 0, r = 0;
	for (let i of e.tableau[t]) {
		let a = B(e, i.inst);
		a.type === "dev" && a.cost === 6 ? r += Ue(e, t, a) : n += a.vp;
	}
	return {
		cards: n,
		chips: e.vps[t],
		six: r,
		total: n + e.vps[t] + r
	};
}
function qe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = Ke(e, n).total;
	let n = Math.max(...Object.values(t)), r = e.players.filter((e) => t[e] === n);
	if (r.length > 1) {
		let t = (t) => e.hands[t].length + e.tableau[t].filter((e) => e.good !== null).length, n = Math.max(...r.map(t));
		r = r.filter((e) => t(e) === n);
	}
	let i = [...e.players].sort((n, r) => {
		if (t[r] !== t[n]) return t[r] - t[n];
		let i = e.hands[n].length + e.tableau[n].filter((e) => e.good !== null).length;
		return e.hands[r].length + e.tableau[r].filter((e) => e.good !== null).length - i;
	});
	return {
		phase: "done",
		winner: r,
		ranking: i,
		scores: t
	};
}
var Je = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: j,
	schemas: {
		action: M,
		publicView: F,
		privateView: de
	},
	setup: Ie,
	reduce: Re,
	viewFor: He,
	status: qe
}, Ye = {
	"old-earth": "games.rftg.cards.old-earth",
	"epsilon-eridani": "games.rftg.cards.epsilon-eridani",
	"alpha-centauri": "games.rftg.cards.alpha-centauri",
	"new-sparta": "games.rftg.cards.new-sparta",
	"earth-s-lost-colony": "games.rftg.cards.earth-s-lost-colony",
	"rebel-fuel-cache": "games.rftg.cards.rebel-fuel-cache",
	"public-works": "games.rftg.cards.public-works",
	"gem-world": "games.rftg.cards.gem-world",
	"colony-ship": "games.rftg.cards.colony-ship",
	"comet-zone": "games.rftg.cards.comet-zone",
	"expedition-force": "games.rftg.cards.expedition-force",
	"mining-robots": "games.rftg.cards.mining-robots",
	"rebel-miners": "games.rftg.cards.rebel-miners",
	"export-duties": "games.rftg.cards.export-duties",
	"former-penal-colony": "games.rftg.cards.former-penal-colony",
	"malevolent-lifeforms": "games.rftg.cards.malevolent-lifeforms",
	"new-military-tactics": "games.rftg.cards.new-military-tactics",
	"space-marines": "games.rftg.cards.space-marines",
	"contact-specialist": "games.rftg.cards.contact-specialist",
	"avian-uplift-race": "games.rftg.cards.avian-uplift-race",
	"spice-world": "games.rftg.cards.spice-world",
	"lost-species-ark-world": "games.rftg.cards.lost-species-ark-world",
	"new-vinland": "games.rftg.cards.new-vinland",
	"artist-colony": "games.rftg.cards.artist-colony",
	"alien-robotic-factory": "games.rftg.cards.alien-robotic-factory",
	"plague-world": "games.rftg.cards.plague-world",
	"distant-world": "games.rftg.cards.distant-world",
	"rebel-outpost": "games.rftg.cards.rebel-outpost",
	"rebel-warrior-race": "games.rftg.cards.rebel-warrior-race",
	"rebel-underground": "games.rftg.cards.rebel-underground",
	"new-survivalists": "games.rftg.cards.new-survivalists",
	"outlaw-world": "games.rftg.cards.outlaw-world",
	"lost-alien-battle-fleet": "games.rftg.cards.lost-alien-battle-fleet",
	"diversified-economy": "games.rftg.cards.diversified-economy",
	"consumer-markets": "games.rftg.cards.consumer-markets",
	"mining-conglomerate": "games.rftg.cards.mining-conglomerate",
	"research-labs": "games.rftg.cards.research-labs",
	"deficit-spending": "games.rftg.cards.deficit-spending",
	"investment-credits": "games.rftg.cards.investment-credits",
	"pan-galactic-league": "games.rftg.cards.pan-galactic-league",
	"mining-league": "games.rftg.cards.mining-league",
	"free-trade-association": "games.rftg.cards.free-trade-association",
	"alien-tech-institute": "games.rftg.cards.alien-tech-institute",
	"galactic-survey-seti": "games.rftg.cards.galactic-survey-seti",
	"galactic-federation": "games.rftg.cards.galactic-federation",
	"refugee-world": "games.rftg.cards.refugee-world",
	"empath-world": "games.rftg.cards.empath-world",
	"galactic-resort": "games.rftg.cards.galactic-resort",
	"pre-sentient-race": "games.rftg.cards.pre-sentient-race",
	"deserted-alien-outpost": "games.rftg.cards.deserted-alien-outpost",
	"deserted-alien-colony": "games.rftg.cards.deserted-alien-colony",
	"galactic-engineers": "games.rftg.cards.galactic-engineers",
	"black-market-trading-world": "games.rftg.cards.black-market-trading-world",
	"merchant-world": "games.rftg.cards.merchant-world",
	"tourist-world": "games.rftg.cards.tourist-world",
	"galactic-trendsetters": "games.rftg.cards.galactic-trendsetters",
	"alien-rosetta-stone-world": "games.rftg.cards.alien-rosetta-stone-world",
	"star-nomad-lair": "games.rftg.cards.star-nomad-lair",
	"the-last-of-the-uplift-gnarssh": "games.rftg.cards.the-last-of-the-uplift-gnarssh",
	"alien-robot-sentry": "games.rftg.cards.alien-robot-sentry",
	"pirate-world": "games.rftg.cards.pirate-world",
	"reptilian-uplift-race": "games.rftg.cards.reptilian-uplift-race",
	"lost-alien-warship": "games.rftg.cards.lost-alien-warship",
	"alien-robot-scout-ship": "games.rftg.cards.alien-robot-scout-ship",
	"runaway-robots": "games.rftg.cards.runaway-robots",
	"interstellar-bank": "games.rftg.cards.interstellar-bank",
	"terraforming-robots": "games.rftg.cards.terraforming-robots",
	"drop-ships": "games.rftg.cards.drop-ships",
	"new-galactic-order": "games.rftg.cards.new-galactic-order",
	"asteroid-belt": "games.rftg.cards.asteroid-belt",
	"merchant-guild": "games.rftg.cards.merchant-guild",
	"secluded-world": "games.rftg.cards.secluded-world",
	"imperium-armaments-world": "games.rftg.cards.imperium-armaments-world",
	"terraformed-world": "games.rftg.cards.terraformed-world",
	"replicant-robots": "games.rftg.cards.replicant-robots",
	"pilgrimage-world": "games.rftg.cards.pilgrimage-world",
	"rebel-homeworld": "games.rftg.cards.rebel-homeworld",
	"new-economy": "games.rftg.cards.new-economy",
	"radioactive-world": "games.rftg.cards.radioactive-world",
	"aquatic-uplift-race": "games.rftg.cards.aquatic-uplift-race",
	"genetics-lab": "games.rftg.cards.genetics-lab",
	"bio-hazard-mining-world": "games.rftg.cards.bio-hazard-mining-world",
	"deserted-alien-library": "games.rftg.cards.deserted-alien-library",
	"destroyed-world": "games.rftg.cards.destroyed-world",
	"galactic-renaissance": "games.rftg.cards.galactic-renaissance",
	"blaster-gem-mines": "games.rftg.cards.blaster-gem-mines",
	"gambling-world": "games.rftg.cards.gambling-world",
	"expanding-colony": "games.rftg.cards.expanding-colony",
	"space-port": "games.rftg.cards.space-port",
	"prosperous-world": "games.rftg.cards.prosperous-world",
	"new-earth": "games.rftg.cards.new-earth",
	"rebel-base": "games.rftg.cards.rebel-base",
	"galactic-imperium": "games.rftg.cards.galactic-imperium",
	"trade-league": "games.rftg.cards.trade-league",
	"mining-world": "games.rftg.cards.mining-world"
}, Xe = {
	NOVELTY: "games.rftg.good.NOVELTY",
	RARE: "games.rftg.good.RARE",
	GENE: "games.rftg.good.GENE",
	ALIEN: "games.rftg.good.ALIEN"
};
function J(e, t) {
	return e(Xe[t]);
}
function Ze(e, t) {
	let n = t.codes, r = (e) => n.includes(e), i = [
		"NOVELTY",
		"RARE",
		"GENE",
		"ALIEN"
	].find((e) => r(`CONSUME_${e}`) || r(`TRADE_${e}`) || r(`WINDFALL_${e}`)) ?? null, a = i ? J(e, i) : "";
	if (t.phase === 1) return r("KEEP") ? e("games.rftg.pw.exploreKeep") : e("games.rftg.pw.exploreDraw", { n: t.value });
	if (t.phase === 2) return r("DRAW_AFTER") ? e("games.rftg.pw.devDrawAfter", { n: t.value }) : r("REDUCE") ? e("games.rftg.pw.devReduce", { n: t.value }) : e("games.rftg.pw.devDraw");
	if (t.phase === 3) return r("DISCARD") && r("EXTRA_MILITARY") ? e("games.rftg.pw.nmt") : r("DISCARD") && r("REDUCE_ZERO") ? e("games.rftg.pw.colonyShip") : r("PAY_MILITARY") ? e("games.rftg.pw.payMilitary") : r("DRAW_AFTER") ? e("games.rftg.pw.settleDrawAfter", { n: t.value }) : r("REDUCE") ? r("RARE") ? e("games.rftg.pw.settleReduceKind", {
		n: t.value,
		kind: e("games.rftg.good.RARE")
	}) : r("ALIEN") ? e("games.rftg.pw.settleReduceKind", {
		n: t.value,
		kind: e("games.rftg.good.ALIEN")
	}) : e("games.rftg.pw.settleReduce", { n: t.value }) : r("AGAINST_REBEL") ? e("games.rftg.pw.militaryKind", {
		n: t.value,
		kind: e("games.rftg.label.rebel")
	}) : r("RARE") ? e("games.rftg.pw.militaryKind", {
		n: t.value,
		kind: e("games.rftg.good.RARE")
	}) : r("ALIEN") ? e("games.rftg.pw.militaryKind", {
		n: t.value,
		kind: e("games.rftg.good.ALIEN")
	}) : e("games.rftg.pw.military", { n: t.value > 0 ? `+${t.value}` : String(t.value) });
	if (t.phase === 4) {
		if (r("DISCARD_HAND")) return e("games.rftg.pw.discardHand", {
			n: t.times,
			v: t.value
		});
		if (r("DRAW_LUCKY")) return e("games.rftg.pw.drawLucky");
		if (r("TRADE_ACTION")) return e(r("TRADE_NO_BONUS") ? "games.rftg.pw.tradeActionNoBonus" : "games.rftg.pw.tradeAction");
		if (r("TRADE_THIS")) return e("games.rftg.pw.tradeThis", { n: t.value });
		if (r("TRADE_ANY")) return e("games.rftg.pw.tradeAny", { n: t.value });
		if (r("TRADE_NOVELTY") || r("TRADE_RARE") || r("TRADE_GENE")) return e("games.rftg.pw.tradeKind", {
			n: t.value,
			kind: a
		});
		if (r("DRAW")) return e("games.rftg.pw.consumeDraw");
		let n;
		n = r("CONSUME_3_DIFF") ? e("games.rftg.pw.consume3diff") : r("CONSUME_ALL") ? e("games.rftg.pw.consumeAll") : r("CONSUME_TWO") ? i ? e("games.rftg.pw.consumePair", { kind: a }) : e("games.rftg.pw.consumePairAny") : i ? e("games.rftg.pw.consumeKind", {
			n: t.times,
			kind: a
		}) : e("games.rftg.pw.consumeAny", { n: t.times });
		let o;
		if (r("CONSUME_ALL")) o = e("games.rftg.pw.rewardAllVp", { n: t.value });
		else if (r("CONSUME_TWO") || r("CONSUME_3_DIFF")) o = e("games.rftg.pw.rewardPairVp", { n: t.value });
		else {
			let n = [];
			r("GET_VP") && n.push(e("games.rftg.pw.rewardVp", { n: t.value })), r("GET_2_CARD") ? n.push(e("games.rftg.pw.rewardCard", { n: t.value * 2 })) : r("GET_CARD") && n.push(e("games.rftg.pw.rewardCard", { n: t.value })), o = n.join(" + ");
		}
		return `${n} → ${o}`;
	}
	return r("PRODUCE") ? e("games.rftg.pw.produce") : r("WINDFALL_ANY") ? e("games.rftg.pw.windfallAny") : r("WINDFALL_NOVELTY") || r("WINDFALL_RARE") || r("WINDFALL_GENE") || r("WINDFALL_ALIEN") ? e("games.rftg.pw.windfallKind", { kind: a }) : r("DRAW_IF") ? e("games.rftg.pw.prodDrawIf", { n: t.value }) : r("DRAW_WORLD_GENE") ? e("games.rftg.pw.prodDrawGene") : r("DRAW_EACH_NOVELTY") ? e("games.rftg.pw.prodDrawEachNovelty") : r("DRAW_EACH_ALIEN") ? e("games.rftg.pw.prodDrawEachAlien") : r("DRAW_DIFFERENT") ? e("games.rftg.pw.prodDrawDiff") : r("DRAW_MOST_RARE") ? e("games.rftg.pw.prodDrawMostRare", { n: t.value }) : e("games.rftg.pw.prodDraw", { n: t.value });
}
function Qe(e, t) {
	let n = t.vp;
	switch (t.type) {
		case "THREE_VP": return e("games.rftg.vpb.threeVp", { n });
		case "TOTAL_MILITARY": return e("games.rftg.vpb.totalMilitary", { n });
		case "NAME": return e("games.rftg.vpb.name", {
			n,
			name: Y(e, t.name ?? "")
		});
		case "NOVELTY_PRODUCTION": return e("games.rftg.vpb.noveltyProd", { n });
		case "RARE_PRODUCTION": return e("games.rftg.vpb.rareProd", { n });
		case "GENE_PRODUCTION": return e("games.rftg.vpb.geneProd", { n });
		case "ALIEN_PRODUCTION": return e("games.rftg.vpb.alienProd", { n });
		case "NOVELTY_WINDFALL": return e("games.rftg.vpb.noveltyWind", { n });
		case "RARE_WINDFALL": return e("games.rftg.vpb.rareWind", { n });
		case "GENE_WINDFALL": return e("games.rftg.vpb.geneWind", { n });
		case "ALIEN_WINDFALL": return e("games.rftg.vpb.alienWind", { n });
		case "MILITARY": return e("games.rftg.vpb.militaryWorld", { n });
		case "REBEL_MILITARY": return e("games.rftg.vpb.rebelMilitary", { n });
		case "SIX_DEVEL": return e("games.rftg.vpb.sixDevel", { n });
		case "DEVEL": return e("games.rftg.vpb.devel", { n });
		case "WORLD": return e("games.rftg.vpb.world", { n });
		case "ALIEN_FLAG": return e("games.rftg.vpb.alienFlag", { n });
		case "DEVEL_EXPLORE": return e("games.rftg.vpb.develExplore", { n });
		case "WORLD_EXPLORE": return e("games.rftg.vpb.worldExplore", { n });
		case "DEVEL_CONSUME": return e("games.rftg.vpb.develConsume", { n });
		case "WORLD_CONSUME": return e("games.rftg.vpb.worldConsume", { n });
		case "DEVEL_TRADE": return e("games.rftg.vpb.develTrade", { n });
		case "WORLD_TRADE": return e("games.rftg.vpb.worldTrade", { n });
		default: return t.type;
	}
}
function Y(e, t) {
	let n = Ye[t];
	return n ? e(n) : t;
}
function $e(e) {
	return e.vpBonus ?? [];
}
//#endregion
//#region src/games/rftg/card-art.tsx
var et = "<defs>\n  <linearGradient id=\"space\" x2=\"1\" y2=\"1\"><stop stop-color=\"#233c59\"/><stop offset=\".55\" stop-color=\"#15263e\"/><stop offset=\"1\" stop-color=\"#0b172c\"/></linearGradient>\n  <linearGradient id=\"silver\" x2=\".3\" y2=\"1\"><stop stop-color=\"#fafbf3\"/><stop offset=\".48\" stop-color=\"#d8e2e6\"/><stop offset=\"1\" stop-color=\"#bbcbd4\"/></linearGradient>\n  <linearGradient id=\"earth\" x2=\"1\" y2=\".65\"><stop stop-color=\"#bce5e3\"/><stop offset=\".32\" stop-color=\"#5bb4c7\"/><stop offset=\".7\" stop-color=\"#286c8c\"/><stop offset=\"1\" stop-color=\"#142d4c\"/></linearGradient>\n  <linearGradient id=\"red-world\" x2=\"1\" y2=\".7\"><stop stop-color=\"#e4b894\"/><stop offset=\".4\" stop-color=\"#a67d77\"/><stop offset=\"1\" stop-color=\"#39344c\"/></linearGradient>\n  <linearGradient id=\"planet-night\" x2=\"1\" y2=\".35\"><stop stop-color=\"#5995a4\"/><stop offset=\"1\" stop-color=\"#132842\"/></linearGradient>\n  <linearGradient id=\"hull\" x2=\".6\" y2=\"1\"><stop stop-color=\"#f2f0d8\"/><stop offset=\".5\" stop-color=\"#bacdd0\"/><stop offset=\"1\" stop-color=\"#627e92\"/></linearGradient>\n  <linearGradient id=\"gold\" x2=\".4\" y2=\"1\"><stop stop-color=\"#f7dda6\"/><stop offset=\".5\" stop-color=\"#dfb364\"/><stop offset=\"1\" stop-color=\"#a9753c\"/></linearGradient>\n  <linearGradient id=\"glass\" x2=\".5\" y2=\"1\"><stop stop-color=\"#8cd3d4\"/><stop offset=\"1\" stop-color=\"#1f667e\"/></linearGradient>\n  <clipPath id=\"earth-clip\"><circle cx=\"110\" cy=\"89\" r=\"65\"/></clipPath>\n  <clipPath id=\"art-clip\"><rect width=\"200\" height=\"172\" rx=\"3\"/></clipPath>\n  <pattern id=\"cargo-lines\" width=\"8\" height=\"8\" patternUnits=\"userSpaceOnUse\"><path d=\"M-2 2L2-2M0 8L8 0M6 10L10 6\" stroke=\"#fff\" stroke-opacity=\".17\" stroke-width=\"1\"/></pattern>\n  <pattern id=\"rare-lines\" width=\"8\" height=\"8\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 4h8\" stroke=\"#18283b\" stroke-opacity=\".4\"/></pattern>\n</defs>", tt = {
	earth: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"104.0\" cy=\"54.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.6\" cy=\"103.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"159.1\" cy=\"152.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.6\" cy=\"29.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"14.2\" cy=\"78.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.7\" cy=\"127.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"69.3\" cy=\"4.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"96.8\" cy=\"53.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"124.4\" cy=\"102.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"151.9\" cy=\"150.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.5\" cy=\"27.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.0\" cy=\"76.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"34.5\" cy=\"125.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.1\" cy=\"2.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"89.6\" cy=\"51.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.2\" cy=\"100.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"144.7\" cy=\"149.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.3\" cy=\"26.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"199.8\" cy=\"75.1\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"27.4\" cy=\"124.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"54.9\" cy=\"0.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"82.4\" cy=\"49.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.0\" cy=\"98.7\" r=\"0.65\" fill=\"#d6e5ed\" /><ellipse cx=\"110\" cy=\"95\" rx=\"79\" ry=\"17\" transform=\"rotate(-20 110 95)\" fill=\"none\" stroke=\"#a2c0cc\" stroke-width=\"1.2\" opacity=\".55\"/><circle cx=\"110\" cy=\"89\" r=\"65\" fill=\"url(#earth)\" stroke=\"#abd5d8\" stroke-width=\"0.7\"/><g clip-path=\"url(#earth-clip)\">\n      <path d=\"M46 57l27-18 17 7 3 11 19 4 6 13-12 9-17-1-6 15-14-2-8-18-13-2Zm63 48 17-6 16 12-4 16-14 16-11-10-2-16Zm21-75 30 9 18 24-17 5-12-11-13 3-7-12Z\" fill=\"#80b09b\"/>\n      <path d=\"M55 65l31-14 4 6 19 9m-47 45 28 1m36-72 21 3m-43 76 23-2\" fill=\"none\" stroke=\"#c2ded3\" stroke-width=\"4\" opacity=\".57\" stroke-linecap=\"round\"/>\n      <path d=\"M158 20c-29 38-32 108 13 144h48V11Z\" fill=\"#102039\" opacity=\".45\"/>\n      <path d=\"M38 89c22-18 47-19 78-9m-42 46c22 9 39 6 59 0\" fill=\"none\" stroke=\"#dce9dc\" opacity=\".5\" stroke-width=\"3\" stroke-linecap=\"round\"/>\n    </g><path d=\"M33 148l9-17 15 1 3 7 24-6 15 13-34 13-31-4Z\" fill=\"#d7e1da\" stroke=\"#28475b\" stroke-width=\"1.5\"/><path d=\"M50 139l16 5 16-4m-36 14 19-4\" stroke=\"#678c9d\" fill=\"none\"/></g>",
	binary: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"124.8\" cy=\"65.7\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"152.4\" cy=\"114.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.9\" cy=\"163.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.4\" cy=\"40.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"35.0\" cy=\"89.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.5\" cy=\"138.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"90.1\" cy=\"15.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.6\" cy=\"64.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"145.2\" cy=\"113.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.7\" cy=\"161.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"0.3\" cy=\"38.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"27.8\" cy=\"87.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"55.4\" cy=\"136.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"82.9\" cy=\"13.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.4\" cy=\"62.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"138.0\" cy=\"111.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"165.5\" cy=\"160.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"193.1\" cy=\"37.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"20.6\" cy=\"86.1\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"48.2\" cy=\"135.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"75.7\" cy=\"11.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"103.3\" cy=\"60.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"130.8\" cy=\"109.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"159\" cy=\"37\" r=\"19\" fill=\"#edc479\" /><circle cx=\"137\" cy=\"56\" r=\"10\" fill=\"#e8deae\" /><circle cx=\"99\" cy=\"111\" r=\"58\" fill=\"url(#red-world)\" stroke=\"#bda59a\" stroke-width=\"1\"/><path d=\"M45 101l20-20 16 7 10-16 28 25-9 24-29 3-10 20-21-10Zm58 32 17-13 23 6-13 18-19 9Z\" fill=\"#745765\"/><path d=\"M48 118c26-11 55-7 82 6m-77-30 22-4 7 5m29 64 14-8\" fill=\"none\" stroke=\"#d9ab89\" stroke-width=\"3\"/><ellipse cx=\"101\" cy=\"111\" rx=\"80\" ry=\"18\" transform=\"rotate(-19 101 111)\" fill=\"none\" stroke=\"#a2c0cc\" stroke-width=\"1.2\" opacity=\".55\"/><path d=\"M33 149l17-24 20 5 8 21Z\" fill=\"#cfb38c\" stroke=\"#293747\" stroke-width=\"2\"/><path d=\"M41 144l10-11 9 3-6 14\" stroke=\"#5d6270\" fill=\"none\"/></g>",
	fortress: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"166.4\" cy=\"87.6\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"194.0\" cy=\"136.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"21.5\" cy=\"13.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"49.1\" cy=\"62.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"76.6\" cy=\"111.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"104.1\" cy=\"160.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.7\" cy=\"37.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"159.2\" cy=\"86.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.8\" cy=\"134.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"14.3\" cy=\"11.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.9\" cy=\"60.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"69.4\" cy=\"109.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"97.0\" cy=\"158.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"124.5\" cy=\"35.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"152.0\" cy=\"84.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.6\" cy=\"133.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.1\" cy=\"10.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"34.7\" cy=\"59.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.2\" cy=\"108.0\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"89.8\" cy=\"156.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.3\" cy=\"33.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"144.9\" cy=\"82.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.4\" cy=\"131.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"154\" cy=\"52\" r=\"53\" fill=\"url(#red-world)\" /><path d=\"M0 138l37-20 22 8 44-10 97 35v21H0Z\" fill=\"#5c5b68\"/><path d=\"M20 140l73-29 83 33-73 25Z\" fill=\"#243a50\" stroke=\"#0d263c\" stroke-width=\"2\"/>\n      <path d=\"M57 126V83l39-21 42 18v48l-37 20Z\" fill=\"#91a5af\" stroke=\"#182f46\" stroke-width=\"2\"/>\n      <path d=\"M96 62v86l42-20V80Z\" fill=\"#48657c\"/><path d=\"M57 83l39 15 42-18\" fill=\"none\" stroke=\"#c0ced0\" stroke-width=\"2\"/>\n      <path d=\"M74 108v25l15 6v-26Zm39-6v28l14-7v-26Z\" fill=\"#152b41\"/>\n      <path d=\"M62 87v11l24 10V96Zm44 12 23-11v10l-23 11Z\" fill=\"#d88775\"/>\n      <path d=\"M45 128V108l12-7m81-14 19 7v32l-19 7m-57-65 4-21 9-4 5 20\" fill=\"#698399\" stroke=\"#193149\" stroke-width=\"2\"/>\n      <path d=\"M101 71l19-9 9 4-20 10Z\" fill=\"#dba483\"/>\n      <path d=\"M30 144l-4 12m15-8-3 12m107-12 9 9\" stroke=\"#c6937f\" stroke-width=\"2\"/>\n    </g>",
	rebel: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"104.0\" cy=\"54.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.6\" cy=\"103.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"159.1\" cy=\"152.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.6\" cy=\"29.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"14.2\" cy=\"78.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.7\" cy=\"127.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"69.3\" cy=\"4.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"96.8\" cy=\"53.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"124.4\" cy=\"102.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"151.9\" cy=\"150.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.5\" cy=\"27.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.0\" cy=\"76.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"34.5\" cy=\"125.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.1\" cy=\"2.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"89.6\" cy=\"51.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.2\" cy=\"100.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"144.7\" cy=\"149.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.3\" cy=\"26.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"199.8\" cy=\"75.1\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"27.4\" cy=\"124.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"54.9\" cy=\"0.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"82.4\" cy=\"49.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.0\" cy=\"98.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"154\" cy=\"52\" r=\"53\" fill=\"url(#red-world)\" /><path d=\"M0 138l37-20 22 8 44-10 97 35v21H0Z\" fill=\"#5c5b68\"/><path d=\"M20 140l73-29 83 33-73 25Z\" fill=\"#243a50\" stroke=\"#0d263c\" stroke-width=\"2\"/>\n      <path d=\"M57 126V83l39-21 42 18v48l-37 20Z\" fill=\"#91a5af\" stroke=\"#182f46\" stroke-width=\"2\"/>\n      <path d=\"M96 62v86l42-20V80Z\" fill=\"#48657c\"/><path d=\"M57 83l39 15 42-18\" fill=\"none\" stroke=\"#c0ced0\" stroke-width=\"2\"/>\n      <path d=\"M74 108v25l15 6v-26Zm39-6v28l14-7v-26Z\" fill=\"#152b41\"/>\n      <path d=\"M62 87v11l24 10V96Zm44 12 23-11v10l-23 11Z\" fill=\"#d88775\"/>\n      <path d=\"M45 128V108l12-7m81-14 19 7v32l-19 7m-57-65 4-21 9-4 5 20\" fill=\"#698399\" stroke=\"#193149\" stroke-width=\"2\"/>\n      <path d=\"M101 71l19-9 9 4-20 10Z\" fill=\"#dba483\"/>\n      <path d=\"M30 144l-4 12m15-8-3 12m107-12 9 9\" stroke=\"#c6937f\" stroke-width=\"2\"/>\n    <path d=\"M154 93V49l24 7-24 13\" fill=\"#d77d66\" stroke=\"#8ca2ad\" stroke-width=\"2\"/></g>",
	colony: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"124.8\" cy=\"65.7\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"152.4\" cy=\"114.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.9\" cy=\"163.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.4\" cy=\"40.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"35.0\" cy=\"89.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.5\" cy=\"138.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"90.1\" cy=\"15.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.6\" cy=\"64.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"145.2\" cy=\"113.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.7\" cy=\"161.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"0.3\" cy=\"38.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"27.8\" cy=\"87.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"55.4\" cy=\"136.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"82.9\" cy=\"13.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.4\" cy=\"62.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"138.0\" cy=\"111.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"165.5\" cy=\"160.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"193.1\" cy=\"37.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"20.6\" cy=\"86.1\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"48.2\" cy=\"135.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"75.7\" cy=\"11.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"103.3\" cy=\"60.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"130.8\" cy=\"109.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"146\" cy=\"54\" r=\"43\" fill=\"url(#earth)\" /><path d=\"M125 24l20 6 6 9-11 12-22-4Z\" fill=\"#8bb79c\"/><path d=\"M0 133c42-25 110-20 200 6v33H0Z\" fill=\"#1a5162\"/><path d=\"M0 151c49-10 122-4 200 8\" fill=\"none\" stroke=\"#72b2ad\" stroke-width=\"2\"/><g transform=\"translate(11 37) scale(0.77)\" >\n  <path d=\"M18 116L100 142l82-37-86-23Z\" fill=\"#25485c\" stroke=\"#112c40\" stroke-width=\"2\"/>\n  <path d=\"M18 116v13l82 26v-13Zm82 26v13l82-37v-13Z\" fill=\"#142b40\"/>\n  <path d=\"M76 54l22-11 24 8v73l-23 11-23-8Z\" fill=\"#d0ded8\" stroke=\"#18354b\" stroke-width=\"2\"/>\n  <path d=\"M98 43v92l24-11V51Z\" fill=\"#83a5b1\"/>\n  <path d=\"M35 86l20-10 20 8v45l-21 10-19-6Z\" fill=\"#bbd0d0\" stroke=\"#19384d\" stroke-width=\"2\"/>\n  <path d=\"M55 76v63l20-10V84Z\" fill=\"#638c9e\"/>\n  <path d=\"M130 72l16-8 17 7v49l-16 8-17-5Z\" fill=\"#cbdad6\" stroke=\"#18384a\" stroke-width=\"2\"/>\n  <path d=\"M146 64v64l17-8V71Z\" fill=\"#668e9d\"/>\n  <path d=\"M83 63l9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm21-30 10-5v7l-10 5Zm0 18 10-5v7l-10 5Zm0 18 10-5v7l-10 5ZM42 94l8 3v6l-8-3Zm0 15 8 3v6l-8-3Zm93-27 7 3v6l-7-3Zm0 16 7 3v6l-7-3Z\" fill=\"#e4ca89\"/>\n  <path d=\"M98 43V24m-8 11h17\" stroke=\"#bfd5d4\" stroke-width=\"2\"/>\n  <circle cx=\"98\" cy=\"23\" r=\"3\" fill=\"#e4ca89\" />\n</g><path d=\"M123 145v-24c0-26 49-26 49 0v24\" fill=\"url(#glass)\" stroke=\"#aecbca\" stroke-width=\"2\"/><path d=\"M132 118c4-16 23-20 31-6m-17-8v39m-18-21h40\" fill=\"none\" stroke=\"#b6d4d2\" stroke-width=\"1\"/></g>",
	resort: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"124.8\" cy=\"65.7\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"152.4\" cy=\"114.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.9\" cy=\"163.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.4\" cy=\"40.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"35.0\" cy=\"89.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.5\" cy=\"138.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"90.1\" cy=\"15.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.6\" cy=\"64.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"145.2\" cy=\"113.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.7\" cy=\"161.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"0.3\" cy=\"38.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"27.8\" cy=\"87.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"55.4\" cy=\"136.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"82.9\" cy=\"13.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.4\" cy=\"62.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"138.0\" cy=\"111.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"165.5\" cy=\"160.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"193.1\" cy=\"37.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"20.6\" cy=\"86.1\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"48.2\" cy=\"135.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"75.7\" cy=\"11.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"103.3\" cy=\"60.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"130.8\" cy=\"109.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"146\" cy=\"54\" r=\"43\" fill=\"url(#earth)\" /><path d=\"M125 24l20 6 6 9-11 12-22-4Z\" fill=\"#8bb79c\"/><path d=\"M0 133c42-25 110-20 200 6v33H0Z\" fill=\"#1a5162\"/><path d=\"M0 151c49-10 122-4 200 8\" fill=\"none\" stroke=\"#72b2ad\" stroke-width=\"2\"/><g transform=\"translate(11 37) scale(0.77)\" >\n  <path d=\"M18 116L100 142l82-37-86-23Z\" fill=\"#25485c\" stroke=\"#112c40\" stroke-width=\"2\"/>\n  <path d=\"M18 116v13l82 26v-13Zm82 26v13l82-37v-13Z\" fill=\"#142b40\"/>\n  <path d=\"M76 54l22-11 24 8v73l-23 11-23-8Z\" fill=\"#d0ded8\" stroke=\"#18354b\" stroke-width=\"2\"/>\n  <path d=\"M98 43v92l24-11V51Z\" fill=\"#83a5b1\"/>\n  <path d=\"M35 86l20-10 20 8v45l-21 10-19-6Z\" fill=\"#bbd0d0\" stroke=\"#19384d\" stroke-width=\"2\"/>\n  <path d=\"M55 76v63l20-10V84Z\" fill=\"#638c9e\"/>\n  <path d=\"M130 72l16-8 17 7v49l-16 8-17-5Z\" fill=\"#cbdad6\" stroke=\"#18384a\" stroke-width=\"2\"/>\n  <path d=\"M146 64v64l17-8V71Z\" fill=\"#668e9d\"/>\n  <path d=\"M83 63l9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm21-30 10-5v7l-10 5Zm0 18 10-5v7l-10 5Zm0 18 10-5v7l-10 5ZM42 94l8 3v6l-8-3Zm0 15 8 3v6l-8-3Zm93-27 7 3v6l-7-3Zm0 16 7 3v6l-7-3Z\" fill=\"#e4ca89\"/>\n  <path d=\"M98 43V24m-8 11h17\" stroke=\"#bfd5d4\" stroke-width=\"2\"/>\n  <circle cx=\"98\" cy=\"23\" r=\"3\" fill=\"#e4ca89\" />\n</g><path d=\"M123 145v-24c0-26 49-26 49 0v24\" fill=\"url(#glass)\" stroke=\"#aecbca\" stroke-width=\"2\"/><path d=\"M132 118c4-16 23-20 31-6m-17-8v39m-18-21h40\" fill=\"none\" stroke=\"#b6d4d2\" stroke-width=\"1\"/><path d=\"M20 145c5-24 12-43 21-50m-12 23-13-13m12 13 18-5\" fill=\"none\" stroke=\"#90b28c\" stroke-width=\"3\"/></g>",
	crystal: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"145.6\" cy=\"76.7\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"173.2\" cy=\"125.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"0.7\" cy=\"2.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"28.3\" cy=\"51.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"55.8\" cy=\"100.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"83.3\" cy=\"149.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.9\" cy=\"26.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"138.4\" cy=\"75.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"166.0\" cy=\"123.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"193.5\" cy=\"0.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"21.1\" cy=\"49.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"48.6\" cy=\"98.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"76.2\" cy=\"147.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"103.7\" cy=\"24.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.2\" cy=\"73.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"158.8\" cy=\"122.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.3\" cy=\"171.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"13.9\" cy=\"48.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.4\" cy=\"97.0\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"69.0\" cy=\"145.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"96.5\" cy=\"22.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"124.1\" cy=\"71.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"151.6\" cy=\"120.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"149\" cy=\"45\" r=\"23\" fill=\"#4f7d95\" /><path d=\"M0 137l33-32 36 12 39-25 51 24 41-7v63H0Z\" fill=\"#384a65\"/>\n      <path d=\"M49 144l-5-54 20-25 18 20-7 63Z\" fill=\"#65bfce\" stroke=\"#142f46\" stroke-width=\"2\"/><path d=\"M64 65l-3 78 14 5 7-63Z\" fill=\"#3c8fa8\"/><path d=\"M44 90l17 7 21-12m-21 12 3-32\" fill=\"none\" stroke=\"#bae0d8\" stroke-width=\"1.5\"/>\n      <path d=\"M88 150l-4-76 27-42 27 39-14 83Z\" fill=\"#afd9d2\" stroke=\"#143349\" stroke-width=\"2\"/><path d=\"M111 32l-4 112 17 10 14-83Z\" fill=\"#4a9eae\"/><path d=\"M84 74l23 15 31-18m-31 18 4-57\" stroke=\"#d3ebe0\" fill=\"none\" stroke-width=\"2\"/>\n      <path d=\"M140 151l1-35 18-30 14 27-8 39Z\" fill=\"#c6d4e9\" stroke=\"#1b364b\" stroke-width=\"2\"/><path d=\"M159 86l-3 54 9 12 8-39Z\" fill=\"#7b9dc3\"/>\n      <path d=\"M0 156l55-9 20 8 33-8 32 12 60-13v26H0Z\" fill=\"#22334f\"/><path d=\"M25 160l28-3m39 7 23-3m34 0 19-6\" stroke=\"#8cc8cd\" stroke-width=\"1.5\"/>\n    </g>",
	ship: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"83.2\" cy=\"43.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.8\" cy=\"92.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"138.3\" cy=\"141.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"165.8\" cy=\"18.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"193.4\" cy=\"67.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"20.9\" cy=\"116.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"48.5\" cy=\"165.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"76.0\" cy=\"42.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"103.6\" cy=\"91.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.1\" cy=\"140.0\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"158.7\" cy=\"16.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.2\" cy=\"65.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"13.7\" cy=\"114.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.3\" cy=\"163.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"68.8\" cy=\"40.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"96.4\" cy=\"89.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"123.9\" cy=\"138.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"151.5\" cy=\"15.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.0\" cy=\"64.2\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"6.6\" cy=\"113.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"34.1\" cy=\"162.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"61.6\" cy=\"38.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"89.2\" cy=\"87.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"162\" cy=\"146\" r=\"62\" fill=\"url(#planet-night)\" /><ellipse cx=\"100\" cy=\"89\" rx=\"93\" ry=\"56\" transform=\"rotate(-27 100 89)\" fill=\"none\" stroke=\"#a2c0cc\" stroke-width=\"1.2\" opacity=\".55\"/><g transform=\"translate(-6 -2) scale(1)\" >\n  <path d=\"M37 112L17 133l45-6 29-26Z\" fill=\"#436980\" stroke=\"#142b40\" stroke-width=\"2\"/>\n  <path d=\"M78 88L47 59l11-10 57 24Z\" fill=\"#cbd8d4\" stroke=\"#1c384d\" stroke-width=\"2\"/>\n  <path d=\"M60 105L119 52l57-18-20 41-76 48Z\" fill=\"url(#hull)\" stroke=\"#163349\" stroke-width=\"2\" stroke-linejoin=\"round\"/>\n  <path d=\"M60 105l20 18 76-48 20-41-57 40Z\" fill=\"#809eac\"/>\n  <path d=\"M75 102l44-49 57-19-57 40Z\" fill=\"#edf1df\"/>\n  <path d=\"M90 99l9-8 12 9-13 9Zm19-18 10-8 12 8-13 9Zm24-17 16-9 8 1-13 13Z\" fill=\"#416b82\"/>\n  <path d=\"M80 123l-2-18 13 8M113 83l12 10m9-24 11 9m-47 15 13 9\" fill=\"none\" stroke=\"#304d64\" stroke-width=\"1.5\"/>\n  <path d=\"M122 106l-2 30 37-50-1-11Z\" fill=\"#d3dcd6\" stroke=\"#1b384c\" stroke-width=\"2\"/>\n  <path d=\"M120 136l12-33 24-28\" fill=\"none\" stroke=\"#7797a8\" stroke-width=\"2\"/>\n  <path d=\"M45 114l-12 5 6 8 16-6Z\" fill=\"#243f58\" stroke=\"#112b40\" stroke-width=\"2\"/>\n  <path d=\"M38 120L15 131l22-3Z\" fill=\"#7fe0df\"/>\n  <path d=\"M38 120L6 139l31-11Z\" fill=\"#8ad7da\" opacity=\".24\"/>\n  <path d=\"M152 49l9-5-5 10-9 4Z\" fill=\"#6ac5d1\"/>\n  <path d=\"M73 110l7 4m59-57 5-4m-25 31 5-4\" stroke=\"#e5c179\" stroke-width=\"2\" stroke-linecap=\"round\"/>\n</g></g>",
	fleet: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"104.0\" cy=\"54.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.6\" cy=\"103.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"159.1\" cy=\"152.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.6\" cy=\"29.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"14.2\" cy=\"78.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.7\" cy=\"127.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"69.3\" cy=\"4.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"96.8\" cy=\"53.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"124.4\" cy=\"102.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"151.9\" cy=\"150.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.5\" cy=\"27.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.0\" cy=\"76.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"34.5\" cy=\"125.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.1\" cy=\"2.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"89.6\" cy=\"51.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.2\" cy=\"100.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"144.7\" cy=\"149.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.3\" cy=\"26.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"199.8\" cy=\"75.1\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"27.4\" cy=\"124.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"54.9\" cy=\"0.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"82.4\" cy=\"49.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.0\" cy=\"98.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"162\" cy=\"146\" r=\"62\" fill=\"url(#planet-night)\" /><ellipse cx=\"100\" cy=\"89\" rx=\"93\" ry=\"56\" transform=\"rotate(-27 100 89)\" fill=\"none\" stroke=\"#a2c0cc\" stroke-width=\"1.2\" opacity=\".55\"/><g transform=\"translate(-6 -2) scale(1)\" >\n  <path d=\"M37 112L17 133l45-6 29-26Z\" fill=\"#436980\" stroke=\"#142b40\" stroke-width=\"2\"/>\n  <path d=\"M78 88L47 59l11-10 57 24Z\" fill=\"#d6b66f\" stroke=\"#1c384d\" stroke-width=\"2\"/>\n  <path d=\"M60 105L119 52l57-18-20 41-76 48Z\" fill=\"url(#hull)\" stroke=\"#163349\" stroke-width=\"2\" stroke-linejoin=\"round\"/>\n  <path d=\"M60 105l20 18 76-48 20-41-57 40Z\" fill=\"#809eac\"/>\n  <path d=\"M75 102l44-49 57-19-57 40Z\" fill=\"#edf1df\"/>\n  <path d=\"M90 99l9-8 12 9-13 9Zm19-18 10-8 12 8-13 9Zm24-17 16-9 8 1-13 13Z\" fill=\"#416b82\"/>\n  <path d=\"M80 123l-2-18 13 8M113 83l12 10m9-24 11 9m-47 15 13 9\" fill=\"none\" stroke=\"#304d64\" stroke-width=\"1.5\"/>\n  <path d=\"M122 106l-2 30 37-50-1-11Z\" fill=\"#d3dcd6\" stroke=\"#1b384c\" stroke-width=\"2\"/>\n  <path d=\"M120 136l12-33 24-28\" fill=\"none\" stroke=\"#7797a8\" stroke-width=\"2\"/>\n  <path d=\"M45 114l-12 5 6 8 16-6Z\" fill=\"#243f58\" stroke=\"#112b40\" stroke-width=\"2\"/>\n  <path d=\"M38 120L15 131l22-3Z\" fill=\"#7fe0df\"/>\n  <path d=\"M38 120L6 139l31-11Z\" fill=\"#8ad7da\" opacity=\".24\"/>\n  <path d=\"M152 49l9-5-5 10-9 4Z\" fill=\"#e9d17f\"/>\n  <path d=\"M73 110l7 4m59-57 5-4m-25 31 5-4\" stroke=\"#e5c179\" stroke-width=\"2\" stroke-linecap=\"round\"/>\n</g><g transform=\"translate(89 80) scale(0.42)\" >\n  <path d=\"M37 112L17 133l45-6 29-26Z\" fill=\"#436980\" stroke=\"#142b40\" stroke-width=\"2\"/>\n  <path d=\"M78 88L47 59l11-10 57 24Z\" fill=\"#d6b66f\" stroke=\"#1c384d\" stroke-width=\"2\"/>\n  <path d=\"M60 105L119 52l57-18-20 41-76 48Z\" fill=\"url(#hull)\" stroke=\"#163349\" stroke-width=\"2\" stroke-linejoin=\"round\"/>\n  <path d=\"M60 105l20 18 76-48 20-41-57 40Z\" fill=\"#809eac\"/>\n  <path d=\"M75 102l44-49 57-19-57 40Z\" fill=\"#edf1df\"/>\n  <path d=\"M90 99l9-8 12 9-13 9Zm19-18 10-8 12 8-13 9Zm24-17 16-9 8 1-13 13Z\" fill=\"#416b82\"/>\n  <path d=\"M80 123l-2-18 13 8M113 83l12 10m9-24 11 9m-47 15 13 9\" fill=\"none\" stroke=\"#304d64\" stroke-width=\"1.5\"/>\n  <path d=\"M122 106l-2 30 37-50-1-11Z\" fill=\"#d3dcd6\" stroke=\"#1b384c\" stroke-width=\"2\"/>\n  <path d=\"M120 136l12-33 24-28\" fill=\"none\" stroke=\"#7797a8\" stroke-width=\"2\"/>\n  <path d=\"M45 114l-12 5 6 8 16-6Z\" fill=\"#243f58\" stroke=\"#112b40\" stroke-width=\"2\"/>\n  <path d=\"M38 120L15 131l22-3Z\" fill=\"#7fe0df\"/>\n  <path d=\"M38 120L6 139l31-11Z\" fill=\"#8ad7da\" opacity=\".24\"/>\n  <path d=\"M152 49l9-5-5 10-9 4Z\" fill=\"#e9d17f\"/>\n  <path d=\"M73 110l7 4m59-57 5-4m-25 31 5-4\" stroke=\"#e5c179\" stroke-width=\"2\" stroke-linecap=\"round\"/>\n</g><g transform=\"translate(25 -8) scale(0.38)\" >\n  <path d=\"M37 112L17 133l45-6 29-26Z\" fill=\"#436980\" stroke=\"#142b40\" stroke-width=\"2\"/>\n  <path d=\"M78 88L47 59l11-10 57 24Z\" fill=\"#d6b66f\" stroke=\"#1c384d\" stroke-width=\"2\"/>\n  <path d=\"M60 105L119 52l57-18-20 41-76 48Z\" fill=\"url(#hull)\" stroke=\"#163349\" stroke-width=\"2\" stroke-linejoin=\"round\"/>\n  <path d=\"M60 105l20 18 76-48 20-41-57 40Z\" fill=\"#809eac\"/>\n  <path d=\"M75 102l44-49 57-19-57 40Z\" fill=\"#edf1df\"/>\n  <path d=\"M90 99l9-8 12 9-13 9Zm19-18 10-8 12 8-13 9Zm24-17 16-9 8 1-13 13Z\" fill=\"#416b82\"/>\n  <path d=\"M80 123l-2-18 13 8M113 83l12 10m9-24 11 9m-47 15 13 9\" fill=\"none\" stroke=\"#304d64\" stroke-width=\"1.5\"/>\n  <path d=\"M122 106l-2 30 37-50-1-11Z\" fill=\"#d3dcd6\" stroke=\"#1b384c\" stroke-width=\"2\"/>\n  <path d=\"M120 136l12-33 24-28\" fill=\"none\" stroke=\"#7797a8\" stroke-width=\"2\"/>\n  <path d=\"M45 114l-12 5 6 8 16-6Z\" fill=\"#243f58\" stroke=\"#112b40\" stroke-width=\"2\"/>\n  <path d=\"M38 120L15 131l22-3Z\" fill=\"#7fe0df\"/>\n  <path d=\"M38 120L6 139l31-11Z\" fill=\"#8ad7da\" opacity=\".24\"/>\n  <path d=\"M152 49l9-5-5 10-9 4Z\" fill=\"#e9d17f\"/>\n  <path d=\"M73 110l7 4m59-57 5-4m-25 31 5-4\" stroke=\"#e5c179\" stroke-width=\"2\" stroke-linecap=\"round\"/>\n</g></g>",
	laboratory: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"8.0\" cy=\"109.5\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"35.6\" cy=\"158.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"63.1\" cy=\"35.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"90.7\" cy=\"84.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"118.2\" cy=\"133.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"145.7\" cy=\"10.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"173.3\" cy=\"59.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"0.8\" cy=\"107.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"28.4\" cy=\"156.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"55.9\" cy=\"33.7\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"83.5\" cy=\"82.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"111.0\" cy=\"131.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"138.6\" cy=\"8.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"166.1\" cy=\"57.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"193.6\" cy=\"106.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"21.2\" cy=\"155.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"48.7\" cy=\"32.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"76.3\" cy=\"81.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"103.8\" cy=\"129.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.4\" cy=\"6.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"158.9\" cy=\"55.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.5\" cy=\"104.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"14.0\" cy=\"153.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"160\" cy=\"40\" r=\"19\" fill=\"#789c97\" /><path d=\"M16 133l86-43 84 32-84 41Z\" fill=\"#365f70\" stroke=\"#142f46\" stroke-width=\"2\"/><path d=\"M16 133v12l86 27v-9Zm86 30v9l84-37v-13Z\" fill=\"#19384b\"/>\n      <path d=\"M43 121V73l51-25 53 21v48l-53 25Z\" fill=\"#aacbca\" stroke=\"#153449\" stroke-width=\"2\"/>\n      <path d=\"M94 48v94l53-25V69Z\" fill=\"#6d9fa8\"/><path d=\"M43 73l51 20 53-24\" fill=\"none\" stroke=\"#d7e5d7\" stroke-width=\"2\"/>\n      <path d=\"M49 88l32 12v21l-32-12Zm55 11 34-16v22l-34 16Z\" fill=\"#21495e\"/>\n      <path d=\"M56 94v16m8-13v16m8-13v16m39-16v13m8-17v13m9-17v13\" stroke=\"#9ed9c1\" stroke-width=\"3\"/>\n      <ellipse cx=\"94\" cy=\"60\" rx=\"28\" ry=\"13\" fill=\"#e0e9dc\" stroke=\"#17394e\" stroke-width=\"2\"/>\n      <path d=\"M66 60V45c0-35 56-35 56 0v15\" fill=\"url(#glass)\" stroke=\"#beded8\" stroke-width=\"2\"/>\n      <path d=\"M94 18v43m-22-20h44\" stroke=\"#c8e1d5\" stroke-width=\"1.2\"/>\n      <path d=\"M83 28c27 15-7 21 16 33m8-33c-27 15 7 21-16 33m-4-25h15m-17 11h17m-11 9h13\" stroke=\"#e8d6a1\" stroke-width=\"2\" fill=\"none\"/>\n      <path d=\"M158 121v-31m-8 4 17-8m-9 35-15 7\" stroke=\"#adcac7\" stroke-width=\"3\"/>\n    </g>",
	genetics: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"166.4\" cy=\"87.6\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"194.0\" cy=\"136.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"21.5\" cy=\"13.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"49.1\" cy=\"62.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"76.6\" cy=\"111.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"104.1\" cy=\"160.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.7\" cy=\"37.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"159.2\" cy=\"86.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.8\" cy=\"134.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"14.3\" cy=\"11.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.9\" cy=\"60.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"69.4\" cy=\"109.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"97.0\" cy=\"158.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"124.5\" cy=\"35.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"152.0\" cy=\"84.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.6\" cy=\"133.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.1\" cy=\"10.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"34.7\" cy=\"59.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.2\" cy=\"108.0\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"89.8\" cy=\"156.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.3\" cy=\"33.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"144.9\" cy=\"82.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.4\" cy=\"131.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"160\" cy=\"40\" r=\"19\" fill=\"#789c97\" /><path d=\"M16 133l86-43 84 32-84 41Z\" fill=\"#365f70\" stroke=\"#142f46\" stroke-width=\"2\"/><path d=\"M16 133v12l86 27v-9Zm86 30v9l84-37v-13Z\" fill=\"#19384b\"/>\n      <path d=\"M43 121V73l51-25 53 21v48l-53 25Z\" fill=\"#aacbca\" stroke=\"#153449\" stroke-width=\"2\"/>\n      <path d=\"M94 48v94l53-25V69Z\" fill=\"#6d9fa8\"/><path d=\"M43 73l51 20 53-24\" fill=\"none\" stroke=\"#d7e5d7\" stroke-width=\"2\"/>\n      <path d=\"M49 88l32 12v21l-32-12Zm55 11 34-16v22l-34 16Z\" fill=\"#21495e\"/>\n      <path d=\"M56 94v16m8-13v16m8-13v16m39-16v13m8-17v13m9-17v13\" stroke=\"#9ed9c1\" stroke-width=\"3\"/>\n      <ellipse cx=\"94\" cy=\"60\" rx=\"28\" ry=\"13\" fill=\"#e0e9dc\" stroke=\"#17394e\" stroke-width=\"2\"/>\n      <path d=\"M66 60V45c0-35 56-35 56 0v15\" fill=\"url(#glass)\" stroke=\"#beded8\" stroke-width=\"2\"/>\n      <path d=\"M94 18v43m-22-20h44\" stroke=\"#c8e1d5\" stroke-width=\"1.2\"/>\n      <path d=\"M83 28c27 15-7 21 16 33m8-33c-27 15 7 21-16 33m-4-25h15m-17 11h17m-11 9h13\" stroke=\"#e8d6a1\" stroke-width=\"2\" fill=\"none\"/>\n      <path d=\"M158 121v-31m-8 4 17-8m-9 35-15 7\" stroke=\"#adcac7\" stroke-width=\"3\"/>\n    </g>",
	federation: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"8.0\" cy=\"109.5\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"35.6\" cy=\"158.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"63.1\" cy=\"35.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"90.7\" cy=\"84.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"118.2\" cy=\"133.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"145.7\" cy=\"10.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"173.3\" cy=\"59.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"0.8\" cy=\"107.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"28.4\" cy=\"156.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"55.9\" cy=\"33.7\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"83.5\" cy=\"82.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"111.0\" cy=\"131.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"138.6\" cy=\"8.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"166.1\" cy=\"57.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"193.6\" cy=\"106.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"21.2\" cy=\"155.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"48.7\" cy=\"32.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"76.3\" cy=\"81.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"103.8\" cy=\"129.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.4\" cy=\"6.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"158.9\" cy=\"55.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.5\" cy=\"104.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"14.0\" cy=\"153.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"108\" cy=\"101\" r=\"62\" fill=\"url(#earth)\" /><path d=\"M55 99l25-14 14 4 10-16 21 11 4 24 21 9-18 30-33-6-5-22-20-3Z\" fill=\"#9cb89c\"/><g transform=\"translate(54 11) scale(0.63)\" >\n  <path d=\"M18 116L100 142l82-37-86-23Z\" fill=\"#25485c\" stroke=\"#112c40\" stroke-width=\"2\"/>\n  <path d=\"M18 116v13l82 26v-13Zm82 26v13l82-37v-13Z\" fill=\"#142b40\"/>\n  <path d=\"M76 54l22-11 24 8v73l-23 11-23-8Z\" fill=\"#d0ded8\" stroke=\"#18354b\" stroke-width=\"2\"/>\n  <path d=\"M98 43v92l24-11V51Z\" fill=\"#83a5b1\"/>\n  <path d=\"M35 86l20-10 20 8v45l-21 10-19-6Z\" fill=\"#bbd0d0\" stroke=\"#19384d\" stroke-width=\"2\"/>\n  <path d=\"M55 76v63l20-10V84Z\" fill=\"#638c9e\"/>\n  <path d=\"M130 72l16-8 17 7v49l-16 8-17-5Z\" fill=\"#cbdad6\" stroke=\"#18384a\" stroke-width=\"2\"/>\n  <path d=\"M146 64v64l17-8V71Z\" fill=\"#668e9d\"/>\n  <path d=\"M83 63l9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm21-30 10-5v7l-10 5Zm0 18 10-5v7l-10 5Zm0 18 10-5v7l-10 5ZM42 94l8 3v6l-8-3Zm0 15 8 3v6l-8-3Zm93-27 7 3v6l-7-3Zm0 16 7 3v6l-7-3Z\" fill=\"#ead098\"/>\n  <path d=\"M98 43V24m-8 11h17\" stroke=\"#bfd5d4\" stroke-width=\"2\"/>\n  <circle cx=\"98\" cy=\"23\" r=\"3\" fill=\"#ead098\" />\n</g><ellipse cx=\"105\" cy=\"103\" rx=\"88\" ry=\"28\" transform=\"rotate(-19 105 103)\" fill=\"none\" stroke=\"#112b40\" stroke-width=\"10\"/><ellipse cx=\"105\" cy=\"101\" rx=\"88\" ry=\"28\" transform=\"rotate(-19 105 101)\" fill=\"none\" stroke=\"#d9dbbe\" stroke-width=\"6\"/><path d=\"M27 122l6 11m139-55 6 11m-85 35 3 10\" stroke=\"#5e8494\" stroke-width=\"3\"/><circle cx=\"22\" cy=\"116\" r=\"5\" fill=\"#e6c67f\" stroke=\"#1b384c\" stroke-width=\"2\"/><circle cx=\"186\" cy=\"85\" r=\"5\" fill=\"#e6c67f\" stroke=\"#1b384c\" stroke-width=\"2\"/></g>",
	alien: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"104.0\" cy=\"54.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.6\" cy=\"103.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"159.1\" cy=\"152.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.6\" cy=\"29.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"14.2\" cy=\"78.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.7\" cy=\"127.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"69.3\" cy=\"4.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"96.8\" cy=\"53.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"124.4\" cy=\"102.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"151.9\" cy=\"150.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.5\" cy=\"27.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.0\" cy=\"76.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"34.5\" cy=\"125.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.1\" cy=\"2.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"89.6\" cy=\"51.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.2\" cy=\"100.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"144.7\" cy=\"149.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.3\" cy=\"26.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"199.8\" cy=\"75.1\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"27.4\" cy=\"124.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"54.9\" cy=\"0.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"82.4\" cy=\"49.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.0\" cy=\"98.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"144\" cy=\"51\" r=\"49\" fill=\"url(#red-world)\" /><path d=\"M0 143l33-14 33 6 44-15 90 29v23H0Z\" fill=\"#535369\"/><path d=\"M21 145l84-46 74 36-77 36Z\" fill=\"#263b51\"/>\n      <path d=\"M61 126l14-54 29-37 28 31 16 57-44 28Z\" fill=\"#b8bca3\" stroke=\"#1b3548\" stroke-width=\"2\"/><path d=\"M104 35v116l44-28-16-57Z\" fill=\"#71878a\"/>\n      <path d=\"M90 68l14-18 13 18-13 13Z\" fill=\"#efd184\" stroke=\"#405864\" stroke-width=\"2\"/>\n      <path d=\"M84 85l-5 31 16 7V91Zm30 6 5 32 14-8-7-31Z\" fill=\"#293e50\"/>\n      <path d=\"M85 96l-3 14 9 4m28-17 4 14 6-3\" fill=\"none\" stroke=\"#e5c67b\" stroke-width=\"2\"/>\n      <path d=\"M46 140l7-25 12-5m81-2 12 8 7 25M104 35V18\" fill=\"none\" stroke=\"#a5b4a6\" stroke-width=\"5\"/>\n      <circle cx=\"104\" cy=\"16\" r=\"4\" fill=\"#eac976\" /><path d=\"M13 156l15-3m136 4 16-4m-73 9 10-5\" stroke=\"#cfb781\" stroke-width=\"2\"/>\n    </g>",
	robot: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"104.0\" cy=\"54.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.6\" cy=\"103.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"159.1\" cy=\"152.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.6\" cy=\"29.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"14.2\" cy=\"78.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.7\" cy=\"127.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"69.3\" cy=\"4.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"96.8\" cy=\"53.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"124.4\" cy=\"102.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"151.9\" cy=\"150.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.5\" cy=\"27.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.0\" cy=\"76.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"34.5\" cy=\"125.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.1\" cy=\"2.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"89.6\" cy=\"51.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.2\" cy=\"100.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"144.7\" cy=\"149.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.3\" cy=\"26.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"199.8\" cy=\"75.1\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"27.4\" cy=\"124.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"54.9\" cy=\"0.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"82.4\" cy=\"49.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.0\" cy=\"98.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"144\" cy=\"42\" r=\"37\" fill=\"#2e5f73\" /><path d=\"M55 53l19-16 38 5 19 28-15 41-47-3-22-29Z\" fill=\"url(#hull)\" stroke=\"#153147\" stroke-width=\"3\"/><path d=\"M63 65l43 5 10 14-11 15-38-5-9-16Z\" fill=\"#254d60\"/><path d=\"M67 76l13 2m12 2 12 2\" stroke=\"#92d8d7\" stroke-width=\"5\" stroke-linecap=\"round\"/>\n      <path d=\"M72 109l-11 30 37 20 34-26-18-24M60 124l-22 2-15 24m102-30 24-7 21 28\" fill=\"#96b6bc\" stroke=\"#19364d\" stroke-width=\"5\"/>\n      <path d=\"M77 116l-6 18 24 12 24-15-13-16Z\" fill=\"#426c80\"/><path d=\"M137 59l20-4 10 14-6 21-20-2-10-17Z\" fill=\"#ccdacf\" stroke=\"#1a364b\" stroke-width=\"2\"/><path d=\"M141 72l15 2\" stroke=\"#73c2ca\" stroke-width=\"3\"/>\n    </g>",
	trade: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"104.0\" cy=\"54.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.6\" cy=\"103.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"159.1\" cy=\"152.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.6\" cy=\"29.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"14.2\" cy=\"78.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.7\" cy=\"127.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"69.3\" cy=\"4.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"96.8\" cy=\"53.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"124.4\" cy=\"102.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"151.9\" cy=\"150.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.5\" cy=\"27.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.0\" cy=\"76.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"34.5\" cy=\"125.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.1\" cy=\"2.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"89.6\" cy=\"51.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.2\" cy=\"100.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"144.7\" cy=\"149.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.3\" cy=\"26.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"199.8\" cy=\"75.1\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"27.4\" cy=\"124.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"54.9\" cy=\"0.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"82.4\" cy=\"49.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.0\" cy=\"98.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"156\" cy=\"40\" r=\"28\" fill=\"#487a87\" /><g transform=\"translate(-8 25) scale(0.9)\" >\n  <path d=\"M18 116L100 142l82-37-86-23Z\" fill=\"#25485c\" stroke=\"#112c40\" stroke-width=\"2\"/>\n  <path d=\"M18 116v13l82 26v-13Zm82 26v13l82-37v-13Z\" fill=\"#142b40\"/>\n  <path d=\"M76 54l22-11 24 8v73l-23 11-23-8Z\" fill=\"#d0ded8\" stroke=\"#18354b\" stroke-width=\"2\"/>\n  <path d=\"M98 43v92l24-11V51Z\" fill=\"#83a5b1\"/>\n  <path d=\"M35 86l20-10 20 8v45l-21 10-19-6Z\" fill=\"#bbd0d0\" stroke=\"#19384d\" stroke-width=\"2\"/>\n  <path d=\"M55 76v63l20-10V84Z\" fill=\"#638c9e\"/>\n  <path d=\"M130 72l16-8 17 7v49l-16 8-17-5Z\" fill=\"#cbdad6\" stroke=\"#18384a\" stroke-width=\"2\"/>\n  <path d=\"M146 64v64l17-8V71Z\" fill=\"#668e9d\"/>\n  <path d=\"M83 63l9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm21-30 10-5v7l-10 5Zm0 18 10-5v7l-10 5Zm0 18 10-5v7l-10 5ZM42 94l8 3v6l-8-3Zm0 15 8 3v6l-8-3Zm93-27 7 3v6l-7-3Zm0 16 7 3v6l-7-3Z\" fill=\"#edc782\"/>\n  <path d=\"M98 43V24m-8 11h17\" stroke=\"#bfd5d4\" stroke-width=\"2\"/>\n  <circle cx=\"98\" cy=\"23\" r=\"3\" fill=\"#edc782\" />\n</g><path d=\"M119 131l39-21 29 12-39 21Z\" fill=\"#e2bd77\" stroke=\"#193449\" stroke-width=\"2\"/><path d=\"M119 131v18l29 12v-18m0 18 39-21v-18\" fill=\"#a47b56\" stroke=\"#193449\" stroke-width=\"2\"/><path d=\"M132 124l28 12m-14-18 27 11\" stroke=\"#35546b\" stroke-width=\"4\"/><g transform=\"translate(92 -11) scale(0.38)\" >\n  <path d=\"M37 112L17 133l45-6 29-26Z\" fill=\"#436980\" stroke=\"#142b40\" stroke-width=\"2\"/>\n  <path d=\"M78 88L47 59l11-10 57 24Z\" fill=\"#cbd8d4\" stroke=\"#1c384d\" stroke-width=\"2\"/>\n  <path d=\"M60 105L119 52l57-18-20 41-76 48Z\" fill=\"url(#hull)\" stroke=\"#163349\" stroke-width=\"2\" stroke-linejoin=\"round\"/>\n  <path d=\"M60 105l20 18 76-48 20-41-57 40Z\" fill=\"#809eac\"/>\n  <path d=\"M75 102l44-49 57-19-57 40Z\" fill=\"#edf1df\"/>\n  <path d=\"M90 99l9-8 12 9-13 9Zm19-18 10-8 12 8-13 9Zm24-17 16-9 8 1-13 13Z\" fill=\"#416b82\"/>\n  <path d=\"M80 123l-2-18 13 8M113 83l12 10m9-24 11 9m-47 15 13 9\" fill=\"none\" stroke=\"#304d64\" stroke-width=\"1.5\"/>\n  <path d=\"M122 106l-2 30 37-50-1-11Z\" fill=\"#d3dcd6\" stroke=\"#1b384c\" stroke-width=\"2\"/>\n  <path d=\"M120 136l12-33 24-28\" fill=\"none\" stroke=\"#7797a8\" stroke-width=\"2\"/>\n  <path d=\"M45 114l-12 5 6 8 16-6Z\" fill=\"#243f58\" stroke=\"#112b40\" stroke-width=\"2\"/>\n  <path d=\"M38 120L15 131l22-3Z\" fill=\"#7fe0df\"/>\n  <path d=\"M38 120L6 139l31-11Z\" fill=\"#8ad7da\" opacity=\".24\"/>\n  <path d=\"M152 49l9-5-5 10-9 4Z\" fill=\"#6ac5d1\"/>\n  <path d=\"M73 110l7 4m59-57 5-4m-25 31 5-4\" stroke=\"#e5c179\" stroke-width=\"2\" stroke-linecap=\"round\"/>\n</g></g>",
	markets: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"145.6\" cy=\"76.7\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"173.2\" cy=\"125.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"0.7\" cy=\"2.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"28.3\" cy=\"51.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"55.8\" cy=\"100.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"83.3\" cy=\"149.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.9\" cy=\"26.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"138.4\" cy=\"75.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"166.0\" cy=\"123.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"193.5\" cy=\"0.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"21.1\" cy=\"49.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"48.6\" cy=\"98.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"76.2\" cy=\"147.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"103.7\" cy=\"24.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.2\" cy=\"73.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"158.8\" cy=\"122.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.3\" cy=\"171.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"13.9\" cy=\"48.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.4\" cy=\"97.0\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"69.0\" cy=\"145.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"96.5\" cy=\"22.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"124.1\" cy=\"71.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"151.6\" cy=\"120.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"156\" cy=\"40\" r=\"28\" fill=\"#487a87\" /><g transform=\"translate(-8 25) scale(0.9)\" >\n  <path d=\"M18 116L100 142l82-37-86-23Z\" fill=\"#25485c\" stroke=\"#112c40\" stroke-width=\"2\"/>\n  <path d=\"M18 116v13l82 26v-13Zm82 26v13l82-37v-13Z\" fill=\"#142b40\"/>\n  <path d=\"M76 54l22-11 24 8v73l-23 11-23-8Z\" fill=\"#d0ded8\" stroke=\"#18354b\" stroke-width=\"2\"/>\n  <path d=\"M98 43v92l24-11V51Z\" fill=\"#83a5b1\"/>\n  <path d=\"M35 86l20-10 20 8v45l-21 10-19-6Z\" fill=\"#bbd0d0\" stroke=\"#19384d\" stroke-width=\"2\"/>\n  <path d=\"M55 76v63l20-10V84Z\" fill=\"#638c9e\"/>\n  <path d=\"M130 72l16-8 17 7v49l-16 8-17-5Z\" fill=\"#cbdad6\" stroke=\"#18384a\" stroke-width=\"2\"/>\n  <path d=\"M146 64v64l17-8V71Z\" fill=\"#668e9d\"/>\n  <path d=\"M83 63l9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm21-30 10-5v7l-10 5Zm0 18 10-5v7l-10 5Zm0 18 10-5v7l-10 5ZM42 94l8 3v6l-8-3Zm0 15 8 3v6l-8-3Zm93-27 7 3v6l-7-3Zm0 16 7 3v6l-7-3Z\" fill=\"#edc782\"/>\n  <path d=\"M98 43V24m-8 11h17\" stroke=\"#bfd5d4\" stroke-width=\"2\"/>\n  <circle cx=\"98\" cy=\"23\" r=\"3\" fill=\"#edc782\" />\n</g><path d=\"M119 131l39-21 29 12-39 21Z\" fill=\"#e2bd77\" stroke=\"#193449\" stroke-width=\"2\"/><path d=\"M119 131v18l29 12v-18m0 18 39-21v-18\" fill=\"#a47b56\" stroke=\"#193449\" stroke-width=\"2\"/><path d=\"M132 124l28 12m-14-18 27 11\" stroke=\"#35546b\" stroke-width=\"4\"/><g transform=\"translate(92 -11) scale(0.38)\" >\n  <path d=\"M37 112L17 133l45-6 29-26Z\" fill=\"#436980\" stroke=\"#142b40\" stroke-width=\"2\"/>\n  <path d=\"M78 88L47 59l11-10 57 24Z\" fill=\"#cbd8d4\" stroke=\"#1c384d\" stroke-width=\"2\"/>\n  <path d=\"M60 105L119 52l57-18-20 41-76 48Z\" fill=\"url(#hull)\" stroke=\"#163349\" stroke-width=\"2\" stroke-linejoin=\"round\"/>\n  <path d=\"M60 105l20 18 76-48 20-41-57 40Z\" fill=\"#809eac\"/>\n  <path d=\"M75 102l44-49 57-19-57 40Z\" fill=\"#edf1df\"/>\n  <path d=\"M90 99l9-8 12 9-13 9Zm19-18 10-8 12 8-13 9Zm24-17 16-9 8 1-13 13Z\" fill=\"#416b82\"/>\n  <path d=\"M80 123l-2-18 13 8M113 83l12 10m9-24 11 9m-47 15 13 9\" fill=\"none\" stroke=\"#304d64\" stroke-width=\"1.5\"/>\n  <path d=\"M122 106l-2 30 37-50-1-11Z\" fill=\"#d3dcd6\" stroke=\"#1b384c\" stroke-width=\"2\"/>\n  <path d=\"M120 136l12-33 24-28\" fill=\"none\" stroke=\"#7797a8\" stroke-width=\"2\"/>\n  <path d=\"M45 114l-12 5 6 8 16-6Z\" fill=\"#243f58\" stroke=\"#112b40\" stroke-width=\"2\"/>\n  <path d=\"M38 120L15 131l22-3Z\" fill=\"#7fe0df\"/>\n  <path d=\"M38 120L6 139l31-11Z\" fill=\"#8ad7da\" opacity=\".24\"/>\n  <path d=\"M152 49l9-5-5 10-9 4Z\" fill=\"#6ac5d1\"/>\n  <path d=\"M73 110l7 4m59-57 5-4m-25 31 5-4\" stroke=\"#e5c179\" stroke-width=\"2\" stroke-linecap=\"round\"/>\n</g></g>",
	credits: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"145.6\" cy=\"76.7\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"173.2\" cy=\"125.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"0.7\" cy=\"2.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"28.3\" cy=\"51.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"55.8\" cy=\"100.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"83.3\" cy=\"149.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.9\" cy=\"26.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"138.4\" cy=\"75.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"166.0\" cy=\"123.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"193.5\" cy=\"0.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"21.1\" cy=\"49.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"48.6\" cy=\"98.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"76.2\" cy=\"147.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"103.7\" cy=\"24.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.2\" cy=\"73.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"158.8\" cy=\"122.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.3\" cy=\"171.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"13.9\" cy=\"48.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.4\" cy=\"97.0\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"69.0\" cy=\"145.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"96.5\" cy=\"22.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"124.1\" cy=\"71.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"151.6\" cy=\"120.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"145\" cy=\"39\" r=\"28\" fill=\"#355e77\" /><path d=\"M26 129l68-35 80 24-72 41Z\" fill=\"#244459\" stroke=\"#102b40\" stroke-width=\"2\"/><path d=\"M26 129v13l76 30v-13l72-41v12l-72 42\" fill=\"#163047\"/>\n      <path d=\"M49 120V78l46-23 51 17v43l-47 24Z\" fill=\"#bfd0cb\" stroke=\"#163248\" stroke-width=\"2\"/><path d=\"M95 55v84l51-24V72Z\" fill=\"#5c8495\"/><path d=\"M49 78l50 18 47-24\" fill=\"none\" stroke=\"#e0dfc6\" stroke-width=\"2\"/>\n      <path d=\"M61 89v27m14-22v27m34-27v28m14-36v29m14-36v30\" stroke=\"#d7cea3\" stroke-width=\"6\"/>\n      <path d=\"M49 75l45-35 52 29-47 23Z\" fill=\"url(#gold)\" stroke=\"#163348\" stroke-width=\"2\"/>\n      <path d=\"M89 59l10-6 11 6-11 6Z\" fill=\"#436878\"/>\n      <ellipse cx=\"158\" cy=\"134\" rx=\"16\" ry=\"7\" fill=\"#e4c385\" stroke=\"#243e50\" stroke-width=\"2\"/><path d=\"M142 134v10c0 10 32 10 32 0v-10\" fill=\"#b88b4e\" stroke=\"#243e50\" stroke-width=\"2\"/><ellipse cx=\"158\" cy=\"133\" rx=\"16\" ry=\"7\" fill=\"#ead198\" stroke=\"#243e50\" stroke-width=\"2\"/>\n    </g>",
	bank: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"83.2\" cy=\"43.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.8\" cy=\"92.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"138.3\" cy=\"141.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"165.8\" cy=\"18.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"193.4\" cy=\"67.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"20.9\" cy=\"116.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"48.5\" cy=\"165.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"76.0\" cy=\"42.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"103.6\" cy=\"91.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.1\" cy=\"140.0\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"158.7\" cy=\"16.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.2\" cy=\"65.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"13.7\" cy=\"114.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.3\" cy=\"163.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"68.8\" cy=\"40.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"96.4\" cy=\"89.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"123.9\" cy=\"138.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"151.5\" cy=\"15.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.0\" cy=\"64.2\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"6.6\" cy=\"113.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"34.1\" cy=\"162.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"61.6\" cy=\"38.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"89.2\" cy=\"87.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"145\" cy=\"39\" r=\"28\" fill=\"#355e77\" /><path d=\"M26 129l68-35 80 24-72 41Z\" fill=\"#244459\" stroke=\"#102b40\" stroke-width=\"2\"/><path d=\"M26 129v13l76 30v-13l72-41v12l-72 42\" fill=\"#163047\"/>\n      <path d=\"M49 120V78l46-23 51 17v43l-47 24Z\" fill=\"#bfd0cb\" stroke=\"#163248\" stroke-width=\"2\"/><path d=\"M95 55v84l51-24V72Z\" fill=\"#5c8495\"/><path d=\"M49 78l50 18 47-24\" fill=\"none\" stroke=\"#e0dfc6\" stroke-width=\"2\"/>\n      <path d=\"M61 89v27m14-22v27m34-27v28m14-36v29m14-36v30\" stroke=\"#d7cea3\" stroke-width=\"6\"/>\n      <path d=\"M49 75l45-35 52 29-47 23Z\" fill=\"url(#gold)\" stroke=\"#163348\" stroke-width=\"2\"/>\n      <path d=\"M89 59l10-6 11 6-11 6Z\" fill=\"#436878\"/>\n      <ellipse cx=\"158\" cy=\"134\" rx=\"16\" ry=\"7\" fill=\"#e4c385\" stroke=\"#243e50\" stroke-width=\"2\"/><path d=\"M142 134v10c0 10 32 10 32 0v-10\" fill=\"#b88b4e\" stroke=\"#243e50\" stroke-width=\"2\"/><ellipse cx=\"158\" cy=\"133\" rx=\"16\" ry=\"7\" fill=\"#ead198\" stroke=\"#243e50\" stroke-width=\"2\"/>\n    </g>",
	works: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"104.0\" cy=\"54.8\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"131.6\" cy=\"103.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"159.1\" cy=\"152.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"186.6\" cy=\"29.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"14.2\" cy=\"78.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"41.7\" cy=\"127.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"69.3\" cy=\"4.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"96.8\" cy=\"53.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"124.4\" cy=\"102.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"151.9\" cy=\"150.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.5\" cy=\"27.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.0\" cy=\"76.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"34.5\" cy=\"125.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.1\" cy=\"2.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"89.6\" cy=\"51.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.2\" cy=\"100.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"144.7\" cy=\"149.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.3\" cy=\"26.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"199.8\" cy=\"75.1\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"27.4\" cy=\"124.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"54.9\" cy=\"0.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"82.4\" cy=\"49.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.0\" cy=\"98.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"160\" cy=\"35\" r=\"24\" fill=\"#386780\" /><g transform=\"translate(-4 45) scale(0.75)\" >\n  <path d=\"M18 116L100 142l82-37-86-23Z\" fill=\"#25485c\" stroke=\"#112c40\" stroke-width=\"2\"/>\n  <path d=\"M18 116v13l82 26v-13Zm82 26v13l82-37v-13Z\" fill=\"#142b40\"/>\n  <path d=\"M76 54l22-11 24 8v73l-23 11-23-8Z\" fill=\"#d0ded8\" stroke=\"#18354b\" stroke-width=\"2\"/>\n  <path d=\"M98 43v92l24-11V51Z\" fill=\"#83a5b1\"/>\n  <path d=\"M35 86l20-10 20 8v45l-21 10-19-6Z\" fill=\"#bbd0d0\" stroke=\"#19384d\" stroke-width=\"2\"/>\n  <path d=\"M55 76v63l20-10V84Z\" fill=\"#638c9e\"/>\n  <path d=\"M130 72l16-8 17 7v49l-16 8-17-5Z\" fill=\"#cbdad6\" stroke=\"#18384a\" stroke-width=\"2\"/>\n  <path d=\"M146 64v64l17-8V71Z\" fill=\"#668e9d\"/>\n  <path d=\"M83 63l9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm21-30 10-5v7l-10 5Zm0 18 10-5v7l-10 5Zm0 18 10-5v7l-10 5ZM42 94l8 3v6l-8-3Zm0 15 8 3v6l-8-3Zm93-27 7 3v6l-7-3Zm0 16 7 3v6l-7-3Z\" fill=\"#77bec8\"/>\n  <path d=\"M98 43V24m-8 11h17\" stroke=\"#bfd5d4\" stroke-width=\"2\"/>\n  <circle cx=\"98\" cy=\"23\" r=\"3\" fill=\"#77bec8\" />\n</g><path d=\"M120 142V38m-39 6 90-21m-22 5v53m-6 0h12m-35-43-20 10m20-10 17-10\" stroke=\"#c6b17b\" stroke-width=\"5\" fill=\"none\"/><path d=\"M84 148l36-15 33 10-36 16Z\" fill=\"#c7b583\"/><path d=\"M106 48l14-10 17-10\" stroke=\"#27435a\" stroke-width=\"2\"/></g>",
	mining: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"124.8\" cy=\"65.7\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"152.4\" cy=\"114.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.9\" cy=\"163.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.4\" cy=\"40.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"35.0\" cy=\"89.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.5\" cy=\"138.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"90.1\" cy=\"15.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.6\" cy=\"64.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"145.2\" cy=\"113.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.7\" cy=\"161.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"0.3\" cy=\"38.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"27.8\" cy=\"87.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"55.4\" cy=\"136.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"82.9\" cy=\"13.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.4\" cy=\"62.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"138.0\" cy=\"111.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"165.5\" cy=\"160.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"193.1\" cy=\"37.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"20.6\" cy=\"86.1\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"48.2\" cy=\"135.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"75.7\" cy=\"11.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"103.3\" cy=\"60.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"130.8\" cy=\"109.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"156\" cy=\"39\" r=\"17\" fill=\"#e5ca91\" /><path d=\"M0 123l49-40 37 37 36-23 78 43v32H0Z\" fill=\"#ac947f\"/><path d=\"M0 146l43-17 54 18 37-11 66 23v13H0Z\" fill=\"#6c6b72\"/><g transform=\"translate(32 37) scale(0.66)\" >\n  <path d=\"M18 116L100 142l82-37-86-23Z\" fill=\"#25485c\" stroke=\"#112c40\" stroke-width=\"2\"/>\n  <path d=\"M18 116v13l82 26v-13Zm82 26v13l82-37v-13Z\" fill=\"#142b40\"/>\n  <path d=\"M76 54l22-11 24 8v73l-23 11-23-8Z\" fill=\"#d0ded8\" stroke=\"#18354b\" stroke-width=\"2\"/>\n  <path d=\"M98 43v92l24-11V51Z\" fill=\"#83a5b1\"/>\n  <path d=\"M35 86l20-10 20 8v45l-21 10-19-6Z\" fill=\"#bbd0d0\" stroke=\"#19384d\" stroke-width=\"2\"/>\n  <path d=\"M55 76v63l20-10V84Z\" fill=\"#638c9e\"/>\n  <path d=\"M130 72l16-8 17 7v49l-16 8-17-5Z\" fill=\"#cbdad6\" stroke=\"#18384a\" stroke-width=\"2\"/>\n  <path d=\"M146 64v64l17-8V71Z\" fill=\"#668e9d\"/>\n  <path d=\"M83 63l9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm21-30 10-5v7l-10 5Zm0 18 10-5v7l-10 5Zm0 18 10-5v7l-10 5ZM42 94l8 3v6l-8-3Zm0 15 8 3v6l-8-3Zm93-27 7 3v6l-7-3Zm0 16 7 3v6l-7-3Z\" fill=\"#e1be7a\"/>\n  <path d=\"M98 43V24m-8 11h17\" stroke=\"#bfd5d4\" stroke-width=\"2\"/>\n  <circle cx=\"98\" cy=\"23\" r=\"3\" fill=\"#e1be7a\" />\n</g><path d=\"M130 143l13-45 30-14m-30 14 25 8m-38 37 20 10m-4-56 9-19 12 6\" fill=\"none\" stroke=\"#c2ccbd\" stroke-width=\"4\"/><path d=\"M13 157l18-3m148 10 12-3\" stroke=\"#d2b18c\" stroke-width=\"2\"/></g>",
	desert: "<g clip-path=\"url(#art-clip)\"><rect x=\"0\" y=\"0\" width=\"200\" height=\"172\" rx=\"2\" fill=\"url(#space)\" /><circle opacity=\"0.65\" cx=\"124.8\" cy=\"65.7\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"152.4\" cy=\"114.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"179.9\" cy=\"163.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"7.4\" cy=\"40.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"35.0\" cy=\"89.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"62.5\" cy=\"138.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"90.1\" cy=\"15.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"117.6\" cy=\"64.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"145.2\" cy=\"113.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"172.7\" cy=\"161.9\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"0.3\" cy=\"38.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"27.8\" cy=\"87.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"55.4\" cy=\"136.6\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"82.9\" cy=\"13.5\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"110.4\" cy=\"62.4\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"138.0\" cy=\"111.3\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"165.5\" cy=\"160.2\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"193.1\" cy=\"37.1\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"20.6\" cy=\"86.1\" r=\"1.35\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"48.2\" cy=\"135.0\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"75.7\" cy=\"11.9\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"103.3\" cy=\"60.8\" r=\"0.65\" fill=\"#d6e5ed\" /><circle opacity=\"0.65\" cx=\"130.8\" cy=\"109.7\" r=\"0.65\" fill=\"#d6e5ed\" /><circle cx=\"156\" cy=\"39\" r=\"17\" fill=\"#e5ca91\" /><path d=\"M0 123l49-40 37 37 36-23 78 43v32H0Z\" fill=\"#ac947f\"/><path d=\"M0 146l43-17 54 18 37-11 66 23v13H0Z\" fill=\"#6c6b72\"/><g transform=\"translate(32 37) scale(0.66)\" >\n  <path d=\"M18 116L100 142l82-37-86-23Z\" fill=\"#25485c\" stroke=\"#112c40\" stroke-width=\"2\"/>\n  <path d=\"M18 116v13l82 26v-13Zm82 26v13l82-37v-13Z\" fill=\"#142b40\"/>\n  <path d=\"M76 54l22-11 24 8v73l-23 11-23-8Z\" fill=\"#d0ded8\" stroke=\"#18354b\" stroke-width=\"2\"/>\n  <path d=\"M98 43v92l24-11V51Z\" fill=\"#83a5b1\"/>\n  <path d=\"M35 86l20-10 20 8v45l-21 10-19-6Z\" fill=\"#bbd0d0\" stroke=\"#19384d\" stroke-width=\"2\"/>\n  <path d=\"M55 76v63l20-10V84Z\" fill=\"#638c9e\"/>\n  <path d=\"M130 72l16-8 17 7v49l-16 8-17-5Z\" fill=\"#cbdad6\" stroke=\"#18384a\" stroke-width=\"2\"/>\n  <path d=\"M146 64v64l17-8V71Z\" fill=\"#668e9d\"/>\n  <path d=\"M83 63l9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm0 17 9 3v7l-9-3Zm21-30 10-5v7l-10 5Zm0 18 10-5v7l-10 5Zm0 18 10-5v7l-10 5ZM42 94l8 3v6l-8-3Zm0 15 8 3v6l-8-3Zm93-27 7 3v6l-7-3Zm0 16 7 3v6l-7-3Z\" fill=\"#e1be7a\"/>\n  <path d=\"M98 43V24m-8 11h17\" stroke=\"#bfd5d4\" stroke-width=\"2\"/>\n  <circle cx=\"98\" cy=\"23\" r=\"3\" fill=\"#e1be7a\" />\n</g><path d=\"M130 143l13-45 30-14m-30 14 25 8m-38 37 20 10m-4-56 9-19 12 6\" fill=\"none\" stroke=\"#c2ccbd\" stroke-width=\"4\"/><path d=\"M13 157l18-3m148 10 12-3\" stroke=\"#d2b18c\" stroke-width=\"2\"/></g>",
	asteroid: "<g clip-path=\"url(#art-clip)\"><rect width=\"200\" height=\"172\" fill=\"url(#space)\"/><circle cx=\"156\" cy=\"35\" r=\"27\" fill=\"url(#planet-night)\"/><path d=\"M0 146l37-16 57 11 52-17 54 19v29H0Z\" fill=\"#304e61\"/><path d=\"M29 89l17-30 28-7 23 20-6 36-31 14-28-9Z\" fill=\"#a69c91\" stroke=\"#1c344d\" stroke-width=\"3\"/><path d=\"M46 59l11 29 40-16m-40 16 3 34m-28-9 25-25\" fill=\"none\" stroke=\"#6d7480\" stroke-width=\"3\"/><path d=\"M125 39l18-15 24 5 11 24-19 16-27-8Zm0 94 18-13 19 17-3 21-22 5-14-15Z\" fill=\"#7c8b98\" stroke=\"#1b324b\" stroke-width=\"3\"/><path d=\"M84 34L25 9m151 105 25 10m-54-42 43-12\" stroke=\"#c7d6d6\" opacity=\".5\"/></g>",
	survey: "<g clip-path=\"url(#art-clip)\"><rect width=\"200\" height=\"172\" fill=\"url(#space)\"/><circle cx=\"156\" cy=\"35\" r=\"27\" fill=\"url(#planet-night)\"/><path d=\"M0 146l37-16 57 11 52-17 54 19v29H0Z\" fill=\"#304e61\"/><path d=\"M60 149l25-48h22l30 48m-62-34h45\" fill=\"#8babb8\" stroke=\"#19364b\" stroke-width=\"4\"/><path d=\"M44 50c-9 43 22 76 62 67L44 50Z\" fill=\"#d7e2d8\" stroke=\"#173248\" stroke-width=\"3\"/><path d=\"M44 50l62 67m-33-36 44-32m-6-7 12 13\" fill=\"none\" stroke=\"#acc8cd\" stroke-width=\"5\"/><path d=\"M130 31c19 2 29 16 30 32m-25-48c26 4 42 23 43 46\" fill=\"none\" stroke=\"#7ec9d2\" stroke-width=\"2\"/></g>",
	avian: "<g clip-path=\"url(#art-clip)\"><rect width=\"200\" height=\"172\" fill=\"url(#space)\"/><circle cx=\"156\" cy=\"35\" r=\"27\" fill=\"url(#planet-night)\"/><path d=\"M0 146l37-16 57 11 52-17 54 19v29H0Z\" fill=\"#304e61\"/><path d=\"M95 87C61 39 35 44 17 31c1 39 27 68 64 76l-18 37 37-20 35 12-13-31c35-4 56-32 65-62-35 6-50 16-72 37l-20 7Z\" fill=\"#bdc9b2\" stroke=\"#1a3547\" stroke-width=\"3\"/><path d=\"M34 47l44 45m-26-38 32 32m86-27-48 34m32-27-37 22\" stroke=\"#728f95\" stroke-width=\"3\"/><path d=\"M93 87c-7-20 14-36 27-22l12 11-18 7-3 19\" fill=\"#dce0c0\" stroke=\"#19374b\" stroke-width=\"2\"/><circle cx=\"115\" cy=\"72\" r=\"3\" fill=\"#20384b\"/></g>",
	reptile: "<g clip-path=\"url(#art-clip)\"><rect width=\"200\" height=\"172\" fill=\"url(#space)\"/><circle cx=\"156\" cy=\"35\" r=\"27\" fill=\"url(#planet-night)\"/><path d=\"M0 146l37-16 57 11 52-17 54 19v29H0Z\" fill=\"#304e61\"/><path d=\"M35 142c-25-30-13-65 13-65-13 13-12 32-2 40l22-9 8-36 38-20 28 19-2 20-24 12 16 32 29 9-6 11-41-10-17-25-21 8-6 26-23-1 5-22-18 10Z\" fill=\"#92b79f\" stroke=\"#173447\" stroke-width=\"3\"/><path d=\"M78 73l8-23 10 10 11-24 8 17 13-12 3 19m-61 54 37-24\" fill=\"#d2c999\" stroke=\"#35585d\" stroke-width=\"2\"/><circle cx=\"128\" cy=\"73\" r=\"4\" fill=\"#edce7c\"/></g>",
	aquatic: "<g clip-path=\"url(#art-clip)\"><rect width=\"200\" height=\"172\" fill=\"url(#space)\"/><circle cx=\"156\" cy=\"35\" r=\"27\" fill=\"url(#planet-night)\"/><path d=\"M0 122c53-29 100 22 200-9v59H0Z\" fill=\"#204a63\"/><path d=\"M23 106c21-39 71-60 112-35l33-12-8 20 25 20-42-1c-25 32-71 43-105 28l-22 15 7-25-13-7Z\" fill=\"#94c8c5\" stroke=\"#18364b\" stroke-width=\"3\"/><path d=\"M76 76l19-25 15 24m-20 32 15 28 17-34\" fill=\"#5d929f\" stroke=\"#244b61\" stroke-width=\"2\"/><path d=\"M37 111c35 11 66 4 95-16\" fill=\"none\" stroke=\"#d5e5d3\" stroke-width=\"3\"/><circle cx=\"135\" cy=\"84\" r=\"3\" fill=\"#18364b\"/><path d=\"M10 150c55-17 115 18 184-6\" fill=\"none\" stroke=\"#6aa6b7\" stroke-width=\"2\"/></g>",
	beast: "<g clip-path=\"url(#art-clip)\"><rect width=\"200\" height=\"172\" fill=\"url(#space)\"/><circle cx=\"156\" cy=\"35\" r=\"27\" fill=\"url(#planet-night)\"/><path d=\"M0 146l37-16 57 11 52-17 54 19v29H0Z\" fill=\"#304e61\"/><path d=\"M46 119C32 90 48 65 79 67l32-15 28 15 26 6 12 26-19 18-22-3-8 31-15 1-3-28-25 4-11 25-16-1 1-30Z\" fill=\"#bfae9b\" stroke=\"#1a354a\" stroke-width=\"3\"/><path d=\"M119 69l-7-28 21 19m9 18 26-3-10 17m-6 11 9 18 8-17\" fill=\"#e0d9be\" stroke=\"#244558\" stroke-width=\"2\"/><circle cx=\"145\" cy=\"90\" r=\"3\" fill=\"#1c354a\"/><path d=\"M54 77l20 28m-6-35 21 31m10-41 8 31\" stroke=\"#7b8e8f\" stroke-width=\"3\"/></g>"
}, nt = {
	"old-earth": "earth",
	"new-earth": "earth",
	"terraformed-world": "earth",
	"alpha-centauri": "binary",
	"epsilon-eridani": "binary",
	"distant-world": "binary",
	"new-sparta": "fortress",
	"imperium-armaments-world": "fortress",
	"rebel-warrior-race": "fortress",
	"rebel-outpost": "rebel",
	"rebel-underground": "rebel",
	"rebel-homeworld": "rebel",
	"rebel-base": "rebel",
	"rebel-fuel-cache": "rebel",
	"earth-s-lost-colony": "colony",
	"former-penal-colony": "colony",
	"new-vinland": "colony",
	"artist-colony": "colony",
	"new-survivalists": "colony",
	"outlaw-world": "colony",
	"refugee-world": "colony",
	"expanding-colony": "colony",
	"prosperous-world": "colony",
	"secluded-world": "colony",
	"pilgrimage-world": "colony",
	"galactic-resort": "resort",
	"tourist-world": "resort",
	"galactic-trendsetters": "resort",
	"galactic-renaissance": "resort",
	"gem-world": "crystal",
	"blaster-gem-mines": "crystal",
	"colony-ship": "ship",
	"expedition-force": "ship",
	"drop-ships": "ship",
	"lost-species-ark-world": "ship",
	"space-marines": "fleet",
	"lost-alien-battle-fleet": "fleet",
	"lost-alien-warship": "fleet",
	"alien-robot-scout-ship": "fleet",
	"pirate-world": "fleet",
	"star-nomad-lair": "fleet",
	"new-military-tactics": "fleet",
	"research-labs": "laboratory",
	"contact-specialist": "laboratory",
	"genetics-lab": "genetics",
	"plague-world": "genetics",
	"empath-world": "genetics",
	"bio-hazard-mining-world": "genetics",
	"galactic-federation": "federation",
	"pan-galactic-league": "federation",
	"new-galactic-order": "federation",
	"galactic-imperium": "federation",
	"alien-robotic-factory": "alien",
	"alien-tech-institute": "alien",
	"deserted-alien-outpost": "alien",
	"deserted-alien-colony": "alien",
	"alien-rosetta-stone-world": "alien",
	"deserted-alien-library": "alien",
	"mining-robots": "robot",
	"alien-robot-sentry": "robot",
	"runaway-robots": "robot",
	"terraforming-robots": "robot",
	"replicant-robots": "robot",
	"diversified-economy": "trade",
	"export-duties": "trade",
	"black-market-trading-world": "trade",
	"merchant-world": "trade",
	"free-trade-association": "trade",
	"trade-league": "trade",
	"merchant-guild": "trade",
	"new-economy": "trade",
	"consumer-markets": "markets",
	"gambling-world": "markets",
	"investment-credits": "credits",
	"deficit-spending": "credits",
	"interstellar-bank": "bank",
	"public-works": "works",
	"galactic-engineers": "works",
	"space-port": "works",
	"mining-world": "mining",
	"rebel-miners": "mining",
	"mining-conglomerate": "mining",
	"mining-league": "mining",
	"radioactive-world": "mining",
	"spice-world": "desert",
	"destroyed-world": "desert",
	"comet-zone": "asteroid",
	"asteroid-belt": "asteroid",
	"galactic-survey-seti": "survey",
	"avian-uplift-race": "avian",
	"reptilian-uplift-race": "reptile",
	"malevolent-lifeforms": "reptile",
	"aquatic-uplift-race": "aquatic",
	"the-last-of-the-uplift-gnarssh": "beast",
	"pre-sentient-race": "beast"
}, rt = {
	NOVELTY: "#60bad8",
	RARE: "#c09169",
	GENE: "#8fc09a",
	ALIEN: "#e2bf68"
}, it = {
	NOVELTY: "M6 8l6 4 6-4m-6 4v8",
	RARE: "M5 8l14 8M5 13l14 8M5 3l14 8",
	GENE: "M7 4c18 5-8 12 10 17m0-17C-1 9 25 16 7 21m2-12h6m-6 7h6",
	ALIEN: "M12 4l7 4v9l-7 4-7-4V8Z"
};
function at({ markup: e, viewBox: t = "0 0 200 172" }) {
	let n = o().replaceAll(":", ""), r = (et + e).replaceAll(/id="([^"]+)"/g, (e, t) => `id="${n}-${t}"`).replaceAll(/url\(#([^)]+)\)/g, (e, t) => `url(#${n}-${t})`);
	return /* @__PURE__ */ y("svg", {
		className: "rftg-illustration",
		viewBox: t,
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: r }
	});
}
function ot({ defId: e }) {
	return /* @__PURE__ */ y(at, { markup: tt[nt[e]] ?? tt.earth });
}
function st({ kind: e }) {
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: /* @__PURE__ */ y("path", {
			d: it[e],
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.8",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	});
}
function ct({ kind: e }) {
	return /* @__PURE__ */ y("span", {
		className: "rftg-cargo",
		style: { color: e ? rt[e] : "#b9cbd4" },
		children: e ? /* @__PURE__ */ y(st, { kind: e }) : /* @__PURE__ */ y(X, {})
	});
}
function X() {
	return /* @__PURE__ */ b("svg", {
		viewBox: "0 0 100 100",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ y("path", {
				d: "M50 6L87 28v44L50 94 13 72V28Z",
				fill: "#172c46",
				stroke: "#e8bd72",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ y("ellipse", {
				cx: "50",
				cy: "50",
				rx: "36",
				ry: "12",
				transform: "rotate(-29 50 50)",
				fill: "none",
				stroke: "#9cced3",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ y("circle", {
				cx: "50",
				cy: "50",
				r: "19",
				fill: "#6aa9bc"
			}),
			/* @__PURE__ */ y("path", {
				d: "M42 34l10 7-6 10 12 9-4 8-13-10-8-13Z",
				fill: "#bed3b5"
			}),
			/* @__PURE__ */ y("path", {
				d: "M50 10v10m0 60v10M18 30l9 5m46 30 9 5",
				stroke: "#e8bd72",
				strokeWidth: "2"
			})
		]
	});
}
var lt = {
	explore: "<svg width=\"54\" height=\"54\" viewBox=\"0 0 54 54\"><path d=\"M12 29l9-10 9 8-8 11-10-9Zm11-12 5-7 11 9-7 6M18 34l-4 9m6-7 8 7M35 13l8-5M38 18l9-2\" fill=\"none\" stroke=\"#6dd4e2\" stroke-width=\"2.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>",
	develop: "<svg width=\"54\" height=\"54\" viewBox=\"0 0 54 54\"><path d=\"M10 40h31M16 40V19l10-6 11 5v22M23 38V25m9 11V23M11 17l16-9 15 8M27 8V4\" fill=\"none\" stroke=\"#6dd4e2\" stroke-width=\"2.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>",
	settle: "<svg width=\"54\" height=\"54\" viewBox=\"0 0 54 54\"><circle cx=\"27\" cy=\"25\" r=\"14\" fill=\"none\" stroke=\"#6dd4e2\" stroke-width=\"2.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 16l9 4-2 10 9 3m-19-4 5 5m19-25-3 5M8 38c-7 7 4 9 20 1s23-18 15-19\" fill=\"none\" stroke=\"#6dd4e2\" stroke-width=\"2.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>",
	trade: "<svg width=\"54\" height=\"54\" viewBox=\"0 0 54 54\"><path d=\"M10 17h30l-7-7m7 7-7 7M42 33H12l7-7m-7 7 7 7\" fill=\"none\" stroke=\"#6dd4e2\" stroke-width=\"2.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>",
	consume: "<svg width=\"54\" height=\"54\" viewBox=\"0 0 54 54\"><path d=\"M10 13h30v25H10Zm0 10h30M20 13v25\" fill=\"none\" stroke=\"#6dd4e2\" stroke-width=\"2.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M34 6v11m-5-5h10\" fill=\"none\" stroke=\"#6dd4e2\" stroke-width=\"2.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>",
	produce: "<svg width=\"54\" height=\"54\" viewBox=\"0 0 54 54\"><path d=\"M10 22l17-9 17 9v19l-17 9-17-9Zm0 0 17 9 17-9M27 31v19M20 8h14m-7-6v12\" fill=\"none\" stroke=\"#6dd4e2\" stroke-width=\"2.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>"
};
function ut({ kind: e }) {
	return /* @__PURE__ */ y("span", {
		className: "rftg-action-symbol",
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: lt[e] ?? lt.explore }
	});
}
//#endregion
//#region src/games/rftg/card.tsx
var dt = {
	1: "I",
	2: "II",
	3: "III",
	4: "IV",
	5: "V"
};
function Z({ ref: e, defId: t, hasGood: n, selected: r, disabled: i, dimmed: a, legal: o, onClick: s, badge: c, anchor: l, inst: u }) {
	let f = m(), p = A(t), h = d(l ?? null), { ref: g, hidden: _ } = d(u === void 0 ? null : `good:${u}`), ee = [...new Set(p.powers.map((e) => e.phase))], v = p.powers[0] ? ft(f, p.powers[0]) : p.good ? J(f, p.good) : f(p.type === "dev" ? "games.rftg.label.dev" : "games.rftg.label.world");
	return /* @__PURE__ */ b("button", {
		ref: (t) => {
			if (h.ref(t), typeof e == "function") return e(t);
			e && (e.current = t);
		},
		type: "button",
		"aria-label": Y(f, t),
		"aria-pressed": s ? !!r : void 0,
		disabled: i || !s,
		onClick: s,
		title: `${Y(f, t)} · ${v}`,
		className: "rftg-card",
		"data-selected": r || void 0,
		"data-legal": o || void 0,
		"data-dimmed": a || void 0,
		"data-military": p.military || void 0,
		style: {
			"--rftg-good": p.good ? rt[p.good] : "#edf1e7",
			visibility: h.hidden ? "hidden" : void 0
		},
		children: [
			/* @__PURE__ */ y("span", {
				className: "rftg-card-art",
				children: /* @__PURE__ */ y(ot, { defId: t })
			}),
			/* @__PURE__ */ y("span", {
				className: "rftg-card-phases",
				"aria-hidden": "true",
				children: ee.map((e) => /* @__PURE__ */ y("span", {
					"data-phase": e,
					children: dt[e]
				}, e))
			}),
			/* @__PURE__ */ y("span", {
				className: "rftg-card-cost",
				"data-type": p.type,
				"data-windfall": p.windfall || void 0,
				"data-good": p.good || void 0,
				children: /* @__PURE__ */ y("span", { children: p.cost })
			}),
			/* @__PURE__ */ y("span", {
				className: "rftg-card-vp",
				children: p.vpBonus ? "?" : p.vp
			}),
			/* @__PURE__ */ b("span", {
				className: "rftg-card-caption",
				children: [/* @__PURE__ */ y("span", {
					className: "rftg-card-name",
					children: Y(f, t)
				}), /* @__PURE__ */ y("span", {
					className: "rftg-card-summary",
					children: v
				})]
			}),
			p.good && /* @__PURE__ */ y("span", {
				className: "rftg-good-mark",
				style: { color: rt[p.good] },
				title: J(f, p.good),
				children: /* @__PURE__ */ y(st, { kind: p.good })
			}),
			a && /* @__PURE__ */ y("span", {
				className: "rftg-card-inactive",
				children: f("games.rftg.label.activeNext")
			}),
			n && p.good && /* @__PURE__ */ y("span", {
				ref: g,
				className: "rftg-card-good",
				style: { visibility: _ ? "hidden" : void 0 },
				children: /* @__PURE__ */ y(ct, { kind: p.good })
			}),
			c && /* @__PURE__ */ y("span", {
				className: "rftg-card-badge",
				children: c
			}),
			r && /* @__PURE__ */ y("span", {
				className: "rftg-card-check",
				"aria-hidden": "true",
				children: "✓"
			})
		]
	});
}
function ft(e, t) {
	let n = (e) => t.codes.includes(e);
	if (t.phase === 1) return e(n("KEEP") ? "games.rftg.brief.keep" : "games.rftg.brief.explore", { n: t.value });
	if (t.phase === 2 && n("DRAW_AFTER")) return e("games.rftg.brief.developAfter", { n: t.value });
	if (t.phase === 2) return e(n("REDUCE") ? "games.rftg.brief.developCost" : "games.rftg.brief.developDraw", { n: t.value || 1 });
	if (t.phase === 3) {
		if (n("DISCARD")) return e(n("REDUCE_ZERO") ? "games.rftg.brief.colonyShip" : "games.rftg.brief.tactics");
		if (n("EXTRA_MILITARY") && !n("AGAINST_REBEL") && !n("ALIEN") && !n("RARE")) return e("games.rftg.brief.military", { n: t.value > 0 ? `+${t.value}` : t.value });
		if (n("REDUCE") && !n("ALIEN") && !n("RARE")) return e("games.rftg.brief.settleCost", { n: t.value });
	}
	if (t.phase === 4) {
		if (n("TRADE_ANY") || n("TRADE_THIS")) return e("games.rftg.brief.trade", { n: t.value });
		if (n("DISCARD_HAND")) return e("games.rftg.brief.discard", { n: t.value });
		if (n("CONSUME_3_DIFF")) return e("games.rftg.brief.different", { n: t.value });
		if (n("CONSUME_TWO")) {
			let r = [
				"NOVELTY",
				"RARE",
				"GENE",
				"ALIEN"
			].find((e) => n(`CONSUME_${e}`));
			return r ? e("games.rftg.brief.pairKind", {
				n: t.value,
				kind: J(e, r)
			}) : e("games.rftg.brief.pair", { n: t.value });
		}
		if (n("GET_VP") && n("GET_CARD")) return e("games.rftg.brief.cardsVp");
		if (n("CONSUME_ANY") && n("GET_VP")) return e("games.rftg.brief.consume", { n: t.value });
	}
	return t.phase === 5 && n("PRODUCE") ? e("games.rftg.brief.produce") : Ze(e, t).replace(/^[IVX]+[:：]\s*/, "");
}
function pt() {
	return /* @__PURE__ */ y("div", {
		className: "rftg-card-back",
		children: /* @__PURE__ */ y(X, {})
	});
}
function mt({ defId: e }) {
	let t = m(), n = A(e);
	return /* @__PURE__ */ b("div", {
		className: "rftg-card-detail",
		children: [/* @__PURE__ */ b("div", {
			className: "rftg-detail-hero",
			children: [/* @__PURE__ */ y(Z, { defId: e }), /* @__PURE__ */ b("div", { children: [
				/* @__PURE__ */ y("h2", { children: Y(t, e) }),
				/* @__PURE__ */ b("p", { children: [
					t(n.type === "dev" ? "games.rftg.label.dev" : "games.rftg.label.world"),
					" · ",
					t(n.military ? "games.rftg.label.defense" : "games.rftg.label.cost"),
					" ",
					n.cost,
					" · ",
					n.vpBonus ? "?" : n.vp,
					" VP"
				] }),
				n.good && /* @__PURE__ */ b("p", { children: [
					J(t, n.good),
					" · ",
					t(n.windfall ? "games.rftg.label.windfall" : "games.rftg.label.production")
				] })
			] })]
		}), /* @__PURE__ */ b("div", {
			className: "rftg-detail-powers",
			children: [n.powers.map((e, n) => /* @__PURE__ */ b("p", { children: [/* @__PURE__ */ y("strong", {
				"data-phase": e.phase,
				children: dt[e.phase]
			}), /* @__PURE__ */ y("span", { children: Ze(t, e).replace(/^[IVX]+[:：]\s*/, "") })] }, n)), $e(n).map((e, n) => /* @__PURE__ */ b("p", { children: [/* @__PURE__ */ y("strong", { children: "VP" }), /* @__PURE__ */ y("span", { children: Qe(t, e) })] }, `b${n}`))]
		})]
	});
}
//#endregion
//#region src/games/rftg/view-player.tsx
function ht(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ y(yt, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var gt = {
	explore5: "explore",
	explore11: "explore",
	develop: "develop",
	settle: "settle",
	trade: "trade",
	consume2x: "consume",
	produce: "produce"
}, _t = {
	explore5: "I",
	explore11: "I",
	develop: "II",
	settle: "III",
	trade: "IV",
	consume2x: "IV",
	produce: "V"
}, vt = r(null);
function Q({ children: e }) {
	let t = i(vt);
	return t ? u(/* @__PURE__ */ y("div", {
		className: "rftg-confirm-bar",
		children: e
	}), t) : null;
}
function yt({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let a = m(), o = p((e) => e.locale), s = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? _(t, o) : e;
	}, u = c({}), [v, x] = l(null), { ref: te } = d("deck"), { ref: ne } = d("table"), { ref: S } = d("hand"), { ref: C } = d("console"), { ref: w } = d("hand-card"), [T, E] = l([]), [D, O] = l(null), [k, ie] = l(null), [j, M] = l(null), N = `${e.phase}|${e.round}|${e.waiting.includes(r)}|${t?.payDue?.inst ?? ""}`, [oe, se] = l(N);
	if (oe !== N && (se(N), E([]), O(null), ie(null)), !t) return null;
	let P = e.players.find((e) => e.rid === r), F = e.phase !== "done" && e.waiting.includes(r), ce = (e, t) => E((n) => n.includes(e) ? n.filter((t) => t !== e) : n.length < t ? [...n, e] : n), le = e.phase === "done" ? "done" : F ? "accent" : "info", ue = {
		opening: a("games.rftg.prompt.opening"),
		select: a(F ? "games.rftg.prompt.select" : "games.rftg.prompt.locked"),
		explore: t.explorePool ? a("games.rftg.prompt.exploreKeep", { n: t.exploreKeepN ?? 1 }) : a("games.rftg.prompt.waiting"),
		develop: t.payDue ? a("games.rftg.prompt.pay", { n: t.payDue.cost }) : a(F ? "games.rftg.prompt.developPick" : "games.rftg.prompt.waiting"),
		settle: t.payDue ? a("games.rftg.prompt.pay", { n: t.payDue.cost }) : a(F ? "games.rftg.prompt.settlePick" : "games.rftg.prompt.waiting"),
		consume: t.consume?.mustTrade ? a("games.rftg.prompt.trade") : a(F ? "games.rftg.prompt.consume" : "games.rftg.prompt.waiting"),
		produce: t.producePicks.length > 0 ? a("games.rftg.prompt.producePick") : a("games.rftg.prompt.waiting"),
		discard: t.mustDiscard > 0 ? a("games.rftg.prompt.discardDown", { n: t.mustDiscard }) : a("games.rftg.prompt.waiting")
	}, de = {
		opening: a("games.rftg.ph.opening"),
		select: a("games.rftg.ph.select"),
		explore: a("games.rftg.ph.explore"),
		develop: a("games.rftg.ph.develop"),
		settle: a("games.rftg.ph.settle"),
		consume: a("games.rftg.ph.consume"),
		produce: a("games.rftg.ph.produce"),
		discard: a("games.rftg.ph.discard"),
		done: a("games.rftg.label.completed")
	}, I = null;
	if (e.phase === "opening" && F) I = /* @__PURE__ */ y(Tt, {
		count: T.length,
		need: 2,
		onOk: () => {
			i({
				type: "openingDiscard",
				drop: T
			}), E([]);
		}
	});
	else if (e.phase === "select" && F) I = /* @__PURE__ */ y("div", {
		className: "rftg-action-choices",
		children: ae.map((e) => /* @__PURE__ */ b("button", {
			type: "button",
			onClick: () => i({
				type: "chooseAction",
				action: e
			}),
			className: "rftg-action-choice",
			children: [
				/* @__PURE__ */ y("span", {
					className: "rftg-action-phase",
					children: _t[e]
				}),
				/* @__PURE__ */ y(ut, { kind: gt[e] }),
				/* @__PURE__ */ y("span", {
					className: "rftg-action-name",
					children: a(xt[e])
				}),
				/* @__PURE__ */ y("span", {
					className: "rftg-action-description",
					children: a(St[e])
				})
			]
		}, e))
	});
	else if (e.phase === "explore" && t.explorePool && t.exploreKeepN !== null) I = /* @__PURE__ */ y(Tt, {
		count: T.length,
		need: t.exploreKeepN,
		onOk: () => {
			i({
				type: "exploreKeep",
				keep: T
			}), E([]);
		}
	});
	else if ((e.phase === "develop" || e.phase === "settle") && !e.placements && F) {
		let n = e.phase === "develop", r = D && t.settleOpts ? t.settleOpts[String(D.inst)] ?? [] : [], o = D && t.devCosts ? t.devCosts[String(D.inst)] : null;
		I = /* @__PURE__ */ b("div", {
			className: "flex flex-col gap-2",
			children: [D !== null && /* @__PURE__ */ b("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ y(Z, {
					defId: wt(t, D.inst),
					selected: !0
				}), /* @__PURE__ */ b("div", {
					className: "flex flex-1 flex-col gap-1",
					children: [n && o !== null && /* @__PURE__ */ y("div", {
						className: "rftg-body font-bold text-ink",
						children: a("games.rftg.prompt.pay", { n: o })
					}), !n && r.map((e) => /* @__PURE__ */ b("button", {
						type: "button",
						className: `btn-quiet rftg-small ${D.mode === e.mode ? "outline-3 outline-sky-500" : ""}`,
						onClick: () => O({
							inst: D.inst,
							mode: e.mode,
							nmt: e.nmt
						}),
						children: [
							a(Ct[e.mode]),
							e.mode === "pay" ? ` −${e.cost} ${a("games.rftg.label.hand")}` : "",
							e.mode === "conquer" && e.nmt > 0 ? ` +${e.nmt} ${Y(a, "new-military-tactics")}` : ""
						]
					}, e.mode))]
				})]
			}), /* @__PURE__ */ b(Q, { children: [/* @__PURE__ */ y("button", {
				type: "button",
				className: "btn-base flex-1",
				disabled: D === null || !n && !D.mode,
				onClick: () => {
					D && (i(n ? {
						type: "selectDev",
						inst: D.inst
					} : {
						type: "selectWorld",
						inst: D.inst,
						mode: D.mode,
						nmt: D.nmt
					}), O(null));
				},
				children: a("games.rftg.btn.confirm")
			}), /* @__PURE__ */ y("button", {
				type: "button",
				className: "btn-quiet flex-1",
				onClick: () => {
					i(n ? {
						type: "selectDev",
						inst: null
					} : {
						type: "selectWorld",
						inst: null
					}), O(null);
				},
				children: a("games.rftg.btn.skip")
			})] })]
		});
	} else if (t.payDue) I = /* @__PURE__ */ y(Tt, {
		count: T.length,
		need: t.payDue.cost,
		onOk: () => {
			i({
				type: "pay",
				cards: T
			}), E([]);
		}
	});
	else if (e.phase === "consume" && t.consume && F) I = /* @__PURE__ */ y(Et, {
		pub: e,
		priv: t,
		myRid: r,
		send: i,
		sel: T,
		setSel: E,
		power: k,
		setPower: ie,
		onDetail: M
	});
	else if (e.phase === "produce" && t.producePicks.length > 0 && F) {
		let e = t.producePicks[0].kinds, n = P.tableau.filter((t) => !t.hasGood && A(t.def).windfall && e.includes(A(t.def).good ?? ""));
		I = /* @__PURE__ */ y("div", {
			className: "flex flex-wrap gap-2",
			children: n.map((e) => /* @__PURE__ */ y(Z, {
				defId: e.def,
				onClick: () => i({
					type: "producePick",
					world: e.inst
				})
			}, e.inst))
		});
	} else e.phase === "discard" && t.mustDiscard > 0 && F && (I = /* @__PURE__ */ y(Tt, {
		count: T.length,
		need: t.mustDiscard,
		onOk: () => {
			i({
				type: "discardDown",
				drop: T
			}), E([]);
		}
	}));
	let L = e.phase === "opening" && F ? 2 : t.payDue ? t.payDue.cost : e.phase === "discard" && F ? t.mustDiscard : 0, R = (e.phase === "develop" || e.phase === "settle") && !e.placements && F, z = D?.inst ?? T[T.length - 1], B = z === void 0 ? void 0 : [...t.hand, ...t.explorePool ?? []].find((e) => e.inst === z)?.def, V = t.consume?.powers.find((e) => e.id === k), H = V ? A(V.def).powers[Number(V.id.split(":")[1])].codes : null, fe = t.consume?.mustTrade ? P.tableau.filter((e) => e.hasGood) : H ? Dt(P.tableau, H) : [], U = e.phase === "produce" && F ? t.producePicks[0]?.kinds : void 0, pe = new Set(fe.map((e) => e.inst).concat(U ? P.tableau.filter((e) => !e.hasGood && A(e.def).windfall && U.includes(A(e.def).good ?? "")).map((e) => e.inst) : []));
	return /* @__PURE__ */ b(ee, {
		adaptive: !0,
		className: "rftg-screen",
		scroll: !1,
		banner: /* @__PURE__ */ b("div", {
			className: "rftg-banner",
			style: { "--rftg-seats": e.players.length },
			children: [
				/* @__PURE__ */ y(h, {
					tone: le,
					accent: "#284c65",
					chip: /* @__PURE__ */ b("span", {
						className: "rftg-round",
						children: [/* @__PURE__ */ y(X, {}), a("games.rftg.label.round", { n: e.round })]
					}),
					text: de[e.phase],
					sub: a("games.rftg.label.pool", { n: e.vpPool })
				}),
				/* @__PURE__ */ b("div", {
					className: "rftg-phase-row",
					children: [/* @__PURE__ */ y("div", {
						className: "rftg-phase-track",
						children: [
							"explore",
							"develop",
							"settle",
							"consume",
							"produce"
						].map((t) => /* @__PURE__ */ y("span", {
							"data-current": e.phase === t || void 0,
							children: de[t]
						}, t))
					}), /* @__PURE__ */ y("span", {
						ref: te,
						className: "rftg-deck",
						children: a("games.rftg.label.deck", { n: e.deckCount })
					})]
				}),
				/* @__PURE__ */ y(g, {
					adaptive: !0,
					members: n,
					myRid: r,
					onPick: (e) => u.current[e]?.scrollIntoView({ block: "start" }),
					anchorOf: (e) => `seat:${e}`,
					action: (t) => e.phase === "done" ? null : e.waiting.includes(t) ? "pending" : "done",
					status: (t) => {
						let n = e.players.find((e) => e.rid === t);
						return n ? /* @__PURE__ */ b("span", {
							className: "rftg-player-status flex items-center gap-1 font-mono rftg-small font-bold tabular-nums",
							children: [
								/* @__PURE__ */ y(f, { value: n.vp }),
								" VP · ",
								a("games.rftg.label.hand"),
								" ",
								n.handCount
							]
						}) : null;
					}
				})
			]
		}),
		children: [/* @__PURE__ */ y(vt, {
			value: v,
			children: /* @__PURE__ */ b("div", {
				className: "rftg-workspace",
				children: [/* @__PURE__ */ y("div", {
					ref: ne,
					className: "rftg-table",
					style: { "--rftg-opponents": Math.max(1, e.players.length - 1) },
					children: [...e.players.filter((e) => e.rid !== r), P].map((t) => /* @__PURE__ */ b("section", {
						ref: (e) => {
							u.current[t.rid] = e;
						},
						className: "rftg-tableau",
						"data-self": t.rid === r || void 0,
						children: [/* @__PURE__ */ b("h2", {
							className: "rftg-tableau-title",
							children: [/* @__PURE__ */ b("span", { children: [s(t.rid), t.rid === r ? ` · ${a("lobby.you")}` : ""] }), /* @__PURE__ */ b("span", { children: [
								e.phase !== "done" && (e.placements ? e.placements[t.rid] ? Y(a, e.placements[t.rid].def) : a("games.rftg.prompt.placedNone") : e.revealed ? a(xt[e.revealed[t.rid]]) : ""),
								" · ",
								t.tableau.length
							] })]
						}), /* @__PURE__ */ y("div", {
							className: "rftg-card-grid",
							children: t.tableau.map((n) => /* @__PURE__ */ y(Z, {
								anchor: `tableau:${n.inst}`,
								inst: n.inst,
								defId: n.def,
								hasGood: n.hasGood,
								legal: F && t.rid === r && pe.has(n.inst),
								selected: e.phase === "consume" && t.rid === r && T.includes(n.inst),
								dimmed: e.phase !== "done" && n.activeAfter >= e.phaseCounter,
								onClick: () => M(n.def)
							}, n.inst))
						})]
					}, t.rid))
				}), /* @__PURE__ */ b("div", {
					ref: C,
					className: "rftg-console",
					children: [/* @__PURE__ */ b("div", {
						className: "rftg-console-scroll",
						children: [/* @__PURE__ */ b("div", {
							className: "rftg-command",
							children: [
								/* @__PURE__ */ b("div", {
									className: "rftg-command-title",
									children: [
										/* @__PURE__ */ y(X, {}),
										/* @__PURE__ */ y("h2", { children: e.phase === "done" ? a("games.rftg.label.completed") : ue[e.phase] }),
										(B || t.payDue) && /* @__PURE__ */ y("button", {
											type: "button",
											className: "rftg-inspect btn-quiet",
											"aria-label": a("games.rftg.label.details"),
											onClick: () => M(B ?? t.payDue.def),
											children: /* @__PURE__ */ y(re, { size: 18 })
										})
									]
								}),
								t.payDue && /* @__PURE__ */ y("div", {
									className: "rftg-pay-target",
									children: /* @__PURE__ */ y(Z, {
										defId: t.payDue.def,
										onClick: () => M(t.payDue.def)
									})
								}),
								I,
								!F && e.phase !== "done" && t.myAction && /* @__PURE__ */ b("div", {
									className: "rftg-locked-action",
									children: [/* @__PURE__ */ y(ut, { kind: gt[t.myAction] }), /* @__PURE__ */ y("span", { children: a(xt[t.myAction]) })]
								})
							]
						}), t.explorePool ? /* @__PURE__ */ b("section", {
							className: "rftg-hand-section",
							children: [/* @__PURE__ */ y("h2", {
								className: "rftg-hand-title",
								children: a("games.rftg.label.explorePool")
							}), /* @__PURE__ */ y("div", {
								ref: S,
								className: "rftg-hand",
								children: t.explorePool.map((e, n) => /* @__PURE__ */ y(Z, {
									ref: n === 0 ? w : void 0,
									anchor: `hand:${e.inst}`,
									defId: e.def,
									selected: T.includes(e.inst),
									onClick: () => ce(e.inst, t.exploreKeepN ?? 1)
								}, e.inst))
							})]
						}) : /* @__PURE__ */ b("section", {
							className: "rftg-hand-section",
							children: [/* @__PURE__ */ b("h2", {
								className: "rftg-hand-title",
								children: [
									a("games.rftg.label.hand"),
									" · ",
									t.hand.length
								]
							}), /* @__PURE__ */ b("div", {
								ref: S,
								className: "rftg-hand",
								children: [t.hand.map((n, r) => {
									let i = L > 0 || R && (e.phase === "develop" ? String(n.inst) in (t.devCosts ?? {}) : String(n.inst) in (t.settleOpts ?? {}));
									return /* @__PURE__ */ y(Z, {
										ref: r === 0 ? w : void 0,
										defId: n.def,
										selected: T.includes(n.inst) || D?.inst === n.inst,
										anchor: `hand:${n.inst}`,
										legal: F && i,
										badge: R && e.phase === "develop" && t.devCosts?.[String(n.inst)] !== void 0 ? `−${t.devCosts[String(n.inst)]}` : void 0,
										onClick: () => {
											R ? i ? O({ inst: n.inst }) : M(n.def) : L > 0 ? ce(n.inst, L) : M(n.def);
										}
									}, n.inst);
								}), t.hand.length === 0 && /* @__PURE__ */ y("div", {
									className: "rftg-empty-hand",
									children: "0"
								})]
							})]
						})]
					}), /* @__PURE__ */ y("div", {
						ref: x,
						className: "rftg-controls"
					})]
				})]
			})
		}), j && /* @__PURE__ */ y(bt, {
			defId: j,
			onClose: () => M(null)
		})]
	});
}
function bt({ defId: e, onClose: t }) {
	let n = m(), r = c(null), i = c(null);
	return a(() => {
		let e = document.activeElement;
		return r.current?.focus({ preventScroll: !0 }), () => e?.focus({ preventScroll: !0 });
	}, []), /* @__PURE__ */ y("div", {
		className: "rftg-detail-shade",
		onClick: t,
		children: /* @__PURE__ */ b("div", {
			ref: i,
			role: "dialog",
			"aria-modal": "true",
			"aria-label": Y(n, e),
			className: "rftg-detail",
			onClick: (e) => e.stopPropagation(),
			onKeyDown: (e) => {
				if (e.key === "Escape" && (e.stopPropagation(), t()), e.key === "Tab") {
					let t = i.current?.querySelectorAll("button:not(:disabled), [tabindex=\"0\"]");
					if (!t?.length) return;
					let n = t[0], r = t[t.length - 1];
					e.shiftKey && document.activeElement === n ? (e.preventDefault(), r.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n.focus());
				}
			},
			children: [/* @__PURE__ */ y(mt, { defId: e }), /* @__PURE__ */ b("button", {
				ref: r,
				type: "button",
				className: "btn-base mt-2 w-full",
				onClick: t,
				children: [/* @__PURE__ */ y(ne, { size: 18 }), n("games.rftg.label.close")]
			})]
		})
	});
}
var xt = {
	explore5: "games.rftg.act.explore5",
	explore11: "games.rftg.act.explore11",
	develop: "games.rftg.act.develop",
	settle: "games.rftg.act.settle",
	trade: "games.rftg.act.trade",
	consume2x: "games.rftg.act.consume2x",
	produce: "games.rftg.act.produce"
}, St = {
	explore5: "games.rftg.actD.explore5",
	explore11: "games.rftg.actD.explore11",
	develop: "games.rftg.actD.develop",
	settle: "games.rftg.actD.settle",
	trade: "games.rftg.actD.trade",
	consume2x: "games.rftg.actD.consume2x",
	produce: "games.rftg.actD.produce"
}, Ct = {
	pay: "games.rftg.prompt.modePay",
	conquer: "games.rftg.prompt.modeConquer",
	colonyShip: "games.rftg.prompt.modeColonyShip"
};
function wt(e, t) {
	return e.hand.find((e) => e.inst === t)?.def ?? e.explorePool?.find((e) => e.inst === t)?.def ?? "";
}
function Tt({ count: e, need: t, onOk: n }) {
	let r = m();
	return /* @__PURE__ */ b(Q, { children: [/* @__PURE__ */ b("span", {
		className: "rftg-confirm-count",
		children: [
			r("games.rftg.label.selected"),
			" ",
			/* @__PURE__ */ b("span", {
				className: "font-mono tabular-nums",
				children: [
					e,
					"/",
					t
				]
			})
		]
	}), /* @__PURE__ */ y("button", {
		type: "button",
		className: "btn-base",
		disabled: e !== t,
		onClick: n,
		children: r("games.rftg.btn.confirm")
	})] });
}
function Et({ pub: e, priv: t, myRid: n, send: r, sel: i, setSel: a, power: o, setPower: s, onDetail: c }) {
	let l = m(), u = t.consume, d = e.players.find((e) => e.rid === n), f = d.tableau.filter((e) => e.hasGood);
	if (u.mustTrade) return f.length === 0 ? /* @__PURE__ */ y("button", {
		type: "button",
		className: "btn-base w-full",
		onClick: () => r({ type: "tradeSkip" }),
		children: l("games.rftg.btn.skip")
	}) : /* @__PURE__ */ y("div", {
		className: "flex flex-wrap gap-2",
		children: f.map((e) => /* @__PURE__ */ b("div", {
			className: "flex flex-col items-center gap-0.5",
			children: [/* @__PURE__ */ y(Z, {
				defId: e.def,
				hasGood: !0,
				onClick: () => r({
					type: "tradeGood",
					world: e.inst
				})
			}), /* @__PURE__ */ y("span", {
				className: "rftg-small font-bold text-ink",
				children: l("games.rftg.btn.sell")
			})]
		}, e.inst))
	});
	if (o) {
		let e = u.powers.find((e) => e.id === o), n = A(e.def).powers[Number(o.split(":")[1])], f = n.codes, p = (e) => A(e.def).good;
		if (f.includes("DRAW_LUCKY")) return /* @__PURE__ */ y("div", {
			className: "flex flex-wrap items-center gap-1.5",
			children: [
				1,
				2,
				3,
				4,
				5,
				6,
				7
			].map((e) => /* @__PURE__ */ y("button", {
				type: "button",
				className: "btn-quiet min-h-11 min-w-11 font-mono font-extrabold",
				onClick: () => {
					r({
						type: "consume",
						power: o,
						lucky: e
					}), s(null);
				},
				children: e
			}, e))
		});
		if (f.includes("DISCARD_HAND")) {
			let e = (e) => a(i.includes(e) ? i.filter((t) => t !== e) : i.length < n.times ? [...i, e] : i);
			return /* @__PURE__ */ b("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ y("div", {
					className: "flex flex-wrap gap-2",
					children: t.hand.map((t) => /* @__PURE__ */ y(Z, {
						defId: t.def,
						selected: i.includes(t.inst),
						onClick: () => e(t.inst)
					}, t.inst))
				}), /* @__PURE__ */ b(Q, { children: [/* @__PURE__ */ b("button", {
					type: "button",
					className: "btn-base flex-1",
					onClick: () => {
						r({
							type: "consume",
							power: o,
							handCards: i
						}), a([]), s(null);
					},
					children: [
						l("games.rftg.btn.confirm"),
						" (",
						i.length,
						")"
					]
				}), /* @__PURE__ */ y("button", {
					type: "button",
					className: "btn-quiet",
					onClick: () => {
						a([]), s(null);
					},
					children: l("games.rftg.btn.skip")
				})] })]
			});
		}
		let m = Dt(d.tableau, f), h = f.includes("TRADE_ACTION") ? 1 : f.includes("CONSUME_ALL") ? m.length : f.includes("CONSUME_3_DIFF") ? 3 : f.includes("CONSUME_TWO") ? 2 : Math.min(n.times, m.length), g = new Set(i.map((e) => p(d.tableau.find((t) => t.inst === e)))), _ = (e) => {
			if (i.includes(e)) return a(i.filter((t) => t !== e));
			if (!(i.length >= h)) {
				if (f.includes("CONSUME_3_DIFF")) {
					let t = p(d.tableau.find((t) => t.inst === e));
					if (t && g.has(t)) return;
				}
				a([...i, e]);
			}
		};
		return /* @__PURE__ */ b("div", {
			className: "flex flex-col gap-2",
			children: [
				/* @__PURE__ */ b("button", {
					type: "button",
					className: "text-left rftg-small text-ink-soft",
					onClick: () => c(e.def),
					children: [
						Ze(l, n),
						" (",
						i.length,
						"/",
						h,
						")"
					]
				}),
				/* @__PURE__ */ y("div", {
					className: "flex flex-wrap gap-2",
					children: m.map((e) => /* @__PURE__ */ y(Z, {
						defId: e.def,
						hasGood: !0,
						selected: i.includes(e.inst),
						onClick: () => _(e.inst)
					}, e.inst))
				}),
				/* @__PURE__ */ b(Q, { children: [/* @__PURE__ */ y("button", {
					type: "button",
					className: "btn-base flex-1",
					disabled: i.length !== h,
					onClick: () => {
						r({
							type: "consume",
							power: o,
							goods: i
						}), a([]), s(null);
					},
					children: l("games.rftg.btn.confirm")
				}), /* @__PURE__ */ y("button", {
					type: "button",
					className: "btn-quiet",
					onClick: () => {
						a([]), s(null);
					},
					children: l("games.rftg.btn.skip")
				})] })
			]
		});
	}
	return /* @__PURE__ */ b("div", {
		className: "flex flex-col gap-2",
		children: [u.powers.length > 0 && /* @__PURE__ */ y("div", {
			className: "flex flex-col gap-1",
			children: u.powers.map((e) => {
				let t = A(e.def).powers[Number(e.id.split(":")[1])];
				return /* @__PURE__ */ b("button", {
					type: "button",
					disabled: !e.usable,
					className: "rftg-power-choice btn-quiet",
					onClick: () => s(e.id),
					children: [
						/* @__PURE__ */ y("span", {
							className: "rftg-power-art",
							children: /* @__PURE__ */ y(ot, { defId: e.def })
						}),
						/* @__PURE__ */ y("span", {
							className: "font-bold text-ink",
							children: Y(l, e.def)
						}),
						/* @__PURE__ */ y("span", {
							className: "text-ink-soft",
							children: Ze(l, t)
						})
					]
				}, e.id);
			})
		}), /* @__PURE__ */ b(Q, { children: [/* @__PURE__ */ y("button", {
			type: "button",
			className: "btn-quiet flex-1",
			onClick: () => r({ type: "consumeAuto" }),
			children: l("games.rftg.btn.auto")
		}), /* @__PURE__ */ b("button", {
			type: "button",
			className: "btn-base flex-1",
			disabled: u.mustAct,
			onClick: () => r({ type: "consumeDone" }),
			children: [l("games.rftg.btn.done"), u.x2 ? ` ${l("games.rftg.label.x2")}` : ""]
		})] })]
	});
}
function Dt(e, t) {
	let n = [
		"NOVELTY",
		"RARE",
		"GENE"
	].find((e) => t.includes(`CONSUME_${e}`));
	return e.filter((e) => e.hasGood && (t.includes("TRADE_ACTION") || t.includes("CONSUME_3_DIFF") || t.includes("CONSUME_ALL") || t.includes("CONSUME_ANY") || !!n && A(e.def).good === n));
}
//#endregion
//#region src/games/rftg/bot.ts
function $(e) {
	let t = e.vp * 2 + e.cost + e.powers.length * .5;
	return e.vpBonus && (t += 6), e.windfall && (t += 1), e.powers.some((e) => e.phase === 4 && e.codes.some((e) => e.startsWith("CONSUME") || e === "DISCARD_HAND")) && (t += 1.5), e.powers.some((e) => e.phase === 5 && e.codes.includes("PRODUCE")) && (t += 1), t;
}
var Ot = (e, t) => {
	let n = e.public, r = e.private;
	if (!r || !n.waiting.includes(t.rid)) return null;
	let i = n.players.find((e) => e.rid === t.rid), a = t.difficulty === "weak", o = () => a ? Math.random() * 3 : 0, s = [...r.hand].sort((e, t) => $(A(e.def)) - $(A(t.def)));
	switch (n.phase) {
		case "opening": return { action: {
			type: "openingDiscard",
			drop: [s[0].inst, s[1].inst]
		} };
		case "select": {
			let e = i.tableau.filter((e) => e.hasGood).length, t = i.tableau.filter((e) => !e.hasGood && A(e.def).powers.some((e) => e.phase === 5 && e.codes.includes("PRODUCE"))).length, n = i.tableau.filter((e) => !e.hasGood && A(e.def).windfall).length, a = r.hand.some((e) => {
				let t = A(e.def);
				return t.type === "dev" && t.cost - 1 <= r.hand.length - 1;
			}), s = r.hand.some((e) => A(e.def).type === "world"), c = [
				["explore5", (r.hand.length <= 4 ? 6 : 1.5) + o()],
				["explore11", (r.hand.length <= 4 ? 5 : 2) + o()],
				["develop", a ? 5 + o() : 0],
				["settle", s ? 5 + o() : 0],
				["trade", e > 0 ? 4 + e + o() : 0],
				["consume2x", e >= 2 ? 3 + e + o() : 0],
				["produce", t + n > 0 ? 2 + t + n * .5 + o() : .2]
			];
			return c.sort((e, t) => t[1] - e[1]), { action: {
				type: "chooseAction",
				action: c[0][0]
			} };
		}
		case "explore": return !r.explorePool || r.exploreKeepN === null ? null : { action: {
			type: "exploreKeep",
			keep: [...r.explorePool].sort((e, t) => $(A(t.def)) - $(A(e.def))).slice(0, r.exploreKeepN).map((e) => e.inst)
		} };
		case "develop": {
			if (r.payDue) break;
			if (!r.devCosts) return null;
			let e = r.hand.filter((e) => String(e.inst) in r.devCosts && r.devCosts[String(e.inst)] <= r.hand.length - 1).sort((e, t) => $(A(t.def)) - $(A(e.def)));
			if (e.length === 0 || a && Math.random() < .2) return { action: {
				type: "selectDev",
				inst: null
			} };
			let t = e[0];
			return r.hand.length - 1 - r.devCosts[String(t.inst)] <= 1 && $(A(t.def)) < 5 ? { action: {
				type: "selectDev",
				inst: null
			} } : { action: {
				type: "selectDev",
				inst: t.inst
			} };
		}
		case "settle": {
			if (r.payDue) break;
			if (!r.settleOpts) return null;
			let e = -1, t = null, n = -1;
			for (let i of r.hand) {
				let a = (r.settleOpts[String(i.inst)] ?? []).filter((e) => e.mode !== "pay" || e.cost <= r.hand.length - 1);
				for (let r of a) {
					let a = $(A(i.def)) + (r.mode === "colonyShip" ? 2 : r.mode === "conquer" ? 1.5 : 0) - r.cost * .3;
					a > n && (n = a, e = i.inst, t = r);
				}
			}
			return !t || a && Math.random() < .15 ? { action: {
				type: "selectWorld",
				inst: null
			} } : { action: {
				type: "selectWorld",
				inst: e,
				mode: t.mode,
				nmt: t.nmt
			} };
		}
		case "consume": {
			let e = r.consume;
			if (!e) return null;
			if (e.mustTrade) {
				let e = i.tableau.filter((e) => e.hasGood);
				if (e.length === 0) return { action: { type: "tradeSkip" } };
				let t = {
					NOVELTY: 0,
					RARE: 1,
					GENE: 2,
					ALIEN: 3
				};
				return { action: {
					type: "tradeGood",
					world: [...e].sort((e, n) => t[A(n.def).good ?? "NOVELTY"] - t[A(e.def).good ?? "NOVELTY"])[0].inst
				} };
			}
			return e.powers.some((e) => e.usable) && e.mustAct || e.mustAct ? { action: { type: "consumeAuto" } } : { action: { type: "consumeDone" } };
		}
		case "produce": {
			if (r.producePicks.length === 0) return null;
			let e = r.producePicks[0].kinds, t = i.tableau.filter((t) => !t.hasGood && A(t.def).windfall && e.includes(A(t.def).good ?? ""));
			return t.length === 0 ? null : { action: {
				type: "producePick",
				world: t[0].inst
			} };
		}
		case "discard": return r.mustDiscard <= 0 ? null : { action: {
			type: "discardDown",
			drop: s.slice(0, r.mustDiscard).map((e) => e.inst)
		} };
		default: return null;
	}
	return r.payDue ? { action: {
		type: "pay",
		cards: s.slice(0, r.payDue.cost).map((e) => e.inst)
	} } : null;
}, kt = (e, t) => e.x >= t.x - 2 && e.x + e.w <= t.x + t.w + 2 && e.y >= t.y - 2 && e.y + e.h <= t.y + t.h + 2;
function At(e, t) {
	let n = t.anchor("deck") ?? t.anchor("table"), r = e.rid ? t.anchor(`seat:${e.rid}`) : null, i = e.data, a = e.rid === t.myRid ? e.secret : void 0, o = t.anchor("hand"), s = t.anchor("console"), c = t.anchor("hand-card");
	if (!n || !r) return null;
	let l = t.queued ? 260 : 460, u = (a?.cards?.slice(0, 4) ?? Array.from({ length: Math.min(i?.n ?? 1, 4) }, () => null)).flatMap((e, i) => {
		let a = e ? `hand:${e.inst}` : null, l = a ? t.anchor(a) : null;
		if (e && (!l || !o || !s || !kt(l, o) || !kt(l, s))) return [];
		let u = l ?? r, d = l?.w ?? c?.w ?? 112, f = l?.h ?? c?.h ?? 170;
		return [{
			card: e,
			name: a,
			from: {
				x: n.x + n.w / 2 - d / 2,
				y: n.y + n.h / 2 - f / 2,
				w: d,
				h: f
			},
			to: u,
			delay: i * 55
		}];
	});
	return u.length ? {
		ms: l + Math.max(...u.map((e) => e.delay)),
		hide: t.queued ? [] : u.flatMap((e) => e.name ? [e.name] : []),
		node: /* @__PURE__ */ y(v, { children: u.map((e, t) => /* @__PURE__ */ y(w, {
			from: e.from,
			to: e.to,
			ms: l,
			delay: e.delay,
			children: /* @__PURE__ */ y("div", {
				className: "rftg-fx-card",
				children: e.card ? /* @__PURE__ */ y(Z, { defId: e.card.def }) : /* @__PURE__ */ y(pt, {})
			})
		}, t)) })
	} : null;
}
function jt(e, t) {
	let n = e.data, r = t.anchor("table"), i = `tableau:${n?.inst}`, a = t.anchor(i), o = e.rid ? t.anchor(`seat:${e.rid}`) : null;
	if (!n?.def || !a || !o || !r || !kt(a, r)) return null;
	let s = t.queued ? 240 : 380;
	return {
		ms: s,
		hide: t.queued ? [] : [i],
		node: /* @__PURE__ */ y(w, {
			from: {
				x: o.x + o.w / 2 - a.w / 2,
				y: o.y,
				w: a.w,
				h: a.h
			},
			to: a,
			ms: s,
			children: /* @__PURE__ */ y("div", {
				className: "rftg-fx-card",
				children: /* @__PURE__ */ y(Z, { defId: n.def })
			})
		})
	};
}
function Mt(e, t) {
	let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null, i = t.anchor("table");
	if (!r || !i) return null;
	let a = (n?.worlds ?? (n?.world === void 0 ? [] : [n.world])).flatMap((e) => {
		let n = t.anchor(`tableau:${e}`);
		return n && kt(n, i) ? [n] : [];
	}), o = t.queued ? 220 : 360;
	return a.length ? {
		ms: o,
		node: /* @__PURE__ */ y(v, { children: a.map((e, t) => /* @__PURE__ */ y(w, {
			from: {
				x: e.x + e.w * .65,
				y: e.y + e.h * .4,
				w: 28,
				h: 36
			},
			to: {
				x: r.x + r.w / 2,
				y: r.y,
				w: 14,
				h: 18
			},
			ms: o,
			children: /* @__PURE__ */ y(ct, { kind: n?.good })
		}, t)) })
	} : {
		ms: o,
		node: /* @__PURE__ */ y(C, {
			at: r,
			ms: o,
			children: /* @__PURE__ */ y("span", {
				className: "rftg-fx-token",
				children: "VP"
			})
		})
	};
}
var Nt = {
	deal: At,
	draw: At,
	place: jt,
	startWorld: jt,
	reveal(e, t) {
		let n = e.data, r = t.anchor(`tableau:${n?.inst}`), i = e.rid ? t.anchor(`seat:${e.rid}`) : null, a = r ?? i;
		return a ? {
			ms: 280,
			node: /* @__PURE__ */ y(T, {
				at: a,
				ms: 280
			})
		} : null;
	},
	consume: Mt,
	trade: Mt,
	consumeHand(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 360,
			node: /* @__PURE__ */ y(C, {
				at: n,
				ms: 360,
				children: /* @__PURE__ */ y("span", {
					className: "rftg-fx-token",
					children: "VP"
				})
			})
		} : null;
	},
	produce(e, t) {
		let n = e.data, r = `good:${n.inst}`, i = t.anchor(r), a = t.anchor("table");
		if (!i || !a || !kt(i, a)) return null;
		let o = t.queued ? 220 : 320;
		return {
			ms: o,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ y(w, {
				from: {
					...i,
					y: i.y - 24
				},
				to: i,
				ms: o,
				children: /* @__PURE__ */ y(ct, { kind: n.good })
			})
		};
	},
	lucky(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null, r = e.data;
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ y(C, {
				at: n,
				ms: 500,
				children: /* @__PURE__ */ y("span", {
					className: "rftg-fx-token",
					children: r.hit ? /* @__PURE__ */ y(X, {}) : /* @__PURE__ */ y(ut, { kind: "explore" })
				})
			})
		} : null;
	},
	discardTableau(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 300,
			node: /* @__PURE__ */ y(T, {
				at: n,
				ms: 300
			})
		} : null;
	},
	gameEnd() {
		return null;
	}
};
//#endregion
//#region src/games/rftg/endgame-review.tsx
function Pt({ board: e, renderResult: t, ...n }) {
	let r = m(), [i, o] = l(!0), [u, d] = l(null), f = c(null), p = c(null), h = c(null);
	a(() => {
		if (!u) return;
		h.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => d(null), 5e3);
		return () => clearTimeout(e);
	}, [u]);
	let g = (e) => {
		d(null), o(e), requestAnimationFrame(() => (e ? f : p).current?.focus({ preventScroll: !0 }));
	}, _ = s(() => ({
		onPlayAgain: n.onPlayAgain && (() => d({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => d({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => d({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), ee = {
		...n,
		..._
	};
	return /* @__PURE__ */ b("div", {
		className: "rftg-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ y("div", {
				className: "rftg-endgame-board",
				inert: i,
				children: e
			}),
			/* @__PURE__ */ y("div", {
				className: "rftg-endgame-overlay",
				hidden: !i,
				children: /* @__PURE__ */ b("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), g(!1));
					},
					className: "rftg-endgame-panel",
					"aria-label": r("session.result.title"),
					children: [
						/* @__PURE__ */ b("header", {
							className: "rftg-endgame-heading",
							children: [/* @__PURE__ */ b("div", {
								className: "rftg-endgame-brand",
								children: [/* @__PURE__ */ y(X, {}), r(j.nameKey)]
							}), /* @__PURE__ */ y("button", {
								type: "button",
								ref: f,
								className: "btn-quiet",
								"aria-label": r("games.rftg.reviewHide"),
								title: r("games.rftg.reviewHide"),
								onClick: () => g(!1),
								children: /* @__PURE__ */ y(re, { size: 19 })
							})]
						}),
						/* @__PURE__ */ y("div", {
							className: "rftg-endgame-result",
							inert: u !== null,
							children: t(ee)
						}),
						u && /* @__PURE__ */ b("div", {
							className: "rftg-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || d(null);
							},
							children: [/* @__PURE__ */ y("button", {
								type: "button",
								ref: h,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = u.run;
									d(null), e();
								},
								children: r(u.label === "again" ? "games.rftg.reviewConfirmAgain" : "games.rftg.reviewConfirmLobby")
							}), /* @__PURE__ */ y("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									d(null), f.current?.focus({ preventScroll: !0 });
								},
								children: r("games.rftg.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ y("div", {
				className: "rftg-endgame-toolbar",
				hidden: i,
				children: /* @__PURE__ */ b("button", {
					type: "button",
					className: "btn-base",
					ref: p,
					onClick: () => g(!0),
					children: [
						/* @__PURE__ */ y(S, { size: 18 }),
						r("games.rftg.reviewShow"),
						/* @__PURE__ */ y(x, { size: 18 })
					]
				})
			})
		]
	});
}
function Ft({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: s, renderRowExtra: c, summary: u, navigation: d, content: f, afterRanking: h, scoreUnit: g, rankOf: ee }) {
	let x = m(), ne = p((e) => e.locale), [S, C] = l({}), w = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? _(n, ne) : e;
	}, T = (t, n) => ee?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), O = e.ranking.some((t) => e.scores?.[t] !== void 0), k = (n, i) => /* @__PURE__ */ b("div", {
		className: "rftg-score-identity",
		children: [
			/* @__PURE__ */ y("span", {
				className: "rftg-score-seat",
				style: { backgroundColor: D[t.find((e) => e.rid === n)?.colorIndex ?? 0]?.hex }
			}),
			/* @__PURE__ */ y("span", {
				className: "rftg-score-place",
				children: e.winner.includes(n) ? x("games.rftg.reviewWinner") : O ? T(n, i) : ""
			}),
			/* @__PURE__ */ b("span", {
				className: "rftg-score-name",
				children: [w(n), n === r && /* @__PURE__ */ y("small", { children: x("lobby.you") })]
			}),
			!!e.autopilot?.[n] && /* @__PURE__ */ b("small", {
				className: "rftg-score-autopilot",
				children: [
					/* @__PURE__ */ y(te, { size: 12 }),
					Math.round(e.autopilot[n] * 100),
					"%"
				]
			})
		]
	}), A = (t) => e.ranking.map((n) => /* @__PURE__ */ y("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ b("div", {
		className: "rftg-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ y(E, {}),
			d,
			/* @__PURE__ */ b("div", {
				className: "rftg-score-body",
				children: [
					/* @__PURE__ */ b("div", {
						className: "rftg-victory",
						children: [/* @__PURE__ */ b("div", {
							className: "rftg-victory-crest",
							children: [/* @__PURE__ */ y(X, {}), /* @__PURE__ */ y("svg", {
								viewBox: "0 0 140 100",
								"aria-hidden": "true",
								children: /* @__PURE__ */ y("path", {
									d: "M40 78L17 63m18 6L15 51m15 9L16 39m85 39 23-15m-18 6 20-18m-15 9 13-21M31 84l17 3m45-3-17 3",
									fill: "none",
									stroke: "#e8bd72",
									strokeWidth: "2",
									strokeLinecap: "round"
								})
							})]
						}), /* @__PURE__ */ y("h1", { children: e.winner.length ? x("games.rftg.label.victors", { names: e.winner.map(w).join(" · ") }) : x("games.rftg.label.finished") })]
					}),
					u && /* @__PURE__ */ y("div", {
						className: "rftg-score-summary",
						children: u
					}),
					i !== void 0 && /* @__PURE__ */ y("p", {
						className: "rftg-score-hints",
						children: x("session.hint.usedCount", { n: i })
					}),
					f ?? (s?.length ? /* @__PURE__ */ y("div", {
						className: "rftg-score-table-scroll",
						children: /* @__PURE__ */ b("table", {
							className: "rftg-score-table",
							"aria-label": x(j.nameKey),
							children: [
								/* @__PURE__ */ y("thead", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", { scope: "col" }), /* @__PURE__ */ y(v, { children: e.ranking.map((t, n) => /* @__PURE__ */ y("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: k(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ y("tbody", { children: s.map((e, t) => /* @__PURE__ */ b(n, { children: [/* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ b("button", {
										type: "button",
										"aria-expanded": !!S[t],
										onClick: () => C((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ y(re, { size: 15 }), e.label]
									}) : e.label
								}), A(e)] }), S[t] && e.details?.map((e, t) => /* @__PURE__ */ b("tr", {
									className: "rftg-score-sub",
									children: [/* @__PURE__ */ y("th", {
										scope: "row",
										children: e.label
									}), A(e)]
								}, t))] }, t)) }),
								O && /* @__PURE__ */ y("tfoot", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
									scope: "row",
									children: x("games.rftg.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ y("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ y("ol", {
						className: "rftg-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ b("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ b("div", {
								className: "rftg-score-rankline",
								children: [k(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ b("strong", {
									className: "rftg-score-points",
									children: [e.scores[t], g && /* @__PURE__ */ y("small", { children: g })]
								})]
							}), c?.(t)]
						}, t))
					})),
					h,
					!!s?.length && c && /* @__PURE__ */ y("div", {
						className: "rftg-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ b("details", { children: [/* @__PURE__ */ y("summary", { children: w(e) }), c(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ b("footer", {
				className: "rftg-score-actions",
				children: [
					o && /* @__PURE__ */ y("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: x("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ y("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: x("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ y("p", { children: x("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/rftg/endgame-scores.tsx
function It(e) {
	let t = m(), n = e.public, r = [
		["cards", "games.rftg.label.scoreCards"],
		["chips", "games.rftg.label.scoreChips"],
		["six", "games.rftg.label.scoreSix"]
	].map(([e, r]) => ({
		label: t(r),
		value: (t) => n.finalScores?.[t]?.[e] ?? "—"
	}));
	return /* @__PURE__ */ y(Ft, {
		...e,
		renderRowExtra: void 0,
		rows: r
	});
}
//#endregion
//#region src/games/rftg/game-over.tsx
function Lt(e) {
	return /* @__PURE__ */ y(It, { ...e });
}
function Rt(e) {
	return /* @__PURE__ */ y(Pt, {
		...e,
		board: /* @__PURE__ */ y(ht, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ y(Lt, { ...e })
	});
}
//#endregion
//#region src/games/rftg/game-over-row.tsx
function zt({ public: e, rid: t }) {
	let n = m(), r = e.finalScores?.[t];
	return r ? /* @__PURE__ */ b("div", {
		className: "mt-1 flex flex-wrap gap-x-3 gap-y-0.5 font-mono text-xs tabular-nums text-ink-soft",
		children: [
			/* @__PURE__ */ b("span", { children: [
				n("games.rftg.label.scoreCards"),
				" ",
				r.cards
			] }),
			/* @__PURE__ */ b("span", { children: [
				n("games.rftg.label.scoreChips"),
				" ",
				r.chips
			] }),
			/* @__PURE__ */ b("span", { children: [
				n("games.rftg.label.scoreSix"),
				" ",
				r.six
			] }),
			/* @__PURE__ */ b("span", {
				className: "font-extrabold text-ink",
				children: [
					n("games.rftg.label.scoreTotal"),
					" ",
					r.total
				]
			})
		]
	}) : null;
}
//#endregion
//#region .bgparty/cache/pack-entry/rftg/entry.tsx
var Bt = {
	definition: Je,
	View: ht,
	bot: Ot,
	fx: Nt,
	OverView: Rt,
	RowView: zt,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "银河竞逐",
			desc: "同时暗选五个阶段:探索、开发、殖民、消费、生产,用手牌付款建起你的银河帝国",
			rules: "目标：建设星际帝国。当任意玩家面前的卡牌达到 12 张，或胜利点（VP）筹码全部用完时，游戏进入终局；总分最高的玩家获胜。\n准备：每人随机获得一个起始世界，抽取 6 张手牌，再弃置其中 2 张。\n流程(每回合):\n· 每人秘密选择一项行动：两种探索行动之一、开发、殖民、贸易与消费、双倍消费或生产。\n· 所有人同时公开所选行动。仅执行本回合被选中的阶段，依次按 I 至 V 的顺序进行。所有玩家均执行这些阶段，选择相应行动的玩家额外获得该阶段奖励。\n阶段:\n· I 探索：抽取 2 张牌，选择其中 1 张保留。选择探索行动的玩家可以改为抽取 7 张、保留 1 张，或抽取 3 张、保留 2 张。\n· II 开发：弃置手牌支付费用，打出 1 张发展卡。选择开发行动的玩家少支付 1 张手牌。每名玩家不能拥有两张同名发展卡。\n· III 殖民：打出一个世界。非军事世界须通过弃置手牌支付费用；军事世界须以军事值征服，无须支付卡牌。两种方式不能混合使用。\n· 选择殖民行动的玩家放置世界后，抽取 1 张牌。风陨世界入场时，自带 1 份货物。\n· IV 消费：使用消费能力，将货物兑换为胜利点筹码或手牌。\n· 选择贸易行动的玩家，先出售 1 份货物并抽取相应数量的牌：新异品为 2 张，稀有元素为 3 张，基因为 4 张，异星技术为 5 张。\n· 选择双倍消费行动的玩家，本阶段获得的胜利点翻倍。\n· V 生产：所有生产世界各生产 1 份货物。选择生产行动的玩家，还可以使一个风陨世界额外生产货物。\n细则：卡牌能力从打出该牌后的下一阶段起生效。每回合结束时，手牌上限为 10 张。终局总分相同时，比较手牌数量与货物数量之和，合计较多者获胜。\n计分：将面前卡牌的牌面分数、持有的胜利点筹码，以及费用为 6 的发展卡所提供的倍数计分相加；同一张卡牌符合多个档位时，只采用得分最高的档位。",
			cards: {
				"old-earth": "旧地球",
				"epsilon-eridani": "波江座ε星",
				"alpha-centauri": "半人马座α星",
				"new-sparta": "新斯巴达",
				"earth-s-lost-colony": "地球失落的殖民地",
				"rebel-fuel-cache": "叛军燃料库",
				"public-works": "公共工程",
				"gem-world": "宝石世界",
				"colony-ship": "殖民船",
				"comet-zone": "彗星带",
				"expedition-force": "远征军",
				"mining-robots": "采矿机器人",
				"rebel-miners": "叛军矿工",
				"export-duties": "出口关税",
				"former-penal-colony": "前流放殖民地",
				"malevolent-lifeforms": "恶意生命体",
				"new-military-tactics": "新军事战术",
				"space-marines": "太空陆战队",
				"contact-specialist": "接触专家",
				"avian-uplift-race": "鸟类提升族",
				"spice-world": "香料世界",
				"lost-species-ark-world": "失落物种方舟世界",
				"new-vinland": "新文兰",
				"artist-colony": "艺术家殖民地",
				"alien-robotic-factory": "异星机器人工厂",
				"plague-world": "瘟疫世界",
				"distant-world": "遥远世界",
				"rebel-outpost": "叛军前哨",
				"rebel-warrior-race": "叛军战士族",
				"rebel-underground": "叛军地下组织",
				"new-survivalists": "新生存主义者",
				"outlaw-world": "法外世界",
				"lost-alien-battle-fleet": "失落异星战舰队",
				"diversified-economy": "多元经济",
				"consumer-markets": "消费市场",
				"mining-conglomerate": "矿业集团",
				"research-labs": "研究实验室",
				"deficit-spending": "赤字支出",
				"investment-credits": "投资信贷",
				"pan-galactic-league": "泛银河联盟",
				"mining-league": "矿业联盟",
				"free-trade-association": "自由贸易协会",
				"alien-tech-institute": "异星科技研究所",
				"galactic-survey-seti": "银河勘测:SETI",
				"galactic-federation": "银河联邦",
				"refugee-world": "难民世界",
				"empath-world": "共情世界",
				"galactic-resort": "银河度假胜地",
				"pre-sentient-race": "前智慧种族",
				"deserted-alien-outpost": "废弃异星前哨",
				"deserted-alien-colony": "废弃异星殖民地",
				"galactic-engineers": "银河工程师",
				"black-market-trading-world": "黑市贸易世界",
				"merchant-world": "商人世界",
				"tourist-world": "旅游世界",
				"galactic-trendsetters": "银河潮流风向标",
				"alien-rosetta-stone-world": "异星罗塞塔石碑世界",
				"star-nomad-lair": "星际游民巢穴",
				"the-last-of-the-uplift-gnarssh": "最后的格纳什提升族",
				"alien-robot-sentry": "异星机器人哨兵",
				"pirate-world": "海盗世界",
				"reptilian-uplift-race": "爬行提升族",
				"lost-alien-warship": "失落异星战舰",
				"alien-robot-scout-ship": "异星机器人侦察船",
				"runaway-robots": "失控机器人",
				"interstellar-bank": "星际银行",
				"terraforming-robots": "地球化机器人",
				"drop-ships": "空投船",
				"new-galactic-order": "新银河秩序",
				"asteroid-belt": "小行星带",
				"merchant-guild": "商人行会",
				"secluded-world": "隐居世界",
				"imperium-armaments-world": "帝国军备世界",
				"terraformed-world": "地球化世界",
				"replicant-robots": "复制机器人",
				"pilgrimage-world": "朝圣世界",
				"rebel-homeworld": "叛军母星",
				"new-economy": "新经济",
				"radioactive-world": "放射性世界",
				"aquatic-uplift-race": "水生提升族",
				"genetics-lab": "基因实验室",
				"bio-hazard-mining-world": "生化危害采矿世界",
				"deserted-alien-library": "废弃异星图书馆",
				"destroyed-world": "毁灭的世界",
				"galactic-renaissance": "银河复兴",
				"blaster-gem-mines": "爆能宝石矿场",
				"gambling-world": "赌博世界",
				"expanding-colony": "扩张中的殖民地",
				"space-port": "太空港",
				"prosperous-world": "繁荣世界",
				"new-earth": "新地球",
				"rebel-base": "叛军基地",
				"galactic-imperium": "银河帝国",
				"trade-league": "贸易联盟",
				"mining-world": "采矿世界"
			},
			good: {
				NOVELTY: "新异品",
				RARE: "稀有元素",
				GENE: "基因",
				ALIEN: "异星遗物"
			},
			act: {
				explore5: "探索 +5",
				explore11: "探索 +1+1",
				develop: "开发",
				settle: "殖民",
				trade: "贸易",
				consume2x: "双倍消费",
				produce: "生产"
			},
			actD: {
				explore5: "抽 7 留 1",
				explore11: "抽 3 留 2",
				develop: "开发费用 −1",
				settle: "放置后摸 1 张",
				trade: "先卖 1 份货换牌",
				consume2x: "消费 VP 翻倍",
				produce: "风陨世界也产货"
			},
			ph: {
				opening: "开局整理",
				select: "暗选行动",
				explore: "I · 探索",
				develop: "II · 开发",
				settle: "III · 殖民",
				consume: "IV · 消费",
				produce: "V · 生产",
				discard: "回合结束"
			},
			prompt: {
				opening: "选择 2 张手牌弃置",
				select: "选择本回合的行动",
				selectWait: "等你暗选行动",
				exploreKeep: "选择 {{n}} 张牌保留",
				developPick: "选择 1 张发展卡，或放弃开发",
				settlePick: "选择 1 个世界，或放弃殖民",
				pay: "弃置 {{n}} 张手牌付款",
				trade: "选择 1 份货物卖出",
				consume: "选择消费能力",
				producePick: "选择 1 个风陨世界生产",
				discardDown: "弃置 {{n}} 张超限手牌",
				waiting: "等待其他玩家…",
				locked: "行动已锁定",
				placedNone: "放弃",
				modePay: "付款",
				modeConquer: "征服",
				modeColonyShip: "殖民船"
			},
			btn: {
				confirm: "确定",
				skip: "放弃",
				auto: "自动结算",
				done: "完成消费",
				lucky: "猜 {{n}}",
				sell: "卖出"
			},
			brief: {
				developAfter: "开发后摸 {{n}} 张",
				pairKind: "{{kind}}×2 → {{n}} VP",
				keep: "探索多留 1 张",
				explore: "探索多摸 {{n}} 张",
				developCost: "开发费用 −{{n}}",
				developDraw: "开发时摸 {{n}} 张",
				colonyShip: "弃置 → 免费殖民",
				tactics: "弃置 → 军事 +3",
				military: "军事 {{n}}",
				settleCost: "殖民费用 −{{n}}",
				trade: "贸易 +{{n}}",
				discard: "弃牌 → {{n}} VP",
				different: "3 种货 → {{n}} VP",
				pair: "2 份货 → {{n}} VP",
				cardsVp: "货 → 手牌与 VP",
				consume: "货 → {{n}} VP",
				produce: "生产 1 份货"
			},
			label: {
				details: "查看所选卡牌详情",
				selected: "已选",
				rebel: "叛军",
				cost: "费用",
				production: "生产世界",
				completed: "帝国建成",
				explorePool: "探索池",
				close: "关闭",
				victors: "{{names}} 获胜",
				finished: "银河竞逐结束",
				round: "第 {{n}} 回合",
				deck: "牌库 {{n}}",
				vp: "VP",
				pool: "筹码池 {{n}}",
				hand: "手牌",
				goods: "货",
				tableauOf: "{{name}} 的桌面",
				military: "军事",
				defense: "防御",
				windfall: "风陨",
				dev: "发展",
				world: "世界",
				activeNext: "下阶段生效",
				x2: "×2",
				scoreCards: "卡面分",
				scoreChips: "筹码分",
				scoreSix: "六费发展",
				scoreTotal: "总分",
				tie: "平分决胜:手牌+货 {{n}}"
			},
			pw: {
				exploreDraw: "I:探索多抽 {{n}} 张",
				exploreKeep: "I:探索多留 1 张",
				devDraw: "II:开发阶段开始摸 1 张",
				devDrawAfter: "II:打出发展后再摸 {{n}} 张",
				devReduce: "II:开发费用 −{{n}}",
				settleReduce: "III:殖民费用 −{{n}}",
				settleReduceKind: "III:殖民{{kind}}世界费用 −{{n}}",
				military: "III:军事 {{n}}",
				militaryKind: "III:对{{kind}}军事 +{{n}}",
				payMilitary: "III:可按防御−1 付款放置军事世界(异星除外)",
				nmt: "III:弃此卡,本次征服军事 +3",
				colonyShip: "III:弃此卡,免费放置 1 个非军事世界",
				settleDrawAfter: "III:放置世界后再摸 {{n}} 张",
				consumeAny: "IV:消费最多 {{n}} 份货",
				consumeKind: "IV:消费最多 {{n}} 份{{kind}}货",
				consumePair: "IV:消费 2 份{{kind}}货",
				consumePairAny: "IV:消费 2 份任意货",
				consume3diff: "IV:消费 3 种不同货",
				consumeAll: "IV:消费全部货",
				rewardVp: "每份 {{n}}VP",
				rewardCard: "每份摸 {{n}} 张",
				rewardPairVp: "得 {{n}}VP",
				rewardAllVp: "每超出 1 份得 {{n}}VP",
				discardHand: "IV:弃最多 {{n}} 张手牌,每张 {{v}}VP",
				drawLucky: "IV:猜费用 1-7 并抽 1 张,猜中留下",
				tradeAction: "IV:弃 1 份货,按其贸易价摸牌",
				tradeActionNoBonus: "IV:弃 1 份货,按贸易价摸牌(不享受加成)",
				tradeAny: "IV:卖货多摸 {{n}} 张",
				tradeKind: "IV:卖{{kind}}货多摸 {{n}} 张",
				tradeThis: "IV:卖本世界的货多摸 {{n}} 张",
				consumeDraw: "IV:消费阶段开始摸 1 张",
				produce: "V:产 1 份货",
				windfallKind: "V:在 1 个{{kind}}风陨世界产货",
				windfallAny: "V:在任意 1 个风陨世界产货",
				prodDraw: "V:生产阶段开始摸 {{n}} 张",
				prodDrawIf: "V:本世界若产货,摸 {{n}} 张",
				prodDrawGene: "V:每有 1 个基因世界摸 1 张",
				prodDrawEachNovelty: "V:本阶段每产 1 份新异品货摸 1 张",
				prodDrawEachAlien: "V:本阶段每产 1 份异星货摸 1 张",
				prodDrawDiff: "V:本阶段每产 1 种不同货摸 1 张",
				prodDrawMostRare: "V:若你产的稀有货严格最多,摸 {{n}} 张"
			},
			vpb: {
				threeVp: "每 3 枚 VP 筹码 {{n}} 分",
				totalMilitary: "每点永久军事 {{n}} 分",
				name: "每张「{{name}}」 {{n}} 分",
				noveltyProd: "每个新异品生产世界 {{n}} 分",
				rareProd: "每个稀有生产世界 {{n}} 分",
				geneProd: "每个基因生产世界 {{n}} 分",
				alienProd: "每个异星生产世界 {{n}} 分",
				noveltyWind: "每个新异品风陨世界 {{n}} 分",
				rareWind: "每个稀有风陨世界 {{n}} 分",
				geneWind: "每个基因风陨世界 {{n}} 分",
				alienWind: "每个异星风陨世界 {{n}} 分",
				militaryWorld: "每个军事世界 {{n}} 分",
				rebelMilitary: "每个叛军军事世界 {{n}} 分",
				sixDevel: "每个 6 费发展 {{n}} 分",
				devel: "每个发展 {{n}} 分",
				world: "每个世界 {{n}} 分",
				alienFlag: "每张异星卡 {{n}} 分",
				develExplore: "每个探索发展 {{n}} 分",
				worldExplore: "每个探索世界 {{n}} 分",
				develConsume: "每个消费发展 {{n}} 分",
				worldConsume: "每个消费世界 {{n}} 分",
				develTrade: "每个贸易发展 {{n}} 分",
				worldTrade: "每个贸易世界 {{n}} 分"
			},
			errPhase: "现在不能这么做",
			errCard: "无效的卡牌",
			errCount: "数量不对",
			errIllegal: "不合法的操作"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Race for the Galaxy",
			desc: "Simultaneously pick phases — Explore, Develop, Settle, Consume, Produce — and pay cards from hand to build your galactic empire",
			rules: "Goal: build the strongest galactic empire. The game ends when anyone has 12+ cards in play or the VP chips run out; highest score wins.\nSetup: each player gets a random start world, draws 6 cards and discards 2.\nEach round:\n· Everyone secretly picks 1 action: Explore (two kinds), Develop, Settle, Trade+Consume, Double Consume, or Produce.\n· Only the chosen phases happen, in order I→V; everyone performs them, but choosers get a bonus.\nPhases:\n· I Explore: Draw 2 cards and keep 1. Players who selected Explore instead draw 7 cards and keep 1, or draw 3 cards and keep 2.\n· II Develop: Discard hand cards to pay the cost and play 1 development. Players who selected Develop pay 1 fewer card. Each player may have only one copy of each development.\n· III Settle: play 1 world — pay cards for non-military worlds, or conquer military worlds with Military power; never both.\n· Players who selected Settle draw 1 card after placing a world. A windfall world enters play with 1 good.\n· IV Consume: use powers to turn goods into VP chips or cards.\n· Players who selected Trade first sell 1 good and draw cards according to its type: 2 cards for Novelty, 3 for Rare Elements, 4 for Genes, or 5 for Alien Technology.\n· Players who selected Double Consume double the VP they earn during this phase.\n· V Produce: production worlds each gain a good; choosers also produce on one windfall world.\nDetails: powers only work from the phase AFTER the card enters play; hand limit is 10 at round end; ties break on cards in hand plus goods.\nScoring: printed VP of cards, VP chips, and 6-cost development multipliers (each card scores only its best single category).",
			cards: {
				"old-earth": "Old Earth",
				"epsilon-eridani": "Epsilon Eridani",
				"alpha-centauri": "Alpha Centauri",
				"new-sparta": "New Sparta",
				"earth-s-lost-colony": "Earth's Lost Colony",
				"rebel-fuel-cache": "Rebel Fuel Cache",
				"public-works": "Public Works",
				"gem-world": "Gem World",
				"colony-ship": "Colony Ship",
				"comet-zone": "Comet Zone",
				"expedition-force": "Expedition Force",
				"mining-robots": "Mining Robots",
				"rebel-miners": "Rebel Miners",
				"export-duties": "Export Duties",
				"former-penal-colony": "Former Penal Colony",
				"malevolent-lifeforms": "Malevolent Lifeforms",
				"new-military-tactics": "New Military Tactics",
				"space-marines": "Space Marines",
				"contact-specialist": "Contact Specialist",
				"avian-uplift-race": "Avian Uplift Race",
				"spice-world": "Spice World",
				"lost-species-ark-world": "Lost Species Ark World",
				"new-vinland": "New Vinland",
				"artist-colony": "Artist Colony",
				"alien-robotic-factory": "Alien Robotic Factory",
				"plague-world": "Plague World",
				"distant-world": "Distant World",
				"rebel-outpost": "Rebel Outpost",
				"rebel-warrior-race": "Rebel Warrior Race",
				"rebel-underground": "Rebel Underground",
				"new-survivalists": "New Survivalists",
				"outlaw-world": "Outlaw World",
				"lost-alien-battle-fleet": "Lost Alien Battle Fleet",
				"diversified-economy": "Diversified Economy",
				"consumer-markets": "Consumer Markets",
				"mining-conglomerate": "Mining Conglomerate",
				"research-labs": "Research Labs",
				"deficit-spending": "Deficit Spending",
				"investment-credits": "Investment Credits",
				"pan-galactic-league": "Pan-Galactic League",
				"mining-league": "Mining League",
				"free-trade-association": "Free Trade Association",
				"alien-tech-institute": "Alien Tech Institute",
				"galactic-survey-seti": "Galactic Survey: SETI",
				"galactic-federation": "Galactic Federation",
				"refugee-world": "Refugee World",
				"empath-world": "Empath World",
				"galactic-resort": "Galactic Resort",
				"pre-sentient-race": "Pre-Sentient Race",
				"deserted-alien-outpost": "Deserted Alien Outpost",
				"deserted-alien-colony": "Deserted Alien Colony",
				"galactic-engineers": "Galactic Engineers",
				"black-market-trading-world": "Black Market Trading World",
				"merchant-world": "Merchant World",
				"tourist-world": "Tourist World",
				"galactic-trendsetters": "Galactic Trendsetters",
				"alien-rosetta-stone-world": "Alien Rosetta Stone World",
				"star-nomad-lair": "Star Nomad Lair",
				"the-last-of-the-uplift-gnarssh": "The Last of the Uplift Gnarssh",
				"alien-robot-sentry": "Alien Robot Sentry",
				"pirate-world": "Pirate World",
				"reptilian-uplift-race": "Reptilian Uplift Race",
				"lost-alien-warship": "Lost Alien Warship",
				"alien-robot-scout-ship": "Alien Robot Scout Ship",
				"runaway-robots": "Runaway Robots",
				"interstellar-bank": "Interstellar Bank",
				"terraforming-robots": "Terraforming Robots",
				"drop-ships": "Drop Ships",
				"new-galactic-order": "New Galactic Order",
				"asteroid-belt": "Asteroid Belt",
				"merchant-guild": "Merchant Guild",
				"secluded-world": "Secluded World",
				"imperium-armaments-world": "Imperium Armaments World",
				"terraformed-world": "Terraformed World",
				"replicant-robots": "Replicant Robots",
				"pilgrimage-world": "Pilgrimage World",
				"rebel-homeworld": "Rebel Homeworld",
				"new-economy": "New Economy",
				"radioactive-world": "Radioactive World",
				"aquatic-uplift-race": "Aquatic Uplift Race",
				"genetics-lab": "Genetics Lab",
				"bio-hazard-mining-world": "Bio-Hazard Mining World",
				"deserted-alien-library": "Deserted Alien Library",
				"destroyed-world": "Destroyed World",
				"galactic-renaissance": "Galactic Renaissance",
				"blaster-gem-mines": "Blaster Gem Mines",
				"gambling-world": "Gambling World",
				"expanding-colony": "Expanding Colony",
				"space-port": "Space Port",
				"prosperous-world": "Prosperous World",
				"new-earth": "New Earth",
				"rebel-base": "Rebel Base",
				"galactic-imperium": "Galactic Imperium",
				"trade-league": "Trade League",
				"mining-world": "Mining World"
			},
			good: {
				NOVELTY: "Novelty",
				RARE: "Rare elements",
				GENE: "Genes",
				ALIEN: "Alien tech"
			},
			act: {
				explore5: "Explore +5",
				explore11: "Explore +1+1",
				develop: "Develop",
				settle: "Settle",
				trade: "Trade",
				consume2x: "Double Consume",
				produce: "Produce"
			},
			actD: {
				explore5: "Draw 7, keep 1",
				explore11: "Draw 3, keep 2",
				develop: "Development costs −1",
				settle: "Draw 1 after placing",
				trade: "Sell 1 good first",
				consume2x: "Double consume VPs",
				produce: "Windfall world produces"
			},
			ph: {
				opening: "Opening",
				select: "Pick actions",
				explore: "I · Explore",
				develop: "II · Develop",
				settle: "III · Settle",
				consume: "IV · Consume",
				produce: "V · Produce",
				discard: "Round end"
			},
			prompt: {
				opening: "Choose 2 cards to discard",
				select: "Choose an action",
				selectWait: "Pick your action",
				exploreKeep: "Keep {{n}} cards",
				developPick: "Choose a development or pass",
				settlePick: "Choose a world or pass",
				pay: "Discard {{n}} cards to pay",
				trade: "Choose a good to sell",
				consume: "Choose a consume power",
				producePick: "Choose a windfall world",
				discardDown: "Discard {{n}} excess cards",
				waiting: "Waiting for other players…",
				locked: "Action locked",
				placedNone: "Pass",
				modePay: "Pay",
				modeConquer: "Conquer",
				modeColonyShip: "Colony Ship"
			},
			btn: {
				confirm: "OK",
				skip: "Pass",
				auto: "Auto-resolve",
				done: "Done consuming",
				lucky: "Guess {{n}}",
				sell: "Sell"
			},
			brief: {
				developAfter: "After develop: draw {{n}}",
				pairKind: "2 {{kind}} → {{n}} VP",
				keep: "Keep 1 extra",
				explore: "Explore +{{n}} cards",
				developCost: "Develop −{{n}}",
				developDraw: "Develop: draw {{n}}",
				colonyShip: "Discard: free settle",
				tactics: "Discard: Military +3",
				military: "Military {{n}}",
				settleCost: "Settle −{{n}}",
				trade: "Trade +{{n}}",
				discard: "Discard → {{n}} VP",
				different: "3 types → {{n}} VP",
				pair: "2 goods → {{n}} VP",
				cardsVp: "Good → cards & VP",
				consume: "Good → {{n}} VP",
				produce: "Produce 1 good"
			},
			label: {
				details: "View selected card details",
				selected: "Selected",
				rebel: "Rebel",
				cost: "Cost",
				production: "Production world",
				completed: "Empire complete",
				explorePool: "Exploration",
				close: "Close",
				victors: "Victory: {{names}}",
				finished: "The galaxy is settled",
				round: "Round {{n}}",
				deck: "Deck {{n}}",
				vp: "VP",
				pool: "VP pool {{n}}",
				hand: "Hand",
				goods: "Goods",
				tableauOf: "{{name}}'s tableau",
				military: "Military",
				defense: "Defense",
				windfall: "Windfall",
				dev: "Development",
				world: "World",
				activeNext: "Active next phase",
				x2: "×2",
				scoreCards: "Cards",
				scoreChips: "Chips",
				scoreSix: "6-cost devs",
				scoreTotal: "Total",
				tie: "Tiebreak: hand + goods {{n}}"
			},
			pw: {
				exploreDraw: "I: draw {{n}} more when exploring",
				exploreKeep: "I: keep 1 more when exploring",
				devDraw: "II: draw 1 at the start of Develop",
				devDrawAfter: "II: draw {{n}} after placing a development",
				devReduce: "II: developments cost −{{n}}",
				settleReduce: "III: settling costs −{{n}}",
				settleReduceKind: "III: {{kind}} worlds cost −{{n}}",
				military: "III: Military {{n}}",
				militaryKind: "III: +{{n}} Military vs {{kind}}",
				payMilitary: "III: may pay for military worlds at defense −1 (not Alien)",
				nmt: "III: discard this for +3 Military on one conquest",
				colonyShip: "III: discard this to place a non-military world free",
				settleDrawAfter: "III: draw {{n}} after placing a world",
				consumeAny: "IV: consume up to {{n}} goods",
				consumeKind: "IV: consume up to {{n}} {{kind}} goods",
				consumePair: "IV: consume 2 {{kind}} goods",
				consumePairAny: "IV: consume any 2 goods",
				consume3diff: "IV: consume 3 different kinds of goods",
				consumeAll: "IV: consume all your goods",
				rewardVp: "{{n}} VP each",
				rewardCard: "draw {{n}} each",
				rewardPairVp: "for {{n}} VP",
				rewardAllVp: "{{n}} VP per good beyond the first",
				discardHand: "IV: discard up to {{n}} hand cards for {{v}} VP each",
				drawLucky: "IV: guess a cost 1-7 and draw; keep it if right",
				tradeAction: "IV: discard a good to draw its trade price",
				tradeActionNoBonus: "IV: discard a good to draw its trade price (no bonuses)",
				tradeAny: "IV: draw {{n}} more when selling",
				tradeKind: "IV: draw {{n}} more when selling {{kind}}",
				tradeThis: "IV: draw {{n}} more when selling this world",
				consumeDraw: "IV: draw 1 at the start of Consume",
				produce: "V: produce a good",
				windfallKind: "V: produce on a {{kind}} windfall world",
				windfallAny: "V: produce on any windfall world",
				prodDraw: "V: draw {{n}} at the start of Produce",
				prodDrawIf: "V: if this world produced, draw {{n}}",
				prodDrawGene: "V: draw 1 per Genes world you have",
				prodDrawEachNovelty: "V: draw 1 per Novelty good produced this phase",
				prodDrawEachAlien: "V: draw 1 per Alien good produced this phase",
				prodDrawDiff: "V: draw 1 per different kind produced this phase",
				prodDrawMostRare: "V: if you produced the most Rare goods, draw {{n}}"
			},
			vpb: {
				threeVp: "{{n}} VP per 3 VP chips",
				totalMilitary: "{{n}} VP per permanent Military",
				name: "{{n}} VP per \"{{name}}\"",
				noveltyProd: "{{n}} VP per Novelty production world",
				rareProd: "{{n}} VP per Rare production world",
				geneProd: "{{n}} VP per Genes production world",
				alienProd: "{{n}} VP per Alien production world",
				noveltyWind: "{{n}} VP per Novelty windfall world",
				rareWind: "{{n}} VP per Rare windfall world",
				geneWind: "{{n}} VP per Genes windfall world",
				alienWind: "{{n}} VP per Alien windfall world",
				militaryWorld: "{{n}} VP per military world",
				rebelMilitary: "{{n}} VP per Rebel military world",
				sixDevel: "{{n}} VP per 6-cost development",
				devel: "{{n}} VP per development",
				world: "{{n}} VP per world",
				alienFlag: "{{n}} VP per Alien card",
				develExplore: "{{n}} VP per Explore development",
				worldExplore: "{{n}} VP per Explore world",
				develConsume: "{{n}} VP per Consume development",
				worldConsume: "{{n}} VP per Consume world",
				develTrade: "{{n}} VP per Trade development",
				worldTrade: "{{n}} VP per Trade world"
			},
			errPhase: "Not allowed right now",
			errCard: "Invalid card",
			errCount: "Wrong number of cards",
			errIllegal: "Illegal move"
		}
	}
};
//#endregion
export { Bt as default };
