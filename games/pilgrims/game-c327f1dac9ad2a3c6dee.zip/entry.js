import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { GameScreen as r } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as i } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as a, seatName as o } from "@bgparty/sdk/ui/player-strip";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { LogTicker as l } from "@bgparty/sdk/ui/log-sheet";
import { BottomSheet as u } from "@bgparty/sdk/bottom-sheet";
import { Texture as d } from "@bgparty/sdk/texture";
import { DeltaNumber as f } from "@bgparty/sdk/fx/delta-number";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { ConfirmButton as g } from "@bgparty/sdk/confirm-button";
import { IconClose as ee } from "@bgparty/sdk/icons";
import { Confetti as te } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as _, OptionSection as ne, OptionSwitch as v } from "@bgparty/sdk/ui/game-options";
//#region src/games/pilgrims/data.ts
var y = [
	"red",
	"blue",
	"green",
	"gold"
], b = [
	"sword",
	"notes",
	"compass",
	"star"
], re = [
	1,
	3,
	10,
	14,
	21,
	23
], x = [
	0,
	4,
	20,
	24
], S = (e, t = {}) => ({
	kind: "move",
	paths: e,
	...t
}), C = (...e) => e.map((e) => Array.from({ length: e }, (e, t) => [t + 1, 0])), w = (...e) => e.map((e) => Array.from({ length: e }, (e, t) => [t + 1, t + 1])), ie = [[
	[1, 0],
	[2, 0],
	[2, -1]
]], ae = [[[1, 0], [2, 0]], [
	[1, 0],
	[2, 0],
	[2, -1]
]], oe = S(C(1)), T = { kind: "clover" }, se = [
	S(C(1, 2)),
	S(ie),
	S(w(1, 2)),
	S([...C(1), ...w(1)])
], E = (e, t, ...n) => ({
	types: e,
	activate: t,
	abilities: n
}), D = [
	E(["scoundrel", "wanderer"], ["sword"], S(w(1))),
	E(["nobleheart"], ["compass", "star"], T, { kind: "extra" }),
	E(["nobleheart", "beast"], ["notes", "star"], { kind: "chooseCompanion" }),
	E(["beast"], ["star"], S([[[1, 0], [2, 0]], [[1, -1], [2, -2]]])),
	E(["wanderer"], ["sword"], S(ie), { kind: "swap" }),
	E(["wanderer"], ["star"], {
		kind: "take",
		color: "green",
		adjacent: !0
	}, {
		kind: "take",
		color: "green",
		adjacent: !0
	}),
	E(["nobleheart"], ["notes", "compass"], S(C(2))),
	E(["scoundrel"], ["compass"], S(C(2, 4))),
	E(["wanderer"], ["sword", "compass"], oe),
	E(["scoundrel"], ["star", "compass"], S(ie)),
	E(["scoundrel"], ["sword"], S(C(2)), {
		kind: "paid",
		effect: S(C(2))
	}),
	E(["beast"], ["star"], { kind: "item" }, {
		kind: "paid",
		effect: { kind: "extra" }
	}),
	E(["beast"], ["sword"], {
		kind: "take",
		color: "red",
		adjacent: !0
	}, T),
	E(["wanderer"], ["notes"], S(C(2), { encounter: !0 })),
	E(["nobleheart"], ["notes"], {
		kind: "take",
		color: "blue",
		adjacent: !0
	}, T),
	E(["scoundrel"], ["star"], S(ae)),
	E(["beast", "scoundrel"], ["star"], S(C(2))),
	E(["beast"], ["compass"], {
		kind: "take",
		color: "green",
		adjacent: !0
	}, T),
	E(["nobleheart", "wanderer"], ["compass"], oe),
	E(["nobleheart"], ["notes"], S(C(2), { encounter: !0 })),
	E(["wanderer"], [
		"sword",
		"compass",
		"notes"
	], { kind: "chooseItem" }),
	E(["scoundrel"], [
		"notes",
		"star",
		"compass"
	], S(w(2))),
	E(["nobleheart"], ["notes"], {
		kind: "take",
		color: "red",
		adjacent: !0
	}, {
		kind: "take",
		color: "red",
		adjacent: !0
	}),
	E(["wanderer"], ["notes"], S(w(2)), T),
	E(["nobleheart"], ["sword"], S(w(1, 2))),
	E(["beast"], ["sword", "notes"], S(C(2))),
	E(["nobleheart"], ["sword", "star"], S(w(1))),
	E(["scoundrel"], ["star"], S(C(2, 3))),
	E(["scoundrel"], ["sword"], {
		kind: "take",
		color: "blue",
		adjacent: !0
	}, {
		kind: "take",
		color: "blue",
		adjacent: !0
	}),
	E(["beast"], ["sword"], S(C(1, 2))),
	E(["beast"], ["compass"], S(ie, { corner: !0 })),
	E(["wanderer"], ["compass", "notes"], S(w(1)))
];
function ce(e, t) {
	let n = [
		["notes", "compass"],
		["star", "sword"],
		["sword", "notes"],
		["compass", "star"]
	], r = [
		"notes",
		"star",
		"sword",
		"compass"
	], i = [
		S([...C(1), ...w(1)]),
		S(ae),
		S(C(1, 2)),
		S(C(2, 3))
	];
	return E([], t === "A" ? n[e] : [r[e]], t === "A" ? oe : i[e], { kind: "reserve" });
}
var O = [
	{
		color: "red",
		activate: "sword",
		art: 0
	},
	{
		color: "red",
		activate: "notes",
		art: 1
	},
	{
		color: "red",
		activate: "compass",
		art: 2
	},
	{
		color: "red",
		activate: "star",
		art: 3
	},
	{
		color: "blue",
		activate: "sword",
		art: 4
	},
	{
		color: "blue",
		activate: "notes",
		art: 5
	},
	{
		color: "blue",
		activate: "compass",
		art: 6
	},
	{
		color: "blue",
		activate: "star",
		art: 7
	},
	{
		color: "green",
		activate: "sword",
		art: 8
	},
	{
		color: "green",
		activate: "notes",
		art: 9
	},
	{
		color: "green",
		activate: "compass",
		art: 10
	},
	{
		color: "green",
		activate: "star",
		art: 11
	},
	...b.map((e) => ({
		color: "gold",
		activate: e,
		art: 12
	}))
].flatMap((e, t) => Array.from({ length: t < 12 ? 5 : 1 }, () => e)), k = (e, t, n, r, i, a, o) => ({
	level: e,
	cost: t,
	party: n,
	retire: r,
	points: i,
	clovers: a,
	...o ? { improvement: o } : {}
}), A = (e) => ({
	kind: "discount",
	color: e
}), j = (e, t = [], n = 0) => ({
	kind: "travel",
	mode: e,
	effects: t,
	extra: n
}), M = (e) => ({
	kind: "activateColor",
	color: e,
	effect: T
}), N = (e) => ({
	kind: "activateSymbol",
	symbol: e,
	effect: { kind: "item" }
}), P = [
	k(1, [
		0,
		1,
		3
	], ["any", "any"], 1, 2, 1, A("red")),
	k(1, [
		1,
		0,
		3
	], [
		"any",
		"any",
		"any"
	], 0, 3, 1, {
		...j(0),
		passItem: !0
	}),
	k(1, [
		0,
		3,
		0
	], ["any"], 0, 2, 1, j(0, [T], 2)),
	k(1, [
		0,
		1,
		2
	], ["any", "any"], 0, 2, 2, { kind: "capacity" }),
	k(1, [
		0,
		4,
		0
	], ["any", "any"], 1, 5, 0, j(1, [T, { kind: "swap" }])),
	k(1, [
		2,
		1,
		1
	], ["any", "any"], 0, 2, 1, j(2, [{ kind: "chooseItem" }])),
	k(1, [
		3,
		1,
		0
	], ["any"], 0, 3, 0, j(3, [T], 1)),
	k(1, [
		3,
		0,
		2
	], ["any"], 1, 3, 0, A("blue")),
	k(1, [
		0,
		3,
		0
	], ["any"], 1, 3, 0, j(1, [{
		kind: "take",
		color: "green"
	}])),
	k(1, [
		1,
		2,
		0
	], ["any", "any"], 0, 3, 1, { kind: "capacity" }),
	k(1, [
		0,
		3,
		0
	], ["any", "any"], 0, 2, 2, { kind: "reserveCapacity" }),
	k(1, [
		4,
		0,
		0
	], ["any", "any"], 1, 3, 0, A("green")),
	k(1, [
		3,
		1,
		0
	], [
		"any",
		"any",
		"any"
	], 1, 3, 0, A("green")),
	k(1, [
		0,
		0,
		3
	], ["any"], 1, 2, 1, j(0, [{
		kind: "take",
		color: "red"
	}])),
	k(1, [
		0,
		1,
		3
	], ["any", "any"], 1, 4, 0, j(3, [{
		kind: "take",
		color: "blue"
	}])),
	k(1, [
		0,
		0,
		3
	], ["any"], 0, 2, 0, j(3, [T], 1)),
	k(1, [
		3,
		0,
		1
	], ["any", "any"], 1, 2, 1, A("blue")),
	k(1, [
		3,
		0,
		1
	], ["any", "any"], 0, 2, 0, j(2, [{ kind: "extra" }])),
	k(1, [
		0,
		3,
		1
	], ["any", "any"], 1, 3, 0, A("red")),
	k(1, [
		2,
		1,
		2
	], [
		"any",
		"any",
		"any"
	], 0, 4, 1, j(1, [T, { kind: "swap" }])),
	k(2, [
		0,
		4,
		0
	], ["nobleheart", "any"], 1, 4, 0, A("green")),
	k(2, [
		3,
		1,
		1
	], ["wanderer", "scoundrel"], 1, 8, 1),
	k(2, [
		1,
		3,
		1
	], ["beast"], 1, 7, 1),
	k(2, [
		4,
		1,
		0
	], [
		"nobleheart",
		"any",
		"any"
	], 1, 6, 0, N("notes")),
	k(2, [
		2,
		4,
		0
	], ["nobleheart", "scoundrel"], 0, 9, 0),
	k(2, [
		2,
		0,
		3
	], ["wanderer"], 1, 4, 1, N("compass")),
	k(2, [
		0,
		1,
		4
	], [
		"wanderer",
		"any",
		"any"
	], 0, 6, 0, M("red")),
	k(2, [
		0,
		4,
		0
	], ["beast", "any"], 0, 5, 0, {
		kind: "completed",
		effect: T
	}),
	k(2, [
		0,
		1,
		4
	], ["nobleheart"], 0, 5, 1, {
		kind: "completed",
		effect: T
	}),
	k(2, [
		1,
		1,
		3
	], [
		"scoundrel",
		"beast",
		"any"
	], 2, 7, 0, {
		kind: "discount",
		color: "gold",
		paid: !0
	}),
	k(2, [
		3,
		0,
		3
	], ["scoundrel"], 0, 4, 1, N("sword")),
	k(2, [
		0,
		1,
		4
	], [
		"scoundrel",
		"any",
		"any"
	], 1, 6, 0, N("star")),
	k(2, [
		2,
		3,
		0
	], ["nobleheart", "any"], 2, 8, 0, {
		kind: "encounter",
		effect: T
	}),
	k(2, [
		3,
		0,
		3
	], ["beast", "any"], 0, 7, 0, M("blue")),
	k(2, [
		3,
		0,
		2
	], ["wanderer", "any"], 0, 5, 0, M("green")),
	k(2, [
		0,
		4,
		0
	], ["wanderer"], 1, 4, 0, A("red")),
	k(2, [
		4,
		0,
		0
	], ["beast", "any"], 1, 4, 0, A("blue"))
], le = [
	{
		group: "A",
		kind: "type",
		value: "nobleheart"
	},
	{
		group: "C",
		kind: "travel"
	},
	{
		group: "C",
		kind: "clovers"
	},
	{
		group: "B",
		kind: "activation",
		value: "notes"
	},
	{
		group: "B",
		kind: "activation",
		value: "compass"
	},
	{
		group: "A",
		kind: "type",
		value: "beast"
	},
	{
		group: "C",
		kind: "level"
	},
	{
		group: "A",
		kind: "type",
		value: "scoundrel"
	},
	{
		group: "B",
		kind: "activation",
		value: "star"
	},
	{
		group: "C",
		kind: "discount"
	},
	{
		group: "B",
		kind: "activation",
		value: "sword"
	},
	{
		group: "A",
		kind: "type",
		value: "wanderer"
	}
], ue = [
	[
		3,
		0,
		0
	],
	[
		0,
		3,
		0
	],
	[
		0,
		0,
		3
	]
], F = [
	{
		cells: [
			0,
			12,
			21
		],
		points: 3,
		reward: "clover"
	},
	{
		cells: [
			7,
			10,
			22
		],
		points: 3,
		reward: "none"
	},
	{
		cells: [
			11,
			14,
			18
		],
		points: 2,
		reward: "item"
	},
	{
		cells: [
			4,
			13,
			23
		],
		points: 3,
		reward: "clover"
	},
	{
		cells: [
			12,
			15,
			21
		],
		points: 3,
		reward: "none"
	},
	{
		cells: [
			3,
			9,
			19
		],
		points: 3,
		reward: "none"
	},
	{
		cells: [
			1,
			11,
			20
		],
		points: 3,
		reward: "clover"
	},
	{
		cells: [
			6,
			17,
			23
		],
		points: 2,
		reward: "item"
	},
	{
		cells: [
			0,
			3,
			6
		],
		points: 3,
		reward: "clover"
	},
	{
		cells: [
			7,
			10,
			16
		],
		points: 2,
		reward: "item"
	},
	{
		cells: [
			14,
			17,
			20
		],
		points: 3,
		reward: "clover"
	},
	{
		cells: [
			1,
			4,
			8
		],
		points: 3,
		reward: "clover"
	},
	{
		cells: [
			5,
			16,
			23
		],
		points: 2,
		reward: "item"
	},
	{
		cells: [
			8,
			18,
			21
		],
		points: 2,
		reward: "item"
	},
	{
		cells: [
			1,
			5,
			15
		],
		points: 3,
		reward: "none"
	},
	{
		cells: [
			3,
			13,
			24
		],
		points: 3,
		reward: "clover"
	},
	{
		cells: [
			2,
			9,
			10
		],
		points: 3,
		reward: "none"
	}
], de = [
	{
		group: "B",
		offsets: [[-2, 0], [2, 0]],
		right: !0,
		reward: "none"
	},
	{
		group: "A",
		offsets: [[1, 0], [-1, 0]],
		right: !1,
		reward: "none"
	},
	{
		group: "B",
		offsets: [
			[2, -2],
			[-2, -2],
			[0, 2]
		],
		right: !1,
		reward: "none"
	},
	{
		group: "B",
		offsets: [
			[2, 2],
			[-2, 2],
			[0, -2]
		],
		right: !0,
		reward: "none"
	},
	{
		group: "D",
		offsets: [
			[2, -2],
			[-2, -2],
			[0, 2]
		],
		right: !1,
		reward: "item"
	},
	{
		group: "D",
		offsets: [[-2, 0], [2, 0]],
		right: !0,
		reward: "item"
	},
	{
		group: "C",
		offsets: [
			[-1, -1],
			[1, -1],
			[0, 1]
		],
		right: !0,
		reward: "clover"
	},
	{
		group: "A",
		offsets: [
			[-1, -1],
			[1, -1],
			[0, 1]
		],
		right: !0,
		reward: "none"
	},
	{
		group: "C",
		offsets: [[1, 0], [-1, 0]],
		right: !1,
		reward: "clover"
	},
	{
		group: "D",
		offsets: [
			[2, 2],
			[-2, 2],
			[0, -2]
		],
		right: !0,
		reward: "item"
	},
	{
		group: "C",
		offsets: [
			[-1, 1],
			[1, 1],
			[0, -1]
		],
		right: !1,
		reward: "clover"
	},
	{
		group: "A",
		offsets: [
			[-1, 1],
			[1, 1],
			[0, -1]
		],
		right: !1,
		reward: "none"
	}
], fe = /* @__PURE__ */ "games.pilgrims.c0,games.pilgrims.c1,games.pilgrims.c2,games.pilgrims.c3,games.pilgrims.c4,games.pilgrims.c5,games.pilgrims.c6,games.pilgrims.c7,games.pilgrims.c8,games.pilgrims.c9,games.pilgrims.c10,games.pilgrims.c11,games.pilgrims.c12,games.pilgrims.c13,games.pilgrims.c14,games.pilgrims.c15,games.pilgrims.c16,games.pilgrims.c17,games.pilgrims.c18,games.pilgrims.c19,games.pilgrims.c20,games.pilgrims.c21,games.pilgrims.c22,games.pilgrims.c23,games.pilgrims.c24,games.pilgrims.c25,games.pilgrims.c26,games.pilgrims.c27,games.pilgrims.c28,games.pilgrims.c29,games.pilgrims.c30,games.pilgrims.c31".split(","), pe = /* @__PURE__ */ "games.pilgrims.a0,games.pilgrims.a1,games.pilgrims.a2,games.pilgrims.a3,games.pilgrims.a4,games.pilgrims.a5,games.pilgrims.a6,games.pilgrims.a7,games.pilgrims.a8,games.pilgrims.a9,games.pilgrims.a10,games.pilgrims.a11,games.pilgrims.a12,games.pilgrims.a13,games.pilgrims.a14,games.pilgrims.a15,games.pilgrims.a16,games.pilgrims.a17,games.pilgrims.a18,games.pilgrims.a19,games.pilgrims.a20,games.pilgrims.a21,games.pilgrims.a22,games.pilgrims.a23,games.pilgrims.a24,games.pilgrims.a25,games.pilgrims.a26,games.pilgrims.a27,games.pilgrims.a28,games.pilgrims.a29,games.pilgrims.a30,games.pilgrims.a31,games.pilgrims.a32,games.pilgrims.a33,games.pilgrims.a34,games.pilgrims.a35,games.pilgrims.a36".split(","), I = [
	"games.pilgrims.i0",
	"games.pilgrims.i1",
	"games.pilgrims.i2",
	"games.pilgrims.i3",
	"games.pilgrims.i4",
	"games.pilgrims.i5",
	"games.pilgrims.i6",
	"games.pilgrims.i7",
	"games.pilgrims.i8",
	"games.pilgrims.i9",
	"games.pilgrims.i10",
	"games.pilgrims.i11",
	"games.pilgrims.i12"
], me = (e) => e.reduce((e, t) => e + t, 0);
function he(e, t) {
	let n = t.kind === "adventure" ? P[t.id] : null, r = [...n?.cost ?? ue[t.id]], i = 0;
	for (let t of e.completed) {
		let e = P[t].improvement;
		if (e?.kind === "discount") {
			if (e.paid) i++;
			else {
				let t = y.indexOf(e.color);
				r[t] = Math.max(0, r[t] - 1);
			}
		}
	}
	return {
		cost: r,
		party: n?.party ?? [],
		retire: n?.retire ?? 0,
		paid: i
	};
}
function ge(e, t) {
	if (!t) return [e];
	let n = [], r = /* @__PURE__ */ new Set();
	for (let i = 0; i < 3; i++) if (e[i]) {
		let a = [...e];
		a[i]--;
		for (let e of ge(a, t - 1)) r.has(e.join()) || (r.add(e.join()), n.push(e));
	}
	return n;
}
function _e(e, t) {
	return t.length ? Math.min(...e.map((n, r) => (t[0] === "any" || D[n].types.includes(t[0]) ? 0 : 2) + _e(e.filter((e, t) => t !== r), t.slice(1)))) : 0;
}
function ve(e, t, n, r) {
	let i = he(e, n), a = e.party.flatMap((e) => e.item === null ? [] : [e.item]), o = [...t, ...a];
	if (new Set(r.items).size !== r.items.length || new Set(r.companions).size !== r.companions.length || new Set(r.retire).size !== r.retire.length || !r.items.every((e) => o.includes(e)) || !r.companions.every((t) => e.party.some((e) => e.id === t && e.card >= 0)) || r.companions.length !== i.party.length || r.retire.length !== i.retire || !r.retire.every((e) => r.companions.includes(e)) || r.discount > i.paid || r.items.length !== me(i.cost) - r.discount) return null;
	let s = y.map((e) => r.items.filter((t) => O[t].color === e).length), c = Math.min(...ge(i.cost, r.discount).map((e) => Math.max(0, me(e) - e.reduce((e, t, n) => e + Math.min(t, s[n]), 0) - s[3]))) + _e(r.companions.map((t) => e.party.find((e) => e.id === t).card), i.party) + r.discount;
	return Number.isFinite(c) ? c : null;
}
function ye(e, t) {
	return t ? e.flatMap((n, r) => ye(e.slice(r + 1), t - 1).map((e) => [n, ...e])) : [[]];
}
function be(e, t, n) {
	let r = he(e, n), i = ye(e.party.filter((e) => e.card >= 0), r.party.length);
	if (!i.length) return null;
	let a = i.reduce((e, t) => _e(t.map((e) => e.card), r.party) < _e(e.map((e) => e.card), r.party) ? t : e), o = [...a].sort((e, t) => Number(e.item !== null) - Number(t.item !== null)).slice(0, r.retire).map((e) => e.id), s = [...e.party.flatMap((e) => e.item === null ? [] : [e.item]), ...t], c = null, l = Infinity;
	for (let i = 0; i <= Math.min(r.paid, me(r.cost)); i++) for (let u of ge(r.cost, i)) {
		let r = [...s], d = [];
		for (let e = 0; e < 3; e++) for (let t = 0; t < u[e]; t++) {
			let t = r.findIndex((t) => O[t].color === y[e]);
			t >= 0 && d.push(...r.splice(t, 1));
		}
		for (; d.length < me(u) && r.length;) {
			let e = r.findIndex((e) => O[e].color === "gold");
			d.push(...r.splice(e >= 0 ? e : 0, 1));
		}
		let f = {
			type: "pay",
			items: d,
			companions: a.map((e) => e.id),
			retire: o,
			discount: i
		}, p = ve(e, t, n, f);
		if (p === null || p > e.clovers) continue;
		let m = p * 2 + d.length + d.filter((e) => O[e].color === "gold").length * .6 + d.filter((e) => t.includes(e)).length * .05;
		m < l && (c = f, l = m);
	}
	return c;
}
//#endregion
//#region src/games/pilgrims/meta.ts
var xe = {
	id: "pilgrims",
	tier: "alpha",
	nameKey: "games.pilgrims.name",
	descKey: "games.pilgrims.desc",
	rulesKey: "games.pilgrims.rules",
	icon: "🍀",
	iconImg: "games/pilgrims.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [
		2,
		3,
		4
	],
	mechanics: [
		"grid-movement",
		"hand-management",
		"engine-building",
		"set-collection"
	],
	interactionTags: [],
	rulesUrl: { en: "https://www.pinktroubadour.eu/download/6/pilgrims-rulebook.pdf" },
	accent: "#376f55",
	releasedAt: "2026-10-30T01:50:00+08:00",
	search: {
		py: "chaoshengzheyichangqihuanmaoxian",
		init: "cszycqhmx"
	},
	hotseat: "cover",
	botDelayMs: 500
}, Se = t.object({
	journeys: t.boolean().default(!1),
	leaderSide: t.enum(["A", "B"]).default("A"),
	soloDifficulty: t.enum([
		"AB",
		"BC",
		"AD",
		"CD"
	]).default("AB")
}).default({
	journeys: !1,
	leaderSide: "A",
	soloDifficulty: "AB"
}), L = t.int().nonnegative(), Ce = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("choose"),
		id: t.string().max(120)
	}),
	t.object({ type: t.literal("buyItem") }),
	t.object({
		type: t.literal("pay"),
		items: t.array(L).max(64),
		companions: t.array(L).max(8),
		retire: t.array(L).max(8),
		discount: t.int().min(0).max(10)
	}),
	t.object({ type: t.literal("cancel") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), we = t.object({
	id: L,
	card: t.int().min(-1).max(31),
	item: L.nullable()
}), Te = t.object({
	card: L,
	visited: t.array(L)
}), Ee = t.object({
	rid: t.string(),
	leader: L,
	position: t.int(),
	handCount: L,
	soloItems: t.array(L).optional(),
	clovers: L,
	party: t.array(we),
	retired: t.array(L),
	completed: t.array(L),
	reserved: t.array(L),
	used: t.array(L),
	activated: t.array(L),
	journey: Te.nullable(),
	journeys: t.array(L),
	solo: t.boolean()
}), De = t.enum([
	"corner",
	"journey",
	"travel",
	"activate",
	"effects",
	"move",
	"take",
	"swap",
	"reserve",
	"returnReserve",
	"retire",
	"chooseItem",
	"chooseCompanion",
	"adventure",
	"pay",
	"resolve",
	"done"
]), Oe = t.object({
	id: t.string(),
	kind: t.enum([
		"corner",
		"journey",
		"travel",
		"activate",
		"clover",
		"effect",
		"move",
		"take",
		"swap",
		"reserve",
		"returnReserve",
		"retire",
		"chooseItem",
		"chooseCompanion",
		"adventure",
		"quest",
		"skip"
	]),
	card: t.int().optional(),
	character: t.int().optional(),
	item: L.optional(),
	cost: L.optional(),
	cells: t.array(L).optional(),
	effect: t.int().optional()
}), ke = t.object({
	adventures: t.number(),
	clovers: t.number(),
	quests: t.number(),
	journeys: t.number(),
	items: t.number(),
	total: t.number(),
	questDetails: t.array(t.object({
		slot: L,
		count: L,
		points: L
	}))
}), Ae = t.lazy(() => t.union([
	t.object({
		kind: t.literal("move"),
		paths: t.array(t.array(t.tuple([t.number(), t.number()]))),
		passItem: t.boolean().optional(),
		encounter: t.boolean().optional(),
		corner: t.boolean().optional()
	}),
	t.object({ kind: t.enum([
		"clover",
		"item",
		"chooseItem",
		"chooseCompanion",
		"reserve",
		"extra",
		"swap"
	]) }),
	t.object({
		kind: t.literal("take"),
		color: t.enum([
			"red",
			"blue",
			"green",
			"gold"
		]),
		adjacent: t.boolean().optional()
	}),
	t.object({
		kind: t.literal("paid"),
		effect: Ae
	})
])), je = t.object({
	id: L,
	source: t.int(),
	kind: t.string(),
	ability: Ae,
	color: t.string().optional(),
	paid: t.boolean()
}), Me = t.object({
	config: Se,
	players: t.array(Ee),
	phase: De,
	actor: t.string(),
	turn: t.string(),
	first: t.string(),
	round: L,
	turnInRound: L,
	board: t.array(t.object({
		kind: t.enum(["item", "companion"]),
		card: L
	}).nullable()),
	market: t.array(L.nullable()),
	quests: t.array(t.object({
		card: L,
		signed: t.array(t.string())
	})),
	deckCounts: t.object({
		items: L,
		companions: L,
		adventure1: L,
		adventure2: L,
		journeys: L
	}),
	discard: t.array(L),
	effects: t.array(je),
	choices: t.array(Oe),
	scores: t.record(t.string(), ke),
	payment: t.object({
		kind: t.enum(["adventure", "quest"]),
		id: L
	}).nullable(),
	falcon: t.int().nullable(),
	soloCard: L.nullable(),
	pendingAbility: Ae.nullable(),
	extraActivation: t.boolean(),
	log: t.array(t.object({
		n: L,
		rid: t.string(),
		kind: t.enum([
			"item",
			"companion",
			"move",
			"activate",
			"clover",
			"retire",
			"reserve",
			"adventure",
			"quest",
			"journey",
			"round",
			"swap",
			"end"
		]),
		card: t.int().optional(),
		amount: t.number().optional(),
		cell: L.optional()
	}))
}), Ne = t.object({
	hand: t.array(L),
	choices: t.array(Oe)
}), Pe = "$falconer", R = (e, t) => e.players.find((e) => e.rid === t), Fe = (e) => {
	let { hand: t, ...n } = e;
	return {
		...n,
		handCount: t.length,
		...e.solo ? { soloItems: [...t] } : {}
	};
}, Ie = (t, n) => e(t.seed, t.cursor++, n);
function Le(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = Ie(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
var z = (e, t, n, r = {}) => {
	e.log.push({
		n: e.serial++,
		rid: t,
		kind: n,
		...r
	}), e.log = e.log.slice(-150);
};
function B(e, ...t) {
	e.tasks.unshift(...t), e.phase = "resolve", e.choices = [], e.pending = null;
}
function V(e, t, n, r, i = null) {
	e.phase = t, e.actor = n, e.choices = r, e.pending = i;
}
function Re(e) {
	return e.itemDeck.length || (e.itemDeck = Le(e, e.discard), e.discard = []), e.itemDeck.shift();
}
function ze(e, t, n) {
	let r = n ?? Re(e);
	r !== void 0 && (R(e, t).hand.push(r), z(e, t, "item", { amount: 1 }));
}
function Be(e, t, n = 1) {
	R(e, t).clovers += n, z(e, t, "clover", { amount: n }), t === "$falconer" && R(e, t).clovers >= 2 && B(e, {
		kind: "soloBuy",
		by: t
	});
}
var Ve = (e) => e.solo ? [] : e.completed.flatMap((e) => P[e].improvement ? [P[e].improvement] : []), He = (e, t, n) => n === 32 ? ce(t.leader, e.config.leaderSide) : D[n], Ue = (e, t, n) => e.players.some((e) => e.rid !== n && e.position === t) || e.falcon === t, We = (e, t) => e >= 0 && e < 5 && t >= 0 && t < 5;
function Ge(e, t, n = 0) {
	let r = [], i = /* @__PURE__ */ new Set(), a = e % 5, o = Math.floor(e / 5);
	for (let e of t.paths) for (let t = 0; t < 4; t++) for (let s of [1, -1]) for (let c = 0; c <= n; c++) {
		let n = e.map(([e, t]) => [e, t]), l = n.at(-1), u = n.at(-2) ?? [0, 0], d = [l[0] - u[0], l[1] - u[1]];
		for (let e = 1; e <= c; e++) n.push([l[0] + d[0] * e, l[1] + d[1] * e]);
		let f = n.map(([e, n]) => {
			let r = e * s, i = n;
			for (let e = 0; e < t; e++) [r, i] = [-i, r];
			return [a + r, o + i];
		});
		if (!f.every(([e, t]) => We(e, t))) continue;
		let p = f.map(([e, t]) => t * 5 + e), m = p.join(".");
		i.has(m) || (i.add(m), r.push(p));
	}
	return r;
}
function Ke(e, t, n) {
	let r = t.party.find((e) => e.id === n);
	r.item !== null && e.discard.push(r.item), t.retired.push(r.card), t.party = t.party.filter((e) => e.id !== n), z(e, t.rid, "retire", { card: r.card });
}
function qe(e, t, n) {
	let r = R(e, t), i = 3 + Ve(r).filter((e) => e.kind === "capacity").length;
	if (!r.solo && r.party.filter((e) => e.card >= 0).length >= i) {
		V(e, "retire", t, r.party.filter((e) => e.card >= 0).map((e) => ({
			id: `retire:${e.id}`,
			kind: "retire",
			character: e.id
		})), {
			kind: "acquire",
			by: t,
			card: n
		});
		return;
	}
	r.party.push({
		id: n,
		card: n,
		item: null
	}), z(e, t, "companion", { card: n }), r.solo && Be(e, t);
}
function Je(e, t, n) {
	let r = re.includes(n) ? "companion" : "item", i = e.board[n]?.card ?? (r === "item" ? Re(e) : e.companionDeck.shift());
	e.board[n] = null, i !== void 0 && (r === "item" ? ze(e, t, i) : qe(e, t, i));
}
function Ye(e, t, n = -1) {
	e.effects.push({
		id: e.effectId++,
		source: n,
		ability: t
	});
}
function Xe(e, t, n) {
	for (let r of Ve(t)) n(r) && "effect" in r && Ye(e, r.effect);
}
function Ze(e, t, n, r = !1) {
	let i = R(e, n);
	if (t === "travel" && V(e, t, n, se.flatMap((e, t) => i.used.includes(t) ? [] : [{
		id: `travel:${t}`,
		kind: "travel",
		card: t
	}])), t === "activate") {
		e.extraActivation = r;
		let a = [r ? {
			id: "skip",
			kind: "skip"
		} : {
			id: "clover",
			kind: "clover"
		}];
		for (let t of i.party) if (!i.activated.includes(t.id)) for (let n of i.hand) {
			let r = +!He(e, i, t.id).activate.includes(O[n].activate);
			i.clovers >= r && a.push({
				id: `activate:${t.id}:${n}`,
				kind: "activate",
				character: t.id,
				item: n,
				cost: r
			});
		}
		V(e, t, n, a);
	}
	if (t === "effects") {
		if (!e.effects.length) {
			e.tasks.length || B(e, {
				kind: "phase",
				by: n,
				phase: "adventure"
			});
			return;
		}
		let r = e.effects.some((e) => e.ability.kind === "swap");
		V(e, t, n, e.effects.filter((e) => !r || e.ability.kind !== "move").map((e) => ({
			id: `effect:${e.id}`,
			kind: "effect",
			effect: e.id
		})));
	}
	if (t === "adventure") {
		let r = [...e.market, ...i.reserved].flatMap((e) => e === null ? [] : [{
			id: `adventure:${e}`,
			kind: "adventure",
			card: e
		}]);
		e.quests.filter((e) => e.signed.includes(n)).length < 2 && e.quests.forEach((e, t) => {
			e.signed.length < 3 && !e.signed.includes(n) && r.push({
				id: `quest:${t}`,
				kind: "quest",
				card: t
			});
		}), r.push({
			id: "skip",
			kind: "skip"
		}), V(e, t, n, r);
	}
}
function Qe(e, t) {
	let { by: n } = t, r = R(e, n), i = t.ability;
	switch (i.kind) {
		case "clover":
			Be(e, n);
			break;
		case "item":
			ze(e, n);
			break;
		case "move": {
			let a = t.source === -2 ? Ve(r).reduce((t, n) => t + (n.kind === "travel" && n.mode === e.selectedTravel ? n.extra ?? 0 : 0), 0) : 0, o = Ge(r.position, i, a);
			o.length && V(e, "move", n, o.map((e) => ({
				id: `move:${e.join(".")}`,
				kind: "move",
				cells: e
			})), t);
			break;
		}
		case "take": {
			let a = e.board.flatMap((e, t) => e?.kind === "item" && O[e.card].color === i.color && (!i.adjacent || Math.abs(t % 5 - r.position % 5) + Math.abs(Math.floor(t / 5) - Math.floor(r.position / 5)) === 1) ? [t] : []);
			a.length && V(e, "take", n, a.map((e) => ({
				id: `take:${e}`,
				kind: "take",
				cells: [e]
			})), t);
			break;
		}
		case "chooseItem":
		case "chooseCompanion": {
			let r = [];
			for (let t = 0; t < 2; t++) {
				let t = i.kind === "chooseItem" ? Re(e) : e.companionDeck.shift();
				t !== void 0 && r.push(t);
			}
			let a = i.kind;
			r.length && V(e, a, n, r.map((e) => ({
				id: `${a}:${e}`,
				kind: a,
				card: e
			})), {
				...t,
				cells: r
			});
			break;
		}
		case "reserve": {
			let i = 1 + Ve(r).filter((e) => e.kind === "reserveCapacity").length;
			if (r.reserved.length >= i) {
				V(e, "returnReserve", n, r.reserved.map((e) => ({
					id: `return:${e}`,
					kind: "returnReserve",
					card: e
				})), t);
				break;
			}
			let a = e.market.flatMap((e) => e === null ? [] : [{
				id: `reserve:${e}`,
				kind: "reserve",
				card: e
			}]);
			e.adventureDecks.forEach((e, t) => {
				e.length && a.push({
					id: `deck:${t}`,
					kind: "reserve",
					card: -1 - t
				});
			}), a.length && V(e, "reserve", n, a, t);
			break;
		}
		case "extra":
			B(e, {
				kind: "phase",
				by: n,
				phase: "activate",
				source: 1
			});
			break;
		case "paid":
			r.clovers && V(e, "effects", n, [{
				id: "paid",
				kind: "effect",
				cost: 1
			}, {
				id: "skip",
				kind: "skip"
			}], t);
			break;
		case "swap": {
			let r = [];
			e.board.forEach((t, n) => {
				if (t?.kind === "item") for (let t of [n + 1, n + 5]) t < 25 && Math.abs(t % 5 - n % 5) + Math.abs(Math.floor(t / 5) - Math.floor(n / 5)) === 1 && e.board[t]?.kind === "item" && r.push({
					id: `swap:${n}:${t}`,
					kind: "swap",
					cells: [n, t]
				});
			}), r.length && V(e, "swap", n, [...r, {
				id: "skip",
				kind: "skip"
			}], t);
			break;
		}
	}
}
function $e(e, t) {
	let n = e.journeyDeck.splice(0, 2);
	n.length && V(e, "journey", t, n.map((e) => ({
		id: `journey:${e}`,
		kind: "journey",
		card: e
	})), {
		kind: "journey",
		by: t,
		cells: n
	});
}
function et(e, t) {
	for (let n = t.cell ?? 0; n < 30; n++) {
		if (n < 25) {
			if (e.board[n] || Ue(e, n)) continue;
			let r = re.includes(n) ? "companion" : "item", i = r === "item" ? Re(e) : e.companionDeck.shift();
			if (i === void 0) continue;
			e.board[n] = {
				kind: r,
				card: i
			}, B(e, {
				...t,
				cell: n + 1
			});
			return;
		}
		let r = n - 25;
		if (e.market[r] !== null) continue;
		let i = r < (e.round <= 2 ? 3 : 2) ? 0 : 1, a = e.adventureDecks[i].shift() ?? e.adventureDecks[1 - i].shift();
		if (a !== void 0) {
			e.market[r] = a, B(e, {
				...t,
				cell: n + 1
			});
			return;
		}
	}
}
function tt(e) {
	if (e.turn = (e.turn + 1) % e.players.length, e.turn === e.first && e.turnInRound++, e.turnInRound === 3) {
		if (e.round === 4) {
			e.phase = "done", e.actor = "", z(e, "", "end");
			return;
		}
		e.round++, e.turnInRound = 0;
		for (let t of e.players) t.used = [];
		e.round === 3 && e.market[2] !== null && P[e.market[2]].level === 1 && (e.adventureDecks[0].push(e.market[2]), e.market[2] = null), e.players.some((e) => e.solo) && (e.soloDeck = Le(e, e.soloUsed), e.soloUsed = []), z(e, "", "round", { amount: e.round });
	}
	B(e, {
		kind: "startTurn",
		by: e.players[e.turn].rid
	});
}
function nt(e, t) {
	let n = [...e.hand], r = [], i = 0;
	for (let e = 0; e < 3; e++) for (let a = 0; a < t[e]; a++) {
		let t = n.findIndex((t) => O[t].color === [
			"red",
			"blue",
			"green"
		][e]);
		t >= 0 ? r.push(...n.splice(t, 1)) : i++;
	}
	let a = n.filter((e) => O[e].color === "gold");
	return a.length >= i ? [...r, ...a.slice(0, i)] : null;
}
function rt(e, t, n) {
	t.hand = t.hand.filter((e) => !n.includes(e));
	for (let e of t.party) e.item !== null && n.includes(e.item) && (e.item = null);
	e.discard.push(...n);
}
function it(e, t, n) {
	if (n.kind === "adventure") {
		let r = e.market.indexOf(n.id);
		r >= 0 && (e.market[r] = null), t.reserved = t.reserved.filter((e) => e !== n.id), Xe(e, t, (e) => e.kind === "completed"), t.completed.push(n.id), z(e, t.rid, "adventure", { card: n.id });
		let i = P[n.id].clovers;
		i && B(e, {
			kind: "ability",
			by: t.rid,
			ability: { kind: "clover" },
			card: i
		});
	} else e.quests[n.id].signed.push(t.rid), z(e, t.rid, "quest", { card: n.id }), le[e.quests[n.id].card].group === "C" && B(e, {
		kind: "ability",
		by: t.rid,
		ability: { kind: "clover" }
	});
}
function at(e) {
	let t = e.tasks.shift();
	if (!t) {
		Ze(e, "adventure", e.players[e.turn].rid);
		return;
	}
	let { by: n } = t, r = R(e, n);
	switch (e.pending = null, e.choices = [], e.phase = "resolve", t.kind) {
		case "spend":
			r.clovers -= t.cost ?? 0, rt(e, r, t.cells ?? []);
			break;
		case "retire":
			Ke(e, r, t.card);
			break;
		case "complete":
			it(e, r, t.target), e.payment = null;
			break;
		case "phase":
			Ze(e, t.phase, n, t.source === 1);
			break;
		case "ability":
			t.ability?.kind === "clover" && t.card ? Be(e, n, t.card) : Qe(e, t);
			break;
		case "acquire":
			t.cell === void 0 ? t.card !== void 0 && qe(e, n, t.card) : Je(e, n, t.cell);
			break;
		case "position":
			if (t.figure === 1 ? e.falcon = t.cell : r.position = t.cell, z(e, n, "move", { cell: t.cell }), !r.solo) {
				let i = t.cells ?? [t.cell];
				i.some((t) => Ue(e, t, n)) && Xe(e, r, (e) => e.kind === "encounter");
				let a = t.ability;
				if (a?.kind === "move" && a.encounter && i.some((t) => Ue(e, t, n)) && Ye(e, { kind: "clover" }), a?.kind === "move" && a.corner && x.includes(t.cell) && Ye(e, { kind: "clover" }), r.journey && F[r.journey.card].cells.includes(t.cell) && !r.journey.visited.includes(t.cell) && (r.journey.visited.push(t.cell), r.journey.visited.length === 3)) {
					let t = r.journey.card, i = F[t].reward;
					r.journeys.push(t), r.journey = null, z(e, n, "journey", { card: t }), B(e, ...i === "none" ? [] : [{
						kind: "ability",
						by: n,
						ability: { kind: i }
					}], {
						kind: "journey",
						by: n
					});
				}
			}
			break;
		case "journey":
			$e(e, n);
			break;
		case "replenish":
			et(e, t);
			break;
		case "endTurn":
			tt(e);
			break;
		case "startTurn":
			e.actor = n, r.activated = [], e.effects = [], e.selectedTravel = -1, r.solo ? B(e, {
				kind: "soloFlip",
				by: n,
				figure: 1
			}, {
				kind: "soloFlip",
				by: n,
				figure: 0
			}, {
				kind: "soloAdventure",
				by: n
			}, {
				kind: "replenish",
				by: n
			}, {
				kind: "endTurn",
				by: n
			}) : B(e, {
				kind: "replenish",
				by: n
			}, {
				kind: "phase",
				by: n,
				phase: "travel"
			});
			break;
		case "soloBuy":
			r.clovers >= 2 && (r.clovers -= 2, ze(e, n), r.clovers >= 2 && B(e, t));
			break;
		case "soloFlip": {
			let r = e.soloDeck.shift();
			e.soloUsed.push(r), e.soloCard = r, B(e, ...de[r].reward === "none" ? [] : [{
				kind: "ability",
				by: n,
				ability: { kind: de[r].reward }
			}], {
				kind: "soloMove",
				by: n,
				card: r,
				figure: t.figure
			});
			break;
		}
		case "soloMove": {
			let i = t.figure === 1 ? e.falcon : r.position, a = de[t.card].offsets.find(([e, t]) => We(i % 5 + e, Math.floor(i / 5) + t));
			if (a) {
				let r = i + a[0] + a[1] * 5;
				B(e, {
					kind: "acquire",
					by: n,
					cell: r
				}, {
					kind: "position",
					by: n,
					cell: r,
					figure: t.figure
				});
			}
			break;
		}
		case "soloAdventure": {
			let t = [
				0,
				1,
				2,
				3,
				4
			];
			de[e.soloCard].right || t.reverse();
			let i = !1;
			for (let a of t) {
				let t = e.market[a];
				if (t === null) continue;
				let o = nt(r, P[t].cost);
				if (o) {
					B(e, {
						kind: "spend",
						by: n,
						cells: o
					}, {
						kind: "complete",
						by: n,
						target: {
							kind: "adventure",
							id: t
						}
					}), i = !0;
					break;
				}
			}
			if (!i && e.quests.filter((e) => e.signed.includes(n)).length < 2) for (let i of t.filter((e) => e < 3)) {
				let t = e.quests[i];
				if (t.signed.includes(n) || t.signed.length >= 3) continue;
				let a = nt(r, [
					[
						3,
						0,
						0
					],
					[
						0,
						3,
						0
					],
					[
						0,
						0,
						3
					]
				][i]);
				if (a) {
					B(e, {
						kind: "spend",
						by: n,
						cells: a
					}, {
						kind: "complete",
						by: n,
						target: {
							kind: "quest",
							id: i
						}
					});
					break;
				}
			}
			break;
		}
	}
}
function ot(e, t, n) {
	let r = [...t, ...t.length === 1 ? [Pe] : []], i = {
		config: Se.parse(e),
		seed: n,
		cursor: 0,
		players: r.map((e, t) => ({
			rid: e,
			leader: t,
			position: e === "$falconer" ? 12 : -1,
			hand: [],
			clovers: e === "$falconer" ? 0 : 1,
			party: e === "$falconer" ? [] : [{
				id: 32,
				card: -1,
				item: null
			}],
			retired: [],
			completed: [],
			reserved: [],
			used: [],
			activated: [],
			journey: null,
			journeys: [],
			solo: e === Pe
		})),
		board: Array.from({ length: 25 }, () => null),
		market: [],
		quests: [],
		itemDeck: [],
		companionDeck: [],
		adventureDecks: [],
		journeyDeck: [],
		discard: [],
		soloDeck: [],
		soloUsed: [],
		first: 0,
		turn: 0,
		round: 1,
		turnInRound: 0,
		actor: "",
		phase: "resolve",
		tasks: [],
		choices: [],
		pending: null,
		effects: [],
		effectId: 0,
		payment: null,
		selectedTravel: -1,
		soloCard: null,
		falcon: t.length === 1 ? 12 : null,
		extraActivation: !1,
		log: [],
		serial: 0
	};
	i.itemDeck = Le(i, O.map((e, t) => t)), i.companionDeck = Le(i, D.map((e, t) => t)), i.adventureDecks = [Le(i, P.flatMap((e, t) => e.level === 1 ? [t] : [])), Le(i, P.flatMap((e, t) => e.level === 2 ? [t] : []))], i.board = i.board.map((e, t) => {
		let n = re.includes(t) ? "companion" : "item";
		return {
			kind: n,
			card: (n === "item" ? i.itemDeck : i.companionDeck).shift()
		};
	}), i.market = [...i.adventureDecks[0].splice(0, 3), ...i.adventureDecks[1].splice(0, 2)], i.quests = Le(i, [
		"A",
		"B",
		"C"
	].map((e) => {
		let t = le.flatMap((t, n) => t.group === e ? [n] : []);
		return {
			card: t[Ie(i, t.length)],
			signed: []
		};
	})), i.config.journeys && (i.journeyDeck = Le(i, F.map((e, t) => t)));
	for (let e of i.players.filter((e) => !e.solo)) ze(i, e.rid);
	return t.length === 1 && (ze(i, Pe, i.board[12].card), i.board[12] = null, ze(i, Pe), i.soloDeck = Le(i, de.flatMap((e, t) => i.config.soloDifficulty.includes(e.group) ? [t] : []))), i.first = t.length === 1 ? 0 : Ie(i, t.length), i.turn = i.first, i.tasks = [
		...t.map((e, n) => t[(i.first + t.length - 1 - n) % t.length]).map((e) => ({
			kind: "phase",
			by: e,
			phase: "corner"
		})),
		...i.config.journeys ? t.map((e) => ({
			kind: "journey",
			by: e
		})) : [],
		{
			kind: "startTurn",
			by: i.players[i.first].rid
		}
	], st(i), { state: i };
}
function st(e) {
	V(e, "corner", e.tasks.shift().by, x.filter((t) => !e.players.some((e) => e.position === t)).map((e) => ({
		id: `corner:${e}`,
		kind: "corner",
		cells: [e]
	})));
}
function ct(e, t, n) {
	let r = { code: "games.pilgrims.errAction" };
	if (t.type === "tick") {
		if (e.phase !== "resolve") return { state: e };
		let t = structuredClone(e);
		return t.tasks[0]?.kind === "phase" && t.tasks[0].phase === "corner" ? st(t) : at(t), { state: t };
	}
	if (e.phase === "done" || e.phase === "resolve" || e.actor !== n.by) return r;
	let i = structuredClone(e), a = R(i, n.by), o = n.by;
	if (t.type === "buyItem") return a.clovers < 2 || !i.itemDeck.length && !i.discard.length || i.phase === "corner" || i.phase === "journey" ? r : (a.clovers -= 2, ze(i, o), i.phase === "activate" && Ze(i, "activate", o, i.extraActivation), { state: i });
	if (t.type === "cancel" && i.phase === "pay") return i.payment = null, Ze(i, "adventure", o), { state: i };
	if (t.type === "pay" && i.phase === "pay" && i.payment) {
		let e = ve(Fe(a), a.hand, i.payment, t);
		return e === null || e > a.clovers ? r : (B(i, {
			kind: "spend",
			by: o,
			cost: e,
			cells: t.items
		}, ...t.retire.map((e) => ({
			kind: "retire",
			by: o,
			card: e
		})), {
			kind: "complete",
			by: o,
			target: i.payment
		}, {
			kind: "phase",
			by: o,
			phase: "effects"
		}, {
			kind: "replenish",
			by: o
		}, {
			kind: "endTurn",
			by: o
		}), { state: i });
	}
	if (t.type !== "choose") return r;
	let s = i.choices.find((e) => e.id === t.id);
	if (!s) return r;
	let c = i.pending;
	switch (i.choices = [], i.pending = null, i.phase = "resolve", s.kind) {
		case "corner": {
			let e = s.cells[0];
			B(i, {
				kind: "acquire",
				by: o,
				cell: e
			}, {
				kind: "position",
				by: o,
				cell: e
			});
			break;
		}
		case "journey":
			a.journey = {
				card: s.card,
				visited: []
			}, i.journeyDeck.push(...c.cells.filter((e) => e !== s.card));
			break;
		case "travel": {
			a.used.push(s.card), i.selectedTravel = s.card;
			let e = Ve(a).filter((e) => e.kind === "travel" && e.mode === s.card), t = {
				...se[s.card],
				passItem: e.some((e) => e.passItem)
			};
			for (let t of e) for (let e of t.effects) Ye(i, e);
			Ye(i, t, -2), B(i, {
				kind: "phase",
				by: o,
				phase: "effects"
			}, {
				kind: "phase",
				by: o,
				phase: "activate"
			});
			break;
		}
		case "activate": {
			let e = a.party.find((e) => e.id === s.character), t = s.item;
			e.item !== null && i.discard.push(e.item), a.hand = a.hand.filter((e) => e !== t), e.item = t, a.clovers -= s.cost, a.activated.push(e.id);
			for (let t of He(i, a, e.id).abilities) Ye(i, t, e.card);
			Xe(i, a, (e) => e.kind === "activateColor" && e.color === O[t].color || e.kind === "activateSymbol" && e.symbol === O[t].activate), z(i, o, "activate", { card: e.card }), B(i, {
				kind: "phase",
				by: o,
				phase: "effects"
			});
			break;
		}
		case "clover":
			Be(i, o), B(i, {
				kind: "phase",
				by: o,
				phase: "effects"
			});
			break;
		case "effect": {
			if (c?.ability?.kind === "paid") {
				if (!a.clovers) return r;
				a.clovers--, B(i, {
					kind: "ability",
					by: o,
					ability: c.ability.effect
				}, {
					kind: "phase",
					by: o,
					phase: "effects"
				});
				break;
			}
			let e = i.effects.findIndex((e) => e.id === s.effect);
			if (e < 0) return r;
			let t = i.effects.splice(e, 1)[0];
			B(i, {
				kind: "ability",
				by: o,
				ability: t.ability,
				source: t.source
			}, {
				kind: "phase",
				by: o,
				phase: "effects"
			});
			break;
		}
		case "move": {
			let e = s.cells, t = e.at(-1), n = c.ability, r = n.kind === "move" && n.passItem ? e.slice(0, -1).filter((e) => !re.includes(e)) : [];
			if (r.length) {
				V(i, "take", o, [...r.map((e) => ({
					id: `pass:${e}`,
					kind: "take",
					cells: [e]
				})), {
					id: "skip",
					kind: "skip"
				}], {
					...c,
					kind: "position",
					cell: t,
					cells: e
				});
				break;
			}
			B(i, {
				kind: "acquire",
				by: o,
				cell: t
			}, {
				kind: "position",
				by: o,
				cell: t,
				cells: e,
				ability: n
			});
			break;
		}
		case "take":
			if (c?.kind === "position") B(i, {
				kind: "acquire",
				by: o,
				cell: s.cells[0]
			}, {
				kind: "acquire",
				by: o,
				cell: c.cell
			}, c);
			else {
				let e = s.cells[0], t = i.board[e]?.card;
				t !== void 0 && (i.board[e] = null, ze(i, o, t));
			}
			break;
		case "swap": {
			let [e, t] = s.cells;
			[i.board[e], i.board[t]] = [i.board[t], i.board[e]], z(i, o, "swap");
			break;
		}
		case "reserve": {
			let e = s.card;
			e < 0 ? e = i.adventureDecks[-1 - e].shift() : i.market[i.market.indexOf(e)] = null, a.reserved.push(e), z(i, o, "reserve", { card: e });
			break;
		}
		case "returnReserve":
			a.reserved = a.reserved.filter((e) => e !== s.card), i.adventureDecks[P[s.card].level - 1].push(s.card), B(i, c);
			break;
		case "retire":
			Ke(i, a, s.character), B(i, {
				kind: "acquire",
				by: o,
				card: c.card
			});
			break;
		case "chooseItem":
		case "chooseCompanion":
			(s.kind === "chooseItem" ? i.itemDeck : i.companionDeck).push(...c.cells.filter((e) => e !== s.card)), s.kind === "chooseItem" ? ze(i, o, s.card) : qe(i, o, s.card);
			break;
		case "adventure":
		case "quest":
			i.payment = {
				kind: s.kind,
				id: s.card
			}, V(i, "pay", o, []);
			break;
		case "skip": e.phase === "adventure" ? B(i, {
			kind: "replenish",
			by: o
		}, {
			kind: "endTurn",
			by: o
		}) : c?.kind === "position" && B(i, {
			kind: "acquire",
			by: o,
			cell: c.cell
		}, c);
	}
	return { state: i };
}
function lt(e, t, n) {
	let r = [...e.party.filter((e) => e.card >= 0).map((e) => e.card), ...e.retired], i = t.flatMap((t, n) => {
		let i = t.signed.indexOf(e.rid);
		if (i < 0) return [];
		let a = le[t.card], o = a.kind === "type" ? r.filter((e) => D[e].types.some((e) => e === a.value)).length : a.kind === "activation" ? r.filter((e) => D[e].activate.some((e) => e === a.value)).length : e.completed.filter((e) => {
			let t = P[e];
			return a.kind === "clovers" ? t.clovers > 0 : a.kind === "level" ? t.level === 2 : a.kind === "travel" ? t.improvement?.kind === "travel" : t.improvement?.kind === "discount";
		}).length;
		return [{
			slot: n,
			count: o,
			points: [
				0,
				1,
				2,
				4,
				6
			][Math.min(o, 4)] + 2 - i
		}];
	}), a = e.completed.reduce((e, t) => e + P[t].points, 0), o = e.solo ? 0 : Math.floor(e.clovers / 3), s = i.reduce((e, t) => e + t.points, 0), c = e.solo ? n.journeys ? 5 : 0 : e.journeys.reduce((e, t) => e + F[t].points, 0) + (e.journey?.visited.length ?? 0), l = e.solo ? e.handCount : 0;
	return {
		adventures: a,
		clovers: o,
		quests: s,
		journeys: c,
		items: l,
		total: a + o + s + c + l,
		questDetails: i
	};
}
function ut(e, t) {
	let n = e.players.find((e) => e.rid === t), r = e.players.map(Fe), i = [
		"activate",
		"chooseItem",
		"chooseCompanion",
		"journey"
	].includes(e.phase);
	return {
		public: {
			config: e.config,
			players: r,
			phase: e.phase,
			actor: e.actor,
			turn: e.players[e.turn].rid,
			first: e.players[e.first].rid,
			round: e.round,
			turnInRound: e.turnInRound,
			board: e.board,
			market: e.market,
			quests: e.quests,
			deckCounts: {
				items: e.itemDeck.length,
				companions: e.companionDeck.length,
				adventure1: e.adventureDecks[0].length,
				adventure2: e.adventureDecks[1].length,
				journeys: e.journeyDeck.length
			},
			discard: e.discard,
			effects: e.effects.map((e) => ({
				id: e.id,
				source: e.source,
				kind: e.ability.kind,
				ability: e.ability,
				paid: e.ability.kind === "paid",
				..."color" in e.ability ? { color: e.ability.color } : {}
			})),
			choices: i ? [] : e.choices,
			payment: e.payment,
			falcon: e.falcon,
			soloCard: e.soloCard,
			scores: Object.fromEntries(r.map((t) => [t.rid, lt(t, e.quests, e.config)])),
			pendingAbility: e.pending?.ability ?? null,
			extraActivation: e.extraActivation,
			log: e.log
		},
		private: {
			hand: n?.hand ?? [],
			choices: e.actor === t && i ? e.choices : []
		}
	};
}
function dt(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t) => [t.rid, lt(Fe(t), e.quests, e.config).total])), n = e.players.map((e) => e.rid).sort((n, r) => t[r] - t[n] || R(e, r).hand.length - R(e, n).hand.length), r = n[0];
	return {
		phase: e.phase,
		ranking: n,
		winner: n.filter((n) => t[n] === t[r] && R(e, n).hand.length === R(e, r).hand.length),
		scores: t
	};
}
var ft = {
	meta: xe,
	saveCompatibility: { version: "1" },
	schemas: {
		action: Ce,
		config: Se,
		publicView: Me,
		privateView: Ne
	},
	setup: ot,
	reduce: ct,
	viewFor: ut,
	status: dt,
	nextTickIn: (e) => e.phase === "resolve" ? 420 : null
};
//#endregion
//#region src/games/pilgrims/item-art.tsx
function pt({ art: e }) {
	switch (e) {
		case 0: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M39 70 31 89l6 3 9-20",
				fill: "#776e59"
			}),
			/* @__PURE__ */ m("path", {
				d: "m34 83 6 3m-8 1 6 3m-1-10 6 3m-4-7 5 3",
				fill: "none",
				stroke: "#c1c8b5"
			}),
			/* @__PURE__ */ m("path", {
				d: "M31 89q-8-2-8 3 0 5 8 5 7-1 7-5Z",
				fill: "#bdc7bd"
			}),
			/* @__PURE__ */ m("path", {
				d: "m44 68 7 4q17-29 24-51L82 4 68 15q-15 23-24 53Z",
				fill: "#d7ded5"
			}),
			/* @__PURE__ */ m("path", {
				d: "M48 68q14-30 30-58L69 29 56 58Z",
				fill: "#9caeab",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M47 65 73 17m-22 40 6 2m-9 3 6 2m-1-12 6 2m-2-7 5 2",
				fill: "none",
				stroke: "#f9f4d9"
			}),
			/* @__PURE__ */ m("path", {
				d: "M33 61q0 8 19 12l11 1q7-1 4-5-3-3-5 1-17-1-24-10-2-4-5-2Z",
				fill: "#aab7ae"
			}),
			/* @__PURE__ */ m("path", {
				d: "M35 61q10 10 28 10m-36 22 7 0",
				fill: "none"
			})
		] });
		case 1: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M20 38 25 78q26 17 55-1l3-39",
				fill: "#776a52"
			}),
			/* @__PURE__ */ m("path", {
				d: "M24 45q6 8 51 5l-1 23q-30 13-48-2Z",
				fill: "#9c9278",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M24 53q18 6 54-1m-53 7q21 7 52-1m-51 7q26 5 50-2",
				fill: "none",
				stroke: "#494a3d"
			}),
			/* @__PURE__ */ m("path", {
				d: "M21 68q25 14 59-2l0 10q-28 17-56 2Z",
				fill: "#b56b54"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "51",
				cy: "37",
				rx: "32",
				ry: "12",
				fill: "#b37056"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "51",
				cy: "36",
				rx: "28",
				ry: "9",
				fill: "#e3dfc9"
			}),
			/* @__PURE__ */ m("path", {
				d: "M28 35q-5 9 22 9 20 0 24-6m-41-6 8-3m21 0 9 3m-28 8 15 0",
				fill: "none",
				stroke: "#89928b"
			}),
			[
				24,
				39,
				59,
				77
			].map((e, t) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("path", {
				d: `M${e} ${39 + t % 2 * 6} ${e + 4} ${76 + t % 2 * 4} ${e + 18} ${42 - t % 2 * 5}`,
				fill: "none",
				stroke: "#dfc78d",
				strokeWidth: "1.6"
			}), /* @__PURE__ */ m("path", {
				d: `m${e + 3} ${73 + t % 2 * 4} 2 7 4-1-1-7`,
				fill: "#d5bc83"
			})] }, e)),
			/* @__PURE__ */ m("path", {
				d: "m35 30 24-24q4-2 5 1L40 34M58 34 86 11q4-1 4 2L63 38",
				fill: "#cfb878"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "38",
				cy: "34",
				rx: "5",
				ry: "4",
				fill: "#ccb67a"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "60",
				cy: "37",
				rx: "5",
				ry: "3",
				fill: "#ccb67a"
			}),
			/* @__PURE__ */ m("path", {
				d: "m62 9-23 23m49-19-26 22m-34 45q22 9 46-1",
				fill: "none",
				stroke: "#f0e2bb"
			})
		] });
		case 2: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M30 94q2-20 6-35l8-19q10-15 8-20-1-7-13-9L32 7l1-5q23 3 28 17 6 12-9 27L44 65q-5 18-7 30Z",
				fill: "#b5a171"
			}),
			/* @__PURE__ */ m("path", {
				d: "M34 91q3-28 11-42 16-19 11-28-3-10-19-15",
				fill: "none",
				stroke: "#e8d3a0"
			}),
			/* @__PURE__ */ m("path", {
				d: "M39 61q-3 4 1 9l-5-1m11-26 5-2 1 5-8 5M35 78l5-2m11-48-8-4 2-4 7 5m-4 7-7-4-2-5M31 91l6-1",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M48 31q-12 7-9 11 8 2 11-6M43 63q7-8 8-3-2 7-9 8",
				fill: "#83a071"
			})
		] });
		case 3: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M43 57q11-25 23-45l4-7-7 2q-15 20-26 48Z",
				fill: "#94825b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M40 54q2-17-8-19L26 33q12 2 15 16M43 52q0-24 9-29",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M35 56q-8 7-10 17-5 12-17 16l8-1-4 5 11-2-4 5 12-4-2 6 9-6 0 6 7-8 0 4q8-17 0-35Z",
				fill: "#cdbc89"
			}),
			/* @__PURE__ */ m("path", {
				d: "M36 60q-5 20-19 29m23-27q-1 22-17 31m20-29q1 16-8 30m6-29q-6 16-16 23m14-25q-6 12-13 16m17-16q8 20 0 30m-6-28q-4 10-9 13",
				fill: "none",
				stroke: "#766849"
			}),
			/* @__PURE__ */ m("path", {
				d: "M35 52q5 3 11 2l0 4q-6 4-12-1Z",
				fill: "#d8c598"
			}),
			/* @__PURE__ */ m("path", {
				d: "m35 55 9 1m-11 2 10 2m-10 0 10 2m17-43 4-6",
				fill: "none"
			})
		] });
		case 4: return /* @__PURE__ */ h("g", {
			transform: "rotate(17 53 52)",
			children: [
				/* @__PURE__ */ m("path", {
					d: "M46 16h12v25q11 5 11 17v34q-12 9-31 0V57q0-11 10-16V16Z",
					fill: "#d5e0d9"
				}),
				/* @__PURE__ */ m("path", {
					d: "M42 64q13 4 24-1v26q-10 8-24 0Z",
					fill: "#c6a56a"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "54",
					cy: "64",
					rx: "12",
					ry: "3",
					fill: "#e1c58d"
				}),
				/* @__PURE__ */ m("path", {
					d: "M41 58q-1-9 10-13V22m-9 57v10m22-33 0 30m-20 5q9 5 19 0",
					fill: "none",
					stroke: "#f8f3dd"
				}),
				/* @__PURE__ */ m("path", {
					d: "m40 70 23 0-1 11-22 0Z",
					fill: "#f4ecd3"
				}),
				/* @__PURE__ */ m("path", {
					d: "M46 16q-3-4-1-8l15 0q1 4-1 8Z",
					fill: "#c8d5ce"
				}),
				/* @__PURE__ */ m("path", {
					d: "M47 9 46 2q6-3 14 0l-2 7Z",
					fill: "#b59869"
				}),
				/* @__PURE__ */ m("path", {
					d: "m50 3 0 3m5-3 0 2m-12 52q6 3 12 1m-9 27 2 0m10 0 1 0",
					fill: "none"
				})
			]
		});
		case 5: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "m16 27 15-5 42 0 16 8-4 53-16 8-40-1-11-8Z",
				fill: "#a77e4e"
			}),
			/* @__PURE__ */ m("path", {
				d: "M31 22q17-9 42 0l-4 63q-20-3-38 0Z",
				fill: "#c6b786"
			}),
			[
				0,
				1,
				2,
				3,
				4,
				5,
				6,
				7
			].map((e) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("path", {
				d: `M${32 + e * 5} ${22 - e % 2 * 2} ${29 + e * 5} 85l3 3 4-65`,
				fill: e % 2 ? "#d9cea3" : "#776f56"
			}), /* @__PURE__ */ m("path", {
				d: `M${32 + e * 5} 26 ${30 + e * 5} 80`,
				stroke: "#eee3bc",
				fill: "none",
				strokeWidth: ".65"
			})] }, e)),
			/* @__PURE__ */ m("path", {
				d: "M16 27 28 29 28 86 18 82Z",
				fill: "#e0ddc5"
			}),
			Array.from({ length: 11 }, (e, t) => /* @__PURE__ */ m("path", {
				d: `M17 ${32 + t * 4.4}h10m-10 0 0 3`,
				fill: "none"
			}, t)),
			Array.from({ length: 7 }, (e, t) => /* @__PURE__ */ m("path", {
				d: `m17 ${34 + t * 7}h7v2h-7Z`,
				fill: "#44483c",
				stroke: "none"
			}, t)),
			/* @__PURE__ */ m("path", {
				d: "M73 24 89 30 83 82 69 91l1-8 4-3Z",
				fill: "#9d7149"
			}),
			/* @__PURE__ */ m("path", {
				d: "M77 39 86 34 81 75 73 82Z",
				fill: "#575342"
			}),
			Array.from({ length: 5 }, (e, t) => /* @__PURE__ */ h("g", {
				fill: "#e3dec1",
				children: [/* @__PURE__ */ m("ellipse", {
					cx: 79 - t * .65,
					cy: 43 + t * 7,
					rx: "1.6",
					ry: "2"
				}), /* @__PURE__ */ m("ellipse", {
					cx: 83 - t * .65,
					cy: 40 + t * 7,
					rx: "1.2",
					ry: "1.8"
				})]
			}, t)),
			/* @__PURE__ */ m("path", {
				d: "m30 26-2 52m47-49 8 3m-10 48 7-4m-54 7 0-7M30 33q22-5 42-1",
				fill: "none"
			})
		] });
		case 6: return /* @__PURE__ */ h("g", {
			transform: "rotate(-22 52 56)",
			children: [
				/* @__PURE__ */ m("path", {
					d: "M13 57q4-13 26-13l30 1q18 5 22 13 8 10-9 19-27 14-61-2-15-6-8-18Z",
					fill: "#af8251"
				}),
				/* @__PURE__ */ m("path", {
					d: "M19 61q30 15 64-1m-65 5q29 14 62 1m-57 5q24 11 52 0",
					fill: "none",
					stroke: "#795e41"
				}),
				/* @__PURE__ */ m("path", {
					d: "M30 56q0-17 3-23 6-10 22-8 16 0 19 11l-1 22q-18 12-43-2Z",
					fill: "#b99761"
				}),
				/* @__PURE__ */ m("path", {
					d: "M33 35q18 7 39 0l-1 16q-19 10-39-1Z",
					fill: "#a07b4e",
					stroke: "none"
				}),
				/* @__PURE__ */ m("path", {
					d: "M31 49q21 11 42 0l0 7q-21 12-43-1Z",
					fill: "#677778"
				}),
				/* @__PURE__ */ m("path", {
					d: "M39 51h9v7h-9Z",
					fill: "#d6be7f"
				}),
				/* @__PURE__ */ m("path", {
					d: "M36 32q17 6 30-1m-27 8 6-5m-1 7 8-6m-1 8 7-8m-25 8 0 4M23 57l4-3m48-3 2-10",
					fill: "none"
				}),
				/* @__PURE__ */ m("path", {
					d: "M21 57q-7 7 4 13m12-41q11-7 22-2m21 29q0 9-12 13",
					fill: "none",
					stroke: "#e0c795"
				})
			]
		});
		case 7: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M40 94q-7-23 9-44 8-14 10-23",
				fill: "none",
				stroke: "#667f55",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ m("path", {
				d: "M44 76q-10-14-21-13l4 5-6 2 8 6 11 1M47 67q18-16 29-9l-8 2 5 4-12 4-13 5",
				fill: "#a8b982"
			}),
			/* @__PURE__ */ m("path", {
				d: "M53 37q-26-1-25-12 3-10 18 0-8-24 3-26 11 0 10 23 8-24 20-17 9 9-13 23 25-7 28 3 0 11-26 10 22 10 14 20-10 9-22-16 6 26-6 28-14-1-5-28-17 22-25 14-9-11 20-20Z",
				fill: "#eeecd6"
			}),
			/* @__PURE__ */ m("path", {
				d: "m33 26 16 7M48 7l7 22m23-18L62 31m24 3-20 2M76 56 62 42M55 63l1-20M30 53l19-14",
				fill: "none",
				stroke: "#a4ab91"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "57",
				cy: "36",
				rx: "9",
				ry: "8",
				fill: "#c6b16e"
			}),
			Array.from({ length: 13 }, (e, t) => /* @__PURE__ */ m("ellipse", {
				cx: 57 + Math.cos(t * 2.4) * Math.sqrt(t) * 2,
				cy: 36 + Math.sin(t * 2.4) * Math.sqrt(t) * 1.6,
				rx: "1.4",
				ry: "2",
				fill: "#b59956",
				transform: `rotate(${t * 47} ${57 + Math.cos(t * 2.4) * Math.sqrt(t) * 2} ${36 + Math.sin(t * 2.4) * Math.sqrt(t) * 1.6})`
			}, t)),
			/* @__PURE__ */ m("path", {
				d: "m28 68 10 7m25-12-12 6m-13 18 2-8",
				fill: "none"
			})
		] });
		case 8: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M52 17C22 13 12 33 21 34c9 0 27-18 39-17 29 3 29 31 7 47-20 15-43 12-44-8-1-15 17-25 30-23 17 2 8 24-4 28-10 4-12-5-7-12 4-6 11-7 17-6M49 64q-3 15-12 21l-11 10",
				fill: "none",
				stroke: "#484735",
				strokeWidth: "4.8"
			}),
			/* @__PURE__ */ m("path", {
				d: "M52 17C22 13 12 33 21 34c9 0 27-18 39-17 29 3 29 31 7 47-20 15-43 12-44-8-1-15 17-25 30-23 17 2 8 24-4 28-10 4-12-5-7-12 4-6 11-7 17-6M49 64q-3 15-12 21l-11 10",
				fill: "none",
				stroke: "#c2a871",
				strokeWidth: "2.8"
			}),
			/* @__PURE__ */ m("path", {
				d: "m25 21 2 3m6-6 2 3m7-5 1 3m9-4 0 3m8-2-1 3m8 0-2 3m7 2-3 2m6 4-3 1m4 6-3 0m2 7-3-1m-1 7-3-2m-1 7-2-2m-4 7-2-3m-5 7-2-3m-6 6-1-3m-7 4 0-3m-8 2 1-3m-8 0 2-3m-7-1 3-2m-5-4 3-1m-2-7 3 1m0-8 3 2m2-7 2 3m4-6 1 3m6-4 0 3m7 0-2 3m4 4-3 0m0 7-3-1M44 47l2 2m5-5 1 3m6-5 0 3m-12 27 3 2m-7 4 3 2m-8 4 3 2m-9 4 3 2m-9 3 3 2",
				fill: "none",
				strokeWidth: ".7"
			}),
			/* @__PURE__ */ m("path", {
				d: "m27 93-4 1 1 4m2-3-1 4",
				fill: "none"
			})
		] });
		case 9: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M67 17Q30 9 17 36q-13 20 3 43l8 6",
				fill: "none",
				stroke: "#78533b",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ m("path", {
				d: "M51 44q-17-6-20 8-1 5-7 9-12 9-7 23 9 14 31 8 19-5 15-19-1-8-7-11l19-36-7-4Z",
				fill: "#92714a"
			}),
			/* @__PURE__ */ m("path", {
				d: "M49 41q-18-6-20 8-1 8-8 11-13 8-7 22 11 16 32 6 15-7 11-18-2-5-7-8l21-36-7-4Z",
				fill: "#d6ba75"
			}),
			/* @__PURE__ */ m("path", {
				d: "M17 71q-5 17 14 18 15-1 20-9M38 47q-9-1-9 11m26 8q-3-2-5-2",
				fill: "none",
				stroke: "#f0dfaa"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "40",
				cy: "66",
				r: "8",
				fill: "#5d5840"
			}),
			/* @__PURE__ */ m("path", {
				d: "m36 58 29-40 5 3-25 41m-19 17 14-15",
				fill: "#756044"
			}),
			/* @__PURE__ */ m("path", {
				d: "m65 13 12 4-6 14-12-4Z",
				fill: "#c7a767"
			}),
			[
				0,
				1,
				2
			].map((e) => /* @__PURE__ */ h("g", {
				fill: "#dddac3",
				children: [/* @__PURE__ */ m("ellipse", {
					cx: 64 - e * 2,
					cy: 17 + e * 4,
					rx: "2",
					ry: "1.6"
				}), /* @__PURE__ */ m("ellipse", {
					cx: 76 - e * 2,
					cy: 21 + e * 4,
					rx: "2",
					ry: "1.6"
				})]
			}, e)),
			/* @__PURE__ */ m("path", {
				d: "m69 18-32 50-11 13m44-61-31 49-10 13m43-60L40 72 31 83",
				fill: "none",
				stroke: "#e8dfba",
				strokeWidth: ".6"
			}),
			/* @__PURE__ */ m("path", {
				d: "m24 78 13 8 2-3-13-8Z",
				fill: "#d9d5b2"
			}),
			/* @__PURE__ */ m("path", {
				d: "M29 88q-14 1-13-12m35 8-6 3M26 39l2-2m-8 8 1 2m-5 7 1 2m-3 7 1 2m1 7 2 2m5 7 2 1m5 0 1 2m3-33 0-2m10-1 1 3",
				fill: "none"
			})
		] });
		case 10: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "m13 31 25-13 23 9 25-11q11 20 7 44L84 87 61 79 34 93 9 83q7-20 4-52Z",
				fill: "#c5aa71"
			}),
			/* @__PURE__ */ m("path", {
				d: "M38 18q7 24-4 75l27-14q10-22 0-52Z",
				fill: "#ded0a2",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M16 32q23-7 23-12m1 5q6 26-3 62m26-56q8 22-1 44m23-55q8 20 4 40l-7 22",
				fill: "none",
				stroke: "#f0e1b9"
			}),
			/* @__PURE__ */ m("path", {
				d: "M15 68q12-5 29-2 14-1 23-12l20-4",
				fill: "none",
				stroke: "#d8e0ce",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ m("path", {
				d: "m13 69 31-1q14-1 23-12l21-4M16 75l6-8m12-2-1 5m19-7 2 5m14-18-1 5",
				fill: "none"
			}),
			[
				[23, 36],
				[31, 29],
				[48, 41],
				[76, 32],
				[81, 61],
				[70, 68],
				[50, 72]
			].map(([e, t], n) => /* @__PURE__ */ m("g", { children: /* @__PURE__ */ m("path", {
				d: `m${e - 3} ${t + 4} 3-7 4 6m-4-1v6m-3-2 3-3 4 2`,
				fill: "none",
				stroke: "#5b704c"
			}) }, n)),
			/* @__PURE__ */ m("path", {
				d: "m16 56 7-10 5 8m34-18 5-9 6 8m-54 46 7-8 5 6M42 48l4-5 5 4v8h-9Zm4-5v-5m29 8 4-5 4 5-3 3-4-1ZM43 80l6-5 5 4v7h-9Zm-19-35 0-5m29 21 1-1m4-4 1-1m-22-3 2 0m-8 8 1 0",
				fill: "none"
			})
		] });
		case 11: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M20 41q5 17 1 29-2 16 14 19 27 8 46-2 8-5 3-20l-5-23Z",
				fill: "#a78450"
			}),
			/* @__PURE__ */ m("path", {
				d: "M26 51q17 8 50 0l4 22q-17 15-55 3Z",
				fill: "#bd9a5f",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M24 68q28 13 56 0m-55 8q25 12 55-1m-52 8 15 3m24-3 12-5m-55-17 12 4m-10-9 10 4m28 4 13-4",
				fill: "none",
				stroke: "#735c3e"
			}),
			/* @__PURE__ */ m("path", {
				d: "M78 37q11-2 11 9-1 18-30 20-21 0-33-14",
				fill: "none",
				stroke: "#554e3a",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "51",
				cy: "40",
				rx: "33",
				ry: "12",
				fill: "#d5b77c"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "51",
				cy: "39",
				rx: "28",
				ry: "9",
				fill: "#514b38"
			}),
			/* @__PURE__ */ m("path", {
				d: "M26 38q20-8 48 0M28 43q20-7 43-2m-37 5 22-3m-19-11 18-1",
				fill: "none",
				stroke: "#88734b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M34 42Q38 58 60 61q20 0 24-15",
				fill: "none",
				stroke: "#d4b779",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ m("path", {
				d: "M31 40q-2-9-6-6-4 4 2 11m44-17-2-6 6-1 4 8",
				fill: "#bb995e"
			}),
			/* @__PURE__ */ m("path", {
				d: "m29 54 1 8m44-5 2 7m-20 20 16-2m-44-2 9 3",
				fill: "none",
				stroke: "#e5c88d"
			})
		] });
		default: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "m54 8 23 28 10 19-32 42-25-30-8-26Z",
				fill: "#adbd86"
			}),
			/* @__PURE__ */ m("path", {
				d: "m54 8-15 58-17-25Z",
				fill: "#b5d4cf"
			}),
			/* @__PURE__ */ m("path", {
				d: "m54 8 11 58 22-11-10-19Z",
				fill: "#b98e79"
			}),
			/* @__PURE__ */ m("path", {
				d: "m39 66 26 0-10 31Z",
				fill: "#bd9379"
			}),
			/* @__PURE__ */ m("path", {
				d: "m22 41 17 25 16 31-25-30Z",
				fill: "#83a883"
			}),
			/* @__PURE__ */ m("path", {
				d: "m65 66 22-11-32 42Z",
				fill: "#9fbcc0"
			}),
			/* @__PURE__ */ m("path", {
				d: "m54 8-15 58 26 0L54 8m-15 58 16 31 10-31 22-11M22 41l17 25",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "m51 13-24 28 11 20m19-45 23 39-14 8m-24 7 11 21m29-29L60 91m-35-45 6 19",
				fill: "none",
				stroke: "#f1eee0",
				strokeWidth: "1.7"
			}),
			/* @__PURE__ */ m("path", {
				d: "m45 34-7 20m10-28-6 19m17-8 3 11m9-8 9 11m-33 23 5 11m14-13-7 12",
				fill: "none",
				strokeWidth: ".7"
			})
		] });
	}
}
//#endregion
//#region src/games/pilgrims/landscape.tsx
function mt({ x: e, y: t, s: n = 1, peak: r = !1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-32 15q8-15 16-34Q-5-48 5-40q10 7 19 31l17 27q-19-5-34 0-19 6-39-3Z",
				fill: r ? "#b9a179" : "#c2aa7e"
			}),
			/* @__PURE__ */ m("path", {
				d: "M5-40Q0-8-9 11l17 7 16-3Q12 0 5-40Z",
				fill: "#a38c6a",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-21-9 13 6 4-13m-8 21 6-2m16-18 3 8m-1 2 6 5m-25-30 6-9m-6 19 3-6",
				fill: "none",
				stroke: "#8a795b",
				strokeWidth: ".65"
			})
		]
	});
}
function ht({ x: e, y: t, s: n = 1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-1 0 0-24l2 0 1 24",
				fill: "#8a7757"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-17-5q8-6 9-13l-5 2q8-9 9-16l-4 2L1-48q2 10 9 18l-4-2q1 7 11 17l-6-2q4 7 12 11l-9 0 1 4-13-3-6 4-1-4-12 4Z",
				fill: "#9da07b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M1-40V-7m-1-19-5 7m7-3 5 7m-8-1-7 7m10-5 7 7M-5-8l-2 2",
				fill: "none",
				stroke: "#737659",
				strokeWidth: ".7"
			})
		]
	});
}
function gt({ x: e, y: t, s: n = 1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "m-3 2 2-24 6-1-1 25m-3-11-9-10m10 3 10-11",
				fill: "#a18b60"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-15-15q-12 0-12-10-7-9 3-15-3-9 9-12 4-12 15-7 9-10 17 0 11-3 14 9 12 2 6 13 9 11-3 17-6 10-17 2-13 9-20 3Z",
				fill: "#b0b08a"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-21-31q4-6 9-2m-4-12q6-4 10 1m5-12q7 1 8 7m10 6q8 0 8 7m-12 10q5-8 10-3m-27 8q6-4 10 0m-13-16q5-4 8 1",
				fill: "none",
				stroke: "#85896a",
				strokeWidth: ".7"
			})
		]
	});
}
function H({ x: e, y: t, s: n = 1, roof: r = "#aa875d" }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-16-4 10-6l13 5-1 19-38-1Z",
				fill: "#d5c49a"
			}),
			/* @__PURE__ */ m("path", {
				d: "m10-6 13 5-1 19-12-3Z",
				fill: "#b5a37d"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-20-5-9-23 15-21 28-2 8 1-6-15-16-1Z",
				fill: r
			}),
			/* @__PURE__ */ m("path", {
				d: "m-6-15 14 16 20-3-13-19Z",
				fill: "#a58860"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-9-23 3 8m-9 7 6-12m7 4 20 1m-17 4 21 1m-17 3 21 1m-17 3 21 1M13-20v-9l5 1v14",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-10 17V7q3-5 7 0v10m3-22 6-1v7l-6 1m15-5 5 2v6l-5-1",
				fill: "#776e52"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-14 10 2 0m19 0 0 5m7-2 2 0",
				fill: "none"
			})
		]
	});
}
function _t({ x: e, y: t, s: n = 1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-12 20V-5L0-18 19-9v29Z",
				fill: "#d7c79e"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-17-4 0-23 24-9 19-5 0-17-10 2Z",
				fill: "#a29a73"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-8 18V-28l10-4 8 5v47m-20-47 13-22 10 22Z",
				fill: "#d0c198"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-10-27 13-22 10 22-12-4Z",
				fill: "#8b9d8c"
			}),
			/* @__PURE__ */ m("path", {
				d: "M2-50v-9m-3 3h6M-3 19V8q5-10 8 0v11M0-22v6m3-6v6m13 11v7",
				fill: "none",
				stroke: "#72684f"
			})
		]
	});
}
function vt({ x: e, y: t, s: n = 1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-9 17-6-28H7l6 46Z",
				fill: "#c4b88e"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-9-28 0-43 10-28Zm-3 0v8h25v-8Z",
				fill: "#a79870"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-2-43v-8l13 3-13 3m-3 24 10-1m-11 8 14-1M0-10v6m1 12v8m-8-14 4 1m8-13 3 1",
				fill: "none"
			})
		]
	});
}
function yt({ x: e, y: t, angle: n = 0 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) rotate(${n})`,
		children: [/* @__PURE__ */ m("path", {
			d: "M-15-5q15-5 30 0v11q-15-5-30 0Z",
			fill: "#b69c70"
		}), /* @__PURE__ */ m("path", {
			d: "M-15-5q15-5 30 0m-30 10q15-5 30 0m-28-15v12m26-12v12M-10-7v10m5-11V2m5-11V2m5-10V2m5-9V3",
			fill: "none"
		})]
	});
}
function bt({ x: e, y: t, rx: n, ry: r }) {
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("path", {
		d: `M${e - n} ${t}q${-n * .1} ${-r} ${n * .8} ${-r}t${n * 1.2} ${r}q${-n * .1} ${r} ${-n} ${r}t${-n} ${-r}Z`,
		fill: "#b1c6ad"
	}), /* @__PURE__ */ m("path", {
		d: `M${e - n * .6} ${t + r * .2}q${n * .6} ${r * .7} ${n * 1.2} 0m${-n * .8} ${-r * .7} ${n * .6} 0`,
		fill: "none",
		stroke: "#e1dcc0"
	})] });
}
function xt({ x: e, y: t, s: n = 1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "m-5 3 0 4m8-4 1 4",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-7 2q-4-4 0-6-1-4 4-3 3-3 6 0 5-1 6 4l-3 6Z",
				fill: "#d9d1ad"
			}),
			/* @__PURE__ */ m("path", {
				d: "m5-3 5 1 0 4-5 0",
				fill: "#938e6b"
			})
		]
	});
}
var St = [
	[
		343,
		28,
		.9
	],
	[
		377,
		36,
		.8
	],
	[
		409,
		26,
		.9
	],
	[
		448,
		22,
		.85
	],
	[
		481,
		42,
		.95
	],
	[
		325,
		69,
		.76
	],
	[
		361,
		84,
		.82
	],
	[
		397,
		84,
		.74
	],
	[
		453,
		80,
		.82
	],
	[
		489,
		102,
		.85
	],
	[
		338,
		119,
		.8
	],
	[
		378,
		133,
		.7
	],
	[
		414,
		139,
		.8
	],
	[
		463,
		150,
		.8
	],
	[
		491,
		166,
		.7
	],
	[
		328,
		174,
		.72
	],
	[
		358,
		192,
		.64
	],
	[
		397,
		193,
		.65
	],
	[
		450,
		206,
		.7
	],
	[
		481,
		228,
		.65
	]
], Ct = [
	[
		346,
		257,
		.55
	],
	[
		363,
		265,
		.75
	],
	[
		384,
		259,
		.5
	],
	[
		407,
		260,
		.62
	],
	[
		437,
		268,
		.55
	],
	[
		470,
		272,
		.65
	],
	[
		491,
		292,
		.65
	],
	[
		344,
		286,
		.65
	],
	[
		366,
		293,
		.6
	],
	[
		390,
		292,
		.7
	],
	[
		415,
		299,
		.6
	],
	[
		451,
		305,
		.7
	],
	[
		480,
		317,
		.6
	],
	[
		332,
		315,
		.6
	],
	[
		350,
		330,
		.75
	],
	[
		378,
		330,
		.7
	],
	[
		399,
		341,
		.65
	],
	[
		426,
		346,
		.7
	],
	[
		464,
		347,
		.65
	],
	[
		488,
		368,
		.6
	],
	[
		345,
		366,
		.65
	],
	[
		366,
		385,
		.7
	],
	[
		405,
		379,
		.6
	],
	[
		437,
		387,
		.7
	],
	[
		469,
		400,
		.65
	],
	[
		492,
		421,
		.6
	],
	[
		339,
		408,
		.65
	],
	[
		355,
		432,
		.65
	],
	[
		389,
		423,
		.7
	],
	[
		416,
		448,
		.7
	],
	[
		450,
		446,
		.7
	],
	[
		479,
		459,
		.65
	],
	[
		349,
		468,
		.7
	],
	[
		381,
		488,
		.7
	],
	[
		420,
		493,
		.7
	],
	[
		470,
		494,
		.65
	]
], wt = [
	[
		20,
		216,
		.7
	],
	[
		47,
		215,
		.65
	],
	[
		78,
		218,
		.6
	],
	[
		6,
		242,
		.6
	],
	[
		27,
		244,
		.7
	],
	[
		60,
		247,
		.7
	],
	[
		81,
		260,
		.65
	],
	[
		14,
		275,
		.65
	],
	[
		40,
		280,
		.65
	],
	[
		68,
		283,
		.6
	],
	[
		4,
		303,
		.6
	],
	[
		30,
		311,
		.75
	],
	[
		58,
		316,
		.65
	],
	[
		19,
		351,
		.65
	],
	[
		49,
		363,
		.7
	],
	[
		78,
		377,
		.65
	],
	[
		8,
		388,
		.6
	],
	[
		30,
		400,
		.7
	],
	[
		63,
		412,
		.65
	],
	[
		87,
		431,
		.7
	],
	[
		14,
		439,
		.7
	],
	[
		41,
		456,
		.65
	],
	[
		68,
		472,
		.75
	],
	[
		10,
		482,
		.65
	],
	[
		42,
		498,
		.7
	],
	[
		96,
		497,
		.65
	]
];
function Tt() {
	return /* @__PURE__ */ h("g", {
		stroke: "#8d7b59",
		strokeWidth: ".8",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ m("rect", {
				width: "500",
				height: "500",
				rx: "9",
				fill: "#cbb58a",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M0 1H500v96q-57-7-91 18-57 21-105-6-67-31-133 12T0 100Z",
				fill: "#c8b38c",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M3 203q48-21 99 5 42-20 102-5 72-31 117 20l6 167q-69-30-132 10-59 22-92-5-66 11-103-12Z",
				fill: "#bfc29a",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M321 1h179v499H304q20-67 30-115-9-49-13-82-14-46-12-82-5-45 8-100Z",
				fill: "#b9ae88",
				stroke: "none"
			}),
			/* @__PURE__ */ m("g", {
				fill: "none",
				stroke: "#b19b74",
				strokeWidth: "1.1",
				children: /* @__PURE__ */ m("path", { d: "M2 29q24-34 49 1 17-40 44-11 20-21 40 2 35-30 58 1 30-33 62 2 25-22 47 5M0 52q31-23 57 1 27-26 55-6 29-27 55-1 25-23 55-5 31-25 76 4M6 86q39-12 67-1m48-11q40-25 69 1m20-5q48-16 80 5M28 125q32-19 58-2m83-16q26-16 55-4m-122 83q47-17 86 0m12-35q36-25 65-10M82 245q26-18 48-4m87-23q41-23 85 2m-25 40q20-15 40 0m-196 34q47-21 82-4M112 389q41-17 76 0m46 42q38-10 69 0" })
			}),
			/* @__PURE__ */ m("g", { children: St.map(([e, t, n], r) => /* @__PURE__ */ m(mt, {
				x: e,
				y: t,
				s: n,
				peak: r % 3 == 0
			}, r)) }),
			/* @__PURE__ */ m("path", {
				d: "M412-6q-11 19-8 43 1 23-22 37-20 14-11 39 7 18-5 32-15 18-13 39 4 22-13 44-19 21-53 30-22 11-52 9-35-2-64-11-29-11-48-16-32-8-57 0Q28 252-5 243v18q34 10 63-1 29-10 59-1l57 18q30 11 64 10 36 0 56-12 42-11 61-37 18-27 13-48-3-18 11-35 19-22 11-46-8-17 5-30 26-17 21-42-4-21 9-43Z",
				fill: "#b2c8b0",
				stroke: "#879c83"
			}),
			/* @__PURE__ */ m("path", {
				d: "M418-5q-12 23-9 43t-23 41q-16 12-8 34 4 20-10 37-13 19-8 38t-20 46q-16 19-48 30-23 13-53 11-34-2-64-12l-55-17q-30-11-58-1Q29 255-2 251",
				fill: "none",
				stroke: "#e0ddbf",
				strokeWidth: "2.6"
			}),
			/* @__PURE__ */ m("g", {
				fill: "none",
				stroke: "#d2d9b8",
				children: /* @__PURE__ */ m("path", { d: "M382 109l2 9m-22 48-4 9m-5 45-7 10m-30 26-13 6m-21 8-12 3m-29 6-16-1m-25-3-12-4m-19-5-13-4m-35-13-12-2M42 254l-15 1" })
			}),
			/* @__PURE__ */ m(bt, {
				x: 58,
				y: 37,
				rx: 22,
				ry: 6
			}),
			/* @__PURE__ */ m(bt, {
				x: 37,
				y: 61,
				rx: 18,
				ry: 5
			}),
			/* @__PURE__ */ m(bt, {
				x: 73,
				y: 77,
				rx: 20,
				ry: 7
			}),
			/* @__PURE__ */ m(bt, {
				x: 40,
				y: 98,
				rx: 22,
				ry: 6
			}),
			/* @__PURE__ */ m(bt, {
				x: 98,
				y: 50,
				rx: 9,
				ry: 5
			}),
			/* @__PURE__ */ m(bt, {
				x: 171,
				y: 129,
				rx: 27,
				ry: 11
			}),
			/* @__PURE__ */ m(bt, {
				x: 127,
				y: 185,
				rx: 22,
				ry: 8
			}),
			/* @__PURE__ */ m(bt, {
				x: 181,
				y: 61,
				rx: 17,
				ry: 6
			}),
			/* @__PURE__ */ m("g", {
				fill: "none",
				stroke: "#ead7a8",
				strokeWidth: "3",
				children: /* @__PURE__ */ m("path", { d: "M96-4q14 29-2 62-15 19-7 38t23 42q-10 16-22 32-2 27 23 39l36 16q15 11 17 28 5 20 34 36 5 26 21 52 7 29 2 50-8 42 9 57M253-3q-2 31-22 41-12 18 4 37 20 25 5 47-21 25-2 47 24 24 13 51-9 27 8 47 10 30-5 49-20 32 0 59 18 20 8 43-9 25 0 42M109 136q37 5 65 0 30 0 65-14m-126 87q43 5 78-5t51 17m-88 59q-15 17-48 25m107 37q-48 21-87 22m130 53q-56-6-77 24M345 333q-17 17-51 21m97 109q-20-18-52-10" })
			}),
			/* @__PURE__ */ h("g", {
				strokeWidth: ".6",
				children: [
					/* @__PURE__ */ m(yt, {
						x: 162,
						y: 261,
						angle: -20
					}),
					/* @__PURE__ */ m(yt, {
						x: 347,
						y: 221,
						angle: 35
					}),
					/* @__PURE__ */ m(yt, {
						x: 390,
						y: 84,
						angle: 15
					})
				]
			}),
			/* @__PURE__ */ h("g", {
				strokeWidth: ".6",
				children: [
					/* @__PURE__ */ m(vt, {
						x: 24,
						y: 65,
						s: .52
					}),
					/* @__PURE__ */ m(H, {
						x: 145,
						y: 78,
						s: .35
					}),
					/* @__PURE__ */ m(_t, {
						x: 230,
						y: 76,
						s: .45
					}),
					/* @__PURE__ */ m(H, {
						x: 252,
						y: 35,
						s: .36
					}),
					/* @__PURE__ */ m(_t, {
						x: 281,
						y: 125,
						s: .4
					}),
					/* @__PURE__ */ m(vt, {
						x: 473,
						y: 133,
						s: .47
					}),
					/* @__PURE__ */ m(H, {
						x: 453,
						y: 56,
						s: .65
					}),
					/* @__PURE__ */ m(vt, {
						x: 429,
						y: 40,
						s: .6
					}),
					/* @__PURE__ */ m(H, {
						x: 74,
						y: 174,
						s: .6
					}),
					/* @__PURE__ */ m(H, {
						x: 28,
						y: 170,
						s: .37
					}),
					/* @__PURE__ */ m(H, {
						x: 147,
						y: 222,
						s: .65
					}),
					/* @__PURE__ */ m(H, {
						x: 196,
						y: 249,
						s: .4
					}),
					/* @__PURE__ */ m(_t, {
						x: 238,
						y: 235,
						s: .63
					}),
					/* @__PURE__ */ m(H, {
						x: 266,
						y: 264,
						s: .47
					}),
					/* @__PURE__ */ m(H, {
						x: 269,
						y: 217,
						s: .44
					}),
					/* @__PURE__ */ m(H, {
						x: 208,
						y: 202,
						s: .47
					}),
					/* @__PURE__ */ m(H, {
						x: 161,
						y: 303,
						s: .72
					}),
					/* @__PURE__ */ m(H, {
						x: 124,
						y: 284,
						s: .45
					}),
					/* @__PURE__ */ m(H, {
						x: 253,
						y: 306,
						s: .62
					}),
					/* @__PURE__ */ m(H, {
						x: 275,
						y: 283,
						s: .37
					}),
					/* @__PURE__ */ m(H, {
						x: 294,
						y: 372,
						s: .46
					}),
					/* @__PURE__ */ m(H, {
						x: 115,
						y: 406,
						s: .55
					}),
					/* @__PURE__ */ m(H, {
						x: 173,
						y: 416,
						s: .83
					}),
					/* @__PURE__ */ m(H, {
						x: 202,
						y: 454,
						s: .7
					}),
					/* @__PURE__ */ m(H, {
						x: 137,
						y: 473,
						s: .5
					}),
					/* @__PURE__ */ m(H, {
						x: 278,
						y: 420,
						s: .6
					}),
					/* @__PURE__ */ m(H, {
						x: 255,
						y: 466,
						s: .7
					}),
					/* @__PURE__ */ m(H, {
						x: 328,
						y: 345,
						s: .45
					}),
					/* @__PURE__ */ m(H, {
						x: 380,
						y: 362,
						s: .4
					})
				]
			}),
			/* @__PURE__ */ h("g", {
				strokeWidth: ".7",
				children: [wt.map(([e, t, n], r) => /* @__PURE__ */ m(gt, {
					x: e,
					y: t,
					s: n
				}, r)), Ct.map(([e, t, n], r) => /* @__PURE__ */ m(ht, {
					x: e,
					y: t,
					s: n
				}, r))]
			}),
			/* @__PURE__ */ h("g", {
				strokeWidth: ".6",
				children: [
					/* @__PURE__ */ m(xt, {
						x: 150,
						y: 152,
						s: .65
					}),
					/* @__PURE__ */ m(xt, {
						x: 184,
						y: 162,
						s: .7
					}),
					/* @__PURE__ */ m(xt, {
						x: 207,
						y: 171,
						s: .6
					}),
					/* @__PURE__ */ m(xt, {
						x: 177,
						y: 180,
						s: .6
					}),
					/* @__PURE__ */ m(xt, {
						x: 145,
						y: 165,
						s: .45
					})
				]
			}),
			/* @__PURE__ */ m("g", {
				fill: "none",
				stroke: "#9a885f",
				strokeWidth: ".7",
				children: /* @__PURE__ */ m("path", { d: "m100 88 3-7m-2 3 5-1m35 20 1-8m-4 6 6 0m41-8 3-6m-4 4 6 1m-81 74 2-6m-1 3 4-2m98 26 2-6m-2 2 5-2m-94 50 0-6m-3 2 6 0m76 16 2-8m-3 5 6-2m73-7 3-6m-3 3 5 0M14 194l12 3m-11 3 8 2m65 179 11 1m-10 4 8 1m220-1 4-4m0 7 6-2m113-163 8 0m-7 3 5 0" })
			}),
			/* @__PURE__ */ m("g", {
				fill: "#b4a579",
				strokeWidth: ".6",
				children: /* @__PURE__ */ m("path", { d: "m90 113 4-7 6 1 3 7-6 3Zm211 43 5-9 7 3 4 9-9 2ZM92 337l5-9 11 1 4 10-10 4Zm189 52 5-8 8 0 7 9-11 4Z" })
			}),
			/* @__PURE__ */ m("g", {
				fill: "none",
				stroke: "#806d4f",
				strokeWidth: ".8",
				opacity: ".55",
				children: [
					1,
					2,
					3,
					4
				].map((e) => /* @__PURE__ */ m("path", { d: `M${e * 100} 1V499M1 ${e * 100}H499` }, e))
			})
		]
	});
}
//#endregion
//#region src/games/pilgrims/detailed-companions.tsx
function Et({ x: e, y: t, r: n = 3 }) {
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("ellipse", {
		cx: e,
		cy: t,
		rx: n,
		ry: n * 1.1,
		fill: "#f1ead0"
	}), /* @__PURE__ */ m("ellipse", {
		cx: e + .7,
		cy: t - .2,
		rx: n * .4,
		ry: n * .6,
		fill: "#30372c",
		stroke: "none"
	})] });
}
function Dt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M47 121q2 9 12 16-10 9-13 19 1 4 7 4 8-12 19-21 5-4-6-14M76 125q12 3 19 13-8 7-13 14 0 5 5 6 12-8 15-20-5-12-16-18",
			fill: "#a08c62"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 153q-4 2-5 8 3 7 16 7l10-4-1-4q-9 3-13-6ZM82 150q-4 4-3 10 13 8 26 1l4-9-5-1q-7 8-17 1Z",
			fill: "#43493d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m46 159 7 2m-9 3q10 4 20-1m19-8 5 3m-8 4q13 5 24-3M51 132l9 7m33-2-9 13M55 148l6-10",
			fill: "none",
			stroke: "#b9b58f",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 85q-11 12-8 29l10 13q25 12 49-1l4-17-9-23Z",
			fill: "#88935c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M36 102q15 13 50 1l5 14q-22 15-53 3Z",
			fill: "#9c7e56"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 108q16 9 44-1m-46 9q17 9 45-2M51 108l1 8m11-7 1 8m11-10 2 8",
			fill: "none",
			stroke: "#5b523a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 77q-22 5-26 24l-7 18 9 2q9-19 22-25M82 80q11 4 14-3l8-17 8 2q-2 30-22 37l-12-8",
			fill: "#8f9e62"
		}),
		/* @__PURE__ */ m("path", {
			d: "M18 104q6-12 16-16m-15 12 12-11m-10 21 4-7M95 82l6-18m-3 21 6-17m-6 24 10-21M37 88l9 4m30-4 6 6M41 97q14 5 25 0m-20 5 5 2",
			fill: "none",
			stroke: "#526442"
		}),
		/* @__PURE__ */ m("path", {
			d: "M16 119q-8 3-11-2-2-5 2-8l5-1 4 5 6 2-2 7Z",
			fill: "#d0b781"
		}),
		/* @__PURE__ */ h("g", {
			transform: "rotate(38 15 121)",
			children: [
				/* @__PURE__ */ m("path", {
					d: "M9 108h9v8q7 4 7 10v13q-9 5-17 0v-13q0-7 5-10v-8",
					fill: "#c6d2c8"
				}),
				/* @__PURE__ */ m("path", {
					d: "M9 129h15v9q-7 4-15 0Z",
					fill: "#c7a466"
				}),
				/* @__PURE__ */ m("path", {
					d: "M12 118q-4 4-2 9m8-10 3 7m-9 11 8 0",
					fill: "none"
				}),
				/* @__PURE__ */ m("path", {
					d: "M10 108v-4h8v4Z",
					fill: "#a18456"
				})
			]
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 39q-10 14-10 27l-9 4 9 4-5 7 12-1 1 9 10-3q10 13 27 6l17-11-4-9 6-4-7-4 0-23Z",
			fill: "#343e32"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 37q17-9 29 0 4 6 3 13 7 0 11 5 7 7-2 11l-9 2q2 7-1 12-21 11-37-12-5-8-5-15Z",
			fill: "#c5ad79"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 45q2 12 7 17l-4 2-6-10m34-14 5 8 6 3",
			fill: "#ac9567",
			stroke: "none"
		}),
		/* @__PURE__ */ m(Et, {
			x: 56,
			y: 49,
			r: 5.7
		}),
		/* @__PURE__ */ m(Et, {
			x: 75,
			y: 46,
			r: 3.2
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 43q10-8 19-3m9-3 8 2m-5 14q8-3 11 2m-38 8q17 14 35 5l-2 10q-22 10-33-15Z",
			fill: "#e7dfba"
		}),
		/* @__PURE__ */ m("path", {
			d: "m49 67 1 6m5-3 0 6m7-4 0 6m7-5 0 5m7-7 0 5M36 64l5 5m-7 3 8 3m-7 4 10 2m-5 4 9 1m-2 5 8-2m2 5 10-4m3 2 8-4m1-4 7-4m-29-2 7 5m-5-1 9 4",
			fill: "none",
			stroke: "#a7ae8f",
			strokeWidth: ".75"
		}),
		/* @__PURE__ */ m("path", {
			d: "M29 35q12-5 20-12l3-19q4-7 10-5l5 5 2 13 25-3q10 1 7 8-8 9-32 15-27 7-40 0Z",
			fill: "#444d3c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M38 33q19-4 37-12m-23-3 13-1m-10-9 7-3M48 27l15-5m3 5 23-7m-46 15 20-4m15-3 16-6m-42-14 1 7m4-13 1 11",
			fill: "none",
			stroke: "#a1a88a",
			strokeWidth: ".75"
		}),
		/* @__PURE__ */ m("path", {
			d: "M103 62q-7-2-7-8 0-3 3-2l4 3-1-11q1-5 4-3l3 14 3-5q4-1 4 3l-4 10-5 3Z",
			fill: "#cfb47f"
		}),
		/* @__PURE__ */ h("g", {
			transform: "rotate(24 108 39)",
			children: [
				/* @__PURE__ */ m("path", {
					d: "M104 49q-1-8 2-15l-2-12 10-10 4 2-5 14 0 12 6 7-3 5-8-3Z",
					fill: "#a7b6ad"
				}),
				/* @__PURE__ */ m("path", {
					d: "M105 23q6 0 10-4m-9 9 6-2m-4 4 3 9m-4 1 8 6",
					fill: "none"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "114",
					cy: "14",
					rx: "5",
					ry: "2",
					fill: "#41483c"
				})
			]
		}),
		/* @__PURE__ */ m("path", {
			d: "M110 26q-14-5-6-11 6-5 2-10m10 14q9-5 1-10-6-5 5-7",
			fill: "none",
			stroke: "#707b64",
			strokeWidth: ".8"
		})
	] });
}
function Ot() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M29 114q-5 10-16 8l-10-4q3 9 16 10l17-6M44 128l-8 15-14 8 1 5 8-1 19-17M82 124l9 16 13 3 2 6-12 1-17-17",
			fill: "#b7a16b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m28 149 7 2m60-7 7 0M38 132l5 3m43-1 5 3",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M28 109q12-15 37-5l13-6q7-6 11-20l-1-14 8-12 11 4 1 18 12 7 10 1 0 8-16 4-4 18q-3 17-21 18l-43-1-16-7Z",
			fill: "#d4d5bc"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 125q-5 17-8 24l-11 7 0 5 13-1 14-26M94 122q9 10 11 20l14 11 8-1-1-5-11-9-9-21",
			fill: "#c9cbb7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M86 72q-1-16 6-22l4-6 6 4-1 8 8 0-1 7q-17 9-18 31l-8 8",
			fill: "#bd9d5e"
		}),
		/* @__PURE__ */ m("path", {
			d: "m93 50-4 6 5 2-7 5 4 3-6 5 4 3-5 8m3 7 3 1",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M92 59q6-4 12 0l-1 15 15 6 13 2-2 7-15 3-10-8-6 15-15-6q10-19 9-34Z",
			fill: "#b7c6c1"
		}),
		/* @__PURE__ */ m("path", {
			d: "M92 70q3-9 8-9m-8 16 7 2m-9 3 7 2m-10 4 8 3M106 72l-1 6 18 8m-16-20 2 6",
			fill: "none",
			stroke: "#e8ead9"
		}),
		/* @__PURE__ */ m(Et, {
			x: 103,
			y: 64,
			r: 2.8
		}),
		/* @__PURE__ */ m("path", {
			d: "M93 60q3-3 8-2m7 14 10 6m-28 16 12 5 10-16M101 89l-3 11m7-7-1 6m5-12 0 7m5-11 0 6M92 81l-12 32",
			fill: "none",
			stroke: "#8e6650"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 102q20 2 35-6l7 21q-12 15-36 9l-9-7Z",
			fill: "#986b48"
		}),
		/* @__PURE__ */ m("path", {
			d: "M26 108q26 10 61-2l3 12q-25 14-61 2Z",
			fill: "#a4b6b0"
		}),
		/* @__PURE__ */ m("path", {
			d: "M30 111q23 10 56-1m-54 7q23 9 53-2",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 72q-9 12-4 28l16 11 16-9 0-21q-13-18-28-9Z",
			fill: "#90a8a4"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 76q14-5 22 9m-26-2 20 12m-21-4 16 10m1 10 11-7",
			fill: "none",
			stroke: "#c5d6cd"
		}),
		/* @__PURE__ */ m("path", {
			d: "M59 103q5 5 12 0l-5 17 5 14-5 4-10-11 2-13-9-7",
			fill: "#879d98"
		}),
		/* @__PURE__ */ m("path", {
			d: "m62 113 6 0m-9 6 6 0m-6 6 7 0m-1 8 4 0M47 99l-11 9-9-3q-6 4 3 8l17 3 14-10",
			fill: "#b2c3b9"
		}),
		/* @__PURE__ */ m("path", {
			d: "M38 57q11 8 22 5l0 13-18-2Z",
			fill: "#7e9690"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 64q9 5 18 3m-17 1 16 3",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M35 54q-4-10 1-18 8-6 19 0l7 12 25-5-16 18-24 4-13-5Z",
			fill: "#b8c9c3"
		}),
		/* @__PURE__ */ m("path", {
			d: "M36 49q18 2 29-5l-2 8-26 5Z",
			fill: "#49584c"
		}),
		/* @__PURE__ */ m(Et, {
			x: 46,
			y: 50,
			r: 1.7
		}),
		/* @__PURE__ */ m(Et, {
			x: 57,
			y: 47,
			r: 1.5
		}),
		/* @__PURE__ */ m("path", {
			d: "m38 37 1 9m5-12 2 9m5-10 2 8m13 10 6-2m-11 7 6-2m-18 8 9-3",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 36q-3-8-13-6-12 5-18 1l-4-5q10 3 13-5 5-8 12-4 4-8 11-6 10 4-1 10 16-2 12 6l-12 5Z",
			fill: "#ad7050"
		}),
		/* @__PURE__ */ m("path", {
			d: "M12 26q10 2 15-8m-1 10q9-1 13-6",
			fill: "none",
			stroke: "#d39e6a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M68 81 111 24 122 16l-6 13-44 56Z",
			fill: "#b99559"
		}),
		/* @__PURE__ */ m("path", {
			d: "m74 77 41-54M49 78q8-3 14 6l-3 6-10-4-6-4",
			fill: "#b4c8bf"
		}),
		/* @__PURE__ */ m("path", {
			d: "m51 81 7 3m6 4 7 3-4 5-10-5M49 116l5 4m-25 1-2 7",
			fill: "none"
		})
	] });
}
function kt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M49 128q-4 14-10 23l-5 3q-2 7 5 9 5 1 11-3v-4q4 5 7-1 1-4-1-10l6-13M74 132q4 9 12 15l1 10q3 4 6 3l9-5-1-4-8-1q-3-15-7-22",
			fill: "#c9b382"
		}),
		/* @__PURE__ */ m("path", {
			d: "m37 156 4 2m5-5 0 6m43-7 4 1m0 3 6-2M42 144l6 3m35-7 5-1",
			fill: "none",
			stroke: "#8d7954"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 101q-9 14-4 31l19 8 7-13 7 13 20-7-7-33Z",
			fill: "#7c965c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 109 38 128l9 4 6-17m22-8 2 22 8-1M63 109l-1 18m-9 5 3-5",
			fill: "none",
			stroke: "#456742"
		}),
		/* @__PURE__ */ m("path", {
			d: "m42 118 9 1-2 11-9-1Zm29 0 10-2 2 12-11 2Z",
			fill: "#b99f71"
		}),
		/* @__PURE__ */ m("path", {
			d: "m41 118-3 8m5-8 0 12m5-10 0 11m23-12 2 11m5-13 1 11",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 67q-19 12-15 37l14 11 17-10 15 10 14-13-8-31Z",
			fill: "#9f9871"
		}),
		/* @__PURE__ */ m("path", {
			d: "M31 81q3-12 10-12l4 29-11 6m42-29 4 22-10 10M32 107l8 3m36-6 5-4",
			fill: "#907c53"
		}),
		/* @__PURE__ */ m("path", {
			d: "M36 33q-11 14-9 32l-8 25 13-6-3 11 13-8 0 11 11-9 21-6q9 10 19 8-9-15-11-33l-2-31Z",
			fill: "#a6b0a0"
		}),
		/* @__PURE__ */ m("path", {
			d: "M37 31q10-14 28-10 16-5 22 10-1 8-4 15l2 12q-4 10-12 16-17 2-27-8-9-8-10-18Z",
			fill: "#c5ae79"
		}),
		/* @__PURE__ */ m("path", {
			d: "M52 42q10-8 18-4 4 11 1 23l-7 7-5-15Z",
			fill: "#c1a46b"
		}),
		/* @__PURE__ */ m(Et, {
			x: 51,
			y: 42,
			r: 3.8
		}),
		/* @__PURE__ */ m(Et, {
			x: 75,
			y: 38,
			r: 3.1
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 36q5-6 12-4m13-3q7-4 12 0m-31 20 5 3m15-13q6 3 10 0M56 58q8 4 13 1",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M35 36q6-19 25-16L75 14q11 0 15 9l-16-3q-19 6-31 22Z",
			fill: "#d6d8bd"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 33q12-15 28-14m-27 9 13-6m14 0 13-1M33 42q-5 30-13 43m18-38q-3 28-11 41m16-38q0 20-10 40M80 43q1 23 12 44",
			fill: "none",
			stroke: "#62756a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 51q7 4 14 0l6 5 10-7 8 7q1 23-13 40l-4 3-5-8q-1 6-8 9v-11q-3 6-9 6l1-13-8 4q5-7 5-19Z",
			fill: "#d1d4b9"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 62q1 15-5 21m11-23q4 15-1 29m9-29q5 19-1 31m9-32q2 15-2 27m11-29q0 15-8 32",
			fill: "none",
			stroke: "#8d9e8d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M37 82q-6 11 1 17l18-1 5-6-8-3-10 1 3-7M79 81q8 6 13-1l7-15 6 1q0 23-12 26l-16 1",
			fill: "#a3b19a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 91q-4-6-7-2l3 5-6-1q-3 3 2 5l8 0 6-3m39-29q-3-7 2-9l5 2 2 8-5 4",
			fill: "#c8b17e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M54 94q20 6 40-6l24-9M92 89q-3-15-1-24l10-18m-45 45 12 1M100 48l2-7m-4 5-2-5",
			fill: "none",
			stroke: "#635b3e",
			strokeWidth: "2.6"
		}),
		/* @__PURE__ */ m("path", {
			d: "m52 93 3 2m-6 0 2 2m52-36-2 6m-69 31 6 3m41-1 5-2",
			fill: "none"
		})
	] });
}
//#endregion
//#region src/games/pilgrims/woodland-companions.tsx
function U({ x: e, y: t, r: n = 3 }) {
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("ellipse", {
		cx: e,
		cy: t,
		rx: n,
		ry: n * 1.15,
		fill: "#f3ebd0"
	}), /* @__PURE__ */ m("ellipse", {
		cx: e + .6,
		cy: t,
		rx: n * .4,
		ry: n * .65,
		fill: "#333b2d",
		stroke: "none"
	})] });
}
function At() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "m56 148-3 13-6 2-1 5 8 0 4-5 4 4 3-3-5-15m17-1-1 14 6 4 9-2-1-4-8-1 1-11",
			fill: "#718378"
		}),
		/* @__PURE__ */ m("path", {
			d: "M57 72q-4 13-8 20l3 15q-8 21-21 42 14 0 19 4 17 6 29 0l19-3q-12-19-20-43l0-16-6-20Z",
			fill: "#bc7950"
		}),
		/* @__PURE__ */ m("path", {
			d: "M57 101q2 25-16 45l12 5q15-20 14-45M69 105q5 26 21 44l-13 3q-12-19-14-42",
			fill: "#d59a65",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M56 83q8 6 17 0m-20 9q10 8 23 0M51 107q8 7 25 0m-20 6q-3 17-15 31m21-29q-1 18-12 31m17-28q5 17 13 27m-7-22 16 22M37 147l12 2m8 2 13 0m9-2 12-1",
			fill: "none",
			stroke: "#e8b27a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 75q-9 5-7 18l11 17 6-5-9-16 4-8m14-6q10 3 11 14l-11 21-6-5 9-16-7-7",
			fill: "#cc8c59"
		}),
		/* @__PURE__ */ m("path", {
			d: "M55 104q-3 4 1 8l8 5 7-7-6-6-3 4-4-4Z",
			fill: "#d4b784"
		}),
		/* @__PURE__ */ m("path", {
			d: "m58 109 5 3 4-3m-8 6 5-2m-8-19 3 4m14-3-3 5M49 82l4 2m25 0-4 1",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 33q-15 12-14 36l-3 12-10 2q4 14 20 9 12-2 17-17l15-4q2 15 16 18l10-7q-12 2-15-11l1-28q-4-18-23-17Z",
			fill: "#d1b15b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M52 34q14-9 24 0 5 5 3 16-2 9-6 15-3 12-10 10-15-4-16-21l-4-8q1-6 9-12Z",
			fill: "#ddbe8b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 42q-4 14 5 23l8 7q-8 0-13-10-5-11-2-17Z",
			fill: "#c49e72",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 52q4 5 8 1m15-3 7-3m-15 7 4 4-3 4m-10 4q6 8 13 2M48 43l8-4m13-2 7 3",
			fill: "none",
			strokeWidth: "1.4"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 30q-18 14-13 33 3 19-8 23m22-49q-13 13-10 33-1 14-11 17m29-52q-12 14-13 25m25-26q-13 11-21 12m25-6q7 16 3 31 0 10 9 12m-9-43q7 21 2 36m-39 8-4 5m2-3 5-6",
			fill: "none",
			stroke: "#8d7943"
		}),
		/* @__PURE__ */ m("path", {
			d: "m59 29-3-11 6 3 3-13 4 11 9-5-7 15Z",
			fill: "#d9c16b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m59 25 11 1m-8-6 3 5M52 75q7 7 16 0",
			fill: "none"
		}),
		/* @__PURE__ */ h("g", {
			fill: "#a3b5a4",
			children: [
				/* @__PURE__ */ m("ellipse", {
					cx: "54",
					cy: "75",
					rx: "2",
					ry: "3"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "59",
					cy: "77",
					rx: "2",
					ry: "3"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "64",
					cy: "76",
					rx: "2",
					ry: "3"
				})
			]
		})
	] });
}
function jt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M58 121q-8 8-13 21l-8 11q-1 5 1 9 2 3 5 2l2-7q1 8 5 5 2-2 0-11l18-22M77 123q10 2 11 10l-10 9q1 5 3 11 3 4 5 2l2-4-3-7q15-9 15-17-1-6-13-12",
			fill: "#cbb278"
		}),
		/* @__PURE__ */ m("path", {
			d: "m46 144 6 2m32-11 5 1m-47 18 3 2m36-7 3 1",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M58 91q-1 11-10 20l-10 8q11 2 21-8l-6 16 12-10 5 12 8-15q8 10 22 8l-14-12 16 0-17-15-2-9Z",
			fill: "#789555"
		}),
		/* @__PURE__ */ m("path", {
			d: "m61 99-10 14m17-14-7 22m14-23 3 18m2-17 13 16M54 92l26-1 2 6-26 2Z",
			fill: "#9a7d4e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M54 92q7-14 1-21l22-2q-4 10 6 20l-6 7-14-1Z",
			fill: "#c9b37b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M59 87q-6-12-13-8l9 10m10-1q-4-17 3-19 5 9 3 18m3 1q7-16 15-13-1 10-12 16",
			fill: "#7d965a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 25Q23 18 20 7q4 12 21 8L36 3q8 13 22 18Q52 9 56 1q7 17 15 23Q76 9 88 4l-5 14 16-7q-6 15-5 17 15 0 20-10-1 12-12 20l18-5q-4 11-14 14 5 8 16 5l-11 10 9 4q-8 5-20 2l10 8q-14 1-23-4l0 10-16-8q-6 8-17 10l-1-12q-11 8-18 7l1-10-15 1 7-11-16-3 11-9q-15-6-16-14 12 7 23 2-12-5-16-14 15 11 28 12Z",
			fill: "#b29053"
		}),
		/* @__PURE__ */ m("path", {
			d: "M20 36q13 13 25 8l0 17-15 9 9-10-14 2 8-9-13-7m62-21q3 8 12 10l-10 9 17-2-15 11 19 4-19 5 6 10-13-5Z",
			fill: "#997d47",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M57 37Q42 14 25 14m36 21Q52 14 45 11m20 25q0-20-7-28m13 26q6-19 18-24m-13 28q18-17 32-16M44 45Q28 24 18 30m26 20q-17-8-25-6m22 12-20 2m26 3q-13 12-17 9m57-29 23-10m-23 17q15-5 25-1m-27 9 22 6m-29 0 17 9m-39-34-9-17m-9 19-13-10m52 6 14-9",
			fill: "none",
			stroke: "#705c39"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 38q9-9 20-4 7-5 11-2 5 3 4 12 2 5 8 8 3 4-5 8-1 12-16 18-11 0-21-13-8-8-7-17 0-6 6-10Z",
			fill: "#cdb67e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 45q-2 14 9 21l7 8-11-5-7-12Z",
			fill: "#b39a65",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "m47 48-8-7 0 12 10 7m35-16 8-10-1 16-6 7",
			fill: "#bd9c66"
		}),
		/* @__PURE__ */ m(U, {
			x: 56,
			y: 46,
			r: 5
		}),
		/* @__PURE__ */ m(U, {
			x: 77,
			y: 42,
			r: 4.6
		}),
		/* @__PURE__ */ m("path", {
			d: "m64 45-3 14 9-3M51 61q12 12 28 0l-5 9q-16 4-23-9Z",
			fill: "#e3dbac"
		}),
		/* @__PURE__ */ m("path", {
			d: "m55 64 3 4m4-2 1 5m6-5 1 4m-22-29 10-4m13-3 8 1m-32 20 4 3M76 56l5-3",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M56 77q-12 10-24 3L15 70l-6 4q18 18 33 17l18-8m17-8q11-3 17-13l-1-24 7-1 2 28q-6 16-20 20",
			fill: "#cfb782"
		}),
		/* @__PURE__ */ m("path", {
			d: "M16 71q-4-3-6-8-2-3-4-1l1 6-7-4q-4-1-2 2l8 7-8-2q-3 0-1 3 5 5 11 6l7-2M93 39q-5-2-6-7-2-5 1-4l6 5-1-12q1-5 3-2l3 13 4-10q2-4 3 0l-3 15q-1 4-3 5Z",
			fill: "#d3bc88"
		}),
		/* @__PURE__ */ m("path", {
			d: "m24 81 7 5m58-16 6-4m1-29 2-4M4 71l7 4",
			fill: "none"
		}),
		/* @__PURE__ */ h("g", {
			fill: "#91b16d",
			children: [/* @__PURE__ */ m("path", { d: "m9 51 5-9 10-3-8 11-7 1m104 24 8-6 10 4-10 4Z" }), /* @__PURE__ */ m("path", { d: "m114 20 5-12 9-3-4 13-10 2Z" })]
		})
	] });
}
function Mt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M50 114q-4 15-11 30l-7 10q0 4 4 5 6-1 12-7l15-28M65 117q1 14 5 28 4 7 12 9l7-3q-6-5-8-12l-2-25",
			fill: "#557959"
		}),
		/* @__PURE__ */ m("path", {
			d: "M34 151q-4 0-6 5l3 7q12 5 25-4l-3-6-8 3-7-4M75 146l-4 6 7 11q12 4 22-4l-2-5-10 1-6-8",
			fill: "#655a41"
		}),
		/* @__PURE__ */ m("path", {
			d: "m38 159 11 0m31-2 12 1m-42-22 6 3m16 2 6-3",
			fill: "none",
			stroke: "#b7aa78"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 72q-8 15-6 38l-4 11q17 7 30-1l12 3q2-22-3-48Z",
			fill: "#4e7954"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 82q4 9-2 24l-2 11 9 2q8-27 2-42M70 83l3 27-7 5",
			fill: "#7b9867"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 78q10 9 20 1m-11 3-2 26m-8 1-5 2m16 3 12-2M51 87l-6 11m20-4 7 12",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M55 64v14l9 5 7-8-3-17",
			fill: "#bf9e65"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 36q-7 9-6 20l-4 9 10 1-4 6 15-4 16-13-3-17Z",
			fill: "#99753e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 36q12-10 20 0 4 5 1 15 8 3 10 9 2 7-10 5-2 10-7 11-13-3-18-22-3-12 4-18Z",
			fill: "#c2a06c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 44q-1 14 7 22l7 6q-10-2-14-12-4-11-2-16Z",
			fill: "#a88a5c",
			stroke: "none"
		}),
		/* @__PURE__ */ m(U, {
			x: 57,
			y: 44,
			r: 4.6
		}),
		/* @__PURE__ */ m(U, {
			x: 71,
			y: 42,
			r: 2.8
		}),
		/* @__PURE__ */ m("path", {
			d: "M54 59q-6 3-8 12 12 1 15-8 3 9 15 5 6-5 4-9-3 7-11 0l-7-3Z",
			fill: "#b88c4b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M58 69q-5 12 4 19l5-18m-6 3 0 8M43 48l3 10m-6-4 2 7m4-23 9-5m9-1 7 1",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M35 27q5-5 12-4l4-14 18 4 4 10q15 1 14 8-22 10-46 3Z",
			fill: "#63905e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 24q10 6 25-1m-21-12 1 11m-13 9q21 7 39-1",
			fill: "none",
			stroke: "#3e664b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M54 23Q43 10 45 1l9 5 5 15Z",
			fill: "#84a8a1"
		}),
		/* @__PURE__ */ m("path", {
			d: "m48 5 8 16m-6-11 5 2m-7 0 5 3",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 78q-11 14-5 24l21 10 5-7-16-10 3-13",
			fill: "#66875a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M62 105q1-4 5-4 4-1 5 3l2 6q-3 4-7 5l-8-5",
			fill: "#c6a674"
		}),
		/* @__PURE__ */ m("path", {
			d: "m65 105 5 3m-6 0 5 3m-5 0 3 2",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M34 101q17 8 39 1l-3 7-31 4-19-10 3-10Z",
			fill: "#b28a48"
		}),
		/* @__PURE__ */ m("path", {
			d: "m40 106 31-3 32-26 3 3-30 30-11 3-9 0m41-36 22-21 3 3-22 22Z",
			fill: "#7f8e7f"
		}),
		/* @__PURE__ */ m("path", {
			d: "m94 76 25-23 3 2-24 24m-27 24 26-25m-72 20 12 7",
			fill: "none",
			stroke: "#4d503a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M70 108q8 2 15 16l12 11",
			fill: "none",
			stroke: "#7c633f",
			strokeWidth: "1.8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M84 133q6-11 22-8l9 3 9-10 8 1 4 7-6 12-13 6-25 0-8-5-6-5-6 3-1-5 7-3Z",
			fill: "#a6a78b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m89 141-5 11 6 3 8-2 2-4-8 0 4-8m13 0 3 12 7 0 4-3-8-2 1-8m7-12 6 3 6 0-3 7-10 0Z",
			fill: "#b1b197"
		}),
		/* @__PURE__ */ m("path", {
			d: "M126 121q-8-6-12 0-6 14 0 18l4-3 4-12m10-1 9 0-1 4-8 1",
			fill: "#9b7948"
		}),
		/* @__PURE__ */ m(U, {
			x: 130,
			y: 122,
			r: 1.7
		}),
		/* @__PURE__ */ m("path", {
			d: "m136 121 5 1-1 3-5 0m-49 12 5 2m9-5 7 1m28 2 4-2m0 6 5-1",
			fill: "none"
		})
	] });
}
function Nt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M51 132q-5 8-5 17l-10 4q-4 7 7 8 6 0 13-3 4-11 7-22M74 133q1 8 4 16l11 1q7 5 0 9-9 2-16 0l-9-22",
			fill: "#577552"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 118q-4 9 3 20l18-1 6-6 7 7 16-3-5-20Z",
			fill: "#926f48"
		}),
		/* @__PURE__ */ m("path", {
			d: "m45 124 14 2m-13 5 10 1m17-6 9-3m-6 9 8-3M49 150l5 1m22 2 9 1",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 92q-11 13-9 29 28 12 56-3l-9-27Z",
			fill: "#698e97"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 105q14 8 38-1l3 10q-22 8-45 3m20-15v11",
			fill: "#4f7481"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 96q-9 7-16 2l-7-8-5 5q6 18 19 15l15-6M82 96q11-2 14 10l8 0-4-14-12-4",
			fill: "#6c98a0"
		}),
		/* @__PURE__ */ m("path", {
			d: "m57 116 10-2 4 5-8 4-6-2Z",
			fill: "#c9af6c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 72 30 77l10 5-13 7 13 2-11 6 17 1-3 9 15-4 8 7 11-10 14 4-3-10 15-2-12-8 6-6-13-4Z",
			fill: "#b6814c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 72q12-11 28-4 12 6 11 17-1 16-17 21-12-1-21-13-6-10-1-21Z",
			fill: "#c4a675"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 78q-3 13 9 21l7 3-9-1q-7-6-8-13m36-16q8 10 3 19l-6 6 4-10-5-12m-34 27-4 11 4 6 10 2-7-8 5-14m23 3 8 14-12 4 5-6-6-10m-28 34-5 13-7 3 9 1 6-15m23-1 6 14 8 1-8 3-8-16Z",
			fill: "#526e60",
			opacity: ".6",
			stroke: "none"
		}),
		/* @__PURE__ */ m(U, {
			x: 50,
			y: 79,
			r: 5
		}),
		/* @__PURE__ */ m(U, {
			x: 74,
			y: 77,
			r: 4
		}),
		/* @__PURE__ */ m("path", {
			d: "M61 76q-5 2-5 11-1 10 4 16 5 6 8-1 0-8-2-14l-2-14",
			fill: "#cbb07c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M59 81q-2 10 3 19l4 2q-3-3-3-11l-2-10Z",
			fill: "#b49666",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 94q2 9 14 10l-2-9-7-4m21 2 6-4 5 5-11 8Z",
			fill: "#e8d5a4"
		}),
		/* @__PURE__ */ m("path", {
			d: "m50 96 2 4m22-6 1 4m-32-20-7-4m9 11-9-2m7 10-7 0m17 8-4 5m23-3 5 2m2-32 8-1m-33-5-9 3",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 72q8-23 9-44L55 3q3 19 12 35 8 16 8 33-16 8-33 1Z",
			fill: "#81a66b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M55 11q-3 25 0 42L49 68m12-39q11 24 7 40m-13-13 3 13m-11-4 2-15M43 70q17 7 30 0",
			fill: "none",
			stroke: "#4d6d46"
		}),
		/* @__PURE__ */ m("path", {
			d: "M18 91q-5-4-10 0-3 3-1 7l5 3q4 0 5-3l4 3q3 0 2-3l-5-4M95 102q2 3 5 2 5-1 4-6v-6q-1-3-4-2l-6 3",
			fill: "#c4ab79"
		}),
		/* @__PURE__ */ m("path", {
			d: "m10 94 7 1m-6 2 5 1m81-2 5 1m-6 2 5 1",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "m99 101-13 31 3 2 13-32M95 87q12-3 18 10l2 12q-5-12-15-13l-12-1Z",
			fill: "#7e9188"
		}),
		/* @__PURE__ */ m("path", {
			d: "m12 100-7 14 1 6m-4-5 17 0 6 6-22 1Z",
			fill: "#b49962"
		}),
		/* @__PURE__ */ m("path", {
			d: "M4 121h20l-3 21-15 0Z",
			fill: "#c6a65c"
		}),
		/* @__PURE__ */ m("path", {
			d: "m7 124 12 14m1-14-11 14M7 122v18m13-19v19m-13-1 13 0",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "m-2 124-5-1m7 10-5 3m28-13 5-2m-1 11 5 2m-11 7 4 3",
			fill: "none",
			stroke: "#bba15e"
		})
	] });
}
function Pt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M48 120q0 13-8 25l-4 8q-8 3-5 7 4 5 17 5 9-1 6-7l-10-4q14-17 17-30M77 123q4 11 12 19l7 13q4 7 10-2 11 0 15-5 5-5-3-5l-5 3q-3-7-7-1-4-16-16-28",
			fill: "#bb9a68"
		}),
		/* @__PURE__ */ m("path", {
			d: "m42 140 5 2m-9 5 6 2m-9 5 5 1m-2-4-5-2m12-11-4-3m50 1 4-3m-1 9 6-3m-4 9 7-3m-2-4 4-3m2 13 3-1M51 126l4 4m29-3-5 4",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 58q-11 8-10 27 0 12 6 27 20 13 45 6 11-15 2-35 3-15-2-22l-12-10-22 0Z",
			fill: "#bc9b6a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M36 74q0 24 13 32 16 8 33 0l3 10q-25 13-45-4-6-18-4-38Z",
			fill: "#a28356",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 63q4 13 14 14l10-4m6-8q2 9 9 10m-37 5q4 7 11 6m20-6 6-1M56 92l7 2",
			fill: "none",
			stroke: "#8e7049"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 70q1 22 11 30 12 9 22-4l5-22M56 74l13 1m-13 7 12 2m-8 6 9 0m-11 10 12 3m-12 5 12 0",
			fill: "none",
			stroke: "#775d3e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 59q-14 3-20 18L12 99q2 7 10 4l26-16-2-8-22 13 8-15 16-7M85 60q19 6 25 22 7 8 1 11l-28 10-5-8 23-11-15-13",
			fill: "#c3a474"
		}),
		/* @__PURE__ */ m("path", {
			d: "m30 76-7 15m-4 4-3 4m76-26 8 8M44 80q-6-6-11-2l-1 5 5 5 11-4m35 12-5-8-4-2-1 7-6-6-3 1 4 9-5-3-1 3 8 7 10-1",
			fill: "#c4a573"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 109q16 5 45-2l7 19-12-2 4 7-14-6-1 9-10-8-6 6-7-10-9 7 1-9-8 2Z",
			fill: "#655940"
		}),
		/* @__PURE__ */ m("path", {
			d: "m36 115 13-3m-12 9 18-8m-12 13 19-12m-7 14 13-15m-4 15 10-15m-3 12 7-12m-1 8 5-7m-38-5q22 4 41-2m-44 8 5 3",
			fill: "none",
			stroke: "#b49e6b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 25q7-14 20-9 9 3 8 14 2 20-12 25-15 0-22-15-4-11 6-15Z",
			fill: "#c4a474"
		}),
		/* @__PURE__ */ m("path", {
			d: "M36 29q-10-5-11 3 1 8 12 5m28-13 8-3q7 2 3 8l-7 3",
			fill: "#c3a170"
		}),
		/* @__PURE__ */ m(U, {
			x: 44,
			y: 29,
			r: 4
		}),
		/* @__PURE__ */ m(U, {
			x: 59,
			y: 27,
			r: 3.6
		}),
		/* @__PURE__ */ m("path", {
			d: "m51 31-5 7 13-1M42 43q9 8 19 0l-1 6-13 1Z",
			fill: "#e1c993"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 22l6 2m8-4 7 1m-10 32 3 4",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M76 22q12-10 22-1 11 8 7 17-2 12-20 16-10-2-16-12-6-11 7-20Z",
			fill: "#c7a878"
		}),
		/* @__PURE__ */ m("path", {
			d: "m69 27-6-3q-7 1-5 7l9 3m32-9 8-4q8 1 4 8l-7 4",
			fill: "#bd9a68"
		}),
		/* @__PURE__ */ m(U, {
			x: 78,
			y: 29,
			r: 4
		}),
		/* @__PURE__ */ m(U, {
			x: 94,
			y: 27,
			r: 3.4
		}),
		/* @__PURE__ */ m("path", {
			d: "m88 29-5 8 12-1M78 42q10 7 22-2m-23-17 6-1m8-1 7-1m-12 33 1 4",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M86 58q-13 18-14 48l-8 5q3-33 16-57Z",
			fill: "#65533b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M55 93Q40 62 22 41L13 27l5-5 10 12q23 27 35 56Z",
			fill: "#625039"
		}),
		/* @__PURE__ */ m("path", {
			d: "m17 28 9 15 22 32m-25-43 9 19m-5-18 19 30m-12-13 13 16m-30-34-5-8m2 13-9-7m11 12-12-4m18 12-8-1m12 5-10-1",
			fill: "none",
			stroke: "#a08d63"
		}),
		/* @__PURE__ */ m("path", {
			d: "m23 42-5 16-5 1-1-5 8-16",
			fill: "#85a06b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m37 87 5 1m-6-6 5 1m-11 6 3 1M39 64l5 2m34 5 4-2m-41-5-2 5m67 13 4-2",
			fill: "none"
		})
	] });
}
function Ft() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M58 119q-10 11-7 24l-7 12q-1 5 5 6l12 6q4 2 5-2l-2-4-10-5q4-6 9-15l6-19M75 121q5 6 1 15l-3 11q0 6 10 5 9 0 19 2 5-1 4-3l-2-4-15-1-4-3q3-10 3-14l-4-12",
			fill: "#698e7a"
		}),
		/* @__PURE__ */ m("path", {
			d: "m48 156 5 3m3 2 1 4m3-4 2 4m19-16 2 4m5-5 2 5m5-5 2 5M55 140l4 2m19-8 4 2",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M54 78q-9 15-8 29l12 18 13-5 12 4 2-10-13-26-3-12Z",
			fill: "#527b68"
		}),
		/* @__PURE__ */ m("path", {
			d: "M54 89q5 9 4 19l8 12m2-31 5 11m-10 1 7 3m-15-9 0 8m-7-8 3-7m-6 18 6-3m24 10 5 2",
			fill: "none",
			stroke: "#344e42"
		}),
		/* @__PURE__ */ m("path", {
			d: "M57 77q-11 4-16 15l-2 18 8 3 4-18 10-9M71 80q13 2 18 13l14-10 4 4q-9 17-20 17L73 92",
			fill: "#678f79"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 108q-5-5-9-1-3 3-1 8 3 4 7 4l4-5m53-30q-4-4-1-9 3-2 5 1 4 3 4 6l-3 7",
			fill: "#7b9b83"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 116q-12 22 1 28 8 2 12-9l-4-18",
			fill: "none",
			stroke: "#745d3f",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 114q-6-1-7 7l2 10q10 4 15-6l-3-10 1-9-6-1Z",
			fill: "#a48048"
		}),
		/* @__PURE__ */ m("path", {
			d: "m43 118 7 0m-10 7 7 1m-4-9 0-6 5 1m-7 19 6-2",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 37q-11 10-9 24l-9 13 11-3-3 10 15-4 14 4 15-7 9-10-7-20-15-13Z",
			fill: "#648b75"
		}),
		/* @__PURE__ */ m("path", {
			d: "m44 46-12-6 1 13-8-2 12 10m7-16 4 8m-9-16-8-9m4 5-9-4m6 6-12-1M34 64l-9 2m14 6-11 6m16-5-7 11m15-8-3 10",
			fill: "none",
			stroke: "#4a6656"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 37q12-10 22-3 7 4 7 9 17 0 29 15 7 10-5 16-23 11-45-7-16-14-8-30Z",
			fill: "#759a82"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 48q-2 14 14 22 21 10 41 1-22 15-44-4-10-9-11-19Z",
			fill: "#587a67",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 36q7-15 17-4l-4 9M70 36q7-11 13-3l0 9",
			fill: "#6e927a"
		}),
		/* @__PURE__ */ m(U, {
			x: 53,
			y: 39,
			r: 7
		}),
		/* @__PURE__ */ m(U, {
			x: 77,
			y: 36,
			r: 4.4
		}),
		/* @__PURE__ */ m("path", {
			d: "M52 61q17 15 47 3l5-6 0 10q-26 20-49 4Z",
			fill: "#303d31"
		}),
		/* @__PURE__ */ m("path", {
			d: "m58 67 3 6 4-4 3 5 5-4 4 4 4-6 5 3 4-6 4 2 3-5",
			fill: "#d6d1a2"
		}),
		/* @__PURE__ */ m("path", {
			d: "m87 55 0 2m10 2 0 2M48 57q-5 4-6 9m15 14 0 5m5-6 1 7m5-7 2 5m6-9 4 4M57 51l10 2m6-6 8 3m-36-20q-3-7 4-10l9 1 2 7",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 30q-4-10 8-13 8 1 11 8l-7 0-7 7Z",
			fill: "#a28450"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 33q10-10 25-7l1 5-21 7Z",
			fill: "#343b2d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 63q-8-1-14 4l-8-1m10-1-9 7m21-8-7 8m5 0-9 5",
			fill: "none",
			stroke: "#b6b899",
			strokeWidth: "1.6"
		}),
		/* @__PURE__ */ m("path", {
			d: "M104 84q0 12 9 13 12 0 13-14l-2-8-7 0-2 11q-5 2-6-4Z",
			fill: "#ae8b4d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m117 75 2-5 3 1 0 4m-5 6 7 1m-12 12 8-1",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M52 66q9 2 17 0m33 18 3 2m-57 28-2 2m-5-1-1 3",
			fill: "none"
		})
	] });
}
//#endregion
//#region src/games/pilgrims/curious-companions.tsx
function W({ x: e, y: t, r: n = 3 }) {
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("ellipse", {
		cx: e,
		cy: t,
		rx: n,
		ry: n * 1.12,
		fill: "#f2ebd1"
	}), /* @__PURE__ */ m("ellipse", {
		cx: e + .6,
		cy: t + .2,
		rx: n * .43,
		ry: n * .62,
		fill: "#30382e",
		stroke: "none"
	})] });
}
function It() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M50 110q-12 6-12 22 0 13-13 20-3 9 9 12l11-1 3-6-9-3q17-15 18-29M76 114q17 2 22 15l-6 15q8-2 15-1l5 6-1 5-15-1q-15 1-15-8l6-14-17-4",
			fill: "#a37d4e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 89q-8 9-13 21l-6 7q-10-2-10-9 7-11 18-4",
			fill: "#866540"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 68q-16 16-15 37 0 23 22 28 23 1 38-18 7-23-9-40Z",
			fill: "#ad8753"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 84q-9 28 3 42 18 9 36-5-18 18-32 11-22-6-12-37Z",
			fill: "#8e6d44",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 74q-15 13-23 0L13 57l-7 0q-4 25 9 33 14 11 29-2M77 81q11 10 22 1l13-14 7 4q-5 20-24 25l-15-5",
			fill: "#b58f5c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M13 60q8-3 7-11-3-3-6 1l2-9q-2-7-5-2l-3 7-5-3q-6-1-5 3l2 7-5 0q-3 2-1 4l10 7 8-1m101 7q7 1 10-5 1-5-6-1l2-8q-2-5-5 0l-3 8-1-7q-2-4-4-1l-2 9 4 10Z",
			fill: "#b89663"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 22q-11-17-20-5-5 11 10 16m40-13q2-20 14-15 8 6 1 17",
			fill: "#ad8752"
		}),
		/* @__PURE__ */ m("path", {
			d: "M28 21q-4-5-5 0l7 8m50-11 5-8",
			fill: "none",
			stroke: "#655239",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 21q22-12 38 6l4 18q17 4 25 13l-2 13-23 1q-7 15-26 15-22-3-26-23L29 43q0-14 13-22Z",
			fill: "#ae8651"
		}),
		/* @__PURE__ */ m("path", {
			d: "M76 48q9-6 17 3l17 6q5 6-1 11l-15 4q-7-2-13-8l-10-4Z",
			fill: "#bd9c65"
		}),
		/* @__PURE__ */ m("path", {
			d: "M33 39q-7 21 6 35l14 8q-16-1-21-18l-3-21m52-16q1 12-2 18l7 3 8 6-12-4-9 4q2-15-4-25Z",
			fill: "#967044",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M20 78q8 7 20-2l-1 8q-15 9-25 0m69 4q9 7 17 0l10-10-7 13q-8 7-17 4Z",
			fill: "#8e6b43",
			stroke: "none"
		}),
		/* @__PURE__ */ m(W, {
			x: 56,
			y: 39,
			r: 4
		}),
		/* @__PURE__ */ m(W, {
			x: 77,
			y: 36,
			r: 3.2
		}),
		/* @__PURE__ */ m("path", {
			d: "M79 63q15 5 23 1l-4 9-17 0-10-9q-1-6 4-5Z",
			fill: "#493e2c"
		}),
		/* @__PURE__ */ m("path", {
			d: "m77 63 6 2-3 4m7-3 3 7 4-7m-11 6 3-3 3 4m6-1 2-4",
			fill: "#e2d8ad"
		}),
		/* @__PURE__ */ m("path", {
			d: "M103 56q9-5 15 0 3 8-8 9l-7-3Z",
			fill: "#333b2c"
		}),
		/* @__PURE__ */ m("path", {
			d: "m39 29-4 9m6-16 4-4m-13 27-4 7m4 7-4 5m10 1-3 7m7 2-2 7m7-10-1 6m0-45 9 2m15-7 7 1m-27 51 8 5m11-7 7-1m-33 14 6 4m-11 4 6 6m-2 5 6 3m5-8 4 5m-20 0 7 5m-3 7 7 4m8-9 7 2m8-8 4 4m-26 25 9 2m4-8 7 0m-46-46-4 3m-2-9-4 2m63 14 5 3m-2-8 5 3M33 146l6 2m-4 4 5 2m-11 9 2-5m4 6 3-5m3 4 3-5m53-12 0 7m5-7 1 7m5-6 2 5",
			fill: "none",
			stroke: "#67563a",
			strokeWidth: ".9"
		})
	] });
}
function Lt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M48 112q-14 9-17 26-2 9-6 15 1 5 10 5 13-13 18-31 12 2 21 12-1 8-8 15 1 5 10 5 16-14 11-27-6-12-25-24Z",
			fill: "#696d90"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 118q-15 18-16 32m22-31q9 0 23 14l-5 18m-32-22 5-4m26 18 7 1m-23-24 6-6",
			fill: "none",
			stroke: "#a4a0af"
		}),
		/* @__PURE__ */ m("path", {
			d: "M27 153q-7 5-4 10l6 2 4-4q9 5 15 1l1-4-11-1-4-5M70 155q-6 6-2 9l8 1 3-4q8 3 15-3l-1-4-12 4-4-5Z",
			fill: "#414941"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 65q-14 8-12 33l-7 22-8 9q8 0 9 6 15-6 15-20l19-9 9 10q-5-24-2-43Z",
			fill: "#e3e1c8"
		}),
		/* @__PURE__ */ m("path", {
			d: "m39 74-4 26-8 25m31-50 1 26m-16 4-5 8m-2 12-5 4m30-19 4 5",
			fill: "none",
			stroke: "#7f9787"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 73q-16 7-19 23l11 10 18-5 1-6-16 2-4-4 17-13M64 76q3 18 14 22l18-18-4-4-16 13-7-18",
			fill: "#d8deca"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 34q15-9 25 3 3 8 0 16l10 7q4 8-9 7-3 8-8 10l-12-7q-4-3-7-15l-8-3Z",
			fill: "#d4b67f"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 33q-12 5-12 19l-7 3q9 10 19 5l4-13 17-13q14 2 22-5-4-11-15-7Z",
			fill: "#c8a15d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 37q-9 9-8 17m11-16q-9 10-7 18m9-15-4 14m19-25q13 5 23-1",
			fill: "none",
			stroke: "#87683e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 40q-2 15 7 24l9 8-10-2q-7-7-7-15l-3-7m28-11q5 7 1 16l8 8-8 1-6-8 0-12Z",
			fill: "#b79b6a",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M34 85q-1 14-4 26l-10 18 8 3q9-11 9-22l8-10m13-21 3 17 5 9-4-20m-19 37q-10 15-10 26l6 3q6-18 12-24m11-5q15 10 13 21l-8 12 7 1q13-14 10-23Z",
			fill: "#b9c5b3",
			stroke: "none"
		}),
		/* @__PURE__ */ m(W, {
			x: 59,
			y: 46,
			r: 3.8
		}),
		/* @__PURE__ */ m(W, {
			x: 74,
			y: 43,
			r: 3
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 62q5-7 10 1l7 1-4 5-11-4m4-25 7-3m5-2 7 0m-11 12-1 7 7 2",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 29q-11-11 3-17l20-5 9 4-3 9q-15 12-29 9Z",
			fill: "#717890"
		}),
		/* @__PURE__ */ m("path", {
			d: "m43 21 24-9m-22 12 24-9m-13-7 0-5 5-1 2 5m-27 16q19 9 37-7",
			fill: "none",
			stroke: "#454e56"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 65q8 4 13 10l14-4-7 8-9-1-4 10-3-13-9-4Z",
			fill: "#b47450"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 100q-5-8-11-5l0 9 8 5 5-3m48-28q-2-5 3-6l5 2-3 6-5 1",
			fill: "#c9ae79"
		}),
		/* @__PURE__ */ m("path", {
			d: "M34 108q-8-10 2-12 7 1 9 8 15 0 20 9-6 12-24 4Z",
			fill: "#c1aa67"
		}),
		/* @__PURE__ */ m("path", {
			d: "m38 100 3 4m6 4 3 2m-9 3 4 1m9-2 4 2",
			fill: "none",
			stroke: "#63888a",
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ m("path", {
			d: "m94 75 14-15-2-2-15 14m-3-4 19 6m-4-15 8-5-4 8Z",
			fill: "#b9985e"
		}),
		/* @__PURE__ */ m("path", {
			d: "m104 105-12 58 3 0 15-57m12-1 7 60 3 0-4-61m-10-4-1 65 3 0 4-64",
			fill: "#a28c59"
		}),
		/* @__PURE__ */ m("path", {
			d: "m97 100 25-61 21 7-17 61Z",
			fill: "#bfb993"
		}),
		/* @__PURE__ */ m("path", {
			d: "m101 97 21-51 16 4-14 50Z",
			fill: "#bdd7c2"
		}),
		/* @__PURE__ */ m("path", {
			d: "m102 94 10-20 4 8 8-14 7 10-7 23Z",
			fill: "#8ca56d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m111 63 6-3 3 4 5-2m3-9 5 0m-16 39 3-10m-3 1 5 3m-4-4 2-4m-1 1 2 0",
			fill: "none",
			stroke: "#65816b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m100 99 27 4-1 5-28-4m19-65 25 5 0 3-26-4m3-4 3-4 5 1 0 5",
			fill: "#a98b56"
		})
	] });
}
function Rt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M57 131q-8 9-7 23l-7 5 0 7 8 0 5-5 5 3 8-3-1-5-11 0 7-23M76 132l1 20 10 7 9-1 2 4-8 5-13-4-6-10-2-19",
			fill: "#48554b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m51 149 9 1m-10 4 7 1m18-5 7-2m-5 7 7-1m-33 8 7 0m23-3 11 2",
			fill: "none",
			stroke: "#99ac99"
		}),
		/* @__PURE__ */ m("path", {
			d: "M55 71q-11 6-6 31-3 17-12 35 24 11 47-1-5-20-6-39l-8-27Z",
			fill: "#586f6c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M54 88q7 21-8 47m9-27-5 29m11-24-2 26m7-27-2 27m9-32 3 27M53 80l9 6m-10-1 8 7m-10-1 7 5m-8 0 7 4",
			fill: "none",
			stroke: "#98a99b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M62 78q-1 31 3 62M45 103q12 4 30-3",
			fill: "none"
		}),
		/* @__PURE__ */ m("g", {
			fill: "#303d32",
			children: [
				110,
				119,
				129
			].map((e) => /* @__PURE__ */ m("circle", {
				cx: "67",
				cy: e,
				r: "1.3"
			}, e))
		}),
		/* @__PURE__ */ m("path", {
			d: "M55 79q-12 10-3 22l19 5 18-22-5-4-16 17-8-7m14-10 7 10 8-4-10-15",
			fill: "#718a80"
		}),
		/* @__PURE__ */ m("path", {
			d: "M83 81q-6-3-5-10l0-8 3-1 2 10 1-13 3 0 1 11 2-10 3 1 0 13 3-7 3 2-6 16-7 3Z",
			fill: "#cdb47e"
		}),
		/* @__PURE__ */ m("path", {
			d: "m82 75 8 4m-3-8 0 6m4-5-1 6M54 87l4 7m-2 4 8 4",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M56 35q14-9 23 4 3 5-1 13 9 2 18 7 4 9-5 9l-12-2q-2 9-8 10-14-2-18-16l-6-12Z",
			fill: "#d6b97f"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 35q-8 10-6 23l-9 1q6 12 18 6l6-14 0-18Z",
			fill: "#c6a85e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 40q-7 16-4 21m8-22q-5 9-5 18",
			fill: "none",
			stroke: "#8f7643"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 45q-1 15 5 23l11 7-9-1q-10-6-11-18m28-16 1 12 11 9-9 0-6-6Z",
			fill: "#b99a69",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 85q0 20-11 46l9 4q11-23 9-40m18 10 6 29-8 3q2-16-4-29M53 96q8 6 16 6l9-10-9 15-16-6Z",
			fill: "#3f5752",
			stroke: "none"
		}),
		/* @__PURE__ */ m(W, {
			x: 63,
			y: 46,
			r: 4.1
		}),
		/* @__PURE__ */ m(W, {
			x: 79,
			y: 43,
			r: 3.4
		}),
		/* @__PURE__ */ m("path", {
			d: "m56 39 8-4m10-2 7 2M58 61q7 9 16 1m-16 1-3 1",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 33q-1-14 17-16 14 0 16 12l-5 9-23 5Z",
			fill: "#687a79"
		}),
		/* @__PURE__ */ m("path", {
			d: "m50 29 28-5m-27 9 27-5m-24 1 0 7m7-8 0 6m7-8 0 6m-10-14-5-13m-5 8 13-5",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M52 71q6 7 17 4l1 5-11 1-8-5Z",
			fill: "#e2dfc7"
		}),
		/* @__PURE__ */ h("g", {
			transform: "translate(16 24) scale(.7)",
			children: [/* @__PURE__ */ m("path", {
				d: "M0 8q-15-4-14-16l11 5 4-9 5 14 11-4-4 11-7 5-12-2Z",
				fill: "#e6e5d0"
			}), /* @__PURE__ */ m("path", {
				d: "m10 7 7 3-7 2m-13-8-6-5m14 18-3 5m-8-6-3 5",
				fill: "none"
			})]
		}),
		/* @__PURE__ */ h("g", {
			transform: "translate(109 30) scale(.7)",
			children: [/* @__PURE__ */ m("path", {
				d: "M0 8q-7-8-5-17L4 0 12-9l-1 14 13-3-8 13-11 1-9-4Z",
				fill: "#e5e5d0"
			}), /* @__PURE__ */ m("path", {
				d: "m-6 7-9 1 9 3m9 5 0 7m6-8 3 6",
				fill: "none"
			})]
		})
	] });
}
function zt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M52 133q-6 12-5 21l-7 4q-1 7 11 7l8-3 1-7-1-20M73 134l3 18 11 4 6-1 0 5-12 3-10-5-5-20",
			fill: "#34423c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 75q-17 13-15 33l-5 29q24 7 51-2l-5-59Z",
			fill: "#3b514b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m44 106-7 28m12-26-4 27m11-17-3 18m14-20 0 19m6-19 4 16m-35-32 7 3m-9 4 7 3m-5 4 6 3m-9 5 6 3",
			fill: "none",
			stroke: "#768a7c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 84q-14 6-15 21l-5 11 6 3q12-9 12-24l8-5M76 85q9 11 22 5l4-10 6 1q-1 23-17 20l-15-8",
			fill: "#46594d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M23 113q-4 2-5 8-2 4-7 4-4 1-2 4 5 3 11-1-4 6-1 7 4 0 6-5-1 6 2 5 4-4 4-12l-4-7m75-34q-4-2-4-6 0-4 4-5 5-2 7 2l1 5-2 9Z",
			fill: "#a6ab86"
		}),
		/* @__PURE__ */ m("path", {
			d: "m20 125 5-3m75-46 5 2m-4 1 4 1m-5 2 4 1",
			fill: "none",
			stroke: "#6c775b",
			strokeWidth: ".75"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 44q9-9 22-1 6 5 5 15l12 4q5 7-7 7l-12-4q-1 9-6 13l-17-9q-4-4-5-15Z",
			fill: "#adad87"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 48q-4 13 6 20l6 7-10-5q-9-9-6-16m30-10 5 14 7 5-13-4Z",
			fill: "#8f9774",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 76q-2 18-11 33l6 6 4-9q11-23 9-39m17 6q15 12 10 29l3 17-9-6 3-19-10-23m-14 5q-3 22-7 35l4 9q5-20 8-39m8 6 1 29 6 2-4-32",
			fill: "#536f66",
			stroke: "none"
		}),
		/* @__PURE__ */ m(W, {
			x: 57,
			y: 53,
			r: 3.9
		}),
		/* @__PURE__ */ m(W, {
			x: 72,
			y: 50,
			r: 3
		}),
		/* @__PURE__ */ m("path", {
			d: "m62 54-1 12 11-3M48 53l-5-5-3 5 4 7",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 60c-7 7-8 16-8 25 0 16-4 25-10 33 6-1 11-5 13-9-2 9-3 16-1 21 5-2 9-6 11-11-2 7-2 12 0 16 5-3 8-7 10-12 1 5 4 8 7 10 3-4 5-10 5-15 3 4 7 6 11 7-4-8-4-15-2-24 4-17 0-29-12-34l-9 4-7-6Z",
			fill: "#80988e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 65c-7 8-5 18-7 30-1 9-5 15-9 20 8-6 13-15 14-25l2-14m8-8c-8 15-1 29-6 45-1 5-4 10-8 15 9-4 14-12 16-20 2-11-2-19 0-28m7-9c-5 14 4 29 0 42-1 6-5 15-10 20 7-4 14-11 15-20 2-11-3-21-2-32m5-9c9 10 6 23 5 32-1 7 0 12 4 18-7-4-11-11-10-18 2-10-1-17-2-22",
			fill: "#607f73",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 66c-6 11-3 20-5 32-1 5-3 10-6 14m17-40c-3 12 0 19-1 30-1 10-5 18-9 23m17-51c-2 10 2 19 1 29-1 12-4 21-9 28m14-55c1 15 5 21 4 33 0 8-1 14-3 20m4-51c6 12 2 21 5 32l4 10",
			fill: "none",
			stroke: "#b4c2b0",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 62c-7-11-17-10-17-1 0 6 4 13 2 19l-8-1 9 11-8 12 14-4m30-34c12 4 16 13 14 24l-8-5M52 68q-5 4-7 11m14-7q-3 11-2 19m8-16q2 9 2 16m8 19-1 9m-15-7-4 10",
			fill: "none",
			stroke: "#374e47",
			strokeWidth: ".9"
		}),
		/* @__PURE__ */ m("path", {
			d: "M38 45q3-7 12-7l-1-26q9-6 21-1l1 25q18-3 20 4-22 17-47 10Z",
			fill: "#3e534d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 16q8 4 17-1m-17 6q8 4 17-1m-17 6q8 4 17-1m-17 6 17-2m-25 15q19 5 37-4m-27-2 1-7",
			fill: "none",
			stroke: "#8ba096"
		}),
		/* @__PURE__ */ m("path", {
			d: "M57 10q-7-7-3-13l6 5 5-6q7 7-1 15",
			fill: "#6b8c88"
		}),
		/* @__PURE__ */ m("path", {
			d: "m55 2-10-7-7 7-7 2 3 8 5-6 6 4 5-7m14 1 8-10 9 5 3 8-7-2-3 6-6-4",
			fill: "#877d55"
		}),
		/* @__PURE__ */ m("path", {
			d: "M103 165q1-22 5-41l-2-24 5-22-4-8 5-13 3 2-3 12 4 8-4 22 1 22-6 42Z",
			fill: "#857553"
		}),
		/* @__PURE__ */ h("g", {
			transform: "translate(115 58)",
			children: [/* @__PURE__ */ m("path", {
				d: "M-11 0q-8-13 5-17 8-3 9-12l10 0 3 5-8 1 9 7-11-1-7 12 4 6Z",
				fill: "#303d35"
			}), /* @__PURE__ */ m("path", {
				d: "m-7-12 9-3m-9 12-5 6m7-8 3 8m8-24 2-1",
				fill: "none",
				stroke: "#728576"
			})]
		})
	] });
}
function Bt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M51 119q-12 8-11 22l3 14-5 4q-2 3 1 5l11 5 8-1q7-4 4-5l-3-4-9-1-1-12q12-12 15-20M77 124q12 11 7 20l-7 9q-3 5 4 7l16 0 5 4q7 1 6-4l-1-5-14-5 5-14-10-15",
			fill: "#818b97"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 111Q23 98 20 73q1-12-8-21l1 22-9-9q0 15 4 23l-6-3q1 10 6 17l-5-1q5 20 32 27Z",
			fill: "#7a8490"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 68q-19 12-18 34l-5 16 9-2-1 13 12-5 7 10 13-7 13 7-2-12 10-5-7-18 3-26Z",
			fill: "#87939d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 84q-12 19-5 37l10-7 8 12 3-16 10 9-3-30Z",
			fill: "#6a7985",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M55 78q-9 7-5 19l16 9 14-10-4-5-10 6-6-8 7-5M80 77q10 4 13 15l9-9 5 4-8 15-11-1-15-14",
			fill: "#8f9da6"
		}),
		/* @__PURE__ */ m("path", {
			d: "M98 84q-3-6 1-9 4-3 9-1 5 0 7 5l-1 5-5-5q-3-1-4 1l5 8q0 3-3 4l-4-5m-25 7q0-6 4-8 6-2 8 1l2 5-5-1q-3 1-2 4l6 3-1 4q-7 0-11-3",
			fill: "#87959e"
		}),
		/* @__PURE__ */ m("path", {
			d: "m100 79 4-2m-1 8 3-3m-24 9 4-2m-4 9 5 1",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 37 27 23l6 20-10-1 10 9-7 3 9 9-3 12 10-2 3 12 13-9 22 1 7-15-3-19-10-13 0-18-15 14Z",
			fill: "#89939b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m33 29 9 12-6 0m34-20-4 13 5 3",
			fill: "#adabb0"
		}),
		/* @__PURE__ */ m("path", {
			d: "M66 41q12-10 18 4 16-2 28 2l14 6q4 7-3 12l-19 4-23-6q-2 12-7 15l-19-10q-10-5-6-15Z",
			fill: "#969da1"
		}),
		/* @__PURE__ */ m("path", {
			d: "M64 59q12 17 37 9l18-9 1 13-15 9-24-1-19-10Z",
			fill: "#343d34"
		}),
		/* @__PURE__ */ m("path", {
			d: "M76 74q15-7 25 2l-9 4-11-2Z",
			fill: "#ad786b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m70 64 3 8 5-6 3 8 4-7 4 9 4-8 5 6 3-8 5 4 4-8 4 3 3-6m-40 19 4-5 4 5 4-4 4 4 4-5",
			fill: "#e1dbb7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 45q-4 13 10 24l9 5-9-2-3 7-4-12-7 0m42-26 7 9 25 2 9 5-30-2-10-8",
			fill: "#687b86",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M38 100q-3 11 1 20l8-5 7 9-2-13m-38-26q1 21 16 29l7 2-12-15m22 30-4 15 4 10 9 1-6-7 2-11m36 0-6 11 6 7 8-1-6-7 6-7",
			fill: "#647783",
			stroke: "none"
		}),
		/* @__PURE__ */ m(W, {
			x: 53,
			y: 45,
			r: 5
		}),
		/* @__PURE__ */ m(W, {
			x: 77,
			y: 38,
			r: 3.5
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 39q6-5 13-2m12-5 8-2M117 49q11-4 12 3l-3 7-10-1Z",
			fill: "#374138"
		}),
		/* @__PURE__ */ m("path", {
			d: "m83 45 4 7m3-7 4 8m3-7 4 9m3-8 4 7m-74-7 6 4m-5 3 8 4m-6 4 9 3m2-7 4 7m-10 2 6 5m5-2 5 8m-21 2 5 4m-8 1 7 5m-6 3 7 4m-6 6 7 3m-3 5 6 5m6-1 4 5m4-11 5 5m-2-13 6 4M10 76l11 15m-9 0 12 12m-10 0 14 10m-5-9 9 11m14 23 7 1m33 4 7 2m-47 15 0 5m6-5 0 5m4-4 1 5m32-14 0 5m5-3 2 5",
			fill: "none",
			stroke: "#4d5b5f",
			strokeWidth: ".85"
		})
	] });
}
function Vt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M55 113q-3 16-12 26l-5 9 5 7 14 10 6-1-5-5-9-8 14-18 4-14M77 116q12 6 13 19l-5 17 8 1 11-4 6 3-1 4-22 5-11-4q-3-5 3-18l-12-13",
			fill: "#53664b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 148q-6 0-6 5 0 5 10 12l8 3q3 1 3-2l-10-9 9 4q5 0 3-2l-11-8m35-2q1 5 5 5h7l3-4q3-3 4 1v4l7 0q3 2-1 4-10 4-19 2l-9-3Z",
			fill: "#a38c57"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 80q-17 15-14 35l-1 10 10-4 5 10 8-10 10 7 8-9 10 5-3-22-9-23Z",
			fill: "#40563d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M52 89q-15 5-19 20l-8 17-5-2 6-25 16-17M78 85q11 11 26 3l9-9 6 3q-4 19-24 20L77 96",
			fill: "#62814d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M23 123q-9-1-10 5-2 5 4 5l6 1 10-7-5-6m83-40q-3-5 2-9 5-4 5 0v6l6-4q4-2 3 2l-5 6 5 2 4-6q3-2 3 1 1 7-2 10-5 5-13 5l-8-5",
			fill: "#af955f"
		}),
		/* @__PURE__ */ m("path", {
			d: "m17 129 8-2m-6 5 7-2m89-48 4 5m1 0 3 2m-6-10 1 3",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 29 27 20l3 13-16-2 11 12-18 5 14 6-13 11 15 1-8 16 17-5-3 16 16-8 4 13 13-12 11 6 7-12 11 3-1-13 15-8-14-4 17-12-20-1 10-15-18 5 0-16-12 12-9-16-5 16Z",
			fill: "#72904d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m29 34-16-20-9-3m18 13 8-9m9 14 0-19-8-7m7 15 10-6m30 15 10-17 18-3m-14 10 17 4m-8-5 13-9m-83 45-20 3-6-3m22 10-14 6m70-20 23-5 13-11m-21 14 13 5",
			fill: "none",
			stroke: "#514f33"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 43q13-13 29-3l7 11 20 1q11 1 7 8-1 4-7 3l-22-1q-1 11-7 18l-22-5q-8-3-11-16Z",
			fill: "#8da65d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M32 42q14-3 28 3l-20 5 7 4-19 8 14-3-8 10 14-4-7 12 12-7-6 15-4-8-14 5 3-13-13 8 6-13-10 2 11-13-7-4Z",
			fill: "#587543",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 48q-6 11 4 18l8 6-10-3-6-10m39-15 4 9 15 2-20 2-4-8",
			fill: "#70894d",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M38 100q-5 13 0 23l8-4 6 8-3-17m28-15 7 7-1 16-8-5m-18 10-9 15-4 8 4 7 7-12 8-13m18 0 3 12-6 13 9 2-2-6 5-13Z",
			fill: "#344c35",
			stroke: "none"
		}),
		/* @__PURE__ */ m(W, {
			x: 55,
			y: 49,
			r: 6.2
		}),
		/* @__PURE__ */ m(W, {
			x: 77,
			y: 45,
			r: 5.2
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 65q10-8 22 0l19-3 7 8q-19 21-38 10-11-6-10-15Z",
			fill: "#b89961"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 66q17 10 36-1-7 17-26 12Z",
			fill: "#343b2c"
		}),
		/* @__PURE__ */ m("path", {
			d: "m53 67 5 7 5-5 4 6 4-6 6 4 3-7m-18 12 2-5 5 5 5-5",
			fill: "#dedab7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M58 75q11-7 17 1l-4 4-11-2Z",
			fill: "#809baf"
		}),
		/* @__PURE__ */ m("path", {
			d: "m35 39 13 4m-17 1 10 4m-23 6 22-3m-17 12 18-9m-19 20 22-14m-13 17 15-10m-8 18 12-13m0 21 6-13m10 8 0-7m-7-43-13-11m16 11-5-14m13 15 1-12m4 14 9-12m-45 70 5 5m-7-1 5 6m-8-1 5 5m-7 2 5 4m13-10 5 9m2-7 5 6m-2-13 5 6m-43 18 3 1m3-5 2 2m30-55 6-3m19-4 5-2",
			fill: "none",
			stroke: "#344e36",
			strokeWidth: ".9"
		})
	] });
}
//#endregion
//#region src/games/pilgrims/village-companions.tsx
function G({ x: e, y: t, r: n = 3 }) {
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("ellipse", {
		cx: e,
		cy: t,
		rx: n,
		ry: n * 1.15,
		fill: "#f2eace"
	}), /* @__PURE__ */ m("ellipse", {
		cx: e + .6,
		cy: t,
		rx: n * .4,
		ry: n * .6,
		fill: "#303a2e",
		stroke: "none"
	})] });
}
function Ht({ x: e, y: t }) {
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("circle", {
			cx: e,
			cy: t,
			r: "13",
			fill: "#8d7750"
		}),
		/* @__PURE__ */ m("circle", {
			cx: e,
			cy: t,
			r: "10",
			fill: "#bdb18a"
		}),
		[
			0,
			45,
			90,
			135
		].map((n) => /* @__PURE__ */ m("path", {
			d: `M${e - 10} ${t}h20`,
			transform: `rotate(${n} ${e} ${t})`,
			fill: "none"
		}, n)),
		/* @__PURE__ */ m("circle", {
			cx: e,
			cy: t,
			r: "2",
			fill: "#665a3e"
		})
	] });
}
function Ut() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M46 110q-5 14-4 30 1 8-5 17 1 4 8 4 6-3 8-12l6-25M68 113q-2 22 7 39 3 7 8 7l4-6q-11-15-11-29v-11",
			fill: "#9f8156"
		}),
		/* @__PURE__ */ m("path", {
			d: "M38 154q-8 2-9 8 7 6 21 2l1-8-6 1m31-6q-7 6-2 11 11 5 19-2l-2-5-8 2Z",
			fill: "#47554a"
		}),
		/* @__PURE__ */ m("path", {
			d: "m47 126-1 16m8-22-2 14m17-10 4 16m-26 9 3 1m28-5 3-1m-39-32 14 4m9-2 7-3",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 64q-12 11-10 33l-3 20q18 9 45 2l6-19-9-35Z",
			fill: "#d9ddca"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 66q-8 14-8 29l-3 25 13 2 7-43m14-14-9 14 6 41 15-3-8-48",
			fill: "#5c7d76"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 71q5 16 10 30m11-28-2 24M46 101l-4 11m27-12 8 8",
			fill: "none",
			stroke: "#90afa2"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 73q-18 12-12 27l20 0 0-7-11-1 3-11M74 75q11 14 20 6l5-12 6 2q-2 20-17 23l-13-6",
			fill: "#d5dcc8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 95q-3-7 1-12 2-3 4-1l-1 8 5-9q4-3 4 1l-3 9 6-4q4 0 2 3-2 6-7 10l-11-1m53-29q-3-3-2-7 1-5 6-5l3 2q-5-1-5 3l4 1q3 4-1 9l-5 1",
			fill: "#c6ac77"
		}),
		/* @__PURE__ */ m("path", {
			d: "m48 95 6-2m-2 4 4-2m42-30 5 1m-5 2 4 1",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 31q14-12 29-1 5 7 2 15 11 2 9 8-1 8-13 6-1 11-4 13-12 3-18-5-8-11-9-23Z",
			fill: "#cbb181"
		}),
		/* @__PURE__ */ m("path", {
			d: "M35 32q-9 3-7 7l4 8-7 5q3 4 11 0l-1 8q5 3 10-3l0-16m27-10q8 4 5 9l-5 6 7 3-9 5",
			fill: "#b09a60"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 40q-4 16 9 25l9 5-9-1q-11-6-12-16m35-19 1 11 6 6-8 2-5-7Z",
			fill: "#b89a69",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M37 86q-4 12-4 27l7 5 4-27m24 1 4 23 7-1-4-20m-32 35-2 17 5 4 5-19m20-6 7 19 4 7-7-22Z",
			fill: "#547169",
			stroke: "none"
		}),
		/* @__PURE__ */ m(G, {
			x: 51,
			y: 42,
			r: 4.4
		}),
		/* @__PURE__ */ m(G, {
			x: 69,
			y: 39,
			r: 3.7
		}),
		/* @__PURE__ */ m("path", {
			d: "m57 43-3 10 10 0M48 58q8 7 17-1m-24-20 7-4m16-3 7 1",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M26 28q2-5 15-4l5-18 15 3 5 14q15-2 17 3-18 14-46 11Z",
			fill: "#5f8190"
		}),
		/* @__PURE__ */ m("path", {
			d: "m46 10 5 6 10 1m-17 6q11 5 21 0m-34 7q19 6 40-1m-25-14-3 8",
			fill: "none",
			stroke: "#354f56"
		}),
		/* @__PURE__ */ m("path", {
			d: "M97 162q0-40 8-81l6-45 6-9 7 2-1 9-7 2-3-4m-5 15-6-8-3 1 7 12",
			fill: "none",
			stroke: "#68593d",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 71q-11 16-13 33m2 0 11 2-1 18-10 8-14-6-1-14 8-10Z",
			fill: "#9e7a4d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M15 112q7 7 22-1m-20 5 4 5 9 0 5-6m-13 2 4 1m-10-13 10-2",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M87 112q-8-4-5-11-2-5 3-8 0-7 7-4 4-9 11-4 8-5 12 3 7 0 6 8 8 5 1 11 4 5-1 10 2 8-6 8-5 8-12 3-8 5-12-2-7 0-5-7-7-2 1-7Z",
			fill: "#cbd0b8"
		}),
		/* @__PURE__ */ m("path", {
			d: "m92 123-1 18-5 8 5 3 7-4 3-20m10-2 0 15 6 5 0 5 7-2-1-6-6-10 2-11",
			fill: "#abbba8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M106 94q-6-8 1-12 6-2 10 4l0 8 7 4-2 8-11 2-9-8Z",
			fill: "#9faf9c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M108 87q-7-6-9-1l2 11 7-4m9 4 4 0",
			fill: "none"
		}),
		/* @__PURE__ */ m(G, {
			x: 113,
			y: 93,
			r: 2.7
		}),
		/* @__PURE__ */ m("path", {
			d: "m91 99 3 4m-6 2 3 4m8-17 3 3m-8 16 4 3m3-5 4 4m0 7 5 0m-19 10 6 2m15-3 6-1",
			fill: "none",
			stroke: "#6d8270"
		})
	] });
}
function Wt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M37 110q-8 13-8 29l-9 8 1 7 13 0 8-7 6-30m7-3q-1 18 7 31l9 5 6-3-6-8-7-23",
			fill: "#78808a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M23 147q-7-1-9 4l4 7 16-2 1-6m31-8q-6 6-1 10l13 1 2-5-7-1",
			fill: "#4b4c3d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M37 74q-12 8-13 24l4 19 23 6 16-12-4-32Z",
			fill: "#8c7658"
		}),
		/* @__PURE__ */ m("path", {
			d: "M34 76q-12 7-14 20l5 11 20-8-3-6-12 4 8-16M54 80q17-8 14-27l5-3q8 24-11 36",
			fill: "#e2dec5"
		}),
		/* @__PURE__ */ m("path", {
			d: "M34 37q12-9 24 2 3 7-1 12 14-1 14 6 0 9-16 8-1 10-6 12l-12-6q-10-9-10-15l-2-11Z",
			fill: "#c4a372"
		}),
		/* @__PURE__ */ m("path", {
			d: "M29 43q-9-6-13 1-2 8 10 9m29-15 7-3q7 2 3 9l-7 3",
			fill: "#bc9a68"
		}),
		/* @__PURE__ */ m("path", {
			d: "M27 45q-2 17 13 25l10 1-12 2-10-12-4-13m30-8 3 11 8 4-11 4-4-6Z",
			fill: "#a98b5e",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M26 88q-4 13 2 27l9 3-3-20m21-15 6 26-8 9 12-8-2-28",
			fill: "#6e5e49",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "m71 105 0 27 4-1 0-27m48-8 7-1-1 42-6 2Z",
			fill: "#46705f",
			stroke: "none"
		}),
		/* @__PURE__ */ m(G, {
			x: 36,
			y: 48,
			r: 5
		}),
		/* @__PURE__ */ m(G, {
			x: 55,
			y: 43,
			r: 3.8
		}),
		/* @__PURE__ */ m("path", {
			d: "m41 48-4 9 10 0M30 59q15 12 28-1l-3 11q-16 5-25-10Z",
			fill: "#483f2e"
		}),
		/* @__PURE__ */ m("path", {
			d: "m33 62 5 5 4-3 5 4 5-4m-17-26 8-4m5-4 7 0",
			fill: "#dfd2a4"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 57q5-8 10-4l8 1-4 5-8 0-5 4-4-3Z",
			fill: "#634b34"
		}),
		/* @__PURE__ */ m("path", {
			d: "M32 33q3-15 14-14l11 7-7 9m-19-6q3 1 6 0m9-8-1 7",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "m33 72 9 5 10-7 4 10-10-1-5 9-3-9-10 0Z",
			fill: "#ad7450"
		}),
		/* @__PURE__ */ m("path", {
			d: "M67 53q-4-4 0-8l4-1 6 4-3 8m-33 41q-2-6 3-7l6 2 0 6-6 3",
			fill: "#c1a26e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M65 44q-11-11-6-22 10-9 22 1 10 13-4 25Z",
			fill: "#b67953"
		}),
		/* @__PURE__ */ m("path", {
			d: "M65 26q13-9 18 5l-9 8-7-2 8-9m-13 4 7 8m-4 0 8 4",
			fill: "none",
			stroke: "#674c35"
		}),
		/* @__PURE__ */ m("path", {
			d: "M55 89 121 81l13 10-68 11Z",
			fill: "#86a794"
		}),
		/* @__PURE__ */ m("path", {
			d: "M65 102 134 91l-2 51-64 13Z",
			fill: "#628d7c"
		}),
		/* @__PURE__ */ m("path", {
			d: "m70 107 53-9-1 30-51 10Z",
			fill: "#344e46"
		}),
		/* @__PURE__ */ m("path", {
			d: "m75 110 44-7m-44 19 44-8m-45 11 44-7",
			fill: "none",
			stroke: "#a8b8a2"
		}),
		Array.from({ length: 9 }, (e, t) => /* @__PURE__ */ m("path", {
			d: `m${76 + t * 4.6} ${111 - t * .8} 0 8m0 4v8`,
			fill: "none",
			stroke: "#beafb1",
			strokeWidth: "2"
		}, t)),
		/* @__PURE__ */ m("path", {
			d: "M67 144 128 132l10 9-65 14Zm-5-39 0 39m-4-34 0 29m-4-24 0 20m72-33 3 27m-5-18 7-1m-5 8 6-1",
			fill: "#8e7950"
		}),
		/* @__PURE__ */ m(Ht, {
			x: 78,
			y: 149
		}),
		/* @__PURE__ */ m(Ht, {
			x: 121,
			y: 141
		}),
		/* @__PURE__ */ m("path", {
			d: "M109 87q-11-15 1-24l6 3-4 9 7-3 3 6-8 9Z",
			fill: "#ae945b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M114 65q-2-24 10-30 15 4 16 19l-9 18Z",
			fill: "#c4a063"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "128",
			cy: "52",
			rx: "10",
			ry: "15",
			transform: "rotate(-26 128 52)",
			fill: "#7c6846"
		}),
		/* @__PURE__ */ m("path", {
			d: "m121 41 10 19m-12-15 9 17m-8-11 6 12m-5-26 4 3m-2 34 9-1m9-36 5 2m-4 15 7 1",
			fill: "none"
		})
	] });
}
function Gt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M49 125q-3 16-10 24l-7 10 6 5 13-4 7-29M76 128q1 14 6 23l16 7 9-5-2-4-12 1-8-24",
			fill: "#615d44"
		}),
		/* @__PURE__ */ m("path", {
			d: "m43 146 10 2m-12 2 10 2m-13 2 10 3m32-13 8-2m-7 6 9-2m-6 7 8 0m-54 6 9 0m44-4 8 0",
			fill: "none",
			stroke: "#b2a17a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 61q-14 6-15 21l5 16 48 4 14-12q-1-25-18-31Z",
			fill: "#6b8790"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 61 38 81l-1 18-7 31q27 17 62 0l-9-35-4-32-8-2 0 19-23 0 1-18Z",
			fill: "#a67c4a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 101q3 13-4 27l16 6 8-7 21 1M46 114l29-2m-24 5 16 0m-23 8 9 2",
			fill: "none",
			stroke: "#c69e67"
		}),
		/* @__PURE__ */ m("path", {
			d: "M33 77q-13 16-1 27 13 9 31-2l14-12-5-7-23 15-7-6m39-16q13 7 14 18-4 14-32 14l-12-8 24-5-5-9",
			fill: "#c5a570"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 96q8-11 16-12l9-7 4 1-2 7 5-4 3 2-6 10-17 8m4-1-11 1-9 5",
			fill: "#c9ae79"
		}),
		/* @__PURE__ */ m("path", {
			d: "m35 81 3 6m-9-2 3 5m4-1 3 5m-8 2 6 4m46-17 2 6m4 0 2 5m-8-2 2 6m-6-4 1 6M40 94l-5-5-5 0 3 6 6 3Z",
			fill: "#a8684d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 31q13-10 25-1 5 5 6 14l-3 14q-4 10-12 13-10-2-17-9-7-7-7-15Z",
			fill: "#c7aa78"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 40q-1 14 10 23l10 4-12-1-10-13m33-18 4 9-3 14-6 5 2-20Z",
			fill: "#ac8d61",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M31 81q-4 13 7 18 11 5 24-3l-5 9q-15 7-25-1-8-8-4-18m51-7q8 5 11 14-1 7-20 9l-10 3 15 2q16-1 20-13-1-7-9-14",
			fill: "#ae8d5e",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 103q-3 14-6 24l8 5 6-4-3-23m34-3 8 25-8 3-6-23m-33-26 3-19 4 0-3 19",
			fill: "#8d643d",
			stroke: "none"
		}),
		/* @__PURE__ */ m(G, {
			x: 54,
			y: 43,
			r: 3.3
		}),
		/* @__PURE__ */ m(G, {
			x: 72,
			y: 40,
			r: 3
		}),
		/* @__PURE__ */ m("path", {
			d: "m61 44-3 10 12-2m-17 7q8 4 15-2m-18-21 9-2m7-1 9 0",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 40q-13-20 6-25l16-5 21 8-1 13 6 11-14-9-3-12-1 16-12-14-3 10-9-9-1 18-6-9Z",
			fill: "#3d473d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 17q-7-5-5-11l14-2 5 6-2 6",
			fill: "#526157"
		}),
		/* @__PURE__ */ m("path", {
			d: "m42 8 12-2m-8 12-4 14m10-16 4 7m3-11 8 11m-5-10 12 14m1-10 5 10M40 114l-5 6-4 24-7 2-2-4 4-5 3-19 7-9",
			fill: "none",
			stroke: "#849084"
		}),
		/* @__PURE__ */ m("path", {
			d: "m81 109 10-5 5 6-2 6-12 4-8-3-2-5Z",
			fill: "#9aa8a0"
		}),
		/* @__PURE__ */ m("path", {
			d: "m76 109 7 5 12-4m-12 4-1 6m6-14 5 2m-9 8 6-2",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M32 113q12-7 18 0l-2 5-11 2-9 16-4-2 9-14Z",
			fill: "#737f75"
		})
	] });
}
function Kt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M51 127q-1 14-9 24-4 5-2 7l5 2q10-7 15-16l5-13m15-2q-3 7-7 15-3 6 0 8l13 4 6-5q-5-4-11-7 5-5 8-12",
			fill: "#d4d4bc"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 153q-9 2-10 9l6 5 13-3 5-8-4-3-8 5m32-9q-6 6-1 11l15 1 8-6-3-4-9 5-5-5",
			fill: "#3c4940"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 81q-12 15-12 43 16 10 33 10 13-1 23-9-5-24-9-43Z",
			fill: "#5b647e"
		}),
		/* @__PURE__ */ m("path", {
			d: "m41 101-5 21m11-17-4 19m9-19-2 22m11-22 0 22m8-23 4 22m3-25 9 23M43 93l33-1-1 9-33 2Z",
			fill: "#8b7650"
		}),
		/* @__PURE__ */ m("path", {
			d: "m56 94 11-1 1 7-11 1Z",
			fill: "#c4ae68"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 75q-8 4-11 18l-7 10-6-1-2 6q12 9 20-1l10-15M77 78q7 2 9 14l17-5 4 6-22 12-9-9",
			fill: "#dcdcc5"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 39q11-9 25 2 3 5 0 13 13-2 16 10 4 10-2 11-3 0-5-6l-7-8q-3 9-9 10-12 0-17-6-9-6-8-15Z",
			fill: "#c5aa7b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 35q-12 3-10 15l-5 6 11 2 6-9m25-13 10 2-1 12-7 2",
			fill: "#62604b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 44q-2 14 8 19l7 5-11-3-7-15m30-2 1 7 11 8-9-2-5-7Z",
			fill: "#a88e61",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M38 102q-5 11-4 21l9 3 6-22m23-1 9 21 5-1-7-21m-38-17-6 17 7-6",
			fill: "#414c65",
			stroke: "none"
		}),
		/* @__PURE__ */ m(G, {
			x: 53,
			y: 47,
			r: 4.8
		}),
		/* @__PURE__ */ m(G, {
			x: 73,
			y: 46,
			r: 3.8
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 41q-5-6 6-7l13 2-2 5m6-2 9-7 4 4-5 6M54 54l-3 8 12-3m-16 5q9-4 15 1l9-5 7 2-4 7-10 0-6 5-13-3Z",
			fill: "#474e3c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 65q13 10 30 5l9 5-5 14-22 4-18-11-1-11Z",
			fill: "#dfdecd"
		}),
		/* @__PURE__ */ m("path", {
			d: "m39 72 9 13m-3-15 9 18m-2-16 7 17m0-15 6 15m2-15 4 12m3-12 3 8M44 80l2 7m5-1 3 5m6-3 2 4m7-5 3 3",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M34 34q3-7 15-7l1-22q12-5 23 1l0 22 12 3q-4 14-30 12-15 0-21-9Z",
			fill: "#5d6978"
		}),
		/* @__PURE__ */ m("path", {
			d: "M52 7q9 4 18 0m-18 5 0 14m5-13 0 15m5-14 0 15m5-15 1 14M39 34q17 8 37-1",
			fill: "none",
			stroke: "#a1b1ae"
		}),
		/* @__PURE__ */ m("path", {
			d: "M104 88q-1-8 6-12l3 0-3 8 7-7 4 0-7 9 4 1-2 5-10 2M23 104q-4-6-7-3l-2 7 5 4 5-4",
			fill: "#c7ae79"
		}),
		/* @__PURE__ */ m("path", {
			d: "M17 108q-12 10-8 21 12 6 19-6l-3-15Z",
			fill: "#c2a05d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m16 110 8 1m-10 4-3 9m9-5 2 3",
			fill: "none"
		})
	] });
}
function qt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M51 122q-14 4-23 19-5 8-8 16 0 4 8 4 6-5 11-14 13-9 25-12M78 123q8 9 20 14 8-1 15-6l4 5q-1 6-7 10-7 3-13 0-15-4-25-10",
			fill: "#566f81"
		}),
		/* @__PURE__ */ m("path", {
			d: "m43 137 14-4m-28 18 4 2m50-18 13 6m6 0 7-3",
			fill: "none",
			stroke: "#91a3a2"
		}),
		/* @__PURE__ */ m("path", {
			d: "M21 154q-7 6-5 12l6 0 4-4 9 2 5-4-1-5-10 3-4-4m85-23q-1-7 5-8 7 3 5 10l-9 9-6-1 2-5",
			fill: "#403f32"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 65q-20 10-19 36 0 24 22 31 26 5 46-11 11-24-8-48Z",
			fill: "#b4b8ab"
		}),
		/* @__PURE__ */ m("path", {
			d: "M36 80q-7 26 6 44m-9-37 15 3m-15 5 16 2m-15 6 17 2m-15 6 16 2m-13 6 15 1M71 81l6 46m-38-13 12-2 1 10-11 2m36-14 11-4 0 9-9 3",
			fill: "none",
			stroke: "#6a8176"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 66q7 9 19 11l-6 8-12-7-6-10m25 8 15-8 6 5-15 11Z",
			fill: "#e5e0c7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M36 77q-18 12-17 35l-10 12 6 4q17-11 18-28l9-13M85 78q7 7 17-2l6-12 6 3q1 23-21 24l-6-5",
			fill: "#9daaa0"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 29q21-12 33 4 5 7 3 12 13-5 19 1 7 8 0 13-4 3-12 2l-8 0q4 13-10 16-18 5-27-8-8-12-4-20Z",
			fill: "#ccac78"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 32q-9-1-11 9l3 22-5-4-1-22 8-14 11 2M42 26l-6-13 5 1 8 10 4-10 5 9 12-5 4 10",
			fill: "#5a5b46"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 36q-4 12 3 24 3 9 13 11l9 2q-17 6-24-4-8-12-4-20m37-13 5 9 9 3-9 7-8-6Z",
			fill: "#b79564",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M31 86q-5 23 8 36l9 4 6 1q-10-6-15-15l-3-28m47 10q8 15 3 25l5-1 4-11-7-15M24 147l7-8 9-5-7 13-6 10m62-28 9 8 9-2-6 7-11-7",
			fill: "#8e9d92",
			stroke: "none"
		}),
		/* @__PURE__ */ m(G, {
			x: 51,
			y: 43,
			r: 4.2
		}),
		/* @__PURE__ */ m(G, {
			x: 75,
			y: 40,
			r: 3.3
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 57q15 9 27-2-2 9-8 13-12 5-19-11Z",
			fill: "#484630"
		}),
		/* @__PURE__ */ m("path", {
			d: "m53 59 2 6m5-5 0 7m5-7 0 6m5-8 0 6m-15 8q8 3 16-1M43 36l8-4m18-4 8 4m-38 20-3 6m4 2-3 6m5-3-2 5M65 51l5 4",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M107 67q-1-7 3-9 4-2 7 2l0 9q-1 4-6 4M16 121q-5-7-9-3-4 2-2 6l1 5q2 4 6 3l7-8",
			fill: "#caae79"
		}),
		/* @__PURE__ */ h("g", {
			fill: "#ad774c",
			stroke: "#765039",
			strokeWidth: ".9",
			children: [
				/* @__PURE__ */ m("path", { d: "M-4 134c4-6 11-9 14-5 4 5-5 12-11 13-6 1-7-4-3-8Z" }),
				/* @__PURE__ */ m("path", {
					d: "M-6 140q-3-1-4 1l1 4 4-1m13-12 3-5 3 3-4 5",
					fill: "#d1aa72"
				}),
				/* @__PURE__ */ m("path", { d: "M17 137c4-1 8 6 8 12-1 6-6 8-10 3-3-5-4-12 2-15Z" }),
				/* @__PURE__ */ m("path", {
					d: "m16 138-2-4 4-1 1 4m3 14 3 4-3 2-3-3",
					fill: "#d1aa72"
				}),
				/* @__PURE__ */ m("path", { d: "M18 157c6 1 2 9-4 13-5 4-11 3-11-2-1-4 8-12 15-11Z" }),
				/* @__PURE__ */ m("path", {
					d: "m17 157 3-2 3 2-3 3m-13 9-4 3-2-3 2-3",
					fill: "#d1aa72"
				}),
				/* @__PURE__ */ m("path", {
					d: "M-2 135q5-5 8-4m10 9q3-1 5 8m-13 18q3-5 8-6",
					fill: "none",
					stroke: "#c99663"
				})
			]
		}),
		/* @__PURE__ */ m("path", {
			d: "M6 123q-2 6 2 7 4 2 5-2l0-5m-6 3 5 1m-5-4 4 1m-2-4 3 1",
			fill: "#caae79",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M107 51 129 45l2 27q-5 10-21 6Z",
			fill: "#c3a158"
		}),
		/* @__PURE__ */ m("path", {
			d: "m128 50 9-1q8 16-6 21m-17-14 2 16m5-18 2 16m-15-19 22-6",
			fill: "none",
			stroke: "#78663e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M105 51q-10-5-3-12 1-8 12-6 4-7 12-2 11-1 12 6l-9 8Z",
			fill: "#e9e4cb"
		}),
		/* @__PURE__ */ m("path", {
			d: "m102 34-6-4m29-5 5-4m10 20 6 1m-34-8 0-2",
			fill: "none",
			stroke: "#a47b4d",
			strokeWidth: "1.2"
		})
	] });
}
function Jt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M49 111q-4 16-13 29l-6 12q1 5 9 5 10-6 15-19l6-20M73 110q18-2 18 11-1 9-8 15l10 7 5-4-6-9 10-15-21-12",
			fill: "#568798"
		}),
		/* @__PURE__ */ m("path", {
			d: "m74 112 12 2-6 10 5 10 9 3-2-9 9-14-19-9M48 121l-8 15 8 4 9-16",
			fill: "#b76f4e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M32 150q-11 0-11 11 6 11 23 10l9-7 0-6-5 0q-1 10-12 4l4-8m43-19q-9 7-2 16 12 11 24 5 6-7 3-12l-4 0q-1 9-11 4l-1-9Z",
			fill: "#4b4d3d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m30 153-2 7m5-4 0 8m53-26-1 7m5-4 1 7",
			fill: "none",
			stroke: "#b1a57c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 69q-8 13-7 29l-8 11 14 1 4 8 11-7 10 7 8-11 12 2-7-20-4-20Z",
			fill: "#537e8a"
		}),
		/* @__PURE__ */ m("path", {
			d: "m43 75-4 22 9 8 11-8-4-22m-3 28 0 7m20-33 4 15-7 11m-31-5 42-2",
			fill: "#b47652"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 75q-16 5-19 20l16 7 4-6-11-5 14-8M74 76q12 13 22 3l7-12 5 3q-1 24-18 24l-13-9",
			fill: "#568599"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 35q13-14 29-5 7 5 3 15 12-3 16 3 5 8-3 10l-13 0q-2 11-9 14-9 3-17-7-8-8-10-13Z",
			fill: "#d1b680"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 42q-2 13 9 22l9 5-11-4-8-13m31-17 3 10 10 5-10 3-5-10Z",
			fill: "#b79a6b",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M31 94q7 4 12 3l-2 4-12-5m43-17 9 11 8 1 8-5-8 8-12-9m-39 15-5 9 8 0 5 6-1-12m-3 34-7 13 6 3 9-13m39-25 9 2-7 11-6-6",
			fill: "#3b6377",
			stroke: "none"
		}),
		/* @__PURE__ */ m(G, {
			x: 53,
			y: 44,
			r: 4.7
		}),
		/* @__PURE__ */ m(G, {
			x: 74,
			y: 40,
			r: 3.8
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 58q16 8 32-2l-6 10-18 0Z",
			fill: "#e5d8ac"
		}),
		/* @__PURE__ */ m("path", {
			d: "m57 36 7-4m4-3 9 2m-13 11-4 11 11-3M41 29q12-15 28-7l6 8-12-4-8 6-5-4-7 7",
			fill: "#c7ae69"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 37q-1-26-14-25-9 2-12 16l-5-2q2-24 21-24l18 17 13-8Q77-8 91 5l7 13-7 4Q84 9 77 15L64 32 52 24 47 37Z",
			fill: "#4c8294"
		}),
		/* @__PURE__ */ m("path", {
			d: "M59 13Q78-8 91 5l7 13-7 4Q84 9 77 15L64 32Z",
			fill: "#ba7851"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 64q14 9 35 1l8 8-18 1-5 12-6-10-16-2-10 5 2-9Z",
			fill: "#b67350"
		}),
		/* @__PURE__ */ h("g", {
			fill: "#cdb573",
			children: [
				/* @__PURE__ */ m("circle", {
					cx: "10",
					cy: "29",
					r: "4"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "94",
					cy: "22",
					r: "4"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "30",
					cy: "77",
					r: "3"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "84",
					cy: "75",
					r: "3"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "44",
					cy: "113",
					r: "3"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "67",
					cy: "119",
					r: "3"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "86",
					cy: "110",
					r: "3"
				})
			]
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 96q-7-5-10 1l3 8 8 0m61-27q-3-6 1-10l6 0 3 6-5 8",
			fill: "#cbb17d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m105 77 5-28 3-1-4 30",
			fill: "#93774d"
		}),
		/* @__PURE__ */ h("g", {
			transform: "translate(112 43) scale(.55)",
			children: [
				/* @__PURE__ */ m("path", {
					d: "M-10-15q-9-19-17-11l-3 7-6-2q3-26 23-9l12 5q20-20 26-8l4 13-6 2-9-9-9 10Z",
					fill: "#bb7751"
				}),
				/* @__PURE__ */ m("path", {
					d: "M-13-16q11-8 20 1l4 10 10 4-3 5-12-1-6 9-11-5-6-13Z",
					fill: "#d3bb83"
				}),
				/* @__PURE__ */ m(G, {
					x: 0,
					y: -9,
					r: 3
				}),
				/* @__PURE__ */ m("path", {
					d: "m-10 1 12 5m-33-26-4 1m62-4 3 2",
					fill: "none"
				})
			]
		}),
		/* @__PURE__ */ h("g", {
			transform: "translate(18 117) rotate(25)",
			children: [
				/* @__PURE__ */ m("path", {
					d: "M-2-4q-15-6-17 9-2 7 4 10-7 8-1 16 13 9 21-2 7-8-2-16 9-9 2-15Z",
					fill: "#baa068"
				}),
				/* @__PURE__ */ m("path", {
					d: "M-2 14V-15h5v30m-18 9 19 0M-7 15v12m0-37h12m-12 4h12",
					fill: "none"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "-4",
					cy: "19",
					rx: "3",
					ry: "4",
					fill: "#66563a"
				})
			]
		})
	] });
}
//#endregion
//#region src/games/pilgrims/fable-companions.tsx
function K({ x: e, y: t, r: n = 3 }) {
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("ellipse", {
		cx: e,
		cy: t,
		rx: n,
		ry: n * 1.15,
		fill: "#f3ebcf"
	}), /* @__PURE__ */ m("ellipse", {
		cx: e + .6,
		cy: t + .1,
		rx: n * .4,
		ry: n * .63,
		fill: "#30382c",
		stroke: "none"
	})] });
}
function Yt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M58 137q17-5 31-13 12-3 25 0l3 22q-18 14-54 17Z",
			fill: "#92724a"
		}),
		/* @__PURE__ */ m("path", {
			d: "m64 140 25-11 22 0m-42 8 20-4m-19 9 26-8m-18 14 21-9m-16 13 20-9m-10 9 14-6m-13 11 11-7m-7 5 2 8m13-35 5 8m-23-5 4-6",
			fill: "none",
			stroke: "#c4a46d"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "63",
			cy: "151",
			rx: "12",
			ry: "19",
			transform: "rotate(19 63 151)",
			fill: "#c7ac71"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "63",
			cy: "151",
			rx: "8",
			ry: "15",
			transform: "rotate(19 63 151)",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M61 162q-10-10 1-22 9-6 8 8-1 12-6 10-5-4 0-12m48 0 3 13 4 0-1-15",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 106q-7 13-8 26l-9 15q0 6 6 7 9-8 13-19l10-21m18-10q12 0 18 11 2 5-9 15l-10-3q4-6 5-12-6-4-15-2",
			fill: "#926f47"
		}),
		/* @__PURE__ */ m("path", {
			d: "M32 145q-10 2-10 8l8 8q9 0 16-4l1-5-10-1m41-25q-2 10-10 15l1 6q10 6 20-1l3-6-5 0-7 2 6-13",
			fill: "#496b50"
		}),
		/* @__PURE__ */ m("path", {
			d: "m46 125 8 3m-6-2-3 9m36-10 8 1m-46 13-4-3m43 9 4-2",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 61q-14 9-14 30l-5 18q13 10 29 8 16-1 26-11-3-17-1-31L69 57q-9 9-15 8Z",
			fill: "#60824f"
		}),
		/* @__PURE__ */ m("path", {
			d: "m44 74-7 24 11 9m8-30 1 21m10-21 5 20m-38 7q18 8 37-3M41 87l6 2m20-2 8-2",
			fill: "none",
			stroke: "#9eb07a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 64q-15 1-23 14-8 14 2 21 16 5 29-9l-5-6-16 7-2-4 16-14M78 66q17 1 21 18l-11 17-9-5 9-14-11-7",
			fill: "#c3a16b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 83q2-6 6-8 4-3 5 2l-3 6 8-3q5-1 3 2-3 6-9 11l-8 1M87 95q-3-7-7-5-4 1-3 6l6 7q5 1 8-3",
			fill: "#c3a774"
		}),
		/* @__PURE__ */ m("path", {
			d: "m50 90 7-5m-5 7 6-4m22 6 4 4m-4-1 2 3",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 27q-3-15 14-18 18-3 19 13l-3 15q8 4 18 2 5 7-2 11l-11 4q-4 15-15 17-15-4-22-16l-5-15Z",
			fill: "#cdb17a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 33q-4 14 5 23l8 6-11-6-6-14m36-20q5 11-1 17 9 4 18 2l-3 6-14 1-6-6Z",
			fill: "#ae9261",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M32 82q-7 14 2 16 9 2 16-4-9 12-23 7-11-6-4-19m16 24q12 8 30 1l10-9-2 10q-14 11-29 9l-11-6m5 12-3 10-7 15 5 4 10-18 7-15m35-6 5 3-11 13-5-2 6-12",
			fill: "#496840",
			stroke: "none"
		}),
		/* @__PURE__ */ m(K, {
			x: 54,
			y: 37,
			r: 3.5
		}),
		/* @__PURE__ */ m(K, {
			x: 73,
			y: 34,
			r: 3
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 49q8 7 16 0l9 4q19 5 36-2-4 9-14 12l16 0q-10 10-31 8l-6 7-8-5-8 7q-6-6-9-8l-9 1 4-10-7-4Z",
			fill: "#bdc7b3"
		}),
		/* @__PURE__ */ m("path", {
			d: "m43 57q3 8 8 12m-3-13 7 15m3-14 6 14m2-13 8 7m3-4 13 2M44 25q-8 3-10 13l6 11 5-7m-4-15q2-10 10-12m4 9q4-7 10-2m7 0q7-6 11 0",
			fill: "#a29c72"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 20q9-11 19-7m-16 6 12-3m-13 10-6-2m11 5 7-4m9-5 7 2m-34 11-7 1 0 7 7 5",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "m34 34-28-3 0 5 28 5 17 35 4-2Z",
			fill: "#6b563b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M5 24q9-8 19-7l4 23q-10-5-19-1Z",
			fill: "#8c9e97"
		}),
		/* @__PURE__ */ m("path", {
			d: "m7 26 16-6m-11 8 3 11m1-12 3 13m-8-10 3 8m-6-9 3 8M24 90l4 3m-2-10 3 3m6-9 3 4m59 0-5 2m2 4-4 1m-11 9 1 4M43 110l10 3m-2-11 4 6",
			fill: "none"
		})
	] });
}
function Xt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M48 116q-8 13-17 20-4 4-1 8 6 8 12 14l12 7q4 2 4-3l-6-6 7 1q3-1 1-4l-15-8-2-6 18-15M79 119q11 4 13 13-2 8-11 16 8 6 13 3l11-2q8 3 3 7-18 4-27 2l-12-4q-3-7 9-19l-13-10",
			fill: "#bd7950"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 97q-20 13-27 5l-8-17-3 3q-4 22 14 28l27-7",
			fill: "none",
			stroke: "#a46540",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ m("path", {
			d: "m7 87-3-8-4-6 1 11-7-3 5 9Z",
			fill: "#9c7247"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 66q-14 10-14 29l-3 19q18 18 40 12l15-16-4-32-17-14Z",
			fill: "#bd784c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 73q-9 9-8 24 3 18 18 25 14 0 19-14l-5-30Z",
			fill: "#d49e58"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 77q-11-2-16 12l-4 7 13 12 26-6-1-7-25 3-2-3 10-10M77 78q18-11 20-31l7 0q2 24-20 43",
			fill: "#c28050"
		}),
		/* @__PURE__ */ m("path", {
			d: "M63 97q-3-5 1-7 3-2 7 2l2 2v7q-3 4-9 4m32-56q-3-7 0-10 4-3 7 1v6l4-5q4-2 4 2-1 6-5 10l-6 0",
			fill: "#cba06a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 36q-14-4-16-16l-2-11 7 2 11 14m29 1q11-11 6-21l4-3q13 10 0 27",
			fill: "#b99563"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 28q13-9 25 0 7 8 5 18 9 2 20 8 9 5 3 10-8 5-24-3-4 12-10 13-10 2-16-4-9-6-10-17l-4-15Z",
			fill: "#c4804f"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 41q-2 19 15 29l-6 0q-9-6-10-17l-4-15m9 40q-11 9-9 24l7 6-6 7q-7-7-7-15 1-17 12-24m41 8q7-5 13-16l-5 15-8 7m-6 45 7 4-7 10q-10 12-3 14l16 4-10 1-12-4q-5-7 9-19m-44 4 4 5 11 9-5-1-6-5-7-9Z",
			fill: "#9e623e",
			stroke: "none"
		}),
		/* @__PURE__ */ m(K, {
			x: 52,
			y: 40,
			r: 4.5
		}),
		/* @__PURE__ */ m(K, {
			x: 76,
			y: 42,
			r: 4
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 54q12 7 31 2-3 10-11 14-13 2-20-16Z",
			fill: "#423f2b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m53 59 3 6 4-4 5 6 5-5m-5-29 0-9m-5 8-2-7m-6 7-3-6M44 40l-6-12m3 18-6-9m5 18-5-6m6 35 6 3m-10 7 5 3m2 13 5 3m-13 31 7 4m41-10 5 2m-34 18 0 4m40-5 1 4",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 107q-10 11-4 24 12 15 26 3 6-7 3-15 11-3 12-14 1-12-9-13Z",
			fill: "#c8ab60"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 109q-8 10-4 18 10 10 20 2 5-7 1-11 11-2 13-12l-5-9Z",
			fill: "#aa8545"
		}),
		/* @__PURE__ */ m("path", {
			d: "m63 121 38-73 5 2-36 75M97 47l0-11 11 4 1 9Z",
			fill: "#ba9957"
		}),
		/* @__PURE__ */ m("path", {
			d: "m66 122 36-77m-33 79 35-78m-49 80 16 1m-15 3 15 0m24-91 5 1m-4 5 4 1m6-3 4 2m-2 3 4 2",
			fill: "none",
			stroke: "#e1c88c",
			strokeWidth: ".65"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "63",
			cy: "118",
			rx: "4",
			ry: "6",
			transform: "rotate(25 63 118)",
			fill: "#514d32"
		})
	] });
}
function Zt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M54 115q1 16-4 29 1 4 6 7 5-6 6-16l2-17M73 116q0 14 3 26 2 4 8 5l3-6q-4-12-5-22",
			fill: "#5e7e56"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 142q-4 7-3 14l-5 0q-3-6-6-3-2 9 8 12l16-2 2-6-4-11m20-4q-1 12 2 19 13 7 22-1 4-7 1-11l-4 0q1 9-9 9l-4-13Z",
			fill: "#5e7e8a"
		}),
		/* @__PURE__ */ m("path", {
			d: "m50 147 9 1m18-3 9 1m-36 4 0 10m33-10 0 8m-29-74 2 8",
			fill: "none",
			stroke: "#a6beb3"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 60q-10 16-8 39l-11 25q23 7 39-1l24 2-8-23-3-41Z",
			fill: "#a46a4a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M52 60q-4 23-11 40l-5 17 13 2 13-14m14-40 1 29 10 25-13 1-9-14",
			fill: "#668e98"
		}),
		/* @__PURE__ */ m("path", {
			d: "m51 63 10 12 13-13m-15 14 1 25m6-24-3 24m-13 4-2 10m25-10 4 11m-40 4q21 10 46 0",
			fill: "none",
			stroke: "#bfa76e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 97q16 8 36-1l1 6q-21 7-38 1Z",
			fill: "#584e36"
		}),
		/* @__PURE__ */ m("path", {
			d: "m60 99 8-1 0 6-8 1Z",
			fill: "#c7ad60"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 66q-16 7-16 22l20 8 3-6-13-7 11-11M80 68q9 9 15 0l4-12 6 2q1 22-17 23l-10-6",
			fill: "#d2b680"
		}),
		/* @__PURE__ */ m("path", {
			d: "M52 88q5-3 8 1 3 3-2 8l-7-1m48-40q-5-5-1-9 3-2 5 0 4 3 4 8l-4 7",
			fill: "#d6bb87"
		}),
		/* @__PURE__ */ m("path", {
			d: "m53 92 5 1m-6 1 5 1m42-44 5 1m-4 2 4 1",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 28q14-7 25 3l-1 15q12 1 11 7-1 7-14 4-1 9-7 14-9 2-16-6-7-7-8-16l-3-7Z",
			fill: "#d4b884"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 32q-10 0-16 9l-11 1q7 7 16 4l13-6m-2-4q-11-5-3-16 4-5 12-7l4-8q3 6 10 5l12-2q7 4 4 9-2 10-7 15l-13-4q-4 9-9 9l-8-4-6 7Z",
			fill: "#c3a456"
		}),
		/* @__PURE__ */ m("path", {
			d: "m46 25 16-9m-12 12 18-10m-8 10 15-9m-50 22 14-6M54 42q5 3 10 0m7-4 7-2m-16 7-3 10 9 0m-12 9 8 1",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 60q14 7 17 14l-8 5-13-13m31 8 12-14 4 6-12 13Z",
			fill: "#b77b52"
		}),
		/* @__PURE__ */ m("path", {
			d: "m103 51 5 40m-3-21 7 2m-7-10-8-5m12 16q6-8 11-4-2 6-10 7",
			fill: "none",
			stroke: "#6a8254",
			strokeWidth: "1.6"
		}),
		/* @__PURE__ */ m("path", {
			d: "M103 51q-15-5-14-17l9 4 3-7 8 6 5-5 2 11-7 10Z",
			fill: "#c17c51"
		}),
		/* @__PURE__ */ m("path", {
			d: "m98 39 5 8 6-10m-4 10 8-5",
			fill: "none"
		})
	] });
}
function Qt() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M49 132q-1 11-7 18-4 5-2 8l4 2 11-5q2-9 5-19M74 134q0 9 3 17 3 4 12 6l7-4q-5-5-13-7l-1-14",
			fill: "#474b40"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 154q-10-2-14 7 5 5 21 2l6-7-6-2m27-5q-4 9 2 13l17 2 5-4-11-4-8-8",
			fill: "#554e3c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 84q-15 9-14 31l-7 18 10 4 8-5q3 8 7 8l7-5 7 5q4-1 7-7l10 3q-3-12-5-25l-5-25Z",
			fill: "#586e7c"
		}),
		/* @__PURE__ */ m("path", {
			d: "m44 108-8 23m14-20-6 23m14-22-3 23m9-24 4 22m2-22 5 16m-42-13q19 11 44-3",
			fill: "none",
			stroke: "#9ea8ad"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 75q-15 5-15 23l-9 13 9 5 16-9m28-26q9 15 22 9l3-11 6 2q-2 24-20 20l-9-9",
			fill: "#637987"
		}),
		/* @__PURE__ */ m("path", {
			d: "M25 109q-7-3-10 2-1 4 5 7l9-2 2-5m67-31q-4-6 0-8 4-3 8 0l1 7q-1 5-5 8",
			fill: "#bca578"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 34q17-11 29 2 5 6 1 13 12 1 15 16 5 14-2 14-6-1-7-10l-3-9q-2 3-7 3-1 10-6 13-12 1-16-8-9-7-10-18Z",
			fill: "#c5a978"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 30q-12 14-10 38l-6 13 14 6 9-11-5-22 11-20Z",
			fill: "#5b696c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 36q-11 14-7 37m10-31q-7 15-3 30m-6 3 6 4",
			fill: "none",
			stroke: "#8d9a98"
		}),
		/* @__PURE__ */ m(K, {
			x: 51,
			y: 46,
			r: 5
		}),
		/* @__PURE__ */ m(K, {
			x: 71,
			y: 43,
			r: 4.4
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 38q8 5 15 1m7-1 11-5M46 58q9-7 18 0m-14 2 8 3m-5 4 6 1m2-18-3 7 10-1m-20 16 6 2",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 32q-3-12 16-14 15-4 22 7L57 25 46 36m-7-4-11-11 4-4 10 8 2-15 4-3 0 13-7 12",
			fill: "#617278"
		}),
		/* @__PURE__ */ m("path", {
			d: "M36 76q16 9 28 4l8 6-13 7-7-6-10 5-13-6Z",
			fill: "#a66e53"
		}),
		/* @__PURE__ */ h("g", {
			fill: "#ded5b7",
			children: [
				/* @__PURE__ */ m("circle", {
					cx: "34",
					cy: "83",
					r: "1.3"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "42",
					cy: "84",
					r: "1.3"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "47",
					cy: "81",
					r: "1.3"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "53",
					cy: "88",
					r: "1.3"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "65",
					cy: "85",
					r: "1.3"
				})
			]
		}),
		/* @__PURE__ */ m("path", {
			d: "m102 66-1 54m0-3-4 12",
			fill: "none",
			stroke: "#987e49",
			strokeWidth: "2.6"
		}),
		/* @__PURE__ */ m("path", {
			d: "M96 122q3 16-4 26 11 8 25-1l10-8-14 1-4-19Z",
			fill: "#c5ac65"
		}),
		/* @__PURE__ */ m("path", {
			d: "m99 126-3 19m7-17 0 18m4-14 5 12m-3-18 6 15m-19-22 13 2 0 5-14-2",
			fill: "none"
		})
	] });
}
function $t() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M49 122q-5 13-5 26 2 5 8 7 6-5 8-13l4-18M78 123q-2 12 5 22 4 3 7 1l3-5q-5-9-8-21",
			fill: "#a89c6d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 144q-6 9-4 17l-4 0-2-5-4 2q-2 10 10 11l13-4 2-6-4-11m30-7q-2 15 5 18 15 4 19-7l-4-2-5 5-7-1 0-9",
			fill: "#5a5140"
		}),
		/* @__PURE__ */ m("path", {
			d: "m47 130 11 3m-12 1 11 3m-13 1 10 3m30-12 7-2m-6 6 7-2m-6 6 8-2",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 64q-21 12-20 37 4 26 33 30 31-1 42-22l-9-35-21-14Z",
			fill: "#537f86"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 75q13 5 27-1l5 42-19 15-17-6Z",
			fill: "#9a7052"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 78q6 14 5 25l-13 19 7 3 12-19 13 18 7-6-17-18 8-21",
			fill: "#b1957e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 72q-5 20-11 31l5 18 11 2 9-19m21-32q15 15 16 32l-10 16-7 3-3-21",
			fill: "none",
			stroke: "#be9e78",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 78q-18 12-12 25l18 10 4-6-13-9 9-14M86 77q12 7 15 20l-13 10-7-6 9-6-11-10",
			fill: "#638d92"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 104q-5-5-8 0l0 7 8 6 9-5-5-4m38-7q-3-8 2-11l5 1 6 9-4 8-9 0",
			fill: "#ceb17c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M33 99q6 1 10 5l-4 6 4 4-5 5-8-5 0-8m52-15 5-5 6 4 0 6 4 3-3 5-9-3Z",
			fill: "#dedbc1"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 32q-4-12 14-16 17-1 19 14l4 15q12-1 12 6-1 9-18 9-1 9-4 14-11 6-18-1-11-6-14-18Z",
			fill: "#c6a774"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 37q-10-10-2-23 7-9 16-6l15 3 8-2q12 6 3 16l-12-6q-5 7-13 5l-9-4-1 14Z",
			fill: "#c5a75e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 16q9 6 18-3m-19 8q8 5 17-3m10-4 10 4m-37 9-5 8m2-10-4 5",
			fill: "none"
		}),
		/* @__PURE__ */ m(K, {
			x: 55,
			y: 43,
			r: 4
		}),
		/* @__PURE__ */ m(K, {
			x: 76,
			y: 41,
			r: 3.4
		}),
		/* @__PURE__ */ m("path", {
			d: "m48 34 11-2m9 0 12-3m-19 13-3 10 10 0M48 60q9 5 15 0m9-1 7 0",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 58q-12-8-22-3l11 9-12-1q9 14 29 10l7-5-6-3m16-8q11-4 23-13-1 8-6 12l13-4q-5 13-15 18-10 4-19-2Z",
			fill: "#c4a257"
		}),
		/* @__PURE__ */ m("path", {
			d: "m34 59 15 6m-14 3 16 0m28-7 11-7m-13 11 11-4m-41 14q14 9 29 1l1 10-9 1-6 6-7-5-10-3Z",
			fill: "#dddbc4"
		}),
		/* @__PURE__ */ m("path", {
			d: "m47 80 9 2m-5 2 9 1m4-4 8-2m-11 7 9-2M70 100l6-2m-7 9 6-1m-8 10 5-1",
			fill: "none"
		}),
		/* @__PURE__ */ h("g", {
			fill: "#c2ae68",
			children: [
				/* @__PURE__ */ m("ellipse", {
					cx: "76",
					cy: "98",
					rx: "2",
					ry: "2.4"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "76",
					cy: "107",
					rx: "2",
					ry: "2.4"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "72",
					cy: "117",
					rx: "2",
					ry: "2.4"
				})
			]
		})
	] });
}
function en() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M55 111q-19 11-32 4Q2 107 7 83l6-21q5-15-8-17l-10-4q7-14 21-9 16 1 16 17-2 15-9 29-5 17 7 21l21 0Z",
			fill: "#b88746"
		}),
		/* @__PURE__ */ m("path", {
			d: "M11 37q-5-2-13 3 0 8 8 10l2-5 8 2 1-6 5 2q-1-8-11-8Z",
			fill: "#d9d2af"
		}),
		/* @__PURE__ */ m("path", {
			d: "M18 51q2 11-6 28-6 24 10 31 10 5 25-1l-3-4q-27 4-25-17 1-12 9-25Z",
			fill: "#9e713e",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M18 50q3 11-4 26m4 1q-6 20 4 27m-2-42 6-11m-5 31q-1 13 5 17m-12-2 4 7m2-60 4 4m-17-4 3 3",
			fill: "none",
			stroke: "#755c38",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M57 105q-16 3-20 16-1 12 10 18l-15 6q-2 12 4 20l5 0q-7-11 0-15l17-10q10-13 9-24m4-10q17 3 24 16 5 10-7 18l15 14 5 1q-8-11-12-17 11-11 4-21l-21-15",
			fill: "#bc8d4c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 119q2 13 13 16m27-25q10 7 13 14l-8 8m-35 5 8-9m-11 21-7 5",
			fill: "none",
			stroke: "#8d673d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M35 160q-6-2-7 2l1 6 5 2 2 4 4-1-1-5 7 3q6 0 3-4l-9-5m63-11q1 8 9 10l8-2-1-3-7 0-3-5Z",
			fill: "#514e38"
		}),
		/* @__PURE__ */ m("path", {
			d: "M55 77q-14 11-13 24 1 14 19 17l17-6q-9-17-9-34Z",
			fill: "#c19a58"
		}),
		/* @__PURE__ */ m("path", {
			d: "M55 83q-10 11-5 21l8 7 6-6-3-26Z",
			fill: "#dbcea1"
		}),
		/* @__PURE__ */ m("path", {
			d: "M61 88q-1 9 6 18m-19-9 1 5m15 11 9-1",
			fill: "none",
			stroke: "#9c8451"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 81q-12 3-18-4-5-6-1-22l-5-2q-6 17-2 24 7 11 22 12m20-11q16-4 13-15-3-8-12-12l-4 4q8 6 8 10-1 5-9 7",
			fill: "#b48747"
		}),
		/* @__PURE__ */ m("path", {
			d: "M30 55q-8-2-6-8 2-6 8-6l7 4 1 5-6 5m34 0q-4-7 0-11 7-2 9 4l-3 7",
			fill: "#7f673f"
		}),
		/* @__PURE__ */ m("path", {
			d: "M31 44q4 1 5 5m-6-3 3 5m39-4 2 4",
			fill: "none",
			stroke: "#b3a171"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 28Q41 18 44 9q10 3 16 15m23 0q5-11 12-15 0 13-7 23",
			fill: "#bd9a5b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m47 15 8 11m36-9-5 10",
			fill: "none",
			stroke: "#655636",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 25q19-9 33 4 8 8 6 20 10 13 22 15l4 4q-7 6-19 2l-23-6q-8 8-17 6-12-1-19-9l-5-9 5-2-4-6 6 0q1-13 11-19Z",
			fill: "#c18e4b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 30q-9 8-7 15l9 3q-4-10 9-16m24-2q7 7 6 18l6 5-3-16Z",
			fill: "#ad7d40",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 48q7 8 17 4l10 10q14 4 24 1l14 8q-13 4-26-2l-17-2q-16 2-25-8l-4-5 7 0-5-6Z",
			fill: "#e1d8b7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M88 48q9 13 23 16l-12 2-18-9Z",
			fill: "#dfd5af"
		}),
		/* @__PURE__ */ m("path", {
			d: "M52 37q6-8 13 1l0 9q-10 5-13-10m26-2q4-7 10-2l0 10-8 4Z",
			fill: "#e8ddb3"
		}),
		/* @__PURE__ */ m("path", {
			d: "M58 37q4-4 5 2l-2 6-3-1m24-9q4-4 4 1l-2 6-3 0",
			fill: "#384233"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 32q10-1 16 6m13-3q5-7 12-7m-19 3 2 13m2-12 3 10m-15 15q9 8 20 3m26 5 8-1 5 3-5 4-9-2Z",
			fill: "#4d5037"
		}),
		/* @__PURE__ */ m("path", {
			d: "M34 53q12 10 27-2l1 21-8 9q-13-14-20-28Z",
			fill: "none",
			stroke: "#544d35",
			strokeWidth: "1.8"
		}),
		/* @__PURE__ */ m("path", {
			d: "m44 31 5-4m-5 26-5 2m8 3-6 3m6 0-5 4m-1 22-4 6m4 7 1 5m-8 2 8-1m12 14-4 8m28-12 10 6m-6 2 4 6m-49-66 6 0m-7-5 5 0m35-3 5 3m24 93 3 2m-72 13 3 0",
			fill: "none",
			stroke: "#82633b",
			strokeWidth: ".8"
		})
	] });
}
function tn({ x: e, y: t, s: n = 1, flip: r = !1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${r ? -n : n} ${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "m-4 20 0 11 8 3 2-3-5-3 1-9m11-1 0 10 8 1 2-3-6-1 0-9",
				fill: "#b4975b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-19 9q10-7 18-15l1-30q0-12 10-12 11 0 10 12l-5 10 0 20 5 6q8 18-7 24-15 3-25-5l-16 2 10-9Z",
				fill: "#dfdfcc"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-14 8q16-11 26-1 3 9-12 10l-14-4-7 1m9-5 15-3m-13 6 14-2m9-37 4 1m-23 44 6 0",
				fill: "none",
				stroke: "#7b8976"
			}),
			/* @__PURE__ */ m("path", {
				d: "m20-37 13 5-14 4m0 0 12 3-12 1",
				fill: "#c5a35b"
			}),
			/* @__PURE__ */ m(K, {
				x: 12,
				y: -38,
				r: 2.6
			})
		]
	});
}
function nn() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m(tn, {
			x: 28,
			y: 112,
			s: .65,
			flip: !0
		}),
		/* @__PURE__ */ m("path", {
			d: "M56 132q-5 11-4 21 4 5 8 5 6 2 8-1v-4l-10-2q4-6 7-15M74 134q-1 9 1 17 3 5 7 6h11l2-4q-6-3-12-2l-1-17",
			fill: "#c5ad79"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 86q-4 22-11 43 10 9 25 9 15-1 26-9-8-22-9-41Z",
			fill: "#658695"
		}),
		/* @__PURE__ */ m("path", {
			d: "M52 89q14 9 28 0 1 20 7 33-18 14-41 2 6-21 6-35Z",
			fill: "#e2dfc6"
		}),
		/* @__PURE__ */ m("path", {
			d: "m51 99-2 23m9-24-2 27m8-26 0 28m7-27 3 25m3-26 5 22M41 129q23 13 49-1",
			fill: "none",
			stroke: "#859584"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 62q-14 8-17 25l10 15 7-5-8-11 12-17M79 67q5 15 19 20l8-1 2 5-12 3-22-14",
			fill: "#d6d8bf"
		}),
		/* @__PURE__ */ m("path", {
			d: "M55 61q-7 13-8 29 8 11 15 3l5-12 8 13 11-4-8-24Z",
			fill: "#ab8152"
		}),
		/* @__PURE__ */ m("path", {
			d: "m61 70 1 14m2-10 0 2m-1 4 0 2m-1 4 0 2m-8-17-4 18m26-16 4 15",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 30q15-11 28 1 7 8 3 20-1 12-7 18-10 11-19 0-13-12-10-26Z",
			fill: "#d0b681"
		}),
		/* @__PURE__ */ m(K, {
			x: 54,
			y: 45,
			r: 4
		}),
		/* @__PURE__ */ m(K, {
			x: 73,
			y: 42,
			r: 3.3
		}),
		/* @__PURE__ */ m("path", {
			d: "m61 46-1 9 7 0M57 64q6 6 13-2m-23-22 7-4m13-3 8 2m-28 20 1 0m3 3 1 0m-4 3 1 0",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 31q5-17 23-17l15 9-7 10-11-6-12 12-7 0-1 13-8 1 2-17Z",
			fill: "#b6a05d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 44q-11-2-12-12l-5-3q13-20 30-23 23-4 30 15-19-9-31 5l-9 12Z",
			fill: "#ac7151"
		}),
		/* @__PURE__ */ m("path", {
			d: "M29 31q14-20 30-19m-23 22q9-13 20-15m-19 18 6 18 10 10m-12-23 3 14m4-27 14-7M39 51l-4 12 6 8-5 9 7 11 5-3-4-10 4-9-5-8 3-7",
			fill: "#bb9b58"
		}),
		/* @__PURE__ */ m("path", {
			d: "m38 65 6 1m-6 7 7 1m-5 7 7 0M47 61q9 8 18 4l9 8-14 0-7 11-3-11-10-2Z",
			fill: "#b67350"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 96q-2-6-6-3-3 2-2 8 2 5 7 5l5-5m48-14q-3-5 1-7 5-2 7 2l-1 7-6 4",
			fill: "#c9b17d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m44 97 5 3m-5 1 3 3m58-20 5 2m-6 0 5 2",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "m100 95 20-51 2-22m-4 30 13-9 5-12m-15 9 12-10m-14 7-4-9m19 8 4-2",
			fill: "none",
			stroke: "#625c3c",
			strokeWidth: "1.6"
		}),
		/* @__PURE__ */ m(tn, {
			x: 109,
			y: 143,
			s: .7
		})
	] });
}
//#endregion
//#region src/games/pilgrims/refined-art.tsx
var rn = "#393c2d";
function an({ x: e, y: t, r: n = 3 }) {
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("ellipse", {
		cx: e,
		cy: t,
		rx: n,
		ry: n * 1.17,
		fill: "#f5ebc8"
	}), /* @__PURE__ */ m("ellipse", {
		cx: e + .6,
		cy: t + .3,
		rx: n * .38,
		ry: n * .6,
		fill: rn,
		stroke: "none"
	})] });
}
function on() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M49 128q-3 12-2 23l-7 8q-5 4-1 7 6 2 19-4l3-7-3-24M70 130q-1 10 4 21l9 4q8 1 9 5-4 5-13 2l-14-4-5-23",
			fill: "#494c3e"
		}),
		/* @__PURE__ */ m("path", {
			d: "m47 140 10 2m-10 3 10 2m-10 3 10 2m17-8 9-2m-9 6 10-2m-18 10-8 3m-10 4 10-2m16 0 10 2",
			fill: "none",
			stroke: "#a3956d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M35 71Q20 64 18 80l-4 21q1 8 11 10l20-7 5-26Z",
			fill: "#9a8b5e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M19 79q12 8 24 2m-25 4q14 8 25 1m-24 5q13 8 22 1m-23 5q11 8 24 1m-21 5 14 3M24 74l-3-12 4-5 9 15m-7-14 1 13m3-15 1 13m-13 6 20 8",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 107q-1 14-8 29l11 4 6-4 6 7 7-5 7 5 7-7 7 2 7-8-14-25Z",
			fill: "#6f797d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 114q-2 11-6 20m12-17-4 19m13-18-4 20m12-22-2 21m7-21 4 15",
			fill: "none",
			stroke: "#404b49"
		}),
		/* @__PURE__ */ m("path", {
			d: "M36 69q-3 8-7 14 1 17 6 26 12 10 34 8l13-11-3-12-11-24Z",
			fill: "#9c6248"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 78q-6 14-4 23l13 9 21-2-12-13 4-19",
			fill: "#b17b54"
		}),
		/* @__PURE__ */ m("path", {
			d: "M34 74Q26 58 21 43 40 26 71 25q11 7 22 15l-16 5q-2 17-8 34l-13 8Z",
			fill: "#b0714e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M25 43q25-3 47-12L55 62l-2 18-15-10Z",
			fill: "#c28a5e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M34 48q11-1 26-7m-22 13 17-8M28 42q22 0 38-7M56 72q-2-19 18-39M39 52q4 9 9 16m-5-17 7 10M33 80l-3 15m8 7 10 5m17 4 7-5",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M64 44q11-4 17 4l3 6q14-2 17 6 4 8-11 10l-8-2q4 8-1 14l-8 3q-13-2-15-14l-3-12Z",
			fill: "#ceb07a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M63 54q-4 12 0 20l7 8-8-2-6-10 1-13M80 50q6 1 9 6",
			fill: "#b99a68",
			stroke: "none"
		}),
		/* @__PURE__ */ m(an, {
			x: 77,
			y: 55,
			r: 3.5
		}),
		/* @__PURE__ */ m("path", {
			d: "M70 49q5-4 10-1m-10 9 5 2m-7 2 5 2m7 7 8 1m-20 1q5 6 12 3m-11 4 7 1m-18-8-4-5",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M60 90q8 1 13 10l10 2 20-12 4 5q-9 14-25 16-12-1-20-9",
			fill: "#a76e4b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M101 91q3-3 8-1l1-9q1-4 4-2l-1 12q4-4 7-2 1 3-5 6 7-1 6 2 0 2-6 3 6 0 4 3-4 3-9 0l-7-7",
			fill: "#cfb17d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M62 92q-2 6 4 9m0-8 5 7m-30-8 4 8m-6-4 4 6M108 91l2 7m0-7 3 2m-4 2 4 1M45 114l-7 14m9-12-6 17",
			fill: "none"
		}),
		/* @__PURE__ */ h("g", {
			stroke: "#48643e",
			fill: "#91b86b",
			children: [/* @__PURE__ */ m("path", { d: "M111 80q-10-1-7-7 1-4 6-1-3-9 3-9 5 0 3 7 7-5 9 0 2 5-6 7 7 4 3 7-4 4-8-2-6 7-9 2-1-3 6-4Z" }), /* @__PURE__ */ m("path", {
				d: "m114 79-1 12",
				fill: "none"
			})]
		})
	] });
}
function sn() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M61 112q3 9-5 18l-13 13q-4 5-4 11l-3 7q-3 2-4-1-1-5 2-10l1-7q5-12 14-22l2-10M74 110q2 7 13 11l10 3q6 1 9-3 4-3 5 0-1 6-7 9-8 3-18-2l-17-8",
			fill: "#d7bd89"
		}),
		/* @__PURE__ */ m("path", {
			d: "M54 117q1 8-7 17m-9 12-2 10m42-41q5 8 15 10m12 1-2 2",
			fill: "none",
			stroke: "#aa8e60"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 35q-7 10-7 24-5 15-21 18 11 8 21 2l-5 9q13 1 22-11l29-5q9 9 18 9l10-5q-16-4-19-19l-5-25Z",
			fill: "#79a398"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 38q-3 24-19 36m22-32q-2 22-10 32m13-30q0 18-7 28m35-28q-1 22 12 31m-8-29q1 19 15 27M36 79l10-8m44 7-7-7",
			fill: "none",
			stroke: "#45695f"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 62q1 9-6 13l7 16q-3 14-13 20 13 11 30 10 14 0 23-9-12-5-17-19l5-18-12-13Z",
			fill: "#eeecd2"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 78q8 11 22 3m-17 7 2 10m15-11-5 9M52 100q-3 8-8 10m15-10-2 12m10-12 2 14m7-12 6 10M44 115q23 7 43-1",
			fill: "none",
			stroke: "#838b6e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 31q14-8 27 1l3 12q-1 4 5 8l-7 3-2 10q-4 6-10 5-13-3-17-18l-3-9Z",
			fill: "#dec797"
		}),
		/* @__PURE__ */ m("path", {
			d: "M52 31q1 14-5 19l-2-11 3-9m29 7 4 11-5-3",
			fill: "#c5ab7c",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 43q5 4 10 0m6 0q5 3 9-1m-23 3-1 2m17-3 3 2m-8 0-3 10 7 0m-8 6q5 3 10-1m-16-23 8-1m6-1 7 1",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 68q-4 1-4 8l13 17 11-3q-8-6-15-16l2-4M77 68q8 3 9 9-2 8-9 14l-7 5-5-6 10-11-4-7",
			fill: "#dfc796"
		}),
		/* @__PURE__ */ m("path", {
			d: "M65 87q4-3 7 2l3 2-3 6-8 1-4-4q0-3 4-3m0 3 5 1m-2-6 4 4m-9-3 4 2",
			fill: "#dec797"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 32q12-12 31-3l1 7q-11 4-30 2Z",
			fill: "#6f968c"
		}),
		[
			0,
			1,
			2,
			3,
			4
		].map((e) => /* @__PURE__ */ h("g", {
			transform: `translate(${49 + e * 7.4} ${26 - Math.sin(e) * 2})`,
			children: [/* @__PURE__ */ m("path", {
				d: "M0 5q-6-6-2-8 3-2 5 1 5-3 6 1 1 5-4 7Z",
				fill: e % 2 ? "#b87850" : "#c68c64"
			}), /* @__PURE__ */ m("path", {
				d: "M0 3q-2-4 2-4 4 1 0 4Z",
				fill: "none"
			})]
		}, e)),
		/* @__PURE__ */ m("g", {
			fill: "#ddb66a",
			children: /* @__PURE__ */ m("path", { d: "M18 89q-7-9-8-3-8-5-6 2l8 8 8-1 3-5Z M109 45q-1-10-5-6-6-4-7 1l6 9 10 1 4-5Z M100 145q-9-7-10-1-9-3-7 3 4 5 12 4l6-3Z" })
		})
	] });
}
function cn() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M33 121q-15 4-26-7l1-8q-10 5-5 14 11 17 30 13Z",
			fill: "#7f9490"
		}),
		/* @__PURE__ */ m("path", {
			d: "M26 117q-6 9-7 21l-9 5 1 5 8-2 6 2 8-7 6-18M65 119q-1 10 6 18l12 2 2 5-7 2-3-3-5 3-9-3-7-16",
			fill: "#8f9b87"
		}),
		/* @__PURE__ */ m("path", {
			d: "m16 144 3-3m4 5 2-6m45 2-2-4m8 4-3-5",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M19 90Q28 65 58 77q11 6 13 19l-3 22q-4 20-28 20-22-1-24-22Z",
			fill: "#71868a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M22 106q3 18 21 23 14 3 24-11-1 14-16 18-24 4-32-15Z",
			fill: "#5e7376",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M26 82q3-18-6-34 14 7 20 22l5-12q8 12 5 25Z",
			fill: "#b47b50"
		}),
		/* @__PURE__ */ m("path", {
			d: "M28 78 24 56m10 24-5-17m11 16-6-14m11 14-4-9",
			fill: "none",
			stroke: "#754f38"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 78q-7-22-4-35l3 8 1-13 5 7 1-13 5 9 2-13 5 11 1-15q13 15 12 34L66 88Z",
			fill: "#b98558"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 67q10-9 23-12m-17 17 17-9m-19-8 12-8m-15 0 9-8m2 39 8-10M61 51l-1 20",
			fill: "none",
			stroke: "#7d573c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M58 109q13 4 14-20L70 67q1-18 14-24 17-6 25 5l-4 17q-12-2-13 10l1 22q-2 28-17 31l-16-5Z",
			fill: "#84928c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M75 62q8 4 17 1m-18 5 17 3m-17 4 15 3m-14 4 15 3m-15 3 16 3m-16 3 15 3m-16 3 14 4m-16 3 13 4m-16 2 13 4m-17 1 9 6",
			fill: "none",
			stroke: "#414d46"
		}),
		/* @__PURE__ */ m("path", {
			d: "M91 42q-3-12 4-15l4 9 7-7 3 12 8-4-1 11Z",
			fill: "#b77b54"
		}),
		/* @__PURE__ */ m("path", {
			d: "M96 46q18-7 26 11l2 14 10 18-4 5-7-8-6-2-3-13-9 2-10-8Z",
			fill: "#b8784c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M116 64q5 9 6 16l-8-9-3-15M126 84l3 5",
			fill: "#cf9460",
			stroke: "none"
		}),
		/* @__PURE__ */ m(an, {
			x: 111,
			y: 54,
			r: 4.8
		}),
		/* @__PURE__ */ m("path", {
			d: "M105 47q4-4 8-2m-10 18 6 3m11 9 4 1m-17-7q-3 11 2 16 5 3 9-2l-4-3q-3 4-4-2l-1-9",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M28 115q-3-8 3-11 6-2 8 4-1 9-8 12l-3-2 3-8M52 116q-1-11 5-11 8 2 4 10l-5 5",
			fill: "#b17c4f"
		}),
		/* @__PURE__ */ m("path", {
			d: "m19 91-5-3 4-5 5 2m4-9-3-5 5-3 6 4M36 87q-5-6-8 0m9 4q-5-5-7 1m18-7q-6-4-7 2m12 0q-6-5-8 1m-19 8q-5-5-7 1m15 0q-5-5-7 1m16-2q-6-4-8 2m17-2q-6-4-8 2m-19 8q-5-4-7 2m24-4q-5-4-7 2m13 1q-5-4-7 2m-12 7q-4-4-6 1m20 1q-5-4-7 1m-1 7q-6-4-8 0",
			fill: "none",
			strokeWidth: ".9"
		})
	] });
}
function ln() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M49 133q-14 3-16 11l1 13q3 6 6 0l-1-8q8 0 15-8m1-2q-2 11-11 17-6 5-4 9 5 2 13-5l10-15m4-4q9 13 2 23-5 7-10 4-5-2-2-7-9-1-9 7 1 8 14 5 17-5 15-25m7-10q-1 11 6 15l2 10q4 4 6-1l-1-13-6-9m1-3q9 8 15 11l-1 8-7 4q-5 7 2 6l13-8 1-12-14-13",
			fill: "#a18350"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 112q-17 10-27 2l-6-8q1-28 8-49l-4-1q-9 21-11 47-1 14 11 19 12 6 30-2m38-9q17 5 25-10 5-16 3-35l-4 0q1 23-8 32-7 7-17 5",
			fill: "#ac8c55"
		}),
		/* @__PURE__ */ m("path", {
			d: "M12 107q-3-20-1-39m3 32 7-11m-10 5-5-10m8-10 7-7m-5-5-3-10m1 64-8 3m16 3 6-6m6 7 8-6m68-25 7-6m-4-2-6-9m7-6 5-6m-4 36 7-6m-12 13 5-2m-17 9 2-7m-5 11 4 0",
			fill: "none",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ h("g", {
			fill: "#b4a16a",
			children: [
				/* @__PURE__ */ m("path", { d: "M16 65q3-17 9-29 3-15 4-29l2-5q0 26-4 39-5 13-7 25Z" }),
				/* @__PURE__ */ m("path", { d: "M22 44Q13 33 10 22L6 16q9 5 11 16l8 9m-5 17q-8-10-13-17l-7-7q9 2 13 10l10 10m2-17q10-9 16-20l4-11q1 12-5 22l-14 14m-7 11q17-5 25-14l8-14 4-3-7 19q-9 11-27 16m6-23q-4-13-6-21l-5-9q8 5 10 18l3 8m8 5q8-11 12-25l4-6q-1 18-12 33m7 6q11-1 18-11l4-2q-3 10-14 15l-11 3" }),
				/* @__PURE__ */ m("path", { d: "M113 73q0-20-6-34l-4-22 0-12 2-4 1 22 6 18q4 13 5 31Z" }),
				/* @__PURE__ */ m("path", { d: "M108 44q-9-11-15-23L91 9l2-6 3 18 13 18m3 11q10-10 13-23l3-18 3-7-1 21q-3 18-16 32m0-1q15-6 22-18l7-9q-4 14-14 22l-13 11m-2 2q-10-3-19-11l-8-12 0-7 6 10q9 12 22 15m-3-16q5-12 5-25l-1-10 3-7 1 23-5 22m10-2q6-8 10-19l3-4-3 13-10 13m-12-2-8-9-5-12 0-7 4 12 10 13m-15 12-8-6-1-6 5 3 7 7m29-12 6-8 2-9 3-4-1 14-7 10" })
			]
		}),
		/* @__PURE__ */ m("path", {
			d: "m18 55-6-14m10 6 5-12m-6 21 13-13m2 0 11-8m69 21-5-16m7 14 4-12m1 8 11-10m-23 3-7-15M10 31l3 12m37-21-7 14m65-5 1-12m20 19 6-6",
			fill: "none",
			stroke: "#796744",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 86q20-13 47-1l-2 23q-4 11 2 24l-3 12-8 4-6-3-8 5-8-5-8 1q-13-5-10-15l2-21-4-17Z",
			fill: "#b28b4e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 93q9 10 7 26l-6 14 5 9 8 2-6-15 7-16-4-21m31-1q-6 15-1 28l4 16-6 9 7-1 2-11-4-25 3-18",
			fill: "#8e6d3e",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 91q8-10 24-11 17-2 27 6l-2 8q-20 9-48 2Z",
			fill: "#c2a265"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 90q7-7 22-8 16 0 23 5-7 7-23 8-16 1-22-5Z",
			fill: "#d5bd83"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 90q15-10 36-3-5 7-22 6-13-1-11-4 4-5 20-4 12 1 10 4-3 4-19 2-8-1-4-3 6-3 17 0m-37-3-3-4m12 0 1-5m13 2 0-4m14 5 1-4m11 7 5-2",
			fill: "none",
			strokeWidth: ".9"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 106q7-12 17-3l-2 5q-8-5-15 0m22-7q7-12 15-6l0 5q-9-1-15 6",
			fill: "#b1aa67"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 117q-2-12 7-14 10-1 11 9 1 11-9 15-8-1-9-10m21-5q0-12 8-13 8 0 7 10-1 11-9 14-6-1-6-11",
			fill: "#d1bb7a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M54 118q-3-9 4-11 7 0 7 7 0 8-7 10-6-1-5-7 1-7 5-6 5 1 3 6-1 3-4 2m17-8q0-8 5-9 6 0 5 7-1 8-6 11-5-1-4-8 1-6 4-5 4 2 1 7",
			fill: "none",
			strokeWidth: "1.2"
		}),
		/* @__PURE__ */ m("path", {
			d: "m68 115-5 11 8-2m-25 8 10-7 6 5 9-7 4 5 11-10-2 10-10 11-6-4-9 7-5-5-10 5Z",
			fill: "#4c4630"
		}),
		/* @__PURE__ */ m("path", {
			d: "m48 134 7-5 7 5 8-7 5 5 8-8m-35 17 9-6m9 5 7-6m-30-35 4 7m-5 2 3 7m-4 3 3 6m7 10 3 5m5 1 0 6m10-8-1 6m8-7 2 5m-30-10 5 4m1-17 3 4m25-25-2 8m4 9-3 7m-28 23 2 8m13-3 3 5m17-8 3 4",
			fill: "none",
			stroke: "#6d5735",
			strokeWidth: ".8"
		})
	] });
}
//#endregion
//#region src/games/pilgrims/art.tsx
var q = "#383a2b", J = "#f4efd9", un = {
	red: "#e6a99b",
	blue: "#a7ced0",
	green: "#b6c99d",
	gold: "#e7cc75"
};
function Y({ kind: e, ...t }) {
	let n;
	switch (e) {
		case "red":
			n = /* @__PURE__ */ h("g", {
				fill: "#ce5d65",
				stroke: "#292c27",
				strokeWidth: "2",
				children: [/* @__PURE__ */ m("path", { d: "M9 29 9 24Q3 21 4 15L5 8Q6 5 9 6L10 3Q13 1 15 4 17 0 20 3L22 5Q25 2 28 6L29 15Q30 21 24 26L23 31 10 32Z" }), /* @__PURE__ */ m("path", {
					d: "M10 7 10 15Q13 18 15 14L15 5M15 14Q18 18 21 14L21 6M21 14Q25 17 27 13M8 19 15 21 21 17Q25 15 26 18L20 25 15 26M10 28 22 28M6 11 9 12",
					fill: "none",
					strokeWidth: "1.5"
				})]
			});
			break;
		case "blue":
			n = /* @__PURE__ */ m("path", {
				d: "M7 24Q1 21 3 14 3 7 11 6l8-2q10 0 12 8 3 9-6 12l-11-1-8 7 2-6Z",
				fill: "#62bbc8",
				stroke: "#292c27",
				strokeWidth: "2.4"
			});
			break;
		case "green":
			n = /* @__PURE__ */ h("g", {
				fill: "#73bc70",
				stroke: "#292c27",
				strokeWidth: "2.3",
				children: [/* @__PURE__ */ m("path", { d: "m3 9 4 1 1-5 4 2q13-6 17 6l1 7 4 3-9 3q-15 2-17-11l-5 1Z" }), /* @__PURE__ */ m("path", {
					d: "M12 10q5 10 15 12",
					fill: "none",
					strokeWidth: "2"
				})]
			});
			break;
		case "gold":
			n = /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
				d: "M17 3q14 0 14 14 0 13-14 14Q3 30 3 17 3 3 17 3Z",
				fill: "#e9dc58",
				stroke: "#292c27",
				strokeWidth: "2.6"
			}), /* @__PURE__ */ m("path", {
				d: "m8 13 6 4 3-9 4 8 6-5-3 12-12 0Z",
				fill: "#f1e681",
				stroke: "#292c27",
				strokeWidth: "2"
			})] });
			break;
		case "sword":
			n = /* @__PURE__ */ m("path", {
				d: "m5 28 6-9-4-4 3-3 4 3L25 3 30 2 29 8 18 19 22 23 19 26 15 22 8 30Z",
				fill: q
			});
			break;
		case "notes":
			n = /* @__PURE__ */ m("path", {
				d: "M10 7 27 3 27 24Q26 30 20 28 15 25 19 22L23 21 23 10 13 13 13 27Q11 33 5 29 2 24 9 23Z",
				fill: q
			});
			break;
		case "compass":
			n = /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
				d: "M17 3Q3 2 3 17q-1 14 14 14 14 0 14-14Q31 3 17 3Z",
				fill: "none",
				strokeWidth: "3"
			}), /* @__PURE__ */ m("path", {
				d: "m12 9 11 8-11 7Z",
				fill: "none",
				strokeWidth: "2.6"
			})] });
			break;
		case "star":
			n = /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("path", {
					d: "m17 2 5 9 10 0-8 8 4 11-11-6-10 7 2-12L2 11l10 1Z",
					fill: q,
					stroke: "none"
				}),
				/* @__PURE__ */ m("path", {
					d: "M12 17q5-5 10 0-5 5-10 0Z",
					fill: J,
					stroke: "none"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "17",
					cy: "17",
					r: "1.5",
					fill: q,
					stroke: "none"
				})
			] });
			break;
		case "wanderer":
			n = /* @__PURE__ */ h("g", {
				fill: "#8e5933",
				stroke: "none",
				children: [
					/* @__PURE__ */ m("path", { d: "m10 4 3-2 20 20-3 3Z" }),
					/* @__PURE__ */ m("path", { d: "M6 9 12 5 17 9 15 14Q20 23 16 29 10 35 4 29-1 24 4 16L7 13Z" }),
					/* @__PURE__ */ m("path", { d: "m5 8 2-5 5 3 5-1-2 6-5 3Z" }),
					/* @__PURE__ */ m("path", {
						d: "m5 15 8-3 1 2-8 3Z",
						fill: J
					})
				]
			});
			break;
		case "nobleheart":
			n = /* @__PURE__ */ m("path", {
				d: "M17 30Q2 20 3 10 4 2 12 5L17 9Q24 0 30 8 34 18 17 30Z",
				fill: "#8e5933"
			});
			break;
		case "beast":
			n = /* @__PURE__ */ m("path", {
				d: "M12 31Q2 30 3 23Q3 19 7 17L9 19Q5 22 9 25Q12 26 14 21L14 16Q13 10 10 10L7 12Q5 10 7 7Q13 3 17 12L18 17Q20 12 17 7L14 5Q13 2 17 2Q24 3 24 12L25 16Q28 12 25 6L23 4Q23 1 27 2Q33 5 30 17L29 24Q28 31 20 32Z",
				fill: "#8e5933",
				stroke: "none"
			});
			break;
		case "scoundrel":
			n = /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
				d: "M2 9q5-5 14-3l7 2 8-3-2 10q-3 12-13 13Q5 27 2 17Z",
				fill: "#825032",
				stroke: "none"
			}), /* @__PURE__ */ m("path", {
				d: "m6 13 9 5-4 3-5-4m15 0 7-5-1 5-4 3",
				fill: J,
				stroke: "none"
			})] });
			break;
		case "hat":
			n = /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("rect", {
					x: "1",
					y: "1",
					width: "32",
					height: "32",
					rx: "3",
					fill: "#8e5933",
					stroke: "none"
				}),
				/* @__PURE__ */ m("path", {
					d: "M6 18Q7 15 11 17L12 11Q17 7 23 12L24 17 29 17Q27 24 15 23Z",
					fill: J,
					stroke: "none"
				}),
				/* @__PURE__ */ m("path", {
					d: "M11.5 15Q17 18 23.7 15.7L24 18.2Q17 20.8 11 18Z",
					fill: "#8e5933",
					stroke: "none"
				})
			] });
			break;
		case "clover":
			n = /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
				d: "M17 17C-1 16 5 1 13 7 15-4 27 3 23 11 36 8 35 23 25 22 31 34 17 35 17 24 7 34 0 21 11 19Z",
				fill: "#89b862"
			}), /* @__PURE__ */ m("path", {
				d: "M17 17 26 30M17 17 14 9M17 17 25 14M17 17 10 23",
				fill: "none",
				strokeWidth: "1"
			})] });
			break;
		case "retire":
			n = /* @__PURE__ */ m("path", {
				d: "m6 8 3-3 9 9 8-10 4 3-9 10 9 10-4 4-9-10-9 9-4-4 10-10Z",
				fill: q
			});
			break;
		case "item":
			n = /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("rect", {
				x: "7",
				y: "2",
				width: "21",
				height: "30",
				rx: "4",
				fill: J
			}), /* @__PURE__ */ m("path", {
				d: "m17 10 7 4-1 9-7 4-7-5 1-9Z M10 13 17 17 24 14M17 17 16 27",
				fill: "#ba8b51"
			})] });
			break;
		case "reserve":
			n = /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("path", {
					d: "M8 10 27 9 27 29Q27 32 23 32L9 32Q6 32 6 28L6 15Q6 12 8 10Z",
					fill: "#c1c8b9"
				}),
				/* @__PURE__ */ m("path", {
					d: "M13 16q-5 0-4 4l1 2 4 0-2 4q-1 4 4 4l5-1q4-1 3-5l-3-1-2 3-1-1 3-5q3-7-3-6l-2 2Z",
					fill: "#798a7d",
					stroke: "none"
				}),
				/* @__PURE__ */ m("path", {
					d: "M9 11V5Q10 1 15 1H25Q30 2 29 7L28 11Q27 14 24 13L25 6H22L21 11Q20 14 17 14L18 6H15L14 11Q13 14 10 14L11 6H9Z",
					fill: J
				}),
				/* @__PURE__ */ m("path", {
					d: "m10 4 3 0m4-1 4 0m3 0 2 1",
					fill: "none",
					strokeWidth: ".8"
				})
			] });
			break;
		case "extra":
			n = /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("path", {
					d: "M1 17h6M4 14v6M9 13l4-4-1 14",
					fill: "none",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ m("path", {
					d: "M17 4q5-2 10 0l-1 22q-5 2-11 0l1-19q0-2 1-3Z",
					fill: J
				}),
				/* @__PURE__ */ m("path", {
					d: "m18 10 4-2 4 3-1 6-4 2-4-4Z",
					fill: "#9b673e",
					stroke: "none"
				}),
				/* @__PURE__ */ m("path", {
					d: "m18 10 4 2 4-1m-4 1-1 6",
					fill: "none",
					stroke: J,
					strokeWidth: ".7"
				}),
				/* @__PURE__ */ m("path", {
					d: "M28 20q5 1 3 8l-3-2m3 2 2-3",
					fill: "none",
					strokeWidth: "1.7"
				})
			] });
			break;
		case "cart":
			n = /* @__PURE__ */ h("g", {
				fill: "#449db5",
				stroke: "#263e3d",
				strokeWidth: "1.25",
				children: [
					/* @__PURE__ */ m("path", { d: "M17 1Q2 1 1 16q-1 16 16 17 16 0 16-16Q33 1 17 1Zm0 4q12 0 12 12 0 12-12 12Q5 29 5 17 5 5 17 5Z" }),
					/* @__PURE__ */ m("path", { d: "m15 5 .5 9 2 .5 1-10m8 5-8 6 1 2 9-5m0 7-10-1-.5 2 9 3m-6 5-4-8-2 1 3 8m-9-2 6-7-2-1-7 5m-3-8 10 2 .5-2-10-4m5-6 7 8 2-1-6-10" }),
					/* @__PURE__ */ m("path", { d: "M17 13q-5 0-5 4 0 5 5 5 5-1 5-5 0-4-5-4Z" }),
					/* @__PURE__ */ m("circle", {
						cx: "17",
						cy: "17",
						r: "2.2",
						fill: J
					})
				]
			});
			break;
		case "horse":
			n = /* @__PURE__ */ h("g", {
				fill: "#449db5",
				stroke: "#263e3d",
				strokeWidth: "1.15",
				children: [
					/* @__PURE__ */ m("path", { d: "M12 11Q9 9 9 4q5 1 7 5m2-1Q15 3 18 1q4 5 2 9" }),
					/* @__PURE__ */ m("path", {
						d: "M15 10q7-2 11 3l4 2-4 1 5 4-4 0 4 4-4 0 4 4-5 3-7-8Z",
						fill: "#377d91"
					}),
					/* @__PURE__ */ m("path", { d: "M13 10q8-3 11 6 3 6 3 13-5 4-15 2l1-8q-5 3-8 4-5-1-4-5l5-5q1-5 7-7Z" }),
					/* @__PURE__ */ m("path", {
						d: "M10 23q9 2 10-7m-6 13q6 2 10 0m-12-18 2 1m5-8 0 4",
						fill: "none",
						strokeWidth: ".75"
					}),
					/* @__PURE__ */ m("ellipse", {
						cx: "13",
						cy: "16",
						rx: "2",
						ry: "2.6",
						fill: J
					}),
					/* @__PURE__ */ m("circle", {
						cx: "13.5",
						cy: "16",
						r: ".8",
						fill: "#263e3d",
						stroke: "none"
					}),
					/* @__PURE__ */ m("circle", {
						cx: "4",
						cy: "22",
						r: ".7",
						fill: "#263e3d",
						stroke: "none"
					})
				]
			});
			break;
		case "boat":
			n = /* @__PURE__ */ h("g", {
				fill: "#449db5",
				stroke: "#263e3d",
				strokeWidth: "1.2",
				children: [
					/* @__PURE__ */ m("path", { d: "M2 6q2 7 15 7 12 0 15-7-1 8-6 14-7-2-12 0-7 2-10-3Q2 12 2 6Z" }),
					/* @__PURE__ */ m("path", {
						d: "M4 11q12 7 25 1M6 16q8 3 13 1m5 1 4-2",
						fill: "none",
						strokeWidth: ".7"
					}),
					/* @__PURE__ */ m("path", { d: "m21 4 2 1-7 20-2-1Z" }),
					/* @__PURE__ */ m("path", { d: "m19 2 6 1-1 3-6-1ZM14 23q6 0 5 6l1 2-6-1-3 0-2 1 2-6Z" }),
					/* @__PURE__ */ m("path", {
						d: "m14 25-2 4m4-4 0 4",
						fill: "none",
						strokeWidth: ".7"
					})
				]
			});
			break;
		case "walk": n = /* @__PURE__ */ h("g", {
			fill: "#449db5",
			stroke: "#263e3d",
			strokeWidth: "1.1",
			children: [
				/* @__PURE__ */ m("path", { d: "M5 0 12 1l-1 5q7-4 18-2l-1 6q-5 2-12 0l-6 2 0 3q-4 2-8-1L3 8Z" }),
				/* @__PURE__ */ m("ellipse", {
					cx: "6",
					cy: "14",
					rx: "3.5",
					ry: "1.5",
					fill: "#36748a"
				}),
				/* @__PURE__ */ m("path", { d: "m12 7 1 3m2-4 1 3m2-4 1 2M24 17q4-2 7 1l-1 8-2 6-5 0 0-3q-5 0-9 2-9 3-12-1 1-8 8-7l10 2 4-1Z" }),
				/* @__PURE__ */ m("ellipse", {
					cx: "27",
					cy: "18",
					rx: "3.5",
					ry: "1.5",
					fill: "#36748a"
				}),
				/* @__PURE__ */ m("path", {
					d: "m24 18 5 0M6 27q6 3 13-1m-5-2 1 3m2-3 1 2m2-2 1 2m6-3 3-1m-4 3 3-1",
					fill: "none",
					strokeWidth: ".7"
				})
			]
		});
	}
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 34 34",
		width: "34",
		height: "34",
		"aria-hidden": !0,
		...t,
		children: /* @__PURE__ */ m("g", {
			stroke: q,
			strokeWidth: "1.6",
			strokeLinejoin: "round",
			strokeLinecap: "round",
			children: n
		})
	});
}
function X() {
	return /* @__PURE__ */ h("svg", {
		className: "pg-march",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ m("rect", {
				x: "1",
				y: "1",
				width: "98",
				height: "98",
				rx: "3",
				fill: "none",
				stroke: "#faf3cc",
				strokeWidth: "4",
				vectorEffect: "non-scaling-stroke"
			}),
			/* @__PURE__ */ m("rect", {
				x: "1",
				y: "1",
				width: "98",
				height: "98",
				rx: "3",
				fill: "none",
				stroke: "#42654c",
				strokeWidth: "2",
				vectorEffect: "non-scaling-stroke"
			}),
			/* @__PURE__ */ m("rect", {
				className: "pg-flow",
				x: "1",
				y: "1",
				width: "98",
				height: "98",
				rx: "3",
				fill: "none",
				stroke: "#fff7c9",
				strokeWidth: "2",
				strokeDasharray: "6 4",
				vectorEffect: "non-scaling-stroke",
				children: /* @__PURE__ */ m("animate", {
					attributeName: "stroke-dashoffset",
					from: "0",
					to: "-20",
					dur: "1s",
					repeatCount: "indefinite"
				})
			})
		]
	});
}
function dn({ card: e }) {
	let t = [
		Dt,
		on,
		sn,
		cn,
		Ot,
		kt,
		At,
		jt,
		Mt,
		Nt,
		Pt,
		Ft,
		It,
		Lt,
		Rt,
		zt,
		Bt,
		Vt,
		Ut,
		Wt,
		Gt,
		Kt,
		qt,
		Jt,
		Yt,
		Xt,
		Zt,
		Qt,
		$t,
		ln,
		en,
		nn
	], n = {
		0: "translate(9 8) scale(.87)",
		7: "translate(9 5) scale(.93)",
		9: "translate(13 7) scale(.92)",
		12: "translate(9 5) scale(.94)",
		13: "translate(0 5) scale(.95)",
		15: "translate(0 9) scale(.94)",
		19: "translate(3 8) scale(.93)",
		22: "translate(13 4) scale(.92)",
		23: "translate(9 10) scale(.9)",
		29: "translate(9 4) scale(.9)",
		30: "translate(9 4) scale(.93)"
	}, r = t[e], i = r ? /* @__PURE__ */ m("g", {
		transform: n[e],
		children: /* @__PURE__ */ m(r, {})
	}) : null;
	return /* @__PURE__ */ m("g", {
		fill: "#c1a579",
		stroke: q,
		strokeWidth: "1.25",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: i
	});
}
function fn({ card: e, className: t }) {
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 140 180",
		className: t,
		"aria-hidden": !0,
		children: [/* @__PURE__ */ m("ellipse", {
			cx: "70",
			cy: "166",
			rx: "46",
			ry: "5",
			fill: "#8d8056",
			opacity: ".13"
		}), /* @__PURE__ */ m(dn, { card: e })]
	});
}
function pn({ art: e, className: t }) {
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 105 105",
		className: t,
		"aria-hidden": !0,
		children: [/* @__PURE__ */ m("ellipse", {
			cx: "52",
			cy: "97",
			rx: "34",
			ry: "3",
			fill: "#806942",
			opacity: ".1"
		}), /* @__PURE__ */ m("g", {
			stroke: q,
			strokeWidth: "1.2",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: /* @__PURE__ */ m(pt, { art: e })
		})]
	});
}
function mn() {
	return /* @__PURE__ */ m(Tt, {});
}
function hn({ marker: e = !1 }) {
	return e ? /* @__PURE__ */ h("g", {
		stroke: "#edf0df",
		strokeWidth: "1.8",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-16 1q-7-11-4-20l9 10-2-20 9 13 3-20 6 20 6-13-1 19 9-9-6 20q-10 7-19 0Z",
				fill: "#92bcc1"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-10 0-1-12 7 8 4-13 5 13 5-7-3 12",
				fill: "#dce9e1",
				stroke: "none"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "-17",
				cy: "6",
				rx: "6",
				ry: "5",
				fill: "#a9b1a0"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "-4",
				cy: "10",
				rx: "6",
				ry: "4.7",
				fill: "#9fa99b"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "10",
				cy: "9",
				rx: "6",
				ry: "5",
				fill: "#afb6a5"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "20",
				cy: "1",
				rx: "5",
				ry: "5.5",
				fill: "#a5ad9e"
			})
		]
	}) : /* @__PURE__ */ h("g", {
		stroke: q,
		strokeWidth: "2",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ m("path", {
				d: "m-17 8 29-11 5 6-30 11Z M-15-2 31 9 28 15-45 0Z",
				fill: "#98805b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-12 1Q-19-14-4-25L-4-12Q6-22 7-31 27-8 13 6Z",
				fill: "#d79b54"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-3 5Q-11-5 1-15 1-8 8-4L6 5Z",
				fill: "#edcf7f"
			})
		]
	});
}
//#endregion
//#region src/games/pilgrims/leaders.tsx
var gn = "#393c2d";
function _n({ x: e, y: t, r: n = 3 }) {
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("ellipse", {
		cx: e,
		cy: t,
		rx: n,
		ry: n * 1.3,
		fill: "#f2ebce"
	}), /* @__PURE__ */ m("ellipse", {
		cx: e + .8,
		cy: t + .3,
		rx: n * .4,
		ry: n * .65,
		fill: gn,
		stroke: "none"
	})] });
}
function vn() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M44 72q-19-5-24 10-7 13-3 29 5 13 25 9l10-18Z",
			fill: "#52684b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M20 84q11 7 23 3m-24 7q9 7 21 4m-22 7q8 7 20 4M25 76q-3-6 4-8l12 5 1 8-9-2Z",
			fill: "#74895e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 119q-2 17-16 29l-3 10 9 4 13-17 10-19m5-7q10 14 12 31l8 8 9-3-7-14-9-23Z",
			fill: "#365a55"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 124q-1 15-14 26m32-25 11 23M33 149l10 5m34-7 8-2",
			fill: "none",
			stroke: "#729086"
		}),
		/* @__PURE__ */ m("path", {
			d: "M27 152q7 4 11 3l-2 7 12 3q6 4-1 6l-19-3-4-5-3 4-4-4 5-12Zm51-6q5 3 10-1l4 10 14-5q8-3 7 3-5 9-22 11l-10-2-3-5Z",
			fill: "#303e35"
		}),
		/* @__PURE__ */ m("path", {
			d: "M20 164q10 3 20 2m45-7q15 0 24-6",
			fill: "none",
			stroke: "#8c9174",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 69q12-7 24 0 10 12 12 30l-2 24-14-4-9 5-15-3q5-16-3-29Z",
			fill: "#4d7b59"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 77q-4 13 3 25l-2 15 9 3 2-25m10-20q6 21 9 29l-3 13-9-5Z",
			fill: "#345b43",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "m51 77 6 15-3 26m9-25 6 18m-30 3 11 3m10 0 12-4m-17-18 2 1m0 7 1 1",
			fill: "none",
			stroke: "#243f34"
		}),
		/* @__PURE__ */ m("path", {
			d: "M60 66q3 8 12 12l-6 5-7-4-5 8-9-12 6-6Z",
			fill: "#b7b77d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m55 73 5 6 5-2-1 12-5-5-6 5-2-9",
			fill: "#c9c68c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 77q-7-2-12 7-3 11 6 23l11 9 8-8-12-10-3-11m24-10q10-1 16 8l8-10 6 5q-8 21-17 17L64 89Z",
			fill: "#608a62"
		}),
		/* @__PURE__ */ m("path", {
			d: "m37 89 3 12 12 10m18-27 10 7 9-11m-45 24 7-3m35-19 7 4",
			fill: "none",
			stroke: "#315a41"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 104q-2 4 2 8l5 1 7-7-2-4-6 4-1-4Zm40-27q-1-5 2-9l1-7q3-3 4 1l0 7 5-9q3-3 4 1l-4 11 6-6q4-2 4 2l-7 10-9 4Z",
			fill: "#c4b281"
		}),
		/* @__PURE__ */ m("path", {
			d: "m95 72 4 4m-43 33 4-1",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M52 56q4 9 0 14l7 7 6-7 7-14",
			fill: "#b8a36e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 27q-10 6-8 18l6 9 15 8 13-8 1-8 14 8q8 3 10-3 1-5-7-10L76 31l-5-9Z",
			fill: "#c8b27e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 38q-6-6-10-1-3 5 5 8l7-2",
			fill: "#b6a06c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 39q5-2 5 3",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 29q-7 3-9 9l6-1-2 7 7-4m27-10 2 8 4-2-2-8",
			fill: "#303b2e"
		}),
		/* @__PURE__ */ m(_n, {
			x: 56,
			y: 37,
			r: 4.5
		}),
		/* @__PURE__ */ m(_n, {
			x: 70,
			y: 34,
			r: 4
		}),
		/* @__PURE__ */ m("path", {
			d: "M63 47q-6 8-17 5l-12-4 5 7-9-2q6 12 25 8l10-7q9 9 23 0l7-7-7 3 3-8-9 8-12-4Z",
			fill: "#2e3c2d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m40 55 13 3 8-5m13-1 7 1 7-4",
			fill: "none",
			stroke: "#637057",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M31 23q-13-7-13-1 1 12 20 14 24-1 49-10 14-7 12-16-3-5-11 2l-15 5q-2-9-8-16l-7 2 2 12-9-9-7 1-2 15Z",
			fill: "#293d30"
		}),
		/* @__PURE__ */ m("path", {
			d: "M24 23q20 9 60-4m-39 4 5-11 8 11 9-5-4-12m-31 24q31 0 60-12",
			fill: "none",
			stroke: "#56694d",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 165Q64 119 76 78l-2-4-5 1Q58 119 49 165Z",
			fill: "#9f8d5c"
		}),
		/* @__PURE__ */ m("path", {
			d: "m54 151 7-5m5-29 6-3m-2-25 4-2",
			fill: "none",
			stroke: "#6a6244",
			strokeWidth: ".7"
		})
	] });
}
function yn() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M44 116q-11 16-11 31l-6 10 7 6 13-14 8-24m7-11 10 21-9 17 10 5 10-20-6-22Z",
			fill: "#5c7750"
		}),
		/* @__PURE__ */ m("path", {
			d: "m42 123-4 22 3 5m27-26 8 12-7 14m-35 1 10 4m23-8 8 5",
			fill: "none",
			stroke: "#344f39"
		}),
		/* @__PURE__ */ m("path", {
			d: "M27 153q7 4 12 3l-4 7 13 1q6 3-1 6l-18-2-8-6Zm39-5q3 5 9 6l6 5 11 0q6 4-2 6l-15-2-12-5Z",
			fill: "#3c4030"
		}),
		/* @__PURE__ */ m("path", {
			d: "m27 164 14 2m26-9 16 5 7 0",
			fill: "none",
			stroke: "#9a9271",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M46 46q-22-6-27 12l-2 31 21 9 17-19Z",
			fill: "#3e6046"
		}),
		/* @__PURE__ */ m("path", {
			d: "M21 57q15 6 24 1m-26 9q13 6 24 1m-25 10 19 4m-14 2 0-19m10 2-3 22",
			fill: "none",
			stroke: "#8a9e74"
		}),
		/* @__PURE__ */ m("path", {
			d: "M24 42q-5-12 7-16l29 7 1 15-9 6Z",
			fill: "#a7a477"
		}),
		/* @__PURE__ */ m("path", {
			d: "M27 31q-8 8 0 14 10 8 17 1l2-9q-3-7-10-6-7 1-8 7 0 6 6 6 5-1 3-6l-4 0m13-4 9 5m-9 1 9 5",
			fill: "none",
			stroke: "#526243"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 46q-18 3-23 23L14 97q7 14 29 19l13-9 5-24 4-20Z",
			fill: "#956a4b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M32 51q-10 13-10 31l-4 16 12 9 8-10-1-30m14-7q4 14 1 36l-6 13 9-3 7-22-1-17",
			fill: "#6c503c",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M28 59q5-7 11-6l5 10-7 17-9-5m-9 24 13 5m8-10 12 4m-10-16 4 2m-3 5 4 2",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 46q4 13 13 13l-3 9-10-4-6-13m9 9-6 13 2 16 5-9 5 7 0-21",
			fill: "#799282"
		}),
		/* @__PURE__ */ m("path", {
			d: "M28 67q-11 10-11 29l5 17 9-3-3-14 11-16M54 69q4 19 16 30l22-10 4 8q-23 20-35 7L45 87Z",
			fill: "#a77750"
		}),
		/* @__PURE__ */ m("path", {
			d: "m24 78-3 17 4 12m31-25 9 18 24-7m-33 9 7-4",
			fill: "none",
			stroke: "#574532"
		}),
		/* @__PURE__ */ m("path", {
			d: "M21 109q-3 6 2 9l7 3 6-4-4-5-6 0m65-20 7-6 8-1 4 4-7 3 3 3q-2 5-12 4Z",
			fill: "#c6ae7b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m27 118-7 5 12 8 6-4-6-6",
			fill: "#b6bcaf"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 37q-8 7-6 19l10 9 10 4 14-9 4-14 11-5-3-8-13-6Z",
			fill: "#c6b17d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 39q-8-10-13-2-3 8 9 13l4-3m-7-7 3 5m38-12 8-4 4 2-4 6",
			fill: "#b19a67"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 36q3-7 14-5l17 1-3-11-15-3-14 7Z",
			fill: "#303d2f"
		}),
		/* @__PURE__ */ m(_n, {
			x: 60,
			y: 43,
			r: 4.4
		}),
		/* @__PURE__ */ m(_n, {
			x: 78,
			y: 44,
			r: 4
		}),
		/* @__PURE__ */ m("path", {
			d: "M68 43q-1 13 7 19 7 1 6-5l-5-11",
			fill: "#baa16b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 50q-4 15 5 22l7 5 4 10q13-1 18-12l-2-11-10 6-8-7-11-3Z",
			fill: "#6b6948"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 56q7-5 17 5l9-3 3 5-9 5-9-4-7 2m-1 3 7 11m0-12 6 13m0-13 6 10m-25-34 1 9",
			fill: "none",
			stroke: "#b3aa72",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 26q-13-7-10 1 7 13 32 12 21 1 30-13l-9-4-4-11-14-9-10 2 1 7-10 1 2 8Z",
			fill: "#74885b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M38 27q19 10 48-2M49 20q11 7 33 3m-23-17 6 9 14 4M51 13q10 8 20 6M58 23l22 5",
			fill: "none",
			stroke: "#354b35"
		}),
		/* @__PURE__ */ m("path", {
			d: "M71 121q0-25 12-25 16-1 15 24",
			fill: "none",
			stroke: "#ad9d68",
			strokeWidth: "2.5"
		}),
		/* @__PURE__ */ m("path", {
			d: "M64 116q18-7 41 1l-5 24q-2 10-18 8-13 0-17-10Z",
			fill: "#9b8554"
		}),
		/* @__PURE__ */ m("path", {
			d: "m65 120 36 1m-34 5 33 2m-31 3 30 2m-27 4 25 2m-21 3 18 1m-24-22 4 25m3-26 3 29m4-29 3 27m4-27 2 25m4-25-1 22",
			fill: "none",
			stroke: "#4e4e35",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M64 115q19-9 41 0l0 5q-23-6-40 1Z",
			fill: "#b8a372"
		}),
		/* @__PURE__ */ m("path", {
			d: "M72 114q-6-13 4-16 10-2 12 13m3 3q-1-15 9-12l6 9",
			fill: "#bda16a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M103 87q-5-12 2-24l4 1q-3 11 3 21Z",
			fill: "#c8bd88"
		}),
		/* @__PURE__ */ m("path", {
			d: "M93 62q6-12 14-12l15 4 4 7q-14 12-33 1Z",
			fill: "#77935d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M96 61q14 5 27-2m-23-3 6-2m8 3 4 0",
			fill: "none",
			stroke: "#b1ba7d",
			strokeWidth: ".8"
		})
	] });
}
function bn() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M38 99q-11-6-22 3l-5 20q-5 13-9 10-6-3-4 2 3 9 12 2 9-7 11-19l9-5",
			fill: "#8d9585"
		}),
		/* @__PURE__ */ m("path", {
			d: "M30 96q18-15 43 3l11 16-5 18-15 5-24-9-10 19 0 10-8 1-3-7 5-24q-8-13-4-24Z",
			fill: "#8f9989"
		}),
		/* @__PURE__ */ m("path", {
			d: "M36 110q-8 14 7 20l18-5 13-11-7-14q-16-8-31 10Z",
			fill: "#6e7d71",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M73 107q-4 25-7 40l6 12 10 0 0-4-6-5 10-28m8-9q6 15 2 31l5 11 11-1-1-5-8-5 2-24",
			fill: "#9ba290"
		}),
		/* @__PURE__ */ m("path", {
			d: "m69 153 7 3m4-1 1 3m21-8 3 4m4-5 2 3m-88 1 6 2m-5-27 8 1",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M71 72q0-16 19-20 23 0 29 17l-1 25q-4 28-27 31-20-2-23-20Z",
			fill: "#8a9381"
		}),
		/* @__PURE__ */ m("path", {
			d: "M77 78q-4 26 12 39l11-2q-16-9-14-31m20-23q12 9 9 29l-9 16-6-4 4-22",
			fill: "#667665",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M78 59q-15 1-17 19l1 23q4 8 12 5 10-7 9-28l4-16Z",
			fill: "#b1ae8c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M70 64q-6 14-4 30m8-16-3 20m16-44q9-9 17 1l4-3 8 10",
			fill: "none",
			stroke: "#66755f"
		}),
		/* @__PURE__ */ m(_n, {
			x: 94,
			y: 76,
			r: 5
		}),
		/* @__PURE__ */ m(_n, {
			x: 110,
			y: 70,
			r: 4.5
		}),
		/* @__PURE__ */ m("path", {
			d: "M98 83q9-11 21-1l7 13-5 13-20 0-9-10Z",
			fill: "#b2ad88"
		}),
		/* @__PURE__ */ m("path", {
			d: "M111 83q10-4 13 4l-2 7-9 1-6-6Z",
			fill: "#4c5948"
		}),
		/* @__PURE__ */ m("path", {
			d: "m113 86 0 4m6-4 1 3m-19 8 5 1m-7 4 3 0m5-1 2 0m10 1 2 1M103 108q6 7 17-2",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M109 109q-3 12 5 14 6-2 5-14",
			fill: "#ba8f79"
		}),
		/* @__PURE__ */ m("path", {
			d: "m113 111 1 9",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M80 101q-1 13 10 18m-7-14 9 10m-16-1q5 12 18 12",
			fill: "none",
			stroke: "#485f50"
		})
	] });
}
function xn() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m(bn, {}),
		/* @__PURE__ */ m("path", {
			d: "M48 102q-7 17-7 41l-3 13 10 3 6-20 6-22m4-13q11 15 11 34l6 12-8 8-9-16-5-23Z",
			fill: "#71949d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 127q1-9 7-11l2 10-4 8-7-1m25-4 6-5 2 12-5 4-5-3",
			fill: "#c6b18b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m46 120-4 6 2 10m7-18 5 3m12 1 7 1m-7 15 3 4m-25-5 3 9m6-30 5 1 4 19",
			fill: "none",
			stroke: "#354f51"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 151q5 5 11 2l1 10 11 5q4 5-5 6l-17-6-3-8Zm32-6q4 3 8 0l3 12 12 1q5 4-1 6l-19-2-5-7Z",
			fill: "#47483a"
		}),
		/* @__PURE__ */ m("path", {
			d: "m40 165 15 6m19-13 13 2m-44-15 7 3m24-8 5-1",
			fill: "none",
			stroke: "#aa9d72",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 59q13-5 26 3l6 35-6 14q-16 3-28-6l-5-20Z",
			fill: "#e7e4ca"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 76q4 13 22 11m-20 8q8 7 25 5m-29 3q13 8 29 2m-17-40 4 6 9-5",
			fill: "none",
			stroke: "#879789"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 64q-9-7-14 4l-8 20 10 6 13-18m22-11q8-6 13 2l-2 13-6 3-8-10",
			fill: "#f0e9cf"
		}),
		/* @__PURE__ */ m("path", {
			d: "m24 75 11 5m-11 0 7 3m37-13 6 4m-3 2 4 2",
			fill: "none",
			stroke: "#9aa091"
		}),
		/* @__PURE__ */ m("path", {
			d: "M22 86q-7 13 6 19l15 6 5-5-16-9 0-8m40-10q6 2 6 10l-2 5 14-17 8 0-2 5-6 2q-10 23-17 18-7-6-8-20",
			fill: "#c5b181"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 105q3-4 8 0l4 5-2 3-8-3m44-29 5-7 4-1 5 2-4 4-7 1",
			fill: "#c6b284"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 55q5 8 2 12 9 8 17-1l1-13",
			fill: "#b5a074"
		}),
		/* @__PURE__ */ m("path", {
			d: "M35 25q-8 5-8 19l9 13 16 6 12-10 3-14-5-16Z",
			fill: "#cbb58b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M54 43q6-3 13 2l5 5-4 6-10-3m-22-10q-8-8-11-1-3 6 7 9l5-1",
			fill: "#bca579"
		}),
		/* @__PURE__ */ m(_n, {
			x: 47,
			y: 37,
			r: 4.5
		}),
		/* @__PURE__ */ m(_n, {
			x: 61,
			y: 33,
			r: 4
		}),
		/* @__PURE__ */ m("path", {
			d: "M38 49q5 7 14 6l4 3-7 2-5-3m-7-8 1 0m2 3 1 0m-2-8 1 0",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M30 25q-9 0-12 8l7-2-9 11 7-2-5 10 9-3-5 10 10-5-1 11 8-8-1-21 9-10 19 6 4 12 8 2-3-8 8 0-8-8 5-2-12-10Z",
			fill: "#8a754e"
		}),
		/* @__PURE__ */ m("path", {
			d: "m27 29-4 6m7 0-5 9m6 0-4 9m8-18-5 13m40-21 5 8m-7-1 5 9",
			fill: "none",
			stroke: "#c1aa70",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M20 20q-13-6-11 1 11 13 40 10 27-2 31-15l-15-2-4-12-10-2-17 2-4 12Z",
			fill: "#b8ad7c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M31 13q14 9 33 0l2 6q-19 9-36 1Z",
			fill: "#4e7278"
		}),
		/* @__PURE__ */ m("path", {
			d: "M13 20q24 13 61-3M33 5q14 7 25-1m-24 5 10-5m0 9 9-6m-32 16 5-5m0 7 5-5m32 0 4 5",
			fill: "none",
			stroke: "#6f7452",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "m53 56 10 4 12 9m-12-8 5-4 5 2m-7 5 6 0 7 5m-10-2 0 6 5 4",
			fill: "none",
			stroke: "#756c42",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ m("path", {
			d: "M36 62q-10 11-9 26m36-23q-1 15 5 24",
			fill: "none",
			stroke: "#6d7150",
			strokeWidth: "4"
		})
	] });
}
function Sn() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M44 66q-18-15-30-1-7 14-5 30l-2 29q8 16 29 12l17-27Z",
			fill: "#3f6d50"
		}),
		/* @__PURE__ */ m("path", {
			d: "M15 67q10 10 24 5m-26 3q5 13 23 9l-2 19-18-3Zm-3 37q14 8 24-1m-24 10q12 10 25 0m-11-48-4 13m-2 5-2 16",
			fill: "none",
			stroke: "#90a17a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M23 64q-8-3-9-10 3-8 10-7l15 6 1 12Z",
			fill: "#8ca187"
		}),
		/* @__PURE__ */ m("path", {
			d: "m19 52 15 7m-12-3 1 7",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M11 104q-11 1-10 12 3 11 16 13l14-4 5-11-9-13Z",
			fill: "#82999a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M5 111q11-9 22 1l-1 11q-11 8-19-1-7-9 2-12 8-3 12 5 2 6-4 8-6 1-6-5l5-2m13-7 5 4m-4-12 7 4",
			fill: "none",
			stroke: "#3e6157"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 119q-9 13-20 22l-4 11 8 7 16-17 9-18m11-9q10 14 17 24l12 10 6-6-12-14-9-15Z",
			fill: "#bba16e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M22 148q5 6 10 6l-5 9 10 2q5 4 0 6l-13-2-7-9Zm68-12q5 3 8-1l3 10 12-3q7 0 4 6-9 9-23 7l-3-4Z",
			fill: "#424438"
		}),
		/* @__PURE__ */ m("path", {
			d: "m23 167 10 1m63-17q11 0 17-6",
			fill: "none",
			stroke: "#b5a57f",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 100q-10 9-14 30l12 7 17-14 9 10 18-8-10-25Z",
			fill: "#638055"
		}),
		/* @__PURE__ */ m("path", {
			d: "m43 108-9 20m18-19-9 18m12-21 4 13m8-12 7 17m-18-11 2-7m-20 29 7-1m19-2 7 0",
			fill: "none",
			stroke: "#334f39"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 63q-13 5-15 19l6 23q16 10 33 0l5-17-9-22Z",
			fill: "#c1a663"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 76q-4 17 4 26l13 3-4-28m12-7q5 16 5 29l-7 4",
			fill: "#a68c51",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "m51 76 4 25m7-23 6 17m-24 7 10 2m7-14 2 0m-1 6 2 1",
			fill: "none",
			stroke: "#675a37"
		}),
		/* @__PURE__ */ m("path", {
			d: "M49 60q4 9 14 7l5 7-11 6-7-5-5 7-7-15Z",
			fill: "#d2bf7b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m50 70 6 4-2 12 7-6 3 2-2-10",
			fill: "#dac68b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 72q-9 6-10 21 1 12 21 16l5-8-15-8 4-14m22-9q10 1 14 15l-4 10-8-2 2-8-9-7",
			fill: "#cbb16d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M35 82q-3 11 4 15l12 6m18-22 6 3m-38 7 7 1",
			fill: "none",
			stroke: "#817044"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 41q-9 10-5 18l10 9 15-5 7-11 2-20-13-10-19 8Z",
			fill: "#bd9b6a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M62 46q6-8 12-3l7 6-3 5-13 0M41 45q-9-6-10 1-1 5 8 8",
			fill: "#b3905f"
		}),
		/* @__PURE__ */ m(_n, {
			x: 53,
			y: 43,
			r: 4.2
		}),
		/* @__PURE__ */ m(_n, {
			x: 68,
			y: 39,
			r: 3.6
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 57q8 6 15-1l-4 6-7 0Z",
			fill: "#554933"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 27q-8-7-14-1-8-1-9 6-10 0-8 8-6 5-1 10-6 8 3 12-2 8 8 9l12-7 11-11-2-13 10-12 21 5 7 12 5 2 4-4-5-3q8-8 1-11 6-7-4-10-1-9-10-7Z",
			fill: "#333f30"
		}),
		/* @__PURE__ */ m("path", {
			d: "M24 28q-7 5 0 8 9-1 4-6m-13 10q-5 7 3 7 7-4 1-7m11-1q-6 5 0 9 7 0 4-7m-21 12q-3 7 5 5 6-4 1-7m10 1q-8 7 0 9 6-3 2-7m46-26q-4 4 1 7m1 2q-4 5 2 6m-44-13 5 2m-12 29-5 5",
			fill: "none",
			stroke: "#68725a",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M27 20q-14-5-11 2 10 12 33 9 24-1 32-12l-15-3q0-17-16-18-18-1-23 22Z",
			fill: "#b4a165"
		}),
		/* @__PURE__ */ m("path", {
			d: "M28 14q16 8 35-2l3 6q-18 10-40 3Z",
			fill: "#5e5b3d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M21 23q27 9 53-3M33 4q-6 11 4 12 12-1 8-9m9-8q-2 9 5 10m-20-8 0 6",
			fill: "none",
			stroke: "#776e42"
		}),
		/* @__PURE__ */ m("path", {
			d: "M34 69q-10 16-5 25m14-22q-9 10-7 21",
			fill: "none",
			stroke: "#3b5840",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ m("path", {
			d: "M56 88q14-1 24 4l17-9-1 28-17 12-24-11Z",
			fill: "#456f52"
		}),
		/* @__PURE__ */ m("path", {
			d: "m58 90 21 5 17-9-3-3-14 7-19-4Z",
			fill: "#d5d3a7"
		}),
		/* @__PURE__ */ m("path", {
			d: "m79 95-1 28m-19-28 15 4m-15 1 15 4m-15 2 14 4m11-14 10-6m-10 11 9-6m-9 11 9-7",
			fill: "none",
			stroke: "#89a07a",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 102q4-7 8-5l3 5-5 1 6 4-1 4-11-3m40-15 5-4q4-1 4 3l-3 5 3 3-2 4-6 0",
			fill: "#bca16b"
		})
	] });
}
function Cn({ leader: e }) {
	return /* @__PURE__ */ m("g", {
		stroke: gn,
		strokeWidth: "1.2",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		transform: "translate(3 5) scale(.96)",
		children: m(e === 0 ? vn : e === 1 ? yn : e === 2 ? xn : Sn, {})
	});
}
//#endregion
//#region src/games/pilgrims/scene-heads.tsx
function Z({ x: e, y: t, r: n = 3 }) {
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("ellipse", {
		cx: e,
		cy: t,
		rx: n,
		ry: n * 1.3,
		fill: "#f3e6c3"
	}), /* @__PURE__ */ m("ellipse", {
		cx: e + .7,
		cy: t + .4,
		rx: n * .4,
		ry: n * .65,
		fill: "#393c2d",
		stroke: "none"
	})] });
}
function wn({ card: e }) {
	switch (e) {
		case 27: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M22 55 19 68l19 6 10-9-5-14",
				fill: "#ac946b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M19 25q19-13 31 0 5 7 1 14 10 0 14 12 7 14 0 15-5-1-8-13l-3-6q-1 8-10 7-1 12-9 13-14-1-19-16-9-10-4-20Z",
				fill: "#c4aa78"
			}),
			/* @__PURE__ */ m("path", {
				d: "M17 24Q3 38 8 60l-8 8 14 5 11-10-5-17 7-21Z",
				fill: "#5f7075"
			}),
			/* @__PURE__ */ m("path", {
				d: "M18 28Q9 40 14 59m7-26q-5 13-3 22m-7 6 6 3",
				fill: "none",
				stroke: "#9aa6a2"
			}),
			/* @__PURE__ */ m(Z, {
				x: 29,
				y: 35,
				r: 4.7
			}),
			/* @__PURE__ */ m(Z, {
				x: 48,
				y: 32,
				r: 4
			}),
			/* @__PURE__ */ m("path", {
				d: "M20 28q9 4 16 0m6-1 11-4M22 48q9-7 16 1m-13 2 7 3m2-11-2 5 9-1m-15 14 7 1m2-11 8 2",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M16 24q-3-13 15-15 15-4 24 7l-21-1-13 13m-5-4L7 14l4-4 9 8 1-12 4-3 1 15",
				fill: "#65777c"
			}),
			/* @__PURE__ */ m("path", {
				d: "M13 65q15 7 27 1l10 7-14 4-6-4-9 6-12-7Z",
				fill: "#a97458"
			})
		] });
		case 26: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M24 51q0 8-4 13l7 8 19-4-4-17",
				fill: "#c3a775"
			}),
			/* @__PURE__ */ m("path", {
				d: "M19 22q13-10 28 0l1 15q1 3 9 6 5 5-2 8l-11-1-3 11q-5 7-13 2-12-6-14-20l-5-7 5-9Z",
				fill: "#d8bc85"
			}),
			/* @__PURE__ */ m("path", {
				d: "M15 35q4-7 8 0l-1 11-5-1-3-6m30-9 3 9 4 4m-28 9 3 6 10 4",
				fill: "#c2a36d",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M8 30q-4-11 7-17 1-10 14-8 10-8 22-2l13 0q-1 8-11 12l-14 3q-5 10-13 11l-6-1q-2 11-9 15l-6-1 5-7-11 2 7-8Z",
				fill: "#c4a25d"
			}),
			/* @__PURE__ */ m("path", {
				d: "M12 24q17-2 29-10m-18 7 19-13m-2 12 17-9m-44 21 8-7m-8 9-5 4",
				fill: "none",
				stroke: "#8d743f"
			}),
			/* @__PURE__ */ m(Z, {
				x: 39,
				y: 32,
				r: 3.8
			}),
			/* @__PURE__ */ m("path", {
				d: "M33 26q6-6 12-1m-11 19 4 1m-11 7q8 6 15-1m-24-17 3 3m5 28 8-4 9 6-6 6-9-4-7 3-4-7",
				fill: "none"
			})
		] });
		case 9: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M14 43q-4 14 8 22l19 4 13-13-5-15Z",
				fill: "#c4a365"
			}),
			/* @__PURE__ */ m("path", {
				d: "M17 41q-3-8-12-5l5 7-8 2 13 3m34-6 11-6-3 8 8 1-14 6",
				fill: "#b49558"
			}),
			/* @__PURE__ */ m("path", {
				d: "M21 38q11-9 25-1l-1 13 13 5-4 5-13-2-2 10q-8 7-17-3l-4-12Z",
				fill: "#cbb17b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M19 51q6 0 11 10l5-4q9 8 17 4l-2 8-8 3-8-3-4 6-6-6-7 1-2-9-6-5Z",
				fill: "#b89b5b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M13 38q14-15 42-6l3 7-14 4-7-3-9 4-9-1-8 3Z",
				fill: "#bda369"
			}),
			/* @__PURE__ */ m("path", {
				d: "M18 33Q28 16 31-7q5 23 20 36l-4 8-15 2Z",
				fill: "#536e86"
			}),
			/* @__PURE__ */ m("path", {
				d: "M31 0q0 21 10 32m-10-19-5 17m-2 9 9-3m-11 19 7 10m9-4 5 6m-7-20 3 4m-11 8 3 6",
				fill: "none",
				stroke: "#3b515d"
			}),
			/* @__PURE__ */ m(Z, {
				x: 27,
				y: 45,
				r: 3.4
			}),
			/* @__PURE__ */ m(Z, {
				x: 41,
				y: 44,
				r: 3.2
			}),
			/* @__PURE__ */ m("path", {
				d: "m34 44-4 13 7-1m-10 7 10 1m-18-24 6-3m16-1 7 2",
				fill: "none"
			})
		] });
		case 0: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M22 51 20 65l18 6 9-11-3-9",
				fill: "#b69d6b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M14 31q10-14 29-7l4 10-2 9 14 5q5 5-1 8l-11-2-3 10-12 4-14-8-5-13-6-7Z",
				fill: "#c6ac77"
			}),
			/* @__PURE__ */ m("path", {
				d: "M14 32q-8 3-7 12l-4 8 9-1 6-9m26-13q10-3 11 6l-9 8m-27 8q-10 9-16 5 0 9 12 8l14-7q7 6 17 1l-1-7-12-3-7 4Z",
				fill: "#4d5544"
			}),
			/* @__PURE__ */ m("path", {
				d: "M4 29q8-9 18-7l1-16 9-4 9 15 12-5q8-5 12 1 1 7-12 16-21 12-44 8-9-1-6-8Z",
				fill: "#586745"
			}),
			/* @__PURE__ */ m("path", {
				d: "M22 21q7 4 18-2m-25 10 18-4m-6 8 20-7m-20-12 2-5m-4 52 8-3m5 4 7-2",
				fill: "none",
				stroke: "#8e9870"
			}),
			/* @__PURE__ */ m(Z, {
				x: 35,
				y: 38,
				r: 4
			}),
			/* @__PURE__ */ m("path", {
				d: "M29 32q5-4 10-1m-15 15 7 1m4-6 0 3",
				fill: "none"
			})
		] });
		case 1: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M9 64q7-15 7-32-10-6-12-13 19-15 45-15l15 11-16 9-6 37-14 9Z",
				fill: "#a9704c"
			}),
			/* @__PURE__ */ m("path", {
				d: "M8 20Q27 20 47 9L32 37l-3 26-11-7Z",
				fill: "#bd8a5c"
			}),
			/* @__PURE__ */ m("path", {
				d: "M34 26q10-5 16 3l3 6q14-3 15 6 1 7-10 8l-9-2q3 9-1 15l-9 3q-14-5-15-20l2-12Z",
				fill: "#d0b17b"
			}),
			/* @__PURE__ */ m(Z, {
				x: 45,
				y: 36,
				r: 3.3
			}),
			/* @__PURE__ */ m("path", {
				d: "M39 30q5-3 10-1m-12 12 5 1m-6 2 5 2m4 5 9 0m-18 2q6 7 13 3m-12 5 4 1M17 29l10-6m-8 13 7-5m-6 16 6-9m4 23 1-9",
				fill: "none"
			})
		] });
		case 21: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M21 56 18 67l17 7 15-7-7-13",
				fill: "#b39c6f"
			}),
			/* @__PURE__ */ m("path", {
				d: "M17 28q8-10 24-4l6 10-3 11 13 5-1 5-11 0-6 11q-14-2-21-14L13 36Z",
				fill: "#c2a876"
			}),
			/* @__PURE__ */ m("path", {
				d: "M15 30q-7 5-7 15l-6 4 12 4 6-14m23-13q10 1 10 10l-7 9m-26 6q-10 11-15 7 4 10 16 3l12-4q7 8 18 3l-6-6-11-5-9 7Z",
				fill: "#5b5b46"
			}),
			/* @__PURE__ */ m("path", {
				d: "M7 26q3-5 13-5L18 1q13-5 26 0l2 21 14 2q0 10-26 12-19 0-27-10Z",
				fill: "#627487"
			}),
			/* @__PURE__ */ m("path", {
				d: "M22 4q9 3 20 0m-19 1 1 16m5-14 1 16m6-15 1 14m5-15 1 13M14 28q20 5 38-1",
				fill: "none",
				stroke: "#9da9a6"
			}),
			/* @__PURE__ */ m(Z, {
				x: 33,
				y: 36
			}),
			/* @__PURE__ */ m("path", {
				d: "M28 30q5-4 10 0m-15 13 7 1m-12 23 4-7 5 10 5-7 5 9 5-10 6 6",
				fill: "#ded7b5"
			})
		] });
		case 18: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "m24 54-3 12 16 6 9-10-4-12",
				fill: "#bca26c"
			}),
			/* @__PURE__ */ m("path", {
				d: "M17 29q10-11 25-3l1 15 15 5-1 5-13 0-5 12q-10 7-22-12l-5-14Z",
				fill: "#cfb380"
			}),
			/* @__PURE__ */ m("path", {
				d: "M18 29q-12-2-12 8l-5 5 9 2-4 9 13-7 0-9m22-9q12-1 12 8l-8 6m-24 19 9 7 11-7",
				fill: "#b49d58"
			}),
			/* @__PURE__ */ m("path", {
				d: "M7 25q-1-7 14-7L24 3l18 1 4 13q16-1 18 5-13 11-35 12-14-1-22-9Z",
				fill: "#607d8d"
			}),
			/* @__PURE__ */ m("path", {
				d: "M22 15q11 5 22 1m-23 2 1 6 23-2 1-5M12 26q16 5 38-2",
				fill: "none"
			}),
			/* @__PURE__ */ m(Z, {
				x: 34,
				y: 36,
				r: 3.7
			}),
			/* @__PURE__ */ m("path", {
				d: "M28 29q5-3 11 0m-15 19q5 7 13 2m-17-9 4 1m9 0 2 1",
				fill: "none"
			})
		] });
		case 24: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M18 31q8-12 25-6l1 13 13 7-2 6-12-2-4 13q-7 11-19-2l-8-18Z",
				fill: "#c8ad77"
			}),
			/* @__PURE__ */ m("path", {
				d: "M12 32q-6 9-1 22l10 6-4-8 6 3m18-26 8 9-6 6M18 49q8 1 11 10 7-5 15-4l-3 12-9-2-7 9-7-9-8-3-5-10Z",
				fill: "#b6b7a0"
			}),
			/* @__PURE__ */ m("path", {
				d: "M8 27q1-6 12-6L17 8q6-9 18-7l13 5 10 4-15 2-1 9q11-2 15 4-12 11-32 9-14 0-17-7Z",
				fill: "#7f906f"
			}),
			/* @__PURE__ */ m("path", {
				d: "m21 9 14-3 11 4m-29 18 20 1m-18 28 6 9m5-8 0 7m6-10 0 6",
				fill: "none"
			}),
			/* @__PURE__ */ m(Z, {
				x: 34,
				y: 35,
				r: 3.6
			}),
			/* @__PURE__ */ m("path", {
				d: "M28 29q5-4 11-1m-13 13 4 1",
				fill: "none"
			})
		] });
		case 31: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "m25 55-3 13 16 6 9-12-5-10",
				fill: "#c6ab78"
			}),
			/* @__PURE__ */ m("path", {
				d: "M18 25q12-8 24 1l3 14 12 6-2 5-12 1-4 10q-7 9-17-2l-9-14-3-10Z",
				fill: "#dbc18b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M10 30q-3-12 8-17 15-9 34 4l-3 13-9-8-9 7-7-3q-2 14-9 15l-5 10-7-1 5-9-7 1 6-8Z",
				fill: "#bda15d"
			}),
			/* @__PURE__ */ m("path", {
				d: "M11 19q15-13 32-7l10 7-14 3-10-7-11 8Z",
				fill: "#aab196"
			}),
			/* @__PURE__ */ m(Z, {
				x: 35,
				y: 34,
				r: 3.7
			}),
			/* @__PURE__ */ m("path", {
				d: "M30 28q4-3 10 0m-15 18q5 8 13 3m-14-14 2 4m-13-14 8-5m-8 10 6-6",
				fill: "none"
			})
		] });
		default: return null;
	}
}
//#endregion
//#region src/games/pilgrims/adventure-objects.tsx
function Q() {
	return /* @__PURE__ */ h("g", {
		stroke: "#82977d",
		strokeWidth: ".7",
		fill: "none",
		children: [
			/* @__PURE__ */ m("path", { d: "M5 107Q23 61 3 8m1 32 25-23M5 55 28 35M9 75 29 59M8 96 22 82m153 27q-26-51 2-102m-2 27-20-14m17 29-24-15m19 35-19-9m22 23-17-5" }),
			/* @__PURE__ */ m("path", {
				d: "M2 20q15 6 23-9-17-2-22 5m-1 28q18 4 25-12-18 1-23 8m170-11q-11-16-23-10 4 14 21 15m-3 19q-12-16-26-12 5 15 24 18",
				fill: "#a4b89b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M5 141q-5-22 3-29l8 23-1-29 12 27q-3-20 6-22l-2 29m143-2-10-26 0 20-9-17 4 24",
				fill: "#8fa587"
			})
		]
	});
}
function Tn({ x: e = 45, y: t = 106, s: n = 1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-22-6q-6-18 7-25 9-7 20-3Q31-28 27-6 21 10 5 16l-8 13-5-1 1-13q-19-5-15-21Z",
				fill: "#9a96a3"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-20-14q3-15 18-16 15-1 24 8l-6 10q-15-10-31 2m-1 12q9 10 22 9l-7 7-8 0Z",
				fill: "#b7b2b0",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M0-32q-13-15-9-43l4-13 5 12 2 23 7-32 8-11 1 14-6 28q10-21 25-27l9 1-4 9-23 24 22-12 14 2-4 7-27 14Z",
				fill: "#b6a259"
			}),
			/* @__PURE__ */ m("path", {
				d: "M1-30-2-69m4 31 10-32m-7 36 27-30m-34 40-12 9m4-4 7-1m-9 7 10-2m-8 7 14-2m-8 7 10-2m-3 7 4-3",
				fill: "none",
				stroke: "#786c4e",
				strokeWidth: ".8"
			})
		]
	});
}
function En({ x: e, y: t, s: n = 1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-26-14q-5-34 9-42 22-13 36 12l6 30-5 1q-4-36-19-39-22-5-20 39Z",
				fill: "#b2a16c"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-21-42 5 2m-2-8 6 3m-1-8 3 5m6-8 1 6m6-5-2 5m8-2-4 4m8 3-5 2m8 4-5 1m6 7-5 0",
				fill: "none",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-31-17q32-8 63 0l-7 39q-3 8-25 8-20 0-24-8Z",
				fill: "#b5985e"
			}),
			/* @__PURE__ */ m("path", {
				d: "M10-15 31-17l-7 38q-6 7-21 9l8-34Z",
				fill: "#8e794c",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-31-17q32-9 63 0l-2 6q-30 7-59 0Z",
				fill: "#d0b77f"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-25-6 52 0m-50 7 49 0m-48 7 46 0m-44 7 42 0m-39 7 34 0m-33-30 4 31m4-32 2 35m6-35 0 36m7-36-2 35m8-36-5 35m10-37-6 34",
				fill: "none",
				stroke: "#746443",
				strokeWidth: ".65"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-25-20q-4-20 9-23 10-2 13 17m5 5q-3-24 10-24 15 3 13 25",
				fill: "#b4b27b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-18-38q-14-9-9-15 9-2 12 11l4-17 6 0-6 19m24-2q-6-14 1-17 6 1 4 14l8-10 5 4-11 13",
				fill: "#789565"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-7-21q-7-7-2-13 8-8 15-1l3 13m-27-4q-6-7-11-1l-1 9 17 2m21-2q3-12 12-9 7 4 3 12",
				fill: "#bd8d68"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-17-34 4 7m-13 5 9 2m26-12 6 6m-16-4 0 8",
				fill: "none",
				stroke: "#82754b",
				strokeWidth: ".7"
			})
		]
	});
}
function Dn({ x: e, y: t, s: n = 1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-13 11q-8 12-6 20l-8 8 1 4 12-6 6-19m20-6 1 18 8 7 6-1-1-4-7-6 0-14",
				fill: "#aa9872"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-21 36 5 2-4 5-9 1m48-12 6 0 4 6-7 0Z",
				fill: "#656954"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-27-11q-13-7-17 3-13 1-11 12-1 10 12 12 2 12 15 6 8 12 18 3 15 8 23-3 13 5 17-7 10-6 2-16-1-12-13-11-10-12-20-5-13-7-20 6Z",
				fill: "#e4dfc2"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-51 6q11-3 17 4 10-5 18 3 14-4 23 4l12-3-5 9-17 0-8 4-11-5-16 3-7-7-8-2Z",
				fill: "#c7c7a7",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-34-17q-8-10-16-3l-3 8-11 3-1 7 11 5 15-2 7-9 10-4-1-6-7 2Z",
				fill: "#b6a276"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-33-15q4-11 13-6 5 8-7 10m-24-3 4 3m-15 11 8-1m-4-4 5 1",
				fill: "none"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "-44",
				cy: "-12",
				rx: "2.4",
				ry: "3",
				fill: "#f0e7c6"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "-44.5",
				cy: "-12",
				r: "1",
				fill: "#384031"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-37-4q8-6 12 0m-15 9q7-6 11 0m5-12q9-6 13 0m-7 9q9-6 14 1m3-11q9-6 13 0m-7 10q10-5 14 2m-32 14q7-6 12 0m9-2q8-4 12 1",
				fill: "none",
				stroke: "#9b9e83",
				strokeWidth: ".8"
			})
		]
	});
}
function On() {
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: "M88 116 92 137q21 11 43-1l4-22",
			fill: "#9b7d50"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "113",
			cy: "115",
			rx: "26",
			ry: "9",
			fill: "#c0a16d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m96 119 2 17m8-15 1 19m11-19 0 19m10-20-2 16m-25-19 14 3 12-5",
			fill: "none",
			stroke: "#6c5e42",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M83 98q-12-1-15-8l38-4 33 4 6 9-20 9-3 9-17 2-2-14Z",
			fill: "#6f8584"
		}),
		/* @__PURE__ */ m("path", {
			d: "M69 88 105 81l37 6-3 6-35 2Z",
			fill: "#bcc6b4"
		}),
		/* @__PURE__ */ m("path", {
			d: "M105 95 139 91l6 8-20 9-3 9-12 2 3-13Z",
			fill: "#516965",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "m78 89 21-3m8 0 23 2m-26 16 10 3m2-3 13-6m-18 15 7-1",
			fill: "none",
			stroke: "#9cae9f",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M105 88q-9-3-10-13l1-9 7-3 3 6-3 4q-2 6 4 8 7 2 11-5l-1-7 6-2 4 5q0 13-12 17Z",
			fill: "#ced0b5"
		}),
		/* @__PURE__ */ m("path", {
			d: "m99 69 3 1m-3 6 3 0m17-3 4-1m-7 10 3 1",
			fill: "none",
			strokeWidth: ".8"
		})
	] });
}
function kn() {
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: "M30 94Q17 66 38 44q17-18 45-13 30-14 57 7 27 20 22 49-2 20-25 34l-64 2Z",
			fill: "#72996f"
		}),
		/* @__PURE__ */ m("path", {
			d: "M117 54q29-3 38 23 6 16-13 33l-9-9q18-15 0-27",
			fill: "#547c55",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 84q-26 3-27 24-1 10 15 11l18-8m75-30q31 3 35 24 2 12-12 17l-22-10",
			fill: "#6a9063"
		}),
		/* @__PURE__ */ m("path", {
			d: "M36 92q-13 0-12 13 2 10 16 6m97-14q16-8 21 4 4 10-9 15",
			fill: "none",
			stroke: "#a2b581"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 91q-5 35 26 40 34 7 59-15-4-20-21-29Z",
			fill: "#a0b17f"
		}),
		/* @__PURE__ */ m("path", {
			d: "M61 102q13 14 39 11l21-9m-56 10q18 13 42 7m-34 4q20 9 39-1m-56-22q-1 12 9 20m58-18q1 11-7 20",
			fill: "none",
			stroke: "#536f4d",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 80q-13 8-12 22l8 12-6 8-9-1q-6 1-5 4 2 3 11 3l-6 7q-1 5 3 4l11-10-1 10q2 5 5 0l4-14 8-6q11-14 7-24m62-15q18 9 18 24l-8 11 4 9 9-2q6-1 6 3-1 3-10 5l7 6q2 5-2 5l-13-10 3 12q-1 5-4 1l-6-15-11-5q-11-11-8-25",
			fill: "#7d9f6b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 85q-7 14 4 25m10-18q-5 11-1 17m77-23q10 11 1 23m-10-14q4 8 1 15m-82 9 4 3m89-7-3 4",
			fill: "none",
			stroke: "#4d754e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M37 54q-18 6-22 21-6 13 8 20 9 8 28 3 16-6 38 3 31 10 52-2 18-4 19-17-1-16-21-23-46-17-102-5Z",
			fill: "#86a472"
		}),
		/* @__PURE__ */ m("path", {
			d: "M29 71q24-12 44-6 21 7 39 3 25-2 32 12 5 9-9 11-12 1-27-6-11-3-25 0-12 4-24-2-11-6-22 0-21 7-18-3 1-6 10-9Z",
			fill: "#aa9780"
		}),
		/* @__PURE__ */ m("path", {
			d: "M21 79q17-13 36-4 15 7 25 2 20-6 34 1 17 11 27 4",
			fill: "none",
			stroke: "#4e5940",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ m("path", {
			d: "m26 72 2 6m13-9 1 6m14-5-1 6m13-1-2 7m16-7 1 7m13-10 2 6m12-4 0 7m10-4-1 7m14-2-2 5",
			fill: "none",
			stroke: "#786d5b",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M32 54q-7-24 8-29 18-6 22 17m46 1q-2-25 15-24 20 2 16 27",
			fill: "#8faa77"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "45",
			cy: "35",
			rx: "10",
			ry: "12",
			fill: "#d3c88c"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "124",
			cy: "32",
			rx: "10",
			ry: "11",
			fill: "#d3c88c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M38 31q1 12 11 9m68-10q9 9 16-1",
			fill: "none",
			stroke: "#3c4c38",
			strokeWidth: "2.8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M33 48q7 5 16 2m66-5q11 4 21-2M70 54l0 3m11-4 3 1m-18 43q-14 4-23 0m85 0q13-2 18-7",
			fill: "none",
			stroke: "#405e40",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ h("g", {
			fill: "#b1bd88",
			children: [
				/* @__PURE__ */ m("ellipse", {
					cx: "37",
					cy: "60",
					rx: "4",
					ry: "2.5"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "65",
					cy: "42",
					rx: "4",
					ry: "2"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "83",
					cy: "40",
					rx: "3",
					ry: "2"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "143",
					cy: "58",
					rx: "5",
					ry: "2.5"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "150",
					cy: "77",
					rx: "3",
					ry: "2"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "138",
					cy: "102",
					rx: "4",
					ry: "2.5"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "43",
					cy: "99",
					rx: "3",
					ry: "2"
				})
			]
		}),
		/* @__PURE__ */ m("path", {
			d: "M63 141q17-7 35-4m-55 7-11-3m108-5 7 4m-93 2 4-7m-26 3-7-5",
			fill: "none",
			stroke: "#8eae8b",
			strokeWidth: ".8"
		})
	] });
}
function An() {
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: "M18 65 75 42l37 23-4 66-88 2Z",
			fill: "#b5b595"
		}),
		/* @__PURE__ */ m("path", {
			d: "M75 43 111 64l-3 67-36-10Z",
			fill: "#949f85"
		}),
		/* @__PURE__ */ m("path", {
			d: "M9 64 72 24l49 37-8 9-43-28-53 30Z",
			fill: "#718e85"
		}),
		/* @__PURE__ */ m("path", {
			d: "M12 62 72 29l40 30-1 5-40-27-53 31Z",
			fill: "#9ab0a0",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M35 132V87q8-15 22-6l5 8-1 42",
			fill: "#6b806c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 131V90q5-10 16-6l0 47M78 72 96 79 94 96 77 91Z",
			fill: "#c3c4a3"
		}),
		/* @__PURE__ */ m("path", {
			d: "m86 77-1 16m-7-10 17 5M23 115l11-2m28 9 7-2m9-11 14 4m-68-22 8-2M26 75l11-3M42 60l14-5m23-9 8 5m-6 6 10 6m-7-3 0 7M61 33l7 6m-16 2 6 5m17-4 4-5m-42 12 7 6m-17-1 7 6",
			fill: "none",
			stroke: "#637966",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M26 21 33 19 38 43l-8 4Z",
			fill: "#a1aa8f"
		}),
		/* @__PURE__ */ m("path", {
			d: "M23 18 33 15 37 20 26 23Z",
			fill: "#c2bfa0"
		})
	] });
}
function jn({ x: e, y: t, s: n = 1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-16-20q17-22 35-6 12 16 4 36-11 20-29 9l-13-7q-10 7-12 6l1-12q-8-7-8-11 10 4 16-1Z",
				fill: "#ccac59"
			}),
			/* @__PURE__ */ m("path", {
				d: "M13-25q4-11 11-14l5 3q-5 8-4 22M0 18q-6 19-16 12l5-14m31-6q7 5 13 6l0 6q-8 0-17-3",
				fill: "#b9994f"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-12-7q3-13 13-15 20-4 23 14l-6 16q-12 11-22 0Z",
				fill: "#e3c575",
				stroke: "none"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "-4",
				cy: "-10",
				rx: "7",
				ry: "9",
				fill: "#f0dfab"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "-6",
				cy: "-10",
				rx: "2",
				ry: "4",
				fill: "#414836"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-18-4q-11-2-13 2l7 4-3 5 10-1m22-24q8 16-2 30m11-27-5 4 5 4-5 4 5 4-6 5m-22-1-5 9m7-6-3 7m18-2 4 2m-10 2 3 2m-4-44 10-9m-6 15 8-10m-29 30-7-7m6 13-7 0m29 12 9 4",
				fill: "none",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("path", {
				d: "M7-15q12 5 7 17l-5 3-2-3 4-10-8-2Z",
				fill: "#dfc272"
			}),
			/* @__PURE__ */ m("path", {
				d: "m6-10 5 3-2 6m-8-26 9-1m-7 4 9 1",
				fill: "none",
				stroke: "#a28b47",
				strokeWidth: ".7"
			})
		]
	});
}
function Mn() {
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: "M73 92 129 77l18 17-3 42-57 7-14-16Z",
			fill: "#9d7251"
		}),
		/* @__PURE__ */ m("path", {
			d: "M74 93q-5-30 19-37l26-3q23-2 29 25l-19 3-42 20Z",
			fill: "#bc9461"
		}),
		/* @__PURE__ */ m("path", {
			d: "M129 80 148 78l-1 16-3 42-16-11Z",
			fill: "#7a644b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m85 99 2 36m12-41 2 42m13-45 3 42m-32-67q-10 10-3 28m18-36q-8 11-3 32m16-35q-3 13 1 29m17 6 13 7",
			fill: "none",
			stroke: "#795b41"
		}),
		/* @__PURE__ */ m("path", {
			d: "m83 69 6-4 9 72-6 1Zm34-13 6 1 13 75-7 2Z",
			fill: "#b9b17c"
		}),
		/* @__PURE__ */ m("path", {
			d: "m80 96 51-14 3 7-50 14Zm20 9 10-2 2 12-10 3Z",
			fill: "#d1c18c"
		}),
		/* @__PURE__ */ m("path", {
			d: "m105 109 1 5m-14-44 1 2m3 23 1 2m4 34 1 2m23-61 1 2m5 25 1 2m4 28 1 2",
			fill: "none",
			stroke: "#5e5e44"
		}),
		/* @__PURE__ */ m("g", {
			fill: "#d5bc6b",
			children: [
				0,
				1,
				2,
				3,
				4
			].map((e) => /* @__PURE__ */ h("g", {
				transform: `translate(${52 + e * 18} ${139 - e % 2 * 5})`,
				children: [
					/* @__PURE__ */ m("ellipse", {
						rx: "5",
						ry: "2.5"
					}),
					/* @__PURE__ */ m("path", { d: "M-5 0v2q5 4 10 0V0" }),
					/* @__PURE__ */ m("path", {
						d: "m-2 1 4 0",
						fill: "none",
						stroke: "#ad9659"
					})
				]
			}, e))
		})
	] });
}
function Nn() {
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: "M7 135 12 71 27 33 61 13 117 12 155 40 172 130Z",
			fill: "#8e9d88"
		}),
		/* @__PURE__ */ m("path", {
			d: "M28 118q-3-71 54-80 57-2 69 79Z",
			fill: "#4a6155"
		}),
		/* @__PURE__ */ m("path", {
			d: "M37 124q-1-61 46-70 42 7 49 70Z",
			fill: "#334d45"
		}),
		/* @__PURE__ */ m("path", {
			d: "m9 96 11-28 21-12 13-24 30-14-23 0-35 16-14 36m111-52-17 22 20 13 17 29 16 9-7-39-22-27M16 125l21-20-1 24m112-29-14 28 27 5",
			fill: "#aab49a",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "m26 34 10 15 22-14m-31 30 14-8m5-28 5 13m63-20 1 14 14 4m4 13 16 1m-2 12-6 17m-122 19 11-3m125 7 9 4M40 134l20-7m82 11 17-4",
			fill: "none",
			stroke: "#607964",
			strokeWidth: ".8"
		})
	] });
}
//#endregion
//#region src/games/pilgrims/adventure-revisions.tsx
function Pn({ card: e, x: t, y: n, w: r, h: i, box: a = "12 0 108 83", flip: o = !1 }) {
	return /* @__PURE__ */ m("g", {
		transform: o ? `translate(${t + r} ${n}) scale(-1 1)` : `translate(${t} ${n})`,
		children: /* @__PURE__ */ m("svg", {
			width: r,
			height: i,
			viewBox: a,
			children: /* @__PURE__ */ m(dn, { card: e })
		})
	});
}
function Fn({ x: e, y: t, s: n = 1, talking: r = !1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-12 58q-12 0-13 10l2 9q18 6 34-1l1-11Z",
				fill: "#8c7353"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-21 64q15 6 30 2m-31 6q15 6 29 1m-26 3-1 9m24-10 2 8",
				fill: "none",
				stroke: "#625a43",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-1 56q-7 3-9 11-1 6 6 10l17 6q3 2 1 7l-3 7 8 2q5-8 5-15 0-6-7-11L7 65l14-2q10 6 9 12l-6 20 7 2q8-15 8-23-1-13-17-18Z",
				fill: "#8f7d66"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-5 66q-1 5 9 9l15 9-2 10m6-27q9 4 9 9l-5 17",
				fill: "none",
				stroke: "#685f50",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ m("path", {
				d: "M10 93q5-1 8 3l1 4 6 2q3 3-2 4-10 0-17-6l1-4Zm16 1q6-1 7 4l8 2q6 1 6 5-4 4-16-1l-7-3Z",
				fill: "#595d4b"
			}),
			/* @__PURE__ */ m("path", {
				d: "m9 99 8 3m13-4 2 3m4-1 6 3",
				fill: "none",
				stroke: "#a8a180",
				strokeWidth: ".7"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-4 22q-13 3-15 19-3 13 7 21 12 9 29 8l6-8q-9-6-11-17L8 26Z",
				fill: "#a18c70"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-13 33q-7 20 5 26l18 6 3-5Q-2 54 0 29Z",
				fill: "#82765e",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M3 25q-10 9-8 22l8 6 7-7-3-19m-10 5-5-6-5 7 8 6m7 3 4 16",
				fill: "#bbc0a6"
			}),
			/* @__PURE__ */ m("path", {
				d: "M0 30q-7 4-9 12-2 6 4 9l16 4 4-6-15-6 8-9",
				fill: "#aa9778"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-7 39q-3 8 3 10l15 4m-10-18 5 2m-12 8 4 1m0 10 6 3m10 1 3 3",
				fill: "none",
				stroke: "#625f49",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("path", {
				d: "M12 49q4-4 7-1l3 2 5-1q3 1 1 4l-4 2-1 5q-2 2-4 0l0-5-7 0Z",
				fill: "#c7b485"
			}),
			/* @__PURE__ */ m("path", {
				d: "m18 52 1 5m3-6 0 5m3-5-1 3",
				fill: "none",
				strokeWidth: ".65"
			}),
			/* @__PURE__ */ m("path", {
				d: "M20 53q4-6 7-3l2 4-11 46q-1 3 1 4",
				fill: "none",
				stroke: "#655c40",
				strokeWidth: "2.5"
			}),
			r ? /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("path", {
					d: "M11 29q8 0 11 8l5 7 14-10 4 4q-10 14-20 15-6-3-12-13",
					fill: "#a18c70"
				}),
				/* @__PURE__ */ m("path", {
					d: "m22 41 4 7 7-3m-19-9 4 0",
					fill: "none",
					stroke: "#665f49"
				}),
				/* @__PURE__ */ m("path", {
					d: "M39 35q-2-4-1-8l2-8q2-3 3 0l-1 9 5-9q3-2 4 1l-5 9 7-4q4 0 2 3l-7 5 8-1q3 2 0 4l-10 6-5-3Z",
					fill: "#c7b485"
				}),
				/* @__PURE__ */ m("path", {
					d: "m41 29 4 5m0-4 2 3m-3 4 5-2",
					fill: "none",
					strokeWidth: ".7"
				})
			] }) : /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("path", {
					d: "M12 29q10 1 13 10l-2 11-7 0-1-10-10-4",
					fill: "#a18c70"
				}),
				/* @__PURE__ */ m("path", {
					d: "M18 46q6-4 9-1l3 2 0 5-4 3-4-2-6 0Z",
					fill: "#c7b485"
				}),
				/* @__PURE__ */ m("path", {
					d: "m21 48 0 4m3-4 0 4m3-4-1 3",
					fill: "none",
					strokeWidth: ".7"
				})
			] }),
			/* @__PURE__ */ m("path", {
				d: "M-5 20q-4-7-2-17Q-4-9 8-8q13 0 16 13l-1 7q10-2 11 3 0 4-9 6l-5 9-14 2-12-8Z",
				fill: "#c9b585"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-4 0q5-8 16-5l5 4q-9-2-15 2m-9 11q-8-4-8 2 0 6 8 7m27-17q7-6 8 0l-3 7",
				fill: "#b5b69b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-8 16q5 3 10 2l5 6 6-1q8-8 16-4l-6 9-8 2-2 11q-2 4-5 1l-2-8-5 6-4-11-6 0q-5-3-3-13Z",
				fill: "#c4c7ad"
			}),
			/* @__PURE__ */ m("path", {
				d: "M0 22q1 9 5 12m4-7 1 10m7-12-2 9m4-11 5-1M-9 13l3 3M-1 7q5-4 10-2m7-1 6 1m-15 6-1 7 7-2m-11 1-4 1",
				fill: "none",
				stroke: "#696e57",
				strokeWidth: ".85"
			}),
			/* @__PURE__ */ m("path", {
				d: "M1 8q4-2 7 0m9-2 5 1",
				fill: "none",
				strokeWidth: "1.3"
			}),
			/* @__PURE__ */ m("path", {
				d: "m4 9 0 2m14-2 0 2M0 3q4-3 9-1m5-3 6 2",
				fill: "none",
				strokeWidth: ".8"
			})
		]
	});
}
function In() {
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: "M56 99q-3 10-10 18l-7 12 6 5q10-10 18-25l4-5m5-3q5 6 4 14l-1 8 9 7 5-4-7-8q3-12-2-20",
			fill: "#c5ae7d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 127q5 0 6 5l-2 4 6 3q4 3 1 5-9 2-17-6l1-7Zm35-4q5-3 8 2l0 5 9 2q4 1 4 5-3 4-13 0l-9-7Z",
			fill: "#555741"
		}),
		/* @__PURE__ */ m("path", {
			d: "m39 133 6 5m36-8 2 4m4-1 8 2",
			fill: "none",
			stroke: "#a3a17a",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M51 80q-8 10-8 21l12 8 9-13q3 8 8 12l14-6q-6-10-8-20Z",
			fill: "#6e8654"
		}),
		/* @__PURE__ */ m("path", {
			d: "M50 86q-3 10-2 15l7 4 9-15m6-4q0 9 6 16l6-2",
			fill: "none",
			stroke: "#456444"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 54q-9 4-10 15l1 15q15 8 33-1l-1-19-10-10Z",
			fill: "#a07b53"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 59q-7 3-11 11l7 6 9-12m20-4q8 4 9 13l-8 3-7-12",
			fill: "#b8ad83"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 70q-7 8-13 13l-7 2-1 5q13 0 24-12l3-4m34-2q1 8 6 11l11-1 1-5-9 0-4-7",
			fill: "#d1b989"
		}),
		/* @__PURE__ */ m("path", {
			d: "M19 85q-4-4-7-2l-4 1q-2 2 2 3l5 1-6 2q-2 2 1 3l6-2-3 3q0 3 3 1l7-4 0-4m73-8q2-5 5-4l3 4-2 5-5 2-4-3Z",
			fill: "#d1b989"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 58q-2 12 1 23m5-24-1 27m14-26-1 25m6-20 0 18m-27-13 29 2m-28 5 28 2m-28 4 25 2",
			fill: "none",
			stroke: "#66533a",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M58 47 55 56q5 7 13 2l-1-11",
			fill: "#b89c6d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 28q9-10 23-3 10 5 8 16l-3 8q-5 10-15 8-12-2-16-13l-7-3q-5-4-1-7l9 1Z",
			fill: "#d4ba89"
		}),
		/* @__PURE__ */ m("path", {
			d: "M42 29q-7-4-12 1l-3 5 10 0-6 7 11-1 4-7m22-7q10-4 14 4l-4 13-6 2 1-9",
			fill: "#a77d4e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 47q3 7 10 7l2-4m5-7-2 5 4 0m-14-17 6 0m9-1 6 2",
			fill: "none",
			stroke: "#8e754d",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "52",
			cy: "37",
			rx: "3.4",
			ry: "4",
			fill: "#eee4bf"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "67",
			cy: "37",
			rx: "3.3",
			ry: "4",
			fill: "#eee4bf"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "52",
			cy: "38",
			r: "1.3"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "66",
			cy: "38",
			r: "1.3"
		}),
		/* @__PURE__ */ m("path", {
			d: "M37 23q1-9 13-10 14-5 28 4l5 7q-23 8-46-1Z",
			fill: "#719d69"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 14q-3-12 3-12 7-1 9 10m7 1q0-11 6-10 7 2 3 13",
			fill: "#91b57d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m51 7 2 0m17 1 2 0M43 23q15 4 33-1",
			fill: "none",
			strokeWidth: ".9"
		}),
		/* @__PURE__ */ m("path", {
			d: "M109 104q1 10-5 20l-8 10 5 4q13-10 17-26m7-6q1 11 7 19l8 7 4-5-6-7-2-15",
			fill: "#cdb487"
		}),
		/* @__PURE__ */ m("path", {
			d: "M98 131q5-1 7 3l-1 4 8 1q5 2 3 5-11 3-21-3l-1-5Zm35-6q5-2 8 2l1 6 10 0q5 1 4 5-5 4-15 0l-11-7Z",
			fill: "#555740"
		}),
		/* @__PURE__ */ m("path", {
			d: "M108 51q-15 0-16 15l1 17q-1 11-8 23 23 14 51 1-7-14-9-27l1-13q-2-11-14-14Z",
			fill: "#749c7c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M99 70q2 13-2 26l-5 8q16 8 30 5l7-2q-12-1-16-3-4-16-1-33Z",
			fill: "#5b8667",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M101 63q9 6 21 0m-24 29q13 6 28 0m-35 11q20 9 38 0m-23-33-1 11m15-12 2 14",
			fill: "none",
			stroke: "#476c51"
		}),
		/* @__PURE__ */ m("path", {
			d: "M101 57q-10-7-15 1l-6 13 8 6 8-12m27-9q9-5 14 5l1 11-9 4-6-13",
			fill: "#e1dfc0"
		}),
		/* @__PURE__ */ m("path", {
			d: "M84 72q-5 4-3 10 3 6 12 4l3-4-8-2 3-6m42 0q0 8 7 13l12 1 1-5-10-2-5-11",
			fill: "#d4ba8a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M91 81q2-6 6-5l4 3 0 5-6 4-4-2m59-3q4-4 8-1l3 2q2 2-1 3l-4-1 3 3q1 3-2 2l-6-2-2-3",
			fill: "#d4ba8a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M105 47 103 57q7 10 17 0l-2-11",
			fill: "#bda073"
		}),
		/* @__PURE__ */ m("path", {
			d: "M99 25q14-10 27 1 8 10 2 23-5 11-17 11-15-2-16-16Z",
			fill: "#d6bd8c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M96 18q-13 10-12 29l-7 17q13-1 18-8l1-14q6-9 9-16 13 7 24-1l1 19-5 18 13-3-6-4 6-21q-1-20-20-24Z",
			fill: "#b49959"
		}),
		/* @__PURE__ */ m("path", {
			d: "m92 22-3 23m9-25-3 12m11-16-5 10m14-10-5 12m13-10-5 11m12-7-5 8m9 10-4 15m-43-3-3 5",
			fill: "none",
			stroke: "#806e42",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "107",
			cy: "36",
			rx: "3.6",
			ry: "4.2",
			fill: "#eee5c2"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "122",
			cy: "35",
			rx: "3.5",
			ry: "4.2",
			fill: "#eee5c2"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "108",
			cy: "37",
			r: "1.3"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "121",
			cy: "36",
			r: "1.3"
		}),
		/* @__PURE__ */ m("path", {
			d: "m103 29 7-1m9-1 7 1m-10 9-2 6 5 0m-10 7q5-4 10 0l-2 4-8-1m-27 25 4 3m48-2 3 4m-36 53 5 3m35-9 1 4",
			fill: "none",
			strokeWidth: ".75"
		}),
		/* @__PURE__ */ m("g", {
			fill: "#365e44",
			children: [
				[103, 76],
				[118, 76],
				[100, 86],
				[114, 86],
				[125, 96],
				[98, 99],
				[112, 102]
			].map(([e, t]) => /* @__PURE__ */ m("ellipse", {
				cx: e,
				cy: t,
				rx: "1.9",
				ry: "1.4"
			}, `${e}-${t}`))
		})
	] });
}
function Ln() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("svg", {
			x: "66",
			y: "5",
			width: "82",
			height: "81",
			viewBox: "12 9 124 113",
			children: /* @__PURE__ */ m(dn, { card: 16 })
		}),
		/* @__PURE__ */ m("path", {
			d: "M62 86q-17-10-26 1-16-2-20 13-15 1-17 14l2 25 71 0 12-34Z",
			fill: "#6b8c6e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M5 111q17-13 36-6m-19-9q10 10 13 26m11-29 6 16m-5 5 20-10",
			fill: "none",
			stroke: "#456c55"
		}),
		/* @__PURE__ */ m(Mn, {}),
		/* @__PURE__ */ m("path", {
			d: "M40 105q-9 0-14 9l-9 12 4 6q11-4 20-15l6-7m11 1q6 7 3 14l9 5 7-1-2-5-6-4 0-12",
			fill: "#9b7856"
		}),
		/* @__PURE__ */ m("path", {
			d: "M19 125q-5-1-9 4l-2 6q4 4 12 1l8-6m37-4q3-3 7 0l3 4 8 0q4 3 0 5l-14 0-6-5",
			fill: "#615c43"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 66q-15 3-18 20-3 12 9 24l19 7 16-10q-9-12-8-27l-8-10Z",
			fill: "#836546"
		}),
		/* @__PURE__ */ m("path", {
			d: "M31 80q-4 13 8 23l11 4 1-33m6 5 6 23",
			fill: "#69563e",
			stroke: "none"
		}),
		/* @__PURE__ */ m(Pn, {
			card: 0,
			x: 24,
			y: 27,
			w: 53,
			h: 54
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 78q-7 3-7 12-1 6 6 10l17 7 4-6-16-9 5-9",
			fill: "#9c7d51"
		}),
		/* @__PURE__ */ m("path", {
			d: "M62 101q4-4 7-2l3 3 6-1q3 2 0 4l-5 1 4 2q1 3-2 3l-10-4-4-3m-10-26q8 0 14 8l6 0 1 5-10 2-11-8",
			fill: "#c2a577"
		}),
		/* @__PURE__ */ m("path", {
			d: "m66 103 3 3m-25-15 4 5m-15-5 3 3m5 8 6 3m-18 26 5-2m38 2 6 1",
			fill: "none",
			strokeWidth: ".75"
		})
	] });
}
function Rn() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M34 102q-8 12-10 26l-10 6 1 6q14 2 18-8l9-19m10-9q8 9 10 20l13 5 3-5-10-8-6-17",
			fill: "#9b7854"
		}),
		/* @__PURE__ */ m("path", {
			d: "M14 133q7-3 10 1l-1 5q-13 8-18 1l1-3Zm52-12q6-3 9 2l7 2q6 0 6 5-6 5-19-1Z",
			fill: "#555b44"
		}),
		/* @__PURE__ */ m("path", {
			d: "M34 61q-16 5-18 22-4 13 8 24 15 6 33-2l-2-32-13-12Z",
			fill: "#62814f"
		}),
		/* @__PURE__ */ m("path", {
			d: "M23 73q-8 22 6 28l11 3-2-38m13 7 3 23-9 6",
			fill: "#47663f",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M24 103q15 5 32-3l0 6q-15 8-30 2Z",
			fill: "#675339"
		}),
		/* @__PURE__ */ m("path", {
			d: "m42 104 7-2 1 5-7 2Z",
			fill: "#b7a26a"
		}),
		/* @__PURE__ */ m(Pn, {
			card: 0,
			x: 15,
			y: 17,
			w: 49,
			h: 51
		}),
		/* @__PURE__ */ m("path", {
			d: "M38 70q7 0 12 8l11 3 12-8 4 5q-10 13-18 12l-17-7",
			fill: "#6a8954"
		}),
		/* @__PURE__ */ m("path", {
			d: "M29 76q-9 8-5 15l14 5 5-6-10-5 3-5",
			fill: "#73925d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M38 88q3-5 7-3l3 3-2 5-7 3-3-3m35-20q0-5 5-5l6 3 0 5-5 6-5-3Z",
			fill: "#c8ae7b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M77 68 91 66 93 69 88 72 87 78 83 81 80 78 82 72 77 73Z",
			fill: "#746b51"
		}),
		/* @__PURE__ */ m("path", {
			d: "M78 65 94 64 96 67 79 69Z",
			fill: "#9aa498"
		}),
		/* @__PURE__ */ m("path", {
			d: "m91 64 0-2m-8 8 4 0m-7 2 3 3",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M111 103q-6 10-5 22l-5 10 5 4q9-4 10-14l4-16m8-3q3 9 0 19l8 7 6-2-7-9 2-16",
			fill: "#d5d1b4"
		}),
		/* @__PURE__ */ m("path", {
			d: "M101 133q5-2 7 3l-1 4-9 4q-5 0-4-4Zm31-5q4-1 7 3l7 1q5 2 3 5l-14-1-6-6Z",
			fill: "#4f5b47"
		}),
		/* @__PURE__ */ m("path", {
			d: "M108 62q-9 5-10 19l-3 25q18 10 40 0l-4-30-11-14Z",
			fill: "#957c7a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M105 78q-3 14-2 24l9 4 0-31m14 3 5 23-6 5",
			fill: "#79666a",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M103 91q15 4 29-1l1 4q-16 5-30 1m8-26 5 28m-11 0-4 8m25-6 3 7",
			fill: "none",
			stroke: "#4d5143"
		}),
		/* @__PURE__ */ m("path", {
			d: "M105 64q-10-6-10-17l-1-12 5-1 3 13q0 5 8 10m16 11q9-6 11-17l2-17-5-1-4 17-9 8",
			fill: "#d8d8bd"
		}),
		/* @__PURE__ */ m("path", {
			d: "M95 36q-4-3-5-8l-1-6q1-4 3-1l3 7-1-12q1-3 3-1l2 11 2-10q2-3 3 0l0 12 3-6q3-1 3 2l-4 12-6 3Zm39-2q-4-3-3-7l-1-9q1-3 3-1l2 10 2-13q2-3 3 0l0 12 3-10q3-2 3 1l-2 12 4-6q3-1 3 2l-6 11-6 2Z",
			fill: "#e3dfc5"
		}),
		/* @__PURE__ */ m(Pn, {
			card: 21,
			x: 96,
			y: 28,
			w: 37,
			h: 41
		}),
		/* @__PURE__ */ m("path", {
			d: "m108 64 5 7 5-7m-6 8 1 16m-2-11 3 0m-2 7 3 0",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M151 109q-2 12-8 21l-2 8 6 3q10-6 12-25m8-7q2 13 8 21l7 1 2-5-6-4-3-17",
			fill: "#d2cdb2"
		}),
		/* @__PURE__ */ m("path", {
			d: "M142 136q5-2 7 2l-1 4-10 3q-4-1-3-4m40-14q5-2 7 2l7 1 0 5-13-1-5-4",
			fill: "#4f5b46"
		}),
		/* @__PURE__ */ m("path", {
			d: "M151 66q-11 5-12 19l-2 24q18 11 38 0l-4-29-10-14Z",
			fill: "#78977b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M146 79q-5 12-3 26l8 5 2-32m13 2 5 24-7 6",
			fill: "#55795f",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M148 68q-11-7-11-20l-2-8 5-1 4 12 9 10m12 8q10-6 11-18l0-12 5 0 1 16q-1 14-11 20",
			fill: "#d9dac2"
		}),
		/* @__PURE__ */ m("path", {
			d: "M135 41q-3-3-3-7l-2-7q1-4 3-1l3 7-1-11q1-3 3-1l2 11 2-9q2-3 3 0l-1 11 4-5q3 0 2 3l-5 10-5 2m36-4q-3-4-2-8l0-8q2-3 3 0l1 10 3-11q2-2 3 1l-2 11 4-7q3-1 3 2l-3 10-5 3Z",
			fill: "#e1dfc3"
		}),
		/* @__PURE__ */ m(Pn, {
			card: 31,
			x: 139,
			y: 33,
			w: 37,
			h: 40
		}),
		/* @__PURE__ */ m("path", {
			d: "m148 73 7 4 6-7m-7 8 1 20m-12 5 25 1m-15-19 3 0m-3 7 4 0m-27 15 5 4",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M168 105q7-5 11 2l2 12q-3 6-9 5l-6-6Z",
			fill: "#ab8655"
		}),
		/* @__PURE__ */ m("path", {
			d: "M169 109q5-2 9 1m-10 6 10 1m-13-2 2-16",
			fill: "none",
			strokeWidth: ".8"
		})
	] });
}
function zn() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("svg", {
			x: "14",
			y: "17",
			width: "73",
			height: "124",
			viewBox: "0 0 140 180",
			children: /* @__PURE__ */ m(dn, { card: 6 })
		}),
		/* @__PURE__ */ m("path", {
			d: "M117 110q-8 10-7 20l-8 8q-1 4 4 5l12-1 1-4-7-1q11-11 13-21m9-6q4 7 0 16l-1 10 12 3 11-1q5-3 1-5l-15-2 4-15",
			fill: "#729781"
		}),
		/* @__PURE__ */ m("path", {
			d: "m106 140 3 2m4-2 2 3m21-8 2 3m4-3 2 3m4-3 2 3",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M114 70q-13 8-14 24l6 21 16 7 17-6q-6-13-5-30l-8-14Z",
			fill: "#527c65"
		}),
		/* @__PURE__ */ m("path", {
			d: "M108 83q-4 15 4 26l10 6 3-6q-10-9-8-32Z",
			fill: "#3c624f",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "m109 89 6 3m4-7 6 5m-20 11 8 1m-5 8 6 1m8 3 6 2m0-15 5 3m-15-29-2 8m6-6 0 6m6-5 2 6",
			fill: "none",
			stroke: "#334d3f",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M135 72q10 1 13 12l1 13-8 8-5-3q7-5 6-10l-3-9-9-3",
			fill: "#759981"
		}),
		/* @__PURE__ */ m("path", {
			d: "M140 98q-6-1-7 5l3 5 6 0 2-7",
			fill: "#87a98c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M110 78q-7-3-12 6l-5 7-13-3-3 5q13 9 22 7 6-3 13-13",
			fill: "#7b9f86"
		}),
		/* @__PURE__ */ m("path", {
			d: "M81 88q-5-5-9-2l-3 5 3 6 5 1 5-5Z",
			fill: "#87a98c"
		}),
		/* @__PURE__ */ m("path", {
			d: "m73 90 4 3m-4 0 3 3m60 7 3 2m-35-16-7 6m42-10 2 6",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M139 102q-10 12-3 25 7 6 15-1l-1-8-6-2-2-11Z",
			fill: "#a1804e"
		}),
		/* @__PURE__ */ m("path", {
			d: "m140 116 7 2m-8 3 9 2m-7-18q7 4 8 12",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m(Pn, {
			card: 11,
			x: 87,
			y: 27,
			w: 72,
			h: 59,
			box: "17 12 95 71",
			flip: !0
		}),
		/* @__PURE__ */ m("path", {
			d: "M133 78q7 3 10 0l-2 5 6-1-1 5 6-1-1 6m-17-16 8-9 5 0m-3 8 5-3 5 2m-14 6 11-2",
			fill: "none",
			stroke: "#4b6e56",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ m("path", {
			d: "M74 93q-4-14 0-29m0 17q-9 2-11-4 7-2 11 2m1-7q8-6 12-2-3 5-11 5",
			fill: "#6e9667"
		}),
		[
			0,
			1,
			2,
			3,
			4,
			5
		].map((e) => /* @__PURE__ */ m("path", {
			d: "M74 64q-9 0-8-6 3-5 8 2Z",
			transform: `rotate(${e * 60} 74 63)`,
			fill: "#eee8ce"
		}, e)),
		/* @__PURE__ */ m("circle", {
			cx: "74",
			cy: "63",
			r: "3",
			fill: "#bdad65"
		}),
		/* @__PURE__ */ m("path", {
			d: "M66 92q-5-4-10-2l-1 4q7 5 12 2l6-2-1-4Z",
			fill: "#d0b487"
		}),
		/* @__PURE__ */ m("path", {
			d: "m61 92 5 2m1-2 3 2",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M84 21q-10-10-15-4-4 7 15 18 17-11 14-18-6-6-14 4Z",
			fill: "#bc7e70"
		})
	] });
}
function Bn() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M53 103q-7 8-6 18l-2 9 9 5 6-3-8-6 5-12 8-6m6-12q10 0 14 8l-1 8 9 1 4-5-8-4q-1-10-10-17",
			fill: "#829168"
		}),
		/* @__PURE__ */ m("path", {
			d: "M45 128q5-2 10 2l1 6 9 1q3 2 1 5-8 4-20-3l-4-5m43-27q5-3 9 1l8 0 1 4q-5 6-16 4l-5-5",
			fill: "#5d6149"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 65q-14 10-13 26 1 10 15 18l15 2 14-13q-11-7-12-23l-8-12Z",
			fill: "#968265"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 78q-4 15 9 23l11 4 3-5q-13-12-11-30Z",
			fill: "#75664f",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M61 70q6 2 11-5l11-15 8-5 3 4-7 8-8 14q-6 9-13 9",
			fill: "#c4ae7c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M48 75q-8 1-7 9l6 8 13-2 18-8 10-11-4-4-12 10-17 4-4-5",
			fill: "#c7b182"
		}),
		/* @__PURE__ */ m("path", {
			d: "M89 45q-1-5 3-7l5-2q4 0 3 2l-6 4 6-1q3 2 0 3l-6 2-1 5-5-1m-4 18q0-5 4-7l5-1q3 1 1 3l-5 3 6-1q4 1 1 3l-7 4-3 2-4-3",
			fill: "#d2bd8e"
		}),
		/* @__PURE__ */ m("path", {
			d: "m91 42 3 3m-8 20 3 3m-43 16 5 4m14-12 4 2m-25 17 5 2m4 1 6 3m2-1 5-4m-11 13-3 8m22-15 7 5",
			fill: "none",
			stroke: "#5f5b44",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M38 70q-10-10-6-21 3-9 18-8l14 6-2 13-14 11Z",
			fill: "#82917a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M37 48q-7 6-3 17l8 7m-3-26 18 3m-20 5 20 3m-18 3 15 3m-14-15 0 18m-8 0-2 9",
			fill: "none",
			stroke: "#556c5b"
		}),
		/* @__PURE__ */ m(Pn, {
			card: 5,
			x: 24,
			y: 20,
			w: 49,
			h: 58,
			box: "20 0 110 110"
		})
	] });
}
function Vn() {
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: "M49 103q-11 9-17 24l-7 6 4 6q12-2 15-12l15-17m8-4q8 7 10 18l10 7 4-5-7-9-7-17",
			fill: "#77945e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M28 132q5-1 8 3l-1 5q-9 8-17 5l-3-4q1-4 9-4Zm50-6q5-2 9 2l5 3 7-1q6 1 4 5-8 6-20 1l-7-5Z",
			fill: "#535d43"
		}),
		/* @__PURE__ */ m("path", {
			d: "m32 121 7 4m-6 0 5 4m43-8 5-1m-4 4 5-2m-58 15-8 4m68-7 8-1",
			fill: "none",
			stroke: "#b7b789",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 58q-15 5-16 22l3 25q17 11 40 0l-1-25-10-21Z",
			fill: "#83966a"
		}),
		/* @__PURE__ */ m("path", {
			d: "M40 70q-8 11-4 28l11 7 7-6-3-36m12 10 6 24-6 8",
			fill: "#5f7d56",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "m43 63 8 8 7-9 9 8m-13 0-1 10m-9 20-6 5m29-5 4 4",
			fill: "none",
			stroke: "#425d42"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 65q-15-1-20 10-3 8 10 16l9-3-10-10 12-4m25-9q13-8 18-15l6 2q-4 15-19 23",
			fill: "#a3b18b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M31 83q-5-5-8-2l-1 6 7 8 7-3m45-36q-2-6 1-9l5-3 4 2-1 8-5 5",
			fill: "#c9b582"
		}),
		/* @__PURE__ */ m("path", {
			d: "m26 84 4 5m-3-2 3 5m55-42 3 2m-2-4 3 1",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M43 29q12-12 26-1l1 12q12 2 14 8 0 4-12 5l-3 12q-10 9-23-1-10-8-10-18Z",
			fill: "#ccb483"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 31q-8 0-10 7l-4 9 8 3-3 7 10-3m25-23q10-3 12 4l-5 10m-31 6q7-7 14 0 13-5 21 2l-9 5-10-1-8 4-11-4Z",
			fill: "#bdc1a4"
		}),
		/* @__PURE__ */ m("path", {
			d: "M39 54q6 12 19 15l5-8 8 0-3 11-11 4-12-7-10-10Z",
			fill: "#bdc1a4"
		}),
		/* @__PURE__ */ m("path", {
			d: "m43 58 6 7m4-5 3 9m7-8 0 6m-3-25-2 8 7-1m-15-20 6-2m8-1 7 1",
			fill: "none",
			stroke: "#676e51",
			strokeWidth: ".85"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "51",
			cy: "38",
			rx: "3.9",
			ry: "4.4",
			fill: "#eee6c5"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "68",
			cy: "37",
			rx: "3.5",
			ry: "4.3",
			fill: "#eee6c5"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "52",
			cy: "39",
			r: "1.4"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "67",
			cy: "38",
			r: "1.3"
		}),
		/* @__PURE__ */ m("path", {
			d: "M30 27q1-7 14-8L46 8q10-8 19 0l5 9 10 2q4 4-3 8-22 12-47 0Z",
			fill: "#608051"
		}),
		/* @__PURE__ */ m("path", {
			d: "M44 17q12 5 24-1l1 5q-12 6-26-1m-7 8q22 5 36-2M49 9l11-2 6 7",
			fill: "none",
			stroke: "#aac087",
			strokeWidth: ".85"
		}),
		/* @__PURE__ */ m("path", {
			d: "M25 81 40 75 46 81 43 108 29 104 23 98Z",
			fill: "#636e56"
		}),
		/* @__PURE__ */ m("path", {
			d: "M41 78 73 64 80 71 49 92 43 107 38 101Z",
			fill: "#d0cbb0"
		}),
		Array.from({ length: 8 }, (e, t) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("path", {
			d: `M${42 + t * 4.2} ${79 - t * 1.8}l3 5-1 20-4-4Z`,
			fill: t % 2 ? "#b4b99f" : "#e3dfc6"
		}), /* @__PURE__ */ m("path", {
			d: `m${45 + t * 4.2} ${84 - t * 1.8}-1 20`,
			fill: "none",
			stroke: "#6a7660",
			strokeWidth: ".7"
		})] }, t)),
		/* @__PURE__ */ m("path", {
			d: "M73 64 83 58 91 64 87 88 77 94 71 87Z",
			fill: "#526e55"
		}),
		/* @__PURE__ */ m("path", {
			d: "M78 67 85 63 85 85 78 89Z",
			fill: "#bbc0a6"
		}),
		/* @__PURE__ */ m("path", {
			d: "m80 69 0 16m3-18 0 17m-56 2 10-4 1 17-9-3Z",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("g", {
			fill: "#d7d7b8",
			children: [
				0,
				1,
				2,
				3
			].map((e) => /* @__PURE__ */ m("circle", {
				cx: 29 + e % 2 * 4,
				cy: 88 + Math.floor(e / 2) * 6,
				r: "1"
			}, e))
		})
	] });
}
function Hn() {
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: "M117 103q-5 13-13 22l-2 8 7 4q10-5 15-22m8-14q10 0 12 9l-7 11 8 6 6-2-6-7 9-12-17-9",
			fill: "#588897"
		}),
		/* @__PURE__ */ m("path", {
			d: "m117 113-8 12 5 4 9-12m19-11-4 6 5 6 8-10",
			fill: "#b37853"
		}),
		/* @__PURE__ */ m("path", {
			d: "M104 131q-10-1-11 7 1 9 14 8l9-6-1-6-5 0q0 7-7 4m41-14q-7 2-5 9 6 9 18 6 5-4 3-8l-4 0q-1 5-8 2l2-6",
			fill: "#51543f"
		}),
		/* @__PURE__ */ m("path", {
			d: "M116 59q-13 9-13 24l-3 20 10 1 6 8 8-6 10 6 5-10 10 0-7-27-11-15Z",
			fill: "#638b83"
		}),
		/* @__PURE__ */ m("path", {
			d: "m111 66-4 26 11 7 7-8-5-25m9 0 6 21-3 8m-24 5 31-3",
			fill: "#b08059"
		}),
		/* @__PURE__ */ m("path", {
			d: "M115 68q-13 6-15 17l16 10 8-5-14-9 11-7m15-5q13 3 16-12l3-11-5-1-5 13-13 5",
			fill: "#749a8a"
		}),
		/* @__PURE__ */ m(Pn, {
			card: 23,
			x: 101,
			y: 4,
			w: 53,
			h: 62,
			box: "0 0 110 79"
		}),
		/* @__PURE__ */ m("path", {
			d: "M108 62q14 7 27-1l7 6-12 3-4 9-5-9-14-1Z",
			fill: "#b27954"
		}),
		/* @__PURE__ */ m("path", {
			d: "M123 83q-12-1-16 11-3 12 8 17 14 4 21-6 4-7-1-12l4-12-8-3Z",
			fill: "#c0a46b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M121 88q-10 0-11 9-1 8 9 10 10-1 12-8l-3-7Z",
			fill: "#ac8a4e"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "123",
			cy: "98",
			rx: "3",
			ry: "4",
			fill: "#584d34"
		}),
		/* @__PURE__ */ m("path", {
			d: "m125 94 22-49 4 2-21 50M145 46l1-10 9 2 1 7Z",
			fill: "#b79b60"
		}),
		/* @__PURE__ */ m("path", {
			d: "m120 89 27-47m-24 51 26-49m-34 58 15 1m18-65 5 2m-7 3 6 2",
			fill: "none",
			stroke: "#665d3c",
			strokeWidth: ".65"
		}),
		/* @__PURE__ */ m("path", {
			d: "M118 85q-5-5-8-1l1 6 9 3 3-3m23-38q-3-5 0-8l5-1 3 3-2 6-5 3",
			fill: "#c8b181"
		}),
		/* @__PURE__ */ m("path", {
			d: "m113 86 6 3m29-43 3 1m-35 22 3 3m15 0 3 2",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ h("g", {
			fill: "#d1bb79",
			children: [
				/* @__PURE__ */ m("circle", {
					cx: "108",
					cy: "69",
					r: "2"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "141",
					cy: "67",
					r: "2"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "110",
					cy: "105",
					r: "2"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "125",
					cy: "111",
					r: "2"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "141",
					cy: "102",
					r: "2"
				})
			]
		})
	] });
}
function Un() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M2 145q-1-17 12-24 14-3 19 10l4 14m105 0q-2-17 9-24 14-7 26 10l5 14",
			fill: "#657d64"
		}),
		/* @__PURE__ */ m("path", {
			d: "M2 127q-4-14 9-18l7 3 3-6 9 4 2 14q-14 10-30 3m142-1q-4-12 9-15l5-8 7 8 12-1 1 12q-18 10-34 4Z",
			fill: "#547656"
		}),
		/* @__PURE__ */ m("path", {
			d: "m4 119 20 3m122-4 21 2m-14 9 11 3m-146-2 9 4",
			fill: "none",
			stroke: "#3e5d45"
		}),
		/* @__PURE__ */ m(Vn, {}),
		/* @__PURE__ */ m(Hn, {}),
		/* @__PURE__ */ m("path", {
			d: "m18 43 7-2v11m-1-2-5 1m68-41 7-2v12m-1-3-5 1m68 32 7-2v12m-1-3-5 1",
			fill: "none"
		})
	] });
}
function Wn() {
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", {
			d: "M67 109q-7 10-7 20l-9 10 5 6q11-5 12-13l10-17m6-12q9 5 11 14l-6 12 8 5 6-4-6-7q7-14-7-24",
			fill: "#8a6c4d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M53 137q7-1 9 4l-1 5-16 2q-6-1-4-5l8-1m41-15q5-3 9 1l5 2 6-2q5 1 4 5-9 7-19 1l-8-3",
			fill: "#4e6d58"
		}),
		/* @__PURE__ */ m("path", {
			d: "m64 123 7 2m20-6 6 2m-43 22 6 1m38-10 9-1",
			fill: "none",
			stroke: "#a4ac84",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M66 65q-14 6-15 22l1 17q14 15 32 8l12-12q-11-12-12-28l-9-8Z",
			fill: "#5f8692"
		}),
		/* @__PURE__ */ m("path", {
			d: "M57 78q-5 21 7 28l11 5 6-7Q67 94 68 68Z",
			fill: "#406c7a",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M54 99q19 9 36-5l3 5q-14 16-39 7Z",
			fill: "#68583d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m71 103 7 0 0 5-6 1Zm-10-32 6 12 7-14m5 6 4 15",
			fill: "none",
			stroke: "#b6bd91",
			strokeWidth: ".9"
		}),
		/* @__PURE__ */ m("path", {
			d: "M62 70q-12 0-16 9l-4 9-18 1-1 6q19 4 27-1l12-13m18-9q11 1 14 12-3 13-26 14l-20-3 1-6 21 1 13-6-7-5",
			fill: "#c3a472"
		}),
		/* @__PURE__ */ m("path", {
			d: "M47 80q-4 7-3 10m39-10 4 5-5 5m-31 0 8 1m-1 9 4 4m18-17 5-1",
			fill: "none",
			stroke: "#886d46",
			strokeWidth: ".9"
		}),
		/* @__PURE__ */ h("g", {
			transform: "translate(30 25) scale(.65)",
			children: [
				/* @__PURE__ */ m("path", {
					d: "M45 27q-3-15 14-18 18-3 19 13l-3 15q8 4 18 2 5 7-2 11l-11 4q-4 15-15 17-15-4-22-16l-5-15Z",
					fill: "#cdb17a"
				}),
				/* @__PURE__ */ m("path", {
					d: "M43 33q-4 14 5 23l8 6-11-6-6-14m36-20q5 11-1 17 9 4 18 2l-3 6-14 1-6-6Z",
					fill: "#ae9261",
					stroke: "none"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "54",
					cy: "37",
					rx: "3.5",
					ry: "4",
					fill: "#f3ebcf"
				}),
				/* @__PURE__ */ m("ellipse", {
					cx: "73",
					cy: "34",
					rx: "3",
					ry: "3.5",
					fill: "#f3ebcf"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "55",
					cy: "38",
					r: "1.2"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "73",
					cy: "35",
					r: "1.2"
				}),
				/* @__PURE__ */ m("path", {
					d: "M44 49q8 7 16 0l9 4q19 5 36-2-4 9-14 12l16 0q-10 10-31 8l-6 7-8-5-8 7q-6-6-9-8l-9 1 4-10-7-4Z",
					fill: "#bdc7b3"
				}),
				/* @__PURE__ */ m("path", {
					d: "m43 57q3 8 8 12m-3-13 7 15m3-14 6 14m2-13 8 7m3-4 13 2M44 25q-8 3-10 13l6 11 5-7m-4-15q2-10 10-12m4 9q4-7 10-2m7 0q7-6 11 0",
					fill: "none",
					stroke: "#7d8563",
					strokeWidth: "1.2"
				}),
				/* @__PURE__ */ m("path", {
					d: "M45 20q9-11 19-7m-16 6 12-3m-13 10-6-2m11 5 7-4m9-5 7 2m-34 11-7 1 0 7 7 5",
					fill: "none"
				})
			]
		}),
		/* @__PURE__ */ m("path", {
			d: "M31 86 78 90l0 4-47-4Z",
			fill: "#85653e"
		}),
		/* @__PURE__ */ m("path", {
			d: "M27 82q-10-4-16 0l2 18q8-2 15-1l4-5Z",
			fill: "#93a69c"
		}),
		/* @__PURE__ */ m("path", {
			d: "M14 84q6-3 12-1l2 13-13 1Z",
			fill: "#bcc5ae",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "m13 83 2 13m12-9 2 8",
			fill: "none",
			stroke: "#5c796c",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M25 88q-4-5-7-2l0 6 4 3 5-1m23-5q-2-6-6-4l-3 4 2 5 6 2 3-3",
			fill: "#cbb080"
		}),
		/* @__PURE__ */ m("path", {
			d: "m21 88 0 5m3-4 0 4m20-5 0 5m3-4 0 5m-31 14 4 7m59-7 8-1m-18 24 2 7",
			fill: "none",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m("path", {
			d: "M7 103v31q18 9 36-2l-1-30Z",
			fill: "#a38a59"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "25",
			cy: "103",
			rx: "19",
			ry: "7",
			fill: "#d0b886"
		}),
		/* @__PURE__ */ m("path", {
			d: "m13 111 2 19m9-20-2 9 6 5m7-15 1 17M14 102q11-8 23 0m-19 2 8-3 6 3m-7-7 0 4",
			fill: "none",
			stroke: "#6d6644",
			strokeWidth: ".85"
		}),
		/* @__PURE__ */ m("path", {
			d: "m105 131 11 0-4 9-12-1m-54 6 7-4 11 2-8 6",
			fill: "#b89a60"
		})
	] });
}
//#endregion
//#region src/games/pilgrims/adventure-early.tsx
function Gn({ card: e, x: t, y: n, w: r = 47, h: i = 43, flip: a = !1 }) {
	return /* @__PURE__ */ m("g", {
		transform: a ? `translate(${t + r} ${n}) scale(-1 1)` : `translate(${t} ${n})`,
		children: /* @__PURE__ */ m("svg", {
			width: r,
			height: i,
			viewBox: "0 0 70 75",
			children: /* @__PURE__ */ m(wn, { card: e })
		})
	});
}
function Kn({ x: e, y: t, r: n = 17 }) {
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("ellipse", {
			cx: e + 2,
			cy: t + 1,
			rx: n * .82,
			ry: n,
			fill: "#786e4d"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: e,
			cy: t,
			rx: n * .82,
			ry: n,
			fill: "#bbaa7b"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: e,
			cy: t,
			rx: n * .65,
			ry: n - 3,
			fill: "none"
		}),
		[
			0,
			30,
			60,
			90,
			120,
			150
		].map((r) => /* @__PURE__ */ m("path", {
			d: `M${e} ${t - n + 3}v${2 * n - 6}`,
			transform: `rotate(${r} ${e} ${t})`,
			fill: "none",
			strokeWidth: ".7"
		}, r)),
		/* @__PURE__ */ m("circle", {
			cx: e,
			cy: t,
			r: "3",
			fill: "#6c6144"
		})
	] });
}
function qn({ x: e, y: t, s: n = 1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		stroke: "#84927a",
		strokeWidth: ".8",
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-15-10 2-19 18-8 16 14-14 14Z",
				fill: "#c8c8a7"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-21-9 22-20 23 20-7 3L1-20-13-5Z",
				fill: "#99ac9b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-2 14V1h8v13M-10-6h7v6h-7m5-18 3 5m7-3 4 5",
				fill: "none"
			})
		]
	});
}
function Jn({ x: e, y: t, s: n = 1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-25 6q-2-17 14-17l20 3 7-10 8 2 2 10 12 4 0 7-15 1-9 10-22 0-11-7-9 0m6 6-1 14 6 0 4-13m15-1 6 13 6-1-5-15",
				fill: "#b7ad86"
			}),
			/* @__PURE__ */ m("path", {
				d: "M14-15q-13-6-14 1l4 18 6-2 4-13m11 2 10 5m-52 8 10 4",
				fill: "#98784d"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "20",
				cy: "-9",
				rx: "2",
				ry: "2.5",
				fill: "#eee6c7"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "21",
				cy: "-9",
				r: ".8"
			})
		]
	});
}
function Yn({ card: e }) {
	switch (e) {
		case 0: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M75 100q-1 13-11 24l-5 8 6 3q10-7 18-23m8-13q2 12 2 24l12 7-1 5-14-3q-5-12-9-21",
				fill: "#56818d"
			}),
			/* @__PURE__ */ m("path", {
				d: "M63 123q4 0 7 5l-5 8-4 0-3 3-6-1q-1-4 7-9Zm28 0q4-2 7 1l0 4 12 2q6 2 5 7l-15 0-8-5Z",
				fill: "#5d5b45"
			}),
			/* @__PURE__ */ m("path", {
				d: "m62 128 4 1m-9 7 6-3m32-5 3 0m0 5 12 1",
				fill: "none",
				stroke: "#aaa27b",
				strokeWidth: ".7"
			}),
			/* @__PURE__ */ m("path", {
				d: "M73 73q-8 6-9 15l2 15q13 8 28 0l1-15-5-14-8 5Z",
				fill: "#5d8d99"
			}),
			/* @__PURE__ */ m("path", {
				d: "M69 84q-3 10 0 17l6 2 0-20m15 0 3 18-5 3-2-21",
				fill: "#487480",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M71 79Q52 70 53 50l-5-1q-6 28 17 39m24-7q23-4 22-30l-5-1q-1 17-19 23",
				fill: "#d1b683"
			}),
			/* @__PURE__ */ m("path", {
				d: "M68 74q-5 2-6 8l8 5 7-9m12-5 8 7-5 7-9-8",
				fill: "#789faa"
			}),
			/* @__PURE__ */ m("path", {
				d: "M67 96q15 4 27-1l0 5q-14 4-27 0Z",
				fill: "#725c40"
			}),
			/* @__PURE__ */ m("path", {
				d: "m80 97 7 0 0 5-7 0Z",
				fill: "#b8ad74"
			}),
			/* @__PURE__ */ m("path", {
				d: "m74 79 15 19m-18-16 14 18",
				fill: "none",
				stroke: "#a17d50",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ m("path", {
				d: "M64 91q-10 0-10 10l3 12 13-3 1-14Z",
				fill: "#916d46"
			}),
			/* @__PURE__ */ m("path", {
				d: "M55 97q8 4 15 0m-10 7 4 0m0-4 0 8",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "m91 106 3 18 5 1-3-19m-3-2 7-2 1 4-8 3",
				fill: "#a7b3a3"
			}),
			/* @__PURE__ */ m(Gn, {
				card: 26,
				x: 66,
				y: 40,
				w: 39,
				h: 41
			}),
			/* @__PURE__ */ m("path", {
				d: "M49 24q-6-12-13-14l-3-7q3-4 7 0l9 7m17 9-2-12q1-6 5-4l3 13m21 7 5-14 7-3 3 4-7 5-1 12m18 2 11-11 7 0q5 3 1 6l-9 2-4 10",
				fill: "#9c7950"
			}),
			/* @__PURE__ */ m("path", {
				d: "M40 24q13-17 37-11 22-8 35 8l9 12q-5 16-30 17-31 3-48-11Z",
				fill: "#ab8455"
			}),
			/* @__PURE__ */ m("path", {
				d: "M44 28q25-15 55-8-4 17-30 22-15 2-25-5Z",
				fill: "#c29a63",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M108 29q-4-14 8-18 11-1 16 11l-1 12 10 4-1 7-10 1-7 7-11-5-6-9Z",
				fill: "#af8859"
			}),
			/* @__PURE__ */ m("path", {
				d: "M115 13q-10-10-14-3-3 6 7 12m17-6q1-12 8-8 6 5-3 13",
				fill: "#a27b4f"
			}),
			/* @__PURE__ */ m("path", {
				d: "M125 34q9-4 15 3l-1 8-10-1-6-5Z",
				fill: "#c2a375"
			}),
			/* @__PURE__ */ m("path", {
				d: "m135 38 5 1-1 4-4-1Z",
				fill: "#514d39"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "120",
				cy: "29",
				rx: "3",
				ry: "3.7",
				fill: "#ece0b9"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "121",
				cy: "30",
				r: "1.2",
				fill: "#403d2d"
			}),
			/* @__PURE__ */ m("path", {
				d: "m49 26 5-6m4 5 6-5m2 9 7-5m7 0 7-6m-31 20 6-5m5 6 7-6m8 2 8-5m-30-13 4-3m34 24 7-4m-1 6 5-2m18 0 5 2",
				fill: "none",
				stroke: "#735a3c",
				strokeWidth: ".7"
			}),
			/* @__PURE__ */ m("path", {
				d: "m47 48 2-7 5 1 2 7m50 1-1-8 5-2 3 9m-30 33 7 2m-9 3 0 9m-12 3 12 3",
				fill: "none"
			}),
			/* @__PURE__ */ h("g", {
				transform: "translate(23 124)",
				children: [
					/* @__PURE__ */ m("path", {
						d: "M-10 0q-3-11 7-14l7-2 3 8 12 3-3 5-12 0-8 4Z",
						fill: "#dce0c9"
					}),
					/* @__PURE__ */ m("path", {
						d: "m0-14-3-16 4-1 2 14m3 1 5-14 3 1-4 15",
						fill: "#e5e4ce"
					}),
					/* @__PURE__ */ m("circle", {
						cx: "6",
						cy: "-11",
						r: "1"
					})
				]
			}),
			/* @__PURE__ */ m("path", {
				d: "m29 47-5-6m6 0-7 5m111 22 6-6m-8 0 7 6",
				fill: "none",
				stroke: "#b3a15f"
			})
		] });
		case 1: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M26 112q40-18 103-3l-3 9-97 3Z",
				fill: "#9c8a58"
			}),
			/* @__PURE__ */ m("path", {
				d: "M33 51q6-26 42-28 27 0 35 23l2 38-10 17-58 2-12-20Z",
				fill: "#689399"
			}),
			/* @__PURE__ */ m("path", {
				d: "M39 52q10-21 35-22 22 0 30 18l-1 37-19 14-36-2-10-16Z",
				fill: "#84a8a7"
			}),
			/* @__PURE__ */ m("path", {
				d: "M43 53 62 47l-1 32-17 5Zm24-8 20 0 0 36-19-1Zm25 1 11 8 0 27-11-1Z",
				fill: "#b7c8bb"
			}),
			/* @__PURE__ */ m("path", {
				d: "m43 54 3 24 11-7 5 7m6-32 4 26 12 7m11-31 5 26m-60 17 19 4m8 3 19 0m-16-4 0-9m11 0 4 0",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M36 51q-14-11-3-19l10 1 5-11 10 1 3-10 15 7 15-3 6 9 14-1 4 11-12 4m-68 51q-20 5-22-5-1-6 8-9 7 1 6 5m77 7q24 6 25-9-3-11-11-3m-82-30 15-3m21-18 8 5 14 0m5-9-7 4",
				fill: "none",
				stroke: "#a58c53",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ m("path", {
				d: "M114 71q13-8 25 1l4 27-19 1-10-15Z",
				fill: "#8c7150"
			}),
			/* @__PURE__ */ m(Gn, {
				card: 21,
				x: 120,
				y: 27,
				w: 38,
				h: 43
			}),
			/* @__PURE__ */ m("path", {
				d: "M139 75q10-3 14 9l-11 12-5-4 7-9-9-4m-11 18 26 2 8 13-5 6-12-14-17-1",
				fill: "#a18358"
			}),
			/* @__PURE__ */ m(Kn, {
				x: 45,
				y: 112,
				r: 19
			}),
			/* @__PURE__ */ m(Kn, {
				x: 126,
				y: 104,
				r: 19
			}),
			/* @__PURE__ */ m(Kn, {
				x: 23,
				y: 139,
				r: 14
			}),
			/* @__PURE__ */ m("path", {
				d: "m13 8 14 22-12 42m150-62-17 22 18 34m-161-24 15-17m142 2 12 9",
				fill: "none",
				stroke: "#819f91"
			})
		] });
		case 2: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M79 91q25 8 58-3l7 11-26 17-29-7-31-17-9-1",
				fill: "#9c8153"
			}),
			/* @__PURE__ */ m("path", {
				d: "M88 96 121 102l-3 18m-39-21 21 25m-33-32-14-8",
				fill: "none",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ m(Kn, {
				x: 137,
				y: 118,
				r: 23
			}),
			/* @__PURE__ */ m("path", {
				d: "M47 90q-13 7-15 22l-12 10 3 6q10-4 18-12l17-17m2-10q3 10 10 20l13 6 2-5-10-9-6-18",
				fill: "#5f8691"
			}),
			/* @__PURE__ */ m("path", {
				d: "M21 120q7-1 8 5l-7 8-4-1-6 3-4-4 9-5Zm52-15q5-2 8 1l-1 5 10 5q6 1 5 7l-12-1-11-9Z",
				fill: "#56645b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M41 57q-9 5-9 17 0 11 17 22l19-10q-8-11-8-25l-9 2Z",
				fill: "#668d96"
			}),
			/* @__PURE__ */ m("path", {
				d: "M36 68q-4 9 3 16l14 7 6-3-14-11-4-11",
				fill: "#507780",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M42 59q-7-8-13-5L15 72l-5 7 6 4q11-8 20-20m23 1q8 8 16 21l9 0 2 5-12 0q-12-7-21-17",
				fill: "#d1b987"
			}),
			/* @__PURE__ */ m("path", {
				d: "M39 58q-4-4-8-3l-6 7 9 6 10-5m11-2 8 0 6 9-7 6-10-10",
				fill: "#7d9fa8"
			}),
			/* @__PURE__ */ m("path", {
				d: "M31 57q-9-9-15-4L7 81q-3 5 2 8l14 4 5-9 6-23Z",
				fill: "#a36f50"
			}),
			/* @__PURE__ */ m("path", {
				d: "M15 57q9 7 17 3m-24 23 18 3m-15-7 17 4m-7-27-7 26m11-21-7 22m20-22 20 25m-18-29 20 27",
				fill: "none",
				stroke: "#6b533a"
			}),
			/* @__PURE__ */ m("path", {
				d: "M81 85q2-3 5-1l2 5-5 3-4-3m-66-12-4 3 2 4 5 0",
				fill: "#d1b987"
			}),
			/* @__PURE__ */ m(Gn, {
				card: 26,
				x: 29,
				y: 17,
				w: 42,
				h: 43
			}),
			/* @__PURE__ */ m("path", {
				d: "M105 66q-10 8-11 20-1 13 17 17l20-5q-8-12-3-21l-9-8Z",
				fill: "#94704d"
			}),
			/* @__PURE__ */ m("path", {
				d: "M112 94q-8 10 1 20l16 0 3-4-11-3 4-9m-18-26q0 7 4 14 11-2 25-10l7-12-4-3-9 11-14 3",
				fill: "#c0a271"
			}),
			/* @__PURE__ */ m("path", {
				d: "m109 81 5 3 17-8m-24 10 6 6m9-7 5 6m-20 10 9 5m-5 4 9 0",
				fill: "none"
			}),
			/* @__PURE__ */ m(Gn, {
				card: 9,
				x: 91,
				y: 8,
				w: 45,
				h: 64
			}),
			/* @__PURE__ */ m("path", {
				d: "m103 97 7-1m-62-21 4 6m10 0 6 6m42-7 6 4m-84 49 9-4m-12 10 9-4",
				fill: "none"
			})
		] });
		case 3: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M-3 65 30 21l24 28L81 7l37 47 26-25 39 45Z",
				fill: "#b6c3ac",
				stroke: "#8d9d82"
			}),
			/* @__PURE__ */ m("path", {
				d: "M83 43q-18 20 14 30 58 21 16 36l-37 21 12 20h58l-27-20q60-19 8-38-49-16-24-38",
				fill: "#b2cebd",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M88 48q-14 17 16 27 54 20 17 34L84 130",
				fill: "none",
				stroke: "#d4e0c5",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ m(qn, {
				x: 137,
				y: 94,
				s: .55
			}),
			/* @__PURE__ */ m(qn, {
				x: 149,
				y: 116,
				s: .8
			}),
			/* @__PURE__ */ m(qn, {
				x: 113,
				y: 131,
				s: .45
			}),
			/* @__PURE__ */ m("path", {
				d: "M3 123q23-16 58-3l12 16-11 14H2Z",
				fill: "#9ba591"
			}),
			/* @__PURE__ */ m("path", {
				d: "M8 130q22-10 51-1m-55 9 42-1m-31 5 35-2",
				fill: "none",
				stroke: "#748673"
			}),
			/* @__PURE__ */ m("svg", {
				x: "6",
				y: "32",
				width: "78",
				height: "105",
				viewBox: "0 0 140 180",
				children: /* @__PURE__ */ m(fn, { card: 13 })
			})
		] });
		case 4: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Gn, {
				card: 1,
				x: 13,
				y: 40,
				w: 35,
				h: 39
			}),
			/* @__PURE__ */ m("path", {
				d: "M24 73q-9 4-12 17-4 12 2 20l16 12 18-7q-11-15-9-34l-6-3Z",
				fill: "#a47856"
			}),
			/* @__PURE__ */ m("path", {
				d: "M17 87q-5 14 3 22l9 7 7-2q-12-8-11-20Z",
				fill: "#8e6145",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M28 83q8 0 16 9l11-4 4 5-15 9q-9-2-17-9",
				fill: "#b1aa83"
			}),
			/* @__PURE__ */ m("path", {
				d: "M53 88q2-5 5-3l0 5 4-2q4 2 0 4l-6 2m-40 15q3 15 16 18l7-4 5 1 6-3q-2-5-11-3l-5 2-9-13",
				fill: "#bda87a"
			}),
			/* @__PURE__ */ m("path", {
				d: "M19 109q-5 7-1 13l11 9 9-3-2-5-8 0-7-12m12 2q6 8 15 10l7-1 3 4q-1 4-9 3l-15-8",
				fill: "#6a716c"
			}),
			/* @__PURE__ */ m("path", {
				d: "m20 120 8 6m5 0 1 3m5-13 5 5m-26-25 2 4m9-9 3 4m8 2 3 1",
				fill: "none",
				strokeWidth: ".7"
			}),
			/* @__PURE__ */ m(Gn, {
				card: 0,
				x: 65,
				y: 12,
				w: 42,
				h: 42
			}),
			/* @__PURE__ */ m("path", {
				d: "M78 52q-11 4-13 17l1 16 11 12q13 0 23-8l-6-29-7-4-4 5Z",
				fill: "#788c57"
			}),
			/* @__PURE__ */ m("path", {
				d: "M70 67q-3 14 6 23l7 3 1-31m9 7 4 18-5 4",
				fill: "#657a49",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M76 60q-9 4-13 13l-11-2-2 5 16 7q9-3 14-11m14-6q10 3 12 12l-4 14-6-2 2-11-10-5",
				fill: "#c4ad77"
			}),
			/* @__PURE__ */ m("path", {
				d: "m72 58-3 8 9 6 7-8m7-5 6 5-4 9-8-8M77 89l12 0m-5-30 0 5m0 7 0 4m0 4 0 4",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M77 92q-5 7-4 14l16 5 13-9-4-10-11 6Z",
				fill: "#69766a"
			}),
			/* @__PURE__ */ m("path", {
				d: "M54 71q-5-6-8-2l3 7 6 1m46 11q6-2 6 2l-6 7-5-1 0-4",
				fill: "#c4ad77"
			}),
			/* @__PURE__ */ m("svg", {
				x: "117",
				y: "55",
				width: "55",
				height: "80",
				viewBox: "0 0 140 180",
				children: /* @__PURE__ */ m(fn, { card: 25 })
			}),
			/* @__PURE__ */ m("g", {
				transform: "translate(87 126) scale(.9)",
				children: /* @__PURE__ */ m(hn, {})
			}),
			/* @__PURE__ */ m("path", {
				d: "m70 133 10 0m21-1 10 0m-24-35-3-6m10 5 4-6",
				fill: "none",
				stroke: "#a78b52"
			})
		] });
		case 5: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ h("g", {
				transform: "translate(113 94)",
				children: [
					/* @__PURE__ */ m("path", {
						d: "M-31 0v28q30 16 59-1V0",
						fill: "#b4b598"
					}),
					/* @__PURE__ */ m("ellipse", {
						rx: "30",
						ry: "10",
						fill: "#6b8e83"
					}),
					/* @__PURE__ */ m("path", {
						d: "m-28 10 15 4m-13 7 17 4m10-9 15-1m-11 9 21-2M-28-2v-53m54 55v-55",
						fill: "none"
					}),
					/* @__PURE__ */ m("path", {
						d: "m-38-53 11-23 53 7 12 27-61-4Z",
						fill: "#68929a"
					}),
					/* @__PURE__ */ m("path", {
						d: "m-27-23 52 0m-27-20 0 48m-13-73 45 8m-48 0 50 7",
						fill: "none"
					}),
					/* @__PURE__ */ m("path", {
						d: "M-2-28q-12-7-16 0l-1 10q5 7 13 0m-12-3 16 0",
						fill: "#bba475"
					})
				]
			}),
			/* @__PURE__ */ m("path", {
				d: "M48 99q-8 11-6 26l-8 6 1 5 13-4q5-9 8-21m8-11q1 12 9 21l13 8 1 5-12-3-15-20",
				fill: "#7c91a0"
			}),
			/* @__PURE__ */ m("path", {
				d: "M38 127q7-1 8 4l-8 7-9 0-2-3 7-2m43-8 5 0 4 4 7 1q5 2 3 6l-16-3-5-5",
				fill: "#5e675c"
			}),
			/* @__PURE__ */ m("path", {
				d: "M45 64q-10 7-11 23l2 13q8 10 17 11l21-6q-8-17-5-34l-8-4-3 6-9-8Z",
				fill: "#e1dfc8"
			}),
			/* @__PURE__ */ m("path", {
				d: "m41 72 5 14-4 14 7 5m11-29 4 22 8 4m-22-32 5 5m-5 6 1 7m3 7 2 5",
				fill: "none",
				stroke: "#a6aa90"
			}),
			/* @__PURE__ */ m("path", {
				d: "M46 72q-10 7-5 17 13 3 27-3l6-10-5-2-5 6-15 2m16-9q7 2 14 7l8-9-4-3-7 5-9-7",
				fill: "#d7c89a"
			}),
			/* @__PURE__ */ m("path", {
				d: "m43 77 5 4m-1 6 15-2m7-9 4 0m10-8 3-5 3 2-2 6 2 2-3 4-5-4",
				fill: "none"
			}),
			/* @__PURE__ */ m(Gn, {
				card: 18,
				x: 32,
				y: 25,
				w: 43,
				h: 43
			}),
			/* @__PURE__ */ m(Jn, {
				x: 150,
				y: 135,
				s: .72
			})
		] });
		case 6: return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Wn, {}), /* @__PURE__ */ m(Fn, {
			x: 135,
			y: 48,
			s: .87
		})] });
		case 7: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M18 116q10-19 18-13l11 9 7 17 12 1 0 5-18 2-16-23-7 10m83-9 17-5 13 14 16-1 2 5-20 3-17-11-11 4",
				fill: "#8c7960"
			}),
			/* @__PURE__ */ m("path", {
				d: "M33 71q10-29 39-30 19-5 37 5 34 0 39 32 3 12-7 20l12 0-9 7-18-5q-12 15-42 15-22 4-35-7L27 94Z",
				fill: "#9a8c83"
			}),
			/* @__PURE__ */ m("path", {
				d: "M37 85q-15-17-27-11L1 91l3 12 18-4 13 4 13-12Z",
				fill: "#a19384"
			}),
			/* @__PURE__ */ m("path", {
				d: "M8 90q5-12 13-11l4 13-11 7-8-1Z",
				fill: "#bfaa86"
			}),
			/* @__PURE__ */ m("path", {
				d: "M36 79q-17-19-2-33l12 19m18-18 11-13 10 5-7 17",
				fill: "#676f62"
			}),
			/* @__PURE__ */ m("path", {
				d: "M22 94q-14-1-9-12l-4 3q-8 14 9 19l5-6m14-9q7 6 13-2",
				fill: "#dfd3aa"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "38",
				cy: "74",
				rx: "5",
				ry: "6",
				fill: "#eee4c1"
			}),
			/* @__PURE__ */ m("path", {
				d: "m33 70 9-3m-4 5 0 4m-26 15 2 0m4-2 1 1",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M143 56q16 3 14-11-2-7-8-5 7-10 12-7l4 5-5 4q8 19-12 23m-98-9 10-5m1 2 11-4m4 1 14-4m-40 16 11-4m1 3 13-5m6 1 14-4m-39 14 9-2m8 1 12-4m7 0 13-4m-45 16 9-3m4 4 13-4m8 2 12-5m-35 14 10-1m5-2 12-1m-1-19 16-3m-4 9 17-2m-6 8 13-1",
				fill: "none",
				stroke: "#605d4f"
			}),
			/* @__PURE__ */ m("path", {
				d: "M47 104q32 12 67-1l19-14-7 14q-36 24-73 11Z",
				fill: "#7f7569",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M35 90q-10 10-4 19l14 17q4 5 1 7l-7 2 11 1q5-1 2-8-7-11-12-21m74-8q-5 10 5 18l13 8q3 3 1 5l6 0q5-5-1-9l-12-15m-101 11-4 8-4-1m-5-5-2 9 5 2m121-7-1 6 7-1",
				fill: "#8e7c66"
			}),
			/* @__PURE__ */ m("path", {
				d: "M42 87q18-9 24 7-1 12-18 16m61-23q17 0 20 12l-6 11m-85-33q6 4 8 13M9 86q-4 2-2 7m3 5 6 0m18-45 4 9m-17 60 5 2m108 2 6-2m-91 7 1 5m-33-7-1 3",
				fill: "none",
				stroke: "#615e4e",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("path", {
				d: "m34 47 3 11-5-2 5 14-8-1m26-25 1-8 7 8 2-8 8 7 2-6 9 6 2-7 12 8 0-5 13 9",
				fill: "#96877a"
			}),
			/* @__PURE__ */ m("path", {
				d: "m41 94 4 8m13-6 12 5m27-8 9-2m-3-35 12 5m-14 5 17 5m-5 6 16 7m-8 4 9 1m-71 40 7 4m5-1 6 4m41-4 4 4m-7-9 5 4",
				fill: "none",
				strokeWidth: ".7"
			})
		] });
		case 8: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("svg", {
				x: "44",
				y: "15",
				width: "84",
				height: "115",
				viewBox: "0 0 140 180",
				children: /* @__PURE__ */ m(fn, { card: 25 })
			}),
			/* @__PURE__ */ m("path", {
				d: "M67 128q19-11 33 0l-3 9-23 2Z",
				fill: "#977c50"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "84",
				cy: "127",
				rx: "16",
				ry: "5",
				fill: "#625c3e"
			}),
			/* @__PURE__ */ m(Gn, {
				card: 31,
				x: 128,
				y: 79,
				w: 48,
				h: 52,
				flip: !0
			}),
			/* @__PURE__ */ m("path", {
				d: "M140 128q-13 6-13 17h51v-18Z",
				fill: "#6b8f91"
			}),
			/* @__PURE__ */ m("path", {
				d: "M0 130q5-18 14-17l8-25q1-9 9-7 9 1 8 10l-7 10-1 20-13 16Z",
				fill: "#d9dfcc"
			}),
			/* @__PURE__ */ m("path", {
				d: "m39 89 15 6-17 2m0 0 15 4-14 1",
				fill: "#b79b5b"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "30",
				cy: "88",
				r: "2",
				fill: "#394234"
			}),
			/* @__PURE__ */ m(qn, {
				x: 15,
				y: 30,
				s: .55
			}),
			/* @__PURE__ */ m(qn, {
				x: 151,
				y: 30,
				s: .6
			})
		] });
		case 9: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M76 98q-4 15-6 29l-5 7q0 5 7 6l8-8 10-24m6-7q2 12 1 24 2 8 9 10l10 1q6-1 2-4l-13-8q2-12 0-23",
				fill: "#6d8796"
			}),
			/* @__PURE__ */ m("path", {
				d: "m73 107 4 10-5 13m23-20 6-3 0 18 7 7",
				fill: "none",
				stroke: "#506c78"
			}),
			/* @__PURE__ */ m("path", {
				d: "M70 129q4-2 7 3l-3 8-8 2-5-3 5-7m38-4q4-2 7 2l7 2q7 1 6 7l-15-1-7-6Z",
				fill: "#665b45"
			}),
			/* @__PURE__ */ m("path", {
				d: "M77 66q-12 7-13 25l1 9q9 7 19 9l23-6q-5-18-6-35l-10-5-5 6Z",
				fill: "#b78d58"
			}),
			/* @__PURE__ */ m("path", {
				d: "M67 81q-4 17 9 23l8 2-4-38m18 8 5 24-8 4",
				fill: "#9a784e",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M78 70q-14 6-18 19l-16-7-2 5q12 11 19 12 6-1 10-13m30-14q7 6 10 19l10 5-2 5q-11-2-16-8l-9-13",
				fill: "#b58b58"
			}),
			/* @__PURE__ */ m("path", {
				d: "M79 69 83 102m10-33 3 31m-37-12-20-18-2 3 17 18Z",
				fill: "#5b563f"
			}),
			/* @__PURE__ */ m("path", {
				d: "M38 76 39 59l3-8 3 8-2 17Z",
				fill: "#c1c5ad"
			}),
			/* @__PURE__ */ m("path", {
				d: "M75 34q10-10 22-2l4 7-2 10 12 4q6 4 1 7l-13 0-6 10q-7 4-14-4l-6-13-5-5 1-7Z",
				fill: "#c6aa79"
			}),
			/* @__PURE__ */ m("path", {
				d: "M70 34q-5 2-5 8l-5 6 10-1-5 8 9-3 4-12m14-9 10 4 0 9-5 4m-17 14 6 4 5-1",
				fill: "#a78e5d"
			}),
			/* @__PURE__ */ m("path", {
				d: "M68 33q3-7 12-6l-3-22q2-5 10-4l9 2 2 23 13 1q7 3 1 7-17 9-34 7Z",
				fill: "#627f8a"
			}),
			/* @__PURE__ */ m("path", {
				d: "M81 6 83 25l10 0-1-19m-19 27q17 6 33-1",
				fill: "none",
				stroke: "#8fa4a1"
			}),
			/* @__PURE__ */ m("path", {
				d: "M77 39q-9 3-9 12l-5 5 10 0 4-8m17-12 8 0-1 12-7 2M78 51l7 0m9-2 5-1m-14 11 12 3",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "m12 16 16 44-15 23m141-78-15 38 18 28m-136-29-11-10m132 3 15-7",
				fill: "none",
				stroke: "#859880"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "86",
				cy: "42",
				rx: "4",
				ry: "5",
				fill: "#f2e6c2"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "87",
				cy: "43",
				rx: "1.4",
				ry: "2",
				fill: "#373d30",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "m81 35 8-2m-7 22 8 0m-9 11 4 4 8-3m-12 12 1 18m11-17 2 16m-11 5 12-2m-30-10 3 2m43 6 6 4",
				fill: "none",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("path", {
				d: "M44 80q-5-6-8-3-2 3 1 5l3 1-2 3q4 5 8 1m73 9q4-4 7 0l3 4q1 5-4 5l-5-4Z",
				fill: "#c4ad7c"
			}),
			/* @__PURE__ */ m("path", {
				d: "m38 80 4 3m-2 0 4 2m79 13 3 3m-3-1 2 3m-49 34 4 0m33-3 7 2m-33-57 3 0m-1 8 3 0",
				fill: "none",
				strokeWidth: ".65"
			})
		] });
		case 10: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M27 113q10-8 24-5l5 12-5 6-29 0Z",
				fill: "#a78b5f"
			}),
			/* @__PURE__ */ m(Fn, {
				x: 43,
				y: 46,
				s: .91,
				talking: !0
			}),
			/* @__PURE__ */ m("path", {
				d: "M122 99q-5 15-16 23l5 7q11-3 17-12m8-12q4 9 0 19l12 5q6 4 1 4l-14-1q-7-6-6-15",
				fill: "#738084"
			}),
			/* @__PURE__ */ m("path", {
				d: "M119 67q-11 11-7 31 6 10 18 11 11 0 20-8-6-10-6-31Z",
				fill: "#c1a062"
			}),
			/* @__PURE__ */ m("path", {
				d: "M116 76q-5 16 3 24l10 5-3-33m15 5 4 20-7 5",
				fill: "#9f8656",
				stroke: "none"
			}),
			/* @__PURE__ */ m(Gn, {
				card: 18,
				x: 107,
				y: 30,
				w: 42,
				h: 41,
				flip: !0
			}),
			/* @__PURE__ */ m("path", {
				d: "M117 76q-8 4-10 16l-12 1 0 6 19 0 9-14m17-9 12 13-1 13-6 0 0-12-11-7",
				fill: "#cbb27c"
			}),
			/* @__PURE__ */ m("path", {
				d: "m117 71-6 7 10 10 8-11m8-5 9 7-6 7m-13-14 3 29m-1-20 3 0m-2 8 3 0m-13 8 6 4m6-5 8 1m-25 22-4 7m25-7 0 6",
				fill: "none",
				stroke: "#685d3d",
				strokeWidth: ".75"
			}),
			/* @__PURE__ */ m("path", {
				d: "M150 108q17-8 23 6l-1 21-20 5-9-11Z",
				fill: "#6b9292"
			}),
			/* @__PURE__ */ m("path", {
				d: "m153 114 16 0m-17 7 17 0m-14 6 13 0",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M60 16q22-12 38-3l16 19-20 1-9-5q-23 3-30-5l-7 4 3-12Z",
				fill: "#dce0ca"
			}),
			/* @__PURE__ */ m("path", {
				d: "m60 15 9 5 9-9m12 3-4 11m-9-7 1 7m22-6 5 4m-2 1 3 3",
				fill: "none",
				stroke: "#859780"
			})
		] });
		case 11: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M53 76q-21-6-25 8-21-1-19 14-14 7-5 18 7 6 22 2-2 16 18 16l21-7q9 15 27 7l9-9q16 12 29 0l2-10q21 1 23-16 4-13-13-20 6-16-11-20-11-9-26 0-11-19-27-11-13 3-12 17-15-8-23 5Z",
				fill: "#e4e1ca"
			}),
			/* @__PURE__ */ m("path", {
				d: "M29 94q-13 5-7 14l17 0m11-28q-18 4-17 16m43-27q-20 6-11 19m31-23q13-4 20 5m2 18q18-2 18 11-2 7-14 8m-35-3q-17 2-12 13l15 1m-36 4q12 8 23-2m33-5 12 3",
				fill: "none",
				stroke: "#8e9b83"
			}),
			/* @__PURE__ */ m("path", {
				d: "M45 86q-8-2-9-10l-5-7 3-4 8 4 3-9 4 0 0 12 6-6 4 3-11 15m61 41q-3 7 7 12l7-4 10 2 4-4-4-4-18-8M17 112l-8 12-8 3 1 5 15-2 8-12",
				fill: "#c7ac76"
			}),
			/* @__PURE__ */ m("path", {
				d: "M21 40q-13-3-17 4l4 10 20 4-4-9m18-12 5 6m55-16-6 9m5 4 9-4m37 6 6-9m-2 1 5 1m-14 1 13 2",
				fill: "none",
				stroke: "#a98c50",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ m("path", {
				d: "m57 39 10-4 2-13 14 3 3 12 13 2q-20 15-42 0Z",
				fill: "#a3804f"
			})
		] });
		default: return null;
	}
}
//#endregion
//#region src/games/pilgrims/adventure-stories.tsx
function Xn({ card: e, x: t, y: n, w: r = 40, h: i = 42, flip: a = !1 }) {
	return /* @__PURE__ */ m("g", {
		transform: a ? `translate(${t + r} ${n}) scale(-1 1)` : `translate(${t} ${n})`,
		children: /* @__PURE__ */ m("svg", {
			width: r,
			height: i,
			viewBox: "0 0 70 75",
			children: /* @__PURE__ */ m(wn, { card: e })
		})
	});
}
function Zn({ card: e, x: t, y: n, w: r = 70, h: i = 105 }) {
	return /* @__PURE__ */ m("svg", {
		x: t,
		y: n,
		width: r,
		height: i,
		viewBox: "0 0 140 180",
		children: /* @__PURE__ */ m(fn, { card: e })
	});
}
function Qn({ x: e, y: t, s: n = 1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-18-12q-8-12-14-5-6 8 5 13m35-9q2-13 11-10 8 5 1 14",
				fill: "#a47b53"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-24-9q17-18 36-6l5 10 16 9q7 8-1 13l-20-1-5 11-23-4-15-15Z",
				fill: "#b78b5a"
			}),
			/* @__PURE__ */ m("path", {
				d: "M2 3q11-5 23 3l7 0 1 7-7 5-19-3Z",
				fill: "#c5a270"
			}),
			/* @__PURE__ */ m("path", {
				d: "M25 5q8-4 11 1l-1 6-7 1-4-3Z",
				fill: "#3d4737"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "1",
				cy: "-3",
				rx: "4",
				ry: "5",
				fill: "#eee0b7"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "2",
				cy: "-3",
				r: "1.6",
				fill: "#384031"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-5-11 9-2m-28-3-3 4M-18 10q9 9 22 7m-23-20 4-2m-9 13 5 1m8 6 5 2m-8 5 6 2",
				fill: "none",
				strokeWidth: ".8"
			})
		]
	});
}
function $n({ x: e, y: t, s: n = 1, white: r = !1 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M0 40Q5 11 0-17m2 38q-18 1-23-12 18-2 23 9m-1-7q15-15 25-10-5 15-24 16m-2-18q-12-7-13-18 15 0 14 15",
				fill: "#7e9f7d"
			}),
			[
				0,
				1,
				2,
				3,
				4,
				5
			].map((e) => /* @__PURE__ */ m("path", {
				d: "M0-8q-13-1-11-13 7-8 13 5Z",
				transform: `rotate(${e * 60} 0 -11)`,
				fill: r ? "#e8e4c8" : "#d5b26b"
			}, e)),
			/* @__PURE__ */ m("circle", {
				cy: "-11",
				r: "4",
				fill: "#b28e4a"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-3-12 5 0m-1-3 0 7m-16 7 4 8m12 13 12-11",
				fill: "none",
				strokeWidth: ".7"
			})
		]
	});
}
function er({ card: e }) {
	switch (e) {
		case 12: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Q, {}),
			/* @__PURE__ */ m(Tn, {
				x: 34,
				y: 112,
				s: .86
			}),
			/* @__PURE__ */ m("path", {
				d: "M71 94q-9 12-6 28l-12 11 2 5 15-9 10-19m10-11q-1 11 7 22l-1 13 6 2 3-17-9-16",
				fill: "#6b7b77"
			}),
			/* @__PURE__ */ m("path", {
				d: "M72 62q-13 13-13 27l12 14 27-8-3-29-11-6Z",
				fill: "#668e99"
			}),
			/* @__PURE__ */ m("path", {
				d: "m67 72-3 16 11 9 9-3-8-28",
				fill: "#4b7480",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M73 70q-12 7-24 8l-13 7 1 5 16-4 22-7m18-7 17 11 9 1-1 6-14-1-18-9",
				fill: "#c3a475"
			}),
			/* @__PURE__ */ m(Xn, {
				card: 0,
				x: 65,
				y: 29,
				w: 42,
				h: 42
			}),
			/* @__PURE__ */ m("path", {
				d: "M119 102q-10 10-9 24l-9 8q0 5 7 4l12-9 8-15m12-11q-1 14 9 25l8 3 0 5-12-1-14-17",
				fill: "#a17b53"
			}),
			/* @__PURE__ */ m("path", {
				d: "M117 67q-18 13-16 33 4 13 18 16l25-8q7-23-8-40Z",
				fill: "#b58b59"
			}),
			/* @__PURE__ */ m("path", {
				d: "M104 83q-1 19 17 25l5 7-12 0-12-10-2-14",
				fill: "#94714c",
				stroke: "none"
			}),
			/* @__PURE__ */ m(Qn, {
				x: 128,
				y: 59,
				s: .71
			}),
			/* @__PURE__ */ m("path", {
				d: "M116 78q-10 9-22 7l-4-4-4 3 5 9 24-1 10-6m13-7q8 0 15 12l5-1 2 5-8 3-18-12",
				fill: "#b58b59"
			}),
			/* @__PURE__ */ m("path", {
				d: "M152 89q-6 12-3 23l11 7 12-5-7-26Z",
				fill: "#c5b391"
			}),
			/* @__PURE__ */ m("path", {
				d: "m152 106 14 1-2 8-10-3m3 5-4 17-7 4 1 4 11-4 6-16m0-4 9 12-1 9 5 1 2-13-8-13",
				fill: "#927b5e"
			}),
			/* @__PURE__ */ m(Xn, {
				card: 31,
				x: 148,
				y: 66,
				w: 31,
				h: 32
			}),
			/* @__PURE__ */ m("path", {
				d: "M154 96 143 91l-2 4 13 8m11-10 10 3-1 6-9 0",
				fill: "#d1b887"
			}),
			/* @__PURE__ */ m("path", {
				d: "m46 85 5-1m43 4 5 1m17 10 6 3m10-8 4 4m-19 31 5 1m28-24 3 2m-62-39 1 6",
				fill: "none",
				strokeWidth: ".7"
			})
		] });
		case 13: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Q, {}),
			/* @__PURE__ */ m("path", {
				d: "M61 95q-9 17-1 33l-10 8 3 5 16-3 11-25m22-17q1 20 14 31l-3 11 8 2 6-13-10-23",
				fill: "#a97e53"
			}),
			/* @__PURE__ */ m("path", {
				d: "M60 51q-22 14-22 44 0 27 29 33 30 5 49-16l2-36-21-25Z",
				fill: "#b18a60"
			}),
			/* @__PURE__ */ m("path", {
				d: "M44 75q-5 32 22 44l13-2q-22-16-20-47m37-11q14 16 14 37l-6 15 13-5 1-30Z",
				fill: "#94714e",
				stroke: "none"
			}),
			/* @__PURE__ */ m(Qn, {
				x: 84,
				y: 43
			}),
			/* @__PURE__ */ m("path", {
				d: "M54 70q-4 12 13 18l26 4 4-6-28-12m35-14q9 6 6 16l-10 5 0 6q13 2 21-11 4-11-8-19",
				fill: "#b48a5b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M87 66q2-9 9-9l13 7-3 13-11-2-2 12-5-1 1-12-8-6Z",
				fill: "#d4be76"
			}),
			/* @__PURE__ */ m("path", {
				d: "M95 74q-8-4-11-1-2 4 6 6l6-1m2-5 3-6m1 9 3-7m-45 15 8-2m-10-5 7-2m-17 15 5 3m54-4 6-3m-5-4 6-2m-40 30 11 3",
				fill: "none",
				stroke: "#725a3e",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("path", {
				d: "M121 98 147 89l7 39-27 15-18-12 1-31Z",
				fill: "#66959c"
			}),
			/* @__PURE__ */ m("path", {
				d: "m125 104 23-10 6 34-27 15Z",
				fill: "#47777f"
			}),
			/* @__PURE__ */ m("path", {
				d: "M109 100 131 92l16-3-21 14Z",
				fill: "#a9bbb0"
			}),
			/* @__PURE__ */ m("path", {
				d: "m114 110 7 3m8-7 18-8m-17 17 19-8m-17 17 19-8m-16 17 17-8",
				fill: "none"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "117",
				cy: "116",
				rx: "3",
				ry: "4",
				fill: "#d2c27c"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "119",
				cy: "129",
				rx: "3",
				ry: "4",
				fill: "#d2c27c"
			}),
			/* @__PURE__ */ m("path", {
				d: "M143 75q-7-4-10 1m1-4 1 9m27-40q-6-4-9 0m2-3 1 8M32 50q-7-4-10 1m4-5 0 9m108 39 9-8",
				fill: "none",
				strokeWidth: ".8"
			})
		] });
		case 14: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Q, {}),
			/* @__PURE__ */ m("path", {
				d: "M40 130q44-14 101-3l-4 11-83 5Z",
				fill: "#93b3a2",
				stroke: "none"
			}),
			/* @__PURE__ */ m($n, {
				x: 51,
				y: 95,
				s: 1.3
			}),
			/* @__PURE__ */ m($n, {
				x: 103,
				y: 70,
				s: 1.2,
				white: !0
			}),
			/* @__PURE__ */ m($n, {
				x: 134,
				y: 111,
				s: .8,
				white: !0
			}),
			/* @__PURE__ */ m($n, {
				x: 82,
				y: 123,
				s: .65
			}),
			/* @__PURE__ */ m("path", {
				d: "M65 141q-2-40 40-72m-19 54q35-29 48-32m-56 48Q46 100 35 79m25 31 1-32m38 29 28-4",
				fill: "none",
				stroke: "#698d79",
				strokeWidth: "2"
			})
		] });
		case 15: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Q, {}),
			/* @__PURE__ */ m("path", {
				d: "M1 140q25-24 45-14m78-20q18-19 55-12",
				fill: "none",
				stroke: "#91af9d",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ m(Zn, {
				card: 18,
				x: 119,
				y: 17,
				w: 39,
				h: 63
			}),
			/* @__PURE__ */ m("g", {
				transform: "translate(98 105) rotate(-12)",
				children: /* @__PURE__ */ m(Dn, {
					x: 0,
					y: 0,
					s: 1.15
				})
			}),
			/* @__PURE__ */ m("path", {
				d: "m45 115-12-8m11 15-17-2m104-16 10-8m-5 15 14-4",
				fill: "none",
				stroke: "#688f80"
			})
		] });
		case 16: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(An, {}),
			/* @__PURE__ */ m("path", {
				d: "M43 106q-7 11-6 22l-9 7 1 5 15-7 6-18m7-5 5 21 8 4 2-4-6-8 0-14",
				fill: "#796c55"
			}),
			/* @__PURE__ */ m("path", {
				d: "M36 68q-8 9-7 29l6 16 30-5-5-32-13-10Z",
				fill: "#a57250"
			}),
			/* @__PURE__ */ m("path", {
				d: "m31 84 8 20 23-1-3 7-25 2-6-16",
				fill: "#855d45",
				stroke: "none"
			}),
			/* @__PURE__ */ m(Xn, {
				card: 1,
				x: 29,
				y: 34,
				w: 42,
				h: 45
			}),
			/* @__PURE__ */ m("path", {
				d: "M42 77q5 11 16 11l30-29 4 4-28 35q-10 2-21-6",
				fill: "#b49b70"
			}),
			/* @__PURE__ */ m("path", {
				d: "M61 117 110 28l4 2-49 89Z",
				fill: "#98794c"
			}),
			/* @__PURE__ */ m("path", {
				d: "m104 35-4-16 5-8 3 9 4-17 3 0 0 17 7-14 3 3-7 25-6 6Z",
				fill: "#d5bc77"
			}),
			/* @__PURE__ */ m("path", {
				d: "M124 113q-3 9-14 18l1 5 16-8 5-13m14-6 4 16 13 3 1-5-8-5-1-13",
				fill: "#5f675d"
			}),
			/* @__PURE__ */ m("path", {
				d: "M121 71q-6 10-7 23l7 23 33-9-10-33-13-7Z",
				fill: "#667b88"
			}),
			/* @__PURE__ */ m("path", {
				d: "m116 93 11 14 23-6 4 6-31 10-8-12m15-28 8 23",
				fill: "#4b6470",
				stroke: "none"
			}),
			/* @__PURE__ */ m(Xn, {
				card: 27,
				x: 119,
				y: 33,
				w: 41,
				h: 45,
				flip: !0
			}),
			/* @__PURE__ */ m("path", {
				d: "M123 81q-10 8-19 8l-8-3-3 4 10 6 17-1m24-17 11 10-2 6-11-6",
				fill: "#c0ac7d"
			}),
			/* @__PURE__ */ m("path", {
				d: "m44 95 5 3m-14 3 4 4m84-4 7 2m9-5 6 0m-35-52 7 3",
				fill: "none",
				strokeWidth: ".7"
			})
		] });
		case 17: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Q, {}),
			/* @__PURE__ */ m("path", {
				d: "M3 132q55-13 83 1t94-1v18H0Z",
				fill: "#a4c3b4",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M50 98q-8 14-6 28l-12 9q-4 5 1 5l17-6 9-23m12-8q5 10 4 25l14 5q5-3 1-5l-10-7q4-9 1-20",
				fill: "#78949a"
			}),
			/* @__PURE__ */ m("path", {
				d: "M45 57q-10 12-7 34 3 12 13 17 15 3 32-6-7-17-7-37l-12-9Z",
				fill: "#8f9b74"
			}),
			/* @__PURE__ */ m("path", {
				d: "m40 78 8 21 14 4-10-43m18 8 8 28-9 4",
				fill: "#728263",
				stroke: "none"
			}),
			/* @__PURE__ */ m(Xn, {
				card: 0,
				x: 40,
				y: 23,
				w: 45,
				h: 46
			}),
			/* @__PURE__ */ m("path", {
				d: "M48 69q-3 12 7 16 14 3 28 1l1-6-22-3m11-8q6 3 13 8l8-4 3 4q-4 7-11 8l-16-6",
				fill: "#c3ac79"
			}),
			/* @__PURE__ */ m("path", {
				d: "m47 66-4 7q0 5 9 7l6-8Zm22 0 8 1 5 6-8 7-7-8Z",
				fill: "#9ba781"
			}),
			/* @__PURE__ */ m("path", {
				d: "M80 78q4-6 8-3l3 4-5 6-5-1m11-11 4-2q5 0 5 3l-5 5-4-1M46 91q8 4 19 3m-17 6 12 2m14 4 2 12m-25 1-2 8m-15 9 8 0m41-7 4 2",
				fill: "none",
				strokeWidth: ".75"
			}),
			/* @__PURE__ */ m("path", {
				d: "M76 107Q83 65 123 25l21-8",
				fill: "none",
				stroke: "#66573e",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ m("path", {
				d: "M141 19q26 10 15 43l-11 14",
				fill: "none",
				stroke: "#617d6a",
				strokeWidth: ".7"
			}),
			/* @__PURE__ */ m(jn, {
				x: 139,
				y: 100,
				s: 1.05
			}),
			/* @__PURE__ */ m("path", {
				d: "m129 63 5 5m-7-6 2 7M40 136q-11 7-24 1m75 1 21-1",
				fill: "none"
			})
		] });
		case 18: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M4 137q84-49 173 0M15 145q66-43 150-1m-94-37-21 38m44-39 15 38",
				fill: "none",
				stroke: "#8da699"
			}),
			/* @__PURE__ */ m("path", {
				d: "M52 97q-13 9-17 24l8 6 15-14m9-13 8 24 9 5 4-4-9-9-2-18",
				fill: "#8c7658"
			}),
			/* @__PURE__ */ m("path", {
				d: "M46 127q-9-3-13 3l1 6 14-2m34-10 9 3 2 6-15-1Z",
				fill: "#58634e"
			}),
			/* @__PURE__ */ m("path", {
				d: "M46 62q-10 11-8 30 3 10 17 12 14 0 25-9-5-15-4-29l-13-6Z",
				fill: "#638c9a"
			}),
			/* @__PURE__ */ m("path", {
				d: "M47 63 53 97l13 4-7-36",
				fill: "#426b7b",
				stroke: "none"
			}),
			/* @__PURE__ */ m(Xn, {
				card: 18,
				x: 42,
				y: 22,
				w: 42,
				h: 45
			}),
			/* @__PURE__ */ m("path", {
				d: "M52 71q10 4 20 3l30-12 3 5-29 17-22-3m21-6 16 18 17 0 0 6-23 1-18-17",
				fill: "#cbb789"
			}),
			/* @__PURE__ */ m("path", {
				d: "M115 103q-7 12-6 25l-10 7 1 5 16-7 5-22m8-8 15 15-4 11 5 3 7-15-12-18",
				fill: "#8d7159"
			}),
			/* @__PURE__ */ m("path", {
				d: "M111 67q-11 17-8 33 13 13 36 4-5-22-8-35l-9-5Z",
				fill: "#a27351"
			}),
			/* @__PURE__ */ m("path", {
				d: "m107 86 7 13 20-1 5 6-20 5-16-9",
				fill: "#805b45",
				stroke: "none"
			}),
			/* @__PURE__ */ m(Xn, {
				card: 1,
				x: 107,
				y: 26,
				w: 43,
				h: 45,
				flip: !0
			}),
			/* @__PURE__ */ m("path", {
				d: "M115 74q-6-9-15-10l-3 5 13 13m18-7-10 18-15 1 0 5 22-1 13-15",
				fill: "#c5b180"
			}),
			/* @__PURE__ */ m("path", {
				d: "M48 67q6 2 10 8l-2 8-9-2-4-9m25-7 9 3 5 10-7 4-8-11M109 70q-6 3-8 11l7 7 10-10m10-8 8 6 4 9-8 5-7-10",
				fill: "none",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("path", {
				d: "m98 63 4-3 5 1 1 4-6 3m0 26-5-2-3 2 2 5 8 1m-48-1 6 2m5-5 5 1m37 1 6 1m-5-10 4 4m-8 14 10 0m-59-8 9 1",
				fill: "none",
				strokeWidth: ".7"
			}),
			/* @__PURE__ */ m("path", {
				d: "m33 33 6-2v13m0-5-5 1m114-23 6-2v14m0-4-5 1m-45 0 4 3m-30 63 4 4",
				fill: "none"
			})
		] });
		case 19: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M100 38q11-20 39-11 28 8 31 38 3 29-23 37l-23-9-16-24Z",
				fill: "#a07e57"
			}),
			/* @__PURE__ */ m("path", {
				d: "M112 42q15-13 28-5 19 10 19 34l-10 18-25-9Z",
				fill: "#b39065",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M139 87q-4 12-2 23l-7 11 5 10 6-2-3-8 9-12 1-16m8-2q10 17 4 29l3 9 7-2-3-9 3-21-3-17",
				fill: "#a17c52"
			}),
			/* @__PURE__ */ m("path", {
				d: "M130 124q5-1 11 3l-1 8-13-1Zm31-2 9 2 4 8-12 1-4-5Z",
				fill: "#6b8280"
			}),
			/* @__PURE__ */ m("path", {
				d: "M131 66q-16 9-16 22l-14-8-5 5q13 15 24 13 9-1 10-17",
				fill: "#b19064"
			}),
			/* @__PURE__ */ m("path", {
				d: "m97 81 8 1 4 7-8 3-7-6Z",
				fill: "#6a8280"
			}),
			/* @__PURE__ */ m("path", {
				d: "M145 30q-5-16 2-18l7 18m-2 3q8-16 15-11l-7 18",
				fill: "#b99566"
			}),
			/* @__PURE__ */ m("path", {
				d: "M139 32q21-10 27 9l0 14-7 11-2 14q-5 9-14 4-10-6-5-18l-6-15q-5-11 7-19Z",
				fill: "#b99164"
			}),
			/* @__PURE__ */ m("path", {
				d: "M145 62q-7 0-9 7-5 10 5 14 9 2 14-6l1-10",
				fill: "#c4a676"
			}),
			/* @__PURE__ */ m("path", {
				d: "M141 33q-14-9-24 0l7 1-3 6 9-2-6 9 9-2 1 11 5-8 2-14 13-8 3 9 6 0-7-18q-9-4-15 5Z",
				fill: "#69858d"
			}),
			/* @__PURE__ */ m("path", {
				d: "m137 31 9-6m-17 11 6-3m1 13 4-10m8-18 2 8m13 4-3 6",
				fill: "none",
				stroke: "#a5b6b1",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "153",
				cy: "48",
				rx: "4.7",
				ry: "5",
				fill: "#eee4c1"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "152",
				cy: "49",
				r: "1.8",
				fill: "#394133"
			}),
			/* @__PURE__ */ m("path", {
				d: "M140 74q5 6 11 0m-8-3 0 2m3-2 0 3M150 40q5-3 9 2M115 46q-1 14 9 24m-13-14 6 18m15 25 8 3m21 5 6 2",
				fill: "none",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("path", {
				d: "M55 101q-13 8-17 24l-10 8 2 6 16-7 12-20m12-6 5 23 9 4 2-4-6-10 2-17",
				fill: "#82694c"
			}),
			/* @__PURE__ */ m("path", {
				d: "M45 55q-13 17-11 39 11 19 41 14l15-11-9-34q-9-13-19-13Z",
				fill: "#66848b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M44 58 49 57l5 17q14 5 24-1l0-13 5 2 1 17q1 14 6 25-22 14-51 2 6-15 4-32Z",
				fill: "#a57c4e"
			}),
			/* @__PURE__ */ m("path", {
				d: "M43 80q-2 18 7 23l13 4 6-6-15-28m23 7 7 19-9 5",
				fill: "#816343",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "m47 84 7 6m-7 4 10 6m5-24 13 1m-17 19 5 4m8-10 7 5m-24-32 1 6m24-6 0 6",
				fill: "none",
				stroke: "#574c34",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("svg", {
				x: "31",
				y: "14",
				width: "55",
				height: "52",
				viewBox: "20 0 100 80",
				children: /* @__PURE__ */ m(dn, { card: 20 })
			}),
			/* @__PURE__ */ m("path", {
				d: "M48 65q-7 9-1 17l30 15 5-6-23-17 2-9m17 1 11 15 13-7 4 5-16 11-20-14",
				fill: "#c9ae7e"
			}),
			/* @__PURE__ */ m("path", {
				d: "M83 69 89 65l12 13-6 5Z",
				fill: "#8c7351"
			}),
			/* @__PURE__ */ m("path", {
				d: "M87 59 101 55l5 11-15 4Z",
				fill: "#a2b4ac"
			}),
			/* @__PURE__ */ m("path", {
				d: "m89 59 13-1 1 5-12 4Z",
				fill: "#c2cabc"
			}),
			/* @__PURE__ */ m(On, {}),
			/* @__PURE__ */ m("path", {
				d: "m77 91 4 2m-6-26 4 8m-25 21 5 4m45-19 3 3",
				fill: "none",
				strokeWidth: ".7"
			})
		] });
		case 20: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Q, {}),
			/* @__PURE__ */ m(Zn, {
				card: 14,
				x: 8,
				y: 26,
				w: 72,
				h: 116
			}),
			/* @__PURE__ */ m(Zn, {
				card: 0,
				x: 99,
				y: 38,
				w: 71,
				h: 105
			}),
			/* @__PURE__ */ m("path", {
				d: "m68 87 15-6 8 8m-12-12 1 9m-6-5 5 4m1-6 4 5",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M42 17 46 4m-10 6 15 3",
				fill: "none",
				stroke: "#a1ac8e"
			})
		] });
		case 21: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Q, {}),
			/* @__PURE__ */ m("path", {
				d: "M20 139q67-17 142 0",
				fill: "none",
				stroke: "#91a38a"
			}),
			/* @__PURE__ */ m(En, {
				x: 64,
				y: 103,
				s: 1.1
			}),
			/* @__PURE__ */ m(En, {
				x: 130,
				y: 81,
				s: .95
			}),
			/* @__PURE__ */ h("g", {
				transform: "translate(126 139) rotate(23)",
				children: [/* @__PURE__ */ m("path", {
					d: "M-8-7q-9 3-7 12l14 5 10-11-4-8Z",
					fill: "#b28a68"
				}), /* @__PURE__ */ m("path", {
					d: "m-10-1 13 4m-9-6 12 4m-9-5 0-8 5-1 2 10",
					fill: "none"
				})]
			})
		] });
		case 22: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Q, {}),
			/* @__PURE__ */ m(Zn, {
				card: 12,
				x: 81,
				y: 22,
				w: 83,
				h: 122
			}),
			/* @__PURE__ */ m("path", {
				d: "m111 88-13 3-1 6 17-2m14-6 12 12-3 5-15-11",
				fill: "#b48b5c"
			}),
			/* @__PURE__ */ m(En, {
				x: 114,
				y: 102,
				s: .65
			}),
			/* @__PURE__ */ m("path", {
				d: "M12 135q11-41 21-45l27 1q20 21 19 44",
				fill: "#9ca68a"
			}),
			/* @__PURE__ */ m("path", {
				d: "m20 134 13-29 7 30m8-35 11 35m-21-32 4-9 7 7m-27 7-5 3",
				fill: "none",
				stroke: "#6b856c"
			})
		] });
		case 23: return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Q, {}), /* @__PURE__ */ m(kn, {})] });
		case 24: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M9 134V17h163v117M8 24q30 28 3 86m161-86q-29 28 0 87",
				fill: "#9faf92"
			}),
			/* @__PURE__ */ m(Zn, {
				card: 6,
				x: 25,
				y: 26,
				w: 70,
				h: 116
			}),
			/* @__PURE__ */ m(Zn, {
				card: 26,
				x: 93,
				y: 26,
				w: 74,
				h: 116
			}),
			/* @__PURE__ */ m("path", {
				d: "M13 141q70-35 150 0m-102-3 6-21m38 22-9-22",
				fill: "none",
				stroke: "#85977e"
			}),
			/* @__PURE__ */ m("path", {
				d: "m78 77 8 7 9-4",
				fill: "none"
			})
		] });
		case 25: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M2 146Q16 102 48 57l21 18 32-64q22 3 44 58l33 75Z",
				fill: "#9eae96"
			}),
			/* @__PURE__ */ m("path", {
				d: "m72 71 30-59 23 44-18-11-10 13-8-6Z",
				fill: "#d9dcc0"
			}),
			/* @__PURE__ */ m("path", {
				d: "m47 58 10 17-13 36m59-55-1 24 14 28m-48-13-10 34m-22 7 11-9m75-2 6 6m-31 8-10 3",
				fill: "none",
				stroke: "#748a73"
			}),
			/* @__PURE__ */ m(Zn, {
				card: 18,
				x: 65,
				y: 36,
				w: 75,
				h: 108
			})
		] });
		case 26: return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Q, {}), /* @__PURE__ */ m(In, {})] });
		case 27: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Q, {}),
			/* @__PURE__ */ m("path", {
				d: "M84 91q-12 15-10 31l-10 8q-3 5 2 6l15-8 12-26m19-6q5 11 3 23l13 7q5 6 1 7l-16-5q-9-6-9-17",
				fill: "#ac8054"
			}),
			/* @__PURE__ */ m("path", {
				d: "M86 55q-13 13-10 36 4 10 14 15 14 0 27-7-6-17-5-34l-12-11Z",
				fill: "#ba8c55"
			}),
			/* @__PURE__ */ m("path", {
				d: "M79 74q2 22 13 26l9-1-8-35m15 8 6 22-7 4",
				fill: "#946d47",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M86 58q-18-9-23-24l1-12 9 3 7 13 12-2 8 9-1 16Z",
				fill: "#b88b55"
			}),
			/* @__PURE__ */ m("path", {
				d: "m75 34-8-14q-7-9-11-3-1 6 11 13m24 3q4-18 13-16 9 5-1 14l-7 10",
				fill: "#b69d70"
			}),
			/* @__PURE__ */ m("path", {
				d: "m66 24 4 5m31-6-5 9",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M77 43q9-9 20-1l6 8 14 3-1 6-17 0-5 9-13-4-8-10Z",
				fill: "#c29a67"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "90",
				cy: "46",
				rx: "3.7",
				ry: "4.4",
				fill: "#eee2b9"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "91",
				cy: "46",
				r: "1.4",
				fill: "#384031"
			}),
			/* @__PURE__ */ m("path", {
				d: "m85 39 7-2m-10 18 4 6 6-2m7-3 1 6 4-6m-16-10-1 4",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M76 102q-13-7-19-21 17 12 22 7",
				fill: "none",
				stroke: "#8b704d",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ m("path", {
				d: "M63 83q-39 1-48-32Q8 25 30 11q32-20 53 10l6 23-10 24Z",
				fill: "#6a976a"
			}),
			/* @__PURE__ */ m("path", {
				d: "M23 20q-13 18-2 39l18 15 16-3Q27 55 35 15m46 13-8 30 8-7 5-14",
				fill: "#4c7855",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M39 9 59 18l-5 14-25-6Z M59 55 71 60 64 76 49 70Z",
				fill: "#a18e65"
			}),
			/* @__PURE__ */ m("path", {
				d: "m43 14 9 4-3 7m8 34 8 4-4 7M28 32q1 23 20 30m-22-20 20 21m-5-47 10 17m13-8 11 20m-6-1 0 10m-22 16 4-8",
				fill: "none",
				stroke: "#355d44",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("path", {
				d: "M80 65q-9-3-9 5 2 11 15 15l15-9-3-6-13 7-4-5m18-3q9-7 11 0l-4 9-6-2",
				fill: "#c29a67"
			}),
			/* @__PURE__ */ m("path", {
				d: "M68 59q6-7 14-1l1 7-8 8-6-5m11 15 5 7m-2-4 6 2m13-13 2-5m-1 4 3-3m-17 25q4 6 14 5m-11 7-2 11m15-4 4 4m-33 9-6 5m46-9 7 4m-83-74q3-5 10-6l10 0 5 4-9 5-9 0Z",
				fill: "none",
				strokeWidth: ".75"
			}),
			/* @__PURE__ */ m("path", {
				d: "M55 58q10 3 17-2l2 4q-3 7-14 8l-5-4Z",
				fill: "#739b6a"
			}),
			/* @__PURE__ */ m("path", {
				d: "m59 58 2 7m4-7 0 6m3-8 2 5",
				fill: "none",
				stroke: "#365d44",
				strokeWidth: ".7"
			})
		] });
		case 28: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Q, {}),
			/* @__PURE__ */ m("path", {
				d: "M2 128q43-23 85 2t92-3v23H0Z",
				fill: "#96b6a5",
				stroke: "none"
			}),
			/* @__PURE__ */ m(Zn, {
				card: 24,
				x: 13,
				y: 17,
				w: 82,
				h: 125
			}),
			/* @__PURE__ */ m("path", {
				d: "M66 97Q75 41 124 28l16 2",
				fill: "none",
				stroke: "#695b43",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ m("path", {
				d: "M137 28q16 14 6 37l-10 13",
				fill: "none",
				stroke: "#678673",
				strokeWidth: ".7"
			}),
			/* @__PURE__ */ m(jn, {
				x: 133,
				y: 94,
				s: 1.1
			}),
			/* @__PURE__ */ m("path", {
				d: "m112 136 15-2m12 4 17-4m-137 5 19-2",
				fill: "none",
				stroke: "#5e8c7f"
			})
		] });
		default: return null;
	}
}
//#endregion
//#region src/games/pilgrims/adventure-fables.tsx
function tr({ card: e, x: t, y: n, w: r = 75, h: i = 115 }) {
	return /* @__PURE__ */ m("svg", {
		x: t,
		y: n,
		width: r,
		height: i,
		viewBox: "0 0 140 180",
		children: /* @__PURE__ */ m(fn, { card: e })
	});
}
function nr() {
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: "M92 53q-14-7-9-16l13 1q-3-11 6-14l9 10 13-8 3 11q15-3 18 7l-14 6 6 10-15-3-7 10-10-11-11 7 3-11Z",
			fill: "#83a66d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M89 41q13 1 19 10m-2-17 5 18m16-16-10 15m22-7-18 10m-12-2-9 6m17-3 7 5",
			fill: "none",
			stroke: "#506d49",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M105 48q-24-4-20-15 6-10 17 6-2-25 6-26 7 3 4 23 12-24 20-19 8 7-13 24 22-16 27-7 1 9-24 13-4 10-17 1Z",
			fill: "#9e788b"
		}),
		/* @__PURE__ */ m("path", {
			d: "M104 45q-13-13-15-8m20 5q-7-25-1-26m7 27q17-23 17-22m-13 23q18-10 23-8",
			fill: "none",
			stroke: "#cfb5bc",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ m("path", {
			d: "M106 41q-10-15-16-24m23 21q-1-14 4-24m2 26q14-7 16-22",
			fill: "none",
			stroke: "#526f4f",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ m("path", {
			d: "M87 19q-8 0-9-6l4-3 0-5 4 2 4-3 3 6 6 1q-2 8-12 8Zm25-8q-7-4-3-9l4 2 5-3 3 4 5 1q-1 10-14 5Zm21 10q-8-3-4-10l4 1 4-5 4 3 5 0q-1 10-13 11Z",
			fill: "#d0b77a"
		}),
		/* @__PURE__ */ m("path", {
			d: "m84 11 6 4m24-10 7 2m12 7 7 0M89 7l-3-7m30 2-2-5m26 15 5-6",
			fill: "none",
			stroke: "#6d6744",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M101 49q10 5 22-4",
			fill: "none",
			stroke: "#4b5e44",
			strokeWidth: "2"
		})
	] });
}
function rr({ pose: e }) {
	return e === 0 ? /* @__PURE__ */ h("g", {
		transform: "translate(20 107)",
		children: [
			/* @__PURE__ */ m("path", {
				d: "M27-18q-3-11-10-17l0 13q-9-8-14-4l5 12q-18-3-24 4-6 5-3 13l7 9q15 1 29-9 12 0 19-10Z",
				fill: "#7c9f8f"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-18-1q12-9 29-4L24 1q-9 14-23 16l-17-5Z",
				fill: "#364a3e"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-11-1 3 8 5-9 3 8 5-9 3 7 5-5m-23 14 3-6 3 5 4-7 3 5 4-7",
				fill: "#e5ddae"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-17-5q3-8 18-7 12-2 20 7l6 5q-9-4-17-3-17 0-26 5Zm3 15q16 7 29-2-1 10-15 13-11 1-14-4Z",
				fill: "#a4b6a0"
			}),
			/* @__PURE__ */ m("path", {
				d: "M15-23q4-8 10-6 10 5 7 15-2 11-12 13-9-5-5-22Z",
				fill: "#bcc36d"
			}),
			/* @__PURE__ */ m("path", {
				d: "m22-24 1 17",
				fill: "none",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ m("path", {
				d: "M14-22q5-12 16-4m-17 16q-5 11 7 13m-31-10 2 1m-2 4 1 1m-1-11 12-2m-6-8 8 6m1-8 5 5",
				fill: "none",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("path", {
				d: "M3 13q-3 8-12 7l-5 6q-2 5 3 4 9-3 12-7l6-8Z",
				fill: "#ba8c64"
			})
		]
	}) : e === 1 ? /* @__PURE__ */ h("g", {
		transform: "translate(76 27) rotate(-10)",
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-5 11q-13 1-18-10-16-6-25-15l1-9q12-3 21 6l18 13q13-6 22 5 5 15-6 21Z",
				fill: "#829f8c"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-46-18q13-1 26 12l10 3q-4 12-17 7l-17-13Z",
				fill: "#354c3d"
			}),
			/* @__PURE__ */ m("path", {
				d: "m-41-15 2 6 4-4 3 7 4-4 3 8m-17-6 1-5 4 5 3-3 4 6",
				fill: "#e3ddaf"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-15-2q-12-7-10-15l9 5q-3-12 5-13l4 11q7-7 13-6l-2 13",
				fill: "#b29d91"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-43-22q10-2 19 7l15 12-3 5q-16-14-31-16Z",
				fill: "#a9baaa"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-42-9q10 11 23 12l4 3q-13 6-28-9Z",
				fill: "#9bb09d"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "4",
				cy: "0",
				rx: "10",
				ry: "12",
				fill: "#b9c36d"
			}),
			/* @__PURE__ */ m("path", {
				d: "m4-8 2 17",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-4-9q10-7 17 3M-7 6q0 11 12 10m-46-37 2 0m-2 5 20 6m23-14 4 9m4-3 2 8",
				fill: "none",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-23 1q-3 4-2 10l-4 3q-2 5 3 4 8-5 8-14Z",
				fill: "#ba8c64"
			})
		]
	}) : /* @__PURE__ */ h("g", {
		transform: "translate(139 47) rotate(12)",
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-9 10q-4-15 8-23 10-5 17-15 8-6 17-3l3 10q-17 2-24 17 12 8 22 3l1 9q-9 9-23 9-15 12-21-7Z",
				fill: "#769c8b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M8-6q5-11 23-19l0 7Q20-17 14-4m-3 6q12 5 21 1l-2 7q-10 9-18 5Z",
				fill: "#354c3d"
			}),
			/* @__PURE__ */ m("path", {
				d: "m15-5 1-5 3 3 2-6 3 3m-9 13 2 6 3-5 3 4 2-5",
				fill: "#e2ddaf"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-6 0q-10-10-17-8l6 10q-11-4-13 1l12 9-6 8 17-3",
				fill: "#ab9390"
			}),
			/* @__PURE__ */ m("path", {
				d: "M16-18q8-12 17-10l1 6q-13 4-20 17m0 18q13-2 18-9l1 5q-9 10-17 10Z",
				fill: "#a6baa5"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "1",
				cy: "8",
				rx: "9",
				ry: "11",
				fill: "#bdc471"
			}),
			/* @__PURE__ */ m("path", {
				d: "M0 0 2 16",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-7 0q8-9 15-1m-17 18q7 6 15 2m23-42 2 0m-50 22 12 5m-17 4 12 1m1 8 6-4",
				fill: "none",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ m("path", {
				d: "M15 5q12-7 18-7l-2 4q-12-1-14 7Z",
				fill: "#ba8c64"
			})
		]
	});
}
function ir() {
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: "M111 111q41 5 40-24l-3-10 13-8-2 13q18 42-30 51l-26-6Z",
			fill: "#6c8b7a"
		}),
		/* @__PURE__ */ m("path", {
			d: "m151 80 5 3-4 6 7 4-7 5 3 7-10 0 1 8-9-2",
			fill: "#aab493"
		}),
		/* @__PURE__ */ m("path", {
			d: "M82 104Q48 86 52 53q9 14 16 12l5-16q4 20 13 22l11-13q-1 18 5 36Z",
			fill: "#8a747d"
		}),
		/* @__PURE__ */ m("path", {
			d: "m56 60 19 29 10-12 9 19m-19-7-8-18m18 6-3-17",
			fill: "none",
			stroke: "#4d5c50"
		}),
		/* @__PURE__ */ m("path", {
			d: "M90 78q29-10 40 14 9 20-6 35-18 18-49 3-17-10-12-29Z",
			fill: "#779787"
		}),
		/* @__PURE__ */ m("path", {
			d: "M79 97q-5 20 14 30l15 2 9-5q-28-1-26-35Z",
			fill: "#a1b19b",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M87 111q-3 14-19 16-7 1-7 6-1 5 4 6l7-4q-2 8 3 5l7-6q0 7 6 3l8-12m17-15q12 1 14 11l-5 8q-7 9-1 8l5 1 2-6q3 8 5 3 7 4 5-3l-5-5q5-15-7-25",
			fill: "#719581"
		}),
		/* @__PURE__ */ m("path", {
			d: "m64 133 4 2 3-4m6 4 2-6m47 1 4-3m-51-8 7 3",
			fill: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M73 112Q57 92 64 68 71 46 66 31L80 27Q96 55 81 78q-7 12 7 25Z",
			fill: "#88aa95"
		}),
		/* @__PURE__ */ m("path", {
			d: "M76 109Q63 88 74 67q8-20 0-35l6-4q15 25 1 50-7 14 8 24Z",
			fill: "#557e6d",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M107 111Q100 96 109 78q18-26 20-37l14 9q-2 22-18 37-6 7-1 20Z",
			fill: "#83a38f"
		}),
		/* @__PURE__ */ m("path", {
			d: "M113 109q-9-17 5-34 13-15 14-26l9 4q-4 19-16 34-6 10-1 21Z",
			fill: "#587e6b",
			stroke: "none"
		}),
		/* @__PURE__ */ m("path", {
			d: "M90 112q-23-31-45-14l-9 15-18-6q18-41 43-28 27 9 42 28Z",
			fill: "#7fa28b"
		}),
		/* @__PURE__ */ m("path", {
			d: "m50 89 9 0m-8 6 13 0m-6 7 10 1m-2 7 12 3m-1-59 9 3m-11 6 10 4m-12 5 10 3m-10 6 8 3m31-8 9 5m-14 2 7 5m-10 2 9 5m-7 6 9 3m-18 16 11-3m-14 7 11-1",
			fill: "none",
			stroke: "#405f4f",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ m("path", {
			d: "M82 96q6-10 13-4l0 6-8 4m10-17q7-6 13 1l-4 7-8-1m11 5q9-6 13 1l-4 7-8 0m-29 0q-5 6 1 11l8 0 1-8m7 6q6-6 13-2l0 8-9 3m-29-31q-6-7-11-4l1 8 7 3m1-21q-5-7-10-2l-1 6 7 4m8-25q-4-7-9-3l0 8 7 3m33 31q6-7 12-3l-2 7-7 4m13-24q7-3 10 3l-5 6-7-2",
			fill: "#9db3a1",
			stroke: "#526f5e",
			strokeWidth: ".7"
		}),
		/* @__PURE__ */ m(rr, { pose: 0 }),
		/* @__PURE__ */ m(rr, { pose: 1 }),
		/* @__PURE__ */ m(rr, { pose: 2 }),
		/* @__PURE__ */ m("path", {
			d: "M6 117q-9-6-8 4l-8-3 5 9 17-2m151-77 3-7 6 4 5-8 3 10-8 10-9-2m-131-68-10-5 0 7-8-2 7 11 11-3",
			fill: "#d4b969"
		}),
		/* @__PURE__ */ m("path", {
			d: "m42 142 6-5 5 5m60 0 5-6 5 4m-35-10 8 0m6-28 6-3m-9 7 6-2",
			fill: "none",
			stroke: "#80916d"
		})
	] });
}
function ar({ card: e }) {
	switch (e) {
		case 29: return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Q, {}), /* @__PURE__ */ m(Ln, {})] });
		case 30: return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Q, {}), /* @__PURE__ */ m("g", {
			transform: "translate(2 7) scale(.9)",
			children: /* @__PURE__ */ m(Rn, {})
		})] });
		case 31: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Nn, {}),
			/* @__PURE__ */ m("path", {
				d: "M51 133Q65 97 81 78t30-43l28 0-18 50-25 56Z",
				fill: "#3d5448",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M78 146q-2-49 34-109m-24 109q-2-47 34-109m-45 94 12 1m-10-12 12 2m-9-13 13 2m-9-13 13 3m-7-14 13 3m-6-15 14 4m-7-15 13 5m-6-16 12 5",
				fill: "none",
				stroke: "#a3a17c",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ m(tr, {
				card: 5,
				x: 32,
				y: 11,
				w: 51,
				h: 83
			}),
			/* @__PURE__ */ m(tr, {
				card: 15,
				x: 51,
				y: 44,
				w: 59,
				h: 90
			}),
			/* @__PURE__ */ m(tr, {
				card: 9,
				x: 105,
				y: 70,
				w: 57,
				h: 79
			}),
			/* @__PURE__ */ m("path", {
				d: "M139 123 151 120 158 126 156 140 142 141Z",
				fill: "#d6bd73"
			}),
			/* @__PURE__ */ m("path", {
				d: "m141 125 13 0m-8 1-1 13m7-13 1 12m-7-18-1-8 6-1 2 7",
				fill: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "m13 31 9 3m-5 6 7 0m143 12-11 10m-1 59 9-9",
				fill: "none",
				stroke: "#677d64"
			})
		] });
		case 32: return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Q, {}), /* @__PURE__ */ m(zn, {})] });
		case 33: return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Q, {}), /* @__PURE__ */ m("g", {
			transform: "translate(10 16) scale(.85)",
			children: /* @__PURE__ */ m(ir, {})
		})] });
		case 34: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Q, {}),
			/* @__PURE__ */ m("path", {
				d: "M72 145q1-24 13-50 11-22 4-43 14-17 39-15 21 16 18 43-1 20 11 36 12 17 5 30Z",
				fill: "#7f9b8b"
			}),
			/* @__PURE__ */ m("path", {
				d: "M93 56q14 15 6 34-9 18-12 41l17-12 17-38 4-28m11 13q-7 23 3 43l11 21-17 8-19-4-5 12 53 0q7-13-5-30-12-16-11-36Z",
				fill: "#658672",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "m90 75 12-19 22 5-9 24 8 14-15 28m25-62 5 35 13 11m-56-20-8 20m56 9-3 16m-41-63 6 3m-13 10 10-5m24 4 7 3m-32 26 9-6m-3 20 12 2m13-25 6 4",
				fill: "none",
				stroke: "#536e60"
			}),
			/* @__PURE__ */ m("g", {
				transform: "translate(8 9) scale(.94)",
				children: /* @__PURE__ */ m(nr, {})
			}),
			/* @__PURE__ */ m(Bn, {})
		] });
		case 35: return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Q, {}), /* @__PURE__ */ m(Un, {})] });
		case 36: return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Q, {}),
			/* @__PURE__ */ m("path", {
				d: "M37 80q-22-7-25 8-17 3-12 18 1 12 19 12-1 18 20 16l20-8q8 17 26 11l12-10q17 11 31 0l4-10q20 3 27-11 8-15-9-25 7-16-11-23-14-13-29-4-10-19-28-12-14 2-17 17-18-9-25 4Z",
				fill: "#e4e1c7"
			}),
			/* @__PURE__ */ m("path", {
				d: "M12 106q15 5 22-3 4 14 20 13 5 15 18 11l15-10 10 2q19 11 31-8l14 1 9-8-3 13-17 2-6 11-18 0-10-4-14 11-17-1-10-10-18 9-18-1-5-16-17-5Z",
				fill: "#c8ceaf",
				stroke: "none"
			}),
			/* @__PURE__ */ m("path", {
				d: "M20 94q9-12 23-5m-15 16q12 6 19-4m11-30q-3-17 15-20m5 4q16-9 28 3m9 6q20-2 20 13m-84 6q15 5 14 16m22-19q17-14 28-4m-19 28q8 13 21 6m-54 13q11 2 17-8m48-23q13-2 17 5m-49-34 4 9m-34 6 4 3",
				fill: "none",
				stroke: "#8e9f84",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ m("path", {
				d: "M41 74q-15-6-14-21l-5-12 4-3 7 8 2-10 4 0 1 13 7-7 4 2-5 14 9 14m76 34 16 6 5-5 4 2-2 9-19-5m-82 10-13 13-2 9 6 1 6-7 14-9",
				fill: "#c8ad7e"
			}),
			/* @__PURE__ */ m("path", {
				d: "M29 50 10 27l1-7 8 1 18 22Z",
				fill: "#99aba3"
			}),
			/* @__PURE__ */ m("path", {
				d: "m13 22 17 23m-10-8 8-7m2 4 6-6",
				fill: "none"
			}),
			/* @__PURE__ */ h("g", {
				transform: "translate(132 36) rotate(25)",
				children: [
					/* @__PURE__ */ m("path", {
						d: "M-11-5 12-5 12 1-11 1Z",
						fill: "#b59a62"
					}),
					/* @__PURE__ */ m("path", {
						d: "m-9 0-3 22m22-22 3 21m-21-25-1-14 21 0 1 14",
						fill: "none",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ m("path", {
						d: "m-5-14 11 0m-11 5 11 0",
						fill: "none"
					})
				]
			}),
			/* @__PURE__ */ m("path", {
				d: "M97 135q-12-7-14 2 0 6 12 7l8-4 3-7-4-2Z M145 62q10 8 16 0 0-7-12-7l-6 1 1 7Z",
				fill: "#b1845e"
			}),
			/* @__PURE__ */ m("path", {
				d: "m156 122 7-9 3 8 10-2-7 9 4 8-11-4m-143-62 5-9 2 8 8 2-8 5m62-52 3-10 3 7 8-2-5 7",
				fill: "#d8bf78"
			})
		] });
		default: return null;
	}
}
//#endregion
//#region src/games/pilgrims/scenes.tsx
function or({ card: e }) {
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 180 150",
		className: "pg-scene",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ m("path", {
			d: "M0 0H180V150H0Z",
			fill: e < 20 ? "#c4d4c9" : "#c6d0ae"
		}), /* @__PURE__ */ h("g", {
			stroke: q,
			strokeWidth: "1",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: [
				/* @__PURE__ */ m("path", {
					d: "M-5 128q35-23 70-9t120-1v39H-5Z",
					fill: "#b8c6a4",
					stroke: "none"
				}),
				m(e < 12 ? Yn : e < 29 ? er : ar, { card: e }),
				/* @__PURE__ */ m("path", {
					d: "m6 142 13-3m31 6 14-1m81-3 16 1M10 115l-2-8m4 7 4-5m147 28 2-9m-1 9 6-4",
					fill: "none",
					stroke: "#819277"
				})
			]
		})]
	});
}
function sr({ leader: e }) {
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 140 180",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ m("ellipse", {
			cx: "66",
			cy: "165",
			rx: "48",
			ry: "5",
			fill: "#8d8056",
			opacity: ".13"
		}), /* @__PURE__ */ m(Cn, { leader: e })]
	});
}
function cr({ card: e, visited: t = [] }) {
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 110 110",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ m("rect", {
				x: "3",
				y: "3",
				width: "104",
				height: "104",
				rx: "5",
				fill: "#d8d7b3",
				stroke: "#857b55"
			}),
			[
				1,
				2,
				3,
				4
			].map((e) => /* @__PURE__ */ m("path", {
				d: `M${5 + e * 20} 5v100M5 ${5 + e * 20}h100`,
				fill: "none",
				stroke: "#b2b48c"
			}, e)),
			F[e].cells.map((e) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("circle", {
				cx: 15 + e % 5 * 20,
				cy: 15 + Math.floor(e / 5) * 20,
				r: "6",
				fill: t.includes(e) ? "#476f53" : "#eddfa5",
				stroke: "#526a4e",
				strokeWidth: "2"
			}), t.includes(e) && /* @__PURE__ */ m("path", {
				d: `m${11 + e % 5 * 20} ${15 + Math.floor(e / 5) * 20} 3 3 5-6`,
				stroke: "#f6eed1",
				fill: "none",
				strokeWidth: "2"
			})] }, e))
		]
	});
}
function lr({ ability: e }) {
	let t = [[0, 0], ...e.paths.flat()], n = Math.min(...t.map((e) => e[0])), r = Math.max(...t.map((e) => e[0])), i = Math.min(...t.map((e) => e[1])), a = Math.max(...t.map((e) => e[1])), o = Math.min(18, 78 / Math.max(1, r - n), 54 / Math.max(1, a - i)), s = (e) => 55 + (e - (n + r) / 2) * o, c = (e) => 45 - (e - (i + a) / 2) * o;
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 110 90",
		className: "pg-movement",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M8 8H102V82H8Z",
				fill: "#e9dfb9",
				stroke: "#b6ac7d"
			}),
			Array.from({ length: 9 }, (e, t) => t - 4).map((e) => /* @__PURE__ */ h("g", {
				stroke: "#c7bd93",
				children: [s(e) > 8 && s(e) < 102 && /* @__PURE__ */ m("path", { d: `M${s(e)} 8V82` }), c(e) > 8 && c(e) < 82 && /* @__PURE__ */ m("path", { d: `M8 ${c(e)}H102` })]
			}, e)),
			/* @__PURE__ */ m("rect", {
				x: s(0) - 6,
				y: c(0) - 6,
				width: "12",
				height: "12",
				fill: "#695b3e"
			}),
			e.paths.map((e, t) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("path", {
				d: `M${s(0)} ${c(0)} ${e.map(([e, t]) => `L${s(e)} ${c(t)}`).join(" ")}`,
				fill: "none",
				stroke: t % 2 ? "#bd8654" : "#647e60",
				strokeWidth: "3"
			}), /* @__PURE__ */ m("circle", {
				cx: s(e.at(-1)[0]),
				cy: c(e.at(-1)[1]),
				r: "4",
				fill: "#393c2d"
			})] }, t))
		]
	});
}
//#endregion
//#region src/games/pilgrims/copy.ts
var $ = {
	name: "games.pilgrims.name",
	desc: "games.pilgrims.desc",
	errAction: "games.pilgrims.errAction",
	leader: "games.pilgrims.leader",
	falconer: "games.pilgrims.falconer",
	falcon: "games.pilgrims.falcon",
	round: "games.pilgrims.round",
	waiting: "games.pilgrims.waiting",
	cornerPrompt: "games.pilgrims.cornerPrompt",
	journeyPrompt: "games.pilgrims.journeyPrompt",
	travelPrompt: "games.pilgrims.travelPrompt",
	extraActivatePrompt: "games.pilgrims.extraActivatePrompt",
	activatePrompt: "games.pilgrims.activatePrompt",
	effectsPrompt: "games.pilgrims.effectsPrompt",
	movePrompt: "games.pilgrims.movePrompt",
	takePrompt: "games.pilgrims.takePrompt",
	swapPrompt: "games.pilgrims.swapPrompt",
	reservePrompt: "games.pilgrims.reservePrompt",
	returnReservePrompt: "games.pilgrims.returnReservePrompt",
	retirePrompt: "games.pilgrims.retirePrompt",
	chooseItemPrompt: "games.pilgrims.chooseItemPrompt",
	chooseCompanionPrompt: "games.pilgrims.chooseCompanionPrompt",
	adventurePrompt: "games.pilgrims.adventurePrompt",
	payPrompt: "games.pilgrims.payPrompt",
	resolvePrompt: "games.pilgrims.resolvePrompt",
	travel0: "games.pilgrims.travel0",
	travel1: "games.pilgrims.travel1",
	travel2: "games.pilgrims.travel2",
	travel3: "games.pilgrims.travel3",
	red: "games.pilgrims.red",
	blue: "games.pilgrims.blue",
	green: "games.pilgrims.green",
	gold: "games.pilgrims.gold",
	sword: "games.pilgrims.sword",
	notes: "games.pilgrims.notes",
	compass: "games.pilgrims.compass",
	star: "games.pilgrims.star",
	wanderer: "games.pilgrims.wanderer",
	nobleheart: "games.pilgrims.nobleheart",
	beast: "games.pilgrims.beast",
	scoundrel: "games.pilgrims.scoundrel",
	any: "games.pilgrims.any",
	clovers: "games.pilgrims.clovers",
	gainClover: "games.pilgrims.gainClover",
	buyItem: "games.pilgrims.buyItem",
	skip: "games.pilgrims.skip",
	endTurn: "games.pilgrims.endTurn",
	pay: "games.pilgrims.pay",
	cancel: "games.pilgrims.cancel",
	hand: "games.pilgrims.hand",
	party: "games.pilgrims.party",
	adventures: "games.pilgrims.adventures",
	quests: "games.pilgrims.quests",
	journeys: "games.pilgrims.journeys",
	reserved: "games.pilgrims.reserved",
	completed: "games.pilgrims.completed",
	retired: "games.pilgrims.retired",
	close: "games.pilgrims.close",
	inspect: "games.pilgrims.inspect",
	details: "games.pilgrims.details",
	points: "games.pilgrims.points",
	handCount: "games.pilgrims.handCount",
	cell: "games.pilgrims.cell",
	deck1: "games.pilgrims.deck1",
	deck2: "games.pilgrims.deck2",
	drawnItems: "games.pilgrims.drawnItems",
	participants: "games.pilgrims.participants",
	retire: "games.pilgrims.retire",
	itemsPayment: "games.pilgrims.itemsPayment",
	paymentClover: "games.pilgrims.paymentClover",
	invalidPayment: "games.pilgrims.invalidPayment",
	choosePayment: "games.pilgrims.choosePayment",
	discount: "games.pilgrims.discount",
	cost: "games.pilgrims.cost",
	reward: "games.pilgrims.reward",
	improvement: "games.pilgrims.improvement",
	noImprovement: "games.pilgrims.noImprovement",
	noItem: "games.pilgrims.noItem",
	used: "games.pilgrims.used",
	selected: "games.pilgrims.selected",
	heldItem: "games.pilgrims.heldItem",
	activateWith: "games.pilgrims.activateWith",
	convert: "games.pilgrims.convert",
	visit: "games.pilgrims.visit",
	questCount: "games.pilgrims.questCount",
	signed: "games.pilgrims.signed",
	join: "games.pilgrims.join",
	questType: "games.pilgrims.questType",
	questActivation: "games.pilgrims.questActivation",
	questClovers: "games.pilgrims.questClovers",
	questTravel: "games.pilgrims.questTravel",
	questLevel: "games.pilgrims.questLevel",
	questDiscount: "games.pilgrims.questDiscount",
	questScale: "games.pilgrims.questScale",
	abilityMove: "games.pilgrims.abilityMove",
	abilityClover: "games.pilgrims.abilityClover",
	abilityItem: "games.pilgrims.abilityItem",
	abilityChooseItem: "games.pilgrims.abilityChooseItem",
	abilityChooseCompanion: "games.pilgrims.abilityChooseCompanion",
	abilityReserve: "games.pilgrims.abilityReserve",
	abilityExtra: "games.pilgrims.abilityExtra",
	abilitySwap: "games.pilgrims.abilitySwap",
	abilityTake: "games.pilgrims.abilityTake",
	abilityAdjacent: "games.pilgrims.abilityAdjacent",
	abilityPaid: "games.pilgrims.abilityPaid",
	abilityEncounter: "games.pilgrims.abilityEncounter",
	abilityCorner: "games.pilgrims.abilityCorner",
	abilityPass: "games.pilgrims.abilityPass",
	improveCapacity: "games.pilgrims.improveCapacity",
	improveReserve: "games.pilgrims.improveReserve",
	improveDiscount: "games.pilgrims.improveDiscount",
	improvePaid: "games.pilgrims.improvePaid",
	improveTravel: "games.pilgrims.improveTravel",
	improveExtra: "games.pilgrims.improveExtra",
	improveActivateColor: "games.pilgrims.improveActivateColor",
	improveActivateSymbol: "games.pilgrims.improveActivateSymbol",
	improveCompleted: "games.pilgrims.improveCompleted",
	improveEncounter: "games.pilgrims.improveEncounter",
	optLeader: "games.pilgrims.optLeader",
	sideA: "games.pilgrims.sideA",
	sideB: "games.pilgrims.sideB",
	optJourneys: "games.pilgrims.optJourneys",
	optSolo: "games.pilgrims.optSolo",
	easy: "games.pilgrims.easy",
	medium: "games.pilgrims.medium",
	hard: "games.pilgrims.hard",
	hardcore: "games.pilgrims.hardcore",
	hint: "games.pilgrims.hint",
	resultTitle: "games.pilgrims.resultTitle",
	victory: "games.pilgrims.victory",
	showResult: "games.pilgrims.showResult",
	review: "games.pilgrims.review",
	total: "games.pilgrims.total",
	scoreAdventures: "games.pilgrims.scoreAdventures",
	scoreClovers: "games.pilgrims.scoreClovers",
	scoreQuests: "games.pilgrims.scoreQuests",
	scoreJourneys: "games.pilgrims.scoreJourneys",
	scoreItems: "games.pilgrims.scoreItems",
	tieItems: "games.pilgrims.tieItems",
	confirmAgain: "games.pilgrims.confirmAgain",
	confirmLobby: "games.pilgrims.confirmLobby",
	logItem: "games.pilgrims.logItem",
	logCompanion: "games.pilgrims.logCompanion",
	logMove: "games.pilgrims.logMove",
	logActivate: "games.pilgrims.logActivate",
	logClover: "games.pilgrims.logClover",
	logRetire: "games.pilgrims.logRetire",
	logReserve: "games.pilgrims.logReserve",
	logAdventure: "games.pilgrims.logAdventure",
	logQuest: "games.pilgrims.logQuest",
	logJourney: "games.pilgrims.logJourney",
	logRound: "games.pilgrims.logRound",
	logSwap: "games.pilgrims.logSwap",
	logEnd: "games.pilgrims.logEnd",
	c0: "games.pilgrims.c0",
	c1: "games.pilgrims.c1",
	c2: "games.pilgrims.c2",
	c3: "games.pilgrims.c3",
	c4: "games.pilgrims.c4",
	c5: "games.pilgrims.c5",
	c6: "games.pilgrims.c6",
	c7: "games.pilgrims.c7",
	c8: "games.pilgrims.c8",
	c9: "games.pilgrims.c9",
	c10: "games.pilgrims.c10",
	c11: "games.pilgrims.c11",
	c12: "games.pilgrims.c12",
	c13: "games.pilgrims.c13",
	c14: "games.pilgrims.c14",
	c15: "games.pilgrims.c15",
	c16: "games.pilgrims.c16",
	c17: "games.pilgrims.c17",
	c18: "games.pilgrims.c18",
	c19: "games.pilgrims.c19",
	c20: "games.pilgrims.c20",
	c21: "games.pilgrims.c21",
	c22: "games.pilgrims.c22",
	c23: "games.pilgrims.c23",
	c24: "games.pilgrims.c24",
	c25: "games.pilgrims.c25",
	c26: "games.pilgrims.c26",
	c27: "games.pilgrims.c27",
	c28: "games.pilgrims.c28",
	c29: "games.pilgrims.c29",
	c30: "games.pilgrims.c30",
	c31: "games.pilgrims.c31",
	a0: "games.pilgrims.a0",
	a1: "games.pilgrims.a1",
	a2: "games.pilgrims.a2",
	a3: "games.pilgrims.a3",
	a4: "games.pilgrims.a4",
	a5: "games.pilgrims.a5",
	a6: "games.pilgrims.a6",
	a7: "games.pilgrims.a7",
	a8: "games.pilgrims.a8",
	a9: "games.pilgrims.a9",
	a10: "games.pilgrims.a10",
	a11: "games.pilgrims.a11",
	a12: "games.pilgrims.a12",
	a13: "games.pilgrims.a13",
	a14: "games.pilgrims.a14",
	a15: "games.pilgrims.a15",
	a16: "games.pilgrims.a16",
	a17: "games.pilgrims.a17",
	a18: "games.pilgrims.a18",
	a19: "games.pilgrims.a19",
	a20: "games.pilgrims.a20",
	a21: "games.pilgrims.a21",
	a22: "games.pilgrims.a22",
	a23: "games.pilgrims.a23",
	a24: "games.pilgrims.a24",
	a25: "games.pilgrims.a25",
	a26: "games.pilgrims.a26",
	a27: "games.pilgrims.a27",
	a28: "games.pilgrims.a28",
	a29: "games.pilgrims.a29",
	a30: "games.pilgrims.a30",
	a31: "games.pilgrims.a31",
	a32: "games.pilgrims.a32",
	a33: "games.pilgrims.a33",
	a34: "games.pilgrims.a34",
	a35: "games.pilgrims.a35",
	a36: "games.pilgrims.a36",
	j0: "games.pilgrims.j0",
	j1: "games.pilgrims.j1",
	j2: "games.pilgrims.j2",
	j3: "games.pilgrims.j3",
	j4: "games.pilgrims.j4",
	j5: "games.pilgrims.j5",
	j6: "games.pilgrims.j6",
	j7: "games.pilgrims.j7",
	j8: "games.pilgrims.j8",
	j9: "games.pilgrims.j9",
	j10: "games.pilgrims.j10",
	j11: "games.pilgrims.j11",
	j12: "games.pilgrims.j12",
	j13: "games.pilgrims.j13",
	j14: "games.pilgrims.j14",
	j15: "games.pilgrims.j15",
	j16: "games.pilgrims.j16",
	i0: "games.pilgrims.i0",
	i1: "games.pilgrims.i1",
	i2: "games.pilgrims.i2",
	i3: "games.pilgrims.i3",
	i4: "games.pilgrims.i4",
	i5: "games.pilgrims.i5",
	i6: "games.pilgrims.i6",
	i7: "games.pilgrims.i7",
	i8: "games.pilgrims.i8",
	i9: "games.pilgrims.i9",
	i10: "games.pilgrims.i10",
	i11: "games.pilgrims.i11",
	i12: "games.pilgrims.i12",
	rules: "games.pilgrims.rules"
};
function ur() {
	let e = c(), t = (t) => e($[t]), n = (t) => e(t < 0 ? $.leader : fe[t]), r = (t) => e(pe[t]), i = (t) => e(I[O[t].art]), a = (t) => e([
		$.travel0,
		$.travel1,
		$.travel2,
		$.travel3
	][t]), o = (n) => {
		switch (n.kind) {
			case "move": return [
				e($.abilityMove),
				n.encounter ? e($.abilityEncounter) : "",
				n.corner ? e($.abilityCorner) : "",
				n.passItem ? e($.abilityPass) : ""
			].filter(Boolean).join(" · ");
			case "take": return e(n.adjacent ? $.abilityAdjacent : $.abilityTake, { color: t(n.color) });
			case "paid": return e($.abilityPaid, { effect: o(n.effect) });
			default: return e({
				clover: $.abilityClover,
				item: $.abilityItem,
				chooseItem: $.abilityChooseItem,
				chooseCompanion: $.abilityChooseCompanion,
				reserve: $.abilityReserve,
				extra: $.abilityExtra,
				swap: $.abilitySwap
			}[n.kind]);
		}
	};
	return {
		t: e,
		word: t,
		character: n,
		adventure: r,
		item: i,
		travel: a,
		ability: o,
		improvement: (n) => {
			if (!n) return e($.noImprovement);
			switch (n.kind) {
				case "discount": return n.paid ? e($.improvePaid) : e($.improveDiscount, { color: t(n.color) });
				case "capacity": return e($.improveCapacity);
				case "reserveCapacity": return e($.improveReserve);
				case "travel": return e($.improveTravel, {
					travel: a(n.mode),
					effect: [
						...n.effects.map(o),
						n.extra ? e($.improveExtra, { n: n.extra }) : "",
						n.passItem ? e($.abilityPass) : ""
					].filter(Boolean).join(" · ")
				});
				case "activateColor": return e($.improveActivateColor, {
					color: t(n.color),
					effect: o(n.effect)
				});
				case "activateSymbol": return e($.improveActivateSymbol, {
					symbol: t(n.symbol),
					effect: o(n.effect)
				});
				case "completed": return e($.improveCompleted, { effect: o(n.effect) });
				case "encounter": return e($.improveEncounter, { effect: o(n.effect) });
			}
		},
		quest: (n) => {
			let r = le[n];
			return r.kind === "type" ? e($.questType, { type: t(r.value) }) : r.kind === "activation" ? e($.questActivation, { symbol: t(r.value) }) : e({
				clovers: $.questClovers,
				travel: $.questTravel,
				level: $.questLevel,
				discount: $.questDiscount
			}[r.kind]);
		},
		costs: (e) => e.flatMap((e, n) => e ? [`${t(y[n])} × ${e}`] : []).join(" · ")
	};
}
//#endregion
//#region src/games/pilgrims/cards.tsx
function dr({ card: e, selected: t = !1, legal: n = !1, onClick: r, disabled: i = !1 }) {
	let a = ur(), o = O[e];
	return /* @__PURE__ */ h("button", {
		className: "pg-item pg-paper",
		style: { background: un[o.color] },
		"aria-label": `${a.item(e)} · ${a.word(o.color)} · ${a.word(o.activate)}`,
		"aria-pressed": t,
		onClick: r,
		disabled: i,
		children: [
			/* @__PURE__ */ m(pn, { art: o.art }),
			/* @__PURE__ */ h("span", {
				className: "pg-item-symbols",
				children: [/* @__PURE__ */ m(Y, { kind: o.color }), /* @__PURE__ */ m(Y, { kind: o.activate })]
			}),
			n && /* @__PURE__ */ m(X, {})
		]
	});
}
function fr({ ability: e }) {
	let t = ur();
	return /* @__PURE__ */ h("div", {
		className: "pg-ability",
		children: [e.kind === "move" ? /* @__PURE__ */ m(lr, { ability: e }) : e.kind === "paid" ? /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m(Y, { kind: "clover" }),
			/* @__PURE__ */ m("span", { children: "→" }),
			/* @__PURE__ */ m(fr, { ability: e.effect })
		] }) : e.kind === "take" ? /* @__PURE__ */ m(Y, { kind: e.color }) : /* @__PURE__ */ m(Y, { kind: e.kind === "clover" ? "clover" : e.kind === "item" || e.kind === "chooseItem" ? "item" : e.kind === "chooseCompanion" ? "hat" : e.kind === "reserve" ? "reserve" : e.kind === "extra" ? "extra" : "item" }), /* @__PURE__ */ m("span", { children: t.ability(e) })]
	});
}
function pr({ character: e, config: t, leaderIndex: n = 0, legal: r = !1, selected: i = !1, onClick: a, onInspect: o }) {
	let s = ur(), c = e.card < 0 ? ce(n, t.leaderSide) : D[e.card];
	return /* @__PURE__ */ h("div", {
		className: "pg-character-wrap",
		children: [
			/* @__PURE__ */ h("button", {
				className: "pg-character pg-paper",
				onClick: a ?? o,
				"aria-pressed": i,
				"aria-label": s.character(e.card),
				children: [
					/* @__PURE__ */ m("span", {
						className: "pg-character-title",
						children: s.character(e.card)
					}),
					/* @__PURE__ */ m("span", {
						className: "pg-types",
						children: e.card < 0 ? /* @__PURE__ */ m(Y, { kind: "hat" }) : D[e.card].types.map((e) => /* @__PURE__ */ m(Y, { kind: e }, e))
					}),
					e.card < 0 ? /* @__PURE__ */ m(sr, { leader: n }) : /* @__PURE__ */ m(fn, { card: e.card }),
					/* @__PURE__ */ m("span", {
						className: "pg-activation",
						children: c.activate.map((e) => /* @__PURE__ */ m(Y, { kind: e }, e))
					}),
					r && /* @__PURE__ */ m(X, {})
				]
			}),
			e.item !== null && /* @__PURE__ */ m("div", {
				className: "pg-held",
				children: /* @__PURE__ */ m(dr, {
					card: e.item,
					onClick: o
				})
			}),
			o && a && /* @__PURE__ */ m("button", {
				className: "pg-detail-button",
				onClick: o,
				"aria-label": s.t($.inspect),
				children: "⌕"
			})
		]
	});
}
function mr({ card: e, legal: t = !1, onClick: n, compact: r = !1 }) {
	let i = ur(), a = P[e];
	return /* @__PURE__ */ h("button", {
		className: `pg-adventure pg-paper${r ? " pg-compact" : ""}`,
		onClick: n,
		"aria-label": i.adventure(e),
		children: [
			/* @__PURE__ */ m(or, { card: e }),
			/* @__PURE__ */ h("div", {
				className: "pg-adventure-copy",
				children: [
					/* @__PURE__ */ m("strong", { children: i.adventure(e) }),
					/* @__PURE__ */ m("span", {
						className: "pg-costs",
						children: a.cost.map((e, t) => e > 0 && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(Y, { kind: y[t] }), /* @__PURE__ */ m("b", { children: e })] }, t))
					}),
					/* @__PURE__ */ h("span", {
						className: "pg-party-cost",
						children: [a.party.map((e, t) => /* @__PURE__ */ m(Y, { kind: e === "any" ? "hat" : e }, t)), a.retire > 0 && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Y, { kind: "retire" }), /* @__PURE__ */ m("b", { children: a.retire })] })]
					}),
					/* @__PURE__ */ h("span", {
						className: "pg-award",
						children: [
							/* @__PURE__ */ m("b", { children: i.t($.points, { n: a.points }) }),
							a.clovers > 0 && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(Y, { kind: "clover" }), a.clovers] }),
							/* @__PURE__ */ m("small", { children: a.level === 1 ? "Ⅰ" : "Ⅱ" })
						]
					})
				]
			}),
			t && /* @__PURE__ */ m(X, {})
		]
	});
}
function hr({ card: e, visited: t = [], onClick: n, legal: r = !1 }) {
	let i = ur();
	return /* @__PURE__ */ h("button", {
		className: "pg-journey pg-paper",
		onClick: n,
		"aria-label": i.t($.journeys),
		children: [
			/* @__PURE__ */ m(cr, {
				card: e,
				visited: t
			}),
			/* @__PURE__ */ m("span", { children: i.t($.visit, { n: t.length }) }),
			r && /* @__PURE__ */ m(X, {})
		]
	});
}
function gr({ children: e }) {
	return /* @__PURE__ */ m("div", {
		className: "pg-detail-paper",
		children: e
	});
}
//#endregion
//#region src/games/pilgrims/payment-view.tsx
var _r = (e, t) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t];
function vr({ pub: e, player: t, hand: r, target: i, send: a }) {
	let o = ur(), [s, c] = n([]), [l, d] = n([]), [f, g] = n([]), [ee, te] = n(0), _ = he(t, i), ne = {
		type: "pay",
		items: s,
		companions: l,
		retire: f,
		discount: ee
	}, v = ve(t, r, i, ne), y = [...r, ...t.party.flatMap((e) => e.item === null ? [] : [e.item])], b = v !== null && v <= t.clovers, re = (e) => {
		d(_r(l, e)), g(f.filter((t) => t !== e));
	};
	return /* @__PURE__ */ m(u, {
		open: !0,
		onClose: () => a({ type: "cancel" }),
		title: o.t($.choosePayment),
		label: o.t($.choosePayment),
		children: /* @__PURE__ */ h("div", {
			className: "pg-payment",
			children: [
				/* @__PURE__ */ h("div", {
					className: "pg-payment-target",
					children: [
						i.kind === "adventure" ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(mr, { card: i.id }), /* @__PURE__ */ m("p", { children: o.improvement(P[i.id].improvement) })] }) : /* @__PURE__ */ m("strong", { children: o.quest(e.quests[i.id].card) }),
						/* @__PURE__ */ h("p", { children: [
							o.t($.cost),
							"：",
							o.costs(_.cost)
						] }),
						/* @__PURE__ */ h("p", { children: [
							o.t($.clovers),
							"：",
							t.clovers
						] })
					]
				}),
				/* @__PURE__ */ h("fieldset", { children: [/* @__PURE__ */ h("legend", { children: [
					o.t($.itemsPayment),
					" · ",
					s.length,
					"/",
					_.cost.reduce((e, t) => e + t, 0) - ee
				] }), /* @__PURE__ */ m("div", {
					className: "pg-payment-items",
					children: y.map((e) => /* @__PURE__ */ m(dr, {
						card: e,
						selected: s.includes(e),
						legal: !s.includes(e),
						onClick: () => c(_r(s, e))
					}, e))
				})] }),
				_.party.length > 0 && /* @__PURE__ */ h("fieldset", { children: [
					/* @__PURE__ */ h("legend", { children: [
						o.t($.participants),
						" · ",
						l.length,
						"/",
						_.party.length
					] }),
					/* @__PURE__ */ m("div", {
						className: "pg-payment-types",
						children: _.party.map((e, t) => /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(Y, { kind: e === "any" ? "hat" : e }), o.word(e)] }, t))
					}),
					/* @__PURE__ */ m("div", {
						className: "pg-payment-party",
						children: t.party.filter((e) => e.card >= 0).map((t) => /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m(pr, {
							character: t,
							config: e.config,
							selected: l.includes(t.id),
							legal: !l.includes(t.id),
							onClick: () => re(t.id)
						}), _.retire > 0 && /* @__PURE__ */ h("label", { children: [/* @__PURE__ */ m("input", {
							type: "checkbox",
							checked: f.includes(t.id),
							disabled: !l.includes(t.id),
							onChange: () => g(_r(f, t.id))
						}), o.t($.retire)] })] }, t.id))
					})
				] }),
				_.retire > 0 && /* @__PURE__ */ h("p", { children: [
					o.t($.retire),
					"：",
					f.length,
					"/",
					_.retire
				] }),
				_.paid > 0 && /* @__PURE__ */ h("label", {
					className: "pg-discount",
					children: [o.t($.discount), /* @__PURE__ */ m("select", {
						value: ee,
						onChange: (e) => te(Number(e.target.value)),
						children: Array.from({ length: Math.min(_.paid, _.cost.reduce((e, t) => e + t, 0)) + 1 }, (e, t) => /* @__PURE__ */ m("option", {
							value: t,
							children: t
						}, t))
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: "pg-payment-confirm",
					children: [/* @__PURE__ */ m("p", {
						role: "status",
						children: v === null ? o.t($.invalidPayment) : o.t($.paymentClover, { n: v })
					}), /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("button", {
						onClick: () => a({ type: "cancel" }),
						children: o.t($.cancel)
					}), /* @__PURE__ */ m("button", {
						className: "pg-primary",
						disabled: !b,
						onClick: () => a(ne),
						children: o.t($.pay)
					})] })]
				})
			]
		})
	});
}
//#endregion
//#region src/games/pilgrims/view-player.tsx
var yr = {
	corner: "cornerPrompt",
	journey: "journeyPrompt",
	travel: "travelPrompt",
	activate: "activatePrompt",
	effects: "effectsPrompt",
	move: "movePrompt",
	take: "takePrompt",
	swap: "swapPrompt",
	reserve: "reservePrompt",
	returnReserve: "returnReservePrompt",
	retire: "retirePrompt",
	chooseItem: "chooseItemPrompt",
	chooseCompanion: "chooseCompanionPrompt",
	adventure: "adventurePrompt",
	pay: "payPrompt",
	resolve: "resolvePrompt",
	done: "resultTitle"
}, br = {
	item: $.logItem,
	companion: $.logCompanion,
	move: $.logMove,
	activate: $.logActivate,
	clover: $.logClover,
	retire: $.logRetire,
	reserve: $.logReserve,
	adventure: $.logAdventure,
	quest: $.logQuest,
	journey: $.logJourney,
	round: $.logRound,
	swap: $.logSwap,
	end: $.logEnd
}, xr = [
	"#5f896c",
	"#b77860",
	"#6f929c",
	"#c4a75e"
];
function Sr(e) {
	return /* @__PURE__ */ m(Cr, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function Cr({ pub: e, priv: t, members: c, myRid: g, send: ee, review: te = !1 }) {
	let _ = ur(), [ne, v] = n(null), [y, b] = n(null), [x, S] = n(null), [C, w] = n(null), [ie, ae] = n(null), [oe, T] = n([]), [E, k] = n(!1), A = !te && e.actor === g && e.phase !== "resolve", j = e.players.find((e) => e.rid === g) ?? e.players[0], M = e.players.find((e) => e.rid === ne) ?? j, N = A ? [...e.choices, ...t?.choices ?? []] : [], le = t?.hand ?? [], ue = [
		"corner",
		"move",
		"take",
		"swap"
	].includes(e.phase), de = le.includes(C ?? -1) ? C : null, fe = s((e) => e.locale), pe = (e) => {
		let t = c.find((t) => t.rid === e);
		return e === "$falconer" ? _.t($.falconer) : t ? o(t, fe) : e;
	}, I = (e) => {
		ee({
			type: "choose",
			id: e.id
		}), T([]), ae(null), w(null);
	}, me = te ? _.t($.resultTitle) : e.phase === "resolve" ? _.t($.resolvePrompt) : A ? _.word(e.phase === "activate" && e.extraActivation ? "extraActivatePrompt" : yr[e.phase]) : _.t($.waiting, { name: pe(e.actor) }), he = N.flatMap((e) => e.cells && [
		"move",
		"corner",
		"take"
	].includes(e.kind) ? [e.cells.at(-1)] : e.kind === "swap" ? ie === null ? e.cells : e.cells.includes(ie) ? e.cells.filter((e) => e !== ie) : [] : []), ge = (t) => {
		let n = N.filter((e) => e.cells && ([
			"move",
			"corner",
			"take"
		].includes(e.kind) ? e.cells.at(-1) === t : e.kind === "swap" && e.cells.includes(t)));
		if (n.length && ue) {
			if (e.phase === "swap") {
				if (ie === null) {
					ae(t);
					return;
				}
				let e = n.find((e) => e.cells.includes(ie));
				e ? I(e) : ae(t);
				return;
			}
			n.length === 1 ? I(n[0]) : T(n);
			return;
		}
		let r = e.board[t];
		r && b({
			kind: r.kind,
			card: r.card
		});
	}, _e = (e) => b({
		kind: "companion",
		card: e,
		owner: M.rid
	}), ve = N.filter((e) => e.kind === "activate" && (de === null || e.item === de)), ye = N.find((e) => e.kind === "clover" || e.kind === "skip"), be = A && !["corner", "journey"].includes(e.phase) && j.clovers >= 2 && e.deckCounts.items + e.discard.length > 0, Se = ["retire", "chooseCompanion"].includes(e.phase), L = [
		"journey",
		"chooseItem",
		"chooseCompanion",
		"retire",
		"returnReserve",
		"reserve"
	].includes(e.phase), Ce = A && L;
	return /* @__PURE__ */ h(r, {
		adaptive: !0,
		scroll: !1,
		className: "pg-screen",
		actionsHeight: "pg-actions-slot",
		banner: /* @__PURE__ */ h("div", {
			className: "pg-banner",
			children: [
				/* @__PURE__ */ m(i, {
					text: me,
					chip: _.t($.round, { n: e.round }),
					accent: xe.accent,
					tone: A ? "accent" : "info"
				}),
				/* @__PURE__ */ m(a, {
					members: c,
					myRid: g,
					scroll: !0,
					adaptive: !0,
					variant: "mini",
					onPick: v,
					picked: (e) => e === M.rid,
					status: (t) => /* @__PURE__ */ h("span", { children: [
						e.actor === t ? "▸ " : "",
						/* @__PURE__ */ m(Y, { kind: "clover" }),
						e.players.find((e) => e.rid === t)?.clovers ?? 0
					] })
				}),
				e.players.some((e) => e.solo) && /* @__PURE__ */ h("button", {
					className: "pg-solo-seat",
					"aria-pressed": M.solo,
					onClick: () => v("$falconer"),
					children: [
						_.t($.falconer),
						" · ",
						e.scores.$falconer.total
					]
				})
			]
		}),
		actions: /* @__PURE__ */ h("div", {
			className: "pg-actions",
			children: [/* @__PURE__ */ m("div", {
				className: "pg-hand",
				"aria-label": _.t($.hand),
				children: le.map((t) => /* @__PURE__ */ m(dr, {
					card: t,
					selected: de === t,
					legal: A && e.phase === "activate" && N.some((e) => e.item === t),
					onClick: () => {
						A && e.phase === "activate" ? (w(de === t ? null : t), v(g)) : b({
							kind: "item",
							card: t
						});
					}
				}, t))
			}), /* @__PURE__ */ h("div", {
				className: "pg-action-buttons",
				children: [
					be && /* @__PURE__ */ h("button", {
						className: "pg-buy",
						onClick: () => ee({ type: "buyItem" }),
						children: [
							/* @__PURE__ */ m(Y, { kind: "clover" }),
							/* @__PURE__ */ m("span", { children: "2 →" }),
							/* @__PURE__ */ m(Y, { kind: "item" }),
							/* @__PURE__ */ m("span", {
								className: "pg-sr",
								children: _.t($.buyItem)
							})
						]
					}),
					ye && /* @__PURE__ */ m("button", {
						className: "pg-primary",
						onClick: () => I(ye),
						children: ye.kind === "clover" ? _.t($.gainClover) : e.phase === "adventure" ? _.t($.endTurn) : _.t($.skip)
					}),
					e.phase === "pay" && A && /* @__PURE__ */ m("button", {
						onClick: () => ee({ type: "cancel" }),
						children: _.t($.cancel)
					})
				]
			})]
		}),
		children: [
			/* @__PURE__ */ h("div", {
				className: "pg-table",
				children: [
					/* @__PURE__ */ m(d, {
						kind: "sheen",
						base: "#dfd8b7",
						className: "absolute inset-0"
					}),
					/* @__PURE__ */ h("nav", {
						className: "pg-tools",
						children: [
							/* @__PURE__ */ m("button", {
								onClick: () => k(!0),
								children: _.t($.party)
							}),
							/* @__PURE__ */ m("button", {
								onClick: () => S("market"),
								children: _.t($.adventures)
							}),
							/* @__PURE__ */ m("button", {
								onClick: () => S("quests"),
								children: _.t($.quests)
							}),
							/* @__PURE__ */ h("button", {
								onClick: () => {
									v(g), S("reserved");
								},
								children: [
									_.t($.reserved),
									" · ",
									j.reserved.length
								]
							})
						]
					}),
					/* @__PURE__ */ h("div", {
						className: "pg-field",
						children: [
							/* @__PURE__ */ m("aside", {
								className: "pg-market",
								"aria-label": _.t($.adventures),
								children: e.market.map((e, t) => e === null ? /* @__PURE__ */ m("div", { className: "pg-empty-adventure" }, `empty:${t}`) : /* @__PURE__ */ m(mr, {
									card: e,
									legal: N.some((t) => t.kind === "adventure" && t.card === e),
									onClick: () => b({
										kind: "adventure",
										card: e
									})
								}, e))
							}),
							/* @__PURE__ */ h("div", {
								className: "pg-map-area",
								children: [
									/* @__PURE__ */ h("div", {
										className: "pg-map",
										role: "group",
										"aria-label": _.t($.movePrompt),
										children: [
											/* @__PURE__ */ m("svg", {
												className: "pg-landscape",
												viewBox: "0 0 500 500",
												"aria-hidden": !0,
												children: /* @__PURE__ */ m(mn, {})
											}),
											/* @__PURE__ */ m("div", {
												className: "pg-grid",
												children: e.board.map((e, t) => /* @__PURE__ */ h("button", {
													className: `pg-cell${ie === t ? " pg-picked" : ""}`,
													"aria-label": `${_.t($.cell, { n: t + 1 })}${e ? " · " + (e.kind === "item" ? _.item(e.card) : _.character(e.card)) : ""}`,
													onClick: () => ge(t),
													children: [
														/* @__PURE__ */ m("small", { children: t + 1 }),
														re.includes(t) && /* @__PURE__ */ m("svg", {
															className: "pg-camp",
															viewBox: "-25 -36 50 55",
															"aria-hidden": !0,
															children: /* @__PURE__ */ m(hn, { marker: !0 })
														}),
														e && /* @__PURE__ */ m("span", {
															className: `pg-map-card pg-land ${e.kind === "companion" ? "pg-map-character" : ""}`,
															style: { background: e.kind === "item" ? un[O[e.card].color] : "#f4efd9" },
															children: e.kind === "companion" ? /* @__PURE__ */ m(fn, { card: e.card }) : /* @__PURE__ */ m(pn, { art: O[e.card].art })
														}, `${e.kind}:${e.card}`),
														e?.kind === "item" && /* @__PURE__ */ h("span", {
															className: "pg-map-symbol",
															children: [/* @__PURE__ */ m(Y, { kind: O[e.card].color }), /* @__PURE__ */ m(Y, { kind: O[e.card].activate })]
														}),
														he.includes(t) && /* @__PURE__ */ m(X, {})
													]
												}, t))
											}),
											/* @__PURE__ */ h("div", {
												className: "pg-pawns",
												"aria-hidden": !0,
												children: [e.players.map((e) => e.position >= 0 && /* @__PURE__ */ m("div", {
													className: "pg-pawn",
													style: {
														left: `${e.position % 5 * 20}%`,
														top: `${Math.floor(e.position / 5) * 20}%`,
														color: e.solo ? "#635d4b" : xr[e.leader]
													},
													children: /* @__PURE__ */ h("svg", {
														viewBox: "0 0 50 65",
														children: [
															/* @__PURE__ */ m("path", {
																d: "M12 16Q8 3 25 2q17 0 13 14l-4 10 11 27q2 8-20 8Q2 62 5 54l11-28Z",
																fill: "currentColor",
																stroke: "#3a3d2e",
																strokeWidth: "2"
															}),
															/* @__PURE__ */ m("path", {
																d: "m17 15 16 0m-20 37q12 6 25 0",
																stroke: "#efe3b8",
																fill: "none",
																strokeWidth: "2"
															}),
															/* @__PURE__ */ m("text", {
																x: "25",
																y: "44",
																textAnchor: "middle",
																fontSize: "21",
																fill: "#fff2c8",
																children: e.solo ? "F" : e.leader + 1
															})
														]
													})
												}, e.rid)), e.falcon !== null && /* @__PURE__ */ m("div", {
													className: "pg-falcon",
													style: {
														left: `${e.falcon % 5 * 20}%`,
														top: `${Math.floor(e.falcon / 5) * 20}%`
													},
													children: /* @__PURE__ */ h("svg", {
														viewBox: "0 0 50 50",
														children: [/* @__PURE__ */ m("path", {
															d: "M26 12q-8-7-11 1l4 13Q7 17 3 19l8 13 15 4 15-15-10 1 5-8-7-1Z",
															fill: "#887b59",
															stroke: "#353e30",
															strokeWidth: "2"
														}), /* @__PURE__ */ m("circle", {
															cx: "26",
															cy: "16",
															r: "1.5",
															fill: "#f4ebc6"
														})]
													})
												})]
											})
										]
									}),
									e.phase === "travel" && A && /* @__PURE__ */ m("div", {
										className: "pg-travel-tray",
										children: N.filter((e) => e.kind === "travel").map((e) => /* @__PURE__ */ h("button", {
											onClick: () => I(e),
											children: [
												/* @__PURE__ */ m(Y, { kind: [
													"cart",
													"horse",
													"boat",
													"walk"
												][e.card] }),
												/* @__PURE__ */ m("span", { children: _.travel(e.card) }),
												/* @__PURE__ */ m(lr, { ability: se[e.card] }),
												/* @__PURE__ */ m(X, {})
											]
										}, e.id))
									}),
									A && e.phase === "effects" && /* @__PURE__ */ m("div", {
										className: "pg-effect-tray",
										children: N.filter((e) => e.kind === "effect").map((t) => {
											let n = e.effects.find((e) => e.id === t.effect);
											return /* @__PURE__ */ h("button", {
												onClick: () => I(t),
												children: [n ? /* @__PURE__ */ m(fr, { ability: n.ability }) : e.pendingAbility ? /* @__PURE__ */ m(fr, { ability: e.pendingAbility }) : null, /* @__PURE__ */ m(X, {})]
											}, t.id);
										})
									})
								]
							}),
							/* @__PURE__ */ h("aside", {
								className: "pg-personal",
								children: [
									/* @__PURE__ */ h("div", {
										className: "pg-personal-heading",
										children: [
											/* @__PURE__ */ m("strong", { children: pe(M.rid) }),
											/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(Y, { kind: "clover" }), /* @__PURE__ */ m(f, { value: M.clovers })] }),
											/* @__PURE__ */ m("span", { children: _.t($.handCount, { n: M.handCount }) })
										]
									}),
									/* @__PURE__ */ m("div", {
										className: "pg-party",
										"aria-label": _.t($.party),
										children: M.party.map((t) => {
											let n = M.rid === g ? ve.filter((e) => e.character === t.id) : [];
											return /* @__PURE__ */ m(pr, {
												character: t,
												config: e.config,
												leaderIndex: M.leader,
												legal: n.length > 0,
												onInspect: () => _e(t.card),
												onClick: n.length ? () => {
													n.length === 1 ? I(n[0]) : T(n);
												} : void 0
											}, t.id);
										})
									}),
									M.soloItems && /* @__PURE__ */ m("div", {
										className: "pg-solo-items",
										children: M.soloItems.map((e) => /* @__PURE__ */ m(dr, {
											card: e,
											onClick: () => b({
												kind: "item",
												card: e
											})
										}, e))
									}),
									/* @__PURE__ */ h("div", {
										className: "pg-collections",
										children: [
											/* @__PURE__ */ h("button", {
												onClick: () => S("completed"),
												children: [
													_.t($.completed),
													" · ",
													M.completed.length
												]
											}),
											/* @__PURE__ */ h("button", {
												onClick: () => S("retired"),
												children: [
													_.t($.retired),
													" · ",
													M.retired.length
												]
											}),
											/* @__PURE__ */ h("button", {
												onClick: () => S("reserved"),
												children: [
													_.t($.reserved),
													" · ",
													M.reserved.length
												]
											})
										]
									}),
									M.journey && /* @__PURE__ */ m(hr, {
										card: M.journey.card,
										visited: M.journey.visited,
										onClick: () => b({
											kind: "journey",
											card: M.journey.card,
											owner: M.rid
										})
									}),
									/* @__PURE__ */ m("div", {
										className: "pg-quests",
										children: e.quests.map((e, t) => /* @__PURE__ */ h("button", {
											className: "pg-quest pg-paper",
											onClick: () => b({
												kind: "quest",
												card: t
											}),
											children: [
												/* @__PURE__ */ h("span", {
													className: "pg-costs",
													children: [/* @__PURE__ */ m(Y, { kind: [
														"red",
														"blue",
														"green"
													][t] }), /* @__PURE__ */ m("b", { children: "3" })]
												}),
												/* @__PURE__ */ m("strong", { children: _.quest(e.card) }),
												/* @__PURE__ */ m("span", { children: e.signed.map(pe).join(" · ") }),
												N.some((e) => e.kind === "quest" && e.card === t) && /* @__PURE__ */ m(X, {})
											]
										}, t))
									})
								]
							})
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "pg-log",
						children: /* @__PURE__ */ m(l, {
							log: e.log,
							line: (e) => _.t(br[e.kind], {
								name: pe(e.rid),
								n: e.kind === "move" ? (e.cell ?? 0) + 1 : e.amount ?? 0,
								card: e.card === void 0 ? "" : ["adventure", "reserve"].includes(e.kind) ? _.adventure(e.card) : [
									"activate",
									"companion",
									"retire"
								].includes(e.kind) ? _.character(e.card) : ""
							})
						})
					})
				]
			}),
			A && e.phase === "pay" && e.payment && /* @__PURE__ */ m(vr, {
				pub: e,
				player: j,
				hand: le,
				target: e.payment,
				send: ee
			}, `${e.payment.kind}:${e.payment.id}`),
			/* @__PURE__ */ m(u, {
				open: oe.length > 0,
				onClose: () => T([]),
				label: me,
				title: me,
				children: /* @__PURE__ */ m("div", {
					className: "pg-choice-list",
					children: oe.map((e) => /* @__PURE__ */ h("button", {
						onClick: () => I(e),
						children: [e.kind === "activate" ? /* @__PURE__ */ h(p, { children: [
							/* @__PURE__ */ m(pn, { art: O[e.item].art }),
							_.t($.activateWith, {
								item: _.item(e.item),
								name: _.character(j.party.find((t) => t.id === e.character).card)
							}),
							e.cost ? _.t($.convert) : ""
						] }) : e.cells?.map((e) => e + 1).join(" → "), /* @__PURE__ */ m(X, {})]
					}, e.id))
				})
			}),
			/* @__PURE__ */ m(u, {
				open: Ce,
				onClose: () => {
					let e = N.find((e) => e.kind === "skip");
					e && I(e);
				},
				label: me,
				title: me,
				children: /* @__PURE__ */ m("div", {
					className: `pg-choice-cards${Se ? " pg-choice-characters" : ""}`,
					children: N.map((t) => /* @__PURE__ */ m("div", { children: t.kind === "journey" ? /* @__PURE__ */ m(hr, {
						card: t.card,
						legal: !0,
						onClick: () => I(t)
					}) : t.kind === "chooseItem" ? /* @__PURE__ */ m(dr, {
						card: t.card,
						legal: !0,
						onClick: () => I(t)
					}) : t.kind === "chooseCompanion" || t.kind === "retire" ? /* @__PURE__ */ m(pr, {
						character: t.kind === "retire" ? j.party.find((e) => e.id === t.character) : {
							id: t.card,
							card: t.card,
							item: null
						},
						config: e.config,
						legal: !0,
						onClick: () => I(t),
						onInspect: () => b({
							kind: "companion",
							card: t.kind === "retire" ? j.party.find((e) => e.id === t.character).card : t.card
						})
					}) : t.card !== void 0 && t.card >= 0 ? /* @__PURE__ */ m(mr, {
						card: t.card,
						legal: !0,
						onClick: () => I(t)
					}) : /* @__PURE__ */ h("button", {
						className: "pg-paper",
						onClick: () => I(t),
						children: [t.kind === "skip" ? _.t($.skip) : _.t(t.card === -1 ? $.deck1 : $.deck2), /* @__PURE__ */ m(X, {})]
					}) }, t.id))
				})
			}),
			/* @__PURE__ */ m(u, {
				open: E,
				onClose: () => k(!1),
				label: _.t($.party),
				title: pe(M.rid),
				children: /* @__PURE__ */ h("div", {
					className: "pg-satchel",
					children: [
						/* @__PURE__ */ m("div", {
							className: "pg-party",
							children: M.party.map((t) => /* @__PURE__ */ m(pr, {
								character: t,
								config: e.config,
								leaderIndex: M.leader,
								onInspect: () => _e(t.card)
							}, t.id))
						}),
						/* @__PURE__ */ h("div", {
							className: "pg-collections",
							children: [
								/* @__PURE__ */ h("button", {
									onClick: () => S("completed"),
									children: [
										_.t($.completed),
										" · ",
										M.completed.length
									]
								}),
								/* @__PURE__ */ h("button", {
									onClick: () => S("retired"),
									children: [
										_.t($.retired),
										" · ",
										M.retired.length
									]
								}),
								/* @__PURE__ */ h("button", {
									onClick: () => S("reserved"),
									children: [
										_.t($.reserved),
										" · ",
										M.reserved.length
									]
								})
							]
						}),
						M.journey && /* @__PURE__ */ m(hr, {
							card: M.journey.card,
							visited: M.journey.visited,
							onClick: () => b({
								kind: "journey",
								card: M.journey.card,
								owner: M.rid
							})
						}),
						/* @__PURE__ */ m("div", {
							className: "pg-journey-history",
							children: M.journeys.map((e) => /* @__PURE__ */ m(hr, {
								card: e,
								visited: F[e].cells,
								onClick: () => b({
									kind: "journey",
									card: e,
									owner: M.rid
								})
							}, e))
						})
					]
				})
			}),
			/* @__PURE__ */ m(u, {
				open: x !== null,
				onClose: () => S(null),
				label: x ? _.word(x === "market" ? "adventures" : x) : "",
				title: x ? _.word(x === "market" ? "adventures" : x) : "",
				children: /* @__PURE__ */ m("div", {
					className: "pg-collection-grid",
					children: x === "quests" ? e.quests.map((e, t) => /* @__PURE__ */ h("button", {
						className: "pg-quest pg-paper",
						onClick: () => b({
							kind: "quest",
							card: t
						}),
						children: [
							/* @__PURE__ */ m("strong", { children: _.quest(e.card) }),
							/* @__PURE__ */ m("span", { children: _.costs([
								[
									3,
									0,
									0
								],
								[
									0,
									3,
									0
								],
								[
									0,
									0,
									3
								]
							][t]) }),
							/* @__PURE__ */ m("span", { children: e.signed.map(pe).join(" · ") })
						]
					}, t)) : x === "retired" ? M.retired.map((t) => /* @__PURE__ */ m(pr, {
						character: {
							id: t,
							card: t,
							item: null
						},
						config: e.config,
						onInspect: () => b({
							kind: "companion",
							card: t
						})
					}, t)) : (x === "market" ? e.market : x ? M[x] : []).filter((e) => e !== null).map((e) => /* @__PURE__ */ m(mr, {
						card: e,
						onClick: () => b({
							kind: "adventure",
							card: e
						})
					}, e))
				})
			}),
			/* @__PURE__ */ m(u, {
				open: y !== null,
				onClose: () => b(null),
				label: _.t($.details),
				title: y ? y.kind === "item" ? _.item(y.card) : y.kind === "companion" ? _.character(y.card) : y.kind === "adventure" ? _.adventure(y.card) : y.kind === "quest" ? _.t($.quests) : _.t($.journeys) : "",
				children: y && /* @__PURE__ */ h(gr, { children: [
					y.kind === "item" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(dr, {
						card: y.card,
						disabled: !0
					}), /* @__PURE__ */ h("p", { children: [
						_.word(O[y.card].color),
						" · ",
						_.word(O[y.card].activate)
					] })] }),
					y.kind === "companion" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(pr, {
						character: {
							id: y.card,
							card: y.card,
							item: null
						},
						config: e.config,
						leaderIndex: e.players.find((e) => e.rid === y.owner)?.leader ?? 0
					}), (y.card < 0 ? ce(e.players.find((e) => e.rid === y.owner)?.leader ?? 0, e.config.leaderSide) : D[y.card]).abilities.map((e, t) => /* @__PURE__ */ m(fr, { ability: e }, t))] }),
					y.kind === "adventure" && /* @__PURE__ */ h(p, { children: [
						/* @__PURE__ */ m(mr, { card: y.card }),
						/* @__PURE__ */ m("p", { children: _.costs(P[y.card].cost) }),
						/* @__PURE__ */ m("p", { children: _.improvement(P[y.card].improvement) }),
						N.filter((e) => e.kind === "adventure" && e.card === y.card).map((e) => /* @__PURE__ */ m("button", {
							className: "pg-primary",
							onClick: () => {
								S(null), b(null), I(e);
							},
							children: _.t($.choosePayment)
						}, e.id))
					] }),
					y.kind === "quest" && /* @__PURE__ */ h(p, { children: [
						/* @__PURE__ */ m("strong", { children: _.quest(e.quests[y.card].card) }),
						/* @__PURE__ */ m("p", { children: _.costs([
							[
								3,
								0,
								0
							],
							[
								0,
								3,
								0
							],
							[
								0,
								0,
								3
							]
						][y.card]) }),
						/* @__PURE__ */ m("p", { children: _.t($.questScale) }),
						e.quests[y.card].signed.map((e, t) => /* @__PURE__ */ h("p", { children: [
							pe(e),
							" · ",
							_.t($.points, { n: 2 - t })
						] }, e)),
						N.filter((e) => e.kind === "quest" && e.card === y.card).map((e) => /* @__PURE__ */ m("button", {
							className: "pg-primary",
							onClick: () => {
								S(null), b(null), I(e);
							},
							children: _.t($.join)
						}, e.id))
					] }),
					y.kind === "journey" && /* @__PURE__ */ h(p, { children: [
						/* @__PURE__ */ m(hr, {
							card: y.card,
							visited: e.players.find((e) => e.rid === y.owner)?.journey?.visited
						}),
						/* @__PURE__ */ m("p", { children: _.t($.points, { n: F[y.card].points }) }),
						F[y.card].reward !== "none" && /* @__PURE__ */ m(fr, { ability: { kind: F[y.card].reward } })
					] })
				] })
			})
		]
	});
}
//#endregion
//#region src/games/pilgrims/bot.ts
var wr = {
	goal: .8,
	engine: .2,
	journey: 1.2,
	clover: 1.1,
	reserve: .2
}, Tr = (e, t) => e.reduce((e, n) => t(n) > t(e) ? n : e);
function Er(e, t, n, r) {
	let i = P[n], a = (4 - e.round) * 3 + 2 - e.turnInRound, o = i.improvement ? r.engine * Math.min(3, a * (i.improvement.kind === "discount" ? .6 : .35)) : 0, s = lt(t, e.quests, e.config).quests, c = lt({
		...t,
		completed: [...t.completed, n]
	}, e.quests, e.config).quests;
	return i.points + i.clovers * r.clover + o + c - s - i.retire * .55;
}
function Dr(e, t, n) {
	let r = D[n], i = t.party.filter((e) => e.card >= 0).length, a = lt({
		...t,
		retired: [...t.retired, n]
	}, e.quests, e.config).quests - e.scores[t.rid].quests, o = r.types.filter((e) => !t.party.some((t) => t.card >= 0 && D[t.card].types.includes(e))).length;
	return (i < 3 ? 2.1 : .8) + o * .35 + a * .6 + r.abilities.length * .12;
}
function Or(e, t, n, r, i) {
	let a = O[r], o = [...n, ...t.party.flatMap((e) => e.item === null ? [] : [e.item])], s = [...e.market, ...t.reserved].filter((e) => e !== null), c = Math.max(0, ...s.map((n) => {
		let r = he(t, {
			kind: "adventure",
			id: n
		}), s = r.cost.reduce((e, t) => e + t, 0), c = y.indexOf(a.color);
		return a.color === "gold" || Math.max(0, r.cost[c] - o.filter((e) => O[e].color === a.color).length) ? Er(e, t, n, i) / (s + 1) : 0;
	}));
	return 1 + (a.color === "gold" ? .7 : 0) + i.goal * Math.min(1.5, c);
}
function kr(e, t, n, r, i) {
	let a = e.board[r];
	return (a ? a.kind === "item" ? Or(e, t, n, a.card, i) : Dr(e, t, a.card) : re.includes(r) ? 1.4 : 1.5) + (t.journey && F[t.journey.card].cells.includes(r) && !t.journey.visited.includes(r) ? i.journey * (t.journey.visited.length === 2 ? 2 : 1) : 0);
}
function Ar(e, t, n, r, i) {
	return r.kind === "move" ? Math.max(0, ...Ge(t.position, r).map((r) => kr(e, t, n, r.at(-1), i))) : r.kind === "clover" ? i.clover : r.kind === "item" || r.kind === "chooseItem" ? 1.7 : r.kind === "chooseCompanion" ? t.party.length < 4 ? 2.6 : 1.3 : r.kind === "reserve" ? i.reserve : r.kind === "extra" ? n.length > 1 ? 1.8 : .3 : r.kind === "paid" ? t.clovers ? Math.max(0, Ar(e, t, n, r.effect, i) - i.clover) : 0 : r.kind === "take" ? Math.max(0, ...e.board.flatMap((a, o) => a?.kind === "item" && O[a.card].color === r.color && (!r.adjacent || Math.abs(o % 5 - t.position % 5) + Math.abs(Math.floor(o / 5) - Math.floor(t.position / 5)) === 1) ? [Or(e, t, n, a.card, i)] : [])) : .1;
}
function jr(e = wr) {
	return ({ public: t, private: n }, r) => {
		if (t.actor !== r.rid || t.phase === "resolve" || t.phase === "done") return null;
		let i = t.players.find((e) => e.rid === r.rid), a = n?.hand ?? [], o = [...t.choices, ...n?.choices ?? []], s = r.difficulty === "weak", c = (e) => ({ action: {
			type: "choose",
			id: e.id
		} });
		if (t.phase === "pay" && t.payment) return { action: be(i, a, t.payment) ?? { type: "cancel" } };
		if (t.phase === "adventure") {
			let n = o.flatMap((e) => (e.kind === "adventure" || e.kind === "quest") && be(i, a, {
				kind: e.kind,
				id: e.card
			}) ? [e] : []);
			return n.length ? c(Tr(n, (n) => {
				if (n.kind === "adventure") return Er(t, i, n.card, e);
				let r = t.quests.map((e, t) => t === n.card ? {
					...e,
					signed: [...e.signed, i.rid]
				} : e);
				return lt(i, r, t.config).quests - t.scores[i.rid].quests + (4 - t.round) * .5 - .5;
			})) : !s && i.clovers >= 2 && a.length < 5 && t.deckCounts.items + t.discard.length > 0 ? { action: { type: "buyItem" } } : c(o.find((e) => e.kind === "skip"));
		}
		return o.length ? s ? t.phase === "activate" ? c(o.find((e) => e.kind === "activate" && !e.cost) ?? o[0]) : c(o[0]) : c(Tr(o, (n) => {
			if (n.kind === "corner" || n.kind === "take" || n.kind === "move") return kr(t, i, a, n.cells.at(-1), e);
			if (n.kind === "travel") {
				let r = se[n.card];
				return Math.max(...Ge(i.position, r).map((n) => kr(t, i, a, n.at(-1), e)));
			}
			if (n.kind === "journey") return F[n.card].cells.reduce((e, t) => e - (Math.abs(t % 5 - i.position % 5) + Math.abs(Math.floor(t / 5) - Math.floor(i.position / 5))) / 10, F[n.card].points);
			if (n.kind === "chooseItem") return Or(t, i, a, n.card, e);
			if (n.kind === "chooseCompanion") return Dr(t, i, n.card);
			if (n.kind === "retire") return -Dr(t, i, i.party.find((e) => e.id === n.character).card);
			if (n.kind === "returnReserve") return -Er(t, i, n.card, e);
			if (n.kind === "reserve") {
				if (n.card < 0) return 0;
				let r = he(i, {
					kind: "adventure",
					id: n.card
				}), o = [...a, ...i.party.flatMap((e) => e.item === null ? [] : [e.item])], s = r.cost.reduce((e, t, n) => e + Math.max(0, t - o.filter((e) => O[e].color === y[n]).length), 0);
				return Er(t, i, n.card, e) - s * 1.5 - Math.max(0, r.party.length - i.party.length + 1) * 2;
			}
			if (n.kind === "activate") {
				let r = i.party.find((e) => e.id === n.character);
				return (r.card < 0 ? ce(i.leader, t.config.leaderSide) : D[r.card]).abilities.reduce((r, o) => r + Ar(t, i, a.filter((e) => e !== n.item), o, e), 0) - n.cost * e.clover - (r.item === null ? 0 : .8) - (O[n.item].color === "gold" ? .5 : 0);
			}
			if (n.kind === "clover") return e.clover;
			if (n.kind === "effect") {
				let e = t.effects.find((e) => e.id === n.effect);
				return e?.kind === "clover" ? 5 : e?.kind === "take" ? 4 : e?.kind === "extra" ? 3 : e?.kind === "reserve" ? 1 : 2;
			}
			return n.kind === "skip" ? -.1 : 0;
		})) : null;
	};
}
var Mr = jr(), Nr = [
	["adventures", "scoreAdventures"],
	["clovers", "scoreClovers"],
	["quests", "scoreQuests"],
	["journeys", "scoreJourneys"],
	["items", "scoreItems"]
];
function Pr({ result: e, public: t, private: r, members: i, myRid: a, hintCount: c, onPlayAgain: l, onBackToLobby: u }) {
	let d = s((e) => e.locale), f = t, p = ur(), [_, ne] = n(!0), v = (e) => {
		let t = i.find((t) => t.rid === e);
		return e === "$falconer" ? p.t($.falconer) : t ? o(t, d) : e;
	}, y = e.winner.map(v).join(" · "), b = f.players.find((t) => t.rid === e.ranking[0]);
	return /* @__PURE__ */ h("div", {
		className: "pg-result",
		children: [
			e.winner.includes(a) && /* @__PURE__ */ m(te, {}),
			/* @__PURE__ */ h("div", {
				className: "h-full",
				inert: _,
				children: [/* @__PURE__ */ m(Cr, {
					pub: f,
					priv: r,
					members: i,
					myRid: a,
					send: () => {},
					review: !0
				}), /* @__PURE__ */ m("button", {
					className: "pg-reopen",
					onClick: () => ne(!0),
					children: p.t($.showResult)
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: "pg-result-shade",
				hidden: !_,
				children: /* @__PURE__ */ h("section", {
					className: "pg-result-book",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": p.t($.resultTitle),
					children: [
						/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("p", { children: p.t($.resultTitle) }), /* @__PURE__ */ m("h1", { children: p.t($.victory, { name: y }) })] }), /* @__PURE__ */ m("button", {
							className: "pg-result-close",
							"aria-label": p.t($.close),
							onClick: () => ne(!1),
							children: /* @__PURE__ */ m(ee, { size: 24 })
						})] }),
						/* @__PURE__ */ h("div", {
							className: "pg-result-content",
							children: [
								/* @__PURE__ */ h("div", {
									className: "pg-result-emblem",
									children: [/* @__PURE__ */ m(sr, { leader: b.leader }), /* @__PURE__ */ h("strong", { children: [f.scores[b.rid].total, /* @__PURE__ */ m("small", { children: p.t($.total) })] })]
								}),
								/* @__PURE__ */ h("div", {
									className: "pg-score-details",
									children: [/* @__PURE__ */ m("div", {
										className: "pg-score-scroll",
										children: /* @__PURE__ */ h("table", {
											className: "pg-score-table",
											children: [/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {}), e.ranking.map((t) => /* @__PURE__ */ h("th", {
												"data-winner": e.winner.includes(t) || void 0,
												children: [
													e.winner.includes(t) ? "⚑ " : "",
													v(t),
													e.autopilot?.[t] ? /* @__PURE__ */ m("small", { children: p.t("session.autopilot.share", { n: Math.round(e.autopilot[t] * 100) }) }) : null
												]
											}, t))] }) }), /* @__PURE__ */ h("tbody", { children: [
												Nr.filter(([e]) => e !== "items" || f.players.some((e) => e.solo)).map(([t, n]) => /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", { children: p.word(n) }), e.ranking.map((e) => /* @__PURE__ */ m("td", { children: Number(f.scores[e][t]) }, e))] }, t)),
												/* @__PURE__ */ h("tr", {
													className: "pg-score-total",
													children: [/* @__PURE__ */ m("th", { children: p.t($.total) }), e.ranking.map((e) => /* @__PURE__ */ m("td", { children: f.scores[e].total }, e))]
												}),
												/* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", { children: p.t($.tieItems) }), e.ranking.map((e) => /* @__PURE__ */ m("td", { children: f.players.find((t) => t.rid === e).handCount }, e))] })
											] })]
										})
									}), /* @__PURE__ */ m("div", {
										className: "pg-quest-results",
										children: f.players.map((e) => /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("strong", { children: v(e.rid) }), f.scores[e.rid].questDetails.map((e) => /* @__PURE__ */ h("p", { children: [
											p.quest(f.quests[e.slot].card),
											" · ",
											p.t($.questCount, { n: e.count }),
											" · ",
											p.t($.points, { n: e.points })
										] }, e.slot))] }, e.rid))
									})]
								}),
								c !== void 0 && /* @__PURE__ */ m("p", { children: p.t("session.hint.usedCount", { n: c }) })
							]
						}),
						/* @__PURE__ */ h("footer", {
							className: "pg-result-footer",
							children: [/* @__PURE__ */ m("button", {
								onClick: () => ne(!1),
								children: p.t($.review)
							}), l || u ? /* @__PURE__ */ h("div", { children: [
								l && /* @__PURE__ */ m(g, {
									label: p.t("session.result.playAgain"),
									confirmLabel: p.t($.confirmAgain),
									onConfirm: l
								}),
								" ",
								u && /* @__PURE__ */ m(g, {
									label: p.t("session.result.backToLobby"),
									confirmLabel: p.t($.confirmLobby),
									onConfirm: u
								})
							] }) : /* @__PURE__ */ m("p", { children: p.t("session.result.waitHost") })]
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/pilgrims/options.tsx
function Fr({ value: e, onChange: t }) {
	let n = ur(), r = Se.safeParse(e), i = r.success ? r.data : Se.parse(void 0);
	return /* @__PURE__ */ h("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ m(ne, {
				title: n.t($.optLeader),
				children: ["A", "B"].map((e) => /* @__PURE__ */ m(_, {
					name: "pilgrims-leader",
					value: e,
					checked: i.leaderSide === e,
					label: n.t(e === "A" ? $.sideA : $.sideB),
					accent: xe.accent,
					onChange: () => t({
						...i,
						leaderSide: e
					})
				}, e))
			}),
			/* @__PURE__ */ m(v, {
				checked: i.journeys,
				label: n.t($.optJourneys),
				accent: xe.accent,
				onChange: () => t({
					...i,
					journeys: !i.journeys
				})
			}),
			/* @__PURE__ */ m(ne, {
				title: n.t($.optSolo),
				children: [
					"AB",
					"BC",
					"AD",
					"CD"
				].map((e, r) => /* @__PURE__ */ m(_, {
					name: "pilgrims-solo",
					value: e,
					checked: i.soloDifficulty === e,
					label: n.t([
						$.easy,
						$.medium,
						$.hard,
						$.hardcore
					][r]),
					accent: xe.accent,
					onChange: () => t({
						...i,
						soloDifficulty: e
					})
				}, e))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/pilgrims/entry.tsx
var Ir = {
	definition: ft,
	View: Sr,
	bot: Mr,
	OverView: Pr,
	Options: Fr,
	locales: {
		zh: {
			name: "朝圣者：一场奇幻冒险",
			desc: "招募奇妙旅伴，收集物品，穿越童话乡野，写下自己的冒险故事。",
			errAction: "这个操作当前不可用，请重新选择。",
			leader: "领袖",
			falconer: "驯鹰人",
			falcon: "猎鹰",
			round: "第 {{n}} 天／4",
			waiting: "等待 {{name}} 行动",
			cornerPrompt: "选择一个起始角落",
			journeyPrompt: "选择一张旅程牌",
			travelPrompt: "选择本回合的移动方式",
			extraActivatePrompt: "再激活一位尚未激活的其他角色，或跳过",
			activatePrompt: "用一张手牌激活角色，或获得三叶草",
			effectsPrompt: "选择要执行的能力",
			movePrompt: "选择地图上的落点",
			takePrompt: "选择要取得的物品",
			swapPrompt: "选择两张相邻物品交换，或跳过",
			reservePrompt: "选择要预留的冒险",
			returnReservePrompt: "选择一张预留冒险放回牌库底",
			retirePrompt: "队伍已满，选择一位原有同伴退休",
			chooseItemPrompt: "保留一张物品，另一张放回牌库底",
			chooseCompanionPrompt: "保留一位同伴，另一张放回牌库底",
			adventurePrompt: "完成一项冒险、报名公共任务，或结束回合",
			payPrompt: "选择支付物品、参与者及退休同伴",
			resolvePrompt: "旅行继续……",
			travel0: "马车",
			travel1: "骑马",
			travel2: "乘船",
			travel3: "步行",
			red: "力量",
			blue: "沟通",
			green: "野外导航",
			gold: "万能",
			sword: "武器",
			notes: "乐器",
			compass: "行旅",
			star: "魔法",
			wanderer: "旅人",
			nobleheart: "善心者",
			beast: "异兽",
			scoundrel: "恶徒",
			any: "任意同伴",
			clovers: "三叶草",
			gainClover: "获得1枚三叶草",
			buyItem: "支付2枚三叶草抽取物品",
			skip: "跳过",
			endTurn: "结束回合",
			pay: "确认支付",
			cancel: "取消",
			hand: "手牌",
			party: "队伍",
			adventures: "冒险",
			quests: "公共任务",
			journeys: "旅程",
			reserved: "预留冒险",
			completed: "已完成",
			retired: "已退休",
			close: "关闭",
			inspect: "查看详情",
			details: "详情",
			points: "{{n}}分",
			handCount: "{{n}}张手牌",
			cell: "地图第{{n}}格",
			deck1: "一级牌库",
			deck2: "二级牌库",
			drawnItems: "待选物品",
			participants: "参与同伴",
			retire: "退休同伴",
			itemsPayment: "支付物品",
			paymentClover: "另需支付{{n}}枚三叶草",
			invalidPayment: "尚未满足物品、同伴或退休要求",
			choosePayment: "选择支付组合",
			discount: "使用宝藏折扣",
			cost: "费用",
			reward: "奖励",
			improvement: "改善",
			noImprovement: "无改善",
			noItem: "未持物品",
			used: "已使用",
			selected: "已选中",
			heldItem: "所持物品",
			activateWith: "以{{item}}激活{{name}}",
			convert: "另付1枚三叶草",
			visit: "已到访 {{n}}／3",
			questCount: "收集{{n}}张",
			signed: "已报名",
			join: "报名",
			questType: "收集{{type}}同伴（含退休者）",
			questActivation: "收集带{{symbol}}符号的同伴（含退休者）",
			questClovers: "收集奖励三叶草的冒险",
			questTravel: "收集改善移动方式的冒险",
			questLevel: "收集二级冒险",
			questDiscount: "收集提供折扣的冒险",
			questScale: "收集1／2／3／4张，获得1／2／4／6分；报名位置另计2／1／0分。",
			abilityMove: "按图移动并取得落点卡牌",
			abilityClover: "获得1枚三叶草",
			abilityItem: "从牌库抽取1张物品",
			abilityChooseItem: "抽取2张物品，保留1张",
			abilityChooseCompanion: "抽取2张同伴，保留1张",
			abilityReserve: "预留1张冒险",
			abilityExtra: "再激活一位其他角色",
			abilitySwap: "移动前可交换两张正交相邻的物品",
			abilityTake: "取得地图上1张{{color}}物品",
			abilityAdjacent: "取得正交相邻格的1张{{color}}物品",
			abilityPaid: "可支付1枚三叶草：{{effect}}",
			abilityEncounter: "越过或到达其他人物所在格时获得1枚三叶草",
			abilityCorner: "到达角落时获得1枚三叶草",
			abilityPass: "途中可取得1张路过格的物品",
			improveCapacity: "队伍同伴上限增加1",
			improveReserve: "预留冒险上限增加1",
			improveDiscount: "每项冒险或公共任务少付1张{{color}}物品",
			improvePaid: "可支付1枚三叶草，抵扣1张任意颜色物品",
			improveTravel: "{{travel}}时：{{effect}}",
			improveExtra: "最多多移动{{n}}格",
			improveActivateColor: "以{{color}}物品激活时：{{effect}}",
			improveActivateSymbol: "以{{symbol}}物品激活时：{{effect}}",
			improveCompleted: "完成其他冒险时：{{effect}}",
			improveEncounter: "越过或到达其他人物所在格时：{{effect}}",
			optLeader: "领袖能力",
			sideA: "A面",
			sideB: "B面",
			optJourneys: "启用旅程牌",
			optSolo: "单人难度",
			easy: "简单",
			medium: "中等",
			hard: "困难",
			hardcore: "极难",
			hint: "选择当前可用的旅行行动。",
			resultTitle: "旅行账册",
			victory: "{{name}}成为最有经验的旅人",
			showResult: "查看旅行账册",
			review: "回看地图",
			total: "总分",
			scoreAdventures: "冒险得分",
			scoreClovers: "剩余三叶草",
			scoreQuests: "公共任务",
			scoreJourneys: "旅程得分",
			scoreItems: "驯鹰人剩余物品",
			tieItems: "平分比较：手牌数量",
			confirmAgain: "确认重新开始？",
			confirmLobby: "确认返回大厅？",
			logItem: "{{name}}取得了物品",
			logCompanion: "{{name}}招募了{{card}}",
			logMove: "{{name}}移动到第{{n}}格",
			logActivate: "{{name}}激活了{{card}}",
			logClover: "{{name}}获得{{n}}枚三叶草",
			logRetire: "{{name}}让{{card}}退休",
			logReserve: "{{name}}预留了{{card}}",
			logAdventure: "{{name}}完成了{{card}}",
			logQuest: "{{name}}报名了公共任务",
			logJourney: "{{name}}完成了旅程",
			logRound: "第{{n}}天开始",
			logSwap: "{{name}}交换了地图上的物品",
			logEnd: "四天的旅行结束了",
			c0: "盗贼",
			c1: "婆婆",
			c2: "仙女",
			c3: "巨龙",
			c4: "骑士",
			c5: "寻水人",
			c6: "公主",
			c7: "野性精灵",
			c8: "猎人",
			c9: "地精",
			c10: "巨人",
			c11: "水妖",
			c12: "熊",
			c13: "画家",
			c14: "牧师",
			c15: "术士",
			c16: "狼",
			c17: "嚎叫者",
			c18: "牧羊人",
			c19: "风琴师",
			c20: "铁匠",
			c21: "顾问",
			c22: "旅店老板",
			c23: "小丑",
			c24: "樵夫",
			c25: "小恶魔",
			c26: "王子",
			c27: "女巫",
			c28: "地主",
			c29: "树桩精",
			c30: "狐狸",
			c31: "鹅姑娘",
			a0: "力量药水",
			a1: "皇家马车",
			a2: "结伴搭车",
			a3: "绝妙风景",
			a4: "篝火情谊",
			a5: "修理水井",
			a6: "帮助爷爷",
			a7: "野猪",
			a8: "演出",
			a9: "年轻强盗",
			a10: "往日故事",
			a11: "争斗",
			a12: "大甜菜",
			a13: "甜蜜点心",
			a14: "疗伤草药",
			a15: "迷途羔羊",
			a16: "复仇",
			a17: "大丰收",
			a18: "村庄舞会",
			a19: "新马蹄铁",
			a20: "宽恕",
			a21: "满满的篮子",
			a22: "冬日储备",
			a23: "巨蛙",
			a24: "皇家舞会",
			a25: "最高峰",
			a26: "归途",
			a27: "袋中恶徒",
			a28: "金鱼",
			a29: "隐藏的宝藏",
			a30: "抢劫",
			a31: "深入地下",
			a32: "寻得真爱",
			a33: "三头龙",
			a34: "魔法花朵",
			a35: "精彩演出",
			a36: "史诗之战",
			j0: "旅程 1",
			j1: "旅程 2",
			j2: "旅程 3",
			j3: "旅程 4",
			j4: "旅程 5",
			j5: "旅程 6",
			j6: "旅程 7",
			j7: "旅程 8",
			j8: "旅程 9",
			j9: "旅程 10",
			j10: "旅程 11",
			j11: "旅程 12",
			j12: "旅程 13",
			j13: "旅程 14",
			j14: "旅程 15",
			j15: "旅程 16",
			j16: "旅程 17",
			i0: "剑",
			i1: "鼓",
			i2: "木杖",
			i3: "扫帚",
			i4: "药瓶",
			i5: "手风琴",
			i6: "帽子",
			i7: "花朵",
			i8: "绳索",
			i9: "吉他",
			i10: "地图",
			i11: "水桶",
			i12: "宝石",
			rules: "目标：\n带领队伍在童话乡野旅行四天，以冒险、三叶草、公共任务及可选旅程获得最高分。基础版支持1–4人；单人模式与官方驯鹰人竞争。所有玩家使用同一面的领袖。\n准备：\n地图有25格，其中6格为营火，放置同伴，其余格放置物品。公共区展示3张一级冒险、2张二级冒险，以及A、B、C组各一张公共任务。每位玩家获得1张手牌和1枚三叶草。随机确定先手，再从末位开始逆序选择不同角落并取得该格物品。\n回合：\n共4轮，每人每轮3回合。每回合依次进行以下步骤：\n· 移动。\n· 激活角色。\n· 完成冒险或报名公共任务。\n· 补充地图与冒险展示区。\n四种移动方式每轮各只能用一次，选择其中三种。移动图案可以旋转和翻转，先取得落点卡牌，再移动人物。营火招募同伴，其余格取得物品；落点无牌或被人物占据时，从对应牌库抽取。队伍最多有领袖与3位同伴；超限时，必须让一位原有同伴退休，并弃置其持有的物品，新同伴不能直接退休。手牌数量不限且对他人保密。\n激活：\n从手牌打出一张物品，激活符号匹配的领袖或同伴；也可支付1枚三叶草转换符号。角色最多持有一张物品，再激活前弃掉旧物。可以不激活而获得1枚三叶草。多项能力由玩家选择顺序，每项每次激活只执行一次；额外激活只能选择本回合尚未激活的其他角色。能力可以移动、取得指定物品、抽二选一、交换物品或预留冒险，具体图案见卡牌详情。预留通常上限1张；超过上限前先选择旧预留放回对应牌库底，再取得新的冒险。预留牌公开。\n冒险与公共任务：\n每回合至多完成一张冒险或报名一个公共任务，也可跳过。冒险可以来自公共展示区或自己的预留。支付物品可取自手牌及角色持物；金色物品可代替任意颜色，每支付1枚三叶草可转换一张物品的颜色。改善的指定颜色折扣可叠加，不能转换颜色；隐藏的宝藏允许每次支付1枚三叶草抵扣一张任意颜色物品。\n选择符合冒险要求的参与同伴，领袖不参与。双类型同伴只能填一个位置；问号表示任意一位独立同伴。每支付2枚三叶草，可转换一位参与同伴的类型。冒险需要退休时，只能从参与者中选择对应数量，所持物品一并弃置。获得卡牌所示分数、三叶草与永久改善；新取得的完成冒险触发改善不作用于它自己。\n三张公共任务分别收取3张红、蓝、绿物品，可以使用折扣及颜色转换。每位玩家最多报名两个任务，同一任务只能报名一次，每项最多三人。报名位置在终局依次获得 2、1、0 分；C组任务报名时另获得1枚三叶草。任务收集1、2、3、4张及以上匹配牌，分别获得 1、2、4、6 分。A组检查同伴类型，B组检查同伴激活符号，均包括现役与退休同伴而不包括领袖；C组检查已完成冒险，不含预留。详情说明具体收集条件。\n三叶草与补充：\n自己的回合中，随时可以支付2枚三叶草抽取一张物品，可重复。物品牌库耗尽时洗混弃牌；同伴不回收。回合末从上到下、从左到右补满地图空格，人物所在格不补，再补满冒险展示区；指定等级的冒险牌库耗尽时，改从另一级牌库补充，两叠均耗尽则保留空位。第二天结束后，若中间展示位仍是一级冒险，将其放回一级牌库底；已补入的二级冒险保留。从第三天起，展示区优先补为两张一级和三张二级冒险。\n旅程（默认关闭）：\n启用后，每人抽两张旅程保留一张，另一张放回牌库底。人物落到三个目标格时分别标记；完成三格后获得所示分数及即时奖励，再抽二选一。新旅程中的当前位置不会自动标记，必须离开再返回。终局时，未完成旅程中每个已到访的目标格也获得 1 分。正式二版共17张旅程牌。\n单人模式：\n玩家先手。驯鹰人与猎鹰从中央格出发，取得中央物品及额外一张物品。四档难度分别使用AB、BC、AD、CD两组共6张单人牌，每轮洗混。每次对手回合翻两张牌，先移动猎鹰，再移动驯鹰人；图案不旋转，选择编号最小的有效目标。每张单人牌的顶部奖励都先领取。对手招募同伴时另获得1枚三叶草，同伴无能力与数量限制；只要有2枚三叶草，立即换一张物品。\n第二张牌的箭头决定检查公共冒险与任务的方向。对手完成第一张付得起物品的冒险，忽略同伴、退休要求和改善，金色物品仅在必要时使用；没有可完成冒险时尝试报名公共任务。终局时，对手每张剩余物品获得 1 分，三叶草不计分；启用旅程时另加5分。\n终局：\n第四轮结束后，计算已完成冒险分数、每剩余 3 枚三叶草获得 1 分、报名位置及公共任务收集分、旅程分。总分最高者获胜；平分时比较剩余手牌，仍同分则共享胜利。"
		},
		en: {
			name: "Pilgrims: Curious Adventures",
			desc: "Gather curious companions and useful items, cross a fairytale land, and collect your own stories.",
			errAction: "That action is unavailable. Please choose again.",
			leader: "Leader",
			falconer: "Falconer",
			falcon: "Falcon",
			round: "Day {{n}} / 4",
			waiting: "Waiting for {{name}}",
			cornerPrompt: "Choose a starting corner",
			journeyPrompt: "Choose a journey",
			travelPrompt: "Choose your travel",
			extraActivatePrompt: "Activate another character not yet activated this turn, or skip",
			activatePrompt: "Activate a character with an item, or gain a clover",
			effectsPrompt: "Choose an ability to use",
			movePrompt: "Choose a destination",
			takePrompt: "Choose an item to take",
			swapPrompt: "Swap adjacent items, or skip",
			reservePrompt: "Choose an adventure to reserve",
			returnReservePrompt: "Return a reserved adventure to its deck",
			retirePrompt: "Your party is full. Retire an existing companion",
			chooseItemPrompt: "Keep one item and return the other",
			chooseCompanionPrompt: "Keep one companion and return the other",
			adventurePrompt: "Complete an adventure, join a quest, or end your turn",
			payPrompt: "Choose items, participants, and companions to retire",
			resolvePrompt: "The journey continues…",
			travel0: "Carriage",
			travel1: "Horse",
			travel2: "Boat",
			travel3: "Walking",
			red: "Strength",
			blue: "Communication",
			green: "Wilderness",
			gold: "Wild",
			sword: "Weapon",
			notes: "Music",
			compass: "Wayfaring",
			star: "Magic",
			wanderer: "Wanderer",
			nobleheart: "Nobleheart",
			beast: "Beast",
			scoundrel: "Scoundrel",
			any: "Any companion",
			clovers: "Clovers",
			gainClover: "Gain 1 clover",
			buyItem: "Spend 2 clovers to draw an item",
			skip: "Skip",
			endTurn: "End turn",
			pay: "Confirm payment",
			cancel: "Cancel",
			hand: "Hand",
			party: "Party",
			adventures: "Adventures",
			quests: "Public quests",
			journeys: "Journeys",
			reserved: "Reserved adventures",
			completed: "Completed",
			retired: "Retired",
			close: "Close",
			inspect: "Inspect",
			details: "Details",
			points: "{{n}} VP",
			handCount: "{{n}} items in hand",
			cell: "Map space {{n}}",
			deck1: "Level I deck",
			deck2: "Level II deck",
			drawnItems: "Item choice",
			participants: "Participants",
			retire: "Retire companions",
			itemsPayment: "Pay with items",
			paymentClover: "Also spend {{n}} clovers",
			invalidPayment: "Item, party, or retirement requirements are not met",
			choosePayment: "Choose your payment",
			discount: "Use treasure discount",
			cost: "Cost",
			reward: "Reward",
			improvement: "Improvement",
			noImprovement: "No improvement",
			noItem: "No held item",
			used: "Used",
			selected: "Selected",
			heldItem: "Held item",
			activateWith: "Activate {{name}} with {{item}}",
			convert: "Spend 1 clover",
			visit: "Visited {{n}} / 3",
			questCount: "{{n}} collected",
			signed: "Joined",
			join: "Join",
			questType: "Collect {{type}} companions, including retired ones",
			questActivation: "Collect companions with {{symbol}}, including retired ones",
			questClovers: "Collect adventures that reward clovers",
			questTravel: "Collect adventures with travel improvements",
			questLevel: "Collect level II adventures",
			questDiscount: "Collect adventures with discounts",
			questScale: "Collect 1 / 2 / 3 / 4 cards for 1 / 2 / 4 / 6 VP; signing positions add 2 / 1 / 0 VP.",
			abilityMove: "Move as shown and take the destination card",
			abilityClover: "Gain 1 clover",
			abilityItem: "Draw 1 item",
			abilityChooseItem: "Draw 2 items and keep 1",
			abilityChooseCompanion: "Draw 2 companions and keep 1",
			abilityReserve: "Reserve 1 adventure",
			abilityExtra: "Activate another character",
			abilitySwap: "Before moving, you may swap two orthogonally adjacent items",
			abilityTake: "Take 1 {{color}} item from the map",
			abilityAdjacent: "Take 1 {{color}} item from an orthogonally adjacent space",
			abilityPaid: "You may spend 1 clover: {{effect}}",
			abilityEncounter: "Gain 1 clover when passing over or landing on another figure",
			abilityCorner: "Gain 1 clover when landing in a corner",
			abilityPass: "Take 1 item from a passed-over space",
			improveCapacity: "Your party may hold 1 more companion",
			improveReserve: "You may reserve 1 more adventure",
			improveDiscount: "Pay 1 fewer {{color}} item for each adventure or quest",
			improvePaid: "You may spend 1 clover to discount any 1 item",
			improveTravel: "When using {{travel}}: {{effect}}",
			improveExtra: "Move up to {{n}} extra spaces",
			improveActivateColor: "When activating with a {{color}} item: {{effect}}",
			improveActivateSymbol: "When activating with {{symbol}}: {{effect}}",
			improveCompleted: "When completing another adventure: {{effect}}",
			improveEncounter: "When passing over or landing on another figure: {{effect}}",
			optLeader: "Leader abilities",
			sideA: "Side A",
			sideB: "Side B",
			optJourneys: "Include journey cards",
			optSolo: "Solo difficulty",
			easy: "Easy",
			medium: "Medium",
			hard: "Hard",
			hardcore: "Hardcore",
			hint: "Choose an available travel action.",
			resultTitle: "Journey ledger",
			victory: "{{name}} is the most experienced pilgrim",
			showResult: "Show journey ledger",
			review: "Review the map",
			total: "Total",
			scoreAdventures: "Adventures",
			scoreClovers: "Remaining clovers",
			scoreQuests: "Public quests",
			scoreJourneys: "Journeys",
			scoreItems: "Falconer’s remaining items",
			tieItems: "Tiebreak: items in hand",
			confirmAgain: "Start another game?",
			confirmLobby: "Return to the lobby?",
			logItem: "{{name}} gained an item",
			logCompanion: "{{name}} recruited {{card}}",
			logMove: "{{name}} moved to space {{n}}",
			logActivate: "{{name}} activated {{card}}",
			logClover: "{{name}} gained {{n}} clovers",
			logRetire: "{{name}} retired {{card}}",
			logReserve: "{{name}} reserved {{card}}",
			logAdventure: "{{name}} completed {{card}}",
			logQuest: "{{name}} joined a public quest",
			logJourney: "{{name}} completed a journey",
			logRound: "Day {{n}} begins",
			logSwap: "{{name}} swapped items on the map",
			logEnd: "Four days of travels have ended",
			c0: "Rogue",
			c1: "Granny",
			c2: "Fairy",
			c3: "Dragon",
			c4: "Knight",
			c5: "Dowser",
			c6: "Princess",
			c7: "Wild Spirit",
			c8: "Hunter",
			c9: "Gnome",
			c10: "Giant",
			c11: "Water Goblin",
			c12: "Bear",
			c13: "Painter",
			c14: "Priest",
			c15: "Warlock",
			c16: "Wolf",
			c17: "Howler",
			c18: "Shepherd",
			c19: "Organist",
			c20: "Blacksmith",
			c21: "Counselor",
			c22: "Innkeeper",
			c23: "Jester",
			c24: "Woodcutter",
			c25: "Imp",
			c26: "Prince",
			c27: "Witch",
			c28: "Landlord",
			c29: "Stump",
			c30: "Fox",
			c31: "Goose Girl",
			a0: "Potion of Strength",
			a1: "Royal Carriage",
			a2: "Ride with a Friend",
			a3: "Amazing View",
			a4: "Bonfire Bonding",
			a5: "Fixing the Well",
			a6: "Helping Grandpa",
			a7: "Wild Boar",
			a8: "Performance",
			a9: "Young Bandit",
			a10: "Old Stories",
			a11: "Brawl",
			a12: "Big Beetroot",
			a13: "Sweet Snack",
			a14: "Healing Herbs",
			a15: "Lost Sheep",
			a16: "Revenge",
			a17: "Great Catch",
			a18: "Village Dance-off",
			a19: "New Horseshoes",
			a20: "Forgiveness",
			a21: "Full Baskets",
			a22: "Supplies for Winter",
			a23: "Giant Frog",
			a24: "Royal Ball",
			a25: "The Highest Mountain",
			a26: "Way Home",
			a27: "Wretch in a Sack",
			a28: "Golden Fish",
			a29: "Hidden Treasure",
			a30: "Robbery",
			a31: "Descent into the Depths",
			a32: "Found Love",
			a33: "Three-headed Dragon",
			a34: "Magical Flower",
			a35: "Epic Show",
			a36: "Epic Fight",
			j0: "Journey 1",
			j1: "Journey 2",
			j2: "Journey 3",
			j3: "Journey 4",
			j4: "Journey 5",
			j5: "Journey 6",
			j6: "Journey 7",
			j7: "Journey 8",
			j8: "Journey 9",
			j9: "Journey 10",
			j10: "Journey 11",
			j11: "Journey 12",
			j12: "Journey 13",
			j13: "Journey 14",
			j14: "Journey 15",
			j15: "Journey 16",
			j16: "Journey 17",
			i0: "Sword",
			i1: "Drum",
			i2: "Staff",
			i3: "Broom",
			i4: "Potion",
			i5: "Accordion",
			i6: "Hat",
			i7: "Flower",
			i8: "Rope",
			i9: "Guitar",
			i10: "Map",
			i11: "Bucket",
			i12: "Gem",
			rules: "Goal:\nLead a party through four days of fairytale travels. Score adventures, clovers, public quests, and optional journeys. The game supports 1–4 players; solo play uses the official Falconer. All leaders use the same side.\nSetup:\nThe 25-space map holds companions on six campfires and items elsewhere. Display three level I adventures, two level II adventures, and one quest each from groups A, B, and C. Each player receives one item and one clover. Choose a random first player, then select different corners in reverse turn order and take those items.\nTurns:\nPlay four rounds, with three turns per player per round. Each turn proceeds in this order:\n· Move.\n· Activate a character.\n· Complete an Adventure or join a public Quest.\n· Replenish the map and Adventure displays.\nUse three of the four travel diagrams each round, each at most once. Diagrams may be rotated or reflected. Take the destination card before moving your figure. Campfires recruit companions; other spaces provide items. Empty or occupied spaces give a card from the corresponding deck. Your party holds a leader and up to three companions. To recruit beyond that limit, retire an existing companion and discard its held item; you cannot retire the newly recruited companion. Your private hand has no limit.\nActivation:\nPlay a hand item under a character with a matching activation symbol, or spend one clover to convert the symbol. A character holds at most one item; discard an old item before reactivation. Instead of activating, gain one clover. Choose the order of multiple abilities, using each once per activation. Extra activations must use other characters not yet activated this turn. Abilities provide movement, specific map items, draw-two-keep-one drafts, item swaps, or adventure reserves; inspect the diagrams for details. The normal reserve limit is one. Return an old reserve to its deck before taking a replacement. Reserved adventures are public.\nAdventures and quests:\nComplete at most one adventure or join one public quest per turn, or skip. Adventures may come from the display or your reserve. Pay with hand items and/or held items. Gold is wild. Spend one clover to convert an item's color. Permanent color discounts stack and cannot change color; Hidden Treasure lets you spend one clover to discount any one item.\nChoose participating companions matching the party requirement. Leaders never participate. A dual-type companion fills only one requirement, and each question mark requires a separate companion. Spend two clovers to convert a participant's type. If retirement is required, retire the required number of participants and discard their held items. Gain the adventure's points, clovers, and permanent improvement. An improvement triggered by completing adventures does not trigger for itself.\nThe three quest positions cost three red, blue, or green items respectively, with discounts and conversions allowed. Join at most two quests, each only once; each quest holds at most three players. Signing positions score 2, 1, and 0 VP. Group C quests also grant one clover immediately. Collecting 1, 2, 3, or at least 4 matching cards scores 1, 2, 4, or 6 VP. Group A counts companion types and group B their activation symbols, including active and retired companions but excluding leaders. Group C counts completed adventures, never reserves. Inspect each quest for its objective.\nClovers and replenishment:\nAt any time during your turn, spend two clovers to draw one item, repeatedly if affordable. Reshuffle item discards when needed; companions do not recycle. Refill unoccupied map spaces from top to bottom and left to right, then refill adventures. If the required adventure deck is empty, draw from the other level; leave the space empty if both decks are exhausted. After day two, return the middle display card to the bottom of the level I deck only if it is still a level I card; keep any level II card already there. From day three, refill toward two level I and three level II display cards.\nJourneys (off by default):\nDraw two journeys, keep one, and return the other to the bottom. Mark its three destinations as your figure lands on them. Completing all three grants its points and any immediate reward, then draft another journey. A new journey does not mark your current space until you leave and return. Each visited space on an unfinished journey scores one VP. The second printing has 17 journeys.\nSolo:\nYou play first. The Falconer and falcon start at the center, taking its item plus one extra item. The four difficulties use AB, BC, AD, or CD, six solo cards reshuffled each round. Reveal two cards per opponent turn, moving the falcon first and the Falconer second. Do not rotate diagrams; take the lowest-numbered valid destination. Grant each card's top reward before movement. Recruiting a companion grants the Falconer one clover; companions have no abilities or limit. Immediately exchange each two clovers for an item.\nThe second card's arrow sets the order for checking adventures and then quests. The Falconer completes the first affordable adventure, ignoring party requirements, retirement, and improvements, and using gold only when necessary. If none is affordable, try to join a quest. Each remaining Falconer item scores one VP, clovers score nothing, and journeys add a flat five VP if enabled.\nScoring:\nAfter round four, score completed adventures, one VP per three remaining clovers, signing positions and quest objectives, and journeys. Highest total wins. Ties go to the player with more hand items; remaining ties share victory."
		}
	}
};
//#endregion
export { Ir as default };
