import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { useWakeLock as s } from "@bgparty/sdk/use-wake-lock";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { BottomSheet as l } from "@bgparty/sdk/bottom-sheet";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { AVATARS as d } from "@bgparty/sdk/avatars";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { seatName as p } from "@bgparty/sdk/ui/player-strip";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Floater as _, FlySprite as v } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as y } from "@bgparty/sdk/confirm-button";
import { GameOverChime as b } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as x, OptionSection as S } from "@bgparty/sdk/ui/game-options";
//#region src/games/thedealer/meta.ts
var C = {
	id: "thedealer",
	tier: "alpha",
	nameKey: "games.thedealer.name",
	descKey: "games.thedealer.desc",
	rulesKey: "games.thedealer.rules",
	icon: "🛸",
	iconImg: "games/thedealer.webp",
	mechanics: [
		"push-your-luck",
		"deduction",
		"hand-management"
	],
	interactionTags: [],
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [5, 6],
	accent: "#c8db45",
	releasedAt: "2026-11-07T15:05:00+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover",
	botDelayMs: 950
}, w = [
	"dealer",
	"sniper",
	"keeper",
	"computer",
	"prophet",
	"gambler",
	"frenemy",
	"giant",
	"witness",
	"destroyer"
], T = t.enum(w), E = t.string(), D = t.int().min(0).max(3), O = t.object({ rolePool: t.enum(["all", "starter"]).default("all") }).prefault({}), k = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("prepare"),
		target: E.optional(),
		friend: t.boolean().optional(),
		prediction: t.int().min(3).max(5).optional()
	}),
	t.object({
		type: t.literal("deal"),
		card: t.int().min(0).max(99),
		target: E
	}),
	t.object({
		type: t.literal("guess"),
		value: D
	}),
	t.object({
		type: t.literal("tell"),
		target: E,
		total: t.int().min(0).max(30)
	}),
	t.object({
		type: t.literal("decide"),
		bank: t.boolean()
	}),
	t.object({
		type: t.literal("destroy"),
		value: D
	}),
	t.object({
		type: t.literal("gamble"),
		take: t.boolean()
	}),
	t.object({ type: t.literal("confirm") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), A = t.object({
	id: t.int(),
	value: D.nullable(),
	parity: t.enum(["even", "odd"]).nullable(),
	guess: D.nullable(),
	correct: t.boolean().nullable(),
	secret: t.boolean()
}), j = t.object({
	total: t.int(),
	bust: t.boolean(),
	base: t.int(),
	bonus: t.int(),
	cards: t.array(D),
	removed: t.array(D)
}), M = t.object({
	round: t.int(),
	roles: t.record(E, T),
	points: t.record(E, t.int()),
	base: t.record(E, t.int()),
	bonus: t.record(E, t.int()),
	bust: t.record(E, t.boolean())
}), N = t.object({
	phase: t.enum([
		"prepare",
		"deal",
		"guess",
		"talk",
		"decisions",
		"destroy",
		"reveal",
		"gamble",
		"score",
		"bonus",
		"review",
		"tie",
		"tieReveal",
		"done"
	]),
	round: t.int(),
	rounds: t.int(),
	cycle: t.int(),
	dealer: E,
	actor: E.nullable(),
	players: t.array(t.object({
		rid: E,
		role: T,
		count: t.int(),
		banked: t.boolean(),
		decided: t.boolean(),
		prepared: t.boolean(),
		score: t.int()
	})),
	targets: t.array(E),
	deckCount: t.int(),
	deadline: t.number().nullable(),
	statements: t.array(t.object({
		by: E,
		target: E,
		total: t.int(),
		cycle: t.int()
	})),
	outcomes: t.record(E, j),
	confirmed: t.array(E),
	results: t.array(M),
	frenemyTarget: E.nullable(),
	frenemyFriend: t.boolean().nullable(),
	sniperPrediction: t.int().nullable(),
	destroyValue: D.nullable(),
	tiePlayers: t.array(E),
	tieGuesses: t.record(E, D),
	tieCard: D.nullable(),
	tieRound: t.int()
}), P = t.object({
	hands: t.record(E, t.array(A)),
	pool: t.array(t.object({
		id: t.int(),
		value: D
	})),
	decision: t.boolean().nullable(),
	friend: t.boolean().nullable(),
	prediction: t.int().nullable(),
	tieGuess: D.nullable()
}), F = {
	deal: 400,
	decisions: 650,
	reveal: 900,
	score: 850,
	bonus: 850,
	tie: 1600
}, I = (e) => Math.floor(e / 25), L = (e) => e.players.find((t) => e.roles[t] === "dealer"), R = (e, t) => e.players.find((n) => e.roles[n] === t), z = (e) => {
	let t = e.players.indexOf(L(e));
	return Array.from({ length: e.players.length - 1 }, (n, r) => e.players[(t + r + 1) % e.players.length]);
}, B = (e) => z(e).filter((t) => !e.banked.includes(t)), ee = (e) => e.reduce((e, t) => e + I(t), 0), V = () => ({ code: "games.thedealer.invalid" });
function H(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function U(e, t) {
	return e.deck.splice(0, t);
}
function W(e, t, n, r = !1) {
	let i = r ? [t] : e.players.filter((n) => n !== t || e.roles[t] === "witness" && e.hands[t].length === 2);
	return {
		kind: "deal",
		rid: t,
		data: {
			id: e.hands[t].length - 1,
			secretOnly: r
		},
		for: i,
		secret: { value: I(n) }
	};
}
function G(e) {
	if (e.cycle++, e.deadline = null, e.decisions = {}, e.targets = B(e), e.deck.length < e.targets.length + 1) {
		e.banked = z(e), te(e);
		return;
	}
	e.pool = U(e, e.targets.length + 1), e.phase = "deal";
}
function te(e) {
	e.phase = R(e, "destroyer") ? "destroy" : "reveal", e.revealAt = 0, e.deadline = null;
}
function ne(e) {
	e.hands = Object.fromEntries(e.players.map((e) => [e, []])), e.pool = [], e.banked = [], e.decisions = {}, e.prepared = [], e.pending = null, e.guesses = {}, e.deadline = null, e.statements = [], e.frenemyTarget = null, e.friend = null, e.prediction = null, e.destroyValue = null, e.removed = {}, e.outcomes = {}, e.revealAt = 0, e.bonusAt = 0, e.confirmed = [], e.cycle = 0, e.targets = [];
	let t = R(e, "keeper"), n = [];
	if (t) {
		let [r] = U(e, 1);
		r !== void 0 && (e.hands[t].push(r), n.push(W(e, t, r, !0)));
	}
	return e.phase = R(e, "sniper") || R(e, "frenemy") ? "prepare" : "deal", e.phase === "deal" && G(e), n;
}
function re(e) {
	return e.players.filter((t) => ["sniper", "frenemy"].includes(e.roles[t])).every((t) => e.prepared.includes(t));
}
function K(e, t, n) {
	let r = ee(n);
	return e.scores[t] += r, e.outcomes[t].bonus += r, r;
}
function ie(e) {
	let t = L(e);
	e.outcomes[t] ??= {
		total: 0,
		bust: !1,
		base: 0,
		bonus: 0,
		cards: [],
		removed: []
	}, e.results.push({
		round: e.round,
		roles: { ...e.roles },
		points: Object.fromEntries(e.players.map((t) => [t, e.outcomes[t].base + e.outcomes[t].bonus])),
		base: Object.fromEntries(e.players.map((t) => [t, e.outcomes[t].base])),
		bonus: Object.fromEntries(e.players.map((t) => [t, e.outcomes[t].bonus])),
		bust: Object.fromEntries(e.players.map((t) => [t, e.outcomes[t].bust]))
	}), e.phase = "review";
}
function ae(e) {
	let t = Math.max(...Object.values(e.scores));
	e.tiePlayers = e.players.filter((n) => e.scores[n] === t), e.tiePlayers.length === 1 || e.deck.length === 0 ? (e.winners = [...e.tiePlayers], e.phase = "done") : (e.phase = "tie", e.tieRound = 1, e.tieGuesses = {}, e.tieCard = null);
}
function oe(e) {
	return e.phase === "deal" ? L(e) : e.phase === "guess" ? e.pending?.target ?? null : e.phase === "destroy" ? R(e, "destroyer") ?? null : e.phase === "gamble" ? z(e)[e.revealAt] ?? null : null;
}
var se = {
	meta: C,
	saveCompatibility: { version: "1" },
	schemas: {
		action: k,
		publicView: N,
		privateView: P,
		config: O
	},
	setup(e, t, n) {
		let r = {
			players: [...t],
			roles: {},
			config: O.parse(e),
			seed: n,
			cursor: 0,
			deck: [],
			hands: {},
			pool: [],
			scores: Object.fromEntries(t.map((e) => [e, 0])),
			phase: "prepare",
			round: 1,
			rounds: t.length === 3 ? 6 : t.length,
			cycle: 0,
			banked: [],
			decisions: {},
			prepared: [],
			targets: [],
			pending: null,
			guesses: {},
			deadline: null,
			statements: [],
			frenemyTarget: null,
			friend: null,
			prediction: null,
			destroyValue: null,
			removed: {},
			outcomes: {},
			revealAt: 0,
			bonusAt: 0,
			confirmed: [],
			results: [],
			tiePlayers: [],
			tieGuesses: {},
			tieCard: null,
			tieRound: 0,
			winners: []
		};
		r.deck = H(r, Array.from({ length: 100 }, (e, t) => t));
		let i = ["dealer", ...H(r, r.config.rolePool === "starter" ? [
			"frenemy",
			"giant",
			"gambler",
			"prophet",
			"computer"
		] : w.filter((e) => e !== "dealer")).slice(0, t.length - 1)];
		return r.roles = Object.fromEntries(t.map((e, t) => [e, i[t]])), {
			state: r,
			fx: ne(r)
		};
	},
	reduce(e, t, n) {
		if (t.type === "tick" && n.by !== "$engine" || t.type !== "tick" && !e.players.includes(n.by)) return V();
		let r = structuredClone(e), i = n.by, a = [], o = r.roles[i];
		if (t.type === "prepare") {
			if (r.phase !== "prepare" || r.prepared.includes(i)) return V();
			if (o === "sniper" && t.prediction !== void 0) r.prediction = t.prediction;
			else if (o === "frenemy" && t.friend !== void 0 && t.target && z(r).includes(t.target) && t.target !== i) r.frenemyTarget = t.target, r.friend = t.friend;
			else return V();
			r.prepared.push(i), re(r) && G(r);
		} else if (t.type === "deal") {
			if (r.phase !== "deal" || i !== L(r) || !r.targets.includes(t.target) || !r.pool.includes(t.card)) return V();
			r.pool.splice(r.pool.indexOf(t.card), 1), r.roles[t.target] === "prophet" ? (r.pending = {
				target: t.target,
				card: t.card
			}, r.phase = "guess") : (r.hands[t.target].push(t.card), r.targets = r.targets.filter((e) => e !== t.target), a.push(W(r, t.target, t.card))), r.phase === "deal" && r.targets.length === 0 && (r.deck.push(...r.pool), r.pool = [], r.phase = "talk");
		} else if (t.type === "guess" && r.phase === "guess") {
			if (r.pending?.target !== i) return V();
			let e = r.pending.card;
			(r.guesses[i] ??= {})[e] = {
				value: t.value,
				correct: I(e) === t.value
			}, r.hands[i].push(e), r.targets = r.targets.filter((e) => e !== i), r.pending = null, a.push(W(r, i, e)), r.phase = "deal", r.targets.length === 0 && (r.deck.push(...r.pool), r.pool = [], r.phase = "talk");
		} else if (t.type === "tell") {
			if (r.phase !== "talk" || !B(r).includes(t.target) || t.target === i) return V();
			r.statements = r.statements.filter((e) => e.by !== i || e.target !== t.target || e.cycle !== r.cycle), r.statements.push({
				by: i,
				target: t.target,
				total: t.total,
				cycle: r.cycle
			});
		} else if (t.type === "decide") {
			if (r.phase !== "talk" || !B(r).includes(i)) return V();
			r.decisions[i] = t.bank, B(r).every((e) => e in r.decisions) && (r.phase = "decisions");
		} else if (t.type === "destroy") {
			if (r.phase !== "destroy" || o !== "destroyer") return V();
			r.destroyValue = t.value;
			let e = r.hands[i].filter((e) => I(e) === t.value);
			r.removed[i] = e, r.hands[i] = r.hands[i].filter((e) => I(e) !== t.value), r.deck.push(...e), r.phase = "reveal", a.push({
				kind: "destroy",
				rid: i,
				data: {
					cards: e.map(I),
					count: e.length
				}
			});
		} else if (t.type === "gamble") {
			if (r.phase !== "gamble" || i !== z(r)[r.revealAt]) return V();
			if (t.take) {
				let e = U(r, 1);
				if (e.length) {
					let t = I(e[0]);
					r.outcomes[i].cards.push(t), t === 0 ? (r.outcomes[i].bust = !0, r.outcomes[i].base = 0, r.deck.push(...r.hands[i], ...e)) : r.outcomes[i].base += t, a.push({
						kind: "prize",
						rid: i,
						data: {
							cards: [t],
							points: t
						}
					});
				}
			}
			r.phase = "score";
		} else if (t.type === "confirm") {
			if (r.phase !== "review" || r.confirmed.includes(i)) return V();
			if (r.confirmed.push(i), r.confirmed.length === r.players.length) {
				if (r.round === r.rounds) ae(r);
				else {
					let e = { ...r.roles };
					r.players.forEach((t, n) => {
						r.roles[r.players[(n + 1) % r.players.length]] = e[t];
					}), r.round++, a.push(...ne(r));
				}
			}
		} else if (t.type === "guess" && r.phase === "tie") {
			if (!r.tiePlayers.includes(i) || i in r.tieGuesses) return V();
			if (r.tieGuesses[i] = t.value, r.tiePlayers.every((e) => e in r.tieGuesses)) {
				let [e] = U(r, 1);
				r.tieCard = I(e), r.deck.push(e), r.phase = "tieReveal", a.push({
					kind: "tie",
					data: { value: r.tieCard }
				});
			}
		} else if (t.type === "tick") {
			if (r.phase === "talk") r.deadline === null ? r.deadline = t.now + 3e4 : t.now >= r.deadline && (B(r).forEach((e) => {
				r.decisions[e] ??= !1;
			}), r.phase = "decisions");
			else if (r.phase === "decisions") {
				let e = B(r).filter((e) => r.decisions[e]);
				r.banked.push(...e), e.forEach((e) => a.push({
					kind: "bank",
					rid: e,
					data: { count: r.hands[e].length },
					...a.length ? { with: !0 } : {}
				})), B(r).length === 0 ? te(r) : G(r);
			} else if (r.phase === "reveal") {
				let e = z(r)[r.revealAt], t = r.hands[e].map(I), n = t.reduce((e, t) => e + t, 0), i = n < 3 || n > (r.roles[e] === "giant" ? 7 : 5);
				r.outcomes[e] = {
					total: n,
					bust: i,
					base: i ? 0 : n,
					bonus: 0,
					cards: t,
					removed: (r.removed[e] ?? []).map(I)
				}, r.phase = r.roles[e] === "gambler" && !i ? "gamble" : "score", a.push({
					kind: "reveal",
					rid: e,
					data: {
						cards: t,
						total: n,
						bust: i
					}
				});
			} else if (r.phase === "score") {
				let e = z(r)[r.revealAt], t = r.outcomes[e], n = L(r);
				if (r.scores[e] += t.base, t.bust) {
					r.roles[e] === "gambler" && t.cards.length > r.hands[e].length || r.deck.push(...r.hands[e]);
					let i = U(r, 2);
					r.outcomes[n] ??= {
						total: 0,
						bust: !1,
						base: 0,
						bonus: 0,
						cards: [],
						removed: []
					};
					let o = K(r, n, i);
					r.outcomes[n].cards.push(...i.map(I)), a.push({
						kind: "return",
						rid: e,
						data: { cards: t.cards }
					}, {
						kind: "prize",
						rid: n,
						data: {
							cards: i.map(I),
							points: o
						},
						with: !0
					});
				} else a.push({
					kind: "score",
					rid: e,
					data: { points: t.base }
				});
				r.revealAt++, r.phase = r.revealAt < z(r).length ? "reveal" : "bonus";
			} else if (r.phase === "bonus") {
				let e = r.players[r.bonusAt++], t = r.outcomes[e];
				if (r.roles[e] === "sniper" && t && !t.bust && t.base === r.prediction) {
					let t = U(r, 2), n = K(r, e, t);
					a.push({
						kind: "prize",
						rid: e,
						data: {
							cards: t.map(I),
							points: n
						}
					});
				}
				if (r.roles[e] === "frenemy" && r.frenemyTarget && r.outcomes[r.frenemyTarget].bust !== r.friend) {
					let t = U(r, 1), n = K(r, e, t);
					a.push({
						kind: "prize",
						rid: e,
						data: {
							cards: t.map(I),
							points: n
						}
					});
				}
				r.bonusAt === r.players.length && ie(r);
			} else if (r.phase === "tieReveal") {
				let e = r.tiePlayers.filter((e) => r.tieGuesses[e] === r.tieCard);
				e.length === 1 ? (r.winners = e, r.phase = "done") : (e.length && (r.tiePlayers = e), r.tieRound++, r.tieGuesses = {}, r.tieCard = null, r.phase = "tie");
			} else return V();
		} else return V();
		return {
			state: r,
			fx: a
		};
	},
	viewFor(e, t) {
		let n = e.players.includes(t), r = Object.fromEntries(e.players.map((n) => [n, e.hands[n].map((r, i) => {
			let a = n in e.outcomes || e.roles[n] === "keeper" && i === 0 ? n in e.outcomes || n === t : !e.banked.includes(n) && (n !== t || e.roles[n] === "witness" && i === 1), o = e.guesses[n]?.[r];
			return {
				id: i,
				value: a ? I(r) : null,
				parity: e.roles[n] === "computer" ? I(r) % 2 == 0 ? "even" : "odd" : null,
				guess: o?.value ?? null,
				correct: o?.correct ?? null,
				secret: e.roles[n] === "keeper" && i === 0
			};
		})]));
		return {
			public: {
				phase: e.phase,
				round: e.round,
				rounds: e.rounds,
				cycle: e.cycle,
				dealer: L(e),
				actor: oe(e),
				players: e.players.map((t) => ({
					rid: t,
					role: e.roles[t],
					count: e.hands[t].length,
					banked: e.banked.includes(t),
					decided: t in e.decisions,
					prepared: e.prepared.includes(t),
					score: e.scores[t]
				})),
				targets: [...e.targets],
				deckCount: e.deck.length,
				deadline: e.deadline,
				statements: e.statements,
				outcomes: e.outcomes,
				confirmed: e.confirmed,
				results: e.results,
				frenemyTarget: e.frenemyTarget,
				frenemyFriend: [
					"bonus",
					"review",
					"tie",
					"tieReveal",
					"done"
				].includes(e.phase) ? e.friend : null,
				sniperPrediction: [
					"bonus",
					"review",
					"tie",
					"tieReveal",
					"done"
				].includes(e.phase) ? e.prediction : null,
				destroyValue: e.destroyValue,
				tiePlayers: e.tiePlayers,
				tieGuesses: ["tieReveal", "done"].includes(e.phase) ? e.tieGuesses : {},
				tieCard: e.tieCard,
				tieRound: e.tieRound
			},
			...n ? { private: {
				hands: r,
				pool: t === L(e) ? e.pool.map((e) => ({
					id: e,
					value: I(e)
				})) : [],
				decision: e.decisions[t] ?? null,
				friend: e.roles[t] === "frenemy" ? e.friend : null,
				prediction: e.roles[t] === "sniper" ? e.prediction : null,
				tieGuess: e.tieGuesses[t] ?? null
			} } : {}
		};
	},
	status(e) {
		let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t] || Number(e.winners.includes(n)) - Number(e.winners.includes(t)));
		return {
			phase: e.phase,
			scores: { ...e.scores },
			...e.phase === "done" ? {
				winner: [...e.winners],
				ranking: t
			} : {}
		};
	},
	nextTickIn(e, t) {
		return e.phase === "talk" ? e.deadline === null ? 0 : Math.max(0, e.deadline - t) : [
			"decisions",
			"reveal",
			"score",
			"bonus",
			"tieReveal"
		].includes(e.phase) ? e.phase === "tieReveal" ? F.tie : F[e.phase] : null;
	}
}, q = {
	dealer: "games.thedealer.dealer",
	sniper: "games.thedealer.sniper",
	keeper: "games.thedealer.keeper",
	computer: "games.thedealer.computer",
	prophet: "games.thedealer.prophet",
	gambler: "games.thedealer.gambler",
	frenemy: "games.thedealer.frenemy",
	giant: "games.thedealer.giant",
	witness: "games.thedealer.witness",
	destroyer: "games.thedealer.destroyer"
}, ce = {
	dealer: "games.thedealer.dealerInfo",
	sniper: "games.thedealer.sniperInfo",
	keeper: "games.thedealer.keeperInfo",
	computer: "games.thedealer.computerInfo",
	prophet: "games.thedealer.prophetInfo",
	gambler: "games.thedealer.gamblerInfo",
	frenemy: "games.thedealer.frenemyInfo",
	giant: "games.thedealer.giantInfo",
	witness: "games.thedealer.witnessInfo",
	destroyer: "games.thedealer.destroyerInfo"
}, J = {
	prepare: "games.thedealer.preparePrompt",
	deal: "games.thedealer.dealPrompt",
	guess: "games.thedealer.guessPrompt",
	talk: "games.thedealer.talkPrompt",
	decisions: "games.thedealer.decisionsPrompt",
	destroy: "games.thedealer.destroyPrompt",
	reveal: "games.thedealer.revealPrompt",
	gamble: "games.thedealer.gamblePrompt",
	score: "games.thedealer.scorePrompt",
	bonus: "games.thedealer.bonusPrompt",
	review: "games.thedealer.reviewPrompt",
	tie: "games.thedealer.tiePrompt",
	tieReveal: "games.thedealer.tieRevealPrompt",
	done: "games.thedealer.donePrompt"
}, Y = {
	dealer: "data:image/webp;base64,UklGRgY3AABXRUJQVlA4IPo2AAAwlQCdASrIAMcAPlUgjESjoiEZTWbQOAVEtgQ4AMYWNf6B1KnQPMflR+Tvyi8c9VXsf7n+0P7/7xOtbqnzJugf+p9wnzQ/2PqU/qf+g/7fuEfqb/z/8N/k/bL/YD3PfuZ6hP6f/qv2v95r/n/tV7rP71/v/2R+AL+zf6n/2+u77GH7mewb/M/8//9PXb/cn4Pv7F/yf3H+B79iv/h7AH/79QD/88T3/kv4h6uvAH7N+r3+p/snpf4v/JP7D+1v989r7/F8FfpP8d+znqP/I/tV+P/vX7p/mV92P3r/Z/2PxJ+An9X/fvx7+QL8c/lf+P/tf7df3L92vrj+O/Y7uQdj/x/+t9QX2M+i/5v+6/5n/sf5n4Ofo/+l6D/Xv/cfbd9gH8+/q3+y/u/70/HP+q/5ni3/eP9z+1/wA/zf+uf8n/BflB9MX8z/2v8x/pf3F9pv6H/gf+v/lfyr+wf+Wf1T/e/37/N/+7/O////0feB/+fcB+2f/891H9pf/gtDLWvT6AR3+VjbD4HBJNm4hqOnvr+TiIva/+mxRepuAv9egYGp3WTMbkye7YjyPoEjtAEP+nujV9JUkRjfzJN+oIzWmOFBHAK03zD2LIaRMbZrIKAL4MjpfVdtoW1vq7ywLfnsMG+IEYKovLCgfqdCBj0ceNglemS/cR/9ezxScQ4U7aLeCOnq2qcgLZg3eNd0E36nvjmKmoNcFpytVSNmYSve6I2bKawN3RRIXr9Tc8TvunQm1VXQiIXl4Mrm1DWubOK11lpVkCfLaMmHA/7kHD4oOoAnPB/BdOlBN1MS92gzrpDnW/7bQ4iNxl6l+AYfVAqEuCX10RChMwAC08ozvFE8dcbvwYXvnsWX8SwP5cS9GwfC2ETb6QdzxHpCVdEtTV2ijPThiRhJCpAqvvFQOHXVgiZGPSsxJr/e8oPOz87kN5mkChHFkxKHuwI1kF6Mopa+JH+TQIWR19eymqCtHQlpICWz4equqAtfvfo18gWW/IGTlbMyB7KC6b03F4/xs50uwLnY6k35WBY4ZNFPX3QVCG0fWqIL+/R2Gg5La7/uYo4/ZvTiz34QxMIQSQngE8MDCw7+9UJQwczuk8zJS9xruR/NG1tVfaPlWdIT/sogoMvINUJ19yAPqq/AOP7Lzy/Nxt20BDxjKR1FEFk+gg98AWuZrttLw2d6ZYCLyQTfbCC/rfnFlm2C4h1W1E8o3axOFO6k7LBLBav/68FHzlY8PiQyCVNTs9WJGcEN+P1+sb/+4jDRRpcCOEBq+Un1afwNfXcyrsN9XgQmB+afSXyXAEIKy6O3XcKdqxnyvBGfoMGxRywD1Lqzdf0sBDRVnpjB3INLmjopYT1TrfYsktnQ+bykIxPyr/UWk5LnSaPS2znDxBVv54ryzhjGfVxxCA24xj0X6X35xIPh6GyD9a0I0xjUuSG9r+U49htthlj+BKE9qpXPX4aVMxNjaxGR2bbn3k24ODm9QAqmF9CTgN3mKUEaOPqLXjc8Qa4vXK7GgZ9Es8u4rlCojIsiW6rBZVRaq3zP3QBX0GUg//dxgfYEpDsPBCCtUgTJfO8XWfrEY0/9AF4DCZYdojqs8p9uTsOoAAD+xZyqwaeKinDmXqbrBnrmijXKcppEBWX0RxhHZxdNTenY8PRTo0sGvyyToQSK/AVf7iw56hS4b78DAK3Nc+ppAwouXuAbTgc14vHJirjnaditppgrJDYxDuxzSZCCezRgjLp53iUqsV0MrsapzSpJBt5OkAFfdXcrh0wpwqHiz1zN3IODS41iKlH4WmdhjQ5/dTQgmAITvGkC9SK/iNuxsdKxZNL0Fq+DZ7yj5Xz/nRFG4RRZCCckGbms6nU2G7FLb1r/BCN2PBUf5gXlgime+WBNdrTnpwAVz42Kwo38HZ9z+HU5FfIKWWxf7DoaEbCr/G00MqxGXdk9zJtNZ/GUinIKTJa6bGBhhLqf+PjP3wh7iV+ZD+kqOc1x8MqvQcv/0rrgafr7a0E4rbWeXtR6t+Hb8RBm+FGe9QSiPAh40CutRoAoZsyFu5vcr1Kv2JGlpkjsKbM11msbKyOrP4KN8/Ut/CDzhdPmCQL0BX0uI1q4g9+ESY6dYYuExxqG8PdONWy+e0qGKcc0pxJAW9kGhv2J6eR9MZKGhVKU4ykaiGBw+ayAFveuvF/0FTXkon17qcGX6ThD0c6eMtX7YbfNU4DH+m5OsUnMdPxfUwb/EBr2F7p92c7+Pg6zHeNqFiru0vawJXX1HokCciz8VSWWy1r3mXi8WefNnjB2oCRmYsNlYk1/+ffg9vcxUzKRbuSDnzG2WabSNryLI0zw5p7Pu73wNHuz0DmVs9gHH462ppaV0IbGseZy35D/sR5+pK4C0CUwuKQ0JIf07jJkEjGWz+1MaEuAtn8A9pJGKZ1R+OK99OljXfzVZDbC9qj088Tyr0krGQXZ0BqrM55yD/ACALE5tKdmpo81atdSZqUMxxXcM8T5Rll4ZoBza1VzwCK20MJo1vS1X5Dw9M8H+ABgj0wnlCs1otSKC35pbNgT2H75/6zNLe/gwuXNd7MTiZ86VISzQPgcRBtAwsTu79TfAco+6Q5OUjrXw187krWGcSHdC5naHPllsS3imBzB1SmAHlPUtssmPlxBzp/fy4HaR8fJigXOc4BAFT07bBfYQK6JGg6MegBVyEpqIOYXS5/l1/31GGl+15+JV1PklrVGCkbtAMEpzqxMhe+xMUzHRkttK6W03QPJMThekWL3kpcssGyS9BhlGQr0FmbGuiIOo13xkSvH7l7MSeRSFNziFclifaOXo6IID+XIXJ5QHsfGiIog0PBikWRyrJVRo+IlEt4MhfxGx3oGik6M8amfGxmhJEQ90dwaWsP0bzCjA+S8PTYG7r4hjBE4RCRpenc8Vyg2CsAfia8KntYeoRKSbR60+CsMBj+nkkHPt5yRyb8+5wQsevywARGtwum9GeL2ZSD3esRY3dqdOUQHZ8lt3gCrWdJTeF2XIZ9rJt5Ny5hLnleU6m5Bjs/PfrIvRO9UjLIA4Y9HTqLbFjat3L7rrkrzEtaLeQADIBJEuqGPCG9jSJfHXbQMsngHvdrd0wV/yQIzK8PIWEVn/tOk2EnRlS1MHq8AeKH8+6T/CeauxdTZvwHI9bubTH8wuV+7z+VsvqFKeetEaBPDfhWCOHNKKJzOccBTqPrIt/rb6VG3UpmfjsZHaEtF9hIIFr4cx6RcyxpFeiFdcJpds8sLQ0VcPHX8WnO4FgUbw01qUedp5lzHvta3k926F+ADxQoK8rl4Ae7Y1QqbiW9qDNxaWWlXqRicD5pMA4i54wsYAkDFHTCc046vE5M18jb7+SG6RtxYHJubgR+Gb4jGiqz+cNWbMDBNGXnFSOWBDHqCWznW7t+ICbj6++XRouXyxftQUeYCCZtQ9JZxl9Ejpn4WKGKrTFny6LBJhpvSXCLFtku0Ts1RVXdEvJaGZp8SMrgUKjSjRhEsDOtjjJb8d1GmwUOrvTkPJQXkDoNOnBNyJ2N1zd/TLtkO3OjvMy3orKb1hT6NAgOOjYqzZ/wl5hxZsYgzM+89FL15E6wnikvogBPO+pt2GB0aVg0k70BjS1oAqeQhFzueSI5CbHUhlOYt7C/Pf/CLkb2S9tz9aRZrP3YyIjSVaXRDBeCtEZ5by3mpMPcqGTpRVUCmsLjAVojj6Kge9YmAZhOMA7NQ55sL7dgsAH7kCM9H7sR6LuhRWO/duJxjobrut9ak3gu82VsChTWG/2VD3hYzPtgbCCTQU8nMQxG+L7uyFLTb1qHtwAZdXfL98pOHz+hXCnAj3iRCr1kP7sxE8gtspaMifyi0EK2dMMv30IQKebH2WbulUKppOwhZA5Chc0JZgzU3/wg5wEkevDfqgKdoHNdq/auAFE3Xf6vBr6OIhwQtXkOotrSHaFKUBKVdR3BOXud/1RDN94LTWO39jDjiZkData+wNmBcV/RPRxIaBy9HnVYwdy5zjUAYi5jpRYvOTdbEJxixvzjjEyBj7Em2RrYCWqJFcD7q7uDgSeTVQDnu2VeEm0sfJNOwdTIQy4w41qIeHZgaEQFTWlhYsjbtxIFgyNUsQailJ90zxL/UNSwLU7HkkGtvW1WU+P5G2uvf4J44UCe13kmfCxPnwZRRtUPL6qYmZ7ouoE+fcheb8A1iOcWA+KZO/4V0DOCT2r67ZnItl3FUR73JdZECfC0Wbz+x+FQfbPFWpcwovURbXBQcvxAb7hViRh9wCxQtoSZNnKcq5DOvyc3EF13gfyVh2San7tFL2cfsLmB0z6N701yDzM7dCV6U+Dcu2Aq8omMKJYwsP764ll3FH6t/gGZmdfk2WaQfOLQRR7EPZFohfEgEtXNCo0389kkrxRsymeKFqMrwWAsgWOnGgfOKQQTCTqHT3OA5E92HyEaZsf9iTnuTIz5mWTbopMmGVCVTC4Q/Sv4DS908zvmnoD3XXjdlwAXiJIKCxidx+dqSW89VNYu2so51499UgntQev0SPCE6G48sAUVM07pLIrTLmg6r0OxmO6BoMJVUJkEiqrnmUt5Rizs5lrzt966V0NoLkLB6o3i8D+qSdi6r2Mz0rSTOt2jQhtb4MYD6bPvuarp1H3QliyTLVMJOBGtKdI/awD8IJNAeS0gq1lDItVMyQ1KtvXYYeA5RLpqaqGPB+ghlpqIyG7zF3Z3XF1pwE957V3RrH/TyjEJSDt+vIWzFhhLhQ4bVGxsEx2TXmrQrFl45Ky7Qzm223p/9u1P/gvgEpxGi8Wol3DP4huc9gzIWEJunoaRq1nNP+/gQYNlNUQyeacKwb1xxE3SEGZ0JzSfl2Q3BYsJS4OsahqPcMeuEdH4hxiEo5DHrJmO0YWDNU6JFQzKS6QsXqF31PY7ZdMQ2AbI/FxG3Fol4wMrrAjfUOHL6fuedn8ot2xnYP45W6RREPHq5neBhbPVCL0qSVwF+zN42ghntpRVHHD+KHlsCpK95H0rZnTjbn/2wXQD/pNDmHT7CKfh4ZRWV6tgcfaLUqhsm2uCyTk+O6iykgIyG1GMTPBVi3VYwVVCITLoYyVW0lZ/9NuyJUvxlDalR/1hr0ajuezQ4YY/+Abj/ie4UVCcjqA/cOfJO4WTcTvE0ZKB+3FzNlbazVzIailqYVsozeJHhQMKPVv1rje8fTbxcXl8ky1gpZ7uv/9BXuthNcv6Ok8HxgJidKU73nNwOGO/dgLXsYudwYVjHkAARo/3eMcPNqaV2KCif8OuUbXnbg1eUJJy2PMvpwqkFDXrA1+/wLSHIiwOOzmGFO4cgqG3jP+P8A0P2xVlkrdI7wF8fipQtgzDnBwl0WZLcXyg5Jlm5KBeZD6VkFxk63ptLmfF9/MdReHfGVZ1u1ANvdf32+T/9ThEulnl6+pfHvMPW3C00O6RcghGkQjfE2s4JtppGGk3X/isi00n17uM0qEB3vqlQLrTkh/74wUybJW7VXtcF2d53Xxn28e3zJCbuQHF0mtfUlGI4iv7vPK4aXog95VsTbmUPFvEioKKJ7gZAMnWt7cENF6EkAPNqz7rTyPl4+bF+4drPKFHeoGxbt/ACtVLEF5xpqoZibLeFkFjpSNqb49zC8plQvTpon6qStB4VUqglbefICBAXb0y3Q4xxUHzmnBIw/hncL+mENj3KH80TYYUukgLAdlKkuGvVkYZuyUEkPojw0fFRTzgBGibA+Ab6pfb8FnLDdzU90+WBY48SH6+TS8+yvmaR8PPzZOD0u+aDIQf+cpAEyb+/9ZYCPx2RSSXVaz8Sx9Xhx2WLCChmrTlScyGuChl57/WXn7W4ryffsTEffQbSbhmVxmmrRcnPItyScJJ18jVLxPVsC0WKJBUXGygOSeyZBz0HJUpc2xrMRx1Wm7ThICVTZkGA052CYbBObzAcX0FDuYTWaeM9r14yrsn0N+zLGlDDNvksD38dDVySPKXKMDDlkzNo3nYsYX0/Ms/UwFWI3wTh1++htuenVvinR9G84lyb92PpYnJqO60XY3dO0RmaKKPrFfvX/9lWaxGXWIkFxfcvAXaxt53yU9Rc4ygxLrF9aETXCPLzKhBBmsOGt4sJjqUL3pQwZ/pcIV7OYCYVWgLQyB+9QAfnGFGjmD8kwnee2kfwsUFW5MA/4UKeuga/TK9qAkEDTujEJdRRpUpdwP1/dL+9HNGSra2n2KfSwOFb8rYMKb3xcp0vSeFLCcGfi3EtDE95Su7ri40mZPVvCStUIuu2zsnO879VqQPaP6vIs/HPwNtha3yRf7afVwC3YAiD7kCcrvDDc70RPkWQe4+ipPwmd9kvz2nQM1f3CADqBOtLxmBgLPgu9fJYWwLKjZ6EtumvYUxH4YuPrdTCzE9FU7zEi8jGVkyxT8NyG48kCNOJ3NI+C7zr291n2G5qf1wNa415WnIkAoBoq0g6D0oZid4YPoK/12jZX4lxGYoNUPCntqdbkBj6qjuAXd0zZqeKcnbQPtnJdBQ+VfExLKNWlMugJ12Ze0GTfa383YGqcYTGzUblpg6cOmhuI5JD05hRGUpH6guUzHgYJX50+jmrQewjbcSnlyJYs54ZG0PQwvbGJdCvbuKb0g20uhWAAmgI2isXkUOA331cB/0h1L3F4RLEnK8+KIot+vpxPC6cLzT0ImuOineMLlaAz6rKOyR+vZecEk3xWxokIfyoY5UZjwBsaMj6zEK3Co5TXDQ7XgfK1Q1L6cda928VwwGr0585VKWvEHWPJG9iIYgEbXRLVlnaelb/2ij64ogNM6YT5meNn95CHFBUqoaDl5Vk1eZMGID6TvUUILEcMhYv52FPlNTn63+Qf7cmgsJjjmr7bOY9dlQytk/p1x6g5GIFFGqky4nVXeCu2oGW0nV930O1s5iaOkArGs4mBVJM9u0hrFWF888HbxT62aRPfwizuQq/U/RgLwf4brTQ/MTepUkY3tGquRtNviuM59ylDSzf0ZgOjKc7dybhzpQM050KcmCMh2fGwcgkjLGRxAmsQsZT477wS5Z6EfRhuwdlJ5RnPp9LXNzbkqXF/qo7x/GRpLr6USPTe62aGBdBF7bBhKykQMT1coewgUaSFWLgyYvX9N9X0na/Bs6iGeEjFO/fjVMoiEVycZtxAzWzwIowRbXxuZz/MV2j2z2nyHvQtQdaqgQUIhfuVMy5XwVifQ3AwG1+QHWMptE63usay+KiIlSsPZ/yREPKCjnjS7eNTe68G5w+ZanEPdX696j7eBZYFngQm+PUS68a2ZkT833JV/43TzG8oPUldCE24YhbDDHWT9BN5YDC0l1MMmixNTPnlaSYBu8PTaWQeJFvKifOu4s2pE4YZMUeXEC/GbSMwV5C3RHPM1KKlFPuPsIB6TXoPf3KHkYqR8iCW1Dnu7Bd2+rJECAVgU6ziEBQ7ftSCIOp4ulEAXP91nyLgzrHtCwhTuB3Aqb8pA+qTCUmGlXTGz/EozIuI/OFkVYxzu5xtuAFtm0maoS2aU67tGAFPBjWcg7gsET8FY88c2cWQuJ+kLLw0wPeJFlLdP1eAOrRTjhg35AF6ehS+6wB5zmraLqhl4Di7X4fNLo8SykS1ePvqsGT0MSEcA7r8yA04xdvmz7ivptzKm6rRp7xPjouAIg2c/IcnHcotv8dDFAkNVYvRdDe8eDAdUajHX4o+kS+BYWuaxG4JGpVwdKUmH8IltlUd0Wd6p7hoEo14lN+k5FafuJ7yFb4ugrodAaL7oiumyL79WBatfSbgb6mHx5CO6KnOo+55FdF9GJ+X7TmvVRQpBrBnwQuysco7HEQqzcEpt9aINQF96Ai4o2hElFnkVwkEcxknynTqUANenUmeyKBDgJHrf+V+UULhqW5kXpYx189szGmdmBe/2maqo/aCaYkAZwzf+fiqGdDZYgmBF4HDAWRFr6YWoYhsHaPDsd3VO/bbfaaV8CL1LHTnAqUzw7j5GXyXwPTDjC0+/GjnywYlZVO9lip14VRAoetT5gwa5hjde8h7/iZkxaDMtXyjbcjPypZRWpRe6Cawf+5ril2kggBrLItShit0bPyFwHUkP+zTn0f5Vuw37eNIeEteTPmu8r/TjkQHdGE0jimrNmq9d6Ku4wgC18B+zNFeEbT9Q+Yvc5d/QqaMuV98ne/tFoe/vI3g1mXq9zSYFszfeooEpcOcgnhkdiZmDj+hneeyzVuDjKLCdbJZz8xJV8a8nRGjMGYQr3oKiqC36iU274GFcVWQ6XsBMOhkwg37LVvI0/GEcHpT43QqDp8k3gi/d/vSnxzuHHEB7XB30w/xK8QoH272P/9zi/dFihdlupdSECeeUR0BYVtavcl5bvTwDTWesM+IFMqUTa/+otO21zVjkW6dplE33GQWq8nZE7Y/Hj+70sn75D5QFDSjG8/JovtxKe+fjVMwl3MYtfRoYnLT7ZCOJyx0DHTv/L3nB60CM6BClLs5Qa0qNOiVayZy8ZpNyi2i96dPoObrXKh+NVaY53+tpa7L1/jPnk44uZq0zFbbCLoFm/wYKbXfgmYV6C8HDtIXvrJZsEltIGVKiWaHd/vJNdojcWHIClOqfWC111f+HYzdmmyQiVbRzfNS/sbf0gcjbhpUzEzihtJs7Ek5jap66rj8H/hc6+XBRuFT6OoYFd/LclqAdCTm0gUzC4HM9uvyv5lbsm1iX283B0GVm0kg6k0YT1XmlLzDywA5ttaG1dKF+cXB+8irdMol7VUJQ5KxkGwvjwq77i+QudMsYaF0EWOl48XDFN+g2esN1Ec/W6OmL/phx7JmwzXflZSv3ON4EflZPwBrhvcGyZEiWKvXfuE4MMPkiCw3qpvNjzX/L6GnhlsgZ2u0Gv9F/QAEyq9pzhFBwW2wUg+Y3Oc5b3G+T8p6pBTJn9X8mVVFe+uTd6ujdqHLJOqGxDUkYmDY1frYs+jSYK8C52dzP6V7+A7VHx1sGCaPxEGXWfsW9zDYRNNLlz/4kgkPUNW4o+2gFZEdnhoLDTn6aLrCmPUe1Hj3PdXjtdeTQy0+Zs+PpYbSXmnWXO8EJ/1kAJNOTreD6ERaOaiNb6tWqzEmGc+Z99jh1SwwcKjYZpv69Vlf8biFhNFBImyyFouPnL5mzHN76quErS5RutiUTiQsPvUaNubTHaChM6ybIrkvAzIsMhe++2rPkXBL3DNaa/UkxOZLgAhrG6fO7ZqaLRajwyBWdPvtoQ4epwX9f3et2gs0Q5auPwq/Sy9Y9wta933bpBQLBEbS9zD24iYdP7SRB6ABiPPBIOU3lYhcsWo+Hsstd8Pz5VqGX4dq3ytebIls27rIrzmhQr8HxHr/I+7cC+7hsr3lje+DLi9OPt/Xllwhk+HVS3J1rhU4DMkVrntAmU7wrrSEIgiXX0cHLB4FO6IlWe15wvrKNouUkAi2TxLeGp0ZtUn3MYUSZ/feZqqv+ArTV4VSndNs+jRnvO+Bmg7eYda0glbOGG2iAgmpOqg/ffLFZ09kkUNSZ+jKFXz7LMovdVq2rGnjeKQ8py7bqs+07YL/Nn1fgoQVUk4HsN+sUweFNlB6GL5FnpUSTIQW+pZKVBKUrQmu4WRqt+9EhlG3t2NTqqegPS6S2Yt3S6qlazIjyXjdQDiJoAHEnc/ICVtGtHto3cTqMOq+czC9KpMewCM0g0mleLuewLmxBFQjy3dQ1EYaMqTvQwMidhcxWr9QG2pExMV9vDVCUPhzVt7dfsxmbmXzqSO3fPovqddbpE1O9pl130Hmu55lYJuqXevTYQUj73J0fxG2JD4pHJGuHfpAY+loDbs9Fs/PKmgjFI+KbVBW5XhRGEHc33dbHMisvG9y2jvTVZKS9SDrLr/kuzoWi+2JWRYjUlIolo8QGQANNgin0n66+E65f2hPeuuSPc3iJV76JSc/qciV3Bm3UzeKsu9EqPP3MLgV52aNvBduIk225gwT87IWH52mtn2771K7oTqViQ9UxdNt6rhGOx2agL7IFkJT2tU3B0r19QsfQ315tiJHDXyN5DXCYEA159jp9MD9yQB26bcy/8kZWM35hsjMlnJ6ZtYY5vSyPuLK41Zth8KvvdE4hMApeGAPYYMdOHfVjfrxZULnaE3cmXtHjR2a14X4cO6UsnTda1p25dzufSMM/qUkjqECT2qOOE7VMwi/jG1/PKsBcX8GG7wqpbpIBX/gVJF6FdKkJgEAiyc3hzQnx4GiJc7neHDT50fsVxwSlGUB0IDPwEzZCfhIid5erKxTiyWv3Gf3NAasR4rEPuZ9XOhomgTXT5j4CR7OhZnZgWyQprbSJG9Ty+UvtmYJCijpMjB/civi4X2VnR4c0kNF8BZV16VjMuLOvjGrh/RCN/r3EUb7lIhxD2/vnMo3GawShNf85vqxkaINytaplWyG2VGa6kaPhuBrp7CBUBK+7inPO2WsWxa14U+djjIAAm9+d0g3SItud/7gmhZrR853f+/lTdcY+eSwKQdXUXBKu1s4fL4Y7xoWwvh/CB2oQG5E1CORoLY+8w1vwWHR/8+2HettHxEbSDZfnmKbjz9LP7GDZrCjRw9uncuEL0ocdmTxfOKuqomsvncuTvxn1yi/oHgqUAR9S30MUJaDnyHIb29OfN3AYjZ8E1UtqPSNc3ibubr21e7A2ec/kE4dcAWG4JSEGnuy0xOL1L2DMJUIE4ZteSewAxWH4tW8x07EvMrQsXusZw9xm6WcUxFL5tuL+21O7ifcUPXvGls2Ff2poRfFJH1tqlTwEvUo0Pjk2ivdnNlW3irhPO4+cV0MF6LLxPwdsfotNSxvWS+BgjjG55TQaFXlXwf7DwuQcABnt1XxZyDsWZPI1YIa7T7Qw/u6gUZytGq0fmMueKN703qBRhN7PBXXDPxKQk3phkq8oySm62m9qEEzoiU73NEvMjTGYQEgkIljmLu0BSCHkdr/c6QWX5cKIcgkA4x4Zw26vnECtj5RVQgczfYgA7D5DsrGohQ4KwZwAL3ar/mdyYNZEAnTBGbRQ3x6+30VGl0gR6ISqeIQiX1PSb5r7H4BKwYoeYbCYiwZOWF1pRxkiCPvsxKIKxy+g6C9v35ghq8+z6MCssjpvQsUnDtE23QbyrJxUD1MgeZUF06/Q7dlh5xn/QbYOXYc7lp4bDn8HtT33mEkSJl9+/uAzI/Z7HZp1HRnFNtew7zhQ8diA4/RNQOUa7rR67wkqSkEF/Dl1DIcFqNm51vF5Qummmir2dsBFsG+Caj+QAVzCsSl3AAsITWIU3SMKSuaz1XFYywry/TVrDDCAWZgAqC/hvXf+TZWIIwvfMk00QL/EcDv4+flkag39gA3J/ohKOLJXmO6pMBBKB9RA000ukibpt3e8Y6dPuxpBS6HAnxM4UyqElgZyAGLEwwibsqBZXRjPT2k5Phq8A3ess6oRKcLYXWG8v1ayFlo2KTrgomlbt5cuogSs/mJMCufUXBQOVnXdgEhQLk/gWa4uz8mCJUyhEuNAgozg5SNs0RJPXJjJxv4aCiWA5w4/Hjm5KSORBwgqtZtk9eW/mJYVb/eNpI+iBzWSXmrIgoI8AareorY+2QEP4yFXnoAhECaLdyxEaLHNEQaWdBvr4tQNX0IgDYL4kMA2I5UxhCZoz3ygqUCIDm3/ZVu9qUOvnq8e17e1hR/z2TC4H8uFyzDQxtDj90kO7pYc7/F5NyMDtd/0JcN+SRGCub8i3gmJJiD5JveAdYhB1f1oIpiwwUgp5RDhlab+fHQUnJpQcCFuXXEOX1hhRNuFf90wibTru0c4q++uKcFW6kRB+4BtWvvjOMUIsEosjc1x/Lqq4fsI++sQcWW5vf3b9Y2mC57HT0pg/kTCQ4Ygv2uMH/Su83GktsaQTJnwuwLnzlNrndDgtyE+IKyrk9zyY7vqwZB2cV5jMMWn3d8+T9xPWZfeYw/7Z/9xaafZp81GCq22bYxsJnWuP7rW7tchj1bab4rBvXSWfJk4kiUNaIQQu9mNe1CZ42fxtMy10GPGFjkDIdbNdClo4sAc3s1xlWyXt7prL+o5Eq3v6c8QAABKULu9WI2S8uB3gROKe2xXjwANktSyZYffD3pUkbxvXNZgcQEZwXa92HkphKNcbHQRz16P6xjYPx7kKlKY18csWH1BRk0fPGanGKYAd0ehTQTxJqwTPY8Y9m0Xh5Bxbgt6cmUquWWoZ9yu2dryo63KZMMqDi4WTMbd/N98ZPJs36tA1KTB/R+cvX0MU8bwJ6ucEhjSXAZR77iSkTgNB5qLM7B2KUmn7vXZSYCPGE6Cj7RqBO2qqKL4STU8YhDX354hNdcpHmSybrIzY0qqHNcCeCD19w+qMVyeefQYUxVGD+b0zsxOQGDDWB4Ue5bSJ7ETWUdZ94U9dgi/3VGTVERLsoUrjOE5Vo9UkqA9BpAzBwAlaFnzFl7AswV71m+SwT8dFdP1vnlyWYy2m9BGuLBIzZ4pssM6f/XwGriF7MlSieNfgCFi35chHq5BnPjpcvm4zrqamQE/Jo7cASGNro5KQeSO6JvH0DoY0755M8uIZ8vLSA2xNaP5Sn7kYkcnaDve82XYGuIRpaHf0CDPwIvmjMbjkcivD1ruBvE20VROcNjZXXiAh+OjTCKyY5E+JLCIqhSx8rIitJfIbTPbgCtvmf2aT4a166Mj8b70DFqCRfp4k/5Z6MPm75enEVq4WLlF8M8yJ8qNGB4yBc4twjwKqg4Acg93I4SHnRKW2lJjzk2lXDIBloOl65G6WbQKGEGULHEa97v3i+pUawI9DCLcMU5g4mY+jvfIsHH8yrr6HCqpCEjdCtOFESUVVEdh8pMnR+p4AB4iFWtcyv3L9c9N23CD7VNHb7vIlhyw2mspZt8QFbcF4s3PLs78/zbaQg1oSjKsI3TOLYTOutSJKNNNlBcYyuFWavDG6QGYR7Pn4cOYnfKdyftWukPWjuSrFNTNIkG2hwzOWfT0yZbUh0otsGi8ig8QS12bc42j6CKs73UykBApLS/bhATBZaFZ3qUUsSZnzHPlPto1ZhV82kjSdVQUFMQwjohSAzladOUwdBBp6sCf1C9tHr8uKpTwdvhMlZ//R31Qhd6UjiELJr0vJXVu3fDsgkxn7BF8J8zBl/sUirqkdwBP1mbkXW3WwSfSpmQXKee69CXGjiwi15tDjFqD1ZRUqrXn+S3tnHozOyp+gDIQ5IDZE3g06XRWrrnQIMGVKT1sKyPjB0hYUNNjwH2gpYIlHVR8QGewb3pb2Hkq7pl+PuCm7r00Ic1GNTUm2aHZXoFaeXOR5khjfbCYptKxQGpMn4cOLQAe4cjrL2iE8ibqd2lwjwSYVy06dmshhiG4CG5GlKLaRGNqSYYldZFHHjsqfy/ebxz4NptAYQZ3xfbho1vNPr3CjZif1rWdNhx7VvRuhKr6b91xh7a1LFs0q5Muw272b00pwdhsbO+TMW0qJm8olKqOdN+A8fTWoml57BQxowx6OU44o+GkMKjkTJpgpQv0tq3aANoatIQx0myfQ6Zbh09tF9QJFxqWKCt6ws7YXsdpBJZ+6gsHwi/Yf8hWlUn1QkafFkyN2voz1psunS9/RNEKZniY3oOXjM+laJXKRIfyeW9CQJsZWHozv/b9CRCUdZ+v/iC/xjb0ggvhiU1T2KuVhMmjrwJiPEN7gmvoVIfXIdnYVT/HXUVGN9kLCpaFvs/QbLJ4n7LsxfW8YJIJKSZJujwK03sqNcKK5E1hWURfnPjKmnQK6oakLMo9JY5Q7lypOnCKNL7nxok6IlOFO0hNtT1HQ7/4R8+NOnASYqkzNyF7naQnEZd3C675zubk5YibAzZ7+Refzjrh6En71g6JUfTmcH0+oKqloXbJ3gqiSmGqNKTaT03FeBGClqDcRbfaEmPV15LpvVDVmfaHDzNilQNp0jy46Yb69ycYmKZqtz/4MEX530Nmki5h2BAHO3W2LiBuM55rte1/itrkBwrtt/31IKep+tE3+SBNfVSQdzelclUkAhz7unW+bSk+tGErkNMYYT0+FAbL+dbsHSY0kEG1F62/A098fti2rV/kSgCG7PcG4YcBbHL9GStTTjVuy/CEboaF1loNgU/aFwhMeiQeE5Xe6z4WrADtCWUzsY2tYeXCV7LXqPm3hKsEOb0D0dHRxlx2EUw2SrtcPwRcwbBp36zT3sv2pNVObVsrPx7IlbCzWUIfqStl+9Gcu3B9wzWqDuu9CMxmvYbyBOWYIfMG+x4kcM934nQtbxv8bLNwXeF6UURayxNsoAjIJWuk3/UwGLuQ5rKS5sBNsMh8nhlEB5YEtUNVjxmpIYcb/HKVRV3VNbwNuJvzJhyoeeTUp2O4ZV+pkwtF9IcK/8fSVREbAHM4LiCTJyR0iYDoU6k7FjCcc5W8LelI8xxvljBhVBeQ81IkHO9ofhxplIrLBfYGcOPoKCvaZvWHGSkYt+RuIW/VshqI/A+lZ0/disvRydAbiz9AtlxyNhE8h/9Vytwr8/p8iN+ha4z9FBEBpxhI+tlcHqTdZWKTz9Kx1PZWLpAGjsh2Vzfyc1pGTX4gIB+xICgNifGDoXYTWWy3fDnm5jPRG69N9ER1q0aAmsDCjJh5R+igidDUIC+MDVVFGdAo64zGJNSff5VZ5Rua4x+pB28NfBUs4hjybZEGnFmXXHNscEDeFYkH4IgwwyhEmHFj9cORrpctvy/MBMm3gHlfmi0BaZ9TrTMBrc5HY6JnnT+bUVsRd4ewhzLGb2ZkNYWSQTflqdtOLyzRsgFQkBpgsIkFP42zUb8cqe7AVT4hdlN3PF+wsIl6s17HgVvVxD5xBoV3qp/UThlN4CAqxBh/LWmilDxRvYXK1CL4nRwx0kEj08CVecfAmImA54wcqObBw+KxfshxgJQ8ZJeVxaUIDqlbh8FQipQGIgMjmAkvSm1ifRxbuODT2aBWDxUKyBRro3QLixZbkrasM/qd9hKbcnJzk/zf8qvYoFjjRwfnw9Hgv3a7JYu9u2p/9DhV2U8rsOBinzM9esXxpamMhu7d5ET7j4Aa0G/SchRn7o/Rv1o/HlJQGjE45yikwuFOmdUmkLMTpGOi153iM/sncQW2aIZxS2hCuerltGAcJssvfHVFoPJwKJlVfdzqHnIe4mERC1yBfu12w+swoEVEH6G9kGzZRC/fm0b7/Q6gnpBXTpLBcNiWwM7jSAZL709SzYdTUrwyYRgQUHMxRCbigSa8fWXCfdQ3PTBLKnAPmOqKdCSp3u9Cfc3j37kem8W3QCcwMZWJRRnllLEudRywa69AaZgLoGTb7p1HGMl0ifVrYre2XZ6yG85pmXZaRHZDkezASDQEC2JBZ7y5D2Y6GsCSoMAEBWcRCxju899j+hB8Mf75U7V2id8O4Fn9xUcjNMQlHyic7DWSugACWV/3SENrtWTJxl787b4jWi/5spxsdpwXkgmWdAsUeU7CRLV6i8qzBD7xkDmByBvb7U6JXZAHOJWRqfJCbBzyzu27+Jk1CtuIy1+byugy38nljDFz5LBSRgbEYxZCv84FuglKhSgx16PwDE017mrr8Jq/L8uL+XVt3hcUo+HDLtOyBILJ8gGIZmZUO25enkZb/jVxWFfbd8rCRVJdcinIEduAFpjgGgL7NlyXerjmuOBnrQObglyvc+8S/l/DMpaoC3axkdCK/7Ow3m4P1FXu9b21AW/gkZNM95OR9tiPG6qOfPHBPuw0+mO1jd+xhLOvfX2oYJv0zpoilo8iRy5S5cDRFdTFLQpHjR8sFWuVdcYApqbgJnqNShKTmS+mnPfpe2JIT/EOesGUyuQmsuj/cDFg2050QBhNtKAjPMiPT3h2A2BmU8PwM+SOAfYtA1eGVPmIj5t7npIoYNNOdsYQrPml6nrMefEjJQ+K8dB/5ZbUOUXwsyBNCsQs6i6KCzq502yu92xAQJGRP1moiHBa4K4pDxeqhVQSDkScNu7asnrsFgbTFWXUCG/B6ORZURgDl3RErNm4kt4qphkxArEFeThwfDebK9REAQa5tmluNXl6IY81pdujn07bErTnhJkgH2lQHE+pWbYkE0q/Ng2SOqEexKW5LYdTjpkOGPD3X8ox3v/AE4EBy9qtMCQPBhC/gg5owV14rRI252O236oFOOdcvpSs34GQNIsfL/AHV5WhsaXiPFa+Uwvr8AUO+XgWS+YuNQi3vcnBzv6rfNL8RYdRRR5D6dN3ajElY3MJ7gsp2VdFoUtq9Le0JCGjXAyFNE2EKddNSUNEE7PjShGhCi8DYDEmuiQJrgEXx2NV+tnIfB1tLr0HrrQ/Ykd5xxPXR7wJ3A911pW/npoD6vk8w03xsgzpu7YzmsWACXj2M6CBZHQP6IS6uO9nCUMbbcMrgH0jxNexINmpNHLTfxbX9PySH/8SJ/eN3SNnmvylgiKeZBUVVGBs6k22yc/PqYd2y6iKgsPJ2NrWkanD+ZN0FNbNxZHpB3j4ylORBZSebq4r3ze9ZzlzSzvENY+t6h7DmU7grmladiIeiOExSwxbRbRZmzzgmnNF2bZScJ0bfCz9VnHqX1WcBJrOYdQ5ZdGuk279kAR3p8NK990m2MfByrA2WcxNf03EvUc0h+8RuQm/gCXWBwSjCuISO2FBJHrZgGTRoIpfhKV8SkzdTZamCylOq5ziO/LdbD3hvtNt3bbPbezk3aJDPWeLI0Sd/HugBCFqIZCCkFou4ZQyWLOYqdGUsuyXCG3mXfLbZD92UnIrdlxf2gO+DB+aa90tfzDU9euDvbDDlnvgdTqYp2pJhTD/IsksgBW5JAVGnGO4i4l9eNfn1cUV9q8wygmtA+lZPmgL7qU0dmrODmaENka84RFDPNDU9wwsuzTIOKT3VDGxPJjuWufeOght52sDxk34RB3WjBpn7qPi0+q3aHT5zu7AGPqihiZjMPbWkdTGDQHUgO50uDMIco/w1YFPBuOgLXMCO2H/1XTZpLtP2m3gg6iyA2/p9jmO+n1cX5gIz/aUzIJzelT54RJIymjSooKwzZlPHATFpbFqDDFmF3lzvIj4g4nGf1E1bG0YpxjsXRvyIyKCxs3Z2ykKAq3Kbc/QNRGUDIh5vLcMsUjQX2uAsEKatSzwPbvK/X9ELVjYajLhHTTDQloCUJcAwU5i9rx5HLSxKmdlGvLmTHfYlkLSGWwBs1CUAG4KaAG5flvhEpycWLQc/em2sT+DvD+5a+XUa/qJkm8UuKSIQ+HJLTE8px/j3oWjL2H/Owd53HeOoN4xjVZupd1IC68otg+GN5Q9LL+tkCc5W8oh/5mXvm/KwvCVelNgMuqLngKNFDXK1oN1ucV7EpjfeGUgB3z/EjgHnThv84AODudUR638E7pFiEz683nEHKlggCWlvqYmwzMAAG7UUXuXU2uuIIG7fW7FGz1e2551GFCKOE0VKx+0STzZ51fN1YVQCe6PSSocFPk4IYw3qemw/uGwaOmfpQAWWUegB8SDeXjjdYMm8M0PJEkI03m2IsXH3frSy/lcQv+zasu9mFZRkPehXAHGagephzLDWj6Px3sQ/em0ET1LoBsmC716196gRA9emag6PDhhGdFdTsisaRMlMVMwUiVU8veNDbNJ7eiOfw3G4ZjyL5ywpGQCrl7zZb3wLwD2TprCZxSfTnN63XKDXocgW7RtFLmZkTJWWP7K9Rdp7uwlBTf6srNdE3Mynsyc9Yep8/e6cCGD0lVebKUNkvvll7OS+3NmoRxGuh3JHqHgaU9HG19exXHR6jsZNZeRoa8ewfNipQ6eR9hNGAqDUlgzoxKxGgL9xJsmKDsgeeNAzEWr1HGBIQDtLG4NuCan4T9ukUQkFyf6ND4fad1TFMLcwxTb/pLLAlQAe+h+j9jFPfZKv+7btZaprLfX77HIeUThJt1DpL6IlIMq9dlHAx+/mgKiPHQW1SKdvJvbHjYpM8gP7uhkYGIHlX0kbudMqJIdlUQtS4TFrTL97XDYqiCJZDrNKmvbb/x0bjAGinc1XWniwIbJY6Rz97DAvZHXFyWarZLNC5mr6bD645XABGXZy4Q2GmwdTcLSQryDVOANKcuuEj7zKHhlK7by05p1psgmvPQde6Vzae6VtKDnS5qwggiabwIPiYqVtI3m2L0+yRwyKYImCLsb5ENMxE3z6yJi/TuOw+10lrxQG+vsW26T2MrTg2WPIhiGpBqVS3MlfzAKySZxaARdHsPi/yk5sdXywARBFA13YiHxyztvw32heMkWdN8fjmOKFKQloM7mq6IcX4RNjEcIDjy9SJfdbwZ9+Ct9uQzzQqHb8e7aEPnuy1+7mDt3BopSU/YnZdlQIwW4dcj6C20RytGC2Ku3/Vgdu0cbH5zF5DwuRz4VlDMPrza2JPy+CL9A81dGIlNwhNjbbNrZtd2o852cvp8kJWSxo4qa5XYugACAWpPdfn9vUkQUWEbQGPJcnIgDHcHfgADLLBacvlJ5mwLWENsfajSXPxM1OSsw29FS1beAPn23LqP0ZnQr5+ZTk5dcKAFGa6zY3WqRuMUIq37GREH5uFGPEkDa+7ZSb0BfBJ49VoASad5alMDjzbW3bHjT3J4mphub7SDsifl/u3rMaAqEbx0pM+xnnquKba9XRPNbIFVifb+g8fi/ovfxMbLJjcb7LNU9znf6wQOLOfapJkfgsFhloqPYihu7hLvLok4kU5nfpmADvrlB7LUEgZ4zDnnzhBBaE409mpXGw1EVwGSFCZtUwIUXz9F/pORQpgeqL9HPgDqAN2JsUXyWfuGmiRH8TFebv/7wlMg9z3TyFMwRhrBnBRET/lRVt9zdPLzNg34qSqBu+NEvIwjmEOMJCAIuhkEwDFTl9Wui5U3NicAAAAAAAA",
	sniper: "data:image/webp;base64,UklGRiowAABXRUJQVlA4IB4wAAAQiwCdASrIAN0APlkkjkSjoiEX3CZQOAWEtDJfXizflrxovmAWIgywaPI7pD/p/7x6L3IfZf7l+1fbx7u+yvq/yqeff/J/jvbf/r/VF/Zv9R7A37Jeel6rP8B/zvUL+z37Ve7V/xf3O91f9v9RH+zf6T1r/Vb/yf/g9hL9t/Tp/dj4a/7l/3fTB//+pSzB+RH5vwn8TnqP9w/w/+6/v3tlf2PjQ6o/4HoV/JPt/+g/vH+L/Xz51fyP/W/v3jL8Sf777kvkF/J/6H/nv7j+7vBdbh/nf+r6gvtV9a/5f9//Kb0sv+L/K+pX1q/7HuAf0D+kf8P1u/2fhlffv937AX9C/wv/h/yfu3f3X/z/1X5re5L6j/93+n/0nyH/z7+5/9f/Edrj96vaWTYHVy7eU3rHvl9ei2Uil3yFfIVOynVC9mQWWXPcmQclOj9dkvqpkaheKVl6E88t3PR3tf9SOGAm+UTHK/vdhp/m3yr04A30jG4n9+aUvH296Bk1tYBsCloqiMd7Fuz03po96f31QxQaN8w3uAEk154p8drrDdZLY+F3l9woEJSGfuOlaj4k8P/qXjmJTBC0qkaSpW2x8J1lp1gK14YPS+6qyAOEs4sSJcNJOQZQXcg8Sf4C83E32yFrU4KsChOzs8FlhYuceI1FauONrw4qesNTRyIamhnb8eyog91yERzrIF9BMaaJGSL7hQAysg1FLq6vJXkCmv6Lh4W+0+2vzMw23iG/3w+PVoniTteCWmpPXiq1HqUz7Nll1EQQvJI+/oS/xd1JWBIo9simaJuGy5I/f09EHZbelxIDJF1QJEYxb34nVWaWfWSXc/BiLT7xaK4NEsid39g16Jgwy3mqdMDe1TAGvGkFSBQfakmCcQuROb92kYLFuT4ScDeCYtR0WAZeG7ywwoeTefqK9DFV+VEn7vnIas85iZ9RE8RQbMbt8BUqlRlJY+jSlgTeEHyvS6cUIEV19p9EU7Enia9F1qjkYHbxAtMxYKucrQ1mflfrp/K4rKsmUjBcJk5n2tthT7D0G7mzrJ9zhHSUs/MiYkIUlKaxcPBEjVQS0B1kjaVboGOvmIRvgLGIziPmI9L1xzW//LCQfgfhCq0rXz5Bb7+shJ6JtVc0kiBGkKIx6GHqbB0Wvx5bSfWGtOn2MJEzONN0zA+tzyq96SbuBepWhy5ASQg5yntolAL/NMBnxoZMkDRkJRjSilio0vY9r8ZLofaZNmhXEZSeIegkID0T+RGQqXZNo6s9kXw/aSjIXUqNPYyVu2m+yrnwc8IR3svcHkJsLm4yukrWC/hHNPxlKiXJd7GPWQNbqVQWDC5y3BC/lDkRVshDpfveTt25dsT0rXfDdGXHOtyaqg+JXGJSca9wfx9ch06FIybmyDCvEiTJCq756+TY+DhAww5+Qu87NJXeM+EEAlVZN4BC0TSwNxxvSDCrvllaM/kbbU4/nWfR7HK+Uw2n6/AjX4MYrpPyJgb6Q5f4o2fzUAD++ao6wsVGpLwhjgubZqUk/Ibq5ETH/NTHzQmNxK5PqzPLv6op2ESWZKPs/YFMp03NzsLyw03zNp+9bS/+s/YsVvR9HQ/FvjVDsKKcM8REVd4mCzXal3MUx3ikeRE5y173Cf2ZtUSDUDa1C7oAa/tKpJ4odMnf+k7Xixn64gL3hFIVndcIwd2+C820i6TZc2XrnIANjSV87gdcWB9j0TThh1dKjIQX2uT5oy82Zyh2dueinNHlm3gX04vkSw6MK5xcAZukeKbUV87Mp+tf8pZ2AIh2Wti0bscn9JgVnuOLgJ4egLP8Rw5NVwFMoGtvjyTzPQ6bI7QHW/MvVc8xusCA8dM7XdyW4d3ZJ6z5vbTyd9chu5tanfUFAOJp9PApPjykpQuU6rRlAuZS6O/FJEa6J8S57w0fXb8+UwesfIaTPkIOSEKwNSVWVt0/z7R53HYbaVDTbnvwFPB5FyyearXMTVFgQPy3tPCO25uIxRWX452qtkxAmOblChiCtmN1pYX1Gy9gi7C+K9c+7h6h5AeF01atmyUqhjf24BZJ3xApiePccTgmJiWaGfCLFKLeb8A4YAaQjipYOjb4/zRyvZRkin79oZohzxOLg6Wfqh/RupbwAKCLqxFLsAskf+n7KVf6opPExNIkPLG3Nb1CLcWeFpEhJ2ldnVRu525Zt6Df+to9p9Ya8gxlJSt51aINlxNpb/S4R/XodhsRcD9kNLMf++iXsOg6ip2zMEcgOW70XecXpUG0OVcLOfy7uLFYUQKbqP63ePwy1VZu6/liq9SlH37c9CUcFMC0DBKD+F49jl9AIOGvrkuWubT2zf9SQUX33NzZw3hAk2AwvT9CkVTl6MCssOC8lLFhn+UgJnxlP3u13YLrhF4yqx5u8r/eVaWz1fwgdc8EYDUjLxjrBh+sxw2D3lf3X2vg3kEf6fUZ7NP0UsZ/8ELJ15zJQVv8imYBAm1rPxVbVmid8caA3aufKVL14TQokNaOajnDCXvijx1ylB1gAGKY/JlFA9wF+8dJKSbeX3MlbyfkqrE3pHw51JUEP/ED2PWHEMy4b/s6FO78VUZuC40UaBMhahRKrP3vEb4ZpWBT9karJPlSE/N1Rw8fpKYNfS/Jokd4qqHZk7/0PC5dt22v4RkKjYRGFgBqebdfQcvZv2ynmwWelhUqElPk88dKcC1BhjKTnGS7ViDP6ORf5RbXXznMmntHsWJw0MYo40blQRkI1MeZtPVN6/jLSafbGjAU8glE76t6WinS5r8gGkAitwBtVI81/mmI+b6tkAX8fntoe+OYuBJ0qxVVKsnz918Vl/+YMQf2jF50THBBC+oly1ywyzB97bYUGXNu4tAtHnpRxuXS/fArozuMWK1PxAbmYTzxdbPt1l8Zv4LRjIgZr0GCyGWwFy5voV5JEgXl74PvMZecOtjmsDSTLb/zIg9I2mE2U7aJURlCtnEt4dimXLCS0PuEoEoYf6JOfVXs3gc1BrCqNPradLH6jsTQMkSnkPR8LXMQT2yUHoxIXu1qkP1Q7z64Rys8qCnvprirtYTpPAPPqvE76INEDwKCDuGLTL9x44XAm7xq27oS3W4dH7iqQFNJZZAo5Q21iLuvY+116MvjXnAn6+TW00eSQW/DRCdCnGJ5UxbDgLS51aY5S5mJrZ3JRhdWDE/IkEAaZ2GxswDZWnYgpx63AsWqhC2vQc8vdAteJjcoee1Hvxpo6euwctvv4bZqYkiuBUb8yiwzXV27cmDKpmkk+85wbbVxKJHjULZoDqZvNHGR/p/k3gkeIR2r77pQwMvllsWBdiGRUWBBNwJeYF2AnvlNWK7QrdOJXYXCLmLFDDUZuCUeOgyYi6p+19jozyYQ1qhvk4SSesQNEQIpk+BUCgx4L2y4gH3y7BWbVeIAXdBGsqUgTZD22K3t4FyIotIW4rWTWzbIPKTkwfbki9PWMBz1qjsQfXiB7SYvugut7YSVJtOs8U6aJGP8N5OIM0meDDMJDDkIjggKEmmOVgET+XsS6zmr3tPec5jemaRBrzRmisAEuhCC1+r/ntVA0eCzK3HEWjsB2BGkSq+g+1a8ohrQzawXQOm9BjhjZskKJR3I+z8TQGl9JKQh4wN+06g4EtWoPRgu1m0kSeCxSSPhgNqjgxY8YEBB0YYl//8Tff9IEQanEV7nFo6+4J7BEtqs+NbVJ13kJYTEgXmOMuPfcGpuXDT/OVwMDqp7y3kxPD0bfTfWK5jPKXTawcTnkFt8STOaWolqQtVaoglt3w/tKhILdoWZ94mYb6JMMccvM9VfLH5+vLjY0NnKAbdej1pe6YRXprB+0006HYNCbZYJz/Hb21phVpsRfRCh4IEaxbp25MF7KHkSfSgNzOC87P1lv5maz2qWlR6iBCfJqX+BTZWMoj2KcL22ECN/Grjs8RQlxhYIYFMwGAJ/773vp/DgAeFbrs5SF7xcQGZDKjrpXddzIkMfwBSVBrJ0YSmP7FOW+P8CbrTWV815uC4mqvzOPKaMaRgEbqgLupXrEk7wr3j7s9YagrNo//BXOk37uMCwUfA0JnA367j8NQNjOW2LxfGMY1XOfEuUK2X3oVTVAxQnThHJEkV7sxbypfedtDAyhiqHrPEthZDDPTMzXW9vcQvVI0REwcB/pb2jT5RicFFVY9INXkgOisow/JAY3zs9rbcS9ESSG1GSNgBB8nx9xuyrxk0YyKmPPvol2lXcefs4LG4xM3LxU4cWUrLMLbLRRDZF6VOcn14QqFLaZzrpByC2mx88bWlkSEt+aaW1vw8mqK9NXwAybNt9vgfGYczGevVaHVU/pTlyjVVMPO0CeSR0qK6YeFaCChPlSdbm1Bty2XmNKL075B2GMMKfSehBOmeOI5q9zACSt+v6U7VnDM6QRWA7CyUzdHLeBuxRkmzm8DaQmhbT+409CzMEsYuHdZS8eIRL5EHFUdjDaM5Rr7ZsU6PB9IiUJFfC7RSfXtbbm1D4WLyalkGdj06QptD0z5wkaP13qtfy6r/kz4t6WBei+LE72OgmWajjMU36FdiRLmxAt5lqKpY0NTeEbzMt0MQbVGkkf1Ff9rLeEQ/3X7EmCz369zplLCvoWI/EL2TMyq2bMDGz46OdHxtXQ2Rc2DLgL3bFdqvTBSA5MqjVtFhtY9UBTB7vdfUvgSk+jwmYfhp14+6oW8mvgCy0Cy+0v57TrHh9unnVuCGMNWu47BFVyv8ncmLxvWxoEN7/T/ViyB8zOVvc49Ch65stHzyXsMk23TelUVwNHewHQoFf5LnO1tFrvX4WCjABiLP5JMK07qKttqGJUzkEx5+OYbkrmi+XZm57obIBYA1omZETdnSLJCbaaKjGpmHnUWwm2+FSIyGOVbtVOOZNJqx4nye24JT+a8W7Hu3Utngtj298jsj6QLyNLaExvUQi829Oxn0pnObFpOoamgoaL/oYs6W+2BZMA2W6zaTvrTsJQv776T4IibtucksgNDtZotpp7hFs0jWio2f1UfqvwsvKD6Eo8LTvb3f21ScsGl8iZirJMtvr58hq1Fg4PDqK6Veem6mpi8hoSX7+EpD5cFEQYadWLU6zzKkdUiMaayVy8X3agUfynSYWsYlHpQzzvr9wNUKSDYtvVCBawJsRWeX4MNjhlLkC13V3jRJBs+wb5IEd6JCEwb2FVx4J7O30lP+cgu+DeX1QU1Tn5TzRolFTkYWPgmjTHtDo2XhJ2LfrjeuKn0ALKW7Ofsb9IEF9Sh1yfRUDZM/6fdwQ++jWvd5FwSPeI+1ZW63jevPnh6xGYnJ4EGHSotgraZz0k/Dsux82Yhd7JVnbhk6VyvXXRYR5cCkL55o+YKcj9W/wr1PmSnpYqDb8X0BlX8nkFrbjhPmK6tVoQQCwj8POHKU610HDdxLLiDzdq0MorIjz0lcEWTEuiJ+081kc6MHVO01gjUQJy+XRTGUjzBZyBT7j7MK2aK8X71d4h156e9Qq8V7H8sp9ENDF0Uv3Rfvm+Lz9BM6NdCaEu9HIoC62eJNH4kRHJ9rZsdymiqMCSReRMcmHB8ZexuyHXqNDpt3JujVdZ6CYAdM65eQllVKJB4dgEMzO13d25QOnI2PDkdmEQG875XvCd4PJbJge/JznCrTXW6Vla56ZmWp+COM3c40WrP8F/XKlDAoGV+PCNaDFT2v8GLxdBAHCnvCsrYG3ZrBv0TBUaPEXbZBRpLjBBQuAgjdVYNxH4qvFbkZrtl9m+jvQKQ/mIn3h+nHqx1H6z8o1I9/BZyfnfflU1WbWk4WcmpalRwVdtxkEnpIKSb6zSqe+KcXihUHsH7SE+kyg9nn5bLEz4GdP1/Ja1C9G04V/MUGF29maxdPgmaiJBTodvFZotSnzvTSY1Z2o+Igsi1X5FfhNuQ3eyk+hqBC106ZUD0cVOk4r2HO8qPLsJVOtS8Vrxm31Uwv6n/+NM7u8kJdPddIv4Hd4qsLl7ryZs/ndU6kNnp8a97Ef+KDtpWzOf60CtX6y3fuRqWr2yIYcNwCZ9X2jPiI/wMRcYyz9DtsnE6yxpIu6ahTDDjwGPintj7ydNGoFcSW4XZckbA05vH8JhD0EME7M1163923iL4NYHknNUweLVsj3+tHl6hAjpJoNZEG7/EfHA2sd788zdwp73gLMIT7nmxBO5Kwdev4yvCoUdWiYJghtdMh5Jdh4mNk3n/tOaSQxJIVpqh0wAhmFyrLCCS8SAbG5Q5as4RI+eHL91xejiobF6xXB5f+wekJdWrfGIS+7G1Hjp6IbL8qB2iPC4diTvDst/Ebh/QqP4f0ofT02i3xdTtww0BD9rx6lakLoPyTH6ODPM9IGTeZmSoBLk3GQQqOAGjnThSQJkv9gkGeL+N90hqYw/LD4o3y1c0suoi+HYIDvICcrvCj72ONwMmVdUo2K3koB0AN0Uf0Vjxm3/vpKJP11RXI7JQappLAwsdcvSqK+LUBp+w74mggt9KQP4Vj16SMJv3GH/vl5OrWK/OznpHSI5VAvideWC0RRnwhI+BerCha3vAZ0RZLVTJAUpJFrEwbzU8bmIX5Kj0P1OK/6bV0Ojd0+c7iPWhlRF+4yjuCRCw1XeSvgV8WnP/lmTOiKA2ab6WO0dwaAkEMzord7qiQwJl7v2AqkgSdHkrzyEFN8aH7qLdO1sfg6/KjkVlKkYnNaiPib35/bbe9RY46nq7YYVaRQ0Yu3rnCCFdTHDjKMFFHzBTshjN9o0F5OYn+0eiz3bQmnvXb1GrBytusvGFEkh+deXffGj3S4iix9S+GWpRrAVo4xwd+HCrmU+GdlWncGJ82cq636fnyisNWYCUT0wZUd+kf8+b4Eiupggcb02GGjBnxvA3nwQmORDYgR8mzb7lfkQy5os7gAJYKUptUS/iWbxm6kSQd5Wgnm3PSsnD5CFv4R1lESP1t62+Xe96Yz7RCthxSjNvR04iE+d+LjGK3Cmr+WVKT1prJwsBmr3znH+N35eaDANcCAHpAx4w3dA87+u1o2PAyg1ujKvO/7VXfpkPBoWxAy2LIdTBlqZSPf9Ky2Ap1nIxNaBLWtGWzrsxL1CwWovXKhQbFNVemf29DG9MJ7XIh4h1Xnb7ZiiGygV9hDyONxjKYhpmgKeh1pMm6byheqdn+sS+4nd3XUhSQSJd2RPKMu0+PuCa4fvOB/wTyftv3JtGerCEjzmKIHBMU64j5Hp9yWMQTG6PBY4gWw86jrL+I9gEjOwRz4kSv/1MMX7mP6opDrNFQfXJn1YcNrz8ZhWuAr9kdK+4xoWim52vhpn5BFqCutKTFq9oym9bY0A6whVe3HiVVPfAF3DvEs/USff+w6pLrGar7DoZmeuivD/mHvWxlTKEIa9kax0Lv+KK6kcbrthnywkyw8ioAH9SjVOz+Pbtv6PMsm+xISsfoNcg9KkjxAX9EqTKoUd+AdHnighcYLYSA0QRwWXZNzcP2dz4kDvZvIbgnd7B9QlGe7D00HSUvk38MyjaB4ZLH9sNCoATPcaXU52BIeDY6VXcAGvF1nYL88YTHjAYaoHglqKVJ6ACfyWBwJvJXbCKcq2xEySWtVX1qC7GOhljuCZSx1AF4XJz2wovOaAcnGOBip++x0wElqThncczykgFifpJL08l8++BLYIDbuYpByh5skayU5Dpyq2VhqLyITgv5Lh5GMZED0DqMouX+xg3DDmcWAfC/zhoLoOfi7hgq2FoS4mGqAxkjLOO+ZQZcvfxIi4dvXxQ2h+gFTHCp1YF7y59921QPYZn9uuIidh4cpfsqeqU+e6UuVSPhMJeX+EYm0KRyYFCpefae+Q/J8wsVSQotXugZ2Dx2/qRZKilRkzSPSwX6sGtwn1N5doUOPp23LpRdsRpGWXohUupqlPZyc+MTKbmuLNc+3vrkkRU8OevwcUuqshIyXHmKxPRqMRuypviQbssIFjCXLb5/I/lV5iPSlw3PaALq0GEVKk888BTnbTyCd8d47w+dqCbSqKdX5xJhjrYPVlQPhE8mj6ns9jiIw5il+dKPbT8SbymVY7t2Vu69G39myjaLYu15adnueTyDBeJOHCfqp1nUy0hU1tsfYowkWbX4YN3+oQWbqaeVXxIdnFa9yi+tMU8XJcBDGyjyoquJhIiwgjd6scC830ICNFio6eL2QmoBMHHyhj+86PPHo3GXUYu1vYidtyLavBirN8VeOmU6wGJn7HuhdQZ26+DJtXqoGpnkF4iZrWfwfXbfaHRIC5KztiN1rz2N4HrkpbMY3Xf/2VNZiQqr6Z05OGH+eVFJlhGTwc8JzWsHdx6Iy5VlJ708rWzVSgZHZicmPto4bFf8aosEDLWKlxxPMSJn+vF8lpTyl/9+DokbYzJr4CO6ykmqP8gfOtYDXm00I0Kq2f9wpKaY+1K/qGwMaJsN+Nl/JcXJjo1AZOW4o2DiBdUwhMHMQNo/dl1u/ZoHL4aia/KIUm5+i6GXyT80o6DQ1n3N/OjvsXNVkCGJumg/LvxCARgKfWdSZMlz4TXbvUTlTORaKEMYoWj6qenWlPSA6lVadtkAx3uGqGW0EJgsz+TztXCHivS2b6AAwCFQyjtLwowaly5oQjZo+q0RfEjlKYlBwjz4qBvoU6QG5BgRExTvdyogRw0zPkJNBzua/g31il9DpiNRejurhlieLyV4uBT5FwTFXPkkg3+BQsug8tbV/jj7C3XbN5NbHt+oz5CHWyACHKftbSG8drMVn2hrM8+8fMeSuxTvlIM+NeMpG55n2O5jXjZDDVbDfLkLn+MQg9oiP7V9eh5iDYHgSneAaheJwB1bZHscURVkW/5a8yEpJ8RobDEFK4RCZoTypjjEQVBB0FZBbD89OkApmVXjZhVi7iYE3QxxY4ZSZjLdp+QtD7pn1Ta05bQtQL/ovJpitUR/5Dx+xg37e1ZouF6Bf3Z8gHtsEaUFd8arAVhqYc61Daj9Um++ZDBTWMX+HmxTi+gUCVU8ro+VlCofi4VQ/ijWvcrphbf+UoF9Q6IEyYlITZ56fysygzOPu+lT4NktdYgCQlSpk3HCBFYwVmSobWPFZfZtPH8zp4ZAlrsUKCBjEfxOV+lQRhlndg9r63V/BykN2k4nWMGLozFK+z/Oi1nNhUoP16D26S1+RFWziYlbx1tHUZnxysuEk6yUoVLCmibflmsyt2kb+8xeBE9ppZkh4+NGTj49LLRwfd62cllBM1c9vJJtzGuxembWEsqTBThmJdkYVM0CA1OtXhzs/zuZ28LO9vMuJ7C8WCJdjTJx3ryRKSEKhWey0TzXFNDkyu7jRSxVO6cuDAdxOZ05ICgPeFBJTvvi4+psJqBaFbzMAyv/sxUghcl4oRgtkINkFDhqySfW8mFDifShTKHJQAiAnJ/Qw6p9ilv9g9FfdUfAj9X26UCXdwVGSA8UoR5n/XOknnm/8YsIl3qUjE6BxwTYqsuHAY/MrtA+Kxw0R2vKuzYqgsylqXDXM9KYCcZGKt0hkcDMqUWieRcXZvrSRhIXKWbrLsqD4avrQ1ztSkQgIt0pH+xZSVbmGM2l0PMP4Ji2kzzr6vvgiLye9ia9Qb1c+BmSxfK0EcB1Eh/M+SRw29bpupyS2RPid0f/HgTUxo+PtWjwhJrtCO0Awkb0gfbmDPSI9rUP2apNs7G7ZC/4wDoh3FAWlctybLVfVogJmQB4ORWTG68mVaAP0W77lb/7tw70v2p5CbGR1JLeQrkEVyJuq0HQlIWkZr3oSAyWvYZEEv/ZE60BHW/NdRiyizX5+jv/pOAE7GH/8I6WlTzt/bpV0/EtKyIadOVccBQ/KWNUQ0XuVvy8xJPCGxg69sts+eefpGh34S984rEstATQ1oqdZ8t7gfNv4+u7YiJWHoTs2mS4ec7dy+3pVlAAqdnda+GTVwOJn5GeaVhdbRvmleii8dLlzGdQdcCulqg/QiDtp24Um8lMDa4s11/1ClsBc9tKMf8woUFuTOH4vubsKCmspFwy5YXvdjtRk0iHbM2YYXUYvF67Ht1zQ++j2egiYrYiwt5kRExNtm88G6BtMDkG/x/eBxEPdT+E9pxObjhC3XAGamxXx0VMGq7dxvcSVOY1zQrQBi99TBuBwpnVdy2cITUYhzCkQJq4zGA8HHSxevljMHgLWXwboPKBYBHKPgL97a+6l9rCJ1N4Yy2lI2cyw0bxS9g3dwNLS9YmevNen16GnmqzgnDxyOg9C7/fnIb7knR07aZP9KTdwcu/VRMhaDJOTUvohp12pE+bYvGVWtbVypki+gg3p4SFhqZ9q9F/KF3nFO9GGg2YFY1PNnIf6rAYqdyfl/k12sF8cDfJgkLBY5fcJmAAKGt8pBztMjQEVKPAtK+btIjc8g7Y3KSCYwH+N2zbi7pbO6NmVx5ob5pvVlJWi5AaLnHYhVWBtOh3TVwFggyAPobew121l5nPpDxtKlKlpFAA0bdkQi742sDhbllLCmouy/otRYuFjYnmd+16WE7+40g/n2pddq1VCtokw1LR4NrZBvMTDYH++p33yFd90FbeUap/RCYh7Rg0JpXUC9fbJ2P41feZSi9/hKW6yMoOE628/TBgWYRFZPUJ1iCVCn8Pz8yneETV6GeLMXfNi8rqiwTgvzF6GSyF008L0SYM8vFWzk7UkEtRQIK0p5cZVHMhgzslXAt/w+L1cezxHZE9+rpiEaqEXZYKaDtWSN2iA2xS9hyOinT/lZzvoxhXH5fL9CDJRSj9CwYOp1LxJhipPwRb2h/EAfFkrFwhU8m+TCMVqAy1LtV21hjJX1ng1htGgZuHnw4BqNDjHE2f+S2TkEgmXQGr/Gd1zwm/nYKZzHcdMFPDU2WKtexP2rFodygt5XaDJ4L8SrR2hWq+Lc2ekUHywKH8AUgBR6XjA1kzT1Zz5vkhGMbc9OCxaIHCmaZ4BudOGFYPqdnhvSGeBwBcNkzsQzKqBzpYstxhwmhHvfBi0xdiod5NC2A0WW0SkRGeCG2RWNiXVKyvFLQEpnDPupIgRW2lAUhAJ0jQKdKSBOEwxvBWF4E2S5XS6RPLCyC6DLhZ++xU0+FPjBsCDUuNEYnhRdsXyPfe71XgNQny/xH8nMrvPyjZuB1ZqRRRU0RISpoHo5fOnhVRXyeSvJ+V8lLGKrwwzhKHqDpt2zTcCaHbF1bwk6epNLTcu+/dOsfZojrqs2uEeCQLEWEGHt/ociCmtuqS7Qf4FM2UzSATNcJUzklIt7fzMHjPExo/kJEZ9fB+GwXnX2l8FBMnRNlxcROoDgRE9NdossTvHylHrTBGNvaNwWy9OEG1fDGmFrGnFYLyN1f95TkMtnRI0TNuPZHXfCRL9xZaY/ffJxHP8x5FpSBCqtDNNH0jSVy+42xaNq41g12z3fKKXqfnnjOgC6x1/trssnv8q5Tk6s+eWXxnrKoXftKoV3T6ARLdA+G8Z2+F/UEOCCnefoSN312t3dkwmvsteEmPHelf+cLJ91g2e7EoLzA1QgkxQfsNVQma/eLqM4Dt61VDcWbA7VxRdDRqpmE2xErV2Ryg8qWFMB/y8sVb9q18V2drkCz08DURVGmX3asmkO+CA4tX0JcDgW553T8mpMXhdo6SdR4KXjm5dA2hgxHaL/0SkyIxifHA0eHLJp6zdcti0yq92dJqx8G5Oi/cc18tVJsY8XCW9uli4/EOcEhyUXFkl08oJ/Cym4CMHg37YpO2wue6my7cakHfRodxP16+ArhbxW+VF3fI9UHZ3ORHLZU5DIJHAjus1CwzgdTlGY3sSqt7xVGKI0jB3s3gZHmgpvlBHTkYUrMpQIXbjY2F+yl0WSQUZXbluMftjYyfhdspeoSFSxvhCgRdlmLp5ENMoXswJWoTs/2tptXDqP9t7669z/LJ2/l7X0k8scpTwLlm4llTwAJ2nNNqK5fHBxMBiBNA/+QwdSairZL7AcSNsc6fPIXyu2VAlCGy4POIQcqrsm/HEL4eCETbBAarcwgLPcOreSBLyHCs1NOpBESeQa/iTvNZ4gm6u0sKyo4ANnN33x6iaLpeBvUDAbToQ4FQCR4+/dZyPSdOKkVy95Q29qgQt0YeHQYWOFKiXoEUOgrLafDyMYzUepwUa9lIjTTqSvRp4T+B2lCd9tid+3ZiFHPfhgk2KL+plksvkB3p5zdEFLdHG9VovW7zShfhYlb58dKoKQVzos90nPWGqIt+eD7XKSRiqOx14Xp0ff3jSK41qD78HiZuSn9j9/+uF6emc2ClzqwIToekPaEubZWOffGXfnecmnzxvtZLUe4czd3m4IzgGYgj6wA82RLKQme3YK1iN42CJCcgqLswazBBShAWbavkGvByRGVohRYW+VKId3AM3w/qjz2jm3lqGhHAeAGUkvwy5e9fDY3n+qKYwFBJLlkYTPf5QhH5UVE+sE6xk3QyFe/kSmecdz+ukfkvTlg1kq23pFZuIpAD+UrfSmMHpWHUfWNp35orHDbRU9uBhwsoJIPeSK22xs+L0eWVw2sNOFi1p8cZOJamMBPPhh81OvyRksS54vH/FmPiBlQ4PQAFNP0STFkxYprCE/2c4F9/MSw57lV/7XjX6lRtKkW6TOHMMU7Q/Fir3x11YiMDV5TAwhS1W24ZGQLVjaCambdN7UFXkIMhlc0+SJ9ACWa8AxV2b0gYmFUTLx8LhhLSrhBG+1NVmA5OGOl04o4CYp5xcD40s4KB4uqEQOJzH/wQT9FgO/yGRMh35BXJu68ap6uPfxwZAF+XbAKNkEzBJ+F/EC3LlqKz48/Mp723NjmyWHlrzb9xK110rbK7dNBxaqd/CrzfcE656vAYNEnBTSXpbm+j3MPZsihUn+01icnXNZff0IQhhjWqdg4nJDZrMPyJraVjtnUvtyS5iss32mlkgl1TpHS4LRWPulD1W0J/OTO+3kc06hB59dSMp2qNTb7IPeeBZ7lQbV4Zg0yT1R+RO61xCbOxGGA/0q3blZc/pajkPXqu/3dtupmAp9LtQ0Sfm5gK2AIh1qkNH/x0sy+tSx+rT2EVGEoomaoM4aRjwb3XkycMa9rN1vt6CTTF3GD+X5GT1hR4BlG4BtN3nQopF+FiZ7iHk+v9u3J65DF03DGbjFb5Fg1hz/CeYVy/XA5XYP7CcxTLnwe2PX7J89eNOCCPb+evgOuln/MRd2UpHVMMbRFQ2IYxtu6rJKT4TdDdGkNHfpz/24Hypyal/7goHaWrPH98DJTanEc5YELLc+iU4UdJS/WoHlEJxEpd0e9ES6HLAJ7I3EJkWiEUmOYYpQ7Zehv5RgpnqfKv6omECkldNUjSSLeZTNapA5kgb5ky/yOjswc3t2q7xFr1UaEtgL+AzbsSTt/HcnrpSYsVcRJMaC4OQ+cp9xznEosUCrWgaho/dXR7o2wO1Nx/Vour/DzgH+T/QIHb59QR3ddJTS0HGlQgGqh0IYuYLict3psHqyNg/+9i4A3/HbBz49lJfV6he38c/8poWsEXbSRAnndWKo/X64itKqKYuBJ+qi5oKEwsejUrJ/B65pYpJqXm+01jcZhAxGGGtwzuQf3QuvO0p65+mv06MkpjJWMCHBO1j0x5CCO65Y37hAs/47pNo8A2O+LxTK3hFSKpQDc86ybyXCejw/hlMZVfGh0IOA3RiKLoLPcjpcR9vGtSL6nXYj8sC5qmiYoXBHxXg9Ad+mfAke8SwGjdLL/HW4ojRvqUQnRXoScAmzhPEuvKkvZdbQLQRQ8pSjjqf5ka7A+5TUoL/XTpkMLYMORqKZfKFfZ8N4WLvaPhyX5kzezB4gTjcOTGtQ4l89VEb9YOQs6cKwZAHx6MwziKlxSY0Vb8mUaQCRSUws9sdr+cqythzpLOzyVRAmwLyhK8Bz1hP8SLZXKEAlXeRMuIU/mWpXyEUxvxj11Z4tWigzMGvjxvkq/zm2sByCqs6IpMBvrepobW4SM1vXci149iTiSewQCX5zdSWRyfyf400ODbd2MSNPcoa6vdLQubEjvwdIGxXmTJ+voY3j5rZJ1AxqzQLvIJ4ueKmrja03oVp0IpgskVpgTUMAlZ2kXRGMes6S8iSztvev7j01Rz8rQ1CQwVSbRsxH681LGJlQgbRoK0D2cZ6zch56r0jxrQ3w7fv5LlJ3mtxZEbaCPZmX14bM9xm4BpSMYYR0pugHPyqeUW7noh0qLrFaN2aWqmlLE7JPVOCPHffg0Wc/J+zS9LJ4iOWS+Egcx7Uji7+9lvLJlAiRP+JF6t0eRj77XUsEeeMsEnE8UiWiROX++GIXaYqmTl+XQscLWCYlSaxU4HeXCyICYyCWxAzyYQq9hgKt3BrrS5ENUFqbHdemQ5ZVhHaUEEbNzgiWdhhC5H5Lg9qyD6vYQdmMZlQdcqlzcClf9jejjNyMOKOYyc2De8xnCE4GwgFHrfSmY01hbiplfk8CbHaw3kdAyNrn5DAlB34BcX1iItqenmVAO5d7e6HBOjqwxvl0dpBe933oUCWn3W4E2fVbeWmoPFmtc7VXvyuF/ADtQA6xX6S38MeG92rm67XmYpHjOobDi/Sr7MJZNHisuj8QXntZvjdKKwU3Uvrl22v5tyAQgMSMg78aAP5pZHRDYlcoMC93SLC2+1CMzByjkfL6zNZ1p2F58xtyKo4TmHSOQmMsRjgJnaEOAsCS1l2OlCx9EEy/gLqn4u5NE3ci0OduZLuGc0oFisJqEQMewhIMxQ+scq2Wad2ewKW2+cXvL9gyExTckXR3wRwTcR4nG3VeHxoAMAlop+u2+93S232U/gJiXxLM+IKEglYgi1W8htEu9SNJL8GtgnQKYnE0/cQ8U7mu2HtSmNv5tsSdpb6ya66ozfjaRJ/+ARcTZG/qLGuFcXRhW3+dh/n+BG6fJakGRD42NSidXTPfEOIwBF5SK7LwLEFQJ2O+vHJDafchb7DXaNM9uxOd2T4a3E7uxI+rL/sDz1QX2NYHvSEG3mPgvZwusJimhfYpkVMnxGC/4v9kvRlcHAIb80qjzF8BjCc55N6m2KxHVKFP01MsaEwQLu+NRRYNllXJrEoZJC4ZypTb2G6olurMq2+DEdNN1lCYjap1Cu1yrz+RCB+/9mElXzrbdSfhENKlXjABlaa4BAO2AC/ZMgHqIzVtUhkaCq4pZscfukkUgtZsGZMUVlQZUp/nOe76vhrvBxOwNdF99tUa7yH48nLv7Z+zBRPVVU7vHkhhFkeT5QBiXcrA5GilG2+T3Ku8YEnH/jb6vcEyVQoh4joVBrAv4iJzZqV6VYrj7bOu331Mb+seosefwSkv1VwEA5UpaM3AyB+9PZ3yycbcc7LYGksxjR6R2bH29jJefs11MRdNE+WkMsogszgvV9OCKyrb6ucvHrdzTzrG2nZ1yp656uUl0GAWDwjFbdEei56zYWup+7py+YtSzxiPCzeMGbqY9aJXRoapDQKeQxVf5jasu71z588MLakrm4AnrPi06RaTI40FvNK904FTu0WJS8oiB26zmq/wOxcJ4pgrPBnr+nS7069l0w9KeEYNoR0icR1znV1LSU2nz7qAAqlEIWzMaQGCvpn6mLhFolGLlthkOK/ZrG/qBzCzhG1gWAdp0XI1i0EJY7ugHe4L/p+Bkxtz8YrTb5pu/QbQJqPZQUQq0wwp1KhqEoVYzj2d80H3qapgbW+u1mXevqd/Mr7nnRqJgPXicz4dOoq1OhD+8plmtPI4t+H9gtlo1iV1BIcFiD/KXxh9EedlhtAFyKtln2r+br5zOU0tZDTxj7yEBa/+mFtRmQpHzcDaWyRoj3+CWxxQUS7l+QQ1d58eGcUmkPtSSrg4+6wu23fXgkSH9DFev4tvtH1iln9oAG+hLkMixUB/kxTvdCLzcwFilvVK8fKuni9d6Rvyk1zd+Y2ltAg0irHeCXkm15w6UKo1urCFvGyhNysBFcMNFx8B/dZCcFqIGu2SB7u+G9IQfSbWsuR48GITjJkCBh6R9kMtCpBAaYR6mA7zUQ2dyHWIYMJymE9AirXo7EWbokofZL1K9Xis5stv3aAobXC8ff+3rMgN9GRAdu8wKDoPtpqJrygMrLO4Wgr+G9NXsjb8GN4ersBQYxAXz63ggqQ+XdnYRkFck4ewTvc/BeMYcaEhweK0scsNAIBBmuiSvBwOq8NfhEoZWqtmhGyJJDIbR92nBUWpG+T1WZYJ2HuHizNwPyRfkjVcF2yUacZ5abWlpF/g9ZfsXyB5yt+DO68PKryDqqH7TaZl2KqP8f5H+67It6tU1A34ON086G/d9v14fCgvyisSXiPi6CYYiWoWMLKML7TMuZ4DeaymhQOY+i+WXLYLHb6IajtXqm5wjsLLRi0hMcqO6q2wxpAx2I24nCxJesSiMnC9F4HwU2j89XFYJCpsggKHRjC4Q5gNFjJs5lplGCtXi6yCeD1UMTYd0ERI+5bcIhQZeMWZlHnMUnwNwU01UCsS/C8xxTCXlZjYAa11Eg9U+7Pz3SIM3TYs6hqRWkXpGvZbAUhHuK4mh36CnIAAAA=",
	keeper: "data:image/webp;base64,UklGRggyAABXRUJQVlA4IPwxAACQkgCdASrIANkAPlkijUSjoiEY6wbAOAWEtjLBoVKeOsR9WtL5f+9eipXv8H/df19/efc/2B9VeVn0D/3v8F+ZfzT/z/qZ/VfsDfr555/qk8xv7a/up7vH/Q/cn3ef1//g+wl/SP9H///bD9Un0Jv3O9O393/hs/tH/c/dX2rf//2b/Ob+meTryX/M/lR55/kP0D+J/uX+J/5v+B9uv/M8ZfTH/U9D/5V92v2f969sH8X/uvDX45/3XqEflv9E/23qDfe9p9u/+/9AX3F+2f8f/KeNB/yf4b1P+xH/J/xvwA/zX+rf7z1p/3Xha/d/9p+w3wA/0P+2/+f/O/5T4cP77/5/7L/VepL6t/9v+w+BD+hf33/t/43teekqpUEUq9/zyVn26UM4sQqkERUg1tBNVttiSf9QC7/kF/OKZnh3pVR/SbihDEGjtzrO1ffI1/iAI/lE9necwTBJfkZReFZtuIH6D8Qsp5hLYgnn4cI31NboH+fk3Zj+2P3ItNTOGL8EftudXso06sWpkTUcZcmkbnJ9qjt0TTQTnwBLWnxG+ZYcWUxuTGxtKzQBVM1K2d6kGhv8mEU/WgDKTpo5T70K8d7eSNAIu/jAf6VZndo85cgsuzzNH0EWoqMnyBJef9G5G1k4nddXy22/jsxh4p/rojnxyMnpAxL+FXEfSmGUHbrksmhn9N2okn2tCmhYaq1Ep+UJ1PyUrw8UEl56ausqp/rONFA3nQIglDRR9KdtgEIyVsTzUjla3svyN4qHtQzV+YKn6hOOLManOCmEfNyUfQgq3OwKX8P3zb9RyGtnqLWVngpZBVbBIoBRgQb8ZtIrdjeI0VITJqL/4UuabEhn+lUOTSkxm+u94BewAI4kBiSFPdZJR2wDIsHLGomnkT+zG8CkOf+sxNg4BwLssYVRuuzi5wSUnietTza0LPEoNjy0WHf0gQh+qmO93nvUmc6ITUShbF/aM0/RqOtXLcbBHViusq2rmxS9TQsxYgDnxum/jo3D3VAfFKjw73ouVsrLoY9rE1mGJs4ANTGo/i7xU6OlEThVjffArGTqZdW/Ju5vn5/sZET1L3f9z9yO7QlGZ1mby150sTkL/Oe8FCUaW3rTH0Y9PSSKd7ckW+/ve/OtPHnI6BEQ1vphKQoybMeVZwXt/edxhd+XbW1xvMACEWgu3+BHAM/nD1Hxl410+Ut/WPv5xxr7F1HYKNHLAst0Z3gwSpkqOJ6MhbJCMG1xCk0sNrBL2bZf35oMowWb8spwTebteypE7sRZC306NVD3t3lDHzqTeiYF2VLt7DjLm60JnZ+f8F6CjjFUofQvircfcetXL4f8E/0mRv2I5ed7FOvnj+KfDWgEwG3GympDk8tnd8cj+T/gdV/34TZ27rl3QHhxEw4LbtJre6Lr/Dd/bwrOp1lTpD1JNIx9nOBy55y17HHagXr1AS0sNhBtxwjqqA7ytVlKKlYNa2uW+7H5ocIEJlIm0amy9kU1wXjLs9MnudVSiAiHYGxDdINArYagxghTazOmQ43LvuXaPGlQK9n/wmiQImwU6E4b0Zw9tMukI+zroeyFREAKwAD++9mp/LtCYZ3S/4NQiC17Qw36xN6ed1o1l3jJlNt+mWc7/IynRAGMImK3701hDk/md4QcKm1V8Uyr634hBPW4WV58qi9vAzDyWDAXEZAJNdScXz/qtf/NI/JQJ/ljT40fZVsCLBIjDZ3oSOcIM3IKgUxR8uUf7gKdJLUmY3y+LSlwnoj8TkGnLFHlp8yVP4lM9KaorO9g9++oEzyps6AqGpNxatuMyayWo9ThVpCx6ykndeRILApOQd9JbWDKv1ZDk/EVmbM8BROvFqDNkeZoih4F6N3/l2M52zFqHmr8rfyiOaovJJE9zNDNvOHXX+ZsSorVTTek4OHiH6AbjTbOf7NLCUrnmIfiKAE63F6R8q62T44fyPNjX1AUkBQx73X2F2UgIWG9VyNlBKIAgDkTXh0lAst37xdO4PAKDsa+Z/NI2dm/NGv2QX01tkL/kPdGyGQKw3h8ttDGF1Oc9ZuDTJXIYbPap2wcK7YMmsupVxe6xQC5t64JWFBD3BFIratVcVPBPM2bAJhhxfHSHR5o5ewZtXQGQ4/7lfuC2f5wapGd0qh4D9PolxtXLshtjcEezh+QgyQX7LQUqiuzLbrzPV6+2h7UpC3GmX9oG2swI+X1TRQ+w+jsf+WjVLC38+JXFwbQxw6tD+QmcSDc2i75WwlOHOim+OxxZo7iwyPMjCWdM8yK3vRl+J1CHfd6S1mNJl23hY90CGgqjfAJcyFLS3RuHFYBKPFy8+jxz1n74aAaYEdTgtNP27MQKIFhV8em3HXn9j9/+ZXZpVjG5cadOGuvGhlinzc+cgKISRIcvL/mVtJEF2FKxwWfCyZhg9uAPRxpusIJtNAMxoKOKrNyS0a/+E4eS3vljXTyfK9Hl9vlBpIMOu/d/sA3o4b2sLUX/DA1Y5Cs1f+eqM1zW7uKbitVGyi5tcITu24GWTAYyrGjcBINk2dXUi8rt+goZnwb025CMKkmYYjhpdPxFSawGazZumtS97vL2AU1lX1FEetBkVYnjYnZ2w3iBjqA8wVys216bwxicluCxkz6fKNY/zyrj8tP/8TAQHrRCFtU/l/RUtm7LSwa3/XHRbMY78Q9V7e2KII4VrR2ZVbz5/B+4/Xl9SgfwyV07ojqzxqacMHxZd0ZYeYBz2ruhZNMuysyd68U5lLsKvQuifM0k9G4C3OZUkze9k6LnFyP/Z2fo0+6JxdpikpFaEAyG+Q+bypeBNUgFbNVSBjO7jrubKItlD55UpytvbLug5/SNpCvOR2vnRZQhEKY45pDS1eqcz8aH/XO5/gy+oFNJW4m9z1qajcBx/bVuTaiO34jS8Q57XoUz8zfjQUzPPjUEzt0UtItUSycm3x/D1mOMk473D9cWZPFtOZM1H5uJsLwd70lCHtnok+dAD3EG7rK6sDTVkaZ0qeJd4eDuchVHMVpSlLU2ahmUbizctOtWY5l34fI133+s+VH9yPTaAMc/qaH2F5UOU+b1XJ2YEPBJigLN2iBGWK+7FvB85ahtKARrbXPGF7cao6BE97ehyqFIiqhHk8nn/gJhHiRlDYEsvYxrVHteAwlidCkApYWSWCRdlWHBPPWH/vI6BMb02vx3mAwrEtTKDY9gkceyGu3Oo/2MIFmQdGZPnDtDFh4kTyG9va+Fk7s91fF7vmZT12HhPQsnSUwvqQKvGgaue6V0Zau1pfWAagFMkMWO3jHu18PN+QlJIsXcARKifRcGVBg+2HT34H8i7Ak5HGxw4fWn1qlcDsz9SXt8SqejICSfNcNL5gTm7W9ZArNl+WmJ1c0GwlqmhZFnI6YUB2i3Pfw5KclBJ/kAsNxW5MY28rpv2Jf6dGtxJONHtM0K7eIDSEBK9ACtt+pJnwq9KixzqwE9o5hn3ooO2yDvjc/HgUtp8t6xv2h1mLdDA2OVL9cfNbeNzVbTzPgkfOPkA6XfELNNCX4ljgni23aSuTiXu7nJ5bl3AG1g9SjibqUsjKMe+RBpRJyuJOvrZpDnMlxYgs3x/7vP0h4/55RARPyBEKCMFVBmvwneDkFFOhQ50f5lNck+xz8fFuLdJ3lzfkPzL6+n3asPkDHfWnhKpJFcjOOni3sYWBV7YPm5zo17DcpTqHEdqpZgm7gzxI6xww17D8kv3faP5QBnbmyxKdxSGIV41d2JdJupiH4W144xSb7qvgTrvNC3pfY4ikK1tZjlUHj+/JevpQT/3xqJiH8TJ+SlHDIKY9g8mVa4Rdc1XUVYy76VxxX+Y2f+SUE3uDM1xhTYTPywuSFcVJA/8tRJnB7pACRQ3waCSRO4RXOcRgGh5u40cPqD20B142ZUCGB4Zv5O5Rmf+2bLoDBuL+qANpjWZ988UWDMLkdkT5k7de3gt6BiVfizeJe6/5dr4aPyi7a8kmrp0t5v9ER91hMU7Ujx/T9rYlGVxgLYaXj7wA6hoI6y71E7Z3O7tCApc+PoomVSog8lrQGcnevj4wLNqTZTlZmfphPrvtoQuO0ld88cxQLxtB2zqnv3Di2RcC8ctB5rVk9vci508/K1So7obdO+gczewiwr8i0XiJVbNyBb7+kuLA1KGtHWPNqW4/l+gtlckd49U8O3VnD5deTBysndpM16ZpRFy7Z5QBg2rnqm11CuMf2LZbbcxPpQyYGc+tthBKa2FQ2m1ctLD9mDQ4Y1PoH79BChdrJEX9dm2cIel+JmS8lwB7Avs8+9szH9zOqgdYZjCQynbZktLfdI5jvIIeA5RUHZXGx9LiO/mwVDPG4/rbir4R8sqfoodASS+q5A5cG/DtwiOrUcKbTsVNpSsR9XgWHeDFWEtFRtc4a1erodkX/um4uwEArHZAwACZ/VCu5P0FA8gQRCx1H12iTG8A60lC5wCpkG4G7pcak4Omyz32xQ8zNbXMFXhTjKKMoo8Chxaz5gGQ5o/R6rXbGuirf1OCMP1gKTcMUwHWXBJCmY/kR2o770s1gVHuEykHvvm1vX7Yy8TdrV8V7cM3BvyvZjqO8siOH1+r3zIl0lpK07zk49WRzoTweyobR6GmfbThXtHAA/1BT9hXS5wpadEbBb2qfcCQfVFzblb4hZMYuDcVlaDweBGzgaSPyCj5fC8m/1UB2VCEJ/Jzbpy2h268B0mtOQO9Y6Vc9ZzBFKc9QKoR1iFlKuY4PmW89IlvbGDIYc1u2dBWz8XeyiEMJxlIgt85NWoAz4UVYPLHSyZsoeuevb8FQ57k3/9cQf/uyWyQn+HoKxVIUV2bSV87q7fkJ5Q1F5tL+6dzIXzD3u5QkD+JFXzQq7M+usunuQpiwhsZxP1bbWQt3YtnB76+X2PgmkkMEVEUlVsNzkpcP6dqXV8rZE1Bt5O7OW+xCb4y/tdq3CH9JIyMW4DdDcVQi1U/PDsFADzREp48SX/bOXoj/RRVWECxX0tFb7T6YHvhntYQFJY9Hzi6E8bCs3IZXPwKUJawRzNI1J+dIssRF+dzEYpgYAiMXwSmBwE8vpJpaw62MdtSUwKokCz7zdvrqgqaKWLWfSprnbNHKQKJk1T2O5YxEYV94X2frC3qWqBh2pfyot3xDSQuvAqJC5QN8wKRHGa0VQ8RGKBOgR7OvVl4yxrs2ky1GwvnRSBlC4EZ/sJnTgm4qLfVqzOfGFvp2fwVGoCyKg0Mflb3pedinGuUFVUoD+gj1GtS/hkvyPbQDSg+xi30a5konG/mdeTxX8uXna4qHSEBUd/UriWTK0R2pMinJxq0twfVHbItmcPGbO8D2iAuXyiOXCqW/3D+azfydOzF+7oYJyKlwma1dSGDYT+5PvAVzgutnMDdm/24Yanl7Dkwr7e4yVkhMkHiOz/5yTIVz5sCy8TW1UNJlCuVN0ycIbSTClHNa0FJH+gnsealJ83EPOJQdZBgB4hWYTmh4oRQuyWZzGd0ABGZN1wCIPwId6RbHtotYpZcUNxqfsMa8FSuC/+qVMVJFPh3ETO3NArN36IjKadrbpvopQDje6ROPbjAOrAXFddjzaYTZCFpcy+wRFYINLDU6lKnIolNeaI+5lo1ImYxOqM+YIHPWwnH9XzzQ2tWnLJQwNhovTEOJ8kP6X76371yt0zY0Wd690wYLSN2m3ms72c5wB0cuiJYGbmiA+0oG4/esl+jUaMBSK04ZVKAAkwNKNSmSNDydXBCtOQzzUfrSPkh3mcmGq1x0NbgDOw28JhZnOymwsvphdD0/Sn4PUcC2Bnzm8vyF5eUB95TulrJPH3dHlJwmcBZykE/+wJSp6dHsysO2Evksb21rRw2WST+/FMC0b+EF47wg+U0SqYUiGRzh8DGharPApK9jQAoXeqrnlakKwv/CW4LwyZwvlTOJDqScFJb9yARJIymoYNGnGJQmm1HRAAEre0o8M4cXoxnR0FoZcB5jP/aV8h+sL5IUlN/y22ClxvjAJv5x4ilHX9GkWp++l3sWVHPJ+shkojtE7BozWFJgYTwlvwK3dkAWaBRLwbtLFKwA6pcn8VCuj8QG/Y6Ky03PLITTthj9jTmMRf2dIyTLR9y3XeHl8R8Ck0ILrt3a2DPa0UG/b+BR1RKG2n35viFQ3SyI5t4Fd+KQcjinD60l7rAiqA4enC+uOujdOBVMehlcIhmLy8CexjSLUJnirX5ETmc+SoKIAnYbHJlvRsbSmZMesDMFUhd7zYnxiYSm+ke8pz3zmZIXY71IIsAN2jBlt46f/Cd0gls1Tpx1g5E328e7l+5ndkgq3uiW14VK33wN9cTTUL+mI+SS2xwKpe+FOlPrlXTcCy1v14IyMlvHhzuXUmZd4NTmg26RjaJp1HTG8S+PGWIn/lSqyd+FWlkNh0mR5n31XyycJref0MyBj9D1RAqhLLn9m9g/7zsHGCnGZtgfhK/y/wO7lhquU9rICniHty0jr/M0EgLZ69kAXj5NIXx/ZbnHbC7Ygg4cZ/aUv7gly3F48TrsolbO9Es0xij73z9RFMNqh8MYuGpqzNFBjb2+kPMzY6fmikjJdtGRaWpW3ZRF0EfdPiFWvjlKHj40xrzHyyIiAWW3W73PBd3QZP51BReeQEZrvHaSnVH50AY/1dt7cSUZiqBU5xdSDKP4HCMGPeWMFzRQwipZnUi0e5u34bKaKMb5R4I2B6dtiNt051EC6fCzG8T28NpT9ubVT8dIsVyniCTycvPcZVWWtabgnaPhxA9RkrggINcTYMBYck3gMMm+fB9froN859CJqL/HhnbVFUjclqYUMjiOZ+DvDBpeLsUXYI7pQcQ9bu12kKKNr7rNtx5gB3czB8EyCvgUbQLOYgH0ktbVpLYo1TMDz0zJa3G/ZtZrJiboglcrLjmHxBMgvujzYE8DvS3e/sj9Gh7ckn/1QEbhP09IjF+Q2JsPtKId6XcNoUp5vFA+e6fI+BexEaR5ir75Hqt2+v9s1HpRCqs+hNJZbA3KhagmwAcUd/pOACm+qQtA3Vt8aPWeN3WmSa4V0G3p7lFOWGO0jraKVvfy6W0AtEH7COtAor1ZuJgRWHM3FaSWxMoLIsjsxhe8Xbyl0nb3FxV73/nvSYibfo4TfppYCxZthcgAlg7xHO2o52+UD88r4aKow/+mV/HSuXMuLt4Rcbe2/HJtcYoTax+JSCh36owFtOExHsf23CP+ohfSAJEyd200zsBXhqaEz6KXnqIKBRNoLF7LXZN7LtSZ1wgbS61EvEbCRDZ8rMMWlFwP+y3ItJs7E81LTZvq1j9V46YZDzFdI/JXLkzcfY+xTfgP5mNWYN+aSecFNaa7mvRpLG0XR/e31MYRxrfr7up/lENZ4eqhnYzC7otb43rLM6bmbzd2BxadIIdCXIxI/C1UrLQo8fJb6yIKZhlTA49uPyiTKRyI6NjFs3CRdxgPCshFs4RCGsW2Nu4eD7uu3+YYyteMJO9Jq9BYHtQO4dRTKfK9ugJZtWDhFSLeZwqfFTaUXoTLVEwwPYU0hc076UequLwiCVXNE3wS0dq4rDE7w4R0Xvx9W2tmUz1lMG3ZE4W+9lXwWnBXA4m28uQ7S0IaL254vIw4FDkPO41Ve8xoLSkJD1GU1b+Lrs3IVhPMPKMgh6OUZIagjVtO7h+ek5nrUIEm0o98NdWQigU4TQTPl1WXVgP4pTJRkl6xiFysiqFmzkFNx5TodURz3PZlp8CBIqCaAYojO1F2bkjR6ktV4WjH8v7e5VDVNTf19qMcJhhYnskd6kKcqvuHds5D7bFGy24Adtt5Lo5don6o9Y8w1436hEbEsGwoZFnE2cNTnb5t/icJynm1joehcZnl3LzZvhfvtkj2URF4N3jP+0PTXayIQWTfOhe4htePhYPLDUYmL19rIfPs19ytL7euWj6PFGs+osX5wesTIWuicD/jA1LKVqQls/G6fpezrDtv6a5+pFF+shxW5ur4ZysFN/FJ9YqHy3yEsir5u9Ex2jn3GFzpsr36FPo+c4abmJPBxUaUlqC8gdS1l8L1LAinNu1D2vxejNP81GYHB9jcGx1TBO64MpxIFkDOGBNTZcvHDqrt0PGRzRDgZIFwYzYjYa6mzZqJXZHIxsBRsK8Qd9/vMIWoviuWPjhkwqhXIA6GCfhGX3pxka0foR+2Z7kEWtjJxosfzawTH0i4sC2c/1ubGGgh2yW/aSWVmiInTomX788Sdaw34ACd18p54+eWxvl8S+KYImvX4Lbnqnmd3zUxK989CjYH+Fn7U0+NrkwhuZpwBl1L7Udbfi6BIoVibccEmEzPxehDdYbCKQu8AboR/JeVZ6KTX+tonz+HkvWDn+R9NOD4gNX3LSTFx/GQJzajjTJ01iaxuLCd0EZM/yincBt9Pe6dPyypC4yQKSQCUzqlGeKnyFB0Ccz4+wLjC2WwWhepaoqzUof3Cmq1uE2cLNdXnIGmrBwljzok0xKfMIHuWhDaI11orzZunSn6QTcI3WtLnJfI8STlsLDD8sizcbLBIDY/n6cPzfZ5ZA+QuXCtGnj9enqdCDiV81fEt6e+rCDeVPEpSxjswny8WQzPKT7uSCG3fuIu71MnowpBRUBKSr18aZNP8/V0h4gtZHUIKLNNh5jI1kTWwHOyxogituYg8hOnjrZrCpnaGGSt/R6a4k546lX54ks4faTZHxT8jEXyCpecqDrHmrkQ7Qjt4Uq7Yx7O1narY2PUF6wGhqgwOF/5LVi0D7kIwbdg0F0fdHrgh5uNKnIYyJOX+Dmh8bgpuLTkEDEfM007IiF+RtfEO1ZFFissnkB9f+pBXtaz4DnZfVa1ZDC1ytN7vFczDGvFjnWDLHbz4FttHXFOrCeHGJPpgSes4EsJrcWy70DtFlxGOp/3d2EMOc+lV2IJsyp6Y27g3FvjgDtDvYfVPvtxZab/3HKTYqQKgLSQkhaVVFHzbrvHr5He9lVTpIyVYOB5o0sbD1f+C9snDsMcyPIAAEFseC5oYACeLPeyVKr49/GipndnJnf3OHbj3si4nnOFQOlxv/irRnmTfSw+NKh0Fib3c+Pb2vQUPiMMmchaEUDNdfyRBmsZIDPEF/5N8Mn5Kr8YfX3eppueeA+PZf9kJgsh4febtyz5I0U+ST+qYO/degxmFhM7Vo1zWT3g4zwSeTf+D6h/ke/sHj85DENiQxdqOifERE/rPhaDw5DEFaHzUncV/LbAYll9Ug8AjbBfP6vz2iy4RiZLkdYcujFNcKjeHhkdvvHhFtzhrNR+EeMNBdgc8nIdEbIqVx8BRXldzFh7lA0PL+rsk7HhVSRXvC61SvdYhqa576h1IS8dzLCXMX0ppwZ6lj7ZjXzbpyp9ZSitYDbeyITaT4yKiImMQWQS1cHCcwBq0ivcdgL7THEBdE1desXrsHBGuPb/ph/De6mhvczmW7JuGAuom/JX9JkRfIXkkstd8u3AC4R5vcADQ5kJPDG9rP/VGqiT35Sw6d3ZYUXH/kukLmuOeMsf4LCcMW3MlU49TNH33HovtDH9g9xRwXDt0qWtUrY9Gw4Kl518WuWwEBvOyFHf/Wi35axksXnAZNAw21vp7a6MVbmJytL9d+Q9/IQl+aYTrQuo1ZpMtDClY78kiGW4oC2gRVJVtm3+lQbpY0qMezodSGkc/jzFC4Dj55sdKMba75hCG0YDhJeBu98T0Dl1kurbrKXfQ3wb8PDzGgVVSu6Y1Ga7Bp00eIhsWezzGM7xIiAiEqJwKgmZ+l87qgJGUBxGWBeFaSKAgAAeX7fYWJXyeFzAmmXV/UzvHM0ctwxqZrWe7vXkTkEchV9QUTUioKj5kGapEgmflbxSpTMiLJCwSMuyQV9RfkBBnz/sOqoCHYlieq7cbKZfzDf84muJmhTTMGNohuVP3ZDFQIb++9VUOIVKs4LZZWkR7TmhEtiY4vg44Pre6M1ahlz5pOYyEKAjtRystR+IozxqK2D1vCuquem4tDQllJDJebw7dnI4mDQAfmgIJRru3AhRMA6s5tgAkyIk+6ICr8ShXyXeSiF4LlXAMwlqsmyBBKfErWt/u8LC9BFhV4PqkwoNyCWHv87AkY6t06ZAOh/AM2A5Lneu+RCPQ5j4RXyA0uj548QCB7WDmPJqNiDi2we3vdcVPIs07MVt0fVCr45I9yfW1WE6yZjYElCxba93frjDYO6mCMYPo69fu+wDVZbRRTILdIKijE5JV48wRoZOJC+2hE5M0PltMP3LMfujeVWoNaTtdj4vqtyF/zlrZT/aO3nVuuF7dgrls/l/ruL8mC4pzmbERSSwuWIWLG25O9/K3LIgaqvGkqmGGYhNSfZgHseUnkznlHnphJt/HeugiSvp5moCMREe3l9Ljj9hqPUy74DkrQS3UzFah78B9o0L7/1ag/CNqcKkr9duqFBecrlTgj3L8WKbn6HjOK3ot26UTN24nVP/BJevBhI38ZCr8SSB7T6glB4DoEKgXYLFB6lT1WMkmeUYpK08Ao4JfCOnFefR2eOzoLn/Iv/17ihDbxRZtGAjeI5advZFS3zqAbjOBazXfVrW7bRHk0QtNvJuWZCFFLszPH4ANjRAppErFuo8gI8ZYnvM6ZI1j/qiPhAVVj/2+B9trPJoOp+tdnSFlnpNBE3iDQXPMyHUkJfXY2FOjhyReNPE7aQqdxmkPDiNZcZMtOulcDfFA+M0pCYcmAAeFJNI/8Dypar/83xqmyTZyj7EzSrcTAUW+bcyIYdEeXVEKMBCtiCJkgcrzrhCDxa1OL1XFHJwr4+qRv9mzX++CdvKq5l69rjkIES+fZwyLLXVvnv+MXQtgp/ySBGGnuYH9CGk+8KGevONsD/pQz6D/xZMBy4Ae/SBFEngHg+2uIEe4utO+4RV+bK+kH3bSV8mwRopZ89zv6gpvhRcs6abW3zFpaENUb80kRHpcZLzYFVd1oOQJ1YBPYOJ7Z5ntpH/IQmgnjWrKidoPYprxIQh6/RBwvkD5jdKsFumQAlc0KLPnZrIZXVvoYbqB02HfvFLxWIJxuac4Q0xhm/2hLxmSFpi5PXVD6YOVpFOpj4OMerpH7MRuKGnA0eQcdaIM9bkvcw5bdhubcKWAeMF4xlc3xkL8WStmt+HOZSbhZbHlpvuGb9JZJq+7jm/kVOvpGyaT3Ank8GZwlIxpUc9+3uWkUuSeYX96gByd7LssIvD5RXtdAEM2AA8Vzjj2iP9eLXxsC8vUQM9nLi7njTvYqVLfMEJU+x3jmY121gzNGGaryHZIY0bqO3dkAFZ6HQ27H+cxhKclLlHyFh++MHdGQlvFFgfUKBvaqnP6Cr/ys8FL7RHvSB9npQ3oywplunOxqCFKpQCq/x978YrNzI8EPf0pxi2r1hZhoDUDQazxtN86XS70swWxs+gD+dWhJADSP5T4yM4P+qVO1HPpeMX8T2h62Xjv0IJrtOhRdzLPjUI8941Y8zyaeFfZ91jpb9A9Dv3BrSzx7H2Va+0eHUmTzCs+aGbSXh0yvwTCIapNYrnPmaY6ZrRNVsYrxT82xkwNRZGMBURwfWR9mucOxVDFTa1MrG6VcNGDzE2/VedcreDPHSJq7tCjOy9UaHhJqoeFL5DvBJnfh/tdz8oa0vH4rfOSfsp2SjgWQaWDTqAbEauLyyVntOwypGFPZflwwkAw6rOIriocBeuz9NYrxkBIIjx7IfWfUrCZyQVu3h1Y1JceCqaCsSijGAp74AZOLnmOIalJgGsAI1IS9Y1WufqcsxjZLwlDzPgfeWGGbf7yPDCRi7Q5Yi9B+8PnBU0s6dk8oU2LZ0dT6+RSnAAHw2F47IcbtVU7Uvq07Y2qHdtyzKE7JBjedGiV7WFQIuJKdmX3Rcv/HUK469f1gkIMdCTuqZxgRt6X0WjlcXbfjbj+fCrFhOmA+cqxWLFJI01GYCboPKMJUIYs67A76t1Nrl2d6zKcui/YaOzm9KBiANyjkTTP9DNQnJo29qj0HHbPzbyIMNk/fgzJPAr3lp7LtULMnj4AvVAcvLVFTK1Nc0xDFg1l0gpb1c+QbgBl3+nIdMdLh1PWuIVV/gJbIS2Ic/myHUsX/zb2Yc5hZ9SjSGHdKuVQZmxmdE1QZ3RolVAMUG4ydsPlougudikVnxGcyD6Lxd1M6t+hxieuD099n9Ru9LjY7fXQ0k/MjN6ASTTsG0IE/bbCH7AmtCn4hC1RnHEOhqDhSHeJPAZEYx1RbKcCxdBCzb8ovbQU74hKP5AugASWNAAPAzulxfuCyDapV5U9fXFp7jjJdFLXiFGMMTlq4+l7F3iWIoItKPlatk8bCCvsQr4k1MjagxjukZhuu9enVFk5j4m0SHIAVU70gnivvMHcXhmubH9N1O41jy4YtJacBQtsV+SXlyP/9cY8mwRRe14ctqnENceXnYjW050A9HS+3lvfEjOz3JD3QkolRA0g4SxQ/rHgOfvlV0fe+4pcJ0T7PpfLE2nCKjKBLtiLwQJawvTmOhMUoLH0jF1k1tGziNwIGWOVeufW3qX46kdKGtNXTz5Ew2g5OFF2Sgz5Xi5Wk/17/DMZ+GgqQmxInvH0IOAAjQwxHpfp3JnxEMgys/WT3++nLHU+l6qCQ/cKxqgrIXNlAKwIcA0o9dGeSZ+gVmGqf3qmDP0V9AAkuEOqqphHT/1WyL6UPnglqZgWkT1kfVYXfyJL2SCRFhIUcIKpN7bQjHGuvoinhjggl7AM1EiEiMZFdUdjPrfxdHJHONT0Sv9l8qs/EwlwZ8/UahwYnOt0mMDNcMxq5Ilch3cocoQyA8GAFC9vTgyBkfgBvbjtcxiTvcTGcYBflRmWDyyqln0P+BwF4+XTW4/QUs/n0E4EDeHOV0JsjVEm4D0zJqnw3YUmHbQSQP1kDd8V96CEUhwjefNk3G3r5edVO85BjpxtAeWiPOX515bkMNgam02iXjvHlUhVZUEzbsl6Di+jOBfI+P/Xi+O1uA9Yk1DmeS0bKTQYD1bnpdCbH8YugndVG9BLdbZVGRSWUkJqFGzN+jWxbjp9F5QQaK0Ax4hNEDOE4zU6qiHaqiwIKNJAo2po6Al33yfmwHsgN8idSQaQTc4JeHR1dszrNELYxxTro0CIFd+P4u5+5a3F+QALCWpaFXVjVIvdfxhBmYK6eBBK/KZnb+HfWFRKf7UEP6BcGtmZU0ku7I3n+K3fhRe3UUF8nYMVq0B/7TgxUzaQwd5IHz8T4RTqSUDdw0k7RuBan+5B40oiK074kJi6fyIWN8lJqbZz5zRZzmUc48TrQRaLsL4aioeWZtXPGlyecA3+5eYSrSdylKT6UV8RHNttC4arKKvJ4d6XsNFvpLuTp5Gsfa2bkCv4y3bjPFso8LiUShIswbPCOrGKQOe9lq22MiVkEPIYhQ+3m6BL1XLhOBKRefmDcoQTNHyZVtgiZAdx94v9Rh71wv/UFGm5P05d2DcvBpMP4J/7ic1xFrZ+mpCFCO0LZXFffB9b9b/q/pcTr2wi8sjNTfQa9RsWMSq6Zd87fQH8ts70TQX7UxxQrbtuMElpcLMWLB1A7ik4RL4Yi3jWQ4UTPogurhyiA1I9HD3hg7f05kzKEJkwhlMCUUFAbUco+4MoQ3o7VhMpVahmrQmX6K3w3ItMBsJEm1Fl4drYlI8f6SY4V3EwJn8wffU3gNNvLiccKsP+/5CpE+R3GmsgimVOT8AbvgWwFZMyyYavrk55A5e4xNOJU87EiiG9WHEAblsZnS+0MNyH5K8bfTnmweDY0dXTi+6oHIVmnFZLfEE4R6yI5UWnSEHgmDSBQ3MArbqojh6GoGg7aeym9bI5Edb26s62IpTpur0bnP4+317bV4pEhv5SiUe0VnFxSJDFrVGAJlyLJbzETtBWCj8ISs2oS76EsAhw2RkQ5eb2lvFpcBJa1knkc1jJrB/2bTY72Y7099A0J2eIApfLWjkBZw5zBcpDNkXyz5G4Y9HGIkTR/ydbIA32BluShbowgH281mJy1lI+yK2OQa7148TZO/FbI9OJ4DO0eBazcNzOgODUVfrw08X7xLH7A5mHwXh/Gvun4bG2C487N7vK8vF1RjVBDmEV61k5i08qPj1Z0/VbSsonnoVb9aeLddn4HArtZWvWg7DHMsKe6ho7fZLfrXS47ZtHHuUguOiYZwNhU9P6wdPs+/fvYf4BiUcSq7dhKbyk0H+P7yIuve1Vd8S8nQUB458BeUxii+KCnV64CtClU2D5wZbcttBGi5mZyYHLyNupu6kOIaLCP2J6mze1u5YhabklZiaLZm/Gmr56o0inSryOrb7aeDp0MBlGbsyY0ulgjupi6kVP0dQT9ulI9Mj8gqm/v4awalAuyTQNZyZ86NZA3NNXbEfNO6TnpieoyzInotBe39MKjO/2FcemoDjewzfi0LNZq7jkunTIPrcgo4NDq04oUWKkTVyKKV4Iqt7E9M0Gpts2laKz1kpEVG2iQ2yEU8ULbSC2PKD7EYkXBiKLwqtz/Yc+FtuHnsi7X5T9XleASKIvY5PgUDdihlYXf/R7p3+v7njEDQTYqefx0B5zAVbFObzhN1RUNapFCfSbjubdBhFOuQN05og9NpxmjQ+6vo2fuSOxx2ewGk2wSaXQlF621aSYVGfRz3UeOj/QdeL5SDL3LLHgh1dlgWTyBL9U/bbpbwi6I8mj8gpBTG930JeDH19QRks6TSGTFiRsYPd8XeSKm4emH/VcIs8UdcXf1hJSrnns03i6w8AWcsWsSgDE127rbiENOool2BGo5Fp+5gOH2/uVt2on7zmlsAbD4VMK3PLDedMGBhCiF/vAjUsyjYQWvUtkRLipdlKI+NLkgzibwUNuFnQDUCvugpngkx5x5xLM/QbV2fkcZ3xzMvJXtYYABpONSeVD+3+Job2I7wZNgporpdJl/iMXxz+scgq8rDQ7p/+iAE1zal0AveO9VLQNH9WQ2x0LKYj7Ui0nEJ0gqYe3kEezaAqOfyzcagQX3JGl57MnvUnYIYBNQ/tK4SgZnqDYsLL/Aq8QHGsqWWlPWJYVJ5MP+mFXS4/Nd9jOzAFM3IDnlAuIKn4QyKB2IXD5ts8IDZC5MqEvqQ7Pe+jmq6a6jN9gLVA6zCE6eOjnreQ6PdbjolIQze6J+MZe073R98j8dWkMLpgsl5z0zGaYT6UEPNqSCcRKeR4TFiFSwJhi0z5wEKPCsSpNvVr++f4NktVHMddJWj2XMdfxHPxaA2tZ5sni93hMhxoPbDeVcVJqPj6wipuJgHaoVhL5ewK73KQ7BHYto9mJY5E9popb20kaRH3ytVmhUQT5Cf08iw6JXQkj3JsqWd7QdRqrRO+Id0wMeN3cKkkWG7GXQD32jAaIbL338oE711OKlcITckNRP6ckLbOEP/DPjJeahBxmtelwgriBHTSR2D9IkdNWcCgQvrULH7DldiD4OCFHUuvVDu84lxBOt29iwVzwAClnoVU+FgAO3VSCfPbGwzT18H/x86eRakCa0nGeLyk0wvTlk9YtgfmabFi1KP3t9wa6BFRzHgXOkEC0+x0OvPWfGmYLHx2f06jsvQVb+YV+APLyY/fZ9NzGXFtsMpXErpMo20xNcdRmZhULIfT1vbIcxPqCevOslNl6656x/dxA+nSm1tO1wWdtfxn6v6hDwevaHk16cykYJ4GSyOrObK56mxDHjGVudHoSexkL8097iZxx5pAxawpazkXScrqSSrJ3ThDOByZXNWi8fLjVQzKV6dsYXRUj5cVRSYna4ff/Uvn1mkHPBXkgPRLMRzJgOAyMhpANXdlfiLtl6+yzbVnJ1QyL7YKYpumit/3kHR9iPLhx02hCRHVCwilzBeb/ALWWJrfnQQkX95jySeMAAHx7+EpSOchbbysUsFAfXiOTjOVlwOHEiu86rYgGbAEFKrbWDHY3wi32mhwyw60JjM7tNZRHGe1WdpcHH60EB6XDsu4u2KIyMDao17Mndy40mqtP8ebREIkAwbA5OeAa/FU5yjloFeRGjMXbQGkj3RVFnCrb8OzsekDk6kuTBFg+5/10NQgmeKJ4W2QuOSc8CV82DykQCset2TtesEK9CypF6dXwPG1ZrFhZ9DvR3BZjZ8uTvUV9NBrGhrJ+6H3RVpCZX4t7IQns43ByXJIUDV6qB/EPcaob1JMf3Ufs4yuo0f7sP9FHEFrchRtv/PJapzS9GM0zGzZj3JN5LHcyy3BSB2dY6ZOw17GMRwNG/gyc+Kzq1yMF+ej+HN7vM9itutJUQ7nWH6Ird+hL1iJxLwWMIEFlmFhpuV/UWcoDulNggaQmDXT1aXDW0l/UXLz1MeScuYA1ONYbgtOhLp7FCEtxphlkcF8Sh3/kV96P8nWAcGG+57VztEY4RgPTDLgv1Cji+HyIffjtHxMThOJfp6ylxygHefIhfIrz+nM9ynSaVbipwCq4Aw4go+awhKq1uBFXombb2/0DnWU8YPrv/n4+BotQfG8EU8/i8bp8P+YeqYlLkBzBPOg21Igq2tkVCgDDdsENHGpfcy0nbk1DWFO+DxwMVB/4DTQySa2yuMcfd7ZQE/DOI8edVoUKGYZKVhdGhroPL21aO/7/zvd6WrSDoSSCOcMAp7iJCbGCZgUYyoiLKsOpV6wnylNQ7Csl2c8Hdz4b2NWKHrfsBc/m1RI33KtoeUIQ4Tk+hKUbwB4FKnSOoV3HWhi8jQ01KumUtRqyNShJEB1dS8Xgc3jG3lxS7nB/GEtIn/ooIP/SsraCo0N7M0F4ia0szBHmIYRHTpJDMorny7CKBecVCgxXANXQCEGSfZIn/xpcZrnUCaXv9xMtnLRVNgle08ZqKAXvP6e95O05VdLPuIl4tCbCr9BNzapnMOEcNn3za7nvcxBnXTCLE/bgMwkTQshCqiUrx/usDljtDN2hCItHKYjbtDPPXgcvQQbU75u1m9rUg1v2WYvms3ZP6DDngFOwdQMx4ZiHx4fCZ9ClXXmMxqclLHI6u2HLuAIQoWlvveU9ohRgTEYGyBl+cWz5dYea+k1TiEXCquQgbHuio4K6Pxly8BdHXwulW4LLQRWJfhWzw/3oJoTAiIrHsYR60acMMIHEW9JJ0+hza8NDUjV/SUSGM3QzmW4JIIqaL0fP920Zn8tP8P3uAQCs4iC+/AA",
	computer: "data:image/webp;base64,UklGRlI2AABXRUJQVlA4IEY2AAAQjwCdASrIAMcAPlUgjESjoiEaDNc4OAVEth/OL7R3GhNOYWB3Vb8W7PiP9j/Z/Rt5B7L/aGmVZt9Tfy/Kz6H87H+q/6nsU/rH+T/8PuBf2H+sfr91sfMN+0n7X+71/q/2290n9e9Qj+3f7n1vvUz/yPqVfu56c37k/DR/dv+r+5nts+oB66uoo+pft3+d8H/x/6B+9/3H9ov8P7eP+l4MOk/+D6H/zT7kfkP8B+63+G+b383/uPB34pfzX3BfIF+UfzX/Lfmt/hvjy+2/3f+J/vP6n+Rnr3+c/2HqC+pXzr/Q/3//K/+D/MfDX83/sv8j6jfXD/K/cp9gH8u/oH+u/wX7y/DH+o/3n6o+dd9b/0n/V/2XwB/y/+s/6z++/vF/lfj6/2P8z+WPt6+hf+b/j/9X+z32D/yv+o/7v+7/6T/4/5////+z7wf+z7af29/8Hue/r5/8l883pTmAzdwjO/1JpSblIWMglC6lcfLIBaEEZW9tsSoKpM29nwzvWpUyfypfK20WVe7iTHXt/SUBsV5smZqxFDlC5ScZvhEqglO/jnW+5CtIW9D+BcoRkOd4t9PPLxG2PeQsN/Y/JNrBPd9bgxVe49Gev8Rs2DuT8TlzZowqVIkr7zyeO5tPWIdOx+eK7/T3HvsqHOKTYxLA5sWi2W1u2n/MfSKD9HRuqick9lTGqYgDyAxa1Vh0NLHXbpMzdj+ptmT7skP6P/UArbFOM/aoL23V2ZA22TkvpS+9WUXDU/MnpjsMbXkX1RKJaLKlNwoazHN9N0JMWfhH7Igq7m4pMDUBVFPKn1lycci6VfPRHNKakXE47nU3gNs8RL89dO6bOLmyzxGfaU35eFRXf6ioVVJe8i9/hwK366noS8Uh2Bqg173gCnbiUdJoOOTmrpWPjV1say1XUbjOc7i+ONAvQ+GhyawyJnL9vEPKRj2o+804x/hDhTk5+p45xk6HrsQwHNNLIyOowNhFQepVZ5LcgZMMW6+gkETtonve3NwnD32z+CBx/Y+SVvTFF2cdfud9Tl77mAzeUG/kPZacYfYjx8WSR+TtKDJ0cDF6bA+XUTl1DNfALqnV/dLTzdpUeKshmwDKVSjUgDx7VNWugE0bndh27SWt+166AQVGlVPLDw/11dnFNXO4vtZrGL8/r8/sIPh/HFhGMHARlEZ9eaJunsz1MXJOQgmbqOelSUqBwTPVeDe0vwLdp4AQ/Vx7F8HpsRLXDSolCtrrBglfQkyMX8bYDp18WkciLt65H3LHHLF90gDuh5aCE+FIJ8GbTOnCVtYAFYnCEfad/mowIIFF82C1coEbJSL8Z5ccgB5Q/rJvt93BmDNX97BBP/qTqGkCvtwyOeZHbu+R6UpWwG7Ji5HKCGvYCyttRYSxKLvNHZp3vtyuCQLjIUG5SO/k7ySL8neY+ogIisF1vQz+sP/9bCuV7DUhvRCNlzKckFgf4mNawODnbx6+fW2U5CGYXhnngnRD3xqqCNsuL6LpOgCBmhcx6KEYuHVN2EEX2oYJFXy1l/WYZXaVtZcAAP7/CMeh7tswefa4/XMBrb7PCSVRoWuSIFNceB0j70uvyKbNlB0t9lTr1GK3bQ3JH2xdYPv1w2DQAj4hTjNDWlpvYQyT4uR4FXX7XHecPPjf+XDOZOtfUP1milKsVct3b/LR9/yqTHVX4KtTz8VNw2mBeEDPc2M/raiw2CGkWeEv2QD8H56IOE+yHK8+pzeLDcAROGpswFUJ0ncHxhpfL4G84Ei7jFKPrfS/SBpk11rDDRXB5JT/5QUnGkp0jdcOu3EPL9OT5wCre/Tu7kYCVw3mCCBLAhaUgBwtn8ZGAAzs4DwtXuBKGFAInGvjtI58RtYv+VxOdRpy2ML/SaUYXrk4g1KlEzRpKbdCKykqX7We+OFZThp1u9Ffo1zlMuT45lfzlEgXho1QEUdMW18U2ClF0W3rOduzcty0fVrsmyGPTrkuscYwS+FG0Pxns3fTVkKjtpc4JRYYWJ2d4MlR52/SdcB48USQn5GNf74C0O811zd9k3xoctFB9joV+5YjUImcf5F1SLfq933CqEgBpedh0Pk2G65JTNCNr+LrvITPSSnSw8hrrM4IPFb50PMDw58Dh1+XDRDoTk55/p3gezzty/OlMO1z1pMMXvF7w4C1hb7zpnfEfxcvM9cJxYnfpMl9fgrcilCfy+BDbfFS6AiguvoMGqKORJvR6168QkKZTyQsTxiPe/P0Wnvbgc/SrkUI3qlBWGZljOA+cZHdDuOqOZcYGeCLdrnojH0N3Aqlx87p//BHDOeVUpRKuJNrSaQlHCM6HOhAQK0J38D0XqRm+ACuAqrMn7bQ4hhQAUeDFqLQ25YTsfaxSnfJi97oVMVWrKeobZsyPGIub4eW8e/TU8LNSpx49U3DdiQGhc/lQbSCdusrgvNTEhMSK25rjeDg1C+QWYBBmmAy1kNhq5siLAKJM+f96C7VIzv9RqOMh069/O25t3DtCpD2JooJo16JGLQau0TrGJ7oEYmFXEHIIiN0k/ZG1bs2Ij3KBfopf0GiDAevjj+oI4ECeROUpmRHawkt/F5g1EpWKcMS08TKS5yPeOWnE66kaV9IkpO8Ud9U0Pqj4ij78C/7R0PVfjpaVffjvVScY4SgRr5fDhAlFFM/ltSlvl6vgnoTLxQpJdCkt4RFgMBdO63H6p5OiajNO622yuq2hquiJpTMHiYdMLBkdUwyf/fdFbYuLdubmOyjgH3Xfu/BO8Uwuhpluy7OLHSFlMDgaM6cTCRGV6MyQxLEM9H0a7bEUWcv9DDPX8LJ4vl8zRD+ji81iZMzOU608S67pjI2ktJ3IqQJqmH7N/3mzlUCPNslLTLUy4oabauoXzIuTpLIEbWo8EX7mfyknCICVGAFDbdE/HtUJ+eSemlnHdG7GCrlYmd6VbQV7pjLpBJRJSs3sQxWWbHYkbDvOEAnn/4KgVPB5PcleD3/e++mz8rGc4ww7fa8grA2VHVWBHK/zWWAxg04BQp7YqDwfZNXFlsCOSXOXkXt61iEJ+enhHVIlrbHHhnOLIrv01TyE7nb6umQDIMuCNH/J5fT+8hYPVXS0P6BeReL14BedH0+nr3dKya//Mtx6Huum+iBlisjttcCbBpJ5N2Lj/j3MJ55BRSGFgeMA0SaHH/52b1Rnrx9qu0F/ijp4sNr6yVZ5Wd/IE2jRp8mqKwNLDYRyYObkLUeSMR0A1z9Y4dtxfKEWNjhqnEhj5eoMzipts5IMmcfuNIYhPH69G394H3fQrkD6fZXeyjWlWbwwuLI9/wmtLPUwWvVz+W37F8gMOLgL0CQbOFGjEEZNBG0hrpGK0HHR+mlvkqbH4YO4C95iVPDLWx7lJxMwBgszhG8JRHtuUS/AL2Ih7OcAsKO6K/SBuThSzFjLVV5J/kds+Bzs6EU6BVB9fxObJu5Trrw6nBfi65RDs1G15cAaxRZsy4OrmRrYjaW4K/ibtIXJJlLhzPWRmhf+P07bidx8ZiT/MQAVfpXbO23uxt4sQyDgsN8aJhtItOBpjHl3q4BDvpBAJaxZHhw9ZYYcCPA2cuFLzdiafbAY7lgwGeWGCu0FUeDCH7Lsvb25gQpHe2stjZMQXE01J/P36FJcBaiS/AY5HejOE4gbzql+KXGJgCg8TCX4noco2riB6YoSzKCvbqGsj3nepl8ExqTnSEf3sMVlrpaMqGXlym8JtavwI4qJPbM5/9vjmNofPCBsYLATR1DGbjY9hAakWeaTHQA8/eK2PuSNGF7jrg6PbONfgCMrOGeHAWpICK2s4HbOeSAEa69IEdUhd+OOr/uL0vLodS0F9B1jlXcXIv22N1zgrCDALGSnlkHV5l8vI35Q7vmWtoNEtoQ4SzJ46D2nDEDhveHBNdyIU8axQNc7/vegGALr1jJ8ngn+Z9jkTiEnNhuxDuQ1Ya4td1XcNOYDpkftlxPi+UuH27Q0BX6i3l9eE1NzJDimubsuRgbSOYK5QMnQBjYgoiIO0WHmIYyW/LaSm4KyJO7zYvHDDqOFXSMlMUwhVJLjMvo5ii2Ja42loYImZLxamSq1XAOivpCZ82GBtttmm7A8vmvjkReuQACg1jSj76FzmabPukRu6hbxrJFNb83uJz28z+l0o4BO5lQxFI9/8ca1CC1rPaKCumDuf6qXLIuijqn4pnK6cYHOQ5Me5Om65ESiLmVMtEoklw9oObml9Bj09jEXAb0qer2OwLdADkUVLbzmGlNN9+Q/k+5htlMzC52WKRKlnwVQd26vZ1AnhAFRCtgRku2IHzufbYCSSX5dxXc9ELSdgzDUVN0gmaoKaQRx3qwkrUfDiK1g8N7FfFKvzZOthrzW1GmFDB6ReLYCvo9FY0CAWb4bKSkK0bVZfACF8u4cm2zdlYZdNGHqIMd9O3gib5e6rIqTULXCmTEBoW0fptFd1zC6p2jzJGZZbO6v4Uej2dI+sT+jUH2wqqs6b0X91mNAEGYwOrV/VCETYL/7jB76AfH1vANHlwqdb5Or4issyqehgNpmrHsWwnyoCFOYHN7LqhjuQvcsCy52Q4zBffArilmGLS14x5CVtpQH4i6mwTQDH7RYgkzhuwhPk239+zT5zMJKgdGxIUr1DtzABOLnD4MXj5STqHaxX0QA3vX9EvC3snpli+WKcaaudnQ+Cvvpnb5nXjvhsXAvoRnYkM0bei7mdKvk/3GVlsFdTMlOrsX4VyoLQ7KxFReB+v5Br6nrnlWiPhtbY0ciwRu3YrEGG6v0ODbcNKFvac5iwIvu+TARDEB5GqnMMyBMMW+AJCc42NlV7/Rj5fItOzgyA2aaAHGVviQB+JafiIEqhqnD92GCXVvB18CEvk4HLm+gPVBVW3wtTgj3TpjKUBOOy9jc8X3Hl+azdXfXvw+FaR2fkZved22fAuIq1TUU7H6TZKrv1o0hxRK/3GVJkN6+iVYYmk1VG95fmBuSGmSCMSX7i4AQCl00c4xcxlfUVVliK6KxtpBzIghQGlLINm0h59rCVgOYxAeHdUHXfp2zxRCLY6CwxFeHBZo2tBt/uf1BDy0omLlJ2vuVQ9DAyweIV41WnPQgxj0u4Bc4nyrezN+DgX6LQWxbABk8McST+lBylWlfpKZgNqNAZwe3GEEjv7DoqYWZf4q5SCDn0XrtTJeqq7+HYqEup32LON0cYmsJkBF2ftMo1PmbBDWBt4Fqgb3sJQCak4bLHEPtE4iq50sc/sR0gvzD9Q0HYsJW5U55V4zp1fKSg+skfqm+StYbm0FzgrtZwxvpd+e8GXu0QpvTeYcJi147FGWBrdmA8g0JQhMFznFyYJd8eHH3+Jzu1PujU+PgICBhQb3XOlmuYZGLyAhcXQZx2Ko+k1DeWyQyyurmxEZKKAkMdsDYuYomtHk+9SU8JDB3UA/Jhmzo4mTiDataAWhm/MBjjz8oVAidL964zJOM+czH3o0nd2zowTC+RTzY0fqlyi0Zqhkz+lZJ0XjE2KHkVUU4qBm3bshe1E/86Zzw5pNKJ3TvZFdxUdMDtvbi+7BDLriK4KK4Q6qVdo3e/45g30Vh9nB7wvJaTY6SVULIoAZQE+TG4ohk4zzrxrbsUHFihAE+YrOzABHbFdBP4PzlvHKP109OnZ16P+C2OwfQMaRF8Ndkps1vxElUhlEvTptsk+lyBqQ66SDzLB7zluSv88BfU8qdDrO/IfRf0Bh4DgjB/JiM+FYbIZIm9fhJ+8FtzoEDMo9i3UfEJSVhBeGV6zYQ6Z4+HkFJub5WX0g2bXxpJ4SNrBk43EHfKPiZPBmH0Sabc5yqKN2TrboRV64mQKiQnSDfhY7XKd/0WX0dm388kAbnqT8yuENBI3aw9350pGAz0W/VD3FNy4MREt+Cg8EsKp2MlX+IHrrhplrCnhNyhSuG6yzWRYk90wpvyS1Iwy8NHqaXNh50B1hMli3qWYV4+iZMIf8PKbQPSTidbnmu+jUuazOci6JDh8KjhOnpeH2Em37sgX+RX4jlAB+cMbi6H0WJMYiVgD1SeZacxqWG/D+h93aKxScyJUT+iRqeRTWQN32bna68CxdQuI7zLXm4R50JntXlXn/xkfgZulGpIXgNtNg0RO4vAGAOd4gOqwJ+ewtDHwv1lGSuzVSvsz9fbFPqf9ohr/wOHz7+YytF5qMDfPd6VtzJ1kzrviJ2cH+/MY81KsGAl+K5TVe/kLCwIQgmavIc3736nlbKIwICABYN8VVzoeo+kr3VQoTkd/v2HWsShBSOs76+WAMCQFBO7ktS3AgJKi4es+ZoFao0EkJw2nNy/K62PmGT+UB/G7J3B8c7MivORbP79MQx7zqocFIV9hCsU/xJ6RosRY4UbafAWWTc5xLC2lxgORNGT3hqC4V+OGnDuNfNNS7BxOx+7Dc46BRdXXGcdKqlxhUCHMGRdmqFIL5anuWoosJv0r5DuEbaT1/3hMrdF4hMLBG4mjgajWu+40btftDqMi7AGNexwoJehqaXhRNid708+ibfsDvUknwn3JhLFlxb3sluollVRSXwHK/SEYCfvmlFaOhSXl7tpqZ1+8+wp/s4RikGhge8Dp5Gpr7ANNzVPjFH6DjP7JM/Mo/asCEwVb8NM8PexJX63CqFEEDijRZfy312jaaQTdxrChyHOhIRSQe/Hyxk+YTIsWN+I2irvF5ndGrK19iRwORs1jSlej6IogM3aDHKcwKu24b99g4U6H4wxnO3i9M/Klw6CK3156j64VRvBrdZiEcuJFspCDXlCNCxdx9+P28o6EbHg4p+wFKRwcqbn/FhOMLFzR46baWI7mjDkLfYM0DtCFeG9OYuK7bxpiUgPp+PqcDxJnB3jxPDRVCKnlUT1qSEGLfJK05kPR6Tng3SHRBP+fe2qEolwS3kVIVw/YK/C29oeLQmehfzT5bsCkDZWHVooSjS5LyyDEtjphYbARrtbeNKQ8UBYs18eVqFYPLfee0jY3IaySKMY9cHoIM93RWtVPjK7If5sscabfWxbycRWfw8Je3JZE05SDYrQ5XWlxD2I0ICXHRIlzsF7Ix48PBBdiWD9W8KffRkLNy4jrWFnadKL8LALXE908degGlKKyjGtmt6suF20OsKoMoDYRq6dpEO2oU1yCn221iLuvwhlV7xZZnqD4ilTAOyv95XLaCwKm5LRSniTR4Ve4PT1UcGY3RnWgJ4x+vvxPAJR8dFwSMGP7mj9A6FXtGOaZwZq0gOBdCrjJHogm5Roxe4nOMP6fKinA7it9OaVutZXMIFNxPS2hFk3aX1hyjcVvGZX986iGn/8ZaDnx8JeFkw9g5Ze8BfFlbjbnQbvAVRoSx5idY7ILc7k8qm2anzMlINpTPrZIuLqOvObOVSTiKCS/an5zJ6fSMKlpESd7u+pSE/v9JMlHDOJwqs8Twpdhqp88hmB7uI0OLqZoWYcdETcWJJIll/3tdVmmHfSA9KT+YQqSJpusJ/WDXLUhljR11GQBvPS9O41oPO/TxurZE48BS2js+7kfVLSzFsdNyNfhCvJKEoc0iLoLCqY5DddiUzKGnyJyAhhto235qDVIBi+opiNuGuKP1ew4b+YjLdwOTETHnF2ylAkGOVKdAoZeUhW3mcfS/l/g5NwgaTStu6DJA5Vploj2aYWWszpnGSUc5WXVHAS+jlOp3n3TEWDhUq57o6/7OM4SUAlU65dN+3RzJYf07qqoq+67M5/SwAemxPHTBIxMNMJKt4cwD0z3yvw5GC+pG+kAvrjlGLEgtc6Kk79PjUcf2UZ72sDhN8pQFcMQwr7p8VY5IRPiqOYuttfPYCS3ep1vriTtrBwYrebNoOAmEgsNvo5m/4GfwE8L8IzkzaQZ3TUTt0fzuKMdF+sbPwe5Z6UIgc9hxCYbhySdsuyVlXRKuBBdUsnZFTfXHiYs4k3+hgUbqWFlSkaAHMUaRjBoehYwRu7eG+K5PWpBHy/+w9Kn0L08nMomXimPH+XmEU9vtK0lf10qziURkK/XKse4SNjvW5wZS6knl6XvC6024eBNm4tciWYr1QF55u/Jup4s/2Cx+UTyArpe4wbOksoeUv9diREBXn/WfXq3ZhoXxdqcYfxS0QjL4uZ07pxJy16ieCFUo1M23Txi4dF8Wx26OHkdBSrdV4anFSqM1nUB1EZBXu2WwSHfsRRMjnkMrOwLJiaVLXN0bPUP5+zcPRCJjgZt0biPhvO5xJ9pIqNwEwhKOye0WhKHa9BFxWN1MSq23bPLKs1rdtXP83KY9KQGzIG2RQ5KFK8fx7jkbHFyEUzfUTGK9x6TQh1S5e22RSEAbN7jg6zdTpY4GIFYKcw0731k6YswyertlV6YfxzeSl+pIBrYCubhWCHAf6lCBT8Sz0EKiL2c6rBZXp9nbpqVG/tPcp3UD6okZ4FTgM4BYN13QHEExeI4qzhVtcyKejOa7kPxCh6Owqc6OZzkcD7h/u5bbeskdkK/Z52ILPNOETQhPLm/EGT1aJzL5yi/hGZKRnr3OFvbqtvms6LuADDfA/dR20RFGR882LAniN5MMP0cNtEVkolRejrGwPfth9IZesi1zCZwRZJaaWQceYA+nJnyn/O4ifLwAXAMptY/la6Ijp+YpFEf5751QdOngaHfWKDwvv45Zq4UPhDgnT1SjZmAhzwpOffy+dCaaIoXgsZ35NfP1+YjzOHVjHEyDhcfqsEF2ZMlb7WOVLJ8L3xeZH/dDXyEONSSBOY/iUumeTYrXNi216jdzmzGLpUiT+5ckJrr05B7YH+pv6DQ9hZLsZLXhXT77L8DzO1TdXgdfIMy3/yDv+mA8hc+qgjyNftgvGOqlUx8oqynYp/lBdGavvw2ma3BBOOHHsNjF4eoa2Iag96Ofksodr1f3T/OrmHCjovPx6AcStb/050U57kX/aPUbuZXh/ofR3tWSOv6AgxwfgC9+X7p+P1ftNYOo8MzO+ArEeGNsUNmZHWV/lSORDX/4Ov0R+lxnvsk3DWPq85cmxl3Phx7ePOlCEBVdlWslHzO4o4rqrSR3tGRgUvEY9QM28KD9i0LaAhwLsbTXHf/5i+s5CdtN7YJDm2Brf1xXJPLBYjN+Gd11/Pz66OusKUtfh9CrwADE2KApF0ms0a++vQEVm4FoTsNOtLy+6GpFCqhJdPNqQwwN87vo1ugDOtCuDPEahfy+5Ir6JReTDyvjKulT8F2BtTBJc6WZrogd++5ZQho8f7Yh4EjHD7MYZD0MaBOPRTW7QXhGb3CqvUfAvMMunt2VuI1I3AuRhArfwRoH5zdVIg3LTgwY6QFFcsg8yPe1fzOFGJ524H0LqnjFsFHqgYlEjP/mvvh/p5MGbTu1oDgfDU0dV9D8rzb8uZHgWQaLoqJhraezq1VSnqvOLVaja/vRm6QdBxpfts2TX1QyuADnkAUt+VAK1UX+KitM849FcwpsdD1XXeg07SVxQnVQTrYpSyhjhJCUuo2d33Tj/GnhZbQ/D2Mps6DDwS81aQnQyi9MFnuq2lc4v2e8Cv06agDYl2AtQJLlDDUfk614yxBsOfDtqJVb9SvluCFTMcXaMddyA48WuHyDKK4W1QPEpuLYSzTOUh0o2C+ox3iQwFjDCCLIBpvDWL8j/CGn6L0lbpXklzEgTMn/htlRPf/lkm3vvsBpMg75aQXu0KPj/LJj/dJ9FAlAPZ+rusM4mYBQ0UKtqThQKwT1bF6hh9Iq/A/L+2dW5xd++8sSvNrw25CpX0RR/otcou28LCjyFDHx41B9Yh3rTSb9QKnESFhkJx8wt1m+nLvGDNSsDizI0dQUI4nVI/6yEwGVUGptsq1iWPwCaEdENTOoTKDbxMmvJS0fYUMH/566o02/FZRwSAGmmb4JroaeHKe4qSkJTuYnkoGBxs2u/IoOxtZQ3Z8a9eQluETP+o6OqnAwYCXnp0dMLMN+9PFz3z+rMhDX+vVMFlxXCym7updxBQiDhLC+flWJpcOPkKtmQOOa7wVKfBGYJSz61oWwFhQpWskj/1G4TtDwM11qI0/pGNO4Hi5BomeV8rk4zbVY14ggW7ALwFb8GV6oFARkAUrSuejwCe4eqJyKJE2xlrtW19qJDSXUkbtNqL68vGaYLldwp7bKVIWujVT5QD1yusi1fvHUTjKtnjIzAvPnbi/s54U0JoI7TNIITCThFw8tnBWdEPDuDid70i7kPNKPaPVWZ4fFCEq9V0xC0Pxdu06CeZAUUAZxm3stb0m+frzgsO9+GYClftuQpp6Ns1VJMFBJEGNxY/JjS+o3BIMcBK97YOZJ7WQpKBJ/9KOzFsSuOFOtlNx0sIDvV/WdPy2R4a/mhRiH3O9+9AcSYxEoLz/km8lWDRUaFchuvb3EZn+/UMM9ihEzP8t+w9nJ7yx3XuqJI3eOaLT3XlQBYVcchDXi9aNAim66CzcWj2I06zxtQVaHjhWisbAUJzpIpCwHHxib7qQCjDDCwnsTukqmboT9aPnsKAfttIj+OUCkMcPNZ7zyfkZTS3ujeRJpkWdGHuUC6SnQfSorn6XnudlMGvVuTYQK9xWDGCkvsQeQl1K7ooV3PHHSXBroA2j7zaMO8xh3ayIe4E/LK+l+F+c5p2D2H1xfm7BiUvJnElZzUQJ3yyNQkQ0PO2jwq/3DB4UTpzyTYXYQGmBLQUinEt0RE7Z8Xn2i4yhllvyibuFXYZQT+W+wjztLzXilOty9+ISGHEmTViNvzROIpVi39w1oLzXyOw794jV/kHvVsjudAtN+pVUM11B4X5D6GBmM78YIyz45cU046bU1YDiBmOwoh3A88F6l3jR6T0WNLnPEvUM7UVYmzdu2x/A7B+gAX5uhOLbtat3d1Tj0JRAJUKfqS1+BF4YKcdc9RaDP7mgiOfE5/AUOfyftHX/SqwFE93mkYjILO4o6qsjycIbYG6ecbKt198AclqT12ndv6716lHWIxo34hjVnJ2KG0816LESkM7jNC6LeUspXWmKZn1ergXfU0QoiSNR2AsBFQrP2FSLAdpLi2/cEHXBcDNOQQ8ea+SMTI+77iA2Skojfm6mdbhBEtIWJf87L1Z/mfJEqMNx7vrXytZIAWHZu8YH+h7NS/aBCztv+yXTwnkRMEWpM/wzNK2DP39otzg2fvbpx8z9nUVkCPXcMu1dnfI5roUxN/eMwA3DJRVVf2VSklFy2qJWUcehaox2TWoFHBWqjwa2e2Hjo146Iicp9hqETm9fuTlQWSgqHwDg+Cov0mgkvEhUkrkiiqlvAAq/cWAgLOXIl/ELaHiN7rwZsXMFCPi84921PHXrgvdksxF8v4kSSIx4L0oJ5G2BRiEfLuSDNiwNnkxvrqH4AmBs8MhoobxYKg7qczDqrtVcGOWvpcAWkwXY6iXCpBwjgu5clipj+1Yz6lNI7sz8K4EbEH11seXDlCOTCuEhUjYE0kTOGC1GvHeiabWNQkU9iSPlFg9lAHHvIfa34eNJ3caPCLSPK6zPFTwgUzd8k4GCfVekYk4MRn6ueQLccJ1LL0HOHCU7c/qOxRf3bC5uTLn2QNDn9dU+liIIDukeulJPD42d8CbP5oT6KMGbM4ARhBCtI3jJ+fNjFOCVbxdlhnobSBTcSkilUj0lvimHlp62AK8zZ9dLS3zBc+T2KvCh/2ZpmkY2sRsebnRIN5FhnDwRH1SrilA/Sr8a6g/y1bPU2CyHJi4V+PzXu28+owf5r+tpwurpigQ58aqCUk4Xaf4ARpyqOrKt5IrEI4WRsJUzAxLV5wycxk0EYUl6CSwjnTJNC90rZileMjLDMDZ4L6C4O/g58WNiKpkX91lXISZy8yCWjvZeq1RGxR6TJsTEVI5nfIztOpEBHt2sJ9yeaKR+HgZRm2QCIWmvHaE+JLlkmWR82U5ei6czi9Q3S0X7IErRUQDixlb6Kcvz9f17drt20DeCVt/uHYeSDNvx83nF0dm7aH5M1b6VFONNCP0PD712G76l+wqGgVJW558b+s3k1kbo5odnvX4xoslHStfdeqtc6oi/ec2cocDii7OtHbc8XEbMTExJHNMgd9PRCzBKzpobTAWBBc6+L+kLJNnJKcyy+BwdJ99YieHTk1MQslgjL+LX9skUM5WorNNyvYbNjri9YN7pM/Lt5wX6lJoKgxOWDYt+uaC+H8Pc4nosRp3yo/ZcIPOMi+yGh3gNSSB2hqh78a7cGpMu8ztzstpVjmWNjpnni/yjtaanM3R2bM7KM/TwccNIgBWrFArIrT/4hfBoEOjpcfM7HWq926JO+AvqIL3ehNTEQlIC6mrgMBteVPB+fYCZu2D/ZgAzgH+7KX/XaTPXqU35LmWdB8KZBAd4y3VGqc+cZT3DWW3YWi1OTu5AmGrz8mm4eiejb7Y2sKQKt4yFj50RiDbAF17ukfHPgs+XPf1cNj08algZXvePiBUCYcyfzPYzd8be0KSN+h8B7VKO/xdkLJpZ5o4MtXpqenEmCko9yDs6IkFCsDUiGU1vf5mSu6ZUk2HPSkvqPZQu7aO0NkpmtKwUgyk5xo9LGkIz8D4ZLo/0+prpjFjx21Qri4/q8xj60ud/F88dANPJjm0JMWgHtfpJHcMks3Kx9yIEkp4lZEjPaPil80X3ohS5Wkm29sBqdejd6qAysNQBJHvI+6RqfBLnDL3Dhsxt2jPqFCRpHP6l4GVRbNOV+NtljTiypi6TUKtxJdm7sSdcG3utGZr8WoJpU2jXs1+batBoRtfFGmu4EaN04FaHo9jJfntgdEPjnWpt4OLJF7mWUncjkOwXQ4lwd+cez9FDhylFWtN2Wpl0/xfrh5d0xb9CXqNzQ4TsMhp8IMn2Di81h+lT+4JJiphUSduTpc6/Rfi+5OFLqkGhZHU3P9bxQsACZUM2k1mIDA9cyVdrHJLWhKqkRxYsk9Syz7EnZFbxdri4OO5+jDk/fORxJgInNzR1uCJAmPCk8B/cAQvxZf/rYosqv5MyzPryee9eyos6SAp3QqvbObcmiBfUTeIs5s/OtfolbxyQt0D0BrKzvEbxh6BUmLgzoiTlSC6p+zlgnZdYQCOC6f+GCNJ8Ra2pB542mqMiDe1R6QCa9ssM7gx5OkHX8J9CXWbl+x12qa1DXKcJctl09gx7k7lweG8U9YhridG+/MY+PVVlrzy8Ehe+nq9n63wBoFpl9dzwSe57mW6h7wmD7lUlr47y7PZQDBdFZs1Lpbpj4SwcFTv20yBm2JI0i1Zd0zzL8LtGkqNio8KZR/UjgmcljFTy5MNZ5GWS9ezNcCOgnYwMGlCPf8V5SutjzUmyVcjW1A3xPHLjNVaYlx9h56H8O1sD4DN+/i+1b64oI6Sc6HFI7AM0HdqqDY0+xRa1YTkqsTVsT9J2Nu7c0/c4/UKL+vPf99593jewtFhGQ4gZz1+pQmWNX6c/dUEdGM3GT2uL669Y4/K8+js42KhDdXe4EmfsQYZcecRGPjjoZua5Nk32yU4psZVJ1IhlUzGSOEJsyhWKYv48UVKVoslzjzd9VfZGgMzLtOZTIES3ccUJv2m0yIx0uPu3bhE3VZjDx/Lk9r29xEZ6sdwdBwzQqBRFJquGQqPlUNqqcGJn+C6OHY6nPMr2+3g7gjGPK8zmJ7r5+jZ433NE4eLsV93EXUxJ1qholsQMJLAdY4cCY5MUIqq0Q+w+vxv6U1QEXd0T9kmkG/nXfEqwCvkkaKG4BBYH5/P4puxl5kk7MMC8+q1OF9Ju6TBBbHe9UNEXAd6yePhquC1TaWMymsY9MEDu//sEyyxVcuylXY8bOqelFTJ7TxfPQXT19NAwiJ0KOfzUAiCBz/xHeJ8tP8du7clQmHV6nhuBNxVVNSqbZu4DCGOSHmnGmraGx7MS+nHY8dITadaeqdl6JYzig2PF0hTKWDebSA+VogcnD9LpenlWEpw7nn9h4aK6iVBy8D73NTMRUZuSJ9MECdE6GepyrS9SBEN9RktbdhXlHbHnjQRwwMkuIj5A2DUqpBoNYM418ZWrc07IvM7il/1ehBoAP6LSrj2seO3IrPQXBw9vO9Lv09pxXcbqAyMCltH3q0vH8/1aYQOd65f1as5xFJaX5LT1R8Wgzq6hISn4b1zebym7i4E4Hojz+m1XGDt1m8jMl1JxdNurzRAo1xLvS58ExHjbTzl6bP1xm4itYe0hObuLO9EsMZZdRtyGCfpCVFWwE5rvZtOisIOqWlcr9W8r9kqwr3jmsfvyMQrsRCZjQgCZJxUPcPpavgwkNqX/jNZUecY3pKzeKulM421Xqai6v5F8FHwz3Iqayv8FJty0zqB2ZhmEaCJB2Vw7RgM7Mt7JKuw9LZO6yianwKvlFnpSHuQbJl3+Wvk4WYbO85gVnHIlutH6CqwYT5SUQfUcMiP64mUEvPwKMpff9rPXpiWvjrEj3mRuy/NO6r3yQtS2PjOsFFLe0rH3MCE1fGjcVjj3CRmi1vrYc8JVq3Ql7zMa0YPqILwGZxOb/Pb9CP5pfHFtVqgLylTvL5YrbYQG1pNUywlLRE5CAWl7bZ6QMDhuipnh7JXnLGieqw/DzF7QnIsfqHB5Vh7mCatLety7jmiWoYUmUyxTLH/GI7WfYexq5IHcrEbeDgMElBi1ObbKFLFJRdehTmR8mfAdUenT3MP7i9IE4UEiMHJc7mrBrHxXsBk55vUjnadjGruCBDDmo4YmbFDFg+MKHjw/2Tumn5MxxjDV9rOwRLFbhfcduLugPQZ/AROVYCJN3raUzZLyboKiEfdessvlljtDM00k+8gMWk4/l03bO5ezidDIV2QTKaPbIWpqzXis4StExSvn5M33NWeR8qiBS9bGUVER3l0iyM9/HhqwaWV4huuJ8nlMq/jw+9qmHpXwnEEtww1I1igoLAqwh5JqK0Ta0HWlll8Ymg+IXQg0c6FMhBImpiEIZ6BqfH4yqE066qRKHaPY3HdTmaAyH0awnmUc5JDkCHinZkh74glArmhDOt/gLAJChx/dSdXuT+p3LSj7Sx4jtq2Of6c0ipPPn4RzrsWuMfJZRLENnpfFYu5sx053Q2NU0DEbu5rImRi0v181sVRpeJreIFLnvtELbhtfoVyzPgHqfq1WkIM6iwiDLtXgkqXsx4QmSoGid/SbZX8IPI6fJ9Lj/64STgvwC/dIfmTHLVXDFpJmiZPXwEew50jrQaal9B2D+hyH3vGjokIp7y7F6uhWnbE9+kMEEgK11QCN6w5avtQPGJtdtDQKUWq2mgAAOHaInF/bC84rlA3ZrzfEmzzVj5yStugeeVx0hcOzjh2/Ull/WCkdh0VOrw8Kc7BHlMdb+jl1Sj5mNkQuUR6HIBAYms9WZSbjZyWM8smCgEvBQ3+NJtgJdrEFKBtM0HjaUlOv0gj8gyY8jW7U6/313dIek4rFveyewOVthzvQWAqDQAORTNQjlbfklmK89+tR+LRO91JteSfT1VkLiFwAtBEzavg7i7kVi7Fa08iF3ss2d2vaKIeazQhURbiL4V2T9CaG5b0GYNUivmmZX9YS3weBE2zghxOFEZcoqrL2VQparY1+0zKPynlTL4/BChJye2QWQA7x9UEgQ8US5o3CGR0e3BP/NpuROH3bh5Sw2wpmpDeWlXhPBS3X/E+npSVWy0TljADMdqWggCXFNqWlbXrCNsgABMxYHOTUXLs88Do1vnbZ5wksGbmmS1VKTUak9lGBjW64wyh5Z3AXqcj4BfBWaY0r4wSrO5KYyWnh9INAbCYHKAJmQZ+wEnNAXFSLjUYUlyDXh/T9mQZK9imFXgUuO7c6QPEB1Um5lOKszNvM2jbRw7PjVJJKuI19U7bO0wLzUod4mZ6jsU5jOAGsp1equcWvaYF0NZ5K74PddQ0aiNtpVJSypgcRFPLVqkt5Lg6wuxusu6XoJJvTxPuE/t/FowIPwoEXSJKTE1CV6qBTL3KOzgScsi4d/y4QRAtxFZltdrfRcopQfct0eoMSe1IpC6KqtelOLcwTMvbzdKkuIoQT5XxJW0Wq1jLrQ/LjAxmWFQZonx3KSykvBk4KKcMae0fxMeQrqJRGos2m1CQ4j43TCoGnFIbUCs3zZirw2xShvrgiPfuKnwj4VseYpKIu1ezVQQtSahhoJYoEuViamz4p8ssyrQuGVuttr3Us5g6L3mYIoH+7eM5rFqRN+TFbAMc9WpOzTrphgRZDXIZdFP0HuqLdqSDyaLUDq14zpvx1v9faJHxf9nXCiHQVWI79OkU6FGfquKHomXXOl+b2xvF9FBNg889qwEBmrexMhQJ/leAYIgJRRBeFa+AFAm8K6K5+ivXOjobecI68C5S55XkCOt/3hFC9MgCqr/fygF3drOViXJuAf9gcKbtc4j+qbqnHeJ3vV28AqsfjWIvnFBtXjo5ahuuAe0JK6S6R6yXSOXsRxse9nz4GXwXpPT+kX95KaUem1wio2H5Zmy/ONc5xd3lnuFsfzLMBhnTTB405Gax5uzRhDUQBeephvci6iLx+eC1qx0fsWJwuG+qDaftaUnRrsMvHtO/U65TS/3Bj1LuR2fnjck4m+IKTRm7WNsCIvyRAg86T9AGp4BS/6IRG9eSMD7PlOwovWe+aw3uJ97sJUUQyYJtycpXO4nDPFipSSV6RtxFZwQ1Vgj7ntAp2l9FA+7aKdTJRUCl7jZiYut+UBteV8fIJkrq+MWhOrTcCrexStCbtjwRIM5pY9SKzCceKCvKZF2QcMEf6LEm3qpFWRSJRSRqUQ8X5AJwaE+A8F7mpsdwe86e2OONu/L8dvXCHH8u1XhkLaj9r5mgKlW+TDNYitIwM0Khis3YwBsxyrBmF8e23fvALvVCkHfOS7Vv/YyHgjBbZb4TM6XvTwoSE4wqZWwX+q35XxOD0xTviOOQTZwRfcMIKH5VE+gQpjxdg30gCPPvK2aVLzpGadvHTQQffvXKqOaL8kYzTBVUkrzIDWLqyNw3EhL1sQ3Fa1v9mORQMjiJQJz9gihBluclO3ca8iQgp8sQ2qGeUe0TUhQYfqUEKjqHw4noPCR4HKDGc7sdG5I4r/qaxcRcoQ528vwsHhqkVvF6taj11WysvW9t+HXSkEfBJ3Z0lf/33XV4MiwvlyX5HJ62VKvgFrPn/sluoJMdpWbDWld8Lca20s1l9N5xUZMcpFh0OZMwgws+87woKz/0Er0Y205O10+bWHUdz67/v0NsOzfLJXvZyp1yA2NtUQm+huf5LCa0W/bkCSXbGhJ/cYR+myFLRmnBCsF2UPEYDH3FTZoDbzon8pgXCeuY0tb/IOKj+jMsYexV9nzctXEeZB+VocUps+DTZld/ZwyzRFInf1GHuULN0crp9EpV+T0DWCZAJD8Ggi47KAg5bGmE43M8Us6qOx9FXUg1fQ3cI7z2av7jo8F8O+5JogUmdn8UmjBPQw5/R5NmLvK2ikQNtPGKPhiCiC0a1lYAtcYDLh4peKKLhMAR5LdzgOsROmCX/GLDzxIER2PyJ+VmZNqxTeVIOqrGsqWgEVY0R10V5toUhsSCEU65prj1NWxD3VmYok2eubJeDgZv+jXcME2v4mz+K4lt6QfJyPqZRRF7V2t1nNrAav9kgstbMHpoAfDy8hPvNYz8MlRSV3uZ7LZTVQWeUlFOIBXfzMszmeiAhJE9GfNK2di9kPzPCV5KltMzyPX+iVVX1OOYnasmLsbZ3RyJ9otCaDBE/BQSW1duDurdWHpC6ttXOq5qjaQb6hwUgBvJuzLftnmwjAPkg/LHR/jKKPGw1YyZVEZjVq75KWNx1SIGLlJJBq9uQSQg77PCYhgAAlDSXLe62xXOlmJiTwslxvQNJfwHTSHwikjDm1d6HfOnrLDgCriQ7ToAvjcbA18ihO2xoNAyiBzfWv5R3KTH7wvldpxK3iswatoDQ0PVjOViiVa/E2yxTtmN2mNdmP/c8Pria5L23AD4k9CfIwh67meZKMEcPUqPlNGaNNZSzvt/NyRJY5wO2NhPjtOrlh442+8lXqt0x9N7utu5ARI3ipx6fhga4YZ5Bbsd8PNn21JgkgvKW/Ajeo6NsoyjGBEZUumuW1/1wB9BcgDOQnWTsmM5yGjCqbh0RLMgk8XEC+E02O+oIjknDe8O3D7S5EGJYb8/gvoUxG2+Da5xfbJOWC/F/EduQHfCHD/e2EbN7TrVHdmHxFnY/bB39tYYZw9kgN6DjgsJ3qnw43xgMy1vQGXgLxvK+mu526deCk66u9nD3zR+M7ayG15os+IZjlC8z/K2kMXmlJ816uzUdpFPw9NAsZJSU6UnlOdvwFVnEL+vV30LeshJX24DDIqKse+k7yMjgr+a44n+2Z3Ne+aTJiCfSbKO+l6RoD1duRK4a7DyQGHXnRVMzrL7WCTCznQ1bjeqP0paDmGrqp+ID2TAgAM0NB8YD7a0ZbsGkqA1i6RHAzK7ur7OGfyhgGMLEwE1POGSNKGACBJFfXR5N5AO4OBTSvO2wQKf0QHCkez5OAjFRlnV7nshDyn0bwmEsMg0B6e3IFxrQ3jJmi1NOvq4X8iPbUDIAOen+9Y/z7DxGq+qu26kSP06Z6iBkfAFIDkpKit3cz6A7Tn1Hs9mrBvAJ+WziFAeYZXvneA/g/BR/ZHyAYMtOJbiBQAAAA",
	prophet: "data:image/webp;base64,UklGRnAyAABXRUJQVlA4IGQyAACwiwCdASrIAMoAPlkkjkSjoiEYK+4QOAWEtgBo2lzk5+980/j/ri9ifef1n7Mer3q7y1ucv+n/ifzM+av+V/4vsp/sn+g/6PuFfqr+tvro/sz7t/3X9Qv9R/vX/T/y/vAf8T/k/6P3X/2X/Y/tL8Af82/xP/y9dP2Qv3d9g39s///7P//a/cD4TP7D/wP20+Bv9nv/j7AH//9sz+AdRP19/r3ox8HPxXhL+PfPP3X8pP7f7VONvrr/2/8j6kfyH7i/ov75/if+t/fPnL/Gf8fwV+Gn9h9ynyC/j38t/xf9v/bb/Cfut7nuxi2P/M/631BfY/6R/mv8F/lf+r/evTZ/4PQT7D/7n7LPsA/mv9U/2v98/dL+4f/////fH+2/4/i3/cv+D+2PwA/zb+zf7n/Hflv9Nn9D/2v8d/qv239sv0L/1/8j8A38v/q3+5/vn+e/+n+p////s+7D/3e3/9sf/57p/7Ef/FxsRbLxpfZjMfF+nBcAntjRvsPvvYsVfYHQrS96ggdXrtcF66TFExPo/9Bgz66KTQCzUe1Zz46vLLa0qaKIIYXERc6R8C/1HqYMNDco7W6hoK14Dc13LWwbgAbytQ8XM1Ncu6M6t6v556p73hfW68V5XHOEbFwmHfQzxTjfoEIYA+umPf4qnqfLHgXGcHUQ7CyqihwyMgNaaXw0rhpPFilEnUN44Ezx+zoDmu/8xtntXcCWYRldLdu+/Qb/1Gxz3C6uFcmUCDFylKSdH1P9q8C1sLyFIlwndEMaAW1MgJM8YN6RNSaR/OfYA7k/vBKuwKSqlQetxoeOLhbCpn3LBr1VUyMxx8vAmQ+cT5m+4fQlm8yjrXHhyiZN3rcoFtNOROCw8GSeEs+1neCOtP5eGbdKKBiEOqZTRNQ9DYpS1IldJPamhleZjCcUUzF/IbSatFPbO3/aZB52Uin+4ALgcQyilR2e/f4yTYoXIiS1TY37Y1QQj7BC5hNjRrsA0tcDet5w3mvB41E8z07mIMEr1HdXE2cmpYBmKKQfwVooiP+pc6BdOhsR0yA4NvfEs6Rv+JCyT+ZslcJ3JI36vVTbmCohWJk2pWBDjhF1g2EzLU+BC/9Kg1L3iBYOOSiKf/6xgkc9xqqbkTp3Li55HHh239Ild3Ozeo//K+ZckzJfFs49OhIcjtLYKsmOHeJGga0L8R1mlb2Mwd39NN0dHfval7o+iigaj+/SPOBAtK+5lL3y01JXYUv8fG3Ga5FxY6Vz5GxuaLTPJbvwXtvRXyplffWfVh1S63jLMpKlhWIM5Jv6ifKXhpwy5kKgjCSO+Qp4GWe0dlFvuFYLcbv530e0iCHTuuZgGCTYRmq3InfCTK80VqVQoBylkAGWnkYFvv6RTDWircAbxENtE5aVP50s0rgKr4D31JpwMy4NlzY/8/2j+vnF8zHa//+m7VfR1wRqKPlSj4MBYNm+ITkJE8/08E7U7LYDrPORXfPG6HTqKHC/JP6OGOX1b7i0UdaoqG/gAP7+B7I9f5+uBsj3Z0BBWmw4m53F4hIw4nTJbIHmh7BBCT8pp9qYVg+t0GhSF0GMpLjB/ObDJPgrKMDn/+qStUKlMA1tjjAG56L7LSM9RjCMVweqy8IfBTsJMBiW7XWOP8qNKbpm/oJGlJiVHwgw+1jdaahlqoxOB+SYlCYNlm+9W34y9VnpaVEP6BCW2X9ZE6Vf/wVcR0hexkPPgpMIrvuSY4pfKiszPyMUfIjaxwS9kJ0ARcFUEoL7Mae+/3VFRYrvAOYjOFLilKuhHQ5IzwURP2oVNYOSbof6NjDo0W7IzcQgCxmDG+tzQPLkaJXqfVeU+T89sEDEUuSg+XGeHcSGpqhDTYgzAIADMCpaxbT28k+INb3LyItRfnDA5PoWZpkOSNaAYI9747mlsMoyBM9P+obpcVmDc2Gz53lg8UNP4TveJX1ED6vr+mCd79B79smrUdQmNTnQs2S+c5UOxzE5uWQZ5HeeuLZ3743r2MsxusTIQECYGX8kfSZuohVA+FgZX+w3evkNKm8MZ4DtGt4PLNvUyz2iMpQPMRgOZsrsIDt03XpAxsgiYOp9tU0YeGoinzfLKdZbM0rqSuaYnbqDCW4Z2sjRdZ3XTVmBp5UBNP0CYelTOIOLML7zMy4S0mf6LtEj2RMIOP/XF0U36arUBb58smW0sGd8rEi5XIupklI7yxmI2tkDiKl7pdK457Eo5q26sYzHYR/Nb8cV7vUdVIRiOx5Aa2S9Kw1zqEuat6CIV//Tq40q4M0POB8zpBJNwEnpiNlP6i13giJy+TQW/swdzFwlVyg+ZL07Nzqm28gk68TnlaAGZboH/dG7k4/zPWc1B4LctooSZFeu96njTeIKt0Dui2/+/zlse5k/jdCf1IQzXmam0TI4i7F6XTQ14ui/LbNALUPmFOc7ozkGQwa74MWiD2SmfZw1VFpCYKPaoB0SpRXiqSfrDJBH+vits0kcE0nZ96TELVaty7e8oMzthW80fVXmuOXmLGQwqTLr1t+jhFIvbVDbIeAXB4C596CIT/4PESfsSs6heUho6P1uJkb9d4LThAIWkAdwplJdPkUh9IP1j48Mk2BzU+Cq92cVOuFNf3RIWANjRaQUiakrDBPGvspJps5Drp8v6Mj7PF5B1G/VCkkvZCs4tZlSX+9Ch1sWuIyDB/bPYo+A1YQMYI9mbHoQje5/12JDhxqgQyNjO9i+kktNRuSyKYjvdC3zGIZ1PfNcZHdxoCCM3o2Pm7N/XFrC1+ReiCpioINsQ38cQQg+ePvpsbSw/xHTe0+BUELtcKyg/EbowcwGiMK4DuzeM2HfqmJOgIjrjfuOgSSIf6Kd8r7z1h/wfueQF/FFeKmdfqBpJTnw5Mh7S+PXslqPTFjdn7LYdrjyxFclCMgVyOnOD0pAuV2U+RiFKuubKrN4uCG0aGdGE4dRu+Xex1hlMoUBRE4RaD3pXuhQ9Sn/H81fytHZGbiIl4pNPGN8TkM4uWFlCIbRdEecjU1r1IB3Ogscc2l9H64yoNlHgZ5Uuyl98k5pWLxbF7CRFPg+n+/0EsVbi5oX5/IWxZcWsz/BQAg78lCXMqKYvFGNtVjaSMPJB+3i2u0FH/HYhoeO44EDtyONGny+A7oWbF/ti0Eaxi0L39Tct7AdbEIvAuwD7nOQNkp2wNC225d+sm4JqigNdgDX/Y42akMwkKJ7WEKTAXF6Tv71BTmqV2IReCTAE0g2WQvWvtjtsQWD5JAwaBZ8omdNnanFRCOgTz8ahMqDw7Zp5IFVzpgpQASRL07JnTr6j7NSVMAmJXvLJCvWF9vRdKso9GsemxhAB2x4wCHx7166xJjlrqL04y1xHeoZsOxoJ9Sj8VFBcic4CsGTZYE84BW1n/W5+TwhscRos1v71m4DgseGSf6GFzysWyyrWBZ+ndnZKeSSs3Spw3NN/Ybn5I16rcsP91MZ0PcV62hYoyz+72d8ySklaBeqWm95Je3+G4HJ8MhA8zrtVOEopxxa4DSxZ/HutaNIXGSy7rqihMkN9KNY4dRXgjuoG8ZT0DvIDjkmDQeSy5dbrdHVKt4istcl3G3Q80B0srlGlpOD4F7PQkRBhDIDWY3MQX4z+PbYpyaicuWIWZ3DgiW4XrADp8inwXcT1stNm8RLNtaWoq9YzlaXG74vH/rdX3eYsiEaHNS4LveTpfNVFprYgKc/lkJD/6MTReAXqsKzfwaLMFAbkuY4DddQLmVZVrEIeKPaufqdusaRQEtZ9l02L8QZsJbkPQAxy/PA3g6ZyR93Cm+Na6hOJv8wMmuhuwO7lPtF4QtBNvPSJvMZAbpL0NLc/Ktetp5/iMVGnqf+x9h/sC/M7TarHDL1O+fo27ABAKUE+jHL+E0NmbAr+SPqK6oV61rVt1nXr+hleImqeXUg1H9pUgyQMjprd5E3obm0Zf+Y9XNWbk2+0eIA0r3WrcLjA9raO9BM8HB8Rl8SmrO98wUfeEw+pg4DKfJn1onY2ubDCtbZkaEnHcI7UePSxY+/3IxYg7nZNtIBbwowCkeKdEC7i6qTYggVDZXzKMeBJuWmL4ka3OmJtuCBd8qvwNt2sB+H0kpMHNyvfUTNXPVekfimGgFjxQ9GNvrsU0YGjjX1DFJDgIAYXdmsNLi4hSHNnzY6VlVkdHhM+1L/+pDiJ1j7dPqLaRUioRCJJKhmuNCjv81DqeIrfKLMjn1JBafzci7pg9O9mWsyogMcy6IHEqM4fTvl8rS7gipenaLF1CDfKLiQUexckUjZ0kH+kSNHuTSCOySH/vneiziLnBCO4MsjutI18+BLADjZnVklygTB3qtYv85VMdvkT4IQXUVs2F1KGJoWzeJcTlk0dJ/ZMedlOQyw7bQA7UFLoDAJhfhDROnwT6Rg6eN7EQEBKC1KTVlvZsGIMkfVzcnx7AzMp7EbCb7lh8zFWIMH4PKIjN4XzGcYGw4EINaOmdrOzYVy5j8GtgiDVSpmYwk8ul32c7zeg3dldp4LUvTGYfFrHsNQKhjYtPyxxziVT/mvAYq90sPQzRoEVmNBMjJoO1AePlT4b7dyBf/YZLCYeXvqVZDE/+1If/XWodKeYz1YMNElzEV+BdV/f+o9AyL5t2D86WhTdljMYMY4x3I+Ye24NkjZYJOlu8dH0UZWu/yexqL0zRdvqTgJZeguF7/YoXNC4iwEUvrk5/AnfLRKCbuuzC1p2Oa0xZmFTqDv7W5lWtyzYfd5itkgFZ4VMsVtNQfGQSnBug7l0UT/AT5xV7/Qtq1tBrFrd3tNRogZm9GFPeXKaQiJRlZRb+225SvSbMD3XkIt+0cP9wuIRc8oJ5AebA22vBp91qUQDjf2yL9Ac4ckhmW32hpjr7Xig/EDP0eq0EEIKgfhrSTIPaGbhpuKmsMhW1jclhTl2R6j4AoHz57s2UMkq+M2J+lOyZl4gazszUySdrcK253rTtv7XkTyLuvTE8E5jnZPcu2lvWW79uXIlVP4eahiw1Ula44hVHy58oQYF0+xurwc+SYlOqz6HJwjTb/ex1RLEk6iVWsOgYvpHuMwcY3ICIJBVim1srjl7OI3Elo6K1FwzD8JtNVVsJlsWFJ9hy34CoNDGI4MCNf+CvDV5aGI27M2/r45GLjgxUEBGRijWJoKOi0qE8DDx959tca8m4IXXWoyj2lyAOStpAC/X87bubEEeB1eepMKxcOuHpTxvlUIFt1nGoFK22S5PEDTjn+i2+R/x5exiJJWSmWhmxp4pMbDHx7GrrDWXiulKWjRdM4tfdxHwUUmfXhsB/5bbsRN56Wv+/+OQMvP7JBE3uXY8jxWRFchUd9CuxtEWlxdxuDgoy24NxRCZmlUJ6Es7GiEoeyNMD8saky7V7vziwD/iryFc1cH8OSpY+5XpEyDqMynnA+VkTRWSeFu7K6H0aiov3hzx0sUFsD6+JHgdDmPWSqAflRGjFhhWy9Gp+fVae1dTzEiQcvNFp/YO3oG/4RslTzhtwAgMdFMN0roUSSzdETZQoI69WGe3nSvQ/YlkACOJTbwjqwB1uj8dnXUBUUsAZ+8gGtflAQKgZdwYlGGwZmamDl4XBu3KhZDorSYd+nyB46xZRXBfjBw5hsP/plu4dsK0r39gfIdeeCIsxnqkMaHBa9mLGiD7EgFLDOrqIl6SbqsAHSP2p32MGaoSj+BpqknAxdpuO7bD1Jbyf8ilwntsc2FnLo4jQmpenFqUpAAFFdZDDi614FmfXJN38HbCb5AvdMji2jBhm30Z0avVdPXuouYlx8t5HPUIqhM3OWsGybS4MIDP9+Z8UyE3JfibLzrZx6SA0EszyOTJr7+OZ7BiD9qUONZ/Tabje2Hqes36/XxWYxItwW4wErjmWGsCWJpD9RYfYy7dhc5s25Aa1sSI8vPjTRiLm+Ohp2SjUWASqPGuOk1bRBiNl5vQ4uQ2L2okRsbGoIq5NaMI1qL+j6dWwfV3Zk5n2UN5LKACgxTs0FkiQHWfCrhXukTtcdGGVsl//ikRcFAvTp+1E1c3QkNEiexDwU55NoAg34GdhGpR/0H2tdiL/CQRw+vreXroNUKa2zBhAprmfb2gHHQBUuFNpjBOhCKhubkPjL7fdkQL9OEw4/O6fJ6rt+PvbjftbVl9ZKC+QqkNauJ5fO5EROVrL9n7Awd1YE0T/mEfswCNzDSY/JlfFdbygEevxWxinNcI4cdRYBdHUZKousyVUAtb4wzjOgifA20vBeXIbmy9hYii6/IPOTFiGKwntf1WwVQKx5ziH3bdfjZV7+6QcYYpTqbEuuiH6BasgMl4pTG8Idx8eg6WptNkPGH9/SbX/7t/wkwz1X7fqOvmHXPBNS8LabOMTmt1IqgUsiHqfmXCUYYOvEgcbKZciAyT5TLSWYgMzIMYhStrsszj+WY3GRtXKli5wlUt4blvXwstxzCcQqc+8Z/kyJYmpVyr7ZHcEJ8oWCvoZB+2ZiIYWDSprYJTrj+heqwPqmcBvDXS5cyNYVZERwSmPAEK1SeZmpXgcM7XRFUd1sd18IsFYXNW+wveskkpnri9RFH77rxPJB0obdfnviffDub12Qoy4RWYn3mEH1ADeXUBqZGgvMoB/9lC/lkcm8cWSB2Arq0m7zABdAMLia023xCAoF9ZTn/GQ2kAHJxhBr5zTedyqOMHjSTn8FjGrvGJEvuqTE/C1VBuexdekNc5Zy2r1lXp2524/VznGJ6Uj4Q/AV3Mr5i6cu+kqEq9KV3ORIKtjJUJMuQxEp6e+jSPfgs1INYLTT/Jl90gKdR97B6BSQsHYBiVgbFLvUGvmO+XQAr3ZW3MgaBflOBGFdXivVvwVTWQL68H8xhGj8Lls/2FtFVVqYhSlIEiGqSvFUA1j0cX3DB2rdNMhcCDtVbCh+Pehyw+qGDF9YVtvx/B0T8Ziq33Ep/bLFeajzxJe+hBVq0RNGs2UKWjeaq1Aw82vSsEtJV7I0Ih+csbZH7xcWEV0P+qxnVBSO89mIZfNF3sKjEkTQGq/piD43KC3v26wf8YDa8zw2blb5DDO42BYjCGPgWi5JfHxeKILHgy+lROPMTdAyliUodefqQzJ376c8O2M2tc3Hx5fBCCspc2EjCDInfg+xpIzfF8Ox25tTBGIrik/myRJcWtrp0mZ1MtpDZah6s2CZTI6bDDHZtGwx5YsRtuDbPIT0n8FatHrzzS20mAkiimXGYfPo/KOCgQAguc0RoQ6OHL1DWz0oOiV5cDYJudmckyEsyzf5cwJQ6nzctFMtJ1I3dBd8YAv6NZts1MRKc/1mzkIDKB5xetzedjz14xE0JpsECFhVHzyd7TOKA0Zn0gYDoFjZ/1F/8Mt0kcYKzszf7R3WZfiztmjceXzrih1qRj0SG7XO8OcN4TtBJDCa+9F4KZifq2e+bgV25Z7DpG4ldIZ+xby1H5V/Q93N0ZT+qLfvftcMDtWxAm45n5yJdfDPG1Z77O9R4Wb75h6nPHchXAjWtG0cJz2+TEXeQv0mbTWqiqe/HTuwttLVKJlhQ+IzQOGiGjnS+SWyiZz7SRMpurYIeuoY7hFrPScUNQQqq1WR9IXQhdVw3TeUMVrG7FL28DxlHzcgqQPd0ckjdJo2glZbgY6rGwvoS83NAnHob71L5muxPjCyBBv8q9AfeKAJgdhdvQJedZ7xa9vjEMCj5XirgJUytyY8bVNV+QyfN4a0kIwa+968xWIgeqVK6TmuzySf4XFnrDxYCAe+Bn9jhq4WXg3PjT1o+SVODMQp+MdFyx59hhWJRhNB09VZ23PHqMwWjMH2aPaI/Td2cbAp4MQKAhU+EP0pvlvK9zRd8mdrIyBT1z4hxCeirNYkRqzQ/SFINewRTBvEkZszR1iRNAJRd0p+Km7nfzhatePil4zN2nUNGsEMf8DLUJxImXgDQHAEYJr3OL62vi/GgbYMfXADhgox7TBP2Vej3jgPKkZHrOp4l3ziLmPQs0WH35YVpab2+apMdJSAqUBbNij+Wc4krdN7ojFPkFakLVThBYpgna8Upk020uZNw9igLasqC1nN6li4FIlzlr9gm4gEZUb8LttssZ7y2HWpHz37yNQMsZ6cRI/ey9f2oGjViZRGcmbXEO5RVLiagXMSEB2V/xB26C8WhKzl8j1/5XaC0MteWrxR/zm1xwzsdbovIY7EUhxLiD5a+I5bUEBilABcSXzky7Dg90AluYlimjX8wl3oeBUoFGdN8BIPyCu3sXaRMhJZqK7rYX91uTLYyUhA1YLUpLjDhKoWM43tA3rOl6ZVmusq8UJxpt/7ApQbZiyS5AzeJhr3W7EzAuE/ojo3g7td9cbZ1CDcr9JGnmeTMm9HkD5QeLdnl3aiqJxUSR1segiw1nVqUO1zrs2JeylY+SPyNbgdcrQgqtvdAfnf8dI5J9nqrnZK8BzJwWE+dllOPz5616IR6fsQJO3UAz4sQJeMZBV1k7CPD7ga1on1671YUORilq43EYL6RuBMJ7e7Xus/Otab71RgUmxk03DDU58pe/l3bsQd74SGJALd8ztvVSnigC9v+1ShLyoxPv+4wlaTmaPFaUj9WZFqNfKGvUiu19iepMeYURWCwm38OpDq+BHfoBoRWOnUdJecKcVpBaGvheRBSdWG6XD8e8enuI6RgGDtspBgaUO2EwiNN6jehLBJV+ZY9WFPJN7+V8/EqVJ6zbTVFQ+Bd/7XYcdb1gVssKDg7LU/mucMcsK1VE9MWrL7Onx0oo79XFzKu+42VCQg7fLKB4oBjb8yaEDMyB87APp9tGjkEynrvFo8W4G/p1+5wwPzl1ZsJs4Ey9bWivP4dnq9oSTnlyIUYpePPXnJwsWv+e9qX7a5hw8EBDesg3JlgWEVeu8jk9i7C+QDZTDYnpy+tcjU1+FkWl0U9PDhoxxkirWziC1fiqqWFkZZna6PQrQgr6j4PiDbWVUvtNFvjjwlNCk2+C2iPR+0jbdbxzelt3Zhr7ClDZWsBaw0srJi+TzqJgG5ZAGqusMywgxGACDC3VvrchaHWKwlmYDrfIvsmG1TLLEOs0GxIFDYzmrir22/gbDB0YI2AbijQtpSarhNp3mEzhNTduvHA3kbjviEMrzw2SnVU9syY3j5GxEognIpPBybVu1S1XNz+ilmtVLOqSdkOAX/rKFAUzr/Akzj5tRVD3liW3hmnqIl1yxMUV08q97lB3XRVI0t0PXd3jOpWSF1G2FtBeBiROmT4aAKGA4s4Iq/2AhjGovJ6iH+qiJ/DakzQG0dgv1SkXC+oft3v0SgAHDSBOnlVzfpuN4Dkz5W/WYemhdcD/kpf6Ou09JePEB6RzwMEjdK3Ui7LmoThDVaVZBkMHqSGG5j9AaXeKeIvDsPM1GdMY1e2J5HLgQbN3W9ma2IClmZGDTg/uZiXjP7mSmTr5sBOZjbTv45XiKoXsnKktx3hHxqaabNOHU83d/gVr/zyNCassn0iJdOQ0bmGrQjcv5apW+U0+lKn92F2uKDgv2KTCz14I1sgb4zMUleoPapQV+QU3X+djrnly2H+4SOA6nsT4BGVSH8ygiLKmUd36zuULHJF/rmTaORtER1KzZUIrwPuOhA8tKPENItIzCfgMvNqzJB5zbmXFJsQ3IiW0xODD/ZuWXW+gvNU6lbfKgEC7CInXNX8gwCaKAoxrqV8K5SqgwFjLO8rpMag5G25lhoafD0NBIAgQyX8uAZyCuZJez0xOZEh19aMN9BphDrDVj+tact9Tr5TqUlbHrSk0cGcQ3HRuW42fnq54xr9jXdKjUfUh/qV9kd0I3trgpHTkSc3vJLffuPuVH1kceb/iONgTPw3G9ASTKrh5yQy0P9VjJJCTKzH71ci0oKB64J/W2Uo41j+E4crsAI/1/P0Ug0DHLgSGyiV2m+i3AGDGg0BnPOuiAFWEoq+WdOS9siyfyM3ZJCjy+KAgY9hyTjhSai/uaB8H3573n+hNHmnVCRdb91/i1cKSaYMYpJAfAHEaXwZocDdwkHRf55KOUfPWRFF2T3WSuQ7/ecWrD1ZiPbLE7mLUusMKn84CKQbQy3VFitOpt9F7F9z9eiMukgltRr6uAr4USbAo4CMzUQ3LLfjwFhg6s9fewgGzCnq3AZBGmweoICbFMloDM7SwjwmbDe3lWel8/B5c0OXTLpg7Yav00tgbUdbTuQUOlWcNkxTblFV/Tqi1rgDMxbcSaxxOB5oHXW4+NaKehj8EYLj1fd9ZnHh38lFrXAe2PbFE/uUW8jZP4+BLt0i/vHDNjLB225lxdS5gUAG9IFd+22l1NPogWJ2lY+XwVsS60wNQ8h9Wphs9Wm0JeZMlnjBu5C4N6/puC5ne2AArqMRgmzy33j5D1zYDk2mTbrOseld7NCHYwORlpQssLA/QxqFU5grSETx+hp6sqPzwjOKjdYHtTzordmMfXcLpFS6OuVVDhlHzwU3/9iA7gcvpyNtl8ByK+Tqyz/JERHBMBqpR8DR6TpwqHZNqX95qktPZdPdKMVG0vPU9gDbGdzckWcCgaTho+T6Mh6Y98WA3K46JVMWJUT3TdDLYhHr6lSQruia0PLBMZWvyGCrTHHGn+on28pFzgzZD8iS2/1O6b2rSopz3cpYonWU68iY+Tb4VW+NBkbYafrelbZOHnYP8twDq387jYTAWb4Zoe7VWQFho9G0/DnjcX6uHb34pglcq4evHXaNhWooSMFE+AtnWSUxwKUAeG6XkHkcBivzUD9Ol6e8RKktIrz0sFzLS2GVz3kvrYVfTlpzQN0Wf5EszCzbhmevGucNjs88TkrwhbqyyHrs9QbNvqxMflTvwOszhh7ctO3yNbaoyD+WJ3qmtsypdicTO0hl8wSI208sIvt/jAcV8WulOZx8fFA5AKba7H4CdOYsIYxcBXce/uCKZeaoxDU2R9pueEbqSlkLL1MAitXl2+UqxTzgS2PJbbh3kkq2N7WCNOKpAILlvFrTyHBnl78D+qnfPvG9RSw9Fp2iY8cXsu4/HTKURQlRusNeVXxaRGLGx/ecnbgGd27Y+XxpV6v1a3QFFsS2ayioHnon1vKyiznQhUzNTMDcLyGq5dWqGfaNiH42BaaywcLHL3Ac5SQq5hz/DuSSuEZFDHiqAlODhQIR7gHpBq+nQSu4g6YdBYVgmBkhf+9ebEguCEFPoxgvZQHIEhBITks7gj9LPL0khSro6fecdbHDDj/RIYlag3Cqb5Bvk1LG0cUGwF4OlpUi0/KrNJoKgAlLSXA2XO2cqfyZMO8ruj88bV2qPtA0EUj4h+2QvB5hpYN/4wRHvZ5NiQudr5LFU/R2JZ+8uDKpAAJG88QDFYnVXDbMaPI6Ygddk1EKTYII+0j/XgaTPYzpAvwTdIdRMqVy7E/g/2EK7mmUmDrUG6ced/ca1ZDpk20bqbVdyPLW/PI8ON+1rbCHduteBR+QpGrDgVzfd6+gxuo4nrTW4gA7LaH71iqyVZ/SV7tMd+XKjl9e5b1MhsPiZ7q/9wRHBZVhielP+kdiNzUtlQvbq0IacMrqCBP5NhCn0A+mIP4BAgWu3lJ33k4KEc0aLYIyN+p1Jsc2Ofd+1HrcDrWw1UllYhFOGCpbHZajrx/R4HDoi8a6aD24szXLD7DoAAd9X6iu2Km1YRHgQrVHs5Ye9q2djxZFA0RwxIDTHxyHEB8jO/nC0iZ3Vauir4eCEAWr+LsOCnwOhQP1E9YZCH9CxjUxfGV367TbBFXPmJTCxwklZxARs+QhN+Pj47VBnr5ec+TdkDDB62/UXTd5JsTZpbRXhalhjfq2+I9ftYJ5qdD2ID5CPtCA4UtOsh/+5t/EJ24TrRyWLHtSpDVpw2mR35PdCxc/YBY2RbwE+gLo6bsp2ew0aFBwGhgJt56UNGl/z7rnXbp7XxQdPI+0Naq4ndRZLOx8w5L0FODGI8EnScQYqoczWLJm3Lc1zlqWIoozHbA2wbMsjYgg6NCABvXuiuG96Ii/bJBj7hQDorfBqMNdMhfLBoVrN+FGfcXEyKgP7F9iGaiFNqh3IYVQJQzXP97kScSnxczW+S8qCMAm3bP21kYhg4C2MgkFZWrR28OQ2I44LTrNGScSv9ir23TMuOKnM+sF7dmYrsoeBK1DSnCYzMPY2YGt2TdaW8gcZbiTbDhBxygpGV+TDsZAumyfJM6tIcylZne6VvlITBNUmhg0fuh0JPpgD16AgJJjzftwSvgwoeuXetxseCFND23mDETbYSYvlc2kN2iMcItbWbvhiGW8Q1EPDwwMdZPROYLhX6noeGmNtuBUaBAM0+BnSh6MKfP2F/Gzo0F8dhvPbMajoSIoarVnasCZXSB5pDOGUxh1jaiFFzkigRjvHIX5KfT442uK9MivhIi89Wp9WRZyjP4+pmkjPRw6ZVjhn/DUFvaaEur9JhhYi9wtizqOPEkRpk9zLbSX8fhJuvKbgQ8xA4RfYSLDsrNPvk7TUDQ2xGLpBLSaVj2EoKXSwPqY3icIrqmwvaCCpQTLGgnG+Pkh04AAET4NLsGlU7BANXKfaHst0JK6CAzi2rSxZOFXeFiFkCx4HpNasq0tl70BbfU1umKK2rE7TfDEPpy31YvO7HF0HCU69z0qv/f85Szp6asNE0t0u18robERrWjE5Y/pP6WlQ7k8S0drPI1zF8VCIZ2i1RlX5gvCA9/wvIeKPEY57Y03y0RrzQBOu8mCDSl5fVLaKTWXaP4Pvjo9b1HHrVxY3tAG3uG7Kv0iSKzyKSH1CcEM/V7mcPfgnzK/Y1zw8PcqSkBkRRms8Br9ZIjPjpE4wcUrnowun9w2AXp0oFuV7Y/e3nBGIq1g6QadnJ93JqjezDlA/6nl3EO/2wVOQ4aeL87t7otGReVaRr+r2lyY0x/7cQS3V3nH+rHUBBi6F5nZ5eCvFnc0aFbAnngKtIZNtki8iwnMnRPy6DYS2IJJjZMXRad1KOPZjHUOEJ+WdXOajz9wgK2jhGtsa5yYqd8henKrSa+4AqaGW624eLCz2lMzOR9KBhEr4o9tlSSxR5iDa3TOd3+ud9iefN3o+Gyt01K12ZB8Qz3jfuBrvpzOark2vHeNxYhfggx2fWA+mF1y9g9TFBxe6G+iyTSkifDSr6veqC8sai9cbO3+G4DEGT7M9hPtj6zII0k2sDsxtfbLq0kV76U80/BH5PHoxx6kQgZbe02GL8ipE8Gu/SBWnuxp16BazB0Jvp0vZ2HFYxcnSIq7l65zaEfXkUcOIb31uFUY5uraOtV73VjtITBpqkQunMDoLxWVDfSqSvkw36YZDy8j0SGeUrn9mDWAtPTTZ9XV+UtvC5ZZOZz9atPgzT7lMT+zwjASvrtzfWTsBQtGd1EDXGQ7KWpGdXxZX+L3FiCaAgRqYQhnwrxCkJcuHnmcW/0LF6FlrPv0Uqal5aBSZg/eLGbcLl0W2wLfwwMellWEwLsCqTL9lbQTQBePpUhZee6fU6u0aCo4H6ZztMwwnVBfwR8ChB80QURKHU5CrziBFRpZTK6Kilv8uz5Bx5FJPO0ijHrcwr0guOXGhrlhtmu23RzWmMyVI9Pl5HKHSqcDLCY4l2oEeqnD4pZ4P7WW7tJAh6juDBy0iwmTprRftann9FCvI6ov7swM8ajhlz1ufOwmR1a3H6cLnXtWVRrzP78d/zg/9vs+4MHtfDmrond9YAr91j8I2pH88YvBF7lvFYgeiow4gh//w+7m+izLsYNw4pPx6Hqb/aF9C9Y1biF+BBt4azjheto1dkvDt+TSQyYfBpmjHFD1cuGkR9jc0cMItqPbiTdjcrBbvkX8wx3QtUqRLob2SvgJa5orcw00zbhPWilZBs3jw7Nt8G84rMKVmBEuvYrNr8SmZPqLMZQ/IZ89vV5spkzTyo6tVXHr3YlIEULzvtelAYr/SAVqf7bAQTkQ8MjlVKKox9DZvD+b7N+M6h8gUDAuZOp/WSicqUp9KvGL9jnmfD9KfVcUmcvJSwzUD9aCl7XfAZDyTguiB8h7KTt69romGWiiykNYYgbhPhmAklQsfGSQlsWixZfK1zex7jdN0bwRANYoH9iTsQXlhpDwVqScSjWOMU2RRyZpzMun1Jgp4dR+viZzvHZ/sw2+L38yX0Fku6F4aJD2auVMRbyqj8jxILtGhV8atgFqedoqlIBh6m3aPvU1jLnH4phhOAO4Kctsf27itF9E9z8DZz/vmqyFFTRyn/UslJjCVXdRhjb38mm5Gu6CoGFN5J+5SaCXDDqHk7I8EwmU95xHixKi6CEJmLx5qDB7A27ShxU2yoVwf7cviNE7yBZA8D4vcKhdeaZFjZx00tMHcB1kM4iUxKOKH2291tWxy4UWuOReJ53ijrXCohbjJgFMYA9heYhXnhGirtpqstmdm5WAxUwDE55SaucdUTRooSfcXrU7z/s+MTI020GopKzRvyF9uPOz8HIIxy93Tp+shjWsSBB7tyoiaohd3vBLyqvlOJfZQChLka264V9zGZwtSM62TvR51Pp4Qp5UIMHvl21WUUYJeQ3Uq8n75bd/xhoWeWPKpju4vAd/jANwkFlf7yb2aKPhiZ0+vj6zs20lFEYR20MEc+1U7eMOxLIBCaqfkms0ViQ6LHH2YEPfJbJTv48dH9Dt2aM3PT6CeZgfGo6Kl+6LSETcPv0Ese2a6ojZDw7MYqzZ8Ea9aj9QtDck0yHYr5c4j6V0cgFlPgx7Ku1+lxuT5orJkw2/ATk/5TYhlXGnnmxdBhY12AbUkMaE/qgXmtdb8/JoF3WWckemYabh6n9BOxn6+jO/wf6pUt1nhUPPWfbhFXT/K6HiRuHDR8p0GHK/revYjWSepkAoLBG77Ez9kUukAFjO+b3yXouj9KEN5qa6fj1WKimDTi0ZMcdsyEwobTq4RP5yj7mvzSsgk0mQLku0mZdqrRJekC/8fttUM7k144Vo9Zu1d1RXDy1xANao2De9mPCkF9NAFAu3b0N8javHEZwXpK+J00+RxRYrEav6rcLvVD5RJ/ckJonyupEfNTpfYj1t77JGBELILoyYr2bVqiEo5pD4GIfzE7oz1UzqhoZpnDXZg/jZLySECoGUVbzQWf7PWRnbosDuimGklcCSNtte/I0gLV5bK5xHEtzPc7s9PLCpwo1IbCjS2WohTyvfpd2OpcAo9KNWW38QzZKePucjaiSGlv2NkBN4wEUjN/pWMGuT2suUA2B3g4QFQfdlt1crS/zScW9xhO2qWt4WzcTGVfScduD3f0LwnU1n5Zq7K9lTN7XOUJjQnDDxRTo+6KSsku2P+yNOp/Q04c7cZDCGDlFnsIsBA5oHnEI7oP+LC/iUm0KSKzXXke9XWlyqvVYWWyGDjkZUq4mmeMwSLv8ueg9vlz+F4OLILmnyQ8Oeo1l1F0fcfQRavtqfyUOt8neXDVSqbMJN3qpxChWm0fcYJkSlLCUB8yXs5ZoLP6sSaSfMBB0DW6TcXq12aJt7+ho7ktR17X+UfF2rlsurrpVVJ6hzOMa53LVzXEU+2AVxYRzgobYQFvpSHXViUjzdjLvqTLXyZoVt9HhdDvpGJgyhefjKBW1OrITYMuyaoer9m+nkrq2ixKBPfOmpEGGKi906jOqs6DzUKNWQpxe7YLoyrRib1gM1uzxMKTlqr6quAVT+Z/8U2AVHQBF/Y9wk817DvYhYn5SAqeO+JOS3yGkTobUkBZEaOd4CtyAD70R1dWkNbRQRjP338Ku93p9acovouPI/lPzGCNpSxd+wvIJ/eZXNGSPYWazp2xzFgXlA96IXnVVFSkw65Xz9Ls9ys5uAoRFBeYzguG3OB/gRe2ubsFwvW3gXaZ4rJCy2OdTtyc/05Lyn44nNh/Z279jARdCTsWg3obFLRUFeZtdTd0ZlWcoiyI+dezpBkkOUSIjCMit+XWsAhUERw1DBYxwwGPjQ0XLatczVPtpr35etK0yckC5U6zDKkULfDF85O9u7uzEtK9oY3JZarVMvSrJcL35NBbcHETfyamD5QFcKLKnrpiPCNWg54YHDBH1UG+mYhnWLDsi5JA3KVCxWYWcMI98aJenXTqA2Ofbh7PlsiHCqc2iRzvVeIuQmYjukI03vh8rsw8w6ePB2EKIhDXxFPiE0QNKRfkg9nnI+WQwDT+rCQpbcpHuNpaiaukqRpCSAfyn5XQTINXU1XJk42tJlyyHON2oM1H752rt3RPORF1821oKd43p6BYqQSHtE7H5FLrROtLaH2OWFNrgrBz0LpjwTDpXmrag1skSFo1RHDnPvPW8uUjahOcpbLzQtnE+rxNWLhFQ8bF3emFgC3trLzY8HyaeXeH85ivRxljYMbnYSJ878EskkDu2RG4YqBzwSJnKQw2O3s69DkYy0SH2HBc2P/mMIwI/wM69i1NpjlrIoLVB8Li70NSeL07/1UsdLqh4EdsDplnBC3qnIlCa3rK90lb0a8Ji8vgapEXWjVln++4Opd5jOj1/Fv21uPr0PMKu48d/WU81creTygj45ecwdGpNRMqN2W0JlhDbXrHyWPgJ9u9nhlY/FbBflq1NFmrmc05ZJ7aGwwOCMo3tASg3Rc7ycnlt0+JdkfMa78SHcMLdhVO30A+h+12p2mIhuXFBGyjDc5Y/gL/n6YKyQ7ySDMuTfN1glCrYCQ39KUNonXz0Y2Y5gOoSs55WP6mu7YYQ6TK9kqRp/mBivJLHqWZnBpw3Gmtu/Uy2/2eCUoiF1YtTmy8pd3/yjFVxksZ0zq3eOCSmUKhwbxyT6tUz0etTbMPtdDMiarKp3CdbC1OwpkG1hguKnWIHvzx9z59STzCsPtPtkwV6iCT45hcw7jRByFSRAzlBbt1cbO7+hFju2Ef9K9OyOx7HSu2gHA8GZ9EZrUp7lUrt8qf1NyhwevTOsrW+r/KgpPbj5UONFhdmnC4llp1N7gOktfyNGsyw7BBYgXUn4vWBcHTWJeCTRrCJy2rstGOuttK+qXOgZ+RapVOogWIEOGn5zXTC0uwrUtGqdEAATJQRITpiUkIQsHahwZ8ajys2wGdqqp/HytfS586S/koDXg6CkVViwEZN5qwHpOpn5WFXiF3ajKkT9qK/Q25AsXYSpA09eMf6BCQBRdoXHppcUYDtGWp0TQDWuBuNepxBwLpR5CO1KQEeEaaODZEAHnktBe/zUpWzUXxnST8VumowijLswwuM7Q/DKk/QNsEssyEb2w55EJA8tMg1r3REaUnA0KD1WHM/ePdl9zBlKsvba0DRqjqNIvoR0QgsO1+WVdoqYle4qCZpj3hzbW8iKgTQAAAA=",
	gambler: "data:image/webp;base64,UklGRvIrAABXRUJQVlA4IOYrAABwdACdASrIAK8APlkkjUSjoiEYvfWIOAWEtQBq9iZGUk22J/Rf3jzK9fPX/lo9F/Mz81f9L6lP0X7A3jreqL92/UN+1v7me8N/1vVL/hPUA/pf+y6yP0HP3Q9Oj2WP7v/6PSs///ZxdLfEz4dfefBn8a+Xftf9w/wX+h/t/tI/3Hf552/3foJ/I/sr+K/uH7d/2329/3H5SeZPwE/o/UC/Gv5l/jPzH/wHxY/Of8rtV9R/un+39QL2A+d/5b+3f5D/v/5P0Uv7D/Beof1x/1n9r/Hz7AP5l/SP8t/a/3b/wX//+ov9r4FP1n/Mf8f/K/AD/KP6X/tv7R/k/2Z+l/+Q/6P+V/037eezv9C/vH/G/wv+J/ar7A/5L/Sv9h/c/8r/6/8p////p90X/Y9vH7i//P3Pv2A/8v5/ngPMBpLL3a/u62lRRN65mi3r7rdlox3aax52QqSLKExHWkq8urkOSFwGaOxzhGkoNR7Aka8zzT2RNeUk5IfBkVn28MDO110HwhQecwVptT3TvQYnSuZf3fiHmU37f7QSwVvgyv6Mchlk1O+d25gJm717XWsOYGjozgoAh/mLWq881nbu0yu9P+zaFdodMqvUi26iUxS+tmoCfk03YO3PZps+JjyPlFKoPK3FPKx/5AwXNQyi+Jfzq80yMsqV694/Uuuua9FS4YPucOdo+bqYjBBiE7ejCXj/0eiPALOqPyXe/Lrc6mrQjCKGCI92CUYDvz1MI/v02G4vdx7gY6BwFTeOtceaP/EGkc8E9NwI/XOiKxMdkVi+VH+l66rMjHKSIMIl1XmY6CKVGTFSKBONZH37Q6gh1ygGbWT7O0nTQZusuF/j9IYeaPLsV68YXMTug7pCikJKjnBly6LKp3boK33TajWYobUwsZV3iVdzwcYSrNunfhNfWY5VRDxeq31kX3/VGzVWly8PPRiEYwe0fitvM33t8xUJPYXsAxeu9ioEJmD3+Y5o1QV/wErbPFLRD4QgSXnUZp8TrpzrWr0dH1IkfyH97LPL+QvCCh3ZC/e/yK35dz4+5Ohnq2/YKgJxWV+AHxOyayPDn4uAMLLSeoPBf1WvKsZu981bfDA3Tpf/BsF8pmDesQbSggFeSs1skP77Lm0PZC/8yo4iv+9+CGYuEZy/dFQ9eyre4t3YaKIVTOUmVjku5xbXXuzUzw2nErnmR2jwoyiGt5nZ0JD8BLi+XJgmFV6l1H66ZO9HLi0i8h7h4kTZcW68FP7Hcc8xONAAAP7/PpF/kQWDDytO937UXd+JAb/QgWR27TdQ+2GsOkZYzOEJylE2OII8jEpgP00FKT0/33T75q46n3IPVt9a4b3tF4qy3+lRv4PWMM2b0w1qKL0GXDSD57A38KSsHyX1DPu4iHpppWRjbl1CMvqCUXUACci6cdBmJ+63QJr3OwX2e2USrLFi31F5lAsylOXf1Shr9ChbiPBmVIPchvaDMs0vnFls/8/IzJcPWFAU9fLjKva2lMVnNBv48tRUqk6R8PojnWYlMZArhAPt3wrlnvkjvSH+3w4wES1hRzavMqPuu5T4TueJhfVqJ3UY4jwo/kp/IVCvXr2ae1FxDDXcyqJwuLQWisJ2y+x9yGgbTftDXwkvQp3iA3keaEiMu4+LJ3ZPAzzwkY8+LxVppuZPCkDmc9iDRXg/9q4l6hVzNi8sqIt4g07AUN0LvzvXbravsFA1XfYYkbUSQd7f689dI5pOePr+C1dEHhKops8JmkbIFjPwKmceubwWBX9ZEZ8hxT8brAKf6Z3hn/tjfI37qFWVrUPtW8VQEYS3Wpn3pO7k9xk+GxgNvo4Pjow1dHymeAkJibBTAMvwJFY6UteIDwY1rwAV9xMQPavh9PITIEfM2ftkrINZJTVCiUtzo5RuQWQ4rAJ4ycrIwmJQC6JNJuskM4+x2CeGEuffUSVvPOVy2j4PJuHjCiDPVsS9c017/YcaLQbGYSzs24sumhTQFw7bY6I+9M4crYCTRfy3gerpqWa7/0OkqfJb+2y79L6qD8jDSuaTwzru3SCj/MDJqO8uLCjfASdAOBu3TgKFANVJHX3Wdw+21e/U9Ct9XKPlIFk7pNjQ71I9uJABJYSWiVw9xbNWfOzdQV7hnm/JTqa1bQeDiOZWC2JXfNDDHusf8u828nHkRoHB7cSUjUPWCp8MhHKng7HaUfNqO+wvSnbS7rsj1tiKO46z/nXjPGY43tET+gRvDU50XrJBShO36jiDdgA3v7U7RnbdGbMk7UR1dvJyUZbxsmvvsoZmeHq6AaL1Ndb7aBpaYjWlvIGsG0pDkzvYm6RdUo5kJYwVtQMHPFHIl6o5Q5eMdKDnPDwsnjoM/O7sjIlFyb/X5QLOA8jWchwCj3dONxbP5e8cCwKhHaRkVZn9O3myOB/rRLcbbdrOBERpQuvfeP+PS5fDZ8Tc+/pD5fGSKt0MHPYN8s6CWMn776fTiIPWv7CXF7axNo+ETArCxc7G3ZkyO/Xutpb03WlkmZ5y5VBBxnQRifh2VQ9EndVq6fb8shgmoULSD6/aSTv9optRg4PWaNCkD6eC+UZix+GhNwpdP4lwRkOcSHwLKdegdQq8pycPb47kel9PPCvZAqYy0Oh4OTr2Ee5Hrc09QIMRBLdK59QCZPDslDZP3hcOoepc39aTsk3gFsRrUVYvAmNxcGfBg/BfPmPUN9Ir/G/c4IPe/FCTJ/FgFmorPrlWkLahQR+VX18orfsgUF+S1zctQtaLItYnoXhjIX6hkZHm1+MP3Xsxp7aVzgPPzWElxSKTvZgSwAVms5bzvI4hR9DtSWvDT62ITlIRz/fvaMZ7MoKjFjch6cQRiPeWtNqgZNAb/I10sVO77Le5cozGxWMUHTAGpoxIQ9KGWa2gGC+RhCZP6t4hSQIDhZiFUqFKkqXbNIkKHevnOvVhhHsGqEKJEKsFCe6oYJJQfVQJyJCDcJM8hXLbj5Kn7f59thmfWG4skJZ2zoUk0QrFLT/CK1SeJuKFkVv9yCknvzAsyJO5DBepESoJFdqCa/eTAXJGRT2P68h7MYrM772/J6ieJL4g/HK4kRZpks3rfRxQo+z87gdyj/bkGAAR4xGTVqNhPFdrxZ2UIFZGgb5nNyZENlErDduPyyJeTJAilagAhQtGp/dAUR90XeyjxWmvsyBDE2h9J37BEZcwbeMxWqXcuPzV3oDO8bgQPSYp/IdOogh6U4LJ01yqgD58OwwIaCqDk+Fo8MuPuzT177XiFnJUlzWSJKzMBNjZWH81e5N87kIE8O1aQM3C19unD9+QQDmrih2c4RyqLTsMFAzOAJKi38YrnljVax8dOoDDs+cxYf5LIcsrpIYKVMuOPvelj0+GGCWVSlTkOiga6jw91C/x1Yo+iWDoqvfgmdhWcgq7Sq4gaK8AC/l8xv4vVyv0yGWeAKA/0M4pbhmOfoInRJM2jUd6KbOSp+eVCkedCeA3PvNdoSmNVzw9kYzF9+sHfnTmfqJjaBOpt/SPXbKZYFJe+qpzF/eQClQHu5hEvt1Q84KinXrGyflw6G5IRhA4eoxIQ504p3It6JDWqL17k/Egf8Dq5OvS+WxuuPp0M/bAqui6Syv+BLVVB97qVfBjGPNzFI1ObMg/6yQfVARtSf8y+xvz7bNbjJh9tdTqqn959/hajiWndYZIHGcrf1K4HpOPEO0ylI28ivCRISOLFORoNwV2nMJHVXyplaz5IJIZwgAh/5jLdiKxli4zy1zdLtBRnAfRbf0H+P7gIbej4OE+xoYKdcFBwIHIv41yfEVOFefKoz9tswRWWpAnBMsYVmQTOvKdCs7H7wnmZNKfeoti3vyOiKd+NhoR2DHpvPQwYkaFmlPLVTUFVrL99rzAE+lOXhzFiUlTuyHyeJg3m/ER2HluLyrrbXDGwoeN7mdWVD43mQUSyu38iL2WiPYT77p/3IQvUKP+w28GRuX1P3XojCB51KJrZZpxOmIlsO6oD4kph1bMxNl1JmryktH4ShNMCz4SelVjBBsOfhMPLr2/gsahIS1Z283MbHqO6ViB5B/czYwJ+bd6YqsvvpNcAeSAnnhsvwOKh2kRuR7EE7hNLKKukeVJKkgb3Zch3yHE5XNSC/o6q8030Dg1YJm9tnBphp0Suo4jsko6xK60NRPnwSiYCopFKHmxSQRnuKhGtHxYBhx2SbJqEoAdq1wh/uiJHhMlGsQcPIcG4IipkBtDqrlScjYV358qsjABg38tx/rfcBHO8W7SLQoFTPzlT9tWJoQJzCHQepQC8pnx4j+WtWI1VWc+F81lF8vMYFMegOlcMin2h6Nh3jBIC7EpcUvRH0Qe3qRalYnLRcDnkxJpUo+nd6cHB6D8OW1/8gPbUriAAWqvU2f7F2WZS6x/IM9lQ8Np9GyB4gljp2WdYoVl6cBh45vChBdhNbfIusg9OCWl5Uh20cuTHYP20rbZ0GxHzA4fHrMoDKpdA7h+i3bcT2Fu+hhOdLbLDUO7oC8QanOlBRgdVwoKiXzc9eC5J72FyG8EMJQmJvYF0epdGnmJa7QOA7rv4vrR2dlhPPXYROx7zDHvkmu/hGvx0vHto9ZOeJwSdZZzkZCNCUeOGt8E/woZSd0UEcojbrEhGnTs7ennFmjgxxnm/PJyRqFxbn5gZ2f8xLCpE+aR0veH+yBm2BF2rjk51zqrFqHsZtzjhawDOqaWnyO3OuChJIyKuqKkTbukEjE7uQ8qqg7QSxjRduH15ZMaSy5ID4HKrsSdAYs79Jey7udN+JbfYrCrV685OjfLOT1bhSBz/dQ1mXvH7FxCQ6DBcfBenZ1MDVVipmmjMUXgEWvh7GP4LUGOTA60I/SVAKd3qipfMLf7HuItO8Gbg6jxyfrbNLGtUNPe6PlTm/nOrA6cfd9RcH+6c/ClM3jOiQgsUwXReFXLTc1vIkQwzU71yrHrNgI2XzAd1YqW9vHRTG+pEwL3/8SrDACfb5ukx3hEppDwoLDX+5euRDVFbTlNAeXT701Nky+qBwjM4qHYm8QmM9+gzao7waeAiAq5G4X53qYeYY0VfE9s9nG56A6o90BMOxHAVpznKS1+oJarS29oVGgqzowmxqNCVBDAv0Tui9Fc2T37TqYdKbo0g+44RVN2/Uc6Fs0Ah+rBsrjtXUe41I2Ot6ctf2dYnfdJ8L4BBpffiE8WwqwROsePNkTi9tcCAw1gbZ8d5ApyBEzGi+GkOziHQj85Do3Yo9iketaOhtYb4TNVK3k7mdD5U0nxBEjGUseQZAMJwPe9670gACDACUXS9WG4anj87NbOdbEWC7Hr91llx8dn4tpdV17BikFV3vijxA2mg4GfFMnOf4oKPaQ2ES9n5Q3OWGj77QKoBStjzMm40UGLx9al51HkTg9yje5NlM4I5619r1Cey3Eydbta/WpesC/gakX81KJmfdyCLK3Hj1hwKNEu3g5u9jyTAW6JXyjkB8KTqIkLwbWOvsgYUVhln1LQfzO2XkusRRMZeNMcwohmqdmL0q+Ld4UDXYm96sM4n4cUnEEfl6NQJoM4VtWnTZG5Edz6K/WaF0p207g1Xg/UJeH2T0GJKU731HEPTd2EuMscVSKKOzmoAGdj5M/lIGG7T8vIL3wE7VtCZvZ3srMb3LTmQNgD9L9h3tUmEIr/YEGlzkrb3ImCj0hnqBGVz6ayqI8kD6ZMThlauoOs35J3tAPShclosfmwOTNKU6jAIOC3TnfiBho1hZOPlDPzop73SrDdd17FAD7T5LGw/Fux1zXkio/8wBZNKoThTi3uTlkl8PZh7oiRJdwuxpTQqS+IH2zRKAqhpv/sj20jmDkLAZKUTEZhLgSFXl8SqxNW1HojHmfqL/ZhZHngoM4wcpykhRwFlzZU+GfMRfZXDOl0vBPSaxyIcUgRjpH3SJCwycgLtlOzz4oFU12F5yTZV38qLvGOc7VYDx4/k0qA62S6j7R1VFu8r/qcOnkVGhcfszdUAujiTHdXeaWofh3ZBx19fI6qO2kT6Of4zzepfDpYGw98pIr4g19nQD/0at9eWUAgtwCk11guUX+xN3LdM6bE6WmJaIYtZMO9x/E0B3jvo5m1NK/gq4dYrqzzi40gP957B4Ra02k52KgO5AL/tJ/efheRbJv9ScGxIpNWYAgiaDZtDuHZYBMIv6CgXZQwoXhahFq9psvUA+Pa46uGufUTzkG/pYAOOv9OhRo17r7F3yfArjqLAiLAbYCj0fp+HpZONQQEXwqZsRVWPXrkdHCzXCxhLX5zFb9WVy+X/RW8y5D5mXoH9v0oxFwSGHTT9ohZ2T917JDARTTBBY0w6jgoU9Nl6pM0toBONK9CrEVg0DIv6Mfzx0WsLyL9FCQXgAAJOPJnWvOJCTEaH3QqH7EdymfGJXBDTEsPk02O+bMipfSrlfgD9YN29YLMKF6s3j7VIQ76I6/8/2YJNnHVqvggAZIAtldi2gchX5Y9ZYz7cVGYEMJ4Swa/R4hAWGgZZQQrAtZFUP75cR10uLoex/kpkzTZT7VIE6mTdyg+TOpH0qw6eSztB15KQOziUFfh1qS+lneV+ONDKLq0MPEPoP5DveDD8lgyg0RV4gtWHuWNnolTDhZ41YX2nRqgtHDKKAtIXR9yDEt+gVXxefK/byBBlEWINQ4WTp+Gq+bUGv62CBk3fu1B73+KdWXPdA4l+s8eofdGGO98ddoaaUXJG5nlQdVVbb1SFtumDPbxLwv5T73yHw+4ltAARqX8ZUBZW/xeLJOvvVKiIiHGlbfAhbwmDT95ITlJrGjL0GWN5X0kUavdPJ2oQ1CxOrqtFYE6iHv82NiyKW096X0CapBZv8C5QNxHZmwAcvNGHiVq1hcnQZQUO9YZfgahlaW5OgaFJruMpqmP3oVH8ZWz1FwSMNnKKMhBOcz3+KVbY/182TYx5YEE06AwZhM7zO0YFWB9YtRWHaKvetG9Ort3Joy+Qzk4HdWBNpGdp/3pquEZPD4M2vaIWqME843nH1R0ADnxdWPlPXS2bOstmFdXFdTPcMW8VduNUHmWVDAMJF42vrSQwYPbBys3w/dftQ3lN+7c/C+ljA+XOHdL2tnu8oab70OsbQCHRmiVLEo4fjYFd+vWfQZbSkUcltdlOTq02rGj66s4q9SaZ0vab9NAjbPZ68Jh40lspBhyzq09jzuL1Kt76Fr030A9l0FvHJuh+pPDqq3u2QOFC1zqafWNhJKMXiH43fbACLkBujnp1bcgY8oJwVTEl4qpnEKghOP4ekpObpGfmp5Fv+YpwKzTQv/DszuUY7PgIHsnjJvy4dOsnMKvMOzelfPHX5sp/UB68uaDOoC+/I3VCYqMdHKQOEh4EKPBMhrlgtLvdcuWlpgiLJovnttqvCz+kEvlWVbUSa7EmPDQMN26OfaumbAEog/VVfx0aNwQEkgrEx5rxR/iIEZUMw0uE7IKw3+hosvQlpv4Tvak+jLpnQMJElkQ2EUkpULkWKNBj7omclchSV3BpQIqGqdwBwp3uWMqRiSX1GTQ4r6E47QAKnWoJBKkJJiujZ9OwDDeZs9R9+C0sOSVT1TcshX38ylKIqNC9EQRSDRXldM/gMlIqDd4hNzGj+b6rhGRcmno6rpCBlv8dV49J4mXDhaKc5HhF21uqJZVkgT/x3xu7kIRT5M1lunAuPigw206+HUSWfNdz8bxK6QY+JAyT7cHT6enVfteLFnkP+vK/FL9WBgxceptKWP4QKHHIWKd8aTdAqt+02aZ/BonmuKkpuITAoVoFG4TvM5gMpzpBFKdfbJ3SLg0IBQOmnjDZB6wXTIbLGNYdWJSoDcdWbu/LYM1dOMAa90e3+6d7f2cABmJUlMa1A1E4cyZo/Nh/3+2cSZVhdfKeLfBTQvo0FFeS50JaDI6VTdvJUTL1iIO16RLsMatTC25OCoa2jd4WsG18PAbJn3myCVmWywlpnqIo0dIGTNP7/b4G7d4Rm9pjJqN5t2ZDyAJK+CQNyu8NaNa9a12XaunkIU8hg0QM0FoA103wiQDwGCG+S5gmUsTmOzdQ9bJRtdytk9erpKwjbor0h7iWXLYD8hXTXTOk3cCtA8Yv/XqhgNfgJZVCgSlKN+vrggvL4cynC06ox6iTU//LR2s7gzA9BYu9gncB+YigfjH50Y88tH0X96SRrknVo359fv8o2YoVh1DoBH8xG3Eg5gHXh3pveh6Qd6HLgaf63eabYcLGDS5YkIX/hNFYr2sDksjU/bUDMsmHP1fHSeP5uPBykUoa+2ec4TbL19ASoLhaJJZsaUgEXADCH41jKl1u79PnYAFj9BnmhyzZYAM9w2lAgrnvozC5ix2ostuoKZ8JRvqtt8w6wEzphNjg0EpCfn3LghfozCD4+oW/L5L8f5kNPP/GwAlaO6EAV2speJf+efyP6JkrESixwMoUoFcg6WUIN9xmqkkElHyrCKJl98bEbjVmw2CUwwcu7wbgkAgV7Bciye9GS7tgPH6hhdvREB4pqkYZ5tNnjnQ2rF6h8Xk/2vw41wjv/Y9mMbAncxyoMnM+nKe4/2xz2NAMaZMAvJSCGqmz2cXN4u4s/ItLcgYp7QR3aHZum1W2W/dx6UXhVRxHCOmwYr+zg5wvgLwaOMz8PegZai/rUfL82/oqZfI3QRU1O+AHdXBfYm2pIb0ozWKP+4ZYCYq1cnIB5tpVbs03iEV5utqSfMJn6zn9Vobsb7fzNyl4QaTQb7E/8dtz8/FtcCdQ3rnWOSz4TK2vvS4hwm5wEaRJTVhmdfIRENVvt14nFdk24NmqRJYaZp3tQBViA9o0M6sY10sVTrRiODKODjOlh8i0H9guGVcEZwJTCv9ZKpZ590hdzQvV991n38pMhBPdxVALy7nolfk+tv8ju8CHEKo1JR+dGnVoWdTPnk8BjMbkZdcsloK2dh+0hApnF9lZSP0gXGcYK5F10boHSXO/dmKVd2RXWXX/1OKYCqQAADGXpf8TLVMlZ4ROxBG97PD4aIYJWdtinDKVaICf+6TdOsvyR+2yFo1C+kX+UusMN8w7SREHYEWvG5C2Xcnou5Bb6Ptq9imy/lZ4ZY0DxwSjGsnfDnEi7fkL3Fx0T78O/1havuimng77Yg/S9NX1R+RdtFivDZgf/ttDwiAWr2b39a46GXu/vDvM5zBdfjJLbr1gIIIUNtjCLYlPY2I6Jz12yW/yL/J+gQIYEj6TWmI+TsJFryJAioAUGdeRuRMgfirFEWZLuPU9W485SKie+mY48bIaWT+hj0YcffRvB4/ayaXUxY5QGSBT1+RE/nETA1Bz4Wv8GEyzcRHnfKeKJwJbZny7qaQOiYtWQfwYIgtWC6w9/82KKheuNYn/3DXASaNBevMt3Qhz34w7llCc1R8EhBeoqXWujy8tzCChe/aZae6CUtBnAOf/c20/lsQi8y/ERT1te3UzN4YwW0Y+eo1PpUyceCh02qV5HvWmF2i3Um6dNEgsu1Pq1uy6to4GElr61JyG5D6sgQc6gjmeIsS4WZARMcRGRILyLuJwtXczvHOkrrJTSnFjf3h20de1G6cA7J4LBVwKx6GpcXUKPCL57XtmBShFZho8Io0k+pESFcA0xVFck4Z+YwYaZ/q1A8H7tbVPM+k0jJuoGL3Yx3nMi6PUW3W2VmFeNc0W/QbFmIHqb8prjmhHYAw45yfE7wKhExt4AWliDtfzc/Dv8IZllO4zrN683v/9Usje4GDn8f0//EWAldSp0QFdZnwwu0VGM3jXshALsS1d2fdl3VkWOhuaOX5T4Ww2RBk/Wcj22YEAWvPtJbwSKoiVnFlHG54Se2FSij/JjNjjCelheHu7nUkUs/okGqFfgkCa6DL96kiXUxLZBYOGwG9GJhtr9t+VMas6jloHqd7HdDwJTD9qPFLdk5IN4S+IYFID6aKrJghRSBLrdjpa6MdGTTSVU+SpRTe4sfClmWQ1eWFDwXCMGc/QcCuBVdZwIK+RVRmx9H34783V1q6L6GEKr0hz/Y/PrOSyuoteFEjbCg1v8ixx+i/dpCJLuDJO2Ja3eeKycqNMPu2G9+kXwm6SxT/EFMVPGntOg9k/4dWJE9EMSkvBqdfpaA3eyLAsIks1RpWWcfVUtLfudpBwPfnaArn1ekxrogNzSFkEi2d3W3T4/Mi+FGs97gW/A4mldA8kAg77+/eZ9sjD9ei0rfxEYyTcEFuEWenyIs+F5Aw+gEdn07lhR6xvMH5A3s6W5zzJro/TrQYJvWLkqT2RPHGLBj1mpvyxw1YMsUUaCfz8jg610nf4hNia2ZxYBH8vBssnFJ8MO76TdBGj/9pOzFitlfp93P0+dTegKSFTdTEM8oj+cdYdO5RCQHbFb15+fsOQnA+m5JJlDgQYSP650/y3UzQk4FW/Gep3YFEeLhY6amJBI/O/PHpsOs+loVw2AeGroP0VbcQx3v8wVcVEqkY6Z4NN2IVCQvHSWKzSQmsOZPFBsMFH16r7QaoB02mW1/WRo5dSqgI6eKsPZDsWuqmRHgdIGwe+zrJxV3LUfv8s8xfIRr4zMDkTZLzjhi8oTqi1yTVPSxHJVJr94/ffFGd8Lxl8ZW8YRyRbscnAVJGe1x5mCZC3dDepo+uMgbLw0odsi+qNWqv6lWiECSjxDzqoIsiChmG1Xk44AGzDYQxg+D3EDMBLM+b+8nJytk+UlexcvLDpA26crPximo93Q88Sp154yuijC+si8fIoEnKkPhXa1xjdqeLMA8mB1aMzMP5UxokGgF80QRD1H2mbYjoIDeqLrswBogpbu46pP/F21SBxEkI5k6dw9S849qTwrpDyNQ9Sy/J/sxOMqIl80feoSJ1RT6noQTjiTu3ifzVmJHOFYC4hKEJC4rW1LvZa0zQViT8kp4y3ToYjqIXyyxd9W4NvY4UXrgggvTv4rGMCwEfj4v1AOx3iXEjd9W+d6dXKEOe+ANDIwiKlTRHI1nTLlaJuquizT2aDyfREORiL8ddKbNDDaW9gDCSANQPOtJXLnO86dMltCKC2fnUaKLXXdoR3YzUKOgHRWbtdu6ub3m+IbgiZkK5PsRfnM7fpdz34OdHOv054tdNWN4OjaNwvYI4r0WMMLZpZDEB9q8s7rx+tYM3HNWnaHTG+Hk3cQRLkWrqi82+Z2z8HqO+zPsyS2wxnSvp3xM2aAfnvpPQ38rbzztinEdOPn6iKNCTRzmc4dE3wKLbMy469eP9XcIPIs/d5o+Av4x/y2bKJ56dKCxmE9gkrMSndHZwdupIf02OYiYtIeDsS7o1jcsZSfToXwoXxWINg5wqyyrBnhiUy45iClOKoGF559xK5aN98cwtDTKq3RL++pN68l/YEbx+sFSFCHcHBMqZ7dnqemSFKPLYBcH0SgpunRLB2VF7yniKU1D3L6NpgVNvkibLYlLcdBazgItqNlIBlqGVk/kPCOX6PqbRn6oeJ/8lfQAnuzNqQD/Zyo00b7Hj5qS8i3zb6FrYRoUJY8giMHDubtrExY2NFkjkoCZgqzZogv6YOAYAC7jcsiWcMsRAbhd4mUd2A6/D56WgV0jb2X0ATE6G0lizxWIlsVCY1Kucimj10pLls7PPEuZMidtXbxUFXR6MdCgD04eiEBK/viM9NHTg8VK+2M4H7OArRKGrC4zSWWBeLBfOo467qTczAvftYhXf4QA3DmiwtBuGIZPAfjmI81ZSQ4ojhhdaFql/p6CFUUS/ksTUNEDoeq5YY3uTindGUzZES4oKHk2U1JKm7wpJiu5eCE0oUNyg9QizL22Jmy5lKk8DsU0Wzp7IC9ZSyKvvoyJAUobYtIcLtg/tqmNUPDseFOlltnd6RLw29HxqJqXYo6ZoiRcDR1iLXv8ik1QioylQxVLWxrEg2ny6IajEgmuZ6FL+t9WpnAj3zE8yinnpsEjaHmSuYkxJPiujQUy7iD3fKb/u9Y8akcaZIixhZJq4REdn4dxogzGZ3+NjWBHidkiCVXp4InKu/lS7hk1bxbl2VNVSmOQKekyhOQ3VUECNIh3QrVSxqAZXXHJW5xp8IKmyIbljA4F3Aac6bdKPNalEj4h2kga9edgQNtwak3mtQrQl4WSRcs1xPFgxxScEb5dc0XN7H5OVuz0L+4LuaiwMeCC5SStEiMu5lV/B/QZ+lNXKTwXVdvuMSGuiUrTFE8Ss3P58JXRnZkmcTpIt6lb7AjJWOaY8jroNdgAI51mR+bGxHfE7DkbNvNZLP3plr/Gf0K5VtBTyP6KAGDzUs7J7Y/yH7kNyaz018FrbTPBCaCaONAB+bXFESGSCjtKHmsUV+3Oq6L0Yk6G+PHhdv+zdwNCM+S9ou+pgsvTLUoE0wXjiRlMcVOR8p5eIUOrNafU4icSP+fLYNsduqRNUJ4DGq2897fZF0UicFEmsV7XH7D160U93KKAHHHc9gQrvdlHpjjdI51jnujA81sflvAnCSbaHIJxTx/y7JDDml9T00IQLdAv+WffCybbodzsR6rHeu42reSq/fPt7usUMNx+5q9JDHfKH3GQRCOmiYz1n/CV3HMf6vvpTepr5Xf7PTD3eBA1omY0riDKjUfIqwpi5qXfwLdfdfWuYrGmTpDwl+uvtWEyTF0DBbR/KoOAoso8zQIU08DwMbW2uyUg1slPHmBVU0Kd9c59Emch1ayn/W/Qundl7adiNI9we5EOtyOwoUCdZbIGLfaT0dhUrxR7uDE1ZFdae4qLj1oacXl+dolfeXFsMQL75ex7ME3n07QWJO3LJni2yzzxfCmnvqmVO2Mp/wmdhYEEaGsb+NZKlm8Yi7Lid6LkRbx9rUYnV3kcgIjsbhDcRFzG/xaMD4MqgGRofR1Kza2r59Nd2jhcH7u0xmqOqBw5ER0dsb40DKwmw8MuVaAN3vJvUHvGJNcFtux35TziZFuh1rAFWniXq2V/O8HnsoQf4vugXQZrdUDmUKiHM4AFsvJF+fOB8or6nX7jSDq3iaAgfwSMEKB5eebDjmlM8oYEwVN3VSO2xFKA0UWZreE94gVSQeEUggHyNzUg5w9zBlhyr0V6Y3RdXAgh592Ctj5EHm5PyLe1sGN6UNXDAl3SqVC9EZonD0L84AY3B/glZnPX2NJT0/dXm8eeZ7PJhXc7/I87DlbWFveMz6/HxdBHin/fW0Spf4N2maiIn1yEsfD+JCrr3N8p5IHcQQR7JU/RB1FKQ11tJGG9uPt4VdAr8Ee1mPwb0OVUoUK76Q6BIpVkIFW4uHEcZeWUfQOgmgr0sgFMzgwoh2Ln3Ub5vvcArGbP8quIV4dXfQ9Q81dM4eWx65v7J/RwCZ2jIIkYqPMz+CBzK/x2Isnj9P2NT+Kj1Mctj/4a6bdaqUAWh0yPLb+40YT6MyZgEgwPjOV9onk6ryVg+Y2FE0MzkFdTH/u2ZNth1JYa1HDJ2bNlNvp4Wtkal+o2koVgFjNR2rIncdUPnLROweyLLzZWm5lvHr9/yWArpiskp9OG0UNd7iH0ugblmDJykeQyOkeWOG7WbCPFvyz0GGiJV6IERDYc5tm+nikw7bqdvoSCNWqeMxqdmzTWvkPhPE+0qBemgzSnVoFvosl6wRms0hDZzYYJrkt0QLVY7Q2h9/mnequVSgsGgXZ+4WJs/n4xl9NQDy3ARFSdTTOQQy/g4kqv+Oemcr3c/Drbl9Zoo2sdM3Ix2EFbXKwaMLbfYfiY4YqInT8DiTbvjYWxmojqwoB+QhAHFmwxEdf52OQiEO2nSNZE7DrrJKdLuEGW/S7SrS/XwYLDNjwEMHdawNrr/ROw+ms8Fo+VBiq3Bz7d9Am4xh/UE6yapzS14SWWLvEehgjjfuF6Pjr6osZJ7JrFiHW6nDvMvifbvm4X2267RxinEphnn4j0zkZhVMIVEqtfyfREdnUXmglhxh3EODq6/hHgFkfhcVw2lcoNJm+poSM5p9bqoz4zcL8oQXZQMGynw3e82GTrvB8D2gE3Ps4H6sic0+iDGIhaPjjOOz0wevQqizHSM8FV+Ay6PpGjwOQvwlfLr46E2mxGgQ/+igaP4QygXtGlcroeWLdv0LiACHgetN79DRfqLZsW8i65tfx6KEuiS4APCZ3J02lEc/osRGD160rvTGiOdbd6iJjC4Gv2znSiv20LXioqvyUa4zl2ydV+a0Ummx2PS1z+4n3bWPwKNTRo2v5B1JaK5jJW32xvBZnX3xfTSYAlTfBpWu3ykedx/eCSZz3HjcnIsWaQM1G5rrztLD5UhiYRolBIU3jslGNv96Ppyvjwf3riL0GByFWcVzSU7hQoEGnTiLlnN0WmdpaNcqfbT1Ch8Lm0bYRbTOVLqEiRC0KIFdCILgnwqK+IrjyV5TZXR71X0QIwl6vK4Y72F3vjpG+4W6pA4k4KD3JAT37bgjKKQ8yYJOpOQyf7XbP9B45Ru/q3g+EhChVk6PjSYSEjF9lpYKaf4AtLI8RkTR+0zmQLElEMYPbi+FBcxawwheItsVpDswiOZmvnVeRe6UrgQsjzMgtaXYEGPjs6CL8XyQEa7uQrJgDKQ94O6ydcqfzpMpLqPjNmbfokKvW7e0dbnNtb2acll9JvLLFgPTrk/gf6gmR3tLfVezgw3YLfruSy5Cwcgj62C2L/8i3KDJmV89G4HzlQi+qdBIehxbfxei6FLK6tFqSX/+C4xCLhdqRoQOR9neUkX3grs8mdUqLTpSoKLtgFOmqz7ZXd629K2ZQ+JXHL8WTazWZIEIX+DJRm6MDwktou6dP2WwcouuJcpaI7ZycXAcPg4N5jEMtG3dagtwDovDAmB14mnMW5EnOo5YsR52iw7y81MOa+ZUOyPrXyW4JPi7v8JVQODDuDES+Pj1CmfsYmmkG8vwhGVb4/TQXhMSra0rD8Ux8Iw2YhiaxvRtKLEG8GCE9Am1oQmAEJP8EE6215vdldLeGCj8nZqcHfsRSRt+VPC/JTFhVv5lApYsQ84nSRDLYyncIb9Re6Vfdrb24YaMd+Phspe+6x/z6ILgIahAdASY/1MJJGDUz0IEGqNrHUkDO4Wn2QMIPp8jybX44pW/02zPxp01QULtJI1cAA=",
	frenemy: "data:image/webp;base64,UklGRtwrAABXRUJQVlA4INArAADweQCdASrIAMAAPlkkjUSjoiEYPeUoOAWEthOBbBQgXKvljAgAyzUQfyv4zd3tyX0v5K+yBY/8D/bf2V7Fuv7rjyruiP+/61f9V6lP057AX6t/sR7fv+b+3fum/dD1C/sh+43vI/9j1c/3T1BP7N/3Oso/eH2D/Lm/eH4Sf7X/3PYW/bH//+wB///UA4F30UfRv2L+4fk75v/jHzH9w/sf7Zf2f26P7D+m+H7on/a+gX8g+1X5j+yfup/hPm/+6f7rwH+L39d+ZHwBfjn8u/wn9o/dH/GfFZ75/s+0g03+8/8T/EewF6ufR/9D/cf3n/wvo5/2noN9gv9/7gH8q/pH+0+5L5a/2v/H8Qb7L/rP2K+AH+W/1n/o/5T8tPpb/j/+j/lP9H+4nss/O/7z/yv8D/n//j/nPsD/k/9M/3398/zf/2/1X/////3R//T21ftF/6Pc5/Xb/0fn+kfzSnH+A3/M2BaHVWUd0RXIUwP+zH4Ew/fcjTCcODMXPoL35vTnle43rfc5BSuPi36Zhqklvq5q5a59AkhowxAVnrI9GKBn8iT6Vo6sG+iF3vanCs9Vt+xkIZA0/RU9jaJSFH7IjS1p2s0hWr1F0ZdKtjPTLg7f7yQ4ZLwFPjzDDrRpJxHLItw67Nl7XttHWTauc3otQEOyZAWSPEoyFPKrYYYWs30AmESkpLtfJdlcdh0AATw3Wt4IpCC37bRxIQ9lB3qLn8jAFJskhnPYARNH2XCBmLmpNCLCFYtnAGzMx+nmbrTjFFSHHmY/8WYg7ASj/rK8qGUfd0JDmg0SeFbxuE/0hKcY/sMyTFBqny5i+6lhx/D36/+n94H3ECnSCOuIIwi7c0ZFTDZQySCbo/iZtGOenHcwavXw7WfTXSUUIS3MB/jbcMZSgxxP2CsG+0rasWAmyzZjBSNXdhOsO90zzsVEb8cwYiL7hI//laPgLT8iL/e1Qi/lhEE3UF34x36gN/oIJmv96rojHdYyome6WYCVw+fgv3Y20OuJQf0xcLIxpDmlyFyiVeYLyvacrmj59SH5G8ShQZ+HWBbsd6/ObFsK5azqKhst6vxOmWPI0uZDfOTblcj3xf8XddsNRgsW979IjwOnPdnQrXmXZMmYDRMXsR0U0vKWnAyWHg98By3g2Jm6CXEEXGFgs8XZcTaRRvtp+wsKF2L7j6cXh8fToY6zZmTz4B8Q+mMmMivhrBVrDOrGzRPH6U0mPnaFGmASR/h4hZwMPbrikwqG5DNwF4rm8e53j1GqM8Zf72EtGZOH+oM10iklvP10TMFjkxq/bZNPvYPUj8+WfAAA/vmewg68j0z8Mo59MYZHC0z0m+M6rJmH/8d2zu6kjnYiuPUhWnlQrBRl4PSAdkbhwR2QPu3fOlguy97ilnqVF0oLKvJoGqzn+Ppyc/PedwQYgBF8m/tsqbs//lUMC10u+/X0zsELI9pQvXEuHaVP1EdzrObjPvznezyGgyZS+KvFkh5ibwKYpJ0UqoUjqKKefisN+dRGD8552VADl+AOHhoWqgAQs3ACIB8c12nfrLi2YQAOzVxU7ofbfC6B98y0X4E+2enCcNChuopPC7Xi4TZZJmX+ac0EdSEeqbTpVSfq2q/hJr1rnk3ektsrf9tGraurfVzbqhRf4qTadvLULV7Xylz8ZcqNf4ZumxJx/pHhnVpYI0JR/82gQhUtCZS8p1NT9nIOjAjWMIOIX6P38wAoKpPVUW/kDRP9bYXPFG4L9BsaeTJ94pX+8rKfUiIxEdBcRyHroB6oLO4Kd1n8ji5On6U32hr+26M1K5evWaT3j5HHrat+CKCVSZQ2d1CSfYy6pGyjAgo7MqXRZjm+AgshJqllzWGYemI589oIqPvlwrln4eQmSyH/haoZvTSp9T/zni0ZNo5iK6gtNFC7wkWXqTl8T1bFDb2WaAahc85To3wXec/5RFJe1+178dyK3GhqE/9YQ+v7e4tYtzqo6pVl4QgNKccVUmyyK1PfkF1XNF0S3FybZnw+UQBViv3GXVHshDzYG3SLNObmE4Pvo3UIv4sAuwyRRn74bL08GHY4EICeRdsx98wza7LI97oTrFXthgeRk9dGIvYoqebt93n7V7qM8bTfuo56r58eQx8A0CMDQd/CsKbIjP4j2hn82ZeRxq5Z8ypnxAgpSVlrDULf27hRSAOVnGtuALwGkkssFUCYkKk524RQ4F0SSqvk/x50i18aAEpT0HFOqzxCIwBD1vzYkbvvQaqM6INmb6Y1caxVlABgWXSXFTzS9o+JnsdQCLAvMsyfVG7Yw6/HAhz3clH8O6GRYwnNMsnj8Z6bGXo8ytOllj/pp/GThsJP7ErbV4asREr4eft4eX15XJl90KB8JuA/Tc5nWWWGLaqsz/9JSiw1damDSczU9oX8JgBcaB28PP3+mS659NH4ymWRM5RdK2k/D3Q0ptAiGU3bCUBPsnASYpxfv2glWtW18NCtkyO+iSmX7NJBgPJn5BCgwaXVQ/k7CmYuQv2ywAAEOUuSB2jNrvV7G6ewfABxrBBBosWN4r5DG/z12mlpPvvsIPx0AAfVdeQEPm8J3xz3LTK+flAvU1ZTQBHSFAP45BguCyXfXzuQ3hty0NqjJYTu15F11YXWEGuN5m5xhKa9KEYTxlZen3vYl/CAqRm4ys4yxh0N15UbglgCA7SvnB8NdkNE0lfLBhxIhYuNVyjvoFnsA9LmYN0p0Qj+cKyeXU7ugG9LkKUKZwlyG++/Q/Ka3rfcpWfwMBBjcZnHUq3CYJYdgc34xFSEylsl4z5ARy+9Fl4mBxCKyhJ6bzMO+cWM9PaDGWH8IYIVdfkxr4QX2AstXWckRCVfLVEUo+JtFhiy53UfLEbqTUGTeKwUaK4Rkr3dtrWeRWTZtDrn4rlZ12xYV7adgToMQhepn1mU8asGQmUsqJiKWx6CZLam+BrIfblkswnYOY1NwiVpI3FEBWAkxdavnhVNs92Fig9U1PJseEVhCHgJ0gaJiDRYe7WkCyilhhzeREESCqyteTTuqZcpwHbpKX5DYITbBoulKtDA077AfmF2SdqIWiTkeE6/Lgz1f6nRE/1fDx6ioUQovVE4wXEDoF3bBF8lXi6/uIJfSXdh0x1dWXdTED8iyM+q2t46ZzPvenf4cS5BKmNwHD94pCzlva40r/d8wY0d9WlPgZxpWmppRLYWuKvKNeUJnGpv1RLBM15WXQJCKB+JrKFLI7SpkMt40A1324auTLIs/8KITeWSPGSv6pL/XGtheZr7sd8yS0NCyXiTeYmbKxjJh5LXJn1TceznGzDXN+I7QBEvXlDS94nw6vdGct/+UJ71TSpn7zDUwq+uwAPO5fSgicivSYGeL5zB2UCpGhtKH+MxwpwR8LNIbKsKPIp2VEbg7eVhaJy9UXMkEGthRgjMDIMeyARB5lS2BM0+4hdF6LgcQT40yPeDkFJQuEUk8i5SKJtWlZC9tOZZD4QsgKdFuy9Rptc1iwh5IrPvhhpmMemCjOgZn2eorAU2Ubw4zOHS4TErfQEbKgZyR3SAG7xE9W3fpXKRqClyiylwbuOQXqLKVY40d+IrGC396z6Okf+CuClsdTN08qiyqnqDRkRRMpgeuQi4pTuYEx/7LYwj/SzR+uvUZbhIC7ZZIzQSlM0gRfYcrZQAAGzF2pN+Vgu2b1fq/uNjUilptsAEEonvl99IkN5h3F0nTBz3thl4Wy3cHiU1FlE9yN64jHKfPz/RY2F3YXZX53/VQVzvw6NXNAPHNBZ2FZ2aumv4N8yLJ+QUJR0Orz6iKEmCacGHIx8ctxad8yhv4FkgH5tFo3qQA2RlyPQvnLuCoFMJodEnzK7GuhCh2HxhgY5R8xsRZBRTQKl2GlXE0Aw4AtiN6X2Xz9m0sQPhOwf9cGLFPxmO2QonQ3zUXvFTozgW1KHQ5MA/6qgqhP10RSA2DC230C/TG/t07SFBPZGh8wiEqDwzCFpoKwiRb1CYVSKVdMBzsABiBNvUCE9xoVWiIfapXofVTF0uq47BadPxpjJUxIb68KLRZrRENI9MW/e2+WtqNlYyrsNKLVrzVsDlfHU1gDNa/kbVGo4hPK8J0YdALy9CIAU9xq8nYl3XssRlW3JmnnQiyGR2wN2wPATjzgm78uhtDG5kCqoheMu45H7veqlUoZSF6E6+bxm06uA9G/HHwIatcg0EupJqX1sBt62sLvLFsHOwu/06pW1j3rRx05nSnuksOlcYKlSv/dlqgN1uXGsNCdImchvAalQk/e+/quDtcXymt1nOz2Fyh0VgjgSIy9tQnx36eu48HAYle7m2P1ur4nxBVodkWLI1afx5IYYWHDG52Ji9k9VhBkBYBi2GEDV+IfAnElQiVYQgRIf+FGSJtcp9QqZ5h+06pTW1e0bAsruQ+HxQmyBKG0xw2RbL6jXAXV3bHrcvUv65fCrDWwWqiz+4bTLaHmDkiDVIR4S8YECCPK2T3YheVdhbwVtU6vneZsMHvk+rqGvHAC9yGhUrSoLvd6ylS6H/bvQQ+1WtUhb5utcJfwBfOaPm0QnYOkAPiXmGFV4sPlB6AssuAecku1AtLT8HYi4/bwBlbJMO4itr1e1rIU+KM5Awoc+3+JYctD3nU/Q4NVQRuGhKoTSn45AsjnhZnNBJcBvNH/q3JUzaPbYGPdIyFMpZ858XJR7VScfWqI30OkyAQhkVcKt+3rU4R6cf2AT++JTCitwzlSgAAAGZIYW17+l2rLlk6zozZYjfjJzfFVP4bh+HW2Rttox2mroJSN7EhRTx38Yxu28akBkcAG5CDV1IGUcqq0DUN6Z/v/RZe4R2QJEK4L+P8pHIMcKNG9EJ7Dj4nxvzppZWyZulX1Qb8yQmhNHdljjdouRZ3Ef9zmfHmycisfHgjYniKEgM9DRaNqNXqCoLLeRS7XMOWOcI+KWA9jN5JcLPD8H4XWQ1iC2/MVjReY9hGqfmNJTCLgwbFxC3Kyvcb3zybB9b0VOrLb32paiPRMdPs6364m96HfNDixYh88ORjSvbJUb8Vzl5ieR8cZQQjHQ9OU2pr+lzBULw/zKUDmvN0bFJv20LmLSguC9sZP46roDiJmrhM6t3edNKWJcjtKvpfIPjgsuQ0+shk93FiDjjy95Uv632aY4yh4W2fXtRMp69n5v2SM5KLaepLt2Zu3crJKcPK034cr0mjD4PudwwhDvLKCV5EiD7ReexKCwvUENJ29JuuxRaFfebMYlusqbZ52FMZflX5C1WCqBX+WuSOoixu0V8m2EzZG/E7S+C/GBOZiHZaq8ALej/OxlFDh7dFEUcaDV9ChZFkRu/hcJ0HDRGe9jUj0PKDe8KJA22oXwn/j0dmuuRU4d2OdSLLOwLbJ3S8n/RVNP9nEaKWVs1ClfaRMTxhuYgi/8LxG4JaHEnFCk9TCL2aZIBH9yYJ1PmkF6I0ha6vZar4J9t/yqVtFdjNT5V1af5XMBABCjUeocv0d44MTMPhHPT1v8gErFOfCA5idSucxTANMSv7v/rjm3eYiCOB+u+Zuu+dvALdlAMhAbtsMFefIy64Unc9CBtRgS7VsrEcYsvcYYYthw9w3l7/TGu5ShzRyvWmPleO73c+fcPJ/J62uRpgubLsCpDY7Eqa22bcrJo6r82hPicsn9EHD8XKfxGsqZsMO/8+kHl5jEoi9EmnY6lchHFsO7zBSwXv3GklwDPjf9N4+DYL9eAomHbmPVXloTUpaBvhDfoF4q4ErsyExI032fPQteXU9BZURg8RTJXNqQTb7MJ1YrG3qLzQfdBPsgKr0AlvYX8mjbSYMCtYGF2pgpexGXt39AFwGnol3/Dg1uR/T+xrHTm0tz+qg2XcNP3wxVh/b/DJEdOEqNbHBV7TcOzJUcLYmdq3nqVSrtpf5UA7CgtgVS8LgRZ6cCyScnLCBygVU3FMBFrgO78slR2Tjf+O+nh9QqFTor/n/NMgB9mRo0+Va9m7v5xgBFl6JZDZ70lewLOVDZLsdoM5WLjR/dEPmR3GKgLvP3NN6z6jkeJxSqsCWPLzEfJQ/EU0Bi1cOfrIrTwKMDI3wP7wvSCYBZ3ZENCaLGF5gkE0GBHhXBl6dkhlXbzEu5NWXWGhzarNRfgL5bWQoSuKWhMLjULaS5gt3/Eceawm5+7SJnAF0vvrrSIZAUxrkGchI9jbCCgqjWJ4/2tCWJKacKs6zZ2Z3VROnLjMiasXQeJll5SXrV4YkZYYExCtStlanPMtl8lB1iCsc5m0nVmzHAu8vQCS0GVfmsVbft3D56/oLAhFpb9dXupAckBTdPzuVETXRwoe6ORNkj+dhDsu+nV9P8KLxDpy+gcoWRk2MkKckiFYZqFARPQTYtTT96lyI4HxlWonHFfe3HOfcV1KTE3O5yZFQzRR+rKAkKAGeV7EjNKPoxjOu0fZDYI2djzsHFed9Hn9mrKOkSOhFDIOSTR1Lm4zVAruwyp9YHhu0JuazmSooKNpZtqUdxXdG/iNNyfX4whi6/HhrBDLA96S9mmjMmwJGZw28qXkUJmQk5aqnZZqmFwvisZY/mUJv2XwROQ6uHbdGxU3uFInaEOc+DJPfZXgJXykT2nHKJtlkKminwvuXMr8QFSW274GYmN+YP/KJSzX+tgCbnyT0NYxQZdegyidw5AnQgfapvTeL561sg/KR8k6+osWbvQCQFl8bbq1OhYIQGwLagrUc2yDiux13ZSEnNX+mIXZtXTGpnpu2PhqABx6N6u859FCKc6oF/qmb9icCEKWvxtwdblqiFOAodo4f2yxYFcbmAw3xzMyjIXXpEMIKY4zs/tFvjXl0CHlQ6sdi+ApWRaYnj05UZie+9aLQ1r6VjmqH6E2QhEBsmM/mo/1xvbjUy2DOEiAGM0pIQjNeI2jpFHRp7lOvL1xdABKWvIHwVIvZgdhp5xA3BRzP/hkcppiHedBm4A18n6tN2W/4IeU+GqfwkLRQIQSr7kaFjngyCGZ3/qrcw1zjZqRCVaLPBNB73Or1yP55QZZ2dTtlCVU3e3cOhD9Vcp68qjXHYzFgdfDPA6RaLm3rWC7BskMIoEafItDjweCh4543f316ttsawmzibmrbMzf4RXCn083xAXMXu9dy/bCQIY0YLfQkL3eutzWBJgSevDTpVB/t7UzjaeszOpICHN6KkIQauqHuFiEerMkWDksku7JPuyDoVBsSisGp2OjQzv05BMcuqQiTKVRxcrQwHjH6DMVHd6vqWTNTc/acdsRK+PgUCGlQXKZJAIJG5L96DYSS3s2etbmfS7Ms9g83sa6O6kq/4+TqR7qA1YLo+a+TWGUvEq8Il4Q77GQ10jUiNnBtQLaDuMbh7f/bPVGrOjz+/B1lsfbikU1SMfMoWxOqLTUTTsu+jX5QF/FGG7/Cb3/vc2d6pZGMwmtH8ZMPRYDmSktOpeIqKkJxoqDnByCwSjqobk5JEAisWz6+vriLBf/mYYbQsAlZY883+MDgcycwa4LHsdFQIuPyBA2wIsh1aHeXP4kEOZDugX/esdn9XJHbOcmMJNzZ2c41ILXkJZ6eYAc9hA533JUdibqa5aVCJR6nJk/SupA58vGaSAyoTqDyilJEc541PDIdlFuCu7giRF9p5kuJwXgxSZjeyv95U0uj9m44RQyKmo1mfQcdKuO7glxrK2CzQkAHEYyZFHYIte6lo/ex+dbOA/ZpTKeQO3ufFMkPiSN5jicuMwkGY/nRTY8ERULMQpDHXus9cCP2/y5631+EKRsISyE8ZWSGoLMJ/F0pYPl5PSU7kRwy1BRkVsY11Q7FD9fHCNsyJqhjrT49085M+Mz/jJwNtOJVRpFKaw/v5l9k+1djUMZY+mE5/m4xp+fwUzaYoUtgL5Jzm+c9LB0OKsp1FfhiI01xHWetvNhUXS/cddR9d+hXFswfMvAahRTX7SZFWBXaYvbbHc1ShDJDoZIo4wN+wcFC+NVudhoU/sXBXiTyHnuTwXbAIETy7zune6gka6M2YF+Lz9lfs2Ga0fSbPg3/m1LYcdQbEpJ0mXneA060UyC6+fkfukPp/eBRKrqGqW/MfaNaqprbpe6Z+jbkU0YLTrKusSv4Kb2yJsw7AL0gyRS80rdbglHsbM/M0r7mqD3jeOnUGEx2Tzyh0ZOOiSvqsG5+yd1vI0nUHtVXiMvM5+cre862itjWFqu4ZW7bNJPpajoit0WFEFwsC6LPuU9gnX+IsNiwl7EP3qOjpUhxSPhMO6kVramJ2w/RFycl1mibGrQH3tD9SxDAnHwq5ZwJSvgeNKWbld41wWo/8JgtHvoDrVOVg+1KoIOx7XdCZtqdri8wyMMooFqfeP/jO7g0MZELdRQpNDcxy6DEkcfT/ntUcsldZL7wXLzbe0H1vhO/0bReAMDG1YsJKYxEH9Ty0o4mLnCbZzUS4QdYf96jpteCEHm2gHQhGDTsHMtNnZjACV8kCqiFKKYQamBHFgnWyBh/ckHz3tFQWfAWwa+FjvKQxUMvN9IULZT/jXCXhPIpnSh1I7pHMcCAmUfrWYhP3e0t9Z2s3IRuy9nlMeoijvOybjckd2DTZ2yw40YtJf0UJUlJOwVQTMNXodN8XefYXQqIoGDCz0SuVUa0nw+AF4mUCAwXxC1Yon7y+YfYoeC7iv1xxa+Rk8iiGHSvnns2m/zBXQ1AEQ9ynwqAZE8O14Iz4QKHnvOO0TxsZCP2lCPsFBpkKeQx4zujFt/apJyQ5Lr9/Aiomlc/C+WLdbTFTnd0sKX5K6dM52bf8WsKsIQQDN0zg5/J6isHs1bR42kd0e82XqOOWZO1YHShYc3CgCG87EYrrxoSZN2mjkktaakbj9JtFZK8D0w+mijzoipuoRbhphIS7Sywb8g0m7KDd+Tk4sxssmInPoVKZNG3ADpN3UxY07Y7v/IPK0GEAY4Qu+8oNMDiOqAf7eCXmPO534ThPx6dzT5q1sdj/EfnboNANn097pasltJfUBVwzuXkFDuHCmUCk0OhhtzMLUTvYsy0xa/MPQGAcl4vKiONYyYoPGdUvX5Dv+7kqAsyppllI9hjGnUYqvQPOsMcMO+tEK8+2iA9JeKWaDWvlKGbhdYV9X0LlKTiApQ+znrwpBWlWlUN7+96d8xW77smvabPN8nMhkKBlFFU6efyi4cBQVDdTBRp/Ln2/2MVoPmy3y9q1r084GAQxCkRG4rKJW+9tCk8IE8hdac9AmPF8/uDPUbrWm05Y1wje5pXV9rMu0uIQ6zOptKE9FS6sE5NPO9IogAmtOVIIkBkzdyrXB6R2xRp154RU7+7XmbBP6RH7PQ+mSEuQpqYAeATIcRSQalhYlZHvADovsKD4tKv/LJ1BGfJY+eAZcRU6gZGI3L0A1oiJLO00DXOCnPmAbn7I8texSK1RUSxr0oxv6mUZLIpLoi1b3EXLU9vuL12hslXZ/gzBsZVwSccbcBAQAPuuo8mbVlOOb1sHpALGdISd3L+XpLf8qfCVsFsmXMhs01gaqxJ6E3J2Y+VP7z183WdsoH9WveU1sZqXKcIwxoUckyNbc5zlr/xw+CWFGOC4XK0DN974yqWCEACsVEz3Ij9PewBFGs+vaXNgEsqi/kXWbpdqXiTjaMhgsJyuWQo98G95kPZF8mwCGrbz6m4VQsagtxsOggkCgj//GPS89F9DhOCVRMWOLt2ZGB8V9BtmCxVQTUyqJGR8nLiIla8shvUh55kV/z3kkiSo1EBSNm14LNCe7HOF7n8k3h7mOhiI+cQeBF8L9WDMRSswpE8HvPWZOAS/sdkGsnGjORoRcPFqhv5dF007b+QiFCzBDmFAVyRLW6QGjTci4UkM7p1S3YwgNNVfzPaUooJO54+yjB/DpYHSUiurX9fi2gzO8et6tfxKWbcD1pEIXy52WaEXeveVw8Wgv4HDBlVITrpxd8SccXB2MnbD32OxP8c9cvCCl3TJzSxmL0cMRK3OeYsczt52hzKD0ThJiARC8nJyU5g78iQtK8zKqYxqcx0GkTTLXx5C/n+k9x53Lro/RRGSMvi0G5xLZaki8o8ZAaWGeyMS2IGOuMo4Oq8/bfsyh4Vej4ZztdTK8ivIsoy4QcPaBIlCFENc+g8LLYTk5AGN8J6+i3ZWI0yCD/GbC9EHHRQAmmyPM5seD8yAnA/33+swH4fLu+JSUCCKXPQtx/BYew6p29jXmMA1A9eeOXsxtSQQKmIGLccVjHruUiACkzXK0JuhYQFtKAp+Rt2Eh8zrw8PEtCvSENranEwAUuxVMHC3ki5bzkXrnd9LVjevUBS+esLboojee5L5zTBNZ6sRTzsn0Ku/UJQZf2+tLJMqU7aAcklmGvDkxngLwmfIZ/iZqEJVCrQyA1AhWSAzVV8f99M83ljmPYugPByporSyab2PUisjknWzlKbVdS5vTVEn4AfBkljSPwWHm0Y6wbda45xnp86qp/D0FAHgzp+FF+5Y/zZvM3v2HQ6h6zTJJV8WLNRRc0Ld6g4Z9024k9gST5UrBw10LKACxyuXGLCETjotEsY/S+SdcJ4fArPWCd10FIxEMdfBjH4exRDefKF1l5TfezizojD4X5ZuPG9B4gxtbctc5V3iW1bF+BGBckrA3bxuIypRd4wL182ZbLFw1Drrb3R6sz6XufaYkW/45ZtRe57qS+vo61bkhb6OcjCd7kOwxa2PRT3AxR/W2e2ocG5FWIyN1r7SbACi930AaVjZq81UeXGXsifv99/FxGHuSpyGeOc7Wo/Yl2BGQ3nOBPOCha9Hz/yJrQ5LyrQS+/jj+IEHa1LXNkABGAAAObpr595WCQmUr1MtiSoEizofTX4vay+R6GUUjVfL4p0QPZCHBoik+yMb2aWr0q2eFDN5+mZqABWlYRGS2Jciy9e3k8rVn/4AFhmCugwcf9qxPtv8LIw7afDoMoDRGihlcOj7YkKu0TlTaDjmQIrgk+mQB/21mxr8Z9EUpyZiv/u+AuHFrqEAi60xGmet2IWS+HXtoRXWo5E8IF6UoU/ygrE8ZVOfZ6I5TNXSSiayJFiMjICVhaIhgSa64+Iz6DIPa7Do78UtZBfowwErVnIdgjKYaTyPpWOHXc2Vuu9sbZ13O6IDVbxbai4ldpge630k07eupD79sHKE1xfapZ9CTOjuvxHjTRrTmkg/ZUc5drEcE7BrI6VSq9s+pf11TCFMDq2e7YYj1FTr024WIz3hpNW5BmqTlk8r23bmByA3DNDpRXSo5FLbpNMIbZIEU9u+k4PYBg5bYtGjh7gZDneMquOduZU0+lth4AJ2emSPOQYrXpUbq9N3+wHsbOOsB/1IhhoPvuJxQqGIXb40NlKC+JBywfQg10B9pfkKtQNUctMuT+IpVUmxj+Fr0UZ9OcPlmaJ32dpTSqOejsgWGRzBY8cPa3XvA9zwFYeYdFYI27Zfz6mVMQn9cqXvxTG/T/GjNmmf82/z+r8VvoFYuiduQOgUr32tWS+YD/YHj0fYNUHfJ5IGouHUqGPPPOoGNylOz6rD7ZZZkljE8fbuD8PEi2DdsYvDRoN5Hu6FJMFsr59DDOHOZKbKiH9/mUIcAjLsBH2E0FdoN9UgcOZpCPdCpjujR3oCaFMHOuCuxm4ZwyIXCotFPSFtfKG1Y8Un+sauRj6LlP5WfOHfgq+1aKtpE7QSe7ZvI0H5mnZR/AHYAYLZ3QNbHn7yhd12FWXG7TBSuueQvkMbb1bsvAYgfprdex7kGqmED1xLDfUUliGObalvsEmU0dEXiwTZPnKKBon8jQvp2GMAG63Nczy+ZUh66Phb4EVVG2QVWR7d/qXBXZF27DG4Er5rlMfWp6D9A6kLrFJDvKn6vplxq5Dauhh3EFIrrzNgXO+GVuJZRgvQhxNlF3pJftq6YCMXjhD+hw1RrfPoBoZNzwLyae69hFUIkD5TB4mPYJyf2wGlrZo5cK0GC5eLGn39jhgLAXomXvGwINU3fVf2tv8+b4ljRDrDDntLnADf25byXeupacwQJunUmhQLojOsBJ3AaFyakAM1G2+ee/kuZtmnBxx1+5PqA7J6nEP9pzJrNbbrBzODowUk+ghKc7WLW69wGXXyCHE0N5+KcAw0LY8DOxUHYLu71XbfYwIuqbuJFzd8GamzVq+A4Vi7gRhNDSc/5r/lA08Mz1H3snZag4ATURzSbLKzimkTeIWjiggVhCxnXZkkVA6l9tCAu7Cswx8QoLiNvEjCiJg186amfw0K6QSIclXIAXT0ftr9dR/e2UV1KN0qLdhuvknaJ+uXmeY8G0wRBBdmd+ndAV4EQat9ToMNEnaPoF3AcqxcZ/n9TSid4/bxQPagMcTeqTr2ZYg0TNjYw4OuVXDFS1ERr2ghGGryA7PPacKbq7xb4gKz2OtSV7w4np4dDw+LPqHnSd3vPVamDnnFzQ+20RQTsMb4AX5poiXncz/irbGx3c3Usdbfyq2H/5FfN3OFWzkyX5rkzB5ZyGaDbTeESohqQQOLe14YaPkqYTgHv0v/YjCnfPTDGKZ2Y95cYz2aslfb3Ddj9JFSpfVH8puT1pyYFfyLc5ABd8J5mWBrvLDWac9LWkpVMrOe/Tk+7+yfc+hJTycLFBQgCgayIt1Si4ujeAd6O1n40Oh/HJhCrxAqRFz3rj+y64BdgfFU2Dt0tz9zrgQ/l6dlwxovSosTTW0A+K8ld5lzye/attAvC3C050HRKlplKkFgi9Zh8UKOLxf7POegvKkQmuIPNlLI+dp9VOXJN6mDDbNoOktAmOxemBZRLw2WLdjgrrqspVRH3+kVS7TIIYNtrkPCyaJWHeRi3/jvNnvQ36DBKLjmsjFx/fk0w8UOV3X5EOiPfhqgaiKB3AJRg1tWW5l95GUV1k+My21OuaGe0KnWl8SFYXzHp/fMkxiTPf5+tk7WltMtvFty7Q/UK/CxeP0TStXDfE5Lz+X5h2qVoFerY1Pk78+4gAm+ULQX/SP1s7JEHC+sif5kim5lgApErGR23Pi7ljfIz3haYhbWp9J1IM4MfQ6Ix2EKAV5CTxRGXo0v+XZ+PdCN3xGCLCzLEg7f2VEg6q/oXGF+wTTSXrhP2HNA45VjjU7I0TquUovbP4lP4DKWiDN6RAoHOzatpFE9g7q7B3lul2gJPy8qyBNKHZpyrFzUV31m1iNiPjuvoDiaKpm9IOHjAqLrZ3RaRiz+iagWFbw/gzra0/x5YK71o9+wrxv+CCf73t8jjvQ92PsP0gD3L2KSSLUpTP45N5JJJwhUfOJPA68sgS4QwkwdcAlB3Z/cqSVm8j6Pg9EWoGWVvver9U4Kqiojm+TiiEibUbLqTy9jtYCNpo32QC2xG5tdTi3soE3jgWvFritBIw5dJo3ncFmTAstCkbiC7xtv47XKBhhwjKwPyIENhKcFLXhZkHimHYnVwLPPIuRrrsQC67s7uiHLe9ZkWpaBc5tsqg53LA5rYqFN/8pniHD7Dm40GZsnzVWgUcSHWxVQEQsW+TLM0+7d0ePBECaniGr+SYwy/RPKqWDb/x/W5z3bbmDY9BwfTP+YCW6EQBaLXELLANqBH6bfwPiwBFRKA7I0VtqiH9BOgb/p1bH/UAKAJjvxyzH2oxOp7r+nxuctV6NtX9P/wkKV9RzqC26Ga2sEKBr/221MX7cl07Ol9WswysrpWc6OYWFqIp1fxFT6VIgTWzvcGV92alAKm9G+0iioxAaNnVqSSFmoEZr9/tPhaiZmIB9OLtSGywsiLKjV+1gNXRLx+39TzP/JoTMZaNgVmfA46PfQVKXwDBXczCevgozaVsg7TqsyD5EnjJMHPpTq2arlVz4Ml83h2qtwT+xfWscN8NIokAre3fRMX0vnftn+VVRxKcaZwYqoVa7+sHufpEs5xaSyQsG/xWXt3b0MTLVndvjovAFsbVQYdrBiRFNbBkxKmy4Gaqk6An+8evE2yU9I8xwHkd9eBqqaAjtzLwMq0/RgvhWFIWe7SQpdaOFsrJ5TVZB95TlS0f55KFfAX3k6sqJIWYnWtolHTgT60hEAOcgcEeKtPHLNtiKFf0QXBYa+ZY3B1+w1+7UXqWOQVNeV84HxRB2vkQhwE7EUAu+DzJIUp6lGjuACT+7u00G1y5aZC3EB4eNq5lMkqjmQwl+8I9IdIPkeuvAwAdABZACOLirQfJD2BWxc5XdNQijx7U7U21NWDi86PzDhB5ZS+f15dGW1QMOl/f/fcRcy0r74QlLVhz+kZc8wiNa8LWzFZe6Ciuz7COvBcob19W7OoA2LLS94HLhhDb/GbbLf1ubwtX8ZFX2rVFk/U0VwpJRlWuUuQq9Otx3LDscAu/sqqPe3BrPQoU/1Adau9LS+inRcykN0pxF9K8PUgTyoNo578H5m0u2Af1pQ8D8S+lzSEscG7lph4VQRFzuz0RCaf2KS2Z5PrYFKQVdO9tjOqquU2xvcYbVvpr82cE1Swtn1aI5ve6y13+lcILBEci7Xi9n6NsyHfyccdp0i3m3mjWs19yazMMxsOt2XJQdad/4Lk2uV/YRKlpZ2qb2zdmpj5vsDekfwmInswAI2xVuExnPSzhpbV5ilIMkCZjSnruUdwe7v9g2E5N+2mE2Ml9OFPnnlj85TKGDhGrqROfI2xisH+7mRGvOZ1IbSXo/KKcHpNt/8YsYsyLvmG9dabeOrsvOsdUlr3Iz21e42/HFkkCdOLwFCySCmViZveIB+zR9JVs9hPfiK/chr3JbAVMbDO/uNxWOyDGgUpEKLc0J2DKB/7DON6IJMyZYwrwLjPlsa+cNynP8hjaLUsQXs3GSoTx/UKXMyBCw+0ujWmYD929wMEmiz6iM4YEYr/xC6CXq1AL4T1BeayHIPnvN3K1sTndv8XHEOkmAZkdVqgvr8hZCTLdTpIeHZCHRGxcxzc5RfJLoT7MmBRnjVKaaWFFHJQ6/bvTA0xTyjCVPoQNLjOJOmE6YdAxjsxAPYCDldG4Hklttd7D24fWoIv18UsbDwoAZ2Mnpsk/U8UePz5QIW/B3+NQo8UWOESBHMi5JR8vJ2JVAAAAA==",
	giant: "data:image/webp;base64,UklGRnxFAABXRUJQVlA4IHBFAADQoQCdASrIAMcAPk0ei0SioaEbvW90KATEthujXAaYZmbYp8gO+Nx5nDMc0Fmfovvl/ZuiG5d5H+2/uP7IFYfu39r/aP9290fWj055d/N/6I9q/+b/aH3K/oH9iPgB/XL9hvcb/qP2v9yv9+/2v5K/AT9qf2Z93n/p/t37mf7J/tP25+AL+k/63//+vL7En7xewT+5npvfu18I/9q/6/7n+1z///YA///to/wD/58Lv2s/4f8nPNn8c+a/t39o/Zv+1ftz8ZX9L37+kv+B6C/yT7W/hv7V+5H95/dn71/vn+n/LXzP+Dn9V+WnwBfjv8s/v/9h/dz+/fFj8v/r/8B3Jmyf5P/j/6H2BfW76F/nv75/lf+r/jf3Y+lz4j/V/mL7h/YD/b/2H91P8f9gH8p/n/+d/tv7n/4n///9j7n/1/gffXP9Z+0XwAfyr+p/7n/C/5z/3f6L6Y/5b/p/5j/V/t37Qfz/++f9L/G/6P9pfsF/lf9O/2397/0X/s/yf///+f3Wf9723ftp/8PdH/Yj/w/n+3a4waZV2svxysYqEfI/ZlaTFgQNC9L1PqvLGkX0C+iM+u+m1QiVtjwePJH/yQ+KGHmbPhNaZ9ckPle3qm7K00ZGY9w1n1OySelJ1gEG/DxuJAQ1eyOVPGgfOh2glRGe+E8lkTcyStQw8enY9/MmkKkDh8/faBCSjyXntNIC8YueijsgQ2ZvzH3+SG82fiBkINVP0K3fd3lWzDYAvU4a1bbmTMhHReLCmSGsFq3uo8W9SAzDV2tU7iiWGRdiknpuiIlgDGf06rGj/vvKwX6crIFPCFSn8wB76ZC1jNvY83X2CKZ3ZEGEouZhZH62I9HnLQD5WlwkOn+XeG5jkEgGIwnHqoEH8QoZS3ArxplcRiwhwGruS6Lhaxl80uCiagIk9tLoqk+yKaxf4ooozDllOcpObuKL7RBJ1M87+GVv7Z/8JkcRO6WXWeEPOKdb/Sh3uARsobLz9VYZ7Xf0LZszB5Fn+nDvPFQvMWgJFIUsII7L+8Rm67oRtgZkmuzwgDKKjgL2oegD2K62zlhVx0ULyOcR9CPLopE89nj/4mr7TBJxZLHSI/kXp+XQX07VsATj4nJb1oYn47Dr3cw6YW5XhuZNgtZlN5xu5zxs0q+Qq9fyKZ8geoO364+KTbF0aXshI16hX1BtnD8R1lnioWEYlDhcpNmxA+gsqhm6DHblhe+vU+RPdEzCZUIqqvyJODZaPW0KeGgFADQLzFFN1Hrlgq7d5WLrz4H5Y14qBZAE0ebSaxyQ6OrwQXU9hO8O4PvTv1JZar5QGdjxE19/8g9DyHqul7k3TOc3kFfa650Ev/sAU2kP5PsnXIxwC86TTTVlvZUKz1+wA1Bj2GyPeEwzg2AsGjj3sQ2ZtFevxWQJZi6hjJTnin9Gs+E+ygKC0e1qiBVCSrosF5/fKiZ3qqR6BOhVU+QujbaCVLKZTmBdSehupU+ja0DxmoSGs5aTwhl+jTRTs+ngM/nWPEYUjb9ymLKddemzaIDEl4pzqUlBLUSsbyf3f/B5msEPJWTsAuhItveK3YUWr8N1ElQBZN/YreijPvymZsgZcvUPJvygY6OFNW+qSr/Tv8PIoNyV32iyl5FjL3+OEucfqwGD7TNOq6j2GF5PvmI9XHzEDi0dSA/yUSdC33UUOcvfsT1mChVOibc3hbG6ip7udDTAQC877p6gBVec1H03F9GZdJwHz2XSY5oAAP79RKAAdmGwIncdLS+zi9QnkdNoA00LNNbBcok0EfhfbY8awptvypgSQ/rf4d33D19gap40N/PR2Y8Dg9BhYdGb/m7rJzHXqkmHYXjwjeYaxmCD+RN0lkvRl/avG8+IJl3D2+noc6iyxaoUHJlyL1mg6Pa7OGxxu+zLTUnTv3DTbmnvolblh+wleb9S6V2rSC1Pv89tYLA3rYkFEDqV4FstWAfVV5Ku8bpc0C70bIz+FBCMMTYUwh0Oarwc8pfR2bHMZINEF3gddWgfHyUk3pf1796ey/Pi+v1ipUDIQPRFdeHdTu4xqv4opuOwQjrPKIY+qO2/7cT4ecAxR3LMoh6zs5nA33tcVfHPdi2D7Cxhuf/VscKMTgkURcrX7ejX3Oe9zwvVK1R9leeuc9y+Mxs9ZzwkIMd6JL/RXX5RIhu6G9AFsKxzg96PeQ7zwmREx9xq/Q0gZv/XD8/zcUU/7qIVMq7ZbGR6g21mcZwKrijjBCxi3YIjxNnFLa6/DuYg1PqzuzB6UhEuO3kRoM+WdkZEBZWHIr+LjjZXrIOpoLNJOoZWj2RrhTFPQCN1YcDygy+UzjNeQQPJt9wtwypLH54cQ+tWpR8fddIIBIHB9R/xxkTLzbOlOd0sl2HL8N98qhAFrc0HeYcuGZubRi6e+ByY0TEVLQKc4Bqqu5Ho6p6NF98JNxD6R2Bz2OmGNeg1b/STxRf32Pcv3P3zYHEQW03CkqjCXqZgaiL1SclJxzrsYL+F95O8PBWSnYTi8SLfHd8Gi6A7DqdiYC26Qv9GbCqwafXLZR+lta1VY/qORUolpBQKgK7IiKultf0XFDaa4PbbEDJk9AJodARlbF3/OB2aEWB67xNhhLT8aRqQDoJcix5HysjmaEEvsC5fKZMbf8lBrFdzuV+2nTV7X/01XcnrW/zGOPs8TM7CDDBgJhtZ3uFXhW/mgSz+EhOqqKsoH3jqgJpwqaymLHVJ6/3bvhfR/pPPHvbSMiT7K/1GuytjWME0CdbQ4U5EA9IfR6cIC+umu+zjHgU8ly3brqTQVCuAatOyV/zkkAb/o+LWag3Uxc0tj5bpjUcTXOsu7v4cQsFiWpc8xF5tMhegOBSZAkT4CUgb++qkiwqUvSsb5eu/5X35lMlSGJPp38pcQh0EWxCBDEcFvNaG3YteCJqi2xiKuI/I/ZzCxrHJyNnJl28t0U5nI+Sr2V/JQmP6DjHrdH6OlazyazX1DgK4AS9VHrcq6g6/jjv2t6sQW2MAdGU6xjGlqZHdoOahK1DP3FU3y6ho6QM59P4Sh/YZfaERzpDfy8clMCcVNk0FyVDiSFi4ZZQdn/h1ppW9rItsTZb8ihd13mMvhJ7HnFPJLqRoz5Ne3nMad7uz3gTjJPLmsRx9rldweadBZJzO4w47ravnPjw7uwttp15cd0wZxUmg2C/w1PCRrFBYfILvC0MI2BCVfE7ow6wLJERwriVYGCAPostBIxiScGcBuCAvIqF/Wn1ezbOCq+uGskVoeKJt0vwwnS+c7FYFfvb+mR/ecAAB7Tb+iV6P4QD19us+xcPBvYfBTmgQQ/aUjRvwVEkcKRLQxQTfv1F3W7uJV8th1eUr3bJppYYr58rzszTeBZIMVid+ZB8C2yCqAUK+Nx4TcwqdTZ060yuq1WtFFCelNemsoNORXVPHr9cUa7BYLjmSkt4RbVKUo64wntEpLEHxRlYUqSJe3661Az1l/4fel8Ux9NG4pJb0nxcZnAmugPHynzB92j9ZjlwiOLsXVAAKrni2htg6TZ/6F8kx3+m/P47rZi8dDgMG+EftLuyEmV24mL/JPLdzBPuxJj5vlspcdylIidEav69nD4yG9mygAALiAbrQIDvHpWshTZnMfH9i8cQUA1ygigq2d75xDQ4munM7C+2cvGKGvfQ9hyLYZboBl49yKOTHASv/WZtKdt3ixtuNsmh5ydsOLHIGPxSgZrTJFrMAFgzAsqxfIcs9umgiL0W0qY5npcbBpxW1xm6+30obWlCMIvQUZ0tXGgPJGW5kU6dfDw5raSsEozl1Q4XqDNsXkZA/SAzTVyM2rYwx3Eli4SA642ABeH1oo4Su0HuTszSd/K1kvlbr677UGqR6b4/W3rQviVYU2Lumnk8bvDYMPMipX1kjOdVrrFM1oXu5IentXpx4BeLespPadNJuR33ebEhenofxkkcmSRdiDa2MalU8u6t1gr+V0OVJ9wKxrGGbZSUSeLf1mLI7zcxiuysG2NvTumn9IK/aybEhK2I12ZYaIK+IZr9ClU96XAsULzgMjtghuLeV1ybH12mLECkVygCH09NnpNvBN71daXM7BWHocacpKciKQsx2ZQAyhL4MODVBSJPW4rZIDGrnGWetegLxFT+SyiY3aF9E2+sUPcZb/TkNl3//WJiasqve57rTlEVtcfjkJb6PEPd/9mfLo5IK51WrCAtL0Sx6x+SAGMZcWna9VQu81ye/2D237oFPOnoSbeVAi8NxgShOyspGS1rCy8prE+ylYVu7o7epiabu3hjI6mof0rO8yQg7oi7M8QGBKH/Zeah/eCPmEFKZE6oltWHCpVJ/ZQEsL6g/3fC6qp5ZJwZ3HmP94TXISlNx0MbTLJgFMTFO+AfUxyL7gGvwFiVyl2CFdlYKIQOyEAL5S0If43lKrdWRxB3YWvCrprBaT/rGTV5uRP4/FIAUYMTZo/xsWWs3MmvgNh1sZTtt03aMS6crkFlhc6t2Qe55Fw9gE0/I5OfAuyn9pSkkVHZLMNmzUfxpLsf2/46t1752gX+DZKOinTFg2xVTZxnptNTAKhR7QCNSsEZitkj8B0hak+Jj5gqeRvigbC1VIX1HMvds+e96K2nbZ7Ysqw9tZY51gVAmbfAbn1xEV9rfIpUTnLQ+IyKCX8vA2ViTn3u/QwExDVyzGT+zYraBvLCSRjGK2LxnxLgX9cs4udQB1IAVZLb1tdjXBGUc+P+UmrDdDLKWSGA7eIIwt5VN6+7qUW1g5gl4rthBCF1BHi4NbdDNBDNr6fq/D7KacHLnHbMotuuw7OZiTdaV7+NO5j6Z4bD4W61JLtNEvbYFkqqiXteftOheP4L7IOLMbq5E9BAGV/LE2HcFNKUZhzeogQTlIOqRah0P+a1ApX8D5Xb0tI47+STi9fMw8aWorWdXg6DEP0WHDa6N+GaSU4YvlNo4ZIVMnt2t3es+cysVXZkRTBEP196DfFuMNMWYuHMzcTzjxlFXPYmn0MwUOWhQW0nWCRzP/efuqZ+ZdwQIgdWA1fGLO3MQloGdb90izK0aNiDdXjXqAd4VfIaZo0qj1dJibNgd/litJqsTB4H/9essLIgCERCDwbsJzrL4yEYRfWmdmT8uDqT5+IdtPDYi0iwlh9MJqMRwfStRwIoGZnIuH0EWkEYwUvwyKws5izTbbjVWmU9iAgc+Cs9YACa5YLVs7KkJTFtYEMUFG65a5fjuMzUl5v6SJ4blz29x9gT9IUfCB6nhczgCK0ui/roxBGI2uZGHB3mqpQ+jnkV9BxiunnPPaRRV4atHfrniIJ7cWKaZPGdJYZI5rCvJwLc+Bd6d6dATjo3X7Njq4rflDX+1VdBB3a/Wuavg9WsbuFa/Q9ZfN/Gar89KdM2aVZX7w626FRy/pm4K+YsjEr5ELFmD+DMdxs9aE9G/JDgpFe2R77sL3bopfFjIM2zMcv5FFh8+5Bu6slpXTfpCwMKhVs+rJXzdTpkMZSsKTg6R3jvYiscxKmLSq+2T0zgLAcWJwodrdRa59+c69X7CYgp3v4Mn0TcP09Ki2vJ0pUu++XgLj+gTYdoXKfcMYLjq4tfdI7Q67qUeS2LMWmX388GLIH+Jzltlz8Dn66rmuBKgXtJoWWYFs8cXxzM/hN770zSbT+F2M/APQ+RWv9tgoB1uW6HcMNnkgBJfpveUVXtmC5UR69XBdH927Ion0wdpSeMEBK8pDkHeUvYcJVx9mEOP1c4dX+Jr3vkabE4/hBwHHPo8/iwbBY1Egf7s4NytgPNO2Y0gfUTe/Me5fqBAInPlZ6WQrRoFqDJBXTpbBZdt9qKrbB7V5dTa2JUymW1Nii9/dAo4VjQKLMlaTSijvyRyldFhtHnMFVhqCNYsI3A5nPn8El24zj7BUeqGZurw+g25/QY40SuvyEk5JWL53XopomZmf64krfVi8WKZE2mztz13NHr52e5MnZVAlwmdPebQES9MIXdBtYw/PjgvtWR8CZMuqHmotWGpM6QxL7W3Ty3mgYNV8h97xSn+A81SbNQkDUdmPm0pzww+OrY1WXz3I5LY5POxpkvaX81AxBU23rcOx/CX/xFAW4A6XL+VBOf5LNtbEXuioHx1Q4e1/8i+kvDy58rWDgjNqB2NoKN6oE+T60fBfMAV+9biwZH333IYuAYKGpoksN6fG0CtwwSkGIfY3ZDDFSWrtqK9XJlD4ABYPK0QodcT7Go2UlsqcnZb3dlrLs1uIKeeokvkByFP/pA5Cr2MroB7BQuWWB/w0u/tuCkCXAO+sFPiU5me3GsKAE82mqKQ+ff6SQ9EBDyFSabdfaXvnKU6xTBoo1gEK+YqW10A9vvhru9AMUHNq4MTx3iZdAQr3oKWygxPbfa8NkdyrjppBA8Piv7KyT0jC1QQOgMqqgYWIXr2NgQjcsYC6SLMPcWOUW0TfKjV2u2HuyE6bhKy6HVY+7ClK4gE+VY13dEmvm8K7LgmYHkhUd/5/d7ppy+U/E++AuJwS3RUN39s0u9+1LK8CSXnwSngr9LIqiHHMDmC8+LzOAoeBzKA/5oLZXOO44m+eK4IAsCTOIhJDbi6b81o9m5qLM9RK3EJQV5mO5k8zsnmZ1Ruf5uFVDWqBix/JfyqdJ8fwCTbbYtPypm9rVOBq7AlDpttlvouksED+vYzEpbPL+43JiMjrbPLdCrLTTa+rzs52FHuxLDJV6CFDHn72aLxONqP7jw/SOVfkDVvjAEDnzdRi1717Evnf6vkjY7Je7nCyw2QG+145mC9s1kEE9jZ3Z4629k2+fbO6DfzKhtdZtyQno2JjCarp/pDYTzADnbI2rIyjneNlFPrZzDFxChjboga+5B27iJyrSfs7X4ULYcbPYboxHbsDlMEP6gVH1JXgJ0LChkJjqTm3w8k5NMdeAwe6JC/WIVIjj7g4veLvMZOT62MhhJasuz6GXvI52Phm/SRYN66jZWFvBxbcA9qCF+1amQKKQV7NGxKmYgEKIqul/6Cd9PwKLV5wQ5HPg7qxFoxf9aXeY8P/nPJUQVnckEy0B1VNxvwg11sk02K53JEUoKst4UdzEwhI/7EA5rgAP0QE5sL2tMoYUz7ohV5usUT69Wi+Afx8TaElqr+ftysvXu9LImTpg2P6rIBmw7POY+43b0YkQder2Y8626LKCo5jdKUyS8JsuvgLa272aPyv4N6WgrXOAd4IrleQhTLP9NxC4gps11l76lSMrqGR+2gokucO7GCfHV4T3nxAqDJ6RYvhUxDVoDvFz3zmeKZWlc/i+Km1Ari5tSq2K6JLpYAvUXfy+ZtkeZ3zMEpOU4cVu2LQRGMApJaulZKr/jteOzQe5C87BWfqnyjyNhZXo2zB4ECtzuqjRgP73F0nZCB8WLFOUdL0sDAH/lX6Etb2M+pcOBZ8JUfN58jOXtySMF8X71cx/v7HZE6I7s8erzPL9tGmTzx4AWfaZP/4WLXkz19XvWmVxgHxUIt6mDPEPndeRN+c6gcMSrgbULUXXO/sgwAFlyG35/0oJ0HQS/YbIVktsf7fXCLu1amAo4FOZZVyXEBpl/ae2hyJNwq8wXnD3P9ywQ303sktt6Elf3zpd0s/qAKUzKhEuO8qam5UTT/QRlYcg681oQ4fV2Xqzrr/xvnp0nRVU7d9ev9BLyE9deFe829YhWcGP72XxEkgOr2qVCgqKc4mH7HHSjapk8x7dhASkArPsi0QOI59TGAH1DpY33fQ6nDn5vMAzxvCM1ixvo8EyJ/yMiiuK8D8WjUp6iQrfaC32y0YBeY4UmVlTaSkJRy7HXn+MHVk6wodavFRf32vMun9SbiD94o9CA5SVpjJ85QEdst7iGsASZnNgwbZj50nPzG2KQmtsyg76wpNCu4+vXvAPjM/RzkhOU/FUQ6YpO7GpMLHxFrq23rJufajqPn8lg6Ako+Sa6/cgIlao6CMkkvSOrv2mrXekpoQiv7N9bpHtAtzozB2vU3x34k0DiFVk8O3ypcz2GzVfGtqr/lHkpfI89gTa6PSlV8uVOYc+VKmQeciE6Ki6grGsYT7bq6PWLePVPHeRwijMki1B+iWfn+yfQfP5J/sbk5j4nadjjjmeazfiV5YygA/dFovJiQT0KNYBr/OLKkXUjWiBiHeb++3esmXt2cjdmr9+K0L6mZatTi3rvmJnftSoa6nuRW8hfkbDc6pxqDtXNJ1Xc9hpGiGqhVb4ln3Sd4+1EWdRIZ2k6d8UOIgLBoSzKMwmiR+xRxrjCwsUwP5fczNY7HqyQlF0S8+mn5qGYpd2TCwiVKyrgWp9y0IiovbbAAA27S4TrVrB58SVLGAzdYgWiTPzCDZlBor+rZxHGQOIjueT1bO2OmtcMZP++x9E8Y1pesV4zPFcvoc6hKAWaRWNmupynu8zDt/pkWMqpAK/cWwT4tTiuzZRXURc615OaCut1oABXTckgB0VCd1cp3XJZ6O18LqlK/opyMkq/3PUq8sE3zSIZGrczLp9dxgo+xSqwbJWsx8Mpq2EAlwdBBsxAG18Jm8SGP1dcDrS8Q25+SUgVmDe7IeYTkurNRxYmomkZBBUQCgl/g6Rktqbfn7jj4zNrfYvH/mIKvufnvtn99lbXLyqWFdoil+lyctCMoq2mzUh8hos6c/syO39Y39RkHJ3MzvdbbmysA1d85ryADGKARtdP1t9z0xkVG3VkJbWslBD/08CFbK59nUioITuKjW8tFA4Q9SuwemUZ2gIkOHsgUoquzWdPUS2VfG1vIEC+j5CkVnqUGd/+lLZJXJAO9cLCVCMmn7woUExdvXvwoWZY7W0xA97I8XjoTZ19/DfAEn0sHjWGBh5TdTKtdwS/5kJzzVlzHrRT6GSCdzVY1zejeqM7v2m4MTvUKt8wyGBEsA0h+3Vf8O06/1e4WcDazzaK1CGcS3kYFFQEjjVrPgyJZU0fWsxx5YftKlw7ViDZMgKg+HAgY/41MnbwdHMYJie4ZJz/bOBoX6CXL7wRJ/Rsyatzjmz4mHOwXWX6bUsJwcAucPXRuyK6ZYjLVvIc0i2cdl3HuASRhjOeRjAqwFMzpu1jVa9S0PkshNv3ah5eHtoN+M26PCCiUqGCS6ceFvxf7dfUTI0373AIDIs34sLsfCQgdADD5IONSulyFKuCc4EEq0cihj1kDxXgJWK7b9iLK8VfXHhaUzbN5taqPzF6SLrZBXz1p/y9wtyI8HCuu/2n/z/ORCqbVPHd2W3EElWv4Jn5PYWgQZU12im9LNwinK2o+AgQwx4oE9Q6vMfgQOZnn69TgGmB3ZIrLRwJojLxboLOAqtZao+OlVe1g03+3McynyfYizN0swejlg+aPCmZTlMmi8oQYwRcSODzMUyZ5+T3XjebwDv1yAIInuiXFHiQUQDWFmNTA+AB0TqwXcBkKuSgG17De9VwHFroqHZ6jzN0oLjSiXOPOmZGNMAe1r5jJ4iSYHiuJ9wn4qwO/RB5A5YbGl+k/VYUlZcvcm8Sf8arCfOK1GTsA3RYYbK17PNjaAFxGJM8z9TdHG6Cx7iG6DHLdlh0lAnoQwuxBl2w9ArKjlLEjuv2RMZGIbTpaydQs4h702Vrnd00rgs4s8iVZsc2svzkwzivSMs5bSDhG9g/Pd3f9QWtlJi7xRzU0swcUQ7TPChzJPPfx+akzMp+WwUVaB14IEwoppwnBvci7xrnJ42uTZzoMGIEAXMgBqAGG4LKts0wI1F3DzHm5A6/Ycqgr3dKZ+HW5XN0y15ajG+7LkSwXDuS6hNK6yo3Fl5LkdAbTXk0oQwI0pnPPQ0VbtrGbPiKNF8bi3W2oY7OVI/4aSwVutQ5wWLS9NBtwviLJCXMlIC1P8HS1rWokEN53WukaFaotgF8wFULZ9n7UD3GkcJnCCdpuAtrPumgYG2M9yH5WQm5kMb9JNfn53CBEamskKgPZcRLS3LhpZ3x1B/mxSoXxr+D2rB4TayOEOH3tzxbFJ+jziuHSVqqt4mc5s5I75LeyU+DaTP9du1b/ozUsh3FCvhBGJ3lijSv+vy6pKAfXzyFjUE+EHvNHQjtH+pLVo/r/1D1o6tRlFSnen1n3farseQT1yxu+c1TnMoR7UGWWl2vhsG3mcYULRwoEqN7cryUxi7mb5xGac7Zq65Ju2yJfSr54AL9SqYL7SzvCK7Gc3XFRLo/jjI18p9sUB7PEoKlhnGwwq5upcdTdANjGluq7SBvrXkpUz+7PjUIArkQFEUIlh+jXGmT55EkgAO8tVI4J9dOwfWMlfuIh1VYk57nyDika2ZOx8mQz4Sck68pDu55YzoYdtwNZurAvYqauU4P6fZqJ+MFRoeWxK8+2S7g/8u5SbH9mLQBB3JFvN05T7fWIfPB/DZC6b2wk2LNs8MalwGwHGWSmlsXI6rg/nKErwVRNf0GnoecWkcr7Hy3TpQGo78SqIN2N/Kdk6WOs9Mv/wHCIoE0IeUzL4fa5bEFX7nzM3l3RLHa9kr7LIrbeqd/VIiNHA5YmRXyz2NCeADACrfQ3qSu5mNTXi6mBJtwG1Qm1ROWbzTR0VXB4VGLTzV6MXb8npggmlhJQB/6Mw0kURDCbvuWAlc3XOoKaBx5uOu5kdCtJZURrvnm23rAnC/qBluRQEwsPoghcMLBGih/zepRacm93rttBUEfQCcK0q3Rdgof89t5rDHelY5URFPhXZ2ahKbQ0vmZ6nXcVM4+fgMupBLjI9CgO4EOrT7dMGWjqtRnrgn2k4JQIvfeeieSTP0kcghdqRpSTjSU9feHgEoTV3xjydvaFdn1lt2NOg8AaE1IgHQcWG2o+3O9D0TL7YjojlCxkMiZB2FPlo+x9XwxuuEuYXF15ghX6pDgr39pypBlGGMElpO0gcE2bI4Biv0y14pfLbnniyacgd6xEBuNWS1dSUmJHiWEU6rBYOdQFR3lUQ4pUTps0jcPcIZRBCnfbII9l7OwzO+a+N/Lv5d2I56zhHFbKK6DpXtUYlHYJcD06BoPR8EIBuCJG1Lmt4nQGCyIuNVeJTZdJo+GF5OZwDToXVGGpxKrFmz00i6fPOzmxOQytWzY62JVwrkYELJ49MkxNwac87EYRwA5D7mLr7L/hD6BJghzUnFL8LfVJ91Q1F5t5MW5x/aV81mVyD3Lra082X/1JRKs03TWC5hvq0NIQUWTpCm90cw7uHO8RmVhFxSe5MoKuF3Woq2NaJWNhRPDnGx8p6Zq8cXxafHaW2B0FSJ/xNjy/CtfIVFKtgOyg8WWuRUyFGvXHvWb+OKU1/ny4fiZTDIyhe7UvMiyvPV6Fjd851jc4JMyqwpltJzqTBp82wb3tVWh6A/8h1E6tl4riJD5YiFifTEL5Jetrjh1FV/sfAx7yggFVylSMwZ/GkY82OEbaoY9GgNxn5Bh2KMUwH8k5poJ4X2oZmcFobC778ez47xTrUiRcMRAOS52R896IAPP/O4FkjoU54rik9p56HpUYK2wVJPwsWVygzWOVS40pYyb3IwMjJDlLsltHWjxEeKnhWxQOex/TDtXc5UEu2mpOFucyYi3E/QYEdyesaohiA61PPywY6XBnAFAzVBHLxvPDcukS7hpwuw70VWpsVSDJZY1d7e17DKg81mGYWgS1Hwe7nrqRzw50i7siCUkRsJNbu7A+Bdgyi0Dr8vlpG1ySUhOYntDgIV7bYQhyqyopOfDN68XezX9z2ANKxlSe7yAn19z2FWWHw2EW7Hux/XuwLb4uGTjzzoghnPm6BrnAkIwkwvDMf4H3uCMBo6RJXqcQMIzKYk5gEcfK5GKledaw/h100a94s3NnFagvkO+Fz/y+Hj/JzCxcirC9My0n82t9mkALzTEFYuyBbTTSUexuXSSzDErN7zHynj6IEcqxma3Suc1Qvtf6AzTdBJUYSDBaB8IkeWBTo6++6KZVlbp3AwtBfIh/9wk8U5npEb5uIR1+kHYHnFvzlVQeEbgjmWXO2EfRBdOH367kQkXy8KwnSq8pPmSTAncizjgCDf9N5ZnZaZ/3YBGxtRRl/4/ceR3kDim6SX3a8GkgH5v4socUVC2ar3l8jvDNOEih/IupcMOX+D4nNr7ke8dqs+hNiVhRy1kYqnKA7SSo4vLNmTg+Q4HnhEmRmvgXYPpABeBzHQzmRfbY+Yr7nJ+03sVeU5W9hOknXR62auAJYdHRL3ZSFwZxVHhdYBJqMFRgu4sLDv6HqBCJ8eqglKv7MxSoiU05J6cLUcW6h3sVdvKwKl1FNMlIPahHHrJDdt5atAhZqW/PrSZe+50O0H6R9FDBP92eOu0I+Ql96uTWSpFVcplA6470KC8k2hN8EOryIgOlZjzZ7IaLH/1KPYf+3d5S6UXTkAflz6VB4yzv6AmkwflELJJl9WJva9f+iFL+U4q9XzjxKXx/qrhqtpoHjCloXXJCUyzDAtZ3Uud0Xj/L2D0L4CaHdekl8W1wI7lkHnfwuvC1Wz6xMmbp6cZdaoVn0DN16kKDb5F5FmaqbgQi7t+gAxeDilLlL240YSV9csE8sPV3DVUwPBdJVePuXabPmuzwN4SAmtbedb8uQVIhgEtHqNL7v/JCNCrNQ8l4/cqGAAwh15Zma17J0R6xa1Oh5C2wpqgJY/0kJTvgnbS8mknpAMZRzEuom0IVjfUNYl46kV/Hsuc5kCnGVOHeUK/X6jOHODyec1J5QQUkpYd4wAGWqWMp7nPwpJY1HRYUjVhDrYs9deiYqooYzE3749XtDvWRlxLMrwIX3ikqPX2PpZ6r2b9hlGsYksciRhzwQzZbQqT9X1qCYpSrosJ64Q+TI7M7EdNXqu82ysXQlfUfaD75YV8yca1VCa4qaS7PjFN0ud0cvXz0Kd6jKgklog6p2Gv1yqSJx8c21WHn3JUHPjbPVaTixWapjwWb9Efpto9GKK4Ur+j8wRIR1V90nt0CyTI1mQKXl2XDnzqr6FsZ9wmUQfB6SWbXugKO+3lEuh/yiFG00jdmegVvhcrq+PVtAB1jTT8N2khnJDh4rURijlIxmOiHmQumbsG5dFuxCtFkkGjRUtt8fV9GnbKNhjoFGRz6D7H2bMtxR2T5ZYP+mL/UHXWvqA1uGMirAeer+A5OvibIgYrjHPS8Qy4CqB3LAChRCPpe2EYsatYGVHk6J7DoahA7WEs+FBn29+wC52TMiSl2herTK3gLwe9SH4XfjwciuXglpomEStI8kcHKnrv/gLSTviiDV24DZzL7U711eA5a1LTcY9TZIaBenC6f78pbJJA3lJIrkw/WGpSfIfifm94MKWxU6WcfhlrNzLjAoxeHM1axafzvChsf/09yFKXM/bXWVb02hNq8FIOiYdsOk/pUtXGd3nZDD4pA3QrjfGfMYbt1X0uDOuJmE06qMZxiAS6UD0MAmf1S8B0bzLBYmogstComEnotlqTACByH2R8VpcMp/4o6Jts1HVqm06l7RTR2Pdwv8K4orbHrqdi/sFQnWdhGIMPuzTWHgcs3fAIeN6vyhKCssIzG9Upu9guqhM5YGC6MYWhytElTDVAUVhmKAEK/eHRZ42/yfFK6CBa6KaSQ2wa11UPkBDz2ijhpsKo7npDteBrrMSTGTRiSA74GBuT8m9RMzMs4sLxhBQ5XC1/D9kIHKjw8nL08rOd6HVnpJG7+4QfN+ePmI6TY31z2eeb2rPhMOZphH9j1JHO/onLUo2dLQ244iC88Eq6VOkixv0lfBVXy9FjDaN1cRhZHG198RZ7/DzSV9yUG293qe1kpzdNfjzow8kXIQoVlLLqk4H4XeVEJuYZKik/nD7S0A72cFlC8vMlNL5+YNAEKx0UhrBgYX5TctjMPoK7lv7BdwRT558fhzuENirUdjBiCXuB9iZubvFxWcupqAvaU4SgCVinZLsRtfOOIeG6gPbdkflRxdB/eHkZmGt7LhN/Jn1b7V+kOPWUZzUwfCRVbIIM79FH2nyZAdsU5CaLrpNi/O4SRn4SeIBhULHclU2FcF1Jce6yk5jm5QL38NGc9dTcZbFMaG4zPGM01FbYQtjNYEu/xpnNnLlbMC5cj39fNHowRIkRP6MXhXY0GguzME8AHBmXzaLEJfe71Jgd02BeXNYkVilHy0YnK0wT+e6uDRxIbwwRXp3ArjMr81YLAqGV+i7/lyntmZKxKhAmW/cdlm8MOYgbxJqqJtwOkrc/nokIHUC7WnbZjrWzeWhQ6+PQUh1tb3p3tf2kD6eEL5t7kVD+ev1n2hOaKC5cU476/CtnP6lqlfKWcFIsmOhyRobgvQsC2nkQpxUKM/wqvKmRQA4FNIiJdsld9luMq6AnkdPIbFQ4YTZsZ3tPDILEqIkJZoWP8WNe4vXx83AK5O6KbMBtQGHHfZ7UdIfVOw7l05/2Ma3KjQ8vb0ZArvQE0dJPyJyJtkj8OcGgtaVzf6aeJvy47eXr2bbea0mUU8Syq6XONu7ukHyaWIggFDbvBTaTjrj3EiEIl2f4YPcK45vV8PmBYsH4kJUxr/7vkWF7Pq5VRjpOiGD2en9Yw9TYVzEF1BEAxLmL7eU+YnQdEHTmwp9IpL5tLSl78ZyB1tW0rEmHt7PolA63gtnX4MWASxvWHxjR920iRD63r5QBChPHYGcDfoc0egCm6hiUjTu9kfMi1fTYk83SWVXVrqt7vEvonCbSOrl//NEwk0oSJ3hxJ/QXgvgykkRTzX2vCAOzaB8hINaU+8bS2aIGA5GBJUsJUZcSmWL3OLTlSO5qQ0j6+aP6772cslExR+en6BF2Kk0Xu/pygGxRT05tGncgS0pkqz1mKfaUiUEuGTg7Ut2Xca/50w+MC2Py+S9oOhZp3J/EFIvFw+1XfSs09DKaIbZ7H01q2cGnqWwqXeVGyfQSDyLmBPgkWLQV8KoTk/YjW2JEdje6ztJlsdY7eCkcu0vRLDXSwgt1G9+l1uYsfG+LMpXWplRbURuZI+mBxQkYNTTwy9TahyC3DwU4sBc0T+Y+gpesO0GP2Ire8HB1+ALvjaBy9LeAe4yzhxM+5nHvJjK/n5VQpgWX3lpJM1VX9JlWwKF3bVn/IoY7Wc/kbPMrfzbzZdpE1kP4omadIfJ4enHFEQOygFH3h1Rqc7ZhAJULbHCYAwxQwrefCmnY9m8AhxRdVtRn0OY3GS7JPV1RhT3C6ACKsexd2DLM36JX5W/ZI4EtIidAPYS35M5wkoK/wz4ZCInLX42WJGdWxpVPXvHsdrq/N0YDw8PHOEd13iufNz9URnpxk1F4HiuxrE3uH5FjBb1Na6RHwHZa2qljtdbboej/CG8C95EJAxLpws3MFF191OtxlJL5x2Y04h4pvrq36tVhnzlMYCUFaVXJauwnHlw8nzJcQaNPCYSqS6GIxQHCPPWGFdTt23bSez2OORT1TdALVpO+zLMXXc+eU5Ac7NmnSHooneQDTwwMR+vZcXKkYb3gL8jTotR8eNeRNXsLeQsAQMB+SwLAczyiPvH3j9v9wq9nx1RDPcnNIhkkkg3mSUKR160V/jxN96e7hI2SX03QfVmIVg0b4Le7FBPj9eK6sk8Bd7zcrahpdnd7eVTIVfgvrQTl90i8rZWgnImIduR0t+mK9d555Kp3kc1+OhKP8UDhnRCkE00wieEP1a63ewxTNo+nbcCuGjvy1kfy/gEI1D3ETHr++uFvcB3iwZgDZCE93tbnW/f5dQkH6L5Ns2iMc/JgKsHeEA3GEnXgyklfnlDs2tKzIE3bdICNp0Z7SglaZtP3zrjDIhITpuusb3ovZeFIrAlfw9q7Q0Ke+IZcYEsJYpnpEkCaUBiOhtKCVOB9FjBRPEO/kLVDD4mvNcGj6gdXPVk7y4av5orEn/aTORkUljL+VjE4aHjuWoyOesr+++f9q2/n/Gv7jPn6gaNGyzJ292LMMLn5lUms6fQHm3+wgl28dZagQR85CRL/iRgEZdbjy+h9bAqJxkAaSVvwlBV+n/VmaECObyu0z5VQ7Yri/iwYnbFKzqu9WibTIW+H6H1GBOiTNgaeTh6N1m3igWNil2OcXKCsa+8wl/5MvYZ+au1o4KNMIAdQrWrOYAaI4CSNFNXwnkFHjdxGJmjsy0qYI8KYFoYYPF7evxK9lopfB5VLFA7oC0YvnvLhmA27M1xtaTf8FwJdLr/C/Ey68Jwpzf6dQG5rxnzrRkSUgFoVjdNSNIHwf090J+UyeTn5XJZLsSbc+nfz1qk6gM053EvAkUaVTtLXLna+YkjF8/ZFnAk3TekeFv+BdxEJ0gvv9ZWfMZNaNAwuqly6miPV5gzgfXddi1JUexiBr+Yv0iSkDDwZbK0oQLeottFQOC5wFtpOOX6JpFYtLUDKiyuEaPO+IWkii+D4bKSFl/xcq0fdCPoiQ4/snpV/uj+0aFU5Zmk+9zK5ISn4sslsoLhW3pAfpMsjvCChJjaUWzQ5PyfYl5PDvvbM2Gb2Iek6LMg1HSx12RuMEv+WRoFZOdA8w6wd3Xy8HaXy4XyEUX+GTdqRZN+k8ezNzvx8BpA4K+z7lDfJmjeMQkmo87Mmp5el/d/Bd/X2S5c6TFMre2mmaxVe+qPGeoIarxU3ayn+eDpKVja8ok4O6JxMlnS7i0aGDMU4Xus/y2aBebp83MPaPki/rl6adu6WPg7g/wHimboRIladc9VriufSiunPXwryaPC2LFA4/myzr+qxT30visvjLWlyuf8OKyCJo4WWZn21B7mBszl0nSHRcRmecKs7RSKDLisWTUZwklTmgOTbKvkdL9509+nLQ9Q+2EoyCt0C8fR8+h21uJPWvfwvm4rMGy2nx7oav5LfpmromKCVH5s/66UXVujGfe5ghyvfJctNJHt12nu2nJTMMzNdBIwNiYCneY0eUVEXHNSPqG2UaJqTbXdmoT66pgzuAg0uVXtPEb2HA2DrzrVhC2KFRE2dVCgaV2t2pSlesACHixz3na1DnM06sM9rRM8wZb3L6Dx/1EZRzMupeeNsTliYIgm48jUbYMXFwn8K5XUK1UvFHdKZimcdIoAqx7IL0UB6iFqQmI1lw/q+56ExoaM4t46yuotX7HsbG4hS8LVT/cju8JcboiOzceMjxYn2TeJ/WcZMtpdo7vH3e05I9dxZhBqIzzdSlU7vNBoKJlck5Gk61GjbjZqmWU1YfE9+59Vd86knRU/3p8pUeWAEv8FpgxcdOjfegjeVPyw47S+ssJ4bx9ib6S9tF29nViAWj31bj0itIBcYEp1I5FGyTooD7zF4lMh/TTeeaV46D1ZLHMDgu4lGYK75JB2uAdwZhvAVIY5Zf2DH1PJugGfVS+glfv8T67oguWGT5YxNXb7RnvbEPT71yXn98Yp/380L0Ic/LHNIbeOV9HDXrOPSIw4TvNpWhnHNWTLfPkAJwtpXJqPHM3btfor0SZPKaX51iKLXfYIx4H6Axp1ByT9TX69mE6CynM1pndtDBwu2svIqaT2GFuYUWUdA9gJEv54uPhMUfE/Gpg94E7QP5OtZ0M/1wWYwRmmRwvoYWfkmd1PuS0MPnbspH1CmIJbtOg210nvinJsElfuZ1VdEqHzR3Fg/Lr+L+AcJsZnIZ+4m/Xqj6EevP6fKgFJRQDqFbG2DFsLhGHYkqgN1NGvTdAc8qKGxGUcJNORhjmGaP8w447CXChjRnXjrbnXj1o1vef/mmAltYJXAlWJjj5t11ZLoLBMlpbuxa0la+QL2WCpmN8zkALdR5Ymacgt43Tzm5hxd4a1zJFrnns/f9ZLfkQ2Z4ROJGLPdWRXFz+F9Wgc376RDs5neao849TUcmQREW5QtMitrvfl83wzQTobM+pjeJuZheMZGdV2ImwePgvjys90SA0+bEOKWSATKUT2BKixkqDRLxAFNKG4RN31AXl9aQW/YwHDoCfX7DVt+wSo9a9qOsHhOnlHWJUlYzEDQ2ebddIj5s//bUuYF4th1OAnq/BBbIIwd1+36IusI6nB6KYhDNrxaQbYwBQ3U1xqCsI2N/WFtFTmQQ3SypyBGMdnD0q8yJReERMcmXoRIBhPnvpUeW+ef7LBjd+LJPyHsgpnQB5W/T5XTA/gmq9038pp+BRiiU1HmqkY4c8TqU5i9wyFk3UK5V3ndNnedh57wBO1vt734C8MnzEZ5hEV3NBiQVu/nDtaeogmA/hM+oXhJ521SIZegpI610rz9z4KE7IzGvWcfgWpDiSan1LxYQ6qBJ45FkmjyuJyj3msdwgAEVToiOvTrqcscsnyehZ2wKnM96AZBwQIsp/iU2khQDNYaddCsaJHPDge6hqN1CB6nQD8mIxnDQmQcOaWdQW4G10XKCk5yFHNqBTRDRGAgNywtrIqSU6omcuo3sSKwUFKC5DzQaewrMEkUbqDW4e4O1AXEcRSPxsT/2dJURGItWteNxdyBhV2iHxdYWTsHti9P4Igux3DrVMxEvYvUK4Tx8L/HZ9SVxPVsoasn5JEaEGxTKys4Pot1sIF4bj6tMBFN8ml5Z6yPUqsY5hwM0mKJkfWmzCTGdgnbvoJaW5XqJCB50qHdGYbLkSOZxmKwDHh20lJyWmkXzRGfoTd1P6pQN8wk5SwtkK7qt3D7oszNq74CJd0MVYpVMkgTKsdlOjkDgxb3o8MrXKhQFSVZpT7/gWBb553fAb57kVnR/MJje00PTId2KqiVO5RgG5SpStEbkeCcauZ4RFFepEglp46rxE95AxPNZJuwFrydADa4jXDf9O5y5k6u/OhZZp16zzNSSx2MsefrX4OQYT8Emz5Nfud+pCs5fw0Qgx51ylL33ePBISJU9WaLBdry1g/mt3MtBvClCGdIh+FtZVWht4w+B0W6JpPsT/+RkMMhPfFULouODXE7A6e/xoADOWvvMvZF4bUOPnPp6uK13eyUsyJCMQyzFcdDAIbTrfCbMEscZHIPF2/PiDElMmIpTFQdfAXzXJh/9u4nvAmL5HKqagYQpZ+1rR3t6CCijLbaJt9gMTXbITWAG5TMVb5XErUSAMfCnXC8IUy28OkH/Ez5rnszWpBhmsDYWL2mgdX6R3l0J5qe+MMeKpebYZrz1jCsW5ik3ysEKldYfVbd1PivOOhyB8W5gNvBaUGdgvoXV3ndJhehRQE00LqcqthS6MF2yeSkVc44F5iw8fGfo14v0oloHGR9NKMiTLGNjty9+eFhLWU3J4vAa/c3u2U96WhDzt8kiGUSWZroOPjlpaTU3Guz/5Rbn+YMVVfc+8VikIjTbi4nZyNnuw5R/nAWG38msqKjyZ0G/GMJZd9HfxfCvaLv/BW1cixM64HXMIvShPA2Kjvj967ns3TXnIfMCF+2Nz/fDGwvLeSWLLEwOUAsl0g5tvVdqto5dNyxUKyY3bEpltN1dmEZMVcmo9guX+FcG5bf4R7F25AvBjoTYs/C6297P7l5Q+MGAXUdjfWtsH2p43kErhpFxbmZu35ikTuMwsKNzGBcWo3RuB4uWOSLK9wRI8BP/G1+9gAgIjo3iRH8bFvsuf9ow7AJJJp51/iNmsPRFuZ7jpSLoT6h6GZomV6RK7x1wDkKhcQy9Y1Id/m2FaH2q78Z6LmugPQcp3yOivhMzf0bcmy6gH4L5PT3tn553wjCjDzznABTKIePhreJV2Q5hM+8+pUadYNvavnTcxedR1SSk0e8EmrLa2lY6V16Bqzl91KCJBA/a4l6LDXFCZieTwpiLOa4XGQkHVgDMyZTUWLL285eSr5XywdSp04FiR/bev3pa8qw+v6NpRPt1VCaIQ2hfi5r6VnKa93nrZ5MXpdNTAliXViE3HEb6wkxJ5JaeymrEtQQURVGWal67pm2S5L9wLqiGx69PMoVtsXpf9Whhqc8Uc7ZXLL42wJ9vUjRhOxAlb2fQgnRf9n/aeF3t3koKQCvs/Zm3n5VzRuQlnnKCFKkovn1JsIojUz30ngO2XDgfLzV1mKjFVO5t3BP2+p9FobjM6uq+Byodhs1C5JZZJQStSVTDpUaXiDok3qadBD7Ki6E8pQ5SoQmlsIMG1yjq1uMBFXv+RLTlhTnUiZiu7Te1IfGiwBjvCng5RDlzB13n7IXL6bmlzx9+27vk81Y+ehIfsPaSeuCmlGWQwqhzDYH31tb1P2T0Kg4CYDnjwjStBbq0A8mW7w3IYJmbTcVqdH7mzfwzYrInqJ+b0ZzHkGA6jJXkIzC/0Rvb8NTOae85lGsxjSTGl/Os+2u74mdj0y4X8hDIUSLzBQxrDjJ/eSNm6S673SE5jAL5djV21tJhKwtabTjdIWlGYlPERjsf6aI73eEJD9qCEZ5NTv65bXJwNIkGJLAgAzEFcGjjLIjMqrnfQ0SQ9gMFLBTQ1hskfIx3RkCAXbUBZz5u1uneO4+H4CkRti34RtK1YO7oaINvGkeVCZj5a8ErL9MphvuuXkP3x9sQ2dgaoqdOIw/EWsmuEwbb+SjWYlHekCfgBgcOvcsDo7uBv20PoPN7LB2Fjd74GmuCfxFKzyVkfH2wSIyZrZqlwooMoDxM5Na56cNd1/URi+5EeP5fWDLKVRSANEX2ABkJHE8Q7Ca/oOiTER6YXx3Wh13/niJwugACdfw+BCMzrKcfU1zsDNow/oKVW2RBA106Gys5s4nKqfwhsZJblGf73aS0si1GgdZzRthGAlD84NpDzYUZuFaSpf/wxU5o9j4L/GE9501+JiLoIByTf48maKjGGyDnucI2QgaIg9yweUHW+P+RNVmaGfwDKwJZWJ3eA1OdAVkNClRfz4HIm7WNrCOC59/XKkVK7fGRY8IPPN8WZXs1rK/wC3ibzZ37o4aqAByaRDSEBTRNns5fgpZlApQV3o8r5l1ZrZ/lMaejj3v8B5RB+n+QfMzs9O1FyKdkB1SRZ3ZlN1fvY6bsEBYlLmxCba2/+PPo3QZPb/kr9Fc7RVZPlc8bVBJCR/j6rWHHKYyj3majpinYOk35PGKqzqEGo3B00zVykR9Vr045uVX7Gg30j2OGI/RJOpslWRCThYmnQ/NR7/ZHTNReZFI91DI9YAaYHNn5RY9uOGoX0e1fSHUjwxjDSaGsf9UVmPEgl089aZJ+w6zxjqAMofYLdgf0cyNeYtFQTsSozl03xmjZvkYAMl+HR1MdXzUicG+cHEmIX4aCMx480LBp5Eg1gxKwyu8uSiAd1KJKLqfPIUL+3BkLTVVtdYkko31n4sfrjMzd5hfzr1fdGMbkUj8+jFQ8q46x13X3PSvWR2r4t/DSRj4xW9bqMURkFkZHEplap1zqCZOe67pdtiUjyCEzPbxI/EJbQ9KBg9lNdYVoX4yAtwZwPKDiaTZLyLzo88zQ/oKISkoIvI03SvDaX4Tc7S3kBd1BMmBkoJtd7mds3RlFCF5QFoiGtyD8eZ0dy0lw2oUYpsS88cPSHRK/GQGZ0R8flDSVPms0mSM08FmCq7ufIYxDkDpVJOkx//h7FFwdqIRLTkqVjPYl8iNm9iYHISNdCc/mwEwGKCWohDC1HrGoKp22Fj9uGyTi9Mq08j/iTmFI6+8ejYekR9rJ+7v7Q8L/pdh26L9mRqzMiXd3yk5eg8j0NWpsg6YMFvPs+SaT5czv26Li8JgydZc3smkpIKiyjdUCXXzboTg3BqxIMiC6nQo5drPzic1MF1X5kgt6Ksqi2wM2Lwo7fhSsRBznfCdHyFbkRpAJMUPQfwCbAYAyhwpAxfqBUUicbkyBOUUCGpySu5f8EwZ7qS86EbXXeJWcR3pBA5dru6QEV7ouS1A2pMjYcsIk71ASzy3T6uURHtjnmLbhSOzwlQR/hQlXda3FSeyjfnnCaAU0nWGHZIXA/gy/QN90y0NmZgrf4j2EB2ECs58HEW5a4WdsF802IGjEDOfoZGKVMVBQZ1vp5FhOtbvCf2bckNL9C8BWFmXZMigXHOR4hMjVpfk7L9JC1t3PQqkNwIq4OC9N9S5JydZ2ZPGPYiUtTomGIcV+DtAjB+4tcXBaZv5bqeVNRiyLlsBG+6bfFfLWSQAwPaUlbb5WbCY4a2Q9KzQW+KH6UDOTiiKIi4BOv3l8Ffd6QU1VDEJX5qaBwMsO1aeNe9+hec7e3JTAARsgPw4xyHNIJyNL9+VWTnW4+ShBeBoErKvBEKU4TlHHj+biseWszjl+H4l5NPKSeYBBXpBXjV6ggpFFVFd5VHCzMPHh6tKM0lb3TOwsj2UEdhmpOiUw8eD33JjtXOrK/BhGgFdPmjzx3VXwwgSaFpE9t9j93tYKywE4+9j/Axk8OGLYGYlkul0+mmzmBZwjqyo388AlPlXL3VwCCmAdsVwAHugdy4lWqmpOKC5sznZGIUA3zrr9pca47gpFOj75KFgVAjy4f9GlLbN4cdSzaduMMSF6it3BrFyywUJpvt4aeNTZCNfzFzfBISZc+DSRbgs8uVv617DElwEfEJlnia7JTQ0iXQRjkbVIa7wPOBAiJ/j1Eo1qDXhazDSWp7rtnKlSF5iERAL3fUdRebDUHQVe0ma9oLBpKfxw4sCiiqQ6nYj2xaSnsDIq+u6FMikEEsXl3KY16cmXzscHK+AYhNsOwqCpvz4D/5XnK2Otzg//aDGvJzkzVwZryfrFDNiGqxbeexw3/ZjYMQE8VmP4L2v7yLlg/EU8tI4QelCAEMP+sGwnCGptbYpVAWBdywW7I2VvwmHLfqQgA6Ql2msUPtCEcPXwqdGIBzNf9GxpDIPtCKjLQAdxlDbvLkSSETWKfoLN+VGuuP0Gg+E4f2vzdNHRNbOLFiZ9gDlVMRpyHHsYfU28ky6CVufcUqXdQFnCMlzq9LJyf04KSlM728580h4EvEC92gQtVbZgXy3hTjiIJnp8Le/TM60UoFBayxn+UdMCIyor6fNw/ACIgQT1Lb5SDgqwfNc3QdHAtINUjyZ8P47dcE7juyBIo9P4I14v/IXKZP6WwgQVgBsAfxCn68vHE+prVJlLNB/swlVCNUv4pN4lNA6wCSgKXhK4Fo4OsNQCPpqyQPw1DVE0ahgGy0jvZAWVwQi7gaTi4Ox3N9Vlc0h+mhpluoMcP/uwENFmv5jA7kPt5kTnW8MdQW/aO1Pz4ADKno1yArmWWFm6b6ISkq4gibPRtSBsZEShkKIJXZgPhTNHV4lAG46HG/2iaYsu/niHLFAASZ/oEMJR6/QT0w1ygg4uvczCcreYqh0agJ9K/xERGoU2fS9zHMMOI//W2geb1Ry2UTbiKvF+BcwiboL4grBTGyCGzjIEZ6z6MrKdvUIqT7hqAfy0zaCaqKcuVfd8T/DSE+mC0Uhl0y4dvIooDuexpdwKu41v9rAm9CHDFwNqnUBnxc8l3aVtRbiTnUwCVRUk87b6I2ddgcJl2sRmyo1fAJNT2XduUGIR69pPdVgb85rUOUE4GqKmsOSt1hueXKlcKtEJzSAxDRjlNpk82WDOgeuENwFyPXdt57CqVX1/1X+F+rGGkklSWaGLATclLR3I81qFTA71Uv5rj0uLnVcX7+NgliF5O/8/BnG1ZNDSSFZJxjm630WWXLa9w8luukr/CcE6efDkc+qAVnf1e9Kf0iNrUUYUclArsYZhZgaN5CX4xCCohXXD5vigrDov184eyC8y5QHsDgDT7uplv1byzdW9rney+IpzD7djEheHPd1tZ0G0sQuJArdDS2NOqFbTPo2ZPm3UV74Oeczdu60Jb6wNNJ8hbvRYHzWQxmOk5GK8bQDCPmlWtATcajCcu6x2+0RVnVzw9IcIvygUINSWHpn7AnvPM9LU2jf4q5rbd6lmx3yez7+2V2X09y4+E4AjoglCfu7IHndAmVbx+p1n7l8DliM7LM+R9/Iwp2KA0zWrAMbLBEkvHsiWNgapN1SpzgNYwNBbDxAA",
	witness: "data:image/webp;base64,UklGRjgxAABXRUJQVlA4ICwxAAAQjwCdASrIAL4APlUijESjoiEaC+8oOAVEtgBi/fuC7+S/vnovV5/If1z/B+sjrR7H8xLpHzif5f1Ofqn2Bf2K6V/mM/cP9x/eO/6f7je8T+1/aB8iX9V/53pu+yv+5HsRfyD/M+nf7OX9y/9Hph9fbqDfED8j+T/9f9KfyD6P/F/3r9x/717jeUPq1/0PQr+T/cX9F/bv3i/wvzu/nf+J4T/H//E9QX8m/nn+T/tH7o/3n43vtO0z3L/a/9z1BfZ76r/wP8F+T/pm/6/+I9T/sR/1v8Z8AP82/r//C9eP+b4UH4//l/sR8AX9L/w3/y/1Hu2f3f/z/0voS+pf/f/ovgJ/nf9y/5/+N7YH7z+0gZT+Uee10p0cwcHF5Oe2sEstIez14r1wRuWHXjx+1907NQcuQB8wRrrOVmvL54yAWsp/wqeZdyJP6/Yaj9Inyi/wEmcaFFu8s5rkoUfmKxOVRnGvlxlBlfunWWkrID5ejUCz0aBtdjilhrISkcpqpjPTLhP982sHThHWQTLIc6XY64qOnVxZbVP6tpJHZevxQPazLkAGvn8AsdxZ12Ytpw98qt6IYFddo1r8ar2dB9ZBXLTP4cCm9TKfx33YNHnNoPJ6WViiVi9Y+4ycAJCw6OPU99P2gVRy4eBr31ePuIXTegpaGFWx1rXhd5i3Gun4KN2rQ/Qmx5VDet/c6e0FIDWPgb7wYxSN9Be2A3WSo5FpcOCdEbdDKl68YU7gIheMK5g0Y8562pFK6vJg6uI0AsYLQWlRO4aJGhUQtlu5+UmM3sS//j1wMFz7B+/f4clucj5TMweABTeaSf13L8gMalH3DxUFXsB4Ok14s5/UQMnPSTjP1znKll3Z/dTpWOWECedgOna9+UFTfcGEph1rRzAAXHd2ow+78uZ2HHBRf1ey6DOn4y5dMmkOE4dQSvvOUW4UzNQwwvsoMuhXfpz9YZ3gTi3vXzoKnqj7XL15FmElXrwrkYZMyoZAawNkz9L7A/JppejU1FvXCNT39YgVeqdWI7nD7Kdw9zXyfZyosgp/X05A/sRZARlbcyJ//92cMj+nY/5mpky9eraI/SQ/DLdbmxhggDI0W5L/S3bmOOaj0APqE4NbPUd4WANmx2iVYVwFB6UBd/YIsAIbqLQfaaQR+/OisB2zCHhK7/l/gGkyk8ZsnJyY6VNoEIw2pXLLkkRHxSg4S6SHgu9gc5tvsbVxhnJo167OM6l42cQxI/JFG5OeX/Vsc5EkF2vjXv9IXNBHCCrRBGFD9i62SZq5gtlyU2+Y+q8xrAa9vpe3CKueSO9Dr9SoV59Z8B5relXQyOTHraODD4U62Slkycv+Pz1PrFb+qXb2uPKBGwHeNnIHWJT4joQccyz99BpzeDNR5aLCsEvhCPxbViUnh7WhqQA7jLvd32SEXJlRh5AOvQRyCPemO/YldYQZ2lillqfnumdrnLyTjCSqbGbX9H2x+2gsIAjWfdLRMFwtxiXcWK9JVcodLWU/iN8APqrLuyxXDPT7Hr+CnCQ2gyTNc4HvOjuAAP70uyMGaU73ORPWLQnOw3Afw2QlxXjVnh5EjaT7wwJbbrwSqvULs3V46EFwdDdUsnbisUFIe41QrSPxbt10aXkw9h1F4ws7TrjG/MpGafHHSB9aCS+E8oJdcvkUgrgEOj7s2CfPMYXK6pgrKyJLwn9rOr2p+ZTER46COCTFKzkAnj73DAoomniTILhYqhok914p5qrcxtlBJsA+3yqhBROKT+SRshxcE9nhMTb+cx9nWutOH+TN4vBqhxoD/DsaFZSZsFV8I+y4IoXuN7ZezSEfiolTm97B5ljSK08qI0NU9CmuaqExd+sjFI0SjyKsAoKDhv8/pGDaqgcxJRujc0s0wzXKwoS3sCqP1ip9CsAoKN4DSl2T3vl0dO1b08kzxJzmZ0JY6edIuT7fk2NfkQ4/Xy+xYk5GDWRSUaDz8AkPIeluOEbpvOQLjdo5TjCXrfXpUZ5oK5PhG7r32GBQMrIg4T0j4RpSh2xCqUzDfxVmKgk/bnDQidlxns/gF/YqKNHDXzPDNZ7rNAU2w+N1UJPaMtmhxDP3eWLh8UXl5B/21PmpBOs+xbkzsM7KVew9AJkbgLb2Du4lZttRwsYTH/z5ekZhLpG9jx3Ie00XEE2Gz8DRlrW2Prw6NgCF3ZKdxbhUqUS296tvdhFA0v0Sp1I4ph2I7l2YgwPVdNwlRvVZoULZzsrzXdKNBrLPrMC2ClSGScgCBgFASWEFqAtACwmgBh+KuITVqfqcAuZWilGKS9+eOJQsNjWNuvpmopf3bvz50Y8qxZzfcTKk8VdDeuccLbHMUu6JRNWzo1uW6y/HzQgq5dvH+LeI2Dldmkd02rCzLiZ7bDnHHwARTJtBY8rdiX1yAizicsPcQ5Zga4z4YVgVlMnbNruX4B5+ZUCwXX6mRL8kIEjYW2jXXZxGHwTN8vCKEsxb1uCeb0hmihpoK66oxJP50LoH8n6F4Tuw+dzxkyIi4M7ND+Wn5dGNj3gyLqXaJAOcMJAMQBLvQywcFzPQ3J/USWsNqLW6in8M9X7z6xxtf7y2NkHIp/4c1vPemCYKdOIqjL4Ot9IOIxU6fBHB4VD4xQclRa0waeAzODgT9jUni5lsWjyHEM6AvkG7x/52iaQ1WFRT/+37yaYHsF01UEApoN7m+hJV0JhD/9yiDE72VBMc57DTJpilTvtXXHPvnnZvBMmZM/7eLV1p38xsqiErbaS2vJmKaGxarh9pRpKvowt48Y8hk+KJ/nOKD+xbtHqQB+1n+vwwPB7XUlUou3vCf/wgSYQ3heoZ1GaTVcfiFKQQoNQxNHFZ90Z5yQ06uK5u7KfXdtNBXsv8uaVM1JaaM7GDl/k0PtezFkUwM2kUXozq/xm7HjKhRNyzujN7a0hcn4ltPJ85+GGJtXiCdbLEThKVXE941k/DS+6F6ItdnV0n26v9+Jdvmqq63/fmc8cd+dXKYPMwOnan7WoQNoKZWOv+cEqP/X3OARRpzZ5pSNfanbq4wpQBtz/kOa57iXtLuU/pXZ9qVqlTGo/hwjqSnTLZvBYDKCQ7ClRmWUze9fA7j3tp9yvvcS88M9/AA8O9sLnz3Der4wkDrRr5QS3MPH8JCtB8jBuGK5hzSAOt+64emnJ/7a7GiWk5Xbsn1n6EBHzXFHizRU32GWcYZXScn6qqAKmiuuXfQUJDjGE+iEi4SEwU42jMilWsHoSNNUAWeg8vAtgfBEg4g07J49nv4oJivl2RUT+Sq6txPhZH1br9e+I+nmWsXcad3pMYt/PxritcNfFqaAAiD4pCte/7+S/McnzbsDIBsdS/fY4JdATO6NekvpIeSB0+kl8E4VIGdym7UeaG0g4BmZey+LFVBbupWviZMr9RY1zQfxPX4BEgreO/MnwJeFg+z0ObQhjTLnF62W+cBnr3GGR2oMGnKf0RbjzrC+aENBNKbIQFzRhgfzO/Uj4EGxjzBKrxzq2iD4gMsD38w+QfQJY0KSIzYqzueRq/rD6UVBv0rWIjSMlz5jCMN5vys9vhzw6OLZA5vnJZEKiKePO+kUQjon+6QwGZh7DxBJnm7tz6gpCU+Of+/FSpQJOFeD7weya0k23AAwhOqmWIomGVr7KpWi1wGSdLToT0RhsKgZ8r+FQpvsF6LNY1SX4Iz0+u+UN60Xj0wrhdRDJ0C4Z4rYlL8/9C2xToZH6f1IiS+aoqsqiVVHEKN5Hd3XqzlyooACJv3biZ4pC6eHometcqh9ui3o+hrsaqn+M6Y5/pCA/WKJwH6HYxJrkLEVCtBwryny0rYQO/HjPbwpGiIXwvsl0DanJvWOvUXpkpXUYbBrse3I4lzCrwcpT/M+RNhUyxo3qo4CdYlL7PN26NztPKieLgCkbCyS3fgr9T/hIPAEUNEjgAhsOnDF/EailxRX8h6P2cPeKDjZYGbeJLs2v6QByELAyTlfNpYCSfNMpFSbFfWimWRic7gAlbtxNlM9v9P1sm2bRQ+ZwZkloBcM/Dg2a0h5vUzLZa5IDw+23EQslhFWTQGiAw68dkTHQk5QJ4BI+xflk74l3v1ADH/5KLEGlTcoEG3Bimj9dy1n6C91I40sAiYVm6lZF8nR8G1nKeBBi/KOS/Bmfrks5FAOATrvzC4h8C+4Dks2mrRjvpblBC/qgQbJ81A2rTnDYmmbbGHZJ79TTgG14/Gh33VfTA0+mz5DTxcDxFNyMtJkcaTtGoWQbd4pgC7oOHmWKzKpeD+eJVzJIQap6GQJe8EfSi1tuJmmVW53xF+ZMEVUQ5EEXFinIH4butl8rrvlrtC645KdCUnNR54Lc8QC+tncixssvRTk9QDO/KSsG6qlAjvOLO8myYZuuFCs3e5giZA6JRNZ3xzNu2vpVCbeOXPIdMXJryOXI2Zo+iAa+dFnN2dTylWMETC8jl4LRpM+UaPgT+JPYafKzwAJEsMY8xGmxcwCpvE4M6N2Qkp9tgBnr4L7hR9iP8dmWvpnMUVDFKZqMvkvEZHMeDV9vSm2ZYqvSilO3JiwZI6Owslvmk2CZHMxFTL4/0o9K44kHzbsMfON0bfbb+BTHVWk7IS2pjaqdFuAjSz2zAJzqq8xjLxihwTzK11EPZ0kqKm7dyE1Sfzt349q/Y+14YF4292URbPGEfT9uMQwXgRjrkNzsIllMt1Z9zYpP3jNb5VBOuGOBZH1MjnZ2R+jkETpXpKwBMdEvzwoynoIr7iq0Hev9HwdP4scyRnFjRC4DBQN+7Beq6H9W71PWov/9dDjWLolckS1w37p+LnFfO+Ny7/GUkFEUjFE++ZPXVmWalxyqEQ4eA1if6MvUpnDNWADai0aa0ZbZKncM+eB+BBio9ANzjU8YqFw0cCi3zAORtC/blQDt4XQ0LSH6s5BdRN7TF+VqFw8DbfruRTnS4JG/D8PyRgbV7a5KYrOmmvqu9FurQfHoY9WD+6dHbzFaiUfTfy/8u8vI1H+SBcmlbKuVvlPOC9CNYFm/BXmhCNxh9Ygl2b7d/S3yV4w8rDHzEmEPqHtjsTfTlVyKFfVAPmYAfyane/X+xtQcqg2HUo3QRI+pLeuoHRNCHsYes3M9eDf3J8wVQpBBKxfd66y01Qx8OgYhVJmBV6THUNomv2lH7IanFEzQgJyPsvYRJ5K494GucVzKpUiNKTO1BA/QOkUeDwZDdOPTriHWrqw1XSAQzpA6n6Pv3SnBVoE7B5ZHw4k5o4XlYzZiH3522oxPRYpcFJ6twxaKqKmNFViH30WmEN5OhUgqx2XV5SM8ZVlIFpwGpT/7RayxTYohkAG90hNOOhq+eX8i68kLn6az4pqukj1OEKeLHcHBOPwDMJPipoDTqnnDi6MMFjvIeyOIIeWAIL/69CsXU4EwInWmGYicJoLB6yIm/6gL/HHZlgUtta9zLDxOVKxjTRuVfcLxfs2yXgJhPLHXkcfJ9EzuIiu/XgMpPBDtrPXMZ/9g8+f9M9gN8zqXBK16n16GeX4i6CYho+MXpBmiLFTnarn7RM6USH4WuIXYuoIuCH87+o+qXdQuZUhOU1/l1hkGgrgRCVMJO9+Lq3mQKvkrDMmlg1UGaZxdKC415JhXWu5h0PiE3d4ohmhcx1xfy8NOebZTlIiMP+ZVtZ/IszJcqnnK+GihbBqKw8o2sRQmBjiJY1stOxWAAjKJ1C/wUrCuuXhsLaKwCHr9KDPsjAmKDMfpKVxdWVA374ImEY4G2bbmZYreZ519VZ03+nfb5jXLYTz9rlMpb3JEFBYmLfSy3gVln3SW4QWYdq2CUmDczo2PQRXN3BuJQ/ipY3dS85MYfgbaHabl1uNXhZZ90d6gdz2t0axJKMZJFPOQqlACz+mWy5nx+rwlsfhCpJF+sknDpHUuswVGeGbr50p+hmxtBb8vKZIWBc4XtzPgbTtqnhqUvmBN+qX/REHw89zFa1oM02+r9XBC1Whj1Yc4cw15nd8x4A47lEJ9sd7MJPE6n7Xh4V/GbY/NYtNUZPEqaFnvx6WnmfBND86uo4WrF13cZEYFXzFiV9bz2s7zCiYF2X9bsCiYmKWRWFsULiKRa0H3dqYII6bS3HT/GjyyXcSOEGomZhveIwNfKy/dTW1jAqCMc8e+7yx1OCkshYOWZgXm5C8/CNrO6YJXNYV42LgWw8lTsekoJ5AZj8+rzHAqnT65U3/NgQROUbGX8fK4RmCYnmy34hYnrwBhvZS0CYygwbRAH+Ago+MO2vXgXnlUcPyJgqrOD6ELVhAg1p4ItU+J9dFOsZpjbyFbl6BX7V4hXQ5Y22dWKfZyvOVGQWzcRHI3KKGm8lQDhXU89JiOKCkFx4D8kyl1oL4A7PDKZRJtoTb+4RdXTHtEYV3REh1PGStRD2Osz89IVe9/rDiMew/1yxJ+GIQTha/6kqNiuZFC8zNFdFbOwvQleSVk5ZeJZBbIS44jVMaIAa2gJ9ZcbuUmcdyDIysWc0FnflOCd5ZhxUwpyx9KlRIpPo2yHbh7fnCbI4VIaak8PXmfm5q7JJnOFL1VT0j7xa+a60Xde+g6MRVjGIZKdaAP2u2cRaCjnKOB/o5vdjZi1d4FCDOzbq4q+1d/HzAJS8XEDve5iVSEN8E7SpZkvRY1ken7qxGyi3NQRDDxnz9q/Pmf1i9BvYzj+5h8QMD60HapCBpEme09i+ccdl3suqEwQeSpR4FlmiTuXcCoioY45Al3SReSexIoWmMZmcsH1Y5Yx3aG/8oIeOrrsIZM1vWH/ehxxN5459cCa4aYJWLA7NYRd0UsEsLxv60jfxD38MFnKTUDZPDefuuySxxgb+RTOHPlYmbO/uHie/4rRikwI44oGt6bC3i72ZJrC2F1acZvxp2TtcimLh3ZOCeaviFnzvbr+67Ku256Zniw1dOv/KISR2erajRuXM+0TK7MWvi8UCyVQ83CKYme1f0vYubt/AePufNzz7h21rFkeiySHbQYAlca/sx4Fpat2VivT/VRgpraiZNncppBuXK54GxHKiebQEZQJOGpmW0qrCjXmVqfL1x4WZXZL22Hd5phpsQtuo4NCBXq+FJFI+DDq6TUgV3ptLQ85juQpEP0NPGWcMOxgkN8dkzyUNp7f9amTmJuRZhMyIR9zPuJdmx1pKalb2E1WQwyAF9Zzp1sqd7Q9X7k8OQMTsz1kQtQpB95litaI8ubSGHiCmXdO23HKrJduLy7pIYOwO5t69uX3QMgDfzpxfq0u9q4mBkRnYIgV7+Iz1ldCi+aKkd2HSW/pb/6z3h8voO/ufacc9yRNZcUlGDcQKNv64W/Ql9LWG8qY/VMoWpfJqs8VDisgHd5X+Ehbf9s6ttjzrjN1s9A0cPTq8bCjZJ0iGfJLF63/jUeiXG11Zk6IXesEzNi+WiNk5Ysb5XsgodE3kfbn64Bd2VSXgU6+UBi5pIqqqqLfDs9xPHam8Uo6g3W3Aet13mNpD/JdUyu4wxNP2s6PRHjwFuaJPRf1nVJ7G3UZJcsWVVK7DDuGW75T3D1MMwKSOEx6ub/Hgq9Q2LvgU1bJxVo3Atay/rUSW4eZdigDtoTsP2vskhDCzyh70V3j02SLMvyNG7dnpHL0SbNZN+Z2YCDFQNUtmRmv+c8LSF9GUPO6JVK7WTdskS0HFoAA6Tesy2BLY+Uar+qjf1CTDSxR5/3Y2He9dJtXOKzaLzG65z49j9zF/zdAY9h6FaAxtzWWVIDV3uM6/a/HOZ64o795Ttx5AqpaDwmlN3lvCRYCN2O391oNp2lv0JcEgRB2GswVCooyRbJ3aaeRn3deJVbCauUurMEBKbrVejw3Zj+xm9oDkWvBXTy6rWufK+E+YaLYvPN2XGCtltlMxEDWI1i6jm/g+sAVAASYmTQLU3hco54nhbKmMzTJFVpCDIyevjNVEWjtTKU/tez8+HVNWEUb96VNbEACeO9ZmlpCsLA28slQ9XwoaWw8g3bZPuJ5usJ9XMKJnkuuths8H4aRAB/PGneU/5DX02fvk1BKc/ZKFcdhCQpuVujcigQuYyGi/81eUzvCJahhk7sNe/A9Zi8z1sVDE54iH1dCKwGcnhsYvyFQY60KGeLFlj5kFFVI51doOEcwBj4nrRl3HtRJIYkeXM/HwiWryhgn2QNXMM6afphDB6yAPtplbWBXzQ+rru8Qby6IFGb3xJht1WkAQqf7PqdAuk+qD5QKhf+jcfM9Uf6kowzWuyZ0sJs1oDEEK6nnn6Pt+rrEixb7oV8OgQ17vKB1uaMnDXCmn+da7NVdAirOOZS5HvkgjPTMY3xbCAtLJJGiS81EBI0P6fzgKWyVpQKKXrDS/mzXRuTBpiPEUHQavUlIP6hyy7YEt+jgenwsmqKPlmney6aKWt7e9sWMjQ2/sJksB1imj4KHo/Al9awsf53+gfu3eAtUsqUrxwVDBONyp4bif7PQWLLG4wNaGRuOu3ByfAMBlzPqMPG/8+5Yd5e9roiD++UAPjnPm6PKT7of8inP1MO3Ev8Dc/d08/8/8tMGKeamfMqwkgcFhEeE1TwggLWngJVRTU3D8rwv5mvLteSByAfZ2GEyGsWT5aQYh2vnHRD5iobD8xc3G0qJjmD14zll/OikniZPf8CCY1Nc2k2Y7R8eWcFdW+XgyBspgEEJXTsGX4s1fkyC5w5+FeVkeSA84VNqfDsrdgdfU54QZtoixATSRoSa4WniwaLaU0DZQBmH7jWZBCobVi8PfL+ejA7fJgAJSNZ/LevRJOKCunpRq5fV1PU44rDCDVb/67U4Mvh5EaiuWJqXp9ZssTvA7etMTuPzPcaq0Y/ouz94d4I5g2I+HN4wm05LWfjjozMoEqhMzqmQ6htGNXw0/AsHBh3gJ9h7+cqlLq+fGuPPj3jiJ7p4ZoLEjbYo/W8lF+lwiuZCZYxzNPKRAm+scJdMmHTTtsoCsc5dsb5w+m+LaOTvbY0Xboxcyl2jnxp+Phd1LZRLXy3IJ0M61WW4SsUGjf/yoMp/pVqd3AcJ7Qs1CVvgKAPw0sA6kgnvG/dJlgILK4cmoLoACaZK5uML2CT84sdEiOj1LPqJOyUXgqU7I6c0sowf3zAt/RCTG78DMpguKasqng7nFNQ+KBXTShf20MAfVmFW1tTPTGwek2T+qcztDw+c3ieagje0nqZhmuhZYa489tDvvsUqA2t21j2YV7JTRxsH8r/hXulJPCRZJPITVq3bNi06Ems2uUg8Hb0dhP2sfwOkQTfkduiVEWtgzqcIe/6wUwSrgK/ldXNdNrrwzhdhZFPSURFvTqauMTYbxdWCY2oD+piH9Jv5UjbrsIgq5YTI5fyfcLE4KhF1Lbl9SJNNWLJubxy023Snvfi+lYRB0xwdW4fp+zm1Ao9gJFpEfBpcz7XZ1XHxqO+UhWDYN3Wq6T0qJJGsDtGyzfCyCywHo4A0s6MkgEuChNFnWN1ruC9PPV/KwM1HFungqpJtgOoQIt1Uz6/2FdgO825r/GLhShzSV946+pMH/gYEhUdwFnl6SZ3kGwJcy1lmiLAecGgrpbdC5fjS40u8wXF2TI/idje6Rui+2Tavzv3X+IKCgjxBeCVpc96wX5wZeerhmv9Sm9SLOqbWKaGkXQac7LcbKgM09CxWfit45H+2N6gh9eg/FJS8GO8Zndwgx8fJUPzL2cZIMZSZLqSGcTboHgfgrmIaM9xXuCbKCaQijyvVYbgzmfDi7+AOl16hDoBYioCc2NSvWoJoi/WDEPRkymSPLoeks3WHFbJEW6PgaD+doxszr8plqr3tWUrJpEFR/skXdp89P5A5PDYvuzC+CgHd6E5xocVFG/kmH7/Cd8M/DvX4cLqQmSZy5AK6XUvu/8dihcmE7M3cYarYvq05EQroc4emiDcKGMRn34C/vCnbX3M5rMBq9SUu8pm3fvesAWCXqjeFd69g0FGEfy4MAyvR0ZygRXwHssB6XTg4P9Hg3fJZ7ko7XrbsXlT3cWAN0MGuwBNyJ+lH/9L9MnQVHL/4G3aboyIhieS2PdAGb22I6O9HauOTzQ7kfv2LHN76ImVKRLjOpd9PqwSPGtJONG39HF/1f8Z1FNu2kOpRAjyY9OuMWK9cGs+srEqpHIVsgGT/RAttpUGrGhbjbCRdMssWyBwGDLI3equ04aJ5Gw3dyAgFoSgw94RgTI+tiiETieJlmst1m+MR4eYjTTBU4l8+EOZ50sYXGGtq2uRjNndwB7U1V4ucCP449RyLwuVpjJ4wPH4n5Q1gizVNEyv2jcW0Tx207lHoZSathV+VokLIrpjrwc84lqOnj5UV0AvUAiR74TckMZBuB2iD99PFItcwJ6a/oEdKN6W7gUdjGIA3FxdlWOKl0mX73LTGDhADRO1bncZzcpQfkhijZyUbfYFc7EhufJ3e7ntX6M18Q7eHXqUtrcVh+YVhCdvHxbY8xSonZ+Y1eff7L767FyhMgiCXjO9HPAXnTklkJQULBabgx8+c5F+OfOsfk5gp5JonVem4PfXsJK65JYC6mzZm8UhQ+wQeF+wd88GM+8B1Gr5uM0vieXZRiqRgW6/v1+3ilNUL78wrOdk4XfZXLVoC3KVOizeB+TO+CboQWy9xJzeBM2qvrxLisEdyF+PcLt7bzl4U9LuQH+TLqP+6u7Yc4dk+hLU1bjlEZXI/rtTDxRxEzf9xodW2KwmF5aDxqsFxT5lYWzufqROMQItXVei/oRH6RePK3eJX6b2o7IttmePrGh65XovKzqf9Iq9M/z4Ao6Ce+6diKC0CeHwTJgEPgT/yQEosewypXj7O1ljBxA1xq0MrUQl+x/T9EI/eSQbPdv0TU9W9Adlvapq1u8tCdhUJ2wWn5ak+nM2YBtl46Lm3O4uOlZQ8EV5be0akFd8DQYAI9o/Ck2YnRIZjVydV+ris6n3LcJb4xQ59g2wIgyesoVhUVCVnMTPRj64g8nWEkHmamBeHjz3cnZWhbZ3PVn3PAM08hYVjQo0t1TVsrnX8YgBXX7zRNVXJYAtvBoF/lO46srLPrr6SqcRarZW87bpRT6h1tpmI5m0d37fRElqVjO1+3YuMfCdg1QNtzJYqx907PIjF3+ZwKIokWnlLz4bE1MsWwspZa+x6+ncduZ+sNONdQlYtS0+/l9XcIDJ3VvP9iw1bRSwEli86xn3GIkOQtL++d4Qv+bZpQMqIcRVUyI7RnMvwOiAzwJGyeQoAEZbNUp1knmQJpA3+J7ykxTuySqzfGQDpax7pYaBLDjVcxxIY7JALFUyTbnor8mD42jgGlfsAnAKCO3Q3AeOLpLR+fvheVEk1ar6SI8PU+moWNghdZA91FHyLlSM8ZD4pudu7PdvFNmxd4D5OQ04e7sQTKC+J+RjGeyMHl+8NII3SAuNK7amWLFcSbnTyuYthzZIXycGE2PGIbGg0jIuOLeVHsFH0nOQNhFW35ewuY2oOdoYE1BbplqSHE7A/BI7pn0A1WF8LxgKIlpHLY6IRE+eih1KqhL9yOFz12HogJT0g7kxsQttRdY0JCxEY1XH2Iw8bIwT046P7D9Cxf8XJAgx/0KlnDYaE0v1feGCcTddCj4ya6zOft1DF8r8/FWaoaalr6mUnv2SPl72VSV/HzXcgz0VTm9ZkbryU1dfZnWgPbfmoahizEM1w3vCbpbl3zYH3QEJn0bC2RUmIt66ayv/ELBh3X6cPqU1AV3tGXhagotSi/oX2/+pLaAevGeYM36U2nkfXNIBG+kqDDHCnu78eS9R1v3zJsTJXK/48bJVqYnxzkdU5pPcKvLC3hyb56w/UngLjcOLIucY7yc5gbsPBzyy+txcBWTb67pAalmZadP3VM9SH1hYzmJBFFRfKb/o4z4KVIZwphiUev7YKBM4ifF8LrEPe/2wxY1j1Mct2E/4PP9q6babg7S5dqPvf144UW814XNeq2iI9h5fpi9uyX3Fu73plwCv2B8XqGB/Y6i5pxxKYWwwrIZ7oUZpQXiQCQFoEF1ni2eUfh8X0uVAvulrCtoBjKji1BvYVPKJ29zOa+HbGS0tU/WkZy+FcL80Te+l5dD/zPGAoj0nwGfB2igPp60LahCplaCs6LDJz0de3AYcm+mmjlnVJRCGcBT/EvzYRBWIr1Xyr3hP7vo6dyfE89i4iKMDBzDaep+W3nOQ9J9rUrawCwVJNe2NOnSMHFFFhnneAPREoVq1h3yxS22vDyMxRn7FSQ5rBlbrP02nsP4pdOOvYZoqzvG/GVI+Tiwp7linH4khtX5BWUnizxa5RZ3rRL6AFpXmg2dZ9OF0lZXQTOROOSjIFpTikWauiT7YX8KWObppvxOkGGzHQAlCOYZFSNNOx142olZbex89zZatdODuR+vlMZ1K2mR12gfOIaWPjv3Z2laJelOwU+CBdB9bGum+9fzd4Y0wT0KMtcc2sHvxZx5XtlBxZUW2ZmF7pXR6obqKsVOP8ZsM3xLEbCvEsS2dwmGj472J09Y/ZK2qVwYT8W0bHhSrYYzgBNizcJmbpUFWuDeb8jdTeNu2iKBwcJbdJSHIpf3IIUCP45atFsz6KzOHUKwYp3cOcK6rP82tekqYQzO21vUSdZnEzrleUrInrYQfOzTKcra/7gQwTLoguPXIp1yVMsnEi6/qk+wHP88StoWx7GVMtnNt2usb/bxkK7UdV82TaWfQxfSg6vBG/fLbhK2aJ7FWakYw0x1L8a4i33Q7TK2dWlSdlPoyC7rmrCG3VJq8oY+DKPejSWzUBymoodXVEaRlTU1DiA+yql/YrSLOUFSN7FWwueftB0EEy58K29neP+/WsvnzGuU4W4t5iUxB00tr4J6ZFgIBqYQBkh+56CBTOGFi+H+xs4Ih0Moy2LcqADjllBcv/lzYFs1kKvk3zUIVcKwGQeOR6Geo2OvWDZ2cEyZZlKxpQfHWlxMtmwitXX5GxrsaCqjZrhkoDm3cB6SL4dGY9Rrg8RYA69AEearNuSAf1xk/Y2OUOOFF35vSAoMQ3TG4MrIcOJYuzKHi8SKWoKSpZsmhfIvCb9nJXAdOlXXyRWqbjxGyMApvmgjFYduLYr9uUwip1/9J3dNb9uH0LQA1FMVhHNtXU2N6oIzWsbseLLNnGBQ16gVgEd3NmfB0JaZcnnB1dHnDsUM7Oy9aRwu7pC8T3jQfVDhizbH9V6oMKeawZOiq+1dv9FdgGAGmattzdauy1idCSBpxZs3eNV7CCphUCsuqKMPKTzMxaJcveaPWBkqZQ+rqXHo97/XUxX8h2GIZPAQnlHXYarfxmNI6pDTFWGjQDcbmJ+30vFEZJ0wQOHbz8uEjEJi3feto8dm8qowEqPD3YagaPDFm0FmzNt2vXOcNZko3PyhYEc1VjNEDbSGyqegbJWUlBPprqSFefhnoR0KGmVbFurGewo8nkZn4J3wD3hh0s9wlnlU/GWFHPkIKJHGO6BQqxMT5SQZRl4AMDxtTugJRAcufGu+f4d2VBtXABV/OAk9NbxAiGhWOO3sF+yLc5k5YBMnANRt6l1NDv5ksplNoOcOiJIGmVF/aw5Zhuff+29yKwvcQApTXkf4SBRy95cSsjv/2v2eFsXay9JxyRotE6g6wmLsTfJykfXxQkxpdu6kTSgjWN/FPZH335+Dv9RXW1j18ChTSVXFZMLCRAP4H58KSo3HfGwlbIfXi28KKPtLA2oRDs323HcFhU34+zrWV/Hecb/lCi5Dsk2r2CN0vOKOhY+qffRoHxE5AbbQY/5aMV/Ct5xfWSU5OSMdMtO8UWTmKBof7WVJjmsdCby6u2RksyQLBiRxt176+DKmN0na8wHESRISeT3hH3erxhfWBkSnHJewPmrzMMabpZNmuE863V4EPsP0BcF7YeD1rpPEJX3sEaGNUguaC5HqIsmFJ4RGX81VnWYjT8owfEcVCj1bgvEZLnmbprGYf4U7xalNdGY+QJsnJUbtBySkt14rVUMJv+DW0nev4ZNtNko5ilVRfoMtHuoRzg51T+Xm+An+Ok4h8hMvA4hyXfZx34Vyfg4ppwfgKqdk0oF4tfP0HZp3QQXazxu7yynaYjZI5tRFLF9yOSb7D1QKhZjoPRNe8rw0xYAwGEswR/MGvRKGEBUflZJbvwY2LlWeFVaPaWQ+HeJQxuPkI/zafTe5KI2jmctmIQV/W+lEl1PX1e/quFMsvSRdBwhkZg4bLANG6GoqWGak8yHboF+AhIlzBpeRAAgbiWe5E2OQyoJd9qhoXr8f8DFB6B15gz10PeRSAcE1ACFJbzmuyD+JuGjMpmfGCaGJG0DtU747qiMwLN/qVuz8g40eVQerPkHM6g4/LsuUOjyJIbxW5x5NNNDHkqsszSDHMaoeU+b7Nz+02pjRPoFN2SLPsukcJDD0jaUWGFHp28196pyxDSCKudj4eNG3EQHqvV1EC2N/1+ldJVcsT0U0MHFwHAcnO4uMBgb9drVHRaQ7fgT0u60Sd46Jys0pIXPwNz+zegsaRRv2PSt8EdTncc2YqKKw/akRlGRcbGRACQXnx8XoA8dnVI3pw0UGUuWnBrVk8jW7W47NnjwE4smMwMP8dgikNjCFF8ueB4dX1T8czfCAR2zbl9rzNRKZUr/cGpw00qZwioLsQwa4YNAZ5tyKUDvC7Gh0pcBD1Ym6Z5vwa8Eec5am7Z9qxliELqqnoytuCnSqFpoaDbr5fD3KefaqIhVYGqYFLM8K7p/r+qrEeTId0cjWL07v5s7XHplsizhtY469MT+VV8Jy3PzLoVKJR5zM/KWFI5+nu/zxuPo7lPX7pH+xSBdNupCBdgCQ4pRGZpPdijwLcS+PonlTlckXhi8lgujsn/50R4Ck4h3JLXneYu7TvnY0CSP3P1JgTc8h8dinpIy4sbjNrDnrIUp6GU56VB7IdefcZR3DIwWVb17TGcd4DI2oXLn6iqi7MsHPj/f3vflj9YlZpiuLJoVIRM8HF0gOpd5GKOAImfRPg6sO51u+s9ozxjA8ysYkwQ5LcmW+wxdsk9KNqR39i5H37IY1DjuLd48HSuaecLjZDWn6NAMZY1WZsJDFQQfbJ5T9NMNR1ORN9HXT/JMiO0ws07Smgq1/4XoWqSQD8c7OWl3cDOyXmw1YSWdSrcST66dx5thUM28tapXuRH9EP+FJOqhZGu3+Uqgk7pXWhpDDlLoL9/j1lHfj0RdiR9QI7UlYNvXzNCmT2L5/Z6QrQcA5u23CI84KkEd3ryQnfdUt79VnuA8ZWi1AnI/ibP9MHDhbgIH0OLE/rqLQCjjjUyQl2iiXvC9AG0vXChcJlBshHQApFO/wtN+wjlgE/cDelw0F7QGETcJ/g0zQ/+SZgFIBj/DAId/8q5GIVvbXfsm/9iviwU7B9NGHcYzU4pdGGucchBeIA0L3KA3j/+wPcoiVw0bFTiLQi1wKLnhSVFvmzTayJYaMqdvmDTUfx7oVmzA7bNhwudFYGgLp4+6fCBmLqURQBdLo3xkflAJHHjHSUAxxHjwjG2UxxKN/fA525+m6vya1OtokRUr3ORiaRha5ia9Zf7qjgT2STt01fHKwuLAruyS7ujKxmEkzYYyVl9L0U6nevt+p5iaspSLn0Kl6P6phmulWDxGk/WD06k4KnFLoty3Rp6AGtc8Ft1g7oAkM4QijGqHnC3atC4kjN6hYL8wl7XAQoGnVYc2z6DQKW19E28v4ZGpHLJ/v53JdlLTBVNk5t2mf5fMan1eqGsxgtUAZ0QfjWLc2/lFPjQTfeD0HhjeLXZoVBLad7PAAZAiy19Jp89MbT2Dt32v3fCs+9xjgpvYIHYHe21AYXpwJZiwWcqRbKOITn62YAFiLnMpdqASd9GL3Ou684QKb5V5jtNcLlRden7taARBnYlKSCWleHnX3hk60OLCQ+eSwL3wmzOPUB5y2FBksJ5Ci0DW0ixKF/kykLieCBneTab1ueX/clmOHSTOrnKEDKi37keSkK2OetvTE15LfKwetR6hShL4BtEJKvzVkIwfVSS4UfSU/EprbsYELMtAHP5oUQ8TxkUXlusaalTIzSC6ZJV5S1U7y9WBgdNI0KTSS6sCsiW3a009gc0tFdKyt4F4t2Hnw1iLb3LThCvIQA5l/jyDGRGnUDO3yIJwKgYwf0z5u0b4Q6DSm/LppE5yTlzhbSKdlAs7w5mBPHc1LLgQxPQscH4nAnUnj7MWLfFFYFG6d+YxW+yncIP/tBsbVwnn723Mqx9dwMdik2d7lCjmkJ+9rA16MZURhs/TZlwXe8ku9yzYZiKlua8MOsQ3zdQez95Bl020Ny5i7Lcap8inaPLgFKyKNmOAyIKFHkdMWPtekBpqJx795AHeeJC2y0CY3fr9HrwbEd/l+pHndjUDxQhKOFjIFXUNzZ7AWTAvRYTEhAAY1leoABHdmrgnQRST3IOoL7F1SCJDjIt6qGwKiskwY+ZUwjXSAJMgckLXBua40cRCKhdggDFiA5ACdGQcDhK66ms2eWe6eUncONPb2zgL2YjPOy1vSYop8tiJAUSvzRTNnwUBkU7eykkskWJJdFzCI/9hZAgpOtRMLkUkyAAiOuYNIEDR8Gmo5QUJ5NPqAMnutRdjhqcbukL0CytP8cclWOKxMhCl81roVH4etqw9QTmBubZHOhNiaolrg1/qvn7KK/TWjm86Ykypm9xr5IpmOGByNWU2znqnPZLf6jyEkcayhaK19FOQL2P9XUlEEEA5lif++xEP9kPgHmfqaxIOKmyM7bYCLDMfm7yRgjHcS9SKuL80PU3rvb2xjO5cEj7/R4r9PX0FR5o7yLHGVFZ1Q4FzFz2uGBA7ardpx3l8xrCSGJbidtxhpmhsLV4BodigxTMlsqp7A+ypuOeJTHjgaOvpH60OnaEAAA=",
	destroyer: "data:image/webp;base64,UklGRtYuAABXRUJQVlA4IMouAAAQiwCdASrIANYAPlkijUSjoiEXrJ6kOAWEtDRcmAZ0ER7j9I/y/m0Wb/I/3X9k+yrsr6y8w3ofzr/7z9k/cf+mfYC/Xrz1PVN+7PqE/av90/eN/4n7d+6//G/8H2CP6v/sutD9CL92fWA/9f7v/DV/af+/6ZP//7NvnR/TOwX+9+GPji9L+5P9y9yT/B8i3SvmT/Kfuj+s/vn7nfGP+l75/jh/Z+oF+PfzH/Lfmv/g/i2+1/0HdLbf/pP+T/lvYF9m/qH+6/wn5FfBV87/2vRf7J+wD+sX+/47z1D2BP6l/kfVq/u//h/pvQl9O/+j/U/AX/Pf7n/0/2W7nPpKFqn+5Zqnucu6YEZ46ErAyu9mDrVll3RyctBEOmcP1g5v4ZGk+47YfpFI9Uhzn++ET7FKcYButh8+4PUdx6z7GfhCdNE6BkI1b7QaJtemVUV4XOGi07PteYjuZL5eRv9On89+MO4f/KVp8D6PZcURrWRi2svzN1yb2SDTfhACTOjyP2BSe7xIV1b+SCa/wgaVO6K4I1aWuLkvfh9qWBE5FCEBN5oz0yFurZd10mrytIYWfAAppstHO09kDL/+TjfOa5dV1NlIZjFzu5OE126cH/y80VSrhd5bAyaKYfsSzPJkPpfyfTsxtD3FCOBiuyzH8ve+KNPGEqnk8791DgLNhSzauSG5otNcclA+k/+NrDLLZ7qRdx0Uot1MEw+qRM9dQ1eM9XQeXJuLV4t5F4Y1xxAuTOzmMvl6fQz6LTyA6zM7Kp22TVExLOoLnFeA6aCf4yWMmVOXGLwBToO4fc1fhoFvbQgsFwld4MF3kl6U/bS7gsIselXSkrNIUvxVqui5rbxyDuBHTtXcymv8tia+O79u2cDdO58yXrdhskO4JpOLD4nEJkgDvM3VTKzkAS2K3jTQ45x1M3bhsBNEB2xeOrAPC11ZoDu+Xtc5f//ktMRs/f6XcBT9KcrwKvLa0oNSPN6r1IAtWeII+oYdOLlMbgQ3zMoQZrVx65TYaNTzrE8waAnW0XG+Uw4JAJjBUztjyIG+44nwzTPgqOA8nb168P2P0GCCb5EP2xkPAwfLL6X+6NEd3nNHk3lRSyXe2/zlOG60VfC255aC3ie9uNeg8w+kEeDvK7XbJLc5AHYJjgqUai659OASYA238GMcbVaSjbmU+jAggLwRhBaJ4nFGjoFWOCGtwKzdxVDP5ZCQZzL7U7EQBotFmdz1svjNYV0qtAk/wLehgcYlc/1MOzSWMKVoT4IpwsXpHgw3KSDo2eJR4sBFV33Dafoqdvq9S1HVHvjmT4KXa12ZD9EEVk5qVx2y5ID8lNfaVTlRRxR9qT6em/aUEVj+pceYvOD2y+qKPFl06iK61eZKMMOrei/eyuxz++P25aQD55TP9zEJN5GZ4WQF6gB48RL7CqIj0S2XrOSxk4glQdshcsBEESIodgo1QpiTuhkAmH08G73olE8RXfCMbHmMWUQJ+A7JTDLKt6UkIAD++AJiad31th4v76mAKQcG2WerBmYITQ380b3cIf6/LNLUQjc/0kpNQ/sOCn8GhuGbpgoP0IEZfOMdH7cl36+n/zqxP3caMf6UD6tg+E6ywUCGwdO5buVyVdI+U9PXfGSP/+cv6D+xLifTSNy0hQ4O0dsGe+HBvZFsz4cmte+fvsRm2J1Oxao5d7Y5mp9NGh4nYCd55qxG8zf2O7V08yckx2glYvpfPQY2EjsWSS+Cz0F3UTA4+vrdWrJwqFlUAAXudZqnlL/ML8DqOZeOTWXhje3czJbyuoCQazuCvuDd4bUECvKlg9c4IxY3btAvT/faJIt3ROQ1oEDvWZhjvPfqA7Q2tWGjmzJIeQKWOlz7yXW4Fb/pEGg+f2bjYjSbNi2jQEBupfHknNpwgvw05pGzJdpkZwW3rCnhcCYywpcVGHw+vSnjxfZ+zndaYXwZqZgFNCM7QYXp0OPuoqroi2E86w//Jf6SSY1qTwFNVSJyVRmOnMdqRgFaQswyxgBzACW3wjFsnhsa7jD3sAL7yVLICFNjJWL7f5aLy93UgveZkMEDFPkBh4im3Nt6fA1O1Pz53tYBj+4k17EdZtO++d1atOz7LwjgrBUOlHLqW7SVcqynIS8pL0X+na9swwL9PzIVPrF0FFsSPh7m8lr9siFBHMwhWtzVadDwI2y4+vC35k9PZKNdRau8HOI8W4SvGm2VHP/17KZgPu/w8oevTQzoPc1YHKG6CgwY8Whw4xFV98Av7ZOXxwDecMAGBb4Ez+TlDWoObeqqJuEFhbnDWzosYUuh0qaTeeEqOZ4UD9Tnvc0jAstUoMBZ14gIqLHLhGwLKs6p36gd4eJv8tGxwcCySIF/ZJMEoXtLj+7bPn+FHzbEJyv7GMSHay+ZFQ4+vrJtdM8YrKI9G7VQ2SRjGw8sx9iqnTmAmyM7XTX98+J6oH3WbBps1gENSiDynw9uu3L6uRmKlboom8/D/Iq+fd7Z3InRHQmm9hO2kjP2k4mdn30cReLf/6TVU+PFNkUBYLdR3hZcIEvTCJ3HTxfj3ZJ5fwODZLJvSb8J5rjq00Yf9mLfl8p92BQfn/02hqXJSaWHEGsQ77AD0q+3Pwc57d7q089LoFSrO1pU2/ttI3Fr4pTZbrSv8UFkd3Pbwd59EAfXKoNmK5NswYAguR5qm02wwcJZbCMlJyg2Xnf7p+rjHJIqKwq0euTaKn86D+GhNNKk3GzD8N5T6oGaTdk+1Yqj/6PvMtI24FVhuPyqbQ3ZQHQ40aDzqZ60iQY+WcLhZkuvfTN1UryCLblDa68kYb2dquUJtFMuHUMyenM+j+9wh6tuAZyxSS86Q2CCKfZoGnkQa++lqT7d7Byz9jjKwzjY4OXwrFlkXOMKFrbL4+BFE23AgNaFKt5WURoSxFEHu8k+KshHKCxc8bQ00qk5n13mO3a/fKumphG9IEmtjt/V1wFCO98aE2CcRskc40+8UahSz//qkZLD1RluBH1jsE4EAehyMZ7cVTnz42L4nrAKJ2MkWbLgq03wHPAWmheO4RzLrPUpGSbEvv0F8caNGHlnL2gz4s9IQsAXCJzHHtrgnCVhG4yD1fzvoZWlMz28kKvxuzHQH3RP49144nJf18FsGOjRPwCp2Nq+737cZFGqnNhoWtie3ec6IbGKmYF6cirE418AGTblLGsbojQDj24FFAJlYZeeE9Tabw2DJmvZk2q5FUYJJzv7Ui0E2xntclUhiSctNpnpziqv8L6CmmXX700F8tfh27qte9puucjqKcW/nPw58m4toIzgXlBHG0t3LuNZPQFlLimPCHcxOR6ftQobiYlGxasD3CTgvB6+124fkfsli5E3mdOvL5Ir+A/VlA34TPl/d3Dx0TAsI2EFEzfWF+df4db506IS55wefymvLLEq9BnSzVTveWKBSkEMEGgsXKE3R02ET489bAKl1ZWm1WfM85QqFcQuK+PXeQ4LoLgnIoWwNQ5rO2Rsrgj+vwugMjMJ1aA57g61PkqxjzVM1XIuXtiBHQApmDbnkRBEmX0ciwHxaq95AAPDSchMTl7w7QhOg0zeWaXI6Urph04pljnNZHfvWd9utKWaz/CEWNyxJjF1qL7/OeKUbV+b7bETbS7yj2NO96SqpYf8hblTKJX2hHhSvnXMs9wXquK4zZdlJkWLqzZK2nAnySUq8k42K8OoET9WF5h+qslj6/DF4qTPHDaAkeVG+VS9MinkBjgDSCnZsqUtVNFbDukMzzJwF4kM5Kf4i78xhhAeaBI8aWB1KiFae/sFV8bHRbi/iwB4757Gf0Ugj4EPsbMGUx+JBZrPDgJN+auFHckgID4IB8wYxKBsyGsRplskH4k6JgppuCIeF90b6jRGAZCx+W8kvRELuVuC/AnoSs9k0HX8iszrruBYMEfpebahhJ/7wae51aFb3+/HpFOzGZFr8wYT4q350TAR9VaSdu912jflUiDZPuEfdq/lGm+MeQwrlYOs/MtrWbRdKcbkWluhz8yOIR4wj1dhw4GfRivK00UxUt3ry3JGL/hgS3rLlWWwOp/CpC00N/hax8FD86oNEjeV5wHYvItG2VOY/+QHNOBbYXL351tfnaOvDVaRqinEGU+/atrDhGg8uxVDhe1THtJwklZdBbjC8ktbh7+ejMCjb97+D32ZJ0ciFnPc/MVzylxpFChf8Ybj2rU/LX7BdMyveDSGyzbX6+8gII2JhYp8Q8LQWTdSfjyq+SzEROiL8vVsI6NCgS24+YMr0t7QieXQMfZjM/beqI8imVBhukiofC+fuEvKiZqDlsZbxIyy0pdiWauehPoXX9HN8yrFNEmBXn+2F0P7A+/XA146q0nLEoSv8sqERN4+6FgjiB4+leElv3YtJ7x+nVLEjQn32uUhqH4fT32d19bH89cfUY/T6frGGFdZudAbp0VnBRkz2sk/jAN8dqOYS5Wv3dvEEtAb8BL6ccm3aPorhp6tpYB/Dg/InILzwD9xaq4otxSfiUgldfXGfpmnKkllOZ8f21SjxPFBZawSTNOo9aAtqGWMi1WYqL/O3f1YUQ1V+iDA3FTcqrAjp23kx/cXc8r/4W7S1zbHsqWsokECRGZkqeN9lBxE6x3n2/A8ZrgWXlM5SAqiCL+bzuIxz2YE+w+Z35gGkKt/KCdNU6E1kwje5Do5D7sRxXM99hkyaKed4irshUzdVCwhRwoOrZxaZuUmhnnUFfY5HvGFHOZSWxJxUIAyNCru5iSfHndTJ7cgjqu8/sbYeEeGGXr1vTVbi+GmVTjjbKjcDWZJcq7im9GA0Ht7WlDHMvbNJTAudNgvvHh0n1Z0xn0bUPHZFaq3I/6kHh8bCU4rKdeFbj1qqNXPvBmL/Y8fK7mUDks1kZDf372OH7KAYuSoOkhDGyv3G9u7SgZOal2N9nCsdt74wFmaqKACAzggkAi6hg3OYJVXR36N74oVC6MU/CSqxSH+gVcqznVNJVqALHcSlYrQ4pRr+ziv3c8Ud+cLrRnTta0x0uQ34xivprVSqMFovnjCRl4/q8vB8j6eLWCekLLnuacYznIzj/Dw0ijAOz0wogNOBXFvd7g2ZeWn9tc6Ot++V9q0teu7X0Yb5uurCbb5tsCZjgh2bW3Jip7VpZaCkjNWecVmHQXuA6adI/uO9qwpNKRmCOnbAkqvbKQgoOiqn8ZHiHhpgrtEL4W/hMbePXWqUSNcw6HfHD+C2IUgnUTdMoAgnWSqIRoaACeBXTuaECRMAbPlKwMH/fwmEpLDASGp+2iJklYx6y2tEOtUw63a+wtAJ8pqbb98OmbwS+fEpqrgQ9dpSysDh17LSR/gi+yn2AC0vTQ+HEu/w5M1ZftxC5b3YXxjdzdKLKioubFaeMR1roaJ8SopKWrdfgTN4R1Q0Ce4aYKgyisYynKANfDOLJfsyH8NRqrFbA4u+2m73tBsucltc6zVXUaZhKPOrQRucRN50nlNm3k5K2SHqdNzXKrNp+r4myYH1I+g06BxTi8CCThnyR2cN5WoaxIRCCEJvYd+Ndt143RexCp+XFy7ojvB32ZEA86shK9y1qgcCc/epsz8HCo+QpApUbmHEEWdn5ABRgYBK1vKK7jIRf66B2a/bdg14LPl28GTtG17k6rIbI15HE4uHhPmhPOsT4Hzyw/MPj7ojGQmF6U89QqicwBJqv2wu+PUkdP2f+kFDujjhQHVcYipzNzJ4/Lu9Y2VVefBROB83KCL+7RRthq4/VX2u5/SfFBuXrkahpfNILlz6fXkiTmhI0myvE+nuGwm+yf/4kFHw+s5BOxTmaxAH+sTBUXNXfi2gV8MhRaneUFdngJRrkaguemZhzUY/AkTpee23KZxVdEKwV4lnV57CTQxBH0jj98Uv0zXWKgGpSvBqYlnoQNO0A4uyYVOL2YP8plin1cPbZckVA0KRqYYkgkb1NFDfHWJO3+W2wHArIoRjEKBPHXx/W86DqRcvRGM/byw3xwxbX7GFa1Tj5EbhbMyv4n30ExU2KowmHtE0UZbNgoE2FKsr0WzYFFv9ym9KTgfFJaZoelZW9i1G42Bk9zWAcZa5m5daNaxUILp96y26HyPQH+3S1HTDE/60ixGgqX77n7mx0wZkTY+RMBXCSITyY/haaVQWVR2lNKFuQHJmSZGCaL5IzuXcotUAGpx1jZ+kjkQJh0GDChrNyshlJB9L02QonHqGczZh+bHGCCqvfyQDBGpviANWnQLMMzCSUoRJpHD22Kh+xeClDM9JOdn29XqamEXGahxh0ndr1bc6tSdN43AKscTEnTNdWfhWieZawyPzBSDj3+kwqOHje6IbzjTKSGMtgWMZx09spfzKUWJH1FPRgj6FVeyEcCMkCCbtmo8FQTewP9typFZy/+fYjNVeJiaHSe1MyoMY5DoABwzeocipouor1ovE8VqNJ+wYKPWtVfbu5tK1Pj71ATFtL6r4H/qW+9HXdJQB1zA1xIZ2AoclJypei3EJqpnM6KoYepbkXG01n0ATcndbSVao0rPayVvZBjIdm5IDISOEX7gcJdO/U6orsGEbMLQ6TtSoYAd/aukg8A6pRXX4ig3ZON+TbkD3+QIU2/wIPTKpIxPiKYo2rucEkIoZ3WLBp6HpSykOsVtoFMDs6jRwLYsyqMJAjLEofo/PJPjezQXqc1t0snoe93D4GHcBr+auV6KyVAPfoyC96qopid++V4umuH+oTBV1U1DCkB/ycPFYY6WRFlHoIX7uK5pGUlcgid3N0oAtOqyCIOpa3qe4a9I5nSu2prG0hRhSX+mlgL+2euGLUwTZ1hN6R99v8LUWeZhYv6CUum7+Drnjz2TGWdHv7CaGTe311WqU3H/QuZJollyy61SWs3T4XyD0Htjq2JLOruWzUszQ91EId5AEXVKbZLZVEEyRb/r6W2ve6cMF023gV/3M0Wn5pSBA/0UVJW1F/ad1vOVMIue3TSOVhlCWZtRHbYy/c4Dmq5zkyZn8nh3Hsv8BcOc+9mEJx3tro6nfWDZuiz71B5ua19fUwjGCbCvYGImZpXoN9MeV/0i6Txg0m/rLD1U6Qcp1u4HnpEryfe/AoAbieEBcE02SydThO1pmw7iPpn0FQQl2UHyeIwaU2ZuivV/utq+yxN1txEWe2KOX7qbl2MlHJo5fSwhJWf/3sOHwsqWOjFuREktp/KO01q47Guocl3TeWO0YUuTAmn9lJwYxApX584NUhgMDeeZlZGSlIIqCQQHQz5v74GgFNEp+Nqh4flHeVSJSvm4/KV3qTxm5mQwz8LI4PAqUvmV/uwud8rnl2zWcKJrQRl0S5R43F1roHLjkYQbX33PNct6a9g69QA9UPd0AHeAYPq1ihbjtuawvmw2oKKWA69uClIE2Ei+YEEg6o4YOA8ZzA5D5TK3kQnTgJ7H2VD1Lf7mcAXz2tVHBqQcoSFO7iPgRxO/BIdTiz7jvV2SFVSrLSkRWEgqi1+ix8jriQc1hU3uulxv5JfJY2euKXoE2E9TA+5pbqZZ59mjTnFdU3P2PhqS9SAfzK6Hx3bMDtt33JDGurmVsarXcYt2dRY4WdmZOId6PuCAEeOGUtl8ojCzVY5dka+Kc+5cozXj6fjoIq9vz62wF8IX0hi/tAVWcssGLOqEuFt+DKqwWusVcXSdjOY/f+vXoVE5x/vZ0k2l5w+tzP9icLK11UIWltOkz/FUInE9fs8QfV7o3g97b6BaPagmsLkD9o1X0Q1fItBoQYIWyxYtvvkVL0UOfdEliV+Amag1kxK5IVmz7adUNYAyQHKkpOdoAthCZWNWbqFHsBClJnBJ7frgiCmHUY0qd6Qfk8nLQIGCRugeMtkNm3j+yD2DMKuLptbTa1QW459t62aZV9I9kBsUJpxxyXjdEOOUjLbjDxC8mX81uLKnQls00sQjGwlK01m8g4Lmh1SpPDJTEM+VQOtViKVHunYdowIqTujuDYA/VAsjSi1n0cg/NxeSbDzsZSuLb7VYWtbFydv+22/K7sF5/eFvwynsQHhU53sKQPQdQ4b9kSyCKiiYz213bjCGpJeMa/wdz5jxFzRcDvlxDfLS0F0isC4ZoI9yHNCmaWl6RHIEpDn6kyqXYu9rfZubNIYW/PiBj3r77Jt88a9Ld9jAx9QM47WjJltXbfV3oO3LQiim87TB8AEju5BIhFoobZVLgGjhJX5vEOD1rAyCVDpED1WfbBhB8VxwJBqyNq1rHFEQypx63WWNUQLppp92fjag5bT1c7Lqnn0iOoq9y31w/rPwGK1sLMZw9GQzN50kqI68MTydHGmhk/tVjjpH+QT6/u4MeoSMjt01PvckpfzjTQ4nKTnKsti0tWn/voQAjcUBzw3b461xEX6jDhxKYPej2rqaEijf0rX4HLiwV/ltllz5yVWPrgb+KhwUBzBSAofp7cke9qeARz10+aXmszjZqwY+Hlv4km9olCN12GN9S239ZfPlPwhMRr+xOJBu9O9DZK2DkwNSnMdrBoCvPzbIeBbKk521Vr1TNtkiO80XS+mDYkLCbKHL/NNjUvK4J/FAA3T2/UAU8abS9JqwJ/0JVr9HhrcOEVJFEHlD3HITjfUoFpfiDCtJOA1h7ZL78P8FwnCJVtG5fyVwMGyG8zR7xA3khqPfiTx20ZOTXAEmhV3OPOtcuC1k0rNinSjvPlfU8buDWMclyonkvuThNflngFA3Npt6OYhinLOuF0oNVQvUGr6pbHuJLH4DLzNZUJkeXbyxgo9+xw9Krywey/3maLsDMU6SsJ7YXhsymhaaT8u++3rgLprGIb/BdTaAIlUI27hOBx0UyFhmPy0uXiV4WhOj30phZUi6WDGe/BQq7sbhkSq5PuRQR57MjNyaDBm2DY3Ej1irpGZsQXpXmCu0B3xTQ8HuwGUSETCF9vJW597itW2Sri6G3oN3M026A4jPT7GDw1l2twNJLm8Kwu5c+N6svIq1KeHfPgMN7NXz0H9PWqN25qUwXJrqy37SJhTRxJ3pSD5Ca5jMIeekMI+gkI29Fd2vUZJnAGUZHAqwlKrIRISJule0sDlCNq107btPzjT6OmLvsfG39pFzZPlG7Cfz4F/yTbJMI7O/+QUxI5clims55NQSk068PkjQBN3JkoXPNvZfCMXIGRlER+CSjE2KeLLrIMV834/6XFJaXwZtrwmu07EX8axf3iO9JXL4/JiDUuovw2l4tYDbSUIQvH+I5QEzf1VBn/rdJXR6DKnbYli30h2m5K1rvorOjDQCQ4GYOMFWoSK01ml0Dagkqnr/pvIkyR+d38PrtzdGztRcSJ/TuJqrTXNVZeU04xDG5yRGDBwMhP+t5wdjvizvS4ULUoww3CGWT6S7PMfJUdQHd+VAoSZeq820LBvE6/JcXVZLpnqk+BxZLlp8xzyxfNv36DGyWR+7Sbk+AkgtMIIt6NhUPH4zQNMh27QD0B9AUbiG1k2oRgN1ndCy5i0Kyd4NwX//j9dV1QwmM/X68p6sWLlgsuc2z6rAroGk5J4dAblE3+CyRsbkbX2wEvGklVNcAOVr4hmLKDfwOV9DSbLd4pVHz8diARQSha9lwpL8k9AnyA8MHRtYcSH84D9XrYse2mhUfgdJHuiVI5BowxXPKFL3eqI72e747mSQZvq3pdDI3JyKmy625BDh05SlHbxSQb/zINXGB1ppnuU3nd50Xp8edAZHJY55CkyTYcfaL0WFSJcV4GgEoondx4v78allDQky0yhI1Y9eBX7rZElwc6hQCqL7nxPh6XykFO3E4porhd9g9XM30/cImHEp91Zv5JnMK/Jp4CZhn5y2ztl13hZqRKCSIM1IDeoyLKmDZp5BYYNTpZiSueciVzvwZYmfkl/iqFjed5zwM2Gpc2ixJZjlqmtmMlKISoAM8P7xWqEuhWgyNmp9br5NNRWEfQCg9bf+nrrmxZpSaQgEGP+Poxmj6XV54RGZDb+VzbfOavWrGJthpBeZAD+3bVWET2nPBU36LrhewmjnINNbJ5wQRerfheiRnjJ2h+f0R6fyxElRppOahlgmtSMpKWIHxMKt4ZZXxdpvBstjl5oTeeW4DLr0DBJq7RAxW3kffb0UnnxvZ+VjuXL4/2YJEiD1XAS2rImDt/rfTOvdGlKuW3iktVCWrOLmivTIDq599AuCdDSt+QQYwR7RVE5RuZQ3qflvfCDC+vE83MEwqpMVM1DM0gGdD4UtredEkztHvdInVEDfoZOqsQ1vFt52znVMOE+hUROvLKjBPeaY2sXrw67UYpj/gAk0OVvvJtIMYZmOFwl5qixjVpBO4bH+gCrUAzmPWC5AoNW2Udl1JANizAz4Hl0QI5TxX4VFynuJW7CXoM3T6MCtKt3l5UIiRO+1+XFUPomGI6VRR2K35mwifMiGhglH7KgzkFIa2D0ptyCC+JBxQlBBwoEsS+Q7TgbRTdE1l4Ot3IMG6xXoXemi32g9oAjpk0ZfCPmWju7jBZbmQNUEaXFTSl173gBNVLF83Ltu/q2Dh0rlQaBxUPja0kg4KZFndj3dHiCh1KAjU4+xBoMuMePGvQ6GsTXVRursCvRx6jvYZg3+AbuTeR2SyW0yI0DT79462n5x55W6Mo0Blz+F93CUepb1AC03aLpWn+y75JQYE2/IAUCu5fFSXdwnLtwbj0Ufph7g21A+xQgI3OPdk8pm+NV5JVJ1ygLh15Y03w9dtsjAfiQrKP+60AnpWkAe7fHZQA1p6Ga3bpJ5B8TCFXDtpFnMZxYbc/OgDsNSs7TNP7CSSKJE87G0zIwvLK3ZLd/diolsxtwLPmjkoXbSvkNReDe8tPK7yRHceIkgml/D+kUVyYE+wvfOB+0Sj1F6+N3fURiBpCw8QDVRP5NdXw06zrQlOtNyo2JxNloT1jIYRdY4v9VcTKRX+5z5l7CBfnssYJaAYp3opKw/miOHhOvTJIRfkrH4umdCnzqaBrHJEY4sEDGQqwPole4pZfnTnwQPJZ7HQ4SWWIBI+UhxU/GG3lCUPV6Teo1f6GKUkLwoby5rQTQtAlA2Z2s1LlzbZZh3VgylrelUksEJxAJ923ObKQfD5vPDOer0jIQRe4BTo/kpJCWK+59fq8oTx0qxnxmhFolwlGh4gE2G8U8gIE2N+wHe0DZBSZ773xyknooGgazKHW3ifS04wN6RlnFUYH0DU+XHrCgaIuAsLufFrdQ6m2pTGfzlAdEQQd+AKwT07hdYoFWuP7vYiO88mA9JrfbwDZeHRp9MhmK0iv1PQho7mrxoprb4MquTJ17GU/UBqXwA71bLXO8ZIdiow1be4u/XRK9XgGRabYRTMxhYct8rhmy0uN1EnJo8Z8e5ETg1KeL/CvNXrmBKyGP92mfAW9kQBjTjppk9Be7u4jZOr/mGN/+TtUfyxrqaR+az6tWcJ4fuxlcOy2uuSP5LgEDzkAWLzpOQbC90b4BrNJhLC2Zqg9oDPfpxLrOdkcFRyKrQQ8TttmwI8NcSjSBUMxykeIfuvddlHbxX71DIdblauiHNudNoyA5pELGXZJmgUWCR1vyx1iunofjhHtXHrB+9e5tRZuH6A/p1j4To+mFR0NGc/5T6oPMeuHdXepO627AHr2wMb0MQOzsoU69nwlL03209xvU4Wl4j7v0km0FzWFgb/eXbhZJjsqdwIrsJ9w+5+0I85j8Ebvq/xN+pcx09Pr7/ku7ifIrC33TKxAJm/sfZGdbrluW6xGYc854AFAkxo9srJqeNjhzwRnHtBrCZqbVtMAKyE+fJG9TKDuoWvelG/HteQZV6blNb67KyORgyPXtJLdl5xYb5eoXo0tHwMzR28f/B0oVCk7MGnTQl/DjFHi1/VAfR4RSLrNmvNwzdAVDYuJJgwHIAdjedXpgs6TY08jHEy/Z1FknstSI2IhQpeEV576n05aDZioE0ewWQt3qUcsM/FFyUio2ZULEBbeKQtF5tE0DZr0XCoEaNI5Za5ync5JxSWIFkUKSXEuWhzMkyyJ+EnjBg+E5q3s/Qwf5xbWSlLV/BZ5x+kUZnjWPWjzaqTwcym7rJEvmdB7bO504C+ohqFLhD1mhbOqn0dhYcWcwtYfEfyAxlFQkVnZNuseL28sLYC4MSQevmim7dwC8TeqtoPZ1vf7ZaBTYQYMRcaz74QMBMzLPKK3GoMuwRQrXBa55scV3A1X843JF9gqZyufrma+eS9d7wZYfTblr6nLhgX2ow2ul/KwqrzJCERsdMmQym7mnwV/b9Tt2XUnzXlGn5XbrIqqRMCdhgOuZnTYUY11DNKCYqhzO8WZTZe7ulV/2cqrx5CKfMfrt4yuMNpd+vy6E3d5nYXEld6Yr7nfnjTMpgkkxOdaJhzCTmwzsW43xQDcVUGjKAyIgOOs1Qh4fkkiwue+rVwXn1tR9kpvRDktWmhiXRZiZFnTQ05+FEGb/lh78mTNC+bZ12svOza7G4JkceXBKo6ZuhHwf1fx0ANSVd3oNY1bTWzx26OGSiSdY3Q33csqTTTcqiyRnE4+tiEKjxjLaoUESz8gBZ9jeJIkUiRMINNaMHqb7/FRYTLEavPWzOFUj+Fmycmwv5n0k96qZdMCYjIxZy47JgmnISsoBbbGLqX84dQg8msLahOZSe0LcGfbz6m3SLNxYX5rN23ytMmjMbUE52/LKR1i1H+A/jobmW8i0NSQiaS8cjyp9Yp3dMx/7dm6boiHZrukvmSRvPqXCJtT2afM6zb8iU78yEGSZkW0VyDzb02rgC+PGkwVsnOO0lD+ScywDg+qk7v1BuM8Y+UJ3EqHyjMr2FbNxKr/ts6U2hcxeosgX4h1i6KOXFjVFf55EMBdR9efuEwID/5PsiMNIgF96rUEsWBRU0Re8DhzuytAqozNtAxnzUlDLSlLNPuqJJ5F3FeHCrm/m81Mg5IVf5DvsHCYhxQ3c6qTfo9jJDKB+E9MHHESO3CR5ZifZrnOD2rNI64dDjg1puVQS8ijzUp4sj/Y0xBFff4dORdjaz9PXPVCXVDsV7S+SH6jllAxot+RXi0XwxU5BVBbG0fiT1GArxwbyEMsqLEs6szW67RWUriYSBwv6JAyA97lZ5l0AF7b+ODt3G7hvWe84hVSfaIcsgyY+KL+zyc64Rck96T1HpL9a7agaMkhgWrcWmFym9S94QngC6TFf5+Tp5L9zufiAT+0vSQvjJ65GvUTZxxIObbdsh28b35geBHLG/9itmSiAGP9DyG34r3DSZEPu7yLcqyHlWIaoZxBFpsHiRns5erzW7iRx2WX9jPLe0ab1j9BB1HvJWpIgQTOONiMdR94pW+4hExitgEcs29B9wRfChSzyYQChFP4s4ov/Kkr4tvoiaSbZqRoOccz0f98PuEEhYTOulXax2vesImHRo0TyXAS/sXAz2lW2xthZEfF1i8e+z+1zKPRloD0+3vG37bSHjHEhXWSY9vhPrRVDYLcO44ldUKBFCX+vUOoHYD6tzI0r6i109iHUz5ThluS4K57XR7JAhvDJoToRXOHyzfm04mFYDWqYbxiDRbvWxXdq9fNX5150sh3nEz1RiPQcQmetnIlUycBslj4XG3pgbVoeW4s4i+YvgSpGqPxOpEsb40ypogQczzAO6Ttl9hxczjqzlPbGEi4D2eS74USMIwMf8KH+9L1vDU0QCekSxWSigGxFyGSlSJ+KyM/XVl7h8e3y+dwucxnGkY/5Pp/LH407aXTSIZhecRJhN0BUGgDJ7p1MRknms6cctLKbz6m9yOr2roprlSvBHJGgD+mYsDHhAtNb6kfu6FAxc9rLeR/ED+K0ijEM+3Dzf4XWcZcxNENf6s4MygaG+XLtUmW2MMV5RdkEbOnPBKWQKbRhZ9Tf2tDXLDlwPcXIVydODsspoFal6/g6S1bWcHtfNoPIuXymkrxHC/9Mw0p1flLGVjBS8RkktbWUu8g8hYYUpSM9khQBZKUZbmk5Ai4ysAvzrHVVzq+2wAA5xV622Lh/f87/amqEtpHapwygv5oWGFA5Qi2R/aLUUMU0sSvXf94UidtxHo111/PDwPcLhOqga57M94a2JXnnRj/OJt9W1ahCfGTwCMC34XWQ0B1t5tdfZJcMYw+nNTPnGJKcj/pfOjar6gXEYzRkfFqLUKVGg9VSPN4vEM882+uFlr1WMIFtC70YtjtU4O5BR2ADDZZVEgFYIj/71GUTE5y4Ncc2vFDAVRWPwWylRLJZaGg1xy1L+diMxiHoSVeKTyihHNaP0HdxdErfBpfFGhr2GJ2cspykVWyaGIb/xdLjidryCZRM5YIQtGtgjIZwJv8SCCaCDV8KiX/7TX7nxHxESLA0y49APqUdCQyWNFHAkltDXBW1AZ8oo94HiU1HxXdfos2serNgpvJ2P+hIKaTcubEvxreFA9dFwhxpO99vu6fD+6PoMCvyoTD3ToNj117HSPddlRAcqn3AW2FLHBJ7NNm2iMqGD0vazee76Z0MX+dXEvVEqazSfo2348ir1Ojm/28X0dAww1R/8eiq05rPg8hdLSd7fjOdiHZ5/kVl3cdeg61FYzUy+ZeEl4dk0dI38jO4ROjeQIsBxCJOgWV1mIyTA8YH7L3x2ACV9WpwKXYy60pFgFshPgxeRnnYgDMbosz+JHL8dw9UuXkX1zDzj56eG87rRNzCXHGerBdpmWuHw9OFyi6v4Kbb2p7/55jeAfFPblxDrVnlDMfHVsLJ5ambSY3OmeXoG6pT55rAYCL9KIzoAGqsJoeXDLYbyhBJ6svnmuNXclMizZDB9tXPI+AHF0wtO2OPD/eCPFvls0iVOfFR+2p0/+HMvAoNYLLtFch5h3vZg1mDDqdMISTyPOAdt9up/ihO+jAr9TI25j5bWtYCNtAac6vq78SCYAVwh6bK7B+mDyr/a1k55D4fyCpbSwmWsS7ujpqCobZXIRvS0UWE3ajwAWFYeW8CFALYPuptdvyZjjygnip4dg/saiGKKWnpfKSz3QX4CF+AhfW8Q32f5y4/zVF7BWZAPPc8ot51/X3jae8p5A/h5DEM1pOxDgVv4MdPWYgSL8u56zhsZRA8bJZHWT9aMK5olV8eTfs191IbHeNzp7LPpFgq7hqgBztDhCq26nesbW3e6CXryuwRaAmqcfrTsQuGf4yVcEQFS201yWh5EDYVHGutu3UpHBg4U/ze+n9ITSQzcB7w/L2qc7FDGHco3JI0147iVqa7dRwCePUyEZlILloIZABxw3a+narjaNUrpAeNaGDPB/5clp+ktzd9sILaTucF8FYOakNw0oxa+XbuuCrHn6XSDQTVkAwmZTnx4c4KLTFwJc8ctLwkhOptD2Wod6OYuWP/z1ZTnAlDUvXYC9bjJVaNZeVc2fr/WFw1xHmTSSg8fEmp9CldT2H0IxTOuXMKoqKQSUtzEPmy3FqMW8sb2mHCk/lvB/Tri3IcsDJhyTqjlTnGn/2c1HPpxrCj1cU7lEgMjDuLB9oFoOzzTEp7ZGq/3MJ4tz+i2Cl+4MoGDS3UD4Yp5I6lwGJZHUkVRwno/X6eFEvTdrqhcvHUBoivr0Z5UcJSuSKWjhUwLwIQPI7cqQbsv2JyNQl6sYtNBQvOonUOZv777b3iU6EMymsrFf+2toUqFMEPLmGxO9IpiJMbVqjeyu0YTmlq09iV1RLu8Vox7Ijoz0t8s87f9gEBLyGQN2/Ur3xKbcXrfIB4lu5b2GdADMbOOVMa7xMf4I8cqdQq/azo/lM3ueI1VPTtcMFn5LufU2Md3CHafxUq50Vk7616MZ4bJ4ALeJB5Ayw1s2wP4k17ezhzrAXeAnFsnLqTUKKbmfKmFM8kSUrMKjG94i00dWHKl6itknkkxwN97eBGwGSc0qguPFXqIhnCSYbFN5noZ7MLraqlzwWhxq4cDoDAVSkdFhm/j+q/IrF/EgqJiWM9VJ3jaiwtQMjRtS/sp/jrP7AVWwUfunmEIX9cawdjLrkuA5bYVNltNd25w4SNZt2RYEXbaKTE9DVzuqrQaiFtX4ptFh1ySJe0U7SUlYYnyTRD8iMtmRo9w9M8GZDBAvqlPhUkwa2AAAA=="
}, le = [
	"data:image/webp;base64,UklGRgYfAABXRUJQVlA4IPoeAABwXQCdASqgALMAPl0ijkUjoiEXfLVwOAXEoA0BDDVnnGyQwL7KH+19R/mAeOX6lP3G9Qv7i+tV6Lf8Z6gH+w6hn0APLh/d34RP7t/2v3W9rD1AP//st/9s/s3bD/Z/yP85fxj5x+3f2z9kf7H+z3xTfxfhO6X/4noJ/IPtD99/qv7b/mp96/2T/P+APwu/pftc+QL8V/jn94/sH7Y/3v93/pr94/y391/aXwINK/uX+u/w/sBeqHzb/Jf2v/Hf9//E+gh/d/lJ7h/Xr/Qe4B/Kv6H/jPzg/w3zH/lv914jf2H/S+wB/LP6v/wf7x+Yv0tfxv+//yX7xf7f2U/m/9z/3/99/en/Wf/////oH/Iv6J/rf7p/mv/V/mP///9/uo/+Ptg/Zf/ze59+u//vSSGAvlu8p9A8VYMHDF83WYSzclnYCLuRBPvu//Pf3n6bl3CtY0CJnlDgq6Im6bwlS9l4Z7gEzwVwN82WWP9MnmossAGwjeSVofMQRuLR32v7hAl/9gPARc6rd9PqtAl6KHax2PaEEEHO5hIaVArG+OxKxdFoz5EAcCtqqNbCeLINUG6RAflT9Ad/DxZjU0RgZfuEBkg7tArU1fWkvW2trsP2PZ6lHHIK13M2f6/Z09JYjbcKGV1PPO2Bp7p+60nV684ML1aqSsKIeQtkcq41V2AQHqblnxWKN6F7/NG9GRuaRSXJ9X3lavNwqEVAwgUFuZZsFHSMdDV8l79ZdYS1ZYjNW28/hGFBufHtvyFcVpbrZ69hmWSGcoBWtsS25D1xbhyWotXwvJ2oAu7eb+EERpTmc7vbkyLFH8LA13NvXlmFeHZ77Y8coPqTCX7e2Q0MNV7fT1Ara0CZZvIdOA82QeDO17z25U1V6r49Avr3YJuZlEQMvwCWA30QWGzqYZwgpH0OwsJqLYkvLsLvTvNRTIGtx+ssa6fNEVZzZb3owMZfSFUcZBajkK2xHXxSS+WqNTY89DPreXnqMQ/dyVKWnBNp8ylKYQAA/vv/KegF4/sXqcIQDKB0oA3oi72igZV0522j1PUw/psPeQ99YF6ZzVAAP54IKQtwQNHQYVdYrmWbHAuCSOn0iKmgnnj2f/Zxfl74SW2PoMoSrBhEH51J+P4EDwZBppa3UgTPLoJx47c3G06o18txJWnjDgY5FZC6TQDhKSbLqAEnjmD+4jfAnKFUm/kdUczd7JnIna0KjuFeaFXaDSITJcgPSPB9A5JM2D6DcLEJL3+4a32duw/ERPsncJM9QYzJbx6ngn4jFKgkdmaY70MBpGFCxn1tdGV1aSYiNxBxXjczjgbqT9Fb4oovojWqBKWsvZ6hJhh9mTxmdGlDLBghXvEIXbGppQ6pXcwENJPxA1Xke0sVvVTCmykN3Gnjwy11bs6xQGnxywqGFjhBUGsu4D7xRcFrjJkJs8YXyoB/AIet2zfyTtC7kVrRYvVoodeIRpab7/mPQRq9DN1gcvlMEhoCLEnxtJX5sOn7nZIPpWcsyJfHpIOR6gUQ6Z6DfmuSQX9VgacMZg5vmMUe/rckQfmT7A+tZofhZH0yWcT9nj4asN1ajj7sfo3RPjAmZcuvf4H50q5owX0JFhjUeD29MJVnS6S1l+cjH/qDGPaY7ndK11rXZ9h7Wxa9srnow+BL1zfv94iRsv0l+P4wN9M+zu9eF3tLLVSDi9K1xHfYO9p3j7OgpyyRbed9fKrDCd8gk7se0PHb9PKPWAtNXxY6GgZlJsYhyxfRcGjwsBGOlcKNED4u6QyzsjCixRISTEjDx6x1g1g9toe+kcoOUz4cFeax2aafpHJqGE8AxrmY0RfbTPwVInnclGFRZ+YISmT4IcEWjNLsGhGVZvw5q+Fhg8LKlbQ8U8Tl/Pdbj3WOKbom0Sq2tGr+gQXWpFGNPPTxTYovxrST5MnYOivGbg3ZU2g9gR68amquhj3/p3a5orxtRXCxJH6WXZb1lKfAzlUvjaodW5RlD3gEJU93+669n5n6UADhj639KLd+oNgiyMJuBpZ+0ecw+0Y081rMJaSkjc2D1c85rJq9SL3ryobzag46aqgZc50tRT6/IcfX4tBgxZx6Os74z7Y0DfYpjixiluy3VyR6Dwb7cm8rc39g61WbmNc3Zu551d0U7ppIIWhCoM1bkUDq698aO7SQoIo1r44/HE/bSrSRlIeUyNOc5QvjfTYUG7K0NfoeWqPAAsCP3O1p8ZhdQyRq9YHbJYPL+IrczO7UQRaBTUnYbSVZKzHfvVkWtbJJTP6eauqrYlc3ru/Q7ku1A0qQHABJhvjsSoM/Fk7Rmw7UcKHIgkVjrIMOB/Y5Mflflz9MzNfsBMxQJxxVyVzKcBALQ5M3PxRB55cAGp0hSFG5sW5fxUBTQZYmhJsSEJJRd41g4AcuYXAmzhUNTvOIRykYH6JzBaIry7NjtLiVZZweVYuEcRynbmWPWwmvu/qurtuTJjhAJhj881UctDeF7exUQ40el2QINNbMCEUKhD9X+dbrkszWf/epe8FwWtueV5NkcILHWy9+wJtzQL4RAoWqz0/iAYfcLKm/tWOsii7f1u6pZ+p0uhQpvIOohj0q1gV8Q6oItY+nY5Fj9O9bDp8HATJW8QizkbdAWXlT+v1M4IHnfMkwyxFBse1/F6HPfWz+wqb+PxVLCOXy6Vf+bkJS9F9w/SaYdJrJsACjFRNJdc6W6wNpXcmjIfnNLTUl811okdUMQpgEFRWd8gyMzkuIWoRKRsOIWaJzRBtLHyKVdfWSL7Q42G5DGj+TAfsIODtKghruG/F0dkgeX43C4iwKk1Jp7mxkn+6Tt3d4GYkMI2kWMohIe66zpeOruF3+vwb2cKrXcqnAGA7CSKEM+yOvIB04hjMo0X7zcLyVrTOKRhAMBAHvEgp7KH+/J5RJqww8OsAIO9AfAo/W5QjVGwre+6/zTW8OMxdlwhjGFWF0bClEa2tB8ar/AeKDV1FdPpFX/ZaURo+FHBGVhrp3V7vRkroFJz5mF4ChUBfwusYffqcGUMU5Q1nETjzsrTAah8wzRreBrEv2sV32ZOEfnm/pshZR4PQRAUdRBlwzaNvEOrRHH9/pHozBbIg/6R5AJWM+ftulCSDoyD9ZinW0FLoi3lFUKGf9B2VT90QhN4ftj3Yi7fGbjkdck+ror3SBJISle2o8erlqg16b/p3xSzRQ9CTWeRrZUA7WY7faDrmyHzLKqFpfnAyhPAOj/5+rxePrW/7feAGrVOn3PHGccueAMxyHKIdY1AmINJGTkDSDB1ZTzcrAg72PT40Hxyqr71pYr8ipE3PUeIMGBxF+YRwApG0Di5ErRl94Fumn6Gbam6UM2Ptzz/X4iqL+nq9J7SK2rQe5RHdyeRHhsZZgMmnrnzz9MuO+sET+4s5SqxsK9yqYLKiZ/UMCJhqyEa7DS8XD87V7b7OAOJTvdSFPX96bx5AvaQ8gryesxsbjvm1P0gacFN1kvD1e0cVuuOeIcy1fJDn7gLsXSMRFiaHRhfq5kKWttg+S8i8ea0MmAEaCHu5MgyKl0+EA0CznT1TThbVeH571gxZnvFKn+ni8xUjZPip/s4wBch1+rig8UBmIWrWuoK9weZP5TFCkRDc/05vEgc+72W5yQBQff5REcCwbin03NMgX+wHV4dGbEEDNkT4lq6lEX5+IN5F2V28SyHJ/inwuOXvvQ71JQJuyyAnAp3EBXYBtQtJc9BGxDfHxliX4Oh5iDvj9RBTMNr+JAvxoJPJDNecJ2k0QOvSDZZ9uM+2yKtKrdZrVyFmZ9ePX3nwHc4sYb9H4BtPvKosn2jJupQqKt0/Qq01yJRFcYg6mSxbpqDbVOqdQzNUZZD5pt9UILiPoWSfoQ7nC7SUCLF+gdi5jcRb3VehHy1KnzyJm3xrorJ4pUV4IyAR2qo0LcgH1sQHetynEZ54n9Mmkxxht3QHFsfEK5dErDjcRWtjY8bBl7y+CPRuXAqZfqTOXoSD7Se0HnS7yx+G2atQ2Z8LKF1St190+xEgYr+Zw/6kCkQSRc+1eQYbs7sBLj/OEdJETrNmyhvDNkdcOGk7Q02HyG8ulXeu7Vw8kpq7Q9h0fmtXXJtgCTt92j5IT6BC7VvqvWu5gyYn68cSH84RHs18UtbYs2hF4QiYw/On0sS2s2pUmTP40BV1CUtYZrf+crBw6atdsIB/Aq36mjCf+3voDjAmTiwkNbt+ENwIdv+OFskLOylz+VJRGlQOmFJ57QjL2vr3OHx6mM/AuBJEwGWTO6YrOFHf3V601PCgu5lRhjaJm4RUkJP2WP//xGyyWkWDQEgxonlK4BrX3ccdh0OctqyyiaOJz6z6EQ1+ostqmF4m2A437DmSOYuhEFFgELQjxD07LWJKcOF2bnlDt4U3dzB4fQNjlQnqMgSEWosKtODe3qrDT2CiLWVLEdrrWTHUKo2Cr8plRJJso8PK/5HIAWSLbi5VPBYU2eRN7KTYTzds84q/Ty85bWmOAKMTFwGCp82gTDUYJxvuTYKr/XrYp8eVp7P6g+f9lQDhinyfCrkWWznP2p8tFWjZen23OJraNXJ+jDuaSZMuC2h76KeDIM35zGe7sfkH2tLajX+fy6CUxJfQx3tH/+HaFIp3870I/VV9TTUY2YlwfAHCct18gqycKmRyatbmIdH+Srpz0rlL4o/O1oSVMikeRdeaiRrs1JUd+ZiY6ov2CiLAksRMw/ICV7ZEAKk3Eg9PWmt58BZUzHvaDP3gscOz5wCPKSp8D1GD0jWUutOpErwI4TBrKAE7P0zitDCJteoVxFQzSyV70UsWQ2/5o2sztlb2ISH5su5v5Ardm8h3S+lSCH57UwANtDyM5QTG81OMwiBwn9iesvVMp+pIKf1KmPHck1Ce3cIm8ETMP535iVdomQaZzAwdOSconCOFaCdnEF/lrv57lKjqV/O4l1wRinftlatx7g1r0VocgyfginAsbDTH4KY9kpbfGhK0472E90oE14LH+w7YhJZDSGD7QV1ldHjzZ6kugZ5WBmLa4ihka47AlA7HlXDCvrYhb6w8v3DTalqWlHceZbNaV82xPZsv6RPD2AH/IgaWluAWS1h48iRQw1oBDZ9Zmhk9ngIauBSqseM8lgChRaPiY7fMdbwCxg1S1EIhHVvGqvaagwb6G2Bxo+vvMO76+QiXHvmDn/I8eBZm0oyJyVtaikkQI86Wb+lPSvNXs+iS20LgwNzrxAJ96N9GhYa0y2O2wZwPkdb/8VWBTHAqKO+WDaPbksCQ209Pmqrwk+kdpaJSgNGL9JADxX27HtzXNWq03w+xOko59Ye27b6oirk3ywoczTUAY9AWa7chir0dqfGU9D6BupnSp86c/xAulDZxEW3cfLoyOobzK8sO3vqNn9yPb7xphZv525i1FYaQ8zxk/F9hfODgm5WxxVxIGWUmNtmJg6yt/D7UnLoMN4t2H/N6ddNlrdl9huSkKuAW8MUhg/+kHuqil0oxQd5lMgdP8YFRr/x4U4jcf5IpHIW7Xn6XEYwL+9AswQvA2t8mNx4iJiCa4tAgEdveMQqODaxPa/8xBJa2Scrh2rM9HIL6CHl73rEzLb3HnxG2u1Zi/mS6OodPkYuK/XLFaVkiJqz04TSQj36hpzvV7g8YVTatmYUzYAELfB26WClylNM2RNt7V7JnXXjJ/mAGdVAHXG68/9LWA4X9x8i1mWlBJLhmennYLrHhhd2fCEVXEXrlt4w4WTjX18hI3jhybvgHp/NQOJI/uNDpcf+1sEk7fOm4e720rbjT6kF1B226eXm5DkhZimHfvF8xCp4oLBqZxAkGqt8Kr/UltEXkjtpradqLDsrt0CuO3ZqKj0DOpyki+pwF7WNEWuBwbRcj5LCAVB+Ig2zuPefBmq6pDQKc3HAX2FjuQCawABPVnRPDVUuMi8PMDqbRK6aVWZEcWLWasyrgmeoxj5TDdCAEh/zF3AYWgu2bhxZuupsAQrg1WbE2B/a27bDs0W2eCBReFAyTllENVT7gNJJ+1CM6YEbQEex40tJ/T/5qd646BeHSwIipbTNBmUh2yxdV7KfJG2eKOflnnRhLIuB2b21lEvOsOppeeboVudwf2leIHaSVWsjQQLLqCwoTCmV6uxKckYz1UbgAkZVSreuqtQDqnhqKM+Vw9mCQ0DBbXj6D0wslahnRlL5KhgPnn0YHcAAO4bZzksbuHOEBUckAoERbdTEjW6RRX8ELBGkbDgm3kChuuPUACihf0uWKU3Oqisgn60GUB9SYqYmXjsWgjXA+MPyo7DSdhQvCjFRpdXcc434KFY2W62uFUUZFz9jTeOVI0XylcCuVarPVCuzns0lyXCbXguIf8ebUZP+cIc4bpnyH4w57SSyxGqxoTBkaa1I2x8dficxLAXZP+bl/TKaBLJiGwj/uYIQmNYp7Snc/A64tVJgrGG9d19jtdaNOWOitqATw5AzwmG09o73VV8/WeBCFNEvZ9Za1aueselUY0ubNvRaFpw7ODo/uEeo2Sxcj0xYt7s/DCbuTqQP6I/ouN1/VdlCFEm5pk1y0CgAiQDnb9qxaPi8B3zuZJWbyhm8SQRI/UpcfA5Em2YVGiJ6g81XQiEiYgtB+ZDvL6yx0ooP7hFZPJrfrTUh31FnjQ12JJhPgPVX7Ob6vvwz0riwA1dRRpLTl1VRYL54x1Zi81T5+/1a9KQR0i7cTtTlDQEjHToBNBIAKNA16yup0xh2Azg557sc1SVP2ZtCeGA98WR2PHs+BaXoZNqFgU1a8EvpHdar5v9COT8HhDwmDd32+V6qvX8uh6DDiC7LRgm6ExgPaSVGBOTo17PqagcRwNvc/MNIkJkuDF614CJViTNTweJtRRGSs2PwG0+7lZfIT0is4npJoq1RxF660ardxaFhyDmvFN0fuSVjX+JzReDola0mDQ5yypEfWBrUzzuch+EeN2/I+FYP+dgdw3GJXov5ndfsqxaQQOufqBhFprnRpL/WeKIpZalVHbVOkDFqSSbePvCVfrLPFEMrZ/QA/plW/IVhQym+epsdm78e5YXPLepSFyXA8AIcq1ZNhzyG1+PHwsFE2zSdRNrOOS9338ygY/iMyJghx7exlVEYUYSBq4xCdhRw5I+lqaA9ZqSCJFb9gkJV21ls+ZCyUthXKDr4r2QdOOIv83QCUXat2ddWTAraiMrVp12p0bSgPRXJ6FLvZIQcqj+xUjW8dSJF6OuDINhaPboymhdEh0k1EYwG4YhLOlkQapZMq0G69/TlssSB9p3ylO48Ujyz6uFN0bBxT0jWhTsUkFWuektxwPNHettl0XDj2WuO+Lg1E20XK3DH0Z+yDOlxDPxWGi/icWKT/Fi5kDkjH9LqjdjueH5bVB34mV9fXT1ImxBWOzbSOqEdJmhP3BJaxAP/+L5AIgpaJ2Aa1vXdhRhU/ZgBa4tP3pwvasr8kkos6sBadJEkAgMxo4wV06pHil+hDiDShj1azKj/mMVCcGOuMMObhFZGCwZDzyUJ8xi/5i+aSXN4xA+EPWqRlyeIg7meqF7NCDooWWQRzw2fFPeqqIlz8r4jsi6W5nJTmqhLOoOXS4V3lm7o5fBwQfUg+BQy0ReyW8mNb/KzWTeUhftDh6ndiwfowjtsdu8ApbzB6OZw6PsM64HHbBPB6iYj5MtKXvog75Xkj0uJPK0DR3Vl+MBaCeyshVtsThZyeaugp6LlE6Vq2mzbFDT5o54d/ycFwn/l2SwzK0T0j9S/GtlDHgjobqiyzuyRpEUIGjR4El43YH1QVLnOP9EajIcf5glm80HElVKGfM9ZnJ582JPU2/lJ5jySwPKK55P4v1aZmGfN8DdLXhlYNEDaPK3h7+fheW44vo81bqLYV2q20LSV6b0G//xTC08GHDu5dzux8Pg/wMNJsDf+j9/WWF/CL92F7sJxEMJUWS4sW3pacL82Gq1GIsPMH3DKwE0XYMJ6UUTr9aO2yLdFRbnUdhMayH4hY3o0HJkz39sFslsMGACArZsD7DIqiKHrMfhYerlAmEtgAVcjPP/wTmOQIiFy/ldhQB5CZ46l490YBM0Gq7cKLR08t0EWmGSHRgXTvgSE80u4R8RCQrWcRutd2thp++UlZAFOhVVDi4X5eri/xSTZSj+Li1kXWX9QM5CGE9xg77SXYP1Hh1yyge6uL5rQsPtthdbocoX4pDjAEr7x/HMU6y8SJ6CIUQYr2RHW1cunnQfMsGKzQkTnKqEbAu91Cqv9iIcsw80FZhvAHyoKVuLfIq1mJQcya1p0TBMh7MZQRG9YUS4XDCT5C1M5fka4Jgn61IyZU0sTtmiT/VoWMkLMMCAZ4jIZWQfJGSr/Hz+KtqUzbmpa5gkw58/oGJdEDdQ1dc7whZ5TyXzUDAESiMHj8DdyUlCs49wzqqv6PBJRNdg9d3utlO6lCZi33vFqX2oIWBrZUZ1+0GYSCi0WohMMRYMN+fod7yXiVpYiqO5e3kDsiVotsfWD4NLgH1QyHZE0Vo2dFv86yZeyI38ouk8FJBlTn0sIdv+bogMwroIOR9bC7foXM+ICPWQzNvF4DGcSh6Wm9vNmKddkbB7afJ56Xu9aqf43x3KIpnWckrSimeXJ07RxJEPNIsPfDgfWdXkHMjU1h2fgNDtTGCXhAW8Az/XjcQtUk2Xsdbiu5xM9WOrmZCAmfTfdUzgFy0LCITbd0kkyQDqbpoEXoFOFhoCrylaGnkQY7pRuAg9+TWyF5RBFAdxK9am649AH+YhtM2l2GPFifC/PkCcJSEy0fsRsee0nFDqsB3tAA/6od4nqfe5Glj0D+RKUmE4d/42EAd475YIzO9+4foUbZG7SH9ve4fSuU1t4Zm1wJdE81J0lMo9QpVCr3TvnfsAdScuRHjUhWr6hyAgPLI+AJkDHbMmu5gl/WhDkdP8E57OoQAHFk25mQDM3uOHbNt0otr3FUp5TJQ/ubuXwTMuwya8gaQ/7dgit2mcp20Tf9L0Yap2gNWYMyyrZpodHsAZVEiN2KghzZbmt+CEccVw9qFPkEiUisi1ACo6CqM9H1K7rMVcIB1QebkITpx0MMXKWM1QP5y5pEAaR0wPdjPVNkQUdgGArLbf40e4YT02o1VEowCoN2NS42eH3wC1hO9Jmdboa5Ax+DCBHDJyBpI8Sam+TB5GJTkD85J3zhScf7p2AMeOpNPBOKX5EL26WIb0gGzW0PAPBODhmbp6rdB+TOkL72P8N+eBAb5mgcvVei4hPMudiXHTm++mqAAfSlzI4Q1goWZq80vYDC1QQl0Dkzlt2n8SrUHnE2SEDtCYRNZjxmQUCDR2SIeD8d8HMRpZ5dPcvbuwX7AFpYpYMupusuEHGzpvVfjWH40vZcY2K+3yCI8KhbWaj02z94hfyY2wm7KeifVIpZf3+VkaUizuMYX7+pHG9Hffz0Rk0M3RmbDtks/3yl5qrk4wp5xjErnfghMLEISmL5p6N/CpwIUePRhuYAh0zW93VEaglKCS8E4mdmmZKWi3CFc9ja1Pa7vdl19GtmQ8VsrOBOi3IbTqg5pJE0gYSTBvoGLUuN5tV0NozzCTcdFU6KEOhK+R3sUm2rR2o0ZBDK2tJp4liWqtoUxjAvr8OPx9nFr7SmhCrxHbL9VRRbWhY/noZuCx4cAvAh0KxJSdzanc57OFD7zNHnZLu2xzmTgdGhKvFmxK+FPY3MrDWtcoFpMe5kAheSvELU7wxxbcMoCrKV5ievzx322kSlxYaRdtWbFGrWwTNhXOMs7Qq1Pa5/H5wcV6BvQ19VXpsfso0QqyQl2YgeZU07vmP+3F6xgctH/ZOwvc74IBqB+u+A70B4KEh8eFnCqCPLg98tsXTOMO4J+8Vd2cpnw+1BII+d4+czSQieJnQjRVpFp0EL6ufl4NSUalQXJ2EbuD7MMEVMEioR+9Dva11IjBTA3nV3NlNRaT+H0aHB/y6QLakMe56Muyv+y7urNoMI4nzokoaDwpApXNpJS9TbICm3mVAhUVJ7SphxnZb8hKl+9djbkv3XdQm+F3MIejDDAf0OdTYlpIqBUrieVsVOvTfe+LXOataopMSM3xa1nQoTBXUkY4ylzlRX4I0keUdgkiGdKbHCYMg5sSVQeegyDQtGiDXaSDxYxHL6SQlu9dEIzz8ajjzof0bgEA+fXibfdw5AHWf7knebbRu3cI8aaOv8QKkeN/JKAgR4Ow8R3swcO/GFSH9znjiYUhX+fACxfTd8gxhrqmi7tBVJu5RxgVuPtVtmHAaZTwvXFOLwPO//pT85dm3+PXVxSCkO1BoBrWdmZSqkod6x0/I8zNJerGeK+uNKrUNEe7MKwAnM9xecvnXVu0sBZv9pzMnF5Hs6ehF30LJssQFQmwTdBDFOCDIj8n/KsrvGOEMwqEd5mxa4KsMVLn+V2svsAOqCKR4NgLLEWto9PncNa35FcjBnJ+KyZcvH2H6uFZP1dQTxtqsyImmZPUB1Zkwy7PzHCch2XTqo7Zhexwcype/+M+r9oJxnWEhr17dc71i0Ha0K9ejVe6iGEB5TJhQlTcvw8EgJ3KpiPNYwkJfss00ph4qa1m/guVvEo2uqixM/eOs7v7tyTm7+AZFHEdJqcsAP9gCSAAAAA",
	"data:image/webp;base64,UklGRjwcAABXRUJQVlA4IDAcAADQVgCdASqgALMAPl0kjkUjoiEXPQ1EOAXEsgBqJyM/cu3xBV7LzVLO/lfyFxRFj+WFzV/u/7f+R/zU9FP9k/0HsC/rh0sfMX+4fq4f8P1ef2P/QewL+onWl+gP+z/puftj8L/9p/2v7R+0H/+tZXZZ/evB/wu+i/2X9tv737V+Mvzr+K/6v969Rf5F9s/zH9v/dn2i7x/jt/b+oF+Rfzv/Ofl/+anGbbJ/o/QC9p/rf+m/vX+A/8/+P9JT+29BPrh/tP7p+Q32Afyv+ff63+5/vD8af8PwN/s3+y9gD+W/1j/ef4j/K/uZ9Mv8//5f8t/o/3F9n36N/g/+7/jPye+wf+Xf1T/f/4D/N/s/81P/59tX7Wf/r3Rf2J/9qLqTgBPUSG0KsOoOhDkJT81ZnIlQbNNvGbuNhKVNpBdOQikC281+k9uAte9Ylu5JEIv2pPj8cd7KyY3hb4w7VfF4+UO9Mhpf9i1bEIqn3V1fTNuuDrfzENlSPVCqINHkbYv/jvK1NY/UU4fvc9Fj1tJJ5szzeoD7BAhfcQnlbeAad1lZ4Q/lS+Moaib22sFNhJQVGvMsh+sAGBULQtc69vRn20Snmf9zPiUDRpnW1jpmJE/ecVLv+hNa66cY7jrUvgGr5tLFz06a+WOSiwuRGL88DH/zF23nABg9RcY78387LR9SoA2zO5iadDWolmijLz9owS0/JRkIaGnPN9CudnzTue03zOUi63orNJdc1oA2Rpi/YN4nnhth8cg0X//Akw+HKLGJ3+svRdxVIRiP6kPPvN4HHUlsA6M8Pn3OZBFcrz/eQ4Gx8VpmT7s+enwLJlQV6XtUsICZUenA2xXX4c/IYsyBAcBL/kn444Zp4Ip2a7pe96SqvK9cgutSv1UeQ/MfzEJ2FxassxchlsAdFGjnYDTSZ5aiSI0ssIhQJEUkHyUAAP77/yL5oyVIrhRKpf39It8Em4oOyiARnMqBiXJAC2wLFW8k9ec22o8SZcQXv17KAtUXQWwfHiTdQ2W1L38XGkAFqN75ZxLzOmU2pDuAIu8g5mHcug+yCTJy0AVJMw3IkaHXIMWbnWjCMZzt/QaFLNv+iT5giFeZP4vqBnvMFZQtTLRREPC8UGBqs8iwnN8e8dPpaRcX9cxONqkFvqfDK1XME+YJxbd0/NrbsHx4glXnsRT6r9PQgzIm6Nhca8+p6H2EJBnpm/BF12y7Oc8au7ebKpkziZK3gfl/YHGY7HJV0LtfCgTLlCNTr9YkSUuVAD8f7x/oTAXidzu7n/xCplDIn0NYMO4OFnxI8fYf1CX8y+r+u6pRbZ/pKSP3ScchPPVsWBx72JdjmVwpNSF5fPqh5yegy71i0MTtI3xyaeATLaJFYRsIAagf+MmyUiJVVd/mUACMCYNeiIiM/9VhyfQpQflyfK1HqNi6Lv/JRKrROdFUjTTDPyMANaKeovcC7vVFiDnyRJzlEuLVF3ASxMGwOOvvzvqHA/1Mp+0z71M4rUFq8suSuXF5nlqe2S09/Kv+BQ/3bLGaA4TrQlTAiYi+UOWqshKRNQPbuzTYm7v8Ra586L9i46ks3ByIbXok/AJvdeRAy8G+DAXnu1vp1N9w5XnoaYfH3RXT4/++E+ckxF4Jpdji0Ec1rDSsz34igaF7Gn2Tnx8Zucy8Y7oE4vLhxW4hQ4PhULJ50uw66BBt6hH+ErxpZQdLMc7m8LbQph7iD/FuFtyqdfOQNflrgM1gQVZICnTCgdviJB4yq8cdBrprCSy8ClXOypG61pELjKSk3kkuvDfi8uGwiM430VpNp25nyTPMpRi2U1WmB8dOOb5kfMYLwQCaUO/bKZ3GukCohs8Ab7mJBHaiMCXzZWr6Y5crTNfJxni6Nc3//k7kdl9EkiLGfR3B8Jy/+48otVZTQaNP6oWu10jB03wcali1fzE9QiYRlSv5zdO25sn2HunI9RUyohWc1eI/H5W+/F/e6uwnMCJtiMFu5G6c8EtmWpTk82oZjXQ4+mjcxuuRmJhPVTFnMPnOsBBMHlF1w34+CGLSWCDnUINrgrbGOidGOQI3njCCCR5H87bvMIbVT8tZDpV7XVSQyDMxo8vz7+MYPm2ouvLZstfvtkj94HU+0jIgqCWHkH7eKlZMrNT+FA0mw0sGrTrpAIUZUJ+/EUaJaMFX+LXjq0SADjMUrAwM1d+4bGi1476X3AbwTP4qJrLBbmeebfLrsL2rAgfaj76Wlp963PON/yIgAScoYhAVCivXmix9sakBAA55RW7UWN/XkJHaS/n0hr1RexAQ4eS35FmIHuKlt2bm0dwjGjz1kdHlYd+ZS/15Il1NpyYA0ou5p0SNauNstIQLL68f8ar6/RWlfafPIFb4aNypSzaWT0xp/YRqFKeZ8Xv8imef/DJLFMXSeUL4MLl4klyrkB5GU6We/jPMBdDFRrHvHgZpZzqqVYCbFIYCcqVeSIpDEoqsS9pgXJCzc59Zi6imJsGkQSES2m/nVdaElwgYxPUk5n6+rX6zzVAnc4+Tbuy54RKtanToIccezspXdNXWsk0P1TiiweJgTJSb/jLHSfhhum916kgGzxcf2HEYJEn+RtQC9fa33VREo2opZ+4czPl25f41AzlAo+IcM8LHS9JYWMecHZN6MKuEymQRMdTRFGISgGH2HVITvU5PQHQ1UUmTXRNQbE3+woVfByRnS3zO1AxtWZdeXZpV+WrhXu9tnFURukz2HPMpo7nudE3Y057xblp5ldU08MU8P/LmeA8E+U8i1c6imkOr5aZ9EIGT8OmWdg65q+Nels5R5M4sU+kebatUCWZkNbAoOy70s9RSXD5ZDcgSI07p5u6/vMkG9rWtipQUeCu9NZuZFviK2jEWLiGBUczip2cfRLs7WIio7pDosDPLGmIr57hTdsvhCK1vVEM+zpvWNTQUWny5OjeMnzCXJcS7/MpIurcnHdTUErt7hVOebARBzE07ZtIaoamLCb3L4wWOtt+jCrlhadtMzj4jPskwvS/WJ6Wnqy7eAbEyXFfbNWZ/abzjQuh6yw6Gs6OQ+ZHIFPWCWTO2JCvnfkR5OghiUnUSzFDB9y4VeZp2TGcnSeO1owWvpogifO/el5+snnxXaVN3oFdlZpxUKDuT93VSPDBj6SRkgL1OeuDvcJQ22zCrhYm/nvfzfbk2nAABbOIz2QLGRF54vl25WSf2G/qDgn+FECwU3mC2In1Bxe/V1wTFkpbZAwy0BUcqndasazLZYx0RwHd+E3o8eUdcIeFZUEQWtorhTLZ2JWkYJhx6FHt04aKkH8c0ozUq34C34J2c87iqFzXSNj5neOT+hSwvpwQyqaZI/T4sf5TO/lhb26ulvulrcbiTRZR/AZYz4TeBFKG0okoaKKF4dL6z/pm4BlCU4QzBhO3TGs3wquh0IHO08WrSmhBQfXIXd3Bk9eMWauAUNJPOMktD55U0wQPlB+jeZkD1aBpJNzJGgR8c5DUumfYKL5/iLKqtgsEPKDOL00tQ2fYoH7r5mnJXBSCG+aJmV4BUKDr00I9+98xXm2+9ideVPzOKlpnADE2iPZ/aiMXC4hT+Oy4Cwg3CtSSyUbww1pjlhUY+Fd0pssWqvXhN5HUQCbWVA+x2tpa8YlU7awXo5GfrxziQ8Mwn2KQef8/LxVa4/ZdlWclQceRyl8Rvbm4Xz5lJtVJS2ly2WBGFdqYS/AxcfmBrrYfBT6ydQvssKrFlwkRBtAsRJYv0HPD0k5647Csmea4UfWyAmbYjgYqLPqoXvJpS3/t4bxV4dhpzIIkm6RBJlfARZiYKYMEU3Sk0i5BknBH1fQaSdEE06W//CUtNumqWzjjioD8GD0BPeYSjXfBdjPfDMdhD8QYHXnfRhbpqb2D7ub351WnGsTU3esPu+uatonb4mwJP3EYn9KGudflyfJpXa+iKtWXZw/sZ1jftmWrtK5QhzGnN62cbM46hJXnEFemc1hYZi0ITOuNWL6m45Ku4h5MRj6rYfG26HY2umnPzQQCocdF4GNEAc6xiCYNY3DJ8BD3s0SPdZ43PRYwgGEuoUMdjifO1XQzuS3ZsCSZvdkf8d90lU8lcTYtXHO3BgxbRmM0EGbWsw0WJL23plf7waE+tM/Mm0ctApj9DRYMAQWE5sQb+sEP+iwtGLGld736zOyO8ywFNZHTKeyjO9jBSnVbppp3rteZWXPgSx+qQJRIoMAfFMEygJQ+2/Km1or4hSHnuviwHrhOuHwIGTthsRzq/RWP/pgSwzhG1IlXC9PMPErk8kbqsuFc+iNM5xVeR7a4/nccxXbKgEdRTGiobYPhnRcN/UEamqJh+o0gV+9mftLumtSl8AAM2a1kQqb49SggXY9/0J3c77W8qgpihLYTzeWSaEygLEG1nYY5T9lstmQ8LgkV7KdHjYz5rGoz6xUQ4tLhGr62wpBba2MoX+4TAbAQEdRqdPNavGPADR4xFRvqDupofuiP0rN5+vR1J9He/6oBx/bSpyFQvvWoLLgMXm3k5eIA22pdKkpQZS+amgLmbtkxbiy849V6gfPgOBrHAYhqYMa6BBLMtJyS84btoeXSqiUq76DoQ+ekCoe+wVa9zxZtxl2hZaUf+mL0I7PojQgT12YuRuA0RYWVZOecl/gKY7ZBTBHrwj3qpE6wjnMwPIAyK7wB3prTuEeZHrS5Sk+YWs9ywgpTuVZHUlNupnG77HO/5lMJn//qZ3LDbTYMX8YOjmMnQ/f/fC3RJyLWsWayyddVEXHkuNuHYJB4Kw3aZ1ed40jQHArWUubxOZbkhDnDTKD7Wpb5+xehwX0QYep/xYFLkQbOe7trgu/WQviUg5p5Lv4OnFNnhThPxkDb5A0InzAS6iQFpQMQIIzG+by3wYWv0DRbQjQQcajqLo3XGzhHnkvX9vFFfjDdyYLFbm+jDvx5mymSdYsygLf3rCEARpDOow66ofcZtqgZ43xHUMVbiQHXbHLoJn/n/4xNO2us477klZU4Gnb2EMrcEd77ca+IuQh9yXWS6y6GqbJMZFMs09OkJhNtw33i8COXNfeelV3Fro1wMf7nClU9cAqzBsMQByE6NDqRHDPkO0bKjmip9SBdkhzrR+MkKZD/xMR8gjW4K+KjkyRj+UUlPR7mLooz9Ou1wzwM9AVdyce0FXJIDbY5Qn/HM8kITzJysmBjWi161qr49Yi/UTgD2iuXsEKqozz7JjZezcwH4ieF0BMSe9l4Br21lgbydkvhEbI3lED5YYHBEkY193XOJMTaUj3/G1z2QXxfsM7UL8Cs1IN09eLU/dGzW1E+Fmgj7SRDxbZqkvLzWD9PQXe911hBrGphozQo5Kvdo5PmOSPfe+1MEcqskREOv8XK6Qn3c2ogGGnpfxhKAN3xE0ZjsYpijrDy27TLWvYMhanHtfgn+ZndFujK0k8vfskWE4nA9PdbKh74jmpPW6/lNEXI6HYHVRtNmqleAA1yFutsjnXdzqMJK0h6ks5mSD9s9wWZZA4hANA0CIq/dvAUNk6iwdpDxwEtc1K/ZbmbnvWAogdspLu9W32LBx67jJocf6drQbCXtaUNj5NXmIxF2dMvHl/cNGs/xgFpKMAnYS9WWpuw464JUO7IzPmUjZ1CuJZxZf9MLa6Xeo91EJjIZ8Nevat2JCxp5kU7kkcpUHvWM2/AE9hWgQtDZ1mbuNE0flWx/COImgKn/dFyU9eMBVtUPYGQpeSX2MAmIgtiQdQaKpiZkgvpCXsM6wF5+hwOm05mXfy6p+TJlXw8xbosyvSG7ZOjREYYbkGkl+OGOmq5rDWj/XanOyk2t+KJ2KQTP1UPpW1R8aSfFPWmq7F/CHaAeFC0+iM/ezt1ugDRdvf5Lm7h5yfbVAIZtCNmibrI7u521lQyXvxVIG/yp1Cxbk8O1hMZbR7Invh1vPnsmQjxCmACJjRXj9grtOR5m8uo+3k3tgW0UglecAruqVFjRq3m10bQXM5LEP3UCnbYICVY4Fs7vX3fyfzpqdZdaAojQ3y0L5e47HTcjRDemS8wUV0bUXQDg+HphL3pOjcFY7MOuY2tLeMSKN3rsKVZaBgbPEL1m+gIWDpiqGvuWliyGSmDblctfY65PBwcGwqyBMdbD2+OwU3j33dbYmAjjFIWfDhfL6b0DGfEP2hEnxgmP/xiy6V+m53y3tVmaAEN7c8qnX5eLjjZxecKy9fuMlQ/eg4drXXsPLmiIvPMw68ayAfSkpA4gXROT00oovCO9yJydz4Z2ZTVYrVVEelfm6o1OqHEWheO1h4RZo0dbq5ltqgt607DCMkRNWg0LyJHDmvCld8HGI1W6TA5HlxkYfpy7z17cTaFgi816iv6LPjQrQaGC4pkeFrPgMI9t0erRTkZcVZckmbvHla+fuvI8G5CjowY2LeLNPTCUn+YlYFZyFeOso7Mhie7xT7OJy2DGUTAr8bSbrIryFrmprggEgKtrG24jYaW0AADTs7hxIMEh5j3e3wg9Tab2LBsghfLxHQp85XhCStb5Wfnm3Eg2N9/9jv/4SiGyARNqMsz3J6VBPE9G4swesSrA92/E3UmloKthypol+PfOjcPRZmgKHE0FxS1lQHTOcJJDFUUJEfiM61mQ2b0S2BoXtynOUCmYaZMF/fvYM/0EShAYyyDk2vVsZAI0QB9QWb/VyzXhCqvo96+iEin9cZi5eFfrx2ptQn1ofjAlS1cZT8LgB2PviWGkOwsGSdrtme8x5MQrL/V/2NrY32NIEznz1ZnRqXHsNJXDaF1Y/r87gXDB4IClY0/KQoABpF+MWZAtMGMiHCQ8GpbmG7gmyZ2QQ2lGGD8YQu6rEgf4VmmrklqWCBoC5F5vHAq274Y8PBNUBl0P6KsrETDJ7moeyeLaBVN5R6mZTjmIeqmuAzX+CUlWiDFdAw8IzBBhsSC1sXJLUTAlbQIVESBpb/BABRvwBTiVOs/qBpHM6naloEIsptpT0lrt78aRXNdzPiKWZB62h3IVGtGKYtaASLuQxE3dPz/n94Z7Ag9BuuTmc3C6eSNoq7kLyZcKcAHxYrcFCVgDzcNLVLbexgBF2YRLVWCsI/5I0rYp5h/U/0VVszrf55Zmxhmothu+jI4lbNZwdA001beLZAtoTwY9fEdDuW76JKz4RCqf/HcPJKKLNOZkG+IllBrVBXnGV9J5covgnL7xN3qQp+JWrmYEqImTMhyiqoSobtYSMXJRLUX7m/sq2r0GSprVVo7rQnIuP7wA7KHbRJ7U5uAdkf+VrdOMuU4PB44UP7tr9w/07lTm5ZsILZ1ZurJieGlYpgflDMTVRR/x41Pc7ITqOCIWdWS++3JYdnVpNC9uUDu4WxA4UEyy51YUhZHiR+YMtqSTUAQabI5bWvcb5ALGEpJEn0yU+ASgeVhjGA3qwtpUzxYYD1CoTkuavtlQ7ARi5RYUoQ0RcqLPlzA3+4jx27UZA8mPu5gc8qdX7cD69mFLmJq9DBAXsQAIAKgXuhNPffzW51rErg9Ys+rqK+KK6BvlOUJAuAkQKUbUfXGzAqNw30yf7JTXi994slZbgW3H8a8MxBQ3Tf7cfmdS4BXM1j1Zk8P0ivciYAhDqZkXsutZox6i02TKS85mD7On+1739SU+BGecKfgnsl/91qSMYaSQE2dXy4ZnG+dzIGhWBeTijcN9vTT9gxujVf4iZJ7biJp5Y20RgtV3H5c0duet/48ky/gM+ybzQdr1XWp33KWcW057y6slqVSsdtEZYMj9UbzqmCNmFJEmYE4ypzWZ6UujKXMa3YluakiR2l3f9V/uKzAbLX8fOkHGVseKVD9qlc2PRio6CqexCt+KwxXBD7xJqXr5cvCsnEHc3zVdIBRaRFml6qujQf9Wr/o/MuYd8c/XRYkjWZegsZPzfes60EBPyKrvhmR/RGPcGJic6yrvpYMKab2MBT5QiQHRol2Iw2gvRnDMvmUmpn6Ah7ViZRK/zNynb3SOe5S/pqBfcFVCrhYYv5Bdcv0uyTJtwB3+iSIe5iFgV1vVHe2ncZjCB1GHyAKLoKQASj/4GEIzG+BeguZHWaReTeSiTXiRJHtTvBHsJ0nMdxbX/2icz2FI6RkjbjA2Aq1/Mrrxlmj31hObzU6s4U1KeewU9JXUFJJ3I/CQYGpoHSXNVubuDrWmekM5RUm5J+iI9qRFt/X6nsa4sgLMVFdXCm2iUopujBcfS/kYaY+ONAcWWJU5ZM33AD0hNGtOfvzWAVC7nOtepf+le75od66yLv/NDR6dkciLGm4xYEfmmJlBwpRxLScxc5y+VBhMexxAclpeT0XGqsvh3kx/zfaDZKcAuDGbb/iqyWgjguDKy2qf5NN9XGcJEtXWtiuC0vJd9xCqZt1ouwIUfMsMK321M+9PQ7Z6jNY7g5tyfAXXAFW2MPJ5cWnXc4Obm8Hgu7tCdzFwAxSA+bbmDnDA/z4h62tU5OCdTRSIawRcneYqMdpk4MDcvzn8RxAAOZESwrL7mQzDEvU9xuteEoC0dIyfnRKBq4Sjpvi3JD8Y8KbzLpedowXGat7+p4IVFlNQvSwqIWIURwh/v5htaTTq4ndSKZn9OAFQga78zrurNfmQ6T5j5zwPpZKwZY8K2h+6kSBEQ89w+9Q1Igel9aI3ISd0JLy5yz/PXSg0Dl/RCykbK459Rd6ocSf7sfjqBjVaeRAGcOxbZJUjnFId4Su1ByuJNU5eEtWclj4tixZlRtV1KyC8XxCKge1CaO0u671LaImy7JW2bCS/sWNfPdsay0O/Ro4oICZ+27qs6PLIBVJ1b5KNmAD/ha5dGtNbbI2Urby5luRnne2uBPzXabk7r+XBZfP64mwdx8vpG/kG7M4E55H5bkLl/IIEltwCru9Iik2Fx0Bluhheq/pEF7QGDiC930FnLxRRpS3UmPzBA16DmJT7J98yyaX3AE4/HdWGWm57RdVdtxMbka6jVuWEF0BA69HCtQtGYXs/rKZd/sZuFuHulCmt7/0I6J2xVtifDx/Bzak+NWz048vCLC7HM0uPjDMcgIgkxLN1FW9snOh67YvbojaWnjqf03Di8N6OXACNqFcA9Y6BdGWAVTPcM9CxRAXlqD+wMvjfg3sOa4oTIBINOxMZcG6+O3jD3yzBOCXnnjrKucdw7d4UJ8mvykQvO2DJP9FeQt2l5I03L3sziBov6C7kR0E4n0hqPAg2T9DUfxcqLeAmDE2zMXaOpDV0oNQbDdCjodmkcIWovj82UIN8TY4pmEbLd73ykoHGKcK2DMyRE2+GCf2fIP3333riYJTnrgUB/84qT/oCek293rSwIQqggwAfcImCEaP8sZejTiM+QhaITO3EX/YTwb5+lX2fh+LtcDtTPgEWkPkQVaHiijf56JR4B8AFs8BTmkP0OMskNL2oKx4fwMBtygQ1YJVg5lPv/K5Q7g+JUBpesl8ou8jPwTyZuPigcLyMaXguoZoIfK7u3j1JM8DZBSqp1Q3d+gZnH0fWdS4a5wqe8gLDoGUjohBcsYNnadTLHAL2M0nm2UmgAc0RvF1sDhSiHGqwQIGGu+Be4bmvg0podJcCgZC7aGb9+s1QJyI45WLIiMFup5V0xorAMha98GLltEBZeKvAYOWj7/hgRDMwxcvHn5wxn3Yr3bhgN/+snTMafnLnndZKkAJJGO2GEQAAAAAA",
	"data:image/webp;base64,UklGRuYdAABXRUJQVlA4INodAABQXwCdASqgALMAPl0kjkSjoiEXvV1IOAXEtgBqvREu3y0/Yfkz7JVZfun9y/Y/9v9yXZr1d5f3P3nV/zf65e5D9HewB+tn65euN+t3uW/dP1Cftb6y3/M9UP90+4D5B/5//wOsj9B3y6P3W+FD+6f9n9w/ao6+PpP1Yf4rwj8Ufpf9u/bL1+sifWV/k+hX8l+3n6f+0/uJ8bf4b/YeBfxb/x/UF/Gv5t/k/y7/Mv6k/p/+B2oOsf5X/gf3r2AvYP6J/t/7x+6/+A9KbUX73+wB/Pv6p/wfWn/Xfrj5GH2n/f/st8AH83/tf/j/xvuw/z3/m/zn5p+zX9B/wP/h/yv+p+QX+Yf1j/j/4D/PftT82P/59s37Yf/r3UP2V/+6LHRY9HFKE904cz4lN3Yb4Z5huHO+5n6l5fCChHdQcvSGEOL005EqiXjdV51EyP/DtpBf8LHQvLJX47YFUjQ1a3TLZ3V23aRCJB6Ep4mgNDBXAoTrkLx5/Snk8/D6BoEHB61tfl+9B/Vad6ORi+vX4CizTkygTTEZAEAomqivVPhxWYbQDb/g65fm+3zfTi/Xwc2M/1Gg3MzJ+Ykw5jSvIKxwUg3Zblii/29CS7wY8wNVMXPcnUE/fy9guU10kV6QMOHZ3F6HnPuL6bceoDa/6E4TLLu+l6cQt3fzyAFGavfyKsy7zpKbeCTOTMtyTW23t4L6jh5FEeNB1gaQGVI+OvRIlghFrg9snEnj/nhnkMLb6lwm6PpnvqmL/RrAQepqeH0DYKUvIow6D/g3J3fbo+Pn2FwvaBE+DIeyyCMv+VpRGPAYJqbGlLXzNv/cFLjuondRhHGNVoehTjwWtvk3EoYm2xxUIaPwfISBsEkOBzO9Xo6ftYCCfOHIH3gq5epZAQ70lb/rEcM/zkKYxuS8Zbk82d3Iyb9gRRzE5k02+IxwPdkoSDjUU1ldKGyDKJ9Pvw1QCVT9EoVF5GW6QRjwIxVpidrUTN82QYcxdTNKpW4eYGBAjHKYm0og0vRV0aYEZnqVtgAA/v9dCL+uhyFYALpZxv0tPhsJxMppvBZ8f6KwRcBNysM0nsjX9E3dRh/NkSzXXdkfxaZ/kmD6E93uie9seFeBjiAz5NZmEHwwHc7LoZNDHolUZF/Mk5IZjV04ZftZlP6CdRYsGB5hx2AgOvwMF0yvxQ2in0yX+lz/TwNiaWXCKsErzaEIS8w5lM3AYXYCoB4rtCwfG53NEVgbjmXrO2T1k/iZFOjNkKggIHrY4saJOtxklT9gJy7lJpffXkrtLonbVHSqAIlcfrUPwSqD/mLq2Ik9usTdexBdW71xqQeV9yroGm4CbKzpHLHoI+ZrA1irEVj7CHedcfT5Kq6enquC1nbUmOV39hhaN9tV5iDM0DHxTuHBk7FmJ9mWN2hNv4uUyEuOPZOGq1OBvYWUnjfhP32adBUT5L9F8ZCzrg1dEXaI0uLqE9K0D9cFNdp1C2mHLYpTA7EPJOUGygru/B4QhYrRAwoQK5dVdtNr34lP3ao856whD1ralb5XepKXEB28D6ALxkz0KEJyPTm0jHqtt2G6AjA64uyxuJ+QC2Cx+9nSOSu2GkUmTdFoJ/gfS7fINNbx0CbL0XAnyK6a0IhPh8/7SeAX5zfJjIjb3w0G5oqhno8xyu3JOey9c6SYyUrYK/Sq48t6AYpaRoS2hykubS1lxZtGgIOdgJOb8MLde9HdE8avVhPdtj4lzkWGtbfoDsdDsguqhH3v1HmFGpsp4yNt+AN/8rKpLIG4q+Mj9yGkSQwczv+WEUnbYqc7ah0Ix2V5LJYUrGUz4Yq7syhbgvTDmF+7gcl873VKUrJ4NeDEX1Ou1seKvYKBrH054CefK9FLMsn8HkkNASqDjKC9fHtj+jhdVLw/PD3GhUiRm5wPjPWuNGzK9y8eeSNQ+hVuWktYAIesrp+as58nJQ+UvHJON6norsn+PtrMe8quwcXwNlNE3OATPWf/dODwpIkmZ9M+91LALsGqNs3GwQydSZ8UO3/WFlJNIWtosyNwYGb5L9easeqqctO5KrMGylKHsIPcCnxJFvny2TTuRL3gcsPtU3FdUPUd3/Wy7toD1GJpQzIA0eKZPygKV6IgZh8xuACcir3WpnfD2Sr9fBY1vd9HNvFM9qdElVbaUEMu0oZGr2sDl010zQw7ena+vSm1f0QI0UtPwAYIswBBTvtvQMHgWou2y8+e+U3Cn94FHmSv0kvItNMywVYqywMkiCn2tKJZnFexhZlBXVF9pMp175Dg9ZrY+l2Dm3QqIi2Df8pz/Bjzum8FcFHusZELyCTCOj31v+rEE47ZNiWk50hxNyl1A/7MmifMTeHMOILi6RFcLERO04ckfp6+6t5IoqpjLQ0uknfTXt6FydiiVka3cqxYRiaU8CyVJh/iKtDjtGMEAE9qe4NEa8CnFh1fwJOyPTT7Xj+SivkJscyXllGtQxet9OZHQu+V4A2W5BBz5/uGif2t+YIBpz56JkupsVAroxKIa1S878jiNgV939cqnq6iejAVSEH/upNpulcsBkJTLsibCL/Bn2rJsRfVRjWn+sc+NHH3C09USjmmaIyEXskNxBFtGf6rj49pWqH1+UDYOqQb6w7ujZv85iFxZ4KAgAWppz9nXSPC/54Bte4FfSSVvTjA9jxuDs6IWlxLmnm9ig9UC1TrLAICTipYf41tUQQ+VBM4sb5aEtWTStmceKRhwjZXeim+QxN6IcMVro/8Rbv0Ai+F86rrH4Z6xd0vdUYLjcQ+S+IFPHjoz0wYxfVZPgd9R3DB9p9d6yhAw+cqIdlB4thAQHmNdu8f0AQcwlIeuDRG37UgkmmvD9DtvKuKs8QBgDqu0e+aGQ77kJt3pG5NA+Sx5iSWyUj6V335NQqYhxIsOSwxk14txNc/zQO25BKxJzIKfLOoLVasJOkKr9Yg6Ns57JSMIOJXjFAGtAfwUfWu9ORQn0I9J0nqIZvaEBNHeR+VeatNtiK7Am223QSYdzdx5BZvVu5k2m7QA4GjjzmPRKw+UPRdl7rwIxa7aXWjWSSOp8y92gnPbHhzbML53w53QirNvvcGsVLjGsyuOkyWkREInjfVDMRq+70Q8LK12WcMvmPGX6vgZxGtkmM7UL+s26Qe8ZHqddtcJcr/PA9v6U9hojYwf8MPWxyLtZpLkVpVuEENUi8rtb/kJk76F0h/e99yyfn0QmL5QfwtbBWapuK2ciMzv7n/Slg5eBzcxiKwfDqlac9y69B1N5Zpiv149iS8OGH3K8bNVcgBgBVxeZRG/0tSLbtEwNPm7aFKUIQ0nJr7XHmFXpDZtQ/R1R6mk91hJqQI+BrHwq/xk9a2CW5UVIWM5Y++oAnHKcWXWEl+zIwojhdjIlFqPqqwGnpabRQbjeB46fz46PFPNRHVACRVaO2522IVppcKDHu1qjnOHHr5mbZ/N+sGzko8brhj9QXxz/W+3GoM5OeeOlKvasNQX8MY4MRgMsTP9Oyf2ErJivarAX+eNpAoi3IRPwdQruvPEd2QqihQ+cnaMXBWMBAfD8oGxrQg5y/b3PGNdUxon+AYJ7C/6gSvM5ZVHEovjAwNUg5vpvGCJ5ufTwlLD9IvbF7Y8ItWS4VWzNthzW8rkpdiEcmoRfovrE5NiaZ2eDJleAwO+gcP0JldPuvJkdklTrJhvVHOr5PwR0V3CKs/TYkL8PZar4VDisaNMlw4ffle7olaF88c+R9YBXqOYsaULd4ZxIVJMqXjICEucCrkfmUonoC+aTbFt4be/wtjnGgS10GrSPYySazpLNgv0jIKCEkL4x9/Fqs0rG5HOc+U/nniNK0GKkBtj+xsbWSDfCS5tCWUORy+N2dSRBJ4iLOhTH1g2Ez9pQ/7bx6xNH3fW06l9+A5AJnZozTT3QIra22BYz28QBNx2VvNtUdL2zrTh1HJDyFYHFd5EkYaak99TXueb0ec9fXLNRqWH36LAL46V8qRD9mDx6xaLC0aWOC6BCCKd5Uf3dbROrbF5k5j7f6WB2RUoaptF3ngPy17pz0YlHasl6Km85P2mhKDwuE5PZ1/O6gJZIg4hl/AFXkt9QMCxcB6tZcXJctgOU+OvG+cP+SDANEOMm3RTKPq9D5xzkg/KQiyAIwxU2oOf3QOZJ1Kn+1TS/a87JIqoWWOxY7tlmSFPnDUy9mxrAgdpEjLeb6RN2NTkTZfLVU5yi1ESsXLRdQtr7nx0KxLdtAmXzbyTYnGFxHQPB+Ot4T5c2y45i+FEYq6JcXipLpvEh38PjRBzQU7jwzSS9vFJbeAiT9ANt1Jad58MNv79/RZu00+f5nJiotLxduT9k9LSur+29UUU5f784/Tv2ekQSP4UL0OYmALXYN3d2SrxO+wRKRtgh4AB67DJo3RZP/1j539VcStt9k7t17Z/vPmLUYpubyMt61SUemYFwCM3KWYGrnabdA48npbPXNdSZJl5+vbm070Jb3DtFGBEfZj6TkDen6XXdnCkV4yXZsWZwPV/W2lPXfOdIeh6eiszbkABsbIDB3SXLqGcphWN6sqK8vHuKpvAE9snPLMLwF9qI8o6uUDVN966i8c5Kc2pbl58s6SdS0yicBS0bHp5IVw5VP758DaYFj3EtFcYf7+2ELO7mRCjJgSDg7Dln8BR/5AhjUdK92fBC5To6sayDjes62iWyd1+A0clfKaK7iq8dGUNM1bpfMmKJGPbPrZBnE2X/voA4IRgdz8o5E2ICOgbNxDVvgjoSrN6p63jW+MUcDgVKGQpKgOgR72aHUdxznKy8STk/6GMghv6pO4Kj2+w/+L8X/Bs1nC4g3w613mvY8iCHKkFW6oH7Ft/B8LOgIdyrSD/9jnq8J303gvZ6X5oaHKKiZQx+EnctwC2AR0x3SWJErOj9SqA6t8zJNpKfSK+F6z9xr+ve+Ewr0c7LrH/GLExI9hvCqhGMY/UOclCmC7hzgVfrGdgByGXyFzhHxpyrgLwFQN7rW0FsGiDFchxBseNTjchkDI6XxMHLQ9xAar8dBZi0qwJmfovOGvPlxr1poRn6ERXGijjPLE7imizL+JRoVhJX9Lyc5ejMl6U2Kk6a6IFg8VseidR+7rEEv3/M89UmGGJ0nwCxgz9p+SF/ntNwy2OEb1XMo+4hKkZCHOD+D7ZEok8Sl+VX712KN4soeJSj1M92+wV6AGqnTovVwrRgQpnNZ5Lgvjf9lIhMMBsUqWmYz5C/qqEsMoUNJhLUdWBvEQa4UmJNkM7EnCNiy4FYN8XldSsnNVA9QfvjUFZZIvKZIT10walxnTHW/xhsfK0Xfoxn9eGIDa73ViueUuZPeoTAFzIuBfeHWVw/dGXxVRJVH/qAhPRi4vUC1FWek6lCzM1Qib+dLy9Hs0JL/GInVbe9bX0WtyKTRLiTdtUmgVhaCZCBxt3SfMfx6hZ9bo5BZfD80yw6IPQq8tFBblQwyJQnoiRfl/RZwIMNPQmdceLpgKbAAaQ2sxEeDpyM9mHOyi+DPc/MO5M2FKWNJt+dtZPnMUxCsgbP7YFPHs8fvPeTEM0v1//ot5BLYxSQeioN/ku4Nx5BtbVAAucQEotmd4gVAz7mPk/0E3W8zX4C4Tq+79p7PVhr1sMUSlDArYygYVEMXkc4Kuj8hTexf+gZPTmpca8fB/z6nfwObg57KH5cwPWkMXiLHDGTNj41pfL/NHfVxpnUu1EjSt6tABVNURPQCtehA++JX71fH+/OxeshY/xn/35TTb1+Z6KVr4j+2KpnS1m4FxKvw0vjEDakGOfZvlkRx7WoEkZXwgNCyANlSY28IrjYaGIUaK5wicej7wp7HHeliTRAjT2a281dfnzZZ3Vv0Bz2UANfUlzmrkqW2/yAn2y3u+YJPWWaytBtrufsPbH9Vv6O+D+Dj5tuDTHvC2/c5Lu5pYy1wbhMEt1vvz4kaxgLpEuREiuTRq2SfGRFoHlo+YvGnoJEpbejaqbG0/vkhsqjuFjPZZ8sRdHVBv0QbhuZHh2awMMva2KRWbGtAiBWFByp4XQr56eGW7NZuTK0yQl/svT2vSM76xuiu+qCMFFFcCXfG+tmV9eY2o9ePyhwZiA53g4YtTTI+pwKT59hznH4RgvKPCKtAQGNctytHSNU6MUeaVAhz4VFSS18tCD6RoQTnGRLCz0kN0ntfSZyWV1QabXeeeaYkVAAApZ+qnmIEvQjy7RWiDZcLPUus+f3/B0cepkRaLTCcsR+VMebMNBI4YEPLBtz4FFe+dYHUd9tEuEIhDHhxyowZ7v6mWt41aNFr5FjnrUaeqycC+t3tM3yzWEVw6li8Qb43KqkNajjDF3dbzSqwjpZbejoCbouALw/d6yp16tuvq0uoBwEil0vFMPd0Vwk6k532fBYoM8GWe4ajFyewxGi5wZFnbwHYzD23XhVSfsiHg66NMNmAQbt+aa7Y4QEI+p2dYNGxXdbUfqW7RUnHYztaw9Wl0bVsORGUwIKBhqPVj0phv1s6T1N+1dlXYeV8ZOvxMzGVWkN2gL6mCCZfC4keS3ZoWm2A0BS0Q8i/No/92V4EL+ATV164SBVsWXELYBfje7Dm9P0c+X5Lv74yxdB0PHJEovvJDROLCV6Y6MZ1mH4kHw/0fyA1b/lmN/bUeQje97POIFOdW7sof6TL/JhVC0Wh2Wz8Rt5XfhmHPT5AjAuG4I1Z+Xv2ca5DJwbD9DIlhw0jCgX6Xssz2Mxk+0pdDgwmmF6CXiVCy9zVYZiwoXKhhDyqq04PnFyIV3obL0ju65YxuQDTIoDGSLmHiH2AnJ/D2pa0eqd2VHXash+4ow7iaxWb7+dvDs30KyOkIa8+o+Wczu3gCoc29FA9qDnDwuK8ZFj6MtmHrfI2oFMBwH9C2r07bCClX0ItGmDUqDZBPNVJw+Lps/o2TxAhI8p9hG2HoVj7KGdDcizqXzWNfHciAaLlc3gKe7gOUq62ufp1K6vDXLPWHj+zDYmjq2hrOHAma6Y3J2SG27SQ8iPy5pufCmbtguujglXm6dO/GbF2VfrHiPYKwR0WDpOnybS1Xv5APog2Q+75bgX4T6nT1zy8fFo3KqiYJM4kLcy3VkjpTUnVJj+ccRSItyxELzqCbuSp3pApsEBMkIaN8NH9kXP987i3i1wGNLT9TrRTPH+vuoB9eSCQt0G1cdS98gDnP0rg+sUXqnOcwQgwj22Hbye11xTMMkgCkbdIMBaevoJoSbJ54eLDKyIyrdNFqP7P7whPpQWcTqFXSEI+F/Y3aYINaD9TsvmjtL1rChqSwOw1ducTNRkmBQTPK7cMjxFjs5afT65Bda4iOil5kWHVdwerVDiIsUpyWzRXCNfp6iiOGe+UCICIjtyx0otmh1Ie58D0myufR2yHRiqn8zTy+7vDdRTe9VDV1bQEuHxbUsBQVSO3oZoUMGLn/4h+ChqOd8Eymk+iI02EP5CliaL6aAEJmdfzjbzCaAqf0VBk4jMV0KDV6ykctXDM6AXtSBe7i4JqY2Sp/Ap+ysvM4UgG65wK/P/q8JAwBrqvn8UXESKYJSocRQVi0MD0Y/m4n6nKDmuu/wWzs4vSZb+N4d0ZlDb/wcFz/bv8HInVYwbE5xNsQyRpkMQTPrBr0GmbnK924t4hbjep7JatiPv4YFzUhPaPOW3rDvexsA6mWY6FoKpMGuqvRokCv7Ok854kLxYmoLxo1s9Loom61AFgQhpMxBJVyUlEu7AFMnVOmGBkURLP1shD50rYPVYgcua/MSfTWRBowXo5fb8pK1gtKjChTSPhC2fYFYJxStINnHGGQlEpL+PwBaztqyblwnDdTwrokwaVukRYdEXLg79IU1cN3w3zxR9aXkgTOn+1WiBGcmmm0whWsH002HlIS/AYayx2gFbE1/v1H68fRr9rNN9h4N1KvZTHanr+N3rfNsBRvCcsPppgcVCFTBK0p0fMos3Urn0kGwQ6PSRB93Kon0tu76fesj3WTEavXiaTeWEmV/hVxnmvFGvxsVOxXiLAdn/09yOhPN3KKrRWbdRH3eBm3wiGBQxXqFHLXWP3SlRCecy+lq/ZfG2VHc4vfEbFa2OIDHBaXmCXNArCxNWEVnvSfLUIIrNklqa3KVX/kye3TncDm71TOxf3r0wO2v5NQZ8ruVp/qNWSEblEI1mjLzYJg2xJijMMlFTjgOvxjS5raI4or7Ioimd5bw6cj4W1gu1EvqQ9d/V1rpYb+6ZlJkUmEeRngGFv3PAPih+LKWPucI5I8BiE6f5TvvEqPg+GAEQ9d261O3IbbADm3/ma0i+jveQvcV0RMvYYO0F0mQ1VcDOvLuj5wGLZuYbUQvabC3EFeLlc18xni34mfb+3WorzZG3wUuhqRD4WOH4fTfC15O5raBQsUU1vrxElyxCriCos1clPHO0ugKpT+XVb67PetpsHBTiZD0b5ay0Sjzyb3m1fzjJAQVQLxshq9PTinON8r3sTfnxGbXKXgjXc8Otat31c8UgykAbr2aIu03WseFL3yXxqgrjJCGUMBb/Q4OBO3TKBNEYoCl9ZFclbI74n2W18oAZRWeGmUXpdS+JW6dE+cDzh51qtTu71HQF9j4HDaSrsaq73wdebHYMyMUvFlk3+Xnmesbo3OuwAFDbV+vrOl1wjy2kzBvOUKMsIuSACWpd6eEDD7s31oSv4gsR7+uQN95pSQFTWAP4ebRJNJLlyUAc82VFp+MrvFx0fOWDv9vHYIbTd3YsupoxREf9p2R2fGPLUpGzWRmgc4g2syP8kvY+bg3nLdWFSTGeU2gfIpt5m0Sz9xO+0TKnKs34LYbCNjq5R4Bt5yjatOq383SOcAbzQ1atBZRUcXessmCrXyLcHwvEibV6G0Feh3bmos32676pJ0+N2Wg/Wy4p1bsa99BTymfwEanuvcLbkvW96LYsreuTdR96TqKa3bJ/7G8hUqqsr1ZnQrOuP+2ncmzdvSwM8fijJ54Wi3QkDAiHaonkrutPWcQSkjfmaCKfILdiTdJVANNp2lls1cXXtrG4QuFMqGfX0XLM2zDqdTF78JlRa+raqf3pISMT0mSSWsTEPgiHUI0lRT9gl+mK5gzHCRvpjrcYKHZ+AOsqoJzu5a+qr5N7+Guvot9Ra/53Iq6Zq3w+5Gj2mLs4LI3z50YRQial6GZzP4GEQPU4/cl79smbNE0QdVTL7whBlv+zp7/1DBahdKCPo8/IwH/yyPCBTQB/mL2fXDNGSc1Njaa80RTAA79+q+ZMdDbS5uvONgsjxkW2/tI0ULntXYXqF7rqjqjnsefGssHdub3jsyF5nTb4Y2sfXg92rKawSm8th6I4jogv5Reourz6CP6QFg2swlgRNAXQNarF8k9oaOx961+grVMVAZoCKqM+bimHAuV3ewPhp19JwefYBw8c+WBaA4P7M3ewxYEQHMtORQ9FWnQmYL2bj8xuK3BQ9G7pbZZt6uqqr6FsdI1+B06T/TOBWq3qY38+oiMqDixm1PU7FEAlI0IeMNpDTuK5fucvNOetbnulF6xM0Uo+lQnRLuSOL6hyhVHgaEFU+odKe/2BoBVkrD1dX+7hHPbFkQR+aKa+pGsKEipPzu+IPNre3wShrgPhVbKCPduezdMLKWWQWJEf5zoJdK/UAPmdFSDcNS/7Cvl0KJAKEufuCzYryUcA+niaVP2kwOf3TTlqSjtlDJw619JqeSW7OUltjHUYSdDcTheclwlqCUO4aVTRV2BwiJYq2kL/u3mg0c5htA6UaWFM5LSxwKKOhDA9KXLt6KGETSn5w0wkGH0Wg3PPry3SbehDv0pLqa2LszQroo3gszG8mm8lju6hRL63Jhd3/21rnqpYdpAn7//BoxN1l+UAFCDAXLEpEg5Gv+dyvbPlxEHCctky79AATDHqnStOO1qOh1Jvk17eTTpU+PdAlvSUDZrX4K7/IR1L+LBcAtiOL+lM3dKmc8Vdkd9Cp4H4K1nM1+6NfiEBW7P1Fp8KNgoGELCrjDPvD7yym0iAks4jJnY3X3AX/UG4b7oFfJboyY/tJrQGXitXjjAEwJZJKYtsaPZhRxwDPyBfmfISVXAmc59fudXiwpM5996V6t8GVj5KloZI3H2LIQKnI51ANnCl6YiNubUa0zMCbWLXpJxzFxUJenHkA6nABhzV+g+tKZVeYSOHsiuFb7XNi5+aUPCj8VRQznj+FCWmkhBj/DKOK95Y1m7HaiELNjTEwLoAApcNHcqRD9IAAAAAAA",
	"data:image/webp;base64,UklGRvAeAABXRUJQVlA4IOQeAACwXgCdASqgALMAPl0mjkSjoiEXnVU0OAXEtQBq2yAuL0L/gea9YP8X/bvts9zvZD115XHPv/G/v35mfMj/Xeqz+0fuB7hX6pf770qv2M95v7neo/+jf4P9l/db/xn/Y/wnvA/sP+g/Xj4AP7T/hvTU9kP9y/Ye/m/+Q9NT9yPg8/sH+2/cH2kP/p7AHoAf/PPp/wHg34h/Sn7h/gv9j/e/blx79U39h6Dfyr7l/p/7L/hP+V8Zf27/O+DPw6/tfUC/J/5h/mPzH99T53/ZdpXZv/keoL7B/TP9l/f/8R/0f7j6Wv9n6HfYr/Ufbx9gH8w/qv+m/Ob/F/Mn/P/4Hi0fg/997AX8z/sH+n/w/5X/TN/Pf9z/G/6H9xvaD+hf4H/q/5b8pvsF/l/9R/2n+A/zX/v/zf///9n3Vf//29/tt/8vdH/YH/2fvAkA46eXRU+D/YlX9tNEBkDLd8Wq4M+iUV//jdYGMu3OmOjpMRc7jrRdy9caQ61owAqVe7n6+QSXXhDsqS4TD/GJek13Ql+rgGCwb31/8KJ8bX96AnIOilvD2um+T8FkEX5D6JfPzj7O40AEfKDvMKQLLjsThm/7rXL+9feTWVgjJycb7w08NRJndEhH2Dkg6fbM41KLm9iSFl3jtBoAdsM8I8QGnX2kU2yvlBINyWh/k6aKOR/gYpatmHQD7hyx/uqm9bWw5aJMax9w6buSx6plbAl2WSYh0qHJ46PjqYkZryZOcVucat7iQqxoLGSPc9D6c608zKKjr29JnOQK79/Q/NImXRV2StXv8WzNwH4hds3eaxmau/b/T/IdjbbyHSMepJRCzCWtBpS+OBrXCEEU+ACtsNVpFe9N//ZmI17wki/YA5rOxBKI8QT8fUtKDrQbWg5EJGOwi9AqoV3RHX4K687nLdxt4dfGoj8Vyk0pu255QsL54SrmEb8crofvRnPpDzjpHw3ypGlHW3f8EMMKThUaw6L4Je/cWIgDoWDCqCK8t7VVIxWd/Yo+B6/jUttFC29AAP77/ymriD+xh/KcDiFbF6IKBVepQKmQT6GZR/SjxL9je7+zfMZLQd8/vbjL3eGj/i/nQn/JM6/t5XyxUMgWLEjd26/nddLsnOndVQR9FaCEVBOnrVxY/JgM9MM5JeI9PKkZdZ78oM/o2K0eiidRQOfEtpf4jPjU5JS9KPHZCa3nfO9X3Di5iMbN6dutpGO+BkuF+9nxRaLrKOkCJfytb8UTj1J7TrzkjzqkhrZ1HGw1DBwXnIi6V/yedHPcQtCsWys+QWT5F2aRkG6E0ZN3P80vMdtWjrazbX4tJljszpXtgWyAjzF6w1uJStQysspnWjJXP7tDb0mYPE1v5SZEwzBHZGzx9XnAPB9eNN3QASTaBy11rZMU3JwmZwQF4xFfTUN+m4EhpOlmvDndTZHKJ2s/3a5Ou+a+onO3wpo0GjBcIpuUB5bTm60DENcoab4KYIvDocSNHJB3o7jbExOzuzbO2N7Q7lmwZXy4qtlqvR841mHBV2V2kCaX0lSkXYTbDEwNxu20rzgPJrZbpGrlYM8t4d4g5c1VPYKPjdRq9wSDdiTqKWrdZfaGfE3owR99zY7n4gDKBAReSwiqbzIPwYQZfPpj3PkG6Z01vPsgVgbEFFPpxKvG4b4SkcyoRXNvCg5fJF/AiaqAG8hG3SSZ84+YbGXHY8iHgKI1dSwcMH1meSPSlnlNi46i0lwO9uD0tKOZeCLDR/+wXYYblBZmgtPIKHoQnlsSVxFATWZtole2zEtxUB6OgvOh9V6oRpziTSt1DHPyeDD1g3mo7mIQreSe8ZJ+JfB77CrMKN+iv5Hj/+IuEiehkaRpctjwNtasv1Q3KmakntnsExJsYsMzsKb3UNaf1tuNa+RLFNEBa2AMAz7LKW/bfX6cxwO1I0PdCxQvFbx/Laz4haxPQWDOLNrJAQCsgVZ8gEN398IryQpJmfUYFuOp3R+fxs6unhyT+MhEwWzduFl+A450gFRUE5WkpkLzn4jLD5PwzsWMxLh6qbLpR00oQx3aMeNgGgbmdCsks4fr0ArrAn/m0UfczsqoPcBLp774OAdEtFAskMjgOrA9N1LXXFZMzgXoS+WcvkeI08Jne92yTVEu+MomWLhlS9NJToJu56GKiu12on+fEhqUARhYAwmEKXJfCwT/yjp5vYNwzljKf8axzNAdn0OCbRqJqgkE9VGrAogaKhBQNU4tXnAyQn7lzkwrwPDwUI/fAFbkRGQM9DzjolWArgJ0tJDTSTixwc4mIn/CVkbMXHKJAUaSxpMeRYU2HCLJnp10G5z3S+HYc0KEloE6JmCokXlK0ooxk6VhzmiQUi3HNeiflzTjOQft6NbCwouSFpWzmv+IJnpUPMjD4qUhZAJkZLe2jEUSp5Aw7Tf9StA++1t5H9IQgHcWNOy7yseWbT5ts0yT4ubyCB36zYtszH4LbraZPFco8MgVstn+2ohEOFKVERbUmmz9oRig3vnt52rDhI8xK+M3vpXIu6ztueT9GTOfhGUgtMGEmjh5BWnSh2zqhwyF/tizf/pg6yJAJ4RQJI5xdNSJ0rWYj+of8y7bAKih9kv1MO/wpB3uG5t6dWbiaJYoPOwr3kSDhilwHZxm7XeWsW8lLvwX9inmIB6p0+Z76zdFexZtle4TppUt4h0T3HkIgWUhooXUVEG24hj3dZDoPOxWPutaS7N2lQabY0ABdgsAs4oThJ/ZklqrPENK+lwXmzl8r+0xgyARAAAw23BvNyVY1Da7gSNw8X5lk06RemvqPfaWgfplohAZC9zu+DfG9PdYXdNA3e2Fcujd44ojeX6WJM017xhZOs4p6/k+U58MqUSYNkpOjV6yCwr+43eIDRdKGMZ0haCepLQzvSRnmTiQIWCl/ki82sJJ+DP+foqb6pCqBt8xVHUzsJzkyJEt0xyHliqVYsGpkgQj6KEM9EZyFBUOT3ZBuUSqT0cQELM4uwszxDkTCKkudraQqu1wuydZ5BtJ+7UsgEZ1mQ9OFNuukkhNZlQAKvlRXL65ph3//LDnwmCgPg36L/LnBb2jXajmWbai0Mjidj6oX5wvAFhudedrzgYbxqQs1FHPTwjTOX6LiGmh4lcb74hUo+a96spvAmVAh0SqagFkt0bqFYxplwU2VebnRNHyvPr4HMdKxk4a8ou8QcLsgAnHc0KYLUAGqb8PM1XlDor/yZUXOgCByeQwNQRLc0cWvaL5DYICMxOqeN51jNzrJuCfqRtMLZANW3wGVvX2/IvdQ96MEsRBvHwR5ihUM4U9qOZIL3eN0YNfjkhfR5Wj5lXDV3/gQEANCh4EJ0drM2N2F3+l7Fpwj4gLpXXgK7gOKeaR9oEePOQxb2NAfM4lejUb70+XIcNETtfyOmgR4hPWS7HskX1cc54zR6SZZcR4pKLH/w0M4qXZMr3OcXe74Fin7rc2b7dijhPvxqz/BRbpEgTh1exZIKIgtMpBJPVdDkDwr0T8BLnKy6GTD3LbfoVpYM6nv/UCUSwqtxlCs63OK833c0gNHpD7ejCA/zCHdLJLHJqwJc3+PCf77P/5bdEd+IMO2gfEwTBg6XK4p1rVlw8fCiYf2xiVmrXHvzcXE+h//ClzpRSehqu+AGkcfq2vEaVfnpV4szRRv+zOIlebrp6XtbLk3OWNuI57/k7KYdzKnAPMXOOfKnP1c7diurlkkFvMNLkU4BxCC/DxDrllYUAJOMYOpeu5G5hUHaPefEaBDMWkmGnyZW/uT519s1bxTTtDeNa7+W+r31vDTQcKYrVUlQXULdWDZo4FjDE6nMkY42Wxxq5epFusH/moKxS9XdVa9rj9m+V8jVjPjV3xRMvVpxknxnYgq+mUFt2NR/AAbNNwdpKdaNafZw7XHUOtAieMYnN83XCWlEfpgIvDxByhbGH4K8iEpe+v5eN/YbA1SH18eChlNfP5PfllWJsKZq72umBDLXyNsFmbk8Ssgt0UPZnk6NMQfLSk962VA8YSDvFATV7VdAB65YufYNMeFN5TEzttmt9zKl6xqshHBVd5UckXPow6GhVKR4f5z5Vt34Jl5xCVUX8ASssdAZlie8U30GTNYP7MYQ727b9PZjP16ofw7NITb+qlK00Tgoymcx/cbXVlu6n36OyTlzwXOL6OVzh85pqGFAbbbE3qKiWz4REvLV+tCq8WCqR/mEH/SR3eh8WUl8EMuIGAByE9PpFffnjbQHSMW2fUznQJdpb0ZYHetBQopUsfeWiBnpaDOjhYEcMQupLKFSkngMrhOq2t2lTyLhPgS+rSpNo9S/OYWAaxqq+0+l9KHYiz381VHgvDUv0JuHc/q+dWVWcCkHvA0h933sLmwULHRjiCzjUhOPLRgVD/NIjbEX4vbqnOyVJ+553fYtL8fQAYVeYBT40XHn4+XRiE/twD0JTX+0eoLEnvVHAok1emh087tNc6ZcsDWJxrocEruKsz7fEYvpauRQCrzNzZFD5DpJ9Omu3EPAX9WcRag128FXol2rVb7TSdCoN+g9RFDJObqOIzwqsnDTOXxVHB5arrrT9jbII57zqnxX4Oc59TbleJukHE5TO0sXy2XsYUrZCMcCeQj99tkqN/wweogddICmeA/z9ZDsJNH3y6a4/PDvuWyKxsFTUWb7wc+xWWVtFTOuf2JS86dSZKeIkfQwRFIGh9CR+F62eD8YdTeOmZ15Cv1A5z48wHW9DhA6b+7cNKWbaCUQL2TB53Zjtgbp5gWT/A2rDPnusAQPnrH96c1X+N02va6C+Bd6mFl1E2MCVjbalvXS1Ai5h7XWahoy4JqmORz439HWQgaBQqCtiDvJk4QQc/CTcwIU7xEoK1TWcB3IjxZXuWmL4IRAuftwvqHhkrMzn1TJ/qZGzSkbtHw5aylSz3MGHpgPvmBf5YNYJoiogPpUnsLLYuT6lTA5kMiG34kIgGidy2EYW2cry+uIDzmYoOt8BXDuPwYA97rPC1v8DBNdaW3FREFiGY16EqG4HILPmGPLh/qgOKGR1+Tx8o/WZw1dphABN/Ct2Rl9AwAZqxKJyWXLH4zxJ8zc2iuA46bhTVvISChLQg9FCnuRm6Uo3bZehcW0nnXzEliwMV5BLPJt/Cnwr5byDssE++TlF32SYKTpo3UxlcnMH8EzMz/CBZlQ0FzR9gogjvyj/gyQ2m+lhfZa6oKpx/64MMwg3Pc3M5EdLxxwH7N1DSQrCJ+Q8nlYcI5dS5BHovRUxRB74P3+JMEU2w8nJ5fMkpTLrsTZ11fy1YjyULNtUpyIERh3AVOp9eGt8ZhvOYwvsCJuQczXguZMLaJ9TSQ2wOS5bmAVmOAzrjKrc5ZGAeQnyp9/uXLypM3jciNnwB5lFRmtwyRkVJ461uOFgp86n6vw3HtD7QgN5lhenQGYrqxdUmwDAAackyfKi/Wg4u5H1MHf5aOKBeRoTpuSD9CbkiWlwNGMRXFG5xCf2aoZII6h1sAuooIJENADu5eqlSXIioYTCtkK4LjEDhWwtJy7fxOCGccTV7GJDMiaUIT5Xy40i0rPGwGAHK4zBYc8rRuNbFBWMNXaX9PdbjkyFaQ0KTMETimMycxZRDV7OSXa5eQLxlQuCO1aQ0UlPt+fJufhkrnrWGFk7nV5637kEWkxCqKq8Cm46im8awpe4smdcJXaZyJ14UFCrWC3L+VlGF/rnH8GEUtvqqrMrI4I2wNBTv9ogslMyaG9u/anY7/h8ZBdYCOgKPJBMQxvo4t9HiN6Ikv5lLBXiCnki4SOboIsa6bSH+0nvaIDklEg9KbOrIpZeeI1OPWbCvGbX/NAQCPL33z3xYlu5AkvgxXBjf6OzK6ikaS3pv2nk/OANPL/Bk5S2HSQehVefS9o5A6QSej2usVykpufwz8RkeKu94okkUZwGPZmpCi65BRr7sGKtIQcmxFMbKnIEaqeY5GwmDvR5xt959P/dvPHBBuU8hWRruq2duAFcc2ZECtPUYfara7YuXppdvAPk+z88r43iUqlbKCO5lN39PnMUaV2KlHHTzHbLBMfRQUYtZ2nlo4jlTcHMc+ts+yeR9x69pl212TjQKFZ3NKfIWEq2LbHpqHa+pvKPam0CmW2LZ1T+aJzObEIxRzLGtPFy6CKQSgdQ9M+Qt1LWtXTPOmC9Jec5VgPXJo7XsdFEmkwoY4lAI96/CJoPX+B0AFyKK4SkE9kdLmAhjTDa+u7aZJ749dLYyR3fmg6q7OPiUkAwZgmXbnS6hV14vggsOd1yreOWFC8DxvXvJX2+xxThea1PtvyDEbTWHx0dRH7Vu6BNM2W3Nz+pqmfq/n6hwhJkFmNIsJ0z7XuRuk2oikQIm1Y9NyI7OO4ygIEn5pNAhCm9FZMFctC0GiNZ3ZrpM1gFmzyHoQb3Nt557Vv+vqNRYmMZlXWYxVLTzAqW97GOfSjC0uxf0q2k/qDAT1XvKVe3Sylq0G9YKZ6jjB3Axny4NOQJ4mXzi/41+kAm4Tan/LzdMVN7xvOD9FkloIgM6hPioCbs4ka5/i/RN3MrSb2Gl2S0FpgJt+cC3Cw4H2FLgyOM6m8M1T7MhCjPrhyWGMCi5qfpZFv9ZUy3ryLnZbwZK1QbzkJXkjJ8zIvhuN9SQaHjfUNsL/uueMYGSMBETO43HbPW3gTm5xkzUCbGXfKmsWGmsZnSUyxhguBnoKrRtZpRC0vbZWglZt1bfwS+mf+U8cSiU3FA67hQtIwy3pgsiRR5r0hHEpJqeSUQcJSUZBtxv5PjIsiLHFQB3vK/RDnjAvxQJ3ZqvgbbPzRECUPHeFagHXL7BiL8wETiIhz4CtJ91NFExQEGQWyrc+DHyXHbHsdM07cQ6JlM7QnKyjcSotOYo/SYDkHFIF7Tojh605F7Xe+rF00UvSTevaeIYn9JFGxc78nQF0qmpKRUCBH5VQvPA937EM32NiNguqNm2SL2Z7RzswckzEQYmDKJJ3QEnxy396XdXZtfKlBs8+XehkzDO5cqRCJBXRqSBXKK015GGQf5aEnLu/XF3z9wLixC3nE8Jux9U1uALTtKl4OLdok3e/IjBSacY2//NNQy9lfMEi0IKX9HMBMPAHgA7o71tj/q1+pfuwwtpZXNVlD1Dot87qrnpwwW+0sdqxPX3P1jLzzR7fl4pQxFa9r2c8s4LC2a2Tap7O7/OpSyQ5XrmKfyYqSSyGkPHY3Bb/HLg8pLHaO6guK8vHUYqHxWk6yXEYDZ8kt8mT6b+mThHaBcO4L0U/5KgXavX5WwfpJoR0WVL/gEe2O2NYxBQ9kBDUr/Mh8aE7qesbUDO8E4k476UXGPhR4rO7Bn8Kc8s/ioAanWW/zplIyhlHqJE7/fj0HnVV+BuausSYY+RBvkDE+rYvoC1qIIOM+o2q8meSxTjiAOxKBpI/UrYYb8ZWEwQzw2xiNqR53XJNpnHMsDIB9bgLWmfvGc+yFJJf7IzqzCGetL94H1Xa6vsTuQyfyqPxXhzLY5CbDW4w2261RXv67AvIRtozS+l+sEGxkVJudmqUZ60/G+16jIOhmomquxZc2ql8b34QL3/p4q8x4KclDNFXpQkKOy2tSCKd/ECqaBupMaEg315A/r3Q57M7dPQntLi/Rhm9Jdmt/A66Q0dhec1WzPtIPjKTBgyzRnJN2hXI0gSIl7cccR6GJT+RQE0sUuMAkPgcPd+TKNwzNMwrVSFwNo4oWnWBdA+loMYAx5pPKMsPo0PhmAs/U9hkBANmHEmUIFoL1zVSRNxXurLApVKkTfPslG3IOPExgYbJt5M9PG7zIdsaPXF7S13F9+wcOGE3vLQuMTgNHoON8LAApLjERj/f+u8leww1yJdrHI/gPbLIRMCLouYroUCvjP+hp2ynM6BAfwxN125XjfOIVFcIXXMSnbtKNgv6WhGkRKScLwEbY0La5bnsYnR69vjTPBQaEJnz/35gZQv8uz8u5r35utyvrrYJlYfeaX0q+hNScyjLeaRWEvD3/rzgNNYvGBD1J57bCAp2BvbThLZNq2es3+8Z4ZZ8/QvMrcW5mejlIfwqXwMTLqnvSSCrOQI2A4m0whQZgy8cXzQU+fae8V4VSGAih+6IpPUlI2nPHX4yOGiIADLA0d44J9OHx5+hMHW2QgZIuvhi30Z5JXDvQBxlSYTZli1zxZ15E1QuZJtOcOsI1yB17fYb4SR4p49wpZZ4JrQzOELQabxVLxOdOwnBp08nPEHFrQ1cnqBDkrFG/tOjPjQGb6lcO1Lb3MXPx9ficfHC6fcr7NjWl/isIZ0HP+Ib/xxguY7gKPyff2pdYuWmr5w2yEaRbRgSx49gJB340VCWPBllNYKqB7QW99cJgJQN+Bz32wtztNwP8BT6HlQbkf23yFa6S/09pBONEpDHIr4B6xloxLT53QZ9ZyDeyvEllIW3v4BIQEUSJR+RyeN7a21D6xV3f08bnV74AO9SZIpWxKEg1D2OV2HcnEGU7fAW7/HfiTXvl3ZXqYv8qmn7o76z1RTASkz3QHvpcAoBG+ZIihaPmspf6Bw4GAHOY2bn+nlCN+K+7e3BDHPgbD0SXboKzpLfgDJdFA6tPOIItNczhiNFhGrIwXsf6ytpdoAhymiD5XoH9JrtB7RmyhziU9jw7YlM4/wsldMVVl8ahRZKclSWPnHtsCWzVaBfVFJps7Fq0cvtN6LIw+wgXQP63hjHV3MYrM2cOKDFb2nxOETxfA2BQI5kUeNl0tgmKtVbTEpbITtSeNmRyngPHE//2+xHuWAM3ewVa6YuhC65Q8NBNCTEm2s0OFwtCbXWRUf/fynkOnWKxMKqW2m2/woFc8f4mQNZBYx/K0DidmWtVCqTpiDfhF/hRoeQ1df/jGZ5D+JbwOH/V+RumpB1ZCAlB7gt9EFh5NYEHJFRqonziRcLncfEe3Jb3YsubxEjXhR5RPZr5LqSv06tLYnmxf5qqX9sX0oMGJRKUoqb+4k50f7A8aRI+BM3lKZy6zsZvZoL+pFSbwv36BmIzuA3tnKAkhSAlUBcWbSQIQbZaTy83lBY2iZ/vekxwwc0FozoWCzJm+J6ankLIWiAy7pZvTXiwHl9tul81LS6LSaaSMHyFWYZf03Ry/Rb1C/n453bw48Mq+cgrusqwXeSya9mB7ylgftmDyMKdvv7RYWOP4cgK7blJSn/DDR4/6g29KUppQgeb506KGkpzYEyEHiJXpgxL16zKe3xZT5SmeaCFhHRvoAZ+CE93Ry+dn9jSJ3y64B4hiGGgLDXkCmPA0ykTwwb/K8dd0P4mzX9bJuMX7TQxBlM+DfK5U0ljdwkjoqlHZ7brjCgMLeKpiA9AeSBG2Uhv2oCfyfGw27NzVWKdPttlKYGp6dj3ApZDiC7M3ebbix6WPW7ioXvOzXOQMdzqz/gxn76sHClniVK7C37nM/PBbFC8A0mg84pYVmLMkyqHWToVY3W72yotubXF5K6fABgCq2L0n1dWCCAMfEu6vgFz+sgu7AqJA2gme4ItkDHJTkdOEgj5jGFCjA5lE4DH0Ay4orVi5PEpHzHsQxWyip5SQAIKnbehizjw26HfXxGvf9ZNasK4umzGRDgmty8Oxl2QG+KJZmM2VqR4sNzIC0V+1xNA1MAP6wxPI52LhULz6ySicqO0Kss4Y1x/DhHNibSFotCuoLBXaP9Hs/HwKi88SFurqw7HYKhQmRa+T3Czol/9OSQTKpVi7vBGJiTr7FeCRh3uFpPP0islbbeXWfmi5lAA3Grdh9Q+YxWeqeLKFfY6OcBc3x9NOcG6bDAK0X/zrPwcxpkBwvH2H+OkON4Q4lVGERYJvSc7A5/cCxya2gld5UnBFDtPJ0X8hmEFLUVQLNnIolT93m+6oH1B1HzFpFP0aNF1v96dShjSIETfeCzcE74fZILys7lQpnxAloYWKb+8LFVmOpkyZktd6zgOpEWxBN/cDzc2Q/WWM2ZCXBS3nXF+buonD3ZZ/aAirzJKm8Vp52QKrs8C4ACRI7M3uZD1SYs/CrXQUyTA4osdzo50lrNLb4Xr8Y+88hge1AA2Zv8fHSRCjJFOclplsoGbr96qMI0/oHhoZGGsRhuwfjtwUWePaKl56LvaRNz6O5kYCr+Fz/tvF44UN/8FKK0P3rEO6X0CrCELhk214XbvmnObb8ngKcfFTXcX5DnIgXz+bSDFJgz4khNN+l9FSt35afLIJYMQpEjL8KY+UujRIe9dyiUVq17OY9O2FfERTr9duE/HsWzj6RJ6oi096oWRl3aWo0x/n4rxeCdOtGRsfpfdDbWPgNcGOxTREVt946d8+pjVRlo36Xczf35WFYmq48FSVBBR7GjHeN3TS/cJiaY5SCaRemTc6cjL5Wa8Paxhp28uTmzZeJ49yk0ZhpErC2LGnBJImWJrVW8VaI/nbj1lagN0V/0S9JqnrdLLx/b8NX4b79gxIIIUDIDHcusFd5bg1XrbayXeG7FuQSw0oPBbHDGefv6I9l9+md1YCDvlZDhWFdFKfD7MKKI2iKBFFteAxUnvaP5CmNH+ppz68M79+if25F/4r04Xpr2RqgWvYutKNgWlTl0cL+x49OImksvBXx/LCSzAbwAAA="
];
function ue({ value: e = null }) {
	return /* @__PURE__ */ h("span", {
		className: `thedealer-card${e === null ? " thedealer-back" : ""}`,
		"aria-hidden": !0,
		children: e === null ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", { className: "thedealer-orbit" }), /* @__PURE__ */ h("b", { children: "?" })] }) : /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("b", {
				className: "thedealer-value",
				children: e
			}),
			/* @__PURE__ */ h("img", {
				src: le[e],
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ h("b", {
				className: "thedealer-value thedealer-value-bottom",
				children: e
			})
		] })
	});
}
function de({ value: e, anchor: t, selected: n, onPick: r }) {
	let i = o(), { ref: a, hidden: s } = c(t), l = /* @__PURE__ */ h("span", {
		ref: a,
		style: { visibility: s ? "hidden" : void 0 },
		children: /* @__PURE__ */ h(ue, { value: e })
	});
	return r ? /* @__PURE__ */ g("button", {
		type: "button",
		className: `thedealer-card-pick${n ? " is-selected" : ""}`,
		onClick: r,
		"aria-pressed": n,
		"aria-label": i("games.thedealer.selectCard", { n: e ?? 0 }),
		children: [l, /* @__PURE__ */ h(fe, {})]
	}) : /* @__PURE__ */ h("span", {
		className: "thedealer-card-slot",
		"aria-label": i(e === null ? "games.thedealer.hidden" : "games.thedealer.cardValue", { n: e ?? 0 }),
		children: l
	});
}
function fe() {
	return /* @__PURE__ */ h("svg", {
		className: "thedealer-ants",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ h("rect", {
			x: "1",
			y: "1",
			width: "98",
			height: "98",
			rx: "4",
			pathLength: "100",
			children: /* @__PURE__ */ h("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-12",
				dur: "0.8s",
				repeatCount: "indefinite"
			})
		})
	});
}
//#endregion
//#region src/games/thedealer/view-player.tsx
function pe({ player: e, pub: t, priv: n, member: r, myRid: i, selectedCard: a, targetSelected: s, onTarget: l, onRole: f, nameOf: p }) {
	let m = o(), _ = e.rid, v = _ === i, y = t.outcomes[_], { ref: b } = c(`score:${_}`), { ref: x, hidden: S } = c(`hand:${_}`), C = t.phase === "deal" && t.dealer === i && a !== null && t.targets.includes(_) || t.phase === "prepare" && t.players.find((e) => e.rid === i)?.role === "frenemy" && _ !== i && _ !== t.dealer, w = t.phase === "talk" && _ !== i && _ !== t.dealer && !e.banked, T = t.statements.filter((e) => e.target === _ && e.cycle === t.cycle).slice(-1)[0], E = n?.hands[_] ?? [], D = v ? n?.friend : t.frenemyFriend, O = e.role === "frenemy" && t.frenemyTarget ? `${m("games.thedealer.chosenTarget", { name: p(t.frenemyTarget) })}${D === !0 ? ` · ${m("games.thedealer.friend")}` : D === !1 ? ` · ${m("games.thedealer.enemy")}` : ""}` : null;
	return /* @__PURE__ */ g("article", {
		className: `thedealer-seat${v ? " is-mine" : ""}${C ? " is-eligible" : ""}${s ? " is-selected" : ""}${e.banked ? " is-banked" : ""}`,
		style: { "--thedealer-player": r ? u[r.colorIndex % u.length].hex : "#819529" },
		"data-rid": _,
		children: [
			/* @__PURE__ */ g("header", {
				className: "thedealer-seat-header",
				children: [/* @__PURE__ */ g("span", {
					className: "thedealer-person",
					children: [r && /* @__PURE__ */ h("img", {
						src: d[r.avatar % d.length],
						alt: ""
					}), /* @__PURE__ */ h("strong", { children: p(_) })]
				}), /* @__PURE__ */ h("span", {
					ref: b,
					className: "thedealer-score",
					children: m("games.thedealer.points", { n: e.score })
				})]
			}),
			/* @__PURE__ */ g("div", {
				className: "thedealer-seat-role",
				children: [/* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => f(e.role),
					"aria-label": m("games.thedealer.roleDetails"),
					children: m(q[e.role])
				}), /* @__PURE__ */ h("span", { children: y ? m(y.bust ? "games.thedealer.bust" : "games.thedealer.safe") : e.banked ? m("games.thedealer.banked") : e.decided ? m("games.thedealer.submitted") : "" })]
			}),
			/* @__PURE__ */ g("div", {
				className: "thedealer-seat-body",
				children: [/* @__PURE__ */ h("button", {
					type: "button",
					className: "thedealer-portrait",
					onClick: () => f(e.role),
					"aria-label": m(q[e.role]),
					children: /* @__PURE__ */ h("img", {
						src: Y[e.role],
						alt: "",
						draggable: !1
					})
				}), /* @__PURE__ */ h("div", {
					className: "thedealer-hand",
					ref: x,
					style: { visibility: S ? "hidden" : void 0 },
					children: e.role === "dealer" ? v && n && n.pool.length ? n.pool.map((e) => /* @__PURE__ */ h(de, {
						value: e.value,
						anchor: `pool:${e.id}`,
						selected: a === e.id,
						onPick: () => l(`card:${e.id}`)
					}, e.id)) : /* @__PURE__ */ h("span", {
						className: "thedealer-dealer-mark",
						children: m("games.thedealer.dealerInfo")
					}) : E.length ? E.map((e, n) => /* @__PURE__ */ g("div", {
						className: "thedealer-hand-item",
						children: [/* @__PURE__ */ h(de, {
							value: e.value,
							anchor: `card:${_}:${n}`
						}), /* @__PURE__ */ g("span", {
							className: "thedealer-card-hint",
							children: [
								e.parity && m(e.parity === "even" ? "games.thedealer.even" : "games.thedealer.odd"),
								e.correct !== null && m(e.correct ? "games.thedealer.correct" : "games.thedealer.incorrect", { n: e.guess ?? 0 }),
								e.secret && v && m("games.thedealer.privateCard")
							]
						})]
					}, `${t.round}:${n}`)) : /* @__PURE__ */ h("span", {
						className: "thedealer-empty",
						children: m("games.thedealer.noCards")
					})
				})]
			}),
			/* @__PURE__ */ g("div", {
				className: "thedealer-seat-note",
				children: [O && /* @__PURE__ */ g("span", { children: [O, (y || T) && " · "] }), y ? m("games.thedealer.roundPoints", { n: y.base + y.bonus }) : T ? m("games.thedealer.statement", {
					name: p(T.by),
					n: T.total
				}) : !O && (e.role === "dealer" ? m("games.thedealer.pool") : m("games.thedealer.safeRange", {
					min: 3,
					max: e.role === "giant" ? 7 : 5
				}))]
			}),
			(C || w) && /* @__PURE__ */ h("button", {
				type: "button",
				className: "thedealer-target",
				onClick: () => l(_),
				"aria-label": m(C ? "games.thedealer.receive" : "games.thedealer.tellPrompt", { name: p(_) }),
				children: C && /* @__PURE__ */ h(fe, {})
			})
		]
	});
}
function me({ count: e }) {
	let t = o(), { ref: n } = c("deck");
	return /* @__PURE__ */ g("span", {
		className: "thedealer-deck",
		ref: n,
		children: [/* @__PURE__ */ h("span", {
			className: "thedealer-deck-mark",
			"aria-hidden": !0,
			children: "◉"
		}), t("games.thedealer.deck", { n: e })]
	});
}
function he({ public: e, private: t, members: n, myRid: r, send: c }) {
	s();
	let u = e, d = t, _ = o(), v = a((e) => e.locale), y = u.players.find((e) => e.rid === r), b = `${r}:${u.round}:${u.cycle}`, [x, S] = i({
		scope: b,
		card: null,
		target: null
	}), [C, w] = i(null), [T, E] = i(null), D = x.scope === b && d?.pool.some((e) => e.id === x.card) ? x.card : null, O = x.scope === b ? x.target : null, k = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? p(t, v) : _("games.thedealer.unknownPlayer");
	}, A = (e) => {
		if (e.startsWith("card:")) {
			S({
				scope: b,
				card: Number(e.slice(5)),
				target: O
			});
			return;
		}
		u.phase === "deal" && u.dealer === r && D !== null ? c({
			type: "deal",
			card: D,
			target: e
		}) : u.phase === "prepare" ? S({
			scope: b,
			card: null,
			target: e
		}) : u.phase === "talk" && w({
			scope: b,
			target: e
		});
	}, j = u.actor === r, M = y && y.role !== "dealer" && !y.banked, N = C?.scope === b && u.phase === "talk" ? C.target : null, P = /* @__PURE__ */ h("span", {
		className: "thedealer-wait",
		children: u.actor && u.actor !== r ? _("games.thedealer.waiting", { name: k(u.actor) }) : _(J[u.phase])
	});
	return u.phase === "prepare" && y && !y.prepared ? (y.role === "sniper" && (P = /* @__PURE__ */ h("div", {
		className: "thedealer-number-choices",
		children: [
			3,
			4,
			5
		].map((e) => /* @__PURE__ */ h("button", {
			type: "button",
			onClick: () => c({
				type: "prepare",
				prediction: e
			}),
			children: _("games.thedealer.prediction", { n: e })
		}, e))
	})), y.role === "frenemy" && (P = /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", {
		className: "thedealer-choice-label",
		children: O ? _("games.thedealer.chosenTarget", { name: k(O) }) : _("games.thedealer.prepareFrenemy")
	}), /* @__PURE__ */ h("div", {
		className: "thedealer-buttons",
		children: [!0, !1].map((e) => /* @__PURE__ */ h("button", {
			type: "button",
			disabled: !O,
			onClick: () => c({
				type: "prepare",
				target: O,
				friend: e
			}),
			children: _(e ? "games.thedealer.chooseFriend" : "games.thedealer.chooseEnemy")
		}, String(e)))
	})] }))) : u.phase === "talk" && M ? P = /* @__PURE__ */ g("div", {
		className: "thedealer-buttons",
		children: [/* @__PURE__ */ g("button", {
			type: "button",
			"aria-pressed": d?.decision === !1,
			onClick: () => c({
				type: "decide",
				bank: !1
			}),
			children: [_("games.thedealer.hit"), d?.decision === !1 && " ✓"]
		}), /* @__PURE__ */ g("button", {
			type: "button",
			className: "thedealer-primary",
			"aria-pressed": d?.decision === !0,
			onClick: () => c({
				type: "decide",
				bank: !0
			}),
			children: [_("games.thedealer.bank"), d?.decision === !0 && " ✓"]
		})]
	}) : u.phase === "guess" && j || u.phase === "tie" && u.tiePlayers.includes(r) && d?.tieGuess === null ? P = /* @__PURE__ */ h("div", {
		className: "thedealer-number-choices",
		children: [
			0,
			1,
			2,
			3
		].map((e) => /* @__PURE__ */ h("button", {
			type: "button",
			onClick: () => c({
				type: "guess",
				value: e
			}),
			children: _("games.thedealer.guess", { n: e })
		}, e))
	}) : u.phase === "destroy" && j ? P = /* @__PURE__ */ h("div", {
		className: "thedealer-number-choices",
		children: [
			0,
			1,
			2,
			3
		].map((e) => /* @__PURE__ */ h("button", {
			type: "button",
			onClick: () => c({
				type: "destroy",
				value: e
			}),
			children: _("games.thedealer.removeNumber", { n: e })
		}, e))
	}) : u.phase === "gamble" && j ? P = /* @__PURE__ */ g("div", {
		className: "thedealer-buttons",
		children: [/* @__PURE__ */ h("button", {
			type: "button",
			onClick: () => c({
				type: "gamble",
				take: !1
			}),
			children: _("games.thedealer.keepScore")
		}), /* @__PURE__ */ h("button", {
			type: "button",
			className: "thedealer-primary",
			onClick: () => c({
				type: "gamble",
				take: !0
			}),
			children: _("games.thedealer.takeGamble")
		})]
	}) : u.phase === "review" && (P = /* @__PURE__ */ g("div", {
		className: "thedealer-buttons",
		children: [/* @__PURE__ */ h("span", { children: _("games.thedealer.waitingConfirmed", {
			n: u.confirmed.length,
			total: u.players.length
		}) }), /* @__PURE__ */ h("button", {
			type: "button",
			className: "thedealer-primary",
			disabled: u.confirmed.includes(r),
			onClick: () => c({ type: "confirm" }),
			children: _("games.thedealer.confirmRound")
		})]
	})), /* @__PURE__ */ g("div", {
		className: "thedealer-screen",
		children: [
			/* @__PURE__ */ h(f, {
				adaptive: !0,
				className: "thedealer-adaptive",
				scroll: !1,
				banner: /* @__PURE__ */ g("header", {
					className: "thedealer-banner",
					children: [/* @__PURE__ */ g("div", {
						className: "thedealer-title",
						children: [
							/* @__PURE__ */ h("h1", { children: "THE DEALER" }),
							/* @__PURE__ */ h("span", { children: _("games.thedealer.round", {
								n: u.round,
								total: u.rounds
							}) }),
							/* @__PURE__ */ h(me, { count: u.deckCount })
						]
					}), /* @__PURE__ */ h("p", { children: _(J[u.phase]) })]
				}),
				actionsHeight: "thedealer-action-slot",
				actions: /* @__PURE__ */ g("div", {
					className: "thedealer-actions",
					children: [/* @__PURE__ */ h("div", {
						className: "thedealer-my-role",
						children: y && /* @__PURE__ */ g(m, { children: [
							/* @__PURE__ */ h("strong", { children: _(q[y.role]) }),
							/* @__PURE__ */ h("span", { children: u.phase === "tieReveal" && u.tieCard !== null ? _("games.thedealer.tieResult", { n: u.tieCard }) : y.role === "dealer" ? _("games.thedealer.cycle", { n: u.cycle }) : _("games.thedealer.safeRange", {
								min: 3,
								max: y.role === "giant" ? 7 : 5
							}) }),
							d?.prediction !== null && d?.prediction !== void 0 && /* @__PURE__ */ h("span", { children: _("games.thedealer.prediction", { n: d.prediction }) })
						] })
					}), /* @__PURE__ */ h("div", {
						className: "thedealer-controls",
						children: P
					})]
				}),
				children: /* @__PURE__ */ h("div", {
					className: "thedealer-table",
					"data-count": u.players.length,
					children: u.players.map((e) => /* @__PURE__ */ h(pe, {
						player: e,
						pub: u,
						priv: d,
						member: n.find((t) => t.rid === e.rid),
						myRid: r,
						selectedCard: D,
						targetSelected: O === e.rid,
						onTarget: A,
						onRole: E,
						nameOf: k
					}, e.rid))
				})
			}),
			/* @__PURE__ */ g(l, {
				open: N !== null,
				onClose: () => w(null),
				label: N ? _("games.thedealer.tellPrompt", { name: k(N) }) : _("games.thedealer.tellPrompt", { name: "" }),
				children: [/* @__PURE__ */ h("p", {
					className: "mb-3",
					children: _("games.thedealer.bluffNotice")
				}), /* @__PURE__ */ h("div", {
					className: "thedealer-tell-grid",
					children: Array.from({ length: 16 }, (e, t) => /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => {
							N && c({
								type: "tell",
								target: N,
								total: t
							}), w(null);
						},
						children: _("games.thedealer.tell", { n: t })
					}, t))
				})]
			}),
			/* @__PURE__ */ h(l, {
				open: T !== null,
				onClose: () => E(null),
				label: T ? _(q[T]) : "",
				children: T && /* @__PURE__ */ g("div", {
					className: "thedealer-role-details",
					children: [/* @__PURE__ */ h("img", {
						src: Y[T],
						alt: ""
					}), /* @__PURE__ */ h("p", { children: _(ce[T]) })]
				})
			})
		]
	});
}
//#endregion
//#region src/games/thedealer/bot.ts
var ge = {
	caution: .2,
	dealerPressure: 1,
	trust: 0
};
function X(e) {
	let t = [1];
	for (let n of e) {
		let e = [
			0,
			1,
			2,
			3
		].filter((e) => (n.value === null || e === n.value) && (n.parity === null || e % 2 == 0 == (n.parity === "even")) && (n.guess === null || e === n.guess === n.correct)), r = Array(t.length + 3).fill(0);
		for (let n of e) t.forEach((t, i) => {
			r[i + n] += t / e.length;
		});
		t = r;
	}
	return t;
}
var _e = (e) => {
	let t = [...e].reduce((e, t) => Math.imul(e ^ t.charCodeAt(0), 16777619), 2166136261);
	return t = Math.imul(t ^ t >>> 16, 2246822507), t = Math.imul(t ^ t >>> 13, 3266489909), (t ^ t >>> 16) >>> 0;
};
function ve(e = ge) {
	return (t, n) => {
		let r = t.public, i = t.private, a = r.players.find((e) => e.rid === n.rid);
		if (!a || !i || r.phase === "done") return null;
		let o = n.difficulty === "weak", s = _e(`${n.rid}:${r.round}:${r.cycle}:${r.tieRound}:${a.count}`), c = (e) => ({ action: e });
		if (r.phase === "prepare" && !a.prepared) {
			if (a.role === "sniper") return c({
				type: "prepare",
				prediction: 3 + s % 3
			});
			if (a.role === "frenemy") {
				let e = r.players.filter((e) => e.rid !== n.rid && e.role !== "dealer");
				return c({
					type: "prepare",
					target: e[s % e.length].rid,
					friend: s % 3 == 0
				});
			}
		}
		if (r.phase === "deal" && r.dealer === n.rid && i.pool.length) {
			if (o) return c({
				type: "deal",
				card: i.pool[0].id,
				target: r.targets[0]
			});
			let t = {
				card: i.pool[0].id,
				target: r.targets[0],
				score: -Infinity
			};
			for (let n of r.targets) {
				let o = r.players.find((e) => e.rid === n), s = o.role === "giant" ? 7 : 5, c = X(i.hands[n]);
				for (let r of i.pool) {
					let i = 0;
					c.forEach((t, n) => {
						let a = n + r.value;
						i += t * (a > s ? 10 + e.dealerPressure : a < 3 ? (3 - a) * .9 : -a);
					}), i += (o.score - a.score) * .015, i > t.score && (t = {
						card: r.id,
						target: n,
						score: i
					});
				}
			}
			return c({
				type: "deal",
				card: t.card,
				target: t.target
			});
		}
		if (r.phase === "guess" && r.actor === n.rid) return c({
			type: "guess",
			value: s % 4
		});
		if (r.phase === "talk") {
			let t = r.players.find((e) => e.role !== "dealer" && e.rid !== n.rid && !e.banked && !r.statements.some((t) => t.by === n.rid && t.target === e.rid && t.cycle === r.cycle));
			if (t) {
				let e = i.hands[t.rid], n = X(e).reduce((e, t, n) => e + t * n, 0);
				return c({
					type: "tell",
					target: t.rid,
					total: Math.max(0, Math.min(30, Math.round(n) + (s % 3 == 0 ? -2 : 0)))
				});
			}
			if (a.role === "dealer" || a.banked || a.decided) return null;
			if (o) return c({
				type: "decide",
				bank: a.count >= (a.role === "giant" ? 4 : 3)
			});
			let l = X(i.hands[n.rid]), u = a.role === "giant" ? 7 : 5, d = (e) => e >= 3 && e <= u ? e : 0, f = 0, p = 0;
			l.forEach((e, t) => {
				f += e * d(t);
				for (let n = 0; n < 4; n++) p += e / 4 * d(t + n);
			});
			let m = r.statements.filter((e) => e.target === n.rid && e.cycle === r.cycle);
			if (m.length && e.trust) {
				let t = m.reduce((e, t) => e + t.total, 0) / m.length;
				f += e.trust * d(Math.round(t));
			}
			return c({
				type: "decide",
				bank: f > 0 && f + e.caution >= p || a.count >= 12
			});
		}
		if (r.phase === "destroy" && r.actor === n.rid) {
			if (o) return c({
				type: "destroy",
				value: s % 4
			});
			let e = i.hands[n.rid], t = 0, r = -1;
			for (let n = 0; n < 4; n++) {
				let i = X(e.filter((e) => e.value !== n)).reduce((e, t, n) => e + t * (n >= 3 && n <= 5 ? n : 0), 0);
				i > r && (t = n, r = i);
			}
			return c({
				type: "destroy",
				value: t
			});
		}
		return r.phase === "gamble" && r.actor === n.rid ? c({
			type: "gamble",
			take: o ? s % 2 == 0 : r.outcomes[n.rid].base < 6
		}) : r.phase === "review" && !r.confirmed.includes(n.rid) ? c({ type: "confirm" }) : r.phase === "tie" && r.tiePlayers.includes(n.rid) && i.tieGuess === null ? c({
			type: "guess",
			value: s % 4
		}) : null;
	};
}
var ye = ve(), be = (e, t, n) => e.type === "decide" ? n(e.bank ? "games.thedealer.bank" : "games.thedealer.hit") : e.type === "guess" || e.type === "destroy" ? n("games.thedealer.chooseNumber", { n: e.value }) : e.type === "gamble" ? n(e.take ? "games.thedealer.takeGamble" : "games.thedealer.keepScore") : n("games.thedealer.hintAction");
//#endregion
//#region src/games/thedealer/fx.tsx
function Z({ box: e, value: t }) {
	return /* @__PURE__ */ h("span", {
		className: "thedealer-fx-card",
		style: { "--thedealer-card-h": `${e.h}px` },
		children: /* @__PURE__ */ h(ue, { value: t })
	});
}
function Q({ at: e, cards: t, boxes: i, ms: a, back: o = !1 }) {
	let s = r(null);
	return n(() => {
		let e = s.current;
		if (!e) return;
		let t = e.animate([{
			transform: "perspective(600px) rotateY(85deg)",
			opacity: .25
		}, {
			transform: "perspective(600px) rotateY(0)",
			opacity: 1
		}], {
			duration: a,
			easing: "cubic-bezier(.2,.7,.2,1)",
			fill: "both"
		});
		return () => t.cancel();
	}, [a]), /* @__PURE__ */ h("div", {
		ref: s,
		className: "thedealer-fx-hand",
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: t.map((t, n) => {
			let r = i[n];
			return r && /* @__PURE__ */ h("span", {
				style: {
					position: "absolute",
					left: r.x - e.x,
					top: r.y - e.y
				},
				children: /* @__PURE__ */ h(Z, {
					box: r,
					value: o ? null : t
				})
			}, n);
		})
	});
}
function xe() {
	let e = o();
	return /* @__PURE__ */ h("span", {
		className: "thedealer-fx-label",
		children: e("games.thedealer.banked")
	});
}
function $(e, t, n = !1) {
	let r = e.data, i = t.anchor(n ? `hand:${e.rid}` : "deck"), a = t.anchor(n ? "deck" : `score:${e.rid}`);
	if (!i || !a) return null;
	let o = r?.cards ?? [], s = F.score;
	return {
		ms: s,
		node: /* @__PURE__ */ g(m, { children: [o.slice(0, 4).map((e, t) => /* @__PURE__ */ h(v, {
			from: i,
			to: a,
			ms: s - 180,
			delay: t * 35,
			children: /* @__PURE__ */ h(Z, {
				box: i,
				value: e
			})
		}, t)), !n && typeof r?.points == "number" && /* @__PURE__ */ h(_, {
			at: a,
			ms: s,
			children: /* @__PURE__ */ g("span", {
				className: "thedealer-fx-label",
				children: ["+", r.points]
			})
		})] })
	};
}
var Se = {
	deal(e, t) {
		let n = e.data, r = e.secret, i = t.anchor("deck"), a = `card:${e.rid}:${n.id}`, o = t.anchor(a) ?? t.anchor(`hand:${e.rid}`);
		return !i || !o ? null : {
			ms: F.deal,
			hide: [a],
			node: /* @__PURE__ */ h(v, {
				from: i,
				to: o,
				ms: F.deal,
				children: /* @__PURE__ */ h(Z, {
					box: o,
					value: r?.value ?? null
				})
			})
		};
	},
	bank(e, t) {
		let n = t.anchor(`hand:${e.rid}`), r = e.data;
		return n ? {
			ms: F.decisions,
			hide: [`hand:${e.rid}`],
			node: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(Q, {
				at: n,
				boxes: Array.from({ length: r.count }, (n, r) => t.anchor(`card:${e.rid}:${r}`)),
				cards: Array(r.count).fill(0),
				ms: F.decisions,
				back: !0
			}), /* @__PURE__ */ h(_, {
				at: n,
				ms: F.decisions,
				children: /* @__PURE__ */ h(xe, {})
			})] })
		} : null;
	},
	reveal(e, t) {
		let n = t.anchor(`hand:${e.rid}`), r = e.data;
		return n ? {
			ms: F.reveal,
			hide: [`hand:${e.rid}`],
			node: /* @__PURE__ */ h(Q, {
				at: n,
				boxes: r.cards.map((n, r) => t.anchor(`card:${e.rid}:${r}`)),
				cards: r.cards,
				ms: F.reveal
			})
		} : null;
	},
	prize(e, t) {
		return $(e, t);
	},
	return(e, t) {
		return $(e, t, !0);
	},
	destroy(e, t) {
		return $(e, t, !0);
	},
	score(e, t) {
		let n = e.data, r = t.anchor(`hand:${e.rid}`), i = t.anchor(`score:${e.rid}`);
		return !r || !i ? null : {
			ms: F.score,
			node: /* @__PURE__ */ h(v, {
				from: r,
				to: i,
				ms: F.score,
				children: /* @__PURE__ */ g("span", {
					className: "thedealer-fx-label",
					children: ["+", n.points]
				})
			})
		};
	},
	tie(e, t) {
		let n = t.anchor("deck"), r = e.data;
		if (!n) return null;
		let i = {
			...n,
			w: 78,
			h: 120
		};
		return {
			ms: F.tie,
			node: /* @__PURE__ */ h(Q, {
				at: {
					...n,
					w: 90,
					h: 130
				},
				boxes: [i],
				cards: [r.value],
				ms: F.tie - 500
			})
		};
	}
};
//#endregion
//#region src/games/thedealer/game-over.tsx
function Ce({ public: e, result: t, members: n, hintCount: r, onPlayAgain: i, onBackToLobby: s }) {
	let c = e, l = o(), u = a((e) => e.locale), d = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? p(t, u) : l("games.thedealer.unknownPlayer");
	};
	return /* @__PURE__ */ g("div", {
		className: "thedealer-ending",
		children: [
			/* @__PURE__ */ h(b, {}),
			/* @__PURE__ */ g("header", { children: [
				/* @__PURE__ */ h("span", { children: "THE DEALER" }),
				/* @__PURE__ */ h("h1", { children: l("games.thedealer.resultTitle") }),
				/* @__PURE__ */ h("p", { children: l("games.thedealer.winner", { names: t.winner.map(d).join(" & ") }) })
			] }),
			/* @__PURE__ */ g("div", {
				className: "thedealer-ending-body",
				children: [/* @__PURE__ */ h("div", {
					className: "thedealer-winner-art",
					children: /* @__PURE__ */ h("img", {
						src: Y.dealer,
						alt: ""
					})
				}), /* @__PURE__ */ g("div", {
					className: "thedealer-bill",
					children: [
						/* @__PURE__ */ h("div", {
							className: "thedealer-total-grid",
							children: t.ranking.map((e) => /* @__PURE__ */ g("article", {
								className: t.winner.includes(e) ? "is-winner" : void 0,
								children: [
									/* @__PURE__ */ h("strong", { children: d(e) }),
									/* @__PURE__ */ h("b", { children: t.scores?.[e] ?? 0 }),
									/* @__PURE__ */ h("span", { children: l("games.thedealer.finalBase", { n: c.results.reduce((t, n) => t + (n.base[e] ?? 0), 0) }) }),
									/* @__PURE__ */ h("span", { children: l("games.thedealer.finalBonus", { n: c.results.reduce((t, n) => t + (n.bonus[e] ?? 0), 0) }) })
								]
							}, e))
						}),
						/* @__PURE__ */ h("div", {
							className: "thedealer-rounds",
							children: c.results.map((e) => /* @__PURE__ */ g("details", { children: [/* @__PURE__ */ h("summary", { children: l("games.thedealer.roundLabel", { n: e.round }) }), /* @__PURE__ */ h("div", {
								className: "thedealer-round-scroll",
								children: /* @__PURE__ */ g("table", { children: [/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: l("games.thedealer.total") }), c.players.map((t) => /* @__PURE__ */ g("th", { children: [d(t.rid), /* @__PURE__ */ h("small", { children: l(q[e.roles[t.rid]]) })] }, t.rid))] }) }), /* @__PURE__ */ g("tbody", { children: [
									/* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: l("games.thedealer.base") }), c.players.map((t) => /* @__PURE__ */ h("td", { children: e.bust[t.rid] ? l("games.thedealer.bust") : e.base[t.rid] }, t.rid))] }),
									/* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: l("games.thedealer.bonus") }), c.players.map((t) => /* @__PURE__ */ h("td", { children: e.bonus[t.rid] }, t.rid))] }),
									/* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: l("games.thedealer.total") }), c.players.map((t) => /* @__PURE__ */ h("td", { children: /* @__PURE__ */ h("b", { children: e.points[t.rid] }) }, t.rid))] })
								] })] })
							})] }, e.round))
						}),
						r !== void 0 && /* @__PURE__ */ h("p", { children: l("session.hint.usedCount", { n: r }) }),
						Object.entries(t.autopilot ?? {}).filter(([, e]) => e > 0).map(([e, t]) => /* @__PURE__ */ g("p", { children: [
							d(e),
							" · ",
							l("session.autopilot.share", { n: Math.round(t * 100) })
						] }, e))
					]
				})]
			}),
			/* @__PURE__ */ g("footer", { children: [
				i && /* @__PURE__ */ h(y, {
					label: l("session.result.playAgain"),
					confirmLabel: l("games.thedealer.confirmAgain"),
					onConfirm: i
				}),
				s && /* @__PURE__ */ h(y, {
					label: l("session.result.backToLobby"),
					confirmLabel: l("games.thedealer.confirmBack"),
					onConfirm: s
				}),
				!i && !s && /* @__PURE__ */ h("span", { children: l("session.result.waitHost") })
			] })
		]
	});
}
//#endregion
//#region src/games/thedealer/options.tsx
function we({ value: e, onChange: t }) {
	let n = o(), r = O.safeParse(e), i = r.success ? r.data : O.parse(void 0);
	return /* @__PURE__ */ h(S, {
		title: n("games.thedealer.rolePool"),
		columns: 2,
		children: ["all", "starter"].map((e) => /* @__PURE__ */ h(x, {
			name: "thedealer-roles",
			value: e,
			checked: i.rolePool === e,
			label: n(e === "all" ? "games.thedealer.allRoles" : "games.thedealer.starterRoles"),
			hint: n(e === "all" ? "games.thedealer.allRolesInfo" : "games.thedealer.starterRolesInfo"),
			accent: "#819529",
			onChange: () => t({ rolePool: e })
		}, e))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/thedealer/entry.tsx
var Te = {
	definition: se,
	View: he,
	bot: ye,
	describe: be,
	fx: Se,
	OverView: Ce,
	Options: we,
	locales: {
		zh: {
			name: "The Dealer",
			desc: "在太空赌场里，看着别人的手牌，猜测自己的点数。相信谁，又该何时收手？",
			rules: "游戏目标:\n在所有轮次结束后获得最多分数。你能看见其他人尚未封存的手牌，却不能查看自己的普通手牌。你可以如实告诉别人牌值，也可以诈唬。其他人的点数声明不保证真实。\n\n准备:\n使用 100 张数字牌，0、1、2、3 各有 25 张。每位玩家获得一个公开角色，其中一人为庄家。标准角色池包含全部角色；入门角色池使用先知、赌徒、巨人、亦敌亦友和超级计算机。随机选取足够角色后，本局始终使用这些角色。\n3 人游戏进行 6 轮，每人担任两次庄家；4 至 6 人游戏进行与人数相同的轮数，每人担任一次庄家。每轮结束后，所有角色向左传一位。\n\n一轮的流程:\n· 首次发牌前，狙击手秘密选择预测点数，亦敌亦友公开选择目标并秘密决定对方是朋友还是敌人。保密者从牌库顶抽取自己的额外牌，只有本人可以查看。\n· 庄家从牌库抽取比仍在要牌的人数多 1 张的牌，查看后，自行选择给每位仍在要牌的玩家各发 1 张。庄家不给自己发手牌，未分配的余牌放回牌库底。\n· 发完这一批牌后，玩家有 30 秒交流。你可以点击一名玩家的区域，对其手牌合计作出点数声明；同一批牌中再次声明会替换你对该玩家的旧声明。\n· 仍在要牌的玩家秘密选择继续要牌或封存手牌。全员提交后同时公开选择；也可以等到倒计时结束，未提交者视为继续要牌。封存的手牌保持盖住，本轮不再收牌。\n· 只要还有人在要牌，就继续抽牌、分配和交流。全员封存后才开始揭牌。若牌库不足以完成新一批发牌，则直接封存现有手牌并结算。\n\n揭牌与得分:\n· 一般角色的手牌合计为 3 至 5 点时安全，获得等于合计点数的分数。低于 3 点或高于 5 点都算爆掉，手牌不得分。巨人的安全范围为 3 至 7 点。\n· 每有一名玩家爆掉，庄家从牌库顶抽取 2 张数字牌，将两张牌的点数加入自己的总分。庄家没有手牌安全范围的限制。\n· 成功手牌和奖励牌离开牌库，爆掉的手牌以及毁灭者弃掉的牌放回牌库底。奖励只能抽取牌库中实际剩余的牌。\n· 依次揭示每人的手牌并结算，再结算狙击手和亦敌亦友的额外奖励。所有人确认本轮结果后，传递角色并开始下一轮。\n\n角色能力:\n· 庄家：选择并分配数字牌，争取让其他人爆掉；每有一人爆掉，抽取 2 张牌计分。\n· 狙击手：轮初秘密选择 3、4 或 5 作为预测点数。如果本轮安全手牌的点数正好等于预测值，再抽取 2 张数字牌，将其点数加入得分。\n· 保密者：轮初抽取 1 张额外数字牌，只有自己可以查看。这张牌盖住摆放，计入本轮手牌合计；之后收到的普通牌仍不能自己查看。\n· 超级计算机：庄家每次发给你一张牌时，必须如实说明该牌为奇数还是偶数。0 属于偶数。\n· 先知：庄家先选定发给你的牌，你猜测这张牌的数值，随后获得真实的正确或错误提示。每次收到牌都可猜一次。\n· 赌徒：揭牌后，若手牌安全，可以再抽取 1 张牌。如果抽到 0，本轮爆掉且手牌不得分；否则，将新牌点数加入原本的手牌得分，不再按 5 点上限判断。\n· 亦敌亦友：轮初公开选择庄家和自己以外的一名玩家，秘密将其指定为朋友或敌人。朋友最终安全，或敌人最终爆掉时，抽取 1 张数字牌计分；即使自己爆掉也能获得这项奖励。\n· 巨人：安全范围扩大为 3 至 7 点。\n· 见证者：收到的第 2 张数字牌正面朝上，所有人包括自己都能看到。封存后仍需等到揭牌阶段才能查看整手牌。\n· 毁灭者：全员封存后、揭牌前，宣布 0 至 3 中的一个数值，然后弃掉自己手牌中该数值的所有牌，再计算剩余手牌。\n\n结束与平局:\n规定轮数结束后，总分最高者获胜。若最高分并列，并列者秘密猜测下一张数字牌的数值，再翻开该牌。恰有一人猜中时，该玩家获胜；多人猜中时，由这些人继续猜牌；无人猜中时，原有并列者继续。牌库没有牌可供裁决时，并列者共同获胜。",
			invalid: "这个操作已不适用于当前局面，请重新选择。",
			unknownPlayer: "来宾",
			round: "第 {{n}} / {{total}} 轮",
			cycle: "第 {{n}} 批牌",
			points: "{{n}} 分",
			deck: "牌库 {{n}} 张",
			dealer: "庄家",
			sniper: "狙击手",
			keeper: "保密者",
			computer: "超级计算机",
			prophet: "先知",
			gambler: "赌徒",
			frenemy: "亦敌亦友",
			giant: "巨人",
			witness: "见证者",
			destroyer: "毁灭者",
			dealerInfo: "每有一人爆掉，抽 2 张牌计分。",
			sniperInfo: "猜中安全手牌的合计，再抽 2 张牌计分。",
			keeperInfo: "额外暗牌只有你能看见，计入手牌合计。",
			computerInfo: "每张牌都会如实提示奇偶；0 为偶数。",
			prophetInfo: "每次收牌时猜数值，并得到真实的对错提示。",
			gamblerInfo: "安全后可抽奖：0 会爆掉，其余点数加分。",
			frenemyInfo: "朋友安全或敌人爆掉，你都能抽 1 张牌计分。",
			giantInfo: "你的安全范围是 3–7 点。",
			witnessInfo: "第 2 张牌对所有人公开。",
			destroyerInfo: "揭牌前宣布一个数值，弃掉所有同值手牌。",
			preparePrompt: "先完成轮初的秘密选择。",
			dealPrompt: "选一张牌，再点击要牌的玩家。",
			guessPrompt: "猜测即将收到的牌。",
			talkPrompt: "相信谁？现在决定要牌或封存。",
			decisionsPrompt: "同时公开本次选择。",
			destroyPrompt: "选择要从自己手牌中移除的数值。",
			revealPrompt: "全员封存，开始揭牌。",
			gamblePrompt: "手牌安全，要再赌一张吗？",
			scorePrompt: "正在结算手牌。",
			bonusPrompt: "正在结算角色奖励。",
			reviewPrompt: "本轮结束。确认后传递角色。",
			tiePrompt: "最高分并列，秘密猜测下一张牌。",
			tieRevealPrompt: "平局猜牌结果。",
			donePrompt: "赌场结账。",
			waiting: "等待 {{name}}",
			yourCards: "你的手牌",
			hidden: "未知牌",
			cardValue: "{{n}} 点牌",
			privateCard: "你的额外暗牌",
			noCards: "尚未收牌",
			banked: "已封存",
			choosing: "选择中",
			submitted: "已提交",
			prepared: "已选定",
			safe: "安全",
			bust: "爆掉",
			safeRange: "安全 {{min}}–{{max}} 点",
			bank: "封存手牌",
			hit: "继续要牌",
			changeDecision: "可在其他人提交前更改选择",
			seconds: "交流 {{n}} 秒",
			lockedBank: "已选择封存",
			lockedHit: "已选择要牌",
			pool: "庄家的待发牌",
			selectCard: "选中 {{n}} 点牌",
			receive: "发给 {{name}}",
			prepareFrenemy: "点选目标，再秘密选择关系。",
			friend: "朋友",
			enemy: "敌人",
			chooseFriend: "指定为朋友",
			chooseEnemy: "指定为敌人",
			choosePrediction: "秘密预测手牌点数",
			prediction: "预测 {{n}} 点",
			chosenTarget: "目标：{{name}}",
			prepareConfirm: "确认秘密选择",
			guess: "猜 {{n}}",
			even: "偶",
			odd: "奇",
			correct: "猜中",
			incorrect: "不是 {{n}}",
			removeNumber: "移除 {{n}}",
			chooseNumber: "选择 {{n}}",
			takeGamble: "再赌一张",
			keepScore: "保留得分",
			confirmRound: "确认本轮",
			waitingConfirmed: "已确认 {{n}} / {{total}}",
			tellPrompt: "向 {{name}} 声明手牌合计",
			tell: "声明 {{n}} 点",
			statement: "{{name}} 说：{{n}} 点",
			statementAria: "{{speaker}} 声明 {{target}} 有 {{n}} 点",
			bluffNotice: "声明可能是诈唬。",
			close: "关闭",
			roleDetails: "查看角色能力",
			resultTitle: "星光赌场结账单",
			winner: "{{names}} 获胜",
			total: "总分",
			roundLabel: "第 {{n}} 轮",
			base: "手牌",
			bonus: "角色奖励",
			roundPoints: "本轮 {{n}} 分",
			result: "查看结账单",
			resultInfo: "展开每轮得分，核对手牌与角色奖励。",
			confirmAgain: "确认再来一局",
			confirmBack: "确认返回大厅",
			hintAction: "完成当前可用的选择。",
			rolePool: "角色池",
			allRoles: "全部角色",
			starterRoles: "入门角色",
			allRolesInfo: "从全部 9 个非庄家角色中随机选取。",
			starterRolesInfo: "从先知、赌徒、巨人、亦敌亦友和超级计算机中随机选取。",
			tieResult: "翻出的牌为 {{n}}",
			tieChoice: "已秘密猜牌",
			finalBase: "手牌得分 {{n}}",
			finalBonus: "角色奖励 {{n}}"
		},
		en: {
			name: "The Dealer",
			desc: "At a space casino, everyone can see your cards except you. Who do you trust, and when do you bank?",
			rules: "Objective:\nFinish with the highest total score. You can see other players’ unbanked hands, but not your own ordinary cards. You may tell the truth or bluff. Point claims made by other players are not guaranteed to be true.\n\nSetup:\nThe deck contains 100 number cards: 25 each of 0, 1, 2 and 3. Each player receives a public character, including one Dealer. The full pool includes all characters. The starter pool contains the Prophet, Gambler, Giant, Frenemy and Supercomputer. Randomly select enough characters and use that selection throughout the game.\nWith 3 players, play 6 rounds so everyone is the Dealer twice. With 4–6 players, play one round per player so everyone is the Dealer once. Pass all characters one seat to the left after each round.\n\nPlaying a round:\n· Before the first deal, the Sniper secretly predicts a total and the Frenemy publicly chooses a target while secretly choosing Friend or Enemy. The Secret Keeper draws an extra card from the top of the deck that only they may see.\n· The Dealer draws one more card than the number of players still asking for cards. After looking at these cards, the Dealer chooses one for each of those players. The Dealer does not receive a hand. Return the unused card to the bottom of the deck.\n· After each batch, players have 30 seconds to talk. Select another player’s area to make a claim about their hand total. A new claim replaces your previous claim about that player in this batch.\n· Players still in the round secretly choose to take another card or bank their hand. Reveal choices together when everyone has submitted. At the end of the timer, anyone who has not submitted continues taking cards. Banked hands stay face down and receive no further cards this round.\n· Repeat dealing and discussion while anyone is still taking cards. Reveal hands only after everyone has banked. If the deck cannot supply a complete new batch, bank and score the existing hands.\n\nRevealing and scoring:\n· A normal hand totalling 3–5 is safe and scores its total. Below 3 or above 5 is a bust and scores nothing. The Giant’s safe range is 3–7.\n· For every player who busts, the Dealer draws 2 number cards and adds their values to their score. The Dealer is not subject to a hand limit.\n· Scoring hands and reward cards leave the deck. Return busted hands and cards discarded by the Destroyer to the bottom of the deck. Rewards draw only as many cards as remain available.\n· Reveal and score each hand in turn, then resolve the Sniper and Frenemy rewards. After everyone confirms the round result, pass characters and begin the next round.\n\nCharacter abilities:\n· Dealer: Choose and distribute number cards to try to make other players bust. Draw 2 scoring cards for every player who busts.\n· Sniper: Secretly predict 3, 4 or 5 at the start of the round. If your safe hand total matches, draw 2 number cards and add their values to your score.\n· Secret Keeper: Draw 1 extra number card at the start of the round. Only you may look at it. Keep it face down, but include its value in your hand total. You still cannot see ordinary cards dealt to you.\n· Supercomputer: The Dealer must truthfully tell you whether each card dealt to you is odd or even. Zero is even.\n· Prophet: After the Dealer commits a card to you, guess its value and receive a truthful correct or incorrect answer. Guess once for each card dealt to you.\n· Gambler: After revealing a safe hand, you may draw 1 more card. A zero makes you bust and lose your hand score. Otherwise, add the new card’s value to your hand score without checking the upper limit again.\n· Frenemy: At the start, publicly choose another player other than the Dealer and secretly designate them Friend or Enemy. If your Friend ultimately succeeds or your Enemy ultimately busts, draw 1 scoring card. You earn this reward even if you bust yourself.\n· Giant: Your safe range expands to 3–7.\n· Witness: Your second number card is face up so everyone, including you, can see it. After banking, wait for the reveal before looking at the rest of your hand.\n· Destroyer: After everyone banks but before hands are revealed, announce a value from 0–3. Discard all cards of that value from your hand, then score the remaining cards.\n\nEnding and ties:\nAfter the required rounds, the highest score wins. Tied leaders secretly guess the next number card, then reveal it. A sole correct guess wins. If several are correct, only those players continue; if nobody is correct, all remaining tied players continue. If no card is available for the tiebreak, they share the victory.",
			invalid: "That action is no longer available. Please choose again.",
			unknownPlayer: "Guest",
			round: "Round {{n}} / {{total}}",
			cycle: "Batch {{n}}",
			points: "{{n}} pts",
			deck: "{{n}} cards left",
			dealer: "Dealer",
			sniper: "Sniper",
			keeper: "Secret Keeper",
			computer: "Supercomputer",
			prophet: "Prophet",
			gambler: "Gambler",
			frenemy: "Frenemy",
			giant: "Giant",
			witness: "Witness",
			destroyer: "Destroyer",
			dealerInfo: "Draw 2 scoring cards for each player who busts.",
			sniperInfo: "Match your predicted safe total to draw 2 scoring cards.",
			keeperInfo: "Only you can see your extra card. Include it in your hand.",
			computerInfo: "Every card has a truthful parity hint. Zero is even.",
			prophetInfo: "Guess each card’s value and receive a truthful answer.",
			gamblerInfo: "Gamble after a safe hand: zero busts; other values add points.",
			frenemyInfo: "Draw 1 scoring card if your Friend succeeds or Enemy busts.",
			giantInfo: "Your safe range is 3–7.",
			witnessInfo: "Your second card is visible to everyone.",
			destroyerInfo: "Name a value before the reveal, then discard all matching cards.",
			preparePrompt: "Make the secret opening choices.",
			dealPrompt: "Select a card, then choose its recipient.",
			guessPrompt: "Guess the card you are about to receive.",
			talkPrompt: "Who do you trust? Take another card or bank.",
			decisionsPrompt: "Reveal everyone’s choices together.",
			destroyPrompt: "Choose a value to remove from your hand.",
			revealPrompt: "Everyone has banked. Reveal the hands.",
			gamblePrompt: "Your hand is safe. Gamble on one more card?",
			scorePrompt: "Scoring this hand.",
			bonusPrompt: "Resolving character rewards.",
			reviewPrompt: "Round complete. Confirm to pass characters.",
			tiePrompt: "The leaders are tied. Secretly guess the next card.",
			tieRevealPrompt: "Tiebreak result.",
			donePrompt: "Time to cash out.",
			waiting: "Waiting for {{name}}",
			yourCards: "Your hand",
			hidden: "Unknown card",
			cardValue: "{{n}} card",
			privateCard: "Your private extra card",
			noCards: "No cards yet",
			banked: "Banked",
			choosing: "Choosing",
			submitted: "Submitted",
			prepared: "Ready",
			safe: "Safe",
			bust: "Bust",
			safeRange: "Safe: {{min}}–{{max}}",
			bank: "Bank hand",
			hit: "Take a card",
			changeDecision: "You may change your choice until everyone submits.",
			seconds: "{{n}}s to talk",
			lockedBank: "Bank selected",
			lockedHit: "Card selected",
			pool: "Dealer’s cards to deal",
			selectCard: "Select the {{n}} card",
			receive: "Deal to {{name}}",
			prepareFrenemy: "Choose a target, then a secret relationship.",
			friend: "Friend",
			enemy: "Enemy",
			chooseFriend: "Choose Friend",
			chooseEnemy: "Choose Enemy",
			choosePrediction: "Secretly predict your hand total",
			prediction: "Prediction: {{n}}",
			chosenTarget: "Target: {{name}}",
			prepareConfirm: "Confirm secret choice",
			guess: "Guess {{n}}",
			even: "Even",
			odd: "Odd",
			correct: "Correct",
			incorrect: "Not {{n}}",
			removeNumber: "Remove {{n}}",
			chooseNumber: "Choose {{n}}",
			takeGamble: "Gamble again",
			keepScore: "Keep score",
			confirmRound: "Confirm round",
			waitingConfirmed: "{{n}} / {{total}} confirmed",
			tellPrompt: "Claim a hand total for {{name}}",
			tell: "Claim {{n}} points",
			statement: "{{name}} says: {{n}}",
			statementAria: "{{speaker}} claims {{target}} has {{n}} points",
			bluffNotice: "Claims may be bluffs.",
			close: "Close",
			roleDetails: "View character ability",
			resultTitle: "Starlight Casino · Cash Out",
			winner: "{{names}} won",
			total: "Total",
			roundLabel: "Round {{n}}",
			base: "Hand",
			bonus: "Character rewards",
			roundPoints: "{{n}} this round",
			result: "View cash out",
			resultInfo: "Open each round to compare hand points and character rewards.",
			confirmAgain: "Confirm another game",
			confirmBack: "Confirm lobby",
			hintAction: "Complete the available choice.",
			rolePool: "Character pool",
			allRoles: "All characters",
			starterRoles: "Starter characters",
			allRolesInfo: "Randomly choose from all 9 non-Dealer characters.",
			starterRolesInfo: "Randomly choose from Prophet, Gambler, Giant, Frenemy and Supercomputer.",
			tieResult: "The card is {{n}}",
			tieChoice: "Secret guess submitted",
			finalBase: "Hand points: {{n}}",
			finalBonus: "Character rewards: {{n}}"
		}
	}
};
//#endregion
export { Te as default };
