import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useLayoutEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { BottomSheet as u } from "@bgparty/sdk/bottom-sheet";
import { DeltaNumber as ee } from "@bgparty/sdk/fx/delta-number";
import { Texture as d } from "@bgparty/sdk/texture";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as p } from "@bgparty/sdk/ui/player-strip";
import { useFxAnchor as m, useFxAnchorsMaybe as te } from "@bgparty/sdk/fx/anchors";
import { usePrefersReducedMotion as ne } from "@bgparty/sdk/fx/use-reduced-motion";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { IconClose as re, IconInfo as v } from "@bgparty/sdk/icons";
import { Floater as y, PulseBox as b } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as ie } from "@bgparty/sdk/confirm-button";
import { OptionSection as ae, OptionSwitch as oe } from "@bgparty/sdk/ui/game-options";
//#region src/games/underwatercities/effects.ts
var x = [
	"credit",
	"kelp",
	"steel",
	"science",
	"bio",
	"point"
], se = () => ({
	credit: 0,
	kelp: 0,
	steel: 0,
	science: 0,
	bio: 0,
	point: 0
}), S = (e) => ({
	kind: "gain",
	gain: e
}), C = (...e) => ({
	kind: "all",
	effects: e
}), w = (...e) => ({
	kind: "choice",
	options: e
}), T = (e, t) => ({
	kind: "pay",
	cost: e,
	then: t
}), E = (e, t, n) => ({
	kind: "if",
	condition: {
		metric: e,
		min: t
	},
	then: n
}), D = (e) => ({
	kind: "if",
	condition: {
		metric: "federation",
		equal: 3
	},
	then: e
}), O = (e, t = 1, n = {}) => ({
	kind: "build",
	structures: e,
	count: t,
	...n
}), k = (e = [
	"farm",
	"desal",
	"lab",
	"tunnel"
], t = 1, n = { science: 1 }) => ({
	kind: "upgrade",
	structures: e,
	count: t,
	cost: n
}), A = (e = 1, t = !1) => ({
	kind: "use",
	count: e,
	keep: t
}), ce = (e = 1) => ({
	kind: "refresh",
	count: e
}), j = (e, t) => ({
	kind: "mission",
	mode: e,
	color: t
}), le = () => ({ kind: "special" }), M = [
	"farm",
	"desal",
	"lab"
], N = [...M, "tunnel"], P = ["white", "purple"], F = [
	[0, 1],
	[1, 2],
	[6, 7],
	[7, 8],
	[0, 3],
	[3, 6],
	[2, 5],
	[5, 8],
	[0, 4],
	[2, 4],
	[6, 4],
	[8, 4],
	[0, 9],
	[0, 9],
	[2, 10],
	[6, 11]
], ue = [
	[180, 110],
	[410, 110],
	[640, 110],
	[180, 350],
	[410, 350],
	[640, 350],
	[180, 590],
	[410, 590],
	[640, 590]
], I = [
	[
		{ steel: 1 },
		{},
		{},
		{ science: 1 },
		{},
		{ federation: 1 },
		{ steel: 1 }
	],
	[
		{ kelp: 1 },
		{},
		{},
		{ steel: 1 },
		{ federation: 1 },
		{ federation: 1 },
		{ kelp: 1 }
	],
	[
		{ kelp: 1 },
		{ federation: 1 },
		{ kelp: 1 },
		{},
		{ science: 1 },
		{},
		{},
		{ steel: 1 }
	],
	[
		{ federation: 1 },
		{},
		{},
		{ steel: 1 },
		{},
		{ kelp: 1 },
		{ science: 1 }
	]
];
function L(e) {
	let t = {
		id: e,
		regular: Array(9).fill(3),
		expansion: Array(9).fill(!0),
		city: {},
		building: {},
		tunnel: {}
	};
	return e <= 4 ? (t.expansion[7] = !1, t.city[4] = { bonus: {
		federation: 1,
		card: 1
	} }, I[e - 1].forEach((e, n) => {
		Object.keys(e).length && (t.tunnel[n] = { bonus: e });
	})) : e === 5 ? (t.regular[4] = 4, t.expansion[7] = !1, t.city[4] = { bonus: { federation: 1 } }, t.city[6] = {
		cost: {
			credit: 3,
			kelp: 1
		},
		production: { point: 3 }
	}, t.building["2:2"] = {
		cost: { steel: 1 },
		multiplier: 2
	}, t.building["5:0"] = { bonus: { steel: 1 } }, t.building["5:1"] = {
		cost: { kelp: 1 },
		multiplier: 2
	}, t.tunnel = {
		1: { bonus: { federation: 1 } },
		8: { bonus: { kelp: 1 } },
		5: { bonus: { science: 1 } },
		14: { bonus: { point: 2 } }
	}) : e === 6 ? (t.regular[3] = 4, t.city[5] = { bonus: { federation: 1 } }, t.city[2] = {
		cost: {
			steel: 3,
			credit: 3
		},
		multiplier: 3
	}, t.building["3:0"] = { cost: { credit: 1 } }, t.building["0:2"] = {
		cost: { steel: 1 },
		multiplier: 2
	}, t.building["7:2"] = { bonus: { steel: 1 } }, t.tunnel = {
		8: {
			cost: { credit: 1 },
			production: { point: 2 }
		},
		11: { production: { credit: 2 } },
		5: { bonus: { science: 1 } },
		2: { bonus: { kelp: 1 } },
		3: { bonus: { federation: 1 } }
	}) : e === 7 ? (t.regular[1] = 2, t.regular[8] = 1, t.building["1:0"] = { bonus: { science: 1 } }, t.building["4:1"] = { bonus: { science: 1 } }, t.building["7:1"] = { bonus: { credit: 1 } }, t.city[4] = { bonus: {
		credit: 1,
		steel: 1
	} }, t.city[3] = {
		cost: {
			science: 2,
			credit: 2
		},
		bonus: { point: 6 }
	}, t.tunnel = {
		1: {
			cost: { credit: 1 },
			multiplier: 3
		},
		14: {
			cost: {
				credit: 1,
				steel: 1
			},
			production: { point: 2 }
		},
		2: {
			cost: { steel: 1 },
			production: { kelp: 1 }
		},
		5: { bonus: { federation: 1 } },
		7: { bonus: { credit: 1 } }
	}) : (t.regular[5] = 4, t.regular[7] = 2, t.city[4] = { bonus: {
		credit: 1,
		steel: 1
	} }, t.city[7] = { bonus: { credit: 1 } }, t.city[1] = {
		cost: { credit: 5 },
		bonus: { point: 5 }
	}, t.building["5:1"] = {
		cost: { science: 1 },
		production: {
			credit: 1,
			point: 1
		}
	}, t.building["7:1"] = { production: { kelp: 1 } }, t.tunnel = {
		9: {
			cost: { steel: 1 },
			production: { science: 1 }
		},
		5: {
			cost: {
				kelp: 1,
				bio: 1
			},
			multiplier: 3
		},
		2: { bonus: { kelp: 1 } }
	}), t;
}
function R(e) {
	let t = e <= 2 ? [
		["g", [
			O(["desal"], 2),
			O(P),
			S({ federation: 2 }),
			C(S({ card: 2 }), w(k(), S({ kelp: 1 })))
		]],
		["r", [
			le(),
			S({
				steel: 2,
				kelp: 1
			}),
			C(O(["tunnel"]), A()),
			w(O(["farm"], 2), O(["lab"], 2))
		]],
		["y", [
			C(A(), w(S({
				kelp: 1,
				steel: 1
			}), S({
				kelp: 1,
				science: 1
			}), S({
				steel: 1,
				science: 1
			}))),
			O(["tunnel"], 2),
			w(S({ science: 2 }), {
				...k(N, 3),
				mode: "main"
			}),
			C(O(P), O(M))
		]]
	] : [
		["g", [
			S({ federation: 2 }),
			O(["desal"], 2),
			w(O(P), S({ kelp: 1 })),
			w(O(["tunnel"]), S({
				federation: 1,
				card: 2,
				credit: 1
			})),
			C(A(), S({ steel: 1 }))
		]],
		["r", [
			O(["lab"], 2),
			S({
				steel: 2,
				kelp: 1
			}),
			C(O(["tunnel"]), O(P)),
			O(["farm"], 2),
			C(A(), O(N, 1, { after: { kind: "upgradeBuilt" } }))
		]],
		["y", [
			S({
				kelp: 1,
				steel: 1,
				science: 1
			}),
			O(["tunnel"], 2),
			C(A(), le()),
			w(S({ science: 2 }), {
				...k(N, 3),
				mode: "main"
			}),
			C(O(P), O(M))
		]]
	], n = 0;
	return [...t.flatMap(([e, t]) => t.map((t) => ({
		id: n++,
		color: e,
		effect: t
	}))), {
		id: n,
		color: "n",
		effect: S({
			card: 2,
			credit: 2
		})
	}];
}
var de = [
	{
		instant: {
			point: 2,
			steel: 3
		},
		production: {}
	},
	{
		instant: {
			credit: 4,
			point: 1
		},
		production: {}
	},
	{
		instant: {
			federation: 3,
			credit: 1
		},
		production: {}
	},
	{
		instant: { kelp: 1 },
		production: { point: 2 }
	},
	{
		instant: {
			federation: 1,
			kelp: 3,
			card: 1
		},
		production: {}
	},
	{
		instant: { bio: 2 },
		production: {}
	},
	{
		instant: {
			steel: 1,
			science: 1
		},
		production: { point: 1 }
	},
	{
		instant: {
			steel: 1,
			credit: 1,
			card: 2
		},
		production: { point: 1 }
	},
	{
		instant: { federation: 1 },
		production: { point: 2 }
	},
	{
		instant: {
			federation: 1,
			credit: 2,
			kelp: 1,
			steel: 1,
			card: 1
		},
		production: {}
	},
	{
		instant: {
			steel: 1,
			card: 1
		},
		production: { point: 2 }
	}
], fe = {
	0: {
		color: "n",
		type: "a",
		name: "Personal Assistant",
		nameZh: "私人助理",
		ruleEn: "Gain steel1 OR credit1."
	},
	66: {
		color: "y",
		type: "d",
		name: "Improvised Greenhouse",
		nameZh: "临时温室",
		ruleEn: "One upgraded connected tunnel may produce credit1 kelp1 science1 instead of credit1 point1."
	},
	65: {
		color: "y",
		type: "a",
		name: "Organize a Conference",
		nameZh: "组织会议",
		ruleEn: "Pay credit1 OR science1 to upgrade lab1."
	},
	64: {
		color: "y",
		type: "p",
		name: "Embassy",
		nameZh: "大使馆",
		ruleEn: "When build second farm in same turn federation1."
	},
	57: {
		color: "y",
		type: "d",
		name: "Sea Vent Factory",
		nameZh: "海底热泉工厂",
		ruleEn: "credit1."
	},
	56: {
		color: "y",
		type: "a",
		name: "Invite Investors",
		nameZh: "邀请投资者",
		ruleEn: "point1 credit1."
	},
	55: {
		color: "y",
		type: "a",
		name: "Build City",
		nameZh: "建造城市",
		ruleEn: "Build city1 usual cost."
	},
	54: {
		color: "y",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay kelp1 gain credit3."
	},
	53: {
		color: "y",
		type: "i",
		name: "Steelplast Reclamation",
		nameZh: "回收钢塑",
		ruleEn: "If connected cities>=2 gain steel1."
	},
	52: {
		color: "y",
		type: "i",
		name: "Synthetic Food",
		nameZh: "合成食品",
		ruleEn: "If connected labs>=2 gain kelp1."
	},
	51: {
		color: "y",
		type: "i",
		name: "Rush Job",
		nameZh: "加急工程",
		ruleEn: "Build desal1 usual cost."
	},
	50: {
		color: "y",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay steel1 gain credit2."
	},
	49: {
		color: "y",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay credit1 gain kelp1."
	},
	48: {
		color: "y",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Exchange kelp1 for steel1 OR vice versa."
	},
	47: {
		color: "y",
		type: "i",
		name: "Lobbyist",
		nameZh: "游说者",
		ruleEn: "card1 federation1."
	},
	46: {
		color: "y",
		type: "i",
		name: "Motivational Speech",
		nameZh: "动员演说",
		ruleEn: "Refresh used action1."
	},
	45: {
		color: "y",
		type: "i",
		name: "Federal Grant",
		nameZh: "联邦拨款",
		ruleEn: "credit1."
	},
	44: {
		color: "r",
		type: "a",
		name: "Shop on the Black Market",
		nameZh: "黑市采购",
		ruleEn: "Pay steel1 gain bio1."
	},
	43: {
		color: "r",
		type: "a",
		name: "Organize a Conference",
		nameZh: "组织会议",
		ruleEn: "Pay science1 OR credit1 to upgrade desal1."
	},
	42: {
		color: "r",
		type: "d",
		name: "Sea Vent Factory",
		nameZh: "海底热泉工厂",
		ruleEn: "steel1."
	},
	41: {
		color: "r",
		type: "a",
		name: "Scavenge the Seafloor",
		nameZh: "海底拾荒",
		ruleEn: "card2 kelp1."
	},
	40: {
		color: "r",
		type: "p",
		name: "Black Ops Team",
		nameZh: "秘密行动小组",
		ruleEn: "When card color mismatches slot gain credit1 excluding always-available slot."
	},
	39: {
		color: "r",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay steel1 gain credit1 science1."
	},
	38: {
		color: "r",
		type: "p",
		name: "Lobbying Office",
		nameZh: "游说办公室",
		ruleEn: "When build second tunnel in same turn federation1."
	},
	37: {
		color: "r",
		type: "p",
		name: "Biomech Construction Crew",
		nameZh: "生物机械施工队",
		ruleEn: "Whenever build connected city's second lab gain credit1."
	},
	36: {
		color: "r",
		type: "d",
		name: "Autonomous Systems",
		nameZh: "自动化系统",
		ruleEn: "One connected lab may produce steel1 kelp1 instead of science1. Upgraded still produces additional steel1."
	},
	35: {
		color: "r",
		type: "p",
		name: "Embassy",
		nameZh: "大使馆",
		ruleEn: "Whenever reach third federation space gain extra credit1."
	},
	34: {
		color: "r",
		type: "a",
		name: "Build Farm or Desalination Plant",
		nameZh: "建造农场或脱盐厂",
		ruleEn: "Build farm1 OR desal1 usual cost; card1."
	},
	62: {
		color: "y",
		type: "p",
		name: "Black Ops Team",
		nameZh: "秘密行动小组",
		ruleEn: "When card color mismatches slot gain card1 excluding always-available slot."
	},
	63: {
		color: "y",
		type: "a",
		name: "Build Tunnel",
		nameZh: "建造隧道",
		ruleEn: "Pay steel1 build tunnel1."
	},
	61: {
		color: "y",
		type: "p",
		name: "Biomech Construction Crew",
		nameZh: "生物机械施工队",
		ruleEn: "Once per turn when upgrade tunnel gain credit1."
	},
	60: {
		color: "y",
		type: "p",
		name: "Intel Expert",
		nameZh: "情报专家",
		ruleEn: "At end of turn before draw may pay credit1 draw card2 additional."
	},
	59: {
		color: "y",
		type: "p",
		name: "Biomech Construction Crew",
		nameZh: "生物机械施工队",
		ruleEn: "Whenever complete connected city's second upgraded farm gain steel1."
	},
	58: {
		color: "y",
		type: "p",
		name: "Biomech Construction Crew",
		nameZh: "生物机械施工队",
		ruleEn: "Whenever build connected city's second desal gain credit1."
	},
	31: {
		color: "r",
		type: "i",
		name: "Sale of Technology",
		nameZh: "出售技术",
		ruleEn: "Pay science1 gain kelp2."
	},
	32: {
		color: "r",
		type: "i",
		name: "Biomech Test",
		nameZh: "生物机械试验",
		ruleEn: "Build city1 with credit1 discount."
	},
	33: {
		color: "r",
		type: "a",
		name: "Build Tunnel",
		nameZh: "建造隧道",
		ruleEn: "Pay credit2 build tunnel1."
	},
	30: {
		color: "r",
		type: "i",
		name: "Lobbyist",
		nameZh: "游说者",
		ruleEn: "If federation==3 may pay credit1 build tunnel1."
	},
	29: {
		color: "r",
		type: "i",
		name: "Lobbyist",
		nameZh: "游说者",
		ruleEn: "credit1 federation1."
	},
	28: {
		color: "r",
		type: "i",
		name: "Seafood Collection",
		nameZh: "收集海产",
		ruleEn: "If upgraded tunnel adjacent connected city>=1 gain kelp1."
	},
	27: {
		color: "r",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay credit1 gain card1 science1."
	},
	26: {
		color: "r",
		type: "i",
		name: "Survey",
		nameZh: "勘察",
		ruleEn: "Build farm1 expansion site usual cost."
	},
	25: {
		color: "r",
		type: "i",
		name: "Federal Grant",
		nameZh: "联邦拨款",
		ruleEn: "kelp1."
	},
	24: {
		color: "r",
		type: "i",
		name: "Technology Negotiation",
		nameZh: "技术谈判",
		ruleEn: "Pay science1 OR steel1 upgrade desal1."
	},
	23: {
		color: "r",
		type: "i",
		name: "Federal Grant",
		nameZh: "联邦拨款",
		ruleEn: "credit2."
	},
	22: {
		color: "g",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay credit1 gain bio1."
	},
	21: {
		color: "g",
		type: "a",
		name: "Organize a Conference",
		nameZh: "组织会议",
		ruleEn: "Upgrade up to2 structures science1 each."
	},
	20: {
		color: "g",
		type: "p",
		name: "Artificial Intelligence",
		nameZh: "人工智能",
		ruleEn: "When use main upgrade slot to upgrade3 may pay science2 total instead of3."
	},
	19: {
		color: "g",
		type: "a",
		name: "Build a Structure",
		nameZh: "建造设施",
		ruleEn: "Build structure1 usual cost; federation1."
	},
	18: {
		color: "g",
		type: "p",
		name: "Personnel Agency",
		nameZh: "人事机构",
		ruleEn: "Special card play credit1 discount."
	},
	17: {
		color: "g",
		type: "i",
		name: "Industrial Espionage",
		nameZh: "工业间谍",
		ruleEn: "card2 science1."
	},
	16: {
		color: "g",
		type: "d",
		name: "Synthetic Food",
		nameZh: "合成食品",
		ruleEn: "kelp1 per3 connected labs."
	},
	15: {
		color: "g",
		type: "p",
		name: "Biomech Construction Crew",
		nameZh: "生物机械施工队",
		ruleEn: "Once per turn when upgrade tunnel gain steel1."
	},
	14: {
		color: "g",
		type: "p",
		name: "Black Ops Team",
		nameZh: "秘密行动小组",
		ruleEn: "When card color mismatches slot gain steel1 excluding always-available slot."
	},
	13: {
		color: "g",
		type: "d",
		name: "Autonomous Systems",
		nameZh: "自动化系统",
		ruleEn: "credit1 per connected city with>=2 desal."
	},
	12: {
		color: "g",
		type: "a",
		name: "Organize a Conference",
		nameZh: "组织会议",
		ruleEn: "card1 credit1 science1."
	},
	11: {
		color: "g",
		type: "a",
		name: "Scavenge the Seafloor",
		nameZh: "海底拾荒",
		ruleEn: "steel1 kelp1."
	},
	10: {
		color: "g",
		type: "i",
		name: "Survey",
		nameZh: "勘察",
		ruleEn: "Build farm1 OR desal1 expansion site usual cost."
	},
	8: {
		color: "g",
		type: "i",
		name: "Trial Run",
		nameZh: "试运行",
		ruleEn: "If connected upgraded lab>=1 gain steel1 science1."
	},
	9: {
		color: "g",
		type: "i",
		name: "Technology Negotiation",
		nameZh: "技术谈判",
		ruleEn: "Pay credit1 upgrade farm1."
	},
	7: {
		color: "g",
		type: "i",
		name: "Lobbyist",
		nameZh: "游说者",
		ruleEn: "federation2."
	},
	4: {
		color: "g",
		type: "i",
		name: "Trial Run",
		nameZh: "试运行",
		ruleEn: "If connected upgraded desal>=1 gain bio1."
	},
	5: {
		color: "g",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay credit1 gain steel2 card1."
	},
	6: {
		color: "g",
		type: "i",
		name: "Construction Windfall",
		nameZh: "意外工程机会",
		ruleEn: "If connected desal>=3 build tunnel1 free."
	},
	1: {
		color: "g",
		type: "i",
		name: "Extraordinary Mission",
		nameZh: "特别任务",
		ruleEn: "Pay credit1 perform any available slot."
	},
	2: {
		color: "g",
		type: "i",
		name: "Federal Grant",
		nameZh: "联邦拨款",
		ruleEn: "credit2 card1."
	},
	3: {
		color: "g",
		type: "i",
		name: "Repeatable Mission",
		nameZh: "重复任务",
		ruleEn: "Pay credit1 perform another player's occupied slot except always-available."
	},
	123: {
		color: "y",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay kelp1 gain bio1."
	},
	122: {
		color: "y",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay credit1 gain kelp1 OR steel1."
	},
	121: {
		color: "y",
		type: "p",
		name: "Black Market",
		nameZh: "黑市",
		ruleEn: "Whenever use action card may exchange steel1 for science1 OR vice versa."
	},
	118: {
		color: "y",
		type: "p",
		name: "Black Market",
		nameZh: "黑市",
		ruleEn: "Once per turn may pay credit1 to exchange kelp1 for steel1 OR vice versa."
	},
	119: {
		color: "y",
		type: "p",
		name: "Free Trade Tunnel",
		nameZh: "自由贸易隧道",
		ruleEn: "Once per turn when upgrade tunnel may pay credit1 gain point1 card1."
	},
	120: {
		color: "y",
		type: "p",
		name: "Personnel Agency",
		nameZh: "人事机构",
		ruleEn: "Whenever claim permanent card including itself gain credit1."
	},
	115: {
		color: "y",
		type: "a",
		name: "Organize a Conference",
		nameZh: "组织会议",
		ruleEn: "Pay science1 OR credit1 upgrade farm1."
	},
	116: {
		color: "y",
		type: "a",
		name: "Organize a Conference",
		nameZh: "组织会议",
		ruleEn: "Pay science1 OR credit1 upgrade tunnel1."
	},
	117: {
		color: "y",
		type: "d",
		name: "Genetics Lab",
		nameZh: "遗传实验室",
		ruleEn: "One produced bio may exchange for steel1 point1 credit1."
	},
	112: {
		color: "y",
		type: "i",
		name: "Technology Negotiation",
		nameZh: "技术谈判",
		ruleEn: "Pay science1 upgrade lab1."
	},
	113: {
		color: "y",
		type: "i",
		name: "Trial Run",
		nameZh: "试运行",
		ruleEn: "If connected labs>=3 gain steel1."
	},
	114: {
		color: "y",
		type: "i",
		name: "Lobbyist",
		nameZh: "游说者",
		ruleEn: "If federation==3 gain steel2."
	},
	69: {
		color: "g",
		type: "i",
		name: "Demonstration",
		nameZh: "示范",
		ruleEn: "Use action1."
	},
	68: {
		color: "g",
		type: "i",
		name: "Federal Grant",
		nameZh: "联邦拨款",
		ruleEn: "credit1 steel1."
	},
	67: {
		color: "g",
		type: "i",
		name: "Survey",
		nameZh: "勘察",
		ruleEn: "Build lab1 OR farm1 expansion usual cost."
	},
	72: {
		color: "g",
		type: "i",
		name: "Sale of Technology",
		nameZh: "出售技术",
		ruleEn: "Pay science1 gain card2 credit3."
	},
	71: {
		color: "g",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay kelp1 gain science1 credit2."
	},
	70: {
		color: "g",
		type: "i",
		name: "Trial Run",
		nameZh: "试运行",
		ruleEn: "If connected upgraded labs>=2 gain science1 steel1 card1."
	},
	75: {
		color: "g",
		type: "i",
		name: "Motivational Speech",
		nameZh: "动员演说",
		ruleEn: "Refresh up to2 used actions."
	},
	74: {
		color: "g",
		type: "i",
		name: "Corruption",
		nameZh: "行贿",
		ruleEn: "Pay kelp1 gain federation3."
	},
	73: {
		color: "g",
		type: "i",
		name: "Construction Windfall",
		nameZh: "意外工程机会",
		ruleEn: "If connected farms>=4 build tunnel1 free."
	},
	78: {
		color: "g",
		type: "a",
		name: "Invite Investors",
		nameZh: "邀请投资者",
		ruleEn: "credit2 steel1."
	},
	77: {
		color: "g",
		type: "a",
		name: "Organize a Conference",
		nameZh: "组织会议",
		ruleEn: "point1 science1."
	},
	76: {
		color: "g",
		type: "i",
		name: "Organic Fusion",
		nameZh: "有机融合",
		ruleEn: "Pay credit1 science1 convert nonsymbiotic city to symbiotic."
	},
	81: {
		color: "g",
		type: "p",
		name: "Coral Tunnels",
		nameZh: "珊瑚隧道",
		ruleEn: "Once per turn build tunnel credit1 discount."
	},
	80: {
		color: "g",
		type: "d",
		name: "Food Labs",
		nameZh: "食品实验室",
		ruleEn: "kelp1 per2 connected upgraded labs."
	},
	79: {
		color: "g",
		type: "p",
		name: "Black Market",
		nameZh: "黑市",
		ruleEn: "Once per turn may pay credit1 gain steel1."
	},
	84: {
		color: "g",
		type: "i",
		name: "Technology Negotiation",
		nameZh: "技术谈判",
		ruleEn: "Pay science1 steel1 upgrade tunnel2."
	},
	83: {
		color: "g",
		type: "p",
		name: "Building Printer",
		nameZh: "建筑打印机",
		ruleEn: "When use city+building slot may build additional building1 usual cost."
	},
	82: {
		color: "g",
		type: "d",
		name: "Autonomous Systems",
		nameZh: "自动化系统",
		ruleEn: "bio1 per connected city with>=2 upgraded desals."
	},
	87: {
		color: "r",
		type: "i",
		name: "Biomech Test",
		nameZh: "生物机械试验",
		ruleEn: "Pay science1 build tunnel1."
	},
	86: {
		color: "r",
		type: "i",
		name: "Filtration Recycling",
		nameZh: "过滤回收",
		ruleEn: "steel1 per2 connected desals."
	},
	85: {
		color: "g",
		type: "a",
		name: "Night Shift",
		nameZh: "夜班",
		ruleEn: "If connected upgraded desals>=1 gain credit1 bio1."
	},
	90: {
		color: "r",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay credit1 gain card1 science1."
	},
	89: {
		color: "r",
		type: "i",
		name: "Industrial Espionage",
		nameZh: "工业间谍",
		ruleEn: "card2 credit1."
	},
	88: {
		color: "r",
		type: "i",
		name: "Construction Windfall",
		nameZh: "意外工程机会",
		ruleEn: "If connected cities>=4 build farm1 free."
	},
	93: {
		color: "r",
		type: "i",
		name: "Extraordinary Mission",
		nameZh: "特别任务",
		ruleEn: "Pay credit2 perform any available slot."
	},
	92: {
		color: "r",
		type: "i",
		name: "Reproduction Systems Test",
		nameZh: "繁殖系统试验",
		ruleEn: "If kelp>=2 gain kelp1."
	},
	91: {
		color: "r",
		type: "i",
		name: "Federal Grant",
		nameZh: "联邦拨款",
		ruleEn: "steel1."
	},
	96: {
		color: "r",
		type: "a",
		name: "Invite Investors",
		nameZh: "邀请投资者",
		ruleEn: "point2."
	},
	95: {
		color: "r",
		type: "i",
		name: "Lobbyist",
		nameZh: "游说者",
		ruleEn: "federation1 card2."
	},
	94: {
		color: "r",
		type: "i",
		name: "Repeatable Mission",
		nameZh: "重复任务",
		ruleEn: "Pay credit2 perform another player's occupied slot except always-available."
	},
	99: {
		color: "r",
		type: "i",
		name: "Kelp Research",
		nameZh: "海带研究",
		ruleEn: "If kelp>=2 gain science1 card1."
	},
	98: {
		color: "r",
		type: "p",
		name: "Undersea Server Farm",
		nameZh: "海底服务器中心",
		ruleEn: "hand limit+1."
	},
	97: {
		color: "r",
		type: "a",
		name: "Scavenge the Seafloor",
		nameZh: "海底拾荒",
		ruleEn: "credit1 kelp1."
	},
	102: {
		color: "r",
		type: "p",
		name: "Consumer Goods Research",
		nameZh: "消费品研究",
		ruleEn: "Once per turn when build lab may pay credit1 gain point1 card2."
	},
	101: {
		color: "r",
		type: "p",
		name: "Genetics Lab",
		nameZh: "遗传实验室",
		ruleEn: "Once per turn may pay bio1 gain kelp1 steel1."
	},
	100: {
		color: "r",
		type: "p",
		name: "Cost Analysis",
		nameZh: "成本分析",
		ruleEn: "Whenever build symbiotic city credit1 discount."
	},
	105: {
		color: "y",
		type: "i",
		name: "Trial Run",
		nameZh: "试运行",
		ruleEn: "If connected upgraded desals>=2 gain card1 point1."
	},
	104: {
		color: "r",
		type: "d",
		name: "Greenhouse",
		nameZh: "温室",
		ruleEn: "At feeding one city requires no kelp."
	},
	103: {
		color: "r",
		type: "p",
		name: "Genetics Lab",
		nameZh: "遗传实验室",
		ruleEn: "Once per turn when upgrade farm may pay credit1 gain kelp1."
	},
	108: {
		color: "y",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay credit1 gain science1."
	},
	107: {
		color: "y",
		type: "i",
		name: "Lobbyist",
		nameZh: "游说者",
		ruleEn: "federation1."
	},
	106: {
		color: "y",
		type: "i",
		name: "Industrial Espionage",
		nameZh: "工业间谍",
		ruleEn: "card3."
	},
	111: {
		color: "y",
		type: "i",
		name: "Rush Job",
		nameZh: "加急工程",
		ruleEn: "Build lab1 OR farm1 usual cost."
	},
	110: {
		color: "y",
		type: "i",
		name: "Duplication Systems Test",
		nameZh: "复制系统试验",
		ruleEn: "If steel>=2 gain steel1."
	},
	109: {
		color: "y",
		type: "i",
		name: "Construction Windfall",
		nameZh: "意外工程机会",
		ruleEn: "If connected desals>=5 build farm1 free."
	},
	126: {
		color: "g",
		type: "i",
		name: "Trial Run",
		nameZh: "试运行",
		ruleEn: "If connected upgraded farms>=1 gain kelp1 point1."
	},
	125: {
		color: "g",
		type: "i",
		name: "Biomech Test",
		nameZh: "生物机械试验",
		ruleEn: "Build city1 discount credit1 kelp1."
	},
	124: {
		color: "g",
		type: "i",
		name: "Demonstration",
		nameZh: "示范",
		ruleEn: "Pay credit1 use up to2 actions."
	},
	129: {
		color: "g",
		type: "i",
		name: "Survey",
		nameZh: "勘察",
		ruleEn: "Build any building1 expansion usual cost."
	},
	128: {
		color: "g",
		type: "i",
		name: "Special Delivery",
		nameZh: "特别递送",
		ruleEn: "Pay credit1 gain point2 card1."
	},
	127: {
		color: "g",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay credit1 gain kelp1 steel1 card1."
	},
	132: {
		color: "g",
		type: "i",
		name: "Technology Negotiation",
		nameZh: "技术谈判",
		ruleEn: "Upgrade up to2 farms each pay credit1 OR science1."
	},
	131: {
		color: "g",
		type: "i",
		name: "Free Trade Partners",
		nameZh: "自由贸易伙伴",
		ruleEn: "point1 per connected metropolis."
	},
	130: {
		color: "g",
		type: "i",
		name: "Sale of Technology",
		nameZh: "出售技术",
		ruleEn: "Pay science1 gain kelp1 card2 point1."
	},
	135: {
		color: "g",
		type: "a",
		name: "Build and Upgrade Tunnel",
		nameZh: "建造并升级隧道",
		ruleEn: "Pay credit1 science1 build tunnel1 then upgrade it."
	},
	134: {
		color: "g",
		type: "i",
		name: "Biomech Test",
		nameZh: "生物机械试验",
		ruleEn: "Pay credit1 build tunnel1."
	},
	133: {
		color: "g",
		type: "i",
		name: "Extraordinary Mission",
		nameZh: "特别任务",
		ruleEn: "Pay credit1 perform available yellow slot."
	},
	138: {
		color: "g",
		type: "e",
		name: "Exports",
		nameZh: "出口",
		ruleEn: "May spend science1 steel1 per point1 unlimited."
	},
	137: {
		color: "g",
		type: "p",
		name: "Consumer Goods Research",
		nameZh: "消费品研究",
		ruleEn: "Whenever action slot gives >=1 steel gain point1."
	},
	136: {
		color: "g",
		type: "p",
		name: "Lobbying Office",
		nameZh: "游说办公室",
		ruleEn: "Once per turn when build tunnel federation2."
	},
	141: {
		color: "g",
		type: "a",
		name: "Build and Upgrade Farm",
		nameZh: "建造并升级农场",
		ruleEn: "Pay bio1 build farm1 then upgrade it."
	},
	140: {
		color: "g",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay credit1 gain science1 point1."
	},
	139: {
		color: "g",
		type: "i",
		name: "Quick Demonstration",
		nameZh: "快速示范",
		ruleEn: "Use action1 keep it available afterwards."
	},
	144: {
		color: "r",
		type: "i",
		name: "Lobbyist",
		nameZh: "游说者",
		ruleEn: "If federation==3 build city1 discount steel1."
	},
	143: {
		color: "r",
		type: "i",
		name: "Smuggling",
		nameZh: "走私",
		ruleEn: "Pay kelp1 gain steel2 card1."
	},
	142: {
		color: "g",
		type: "e",
		name: "Exports",
		nameZh: "出口",
		ruleEn: "May spend bio1 per point1 unlimited."
	},
	147: {
		color: "r",
		type: "i",
		name: "Sale of Technology",
		nameZh: "出售技术",
		ruleEn: "Pay science1 gain kelp1 point1."
	},
	146: {
		color: "r",
		type: "i",
		name: "Construction Windfall",
		nameZh: "意外工程机会",
		ruleEn: "If connected cities>=5 build desal1 free."
	},
	145: {
		color: "r",
		type: "i",
		name: "Demonstration",
		nameZh: "示范",
		ruleEn: "Pay credit1 use action1."
	},
	150: {
		color: "r",
		type: "i",
		name: "Extraordinary Mission",
		nameZh: "特别任务",
		ruleEn: "Pay credit1 perform available green slot."
	},
	149: {
		color: "r",
		type: "i",
		name: "Special Delivery",
		nameZh: "特别递送",
		ruleEn: "Pay kelp1 gain point2."
	},
	148: {
		color: "r",
		type: "i",
		name: "Corruption",
		nameZh: "行贿",
		ruleEn: "Pay credit1 gain federation2."
	},
	153: {
		color: "r",
		type: "i",
		name: "Industrial Espionage",
		nameZh: "工业间谍",
		ruleEn: "Gain point1 OR card3."
	},
	152: {
		color: "r",
		type: "i",
		name: "Free Trade Network",
		nameZh: "自由贸易网络",
		ruleEn: "If upgraded tunnels adjacent connected cities>=3 gain point2."
	},
	151: {
		color: "r",
		type: "i",
		name: "Survey",
		nameZh: "勘察",
		ruleEn: "Build desal1 expansion usual cost."
	},
	156: {
		color: "r",
		type: "p",
		name: "Coral Tunnels",
		nameZh: "珊瑚隧道",
		ruleEn: "When build second tunnel of turn it is free."
	},
	155: {
		color: "r",
		type: "e",
		name: "Exports",
		nameZh: "出口",
		ruleEn: "May spend science1 kelp1 per point1 unlimited."
	},
	154: {
		color: "r",
		type: "a",
		name: "Build City",
		nameZh: "建造城市",
		ruleEn: "Build city1 discount kelp1."
	},
	159: {
		color: "r",
		type: "i",
		name: "Biomech Test",
		nameZh: "生物机械试验",
		ruleEn: "Build tunnel1 usual cost."
	},
	158: {
		color: "r",
		type: "a",
		name: "Build Expansion",
		nameZh: "建造扩建设施",
		ruleEn: "Pay credit2 build any building1 expansion."
	},
	157: {
		color: "r",
		type: "e",
		name: "Exports",
		nameZh: "出口",
		ruleEn: "May spend steel1 kelp1 per point1 unlimited."
	},
	162: {
		color: "y",
		type: "i",
		name: "Repeatable Mission",
		nameZh: "重复任务",
		ruleEn: "Pay credit2 perform another player's occupied red slot."
	},
	161: {
		color: "r",
		type: "i",
		name: "Corruption",
		nameZh: "行贿",
		ruleEn: "Pay science1 gain federation2."
	},
	160: {
		color: "r",
		type: "i",
		name: "Technology Negotiation",
		nameZh: "技术谈判",
		ruleEn: "Pay credit2 science1 build farm1 then upgrade it."
	},
	165: {
		color: "y",
		type: "i",
		name: "Special Delivery",
		nameZh: "特别递送",
		ruleEn: "Pay credit1 gain point1 card1."
	},
	164: {
		color: "y",
		type: "i",
		name: "Industrial Espionage",
		nameZh: "工业间谍",
		ruleEn: "Gain credit1 OR card2."
	},
	163: {
		color: "y",
		type: "i",
		name: "Replication Systems Test",
		nameZh: "复制系统试验",
		ruleEn: "If steel>=3 gain steel1."
	},
	168: {
		color: "y",
		type: "i",
		name: "Federal Grant",
		nameZh: "联邦拨款",
		ruleEn: "bio1."
	},
	167: {
		color: "y",
		type: "i",
		name: "Sale of Technology",
		nameZh: "出售技术",
		ruleEn: "Pay science1 gain point1 credit1 card1."
	},
	166: {
		color: "y",
		type: "a",
		name: "Invite Emissary",
		nameZh: "邀请使节",
		ruleEn: "federation1 point1."
	},
	171: {
		color: "y",
		type: "i",
		name: "Biomech Test",
		nameZh: "生物机械试验",
		ruleEn: "Pay steel3 build city1."
	},
	170: {
		color: "y",
		type: "i",
		name: "Nanogrille Online",
		nameZh: "纳米网络上线",
		ruleEn: "If connected symbiotic cities>=2 gain point1."
	},
	169: {
		color: "y",
		type: "i",
		name: "Technology Negotiation",
		nameZh: "技术谈判",
		ruleEn: "Pay science1 credit1 upgrade tunnel2."
	},
	174: {
		color: "y",
		type: "p",
		name: "Embassy",
		nameZh: "大使馆",
		ruleEn: "Once per turn when advance federation gain steel1 card1."
	},
	173: {
		color: "y",
		type: "a",
		name: "Night Shift",
		nameZh: "夜班",
		ruleEn: "Gain production of1 upgraded structure adjacent connected city."
	},
	172: {
		color: "y",
		type: "i",
		name: "Corruption",
		nameZh: "行贿",
		ruleEn: "Pay kelp1 gain federation2."
	},
	177: {
		color: "y",
		type: "i",
		name: "Trial Run",
		nameZh: "试运行",
		ruleEn: "If connected upgraded desal>=1 gain credit1 bio1."
	},
	176: {
		color: "y",
		type: "e",
		name: "Export Payment",
		nameZh: "出口收入",
		ruleEn: "May pay credit2 gain point2 once."
	},
	175: {
		color: "y",
		type: "e",
		name: "Federal Priority",
		nameZh: "联邦优先项目",
		ruleEn: "point1 per3 connected farms."
	},
	180: {
		color: "y",
		type: "i",
		name: "Genetics Experiment",
		nameZh: "遗传试验",
		ruleEn: "Pay bio1 gain point2."
	},
	179: {
		color: "y",
		type: "i",
		name: "Motivational Speech",
		nameZh: "动员演说",
		ruleEn: "Refresh used action1 OR card2."
	},
	178: {
		color: "y",
		type: "i",
		name: "Nanogrille Online",
		nameZh: "纳米网络上线",
		ruleEn: "If connected labs>=3 gain point1."
	},
	188: {
		color: "r",
		type: "e",
		name: "Federal Priority",
		nameZh: "联邦优先项目",
		ruleEn: "Cost credit3; point2 per connected upgraded desal."
	},
	181: {
		color: "g",
		type: "e",
		name: "Trade Surplus",
		nameZh: "贸易盈余",
		ruleEn: "Cost credit3; may pay steel1 per point1 max14."
	},
	189: {
		color: "y",
		type: "e",
		name: "Federal Priority",
		nameZh: "联邦优先项目",
		ruleEn: "Cost credit3; point3 per connected city with all3 building types."
	},
	183: {
		color: "r",
		type: "e",
		name: "Federal Priority",
		nameZh: "联邦优先项目",
		ruleEn: "Cost credit3; point3 per2 connected upgraded farms."
	},
	190: {
		color: "g",
		type: "e",
		name: "Federal Priority",
		nameZh: "联邦优先项目",
		ruleEn: "Cost credit3; point2 per connected upgraded lab."
	},
	182: {
		color: "g",
		type: "e",
		name: "Trade Surplus",
		nameZh: "贸易盈余",
		ruleEn: "Cost credit3; may pay credit15 gain point13 once."
	},
	186: {
		color: "y",
		type: "e",
		name: "Federal Priority",
		nameZh: "联邦优先项目",
		ruleEn: "Cost credit3; point2 per connected symbiotic city."
	},
	187: {
		color: "r",
		type: "e",
		name: "Trade Surplus",
		nameZh: "贸易盈余",
		ruleEn: "Cost credit3; may pay kelp2 per point3 max5."
	},
	185: {
		color: "y",
		type: "e",
		name: "Trade Surplus",
		nameZh: "贸易盈余",
		ruleEn: "Cost credit3; may pay science2 per point3 max5."
	},
	184: {
		color: "r",
		type: "e",
		name: "Trade Surplus",
		nameZh: "贸易盈余",
		ruleEn: "Cost credit3; may pay bio1 per point2 max6."
	},
	193: {
		color: "g",
		type: "a",
		name: "Secret Mission",
		nameZh: "秘密任务",
		ruleEn: "Cost credit2; pay credit1 perform any slot available OR not occupied by self."
	},
	192: {
		color: "g",
		type: "d",
		name: "Island",
		nameZh: "岛屿",
		ruleEn: "Cost credit1; credit1 kelp2."
	},
	191: {
		color: "g",
		type: "i",
		name: "Biomech Test",
		nameZh: "生物机械试验",
		ruleEn: "Cost credit1; pay credit1 kelp1 build symbiotic city1."
	},
	196: {
		color: "r",
		type: "i",
		name: "Trade Route",
		nameZh: "贸易航线",
		ruleEn: "Cost credit1; draw2 unused blue metropolises choose1 immediately connected return other."
	},
	195: {
		color: "r",
		type: "a",
		name: "Build Expansion",
		nameZh: "建造扩建设施",
		ruleEn: "Cost credit1; build any building1 expansion usual cost."
	},
	194: {
		color: "g",
		type: "d",
		name: "Autonomous Systems",
		nameZh: "自动化系统",
		ruleEn: "Cost credit1; credit2 point1 per connected city with>=2 upgraded farms."
	},
	199: {
		color: "r",
		type: "i",
		name: "Nanomachine Test",
		nameZh: "纳米机械试验",
		ruleEn: "Cost credit1; build desal1 tunnel1 free."
	},
	198: {
		color: "r",
		type: "i",
		name: "Sale of Technology",
		nameZh: "出售技术",
		ruleEn: "Cost credit1; pay science1 gain point3 kelp2."
	},
	197: {
		color: "g",
		type: "d",
		name: "Island",
		nameZh: "岛屿",
		ruleEn: "Cost credit2; steel1 credit1 point3."
	},
	202: {
		color: "y",
		type: "p",
		name: "Corporate Expansion",
		nameZh: "企业扩张",
		ruleEn: "Cost credit1; whenever newly connect metropolis gain credit2 point2."
	},
	201: {
		color: "y",
		type: "p",
		name: "Lobbying Office",
		nameZh: "游说办公室",
		ruleEn: "Cost credit1; whenever build city federation2."
	},
	200: {
		color: "r",
		type: "a",
		name: "Corporate Sponsorship",
		nameZh: "企业赞助",
		ruleEn: "Cost credit2; build tunnel1 then upgrade it free."
	},
	205: {
		color: "y",
		type: "i",
		name: "Nanomachine Test",
		nameZh: "纳米机械试验",
		ruleEn: "Cost credit2; build up to2 any buildings expansion free."
	},
	204: {
		color: "y",
		type: "a",
		name: "Scavenge the Seafloor",
		nameZh: "海底拾荒",
		ruleEn: "Cost credit1; credit2 card1 kelp1."
	},
	203: {
		color: "y",
		type: "d",
		name: "Island",
		nameZh: "岛屿",
		ruleEn: "Cost credit2; bio1 credit1 point2."
	}
}, z = (e = {}) => O(["tunnel"], 1, e), pe = (e = {}) => O(["farm"], 1, e), B = (e = {}) => O(["desal"], 1, e), me = (e = {}) => O(P, 1, e), he = (e = M, t = 1, n = !1) => O(e, t, {
	expansion: !0,
	free: n
}), ge = (e, t, n, r = 1) => ({
	...k([e], r),
	mode: `${t}|${n}`
}), _e = {
	0: w(S({ steel: 1 }), S({ credit: 1 })),
	1: T({ credit: 1 }, j("available")),
	2: S({
		credit: 2,
		card: 1
	}),
	3: T({ credit: 1 }, j("occupied")),
	4: E("upDesal", 1, S({ bio: 1 })),
	5: T({ credit: 1 }, S({
		steel: 2,
		card: 1
	})),
	6: E("desal", 3, z({ free: !0 })),
	7: S({ federation: 2 }),
	8: E("upLab", 1, S({
		steel: 1,
		science: 1
	})),
	9: k(["farm"], 1, { credit: 1 }),
	10: he(["farm", "desal"]),
	11: S({
		steel: 1,
		kelp: 1
	}),
	12: S({
		card: 1,
		credit: 1,
		science: 1
	}),
	15: S({ steel: 1 }),
	17: S({
		card: 2,
		science: 1
	}),
	19: C(O(N), S({ federation: 1 })),
	21: k(N, 2),
	22: T({ credit: 1 }, S({ bio: 1 })),
	23: S({ credit: 2 }),
	24: ge("desal", "science", "steel"),
	25: S({ kelp: 1 }),
	26: he(["farm"]),
	27: T({ credit: 1 }, S({
		card: 1,
		science: 1
	})),
	28: E("upTunnel", 1, S({ kelp: 1 })),
	29: S({
		credit: 1,
		federation: 1
	}),
	30: D(z({ override: { credit: 1 } })),
	31: T({ science: 1 }, S({ kelp: 2 })),
	32: me({ discount: { credit: 1 } }),
	33: z({ override: { credit: 2 } }),
	34: C(O(["farm", "desal"]), S({ card: 1 })),
	39: T({ steel: 1 }, S({
		credit: 1,
		science: 1
	})),
	41: S({
		card: 2,
		kelp: 1
	}),
	43: ge("desal", "science", "credit"),
	44: T({ steel: 1 }, S({ bio: 1 })),
	45: S({ credit: 1 }),
	46: ce(),
	47: S({
		card: 1,
		federation: 1
	}),
	48: w(T({ kelp: 1 }, S({ steel: 1 })), T({ steel: 1 }, S({ kelp: 1 }))),
	49: T({ credit: 1 }, S({ kelp: 1 })),
	50: T({ steel: 1 }, S({ credit: 2 })),
	51: B(),
	52: E("lab", 2, S({ kelp: 1 })),
	53: E("cities", 2, S({ steel: 1 })),
	54: T({ kelp: 1 }, S({ credit: 3 })),
	55: me(),
	56: S({
		point: 1,
		credit: 1
	}),
	65: ge("lab", "credit", "science"),
	63: z({ override: { steel: 1 } }),
	67: he(["lab", "farm"]),
	68: S({
		credit: 1,
		steel: 1
	}),
	69: A(),
	70: E("upLab", 2, S({
		science: 1,
		steel: 1,
		card: 1
	})),
	71: T({ kelp: 1 }, S({
		science: 1,
		credit: 2
	})),
	72: T({ science: 1 }, S({
		card: 2,
		credit: 3
	})),
	73: E("farm", 4, z({ free: !0 })),
	74: T({ kelp: 1 }, S({ federation: 3 })),
	75: ce(2),
	76: {
		kind: "convert",
		cost: {
			credit: 1,
			science: 1
		}
	},
	77: S({
		point: 1,
		science: 1
	}),
	78: S({
		credit: 2,
		steel: 1
	}),
	84: T({
		science: 1,
		steel: 1
	}, k(["tunnel"], 2, {})),
	85: E("upDesal", 1, S({
		credit: 1,
		bio: 1
	})),
	86: {
		kind: "scaled",
		mode: "desal",
		count: 2,
		gain: { steel: 1 }
	},
	87: z({ override: { science: 1 } }),
	88: E("cities", 4, pe({ free: !0 })),
	89: S({
		card: 2,
		credit: 1
	}),
	90: T({ credit: 1 }, S({
		card: 1,
		science: 1
	})),
	91: S({ steel: 1 }),
	92: E("kelp", 2, S({ kelp: 1 })),
	93: T({ credit: 2 }, j("available")),
	94: T({ credit: 2 }, j("occupied")),
	95: S({
		federation: 1,
		card: 2
	}),
	96: S({ point: 2 }),
	97: S({
		credit: 1,
		kelp: 1
	}),
	99: E("kelp", 2, S({
		science: 1,
		card: 1
	})),
	105: E("upDesal", 2, S({
		card: 1,
		point: 1
	})),
	106: S({ card: 3 }),
	107: S({ federation: 1 }),
	108: T({ credit: 1 }, S({ science: 1 })),
	109: E("desal", 5, pe({ free: !0 })),
	110: E("steel", 2, S({ steel: 1 })),
	111: O(["lab", "farm"]),
	112: k(["lab"]),
	113: E("lab", 3, S({ steel: 1 })),
	114: D(S({ steel: 2 })),
	115: ge("farm", "science", "credit"),
	116: ge("tunnel", "science", "credit"),
	122: T({ credit: 1 }, w(S({ kelp: 1 }), S({ steel: 1 }))),
	123: T({ kelp: 1 }, S({ bio: 1 })),
	124: T({ credit: 1 }, A(2)),
	125: me({ discount: {
		credit: 1,
		kelp: 1
	} }),
	126: E("upFarm", 1, S({
		kelp: 1,
		point: 1
	})),
	127: T({ credit: 1 }, S({
		kelp: 1,
		steel: 1,
		card: 1
	})),
	128: T({ credit: 1 }, S({
		point: 2,
		card: 1
	})),
	129: he(),
	130: T({ science: 1 }, S({
		kelp: 1,
		card: 2,
		point: 1
	})),
	131: {
		kind: "scaled",
		mode: "metropolises",
		count: 1,
		gain: { point: 1 }
	},
	132: ge("farm", "credit", "science", 2),
	133: T({ credit: 1 }, j("available", "y")),
	134: z({ override: { credit: 1 } }),
	135: z({
		override: {
			credit: 1,
			science: 1
		},
		after: {
			kind: "upgradeBuilt",
			free: !0
		}
	}),
	139: A(1, !0),
	140: T({ credit: 1 }, S({
		science: 1,
		point: 1
	})),
	141: pe({
		override: { bio: 1 },
		after: {
			kind: "upgradeBuilt",
			free: !0
		}
	}),
	143: T({ kelp: 1 }, S({
		steel: 2,
		card: 1
	})),
	144: D(me({ discount: { steel: 1 } })),
	145: T({ credit: 1 }, A()),
	146: E("cities", 5, B({ free: !0 })),
	147: T({ science: 1 }, S({
		kelp: 1,
		point: 1
	})),
	148: T({ credit: 1 }, S({ federation: 2 })),
	149: T({ kelp: 1 }, S({ point: 2 })),
	150: T({ credit: 1 }, j("available", "g")),
	151: he(["desal"]),
	152: E("upTunnel", 3, S({ point: 2 })),
	153: w(S({ point: 1 }), S({ card: 3 })),
	154: me({ discount: { kelp: 1 } }),
	158: O(M, 1, {
		expansion: !0,
		override: { credit: 2 }
	}),
	159: z(),
	160: pe({
		override: {
			credit: 2,
			science: 1
		},
		after: {
			kind: "upgradeBuilt",
			free: !0
		}
	}),
	161: T({ science: 1 }, S({ federation: 2 })),
	162: T({ credit: 2 }, j("occupied", "r")),
	163: E("steel", 3, S({ steel: 1 })),
	164: w(S({ credit: 1 }), S({ card: 2 })),
	165: T({ credit: 1 }, S({
		point: 1,
		card: 1
	})),
	166: S({
		federation: 1,
		point: 1
	}),
	167: T({ science: 1 }, S({
		point: 1,
		credit: 1,
		card: 1
	})),
	168: S({ bio: 1 }),
	169: T({
		credit: 1,
		science: 1
	}, k(["tunnel"], 2, {})),
	170: E("purple", 2, S({ point: 1 })),
	171: me({ override: { steel: 3 } }),
	172: T({ kelp: 1 }, S({ federation: 2 })),
	173: { kind: "trialProduction" },
	177: E("upDesal", 1, S({
		credit: 1,
		bio: 1
	})),
	178: E("lab", 3, S({ point: 1 })),
	179: w(ce(), S({ card: 2 })),
	180: T({ bio: 1 }, S({ point: 2 })),
	191: O(["purple"], 1, { override: {
		credit: 1,
		kelp: 1
	} }),
	193: T({ credit: 1 }, j("any")),
	195: he(),
	196: { kind: "tradeRoute" },
	198: T({ science: 1 }, S({
		point: 3,
		kelp: 2
	})),
	199: C(B({ free: !0 }), z({ free: !0 })),
	200: z({
		free: !0,
		after: {
			kind: "upgradeBuilt",
			free: !0
		}
	}),
	204: S({
		credit: 2,
		card: 1,
		kelp: 1
	}),
	205: he(M, 2, !0)
}, V = Object.fromEntries(Object.entries(fe).map(([e, t]) => [e, {
	...t,
	id: Number(e),
	effect: _e[Number(e)],
	cost: Number(e) >= 181 ? Number(e) <= 190 ? 3 : [
		193,
		197,
		200,
		203,
		205
	].includes(Number(e)) ? 2 : 1 : 0
}])), ve = [
	Object.values(V).filter((e) => e.id >= 1 && e.id <= 66).map((e) => e.id),
	Object.values(V).filter((e) => e.id >= 67 && e.id <= 123).map((e) => e.id),
	Object.values(V).filter((e) => e.id >= 124 && e.id <= 180).map((e) => e.id)
], ye = Array.from({ length: 10 }, (e, t) => 181 + t), be = Array.from({ length: 15 }, (e, t) => 191 + t), xe = (e) => ({
	kind: "playCard",
	card: e
}), Se = {
	id: "underwatercities",
	tier: "alpha",
	mechanics: [
		"worker-placement",
		"engine-building",
		"hand-management",
		"route-building"
	],
	interactionTags: [],
	nameKey: "games.underwatercities.name",
	descKey: "games.underwatercities.desc",
	rulesKey: "games.underwatercities.rules",
	icon: "🫧",
	iconImg: "games/underwatercities.webp",
	rulesUrl: { en: "https://www.yucata.de/game-plugins/underwatercities/1.2.7/UnderwaterCities-rules-EN.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#087e91",
	releasedAt: "2026-10-30T15:27:00+08:00",
	search: {
		py: "shui xia cheng shi hai di du shi",
		init: "sxcs hdds"
	},
	hotseat: "cover"
}, Ce = t.object({
	advanced: t.boolean().default(!1),
	contracts: t.boolean().default(!1)
}).default({
	advanced: !1,
	contracts: !1
}), we = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.int().nonnegative()
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), Te = t.object({
	credit: t.int().nonnegative(),
	kelp: t.int().nonnegative(),
	steel: t.int().nonnegative(),
	science: t.int().nonnegative(),
	bio: t.int().nonnegative(),
	point: t.int().nonnegative()
}), Ee = t.object({
	credit: t.int().optional(),
	kelp: t.int().optional(),
	steel: t.int().optional(),
	science: t.int().optional(),
	bio: t.int().optional(),
	point: t.int().optional(),
	card: t.int().optional(),
	federation: t.int().optional()
}), De = t.lazy(() => t.object({
	kind: t.string(),
	gain: Ee.optional(),
	cost: Ee.optional(),
	effects: t.array(De).optional(),
	options: t.array(De).optional(),
	condition: t.object({
		metric: t.string(),
		min: t.number().optional(),
		equal: t.number().optional()
	}).optional(),
	then: De.optional(),
	count: t.int().optional(),
	structures: t.array(t.enum([
		"farm",
		"desal",
		"lab",
		"tunnel",
		"white",
		"purple"
	])).optional(),
	expansion: t.boolean().optional(),
	free: t.boolean().optional(),
	discount: Ee.optional(),
	override: Ee.optional(),
	after: De.optional(),
	color: t.string().optional(),
	mode: t.string().optional(),
	keep: t.boolean().optional(),
	card: t.int().optional(),
	target: t.int().optional(),
	site: t.int().optional(),
	index: t.int().optional(),
	rid: t.string().optional(),
	used: t.array(t.int()).optional(),
	source: t.int().optional(),
	optional: t.boolean().optional()
})), Oe = t.object({
	kind: t.enum([
		"farm",
		"desal",
		"lab"
	]),
	up: t.boolean(),
	site: t.int()
}), ke = t.object({
	rid: t.string(),
	board: t.int().min(1).max(8),
	resources: Te,
	cities: t.array(t.enum([
		"empty",
		"white",
		"purple"
	])).length(9),
	buildings: t.array(t.array(Oe)).length(9),
	tunnels: t.array(t.int().min(0).max(2)).length(16),
	claimed: t.array(t.int()),
	used: t.array(t.int()),
	paidInstant: t.array(t.int()),
	fed: t.int().min(0).max(4),
	fedStamp: t.int(),
	metro: t.array(t.int()).length(3),
	metroConnected: t.array(t.boolean()).length(3),
	extraMetro: t.array(t.int()),
	contracts: t.array(t.int()),
	handCount: t.int().nonnegative(),
	turns: t.int().min(0).max(3),
	breakdown: t.record(t.string(), t.number())
}), Ae = t.object({
	id: t.int(),
	kind: t.string(),
	card: t.int().optional(),
	slot: t.int().optional(),
	target: t.int().optional(),
	site: t.int().optional(),
	build: t.enum([
		"farm",
		"desal",
		"lab",
		"tunnel",
		"white",
		"purple"
	]).optional(),
	cost: Te.optional(),
	gain: Ee.optional(),
	value: t.int().optional(),
	source: t.int().optional(),
	mode: t.string().optional(),
	effect: De.optional()
}), je = t.object({
	phase: t.string(),
	round: t.int().min(1).max(10),
	era: t.int().min(1).max(3),
	players: t.array(ke),
	order: t.array(t.string()),
	active: t.string(),
	slots: t.array(t.array(t.string())),
	cloneUsed: t.boolean(),
	specialTop: t.int().nullable(),
	highSpecial: t.array(t.int()),
	contracts: t.array(t.int()),
	deckCount: t.int(),
	discard: t.array(t.int()),
	supply: t.object({
		white: t.int(),
		purple: t.int(),
		tunnel: t.int()
	}),
	prompt: t.object({
		rid: t.string(),
		kind: t.string(),
		source: t.int().optional(),
		effect: De.optional()
	}).nullable(),
	last: t.object({
		rid: t.string(),
		kind: t.string(),
		card: t.int().optional(),
		target: t.int().optional(),
		site: t.int().optional(),
		build: t.string().optional(),
		gain: Ee.optional()
	}).nullable(),
	log: t.array(t.object({
		rid: t.string(),
		kind: t.string(),
		round: t.int(),
		card: t.int().optional(),
		value: t.int().optional()
	})),
	soloWon: t.boolean(),
	advanced: t.boolean()
}), Me = t.object({
	hand: t.array(t.int()),
	options: t.array(Ae),
	peek: t.array(t.int())
}), H = (e, t) => e.players.find((e) => e.rid === t), U = (e, t) => e.claimed.includes(t), W = (e, t) => ({
	...e,
	source: t,
	...e.effects ? { effects: e.effects.map((e) => W(e, t)) } : {},
	...e.options ? { options: e.options.map((e) => W(e, t)) } : {},
	...e.then ? { then: W(e.then, t) } : {},
	...e.after ? { after: W(e.after, t) } : {}
}), G = (e, t, ...n) => {
	e.tasks.unshift(...n.map((e) => ({
		rid: t,
		effect: e
	})));
};
function K(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Ne(e, t, n) {
	for (let r = 0; r < n; r++) {
		e.deck.length || (e.deck = K(e, e.discard.filter((t) => (t <= 66 ? 1 : t <= 123 ? 2 : 3) === e.era)), e.discard = e.discard.filter((t) => !e.deck.includes(t)));
		let n = e.deck.shift();
		n !== void 0 && e.hands[t].push(n);
	}
}
function Pe(e, t, n = !1) {
	t !== 0 && (t >= 191 && !n ? e.low.push(t) : t >= 181 ? e.retired.push(t) : e.discard.push(t));
}
function q(e) {
	let t = /* @__PURE__ */ new Set([8]), n = !0;
	for (; n;) n = !1, F.forEach(([r, i], a) => {
		e.tunnels[a] && a !== 12 && a !== 13 && (t.has(r) && !t.has(i) && (t.add(i), n = !0), t.has(i) && !t.has(r) && (t.add(r), n = !0));
	});
	return t.has(0) && e.tunnels[12] && e.tunnels[13] && t.add(9), t;
}
function Fe(e, t, n = q(e)) {
	return e.tunnels[t] > 0 && F[t].some((t) => t < 9 && n.has(t) && e.cities[t] !== "empty");
}
function J(e, t) {
	if (t in e.resources) return e.resources[t];
	if (t === "federation") return e.fed ? 5 - e.fed : 5;
	let n = q(e);
	if (t === "cities") return e.cities.filter((e, t) => e !== "empty" && n.has(t)).length;
	if (t === "purple") return e.cities.filter((e, t) => e === "purple" && n.has(t)).length;
	if (t === "metropolises") return e.metroConnected.filter(Boolean).length + e.extraMetro.length;
	if (t === "connectedTunnel") return e.tunnels.filter((e, t) => e && F[t].some((e) => n.has(e))).length;
	if (t === "tunnel" || t === "upTunnel") return e.tunnels.filter((r, i) => r >= (t === "upTunnel" ? 2 : 1) && Fe(e, i, n)).length;
	let r = t.replace(/^up/, "").toLowerCase();
	return [
		"farm",
		"desal",
		"lab"
	].includes(r) ? e.buildings.reduce((i, a, o) => i + (n.has(o) && e.cities[o] !== "empty" ? a.filter((e) => e.kind === r && (!t.startsWith("up") || e.up)).length : 0), 0) : t === "diverse" ? e.buildings.filter((t, r) => n.has(r) && e.cities[r] !== "empty" && new Set(t.map((e) => e.kind)).size === 3).length : 0;
}
function Ie(e, t, n, r = 0) {
	let i = H(e, t);
	for (let e of x) i.resources[e] = Math.max(0, i.resources[e] + (n[e] ?? 0));
	if (n.card && Ne(e, t, n.card), n.federation) {
		let r = [];
		for (let t = 0; t < n.federation; t++) i.fed = Math.min(4, i.fed + 1), i.fedStamp = ++e.stamp, e.soloAdvanced = !0, i.fed === 2 && i.resources.credit++, i.fed === 3 && i.resources.steel++, i.fed >= 4 && i.resources.point++, i.fed === 2 && U(i, 35) && i.resources.credit++;
		U(i, 174) && !e.flags[174] && (e.flags[174] = 1, r.push(S({
			steel: 1,
			card: 1
		}))), G(e, t, ...r);
	}
	r >= 1e3 && (n.steel ?? 0) > 0 && U(i, 137) && i.resources.point++;
}
function Le(...e) {
	let t = se();
	for (let n of e) for (let e of x) t[e] += n?.[e] ?? 0;
	return t;
}
function Re(e, t, n = !1) {
	let r = Le(t), i = [];
	for (let t = 0; t <= (n ? r.kelp : 0); t++) for (let a = 0; a <= (n ? r.steel : 0); a++) {
		let n = {
			...r,
			kelp: r.kelp - t,
			steel: r.steel - a,
			bio: r.bio + t + a
		};
		x.every((t) => e.resources[t] >= n[t]) && i.push(n);
	}
	return i;
}
var ze = (e, t) => {
	for (let n of x) e.resources[n] -= t[n];
}, Be = {
	white: {
		steel: 2,
		kelp: 1,
		credit: 1
	},
	purple: {
		steel: 1,
		kelp: 1,
		bio: 1,
		credit: 2
	},
	farm: { kelp: 1 },
	desal: { credit: 1 },
	lab: { steel: 1 },
	tunnel: {
		steel: 1,
		credit: 1
	}
};
function Ve(e, t) {
	return e.cities[t] === "empty" && F.some(([n, r]) => n === t && r < 9 && e.cities[r] !== "empty" || r === t && n < 9 && e.cities[n] !== "empty");
}
function He(e, t, n, r, i, a, o = !0) {
	let s = L(t.board), c = r === "tunnel" ? s.tunnel[i] : P.includes(r) ? s.city[i] : s.building[`${i}:${a}`], l = Le(n.override ?? Be[r]), u = Le(n.discount);
	r === "purple" && U(t, 100) && u.credit++, o && r === "tunnel" && U(t, 81) && !e.flags[81] && u.credit++, (n.free || r === "tunnel" && U(t, 156) && e.counts.tunnel === 1) && (l = se());
	for (let e of x) l[e] = Math.max(0, l[e] - u[e]) + (c?.cost?.[e] ?? 0);
	return l;
}
function Ue(e, t) {
	return e.tasks.filter((e) => e.rid === t && e.effect.kind === "upgradeBuilt" && !e.effect.free).length;
}
function We(e, t, n, r, i, a) {
	let o = L(t.board), s = n === "tunnel" ? o.tunnel[r] : P.includes(n) ? o.city[r] : o.building[`${r}:${i}`], c = structuredClone(t);
	n === "tunnel" ? c.tunnels[r] = 1 : P.includes(n) ? c.cities[r] = n : c.buildings[r].push({
		kind: n,
		site: i,
		up: !1
	});
	let l = t.resources.science - a.science + (s?.bonus?.science ?? 0);
	for (let t of $e(e, c)) l += t.gain?.science ?? 0;
	return e.contracts.includes(7) && J(c, "connectedTunnel") >= 6 && (l += 2), l;
}
function Ge(e, t, n) {
	let r = H(e, t), i = L(r.board), a = [], o = q(r);
	for (let s of n.structures ?? []) {
		let c = s === "tunnel" ? Array.from({ length: 16 }, (e, t) => t) : Array.from({ length: 9 }, (e, t) => t);
		for (let l of c) {
			if (s === "tunnel" && (!e.supply.tunnel || r.tunnels[l] || !F[l].some((e) => e < 9 && o.has(e))) || P.includes(s) && (!Ve(r, l) || e.supply[s] <= 0) || M.includes(s) && r.cities[l] === "empty" && !Ve(r, l)) continue;
			let c = M.includes(s) ? n.expansion ? i.expansion[l] ? [4] : [] : Array.from({ length: i.regular[l] }, (e, t) => t) : [-1];
			for (let i of c) if (!(i >= 0 && r.buildings[l].some((e) => e.site === i))) for (let o of Re(r, He(e, r, n, s, l, i), !0)) {
				let c = Ue(e, t) + +(n.after?.kind === "upgradeBuilt" && !n.after.free);
				c && We(e, r, s, l, i, o) < c || a.push({
					id: 0,
					kind: "build",
					build: s,
					target: l,
					site: i,
					cost: o
				});
			}
		}
	}
	return a;
}
function Ke(e, t, n) {
	let r = H(e, t), i = [], a = n.mode?.includes("|") ? n.mode.split("|").map((e) => ({ [e]: 1 })) : [n.cost ?? { science: 1 }];
	for (let e of n.structures ?? []) {
		if (e === "white" || e === "purple") continue;
		let t = e === "tunnel" ? r.tunnels.flatMap((e, t) => e === 1 ? [{
			target: t,
			site: -1
		}] : []) : r.buildings.flatMap((t, n) => t.flatMap((t) => t.kind === e && !t.up ? [{
			target: n,
			site: t.site
		}] : []));
		for (let { target: o, site: s } of t) for (let t of a) {
			let a = n.mode === "main" && U(r, 20) && n.index === 2 ? {} : t;
			for (let t of Re(r, a)) i.push({
				id: 0,
				kind: "upgrade",
				build: e,
				target: o,
				site: s,
				cost: t
			});
		}
	}
	return i;
}
var qe = /* @__PURE__ */ new Set([
	"all",
	"choice",
	"pay",
	"build",
	"upgrade",
	"use",
	"refresh",
	"mission",
	"special",
	"specialPeek",
	"returnSpecial",
	"playCard",
	"replace",
	"discard",
	"turn",
	"convert",
	"tradeRoute",
	"chooseMetro",
	"trialProduction",
	"endCards",
	"endExchange",
	"productionChoice",
	"intel"
]);
function Je(e, t) {
	let n = t.condition, r = J(e, n.metric);
	return n.equal === void 0 ? r >= (n.min ?? 0) : r === n.equal;
}
function Ye(e, t, n, r) {
	return R(e.players.length).filter((i) => {
		if (r && i.color !== r) return !1;
		let a = e.slots[i.id];
		return n === "available" ? i.color === "n" || a.length === 0 : n === "occupied" ? i.color !== "n" && a.length > 0 && !a.includes(t) : i.color === "n" || !a.includes(t);
	});
}
function Xe(e, t) {
	let n = e.tasks[0];
	if (!n || n.rid !== t || !qe.has(n.effect.kind)) return [];
	let r = n.effect, i = H(e, t), a = [], o = (e) => a.push({
		...e,
		id: 0
	});
	switch (r.kind) {
		case "turn":
			for (let n of e.hands[t]) for (let r of R(e.players.length)) {
				let a = e.slots[r.id];
				r.color === "n" || !a.length ? o({
					kind: "play",
					card: n,
					slot: r.id
				}) : e.players.length === 4 && !e.cloneUsed && !a.includes(t) && i.resources.credit >= 1 && o({
					kind: "clone",
					card: n,
					slot: r.id,
					cost: Le({ credit: 1 })
				});
			}
			break;
		case "discard":
			for (let n of e.hands[t]) o({
				kind: "discard",
				card: n
			});
			break;
		case "all":
			r.effects?.forEach((e, t) => o({
				kind: "resolve",
				value: t,
				effect: e
			})), o({ kind: "skip" });
			break;
		case "choice":
			r.options?.forEach((e, t) => o({
				kind: "resolve",
				value: t,
				effect: e
			})), o({ kind: "skip" });
			break;
		case "pay":
			for (let e of Re(i, r.cost ?? {})) o({
				kind: "pay",
				cost: e,
				effect: r.then
			});
			o({ kind: "skip" });
			break;
		case "build":
			a.push(...Ge(e, t, r)), o({ kind: "skip" });
			break;
		case "upgrade":
			a.push(...Ke(e, t, r)), o({ kind: "skip" });
			break;
		case "use":
			i.claimed.filter((e) => V[e].type === "a" && !i.used.includes(e) && !r.used?.includes(e)).forEach((e) => o({
				kind: "use",
				card: e
			})), o({ kind: "skip" });
			break;
		case "refresh":
			i.used.filter((e) => !r.used?.includes(e)).forEach((e) => o({
				kind: "refresh",
				card: e
			})), o({ kind: "skip" });
			break;
		case "mission":
			Ye(e, t, r.mode ?? "available", r.color).forEach((e) => o({
				kind: "mission",
				slot: e.id
			})), o({ kind: "skip" });
			break;
		case "special":
			e.high.forEach((e) => o({
				kind: "takeSpecial",
				card: e,
				mode: "high"
			})), e.low.length && (o({
				kind: "takeSpecial",
				card: e.low[0],
				mode: "top"
			}), o({ kind: "peekSpecial" })), o({ kind: "skip" });
			break;
		case "specialPeek":
			e.peek.forEach((e) => o({
				kind: "takePeek",
				card: e
			}));
			break;
		case "returnSpecial":
			e.peekReturn.forEach((e) => o({
				kind: "returnSpecial",
				card: e
			}));
			break;
		case "playCard": {
			let e = V[r.card], t = Math.max(0, e.cost - +!!U(i, 18));
			for (let n of Re(i, { credit: t })) o({
				kind: "claimCard",
				card: e.id,
				cost: n
			});
			o({
				kind: "ignoreCard",
				card: e.id
			});
			break;
		}
		case "replace":
			i.claimed.filter((e) => V[e].type === "a").forEach((e) => o({
				kind: "replace",
				card: e
			}));
			break;
		case "convert":
			e.supply.purple > 0 && i.cities.forEach((e, t) => {
				if (e === "white") for (let e of Re(i, r.cost ?? {}, !0)) o({
					kind: "convert",
					target: t,
					cost: e
				});
			}), o({ kind: "skip" });
			break;
		case "tradeRoute":
			e.bluePool.length && o({ kind: "drawMetro" }), o({ kind: "skip" });
			break;
		case "chooseMetro":
			e.peek.forEach((e) => o({
				kind: "chooseMetro",
				value: e
			}));
			break;
		case "trialProduction":
			i.buildings.forEach((e, t) => e.forEach((e) => {
				e.up && i.cities[t] !== "empty" && q(i).has(t) && o({
					kind: "trialProduction",
					target: t,
					site: e.site,
					build: e.kind
				});
			})), i.tunnels.forEach((e, t) => {
				e === 2 && Fe(i, t) && o({
					kind: "trialProduction",
					target: t,
					site: -1,
					build: "tunnel"
				});
			}), o({ kind: "skip" });
			break;
		case "endCards":
			for (let e of r.used ?? []) o({
				kind: "scoreCard",
				card: e
			});
			o({ kind: "skip" });
			break;
		case "endExchange": {
			let e = Math.min(r.count ?? 999, ...Object.entries(r.cost ?? {}).map(([e, t]) => Math.floor(i.resources[e] / t)));
			for (let t = 1; t <= e; t++) o({
				kind: "exchangeEnd",
				value: t,
				cost: Le(Object.fromEntries(Object.entries(r.cost ?? {}).map(([e, n]) => [e, n * t]))),
				gain: { point: (r.gain?.point ?? 0) * t }
			});
			o({ kind: "skip" });
			break;
		}
		case "productionChoice":
			r.mode === "lab" ? i.buildings.forEach((e, t) => e.forEach((e) => {
				e.kind === "lab" && i.cities[t] !== "empty" && q(i).has(t) && o({
					kind: "produceLab",
					target: t,
					site: e.site
				});
			})) : r.mode === "tunnel" ? i.tunnels.forEach((e, t) => {
				e === 2 && Fe(i, t) && o({
					kind: "produceTunnel",
					target: t
				});
			}) : i.resources.bio >= 1 && o({ kind: "produceBio" }), o({ kind: "skip" });
			break;
		case "intel": i.resources.credit >= 1 && o({
			kind: "intel",
			cost: Le({ credit: 1 })
		}), o({ kind: "skip" });
	}
	if (e.phase === "play" && t === e.active && !["discard", "turn"].includes(r.kind)) for (let n of [
		79,
		101,
		118
	]) !U(i, n) || e.flags[String(n)] || e.tasks.some((e) => e.rid === t && e.effect.mode === "once" && e.effect.card === n) || (n === 101 && i.resources.bio >= 1 || n === 79 && i.resources.credit >= 1 || n === 118 && i.resources.credit >= 1 && i.resources.kelp + i.resources.steel > 0) && o({
		kind: "permanent",
		card: n
	});
	let s = Ue(e, t);
	return a.filter((e) => e.kind === "build" || !e.cost || i.resources.science - e.cost.science >= s).map((e, t) => ({
		...e,
		id: t
	}));
}
function Ze(e, t) {
	e.active = t, e.flags = {}, e.counts = {
		farm: 0,
		tunnel: 0,
		upgradeMain: 0
	}, e.phase = "play";
	let n = 3 + +!!U(H(e, t), 98);
	G(e, t, ...e.hands[t].length > n ? [{
		kind: "discard",
		count: n
	}] : [], { kind: "turn" });
}
function Qe(e, t, n) {
	let r = Ce.parse(e), i = {
		players: [],
		hands: {},
		order: [],
		active: "",
		phase: "setup",
		round: 1,
		era: 1,
		deck: [],
		discard: [],
		retired: [],
		low: [],
		high: [],
		contracts: [],
		bluePool: [],
		slots: R(t.length).map(() => []),
		cloneUsed: !1,
		tasks: [],
		peek: [],
		peekReturn: [],
		flags: {},
		counts: {},
		stamp: 0,
		seed: n,
		cursor: 0,
		advanced: r.advanced || t.length === 1,
		last: null,
		log: [],
		supply: {
			white: 17 - t.length,
			purple: t.length === 1 ? 99 : t.length * 3 + 1,
			tunnel: 46
		},
		soloWon: !1,
		soloAdvanced: !1
	};
	i.order = K(i, t), i.deck = K(i, ve[0]), i.low = K(i, be), i.high = K(i, ye).slice(0, 6);
	let a = K(i, t.length === 1 ? [
		0,
		2,
		3,
		4
	] : [
		0,
		1,
		2,
		3,
		4
	]);
	i.bluePool = K(i, Array.from({ length: 11 }, (e, t) => t));
	let o = K(i, [
		1,
		2,
		3,
		4
	].map((e) => e + (i.advanced ? 4 : 0)));
	i.players = i.order.map((e, t) => ({
		rid: e,
		board: o[t],
		resources: {
			...se(),
			credit: t >= 2 ? 3 : 2,
			kelp: 1,
			steel: t === 3 ? 2 : 1,
			science: 1
		},
		cities: Array.from({ length: 9 }, (e, t) => t === 8 ? "white" : "empty"),
		buildings: Array.from({ length: 9 }, () => []),
		tunnels: Array(16).fill(0),
		claimed: [0],
		used: [],
		paidInstant: [],
		fed: t,
		fedStamp: 0,
		metro: [
			a[t],
			i.bluePool.shift(),
			i.bluePool.shift()
		],
		metroConnected: [
			!1,
			!1,
			!1
		],
		extraMetro: [],
		contracts: [],
		handCount: 0,
		turns: 0,
		breakdown: {}
	})), r.contracts && t.length > 1 && (i.contracts = K(i, [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	]).slice(0, 3));
	for (let e of i.order) i.hands[e] = [], Ne(i, e, 6), i.tasks.push({
		rid: e,
		effect: {
			kind: "discard",
			count: 3
		}
	});
	if (i.tasks.push({
		rid: i.order[0],
		effect: { kind: "start" }
	}), t.length === 1) for (let e of [
		3,
		4,
		11
	]) i.slots[e] = ["solo"];
	return {
		state: i,
		fx: []
	};
}
function $e(e, t) {
	let n = q(t), r = [];
	return [
		9,
		10,
		11
	].forEach((e, i) => {
		!t.metroConnected[i] && n.has(e) && (t.metroConnected[i] = !0, i > 0 && r.push(S(de[t.metro[i]].instant)), U(t, 202) && r.push(S({
			credit: 2,
			point: 2
		})));
	}), r;
}
function et(e, t, n) {
	let r = [], i = n.build, a = n.target, o = q(t);
	return e.counts[i] = (e.counts[i] ?? 0) + 1, i === "farm" && e.counts.farm === 2 && U(t, 64) && r.push(S({ federation: 1 })), i === "tunnel" && (e.counts.tunnel === 2 && U(t, 38) && r.push(S({ federation: 1 })), U(t, 136) && !e.flags[136] && (e.flags[136] = 1, r.push(S({ federation: 2 })))), i === "lab" && U(t, 102) && !e.flags[102] && r.push({
		...T({ credit: 1 }, S({
			point: 1,
			card: 2
		})),
		mode: "once",
		card: 102
	}), (i === "lab" || i === "desal") && t.cities[a] !== "empty" && o.has(a) && t.buildings[a].filter((e) => e.kind === i).length === 2 && U(t, i === "lab" ? 37 : 58) && r.push(S({ credit: 1 })), P.includes(i) && U(t, 201) && r.push(S({ federation: 2 })), r;
}
function tt(e, t) {
	let n = W(V[t].effect, t);
	return U(e, 121) ? [w(T({ steel: 1 }, S({ science: 1 })), T({ science: 1 }, S({ steel: 1 })), S({})), n] : [n];
}
function nt(e, t, n) {
	let r = [], i = n.build;
	if (i === "tunnel") {
		for (let [n, i] of [[61, { credit: 1 }], [15, { steel: 1 }]]) U(t, n) && !e.flags[String(n)] && (e.flags[String(n)] = 1, r.push(S(i)));
		U(t, 119) && !e.flags[119] && r.push({
			...T({ credit: 1 }, S({
				point: 1,
				card: 1
			})),
			mode: "once",
			card: 119
		});
	}
	if (i === "farm") {
		U(t, 103) && !e.flags[103] && r.push({
			...T({ credit: 1 }, S({ kelp: 1 })),
			mode: "once",
			card: 103
		});
		let i = n.target;
		U(t, 59) && q(t).has(i) && t.cities[i] !== "empty" && t.buildings[i].filter((e) => e.kind === "farm" && e.up).length === 2 && r.push(S({ steel: 1 }));
	}
	return r;
}
function rt(e, t) {
	let n = [];
	for (let r of [...e.contracts]) {
		if (!(r === 1 ? J(t, "upTunnel") >= 3 : r === 2 ? t.paidInstant.length + t.claimed.filter((e) => e >= 181).length >= 3 : r === 3 ? J(t, "metropolises") >= 2 : r === 4 ? J(t, "diverse") >= 2 : r === 5 ? J(t, "upFarm") >= 2 && J(t, "upTunnel") >= 2 : r === 6 ? J(t, "purple") >= 3 : r === 7 ? J(t, "connectedTunnel") >= 6 : [
			"upFarm",
			"upDesal",
			"upLab",
			"upTunnel"
		].every((e) => J(t, e) >= 1))) continue;
		e.contracts = e.contracts.filter((e) => e !== r), t.contracts.push(r);
		let i = {
			1: S({
				point: 3,
				credit: 2
			}),
			2: S({
				point: 3,
				bio: 1
			}),
			3: C(O(["farm"], 1, { free: !0 }), S({
				kelp: 1,
				point: 3
			})),
			4: C(O(["lab"], 1, { free: !0 }), S({
				kelp: 1,
				point: 3
			})),
			5: C(O(["desal"], 1, { free: !0 }), S({
				credit: 1,
				point: 4
			})),
			6: S({
				point: 4,
				credit: 1
			}),
			7: S({
				point: 2,
				steel: 1,
				science: 2
			}),
			8: S({ point: 5 })
		};
		n.push(i[r]), e.log.push({
			rid: t.rid,
			kind: "contract",
			round: e.round,
			value: r
		});
	}
	return n;
}
function it(e, t) {
	return e === "farm" ? {
		kelp: 1,
		...t ? { point: 1 } : {}
	} : e === "desal" ? {
		credit: 1,
		...t ? { bio: 1 } : {}
	} : e === "lab" ? {
		science: 1,
		...t ? { steel: 1 } : {}
	} : {
		credit: 1,
		...t ? { point: 1 } : {}
	};
}
function at(e, t) {
	let n = q(t), r = L(t.board), i = se(), a = (e, t = 1) => {
		for (let n of x) i[n] += (e[n] ?? 0) * t;
	};
	t.cities.forEach((e, i) => {
		if (e !== "empty" && n.has(i)) {
			e === "purple" && a({ point: 2 }, r.city[i]?.multiplier ?? 1), a(r.city[i]?.production ?? {});
			for (let e of t.buildings[i]) {
				let t = r.building[`${i}:${e.site}`];
				a(it(e.kind, e.up), t?.multiplier ?? 1), a(t?.production ?? {});
			}
			for (let e of [
				"farm",
				"desal",
				"lab"
			]) t.buildings[i].filter((t) => t.kind === e && t.up).length >= 2 && a(e === "farm" ? {
				kelp: 1,
				point: 1
			} : e === "desal" ? { credit: 1 } : { steel: 1 });
		}
	}), t.tunnels.forEach((e, i) => {
		Fe(t, i, n) && (a(it("tunnel", e === 2), r.tunnel[i]?.multiplier ?? 1), (t.board !== 7 || i !== 14) && a(r.tunnel[i]?.production ?? {}));
	}), t.board === 7 && t.metroConnected[1] && a({ point: 2 }), t.metroConnected.forEach((e, n) => {
		e && n > 0 && a(de[t.metro[n]].production);
	});
	for (let e of t.extraMetro) a(de[e].production);
	for (let e of t.claimed) {
		if (e === 57 && a({ credit: 1 }), e === 42 && a({ steel: 1 }), e === 16 && a({ kelp: Math.floor(J(t, "lab") / 3) }), e === 80 && a({ kelp: Math.floor(J(t, "upLab") / 2) }), [
			13,
			82,
			194
		].includes(e)) {
			let r = t.buildings.filter((r, i) => n.has(i) && t.cities[i] !== "empty" && r.filter((t) => t.kind === (e === 194 ? "farm" : "desal") && (e === 13 || t.up)).length >= 2).length;
			a(e === 13 ? { credit: r } : e === 82 ? { bio: r } : {
				credit: 2 * r,
				point: r
			});
		}
		e === 192 && a({
			credit: 1,
			kelp: 2
		}), e === 197 && a({
			steel: 1,
			credit: 1,
			point: 3
		}), e === 203 && a({
			bio: 1,
			credit: 1,
			point: 2
		});
	}
	return i;
}
function ot(e, t) {
	let n = (e, t, n = 999) => ({
		kind: "endExchange",
		cost: e,
		gain: { point: t },
		count: n
	});
	switch (t) {
		case 138: return n({
			science: 1,
			steel: 1
		}, 1);
		case 142: return n({ bio: 1 }, 1);
		case 155: return n({
			science: 1,
			kelp: 1
		}, 1);
		case 157: return n({
			steel: 1,
			kelp: 1
		}, 1);
		case 176: return n({ credit: 2 }, 2, 1);
		case 175: return S({ point: Math.floor(J(e, "farm") / 3) });
		case 181: return n({ steel: 1 }, 1, 14);
		case 182: return n({ credit: 15 }, 13, 1);
		case 183: return S({ point: 3 * Math.floor(J(e, "upFarm") / 2) });
		case 184: return n({ bio: 1 }, 2, 6);
		case 185: return n({ science: 2 }, 3, 5);
		case 186: return S({ point: 2 * J(e, "purple") });
		case 187: return n({ kelp: 2 }, 3, 5);
		case 188: return S({ point: 2 * J(e, "upDesal") });
		case 189: return S({ point: 3 * J(e, "diverse") });
		case 190: return S({ point: 2 * J(e, "upLab") });
	}
	return S({});
}
function st(e) {
	if (!e.metroConnected[0]) return 0;
	let t = e.metro[0];
	if (t === 0) return 2 * (e.paidInstant.length + e.claimed.filter((e) => e >= 181).length);
	if (t === 1) {
		let t = J(e, "cities");
		return t >= 7 ? 12 : t === 6 ? 8 : t === 5 ? 4 : 0;
	}
	if (t === 2) {
		let t = J(e, "connectedTunnel");
		return t >= 10 ? 9 : t === 9 ? 7 : t === 8 ? 5 : 0;
	}
	return t === 3 ? J(e, "metropolises") * 3 : 4 * Math.min(...[
		"upFarm",
		"upDesal",
		"upLab",
		"upTunnel"
	].map((t) => J(e, t)));
}
function ct(e) {
	if (e.players.length === 1) {
		let t = [
			3,
			2,
			1,
			0,
			4,
			5,
			6,
			7,
			11,
			10,
			9,
			8
		], n = e.round % 4;
		e.slots = e.slots.map(() => []);
		for (let r of [
			n,
			4 + n,
			8 + n
		]) e.slots[t[r]] = ["solo"];
		if (!e.soloAdvanced) {
			e.deck.length || (e.deck = K(e, e.discard.splice(0)));
			let n = e.deck.shift();
			if (n !== void 0) {
				Pe(e, n);
				let r = (String(n).split("").reduce((e, t) => e + Number(t), 0) - 1) % 12;
				for (; e.slots[t[r]].length;) r = (r + 1) % 12;
				e.slots[t[r]] = ["solo"];
			}
		}
		e.soloAdvanced = !1;
	} else e.slots = e.slots.map(() => []);
	e.cloneUsed = !1, e.order.sort((t, n) => {
		let r = H(e, t), i = H(e, n);
		return i.fed - r.fed || (r.fed > 0 ? i.fedStamp - r.fedStamp : 0);
	});
	for (let t of e.players) t.fed = 0, t.fedStamp = 0, t.turns = 0;
	if ([
		4,
		7,
		10
	].includes(e.round)) {
		e.phase = "production";
		for (let t of e.order) e.tasks.push({
			rid: t,
			effect: { kind: "productionStart" }
		});
		e.tasks.push({
			rid: e.order[0],
			effect: { kind: e.round === 10 ? "scoringStart" : "nextEra" }
		});
	} else e.round++, Ze(e, e.order[0]);
}
function lt(e) {
	let { rid: t, effect: n } = e.tasks.shift(), r = H(e, t);
	switch (e.last = {
		rid: t,
		kind: n.kind,
		...n.card === void 0 ? {} : { card: n.card }
	}, n.kind) {
		case "start":
			Ze(e, e.order[0]);
			break;
		case "gain":
			Ie(e, t, n.gain ?? {}, n.source), e.last.gain = n.gain;
			break;
		case "if":
			Je(r, n) && G(e, t, n.then);
			break;
		case "scaled": {
			let i = Math.floor(J(r, n.mode) / (n.count ?? 1));
			Ie(e, t, Object.fromEntries(Object.entries(n.gain ?? {}).map(([e, t]) => [e, t * i])));
			break;
		}
		case "discardCard":
			Pe(e, n.card, n.mode === "paid");
			break;
		case "claim":
			r.claimed.push(n.card), V[n.card].type === "p" && U(r, 120) && G(e, t, S({ credit: 1 }));
			break;
		case "useDiscarded":
			G(e, t, ...tt(r, n.card)), e.last = {
				rid: t,
				kind: "use",
				card: n.card
			};
			break;
		case "upgradeBuilt": {
			let i = n.mode, a = n.target, o = n.site, s = n.free ? se() : Le({ science: 1 });
			x.every((e) => r.resources[e] >= s[e]) && (ze(r, s), i === "tunnel" ? r.tunnels[a] = 2 : r.buildings[a].find((e) => e.site === o).up = !0, G(e, t, ...nt(e, r, {
				id: 0,
				kind: "upgrade",
				build: i,
				target: a,
				site: o
			})), e.last = {
				rid: t,
				kind: "upgrade",
				build: i,
				target: a,
				site: o
			});
			break;
		}
		case "endTurn":
			U(r, 60) ? G(e, t, { kind: "intel" }, { kind: "finishTurn" }) : G(e, t, { kind: "finishTurn" });
			break;
		case "finishTurn": {
			Ne(e, t, 1), r.turns++;
			let n = e.order[(e.order.indexOf(t) + 1) % e.order.length];
			e.players.every((e) => e.turns === 3) ? ct(e) : Ze(e, n);
			break;
		}
		case "productionStart": {
			let n = at(e, r);
			Ie(e, t, n), e.last = {
				rid: t,
				kind: "production",
				gain: n
			};
			let i = [];
			U(r, 36) && J(r, "lab") > 0 && i.push({
				kind: "productionChoice",
				mode: "lab"
			}), U(r, 66) && J(r, "upTunnel") > 0 && i.push({
				kind: "productionChoice",
				mode: "tunnel"
			}), U(r, 117) && n.bio > 0 && i.push({
				kind: "productionChoice",
				mode: "bio"
			}), G(e, t, ...i, { kind: "feeding" });
			break;
		}
		case "feeding": {
			let n = Math.max(0, J(r, "cities") - +!!U(r, 104)), i = Math.min(n, r.resources.kelp);
			r.resources.kelp -= i, n -= i;
			let a = Math.min(n, r.resources.bio);
			r.resources.bio -= a, n -= a, r.resources.point = Math.max(0, r.resources.point - n * 3), e.last = {
				rid: t,
				kind: "feeding",
				gain: {
					kelp: -i,
					bio: -a,
					point: -n * 3
				}
			}, e.log.push({
				rid: t,
				kind: "production",
				round: e.round,
				value: r.resources.point
			});
			break;
		}
		case "nextEra":
			e.era++, e.round++, e.retired.push(...e.deck, ...e.discard), e.deck = K(e, ve[e.era - 1]), e.discard = [];
			for (let t of e.order) {
				let n = H(e, t);
				n.used = [], Ne(e, t, 3), e.tasks.push({
					rid: t,
					effect: {
						kind: "discard",
						count: 3 + +!!U(n, 98)
					}
				});
			}
			e.tasks.push({
				rid: e.order[0],
				effect: { kind: "start" }
			}), e.phase = "era";
			break;
		case "scoringStart":
			e.phase = "scoring";
			for (let t of e.order) e.tasks.push({
				rid: t,
				effect: { kind: "brownScore" }
			});
			e.tasks.push({
				rid: e.order[0],
				effect: { kind: "done" }
			});
			break;
		case "brownScore": {
			r.breakdown.play = r.resources.point;
			let n = st(r);
			r.resources.point += n, r.breakdown.metropolis = n;
			let i = r.claimed.filter((e) => V[e].type === "e");
			G(e, t, ...i.length ? [{
				kind: "endCards",
				used: i
			}] : [], { kind: "cityScore" });
			break;
		}
		case "cityScore": {
			r.breakdown.cards = r.resources.point - r.breakdown.play - r.breakdown.metropolis;
			let n = q(r), i = r.cities.reduce((e, t, i) => e + (t !== "empty" && n.has(i) ? [
				2,
				3,
				4,
				6
			][new Set(r.buildings[i].map((e) => e.kind)).size] : 0), 0);
			r.resources.point += i, r.breakdown.cities = i;
			let a = r.resources.credit + 2 * r.resources.bio + r.resources.kelp + r.resources.steel + r.resources.science;
			r.breakdown.resources = Math.floor(a / 4), r.resources.point += r.breakdown.resources, e.last = {
				rid: t,
				kind: "score",
				gain: { point: i + r.breakdown.resources }
			};
			break;
		}
		case "done": e.phase = "done", e.soloWon = e.players.length === 1 && J(r, "cities") >= 7 && r.resources.point >= 100;
	}
	G(e, t, ...rt(e, r));
}
function ut(e, t, n, r) {
	let i = V[r];
	i.type === "i" ? (r >= 181 && t.paidInstant.push(r), G(e, t.rid, ...i.effect ? [W(i.effect, r)] : [], {
		kind: "discardCard",
		card: r,
		mode: r >= 181 ? "paid" : ""
	})) : i.type === "a" && t.claimed.filter((e) => V[e].type === "a").length >= 4 && n.mode !== "replaced" ? G(e, t.rid, {
		kind: "replace",
		card: r
	}) : G(e, t.rid, {
		kind: "claim",
		card: r
	});
}
function dt(e, t, n) {
	let r = H(e, t), i = e.tasks[0].effect;
	if (n.kind === "permanent") {
		G(e, t, W({
			...n.card === 79 ? T({ credit: 1 }, S({ steel: 1 })) : n.card === 101 ? T({ bio: 1 }, S({
				kelp: 1,
				steel: 1
			})) : w({
				...T({
					credit: 1,
					kelp: 1
				}, S({ steel: 1 })),
				mode: "once",
				card: 118
			}, {
				...T({
					credit: 1,
					steel: 1
				}, S({ kelp: 1 })),
				mode: "once",
				card: 118
			}),
			mode: "once",
			card: n.card
		}, n.card));
		return;
	}
	e.tasks.shift(), e.last = {
		rid: t,
		kind: n.kind,
		...n.card === void 0 ? {} : { card: n.card },
		...n.target === void 0 ? {} : { target: n.target },
		...n.site === void 0 ? {} : { site: n.site },
		...n.build ? { build: n.build } : {}
	};
	let a = (n = (i.count ?? 1) - 1) => {
		n > 0 && G(e, t, {
			...i,
			count: n
		});
	};
	switch (n.kind) {
		case "skip":
			i.kind === "endCards" && (r.breakdown.cards = r.resources.point - r.breakdown.play - r.breakdown.metropolis);
			break;
		case "discard": {
			let r = e.hands[t].indexOf(n.card);
			e.hands[t].splice(r, 1), Pe(e, n.card), e.hands[t].length > (i.count ?? 3) && G(e, t, i);
			break;
		}
		case "play":
		case "clone": {
			let i = n.card, a = R(e.players.length)[n.slot];
			e.hands[t].splice(e.hands[t].indexOf(i), 1), n.kind === "clone" && (ze(r, n.cost), e.cloneUsed = !0), a.color !== "n" && e.slots[a.id].push(t);
			let o = W(a.effect, 1e3 + a.id);
			U(r, 83) && a.id === R(e.players.length).length - 2 && a.color === "y" && (o.effects = [...o.effects ?? [], W(O(M), 1e3 + a.id)]);
			let s = [];
			if (a.color === V[i].color) s.push(C(xe(i), o));
			else if (Pe(e, i), s.push(o), a.color !== "n") for (let [e, t] of [
				[40, { credit: 1 }],
				[14, { steel: 1 }],
				[62, { card: 1 }]
			]) U(r, e) && s.unshift(S(t));
			G(e, t, ...s, { kind: "endTurn" }), e.log.push({
				rid: t,
				kind: "play",
				round: e.round,
				card: i,
				value: a.id
			});
			break;
		}
		case "resolve":
			if (i.kind === "all") {
				let r = i.effects.filter((e, t) => t !== n.value);
				r.length && G(e, t, {
					...i,
					effects: r
				});
			}
			G(e, t, n.effect);
			break;
		case "pay":
			ze(r, n.cost), i.mode === "once" && (e.flags[String(i.card)] = 1), G(e, t, n.effect);
			break;
		case "claimCard":
			ze(r, n.cost), ut(e, r, i, n.card);
			break;
		case "ignoreCard":
			Pe(e, n.card);
			break;
		case "replace": {
			let a = n.card, o = !r.used.includes(a);
			r.claimed = r.claimed.filter((e) => e !== a), r.used = r.used.filter((e) => e !== a), Pe(e, a, !0), G(e, t, ...o ? [w({
				kind: "useDiscarded",
				card: a
			}, S({}))] : [], {
				kind: "claim",
				card: i.card
			});
			break;
		}
		case "build": {
			n.build === "tunnel" && He(e, r, i, "tunnel", n.target, n.site, !1).credit > He(e, r, i, "tunnel", n.target, n.site).credit && (e.flags[81] = 1), ze(r, n.cost);
			let o = n.build, s = n.target, c = n.site, l = L(r.board), u = o === "tunnel" ? l.tunnel[s] : P.includes(o) ? l.city[s] : l.building[`${s}:${c}`];
			o === "tunnel" ? (r.tunnels[s] = 1, e.supply.tunnel--) : P.includes(o) ? (r.cities[s] = o, e.supply[o]--) : r.buildings[s].push({
				kind: o,
				site: c,
				up: !1
			}), a(), i.after && G(e, t, {
				...i.after,
				mode: o,
				target: s,
				site: c
			}), G(e, t, ...u?.bonus ? [S(u.bonus)] : [], ...et(e, r, n), ...$e(e, r));
			break;
		}
		case "upgrade":
			ze(r, n.cost), n.build === "tunnel" ? r.tunnels[n.target] = 2 : r.buildings[n.target].find((e) => e.site === n.site).up = !0, i.mode === "main" && (i.index = (i.index ?? 0) + 1), a(), G(e, t, ...nt(e, r, n));
			break;
		case "use": {
			let a = n.card;
			i.keep || r.used.push(a), (i.count ?? 1) > 1 && G(e, t, {
				...i,
				count: (i.count ?? 1) - 1,
				used: [...i.used ?? [], a]
			}), G(e, t, ...tt(r, a));
			break;
		}
		case "refresh":
			r.used = r.used.filter((e) => e !== n.card), a();
			break;
		case "mission": {
			let i = R(e.players.length)[n.slot], a = W(i.effect, 1e3 + i.id);
			U(r, 83) && i.id === R(e.players.length).length - 2 && i.color === "y" && (a.effects = [...a.effects ?? [], W(O(M), 1e3 + i.id)]), G(e, t, a);
			break;
		}
		case "takeSpecial":
			n.mode === "high" ? e.high = e.high.filter((e) => e !== n.card) : e.low.shift(), e.hands[t].push(n.card);
			break;
		case "peekSpecial":
			e.low.push(e.low.shift()), e.peek = e.low.splice(0, 3), G(e, t, { kind: "specialPeek" });
			break;
		case "takePeek":
			e.hands[t].push(n.card), e.peekReturn = e.peek.filter((e) => e !== n.card), e.peek = [], e.peekReturn.length && G(e, t, { kind: "returnSpecial" });
			break;
		case "returnSpecial":
			e.low.push(n.card), e.peekReturn = e.peekReturn.filter((e) => e !== n.card), e.peekReturn.length && G(e, t, i);
			break;
		case "convert":
			ze(r, n.cost), r.cities[n.target] = "purple", e.supply.white++, e.supply.purple--;
			break;
		case "drawMetro":
			e.peek = e.bluePool.splice(0, 2), G(e, t, { kind: "chooseMetro" });
			break;
		case "chooseMetro":
			r.extraMetro.push(n.value), e.bluePool.push(...e.peek.filter((e) => e !== n.value)), e.peek = [], G(e, t, S(de[n.value].instant), ...U(r, 202) ? [S({
				credit: 2,
				point: 2
			})] : []);
			break;
		case "trialProduction":
			G(e, t, S(it(n.build, !0)));
			break;
		case "scoreCard": {
			let a = i.used.filter((e) => e !== n.card);
			a.length && G(e, t, {
				...i,
				used: a
			}), G(e, t, W(ot(r, n.card), n.card));
			break;
		}
		case "exchangeEnd":
			ze(r, n.cost), Ie(e, t, n.gain);
			break;
		case "produceLab": {
			let i = L(r.board).building[`${n.target}:${n.site}`]?.multiplier ?? 1;
			r.resources.science -= i, Ie(e, t, {
				steel: i,
				kelp: i
			});
			break;
		}
		case "produceTunnel": {
			let i = L(r.board).tunnel[n.target]?.multiplier ?? 1;
			r.resources.point -= i, Ie(e, t, {
				kelp: i,
				science: i
			});
			break;
		}
		case "produceBio":
			r.resources.bio--, Ie(e, t, {
				steel: 1,
				point: 1,
				credit: 1
			});
			break;
		case "intel": ze(r, n.cost), Ne(e, t, 2);
	}
	G(e, t, ...rt(e, r));
}
function ft(e) {
	for (; e.tasks[0]?.effect.kind === "discard" && e.hands[e.tasks[0].rid].length <= (e.tasks[0].effect.count ?? 3);) e.tasks.shift();
}
function pt(e, t, n) {
	if (e.phase === "done") return { code: "games.underwatercities.errFinished" };
	let r = e.tasks[0];
	if (!r) return { code: "games.underwatercities.errAction" };
	if (t.type === "tick") {
		if (qe.has(r.effect.kind)) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return lt(t), ft(t), {
			state: t,
			fx: t.last ? [{
				kind: "change",
				rid: t.last.rid,
				data: { ...t.last }
			}] : []
		};
	}
	if (r.rid !== n.by) return { code: "games.underwatercities.errTurn" };
	let i = Xe(e, n.by).find((e) => e.id === t.id);
	if (!i) return { code: "games.underwatercities.errAction" };
	let a = structuredClone(e);
	return dt(a, n.by, i), ft(a), ["takePeek", "returnSpecial"].includes(i.kind) && a.last && delete a.last.card, {
		state: a,
		fx: [
			"build",
			"upgrade",
			"convert",
			"use",
			"play",
			"clone",
			"claimCard",
			"exchangeEnd",
			"chooseMetro"
		].includes(i.kind) && a.last ? [{
			kind: "change",
			rid: n.by,
			data: { ...a.last }
		}] : []
	};
}
function mt(e, t) {
	let n = e.tasks[0], r = /* @__PURE__ */ new Set([
		"discard",
		"specialPeek",
		"returnSpecial",
		"chooseMetro"
	]);
	return {
		public: {
			phase: e.phase,
			round: e.round,
			era: e.era,
			players: e.players.map((t) => ({
				...t,
				handCount: e.hands[t.rid].length
			})),
			order: e.order,
			active: e.active,
			slots: e.slots,
			cloneUsed: e.cloneUsed,
			specialTop: e.low[0] ?? null,
			highSpecial: e.high,
			contracts: e.contracts,
			deckCount: e.deck.length,
			discard: e.discard,
			supply: e.supply,
			prompt: n ? {
				rid: n.rid,
				kind: n.effect.kind,
				...n.effect.source ? { source: n.effect.source } : {},
				...r.has(n.effect.kind) ? {} : { effect: n.effect }
			} : null,
			last: e.last,
			log: e.log,
			soloWon: e.soloWon,
			advanced: e.advanced
		},
		private: {
			hand: e.hands[t] ?? [],
			options: Xe(e, t),
			peek: n?.rid === t ? [...e.peek, ...e.peekReturn] : []
		}
	};
}
function ht(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.order].sort((t, n) => H(e, n).resources.point - H(e, t).resources.point);
	return {
		phase: "done",
		ranking: t,
		winner: e.players.length === 1 ? e.soloWon ? t : [] : t.slice(0, 1),
		scores: Object.fromEntries(e.players.map((e) => [e.rid, e.resources.point]))
	};
}
var gt = {
	saveCompatibility: { version: "1" },
	meta: Se,
	schemas: {
		action: we,
		publicView: je,
		privateView: Me,
		config: Ce
	},
	setup: Qe,
	reduce: pt,
	viewFor: mt,
	status: ht,
	nextTickIn: (e) => e.phase !== "done" && e.tasks.length && !qe.has(e.tasks[0].effect.kind) ? 420 : null
}, _t = {
	actionCard: "行动牌",
	actionCards: "行动牌",
	useDiscarded: "使用弃掉的行动牌",
	useTemplate: "使用最多{{n}}张行动牌",
	refreshTemplate: "恢复最多{{n}}张行动牌",
	advanceFederation: "联邦推进{{n}}格",
	scaledTemplate: "每{{n}}个{{kind}}，获得{{gain}}",
	city: "城市网络",
	slots: "公共工位",
	cards: "卡牌",
	hand: "手牌",
	claimed: "已保留卡牌",
	special: "特殊牌",
	contracts: "政府合同",
	federation: "联邦",
	credit: "信用",
	kelp: "海带",
	steel: "钢塑",
	science: "科研",
	bio: "生物质",
	point: "分数",
	card: "张牌",
	farm: "农场",
	desal: "脱盐厂",
	lab: "实验室",
	labPlural: "实验室",
	tunnel: "隧道",
	white: "白色城市",
	purple: "共生城市",
	g: "绿色",
	r: "红色",
	y: "黄色",
	n: "无色",
	i: "即时",
	a: "行动",
	p: "常驻",
	d: "生产",
	e: "终局",
	confirm: "确认选择",
	cancel: "取消选择",
	skip: "放弃此效果",
	waiting: "等待玩家选择",
	automatic: "正在结算",
	build: "建造",
	upgrade: "升级",
	gain: "获得",
	pay: "支付",
	free: "免费",
	usual: "按通常费用",
	expansion: "扩建位",
	choice: "选择一项",
	discount: "建造费用减少",
	choose: "选择一项",
	all: "选择先结算的部分",
	use: "使用行动牌",
	refresh: "恢复行动牌",
	mission: "执行工位行动",
	available: "空闲工位",
	occupied: "他人占据的工位",
	any: "空闲或非自己占据的工位",
	specialPeek: "从三张中保留一张",
	returnSpecial: "选择先放回牌堆底的卡牌",
	playCard: "决定是否使用卡牌",
	replace: "弃掉一张旧行动牌",
	discard: "弃到手牌上限",
	turn: "选择手牌和工位",
	convert: "将一座白色城市改为共生城市",
	tradeRoute: "抽取两座未使用的蓝色都会",
	chooseMetro: "选择一座都会立即连接",
	trialProduction: "获得一个升级设施的生产",
	endCards: "选择下一张终局牌",
	endExchange: "选择兑换数量",
	productionChoice: "选择生产替代效果",
	intel: "额外抽牌",
	peekSpecial: "将顶牌移到底部，再抽三选一",
	takeSpecial: "拿取特殊牌",
	takePeek: "保留这张牌",
	ignoreCard: "弃掉卡牌，不执行效果",
	claimCard: "使用这张牌",
	clone: "克隆工位",
	resolve: "结算",
	scoreCard: "结算终局牌",
	exchangeEnd: "兑换资源",
	produceLab: "实验室改为生产钢塑与海带",
	produceTunnel: "隧道改为生产海带与科研",
	produceBio: "将生产的生物质改为钢塑、分数与信用",
	drawMetro: "抽取都会",
	permanent: "使用常驻能力",
	take: "拿取",
	round: "轮",
	era: "年代",
	board: "版图",
	network: "连网城市",
	networkOne: "连网城市",
	feeding: "城市供给",
	connected: "已连通",
	disconnected: "未连通",
	level: "级",
	used: "已使用",
	ready: "可用",
	details: "查看详情",
	close: "关闭",
	next: "继续",
	top: "牌堆顶",
	cost: "费用",
	reward: "奖励",
	production: "生产",
	multiplier: "通常生产倍率",
	zoom: "放大版图",
	fit: "适应版图",
	scoreItem: "计分项目",
	hideResult: "回看城市网络",
	showResult: "查看结算",
	projectReport: "海底城市发展报告",
	confirmAgain: "确认再来一局",
	confirmLobby: "确认返回大厅",
	total: "总分",
	play: "对局得分",
	metropolis: "都会",
	cities: "城市",
	resources: "剩余资源",
	winner: "优胜者",
	soloWin: "单人挑战成功",
	soloLoss: "单人挑战未达成",
	again: "再来一局",
	lobby: "返回大厅",
	hostWait: "等待主机决定",
	advanced: "高级版图",
	advancedHelp: "使用非对称版图。单人模式始终使用高级版图。",
	contractsHelp: "展示三张竞争目标；单人模式不使用。",
	supply: "剩余供应",
	selectCard: "先选择一张手牌",
	selectSlot: "选择一个工位",
	selectTarget: "选择版图上的合法位置",
	selectOption: "选择要执行的效果",
	active: "当前行动",
	noActions: "当前没有可执行的选择",
	allCards: "查看卡牌",
	paid: "支付后生效",
	once: "每回合一次",
	tunnelCount: "连网隧道",
	upTunnel: "邻接连网城市的升级隧道",
	upFarm: "连网升级农场",
	upDesal: "连网升级脱盐厂",
	upLab: "连网升级实验室",
	diverse: "拥有三种建筑的连网城市",
	connectedFarm: "连网农场",
	connectedDesal: "连网脱盐厂",
	connectedLab: "连网实验室",
	if: "若",
	atLeast: "至少",
	then: "则",
	same: "同一城市",
	after: "然后",
	upTo: "最多",
	each: "每个",
	keep: "使用后保持可用"
}, vt = {
	actionCard: "action card",
	actionCards: "action cards",
	useDiscarded: "Use the discarded action card",
	useTemplate: "Use up to {{n}} {{cards}}",
	refreshTemplate: "Refresh up to {{n}} {{cards}}",
	advanceFederation: "advance {{n}} Federation {{spaces}}",
	scaledTemplate: "Gain {{gain}} per {{n}} {{kind}}",
	city: "City network",
	slots: "Action slots",
	cards: "Cards",
	hand: "Hand",
	claimed: "Cards in play",
	special: "Special cards",
	contracts: "Government contracts",
	federation: "Federation",
	credit: "credits",
	kelp: "kelp",
	steel: "steelplast",
	science: "science",
	bio: "biomatter",
	point: "points",
	card: "cards",
	farm: "Farm",
	desal: "Desalination plant",
	lab: "Laboratory",
	labPlural: "Laboratories",
	tunnel: "Tunnel",
	white: "White city",
	purple: "Symbiotic city",
	g: "Green",
	r: "Red",
	y: "Yellow",
	n: "Colorless",
	i: "Instant",
	a: "Action",
	p: "Permanent",
	d: "Production",
	e: "End scoring",
	confirm: "Confirm choice",
	cancel: "Clear selection",
	skip: "Decline this effect",
	waiting: "Waiting for a choice",
	automatic: "Resolving",
	build: "Build",
	upgrade: "Upgrade",
	gain: "Gain",
	pay: "Pay",
	free: "Free",
	usual: "for the usual cost",
	expansion: "Expansion site",
	choice: "Choose one",
	discount: "Building discount",
	choose: "Choose one",
	all: "Choose what to resolve first",
	use: "Use an action card",
	refresh: "Refresh an action card",
	mission: "Perform a slot action",
	available: "available slots",
	occupied: "slots occupied by another player",
	any: "available slots or slots not occupied by you",
	specialPeek: "Keep one of the three cards",
	returnSpecial: "Choose which card goes to the bottom first",
	playCard: "Decide whether to use the card",
	replace: "Discard an old action card",
	discard: "Discard to your hand limit",
	turn: "Choose a card and an action slot",
	convert: "Convert a white city to a symbiotic city",
	tradeRoute: "Draw two unused blue metropolises",
	chooseMetro: "Choose a metropolis to connect immediately",
	trialProduction: "Gain one upgraded structure’s production",
	endCards: "Choose the next end-scoring card",
	endExchange: "Choose how much to exchange",
	productionChoice: "Choose a production replacement",
	intel: "Draw additional cards",
	peekSpecial: "Move the top card to the bottom, then draw three and keep one",
	takeSpecial: "Take a Special card",
	takePeek: "Keep this card",
	ignoreCard: "Discard the card without its effect",
	claimCard: "Use this card",
	clone: "Clone the slot",
	resolve: "Resolve",
	scoreCard: "Score this card",
	exchangeEnd: "Exchange resources",
	produceLab: "Laboratory produces steelplast and kelp instead",
	produceTunnel: "Tunnel produces kelp and science instead",
	produceBio: "Replace produced biomatter with steelplast, points, and credits",
	drawMetro: "Draw metropolises",
	permanent: "Use a permanent ability",
	take: "Take",
	round: "Round",
	era: "Era",
	board: "Board",
	network: "Connected cities",
	networkOne: "Connected city",
	feeding: "City feeding",
	connected: "Connected",
	disconnected: "Disconnected",
	level: "Level",
	used: "Used",
	ready: "Ready",
	details: "Card details",
	close: "Close",
	next: "Continue",
	top: "Top of deck",
	cost: "Cost",
	reward: "Reward",
	production: "Production",
	multiplier: "Ordinary production multiplier",
	zoom: "Enlarge board",
	fit: "Fit board",
	scoreItem: "Score source",
	hideResult: "Review city networks",
	showResult: "Show results",
	projectReport: "Underwater development report",
	confirmAgain: "Confirm new game",
	confirmLobby: "Confirm return to lobby",
	total: "Total",
	play: "During play",
	metropolis: "Metropolis",
	cities: "Cities",
	resources: "Remaining resources",
	winner: "Winner",
	soloWin: "Solo challenge won",
	soloLoss: "Solo challenge not completed",
	again: "Play again",
	lobby: "Back to lobby",
	hostWait: "Waiting for the host",
	advanced: "Advanced boards",
	advancedHelp: "Use asymmetric boards. Solo always uses an advanced board.",
	contractsHelp: "Reveal three competitive objectives. Not used in solo play.",
	supply: "Remaining supply",
	selectCard: "Choose a card first",
	selectSlot: "Choose an action slot",
	selectTarget: "Choose a legal site on the board",
	selectOption: "Choose an effect to perform",
	active: "Current turn",
	noActions: "No choices are currently available",
	allCards: "View cards",
	paid: "Pay to activate",
	once: "Once per turn",
	tunnelCount: "Connected tunnels",
	upTunnel: "Upgraded tunnels at connected cities",
	upFarm: "Connected upgraded farms",
	upDesal: "Connected upgraded desalination plants",
	upLab: "Connected upgraded laboratories",
	diverse: "Connected cities with all three building types",
	connectedFarm: "connected farms",
	connectedDesal: "connected desalination plants",
	connectedLab: "connected laboratories",
	if: "If",
	atLeast: "at least",
	then: "then",
	same: "in the same city",
	after: "then",
	upTo: "up to",
	each: "each",
	keep: "Keep available after use"
}, yt = {
	13: "生产时，每座拥有至少2座脱盐厂的连网城市额外生产1信用。",
	14: "打出的牌与有色工位颜色不匹配时，获得1钢塑。",
	15: "每回合第一次升级隧道时，获得1钢塑。",
	16: "生产时，每3座连网实验室额外生产1海带。",
	18: "打出特殊牌时，费用减少1信用。",
	20: "通过主板升级工位升级3个设施时，总共仅支付2科研。",
	35: "进入联邦轨道第3格时，额外获得1信用。",
	36: "生产时，可以让1座连网实验室改为生产1钢塑和1海带，替代1科研；升级实验室仍额外生产1钢塑。",
	37: "在连网城市建造第2座实验室时，获得1信用。",
	38: "同一回合建造第2条隧道时，推进联邦1格。",
	40: "打出的牌与有色工位颜色不匹配时，获得1信用。",
	42: "生产时额外生产1钢塑。",
	57: "生产时额外生产1信用。",
	58: "在连网城市建造第2座脱盐厂时，获得1信用。",
	59: "在连网城市完成第2座升级农场时，获得1钢塑。",
	60: "回合结束抽牌前，可以支付1信用，额外抽2张牌。",
	61: "每回合第一次升级隧道时，获得1信用。",
	62: "打出的牌与有色工位颜色不匹配时，抽1张牌。",
	64: "同一回合建造第2座农场时，推进联邦1格。",
	66: "生产时，可以让1条邻接连网城市的升级隧道改为生产1信用、1海带和1科研，替代1信用和1分。",
	79: "每回合一次，可以支付1信用，获得1钢塑。",
	80: "生产时，每2座连网升级实验室额外生产1海带。",
	81: "每回合一次，建造隧道的费用可减少1信用。",
	82: "生产时，每座拥有至少2座升级脱盐厂的连网城市额外生产1生物质。",
	83: "使用主板上同时建造城市与建筑的工位时，可以按通常费用额外建造1座建筑。",
	98: "手牌上限增加1，不额外抽牌。",
	100: "每次建造共生城市时，费用减少1信用。",
	101: "每回合一次，可以支付1生物质，获得1海带和1钢塑。",
	102: "每回合一次，建造实验室时可以支付1信用，获得1分并抽2张牌。",
	103: "每回合一次，升级农场时可以支付1信用，获得1海带。",
	104: "生产后的供给阶段，有1座城市不消耗海带。",
	117: "生产时，可以将本次生产的1生物质改为1钢塑、1分和1信用。",
	118: "每回合一次，可以支付1信用，再将1海带换成1钢塑，或将1钢塑换成1海带。",
	119: "每回合一次，升级隧道时可以支付1信用，获得1分并抽1张牌。",
	120: "保留一张常驻牌时，获得1信用，本牌自身也会触发。",
	121: "每次使用行动牌时，可以将1钢塑换成1科研，或反向交换。",
	136: "每回合第一次建造隧道时，推进联邦2格。",
	137: "工位本身使你获得至少1钢塑时，获得1分。联邦或卡牌奖励不触发。",
	138: "终局时，可以反复支付1科研和1钢塑，每组获得1分。",
	142: "终局时，可以反复支付1生物质，每个获得1分。",
	155: "终局时，可以反复支付1科研和1海带，每组获得1分。",
	156: "同一回合建造的第2条隧道免费。",
	157: "终局时，可以反复支付1钢塑和1海带，每组获得1分。",
	174: "每回合第一次推进联邦时，获得1钢塑并抽1张牌。",
	175: "终局时，每3座连网农场获得1分。",
	176: "终局时，可以支付2信用，获得2分，仅限一次。",
	181: "终局时，可以按每1钢塑获得1分兑换，最多兑换14次。",
	182: "终局时，可以支付15信用，获得13分，仅限一次。",
	183: "终局时，每2座连网升级农场获得3分。",
	184: "终局时，可以按每1生物质获得2分兑换，最多兑换6次。",
	185: "终局时，可以按每2科研获得3分兑换，最多兑换5次。",
	186: "终局时，每座连网共生城市获得2分。",
	187: "终局时，可以按每2海带获得3分兑换，最多兑换5次。",
	188: "终局时，每座连网升级脱盐厂获得2分。",
	189: "终局时，每座拥有全部3种建筑的连网城市获得3分。",
	190: "终局时，每座连网升级实验室获得2分。",
	192: "生产时额外生产1信用和2海带。",
	194: "生产时，每座拥有至少2座升级农场的连网城市额外生产2信用和1分。",
	197: "生产时额外生产1钢塑、1信用和3分。",
	201: "每次建造城市时，推进联邦2格。",
	202: "每次新连接一座都会时，获得2信用和2分。",
	203: "生产时额外生产1生物质、1信用和2分。"
}, bt = {
	13: "During production, gain 1 extra credit for each connected city with at least 2 desalination plants.",
	14: "When your card does not match a colored action slot, gain 1 steelplast.",
	15: "Once per turn, when you upgrade a tunnel, gain 1 steelplast.",
	16: "During production, gain 1 kelp per 3 connected laboratories.",
	18: "Pay 1 fewer credit when playing a Special card.",
	20: "When upgrading 3 structures through a main-board upgrade action, pay 2 science in total.",
	35: "When entering Federation space 3, gain 1 extra credit.",
	36: "During production, one connected laboratory may replace its 1 science with 1 steelplast and 1 kelp. Its upgraded output is unchanged.",
	37: "When building the second laboratory at a connected city, gain 1 credit.",
	38: "When building your second tunnel in a turn, advance 1 Federation space.",
	40: "When your card does not match a colored action slot, gain 1 credit.",
	42: "During production, gain 1 extra steelplast.",
	57: "During production, gain 1 extra credit.",
	58: "When building the second desalination plant at a connected city, gain 1 credit.",
	59: "When completing the second upgraded farm at a connected city, gain 1 steelplast.",
	60: "Before drawing at the end of your turn, you may pay 1 credit to draw 2 extra cards.",
	61: "Once per turn, when upgrading a tunnel, gain 1 credit.",
	62: "When your card does not match a colored action slot, draw 1 card.",
	64: "When building your second farm in a turn, advance 1 Federation space.",
	66: "During production, one upgraded tunnel at a connected city may replace its 1 point with 1 kelp and 1 science; it still produces its credit.",
	79: "Once per turn, you may pay 1 credit to gain 1 steelplast.",
	80: "During production, gain 1 kelp per 2 connected upgraded laboratories.",
	81: "Once per turn, reduce a tunnel construction cost by 1 credit.",
	82: "During production, each connected city with at least 2 upgraded desalination plants produces 1 extra biomatter.",
	83: "When using the city-and-building action slot, you may build 1 additional building for its usual cost.",
	98: "Increase your hand limit by 1. Do not draw an extra card.",
	100: "Reduce every symbiotic city construction cost by 1 credit.",
	101: "Once per turn, you may pay 1 biomatter to gain 1 kelp and 1 steelplast.",
	102: "Once per turn, when building a laboratory, you may pay 1 credit to gain 1 point and draw 2 cards.",
	103: "Once per turn, when upgrading a farm, you may pay 1 credit to gain 1 kelp.",
	104: "After production, one connected city needs no kelp for feeding.",
	117: "During production, you may replace 1 biomatter produced with 1 steelplast, 1 point, and 1 credit.",
	118: "Once per turn, you may pay 1 credit to exchange 1 kelp for 1 steelplast, or 1 steelplast for 1 kelp.",
	119: "Once per turn, when upgrading a tunnel, you may pay 1 credit to gain 1 point and draw 1 card.",
	120: "When keeping a permanent card, including this card, gain 1 credit.",
	121: "Whenever you use an action card, you may exchange 1 steelplast for 1 science, or 1 science for 1 steelplast.",
	136: "Once per turn, when building a tunnel, advance 2 Federation spaces.",
	137: "When an action slot itself gives you at least 1 steelplast, gain 1 point. Federation and card rewards do not trigger this ability.",
	138: "At final scoring, you may exchange any number of sets of 1 science and 1 steelplast for 1 point per set.",
	142: "At final scoring, you may exchange biomatter for 1 point each.",
	155: "At final scoring, you may exchange sets of 1 science and 1 kelp for 1 point per set.",
	156: "The second tunnel you build in a turn is free.",
	157: "At final scoring, you may exchange sets of 1 steelplast and 1 kelp for 1 point per set.",
	174: "Once per turn, when advancing on the Federation track, gain 1 steelplast and draw 1 card.",
	175: "At final scoring, gain 1 point per 3 connected farms.",
	176: "At final scoring, you may pay 2 credits to gain 2 points once.",
	181: "At final scoring, exchange up to 14 steelplast for 1 point each.",
	182: "At final scoring, you may pay 15 credits to gain 13 points once.",
	183: "At final scoring, gain 3 points per 2 connected upgraded farms.",
	184: "At final scoring, exchange up to 6 biomatter for 2 points each.",
	185: "At final scoring, exchange up to 5 sets of 2 science for 3 points per set.",
	186: "At final scoring, gain 2 points per connected symbiotic city.",
	187: "At final scoring, exchange up to 5 sets of 2 kelp for 3 points per set.",
	188: "At final scoring, gain 2 points per connected upgraded desalination plant.",
	189: "At final scoring, gain 3 points per connected city with all 3 building types.",
	190: "At final scoring, gain 2 points per connected upgraded laboratory.",
	192: "During production, gain 1 extra credit and 2 kelp.",
	194: "During production, each connected city with at least 2 upgraded farms produces 2 extra credits and 1 extra point.",
	197: "During production, gain 1 extra steelplast, 1 credit, and 3 points.",
	201: "Whenever you build a city, advance 2 Federation spaces.",
	202: "Whenever you connect a new metropolis, gain 2 credits and 2 points.",
	203: "During production, gain 1 extra biomatter, 1 credit, and 2 points."
}, xt = [
	"",
	"拥有3条邻接连网城市的升级隧道。奖励：3分和2信用。",
	"已打出并支付3张特殊牌。奖励：3分和1生物质。",
	"连接2座都会。奖励：免费建造1座农场，获得1海带和3分。",
	"拥有2座含全部3种建筑的连网城市。奖励：免费建造1座实验室，获得1海带和3分。",
	"拥有2座连网升级农场和2条邻接连网城市的升级隧道。奖励：免费建造1座脱盐厂，获得1信用和4分。",
	"拥有3座连网共生城市。奖励：4分和1信用。",
	"拥有6条连网隧道。奖励：2分、1钢塑和2科研。",
	"4种设施各拥有至少1个连网升级设施。奖励：5分。"
], St = [
	"",
	"Have 3 upgraded tunnels at connected cities. Gain 3 points and 2 credits.",
	"Play and pay for 3 Special cards. Gain 3 points and 1 biomatter.",
	"Connect 2 metropolises. Build a farm for free; gain 1 kelp and 3 points.",
	"Have 2 connected cities with all 3 building types. Build a laboratory for free; gain 1 kelp and 3 points.",
	"Have 2 connected upgraded farms and 2 upgraded tunnels at connected cities. Build a desalination plant for free; gain 1 credit and 4 points.",
	"Have 3 connected symbiotic cities. Gain 4 points and 1 credit.",
	"Have 6 connected tunnels. Gain 2 points, 1 steelplast, and 2 science.",
	"Have at least 1 connected upgraded structure of each of the 4 types. Gain 5 points."
], Ct = [
	"每张已支付并保留的特殊牌获得2分。",
	"连网城市达到5、6、7座时，分别获得4、8、12分。",
	"连网隧道达到8、9、10条时，分别获得5、7、9分。",
	"每座连网都会获得3分。",
	"4种连网升级设施各1个为一组，每组获得4分。"
], wt = [
	"Score 2 points per paid Special card still kept.",
	"Score 4/8/12 points for 5/6/7 connected cities.",
	"Score 5/7/9 points for 8/9/10 connected tunnels.",
	"Score 3 points per connected metropolis.",
	"Score 4 points per set of 4 different connected upgraded structures."
], Tt = (e) => e === "zh" ? _t : vt, Y = (e, t) => Tt(t)[e] ?? e;
function X(e, t) {
	return Object.entries(e).filter(([, e]) => e !== 0).map(([e, n]) => e === "federation" ? Y("advanceFederation", t).replace("{{n}}", String(n)).replace("{{spaces}}", n === 1 ? "space" : "spaces") : `${n}${t === "en" ? " " : ""}${t === "en" && n === 1 ? {
		credit: "credit",
		point: "point",
		card: "card"
	}[e] ?? Y(e, t) : Y(e, t)}`).join(t === "zh" ? "、" : ", ");
}
var Z = (e, t) => t === "zh" ? V[e]?.nameZh ?? String(e) : V[e]?.name ?? String(e);
function Et(e, t) {
	if (!e) return "";
	let n = (e) => Y(e, t), r = t === "zh" ? "；" : "; ", i = (e.structures ?? []).map((r) => {
		let i = n(r);
		return t === "en" && (e.count ?? 1) > 1 ? r === "white" || r === "purple" ? i.replace(/city$/, "cities") : r === "lab" ? n("labPlural") : i + "s" : i;
	}).join(t === "zh" ? "或" : " or ");
	switch (e.kind) {
		case "gain": {
			let { federation: i, ...a } = e.gain ?? {};
			return [Object.keys(a).length ? `${n("gain")} ${X(a, t)}` : "", i ? X({ federation: i }, t) : ""].filter(Boolean).join(r);
		}
		case "all": return (e.effects ?? []).map((e) => Et(e, t)).join(r);
		case "choice": return (e.options ?? []).map((e) => Et(e, t)).join(t === "zh" ? "，或 " : "; OR ");
		case "pay": return `${n("pay")} ${X(e.cost ?? {}, t)}${r}${Et(e.then, t)}`;
		case "build": return `${n("build")} ${e.count ?? 1} ${i}${e.expansion ? ` · ${n("expansion")}` : ""} · ${e.free ? n("free") : e.override ? `${n("pay")} ${X(e.override, t)}` : n("usual")}${e.discount ? ` · ${n("discount")} ${X(e.discount, t)}` : ""}${e.after ? `${r}${n("upgrade")}${e.after.free ? ` · ${n("free")}` : ` · ${n("pay")} 1 ${n("science")}`}` : ""}`;
		case "upgrade": return `${n("upgrade")} ${n("upTo")} ${e.count ?? 1} ${i} · ${e.mode?.includes("|") ? e.mode.split("|").map((e) => X({ [e]: 1 }, t)).join(t === "zh" ? "或" : " or ") : X(e.cost ?? { science: 1 }, t)}`;
		case "if": return `${n("if")} ${n({
			farm: "connectedFarm",
			desal: "connectedDesal",
			lab: "connectedLab"
		}[e.condition.metric] ?? e.condition.metric)} ${e.condition.equal === void 0 ? `≥ ${e.condition.min}` : `= ${e.condition.equal}`}${t === "zh" ? "，" : ", "}${Et(e.then, t)}`;
		case "use": return `${n("useTemplate").replace("{{n}}", String(e.count ?? 1)).replace("{{cards}}", n((e.count ?? 1) === 1 ? "actionCard" : "actionCards"))}${e.keep ? ` · ${n("keep")}` : ""}`;
		case "useDiscarded": return `${n("useDiscarded")} · ${Z(e.card, t)} · ${Et(V[e.card].effect, t)}`;
		case "refresh": return n("refreshTemplate").replace("{{n}}", String(e.count ?? 1)).replace("{{cards}}", n((e.count ?? 1) === 1 ? "actionCard" : "actionCards"));
		case "mission": return `${n("mission")} · ${e.color ? n(e.color) + " " : ""}${n(e.mode ?? "available")}`;
		case "playCard": return Dt(e.card, t);
		case "scaled": return n("scaledTemplate").replace("{{n}}", String(e.count)).replace("{{kind}}", n(e.mode)).replace("{{gain}}", X(e.gain ?? {}, t));
		case "endExchange": return `${n("pay")} ${X(e.cost ?? {}, t)}${r}${n("gain")} ${X(e.gain ?? {}, t)} · ${n("upTo")} ${e.count}`;
		default: return n(e.kind);
	}
}
function Dt(e, t) {
	let n = V[e];
	return n ? n.effect && ["i", "a"].includes(n.type) ? Et(n.effect, t) : t === "zh" ? yt[e] ?? "" : bt[e] ? bt[e] : n.ruleEn.replace(/^Cost credit\d;\s*/, "").replace(/\b(credit|kelp|steel|science|bio|point|card|federation)(\d+)/g, (e, t, n) => `${n} ${t === "steel" ? "steelplast" : t === "bio" ? "biomatter" : t === "federation" ? "Federation spaces" : t === "card" ? "cards" : t === "point" ? "points" : t === "credit" ? "credits" : t}`).replace(/\bper(\d)/g, "per $1").replace(/>=/g, "at least ").replace(/==/g, " is ").replace(/\bdesals?\b/g, "desalination plants").replace(/\blabs\b/g, "laboratories").replace(/\bfed(?:eration)?(?=\d)/g, "Federation ").replace(/\+1/g, " increases by 1") : "";
}
function Ot(e, t) {
	let n = (e) => Y(e, t);
	if (e.effect && e.kind === "resolve") return Et(e.effect, t);
	let r = n(e.kind);
	return e.build && (r += ` ${n(e.build)}${e.target === void 0 ? "" : ` · ${e.target + 1}`}${e.site !== void 0 && e.site >= 0 ? ` / ${e.site === 4 ? n("expansion") : e.site + 1}` : ""}`), e.card !== void 0 && (r += ` · ${Z(e.card, t)}`), e.slot !== void 0 && (r += ` · ${n("slots")} ${e.slot + 1}`), e.value !== void 0 && e.kind !== "resolve" && (r += ` ${e.value}`), e.cost && x.some((t) => e.cost[t] > 0) && (r += ` · ${n("pay")} ${X(e.cost, t)}`), e.gain && (r += ` · ${n("gain")} ${X(e.gain, t)}`), r;
}
//#endregion
//#region src/games/underwatercities/resource-icon.tsx
function kt({ kind: e }) {
	let t = r().replace(/:/g, "");
	return /* @__PURE__ */ _("svg", {
		className: "uc-resource-icon",
		viewBox: "0 0 60 60",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ _("defs", { children: [/* @__PURE__ */ _("linearGradient", {
			id: `${t}-water`,
			x1: "0",
			y1: "0",
			x2: "1",
			y2: ".7",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#bcf5ef" }),
				/* @__PURE__ */ g("stop", {
					offset: ".4",
					stopColor: "#4aaac5"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#10557e"
				})
			]
		}), /* @__PURE__ */ _("linearGradient", {
			id: `${t}-metal`,
			x2: "1",
			y2: "1",
			children: [
				/* @__PURE__ */ g("stop", { stopColor: "#c2e2df" }),
				/* @__PURE__ */ g("stop", {
					offset: ".35",
					stopColor: "#365d77"
				}),
				/* @__PURE__ */ g("stop", {
					offset: ".7",
					stopColor: "#8db5c2"
				}),
				/* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#25425b"
				})
			]
		})] }), e === "credit" ? /* @__PURE__ */ _("g", {
			stroke: "#8b771e",
			strokeWidth: "1.5",
			children: [
				/* @__PURE__ */ g("rect", {
					x: "6",
					y: "3",
					width: "48",
					height: "54",
					rx: "2",
					fill: "#eed62f"
				}),
				/* @__PURE__ */ g("path", {
					d: "M12 4V56M48 4V56M6 12H54M6 48H54",
					fill: "none"
				}),
				/* @__PURE__ */ g("path", {
					d: "M18 6 15 14 19 18 15 23V38L19 42 16 48 20 54M40 6 44 14 40 18 44 23V38L40 42 44 48 40 54",
					fill: "none"
				}),
				/* @__PURE__ */ g("path", {
					d: "M29 21 24 26V29L28 27V44H33V21Z",
					stroke: "none",
					fill: "#665b15"
				})
			]
		}) : e === "point" ? /* @__PURE__ */ _("g", { children: [
			/* @__PURE__ */ g("path", {
				d: "M30 3 37 8 44 8 47 17 54 22 51 30 54 38 46 43 42 51 33 50 25 55 19 48 10 45 11 36 5 29 11 22 12 13 21 11 25 4Z",
				fill: `url(#${t}-metal)`,
				stroke: "#254b67",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M14 17 20 14M10 29 14 33M16 43 23 47M39 46 45 40M47 24 45 18",
				fill: "none",
				stroke: "#bdd6d5",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "30",
				cy: "31",
				r: "19",
				fill: "#194d71",
				stroke: "#8eb7c8",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M30 5C27 16 17 24 17 34A13 14 0 0 0 43 34C43 25 34 16 30 5Z",
				fill: `url(#${t}-water)`,
				stroke: "#bededf",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ g("path", {
				d: "M27 19Q19 29 22 37",
				fill: "none",
				stroke: "#e8faf4",
				strokeWidth: "2.5",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ g("path", {
				d: "M28 47Q36 49 41 41",
				fill: "none",
				stroke: "#6ca7bc",
				strokeWidth: "1.5"
			})
		] }) : /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("rect", {
			x: "3",
			y: "3",
			width: "54",
			height: "54",
			fill: e === "kelp" ? "#80b832" : e === "science" ? "#66b6c7" : e === "bio" ? "#df368f" : "#f3f4ee",
			stroke: e === "kelp" ? "#487321" : e === "bio" ? "#9c2967" : "#769da5",
			strokeWidth: "2"
		}), e === "bio" ? /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("circle", {
				cx: "30",
				cy: "30",
				r: "23",
				fill: "#fff9ee",
				stroke: "#7db6bb",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M30 9C30 21 38 27 51 29C39 31 33 39 31 51C29 39 21 34 9 32C21 29 27 22 30 9Z",
				fill: "#df2288"
			}),
			/* @__PURE__ */ g("path", {
				d: "M30 15Q31 27 44 29M16 32Q28 33 30 45",
				fill: "none",
				stroke: "#f363ae",
				strokeWidth: "1"
			})
		] }) : /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("circle", {
			cx: "30",
			cy: "30",
			r: "23",
			fill: "#fffdf3",
			stroke: e === "kelp" ? "#568b39" : "#78aeb7",
			strokeWidth: "1.5"
		}), e === "kelp" ? /* @__PURE__ */ g("g", {
			fill: "#7fa93f",
			stroke: "#739137",
			strokeWidth: ".8",
			children: /* @__PURE__ */ g("path", { d: "M30 49Q29 29 14 18Q19 34 30 49ZM31 49Q32 30 48 16Q43 37 31 49ZM30 44Q18 40 13 31Q15 45 30 49ZM31 43Q40 36 47 35Q44 46 31 49ZM30 43Q24 18 29 10Q35 21 30 43Z" })
		}) : e === "science" ? /* @__PURE__ */ _("g", {
			stroke: "#558eaa",
			strokeWidth: "1.8",
			children: [
				/* @__PURE__ */ g("path", {
					d: "M24 12H36V17H34V29L43 43Q44 48 39 48H21Q16 48 18 43L27 29V17H24Z",
					fill: `url(#${t}-water)`
				}),
				/* @__PURE__ */ g("path", {
					d: "M26 34H35L41 44Q42 46 38 46H23Q19 46 21 43Z",
					fill: "#2e95b6",
					stroke: "none"
				}),
				/* @__PURE__ */ g("path", {
					d: "M29 19V29L23 40",
					fill: "none",
					stroke: "#fff",
					strokeWidth: "2"
				})
			]
		}) : /* @__PURE__ */ _("g", {
			transform: "rotate(38 30 30)",
			stroke: "#82aebb",
			fill: "none",
			strokeWidth: "2",
			children: [/* @__PURE__ */ g("rect", {
				x: "19",
				y: "11",
				width: "22",
				height: "38",
				rx: "9"
			}), /* @__PURE__ */ g("path", { d: "M25 12V48M35 12V48M20 20H40M19 27H41M19 34H41M20 41H40" })]
		})] })] })]
	});
}
//#endregion
//#region src/games/underwatercities/art.tsx
function At() {
	let [e, t] = s(!1);
	return n(() => {
		let e = window.matchMedia("(orientation: landscape) and (max-height: 480px)"), n = () => t(e.matches);
		return n(), e.addEventListener("change", n), () => e.removeEventListener("change", n);
	}, []), [e, t];
}
var jt = {
	g: "#4d9655",
	r: "#d75b52",
	y: "#d8ac35",
	n: "#73858d",
	farm: "#83bd47",
	desal: "#e2ab39",
	lab: "#e7f5f5",
	tunnel: "#dab95e",
	white: "#dceef0",
	purple: "#bb80c9"
};
function Mt({ kind: e, up: t = !1 }) {
	let n = r().replace(/:/g, "");
	return /* @__PURE__ */ _("svg", {
		viewBox: "0 0 80 70",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ _("defs", { children: [/* @__PURE__ */ _("linearGradient", {
				id: `${n}-metal`,
				children: [
					/* @__PURE__ */ g("stop", { stopColor: "#789ca3" }),
					/* @__PURE__ */ g("stop", {
						offset: ".35",
						stopColor: "#eff6e9"
					}),
					/* @__PURE__ */ g("stop", {
						offset: ".6",
						stopColor: "#c7ddcf"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#527d8a"
					})
				]
			}), /* @__PURE__ */ _("linearGradient", {
				id: `${n}-glass`,
				x2: ".9",
				y2: "1",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: e === "purple" ? "#f0c4ee" : "#e6f8ee" }),
					/* @__PURE__ */ g("stop", {
						offset: ".5",
						stopColor: e === "purple" ? "#a573b8" : "#91c7d4",
						stopOpacity: ".6"
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: e === "purple" ? "#633e8a" : "#357a9c"
					})
				]
			})] }),
			t && /* @__PURE__ */ _("g", {
				stroke: "#385b63",
				strokeWidth: "1.5",
				children: [/* @__PURE__ */ g("path", {
					d: "M12 54Q40 42 68 54V62Q40 73 12 62Z",
					fill: "#84959a"
				}), /* @__PURE__ */ g("path", {
					d: "M13 54Q40 65 67 54M20 59V64M31 62V67M49 62V67M60 59V64",
					fill: "none",
					stroke: "#dae8dc"
				})]
			}),
			[
				"farm",
				"desal",
				"lab"
			].includes(e) ? /* @__PURE__ */ _("g", {
				stroke: "#375c62",
				strokeWidth: "1.4",
				strokeLinejoin: "round",
				children: [
					/* @__PURE__ */ g("ellipse", {
						cx: "40",
						cy: "56",
						rx: "30",
						ry: "8",
						fill: "#2c626d",
						opacity: ".35",
						stroke: "none"
					}),
					/* @__PURE__ */ g("path", {
						d: "M13 49Q40 38 67 49V56Q40 68 13 56Z",
						fill: `url(#${n}-metal)`
					}),
					/* @__PURE__ */ g("path", {
						d: "M16 22Q40 12 64 22V49Q40 60 16 49Z",
						fill: e === "farm" ? "#83b747" : e === "desal" ? "#d6ac2e" : "#cfdedc"
					}),
					/* @__PURE__ */ g("path", {
						d: "M18 25Q40 34 62 25V47Q40 57 18 47Z",
						fill: e === "farm" ? "#4f8b2a" : e === "desal" ? "#e8c959" : "#e5f0ec"
					}),
					/* @__PURE__ */ g("path", {
						d: "M22 29V49M32 32V52M48 32V52M58 29V49",
						stroke: e === "desal" ? "#97751d" : "#638c7f",
						strokeWidth: "2"
					}),
					e === "farm" ? /* @__PURE__ */ _("g", { children: [
						/* @__PURE__ */ g("path", {
							d: "M30 46V26H50V46Q40 52 30 46Z",
							fill: "#a6d9b5"
						}),
						/* @__PURE__ */ g("path", {
							d: "M40 46Q32 36 35 29Q41 33 40 46M41 44Q45 31 49 30Q50 41 41 44M40 42Q39 29 42 24",
							fill: "#4d8b2b",
							stroke: "#47792e"
						}),
						/* @__PURE__ */ g("path", {
							d: "M14 41H20V51H26M59 32H67V49H62",
							fill: "none",
							stroke: "#d9e6b7",
							strokeWidth: "3"
						})
					] }) : e === "desal" ? /* @__PURE__ */ _("g", { children: [
						/* @__PURE__ */ g("path", {
							d: "M26 35V45H33V35M47 35V46H54V35",
							fill: "#566d6b"
						}),
						/* @__PURE__ */ g("path", {
							d: "M21 48H28V55H54V49H64",
							fill: "none",
							stroke: "#e7edc8",
							strokeWidth: "3"
						}),
						/* @__PURE__ */ g("path", {
							d: "M36 40V48H42V40",
							fill: "#7bc1cf"
						}),
						/* @__PURE__ */ g("path", {
							d: "M62 34H70V50H65",
							fill: "none",
							stroke: "#7f9f9e",
							strokeWidth: "3"
						})
					] }) : /* @__PURE__ */ _("g", { children: [
						/* @__PURE__ */ g("path", {
							d: "M25 36H34V43H25ZM46 36H55V43H46Z",
							fill: "#70b6d0"
						}),
						/* @__PURE__ */ g("path", {
							d: "M35 36H44V52H35Z",
							fill: "#68959b"
						}),
						/* @__PURE__ */ g("path", {
							d: "M37 39H42V43H37",
							fill: "#d8f8dc",
							stroke: "none"
						}),
						/* @__PURE__ */ g("path", {
							d: "M15 41H10V52H19M63 41H69V52H61",
							fill: "none",
							stroke: "#e6efe4",
							strokeWidth: "3"
						})
					] }),
					/* @__PURE__ */ g("ellipse", {
						cx: "40",
						cy: "22",
						rx: "24",
						ry: "9",
						fill: e === "farm" ? "#b9d97e" : e === "desal" ? "#ffe591" : "#f7fcf1"
					}),
					/* @__PURE__ */ g("path", {
						d: "M23 22Q40 28 57 22M23 24V27M57 24V27",
						fill: "none",
						stroke: e === "farm" ? "#6e963d" : e === "desal" ? "#baa13e" : "#9bb9b5"
					}),
					/* @__PURE__ */ g("path", {
						d: "M30 19V13Q40 9 50 13V19Q40 23 30 19Z",
						fill: e === "farm" ? "#81b441" : e === "desal" ? "#dec556" : "#b9d0ce"
					}),
					/* @__PURE__ */ g("ellipse", {
						cx: "40",
						cy: "13",
						rx: "10",
						ry: "3.5",
						fill: e === "farm" ? "#d6eab2" : e === "desal" ? "#fff0b1" : "#f2fbf5"
					}),
					e === "lab" && /* @__PURE__ */ g("path", {
						d: "M38 10V4H44V10",
						fill: "#6b9fa4"
					}),
					[
						20,
						28,
						52,
						60
					].map((e) => /* @__PURE__ */ g("circle", {
						cx: e,
						cy: e < 40 ? 53 : 54,
						r: "1",
						fill: "#42666c",
						stroke: "none"
					}, e))
				]
			}) : e === "tunnel" ? /* @__PURE__ */ _("g", {
				stroke: "#3b6271",
				strokeWidth: "1.5",
				children: [
					/* @__PURE__ */ g("path", {
						d: "M7 26Q40 15 73 26V46Q40 60 7 46Z",
						fill: "#75a7b9"
					}),
					/* @__PURE__ */ g("path", {
						d: "M8 26Q40 38 73 26M8 44Q40 55 73 44",
						fill: "none",
						stroke: "#c5e5df",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ g("path", {
						d: "M15 24V49M29 21V53M44 21V54M59 23V50",
						stroke: "#d5b853",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ g("ellipse", {
						cx: "8",
						cy: "36",
						rx: "5",
						ry: "11",
						fill: "#2f6778"
					}),
					/* @__PURE__ */ g("path", {
						d: "M4 29 11 42M4 35 10 47",
						stroke: "#8fc8cb"
					}),
					/* @__PURE__ */ g("path", {
						d: "M22 30H26M37 32H41M52 30H56M66 29H69",
						stroke: "#eff3cb",
						strokeWidth: "3"
					})
				]
			}) : /* @__PURE__ */ _("g", {
				stroke: "#33596b",
				strokeWidth: "1.4",
				children: [
					/* @__PURE__ */ g("path", {
						d: "M5 51Q40 37 75 51V59Q40 75 5 59Z",
						fill: `url(#${n}-metal)`
					}),
					/* @__PURE__ */ g("ellipse", {
						cx: "40",
						cy: "51",
						rx: "35",
						ry: "11",
						fill: "#2c6778"
					}),
					/* @__PURE__ */ g("path", {
						d: "M8 51C8 22 22 5 40 5S72 22 72 51Q40 68 8 51Z",
						fill: `url(#${n}-glass)`
					}),
					/* @__PURE__ */ _("g", {
						fill: e === "purple" ? "#655088" : "#447d8e",
						stroke: "#b9dfdc",
						strokeWidth: ".7",
						children: [/* @__PURE__ */ g("path", { d: "M20 50V35L28 31 34 35V53L20 50M37 54V24L44 20 50 24V54M53 52V38L59 34 65 38V49" }), /* @__PURE__ */ g("path", {
							d: "M24 39V44M29 41V47M41 28V33M46 29V34M41 38V45M46 39V47M57 41V46M61 41V46",
							stroke: "#e0f4c3",
							strokeWidth: "1.8"
						})]
					}),
					/* @__PURE__ */ g("path", {
						d: "M8 51Q40 65 72 51M40 6C21 12 17 37 20 55M40 6C59 12 63 37 60 55M10 36Q40 48 70 36",
						fill: "none",
						stroke: "#c2dede",
						strokeOpacity: ".65"
					}),
					/* @__PURE__ */ g("path", {
						d: "M15 34Q20 15 33 11",
						stroke: "#f5fff3",
						strokeWidth: "3",
						strokeLinecap: "round",
						fill: "none"
					}),
					/* @__PURE__ */ g("path", {
						d: "M9 56Q40 69 71 56M16 59V64M29 63V67M51 63V67M64 59V64",
						fill: "none",
						stroke: "#3e6f7a"
					}),
					e === "purple" && /* @__PURE__ */ g("g", {
						fill: "#b6c688",
						stroke: "#617a57",
						children: /* @__PURE__ */ g("path", { d: "M29 54Q23 47 25 42Q31 47 29 54M52 54Q58 45 56 40Q50 46 52 54" })
					})
				]
			})
		]
	});
}
function Nt({ shape: e, x: t, y: n, width: r = 0, height: i = 0, r: a = 0, angle: o = 0 }) {
	let s = ne() ? null : /* @__PURE__ */ g("animate", {
		attributeName: "stroke-dashoffset",
		from: "0",
		to: "-24",
		dur: "1.2s",
		repeatCount: "indefinite"
	}), c = {
		fill: "none",
		stroke: "#fff2aa",
		strokeWidth: 3,
		strokeDasharray: "7 5",
		pointerEvents: "none"
	};
	return e === "circle" ? /* @__PURE__ */ g("circle", {
		...c,
		cx: t,
		cy: n,
		r: a,
		children: s
	}) : /* @__PURE__ */ g("rect", {
		...c,
		x: t,
		y: n,
		width: r,
		height: i,
		rx: 9,
		transform: `rotate(${o},${t + r / 2},${n + i / 2})`,
		children: s
	});
}
function Pt({ rule: e, x: t, y: n, lang: r }) {
	if (!e) return null;
	let i = e.cost ?? e.bonus ?? e.production ?? {}, a = Object.entries(i), o = e.cost ? "cost" : e.bonus ? "reward" : "production", s = Math.max(38, a.length * 36 + (e.multiplier ? 28 : 0));
	return /* @__PURE__ */ _("g", {
		transform: `translate(${t - s / 2},${n})`,
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ _("title", { children: [
				Y(o, r),
				": ",
				X(i, r),
				" ",
				e.multiplier ? `×${e.multiplier}` : ""
			] }),
			/* @__PURE__ */ g("rect", {
				width: s,
				height: "25",
				rx: "4",
				fill: e.cost ? "#6e3f3a" : "#dce7cd",
				stroke: e.cost ? "#d79577" : "#8aaba4"
			}),
			a.map(([t, n], r) => /* @__PURE__ */ _("g", {
				transform: `translate(${r * 36 + 2},1)`,
				children: [x.includes(t) ? /* @__PURE__ */ g("svg", {
					width: "21",
					height: "21",
					children: /* @__PURE__ */ g(kt, { kind: t })
				}) : t === "card" ? /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("rect", {
					x: "4",
					y: "3",
					width: "13",
					height: "18",
					rx: "1",
					fill: "#fffdf0",
					stroke: "#537b81"
				}), /* @__PURE__ */ g("path", {
					d: "M7 7H14M7 10H14",
					stroke: "#93b3b2"
				})] }) : /* @__PURE__ */ _("g", {
					fill: "none",
					stroke: "#b69a3a",
					strokeWidth: "1.5",
					children: [
						/* @__PURE__ */ g("circle", {
							cx: "11",
							cy: "11",
							r: "8"
						}),
						/* @__PURE__ */ g("ellipse", {
							cx: "11",
							cy: "11",
							rx: "3",
							ry: "8"
						}),
						/* @__PURE__ */ g("path", { d: "M3 11H19M1 6Q-2 19 7 22M21 6Q24 19 15 22" })
					]
				}), /* @__PURE__ */ g("text", {
					x: "23",
					y: "17",
					fill: e.cost ? "#fff5d8" : "#244a50",
					fontSize: "13",
					fontWeight: "800",
					children: n
				})]
			}, t)),
			e.multiplier && /* @__PURE__ */ _("text", {
				x: a.length * 36 + 3,
				y: "18",
				fill: "#234b56",
				fontSize: "15",
				fontWeight: "800",
				children: ["×", e.multiplier]
			})
		]
	});
}
function Ft({ id: e, lang: t, compact: n = !1 }) {
	let r = V[e], i = Tt(t);
	return /* @__PURE__ */ _("div", {
		className: `uc-card-face ${n ? "uc-card-compact" : ""}`,
		style: { "--uc-card-color": jt[r.color] },
		children: [
			/* @__PURE__ */ _("div", {
				className: "uc-card-heading",
				children: [
					/* @__PURE__ */ g("span", { children: i[r.color] }),
					/* @__PURE__ */ _("b", { children: ["#", e] }),
					r.cost > 0 && /* @__PURE__ */ _("span", {
						className: "uc-icon-cost",
						children: [r.cost, /* @__PURE__ */ g(kt, { kind: "credit" })]
					})
				]
			}),
			/* @__PURE__ */ g("strong", {
				className: "uc-card-title",
				children: Z(e, t)
			}),
			/* @__PURE__ */ _("div", {
				className: "uc-card-art",
				children: [/* @__PURE__ */ _("svg", {
					viewBox: "0 0 180 56",
					"aria-hidden": "true",
					children: [
						/* @__PURE__ */ g("path", {
							d: "M0 42Q45 20 90 40T180 34V56H0Z",
							fill: "#d3e5df"
						}),
						/* @__PURE__ */ g("path", {
							d: "M0 50Q50 36 110 48T180 46",
							fill: "none",
							stroke: "#7db5b1",
							strokeWidth: "2"
						}),
						/* @__PURE__ */ g("path", {
							d: "M15 44Q7 21 15 12M22 47Q28 25 22 20M160 47Q174 27 162 17",
							fill: "none",
							stroke: "#73a77b",
							strokeWidth: "4"
						}),
						/* @__PURE__ */ g("circle", {
							cx: "132",
							cy: "13",
							r: "4",
							fill: "none",
							stroke: "#a0c9cd"
						})
					]
				}), /* @__PURE__ */ g("div", { children: /* @__PURE__ */ g(Mt, { kind: e % 4 == 0 ? "farm" : e % 4 == 1 ? "lab" : e % 4 == 2 ? "desal" : "purple" }) })]
			}),
			/* @__PURE__ */ g("span", {
				className: "uc-type-label",
				children: Y(r.type, t)
			}),
			/* @__PURE__ */ g("p", { children: Dt(e, t) })
		]
	});
}
function It(e, t, n, r = ue) {
	let [i, a] = r[e], o = e === 0 ? [
		-90,
		-45,
		0,
		90
	] : e === 1 || e === 2 ? [
		-140,
		-90,
		-40,
		90
	] : e === 3 ? [
		-140,
		180,
		140,
		-90
	] : e === 4 ? [
		180,
		-90,
		0,
		90
	] : e === 5 ? [
		-40,
		0,
		40,
		180
	] : e === 6 ? [
		-140,
		-100,
		140,
		0
	] : e === 7 ? [
		-140,
		-90,
		-40,
		90
	] : [
		-40,
		0,
		40,
		180
	];
	n === 2 && e === 1 && o.splice(1, 1), n === 2 && e === 7 && o.splice(0, 1);
	let s = t === 4 ? e === 0 ? 45 : e < 3 ? e === 2 ? 45 : 135 : e === 3 ? -40 : e === 4 ? -140 : e === 5 ? 140 : e === 6 ? 40 : e === 7 ? 140 : 135 : o[t];
	return [i + Math.cos(s * Math.PI / 180) * 73, a + Math.sin(s * Math.PI / 180) * 73];
}
function Lt({ p: e, lang: t, options: r = [], selected: c, onPick: l }) {
	let u = a(() => L(e.board), [e.board]), ee = q(e), d = Tt(t), f = J(e, "cities"), p = f === 1 ? d.networkOne : d.network, { ref: ne } = m(`uc-board:${e.rid}`), h = o(null), re = te(), [v, y] = s(820), b = a(() => ue.map(([e, t]) => [55 + (e - 55) * (v - 110) / 710, t]), [v]);
	n(() => {
		let e = h.current;
		if (!e) return;
		let t = new ResizeObserver(() => {
			let t = e.getBoundingClientRect();
			t.height > 0 && y(Math.max(820, Math.round(720 * t.width / t.height)));
		});
		return t.observe(e), () => t.disconnect();
	}, []), i(() => {
		if (!re) return;
		let t = [], n = (e, n, r, i, a) => {
			t.push(e), re.registerProbe(e, () => {
				let e = h.current?.getBoundingClientRect();
				if (!e || e.height === 0) return null;
				let t = Math.min(e.width / v, e.height / 720);
				return {
					x: e.x + (e.width - v * t) / 2 + (n - i / 2) * t,
					y: e.y + (e.height - 720 * t) / 2 + (r - a / 2) * t,
					w: i * t,
					h: a * t
				};
			});
		};
		return b.forEach(([t, r], i) => {
			n(`uc-site:${e.rid}:city:${i}`, t, r, 96, 86);
			for (let t of [...Array.from({ length: u.regular[i] }, (e, t) => t), 4]) {
				let [r, a] = It(i, t, u.regular[i], b);
				n(`uc-site:${e.rid}:building:${i}:${t}`, r, a, 52, 48);
			}
		}), F.forEach(([t, r], i) => {
			let a = b[t], o = r < 9 ? b[r] : r === 9 ? [55, 110] : r === 10 ? [v - 50, 110] : [55, 590];
			n(`uc-site:${e.rid}:tunnel:${i}`, (a[0] + o[0]) / 2, (a[1] + o[1]) / 2 + (i === 12 ? -33 : i === 13 ? 33 : 0), 74, 46);
		}), () => t.forEach((e) => re.registerProbe(e, null));
	}, [
		re,
		e.rid,
		u,
		b,
		v
	]);
	let ie = (e, t, n = -1, i = !1) => r.find((r) => (r.kind === e || e === "build" && r.kind === "convert") && r.target === t && (r.site ?? -1) === n && (n >= 0 || r.build === "tunnel" === i)), ae = r[0] ? `${r[0].build}:${r[0].target}:${r[0].site}` : "start";
	i(() => {
		let e = h.current, t = e?.parentElement?.parentElement;
		if (!e || !t?.classList.contains("uc-zoom")) return;
		let n = e.querySelector("[role=\"button\"]") ?? e.querySelector("[data-uc-city=\"8\"]");
		if (!n) return;
		let r = n.getBoundingClientRect(), i = t.getBoundingClientRect();
		t.scrollTo({
			left: t.scrollLeft + r.x + r.width / 2 - i.x - i.width / 2,
			top: t.scrollTop + r.y + r.height / 2 - i.y - i.height / 2
		});
	}, [
		v,
		e.rid,
		ae
	]);
	let oe = (e) => e ? {
		role: "button",
		tabIndex: 0,
		onClick: () => l?.(e),
		onKeyDown: (t) => {
			(t.key === "Enter" || t.key === " ") && (t.preventDefault(), l?.(e));
		},
		"aria-label": `${Y(e.kind, t)} ${Y(e.build ?? "city", t)} ${e.target + 1}${e.site !== void 0 && e.site >= 0 ? ` / ${e.site === 4 ? d.expansion : e.site + 1}` : ""}`
	} : {};
	return /* @__PURE__ */ _("div", {
		ref: ne,
		className: "uc-board-wrap",
		children: [/* @__PURE__ */ _("svg", {
			ref: h,
			className: "uc-ocean-board",
			viewBox: `0 0 ${v} 720`,
			"aria-label": `${d.board} ${e.board} · ${f} ${p}`,
			children: [
				/* @__PURE__ */ _("defs", { children: [/* @__PURE__ */ _("linearGradient", {
					id: `sea-${e.rid}`,
					x2: ".8",
					y2: "1",
					children: [/* @__PURE__ */ g("stop", { stopColor: "#0e6680" }), /* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: "#083c57"
					})]
				}), /* @__PURE__ */ g("pattern", {
					id: `contour-${e.rid}`,
					width: "150",
					height: "120",
					patternUnits: "userSpaceOnUse",
					children: /* @__PURE__ */ g("path", {
						d: "M-20 40Q30-20 100 40T180 40M-20 60Q30 0 100 60T180 60M-20 80Q30 20 100 80T180 80",
						fill: "none",
						stroke: "#5da4a9",
						strokeOpacity: ".17",
						strokeWidth: "2"
					})
				})] }),
				/* @__PURE__ */ g("rect", {
					width: v,
					height: "720",
					rx: "26",
					fill: `url(#sea-${e.rid})`
				}),
				/* @__PURE__ */ g("rect", {
					width: v,
					height: "720",
					rx: "26",
					fill: `url(#contour-${e.rid})`
				}),
				/* @__PURE__ */ g("path", {
					d: `M0 0H88L68 63 97 118 58 157 72 204 23 247 39 329 0 365ZM${v} 0H${v - 70}L${v - 48} 48 ${v - 81} 98 ${v - 45} 157 ${v - 70} 190 ${v - 26} 270 ${v} 289ZM0 720V612L45 577 81 589 71 655 104 698 95 720Z`,
					fill: "#759b8b",
					stroke: "#afd0aa",
					strokeWidth: "5"
				}),
				/* @__PURE__ */ g("g", {
					opacity: ".6",
					stroke: "#72b690",
					strokeWidth: "6",
					fill: "none",
					children: /* @__PURE__ */ g("path", { d: "M65 507Q84 458 70 429M75 503Q101 479 93 462M745 610Q726 568 740 534M753 620Q770 585 760 569" })
				}),
				F.map(([n, r], i) => {
					let a = b[n], o = r < 9 ? b[r] : r === 9 ? [55, 110] : r === 10 ? [v - 50, 110] : [55, 590], s = i === 12 ? -33 : i === 13 ? 33 : 0, l = (a[0] + o[0]) / 2, d = (a[1] + o[1]) / 2 + s, f = ie(e.tunnels[i] === 1 ? "upgrade" : "build", i, -1, !0), p = !!f, m = !!f && f.id === c, te = Math.atan2(o[1] - a[1], o[0] - a[0]) * 180 / Math.PI, ne = u.tunnel[i];
					return /* @__PURE__ */ _("g", {
						...oe(f),
						className: p ? "uc-board-hit" : "",
						children: [
							/* @__PURE__ */ g("path", {
								d: `M${a[0]} ${a[1] + s}L${o[0]} ${o[1] + s}`,
								stroke: e.tunnels[i] ? ee.has(n) ? "#c9db8c" : "#78918d" : "#5a8e9e",
								strokeWidth: e.tunnels[i] ? 13 : 4,
								strokeDasharray: e.tunnels[i] ? void 0 : "6 8"
							}),
							/* @__PURE__ */ g("rect", {
								x: l - 37,
								y: d - 23,
								width: "74",
								height: "46",
								rx: "10",
								fill: m ? "#ffe591" : p ? "#d7edc2" : e.tunnels[i] ? "#d2b45e" : "#174e65",
								stroke: p ? "#fff2a2" : "#90b6b4",
								strokeWidth: p ? 4 : 2,
								transform: `rotate(${te},${l},${d})`
							}),
							p && /* @__PURE__ */ g(Nt, {
								shape: "rect",
								x: l - 40,
								y: d - 26,
								width: 80,
								height: 52,
								angle: te
							}),
							e.tunnels[i] > 0 && /* @__PURE__ */ g("svg", {
								x: l - 34,
								y: d - 25,
								width: "68",
								height: "50",
								children: /* @__PURE__ */ g(Mt, {
									kind: "tunnel",
									up: e.tunnels[i] === 2
								})
							}),
							/* @__PURE__ */ g("text", {
								x: l,
								y: e.tunnels[i] ? d + 36 : d + 7,
								textAnchor: "middle",
								fill: e.tunnels[i] ? "#f3edc4" : p ? "#244d52" : "#c6dddd",
								fontSize: e.tunnels[i] ? 15 : 20,
								fontWeight: "800",
								children: e.tunnels[i] === 2 ? "Ⅱ" : e.tunnels[i] ? "Ⅰ" : i + 1
							}),
							/* @__PURE__ */ g(Pt, {
								rule: ne,
								x: l,
								y: d + 27,
								lang: t
							})
						]
					}, i);
				}),
				b.map(([n, r], i) => {
					let a = e.cities[i], o = ie("build", i), s = !!o && o.id === c, l = ee.has(i) && a !== "empty";
					return /* @__PURE__ */ _("g", {
						"data-uc-city": i,
						children: [/* @__PURE__ */ _("g", {
							...oe(o),
							className: o ? "uc-board-hit" : "",
							children: [
								/* @__PURE__ */ g("circle", {
									cx: n,
									cy: r,
									r: "50",
									fill: s ? "#f3d67f" : o ? "#72a9a5" : "#14516a",
									stroke: o ? "#ffe796" : l ? "#c8e9df" : "#6998a6",
									strokeWidth: o ? 5 : 3,
									strokeDasharray: a === "empty" ? "7 6" : void 0
								}),
								o && /* @__PURE__ */ g(Nt, {
									shape: "circle",
									x: n,
									y: r,
									r: 55
								}),
								a === "empty" ? /* @__PURE__ */ g("text", {
									x: n,
									y: r + 10,
									textAnchor: "middle",
									fontSize: "30",
									fontWeight: "800",
									fill: "#c1dcde",
									children: i + 1
								}) : /* @__PURE__ */ g("svg", {
									x: n - 48,
									y: r - 43,
									width: "96",
									height: "84",
									opacity: l ? 1 : .55,
									children: /* @__PURE__ */ g(Mt, { kind: a })
								}),
								a !== "empty" && /* @__PURE__ */ _("text", {
									x: n,
									y: r + 65,
									textAnchor: "middle",
									fill: "#e5f6ed",
									fontSize: "18",
									children: [
										i + 1,
										" ",
										l ? "●" : "○"
									]
								}),
								/* @__PURE__ */ g(Pt, {
									rule: u.city[i],
									x: n,
									y: r - 42,
									lang: t
								})
							]
						}), [...Array.from({ length: u.regular[i] }, (e, t) => t), ...u.expansion[i] ? [4] : []].map((n) => {
							let [r, a] = It(i, n, u.regular[i], b), o = e.buildings[i].find((e) => e.site === n), s = ie(o ? "upgrade" : "build", i, n), l = !!s && s.id === c, ee = u.building[`${i}:${n}`];
							return /* @__PURE__ */ _("g", {
								...oe(s),
								className: s ? "uc-board-hit" : "",
								children: [
									/* @__PURE__ */ g("circle", {
										cx: r,
										cy: a,
										r: "26",
										fill: l ? "#ffe5a0" : s ? "#d2e8c0" : n === 4 ? "#184d66" : "#3c7785",
										stroke: s ? "#fff4b1" : n === 4 ? "#72b6dc" : "#76b0b4",
										strokeDasharray: n === 4 ? "4 5" : void 0,
										strokeWidth: s ? 4 : 2
									}),
									s && /* @__PURE__ */ g(Nt, {
										shape: "circle",
										x: r,
										y: a,
										r: 30
									}),
									o ? /* @__PURE__ */ g("svg", {
										x: r - 27,
										y: a - 26,
										width: "54",
										height: "48",
										children: /* @__PURE__ */ g(Mt, {
											kind: o.kind,
											up: o.up
										})
									}) : /* @__PURE__ */ _("text", {
										x: r,
										y: a + 6,
										fontSize: "16",
										textAnchor: "middle",
										fill: s ? "#335957" : "#c0dbdc",
										children: [n === 4 ? "E" : n + 1, ee?.multiplier ? ` ×${ee.multiplier}` : ""]
									}),
									/* @__PURE__ */ g(Pt, {
										rule: ee,
										x: r,
										y: a + 22,
										lang: t
									})
								]
							}, n);
						})]
					}, i);
				}),
				[
					0,
					1,
					2
				].map((t) => {
					let [n, r] = t === 0 ? [55, 110] : t === 1 ? [v - 50, 110] : [55, 590], i = e.metroConnected[t];
					return /* @__PURE__ */ _("g", { children: [
						/* @__PURE__ */ g("path", {
							d: `M${n} ${r - 43}L${n + 39} ${r - 22}V${r + 22}L${n} ${r + 43}L${n - 39} ${r + 22}V${r - 22}Z`,
							fill: t === 0 ? "#977c58" : "#81b6c6",
							stroke: i ? "#f4e4a2" : "#244d63",
							strokeWidth: "4"
						}),
						/* @__PURE__ */ g("path", {
							d: `M${n - 24} ${r + 18}V${r - 6}H${n - 10}V${r + 18}M${n - 4} ${r + 18}V${r - 24}H${n + 11}V${r + 18}M${n + 16} ${r + 18}V${r - 2}H${n + 27}V${r + 18}`,
							fill: "#e9e8cf",
							stroke: "#355b67",
							strokeWidth: "2"
						}),
						/* @__PURE__ */ _("text", {
							x: n,
							y: r + 66,
							fontSize: "20",
							textAnchor: "middle",
							fill: "#edf3dc",
							children: [
								i ? "✓" : "○",
								" ",
								e.metro[t] + 1
							]
						})
					] }, t);
				}),
				/* @__PURE__ */ _("text", {
					x: v / 2,
					y: "704",
					textAnchor: "middle",
					fontSize: "20",
					fill: "#bcd5d6",
					children: [
						d.board,
						" ",
						e.board,
						" · ",
						f,
						" ",
						p
					]
				})
			]
		}), /* @__PURE__ */ _("div", {
			className: "uc-metro-legend",
			children: [/* @__PURE__ */ _("p", { children: ["⬟ ", t === "zh" ? Ct[e.metro[0]] : wt[e.metro[0]]] }), [1, 2].map((n) => /* @__PURE__ */ _("p", { children: [
				"⬡ ",
				e.metro[n] + 1,
				" · ",
				X(de[e.metro[n]].instant, t),
				Object.keys(de[e.metro[n]].production).length > 0 ? ` · ${d.production}: ${X(de[e.metro[n]].production, t)}` : ""
			] }, n))]
		})]
	});
}
//#endregion
//#region src/games/underwatercities/view-player.tsx
function Rt(e) {
	let t = c((e) => e.locale), n = Tt(t), r = e.public, i = e.private, [a, o] = s(e.myRid), [l, m] = s("city"), [te, ne] = s(null), [re, y] = s(""), [b, ie] = s(null), [ae, oe] = s(null), [se, S] = s(!1), C = (e) => {
		e !== null && oe(e), S(e !== null);
	}, [w, T] = At(), E = i?.options ?? [], D = r.prompt?.rid === e.myRid, O = r.players.find((e) => e.rid === a) ?? r.players[0], k = r.players.find((t) => t.rid === e.myRid) ?? O, A = J(O, "cities"), ce = A === 1 ? n.networkOne : n.network, j = (t) => e.members.find((e) => e.rid === t)?.name ?? t, le = (e) => JSON.stringify(e), M = E.find((e) => le(e) === re), N = r.prompt, P = N?.kind === "turn", F = N?.kind === "discard", ue = P && te !== null && i?.hand.includes(te) ? te : null, I = [...new Set(E.map((e) => e.build).filter(Boolean))], L = [
		"use",
		"refresh",
		"replace",
		"scoreCard",
		"permanent",
		"takeSpecial"
	], de = D && E.some((e) => L.includes(e.kind)), fe = D && I.length ? "city" : de ? "cards" : l, z = b && I.includes(b) ? b : I[0], pe = D && O.rid === e.myRid ? E.filter((e) => e.build === z) : [], B = (e) => y(le(e)), me = (t) => {
		e.send({
			type: "choose",
			id: t.id
		}), y(""), ne(null);
	}, he = (e) => {
		if (P) ne(e), y(""), m("slots");
		else if (F) {
			let t = E.find((t) => t.card === e);
			t && B(t);
		} else C(e);
	}, ge = E.filter((e) => ![
		"play",
		"clone",
		"discard",
		"build",
		"upgrade",
		...L
	].includes(e.kind)), _e = N && N.kind in n ? Y(N.kind, t) : n.automatic, ve = M ? Ot(M, t) : D ? P ? ue === null ? n.selectCard : n.selectSlot : F ? n.discard : I.length ? n.selectTarget : n.selectOption : `${n.waiting} · ${j(N?.rid ?? r.active)}`;
	return /* @__PURE__ */ _(f, {
		adaptive: !0,
		scroll: !1,
		className: "uc-screen",
		banner: /* @__PURE__ */ _("div", {
			className: "uc-banner",
			children: [
				/* @__PURE__ */ _("div", {
					className: "uc-phase",
					children: [/* @__PURE__ */ _("b", { children: [
						n.era,
						" ",
						r.era,
						" · ",
						n.round,
						" ",
						r.round,
						"/10"
					] }), /* @__PURE__ */ g("span", { children: D ? _e : `${j(N?.rid ?? r.active)} · ${_e}` })]
				}),
				/* @__PURE__ */ g(p, {
					members: e.members,
					myRid: e.myRid,
					variant: "mini",
					adaptive: !0,
					onPick: o,
					picked: (e) => e === O.rid,
					status: (e) => /* @__PURE__ */ g("span", { children: r.players.find((t) => t.rid === e)?.resources.point ?? 0 })
				}),
				/* @__PURE__ */ g("div", {
					className: "uc-resource-bar",
					children: x.map((e) => /* @__PURE__ */ _("span", {
						className: `uc-resource uc-resource-${e}`,
						children: [
							/* @__PURE__ */ g(kt, { kind: e }),
							/* @__PURE__ */ g("b", { children: /* @__PURE__ */ g(ee, { value: k.resources[e] }) }),
							/* @__PURE__ */ g("small", { children: Y(e, t) })
						]
					}, e))
				})
			]
		}),
		actionsHeight: "uc-actions-height",
		actions: /* @__PURE__ */ _("div", {
			className: "uc-actions",
			children: [D && I.length > 0 ? /* @__PURE__ */ _("div", {
				className: "uc-construction-dock",
				children: [/* @__PURE__ */ _("div", {
					className: "uc-tools",
					children: [I.map((n) => /* @__PURE__ */ g("button", {
						onClick: () => {
							ie(n), y(""), o(e.myRid), m("city");
						},
						className: n === z ? "uc-tab-selected" : "",
						children: Y(n, t)
					}, n)), ge.map((e) => /* @__PURE__ */ g("button", {
						className: M?.id === e.id ? "uc-selected" : "",
						onClick: () => B(e),
						children: Ot(e, t)
					}, e.id))]
				}), M?.build && /* @__PURE__ */ g("div", {
					className: "uc-payment-options",
					children: E.filter((e) => e.build === z && e.target === M.target && e.site === M.site).map((e) => /* @__PURE__ */ g("button", {
						className: M?.id === e.id ? "uc-selected" : "",
						onClick: () => B(e),
						children: Ot(e, t)
					}, e.id))
				})]
			}) : /* @__PURE__ */ g("div", {
				className: "uc-hand",
				"aria-label": n.hand,
				children: (i?.hand ?? []).map((e) => /* @__PURE__ */ _("article", {
					className: ue === e || M?.card === e ? "uc-hand-card uc-selected" : "uc-hand-card",
					children: [/* @__PURE__ */ g("button", {
						className: `uc-card-button ${D && (P || F) ? "uc-target" : ""}`,
						onClick: () => he(e),
						"aria-label": `${Z(e, t)} · ${Dt(e, t)}`,
						children: /* @__PURE__ */ g(Ft, {
							id: e,
							lang: t,
							compact: !0
						})
					}), /* @__PURE__ */ g("button", {
						className: "uc-detail",
						onClick: () => C(e),
						"aria-label": `${n.details} · ${Z(e, t)}`,
						children: /* @__PURE__ */ g(v, { size: 18 })
					})]
				}, e))
			}), /* @__PURE__ */ _("div", {
				className: "uc-confirm",
				children: [/* @__PURE__ */ g("p", { children: ve }), /* @__PURE__ */ g("button", {
					className: "btn-base",
					disabled: !M,
					onClick: () => M && me(M),
					children: n.confirm
				})]
			})]
		}),
		children: [
			/* @__PURE__ */ g(d, {
				kind: "sheen",
				base: "#d9e8e6",
				className: "uc-texture"
			}),
			/* @__PURE__ */ g("div", {
				className: "uc-tabs",
				children: [
					"city",
					"slots",
					"cards"
				].map((e) => /* @__PURE__ */ g("button", {
					className: fe === e ? "uc-tab-selected" : "",
					onClick: () => m(e),
					children: n[e]
				}, e))
			}),
			/* @__PURE__ */ _("div", {
				className: "uc-layout",
				"data-tab": fe,
				children: [
					/* @__PURE__ */ _("section", {
						className: "uc-board-section",
						children: [
							/* @__PURE__ */ _("div", {
								className: "uc-board-toolbar",
								children: [/* @__PURE__ */ _("b", { children: [
									j(O.rid),
									" · ",
									A,
									" ",
									ce
								] }), /* @__PURE__ */ g("button", {
									onClick: () => T(!w),
									children: w ? n.fit : n.zoom
								})]
							}),
							/* @__PURE__ */ g("div", {
								className: `uc-board-viewport ${w ? "uc-zoom" : ""}`,
								children: /* @__PURE__ */ g(Lt, {
									p: O,
									lang: t,
									options: pe,
									selected: M?.id,
									onPick: B
								})
							}),
							/* @__PURE__ */ _("div", {
								className: "uc-fed-track",
								children: [/* @__PURE__ */ g("b", { children: n.federation }), [
									0,
									1,
									2,
									3,
									4
								].map((e) => /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("span", { children: e === 0 ? "—" : 5 - e }), r.players.filter((t) => t.fed === e).sort((e, t) => t.fedStamp - e.fedStamp).map((e) => /* @__PURE__ */ g("strong", { children: j(e.rid) }, e.rid))] }, e))]
							})
						]
					}),
					/* @__PURE__ */ _("aside", {
						className: "uc-side",
						children: [/* @__PURE__ */ _("section", {
							className: "uc-slots-section",
							children: [/* @__PURE__ */ g("h2", { children: n.slots }), /* @__PURE__ */ g("div", {
								className: "uc-slot-grid",
								children: R(r.players.length).map((e) => {
									let n = E.find((t) => t.slot === e.id && (P ? t.card === ue : t.kind === "mission")), i = r.slots[e.id];
									return /* @__PURE__ */ _("button", {
										className: `uc-slot ${n ? "uc-target " : ""}${M?.id === n?.id && n ? "uc-selected" : ""}`,
										style: { "--uc-slot-color": jt[e.color] },
										disabled: !n,
										onClick: () => n && B(n),
										children: [/* @__PURE__ */ _("span", {
											className: "uc-slot-title",
											children: [
												Y(e.color, t),
												" ",
												e.id + 1,
												i.length > 0 ? " · " + i.map((e) => e === "solo" ? "⊘" : j(e)).join(", ") : ""
											]
										}), /* @__PURE__ */ g("span", { children: Et(e.effect, t) })]
									}, e.id);
								})
							})]
						}), /* @__PURE__ */ _("section", {
							className: "uc-cards-section",
							children: [
								/* @__PURE__ */ _("h2", { children: [
									n.claimed,
									" · ",
									j(O.rid)
								] }),
								/* @__PURE__ */ g("div", {
									className: "uc-claimed",
									children: O.claimed.map((r) => /* @__PURE__ */ _("button", {
										onClick: () => {
											let t = O.rid === e.myRid ? E.find((e) => [
												"use",
												"refresh",
												"replace",
												"scoreCard",
												"permanent"
											].includes(e.kind) && e.card === r) : void 0;
											t ? B(t) : C(r);
										},
										className: `${O.used.includes(r) ? "uc-used" : ""} ${D && O.rid === e.myRid && E.some((e) => L.includes(e.kind) && e.card === r) ? "uc-target" : ""} ${O.rid === e.myRid && M?.card === r ? "uc-selected" : ""}`,
										children: [/* @__PURE__ */ _("span", { children: [
											Y(V[r].type, t),
											" · ",
											Z(r, t)
										] }), V[r].type === "a" && /* @__PURE__ */ g("b", { children: O.used.includes(r) ? n.used : n.ready })]
									}, r))
								}),
								/* @__PURE__ */ g("h2", { children: n.special }),
								/* @__PURE__ */ g("div", {
									className: "uc-special-row",
									children: [...r.specialTop === null ? [] : [r.specialTop], ...r.highSpecial].map((n) => /* @__PURE__ */ _("button", {
										onClick: () => {
											let e = E.find((e) => e.kind === "takeSpecial" && e.card === n);
											e ? B(e) : C(n);
										},
										className: `${D && E.some((e) => e.kind === "takeSpecial" && e.card === n) ? "uc-target" : ""} ${O.rid === e.myRid && M?.card === n ? "uc-selected" : ""}`,
										children: [Z(n, t), /* @__PURE__ */ _("small", {
											className: "uc-icon-cost",
											children: [V[n].cost, /* @__PURE__ */ g(kt, { kind: "credit" })]
										})]
									}, n))
								}),
								r.contracts.length > 0 && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("h2", { children: n.contracts }), r.contracts.map((e) => /* @__PURE__ */ _("p", {
									className: "uc-contract",
									children: [
										e,
										". ",
										(t === "zh" ? xt : St)[e]
									]
								}, e))] }),
								/* @__PURE__ */ _("p", {
									className: "uc-supply",
									children: [
										n.supply,
										" · ",
										n.white,
										" ",
										r.supply.white,
										" · ",
										n.purple,
										" ",
										r.players.length === 1 ? "∞" : r.supply.purple,
										" · ",
										n.tunnel,
										" ",
										r.supply.tunnel
									]
								})
							]
						})]
					}),
					D && !P && !F && !I.length && /* @__PURE__ */ _("section", {
						className: "uc-decisions",
						children: [
							/* @__PURE__ */ g("h2", { children: _e }),
							I.length > 0 && /* @__PURE__ */ g("div", {
								className: "uc-tools",
								children: I.map((n) => /* @__PURE__ */ g("button", {
									onClick: () => {
										ie(n), o(e.myRid), m("city");
									},
									className: n === z ? "uc-tab-selected" : "",
									children: Y(n, t)
								}, n))
							}),
							I.length > 0 && M?.build && /* @__PURE__ */ g("div", {
								className: "uc-target-choices",
								children: E.filter((e) => e.build === z && e.target === M.target && e.site === M.site).map((e) => /* @__PURE__ */ g("button", {
									className: M?.id === e.id ? "uc-selected" : "",
									onClick: () => B(e),
									children: Ot(e, t)
								}, e.id))
							}),
							/* @__PURE__ */ g("div", {
								className: "uc-effect-choices",
								children: ge.map((e) => /* @__PURE__ */ _("button", {
									className: `${M?.id === e.id ? "uc-selected" : ""} ${e.kind === "skip" ? "uc-skip" : "uc-target"}`,
									onClick: () => B(e),
									children: [Ot(e, t), e.card !== void 0 && [
										"takeSpecial",
										"takePeek",
										"claimCard",
										"scoreCard"
									].includes(e.kind) && /* @__PURE__ */ g("small", { children: Dt(e.card, t) })]
								}, e.id))
							})
						]
					})
				]
			}),
			/* @__PURE__ */ g("div", {
				className: "uc-detail-layer",
				children: /* @__PURE__ */ g(u, {
					open: se,
					onClose: () => C(null),
					label: n.details,
					title: ae === null ? n.details : Z(ae, t),
					children: ae !== null && /* @__PURE__ */ _("div", {
						className: "uc-card-detail",
						children: [/* @__PURE__ */ g(Ft, {
							id: ae,
							lang: t
						}), /* @__PURE__ */ _("p", { children: [
							n.cost,
							": ",
							V[ae].cost ? X({ credit: V[ae].cost }, t) : n.free
						] })]
					})
				})
			})
		]
	});
}
//#endregion
//#region src/games/underwatercities/bot.ts
var zt = {
	economy: 1,
	connection: 1.1,
	synergy: 1,
	federation: .8,
	conservation: 1
}, Q = (e, t, n) => Object.entries(e).reduce((e, [r, i]) => e + i * Bt(r, t, n), 0);
function Bt(e, t, n) {
	let r = n.round <= 4 ? 3 : n.round <= 7 ? 2 : 1;
	if (e === "point") return n.round >= 8 ? 1.4 : .7;
	if (e === "card") return t.handCount < 4 ? .55 : .22;
	if (e === "federation") return n.players.length === 1 ? .4 : t.fed < 3 ? 1.1 : .8;
	let i = t.resources[e], a = e === "kelp" ? Math.max(2, J(t, "cities")) : e === "steel" || e === "credit" ? 3 : e === "science" ? 2 : 1;
	return ((e === "bio" ? 1.6 : e === "science" ? 1.3 : 1.35) + (i < a ? .7 : 0) - (i > a + 4 ? .65 : 0)) * (r === 1 && n.round === 10 ? .7 : 1);
}
function Vt(e, t, n, r) {
	let i = V[e], a = n.round <= 4 ? 3 : n.round <= 7 ? 2 : 1;
	if (i.type === "i") return $(i.effect, t, n, r);
	if (i.type === "a") {
		let e = t.claimed.filter((e) => V[e].type === "a").length;
		return $(i.effect, t, n, r) * Math.max(.45, 1.5 - e * .2) + a * .3;
	}
	return i.type === "d" ? a * (i.id === 104 ? 2.5 : [
		192,
		197,
		203
	].includes(e) ? 5 : 1.9) * r.economy : i.type === "e" ? e >= 181 ? Math.max(2, J(t, "upFarm") + J(t, "upLab") + J(t, "upDesal")) : 2.2 : ([
		18,
		20,
		37,
		58,
		59,
		61,
		64,
		79,
		81,
		100,
		101,
		102,
		103,
		119,
		120,
		121,
		136,
		137,
		156,
		174,
		201,
		202
	].includes(e) ? 3 : 1.8) * a * .55 * r.synergy;
}
function $(e, t, n, r) {
	if (!e) return 0;
	let i = (n.round <= 4 ? 3 : n.round <= 7 ? 2 : 1) * r.economy;
	switch (e.kind) {
		case "gain": return Q(e.gain ?? {}, t, n);
		case "all": return e.effects?.reduce((e, i) => e + $(i, t, n, r), 0) ?? 0;
		case "choice": return Math.max(0, ...(e.options ?? []).map((e) => $(e, t, n, r)));
		case "pay": return Object.entries(e.cost ?? {}).some(([e, n]) => (t.resources[e] ?? 0) < n) ? 0 : Math.max(0, $(e.then, t, n, r) - Q(e.cost ?? {}, t, n) * r.conservation);
		case "build": return Math.max(...(e.structures ?? []).map((e) => e === "tunnel" ? 2.3 * r.connection : e === "white" ? 3.1 * r.connection : e === "purple" ? 3.5 * r.connection : e === "farm" ? 1.6 * i + 1 : e === "desal" ? 2.1 * i : 2 * i), 0) * (e.count ?? 1) + (e.free ? 2 : 0);
		case "upgrade": return Math.min(e.count ?? 1, t.buildings.flat().filter((e) => !e.up).length + t.tunnels.filter((e) => e === 1).length) * i * 1.5;
		case "use": return Math.max(0, ...t.claimed.filter((e) => V[e].type === "a" && !t.used.includes(e)).map((e) => $(V[e].effect, t, n, r))) * (e.count ?? 1);
		case "refresh": return t.used.length > 0 ? 2.2 : 0;
		case "if": {
			let i = e.condition, a = J(t, i.metric);
			return (i.equal === void 0 ? a >= (i.min ?? 0) : a === i.equal) ? $(e.then, t, n, r) : 0;
		}
		case "scaled": return Math.floor(J(t, e.mode) / (e.count ?? 1)) * Q(e.gain ?? {}, t, n);
		case "special": return n.round < 8 ? 3 : 1.8;
		case "mission": return 5.2;
		case "convert": return i * 1.4;
		case "trialProduction": return 3;
		case "tradeRoute": return 5;
		case "playCard": return Vt(e.card, t, n, r);
		default: return 0;
	}
}
function Ht(e, t, n, r, i) {
	let a = n.round <= 4 ? 3 : n.round <= 7 ? 2 : 1, o = q(t), s = e.cost ? Q(e.cost, t, n) : 0;
	switch (e.kind) {
		case "skip":
		case "ignoreCard": return -.1;
		case "discard": return -Vt(e.card, t, n, i) - +(new Set(r.hand.map((e) => V[e].color)).size >= 3 && r.hand.filter((t) => V[t].color === V[e.card].color).length === 1);
		case "play":
		case "clone": {
			let r = R(n.players.length)[e.slot], a = V[e.card].color === r.color;
			return $(r.effect, t, n, i) + (a ? Vt(e.card, t, n, i) : -.08 * Vt(e.card, t, n, i)) - s * .8;
		}
		case "build": {
			let n = e.build, r = e.target, c;
			if (n === "tunnel") {
				let e = F[r], n = e.find((e) => !o.has(e)), s = +(n !== void 0 && n < 9 && t.cities[n] !== "empty"), l = n !== void 0 && n < 9 ? t.buildings[n].length : 0, u = e.some((e) => e >= 9) ? 2 : 0;
				c = (2 + s * 4 + l * 2 + u) * i.connection + (Fe({
					...t,
					tunnels: t.tunnels.map((e, t) => t === r ? 1 : e)
				}, r) ? a * 1.3 : 0), (r === 12 || r === 13) && (c += t.tunnels[r === 12 ? 13 : 12] ? 3 : -1.5);
			} else if (n === "white" || n === "purple") c = (o.has(r) ? 4.2 : 1.6) * i.connection + (n === "purple" ? a * 2 : 0) + t.buildings[r].length * a * .8, J(t, "cities") > J(t, "farm") + 2 && (c -= 2);
			else {
				c = (o.has(r) && t.cities[r] !== "empty" ? 1 : .42) * a * (n === "farm" ? 2 : n === "desal" ? 2.5 : 2.1) * i.economy;
				let e = t.buildings[r];
				e.some((e) => e.kind === n) || (c += 1.4 * i.synergy), n === "farm" && J(t, "farm") < J(t, "cities") && (c += 2.6), n === "lab" && J(t, "lab") === 0 && (c += 2), e.some((e) => e.kind === n && e.up) && (c += 1);
			}
			return c - s * i.conservation;
		}
		case "upgrade": {
			let n = ((e.build === "tunnel" ? Fe(t, e.target) : o.has(e.target) && t.cities[e.target] !== "empty") ? 1 : .2) * a * (e.build === "desal" ? 2 : e.build === "lab" ? 1.7 : .9) * i.economy;
			return e.build !== "tunnel" && t.buildings[e.target].filter((t) => t.kind === e.build && t.up).length === 1 && (n += a * 1.6 * i.synergy), n - s * .4;
		}
		case "resolve": return $(e.effect, t, n, i) + (e.effect?.kind === "gain" ? 1.5 : 0);
		case "pay": return $(e.effect, t, n, i) - s * i.conservation;
		case "claimCard": return Vt(e.card, t, n, i) - s * .6;
		case "replace": return -Vt(e.card, t, n, i);
		case "use": return $(V[e.card].effect, t, n, i);
		case "refresh": return $(V[e.card].effect, t, n, i);
		case "takeSpecial":
		case "takePeek": return Vt(e.card, t, n, i) - V[e.card].cost * .6;
		case "peekSpecial": return n.round < 7 ? 3 : 1;
		case "returnSpecial": return -Vt(e.card, t, n, i);
		case "mission": return $(R(n.players.length)[e.slot].effect, t, n, i);
		case "convert": return a * 2 + 1 - s * .5;
		case "drawMetro": return 7;
		case "chooseMetro": return [
			6,
			6,
			4,
			2 + 2 * a,
			5,
			4,
			3 + a,
			3 + a,
			2 + 2 * a,
			6,
			2 + 2 * a
		][e.value];
		case "trialProduction": return e.build === "desal" ? 4 : e.build === "lab" ? 3 : 2;
		case "scoreCard": return e.card >= 181 ? 4 : 2;
		case "exchangeEnd": return (e.gain?.point ?? 0) - s / 5;
		case "produceBio": return 2.7;
		case "produceTunnel": return 1.4;
		case "produceLab": return t.resources.science < 2 ? -.3 : 1.2;
		case "intel": return r.hand.length < 4 ? .7 : -.2;
		case "permanent": {
			let r = e.card === 79 ? Q({ steel: 1 }, t, n) - Q({ credit: 1 }, t, n) * i.conservation : e.card === 101 ? Q({
				kelp: 1,
				steel: 1
			}, t, n) - Q({ bio: 1 }, t, n) * i.conservation : Math.max(t.resources.steel > 0 ? Q({ kelp: 1 }, t, n) - Q({
				steel: 1,
				credit: 1
			}, t, n) * i.conservation : -Infinity, t.resources.kelp > 0 ? Q({ steel: 1 }, t, n) - Q({
				kelp: 1,
				credit: 1
			}, t, n) * i.conservation : -Infinity);
			return r > 0 ? r : -Infinity;
		}
		default: return .1;
	}
}
function Ut(e = zt) {
	return (t, n) => {
		let r = t.public, i = t.private, a = i?.options ?? [];
		if (!i || r.prompt?.rid !== n.rid || !a.length) return null;
		if (n.difficulty === "weak") {
			let e = a.filter((e) => ![
				"skip",
				"ignoreCard",
				"permanent",
				"peekSpecial"
			].includes(e.kind)), t = e.length ? e : a, n = 2 ** 32 - 2 ** 32 % t.length, r;
			do
				r = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
			while (r >= n);
			return { action: {
				type: "choose",
				id: t[r % t.length].id
			} };
		}
		let o = r.players.find((e) => e.rid === n.rid), s = a[0], c = -Infinity;
		for (let t of a) {
			let n = Ht(t, o, r, i, e);
			n > c && (c = n, s = t);
		}
		return { action: {
			type: "choose",
			id: s.id
		} };
	};
}
var Wt = Ut(), Gt = (e, t, n) => {
	if (e.type !== "choose") return "";
	let r = t.private?.options.find((t) => t.id === e.id), i = n("games.underwatercities.name") === "水下城市" ? "zh" : "en";
	return r ? Ot(r, i) : "";
}, Kt = { change(e, t) {
	let n = e.data;
	if (!n) return null;
	let r = e.rid ? t.anchor(`uc-board:${e.rid}`) : null;
	if (!r) return null;
	if (n.kind === "production" || n.kind === "score") return {
		ms: 420,
		node: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(b, {
			at: r,
			ms: 420
		}), /* @__PURE__ */ g(y, {
			at: {
				...r,
				h: Math.min(r.h, 80)
			},
			ms: 420,
			children: /* @__PURE__ */ g("span", {
				className: "uc-fx-gain",
				children: x.filter((e) => (n.gain?.[e] ?? 0) > 0).map((e) => /* @__PURE__ */ _("span", { children: [
					"+",
					n.gain[e],
					/* @__PURE__ */ g(kt, { kind: e })
				] }, e))
			})
		})] })
	};
	if ([
		"build",
		"upgrade",
		"convert"
	].includes(n.kind ?? "")) {
		let r = n.build === "tunnel" ? "tunnel" : n.site !== void 0 && n.site >= 0 ? "building" : "city", i = t.anchor(`uc-site:${e.rid}:${r}:${n.target}${r === "building" ? `:${n.site}` : ""}`);
		return i ? {
			ms: 420,
			node: /* @__PURE__ */ g(b, {
				at: i,
				ms: 420
			})
		} : null;
	}
	return null;
} };
//#endregion
//#region src/games/underwatercities/game-over.tsx
function qt(e) {
	let t = c((e) => e.locale), n = l(), r = Tt(t), i = e.public, [a, o] = s(e.result.ranking[0]), [ee, d] = s(!0), [f, p] = At(), [m, te] = s(null), [ne, h] = s(!1), v = i.players.find((e) => e.rid === a) ?? i.players[0], y = (t) => e.members.find((e) => e.rid === t)?.name ?? t, b = e.result.winner[0];
	return /* @__PURE__ */ _("div", {
		className: "uc-result",
		children: [
			/* @__PURE__ */ _("div", {
				className: "uc-final-scene",
				inert: ee,
				children: [
					/* @__PURE__ */ _("div", {
						className: "uc-final-toolbar",
						children: [/* @__PURE__ */ g("div", {
							className: "uc-final-players",
							children: e.result.ranking.map((e) => /* @__PURE__ */ _("button", {
								"aria-pressed": e === v.rid,
								onClick: () => o(e),
								children: [
									y(e),
									" · ",
									i.players.find((t) => t.rid === e).resources.point
								]
							}, e))
						}), /* @__PURE__ */ g("button", {
							onClick: () => p(!f),
							children: f ? r.fit : r.zoom
						})]
					}),
					/* @__PURE__ */ g("div", {
						className: `uc-board-viewport ${f ? "uc-zoom" : ""}`,
						children: /* @__PURE__ */ g(Lt, {
							p: v,
							lang: t
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "uc-final-cards",
						children: v.claimed.map((e) => /* @__PURE__ */ g("button", {
							onClick: () => {
								te(e), h(!0);
							},
							children: Z(e, t)
						}, e))
					})
				]
			}),
			/* @__PURE__ */ g("div", {
				className: "uc-result-layer",
				hidden: !ee,
				children: /* @__PURE__ */ _("section", {
					className: "uc-report",
					children: [
						/* @__PURE__ */ _("header", {
							className: "uc-report-heading",
							children: [/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("p", { children: r.projectReport }), /* @__PURE__ */ g("h1", { children: i.players.length === 1 ? i.soloWon ? r.soloWin : r.soloLoss : `${r.winner} · ${y(b)}` })] }), /* @__PURE__ */ g("button", {
								onClick: () => d(!1),
								"aria-label": r.hideResult,
								children: /* @__PURE__ */ g(re, { size: 24 })
							})]
						}),
						/* @__PURE__ */ _("div", {
							className: "uc-report-scroll",
							children: [
								/* @__PURE__ */ g("div", {
									className: "uc-score-table-wrap",
									children: /* @__PURE__ */ _("table", {
										className: "uc-score-table",
										children: [/* @__PURE__ */ g("thead", { children: /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", { children: r.scoreItem }), e.result.ranking.map((t, n) => /* @__PURE__ */ _("th", {
											"data-winner": e.result.winner.includes(t),
											children: [/* @__PURE__ */ g("span", { children: n + 1 }), /* @__PURE__ */ g("b", { children: y(t) })]
										}, t))] }) }), /* @__PURE__ */ _("tbody", { children: [[
											"play",
											"metropolis",
											"cards",
											"cities",
											"resources"
										].map((t) => /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", {
											scope: "row",
											children: r[t]
										}), e.result.ranking.map((e) => /* @__PURE__ */ g("td", { children: i.players.find((t) => t.rid === e).breakdown[t] ?? 0 }, e))] }, t)), /* @__PURE__ */ _("tr", {
											className: "uc-score-total",
											children: [/* @__PURE__ */ g("th", {
												scope: "row",
												children: r.total
											}), e.result.ranking.map((e) => /* @__PURE__ */ g("td", { children: i.players.find((t) => t.rid === e).resources.point }, e))]
										})] })]
									})
								}),
								e.result.ranking.some((t) => (e.result.autopilot?.[t] ?? 0) > 0) && /* @__PURE__ */ g("div", {
									className: "uc-result-stats",
									children: e.result.ranking.map((t) => (e.result.autopilot?.[t] ?? 0) > 0 ? /* @__PURE__ */ _("p", { children: [
										y(t),
										" · ",
										n("session.autopilot.share", { n: Math.round(e.result.autopilot[t] * 100) })
									] }, t) : null)
								}),
								e.hintCount !== void 0 && /* @__PURE__ */ g("p", {
									className: "uc-result-stats",
									children: n("session.hint.usedCount", { n: e.hintCount })
								})
							]
						}),
						/* @__PURE__ */ _("footer", {
							className: "uc-report-actions",
							children: [
								/* @__PURE__ */ g("button", {
									className: "btn-quiet",
									onClick: () => d(!1),
									children: r.hideResult
								}),
								e.onPlayAgain && /* @__PURE__ */ g(ie, {
									label: r.again,
									confirmLabel: r.confirmAgain,
									onConfirm: e.onPlayAgain
								}),
								e.onBackToLobby && /* @__PURE__ */ g(ie, {
									label: r.lobby,
									confirmLabel: r.confirmLobby,
									onConfirm: e.onBackToLobby
								}),
								!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ g("p", { children: r.hostWait })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ g("button", {
				className: "uc-restore-result",
				hidden: ee,
				onClick: () => d(!0),
				children: r.showResult
			}),
			/* @__PURE__ */ g("div", {
				className: "uc-detail-layer",
				children: /* @__PURE__ */ g(u, {
					open: ne,
					onClose: () => h(!1),
					label: r.details,
					title: m === null ? r.details : Z(m, t),
					children: m !== null && /* @__PURE__ */ g("div", {
						className: "uc-card-detail",
						children: /* @__PURE__ */ g(Ft, {
							id: m,
							lang: t
						})
					})
				})
			})
		]
	});
}
//#endregion
//#region src/games/underwatercities/options.tsx
function Jt({ value: e, onChange: t }) {
	let n = Tt(c((e) => e.locale)), r = Ce.safeParse(e), i = r.success ? r.data : Ce.parse(void 0);
	return /* @__PURE__ */ _(ae, {
		title: n.board,
		children: [/* @__PURE__ */ g(oe, {
			checked: i.advanced,
			label: n.advanced,
			hint: n.advancedHelp,
			onChange: () => t({
				...i,
				advanced: !i.advanced
			})
		}), /* @__PURE__ */ g(oe, {
			checked: i.contracts,
			label: n.contracts,
			hint: n.contractsHelp,
			onChange: () => t({
				...i,
				contracts: !i.contracts
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/underwatercities/entry.tsx
var Yt = {
	definition: gt,
	View: Rt,
	bot: Wt,
	describe: Gt,
	fx: Kt,
	OverView: qt,
	Options: Jt,
	locales: {
		zh: {
			name: "水下城市",
			desc: "让人员与工位颜色匹配，建造并连接海底城市，发展能够持续生产的设施网络。包含2018年基础版、政府合同、高级版图和单人模式。",
			errFinished: "本局已经结束。",
			errAction: "该选择当前不可执行，请重新选择。",
			errTurn: "请等待当前玩家完成选择。",
			rules: "目标：\n发展海底城市网络，在10轮结束时获得最高分。每轮每人行动3次，所有玩家按本轮顺序依次行动。第4、7、10轮之后进行生产。最终同分时，最后一轮结束时的联邦顺序靠前者获胜。\n准备：\n每人获得一张随机玩家版图、一座位于右下角的白色城市、一张私人助理、1份海带、1份钢塑、1点科研和2点信用。首轮第三位额外获得1点信用，第四位额外获得1点信用和1份钢塑。首位从联邦轨道下方开始，其后各位分别从第4、3、2格开始。每人抽6张年代Ⅰ卡，弃到3张。每人随机获得1座棕色都会和2座蓝色都会。高级版图在设置中启用；政府合同启用时随机展示3张。\n回合：\n回合开始时将手牌弃到上限，通常为3张；海底服务器中心将上限提高到4张。选择一张手牌和一个空工位。颜色匹配时，可以先完整结算工位，再结算卡牌，或反过来；两组效果不能交错。组内各部分可以选择顺序，新触发的效果立即结算。颜色不匹配时，仅执行工位并弃掉卡牌。卡牌效果可以放弃。回合结束抽1张牌；超过手牌上限时，正式弃牌发生在下次回合开始。\n无色工位始终可用，获得2张牌和2点信用，所出卡牌无效。四人局每轮全桌可以使用一次克隆：支付1点信用，使用另一名玩家占据的工位；不能克隆自己占据的工位。卡牌提供的额外工位行动不放置人员，不再打牌。注明可用工位的效果也可以选无色工位；注明他人占据的工位则不能。\n卡牌：\n即时牌执行后弃置；行动牌、常驻牌、生产牌和终局牌留在面前。行动牌每个年代可用一次，必须由工位或卡牌提供使用机会。最多保留4张行动牌，包含助理；获得第五张时先弃掉一张，如果弃掉的旧牌尚未使用，可以立即使用一次。特殊牌取得时加入手牌，同色打出且支付票面信用后才生效；1至2点信用特殊牌未支付或弃置时放回特殊牌堆底，已支付的即时牌保留作计数。3点信用特殊牌开局仅展示6张，不补充。\n取得特殊牌时，可选择一张公开的3点信用牌、拿取低费牌堆顶牌，或将顶牌移到底部，再从后续3张中保留1张，其余按自选顺序放回底部。常驻牌的折扣、触发奖励和每回合能力按各牌文字执行。\n建造与连通：\n建造费用如下：\n· 白色城市：支付2份钢塑、1份海带和1点信用。\n· 共生城市：支付1份钢塑、1份海带、1份生物质和2点信用。\n城市只能建在与既有城市相邻的位置，两城之间的隧道可以尚未建造。其他结构的建造费用如下：\n· 农场：支付1份海带。\n· 脱盐厂：支付1点信用。\n· 实验室：支付1份钢塑。\n· 隧道：支付1份钢塑和1点信用。\n建造时生物质可逐个代替海带或钢塑；不能替代信用、科研或必付生物质。牌面指定费用替代通常费用，折扣可以叠加，最低为免费。高级版图的场地附加费在所有减费之后支付，免费建造也必须支付附加费；位置奖励另行立即获得。\n建筑可以建在已有城市周围，也可建在当前能够合法建造城市的空城位周围。扩建位只能由注明扩建的效果使用。隧道必须接入右下角起始城市的网络，可经过尚未建城的位置。城市、建筑、隧道位置的建造奖励立即获得，不要求连网。连接上方左岸的棕色都会需要两条平行隧道；另外两座都会各需要一条。17座白城、46条隧道及按人数使用的7、10、13座共生城为全桌有限供应；普通建筑不限。\n升级与生产：\n每次通常支付1点科研升级一个建筑或隧道，各结构最多升级一次。生产只计算已连入起始城市网络的城市、其建筑，以及邻接连网城市的隧道。各类结构的生产效果如下：\n· 城市：共生城生产2分，白城不生产。\n· 农场生产1份海带，升级额外生产1分；同城至少2座升级农场额外生产1份海带和1分。\n· 脱盐厂生产1点信用，升级额外生产1份生物质；同城至少2座升级脱盐厂额外生产1点信用。\n· 实验室生产1点科研，升级额外生产1份钢塑；同城至少2座升级实验室额外生产1份钢塑。\n· 隧道生产1点信用，升级额外生产1分。\n位置倍率只乘该结构的通常生产与升级生产，不乘同类配对或其他额外生产。\n生产后，每座连网城市消耗1份海带；不足部分先支付生物质，再每缺1个扣3分，分数最低为0。生产牌与都会按其文字额外结算。进入下个年代时，所有行动牌恢复可用，每人抽新年代3张牌并弃到手牌上限。最后一次生产后直接终局。\n联邦与合同：\n联邦轨道从下方依次进入第4、3、2、1格，进入第3格获得1点信用，进入第2格获得1份钢塑，进入第1格获得1分。到顶后每次额外推进仍获得1分。同格后到者位于上方，排在前面；轨道下方未推进者保持本轮相对顺序。每轮结束先按轨道确定新顺序，再将所有标记归到下方，最后一轮也须排序。政府合同条件一旦满足，立即领取并获得奖励，每张仅由首位达成者领取，不补充。\n终局：\n先结算已连接的棕色都会，再由玩家选择终局牌顺序与资源兑换数量，多张终局牌共用剩余资源。然后每座连网城市按其中建筑类型数0、1、2、3分别获得2、3、4、6分。剩余生物质按每个2点信用，海带、钢塑、科研按每个1点信用折算，与剩余信用合计每4点信用获得1分。\n单人：\n使用高级版图与双人主板，不使用政府合同，也不使用按城市数量计分的棕色都会。共生城不限数量。每种颜色最右侧工位开局被阻挡，每轮顺时针移动一格；若本轮未推进联邦，下轮翻开当前年代一张牌，将编号各数字相加，从首个绿色工位顺时针数到该数，若已占用则继续到首个空位，额外阻挡该工位。结束时至少连接7座城市且获得100分即获胜。"
		},
		en: {
			name: "Underwater Cities",
			desc: "Match personnel cards to action slots, connect underwater cities, and develop a productive network. Includes the 2018 base game, government contracts, advanced boards, and solo play.",
			errFinished: "This game has ended.",
			errAction: "That choice is no longer available. Please choose again.",
			errTurn: "Wait for the current player to finish choosing.",
			rules: "Goal:\nScore the most points over 10 rounds. Each player takes 3 turns per round, following the current player order. Production occurs after rounds 4, 7, and 10. Final ties are broken by the Federation order established after the last round.\nSetup:\nEach player receives a random player board, a white city at its lower-right site, a Personal Assistant, 1 kelp, 1 steelplast, 1 science, and 2 credits. The third player also receives 1 credit; the fourth receives 1 credit and 1 steelplast. The first player starts below the Federation track, and subsequent players start on spaces 4, 3, and 2. Draw 6 Era I cards and discard to 3. Randomly assign one brown and two blue metropolises to each board. Advanced boards are optional. When government contracts are enabled, reveal 3 random contracts.\nTurns:\nAt the beginning of your turn, discard to your hand limit, normally 3; Undersea Server Farm raises it to 4. Play one card and choose an available action slot. If their colors match, resolve the entire card and the entire slot in either order. Do not interleave the two groups. Parts within a group can be ordered freely; triggered effects interrupt immediately. If colors differ, discard the card without its effect and resolve the slot. Card effects may be declined. Draw 1 card at the end of your turn; excess cards are officially discarded at the start of your next turn.\nThe colorless slot is always available: gain 2 cards and 2 credits, ignoring the played card. In a four-player game, the action-cloning tile may be used once per round by the whole table: pay 1 credit to use a slot occupied by another player, excluding your own slots. Extra slot actions granted by cards place no action tile and require no second card. An available-slot effect may select the colorless slot; an occupied-slot effect may not.\nCards:\nInstant effects are discarded after resolution. Action, permanent, production, and end-scoring cards remain in play. Action cards can be used once per era, and only when an effect grants an activation. You may keep at most 4 action cards, including your Assistant. When replacing one, you may immediately use the discarded old card if it was still available. Special cards enter your hand and take effect only when played on a matching slot and their printed credit cost is paid. Unpaid or discarded 1–2-credit Special cards return to the bottom of their deck; paid instant Special cards are kept for counting. Only 6 three-credit cards are revealed at setup and they are never replaced.\nWhen drawing a Special card, take a face-up three-credit card, take the low-cost deck's top card, or move that top card to the bottom and draw the next 3. Keep one and return the other two to the bottom in either order. Permanent discounts, triggers, and once-per-turn abilities follow their individual card text.\nBuilding and connections:\nConstruction costs:\n· White city: Pay 2 steelplast, 1 kelp and 1 credit.\n· Symbiotic city: Pay 1 steelplast, 1 kelp, 1 biomatter and 2 credits.\nA new city must be adjacent to an existing city, even if their connecting tunnel has not been built. Other structures cost:\n· Farm: Pay 1 kelp.\n· Desalination plant: Pay 1 credit.\n· Laboratory: Pay 1 steelplast.\n· Tunnel: Pay 1 steelplast and 1 credit.\nBiomatter can replace kelp or steelplast one for one when building, but not credits, science or required biomatter. A specified cost replaces the usual cost; discounts combine and cannot reduce a cost below zero. Advanced-site surcharges are paid after all discounts, including free construction. Gain site rewards immediately.\nBuildings may surround an existing city or an empty city site where building a city would currently be legal. Expansion sites require an effect expressly allowing expansion. Tunnels must extend the network from the lower-right starting city and may pass through empty city sites. Site rewards trigger immediately even outside the network. The brown metropolis requires both parallel tunnels; each blue metropolis requires one. The shared supply contains only 17 white cities, 46 tunnels, and 7/10/13 symbiotic cities for 2/3/4 players. Buildings are unlimited.\nUpgrades and production:\nAn upgrade normally costs 1 science. Each building or tunnel can be upgraded once. Only connected cities, buildings at connected cities and tunnels adjacent to connected cities produce.\nProduction by structure:\n· Cities: A symbiotic city produces 2 points. White cities produce nothing.\n· Farms: Each produces 1 kelp and, when upgraded, 1 point. A city with at least 2 upgraded farms produces an additional 1 kelp and 1 point.\n· Desalination plants: Each produces 1 credit and, when upgraded, 1 biomatter. A city with at least 2 upgraded plants produces an additional 1 credit.\n· Laboratories: Each produces 1 science and, when upgraded, 1 steelplast. A city with at least 2 upgraded laboratories produces an additional 1 steelplast.\n· Tunnels: Each produces 1 credit and, when upgraded, 1 point.\nSite multipliers affect that structure’s ordinary and upgraded output. They do not multiply pair bonuses or other additional production.\nAfter production, feed each connected city with 1 kelp. Cover shortages with biomatter, then lose 3 points per unfed city, to a minimum of zero. Production cards and connected metropolises also apply. On entering a new era, refresh all action cards, draw 3 cards from the new era, and discard to the hand limit. The last production is followed directly by final scoring.\nFederation and contracts:\nAdvance from below the track through spaces 4, 3, 2, and 1. Entering space 3 grants 1 credit, space 2 grants 1 steelplast, and space 1 grants 1 point. Each additional advance at the top still grants 1 point. A later arrival stacks above earlier markers and precedes them. Markers below the track keep their relative order. At the end of every round, including the last, determine the new order and return all markers below the track. The first player meeting a government contract's requirements claims it immediately and receives its reward. Claimed contracts are never replaced.\nFinal scoring:\nScore the connected brown metropolis, then resolve end-scoring cards in the player's chosen order and choose how many resources to exchange. Cards share the remaining resources. Each connected city scores 2/3/4/6 points for 0/1/2/3 different building types. Convert remaining biomatter to 2 credits each and kelp, steelplast, and science to 1 credit each; score 1 point per 4 total credits.\nSolo:\nUse an advanced board and the two-player main board. Do not use contracts or the brown metropolis scoring connected-city counts. Symbiotic domes are unlimited. Block the rightmost slot of each color at setup, moving those three blockers clockwise by one slot each round. If you did not advance on the Federation track, reveal an era card, sum its printed digits, and count clockwise from the first green slot; if occupied, continue to the next empty slot and block it for the next round. Win by finishing with at least 7 connected cities and 100 points."
		}
	}
};
//#endregion
export { Yt as default };
