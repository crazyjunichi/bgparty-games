import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useT as a } from "@bgparty/sdk/i18n";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { PLAYER_COLORS as s } from "@bgparty/sdk/player-colors";
import { PhaseBanner as c } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { GameOverScreen as p } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/bullet/data.ts
var m = [
	"R",
	"B",
	"G",
	"Y",
	"P"
];
function h() {
	let e = [];
	for (let t of m) for (let n of [
		1,
		2,
		3,
		4
	]) {
		let r = n === 4 ? 2 : 6;
		for (let i = 0; i < r; i += 1) e.push(`${t}${n}`);
		e.push(`${t}${n}s`, `${t}${n}s`);
	}
	return e;
}
function g(e) {
	return {
		id: e,
		color: e[0],
		num: Number(e[1]),
		star: e.endsWith("s")
	};
}
var _ = {
	"<": [0, -1],
	">": [0, 1],
	v: [-1, 0],
	"<v": [-1, -1],
	"v>": [-1, 1]
}, ee = {
	gainAp: "games.bullet.act.gainAp",
	flip: "games.bullet.act.flip",
	moveCross1: "games.bullet.act.moveCross1"
}, v = [
	[0, -1],
	[0, 1],
	[1, 0]
], y = [
	[-1, -1],
	[1, 1],
	[1, -1],
	[-1, 1]
], b = [
	...v,
	[-1, 0],
	...y
], te = [
	{
		key: "games.bullet.pat.adelheid.0",
		grid: [[
			"R",
			"X",
			"P"
		], [
			"X",
			"X",
			"X"
		]]
	},
	{
		key: "games.bullet.pat.adelheid.1",
		grid: [[
			"G",
			"G",
			"O"
		], [
			"X",
			"X",
			"X"
		]]
	},
	{
		key: "games.bullet.pat.adelheid.2",
		grid: [
			["X", " "],
			["X", "P"],
			["X", "P"]
		]
	},
	{
		key: "games.bullet.pat.adelheid.3",
		grid: [
			[
				"X",
				" ",
				" ",
				" "
			],
			[
				" ",
				"X",
				" ",
				" "
			],
			[
				" ",
				" ",
				"(X)",
				"/"
			],
			[
				" ",
				" ",
				" ",
				"Y"
			]
		]
	},
	{
		key: "games.bullet.pat.adelheid.4",
		grid: [
			[
				" ",
				"G",
				" "
			],
			[
				"X",
				"(X)",
				"X"
			],
			[
				" ",
				"O",
				" "
			]
		]
	},
	{
		key: "games.bullet.pat.adelheid.5",
		grid: [
			[" ", "O"],
			[" ", "P"],
			["X", "P"],
			["X", "X"]
		]
	},
	{
		key: "games.bullet.pat.adelheid.6",
		grid: [
			[" ", "X"],
			["Y", "(X)"],
			[" ", "X"]
		]
	},
	{
		key: "games.bullet.pat.adelheid.7",
		grid: [[
			"R",
			"B",
			"X"
		], [
			"R",
			"X",
			"X"
		]]
	},
	{
		key: "games.bullet.pat.adelheid.8",
		grid: [[
			"X",
			"X",
			"X"
		], [
			"R",
			"R",
			"X"
		]]
	},
	{
		key: "games.bullet.pat.adelheid.9",
		grid: [
			[
				"O",
				" ",
				"X"
			],
			[
				" ",
				"3",
				"X"
			],
			[
				"O",
				" ",
				"X"
			]
		]
	}
], ne = [
	{
		key: "games.bullet.pat.ekolu.0",
		grid: [
			["X", " "],
			["X", " "],
			["X", " "],
			["O", " "],
			["O", "O"]
		]
	},
	{
		key: "games.bullet.pat.ekolu.1",
		grid: [
			[
				" ",
				" ",
				"O",
				" "
			],
			[
				"X",
				"X",
				"X",
				" "
			],
			[
				"O",
				" ",
				" ",
				"O"
			]
		]
	},
	{
		key: "games.bullet.pat.ekolu.2",
		grid: [[
			"1",
			"X",
			"X"
		], [
			"2",
			"3",
			"X"
		]]
	},
	{
		key: "games.bullet.pat.ekolu.3",
		grid: [
			[
				" ",
				"O",
				" ",
				" "
			],
			[
				"X",
				"X",
				"X",
				" "
			],
			[
				"O",
				" ",
				" ",
				"O"
			]
		]
	},
	{
		key: "games.bullet.pat.ekolu.4",
		grid: [
			[
				"O",
				" ",
				" "
			],
			[
				"_",
				" ",
				" "
			],
			[
				"O",
				" ",
				"O"
			],
			[
				"X",
				"X",
				"X"
			]
		]
	},
	{
		key: "games.bullet.pat.ekolu.5",
		grid: [
			[
				" ",
				" ",
				"O",
				" ",
				" "
			],
			[
				" ",
				" ",
				"_",
				" ",
				" "
			],
			[
				" ",
				" ",
				"_",
				" ",
				" "
			],
			[
				" ",
				" ",
				"_",
				" ",
				" "
			],
			[
				" ",
				" ",
				"_",
				" ",
				" "
			],
			[
				"O",
				"X",
				"X",
				"X",
				"O"
			]
		]
	},
	{
		key: "games.bullet.pat.ekolu.6",
		grid: [[
			"1",
			"X",
			"1"
		], [
			"X",
			"2",
			"X"
		]]
	},
	{
		key: "games.bullet.pat.ekolu.7",
		grid: [[
			" ",
			"O",
			"X",
			" "
		], [
			"O",
			"O",
			"X",
			"X"
		]]
	},
	{
		key: "games.bullet.pat.ekolu.8",
		grid: [
			[
				" ",
				"O",
				" "
			],
			[
				"O",
				" ",
				"O"
			],
			[
				"X",
				"X",
				"X"
			]
		]
	}
], x = [
	{
		key: "games.bullet.pat.esfir.0",
		grid: [[
			"O",
			"X",
			"X",
			"X",
			"O"
		]]
	},
	{
		key: "games.bullet.pat.esfir.1",
		grid: [
			[
				"O",
				" ",
				"O"
			],
			[
				"O",
				" ",
				"O"
			],
			[
				"X",
				"X",
				"X"
			]
		]
	},
	{
		key: "games.bullet.pat.esfir.2",
		grid: [
			[
				"X",
				"X",
				"X"
			],
			[
				"/",
				"3",
				"/"
			],
			[
				" ",
				"/",
				" "
			]
		]
	},
	{
		key: "games.bullet.pat.esfir.3",
		grid: [[
			"X",
			"O",
			"X"
		], [
			"O",
			"X",
			"O"
		]]
	},
	{
		key: "games.bullet.pat.esfir.4",
		grid: [
			["X", "O"],
			["X", "O"],
			["X", "O"]
		]
	},
	{
		key: "games.bullet.pat.esfir.5",
		grid: [
			[
				"O",
				" ",
				" ",
				" "
			],
			[
				"O",
				"X",
				"X",
				"X"
			],
			[
				"O",
				" ",
				" ",
				" "
			]
		]
	},
	{
		key: "games.bullet.pat.esfir.6",
		grid: [
			["Y"],
			["O"],
			["X"],
			["X"],
			["X"]
		]
	},
	{
		key: "games.bullet.pat.esfir.7",
		grid: [[
			"/",
			"/",
			"X",
			"X",
			"X"
		]]
	},
	{
		key: "games.bullet.pat.esfir.8",
		grid: [
			[" ", "X"],
			["O", "X"],
			["R", "X"]
		]
	},
	{
		key: "games.bullet.pat.esfir.9",
		grid: [[
			"=",
			"_",
			"="
		], [
			"X",
			"X",
			"X"
		]]
	}
], re = [
	{
		key: "games.bullet.pat.lingling.0",
		grid: [
			[
				"+",
				" ",
				"+"
			],
			[
				"+",
				" ",
				"+"
			],
			[
				"=",
				" ",
				"="
			]
		]
	},
	{
		key: "games.bullet.pat.lingling.1",
		grid: [
			[
				"(+)",
				" ",
				" ",
				" "
			],
			[
				" ",
				"(+)",
				" ",
				" "
			],
			[
				" ",
				" ",
				"(+)",
				" "
			],
			[
				" ",
				" ",
				" ",
				"(+)"
			]
		]
	},
	{
		key: "games.bullet.pat.lingling.2",
		grid: [["(+)", "(+)"], ["(+)", "(+)"]]
	},
	{
		key: "games.bullet.pat.lingling.3",
		grid: [
			[
				"(+)",
				"(+)",
				"(+)"
			],
			[
				" ",
				"(+)",
				" "
			],
			[
				" ",
				"/",
				" "
			]
		]
	},
	{
		key: "games.bullet.pat.lingling.4",
		grid: [
			["(+)"],
			["(+)"],
			["(+)"],
			["(+)"],
			["(+)"]
		]
	},
	{
		key: "games.bullet.pat.lingling.5",
		grid: [[
			"(+)",
			"(+)",
			"(+)",
			"(+)",
			"(+)"
		]]
	},
	{
		key: "games.bullet.pat.lingling.6",
		grid: [
			[
				"+",
				" ",
				"+"
			],
			[
				" ",
				"/",
				" "
			],
			[
				"+",
				" ",
				"+"
			]
		]
	},
	{
		key: "games.bullet.pat.lingling.7",
		grid: [
			[
				" ",
				" ",
				" ",
				"(+)"
			],
			[
				" ",
				" ",
				"(+)",
				" "
			],
			[
				" ",
				"(+)",
				" ",
				" "
			],
			[
				"(+)",
				" ",
				" ",
				" "
			]
		]
	},
	{
		key: "games.bullet.pat.lingling.8",
		grid: [
			["+"],
			["+"],
			["+"],
			["O"]
		]
	},
	{
		key: "games.bullet.pat.lingling.9",
		grid: [[
			"(+)",
			"_",
			"_",
			"_",
			"(+)"
		], [
			" ",
			" ",
			"(+)",
			" ",
			" "
		]]
	}
], ie = [
	{
		key: "games.bullet.pat.mariel.0",
		grid: [
			[
				"R",
				"X",
				" "
			],
			[
				"O",
				"X",
				"X"
			],
			[
				"O",
				" ",
				" "
			]
		]
	},
	{
		key: "games.bullet.pat.mariel.1",
		grid: [
			[
				"O",
				" ",
				"O"
			],
			[
				" ",
				"O",
				" "
			],
			[
				"X",
				"X",
				"X"
			]
		]
	},
	{
		key: "games.bullet.pat.mariel.2",
		grid: [
			[
				" ",
				"X",
				" "
			],
			[
				"O",
				"X",
				"O"
			],
			[
				"O",
				"X",
				"O"
			]
		]
	},
	{
		key: "games.bullet.pat.mariel.3",
		grid: [[
			"X",
			"X",
			"X"
		], [
			"O",
			"3",
			"O"
		]]
	},
	{
		key: "games.bullet.pat.mariel.4",
		grid: [
			[
				" ",
				"X",
				" "
			],
			[
				"X",
				"O",
				"X"
			],
			[
				" ",
				"O",
				" "
			],
			[
				" ",
				"O",
				" "
			]
		]
	},
	{
		key: "games.bullet.pat.mariel.5",
		grid: [[
			"O",
			"O",
			"X",
			"X",
			"X"
		], [
			"O",
			" ",
			" ",
			" ",
			" "
		]]
	},
	{
		key: "games.bullet.pat.mariel.6",
		grid: [
			["B"],
			["O"],
			["O"],
			["X"],
			["X"],
			["X"]
		]
	},
	{
		key: "games.bullet.pat.mariel.7",
		grid: [
			[
				"O",
				" ",
				"O"
			],
			[
				"X",
				"O",
				"X"
			],
			[
				" ",
				"X",
				" "
			]
		]
	},
	{
		key: "games.bullet.pat.mariel.8",
		grid: [
			[" ", "X"],
			["X", "X"],
			["O", "O"],
			["/", "/"]
		]
	},
	{
		key: "games.bullet.pat.mariel.9",
		grid: [
			[
				"X",
				"X",
				"X"
			],
			[
				" ",
				"O",
				" "
			],
			[
				"O",
				" ",
				"O"
			]
		]
	}
], ae = [
	{
		key: "games.bullet.pat.rie.0",
		color: "R",
		grid: [
			["O"],
			["O"],
			["O"],
			["X"],
			["X"],
			["X"]
		]
	},
	{
		key: "games.bullet.pat.rie.1",
		color: "Y",
		grid: [[
			"X",
			"O",
			"X",
			"O",
			"X"
		]]
	},
	{
		key: "games.bullet.pat.rie.2",
		color: "P",
		grid: [[
			"O",
			"O",
			"(X)",
			"(X)",
			"(X)"
		]]
	},
	{
		key: "games.bullet.pat.rie.3",
		color: "B",
		grid: [[
			"R",
			"B",
			"X",
			"X",
			"X"
		]]
	},
	{
		key: "games.bullet.pat.rie.4",
		color: "G",
		grid: [[
			"/",
			"X",
			"X",
			"X",
			"/"
		]]
	},
	{
		key: "games.bullet.pat.rie.5",
		color: "B",
		grid: [
			["X"],
			["X"],
			["X"],
			["O"],
			["O"],
			["O"]
		]
	},
	{
		key: "games.bullet.pat.rie.6",
		color: "G",
		grid: [
			["1"],
			["2"],
			["X"],
			["X"],
			["X"]
		]
	},
	{
		key: "games.bullet.pat.rie.7",
		color: "P",
		grid: [
			["X"],
			["X"],
			["X"],
			["O"],
			["3"]
		]
	},
	{
		key: "games.bullet.pat.rie.8",
		color: "Y",
		grid: [
			["O"],
			["X"],
			["X"],
			["X"],
			["O"]
		]
	},
	{
		key: "games.bullet.pat.rie.9",
		color: "R",
		grid: [[
			"X",
			"X",
			"X",
			"/",
			"/"
		]]
	}
], oe = [
	{
		key: "games.bullet.pat.senka.0",
		grid: [
			[
				"X",
				" ",
				" "
			],
			[
				" ",
				"(C)",
				" "
			],
			[
				" ",
				" ",
				"X"
			]
		]
	},
	{
		key: "games.bullet.pat.senka.1",
		grid: [[
			"X",
			" ",
			"X"
		], [
			"O",
			"C",
			"O"
		]]
	},
	{
		key: "games.bullet.pat.senka.2",
		grid: [[
			"C",
			"_",
			"_",
			"X",
			"X"
		]]
	},
	{
		key: "games.bullet.pat.senka.3",
		grid: [[
			"O",
			"C",
			"O"
		], [
			"X",
			" ",
			"X"
		]]
	},
	{
		key: "games.bullet.pat.senka.4",
		grid: [
			[
				" ",
				" ",
				"X"
			],
			[
				" ",
				"(C)",
				" "
			],
			[
				"X",
				" ",
				" "
			]
		]
	},
	{
		key: "games.bullet.pat.senka.5",
		grid: [[
			"X",
			"X",
			"_",
			"_",
			"C"
		]]
	},
	{
		key: "games.bullet.pat.senka.6",
		grid: [
			[
				" ",
				"(C)",
				" "
			],
			[
				" ",
				" ",
				" "
			],
			[
				"X",
				" ",
				"X"
			]
		]
	},
	{
		key: "games.bullet.pat.senka.7",
		grid: [
			["X"],
			["(C)"],
			["X"]
		]
	},
	{
		key: "games.bullet.pat.senka.8",
		grid: [
			[
				"X",
				" ",
				"X"
			],
			[
				" ",
				" ",
				" "
			],
			[
				" ",
				"(C)",
				" "
			]
		]
	},
	{
		key: "games.bullet.pat.senka.9",
		grid: [[
			"X",
			"(C)",
			"X"
		]]
	}
], S = [
	{
		key: "games.bullet.pat.youngja.0",
		grid: [
			["<", "/"],
			["<", "/"],
			["<", "/"]
		]
	},
	{
		key: "games.bullet.pat.youngja.1",
		grid: [[
			">",
			">",
			">"
		], [
			" ",
			"/",
			" "
		]]
	},
	{
		key: "games.bullet.pat.youngja.2",
		grid: [
			["/", ">"],
			["/", ">"],
			["/", ">"]
		]
	},
	{
		key: "games.bullet.pat.youngja.3",
		grid: [
			["v"],
			["v"],
			["v"],
			["/"]
		]
	},
	{
		key: "games.bullet.pat.youngja.4",
		grid: [[
			" ",
			"v",
			" "
		], [
			"<v",
			"/",
			"v>"
		]]
	},
	{
		key: "games.bullet.pat.youngja.5",
		grid: [[
			" ",
			"/",
			" "
		], [
			"<",
			"<",
			"<"
		]]
	},
	{
		key: "games.bullet.pat.youngja.6",
		grid: [["v", " "], ["/", ">"]]
	},
	{
		key: "games.bullet.pat.youngja.7",
		grid: [[
			" ",
			"/",
			" "
		], [
			"v",
			"v",
			"v"
		]]
	},
	{
		key: "games.bullet.pat.youngja.8",
		grid: [[" ", "v"], ["<", "/"]]
	},
	{
		key: "games.bullet.pat.youngja.9",
		grid: [[
			"v",
			"v",
			"v"
		], [
			" ",
			"/",
			" "
		]]
	}
], C = {
	esfir: {
		id: "esfir",
		difficulty: 1,
		handSize: 4,
		apMax: 7,
		maxLife: 4,
		ua: "none",
		actions: [
			{
				t: "move",
				cost: 1,
				move: {
					dirs: v,
					dist: "one"
				},
				text: "games.bullet.act.moveLrd"
			},
			{
				t: "draw",
				cost: 2,
				text: "games.bullet.act.draw"
			},
			{
				t: "move",
				cost: 2,
				move: {
					dirs: [[-1, 0]],
					dist: "one"
				},
				text: "games.bullet.act.moveUp"
			},
			{
				t: "move",
				cost: 2,
				move: {
					dirs: [[1, 0]],
					dist: "slide"
				},
				text: "games.bullet.act.moveDown"
			}
		],
		star: ["gainAp"],
		patterns: x
	},
	adelheid: {
		id: "adelheid",
		difficulty: 3,
		handSize: 3,
		apMax: 7,
		maxLife: 4,
		ua: "compose",
		actions: [
			{
				t: "move",
				cost: 1,
				move: {
					dirs: v,
					dist: "one"
				},
				text: "games.bullet.act.moveLrd"
			},
			{
				t: "draw",
				cost: 2,
				text: "games.bullet.act.draw"
			},
			{
				t: "move",
				cost: 1,
				move: {
					dirs: y,
					dist: "one"
				},
				text: "games.bullet.act.moveDiag"
			}
		],
		star: ["gainAp", "flip"],
		patterns: te
	},
	ekolu: {
		id: "ekolu",
		difficulty: 3,
		handSize: 3,
		apMax: 6,
		maxLife: 3,
		ua: "sacred3",
		actions: [
			{
				t: "move",
				cost: 1,
				move: {
					dirs: v,
					dist: "one"
				},
				text: "games.bullet.act.moveLrd"
			},
			{
				t: "discardDraw",
				cost: 1,
				text: "games.bullet.act.discardDraw"
			},
			{
				t: "placeCenter",
				cost: 1,
				text: "games.bullet.act.placeCenter"
			}
		],
		star: ["gainAp"],
		patterns: ne
	},
	lingling: {
		id: "lingling",
		difficulty: 3,
		handSize: 3,
		apMax: 7,
		maxLife: 4,
		ua: "calculating",
		actions: [
			{
				t: "move",
				cost: 1,
				move: {
					dirs: v,
					dist: "one"
				},
				text: "games.bullet.act.moveLrd"
			},
			{
				t: "draw",
				cost: 2,
				text: "games.bullet.act.draw"
			},
			{
				t: "move",
				cost: 2,
				move: {
					dirs: b,
					dist: "num"
				},
				text: "games.bullet.act.moveNum"
			},
			{
				t: "boostNext",
				cost: 1,
				text: "games.bullet.act.boostNext"
			}
		],
		star: ["gainAp"],
		patterns: re
	},
	mariel: {
		id: "mariel",
		difficulty: 2,
		handSize: 3,
		apMax: 7,
		maxLife: 4,
		ua: "mariel",
		actions: [
			{
				t: "move",
				cost: 1,
				move: {
					dirs: [...v, [-1, 0]],
					dist: "slide"
				},
				text: "games.bullet.act.slide"
			},
			{
				t: "draw",
				cost: 2,
				text: "games.bullet.act.draw"
			},
			{
				t: "moveMarker",
				cost: 1,
				text: "games.bullet.act.moveMarker"
			},
			{
				t: "clearAdj",
				cost: 1,
				text: "games.bullet.act.clearAdj"
			}
		],
		star: ["gainAp"],
		patterns: ie
	},
	rie: {
		id: "rie",
		difficulty: 3,
		handSize: 3,
		apMax: 7,
		maxLife: 2,
		ua: "niceTry",
		actions: [
			{
				t: "move",
				cost: 1,
				move: {
					dirs: v,
					dist: "one"
				},
				text: "games.bullet.act.moveLrd"
			},
			{
				t: "draw",
				cost: 2,
				text: "games.bullet.act.draw"
			},
			{
				t: "reveal",
				cost: 1,
				text: "games.bullet.act.reveal"
			},
			{
				t: "clearLife",
				cost: 5,
				text: "games.bullet.act.clearLife"
			}
		],
		star: ["gainAp"],
		patterns: ae
	},
	senka: {
		id: "senka",
		difficulty: 4,
		handSize: 3,
		apMax: 7,
		maxLife: 4,
		ua: "crosshair",
		actions: [
			{
				t: "move",
				cost: 1,
				move: {
					dirs: v,
					dist: "one"
				},
				text: "games.bullet.act.moveLrd"
			},
			{
				t: "draw",
				cost: 2,
				text: "games.bullet.act.draw"
			},
			{
				t: "moveCross",
				cost: 1,
				text: "games.bullet.act.moveCross"
			}
		],
		star: ["gainAp", "moveCross1"],
		patterns: oe
	},
	youngja: {
		id: "youngja",
		difficulty: 2,
		handSize: 3,
		apMax: 7,
		maxLife: 4,
		ua: "levitation",
		actions: [
			{
				t: "discardDraw",
				cost: 1,
				text: "games.bullet.act.discardDraw"
			},
			{
				t: "draw",
				cost: 2,
				text: "games.bullet.act.draw"
			},
			{
				t: "push",
				cost: 2,
				text: "games.bullet.act.push"
			},
			{
				t: "anyNext",
				cost: 1,
				text: "games.bullet.act.anyNext"
			}
		],
		star: ["gainAp"],
		patterns: S
	}
}, se = {
	gainAp: "games.bullet.pow.gainAp",
	drawCard: "games.bullet.pow.drawCard",
	drawDiscard: "games.bullet.pow.drawDiscard",
	clearCenter: "games.bullet.pow.clearCenter",
	clearSight: "games.bullet.pow.clearSight",
	moveAny: "games.bullet.pow.moveAny",
	swap: "games.bullet.pow.swap",
	putTwo: "games.bullet.pow.putTwo",
	copy: "games.bullet.pow.copy"
};
function w() {
	return [
		"gainAp",
		"drawCard",
		"drawDiscard",
		"clearCenter",
		"clearSight",
		"moveAny",
		"swap",
		"putTwo",
		"copy"
	].flatMap((e) => [
		e,
		e,
		e
	]);
}
//#endregion
//#region src/games/bullet/meta.ts
var ce = {
	id: "bullet",
	tier: "beta",
	mechanics: ["tile-placement"],
	interactionTags: [],
	nameKey: "games.bullet.name",
	descKey: "games.bullet.desc",
	rulesKey: "games.bullet.rules",
	icon: "💘",
	iconImg: "games/bullet.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/bullet/en.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [1],
	accent: "#ec4899",
	releasedAt: "2026-10-24T13:42:56+08:00",
	search: {
		py: "dan wan tian xin",
		init: "dwtx"
	},
	hotseat: "cover"
}, T = t.int().min(0).max(29), le = t.object({ mode: t.enum(["ffa", "score"]).catch("ffa") }).default({ mode: "ffa" }), E = t.enum([
	"esfir",
	"adelheid",
	"ekolu",
	"lingling",
	"mariel",
	"rie",
	"senka",
	"youngja"
]), D = {
	cell: T.optional(),
	to: T.optional(),
	card: t.int().min(0).optional(),
	cross: t.int().min(0).max(1).optional()
}, ue = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("pick"),
		heroine: E
	}),
	t.object({
		type: t.literal("placeMarkers"),
		cells: t.array(T).min(1).max(2)
	}),
	t.object({ type: t.literal("place") }),
	t.object({
		type: t.literal("act"),
		idx: t.int().min(0),
		...D
	}),
	t.object({
		type: t.literal("usePattern"),
		card: t.int().min(0),
		origin: T.optional(),
		bonus: t.array(T).max(3).optional()
	}),
	t.object({
		type: t.literal("powerup"),
		slot: t.int().min(0).max(2),
		copySlot: t.int().min(0).max(2).optional(),
		a: T.optional(),
		b: T.optional(),
		cells: t.array(T).max(2).optional(),
		...D
	}),
	t.object({
		type: t.literal("riePick"),
		idx: t.int().min(0).max(1)
	}),
	t.object({
		type: t.literal("starResolve"),
		skip: t.boolean().optional(),
		cell: T.optional(),
		cross: t.int().min(0).max(1).optional(),
		to: T.optional()
	}),
	t.object({
		type: t.literal("marielRelocate"),
		cell: T
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("endPhase"),
		take: t.int().min(0).nullable(),
		replaceSlot: t.int().min(0).max(2).optional(),
		discard: t.array(t.int().min(0))
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), O = t.string(), k = t.string(), de = t.object({
	rid: O,
	heroine: E.nullable(),
	alive: t.boolean(),
	done: t.boolean(),
	sight: t.array(t.object({
		id: k,
		faceDown: t.boolean()
	}).nullable()),
	current: t.int().nonnegative(),
	incoming: t.int().nonnegative(),
	life: t.int().nonnegative(),
	lifeBullets: t.array(k),
	ap: t.int().nonnegative(),
	handCount: t.int().nonnegative(),
	deckCount: t.int().nonnegative(),
	discard: t.array(t.int().nonnegative()),
	powerups: t.array(t.string().nullable()),
	patternsPlayed: t.int().nonnegative(),
	mariel: T.nullable(),
	crosshairs: t.array(T).nullable(),
	endDone: t.boolean(),
	pending: t.string().nullable()
}), fe = t.object({
	mode: t.enum(["ffa", "score"]),
	phase: t.enum([
		"pick",
		"play",
		"end",
		"sudden",
		"over"
	]),
	round: t.int().min(1),
	intensity: t.int().nonnegative(),
	center: t.int().nonnegative(),
	centerPowerups: t.array(t.string()),
	powerupDeckCount: t.int().nonnegative(),
	players: t.array(de),
	scoreTrack: t.int().nonnegative(),
	sudden: t.array(O).nullable()
}), pe = t.object({
	hand: t.array(t.int().nonnegative()),
	rieOptions: t.array(k).nullable(),
	starQueue: t.array(t.string())
}), A = (e) => ({ code: e }), j = {
	place: 330,
	move: 300,
	clear: 680,
	hit: 480,
	draw: 300,
	flip: 260
};
function me(e, t, n) {
	e.resolution ||= {
		steps: [],
		ms: n
	}, e.resolution.steps.push(t);
}
function M(e, t, n, r) {
	e.push({
		kind: n,
		rid: t.rid,
		data: r,
		...e.length ? { with: !0 } : {}
	});
}
function N(t, n) {
	let r = e(t.seed, t.cursor, n.length);
	return t.cursor += 1, n.splice(r, 1)[0];
}
function he(t, n) {
	let r = e(t.seed, t.cursor, n.length);
	return t.cursor += 1, n.splice(r, 1)[0];
}
function P(t) {
	let n = e(t.seed, t.cursor, t.powerupDeck.length);
	return t.cursor += 1, t.powerupDeck.splice(n, 1)[0];
}
function ge(t, n) {
	let r = Array.from({ length: n }, (e, t) => t);
	for (let i = n - 1; i > 0; --i) {
		let n = e(t.seed, t.cursor, i + 1);
		t.cursor += 1, [r[i], r[n]] = [r[n], r[i]];
	}
	return r;
}
var F = (e) => [Math.floor(e / 5), e % 5], I = (e, t) => e * 5 + t, L = (e, t) => e >= 0 && e < 6 && t >= 0 && t < 5;
function R(e, t) {
	return e.sight[t] !== null || e.mariel === t;
}
function z(e) {
	let t = g(e.id);
	return e.fd ? {
		color: null,
		num: null,
		star: !1
	} : {
		color: t.color,
		num: t.num,
		star: t.star
	};
}
function _e(e, t, n) {
	if (!t) return !1;
	let r = z(t);
	return r.color === null ? t.fd && e.heroine !== null && C[e.heroine].ua === "compose" : r.color === n;
}
function ve(e, t, n) {
	if (!t) return !1;
	let r = z(t);
	return r.num === null ? !1 : e.heroine === "ekolu" && r.num === 3 || r.num === n;
}
function ye(e, t) {
	return e.sight[t] !== null || e.mariel === t;
}
function be(e, t) {
	let n = e.players.length;
	for (let r = 1; r <= n; r += 1) {
		let i = (t + r) % n;
		if (e.players[i].alive) return i;
	}
	return t;
}
function xe(e, t, n) {
	let r = 0;
	for (let e of n) z({
		id: e.id,
		fd: e.fd
	}).star && (r += 1);
	if (e.mode === "score") for (let t of n) e.scoreTrack.push(t.id);
	else {
		let r = e.players.indexOf(t), i = e.players[be(e, r)];
		for (let e of n) i.incoming.push({
			id: e.id,
			fd: !0
		});
	}
	return r;
}
function Se(e, t) {
	if (t <= 0 || !e.heroine) return;
	let n = C[e.heroine];
	for (let r = 0; r < t; r += 1) for (let t of n.star) if (t === "gainAp") e.ap = Math.min(n.apMax, e.ap + 1);
	else {
		let n = e.pending.find((e) => e.kind === "star");
		n || (n = {
			kind: "star",
			queue: []
		}, e.pending.push(n)), n.queue.push(t);
	}
}
function Ce(e, t, n, r, i = null, a = []) {
	let o = [], s = [], c = t.ap, l = t.mariel !== null && n.includes(t.mariel) ? t.mariel : null, u = !1;
	for (let e of n) {
		let n = t.sight[e];
		n && (o.push({
			id: n.id,
			fd: n.fd
		}), s.push({
			cell: e,
			id: n.id,
			fd: n.fd
		}), t.sight[e] = null), t.mariel === e && (t.mariel = null, u = !0);
	}
	let d = xe(e, t, o);
	return Se(t, d), u && t.pending.push({ kind: "mariel" }), (s.length || l !== null || i !== null) && M(r, t, "bulletClear", {
		pieces: s,
		marker: l,
		pattern: i,
		origins: a,
		heroine: t.heroine,
		apBefore: c,
		apAfter: t.ap,
		to: e.mode === "score" ? null : e.players[be(e, e.players.indexOf(t))].rid,
		stars: s.filter((e) => !e.fd && g(e.id).star).map((e) => e.cell)
	}), d;
}
var we = [
	"R",
	"B",
	"G",
	"Y",
	"P"
], Te = [
	"1",
	"2",
	"3",
	"4"
];
function Ee(e, t, n, r, i) {
	let a = [];
	for (let o = 0; o < t.length; o += 1) for (let s = 0; s < t[o].length; s += 1) {
		let c = t[o][s];
		if (c === " " || c === "X") continue;
		let l = n + o, u = r + s;
		if (!L(l, u)) return !1;
		let d = I(l, u), f = e.sight[d], p = ye(e, d);
		if (i) {
			if (!p) return !1;
			continue;
		}
		if (c === "O" || c === "(X)") {
			if (!p) return !1;
		} else if (c === "(+)") {
			if (!p) return !1;
		} else if (c !== "+") {
			if (c === "_") {
				if (p || (e.crosshairs ?? []).includes(d)) return !1;
			} else if (c === "/") {
				if (p) return !1;
			} else if (we.includes(c)) {
				if (!_e(e, f, c)) return !1;
			} else if (Te.includes(c)) {
				if (!ve(e, f, Number(c))) return !1;
			} else if (c === "=") {
				if (!f) return !1;
				let t = z(f);
				if (t.num === null) return !1;
				a.push(e.heroine === "ekolu" && t.num === 3 ? null : t.num);
			} else if (c === "C") {
				if (!(e.crosshairs ?? []).includes(d) || p) return !1;
			} else if (c === "(C)") {
				if (!(e.crosshairs ?? []).includes(d) || !p) return !1;
			} else c in _;
		}
	}
	let o = a.filter((e) => e !== null);
	return !(o.length > 0 && !o.every((e) => e === o[0]));
}
function De(e, t, n) {
	let r = [];
	for (let i = 0; i < e.length; i += 1) for (let a = 0; a < e[i].length; a += 1) {
		let e = t + i, o = n + a;
		L(e, o) && r.push(I(e, o));
	}
	return r;
}
function Oe(e, t, n) {
	let r = [];
	for (let i = 0; i < e.length; i += 1) for (let a = 0; a < e[i].length; a += 1) {
		if (e[i][a] !== "X" && e[i][a] !== "(X)") continue;
		let o = t + i, s = n + a;
		L(o, s) && r.push(I(o, s));
	}
	return r;
}
function ke(e, t, n, r) {
	let i = 0;
	for (let a = 0; a < t.length; a += 1) for (let o = 0; o < t[a].length; o += 1) {
		if (t[a][o] !== "+" && t[a][o] !== "(+)") continue;
		let s = n + a, c = r + o;
		if (!L(s, c)) continue;
		let l = e.sight[I(s, c)];
		if (l) {
			let e = z(l);
			e.num !== null && (i += e.num);
		}
	}
	return i;
}
function Ae(e, t, n) {
	let r = C[e], i = r.patterns[t];
	if (!i) return [];
	let a = [];
	if (r.ua === "crosshair") {
		let e = null;
		for (let t = 0; t < i.grid.length && !e; t += 1) for (let n = 0; n < i.grid[t].length; n += 1) if (i.grid[t][n] === "C" || i.grid[t][n] === "(C)") {
			e = [t, n];
			break;
		}
		if (!e || !n.crosshairs) return [];
		for (let t of n.crosshairs) {
			let [r, o] = F(t), s = r - e[0], c = o - e[1];
			Ee(n, i.grid, s, c, !1) && a.push(I(s, c));
		}
		return a;
	}
	for (let e = 0; e < 30; e += 1) {
		let [t, r] = F(e);
		Ee(n, i.grid, t, r, !1) && a.push(e);
	}
	return a;
}
function je(e, t, n, r) {
	let i = [];
	for (let a = 0; a < t.length; a += 1) for (let o = 0; o < t[a].length; o += 1) {
		let s = _[t[a][o]];
		if (!s) continue;
		let c = n + a, l = r + o;
		if (!L(c, l)) continue;
		let u = I(c, l);
		(e.sight[u] || e.mariel === u) && i.push({
			from: u,
			dir: s
		});
	}
	i.sort((e, t) => e.from - t.from);
	for (let t of i) me(e, {
		kind: "push",
		...t
	}, j.clear);
}
function Me(e, t, n, r, i, a) {
	let o = a ?? [], s = t.sight[n], c = t.mariel === n;
	if (!s && !c) return;
	let [l, u] = F(n), d = l + r[0], f = u + r[1];
	if (!L(d, f)) {
		Ce(e, t, [n], i);
		return;
	}
	let p = I(d, f);
	R(t, p) && Me(e, t, p, r, i, o), s && (t.sight[p] = s, t.sight[n] = null), c && (t.mariel = p), o.push({
		from: n,
		to: p,
		id: s?.id ?? "",
		fd: s?.fd ?? !1,
		marker: c
	}), !a && o.length && M(i, t, "bulletMove", {
		moves: o,
		heroine: t.heroine
	});
}
function Ne(e, t, n) {
	let r = g(t.id), i = [
		"R",
		"B",
		"G",
		"Y",
		"P"
	].indexOf(r.color), a = 0, o = -1;
	for (let t = 0; t < 6; t += 1) {
		let n = I(t, i);
		if (!R(e, n) && (a += 1, a === r.num)) {
			o = n;
			break;
		}
	}
	if (o >= 0) {
		e.sight[o] = {
			id: t.id,
			fd: t.fd
		}, M(n, e, "bulletPlace", {
			id: t.id,
			fd: t.fd,
			target: o,
			heroine: e.heroine
		});
		return;
	}
	M(n, e, "bulletMiss", {
		id: t.id,
		fd: t.fd,
		col: i,
		heroine: e.heroine
	}), me(e, {
		kind: "impact",
		item: t
	}, j.place);
}
function Pe(e, t, n, r) {
	let i = g(n.id);
	if (t.heroine === "rie" && t.discard.length > 0 && C.rie.patterns[t.discard[t.discard.length - 1]].color === i.color) {
		let i = t.ap;
		Se(t, xe(e, t, [{
			id: n.id,
			fd: n.fd
		}])), M(r, t, "niceTry", {
			id: n.id,
			fd: n.fd,
			heroine: t.heroine,
			apBefore: i,
			apAfter: t.ap,
			to: e.mode === "score" ? null : e.players[be(e, e.players.indexOf(t))].rid
		});
		return;
	}
	--t.life, t.lifeBullets.push(n.id), t.lostLife = !0, M(r, t, "hit", {
		id: n.id,
		life: t.life,
		heroine: t.heroine
	}), t.life <= 0 && e.phase !== "sudden" && (t.alive = !1, t.done = !0, t.endDone = !0, t.outRound = e.round, M(r, t, "ko", { heroine: t.heroine }), me(t, { kind: "finish" }, j.hit));
}
function Fe(e, t, n) {
	if (t.deck.length === 0) {
		if (t.discard.length === 0) return !1;
		t.deck = ge(e, t.discard.length).map((e) => t.discard[e]), t.discard = [];
	}
	return t.hand.push(t.deck.pop()), n && n.push({
		kind: "bulletDraw",
		rid: t.rid,
		data: { count: 1 },
		for: [t.rid],
		secret: {
			pattern: t.hand[t.hand.length - 1],
			slot: t.hand.length - 1,
			heroine: t.heroine
		},
		...n.length ? { with: !0 } : {}
	}), !0;
}
function Ie(e, t, n) {
	let r = t.length === 1 ? "score" : e.mode, i = {
		mode: r,
		phase: "pick",
		round: 1,
		intensity: 4,
		seed: n,
		cursor: 0,
		center: h(),
		powerupDeck: r === "ffa" ? w() : [],
		centerPowerups: [],
		scoreTrack: [],
		sudden: null,
		winner: [],
		ranking: [],
		players: t.map((e) => ({
			rid: e,
			heroine: null,
			alive: !0,
			done: !1,
			sight: Array.from({ length: 30 }, () => null),
			current: [],
			incoming: [],
			life: 0,
			lifeBullets: [],
			ap: 0,
			hand: [],
			deck: [],
			discard: [],
			powerups: [
				null,
				null,
				null
			],
			patternsPlayed: 0,
			boostNext: 0,
			anyNext: !1,
			mariel: null,
			crosshairs: null,
			endDone: !1,
			lostLife: !1,
			outRound: null,
			pending: []
		}))
	};
	if (r === "ffa") for (let e = 0; e < t.length; e += 1) i.centerPowerups.push(P(i));
	return { state: i };
}
function Le(e, t) {
	return e.players.find((e) => e.rid === t);
}
function Re(e) {
	return e.pending.length > 0 || !!e.resolution;
}
function ze(e, t, n) {
	return e.phase !== "pick" || t.heroine ? A("games.bullet.errPhase") : e.players.some((e) => e.heroine === n) ? A("games.bullet.errHeroineTaken") : null;
}
function Be(e, t, n) {
	let r = C[n];
	t.heroine = n, t.life = r.maxLife, t.ap = r.apMax, t.deck = ge(e, r.patterns.length);
	for (let e = 0; e < r.handSize; e += 1) t.hand.push(t.deck.pop());
	for (let n = 0; n < 10; n += 1) t.current.push({
		id: N(e, e.center),
		fd: !1
	});
	(r.ua === "mariel" || r.ua === "crosshair") && t.pending.push({ kind: "markers" });
}
function Ve(e) {
	e.phase === "pick" && e.players.every((e) => e.heroine !== null && e.pending.length === 0) && (e.phase = "play");
}
function He(e, t) {
	return e.phase !== "play" && e.phase !== "sudden" || !t.alive || t.done ? A("games.bullet.errPhase") : Re(t) ? A("games.bullet.errPending") : null;
}
function Ue(e, t, n, r) {
	if (n.cell === void 0 || n.to === void 0) return A("games.bullet.errBadMove");
	let i = e.sight[n.cell];
	if (!i || !L(...F(n.to)) || R(e, n.to)) return A("games.bullet.errBadCell");
	let [a, o] = F(n.cell), [s, c] = F(n.to), l = s - a, u = c - o, d = t.move.dirs;
	if (t.move.dist === "one") {
		if (!d.some(([e, t]) => e === l && t === u)) return A("games.bullet.errBadMove");
	} else if (t.move.dist === "num") {
		let e = z(i).num;
		if (e === null || !d.some(([t, n]) => t * e === l && n * e === u)) return A("games.bullet.errBadMove");
	} else if (!d.some(([t, n]) => {
		if (t === 0 && n === 0) return !1;
		let r = t === 0 ? u / n : n !== 0 && Math.abs(l) !== Math.abs(u) ? -1 : l / t;
		if (r < 1 || !Number.isInteger(r) || t * r !== l || n * r !== u) return !1;
		for (let i = 1; i < r; i += 1) if (R(e, I(a + t * i, o + n * i))) return !1;
		let i = s + t, d = c + n;
		return !L(i, d) || R(e, I(i, d));
	})) return A("games.bullet.errBadMove");
	return e.sight[n.to] = i, e.sight[n.cell] = null, M(r, e, "bulletMove", {
		moves: [{
			from: n.cell,
			to: n.to,
			id: i.id,
			fd: i.fd,
			marker: !1
		}],
		heroine: e.heroine
	}), null;
}
function We(e, t, n, r) {
	if (!t.heroine) return A("games.bullet.errPhase");
	let i = C[t.heroine].actions[n.idx];
	if (!i) return A("games.bullet.errPhase");
	if (t.ap < i.cost) return A("games.bullet.errNoAp");
	switch (i.t) {
		case "move": {
			let e = Ue(t, i, n, r);
			if (e) return e;
			break;
		}
		case "push": {
			if (n.cell === void 0 || n.to === void 0) return A("games.bullet.errBadMove");
			if (!t.sight[n.cell] && t.mariel !== n.cell) return A("games.bullet.errBadCell");
			let [i, a] = F(n.cell), [o, s] = F(n.to), c = [o - i, s - a];
			if (!Object.values(_).some(([e, t]) => e === c[0] && t === c[1])) return A("games.bullet.errBadMove");
			Me(e, t, n.cell, c, r);
			break;
		}
		case "draw":
			if (!Fe(e, t, r)) return A("games.bullet.errPhase");
			break;
		case "discardDraw":
			if (n.card === void 0 || n.card < 0 || n.card >= t.hand.length) return A("games.bullet.errBadCell");
			if (t.discard.push(t.hand.splice(n.card, 1)[0]), !Fe(e, t, r)) return A("games.bullet.errPhase");
			break;
		case "placeCenter":
			if (n.cell === void 0 || R(t, n.cell)) return A("games.bullet.errBadCell");
			if (e.center.length === 0) return A("games.bullet.errPhase");
			t.sight[n.cell] = {
				id: N(e, e.center),
				fd: !1
			}, M(r, t, "bulletPlace", {
				id: t.sight[n.cell].id,
				fd: !1,
				target: n.cell,
				source: "center",
				heroine: t.heroine
			});
			break;
		case "boostNext":
			t.boostNext += 1, M(r, t, "bulletAbility", { heroine: t.heroine });
			break;
		case "anyNext":
			t.anyNext = !0, M(r, t, "bulletAbility", { heroine: t.heroine });
			break;
		case "moveMarker": {
			if (n.cell === void 0 || R(t, n.cell)) return A("games.bullet.errBadCell");
			let e = t.mariel;
			t.mariel = n.cell, M(r, t, "bulletMarker", {
				from: e,
				to: n.cell,
				marker: !0,
				heroine: t.heroine
			});
			break;
		}
		case "clearAdj": {
			if (n.cell === void 0 || !t.sight[n.cell] || t.mariel === null) return A("games.bullet.errBadCell");
			let [i, a] = F(t.mariel), [o, s] = F(n.cell);
			if (Math.abs(i - o) + Math.abs(a - s) !== 1) return A("games.bullet.errBadCell");
			Ce(e, t, [n.cell], r);
			break;
		}
		case "reveal": {
			if (t.current.length === 0) return A("games.bullet.errPhase");
			let n = he(e, t.current);
			if (t.current.length === 0) {
				Ne(t, n, r);
				break;
			}
			let i = he(e, t.current);
			t.pending.push({
				kind: "rie",
				options: [n.id, i.id]
			}), r.push({
				kind: "bulletReveal",
				for: [t.rid],
				secret: { ids: [n.id, i.id] },
				...r.length ? { with: !0 } : {}
			}), t.current.push({
				id: `held:${n.id}:${+!!n.fd}`,
				fd: n.fd
			}), t.current.push({
				id: `held:${i.id}:${+!!i.fd}`,
				fd: i.fd
			});
			break;
		}
		case "clearLife": {
			if (n.card === void 0 || n.card < 0 || n.card >= t.lifeBullets.length) return A("games.bullet.errBadCell");
			let i = t.lifeBullets.splice(n.card, 1)[0];
			Se(t, xe(e, t, [{
				id: i,
				fd: !1
			}])), M(r, t, "bulletLifeClear", {
				id: i,
				heroine: t.heroine
			});
			break;
		}
		case "moveCross": {
			if (n.cross === void 0 || n.to === void 0 || !t.crosshairs || n.cross >= t.crosshairs.length) return A("games.bullet.errBadCell");
			let [e, i] = F(t.crosshairs[n.cross]), [a, o] = F(n.to);
			if (!L(a, o)) return A("games.bullet.errBadCell");
			let s = Math.abs(a - e) + Math.abs(o - i);
			if (s < 1 || s > 2) return A("games.bullet.errBadMove");
			let c = t.crosshairs[n.cross];
			t.crosshairs[n.cross] = n.to, M(r, t, "bulletMarker", {
				from: c,
				to: n.to,
				marker: !1,
				heroine: t.heroine
			});
			break;
		}
	}
	return t.ap -= i.cost, null;
}
function Ge(e, t, n, r) {
	if (!t.heroine) return A("games.bullet.errPhase");
	let i = C[t.heroine];
	if (n.card < 0 || n.card >= t.hand.length) return A("games.bullet.errBadCell");
	let a = i.patterns[t.hand[n.card]], o = [];
	if (i.ua === "crosshair") {
		let e = (() => {
			for (let e = 0; e < a.grid.length; e += 1) for (let t = 0; t < a.grid[e].length; t += 1) if (a.grid[e][t] === "C" || a.grid[e][t] === "(C)") return [e, t];
			return null;
		})();
		if (!e || !t.crosshairs) return A("games.bullet.errBadPattern");
		for (let n of t.crosshairs) {
			let [r, i] = F(n), s = r - e[0], c = i - e[1];
			Ee(t, a.grid, s, c, t.anyNext) && o.push(I(s, c));
		}
		if (o.length === 0) return A("games.bullet.errBadPattern");
	} else {
		if (n.origin === void 0) return A("games.bullet.errBadPattern");
		let [e, r] = F(n.origin);
		if (!Ee(t, a.grid, e, r, t.anyNext)) return A("games.bullet.errBadPattern");
		o.push(n.origin);
	}
	let s = [];
	if (i.ua === "calculating") {
		let e = ke(t, a.grid, F(o[0])[0], F(o[0])[1]) + t.boostNext, r = n.bonus ?? [];
		if (e >= 6) {
			let n = e >= 13 || e >= 10 ? 3 : 2;
			if (r.length > n) return A("games.bullet.errBadBonus");
			let i = new Set(De(a.grid, F(o[0])[0], F(o[0])[1])), c = e >= 13;
			for (let e of r) if (!ye(t, e) || i.has(e) !== c) return A("games.bullet.errBadBonus");
			if (new Set(r).size !== r.length) return A("games.bullet.errBadBonus");
			s = r;
		} else if (r.length > 0) return A("games.bullet.errBadBonus");
	} else if ((n.bonus ?? []).length > 0) return A("games.bullet.errBadBonus");
	let c = t.hand[n.card];
	t.discard.push(t.hand.splice(n.card, 1)[0]), t.patternsPlayed += 1, t.boostNext = 0, t.anyNext = !1;
	let l = new Set(s);
	for (let e of o) {
		let [t, n] = F(e);
		for (let e of Oe(a.grid, t, n)) l.add(e);
	}
	if (Ce(e, t, [...l], r, c, o), i.ua === "levitation") {
		let [e, n] = F(o[0]);
		je(t, a.grid, e, n);
	}
	return i.ua === "sacred3" && t.patternsPlayed === 3 && me(t, { kind: "sacred3" }, j.clear), null;
}
function Ke(e, t, n, r, i) {
	switch (n) {
		case "gainAp": return t.ap = Math.min(C[t.heroine].apMax, t.ap + 1), M(i, t, "bulletAbility", { heroine: t.heroine }), null;
		case "drawCard": return Fe(e, t, i) ? null : A("games.bullet.errPhase");
		case "drawDiscard": return t.discard.length === 0 ? A("games.bullet.errPhase") : (t.hand.push(t.discard.pop()), i.push({
			kind: "bulletDraw",
			rid: t.rid,
			data: { count: 1 },
			for: [t.rid],
			secret: {
				pattern: t.hand[t.hand.length - 1],
				slot: t.hand.length - 1,
				heroine: t.heroine
			},
			...i.length ? { with: !0 } : {}
		}), null);
		case "clearCenter": return e.center.length === 0 ? A("games.bullet.errPhase") : (xe(e, t, [{
			id: N(e, e.center),
			fd: !1
		}]), M(i, t, "bulletAbility", { heroine: t.heroine }), null);
		case "clearSight": return r.cell === void 0 || !ye(t, r.cell) ? A("games.bullet.errBadCell") : (Ce(e, t, [r.cell], i), null);
		case "moveAny": {
			if (r.cell === void 0 || r.to === void 0) return A("games.bullet.errBadMove");
			let e = t.sight[r.cell];
			return !e || R(t, r.to) ? A("games.bullet.errBadCell") : (t.sight[r.to] = e, t.sight[r.cell] = null, M(i, t, "bulletMove", {
				moves: [{
					from: r.cell,
					to: r.to,
					id: e.id,
					fd: e.fd,
					marker: !1
				}],
				heroine: t.heroine
			}), null);
		}
		case "swap": {
			if (r.a === void 0 || r.b === void 0) return A("games.bullet.errBadCell");
			let e = t.sight[r.a], n = t.sight[r.b];
			return !e || !n ? A("games.bullet.errBadCell") : (t.sight[r.a] = n, t.sight[r.b] = e, M(i, t, "bulletMove", {
				moves: [{
					from: r.a,
					to: r.b,
					id: e.id,
					fd: e.fd,
					marker: !1
				}, {
					from: r.b,
					to: r.a,
					id: n.id,
					fd: n.fd,
					marker: !1
				}],
				heroine: t.heroine
			}), null);
		}
		case "putTwo": {
			let n = r.cells ?? [];
			if (n.length < 1 || n.length > 2 || new Set(n).size !== n.length) return A("games.bullet.errBadCell");
			for (let e of n) if (!ye(t, e)) return A("games.bullet.errBadCell");
			for (let r of n) {
				let n = t.sight[r];
				n && (M(i, t, "bulletReturn", {
					cell: r,
					id: n.id,
					fd: n.fd,
					heroine: t.heroine
				}), e.center.push(n.id), t.sight[r] = null), t.mariel === r && (t.mariel = null, t.pending.push({ kind: "mariel" }));
			}
			return null;
		}
		case "copy": return A("games.bullet.errPhase");
	}
}
function qe(e, t, n, r) {
	if (e.mode !== "ffa") return A("games.bullet.errNoPowerup");
	if (!t.heroine) return A("games.bullet.errPhase");
	let i = t.powerups[n.slot];
	if (!i) return A("games.bullet.errNoPowerup");
	let a = i;
	if (i === "copy") {
		if (n.copySlot === void 0 || n.copySlot === n.slot) return A("games.bullet.errNoPowerup");
		let e = t.powerups[n.copySlot];
		if (!e || e === "copy") return A("games.bullet.errNoPowerup");
		a = e;
	}
	return Ke(e, t, a, n, r) || (t.powerups[n.slot] = null, null);
}
function Je(e) {
	return e.players.filter((e) => e.alive);
}
function Ye(e) {
	if (e.phase === "play" && !e.players.some((e) => e.resolution) && e.players.every((e) => e.done)) {
		e.phase = "end";
		for (let t of e.players) t.endDone = !t.alive;
		e.players.every((e) => e.endDone) && Qe(e);
	}
}
function Xe(e, t, n) {
	if (e.phase !== "end" || t.endDone) return A("games.bullet.errPhase");
	let r = C[t.heroine];
	if (e.mode === "score") {
		if (n.take !== null) return A("games.bullet.errNoPowerup");
	} else if (n.take !== null) {
		let r = e.centerPowerups[n.take];
		if (!r) return A("games.bullet.errNoPowerup");
		let i = t.powerups.indexOf(null);
		if (i < 0) {
			if (n.replaceSlot === void 0 || !t.powerups[n.replaceSlot]) return A("games.bullet.errNoPowerup");
			t.powerups[n.replaceSlot] = r;
		} else t.powerups[i] = r;
		e.centerPowerups.splice(n.take, 1);
	}
	let i = Math.max(0, t.hand.length - r.handSize);
	if (n.discard.length !== i || new Set(n.discard).size !== n.discard.length || n.discard.some((e) => e < 0 || e >= t.hand.length)) return A("games.bullet.errBadDiscard");
	let a = t.hand.filter((e, t) => !n.discard.includes(t));
	for (t.discard.push(...t.hand.filter((e, t) => n.discard.includes(t))), t.hand = a; t.hand.length < r.handSize && Fe(e, t););
	let o = e.intensity + (e.mode === "score" ? e.scoreTrack.length : 0);
	for (; o > 0;) {
		if (e.center.length === 0) return e.phase = "over", e.winner = [], e.ranking = Ze(e), null;
		t.current.push({
			id: N(e, e.center),
			fd: !1
		}), --o;
	}
	return t.endDone = !0, null;
}
function Ze(e) {
	return [...e.players].sort((e, t) => {
		let n = e.outRound ?? 999, r = t.outRound ?? 999;
		return n === r ? e.current.length - t.current.length : r - n;
	}).map((e) => e.rid);
}
function Qe(e) {
	let t = Je(e);
	if (t.length === 0) {
		let t = Math.min(...e.players.map((e) => e.current.length)), n = e.players.filter((e) => e.current.length === t);
		if (n.length === 1) {
			e.phase = "over", e.winner = [n[0].rid], e.ranking = [n[0].rid, ...Ze(e).filter((e) => e !== n[0].rid)];
			return;
		}
		e.phase = "sudden", e.sudden = n.map((e) => e.rid);
		for (let e of n) e.alive = !0, e.done = !1, e.life = 1, e.pending = [], e.current.push(...e.incoming), e.incoming = [];
		return;
	}
	if (t.length === 1 && e.players.length > 1) {
		e.phase = "over", e.winner = [t[0].rid], e.ranking = [t[0].rid, ...Ze(e).filter((e) => e !== t[0].rid)];
		return;
	}
	e.mode === "score" && (e.center.push(...e.scoreTrack), e.scoreTrack = []);
	for (let t of e.players) if (!t.alive) {
		for (let n of t.sight) n && e.center.push(n.id);
		t.sight = Array.from({ length: 30 }, () => null);
		for (let n of t.current) e.center.push(n.id);
		t.current = [];
		for (let n of t.incoming) e.center.push(n.id);
		t.incoming = [], e.center.push(...t.lifeBullets), t.lifeBullets = [];
	}
	e.intensity += 1 + e.players.filter((e) => e.lostLife).length;
	for (let e of t) e.current.push(...e.incoming), e.incoming = [], e.ap = C[e.heroine].apMax, e.patternsPlayed = 0, e.boostNext = 0, e.anyNext = !1, e.lostLife = !1, e.done = !1, e.endDone = !1;
	if (e.mode === "ffa") for (; e.centerPowerups.length < t.length && e.powerupDeck.length > 0;) e.centerPowerups.push(P(e));
	e.round += 1, e.phase = "play";
}
function $e(e, t, n) {
	let r = e, i = [];
	if (t.type === "tick") {
		if (r.phase === "over") return { state: r };
		let e = r.players.filter((e) => e.resolution);
		if (!e.length) return { state: r };
		let t = Math.min(...e.map((e) => e.resolution.ms));
		for (let n of e) {
			let e = n.resolution;
			if (e.ms -= t, e.ms > 0) continue;
			let a = e.steps.shift(), o = i.length;
			if (a?.kind === "impact") Pe(r, n, a.item, i), r.phase === "sudden" && n.life <= 0 && me(n, { kind: "finish" }, j.hit);
			else if (a?.kind === "push") Me(r, n, a.from, a.dir, i);
			else if (a?.kind === "sacred3") Ce(r, n, n.sight.flatMap((e, t) => e && z(e).num === 3 ? [t] : []), i);
			else if (a?.kind === "finish" && r.phase === "sudden") {
				r.phase = "over", n.alive = !1, n.outRound = r.round;
				let e = (r.sudden ?? []).filter((e) => e !== n.rid);
				r.winner = e, r.ranking = [
					...e,
					n.rid,
					...Ze(r).filter((t) => t !== n.rid && !e.includes(t))
				], delete n.resolution;
				break;
			}
			e.steps.length ? e.ms = i.slice(o).some((e) => e.kind === "hit" || e.kind === "ko") ? j.hit : i.slice(o).some((e) => e.kind === "bulletClear") ? j.clear : j.move : delete n.resolution;
		}
		return Ye(r), {
			state: r,
			fx: i
		};
	}
	let a = Le(r, n.by);
	if (!a) return A("games.bullet.errNotYours");
	if (a.resolution || r.phase === "sudden" && r.players.some((e) => e.resolution)) return A("games.bullet.errPending");
	switch (t.type) {
		case "pick": return ze(r, a, t.heroine) || (Be(r, a, t.heroine), Ve(r), {
			state: r,
			fx: i
		});
		case "placeMarkers": {
			if (r.phase !== "pick" || !a.heroine) return A("games.bullet.errPhase");
			if (!a.pending.find((e) => e.kind === "markers")) return A("games.bullet.errPending");
			let e = C[a.heroine], n = e.ua === "mariel" ? 1 : e.ua === "crosshair" ? 2 : 0;
			return t.cells.length !== n || new Set(t.cells).size !== n ? A("games.bullet.errBadCell") : (e.ua === "mariel" ? a.mariel = t.cells[0] : a.crosshairs = [...t.cells], a.pending = a.pending.filter((e) => e.kind !== "markers"), Ve(r), {
				state: r,
				fx: i
			});
		}
		case "place":
			if (r.phase === "sudden") {
				if (!r.sudden?.includes(a.rid)) return A("games.bullet.errPhase");
				if (Re(a)) return A("games.bullet.errPending");
				if (a.current.length === 0) {
					if (r.center.length === 0) return r.phase = "over", r.winner = [], r.ranking = Ze(r), {
						state: r,
						fx: i
					};
					a.current.push({
						id: N(r, r.center),
						fd: !1
					});
				}
				return Ne(a, he(r, a.current), i), {
					state: r,
					fx: i
				};
			}
			return He(r, a) || (a.current.length === 0 ? A("games.bullet.errPhase") : (Ne(a, he(r, a.current), i), Ye(r), {
				state: r,
				fx: i
			}));
		case "act": return He(r, a) || (r.phase === "play" ? We(r, a, t, i) || (Ye(r), {
			state: r,
			fx: i
		}) : A("games.bullet.errPhase"));
		case "usePattern": return He(r, a) || (r.phase === "play" ? Ge(r, a, t, i) || (Ye(r), {
			state: r,
			fx: i
		}) : A("games.bullet.errPhase"));
		case "powerup": return He(r, a) || (r.phase === "play" ? qe(r, a, t, i) || {
			state: r,
			fx: i
		} : A("games.bullet.errPhase"));
		case "riePick": {
			if (!a.pending.find((e) => e.kind === "rie")) return A("games.bullet.errPending");
			let e = a.current.filter((e) => e.id.startsWith("held:"));
			if (a.current = a.current.filter((e) => !e.id.startsWith("held:")), !e[t.idx]) return A("games.bullet.errBadCell");
			let n = e.map((e) => {
				let [, t, n] = e.id.split(":");
				return {
					id: t,
					fd: n === "1"
				};
			}), o = n[t.idx], s = n[1 - t.idx];
			return s && a.current.push(s), a.pending = a.pending.filter((e) => e.kind !== "rie"), Ne(a, o, i), Ye(r), {
				state: r,
				fx: i
			};
		}
		case "starResolve": {
			let e = a.pending.find((e) => e.kind === "star");
			if (!e || e.queue.length === 0) return A("games.bullet.errPending");
			let n = e.queue[0];
			if (!t.skip) {
				if (n === "flip") {
					if (t.cell === void 0 || !a.sight[t.cell]) return A("games.bullet.errBadCell");
					a.sight[t.cell] = {
						...a.sight[t.cell],
						fd: !0
					}, M(i, a, "bulletFlip", {
						cell: t.cell,
						id: a.sight[t.cell].id,
						heroine: a.heroine
					});
				} else if (n === "moveCross1") {
					if (t.cross === void 0 || t.to === void 0 || !a.crosshairs || t.cross >= a.crosshairs.length) return A("games.bullet.errBadCell");
					let [e, n] = F(a.crosshairs[t.cross]), [r, o] = F(t.to);
					if (!L(r, o) || Math.abs(r - e) + Math.abs(o - n) !== 1) return A("games.bullet.errBadMove");
					let s = a.crosshairs[t.cross];
					a.crosshairs[t.cross] = t.to, M(i, a, "bulletMarker", {
						from: s,
						to: t.to,
						marker: !1,
						heroine: a.heroine
					});
				}
			}
			return e.queue.shift(), e.queue.length === 0 && (a.pending = a.pending.filter((e) => e.kind !== "star")), {
				state: r,
				fx: i
			};
		}
		case "marielRelocate": return a.pending.find((e) => e.kind === "mariel") ? R(a, t.cell) ? A("games.bullet.errBadCell") : (a.mariel = t.cell, M(i, a, "bulletMarker", {
			from: null,
			to: t.cell,
			marker: !0,
			heroine: a.heroine
		}), a.pending = a.pending.filter((e) => e.kind !== "mariel"), {
			state: r,
			fx: i
		}) : A("games.bullet.errPending");
		case "endTurn": return r.phase !== "play" || !a.alive || a.done ? A("games.bullet.errPhase") : Re(a) ? A("games.bullet.errPending") : a.current.length > 0 ? A("games.bullet.errNotEmpty") : (a.done = !0, Ye(r), {
			state: r,
			fx: i
		});
		case "endPhase": return Xe(r, a, t) || (r.phase === "end" && r.players.every((e) => e.endDone) && Qe(r), {
			state: r,
			fx: i
		});
	}
}
function et(e, t) {
	let n = Le(e, t), r = {
		mode: e.mode,
		phase: e.phase,
		round: e.round,
		intensity: e.intensity,
		center: e.center.length,
		centerPowerups: [...e.centerPowerups],
		powerupDeckCount: e.powerupDeck.length,
		players: e.players.map((e) => ({
			rid: e.rid,
			heroine: e.heroine,
			alive: e.alive,
			done: e.done,
			sight: e.sight.map((e) => e ? {
				id: e.id,
				faceDown: e.fd
			} : null),
			current: e.current.length,
			incoming: e.incoming.length,
			life: e.life,
			lifeBullets: [...e.lifeBullets],
			ap: e.ap,
			handCount: e.hand.length,
			deckCount: e.deck.length,
			discard: [...e.discard],
			powerups: e.powerups.map((e) => e ?? null),
			patternsPlayed: e.patternsPlayed,
			mariel: e.mariel,
			crosshairs: e.crosshairs ? [...e.crosshairs] : null,
			endDone: e.endDone,
			pending: e.resolution ? "resolve" : e.pending[0]?.kind ?? null
		})),
		scoreTrack: e.scoreTrack.length,
		sudden: e.sudden ? [...e.sudden] : null
	}, i = n?.pending.find((e) => e.kind === "rie"), a = n?.pending.find((e) => e.kind === "star");
	return {
		public: r,
		private: {
			hand: n ? [...n.hand] : [],
			rieOptions: i ? [...i.options] : null,
			starQueue: a ? [...a.queue] : []
		}
	};
}
function tt(e) {
	if (e.phase !== "over") return { phase: e.phase };
	let t = {};
	return e.mode === "score" && (t[e.players[0].rid] = e.round - 1), {
		phase: "over",
		winner: e.winner,
		ranking: e.ranking,
		scores: e.mode === "score" ? t : void 0
	};
}
var nt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: ce,
	schemas: {
		action: ue,
		publicView: fe,
		privateView: pe,
		config: le
	},
	setup: Ie,
	reduce: $e,
	viewFor: et,
	status: tt,
	nextTickIn: (e) => {
		if (e.phase === "over") return null;
		let t = e.players.flatMap((e) => e.resolution ? [e.resolution.ms] : []);
		return t.length ? Math.min(...t) : null;
	}
}, rt = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%3e%3cdefs%3e%3csymbol%20id='hero-esfir'%20viewBox='0%200%20620%201080'%3e%3cdefs%3e%3clinearGradient%20id='ev-hair'%20x1='0'%20y1='0'%20x2='.85'%20y2='1'%3e%3cstop%20stop-color='%23a83b62'/%3e%3cstop%20offset='.3'%20stop-color='%23ef6f64'/%3e%3cstop%20offset='.7'%20stop-color='%23ff9d73'/%3e%3cstop%20offset='1'%20stop-color='%23d54465'/%3e%3c/linearGradient%3e%3clinearGradient%20id='ev-hair-light'%20x1='0'%20y1='0'%20x2='1'%20y2='.6'%3e%3cstop%20stop-color='%23ffbd91'/%3e%3cstop%20offset='.52'%20stop-color='%23f78769'/%3e%3cstop%20offset='1'%20stop-color='%23d04d67'/%3e%3c/linearGradient%3e%3clinearGradient%20id='ev-coat'%20x1='0'%20y1='0'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%2340314c'/%3e%3cstop%20offset='.53'%20stop-color='%23222c43'/%3e%3cstop%20offset='1'%20stop-color='%23131d33'/%3e%3c/linearGradient%3e%3clinearGradient%20id='ev-lining'%20x1='0'%20y1='0'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23b84161'/%3e%3cstop%20offset='1'%20stop-color='%23542c51'/%3e%3c/linearGradient%3e%3clinearGradient%20id='ev-skin'%20x1='0'%20y1='0'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23ffe1c8'/%3e%3cstop%20offset='.6'%20stop-color='%23ffceba'/%3e%3cstop%20offset='1'%20stop-color='%23de8e96'/%3e%3c/linearGradient%3e%3clinearGradient%20id='ev-uniform'%20x1='0'%20y1='0'%20x2='.7'%20y2='1'%3e%3cstop%20stop-color='%23688b78'/%3e%3cstop%20offset='.5'%20stop-color='%2348685d'/%3e%3cstop%20offset='1'%20stop-color='%23284747'/%3e%3c/linearGradient%3e%3clinearGradient%20id='ev-iris'%20x1='0'%20y1='0'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23267978'/%3e%3cstop%20offset='.55'%20stop-color='%23a6d87e'/%3e%3cstop%20offset='1'%20stop-color='%23e2ed8e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='ev-boot'%20x1='0'%20y1='0'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%2349394d'/%3e%3cstop%20offset='1'%20stop-color='%231a2439'/%3e%3c/linearGradient%3e%3clinearGradient%20id='ev-fur'%20x1='0'%20y1='0'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0d4'/%3e%3cstop%20offset='.6'%20stop-color='%23e7d4c4'/%3e%3cstop%20offset='1'%20stop-color='%23a7a8b2'/%3e%3c/linearGradient%3e%3cclipPath%20id='ev-eye-a'%3e%3cpath%20d='M257%20238%20Q277%20220%20300%20236%20Q282%20252%20260%20248Z'/%3e%3c/clipPath%3e%3cclipPath%20id='ev-eye-b'%3e%3cpath%20d='M323%20234%20Q340%20215%20361%20225%20Q350%20244%20328%20245Z'/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20stroke='%23322338'%20stroke-width='2.5'%20stroke-linejoin='round'%20stroke-linecap='round'%3e%3c!--%20Loose%20hair,%20asymmetric%20coat%20tails%20and%20the%20pose%20are%20drawn%20specifically%20for%20this%20study.%20--%3e%3cpath%20d='M235%20149%20C151%20195%20180%20358%20141%20480%20C114%20574%2022%20635%2025%20739%20C44%20691%2091%20696%20113%20658%20C80%20742%2027%20807%2051%20948%20C83%20865%20153%20840%20180%20775%20C155%20889%20188%201005%20126%201070%20C266%201047%20250%20930%20286%20853%20C324%20983%20438%201010%20526%201047%20C460%20963%20483%20906%20468%20831%20C497%20850%20537%20880%20596%20878%20C536%20831%20576%20737%20526%20660%20C566%20685%20586%20691%20613%20692%20C561%20631%20561%20573%20514%20531%20C466%20472%20440%20390%20419%20284%20C412%20193%20367%20127%20296%20132Z'%20fill='url(%23ev-hair)'/%3e%3cpath%20d='M216%20263%20C185%20428%20186%20589%20105%20740%20C150%20730%20178%20668%20182%20641%20C163%20801%20230%20870%20186%20985%20C250%20912%20238%20827%20249%20733%20L269%20376Z'%20fill='%23ac3b63'%20stroke='none'/%3e%3cpath%20d='M391%20274%20C409%20388%20408%20517%20489%20595%20C527%20628%20523%20698%20569%20734%20C529%20654%20558%20648%20535%20608%20C499%20555%20453%20454%20445%20349Z'%20fill='%23ffc397'%20stroke='none'/%3e%3cpath%20d='M148%20549%20C123%20660%2058%20683%2052%20757%20M190%20421%20C194%20629%20117%20722%2088%20837%20M430%20363%20C431%20581%20535%20669%20522%20801%20M207%20769%20C235%20865%20203%20961%20180%20996'%20fill='none'%20stroke='%23ffba8d'%20stroke-width='4'%20opacity='.65'/%3e%3cpath%20d='M291%20675%20C242%20690%20177%20725%20157%20777%20L101%20980%20Q162%20970%20217%20915%20L278%20797%20L341%20803%20L392%201009%20Q454%201006%20491%20970%20L441%20762%20C419%20700%20356%20672%20291%20675Z'%20fill='url(%23ev-coat)'/%3e%3cpath%20d='M170%20779%20L112%20965%20Q173%20939%20204%20894%20L254%20758Z%20M390%20773%20L405%20986%20L478%20969%20L438%20783Z'%20fill='url(%23ev-lining)'/%3e%3cpath%20d='M249%20748%20C220%20818%20204%20867%20205%20943%20L221%201080%20L299%201080%20L299%20939%20L323%20789Z'%20fill='url(%23ev-skin)'/%3e%3cpath%20d='M323%20780%20C331%20847%20350%20907%20355%20944%20L354%201080%20L440%201080%20L433%20932%20C432%20863%20415%20801%20393%20753Z'%20fill='url(%23ev-skin)'/%3e%3cpath%20d='M211%20932%20Q251%20948%20298%20931%20L299%201080%20L221%201080Z%20M354%20937%20Q391%20959%20435%20942%20L440%201080%20L354%201080Z'%20fill='url(%23ev-boot)'/%3e%3cpath%20d='M216%20950%20Q253%20964%20297%20949%20M357%20956%20Q395%20976%20436%20958'%20fill='none'%20stroke='%23ae6e89'%20stroke-width='5'/%3e%3cpath%20d='M232%20971%20L242%201060%20M370%20978%20L383%201060'%20stroke='%23777386'%20opacity='.45'%20stroke-width='6'/%3e%3c!--%20Saluting%20arm,%20flared%20sleeve%20and%20shoulder.%20--%3e%3cpath%20d='M242%20353%20C206%20340%20182%20318%20156%20279%20L135%20217%20L93%20234%20C90%20314%20102%20392%20160%20459%20L222%20477Z'%20fill='url(%23ev-coat)'/%3e%3cpath%20d='M100%20250%20L111%20298%20L160%20280%20L139%20236Z'%20fill='%2361354f'/%3e%3cpath%20d='M119%20314%20C128%20366%20144%20393%20185%20410%20L168%20443%20C131%20413%20104%20376%2098%20329Z'%20fill='%23775069'%20stroke='none'/%3e%3cpath%20d='M117%20280%20L151%20266%20M124%20296%20L158%20283'%20fill='none'%20stroke='%23d1a772'%20stroke-width='5'/%3e%3cpath%20d='M109%20220%20L107%20200%20Q109%20181%20127%20166%20L167%20136%20Q178%20128%20184%20137%20Q186%20144%20176%20151%20L150%20174%20L177%20165%20L205%20161%20Q213%20161%20212%20169%20Q211%20174%20202%20178%20L172%20187%20L162%20205%20L148%20223%20L145%20240%20L113%20247Z'%20fill='url(%23ev-skin)'/%3e%3cpath%20d='M112%20207%20Q119%20190%20132%20190%20L150%20195%20L145%20220%20L145%20237%20L113%20246Z'%20fill='%23343146'/%3e%3cpath%20d='M129%20180%20L142%20176%20M145%20181%20L166%20171%20M152%20189%20L173%20184'%20fill='none'%20stroke='%23b16e81'%20stroke-width='1.7'/%3e%3cpath%20d='M120%20214%20L135%20207%20L140%20217%20L128%20226Z'%20fill='%23c45b6d'/%3e%3c!--%20Far%20arm%20at%20the%20hip.%20--%3e%3cpath%20d='M383%20352%20C431%20339%20467%20373%20500%20423%20L543%20501%20Q551%20524%20532%20548%20L454%20620%20L410%20590%20L473%20504%20L424%20460%20L393%20450Z'%20fill='url(%23ev-coat)'/%3e%3cpath%20d='M444%20397%20Q472%20423%20499%20458%20L479%20488%20L449%20452Z%20M516%20492%20L502%20522%20L447%20573%20L463%20592%20L529%20538%20Q540%20527%20533%20509Z'%20fill='%234d3451'%20stroke='none'/%3e%3cpath%20d='M464%20573%20L439%20605%20L412%20582%20L432%20550Z'%20fill='%23684257'/%3e%3cpath%20d='M455%20584%20L433%20611%20M448%20579%20L426%20603'%20stroke='%23d1a772'%20stroke-width='4'/%3e%3cpath%20d='M435%20606%20L422%20630%20Q416%20639%20408%20635%20L395%20613%20L391%20592%20L401%20576%20Q407%20571%20412%20579%20L416%20589%20L427%20588Z'%20fill='url(%23ev-skin)'/%3e%3cpath%20d='M405%20591%20L412%20612%20M412%20589%20L420%20606%20M398%20598%20L405%20618'%20stroke='%23b16e81'%20stroke-width='1.7'%20fill='none'/%3e%3c!--%20Jacket%20and%20uniform.%20--%3e%3cpath%20d='M242%20335%20Q268%20316%20307%20321%20Q351%20311%20390%20346%20L414%20461%20L409%20596%20L448%20737%20Q400%20781%20351%20777%20L271%20774%20L201%20744%20L219%20594%20L207%20441Z'%20fill='url(%23ev-coat)'/%3e%3cpath%20d='M248%20353%20Q305%20347%20371%20346%20L389%20452%20L368%20570%20L394%20724%20Q328%20765%20242%20721%20L259%20573%20L236%20452Z'%20fill='url(%23ev-uniform)'/%3e%3cpath%20d='M247%20403%20Q280%20407%20307%20444%20L317%20549%20L277%20572%20L258%20529Z%20M356%20402%20L379%20445%20L357%20535%20L326%20548%20L326%20442Z'%20fill='%2378917a'%20stroke='none'/%3e%3cpath%20d='M263%20476%20L301%20486%20L300%20526%20L269%20523Z%20M337%20482%20L368%20470%20L363%20512%20L336%20524Z'%20fill='%23405d54'%20stroke='%2398aa89'%20stroke-width='1.6'/%3e%3cpath%20d='M264%20479%20L300%20489%20L288%20500%20L268%20495Z%20M338%20484%20L368%20473%20L361%20488%20L339%20497Z'%20fill='%2381977b'%20stroke='none'/%3e%3cpath%20d='M264%20555%20L312%20566%20L319%20616%20L264%20630%20M360%20544%20L325%20561%20L321%20615%20L373%20628'%20fill='none'%20stroke='%23a6b395'%20stroke-width='1.4'/%3e%3cpath%20d='M274%20607%20L293%20644%20L275%20677%20L253%20670%20M352%20608%20L340%20644%20L374%20686'%20fill='none'%20stroke='%23263f40'%20stroke-width='8'%20opacity='.7'/%3e%3cpath%20d='M250%20330%20L224%20365%20L211%20445%20L233%20487%20L254%20421%20L266%20385%20L284%20364Z%20M372%20331%20L394%20356%20L406%20443%20L383%20486%20L357%20395%20L336%20362Z'%20fill='url(%23ev-lining)'/%3e%3cpath%20d='M250%20330%20L224%20365%20L235%20420%20L264%20379%20M372%20331%20L394%20356%20L382%20418%20L357%20380'%20fill='none'%20stroke='%23e5ad8f'%20stroke-width='3'/%3e%3cpath%20d='M242%20719%20L268%20774%20L349%20788%20L395%20723%20L349%20736%20L289%20742Z'%20fill='%23476254'/%3e%3cpath%20d='M253%20732%20L267%20761%20L302%20771%20L305%20743%20M336%20744%20L337%20776%20L367%20762%20L380%20737'%20fill='none'%20stroke='%238ca38b'%20stroke-width='2'/%3e%3cpath%20d='M244%20697%20Q312%20723%20387%20695%20L395%20716%20Q318%20747%20241%20720Z'%20fill='%232b2b3b'/%3e%3cpath%20d='M302%20709%20L340%20709%20L340%20733%20L302%20733Z'%20fill='%23b89770'/%3e%3cpath%20d='M310%20715%20L332%20715%20L332%20727%20L310%20727Z'%20fill='%2345413f'%20stroke-width='1.5'/%3e%3cpath%20d='M245%20690%20L257%20695%20L251%20731%20L239%20727%20M366%20701%20L378%20698%20L386%20724%20L375%20728'%20fill='%2366806a'%20stroke-width='1.5'/%3e%3c!--%20Collar%20and%20fur:%20broken%20outlines%20rather%20than%20a%20smooth%20white%20collar.%20--%3e%3cpath%20d='M273%20292%20L276%20337%20L301%20365%20L339%20335%20L338%20287Z'%20fill='url(%23ev-skin)'/%3e%3cpath%20d='M278%20303%20L279%20328%20L303%20346%20L334%20316%20L335%20298Z'%20fill='%23cf8590'%20stroke='none'/%3e%3cpath%20d='M273%20326%20L295%20351%20L281%20391%20L253%20355Z%20M339%20321%20L312%20349%20L332%20388%20L365%20351Z'%20fill='%23aab49b'/%3e%3cpath%20d='M295%20351%20L312%20349%20L325%20365%20L309%20389%20L290%20367Z'%20fill='%23a63750'/%3e%3cpath%20d='M307%20369%20L323%20386%20L317%20420%20L300%20438%20L288%20418%20L294%20384Z'%20fill='%239a3d56'/%3e%3cpath%20d='M303%20383%20L311%20413%20L302%20430'%20fill='none'%20stroke='%23d0656c'%20stroke-width='3'/%3e%3cpath%20d='M251%20331%20L238%20332%20L235%20345%20L226%20342%20L220%20356%20L210%20357%20L210%20371%20L201%20370%20L207%20385%20L201%20392%20L215%20400%20L212%20413%20L225%20414%20L224%20430%20L236%20421%20L241%20435%20L250%20419%20L258%20421%20L257%20400%20L266%20389%20L258%20379%20L265%20367%20L255%20360%20L260%20346Z'%20fill='url(%23ev-fur)'/%3e%3cpath%20d='M371%20326%20L384%20330%20L384%20343%20L397%20344%20L395%20358%20L407%20364%20L401%20377%20L412%20385%20L402%20396%20L407%20410%20L392%20411%20L386%20430%20L378%20418%20L365%20425%20L365%20407%20L355%20405%20L362%20390%20L352%20379%20L362%20370%20L355%20357%20L367%20350Z'%20fill='url(%23ev-fur)'/%3e%3cpath%20d='M232%20351%20L240%20361%20L230%20378%20M218%20371%20L225%20385%20L219%20397%20M248%20376%20L242%20400%20M379%20348%20L371%20366%20L382%20378%20M397%20376%20L388%20390%20L390%20405'%20fill='none'%20stroke='%23aaabb0'%20stroke-width='1.3'/%3e%3c!--%20Face%20with%20two%20separately%20shaped%20eyes,%20nose,%20asymmetric%20smile%20and%20hair%20shadows.%20--%3e%3cpath%20d='M240%20209%20C230%20197%20224%20211%20227%20229%20Q229%20245%20244%20248%20L246%20268%20Q258%20298%20291%20315%20Q303%20321%20316%20314%20Q347%20303%20363%20278%20Q375%20252%20369%20211%20L353%20169%20L281%20163Z'%20fill='url(%23ev-skin)'/%3e%3cpath%20d='M243%20206%20L254%20219%20L261%20246%20L271%20251%20L264%20266%20L277%20298%20Q252%20283%20247%20267Z%20M347%20207%20L355%20238%20L353%20268%20L335%20295%20Q356%20288%20364%20270%20L370%20224Z'%20fill='%23e49b9d'%20stroke='none'/%3e%3cpath%20d='M231%20217%20L240%20213%20L241%20231%20L233%20229'%20fill='none'%20stroke='%23bf7d8e'%20stroke-width='1.5'/%3e%3cpath%20d='M257%20238%20Q277%20220%20300%20236%20Q282%20252%20260%20248Z'%20fill='%23fff5e9'%20stroke='none'/%3e%3cg%20clip-path='url(%23ev-eye-a)'%3e%3cellipse%20cx='279'%20cy='237'%20rx='11'%20ry='17'%20fill='url(%23ev-iris)'%20stroke='%233b6961'%20stroke-width='1.2'/%3e%3cellipse%20cx='280'%20cy='233'%20rx='3.4'%20ry='8.5'%20fill='%23284a51'%20stroke='none'/%3e%3cellipse%20cx='275'%20cy='229'%20rx='4.2'%20ry='3'%20fill='%23fffced'%20stroke='none'/%3e%3cpath%20d='M272%20247%20L280%20243%20L286%20245'%20fill='none'%20stroke='%23edffb8'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M323%20234%20Q340%20215%20361%20225%20Q350%20244%20328%20245Z'%20fill='%23fff5e9'%20stroke='none'/%3e%3cg%20clip-path='url(%23ev-eye-b)'%3e%3cellipse%20cx='342'%20cy='230'%20rx='10'%20ry='17'%20fill='url(%23ev-iris)'%20stroke='%233b6961'%20stroke-width='1.2'/%3e%3cellipse%20cx='343'%20cy='226'%20rx='3.2'%20ry='8'%20fill='%23284a51'%20stroke='none'/%3e%3cellipse%20cx='338'%20cy='221'%20rx='4'%20ry='3'%20fill='%23fffced'%20stroke='none'/%3e%3cpath%20d='M337%20240%20L343%20236%20L348%20238'%20fill='none'%20stroke='%23edffb8'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M255%20236%20Q276%20220%20300%20235%20M323%20233%20Q341%20214%20362%20225'%20fill='none'%20stroke='%23432a40'%20stroke-width='4'/%3e%3cpath%20d='M257%20237%20L250%20231%20M259%20235%20L254%20228%20M357%20224%20L364%20218%20M360%20226%20L367%20222'%20fill='none'%20stroke='%23432a40'%20stroke-width='2.4'/%3e%3cpath%20d='M263%20249%20Q280%20253%20295%20243%20M329%20245%20Q344%20245%20353%20237'%20fill='none'%20stroke='%23a85c75'%20stroke-width='1.3'/%3e%3cpath%20d='M261%20218%20Q277%20210%20293%20218%20M326%20214%20Q339%20204%20354%20211'%20fill='none'%20stroke='%239b435d'%20stroke-width='3'/%3e%3cpath%20d='M310%20240%20L304%20261%20L310%20264'%20fill='none'%20stroke='%23ba7383'%20stroke-width='1.8'/%3e%3cpath%20d='M302%20259%20L307%20257'%20fill='none'%20stroke='%23fff0d9'%20stroke-width='3'/%3e%3cpath%20d='M281%20279%20Q306%20291%20331%20272%20Q316%20299%20297%20292Z'%20fill='%23954457'%20stroke-width='1.4'/%3e%3cpath%20d='M285%20281%20Q308%20289%20327%20276%20L318%20285%20Q301%20290%20289%20285Z'%20fill='%23fff4df'%20stroke='none'/%3e%3cpath%20d='M301%20302%20L311%20301'%20fill='none'%20stroke='%23c9828d'%20stroke-width='1.5'/%3e%3cpath%20d='M258%20263%20L263%20258%20M264%20265%20L269%20260%20M345%20255%20L350%20250'%20fill='none'%20stroke='%23e58d97'%20stroke-width='2'/%3e%3c!--%20Front%20locks%20are%20individually%20shaped%20and%20break%20the%20silhouette.%20--%3e%3cpath%20d='M231%20165%20Q263%20113%20322%20135%20Q378%20145%20386%20202%20L378%20260%20L364%20288%20L364%20231%20Q346%20217%20335%20194%20L341%20223%20Q318%20215%20309%20186%20L313%20225%20Q289%20213%20282%20189%20L278%20227%20Q260%20218%20252%20200%20L243%20259%20L231%20286%20Q229%20255%20222%20234%20Q216%20201%20231%20165Z'%20fill='url(%23ev-hair-light)'/%3e%3cpath%20d='M250%20177%20L240%20229%20L234%20251%20M271%20162%20L263%20199%20L275%20215%20M296%20152%20L288%20179%20L302%20207%20M320%20151%20L315%20171%20L332%20210%20M344%20163%20L340%20183%20L356%20215'%20fill='none'%20stroke='%23ffcf9b'%20stroke-width='3'/%3e%3cpath%20d='M229%20220%20Q214%20269%20219%20316%20C230%20351%20218%20405%20188%20444%20C220%20436%20250%20400%20252%20361%20L259%20310%20L245%20280Z'%20fill='url(%23ev-hair-light)'/%3e%3cpath%20d='M233%20270%20Q226%20319%20233%20348%20L213%20409'%20fill='none'%20stroke='%23ffd1a2'%20stroke-width='4'/%3e%3cpath%20d='M365%20214%20Q403%20247%20391%20317%20C381%20376%20423%20410%20453%20461%20Q424%20456%20405%20434%20C434%20511%20471%20526%20502%20551%20C424%20546%20388%20487%20381%20439%20C364%20377%20341%20350%20355%20307%20L364%20277Z'%20fill='url(%23ev-hair)'/%3e%3cpath%20d='M375%20242%20Q389%20285%20372%20329%20C360%20376%20400%20418%20412%20463%20M383%20364%20Q393%20410%20438%20448'%20fill='none'%20stroke='%23ffc395'%20stroke-width='4'/%3e%3cpath%20d='M247%20310%20C253%20417%20202%20515%20184%20582%20Q177%20614%20184%20647%20C204%20620%20224%20603%20235%20573%20C219%20650%20242%20697%20211%20754%20C275%20707%20284%20621%20265%20556%20C266%20473%20292%20412%20274%20348Z'%20fill='url(%23ev-hair-light)'/%3e%3cpath%20d='M258%20379%20C267%20475%20220%20533%20210%20594%20M247%20518%20C235%20597%20260%20666%20229%20711'%20fill='none'%20stroke='%23ffd0a0'%20stroke-width='3'/%3e%3c!--%20Soft%20military%20beret,%20tilted%20brim,%20enamel%20star.%20--%3e%3cpath%20d='M214%20161%20Q203%20139%20223%20115%20Q242%2087%20276%2086%20Q331%2058%20370%2084%20Q404%20111%20397%20149%20L382%20171%20L269%20180Z'%20fill='url(%23ev-coat)'/%3e%3cpath%20d='M219%20141%20Q233%20106%20271%20105%20Q312%2076%20354%2088%20Q309%2099%20301%20137%20L252%20151Z'%20fill='%23654055'%20stroke='none'/%3e%3cpath%20d='M307%2089%20Q337%2074%20365%2091%20L386%20121%20L375%20151%20L302%20160Z'%20fill='%2326283c'%20stroke='none'/%3e%3cpath%20d='M215%20158%20Q295%20133%20392%20149%20L383%20176%20Q300%20157%20228%20185Z'%20fill='%2332283b'/%3e%3cpath%20d='M225%20169%20Q304%20147%20383%20160'%20fill='none'%20stroke='%23ad6b7d'%20stroke-width='2'/%3e%3ccircle%20cx='264'%20cy='132'%20r='18'%20fill='%23a74759'%20stroke='%23c89d73'%20stroke-width='2'/%3e%3cpath%20d='M264%20117%20L268%20127%20L279%20127%20L270%20134%20L274%20145%20L264%20138%20L255%20145%20L258%20134%20L249%20127%20L260%20127Z'%20fill='%23e4b87c'%20stroke='none'/%3e%3cpath%20d='M260%20128%20L263%20123%20L264%20132%20L269%20136'%20fill='none'%20stroke='%23fff0b6'%20stroke-width='1.3'/%3e%3c!--%20Small%20material%20seams%20and%20cool%20edge%20light.%20--%3e%3cpath%20d='M202%20486%20L213%20581%20L194%20706%20M418%20461%20L418%20562%20M119%20331%20Q118%20373%20149%20399%20M384%20105%20Q397%20123%20389%20143%20M242%20174%20Q228%20217%20229%20239%20M494%20439%20L524%20495'%20fill='none'%20stroke='%236dd4d5'%20stroke-width='2.6'%20opacity='.7'/%3e%3cpath%20d='M234%20488%20L226%20574%20L230%20646%20M400%20492%20L394%20568%20L418%20682'%20fill='none'%20stroke='%23b66e85'%20stroke-width='1.4'/%3e%3ccircle%20cx='317'%20cy='473'%20r='3'%20fill='%23d7bc89'%20stroke='none'/%3e%3ccircle%20cx='320'%20cy='538'%20r='3'%20fill='%23d7bc89'%20stroke='none'/%3e%3ccircle%20cx='320'%20cy='592'%20r='3'%20fill='%23d7bc89'%20stroke='none'/%3e%3c/g%3e%3c/symbol%3e%3csymbol%20id='hero-mariel'%20viewBox='0%200%20620%201080'%3e%3cdefs%3e%3clinearGradient%20id='mariel-hair'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23ffad87'/%3e%3cstop%20offset='1'%20stop-color='%23ae4e75'/%3e%3c/linearGradient%3e%3clinearGradient%20id='mariel-cloth'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23ded6e9'/%3e%3cstop%20offset='1'%20stop-color='%236e5890'/%3e%3c/linearGradient%3e%3clinearGradient%20id='mariel-skin'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23ffe0c8'/%3e%3cstop%20offset='1'%20stop-color='%23dc98a2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='mariel-iris'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%236e5890'/%3e%3cstop%20offset='1'%20stop-color='%236d89b1'/%3e%3c/linearGradient%3e%3c/defs%3e%3cg%20stroke='%2332293f'%20stroke-width='2.1'%20stroke-linejoin='round'%20stroke-linecap='round'%3e%3cpath%20d='M218%20160Q169%20241%20188%20321L161%20403L231%20357L257%20209Z%20M362%20168Q422%20213%20409%20302L438%20365L368%20340L345%20210Z'%20fill='url(%23mariel-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='mariel-detail-0'%3e%3cpath%20d='M218%20160Q169%20241%20188%20321L161%20403L231%20357L257%20209Z%20M362%20168Q422%20213%20409%20302L438%20365L368%20340L345%20210Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23mariel-detail-0)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%23ae4e75'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%23ffad87'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%23ae4e75'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%23ae4e75'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M244%20705L210%20943L220%201080H294L318%20834L343%20978L361%201080H440L410%20739Z'%20fill='url(%23mariel-cloth)'%20/%3e%3cdefs%3e%3cclipPath%20id='mariel-detail-1'%3e%3cpath%20d='M244%20705L210%20943L220%201080H294L318%20834L343%20978L361%201080H440L410%20739Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23mariel-detail-1)'%3e%3cpath%20d='M207%20378L227%20431L206%20491L211%20554L197%20600L183%20689L173%20755L153%20747L177%20539Z%20M396%20378L412%20409L399%20472L418%20541L425%20628L455%20757L432%20770L410%20666L389%20570L392%20495Z'%20fill='%236e5890'%20stroke='none'%20opacity='.42'/%3e%3cpath%20d='M226%20381L211%20446L218%20503L208%20540L211%20471L229%20408Z%20M390%20393L403%20439L398%20476L389%20448Z%20M212%20575L199%20715L192%20740L204%20640Z'%20fill='%23ded6e9'%20stroke='none'%20opacity='.8'/%3e%3cpath%20d='M215%20418Q200%20451%20208%20486L200%20514M399%20421L409%20451L403%20481M231%20523L216%20553L207%20592M382%20525L401%20558L409%20603M233%20657L208%20728L196%20784M375%20649L408%20725L425%20784'%20fill='none'%20stroke='%236e5890'%20stroke-width='2'/%3e%3cpath%20d='M216%20430L211%20470M206%20587L193%20701M410%20589L431%20703M230%20748L241%20780M385%20747L393%20780'%20fill='none'%20stroke='%23ded6e9'%20stroke-width='2.3'/%3e%3cpath%20d='M260%20822Q244%20915%20250%201005M358%20836L386%201019'%20fill='none'%20stroke='%23ded6e9'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M275%20786L249%20984M368%20784L389%201018'%20fill='none'%20stroke='%23ae4e75'%20stroke-width='5'/%3e%3cpath%20d='M239%20687L218%20950L256%20985L290%20779L329%20864L347%201033L408%201057L396%20719Z'%20fill='%233e385b'%20/%3e%3cpath%20d='M254%20350L207%20374L179%20508L135%20863L202%20905L267%20603L323%20588L388%20925L458%20888L417%20589L393%20361L348%20340Z'%20fill='url(%23mariel-cloth)'%20/%3e%3cdefs%3e%3cclipPath%20id='mariel-detail-2'%3e%3cpath%20d='M254%20350L207%20374L179%20508L135%20863L202%20905L267%20603L323%20588L388%20925L458%20888L417%20589L393%20361L348%20340Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23mariel-detail-2)'%3e%3cpath%20d='M207%20378L227%20431L206%20491L211%20554L197%20600L183%20689L173%20755L153%20747L177%20539Z%20M396%20378L412%20409L399%20472L418%20541L425%20628L455%20757L432%20770L410%20666L389%20570L392%20495Z'%20fill='%236e5890'%20stroke='none'%20opacity='.42'/%3e%3cpath%20d='M226%20381L211%20446L218%20503L208%20540L211%20471L229%20408Z%20M390%20393L403%20439L398%20476L389%20448Z%20M212%20575L199%20715L192%20740L204%20640Z'%20fill='%23ded6e9'%20stroke='none'%20opacity='.8'/%3e%3cpath%20d='M215%20418Q200%20451%20208%20486L200%20514M399%20421L409%20451L403%20481M231%20523L216%20553L207%20592M382%20525L401%20558L409%20603M233%20657L208%20728L196%20784M375%20649L408%20725L425%20784'%20fill='none'%20stroke='%236e5890'%20stroke-width='2'/%3e%3cpath%20d='M216%20430L211%20470M206%20587L193%20701M410%20589L431%20703M230%20748L241%20780M385%20747L393%20780'%20fill='none'%20stroke='%23ded6e9'%20stroke-width='2.3'/%3e%3cpath%20d='M260%20822Q244%20915%20250%201005M358%20836L386%201019'%20fill='none'%20stroke='%23ded6e9'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M254%20363L239%20461L271%20487L262%20562L317%20583L356%20555L345%20480L376%20439L347%20359Z'%20fill='%23d6b0d1'%20/%3e%3cpath%20d='M256%20369L239%20445L265%20469L291%20417L309%20447L337%20420L355%20464L376%20440L349%20359L308%20393Z'%20fill='%23f5e9ec'%20/%3e%3cpath%20d='M270%20487L301%20511L322%20487L347%20499L346%20548L315%20568L271%20552Z'%20fill='%23f6d7c2'%20/%3e%3cpath%20d='M223%20383L191%20444L172%20555L155%20637L186%20655L225%20556L253%20414Z'%20fill='%23eee2ec'%20/%3e%3cpath%20d='M156%20629L181%20639L176%20682L157%20711L147%20703L152%20677L140%20688L133%20680L146%20657Z'%20fill='url(%23mariel-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='mariel-detail-3'%3e%3cpath%20d='M156%20629L181%20639L176%20682L157%20711L147%20703L152%20677L140%20688L133%20680L146%20657Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23mariel-detail-3)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M366%20358Q399%20337%20417%20288L409%20207L377%20204L382%20281L347%20332Z'%20fill='%23f0e0e8'%20/%3e%3cpath%20d='M378%20209L369%20181L335%20142L320%20116Q321%20106%20329%20109L348%20130L342%20108Q344%20101%20350%20106L372%20135L396%20178L406%20205Z'%20fill='url(%23mariel-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='mariel-detail-4'%3e%3cpath%20d='M378%20209L369%20181L335%20142L320%20116Q321%20106%20329%20109L348%20130L342%20108Q344%20101%20350%20106L372%20135L396%20178L406%20205Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23mariel-detail-4)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cg%20transform='rotate(3%20310%20258)'%3e%3cpath%20d='M269%20291L267%20352L309%20379L354%20348L347%20287Z'%20fill='%23ffdbc4'%20/%3e%3cpath%20d='M271%20300L274%20328L311%20348L346%20320L345%20292Z'%20fill='%23dc929a'%20stroke='none'/%3e%3cpath%20d='M237%20199Q224%20195%20227%20222Q228%20244%20246%20247L251%20273Q268%20307%20303%20321Q316%20325%20331%20315Q365%20298%20377%20270L382%20205L355%20157L277%20157Z'%20fill='%23ffdbc4'%20/%3e%3cpath%20d='M241%20204L253%20220L259%20256L280%20298L300%20317Q265%20306%20251%20276Z%20M365%20203L370%20240L365%20273L344%20300Q371%20286%20379%20267L382%20210Z'%20fill='%23dc929a'%20stroke='none'/%3e%3cpath%20d='M233%20211L241%20216L241%20232'%20fill='none'%20stroke='%23b77d8d'%20stroke-width='1.5'/%3e%3cdefs%3e%3cclipPath%20id='mariel-eye-277'%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23mariel-eye-277)'%3e%3cellipse%20cx='279'%20cy='238'%20rx='11'%20ry='16'%20fill='url(%23mariel-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='280'%20cy='234'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='275'%20cy='231'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M274%20248l8-3'%20fill='none'%20stroke='%236d89b1'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M254%20238Q275%20218%20299%20234'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M256%20237l-5-6M259%20234l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M261%20217q13-9%2028-3'%20fill='none'%20stroke='%23ae4e75'%20stroke-width='3'/%3e%3cdefs%3e%3cclipPath%20id='mariel-eye-341'%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23mariel-eye-341)'%3e%3cellipse%20cx='343'%20cy='235'%20rx='11'%20ry='16'%20fill='url(%23mariel-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='344'%20cy='231'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='339'%20cy='228'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M338%20245l8-3'%20fill='none'%20stroke='%236d89b1'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M318%20235Q339%20214%20363%20231'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M320%20234l-5-6M323%20231l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M325%20214q13-9%2028-3'%20fill='none'%20stroke='%23ae4e75'%20stroke-width='3'/%3e%3cpath%20d='M313%20240L305%20261L312%20264'%20fill='none'%20stroke='%23b87683'%20stroke-width='1.6'/%3e%3cpath%20d='M304%20260l4-3'%20fill='none'%20stroke='%23fff2d7'%20stroke-width='2.5'/%3e%3cpath%20d='M292%20286Q311%20280%20328%20284'%20fill='none'%20stroke='%23925265'%20stroke-width='2'/%3e%3cpath%20d='M241%20224Q250%20211%20263%20216L253%20235Z%20M356%20210Q374%20208%20378%20220L369%20239Z'%20fill='%23be7c89'%20stroke='none'%20opacity='.2'/%3e%3cpath%20d='M269%20271Q278%20277%20287%20273L286%20281Q276%20284%20267%20279Z%20M340%20267Q348%20270%20357%20266L356%20273Q346%20278%20339%20274Z'%20fill='%23f29c9d'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M262%20263l4-6M269%20266l4-6M276%20267l4-5M343%20261l4-6M350%20261l4-5'%20fill='none'%20stroke='%23d28a96'%20stroke-width='1.2'/%3e%3cpath%20d='M262%20253Q278%20259%20289%20251M330%20249Q346%20254%20357%20246'%20fill='none'%20stroke='%23bd8595'%20stroke-width='1'/%3e%3cpath%20d='M288%20303Q305%20313%20322%20303'%20fill='none'%20stroke='%23f8e2cd'%20stroke-width='2'/%3e%3cpath%20d='M286%20294q11%207%2020%204'%20fill='none'%20stroke='%23bd808d'%20stroke-width='0.9'/%3e%3c/g%3e%3cpath%20d='M233%20166Q278%20123%20339%20150Q384%20163%20388%20215L369%20275L364%20223L348%20195L348%20230L322%20205L314%20178L305%20230L279%20207L268%20184L255%20230L243%20276L226%20250Z'%20fill='url(%23mariel-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='mariel-detail-5'%3e%3cpath%20d='M233%20166Q278%20123%20339%20150Q384%20163%20388%20215L369%20275L364%20223L348%20195L348%20230L322%20205L314%20178L305%20230L279%20207L268%20184L255%20230L243%20276L226%20250Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23mariel-detail-5)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%23ae4e75'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%23ffad87'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%23ae4e75'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%23ae4e75'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M247%20182L238%20236M276%20162L272%20200M308%20162L302%20208M339%20172L344%20205'%20fill='none'%20stroke='%23ffcd9e'%20stroke-width='3'/%3e%3cpath%20d='M232%20155L215%20102L259%20118L279%2049L316%20109L365%2084L352%20152L300%20173Z'%20fill='%23b0b0de'%20/%3e%3cpath%20d='M215%20102L275%20145L279%2049L299%20140L365%2084L328%20157Z'%20fill='%23e1cbe4'%20stroke-width='1.4'/%3e%3cpath%20d='M241%20563L273%20590L321%20584L364%20567L375%20590L319%20620L254%20616Z'%20fill='%23a06c9b'%20/%3e%3cpath%20d='M209%20451L176%20725M379%20389L401%20714M225%20714L204%20839'%20fill='none'%20stroke='%23a2cfd4'%20stroke-width='3'/%3e%3cpath%20d='M128%20518L230%20459L275%20654L189%20607Z'%20fill='%23f7efe7'%20/%3e%3cpath%20d='M128%20518L209%20550L275%20654L189%20607Z'%20fill='%23b6bbdd'%20/%3e%3cpath%20d='M128%20518L209%20550L230%20459'%20fill='none'%20stroke='%23fff8eb'%20stroke-width='2'/%3e%3c/g%3e%3c/symbol%3e%3csymbol%20id='hero-adelheid'%20viewBox='0%200%20620%201080'%3e%3cdefs%3e%3clinearGradient%20id='adelheid-hair'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%234d405f'/%3e%3cstop%20offset='1'%20stop-color='%231f233a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='adelheid-cloth'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%239f3a55'/%3e%3cstop%20offset='1'%20stop-color='%23e6c19a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='adelheid-skin'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23ffe0c8'/%3e%3cstop%20offset='1'%20stop-color='%23dc98a2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='adelheid-iris'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23e6c19a'/%3e%3cstop%20offset='1'%20stop-color='%23d86284'/%3e%3c/linearGradient%3e%3c/defs%3e%3cg%20stroke='%2332293f'%20stroke-width='2.1'%20stroke-linejoin='round'%20stroke-linecap='round'%3e%3cpath%20d='M232%20155Q175%20226%20205%20345L170%20424L232%20393L272%20225L352%20206L394%20372L429%20395L403%20255Q406%20139%20307%20121Z'%20fill='url(%23adelheid-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='adelheid-detail-0'%3e%3cpath%20d='M232%20155Q175%20226%20205%20345L170%20424L232%20393L272%20225L352%20206L394%20372L429%20395L403%20255Q406%20139%20307%20121Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23adelheid-detail-0)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%231f233a'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%234d405f'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%231f233a'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%231f233a'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M244%20705L210%20943L220%201080H294L318%20834L343%20978L361%201080H440L410%20739Z'%20fill='url(%23adelheid-cloth)'%20/%3e%3cdefs%3e%3cclipPath%20id='adelheid-detail-1'%3e%3cpath%20d='M244%20705L210%20943L220%201080H294L318%20834L343%20978L361%201080H440L410%20739Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23adelheid-detail-1)'%3e%3cpath%20d='M207%20378L227%20431L206%20491L211%20554L197%20600L183%20689L173%20755L153%20747L177%20539Z%20M396%20378L412%20409L399%20472L418%20541L425%20628L455%20757L432%20770L410%20666L389%20570L392%20495Z'%20fill='%23e6c19a'%20stroke='none'%20opacity='.42'/%3e%3cpath%20d='M226%20381L211%20446L218%20503L208%20540L211%20471L229%20408Z%20M390%20393L403%20439L398%20476L389%20448Z%20M212%20575L199%20715L192%20740L204%20640Z'%20fill='%239f3a55'%20stroke='none'%20opacity='.8'/%3e%3cpath%20d='M215%20418Q200%20451%20208%20486L200%20514M399%20421L409%20451L403%20481M231%20523L216%20553L207%20592M382%20525L401%20558L409%20603M233%20657L208%20728L196%20784M375%20649L408%20725L425%20784'%20fill='none'%20stroke='%23e6c19a'%20stroke-width='2'/%3e%3cpath%20d='M216%20430L211%20470M206%20587L193%20701M410%20589L431%20703M230%20748L241%20780M385%20747L393%20780'%20fill='none'%20stroke='%239f3a55'%20stroke-width='2.3'/%3e%3cpath%20d='M260%20822Q244%20915%20250%201005M358%20836L386%201019'%20fill='none'%20stroke='%239f3a55'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M275%20786L249%20984M368%20784L389%201018'%20fill='none'%20stroke='%231f233a'%20stroke-width='5'/%3e%3cpath%20d='M227%20394L178%20416L166%20587L114%20810L212%20886L286%20716L369%20731L432%20875L503%20819L430%20601L431%20404L351%20355Z'%20fill='url(%23adelheid-cloth)'%20/%3e%3cdefs%3e%3cclipPath%20id='adelheid-detail-2'%3e%3cpath%20d='M227%20394L178%20416L166%20587L114%20810L212%20886L286%20716L369%20731L432%20875L503%20819L430%20601L431%20404L351%20355Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23adelheid-detail-2)'%3e%3cpath%20d='M207%20378L227%20431L206%20491L211%20554L197%20600L183%20689L173%20755L153%20747L177%20539Z%20M396%20378L412%20409L399%20472L418%20541L425%20628L455%20757L432%20770L410%20666L389%20570L392%20495Z'%20fill='%23e6c19a'%20stroke='none'%20opacity='.42'/%3e%3cpath%20d='M226%20381L211%20446L218%20503L208%20540L211%20471L229%20408Z%20M390%20393L403%20439L398%20476L389%20448Z%20M212%20575L199%20715L192%20740L204%20640Z'%20fill='%239f3a55'%20stroke='none'%20opacity='.8'/%3e%3cpath%20d='M215%20418Q200%20451%20208%20486L200%20514M399%20421L409%20451L403%20481M231%20523L216%20553L207%20592M382%20525L401%20558L409%20603M233%20657L208%20728L196%20784M375%20649L408%20725L425%20784'%20fill='none'%20stroke='%23e6c19a'%20stroke-width='2'/%3e%3cpath%20d='M216%20430L211%20470M206%20587L193%20701M410%20589L431%20703M230%20748L241%20780M385%20747L393%20780'%20fill='none'%20stroke='%239f3a55'%20stroke-width='2.3'/%3e%3cpath%20d='M260%20822Q244%20915%20250%201005M358%20836L386%201019'%20fill='none'%20stroke='%239f3a55'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M184%20568L135%20793L189%20840L262%20653L279%20435L251%20377L221%20441Z%20M367%20386L409%20423L413%20600L478%20793L435%20834L346%20661Z'%20fill='%23b74958'%20/%3e%3cpath%20d='M263%20360L248%20482L284%20579L346%20579L371%20465L349%20353L309%20380Z'%20fill='%23f3eee1'%20/%3e%3cpath%20d='M282%20557L349%20557L379%20694L336%20741L260%20709L245%20649Z'%20fill='%2324283c'%20/%3e%3cpath%20d='M273%20589L295%20676L276%20707M341%20590L329%20689L352%20722'%20fill='none'%20stroke='%23725875'%20stroke-width='3'/%3e%3cpath%20d='M228%20375L186%20363L146%20392L123%20367L89%20392L132%20454Q152%20479%20179%20457L233%20425Z'%20fill='%23a94457'%20/%3e%3cpath%20d='M126%20368L113%20339L105%20297L94%20280L84%20283L89%20311L74%20287L64%20291L79%20324L65%20308L57%20314L84%20348L93%20389Z'%20fill='url(%23adelheid-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='adelheid-detail-3'%3e%3cpath%20d='M126%20368L113%20339L105%20297L94%20280L84%20283L89%20311L74%20287L64%20291L79%20324L65%20308L57%20314L84%20348L93%20389Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23adelheid-detail-3)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M375%20365L414%20367L450%20406L487%20359L521%20382L478%20471Q456%20499%20431%20480L385%20437Z'%20fill='%23903c54'%20/%3e%3cpath%20d='M489%20363L484%20335L492%20305L485%20279Q487%20270%20494%20278L506%20300L512%20279L521%20254Q530%20250%20527%20263L521%20296L538%20281Q548%20281%20544%20290L522%20313L520%20380Z'%20fill='url(%23adelheid-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='adelheid-detail-4'%3e%3cpath%20d='M489%20363L484%20335L492%20305L485%20279Q487%20270%20494%20278L506%20300L512%20279L521%20254Q530%20250%20527%20263L521%20296L538%20281Q548%20281%20544%20290L522%20313L520%20380Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23adelheid-detail-4)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cg%20transform='rotate(-4%20310%20258)'%3e%3cpath%20d='M269%20291L267%20352L309%20379L354%20348L347%20287Z'%20fill='%23ffdbc4'%20/%3e%3cpath%20d='M271%20300L274%20328L311%20348L346%20320L345%20292Z'%20fill='%23dc929a'%20stroke='none'/%3e%3cpath%20d='M237%20199Q224%20195%20227%20222Q228%20244%20246%20247L251%20273Q268%20307%20303%20321Q316%20325%20331%20315Q365%20298%20377%20270L382%20205L355%20157L277%20157Z'%20fill='%23ffdbc4'%20/%3e%3cpath%20d='M241%20204L253%20220L259%20256L280%20298L300%20317Q265%20306%20251%20276Z%20M365%20203L370%20240L365%20273L344%20300Q371%20286%20379%20267L382%20210Z'%20fill='%23dc929a'%20stroke='none'/%3e%3cpath%20d='M233%20211L241%20216L241%20232'%20fill='none'%20stroke='%23b77d8d'%20stroke-width='1.5'/%3e%3cdefs%3e%3cclipPath%20id='adelheid-eye-277'%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23adelheid-eye-277)'%3e%3cellipse%20cx='279'%20cy='238'%20rx='11'%20ry='16'%20fill='url(%23adelheid-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='280'%20cy='234'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='275'%20cy='231'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M274%20248l8-3'%20fill='none'%20stroke='%23d86284'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M254%20238Q275%20218%20299%20234'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M256%20237l-5-6M259%20234l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M261%20217q13-9%2028-3'%20fill='none'%20stroke='%231f233a'%20stroke-width='3'/%3e%3cdefs%3e%3cclipPath%20id='adelheid-eye-341'%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23adelheid-eye-341)'%3e%3cellipse%20cx='343'%20cy='235'%20rx='11'%20ry='16'%20fill='url(%23adelheid-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='344'%20cy='231'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='339'%20cy='228'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M338%20245l8-3'%20fill='none'%20stroke='%23d86284'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M318%20235Q339%20214%20363%20231'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M320%20234l-5-6M323%20231l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M325%20214q13-9%2028-3'%20fill='none'%20stroke='%231f233a'%20stroke-width='3'/%3e%3cpath%20d='M313%20240L305%20261L312%20264'%20fill='none'%20stroke='%23b87683'%20stroke-width='1.6'/%3e%3cpath%20d='M304%20260l4-3'%20fill='none'%20stroke='%23fff2d7'%20stroke-width='2.5'/%3e%3cpath%20d='M286%20280Q311%20292%20336%20274Q320%20302%20303%20294Z'%20fill='%239f5365'%20stroke-width='1.4'/%3e%3cpath%20d='M290%20282Q314%20289%20331%20278L320%20286L300%20287Z'%20fill='%23fff5e1'%20stroke='none'/%3e%3cpath%20d='M241%20224Q250%20211%20263%20216L253%20235Z%20M356%20210Q374%20208%20378%20220L369%20239Z'%20fill='%23be7c89'%20stroke='none'%20opacity='.2'/%3e%3cpath%20d='M269%20271Q278%20277%20287%20273L286%20281Q276%20284%20267%20279Z%20M340%20267Q348%20270%20357%20266L356%20273Q346%20278%20339%20274Z'%20fill='%23f29c9d'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M262%20263l4-6M269%20266l4-6M276%20267l4-5M343%20261l4-6M350%20261l4-5'%20fill='none'%20stroke='%23d28a96'%20stroke-width='1.2'/%3e%3cpath%20d='M262%20253Q278%20259%20289%20251M330%20249Q346%20254%20357%20246'%20fill='none'%20stroke='%23bd8595'%20stroke-width='1'/%3e%3cpath%20d='M288%20303Q305%20313%20322%20303'%20fill='none'%20stroke='%23f8e2cd'%20stroke-width='2'/%3e%3cpath%20d='M286%20294q11%207%2020%204'%20fill='none'%20stroke='%23bd808d'%20stroke-width='0.9'/%3e%3c/g%3e%3cpath%20d='M226%20162Q256%20111%20325%20133Q382%20143%20388%20219L374%20309L362%20284L366%20211L349%20181L344%20226L319%20213L309%20168L299%20225L276%20212L271%20175L253%20218L246%20305L221%20278Z'%20fill='url(%23adelheid-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='adelheid-detail-5'%3e%3cpath%20d='M226%20162Q256%20111%20325%20133Q382%20143%20388%20219L374%20309L362%20284L366%20211L349%20181L344%20226L319%20213L309%20168L299%20225L276%20212L271%20175L253%20218L246%20305L221%20278Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23adelheid-detail-5)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%231f233a'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%234d405f'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%231f233a'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%231f233a'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M242%20174L238%20259M277%20155L279%20202M314%20148L325%20201M355%20161L370%20222'%20fill='none'%20stroke='%238f6a87'%20stroke-width='2.8'/%3e%3cpath%20d='M266%20349L297%20369L310%20357L328%20372L352%20342L341%20387L312%20380L284%20394Z'%20fill='%234b2c42'%20/%3e%3cpath%20d='M297%20368L282%20358L278%20382L301%20377L319%20392L328%20368L313%20370Z'%20fill='%23d38c59'%20/%3e%3cpath%20d='M91%20298L110%20174'%20fill='none'%20stroke='%23fff2d2'%20stroke-width='5'/%3e%3cpath%20d='M249%20399L226%20507L247%20546M372%20388L394%20497L377%20535'%20fill='none'%20stroke='%23e6bd74'%20stroke-width='4'/%3e%3ccircle%20cx='313'%20cy='424'%20r='3'%20fill='%23b88d5b'/%3e%3ccircle%20cx='313'%20cy='452'%20r='3'%20fill='%23b88d5b'/%3e%3ccircle%20cx='313'%20cy='480'%20r='3'%20fill='%23b88d5b'/%3e%3ccircle%20cx='313'%20cy='508'%20r='3'%20fill='%23b88d5b'/%3e%3cpath%20d='M104%20549Q305%20352%20515%20496M119%20565Q316%20369%20524%20511M133%20582Q325%20386%20530%20528'%20fill='none'%20stroke='%23edbf78'%20stroke-width='2'/%3e%3c/g%3e%3c/symbol%3e%3csymbol%20id='hero-ekolu'%20viewBox='0%200%20620%201080'%3e%3cdefs%3e%3clinearGradient%20id='ekolu-hair'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23efbe60'/%3e%3cstop%20offset='1'%20stop-color='%238c5d43'/%3e%3c/linearGradient%3e%3clinearGradient%20id='ekolu-cloth'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23faf0d4'/%3e%3cstop%20offset='1'%20stop-color='%234586a3'/%3e%3c/linearGradient%3e%3clinearGradient%20id='ekolu-skin'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23cf9a6e'/%3e%3cstop%20offset='1'%20stop-color='%2397624f'/%3e%3c/linearGradient%3e%3clinearGradient%20id='ekolu-iris'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%234586a3'/%3e%3cstop%20offset='1'%20stop-color='%2386d8e2'/%3e%3c/linearGradient%3e%3c/defs%3e%3cg%20stroke='%2332293f'%20stroke-width='2.1'%20stroke-linejoin='round'%20stroke-linecap='round'%3e%3cpath%20d='M247%20160L201%20257L163%20522L220%20495L238%20375L251%20538L292%20369L356%20438L385%20524L402%20359L458%20536L438%20300L370%20169L342%2068L306%2020L285%20120Z'%20fill='url(%23ekolu-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='ekolu-detail-0'%3e%3cpath%20d='M247%20160L201%20257L163%20522L220%20495L238%20375L251%20538L292%20369L356%20438L385%20524L402%20359L458%20536L438%20300L370%20169L342%2068L306%2020L285%20120Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23ekolu-detail-0)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%238c5d43'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%23efbe60'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%238c5d43'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%238c5d43'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M223%20622L166%201039L238%201009L265%201070L311%201028L366%201072L401%201017L474%201049L409%20625Z'%20fill='%23f4ead6'%20/%3e%3cpath%20d='M223%20622L200%20994L234%20953L260%201003L310%20685L351%20996L381%20952L431%201008L409%20625Z'%20fill='%234c91ae'%20/%3e%3cpath%20d='M254%20636L235%20944L266%20913L311%201031L354%20915L395%20955L369%20642Z'%20fill='%23fff3db'%20/%3e%3cpath%20d='M255%20696L267%20916L311%20997L353%20915L369%20700'%20fill='none'%20stroke='%23c29350'%20stroke-width='4'/%3e%3cpath%20d='M247%20347L211%20396L236%20487L244%20599L222%20654L313%20724L406%20651L375%20593L384%20471L412%20397L353%20340Z'%20fill='url(%23ekolu-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='ekolu-detail-1'%3e%3cpath%20d='M247%20347L211%20396L236%20487L244%20599L222%20654L313%20724L406%20651L375%20593L384%20471L412%20397L353%20340Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23ekolu-detail-1)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23885a52'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23e9ba89'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M252%20352L310%20385L357%20346L376%20389L344%20420L374%20466L346%20497L363%20559L313%20599L261%20557L280%20499L245%20467L273%20420L235%20389Z'%20fill='%23e9bb65'%20/%3e%3cpath%20d='M253%20365L293%20392L263%20411Z%20M364%20367L328%20392L354%20412Z%20M310%20427L285%20468L339%20468Z%20M280%20508L310%20543L263%20544Z%20M342%20510L359%20546L316%20546Z%20M310%20568L291%20604L335%20604Z'%20fill='%23397f9f'%20/%3e%3cpath%20d='M281%20410L310%20389L339%20410L310%20429Z%20M278%20480L310%20500L342%20479L310%20456Z'%20fill='%23f7e7c2'%20/%3e%3cpath%20d='M240%20375L214%20390L183%20496L159%20561L181%20576L226%20516L264%20405Z'%20fill='url(%23ekolu-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='ekolu-detail-2'%3e%3cpath%20d='M240%20375L214%20390L183%20496L159%20561L181%20576L226%20516L264%20405Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23ekolu-detail-2)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23885a52'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23e9ba89'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M161%20559L139%20587L102%20596L94%20607L121%20609L102%20626L106%20633L139%20615L125%20637L132%20643L157%20619L168%20597L184%20575Z'%20fill='url(%23ekolu-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='ekolu-detail-3'%3e%3cpath%20d='M161%20559L139%20587L102%20596L94%20607L121%20609L102%20626L106%20633L139%20615L125%20637L132%20643L157%20619L168%20597L184%20575Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23ekolu-detail-3)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23885a52'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23e9ba89'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M375%20372L410%20390L440%20493L464%20562L439%20578L403%20508L353%20406Z'%20fill='url(%23ekolu-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='ekolu-detail-4'%3e%3cpath%20d='M375%20372L410%20390L440%20493L464%20562L439%20578L403%20508L353%20406Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23ekolu-detail-4)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23885a52'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23e9ba89'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M442%20565L459%20555L479%20583L510%20595L523%20610L515%20616L486%20603L507%20627L500%20635L477%20614L484%20636L475%20643L458%20614Z'%20fill='url(%23ekolu-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='ekolu-detail-5'%3e%3cpath%20d='M442%20565L459%20555L479%20583L510%20595L523%20610L515%20616L486%20603L507%20627L500%20635L477%20614L484%20636L475%20643L458%20614Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23ekolu-detail-5)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23885a52'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23e9ba89'%20stroke-width='2'/%3e%3c/g%3e%3cg%20transform='rotate(0%20310%20258)'%3e%3cpath%20d='M269%20291L267%20352L309%20379L354%20348L347%20287Z'%20fill='%23be865e'%20/%3e%3cpath%20d='M271%20300L274%20328L311%20348L346%20320L345%20292Z'%20fill='%23995f59'%20stroke='none'/%3e%3cpath%20d='M237%20199Q224%20195%20227%20222Q228%20244%20246%20247L251%20273Q268%20307%20303%20321Q316%20325%20331%20315Q365%20298%20377%20270L382%20205L355%20157L277%20157Z'%20fill='%23be865e'%20/%3e%3cpath%20d='M241%20204L253%20220L259%20256L280%20298L300%20317Q265%20306%20251%20276Z%20M365%20203L370%20240L365%20273L344%20300Q371%20286%20379%20267L382%20210Z'%20fill='%23995f59'%20stroke='none'/%3e%3cpath%20d='M233%20211L241%20216L241%20232'%20fill='none'%20stroke='%23b77d8d'%20stroke-width='1.5'/%3e%3cdefs%3e%3cclipPath%20id='ekolu-eye-277'%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23ekolu-eye-277)'%3e%3cellipse%20cx='279'%20cy='238'%20rx='11'%20ry='16'%20fill='url(%23ekolu-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='280'%20cy='234'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='275'%20cy='231'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M274%20248l8-3'%20fill='none'%20stroke='%2386d8e2'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M254%20238Q275%20218%20299%20234'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M256%20237l-5-6M259%20234l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M261%20217q13-9%2028-3'%20fill='none'%20stroke='%238c5d43'%20stroke-width='3'/%3e%3cdefs%3e%3cclipPath%20id='ekolu-eye-341'%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23ekolu-eye-341)'%3e%3cellipse%20cx='343'%20cy='235'%20rx='11'%20ry='16'%20fill='url(%23ekolu-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='344'%20cy='231'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='339'%20cy='228'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M338%20245l8-3'%20fill='none'%20stroke='%2386d8e2'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M318%20235Q339%20214%20363%20231'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M320%20234l-5-6M323%20231l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M325%20214q13-9%2028-3'%20fill='none'%20stroke='%238c5d43'%20stroke-width='3'/%3e%3cpath%20d='M313%20240L305%20261L312%20264'%20fill='none'%20stroke='%23b87683'%20stroke-width='1.6'/%3e%3cpath%20d='M304%20260l4-3'%20fill='none'%20stroke='%23fff2d7'%20stroke-width='2.5'/%3e%3cpath%20d='M292%20286Q311%20280%20328%20284'%20fill='none'%20stroke='%23925265'%20stroke-width='2'/%3e%3cpath%20d='M241%20224Q250%20211%20263%20216L253%20235Z%20M356%20210Q374%20208%20378%20220L369%20239Z'%20fill='%23be7c89'%20stroke='none'%20opacity='.2'/%3e%3cpath%20d='M269%20271Q278%20277%20287%20273L286%20281Q276%20284%20267%20279Z%20M340%20267Q348%20270%20357%20266L356%20273Q346%20278%20339%20274Z'%20fill='%23f29c9d'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M262%20263l4-6M269%20266l4-6M276%20267l4-5M343%20261l4-6M350%20261l4-5'%20fill='none'%20stroke='%23d28a96'%20stroke-width='1.2'/%3e%3cpath%20d='M262%20253Q278%20259%20289%20251M330%20249Q346%20254%20357%20246'%20fill='none'%20stroke='%23bd8595'%20stroke-width='1'/%3e%3cpath%20d='M288%20303Q305%20313%20322%20303'%20fill='none'%20stroke='%23f8e2cd'%20stroke-width='2'/%3e%3cpath%20d='M286%20294q11%207%2020%204'%20fill='none'%20stroke='%23bd808d'%20stroke-width='0.9'/%3e%3c/g%3e%3cpath%20d='M242%20179L223%20267L239%20298L255%20236L269%20191L304%20163L336%20191L361%20228L378%20286L393%20247L374%20174L334%20141L299%20132Z'%20fill='url(%23ekolu-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='ekolu-detail-6'%3e%3cpath%20d='M242%20179L223%20267L239%20298L255%20236L269%20191L304%20163L336%20191L361%20228L378%20286L393%20247L374%20174L334%20141L299%20132Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23ekolu-detail-6)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%238c5d43'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%23efbe60'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%238c5d43'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%238c5d43'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M272%20157L267%20115L291%20134L306%2042L327%20133L350%20107L343%20166L310%20195Z'%20fill='%23ebc579'%20/%3e%3cpath%20d='M279%20160L311%20177L337%20157L328%20182L310%20197L290%20183Z'%20fill='%233b87a6'%20/%3e%3cpath%20d='M302%20174L311%20163L320%20174L312%20186Z'%20fill='%23abf0ec'%20/%3e%3cpath%20d='M273%20339L310%20358L350%20334L342%20358L311%20377L282%20360Z'%20fill='%23407d99'%20/%3e%3ccircle%20cx='309'%20cy='360'%20r='9'%20fill='%23e7ba65'/%3e%3cpath%20d='M225%20420L211%20460M396%20422L410%20461'%20fill='none'%20stroke='%23e4ba66'%20stroke-width='9'/%3e%3c/g%3e%3c/symbol%3e%3csymbol%20id='hero-lingling'%20viewBox='0%200%20620%201080'%3e%3cdefs%3e%3clinearGradient%20id='lingling-hair'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23ba6d91'/%3e%3cstop%20offset='1'%20stop-color='%23634061'/%3e%3c/linearGradient%3e%3clinearGradient%20id='lingling-cloth'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23bce2e4'/%3e%3cstop%20offset='1'%20stop-color='%23437e9f'/%3e%3c/linearGradient%3e%3clinearGradient%20id='lingling-skin'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23ffe0c8'/%3e%3cstop%20offset='1'%20stop-color='%23dc98a2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='lingling-iris'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23437e9f'/%3e%3cstop%20offset='1'%20stop-color='%23edbf74'/%3e%3c/linearGradient%3e%3c/defs%3e%3cg%20stroke='%2332293f'%20stroke-width='2.1'%20stroke-linejoin='round'%20stroke-linecap='round'%3e%3cpath%20d='M231%20143Q203%20170%20211%20219L192%20311L219%20299L201%20385L237%20365L218%20459L266%20408L367%20424L397%20367L420%20377L399%20302L417%20295L392%20208Q399%20129%20322%20124L310%2081L299%20126Z'%20fill='url(%23lingling-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='lingling-detail-0'%3e%3cpath%20d='M231%20143Q203%20170%20211%20219L192%20311L219%20299L201%20385L237%20365L218%20459L266%20408L367%20424L397%20367L420%20377L399%20302L417%20295L392%20208Q399%20129%20322%20124L310%2081L299%20126Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23lingling-detail-0)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%23634061'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%23ba6d91'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%23634061'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%23634061'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M234%20658Q210%20751%20244%20811L327%20873L287%201080H365L440%20851Q454%20820%20415%20788L354%20727L372%20675Z'%20fill='%23294a65'%20/%3e%3cpath%20d='M261%20669Q351%20658%20383%20717L461%20870L483%201060L412%201080L382%20909L296%20820Q249%20794%20235%20743Z'%20fill='%233f6480'%20/%3e%3cpath%20d='M296%20747L407%20889L447%201024M339%20890L320%201026'%20fill='none'%20stroke='%2384b2c0'%20stroke-width='4'/%3e%3cpath%20d='M250%20351L211%20383L190%20562L203%20721L265%20750L304%20616L342%20747L406%20722L421%20543L397%20376L351%20347Z'%20fill='url(%23lingling-cloth)'%20/%3e%3cdefs%3e%3cclipPath%20id='lingling-detail-1'%3e%3cpath%20d='M250%20351L211%20383L190%20562L203%20721L265%20750L304%20616L342%20747L406%20722L421%20543L397%20376L351%20347Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23lingling-detail-1)'%3e%3cpath%20d='M207%20378L227%20431L206%20491L211%20554L197%20600L183%20689L173%20755L153%20747L177%20539Z%20M396%20378L412%20409L399%20472L418%20541L425%20628L455%20757L432%20770L410%20666L389%20570L392%20495Z'%20fill='%23437e9f'%20stroke='none'%20opacity='.42'/%3e%3cpath%20d='M226%20381L211%20446L218%20503L208%20540L211%20471L229%20408Z%20M390%20393L403%20439L398%20476L389%20448Z%20M212%20575L199%20715L192%20740L204%20640Z'%20fill='%23bce2e4'%20stroke='none'%20opacity='.8'/%3e%3cpath%20d='M215%20418Q200%20451%20208%20486L200%20514M399%20421L409%20451L403%20481M231%20523L216%20553L207%20592M382%20525L401%20558L409%20603M233%20657L208%20728L196%20784M375%20649L408%20725L425%20784'%20fill='none'%20stroke='%23437e9f'%20stroke-width='2'/%3e%3cpath%20d='M216%20430L211%20470M206%20587L193%20701M410%20589L431%20703M230%20748L241%20780M385%20747L393%20780'%20fill='none'%20stroke='%23bce2e4'%20stroke-width='2.3'/%3e%3cpath%20d='M260%20822Q244%20915%20250%201005M358%20836L386%201019'%20fill='none'%20stroke='%23bce2e4'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M272%20354L262%20467L286%20595L330%20598L354%20456L347%20355L309%20373Z'%20fill='%23eef1e4'%20/%3e%3cpath%20d='M250%20353L240%20434L267%20464L252%20486L279%20564L283%20399Z%20M350%20350L375%20399L365%20435L383%20452L343%20557L334%20393Z'%20fill='%237fbbd0'%20/%3e%3cpath%20d='M219%20388Q190%20417%20189%20479L170%20553L194%20584L227%20522L245%20420Z'%20fill='%23b5dae0'%20/%3e%3cpath%20d='M176%20548L162%20568L145%20572L140%20596L143%20634Q151%20642%20155%20629L155%20601L163%20635Q172%20641%20175%20628L171%20598L185%20626Q196%20628%20191%20615L181%20591L200%20602L204%20593L194%20577L198%20564Z'%20fill='url(%23lingling-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='lingling-detail-2'%3e%3cpath%20d='M176%20548L162%20568L145%20572L140%20596L143%20634Q151%20642%20155%20629L155%20601L163%20635Q172%20641%20175%20628L171%20598L185%20626Q196%20628%20191%20615L181%20591L200%20602L204%20593L194%20577L198%20564Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23lingling-detail-2)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M375%20375L408%20383L436%20440L461%20383L485%20400L466%20482Q455%20509%20429%20501L390%20460Z'%20fill='%23c4e1e5'%20/%3e%3cpath%20d='M462%20385L453%20363L458%20339L448%20319Q448%20309%20456%20315L470%20335L473%20307Q478%20299%20482%20309L482%20338L493%20318Q502%20316%20501%20326L487%20357L486%20399Z'%20fill='url(%23lingling-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='lingling-detail-3'%3e%3cpath%20d='M462%20385L453%20363L458%20339L448%20319Q448%20309%20456%20315L470%20335L473%20307Q478%20299%20482%20309L482%20338L493%20318Q502%20316%20501%20326L487%20357L486%20399Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23lingling-detail-3)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cg%20transform='rotate(3%20310%20258)'%3e%3cpath%20d='M269%20291L267%20352L309%20379L354%20348L347%20287Z'%20fill='%23ffdbc4'%20/%3e%3cpath%20d='M271%20300L274%20328L311%20348L346%20320L345%20292Z'%20fill='%23dc929a'%20stroke='none'/%3e%3cpath%20d='M237%20199Q224%20195%20227%20222Q228%20244%20246%20247L251%20273Q268%20307%20303%20321Q316%20325%20331%20315Q365%20298%20377%20270L382%20205L355%20157L277%20157Z'%20fill='%23ffdbc4'%20/%3e%3cpath%20d='M241%20204L253%20220L259%20256L280%20298L300%20317Q265%20306%20251%20276Z%20M365%20203L370%20240L365%20273L344%20300Q371%20286%20379%20267L382%20210Z'%20fill='%23dc929a'%20stroke='none'/%3e%3cpath%20d='M233%20211L241%20216L241%20232'%20fill='none'%20stroke='%23b77d8d'%20stroke-width='1.5'/%3e%3cdefs%3e%3cclipPath%20id='lingling-eye-277'%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23lingling-eye-277)'%3e%3cellipse%20cx='279'%20cy='238'%20rx='11'%20ry='16'%20fill='url(%23lingling-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='280'%20cy='234'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='275'%20cy='231'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M274%20248l8-3'%20fill='none'%20stroke='%23edbf74'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M254%20238Q275%20218%20299%20234'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M256%20237l-5-6M259%20234l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M261%20217q13-9%2028-3'%20fill='none'%20stroke='%23634061'%20stroke-width='3'/%3e%3cdefs%3e%3cclipPath%20id='lingling-eye-341'%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23lingling-eye-341)'%3e%3cellipse%20cx='343'%20cy='235'%20rx='11'%20ry='16'%20fill='url(%23lingling-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='344'%20cy='231'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='339'%20cy='228'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M338%20245l8-3'%20fill='none'%20stroke='%23edbf74'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M318%20235Q339%20214%20363%20231'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M320%20234l-5-6M323%20231l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M325%20214q13-9%2028-3'%20fill='none'%20stroke='%23634061'%20stroke-width='3'/%3e%3cpath%20d='M313%20240L305%20261L312%20264'%20fill='none'%20stroke='%23b87683'%20stroke-width='1.6'/%3e%3cpath%20d='M304%20260l4-3'%20fill='none'%20stroke='%23fff2d7'%20stroke-width='2.5'/%3e%3cpath%20d='M286%20280Q311%20292%20336%20274Q320%20302%20303%20294Z'%20fill='%239f5365'%20stroke-width='1.4'/%3e%3cpath%20d='M290%20282Q314%20289%20331%20278L320%20286L300%20287Z'%20fill='%23fff5e1'%20stroke='none'/%3e%3cpath%20d='M241%20224Q250%20211%20263%20216L253%20235Z%20M356%20210Q374%20208%20378%20220L369%20239Z'%20fill='%23be7c89'%20stroke='none'%20opacity='.2'/%3e%3cpath%20d='M269%20271Q278%20277%20287%20273L286%20281Q276%20284%20267%20279Z%20M340%20267Q348%20270%20357%20266L356%20273Q346%20278%20339%20274Z'%20fill='%23f29c9d'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M262%20263l4-6M269%20266l4-6M276%20267l4-5M343%20261l4-6M350%20261l4-5'%20fill='none'%20stroke='%23d28a96'%20stroke-width='1.2'/%3e%3cpath%20d='M262%20253Q278%20259%20289%20251M330%20249Q346%20254%20357%20246'%20fill='none'%20stroke='%23bd8595'%20stroke-width='1'/%3e%3cpath%20d='M288%20303Q305%20313%20322%20303'%20fill='none'%20stroke='%23f8e2cd'%20stroke-width='2'/%3e%3cpath%20d='M286%20294q11%207%2020%204'%20fill='none'%20stroke='%23bd808d'%20stroke-width='0.9'/%3e%3c/g%3e%3cpath%20d='M232%20171Q254%20127%20322%20143Q377%20145%20385%20203L375%20260L359%20221L344%20180L340%20229L318%20209L303%20175L293%20225L270%20208L262%20183L246%20260L224%20282Z'%20fill='url(%23lingling-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='lingling-detail-4'%3e%3cpath%20d='M232%20171Q254%20127%20322%20143Q377%20145%20385%20203L375%20260L359%20221L344%20180L340%20229L318%20209L303%20175L293%20225L270%20208L262%20183L246%20260L224%20282Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23lingling-detail-4)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%23634061'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%23ba6d91'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%23634061'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%23634061'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M253%20162L239%20230M282%20156L275%20197M317%20154L329%20200M352%20160L366%20215'%20fill='none'%20stroke='%23d391a7'%20stroke-width='3'/%3e%3cpath%20d='M294%20140Q274%20109%20294%2091Q313%20111%20307%20132'%20fill='none'%20stroke='%239d5c86'%20stroke-width='3'/%3e%3cg%20fill='none'%20stroke='%23703b60'%20stroke-width='3'%3e%3cpath%20d='M249%20228Q270%20216%20300%20228L297%20250Q271%20261%20252%20248Z%20M321%20225Q343%20213%20371%20223L367%20246Q341%20257%20323%20245Z%20M300%20230L321%20228'/%3e%3c/g%3e%3cpath%20d='M284%20359L310%20375L336%20356L328%20386L310%20394L291%20384Z'%20fill='%2327566d'%20/%3e%3cpath%20d='M309%20386L318%20406L308%20464L296%20439Z'%20fill='%236bd3d2'%20/%3e%3cpath%20d='M140%20658L253%20643L284%20684L169%20702Z%20M157%20665L239%20655M177%20680L259%20667'%20fill='none'%20stroke='%2391f5ed'%20stroke-width='2'/%3e%3ccircle%20cx='205'%20cy='674'%20r='12'%20fill='%2368d7d6'/%3e%3c/g%3e%3c/symbol%3e%3csymbol%20id='hero-rie'%20viewBox='0%200%20620%201080'%3e%3cdefs%3e%3clinearGradient%20id='rie-hair'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23ffc578'/%3e%3cstop%20offset='1'%20stop-color='%23bd5a65'/%3e%3c/linearGradient%3e%3clinearGradient%20id='rie-cloth'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23455c61'/%3e%3cstop%20offset='1'%20stop-color='%23212f40'/%3e%3c/linearGradient%3e%3clinearGradient%20id='rie-skin'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23ffe0c8'/%3e%3cstop%20offset='1'%20stop-color='%23dc98a2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='rie-iris'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23212f40'/%3e%3cstop%20offset='1'%20stop-color='%2382bf87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cg%20stroke='%2332293f'%20stroke-width='2.1'%20stroke-linejoin='round'%20stroke-linecap='round'%3e%3cpath%20d='M278%20134Q323%2075%20383%20101L412%20144L395%20121L425%20206L383%20184L406%20259L367%20228L369%20318L328%20229Z'%20fill='url(%23rie-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='rie-detail-0'%3e%3cpath%20d='M278%20134Q323%2075%20383%20101L412%20144L395%20121L425%20206L383%20184L406%20259L367%20228L369%20318L328%20229Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23rie-detail-0)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%23bd5a65'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%23ffc578'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%23bd5a65'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%23bd5a65'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M244%20705L210%20943L220%201080H294L318%20834L343%20978L361%201080H440L410%20739Z'%20fill='url(%23rie-cloth)'%20/%3e%3cdefs%3e%3cclipPath%20id='rie-detail-1'%3e%3cpath%20d='M244%20705L210%20943L220%201080H294L318%20834L343%20978L361%201080H440L410%20739Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23rie-detail-1)'%3e%3cpath%20d='M207%20378L227%20431L206%20491L211%20554L197%20600L183%20689L173%20755L153%20747L177%20539Z%20M396%20378L412%20409L399%20472L418%20541L425%20628L455%20757L432%20770L410%20666L389%20570L392%20495Z'%20fill='%23212f40'%20stroke='none'%20opacity='.42'/%3e%3cpath%20d='M226%20381L211%20446L218%20503L208%20540L211%20471L229%20408Z%20M390%20393L403%20439L398%20476L389%20448Z%20M212%20575L199%20715L192%20740L204%20640Z'%20fill='%23455c61'%20stroke='none'%20opacity='.8'/%3e%3cpath%20d='M215%20418Q200%20451%20208%20486L200%20514M399%20421L409%20451L403%20481M231%20523L216%20553L207%20592M382%20525L401%20558L409%20603M233%20657L208%20728L196%20784M375%20649L408%20725L425%20784'%20fill='none'%20stroke='%23212f40'%20stroke-width='2'/%3e%3cpath%20d='M216%20430L211%20470M206%20587L193%20701M410%20589L431%20703M230%20748L241%20780M385%20747L393%20780'%20fill='none'%20stroke='%23455c61'%20stroke-width='2.3'/%3e%3cpath%20d='M260%20822Q244%20915%20250%201005M358%20836L386%201019'%20fill='none'%20stroke='%23455c61'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M275%20786L249%20984M368%20784L389%201018'%20fill='none'%20stroke='%23bd5a65'%20stroke-width='5'/%3e%3cpath%20d='M237%20665L215%20922L290%20935L315%20760L341%20942L415%20951L394%20671Z'%20fill='%23344551'%20/%3e%3cpath%20d='M247%20346L206%20374L191%20482L226%20574L220%20687Q310%20740%20408%20686L383%20570L415%20459L391%20363L346%20339Z'%20fill='url(%23rie-cloth)'%20/%3e%3cdefs%3e%3cclipPath%20id='rie-detail-2'%3e%3cpath%20d='M247%20346L206%20374L191%20482L226%20574L220%20687Q310%20740%20408%20686L383%20570L415%20459L391%20363L346%20339Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23rie-detail-2)'%3e%3cpath%20d='M207%20378L227%20431L206%20491L211%20554L197%20600L183%20689L173%20755L153%20747L177%20539Z%20M396%20378L412%20409L399%20472L418%20541L425%20628L455%20757L432%20770L410%20666L389%20570L392%20495Z'%20fill='%23212f40'%20stroke='none'%20opacity='.42'/%3e%3cpath%20d='M226%20381L211%20446L218%20503L208%20540L211%20471L229%20408Z%20M390%20393L403%20439L398%20476L389%20448Z%20M212%20575L199%20715L192%20740L204%20640Z'%20fill='%23455c61'%20stroke='none'%20opacity='.8'/%3e%3cpath%20d='M215%20418Q200%20451%20208%20486L200%20514M399%20421L409%20451L403%20481M231%20523L216%20553L207%20592M382%20525L401%20558L409%20603M233%20657L208%20728L196%20784M375%20649L408%20725L425%20784'%20fill='none'%20stroke='%23212f40'%20stroke-width='2'/%3e%3cpath%20d='M216%20430L211%20470M206%20587L193%20701M410%20589L431%20703M230%20748L241%20780M385%20747L393%20780'%20fill='none'%20stroke='%23455c61'%20stroke-width='2.3'/%3e%3cpath%20d='M260%20822Q244%20915%20250%201005M358%20836L386%201019'%20fill='none'%20stroke='%23455c61'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M270%20356L253%20482L274%20598L348%20598L370%20472L350%20350L307%20376Z'%20fill='%2326343c'%20/%3e%3cpath%20d='M245%20351L224%20396L231%20511L265%20597L273%20417Z%20M350%20344L381%20374L391%20464L357%20593L337%20404Z'%20fill='%2391a58a'%20/%3e%3cpath%20d='M213%20375L181%20390L144%20422L119%20391L98%20411L133%20467Q150%20484%20173%20468L224%20434Z'%20fill='url(%23rie-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='rie-detail-3'%3e%3cpath%20d='M213%20375L181%20390L144%20422L119%20391L98%20411L133%20467Q150%20484%20173%20468L224%20434Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23rie-detail-3)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M104%20410L90%20389L84%20353L73%20338Q67%20330%2076%20327L88%20336L92%20317Q96%20312%20102%20318L116%20347L119%20391Z'%20fill='url(%23rie-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='rie-detail-4'%3e%3cpath%20d='M104%20410L90%20389L84%20353L73%20338Q67%20330%2076%20327L88%20336L92%20317Q96%20312%20102%20318L116%20347L119%20391Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23rie-detail-4)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M385%20370L413%20379L446%20464L425%20570L400%20574L413%20468L365%20421Z'%20fill='url(%23rie-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='rie-detail-5'%3e%3cpath%20d='M385%20370L413%20379L446%20464L425%20570L400%20574L413%20468L365%20421Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23rie-detail-5)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M402%20563L424%20558L428%20591L413%20624L401%20627L397%20617L408%20595L395%20604L388%20598Z'%20fill='url(%23rie-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='rie-detail-6'%3e%3cpath%20d='M402%20563L424%20558L428%20591L413%20624L401%20627L397%20617L408%20595L395%20604L388%20598Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23rie-detail-6)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M79%20346L506%20244Q527%20243%20532%20258Q537%20272%20514%20280L91%20367Z'%20fill='%23cfa979'%20/%3e%3cpath%20d='M90%20351L516%20252'%20fill='none'%20stroke='%23f6dfb0'%20stroke-width='5'/%3e%3cpath%20d='M92%20356L149%20343'%20fill='none'%20stroke='%23726057'%20stroke-width='13'/%3e%3cg%20transform='rotate(-5%20310%20258)'%3e%3cpath%20d='M269%20291L267%20352L309%20379L354%20348L347%20287Z'%20fill='%23ffdbc4'%20/%3e%3cpath%20d='M271%20300L274%20328L311%20348L346%20320L345%20292Z'%20fill='%23dc929a'%20stroke='none'/%3e%3cpath%20d='M237%20199Q224%20195%20227%20222Q228%20244%20246%20247L251%20273Q268%20307%20303%20321Q316%20325%20331%20315Q365%20298%20377%20270L382%20205L355%20157L277%20157Z'%20fill='%23ffdbc4'%20/%3e%3cpath%20d='M241%20204L253%20220L259%20256L280%20298L300%20317Q265%20306%20251%20276Z%20M365%20203L370%20240L365%20273L344%20300Q371%20286%20379%20267L382%20210Z'%20fill='%23dc929a'%20stroke='none'/%3e%3cpath%20d='M233%20211L241%20216L241%20232'%20fill='none'%20stroke='%23b77d8d'%20stroke-width='1.5'/%3e%3cdefs%3e%3cclipPath%20id='rie-eye-277'%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23rie-eye-277)'%3e%3cellipse%20cx='279'%20cy='238'%20rx='11'%20ry='16'%20fill='url(%23rie-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='280'%20cy='234'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='275'%20cy='231'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M274%20248l8-3'%20fill='none'%20stroke='%2382bf87'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M254%20238Q275%20218%20299%20234'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M256%20237l-5-6M259%20234l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M261%20217q13-9%2028-3'%20fill='none'%20stroke='%23bd5a65'%20stroke-width='3'/%3e%3cdefs%3e%3cclipPath%20id='rie-eye-341'%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23rie-eye-341)'%3e%3cellipse%20cx='343'%20cy='235'%20rx='11'%20ry='16'%20fill='url(%23rie-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='344'%20cy='231'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='339'%20cy='228'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M338%20245l8-3'%20fill='none'%20stroke='%2382bf87'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M318%20235Q339%20214%20363%20231'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M320%20234l-5-6M323%20231l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M325%20214q13-9%2028-3'%20fill='none'%20stroke='%23bd5a65'%20stroke-width='3'/%3e%3cpath%20d='M313%20240L305%20261L312%20264'%20fill='none'%20stroke='%23b87683'%20stroke-width='1.6'/%3e%3cpath%20d='M304%20260l4-3'%20fill='none'%20stroke='%23fff2d7'%20stroke-width='2.5'/%3e%3cpath%20d='M286%20280Q311%20292%20336%20274Q320%20302%20303%20294Z'%20fill='%239f5365'%20stroke-width='1.4'/%3e%3cpath%20d='M290%20282Q314%20289%20331%20278L320%20286L300%20287Z'%20fill='%23fff5e1'%20stroke='none'/%3e%3cpath%20d='M241%20224Q250%20211%20263%20216L253%20235Z%20M356%20210Q374%20208%20378%20220L369%20239Z'%20fill='%23be7c89'%20stroke='none'%20opacity='.2'/%3e%3cpath%20d='M269%20271Q278%20277%20287%20273L286%20281Q276%20284%20267%20279Z%20M340%20267Q348%20270%20357%20266L356%20273Q346%20278%20339%20274Z'%20fill='%23f29c9d'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M262%20263l4-6M269%20266l4-6M276%20267l4-5M343%20261l4-6M350%20261l4-5'%20fill='none'%20stroke='%23d28a96'%20stroke-width='1.2'/%3e%3cpath%20d='M262%20253Q278%20259%20289%20251M330%20249Q346%20254%20357%20246'%20fill='none'%20stroke='%23bd8595'%20stroke-width='1'/%3e%3cpath%20d='M288%20303Q305%20313%20322%20303'%20fill='none'%20stroke='%23f8e2cd'%20stroke-width='2'/%3e%3cpath%20d='M286%20294q11%207%2020%204'%20fill='none'%20stroke='%23bd808d'%20stroke-width='0.9'/%3e%3c/g%3e%3cpath%20d='M238%20173Q291%20130%20343%20156Q382%20176%20384%20220L368%20277L355%20241L351%20200L328%20222L306%20199L303%20165L282%20219L263%20206L249%20252L228%20281Z'%20fill='url(%23rie-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='rie-detail-7'%3e%3cpath%20d='M238%20173Q291%20130%20343%20156Q382%20176%20384%20220L368%20277L355%20241L351%20200L328%20222L306%20199L303%20165L282%20219L263%20206L249%20252L228%20281Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23rie-detail-7)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%23bd5a65'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%23ffc578'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%23bd5a65'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%23bd5a65'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M222%20158Q221%20100%20283%2090Q355%2064%20382%20140L376%20160L303%20183Z'%20fill='%23283f45'%20/%3e%3cpath%20d='M222%20158Q300%20131%20402%20157L417%20178Q328%20173%20237%20191Z'%20fill='%23365453'%20/%3e%3cpath%20d='M247%20141Q301%20107%20365%20142'%20fill='none'%20stroke='%23d6ac64'%20stroke-width='3'/%3e%3cpath%20d='M296%20111L317%20111L321%20135L309%20145L294%20135Z'%20fill='%23d6ac64'%20/%3e%3cpath%20d='M246%20191L239%20235M278%20183L272%20205M349%20188L368%20235'%20fill='none'%20stroke='%23ffe2a0'%20stroke-width='3'/%3e%3cpath%20d='M231%20623Q310%20654%20393%20624L402%20649Q313%20689%20224%20652Z'%20fill='%236c674e'%20/%3e%3cpath%20d='M294%20644H330V670H294Z'%20fill='%23d9b16f'%20/%3e%3cpath%20d='M220%20388L203%20447M402%20383L420%20428'%20fill='none'%20stroke='%23a4c1aa'%20stroke-width='3'/%3e%3c/g%3e%3c/symbol%3e%3csymbol%20id='hero-senka'%20viewBox='0%200%20620%201080'%3e%3cdefs%3e%3clinearGradient%20id='senka-hair'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23a3bad1'/%3e%3cstop%20offset='1'%20stop-color='%2353647f'/%3e%3c/linearGradient%3e%3clinearGradient%20id='senka-cloth'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%2349283f'/%3e%3cstop%20offset='1'%20stop-color='%23201f37'/%3e%3c/linearGradient%3e%3clinearGradient%20id='senka-skin'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23ffe0c8'/%3e%3cstop%20offset='1'%20stop-color='%23dc98a2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='senka-iris'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23201f37'/%3e%3cstop%20offset='1'%20stop-color='%2377c9e7'/%3e%3c/linearGradient%3e%3c/defs%3e%3cg%20stroke='%2332293f'%20stroke-width='2.1'%20stroke-linejoin='round'%20stroke-linecap='round'%3e%3cpath%20d='M226%20162Q278%20107%20345%20142L390%20201L417%20468L367%20419L352%20284L262%20260L253%20408L206%20453L215%20318Z'%20fill='url(%23senka-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='senka-detail-0'%3e%3cpath%20d='M226%20162Q278%20107%20345%20142L390%20201L417%20468L367%20419L352%20284L262%20260L253%20408L206%20453L215%20318Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23senka-detail-0)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%2353647f'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%23a3bad1'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%2353647f'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%2353647f'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M244%20705L210%20943L220%201080H294L318%20834L343%20978L361%201080H440L410%20739Z'%20fill='url(%23senka-cloth)'%20/%3e%3cdefs%3e%3cclipPath%20id='senka-detail-1'%3e%3cpath%20d='M244%20705L210%20943L220%201080H294L318%20834L343%20978L361%201080H440L410%20739Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23senka-detail-1)'%3e%3cpath%20d='M207%20378L227%20431L206%20491L211%20554L197%20600L183%20689L173%20755L153%20747L177%20539Z%20M396%20378L412%20409L399%20472L418%20541L425%20628L455%20757L432%20770L410%20666L389%20570L392%20495Z'%20fill='%23201f37'%20stroke='none'%20opacity='.42'/%3e%3cpath%20d='M226%20381L211%20446L218%20503L208%20540L211%20471L229%20408Z%20M390%20393L403%20439L398%20476L389%20448Z%20M212%20575L199%20715L192%20740L204%20640Z'%20fill='%2349283f'%20stroke='none'%20opacity='.8'/%3e%3cpath%20d='M215%20418Q200%20451%20208%20486L200%20514M399%20421L409%20451L403%20481M231%20523L216%20553L207%20592M382%20525L401%20558L409%20603M233%20657L208%20728L196%20784M375%20649L408%20725L425%20784'%20fill='none'%20stroke='%23201f37'%20stroke-width='2'/%3e%3cpath%20d='M216%20430L211%20470M206%20587L193%20701M410%20589L431%20703M230%20748L241%20780M385%20747L393%20780'%20fill='none'%20stroke='%2349283f'%20stroke-width='2.3'/%3e%3cpath%20d='M260%20822Q244%20915%20250%201005M358%20836L386%201019'%20fill='none'%20stroke='%2349283f'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M275%20786L249%20984M368%20784L389%201018'%20fill='none'%20stroke='%2353647f'%20stroke-width='5'/%3e%3cpath%20d='M230%20685L209%20785L267%20815L311%20767L359%20815L416%20782L390%20683Z'%20fill='%232a2a41'%20/%3e%3cpath%20d='M240%20711L228%20776M270%20719L264%20799M349%20718L360%20798M379%20708L399%20775'%20fill='none'%20stroke='%236f4b6b'%20stroke-width='3'/%3e%3cpath%20d='M238%20344L198%20378L173%20510L155%20745L202%20827L249%20641L285%20589L342%20594L379%20650L426%20830L475%20762L435%20519L419%20378L360%20342Z'%20fill='url(%23senka-cloth)'%20/%3e%3cdefs%3e%3cclipPath%20id='senka-detail-2'%3e%3cpath%20d='M238%20344L198%20378L173%20510L155%20745L202%20827L249%20641L285%20589L342%20594L379%20650L426%20830L475%20762L435%20519L419%20378L360%20342Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23senka-detail-2)'%3e%3cpath%20d='M207%20378L227%20431L206%20491L211%20554L197%20600L183%20689L173%20755L153%20747L177%20539Z%20M396%20378L412%20409L399%20472L418%20541L425%20628L455%20757L432%20770L410%20666L389%20570L392%20495Z'%20fill='%23201f37'%20stroke='none'%20opacity='.42'/%3e%3cpath%20d='M226%20381L211%20446L218%20503L208%20540L211%20471L229%20408Z%20M390%20393L403%20439L398%20476L389%20448Z%20M212%20575L199%20715L192%20740L204%20640Z'%20fill='%2349283f'%20stroke='none'%20opacity='.8'/%3e%3cpath%20d='M215%20418Q200%20451%20208%20486L200%20514M399%20421L409%20451L403%20481M231%20523L216%20553L207%20592M382%20525L401%20558L409%20603M233%20657L208%20728L196%20784M375%20649L408%20725L425%20784'%20fill='none'%20stroke='%23201f37'%20stroke-width='2'/%3e%3cpath%20d='M216%20430L211%20470M206%20587L193%20701M410%20589L431%20703M230%20748L241%20780M385%20747L393%20780'%20fill='none'%20stroke='%2349283f'%20stroke-width='2.3'/%3e%3cpath%20d='M260%20822Q244%20915%20250%201005M358%20836L386%201019'%20fill='none'%20stroke='%2349283f'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M264%20352L249%20465L277%20598L341%20601L369%20462L347%20350L311%20383Z'%20fill='%23303043'%20/%3e%3cpath%20d='M233%20383L207%20475L233%20554L268%20499L279%20378Z%20M360%20370L398%20396L409%20478L381%20548L343%20487Z'%20fill='%237b3f59'%20/%3e%3cpath%20d='M200%20391L176%20423L150%20565L173%20640L206%20613L198%20544L231%20433Z'%20fill='%2346273f'%20/%3e%3cpath%20d='M172%20629L185%20622L204%20635L214%20665L207%20675L196%20657L192%20683L181%20686L172%20665Z'%20fill='url(%23senka-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='senka-detail-3'%3e%3cpath%20d='M172%20629L185%20622L204%20635L214%20665L207%20675L196%20657L192%20683L181%20686L172%20665Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23senka-detail-3)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M401%20387L433%20399L461%20488L453%20575L423%20586L418%20496L378%20432Z'%20fill='%234e2943'%20/%3e%3cpath%20d='M426%20576L450%20570L458%20601L446%20624L435%20625L433%20609L418%20606Z'%20fill='url(%23senka-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='senka-detail-4'%3e%3cpath%20d='M426%20576L450%20570L458%20601L446%20624L435%20625L433%20609L418%20606Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23senka-detail-4)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M414%20606L465%20604L472%20624L453%20635L450%20690L425%20689L430%20630L410%20627Z'%20fill='%232a3044'%20/%3e%3cpath%20d='M417%20611H462'%20fill='none'%20stroke='%2390b8c5'%20stroke-width='3'/%3e%3cg%20transform='rotate(-3%20310%20258)'%3e%3cpath%20d='M269%20291L267%20352L309%20379L354%20348L347%20287Z'%20fill='%23ffdbc4'%20/%3e%3cpath%20d='M271%20300L274%20328L311%20348L346%20320L345%20292Z'%20fill='%23dc929a'%20stroke='none'/%3e%3cpath%20d='M237%20199Q224%20195%20227%20222Q228%20244%20246%20247L251%20273Q268%20307%20303%20321Q316%20325%20331%20315Q365%20298%20377%20270L382%20205L355%20157L277%20157Z'%20fill='%23ffdbc4'%20/%3e%3cpath%20d='M241%20204L253%20220L259%20256L280%20298L300%20317Q265%20306%20251%20276Z%20M365%20203L370%20240L365%20273L344%20300Q371%20286%20379%20267L382%20210Z'%20fill='%23dc929a'%20stroke='none'/%3e%3cpath%20d='M233%20211L241%20216L241%20232'%20fill='none'%20stroke='%23b77d8d'%20stroke-width='1.5'/%3e%3cdefs%3e%3cclipPath%20id='senka-eye-277'%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23senka-eye-277)'%3e%3cellipse%20cx='279'%20cy='238'%20rx='11'%20ry='16'%20fill='url(%23senka-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='280'%20cy='234'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='275'%20cy='231'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M274%20248l8-3'%20fill='none'%20stroke='%2377c9e7'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M254%20238Q275%20218%20299%20234'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M256%20237l-5-6M259%20234l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M261%20217q13-9%2028-3'%20fill='none'%20stroke='%2353647f'%20stroke-width='3'/%3e%3cdefs%3e%3cclipPath%20id='senka-eye-341'%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23senka-eye-341)'%3e%3cellipse%20cx='343'%20cy='235'%20rx='11'%20ry='16'%20fill='url(%23senka-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='344'%20cy='231'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='339'%20cy='228'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M338%20245l8-3'%20fill='none'%20stroke='%2377c9e7'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M318%20235Q339%20214%20363%20231'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M320%20234l-5-6M323%20231l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M325%20214q13-9%2028-3'%20fill='none'%20stroke='%2353647f'%20stroke-width='3'/%3e%3cpath%20d='M313%20240L305%20261L312%20264'%20fill='none'%20stroke='%23b87683'%20stroke-width='1.6'/%3e%3cpath%20d='M304%20260l4-3'%20fill='none'%20stroke='%23fff2d7'%20stroke-width='2.5'/%3e%3cpath%20d='M292%20286Q311%20280%20328%20284'%20fill='none'%20stroke='%23925265'%20stroke-width='2'/%3e%3cpath%20d='M241%20224Q250%20211%20263%20216L253%20235Z%20M356%20210Q374%20208%20378%20220L369%20239Z'%20fill='%23be7c89'%20stroke='none'%20opacity='.2'/%3e%3cpath%20d='M269%20271Q278%20277%20287%20273L286%20281Q276%20284%20267%20279Z%20M340%20267Q348%20270%20357%20266L356%20273Q346%20278%20339%20274Z'%20fill='%23f29c9d'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M262%20263l4-6M269%20266l4-6M276%20267l4-5M343%20261l4-6M350%20261l4-5'%20fill='none'%20stroke='%23d28a96'%20stroke-width='1.2'/%3e%3cpath%20d='M262%20253Q278%20259%20289%20251M330%20249Q346%20254%20357%20246'%20fill='none'%20stroke='%23bd8595'%20stroke-width='1'/%3e%3cpath%20d='M288%20303Q305%20313%20322%20303'%20fill='none'%20stroke='%23f8e2cd'%20stroke-width='2'/%3e%3cpath%20d='M286%20294q11%207%2020%204'%20fill='none'%20stroke='%23bd808d'%20stroke-width='0.9'/%3e%3c/g%3e%3cpath%20d='M224%20164Q250%20126%20321%20144L370%20168L390%20221L373%20295L359%20244L357%20199L335%20220L319%20174L308%20225L280%20204L266%20178L253%20248L236%20284L223%20246Z'%20fill='url(%23senka-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='senka-detail-5'%3e%3cpath%20d='M224%20164Q250%20126%20321%20144L370%20168L390%20221L373%20295L359%20244L357%20199L335%20220L319%20174L308%20225L280%20204L266%20178L253%20248L236%20284L223%20246Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23senka-detail-5)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%2353647f'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%23a3bad1'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%2353647f'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%2353647f'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M240%20177L235%20230M275%20160L273%20198M312%20156L325%20205M354%20175L368%20233'%20fill='none'%20stroke='%23cfdfdf'%20stroke-width='3'/%3e%3cpath%20d='M214%20326Q168%20243%20202%20164L250%2099L315%2084L373%20123L407%20213L397%20337L369%20311L378%20221Q370%20156%20308%20146Q245%20150%20231%20210L239%20309Z'%20fill='%2351273e'%20/%3e%3cpath%20d='M250%2099L315%2084L373%20123L347%20138L310%20115L270%20134L213%20207Z'%20fill='%23813b52'%20/%3e%3cpath%20d='M203%20166L247%20115L315%2098M388%20185L402%20250'%20fill='none'%20stroke='%23da686e'%20stroke-width='3'/%3e%3cpath%20d='M263%20340L284%20362L309%20351L339%20365L354%20339L351%20391L312%20407L270%20390Z'%20fill='%23252a3d'%20/%3e%3cpath%20d='M227%20466L198%20727M405%20478L440%20737'%20fill='none'%20stroke='%2395637e'%20stroke-width='3'/%3e%3cpath%20d='M287%20429L278%20501M336%20429L346%20500'%20fill='none'%20stroke='%236082a2'%20stroke-width='3'/%3e%3c/g%3e%3c/symbol%3e%3csymbol%20id='hero-youngja'%20viewBox='0%200%20620%201080'%3e%3cdefs%3e%3clinearGradient%20id='youngja-hair'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23f4e5d6'/%3e%3cstop%20offset='1'%20stop-color='%23aaa7c4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='youngja-cloth'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23e7e9ee'/%3e%3cstop%20offset='1'%20stop-color='%23344e83'/%3e%3c/linearGradient%3e%3clinearGradient%20id='youngja-skin'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23ffe0c8'/%3e%3cstop%20offset='1'%20stop-color='%23dc98a2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='youngja-iris'%20x1='0'%20y1='0'%20x2='.8'%20y2='1'%3e%3cstop%20stop-color='%23344e83'/%3e%3cstop%20offset='1'%20stop-color='%23b87559'/%3e%3c/linearGradient%3e%3c/defs%3e%3cg%20stroke='%2332293f'%20stroke-width='2.1'%20stroke-linejoin='round'%20stroke-linecap='round'%3e%3cpath%20d='M241%20149L230%2076L272%20110L294%2020L321%2092L348%2050L358%20126L397%20162L411%20338L460%20488L411%20462L429%20580L375%20537L356%20339L252%20325L219%20481L173%20529L193%20408L205%20221Z'%20fill='url(%23youngja-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='youngja-detail-0'%3e%3cpath%20d='M241%20149L230%2076L272%20110L294%2020L321%2092L348%2050L358%20126L397%20162L411%20338L460%20488L411%20462L429%20580L375%20537L356%20339L252%20325L219%20481L173%20529L193%20408L205%20221Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23youngja-detail-0)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%23aaa7c4'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%23f4e5d6'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%23aaa7c4'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%23aaa7c4'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M227%20716L232%20934L218%201080H295L309%20824L336%20929L355%201080H433L411%20768Z'%20fill='url(%23youngja-cloth)'%20/%3e%3cdefs%3e%3cclipPath%20id='youngja-detail-1'%3e%3cpath%20d='M227%20716L232%20934L218%201080H295L309%20824L336%20929L355%201080H433L411%20768Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23youngja-detail-1)'%3e%3cpath%20d='M207%20378L227%20431L206%20491L211%20554L197%20600L183%20689L173%20755L153%20747L177%20539Z%20M396%20378L412%20409L399%20472L418%20541L425%20628L455%20757L432%20770L410%20666L389%20570L392%20495Z'%20fill='%23344e83'%20stroke='none'%20opacity='.42'/%3e%3cpath%20d='M226%20381L211%20446L218%20503L208%20540L211%20471L229%20408Z%20M390%20393L403%20439L398%20476L389%20448Z%20M212%20575L199%20715L192%20740L204%20640Z'%20fill='%23e7e9ee'%20stroke='none'%20opacity='.8'/%3e%3cpath%20d='M215%20418Q200%20451%20208%20486L200%20514M399%20421L409%20451L403%20481M231%20523L216%20553L207%20592M382%20525L401%20558L409%20603M233%20657L208%20728L196%20784M375%20649L408%20725L425%20784'%20fill='none'%20stroke='%23344e83'%20stroke-width='2'/%3e%3cpath%20d='M216%20430L211%20470M206%20587L193%20701M410%20589L431%20703M230%20748L241%20780M385%20747L393%20780'%20fill='none'%20stroke='%23e7e9ee'%20stroke-width='2.3'/%3e%3cpath%20d='M260%20822Q244%20915%20250%201005M358%20836L386%201019'%20fill='none'%20stroke='%23e7e9ee'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M275%20786L249%20984M368%20784L389%201018'%20fill='none'%20stroke='%23aaa7c4'%20stroke-width='5'/%3e%3cpath%20d='M227%20692L187%20803L259%20843L310%20804L366%20846L431%20801L393%20686Z'%20fill='%23294b7f'%20/%3e%3cpath%20d='M254%20347L212%20376L182%20505L157%20731L216%20857L269%20637L344%20638L395%20864L469%20738L425%20493L399%20372L347%20345Z'%20fill='url(%23youngja-cloth)'%20/%3e%3cdefs%3e%3cclipPath%20id='youngja-detail-2'%3e%3cpath%20d='M254%20347L212%20376L182%20505L157%20731L216%20857L269%20637L344%20638L395%20864L469%20738L425%20493L399%20372L347%20345Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23youngja-detail-2)'%3e%3cpath%20d='M207%20378L227%20431L206%20491L211%20554L197%20600L183%20689L173%20755L153%20747L177%20539Z%20M396%20378L412%20409L399%20472L418%20541L425%20628L455%20757L432%20770L410%20666L389%20570L392%20495Z'%20fill='%23344e83'%20stroke='none'%20opacity='.42'/%3e%3cpath%20d='M226%20381L211%20446L218%20503L208%20540L211%20471L229%20408Z%20M390%20393L403%20439L398%20476L389%20448Z%20M212%20575L199%20715L192%20740L204%20640Z'%20fill='%23e7e9ee'%20stroke='none'%20opacity='.8'/%3e%3cpath%20d='M215%20418Q200%20451%20208%20486L200%20514M399%20421L409%20451L403%20481M231%20523L216%20553L207%20592M382%20525L401%20558L409%20603M233%20657L208%20728L196%20784M375%20649L408%20725L425%20784'%20fill='none'%20stroke='%23344e83'%20stroke-width='2'/%3e%3cpath%20d='M216%20430L211%20470M206%20587L193%20701M410%20589L431%20703M230%20748L241%20780M385%20747L393%20780'%20fill='none'%20stroke='%23e7e9ee'%20stroke-width='2.3'/%3e%3cpath%20d='M260%20822Q244%20915%20250%201005M358%20836L386%201019'%20fill='none'%20stroke='%23e7e9ee'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M268%20354L256%20470L282%20598L337%20597L364%20466L348%20349L310%20375Z'%20fill='%23faf0e4'%20/%3e%3cpath%20d='M249%20356L230%20412L247%20472L273%20455L280%20386Z%20M351%20354L384%20400L376%20467L345%20451L335%20385Z'%20fill='%23bbc8e0'%20/%3e%3cpath%20d='M212%20377L181%20397L145%20480L112%20459L91%20490L136%20535Q158%20553%20175%20530L219%20450Z'%20fill='%23ede4e4'%20/%3e%3cpath%20d='M114%20464L105%20443L85%20431L79%20412Q74%20405%2070%20411L72%20433L61%20421Q52%20416%2052%20425L70%20451L63%20456L48%20451Q39%20454%2048%20463L78%20478L94%20491Z'%20fill='url(%23youngja-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='youngja-detail-3'%3e%3cpath%20d='M114%20464L105%20443L85%20431L79%20412Q74%20405%2070%20411L72%20433L61%20421Q52%20416%2052%20425L70%20451L63%20456L48%20451Q39%20454%2048%20463L78%20478L94%20491Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23youngja-detail-3)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M390%20375L422%20393L459%20473L490%20446L513%20474L470%20531Q449%20549%20431%20529L377%20443Z'%20fill='%23e2dce6'%20/%3e%3cpath%20d='M492%20449L499%20425L517%20413L522%20393Q529%20384%20532%20395L529%20418L541%20405Q550%20400%20552%20410L533%20438L542%20435L560%20427Q569%20428%20565%20438L539%20462L515%20477Z'%20fill='url(%23youngja-skin)'%20/%3e%3cdefs%3e%3cclipPath%20id='youngja-detail-4'%3e%3cpath%20d='M492%20449L499%20425L517%20413L522%20393Q529%20384%20532%20395L529%20418L541%20405Q550%20400%20552%20410L533%20438L542%20435L560%20427Q569%20428%20565%20438L539%20462L515%20477Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23youngja-detail-4)'%3e%3cpath%20d='M194%20389L207%20397L188%20436L170%20455L155%20457L181%20431Z%20M415%20396L428%20432L434%20467L423%20480L418%20437Z%20M175%20536L181%20548L173%20580L164%20580Z'%20fill='%23d68f9d'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M193%20409L176%20432M422%20425L429%20448'%20fill='none'%20stroke='%23ffe9cf'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M174%20536Q206%20719%20292%20803L238%20854Q159%20721%20157%20595Z'%20fill='%23659fc1'%20/%3e%3cpath%20d='M425%20522Q404%20700%20326%20781L377%20854Q477%20699%20455%20573Z'%20fill='%23d78892'%20/%3e%3cg%20transform='rotate(0%20310%20258)'%3e%3cpath%20d='M269%20291L267%20352L309%20379L354%20348L347%20287Z'%20fill='%23ffdbc4'%20/%3e%3cpath%20d='M271%20300L274%20328L311%20348L346%20320L345%20292Z'%20fill='%23dc929a'%20stroke='none'/%3e%3cpath%20d='M237%20199Q224%20195%20227%20222Q228%20244%20246%20247L251%20273Q268%20307%20303%20321Q316%20325%20331%20315Q365%20298%20377%20270L382%20205L355%20157L277%20157Z'%20fill='%23ffdbc4'%20/%3e%3cpath%20d='M241%20204L253%20220L259%20256L280%20298L300%20317Q265%20306%20251%20276Z%20M365%20203L370%20240L365%20273L344%20300Q371%20286%20379%20267L382%20210Z'%20fill='%23dc929a'%20stroke='none'/%3e%3cpath%20d='M233%20211L241%20216L241%20232'%20fill='none'%20stroke='%23b77d8d'%20stroke-width='1.5'/%3e%3cdefs%3e%3cclipPath%20id='youngja-eye-277'%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M255%20238Q277%20219%20298%20234Q279%20253%20258%20247Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23youngja-eye-277)'%3e%3cellipse%20cx='279'%20cy='238'%20rx='11'%20ry='16'%20fill='url(%23youngja-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='280'%20cy='234'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='275'%20cy='231'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M274%20248l8-3'%20fill='none'%20stroke='%23b87559'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M254%20238Q275%20218%20299%20234'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M256%20237l-5-6M259%20234l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M261%20217q13-9%2028-3'%20fill='none'%20stroke='%23aaa7c4'%20stroke-width='3'/%3e%3cdefs%3e%3cclipPath%20id='youngja-eye-341'%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cpath%20d='M319%20235Q341%20215%20362%20231Q343%20250%20322%20244Z'%20fill='%23fff7ed'%20stroke='none'/%3e%3cg%20clip-path='url(%23youngja-eye-341)'%3e%3cellipse%20cx='343'%20cy='235'%20rx='11'%20ry='16'%20fill='url(%23youngja-iris)'%20stroke='%233e3c58'%20stroke-width='1'/%3e%3cellipse%20cx='344'%20cy='231'%20rx='3.5'%20ry='9'%20fill='%23343048'%20stroke='none'/%3e%3ccircle%20cx='339'%20cy='228'%20r='4'%20fill='%23fffcdf'/%3e%3cpath%20d='M338%20245l8-3'%20fill='none'%20stroke='%23b87559'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M318%20235Q339%20214%20363%20231'%20fill='none'%20stroke='%2339283f'%20stroke-width='4'/%3e%3cpath%20d='M320%20234l-5-6M323%20231l-3-6'%20fill='none'%20stroke='%2339283f'%20stroke-width='2'/%3e%3cpath%20d='M325%20214q13-9%2028-3'%20fill='none'%20stroke='%23aaa7c4'%20stroke-width='3'/%3e%3cpath%20d='M313%20240L305%20261L312%20264'%20fill='none'%20stroke='%23b87683'%20stroke-width='1.6'/%3e%3cpath%20d='M304%20260l4-3'%20fill='none'%20stroke='%23fff2d7'%20stroke-width='2.5'/%3e%3cpath%20d='M292%20286Q311%20280%20328%20284'%20fill='none'%20stroke='%23925265'%20stroke-width='2'/%3e%3cpath%20d='M241%20224Q250%20211%20263%20216L253%20235Z%20M356%20210Q374%20208%20378%20220L369%20239Z'%20fill='%23be7c89'%20stroke='none'%20opacity='.2'/%3e%3cpath%20d='M269%20271Q278%20277%20287%20273L286%20281Q276%20284%20267%20279Z%20M340%20267Q348%20270%20357%20266L356%20273Q346%20278%20339%20274Z'%20fill='%23f29c9d'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M262%20263l4-6M269%20266l4-6M276%20267l4-5M343%20261l4-6M350%20261l4-5'%20fill='none'%20stroke='%23d28a96'%20stroke-width='1.2'/%3e%3cpath%20d='M262%20253Q278%20259%20289%20251M330%20249Q346%20254%20357%20246'%20fill='none'%20stroke='%23bd8595'%20stroke-width='1'/%3e%3cpath%20d='M288%20303Q305%20313%20322%20303'%20fill='none'%20stroke='%23f8e2cd'%20stroke-width='2'/%3e%3cpath%20d='M286%20294q11%207%2020%204'%20fill='none'%20stroke='%23bd808d'%20stroke-width='0.9'/%3e%3c/g%3e%3cpath%20d='M236%20169Q273%20128%20324%20139Q381%20146%20390%20211L372%20280L360%20228L348%20181L333%20222L313%20194L303%20160L292%20218L273%20198L253%20245L237%20290L221%20241Z'%20fill='url(%23youngja-hair)'%20/%3e%3cdefs%3e%3cclipPath%20id='youngja-detail-5'%3e%3cpath%20d='M236%20169Q273%20128%20324%20139Q381%20146%20390%20211L372%20280L360%20228L348%20181L333%20222L313%20194L303%20160L292%20218L273%20198L253%20245L237%20290L221%20241Z'%20fill='white'%20/%3e%3c/clipPath%3e%3c/defs%3e%3cg%20clip-path='url(%23youngja-detail-5)'%3e%3cpath%20d='M221%20165Q265%20108%20309%20141Q274%20151%20256%20191L237%20258L232%20291L226%20246Z'%20fill='%23aaa7c4'%20stroke='none'%20opacity='.45'/%3e%3cpath%20d='M305%20143Q334%20136%20359%20158L378%20211L366%20238L352%20183L332%20169Z'%20fill='%23f4e5d6'%20stroke='none'%20opacity='.5'/%3e%3cpath%20d='M240%20180Q260%20149%20280%20154L265%20173L250%20212Z%20M300%20151L305%20186L294%20212L295%20176Z%20M340%20158Q365%20174%20370%20208L357%20194Z'%20fill='%23fff3d1'%20stroke='none'%20opacity='.32'/%3e%3cpath%20d='M246%20169Q231%20212%20237%20249M258%20160Q251%20183%20252%20205M279%20151Q271%20174%20276%20200M297%20153Q288%20182%20286%20199M320%20150Q337%20173%20339%20203M348%20166Q370%20203%20369%20241'%20fill='none'%20stroke='%23aaa7c4'%20stroke-width='1.4'/%3e%3cpath%20d='M242%20239L237%20265M252%20199L247%20227M276%20188L279%20203M329%20181L335%20197M365%20220L369%20243'%20fill='none'%20stroke='%23fff4db'%20stroke-width='1.1'/%3e%3cpath%20d='M215%20268Q220%20318%20207%20355M394%20249Q387%20292%20405%20332M226%20329L215%20384M398%20316L408%20360'%20fill='none'%20stroke='%23aaa7c4'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M252%20164L236%20228M281%20150L275%20193M317%20147L329%20195M354%20163L371%20223'%20fill='none'%20stroke='%23fff7dd'%20stroke-width='3'/%3e%3cpath%20d='M245%20151L233%2093L271%20121L294%2035L314%20126L348%2075L344%20151L303%20165Z'%20fill='%23efdfd5'%20/%3e%3cpath%20d='M284%20137L297%2063L304%20143'%20fill='none'%20stroke='%23fff8df'%20stroke-width='3'/%3e%3cpath%20d='M268%20316Q282%20309%20287%20337L280%20365L263%20361L254%20338Z%20M348%20313Q365%20313%20369%20339L359%20365L344%20354L340%20334Z'%20fill='%23273c66'%20/%3e%3cpath%20d='M270%20328L269%20348M355%20327L356%20348'%20fill='none'%20stroke='%2380c5dc'%20stroke-width='4'/%3e%3cpath%20d='M300%20376L317%20375L328%20396L315%20415L299%20400Z'%20fill='%23244d7c'%20/%3e%3cpath%20d='M308%20409L326%20429L318%20512L295%20538L289%20501L299%20431Z'%20fill='%23326394'%20/%3e%3cpath%20d='M309%20426L309%20502'%20fill='none'%20stroke='%239ae2e3'%20stroke-width='3'/%3e%3cpath%20d='M267%20586L337%20588L352%20641L276%20647Z'%20fill='%23466590'%20/%3e%3cpath%20d='M271%20601L343%20603'%20fill='none'%20stroke='%23a4cada'%20stroke-width='4'/%3e%3c/g%3e%3c/symbol%3e%3c/defs%3e%3c/svg%3e", it = {
	R: "#f64b65",
	B: "#58b8ff",
	G: "#9bdc68",
	Y: "#ffc65a",
	P: "#ed80cf"
}, at = {
	R: "#bb2547",
	B: "#2864a8",
	G: "#477c3e",
	Y: "#a9661b",
	P: "#aa3b8e"
}, ot = {
	esfir: "#bcafff",
	adelheid: "#ffbd81",
	ekolu: "#a4efed",
	lingling: "#81f0fa",
	mariel: "#ebbae9",
	rie: "#ffb36d",
	senka: "#a3c8ff",
	youngja: "#9ae4e7"
}, st = "M21 72C10 49 28 38 25 23L38 35L49 5L57 31L68 16L67 39L80 32C75 42 89 58 79 75C68 93 34 96 21 72Z", ct = "M50 4L62 34L95 36L70 57L79 90L50 72L21 90L30 57L5 36L38 34Z";
function lt({ heroine: e, className: t = "" }) {
	return /* @__PURE__ */ d("svg", {
		className: `bullet-portrait ${t}`,
		viewBox: "0 0 620 1080",
		"aria-hidden": "true",
		children: /* @__PURE__ */ d("use", { href: `${rt}#hero-${e}` })
	});
}
function ut({ empty: e = !1 }) {
	return /* @__PURE__ */ d("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		className: e ? "bullet-heart is-empty" : "bullet-heart",
		children: /* @__PURE__ */ d("path", { d: "M12 21C9 18 1 13 1 7C1 0 9-1 12 5C15-1 23 0 23 7C23 13 15 18 12 21Z" })
	});
}
function B({ id: e, faceDown: t = !1, className: n = "" }) {
	let r = g(e), i = it[r.color];
	return /* @__PURE__ */ f("svg", {
		className: `bullet-chip ${n}`,
		viewBox: "0 0 100 100",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ d("circle", {
				cx: "50",
				cy: "52",
				r: "49",
				fill: "#041b28"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "50",
				cy: "50",
				r: "48",
				fill: t ? "#192638" : i,
				stroke: t ? "#77919e" : "#fcf3df",
				strokeWidth: "1.8"
			}),
			t ? /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("circle", {
					cx: "50",
					cy: "50",
					r: "37",
					fill: "none",
					stroke: "#b2bcc5",
					strokeWidth: "1",
					strokeDasharray: "3 3"
				}),
				/* @__PURE__ */ d("path", {
					d: "M50 21L73 50L50 79L27 50Z",
					fill: "#506576"
				}),
				/* @__PURE__ */ d("text", {
					x: "50",
					y: "65",
					fill: "#f3efec",
					fontSize: "44",
					textAnchor: "middle",
					fontWeight: "800",
					children: "?"
				})
			] }) : /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("circle", {
					cx: "50",
					cy: "50",
					r: "43",
					fill: "none",
					stroke: "#0c2634",
					strokeOpacity: ".23"
				}),
				/* @__PURE__ */ d("path", {
					d: st,
					fill: "#fff9e9"
				}),
				r.color === "B" && /* @__PURE__ */ d("path", {
					d: "M16 39L14 24L24 36M84 39L86 24L76 36",
					stroke: "#fff9e9",
					strokeWidth: "3",
					fill: "none"
				}),
				r.star && /* @__PURE__ */ d("path", {
					d: ct,
					transform: "translate(10 17) scale(.8)",
					fill: i,
					stroke: "#fff9e9",
					strokeWidth: "2.5"
				}),
				/* @__PURE__ */ d("text", {
					x: "50",
					y: "77",
					fill: r.star ? "#fff9e9" : at[r.color],
					fontSize: "52",
					textAnchor: "middle",
					fontWeight: "850",
					children: r.num
				})
			] })
		]
	});
}
function dt({ color: e }) {
	return /* @__PURE__ */ f("svg", {
		className: "bullet-ring",
		viewBox: "0 0 100 100",
		style: { color: it[e] },
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ d("circle", {
				cx: "50",
				cy: "50",
				r: "43",
				fill: "#0d2634",
				fillOpacity: ".64",
				stroke: "currentColor",
				strokeOpacity: ".22",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "50",
				cy: "50",
				r: "40",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.5",
				strokeDasharray: "21 6 42 7 21 6 42 7",
				transform: "rotate(-32 50 50)"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "50",
				cy: "50",
				r: "35",
				fill: "none",
				stroke: "currentColor",
				strokeDasharray: ".6 3",
				strokeWidth: ".5",
				opacity: ".24"
			})
		]
	});
}
function ft({ sym: e }) {
	let t = it[e];
	if (e === " ") return null;
	if (t) return /* @__PURE__ */ d("circle", {
		cx: "20",
		cy: "20",
		r: "11",
		fill: t,
		stroke: "#fff4e2",
		strokeWidth: "1"
	});
	let n = e.startsWith("("), r = e.replace(/[()]/g, "");
	return /* @__PURE__ */ f("g", {
		fill: "none",
		stroke: "#f6f2e8",
		strokeWidth: "2.4",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			n && /* @__PURE__ */ d("circle", {
				cx: "20",
				cy: "20",
				r: "17",
				strokeWidth: "1",
				opacity: ".6"
			}),
			r === "O" && /* @__PURE__ */ d("circle", {
				cx: "20",
				cy: "20",
				r: "11"
			}),
			r === "X" && /* @__PURE__ */ d("path", {
				d: "M9 9L31 31M31 9L9 31",
				strokeWidth: "3.5"
			}),
			r === "_" && /* @__PURE__ */ d("rect", {
				x: "7",
				y: "7",
				width: "26",
				height: "26",
				strokeDasharray: "3 3",
				strokeWidth: "1.5"
			}),
			r === "/" && /* @__PURE__ */ d("path", {
				d: "M8 32L32 8M9 9L31 31",
				opacity: ".65"
			}),
			r === "=" && /* @__PURE__ */ d("path", { d: "M8 15H32M8 25H32" }),
			r === "+" && /* @__PURE__ */ d("path", {
				d: "M20 7V33M7 20H33",
				stroke: "#ffe4a3"
			}),
			r === "C" && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", {
				cx: "20",
				cy: "20",
				r: "10",
				stroke: "#ffbd8e"
			}), /* @__PURE__ */ d("path", {
				d: "M20 3V13M20 27V37M3 20H13M27 20H37",
				stroke: "#ffbd8e"
			})] }),
			"1234".includes(r) && /* @__PURE__ */ d("text", {
				x: "20",
				y: "31",
				fill: "#f6f2e8",
				stroke: "none",
				fontSize: "30",
				fontWeight: "800",
				textAnchor: "middle",
				children: r
			}),
			[
				"<",
				">",
				"v",
				"<v",
				"v>"
			].includes(r) && /* @__PURE__ */ d("g", {
				transform: `rotate(${{
					"<": -90,
					">": 90,
					v: 0,
					"<v": -45,
					"v>": 45
				}[r]} 20 20)`,
				children: /* @__PURE__ */ d("path", {
					d: "M20 33V7M9 18L20 7L31 18",
					stroke: "#d6c3ff"
				})
			})
		]
	});
}
function pt({ grid: e, colorTag: t }) {
	let n = Math.max(...e.map((e) => e.length)), r = e.length;
	return /* @__PURE__ */ f("svg", {
		className: "bullet-pattern",
		viewBox: `0 0 ${n * 40 + 8} ${r * 40 + 8}`,
		"aria-hidden": "true",
		style: { "--bullet-pattern-ratio": `${n}/${r}` },
		children: [t && /* @__PURE__ */ d("rect", {
			x: "4",
			y: "0",
			width: n * 40,
			height: "5",
			rx: "2",
			fill: it[t]
		}), e.flatMap((e, t) => e.map((e, n) => /* @__PURE__ */ d("g", {
			transform: `translate(${n * 40 + 4} ${t * 40 + 4})`,
			children: /* @__PURE__ */ d(ft, { sym: e })
		}, `${t}-${n}`)))]
	});
}
function mt({ cross: e = !1 }) {
	return /* @__PURE__ */ d("svg", {
		className: e ? "bullet-cross" : "bullet-mariel",
		viewBox: "0 0 100 100",
		"aria-hidden": "true",
		children: e ? /* @__PURE__ */ f("g", {
			fill: "none",
			stroke: "#ffbd8e",
			strokeWidth: "3",
			children: [
				/* @__PURE__ */ d("circle", {
					cx: "50",
					cy: "50",
					r: "31"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "50",
					cy: "50",
					r: "17"
				}),
				/* @__PURE__ */ d("path", { d: "M50 4V30M50 70V96M4 50H30M70 50H96" })
			]
		}) : /* @__PURE__ */ f("g", {
			stroke: "#f6e5f5",
			strokeWidth: "2",
			children: [
				/* @__PURE__ */ d("path", {
					d: "M50 7L89 73L52 61L14 77Z",
					fill: "#d5addb"
				}),
				/* @__PURE__ */ d("path", {
					d: "M50 7L52 61L89 73L56 43Z",
					fill: "#faf0e4"
				}),
				/* @__PURE__ */ d("path", {
					d: "M14 77L56 43L52 61Z",
					fill: "#9574bc"
				})
			]
		})
	});
}
function ht() {
	return /* @__PURE__ */ f("span", {
		className: "bullet-brand",
		"aria-label": "Bullet Heart",
		children: [/* @__PURE__ */ f("b", { children: ["BULLET", /* @__PURE__ */ d(ut, {})] }), /* @__PURE__ */ d("small", { children: "H E A R T" })]
	});
}
//#endregion
//#region src/games/bullet/view-player.tsx
var gt = [
	"R",
	"B",
	"G",
	"Y",
	"P"
];
function _t(e) {
	let t = e.public, n = e.private, r = t.players.find((t) => t.rid === e.myRid);
	return t.phase === "pick" ? /* @__PURE__ */ d(vt, {
		pub: t,
		myRid: e.myRid,
		send: e.send
	}) : !r?.heroine || !n ? null : /* @__PURE__ */ d(yt, {
		pub: t,
		priv: n,
		me: r,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function vt({ pub: e, myRid: t, send: n }) {
	let r = a(), o = e.players.find((e) => e.rid === t), s = new Set(e.players.map((e) => e.heroine)), [u, p] = i([]), m = o?.heroine === "mariel" ? 1 : 2, h = o?.pending === "markers", g = h ? o?.heroine === "mariel" ? r("games.bullet.placeMarielMarker") : r("games.bullet.placeCrosshairs") : o?.heroine ? r("games.bullet.pickWaiting") : r("games.bullet.pickTitle");
	return /* @__PURE__ */ d(l, {
		adaptive: !0,
		className: "bullet-screen bullet-pick-screen",
		banner: /* @__PURE__ */ f("div", {
			className: "bullet-pick-heading",
			children: [/* @__PURE__ */ d(ht, {}), /* @__PURE__ */ d(c, {
				tone: o?.heroine ? "info" : "accent",
				text: g,
				accent: ce.accent
			})]
		}),
		children: h && o?.heroine ? /* @__PURE__ */ f("div", {
			className: "bullet-marker-area",
			children: [/* @__PURE__ */ d(lt, { heroine: o.heroine }), /* @__PURE__ */ d("div", {
				className: "bullet-marker-grid",
				children: Array.from({ length: 30 }, (e, t) => /* @__PURE__ */ f("button", {
					type: "button",
					"aria-label": r("games.bullet.cellLabel", {
						row: Math.floor(t / 5) + 1,
						col: t % 5 + 1
					}),
					className: u.includes(t) ? "is-picked" : "",
					onClick: () => {
						let e = u.includes(t) ? u.filter((e) => e !== t) : u.length < m ? [...u, t] : u;
						p(e), e.length === m && n({
							type: "placeMarkers",
							cells: e
						});
					},
					children: [/* @__PURE__ */ d(dt, { color: gt[t % 5] }), u.includes(t) && /* @__PURE__ */ d(mt, { cross: o.heroine !== "mariel" })]
				}, t))
			})]
		}) : o?.heroine ? /* @__PURE__ */ f("div", {
			className: "bullet-hero-waiting",
			children: [/* @__PURE__ */ d(lt, { heroine: o.heroine }), /* @__PURE__ */ f("div", { children: [
				/* @__PURE__ */ d("h2", { children: r(`games.bullet.hero.${o.heroine}.name`) }),
				/* @__PURE__ */ d("p", { children: r(`games.bullet.hero.${o.heroine}.title`) }),
				/* @__PURE__ */ d("b", { children: r(`games.bullet.hero.${o.heroine}.ua`) }),
				/* @__PURE__ */ d("p", { children: r(`games.bullet.hero.${o.heroine}.uaDesc`) })
			] })]
		}) : /* @__PURE__ */ d("div", {
			className: "bullet-hero-picker",
			children: Object.keys(C).map((e) => /* @__PURE__ */ f("button", {
				type: "button",
				disabled: s.has(e),
				className: "bullet-hero-card",
				onClick: () => n({
					type: "pick",
					heroine: e
				}),
				children: [/* @__PURE__ */ d("div", {
					className: "bullet-pick-portrait",
					children: /* @__PURE__ */ d(lt, { heroine: e })
				}), /* @__PURE__ */ f("div", {
					className: "bullet-pick-copy",
					children: [
						/* @__PURE__ */ d("span", {
							className: "bullet-difficulty",
							"aria-label": r("games.bullet.difficulty"),
							children: "★".repeat(C[e].difficulty)
						}),
						/* @__PURE__ */ d("h2", { children: r(`games.bullet.hero.${e}.name`) }),
						/* @__PURE__ */ d("p", { children: r(`games.bullet.hero.${e}.title`) }),
						/* @__PURE__ */ f("p", { children: [
							/* @__PURE__ */ d("b", { children: r(`games.bullet.hero.${e}.ua`) }),
							" ",
							r(`games.bullet.hero.${e}.uaDesc`)
						] }),
						/* @__PURE__ */ d("div", {
							className: "bullet-pick-patterns",
							children: C[e].patterns.slice(0, 3).map((e, t) => /* @__PURE__ */ d(pt, {
								grid: e.grid,
								colorTag: e.color
							}, t))
						})
					]
				})]
			}, e))
		})
	});
}
function yt({ pub: e, priv: t, me: n, members: r, myRid: o, send: s }) {
	let c = a(), [p, m] = i(null), [h, g] = i(!1), [_, v] = i(null), [y, b] = i(null), [te, ne] = i(void 0), [x, re] = i([]), ie = `${e.phase}:${e.round}`, [ae, oe] = i(ie);
	ie !== ae && (oe(ie), m(null), v(null), b(null), ne(void 0), re([]));
	let S = C[n.heroine], w = e.phase === "sudden", T = e.phase === "end", le = w && (e.sudden ?? []).includes(o), E = e.phase === "play" && n.alive && !n.done && n.pending === null, D = n.pending, ue = "info", O;
	w ? (ue = "warn", O = c("games.bullet.suddenDeath")) : n.alive ? T ? (ue = n.endDone ? "info" : "accent", O = n.endDone ? c("games.bullet.endWaiting") : c("games.bullet.endPhaseTitle")) : D === "resolve" ? O = "" : D ? (ue = "warn", O = c(D === "rie" ? "games.bullet.riePickPrompt" : D === "star" ? "games.bullet.starChoicePrompt" : "games.bullet.placeMarielMarker")) : n.done ? O = c("games.bullet.waitingDone") : (ue = "accent", O = n.current > 0 ? "" : c("games.bullet.endTurn")) : O = c("games.bullet.eliminated");
	let k = null;
	if (D === "mariel") k = c("games.bullet.placeMarielMarker");
	else if (D === "star") k = c("games.bullet.starChoicePrompt");
	else if (E && p) {
		if (p.kind === "pattern") k = p.origin === null ? c("games.bullet.hintOrigin") : S.ua === "calculating" ? c("games.bullet.bonusClearPrompt", { n: 3 }) : c("games.bullet.confirmClear");
		else if (p.kind === "act") {
			let e = S.actions[p.idx];
			k = e.t === "move" || e.t === "push" ? p.from === null ? c("games.bullet.hintFrom") : c("games.bullet.hintTo") : e.t === "moveCross" ? p.from === null ? c("games.bullet.hintCrossFrom") : c("games.bullet.hintTo") : e.t === "discardDraw" ? c("games.bullet.act.discardDraw") : e.t === "clearLife" ? c("games.bullet.hintLife") : c("games.bullet.hintCell");
		} else {
			let e = p.copySlot === null ? n.powerups[p.slot] : n.powerups[p.copySlot];
			k = e === "moveAny" ? p.cells.length === 0 ? c("games.bullet.hintFrom") : c("games.bullet.hintTo") : c(e === "swap" ? "games.bullet.hintSwap" : e === "putTwo" ? "games.bullet.hintPutTwo" : "games.bullet.hintCell");
		}
	}
	let de = (e) => {
		if (D === "mariel") {
			s({
				type: "marielRelocate",
				cell: e
			});
			return;
		}
		if (D === "star") {
			let r = t.starQueue[0];
			if (r === "flip") s({
				type: "starResolve",
				cell: e
			});
			else if (r === "moveCross1") {
				let t = n.crosshairs?.indexOf(e) ?? -1;
				_ === null ? t >= 0 && v(e) : (s({
					type: "starResolve",
					cross: n.crosshairs?.indexOf(_) ?? 0,
					to: e
				}), v(null));
			}
			return;
		}
		if (!E || !p) return;
		if (p.kind === "pattern") {
			if (p.origin === null) m({
				...p,
				origin: e
			});
			else if (S.ua === "calculating") {
				let t = p.bonus.includes(e) ? p.bonus.filter((t) => t !== e) : p.bonus.length < 3 ? [...p.bonus, e] : p.bonus;
				m({
					...p,
					bonus: t
				});
			}
			return;
		}
		if (p.kind === "act") {
			let t = S.actions[p.idx];
			if (t.t === "move" || t.t === "push") {
				p.from === null ? m({
					...p,
					from: e
				}) : (s({
					type: "act",
					idx: p.idx,
					cell: p.from,
					to: e
				}), m(null));
				return;
			}
			if (t.t === "placeCenter" || t.t === "moveMarker" || t.t === "clearAdj") {
				s({
					type: "act",
					idx: p.idx,
					cell: e
				}), m(null);
				return;
			}
			if (t.t === "moveCross") {
				let t = n.crosshairs?.indexOf(e) ?? -1;
				p.from === null ? t >= 0 && m({
					...p,
					from: e
				}) : (s({
					type: "act",
					idx: p.idx,
					cross: n.crosshairs?.indexOf(p.from) ?? 0,
					to: e
				}), m(null));
				return;
			}
			return;
		}
		let r = p.copySlot === null ? n.powerups[p.slot] : n.powerups[p.copySlot];
		if (r === "clearSight") {
			s({
				type: "powerup",
				slot: p.slot,
				copySlot: p.copySlot ?? void 0,
				cell: e
			}), m(null);
			return;
		}
		if (r === "moveAny") {
			p.cells.length === 0 ? m({
				...p,
				cells: [e]
			}) : (s({
				type: "powerup",
				slot: p.slot,
				copySlot: p.copySlot ?? void 0,
				cell: p.cells[0],
				to: e
			}), m(null));
			return;
		}
		if (r === "swap" || r === "putTwo") {
			let t = [...p.cells, e];
			t.length === 2 ? (s(r === "swap" ? {
				type: "powerup",
				slot: p.slot,
				copySlot: p.copySlot ?? void 0,
				a: t[0],
				b: t[1]
			} : {
				type: "powerup",
				slot: p.slot,
				copySlot: p.copySlot ?? void 0,
				cells: t
			}), m(null)) : m({
				...p,
				cells: t
			});
			return;
		}
	}, fe = (e) => {
		if (E) {
			if (p?.kind === "act" && S.actions[p.idx].t === "discardDraw") {
				s({
					type: "act",
					idx: p.idx,
					card: e
				}), m(null);
				return;
			}
			if (S.ua === "crosshair") {
				s({
					type: "usePattern",
					card: e
				});
				return;
			}
			m(p?.kind === "pattern" && p.card === e ? null : {
				kind: "pattern",
				card: e,
				origin: null,
				bonus: []
			});
		}
	}, pe = () => {
		p?.kind === "pattern" && p.origin !== null && (s({
			type: "usePattern",
			card: p.card,
			origin: p.origin,
			bonus: p.bonus.length > 0 ? p.bonus : void 0
		}), m(null));
	}, A = (e) => {
		if (g(!1), !E) return;
		let t = S.actions[e];
		if (!(n.ap < t.cost)) {
			if (t.t === "draw" || t.t === "boostNext" || t.t === "anyNext" || t.t === "reveal") {
				s({
					type: "act",
					idx: e
				});
				return;
			}
			m(p?.kind === "act" && p.idx === e ? null : {
				kind: "act",
				idx: e,
				from: null
			});
		}
	}, j = (t) => {
		if (g(!1), !E || e.mode !== "ffa") return;
		let r = n.powerups[t];
		if (r) {
			if (r === "gainAp" || r === "drawCard" || r === "drawDiscard" || r === "clearCenter") {
				s({
					type: "powerup",
					slot: t
				});
				return;
			}
			m(p?.kind === "power" && p.slot === t ? null : {
				kind: "power",
				slot: t,
				copySlot: null,
				cells: []
			});
		}
	}, me = (e) => {
		if (p?.kind !== "power") return;
		let t = n.powerups[e];
		if (t && t !== "copy") {
			if (t === "gainAp" || t === "drawCard" || t === "drawDiscard" || t === "clearCenter") {
				s({
					type: "powerup",
					slot: p.slot,
					copySlot: e
				}), m(null);
				return;
			}
			m({
				...p,
				copySlot: e,
				cells: []
			});
		}
	}, M = Math.max(0, t.hand.length - S.handSize), N = n.powerups.every((e) => e !== null), he = () => {
		s({
			type: "endPhase",
			take: y,
			replaceSlot: te,
			discard: x
		});
	}, P = /* @__PURE__ */ new Set();
	if (p?.kind === "act" && p.from !== null && P.add(p.from), p?.kind === "power") for (let e of p.cells) P.add(e);
	_ !== null && P.add(_);
	let ge = {
		heroine: n.heroine,
		sight: n.sight.map((e) => e ? {
			id: e.id,
			fd: e.faceDown
		} : null),
		mariel: n.mariel,
		crosshairs: n.crosshairs
	}, F = p?.kind === "pattern" ? S.patterns[t.hand[p.card]] : null, I = F && p?.kind === "pattern" ? Ae(n.heroine, t.hand[p.card], ge) : [], L = /* @__PURE__ */ new Map();
	if (F && p?.kind === "pattern" && p.origin !== null && F.grid.forEach((e, t) => e.forEach((e, n) => {
		let r = Math.floor(p.origin / 5) + t, i = p.origin % 5 + n;
		r >= 0 && r < 6 && i >= 0 && i < 5 && e !== " " && L.set(r * 5 + i, e);
	})), p?.kind === "pattern") for (let e of p.bonus) P.add(e);
	let R = p?.kind === "pattern" || D === "star", z = /* @__PURE__ */ f(u, { children: [
		(!w || le) && /* @__PURE__ */ f("button", {
			type: "button",
			className: "bullet-main-place",
			disabled: w ? !le || !!D : !E || n.current === 0,
			onClick: () => s({ type: "place" }),
			children: [
				c("games.bullet.placeBullet"),
				" ",
				/* @__PURE__ */ d("b", { children: n.current })
			]
		}),
		!w && /* @__PURE__ */ d("button", {
			type: "button",
			className: "bullet-mobile-action-toggle",
			"aria-expanded": h,
			"aria-label": c("games.bullet.actionsTitle"),
			disabled: !E,
			onClick: () => g(!h),
			children: c("games.bullet.actionsTitle")
		}),
		!w && /* @__PURE__ */ d("button", {
			type: "button",
			className: R ? "bullet-finish has-phone-choice" : "bullet-finish",
			disabled: !E || n.current > 0,
			onClick: () => s({ type: "endTurn" }),
			children: c("games.bullet.endTurn")
		}),
		p?.kind === "pattern" && /* @__PURE__ */ d("button", {
			type: "button",
			className: "bullet-phone-confirm",
			disabled: !E || p.origin === null,
			onClick: pe,
			children: c("games.bullet.confirmClear")
		}),
		D === "star" && /* @__PURE__ */ d("button", {
			type: "button",
			className: "bullet-phone-confirm",
			onClick: () => s({
				type: "starResolve",
				skip: !0
			}),
			children: c("games.bullet.starSkip")
		}),
		p && /* @__PURE__ */ d("button", {
			type: "button",
			className: "bullet-phone-cancel",
			onClick: () => m(null),
			children: c("games.bullet.cancel")
		})
	] });
	return /* @__PURE__ */ d(l, {
		adaptive: !0,
		scroll: !1,
		className: "bullet-screen",
		banner: /* @__PURE__ */ f("div", {
			className: "bullet-topbar",
			children: [
				/* @__PURE__ */ d(ht, {}),
				/* @__PURE__ */ f("div", {
					className: "bullet-round",
					children: [/* @__PURE__ */ d("b", { children: c("games.bullet.round", { n: e.round }) }), /* @__PURE__ */ d("span", { children: c("games.bullet.intensity", { n: e.intensity + (e.mode === "score" ? e.scoreTrack : 0) }) })]
				}),
				/* @__PURE__ */ d("div", {
					className: "bullet-players",
					children: e.players.map((e) => /* @__PURE__ */ d(xt, {
						p: e,
						member: r.find((t) => t.rid === e.rid),
						own: e.rid === o
					}, e.rid))
				})
			]
		}),
		children: /* @__PURE__ */ f("div", {
			className: "bullet-play-layout",
			children: [
				/* @__PURE__ */ d(Ct, { me: n }),
				/* @__PURE__ */ f("div", {
					className: "bullet-board",
					children: [
						/* @__PURE__ */ f("div", {
							className: "bullet-board-heading",
							children: [
								/* @__PURE__ */ f(V, {
									name: `bag:${o}`,
									className: "bullet-bag",
									children: [/* @__PURE__ */ d("span", { children: c("games.bullet.currentBag") }), /* @__PURE__ */ d("b", { children: n.current })]
								}),
								/* @__PURE__ */ f(V, {
									name: `center:${o}`,
									className: "bullet-center",
									children: [/* @__PURE__ */ d("span", { children: c("games.bullet.centerBag") }), /* @__PURE__ */ d("b", { children: e.center })]
								}),
								/* @__PURE__ */ f(V, {
									name: `incoming:${o}`,
									className: "bullet-incoming",
									children: [/* @__PURE__ */ d("span", { children: c("games.bullet.incomingBag") }), /* @__PURE__ */ d("b", { children: n.incoming })]
								})
							]
						}),
						/* @__PURE__ */ d("div", {
							className: "bullet-board-space",
							children: /* @__PURE__ */ f("div", {
								className: "bullet-sight",
								children: [/* @__PURE__ */ d("div", {
									className: "bullet-colors",
									children: gt.map((e) => /* @__PURE__ */ d("span", {
										style: { "--bullet-column": it[e] },
										children: /* @__PURE__ */ f("svg", {
											viewBox: "0 0 100 100",
											"aria-hidden": "true",
											children: [/* @__PURE__ */ d("circle", {
												cx: "50",
												cy: "50",
												r: "46",
												fill: "currentColor"
											}), /* @__PURE__ */ d("path", {
												d: "M25 65L28 35L40 44L50 12L61 42L76 30L77 63Q50 86 25 65Z",
												fill: "#fff8eb"
											})]
										})
									}, e))
								}), /* @__PURE__ */ d("div", {
									className: "bullet-cells",
									children: n.sight.map((e, t) => /* @__PURE__ */ d(Tt, {
										rid: o,
										index: t,
										bullet: e,
										mariel: n.mariel === t,
										cross: n.crosshairs?.includes(t) ?? !1,
										picked: P.has(t),
										origin: !!F && p?.kind === "pattern" && p.origin === null && I.includes(t),
										preview: L.get(t),
										interactive: E || D === "star" || D === "mariel",
										onClick: () => de(t)
									}, t))
								})]
							})
						}),
						/* @__PURE__ */ d("div", {
							className: "bullet-board-footer",
							children: /* @__PURE__ */ d("span", {
								className: "bullet-hint",
								"data-tone": ue,
								role: "status",
								children: k ?? O
							})
						}),
						T && !n.endDone && n.alive && /* @__PURE__ */ f("div", {
							className: "bullet-end-panel absolute inset-0 z-20 flex flex-col gap-2 overflow-y-auto bg-surface/95 p-3",
							children: [
								e.mode === "ffa" && /* @__PURE__ */ f("div", {
									className: "flex flex-wrap items-center gap-1",
									children: [
										/* @__PURE__ */ d("span", {
											className: "flex-none text-[10px] font-bold text-ink/60",
											children: c("games.bullet.endTakePowerup")
										}),
										e.centerPowerups.map((e, t) => /* @__PURE__ */ d("button", {
											type: "button",
											onClick: () => b(y === t ? null : t),
											className: `btn-quiet flex-none text-[11px] ${y === t ? "ring-2 ring-pink-500" : ""}`,
											children: c(se[e])
										}, t)),
										/* @__PURE__ */ d("button", {
											type: "button",
											onClick: () => b(null),
											className: `btn-quiet flex-none text-[11px] ${y === null ? "ring-2 ring-pink-500" : ""}`,
											children: c("games.bullet.endNoPowerup")
										})
									]
								}),
								N && y !== null && /* @__PURE__ */ f("div", {
									className: "flex flex-wrap items-center gap-1",
									children: [/* @__PURE__ */ d("span", {
										className: "text-[10px] font-bold text-ink/60",
										children: c("games.bullet.endReplace")
									}), n.powerups.map((e, t) => /* @__PURE__ */ d("button", {
										type: "button",
										onClick: () => ne(t),
										className: `btn-quiet text-[11px] ${te === t ? "ring-2 ring-pink-500" : ""}`,
										children: e ? c(se[e]) : "·"
									}, t))]
								}),
								M > 0 && /* @__PURE__ */ f("div", {
									className: "flex flex-wrap items-center gap-1",
									children: [/* @__PURE__ */ d("span", {
										className: "flex-none text-[10px] font-bold text-warn-ink",
										children: c("games.bullet.endDiscardDown", { n: M })
									}), t.hand.map((e, t) => /* @__PURE__ */ d("button", {
										type: "button",
										onClick: () => re(x.includes(t) ? x.filter((e) => e !== t) : x.length < M ? [...x, t] : x),
										className: `btn-quiet flex-none text-[11px] ${x.includes(t) ? "ring-2 ring-rose-500" : ""}`,
										children: c(S.patterns[e].key)
									}, t))]
								}),
								/* @__PURE__ */ d("button", {
									type: "button",
									disabled: x.length !== M || N && y !== null && te === void 0,
									onClick: he,
									className: "btn-base mt-auto min-h-12 w-full",
									style: { backgroundColor: ce.accent },
									children: c("games.bullet.endSubmit")
								})
							]
						}),
						D === "rie" && t.rieOptions && /* @__PURE__ */ d("div", {
							className: "bullet-rie-panel absolute inset-0 z-20 grid place-items-center bg-surface/80",
							children: /* @__PURE__ */ d("div", {
								className: "card flex items-center gap-4 p-4",
								children: t.rieOptions.map((e, t) => /* @__PURE__ */ d("button", {
									type: "button",
									"aria-label": bt(e, !1, c),
									onClick: () => s({
										type: "riePick",
										idx: t
									}),
									className: "bullet-rie-option grid size-16 place-items-center rounded-xl border-2 border-ink bg-surface shadow-[2px_2px_0_var(--color-ink)] active:translate-y-0.5",
									children: /* @__PURE__ */ d(V, {
										name: `rie:${o}:${t}`,
										children: /* @__PURE__ */ d(B, { id: e })
									})
								}, t))
							})
						}),
						(p !== null || D === "star") && /* @__PURE__ */ f("div", {
							className: `bullet-confirm ${p?.kind === "pattern" || D === "star" ? "is-simple" : ""} absolute inset-x-2 bottom-2 z-10 flex flex-wrap items-center justify-center gap-2 rounded-xl border-2 border-ink bg-surface/95 p-2 shadow-[3px_3px_0_var(--color-ink)]`,
							children: [
								D === "star" && /* @__PURE__ */ d("button", {
									type: "button",
									onClick: () => {
										s({
											type: "starResolve",
											skip: !0
										}), v(null);
									},
									className: "btn-quiet min-h-11 px-4",
									children: c("games.bullet.starSkip")
								}),
								p?.kind === "pattern" && /* @__PURE__ */ d("button", {
									type: "button",
									disabled: p.origin === null,
									onClick: pe,
									className: "btn-base min-h-11 px-4",
									style: { backgroundColor: ce.accent },
									children: c("games.bullet.confirmClear")
								}),
								p?.kind === "act" && S.actions[p.idx].t === "clearLife" && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("span", {
									className: "text-[10px] font-bold text-ink/60",
									children: c("games.bullet.lifeRow")
								}), n.lifeBullets.map((e, t) => /* @__PURE__ */ d("button", {
									type: "button",
									"aria-label": bt(e, !1, c),
									onClick: () => {
										s({
											type: "act",
											idx: p.idx,
											card: t
										}), m(null);
									},
									className: "bullet-life-option grid size-11 place-items-center rounded-lg border-2 border-ink bg-surface",
									children: /* @__PURE__ */ d(B, { id: e })
								}, t))] }),
								p?.kind === "power" && n.powerups[p.slot] === "copy" && p.copySlot === null && n.powerups.map((e, t) => e && t !== p.slot && e !== "copy" ? /* @__PURE__ */ d("button", {
									type: "button",
									onClick: () => me(t),
									className: "btn-quiet text-[11px]",
									children: c(se[e])
								}, t) : null),
								p !== null && /* @__PURE__ */ d("button", {
									type: "button",
									onClick: () => {
										m(null), v(null);
									},
									className: "btn-quiet min-h-11 px-4",
									children: c("games.bullet.cancel")
								})
							]
						})
					]
				}),
				/* @__PURE__ */ f("div", {
					className: `bullet-rail ${h ? "is-open" : ""}`,
					children: [
						/* @__PURE__ */ f("div", {
							className: "bullet-resource",
							children: [/* @__PURE__ */ d("span", { children: c("games.bullet.actionPoints") }), /* @__PURE__ */ d(St, {
								me: n,
								variant: "rail"
							})]
						}),
						/* @__PURE__ */ f("div", {
							className: "bullet-action-drawer",
							children: [
								/* @__PURE__ */ d("div", {
									className: "bullet-action-list",
									children: S.actions.map((e, t) => /* @__PURE__ */ f("button", {
										type: "button",
										disabled: !E || n.ap < e.cost,
										onClick: () => A(t),
										className: p?.kind === "act" && p.idx === t ? "bullet-action-card is-picked" : "bullet-action-card",
										children: [
											/* @__PURE__ */ d("span", {
												className: "bullet-action-cost",
												children: e.cost
											}),
											/* @__PURE__ */ d(Et, { kind: e.t === "move" ? e.move.dirs[0][0] === -1 && e.move.dirs.length === 1 ? "up" : e.move.dirs[0][0] === 1 && e.move.dirs.length === 1 ? "down" : "move" : e.t }),
											/* @__PURE__ */ d("span", { children: c(e.text) })
										]
									}, t))
								}),
								/* @__PURE__ */ f("div", {
									className: "bullet-star-action",
									children: [
										/* @__PURE__ */ d("b", { children: "✦" }),
										/* @__PURE__ */ d("span", { children: c("games.bullet.starActionTitle") }),
										/* @__PURE__ */ d("span", { children: S.star.map((e) => c(ee[e])).join(" · ") })
									]
								}),
								e.mode === "ffa" && /* @__PURE__ */ d("div", {
									className: "bullet-powers",
									children: n.powerups.map((e, t) => e ? /* @__PURE__ */ f("button", {
										type: "button",
										disabled: !E,
										className: p?.kind === "power" && p.slot === t ? "is-picked" : "",
										onClick: () => j(t),
										children: ["✧ ", c(se[e])]
									}, t) : null)
								})
							]
						}),
						/* @__PURE__ */ d("div", {
							className: "bullet-main-actions",
							children: z
						}),
						/* @__PURE__ */ f("div", {
							className: "bullet-hand-heading",
							children: [/* @__PURE__ */ f("b", { children: [
								c("games.bullet.patternsTitle"),
								" ",
								/* @__PURE__ */ d("span", { children: t.hand.length })
							] }), /* @__PURE__ */ d(V, {
								name: `deck:${o}`,
								children: /* @__PURE__ */ f("span", { children: [
									c("games.bullet.deckShort", { n: n.deckCount }),
									" · ",
									c("games.bullet.discardShort", { n: n.discard.length })
								] })
							})]
						}),
						/* @__PURE__ */ d("div", {
							className: "bullet-hand",
							children: t.hand.map((e, t) => /* @__PURE__ */ d(wt, {
								rid: o,
								index: t,
								heroine: n.heroine,
								pattern: e,
								disabled: !E,
								selected: p?.kind === "pattern" && p.card === t,
								onClick: () => fe(t)
							}, `${e}:${t}`))
						})
					]
				})
			]
		})
	});
}
function V({ name: e, className: t = "", children: n }) {
	let { ref: r, hidden: i } = o(e);
	return /* @__PURE__ */ d("div", {
		ref: r,
		className: t,
		style: { visibility: i ? "hidden" : void 0 },
		children: n
	});
}
function bt(e, t, n) {
	if (t) return n("games.bullet.faceDownBullet");
	let r = g(e);
	return `${n("games.bullet.bulletLabel", {
		color: n(`games.bullet.colors.${r.color}`),
		n: r.num
	})}${r.star ? ` · ${n("games.bullet.starBullet")}` : ""}`;
}
function xt({ p: e, member: t, own: n }) {
	let r = a(), { ref: i } = o(`seat:${e.rid}`), c = e.heroine ? C[e.heroine].maxLife : 4;
	return /* @__PURE__ */ f("div", {
		ref: i,
		className: `bullet-player ${n ? "is-own" : ""} ${e.alive ? "" : "is-out"}`,
		children: [/* @__PURE__ */ f("div", {
			className: "bullet-player-name",
			children: [
				/* @__PURE__ */ d("i", { style: { backgroundColor: s[(t?.colorIndex ?? 0) % s.length].hex } }),
				/* @__PURE__ */ d("span", { children: t?.name ?? e.rid }),
				e.done && /* @__PURE__ */ d("span", {
					"aria-label": r("games.bullet.endTurn"),
					children: "✓"
				})
			]
		}), /* @__PURE__ */ f("div", {
			className: "bullet-player-stats",
			children: [/* @__PURE__ */ d("span", {
				"aria-label": `${r("games.bullet.life")} ${e.life}`,
				children: Array.from({ length: c }, (t, n) => /* @__PURE__ */ d(ut, { empty: n >= e.life }, n))
			}), /* @__PURE__ */ f("small", { children: [e.current, /* @__PURE__ */ f("span", { children: [" +", e.incoming] })] })]
		})]
	});
}
function St({ me: e, variant: t }) {
	let n = a(), r = C[e.heroine].apMax;
	return /* @__PURE__ */ f("div", {
		className: "bullet-ap",
		"aria-label": `${n("games.bullet.actionPoints")} ${e.ap}/${r}`,
		children: [/* @__PURE__ */ d("b", { children: t === "hero" ? n("games.bullet.ap") : `${e.ap} / ${r}` }), /* @__PURE__ */ d("div", { children: Array.from({ length: r }, (n, r) => /* @__PURE__ */ d(V, {
			name: `ap:${e.rid}:${t}:${r}`,
			className: r < e.ap ? "is-filled" : "",
			children: /* @__PURE__ */ d("span", {})
		}, r)) })]
	});
}
function Ct({ me: e }) {
	let t = a(), n = e.heroine, r = C[n];
	return /* @__PURE__ */ f("div", {
		className: "bullet-hero-panel",
		children: [
			/* @__PURE__ */ d(V, {
				name: `portrait:${e.rid}`,
				className: "bullet-hero-image",
				children: /* @__PURE__ */ d(lt, { heroine: n })
			}),
			/* @__PURE__ */ f("div", {
				className: "bullet-hero-name",
				children: [/* @__PURE__ */ d("small", { children: t(`games.bullet.hero.${n}.title`) }), /* @__PURE__ */ d("h2", { children: t(`games.bullet.hero.${n}.name`) })]
			}),
			/* @__PURE__ */ f("div", {
				className: "bullet-hero-life",
				children: [/* @__PURE__ */ d("span", { children: t("games.bullet.life") }), /* @__PURE__ */ d("div", {
					className: "bullet-life",
					children: Array.from({ length: r.maxLife }, (t, n) => /* @__PURE__ */ d(V, {
						name: `life:${e.rid}:${n}`,
						children: /* @__PURE__ */ d(ut, { empty: n >= e.life })
					}, n))
				})]
			}),
			/* @__PURE__ */ d("div", {
				className: "bullet-hero-ap",
				children: /* @__PURE__ */ d(St, {
					me: e,
					variant: "hero"
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "bullet-hero-ability",
				children: [/* @__PURE__ */ d("b", { children: t(`games.bullet.hero.${n}.ua`) }), /* @__PURE__ */ d("span", { children: t(`games.bullet.hero.${n}.uaDesc`) })]
			})
		]
	});
}
function wt({ rid: e, index: t, heroine: n, pattern: r, selected: i, disabled: s, onClick: c }) {
	let l = a(), { ref: u, hidden: p } = o(`hand:${e}:${t}`), m = C[n].patterns[r];
	return /* @__PURE__ */ f("button", {
		ref: u,
		type: "button",
		disabled: s,
		onClick: c,
		"aria-pressed": i,
		style: { visibility: p ? "hidden" : void 0 },
		className: `bullet-pattern-card ${i ? "is-picked" : ""}`,
		children: [/* @__PURE__ */ f("span", {
			className: "bullet-pattern-face",
			children: [/* @__PURE__ */ d(pt, {
				grid: m.grid,
				colorTag: m.color
			}), i && /* @__PURE__ */ d("i", {
				"aria-hidden": "true",
				children: "✓"
			})]
		}), /* @__PURE__ */ d("span", {
			className: "bullet-pattern-title",
			children: l(m.key)
		})]
	});
}
function Tt({ rid: e, index: t, bullet: n, mariel: r, cross: i, picked: s, origin: c, preview: l, interactive: u, onClick: p }) {
	let m = a(), { ref: h } = o(`cell:${e}:${t}`), { ref: g, hidden: _ } = o(n ? `bullet:${e}:${t}:${n.id}:${+!!n.faceDown}` : null), { ref: ee, hidden: v } = o(r ? `marker:${e}:${t}` : i ? `cross:${e}:${t}` : null), y = l === "X" || l === "(X)", b = m("games.bullet.cellLabel", {
		row: Math.floor(t / 5) + 1,
		col: t % 5 + 1
	});
	return n && (b += ` · ${bt(n.id, n.faceDown, m)}`), i && (b += ` · ${m("games.bullet.crosshairLabel")}`), r && (b += ` · ${m("games.bullet.marielLabel")}`), /* @__PURE__ */ f("button", {
		ref: h,
		type: "button",
		"aria-label": b,
		disabled: !u,
		onClick: p,
		className: `bullet-cell ${s ? "is-picked" : ""} ${c ? "is-origin" : ""} ${l ? "is-preview" : ""} ${y ? "is-clear" : ""}`,
		children: [
			/* @__PURE__ */ d(dt, { color: gt[t % 5] }),
			n && /* @__PURE__ */ d("span", {
				ref: g,
				className: "bullet-piece",
				style: { visibility: _ ? "hidden" : void 0 },
				children: /* @__PURE__ */ d(B, {
					id: n.id,
					faceDown: n.faceDown
				})
			}),
			(r || i) && /* @__PURE__ */ d("span", {
				ref: ee,
				className: "bullet-marker",
				style: { visibility: v ? "hidden" : void 0 },
				children: /* @__PURE__ */ d(mt, { cross: i })
			}),
			y && /* @__PURE__ */ d("span", {
				className: "bullet-clear-mark",
				"aria-hidden": "true",
				children: "×"
			}),
			c && /* @__PURE__ */ d("span", {
				className: "bullet-origin-dot",
				"aria-hidden": "true"
			})
		]
	});
}
function Et({ kind: e }) {
	return /* @__PURE__ */ d("svg", {
		className: "bullet-action-icon",
		viewBox: "0 0 48 48",
		"aria-hidden": "true",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.4",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: ["draw", "discardDraw"].includes(e) ? /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("rect", {
				x: "9",
				y: "6",
				width: "23",
				height: "30",
				rx: "3"
			}),
			/* @__PURE__ */ d("rect", {
				x: "17",
				y: "12",
				width: "23",
				height: "30",
				rx: "3"
			}),
			/* @__PURE__ */ d("path", { d: "M28 20V33M22 26H34" })
		] }) : e === "up" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", {
			cx: "24",
			cy: "36",
			r: "6"
		}), /* @__PURE__ */ d("path", { d: "M24 26V6M16 14L24 6L32 14" })] }) : e === "down" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", {
			cx: "24",
			cy: "11",
			r: "6"
		}), /* @__PURE__ */ d("path", { d: "M24 21V40M16 32L24 40L32 32" })] }) : e === "move" || e === "push" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", {
			cx: "24",
			cy: "20",
			r: "6"
		}), /* @__PURE__ */ d("path", { d: "M6 20H14M34 20H42M11 15L6 20L11 25M37 15L42 20L37 25M24 32V43M19 38L24 43L29 38" })] }) : e === "moveCross" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", {
			cx: "24",
			cy: "24",
			r: "12"
		}), /* @__PURE__ */ d("path", { d: "M24 3V16M24 32V45M3 24H16M32 24H45" })] }) : /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("path", { d: "M24 5L29 18L43 24L29 29L24 43L18 29L5 24L18 18Z" }), /* @__PURE__ */ d("path", { d: "M24 15V33M15 24H33" })] })
	});
}
//#endregion
//#region src/games/bullet/bot.ts
var Dt = [
	"esfir",
	"adelheid",
	"mariel",
	"youngja",
	"lingling",
	"rie",
	"ekolu",
	"senka"
];
function Ot(e) {
	return {
		heroine: e.heroine,
		sight: e.sight.map((e) => e ? {
			id: e.id,
			fd: e.faceDown
		} : null),
		mariel: e.mariel,
		crosshairs: e.crosshairs
	};
}
var kt = (e, t) => {
	let { public: n, private: r } = e, i = n.players.find((e) => e.rid === t.rid);
	if (!i || !r || i.pending === "resolve" || n.phase === "sudden" && n.players.some((e) => e.pending === "resolve")) return null;
	if (n.phase === "pick") {
		if (!i.heroine) {
			let e = new Set(n.players.map((e) => e.heroine)), t = Dt.find((t) => !e.has(t));
			return t ? { action: {
				type: "pick",
				heroine: t
			} } : null;
		}
		return i.pending === "markers" ? { action: {
			type: "placeMarkers",
			cells: i.heroine === "mariel" ? [17] : [16, 18]
		} } : null;
	}
	if (n.phase === "end") {
		if (i.endDone || !i.alive) return null;
		let e = C[i.heroine].handSize, t = Math.max(0, r.hand.length - e), a = n.mode === "ffa" && n.centerPowerups.length > 0 ? 0 : null;
		return { action: {
			type: "endPhase",
			take: a,
			replaceSlot: a !== null && i.powerups.every((e) => e !== null) ? 0 : void 0,
			discard: Array.from({ length: t }, (e, t) => t)
		} };
	}
	if (n.phase === "sudden") return n.sudden?.includes(t.rid) ? { action: { type: "place" } } : null;
	if (n.phase !== "play" || !i.alive || i.done) return null;
	if (i.pending === "rie") return { action: {
		type: "riePick",
		idx: 0
	} };
	if (i.pending === "star") return { action: {
		type: "starResolve",
		skip: !0
	} };
	if (i.pending === "mariel") {
		let e = Array.from({ length: 30 }, (e, t) => t).find((e) => !i.sight[e] && i.mariel !== e);
		return e === void 0 ? null : { action: {
			type: "marielRelocate",
			cell: e
		} };
	}
	let a = i.sight.filter((e) => e !== null).length;
	if (t.difficulty !== "weak" && a > 6) {
		let e = Ot(i);
		for (let t = 0; t < r.hand.length; t += 1) {
			let n = Ae(i.heroine, r.hand[t], e);
			if (n.length > 0) return { action: i.heroine === "senka" ? {
				type: "usePattern",
				card: t
			} : {
				type: "usePattern",
				card: t,
				origin: n[0]
			} };
		}
	}
	if (i.current > 0) return { action: { type: "place" } };
	if (t.difficulty !== "weak") {
		let e = Ot(i);
		for (let t = 0; t < r.hand.length; t += 1) {
			let n = Ae(i.heroine, r.hand[t], e);
			if (n.length > 0) return { action: i.heroine === "senka" ? {
				type: "usePattern",
				card: t
			} : {
				type: "usePattern",
				card: t,
				origin: n[0]
			} };
		}
	}
	return { action: { type: "endTurn" } };
}, H = (e) => Math.max(0, Math.min(1, e)), At = (e) => 1 - (1 - H(e)) ** 3, U = (e) => ({
	x: e.x + e.w / 2,
	y: e.y + e.h / 2
}), jt = (e, t, n) => ({
	x: e.x + (t.x - e.x) * n,
	y: e.y + (t.y - e.y) * n
}), W = (e, t) => {
	let n = e.anchor(t);
	return n && n.w > 0 && n.h > 0 ? n : null;
}, Mt = (e, t, n, r) => `bullet:${e}:${t}:${n}:${+!!r}`, G = (e, t, n) => W(e, `cell:${t}:${n}`), K = (e) => ot[e], Nt = (e, t = !1) => t ? "#c8d9e8" : it[g(e).color];
function q({ ms: e, paint: t }) {
	let i = r(null);
	return n(() => {
		let n = i.current;
		if (!n) return;
		let r = n.getBoundingClientRect(), a = Math.min(window.devicePixelRatio || 1, 1.5);
		n.width = Math.ceil(r.width * a), n.height = Math.ceil(r.height * a);
		let o = n.getContext("2d");
		if (!o) return;
		let s = performance.now(), c = 0, l = (n) => {
			let i = H((n - s) / e);
			o.setTransform(a, 0, 0, a, 0, 0), o.clearRect(0, 0, r.width, r.height), o.save(), o.globalCompositeOperation = "screen", t(o, i, r.width < 600), o.restore(), i < 1 && (c = requestAnimationFrame(l));
		};
		return c = requestAnimationFrame(l), () => cancelAnimationFrame(c);
	}, [e, t]), /* @__PURE__ */ d("canvas", {
		ref: i,
		className: "bullet-fx-canvas"
	});
}
function J(e, t, n, r, i) {
	if (!(t.length < 2 || i <= 0)) {
		e.save(), e.lineCap = "round", e.lineJoin = "round", e.beginPath(), e.moveTo(t[0].x, t[0].y);
		for (let n of t.slice(1)) e.lineTo(n.x, n.y);
		for (let [t, a, o] of [
			[
				r * 4,
				.12,
				n
			],
			[
				r * 1.8,
				.55,
				n
			],
			[
				r * .45,
				1,
				"#fffdf2"
			]
		]) e.strokeStyle = o, e.lineWidth = t, e.globalAlpha = i * a, e.stroke();
		e.restore();
	}
}
function Y(e, t, n, r, i, a = .6) {
	n <= 0 || i <= 0 || (e.save(), e.globalAlpha = i, e.strokeStyle = r, e.lineWidth = 1.5, e.beginPath(), e.ellipse(t.x, t.y, n, n * a, -.25, 0, Math.PI * 2), e.stroke(), e.globalAlpha = i * .4, e.lineWidth = 4, e.stroke(), e.restore());
}
function Pt(e, t, n, r, i) {
	J(e, [{
		x: t.x - n,
		y: t.y
	}, {
		x: t.x + n,
		y: t.y
	}], r, 1.8, i), J(e, [{
		x: t.x,
		y: t.y - n * 1.7
	}, {
		x: t.x,
		y: t.y + n * 1.7
	}], r, 1.5, i);
}
function X(e, t, n, r, i, a) {
	if (i <= 0 || i >= 1) return;
	let o = (1 - i) ** 1.4;
	Y(e, t, n * (.2 + At(i) * 1.2), r, o), Y(e, t, n * (.1 + At(i) * .8), "#fff7db", o * .6, 1), Pt(e, t, n * .65 * (1 - i), r, o);
	for (let s = 0; s < (a ? 7 : 14); s++) {
		let a = s * 2.39996, c = n * (.3 + i * (1.1 + s % 3 * .2)), l = {
			x: t.x + Math.cos(a) * c,
			y: t.y + Math.sin(a) * c * .75
		};
		e.save(), e.translate(l.x, l.y), e.rotate(a + i), e.globalAlpha = o * .8, e.fillStyle = s % 3 ? r : "#fff9df", e.beginPath(), e.moveTo(-2, -4), e.lineTo(3 + s % 3, 0), e.lineTo(1, 5), e.closePath(), e.fill(), e.restore();
	}
}
function Z(e, t, n, r, i, a = 5) {
	let o = jt(t, n, At(i));
	J(e, [jt(t, n, At(Math.max(0, i - .32))), o], r, a, Math.sin(Math.PI * H(i)) * .9);
	for (let o = 1; o < 4; o++) Y(e, jt(t, n, At(Math.max(0, i - o * .07))), a * (1.8 - o * .25), r, (1 - i) * .22, 1);
}
function Ft(e, t, n, r, i, a) {
	if (i <= 0 || i >= 1) return;
	let o = K(t), s = Math.sin(Math.PI * i);
	if (t === "esfir") {
		Y(e, n, r * (.55 + i * .8), o, s), Y(e, n, r * (.9 + i * .5), "#d9f4ff", s * .6, .26);
		for (let t = 0; t < 5; t++) {
			let a = t * 1.256 + i * 2;
			Pt(e, {
				x: n.x + Math.cos(a) * r,
				y: n.y + Math.sin(a) * r * .5
			}, 3 + (1 - i) * 4, o, s);
		}
	} else if (t === "mariel") for (let t = 0; t < (a ? 4 : 8); t++) {
		let a = t * 2.4 + i, c = r * (.3 + i), l = {
			x: n.x + Math.cos(a) * c,
			y: n.y + Math.sin(a) * c * .7
		};
		e.save(), e.translate(l.x, l.y), e.rotate(a), e.globalAlpha = s, e.fillStyle = t % 2 ? "#fff4e9" : o, e.beginPath(), e.moveTo(-8, -4), e.lineTo(14, 0), e.lineTo(-5, 6), e.lineTo(0, 0), e.closePath(), e.fill(), e.restore();
	}
	else if (t === "adelheid") {
		for (let t = 0; t < 3; t++) Y(e, n, r * (.5 + t * .23 + i * .35), o, s * .8, .45);
		for (let t = 0; t < 5; t++) {
			let a = {
				x: n.x - r + t * r * .5 + i * 20,
				y: n.y + Math.sin(t + i * 3) * r * .5
			};
			e.save(), e.globalAlpha = s, e.fillStyle = "#ffedcb", e.font = `${Math.max(16, r * .32)}px serif`, e.fillText("♪", a.x, a.y), e.restore();
		}
	} else if (t === "ekolu") for (let t = 0; t < 3; t++) J(e, Array.from({ length: 4 }, (e, a) => {
		let o = a * Math.PI * 2 / 3 - Math.PI / 2 + i * .5 + t * .1;
		return {
			x: n.x + Math.cos(o) * r * (1 - t * .2),
			y: n.y + Math.sin(o) * r * (1 - t * .2)
		};
	}), t === 1 ? "#ffe6b0" : o, 2, s * .7);
	else if (t === "lingling") for (let t = 0; t < 3; t++) J(e, Array.from({ length: 9 }, (e, a) => ({
		x: n.x - r + a * r / 4,
		y: n.y + Math.sin(a * 7 + Math.floor(i * 12) + t * 4) * r * .2 + (t - 1) * r * .3
	})), o, 2, s);
	else if (t === "rie") J(e, Array.from({ length: 24 }, (e, t) => {
		let i = -.8 + t * 2.8 / 23;
		return {
			x: n.x + Math.cos(i) * r,
			y: n.y + Math.sin(i) * r * .6
		};
	}), o, 7 * (1 - i) + 1, s), Pt(e, n, r * .55, "#ffecc8", s);
	else if (t === "senka") {
		Y(e, n, r * (.6 + .15 * (1 - i)), o, s, 1);
		for (let t = 0; t < 4; t++) {
			let i = t * Math.PI / 2;
			J(e, [{
				x: n.x + Math.cos(i) * r * .4,
				y: n.y + Math.sin(i) * r * .4
			}, {
				x: n.x + Math.cos(i) * r,
				y: n.y + Math.sin(i) * r
			}], o, 2, s);
		}
		Pt(e, n, r * .35 * (1 - i), "#ffe7ae", s);
	} else for (let t = 0; t < (a ? 4 : 7); t++) {
		let a = n.x + (t - 3) * r * .28, c = n.y + Math.sin(t * 3) * r * .35 - i * r * .7;
		J(e, [
			{
				x: a - 8,
				y: c + 22
			},
			{
				x: a + 5,
				y: c + 8
			},
			{
				x: a,
				y: c - 16
			}
		], o, 6 * (1 - i), s * .7);
	}
}
function Q({ from: e, to: t, size: i, ms: a, children: o, flip: s = !1, vanish: c = !1 }) {
	let l = r(null);
	return n(() => {
		let n = l.current?.animate([{
			transform: `translate(${e.x - i / 2}px,${e.y - i / 2}px) scale(${s ? ".1,1" : "1"})`,
			opacity: 1
		}, {
			transform: `translate(${t.x - i / 2}px,${t.y - i / 2}px) scale(${c ? ".05" : "1"})`,
			opacity: +!c
		}], {
			duration: a,
			easing: "cubic-bezier(.16,.6,.24,1)",
			fill: "both"
		});
		return () => n?.cancel();
	}, [
		e.x,
		e.y,
		t.x,
		t.y,
		i,
		a,
		s,
		c
	]), /* @__PURE__ */ d("div", {
		ref: l,
		className: "bullet-fx-sprite",
		style: {
			width: i,
			height: i
		},
		children: o
	});
}
function It({ bounds: e, heroine: t, ms: n }) {
	return /* @__PURE__ */ f("div", {
		className: "bullet-fx-cutin",
		style: {
			left: e.x,
			top: e.y + e.h * .12,
			width: e.w,
			height: e.h * .65,
			"--bullet-fx-ms": `${n}ms`,
			"--bullet-fx-accent": K(t)
		},
		children: [/* @__PURE__ */ d(lt, { heroine: t }), /* @__PURE__ */ d("i", {})]
	});
}
function $(e, t, n = "#b8ebdf") {
	let r = t && W(e, `seat:${t}`);
	return r ? {
		ms: 180,
		node: /* @__PURE__ */ d(q, {
			ms: 180,
			paint: (e, t) => Y(e, U(r), r.w * .5 * (.8 + t * .3), n, Math.sin(t * Math.PI))
		})
	} : null;
}
function Lt(e, t, n, r) {
	let i = n.flatMap((n) => {
		let r = G(e, t, n.from), i = G(e, t, n.to);
		return r && i ? [{
			...n,
			a: r,
			b: i
		}] : [];
	});
	if (!i.length) return $(e, t, K(r));
	let a = e.queued ? 130 : j.move;
	return {
		ms: a,
		hide: e.queued ? [] : i.map((e) => e.marker ? `marker:${t}:${e.to}` : Mt(t, e.to, e.id, e.fd)),
		node: /* @__PURE__ */ f(u, { children: [!e.queued && i.map((e, t) => /* @__PURE__ */ d(Q, {
			from: U(e.a),
			to: U(e.b),
			size: e.b.w * .65,
			ms: a,
			children: e.marker ? /* @__PURE__ */ d(mt, {}) : /* @__PURE__ */ d(B, {
				id: e.id,
				faceDown: e.fd
			})
		}, t)), /* @__PURE__ */ d(q, {
			ms: a,
			paint: (t, n, a) => i.forEach((i) => {
				let o = i.marker ? K(r) : Nt(i.id, i.fd);
				e.queued || Z(t, U(i.a), U(i.b), o, n), X(t, U(i.b), i.b.w * .42, o, H((n - .55) / .45), a);
			})
		})] })
	};
}
var Rt = {
	bulletPlace(e, t) {
		let n = e.data, r = e.rid, i = G(t, r, n.target), a = G(t, r, n.target % 5);
		if (!i || !a) return $(t, r);
		let o = t.queued ? 130 : j.place, s = Nt(n.id, n.fd), c = n.source === "center" ? U(W(t, `center:${r}`) ?? a) : {
			x: U(a).x,
			y: a.y - a.h * .35
		}, l = U(i);
		return {
			ms: o,
			hide: t.queued ? [] : [Mt(r, n.target, n.id, n.fd)],
			node: /* @__PURE__ */ f(u, { children: [!t.queued && /* @__PURE__ */ d(Q, {
				from: c,
				to: l,
				size: i.w * .65,
				ms: o * .78,
				children: /* @__PURE__ */ d(B, {
					id: n.id,
					faceDown: n.fd
				})
			}), /* @__PURE__ */ d(q, {
				ms: o,
				paint: (e, n, r) => {
					t.queued || Z(e, c, l, s, H(n / .8), 7), X(e, l, i.w * .5, s, H((n - .55) / .45), r);
				}
			})] })
		};
	},
	bulletMove(e, t) {
		let n = e.data;
		return Lt(t, e.rid, n.moves, n.heroine);
	},
	bulletClear(e, t) {
		let n = e.data, r = e.rid, i = n.pieces.flatMap((e) => {
			let n = G(t, r, e.cell);
			return n ? [{
				...e,
				b: n
			}] : [];
		}), a = n.marker === null ? null : G(t, r, n.marker), o = G(t, r, n.origins[0] ?? n.pieces[0]?.cell ?? n.marker ?? 12);
		if (!o) return $(t, r, K(n.heroine));
		let s = t.queued ? 180 : j.clear, c = K(n.heroine), l = i.length ? {
			x: i.reduce((e, t) => e + U(t.b).x, 0) / i.length,
			y: i.reduce((e, t) => e + U(t.b).y, 0) / i.length
		} : U(o), p = n.to ? W(t, `incoming:${n.to}`) ?? W(t, `seat:${n.to}`) : W(t, `center:${r}`), m = Array.from({ length: Math.max(0, n.apAfter - n.apBefore) }, (e, t) => n.apBefore + t).flatMap((e) => {
			let n = [`ap:${r}:rail:${e}`, `ap:${r}:hero:${e}`].find((e) => W(t, e));
			return n ? [{
				name: n,
				b: W(t, n)
			}] : [];
		}), h = [];
		if (n.pattern !== null) for (let e of n.origins) C[n.heroine].patterns[n.pattern].grid.forEach((n, i) => n.forEach((n, a) => {
			let o = Math.floor(e / 5) + i, s = e % 5 + a;
			if (n === " " || o < 0 || o >= 6 || s < 0 || s >= 5) return;
			let c = G(t, r, o * 5 + s);
			c && h.push(c);
		}));
		let g = (i.length >= 2 || n.stars.length > 0) && !t.queued ? W(t, `portrait:${r}`) : null;
		return {
			ms: s,
			hide: t.queued ? [] : m.map((e) => e.name),
			node: /* @__PURE__ */ f(u, { children: [
				!t.queued && i.map((e) => /* @__PURE__ */ d(Q, {
					from: U(e.b),
					to: U(e.b),
					size: e.b.w * .65,
					ms: s * .29,
					vanish: !0,
					children: /* @__PURE__ */ d(B, {
						id: e.id,
						faceDown: e.fd
					})
				}, e.cell)),
				!t.queued && a && /* @__PURE__ */ d(Q, {
					from: U(a),
					to: U(a),
					size: a.w * .7,
					ms: s * .3,
					vanish: !0,
					children: /* @__PURE__ */ d(mt, {})
				}),
				g && /* @__PURE__ */ d(It, {
					bounds: g,
					heroine: n.heroine,
					ms: s
				}),
				/* @__PURE__ */ d(q, {
					ms: s,
					paint: (e, r, a) => {
						if (t.queued) {
							X(e, l, o.w, c, r, a);
							return;
						}
						for (let t of h) Y(e, U(t), t.w * .39, c, H(1 - r / .4), 1);
						Ft(e, n.heroine, l, o.w * 1.1, H(r / .85), a);
						for (let t of i) {
							let n = U(t.b), i = t.b.w * .48, o = Math.sin(Math.PI * H((r - .07) / .4));
							J(e, [{
								x: n.x - i,
								y: n.y + i * .8
							}, {
								x: n.x + i,
								y: n.y - i * .8
							}], Nt(t.id, t.fd), 5, o), J(e, [{
								x: n.x - i,
								y: n.y - i * .8
							}, {
								x: n.x + i,
								y: n.y + i * .8
							}], c, 3, o), X(e, n, t.b.w * .6, Nt(t.id, t.fd), H((r - .16) / .65), a), p && r > .37 && Z(e, n, U(p), "#d7c6ff", H((r - .37) / .48), 3);
						}
						for (let [t, o] of m.entries()) {
							let s = i.find((e) => e.cell === n.stars[t % Math.max(1, n.stars.length)]), c = s ? U(s.b) : l, u = H((r - .36) / .46), d = U(o.b);
							Z(e, c, d, "#a9ffe6", u, 4), Pt(e, jt(c, d, At(u)), 5, "#e6ffcf", Math.sin(Math.PI * u)), X(e, d, 12, "#b3ffe6", H((r - .77) / .23), a);
						}
					}
				})
			] })
		};
	},
	bulletMiss(e, t) {
		let n = e.data, r = e.rid, i = G(t, r, n.col), a = G(t, r, 25 + n.col);
		if (!i || !a) return $(t, r, "#ff6989");
		let o = t.queued ? 130 : j.place, s = {
			x: U(i).x,
			y: i.y - i.h * .3
		}, c = {
			x: U(a).x,
			y: a.y + a.h * 1.15
		};
		return {
			ms: o,
			node: /* @__PURE__ */ f(u, { children: [!t.queued && /* @__PURE__ */ d(Q, {
				from: s,
				to: c,
				size: i.w * .65,
				ms: o,
				children: /* @__PURE__ */ d(B, {
					id: n.id,
					faceDown: n.fd
				})
			}), /* @__PURE__ */ d(q, {
				ms: o,
				paint: (e, t) => Z(e, s, c, Nt(n.id, n.fd), t, 8)
			})] })
		};
	},
	hit(e, t) {
		let n = e.data, r = e.rid, i = W(t, `life:${r}:${Math.max(0, n.life)}`), a = W(t, `portrait:${r}`);
		if (!i || !a) return $(t, r, "#ff567e");
		let o = t.queued ? 180 : j.hit, s = U(i), c = U(a);
		return {
			ms: o,
			node: /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(Q, {
				from: s,
				to: {
					x: s.x,
					y: s.y - 18
				},
				size: i.w,
				ms: o,
				vanish: !0,
				children: /* @__PURE__ */ d(ut, {})
			}), /* @__PURE__ */ d(q, {
				ms: o,
				paint: (e, t, n) => {
					X(e, s, i.w * 2, "#ff5c82", t, n), e.save(), e.beginPath(), e.rect(a.x, a.y, a.w, a.h), e.clip();
					for (let n = 0; n < 5; n++) {
						let r = c.y + (n - 2) * a.h * .11;
						J(e, [
							{
								x: c.x - a.w * .5,
								y: r + 30
							},
							{
								x: c.x - 10,
								y: r - 10
							},
							{
								x: c.x + 8,
								y: r + 9
							},
							{
								x: c.x + a.w * .5,
								y: r - 20
							}
						], "#ff416c", 4, Math.sin(Math.PI * t) * .7);
					}
					e.restore();
				}
			})] })
		};
	},
	ko(e, t) {
		let n = W(t, `portrait:${e.rid}`);
		return n ? {
			ms: j.hit,
			node: /* @__PURE__ */ d(q, {
				ms: j.hit,
				paint: (e, t, r) => X(e, U(n), Math.min(n.w, n.h) * .65, "#f46eaa", t, r)
			})
		} : $(t, e.rid, "#ff5577");
	},
	bulletMarker(e, t) {
		let n = e.data, r = e.rid, i = G(t, r, n.to), a = n.from === null ? W(t, `portrait:${r}`) : G(t, r, n.from);
		if (!i || !a) return $(t, r);
		let o = t.queued ? 130 : j.move;
		return {
			ms: o,
			hide: t.queued ? [] : [`${n.marker ? "marker" : "cross"}:${r}:${n.to}`],
			node: /* @__PURE__ */ f(u, { children: [!t.queued && /* @__PURE__ */ d(Q, {
				from: U(a),
				to: U(i),
				size: i.w * .8,
				ms: o,
				children: /* @__PURE__ */ d(mt, { cross: !n.marker })
			}), /* @__PURE__ */ d(q, {
				ms: o,
				paint: (e, t, r) => {
					Z(e, U(a), U(i), K(n.heroine), t, 3), Ft(e, n.heroine, U(i), i.w * .5, t, r);
				}
			})] })
		};
	},
	bulletDraw(e, t) {
		let n = e.secret, r = e.rid;
		if (!n || r !== t.myRid) return $(t, r);
		let i = W(t, `hand:${r}:${n.slot}`), a = W(t, `deck:${r}`);
		if (!i || !a) return $(t, r);
		let o = t.queued ? 130 : j.draw;
		return {
			ms: o,
			hide: t.queued ? [] : [`hand:${r}:${n.slot}`],
			node: /* @__PURE__ */ f(u, { children: [!t.queued && /* @__PURE__ */ d(Q, {
				from: U(a),
				to: U(i),
				size: Math.min(i.w, i.h),
				ms: o,
				flip: !0,
				children: /* @__PURE__ */ d("div", {
					className: "bullet-fx-card",
					children: /* @__PURE__ */ d(pt, { grid: C[n.heroine].patterns[n.pattern].grid })
				})
			}), /* @__PURE__ */ d(q, {
				ms: o,
				paint: (e, t, r) => X(e, U(i), i.w * .5, K(n.heroine), H((t - .5) / .5), r)
			})] })
		};
	},
	bulletReveal(e, t) {
		let n = e.secret, r = t.myRid;
		if (!n) return null;
		let i = n.ids.flatMap((e, n) => {
			let i = W(t, `rie:${r}:${n}`);
			return i ? [{
				id: e,
				b: i,
				i: n
			}] : [];
		}), a = W(t, `bag:${r}`);
		if (!i.length || !a) return null;
		let o = j.draw;
		return {
			ms: o,
			hide: t.queued ? [] : i.map((e) => `rie:${r}:${e.i}`),
			node: /* @__PURE__ */ f(u, { children: [!t.queued && i.map((e) => /* @__PURE__ */ d(Q, {
				from: U(a),
				to: U(e.b),
				size: e.b.w,
				ms: o,
				flip: !0,
				children: /* @__PURE__ */ d(B, { id: e.id })
			}, e.i)), /* @__PURE__ */ d(q, {
				ms: o,
				paint: (e, t, n) => i.forEach((r) => X(e, U(r.b), r.b.w * .5, Nt(r.id), H((t - .5) / .5), n))
			})] })
		};
	},
	bulletFlip(e, t) {
		let n = e.data, r = e.rid, i = G(t, r, n.cell);
		if (!i) return $(t, r);
		let a = t.queued ? 130 : j.flip;
		return {
			ms: a,
			hide: t.queued ? [] : [Mt(r, n.cell, n.id, !0)],
			node: /* @__PURE__ */ f(u, { children: [!t.queued && /* @__PURE__ */ d(Q, {
				from: U(i),
				to: U(i),
				size: i.w * .65,
				ms: a,
				flip: !0,
				children: /* @__PURE__ */ d(B, {
					id: n.id,
					faceDown: !0
				})
			}), /* @__PURE__ */ d(q, {
				ms: a,
				paint: (e, t, r) => Ft(e, n.heroine, U(i), i.w * .6, t, r)
			})] })
		};
	},
	bulletReturn(e, t) {
		let n = e.data, r = e.rid, i = G(t, r, n.cell), a = W(t, `center:${r}`);
		if (!i || !a) return $(t, r);
		let o = t.queued ? 130 : j.move;
		return {
			ms: o,
			node: /* @__PURE__ */ f(u, { children: [!t.queued && /* @__PURE__ */ d(Q, {
				from: U(i),
				to: U(a),
				size: i.w * .65,
				ms: o,
				vanish: !0,
				children: /* @__PURE__ */ d(B, {
					id: n.id,
					faceDown: n.fd
				})
			}), /* @__PURE__ */ d(q, {
				ms: o,
				paint: (e, t) => Z(e, U(i), U(a), K(n.heroine), t, 4)
			})] })
		};
	},
	bulletAbility(e, t) {
		let n = e.data, r = W(t, `portrait:${e.rid}`);
		return r ? {
			ms: j.move,
			node: /* @__PURE__ */ d(q, {
				ms: j.move,
				paint: (e, t, i) => Ft(e, n.heroine, U(r), Math.min(r.w, r.h) * .5, t, i)
			})
		} : $(t, e.rid);
	},
	niceTry(e, t) {
		let n = e.data, r = e.rid, i = W(t, `portrait:${r}`), a = n.to ? W(t, `seat:${n.to}`) : W(t, `center:${r}`);
		return i ? {
			ms: j.hit,
			node: /* @__PURE__ */ d(q, {
				ms: j.hit,
				paint: (e, t, n) => {
					Ft(e, "rie", U(i), Math.min(i.w, i.h) * .5, t, n), a && Z(e, U(i), U(a), "#ffce8f", t, 6);
				}
			})
		} : $(t, r);
	},
	bulletLifeClear(e, t) {
		return Rt.niceTry({
			...e,
			data: {
				heroine: "rie",
				to: null
			}
		}, t);
	}
};
//#endregion
//#region src/games/bullet/game-over.tsx
function zt({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ f("div", {
		className: "bullet-over",
		children: [/* @__PURE__ */ d("div", {
			className: "bullet-over-brand",
			children: /* @__PURE__ */ d(ht, {})
		}), /* @__PURE__ */ d(p, {
			hintCount: e,
			result: t,
			members: n,
			myRid: r,
			accent: ce.accent,
			onPlayAgain: i,
			onBackToLobby: a
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/bullet/entry.tsx
var Bt = {
	definition: nt,
	View: _t,
	bot: kt,
	fx: Rt,
	OverView: zt,
	locales: {
		zh: {
			name: "弹丸甜心",
			desc: "在弹幕中拼图清场,把子弹轰给左手边的对手",
			rules: "目标:在弹幕中存活到最后。将视野中清除的子弹送给左侧对手。\n准备:\n· 每人选一名女主角,获得她的行动、星行动、独有技能与专属图案牌堆,并抽 3 张图案作手牌。\n· 视野是 5 列、6 行的网格。中央弹袋共 140 颗子弹,开局每人从中央随机抽 10 颗放入自己的弹袋。\n· 强度轨从 4 起步,随回合攀升。\n流程:每回合所有人同时自由行动,顺序与次数不限——\n· 放置子弹:从弹袋抽一颗,放进颜色对应的列,落在该列第「数字」个空格(跳过已占的格子)。落出视野底边即被命中,扣 1 点生命。\n· 使用行动:消耗行动点(AP)移动子弹、抽图案等,行动写在各自的行动板上。\n· 使用图案:图案网格与视野中的排列完全一致(不可旋转/镜像)时可打出,清除 X 格上的子弹,送入左手边对手的来袭区。\n· 清除带星子弹时(任何方式),触发你行动板上所有星行动。\n· 弹袋用尽后，才能结束本轮行动；所有玩家都结束行动后，进入结束阶段：从中央选择并拿取一个道具、补抽图案至手牌上限、再按强度从中央抽弹放入弹袋。\n· 随后强度上升 1(本回合每有一人失去生命再上升 1),来袭区的子弹倒入弹袋,将行动点恢复至上限,开始新回合。\n结束:\n· 只剩一名女主角存活时她获胜;同一回合全员倒下时,弹袋余弹最少者获胜,若仍然相同，则进入死亡加赛。\n· 中央弹袋被抽空时,全员力竭,平局。\n单人冲分:没有道具;清除的子弹放上强度轨,每颗使当回合强度上升 1;成绩等于存活的回合数。",
			mode: "模式",
			modeFfa: "自由对战(2-4 人)",
			modeScore: "单人冲分(1 人)",
			pickTitle: "选择你的女主角",
			pickWaiting: "等待其他玩家选择…",
			difficulty: "难度",
			round: "第 {{n}} 回合",
			intensity: "强度 {{n}}",
			ap: "AP",
			life: "生命",
			actionPoints: "行动点",
			actionsTitle: "行动",
			patternsTitle: "图案",
			starActionTitle: "星行动",
			cellLabel: "第 {{row}} 行，第 {{col}} 列",
			bulletLabel: "{{color}}色 {{n}} 号子弹",
			faceDownBullet: "面朝下的子弹",
			starBullet: "星弹",
			crosshairLabel: "准星",
			marielLabel: "玛丽尔标记",
			colors: {
				R: "红",
				B: "蓝",
				G: "绿",
				Y: "黄",
				P: "粉紫"
			},
			currentBag: "弹袋",
			incomingBag: "来袭",
			centerBag: "中央",
			placeBullet: "放置子弹",
			endTurn: "收工",
			endTurnHint: "弹袋抽空后才能收工",
			waitingDone: "已收工,等待其他玩家…",
			eliminated: "已被击坠,等待回合结算…",
			placeMarielMarker: "把玛丽尔标记放到视野任意格",
			placeCrosshairs: "把两个准星放到视野任意格",
			endPhaseTitle: "结束阶段",
			endTakePowerup: "从中央选拿一个道具",
			endNoPowerup: "不拿道具",
			endReplace: "槽位已满:选一个槽位替换,或不拿",
			endDiscardDown: "弃掉 {{n}} 张图案至手牌上限",
			endSubmit: "完成结束阶段",
			endWaiting: "等待其他玩家完成结束阶段…",
			suddenDeath: "死亡加赛!只能放置子弹,先被击中者落败",
			scoreResult: "存活回合数",
			tieExhausted: "中央弹袋抽空,全员力竭——平局",
			riePickPrompt: "展示了两颗子弹:选择要放置的一颗",
			starChoicePrompt: "星行动:选择目标,或放弃",
			starSkip: "放弃",
			bonusClearPrompt: "选择要清除的子弹(至多 {{n}} 颗)",
			confirmClear: "清除",
			cancel: "取消",
			hintDefault: "放子弹、用行动或打图案;弹袋抽空后才能收工",
			hintFrom: "① 点要移动的子弹",
			hintTo: "② 点目标格",
			hintCell: "点视野中的一个格子",
			hintOrigin: "点视野中的格子,图案的左上角对齐这里",
			hintCrossFrom: "① 点一个准星",
			hintSwap: "依次点两颗子弹,交换它们",
			hintPutTwo: "依次点两颗子弹,放回中央",
			hintLife: "点生命区的一颗子弹,清除它",
			deckShort: "牌堆 {{n}}",
			discardShort: "弃牌 {{n}}",
			lifeRow: "生命区",
			errPhase: "现在不能这么做",
			errNotYours: "这不是你的子弹",
			errHeroineTaken: "这名女主角已被选走",
			errNoAp: "行动点不够",
			errBadMove: "不能这样移动",
			errBadCell: "这个位置不行",
			errBadPattern: "排列不匹配",
			errBadBonus: "奖励清除的数量或位置不对",
			errNotEmpty: "弹袋还没抽空,不能收工",
			errNoPowerup: "没有可用的道具",
			errPending: "先处理完当前的选择",
			errBadDiscard: "要弃的图案数量不对",
			hero: {
				esfir: {
					name: "艾斯菲尔·沃尔科娃",
					title: "红矮星",
					ua: "全力",
					uaDesc: "你的图案手牌上限为 4。"
				},
				adelheid: {
					name: "阿德海德·贝肯鲍尔",
					title: "音乐炼金术士",
					ua: "作曲",
					uaDesc: "你视野中面朝下的子弹视为所有颜色,且没有数字与星。"
				},
				ekolu: {
					name: "埃可露·卡帕卡希",
					title: "高阶圣三角使",
					ua: "圣形教诲",
					uaDesc: "你有 3 点生命、6 点 AP 与 9 张图案。你视野中的「3」子弹视为所有数字。每回合使用第 3 张图案时,清除视野中所有「3」子弹。"
				},
				lingling: {
					name: "萧玲玲",
					title: "科技狂",
					ua: "计算中",
					uaDesc: "「+」格不需要匹配子弹。使用图案时,把「+」格上子弹的数字相加:合计 6-9 则清除图案外至多 2 颗子弹;10-12 则清除图案外至多 3 颗;13 以上则清除图案内至多 3 颗。"
				},
				mariel: {
					name: "玛丽尔·马丁",
					title: "永远无聊的纸艺师",
					ua: "在场",
					uaDesc: "开局把玛丽尔标记放在视野任意格。她视为一颗没有颜色和数字的子弹。当她将被移出视野时,改为放到任意空格。"
				},
				rie: {
					name: "赤木理惠",
					title: "棒球混混",
					ua: "想得美!",
					uaDesc: "你有 2 点生命。你的图案顶部标有颜色;与你弃牌堆顶图案同色的子弹将命中你时,改为清除它。"
				},
				senka: {
					name: "森卡·卡桑",
					title: "过一天算一天的杀手",
					ua: "锁定目标",
					uaDesc: "开局把 2 个准星放在视野任意格。你的图案会从每个满足图案要求的准星处分别结算。准星与子弹可同处一格;放置子弹时不跳过只有准星的格子。"
				},
				youngja: {
					name: "金英子",
					title: "往昔的调皮鬼神",
					ua: "悬浮",
					uaDesc: "箭头格不需要匹配子弹。使用图案时,箭头格上的子弹同时向箭头方向移动 1 格,被推撞的子弹连锁让位。子弹可从左、右、上方移出视野并被清除。"
				}
			},
			act: {
				moveLrd: "移动一颗子弹:左、右或下 1 格",
				moveUp: "上移一颗子弹 1 格",
				moveDown: "下移一颗子弹任意格数",
				moveDiag: "斜向移动一颗子弹 1 格",
				moveNum: "将一颗子弹沿一个方向移动等于其数字的格数",
				slide: "将一颗子弹沿正交方向滑到最远处",
				push: "推动一颗子弹 1 格,被撞的子弹连锁让位",
				draw: "抽一张图案",
				discardDraw: "弃一张图案,然后抽一张图案",
				placeCenter: "从中央随机取一颗子弹,直接放入任意空格",
				boostNext: "你打出的下一张图案总数 +1",
				anyNext: "你打出的下一张图案,要求全部视为「任意子弹」",
				moveMarker: "把玛丽尔标记移到任意空格",
				clearAdj: "清除一颗与玛丽尔标记正交相邻的子弹",
				reveal: "从弹袋随机展示 2 颗子弹,放置其中 1 颗,放回另 1 颗",
				clearLife: "清除生命区中的一颗子弹",
				moveCross: "将一个准星沿正交方向移动 1-2 格",
				gainAp: "获得 1 点 AP",
				flip: "将视野中一颗子弹翻面",
				moveCross1: "将一个准星沿正交方向移动 1 格"
			},
			pow: {
				gainAp: "获得 1 点 AP",
				drawCard: "抽一张图案",
				drawDiscard: "从弃牌堆顶抽一张图案",
				clearCenter: "从中央随机清除一颗子弹",
				clearSight: "清除你视野中的一颗子弹",
				moveAny: "移动一颗子弹到任意空格",
				swap: "交换视野中的两颗子弹",
				putTwo: "把视野中的两颗子弹放回中央",
				copy: "复制你持有的另一个道具"
			},
			pat: {
				adelheid: {
					0: "熔焰旋律",
					1: "木质华尔兹",
					2: "燃素乐句",
					3: "指挥",
					4: "催化和弦",
					5: "坠落重拍",
					6: "交叉淡变",
					7: "热能渐强",
					8: "焚桥",
					9: "贝多芬"
				},
				ekolu: {
					0: "三重进攻",
					1: "摩利之傲",
					2: "弗洛伊德之叛",
					3: "阿波罗尼奥斯之婪",
					4: "毕达哥拉斯之躁",
					5: "三角化",
					6: "帕斯卡之怠",
					7: "小野之妄",
					8: "海伦之羞"
				},
				esfir: {
					0: "逃逸速度",
					1: "黑色獠牙",
					2: "重力井",
					3: "自由漂浮",
					4: "碾压之力",
					5: "星光破坏者",
					6: "流星",
					7: "一亿九千万G对撞机",
					8: "超新星",
					9: "引力子帷幕"
				},
				lingling: {
					0: "手指枪大乱射",
					1: "磁力射线 V2",
					2: "氩气炸弹 V1.0",
					3: "方块转换器 V.1.0",
					4: "推进增幅器 V0.1",
					5: "放射激光死亡凝视",
					6: "临界过载致盲闪光",
					7: "斥力射线 V2",
					8: "全息弹 V1.2.2",
					9: "盲眼礼炮"
				},
				mariel: {
					0: "折纸:刀",
					1: "折纸:千鹤齐飞",
					2: "纸艺:原子弹",
					3: "纸艺:阔剑雷",
					4: "折纸:赏花祭",
					5: "纸艺:马格南",
					6: "纸艺:子弹列车",
					7: "折纸:飘零仙人掌花",
					8: "纸艺:电击枪",
					9: "纸艺:纸飞机"
				},
				rie: {
					0: "完封大胜",
					1: "雨天改期",
					2: "小行星带",
					3: "手臂火箭筒",
					4: "双重赛",
					5: "登月弹",
					6: "猛击混战",
					7: "终极满贯炮",
					8: "曲球",
					9: "破坏指节"
				},
				senka: {
					0: "奥古 A10 M1",
					1: "C 系列原型机-凯瑟琳",
					2: "凯恩 M30",
					3: "双管枪",
					4: "星辰 .12",
					5: "重型火炮",
					6: "七级夜视仪",
					7: "魔法施放器",
					8: "陌生人",
					9: "寻宝猎人"
				},
				youngja: {
					0: "报丧女妖之嚎",
					1: "到场即死",
					2: "甩头狂",
					3: "跳脸杀",
					4: "局地山洪",
					5: "就在你身后",
					6: "惊声尖叫",
					7: "脊背发凉",
					8: "恐怖噪音",
					9: "吵醒死人"
				}
			}
		},
		en: {
			name: "Bullet♥",
			desc: "Clear patterns in your bullet-riddled sight and bury your left neighbor in lead",
			rules: "Goal: Be the last heroine standing. Clear bullets from your sight and send them to the player on your left.\nSetup:\n· Each player picks a heroine with her own actions, star actions, unique ability and pattern deck, then draws 3 patterns.\n· Your sight has 5 columns and 6 rows. The center holds 140 bullets; each player draws 10 at random into their own bag.\n· The intensity track starts at 4 and climbs every round.\nPlay: Each round, everyone acts simultaneously, in any order, as often as they can —\n· Place bullets: draw from your bag, drop it into the column matching its color, landing on the Nth open space down (N = its number), skipping occupied spaces. Falling off the bottom means a hit: lose 1 life.\n· Use actions: spend AP to move bullets, draw patterns, and more, as listed on your board.\n· Use patterns: if a pattern grid exactly matches an arrangement in your sight (no rotating or mirroring), play it to clear the bullets on its X spaces, sending them to the incoming area of the player on your left.\n· Clearing a starred bullet (by any means) triggers all of your star actions.\n· You may only finish once your bag is empty. When everyone is done, the End Phase begins: take one powerup from the middle, redraw patterns up to your hand size, then draw bullets from the center equal to the intensity.\n· Then intensity rises by 1 (plus 1 per heroine who lost life this round), incoming bullets pour into your bag, AP refills, and a new round begins.\nGame end:\n· The last heroine standing wins. If everyone falls in the same round, whoever has the fewest bullets left in their bag wins; still tied, sudden death decides.\n· If the center runs out of bullets, everyone is exhausted — the game is a tie.\nScore Attack (solo): no powerups; cleared bullets go onto the intensity track, each raising this round's intensity by 1; your score is the number of rounds you survive.",
			mode: "Mode",
			modeFfa: "Free-For-All (2-4p)",
			modeScore: "Score Attack (1p)",
			pickTitle: "Choose your heroine",
			pickWaiting: "Waiting for others to pick…",
			difficulty: "Difficulty",
			round: "Round {{n}}",
			intensity: "Intensity {{n}}",
			ap: "AP",
			life: "Life",
			actionPoints: "Action points",
			actionsTitle: "Actions",
			patternsTitle: "Patterns",
			starActionTitle: "Star action",
			cellLabel: "Row {{row}}, column {{col}}",
			bulletLabel: "{{color}} {{n}} bullet",
			faceDownBullet: "Face-down bullet",
			starBullet: "Starred bullet",
			crosshairLabel: "Crosshair",
			marielLabel: "Mariel marker",
			colors: {
				R: "Red",
				B: "Blue",
				G: "Green",
				Y: "Yellow",
				P: "Pink"
			},
			currentBag: "Bag",
			incomingBag: "Incoming",
			centerBag: "Center",
			placeBullet: "Place bullet",
			endTurn: "Finish",
			endTurnHint: "You can only finish once your bag is empty",
			waitingDone: "Finished. Waiting for others…",
			eliminated: "Shot down — waiting for the round to settle…",
			placeMarielMarker: "Place the Mariel marker in your sight",
			placeCrosshairs: "Place 2 crosshairs in your sight",
			endPhaseTitle: "End Phase",
			endTakePowerup: "Take one powerup from the middle",
			endNoPowerup: "Take none",
			endReplace: "Slots full: pick a slot to replace, or take none",
			endDiscardDown: "Discard {{n}} pattern(s) down to your hand size",
			endSubmit: "Done with End Phase",
			endWaiting: "Waiting for others to finish the End Phase…",
			suddenDeath: "Sudden death! Place bullets only — first to get hit loses",
			scoreResult: "Rounds survived",
			tieExhausted: "The center ran dry — everyone is exhausted. Tie!",
			riePickPrompt: "Two bullets revealed: pick one to place",
			starChoicePrompt: "Star action: pick a target, or skip",
			starSkip: "Skip",
			bonusClearPrompt: "Pick bullets to clear (up to {{n}})",
			confirmClear: "Clear",
			cancel: "Cancel",
			hintDefault: "Place bullets, use actions or patterns; finish only when your bag is empty",
			hintFrom: "1. Tap the bullet to move",
			hintTo: "2. Tap the target space",
			hintCell: "Tap a space in your sight",
			hintOrigin: "Tap a space; the pattern's top-left corner lands there",
			hintCrossFrom: "1. Tap a crosshair",
			hintSwap: "Tap two bullets to swap them",
			hintPutTwo: "Tap two bullets to put back into the center",
			hintLife: "Tap a bullet in your life area to clear it",
			deckShort: "Deck {{n}}",
			discardShort: "Discard {{n}}",
			lifeRow: "Life area",
			errPhase: "Not right now",
			errNotYours: "Not yours to use",
			errHeroineTaken: "That heroine is taken",
			errNoAp: "Not enough AP",
			errBadMove: "Cannot move like that",
			errBadCell: "Not a valid space",
			errBadPattern: "The arrangement does not match",
			errBadBonus: "Wrong bonus clears",
			errNotEmpty: "Your bag is not empty yet",
			errNoPowerup: "No powerup available",
			errPending: "Finish the pending choice first",
			errBadDiscard: "Wrong number of patterns to discard",
			hero: {
				esfir: {
					name: "Esfir Volkova",
					title: "The Red Dwarf Star",
					ua: "Full Power",
					uaDesc: "Your pattern hand size is 4."
				},
				adelheid: {
					name: "Adelheid Beckenbauer",
					title: "Musical Alchemist",
					ua: "Compose",
					uaDesc: "Face-down bullets in your sight are all colors and have no number or stars."
				},
				ekolu: {
					name: "Ekolu Kapakahi",
					title: "High Centroid Triometron",
					ua: "Sacred Shape's Teachings",
					uaDesc: "You have 3 life, 6 AP, and 9 patterns. \"3\" bullets in your sight are all numbers. When you use your third pattern in a round, clear all \"3\" bullets in your sight."
				},
				lingling: {
					name: "Ling-Ling Xiao",
					title: "Technological Fanatic",
					ua: "Calculating",
					uaDesc: "\"+\" spaces need no matching bullet. When you use a pattern, total the numbers on bullets in the \"+\" spaces: 6-9 clears up to 2 bullets outside the pattern; 10-12 clears up to 3 outside; 13+ clears up to 3 inside."
				},
				mariel: {
					name: "Mariel Martin",
					title: "Eternally Bored Papercrafter",
					ua: "Active",
					uaDesc: "During setup, place the Mariel marker on any space in your sight. She counts as a bullet with no color or number. When she would be removed from your sight, put her on any empty space instead."
				},
				rie: {
					name: "Rie Akagi",
					title: "Baseball-loving Gangster",
					ua: "Nice Try!",
					uaDesc: "You have 2 life. Your patterns show a color on top. When a bullet sharing the color of your discard pile's top card would hit you, clear it instead."
				},
				senka: {
					name: "Senka Kasun",
					title: "Hitman Surviving From Day to Day",
					ua: "Draw a Bead",
					uaDesc: "During setup, place 2 crosshairs on any spaces in your sight. Your patterns resolve once from each crosshair whose pattern requirements are met. Crosshairs and bullets can share a space; when placing bullets, spaces holding only a crosshair are not skipped."
				},
				youngja: {
					name: "Young-Ja Kim",
					title: "Mischievous Gwisin of Times Past",
					ua: "Levitation",
					uaDesc: "Arrow spaces need no matching bullet. When you use a pattern, all bullets on arrows move 1 space in the arrow's direction at once, shoving others aside in a chain. Bullets may leave your sight left, right, or up, and are cleared when they do."
				}
			},
			act: {
				moveLrd: "Move a bullet left, right, or down 1 space",
				moveUp: "Move a bullet up 1 space",
				moveDown: "Move a bullet down any number of spaces",
				moveDiag: "Move a bullet diagonally 1 space",
				moveNum: "Move a bullet in one direction a number of spaces equal to its number",
				slide: "Slide a bullet orthogonally as far as possible",
				push: "Push a bullet 1 space; shoved bullets chain",
				draw: "Draw a pattern",
				discardDraw: "Discard a pattern to draw a pattern",
				placeCenter: "Put a random bullet from the center into any empty space",
				boostNext: "Add 1 to the total of your next pattern",
				anyNext: "Your next pattern's requirements all become \"any bullet\"",
				moveMarker: "Move the Mariel marker to any empty space",
				clearAdj: "Clear a bullet orthogonally adjacent to the Mariel marker",
				reveal: "Reveal 2 random bullets from your bag; place 1, return the other",
				clearLife: "Clear a bullet from your life",
				moveCross: "Move a crosshair orthogonally 1-2 spaces",
				gainAp: "Gain 1 AP",
				flip: "Flip a bullet in your sight face-down",
				moveCross1: "Move a crosshair orthogonally 1 space"
			},
			pow: {
				gainAp: "Gain 1 AP",
				drawCard: "Draw a pattern",
				drawDiscard: "Draw a pattern from the top of the discard",
				clearCenter: "Clear a random bullet from the center",
				clearSight: "Clear a bullet in your sight",
				moveAny: "Move a bullet to any space",
				swap: "Swap 2 bullets in your sight",
				putTwo: "Put 2 bullets from your sight back into the center",
				copy: "Copy another powerup you have"
			},
			pat: {
				adelheid: {
					0: "Molten Melody",
					1: "Wooden Waltz",
					2: "Phlogistic Phrase",
					3: "Conduct",
					4: "Catalyst Chord",
					5: "The Drop",
					6: "Cross Fade",
					7: "Caloric Crescendo",
					8: "Burning Bridges",
					9: "Beethoven"
				},
				ekolu: {
					0: "Tri Attack",
					1: "Morley's Arrogance",
					2: "Floyd's Betrayal",
					3: "Apollonius' Greed",
					4: "Pythagoras' Impatience",
					5: "Trigonometrize",
					6: "Pascal's Neglect",
					7: "Ono's Hubris",
					8: "Heron's Shame"
				},
				esfir: {
					0: "Escape Velocity",
					1: "Black Fang",
					2: "Gravity Well",
					3: "Free Floating",
					4: "Crushing Force",
					5: "Starlight Buster",
					6: "Shooting Star",
					7: "190,000,000G Collider",
					8: "Supernova",
					9: "Graviton Curtain"
				},
				lingling: {
					0: "Finger Guns Shoot Em Up",
					1: "Magnet Ray V2",
					2: "Ar Bomb V1.0",
					3: "Tetro-Converter V.1.0",
					4: "Boost Booster V0.1",
					5: "Emission Laser Death Glare",
					6: "Critical Overload Flash Blind",
					7: "Repulsion Ray V2",
					8: "Soligram Bullet V1.2.2",
					9: "Blind Eye Salute"
				},
				mariel: {
					0: "Origami: Katana",
					1: "Origami: Flight of 1000 Cranes",
					2: "Papercraft: A-Bomb",
					3: "Papercraft: Claymore",
					4: "Origami: Flower Viewing Festival",
					5: "Papercraft: Magnum",
					6: "Papercraft: Bullet Train",
					7: "Origami: Falling Cactus Blossoms",
					8: "Papercraft: Taser",
					9: "Papercraft: Airplane"
				},
				rie: {
					0: "Blowout",
					1: "Rain Check",
					2: "Asteroid Belt",
					3: "Arm Bazooka",
					4: "Doubleheader",
					5: "Moonshot",
					6: "Slugfest",
					7: "Ultimate Grand Slam",
					8: "Curveball",
					9: "Buster Knuckle"
				},
				senka: {
					0: "Aug A10 M1",
					1: "C-Series Prototype - Catherine",
					2: "Caine M30",
					3: "Double Barrel",
					4: "Etoile .12",
					5: "Heavy Oronance",
					6: "Level 7 NVS",
					7: "Magic Caster",
					8: "The Stranger",
					9: "Treasure Chaser"
				},
				youngja: {
					0: "Banshee Wail",
					1: "Dead On Arrival",
					2: "Headbanger",
					3: "Jump Scare",
					4: "Localized Flash Flood",
					5: "Right Behind You",
					6: "Shock Scream",
					7: "Spine Chiller",
					8: "Terror Noise",
					9: "Wake The Dead"
				}
			}
		}
	}
};
//#endregion
export { Bt as default };
