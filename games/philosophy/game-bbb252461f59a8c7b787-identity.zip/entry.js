import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { useT as o } from "@bgparty/sdk/i18n";
import { IconRotate as s } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as c } from "@bgparty/sdk/player-colors";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as ee } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as te } from "@bgparty/sdk/ui/player-strip";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { Floater as p, FlySprite as m, PulseBox as h } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as g } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/philosophy/meta.ts
var _ = {
	id: "philosophy",
	tier: "beta",
	mechanics: ["tile-placement", "grid-movement"],
	interactionTags: [],
	nameKey: "games.philosophy.name",
	descKey: "games.philosophy.desc",
	rulesKey: "games.philosophy.rules",
	icon: "💭",
	iconImg: "games/philosophy.webp",
	rulesUrl: {
		zh: "https://rules.bgparty.uuppi.com/philosophy/zh.pdf",
		en: "https://rules.bgparty.uuppi.com/philosophy/en.pdf"
	},
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#0f766e",
	releasedAt: "2026-09-16",
	search: {
		py: "zhe xue",
		init: "zx"
	},
	hotseat: "cover"
}, v = [
	"push",
	"cornerPush",
	"slideL",
	"slideR",
	"pullL",
	"pullR",
	"longShot",
	"cornerLongShot",
	"decision",
	"rephrase",
	"toss",
	"persuade"
], y = {
	push: {
		kind: "push",
		targetStyle: "orth1",
		nameKey: "games.philosophy.tile.push",
		descKey: "games.philosophy.tileDesc.push"
	},
	cornerPush: {
		kind: "cornerPush",
		targetStyle: "diag1",
		nameKey: "games.philosophy.tile.cornerPush",
		descKey: "games.philosophy.tileDesc.cornerPush"
	},
	slideL: {
		kind: "slideL",
		targetStyle: "orth1",
		nameKey: "games.philosophy.tile.slideL",
		descKey: "games.philosophy.tileDesc.slideL"
	},
	slideR: {
		kind: "slideR",
		targetStyle: "orth1",
		nameKey: "games.philosophy.tile.slideR",
		descKey: "games.philosophy.tileDesc.slideR"
	},
	pullL: {
		kind: "pullL",
		targetStyle: "orth1",
		nameKey: "games.philosophy.tile.pullL",
		descKey: "games.philosophy.tileDesc.pullL"
	},
	pullR: {
		kind: "pullR",
		targetStyle: "orth1",
		nameKey: "games.philosophy.tile.pullR",
		descKey: "games.philosophy.tileDesc.pullR"
	},
	longShot: {
		kind: "longShot",
		targetStyle: "orth2",
		nameKey: "games.philosophy.tile.longShot",
		descKey: "games.philosophy.tileDesc.longShot"
	},
	cornerLongShot: {
		kind: "cornerLongShot",
		targetStyle: "diag2",
		nameKey: "games.philosophy.tile.cornerLongShot",
		descKey: "games.philosophy.tileDesc.cornerLongShot"
	},
	decision: {
		kind: "decision",
		targetStyle: "diag1",
		nameKey: "games.philosophy.tile.decision",
		descKey: "games.philosophy.tileDesc.decision"
	},
	rephrase: {
		kind: "rephrase",
		targetStyle: "diag1",
		nameKey: "games.philosophy.tile.rephrase",
		descKey: "games.philosophy.tileDesc.rephrase"
	},
	toss: {
		kind: "toss",
		targetStyle: "orth1",
		nameKey: "games.philosophy.tile.toss",
		descKey: "games.philosophy.tileDesc.toss"
	},
	persuade: {
		kind: "persuade",
		targetStyle: "orth1",
		nameKey: "games.philosophy.tile.persuade",
		descKey: "games.philosophy.tileDesc.persuade"
	}
};
function b(e, t) {
	if (e < 0 || e >= 7 || t < 0 || t >= 7) return !1;
	let n = t === 0 || t === 6 ? 2 : +(t === 1 || t === 5);
	return e >= n && e < 7 - n;
}
function x(e, t) {
	return e >= 2 && e <= 4 && t >= 2 && t <= 4;
}
var S = [
	{
		x: 0,
		y: -1
	},
	{
		x: 1,
		y: 0
	},
	{
		x: 0,
		y: 1
	},
	{
		x: -1,
		y: 0
	}
], C = [
	{
		x: 1,
		y: -1
	},
	{
		x: 1,
		y: 1
	},
	{
		x: -1,
		y: 1
	},
	{
		x: -1,
		y: -1
	}
];
function w(e, t) {
	return (e === "orth1" || e === "orth2" ? S : C)[t & 3];
}
function T(e, t, n, r) {
	let i = w(e, r), a = e === "orth2" || e === "diag2" ? 2 : 1;
	return {
		x: t + i.x * a,
		y: n + i.y * a
	};
}
var E = (e) => ({
	x: -e.y,
	y: e.x
}), D = (e) => ({
	x: e.y,
	y: -e.x
}), O = E;
function ne(e, t, n, r, i) {
	let a = y[e], o = w(a.targetStyle, r), s = T(a.targetStyle, t, n, r);
	switch (e) {
		case "push":
		case "cornerPush":
		case "longShot":
		case "cornerLongShot": return {
			target: s,
			moves: [{
				self: !1,
				from: s,
				to: {
					x: s.x + o.x,
					y: s.y + o.y
				},
				dir: o
			}]
		};
		case "slideL": return {
			target: s,
			moves: [{
				self: !1,
				from: s,
				to: {
					x: s.x + D(o).x,
					y: s.y + D(o).y
				},
				dir: D(o)
			}]
		};
		case "slideR": return {
			target: s,
			moves: [{
				self: !1,
				from: s,
				to: {
					x: s.x + O(o).x,
					y: s.y + O(o).y
				},
				dir: O(o)
			}]
		};
		case "pullL":
		case "pullR": {
			let r = e === "pullL" ? D(o) : O(o);
			return {
				target: s,
				moves: [{
					self: !1,
					from: s,
					to: {
						x: t + r.x,
						y: n + r.y
					},
					dir: {
						x: t + r.x - s.x,
						y: n + r.y - s.y
					}
				}]
			};
		}
		case "decision": {
			let e = i === "R" ? O(o) : D(o);
			return {
				target: s,
				moves: [{
					self: !1,
					from: s,
					to: {
						x: s.x + e.x,
						y: s.y + e.y
					},
					dir: e
				}]
			};
		}
		case "toss": return {
			target: s,
			moves: [{
				self: !1,
				from: s,
				to: {
					x: t - o.x,
					y: n - o.y
				},
				dir: {
					x: -o.x,
					y: -o.y
				}
			}]
		};
		case "persuade": return {
			target: s,
			moves: [{
				self: !0,
				from: {
					x: t,
					y: n
				},
				to: {
					x: t - o.x,
					y: n - o.y
				},
				dir: {
					x: -o.x,
					y: -o.y
				}
			}, {
				self: !1,
				from: s,
				to: {
					x: t,
					y: n
				},
				dir: {
					x: -o.x,
					y: -o.y
				}
			}]
		};
		case "rephrase": return null;
	}
}
//#endregion
//#region src/games/philosophy/schema.ts
var k = t.enum(v), A = t.int().min(0).max(6), re = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		kind: k,
		x: A,
		y: A,
		rot: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("choose"),
		option: t.int().nonnegative()
	}),
	t.object({ type: t.literal("resign") })
]), j = t.string(), M = t.object({
	x: t.int(),
	y: t.int()
}), ie = t.object({
	id: t.int().nonnegative(),
	kind: k,
	owner: j,
	x: A,
	y: A,
	rot: t.int().min(0).max(3)
}), N = t.object({
	tileId: t.int().nonnegative(),
	param: t.union([t.enum(["L", "R"]), t.int().min(0).max(3)]).nullable()
}), P = t.object({
	phase: t.enum([
		"place",
		"choose",
		"done"
	]),
	turn: j,
	tiles: t.array(ie),
	players: t.array(t.object({
		rid: j,
		unplayed: t.array(k)
	})),
	firstMove: t.boolean(),
	pending: t.array(N).nullable(),
	winner: j.nullable(),
	winLine: t.array(M).nullable(),
	endReason: t.enum([
		"conclusion",
		"stuck",
		"resign"
	]).nullable()
}), F = t.object({}), I = 64, L = (e) => ({ code: e }), R = (e, t, n) => e.tiles.find((e) => e.x === t && e.y === n), z = (e, t) => v.filter((n) => !e.tiles.some((e) => e.owner === t && e.kind === n));
function B(e, t) {
	let n = y[t.kind], r = T(n.targetStyle, t.x, t.y, t.rot), i = b(r.x, r.y) ? R(e, r.x, r.y) : void 0;
	return !i || t.kind !== "rephrase" && i.owner === t.owner ? [] : t.kind === "decision" ? [{
		tileId: t.id,
		param: "L"
	}, {
		tileId: t.id,
		param: "R"
	}] : t.kind === "rephrase" ? [
		0,
		1,
		2,
		3
	].map((e) => ({
		tileId: t.id,
		param: e
	})) : [{
		tileId: t.id,
		param: null
	}];
}
function V(e) {
	let t = [];
	for (let n of e.tiles) {
		if (n.owner !== e.turn || e.activated.includes(n.id) && !e.rephrased.includes(n.id)) continue;
		let r = y[n.kind], i = T(r.targetStyle, n.x, n.y, n.rot), a = b(i.x, i.y) ? R(e, i.x, i.y) : void 0;
		a && (n.kind === "rephrase" || a.owner !== n.owner) && (e.triggered.includes(n.id) || e.triggered.includes(a.id)) && t.push(...B(e, n));
	}
	return t;
}
function H(e, t, n, r, i, a) {
	let o = (t, n, r) => {
		b(n, r) ? (i.push({
			id: t.id,
			kind: t.kind,
			rid: t.owner,
			rot: t.rot,
			from: {
				x: t.x,
				y: t.y
			},
			to: {
				x: n,
				y: r
			}
		}), t.x = n, t.y = r) : (a.push({
			id: t.id,
			kind: t.kind,
			rid: t.owner,
			rot: t.rot,
			from: {
				x: t.x,
				y: t.y
			}
		}), e.tiles.splice(e.tiles.indexOf(t), 1));
	}, s = [];
	for (let t = n.x, i = n.y;; t += r.x, i += r.y) {
		let n = R(e, t, i);
		if (!n) break;
		s.push(n);
	}
	for (let e = s.length - 1; e >= 0; --e) o(s[e], s[e].x + r.x, s[e].y + r.y);
	let c = e.tiles.find((e) => e.id === t);
	c && o(c, n.x, n.y);
}
function U(e, t, n) {
	let r = e.tiles.find((e) => e.id === t.tileId);
	if (!r) return;
	e.activated.push(r.id);
	let i = {
		x: r.x,
		y: r.y
	}, a = [], o = [], s = null;
	if (r.kind === "rephrase") {
		let n = T(y.rephrase.targetStyle, r.x, r.y, r.rot), i = R(e, n.x, n.y);
		i && typeof t.param == "number" ? (i.rot = t.param, s = {
			id: i.id,
			kind: i.kind,
			rid: i.owner,
			rot: i.rot,
			x: i.x,
			y: i.y
		}, e.triggered = [i.id], e.rephrased = i.owner === e.turn ? [i.id] : []) : (e.triggered = [], e.rephrased = []);
	} else {
		let n = t.param === "L" || t.param === "R" ? t.param : null, i = ne(r.kind, r.x, r.y, r.rot, n);
		if (i) for (let t of i.moves) {
			let n = R(e, t.from.x, t.from.y);
			n && H(e, n.id, t.to, t.dir, a, o);
		}
		e.triggered = a.map((e) => e.id), e.rephrased = [];
	}
	n.push({
		kind: "activate",
		data: {
			tileId: r.id,
			kind: r.kind,
			at: i,
			moves: a,
			returned: o,
			spin: s
		}
	});
}
var W = [
	{
		x: 1,
		y: 0
	},
	{
		x: 0,
		y: 1
	},
	{
		x: 1,
		y: 1
	},
	{
		x: 1,
		y: -1
	}
];
function ae(e, t) {
	for (let n of e.tiles) if (n.owner === t) for (let r of W) {
		let i = R(e, n.x + r.x, n.y + r.y), a = R(e, n.x + 2 * r.x, n.y + 2 * r.y);
		if (i?.owner === t && a?.owner === t) return [
			{
				x: n.x,
				y: n.y
			},
			{
				x: i.x,
				y: i.y
			},
			{
				x: a.x,
				y: a.y
			}
		];
	}
	return null;
}
var oe = [];
for (let e = 2; e <= 4; e += 1) for (let t = 2; t <= 4; t += 1) oe.push([t, e]);
function G(e) {
	return `${e.tiles.map((e) => `${e.id}:${e.x},${e.y},${e.rot}`).sort().join("|")}#${[...e.triggered].sort((e, t) => e - t).join(",")}`;
}
function K(e, t) {
	e.pending = null, e.chainHashes = [];
	let n = e.players.map((t) => ({
		p: t,
		line: ae(e, t)
	})).filter((e) => e.line !== null);
	if (n.length === 1) {
		e.phase = "done", e.winner = n[0].p, e.winLine = n[0].line, e.endReason = "conclusion", t.push({
			kind: "conclusion",
			rid: n[0].p,
			data: { line: n[0].line }
		});
		return;
	}
	let r = e.players[(e.players.indexOf(e.turn) + 1) % e.players.length];
	e.turn = r, e.phase = "place", e.activated = [], e.triggered = [], e.rephrased = [];
	let i = oe.every(([t, n]) => R(e, t, n) !== void 0);
	(z(e, r).length === 0 || i) && (e.phase = "done", e.winner = e.players.find((e) => e !== r) ?? null, e.endReason = "stuck", t.push({
		kind: "stuck",
		rid: r,
		data: {}
	}));
}
function se(e, t, n) {
	for (;;) {
		if (n.length === 0) return K(e, t);
		if (n.length > 1) {
			e.phase = "choose", e.pending = n;
			return;
		}
		U(e, n[0], t);
		let r = G(e);
		if (e.chainHashes.includes(r) || e.chainHashes.length >= I) return K(e, t);
		e.chainHashes.push(r), n = V(e);
	}
}
var q = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: _,
	schemas: {
		action: re,
		publicView: P,
		privateView: F
	},
	setup(t, n, r) {
		return { state: {
			players: [...n],
			tiles: [],
			nextTileId: 1,
			turn: n[e(r, 0, n.length)],
			phase: "place",
			pending: null,
			activated: [],
			triggered: [],
			rephrased: [],
			chainHashes: [],
			firstPlaced: !1,
			winner: null,
			winLine: null,
			endReason: null
		} };
	},
	reduce(e, t, { by: n }) {
		let r = structuredClone(e);
		if (t.type === "resign") return r.phase === "done" ? L("games.philosophy.errPhase") : r.players.includes(n) ? (r.phase = "done", r.winner = r.players.find((e) => e !== n) ?? null, r.endReason = "resign", {
			state: r,
			fx: [{
				kind: "resign",
				rid: n,
				data: {}
			}]
		}) : L("games.philosophy.errTurn");
		if (t.type === "place") {
			if (r.phase !== "place") return L("games.philosophy.errPhase");
			if (r.turn !== n) return L("games.philosophy.errTurn");
			if (!z(r, n).includes(t.kind)) return L("games.philosophy.errKind");
			if (!x(t.x, t.y)) return L("games.philosophy.errZone");
			if (!r.firstPlaced && t.x === 3 && t.y === 3) return L("games.philosophy.errCenter");
			if (R(r, t.x, t.y)) return L("games.philosophy.errOccupied");
			let e = {
				id: r.nextTileId,
				kind: t.kind,
				owner: n,
				x: t.x,
				y: t.y,
				rot: t.rot
			};
			r.nextTileId += 1, r.tiles.push(e), r.firstPlaced = !0, r.activated = [], r.triggered = [], r.rephrased = [];
			let i = [{
				kind: "place",
				rid: n,
				data: {
					id: e.id,
					kind: e.kind,
					x: e.x,
					y: e.y,
					rot: e.rot
				}
			}];
			return r.chainHashes = [G(r)], se(r, i, B(r, e)), {
				state: r,
				fx: i
			};
		}
		if (r.phase !== "choose" || !r.pending) return L("games.philosophy.errPhase");
		if (r.turn !== n) return L("games.philosophy.errTurn");
		let i = r.pending[t.option];
		if (!i) return L("games.philosophy.errOption");
		r.pending = null, r.phase = "place";
		let a = [];
		U(r, i, a);
		let o = G(r);
		return r.chainHashes.includes(o) || r.chainHashes.length >= I ? K(r, a) : (r.chainHashes.push(o), se(r, a, V(r))), {
			state: r,
			fx: a
		};
	},
	viewFor(e) {
		return {
			public: {
				phase: e.phase,
				turn: e.turn,
				tiles: e.tiles.map((e) => ({ ...e })),
				players: e.players.map((t) => ({
					rid: t,
					unplayed: z(e, t)
				})),
				firstMove: !e.firstPlaced,
				pending: e.pending ? e.pending.map((e) => ({ ...e })) : null,
				winner: e.winner,
				winLine: e.winLine ? e.winLine.map((e) => ({ ...e })) : null,
				endReason: e.endReason
			},
			private: {}
		};
	},
	status(e) {
		return e.phase !== "done" || !e.winner ? { phase: e.phase } : {
			phase: "done",
			winner: [e.winner],
			ranking: [e.winner, ...e.players.filter((t) => t !== e.winner)]
		};
	}
};
//#endregion
//#region src/games/philosophy/tile-view.tsx
function J({ angle: e, dashed: t }) {
	return /* @__PURE__ */ f("g", {
		transform: `rotate(${e})`,
		children: [/* @__PURE__ */ d("line", {
			x1: 0,
			y1: 20,
			x2: 0,
			y2: -14,
			stroke: "var(--color-ink)",
			strokeWidth: 7,
			strokeLinecap: "round",
			strokeDasharray: t ? "7 6" : void 0
		}), /* @__PURE__ */ d("path", {
			d: "M -11 -4 L 0 -19 L 11 -4",
			fill: "none",
			stroke: "var(--color-ink)",
			strokeWidth: 7,
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})]
	});
}
function ce({ kind: e }) {
	switch (e) {
		case "push":
		case "cornerPush": return /* @__PURE__ */ d(J, { angle: 0 });
		case "longShot":
		case "cornerLongShot": return /* @__PURE__ */ d(J, {
			angle: 0,
			dashed: !0
		});
		case "slideL": return /* @__PURE__ */ d(J, { angle: -90 });
		case "slideR": return /* @__PURE__ */ d(J, { angle: 90 });
		case "pullL": return /* @__PURE__ */ d(J, { angle: -135 });
		case "pullR": return /* @__PURE__ */ d(J, { angle: 135 });
		case "decision": return /* @__PURE__ */ f("g", {
			opacity: .9,
			children: [/* @__PURE__ */ d("g", {
				transform: "translate(4 0) scale(0.72)",
				children: /* @__PURE__ */ d(J, { angle: -90 })
			}), /* @__PURE__ */ d("g", {
				transform: "translate(-4 0) scale(0.72)",
				children: /* @__PURE__ */ d(J, { angle: 90 })
			})]
		});
		case "rephrase": return /* @__PURE__ */ f("g", {
			fill: "none",
			stroke: "var(--color-ink)",
			strokeWidth: 7,
			strokeLinecap: "round",
			children: [/* @__PURE__ */ d("path", { d: "M 17 4 A 17 17 0 1 1 4 -17" }), /* @__PURE__ */ d("path", {
				d: "M 13 -15 L 3 -18 L 5 -7",
				strokeLinejoin: "round"
			})]
		});
		case "toss": return /* @__PURE__ */ f("g", {
			fill: "none",
			stroke: "var(--color-ink)",
			strokeWidth: 7,
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: [/* @__PURE__ */ d("path", { d: "M -4 -22 Q 30 -6 6 16" }), /* @__PURE__ */ d("path", { d: "M -5 7 L 6 16 L 12 4" })]
		});
		case "persuade": return /* @__PURE__ */ f("g", { children: [/* @__PURE__ */ d(J, { angle: 180 }), /* @__PURE__ */ d("circle", {
			cx: 0,
			cy: -24,
			r: 5.5,
			fill: "var(--color-ink)"
		})] });
	}
}
function Y({ kind: e, rot: t, color: n, cell: r, ghost: i }) {
	let a = r / 2, o = (y[e].targetStyle === "diag1" || y[e].targetStyle === "diag2" ? 45 : 0) + t * 90, s = r / 100;
	return /* @__PURE__ */ f("g", { children: [
		/* @__PURE__ */ d("rect", {
			x: -a + 2,
			y: -a + 2,
			width: r - 4,
			height: r - 4,
			rx: r * .14,
			fill: "var(--color-surface)",
			stroke: "var(--color-ink)",
			strokeWidth: 2.5,
			strokeDasharray: i ? "6 4" : void 0
		}),
		/* @__PURE__ */ d("rect", {
			x: -a + 8,
			y: -a + 8,
			width: r - 16,
			height: r - 16,
			rx: r * .09,
			fill: "none",
			stroke: n,
			strokeWidth: 3.5
		}),
		/* @__PURE__ */ f("g", {
			transform: `rotate(${o}) scale(${s})`,
			children: [/* @__PURE__ */ d("path", {
				d: "M -9 -31 L 9 -31 L 0 -44 Z",
				fill: n,
				stroke: "var(--color-ink)",
				strokeWidth: 2.5,
				strokeLinejoin: "round"
			}), /* @__PURE__ */ d(ce, { kind: e })]
		})
	] });
}
function X({ kind: e, rot: t, color: n, size: r, ghost: i }) {
	return /* @__PURE__ */ d("svg", {
		viewBox: "-50 -50 100 100",
		style: {
			width: r,
			height: r
		},
		"aria-hidden": !0,
		children: /* @__PURE__ */ d(Y, {
			kind: e,
			rot: t,
			color: n,
			cell: 92,
			ghost: i
		})
	});
}
//#endregion
//#region src/games/philosophy/view-player.tsx
var Z = 100;
function le(e) {
	let t = e.public;
	return /* @__PURE__ */ d(ue, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ue({ pub: e, members: t, myRid: n, send: r }) {
	let a = o(), [p, m] = i(null), [h, g] = i(null), [v, b] = i(null), [S, C] = i(!1), w = e.turn === n && e.phase !== "done", E = w && e.phase === "place", D = w && e.phase === "choose", O = `${e.phase}:${e.turn}:${e.tiles.length}:${e.pending?.length ?? ""}`, [k, A] = i(O);
	k !== O && (A(O), m(null), g(null), b(null), C(!1));
	let re = (e) => t.find((t) => t.rid === e)?.name ?? e, j = (e) => {
		let n = t.find((t) => t.rid === e);
		return c[(n?.colorIndex ?? 0) % c.length].hex;
	}, M = e.players.find((e) => e.rid === n), ie = new Set(e.tiles.map((e) => e.x + e.y * 7)), N = (t, n) => x(t, n) && !ie.has(t + n * 7) && !(e.firstMove && t === 3 && n === 3), P = e.pending ?? [], F = [...new Set(P.map((e) => e.tileId))], I = v === null ? [] : P.filter((e) => e.tileId === v), L = v === null ? null : e.tiles.find((e) => e.id === v) ?? null, R = L?.kind ?? null, z = L && R === "decision" ? I.map((e) => {
		let t = ne("decision", L.x, L.y, L.rot, e.param === "R" ? "R" : "L");
		return {
			option: P.indexOf(e),
			to: t?.moves[0].to ?? null
		};
	}) : [], B = (() => {
		if (!L || R !== "rephrase") return null;
		let t = T(y.rephrase.targetStyle, L.x, L.y, L.rot);
		return e.tiles.find((e) => e.x === t.x && e.y === t.y) ?? null;
	})(), V = (e, t) => {
		E && p && N(e, t) && g({
			x: e,
			y: t
		});
	}, H = (e) => {
		if (!D || !F.includes(e.id)) return;
		if (v === e.id) {
			b(null);
			return;
		}
		let t = P.filter((t) => t.tileId === e.id);
		t.length === 1 ? r({
			type: "choose",
			option: P.indexOf(t[0])
		}) : b(e.id);
	}, U = "info", W;
	return e.phase === "done" ? (U = "done", W = e.winner === n ? a("games.philosophy.stageWin") : a("games.philosophy.stageLose")) : E ? (U = "accent", W = a("games.philosophy.stagePlace")) : D ? (U = "accent", W = a("games.philosophy.stageChoose")) : W = a(e.phase === "choose" ? "games.philosophy.waitChoose" : "games.philosophy.waitTurn", { name: re(e.turn) }), /* @__PURE__ */ d(l, {
		adaptive: !0,
		scroll: !1,
		className: "ph-game",
		banner: /* @__PURE__ */ f("div", {
			className: "ph-header",
			children: [/* @__PURE__ */ d(ee, {
				tone: U,
				text: W,
				chip: a("games.philosophy.tilesChip", { n: M?.unplayed.length ?? 0 }),
				accent: _.accent
			}), /* @__PURE__ */ d(te, {
				members: t.filter((t) => e.players.some((e) => e.rid === t.rid)),
				myRid: n,
				variant: "plate",
				anchorOf: (e) => `seat:${e}`,
				action: (t) => e.phase !== "done" && t === e.turn ? "pending" : null,
				status: (t) => {
					let n = e.players.find((e) => e.rid === t);
					return n ? /* @__PURE__ */ f("span", {
						"aria-label": a("games.philosophy.tilesAria", { n: n.unplayed.length }),
						className: "ph-count flex items-center gap-0.5 rounded-md border border-ink bg-surface px-1 text-[10px] leading-3.5 font-bold",
						children: [/* @__PURE__ */ d("span", {
							"aria-hidden": !0,
							children: "💭"
						}), /* @__PURE__ */ d("span", {
							className: "font-mono tabular-nums",
							children: n.unplayed.length
						})]
					}) : null;
				}
			})]
		}),
		children: /* @__PURE__ */ d("div", {
			className: "ph-stage",
			children: /* @__PURE__ */ f("div", {
				className: "ph-table",
				children: [/* @__PURE__ */ d(de, {
					pub: e,
					colorOf: j,
					ghost: E && p && h ? {
						...h,
						kind: p.kind,
						rot: p.rot
					} : null,
					legalCells: E && p ? N : null,
					candidateIds: D || e.phase === "choose" ? F : [],
					decisionMarks: z,
					onCellTap: V,
					onTileTap: H,
					onMarkTap: (e) => {
						r({
							type: "choose",
							option: e
						}), b(null);
					}
				}), /* @__PURE__ */ f("div", {
					className: "ph-console",
					children: [/* @__PURE__ */ f("div", {
						className: "ph-controls",
						children: [/* @__PURE__ */ d("div", {
							className: "ph-facing",
							children: D && B && /* @__PURE__ */ d(u, { children: I.map((e) => /* @__PURE__ */ d("button", {
								type: "button",
								"aria-label": a("games.philosophy.rotAria", { n: Number(e.param) }),
								onClick: () => {
									r({
										type: "choose",
										option: P.indexOf(e)
									}), b(null);
								},
								className: "ph-facing-choice card p-0.5",
								children: /* @__PURE__ */ d(X, {
									kind: B.kind,
									rot: Number(e.param),
									color: j(B.owner),
									size: "var(--ph-facing-size)"
								})
							}, e.param)) })
						}), /* @__PURE__ */ d("div", {
							className: "ph-action-slot",
							children: E ? /* @__PURE__ */ f("div", {
								className: "ph-place-actions",
								children: [
									/* @__PURE__ */ d("button", {
										type: "button",
										"aria-label": a("games.philosophy.rotate"),
										disabled: !p,
										onClick: () => m((e) => e && {
											...e,
											rot: (e.rot + 1) % 4
										}),
										className: "ph-rotate btn-quiet grid size-12 flex-none place-items-center",
										children: /* @__PURE__ */ d(s, {
											size: 20,
											"aria-hidden": !0
										})
									}),
									/* @__PURE__ */ d("button", {
										type: "button",
										disabled: !p || !h,
										onClick: () => {
											r({
												type: "place",
												kind: p.kind,
												x: h.x,
												y: h.y,
												rot: p.rot
											}), m(null), g(null);
										},
										className: "ph-confirm btn-base min-h-12 flex-1 text-sm text-white",
										style: { background: _.accent },
										children: a("games.philosophy.placeConfirm")
									}),
									/* @__PURE__ */ d("button", {
										type: "button",
										onClick: () => S ? r({ type: "resign" }) : C(!0),
										className: `ph-resign btn-quiet min-h-12 flex-none px-3 text-xs font-bold ${S ? "text-danger" : ""}`,
										children: a(S ? "games.philosophy.resignArmed" : "games.philosophy.resign")
									})
								]
							}) : D ? /* @__PURE__ */ d("p", {
								className: "ph-action-hint flex min-h-12 items-center justify-center text-xs font-bold opacity-70",
								children: a(R === "decision" ? "games.philosophy.decisionHint" : R === "rephrase" ? "games.philosophy.rephraseHint" : "games.philosophy.chooseHint")
							}) : /* @__PURE__ */ d("p", {
								className: "ph-action-hint flex min-h-12 items-center justify-center text-xs font-bold opacity-50",
								children: a("games.philosophy.watchHint")
							})
						})]
					}), /* @__PURE__ */ d("div", {
						className: "ph-tray",
						children: (M?.unplayed ?? []).map((e) => {
							let t = p?.kind === e;
							return /* @__PURE__ */ d("button", {
								type: "button",
								"aria-label": a(y[e].nameKey),
								disabled: !E,
								onClick: () => {
									m(t ? null : {
										kind: e,
										rot: 0
									}), g(null);
								},
								className: `ph-hand-tile rounded-xl p-0.5 ${t ? "ring-3 ring-ink ring-offset-1 ring-offset-paper" : ""} ${E ? "" : "opacity-70"}`,
								children: /* @__PURE__ */ d(X, {
									kind: e,
									rot: t ? p.rot : 0,
									color: j(n),
									size: "var(--ph-hand-size)"
								})
							}, e);
						})
					})]
				})]
			})
		})
	});
}
function de({ pub: e, colorOf: t, ghost: n, legalCells: r, candidateIds: i, decisionMarks: o, onCellTap: s, onTileTap: c, onMarkTap: l }) {
	let { ref: ee } = a("board"), te = new Set((e.winLine ?? []).map((e) => e.x + e.y * 7));
	return /* @__PURE__ */ d("div", {
		className: "ph-board-stage frame",
		children: /* @__PURE__ */ d("div", {
			ref: ee,
			className: "ph-board",
			children: /* @__PURE__ */ f("svg", {
				viewBox: "0 0 700 700",
				className: "h-full w-full",
				children: [
					Array.from({ length: 49 }, (e, t) => {
						let n = t % 7, i = Math.floor(t / 7);
						if (!b(n, i)) return null;
						let a = r?.(n, i) ?? !1, o = te.has(t);
						return /* @__PURE__ */ d("rect", {
							x: n * Z + 3,
							y: i * Z + 3,
							width: 94,
							height: 94,
							rx: 14,
							fill: o ? "var(--color-done-soft)" : a ? "color-mix(in srgb, var(--color-info) 22%, var(--color-surface))" : x(n, i) ? "color-mix(in srgb, var(--color-ink) 5%, var(--color-surface))" : "var(--color-surface)",
							stroke: o ? "var(--color-done)" : "color-mix(in srgb, var(--color-ink) 30%, transparent)",
							strokeWidth: o ? 4 : 2,
							className: a ? "cursor-pointer" : "",
							onClick: () => s(n, i)
						}, t);
					}),
					/* @__PURE__ */ d("circle", {
						cx: 350,
						cy: 350,
						r: 7,
						fill: "none",
						stroke: "color-mix(in srgb, var(--color-ink) 40%, transparent)",
						strokeWidth: 2.5
					}),
					e.tiles.map((e) => {
						let n = i.includes(e.id);
						return /* @__PURE__ */ f("g", {
							transform: `translate(${e.x * Z + Z / 2}, ${e.y * Z + Z / 2})`,
							onClick: () => c(e),
							className: n ? "cursor-pointer" : "",
							children: [n && /* @__PURE__ */ d("rect", {
								x: -46,
								y: -46,
								width: 92,
								height: 92,
								rx: 16,
								fill: "none",
								stroke: "var(--color-warn)",
								strokeWidth: 5,
								className: "animate-pulse"
							}), /* @__PURE__ */ d(Y, {
								kind: e.kind,
								rot: e.rot,
								color: t(e.owner),
								cell: 86
							})]
						}, e.id);
					}),
					o.map((e, t) => e.to && b(e.to.x, e.to.y) ? /* @__PURE__ */ f("g", {
						transform: `translate(${e.to.x * Z + Z / 2}, ${e.to.y * Z + Z / 2})`,
						onClick: () => l(e.option),
						className: "cursor-pointer",
						children: [/* @__PURE__ */ d("circle", {
							r: 26,
							fill: "var(--color-warn-soft)",
							stroke: "var(--color-ink)",
							strokeWidth: 3,
							className: "animate-pulse"
						}), /* @__PURE__ */ d("circle", {
							r: 8,
							fill: "var(--color-ink)"
						})]
					}, t) : null),
					n && /* @__PURE__ */ d("g", {
						transform: `translate(${n.x * Z + Z / 2}, ${n.y * Z + Z / 2})`,
						opacity: .6,
						children: /* @__PURE__ */ d(Y, {
							kind: n.kind,
							rot: n.rot,
							color: "var(--color-ink)",
							cell: 86,
							ghost: !0
						})
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/philosophy/bot.ts
function fe(e) {
	return {
		players: e.players.map((e) => e.rid),
		tiles: e.tiles.map((e) => ({ ...e })),
		nextTileId: e.tiles.reduce((e, t) => Math.max(e, t.id), 0) + 1,
		turn: e.turn,
		phase: e.phase,
		pending: e.pending ? e.pending.map((e) => ({ ...e })) : null,
		activated: [],
		triggered: [],
		rephrased: [],
		chainHashes: [],
		firstPlaced: !e.firstMove,
		winner: e.winner,
		winLine: e.winLine ? e.winLine.map((e) => ({ ...e })) : null,
		endReason: e.endReason
	};
}
function pe(e, t) {
	let n = (t, n) => e.tiles.find((e) => e.x === t && e.y === n), r = [
		{
			x: 1,
			y: 0
		},
		{
			x: 0,
			y: 1
		},
		{
			x: 1,
			y: 1
		},
		{
			x: 1,
			y: -1
		}
	], i = 0;
	for (let a of e.tiles) if (a.owner === t) for (let e of r) {
		if (n(a.x + e.x, a.y + e.y)?.owner !== t) continue;
		let r = (e, t) => b(e, t) && !n(e, t);
		(r(a.x - e.x, a.y - e.y) || r(a.x + 2 * e.x, a.y + 2 * e.y)) && (i += 1);
	}
	return i;
}
function me(e, t) {
	if (e.phase === "done") return e.winner === t ? 1e6 : e.winner ? -1e6 : 0;
	let n = e.players.find((e) => e.rid !== t)?.rid;
	return pe(e, t) * 3 - (n ? pe(e, n) * 5 : 0);
}
function he(e, t, n) {
	let r = q.reduce(fe(e), n, { by: t });
	return "code" in r ? null : q.viewFor(r.state, t).public;
}
var ge = (e, t) => {
	let n = e.public, r = t.rid;
	if (n.phase === "done" || n.turn !== r) return null;
	if (n.phase === "choose" && n.pending) {
		if (t.difficulty === "weak") return { action: {
			type: "choose",
			option: n.tiles.length % n.pending.length
		} };
		let e = 0, i = -Infinity;
		for (let t = 0; t < n.pending.length; t += 1) {
			let a = he(n, r, {
				type: "choose",
				option: t
			});
			if (!a) continue;
			let o = me(a, r);
			o > i && (i = o, e = t);
		}
		return { action: {
			type: "choose",
			option: e
		} };
	}
	if (n.phase !== "place") return null;
	let i = n.players.find((e) => e.rid === r);
	if (!i || i.unplayed.length === 0) return null;
	let a = new Set(n.tiles.map((e) => e.x + e.y * 7)), o = [];
	for (let e = 2; e <= 4; e += 1) for (let t = 2; t <= 4; t += 1) x(t, e) && !a.has(t + e * 7) && !(n.firstMove && t === 3 && e === 3) && o.push({
		x: t,
		y: e
	});
	let s = i.unplayed.flatMap((e) => o.flatMap((t) => [
		0,
		1,
		2,
		3
	].map((n) => ({
		type: "place",
		kind: e,
		x: t.x,
		y: t.y,
		rot: n
	}))));
	if (s.length === 0) return null;
	if (t.difficulty === "weak") return { action: s[(n.tiles.length * 7 + i.unplayed.length) % s.length] };
	let c = s[0], l = -Infinity;
	for (let e of s) {
		let t = he(n, r, e);
		if (!t) continue;
		let i = me(t, r);
		i > l && (l = i, c = e);
	}
	return { action: c };
}, _e = (e, t, n) => {
	if (e.type === "place") return n("games.philosophy.hintPlace", {
		tile: n(y[e.kind].nameKey),
		x: e.x + 1,
		y: e.y + 1
	});
	if (e.type === "choose") {
		let r = t.public.pending?.[e.option], i = r ? t.public.tiles.find((e) => e.id === r.tileId) : void 0;
		if (!i) return "";
		let a = n(y[i.kind].nameKey);
		return r?.param === "L" ? n("games.philosophy.hintChooseLeft", { tile: a }) : r?.param === "R" ? n("games.philosophy.hintChooseRight", { tile: a }) : typeof r?.param == "number" ? n("games.philosophy.hintChooseRot", {
			tile: a,
			rot: n("games.philosophy.rotAria", { n: r.param })
		}) : n("games.philosophy.hintChoose", { tile: a });
	}
	return "";
};
//#endregion
//#region src/games/philosophy/fx.tsx
function Q(e, t, n) {
	let r = Math.min(e.w, e.h), i = e.x + (e.w - r) / 2, a = e.y + (e.h - r) / 2, o = r / 7;
	return {
		x: i + t * o,
		y: a + n * o,
		w: o,
		h: o
	};
}
function $(e, t) {
	let n = e.member(t);
	return c[(n?.colorIndex ?? 0) % c.length].hex;
}
function ve({ kind: e, rid: t, ctx: n, rot: r = 0 }) {
	return /* @__PURE__ */ d("svg", {
		viewBox: "-50 -50 100 100",
		style: {
			width: "100%",
			height: "100%"
		},
		children: /* @__PURE__ */ d(Y, {
			kind: e,
			rot: r,
			color: $(n, t),
			cell: 92
		})
	});
}
function ye({ at: e, rot: t, kind: i, rid: a, ctx: o, ms: s }) {
	let c = r(null);
	return n(() => {
		let e = c.current;
		if (!e) return;
		let t = e.animate([{
			transform: "rotate(-90deg)",
			opacity: .4
		}, {
			transform: "rotate(0deg)",
			opacity: 1
		}], {
			duration: s,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => t.cancel();
	}, [s]), /* @__PURE__ */ d("div", {
		ref: c,
		className: "absolute",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ d("svg", {
			viewBox: "-50 -50 100 100",
			style: {
				width: "100%",
				height: "100%"
			},
			children: /* @__PURE__ */ d(Y, {
				kind: i,
				rot: t,
				color: $(o, a),
				cell: 92
			})
		})
	});
}
var be = (e) => {
	let t = e;
	return t && typeof t.tileId == "number" && t.at ? t : null;
}, xe = {
	place(e, t) {
		let n = e.data, r = t.anchor("board");
		return typeof n?.x != "number" || typeof n.y != "number" || !r ? null : {
			ms: 500,
			node: /* @__PURE__ */ d(h, {
				at: Q(r, n.x, n.y),
				ms: 500
			})
		};
	},
	activate(e, t) {
		let n = be(e.data), r = t.anchor("board");
		return !n || !r ? null : {
			ms: 700,
			node: /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d(h, {
					at: Q(r, n.at.x, n.at.y),
					ms: 500
				}),
				n.moves.map((e, n) => /* @__PURE__ */ d(m, {
					from: Q(r, e.from.x, e.from.y),
					to: Q(r, e.to.x, e.to.y),
					ms: 550,
					delay: n * 50,
					children: /* @__PURE__ */ d(ve, {
						kind: e.kind,
						rid: e.rid,
						ctx: t,
						rot: e.rot
					})
				}, `m${e.id}`)),
				n.returned.map((e, i) => {
					let a = t.anchor(`seat:${e.rid}`);
					return a ? /* @__PURE__ */ d(m, {
						from: Q(r, e.from.x, e.from.y),
						to: a,
						ms: 700,
						delay: n.moves.length * 50 + i * 60,
						children: /* @__PURE__ */ d(ve, {
							kind: e.kind,
							rid: e.rid,
							ctx: t,
							rot: e.rot
						})
					}, `r${e.id}`) : null;
				}),
				n.spin && /* @__PURE__ */ d(ye, {
					at: Q(r, n.spin.x, n.spin.y),
					rot: n.spin.rot,
					kind: n.spin.kind,
					rid: n.spin.rid,
					ctx: t,
					ms: 550
				})
			] })
		};
	},
	conclusion(e, t) {
		let n = e.data, r = t.anchor("board");
		return !n?.line || !r ? null : {
			ms: 1400,
			node: /* @__PURE__ */ d(u, { children: n.line.map((e, t) => /* @__PURE__ */ d(h, {
				at: Q(r, e.x, e.y),
				ms: 1400,
				delay: t * 120
			}, t)) })
		};
	},
	stuck(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ d(p, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ d("span", { children: "🚫💭" })
			})
		} : null;
	},
	resign(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ d(p, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ d("span", { children: "🏳️" })
			})
		} : null;
	}
};
//#endregion
//#region src/games/philosophy/game-over.tsx
function Se(e) {
	return /* @__PURE__ */ d("div", {
		className: "ph-over",
		children: /* @__PURE__ */ d(g, {
			...e,
			accent: _.accent
		})
	});
}
//#endregion
//#region src/games/philosophy/guide.tsx
function Ce() {
	let e = o();
	return /* @__PURE__ */ d("div", {
		className: "grid w-full grid-cols-3 gap-1.5",
		children: v.map((t) => /* @__PURE__ */ f("div", {
			className: "frame flex flex-col items-center gap-0.5 p-1.5",
			children: [
				/* @__PURE__ */ d(X, {
					kind: t,
					rot: 0,
					color: "var(--color-ink)",
					size: 44
				}),
				/* @__PURE__ */ d("p", {
					className: "text-xs font-extrabold",
					children: e(y[t].nameKey)
				}),
				/* @__PURE__ */ d("p", {
					className: "text-center text-[10px] leading-3.5 font-bold opacity-70",
					children: e(y[t].descKey)
				})
			]
		}, t))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/philosophy/entry.tsx
var we = {
	definition: q,
	View: le,
	bot: ge,
	describe: _e,
	fx: xe,
	OverView: Se,
	Guide: Ce,
	locales: {
		zh: {
			name: "哲学",
			desc: "摆想法、推连锁,先连成三连者胜",
			rules: "目标:己方三块牌在棋盘上沿横向、纵向或对角线方向连成一条直线（结论）即获胜。\n准备:每人 12 种想法牌各 1 块;棋盘为 7 行 7 列切去四角共 37 格,中央九格是放置区。\n回合:\n· 从手牌选 1 块放进中央九格的空格,可自选朝向;游戏中的第一步不能将想法牌放在棋盘正中心。\n· 新放的牌若指向对手牌,立即激活结算。\n· 随后检查连锁:牌指向本次连锁中刚移动过的对手牌，或本次连锁中刚移动过的己方牌指向对手牌时，都必须激活;多个连锁同时出现时任选一个先结算。\n· 每块牌每回合至多激活一次。\n· 轮到自己时无处可放(手牌已空或放置区已满)直接判负。\n效果:牌面三角标指向目标格,效果全部相对朝向结算(见下图鉴);「转述」可以选择己方的想法牌。\n移动通则:落点有牌则整列同向推挤;被推出棋盘的牌回到持有者手牌,之后可再放。\n结束：己方三块牌沿横向、纵向或对角线方向连成直线时，立即获胜；即使在对方回合中因推挤而形成直线，也同样获胜。双方同时形成直线时，游戏继续。",
			tilesChip: "剩 {{n}}",
			tilesAria: "{{n}} 块未上场的牌",
			stagePlace: "轮到你:放一块想法牌",
			stageChoose: "连锁反应:选一块激活",
			waitTurn: "等 {{name}} 放牌…",
			waitChoose: "等 {{name}} 处理连锁…",
			stageWin: "三连达成,你赢了!",
			stageLose: "对方达成了结论",
			rotate: "旋转",
			placeConfirm: "放置",
			resign: "认输",
			resignArmed: "再点一次确认认输",
			chooseHint: "点高亮的牌选择要激活的连锁",
			decisionHint: "点棋盘上的圆点选择滑移方向",
			rephraseHint: "选目标牌的新朝向",
			rotAria: "朝向 {{n}}",
			watchHint: "轮到你时,这里会出现操作按钮",
			tile: {
				push: "推",
				cornerPush: "斜推",
				slideL: "左滑",
				slideR: "右滑",
				pullL: "左拉",
				pullR: "右拉",
				longShot: "远推",
				cornerLongShot: "斜远推",
				decision: "抉择",
				rephrase: "转述",
				toss: "抛跃",
				persuade: "说服"
			},
			tileDesc: {
				push: "将本牌正对的牌沿本牌朝向向前推动 1 格。",
				cornerPush: "将本牌斜对的牌沿本牌朝向的斜线推动 1 格。",
				slideL: "将本牌正对的牌向本牌朝向的左侧滑动 1 格。",
				slideR: "将本牌正对的牌向本牌朝向的右侧滑动 1 格。",
				pullL: "将本牌正对的牌拉到本牌左侧的相邻格。",
				pullR: "将本牌正对的牌拉到本牌右侧的相邻格。",
				longShot: "将本牌正前方隔 1 格的牌沿本牌朝向向前推动 1 格。",
				cornerLongShot: "将本牌斜前方隔 1 格的牌沿本牌朝向的斜线推动 1 格。",
				decision: "将本牌斜对的牌向本牌朝向的左侧或右侧滑动 1 格，方向由你选择。",
				rephrase: "将本牌斜对的一张牌拿起，旋转后放回原格；可以选择己方的牌。",
				toss: "将本牌正对的牌越过本牌，抛到本牌身后的相邻格。",
				persuade: "先将本牌后退 1 格，再将本牌原先正对的牌移入本牌原来所在的格子。"
			},
			errPhase: "现在不能这么做",
			errTurn: "还没轮到你",
			errKind: "这块牌已经上场了",
			errZone: "只能放在中央九格区域",
			errCenter: "第一手不能放正中心",
			errOccupied: "这格已经有牌了",
			errOption: "无效的选项",
			hintPlace: "放{{tile}}到第 {{y}} 行第 {{x}} 列",
			hintChoose: "激活{{tile}}",
			hintChooseLeft: "激活{{tile}},选左滑",
			hintChooseRight: "激活{{tile}},选右滑",
			hintChooseRot: "激活{{tile}},{{rot}}"
		},
		en: {
			name: "Philosophy",
			desc: "Place ideas, chain reactions, first to make 3-in-a-row wins",
			rules: "Goal: make a row of 3 of your tiles (horizontal, vertical or diagonal) — a Conclusion — to win.\nSetup: each player has 12 idea tiles, one of each kind; the board is a 7×7 cross of 37 cells, the central 3×3 is the placement zone.\nTurn:\n· Place 1 tile from your unplayed pile onto an empty cell of the central 3×3, in any orientation; the very first placement of the game may not be the dead-center cell.\n· If the new tile targets an enemy tile, it activates immediately.\n· Then check chain reactions: a tile targeting a just-moved enemy tile, or one that just moved and now targets an enemy tile, must activate; if several are available, pick one first.\n· Each tile activates at most once per turn.\n· If you cannot place (no tiles left or the zone is full), you lose.\nEffects: the triangle marks the targeted cell; all effects are relative to facing (see gallery). Rephrase may target your own tiles.\nMovement: entering an occupied cell pushes the whole line; tiles pushed off the board return to their owner's pile.\nEnd: a single Conclusion wins (even formed on the opponent's turn); if both sides conclude at once, play continues.",
			tilesChip: "{{n}} left",
			tilesAria: "{{n}} tiles not on the board",
			stagePlace: "Your turn: place an idea tile",
			stageChoose: "Chain reaction: pick one to activate",
			waitTurn: "Waiting for {{name}} to place…",
			waitChoose: "Waiting for {{name}} to resolve…",
			stageWin: "Conclusion — you win!",
			stageLose: "Your opponent reached a Conclusion",
			rotate: "Rotate",
			placeConfirm: "Place",
			resign: "Resign",
			resignArmed: "Tap again to resign",
			chooseHint: "Tap a highlighted tile to activate it",
			decisionHint: "Tap a dot on the board to pick the slide",
			rephraseHint: "Pick a new facing for the target",
			rotAria: "Facing {{n}}",
			watchHint: "Controls appear here on your turn",
			tile: {
				push: "Push",
				cornerPush: "Corner Push",
				slideL: "Slide Left",
				slideR: "Slide Right",
				pullL: "Pull Left",
				pullR: "Pull Right",
				longShot: "Long Shot",
				cornerLongShot: "Corner Long Shot",
				decision: "Decision",
				rephrase: "Rephrase",
				toss: "Toss",
				persuade: "Persuade"
			},
			tileDesc: {
				push: "Push the tile directly in front of this tile 1 cell forward in the direction this tile faces.",
				cornerPush: "Push the tile diagonally in front of this tile 1 cell farther along the diagonal this tile faces.",
				slideL: "Slide the tile directly in front of this tile 1 cell to the left, relative to this tile’s facing.",
				slideR: "Slide the tile directly in front of this tile 1 cell to the right, relative to this tile’s facing.",
				pullL: "Pull the tile directly in front of this tile into the adjacent cell on this tile’s left.",
				pullR: "Pull the tile directly in front of this tile into the adjacent cell on this tile’s right.",
				longShot: "Push the tile 2 cells directly ahead of this tile 1 cell farther forward.",
				cornerLongShot: "Push the tile 2 cells diagonally ahead of this tile 1 cell farther along that diagonal.",
				decision: "Slide the tile diagonally in front of this tile 1 cell to the left or right, relative to this tile’s facing. You choose the direction.",
				rephrase: "Pick up the tile diagonally in front of this tile, rotate it, and return it to the same cell. You may choose one of your own tiles.",
				toss: "Toss the tile directly in front of this tile over this tile into the adjacent cell behind it.",
				persuade: "Move this tile back 1 cell, then move the tile that was directly in front of it into the cell this tile just left."
			},
			errPhase: "Not allowed right now",
			errTurn: "Not your turn",
			errKind: "That tile is already on the board",
			errZone: "Only the central 3×3 cells",
			errCenter: "The first tile cannot be dead-center",
			errOccupied: "That cell is occupied",
			errOption: "Invalid option",
			hintPlace: "Place {{tile}} at row {{y}}, column {{x}}",
			hintChoose: "Activate {{tile}}",
			hintChooseLeft: "Activate {{tile}}: slide left",
			hintChooseRight: "Activate {{tile}}: slide right",
			hintChooseRot: "Activate {{tile}}: {{rot}}"
		}
	}
};
//#endregion
export { we as default };
