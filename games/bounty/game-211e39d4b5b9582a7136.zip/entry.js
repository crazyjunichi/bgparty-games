import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useT as r } from "@bgparty/sdk/i18n";
import { GameScreen as i } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as a } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as o } from "@bgparty/sdk/ui/player-strip";
import { Fragment as s, jsx as c, jsxs as l } from "react/jsx-runtime";
import { GameOverScreen as u } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/bounty/cards.ts
var d = [
	{
		id: "c01",
		bounty: 1
	},
	{
		id: "c02",
		bounty: 1
	},
	{
		id: "c03",
		bounty: 1
	},
	{
		id: "c04",
		bounty: 1
	},
	{
		id: "c05",
		bounty: 1
	},
	{
		id: "c06",
		bounty: 1
	},
	{
		id: "c07",
		bounty: 2
	},
	{
		id: "c08",
		bounty: 2
	},
	{
		id: "c09",
		bounty: 2
	},
	{
		id: "c10",
		bounty: 2
	},
	{
		id: "c11",
		bounty: 2
	},
	{
		id: "c12",
		bounty: 3
	},
	{
		id: "c13",
		bounty: 3
	},
	{
		id: "c14",
		bounty: 3
	},
	{
		id: "c15",
		bounty: 3
	},
	{
		id: "c16",
		bounty: 4
	},
	{
		id: "c17",
		bounty: 4
	},
	{
		id: "c18",
		bounty: 4
	},
	{
		id: "c19",
		bounty: 5
	},
	{
		id: "c20",
		bounty: 5
	},
	{
		id: "c21",
		bounty: 6
	},
	{
		id: "c22",
		bounty: 7
	},
	{
		id: "c23",
		bounty: 8
	}
], f = Object.fromEntries(d.map((e) => [e.id, e.bounty])), p = [
	{
		id: "captain",
		pair: "captain",
		partner: "mate",
		value: 6
	},
	{
		id: "mate",
		pair: "captain",
		partner: "captain",
		value: 6
	},
	{
		id: "cook",
		pair: "cook",
		partner: "souschef",
		value: 5
	},
	{
		id: "souschef",
		pair: "cook",
		partner: "cook",
		value: 5
	},
	{
		id: "hunter",
		pair: "hunter",
		partner: "fang",
		value: 4
	},
	{
		id: "fang",
		pair: "hunter",
		partner: "hunter",
		value: 4
	},
	{
		id: "warden",
		pair: "warden",
		partner: "guard",
		value: 3
	},
	{
		id: "guard",
		pair: "warden",
		partner: "warden",
		value: 3
	},
	{
		id: "traveler",
		pair: "traveler",
		partner: "stray",
		value: 2
	},
	{
		id: "stray",
		pair: "traveler",
		partner: "traveler",
		value: 2
	},
	{
		id: "detective",
		pair: "detective",
		partner: "thief",
		value: 1
	},
	{
		id: "thief",
		pair: "detective",
		partner: "detective",
		value: 1
	}
], m = Object.fromEntries(p.map((e) => [e.id, e])), h = (e) => e in m, g = (e) => f[e.split(":")[1]] ?? 0, _ = {
	id: "bounty",
	tier: "alpha",
	mechanics: ["hand-management", "set-collection"],
	interactionTags: [],
	nameKey: "games.bounty.name",
	descKey: "games.bounty.desc",
	rulesKey: "games.bounty.rules",
	icon: "🤠",
	iconImg: "games/bounty.webp",
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#b45309",
	releasedAt: "2026-09-28",
	search: {
		py: "wu tuo bang li de shang jin lie ren",
		init: "wtbldsjlr"
	},
	hotseat: "cover"
}, v = t.string(), y = t.string(), b = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("ban"),
		cards: t.array(y).length(2)
	}),
	t.object({
		type: t.literal("search"),
		from: t.enum(["mine", "opp"])
	}),
	t.object({
		type: t.literal("attack"),
		card: y,
		group: t.union([t.literal("new"), t.int().nonnegative()])
	}),
	t.object({
		type: t.literal("lock"),
		group: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("recruit"),
		card: y
	}),
	t.object({
		type: t.literal("dispatch"),
		cards: t.array(y).length(2)
	}),
	t.object({
		type: t.literal("exile"),
		card: y
	}),
	t.object({ type: t.literal("stop") }),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("discardPick"),
		cards: t.array(y).min(1)
	}),
	t.object({
		type: t.literal("travelerPick"),
		zone: t.enum([
			"ownDeck",
			"oppDeck",
			"oppHand",
			"market",
			"ownPrison",
			"oppPrison"
		]),
		card: y.optional()
	}),
	t.object({
		type: t.literal("wardenPick"),
		card: y
	})
]), x = t.object({
	cards: t.array(y),
	locked: t.boolean()
}), S = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("discard"),
		by: v
	}),
	t.object({
		kind: t.literal("traveler"),
		by: v
	}),
	t.object({
		kind: t.literal("warden"),
		by: v
	})
]), C = t.object({
	kind: t.literal("ban"),
	rid: v,
	cards: t.array(y)
}), w = t.object({
	kind: t.literal("unban"),
	rid: v,
	cards: t.array(y)
}), T = t.object({
	kind: t.literal("search"),
	rid: v,
	from: t.enum(["mine", "opp"])
}), E = t.object({
	kind: t.literal("attack"),
	rid: v,
	card: y,
	group: t.union([t.literal("new"), t.int().nonnegative()])
}), D = t.object({
	kind: t.literal("lock"),
	rid: v,
	group: t.int().nonnegative()
}), ee = t.object({
	kind: t.literal("recruit"),
	rid: v,
	card: y
}), O = t.object({
	kind: t.literal("dispatch"),
	rid: v,
	pair: t.string(),
	cards: t.array(y)
}), k = t.object({
	kind: t.literal("exile"),
	rid: v,
	card: y
}), A = t.object({
	kind: t.literal("hunter"),
	rid: v,
	toPrison: t.array(y),
	toHand: t.int().nonnegative()
}), j = t.object({
	kind: t.literal("warden"),
	rid: v,
	card: y
}), M = t.object({
	kind: t.literal("traveler"),
	rid: v,
	zone: t.string(),
	card: y.nullable()
}), N = t.object({
	kind: t.literal("detective"),
	rid: v,
	count: t.int().nonnegative()
}), te = t.object({
	kind: t.literal("discard"),
	rid: v,
	cards: t.array(y)
}), ne = t.object({
	kind: t.literal("skip"),
	rid: v
}), re = t.object({
	kind: t.literal("pass"),
	rid: v
}), ie = t.object({
	kind: t.literal("stop"),
	rid: v
}), ae = t.object({
	prison: t.int(),
	helper: t.int(),
	token: t.int(),
	total: t.int()
}), oe = t.object({
	kind: t.literal("settle"),
	reason: t.enum(["stop", "stall"]),
	scores: t.record(v, ae),
	winner: t.array(v)
}), P = t.discriminatedUnion("kind", [
	C,
	w,
	T,
	E,
	D,
	ee,
	O,
	k,
	A,
	j,
	M,
	N,
	te,
	ne,
	re,
	ie,
	oe
]), F = t.object({
	phase: t.enum([
		"ban",
		"play",
		"done"
	]),
	turn: v,
	actionsLeft: t.int().nonnegative(),
	market: t.array(t.object({
		id: t.string(),
		banned: t.boolean()
	})),
	tokenSupply: t.int().nonnegative(),
	players: t.array(t.object({
		rid: v,
		deckCount: t.int().nonnegative(),
		handCount: t.int().nonnegative(),
		tokens: t.int().nonnegative(),
		prison: t.array(x),
		prisonSum: t.int().nonnegative(),
		canStop: t.boolean()
	})),
	pending: S.nullable(),
	stopBy: v.nullable(),
	last: P.nullable(),
	log: t.array(P)
}), se = t.object({ hand: t.array(y) }), I = (e, t) => e.players.find((e) => e !== t);
function L(t, n) {
	for (let r = n.length - 1; r > 0; --r) {
		let i = e(t.seed, t.rngCursor, r + 1);
		t.rngCursor += 1, [n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
var R = (e, t) => e.hands[t].filter(h).length, ce = (e, t) => R(e, t) >= 4 ? 8 : 7, z = (e, t) => e.hands[t].length > ce(e, t) || R(e, t) > 4, B = (e) => e.reduce((e, t) => e + t.cards.reduce((e, t) => e + g(t), 0), 0), V = (e, t) => e.decks[t].length === 0 && !e.hands[t].some((e) => !h(e));
function H(e, t) {
	e.last = t, e.log = [...e.log, t];
}
function U(e, t, n) {
	for (let r of e) {
		if (r.locked && !n) continue;
		let e = r.cards.indexOf(t);
		if (!(e < 0)) return r.cards.splice(e, 1), !0;
	}
	return !1;
}
var W = (e) => e.filter((e) => e.cards.length > 0);
function G(e, t) {
	let n = e.hands[t];
	if (e.decks[t].length > 0 || e.decks[I(e, t)].length > 0) return !0;
	if (n.some((e) => !h(e))) return n.some((e) => !h(e) && n.length > g(e)), !0;
	if (e.tokenSupply > 0 && e.prisons[t].some((e) => !e.locked && e.cards.reduce((e, t) => e + g(t), 0) >= 10) || e.market.some((t) => !e.banned.includes(t) && (m[t].pair !== "captain" || e.actionsLeft >= 2))) return !0;
	let r = n.filter(h);
	return !!r.some((e) => r.includes(m[e].partner));
}
function le(e, t) {
	let n = +!!e.cookBonus[t];
	e.cookBonus[t] = !1, e.actionsLeft = 2 + n, e.turnFlags = {
		cookRecruit: !1,
		cookDispatch: !1
	};
}
function ue(e) {
	let t = I(e, e.turn);
	for (;;) {
		if (e.needUnban && t !== e.first && (e.needUnban = !1, H(e, {
			kind: "unban",
			rid: t,
			cards: [...e.banned]
		}), e.banned = []), e.skipNext[t]) {
			e.skipNext[t] = !1, H(e, {
				kind: "skip",
				rid: t
			}), t = I(e, t);
			continue;
		}
		break;
	}
	if (e.turn = t, le(e, t), G(e, t)) {
		e.stallPasses = 0;
		return;
	}
	if (H(e, {
		kind: "pass",
		rid: t
	}), e.stallPasses += 1, e.stallPasses >= e.players.length) {
		J(e, "stall");
		return;
	}
	K(e);
}
function de(e) {
	let t = e.turn;
	for (; e.hands[t].length < 5 && e.decks[t].length > 0;) e.hands[t].push(e.decks[t].pop());
	ue(e);
}
function K(e) {
	if (z(e, e.turn)) {
		e.pending = {
			kind: "discard",
			by: e.turn
		};
		return;
	}
	de(e);
}
function q(e) {
	e.pending || e.actionsLeft > 0 && G(e, e.turn) || K(e);
}
function J(e, t) {
	let n = {};
	for (let t of e.players) {
		let r = B(e.prisons[t]), i = e.hands[t].filter(h).reduce((e, t) => e + m[t].value, 0), a = e.tokens[t];
		n[t] = {
			prison: r,
			helper: i,
			token: a,
			total: r + i + a
		};
	}
	let [r, i] = e.players, a = (t) => e.prisons[t].reduce((e, t) => e + t.cards.length, 0), o = [];
	n[r].total === n[i].total ? n[r].token === n[i].token ? a(r) !== a(i) && (o = [a(r) < a(i) ? r : i]) : o = [n[r].token > n[i].token ? r : i] : o = [n[r].total > n[i].total ? r : i], e.scores = n, e.winner = o, e.phase = "done", e.pending = null, H(e, {
		kind: "settle",
		reason: t,
		scores: n,
		winner: o
	});
}
function fe(t, n, r) {
	let i = {
		players: n,
		first: n[0],
		phase: "ban",
		turn: n[1],
		actionsLeft: 0,
		decks: {},
		hands: {},
		prisons: {},
		tokens: {},
		tokenSupply: 15,
		market: p.map((e) => e.id),
		banned: [],
		needUnban: !0,
		skipNext: {},
		cookBonus: {},
		turnFlags: {
			cookRecruit: !1,
			cookDispatch: !1
		},
		stallPasses: 0,
		pending: null,
		stopBy: null,
		scores: null,
		winner: [],
		last: null,
		log: [],
		seed: r,
		rngCursor: 0
	};
	return n.forEach((e, t) => {
		i.decks[e] = L(i, d.map((e) => `${t}:${e.id}`)), i.hands[e] = i.decks[e].splice(-5), i.prisons[e] = [], i.tokens[e] = 0, i.skipNext[e] = !1, i.cookBonus[e] = !1;
	}), i.first = n[e(r, i.rngCursor++, n.length)], i.turn = I(i, i.first), { state: i };
}
var Y = (e) => ({ code: e });
function pe(t, n, r) {
	if (t.phase === "done") return Y("games.bounty.errNotYourTurn");
	let i = structuredClone(t), a = r.by, o = I(i, a);
	if (i.phase === "ban") {
		if (a !== i.turn) return Y("games.bounty.errNotYourTurn");
		if (n.type !== "ban") return Y("games.bounty.errBanFirst");
		let [e, t] = n.cards;
		return e === t || !i.market.includes(e) || !i.market.includes(t) ? Y("games.bounty.errBadCard") : (i.banned = [...n.cards], H(i, {
			kind: "ban",
			rid: a,
			cards: [...n.cards]
		}), i.phase = "play", i.turn = i.first, le(i, i.first), { state: i });
	}
	if (n.type === "stop") return i.pending ? Y("games.bounty.errPending") : V(i, a) ? (i.stopBy = a, H(i, {
		kind: "stop",
		rid: a
	}), J(i, "stop"), { state: i }) : Y("games.bounty.errStop");
	if (i.pending) {
		if (a !== i.pending.by) return Y("games.bounty.errNotYourTurn");
		let t = i.pending;
		if (t.kind === "discard") {
			if (n.type !== "discardPick") return Y("games.bounty.errPending");
			let e = [...i.hands[a]];
			for (let t of n.cards) {
				let n = e.indexOf(t);
				if (n < 0) return Y("games.bounty.errBadCard");
				e.splice(n, 1);
			}
			return i.hands[a] = e, z(i, a) ? Y("games.bounty.errDiscard") : (H(i, {
				kind: "discard",
				rid: a,
				cards: [...n.cards]
			}), i.pending = null, de(i), { state: i });
		}
		if (t.kind === "traveler") {
			if (n.type !== "travelerPick") return Y("games.bounty.errPending");
			let t = i.hands[a], r = null, s = !0;
			switch (n.zone) {
				case "ownDeck":
					if (i.decks[a].length === 0) return Y("games.bounty.errBadZone");
					r = i.decks[a].pop(), s = !1;
					break;
				case "oppDeck":
					if (i.decks[o].length === 0) return Y("games.bounty.errBadZone");
					r = i.decks[o].pop(), s = !1;
					break;
				case "oppHand": {
					if (i.hands[o].length === 0) return Y("games.bounty.errBadZone");
					let t = e(i.seed, i.rngCursor++, i.hands[o].length);
					r = i.hands[o].splice(t, 1)[0], s = !1;
					break;
				}
				case "market": {
					let e = n.card;
					if (!e || !i.market.includes(e) || i.banned.includes(e)) return Y("games.bounty.errBadZone");
					i.market = i.market.filter((t) => t !== e), r = e;
					break;
				}
				case "ownPrison": {
					let e = n.card;
					if (!e || !U(i.prisons[a], e, !0)) return Y("games.bounty.errBadZone");
					i.prisons[a] = W(i.prisons[a]), r = e;
					break;
				}
				case "oppPrison": {
					let t = i.prisons[o].filter((e) => !e.locked).flatMap((e) => e.cards);
					if (t.length === 0) return Y("games.bounty.errBadZone");
					r = t[e(i.seed, i.rngCursor++, t.length)], U(i.prisons[o], r, !1), i.prisons[o] = W(i.prisons[o]), s = !1;
					break;
				}
			}
			return t.push(r), H(i, {
				kind: "traveler",
				rid: a,
				zone: n.zone,
				card: s ? r : null
			}), (t.length >= 5 || !he(i, a)) && (i.pending = null, q(i)), { state: i };
		}
		return n.type === "wardenPick" ? U(i.prisons[o], n.card, !1) ? (i.prisons[o] = W(i.prisons[o]), i.prisons[a] = [...i.prisons[a], {
			cards: [n.card],
			locked: !1
		}], H(i, {
			kind: "warden",
			rid: a,
			card: n.card
		}), i.pending = null, q(i), { state: i }) : Y("games.bounty.errBadCard") : Y("games.bounty.errPending");
	}
	if (a !== i.turn || i.actionsLeft <= 0) return Y("games.bounty.errNotYourTurn");
	switch (n.type) {
		case "search": {
			let e = n.from === "mine" ? i.decks[a] : i.decks[o];
			return e.length === 0 ? Y("games.bounty.errDeckEmpty") : (i.hands[a].push(e.pop()), H(i, {
				kind: "search",
				rid: a,
				from: n.from
			}), --i.actionsLeft, i.stallPasses = 0, q(i), { state: i });
		}
		case "attack": {
			let e = i.hands[a].indexOf(n.card);
			if (e < 0 || h(n.card)) return Y("games.bounty.errBadCard");
			if (i.hands[a].length <= g(n.card)) return Y("games.bounty.errAttackWeak");
			if (i.hands[a].splice(e, 1), n.group === "new") i.prisons[a] = [...i.prisons[a], {
				cards: [n.card],
				locked: !1
			}];
			else {
				let e = i.prisons[a][n.group];
				if (!e || e.locked) return Y("games.bounty.errBadGroup");
				e.cards.push(n.card);
			}
			return H(i, {
				kind: "attack",
				rid: a,
				card: n.card,
				group: n.group
			}), --i.actionsLeft, i.stallPasses = 0, q(i), { state: i };
		}
		case "lock": {
			let e = i.prisons[a][n.group];
			return !e || e.locked || e.cards.reduce((e, t) => e + g(t), 0) < 10 ? Y("games.bounty.errLock") : i.tokenSupply <= 0 ? Y("games.bounty.errNoToken") : (e.locked = !0, --i.tokenSupply, i.tokens[a] += 1, H(i, {
				kind: "lock",
				rid: a,
				group: n.group
			}), --i.actionsLeft, i.stallPasses = 0, q(i), { state: i });
		}
		case "recruit":
			if (!i.market.includes(n.card) || i.banned.includes(n.card)) return Y("games.bounty.errBadCard");
			if (m[n.card].pair === "captain") {
				if (i.actionsLeft < 2) return Y("games.bounty.errCaptain");
				i.actionsLeft = 0;
			} else --i.actionsLeft;
			return i.market = i.market.filter((e) => e !== n.card), i.hands[a].push(n.card), m[n.card].pair === "cook" && (i.turnFlags.cookRecruit = !0), me(i, a), H(i, {
				kind: "recruit",
				rid: a,
				card: n.card
			}), i.stallPasses = 0, q(i), { state: i };
		case "dispatch": {
			let [t, r] = n.cards;
			if (t === r || !h(t) || !h(r) || !i.hands[a].includes(t) || !i.hands[a].includes(r)) return Y("games.bounty.errBadCard");
			if (m[t].partner !== r) return Y("games.bounty.errNeedPair");
			let s = m[t].pair;
			switch (i.hands[a] = i.hands[a].filter((e) => e !== t && e !== r), H(i, {
				kind: "dispatch",
				rid: a,
				pair: s,
				cards: [t, r]
			}), --i.actionsLeft, i.stallPasses = 0, s) {
				case "captain":
					i.skipNext[o] = !0;
					break;
				case "cook":
					i.turnFlags.cookDispatch = !0, me(i, a);
					break;
				case "hunter": {
					let e = [], t = 0;
					for (let n = 0; n < 3 && i.decks[a].length > 0; n += 1) {
						let n = i.decks[a].pop();
						g(n) >= 7 ? (i.hands[a].push(n), t += 1) : e.push(n);
					}
					e.length > 0 && (i.prisons[a] = [...i.prisons[a], {
						cards: e,
						locked: !1
					}]), H(i, {
						kind: "hunter",
						rid: a,
						toPrison: e,
						toHand: t
					});
					break;
				}
				case "warden":
					i.prisons[o].some((e) => !e.locked && e.cards.length > 0) && (i.pending = {
						kind: "warden",
						by: a
					});
					break;
				case "traveler":
					i.hands[a].length < 5 && he(i, a) && (i.pending = {
						kind: "traveler",
						by: a
					});
					break;
				case "detective": {
					let t = Math.min(3, i.hands[o].length);
					for (let n = 0; n < t; n += 1) {
						let t = e(i.seed, i.rngCursor++, i.hands[o].length);
						i.hands[a].push(i.hands[o].splice(t, 1)[0]);
					}
					H(i, {
						kind: "detective",
						rid: a,
						count: t
					});
					break;
				}
			}
			return q(i), { state: i };
		}
		case "exile": {
			let e = i.hands[a].indexOf(n.card);
			return e < 0 || h(n.card) ? Y("games.bounty.errBadCard") : (i.hands[a].splice(e, 1), i.decks[o].push(n.card), H(i, {
				kind: "exile",
				rid: a,
				card: n.card
			}), --i.actionsLeft, i.stallPasses = 0, q(i), { state: i });
		}
		case "endTurn": return i.actionsLeft = 0, i.stallPasses = 0, K(i), { state: i };
		default: return Y("games.bounty.errPending");
	}
}
function me(e, t) {
	e.turnFlags.cookRecruit && e.turnFlags.cookDispatch && (e.cookBonus[t] = !0);
}
function he(e, t) {
	let n = I(e, t);
	return e.decks[t].length > 0 || e.decks[n].length > 0 || e.hands[n].length > 0 || e.market.some((t) => !e.banned.includes(t)) || e.prisons[t].some((e) => e.cards.length > 0) || e.prisons[n].some((e) => !e.locked && e.cards.length > 0);
}
function ge(e, t) {
	return {
		public: {
			phase: e.phase,
			turn: e.turn,
			actionsLeft: e.actionsLeft,
			market: e.market.map((t) => ({
				id: t,
				banned: e.banned.includes(t)
			})),
			tokenSupply: e.tokenSupply,
			players: e.players.map((t) => ({
				rid: t,
				deckCount: e.decks[t].length,
				handCount: e.hands[t].length,
				tokens: e.tokens[t],
				prison: e.prisons[t],
				prisonSum: B(e.prisons[t]),
				canStop: e.phase === "play" && V(e, t)
			})),
			pending: e.pending,
			stopBy: e.stopBy,
			last: e.last,
			log: e.log
		},
		private: { hand: e.hands[t] ?? [] }
	};
}
function _e(e) {
	if (e.phase !== "done" || !e.scores) return { phase: e.phase };
	let t = (t) => e.scores[t].total, n = [...e.players].sort((e, n) => t(n) - t(e));
	return {
		phase: "done",
		winner: e.winner,
		ranking: n,
		scores: Object.fromEntries(e.players.map((e) => [e, t(e)]))
	};
}
var ve = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: _,
	schemas: {
		action: b,
		publicView: F,
		privateView: se
	},
	setup: fe,
	reduce: pe,
	viewFor: ge,
	status: _e
}, ye = {
	captain: {
		bg: "#e0f2fe",
		fg: "#0369a1",
		icon: "⚓"
	},
	cook: {
		bg: "#fee2e2",
		fg: "#b91c1c",
		icon: "🍳"
	},
	hunter: {
		bg: "#dcfce7",
		fg: "#15803d",
		icon: "🎯"
	},
	warden: {
		bg: "#ede9fe",
		fg: "#6d28d9",
		icon: "🔑"
	},
	traveler: {
		bg: "#cffafe",
		fg: "#0e7490",
		icon: "🧭"
	},
	detective: {
		bg: "#fce7f3",
		fg: "#be185d",
		icon: "🔍"
	}
}, X = {
	c01: "games.bounty.crim.c01",
	c02: "games.bounty.crim.c02",
	c03: "games.bounty.crim.c03",
	c04: "games.bounty.crim.c04",
	c05: "games.bounty.crim.c05",
	c06: "games.bounty.crim.c06",
	c07: "games.bounty.crim.c07",
	c08: "games.bounty.crim.c08",
	c09: "games.bounty.crim.c09",
	c10: "games.bounty.crim.c10",
	c11: "games.bounty.crim.c11",
	c12: "games.bounty.crim.c12",
	c13: "games.bounty.crim.c13",
	c14: "games.bounty.crim.c14",
	c15: "games.bounty.crim.c15",
	c16: "games.bounty.crim.c16",
	c17: "games.bounty.crim.c17",
	c18: "games.bounty.crim.c18",
	c19: "games.bounty.crim.c19",
	c20: "games.bounty.crim.c20",
	c21: "games.bounty.crim.c21",
	c22: "games.bounty.crim.c22",
	c23: "games.bounty.crim.c23"
}, Z = {
	captain: "games.bounty.helper.captain",
	mate: "games.bounty.helper.mate",
	cook: "games.bounty.helper.cook",
	souschef: "games.bounty.helper.souschef",
	hunter: "games.bounty.helper.hunter",
	fang: "games.bounty.helper.fang",
	warden: "games.bounty.helper.warden",
	guard: "games.bounty.helper.guard",
	traveler: "games.bounty.helper.traveler",
	stray: "games.bounty.helper.stray",
	detective: "games.bounty.helper.detective",
	thief: "games.bounty.helper.thief"
}, be = {
	captain: "games.bounty.pairEffect.captain",
	cook: "games.bounty.pairEffect.cook",
	hunter: "games.bounty.pairEffect.hunter",
	warden: "games.bounty.pairEffect.warden",
	traveler: "games.bounty.pairEffect.traveler",
	detective: "games.bounty.pairEffect.detective"
}, xe = (e) => e.includes("·") ? e.split("·").pop() : e.split(",")[0];
function Q({ id: e, size: t, dim: n }) {
	let i = r(), a = e.split(":")[1];
	return /* @__PURE__ */ l("span", {
		className: `bounty-card bounty-card--${t} inline-flex flex-none flex-col items-center justify-between rounded border-2 border-ink bg-amber-50 px-0.5 py-1 ${n ? "opacity-40" : ""}`,
		children: [
			/* @__PURE__ */ c("span", {
				className: "bounty-wanted font-display font-extrabold tracking-widest text-ink/50",
				children: "WANTED"
			}),
			/* @__PURE__ */ l("span", {
				className: "bounty-bounty font-mono font-extrabold tabular-nums",
				style: { color: _.accent },
				children: ["$", g(e)]
			}),
			/* @__PURE__ */ c("span", {
				className: "bounty-card-name w-full truncate text-center font-bold text-ink/80",
				children: xe(i(X[a]))
			})
		]
	});
}
function Se({ id: e, size: t, dim: n }) {
	let i = r(), a = m[e], o = ye[a.pair];
	return /* @__PURE__ */ l("span", {
		className: `bounty-card bounty-card--${t} relative inline-flex flex-none flex-col items-center justify-between rounded border-2 border-ink px-0.5 py-1 ${n ? "opacity-40" : ""}`,
		style: { background: o.bg },
		children: [
			/* @__PURE__ */ c("span", {
				className: "bounty-helper-symbol",
				"aria-hidden": !0,
				children: o.icon
			}),
			/* @__PURE__ */ c("span", {
				className: "bounty-card-name w-full truncate text-center font-bold",
				style: { color: o.fg },
				children: xe(i(Z[e]))
			}),
			/* @__PURE__ */ c("span", {
				className: "bounty-helper-value absolute -bottom-1 -left-1 grid place-items-center rounded-full border-2 border-ink bg-surface font-mono font-extrabold tabular-nums",
				style: { color: o.fg },
				children: a.value
			})
		]
	});
}
function Ce() {
	return /* @__PURE__ */ c("span", {
		className: "bounty-card bounty-card--market grid flex-none place-items-center rounded border-2 border-ink",
		style: { background: `repeating-linear-gradient(45deg, ${_.accent} 0 6px, #7c3f0c 6px 12px)` },
		"aria-hidden": !0,
		children: /* @__PURE__ */ c("span", {
			className: "bounty-banned-symbol text-surface",
			children: "★"
		})
	});
}
function we({ count: e, label: t, disabled: n, onPick: r }) {
	return /* @__PURE__ */ l("button", {
		type: "button",
		"aria-label": t,
		disabled: n || e === 0,
		onClick: r,
		className: "bounty-deck relative flex-none transition-transform active:translate-y-0.5 disabled:cursor-default",
		children: [/* @__PURE__ */ c("span", {
			className: "bounty-deck-back grid place-items-center rounded border-2 border-ink bg-ink font-display font-extrabold text-surface",
			style: { boxShadow: "2px 2px 0 var(--color-ink)" },
			"aria-hidden": !0,
			children: "🤠"
		}), /* @__PURE__ */ c("span", {
			className: "bounty-deck-count absolute -top-1.5 -right-1.5 grid place-items-center rounded-full border-2 border-ink bg-surface font-mono font-extrabold tabular-nums",
			children: e
		})]
	});
}
function Te(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ c(Ee, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var $ = {
	hand: [],
	market: null,
	lockGroup: null,
	stopAsk: !1,
	pickZone: null
};
function Ee({ pub: e, priv: t, members: s, myRid: u, send: d }) {
	let f = r(), p = (e) => s.find((t) => t.rid === e)?.name ?? e, v = e.players.find((e) => e.rid === u), y = e.players.find((e) => e.rid !== u), b = t?.hand ?? [], x = e.phase === "play" && e.turn === u && !e.pending, S = e.pending && e.pending.by === u ? e.pending : null, [C, w] = n($), [T, E] = n([]), D = `${e.phase}|${e.turn}|${e.actionsLeft}|${e.pending?.kind ?? ""}|${b.join(".")}|${e.market.map((e) => e.id + (e.banned ? "!" : "")).join(".")}`, [ee, O] = n(D);
	ee !== D && (O(D), w($), E([]));
	let k = C.hand.map((e) => b[e]).filter(Boolean), A = k.filter((e) => !h(e)), j = k.filter(h), M = null;
	if (x) {
		if (C.stopAsk) M = { kind: "stop" };
		else if (C.lockGroup !== null && C.hand.length === 0) {
			let t = v?.prison[C.lockGroup], n = t ? t.cards.reduce((e, t) => e + g(t), 0) : 0;
			M = {
				kind: "lock",
				group: C.lockGroup,
				ok: !!t && !t.locked && n >= 10 && e.tokenSupply > 0
			};
		} else if (C.market) {
			let t = e.market.find((e) => e.id === C.market), n = m[C.market].pair === "captain" && e.actionsLeft < 2;
			M = {
				kind: "recruit",
				id: C.market,
				ok: !!t && !t.banned && !n
			};
		} else A.length === 1 && j.length === 0 ? M = {
			kind: "attack",
			ok: b.length > g(A[0])
		} : j.length === 2 && A.length === 0 ? m[j[0]].partner === j[1] && (M = { kind: "dispatch" }) : j.length === 1 && A.length === 0 && (M = {
			kind: "helperInfo",
			id: j[0]
		});
	}
	let N = (e) => {
		(x || S?.kind === "discard") && w((t) => ({
			...t,
			market: null,
			lockGroup: null,
			stopAsk: !1,
			hand: t.hand.includes(e) ? t.hand.filter((t) => t !== e) : [...t.hand, e]
		}));
	}, te = (t) => {
		if (S?.kind === "traveler" && C.pickZone === "market") {
			d({
				type: "travelerPick",
				zone: "market",
				card: t
			}), w($);
			return;
		}
		if (e.phase === "ban" && e.turn === u) {
			let n = e.market.find((e) => e.id === t);
			if (!n || n.banned) return;
			E((e) => e.includes(t) ? e.filter((e) => e !== t) : e.length >= 2 ? e : [...e, t]);
			return;
		}
		x && w((e) => ({
			...$,
			market: e.market === t ? null : t
		}));
	}, ne = (e) => {
		if ((S?.kind !== "traveler" || C.pickZone !== "ownPrison") && x) {
			if (A.length === 1 && j.length === 0 && b.length > g(A[0])) {
				d({
					type: "attack",
					card: A[0],
					group: e
				}), w($);
				return;
			}
			C.hand.length === 0 && w((t) => ({
				...$,
				lockGroup: t.lockGroup === e ? null : e
			}));
		}
	}, re = (e) => {
		S?.kind === "traveler" && C.pickZone === "ownPrison" && (d({
			type: "travelerPick",
			zone: "ownPrison",
			card: e
		}), w($));
	}, ie = (e) => {
		S?.kind === "warden" && (d({
			type: "wardenPick",
			card: e
		}), w($));
	}, ae = (e) => {
		if (e === "market" || e === "ownPrison") {
			w((t) => ({
				...$,
				pickZone: t.pickZone === e ? null : e
			}));
			return;
		}
		d({
			type: "travelerPick",
			zone: e
		}), w($);
	}, oe = () => {
		M && (M.kind === "attack" && M.ok ? d({
			type: "attack",
			card: A[0],
			group: "new"
		}) : M.kind === "dispatch" ? d({
			type: "dispatch",
			cards: [j[0], j[1]]
		}) : M.kind === "recruit" && M.ok ? d({
			type: "recruit",
			card: M.id
		}) : M.kind === "lock" && M.ok ? d({
			type: "lock",
			group: M.group
		}) : M.kind === "stop" && d({ type: "stop" }), w($));
	}, P = "info", F = "";
	e.phase === "ban" ? (P = e.turn === u ? "accent" : "info", F = e.turn === u ? f("games.bounty.banYou") : f("games.bounty.banWait", { name: p(e.turn) })) : e.pending ? (P = e.pending.by === u ? "accent" : "info", F = e.pending.kind === "discard" ? f("games.bounty.discardTitle") : e.pending.kind === "traveler" ? f("games.bounty.travelerTitle") : f("games.bounty.wardenTitle"), e.pending.by !== u && (F = f("games.bounty.turnWait", { name: p(e.pending.by) }))) : x ? (P = "accent", F = f("games.bounty.turnYou", { n: e.actionsLeft })) : e.phase === "play" && (F = f("games.bounty.turnWait", { name: p(e.turn) }));
	let se = /* @__PURE__ */ l("div", {
		className: "bounty-top",
		children: [/* @__PURE__ */ c(a, {
			tone: P,
			text: F,
			accent: _.accent
		}), /* @__PURE__ */ c(o, {
			variant: "plate",
			members: s,
			myRid: u,
			action: (t) => e.phase !== "done" && t === e.turn ? "pending" : null,
			status: (t) => {
				let n = e.players.find((e) => e.rid === t);
				if (!n) return null;
				let r = (e, t, n) => /* @__PURE__ */ l("span", {
					className: "flex items-center gap-px",
					children: [/* @__PURE__ */ c("span", {
						"aria-hidden": !0,
						className: "bounty-stat-icon text-[10px]",
						children: e
					}), t]
				}, n);
				return /* @__PURE__ */ l("span", {
					className: "bounty-player-stats flex w-full flex-nowrap items-center justify-between gap-0.5 font-mono text-sm leading-4.5 font-extrabold tabular-nums whitespace-nowrap",
					children: [
						r("🃏", n.handCount, "h"),
						r("🂠", n.deckCount, "d"),
						r("🪙", n.tokens, "t"),
						r("⛓️", n.prisonSum, "p")
					]
				});
			}
		})]
	}), I = /* @__PURE__ */ l("div", {
		className: `bounty-table flex min-h-full flex-col gap-2 p-2${e.phase === "ban" && e.turn === u || S || M ? " bounty-table--confirming" : ""}${S?.kind === "traveler" ? " bounty-table--traveler" : ""}`,
		children: [
			y && /* @__PURE__ */ c(De, {
				label: f("games.bounty.oppPrison"),
				groups: y.prison,
				side: "opponent",
				pickable: S?.kind === "warden",
				onPickCard: ie
			}),
			/* @__PURE__ */ l("div", {
				className: "bounty-market frame flex flex-col gap-1.5 p-2",
				children: [
					/* @__PURE__ */ c("span", {
						className: "section-label",
						children: f("games.bounty.marketLabel")
					}),
					/* @__PURE__ */ c("div", {
						className: "bounty-market-cards flex flex-wrap items-center gap-1",
						children: e.market.map((t) => {
							let n = T.includes(t.id) || C.market === t.id || S?.kind === "traveler" && C.pickZone === "market" && !t.banned;
							if (t.banned) return /* @__PURE__ */ l("span", {
								className: "relative inline-flex",
								children: [/* @__PURE__ */ c(Ce, {}), /* @__PURE__ */ c("span", {
									className: "bounty-banned-label absolute inset-x-0 bottom-0.5 text-center text-[8px] font-extrabold text-surface",
									children: f("games.bounty.bannedMark")
								})]
							}, t.id);
							let r = e.phase === "ban" && e.turn === u || x || S?.kind === "traveler" && C.pickZone === "market";
							return /* @__PURE__ */ c("button", {
								type: "button",
								"aria-label": f(Z[t.id]),
								disabled: !r,
								onClick: () => te(t.id),
								className: `relative inline-flex flex-none rounded outline-2 outline-offset-1 transition-transform active:translate-y-0.5 disabled:cursor-default ${n ? "-translate-y-0.5 shadow-[2px_2px_0_var(--color-ink)] outline-solid" : "outline-transparent"}`,
								style: { outlineColor: _.accent },
								children: /* @__PURE__ */ c(Se, {
									id: t.id,
									size: "market"
								})
							}, t.id);
						})
					}),
					/* @__PURE__ */ l("div", {
						className: "bounty-decks flex items-center gap-3 pt-1",
						children: [
							v && /* @__PURE__ */ c(we, {
								count: v.deckCount,
								label: f("games.bounty.deckAria", { n: v.deckCount }),
								disabled: !x,
								onPick: () => d({
									type: "search",
									from: "mine"
								})
							}),
							y && /* @__PURE__ */ c(we, {
								count: y.deckCount,
								label: f("games.bounty.deckAria", { n: y.deckCount }),
								disabled: !x,
								onPick: () => d({
									type: "search",
									from: "opp"
								})
							}),
							/* @__PURE__ */ l("span", {
								className: "bounty-search-label text-[10px] font-bold text-ink/50",
								children: [
									f("games.bounty.searchMine"),
									" / ",
									f("games.bounty.searchOpp")
								]
							})
						]
					})
				]
			}),
			v && /* @__PURE__ */ c(De, {
				label: f("games.bounty.myPrison"),
				groups: v.prison,
				side: "own",
				onPickGroup: ne,
				onPickCard: re,
				highlightGroups: x && A.length === 1 && j.length === 0 && b.length > g(A[0]),
				pickCards: S?.kind === "traveler" && C.pickZone === "ownPrison",
				lockGroup: C.lockGroup
			})
		]
	}), L = /* @__PURE__ */ l("div", {
		className: "bounty-overlay pointer-events-none flex flex-col gap-1.5 p-2",
		children: [
			e.phase === "ban" && e.turn === u && /* @__PURE__ */ l("div", {
				className: "bounty-confirm pointer-events-auto flex min-h-12 items-center gap-2 plate px-3 py-1.5",
				children: [
					/* @__PURE__ */ c("span", {
						className: "min-w-0 flex-1 truncate text-sm font-extrabold",
						children: f("games.bounty.banYou")
					}),
					/* @__PURE__ */ c("button", {
						type: "button",
						className: "btn-quiet min-h-11 px-3 text-sm",
						onClick: () => E([]),
						children: f("games.bounty.cancel")
					}),
					/* @__PURE__ */ c("button", {
						type: "button",
						disabled: T.length !== 2,
						className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
						style: { background: _.accent },
						onClick: () => {
							d({
								type: "ban",
								cards: [T[0], T[1]]
							}), E([]);
						},
						children: f("games.bounty.banConfirm", { n: T.length })
					})
				]
			}),
			S?.kind === "traveler" && /* @__PURE__ */ l("div", {
				className: "pointer-events-auto plate flex flex-col gap-1.5 px-3 py-2",
				children: [/* @__PURE__ */ c("span", {
					className: "text-sm font-extrabold",
					children: f("games.bounty.travelerTitle")
				}), /* @__PURE__ */ c("div", {
					className: "flex flex-wrap gap-1",
					children: [
						[
							"ownDeck",
							(v?.deckCount ?? 0) > 0,
							"games.bounty.zoneOwnDeck"
						],
						[
							"oppDeck",
							(y?.deckCount ?? 0) > 0,
							"games.bounty.zoneOppDeck"
						],
						[
							"oppHand",
							(y?.handCount ?? 0) > 0,
							"games.bounty.zoneOppHand"
						],
						[
							"market",
							e.market.some((e) => !e.banned),
							"games.bounty.zoneMarket"
						],
						[
							"ownPrison",
							(v?.prison ?? []).some((e) => e.cards.length > 0),
							"games.bounty.zoneOwnPrison"
						],
						[
							"oppPrison",
							(y?.prison ?? []).some((e) => !e.locked && e.cards.length > 0),
							"games.bounty.zoneOppPrison"
						]
					].map(([e, t, n]) => /* @__PURE__ */ c("button", {
						type: "button",
						disabled: !t,
						onClick: () => ae(e),
						className: `btn-quiet min-h-11 px-3 text-xs disabled:opacity-40 ${C.pickZone === e ? "shadow-[2px_2px_0_var(--color-ink)]" : ""}`,
						style: C.pickZone === e ? {
							background: _.accent,
							color: "#fff"
						} : void 0,
						children: f(n)
					}, e))
				})]
			}),
			S?.kind === "warden" && /* @__PURE__ */ c("div", {
				className: "pointer-events-auto plate px-3 py-2 text-sm font-extrabold",
				children: f("games.bounty.wardenTitle")
			}),
			S?.kind === "discard" && /* @__PURE__ */ c(Oe, {
				hand: b,
				sel: C.hand,
				onCancel: () => w($),
				onConfirm: (e) => {
					d({
						type: "discardPick",
						cards: e
					}), w($);
				}
			}),
			M && /* @__PURE__ */ l("div", {
				className: "bounty-confirm pointer-events-auto flex min-h-12 items-center gap-2 plate px-3 py-1.5",
				children: [
					/* @__PURE__ */ l("span", {
						className: "min-w-0 flex-1 truncate text-sm font-extrabold",
						children: [
							M.kind === "attack" && (M.ok ? `${f("games.bounty.attack")} $${g(A[0])}` : f("games.bounty.attackNeed", {
								n: g(A[0]),
								m: b.length
							})),
							M.kind === "dispatch" && f(be[m[j[0]].pair]),
							M.kind === "helperInfo" && f(be[m[M.id].pair]),
							M.kind === "recruit" && (M.ok ? f(Z[M.id]) : f("games.bounty.recruitCaptain")),
							M.kind === "lock" && (M.ok ? f("games.bounty.lockGain") : f("games.bounty.lockNeed")),
							M.kind === "stop" && f("games.bounty.stopConfirm")
						]
					}),
					/* @__PURE__ */ c("button", {
						type: "button",
						className: "btn-quiet min-h-11 px-3 text-sm",
						onClick: () => w($),
						children: f("games.bounty.cancel")
					}),
					(M.kind === "attack" || M.kind === "dispatch" || M.kind === "recruit" || M.kind === "lock" || M.kind === "stop") && /* @__PURE__ */ c("button", {
						type: "button",
						disabled: "ok" in M && !M.ok,
						className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
						style: { background: _.accent },
						onClick: oe,
						children: M.kind === "attack" ? f("games.bounty.attackToNew") : M.kind === "dispatch" ? f("games.bounty.dispatch") : M.kind === "recruit" ? f("games.bounty.recruit") : M.kind === "lock" ? f("games.bounty.lock") : f("games.bounty.stop")
					}),
					M.kind === "attack" && M.ok && /* @__PURE__ */ c("button", {
						type: "button",
						className: "btn-base min-h-11 px-4 text-sm text-white",
						style: { background: "#57534e" },
						onClick: () => {
							d({
								type: "exile",
								card: A[0]
							}), w($);
						},
						children: f("games.bounty.exile")
					})
				]
			})
		]
	}), R = /* @__PURE__ */ l("div", {
		className: "bounty-actions flex h-full flex-col gap-1 px-2 pb-1",
		children: [/* @__PURE__ */ l("div", {
			className: "bounty-action-buttons flex flex-none items-center gap-2",
			children: [
				/* @__PURE__ */ c("button", {
					type: "button",
					className: "btn-quiet min-h-11 px-3 text-sm disabled:opacity-40",
					disabled: !v?.canStop || !!e.pending,
					onClick: () => w({
						...$,
						stopAsk: !0
					}),
					children: f("games.bounty.stop")
				}),
				/* @__PURE__ */ c("button", {
					type: "button",
					className: "btn-quiet min-h-11 px-3 text-sm disabled:opacity-40",
					disabled: !x,
					onClick: () => d({ type: "endTurn" }),
					children: f("games.bounty.endTurn")
				}),
				j.length > 0 && A.length > 0 && /* @__PURE__ */ c("span", {
					className: "text-xs font-bold text-ink/50",
					children: f("games.bounty.dispatchNeedPair")
				})
			]
		}), /* @__PURE__ */ l("div", {
			className: "bounty-hand flex min-h-0 flex-1 items-center gap-1 overflow-x-auto",
			children: [b.map((e, t) => /* @__PURE__ */ c("button", {
				type: "button",
				"aria-label": h(e) ? f(Z[e]) : f(X[e.split(":")[1]]),
				disabled: !x && S?.kind !== "discard",
				onClick: () => N(t),
				className: `flex flex-none rounded outline-2 outline-offset-1 transition-transform active:translate-y-0.5 disabled:cursor-default ${C.hand.includes(t) ? "-translate-y-1 shadow-[2px_2px_0_var(--color-ink)] outline-solid" : "outline-transparent"}`,
				style: { outlineColor: _.accent },
				children: h(e) ? /* @__PURE__ */ c(Se, {
					id: e,
					size: "hand"
				}) : /* @__PURE__ */ c(Q, {
					id: e,
					size: "hand"
				})
			}, `${e}${t}`)), b.length === 0 && /* @__PURE__ */ c("span", {
				className: "text-xs font-bold text-ink/50",
				children: f("games.bounty.emptyHand")
			})]
		})]
	});
	return /* @__PURE__ */ c(i, {
		adaptive: !0,
		className: "bounty-screen",
		banner: se,
		actions: R,
		actionsHeight: "bounty-actions-slot h-34",
		overlay: L,
		children: I
	});
}
function De({ label: e, groups: t, side: n, onPickGroup: i, onPickCard: a, highlightGroups: o, pickCards: u, pickable: d, lockGroup: f }) {
	let p = r();
	return /* @__PURE__ */ l("div", {
		className: `bounty-prison bounty-prison--${n} frame flex flex-col gap-1 p-2`,
		children: [/* @__PURE__ */ c("span", {
			className: "section-label",
			children: e
		}), /* @__PURE__ */ l("div", {
			className: "bounty-prison-groups flex flex-wrap items-end gap-2",
			children: [t.length === 0 && /* @__PURE__ */ c("span", {
				className: "text-xs font-bold text-ink/40",
				children: p("games.bounty.emptyPrison")
			}), t.map((t, n) => {
				let r = t.cards.reduce((e, t) => e + g(t), 0), m = (u || d && !t.locked) && a, h = /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("span", {
					className: `bounty-prison-cards${m ? " bounty-prison-cards--pickable" : ""}`,
					children: t.cards.map((e) => /* @__PURE__ */ c("span", {
						className: "bounty-prison-card-wrap",
						children: m ? /* @__PURE__ */ c("button", {
							type: "button",
							"aria-label": p(X[e.split(":")[1]]),
							onClick: () => a(e),
							className: "bounty-prison-card-button flex rounded transition-transform active:translate-y-0.5",
							children: /* @__PURE__ */ c(Q, {
								id: e,
								size: "prison"
							})
						}) : /* @__PURE__ */ c(Q, {
							id: e,
							size: "prison"
						})
					}, e))
				}), /* @__PURE__ */ l("span", {
					className: "bounty-group-sum mt-0.5 flex items-center gap-1 font-mono text-[10px] font-extrabold tabular-nums",
					style: { color: t.locked ? "#b91c1c" : void 0 },
					children: [t.locked && /* @__PURE__ */ c("span", {
						"aria-hidden": !0,
						children: "🔒"
					}), p("games.bounty.groupSum", { n: r })]
				})] }), v = !!i && (!t.locked || !o);
				return /* @__PURE__ */ c("span", {
					className: `bounty-prison-group inline-flex flex-col items-center rounded-lg border-2 p-1 ${f === n ? "border-solid" : o && !t.locked ? "border-dashed" : "border-transparent"}`,
					style: { borderColor: f === n || o && !t.locked ? _.accent : void 0 },
					children: v && !m ? /* @__PURE__ */ c("button", {
						type: "button",
						"aria-label": `${e} ${n + 1}`,
						onClick: () => i(n),
						className: "bounty-prison-group-button flex flex-col items-center",
						children: h
					}) : h
				}, n);
			})]
		})]
	});
}
function Oe({ hand: e, sel: t, onCancel: n, onConfirm: i }) {
	let a = r(), o = t.map((t) => e[t]).filter(Boolean), s = e.filter(h).length - o.filter(h).length, u = e.length - o.length, d = s >= 4 ? 8 : 7, f = o.length > 0 && u <= d && s <= 4;
	return /* @__PURE__ */ l("div", {
		className: "bounty-confirm pointer-events-auto flex min-h-12 items-center gap-2 plate px-3 py-1.5",
		children: [
			/* @__PURE__ */ c("span", {
				className: "min-w-0 flex-1 truncate text-sm font-extrabold",
				children: a("games.bounty.discardTitle")
			}),
			/* @__PURE__ */ c("button", {
				type: "button",
				className: "btn-quiet min-h-11 px-3 text-sm",
				onClick: n,
				children: a("games.bounty.cancel")
			}),
			/* @__PURE__ */ c("button", {
				type: "button",
				disabled: !f,
				className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
				style: { background: _.accent },
				onClick: () => i(o),
				children: a("games.bounty.discardDo", { n: o.length })
			})
		]
	});
}
//#endregion
//#region src/games/bounty/game-over.tsx
function ke({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ c("div", {
		className: "bounty-game-over",
		children: /* @__PURE__ */ c(u, {
			hintCount: e,
			result: t,
			members: n,
			myRid: r,
			accent: _.accent,
			onPlayAgain: i,
			onBackToLobby: a
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/bounty/entry.tsx
var Ae = {
	definition: ve,
	View: Te,
	OverView: ke,
	locales: {
		zh: {
			name: "乌托邦里的赏金猎人",
			desc: "双人赏金对决:搜捕通缉犯关进监狱,招募搭档帮手连击,把握时机喊停结算",
			rules: "目标:把通缉犯关进监狱攒赏金,适时喊停,总分高者胜。\n准备:各洗 23 张通缉犯牌库并抽 5 张;12 张帮手摊开成公共区。\n先后手:后手先禁用公共区 2 张帮手,到自己首个回合时自动解禁。\n流程(每回合 2 个行动,可重复选同一种):\n· 搜捕:抽自己或对方牌库顶 1 张入手。\n· 出击:将 1 张手牌中的通缉犯关进我方监狱;打出前手牌总数须大于其赏金。\n· 封锁:我方监狱某组赏金合计达到 10 时,花费 1 个行动获得 1 枚黄金令牌锁住该组。\n· 招募:从公共区获得 1 张帮手;船长搭档需消耗整回合 2 个行动。\n· 派遣:打出 1 对搭档帮手发动效果(点牌面可见效果)。\n· 驱逐:把 1 张手牌通缉犯放到对方牌库顶。\n回合结束:手牌上限 7 张,帮手至多 4 张,超出须弃置。\n集齐 4 张帮手时手牌上限增加 1 张;然后从牌库补到 5 张。\n搭档效果(派遣一对触发):\n· 船长:跳过对方下个回合;招募需消耗整回合 2 个行动。\n· 厨师:同回合内招募并派遣,下个回合增加 1 个行动。\n· 猎人:将我方牌库顶 3 张关进监狱,其中赏金为 7、8 的改为收入手牌。\n· 狱长:对方监狱 1 张通缉犯转移至我方监狱。\n· 旅人:从双方牌库、对方手牌、公共区、双方监狱逐张补牌,直到手牌达 5 张。\n· 侦探:盲抽对方 3 张手牌。\n喊停:手里和牌库都没有通缉犯时可喊停,立即结算。\n计分:监狱赏金 + 手中帮手分值 + 黄金令牌数;平手先比令牌多,再比监狱张数少。",
			turnYou: "轮到你:还剩 {{n}} 个行动",
			turnWait: "等 {{name}} 行动…",
			banYou: "你是后手:禁用 2 张帮手",
			banWait: "等 {{name}} 禁用帮手…",
			banConfirm: "禁用这 {{n}} 张帮手",
			searchMine: "搜捕我方牌库",
			searchOpp: "搜捕对方牌库",
			deckAria: "牌库还剩 {{n}} 张",
			attack: "出击",
			attackToNew: "出击·新组",
			attackNeed: "手牌总数须大于 ${{n}}(现有 {{m}} 张)",
			lock: "封锁",
			lockGain: "封锁此组并拿 1 枚黄金令牌",
			lockNeed: "该组赏金合计未满 $10",
			recruit: "招募",
			recruitCaptain: "船长搭档需整回合 2 个行动",
			dispatch: "派遣",
			dispatchNeedPair: "需选中一对搭档帮手",
			exile: "驱逐到对方牌库顶",
			stop: "喊停",
			stopConfirm: "确认喊停,立即结算",
			stopNotYet: "手里或牌库还有通缉犯,不能喊停",
			endTurn: "结束回合",
			cancel: "取消",
			discardTitle: "手牌超限:点选弃置,直至合规",
			discardDo: "弃置 {{n}} 张",
			travelerTitle: "旅人补牌:点任意区域,补到 5 张",
			wardenTitle: "狱长转移:点对方监狱 1 张通缉犯",
			zoneOwnDeck: "我方牌库",
			zoneOppDeck: "对方牌库",
			zoneOppHand: "对方手牌(盲抽)",
			zoneMarket: "公共区帮手",
			zoneOwnPrison: "我方监狱",
			zoneOppPrison: "对方监狱(盲抽)",
			oppPrison: "对方监狱",
			myPrison: "我方监狱",
			marketLabel: "公共区",
			bannedMark: "禁用",
			emptyPrison: "还没有关押通缉犯",
			emptyHand: "手牌空了",
			groupSum: "合计 ${{n}}",
			newGroup: "新组",
			lockedGroup: "已封锁",
			crim: {
				c01: "怪盗·火犀鸟",
				c02: "血骑·特罗姆斯",
				c03: "实验品·蛇猫丹吉尔",
				c04: "扒手·闪电指",
				c05: "骗子·空手套",
				c06: "夜啼·扰梦虫",
				c07: "强盗·巨蛇博斯",
				c08: "卷鼻律师·罗托",
				c09: "烟雾弹伯爵·杜卡皮拉",
				c10: "路霸·铁壳",
				c11: "伪币匠·铜爪",
				c12: "毒舌·讽言家",
				c13: "催眠师·钟摆",
				c14: "涂鸦王·喷漆",
				c15: "劫筏·潮落",
				c16: "雇佣兵·鲨鱼武藏",
				c17: "沙漠毒贩·红响尾",
				c18: "走私王·暗渠",
				c19: "杀人·麦金",
				c20: "幻影大盗·无存",
				c21: "暴食·魔鬼蛙",
				c22: "魔术师·幻影洗牌",
				c23: "大魔术师·谢幕"
			},
			helper: {
				captain: "探索号船长·科尔瓦克斯",
				mate: "探索号大副·帕奇",
				cook: "厨师长·洪龙",
				souschef: "副厨师长·醉虎",
				hunter: "猎人·吉赛斯",
				fang: "猎牙·巴罗尔",
				warden: "监狱长·莫塔古斯",
				guard: "狱警·玻璃迪鲁夫",
				traveler: "旅行者·凯斯文娜",
				stray: "流浪者·树皮",
				detective: "侦探·奶酪意面波罗波",
				thief: "侠盗·泽罗"
			},
			pairEffect: {
				captain: "派遣:跳过对方下个回合;招募需整回合 2 个行动",
				cook: "同回合内招募并派遣:下个回合增加 1 个行动",
				hunter: "派遣:将我方牌库顶 3 张关进监狱,赏金为 7、8 的改为收入手牌",
				warden: "派遣:对方监狱 1 张通缉犯转移至我方监狱",
				traveler: "派遣:从双方牌库、对方手牌、公共区、双方监狱补牌,直到手牌达 5 张",
				detective: "派遣:盲抽对方 3 张手牌"
			},
			errNotYourTurn: "现在轮不到你",
			errBanFirst: "先完成禁用帮手",
			errBadCard: "这张牌不能这么用",
			errBadGroup: "这组不能追加",
			errAttackWeak: "手牌总数不大于其赏金,无法出击",
			errLock: "这组赏金合计未满 $10",
			errNoToken: "黄金令牌已用完",
			errCaptain: "招募船长搭档需要整回合 2 个行动",
			errNeedPair: "派遣需要一对搭档帮手",
			errDeckEmpty: "牌库已空",
			errStop: "手里或牌库还有通缉犯,不能喊停",
			errPending: "先完成当前结算",
			errDiscard: "仍超出上限,继续弃置",
			errBadZone: "这个区域没有可补的牌"
		},
		en: {
			name: "Wanted and Recruit",
			desc: "A two-player bounty duel: jail wanted criminals, recruit partner helpers, and call stop at the perfect moment",
			rules: "Goal: jail wanted criminals for bounty, call stop at the right moment, and outscore your rival.\nSetup: each player shuffles a 23-card criminal deck and draws 5; 12 helpers form the public area.\nTurn order: the second player bans 2 helpers first; they return automatically on their first turn.\nPlay (2 actions per turn, the same action may repeat):\n· Search: draw the top card of either deck into your hand.\n· Attack: jail 1 criminal from your hand; your hand size must exceed its bounty before playing.\n· Lock: when a prison group totals 10 bounty, spend 1 action to take a gold token and lock it.\n· Recruit: take 1 helper from the public area; the captain pair costs both actions of the turn.\n· Dispatch: play a partner pair of helpers to trigger their effect (tap a card to read it).\n· Exile: put a criminal from your hand on top of the rival’s deck.\nTurn end: hand limit 7, at most 4 helpers; discard the excess.\nWith 4 helpers the hand limit increases by 1; then draw up to 5 from your deck.\nPartner pairs (dispatch both to trigger):\n· Captain: skip the rival’s next turn; recruiting costs both actions.\n· Chefs: recruit and dispatch in the same turn to gain 1 extra action next turn.\n· Hunters: top 3 of your deck go to prison; bounty 7 and 8 go to your hand instead.\n· Wardens: move 1 criminal from the rival’s prison to yours.\n· Travelers: refill your hand one card at a time from either deck, the rival’s hand, the public area, or either prison, until you hold 5.\n· Detectives: draw 3 random cards from the rival’s hand.\nStop: with no criminals in hand and deck, you may call stop and settle at once.\nScoring: prison bounty + helper values in hand + gold tokens; ties break on tokens, then fewer prisoners.",
			turnYou: "Your turn: {{n}} actions left",
			turnWait: "Waiting for {{name}}…",
			banYou: "You go second: ban 2 helpers",
			banWait: "Waiting for {{name}} to ban helpers…",
			banConfirm: "Ban these {{n}} helpers",
			searchMine: "Search my deck",
			searchOpp: "Search rival’s deck",
			deckAria: "{{n}} cards left in deck",
			attack: "Attack",
			attackToNew: "Attack · new group",
			attackNeed: "Hand size must exceed ${{n}} (have {{m}})",
			lock: "Lock",
			lockGain: "Lock this group and take 1 gold token",
			lockNeed: "This group has not reached $10",
			recruit: "Recruit",
			recruitCaptain: "The captain pair needs both actions of the turn",
			dispatch: "Dispatch",
			dispatchNeedPair: "Select a partner pair of helpers",
			exile: "Exile onto rival’s deck",
			stop: "Stop",
			stopConfirm: "Confirm stop and settle now",
			stopNotYet: "Criminals remain in hand or deck; cannot stop",
			endTurn: "End turn",
			cancel: "Cancel",
			discardTitle: "Hand over limit: tap cards to discard until legal",
			discardDo: "Discard {{n}}",
			travelerTitle: "Travelers: tap any zone to refill your hand to 5",
			wardenTitle: "Wardens: tap 1 criminal in the rival’s prison",
			zoneOwnDeck: "My deck",
			zoneOppDeck: "Rival’s deck",
			zoneOppHand: "Rival’s hand (blind)",
			zoneMarket: "Public helpers",
			zoneOwnPrison: "My prison",
			zoneOppPrison: "Rival’s prison (blind)",
			oppPrison: "Rival’s prison",
			myPrison: "My prison",
			marketLabel: "Public area",
			bannedMark: "Banned",
			emptyPrison: "No criminals jailed yet",
			emptyHand: "Hand is empty",
			groupSum: "Total ${{n}}",
			newGroup: "New group",
			lockedGroup: "Locked",
			crim: {
				c01: "Firefinch the Phantom Thief",
				c02: "Troms the Blood Rider",
				c03: "Tangier the Snake-Cat",
				c04: "Quickfingers the Pickpocket",
				c05: "Emptysleeve the Swindler",
				c06: "Dreambug the Night Cry",
				c07: "Boss the Great Serpent",
				c08: "Roto the Snout Lawyer",
				c09: "Dukapira the Smokescreen Earl",
				c10: "Ironhide the Roadhog",
				c11: "Copperclaw the Counterfeiter",
				c12: "Mockingbird the Snarker",
				c13: "Pendulum the Hypnotist",
				c14: "Sprayrat the Graffiti King",
				c15: "Ebb the Raft Raider",
				c16: "Musashi the Mercenary Shark",
				c17: "Red Rattler the Desert Dealer",
				c18: "Darkcanal the Smuggler King",
				c19: "McKim the Killer",
				c20: "Vanish the Phantom Burglar",
				c21: "Devilfrog the Glutton",
				c22: "Shuffle the Magician",
				c23: "Curtain the Grand Magician"
			},
			helper: {
				captain: "Korvax, Captain of the Explorer",
				mate: "Patch, First Mate of the Explorer",
				cook: "Honglong the Head Chef",
				souschef: "Drunk Tiger the Sous Chef",
				hunter: "Gises the Hunter",
				fang: "Balor the Fang",
				warden: "Mortagus the Warden",
				guard: "Boladi the Guard",
				traveler: "Kesvenna the Traveler",
				stray: "Bark the Vagabond",
				detective: "Detective Cheese-Pasta Bolobo",
				thief: "Zero the Gentleman Thief"
			},
			pairEffect: {
				captain: "Dispatch: skip the rival’s next turn; recruiting costs both actions",
				cook: "Recruit and dispatch in the same turn: gain 1 extra action next turn",
				hunter: "Dispatch: move the top 3 cards of your deck into prison; those with bounty 7 or 8 go to your hand instead",
				warden: "Dispatch: move 1 criminal from the rival’s prison to yours",
				traveler: "Dispatch: refill your hand to 5 from either deck, the rival’s hand, the public area, or either prison",
				detective: "Dispatch: draw 3 random cards from the rival’s hand"
			},
			errNotYourTurn: "Not your turn",
			errBanFirst: "Finish banning helpers first",
			errBadCard: "That card cannot be used this way",
			errBadGroup: "Cannot add to this group",
			errAttackWeak: "Hand size does not exceed its bounty",
			errLock: "This group has not reached $10",
			errNoToken: "No gold tokens left",
			errCaptain: "Recruiting the captain pair needs both actions",
			errNeedPair: "Dispatch needs a partner pair",
			errDeckEmpty: "Deck is empty",
			errStop: "Criminals remain in hand or deck; cannot stop",
			errPending: "Finish the current resolution first",
			errDiscard: "Still over the limit; keep discarding",
			errBadZone: "Nothing to take from this zone"
		}
	}
};
//#endregion
export { Ae as default };
