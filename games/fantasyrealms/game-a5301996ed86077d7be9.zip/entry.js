import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { Texture as l } from "@bgparty/sdk/texture";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as f, seatName as p } from "@bgparty/sdk/ui/player-strip";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { AVATARS as v } from "@bgparty/sdk/avatars";
import { IconBot as y } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as b } from "@bgparty/sdk/player-colors";
import { Confetti as x } from "@bgparty/sdk/ui/confetti";
import { createPortal as S } from "react-dom";
//#region src/games/fantasyrealms/cards.ts
var C = [
	"army",
	"leader",
	"wizard",
	"weapon",
	"artifact",
	"beast",
	"land",
	"weather",
	"flood",
	"flame",
	"wild"
];
function w(e, t, n, r) {
	return {
		id: e,
		suit: t,
		strength: n,
		nameKey: `games.fantasyrealms.cards.${e}`,
		effectKey: `games.fantasyrealms.effects.${e}`,
		action: r
	};
}
var T = [
	w("FR01", "land", 9),
	w("FR02", "land", 6),
	w("FR03", "land", 8),
	w("FR04", "land", 7),
	w("FR05", "land", 4),
	w("FR06", "flood", 1),
	w("FR07", "flood", 18),
	w("FR08", "flood", 32),
	w("FR09", "flood", 14, "island"),
	w("FR10", "flood", 4),
	w("FR11", "weather", 8),
	w("FR12", "weather", 30),
	w("FR13", "weather", 27),
	w("FR14", "weather", 13),
	w("FR15", "weather", 4),
	w("FR16", "flame", 40),
	w("FR17", "flame", 2),
	w("FR18", "flame", 9),
	w("FR19", "flame", 11),
	w("FR20", "flame", 4),
	w("FR21", "army", 20),
	w("FR22", "army", 10),
	w("FR23", "army", 17),
	w("FR24", "army", 15),
	w("FR25", "army", 5),
	w("FR26", "wizard", 7),
	w("FR27", "wizard", 9),
	w("FR28", "wizard", 3, "necro"),
	w("FR29", "wizard", 25),
	w("FR30", "wizard", 5),
	w("FR31", "leader", 8),
	w("FR32", "leader", 6),
	w("FR33", "leader", 2),
	w("FR34", "leader", 4),
	w("FR35", "leader", 15),
	w("FR36", "beast", 9),
	w("FR37", "beast", 35),
	w("FR38", "beast", 6),
	w("FR39", "beast", 30),
	w("FR40", "beast", 12),
	w("FR41", "weapon", 23),
	w("FR42", "weapon", 1),
	w("FR43", "weapon", 7),
	w("FR44", "weapon", 3),
	w("FR45", "weapon", 35),
	w("FR46", "artifact", 4),
	w("FR47", "artifact", 5),
	w("FR48", "artifact", 2),
	w("FR49", "artifact", 3, "book"),
	w("FR50", "artifact", 1),
	w("FR51", "wild", 0, "shifter"),
	w("FR52", "wild", 0, "mirage"),
	w("FR53", "wild", 0, "doppel")
], E = new Map(T.map((e) => [e.id, e])), D = [
	"army",
	"land",
	"weather",
	"flood",
	"flame"
], O = [
	"artifact",
	"leader",
	"wizard",
	"weapon",
	"beast"
], k = [
	"army",
	"leader",
	"wizard",
	"beast"
], A = {
	army: "games.fantasyrealms.suit.army",
	leader: "games.fantasyrealms.suit.leader",
	wizard: "games.fantasyrealms.suit.wizard",
	weapon: "games.fantasyrealms.suit.weapon",
	artifact: "games.fantasyrealms.suit.artifact",
	beast: "games.fantasyrealms.suit.beast",
	land: "games.fantasyrealms.suit.land",
	weather: "games.fantasyrealms.suit.weather",
	flood: "games.fantasyrealms.suit.flood",
	flame: "games.fantasyrealms.suit.flame",
	wild: "games.fantasyrealms.suit.wild"
}, j = {
	id: "fantasyrealms",
	tier: "released",
	mechanics: ["set-collection", "hand-management"],
	interactionTags: [],
	nameKey: "games.fantasyrealms.name",
	descKey: "games.fantasyrealms.desc",
	rulesKey: "games.fantasyrealms.rules",
	icon: "🏰",
	iconImg: "games/fantasyrealms.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/fantasyrealms/en.pdf" },
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [3],
	accent: "#7c5cbf",
	releasedAt: "2026-09-16",
	search: {
		py: "huan xiang guo du",
		init: "hxgd"
	},
	hotseat: "cover"
}, M = t.string().regex(/^FR\d{2}$/), N = t.object({
	doppel: M.nullable(),
	mirage: M.nullable(),
	shifter: M.nullable(),
	bookTarget: M.nullable(),
	bookSuit: t.enum(C).nullable(),
	island: M.nullable(),
	necro: M.nullable()
}), P = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("take"),
		from: t.enum(["deck", "discard"]),
		card: M.optional()
	}),
	t.object({
		type: t.literal("drop"),
		card: M
	}),
	t.object({
		type: t.literal("declare"),
		decl: N
	}),
	t.object({ type: t.literal("declareDone") })
]), F = t.string(), I = t.object({
	phase: t.enum([
		"play",
		"declare",
		"done"
	]),
	turn: F.nullable(),
	turnPhase: t.enum(["take", "drop"]).nullable(),
	deckCount: t.int().nonnegative(),
	discard: t.array(M),
	players: t.array(t.object({
		rid: F,
		handCount: t.int().nonnegative(),
		confirmed: t.boolean()
	})),
	scores: t.record(t.string(), t.number()).nullable(),
	baseSums: t.record(t.string(), t.number()).nullable(),
	final: t.record(t.string(), t.object({
		hand: t.array(M),
		decl: N
	})).nullable()
}), L = t.object({
	hand: t.array(M),
	myDecl: N,
	myConfirmed: t.boolean()
}), R = {
	doppel: null,
	mirage: null,
	shifter: null,
	bookTarget: null,
	bookSuit: null,
	island: null,
	necro: null
};
function z(e, t, n) {
	let r = new Set(e), i = { ...R };
	n.doppel && n.doppel !== "FR53" && r.has(n.doppel) && (i.doppel = n.doppel), n.mirage && D.includes(E.get(n.mirage)?.suit) && (i.mirage = n.mirage), n.shifter && O.includes(E.get(n.shifter)?.suit) && (i.shifter = n.shifter), n.bookTarget && n.bookSuit && n.bookTarget !== "FR49" && r.has(n.bookTarget) && C.includes(n.bookSuit) && (i.bookTarget = n.bookTarget, i.bookSuit = n.bookSuit);
	let a = n.island ? E.get(n.island)?.suit : void 0;
	n.island && r.has(n.island) && (a === "flood" || a === "flame") && (i.island = n.island);
	let o = n.necro ? E.get(n.necro)?.suit : void 0;
	return n.necro && t.includes(n.necro) && o && k.includes(o) && (i.necro = n.necro), i;
}
var B = (e, t) => e.armyCleared || t === "flood" && e.floodArmyCleared ? 0 : e.countSuit("army"), V = {
	FR01: (e, t) => t.has("FR13") && t.has("FR16") ? 50 : 0,
	FR02: (e, t) => t.has("FR24") || t.has("FR39") ? 25 : 0,
	FR03: (e, t) => t.hasSuit("wizard") ? 15 : 0,
	FR04: (e, t) => 12 * t.countSuit("beast") + (t.has("FR22") ? 12 : 0),
	FR05: (e, t) => 15 * t.countSuitEx("land", e.id),
	FR06: (e, t) => Math.max(0, ...t.live().filter((e) => [
		"weapon",
		"flood",
		"flame",
		"land",
		"weather"
	].includes(e.suit)).map((e) => e.strength)),
	FR10: (e, t) => 15 * t.countSuitEx("flood", e.id),
	FR11: (e, t) => 10 * t.countSuit("flood"),
	FR14: (e, t) => t.has("FR11") && (t.has("FR12") || t.has("FR08")) ? 40 : 0,
	FR15: (e, t) => 15 * t.countSuitEx("weather", e.id),
	FR17: (e, t) => t.has("FR49") && t.has("FR03") && t.hasSuit("wizard") ? 100 : 0,
	FR18: (e, t) => 9 * (t.countSuit("weapon") + t.countSuit("artifact")),
	FR19: (e, t) => t.has("FR11") ? 30 : 0,
	FR20: (e, t) => 15 * t.countSuitEx("flame", e.id),
	FR22: (e, t) => t.hasSuit("weather") ? 0 : 5,
	FR25: (e, t) => 10 * t.countSuit("land"),
	FR26: (e, t) => {
		let n = /* @__PURE__ */ new Map();
		for (let e of t.live()) n.has(e.suit) || n.set(e.suit, /* @__PURE__ */ new Set()), n.get(e.suit)?.add(e.nameId);
		let r = 0;
		for (let e of n.values()) e.size === 3 ? r += 10 : e.size === 4 ? r += 40 : e.size >= 5 && (r += 100);
		return r;
	},
	FR27: (e, t) => 9 * t.countSuit("beast"),
	FR30: (e, t) => 5 * (t.countSuit("land") + t.countSuit("weather") + t.countSuit("flood") + t.countSuit("flame")),
	FR31: (e, t) => (t.has("FR32") ? 20 : 5) * t.countSuit("army"),
	FR32: (e, t) => (t.has("FR31") ? 20 : 5) * t.countSuit("army"),
	FR33: (e, t) => 8 * (t.countSuit("army") + t.countSuit("wizard") + t.countSuitEx("leader", e.id)),
	FR34: (e, t) => t.live().filter((e) => e.suit === "army").reduce((e, t) => e + t.strength, 0),
	FR35: (e, t) => 10 * t.countSuit("army"),
	FR36: (e, t) => t.has("FR33") ? 30 : t.has("FR35") || t.has("FR32") || t.has("FR30") ? 15 : 0,
	FR38: (e, t) => t.hasSuit("leader") || t.hasSuit("wizard") ? 14 : 0,
	FR40: (e, t) => t.has("FR07") ? 28 : 0,
	FR42: (e, t) => t.hasSuit("wizard") ? 25 : 0,
	FR43: (e, t) => t.hasSuit("leader") ? t.has("FR46") ? 40 : 10 : 0,
	FR44: (e, t) => t.has("FR22") || t.has("FR34") || t.has("FR27") ? 30 : 0,
	FR46: (e, t) => t.hasSuit("leader") ? t.has("FR43") ? 40 : 15 : 0,
	FR47: (e, t) => {
		let n = [
			0,
			0,
			0,
			10,
			30,
			60,
			100,
			150
		], r = t.live().map((e) => e.strength).sort((e, t) => e - t), i = 0;
		for (;;) {
			let e = [];
			for (let t of r) e.length > 0 && t === e[e.length - 1] + 1 ? e.push(t) : e.length < 3 && !e.includes(t) && e.splice(0, e.length, t);
			if (e.length < 3) return i;
			i += n[Math.min(e.length, 7)];
			for (let t of e) r.splice(r.indexOf(t), 1);
		}
	},
	FR48: (e, t) => {
		let n = /* @__PURE__ */ new Set();
		for (let e of t.live()) {
			if (n.has(e.suit)) return 0;
			n.add(e.suit);
		}
		return 50;
	}
}, H = {
	FR07: (e, t) => -3 * (t.countSuit("flame") + B(t, "flood")),
	FR12: (e, t) => -5 * (t.countSuit("leader") + t.countSuit("beast") + t.countSuit("flame") + B(t, "weather")),
	FR21: (e, t) => t.hasSuit("leader") ? 0 : -8,
	FR23: (e, t) => -2 * t.countSuit("land"),
	FR24: (e, t) => t.armyCleared ? 0 : -2 * t.countSuitEx("army", e.id),
	FR29: (e, t) => -10 * (t.countSuit("leader") + t.countSuitEx("wizard", e.id)),
	FR35: (e, t) => -5 * t.countSuitEx("leader", e.id),
	FR39: (e, t) => t.hasSuit("wizard") ? 0 : -40
}, U = {
	FR08: (e, t, n) => t.suit === "army" && !n.armyCleared && !n.floodArmyCleared || t.suit === "land" && t.nameId !== "FR01" || t.suit === "flame" && t.nameId !== "FR19",
	FR11: (e, t) => t.suit === "flame" && t.nameId !== "FR19",
	FR12: (e, t) => t.suit === "flood",
	FR16: (e, t) => ![
		"flame",
		"wizard",
		"weather",
		"weapon",
		"artifact",
		"wild"
	].includes(t.suit) && ![
		"FR01",
		"FR08",
		"FR09",
		"FR36",
		"FR39"
	].includes(t.nameId),
	FR37: (e, t, n) => t.suit === "army" && !n.armyCleared || t.suit === "leader" || t.suit === "beast" && t.id !== e.id
}, ee = {
	FR13: (e, t) => !t.hasSuit("flame"),
	FR41: (e, t) => !t.hasSuit("flood"),
	FR45: (e, t) => !t.hasSuit("army") && !t.armyCleared || t.hasSuit("weather")
}, te = {
	FR01: (e) => e.suit === "flood",
	FR02: (e) => e.suit === "weather",
	FR27: (e) => e.suit === "beast",
	FR50: () => !0
};
function ne(e) {
	let t = () => e.filter((e) => !e.blanked);
	return {
		has: (e) => t().some((t) => t.nameId === e),
		hasSuit: (e) => t().some((t) => t.suit === e),
		countSuit: (e) => t().filter((t) => t.suit === e).length,
		countSuitEx: (e, n) => t().filter((t) => t.suit === e && t.id !== n).length,
		live: t,
		armyCleared: e.some((e) => e.id === "FR25"),
		floodArmyCleared: e.some((e) => e.id === "FR41")
	};
}
function re(e, t) {
	let n = (r, i) => {
		let a = e.filter((e) => !e.blanked && !e.cleared && e.hooksId !== null && U[e.hooksId] && U[e.hooksId](e, r, t));
		if (a.length === 0) return !1;
		let o = [];
		for (let e of a) {
			if (r.hooksId !== null && U[r.hooksId] && !r.cleared && U[r.hooksId](r, e, t) || i.includes(e)) return !0;
			o.push(e);
		}
		return o.some((e) => !n(e, [...i, e]));
	}, r = e.filter((e) => n(e, [e]));
	for (let e of r) e.blanked = !0;
	let i = !0;
	for (; i;) {
		i = !1;
		for (let n of [...e].sort((e, t) => e.id.localeCompare(t.id))) !n.blanked && !n.cleared && n.hooksId !== null && ee[n.hooksId] && ee[n.hooksId](n, t) && (n.blanked = !0, i = !0);
	}
}
function W(e, t) {
	let n = (t.necro ? [...e, t.necro] : [...e]).map((e) => {
		let t = E.get(e);
		return {
			id: e,
			nameId: e,
			suit: t?.suit ?? "wild",
			strength: t?.strength ?? 0,
			hooksId: e,
			noBonus: !1,
			cleared: !1,
			blanked: !1
		};
	}), r = new Map(n.map((e) => [e.id, e])), i = r.get("FR53");
	if (i && t.doppel) {
		let e = r.get(t.doppel);
		e && e.id !== "FR53" && (i.nameId = e.nameId, i.suit = e.suit, i.strength = e.strength, i.hooksId = e.hooksId, i.noBonus = !0);
	}
	for (let [e, n] of [["FR52", t.mirage], ["FR51", t.shifter]]) {
		let t = r.get(e), i = n ? E.get(n) : void 0;
		t && i && (t.nameId = i.id, t.suit = i.suit, t.hooksId = null);
	}
	if (r.get("FR49") && t.bookTarget && t.bookSuit) {
		let e = r.get(t.bookTarget);
		e && e.id !== "FR49" && (e.suit = t.bookSuit);
	}
	let a = r.get("FR09");
	for (let e of n) {
		let t = e.hooksId !== null && !e.noBonus ? te[e.hooksId] : void 0;
		if (t) for (let e of n) t(e) && (e.cleared = !0);
	}
	if (a && t.island) {
		let e = r.get(t.island);
		e && (e.cleared = !0);
	}
	let o = ne(n);
	re(n, o);
	let s = n.map((e) => {
		if (e.blanked) return {
			id: e.id,
			nameId: e.nameId,
			suit: e.suit,
			strength: e.strength,
			bonus: 0,
			penalty: 0,
			blanked: !0,
			cleared: e.cleared,
			total: 0
		};
		let t = !e.noBonus && e.hooksId !== null && V[e.hooksId] ? V[e.hooksId](e, o) : 0, n = !e.cleared && e.hooksId !== null && H[e.hooksId] ? H[e.hooksId](e, o) : 0;
		return {
			id: e.id,
			nameId: e.nameId,
			suit: e.suit,
			strength: e.strength,
			bonus: t,
			penalty: n,
			blanked: !1,
			cleared: e.cleared,
			total: e.strength + t + n
		};
	});
	return {
		total: s.reduce((e, t) => e + t.total, 0),
		baseSum: s.reduce((e, t) => e + (t.blanked ? 0 : t.strength), 0),
		cards: s
	};
}
function ie(e) {
	let t = [], n = (t) => e.includes(t);
	if (n("FR53") && t.push({
		key: "doppel",
		options: [null, ...e.filter((e) => e !== "FR53")].map((e) => [e, null])
	}), n("FR52") && t.push({
		key: "mirage",
		options: [null, ...T.filter((e) => D.includes(e.suit)).map((e) => e.id)].map((e) => [e, null])
	}), n("FR51") && t.push({
		key: "shifter",
		options: [null, ...T.filter((e) => O.includes(e.suit)).map((e) => e.id)].map((e) => [e, null])
	}), n("FR49")) {
		let n = [[null, null]];
		for (let t of e) if (t !== "FR49") for (let e of C) n.push([t, e]);
		t.push({
			key: "book",
			options: n
		});
	}
	return n("FR09") && t.push({
		key: "island",
		options: [null, ...e.filter((e) => ["flood", "flame"].includes(E.get(e)?.suit ?? ""))].map((e) => [e, null])
	}), t;
}
function ae(e, t, n) {
	let r = { ...e };
	return t.key === "book" ? (r.bookTarget = n[0], r.bookSuit = n[1]) : r[t.key] = n[0], r;
}
function oe(e, t, n, r) {
	let i = n, a = W(e, i).total;
	for (let n = 0; n < r; n += 1) {
		let n = !1;
		for (let r of t) for (let t of r.options) {
			let o = ae(i, r, t), s = W(e, o).total;
			s > a && (a = s, i = o, n = !0);
		}
		if (!n) return i;
	}
	return i;
}
function G(e, t, n = "full") {
	let r = e.includes("FR28") ? [null, ...t.filter((e) => k.includes(E.get(e)?.suit))] : [null], i = { ...R }, a = -Infinity;
	for (let t of r) {
		let r = t ? [...e, t] : e, o = ie(r), s = [{
			...R,
			necro: t
		}];
		if (n === "full") for (let e of o) {
			let t = s[0], n = -Infinity;
			for (let i of e.options) {
				let a = ae(s[0], e, i), o = W(r, a).total;
				o > n && (n = o, t = a);
			}
			s.push(t);
		}
		for (let e of s) {
			let s = oe(r, o, e, n === "full" ? 8 : 3), c = W(r, s).total;
			c > a && (a = c, i = {
				...s,
				necro: t
			});
		}
	}
	return i;
}
function se(t, n, r) {
	let i = 0, a = T.map((e) => e.id);
	for (let t = a.length - 1; t > 0; --t) {
		let n = e(r, i, t + 1);
		i += 1, [a[t], a[n]] = [a[n], a[t]];
	}
	let o = {};
	for (let e of n) o[e] = a.splice(0, 7);
	let s = n.map((e, t) => ({
		kind: "deal",
		rid: e,
		data: { count: 7 },
		for: [e],
		secret: { cards: o[e] },
		...t > 0 ? { with: !0 } : {}
	}));
	return {
		state: {
			players: n,
			phase: "play",
			turnIdx: 0,
			turnPhase: "take",
			deck: a,
			discard: [],
			hands: o,
			decls: {},
			confirmed: {},
			scores: null,
			baseSums: null,
			seed: r,
			rngCursor: i
		},
		fx: s
	};
}
function ce(e, t, n) {
	if (t.type === "take") {
		if (e.phase !== "play" || e.turnPhase !== "take" || e.players[e.turnIdx] !== n.by) return { code: "games.fantasyrealms.errNotYourTurn" };
		if (t.from === "deck" && e.deck.length === 0 || t.from === "discard" && (!t.card || !e.discard.includes(t.card))) return { code: "games.fantasyrealms.errBadTake" };
		let r = structuredClone(e);
		if (t.from === "deck") {
			let e = r.deck.pop();
			return r.hands[n.by].push(e), {
				state: {
					...r,
					turnPhase: "drop"
				},
				fx: [{
					kind: "take",
					rid: n.by,
					data: { from: "deck" },
					for: [n.by],
					secret: { card: e }
				}]
			};
		}
		let i = t.card;
		return r.discard = r.discard.filter((e) => e !== i), r.hands[n.by].push(i), {
			state: {
				...r,
				turnPhase: "drop"
			},
			fx: [{
				kind: "take",
				rid: n.by,
				data: {
					from: "discard",
					card: i
				}
			}]
		};
	}
	if (t.type === "drop") {
		if (e.phase !== "play" || e.turnPhase !== "drop" || e.players[e.turnIdx] !== n.by) return { code: "games.fantasyrealms.errNotYourTurn" };
		if (!e.hands[n.by]?.includes(t.card)) return { code: "games.fantasyrealms.errBadDrop" };
		let r = structuredClone(e);
		r.hands[n.by] = r.hands[n.by].filter((e) => e !== t.card), r.discard.push(t.card);
		let i = [{
			kind: "drop",
			rid: n.by,
			data: { card: t.card }
		}];
		return r.discard.length >= 10 ? (r.phase = "declare", i.push({ kind: "declareStart" })) : (r.turnIdx = (r.turnIdx + 1) % r.players.length, r.turnPhase = "take"), {
			state: r,
			fx: i
		};
	}
	if (t.type === "declare") {
		if (e.phase !== "declare" || e.confirmed[n.by]) return { code: "games.fantasyrealms.errBadDecl" };
		let r = structuredClone(e);
		return r.decls[n.by] = z(r.hands[n.by], r.discard, t.decl), {
			state: r,
			fx: []
		};
	}
	if (e.phase !== "declare" || e.confirmed[n.by]) return { code: "games.fantasyrealms.errBadDecl" };
	let r = structuredClone(e);
	if (r.confirmed[n.by] = !0, Object.keys(r.confirmed).length < r.players.length) return {
		state: r,
		fx: []
	};
	let i = {}, a = {};
	for (let e of r.players) {
		let t = z(r.hands[e], r.discard, r.decls[e] ?? R);
		r.decls[e] = t;
		let n = W(r.hands[e], t);
		i[e] = n.total, a[e] = n.baseSum;
	}
	return r.scores = i, r.baseSums = a, r.phase = "done", {
		state: r,
		fx: []
	};
}
function le(e, t) {
	return {
		public: {
			phase: e.phase,
			turn: e.phase === "play" ? e.players[e.turnIdx] : null,
			turnPhase: e.phase === "play" ? e.turnPhase : null,
			deckCount: e.deck.length,
			discard: e.discard,
			players: e.players.map((t) => ({
				rid: t,
				handCount: e.hands[t].length,
				confirmed: !!e.confirmed[t]
			})),
			scores: e.scores,
			baseSums: e.baseSums,
			final: e.phase === "done" ? Object.fromEntries(e.players.map((t) => [t, {
				hand: e.hands[t],
				decl: e.decls[t] ?? { ...R }
			}])) : null
		},
		private: {
			hand: e.hands[t] ?? [],
			myDecl: e.decls[t] ?? { ...R },
			myConfirmed: !!e.confirmed[t]
		}
	};
}
function ue(e) {
	if (e.phase !== "done" || !e.scores || !e.baseSums) return { phase: e.phase };
	let t = [...e.players].sort((t, n) => (e.scores?.[n] ?? 0) - (e.scores?.[t] ?? 0) || (e.baseSums?.[t] ?? 0) - (e.baseSums?.[n] ?? 0)), n = t[0];
	return {
		phase: "done",
		winner: t.filter((t) => e.scores?.[t] === e.scores?.[n] && e.baseSums?.[t] === e.baseSums?.[n]),
		ranking: t,
		scores: e.scores
	};
}
var de = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: j,
	schemas: {
		action: P,
		publicView: I,
		privateView: L
	},
	setup: se,
	reduce: ce,
	viewFor: le,
	status: ue
};
//#endregion
//#region src/games/fantasyrealms/castle-icon.tsx
function fe({ size: e = 16, color: t = "var(--color-ink)", className: n }) {
	return /* @__PURE__ */ h("svg", {
		width: e,
		height: e,
		viewBox: "0 0 64 64",
		fill: "none",
		"aria-hidden": !0,
		className: n,
		children: /* @__PURE__ */ h("path", {
			fillRule: "evenodd",
			fill: t,
			d: "M12 54 L12 20 L18 20 L18 14 L24 14 L24 20 L29 20 L29 14 L35 14 L35 20 L40 20 L40 14 L46 14 L46 20 L52 20 L52 54 Z M28 54 L28 45 Q32 39 36 45 L36 54 Z"
		})
	});
}
//#endregion
//#region src/games/fantasyrealms/suit-mark.tsx
var pe = {
	army: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", { d: "M24 4 40 10v15c0 9-6 15-16 19C14 40 8 34 8 25V10z" }), /* @__PURE__ */ h("path", { d: "M24 12v23M18 20l6-8 6 8M16 30h16" })] }),
	leader: /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ h("path", { d: "M5 16 13 25 24 10 35 25 43 16 39 39H9z" }),
		/* @__PURE__ */ h("path", { d: "M10 40h28" }),
		/* @__PURE__ */ h("circle", {
			cx: "5",
			cy: "13",
			r: "2",
			fill: "currentColor",
			stroke: "none"
		}),
		/* @__PURE__ */ h("circle", {
			cx: "24",
			cy: "7",
			r: "2",
			fill: "currentColor",
			stroke: "none"
		}),
		/* @__PURE__ */ h("circle", {
			cx: "43",
			cy: "13",
			r: "2",
			fill: "currentColor",
			stroke: "none"
		})
	] }),
	wizard: /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ h("path", {
			d: "M9 40 29 20",
			strokeWidth: "5"
		}),
		/* @__PURE__ */ h("path", {
			d: "m32 5 3 8 8 3-8 3-3 8-3-8-8-3 8-3z",
			fill: "currentColor",
			stroke: "none"
		}),
		/* @__PURE__ */ h("path", {
			d: "m12 10 1.5 3.5L17 15l-3.5 1.5L12 20l-1.5-3.5L7 15l3.5-1.5z",
			fill: "currentColor",
			stroke: "none"
		})
	] }),
	weapon: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", { d: "m24 3 6 11-3 17h-6l-3-17z" }), /* @__PURE__ */ h("path", {
		d: "M9 31h30M24 31v12M19 43h10",
		strokeWidth: "4.2"
	})] }),
	artifact: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", { d: "M12 11h24l8 12-20 21L4 23z" }), /* @__PURE__ */ h("path", {
		d: "M4 23h40M12 11l5 12 7 21 7-21 5-12",
		strokeWidth: "3"
	})] }),
	beast: /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ h("circle", {
			cx: "9",
			cy: "19",
			r: "4",
			fill: "currentColor",
			stroke: "none"
		}),
		/* @__PURE__ */ h("circle", {
			cx: "18",
			cy: "11",
			r: "4",
			fill: "currentColor",
			stroke: "none"
		}),
		/* @__PURE__ */ h("circle", {
			cx: "30",
			cy: "11",
			r: "4",
			fill: "currentColor",
			stroke: "none"
		}),
		/* @__PURE__ */ h("circle", {
			cx: "39",
			cy: "19",
			r: "4",
			fill: "currentColor",
			stroke: "none"
		}),
		/* @__PURE__ */ h("path", {
			d: "M24 21c-5 0-7 5-11 8-5 5-3 13 4 13 3 0 5-2 7-2s4 2 7 2c7 0 9-8 4-13-4-3-6-8-11-8z",
			fill: "currentColor",
			stroke: "none"
		})
	] }),
	land: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", { d: "M3 40 17 12l8 16 7-20 13 32z" }), /* @__PURE__ */ h("path", {
		d: "M3 41h42M14 19l3-7 4 8M29 18l3-10 4 12",
		strokeWidth: "3.2"
	})] }),
	weather: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", { d: "M11 31C6 31 4 27 4 23c0-5 4-9 9-9 2-6 7-9 13-8 5 0 8 3 10 8 5 0 8 4 8 9 0 4-3 8-8 8H11z" }), /* @__PURE__ */ h("path", {
		d: "m26 24-6 12h7l-3 9 14-16h-8l3-5z",
		fill: "currentColor",
		stroke: "none"
	})] }),
	flood: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", { d: "M24 4c6 10 17 21 17 29 0 9-7 13-17 13S7 42 7 33C7 25 18 14 24 4z" }), /* @__PURE__ */ h("path", {
		d: "M12 33c4-3 8-3 12 0s8 3 12 0M17 39c3-2 6-2 9 0s5 2 7 0",
		strokeWidth: "3.1"
	})] }),
	flame: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", { d: "M27 4c-2 11 10 13 10 26 0 9-6 15-14 15-9 0-14-6-14-15 0-5 3-10 8-14 0 7 5 8 6 3 1-4 2-9 4-15z" }), /* @__PURE__ */ h("path", {
		d: "M24 26c2 5 6 7 5 12-1 4-7 6-10 2-3-4 0-9 5-14z",
		fill: "currentColor",
		stroke: "none"
	})] }),
	wild: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", { d: "M11 19c2-8 9-13 18-12 5 1 8 3 11 7M40 14V6M40 14h-8M37 29c-2 8-9 13-18 12-5-1-8-3-11-7M8 34v8M8 34h8" }), /* @__PURE__ */ h("path", { d: "m24 16 8 8-8 8-8-8z" })] })
};
function K({ suit: e, className: t }) {
	return /* @__PURE__ */ h("svg", {
		className: t,
		viewBox: "0 0 48 48",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "3.6",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: pe[e]
	});
}
//#endregion
//#region src/games/fantasyrealms/card.tsx
var me = {
	army: "#7a4b57",
	leader: "#784a8b",
	wizard: "#4e5c9a",
	weapon: "#4b5f70",
	artifact: "#8a6938",
	beast: "#8a5c37",
	land: "#3d7358",
	weather: "#5f667c",
	flood: "#247896",
	flame: "#a75234",
	wild: "#9a4d79"
};
function he(e) {
	return { backgroundColor: me[e] };
}
function q({ id: e, size: t, dimmed: n, badge: r, face: i }) {
	let a = c(), o = E.get(e);
	if (!o) return null;
	let s = i?.suit ?? o.suit, l = i?.strength ?? o.strength, u = i?.nameId ?? e, d = a(E.get(u)?.nameKey ?? o.nameKey);
	return /* @__PURE__ */ g("span", {
		className: `fr-card fr-card--${t} ${n ? "fr-card--blanked" : ""}`,
		style: { "--fr-suit": me[s] },
		children: [
			/* @__PURE__ */ g("span", {
				className: "fr-card__top",
				children: [/* @__PURE__ */ h(K, {
					suit: s,
					className: "fr-card__pip"
				}), /* @__PURE__ */ h("span", {
					className: "fr-card__strength font-mono tabular-nums",
					children: l
				})]
			}),
			/* @__PURE__ */ h("span", {
				className: "fr-card__emblem",
				children: /* @__PURE__ */ h(K, { suit: s })
			}),
			o.action && /* @__PURE__ */ h("span", {
				className: "fr-card__rune",
				"aria-hidden": "true",
				children: "✦"
			}),
			/* @__PURE__ */ h("span", {
				className: "fr-card__name",
				children: d
			}),
			u !== e && /* @__PURE__ */ h("span", {
				className: "fr-card__changed",
				"aria-hidden": "true",
				children: "↝"
			}),
			n && /* @__PURE__ */ g("span", {
				className: "fr-card__seal",
				children: [a("games.fantasyrealms.blankedTag"), " · 0"]
			}),
			r
		]
	});
}
function J({ size: e }) {
	return /* @__PURE__ */ g("span", {
		className: `fr-card fr-card--${e} fr-card--back`,
		children: [/* @__PURE__ */ h("span", {
			className: "fr-card__back-crest",
			children: /* @__PURE__ */ h(fe, {
				size: e === "sm" ? 31 : 44,
				color: "var(--fr-gold)"
			})
		}), /* @__PURE__ */ h("span", {
			className: "fr-card__back-monogram",
			"aria-hidden": "true",
			children: "FR"
		})]
	});
}
//#endregion
//#region src/games/fantasyrealms/detail-panel.tsx
function ge(e, t, n) {
	if (n === "book") return !t.bookTarget || !t.bookSuit ? e("games.fantasyrealms.declTargetNone") : e("games.fantasyrealms.declTargetBook", {
		name: e(E.get(t.bookTarget)?.nameKey ?? "games.fantasyrealms.name"),
		suit: e(A[t.bookSuit])
	});
	let r = t[n];
	return r ? e("games.fantasyrealms.declTarget", { name: e(E.get(r)?.nameKey ?? "games.fantasyrealms.name") }) : e("games.fantasyrealms.declTargetNone");
}
function _e({ id: e, action: t, decl: n, scored: r, onClose: i }) {
	let a = c(), o = E.get(e);
	if (!o) return null;
	let s = n && o.action ? ge(a, n, o.action) : null, l = r ? E.get(r.nameId) ?? o : o, u = r?.suit ?? o.suit;
	return /* @__PURE__ */ g("div", {
		className: "fr-detail",
		children: [
			/* @__PURE__ */ h(q, {
				id: e,
				size: "sm",
				face: r,
				dimmed: r?.blanked,
				badge: r && /* @__PURE__ */ h("span", {
					className: "fr-score-card__total font-mono tabular-nums",
					children: r.total
				})
			}),
			/* @__PURE__ */ g("div", {
				className: "fr-detail__text",
				children: [
					/* @__PURE__ */ g("p", {
						className: "fr-detail__title",
						children: [
							/* @__PURE__ */ h(K, {
								suit: u,
								className: "inline-block size-4 align-[-2px]"
							}),
							" ",
							a(l.nameKey),
							" · ",
							a(A[u])
						]
					}),
					/* @__PURE__ */ h("p", {
						className: "fr-detail__effect",
						children: a(o.effectKey)
					}),
					r && /* @__PURE__ */ h("p", {
						className: "fr-detail__effect font-mono tabular-nums",
						children: r.blanked ? a("games.fantasyrealms.blankedTag") : `${r.strength} + ${r.bonus} ${r.penalty < 0 ? "−" : "+"} ${Math.abs(r.penalty)} = ${r.total}`
					}),
					s && /* @__PURE__ */ h("p", {
						className: "fr-detail__target",
						children: s
					})
				]
			}),
			/* @__PURE__ */ g("div", {
				className: "fr-detail__buttons",
				children: [/* @__PURE__ */ h("button", {
					type: "button",
					onClick: i,
					"aria-label": a("games.fantasyrealms.close"),
					className: "btn-quiet px-2 text-lg",
					children: "×"
				}), t && /* @__PURE__ */ h("button", {
					type: "button",
					onClick: t.onClick,
					className: "btn-base bg-pop px-2 text-xs",
					children: t.label
				})]
			})
		]
	});
}
//#endregion
//#region src/games/fantasyrealms/take-ants.tsx
function ve() {
	return /* @__PURE__ */ g("svg", {
		className: "fr-take-ants",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		focusable: "false",
		children: [/* @__PURE__ */ h("rect", {
			className: "fr-take-ants__base",
			x: "0",
			y: "0",
			width: "100",
			height: "100",
			rx: "7",
			fill: "none",
			vectorEffect: "non-scaling-stroke"
		}), /* @__PURE__ */ h("rect", {
			className: "fr-take-ants__march",
			x: "0",
			y: "0",
			width: "100",
			height: "100",
			rx: "7",
			fill: "none",
			vectorEffect: "non-scaling-stroke",
			strokeDasharray: "6 4",
			children: /* @__PURE__ */ h("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-10",
				dur: "0.55s",
				repeatCount: "indefinite"
			})
		})]
	});
}
//#endregion
//#region src/games/fantasyrealms/view-player.tsx
var ye = {
	doppel: "games.fantasyrealms.actionNone.doppel",
	mirage: "games.fantasyrealms.actionNone.mirage",
	shifter: "games.fantasyrealms.actionNone.shifter",
	book: "games.fantasyrealms.actionNone.book",
	island: "games.fantasyrealms.actionNone.island",
	necro: "games.fantasyrealms.actionNone.necro"
}, be = {
	doppel: "games.fantasyrealms.actionTitle.doppel",
	mirage: "games.fantasyrealms.actionTitle.mirage",
	shifter: "games.fantasyrealms.actionTitle.shifter",
	book: "games.fantasyrealms.actionTitle.book",
	island: "games.fantasyrealms.actionTitle.island",
	necro: "games.fantasyrealms.actionTitle.necro"
};
function xe(e, t, n, r, i) {
	let a = 0, o = 1;
	for (let s = 1; s <= n; s++) {
		let c = Math.ceil(n / s), l = Math.min((e - (s - 1) * r) / s, (t - (c - 1) * i) / c * 58 / 86);
		l > a && (a = l, o = s);
	}
	return a < 96 && (o = Math.max(1, Math.min(n, Math.floor((e + r) / (96 + r))))), {
		columns: o,
		width: Math.floor(Math.max(96, Math.min(480, a)) * 100) / 100
	};
}
function Se(e, t, n) {
	let r = Math.max(190, Math.min(334, t * .3)), i = Math.floor(Math.max(96, Math.min(208, (e - 7 * n) / 8, (r - 64) * 80 / 104)) * 100) / 100;
	return {
		width: i,
		height: Math.ceil(i * 104 / 80) + 64
	};
}
function Ce(e, t, n, r) {
	let i = 0, a = 1;
	for (let o = 1; o <= n; o++) {
		let s = Math.ceil(n / o), c = Math.min((e - (o - 1) * 12) / o, ((t - (s - 1) * 12) / s - r) * 58 / 86);
		c > i && (i = c, a = o);
	}
	return i < 96 && (a = Math.max(1, Math.min(n, Math.floor((e + 12) / 108)))), {
		columns: a,
		width: Math.floor(Math.max(96, Math.min(320, i)) * 100) / 100
	};
}
function we(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ h(Te, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Te({ pub: e, priv: t, members: o, myRid: s, send: l }) {
	let p = c(), m = (e) => o.find((t) => t.rid === e)?.name ?? e, _ = e.turn === s, v = _ && e.turnPhase === "take", y = _ && e.turnPhase === "drop", [b, x] = a(null), [S, C] = a(null), [w, T] = a(null), D = i(null);
	n(() => {
		let t = D.current, n = t?.querySelector(".game-screen-layout"), r = t?.querySelector(".fr-banner-stack"), i = t?.querySelector(".fr-table"), a = t?.querySelector(".fr-actions-height"), s = t?.querySelector(".fr-market-scroll"), c = s?.querySelector(".fr-market-grid"), l = t?.querySelector(".fr-draw-row"), u = l?.querySelector(".fr-deck-zone");
		if (!t || !n || !r || !i || !a) return;
		let d = (e, t, n) => {
			e.style.getPropertyValue(t) !== n && e.style.setProperty(t, n);
		}, f = () => {
			let f = getComputedStyle(i).getPropertyValue("--fr-wide").trim() === "1";
			if (t.dataset.frWide = String(f), !f) {
				for (let e of [
					"--fr-hand-card-w",
					"--fr-hand-gap",
					"--fr-actions-h",
					"--fr-detail-card-w",
					"--fr-detail-text-h"
				]) n.style.removeProperty(e);
				if (r.style.removeProperty("--fr-seat-count"), c) for (let e of ["--fr-market-columns", "--fr-market-card-w"]) c.style.removeProperty(e);
				u?.style.removeProperty("--fr-deck-card-w");
				return;
			}
			let p = Math.max(8, Math.min(14, t.clientWidth * .007)), m = Se(a.clientWidth - 20, t.clientHeight, p);
			if (d(r, "--fr-seat-count", String(Math.max(1, o.length))), d(n, "--fr-hand-gap", `${p}px`), d(n, "--fr-hand-card-w", `${m.width}px`), d(n, "--fr-actions-h", `${m.height}px`), d(n, "--fr-detail-card-w", `${Math.floor(Math.max(96, Math.min(208, i.clientWidth * .16, (i.clientHeight - 28) * 58 / 86)))}px`), d(n, "--fr-detail-text-h", `${Math.max(72, Math.min(360, i.clientHeight - 28))}px`), s && c && e.discard.length > 0) {
				let t = getComputedStyle(c), n = xe(s.clientWidth - Number.parseFloat(t.paddingLeft) - Number.parseFloat(t.paddingRight), s.clientHeight - Number.parseFloat(t.paddingTop) - Number.parseFloat(t.paddingBottom), e.discard.length, Number.parseFloat(t.columnGap), Number.parseFloat(t.rowGap));
				d(c, "--fr-market-columns", String(n.columns)), d(c, "--fr-market-card-w", `${n.width}px`);
			}
			if (l && u) {
				let t = l.querySelector(".fr-turn-plaque"), n = getComputedStyle(l), r = getComputedStyle(u), i = t?.getBoundingClientRect().height ?? 0, a = l.clientWidth - Number.parseFloat(n.paddingLeft) - Number.parseFloat(n.paddingRight) - Number.parseFloat(r.paddingLeft) - Number.parseFloat(r.paddingRight) - 2, o = l.clientHeight - Number.parseFloat(n.paddingTop) - Number.parseFloat(n.paddingBottom) - i - (i > 0 ? Number.parseFloat(n.rowGap) : 0) - 48, s = Math.max(96, Math.min(e.discard.length === 0 ? 480 : 240, a, o * 58 / 86));
				d(u, "--fr-deck-card-w", `${Math.floor(s * 100) / 100}px`);
			}
		};
		f();
		let p = new ResizeObserver(f);
		for (let e of [
			t,
			i,
			a,
			s,
			l
		]) e && p.observe(e);
		return () => p.disconnect();
	}, [
		e.phase,
		e.discard.length,
		o.length
	]);
	let [O, k] = a(e.phase);
	O !== e.phase && (k(e.phase), x(null), C(null), T(null));
	let [A, M] = a(`${e.turn}:${e.turnPhase}`);
	A !== `${e.turn}:${e.turnPhase}` && (M(`${e.turn}:${e.turnPhase}`), x(null));
	let N = S ?? t?.myDecl ?? R, P = r(() => t?.hand ?? [], [t]), F = r(() => e.phase !== "play" && t ? W(P, N) : null, [
		e.phase,
		t,
		P,
		N
	]), I = (e) => {
		C(e), l({
			type: "declare",
			decl: e
		});
	}, L = "info", z;
	e.phase === "play" ? v ? (L = "accent", z = p("games.fantasyrealms.takePrompt")) : y ? (L = "warn", z = p("games.fantasyrealms.dropPrompt")) : z = p("games.fantasyrealms.takeWaiting", { name: m(e.turn ?? "") }) : e.phase === "declare" ? t?.myConfirmed ? z = p("games.fantasyrealms.waitingConfirm") : (L = "accent", z = p("games.fantasyrealms.declarePrompt")) : (L = "done", z = p("games.fantasyrealms.doneText"));
	let B = e.phase === "play" ? p("games.fantasyrealms.discardChip", {
		n: e.discard.length,
		total: 10
	}) : e.phase === "declare" ? p("games.fantasyrealms.confirmChip", {
		n: e.players.filter((e) => e.confirmed).length,
		total: e.players.length
	}) : void 0, V = b !== null && e.discard.includes(b), H = b !== null && P.includes(b);
	return /* @__PURE__ */ h("div", {
		ref: D,
		className: "fr-game",
		"data-fr-phase": e.phase,
		children: /* @__PURE__ */ h(u, {
			adaptive: !0,
			banner: /* @__PURE__ */ g("div", {
				className: "fr-banner-stack",
				children: [/* @__PURE__ */ h(d, {
					tone: L,
					text: z,
					chip: B,
					accent: j.accent
				}), /* @__PURE__ */ h(f, {
					variant: "medal",
					members: o,
					myRid: s,
					anchorOf: (e) => `seat:${e}`,
					action: (t) => {
						if (e.phase === "declare") {
							let n = e.players.find((e) => e.rid === t);
							return n ? n.confirmed ? "done" : "pending" : null;
						}
						return e.turn === t ? "pending" : null;
					},
					status: (t) => {
						let n = e.players.find((e) => e.rid === t);
						return n ? /* @__PURE__ */ g("span", {
							"data-fr-seat": t,
							className: "font-mono text-xs font-bold tabular-nums",
							children: ["▣ ", n.handCount]
						}) : null;
					}
				})]
			}),
			actionsHeight: "fr-actions-height h-36 short:h-20",
			actions: e.phase === "declare" && t ? /* @__PURE__ */ h(Me, {
				total: F?.total ?? 0,
				confirmed: t.myConfirmed,
				onAuto: () => I(G(P, e.discard)),
				onConfirm: () => l({ type: "declareDone" })
			}) : e.phase === "play" && t ? /* @__PURE__ */ h(Ae, {
				hand: P,
				sel: b,
				myDrop: y,
				onSelect: (e) => x(b === e ? null : e)
			}) : /* @__PURE__ */ h("div", { className: "fr-hand-tray" }),
			overlay: b && E.get(b) && (e.phase === "play" || e.phase === "declare") ? /* @__PURE__ */ h(_e, {
				id: b,
				decl: e.phase === "declare" ? N : void 0,
				scored: e.phase === "declare" ? F?.cards.find((e) => e.id === b) : void 0,
				action: e.phase === "play" && v && V ? {
					label: p("games.fantasyrealms.takeThis"),
					onClick: () => {
						l({
							type: "take",
							from: "discard",
							card: b
						}), x(null);
					}
				} : e.phase === "play" && y && H ? {
					label: p("games.fantasyrealms.dropThis"),
					onClick: () => {
						l({
							type: "drop",
							card: b
						}), x(null);
					}
				} : void 0,
				onClose: () => x(null)
			}) : void 0,
			scroll: !1,
			children: e.phase === "declare" && t ? /* @__PURE__ */ h(je, {
				pub: e,
				hand: P,
				decl: N,
				preview: F,
				confirmed: t.myConfirmed,
				onEdit: I,
				onInspect: x,
				sheet: w,
				setSheet: T
			}) : /* @__PURE__ */ h(Ee, {
				pub: e,
				myTake: v,
				myDrop: y,
				sel: b,
				setSel: x,
				send: l
			})
		})
	});
}
function Ee({ pub: e, myTake: t, myDrop: n, sel: r, setSel: i, send: a }) {
	let s = c(), { ref: u } = o("table"), { ref: d } = o("discard");
	return /* @__PURE__ */ g("div", {
		ref: u,
		"data-fr-anchor": "table",
		className: "fr-table fr-play-table",
		children: [/* @__PURE__ */ h(l, {
			kind: "sheen",
			base: "#302244",
			className: "absolute inset-0 size-full"
		}), /* @__PURE__ */ g("div", {
			className: "fr-table__content",
			"data-empty-market": e.discard.length === 0,
			children: [
				/* @__PURE__ */ g("div", {
					className: "fr-draw-row",
					children: [/* @__PURE__ */ g("div", {
						className: `fr-deck-zone ${t && e.deckCount > 0 ? "fr-deck-zone--take" : ""}`,
						children: [/* @__PURE__ */ h(De, {
							count: e.deckCount,
							tappable: t && e.deckCount > 0,
							onTake: () => a({
								type: "take",
								from: "deck"
							})
						}), t && e.deckCount > 0 && /* @__PURE__ */ h(ve, {})]
					}), /* @__PURE__ */ g("div", {
						className: "fr-turn-plaque",
						children: [
							/* @__PURE__ */ h("span", {
								className: "fr-turn-plaque__eyebrow",
								children: s("games.fantasyrealms.turnPlaque")
							}),
							/* @__PURE__ */ h("span", {
								className: "fr-turn-plaque__main",
								children: s(t ? "games.fantasyrealms.chooseCard" : n ? "games.fantasyrealms.dropPrompt" : "games.fantasyrealms.waitTable")
							}),
							/* @__PURE__ */ h("span", {
								className: "fr-turn-plaque__sub",
								children: s(t ? "games.fantasyrealms.takeSources" : n ? "games.fantasyrealms.dropSource" : "games.fantasyrealms.waitSource")
							})
						]
					})]
				}),
				/* @__PURE__ */ g("div", {
					className: "fr-market-heading",
					children: [/* @__PURE__ */ h("strong", { children: s("games.fantasyrealms.discardArea") }), /* @__PURE__ */ h("span", { children: t && e.discard.length > 0 ? s("games.fantasyrealms.discardTakeHint") : s("games.fantasyrealms.discardChip", {
						n: e.discard.length,
						total: 10
					}) })]
				}),
				/* @__PURE__ */ g("div", {
					ref: d,
					"data-fr-anchor": "discard",
					"data-empty": e.discard.length === 0,
					className: `fr-market-frame ${t && e.discard.length > 0 ? "fr-market-frame--take" : ""}`,
					children: [/* @__PURE__ */ h("div", {
						className: "fr-market-scroll",
						children: e.discard.length > 0 ? /* @__PURE__ */ h("div", {
							className: "fr-market-grid",
							children: e.discard.map((e) => /* @__PURE__ */ h("button", {
								type: "button",
								"aria-label": s(E.get(e)?.nameKey ?? "games.fantasyrealms.name"),
								"aria-pressed": r === e,
								onClick: () => i(r === e ? null : e),
								className: `fr-market-card ${t ? "fr-market-card--take" : ""} ${r === e ? "fr-market-card--selected" : ""}`,
								children: /* @__PURE__ */ h(Oe, { id: e })
							}, e))
						}) : /* @__PURE__ */ h("div", {
							className: "fr-market-empty",
							children: s("games.fantasyrealms.discardEmpty")
						})
					}), t && e.discard.length > 0 && /* @__PURE__ */ h(ve, {})]
				})
			]
		})]
	});
}
function De({ count: e, tappable: t, onTake: n }) {
	let r = c(), { ref: i } = o("deck");
	return /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
		ref: i,
		"data-fr-anchor": "deck",
		type: "button",
		disabled: !t,
		"aria-label": r("games.fantasyrealms.deckTakeAria"),
		onClick: n,
		className: "fr-deck-zone__button",
		children: /* @__PURE__ */ h(J, { size: "sm" })
	}), /* @__PURE__ */ h("span", {
		className: "fr-deck-zone__count font-mono tabular-nums",
		children: r("games.fantasyrealms.deckCount", { n: e })
	})] });
}
function Oe({ id: e }) {
	let { ref: t, hidden: n } = o(`discardCard:${e}`);
	return /* @__PURE__ */ h("span", {
		ref: t,
		"data-fr-anchor": `discardCard:${e}`,
		className: "inline-flex",
		style: { visibility: n ? "hidden" : void 0 },
		children: /* @__PURE__ */ h(q, {
			id: e,
			size: "sm"
		})
	});
}
function ke({ id: e }) {
	let { ref: t, hidden: n } = o(`handCard:${e}`);
	return /* @__PURE__ */ h("span", {
		ref: t,
		"data-fr-anchor": `handCard:${e}`,
		className: "inline-flex",
		style: { visibility: n ? "hidden" : void 0 },
		children: /* @__PURE__ */ h(q, {
			id: e,
			size: "lg"
		})
	});
}
function Ae({ hand: e, sel: t, myDrop: n, onSelect: r }) {
	let i = c();
	return /* @__PURE__ */ g("div", {
		className: "fr-hand-tray",
		children: [/* @__PURE__ */ g("div", {
			className: "fr-hand-tray__heading",
			children: [/* @__PURE__ */ h("span", { children: i("games.fantasyrealms.handLabel", { n: e.length }) }), /* @__PURE__ */ h("span", { children: i(n ? "games.fantasyrealms.dropSource" : "games.fantasyrealms.handSwipe") })]
		}), /* @__PURE__ */ h("div", {
			className: "fr-hand-tray__scroll",
			children: /* @__PURE__ */ h("div", {
				className: "fr-hand-tray__row",
				children: e.map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					"aria-label": i(E.get(e)?.nameKey ?? "games.fantasyrealms.name"),
					"aria-pressed": t === e,
					onClick: () => r(e),
					className: `fr-hand-card ${n ? "fr-hand-card--drop" : ""} ${t === e ? "fr-hand-card--selected" : ""}`,
					children: /* @__PURE__ */ h(ke, { id: e })
				}, e))
			})
		})]
	});
}
function je({ pub: e, hand: t, decl: r, preview: a, confirmed: s, onEdit: u, onInspect: d, sheet: f, setSheet: p }) {
	let _ = c(), v = new Set(t), { ref: y } = o("table"), b = i(null), x = a?.cards.length ?? 0;
	return n(() => {
		let e = b.current, t = e?.querySelector(".fr-score-grid");
		if (!e || !t) return;
		let n = () => {
			if (getComputedStyle(e).getPropertyValue("--fr-score-wide").trim() !== "1") {
				t.style.removeProperty("--fr-score-columns"), t.style.removeProperty("--fr-score-card-w");
				return;
			}
			let n = getComputedStyle(t), r = Ce(e.clientWidth - parseFloat(n.paddingLeft) - parseFloat(n.paddingRight), e.clientHeight - parseFloat(n.paddingTop) - parseFloat(n.paddingBottom), x, 112);
			t.style.setProperty("--fr-score-columns", String(r.columns)), t.style.setProperty("--fr-score-card-w", `${r.width}px`);
		};
		n();
		let r = new ResizeObserver(n);
		return r.observe(e), () => r.disconnect();
	}, [x]), /* @__PURE__ */ g("div", {
		ref: y,
		"data-fr-anchor": "table",
		className: "fr-table fr-score-table",
		children: [
			/* @__PURE__ */ h(l, {
				kind: "sheen",
				base: "#302244",
				className: "absolute inset-0 size-full"
			}),
			/* @__PURE__ */ g("div", {
				className: "fr-table__content fr-score-table",
				children: [/* @__PURE__ */ g("div", {
					className: "fr-score-heading",
					children: [/* @__PURE__ */ h("strong", { children: _("games.fantasyrealms.scoreTable") }), /* @__PURE__ */ h("span", { children: _(s ? "games.fantasyrealms.confirmedTag" : "games.fantasyrealms.declarePrompt") })]
				}), /* @__PURE__ */ h("div", {
					ref: b,
					className: "fr-score-scroll",
					children: /* @__PURE__ */ h("div", {
						className: "fr-score-grid",
						children: a?.cards.map((e) => {
							let t = E.get(e.id), n = t?.action, i = n === "book" ? !!(r.bookTarget && r.bookSuit) : n ? !!r[n] : !1, a = !v.has(e.id), o = _(E.get(e.nameId)?.nameKey ?? t?.nameKey ?? "games.fantasyrealms.name");
							return /* @__PURE__ */ g("div", {
								className: "fr-score-tile",
								children: [
									/* @__PURE__ */ h("button", {
										type: "button",
										onClick: () => d(e.id),
										className: "fr-score-card",
										"aria-label": `${o} · ${e.total}`,
										children: /* @__PURE__ */ h(q, {
											id: e.id,
											size: "sm",
											face: e,
											dimmed: e.blanked,
											badge: /* @__PURE__ */ h("span", {
												className: "fr-score-card__total font-mono tabular-nums",
												children: e.total
											})
										})
									}),
									/* @__PURE__ */ h("div", {
										className: "fr-score-tile__math font-mono tabular-nums",
										children: a ? /* @__PURE__ */ h("span", { children: _("games.fantasyrealms.fromDiscardTag") }) : e.blanked ? /* @__PURE__ */ h("span", { children: _("games.fantasyrealms.blankedTag") }) : /* @__PURE__ */ g(m, { children: [
											e.bonus !== 0 && /* @__PURE__ */ g("span", { children: ["+", e.bonus] }),
											e.penalty !== 0 && /* @__PURE__ */ h("span", { children: e.penalty }),
											e.bonus === 0 && e.penalty === 0 && /* @__PURE__ */ h("span", { children: "—" })
										] })
									}),
									n ? /* @__PURE__ */ h("button", {
										type: "button",
										disabled: s,
										onClick: () => p(n),
										className: "fr-score-tile__configure",
										children: _(i ? "games.fantasyrealms.configured" : "games.fantasyrealms.configure")
									}) : /* @__PURE__ */ h("span", { className: "fr-score-tile__spacer" })
								]
							}, e.id);
						})
					})
				})]
			}),
			f && /* @__PURE__ */ h(Ne, {
				sheet: f,
				hand: t,
				discard: e.discard,
				decl: r,
				onEdit: u,
				onClose: () => p(null)
			})
		]
	});
}
function Me({ total: e, confirmed: t, onAuto: n, onConfirm: r }) {
	let i = c();
	return /* @__PURE__ */ g("div", {
		className: "fr-score-actions",
		children: [/* @__PURE__ */ g("div", {
			className: "fr-score-actions__total",
			children: [/* @__PURE__ */ h("span", { children: i("games.fantasyrealms.totalLabel") }), /* @__PURE__ */ h("strong", {
				className: "font-mono tabular-nums",
				children: e
			})]
		}), t ? /* @__PURE__ */ g("div", {
			className: "fr-score-actions__confirmed",
			children: ["✦ ", i("games.fantasyrealms.waitingConfirm")]
		}) : /* @__PURE__ */ g("div", {
			className: "fr-score-actions__buttons",
			children: [/* @__PURE__ */ h("button", {
				type: "button",
				onClick: n,
				className: "btn-quiet px-2",
				children: i("games.fantasyrealms.autoBest")
			}), /* @__PURE__ */ h("button", {
				type: "button",
				onClick: r,
				className: "btn-base px-2 text-white",
				style: { backgroundColor: j.accent },
				children: i("games.fantasyrealms.confirmDecl")
			})]
		})]
	});
}
function Ne({ sheet: e, hand: t, discard: r, decl: o, onEdit: s, onClose: l }) {
	let u = c(), [d, f] = a(o.bookTarget), p = i(null), _ = u(ye[e]), v = e === "doppel" ? [null, ...t.filter((e) => e !== "FR53")] : e === "mirage" ? [null, ...T.filter((e) => D.includes(e.suit)).map((e) => e.id)] : e === "shifter" ? [null, ...T.filter((e) => O.includes(e.suit)).map((e) => e.id)] : e === "island" ? [null, ...t.filter((e) => ["flood", "flame"].includes(E.get(e)?.suit ?? ""))] : e === "necro" ? [null, ...r.filter((e) => k.includes(E.get(e)?.suit))] : [null, ...t.filter((e) => e !== "FR49")], y = e === "doppel" ? o.doppel : e === "mirage" ? o.mirage : e === "shifter" ? o.shifter : e === "island" ? o.island : e === "necro" ? o.necro : o.bookTarget;
	n(() => {
		let e = p.current, t = e?.querySelector(".fr-decl-sheet__scroll"), n = e?.querySelector(".fr-decl-sheet__cards");
		if (!e || !t || !n) return;
		let r = () => {
			if (getComputedStyle(t).getPropertyValue("--fr-sheet-wide").trim() !== "1") {
				n.style.removeProperty("--fr-sheet-columns"), n.style.removeProperty("--fr-sheet-card-w");
				return;
			}
			let e = getComputedStyle(n), r = xe(t.clientWidth - parseFloat(e.paddingLeft) - parseFloat(e.paddingRight), t.clientHeight - parseFloat(e.paddingTop) - parseFloat(e.paddingBottom), v.length, 12, 12);
			n.style.setProperty("--fr-sheet-columns", String(r.columns)), n.style.setProperty("--fr-sheet-card-w", `${Math.min(208, r.width)}px`);
		};
		r();
		let i = new ResizeObserver(r);
		return i.observe(e), i.observe(t), () => i.disconnect();
	}, [
		v.length,
		e,
		d
	]);
	let b = (t) => {
		if (e === "book") {
			f(t), t === null && (s({
				...o,
				bookTarget: null,
				bookSuit: null
			}), l());
			return;
		}
		s({
			...o,
			[e]: t
		}), l();
	};
	return /* @__PURE__ */ h("div", {
		ref: p,
		className: "fr-declaration fixed inset-0 z-40 flex items-end justify-center bg-ink/40",
		onClick: l,
		children: /* @__PURE__ */ g("div", {
			className: "card fr-decl-sheet safe-b max-h-[70%] w-full max-w-md overflow-y-auto rounded-b-none p-3",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ g("header", {
					className: "fr-decl-sheet__heading",
					children: [/* @__PURE__ */ h("h2", { children: u(be[e]) }), /* @__PURE__ */ h("button", {
						type: "button",
						onClick: l,
						"aria-label": u("games.fantasyrealms.close"),
						children: "×"
					})]
				}),
				e === "book" && d && /* @__PURE__ */ g("div", {
					className: "fr-decl-sheet__book",
					children: [/* @__PURE__ */ h("p", { children: u("games.fantasyrealms.declTarget", { name: u(E.get(d)?.nameKey ?? "games.fantasyrealms.name") }) }), /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-quiet",
						onClick: () => f(null),
						children: u("games.fantasyrealms.chooseTargetAgain")
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: "fr-decl-sheet__scroll",
					children: /* @__PURE__ */ h("div", {
						className: e === "book" && d ? "fr-decl-sheet__suits flex flex-wrap gap-1.5" : "fr-decl-sheet__cards",
						children: e === "book" && d ? /* @__PURE__ */ h(m, { children: C.map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => {
								s({
									...o,
									bookTarget: d,
									bookSuit: e
								}), l();
							},
							className: "fr-sheet-suit",
							"aria-pressed": o.bookTarget === d && o.bookSuit === e,
							style: he(e),
							children: [
								/* @__PURE__ */ h(K, { suit: e }),
								" ",
								u(A[e])
							]
						}, e)) }) : v.map((e) => e === null ? /* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => b(null),
							"aria-pressed": y === null,
							className: `fr-sheet-card fr-sheet-card--none ${y === null ? "fr-sheet-card--current" : ""}`,
							children: _
						}, "none") : /* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => b(e),
							"aria-pressed": y === e,
							className: `fr-sheet-card ${y === e ? "fr-sheet-card--current" : ""}`,
							"aria-label": u(E.get(e)?.nameKey ?? "games.fantasyrealms.name"),
							children: /* @__PURE__ */ h(q, {
								id: e,
								size: "sm"
							})
						}, e))
					})
				})
			]
		})
	});
}
//#endregion
//#region src/games/fantasyrealms/bot.ts
function Pe(e, t) {
	let n = (e) => W(e, G(e, t, "fast")).total;
	if (e.length <= 7) return n(e);
	let r = -Infinity;
	for (let t of e) {
		let i = n(e.filter((e) => e !== t));
		i > r && (r = i);
	}
	return r;
}
function Fe(e, t) {
	let n = e[0], r = -Infinity;
	for (let i of e) {
		let a = e.filter((e) => e !== i), o = W(a, G(a, t, "fast")).total;
		o > r && (r = o, n = i);
	}
	return n;
}
function Ie(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Le = {
	sampleK: 12,
	takeDiscardBonus: 0
};
function Re(e = Le) {
	return (t, n) => {
		let r = t.public, i = t.private;
		if (!i) return null;
		let a = i.hand;
		if (r.phase === "declare") {
			if (i.myConfirmed) return null;
			if (n.difficulty === "weak") return { action: { type: "declareDone" } };
			let e = G(a, r.discard), t = i.myDecl;
			return Object.keys(e).every((n) => e[n] === t[n]) ? { action: { type: "declareDone" } } : { action: {
				type: "declare",
				decl: e
			} };
		}
		if (r.phase !== "play" || r.turn !== n.rid || !r.turnPhase) return null;
		if (r.turnPhase === "drop") return { action: {
			type: "drop",
			card: n.difficulty === "weak" ? Ie(a) : Fe(a, r.discard)
		} };
		if (n.difficulty === "weak") return r.discard.length > 0 && crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 2 == 0 ? { action: {
			type: "take",
			from: "discard",
			card: Ie(r.discard)
		} } : { action: {
			type: "take",
			from: "deck"
		} };
		let o = null, s = -Infinity;
		for (let e of r.discard) {
			let t = Pe([...a, e], r.discard.filter((t) => t !== e));
			t > s && (s = t, o = e);
		}
		let c = /* @__PURE__ */ new Set([...a, ...r.discard]), l = T.map((e) => e.id).filter((e) => !c.has(e)), u = Math.max(1, Math.floor(l.length / Math.max(1, e.sampleK))), d = l.filter((e, t) => t % u === 0).slice(0, e.sampleK), f = d.length > 0 ? d.reduce((e, t) => e + Pe([...a, t], r.discard), 0) / d.length : -Infinity;
		return o !== null && s + e.takeDiscardBonus >= f ? { action: {
			type: "take",
			from: "discard",
			card: o
		} } : { action: {
			type: "take",
			from: "deck"
		} };
	};
}
var ze = Re(), Be = (e, t, n) => {
	let r = (e) => n(E.get(e)?.nameKey ?? "games.fantasyrealms.name");
	return e.type === "take" ? e.from === "deck" ? n("games.fantasyrealms.deckTakeAria") : n("games.fantasyrealms.hintTakeDiscard", { card: r(e.card ?? "") }) : e.type === "drop" ? n("games.fantasyrealms.hintDrop", { card: r(e.card) }) : e.type === "declare" ? n("games.fantasyrealms.hintDeclare") : e.type === "declareDone" ? n("games.fantasyrealms.confirmDecl") : "";
};
//#endregion
//#region src/games/fantasyrealms/fx.tsx
function Y(e, t) {
	let n = document.querySelector(".fr-game"), r = t.startsWith("seat:") ? n?.querySelector(`[data-fr-seat="${CSS.escape(t.slice(5))}"]`)?.closest("li")?.firstElementChild : n?.querySelector(`[data-fr-anchor="${CSS.escape(t)}"]`);
	if (!(r instanceof HTMLElement)) return null;
	let i = r.getBoundingClientRect();
	if (i.width <= 0 || i.height <= 0 || i.left < -2 || i.top < -2 || i.right > window.innerWidth + 2 || i.bottom > window.innerHeight + 2) return null;
	for (let e = r.parentElement; e; e = e.parentElement) {
		let t = getComputedStyle(e), n = e.getBoundingClientRect(), r = n.left + e.clientLeft, a = n.top + e.clientTop;
		if (/(auto|scroll|hidden|clip)/.test(t.overflowX) && (i.left < r - 2 || i.right > r + e.clientWidth + 2) || /(auto|scroll|hidden|clip)/.test(t.overflowY) && (i.top < a - 2 || i.bottom > a + e.clientHeight + 2)) return null;
	}
	return e.anchor(t);
}
function X(e, t) {
	return t ? Y(e, `seat:${t}`) : null;
}
function Z(e, t) {
	let n = Math.min(e.w, e.h * t), r = n / t;
	return {
		x: e.x + (e.w - n) / 2,
		y: e.y + (e.h - r) / 2,
		w: n,
		h: r
	};
}
function Q({ from: e, to: t, ms: r, delay: a = 0, fade: o = !1, children: s }) {
	let c = i(null), l = document.querySelector(".fr-game")?.dataset.frWide === "true";
	return n(() => {
		let n = c.current;
		if (!n) return;
		let i = n.animate([
			{
				left: `${e.x}px`,
				top: `${e.y}px`,
				width: `${e.w}px`,
				height: `${e.h}px`,
				opacity: 1
			},
			{
				left: `${e.x + (t.x - e.x) * .55}px`,
				top: `${e.y + (t.y - e.y) * .55 - 14}px`,
				width: `${e.w + (t.w - e.w) * .55}px`,
				height: `${e.h + (t.h - e.h) * .55}px`,
				opacity: 1,
				offset: .55
			},
			{
				left: `${t.x}px`,
				top: `${t.y}px`,
				width: `${t.w}px`,
				height: `${t.h}px`,
				opacity: +!o
			}
		], {
			duration: r,
			delay: a,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => i.cancel();
	}, [
		e,
		t,
		r,
		a,
		o
	]), /* @__PURE__ */ h("div", {
		ref: c,
		className: "fr-skin fr-flight",
		"data-fr-wide": l,
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: s
	});
}
var Ve = {
	deal(e, t) {
		if (t.queued > 0) return null;
		let n = Y(t, "deck");
		if (!n) return null;
		let r = e.secret;
		if (r && Array.isArray(r.cards)) {
			let e = [], i = [];
			for (let [a, o] of r.cards.entries()) {
				let r = Y(t, `handCard:${o}`);
				r && (i.push(`handCard:${o}`), e.push(/* @__PURE__ */ h(Q, {
					from: n,
					to: r,
					ms: 300,
					delay: a * 50,
					children: /* @__PURE__ */ h(q, {
						id: o,
						size: "lg"
					})
				}, o)));
			}
			return e.length ? {
				ms: 300 + e.length * 50,
				node: e,
				hide: i
			} : null;
		}
		let i = X(t, e.rid);
		if (!i) return null;
		let a = e.data?.count, o = typeof a == "number" ? a : 7;
		return {
			ms: 300 + o * 50,
			node: Array.from({ length: o }, (e, t) => /* @__PURE__ */ h(Q, {
				from: n,
				to: Z(i, 58 / 86),
				fade: !0,
				ms: 300,
				delay: t * 50,
				children: /* @__PURE__ */ h(J, { size: "sm" })
			}, t))
		};
	},
	take(e, t) {
		if (t.queued > 0) return null;
		let n = e.data, r = e.secret;
		if (n?.from === "discard" && typeof n.card == "string") {
			let r = Y(t, `discardCard:${n.card}`), i = e.rid === t.myRid, a = i ? null : X(t, e.rid), o = i ? Y(t, `handCard:${n.card}`) : a ? Z(a, 58 / 86) : null;
			return !r || !o ? null : {
				ms: 320,
				node: /* @__PURE__ */ h(Q, {
					from: r,
					to: o,
					fade: !i,
					ms: 320,
					children: /* @__PURE__ */ h(q, {
						id: n.card,
						size: "sm"
					})
				}),
				hide: i ? [`handCard:${n.card}`] : void 0
			};
		}
		let i = Y(t, "deck");
		if (!i) return null;
		if (r && typeof r.card == "string") {
			let e = Y(t, `handCard:${r.card}`);
			return e ? {
				ms: 320,
				node: /* @__PURE__ */ h(Q, {
					from: i,
					to: e,
					ms: 320,
					children: /* @__PURE__ */ h(q, {
						id: r.card,
						size: "lg"
					})
				}),
				hide: [`handCard:${r.card}`]
			} : null;
		}
		let a = X(t, e.rid);
		return a ? {
			ms: 320,
			node: /* @__PURE__ */ h(Q, {
				from: i,
				to: Z(a, 58 / 86),
				fade: !0,
				ms: 320,
				children: /* @__PURE__ */ h(J, { size: "sm" })
			})
		} : null;
	},
	drop(e, t) {
		if (t.queued > 0) return null;
		let n = e.data;
		if (typeof n?.card != "string") return null;
		let r = X(t, e.rid), i = Y(t, `discardCard:${n.card}`);
		if (!r || !i) return null;
		let a = Z(r, i.w / i.h);
		return {
			ms: 320,
			node: /* @__PURE__ */ h(Q, {
				from: a,
				to: i,
				ms: 320,
				children: /* @__PURE__ */ h(q, {
					id: n.card,
					size: "sm"
				})
			}),
			hide: [`discardCard:${n.card}`]
		};
	},
	declareStart(e, t) {
		let n = Y(t, "table");
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ h(_, {
				at: n,
				ms: 700
			})
		} : null;
	}
};
//#endregion
//#region src/games/fantasyrealms/game-over-row.tsx
function He(e, t, n) {
	let r = 0, i = 1;
	for (let a = 1; a <= n; a++) {
		let o = Math.ceil(n / a), s = Math.min((e - (a - 1) * 12) / a, ((t - (o - 1) * 12) / o - 62) * 58 / 86);
		s > r && (r = s, i = a);
	}
	return r < 96 && (i = Math.max(1, Math.min(n, Math.floor((e + 12) / 108)))), {
		columns: i,
		width: Math.floor(Math.max(96, Math.min(320, r)) * 100) / 100
	};
}
function $({ hand: e, decl: t, scored: o, expanded: s = !1 }) {
	let l = c(), [u, d] = a(null), f = i(null), p = i(null), _ = r(() => o ?? W(e, t), [
		e,
		t,
		o
	]);
	return n(() => {
		let e = f.current, t = e?.querySelector(".fr-final-cards");
		if (!e || !t || !s) return;
		let n = () => {
			if (getComputedStyle(e).getPropertyValue("--fr-final-wide").trim() !== "1") {
				t.style.removeProperty("--fr-final-columns"), t.style.removeProperty("--fr-final-card-w");
				return;
			}
			let n = He(e.clientWidth - 16, e.clientHeight - 16, _.cards.length);
			t.style.setProperty("--fr-final-columns", String(n.columns)), t.style.setProperty("--fr-final-card-w", `${n.width}px`);
		};
		n();
		let r = new ResizeObserver(n);
		return r.observe(e), () => r.disconnect();
	}, [s, _.cards.length]), n(() => {
		let e = p.current;
		if (!e) return;
		let t = () => {
			e.dataset.frWide = String(e.clientWidth >= 960 && e.clientHeight >= 480 && e.clientWidth > e.clientHeight);
		};
		t();
		let n = new ResizeObserver(t);
		return n.observe(e), () => n.disconnect();
	}, [u]), /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("div", {
		ref: f,
		className: s ? "fr-final-scroll" : "overflow-x-auto",
		children: /* @__PURE__ */ h("div", {
			className: s ? "fr-final-cards" : "flex w-max gap-1.5 p-0.5",
			children: _.cards.map((t) => /* @__PURE__ */ g("div", {
				className: s ? "fr-final-tile" : "flex-none",
				children: [/* @__PURE__ */ h("button", {
					type: "button",
					"aria-label": `${l(E.get(t.nameId)?.nameKey ?? "games.fantasyrealms.name")} · ${t.total}`,
					onClick: () => d(t.id),
					className: "fr-final-card flex-none transition-transform active:translate-y-0.5",
					children: /* @__PURE__ */ h(q, {
						id: t.id,
						size: "sm",
						face: t,
						dimmed: t.blanked,
						badge: /* @__PURE__ */ h("span", {
							className: "fr-score-card__total font-mono tabular-nums",
							children: t.total
						})
					})
				}), s && /* @__PURE__ */ g("div", {
					className: "fr-final-math font-mono tabular-nums",
					children: [/* @__PURE__ */ h("span", { children: t.blanked ? l("games.fantasyrealms.blankedTag") : `${t.strength} + ${t.bonus} ${t.penalty < 0 ? "−" : "+"} ${Math.abs(t.penalty)} = ${t.total}` }), !e.includes(t.id) && /* @__PURE__ */ h("span", { children: l("games.fantasyrealms.fromDiscardTag") })]
				})]
			}, t.id))
		})
	}), u && E.get(u) && S(/* @__PURE__ */ h("div", {
		ref: p,
		className: "fr-skin fr-final-dialog fixed inset-0 z-40 flex items-end justify-center bg-ink/40",
		onClick: () => d(null),
		children: /* @__PURE__ */ h("div", {
			className: "fr-final-dialog__panel safe-b w-full max-w-md p-3",
			onClick: (e) => e.stopPropagation(),
			children: /* @__PURE__ */ h(_e, {
				id: u,
				decl: t,
				scored: _.cards.find((e) => e.id === u),
				onClose: () => d(null)
			})
		})
	}), document.body)] });
}
function Ue(e) {
	let t = e.public.final?.[e.rid];
	return t ? /* @__PURE__ */ h("div", {
		className: "fr-skin mt-1.5",
		children: /* @__PURE__ */ h($, {
			hand: t.hand,
			decl: t.decl
		})
	}) : null;
}
//#endregion
//#region src/games/fantasyrealms/game-over.tsx
function We({ result: e, public: t, members: o, myRid: l, onPlayAgain: d, onBackToLobby: f }) {
	let m = t, _ = c(), S = s((e) => e.locale), C = i(null), [w, T] = a(e.ranking.includes(l) ? l : e.ranking[0]), E = e.ranking.includes(w) ? w : e.ranking[0], D = m.final?.[E], O = r(() => Object.fromEntries(e.ranking.map((t) => {
		let n = m.final?.[t], r = n ? W(n.hand, n.decl) : null;
		return [t, {
			total: e.scores?.[t] ?? m.scores?.[t] ?? r?.total ?? 0,
			base: m.baseSums?.[t] ?? r?.baseSum ?? 0,
			count: r?.cards.length ?? 0,
			scored: r
		}];
	})), [
		e.ranking,
		e.scores,
		m.final,
		m.scores,
		m.baseSums
	]), k = (e) => {
		let t = o.find((t) => t.rid === e);
		return t ? p(t, S) : e;
	};
	return n(() => {
		let t = C.current, n = t?.querySelector(".fr-over-main"), r = t?.querySelector(".fr-over-ranking");
		if (!t || !n || !r) return;
		let i = () => {
			let i = getComputedStyle(n).getPropertyValue("--fr-over-wide").trim() === "1";
			t.dataset.frWide = String(i), i ? r.style.setProperty("--fr-rank-height", `${Math.max(100, Math.floor((n.clientHeight - (e.ranking.length - 1) * 10) / Math.max(1, e.ranking.length)))}px`) : r.style.removeProperty("--fr-rank-height");
		};
		i();
		let a = new ResizeObserver(i);
		return a.observe(t), a.observe(n), () => a.disconnect();
	}, [e.ranking.length, S]), /* @__PURE__ */ g("div", {
		ref: C,
		className: "fr-skin fr-over",
		children: [e.winner.length > 0 && /* @__PURE__ */ h(x, {}), /* @__PURE__ */ h(u, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ h("header", {
				className: "fr-over-heading",
				children: /* @__PURE__ */ h("h1", { children: _("games.fantasyrealms.resultTitle") })
			}),
			actionsHeight: "fr-over-actions-height",
			actions: d || f ? /* @__PURE__ */ g("div", {
				className: "fr-over-actions",
				children: [d && /* @__PURE__ */ h("button", {
					type: "button",
					onClick: d,
					children: _("session.result.playAgain")
				}), f && /* @__PURE__ */ h("button", {
					type: "button",
					onClick: f,
					children: _("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ h("p", {
				className: "fr-over-wait",
				children: _("session.result.waitHost")
			}),
			children: /* @__PURE__ */ g("div", {
				className: "fr-over-main",
				"data-has-realm": !!D,
				children: [/* @__PURE__ */ h("ol", {
					className: "fr-over-ranking",
					"aria-label": _("games.fantasyrealms.resultRanking"),
					children: e.ranking.map((t) => {
						let n = o.find((e) => e.rid === t), { total: r, base: i } = O[t], a = e.ranking.findIndex((e) => O[e].total === r && O[e].base === i) + 1, s = e.autopilot?.[t];
						return /* @__PURE__ */ h("li", { children: /* @__PURE__ */ g("button", {
							type: "button",
							className: "fr-over-player",
							"data-winner": e.winner.includes(t),
							"aria-pressed": E === t,
							onClick: () => T(t),
							children: [
								/* @__PURE__ */ h("span", {
									className: "fr-over-rank",
									"aria-label": _("games.fantasyrealms.resultRank", { n: a }),
									children: a
								}),
								/* @__PURE__ */ h("span", {
									className: "fr-over-avatar",
									style: { background: b[(n?.colorIndex ?? 0) % b.length].hex },
									children: n && /* @__PURE__ */ h("img", {
										src: v[n.avatar % v.length],
										alt: "",
										draggable: !1
									})
								}),
								/* @__PURE__ */ g("span", {
									className: "fr-over-person",
									children: [/* @__PURE__ */ h("strong", {
										title: k(t),
										children: k(t)
									}), /* @__PURE__ */ g("span", {
										className: "fr-over-flags",
										children: [t === l && /* @__PURE__ */ h("span", { children: _("lobby.you") }), e.winner.includes(t) && /* @__PURE__ */ h("b", { children: _("games.fantasyrealms.resultWinner") })]
									})]
								}),
								/* @__PURE__ */ g("span", {
									className: "fr-over-score",
									children: [/* @__PURE__ */ h("small", { children: _("games.fantasyrealms.resultTotal") }), /* @__PURE__ */ h("strong", {
										className: "font-mono tabular-nums",
										children: r
									})]
								}),
								/* @__PURE__ */ g("span", {
									className: "fr-over-base",
									children: [
										_("games.fantasyrealms.resultBase"),
										" ",
										/* @__PURE__ */ h("b", {
											className: "font-mono tabular-nums",
											children: i
										})
									]
								}),
								s !== void 0 && s > 0 && /* @__PURE__ */ g("span", {
									className: "fr-over-bot",
									children: [/* @__PURE__ */ h(y, { size: 16 }), _("session.autopilot.share", { n: Math.round(s * 100) })]
								})
							]
						}) }, t);
					})
				}), D && /* @__PURE__ */ g("section", {
					className: "fr-over-realm",
					children: [/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("h2", { children: _("games.fantasyrealms.resultRealm", { name: k(E) }) }), /* @__PURE__ */ h("span", { children: _("games.fantasyrealms.resultCards", { n: O[E].count }) })] }), /* @__PURE__ */ h($, {
						hand: D.hand,
						decl: D.decl,
						scored: O[E].scored ?? void 0,
						expanded: !0
					}, E)]
				})]
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/fantasyrealms/entry.tsx
var Ge = {
	definition: de,
	View: we,
	bot: ze,
	describe: Be,
	fx: Ve,
	OverView: We,
	RowView: Ue,
	locales: {
		zh: {
			name: "幻想国度",
			desc: "抽牌换牌凑连锁,搭出得分最高的幻想国度",
			rules: "目标:不断抽牌换牌,终局时让 7 张手牌的总分最高。\n流程:\n· 轮到你时,从牌堆顶抽 1 张,或从弃牌区(全部公开)任取 1 张。\n· 然后弃 1 张牌到弃牌区。\n· 弃牌区满 10 张时进入理牌阶段。\n理牌:\n· 部分牌需要指定效果对象:分身灵、幻象、变形者、变化之书、孤岛、死灵法师。\n· 效果对象可反复调整,也可用「一键最优」。\n· 所有人确认后结算。\n计分:\n· 每张卡牌的分数等于其基础分加上奖励分，再扣除惩罚分。被“移除”的卡牌计0分。\n· 总分最高的玩家获胜；总分相同时，手牌基础分总和较低的玩家获胜。",
			takePrompt: "轮到你：从牌堆或弃牌区取牌",
			takeWaiting: "等 {{name}} 行动…",
			dropPrompt: "点一张手牌弃掉",
			turnPlaque: "本回合",
			chooseCard: "选 1 张，构筑你的国度",
			takeSources: "牌堆未知 · 弃牌公开",
			dropSource: "从手牌中弃 1 张",
			waitTable: "等待下一步",
			waitSource: "公开弃牌仍可查看",
			discardTakeHint: "可从这里拿牌",
			handLabel: "你的国度 · {{n}} 张手牌",
			handSwipe: "左右滑动 ›",
			scoreTable: "国度计分",
			configure: "设置效果",
			configured: "已设置",
			declarePrompt: "理牌：设置效果后确认",
			waitingConfirm: "已确认,等其他人理牌…",
			doneText: "计分完成",
			discardChip: "弃牌 {{n}}/{{total}}",
			confirmChip: "已确认 {{n}}/{{total}}",
			deckCount: "牌堆 {{n}}",
			deckTakeAria: "从牌堆抽一张牌",
			discardArea: "弃牌区",
			discardEmpty: "等待首张弃牌",
			takeThis: "拿这张",
			dropThis: "弃这张",
			close: "关闭",
			totalLabel: "当前总分",
			autoBest: "一键最优",
			confirmDecl: "确认声明",
			confirmedTag: "已确认",
			blankedTag: "被移除",
			fromDiscardTag: "取自弃牌区",
			declTarget: "当前目标:{{name}}",
			declTargetBook: "当前目标:{{name}} → {{suit}}",
			declTargetNone: "当前目标:未设置",
			chooseTargetAgain: "重新选择目标",
			resultTitle: "国度终局",
			resultRanking: "最终排名",
			resultRank: "第 {{n}} 名",
			resultWinner: "获胜",
			resultTotal: "总分",
			resultBase: "基础分总和",
			resultRealm: "{{name}}的国度",
			resultCards: "{{n}} 张牌",
			errNotYourTurn: "现在轮不到你",
			errBadTake: "这张牌不能拿",
			errBadDrop: "这张牌不在你手里",
			errBadDecl: "声明不合法或已确认",
			suit: {
				army: "军队",
				leader: "领袖",
				wizard: "法师",
				weapon: "武器",
				artifact: "神器",
				beast: "野兽",
				land: "大地",
				weather: "气象",
				flood: "洪水",
				flame: "火焰",
				wild: "百搭"
			},
			actionNone: {
				doppel: "不复制",
				mirage: "不变身",
				shifter: "不变身",
				book: "不改花色",
				island: "不使用",
				necro: "不取牌"
			},
			actionTitle: {
				doppel: "分身灵:复制哪张牌?",
				mirage: "幻象:变成哪张牌?",
				shifter: "变形者:变成哪张牌?",
				book: "变化之书:先选目标牌,再选花色",
				island: "孤岛:清除哪张牌的惩罚?",
				necro: "死灵法师:从弃牌区取哪张?"
			},
			cards: {
				FR01: "山脉",
				FR02: "洞穴",
				FR03: "钟楼",
				FR04: "森林",
				FR05: "土元素",
				FR06: "生命之泉",
				FR07: "沼泽",
				FR08: "大洪水",
				FR09: "孤岛",
				FR10: "水元素",
				FR11: "暴雨",
				FR12: "暴风雪",
				FR13: "浓烟",
				FR14: "旋风",
				FR15: "气元素",
				FR16: "野火",
				FR17: "蜡烛",
				FR18: "锻炉",
				FR19: "闪电",
				FR20: "火元素",
				FR21: "骑士团",
				FR22: "精灵弓手",
				FR23: "轻骑兵",
				FR24: "矮人步兵",
				FR25: "游侠",
				FR26: "收藏家",
				FR27: "驯兽师",
				FR28: "死灵法师",
				FR29: "术士领主",
				FR30: "女巫",
				FR31: "国王",
				FR32: "王后",
				FR33: "公主",
				FR34: "军阀",
				FR35: "女皇",
				FR36: "独角兽",
				FR37: "蛇怪",
				FR38: "战马",
				FR39: "巨龙",
				FR40: "九头蛇",
				FR41: "战舰",
				FR42: "魔杖",
				FR43: "凯斯之剑",
				FR44: "精灵长弓",
				FR45: "战斗飞艇",
				FR46: "凯斯之盾",
				FR47: "秩序宝石",
				FR48: "世界树",
				FR49: "变化之书",
				FR50: "守护符文",
				FR51: "变形者",
				FR52: "幻象",
				FR53: "分身灵"
			},
			effects: {
				FR01: "与浓烟和野火同在手牌时 +50;清除所有洪水牌的惩罚。",
				FR02: "与矮人步兵或巨龙同在手牌时 +25;清除所有气象牌的惩罚。",
				FR03: "与任一法师同在手牌时 +15。",
				FR04: "手牌中每张野兽牌 +12;与精灵弓手同在时 +12。",
				FR05: "手牌中每另一张大地牌 +15。",
				FR06: "获得手牌中武器/洪水/火焰/大地/气象牌里最高的基础分作为奖励。",
				FR07: "手牌中每张军队和火焰牌 −3。",
				FR08: "移除所有军队牌、除山脉外所有大地牌、除闪电外所有火焰牌。",
				FR09: "动作:清除手牌中一张洪水或火焰牌的惩罚。",
				FR10: "手牌中每另一张洪水牌 +15。",
				FR11: "手牌中每张洪水牌 +10;移除除闪电外所有火焰牌。",
				FR12: "手牌中每张领袖、野兽、火焰、军队牌 −5;移除所有洪水牌。",
				FR13: "手牌中没有火焰牌时被移除。",
				FR14: "与暴雨同在,且与暴风雪或大洪水同在手牌时 +40。",
				FR15: "手牌中每另一张气象牌 +15。",
				FR16: "移除所有非火焰/法师/气象/武器/神器/百搭的牌;山脉、大洪水、孤岛、独角兽、巨龙除外。",
				FR17: "与变化之书、钟楼和任一法师同在手牌时 +100。",
				FR18: "手牌中每张武器和神器牌 +9。",
				FR19: "与暴雨同在手牌时 +30。",
				FR20: "手牌中每另一张火焰牌 +15。",
				FR21: "手牌中没有领袖牌时 −8。",
				FR22: "手牌中没有气象牌时 +5。",
				FR23: "手牌中每张大地牌 −2。",
				FR24: "手牌中每另一张军队牌 −2。",
				FR25: "手牌中每张大地牌 +10;从所有牌的惩罚中清除「军队」一词。",
				FR26: "每个花色:集齐 3 张 +10,4 张 +40,5 张及以上 +100。",
				FR27: "手牌中每张野兽牌 +9;清除所有野兽牌的惩罚。",
				FR28: "动作:终局时从弃牌区取一张军队/领袖/法师/野兽牌加入手牌。",
				FR29: "手牌中每张领袖牌和每另一张法师牌 −10。",
				FR30: "手牌中每张大地、气象、洪水、火焰牌 +5。",
				FR31: "手牌中每张军队牌 +5;若与王后同在则每张 +20。",
				FR32: "手牌中每张军队牌 +5;若与国王同在则每张 +20。",
				FR33: "手牌中每张军队、法师和其他领袖牌 +8。",
				FR34: "获得手牌中所有军队牌基础分之和作为奖励。",
				FR35: "手牌中每张军队牌 +10;每另一张领袖牌 −5。",
				FR36: "与公主同在手牌时 +30;或与女皇、王后、女巫任一同在时 +15。",
				FR37: "移除所有军队、领袖和其他野兽牌。",
				FR38: "与任一领袖或法师同在手牌时 +14。",
				FR39: "手牌中没有法师牌时 −40。",
				FR40: "与沼泽同在手牌时 +28。",
				FR41: "手牌中没有洪水牌时被移除;从所有洪水牌的惩罚中清除「军队」一词。",
				FR42: "与任一法师同在手牌时 +25。",
				FR43: "手牌中有领袖牌时 +10;若再有凯斯之盾则改为 +40。",
				FR44: "与精灵弓手、军阀或驯兽师任一同在手牌时 +30。",
				FR45: "手牌中没有军队牌,或有气象牌时被移除。",
				FR46: "手牌中有领袖牌时 +15;若再有凯斯之剑则改为 +40。",
				FR47: "手牌中基础分连续的牌组成连龙:3 连 +10,4 连 +30,5 连 +60,6 连 +100,7 连及以上 +150;可有多组。",
				FR48: "手牌中未被移除的牌花色全不相同时 +50。",
				FR49: "动作:改变手牌中一张牌的花色(名字不变)。",
				FR50: "清除所有牌的惩罚。",
				FR51: "动作:变身为任一神器/领袖/法师/武器/野兽牌(获得其名与花色,基础分恒为 0)。",
				FR52: "动作:变身为任一军队/大地/气象/洪水/火焰牌(获得其名与花色,基础分恒为 0)。",
				FR53: "动作:复制手牌中另一张牌的名字、花色、基础分与惩罚。"
			},
			hintTakeDiscard: "从弃牌区拿走{{card}}",
			hintDrop: "弃掉{{card}}",
			hintDeclare: "按推荐设置动作牌"
		},
		en: {
			name: "Fantasy Realms",
			desc: "Draw and swap cards to build the highest-scoring realm",
			rules: "Goal: Keep drawing and swapping so your 7-card hand scores the most at the end.\nFlow:\n· On your turn, draw the top card of the deck, or take any one card from the face-up discard area.\n· Then discard one card onto the discard area.\n· When the discard area reaches 10 cards, scoring begins.\nScoring setup:\n· Some cards need a target: Doppelgänger, Mirage, Shapeshifter, Book of Changes, Island, Necromancer.\n· Targets can be adjusted freely, or use \"Best pick\".\n· The game settles once everyone confirms.\nScoring:\n· Each card scores its base value plus bonuses, minus penalties. Blanked cards score 0 points.\n· Highest total wins; ties go to the lower base-value sum.",
			takePrompt: "Choose deck or discard",
			takeWaiting: "Waiting for {{name}}…",
			dropPrompt: "Discard 1 hand card",
			turnPlaque: "This turn",
			chooseCard: "Choose 1 card for your realm",
			takeSources: "Deck is hidden · discard is open",
			dropSource: "Discard 1 card from your hand",
			waitTable: "Waiting for the next move",
			waitSource: "You can inspect the open discard",
			discardTakeHint: "Take a card from here",
			handLabel: "Your realm · {{n}} cards",
			handSwipe: "Swipe to see all ›",
			scoreTable: "Realm scoring",
			configure: "Set effect",
			configured: "Set",
			declarePrompt: "Set effects, then confirm",
			waitingConfirm: "Confirmed, waiting for others…",
			doneText: "Scoring complete",
			discardChip: "Discard {{n}}/{{total}}",
			confirmChip: "Confirmed {{n}}/{{total}}",
			deckCount: "Deck {{n}}",
			deckTakeAria: "Draw a card from the deck",
			discardArea: "Discard area",
			discardEmpty: "Waiting for the first discard",
			takeThis: "Take this",
			dropThis: "Discard this",
			close: "Close",
			totalLabel: "Current total",
			autoBest: "Best pick",
			confirmDecl: "Confirm",
			confirmedTag: "Confirmed",
			blankedTag: "Blanked",
			fromDiscardTag: "from discard",
			declTarget: "Target: {{name}}",
			declTargetBook: "Target: {{name}} → {{suit}}",
			declTargetNone: "Target: not set",
			chooseTargetAgain: "Choose another target",
			resultTitle: "Final realms",
			resultRanking: "Final ranking",
			resultRank: "Rank {{n}}",
			resultWinner: "Winner",
			resultTotal: "Total",
			resultBase: "Base-value sum",
			resultRealm: "{{name}}’s realm",
			resultCards: "{{n}} cards",
			errNotYourTurn: "Not your turn",
			errBadTake: "You can't take that card",
			errBadDrop: "That card is not in your hand",
			errBadDecl: "Invalid declaration or already confirmed",
			suit: {
				army: "Army",
				leader: "Leader",
				wizard: "Wizard",
				weapon: "Weapon",
				artifact: "Artifact",
				beast: "Beast",
				land: "Land",
				weather: "Weather",
				flood: "Flood",
				flame: "Flame",
				wild: "Wild"
			},
			actionNone: {
				doppel: "No copy",
				mirage: "No transform",
				shifter: "No transform",
				book: "No change",
				island: "Not used",
				necro: "No take"
			},
			actionTitle: {
				doppel: "Doppelgänger: copy which card?",
				mirage: "Mirage: become which card?",
				shifter: "Shapeshifter: become which card?",
				book: "Book of Changes: pick a card, then a suit",
				island: "Island: clear penalty from which card?",
				necro: "Necromancer: take which card from the discard?"
			},
			cards: {
				FR01: "Mountain",
				FR02: "Cavern",
				FR03: "Bell Tower",
				FR04: "Forest",
				FR05: "Earth Elemental",
				FR06: "Fountain of Life",
				FR07: "Swamp",
				FR08: "Great Flood",
				FR09: "Island",
				FR10: "Water Elemental",
				FR11: "Rainstorm",
				FR12: "Blizzard",
				FR13: "Smoke",
				FR14: "Whirlwind",
				FR15: "Air Elemental",
				FR16: "Wildfire",
				FR17: "Candle",
				FR18: "Forge",
				FR19: "Lightning",
				FR20: "Fire Elemental",
				FR21: "Knights",
				FR22: "Elven Archers",
				FR23: "Light Cavalry",
				FR24: "Dwarvish Infantry",
				FR25: "Rangers",
				FR26: "Collector",
				FR27: "Beastmaster",
				FR28: "Necromancer",
				FR29: "Warlock Lord",
				FR30: "Enchantress",
				FR31: "King",
				FR32: "Queen",
				FR33: "Princess",
				FR34: "Warlord",
				FR35: "Empress",
				FR36: "Unicorn",
				FR37: "Basilisk",
				FR38: "Warhorse",
				FR39: "Dragon",
				FR40: "Hydra",
				FR41: "Warship",
				FR42: "Magic Wand",
				FR43: "Sword of Keth",
				FR44: "Elven Longbow",
				FR45: "War Dirigible",
				FR46: "Shield of Keth",
				FR47: "Gem of Order",
				FR48: "World Tree",
				FR49: "Book of Changes",
				FR50: "Protection Rune",
				FR51: "Shapeshifter",
				FR52: "Mirage",
				FR53: "Doppelgänger"
			},
			effects: {
				FR01: "+50 with Smoke and Wildfire. Clears the penalty on all Floods.",
				FR02: "+25 with Dwarvish Infantry or Dragon. Clears the penalty on all Weathers.",
				FR03: "+15 with any Wizard.",
				FR04: "+12 for each Beast. +12 with Elven Archers.",
				FR05: "+15 for each other Land.",
				FR06: "Bonus equal to the highest base value among your Weapons, Floods, Flames, Lands and Weathers.",
				FR07: "−3 for each Army and Flame.",
				FR08: "Blanks all Armies, all Lands except Mountain, and all Flames except Lightning.",
				FR09: "Action: clear the penalty on one Flood or Flame.",
				FR10: "+15 for each other Flood.",
				FR11: "+10 for each Flood. Blanks all Flames except Lightning.",
				FR12: "−5 for each Leader, Beast, Flame and Army. Blanks all Floods.",
				FR13: "Blanked unless you hold a Flame.",
				FR14: "+40 with Rainstorm and either Blizzard or Great Flood.",
				FR15: "+15 for each other Weather.",
				FR16: "Blanks all cards except Flames, Wizards, Weathers, Weapons, Artifacts, Wilds, Mountain, Great Flood, Island, Unicorn and Dragon.",
				FR17: "+100 with Book of Changes, Bell Tower and any Wizard.",
				FR18: "+9 for each Weapon and Artifact.",
				FR19: "+30 with Rainstorm.",
				FR20: "+15 for each other Flame.",
				FR21: "−8 if you hold no Leader.",
				FR22: "+5 if you hold no Weather.",
				FR23: "−2 for each Land.",
				FR24: "−2 for each other Army.",
				FR25: "+10 for each Land. Clears the word \"Army\" from all penalties.",
				FR26: "For each suit: 3 cards +10, 4 cards +40, 5 or more +100.",
				FR27: "+9 for each Beast. Clears the penalty on all Beasts.",
				FR28: "Action: at the end, take one Army/Leader/Wizard/Beast from the discard into your hand.",
				FR29: "−10 for each Leader and each other Wizard.",
				FR30: "+5 for each Land, Weather, Flood and Flame.",
				FR31: "+5 for each Army, or +20 each with Queen.",
				FR32: "+5 for each Army, or +20 each with King.",
				FR33: "+8 for each Army, Wizard and other Leader.",
				FR34: "Bonus equal to the sum of the base values of all your Armies.",
				FR35: "+10 for each Army. −5 for each other Leader.",
				FR36: "+30 with Princess, or +15 with Empress, Queen or Enchantress.",
				FR37: "Blanks all Armies, Leaders and other Beasts.",
				FR38: "+14 with any Leader or Wizard.",
				FR39: "−40 if you hold no Wizard.",
				FR40: "+28 with Swamp.",
				FR41: "Blanked if you hold no Flood. Clears the word \"Army\" from the penalty on all Floods.",
				FR42: "+25 with any Wizard.",
				FR43: "+10 with a Leader in hand, or +40 instead with Shield of Keth.",
				FR44: "+30 with Elven Archers, Warlord or Beastmaster.",
				FR45: "Blanked if you hold no Army or hold any Weather.",
				FR46: "+15 with a Leader in hand, or +40 instead with Sword of Keth.",
				FR47: "Runs of consecutive base values in hand: 3-run +10, 4-run +30, 5-run +60, 6-run +100, 7+ +150. Multiple runs allowed.",
				FR48: "+50 if all unblanked cards in hand have different suits.",
				FR49: "Action: change one hand card's suit (name unchanged).",
				FR50: "Clears the penalty on all cards.",
				FR51: "Action: become any Artifact/Leader/Wizard/Weapon/Beast (name and suit only; base stays 0).",
				FR52: "Action: become any Army/Land/Weather/Flood/Flame (name and suit only; base stays 0).",
				FR53: "Action: copy another hand card's name, suit, base value and penalty."
			},
			hintTakeDiscard: "Take {{card}} from the discard area",
			hintDrop: "Discard {{card}}",
			hintDeclare: "Set action cards as recommended"
		}
	}
};
//#endregion
export { Ge as default };
