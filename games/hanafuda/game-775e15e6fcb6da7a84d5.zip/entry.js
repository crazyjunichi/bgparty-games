import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { useT as c } from "@bgparty/sdk/i18n";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as u } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as v } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as y, OptionSection as ee } from "@bgparty/sdk/ui/game-options";
//#region src/games/hanafuda/cards.ts
var b = {
	1: [
		"bright",
		"tanzaku",
		"kasu",
		"kasu"
	],
	2: [
		"tane",
		"tanzaku",
		"kasu",
		"kasu"
	],
	3: [
		"bright",
		"tanzaku",
		"kasu",
		"kasu"
	],
	4: [
		"tane",
		"tanzaku",
		"kasu",
		"kasu"
	],
	5: [
		"tane",
		"tanzaku",
		"kasu",
		"kasu"
	],
	6: [
		"tane",
		"tanzaku",
		"kasu",
		"kasu"
	],
	7: [
		"tane",
		"tanzaku",
		"kasu",
		"kasu"
	],
	8: [
		"bright",
		"tane",
		"kasu",
		"kasu"
	],
	9: [
		"tane",
		"tanzaku",
		"kasu",
		"kasu"
	],
	10: [
		"tane",
		"tanzaku",
		"kasu",
		"kasu"
	],
	11: [
		"bright",
		"tane",
		"tanzaku",
		"kasu"
	],
	12: [
		"bright",
		"kasu",
		"kasu",
		"kasu"
	]
}, x = {
	bright: 20,
	tane: 10,
	tanzaku: 5,
	kasu: 1
}, S = /* @__PURE__ */ new Set([
	1,
	2,
	3
]), C = /* @__PURE__ */ new Set([
	6,
	9,
	10
]), te = /* @__PURE__ */ new Set([
	20,
	24,
	36
]);
function w() {
	let e = [];
	for (let t = 1; t <= 12; t += 1) for (let [n, r] of b[t].entries()) {
		let i = (t - 1) * 4 + n;
		e.push({
			month: t,
			kind: r,
			points: x[r],
			isRain: i === 40,
			isMoon: i === 28,
			isCurtain: i === 8,
			isSakeCup: i === 32,
			isInoShikaCho: te.has(i),
			tanzaku: r === "tanzaku" ? S.has(t) ? "red" : C.has(t) ? "blue" : "plain" : null
		});
	}
	return e;
}
var T = w();
function E(e) {
	return T[e];
}
function ne(e) {
	let t = Math.floor(e / 4) + 1, n = e % 4 + 1;
	return `games/hanafuda/cards/m${String(t).padStart(2, "0")}-${n}.webp`;
}
var D = "games/hanafuda/cards/back.webp", O = /* @__PURE__ */ new Set([
	4,
	5,
	7,
	12
]), re = Array.from({ length: 48 }, (e, t) => t);
//#endregion
//#region src/games/hanafuda/yaku.ts
function k(e) {
	return e.map((e) => ({
		key: e.key,
		points: e.points
	}));
}
function A(e, t) {
	let n = {
		brights: [],
		tanes: [],
		tanzakus: [],
		kasus: [],
		redTan: [],
		blueTan: [],
		hasRain: !1,
		hasMoon: !1,
		hasCurtain: !1,
		hasCup: !1,
		inoShikaCho: 0,
		nonWillowTan: [],
		months: /* @__PURE__ */ new Map()
	}, r = {};
	for (let i of e) {
		let e = E(i), a = e.kind;
		t && e.month === 11 && (a = "kasu"), r[i] = a, a === "bright" && n.brights.push(i), a === "tane" && n.tanes.push(i), a === "tanzaku" && n.tanzakus.push(i), a === "kasu" && n.kasus.push(i), e.isSakeCup && (n.tanes.push(i), n.kasus.push(i)), e.tanzaku === "red" && n.redTan.push(i), e.tanzaku === "blue" && n.blueTan.push(i), e.isRain && (n.hasRain = !0), e.isMoon && (n.hasMoon = !0), e.isCurtain && (n.hasCurtain = !0), e.isSakeCup && (n.hasCup = !0), e.isInoShikaCho && (n.inoShikaCho += 1), a === "tanzaku" && e.month !== 11 && n.nonWillowTan.push(i);
		let o = n.months.get(e.month);
		o ? o.push(i) : n.months.set(e.month, [i]);
	}
	return n;
}
function j(e) {
	return {
		list: e,
		total: e.reduce((e, t) => e + t.points, 0)
	};
}
function M(e) {
	let t = A(e, !1), n = [], r = t.brights.length;
	return r === 5 ? n.push({
		key: "games.hanafuda.yaku.goko",
		points: 10
	}) : r === 4 && t.hasRain ? n.push({
		key: "games.hanafuda.yaku.ameshiko",
		points: 7
	}) : r === 4 ? n.push({
		key: "games.hanafuda.yaku.shiko",
		points: 8
	}) : r === 3 && !t.hasRain && n.push({
		key: "games.hanafuda.yaku.sanko",
		points: 5
	}), t.inoShikaCho === 3 && n.push({
		key: "games.hanafuda.yaku.inoshikacho",
		points: 5
	}), t.redTan.length === 3 && n.push({
		key: "games.hanafuda.yaku.akatan",
		points: 5
	}), t.blueTan.length === 3 && n.push({
		key: "games.hanafuda.yaku.aotan",
		points: 5
	}), t.hasCurtain && t.hasCup && n.push({
		key: "games.hanafuda.yaku.hanami",
		points: 5
	}), t.hasMoon && t.hasCup && n.push({
		key: "games.hanafuda.yaku.tsukimi",
		points: 5
	}), t.tanes.length >= 5 && n.push({
		key: "games.hanafuda.yaku.tane",
		points: t.tanes.length - 4
	}), t.tanzakus.length >= 5 && n.push({
		key: "games.hanafuda.yaku.tan",
		points: t.tanzakus.length - 4
	}), t.kasus.length >= 10 && n.push({
		key: "games.hanafuda.yaku.kasu",
		points: t.kasus.length - 9
	}), j(n);
}
function ie(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = E(n).month;
		t.set(e, (t.get(e) ?? 0) + 1);
	}
	let n = [...t.values()].sort((e, t) => t - e);
	return n[0] === 4 ? "teshi" : n.length === 4 && n.every((e) => e === 2) ? "kuttsuki" : null;
}
function ae(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = E(n).month, r = (t.get(e) ?? 0) + 1;
		if (r === 4) return !0;
		t.set(e, r);
	}
	return !1;
}
function N(e) {
	let t = A(e, !1), n = [], r = t.brights.length, i = (t) => e.includes(t);
	r === 5 ? n.push({
		key: "games.hanafuda.yaku.goko",
		points: 200
	}) : (r === 4 && !t.hasRain && n.push({
		key: "games.hanafuda.yaku.shiko",
		points: 60
	}), i(0) && i(28) && i(44) && n.push({
		key: "games.hanafuda.yaku.shoto",
		points: 20
	})), t.redTan.length === 3 && n.push({
		key: "games.hanafuda.yaku.akatan",
		points: 40
	}), t.blueTan.length === 3 && n.push({
		key: "games.hanafuda.yaku.aotan",
		points: 40
	});
	let a = t.nonWillowTan.length >= 7, o = !a && t.nonWillowTan.length === 6;
	a ? n.push({
		key: "games.hanafuda.yaku.nanatan",
		points: 40
	}) : o && n.push({
		key: "games.hanafuda.yaku.rokutan",
		points: 30
	}), !a && i(0) && i(4) && i(8) && n.push({
		key: "games.hanafuda.yaku.omote",
		points: 30
	}), t.hasCurtain && t.hasMoon && t.hasCup && n.push({
		key: "games.hanafuda.yaku.nomi",
		points: 30
	}), t.inoShikaCho === 3 && n.push({
		key: "games.hanafuda.yaku.inoshikacho",
		points: 20
	}), t.hasCurtain && t.hasCup && n.push({
		key: "games.hanafuda.yaku.hanami",
		points: 20
	}), t.hasMoon && t.hasCup && n.push({
		key: "games.hanafuda.yaku.tsukimi",
		points: 20
	}), i(17) && i(21) && i(25) && n.push({
		key: "games.hanafuda.yaku.kusa",
		points: 20
	});
	for (let [e, r] of [
		[4, "games.hanafuda.yaku.fujishima"],
		[12, "games.hanafuda.yaku.kirishima"],
		[11, "games.hanafuda.yaku.ameshima"]
	]) (t.months.get(e)?.length ?? 0) === 4 && n.push({
		key: r,
		points: 20
	});
	return j(n);
}
function P(e) {
	let t = A(e, !0), n = [], r = t.brights.length;
	return r === 5 ? n.push({
		key: "games.hanafuda.yaku.goko",
		points: 12
	}) : r === 4 && !t.hasRain && n.push({
		key: "games.hanafuda.yaku.shiko",
		points: 10
	}), t.redTan.length === 3 && n.push({
		key: "games.hanafuda.yaku.akatan",
		points: 7
	}), t.blueTan.length === 3 && n.push({
		key: "games.hanafuda.yaku.aotan",
		points: 7
	}), t.nonWillowTan.length >= 7 && n.push({
		key: "games.hanafuda.yaku.nanatan",
		points: 10
	}), t.kasus.length >= 16 && n.push({
		key: "games.hanafuda.yaku.kasuju",
		points: 12 + (t.kasus.length - 16)
	}), j(n);
}
function oe(e, t) {
	let n = A(e, !0), r = [], i = [...n.months.values()].map((e) => e.length).sort((e, t) => t - e).join(",");
	if (i === "4,3") r.push({
		key: "games.hanafuda.teyaku.shiso",
		points: 20
	});
	else if (i === "4,2,1") r.push({
		key: "games.hanafuda.teyaku.ichiyon",
		points: 8
	});
	else if (i === "4,1,1,1") r.push({
		key: "games.hanafuda.teyaku.teshi",
		points: 6
	});
	else if (i === "3,3,1") r.push({
		key: "games.hanafuda.teyaku.futasam",
		points: 6
	});
	else if (i === "3,2,2") r.push({
		key: "games.hanafuda.teyaku.haneken",
		points: 7
	});
	else if (i === "3,1,1,1,1") {
		let e = [...n.months.entries()].find(([, e]) => e.length === 3)[0];
		r.push(O.has(e) ? {
			key: "games.hanafuda.teyaku.tachisam",
			points: 3
		} : {
			key: "games.hanafuda.teyaku.sampon",
			points: 2
		});
	} else i === "2,2,2,1" && r.push({
		key: "games.hanafuda.teyaku.kuttsuki",
		points: 4
	});
	let a = /* @__PURE__ */ new Map();
	for (let e of t) {
		let t = E(e).month;
		a.set(t, (a.get(t) ?? 0) + 1);
	}
	for (let [e, t] of n.months) if (t.length === 1 && a.get(e) === 3) {
		r.push(O.has(e) ? {
			key: "games.hanafuda.teyaku.mukotachi",
			points: 3
		} : {
			key: "games.hanafuda.teyaku.mukosam",
			points: 2
		});
		break;
	}
	let o = e.length;
	return n.kasus.length === o ? r.push({
		key: "games.hanafuda.teyaku.karasu",
		points: 4
	}) : n.kasus.length === 0 ? r.push({
		key: "games.hanafuda.teyaku.sunashi",
		points: 4
	}) : (n.brights.length === 1 && n.tanes.length === 0 && n.tanzakus.length === 0 && r.push({
		key: "games.hanafuda.teyaku.pikaichi",
		points: 4
	}), n.tanes.length === 1 && n.brights.length === 0 && n.tanzakus.length === 0 && r.push({
		key: "games.hanafuda.teyaku.toichi",
		points: 3
	}), n.tanzakus.length === 1 && n.brights.length === 0 && n.tanes.length === 0 && r.push({
		key: "games.hanafuda.teyaku.tanichi",
		points: 3
	}), n.tanzakus.length >= 2 && n.brights.length === 0 && n.tanes.length === 0 && r.push({
		key: "games.hanafuda.teyaku.aka",
		points: 3
	})), (n.redTan.length === 3 || n.blueTan.length === 3) && r.push({
		key: "games.hanafuda.teyaku.nigiri",
		points: 10
	}), n.brights.length === 5 ? r.push({
		key: "games.hanafuda.teyaku.tegoko",
		points: 15
	}) : n.brights.length === 4 && r.push({
		key: "games.hanafuda.teyaku.teshiko",
		points: 12
	}), n.nonWillowTan.length >= 7 && r.push({
		key: "games.hanafuda.teyaku.tenana",
		points: 10
	}), r;
}
function se(e) {
	return [...A(e, !0).months.entries()].filter(([, e]) => e.length === 3).map(([e]) => e);
}
var ce = /* @__PURE__ */ new Set([
	"games.hanafuda.teyaku.aka",
	"games.hanafuda.teyaku.tanichi",
	"games.hanafuda.teyaku.toichi",
	"games.hanafuda.teyaku.karasu"
]);
function le(e) {
	return e.some((e) => ce.has(e.key));
}
function F(e) {
	return e.reduce((e, t) => e + E(t).points, 0);
}
//#endregion
//#region src/games/hanafuda/hachihachi.ts
var I = 12;
function ue(e) {
	let t = [];
	for (let n of e.field) {
		let e = E(n);
		e.kind === "bright" && t.push(e.month === 11 || e.month === 12 ? 4 : 2);
	}
	return t;
}
function L(e, t, n, r) {
	e.scores[t] -= r, e.scores[n] += r;
}
function de(e) {
	let t = [], n = e.hachi;
	n.teyakuTransfers = [], n.fukikeshiDone = !1;
	let r = [...n.carry, ...ue(e)].sort((e, t) => t - e);
	n.multiplier = r[0] ?? 1, n.carry = r.slice(1), t.push({
		kind: "hachiField",
		data: {
			multiplier: n.multiplier,
			carry: n.carry.length
		}
	});
	for (let r of e.players) {
		let i = oe(e.hands[r], e.field);
		if (n.teyaku[r] = i, i.length > 0) {
			let a = i.reduce((e, t) => e + t.points, 0), o = a * I * n.multiplier;
			for (let t of e.players) t !== r && (L(e, t, r, o), n.teyakuTransfers.push({
				from: t,
				to: r,
				amount: o
			}));
			t.push({
				kind: "teyaku",
				rid: r,
				data: {
					list: k(i),
					kan: a,
					amount: o
				}
			});
		}
		n.sampon[r] = se(e.hands[r]), n.nuke[r] = le(i), n.collected[r] = 0, n.sage[r] = !1;
	}
	return t;
}
function R(e, t) {
	let n = e.hachi, r = [], i = n.sampon[t];
	if (!i || i.length === 0) return r;
	let a = /* @__PURE__ */ new Map();
	for (let n of e.captured[t]) {
		let e = E(n).month;
		a.set(e, (a.get(e) ?? 0) + 1);
	}
	let o = i.filter((e) => (a.get(e) ?? 0) === 4);
	if (o.length === 0) return r;
	n.sampon[t] = i.filter((e) => !o.includes(e));
	let s = o.length * I * n.multiplier;
	for (let n of e.players) n !== t && L(e, n, t, s);
	return r.push({
		kind: "tobikomi",
		rid: t,
		data: {
			months: o,
			amount: s
		}
	}), r;
}
function fe(e, t) {
	let { total: n } = P(e.captured[t]);
	return n <= (e.yakuBase[t] ?? 0) ? !1 : (e.pendingTotal = n, e.stage = "declare", !0);
}
function z(e, t) {
	let n = e.hachi;
	if (n.fukikeshiDone) return !1;
	let { list: r } = P(e.captured[t]);
	if (!r.some((e) => e.key === "games.hanafuda.yaku.kasuju")) return !1;
	for (let t of n.teyakuTransfers) L(e, t.to, t.from, t.amount);
	return n.teyakuTransfers = [], n.fukikeshiDone = !0, !0;
}
function pe(e, t) {
	let n = e.hachi, r = e.pendingTotal, i = (r - (e.yakuBase[t] ?? 0)) * I * n.multiplier;
	for (let n of e.players) n !== t && L(e, n, t, i / 2);
	return e.yakuBase[t] = r, n.collected[t] += i, i;
}
function me(e) {
	let t = e.hachi, n = [];
	for (let r of e.players) {
		if (!t.nuke[r] || F(e.captured[r]) < 89) continue;
		t.nuke[r] = !1;
		let i = I * t.multiplier;
		for (let t of e.players) t !== r && L(e, t, r, i);
		n.push({
			rid: r,
			amount: i
		});
	}
	return n;
}
function he(e, t, n) {
	let r = e.hachi, i = [], a = pe(e, t), o = z(e, t);
	if (!n) return r.sage[t] = !0, e.stage = "play", i.push({
		kind: "declare",
		rid: t,
		data: {
			stop: !1,
			total: e.pendingTotal,
			amount: a,
			fukikeshi: o
		}
	}), {
		fx: i,
		ended: !1,
		winner: null
	};
	for (let n of e.players) {
		if (n === t || !r.sage[n] || r.collected[n] === 0) continue;
		let a = r.collected[n];
		for (let t of e.players) t !== n && L(e, n, t, a / 2);
		L(e, n, t, a), i.push({
			kind: "sagePenalty",
			rid: n,
			data: {
				amount: a * 2,
				to: t
			}
		}), r.collected[n] = 0, r.sage[n] = !1;
	}
	let s = me(e);
	return i.push({
		kind: "declare",
		rid: t,
		data: {
			stop: !0,
			total: e.pendingTotal,
			amount: a,
			fukikeshi: o,
			nukes: s
		}
	}), {
		fx: i,
		ended: !0,
		winner: t
	};
}
function ge(e) {
	let t = e.hachi, n = [];
	for (let r of e.players) {
		if (!t.sage[r] || t.collected[r] === 0) continue;
		let i = t.collected[r] / 2;
		for (let t of e.players) t !== r && L(e, r, t, i / 2);
		n.push({
			kind: "sagePenalty",
			rid: r,
			data: {
				amount: i,
				to: null
			}
		}), t.collected[r] = 0, t.sage[r] = !1;
	}
	let r = me(e), i = {}, a = {};
	for (let n of e.players) a[n] = F(e.captured[n]), i[n] = (a[n] - 88) * t.multiplier, e.scores[n] += i[n];
	let o = Math.max(...e.players.map((e) => a[e])), s = e.players.filter((e) => a[e] === o);
	return n.push({
		kind: "settle",
		data: {
			deltas: i,
			points: a,
			nukes: r,
			multiplier: t.multiplier
		}
	}), {
		fx: n,
		winner: s.length === 1 ? s[0] : null
	};
}
function _e() {
	return {
		multiplier: 1,
		carry: [],
		teyaku: {},
		teyakuTransfers: [],
		sampon: {},
		nuke: {},
		collected: {},
		sage: {},
		fukikeshiDone: !1
	};
}
//#endregion
//#region src/games/hanafuda/hanaawase.ts
function ve(e) {
	let t = {}, n = {}, r = {};
	for (let n of e.players) t[n] = N(e.captured[n]), r[n] = F(e.captured[n]);
	for (let i of e.players) {
		let a = e.players.filter((e) => e !== i).reduce((e, n) => e + t[n].total, 0);
		n[i] = r[i] - 88 + t[i].total * 2 - a, e.scores[i] += n[i];
	}
	let i = Math.max(...e.players.map((e) => n[e])), a = e.players.filter((e) => n[e] === i), o = a.length === 1 && i > 0 ? a[0] : null;
	return {
		fx: [{
			kind: "settle",
			data: {
				deltas: n,
				points: r,
				yakus: Object.fromEntries(e.players.map((e) => [e, k(t[e].list)]))
			}
		}],
		result: {
			deltas: n,
			yakus: t,
			winner: o
		}
	};
}
//#endregion
//#region src/games/hanafuda/koikoi.ts
function ye(e) {
	let t = [];
	for (let n of e.players) {
		let r = ie(e.hands[n]);
		r && t.push({
			rid: n,
			kind: r
		});
	}
	return t;
}
function be(e, t) {
	let { total: n } = M(e.captured[t]);
	return n <= (e.yakuBase[t] ?? 0) ? !1 : (e.pendingTotal = n, e.stage = "declare", !0);
}
function xe(e, t, n) {
	let r = e.pendingTotal;
	if (!n) return e.koikoiDeclared[t] = !0, e.yakuBase[t] = r, e.stage = "play", {
		fx: [{
			kind: "declare",
			rid: t,
			data: {
				stop: !1,
				total: r
			}
		}],
		ended: !1
	};
	let i = e.players.some((n) => n !== t && e.koikoiDeclared[n]), a = (r >= 7 ? 2 : 1) * (i ? 2 : 1), o = r * a;
	return e.scores[t] += o, {
		fx: [{
			kind: "declare",
			rid: t,
			data: {
				stop: !0,
				total: r,
				mult: a,
				gain: o
			}
		}],
		ended: !0
	};
}
//#endregion
//#region src/games/hanafuda/meta.ts
var B = {
	id: "hanafuda",
	tier: "beta",
	mechanics: ["set-collection", "push-your-luck"],
	interactionTags: [],
	nameKey: "games.hanafuda.name",
	descKey: "games.hanafuda.desc",
	rulesKey: "games.hanafuda.rules",
	icon: "🎴",
	iconImg: "games/hanafuda.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/hanafuda/en.pdf" },
	minPlayers: 2,
	maxPlayers: 3,
	bestPlayers: [2],
	accent: "#b3382c",
	releasedAt: "2026-09-16",
	search: {
		py: "hua zha",
		init: "hz"
	},
	hotseat: "cover"
}, V = t.int().min(0).max(47), Se = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("tick"),
		now: t.number()
	}),
	t.object({
		type: t.literal("play"),
		card: V,
		take: V.optional()
	}),
	t.object({
		type: t.literal("takeFlip"),
		card: V
	}),
	t.object({
		type: t.literal("declare"),
		stop: t.boolean()
	})
]), Ce = t.object({
	threePlayer: t.enum(["hanaawase", "hachihachi"]).default("hanaawase"),
	rounds: t.union([t.literal(12), t.literal(6)]).default(12)
}).default({
	threePlayer: "hanaawase",
	rounds: 12
}), we = t.string(), Te = t.object({
	key: t.string(),
	points: t.int()
}), Ee = t.object({
	variant: t.enum([
		"koikoi",
		"hanaawase",
		"hachihachi"
	]),
	phase: t.enum(["play", "done"]),
	round: t.int().min(1),
	totalRounds: t.int().min(1),
	dealer: we,
	field: t.array(V),
	fieldSlots: t.array(V.nullable()),
	turn: t.object({
		seat: we,
		stage: t.enum([
			"play",
			"flipChoice",
			"declare",
			"introBeat",
			"drawBeat",
			"flipRevealBeat",
			"turnBeat",
			"yakuBeat",
			"roundBeat"
		]),
		drawn: V.nullable()
	}),
	players: t.array(t.object({
		rid: we,
		captured: t.array(V),
		score: t.int(),
		yaku: t.array(Te),
		declaring: t.boolean(),
		teyaku: t.array(Te)
	})),
	pendingDeclare: t.object({
		total: t.int(),
		doubled: t.boolean()
	}).nullable(),
	hachi: t.object({
		multiplier: t.int(),
		carry: t.int()
	}).nullable(),
	deckLeft: t.int().nonnegative()
}), De = t.object({ hand: t.array(V) });
//#endregion
//#region src/games/hanafuda/state.ts
function Oe(e) {
	return e === "koikoi" ? {
		handSize: 8,
		fieldSize: 8
	} : {
		handSize: 7,
		fieldSize: 6
	};
}
function ke(t, n) {
	let r = [...re];
	for (let i = r.length - 1; i > 0; --i) {
		let a = e(t, n, i + 1);
		n += 1, [r[i], r[a]] = [r[a], r[i]];
	}
	return {
		deck: r,
		cursor: n
	};
}
function Ae(e) {
	if (e.length !== 8) return !1;
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = E(n).month;
		t.set(e, (t.get(e) ?? 0) + 1);
	}
	return t.size === 4 && [...t.values()].every((e) => e === 2);
}
function je(e) {
	let { handSize: t, fieldSize: n } = Oe(e.variant), r = ke(e.seed, e.rngCursor);
	e.rngCursor = r.cursor;
	let i = 0;
	for (let n of e.players) e.hands[n] = r.deck.slice(i, i + t), i += t;
	let a = r.deck.slice(i, i + n);
	return i += n, ae(a) || Ae(a) ? null : (e.deck = r.deck.slice(i), a);
}
function Me(e) {
	for (let t = 0; t < 100; t += 1) {
		let t = je(e);
		if (t) {
			e.field = t, e.fieldSlots = [...t].sort((e, t) => E(e).month - E(t).month || e - t);
			break;
		}
	}
	e.stage = "play", e.drawn = null, e.turnIdx = e.dealerIdx, e.yakuBase = {}, e.koikoiDeclared = {}, e.pendingTotal = 0;
}
function H(e, t) {
	let n = E(t).month;
	return e.filter((e) => E(e).month === n);
}
function Ne(e, t, n, r) {
	let i = H(e.field, n);
	if (i.length === 0) {
		e.field = [...e.field, n];
		let t = e.fieldSlots.indexOf(null);
		return e.fieldSlots = t >= 0 ? e.fieldSlots.map((e, r) => r === t ? n : e) : [...e.fieldSlots, n], { taken: [] };
	}
	if (i.length === 2) {
		let a = r ?? i[0];
		return e.field = e.field.filter((e) => e !== a), e.fieldSlots = e.fieldSlots.map((e) => e === a ? null : e), e.captured[t] = [
			...e.captured[t],
			n,
			a
		], { taken: [n, a] };
	}
	let a = new Set(i);
	return e.field = e.field.filter((e) => !a.has(e)), e.fieldSlots = e.fieldSlots.map((e) => e !== null && a.has(e) ? null : e), e.captured[t] = [
		...e.captured[t],
		n,
		...i
	], { taken: [n, ...i] };
}
function Pe(e) {
	return e.players.every((t) => e.hands[t].length === 0);
}
//#endregion
//#region src/games/hanafuda/rules.ts
var U = {
	land: 420,
	match: 450,
	gather: 460,
	stagger: 80,
	hold: 220,
	flipWait: 760,
	yaku: 1500,
	declare: 1400,
	round: 1500,
	field: 320,
	fieldStagger: 75,
	deal: 340,
	dealStagger: 55,
	hachiField: 1400,
	teyakuKind: 1600,
	teyakuList: 1800,
	buffer: 180
}, W = (e) => e > 0 ? U.land + U.match + U.gather + (e - 1) * U.stagger : U.land + U.hold, Fe = (e) => W(e) + U.buffer;
function Ie(e) {
	let t = (e) => {
		let t = e.data;
		return e.kind === "field" ? U.field + (Array.isArray(t?.cards) ? t.cards.length : 0) * U.fieldStagger : e.kind === "deal" ? U.deal + (typeof t?.count == "number" ? t.count : 0) * U.dealStagger : e.kind === "hachiField" ? typeof t?.multiplier == "number" && t.multiplier > 1 ? U.hachiField : 0 : e.kind === "teyaku" ? typeof t?.kind == "string" ? U.teyakuKind : U.teyakuList : 0;
	}, n = 0, r = 0;
	for (let i of e) i.with || (n += r, r = 0), r = Math.max(r, t(i));
	return n + r;
}
function Le(e, t) {
	let n = () => {
		e.stage = "introBeat", e.beatMs = Ie(t) + U.buffer;
	};
	for (;;) {
		for (let t of e.players) e.captured[t] = [];
		Me(e), t.push({
			kind: "field",
			data: { cards: e.field }
		});
		for (let [n, r] of e.players.entries()) t.push({
			kind: "deal",
			rid: r,
			data: { count: e.hands[r].length },
			for: [r],
			secret: { cards: e.hands[r] },
			...n > 0 ? { with: !0 } : {}
		});
		if (e.variant === "hachihachi") {
			t.push(...de(e)), n();
			return;
		}
		if (e.variant !== "koikoi") {
			n();
			return;
		}
		let r = ye(e);
		if (r.length > 1) continue;
		if (r.length === 0) {
			n();
			return;
		}
		let { rid: i, kind: a } = r[0];
		if (e.scores[i] += 6, t.push({
			kind: "teyaku",
			rid: i,
			data: {
				kind: a,
				gain: 6
			}
		}), !Re(e, i)) return;
	}
}
function Re(e, t) {
	return e.round >= e.totalRounds ? (e.phase = "done", !1) : (e.round += 1, t && (e.dealerIdx = e.players.indexOf(t)), !0);
}
function G(e, t) {
	e.stage = "roundBeat", e.pendingWinner = t, e.beatMs = U.round + U.buffer;
}
function ze(e, t) {
	if (!Pe(e)) {
		e.turnIdx = (e.turnIdx + 1) % e.players.length, e.stage = "play";
		return;
	}
	if (e.variant === "koikoi") {
		t.push({
			kind: "settle",
			data: { draw: !0 }
		}), G(e, null);
		return;
	}
	if (e.variant === "hanaawase") {
		let { fx: n, result: r } = ve(e);
		t.push(...n.map((e, t) => t === 0 ? e : {
			...e,
			with: !0
		})), G(e, r.winner);
		return;
	}
	let { fx: n, winner: r } = ge(e);
	t.push(...n.map((e, t) => t === 0 ? e : {
		...e,
		with: !0
	})), G(e, r);
}
function Be(e, t, n) {
	if (e.variant === "koikoi" && be(e, t)) {
		let { list: r } = M(e.captured[t]);
		return n.push({
			kind: "yaku",
			rid: t,
			data: {
				list: k(r),
				total: e.pendingTotal
			}
		}), e.stage = "yakuBeat", e.beatMs = U.yaku + U.buffer, {
			state: e,
			fx: n
		};
	}
	if (e.variant === "hachihachi" && fe(e, t)) {
		let { list: r } = P(e.captured[t]);
		return n.push({
			kind: "yaku",
			rid: t,
			data: {
				list: k(r),
				total: e.pendingTotal
			}
		}), e.stage = "yakuBeat", e.beatMs = U.yaku + U.buffer, {
			state: e,
			fx: n
		};
	}
	return ze(e, n), {
		state: e,
		fx: n
	};
}
function Ve(e, t, n) {
	let r = e.deck[0];
	if (r === void 0) return Be(e, t, n);
	e.deck = e.deck.slice(1);
	let i = H(e.field, r);
	if (i.length === 2) return e.stage = "flipRevealBeat", e.drawn = r, n.push({
		kind: "flipWait",
		rid: t,
		data: {
			card: r,
			matches: i
		}
	}), e.beatMs = U.flipWait + U.buffer, {
		state: e,
		fx: n
	};
	let a = e.fieldSlots, { taken: o } = Ne(e, t, r);
	return n.push({
		kind: "flip",
		rid: t,
		data: {
			card: r,
			taken: o,
			slots: a,
			from: "deck"
		}
	}), e.hachi && n.push(...R(e, t).map((e) => ({
		...e,
		with: !0
	}))), e.stage = "turnBeat", e.beatMs = Fe(o.length), {
		state: e,
		fx: n
	};
}
function He(t, n, r) {
	let i = n.length === 2 ? "koikoi" : t.threePlayer, a = {}, o = {}, s = {};
	for (let e of n) a[e] = [], o[e] = [], s[e] = 0;
	let c = {
		players: n,
		variant: i,
		seed: r,
		totalRounds: t.rounds,
		round: 1,
		dealerIdx: e(r, 0, n.length),
		turnIdx: 0,
		stage: "play",
		drawn: null,
		deck: [],
		field: [],
		fieldSlots: [],
		hands: a,
		captured: o,
		scores: s,
		yakuBase: {},
		koikoiDeclared: {},
		pendingTotal: 0,
		beatMs: 0,
		pendingWinner: null,
		hachi: i === "hachihachi" ? _e() : null,
		rngCursor: 1,
		phase: "play"
	};
	c.turnIdx = c.dealerIdx;
	let l = [];
	return Le(c, l), {
		state: c,
		fx: l
	};
}
function Ue(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "play") return {
			state: e,
			fx: []
		};
		if (e.stage === "introBeat" || e.stage === "flipRevealBeat" || e.stage === "yakuBeat") {
			let t = structuredClone(e);
			return t.stage = e.stage === "introBeat" ? "play" : e.stage === "flipRevealBeat" ? "flipChoice" : "declare", t.beatMs = 0, {
				state: t,
				fx: []
			};
		}
		if (e.stage === "drawBeat") {
			let t = structuredClone(e);
			return Ve(t, t.players[t.turnIdx], []);
		}
		if (e.stage === "turnBeat") {
			let t = structuredClone(e);
			return Be(t, t.players[t.turnIdx], []);
		}
		if (e.stage === "roundBeat") {
			let t = structuredClone(e), n = t.pendingWinner;
			t.pendingWinner = null;
			let r = [];
			return Re(t, n) && Le(t, r), {
				state: t,
				fx: r
			};
		}
		return {
			state: e,
			fx: []
		};
	}
	let r = e.players[e.turnIdx];
	if (e.phase !== "play" || r !== n.by) return { code: "games.hanafuda.errNotYourTurn" };
	if (t.type === "play") {
		if (e.stage !== "play") return { code: "games.hanafuda.errNotYourTurn" };
		if (!e.hands[n.by].includes(t.card)) return { code: "games.hanafuda.errBadCard" };
		let r = H(e.field, t.card);
		if (r.length === 2 && (t.take === void 0 || !r.includes(t.take)) || r.length !== 2 && t.take !== void 0) return { code: "games.hanafuda.errBadTake" };
		let i = structuredClone(e);
		i.hands[n.by] = i.hands[n.by].filter((e) => e !== t.card);
		let a = i.fieldSlots, { taken: o } = Ne(i, n.by, t.card, t.take), s = [{
			kind: "play",
			rid: n.by,
			data: {
				card: t.card,
				taken: o,
				slots: a
			},
			for: [n.by],
			secret: { hand: e.hands[n.by] }
		}];
		return i.hachi && s.push(...R(i, n.by).map((e) => ({
			...e,
			with: !0
		}))), i.stage = "drawBeat", i.beatMs = Fe(o.length), {
			state: i,
			fx: s
		};
	}
	if (t.type === "takeFlip") {
		if (e.stage !== "flipChoice" || e.drawn === null) return { code: "games.hanafuda.errNotYourTurn" };
		if (!H(e.field, e.drawn).includes(t.card)) return { code: "games.hanafuda.errBadTake" };
		let r = structuredClone(e), i = r.drawn;
		r.drawn = null;
		let a = r.fieldSlots, { taken: o } = Ne(r, n.by, i, t.card), s = [{
			kind: "flip",
			rid: n.by,
			data: {
				card: i,
				taken: o,
				slots: a,
				from: "wait"
			}
		}];
		return r.hachi && s.push(...R(r, n.by).map((e) => ({
			...e,
			with: !0
		}))), r.stage = "turnBeat", r.beatMs = Fe(o.length), {
			state: r,
			fx: s
		};
	}
	if (e.stage !== "declare") return { code: "games.hanafuda.errNotYourTurn" };
	let i = structuredClone(e);
	if (i.variant === "koikoi") {
		let { fx: e, ended: r } = xe(i, n.by, t.stop);
		return r ? G(i, n.by) : (i.stage = "turnBeat", i.beatMs = U.declare + U.buffer), {
			state: i,
			fx: e
		};
	}
	if (i.variant === "hachihachi") {
		let { fx: e, ended: r, winner: a } = he(i, n.by, t.stop);
		for (let t = 1; t < e.length; t += 1) e[t] = {
			...e[t],
			with: !0
		};
		return r ? G(i, a) : (i.stage = "turnBeat", i.beatMs = U.declare + U.buffer), {
			state: i,
			fx: e
		};
	}
	return { code: "games.hanafuda.errNotYourTurn" };
}
function We(e, t) {
	return {
		public: {
			variant: e.variant,
			phase: e.phase,
			round: e.round,
			totalRounds: e.totalRounds,
			dealer: e.players[e.dealerIdx],
			field: e.field,
			fieldSlots: e.fieldSlots,
			turn: {
				seat: e.players[e.turnIdx],
				stage: e.stage,
				drawn: e.drawn
			},
			players: e.players.map((t) => ({
				rid: t,
				captured: e.captured[t],
				score: e.scores[t],
				yaku: e.variant === "koikoi" ? M(e.captured[t]).list : e.variant === "hachihachi" ? P(e.captured[t]).list : [],
				declaring: e.variant === "koikoi" ? e.koikoiDeclared[t] === !0 : e.hachi?.sage[t] === !0,
				teyaku: e.hachi?.teyaku[t] ?? []
			})),
			pendingDeclare: e.stage === "declare" ? {
				total: e.pendingTotal,
				doubled: e.variant === "koikoi" && e.pendingTotal >= 7
			} : null,
			hachi: e.variant === "hachihachi" && e.hachi ? {
				multiplier: e.hachi.multiplier,
				carry: e.hachi.carry.length
			} : null,
			deckLeft: e.deck.length
		},
		private: { hand: e.hands[t] ?? [] }
	};
}
function Ge(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]), n = e.scores[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.scores[t] === n),
		ranking: t,
		scores: { ...e.scores }
	};
}
var Ke = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: B,
	schemas: {
		action: Se,
		publicView: Ee,
		privateView: De,
		config: Ce
	},
	setup: He,
	reduce: Ue,
	viewFor: We,
	status: Ge,
	nextTickIn: (e) => e.phase === "play" && (e.stage === "introBeat" || e.stage === "drawBeat" || e.stage === "flipRevealBeat" || e.stage === "turnBeat" || e.stage === "yakuBeat" || e.stage === "roundBeat") ? e.beatMs : null
}, qe = "aspect-[976/1600]";
function K({ id: e, className: t = "" }) {
	return /* @__PURE__ */ p("img", {
		src: ne(e),
		alt: "",
		draggable: !1,
		className: `${qe} rounded-md border-2 border-ink bg-surface object-cover ${t}`
	});
}
function Je({ className: e = "" }) {
	return /* @__PURE__ */ p("img", {
		src: D,
		alt: "",
		draggable: !1,
		className: `${qe} rounded-md border-2 border-ink object-cover ${e}`
	});
}
//#endregion
//#region src/games/hanafuda/view-player.tsx
function Ye(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ p(Qe, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var Xe = [
	"bright",
	"tane",
	"tanzaku",
	"kasu"
], Ze = {
	bright: "games.hanafuda.kind.bright",
	tane: "games.hanafuda.kind.tane",
	tanzaku: "games.hanafuda.kind.tanzaku",
	kasu: "games.hanafuda.kind.kasu"
};
function Qe({ pub: e, priv: t, members: f, myRid: h, send: g }) {
	let _ = c(), v = (e) => f.find((t) => t.rid === e)?.name ?? e, y = e.players.find((e) => e.rid === h), ee = t?.hand ?? [], b = e.phase === "play" && e.turn.seat === h, x = b && e.turn.stage === "play", S = b && e.turn.stage === "flipChoice" && e.turn.drawn !== null, C = (e.turn.stage === "flipChoice" || e.turn.stage === "flipRevealBeat") && e.turn.drawn !== null, te = b && e.turn.stage === "declare", w = `${e.round}:${e.turn.seat}:${e.turn.stage}`, [T, ne] = a({
		key: w,
		card: null
	});
	T.key !== w && ne({
		key: w,
		card: null
	});
	let D = T.key === w ? T.card : null, O = (e) => ne({
		key: w,
		card: e
	}), re = D === null ? [] : e.field.filter((e) => E(e).month === E(D).month), k = S ? e.field.filter((t) => E(t).month === E(e.turn.drawn).month) : [], A = C ? e.field.filter((t) => E(t).month === E(e.turn.drawn).month) : [], j = new Set(S ? k : re.length === 2 ? re : []), M = /* @__PURE__ */ new Set([...j, ...A]), ie = (t) => {
		if (x) {
			if (e.field.filter((e) => E(e).month === E(t).month).length === 2) {
				O(t === D ? null : t);
				return;
			}
			g({
				type: "play",
				card: t
			}), O(null);
		}
	}, ae = (e) => {
		if (S && k.includes(e)) {
			g({
				type: "takeFlip",
				card: e
			});
			return;
		}
		x && D !== null && j.has(e) && (g({
			type: "play",
			card: D,
			take: e
		}), O(null));
	}, { ref: N } = o("field"), P = i(null), oe = n((e) => {
		N(e), P.current = e;
	}, [N]), { ref: se } = o("deck"), { ref: ce } = o("captured:me"), { ref: le } = o("hand"), { ref: F } = o("hand:measure"), { ref: I } = o("reveal"), { ref: ue, hidden: L } = o("drawn");
	r(() => {
		let e = P.current, t = e?.parentElement;
		if (!e || !t) return;
		let n = () => {
			let n = Math.max(44, (e.clientHeight - 56) * 976 / 1600);
			t.style.setProperty("--hf-field-fit-width", `${n}px`);
		}, r = new ResizeObserver(n);
		return r.observe(e), n(), () => {
			r.disconnect(), t.style.removeProperty("--hf-field-fit-width");
		};
	}, []), r(() => {
		if (D === null && !C) return;
		let e = P.current, t = e?.querySelector(".hf-field-card-hinted");
		if (!e || !t) return;
		let n = e.getBoundingClientRect(), r = t.getBoundingClientRect();
		r.top < n.top ? e.scrollTop += r.top - n.top - 8 : r.bottom > n.bottom && (e.scrollTop += r.bottom - n.bottom + 8);
	}, [
		D,
		C,
		e.field
	]);
	let de = e.turn.stage === "introBeat" || e.turn.stage === "drawBeat" || e.turn.stage === "flipRevealBeat" || e.turn.stage === "turnBeat" || e.turn.stage === "yakuBeat" || e.turn.stage === "roundBeat" ? _("games.hanafuda.resolving") : te ? _("games.hanafuda.declarePrompt") : S ? _("games.hanafuda.flipChoicePrompt") : x ? _("games.hanafuda.yourTurn") : _("games.hanafuda.waiting", { name: v(e.turn.seat) }), R = e.hachi?.multiplier === 4 ? "games.hanafuda.multi.4" : e.hachi?.multiplier === 2 ? "games.hanafuda.multi.2" : "games.hanafuda.multi.1", fe = Xe.map((e) => ({
		kind: e,
		cards: (y?.captured ?? []).filter((t) => E(t).kind === e)
	})), z = e.variant === "hachihachi" ? _("games.hanafuda.unitKan") : "";
	return /* @__PURE__ */ p(d, {
		adaptive: !0,
		className: "hf-screen",
		banner: /* @__PURE__ */ m("div", {
			className: "hf-banner flex flex-col gap-2",
			children: [/* @__PURE__ */ p(l, {
				tone: te ? "warn" : x || S ? "accent" : "info",
				accent: B.accent,
				chip: `${e.round}/${e.totalRounds}`,
				text: de,
				sub: e.hachi ? _("games.hanafuda.multiSub", {
					multi: _(R),
					carry: e.hachi.carry
				}) : void 0
			}), /* @__PURE__ */ p("div", {
				className: "hf-seats",
				children: /* @__PURE__ */ p(u, {
					members: f,
					myRid: h,
					variant: "plate",
					status: (t) => {
						let n = e.players.find((e) => e.rid === t);
						return n ? /* @__PURE__ */ m("span", {
							className: "hf-seat-score flex items-center gap-1 font-mono text-xs font-bold tabular-nums",
							children: [
								/* @__PURE__ */ p(s, { value: n.score }),
								/* @__PURE__ */ m("span", {
									className: "opacity-60",
									children: ["/ ", n.captured.length]
								}),
								t === e.dealer && /* @__PURE__ */ p("span", {
									className: "rounded bg-ink px-1 text-[10px] text-surface",
									children: _("games.hanafuda.dealerMark")
								}),
								n.declaring && /* @__PURE__ */ p("span", {
									className: "rounded bg-warn-soft px-1 text-[10px] text-warn-ink",
									children: _("games.hanafuda.declaringBadge")
								})
							]
						}) : null;
					},
					action: (t) => e.phase === "play" && e.turn.stage === "play" && e.turn.seat === t ? "pending" : null,
					anchorOf: (e) => `seat:${e}`
				})
			})]
		}),
		actionsHeight: "hf-actions-height",
		actions: te && e.pendingDeclare ? /* @__PURE__ */ m("div", {
			className: "hf-hand-tray flex h-full items-center gap-2 px-2",
			children: [/* @__PURE__ */ m("button", {
				type: "button",
				onClick: () => g({
					type: "declare",
					stop: !0
				}),
				className: "btn-base min-w-0 flex-1 text-sm text-surface",
				style: { background: B.accent },
				children: [_(e.variant === "hachihachi" ? "games.hanafuda.stop88" : "games.hanafuda.stopKoikoi"), /* @__PURE__ */ m("span", {
					className: "font-mono tabular-nums",
					children: [
						e.pendingDeclare.total,
						z,
						e.pendingDeclare.doubled ? " ×2" : ""
					]
				})]
			}), /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => g({
					type: "declare",
					stop: !1
				}),
				className: "btn-base min-w-0 flex-1 bg-surface text-sm",
				children: _(e.variant === "hachihachi" ? "games.hanafuda.continue88" : "games.hanafuda.continueKoikoi")
			})]
		}) : /* @__PURE__ */ p("div", {
			className: "hf-hand-tray h-full overflow-x-auto overscroll-x-contain",
			children: /* @__PURE__ */ m("div", {
				ref: le,
				className: "hf-hand-row mx-auto flex h-full w-max min-w-full items-center justify-center gap-1.5 px-2",
				children: [/* @__PURE__ */ p("span", {
					ref: F,
					className: "hf-hand-measure",
					"aria-hidden": !0
				}), ee.map((t) => /* @__PURE__ */ p(nt, {
					id: t,
					active: D === t,
					disabled: !x,
					matches: e.field.filter((e) => E(e).month === E(t).month).length,
					onClick: () => ie(t)
				}, t))]
			})
		}),
		scroll: !1,
		children: /* @__PURE__ */ m("div", {
			className: "hf-main flex h-full min-h-0 flex-col gap-2",
			children: [/* @__PURE__ */ m("div", {
				className: "hf-table relative flex min-h-0 flex-1 flex-col overflow-hidden",
				children: [
					/* @__PURE__ */ m("div", {
						className: "hf-table-head flex h-9 flex-none items-center justify-between px-3",
						children: [
							/* @__PURE__ */ p("span", {
								className: "hf-table-title",
								children: _("games.hanafuda.fieldLabel")
							}),
							/* @__PURE__ */ p("span", {
								className: "hf-table-crest",
								"aria-hidden": !0,
								children: "✿"
							}),
							/* @__PURE__ */ m("div", {
								className: "hf-deck flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ p("span", {
										className: "hf-deck-title",
										children: _("games.hanafuda.deckLabel")
									}),
									/* @__PURE__ */ p("span", {
										className: "hf-deck-count font-display text-sm font-extrabold tabular-nums",
										children: e.deckLeft
									}),
									/* @__PURE__ */ p("span", {
										ref: se,
										children: /* @__PURE__ */ p(Je, { className: "hf-deck-back" })
									})
								]
							})
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "hf-field-area relative min-h-0 flex-1",
						children: [/* @__PURE__ */ p("div", {
							ref: oe,
							className: "hf-field relative h-full min-h-0 overflow-y-auto p-2",
							children: /* @__PURE__ */ p("div", {
								className: "hf-field-grid grid min-h-full grid-cols-4 content-start gap-1.5 wide:grid-cols-8",
								children: e.fieldSlots.map((e, t) => /* @__PURE__ */ p(et, {
									slot: t,
									id: e,
									selectable: e !== null && j.has(e),
									highlighted: e !== null && M.has(e),
									onClick: () => e !== null && ae(e)
								}, t))
							})
						}), /* @__PURE__ */ p("div", {
							ref: I,
							className: "hf-reveal-lane",
							"aria-hidden": !C,
							children: /* @__PURE__ */ p("div", {
								ref: ue,
								className: "hf-drawn",
								style: { visibility: !C || L ? "hidden" : void 0 },
								children: C && e.turn.drawn !== null && /* @__PURE__ */ p(K, {
									id: e.turn.drawn,
									className: "w-full"
								})
							})
						})]
					}),
					/* @__PURE__ */ m("div", {
						className: "hf-yaku-strip pointer-events-none absolute inset-x-2 bottom-1 z-10 flex items-center gap-1 overflow-x-auto whitespace-nowrap",
						"aria-live": "polite",
						children: [y?.teyaku.map((e) => /* @__PURE__ */ m("span", {
							className: "hf-yaku-chip bg-warn-soft text-warn-ink",
							children: [
								_(e.key),
								" ",
								e.points,
								z
							]
						}, e.key)), y?.yaku.map((e) => /* @__PURE__ */ m("span", {
							className: "hf-yaku-chip bg-info-soft text-info-ink",
							children: [
								_(e.key),
								" ",
								e.points,
								z
							]
						}, e.key))]
					})
				]
			}), /* @__PURE__ */ p("div", {
				ref: ce,
				className: "hf-captured flex h-12 flex-none items-stretch gap-1 px-1 py-1 short:h-10",
				children: fe.map(({ kind: e, cards: t }) => /* @__PURE__ */ p($e, {
					kind: e,
					cards: t
				}, e))
			})]
		})
	});
}
function $e({ kind: e, cards: t }) {
	let n = c(), { ref: r, hidden: i } = o(`captured:${e}`);
	return /* @__PURE__ */ m("div", {
		ref: r,
		className: "hf-capture-pile flex min-w-0 flex-1 items-center justify-center gap-1",
		children: [
			/* @__PURE__ */ p("span", {
				className: "hf-pile-name",
				children: n(Ze[e])
			}),
			t.length > 0 && /* @__PURE__ */ p("span", {
				style: { visibility: i ? "hidden" : void 0 },
				children: /* @__PURE__ */ p(K, {
					id: t[t.length - 1],
					className: "hf-captured-card"
				})
			}),
			/* @__PURE__ */ m("span", {
				className: "hf-pile-count font-display text-xs font-extrabold tabular-nums",
				children: ["×", t.length]
			})
		]
	});
}
function et({ slot: e, id: t, selectable: n, highlighted: r, onClick: i }) {
	let { ref: a } = o(`fslot:${e}`);
	return /* @__PURE__ */ p("div", {
		ref: a,
		className: "hf-field-slot aspect-[976/1600] w-full max-w-[17vmin] justify-self-center short:min-w-11 short:max-w-[11vmin]",
		children: t !== null && /* @__PURE__ */ p(tt, {
			id: t,
			selectable: n,
			highlighted: r,
			onClick: i
		})
	});
}
function tt({ id: e, selectable: t, highlighted: n, onClick: r }) {
	let i = c(), { ref: a, hidden: s } = o(`fcard:${e}`);
	return /* @__PURE__ */ m("button", {
		ref: a,
		type: "button",
		onClick: r,
		disabled: !t,
		"aria-label": i("games.hanafuda.cardLabel", {
			n: E(e).month,
			kind: i(Ze[E(e).kind])
		}),
		className: `hf-field-card relative h-full min-h-11 w-full ${n ? "hf-field-card-hinted" : ""} ${t ? "hf-field-card-selectable cursor-pointer" : ""}`,
		style: { visibility: s ? "hidden" : void 0 },
		children: [/* @__PURE__ */ p(K, {
			id: e,
			className: "h-full w-full"
		}), n && /* @__PURE__ */ p("span", {
			className: "hf-target-mark",
			"aria-hidden": !0,
			children: "✦"
		})]
	});
}
function nt({ id: e, active: t, disabled: n, matches: r, onClick: i }) {
	let a = c(), { ref: s, hidden: l } = o(`hcard:${e}`);
	return /* @__PURE__ */ m("button", {
		ref: s,
		type: "button",
		onClick: i,
		disabled: n,
		"aria-label": a("games.hanafuda.cardLabel", {
			n: E(e).month,
			kind: a(Ze[E(e).kind])
		}),
		className: `hf-hand-card relative min-h-11 flex-none ${n ? "" : "cursor-pointer"} ${t ? "hf-hand-card-active" : ""}`,
		style: { visibility: l ? "hidden" : void 0 },
		children: [/* @__PURE__ */ p(K, {
			id: e,
			className: "w-full"
		}), r > 0 && !n && /* @__PURE__ */ m("span", {
			className: "hf-hand-match",
			"aria-hidden": !0,
			children: ["×", r]
		})]
	});
}
//#endregion
//#region src/games/hanafuda/bot.ts
function rt(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function it(e) {
	return e === "koikoi" ? M : e === "hachihachi" ? P : N;
}
var at = {
	koikoi: 8,
	hachihachi: 8,
	hanaawase: .3
};
function ot(e, t) {
	let n = E(e), r = n.points;
	return n.kind === "bright" && (r += 6), n.kind === "tanzaku" && (r += 3), n.isSakeCup && (r += 4), n.isInoShikaCho && (r += 3), (n.tanzaku === "red" || n.tanzaku === "blue") && (r += 2), t.some((t) => t !== e && E(t).month === n.month) && (r += 4), r;
}
function st(e, t, n, r) {
	let i = e(n).total, a = e([...n, ...r]).total;
	return F(r) + (a - i) * t;
}
var ct = (e, t) => {
	let n = e.public, r = e.private;
	if (n.phase !== "play" || n.turn.seat !== t.rid || !r) return null;
	let i = n.players.find((e) => e.rid === t.rid);
	if (!i) return null;
	let a = it(n.variant), o = t.difficulty === "weak" ? 0 : at[n.variant];
	if (n.turn.stage === "flipChoice" && n.turn.drawn !== null) {
		let e = n.turn.drawn, t = n.field.filter((t) => E(t).month === E(e).month), r = t[0], s = -Infinity;
		for (let n of t) {
			let t = st(a, o, i.captured, [e, n]);
			t > s && (s = t, r = n);
		}
		return { action: {
			type: "takeFlip",
			card: r
		} };
	}
	if (n.turn.stage === "declare" && n.pendingDeclare) {
		let e = n.pendingDeclare.total, r = n.deckLeft <= 6, i = n.variant === "koikoi" ? r ? 4 : 7 : r ? 7 : 10;
		return { action: {
			type: "declare",
			stop: e >= (t.difficulty === "weak" ? i + 3 : i) || t.difficulty === "weak" && e >= i && crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 2 == 0
		} };
	}
	if (n.turn.stage === "play") {
		let e = r.hand;
		if (e.length === 0) return null;
		if (t.difficulty === "weak" && e.length > 1 && crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 4 == 0) {
			let t = rt(e), r = n.field.filter((e) => E(e).month === E(t).month);
			return { action: {
				type: "play",
				card: t,
				...r.length === 2 ? { take: rt(r) } : {}
			} };
		}
		let s = e[0], c, l = -Infinity;
		for (let t of e) {
			let r = n.field.filter((e) => E(e).month === E(t).month);
			if (r.length === 0) {
				let n = -ot(t, e);
				n > l && (l = n, s = t, c = void 0);
				continue;
			}
			let u = r.length === 2 ? r : [void 0];
			for (let e of u) {
				let n = e === void 0 ? [t, ...r] : [t, e], u = st(a, o, i.captured, n);
				u > l && (l = u, s = t, c = e);
			}
		}
		return { action: {
			type: "play",
			card: s,
			...c === void 0 ? {} : { take: c }
		} };
	}
	return null;
}, lt = {
	bright: "games.hanafuda.kind.bright",
	tane: "games.hanafuda.kind.tane",
	tanzaku: "games.hanafuda.kind.tanzaku",
	kasu: "games.hanafuda.kind.kasu"
}, ut = (e, t, n) => {
	if (e.type === "tick") return "";
	if (e.type === "declare") {
		let r = t.public.variant === "hachihachi";
		return n(e.stop ? r ? "games.hanafuda.stop88" : "games.hanafuda.stopKoikoi" : r ? "games.hanafuda.continue88" : "games.hanafuda.continueKoikoi");
	}
	let r = E(e.card);
	return e.type === "takeFlip" ? n("games.hanafuda.hintTakeFlip", {
		n: r.month,
		kind: n(lt[r.kind])
	}) : e.take === void 0 ? n("games.hanafuda.hintPlay", {
		n: r.month,
		kind: n(lt[r.kind])
	}) : n("games.hanafuda.hintPlayTake", {
		n: r.month,
		kind: n(lt[E(e.take).kind])
	});
}, q = 56, J = 1600 / 976, Y = U.land, dt = U.match, ft = U.gather, pt = U.stagger;
function X(e, t = q, n = q * J) {
	let r = e.anchor("field");
	return r ? {
		x: r.x + r.w / 2 - t / 2,
		y: r.y + r.h / 2 - n / 2,
		w: t,
		h: n
	} : null;
}
function mt(e, t) {
	let n = e.anchor("field"), r = e.anchor("reveal");
	if (!n || !r) return null;
	let i = Math.min(r.w, Math.max(36, (n.h - 16) / J), t.w * 1.15), a = i * J, o = n.y + 8, s = n.y + n.h - 8;
	return {
		x: r.x + r.w - i,
		y: Math.max(o, Math.min(s - a, t.y - Math.min(24, t.h * .25))),
		w: i,
		h: a
	};
}
function Z(e) {
	return e.anchor("deck") ?? X(e);
}
function ht(e) {
	let t = Math.min(e.w, e.h * .61), n = t * J;
	return {
		x: e.x + e.w / 2 - t / 2,
		y: e.y + e.h / 2 - n / 2,
		w: t,
		h: n
	};
}
function gt(e, t, n) {
	let r = t && t === e.myRid ? e.anchor(`captured:${E(n).kind}`) ?? e.anchor("captured:me") ?? e.anchor(`seat:${t}`) : t ? e.anchor(`seat:${t}`) : null;
	return r ? ht(r) : null;
}
function _t(e, t, n) {
	let r = e.anchor("hand"), i = e.anchor("hand:measure"), a = t.indexOf(n);
	if (!r || !i || a < 0) return null;
	let o = document.querySelector(".hf-hand-row"), s = o ? getComputedStyle(o) : null, c = s ? Number.parseFloat(s.columnGap) : 6, l = s ? Number.parseFloat(s.paddingLeft) : 8, u = i.w, d = t.length * u + (t.length - 1) * c, f = u * J;
	return {
		x: r.x + Math.max(l, (r.w - d) / 2) + a * (u + c),
		y: r.y + (r.h - f) / 2,
		w: u,
		h: f
	};
}
function vt(e) {
	return e.anchor("drawn");
}
function yt(e, t, n, r) {
	if (t && t === e.myRid) {
		let t = _t(e, r, n);
		if (t) return t;
	}
	let i = t ? e.anchor(`seat:${t}`) : null;
	return i ? ht(i) : null;
}
function Q({ id: e, width: t = q }) {
	return /* @__PURE__ */ p("div", {
		style: { width: t },
		children: /* @__PURE__ */ p(K, {
			id: e,
			className: "w-full"
		})
	});
}
function bt({ id: e, ms: t, delay: n = 0, width: a = q }) {
	let o = i(null);
	return r(() => {
		let e = o.current;
		if (!e) return;
		let r = e.animate([
			{
				transform: "rotateY(0deg)",
				offset: 0
			},
			{
				transform: "rotateY(0deg)",
				offset: .18
			},
			{
				transform: "rotateY(180deg)",
				offset: .72
			},
			{
				transform: "rotateY(180deg)",
				offset: 1
			}
		], {
			duration: t,
			delay: n,
			easing: "ease-in-out",
			fill: "both"
		});
		return () => r.cancel();
	}, [
		e,
		t,
		n
	]), /* @__PURE__ */ p("div", {
		className: "hf-flip-wrap",
		style: { width: a },
		children: /* @__PURE__ */ m("div", {
			ref: o,
			className: "hf-flip-core",
			style: { width: "100%" },
			children: [/* @__PURE__ */ p(Je, { className: "hf-flip-back" }), /* @__PURE__ */ p(K, {
				id: e,
				className: "hf-flip-front"
			})]
		})
	});
}
function xt({ id: e, from: t, slot: n, to: a, captureAt: o, flip: s = !1, featured: c = !1 }) {
	let l = i(null);
	return r(() => {
		let e = l.current;
		if (!e) return;
		let r = q, i = q * J;
		e.style.left = `${t.x + (t.w - r) / 2}px`, e.style.top = `${t.y + (t.h - i) / 2}px`, e.style.width = `${r}px`, e.style.height = `${i}px`;
		let s = t.x + t.w / 2, c = t.y + t.h / 2, u = n.x + n.w / 2 - s, d = n.y + n.h / 2 - c, f = a.x + a.w / 2 - s, p = a.y + a.h / 2 - c, m = t.w / r, h = n.w / r, g = a.w / r, _ = o + ft, v = (e) => Math.min(e / _, 1), y = e.animate([
			{
				transform: `translate(0px, 0px) scale(${m})`,
				offset: 0
			},
			{
				transform: `translate(${u * .55}px, ${d * .55 - 12}px) scale(${(m + h) / 2})`,
				offset: v(Y * .55)
			},
			{
				transform: `translate(${u}px, ${d}px) scale(${h})`,
				offset: v(Y)
			},
			{
				transform: `translate(${u}px, ${d}px) scale(${h * 1.08})`,
				offset: v(Math.max(Y, o - dt / 2))
			},
			{
				transform: `translate(${u}px, ${d}px) scale(${h})`,
				offset: v(o)
			},
			{
				transform: `translate(${u + (f - u) * .55}px, ${d + (p - d) * .55 - 12}px) scale(${(h + g) / 2})`,
				offset: v(o + ft * .55)
			},
			{
				transform: `translate(${f}px, ${p}px) scale(${g})`,
				offset: 1
			}
		], {
			duration: _,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => y.cancel();
	}, [
		t,
		n,
		a,
		o,
		e
	]), /* @__PURE__ */ p("div", {
		ref: l,
		className: `absolute ${c ? "hf-fx-featured" : ""}`,
		style: {
			left: t.x,
			top: t.y
		},
		children: s ? /* @__PURE__ */ p(bt, {
			id: e,
			ms: Y
		}) : /* @__PURE__ */ p(Q, { id: e })
	});
}
function St(e, t, n, r, i, a, o = !1) {
	if (!i) return null;
	let s = [n, ...r.filter((e) => e !== n)], c = a.indexOf(s[1]), l = [];
	for (let [r, u] of s.entries()) {
		let s = gt(e, t, u), d = u === n ? c : a.indexOf(u), f = (d >= 0 ? e.anchor(`fslot:${d}`) : null) ?? X(e), m = u === n && f ? mt(e, f) ?? f : f;
		m && s && l.push(/* @__PURE__ */ p(xt, {
			id: u,
			from: u === n ? i : m,
			slot: m,
			to: s,
			captureAt: Y + dt + r * pt,
			flip: o && u === n,
			featured: u === n
		}, u), /* @__PURE__ */ p(_, {
			at: m,
			ms: dt,
			delay: Y
		}, `p${u}`));
	}
	if (l.length === 0) return null;
	let u = t === e.myRid ? [...new Set(s.map((e) => `captured:${E(e).kind}`))] : [];
	return {
		ms: W(s.length),
		node: l,
		hide: u
	};
}
function Ct({ at: e, ms: t, list: n, total: r, unit: i }) {
	let a = c();
	return /* @__PURE__ */ p(h, {
		at: e,
		ms: t,
		children: /* @__PURE__ */ m("div", {
			className: "flex flex-col items-center gap-0.5 rounded-xl border-2 border-ink bg-surface px-3 py-1.5 shadow-[3px_3px_0_var(--color-ink)]",
			children: [n.slice(0, 4).map((e) => /* @__PURE__ */ m("span", {
				className: "text-xs font-bold whitespace-nowrap",
				children: [
					a(e.key),
					" ",
					e.points,
					i
				]
			}, e.key)), /* @__PURE__ */ m("span", {
				className: "font-mono text-sm font-extrabold tabular-nums",
				style: { color: "var(--color-done-ink)" },
				children: [r, i]
			})]
		})
	});
}
function $({ at: e, ms: t, text: n, sub: r }) {
	return /* @__PURE__ */ p(h, {
		at: e,
		ms: t,
		children: /* @__PURE__ */ m("div", {
			className: "flex flex-col items-center rounded-xl border-2 border-ink bg-surface px-3 py-1.5 shadow-[3px_3px_0_var(--color-ink)]",
			children: [/* @__PURE__ */ p("span", {
				className: "text-sm font-extrabold whitespace-nowrap",
				children: n
			}), r && /* @__PURE__ */ p("span", {
				className: "font-mono text-xs font-bold tabular-nums",
				children: r
			})]
		})
	});
}
var wt = {
	deal(e, t) {
		let n = U.deal, r = U.dealStagger, i = e.secret;
		if (i && Array.isArray(i.cards)) {
			let e = Z(t);
			if (!e) return null;
			let a = [], o = [];
			for (let [s, c] of i.cards.entries()) {
				let i = t.anchor(`hcard:${c}`);
				i && (o.push(`hcard:${c}`), a.push(/* @__PURE__ */ p(g, {
					from: e,
					to: i,
					ms: n,
					delay: s * r,
					children: /* @__PURE__ */ p(Q, {
						id: c,
						width: e.w
					})
				}, c)));
			}
			return a.length === 0 ? null : {
				ms: n + a.length * r,
				node: a,
				hide: o
			};
		}
		let a = Z(t), o = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		if (!a || !o) return null;
		let s = e.data?.count, c = typeof s == "number" ? s : 8;
		return {
			ms: n + c * r,
			node: Array.from({ length: c }, (e, t) => /* @__PURE__ */ p(g, {
				from: a,
				to: o,
				ms: n,
				delay: t * r,
				children: /* @__PURE__ */ p("div", {
					style: { width: a.w },
					children: /* @__PURE__ */ p(Je, { className: "w-full" })
				})
			}, t))
		};
	},
	field(e, t) {
		let n = e.data?.cards;
		if (!Array.isArray(n) || n.length === 0) return null;
		let r = Z(t);
		if (!r) return null;
		let i = U.field, a = U.fieldStagger, o = [], s = [];
		for (let [e, c] of n.entries()) {
			let n = t.anchor(`fcard:${c}`);
			n && (s.push(`fcard:${c}`), o.push(/* @__PURE__ */ p(g, {
				from: r,
				to: n,
				ms: i,
				delay: e * a,
				children: /* @__PURE__ */ p(bt, {
					id: c,
					ms: i,
					delay: e * a,
					width: r.w
				})
			}, c)));
		}
		return o.length === 0 ? null : {
			ms: i + o.length * a,
			node: o,
			hide: s
		};
	},
	play(e, t) {
		let n = e.data, r = e.secret;
		if (typeof n?.card != "number" || !Array.isArray(n.taken)) return null;
		let i = n.card, a = n.taken, o = Array.isArray(n.slots) ? n.slots : [], s = Array.isArray(r?.hand) ? r.hand : [], c = yt(t, e.rid, i, s);
		if (a.length > 0) return St(t, e.rid, i, a, c, o);
		let l = t.anchor(`fcard:${i}`) ?? X(t);
		return !l || !c ? null : {
			ms: W(0),
			node: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(g, {
				from: c,
				to: l,
				ms: Y,
				children: /* @__PURE__ */ p(Q, {
					id: i,
					width: c.w
				})
			}), /* @__PURE__ */ p(_, {
				at: l,
				ms: U.hold,
				delay: Y - 40
			})] }),
			hide: [`fcard:${i}`]
		};
	},
	flip(e, t) {
		let n = e.data;
		if (typeof n?.card != "number" || !Array.isArray(n.taken)) return null;
		let r = n.card, i = n.taken, a = Array.isArray(n.slots) ? n.slots : [], o = n.from === "wait" ? vt(t) : Z(t);
		if (i.length > 0) return St(t, e.rid, r, i, o, a, n.from !== "wait");
		let s = t.anchor(`fcard:${r}`) ?? X(t);
		return !s || !o ? null : {
			ms: W(0),
			node: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(g, {
				from: o,
				to: s,
				ms: Y,
				children: n.from === "wait" ? /* @__PURE__ */ p(Q, {
					id: r,
					width: o.w
				}) : /* @__PURE__ */ p(bt, {
					id: r,
					ms: Y,
					width: o.w
				})
			}), /* @__PURE__ */ p(_, {
				at: s,
				ms: U.hold,
				delay: Y - 40
			})] }),
			hide: [`fcard:${r}`]
		};
	},
	flipWait(e, t) {
		let n = e.data;
		if (typeof n?.card != "number") return null;
		let r = Z(t), i = vt(t) ?? X(t);
		if (!r || !i) return null;
		let a = Array.isArray(n.matches) ? n.matches : [];
		return {
			ms: U.flipWait,
			node: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(g, {
				from: r,
				to: i,
				ms: Y,
				children: /* @__PURE__ */ p(bt, {
					id: n.card,
					ms: Y,
					width: r.w
				})
			}), a.map((e) => {
				let n = t.anchor(`fcard:${e}`);
				return n ? /* @__PURE__ */ p(_, {
					at: n,
					ms: U.match,
					delay: Y - 40
				}, e) : null;
			})] }),
			hide: ["drawn"]
		};
	},
	yaku(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.list) || typeof n.total != "number") return null;
		let r = (e.rid ? t.anchor(`seat:${e.rid}`) : null) ?? X(t);
		return r ? {
			ms: U.yaku,
			node: /* @__PURE__ */ p(Ct, {
				at: r,
				ms: U.yaku,
				list: n.list,
				total: n.total,
				unit: ""
			})
		} : null;
	},
	declare(e, t) {
		let n = e.data;
		if (typeof n?.stop != "boolean") return null;
		let r = (e.rid ? t.anchor(`seat:${e.rid}`) : null) ?? X(t);
		if (!r) return null;
		let i = typeof n.gain == "number" ? `+${n.gain}` : typeof n.amount == "number" ? `+${n.amount}` : void 0;
		return {
			ms: U.declare,
			node: /* @__PURE__ */ p(Tt, {
				at: r,
				ms: U.declare,
				stop: n.stop,
				sub: i
			})
		};
	},
	teyaku(e, t) {
		let n = e.data, r = (e.rid ? t.anchor(`seat:${e.rid}`) : null) ?? X(t);
		if (!r) return null;
		if (typeof n?.kind == "string") {
			let e = typeof n.gain == "number" ? `+${n.gain}` : void 0;
			return {
				ms: U.teyakuKind,
				node: /* @__PURE__ */ p(Et, {
					at: r,
					ms: U.teyakuKind,
					kind: n.kind,
					sub: e
				})
			};
		}
		if (Array.isArray(n?.list)) {
			let e = n.list.reduce((e, t) => e + t.points, 0);
			return {
				ms: U.teyakuList,
				node: /* @__PURE__ */ p(Ct, {
					at: r,
					ms: U.teyakuList,
					list: n.list,
					total: e,
					unit: ""
				})
			};
		}
		return null;
	},
	hachiField(e, t) {
		let n = e.data;
		if (typeof n?.multiplier != "number" || n.multiplier <= 1) return null;
		let r = X(t);
		return r ? {
			ms: U.hachiField,
			node: /* @__PURE__ */ p(Dt, {
				at: r,
				ms: U.hachiField,
				multiplier: n.multiplier
			})
		} : null;
	},
	tobikomi(e, t) {
		let n = e.data, r = (e.rid ? t.anchor(`seat:${e.rid}`) : null) ?? X(t);
		return !r || typeof n?.amount != "number" ? null : {
			ms: 1200,
			node: /* @__PURE__ */ p(Ot, {
				at: r,
				ms: 1200,
				amount: n.amount
			})
		};
	},
	sagePenalty(e, t) {
		let n = e.data, r = (e.rid ? t.anchor(`seat:${e.rid}`) : null) ?? X(t);
		return !r || typeof n?.amount != "number" ? null : {
			ms: 1200,
			node: /* @__PURE__ */ p(kt, {
				at: r,
				ms: 1200,
				amount: n.amount
			})
		};
	},
	settle(e, t) {
		if (!e.data?.draw) return {
			ms: 1200,
			node: null
		};
		let n = X(t);
		return n ? {
			ms: 1400,
			node: /* @__PURE__ */ p(At, {
				at: n,
				ms: 1400
			})
		} : null;
	}
};
function Tt({ at: e, ms: t, stop: n, sub: r }) {
	let i = c();
	return /* @__PURE__ */ p($, {
		at: e,
		ms: t,
		text: i(n ? "games.hanafuda.fxStop" : "games.hanafuda.fxContinue"),
		sub: r
	});
}
function Et({ at: e, ms: t, kind: n, sub: r }) {
	let i = c();
	return /* @__PURE__ */ p($, {
		at: e,
		ms: t,
		text: i(n === "teshi" ? "games.hanafuda.teyaku.teshi" : "games.hanafuda.teyaku.kuttsuki"),
		sub: r
	});
}
function Dt({ at: e, ms: t, multiplier: n }) {
	let r = c();
	return /* @__PURE__ */ p($, {
		at: e,
		ms: t,
		text: r(n === 4 ? "games.hanafuda.multi.4" : "games.hanafuda.multi.2")
	});
}
function Ot({ at: e, ms: t, amount: n }) {
	let r = c();
	return /* @__PURE__ */ p($, {
		at: e,
		ms: t,
		text: r("games.hanafuda.fxTobikomi"),
		sub: `+${n}`
	});
}
function kt({ at: e, ms: t, amount: n }) {
	let r = c();
	return /* @__PURE__ */ p($, {
		at: e,
		ms: t,
		text: r("games.hanafuda.fxSagePenalty"),
		sub: `−${n}`
	});
}
function At({ at: e, ms: t }) {
	let n = c();
	return /* @__PURE__ */ p($, {
		at: e,
		ms: t,
		text: n("games.hanafuda.fxDraw")
	});
}
//#endregion
//#region src/games/hanafuda/game-over.tsx
function jt(e) {
	return /* @__PURE__ */ p("div", {
		className: "hf-result",
		children: /* @__PURE__ */ p(v, {
			hintCount: e.hintCount,
			result: e.result,
			members: e.members,
			myRid: e.myRid,
			accent: B.accent,
			onPlayAgain: e.onPlayAgain,
			onBackToLobby: e.onBackToLobby
		})
	});
}
//#endregion
//#region src/games/hanafuda/options.tsx
var Mt = ["hanaawase", "hachihachi"], Nt = [12, 6];
function Pt({ value: e, onChange: t }) {
	let n = c(), r = Ce.safeParse(e), i = r.success ? r.data : Ce.parse(void 0);
	return /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ m("div", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ p(ee, {
				title: n("games.hanafuda.optThreePlayer"),
				children: Mt.map((e) => /* @__PURE__ */ p(y, {
					name: "hanafuda-three-player",
					value: e,
					checked: i.threePlayer === e,
					label: n(e === "hanaawase" ? "games.hanafuda.optHanaawase" : "games.hanafuda.optHachihachi"),
					accent: B.accent,
					onChange: () => t({
						...i,
						threePlayer: e
					})
				}, e))
			}), /* @__PURE__ */ p("p", {
				className: "text-xs opacity-60",
				children: n("games.hanafuda.optThreePlayerHint")
			})]
		}), /* @__PURE__ */ p(ee, {
			title: n("games.hanafuda.optRounds"),
			children: Nt.map((e) => /* @__PURE__ */ p(y, {
				name: "hanafuda-rounds",
				value: String(e),
				checked: i.rounds === e,
				label: n("games.hanafuda.optRoundsValue", { n: e }),
				accent: B.accent,
				onChange: () => t({
					...i,
					rounds: e
				})
			}, e))
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/hanafuda/entry.tsx
var Ft = {
	definition: Ke,
	View: Ye,
	bot: ct,
	describe: ut,
	fx: wt,
	OverView: jt,
	Options: Pt,
	locales: {
		zh: {
			name: "花札",
			desc: "按月配对收牌凑役:来来、花合、八八三玩法",
			rules: "目标:打出手牌与翻开的牌按月配对收取,凑役得分;全部局数打完后总分最高者获胜。\n2 人玩「来来」;3 人玩「花合」或「八八」,由开局选项决定,默认花合。\n准备:\n· 牌共 48 张,分 12 个月,每月 4 张。\n· 按牌面分光牌(20 点)、种牌(10 点)、短册(5 点)、皮牌(1 点)四类。\n· 来来:每人 8 张手牌、场牌 8 张;花合/八八:每人 7 张、场牌 6 张;其余为山札。\n· 共 12 局(可在开局选项改为 6 局)。\n流程:\n· 轮到你时打出一张手牌:场上有同月牌必须配对收取。\n· 有 2 张同月时任选一张收取;有 3 张同月时四张全部收走;无同月则打出的牌留在场上。\n· 随后翻开山札一张,按同样规则配对。\n· 手牌全部出尽,本局结束;得分者担任下一局庄家,流局时庄家连任。\n来来(2 人):\n· 役:五光 10、四光 8、雨四光 7、三光 5、猪鹿蝶 5。\n· 赤短 5、青短 5、花见酒 5、月见酒 5。\n· 种 1 分(5 张起每多 1 张多 1 分)、短 1 分(同种)。\n· 皮 1 分(10 张起每多 1 张多 1 分)。\n· 光牌役只计最高一档,其余役全部叠加。\n· 成役或役增值时必须二选一:「结算」立即收下役分结束本局,或「来来」继续追分。\n· 来来了之后役点没有增加就不能结算。\n· 结算时役点达 7 分以上翻倍;来来了之后被对方抢先结算,对方得分再翻倍。\n· 起手摸到 4 张同月或 4 组对子是手役,直接获得 6 分并结束本局。\n· 双方手牌出尽仍无人结算为流局,本局无人得分。\n花合(3 人):\n· 终局按(牌点 −88)加上自己役点的 2 倍、减去另两家役点之和计得失,三人得失相加为零。\n· 役:五光 200、四光 60、赤短/青短/七短各 40、六短/表菅原/幕月盏各 30。\n· 松桐坊主/猪鹿蝶/花见酒/月见酒/草/藤岛/桐岛/雨岛各 20。\n· 五光、四光、松桐坊主三者只计最高一档;表菅原与七短两者只计最高一档。\n八八(3 人):\n· 场牌出现松/樱/芒的光牌,本场一切收支按 2 倍计;出现柳/桐的光牌按 4 倍计。\n· 同场出现多张光牌时,多余的逐张结转到下一局。\n· 起手自动结算手役,由另两家按本场倍率支付。\n· 手役(单位贯):四三 20、握短 10、一二四 8、羽见 7、手四/双三本 6。\n· 喰付/空素/素无/光一各 4;赤/短一/十一/立三本/向立三本各 3;三本/向三本各 2。\n· 局中凑成下列役时,可「收役」结账,或「追役」继续。\n· 五光 12 贯、四光 10、赤短/青短 7、七短 10。\n· 素十六 12 贯(每多 1 张多 1 贯)。\n· 追役后本局未再成役,须退还已收役分的一半;被他人抢先收役,追役者赔付双倍。\n· 素十六成立时,本局已付的手役分全部退还。\n· 无人收役打完全部手牌为场流,按(牌点 −88)乘以本场倍率计得失。\n· 1 贯合 12 文,得分以文显示。\n牌面:Louie Mantia,Wikimedia Commons,CC BY-SA 4.0。",
			yourTurn: "轮到你:打出一张手牌",
			resolving: "落札与结算中…",
			fieldLabel: "场札",
			deckLabel: "山札",
			cardLabel: "{{n}} 月{{kind}}牌",
			waiting: "等 {{name}} 行动…",
			flipChoicePrompt: "翻牌有两张同月:点选要收的一张",
			declarePrompt: "役成立!结算还是继续?",
			stopKoikoi: "结算",
			continueKoikoi: "来来!",
			stop88: "收役",
			continue88: "追役",
			fxStop: "结算!",
			fxContinue: "来来!",
			fxTobikomi: "飞込",
			fxSagePenalty: "追役罚",
			fxDraw: "流局",
			unitKan: " 贯",
			dealerMark: "庄",
			declaringBadge: "宣言中",
			optThreePlayer: "3 人玩法",
			optHanaawase: "花合",
			optHachihachi: "八八",
			optThreePlayerHint: "2 人开局固定玩来来(Koi-Koi)",
			optRounds: "总局数",
			optRoundsValue: "{{n}} 局",
			multiSub: "本场 {{multi}} · 结转 {{carry}} 张",
			errNotYourTurn: "现在轮不到你",
			errBadCard: "这张牌不在你手里",
			errBadTake: "这张不能这样收",
			kind: {
				bright: "光",
				tane: "种",
				tanzaku: "短",
				kasu: "皮"
			},
			multi: {
				1: "小场 ×1",
				2: "大场 ×2",
				4: "绝场 ×4"
			},
			yaku: {
				goko: "五光",
				shiko: "四光",
				ameshiko: "雨四光",
				sanko: "三光",
				inoshikacho: "猪鹿蝶",
				akatan: "赤短",
				aotan: "青短",
				hanami: "花见酒",
				tsukimi: "月见酒",
				tane: "种",
				tan: "短",
				kasu: "皮",
				shoto: "松桐坊主",
				nanatan: "七短",
				rokutan: "六短",
				omote: "表菅原",
				nomi: "幕月盏",
				kusa: "草",
				fujishima: "藤岛",
				kirishima: "桐岛",
				ameshima: "雨岛",
				kasuju: "素十六"
			},
			teyaku: {
				teshi: "手四",
				kuttsuki: "喰付",
				shiso: "四三",
				ichiyon: "一二四",
				futasam: "双三本",
				haneken: "羽见",
				sampon: "三本",
				tachisam: "立三本",
				mukosam: "向三本",
				mukotachi: "向立三本",
				karasu: "空素",
				sunashi: "素无",
				pikaichi: "光一",
				toichi: "十一",
				tanichi: "短一",
				aka: "赤",
				nigiri: "握短",
				tegoko: "手五光",
				teshiko: "手四光",
				tenana: "手七短"
			},
			hintPlay: "打出 {{n}} 月的{{kind}}牌",
			hintPlayTake: "打出 {{n}} 月牌,收走那张{{kind}}",
			hintTakeFlip: "收走那张 {{n}} 月的{{kind}}牌"
		},
		en: {
			name: "Hanafuda",
			desc: "Match cards by month to build yaku: Koi-Koi, Hana-Awase, Hachi-Hachi",
			rules: "Goal: capture cards by matching months and score with yaku; after all rounds the highest total wins.\nTwo players play Koi-Koi; three play Hana-Awase or Hachi-Hachi (set in the game options, default Hana-Awase).\nSetup:\n· 48 cards in 12 months of 4.\n· Ranks: Bright (20), Animal (10), Ribbon (5) and Chaff (1).\n· Koi-Koi: 8 cards each, 8 on the field; Hana-Awase/Hachi-Hachi: 7 each, 6 on the field; the rest is the draw pile.\n· 12 rounds (can be changed to 6 in the game options).\nPlay:\n· On your turn play one hand card: if the field has the same month you must capture.\n· With 2 matches pick one; with 3 matches take all four; with none the card stays on the field.\n· Then flip the top of the draw pile and match it the same way.\n· The round ends when all hands are empty; the scorer deals next round (dealer stays after a draw).\nKoi-Koi (2 players):\n· Yaku: Goko 10, Shiko 8, Ame-Shiko 7, Sanko 5, Ino-Shika-Cho 5.\n· Akatan 5, Aotan 5, Hanami 5, Tsukimi 5.\n· Tane 1 point (from 5 animals, 1 more per extra card), Tan 1 (likewise from 5 ribbons).\n· Kasu 1 point (from 10 chaff, 1 more per extra card).\n· Only the best bright yaku counts; all other yaku stack.\n· When a yaku forms or improves you must choose: \"Stop\" to bank the points and end the round, or \"Koi-Koi\" to press on.\n· After calling Koi-Koi you may only stop once your points have increased.\n· Scores of 7 or more are doubled; if you called Koi-Koi and your opponent stops first, their score is doubled.\n· A starting hand of 4 of a month or 4 pairs is a lucky hand: score 6 points and end the round.\n· If both hands run out with no stop, the round is a draw and nobody scores.\nHana-Awase (3 players):\n· Scoring: (card points −88) plus twice your own yaku, minus the sum of both rivals' yaku; the three deltas sum to zero.\n· Yaku: Goko 200, Shiko 60, Akatan/Aotan/Nanatan 40 each, Rokutan/Omote-Sugawara/Nomi 30 each.\n· Matsu-Kiri/Ino-Shika-Cho/Hanami/Tsukimi/Kusa/Fuji-shima/Kiri-shima/Ame-shima 20 each.\n· Of Goko, Shiko and Matsu-Kiri only the best counts; of Omote-Sugawara and Nanatan only the best counts.\nHachi-Hachi (3 players):\n· A Pine/Cherry/Susuki bright on the field doubles all payments this round; a Willow/Paulownia bright quadruples them.\n· Extra brights on the same field carry over, one per following round.\n· Hand yaku are settled automatically at the start, paid by both rivals at the field multiplier.\n· Hand yaku (in kan): Shiso 20, Nigiri 10, Ichi-Yon 8, Haneken 7, Teshi/Double Threes 6.\n· Pairs/All Chaff/No Chaff/One Bright 4 each; Red Ribbons/One Ribbon/Toichi/Standing Three/Field Standing 3 each; Three of a Kind/Field Three 2 each.\n· During play, forming any of these yaku lets you \"Collect\" or \"Press\":\n· Goko 12 kan, Shiko 10, Akatan/Aotan 7, Nanatan 10.\n· Kasu-16 12 kan, 1 more per extra card.\n· If you pressed and form nothing more, you refund half of what you collected; if a rival collects first, you pay double.\n· When Kasu-16 forms, all hand-yaku payments this round are refunded.\n· If nobody collects before hands run out, the field washes out: settle (card points −88) times the field multiplier.\n· 1 kan equals 12 mon; scores are shown in mon.\nCard art: Louie Mantia, via Wikimedia Commons, CC BY-SA 4.0.",
			yourTurn: "Your turn: play a hand card",
			resolving: "Resolving cards…",
			fieldLabel: "Field",
			deckLabel: "Deck",
			cardLabel: "{{n}} · {{kind}}",
			waiting: "Waiting for {{name}}…",
			flipChoicePrompt: "Two matches for the flipped card: pick one to capture",
			declarePrompt: "Yaku! Stop or press on?",
			stopKoikoi: "Stop",
			continueKoikoi: "Koi-Koi!",
			stop88: "Collect",
			continue88: "Press",
			fxStop: "Stop!",
			fxContinue: "Koi-Koi!",
			fxTobikomi: "Tobikomi",
			fxSagePenalty: "Press penalty",
			fxDraw: "Draw",
			unitKan: " kan",
			dealerMark: "D",
			declaringBadge: "Called",
			optThreePlayer: "3-player variant",
			optHanaawase: "Hana-Awase",
			optHachihachi: "Hachi-Hachi",
			optThreePlayerHint: "Two players always play Koi-Koi",
			optRounds: "Rounds",
			optRoundsValue: "{{n}} rounds",
			multiSub: "Field {{multi}} · {{carry}} carried",
			errNotYourTurn: "Not your turn",
			errBadCard: "That card is not in your hand",
			errBadTake: "Cannot capture that way",
			kind: {
				bright: "Bright",
				tane: "Animal",
				tanzaku: "Ribbon",
				kasu: "Chaff"
			},
			multi: {
				1: "Small ×1",
				2: "Grand ×2",
				4: "Storm ×4"
			},
			yaku: {
				goko: "Goko",
				shiko: "Shiko",
				ameshiko: "Ame-Shiko",
				sanko: "Sanko",
				inoshikacho: "Ino-Shika-Cho",
				akatan: "Akatan",
				aotan: "Aotan",
				hanami: "Hanami",
				tsukimi: "Tsukimi",
				tane: "Tane",
				tan: "Tan",
				kasu: "Kasu",
				shoto: "Matsu-Kiri",
				nanatan: "Nanatan",
				rokutan: "Rokutan",
				omote: "Omote-Sugawara",
				nomi: "Nomi",
				kusa: "Kusa",
				fujishima: "Fuji-shima",
				kirishima: "Kiri-shima",
				ameshima: "Ame-shima",
				kasuju: "Kasu-16"
			},
			teyaku: {
				teshi: "Teshi",
				kuttsuki: "Pairs",
				shiso: "Shiso",
				ichiyon: "Ichi-Yon",
				futasam: "Double Threes",
				haneken: "Haneken",
				sampon: "Three of a Kind",
				tachisam: "Standing Three",
				mukosam: "Field Three",
				mukotachi: "Field Standing",
				karasu: "All Chaff",
				sunashi: "No Chaff",
				pikaichi: "One Bright",
				toichi: "Toichi",
				tanichi: "One Ribbon",
				aka: "Red Ribbons",
				nigiri: "Nigiri",
				tegoko: "Hand Goko",
				teshiko: "Hand Shiko",
				tenana: "Hand Nanatan"
			},
			hintPlay: "Play the {{kind}} of month {{n}}",
			hintPlayTake: "Play month {{n}} and take the {{kind}}",
			hintTakeFlip: "Take the {{kind}} of month {{n}}"
		}
	}
};
//#endregion
export { Ft as default };
