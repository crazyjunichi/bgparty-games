import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as o } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { Texture as l } from "@bgparty/sdk/texture";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { Floater as m, FlySprite as h, PulseBox as g } from "@bgparty/sdk/fx/primitives";
import { AVATARS as _ } from "@bgparty/sdk/avatars";
import { IconBot as v } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as y } from "@bgparty/sdk/player-colors";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
import { GameOverScreen as x } from "@bgparty/sdk/ui/game-over-screen";
import { seatName as S } from "@bgparty/sdk/ui/player-strip";
//#region src/games/yahtzee/meta.ts
var C = {
	id: "yahtzee",
	tier: "released",
	mechanics: ["roll-and-write", "dice-rolling"],
	interactionTags: [],
	nameKey: "games.yahtzee.name",
	descKey: "games.yahtzee.desc",
	rulesKey: "games.yahtzee.rules",
	icon: "⛵",
	iconImg: "games/yahtzee.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/yahtzee/en.pdf" },
	precacheAssets: ["yacht-mark.webp"],
	minPlayers: 1,
	maxPlayers: 6,
	bestPlayers: [3, 4],
	accent: "#0891b2",
	releasedAt: "2026-09-21",
	search: {
		py: "kuai ting tou zi",
		init: "kttz"
	},
	hotseat: "open"
}, w = t.int().min(1).max(6), T = t.int().min(0).max(12), E = t.string(), D = t.array(t.int().nonnegative().nullable()).length(13), O = t.array(t.array(w).length(5).nullable()).length(13), k = t.discriminatedUnion("type", [
	t.object({ type: t.literal("roll") }),
	t.object({
		type: t.literal("hold"),
		die: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("score"),
		cat: T
	})
]), A = t.object({
	phase: t.enum(["play", "done"]),
	turn: E.nullable(),
	dice: t.array(w).length(5).nullable(),
	held: t.tuple([
		t.boolean(),
		t.boolean(),
		t.boolean(),
		t.boolean(),
		t.boolean()
	]),
	rollsLeft: t.int().min(0).max(2),
	scores: t.record(t.string(), D),
	placedDice: t.record(t.string(), O),
	bonuses: t.record(t.string(), t.int().nonnegative()),
	options: t.array(t.object({
		cat: T,
		value: t.int().nonnegative(),
		bonus: t.int().nonnegative()
	})).nullable()
}), j = t.object({}), M = {
	threeKind: 6,
	fourKind: 7,
	fullHouse: 8,
	smallStraight: 9,
	largeStraight: 10,
	yahtzee: 11,
	chance: 12
};
function N(e) {
	let t = [
		0,
		0,
		0,
		0,
		0,
		0,
		0
	];
	for (let n of e) t[n] += 1;
	return t;
}
function P(e, t) {
	let n = t.reduce((e, t) => e + t, 0), r = N(t);
	if (e < 6) return (e + 1) * r[e + 1];
	let i = Math.max(...r);
	switch (e) {
		case M.threeKind: return i >= 3 ? n : 0;
		case M.fourKind: return i >= 4 ? n : 0;
		case M.fullHouse: {
			let e = r.filter((e) => e > 0).sort((e, t) => e - t);
			return e.length === 2 && e[0] === 2 && e[1] === 3 ? 25 : 0;
		}
		case M.smallStraight: {
			let e = (e, t, n, i) => r[e] > 0 && r[t] > 0 && r[n] > 0 && r[i] > 0;
			return e(1, 2, 3, 4) || e(2, 3, 4, 5) || e(3, 4, 5, 6) ? 30 : 0;
		}
		case M.largeStraight: {
			let e = (e) => [
				0,
				1,
				2,
				3,
				4
			].every((t) => r[e + t] > 0);
			return e(1) || e(2) ? 40 : 0;
		}
		case M.yahtzee: return i === 5 ? 50 : 0;
		default: return n;
	}
}
function F(e, t) {
	if (t.every((e) => e === t[0]) && e[M.yahtzee] !== null) {
		let n = e[M.yahtzee] === 50 ? 100 : 0, r = t[0], i = r - 1;
		if (e[i] === null) return [{
			cat: i,
			value: 5 * r,
			bonus: n
		}];
		let a = [
			M.threeKind,
			M.fourKind,
			M.fullHouse,
			M.smallStraight,
			M.largeStraight,
			M.chance
		].filter((t) => e[t] === null);
		if (a.length > 0) {
			let e = 5 * r;
			return a.map((t) => ({
				cat: t,
				value: t === M.fullHouse ? 25 : t === M.smallStraight ? 30 : t === M.largeStraight ? 40 : e,
				bonus: n
			}));
		}
		return Array.from({ length: 6 }, (e, t) => t).filter((t) => e[t] === null).map((e) => ({
			cat: e,
			value: 0,
			bonus: n
		}));
	}
	let n = [];
	for (let r = 0; r < 13; r += 1) e[r] === null && n.push({
		cat: r,
		value: P(r, t),
		bonus: 0
	});
	return n;
}
function I(e) {
	let t = 0;
	for (let n = 0; n < 6; n += 1) t += e[n] ?? 0;
	return t;
}
function L(e) {
	let t = 0;
	for (let n = 6; n < 13; n += 1) t += e[n] ?? 0;
	return t;
}
function R(e, t) {
	let n = I(e);
	return n + (n >= 63 ? 35 : 0) + L(e) + t * 100;
}
function z(e, t, n) {
	let r = {}, i = {}, a = {};
	for (let e of t) r[e] = Array.from({ length: 13 }, () => null), i[e] = Array.from({ length: 13 }, () => null), a[e] = 0;
	return { state: {
		players: t,
		turnIdx: 0,
		dice: null,
		held: [
			!1,
			!1,
			!1,
			!1,
			!1
		],
		rollsLeft: 2,
		scores: r,
		placedDice: i,
		bonuses: a,
		phase: "play",
		seed: n,
		rngCursor: 0
	} };
}
function ee(t, n, r) {
	if (t.phase !== "play") return { code: "games.yahtzee.errNotYourTurn" };
	let i = t.players[t.turnIdx];
	if (r.by !== i) return { code: "games.yahtzee.errNotYourTurn" };
	if (n.type === "hold") {
		if (t.dice === null) return { code: "games.yahtzee.errNeedRoll" };
		if (t.rollsLeft === 0) return { code: "games.yahtzee.errNoRollsLeft" };
		let e = structuredClone(t);
		return e.held[n.die] = !e.held[n.die], { state: e };
	}
	if (n.type === "roll") {
		if (t.dice !== null && t.rollsLeft === 0) return { code: "games.yahtzee.errNoRollsLeft" };
		let n = structuredClone(t), r = n.rngCursor, a = n.dice === null, o = [], s = Array.from({ length: 5 }, (t, i) => !a && n.held[i] ? n.dice[i] : (o.push(i), e(n.seed, r++, 6) + 1));
		return n.rngCursor = r, n.dice = s, n.rollsLeft = a ? 2 : n.rollsLeft - 1, {
			state: n,
			fx: [{
				kind: "roll",
				rid: i,
				data: {
					dice: s,
					rolledIdx: o
				}
			}]
		};
	}
	if (t.dice === null) return { code: "games.yahtzee.errNeedRoll" };
	let a = t.scores[i], o = F(a, t.dice).find((e) => e.cat === n.cat);
	if (!o) return { code: "games.yahtzee.errBadCat" };
	let s = structuredClone(t);
	s.scores[i][n.cat] = o.value, s.placedDice ??= Object.fromEntries(s.players.map((e) => [e, Array.from({ length: 13 }, () => null)])), s.placedDice[i][n.cat] = [...t.dice], o.bonus > 0 && (s.bonuses[i] += 1);
	let c = [{
		kind: "score",
		rid: i,
		data: {
			cat: n.cat,
			value: o.value,
			bonus: o.bonus
		}
	}];
	return s.players.every((e) => s.scores[e].every((e) => e !== null)) ? (s.phase = "done", s.turnIdx = -1) : s.turnIdx = (s.turnIdx + 1) % s.players.length, s.dice = null, s.held = [
		!1,
		!1,
		!1,
		!1,
		!1
	], s.rollsLeft = 2, {
		state: s,
		fx: c
	};
}
function te(e) {
	let t = e.phase === "play" ? e.players[e.turnIdx] : null;
	return {
		public: {
			phase: e.phase,
			turn: t,
			dice: e.dice,
			held: e.held,
			rollsLeft: e.rollsLeft,
			scores: e.scores,
			placedDice: e.placedDice ?? Object.fromEntries(e.players.map((e) => [e, Array.from({ length: 13 }, () => null)])),
			bonuses: e.bonuses,
			options: t !== null && e.dice !== null ? F(e.scores[t], e.dice) : null
		},
		private: {}
	};
}
function ne(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = R(e.scores[n], e.bonuses[n]);
	let n = [...e.players].sort((e, n) => t[n] - t[e]), r = t[n[0]];
	return {
		phase: "done",
		winner: n.filter((e) => t[e] === r),
		ranking: n,
		scores: t
	};
}
var re = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: C,
	schemas: {
		action: k,
		publicView: A,
		privateView: j
	},
	setup: z,
	reduce: ee,
	viewFor: te,
	status: ne
}, ie = {
	1: [[1, 1]],
	2: [[0, 0], [2, 2]],
	3: [
		[0, 0],
		[1, 1],
		[2, 2]
	],
	4: [
		[0, 0],
		[2, 0],
		[0, 2],
		[2, 2]
	],
	5: [
		[0, 0],
		[2, 0],
		[1, 1],
		[0, 2],
		[2, 2]
	],
	6: [
		[0, 0],
		[2, 0],
		[0, 1],
		[2, 1],
		[0, 2],
		[2, 2]
	]
}, ae = [
	"games.yahtzee.catAces",
	"games.yahtzee.catTwos",
	"games.yahtzee.catThrees",
	"games.yahtzee.catFours",
	"games.yahtzee.catFives",
	"games.yahtzee.catSixes",
	"games.yahtzee.catThreeKind",
	"games.yahtzee.catFourKind",
	"games.yahtzee.catFullHouse",
	"games.yahtzee.catSmallStraight",
	"games.yahtzee.catLargeStraight",
	"games.yahtzee.catYahtzee",
	"games.yahtzee.catChance"
];
function B({ value: e, size: t = 40, mini: n = !1, ghost: r = !1 }) {
	let i = 40 / 3;
	return /* @__PURE__ */ f("svg", {
		width: t,
		height: t,
		viewBox: "0 0 40 40",
		"aria-hidden": !0,
		className: `yz-die-face ${n ? "yz-mini-die" : ""} ${r ? "yz-die-ghost" : ""}`,
		children: ie[e].map(([e, t], n) => /* @__PURE__ */ f("circle", {
			cx: e * i + i / 2,
			cy: t * i + i / 2,
			r: i * .28,
			fill: "var(--yz-ink, #174881)"
		}, n))
	});
}
function V(e) {
	let t = e.public;
	return /* @__PURE__ */ f(U, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function H() {
	let e = r(null);
	return n(() => {
		let t = e.current, n = t?.querySelector(".game-screen-layout");
		if (!t || !n) return;
		let r = window.matchMedia("(orientation: landscape)"), i = [
			"pad",
			"gap",
			"top",
			"side",
			"row-h",
			"head",
			"label",
			"score",
			"chip",
			"mini",
			"cell-pad",
			"die",
			"roll",
			"avatar"
		], a = () => {
			delete t.dataset.yzLayout;
			for (let e of i) n.style.removeProperty(`--yz-${e}`);
		}, o = () => {
			let { width: e, height: i } = t.getBoundingClientRect();
			if (!r.matches || e < 1e3 || i < 600) {
				a();
				return;
			}
			let o = Math.max(6, Math.min(e, i) * .008), s = o, c = Math.max(64, i * .085), l = i - 2 * o - c - s, u = Math.max(260, Math.min((e - 2 * o) * .3, l * .58)), d = e - 2 * o - u - s, f = d >= 900 && l >= 540, p = f ? 4 : 8, m = Math.max(38, l * .06), h = Math.max(64, (l - 6 - m - 3 * o - (p - 1) * s) / p), g = (d - 6 - 2 * o - 2 * s - (f ? 2 * s : 0)) / (f ? 4 : 2), _ = Math.max(6, h * .075), v = Math.max(20, Math.min(h * .34, (g - 2 * _) / 5.8)), y = Math.max(56, l * .14), b = Math.max(20, l * .045), x = Math.max(42, Math.min((u - 4 * o - s) / 2 - 16, (l - y - b - 6 * o - 3 * s) / 3 - 20)), S = {
				pad: o,
				gap: s,
				top: c,
				side: u,
				"row-h": h,
				head: m,
				label: Math.max(13, Math.min(h * .3, g * .1)),
				score: Math.max(20, Math.min(h * .4, g * .18)),
				chip: Math.max(30, Math.min(h * .5, g * .26)),
				mini: v,
				"cell-pad": _,
				die: x,
				roll: y,
				avatar: c * .58
			}, C = f ? "wide" : "side";
			t.dataset.yzLayout !== C && (t.dataset.yzLayout = C);
			for (let [e, t] of Object.entries(S)) {
				let r = `${t.toFixed(4)}px`;
				n.style.getPropertyValue(`--yz-${e}`) !== r && n.style.setProperty(`--yz-${e}`, r);
			}
		}, s = new ResizeObserver(o);
		return s.observe(t), r.addEventListener("change", o), o(), () => {
			s.disconnect(), r.removeEventListener("change", o), a();
		};
	}, []), e;
}
function U({ pub: e, members: t, myRid: n, send: r }) {
	let a = c(), o = H(), s = e.phase === "play" && e.turn === n, [l, d] = i({
		turn: e.turn,
		rid: null
	}), p = (l.turn === e.turn ? l.rid : null) ?? e.turn ?? n, m = e.scores[p] ?? e.scores[Object.keys(e.scores)[0]], h = e.placedDice[p] ?? Array.from({ length: 13 }, () => null), g = s && p === n && e.options !== null ? e.options : null, _ = new Map((g ?? []).map((e) => [e.cat, e])), v = g?.length ? Math.max(...g.map((e) => e.value)) : null, y = t.find((e) => e.rid === p)?.name ?? p;
	return /* @__PURE__ */ f("div", {
		ref: o,
		className: "yz-screen",
		children: /* @__PURE__ */ f(u, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ f("div", {
				className: "yz-player-rail",
				children: t.filter((t) => e.scores[t.rid]).map((t) => {
					let n = e.phase === "play" && e.turn === t.rid;
					return /* @__PURE__ */ f(W, {
						rid: t.rid,
						name: t.name,
						score: R(e.scores[t.rid], e.bonuses[t.rid] ?? 0),
						current: n,
						picked: p === t.rid,
						hint: n ? e.dice === null ? a("games.yahtzee.roll") : a("games.yahtzee.tapScore") : a("games.yahtzee.waitingShort"),
						onPick: () => d({
							turn: e.turn,
							rid: t.rid
						})
					}, t.rid);
				})
			}),
			actionsHeight: "yz-actions-height",
			actions: /* @__PURE__ */ f(q, {
				pub: e,
				myTurn: s,
				onRoll: () => r({ type: "roll" }),
				onHold: (e) => r({
					type: "hold",
					die: e
				})
			}),
			children: /* @__PURE__ */ f(G, {
				card: m,
				placedDice: h,
				bonuses: e.bonuses[p] ?? 0,
				title: a("games.yahtzee.cardOf", { name: y }),
				optionOf: _,
				bestValue: v,
				onScore: (e) => r({
					type: "score",
					cat: e
				})
			})
		})
	});
}
function W({ rid: e, name: t, score: n, current: r, picked: i, hint: s, onPick: c }) {
	let { ref: l } = a(`seat:${e}`);
	return /* @__PURE__ */ p("button", {
		ref: l,
		type: "button",
		onClick: c,
		"aria-pressed": i,
		className: `yz-player ${r ? "is-current" : ""} ${i ? "is-picked" : ""}`,
		children: [
			/* @__PURE__ */ f("span", {
				className: "yz-player-avatar",
				"aria-hidden": !0,
				children: t.slice(0, 1)
			}),
			/* @__PURE__ */ p("span", {
				className: "yz-player-copy",
				children: [/* @__PURE__ */ f("span", {
					className: "yz-player-name",
					children: t
				}), /* @__PURE__ */ f("span", {
					className: "yz-player-hint",
					children: s
				})]
			}),
			/* @__PURE__ */ f(o, {
				value: n,
				className: "yz-player-score"
			})
		]
	});
}
function G({ card: e, placedDice: t, bonuses: n, title: r, optionOf: i, bestValue: a, onScore: o }) {
	let s = c(), u = I(e), d = u >= 63, m = (n) => {
		let r = i.get(n) ?? null;
		return /* @__PURE__ */ f(K, {
			cat: n,
			value: e[n],
			dice: t[n] ?? null,
			option: r,
			best: r !== null && r.value === a,
			onTap: () => o(n)
		}, n);
	};
	return /* @__PURE__ */ p("div", {
		className: "yz-board",
		role: "region",
		"aria-label": r,
		children: [
			/* @__PURE__ */ f(l, {
				kind: "sheen",
				base: "#0f70c3",
				className: "yz-board-texture"
			}),
			/* @__PURE__ */ p("div", {
				className: "yz-board-head",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ f("span", { children: s("games.yahtzee.upperZone") }), /* @__PURE__ */ f("span", { children: s("games.yahtzee.comboZone") })]
			}),
			/* @__PURE__ */ f("div", {
				className: "yz-board-scroll",
				tabIndex: 0,
				"aria-label": r,
				children: /* @__PURE__ */ p("div", {
					className: "yz-board-columns",
					children: [/* @__PURE__ */ p("div", {
						className: "yz-column",
						children: [
							Array.from({ length: 6 }, (e, t) => m(t)),
							/* @__PURE__ */ p("div", {
								className: "yz-subtotal",
								children: [
									/* @__PURE__ */ f("span", { children: s("games.yahtzee.upperSubtotal") }),
									/* @__PURE__ */ p("strong", { children: [
										u,
										" / ",
										63
									] }),
									/* @__PURE__ */ f("span", {
										className: "yz-progress",
										"aria-hidden": !0,
										children: /* @__PURE__ */ f("span", { style: { width: `${Math.min(100, u / 63 * 100)}%` } })
									})
								]
							}),
							/* @__PURE__ */ p("div", {
								className: `yz-award ${d ? "is-earned" : ""}`,
								children: [/* @__PURE__ */ f("span", { children: s("games.yahtzee.upperGoal") }), /* @__PURE__ */ f("strong", { children: s("games.yahtzee.upperPrize") })]
							})
						]
					}), /* @__PURE__ */ p("div", {
						className: "yz-column",
						children: [Array.from({ length: 7 }, (e, t) => m(6 + t)), /* @__PURE__ */ p("div", {
							className: "yz-jackpot",
							children: [/* @__PURE__ */ p("div", {
								className: "yz-jackpot-title",
								children: [/* @__PURE__ */ f("img", {
									src: "games/yahtzee/yacht-mark.webp",
									alt: ""
								}), /* @__PURE__ */ f("span", { children: s("games.yahtzee.bonusRow") })]
							}), /* @__PURE__ */ f("strong", { children: s("games.yahtzee.bonusCount", { n }) })]
						})]
					})]
				})
			})
		]
	});
}
function K({ cat: e, value: t, dice: n, option: r, best: i, onTap: o }) {
	let s = c(), { ref: l } = a(`cell:${e}`), u = s(ae[e]), d = t !== null, m = r !== null, h = d ? n ?? Array.from({ length: 5 }, () => 0) : null, g = d ? `${u} ${t}` : r ? `${u} ${r.value}${r.bonus ? ` +${r.bonus}` : ""}` : u;
	return /* @__PURE__ */ p("button", {
		ref: l,
		type: "button",
		disabled: !m,
		onClick: o,
		"aria-label": g,
		className: `yz-cell ${d ? "is-filled" : ""} ${m ? "is-option" : ""} ${i ? "is-best" : ""}`,
		children: [/* @__PURE__ */ p("span", {
			className: "yz-cell-top",
			children: [/* @__PURE__ */ p("span", {
				className: "yz-cell-label",
				children: [e < 6 && /* @__PURE__ */ f("span", {
					className: "yz-pip",
					children: e + 1
				}), /* @__PURE__ */ f("span", {
					className: "yz-label-text",
					children: u
				})]
			}), d ? /* @__PURE__ */ f("span", {
				className: `yz-chip ${t === 0 ? "is-zero" : ""}`,
				children: t
			}) : r ? /* @__PURE__ */ p("span", {
				className: "yz-option-score",
				children: [r.bonus > 0 && /* @__PURE__ */ p("small", { children: ["+", r.bonus] }), /* @__PURE__ */ f("span", {
					className: r.value === 0 ? "is-zero" : "",
					children: r.value
				})]
			}) : /* @__PURE__ */ f("span", {
				className: "yz-empty-score",
				"aria-hidden": !0,
				children: "○"
			})]
		}), h && /* @__PURE__ */ f("span", {
			className: "yz-mini-dice",
			"aria-hidden": !0,
			children: h.map((e, t) => e === 0 ? /* @__PURE__ */ f("span", {
				className: "yz-unknown-die",
				children: "?"
			}, t) : /* @__PURE__ */ f(B, {
				value: e,
				size: 20,
				mini: !0
			}, t))
		})]
	});
}
function q({ pub: e, myTurn: t, onRoll: n, onHold: r }) {
	let i = c(), { ref: o, hidden: s } = a("tray"), l = t && e.dice !== null && e.rollsLeft > 0, u = t && (e.dice === null || e.rollsLeft > 0), d = u ? e.dice === null ? i("games.yahtzee.roll") : i("games.yahtzee.reroll", { n: e.rollsLeft }) : i(t ? "games.yahtzee.chooseScore" : "games.yahtzee.waitingShort");
	return /* @__PURE__ */ p("div", {
		className: "yz-tray",
		children: [/* @__PURE__ */ p("div", {
			className: "yz-tray-deck",
			children: [/* @__PURE__ */ p("div", {
				className: "yz-tray-caption",
				children: [/* @__PURE__ */ f("strong", { children: i("games.yahtzee.fiveDice") }), /* @__PURE__ */ f("span", { children: e.dice === null ? i("games.yahtzee.firstDice") : i("games.yahtzee.rollsRemain", { n: e.rollsLeft }) })]
			}), /* @__PURE__ */ f("div", {
				ref: o,
				className: "yz-dice-row",
				style: { visibility: s ? "hidden" : void 0 },
				children: Array.from({ length: 5 }, (t, n) => /* @__PURE__ */ f(oe, {
					index: n,
					value: e.dice?.[n] ?? null,
					held: e.held[n],
					canHold: l,
					onHold: () => r(n),
					heldLabel: i("games.yahtzee.heldBadge")
				}, n))
			})]
		}), /* @__PURE__ */ f("button", {
			type: "button",
			disabled: !u,
			onClick: n,
			className: "yz-roll-button",
			children: d
		})]
	});
}
function oe({ index: e, value: t, held: n, canHold: r, onHold: i, heldLabel: o }) {
	let { ref: s, hidden: c } = a(`die:${e}`);
	return /* @__PURE__ */ p("button", {
		type: "button",
		disabled: !r,
		onClick: i,
		"aria-pressed": n,
		"aria-label": t === null ? void 0 : `${t} · ${n ? o : ""}`,
		className: `yz-die-slot ${n ? "is-held" : ""}`,
		style: { visibility: c ? "hidden" : void 0 },
		children: [/* @__PURE__ */ f("span", {
			ref: s,
			className: "yz-die-object",
			children: /* @__PURE__ */ f(B, {
				value: t ?? 5,
				size: 42,
				ghost: t === null
			})
		}), n && /* @__PURE__ */ f("span", {
			className: "yz-held-badge",
			children: o
		})]
	});
}
//#endregion
//#region src/games/yahtzee/bot.ts
function J(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var se = [
	"games.yahtzee.catAces",
	"games.yahtzee.catTwos",
	"games.yahtzee.catThrees",
	"games.yahtzee.catFours",
	"games.yahtzee.catFives",
	"games.yahtzee.catSixes",
	"games.yahtzee.catThreeKind",
	"games.yahtzee.catFourKind",
	"games.yahtzee.catFullHouse",
	"games.yahtzee.catSmallStraight",
	"games.yahtzee.catLargeStraight",
	"games.yahtzee.catYahtzee",
	"games.yahtzee.catChance"
];
function Y(e, t, n) {
	let r = t + n;
	return e < 6 && (r += (t - 3 * (e + 1)) * .3), e === M.yahtzee && (r += 8), e === M.chance && --r, r;
}
function ce(e, t) {
	let n = -Infinity;
	for (let r of F(e, t)) n = Math.max(n, Y(r.cat, r.value, r.bonus));
	return n;
}
function le(e, t, n) {
	let r = 6 ** n, i = 0;
	for (let a = 0; a < r; a += 1) {
		let r = a, o = [...t];
		for (let e = 0; e < n; e += 1) o.push(r % 6 + 1), r = Math.floor(r / 6);
		i += ce(e, o);
	}
	return i / r;
}
var ue = (e, t) => {
	let n = e.public;
	if (n.phase !== "play" || n.turn !== t.rid) return null;
	if (n.dice === null) return { action: { type: "roll" } };
	let r = n.options;
	if (!r || r.length === 0) return null;
	if (t.difficulty === "weak") {
		if (n.rollsLeft > 0) {
			let e = J([!0, !1]), t = Array.from({ length: 5 }, () => J([!0, !1])).findIndex((e, t) => e !== n.held[t]);
			if (e && t >= 0) return { action: {
				type: "hold",
				die: t
			} };
			if (J([!0, !1])) return { action: { type: "roll" } };
		}
		return { action: {
			type: "score",
			cat: J(r).cat
		} };
	}
	let i = n.scores[t.rid], a = r[0].cat, o = -Infinity;
	for (let e of r) {
		let t = Y(e.cat, e.value, e.bonus);
		t > o && (o = t, a = e.cat);
	}
	if (n.rollsLeft > 0) {
		let e = 31, t = o;
		for (let r = 0; r < 31; r += 1) {
			let a = [];
			for (let e = 0; e < 5; e += 1) r & 1 << e && a.push(n.dice[e]);
			let o = le(i, a, 5 - a.length);
			o > t && (t = o, e = r);
		}
		if (e !== 31 && t > o + 1.2) {
			for (let t = 0; t < 5; t += 1) if (!!(e & 1 << t) !== n.held[t]) return { action: {
				type: "hold",
				die: t
			} };
			return { action: { type: "roll" } };
		}
	}
	return { action: {
		type: "score",
		cat: a
	} };
}, de = (e, t, n) => {
	if (e.type === "roll") return t.public.dice === null ? n("games.yahtzee.describeRoll") : n("games.yahtzee.describeReroll");
	if (e.type === "hold") return n("games.yahtzee.describeHold", { value: t.public.dice?.[e.die] ?? 0 });
	if (e.type === "score") {
		let r = t.public.options?.find((t) => t.cat === e.cat);
		return n("games.yahtzee.describeScore", {
			cat: n(se[e.cat]),
			n: r?.value ?? 0
		});
	}
	return "";
}, X = [
	"一点(1 的总和)",
	"两点",
	"三点",
	"四点",
	"五点",
	"六点",
	"三条(同点≥3,计总点)",
	"四条(同点≥4,计总点)",
	"葫芦(25)",
	"小顺(30)",
	"大顺(40)",
	"快艇(50)",
	"机会(计总点)"
], fe = (e) => e.map((e, t) => e === null ? null : `${X[t]}=${e}`).filter(Boolean).join("; ") || "(全空)", pe = (e) => e.slice(0, 6).reduce((e, t) => e + (t ?? 0), 0), me = {
	needsAction: (e, t) => e.public.phase === "play" && e.public.turn === t.rid,
	describeView(e, t) {
		let n = e.public, r = ["回合制:每回合最多掷 3 次(首掷+2 次重掷),重掷前可用 hold 保留任意骰子,然后选一个空格记分。上区(0-5 格)合计 ≥63 额外 +35。"], i = n.scores[t.rid];
		return i && r.push(`你的计分卡: ${fe(i)};上区小计 ${pe(i)}/63;快艇奖励筹码 ${n.bonuses[t.rid] ?? 0} 个(每个 100 分)`), r.push(`各玩家总分: ${Object.keys(n.scores).map((e) => `${e === t.rid ? "你" : e}=${n.scores[e].reduce((e, t) => e + (t ?? 0), 0)}`).join(", ")}`), n.dice ? r.push(`当前骰面: ${n.dice.map((e, t) => `${t}:${e}${n.held[t] ? "(已保留)" : ""}`).join(" ")};剩余重掷 ${n.rollsLeft} 次`) : r.push("还没掷骰,输出 roll 行动。"), n.options && r.push(`可记分的格子(格号: 分数): ${n.options.map((e) => `${e.cat}(${X[e.cat]}): ${e.value}${e.bonus ? ` +奖励${e.bonus}` : ""}`).join("; ")}`), r.push("行动:roll(掷/重掷未保留的骰子)/hold(切换保留某颗,die=骰子序号 0-4)/score(记分,cat=格号 0-12)。"), r.join("\n");
	},
	actionJsonSchema: { oneOf: [
		{
			type: "object",
			properties: { type: { const: "roll" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "hold" },
				die: {
					type: "integer",
					minimum: 0,
					maximum: 4
				}
			},
			required: ["type", "die"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "score" },
				cat: {
					type: "integer",
					minimum: 0,
					maximum: 12
				}
			},
			required: ["type", "cat"],
			additionalProperties: !1
		}
	] },
	parseAction(e, t, n) {
		let r = k.safeParse(e);
		if (!r.success) return null;
		let i = r.data, a = t.public;
		if (a.phase !== "play" || a.turn !== n.rid) return null;
		switch (i.type) {
			case "roll": return a.dice === null || a.rollsLeft > 0 ? i : null;
			case "hold": return a.dice !== null && a.rollsLeft > 0 ? i : null;
			case "score": return a.options?.some((e) => e.cat === i.cat) ? i : null;
		}
	}
};
//#endregion
//#region src/games/yahtzee/fx.tsx
function Z(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
var Q = {
	roll(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.dice) || !Array.isArray(n?.rolledIdx)) return null;
		let r = n.dice, i = n.rolledIdx, a = t.anchor("tray");
		if (!a) return null;
		let o = t.queued > 0;
		return {
			ms: o ? 300 : 520 + i.length * 60,
			hide: o ? void 0 : i.map((e) => `die:${e}`),
			node: /* @__PURE__ */ f(d, { children: i.map((e, n) => {
				let i = t.anchor(`die:${e}`) ?? {
					x: a.x + a.w / 2 - 20,
					y: a.y + a.h / 2 - 20,
					w: 40,
					h: 40
				};
				return /* @__PURE__ */ f(h, {
					from: {
						...i,
						y: i.y - 110
					},
					to: i,
					ms: o ? 180 : 400,
					delay: o ? 0 : n * 60,
					children: /* @__PURE__ */ f("span", {
						className: "yz-flying-die",
						style: {
							width: i.w,
							height: i.h,
							borderRadius: i.w * .19
						},
						children: /* @__PURE__ */ f(B, {
							value: r[e],
							size: i.w
						})
					})
				}, e);
			}) })
		};
	},
	score(e, t) {
		let n = e.data;
		if (typeof n?.cat != "number" || typeof n?.value != "number") return null;
		let r = t.anchor(`cell:${n.cat}`), i = r ?? Z(t, e.rid);
		if (!i) return null;
		let a = Math.max(14, Math.min(i.w * .08, i.h * .18)), o = typeof n.bonus == "number" ? n.bonus : 0;
		return {
			ms: 750,
			node: /* @__PURE__ */ p(d, { children: [
				r && /* @__PURE__ */ f(g, {
					at: r,
					ms: 500
				}),
				/* @__PURE__ */ f(m, {
					at: i,
					ms: 700,
					children: /* @__PURE__ */ f("span", {
						style: { fontSize: a },
						className: "rounded-lg border-2 border-ink bg-surface px-1.5 font-mono text-sm font-black tabular-nums shadow-[2px_2px_0_var(--color-ink)]",
						children: n.value > 0 ? `+${n.value}` : "0"
					})
				}),
				o > 0 && /* @__PURE__ */ f(m, {
					at: Z(t, e.rid) ?? i,
					ms: 900,
					delay: 250,
					children: /* @__PURE__ */ p("span", {
						style: { fontSize: a },
						className: "rounded-lg border-2 border-ink bg-warn px-1.5 font-mono text-sm font-black tabular-nums text-warn-ink shadow-[2px_2px_0_var(--color-ink)]",
						children: ["+", o]
					})
				})
			] })
		};
	}
};
//#endregion
//#region src/games/yahtzee/game-over-row.tsx
function $({ public: e, rid: t }) {
	let n = c(), r = e, i = r.scores[t];
	if (!i) return null;
	let a = I(i);
	return /* @__PURE__ */ f("div", {
		className: "mt-1 font-mono text-xs tabular-nums text-ink-soft",
		children: n("games.yahtzee.overLine", {
			upper: a,
			bonus: a >= 63 ? "(+35)" : "",
			lower: L(i),
			yb: (r.bonuses[t] ?? 0) * 100
		})
	});
}
//#endregion
//#region src/games/yahtzee/game-over.tsx
var he = [
	"games.yahtzee.catAces",
	"games.yahtzee.catTwos",
	"games.yahtzee.catThrees",
	"games.yahtzee.catFours",
	"games.yahtzee.catFives",
	"games.yahtzee.catSixes",
	"games.yahtzee.catThreeKind",
	"games.yahtzee.catFourKind",
	"games.yahtzee.catFullHouse",
	"games.yahtzee.catSmallStraight",
	"games.yahtzee.catLargeStraight",
	"games.yahtzee.catYahtzee",
	"games.yahtzee.catChance"
];
function ge(e) {
	let t = A.safeParse(e.public), n = e.result.ranking;
	return t.success && t.data.phase === "done" && n.length >= 1 && n.length <= 6 && new Set(n).size === n.length && n.every((e) => t.data.scores[e]) ? /* @__PURE__ */ f(ve, {
		...e,
		pub: t.data
	}) : /* @__PURE__ */ f(x, {
		result: e.result,
		members: e.members,
		myRid: e.myRid,
		accent: C.accent,
		onPlayAgain: e.onPlayAgain,
		onBackToLobby: e.onBackToLobby,
		renderRowExtra: t.success ? (n) => /* @__PURE__ */ f($, {
			public: t.data,
			rid: n,
			myRid: e.myRid
		}) : void 0
	});
}
function _e(e, t) {
	let i = r(null);
	return n(() => {
		let n = i.current;
		if (!n) return;
		let r = window.matchMedia("(orientation: landscape)"), a = [
			"pad",
			"gap",
			"top-h",
			"actions-h",
			"rank-w",
			"rank-h",
			"sheet-head-h",
			"zone-head-h",
			"row-h",
			"cell-pad",
			"cell-label",
			"chip-size",
			"mini-size",
			"avatar-size",
			"rank-name",
			"rank-score",
			"rank-meta",
			"heading-font",
			"name-font",
			"total-font",
			"button-font",
			"rail-h"
		], o = () => {
			let { width: i, height: a } = n.getBoundingClientRect(), o = r.matches && i >= 1e3 && a >= 600, s = r.matches && i >= 600 && !o, c = o ? "large" : s ? "low" : "flow", l = (o || s) && e > 1, u = s && e === 1, d = Math.max(4, Math.min(i, a) * .008), f = Math.max(6, d), p = o ? Math.max(48, a * .065) : 40, m = t > 1 && !o && !s ? 104 : t > 0 ? Math.max(48, o ? a * .075 : 48) : Math.max(40, o ? a * .06 : 40), h = a - 2 * d - p - m - 2 * f, g = i - 2 * d, _ = l ? o ? Math.min(g * .26, h * .55) : Math.max(160, g * .28) : g, v = l ? o ? (h - (e - 1) * f) / e : 72 : u ? 72 : o ? Math.max(88, a * .1) : 88, y = l ? g - _ - f : g, b = l ? h : h - v - f, x = u ? 0 : o ? Math.max(64, a * .075) : 60, S = o ? Math.max(40, a * .045) : 34, C = (y - 6 - 2 * d - 2 * f) / 2, w = o && C >= 420 && b >= 480, T = w ? 4 : 8, E = Math.max(72, (b - 6 - x - S - 3 * d - (T - 1) * f) / T), D = w ? (C - f) / 2 : C, O = Math.max(6, E * .07), k = Math.max(13, Math.min(E * .2, D * .09)), A = Math.max(20, Math.min(E * .3, (D - 2 * O) / 5.8)), j = o && l && v >= 230, M = l && o ? j ? Math.min(v * .38, _ * .42) : Math.min(v * .58, _ * .2) : o ? v * .65 : 44, N = l && o ? Math.max(18, Math.min(v * (j ? .1 : .21), _ * .075)) : o ? v * .26 : 16, P = l && o ? Math.max(30, Math.min(v * (j ? .2 : .38), _ * .18)) : o ? v * .45 : 30, F = l && o ? Math.max(12, Math.min(v * .08, 20)) : o ? v * .15 : 11;
			n.dataset.yzOver = c, n.dataset.yzOverColumns = String(l), n.dataset.yzOverWide = String(w), n.dataset.yzOverVerticalRank = String(j), n.dataset.yzOverSingle = String(e === 1);
			let I = {
				pad: d,
				gap: f,
				"top-h": p,
				"actions-h": m,
				"rank-w": _,
				"rank-h": v,
				"sheet-head-h": x,
				"zone-head-h": S,
				"row-h": E,
				"cell-pad": O,
				"cell-label": k,
				"chip-size": Math.max(30, Math.min(E * .45, D * .23)),
				"mini-size": A,
				"avatar-size": M,
				"rank-name": N,
				"rank-score": P,
				"rank-meta": F,
				"heading-font": p * .52,
				"name-font": o ? Math.max(22, Math.min(x * .35, y * .04)) : 17,
				"total-font": Math.max(30, Math.min(x * .65, y * .1)),
				"button-font": o ? m * .32 : 17,
				"rail-h": v
			};
			for (let [e, t] of Object.entries(I)) {
				let r = `${t.toFixed(4)}px`;
				n.style.getPropertyValue(`--yz-over-${e}`) !== r && n.style.setProperty(`--yz-over-${e}`, r);
			}
		}, s = new ResizeObserver(o);
		return s.observe(n), r.addEventListener("change", o), o(), () => {
			s.disconnect(), r.removeEventListener("change", o), delete n.dataset.yzOver, delete n.dataset.yzOverColumns, delete n.dataset.yzOverWide, delete n.dataset.yzOverVerticalRank, delete n.dataset.yzOverSingle;
			for (let e of a) n.style.removeProperty(`--yz-over-${e}`);
		};
	}, [e, t]), i;
}
function ve({ pub: e, result: t, members: n, myRid: r, onPlayAgain: a, onBackToLobby: o }) {
	let l = c(), d = s((e) => e.locale), m = _e(t.ranking.length, Number(!!a) + Number(!!o)), [h, g] = i(null), x = h && t.ranking.includes(h) ? h : t.ranking[0], C = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? S(t, d) : e;
	}, w = e.scores[x], T = I(w), E = e.bonuses[x] ?? 0, D = (t) => {
		let n = w[t], r = n === null ? null : e.placedDice[x]?.[t];
		return /* @__PURE__ */ p("div", {
			className: "yz-over-cell",
			"data-history": !!r,
			"data-empty": n === null,
			children: [
				/* @__PURE__ */ p("span", {
					className: "yz-over-cell-name",
					children: [t < 6 && /* @__PURE__ */ f("b", {
						className: "yz-over-pip",
						"aria-hidden": !0,
						children: t + 1
					}), /* @__PURE__ */ f("span", { children: l(he[t]) })]
				}),
				/* @__PURE__ */ f("b", {
					className: "yz-over-chip",
					"data-zero": n === 0,
					children: n ?? "—"
				}),
				r && /* @__PURE__ */ f("span", {
					className: "yz-over-dice",
					"aria-hidden": !0,
					children: r.map((e, t) => /* @__PURE__ */ f(B, {
						value: e,
						size: 20,
						mini: !0
					}, t))
				})
			]
		}, t);
	};
	return /* @__PURE__ */ p("div", {
		ref: m,
		className: "yz-over",
		children: [t.winner.length > 0 && /* @__PURE__ */ f(b, {}), /* @__PURE__ */ f(u, {
			adaptive: !0,
			scroll: !1,
			actionsHeight: "yz-over-action-height",
			banner: /* @__PURE__ */ f("header", {
				className: "yz-over-heading",
				children: /* @__PURE__ */ f("h1", { children: l("session.result.title") })
			}),
			actions: a || o ? /* @__PURE__ */ p("div", {
				className: "yz-over-actions",
				children: [a && /* @__PURE__ */ f("button", {
					type: "button",
					className: "yz-over-play",
					onClick: a,
					children: l("session.result.playAgain")
				}), o && /* @__PURE__ */ f("button", {
					type: "button",
					className: "yz-over-back",
					onClick: o,
					children: l("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ f("p", {
				className: "yz-over-wait",
				children: l("session.result.waitHost")
			}),
			children: /* @__PURE__ */ p("div", {
				className: "yz-over-body",
				children: [/* @__PURE__ */ f("nav", {
					className: "yz-over-ranking",
					"data-single": t.ranking.length === 1,
					"aria-label": l("session.result.title"),
					children: /* @__PURE__ */ f("ol", { children: t.ranking.map((e, i) => {
						let a = n.find((t) => t.rid === e), o = t.autopilot?.[e], s = C(e);
						return /* @__PURE__ */ f("li", { children: /* @__PURE__ */ p("button", {
							type: "button",
							className: "yz-over-person",
							"aria-pressed": e === x,
							onClick: () => g(e),
							children: [
								/* @__PURE__ */ p("span", {
									className: "yz-over-avatar",
									style: { backgroundColor: y[(a?.colorIndex ?? 0) % y.length].hex },
									children: [
										a && /* @__PURE__ */ f("img", {
											src: _[a.avatar % _.length],
											alt: "",
											draggable: !1
										}),
										/* @__PURE__ */ f("b", {
											className: "yz-over-rank",
											children: i + 1
										}),
										t.winner.includes(e) && /* @__PURE__ */ f("span", {
											className: "yz-over-crown",
											"aria-hidden": !0,
											children: "👑"
										})
									]
								}),
								/* @__PURE__ */ p("span", {
									className: "yz-over-person-copy",
									children: [/* @__PURE__ */ f("strong", {
										title: s,
										children: s
									}), /* @__PURE__ */ p("span", {
										className: "yz-over-person-meta",
										children: [e === r && /* @__PURE__ */ f("small", { children: l("lobby.you") }), o !== void 0 && o > 0 && /* @__PURE__ */ p("small", { children: [/* @__PURE__ */ f(v, { size: 14 }), l("session.autopilot.share", { n: Math.round(o * 100) })] })]
									})]
								}),
								/* @__PURE__ */ f("b", {
									className: "yz-over-rank-score",
									children: t.scores?.[e] ?? "—"
								})
							]
						}) }, e);
					}) })
				}), /* @__PURE__ */ p("section", {
					className: "yz-over-sheet",
					"aria-label": l("games.yahtzee.cardOf", { name: C(x) }),
					children: [
						/* @__PURE__ */ p("header", {
							className: "yz-over-sheet-head",
							children: [/* @__PURE__ */ f("h2", {
								title: C(x),
								children: C(x)
							}), /* @__PURE__ */ p("span", { children: [l("games.yahtzee.totalRow"), /* @__PURE__ */ f("b", { children: t.scores?.[x] ?? "—" })] })]
						}),
						/* @__PURE__ */ p("div", {
							className: "yz-over-zone-head",
							children: [/* @__PURE__ */ f("span", { children: l("games.yahtzee.upperZone") }), /* @__PURE__ */ p("span", { children: [
								l("games.yahtzee.overLowerSubtotal"),
								" ",
								/* @__PURE__ */ f("b", { children: L(w) })
							] })]
						}),
						/* @__PURE__ */ f("div", {
							className: "yz-over-paper-scroll",
							tabIndex: 0,
							"aria-label": l("games.yahtzee.cardOf", { name: C(x) }),
							children: /* @__PURE__ */ p("div", {
								className: "yz-over-zones",
								children: [/* @__PURE__ */ p("div", {
									className: "yz-over-zone",
									children: [
										Array.from({ length: 6 }, (e, t) => D(t)),
										/* @__PURE__ */ p("div", {
											className: "yz-over-ledger",
											children: [/* @__PURE__ */ f("span", { children: l("games.yahtzee.upperSubtotal") }), /* @__PURE__ */ p("strong", { children: [
												T,
												" / ",
												63
											] })]
										}),
										/* @__PURE__ */ p("div", {
											className: "yz-over-ledger",
											children: [/* @__PURE__ */ f("span", { children: l("games.yahtzee.upperBonusRow") }), /* @__PURE__ */ p("strong", { children: ["+", T >= 63 ? 35 : 0] })]
										})
									]
								}), /* @__PURE__ */ p("div", {
									className: "yz-over-zone",
									children: [Array.from({ length: 7 }, (e, t) => D(t + 6)), /* @__PURE__ */ p("div", {
										className: "yz-over-ledger yz-over-bonus",
										children: [/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f("img", {
											src: "games/yahtzee/yacht-mark.webp",
											alt: ""
										}), l("games.yahtzee.bonusRow")] }), /* @__PURE__ */ p("strong", { children: [
											"+",
											E * 100,
											" ",
											/* @__PURE__ */ p("small", { children: [
												"(",
												l("games.yahtzee.bonusCount", { n: E }),
												")"
											] })
										] })]
									})]
								})]
							})
						})
					]
				})]
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/yahtzee/entry.tsx
var ye = {
	definition: re,
	View: V,
	bot: ue,
	describe: de,
	llm: me,
	fx: Q,
	OverView: ge,
	RowView: $,
	locales: {
		zh: {
			name: "快艇骰子",
			desc: "五颗骰子掷三次，凑组合填满计分卡",
			rules: "目标:13 个计分格全部填满后,总分最高者获胜。\n流程:\n· 轮到你时掷出 5 颗骰子;每回合最多掷 3 次,第 2、3 次可保留任意骰子,只重掷其余。\n· 每次掷骰后都可以停手,在计分卡上选一个空格记分;骰面不配合的格子只能记 0 分。\n计分:\n· 上半区(一点至六点):记对应点数骰子的点数总和;合计达 63 分时额外奖励 35 分。\n· 三条、四条:同点骰子至少 3 颗、4 颗时,记 5 颗骰子的总和,否则记 0 分。\n· 葫芦：三颗骰子点数相同，另外两颗组成一对，获得25分。\n· 小顺：包含四个连续点数，获得30分。\n· 大顺：五颗骰子的点数连续，获得40分。\n· 快艇：五颗骰子点数相同，获得50分。\n· 机会：获得五颗骰子的点数总和对应的分数。\n· 快艇格已记分后又掷出快艇:若快艇格记的是 50 分,每次奖励 100 分。\n· 并且必须记到对应点数的上半区空格。\n· 该格已填则当百搭,记到下半区任意空格(顺子、葫芦按满分记)。\n· 下半区也全满时,在任意上半区空格记 0 分。",
			catAces: "一点",
			catTwos: "两点",
			catThrees: "三点",
			catFours: "四点",
			catFives: "五点",
			catSixes: "六点",
			catThreeKind: "三条",
			catFourKind: "四条",
			catFullHouse: "葫芦",
			catSmallStraight: "小顺",
			catLargeStraight: "大顺",
			catYahtzee: "快艇",
			catChance: "机会",
			upperZone: "点数区 · 1—6",
			comboZone: "组合区 · 7 类",
			fiveDice: "五骰好运",
			firstDice: "先掷 5 颗",
			rollsRemain: "还可再掷 {{n}} 次",
			tapScore: "点栏即记分",
			waitingShort: "等候",
			upperGoal: "满 63",
			upperPrize: "奖 +35",
			bonusCount: "+100 × {{n}}",
			chooseScore: "点选栏位记分",
			upperSubtotal: "上半小计",
			upperBonusRow: "满 63 奖 35",
			bonusRow: "快艇奖励",
			totalRow: "总分",
			roll: "掷骰子",
			reroll: "再掷(剩 {{n}} 次)",
			rollPrompt: "轮到你，掷出 5 颗骰子",
			turnPrompt: "点骰子保留，再掷或点栏位直接记分",
			heldBadge: "留",
			scorePrompt: "点一个栏位直接记分",
			waitingRoll: "等 {{name}} 掷骰…",
			waitingScore: "等 {{name}} 记分…",
			cardOf: "{{name}} 的计分卡",
			yahtzeeBonusGain: "+{{n}} 快艇奖励!",
			overLowerSubtotal: "下半小计",
			overLine: "上半区 {{upper}}{{bonus}} · 下半区 {{lower}} · 快艇奖励 {{yb}}",
			describeRoll: "掷 5 颗骰子",
			describeReroll: "重掷未保留的骰子",
			describeHold: "切换保留 {{value}} 点骰",
			describeScore: "在「{{cat}}」记 {{n}} 分",
			errNotYourTurn: "现在轮不到你",
			errNeedRoll: "先掷骰子",
			errNoRollsLeft: "本回合掷骰次数已用完",
			errBadCat: "这个格子不能记"
		},
		en: {
			name: "Yahtzee",
			desc: "Roll five dice up to three times, fill the scorecard",
			rules: "Goal: once all 13 scoring boxes are filled, the highest total score wins.\nPlay:\n· On your turn, roll 5 dice; you may roll up to 3 times, keeping any dice and rerolling the rest on the 2nd and 3rd rolls.\n· After any roll you may stop and score one open box; a box the dice do not qualify for scores 0.\nScoring:\n· Upper section (Aces to Sixes): score the total of dice showing that number; a 63-point subtotal earns a 35-point bonus.\n· 3/4 of a Kind: with at least 3 or 4 matching dice, score the total of all 5 dice, otherwise 0.\n· Full House: Three dice of one value and two dice of another value score 25 points.\n· Small Straight: A run of four consecutive values scores 30 points.\n· Large Straight: A run of five consecutive values scores 40 points.\n· Yahtzee: Five dice of the same value score 50 points.\n· Chance: Score the total value of all five dice.\n· Rolling another Yahtzee after the Yahtzee box is filled: a 100-point bonus each time if the box holds 50.\n· It must then be scored in the matching upper-section box.\n· If that box is filled, it acts as a joker: score it in any open lower-section box (straights and full house score full value).\n· If the lower section is also full, score 0 in any open upper-section box.",
			catAces: "Aces",
			catTwos: "Twos",
			catThrees: "Threes",
			catFours: "Fours",
			catFives: "Fives",
			catSixes: "Sixes",
			catThreeKind: "3 of a Kind",
			catFourKind: "4 of a Kind",
			catFullHouse: "Full House",
			catSmallStraight: "Sm. Straight",
			catLargeStraight: "Lg. Straight",
			catYahtzee: "Yahtzee",
			catChance: "Chance",
			upperZone: "Upper · 1–6",
			comboZone: "Combos · 7",
			fiveDice: "Five lucky dice",
			firstDice: "Roll all 5",
			rollsRemain: "{{n}} rerolls left",
			tapScore: "Tap to score",
			waitingShort: "Waiting",
			upperGoal: "Reach 63",
			upperPrize: "Bonus +35",
			bonusCount: "+100 × {{n}}",
			chooseScore: "Tap a box to score",
			upperSubtotal: "Upper subtotal",
			upperBonusRow: "63 → +35",
			bonusRow: "Yahtzee bonus",
			totalRow: "Total",
			roll: "Roll",
			reroll: "Reroll ({{n}} left)",
			rollPrompt: "Your turn — roll the 5 dice",
			turnPrompt: "Tap dice to hold, reroll, or tap a box to score",
			heldBadge: "HOLD",
			scorePrompt: "Tap a box to score immediately",
			waitingRoll: "Waiting for {{name}} to roll…",
			waitingScore: "Waiting for {{name}} to score…",
			cardOf: "{{name}}'s scorecard",
			yahtzeeBonusGain: "+{{n}} Yahtzee bonus!",
			overLowerSubtotal: "Lower subtotal",
			overLine: "Upper {{upper}}{{bonus}} · Lower {{lower}} · Yahtzee bonus {{yb}}",
			describeRoll: "Roll 5 dice",
			describeReroll: "Reroll the unheld dice",
			describeHold: "Toggle hold on the {{value}} die",
			describeScore: "Score {{n}} in \"{{cat}}\"",
			errNotYourTurn: "Not your turn",
			errNeedRoll: "Roll first",
			errNoRollsLeft: "No rolls left this turn",
			errBadCat: "Cannot score that box"
		}
	}
};
//#endregion
export { ye as default };
