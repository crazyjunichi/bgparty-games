import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useT as o } from "@bgparty/sdk/i18n";
import { IconBack as s, IconCheck as c, IconClose as l, IconInfo as u, IconLayoutCover as d, IconLog as f, IconZoomIn as p, IconZoomOut as m } from "@bgparty/sdk/icons";
import { GameScreen as h } from "@bgparty/sdk/ui/game-screen";
import { LogSheet as g } from "@bgparty/sdk/ui/log-sheet";
import { usePrefersReducedMotion as _ } from "@bgparty/sdk/fx/use-reduced-motion";
import { Fragment as ee, jsx as v, jsxs as y } from "react/jsx-runtime";
import { GameOverScreen as b } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as x, OptionSection as te, OptionSwitch as ne } from "@bgparty/sdk/ui/game-options";
//#region src/games/twilightstruggle/cards.ts
var S = [
	{
		id: 1,
		key: "asiaScoring",
		ops: 0,
		side: "both",
		stage: "early",
		unique: !1,
		optional: !1,
		scoring: "asia"
	},
	{
		id: 2,
		key: "europeScoring",
		ops: 0,
		side: "both",
		stage: "early",
		unique: !1,
		optional: !1,
		scoring: "europe"
	},
	{
		id: 3,
		key: "middleEastScoring",
		ops: 0,
		side: "both",
		stage: "early",
		unique: !1,
		optional: !1,
		scoring: "middleEast"
	},
	{
		id: 4,
		key: "duckAndCover",
		ops: 3,
		side: "us",
		stage: "early",
		unique: !1,
		optional: !1
	},
	{
		id: 5,
		key: "fiveYearPlan",
		ops: 3,
		side: "us",
		stage: "early",
		unique: !1,
		optional: !1
	},
	{
		id: 6,
		key: "theChinaCard",
		ops: 4,
		side: "both",
		stage: "early",
		unique: !1,
		optional: !1,
		noHeadline: !0
	},
	{
		id: 7,
		key: "socialistGovernments",
		ops: 3,
		side: "ussr",
		stage: "early",
		unique: !1,
		optional: !1
	},
	{
		id: 8,
		key: "fidel",
		ops: 2,
		side: "ussr",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 9,
		key: "vietnamRevolts",
		ops: 2,
		side: "ussr",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 10,
		key: "blockade",
		ops: 1,
		side: "ussr",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 11,
		key: "koreanWar",
		ops: 2,
		side: "ussr",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 12,
		key: "romanianAbdication",
		ops: 1,
		side: "ussr",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 13,
		key: "arabIsraeliWar",
		ops: 2,
		side: "ussr",
		stage: "early",
		unique: !1,
		optional: !1
	},
	{
		id: 14,
		key: "comecon",
		ops: 3,
		side: "ussr",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 15,
		key: "nasser",
		ops: 1,
		side: "ussr",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 16,
		key: "warsawPactFormed",
		ops: 3,
		side: "ussr",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 17,
		key: "deGaulleLeadsFrance",
		ops: 3,
		side: "ussr",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 18,
		key: "capturedNaziScientist",
		ops: 1,
		side: "both",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 19,
		key: "trumanDoctrine",
		ops: 1,
		side: "us",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 20,
		key: "olympicGames",
		ops: 2,
		side: "both",
		stage: "early",
		unique: !1,
		optional: !1
	},
	{
		id: 21,
		key: "nato",
		ops: 4,
		side: "us",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 22,
		key: "independentReds",
		ops: 2,
		side: "us",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 23,
		key: "marshallPlan",
		ops: 4,
		side: "us",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 24,
		key: "indoPakistaniWar",
		ops: 2,
		side: "both",
		stage: "early",
		unique: !1,
		optional: !1
	},
	{
		id: 25,
		key: "containment",
		ops: 3,
		side: "us",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 26,
		key: "ciaCreated",
		ops: 1,
		side: "us",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 27,
		key: "usJapanMutualDefensePact",
		ops: 4,
		side: "us",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 28,
		key: "suezCrisis",
		ops: 3,
		side: "ussr",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 29,
		key: "eastEuropeanUnrest",
		ops: 3,
		side: "us",
		stage: "early",
		unique: !1,
		optional: !1
	},
	{
		id: 30,
		key: "decolonization",
		ops: 2,
		side: "ussr",
		stage: "early",
		unique: !1,
		optional: !1
	},
	{
		id: 31,
		key: "redScarePurge",
		ops: 4,
		side: "both",
		stage: "early",
		unique: !1,
		optional: !1
	},
	{
		id: 32,
		key: "unIntervention",
		ops: 1,
		side: "both",
		stage: "early",
		unique: !1,
		optional: !1,
		noHeadline: !0
	},
	{
		id: 33,
		key: "deStalinization",
		ops: 3,
		side: "ussr",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 34,
		key: "nuclearTestBan",
		ops: 4,
		side: "both",
		stage: "early",
		unique: !1,
		optional: !1
	},
	{
		id: 35,
		key: "formosanResolution",
		ops: 2,
		side: "us",
		stage: "early",
		unique: !0,
		optional: !1
	},
	{
		id: 36,
		key: "brushWar",
		ops: 3,
		side: "both",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 37,
		key: "centralAmericaScoring",
		ops: 0,
		side: "both",
		stage: "mid",
		unique: !1,
		optional: !1,
		scoring: "centralAmerica"
	},
	{
		id: 38,
		key: "southeastAsiaScoring",
		ops: 0,
		side: "both",
		stage: "mid",
		unique: !0,
		optional: !1,
		scoring: "southeastAsia"
	},
	{
		id: 39,
		key: "armsRace",
		ops: 3,
		side: "both",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 40,
		key: "cubanMissileCrisis",
		ops: 3,
		side: "both",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 41,
		key: "nuclearSubs",
		ops: 2,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 42,
		key: "quagmire",
		ops: 3,
		side: "ussr",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 43,
		key: "saltNegotiations",
		ops: 3,
		side: "both",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 44,
		key: "bearTrap",
		ops: 3,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 45,
		key: "summit",
		ops: 1,
		side: "both",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 46,
		key: "howILearnedToStopWorrying",
		ops: 2,
		side: "both",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 47,
		key: "junta",
		ops: 2,
		side: "both",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 48,
		key: "kitchenDebates",
		ops: 1,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 49,
		key: "missileEnvy",
		ops: 2,
		side: "both",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 50,
		key: "weWillBuryYou",
		ops: 4,
		side: "ussr",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 51,
		key: "brezhnevDoctrine",
		ops: 3,
		side: "ussr",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 52,
		key: "portugueseEmpireCrumbles",
		ops: 2,
		side: "ussr",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 53,
		key: "southAfricanUnrest",
		ops: 2,
		side: "ussr",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 54,
		key: "allende",
		ops: 1,
		side: "ussr",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 55,
		key: "willyBrandt",
		ops: 2,
		side: "ussr",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 56,
		key: "muslimRevolution",
		ops: 4,
		side: "ussr",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 57,
		key: "abmTreaty",
		ops: 4,
		side: "both",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 58,
		key: "culturalRevolution",
		ops: 3,
		side: "ussr",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 59,
		key: "flowerPower",
		ops: 4,
		side: "ussr",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 60,
		key: "u2Incident",
		ops: 3,
		side: "ussr",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 61,
		key: "opec",
		ops: 3,
		side: "ussr",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 62,
		key: "loneGunman",
		ops: 1,
		side: "ussr",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 63,
		key: "colonialRearGuards",
		ops: 2,
		side: "us",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 64,
		key: "panamaCanalReturned",
		ops: 1,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 65,
		key: "campDavidAccords",
		ops: 2,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 66,
		key: "puppetGovernments",
		ops: 2,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 67,
		key: "grainSalesToSoviets",
		ops: 2,
		side: "us",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 68,
		key: "johnPaulIIElectedPope",
		ops: 2,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 69,
		key: "latinAmericanDeathSquads",
		ops: 2,
		side: "both",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 70,
		key: "oasFounded",
		ops: 1,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 71,
		key: "nixonPlaysTheChinaCard",
		ops: 2,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 72,
		key: "sadatExpelsSoviets",
		ops: 1,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 73,
		key: "shuttleDiplomacy",
		ops: 3,
		side: "us",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 74,
		key: "theVoiceOfAmerica",
		ops: 2,
		side: "us",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 75,
		key: "liberationTheology",
		ops: 2,
		side: "ussr",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 76,
		key: "ussuriRiverSkirmish",
		ops: 3,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 77,
		key: "askNotWhatYourCountryCanDoForYou",
		ops: 3,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 78,
		key: "allianceForProgress",
		ops: 3,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !1
	},
	{
		id: 79,
		key: "africaScoring",
		ops: 0,
		side: "both",
		stage: "mid",
		unique: !1,
		optional: !1,
		scoring: "africa"
	},
	{
		id: 80,
		key: "oneSmallStep",
		ops: 2,
		side: "both",
		stage: "mid",
		unique: !1,
		optional: !1
	},
	{
		id: 81,
		key: "southAmericaScoring",
		ops: 0,
		side: "both",
		stage: "mid",
		unique: !1,
		optional: !1,
		scoring: "southAmerica"
	},
	{
		id: 82,
		key: "iranianHostageCrisis",
		ops: 3,
		side: "ussr",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 83,
		key: "theIronLady",
		ops: 3,
		side: "us",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 84,
		key: "reaganBombsLibya",
		ops: 2,
		side: "us",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 85,
		key: "starWars",
		ops: 2,
		side: "us",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 86,
		key: "northSeaOil",
		ops: 3,
		side: "us",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 87,
		key: "theReformer",
		ops: 3,
		side: "ussr",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 88,
		key: "marineBarracksBombing",
		ops: 2,
		side: "ussr",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 89,
		key: "sovietsShootDownKAL007",
		ops: 4,
		side: "us",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 90,
		key: "glasnost",
		ops: 4,
		side: "ussr",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 91,
		key: "ortegaElectedInNicaragua",
		ops: 2,
		side: "ussr",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 92,
		key: "terrorism",
		ops: 2,
		side: "both",
		stage: "late",
		unique: !1,
		optional: !1
	},
	{
		id: 93,
		key: "iranContraScandal",
		ops: 2,
		side: "ussr",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 94,
		key: "chernobyl",
		ops: 3,
		side: "us",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 95,
		key: "latinAmericanDebtCrisis",
		ops: 2,
		side: "ussr",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 96,
		key: "tearDownThisWall",
		ops: 3,
		side: "us",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 97,
		key: "anEvilEmpire",
		ops: 3,
		side: "us",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 98,
		key: "aldrichAmesRemix",
		ops: 3,
		side: "ussr",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 99,
		key: "pershingIIDeployed",
		ops: 3,
		side: "ussr",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 100,
		key: "wargames",
		ops: 4,
		side: "both",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 101,
		key: "solidarity",
		ops: 2,
		side: "us",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 102,
		key: "iranIraqWar",
		ops: 2,
		side: "both",
		stage: "late",
		unique: !0,
		optional: !1
	},
	{
		id: 103,
		key: "defectors",
		ops: 2,
		side: "us",
		stage: "early",
		unique: !1,
		optional: !1
	},
	{
		id: 104,
		key: "theCambridgeFive",
		ops: 2,
		side: "ussr",
		stage: "early",
		unique: !1,
		optional: !0
	},
	{
		id: 105,
		key: "specialRelationship",
		ops: 2,
		side: "us",
		stage: "early",
		unique: !1,
		optional: !0
	},
	{
		id: 106,
		key: "norad",
		ops: 3,
		side: "us",
		stage: "early",
		unique: !0,
		optional: !0
	},
	{
		id: 107,
		key: "che",
		ops: 3,
		side: "ussr",
		stage: "mid",
		unique: !1,
		optional: !0
	},
	{
		id: 108,
		key: "ourManInTehran",
		ops: 2,
		side: "us",
		stage: "mid",
		unique: !0,
		optional: !0
	},
	{
		id: 109,
		key: "yuriAndSamantha",
		ops: 2,
		side: "ussr",
		stage: "late",
		unique: !0,
		optional: !0
	},
	{
		id: 110,
		key: "awacsSaleToSaudis",
		ops: 3,
		side: "us",
		stage: "late",
		unique: !0,
		optional: !0
	}
], C = Object.fromEntries(S.map((e) => [e.id, e])), w = {
	afghanistan: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["asia"],
		adjacent: [
			"ussr",
			"iran",
			"pakistan"
		]
	},
	algeria: {
		stability: 2,
		battleground: !0,
		superpower: !1,
		regions: ["africa"],
		adjacent: [
			"morocco",
			"saharanStates",
			"tunisia",
			"france"
		]
	},
	angola: {
		stability: 1,
		battleground: !0,
		superpower: !1,
		regions: ["africa"],
		adjacent: [
			"zaire",
			"botswana",
			"southAfrica"
		]
	},
	argentina: {
		stability: 2,
		battleground: !0,
		superpower: !1,
		regions: ["southAmerica"],
		adjacent: [
			"chile",
			"uruguay",
			"paraguay"
		]
	},
	australia: {
		stability: 4,
		battleground: !1,
		superpower: !1,
		regions: ["asia"],
		adjacent: ["malaysia"]
	},
	austria: {
		stability: 4,
		battleground: !1,
		superpower: !1,
		regions: [
			"europe",
			"westernEurope",
			"easternEurope"
		],
		adjacent: [
			"westGermany",
			"eastGermany",
			"hungary",
			"italy"
		]
	},
	benelux: {
		stability: 3,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "westernEurope"],
		adjacent: ["uk", "westGermany"]
	},
	bolivia: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["southAmerica"],
		adjacent: ["peru", "paraguay"]
	},
	botswana: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["africa"],
		adjacent: [
			"angola",
			"southAfrica",
			"zimbabwe"
		]
	},
	brazil: {
		stability: 2,
		battleground: !0,
		superpower: !1,
		regions: ["southAmerica"],
		adjacent: ["uruguay", "venezuela"]
	},
	bulgaria: {
		stability: 3,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "easternEurope"],
		adjacent: ["greece", "turkey"]
	},
	burma: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["asia", "southeastAsia"],
		adjacent: ["india", "laosCambodia"]
	},
	cameroon: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["africa"],
		adjacent: ["nigeria", "zaire"]
	},
	canada: {
		stability: 4,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "westernEurope"],
		adjacent: ["us", "uk"]
	},
	chile: {
		stability: 3,
		battleground: !0,
		superpower: !1,
		regions: ["southAmerica"],
		adjacent: ["peru", "argentina"]
	},
	chineseCivilWar: {
		stability: 3,
		battleground: !1,
		superpower: !1,
		regions: ["asia"],
		adjacent: ["ussr"]
	},
	colombia: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["southAmerica"],
		adjacent: [
			"panama",
			"ecuador",
			"venezuela"
		]
	},
	costaRica: {
		stability: 3,
		battleground: !1,
		superpower: !1,
		regions: ["centralAmerica"],
		adjacent: [
			"honduras",
			"nicaragua",
			"panama"
		]
	},
	cuba: {
		stability: 3,
		battleground: !0,
		superpower: !1,
		regions: ["centralAmerica"],
		adjacent: [
			"nicaragua",
			"haiti",
			"us"
		]
	},
	czechoslovakia: {
		stability: 3,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "easternEurope"],
		adjacent: [
			"eastGermany",
			"poland",
			"hungary"
		]
	},
	denmark: {
		stability: 3,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "westernEurope"],
		adjacent: ["sweden", "westGermany"]
	},
	dominicanRepublic: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["centralAmerica"],
		adjacent: ["haiti"]
	},
	eastGermany: {
		stability: 3,
		battleground: !0,
		superpower: !1,
		regions: ["europe", "easternEurope"],
		adjacent: [
			"westGermany",
			"austria",
			"czechoslovakia",
			"poland"
		]
	},
	ecuador: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["southAmerica"],
		adjacent: ["colombia", "peru"]
	},
	egypt: {
		stability: 2,
		battleground: !0,
		superpower: !1,
		regions: ["middleEast"],
		adjacent: [
			"libya",
			"israel",
			"sudan"
		]
	},
	elSalvador: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["centralAmerica"],
		adjacent: ["guatemala", "honduras"]
	},
	ethiopia: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["africa"],
		adjacent: ["somalia", "sudan"]
	},
	finland: {
		stability: 4,
		battleground: !1,
		superpower: !1,
		regions: [
			"europe",
			"westernEurope",
			"easternEurope"
		],
		adjacent: ["sweden", "ussr"]
	},
	france: {
		stability: 3,
		battleground: !0,
		superpower: !1,
		regions: ["europe", "westernEurope"],
		adjacent: [
			"uk",
			"westGermany",
			"spainPortugal",
			"italy",
			"algeria"
		]
	},
	greece: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "westernEurope"],
		adjacent: [
			"italy",
			"yugoslavia",
			"bulgaria",
			"turkey"
		]
	},
	guatemala: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["centralAmerica"],
		adjacent: [
			"mexico",
			"elSalvador",
			"honduras"
		]
	},
	gulfStates: {
		stability: 3,
		battleground: !1,
		superpower: !1,
		regions: ["middleEast"],
		adjacent: ["iraq", "saudiArabia"]
	},
	haiti: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["centralAmerica"],
		adjacent: ["cuba", "dominicanRepublic"]
	},
	honduras: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["centralAmerica"],
		adjacent: [
			"guatemala",
			"elSalvador",
			"costaRica",
			"nicaragua"
		]
	},
	hungary: {
		stability: 3,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "easternEurope"],
		adjacent: [
			"austria",
			"czechoslovakia",
			"romania",
			"yugoslavia"
		]
	},
	india: {
		stability: 3,
		battleground: !0,
		superpower: !1,
		regions: ["asia"],
		adjacent: ["pakistan", "burma"]
	},
	indonesia: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["asia", "southeastAsia"],
		adjacent: ["malaysia", "philippines"]
	},
	iran: {
		stability: 2,
		battleground: !0,
		superpower: !1,
		regions: ["middleEast"],
		adjacent: [
			"iraq",
			"afghanistan",
			"pakistan"
		]
	},
	iraq: {
		stability: 3,
		battleground: !0,
		superpower: !1,
		regions: ["middleEast"],
		adjacent: [
			"jordan",
			"saudiArabia",
			"gulfStates",
			"iran"
		]
	},
	israel: {
		stability: 4,
		battleground: !0,
		superpower: !1,
		regions: ["middleEast"],
		adjacent: [
			"lebanon",
			"syria",
			"jordan",
			"egypt"
		]
	},
	italy: {
		stability: 2,
		battleground: !0,
		superpower: !1,
		regions: ["europe", "westernEurope"],
		adjacent: [
			"france",
			"spainPortugal",
			"austria",
			"yugoslavia",
			"greece"
		]
	},
	ivoryCoast: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["africa"],
		adjacent: ["westAfricanStates", "nigeria"]
	},
	japan: {
		stability: 4,
		battleground: !0,
		superpower: !1,
		regions: ["asia"],
		adjacent: [
			"philippines",
			"taiwan",
			"southKorea",
			"us"
		]
	},
	jordan: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["middleEast"],
		adjacent: [
			"iraq",
			"israel",
			"lebanon",
			"saudiArabia"
		]
	},
	kenya: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["africa"],
		adjacent: ["seAfricanStates", "somalia"]
	},
	laosCambodia: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["asia", "southeastAsia"],
		adjacent: [
			"burma",
			"thailand",
			"vietnam"
		]
	},
	lebanon: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["middleEast"],
		adjacent: [
			"israel",
			"syria",
			"jordan"
		]
	},
	libya: {
		stability: 2,
		battleground: !0,
		superpower: !1,
		regions: ["middleEast"],
		adjacent: ["tunisia", "egypt"]
	},
	malaysia: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["asia", "southeastAsia"],
		adjacent: [
			"thailand",
			"indonesia",
			"australia"
		]
	},
	mexico: {
		stability: 2,
		battleground: !0,
		superpower: !1,
		regions: ["centralAmerica"],
		adjacent: ["guatemala", "us"]
	},
	morocco: {
		stability: 3,
		battleground: !1,
		superpower: !1,
		regions: ["africa"],
		adjacent: [
			"algeria",
			"westAfricanStates",
			"spainPortugal"
		]
	},
	nicaragua: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["centralAmerica"],
		adjacent: [
			"costaRica",
			"honduras",
			"cuba"
		]
	},
	nigeria: {
		stability: 1,
		battleground: !0,
		superpower: !1,
		regions: ["africa"],
		adjacent: [
			"ivoryCoast",
			"saharanStates",
			"cameroon"
		]
	},
	northKorea: {
		stability: 3,
		battleground: !0,
		superpower: !1,
		regions: ["asia"],
		adjacent: ["southKorea", "ussr"]
	},
	norway: {
		stability: 4,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "westernEurope"],
		adjacent: ["uk", "sweden"]
	},
	pakistan: {
		stability: 2,
		battleground: !0,
		superpower: !1,
		regions: ["asia"],
		adjacent: [
			"afghanistan",
			"iran",
			"india"
		]
	},
	panama: {
		stability: 2,
		battleground: !0,
		superpower: !1,
		regions: ["centralAmerica"],
		adjacent: ["costaRica", "colombia"]
	},
	paraguay: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["southAmerica"],
		adjacent: [
			"argentina",
			"uruguay",
			"bolivia"
		]
	},
	peru: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["southAmerica"],
		adjacent: [
			"ecuador",
			"bolivia",
			"chile"
		]
	},
	philippines: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["asia", "southeastAsia"],
		adjacent: ["indonesia", "japan"]
	},
	poland: {
		stability: 3,
		battleground: !0,
		superpower: !1,
		regions: ["europe", "easternEurope"],
		adjacent: [
			"eastGermany",
			"czechoslovakia",
			"ussr"
		]
	},
	romania: {
		stability: 3,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "easternEurope"],
		adjacent: [
			"hungary",
			"yugoslavia",
			"turkey",
			"ussr"
		]
	},
	seAfricanStates: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["africa"],
		adjacent: ["zimbabwe", "kenya"]
	},
	saharanStates: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["africa"],
		adjacent: ["algeria", "nigeria"]
	},
	saudiArabia: {
		stability: 3,
		battleground: !0,
		superpower: !1,
		regions: ["middleEast"],
		adjacent: [
			"iraq",
			"jordan",
			"gulfStates"
		]
	},
	somalia: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["africa"],
		adjacent: ["kenya", "ethiopia"]
	},
	southAfrica: {
		stability: 3,
		battleground: !0,
		superpower: !1,
		regions: ["africa"],
		adjacent: ["angola", "botswana"]
	},
	southKorea: {
		stability: 3,
		battleground: !0,
		superpower: !1,
		regions: ["asia"],
		adjacent: [
			"japan",
			"taiwan",
			"northKorea"
		]
	},
	spainPortugal: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "westernEurope"],
		adjacent: [
			"france",
			"italy",
			"morocco"
		]
	},
	sudan: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["africa"],
		adjacent: ["ethiopia", "egypt"]
	},
	sweden: {
		stability: 4,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "westernEurope"],
		adjacent: [
			"norway",
			"finland",
			"denmark"
		]
	},
	syria: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["middleEast"],
		adjacent: [
			"israel",
			"lebanon",
			"turkey"
		]
	},
	taiwan: {
		stability: 3,
		battleground: !1,
		superpower: !1,
		regions: ["asia"],
		adjacent: ["japan", "southKorea"]
	},
	thailand: {
		stability: 2,
		battleground: !0,
		superpower: !1,
		regions: ["asia", "southeastAsia"],
		adjacent: [
			"laosCambodia",
			"vietnam",
			"malaysia"
		]
	},
	tunisia: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["africa"],
		adjacent: ["algeria", "libya"]
	},
	turkey: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "westernEurope"],
		adjacent: [
			"greece",
			"bulgaria",
			"romania",
			"syria"
		]
	},
	uk: {
		stability: 5,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "westernEurope"],
		adjacent: [
			"canada",
			"norway",
			"benelux",
			"france"
		]
	},
	us: {
		stability: 999,
		battleground: !1,
		superpower: !0,
		regions: [],
		adjacent: [
			"japan",
			"mexico",
			"cuba",
			"canada"
		]
	},
	ussr: {
		stability: 999,
		battleground: !1,
		superpower: !0,
		regions: [],
		adjacent: [
			"finland",
			"poland",
			"romania",
			"afghanistan",
			"northKorea",
			"chineseCivilWar"
		]
	},
	uruguay: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["southAmerica"],
		adjacent: [
			"argentina",
			"paraguay",
			"brazil"
		]
	},
	venezuela: {
		stability: 2,
		battleground: !0,
		superpower: !1,
		regions: ["southAmerica"],
		adjacent: ["colombia", "brazil"]
	},
	vietnam: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["asia", "southeastAsia"],
		adjacent: ["laosCambodia", "thailand"]
	},
	westAfricanStates: {
		stability: 2,
		battleground: !1,
		superpower: !1,
		regions: ["africa"],
		adjacent: ["morocco", "ivoryCoast"]
	},
	westGermany: {
		stability: 4,
		battleground: !0,
		superpower: !1,
		regions: ["europe", "westernEurope"],
		adjacent: [
			"france",
			"benelux",
			"denmark",
			"eastGermany",
			"austria"
		]
	},
	yugoslavia: {
		stability: 3,
		battleground: !1,
		superpower: !1,
		regions: ["europe", "easternEurope"],
		adjacent: [
			"italy",
			"hungary",
			"greece",
			"romania"
		]
	},
	zaire: {
		stability: 1,
		battleground: !0,
		superpower: !1,
		regions: ["africa"],
		adjacent: [
			"cameroon",
			"angola",
			"zimbabwe"
		]
	},
	zimbabwe: {
		stability: 1,
		battleground: !1,
		superpower: !1,
		regions: ["africa"],
		adjacent: [
			"zaire",
			"botswana",
			"seAfricanStates"
		]
	}
}, re = Object.keys(w), ie = [
	"europe",
	"asia",
	"middleEast",
	"centralAmerica",
	"southAmerica",
	"africa"
], T = {
	us: "ussr",
	ussr: "us"
}, ae = [
	3,
	4,
	3,
	4,
	3,
	4,
	3,
	2
], oe = [
	[2, 1],
	[0, 0],
	[2, 0],
	[0, 0],
	[3, 1],
	[0, 0],
	[4, 2],
	[2, 0]
], se = (e) => e >= 7 ? 4 : e >= 5 ? 3 : 2, ce = {
	asia: [
		3,
		7,
		9
	],
	europe: [
		3,
		7,
		null
	],
	middleEast: [
		3,
		5,
		7
	],
	centralAmerica: [
		1,
		3,
		5
	],
	southAmerica: [
		2,
		5,
		6
	],
	africa: [
		1,
		4,
		6
	]
}, le = [
	"europe",
	"asia",
	"centralAmerica",
	"southAmerica"
], E = [
	"burma",
	"laosCambodia",
	"vietnam",
	"thailand",
	"malaysia",
	"indonesia",
	"philippines"
], ue = [
	13,
	11,
	24,
	36,
	102
], de = (e) => e <= 3 ? 6 : 7, fe = (e) => e <= 3 ? 8 : 9;
function pe(e, t) {
	return e.space[t] >= 8 && e.space[T[t]] < 8 || t === "us" && e.mods.northSeaOil ? 8 : de(e.turn);
}
var D = re.filter((e) => e !== "chineseCivilWar" && !w[e].superpower), O = (e) => D.filter((t) => w[t].regions.includes(e));
function k(t) {
	let n = e(t.seed, t.rng, 6) + 1;
	return t.rng += 1, n;
}
function me(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rng, n + 1);
		t.rng += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function A(e, t) {
	return e.influence[t] ?? {
		us: 0,
		ussr: 0
	};
}
function j(e, t, n, r) {
	let i = A(e, t), a = {
		us: Math.max(0, i.us + (n === "us" ? r : 0)),
		ussr: Math.max(0, i.ussr + (n === "ussr" ? r : 0))
	};
	a.us === 0 && a.ussr === 0 ? delete e.influence[t] : e.influence[t] = a;
}
function M(e, t, n, r) {
	let i = A(e, t), a = {
		us: n === "us" ? r : i.us,
		ussr: n === "ussr" ? r : i.ussr
	};
	a.us === 0 && a.ussr === 0 ? delete e.influence[t] : e.influence[t] = a;
}
function N(e, t) {
	let { us: n, ussr: r } = A(e, t), i = w[t].stability;
	return n >= r + i ? "us" : r >= n + i ? "ussr" : null;
}
var P = (e, t, n) => A(e, t)[n] > 0;
function he(e, t) {
	return D.filter((n) => P(e, n, t));
}
function F(e, t, n = !1) {
	e.vp = Math.max(-20, Math.min(20, e.vp + t)), !n && Math.abs(e.vp) >= 20 && !e.over && (e.over = {
		winner: e.vp > 0 ? "us" : "ussr",
		reason: "vp20"
	});
}
function I(e, t, n) {
	if (e.over) return;
	let r = e.defcon + t;
	if (r < 2) {
		e.defcon = 1, e.log.push({
			k: "defcon",
			n: 1
		}), e.over = {
			winner: T[n],
			reason: "nuclear"
		};
		return;
	}
	let i = e.defcon;
	e.defcon = Math.min(5, r), e.defcon < i && e.log.push({
		k: "defcon",
		n: e.defcon
	}), i > 2 && e.defcon === 2 && e.phase === "ar" && e.mods.norad && N(e, "canada") === "us" && (e.noradReady = !0);
}
function ge(e, t, n) {
	e.milops[t] = Math.min(5, Math.max(0, e.milops[t] + n));
}
function _e(e, t, n, r = !1) {
	let i = e.space[t], a = Math.min(8, i + n);
	e.space[t] = a, e.arTotal.us = pe(e, "us"), e.arTotal.ussr = pe(e, "ussr");
	let o = r ? [a] : Array.from({ length: a - i }, (e, t) => i + t + 1);
	for (let n of o) {
		if (n < 1 || n > 8) continue;
		let [r, i] = oe[n - 1], a = e.space[T[t]] < n ? r : i;
		a && F(e, t === "us" ? a : -a);
	}
}
function L(e, t, n) {
	let r = 0;
	return e.mods.opsPlus === t && (r += 1), e.mods.opsMinus === t && --r, Math.min(4, Math.max(1, n + r));
}
function ve(e, t) {
	let n = w[t].regions;
	return !!(e.defcon <= 4 && n.includes("europe") || e.defcon <= 3 && n.includes("asia") || e.defcon <= 2 && n.includes("middleEast"));
}
function ye(e, t) {
	return !e.mods.nato || !w[t].regions.includes("europe") || e.mods.natoOff.includes(t) ? !1 : N(e, t) === "us";
}
function be(e, t, n, r = !1) {
	return !D.includes(t) || !P(e, t, T[n]) ? !1 : r ? !0 : ye(e, t) || e.mods.usJapan && t === "japan" || n === "ussr" && e.mods.reformer && w[t].regions.includes("europe") ? !1 : !ve(e, t);
}
function R(e, t, n, r = !1) {
	if (!D.includes(t)) return !1;
	let i = A(e, t);
	return i.us === 0 && i.ussr === 0 || i[n] > 0 && i[T[n]] === 0 ? !1 : r ? !0 : ye(e, t) || e.mods.usJapan && t === "japan" ? !1 : !ve(e, t);
}
function xe(e, t, n) {
	let r = w[n].stability, i = 0, a = w[n].regions;
	e.mods.deathSquads && (a.includes("centralAmerica") || a.includes("southAmerica")) && (i += e.mods.deathSquads === t.side ? 1 : -1), e.mods.salt && --i, t.card === 6 && a.includes("asia") && (i += 1), e.mods.vietnam && t.side === "ussr" && a.includes("southeastAsia") && (i += 1);
	let o = k(e), s = o + t.ops + i - r * 2, c = s > 0, l = !1;
	if (c) {
		let r = A(e, n)[T[t.side]], i = Math.min(s, r);
		l = i > 0, j(e, n, T[t.side], -i), s - i > 0 && j(e, n, t.side, s - i);
	}
	e.log.push({
		k: "coup",
		side: t.side,
		country: n,
		roll: o,
		success: c
	});
	let u = e.actor ?? t.side;
	return e.mods.cuban && e.mods.cuban !== t.side ? I(e, 1 - e.defcon, u) : w[n].battleground && !(t.side === "us" && e.mods.nuclearSubs) && I(e, -1, u), t.side === "us" && e.mods.yuri && F(e, -1), t.free || ge(e, t.side, t.ops), l;
}
function Se(e, t, n) {
	let r = 0;
	e.mods.iranContra && (r += 1);
	for (let t of w[n].adjacent) if (t === "us") --r;
	else if (t === "ussr") r += 1;
	else {
		let n = N(e, t);
		n === "us" ? --r : n === "ussr" && (r += 1);
	}
	let i = A(e, n);
	i.ussr > i.us ? r += 1 : i.ussr < i.us && --r;
	let a = k(e), o = k(e), s = o + r - a, c = 0;
	s > 0 ? (c = Math.min(s, i.us), j(e, n, "us", -c)) : s < 0 && (c = Math.min(-s, i.ussr), j(e, n, "ussr", -c)), e.log.push({
		k: "realign",
		side: t,
		country: n,
		usRoll: a,
		ussrRoll: o,
		removed: c
	});
}
function z(e, t, n, r, i = {}) {
	let { countryItself: a = !1, lower: o = 4, winVp: s = 2, winMilops: c = 2 } = i, l = 0;
	for (let t of w[r].adjacent) t !== "us" && t !== "ussr" && N(e, t) === T[n] && (l += 1);
	a && N(e, r) === T[n] && (l += 1), t === 11 && n === "ussr" && e.config.civilWar && e.china.holder === null && (l += 1);
	let u = k(e), d = u - l >= o;
	if (ge(e, n, c), d) {
		F(e, n === "us" ? s : -s);
		let t = A(e, r)[T[n]];
		M(e, r, T[n], 0), j(e, r, n, t);
	}
	e.log.push({
		k: "war",
		card: t,
		side: n,
		country: r,
		roll: u,
		success: d
	});
}
function Ce(e, t, n) {
	let r = {
		bg: 0,
		total: 0,
		adj: 0
	};
	for (let i of O(t)) N(e, i) === n && (r.total += 1, (i === "taiwan" ? e.mods.formosan : w[i].battleground) && (r.bg += 1), le.includes(t) && w[i].adjacent.includes(T[n]) && (r.adj += 1));
	return r;
}
function B(e, t) {
	return O(e).filter((e) => e === "taiwan" ? t : w[e].battleground).length;
}
function we(e, t, n) {
	return e.total > t.total && n > 0 && e.bg === n ? "control" : e.total > t.total && e.bg > t.bg && e.total > e.bg ? "domination" : e.total > 0 ? "presence" : null;
}
function Te(e, t, n = !1) {
	let r = Ce(e, t, "us"), i = Ce(e, t, "ussr");
	!n && e.mods.shuttle && (t === "asia" || t === "middleEast") && (i = {
		bg: Math.max(0, i.bg - 1),
		total: Math.max(0, i.total - 1),
		adj: i.adj
	});
	let a = B(t, e.mods.formosan);
	return {
		us: r,
		ussr: i,
		usTier: we(r, i, a),
		ussrTier: we(i, r, a)
	};
}
function Ee(e, t, n = !1) {
	let [r, i, a] = ce[t], { us: o, ussr: s, usTier: c, ussrTier: l } = Te(e, t, n);
	!n && e.mods.shuttle && (t === "asia" || t === "middleEast") && (e.mods.shuttle = !1, e.limbo = e.limbo.filter((e) => e !== 73), e.removed.push(73));
	let u = (e) => e === "control" ? a ?? 0 : e === "domination" ? i : e === "presence" ? r : 0;
	if (t === "europe" && (c === "control" || l === "control")) {
		let n = c === "control" ? "us" : "ussr";
		e.log.push({
			k: "score",
			region: t,
			us: 0,
			ussr: 0
		}), e.over = {
			winner: n,
			reason: "europe"
		};
		return;
	}
	let d = u(c) + o.bg + o.adj, f = u(l) + s.bg + s.adj;
	e.log.push({
		k: "score",
		region: t,
		us: d,
		ussr: f
	}), F(e, d - f, n);
}
function De(e) {
	let t = 0, n = 0;
	for (let r of E) {
		let i = N(e, r), a = r === "thailand" ? 2 : 1;
		i === "us" ? t += a : i === "ussr" && (n += a);
	}
	e.log.push({
		k: "score",
		region: "southeastAsia",
		us: t,
		ussr: n
	}), F(e, t - n);
}
function Oe(e, t) {
	let n = e.config.optionalCards;
	return Object.values(C).filter((e) => e.stage === t && e.id !== 6 && (n || !e.optional)).map((e) => e.id);
}
function ke(e) {
	let t = fe(e.turn), n = "ussr";
	for (; e.hands.us.length < t || e.hands.ussr.length < t;) {
		if (e.hands[n].length >= t) {
			n = T[n];
			continue;
		}
		if (e.deck.length === 0) {
			if (e.discard.length === 0) break;
			e.deck = me(e, e.discard), e.discard = [];
		}
		e.hands[n].push(e.deck.pop()), n = T[n];
	}
}
function Ae(e) {
	e.turn === 4 ? e.deck = me(e, [...e.deck, ...Oe(e, "mid")]) : e.turn === 8 && (e.deck = me(e, [...e.deck, ...Oe(e, "late")]));
}
//#endregion
//#region src/games/twilightstruggle/events.ts
function je(t, n) {
	let r = e(t.seed, t.rng, n);
	return t.rng += 1, r;
}
var Me = () => O("easternEurope"), Ne = () => O("westernEurope"), Pe = () => O("europe"), Fe = () => [...O("centralAmerica"), ...O("southAmerica")], Ie = () => [...O("africa"), ...O("southeastAsia")], Le = [
	"europe",
	"asia",
	"middleEast",
	"africa",
	"centralAmerica",
	"southAmerica"
];
function V(e, t, n, r, i, a, o, s, c = {}) {
	let l = c.perMax ?? 1, u = i.filter((t) => o === "remove" || o === "removeAll" ? P(e, t, s) : o === "match" ? P(e, t, "ussr") : o !== "double" || P(e, t, s));
	u.length !== 0 && (e.pending = {
		kind: "countries",
		side: t,
		card: n,
		tag: r,
		pool: u,
		n: Math.min(a, u.length * l),
		perMax: l,
		exact: c.exact ?? !0,
		mode: o,
		target: s,
		amt: c.amt,
		min: 0,
		max: 0,
		options: void 0,
		data: { ...c.data }
	});
}
function H(e, t, n, r, i, a) {
	e.pending = {
		kind: "option",
		side: t,
		card: n,
		tag: r,
		pool: [],
		n: 0,
		perMax: 1,
		exact: !0,
		options: i,
		data: a
	};
}
function Re(e, t, n, r, i, a, o, s) {
	i.length !== 0 && o !== 0 && (e.pending = {
		kind: "cards",
		side: t,
		card: n,
		tag: r,
		pool: i,
		n: 0,
		perMax: 1,
		exact: a > 0,
		min: Math.min(a, i.length),
		max: Math.min(o, i.length),
		data: s
	});
}
function ze(e, t, n, r, i) {
	let a = ["influence", "realign"];
	r && D.some((n) => be(e, n, t)) && a.push("coup"), Be(e, t, n) && a.push("space"), H(e, t, i, "blankOps", a, { ops: n });
}
function Be(e, t, n) {
	let r = e.space[t];
	if (r >= 8) return !1;
	let i = 1 + +(r >= 2 && e.space[T[t]] < 2);
	return e.spaceUsed[t] >= i ? !1 : n >= se(r);
}
function Ve(e, t) {
	let n = e.space[t], r = k(e), i = r <= ae[n];
	e.spaceUsed[t] += 1, i && _e(e, t, 1), e.log.push({
		k: "space",
		side: t,
		roll: r,
		success: i,
		pos: e.space[t]
	});
}
function He(e, t, n, r, i = {}) {
	let a = n === 6 ? L(e, t, 4) : L(e, t, C[n].ops);
	e.spending = {
		side: t,
		card: n,
		blank: i.blank ?? !1,
		ops: a,
		mode: r,
		snapshot: he(e, t),
		asiaAll: n === 6,
		seaAll: e.mods.vietnam && t === "ussr",
		asiaBonus: !1,
		seaBonus: !1,
		free: i.free ?? !1,
		restricted: i.restricted ?? null
	};
}
function U(e, t, n, r = {}) {
	e.coup = {
		side: t,
		card: n,
		ops: n === 6 ? L(e, t, 4) : L(e, t, C[n].ops),
		free: r.free ?? !1,
		restricted: r.restricted ?? null,
		che: r.che ?? !1
	};
}
function W(e, t) {
	let n = w[t].regions;
	n.includes("asia") || (e.asiaAll = !1), n.includes("southeastAsia") || (e.seaAll = !1), e.asiaAll && !e.asiaBonus && (e.asiaBonus = !0, e.ops += 1), e.seaAll && !e.seaBonus && (e.seaBonus = !0, e.ops += 1), e.asiaBonus && !e.asiaAll && (e.asiaBonus = !1, --e.ops), e.seaBonus && !e.seaAll && (e.seaBonus = !1, --e.ops);
}
function Ue(e, t, n) {
	if (n === "chineseCivilWar") return e.config.civilWar && e.china.holder === null && t.side === "ussr" && (!t.restricted || t.restricted.includes(n)) && e.mods.chernobyl !== "asia" && t.ops >= 1;
	if (!D.includes(n) || t.restricted && !t.restricted.includes(n) || t.side === "ussr" && e.mods.chernobyl && w[n].regions.includes(e.mods.chernobyl)) return !1;
	let r = w[n].adjacent.includes(t.side), i = t.snapshot.includes(n) || t.snapshot.some((e) => w[e].adjacent.includes(n));
	if (!r && !i) return !1;
	let a = N(e, n) === T[t.side] ? 2 : 1;
	return t.ops >= a;
}
function We(e, t, n) {
	if (C[t].scoring || t === 6 || t === 32) return !0;
	if (e.config.civilWar && e.china.holder === null && (t === 58 || t === 35 || t === 31 && n === "ussr")) return !1;
	switch (t) {
		case 7: return !e.mods.ironLady;
		case 13: return !e.mods.campDavid;
		case 21: return e.mods.warsaw || e.mods.marshall;
		case 48: {
			let t = (t) => D.filter((n) => w[n].battleground && N(e, n) === t).length;
			return t("us") > t("ussr");
		}
		case 55: return !e.mods.tearDown;
		case 56: return !e.mods.awacs;
		case 59: return !e.mods.evilEmpire;
		case 61: return !e.opecBan;
		case 80: return e.space[n] < e.space[T[n]];
		case 85: return e.space.us > e.space.ussr && e.discard.some((e) => !C[e].scoring);
		case 100: return e.defcon === 2;
		case 101: return e.mods.johnPaul;
		case 104: return e.turn < 8;
		case 105: return N(e, "uk") === "us";
		case 108: return O("middleEast").some((t) => N(e, t) === "us");
		default: return !0;
	}
}
function Ge(e, t, n) {
	let r = T[n];
	switch (t) {
		case 4:
			I(e, -1, e.actor ?? n), e.over || F(e, 5 - e.defcon);
			break;
		case 5: {
			let n = e.hands.ussr;
			if (n.length > 0) {
				let r = n[je(e, n.length)];
				K(e, "ussr", r), e.log.push({
					k: "play",
					side: "ussr",
					card: r,
					mode: "discard",
					withCard: t
				}), C[r].side === "us" && We(e, r, "ussr") ? (Ge(e, r, "ussr"), G(e, r, !0)) : e.discard.push(r);
			}
			break;
		}
		case 7:
			V(e, "ussr", 7, "alloc", Ne().filter((t) => P(e, t, "us")), 3, "remove", "us", { perMax: 2 });
			break;
		case 8:
			M(e, "cuba", "us", 0), M(e, "cuba", "ussr", Math.max(3, A(e, "cuba").ussr));
			break;
		case 9:
			j(e, "vietnam", "ussr", 2), e.mods.vietnam = !0;
			break;
		case 10: {
			let t = e.hands.us.filter((t) => L(e, "us", C[t].ops) >= 3 && t !== 6);
			t.length > 0 ? Re(e, "us", 10, "blockade", t, 0, 1) : M(e, "westGermany", "us", 0);
			break;
		}
		case 11:
			z(e, 11, "ussr", "southKorea");
			break;
		case 12:
			M(e, "romania", "us", 0), M(e, "romania", "ussr", Math.max(3, A(e, "romania").ussr));
			break;
		case 13:
			z(e, 13, "ussr", "israel", { countryItself: !0 });
			break;
		case 14:
			V(e, "ussr", 14, "alloc", Me().filter((t) => N(e, t) !== "us"), 4, "add", "ussr");
			break;
		case 15:
			j(e, "egypt", "ussr", 2), j(e, "egypt", "us", -Math.ceil(A(e, "egypt").us / 2));
			break;
		case 16:
			e.mods.warsaw = !0, Me().filter((t) => P(e, t, "us")).length > 0 ? H(e, "ussr", 16, "warsaw", ["remove", "add"]) : V(e, "ussr", 16, "alloc", Me(), 5, "add", "ussr", { perMax: 2 });
			break;
		case 17:
			j(e, "france", "us", -2), j(e, "france", "ussr", 1), e.mods.natoOff.push("france");
			break;
		case 18:
			_e(e, n, 1);
			break;
		case 19:
			V(e, "us", 19, "alloc", Pe().filter((t) => N(e, t) === null), 1, "removeAll", "ussr");
			break;
		case 20:
			H(e, r, 20, "olympic", ["participate", "boycott"], { sponsor: n });
			break;
		case 21:
			e.mods.nato = !0;
			break;
		case 22:
			V(e, "us", 22, "alloc", [
				"yugoslavia",
				"romania",
				"bulgaria",
				"hungary",
				"czechoslovakia"
			].filter((t) => P(e, t, "ussr")), 1, "match", "us");
			break;
		case 23:
			e.mods.marshall = !0, V(e, "us", 23, "alloc", Ne().filter((t) => N(e, t) !== "ussr"), 7, "add", "us");
			break;
		case 24:
			V(e, n, 24, "alloc", ["india", "pakistan"], 1, "war", n);
			break;
		case 25:
			e.mods.opsPlus = "us";
			break;
		case 26:
			e.mods.revealedHand = "ussr", ze(e, "us", L(e, "us", 1), !0, 26);
			break;
		case 27:
			M(e, "japan", "us", Math.max(A(e, "japan").us, A(e, "japan").ussr + 4)), e.mods.usJapan = !0;
			break;
		case 28:
			V(e, "ussr", 28, "alloc", [
				"france",
				"uk",
				"israel"
			].filter((t) => P(e, t, "us")), 4, "remove", "us", { perMax: 2 });
			break;
		case 29: {
			let t = e.turn >= 8 ? 2 : 1;
			V(e, "us", 29, "alloc", Me().filter((t) => P(e, t, "ussr")), 3, "remove", "ussr", { amt: t });
			break;
		}
		case 30:
			V(e, "ussr", 30, "alloc", Ie(), 4, "add", "ussr");
			break;
		case 31:
			e.mods.opsMinus = r;
			break;
		case 33:
			V(e, "ussr", 33, "destalRemove", he(e, "ussr"), 4, "remove", "ussr", {
				perMax: 4,
				exact: !1
			});
			break;
		case 34:
			F(e, (n === "us" ? 1 : -1) * (e.defcon - 2)), I(e, 2, n);
			break;
		case 35:
			e.mods.formosan = !0;
			break;
		case 36:
			V(e, n, 36, "alloc", D.filter((t) => w[t].stability <= 2 && !ye(e, t)), 1, "war", n);
			break;
		case 39: {
			let t = e.milops[n];
			t > e.milops[r] && F(e, (n === "us" ? 1 : -1) * (t >= e.defcon ? 3 : 1));
			break;
		}
		case 40:
			I(e, 2 - e.defcon, n), e.mods.cuban = n;
			break;
		case 41:
			e.mods.nuclearSubs = !0;
			break;
		case 42:
			e.mods.norad = !1, e.trap = "us";
			break;
		case 43: {
			I(e, 2, n), e.mods.salt = !0;
			let t = e.discard.filter((e) => !C[e].scoring);
			t.length > 0 && Re(e, n, 43, "salt", t, 0, 1);
			break;
		}
		case 44:
			e.trap = "ussr";
			break;
		case 45: {
			let t = (t) => Le.filter((n) => {
				let r = we(Ce(e, n, t), Ce(e, n, T[t]), B(n, e.mods.formosan));
				return r === "domination" || r === "control";
			}).length, n = k(e) + t("us"), r = k(e) + t("ussr");
			if (n !== r) {
				let t = n > r ? "us" : "ussr";
				F(e, t === "us" ? 2 : -2), e.over || H(e, t, 45, "summitDefcon", [
					"improve",
					"noChange",
					"degrade"
				]);
			}
			break;
		}
		case 46:
			e.milops[n] = 5, H(e, n, 46, "howILearned", [
				"1",
				"2",
				"3",
				"4",
				"5"
			]);
			break;
		case 47:
			V(e, n, 47, "juntaPlace", Fe(), 1, "add", n, {
				perMax: 1,
				amt: 2
			});
			break;
		case 48:
			F(e, 2);
			break;
		case 49: {
			let t = e.hands[r];
			if (t.length === 0) break;
			let i = Math.max(...t.map((t) => L(e, r, C[t].ops)));
			Re(e, r, 49, "missileEnvy", t.filter((t) => L(e, r, C[t].ops) === i), 1, 1, { phasing: n });
			break;
		}
		case 50:
			I(e, -1, e.actor ?? n), e.mods.bury = !0;
			break;
		case 51:
			e.mods.opsPlus = "ussr";
			break;
		case 52:
			j(e, "angola", "ussr", 2), j(e, "seAfricanStates", "ussr", 2);
			break;
		case 53:
			H(e, "ussr", 53, "southAfrica", [
				"sa2",
				"sa1ang2",
				"sa1bot2",
				"sa1ang1bot1"
			]);
			break;
		case 54:
			j(e, "chile", "ussr", 2);
			break;
		case 55:
			F(e, -1), j(e, "westGermany", "ussr", 1), e.mods.natoOff.push("westGermany");
			break;
		case 56:
			V(e, "ussr", 56, "alloc", [
				"sudan",
				"iran",
				"iraq",
				"egypt",
				"libya",
				"saudiArabia",
				"syria",
				"jordan"
			].filter((t) => P(e, t, "us")), 2, "removeAll", "us");
			break;
		case 57:
			I(e, 1, n), ze(e, n, L(e, n, 4), !0, 57);
			break;
		case 58:
			e.china.holder === "us" ? e.china = {
				holder: "ussr",
				faceUp: !0
			} : F(e, -1);
			break;
		case 59:
			e.mods.flower = !0;
			break;
		case 60:
			F(e, -1), e.mods.u2 = !0;
			break;
		case 61: {
			let t = [
				"egypt",
				"iran",
				"libya",
				"saudiArabia",
				"iraq",
				"gulfStates",
				"venezuela"
			].filter((t) => N(e, t) === "ussr").length;
			F(e, -t);
			break;
		}
		case 62:
			e.mods.revealedHand = "us", ze(e, "ussr", L(e, "ussr", 1), !0, 62);
			break;
		case 63:
			V(e, "us", 63, "alloc", Ie(), 4, "add", "us");
			break;
		case 64:
			j(e, "panama", "us", 1), j(e, "costaRica", "us", 1), j(e, "venezuela", "us", 1);
			break;
		case 65:
			F(e, 1), j(e, "israel", "us", 1), j(e, "jordan", "us", 1), j(e, "egypt", "us", 1), e.mods.campDavid = !0;
			break;
		case 66:
			V(e, "us", 66, "alloc", D.filter((t) => {
				let n = A(e, t);
				return n.us === 0 && n.ussr === 0;
			}), 3, "add", "us");
			break;
		case 67: {
			let t = e.hands.ussr;
			if (t.length === 0) {
				ze(e, "us", L(e, "us", 2), !0, 67);
				break;
			}
			let n = t[je(e, t.length)];
			K(e, "ussr", n), e.limbo.push(n), e.log.push({
				k: "play",
				side: "us",
				card: 67,
				mode: "draw",
				withCard: n
			});
			let r = ["use", "return"];
			e.hands.us.includes(32) && r.push("un"), H(e, "us", 67, "grainSales", r, { card: n });
			break;
		}
		case 68:
			j(e, "poland", "ussr", -2), j(e, "poland", "us", 1), e.mods.johnPaul = !0;
			break;
		case 69:
			e.mods.deathSquads = n;
			break;
		case 70:
			V(e, "us", 70, "alloc", Fe(), 2, "add", "us", { perMax: 2 });
			break;
		case 71:
			e.china.holder === "ussr" ? e.china = {
				holder: "us",
				faceUp: !1
			} : F(e, 2);
			break;
		case 72:
			M(e, "egypt", "ussr", 0), j(e, "egypt", "us", 1);
			break;
		case 73:
			e.mods.shuttle = !0;
			break;
		case 74:
			V(e, "us", 74, "alloc", D.filter((t) => !w[t].regions.includes("europe") && P(e, t, "ussr")), 4, "remove", "ussr", { perMax: 2 });
			break;
		case 75:
			V(e, "ussr", 75, "alloc", O("centralAmerica"), 3, "add", "ussr", { perMax: 2 });
			break;
		case 76:
			e.china.holder === "ussr" ? e.china = {
				holder: "us",
				faceUp: !0
			} : V(e, "us", 76, "alloc", O("asia"), 4, "add", "us", { perMax: 2 });
			break;
		case 77:
			e.hands.us.length === 0 && e.log.push({
				k: "play",
				side: "us",
				card: 77,
				mode: "noDiscard"
			}), Re(e, "us", 77, "asknot", [...e.hands.us], 0, e.hands.us.length);
			break;
		case 78: {
			let t = Fe().filter((t) => w[t].battleground && N(e, t) === "us").length;
			F(e, t);
			break;
		}
		case 80:
			_e(e, n, 2, !0);
			break;
		case 82:
			M(e, "iran", "us", 0), j(e, "iran", "ussr", 2), e.mods.iranHostage = !0;
			break;
		case 83:
			F(e, 1), M(e, "uk", "ussr", 0), j(e, "argentina", "ussr", 1), e.mods.ironLady = !0;
			break;
		case 84:
			F(e, Math.floor(A(e, "libya").ussr / 2));
			break;
		case 85:
			Re(e, "us", 85, "starwars", e.discard.filter((e) => !C[e].scoring), 1, 1);
			break;
		case 86:
			e.opecBan = !0, e.mods.northSeaOil = !0, e.arTotal.us = 8;
			break;
		case 87:
			e.mods.reformer = !0, V(e, "ussr", 87, "alloc", Pe(), e.vp < 0 ? 6 : 4, "add", "ussr", { perMax: 2 });
			break;
		case 88:
			M(e, "lebanon", "us", 0), V(e, "ussr", 88, "alloc", O("middleEast").filter((t) => P(e, t, "us")), 2, "remove", "us", { perMax: 2 });
			break;
		case 89:
			I(e, -1, e.actor ?? n), F(e, 2), !e.over && N(e, "southKorea") === "us" && ze(e, "us", L(e, "us", 4), !1, 89);
			break;
		case 90:
			I(e, 1, n), F(e, -2), !e.over && e.mods.reformer && ze(e, "ussr", L(e, "ussr", 4), !1, 90);
			break;
		case 91: {
			M(e, "nicaragua", "us", 0);
			let t = w.nicaragua.adjacent.filter((e) => D.includes(e));
			t.some((t) => be(e, t, "ussr", !0)) && (e.coup = {
				side: "ussr",
				card: 91,
				ops: L(e, "ussr", 2),
				free: !0,
				restricted: t,
				che: !1
			});
			break;
		}
		case 92: {
			let i = n === "ussr" && e.mods.iranHostage ? 2 : 1;
			for (let n = 0; n < i && e.hands[r].length > 0; n++) {
				let n = e.hands[r], i = n[je(e, n.length)];
				K(e, r, i), e.discard.push(i), e.log.push({
					k: "play",
					side: r,
					card: i,
					mode: "discard",
					withCard: t
				});
			}
			break;
		}
		case 93:
			e.mods.iranContra = !0;
			break;
		case 94:
			H(e, "us", 94, "chernobyl", [...Le]);
			break;
		case 95: {
			let t = e.hands.us.filter((t) => L(e, "us", C[t].ops) >= 3 && t !== 6);
			t.length > 0 ? Re(e, "us", 95, "debtCrisis", t, 0, 1) : Ke(e);
			break;
		}
		case 96:
			e.mods.tearDown = !0, e.mods.natoOff = e.mods.natoOff.filter((e) => e !== "westGermany"), F(e, 1), j(e, "eastGermany", "us", 3), H(e, "us", 96, "teardown", ["coup", "realign"]);
			break;
		case 97:
			F(e, 1), e.mods.flower = !1, e.mods.evilEmpire = !0;
			break;
		case 98:
			e.mods.revealedHand = "us", e.hands.us.length > 0 && Re(e, "ussr", 98, "ames", [...e.hands.us], 1, 1);
			break;
		case 99:
			F(e, -1), V(e, "ussr", 99, "alloc", Ne().filter((t) => P(e, t, "us")), 3, "remove", "us");
			break;
		case 100:
			F(e, n === "us" ? -6 : 6, !0), e.over = {
				winner: e.vp > 0 ? "us" : e.vp < 0 ? "ussr" : null,
				reason: "wargames"
			};
			break;
		case 101:
			j(e, "poland", "us", 3), e.mods.johnPaul = !1;
			break;
		case 102:
			V(e, n, 102, "alloc", ["iran", "iraq"], 1, "war", n);
			break;
		case 103:
			F(e, 1);
			break;
		case 104: {
			let t = /* @__PURE__ */ new Set(), n = e.config.legacyCambridgeActions?.includes(e.actionCount + 1);
			for (let r of e.hands.us) {
				let i = C[r].scoring;
				i === "southeastAsia" && (e.lastCambridgeAction = e.actionCount + 1), i && (!n || i !== "southeastAsia") && t.add(i);
			}
			let r = [...t].flatMap((e) => O(e));
			r.length > 0 && V(e, "ussr", 104, "alloc", r, 1, "add", "ussr");
			break;
		}
		case 105:
			e.mods.nato ? (F(e, 2), V(e, "us", 105, "alloc", Ne(), 1, "add", "us", { amt: 2 })) : V(e, "us", 105, "alloc", w.uk.adjacent.filter((e) => D.includes(e)), 1, "add", "us");
			break;
		case 106:
			e.mods.norad = !0;
			break;
		case 107: {
			let t = Fe().concat(O("africa")).filter((e) => !w[e].battleground);
			t.some((t) => be(e, t, "ussr", !0)) && (e.coup = {
				side: "ussr",
				card: 107,
				ops: L(e, "ussr", 3),
				free: !0,
				restricted: t,
				che: !0
			});
			break;
		}
		case 108: {
			let t = e.deck.splice(-Math.min(5, e.deck.length));
			t.length > 0 && (e.limbo.push(...t), Re(e, "us", 108, "tehran", t, 0, t.length));
			break;
		}
		case 109:
			e.mods.yuri = !0;
			break;
		case 110: j(e, "saudiArabia", "us", 2), e.mods.awacs = !0;
	}
}
function Ke(e) {
	V(e, "ussr", 95, "alloc", O("southAmerica").filter((t) => P(e, t, "ussr")), 2, "double", "ussr");
}
function G(e, t, n) {
	if (t !== 6) {
		if (t === 73 && n) {
			e.limbo.push(73);
			return;
		}
		if (t === 49 && n && e.pending?.tag === "missileEnvy") {
			e.limbo.push(49);
			return;
		}
		n && C[t].unique ? e.removed.push(t) : e.discard.push(t);
	}
}
function qe(e, t, n) {
	let r = e.pending;
	if (!r || r.kind !== "countries" || r.side !== t) return { code: "games.twilightstruggle.errPending" };
	if (n.length === 0) {
		let t = r.data?.used ?? {}, n = r.pool.filter((n) => (t[n] ?? 0) < r.perMax && (r.mode === "add" || P(e, n, r.target)));
		return r.exact && r.n > 0 && n.length > 0 ? { code: "games.twilightstruggle.errBadAlloc" } : Je(e, r);
	}
	let i = n[0];
	if (!r.pool.includes(i) || r.mode === "remove" && !P(e, i, r.target)) return { code: "games.twilightstruggle.errBadTarget" };
	let a = r.data?.used ?? {};
	if ((a[i] ?? 0) >= r.perMax) return { code: "games.twilightstruggle.errBadAlloc" };
	a[i] = (a[i] ?? 0) + 1, r.data = {
		...r.data,
		used: a
	}, --r.n;
	let o = r.amt ?? 1;
	switch (r.mode) {
		case "add":
			j(e, i, r.target, o);
			break;
		case "remove":
			j(e, i, r.target, -o);
			break;
		case "removeAll":
			M(e, i, r.target, 0);
			break;
		case "double":
			M(e, i, r.target, A(e, i)[r.target] * 2);
			break;
		case "match":
			M(e, i, r.target, A(e, i)[T[r.target]]);
			break;
		case "war": {
			e.pending = null;
			let t = r.card === 36 ? {
				lower: 3,
				winVp: 1,
				winMilops: 3
			} : r.card === 13 ? { countryItself: !0 } : {};
			return z(e, r.card, r.target, i, t), null;
		}
	}
	return r.n <= 0 || (r.pool = r.pool.filter((t) => (a[t] ?? 0) < r.perMax && (r.mode === "add" || P(e, t, r.target))), r.pool.length === 0) ? Je(e, r) : null;
}
function Je(e, t) {
	switch (e.pending = null, t.tag) {
		case "destalRemove": {
			let n = 4 - t.n;
			n > 0 && V(e, "ussr", 33, "destalAdd", D.filter((t) => N(e, t) !== "us"), n, "add", "ussr", { perMax: 2 });
			break;
		}
		case "juntaPlace": {
			let n = Fe(), r = [];
			n.some((n) => be(e, n, t.target, !0)) && r.push("coup"), n.some((n) => R(e, n, t.target, !0)) && r.push("realign"), r.length > 0 && H(e, t.target, 47, "juntaAction", r);
			break;
		}
	}
	return null;
}
function Ye(e, t, n) {
	let r = e.pending;
	if (!r || r.kind !== "cards" || r.side !== t) return { code: "games.twilightstruggle.errPending" };
	if (n.length < (r.min ?? 0) || n.length > (r.max ?? 0)) return { code: "games.twilightstruggle.errBadAlloc" };
	if (n.some((e) => !r.pool.includes(e))) return { code: "games.twilightstruggle.errBadCard" };
	switch (e.pending = null, r.tag) {
		case "blockade":
			n.length === 0 ? M(e, "westGermany", "us", 0) : (K(e, "us", n[0]), e.discard.push(n[0]), e.log.push({
				k: "play",
				side: "us",
				card: n[0],
				mode: "discard",
				withCard: r.card
			}));
			break;
		case "debtCrisis":
			n.length === 0 ? Ke(e) : (K(e, "us", n[0]), e.discard.push(n[0]));
			break;
		case "salt":
		case "starwars": {
			if (n.length === 0) break;
			let i = n[0];
			if (e.discard = e.discard.filter((e) => e !== i), r.tag === "salt") e.hands[t].push(i), e.log.push({
				k: "play",
				side: t,
				card: r.card,
				mode: "retrieve",
				withCard: i
			});
			else {
				let t = We(e, i, "us");
				t && Ge(e, i, "us"), G(e, i, t);
			}
			break;
		}
		case "asknot":
			for (let t of n) K(e, "us", t), e.discard.push(t), e.log.push({
				k: "play",
				side: "us",
				card: t,
				mode: "discard",
				withCard: r.card
			});
			n.length === 0 && e.log.push({
				k: "play",
				side: "us",
				card: r.card,
				mode: "noDiscard"
			}), $e(e, "us", n.length);
			break;
		case "ames":
			K(e, "us", n[0]), e.discard.push(n[0]);
			break;
		case "tehran": {
			for (let t of n) e.limbo = e.limbo.filter((e) => e !== t), e.discard.push(t), e.log.push({
				k: "play",
				side: "us",
				card: t,
				mode: "discard",
				withCard: r.card
			});
			let t = e.limbo.filter((e) => r.pool.includes(e));
			e.limbo = e.limbo.filter((e) => !r.pool.includes(e)), e.deck = me(e, [...e.deck, ...t]);
			break;
		}
		case "missileEnvy": {
			let t = n[0], i = r.data?.phasing ?? "us", a = T[i];
			K(e, a, t), e.hands[i].push(t), e.limbo = e.limbo.filter((e) => e !== 49), e.hands[a].push(49), e.mustOps[a] = 49, e.log.push({
				k: "play",
				side: i,
				card: 49,
				mode: "exchange",
				withCard: t
			});
			let o = C[t];
			if (o.scoring) et(e, t), K(e, i, t), G(e, t, !0);
			else if (o.side === i || o.side === "both") {
				K(e, i, t);
				let n = We(e, t, i);
				n && Ge(e, t, i), G(e, t, n);
			} else e.afterOps = {
				card: t,
				mode: "influence"
			}, e.afterOps = null, Xe(e, i, t);
			break;
		}
		case "spaceDiscard": n.length > 0 && (K(e, t, n[0]), e.discard.push(n[0]));
	}
	return null;
}
function Xe(e, t, n) {
	let r = L(e, t, C[n].ops), i = ["influence", "realign"];
	D.some((n) => be(e, n, t)) && i.push("coup"), Be(e, t, r) && i.push("space"), H(e, t, n, "meOps", i, {
		ops: r,
		card: n
	});
}
function Ze(e, t, n) {
	let r = e.pending;
	if (!r || r.kind !== "option" || r.side !== t) return { code: "games.twilightstruggle.errPending" };
	if (!r.options.includes(n)) return { code: "games.twilightstruggle.errBadTarget" };
	e.pending = null;
	let i = r.data?.ops ?? 0;
	switch (r.tag) {
		case "blankOps":
			Qe(e, t, n, i, r.card);
			break;
		case "meOps":
			Qe(e, t, n, i, r.data?.card ?? r.card);
			break;
		case "warsaw":
			if (n === "remove") {
				let t = Me().filter((t) => P(e, t, "us"));
				V(e, "ussr", 16, "alloc", t, Math.min(4, t.length), "removeAll", "us");
			} else V(e, "ussr", 16, "alloc", Me(), 5, "add", "ussr", { perMax: 2 });
			break;
		case "olympic": {
			let i = r.data?.sponsor ?? "us";
			if (n === "boycott") I(e, -1, e.actor ?? t), e.over || ze(e, i, L(e, i, 4), !0, 20);
			else for (;;) {
				let t = k(e) + 2, n = k(e);
				if (t !== n) {
					F(e, (t > n ? i : T[i]) === "us" ? 2 : -2);
					break;
				}
			}
			break;
		}
		case "summitDefcon":
			n === "improve" ? I(e, 1, e.actor ?? t) : n === "degrade" && I(e, -1, e.actor ?? t);
			break;
		case "howILearned":
			I(e, Number(n) - e.defcon, t);
			break;
		case "chernobyl":
			e.mods.chernobyl = n;
			break;
		case "southAfrica":
			n === "sa2" ? j(e, "southAfrica", "ussr", 2) : n === "sa1ang2" ? (j(e, "southAfrica", "ussr", 1), j(e, "angola", "ussr", 2)) : n === "sa1bot2" ? (j(e, "southAfrica", "ussr", 1), j(e, "botswana", "ussr", 2)) : (j(e, "southAfrica", "ussr", 1), j(e, "angola", "ussr", 1), j(e, "botswana", "ussr", 1));
			break;
		case "grainSales": {
			let t = r.data?.card;
			if (e.log.push({
				k: "play",
				side: "us",
				card: 67,
				mode: n,
				withCard: t
			}), n === "use") {
				e.limbo = e.limbo.filter((e) => e !== t), e.hands.us.push(t);
				let n = C[t];
				if (n.scoring) K(e, "us", t), et(e, t), G(e, t, !0);
				else if (n.side === "ussr") {
					K(e, "us", t);
					let r = We(e, t, "us");
					r && Ge(e, t, "us"), G(e, t, r), e.afterBlank = {
						side: "us",
						ops: L(e, "us", n.ops),
						canCoup: !0,
						fromCard: t
					};
				} else {
					K(e, "us", t), e.limbo.push(t);
					let r = L(e, "us", n.ops), i = ["influence", "realign"];
					D.some((t) => be(e, t, "us")) && i.push("coup"), Be(e, "us", r) && i.push("space"), t !== 32 && We(e, t, "us") && i.push("event"), H(e, "us", t, "grainPlay", i, {
						card: t,
						ops: r
					});
				}
			} else n === "return" ? (e.limbo = e.limbo.filter((e) => e !== t), e.hands.ussr.push(t), ze(e, "us", L(e, "us", 2), !0, 67)) : (K(e, "us", 32), e.discard.push(32), e.limbo = e.limbo.filter((e) => e !== t), e.discard.push(t), e.mods.u2 && F(e, -1), ze(e, "us", L(e, "us", C[t].ops), !0, t));
			break;
		}
		case "grainPlay": {
			e.limbo = e.limbo.filter((e) => e !== r.card), e.log.push({
				k: "play",
				side: t,
				card: r.card,
				mode: n
			}), e.mods.flower && ue.includes(r.card) && n !== "space" && F(e, -2);
			let a = n === "event" && We(e, r.card, t);
			a && Ge(e, r.card, t), G(e, r.card, a), n !== "event" && Qe(e, t, n, i, r.card);
			break;
		}
		case "teardown": {
			let t = Pe();
			n === "coup" ? t.some((t) => be(e, t, "us", !0)) && (e.coup = {
				side: "us",
				card: 96,
				ops: L(e, "us", 3),
				free: !0,
				restricted: t,
				che: !1
			}) : He(e, "us", 96, "realign", {
				free: !0,
				restricted: t
			});
			break;
		}
		case "juntaAction": {
			let r = Fe(), i = t;
			n === "coup" ? e.coup = {
				side: i,
				card: 47,
				ops: L(e, i, 2),
				free: !0,
				restricted: r,
				che: !1
			} : He(e, i, 47, "realign", {
				free: !0,
				restricted: r
			});
			break;
		}
		case "cubanCancel": j(e, n, "us", -2), e.mods.cuban = null;
	}
	return null;
}
function Qe(e, t, n, r, i) {
	n === "influence" ? e.spending = {
		side: t,
		card: i,
		blank: !0,
		ops: r,
		mode: "influence",
		snapshot: he(e, t),
		asiaAll: !1,
		seaAll: e.mods.vietnam && t === "ussr",
		asiaBonus: !1,
		seaBonus: !1,
		free: !1,
		restricted: null
	} : n === "realign" ? e.spending = {
		side: t,
		card: i,
		blank: !0,
		ops: r,
		mode: "realign",
		snapshot: he(e, t),
		asiaAll: !1,
		seaAll: e.mods.vietnam && t === "ussr",
		asiaBonus: !1,
		seaBonus: !1,
		free: !1,
		restricted: null
	} : n === "coup" ? e.coup = {
		side: t,
		card: i,
		ops: r,
		free: !1,
		restricted: null,
		che: !1
	} : n === "space" && (Ve(e, t), e.hands[t].includes(i) && (K(e, t, i), e.discard.push(i)));
}
function $e(e, t, n) {
	for (let r = 0; r < n; r++) {
		if (e.deck.length === 0) {
			if (e.discard.length === 0) return;
			e.deck = me(e, e.discard), e.discard = [];
		}
		e.hands[t].push(e.deck.pop());
	}
}
function K(e, t, n) {
	e.hands[t] = e.hands[t].filter((e) => e !== n), e.mustOps[t] === n && (e.mustOps[t] = null);
}
function et(e, t) {
	let n = C[t].scoring;
	n && (n === "southeastAsia" ? De(e) : Ee(e, n));
}
//#endregion
//#region src/games/twilightstruggle/meta.ts
var tt = {
	id: "twilightstruggle",
	tier: "released",
	mechanics: ["area-control"],
	interactionTags: [],
	nameKey: "games.twilightstruggle.name",
	descKey: "games.twilightstruggle.desc",
	rulesKey: "games.twilightstruggle.rules",
	icon: "🌐",
	iconImg: "games/twilightstruggle.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/twilightstruggle/en.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#b91c1c",
	releasedAt: "2026-10-02",
	search: {
		py: "leng zhan re dou",
		init: "lzrd"
	},
	hotseat: "cover"
}, nt = [...D, "chineseCivilWar"];
function rt(e) {
	let t = e.spending;
	return JSON.stringify([
		e.turn,
		e.current,
		e.arDone,
		t ? [
			t.card,
			t.side,
			t.opsLeft,
			t.mode,
			t.snapshot,
			t.free,
			t.restricted,
			t.asiaAll,
			t.seaAll,
			t.asiaBonus,
			t.seaBonus
		] : null,
		e.civilWar,
		e.china,
		e.mods.chernobyl,
		e.mods.vietnam,
		nt.map((t) => [
			t,
			e.influence[t]?.us ?? 0,
			e.influence[t]?.ussr ?? 0
		])
	]);
}
function it(e, t) {
	let n = e.spending, r = {
		...e,
		influence: { ...e.influence },
		china: { ...e.china },
		spending: n ? { ...n } : null
	};
	if (!n || n.mode !== "influence") return {
		view: r,
		targets: /* @__PURE__ */ new Set(),
		valid: !1,
		complete: !1
	};
	let i = {
		...n,
		ops: n.opsLeft,
		mode: "influence",
		blank: !1
	}, a = (t) => {
		if (i.ops <= 0 || i.restricted && !i.restricted.includes(t)) return !1;
		if (t === "chineseCivilWar") return e.civilWar && r.china.holder === null && i.side === "ussr" && e.mods.chernobyl !== "asia" && i.ops >= 1;
		if (!D.includes(t)) return !1;
		let n = w[t];
		return i.side === "ussr" && e.mods.chernobyl && n.regions.includes(e.mods.chernobyl) || !n.adjacent.includes(i.side) && !i.snapshot.includes(t) && !i.snapshot.some((e) => w[e].adjacent.includes(t)) ? !1 : i.ops >= (N(r, t) === T[i.side] ? 2 : 1);
	};
	for (let e of t) {
		if (!a(e)) return {
			view: r,
			targets: /* @__PURE__ */ new Set(),
			valid: !1,
			complete: !1
		};
		let t = N(r, e) === T[i.side] ? 2 : 1;
		W(i, e);
		let n = r.influence[e] ?? {
			us: 0,
			ussr: 0
		};
		r.influence[e] = {
			...n,
			[i.side]: n[i.side] + 1
		}, e === "chineseCivilWar" && r.influence[e].ussr >= 3 && (r.china = {
			holder: "ussr",
			faceUp: !0
		}), i.ops -= t;
	}
	r.spending = {
		...n,
		opsLeft: i.ops,
		asiaAll: i.asiaAll,
		seaAll: i.seaAll,
		asiaBonus: i.asiaBonus,
		seaBonus: i.seaBonus
	};
	let o = new Set(nt.filter(a));
	return {
		view: r,
		targets: o,
		valid: !0,
		complete: i.ops <= 0 || o.size === 0
	};
}
//#endregion
//#region src/games/twilightstruggle/setup-placement.ts
function at(e, t, n, r) {
	if (t <= 0) return [];
	let i = e === "ussr" ? "easternEurope" : "westernEurope", a = e === "us" && t <= n;
	return D.filter((e) => w[e].regions.includes(i) || a && (r[e]?.us ?? 0) > 0);
}
//#endregion
//#region src/games/twilightstruggle/country-draft.ts
function ot(e) {
	return JSON.stringify([
		e.turn,
		e.phase,
		e.current,
		e.arDone,
		e.setup,
		e.pending,
		e.influence,
		e.log.length
	]);
}
function st(e, t, n = [], r = !1) {
	let i = {
		...e,
		influence: structuredClone(e.influence),
		setup: e.setup ? { ...e.setup } : null,
		pending: e.pending ? structuredClone(e.pending) : null
	}, a = () => ({
		view: i,
		targets: /* @__PURE__ */ new Set(),
		valid: !1,
		complete: !1,
		remaining: 0,
		destal: !1
	});
	if (e.over) return a();
	if (i.phase === "setup" && i.setup) {
		if (n.length || r) return a();
		let e = i.setup, o = () => at(e.step, e.left, i.usBonus, i.influence);
		for (let n of t) {
			if (!o().includes(n)) return a();
			let t = i.influence[n] ?? {
				us: 0,
				ussr: 0
			};
			i.influence[n] = {
				...t,
				[e.step]: t[e.step] + 1
			}, --e.left;
		}
		return {
			view: i,
			targets: new Set(o()),
			valid: !0,
			complete: e.left === 0,
			remaining: e.left,
			destal: !1
		};
	}
	let o = i.pending;
	if (o?.kind !== "countries" || o.mode === "war") return a();
	let s = o.card === 33 && o.mode === "remove";
	if (!s && (n.length || r)) return a();
	let c = o, l = () => new Set(c.n > 0 ? c.pool.filter((e) => (c.used?.[e] ?? 0) < c.perMax) : []), u = (e) => {
		for (let t of e) {
			if (!l().has(t)) return !1;
			let e = i.influence[t] ?? {
				us: 0,
				ussr: 0
			}, n = c.target, r = c.amt ?? 1, a = c.mode, o = a === "add" ? e[n] + r : a === "remove" ? Math.max(0, e[n] - r) : a === "removeAll" ? 0 : a === "double" ? e[n] * 2 : e[T[n]], s = {
				...e,
				[n]: o
			};
			s.us || s.ussr ? i.influence[t] = s : delete i.influence[t], c.used = {
				...c.used,
				[t]: (c.used?.[t] ?? 0) + 1
			}, --c.n, c.pool = c.pool.filter((e) => (c.used?.[e] ?? 0) < c.perMax && (a === "add" || (i.influence[e]?.[n] ?? 0) > 0));
		}
		return !0;
	};
	if (s) {
		if (!u(n) || !r && t.length) return a();
		if (r) {
			let e = 4 - o.n, n = D.filter((e) => N(i, e) !== "us");
			if (c = {
				kind: "countries",
				side: "ussr",
				card: 33,
				pool: e > 0 ? n : [],
				n: e,
				perMax: 2,
				exact: !0,
				mode: "add",
				target: "ussr"
			}, i.pending = c, !u(t)) return a();
		}
	} else if (!u(t)) return a();
	return {
		view: i,
		targets: l(),
		valid: !0,
		complete: (!s || r) && (c.n <= 0 || l().size === 0 || !c.exact),
		remaining: c.n,
		destal: s
	};
}
//#endregion
//#region src/games/twilightstruggle/cuban-crisis.ts
var ct = {
	us: ["westGermany", "turkey"],
	ussr: ["cuba"]
};
function lt(e, t) {
	return !e.mods.cuban || e.mods.cuban === t ? [] : ct[t].filter((n) => (e.influence[n]?.[t] ?? 0) >= 2);
}
//#endregion
//#region src/games/twilightstruggle/schema.ts
var q = t.enum(["us", "ussr"]), J = t.number().int().min(1).max(110), Y = t.string(), ut = t.object({
	optionalCards: t.boolean(),
	hostSide: t.enum([
		"random",
		"us",
		"ussr"
	]),
	usBonus: t.number().int().min(0).max(4).default(0),
	civilWar: t.boolean().default(!1),
	legacyCambridgeActions: t.array(t.number().int().positive()).optional()
}).prefault({
	optionalCards: !0,
	hostSide: "random",
	usBonus: 0,
	civilWar: !1
}), dt = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("tick"),
		now: t.number()
	}),
	t.object({
		type: t.literal("setupPlace"),
		country: Y
	}),
	t.object({
		type: t.literal("allocateSetup"),
		context: t.string().max(12e3),
		countries: t.array(Y).max(11)
	}),
	t.object({
		type: t.literal("headline"),
		card: J
	}),
	t.object({
		type: t.literal("play"),
		card: J,
		mode: t.enum([
			"event",
			"influence",
			"coup",
			"realign",
			"space"
		]),
		first: t.enum(["event", "ops"]).optional(),
		withCard: J.optional()
	}),
	t.object({
		type: t.literal("place"),
		country: Y
	}),
	t.object({
		type: t.literal("allocateInfluence"),
		context: t.string().max(12e3),
		countries: t.array(Y).max(16)
	}),
	t.object({
		type: t.literal("coupAt"),
		country: Y
	}),
	t.object({
		type: t.literal("realignAt"),
		country: Y
	}),
	t.object({ type: t.literal("finishOps") }),
	t.object({
		type: t.literal("trapDiscard"),
		card: J
	}),
	t.object({
		type: t.literal("pickCountries"),
		countries: t.array(Y)
	}),
	t.object({
		type: t.literal("allocateCountries"),
		context: t.string().max(12e3),
		countries: t.array(Y).max(16),
		removals: t.array(Y).max(4).optional()
	}),
	t.object({
		type: t.literal("pickCards"),
		cards: t.array(J)
	}),
	t.object({
		type: t.literal("pickOption"),
		option: t.string()
	}),
	t.object({
		type: t.literal("cancelCuban"),
		country: t.enum([
			"cuba",
			"westGermany",
			"turkey"
		]).optional()
	}),
	t.object({ type: t.literal("passAr") })
]), ft = t.enum([
	"europe",
	"asia",
	"middleEast",
	"africa",
	"centralAmerica",
	"southAmerica",
	"westernEurope",
	"easternEurope",
	"southeastAsia"
]), pt = t.number().int().min(0).max(110), mt = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("countries"),
		side: q,
		card: pt,
		pool: t.array(Y),
		n: t.number().int().min(1),
		perMax: t.number().int().min(1),
		exact: t.boolean(),
		mode: t.enum([
			"add",
			"remove",
			"removeAll",
			"double",
			"match",
			"war"
		]),
		target: q,
		amt: t.number().int().min(1).optional(),
		used: t.record(Y, t.number().int().nonnegative()).optional()
	}),
	t.object({
		kind: t.literal("cards"),
		side: q,
		card: pt,
		pool: t.array(J),
		min: t.number().int().nonnegative(),
		max: t.number().int().min(1)
	}),
	t.object({
		kind: t.literal("option"),
		side: q,
		card: pt,
		options: t.array(t.string())
	})
]), ht = t.object({
	opsMinus: q.nullable(),
	opsPlus: q.nullable(),
	vietnam: t.boolean(),
	salt: t.boolean(),
	iranContra: t.boolean(),
	deathSquads: q.nullable(),
	chernobyl: ft.nullable(),
	nuclearSubs: t.boolean(),
	yuri: t.boolean(),
	u2: t.boolean(),
	bury: t.boolean(),
	northSeaOil: t.boolean(),
	warsaw: t.boolean(),
	marshall: t.boolean(),
	nato: t.boolean(),
	natoOff: t.array(Y),
	usJapan: t.boolean(),
	campDavid: t.boolean(),
	formosan: t.boolean(),
	flower: t.boolean(),
	ironLady: t.boolean(),
	reformer: t.boolean(),
	tearDown: t.boolean(),
	evilEmpire: t.boolean(),
	shuttle: t.boolean(),
	iranHostage: t.boolean(),
	awacs: t.boolean(),
	norad: t.boolean(),
	johnPaul: t.boolean(),
	cuban: q.nullable(),
	revealedHand: q.nullable()
}), gt = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("turn"),
		n: t.number().int()
	}),
	t.object({
		k: t.literal("headline"),
		us: J,
		ussr: J
	}),
	t.object({
		k: t.literal("play"),
		side: q,
		card: J,
		mode: t.string(),
		withCard: J.optional()
	}),
	t.object({
		k: t.literal("coup"),
		side: q,
		country: Y,
		roll: t.number().int(),
		success: t.boolean()
	}),
	t.object({
		k: t.literal("realign"),
		side: q,
		country: Y,
		usRoll: t.number().int(),
		ussrRoll: t.number().int(),
		removed: t.number().int()
	}),
	t.object({
		k: t.literal("space"),
		side: q,
		roll: t.number().int(),
		success: t.boolean(),
		pos: t.number().int()
	}),
	t.object({
		k: t.literal("war"),
		card: J,
		side: q,
		country: Y,
		roll: t.number().int(),
		success: t.boolean()
	}),
	t.object({
		k: t.literal("score"),
		region: t.string(),
		us: t.number().int(),
		ussr: t.number().int()
	}),
	t.object({
		k: t.literal("defcon"),
		n: t.number().int()
	}),
	t.object({
		k: t.literal("milops"),
		side: q,
		diff: t.number().int()
	}),
	t.object({
		k: t.literal("trap"),
		side: q,
		roll: t.number().int(),
		escaped: t.boolean()
	}),
	t.object({
		k: t.literal("over"),
		winner: q.nullable(),
		reason: t.string()
	}),
	t.object({
		k: t.literal("delta"),
		vp: t.number().int(),
		inf: t.array(t.object({
			c: Y,
			us: t.number().int(),
			ussr: t.number().int()
		}))
	})
]), _t = t.object({
	phase: t.enum([
		"setup",
		"headline",
		"ar",
		"turnEnd",
		"final",
		"over"
	]),
	turn: t.number().int().min(1),
	current: q.nullable(),
	seats: t.object({
		us: t.string(),
		ussr: t.string()
	}),
	defcon: t.number().int().min(1).max(5),
	vp: t.number().int(),
	milops: t.object({
		us: t.number().int(),
		ussr: t.number().int()
	}),
	space: t.object({
		us: t.number().int(),
		ussr: t.number().int()
	}),
	spaceUsed: t.object({
		us: t.number().int(),
		ussr: t.number().int()
	}),
	arDone: t.object({
		us: t.number().int(),
		ussr: t.number().int()
	}),
	arTotal: t.object({
		us: t.number().int(),
		ussr: t.number().int()
	}),
	civilWar: t.boolean(),
	usBonus: t.number().int().min(0).max(4),
	influence: t.record(t.string(), t.object({
		us: t.number().int(),
		ussr: t.number().int()
	})),
	china: t.object({
		holder: q.nullable(),
		faceUp: t.boolean()
	}),
	deckCount: t.number().int().nonnegative(),
	discard: t.array(J),
	removed: t.array(J),
	handCounts: t.object({
		us: t.number().int(),
		ussr: t.number().int()
	}),
	mods: ht,
	setup: t.object({
		step: q,
		left: t.number().int()
	}).nullable(),
	headline: t.object({
		usReady: t.boolean(),
		ussrReady: t.boolean(),
		usCard: J.nullable(),
		ussrCard: J.nullable()
	}).nullable(),
	spending: t.object({
		card: J,
		side: q,
		opsLeft: t.number().int(),
		mode: t.enum(["influence", "realign"]).nullable(),
		snapshot: t.array(Y),
		asiaAll: t.boolean(),
		seaAll: t.boolean(),
		asiaBonus: t.boolean(),
		seaBonus: t.boolean(),
		free: t.boolean(),
		restricted: t.array(Y).nullable()
	}).nullable(),
	coup: t.object({
		side: q,
		card: J,
		ops: t.number().int(),
		free: t.boolean(),
		restricted: t.array(Y).nullable(),
		che: t.boolean()
	}).nullable(),
	trapNow: t.boolean(),
	mustOps: t.object({
		us: J.nullable(),
		ussr: J.nullable()
	}),
	pending: mt.nullable(),
	afterEvent: J.nullable(),
	log: t.array(gt),
	over: t.object({
		winner: q.nullable(),
		reason: t.string()
	}).nullable()
}), vt = t.object({
	hand: t.array(J),
	pendingPool: t.array(J).nullable(),
	chinaReady: t.boolean(),
	oppHand: t.array(J).nullable(),
	headlineOpp: J.nullable(),
	offeredCard: J.nullable()
}), X = (e) => ({ code: e });
function yt(t, n, r) {
	let i = ut.parse(t), a = (i.hostSide === "random" ? e(r, 0, 2) === 0 : i.hostSide === "us") ? {
		us: n[0],
		ussr: n[1]
	} : {
		us: n[1],
		ussr: n[0]
	}, o = {
		seed: r,
		rng: +(i.hostSide === "random"),
		config: i,
		seats: a,
		actionCount: 0,
		lastCambridgeAction: null,
		turn: 1,
		phase: "setup",
		actor: null,
		influence: {},
		defcon: 5,
		vp: 0,
		milops: {
			us: 0,
			ussr: 0
		},
		space: {
			us: 0,
			ussr: 0
		},
		spaceUsed: {
			us: 0,
			ussr: 0
		},
		ars: {
			us: 0,
			ussr: 0
		},
		arTotal: {
			us: 6,
			ussr: 6
		},
		deck: [],
		discard: [],
		removed: [],
		hands: {
			us: [],
			ussr: []
		},
		china: {
			holder: i.civilWar ? null : "ussr",
			faceUp: !i.civilWar
		},
		mods: {
			opsMinus: null,
			opsPlus: null,
			vietnam: !1,
			salt: !1,
			iranContra: !1,
			deathSquads: null,
			chernobyl: null,
			nuclearSubs: !1,
			yuri: !1,
			u2: !1,
			bury: !1,
			northSeaOil: !1,
			warsaw: !1,
			marshall: !1,
			nato: !1,
			natoOff: [],
			usJapan: !1,
			campDavid: !1,
			formosan: !1,
			flower: !1,
			ironLady: !1,
			reformer: !1,
			tearDown: !1,
			evilEmpire: !1,
			shuttle: !1,
			iranHostage: !1,
			awacs: !1,
			norad: !1,
			johnPaul: !1,
			cuban: null,
			revealedHand: null
		},
		opecBan: !1,
		setup: {
			step: "ussr",
			left: 6
		},
		headline: null,
		hlQueue: [],
		spending: null,
		coup: null,
		pending: null,
		trap: null,
		mustOps: {
			us: null,
			ussr: null
		},
		afterOps: null,
		afterEvent: null,
		afterBlank: null,
		limbo: [],
		noradReady: !1,
		spaceDiscardQueue: [],
		endStep: 0,
		log: [],
		over: null
	};
	for (let [e, t, n] of [
		[
			"ussr",
			"northKorea",
			3
		],
		[
			"ussr",
			"eastGermany",
			3
		],
		[
			"ussr",
			"finland",
			1
		],
		[
			"ussr",
			"syria",
			1
		],
		[
			"ussr",
			"iraq",
			1
		],
		[
			"us",
			"australia",
			4
		],
		[
			"us",
			"canada",
			2
		],
		[
			"us",
			"uk",
			5
		],
		[
			"us",
			"panama",
			1
		],
		[
			"us",
			"israel",
			1
		],
		[
			"us",
			"iran",
			1
		],
		[
			"us",
			"southKorea",
			1
		],
		[
			"us",
			"japan",
			1
		],
		[
			"us",
			"southAfrica",
			1
		],
		[
			"us",
			"philippines",
			1
		]
	]) o.influence[t] = {
		us: e === "us" ? n : 0,
		ussr: e === "ussr" ? n : 0
	};
	return o.log.push({
		k: "turn",
		n: 1
	}), { state: o };
}
function bt(e, t) {
	for (let n = 0; n < 200; n++) {
		if (Et(e, t, n === 0), e.over || e.pending || e.spending || e.coup) return;
		if (e.afterBlank) {
			let t = e.afterBlank;
			e.afterBlank = null, ze(e, t.side, t.ops, t.canCoup, t.fromCard);
			continue;
		}
		if (e.afterOps) {
			let t = e.afterOps;
			e.afterOps = null, t.mode === "coup" ? U(e, e.actor, t.card) : He(e, e.actor, t.card, t.mode);
			continue;
		}
		if (e.afterEvent !== null) {
			let t = e.afterEvent;
			e.afterEvent = null;
			let n = We(e, t, e.actor);
			n && Ge(e, t, e.actor), G(e, t, n);
			continue;
		}
		if (e.endStep > 0) {
			Ct(e, t);
			continue;
		}
		if (e.phase === "headline") {
			if (xt(e)) continue;
			return;
		}
		if (e.phase === "ar") {
			if (St(e), e.endStep > 0) continue;
			return;
		}
		return;
	}
}
function xt(e) {
	let t = e.headline;
	if (!t) return !1;
	if (e.hlQueue.length === 0) return t.us !== null && t.ussr !== null && (e.phase = "ar", e.headline = null, e.actor = "ussr"), !1;
	let n = e.hlQueue.shift(), r = n === "us" ? t.us : t.ussr;
	if (e.actor = n, r === 103) {
		let r = T[n];
		return t[r] !== null && (e.discard.push(t[r]), e.hlQueue = e.hlQueue.filter((e) => e !== r)), G(e, 103, !1), !0;
	}
	if (C[r].scoring) et(e, r), G(e, r, !0);
	else {
		let t = We(e, r, n);
		t && Ge(e, r, n), G(e, r, t);
	}
	return !0;
}
function St(e) {
	let t = e.actor;
	if (!t) return;
	if (e.noradReady && (e.noradReady = !1, e.mods.norad && N(e, "canada") === "us")) {
		let t = he(e, "us");
		if (t.length > 0) {
			e.pending = {
				kind: "countries",
				side: "us",
				card: 106,
				tag: "norad",
				pool: t,
				n: 1,
				perMax: 1,
				exact: !1,
				mode: "add",
				target: "us"
			};
			return;
		}
	}
	e.ars[t] += 1;
	let n = T[t];
	e.ars[n] < e.arTotal[n] ? e.actor = n : e.ars[t] < e.arTotal[t] ? e.actor = t : (e.actor = null, e.endStep = 1);
}
function Ct(e, t) {
	switch (e.endStep) {
		case 1: {
			let t = (t) => e.hands[t].some((e) => C[e].scoring), n = t("us"), r = t("ussr");
			if (n || r) {
				e.over = {
					winner: n && r ? null : n ? "ussr" : "us",
					reason: "scoringHeld"
				}, e.log.push({
					k: "over",
					winner: e.over.winner,
					reason: "scoringHeld"
				});
				return;
			}
			e.endStep = 2;
			break;
		}
		case 2: {
			let t = e.mods;
			t.opsMinus = null, t.opsPlus = null, t.vietnam = !1, t.salt = !1, t.iranContra = !1, t.deathSquads = null, t.chernobyl = null, t.nuclearSubs = !1, t.yuri = !1, t.u2 = !1, t.northSeaOil = !1, t.cuban = null, t.revealedHand = null, e.spaceUsed = {
				us: 0,
				ussr: 0
			}, e.spaceDiscardQueue = ["ussr", "us"].filter((t) => e.space[t] >= 6 && e.space[T[t]] < 6 && e.hands[t].some((e) => e !== 6)), e.endStep = 3;
			break;
		}
		case 3: {
			let t = e.spaceDiscardQueue.shift();
			if (!t) {
				e.endStep = 4;
				break;
			}
			e.pending = {
				kind: "cards",
				side: t,
				card: 0,
				tag: "spaceDiscard",
				pool: e.hands[t],
				n: 0,
				perMax: 1,
				exact: !1,
				min: 0,
				max: 1
			};
			break;
		}
		case 4:
			for (let n of ["us", "ussr"]) {
				let r = e.defcon - e.milops[n];
				if (r > 0 && (e.log.push({
					k: "milops",
					side: n,
					diff: r
				}), F(e, n === "us" ? -r : r), Et(e, t), e.over)) return;
				e.milops[n] = 0;
			}
			e.endStep = 5;
			break;
		case 5:
			if (e.china.holder !== null && (e.china.faceUp = !0), e.turn += 1, e.turn > 10) {
				wt(e), e.endStep = 0, e.phase = "over";
				return;
			}
			e.endStep = 6;
			break;
		case 6:
			I(e, 1, "us"), e.endStep = 7;
			break;
		case 7:
			Ae(e), e.endStep = 8;
			break;
		case 8:
			ke(e), e.endStep = 9;
			break;
		case 9:
			e.ars = {
				us: 0,
				ussr: 0
			}, e.arTotal = {
				us: pe(e, "us"),
				ussr: pe(e, "ussr")
			}, e.log.push({
				k: "turn",
				n: e.turn
			}), e.phase = "headline", e.headline = {
				us: null,
				ussr: null
			}, e.hlQueue = [], e.endStep = 0;
			break;
		default: e.endStep = 0;
	}
}
function wt(e) {
	for (let t of [
		"asia",
		"europe",
		"middleEast",
		"africa",
		"centralAmerica",
		"southAmerica"
	]) if (Ee(e, t, !0), e.over) return;
	e.china.holder !== null && F(e, e.china.holder === "us" ? 1 : -1, !0);
	let t = e.vp > 0 ? "us" : e.vp < 0 ? "ussr" : null;
	e.over = {
		winner: t,
		reason: t ? "final" : "draw"
	}, e.log.push({
		k: "over",
		winner: t,
		reason: e.over.reason
	});
}
function Tt(e) {
	let t = {};
	for (let [n, r] of Object.entries(e.influence)) t[n] = { ...r };
	return {
		vp: e.vp,
		inf: t
	};
}
function Et(e, t, n = !0) {
	let r = e.vp - t.vp, i = [], a = /* @__PURE__ */ new Set([...Object.keys(t.inf), ...Object.keys(e.influence)]);
	for (let n of a) {
		let r = t.inf[n] ?? {
			us: 0,
			ussr: 0
		}, a = e.influence[n] ?? {
			us: 0,
			ussr: 0
		};
		(a.us !== r.us || a.ussr !== r.ussr) && i.push({
			c: n,
			us: a.us - r.us,
			ussr: a.ussr - r.ussr
		});
	}
	if (r === 0 && i.length === 0) return;
	Object.assign(t, Tt(e));
	let o = e.log[e.log.length - 1];
	if (n && o?.k === "delta") {
		o.vp += r;
		for (let e of i) {
			let t = o.inf.find((t) => t.c === e.c);
			t ? (t.us += e.us, t.ussr += e.ussr) : o.inf.push(e);
		}
		o.inf = o.inf.filter((e) => e.us !== 0 || e.ussr !== 0);
		return;
	}
	e.log.push({
		k: "delta",
		vp: r,
		inf: i
	});
}
function Dt(e, t, n) {
	let r = Tt(e), i = kt(e, t, n, r);
	return "state" in i && (Et(i.state, r), i.state.actionCount += 1), i;
}
function Ot(e, t) {
	return e.seats.us === t ? "us" : e.seats.ussr === t ? "ussr" : null;
}
function kt(e, t, n, r) {
	if (t.type === "tick") return { state: e };
	if (e.over) return X("games.twilightstruggle.errNotYourTurn");
	let i = Ot(e, n.by);
	if (!i) return X("games.twilightstruggle.errNotYourTurn");
	switch (t.type) {
		case "setupPlace": return At(e, i, t.country);
		case "allocateSetup": return jt(e, i, t, r);
		case "headline": return Mt(e, i, t.card, r);
		case "play": return Nt(e, i, t, r);
		case "place": return Rt(e, i, t.country, r);
		case "allocateInfluence": return Lt(e, i, t, r);
		case "allocateCountries": return jt(e, i, t, r);
		case "coupAt": return Bt(e, i, t.country, r);
		case "realignAt": return zt(e, i, t.country, r);
		case "finishOps": return Vt(e, i, r);
		case "trapDiscard": return Ht(e, i, t.card, r);
		case "pickCountries": return qe(e, i, t.countries) || (bt(e, r), { state: e });
		case "pickCards": return Ye(e, i, t.cards) || (bt(e, r), { state: e });
		case "pickOption": return Ze(e, i, t.option) || (bt(e, r), { state: e });
		case "cancelCuban": return Ut(e, i, t.country);
		case "passAr": return Wt(e, i, r);
		default: return X("games.twilightstruggle.errBadMode");
	}
}
function At(e, t, n) {
	return e.phase !== "setup" || !e.setup || e.setup.step !== t ? X("games.twilightstruggle.errNotYourTurn") : at(t, e.setup.left, e.config.usBonus, e.influence).includes(n) ? (e.influence[n] = e.influence[n] ?? {
		us: 0,
		ussr: 0
	}, e.influence[n][t] += 1, --e.setup.left, e.setup.left === 0 && (t === "ussr" ? e.setup = {
		step: "us",
		left: 7 + e.config.usBonus
	} : (e.setup = null, e.deck = me(e, Oe(e, "early")), ke(e), e.phase = "headline", e.headline = {
		us: null,
		ussr: null
	}, e.hlQueue = [])), { state: e }) : X("games.twilightstruggle.errSetup");
}
function jt(e, t, n, r) {
	let i = Kt(e, e.seats[t]).public, a = n.type === "allocateSetup";
	if (e.over || n.context !== ot(i) || (a ? e.phase !== "setup" || e.setup?.step !== t : e.pending?.kind !== "countries" || e.pending.side !== t || e.pending.mode === "war")) return X("games.twilightstruggle.errPending");
	let o = a ? [] : n.removals ?? [], s = !a && e.pending?.tag === "destalRemove", c = st(i, n.countries, o, s);
	if (!c.valid || !c.complete) return X("games.twilightstruggle.errBadAlloc");
	let l = structuredClone(e);
	if (a) for (let e of n.countries) {
		let n = At(l, t, e);
		if ("code" in n) return n;
	}
	else {
		let e = (e) => {
			let n = l.pending;
			for (let r of e) {
				if (l.pending !== n) return X("games.twilightstruggle.errBadAlloc");
				let e = qe(l, t, [r]);
				if (e) return e;
			}
			return l.pending === n ? qe(l, t, []) : null;
		};
		if (s) {
			let t = e(o);
			if (t) return t;
			if (l.pending?.tag !== "destalAdd") {
				if (n.countries.length) return X("games.twilightstruggle.errBadAlloc");
			} else {
				let t = e(n.countries);
				if (t) return t;
			}
		} else {
			let t = e(n.countries);
			if (t) return t;
		}
		bt(l, r);
	}
	return { state: l };
}
function Mt(e, t, n, r) {
	if (e.phase !== "headline" || !e.headline || e.headline[t] !== null) return X("games.twilightstruggle.errNotYourTurn");
	if (!e.hands[t].includes(n)) return X("games.twilightstruggle.errBadCard");
	if (C[n].noHeadline || e.config.civilWar && e.china.holder === null && (n === 58 || n === 35 || n === 31 && t === "ussr")) return X("games.twilightstruggle.errHeadline");
	if (K(e, t, n), e.headline[t] = n, e.headline.us !== null && e.headline.ussr !== null) {
		let t = C[e.headline.us].ops, n = C[e.headline.ussr].ops;
		e.log.push({
			k: "headline",
			us: e.headline.us,
			ussr: e.headline.ussr
		});
		let i = e.headline.us === 103 ? "us" : e.headline.ussr === 103 ? "ussr" : null;
		e.hlQueue = i ? [i, T[i]] : t >= n ? ["us", "ussr"] : ["ussr", "us"], bt(e, r);
	}
	return { state: e };
}
function Nt(e, t, n, r) {
	if (e.phase !== "ar" || e.actor !== t) return X("games.twilightstruggle.errNotYourTurn");
	if (e.pending || e.spending || e.coup) return X("games.twilightstruggle.errPending");
	let i = C[n.card];
	if (!i) return X("games.twilightstruggle.errBadCard");
	let a = n.card === 6;
	if (!a && !e.hands[t].includes(n.card) || a && !(e.china.holder === t && e.china.faceUp)) return X("games.twilightstruggle.errBadCard");
	if (e.trap === t && (e.hands[t].some((n) => !C[n].scoring && L(e, t, C[n].ops) >= 2) || !i.scoring || n.mode !== "event")) return X("games.twilightstruggle.errTrap");
	let o = e.trap === t && !e.hands[t].some((n) => !C[n].scoring && L(e, t, C[n].ops) >= 2);
	if (e.mustOps[t] !== null && !o && (n.card !== e.mustOps[t] || n.mode === "event") || i.scoring && n.mode !== "event" || a && n.mode === "event") return X("games.twilightstruggle.errBadMode");
	if (n.card === 32 && n.mode === "event") {
		if (n.withCard === void 0 || !e.hands[t].includes(n.withCard)) return X("games.twilightstruggle.errBadCard");
		if (C[n.withCard].side !== T[t]) return X("games.twilightstruggle.errBadMode");
	}
	if (n.mode === "event" && e.config.civilWar && e.china.holder === null && (n.card === 58 || n.card === 35 || n.card === 31 && t === "ussr")) return X("games.twilightstruggle.errBadMode");
	if (e.mods.bury && t === "us" && ((n.card !== 32 || n.mode !== "event") && F(e, -3), e.mods.bury = !1), t === "us" && e.mods.flower && ue.includes(n.card) && n.mode !== "space" && F(e, -2), a && t === "us" && (e.mods.formosan = !1), e.log.push({
		k: "play",
		side: t,
		card: n.card,
		mode: n.mode,
		...n.card === 32 && n.mode === "event" ? { withCard: n.withCard } : {}
	}), n.mode === "event") {
		if (i.scoring) return K(e, t, n.card), et(e, n.card), G(e, n.card, !0), bt(e, r), { state: e };
		if (n.card === 32) return Ft(e, t, n.withCard, r);
		K(e, t, n.card);
		let a = We(e, n.card, t);
		return a && Ge(e, n.card, t), G(e, n.card, a), bt(e, r), { state: e };
	}
	if (n.mode === "space") return Be(e, t, L(e, t, i.ops)) ? (Pt(e, t, n.card), G(e, n.card, !1), Ve(e, t), bt(e, r), { state: e }) : X("games.twilightstruggle.errOps");
	if (n.mode === "coup" && !D.some((n) => be(e, n, t))) return X("games.twilightstruggle.errNoCoupTarget");
	let s = i.side === T[t] && We(e, n.card, t);
	return Pt(e, t, n.card), s && n.first === "event" ? (Ge(e, n.card, t), G(e, n.card, !0), e.afterOps = {
		card: n.card,
		mode: n.mode
	}) : (s ? e.afterEvent = n.card : G(e, n.card, !1), n.mode === "coup" ? U(e, t, n.card) : He(e, t, n.card, n.mode)), bt(e, r), { state: e };
}
function Pt(e, t, n) {
	n === 6 ? e.china = {
		holder: T[t],
		faceUp: !1
	} : K(e, t, n);
}
function Ft(e, t, n, r) {
	return n === void 0 || !e.hands[t].includes(n) ? X("games.twilightstruggle.errBadCard") : C[n].side === T[t] ? (K(e, t, 32), K(e, t, n), e.discard.push(32, n), e.mods.u2 && F(e, -1), ze(e, t, L(e, t, C[n].ops), !0, n), bt(e, r), { state: e }) : X("games.twilightstruggle.errBadMode");
}
function It(e, t, n) {
	e.hands[t].includes(n) && (K(e, t, n), e.discard.push(n));
}
function Lt(e, t, n, r) {
	if (!e.spending || e.spending.side !== t || e.spending.mode !== "influence" || n.context !== rt(Kt(e, e.seats[t]).public)) return X("games.twilightstruggle.errPending");
	let i = structuredClone(e), a = i.spending;
	for (let e of n.countries) {
		if (i.spending !== a) return X("games.twilightstruggle.errBadAlloc");
		let n = Rt(i, t, e, r);
		if ("code" in n) return n;
	}
	return i.spending === a ? Vt(i, t, r) : { state: i };
}
function Rt(e, t, n, r) {
	let i = e.spending;
	if (!i || i.side !== t || i.mode !== "influence") return X("games.twilightstruggle.errPending");
	if (e.mods.chernobyl && t === "ussr" && w[n]?.regions.includes(e.mods.chernobyl)) return X("games.twilightstruggle.errChernobyl");
	if (!Ue(e, i, n)) return X("games.twilightstruggle.errBadTarget");
	let a = N(e, n) === T[t] ? 2 : 1;
	return W(i, n), e.influence[n] = e.influence[n] ?? {
		us: 0,
		ussr: 0
	}, e.influence[n][t] += 1, n === "chineseCivilWar" && e.influence[n].ussr >= 3 && (e.china = {
		holder: "ussr",
		faceUp: !0
	}), i.ops -= a, i.ops <= 0 && (i.blank && It(e, t, i.card), e.spending = null, bt(e, r)), { state: e };
}
function zt(e, t, n, r) {
	let i = e.spending;
	return !i || i.side !== t || i.mode !== "realign" ? X("games.twilightstruggle.errPending") : i.restricted && !i.restricted.includes(n) || !R(e, n, t, i.free) ? X("games.twilightstruggle.errBadTarget") : (W(i, n), Se(e, t, n), --i.ops, i.ops <= 0 && (i.blank && It(e, t, i.card), e.spending = null, bt(e, r)), { state: e });
}
function Bt(e, t, n, r) {
	let i = e.coup;
	if (!i || i.side !== t) return X("games.twilightstruggle.errPending");
	if (i.restricted && !i.restricted.includes(n) || i.cheUsed === n || !be(e, n, t, i.free)) return X("games.twilightstruggle.errBadTarget");
	if (t === "ussr" && e.mods.reformer && w[n].regions.includes("europe") && !i.free) return X("games.twilightstruggle.errReformer");
	let a = xe(e, i, n);
	if (i.che && !i.cheUsed && a && !e.over) {
		let r = (i.restricted ?? []).filter((e) => e !== n);
		if (r.some((n) => be(e, n, t, !0))) return e.coup = {
			...i,
			restricted: r,
			cheUsed: n
		}, { state: e };
	}
	return It(e, t, i.card), e.coup = null, bt(e, r), { state: e };
}
function Vt(e, t, n) {
	if (e.coup && e.coup.side === t && e.coup.free) return e.coup = null, bt(e, n), { state: e };
	let r = e.spending;
	return !r || r.side !== t ? X("games.twilightstruggle.errPending") : r.mode === "influence" && r.ops > 0 && (D.some((t) => Ue(e, r, t)) || Ue(e, r, "chineseCivilWar")) ? X("games.twilightstruggle.errOps") : (r.blank && It(e, t, r.card), e.spending = null, bt(e, n), { state: e });
}
function Ht(e, t, n, r) {
	if (e.phase !== "ar" || e.actor !== t || e.trap !== t) return X("games.twilightstruggle.errTrap");
	if (e.pending || e.spending || e.coup) return X("games.twilightstruggle.errPending");
	if (!e.hands[t].includes(n) || C[n].scoring || L(e, t, C[n].ops) < 2) return X("games.twilightstruggle.errBadCard");
	K(e, t, n), e.discard.push(n), e.log.push({
		k: "play",
		side: t,
		card: n,
		mode: "discard",
		withCard: t === "us" ? 42 : 44
	});
	let i = k(e), a = i <= 4;
	return a && (e.trap = null), e.log.push({
		k: "trap",
		side: t,
		roll: i,
		escaped: a
	}), bt(e, r), { state: e };
}
function Ut(e, t, n) {
	if (!e.mods.cuban || e.mods.cuban === t) return X("games.twilightstruggle.errBadMode");
	if (n !== void 0) return e.phase === "setup" || !lt(e, t).includes(n) ? X("games.twilightstruggle.errBadTarget") : (e.influence[n][t] -= 2, e.mods.cuban = null, e.pending?.tag === "cubanCancel" && (e.pending = null), { state: e });
	if (e.phase !== "ar" || e.actor !== t || e.pending || e.spending || e.coup) return X("games.twilightstruggle.errPending");
	if (t === "ussr") {
		if (A(e, "cuba").ussr < 2) return X("games.twilightstruggle.errBadTarget");
		e.influence.cuba.ussr -= 2, e.mods.cuban = null;
	} else {
		let n = ["westGermany", "turkey"].filter((t) => A(e, t).us >= 2);
		if (n.length === 0) return X("games.twilightstruggle.errBadTarget");
		n.length === 1 ? (e.influence[n[0]].us -= 2, e.mods.cuban = null) : e.pending = {
			kind: "option",
			side: t,
			card: 40,
			tag: "cubanCancel",
			pool: [],
			n: 0,
			perMax: 1,
			exact: !0,
			options: [...n]
		};
	}
	return { state: e };
}
function Wt(e, t, n) {
	if (e.phase !== "ar" || e.actor !== t) return X("games.twilightstruggle.errNotYourTurn");
	if (e.pending || e.spending || e.coup) return X("games.twilightstruggle.errPending");
	let r = e.ars[t] === 7 && e.arTotal[t] === 8, i = e.hands[t].length === 0 && !(e.china.holder === t && e.china.faceUp), a = e.trap === t && !e.hands[t].some((n) => !C[n].scoring && L(e, t, C[n].ops) >= 2) && !e.hands[t].some((e) => C[e].scoring);
	return !r && !i && !a || e.mustOps[t] !== null && !i && !a ? X("games.twilightstruggle.errBadMode") : (a && e.log.push({
		k: "play",
		side: t,
		card: t === "us" ? 42 : 44,
		mode: "skip"
	}), Gt(e, n), { state: e });
}
function Gt(e, t) {
	bt(e, t);
}
function Kt(e, t) {
	let n = Ot(e, t), r = e.headline, i = r !== null && r.us !== null && r.ussr !== null, a = {
		phase: e.over ? "over" : e.endStep > 0 ? "turnEnd" : e.phase,
		turn: e.turn,
		current: e.actor,
		seats: e.seats,
		defcon: e.defcon,
		vp: e.vp,
		milops: e.milops,
		space: e.space,
		spaceUsed: e.spaceUsed,
		arDone: e.ars,
		arTotal: e.arTotal,
		civilWar: e.config.civilWar,
		usBonus: e.config.usBonus,
		influence: e.influence,
		china: e.china,
		deckCount: e.deck.length,
		discard: e.discard,
		removed: e.removed,
		handCounts: {
			us: e.hands.us.length,
			ussr: e.hands.ussr.length
		},
		mods: e.mods,
		setup: e.setup,
		headline: r ? {
			usReady: r.us !== null,
			ussrReady: r.ussr !== null,
			usCard: i ? r.us : null,
			ussrCard: i ? r.ussr : null
		} : null,
		spending: e.spending ? {
			card: e.spending.card,
			side: e.spending.side,
			opsLeft: e.spending.ops,
			mode: e.spending.mode,
			snapshot: e.spending.snapshot,
			free: e.spending.free,
			restricted: e.spending.restricted,
			asiaAll: e.spending.asiaAll,
			seaAll: e.spending.seaAll,
			asiaBonus: e.spending.asiaBonus,
			seaBonus: e.spending.seaBonus
		} : null,
		coup: e.coup ? {
			side: e.coup.side,
			card: e.coup.card,
			ops: e.coup.ops,
			free: e.coup.free,
			restricted: e.coup.restricted,
			che: e.coup.che
		} : null,
		trapNow: e.trap !== null && e.trap === e.actor && e.phase === "ar" && !e.pending && !e.spending && !e.coup,
		mustOps: e.mustOps,
		afterEvent: e.afterEvent,
		pending: e.pending ? e.pending.kind === "countries" ? {
			kind: "countries",
			side: e.pending.side,
			card: e.pending.card,
			pool: e.pending.mode === "remove" ? e.pending.pool.filter((t) => A(e, t)[e.pending.target] > 0) : e.pending.pool,
			n: e.pending.n,
			perMax: e.pending.perMax,
			exact: e.pending.exact,
			mode: e.pending.mode ?? "add",
			target: e.pending.target ?? "us",
			amt: e.pending.amt,
			used: e.pending.data?.used
		} : e.pending.kind === "cards" ? {
			kind: "cards",
			side: e.pending.side,
			card: e.pending.card,
			pool: [],
			min: e.pending.min ?? 0,
			max: e.pending.max ?? 0
		} : {
			kind: "option",
			side: e.pending.side,
			card: e.pending.card,
			options: e.pending.options ?? []
		} : null,
		log: e.log,
		over: e.over
	};
	if (!n) return { public: a };
	let o = T[n];
	return {
		public: a,
		private: {
			hand: e.hands[n],
			pendingPool: e.pending && e.pending.side === n && e.pending.kind === "cards" ? e.pending.pool : null,
			chinaReady: e.china.holder === n && e.china.faceUp,
			oppHand: e.mods.revealedHand === o ? [...e.hands[o]] : null,
			headlineOpp: r && e.space[n] >= 4 && e.space[o] < 4 ? r[o] : null,
			offeredCard: e.pending?.side === n && (e.pending.tag === "grainSales" || e.pending.tag === "grainPlay") ? e.pending.data?.card ?? null : null
		}
	};
}
function qt(e) {
	if (!e.over) return { phase: e.phase };
	let t = e.seats.us, n = e.seats.ussr;
	return {
		phase: "over",
		winner: e.over.winner ? [e.seats[e.over.winner]] : [],
		ranking: e.over.winner ? [e.seats[e.over.winner], e.seats[T[e.over.winner]]] : [t, n],
		scores: {
			[t]: e.vp,
			[n]: -e.vp
		}
	};
}
function Jt({ version: e, log: t }) {
	if (e !== void 0 && e !== "1") return null;
	let n = t[0];
	if (!n || n.type !== "$setup" || !Array.isArray(n.players) || !n.players.length || !n.players.every((e) => typeof e == "string") || new Set(n.players).size !== n.players.length || typeof n.seed != "number" || !Number.isFinite(n.seed)) return null;
	let r = ut.safeParse(n.config);
	if (!r.success) return null;
	let i = {
		...r.data,
		legacyCambridgeActions: []
	};
	for (;;) {
		let e = yt(i, n.players, n.seed).state, r = !1;
		for (let a = 1; a < t.length; a++) {
			let o = t[a];
			if (!o || typeof o.by != "string") return null;
			let s = dt.safeParse(o.action);
			if (!s.success || (s.data.type === "tick" ? o.by !== "$engine" : !n.players.includes(o.by))) return null;
			let c = Dt(e, s.data, { by: o.by });
			if ("code" in c) {
				let t = e.lastCambridgeAction;
				if (t === null || i.legacyCambridgeActions.includes(t)) return null;
				i.legacyCambridgeActions.push(t), r = !0;
				break;
			}
			e = c.state;
		}
		if (!r) return [{
			...n,
			config: i,
			saveVersion: "2"
		}, ...t.slice(1)];
	}
}
var Yt = {
	saveCompatibility: {
		version: "2",
		migrate: Jt
	},
	meta: tt,
	schemas: {
		action: dt,
		publicView: _t,
		privateView: vt,
		config: ut
	},
	setup: yt,
	reduce: Dt,
	viewFor: Kt,
	status: qt
}, Xt = 9182, Zt = 5940, Qt = {
	afghanistan: {
		x: 6024,
		y: 2208,
		w: 352,
		h: 224
	},
	algeria: {
		x: 3489,
		y: 2340,
		w: 353,
		h: 233
	},
	angola: {
		x: 4112,
		y: 4064,
		w: 352,
		h: 232
	},
	argentina: {
		x: 1736,
		y: 5096,
		w: 352,
		h: 224
	},
	australia: {
		x: 8017,
		y: 4338,
		w: 354,
		h: 233
	},
	austria: {
		x: 3912,
		y: 1528,
		w: 352,
		h: 232
	},
	benelux: {
		x: 3280,
		y: 1248,
		w: 416,
		h: 232
	},
	bolivia: {
		x: 1816,
		y: 4248,
		w: 353,
		h: 222
	},
	botswana: {
		x: 4464,
		y: 4488,
		w: 352,
		h: 224
	},
	brazil: {
		x: 2504,
		y: 3960,
		w: 352,
		h: 232
	},
	bulgaria: {
		x: 4626,
		y: 1807,
		w: 352,
		h: 233
	},
	burma: {
		x: 6952,
		y: 2792,
		w: 352,
		h: 232
	},
	cameroon: {
		x: 3976,
		y: 3608,
		w: 360,
		h: 232
	},
	canada: {
		x: 1515,
		y: 1296,
		w: 352,
		h: 231
	},
	chile: {
		x: 1600,
		y: 4568,
		w: 352,
		h: 240
	},
	chineseCivilWar: {
		x: 7340,
		y: 1980,
		w: 480,
		h: 330
	},
	colombia: {
		x: 1595,
		y: 3561,
		w: 352,
		h: 234
	},
	costaRica: {
		x: 897,
		y: 3239,
		w: 354,
		h: 231
	},
	cuba: {
		x: 1360,
		y: 2608,
		w: 352,
		h: 232
	},
	czechoslovakia: {
		x: 4224,
		y: 1248,
		w: 352,
		h: 232
	},
	denmark: {
		x: 3568,
		y: 720,
		w: 352,
		h: 248
	},
	dominicanRepublic: {
		x: 2135,
		y: 2856,
		w: 353,
		h: 232
	},
	eastGermany: {
		x: 3882,
		y: 984,
		w: 352,
		h: 231
	},
	ecuador: {
		x: 1176,
		y: 3688,
		w: 352,
		h: 240
	},
	egypt: {
		x: 4536,
		y: 2664,
		w: 352,
		h: 224
	},
	elSalvador: {
		x: 534,
		y: 2996,
		w: 353,
		h: 219
	},
	ethiopia: {
		x: 4888,
		y: 3272,
		w: 352,
		h: 224
	},
	finland: {
		x: 4544,
		y: 464,
		w: 352,
		h: 224
	},
	france: {
		x: 3280,
		y: 1576,
		w: 352,
		h: 240
	},
	greece: {
		x: 4304,
		y: 2096,
		w: 368,
		h: 248
	},
	guatemala: {
		x: 664,
		y: 2696,
		w: 352,
		h: 224
	},
	gulfStates: {
		x: 5424,
		y: 2661,
		w: 355,
		h: 219
	},
	haiti: {
		x: 1752,
		y: 2864,
		w: 344,
		h: 224
	},
	honduras: {
		x: 935,
		y: 2961,
		w: 353,
		h: 232
	},
	hungary: {
		x: 4312,
		y: 1528,
		w: 352,
		h: 232
	},
	india: {
		x: 6472,
		y: 2744,
		w: 352,
		h: 224
	},
	indonesia: {
		x: 8016,
		y: 3864,
		w: 344,
		h: 224
	},
	iran: {
		x: 5544,
		y: 2368,
		w: 368,
		h: 248
	},
	iraq: {
		x: 5176,
		y: 2384,
		w: 352,
		h: 232
	},
	israel: {
		x: 4712,
		y: 2384,
		w: 360,
		h: 232
	},
	italy: {
		x: 3808,
		y: 1808,
		w: 360,
		h: 248
	},
	ivoryCoast: {
		x: 3309,
		y: 3359,
		w: 353,
		h: 209
	},
	japan: {
		x: 8472,
		y: 2376,
		w: 352,
		h: 224
	},
	jordan: {
		x: 4968,
		y: 2648,
		w: 360,
		h: 240
	},
	kenya: {
		x: 4927,
		y: 3624,
		w: 353,
		h: 231
	},
	laosCambodia: {
		x: 7352,
		y: 2840,
		w: 336,
		h: 224
	},
	lebanon: {
		x: 4792,
		y: 2112,
		w: 352,
		h: 232
	},
	libya: {
		x: 4128,
		y: 2624,
		w: 352,
		h: 232
	},
	malaysia: {
		x: 7360,
		y: 3536,
		w: 352,
		h: 224
	},
	mexico: {
		x: 320,
		y: 2409,
		w: 353,
		h: 231
	},
	morocco: {
		x: 3091,
		y: 2462,
		w: 354,
		h: 231
	},
	nicaragua: {
		x: 1332,
		y: 2964,
		w: 354,
		h: 231
	},
	nigeria: {
		x: 3808,
		y: 3296,
		w: 352,
		h: 232
	},
	northKorea: {
		x: 8080,
		y: 1840,
		w: 352,
		h: 224
	},
	norway: {
		x: 3480,
		y: 440,
		w: 352,
		h: 232
	},
	pakistan: {
		x: 6040,
		y: 2552,
		w: 344,
		h: 232
	},
	panama: {
		x: 1344,
		y: 3224,
		w: 352,
		h: 240
	},
	paraguay: {
		x: 2048,
		y: 4536,
		w: 352,
		h: 232
	},
	peru: {
		x: 1408,
		y: 3984,
		w: 352,
		h: 232
	},
	philippines: {
		x: 8160,
		y: 3104,
		w: 352,
		h: 224
	},
	poland: {
		x: 4296,
		y: 984,
		w: 352,
		h: 232
	},
	romania: {
		x: 4704,
		y: 1525,
		w: 353,
		h: 233
	},
	saharanStates: {
		x: 3647,
		y: 2907,
		w: 358,
		h: 235
	},
	saudiArabia: {
		x: 5256,
		y: 2920,
		w: 408,
		h: 232
	},
	seAfricanStates: {
		x: 4984,
		y: 4e3,
		w: 352,
		h: 224
	},
	somalia: {
		x: 5322,
		y: 3385,
		w: 354,
		h: 235
	},
	southAfrica: {
		x: 4280,
		y: 4784,
		w: 344,
		h: 232
	},
	southKorea: {
		x: 8160,
		y: 2112,
		w: 352,
		h: 232
	},
	spainPortugal: {
		x: 2984,
		y: 1952,
		w: 360,
		h: 232
	},
	sudan: {
		x: 4602,
		y: 2984,
		w: 354,
		h: 231
	},
	sweden: {
		x: 4024,
		y: 680,
		w: 368,
		h: 248
	},
	syria: {
		x: 5176,
		y: 2104,
		w: 352,
		h: 232
	},
	taiwan: {
		x: 7992,
		y: 2688,
		w: 344,
		h: 232
	},
	thailand: {
		x: 7176,
		y: 3112,
		w: 352,
		h: 224
	},
	tunisia: {
		x: 3904,
		y: 2312,
		w: 344,
		h: 224
	},
	turkey: {
		x: 5024,
		y: 1840,
		w: 368,
		h: 232
	},
	uk: {
		x: 3e3,
		y: 976,
		w: 392,
		h: 240
	},
	uruguay: {
		x: 2170,
		y: 4874,
		w: 352,
		h: 231
	},
	venezuela: {
		x: 1816,
		y: 3272,
		w: 360,
		h: 232
	},
	vietnam: {
		x: 7576,
		y: 3120,
		w: 352,
		h: 224
	},
	westAfricanStates: {
		x: 3052,
		y: 2814,
		w: 355,
		h: 231
	},
	westGermany: {
		x: 3744,
		y: 1248,
		w: 344,
		h: 232
	},
	yugoslavia: {
		x: 4216,
		y: 1823,
		w: 352,
		h: 217
	},
	zaire: {
		x: 4456,
		y: 3744,
		w: 352,
		h: 224
	},
	zimbabwe: {
		x: 4589,
		y: 4225,
		w: 353,
		h: 205
	}
}, $t = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 2296 1485\">\n<rect width=\"2296\" height=\"1485\" fill=\"#cbcbc7\"/>\n<path fill=\"#af2124\" fill-rule=\"evenodd\" d=\"M1229,0L2296,0L2296,260L2279,260L2279,261L2275,262L2274,264L2272,264L2271,266L2267,267L2266,269L2262,270L2261,272L2257,273L2257,274L2254,275L2253,277L2251,277L2251,278L2249,278L2248,280L2244,281L2244,283L2237,289L2237,291L2231,296L2231,298L2225,303L2225,305L2224,305L2224,306L2218,311L2218,313L2213,317L2213,318L2215,318L2215,319L2217,319L2217,320L2219,320L2219,321L2221,321L2221,322L2223,322L2223,323L2226,323L2226,324L2228,324L2228,325L2230,325L2230,326L2232,326L2232,327L2235,327L2235,328L2237,328L2237,329L2239,329L2239,330L2241,330L2241,331L2244,331L2244,332L2246,332L2246,333L2248,333L2248,334L2250,334L2250,335L2252,335L2252,336L2255,336L2255,337L2261,339L2261,343L2260,343L2260,346L2259,346L2259,349L2258,349L2258,352L2257,352L2257,355L2256,355L2256,359L2255,359L2255,362L2254,362L2254,365L2253,365L2253,368L2252,368L2252,371L2251,371L2251,374L2250,374L2250,377L2249,377L2249,380L2248,380L2248,383L2247,383L2247,386L2246,386L2246,389L2245,389L2245,392L2244,392L2244,395L2243,395L2243,398L2242,398L2242,401L2241,401L2241,404L2240,404L2240,407L2239,407L2239,410L2238,410L2238,413L2237,413L2237,416L2236,416L2236,419L2235,419L2235,422L2234,422L2233,427L2227,432L2227,434L2221,439L2221,441L2216,445L2216,447L2210,452L2210,454L2204,459L2204,461L2203,461L2203,462L2198,466L2198,468L2192,473L2192,475L2187,479L2187,481L2186,481L2182,486L2158,486L2158,487L2152,489L2151,491L2149,491L2149,492L2143,494L2142,496L2136,498L2135,500L2129,502L2128,504L2122,506L2121,508L2119,508L2119,509L2113,511L2112,513L2106,515L2105,517L2103,517L2103,518L2101,518L2101,519L2091,519L2091,520L2090,520L2085,526L2083,526L2076,534L2073,534L2072,527L2071,527L2071,524L2070,524L2070,520L2065,520L2065,519L2060,519L2060,518L2056,518L2056,519L2055,519L2055,521L2054,521L2053,524L2051,525L2051,530L2050,530L2050,534L2049,534L2049,539L2051,540L2051,542L2052,542L2053,544L2060,544L2060,543L2067,543L2067,542L2077,542L2080,546L2082,546L2082,547L2085,549L2085,551L2084,551L2078,558L2076,558L2075,560L2072,560L2072,561L2069,561L2069,562L2066,562L2066,563L2057,565L2057,571L2058,571L2058,574L2059,574L2059,577L2060,577L2060,580L2061,580L2061,584L2062,584L2062,586L2064,587L2064,589L2065,589L2065,591L2066,591L2066,593L2067,593L2067,595L2068,595L2068,597L2069,597L2069,599L2070,599L2070,601L2071,601L2071,603L2072,603L2072,605L2073,605L2073,618L2067,623L2069,626L2071,626L2072,628L2075,629L2075,634L2074,634L2074,638L2073,638L2073,641L2072,641L2072,645L2071,645L2071,649L2070,649L2069,656L2068,656L2068,658L2065,660L2065,662L2061,665L2061,667L2058,669L2058,671L2054,674L2054,676L2050,679L2050,681L2049,681L2028,703L2026,703L2026,704L2025,704L2022,708L2020,708L2017,712L2012,713L2012,714L2009,714L2009,715L2006,715L2006,716L2003,716L2003,717L2000,717L2000,718L1997,718L1997,719L1994,719L1993,721L1991,721L1990,723L1988,723L1988,724L1986,724L1986,725L1984,725L1984,726L1981,726L1981,727L1979,727L1979,728L1976,728L1976,729L1974,729L1974,730L1971,730L1971,731L1967,732L1967,733L1969,734L1969,736L1971,737L1971,739L1973,740L1973,743L1972,743L1972,745L1971,745L1959,758L1956,758L1952,753L1950,753L1950,752L1947,750L1947,748L1950,747L1950,746L1952,746L1953,744L1959,742L1959,729L1942,725L1942,724L1940,724L1939,722L1935,721L1934,719L1932,719L1932,718L1929,717L1929,716L1918,716L1918,717L1908,717L1908,718L1898,718L1898,719L1886,719L1886,718L1883,718L1883,717L1881,717L1881,716L1879,716L1879,715L1877,715L1877,714L1875,714L1875,713L1873,713L1873,712L1871,712L1871,711L1868,711L1868,710L1866,710L1866,709L1864,709L1864,708L1858,706L1858,705L1857,705L1857,700L1856,700L1856,695L1855,695L1855,690L1854,690L1853,679L1850,679L1850,678L1848,678L1848,677L1846,677L1846,676L1843,676L1843,675L1841,675L1841,674L1839,674L1839,673L1836,673L1836,672L1834,672L1834,671L1832,671L1832,670L1829,670L1829,669L1827,669L1827,668L1824,668L1824,667L1822,667L1822,666L1820,666L1820,665L1817,665L1817,664L1815,664L1815,663L1813,663L1813,662L1810,662L1810,661L1808,661L1808,660L1806,660L1806,659L1800,659L1800,658L1793,658L1793,657L1787,657L1787,656L1769,654L1768,651L1766,650L1766,648L1765,648L1765,646L1764,646L1764,644L1763,644L1763,642L1762,642L1760,636L1758,635L1758,633L1757,633L1757,631L1756,631L1756,629L1755,629L1753,623L1751,622L1751,620L1750,620L1750,618L1749,618L1749,616L1748,616L1746,610L1744,610L1744,609L1742,609L1742,608L1739,608L1739,607L1737,607L1737,606L1735,606L1735,605L1733,605L1733,604L1731,604L1731,603L1729,603L1729,602L1727,602L1727,601L1725,601L1725,600L1723,600L1723,599L1721,599L1721,598L1719,598L1719,597L1717,597L1717,596L1715,596L1715,595L1709,593L1702,585L1700,585L1700,584L1699,584L1694,578L1692,578L1686,571L1649,571L1644,565L1642,565L1638,560L1636,560L1636,559L1635,559L1631,554L1629,554L1626,550L1596,550L1596,551L1539,552L1539,553L1508,553L1506,550L1504,550L1502,547L1500,547L1498,544L1496,544L1494,541L1492,541L1490,538L1488,538L1486,535L1484,535L1481,531L1479,531L1477,528L1475,528L1473,525L1471,525L1471,524L1468,522L1468,520L1467,520L1467,518L1466,518L1466,516L1465,516L1465,514L1464,514L1464,512L1463,512L1463,510L1462,510L1462,508L1461,508L1461,506L1460,506L1460,504L1459,504L1459,502L1458,502L1458,500L1457,500L1457,498L1456,498L1456,496L1455,496L1455,493L1458,492L1459,490L1461,490L1462,488L1464,488L1465,486L1469,485L1470,483L1467,482L1467,481L1465,481L1465,480L1463,480L1463,479L1461,479L1461,478L1458,478L1458,477L1456,477L1456,476L1450,474L1450,473L1445,469L1445,467L1440,463L1440,461L1434,456L1434,454L1429,450L1429,448L1424,444L1424,441L1433,440L1433,439L1437,439L1437,438L1442,438L1442,437L1446,437L1446,436L1451,436L1451,435L1455,435L1455,434L1460,434L1460,433L1464,433L1464,432L1473,431L1473,430L1475,430L1475,429L1473,429L1473,428L1470,428L1470,427L1468,427L1468,426L1465,426L1465,425L1463,425L1463,424L1460,424L1460,423L1458,423L1458,422L1455,422L1455,421L1453,421L1453,420L1450,420L1450,419L1448,419L1448,418L1445,418L1445,417L1443,417L1443,416L1441,416L1441,415L1438,415L1438,414L1436,414L1436,413L1433,413L1433,412L1429,412L1429,413L1427,413L1427,414L1425,414L1425,415L1423,415L1423,416L1421,416L1421,417L1419,417L1419,418L1417,418L1417,419L1415,419L1415,420L1413,420L1413,421L1411,421L1411,422L1406,423L1406,424L1392,437L1392,439L1393,439L1394,443L1396,444L1397,448L1399,449L1399,451L1401,452L1402,456L1404,457L1405,461L1407,462L1408,466L1410,467L1411,471L1412,471L1413,474L1415,475L1415,477L1416,477L1416,479L1418,480L1419,484L1421,485L1421,487L1422,487L1422,492L1421,492L1421,494L1420,494L1420,496L1419,496L1419,499L1418,499L1418,501L1417,501L1417,504L1416,504L1416,506L1415,506L1415,508L1414,508L1414,511L1413,511L1412,515L1410,515L1401,505L1397,505L1397,506L1394,506L1394,507L1391,507L1391,508L1388,508L1388,509L1385,509L1385,510L1382,510L1382,511L1379,511L1379,512L1375,512L1375,511L1370,507L1370,505L1363,499L1363,497L1357,492L1357,490L1350,484L1349,478L1348,478L1348,474L1347,474L1346,465L1345,465L1345,461L1344,461L1344,456L1341,455L1329,442L1327,442L1327,441L1313,428L1313,426L1311,425L1311,423L1309,422L1309,420L1307,419L1307,417L1306,417L1305,415L1302,416L1301,418L1297,419L1296,421L1292,422L1292,423L1289,424L1288,426L1284,427L1284,428L1281,429L1280,431L1274,432L1274,431L1272,431L1272,430L1270,430L1270,429L1264,427L1263,425L1261,425L1261,424L1259,424L1259,423L1257,423L1257,422L1251,420L1251,419L1250,419L1246,414L1244,414L1243,411L1241,411L1206,375L1171,375L1171,374L1163,373L1163,372L1160,372L1160,371L1157,371L1157,370L1148,368L1148,366L1149,366L1150,364L1152,364L1155,360L1157,360L1159,357L1161,357L1164,353L1166,353L1166,352L1169,350L1169,333L1168,333L1168,316L1167,316L1167,300L1166,300L1166,283L1162,282L1161,280L1155,278L1154,276L1150,275L1149,273L1145,272L1144,270L1140,269L1139,267L1133,265L1132,263L1130,263L1130,262L1128,262L1127,260L1125,260L1125,259L1122,258L1123,250L1124,250L1124,247L1125,247L1125,244L1126,244L1126,241L1127,241L1127,238L1128,238L1128,235L1129,235L1129,231L1130,231L1130,227L1131,227L1131,223L1132,223L1132,219L1133,219L1135,207L1136,207L1136,204L1137,204L1138,196L1139,196L1139,195L1142,195L1142,194L1146,194L1146,193L1152,192L1152,191L1156,191L1156,190L1159,190L1159,189L1163,189L1163,188L1174,188L1174,187L1185,187L1185,186L1195,186L1195,185L1227,183L1226,178L1225,178L1224,173L1223,173L1223,170L1222,170L1222,168L1221,168L1222,162L1233,152L1233,150L1234,150L1234,149L1245,139L1245,137L1255,128L1254,122L1253,122L1253,120L1252,120L1252,117L1251,117L1251,115L1250,115L1250,112L1249,112L1249,110L1248,110L1248,107L1247,107L1247,105L1246,105L1246,102L1245,102L1245,100L1244,100L1244,97L1243,97L1243,95L1242,95L1242,92L1241,92L1241,90L1240,90L1240,87L1239,87L1239,85L1238,85L1238,82L1237,82L1237,80L1236,80L1236,77L1235,77L1234,72L1233,72L1233,70L1232,70L1232,67L1231,67L1231,65L1230,65L1230,62L1229,62L1229,59L1228,59L1226,50L1225,50L1225,48L1224,48L1224,45L1223,45L1223,42L1222,42L1222,39L1221,39L1221,34L1224,32L1224,30L1225,30L1225,29L1227,28L1227,26L1230,24Z\"/>\n<path fill=\"#917c87\" fill-rule=\"evenodd\" d=\"M218,21L225,21L225,22L245,24L245,25L251,25L251,26L258,26L258,27L264,27L264,28L266,28L266,29L269,30L271,33L273,33L273,34L276,35L278,38L280,38L282,41L284,41L284,42L287,43L289,46L291,46L292,48L294,48L294,49L308,62L308,64L320,75L320,77L337,93L337,95L355,112L356,115L360,116L361,118L365,119L366,121L370,122L371,124L375,125L375,126L378,127L379,129L381,129L381,130L383,130L384,132L386,132L386,133L389,134L389,136L346,138L346,139L277,139L277,138L276,138L271,144L269,144L264,150L262,150L257,156L255,156L250,162L248,162L242,169L240,169L240,170L234,175L234,207L235,207L237,210L239,210L239,212L241,212L269,241L281,241L281,242L292,242L292,243L304,243L304,244L316,244L316,245L327,245L327,246L339,246L339,247L342,247L342,248L344,248L344,249L347,249L347,250L349,250L349,251L351,251L351,252L354,252L354,253L356,253L356,254L359,254L359,255L364,256L364,257L366,257L366,258L369,259L369,261L370,261L370,263L371,263L371,265L372,265L372,267L373,267L373,269L374,269L374,271L375,271L375,273L376,273L376,275L377,275L377,277L378,277L378,280L379,280L379,282L380,282L380,284L381,284L381,286L382,286L382,288L383,288L383,290L384,290L384,292L385,292L385,294L386,294L386,296L387,296L389,302L393,302L393,301L398,301L398,300L410,298L410,294L409,294L409,290L408,290L408,286L407,286L407,282L406,282L406,278L405,278L405,274L404,274L404,270L403,270L403,266L402,266L402,261L403,261L404,259L406,259L407,257L409,257L411,254L413,254L414,252L416,252L418,249L420,249L421,247L423,247L425,244L427,244L428,242L430,242L432,239L434,239L434,238L436,237L436,236L434,236L420,221L418,221L418,220L409,212L410,197L411,197L411,188L412,188L412,179L413,179L413,169L414,169L414,160L415,160L415,151L420,151L420,152L424,152L424,153L431,154L431,155L434,155L434,156L442,157L442,158L445,158L445,159L453,160L453,161L460,162L460,163L463,163L463,164L467,164L467,165L471,165L471,166L474,166L474,167L478,167L478,168L482,168L482,169L489,170L489,171L492,171L492,172L496,172L496,173L503,174L503,175L504,175L504,181L505,181L505,187L506,187L506,193L507,193L507,199L508,199L509,210L512,210L512,209L515,209L515,208L518,208L518,207L521,207L521,206L524,206L524,205L527,205L527,204L530,204L530,203L533,203L533,202L536,202L536,201L539,201L539,200L542,200L542,199L545,199L545,198L549,198L549,197L552,197L552,196L556,196L593,234L595,234L595,235L596,235L597,237L599,237L602,241L604,241L606,244L608,244L610,247L612,247L615,251L617,251L619,254L621,254L623,257L625,257L628,261L630,261L632,264L634,264L638,269L640,269L643,273L645,273L649,278L651,278L651,279L654,281L654,297L653,297L653,298L648,299L648,300L645,300L645,301L640,302L640,303L638,303L638,304L632,305L632,306L630,306L630,307L624,308L624,309L619,310L619,311L617,311L617,312L611,313L610,315L606,316L605,318L601,319L601,320L598,321L597,323L593,324L592,326L588,327L587,329L583,330L582,332L580,332L580,333L578,333L577,335L574,336L575,372L589,372L589,371L603,371L603,370L617,370L617,371L615,371L615,372L613,372L613,373L610,373L610,374L608,374L608,375L605,375L605,376L603,376L603,377L600,377L600,378L598,378L598,379L596,379L596,380L593,380L593,381L591,381L591,382L588,382L588,383L586,383L586,384L584,384L584,385L581,385L581,386L579,386L579,387L576,387L576,388L574,388L574,389L572,389L572,390L569,390L569,391L567,391L567,392L564,392L564,393L562,393L562,394L560,394L560,395L557,395L557,396L555,396L555,397L552,397L552,398L549,398L549,399L546,399L546,400L543,400L543,401L539,401L539,402L536,402L536,403L533,403L533,404L529,404L529,405L526,405L526,406L523,406L523,407L520,407L520,408L516,408L516,409L513,409L513,410L504,412L504,419L505,419L505,425L506,425L506,433L499,434L499,435L495,435L495,436L488,437L488,438L484,438L484,439L477,440L477,441L473,441L473,442L470,442L470,443L462,444L460,450L458,451L458,453L457,453L455,459L453,460L451,466L449,467L449,469L448,469L446,475L444,476L442,482L440,483L440,485L439,485L439,487L438,487L438,489L437,489L437,491L436,491L436,494L438,495L438,497L439,497L439,499L440,499L442,505L444,506L444,508L445,508L445,510L446,510L446,512L447,512L447,515L446,515L445,517L443,517L440,521L438,521L436,524L434,524L431,528L429,528L427,531L425,531L423,534L421,534L418,538L416,538L416,539L415,539L414,541L412,541L409,545L407,545L405,548L403,548L401,551L399,551L396,555L394,555L392,558L390,558L387,562L385,562L385,563L382,565L382,570L383,570L385,585L386,585L386,589L387,589L387,594L388,594L388,599L389,599L389,604L390,604L390,609L391,609L391,614L392,614L392,619L393,619L393,624L394,624L394,629L395,629L395,635L390,636L390,637L388,637L388,638L385,638L385,639L383,639L383,640L379,640L379,638L378,638L378,636L377,636L377,634L376,634L376,632L375,632L375,630L374,630L374,628L373,628L373,626L372,626L372,624L371,624L371,621L370,621L370,619L369,619L369,617L368,617L368,615L367,615L367,613L366,613L366,611L365,611L365,609L364,609L364,607L363,607L363,605L362,605L362,603L361,603L361,600L360,600L360,598L359,598L359,596L358,596L358,594L357,594L357,592L356,592L356,590L355,590L355,588L354,588L354,586L353,586L353,584L352,584L351,579L350,579L350,580L287,580L287,581L272,582L272,583L265,583L265,584L257,584L257,585L249,585L249,586L234,587L234,588L227,588L227,589L219,589L219,593L218,593L217,600L216,600L216,603L215,603L215,607L214,607L214,610L213,610L213,614L212,614L212,617L211,617L211,620L210,620L210,624L209,624L209,627L208,627L208,631L207,631L207,634L204,634L204,633L200,630L200,628L185,614L185,612L169,597L169,595L168,595L156,582L153,582L153,583L151,583L151,584L149,584L149,585L147,585L147,586L145,586L145,587L143,587L143,588L140,588L140,587L136,586L135,584L131,583L130,581L126,580L126,579L123,578L122,576L118,575L117,573L113,572L112,570L108,569L107,567L103,566L102,564L98,563L97,561L93,560L92,558L79,558L79,557L55,555L55,554L40,553L40,552L33,552L33,551L25,551L25,552L0,552L0,85L9,84L9,83L14,83L14,82L20,82L20,81L26,81L26,77L30,77L30,76L34,76L34,75L38,75L38,74L42,74L42,73L46,73L46,72L50,72L50,71L54,71L54,70L58,70L58,69L62,69L62,68L66,68L66,67L71,67L71,66L75,66L75,65L79,65L79,64L135,65L135,66L138,66L138,67L147,69L147,70L149,70L149,71L152,71L152,72L161,74L161,75L163,75L163,76L166,76L166,77L169,77L169,78L172,78L172,79L175,79L175,80L180,81L180,80L181,80L181,77L182,77L182,75L183,75L183,73L184,73L184,71L185,71L185,69L186,69L186,67L187,67L187,65L188,65L188,63L189,63L189,61L190,61L190,59L191,59L191,57L192,57L192,38L195,38L195,37L198,37L198,36L202,36L202,35L205,35L205,34L210,34L210,35L219,43L219,45L228,53L228,50L227,50L227,47L226,47L224,38L223,38L223,36L222,36L222,33L221,33L221,30L220,30Z\"/>\n<path fill=\"#eac4a2\" fill-rule=\"evenodd\" d=\"M964,587L975,587L975,588L978,588L978,589L981,589L981,590L984,590L984,591L987,591L987,592L990,592L990,593L993,593L993,594L996,594L996,595L999,595L999,596L1002,596L1002,597L1005,597L1005,598L1008,598L1008,599L1011,599L1011,600L1014,600L1014,601L1017,601L1017,602L1026,604L1026,605L1027,605L1027,609L1028,609L1028,613L1029,613L1029,617L1030,617L1030,622L1031,622L1031,626L1032,626L1034,638L1035,638L1036,647L1044,654L1044,656L1045,656L1045,657L1049,660L1049,662L1056,668L1056,670L1063,676L1063,678L1070,684L1070,686L1077,692L1077,694L1084,700L1084,702L1085,702L1091,709L1093,709L1094,711L1096,711L1096,712L1098,712L1098,713L1100,713L1100,714L1102,714L1102,715L1104,715L1104,716L1106,716L1106,717L1108,717L1108,718L1110,718L1110,719L1112,719L1112,720L1114,720L1114,721L1120,723L1121,725L1123,725L1123,726L1125,726L1125,727L1127,727L1127,728L1129,728L1129,729L1131,729L1131,730L1133,730L1133,731L1135,731L1135,732L1137,732L1137,733L1139,733L1139,734L1141,734L1141,735L1147,737L1148,739L1150,739L1150,740L1152,740L1152,741L1154,741L1154,742L1156,742L1156,743L1158,743L1158,744L1160,744L1160,745L1162,745L1162,746L1164,746L1164,747L1166,747L1166,748L1168,748L1168,749L1171,749L1171,746L1172,746L1172,743L1173,743L1173,740L1174,740L1174,737L1175,737L1175,734L1176,734L1176,731L1177,731L1177,728L1178,728L1179,721L1180,721L1180,722L1283,724L1283,725L1285,726L1285,728L1286,728L1286,730L1287,730L1287,732L1288,732L1288,734L1289,734L1289,736L1290,736L1292,742L1294,743L1294,745L1297,747L1297,749L1299,750L1299,752L1301,753L1301,755L1303,756L1303,758L1305,759L1305,761L1308,763L1308,765L1310,766L1310,768L1312,769L1312,771L1314,772L1314,774L1316,775L1316,777L1319,779L1319,781L1321,782L1321,784L1323,785L1323,787L1325,788L1325,790L1328,792L1328,794L1331,796L1331,798L1334,800L1334,802L1337,804L1337,806L1340,808L1340,810L1342,811L1342,813L1345,815L1345,817L1348,819L1348,821L1349,821L1351,824L1384,823L1384,822L1400,822L1400,821L1417,821L1415,830L1414,830L1414,832L1413,832L1411,841L1410,841L1410,843L1409,843L1409,846L1408,846L1407,852L1406,852L1406,854L1405,854L1405,857L1404,857L1404,860L1403,860L1402,866L1401,866L1401,868L1400,868L1400,871L1399,871L1399,874L1398,874L1397,879L1396,879L1396,880L1394,881L1394,883L1363,913L1363,915L1335,942L1335,944L1333,945L1332,949L1330,950L1330,952L1328,953L1328,955L1326,956L1326,958L1324,959L1324,961L1323,961L1322,964L1320,965L1319,969L1317,970L1317,972L1315,973L1315,975L1314,975L1313,978L1312,978L1312,985L1313,985L1313,990L1314,990L1315,1002L1316,1002L1316,1007L1317,1007L1318,1019L1319,1019L1320,1030L1321,1030L1321,1036L1322,1036L1323,1047L1324,1047L1324,1053L1325,1053L1325,1058L1326,1058L1326,1065L1325,1065L1322,1069L1320,1069L1317,1073L1315,1073L1311,1078L1309,1078L1305,1083L1303,1083L1300,1087L1298,1087L1294,1092L1292,1092L1288,1097L1286,1097L1282,1102L1280,1102L1277,1106L1275,1106L1275,1107L1270,1111L1271,1119L1272,1119L1272,1122L1273,1122L1273,1126L1274,1126L1274,1130L1275,1130L1275,1134L1276,1134L1276,1138L1277,1138L1277,1142L1278,1142L1278,1146L1279,1146L1279,1151L1278,1151L1276,1154L1274,1154L1271,1158L1269,1158L1266,1162L1264,1162L1262,1165L1260,1165L1257,1169L1255,1169L1252,1173L1250,1173L1250,1175L1247,1177L1247,1179L1244,1181L1244,1183L1241,1185L1241,1187L1238,1189L1238,1191L1235,1193L1235,1195L1231,1198L1231,1200L1228,1202L1228,1204L1225,1206L1225,1208L1222,1210L1222,1212L1219,1214L1219,1216L1216,1218L1216,1220L1213,1222L1213,1224L1212,1224L1212,1225L1210,1226L1210,1228L1206,1231L1206,1233L1203,1235L1203,1237L1200,1239L1200,1241L1199,1241L1198,1243L1192,1243L1192,1242L1188,1242L1188,1241L1183,1241L1183,1240L1179,1240L1179,1239L1174,1239L1174,1238L1169,1238L1169,1237L1165,1237L1165,1236L1160,1236L1160,1235L1156,1235L1156,1234L1151,1234L1151,1233L1147,1233L1147,1232L1138,1231L1137,1229L1135,1229L1128,1221L1126,1221L1118,1212L1116,1212L1109,1204L1107,1204L1099,1195L1097,1195L1097,1194L1089,1187L1088,1178L1087,1178L1087,1173L1086,1173L1085,1164L1084,1164L1084,1159L1083,1159L1082,1150L1081,1150L1081,1145L1080,1145L1080,1141L1079,1141L1079,1136L1077,1135L1077,1133L1075,1132L1075,1130L1073,1129L1073,1127L1071,1126L1071,1124L1069,1123L1069,1121L1067,1120L1067,1118L1065,1117L1065,1115L1063,1114L1063,1112L1061,1111L1061,1109L1059,1108L1059,1106L1057,1105L1057,1103L1055,1102L1055,1100L1054,1100L1053,1097L1051,1096L1051,1087L1052,1087L1052,1080L1053,1080L1053,1073L1054,1073L1054,1066L1055,1066L1055,1059L1056,1059L1056,1052L1057,1052L1057,1045L1058,1045L1058,1038L1059,1038L1059,1031L1060,1031L1060,1024L1061,1024L1061,1017L1062,1017L1062,1010L1063,1010L1063,1001L1062,1001L1061,995L1060,995L1060,993L1059,993L1059,990L1058,990L1058,988L1057,988L1056,982L1055,982L1055,980L1054,980L1054,977L1053,977L1052,972L1051,972L1051,969L1050,969L1050,963L1049,963L1049,957L1048,957L1048,951L1047,951L1047,945L1046,945L1046,939L1045,939L1045,933L1044,933L1044,927L1043,927L1043,920L1042,920L1042,914L1041,914L1039,896L1036,896L1036,895L1034,895L1034,894L1031,894L1031,893L1029,893L1029,892L1026,892L1026,891L1024,891L1024,890L1022,890L1022,889L1019,889L1019,888L1017,888L1017,887L1014,887L1014,886L1012,886L1012,885L1009,885L1009,884L1007,884L1007,883L1004,883L1004,882L1002,882L1002,881L1000,881L1000,880L997,880L997,879L995,879L995,878L992,878L992,877L987,876L987,875L985,875L985,874L983,874L983,873L980,873L980,872L974,872L974,873L959,875L959,876L955,876L955,877L940,879L940,880L931,881L931,882L926,882L926,883L921,883L921,884L912,885L912,886L904,886L904,885L902,885L902,884L900,884L900,883L897,883L897,882L895,882L895,881L893,881L893,880L890,880L890,879L888,879L888,878L886,878L886,877L883,877L883,876L881,876L881,875L879,875L879,874L876,874L876,873L874,873L874,872L872,872L872,871L869,871L869,870L867,870L867,869L865,869L865,868L863,868L863,867L860,867L860,866L858,866L858,865L856,865L856,864L853,864L853,863L851,863L851,862L849,862L849,861L846,861L846,860L844,860L844,859L842,859L842,858L839,858L839,857L835,856L835,855L816,837L816,835L796,816L796,814L794,813L794,805L795,805L797,785L798,785L798,779L799,779L799,765L798,765L796,745L795,745L795,739L794,739L793,723L794,723L794,721L795,721L797,715L799,714L799,712L800,712L800,710L801,710L803,704L805,703L805,701L806,701L806,699L807,699L809,693L811,692L811,690L812,690L812,688L813,688L815,682L816,682L817,679L818,679L818,672L819,672L819,666L820,666L820,659L821,659L821,653L822,653L824,633L827,632L827,631L829,631L829,630L831,630L831,629L833,629L833,628L835,628L835,627L837,627L837,626L839,626L839,625L841,625L841,624L843,624L843,623L845,623L845,622L847,622L847,621L849,621L849,620L851,620L851,619L853,619L853,618L855,618L855,617L857,617L857,616L859,616L859,615L861,615L861,614L863,614L863,613L865,613L865,612L867,612L867,611L869,611L869,610L871,610L871,609L873,609L873,608L875,608L875,607L877,607L877,606L879,606L879,605L881,605L881,604L883,604L883,603L885,603L885,602L887,602L887,601L889,601L889,600L891,600L891,599L893,599L893,598L895,598L895,597L897,597L897,596L899,596L899,595L907,595L907,594L915,594L915,593L923,593L923,592L931,592L931,591L939,591L939,590L947,590L947,589L956,589L956,588L964,588ZM1404,1041L1407,1041L1407,1042L1410,1044L1410,1046L1413,1048L1413,1050L1417,1053L1417,1059L1416,1059L1415,1066L1414,1066L1414,1069L1413,1069L1413,1072L1412,1072L1412,1076L1411,1076L1410,1083L1409,1083L1409,1086L1408,1086L1408,1090L1407,1090L1407,1093L1406,1093L1406,1096L1405,1096L1405,1100L1404,1100L1404,1103L1403,1103L1402,1107L1400,1108L1400,1110L1398,1111L1397,1115L1395,1116L1395,1118L1393,1119L1392,1123L1390,1124L1390,1126L1388,1127L1387,1131L1385,1132L1385,1134L1383,1135L1382,1139L1380,1140L1379,1144L1378,1144L1377,1147L1375,1148L1374,1152L1372,1153L1371,1156L1369,1156L1369,1155L1351,1138L1351,1136L1350,1136L1351,1128L1352,1128L1352,1125L1353,1125L1353,1122L1354,1122L1354,1119L1355,1119L1355,1116L1356,1116L1356,1113L1357,1113L1357,1110L1358,1110L1358,1107L1359,1107L1359,1098L1358,1098L1358,1093L1357,1093L1357,1087L1356,1087L1356,1081L1355,1081L1355,1074L1358,1073L1359,1071L1361,1071L1362,1069L1364,1069L1365,1067L1367,1067L1368,1065L1370,1065L1371,1063L1373,1063L1374,1061L1376,1061L1377,1059L1379,1059L1380,1057L1382,1057L1383,1055L1385,1055L1386,1053L1388,1053L1389,1051L1391,1051L1392,1049L1394,1049L1395,1047L1397,1047L1398,1045L1400,1045L1401,1043L1403,1043Z\"/>\n<path fill=\"#e67d31\" fill-rule=\"evenodd\" d=\"M2258,458L2262,459L2269,467L2271,467L2271,468L2278,474L2278,481L2277,481L2277,488L2276,488L2275,500L2274,500L2272,509L2271,509L2271,511L2270,511L2270,514L2269,514L2267,523L2266,523L2266,525L2265,525L2265,528L2264,528L2262,537L2261,537L2261,539L2260,539L2258,548L2257,548L2257,550L2256,550L2256,553L2255,553L2255,556L2254,556L2254,559L2253,559L2252,564L2249,565L2249,566L2247,566L2247,567L2245,567L2245,568L2242,568L2242,569L2240,569L2240,570L2238,570L2238,571L2236,571L2236,572L2233,572L2233,573L2231,573L2231,574L2229,574L2229,575L2226,575L2226,576L2224,576L2224,577L2222,577L2222,578L2220,578L2220,579L2217,579L2217,580L2215,580L2215,581L2213,581L2213,582L2211,582L2211,583L2208,583L2207,585L2205,585L2204,587L2202,587L2201,589L2199,589L2199,590L2196,591L2195,593L2193,593L2193,594L2191,594L2190,596L2188,596L2183,602L2181,602L2177,607L2175,607L2175,608L2174,608L2170,613L2168,613L2163,619L2160,619L2160,617L2159,617L2159,615L2158,615L2158,612L2157,612L2157,610L2156,610L2156,608L2155,608L2155,606L2154,606L2154,603L2153,603L2153,601L2152,601L2152,599L2151,599L2151,596L2150,596L2150,594L2149,594L2149,592L2148,592L2148,588L2150,588L2150,587L2152,587L2152,586L2154,586L2154,585L2156,585L2156,584L2158,584L2158,583L2160,583L2160,582L2162,582L2162,581L2164,581L2164,580L2166,580L2166,579L2168,579L2168,578L2170,578L2170,577L2172,577L2172,576L2174,576L2174,575L2177,575L2177,574L2180,574L2180,573L2184,573L2184,572L2187,572L2187,571L2190,571L2190,570L2194,570L2194,569L2197,569L2197,568L2200,568L2200,567L2204,567L2204,566L2231,540L2231,537L2232,537L2232,534L2233,534L2233,531L2234,531L2234,528L2235,528L2235,525L2236,525L2236,522L2237,522L2237,519L2238,519L2238,516L2239,516L2241,507L2242,507L2242,505L2243,505L2243,502L2244,502L2244,499L2245,499L2245,496L2246,496L2246,493L2247,493L2247,490L2248,490L2248,487L2249,487L2249,484L2250,484L2250,481L2251,481L2251,478L2252,478L2252,475L2253,475L2255,466L2256,466L2256,464L2257,464ZM2152,489L2153,489L2153,490L2152,490L2151,494L2149,495L2148,499L2146,500L2145,504L2143,505L2143,507L2141,508L2140,512L2138,513L2137,517L2135,518L2135,520L2134,520L2134,522L2133,522L2133,526L2134,526L2134,528L2135,528L2135,531L2136,531L2136,534L2137,534L2137,537L2138,537L2138,540L2139,540L2141,549L2142,549L2142,551L2143,551L2143,554L2144,554L2144,557L2145,557L2145,560L2146,560L2146,563L2147,563L2147,566L2148,566L2148,570L2143,571L2143,572L2138,573L2138,574L2135,574L2135,575L2130,576L2130,577L2128,577L2128,578L2121,579L2121,576L2120,576L2120,573L2119,573L2119,570L2118,570L2118,567L2117,567L2117,564L2116,564L2116,561L2115,561L2115,558L2114,558L2112,549L2111,549L2111,547L2110,547L2110,545L2109,545L2109,543L2108,543L2108,541L2107,541L2107,539L2106,539L2106,537L2105,537L2105,534L2104,534L2104,532L2103,532L2103,530L2102,530L2102,528L2101,528L2101,526L2100,526L2100,524L2099,524L2099,522L2098,522L2097,519L2101,519L2101,518L2105,517L2106,515L2108,515L2108,514L2112,513L2113,511L2115,511L2115,510L2121,508L2122,506L2128,504L2129,502L2135,500L2136,498L2142,496L2143,494L2145,494L2145,493L2151,491ZM1596,550L1626,550L1626,551L1627,551L1629,554L1631,554L1636,560L1638,560L1642,565L1644,565L1649,571L1686,571L1692,578L1694,578L1700,585L1702,585L1709,593L1711,593L1711,594L1713,594L1713,595L1715,595L1715,596L1717,596L1717,597L1719,597L1719,598L1721,598L1721,599L1723,599L1723,600L1725,600L1725,601L1727,601L1727,602L1729,602L1729,603L1731,603L1731,604L1733,604L1733,605L1735,605L1735,606L1737,606L1737,607L1739,607L1739,608L1742,608L1742,609L1746,610L1746,612L1747,612L1747,614L1748,614L1748,616L1749,616L1751,622L1753,623L1753,625L1754,625L1754,627L1755,627L1755,629L1756,629L1758,635L1760,636L1760,638L1761,638L1761,640L1762,640L1762,642L1763,642L1763,644L1764,644L1764,646L1765,646L1765,648L1766,648L1766,650L1768,651L1769,654L1775,654L1775,655L1781,655L1781,656L1787,656L1787,657L1793,657L1793,658L1806,659L1806,660L1808,660L1808,661L1810,661L1810,662L1813,662L1813,663L1815,663L1815,664L1817,664L1817,665L1820,665L1820,666L1822,666L1822,667L1824,667L1824,668L1827,668L1827,669L1832,670L1832,671L1834,671L1834,672L1836,672L1836,673L1839,673L1839,674L1841,674L1841,675L1843,675L1843,676L1846,676L1846,677L1848,677L1848,678L1850,678L1850,679L1853,679L1854,690L1855,690L1855,704L1857,704L1858,706L1860,706L1860,707L1862,707L1862,708L1864,708L1864,709L1866,709L1866,710L1868,710L1868,711L1871,711L1871,712L1873,712L1873,713L1875,713L1875,714L1877,714L1877,715L1879,715L1879,716L1881,716L1881,717L1883,717L1883,718L1886,718L1886,719L1898,719L1898,718L1908,718L1908,717L1918,717L1918,716L1929,716L1929,717L1931,717L1932,719L1934,719L1935,721L1939,722L1940,724L1946,726L1946,728L1945,728L1924,750L1922,750L1921,752L1924,753L1925,755L1927,755L1928,757L1932,758L1933,760L1935,760L1935,761L1938,762L1939,764L1943,765L1943,766L1946,767L1947,769L1951,770L1951,771L1954,772L1955,774L1959,775L1960,777L1962,777L1962,778L1965,779L1966,781L1970,782L1970,783L1973,784L1974,786L1976,786L1976,787L1978,787L1979,789L1981,789L1981,790L1982,790L1982,793L1973,801L1973,803L1964,811L1964,813L1955,821L1955,823L1954,823L1947,831L1909,831L1904,825L1902,825L1898,820L1896,820L1892,815L1890,815L1890,814L1889,814L1885,809L1883,809L1880,805L1878,805L1866,818L1864,818L1864,821L1865,821L1865,823L1866,823L1866,825L1867,825L1867,828L1868,828L1868,830L1869,830L1869,832L1870,832L1870,834L1871,834L1871,837L1872,837L1872,839L1873,839L1873,841L1874,841L1874,844L1875,844L1875,846L1876,846L1876,848L1877,848L1877,850L1878,850L1878,853L1879,853L1879,855L1880,855L1880,857L1881,857L1881,859L1882,859L1882,862L1891,870L1891,872L1900,880L1900,882L1909,890L1909,892L1918,900L1918,902L1928,911L1928,914L1902,915L1905,919L1907,919L1913,926L1915,926L1922,934L1924,934L1930,941L1932,941L1932,942L1938,947L1938,950L1937,950L1937,952L1936,952L1936,954L1935,954L1935,956L1934,956L1934,958L1933,958L1933,960L1932,960L1930,966L1928,967L1927,971L1920,971L1920,970L1915,970L1915,969L1904,968L1904,967L1898,962L1898,960L1892,955L1892,953L1887,949L1887,947L1881,942L1881,940L1875,935L1875,933L1869,928L1869,926L1863,921L1863,919L1855,912L1855,910L1847,903L1847,901L1839,894L1839,892L1830,884L1830,882L1828,881L1828,879L1827,879L1826,876L1824,875L1824,873L1827,873L1827,874L1830,874L1830,875L1833,875L1833,876L1836,876L1836,877L1839,877L1839,878L1842,878L1842,879L1845,879L1845,880L1848,880L1848,881L1851,881L1851,882L1854,882L1854,883L1863,885L1863,886L1865,886L1865,887L1871,888L1871,889L1873,889L1880,897L1882,897L1888,904L1890,904L1894,909L1895,909L1895,907L1893,906L1893,904L1892,904L1891,901L1889,900L1888,896L1886,895L1886,893L1884,892L1883,888L1881,887L1881,885L1880,885L1879,882L1877,881L1876,877L1874,876L1874,874L1873,874L1872,871L1870,870L1869,866L1865,863L1865,861L1861,858L1861,856L1857,853L1857,851L1852,847L1852,845L1848,842L1848,840L1847,840L1847,839L1844,837L1844,835L1840,832L1840,830L1838,829L1838,827L1835,825L1835,823L1833,822L1833,820L1831,819L1831,817L1829,816L1829,814L1826,812L1826,810L1824,809L1824,807L1823,807L1822,804L1820,803L1820,757L1817,756L1817,755L1815,755L1815,754L1813,754L1813,753L1811,753L1810,751L1808,751L1808,750L1806,750L1806,749L1804,749L1804,748L1798,746L1797,744L1795,744L1795,743L1793,743L1793,742L1787,740L1786,738L1784,738L1784,737L1782,737L1782,736L1780,736L1780,735L1774,733L1774,732L1770,732L1770,733L1768,733L1768,734L1765,734L1765,735L1762,735L1762,736L1759,736L1759,737L1756,737L1756,738L1753,738L1753,739L1750,739L1750,740L1741,742L1741,743L1740,743L1739,745L1737,745L1735,748L1733,748L1732,750L1730,750L1730,751L1729,751L1728,753L1726,753L1724,756L1722,756L1721,758L1719,758L1717,761L1715,761L1713,764L1711,764L1710,766L1708,766L1706,769L1704,769L1702,772L1700,772L1699,774L1697,774L1695,777L1693,777L1691,780L1689,780L1689,781L1687,782L1687,786L1688,786L1688,790L1689,790L1689,795L1690,795L1690,799L1691,799L1691,803L1692,803L1692,810L1690,811L1690,813L1688,814L1688,816L1686,817L1686,819L1684,820L1684,822L1681,824L1681,826L1679,827L1679,829L1677,830L1677,832L1675,833L1675,835L1673,836L1673,838L1671,839L1671,841L1669,842L1669,844L1666,846L1665,849L1663,849L1663,847L1661,846L1661,844L1660,844L1660,842L1659,842L1659,840L1658,840L1656,834L1654,833L1654,831L1653,831L1653,829L1652,829L1652,827L1651,827L1651,825L1650,825L1648,819L1646,818L1646,816L1645,816L1645,814L1644,814L1644,812L1643,812L1641,806L1639,805L1639,803L1638,803L1638,801L1637,801L1637,799L1636,799L1636,797L1635,797L1635,795L1634,795L1634,793L1633,793L1633,789L1632,789L1632,785L1631,785L1631,780L1630,780L1630,776L1629,776L1629,772L1628,772L1628,767L1627,767L1627,763L1626,763L1626,759L1625,759L1625,754L1624,754L1624,750L1623,750L1623,746L1622,746L1622,741L1621,741L1621,737L1620,737L1620,733L1619,733L1619,729L1618,729L1618,724L1582,724L1581,719L1580,719L1580,716L1579,716L1578,711L1577,711L1577,708L1576,708L1576,706L1575,706L1574,700L1573,700L1573,698L1572,698L1571,692L1565,690L1564,688L1560,687L1559,685L1553,683L1552,681L1546,679L1545,677L1541,676L1540,674L1534,672L1533,670L1529,669L1528,667L1526,667L1526,666L1524,666L1524,665L1522,665L1522,664L1520,663L1520,649L1519,649L1518,622L1517,622L1517,609L1516,609L1515,581L1514,581L1514,568L1513,568L1513,553L1596,551ZM2066,684L2069,684L2069,685L2071,685L2071,686L2073,686L2073,687L2075,687L2075,688L2081,690L2081,693L2080,693L2079,697L2077,698L2075,704L2073,705L2073,707L2072,707L2070,713L2068,714L2066,720L2063,721L2062,718L2060,717L2060,715L2058,714L2058,712L2056,711L2056,706L2057,706L2057,704L2058,704L2058,702L2059,702L2059,699L2060,699L2060,697L2061,697L2061,695L2062,695L2062,693L2063,693L2063,690L2064,690ZM2060,752L2064,753L2064,754L2065,754L2072,762L2074,762L2083,772L2085,772L2094,782L2098,782L2098,783L2102,783L2102,784L2106,784L2106,785L2118,787L2118,802L2117,802L2117,842L2116,842L2116,849L2115,849L2114,861L2113,861L2110,865L2108,865L2105,869L2103,869L2100,873L2097,873L2097,872L2094,870L2094,868L2090,865L2090,863L2089,863L2089,862L2087,863L2087,861L2085,860L2085,858L2084,858L2084,856L2083,856L2083,854L2086,856L2086,853L2085,853L2085,848L2084,848L2084,843L2083,843L2082,832L2077,831L2077,830L2075,830L2075,829L2073,829L2073,828L2071,828L2071,827L2069,827L2069,826L2067,826L2067,825L2065,825L2065,824L2063,824L2063,823L2061,823L2061,822L2056,822L2056,823L2049,824L2049,825L2046,825L2046,826L2043,826L2043,827L2039,827L2039,822L2040,822L2040,816L2041,816L2041,811L2042,811L2042,806L2043,806L2043,801L2044,801L2044,795L2045,795L2046,785L2047,785L2047,782L2048,782L2048,780L2049,780L2049,778L2050,778L2050,775L2051,775L2051,773L2052,773L2052,771L2053,771L2053,768L2054,768L2054,766L2055,766L2055,763L2056,763L2056,761L2057,761L2057,759L2058,759L2058,756L2059,756ZM1688,837L1690,837L1690,838L1704,851L1704,853L1705,853L1705,859L1704,859L1704,863L1703,863L1703,867L1702,867L1700,879L1698,879L1698,878L1682,863L1682,858L1683,858L1683,854L1684,854L1684,851L1685,851L1685,847L1686,847L1686,844L1687,844ZM2021,860L2024,860L2025,862L2029,863L2030,865L2032,865L2033,867L2035,867L2036,869L2038,869L2039,871L2041,871L2042,873L2045,874L2045,876L2044,876L2043,878L2041,878L2040,880L2038,880L2036,883L2034,883L2034,884L2032,885L2032,887L2034,888L2034,890L2035,890L2035,892L2036,892L2036,894L2037,894L2039,900L2041,901L2041,903L2042,903L2042,905L2043,905L2043,907L2044,907L2044,909L2045,909L2045,911L2046,911L2045,917L2043,918L2042,922L2041,922L2040,925L2038,926L2038,928L2037,928L2037,930L2035,931L2035,933L2034,933L2034,935L2032,936L2032,938L2028,941L2028,943L2024,946L2024,948L2019,952L2019,954L2018,954L2016,957L2006,957L2006,956L1998,956L1998,955L1990,955L1990,954L1973,953L1972,950L1970,949L1970,947L1969,947L1969,945L1968,945L1966,939L1964,938L1964,936L1963,936L1963,934L1962,934L1960,928L1958,927L1958,925L1957,925L1957,923L1956,923L1956,921L1955,921L1955,919L1954,919L1954,916L1955,916L1956,914L1958,914L1959,912L1961,912L1961,911L1962,911L1963,909L1965,909L1966,907L1968,907L1970,904L1972,904L1973,902L1975,902L1977,899L1979,899L1980,897L1982,897L1984,894L1986,894L1987,892L1989,892L1991,889L1993,889L1994,887L1996,887L1996,886L1998,885L1998,883L1999,883ZM2107,911L2111,911L2111,912L2108,912L2108,913L2105,913L2105,914L2102,914L2102,915L2099,915L2099,916L2095,916L2095,917L2092,917L2092,918L2089,918L2089,919L2086,919L2086,920L2077,922L2077,923L2085,930L2085,932L2086,932L2086,941L2085,941L2085,949L2084,949L2084,956L2083,956L2083,964L2075,964L2075,963L2067,963L2067,962L2046,960L2046,956L2047,956L2047,954L2048,954L2048,952L2049,952L2049,949L2050,949L2050,947L2051,947L2051,945L2052,945L2052,942L2053,942L2053,940L2054,940L2054,938L2055,938L2055,935L2056,935L2056,933L2057,933L2057,931L2058,931L2058,928L2059,928L2059,926L2060,926L2061,923L2065,923L2065,922L2068,922L2068,921L2072,921L2072,920L2076,920L2076,919L2088,917L2088,916L2091,916L2091,915L2095,915L2095,914L2099,914L2099,913L2103,913L2103,912L2107,912ZM2156,934L2162,934L2162,935L2168,935L2168,936L2186,938L2196,950L2198,950L2198,949L2204,944L2204,942L2205,942L2209,937L2214,937L2214,938L2222,939L2222,940L2225,940L2225,941L2237,943L2237,944L2240,944L2240,945L2252,947L2252,948L2255,948L2255,949L2259,949L2259,950L2271,952L2271,953L2274,953L2274,955L2275,955L2277,958L2279,958L2279,959L2286,960L2286,961L2289,961L2289,962L2292,962L2292,963L2296,963L2296,1007L2279,1008L2279,1009L2276,1009L2276,1010L2275,1010L2274,1012L2272,1012L2272,1013L2262,1013L2262,1012L2244,1011L2244,1010L2236,1010L2236,1009L2227,1009L2228,982L2225,981L2225,980L2223,980L2222,978L2220,978L2220,977L2214,975L2213,973L2207,971L2206,969L2200,967L2199,965L2193,963L2192,961L2190,961L2190,960L2184,958L2183,956L2177,954L2177,953L2176,953L2175,951L2173,951L2165,942L2163,942ZM1926,984L1937,984L1937,985L1948,985L1948,986L1959,986L1959,987L1970,987L1970,988L1981,988L1981,989L1992,989L1992,990L2007,990L2007,991L2021,991L2021,992L2036,992L2036,993L2050,993L2050,994L2094,996L2094,997L2099,997L2099,998L2104,998L2104,999L2119,1001L2119,1002L2123,1002L2123,1003L2128,1003L2128,1005L2125,1005L2125,1006L2122,1006L2122,1007L2119,1007L2119,1008L2116,1008L2116,1009L2112,1009L2112,1010L2109,1010L2109,1011L2106,1011L2106,1012L2103,1012L2103,1013L2100,1013L2100,1014L2096,1014L2096,1015L2093,1015L2093,1016L2090,1016L2090,1017L2087,1017L2087,1018L2084,1018L2084,1019L2074,1019L2074,1018L2069,1018L2069,1017L2063,1017L2063,1016L2057,1016L2057,1015L2046,1014L2046,1013L2041,1013L2041,1012L2035,1012L2035,1011L2029,1011L2029,1010L2024,1010L2024,1009L2013,1008L2013,1007L2001,1005L2001,1004L1998,1004L1998,1003L1994,1003L1994,1002L1982,1000L1982,999L1979,999L1979,998L1967,996L1967,995L1964,995L1964,994L1960,994L1960,993L1948,991L1948,990L1945,990L1945,989L1941,989L1941,988L1929,986L1929,985L1926,985ZM2264,1024L2266,1024L2266,1026L2267,1026L2267,1029L2268,1029L2268,1032L2269,1032L2271,1041L2272,1041L2272,1043L2273,1043L2273,1046L2274,1046L2274,1049L2275,1049L2275,1052L2276,1052L2276,1057L2277,1057L2277,1056L2278,1056L2278,1057L2281,1057L2281,1058L2283,1058L2283,1059L2285,1059L2285,1060L2288,1060L2288,1061L2293,1062L2293,1063L2296,1064L2296,1271L2295,1271L2295,1272L2293,1272L2293,1273L2291,1273L2291,1274L2289,1274L2289,1275L2286,1275L2286,1276L2284,1276L2284,1277L2282,1277L2282,1278L2280,1278L2280,1279L2278,1279L2278,1280L2277,1280L2277,1276L2276,1276L2276,1283L2271,1283L2271,1282L2267,1282L2267,1281L2262,1281L2262,1280L2258,1280L2258,1279L2253,1279L2253,1278L2249,1278L2249,1277L2240,1276L2240,1275L2238,1274L2236,1268L2234,1267L2233,1263L2231,1262L2229,1256L2226,1256L2226,1255L2223,1255L2223,1254L2220,1254L2220,1253L2217,1253L2217,1252L2214,1252L2214,1251L2211,1251L2211,1250L2208,1250L2208,1249L2205,1249L2205,1248L2202,1248L2202,1247L2197,1246L2190,1238L2188,1238L2181,1230L2179,1230L2179,1229L2178,1229L2172,1222L2170,1222L2165,1216L2158,1216L2158,1217L2153,1217L2153,1218L2147,1218L2147,1219L2141,1219L2141,1220L2123,1222L2123,1223L2120,1224L2118,1227L2116,1227L2115,1229L2113,1229L2112,1231L2110,1231L2109,1233L2107,1233L2105,1236L2103,1236L2102,1238L2100,1238L2099,1240L2097,1240L2097,1241L2094,1242L2094,1243L2077,1243L2077,1244L2060,1244L2060,1245L2036,1245L2036,1244L2029,1244L2029,1243L2008,1241L2008,1235L2009,1235L2010,1226L2011,1226L2011,1222L2012,1222L2012,1218L2013,1218L2014,1207L2012,1206L2012,1204L2011,1204L2011,1202L2010,1202L2010,1200L2009,1200L2009,1198L2008,1198L2006,1192L2004,1191L2004,1189L2003,1189L2003,1187L2002,1187L2002,1185L2001,1185L2001,1183L2000,1183L1998,1177L1996,1176L1996,1174L1995,1174L1995,1172L1994,1172L1994,1170L1993,1170L1993,1168L1992,1168L1992,1166L1991,1166L1991,1158L1992,1158L1992,1152L1993,1152L1993,1146L1994,1146L1996,1128L1997,1128L1997,1126L1998,1126L2000,1120L2002,1119L2002,1117L2003,1117L2003,1115L2004,1115L2006,1109L2008,1108L2008,1106L2009,1106L2009,1104L2010,1104L2010,1102L2011,1102L2011,1100L2012,1100L2012,1098L2014,1097L2015,1094L2067,1093L2067,1092L2069,1092L2069,1091L2071,1091L2071,1090L2073,1090L2073,1089L2075,1089L2075,1088L2077,1088L2077,1087L2080,1087L2080,1086L2082,1086L2082,1085L2084,1085L2084,1084L2086,1084L2086,1083L2088,1083L2088,1082L2090,1082L2090,1081L2092,1081L2092,1080L2097,1079L2097,1077L2102,1073L2102,1071L2107,1067L2107,1065L2111,1062L2111,1060L2115,1057L2115,1055L2116,1055L2119,1051L2124,1052L2125,1054L2131,1056L2132,1058L2136,1059L2137,1061L2139,1061L2139,1062L2141,1062L2142,1064L2144,1064L2144,1065L2147,1066L2147,1065L2151,1062L2151,1060L2155,1057L2155,1055L2159,1052L2159,1050L2164,1046L2164,1044L2168,1041L2168,1039L2172,1036L2172,1034L2173,1034L2175,1031L2182,1031L2182,1032L2187,1032L2187,1033L2192,1033L2192,1034L2197,1034L2197,1035L2203,1035L2203,1036L2213,1037L2212,1042L2210,1043L2209,1047L2207,1048L2206,1052L2204,1053L2204,1055L2203,1055L2203,1057L2201,1058L2201,1060L2200,1060L2199,1063L2202,1064L2203,1066L2205,1066L2206,1068L2208,1068L2209,1070L2213,1071L2214,1073L2216,1073L2216,1074L2219,1075L2220,1077L2224,1078L2225,1080L2227,1080L2227,1081L2230,1082L2231,1084L2233,1084L2233,1085L2235,1085L2236,1087L2239,1088L2240,1085L2241,1085L2241,1083L2242,1083L2242,1081L2244,1080L2244,1078L2245,1078L2245,1076L2246,1076L2248,1070L2250,1069L2250,1067L2251,1067L2251,1065L2252,1065L2254,1059L2255,1059L2256,1056L2257,1056L2257,1052L2258,1052L2258,1048L2259,1048L2259,1044L2260,1044L2260,1040L2261,1040L2261,1036L2262,1036Z\"/>\n<path fill=\"#b29f7b\" fill-rule=\"evenodd\" d=\"M442,827L456,827L456,828L461,828L461,829L465,829L465,830L480,832L480,833L484,833L484,834L499,836L499,837L503,837L503,838L508,838L508,839L512,839L512,840L516,840L516,841L521,841L521,842L525,842L525,843L529,843L529,844L534,844L534,845L542,846L542,847L545,848L555,859L557,859L568,871L570,871L580,882L584,882L584,883L588,883L588,884L592,884L592,885L596,885L596,886L600,886L600,887L604,887L604,888L608,888L608,889L612,889L612,890L616,890L616,891L628,893L628,894L631,894L631,895L639,896L639,897L640,897L640,903L641,903L642,916L643,916L644,929L645,929L645,936L648,936L648,937L650,937L650,938L652,938L652,939L655,939L655,940L657,940L657,941L659,941L659,942L661,942L661,943L664,943L664,944L666,944L666,945L668,945L668,946L671,946L671,947L673,947L673,948L675,948L675,949L678,949L678,950L680,950L680,951L682,951L682,952L685,952L685,953L687,953L687,954L689,954L689,955L691,955L691,956L694,956L694,957L696,957L696,958L698,958L698,959L701,959L701,960L703,960L703,961L705,961L705,962L708,962L708,963L711,963L711,964L714,964L714,965L717,965L717,966L720,966L720,967L723,967L723,968L726,968L726,969L729,969L729,970L732,970L732,971L735,971L735,972L738,972L738,973L741,973L741,974L744,974L744,975L747,975L747,976L750,976L750,977L753,977L753,978L756,978L756,979L759,979L759,980L762,980L762,981L765,981L765,982L768,982L768,983L771,983L771,984L774,984L774,985L783,987L784,990L785,990L785,993L786,993L786,995L787,995L787,998L788,998L788,1000L789,1000L790,1006L791,1006L791,1008L792,1008L792,1013L788,1016L788,1018L787,1018L787,1019L785,1020L785,1022L781,1025L781,1027L778,1029L778,1031L774,1034L774,1036L770,1039L770,1041L767,1043L767,1045L763,1048L763,1050L759,1053L759,1055L756,1057L756,1059L752,1062L752,1070L751,1070L751,1077L750,1077L750,1085L749,1085L748,1101L747,1101L747,1108L746,1108L746,1116L745,1116L745,1118L741,1121L741,1123L736,1127L736,1129L732,1132L732,1134L728,1137L728,1139L723,1143L723,1145L722,1145L718,1150L714,1151L713,1153L709,1154L708,1156L704,1157L703,1159L699,1160L698,1162L694,1163L693,1165L689,1166L688,1168L682,1170L681,1172L677,1173L676,1175L674,1175L674,1176L672,1176L671,1178L667,1179L666,1181L662,1182L661,1189L660,1189L660,1192L659,1192L659,1195L658,1195L658,1198L657,1198L657,1201L656,1201L656,1204L655,1204L655,1207L654,1207L654,1211L653,1211L653,1214L652,1214L652,1217L651,1217L651,1220L650,1220L648,1229L645,1230L645,1231L643,1231L643,1232L640,1232L640,1233L638,1233L638,1234L636,1234L636,1235L634,1235L634,1236L631,1236L631,1237L629,1237L629,1238L627,1238L627,1239L624,1239L624,1240L622,1240L622,1241L620,1241L620,1242L618,1242L618,1243L615,1243L615,1244L613,1244L613,1245L611,1245L611,1246L608,1246L608,1247L606,1247L606,1248L604,1248L604,1249L602,1249L602,1250L599,1250L599,1253L598,1253L598,1255L597,1255L597,1257L596,1257L596,1260L595,1260L595,1262L594,1262L594,1265L593,1265L593,1267L592,1267L592,1269L591,1269L591,1272L590,1272L590,1274L589,1274L589,1276L588,1276L588,1279L587,1279L587,1281L586,1281L586,1284L585,1284L585,1286L584,1286L584,1288L583,1288L583,1291L582,1291L581,1295L580,1295L580,1296L577,1296L577,1297L574,1297L574,1298L571,1298L571,1299L568,1299L568,1300L565,1300L565,1301L562,1301L562,1302L559,1302L559,1303L556,1303L556,1304L553,1304L553,1305L550,1305L550,1306L547,1306L547,1307L543,1307L543,1308L537,1309L535,1315L533,1316L531,1322L529,1323L527,1329L525,1330L523,1336L521,1337L521,1339L520,1339L518,1345L516,1346L514,1352L512,1353L510,1359L509,1359L508,1361L501,1362L501,1363L498,1363L498,1364L495,1364L495,1365L491,1365L491,1366L486,1367L486,1368L490,1369L491,1371L493,1371L493,1372L499,1374L500,1376L506,1378L507,1381L506,1381L500,1388L498,1388L491,1396L489,1396L482,1404L480,1404L473,1412L471,1412L471,1414L477,1419L477,1421L483,1426L483,1428L490,1434L490,1436L497,1442L497,1444L504,1450L504,1453L495,1453L495,1454L486,1454L486,1455L476,1455L476,1456L465,1456L459,1449L457,1449L451,1442L449,1442L443,1435L441,1435L435,1428L433,1428L427,1421L425,1421L425,1420L419,1415L419,1398L420,1398L420,1383L421,1383L421,1367L422,1367L422,1361L423,1361L423,1356L424,1356L424,1351L425,1351L425,1345L426,1345L426,1340L427,1340L427,1335L428,1335L428,1329L429,1329L429,1324L430,1324L430,1319L431,1319L431,1313L432,1313L432,1308L433,1308L433,1303L434,1303L434,1297L435,1297L435,1292L436,1292L436,1287L437,1287L437,1281L438,1281L438,1276L439,1276L439,1271L440,1271L440,1265L441,1265L441,1260L442,1260L442,1255L443,1255L443,1249L444,1249L444,1244L445,1244L445,1239L446,1239L446,1234L447,1234L447,1228L448,1228L448,1223L449,1223L449,1218L450,1218L450,1212L451,1212L451,1207L452,1207L452,1202L453,1202L453,1196L454,1196L454,1191L455,1191L455,1186L456,1186L456,1181L457,1181L457,1175L458,1175L458,1170L459,1170L459,1165L460,1165L460,1159L461,1159L461,1154L462,1154L462,1147L461,1147L459,1138L458,1138L458,1136L457,1136L456,1130L455,1130L455,1128L454,1128L452,1119L451,1119L451,1117L450,1117L448,1108L447,1108L447,1106L446,1106L445,1100L442,1099L431,1087L429,1087L417,1074L415,1074L415,1073L403,1062L403,1060L401,1059L401,1057L400,1057L400,1055L399,1055L399,1053L398,1053L398,1051L397,1051L395,1045L393,1044L393,1042L392,1042L392,1040L391,1040L391,1038L390,1038L388,1032L386,1031L386,1029L385,1029L385,1027L384,1027L384,1025L383,1025L383,1023L382,1023L380,1017L378,1016L378,1014L377,1014L377,1012L376,1012L376,1010L375,1010L375,1008L374,1008L372,1002L370,1001L370,999L369,999L369,997L368,997L368,995L367,995L365,989L363,988L363,986L362,986L362,984L361,984L361,982L360,982L360,980L359,980L359,978L358,978L358,976L357,976L357,964L356,964L356,950L357,950L357,948L367,939L367,937L368,937L368,936L378,927L378,925L388,916L388,913L389,913L389,910L390,910L390,907L391,907L393,898L394,898L394,896L395,896L395,891L394,891L393,886L392,886L392,884L391,884L391,882L390,882L390,880L389,880L389,877L388,877L388,875L387,875L387,873L386,873L386,870L385,870L385,868L384,868L384,866L383,866L383,861L384,861L384,859L386,858L387,854L389,853L390,849L392,848L393,844L395,843L396,839L398,838L399,834L400,834L401,832L409,832L409,831L417,831L417,830L426,830L426,829L434,829L434,828L442,828Z\"/>\n<path fill=\"#a38291\" fill-rule=\"evenodd\" d=\"M1094,0L1227,0L1227,27L1226,27L1226,28L1223,28L1223,30L1222,30L1222,32L1220,33L1219,37L1220,37L1220,39L1221,39L1221,41L1222,41L1222,43L1223,43L1223,45L1224,45L1224,48L1225,48L1225,50L1226,50L1226,53L1227,53L1227,56L1228,56L1230,65L1231,65L1231,67L1232,67L1232,70L1233,70L1234,75L1235,75L1235,77L1236,77L1236,80L1237,80L1237,82L1238,82L1238,85L1239,85L1239,88L1240,88L1240,92L1241,92L1241,95L1242,95L1242,99L1243,99L1243,102L1244,102L1244,106L1246,107L1246,109L1247,109L1247,111L1248,111L1250,117L1252,118L1252,120L1253,120L1253,122L1254,122L1254,125L1255,125L1255,128L1254,128L1254,129L1245,137L1245,139L1233,150L1233,152L1222,162L1222,164L1221,164L1221,168L1222,168L1222,169L1205,170L1205,171L1195,171L1195,172L1186,172L1186,173L1179,173L1179,174L1172,174L1172,175L1165,175L1165,176L1158,176L1158,177L1151,177L1151,178L1135,179L1135,176L1134,176L1134,173L1133,173L1133,169L1132,169L1132,166L1131,166L1131,163L1130,163L1130,160L1129,160L1129,156L1128,156L1128,153L1127,153L1127,150L1126,150L1126,147L1125,147L1125,142L1126,142L1128,139L1130,139L1132,136L1134,136L1137,132L1139,132L1139,131L1140,131L1177,93L1179,93L1182,89L1165,88L1165,87L1157,87L1157,86L1148,86L1147,89L1146,89L1146,91L1145,91L1145,93L1143,94L1143,96L1142,96L1142,98L1141,98L1139,104L1137,105L1137,107L1136,107L1136,109L1135,109L1135,111L1134,111L1134,113L1133,113L1132,116L1118,116L1118,115L1079,113L1079,155L1080,155L1080,184L1081,184L1081,214L1080,214L1080,216L1078,217L1078,219L1077,219L1077,221L1075,222L1075,224L1073,225L1072,229L1070,230L1070,232L1069,232L1069,234L1067,235L1066,239L1064,240L1063,244L1062,244L1061,247L1059,248L1059,250L1058,250L1058,252L1056,253L1055,257L1053,258L1051,273L1050,273L1050,276L1049,276L1049,282L1048,282L1048,287L1047,287L1047,294L1048,294L1048,297L1049,297L1050,302L1051,302L1051,306L1052,306L1052,310L1053,310L1053,314L1054,314L1054,318L1055,318L1057,330L1052,331L1052,332L1048,332L1048,333L1045,333L1045,334L1042,334L1042,335L1039,335L1039,336L1036,336L1036,337L1033,337L1033,338L1030,338L1030,339L1027,339L1027,340L1024,340L1024,341L1021,341L1021,342L1018,342L1018,343L1015,343L1015,344L1012,344L1012,346L1014,346L1014,347L1016,347L1016,348L1018,348L1018,349L1024,351L1025,353L1027,353L1028,355L1030,355L1031,357L1035,358L1036,360L1038,360L1039,362L1041,362L1042,364L1045,365L1045,368L1042,370L1042,372L1038,375L1038,377L1037,377L1037,378L1035,379L1035,381L1032,383L1032,442L1075,484L1075,486L1076,486L1076,488L1077,488L1077,490L1078,490L1078,492L1079,492L1079,494L1080,494L1080,496L1081,496L1081,498L1082,498L1082,500L1083,500L1083,502L1084,502L1084,504L1085,504L1085,506L1086,506L1086,508L1087,508L1087,510L1088,510L1088,512L1089,512L1089,515L1090,515L1090,517L1091,517L1091,522L1090,522L1090,524L1089,524L1089,526L1088,526L1088,528L1087,528L1087,530L1086,530L1086,532L1085,532L1085,535L1084,535L1084,537L1083,537L1083,539L1082,539L1080,545L1075,549L1075,551L1069,556L1069,558L1068,558L1065,562L1062,562L1061,560L1059,560L1058,558L1054,557L1053,555L1051,555L1050,553L1048,553L1047,551L1045,551L1044,549L1042,549L1041,547L1039,547L1038,545L1035,544L1035,542L1041,542L1041,541L1047,541L1047,540L1053,540L1053,539L1071,537L1072,516L1070,516L1070,515L1069,515L1059,504L1057,504L1047,493L1045,493L1045,492L1044,492L1043,490L1041,490L1038,486L1036,486L1034,483L1032,483L1030,480L1028,480L1025,476L1023,476L1021,473L1019,473L1017,470L1015,470L1012,466L1010,466L1008,463L1006,463L1003,459L1001,459L1001,458L985,443L985,441L984,441L984,442L976,449L976,451L975,451L969,458L921,457L921,458L918,458L918,459L914,459L912,486L877,514L877,516L878,516L878,518L879,518L879,521L880,521L880,523L881,523L881,525L882,525L882,528L883,528L883,530L884,530L884,532L885,532L885,536L884,536L876,545L874,545L864,556L862,556L862,557L861,557L852,567L850,567L849,569L845,569L845,570L842,570L842,571L838,571L838,572L834,572L834,573L822,575L822,576L815,577L815,578L811,578L811,579L807,579L807,580L800,580L800,579L798,579L798,578L796,578L796,577L793,577L793,576L791,576L791,575L789,575L789,574L786,574L786,573L784,573L784,572L781,572L781,571L779,571L779,570L777,570L777,569L774,569L774,568L772,568L772,567L770,567L770,566L767,566L767,565L763,564L763,548L764,548L764,532L765,532L765,514L764,514L763,506L762,506L761,499L760,499L760,496L759,496L759,492L758,492L758,488L757,488L757,485L756,485L756,481L755,481L755,478L754,478L753,469L759,469L759,468L765,468L765,467L772,467L772,466L778,466L778,465L784,465L784,464L791,464L791,463L797,463L797,462L803,462L803,461L810,461L810,460L852,459L852,440L851,440L851,423L850,423L850,405L846,405L846,404L843,404L843,403L840,403L840,402L836,402L836,401L833,401L833,400L830,400L830,399L826,399L826,398L820,397L820,396L818,396L816,393L814,393L812,390L810,390L807,386L805,386L805,385L803,384L803,382L806,382L806,381L809,381L809,380L813,380L813,379L816,379L816,378L819,378L819,377L823,377L823,376L850,376L850,375L852,375L852,374L854,374L854,373L856,373L856,372L858,372L858,371L860,371L860,370L862,370L862,369L864,369L864,368L866,368L866,367L868,367L868,366L870,366L870,365L876,363L876,346L877,346L879,343L881,343L883,340L885,340L888,336L890,336L890,335L891,335L903,322L905,322L918,308L920,308L922,305L924,305L925,303L927,303L928,301L930,301L931,299L933,299L933,298L936,297L937,295L941,294L942,292L978,292L978,293L979,293L979,290L980,290L980,288L981,288L981,285L982,285L982,283L983,283L983,280L984,280L984,278L985,278L985,275L986,275L986,273L987,273L988,268L987,268L987,267L984,267L984,266L982,266L982,265L980,265L980,264L978,264L978,263L976,263L976,262L974,262L974,261L972,261L972,260L970,260L970,259L967,258L967,256L966,256L966,254L965,254L965,252L964,252L964,249L963,249L963,247L962,247L962,245L961,245L961,243L960,243L960,241L959,241L959,237L961,237L961,236L963,236L963,235L965,235L965,234L967,234L967,233L969,233L969,232L971,232L971,231L973,231L973,230L975,230L975,229L977,229L977,228L979,228L979,227L981,227L981,226L983,226L983,225L985,225L985,224L988,224L988,223L990,223L990,222L993,222L993,225L994,225L994,228L995,228L995,231L996,231L996,234L997,234L999,243L1004,243L1004,244L1009,244L1009,245L1014,245L1014,246L1022,247L1022,245L1019,243L1019,241L1017,240L1017,238L1015,237L1015,235L1013,234L1013,232L1010,230L1010,228L1008,227L1008,225L1007,225L1006,222L1004,221L996,196L992,196L992,197L989,197L989,198L985,198L985,199L981,199L981,200L977,200L977,201L973,201L973,202L969,202L969,203L965,203L965,204L961,204L961,205L955,205L955,204L952,203L951,201L947,200L946,198L944,198L943,196L941,196L940,194L938,194L937,192L935,192L934,190L932,190L931,188L929,188L929,187L927,186L926,180L925,180L925,178L924,178L924,175L923,175L923,172L922,172L922,169L921,169L921,166L920,166L920,163L919,163L919,160L918,160L918,157L917,157L917,154L916,154L916,151L915,151L915,147L917,147L918,145L920,145L920,144L922,144L922,143L924,143L924,142L926,142L926,141L928,141L928,140L930,140L930,139L932,139L932,138L934,138L934,137L936,137L936,136L938,136L938,135L945,134L945,133L949,133L949,132L953,132L953,131L960,130L960,129L964,129L964,128L968,128L968,127L975,126L975,125L979,125L980,122L996,107L996,105L997,105L1013,88L1015,88L1017,85L1019,85L1022,81L1024,81L1027,77L1029,77L1031,74L1033,74L1036,70L1038,70L1040,67L1042,67L1042,66L1046,63L1046,59L1045,59L1044,52L1043,52L1043,48L1042,48L1042,44L1041,44L1041,39L1046,38L1046,37L1049,37L1049,36L1052,36L1052,35L1057,34L1057,33L1060,33L1060,32L1063,32L1063,31L1065,31L1065,30L1074,28L1074,27L1076,27L1076,26L1085,24L1085,23L1083,23L1083,22L1084,22L1084,20L1085,20L1085,18L1086,18L1086,16L1087,16L1087,14L1088,14L1088,11L1089,11L1089,9L1090,9L1090,7L1091,7L1091,5L1092,5L1092,3L1093,3ZM797,208L827,208L827,211L826,211L826,213L825,213L825,215L824,215L824,217L823,217L823,219L822,219L821,222L850,222L849,226L848,226L847,229L845,230L845,232L844,232L844,234L842,235L841,239L840,239L839,242L837,243L835,249L859,272L859,274L863,277L863,279L865,280L865,282L867,283L867,285L869,286L869,288L871,289L871,291L873,292L873,294L875,295L875,297L877,297L878,299L880,299L881,301L883,301L884,303L886,303L887,305L889,305L890,307L892,307L893,309L896,310L896,313L892,316L892,318L888,321L888,323L887,323L884,327L873,328L873,329L867,329L867,330L861,330L861,331L856,331L856,332L838,334L838,335L833,335L833,336L828,336L828,337L823,337L823,338L818,338L818,339L803,341L804,336L805,336L805,334L806,334L806,332L807,332L807,330L808,330L808,328L809,328L809,326L810,326L812,320L814,319L814,317L816,316L817,312L818,312L819,309L820,309L819,307L816,307L816,306L814,306L814,305L812,305L812,304L810,304L810,303L808,303L808,302L803,303L801,306L799,306L798,308L796,308L796,309L793,310L792,312L787,313L787,314L785,314L785,315L782,315L782,316L779,316L779,317L776,317L776,318L767,320L767,321L765,321L765,322L762,322L762,323L759,323L759,324L756,324L756,325L753,325L753,326L749,326L749,325L748,325L748,323L746,322L745,318L743,317L744,308L745,308L745,305L746,305L746,302L747,302L747,299L748,299L748,292L747,292L747,289L746,289L744,277L761,277L761,275L769,268L769,266L770,266L770,265L776,260L776,258L783,252L785,243L786,243L786,241L787,241L789,232L790,232L790,230L791,230L791,226L792,226L793,219L794,219L795,212L796,212L796,209L797,209ZM1207,468L1225,468L1225,469L1227,469L1227,470L1229,470L1229,471L1231,471L1231,472L1233,472L1233,473L1235,473L1235,474L1238,474L1238,475L1240,475L1240,476L1242,476L1242,477L1244,477L1244,478L1246,478L1246,479L1248,479L1248,480L1289,480L1289,481L1290,481L1290,480L1304,480L1304,479L1331,478L1331,477L1347,477L1347,478L1349,478L1350,484L1357,490L1357,492L1363,497L1363,499L1370,505L1370,507L1371,507L1370,513L1368,514L1368,516L1367,516L1367,518L1366,518L1364,524L1362,525L1362,527L1361,527L1361,529L1360,529L1358,535L1356,536L1356,538L1355,538L1355,540L1354,540L1354,542L1353,542L1353,544L1352,544L1351,546L1334,547L1334,548L1317,549L1317,550L1308,550L1308,551L1299,551L1299,552L1282,553L1282,554L1273,554L1273,555L1265,555L1265,556L1255,556L1255,555L1253,555L1252,553L1248,552L1247,550L1243,549L1242,547L1238,546L1237,544L1233,543L1232,541L1230,541L1229,539L1225,538L1224,536L1222,536L1222,535L1220,535L1220,534L1218,533L1218,531L1216,530L1216,528L1215,528L1215,526L1214,526L1212,520L1210,519L1210,517L1209,517L1209,515L1208,515L1208,513L1207,513L1207,506L1208,506L1209,497L1170,498L1170,505L1169,505L1169,512L1168,512L1168,520L1169,520L1169,521L1177,528L1177,530L1188,540L1189,544L1187,544L1187,545L1185,545L1185,546L1183,546L1183,547L1181,547L1181,548L1179,548L1179,549L1177,549L1177,550L1175,550L1175,551L1173,551L1173,552L1171,552L1171,553L1169,553L1169,554L1167,554L1167,555L1165,555L1165,556L1163,556L1163,557L1160,557L1160,556L1154,551L1154,549L1146,542L1146,540L1138,533L1138,531L1131,525L1131,523L1123,516L1123,514L1115,507L1115,501L1116,501L1117,493L1118,493L1118,492L1123,492L1123,491L1128,491L1128,490L1134,490L1134,489L1139,489L1139,488L1145,488L1145,487L1155,486L1155,485L1161,485L1161,484L1163,484L1163,483L1165,483L1165,482L1167,482L1167,481L1169,481L1169,480L1171,480L1171,479L1173,479L1173,478L1175,478L1175,477L1177,477L1177,476L1179,476L1179,475L1186,474L1186,473L1190,473L1190,472L1194,472L1194,471L1201,470L1201,469L1207,469Z\"/>\n<path fill=\"#bfc6cc\" fill-rule=\"evenodd\" d=\"M1397,505L1401,505L1410,515L1412,515L1412,513L1416,514L1417,516L1419,516L1420,518L1422,518L1423,520L1425,520L1426,522L1428,522L1429,524L1431,524L1432,526L1434,526L1434,527L1437,528L1437,529L1442,529L1442,528L1447,528L1447,527L1456,526L1456,525L1460,525L1460,524L1470,523L1470,524L1473,525L1475,528L1477,528L1479,531L1481,531L1484,535L1486,535L1488,538L1490,538L1492,541L1494,541L1496,544L1498,544L1500,547L1502,547L1504,550L1506,550L1508,553L1511,553L1511,556L1512,556L1512,564L1513,564L1513,571L1514,571L1515,595L1516,595L1516,609L1517,609L1517,622L1518,622L1519,667L1516,668L1515,670L1513,670L1512,672L1510,672L1509,674L1507,674L1506,676L1504,676L1503,678L1501,678L1500,680L1498,680L1497,682L1495,682L1494,684L1491,684L1475,667L1472,667L1472,666L1469,666L1469,665L1466,665L1466,664L1463,664L1463,663L1460,663L1460,662L1457,662L1457,661L1454,661L1454,660L1451,660L1451,659L1448,659L1448,658L1445,658L1445,657L1442,657L1442,656L1439,656L1439,655L1430,653L1430,652L1425,651L1425,650L1423,650L1423,649L1417,648L1417,647L1412,646L1412,645L1410,645L1410,644L1407,644L1407,643L1404,643L1404,642L1402,642L1402,641L1399,641L1399,640L1396,640L1396,639L1394,639L1394,638L1389,637L1389,636L1377,625L1377,623L1365,612L1365,610L1353,599L1353,597L1352,597L1352,628L1353,628L1354,630L1356,630L1357,632L1361,633L1362,635L1364,635L1365,637L1367,637L1368,639L1370,639L1371,641L1373,641L1374,643L1376,643L1377,645L1379,645L1380,647L1382,647L1382,648L1385,649L1386,651L1392,652L1392,653L1394,653L1394,654L1400,655L1400,656L1402,656L1402,657L1411,659L1411,660L1413,660L1413,661L1416,661L1416,662L1419,662L1419,663L1421,663L1421,664L1424,664L1424,665L1427,665L1427,666L1429,666L1429,667L1432,667L1432,668L1437,669L1437,670L1439,671L1439,673L1441,674L1442,678L1444,679L1444,681L1446,682L1447,686L1449,687L1449,689L1451,690L1452,693L1453,693L1455,690L1457,690L1461,685L1463,685L1466,681L1469,681L1471,684L1473,684L1473,685L1505,716L1504,720L1487,736L1487,738L1470,754L1470,756L1469,756L1454,772L1451,772L1451,773L1448,773L1448,774L1445,774L1445,775L1442,775L1442,776L1439,776L1439,777L1436,777L1436,778L1433,778L1433,779L1430,779L1430,780L1427,780L1427,781L1424,781L1424,782L1421,782L1421,783L1418,783L1418,784L1415,784L1415,785L1412,785L1412,786L1409,786L1409,787L1406,787L1406,788L1403,788L1403,789L1400,789L1400,790L1397,790L1397,791L1394,791L1394,792L1391,792L1391,793L1388,793L1388,794L1385,794L1385,795L1382,795L1382,796L1379,796L1379,797L1376,797L1376,798L1372,798L1372,799L1369,799L1369,800L1366,800L1366,801L1363,801L1363,802L1360,802L1360,803L1356,803L1356,799L1355,799L1355,795L1354,795L1354,790L1353,790L1353,786L1352,786L1352,781L1351,781L1351,777L1350,777L1350,773L1349,773L1349,768L1348,768L1348,764L1347,764L1347,760L1346,760L1346,755L1345,755L1345,751L1344,751L1344,747L1343,747L1343,742L1305,705L1305,703L1304,703L1301,699L1299,699L1294,693L1292,693L1288,688L1286,688L1281,682L1279,682L1275,677L1273,677L1269,672L1267,672L1262,666L1260,666L1256,661L1254,661L1249,655L1247,655L1248,659L1250,660L1250,662L1251,662L1251,664L1252,664L1254,670L1256,671L1256,673L1257,673L1259,679L1261,680L1261,682L1262,682L1264,688L1266,689L1266,691L1267,691L1269,697L1271,698L1271,700L1272,700L1274,706L1276,707L1276,709L1277,709L1279,715L1281,716L1281,718L1282,718L1284,724L1250,724L1250,723L1215,723L1215,722L1180,722L1180,721L1179,721L1178,728L1177,728L1177,731L1176,731L1176,734L1175,734L1175,737L1174,737L1174,740L1173,740L1171,749L1168,749L1168,748L1166,748L1166,747L1164,747L1164,746L1162,746L1162,745L1160,745L1160,744L1158,744L1158,743L1156,743L1156,742L1154,742L1154,741L1148,739L1147,737L1145,737L1145,736L1143,736L1143,735L1141,735L1141,734L1139,734L1139,733L1137,733L1137,732L1135,732L1135,731L1133,731L1133,730L1131,730L1131,729L1129,729L1129,728L1127,728L1127,727L1121,725L1120,723L1118,723L1118,722L1116,722L1116,721L1114,721L1114,720L1112,720L1112,719L1110,719L1110,718L1108,718L1108,717L1106,717L1106,716L1104,716L1104,715L1102,715L1102,714L1100,714L1100,713L1094,711L1093,709L1091,709L1091,708L1084,702L1084,700L1077,694L1077,692L1070,686L1070,684L1063,678L1063,676L1056,670L1056,668L1049,662L1049,660L1048,660L1048,658L1047,658L1047,655L1046,655L1046,653L1045,653L1045,650L1044,650L1044,648L1043,648L1043,645L1042,645L1042,643L1041,643L1041,641L1040,641L1040,638L1039,638L1039,636L1038,636L1038,633L1037,633L1037,631L1036,631L1036,628L1035,628L1035,626L1034,626L1034,623L1033,623L1033,621L1032,621L1032,618L1031,618L1031,616L1030,616L1030,613L1029,613L1029,611L1028,611L1028,608L1034,609L1034,610L1036,610L1036,611L1039,611L1039,612L1044,613L1044,614L1046,614L1046,615L1052,616L1052,617L1057,618L1057,619L1059,619L1059,620L1065,621L1065,622L1070,623L1070,624L1072,624L1072,625L1078,626L1078,627L1080,627L1080,628L1083,628L1083,629L1085,629L1085,630L1088,630L1088,631L1090,631L1090,632L1093,632L1093,633L1095,633L1095,634L1097,634L1097,635L1100,635L1100,636L1102,636L1102,637L1105,637L1105,638L1110,639L1110,640L1112,640L1112,641L1114,641L1114,642L1117,642L1117,643L1120,643L1120,642L1123,641L1125,638L1127,638L1128,636L1130,636L1131,633L1133,633L1133,631L1134,631L1140,624L1146,624L1146,625L1150,625L1150,626L1154,626L1154,627L1158,627L1158,628L1162,628L1162,629L1167,629L1167,630L1171,630L1171,631L1175,631L1175,632L1180,632L1180,631L1183,630L1186,626L1188,626L1190,623L1192,623L1194,620L1196,620L1199,616L1201,616L1203,613L1205,613L1205,612L1211,612L1211,611L1224,610L1224,609L1231,609L1232,607L1234,607L1235,605L1237,605L1238,603L1240,603L1241,601L1243,601L1244,599L1246,599L1247,597L1249,597L1250,595L1252,595L1252,585L1253,585L1254,566L1255,566L1255,557L1256,557L1256,556L1265,556L1265,555L1291,553L1291,552L1299,552L1299,551L1308,551L1308,550L1326,549L1326,548L1334,548L1334,547L1352,546L1352,544L1353,544L1353,542L1354,542L1356,536L1358,535L1358,533L1359,533L1359,531L1360,531L1362,525L1364,524L1364,522L1365,522L1365,520L1366,520L1366,518L1367,518L1367,516L1368,516L1368,514L1370,513L1371,510L1374,510L1375,512L1379,512L1379,511L1382,511L1382,510L1385,510L1385,509L1388,509L1388,508L1391,508L1391,507L1394,507L1394,506L1397,506Z\"/>\n<path fill=\"#baa8ce\" fill-rule=\"evenodd\" d=\"M1118,253L1123,253L1123,254L1122,254L1122,258L1123,258L1123,259L1127,260L1128,262L1132,263L1133,265L1139,267L1140,269L1144,270L1145,272L1149,273L1150,275L1154,276L1155,278L1157,278L1157,279L1159,279L1159,280L1161,280L1162,282L1165,283L1165,322L1166,322L1166,326L1167,326L1167,330L1168,330L1168,334L1169,334L1169,349L1166,350L1164,353L1162,353L1162,354L1161,354L1159,357L1157,357L1155,360L1153,360L1153,361L1150,363L1150,365L1148,366L1148,368L1151,368L1151,369L1154,369L1154,370L1163,372L1163,373L1165,373L1165,374L1168,375L1168,376L1176,376L1176,375L1206,375L1241,411L1243,411L1244,414L1246,414L1246,415L1249,417L1249,420L1248,420L1248,421L1236,432L1236,434L1224,445L1224,447L1221,449L1221,451L1219,452L1219,454L1216,456L1216,458L1213,460L1213,462L1211,463L1211,465L1210,465L1208,468L1201,469L1201,470L1197,470L1197,471L1190,472L1190,473L1186,473L1186,474L1182,474L1182,475L1175,476L1175,477L1171,477L1171,478L1168,478L1168,479L1160,480L1160,481L1157,481L1157,482L1145,484L1145,485L1138,486L1138,487L1134,487L1134,488L1127,489L1127,490L1121,490L1121,489L1119,489L1119,488L1117,488L1117,487L1111,485L1110,483L1108,483L1108,482L1106,482L1106,481L1104,481L1104,480L1098,478L1097,476L1095,476L1095,475L1093,475L1093,474L1091,474L1091,473L1085,471L1085,470L1080,466L1080,464L1077,462L1077,460L1074,458L1074,456L1070,453L1070,451L1067,449L1067,447L1063,444L1063,442L1060,440L1060,438L1049,438L1049,437L1039,437L1039,436L1038,436L1036,404L1035,404L1035,394L1034,394L1034,381L1039,377L1039,375L1045,370L1045,368L1046,368L1049,364L1046,363L1046,362L1044,362L1044,361L1042,361L1042,360L1040,360L1040,359L1038,359L1038,358L1036,358L1036,357L1034,357L1034,356L1032,356L1032,355L1030,355L1030,354L1028,354L1028,353L1026,353L1026,352L1024,352L1024,351L1022,351L1022,350L1020,350L1020,349L1018,349L1018,348L1016,348L1016,347L1014,347L1014,346L1012,346L1012,344L1015,344L1015,343L1018,343L1018,342L1021,342L1021,341L1024,341L1024,340L1027,340L1027,339L1030,339L1030,338L1033,338L1033,337L1036,337L1036,336L1039,336L1039,335L1042,335L1042,334L1045,334L1045,333L1048,333L1048,332L1052,332L1052,331L1057,330L1057,326L1056,326L1056,322L1055,322L1055,318L1054,318L1054,314L1053,314L1053,310L1052,310L1052,306L1051,306L1051,301L1050,301L1050,297L1049,297L1049,276L1050,276L1050,275L1053,275L1053,274L1056,274L1056,273L1059,273L1059,272L1062,272L1062,271L1065,271L1065,270L1068,270L1068,269L1071,269L1071,268L1074,268L1074,267L1078,267L1078,266L1081,266L1081,265L1084,265L1084,264L1087,264L1087,263L1090,263L1090,262L1093,262L1093,261L1096,261L1096,260L1099,260L1099,259L1102,259L1102,258L1105,258L1105,257L1108,257L1108,256L1111,256L1111,255L1115,255L1115,254L1118,254Z\"/>\n<path fill=\"#d0c28d\" fill-rule=\"evenodd\" d=\"M25,551L33,551L33,552L40,552L40,553L48,553L48,554L55,554L55,555L63,555L63,556L71,556L71,557L78,557L78,558L93,559L93,560L97,561L98,563L102,564L103,566L107,567L108,569L112,570L113,572L117,573L118,575L122,576L123,578L125,578L126,580L130,581L131,583L135,584L136,586L138,586L138,587L140,587L140,588L143,588L143,587L145,587L145,586L147,586L147,585L149,585L149,584L151,584L151,583L153,583L153,582L156,582L156,583L169,595L169,597L185,612L185,614L186,614L186,615L200,628L200,630L202,631L203,636L204,636L204,639L205,639L205,642L206,642L206,644L207,644L207,647L208,647L208,650L209,650L209,653L210,653L210,656L211,656L211,658L212,658L214,667L215,667L215,669L216,669L218,678L219,678L219,680L220,680L222,689L223,689L223,691L224,691L226,700L230,700L230,701L234,701L234,702L241,703L241,704L244,704L244,705L248,705L248,706L252,706L252,707L255,707L255,708L262,709L262,706L263,706L263,703L264,703L264,700L265,700L265,697L266,697L266,694L267,694L267,690L268,690L268,687L269,687L269,684L270,684L270,681L271,681L271,678L272,678L272,677L280,677L280,676L304,674L304,680L303,680L303,686L302,686L302,693L301,693L301,699L300,699L300,705L299,705L299,711L298,711L298,717L297,717L297,724L296,724L294,742L296,742L296,743L298,743L298,744L300,744L300,745L303,745L303,746L305,746L305,747L307,747L307,748L309,748L309,749L312,749L312,750L314,750L314,751L316,751L316,752L319,752L319,753L321,753L321,754L323,754L323,755L326,755L326,756L328,756L328,757L330,757L330,758L332,758L332,759L335,759L335,760L337,760L337,761L339,761L339,762L376,762L376,763L377,763L377,765L367,774L367,776L366,776L366,777L358,784L358,786L350,793L350,796L352,797L352,799L353,799L353,801L354,801L354,803L355,803L357,809L359,810L359,812L360,812L360,814L361,814L361,816L362,816L362,818L363,818L363,820L364,820L364,836L363,836L362,865L357,864L356,862L352,861L352,860L349,859L348,857L344,856L343,854L339,853L339,852L336,851L335,849L331,848L330,846L326,845L325,843L323,843L322,841L318,840L317,838L313,837L312,835L310,835L310,834L308,833L307,828L306,828L306,826L305,826L305,824L304,824L304,821L303,821L303,819L302,819L302,816L301,816L301,814L300,814L300,811L299,811L299,809L298,809L298,806L297,806L297,804L296,804L296,801L294,800L293,796L291,795L290,791L288,790L287,786L285,785L283,779L281,778L281,776L280,776L280,774L278,773L277,769L275,768L274,764L271,764L271,763L269,763L269,762L263,761L263,760L261,760L261,759L258,759L258,758L253,757L253,756L251,756L251,755L245,754L245,753L240,752L240,751L238,751L238,750L233,750L233,749L229,749L229,748L224,748L224,747L215,746L215,745L211,745L211,744L206,744L206,743L202,743L202,742L197,742L197,741L193,741L193,740L189,740L189,739L184,739L184,738L180,738L180,737L175,737L175,736L171,736L171,735L166,735L166,734L162,734L162,733L153,732L153,731L117,696L117,694L111,689L111,687L110,687L110,686L108,685L108,683L105,681L105,679L103,678L103,676L100,674L100,672L97,670L97,668L94,666L94,664L93,664L93,663L91,662L91,660L88,658L88,656L86,655L86,653L83,651L83,649L80,647L80,645L77,643L77,641L76,641L76,640L74,639L74,637L71,635L71,633L69,632L69,630L68,630L68,629L66,628L66,626L63,624L63,622L61,621L61,619L59,618L59,616L57,615L57,613L55,612L55,610L54,610L53,607L51,606L50,602L48,601L48,599L46,598L46,596L44,595L44,593L42,592L42,590L40,589L40,587L38,586L38,584L36,583L36,581L35,581L34,578L32,577L31,573L30,573L29,570L27,569L27,567L26,567L26,559L25,559Z\"/>\n</svg>", en = {
	"#cbcbc7": "#cbcbc7",
	"#af2124": "#af2124",
	"#917c87": "#917c87",
	"#eac4a2": "#eac4a2",
	"#e67d31": "#e67d31",
	"#b29f7b": "#b29f7b",
	"#a38291": "#a38291",
	"#bfc6cc": "#a9c4d8",
	"#baa8ce": "#baa8ce",
	"#d0c28d": "#d0c28d"
}, tn = {
	us: "#2563eb",
	ussr: "#dc2626"
}, nn = 352, rn = {
	influence: 38,
	detail: 62
}, an = 180, on = 160 / nn, sn = [
	"presence",
	"domination",
	"control"
], cn = 12, ln = Object.entries(Qt).flatMap(([e, t]) => {
	if (!D.includes(e)) return [];
	let n = ie.find((t) => w[e].regions.includes(t));
	return n ? [{
		region: n,
		rect: t
	}] : [];
});
function un(e, t) {
	let n = Object.fromEntries(ie.map((e) => [e, Infinity]));
	for (let { region: r, rect: i } of ln) {
		let a = Math.max(i.x - e, 0, e - i.x - i.w), o = Math.max(i.y - t, 0, t - i.y - i.h), s = Math.hypot(a, o);
		s < n[r] && (n[r] = s);
	}
	return {
		region: ie.reduce((e, t) => n[t] < n[e] ? t : e),
		distanceByRegion: n
	};
}
function dn(e, t, n) {
	let r = Math.min(1, Math.max(0, (n - e) / (t - e)));
	return r * r * (3 - 2 * r);
}
function fn(e, t, n) {
	return e + (t - e) * n;
}
function pn(e, t, n) {
	if (n <= 0) return e;
	if (n >= 1) return t;
	let r = Number.parseInt(e.slice(1), 16), i = Number.parseInt(t.slice(1), 16), a = (e) => Math.round(fn(r >> e & 255, i >> e & 255, n)).toString(16).padStart(2, "0");
	return "#" + a(16) + a(8) + a(0);
}
var mn = {
	us: {
		x: 900,
		y: 2080
	},
	ussr: {
		x: 5400,
		y: 1160
	}
};
function hn(e, t, n) {
	let r = e.x + e.w / 2, i = e.y + e.h / 2, a = t - r, o = n - i, s = Math.min(a === 0 ? Infinity : e.w / 2 / Math.abs(a), o === 0 ? Infinity : e.h / 2 / Math.abs(o));
	return {
		x: r + a * s,
		y: i + o * s
	};
}
var gn = {
	"#af2124": null,
	"#917c87": "europe",
	"#eac4a2": "africa",
	"#e67d31": "asia",
	"#b29f7b": "southAmerica",
	"#a38291": "europe",
	"#bfc6cc": "middleEast",
	"#baa8ce": "europe",
	"#d0c28d": "centralAmerica"
}, _n = (() => {
	let e = $t.replace(/^[\s\S]*?<svg[^>]*>/, "").replace(/<\/svg>\s*$/, "");
	for (let [t, n] of Object.entries(gn)) e = e.replace(`fill="${t}"`, `fill="${t}" data-scoring-region="${n ?? "none"}"`);
	for (let [t, n] of Object.entries(en)) e = e.split(`fill="${t}"`).join(`fill="${n}"`);
	return e;
})();
function vn(e) {
	let t = [], n = /* @__PURE__ */ new Set(), r = (e) => {
		if (e === "us" || e === "ussr") return mn[e];
		let t = Qt[e];
		return t ? {
			x: t.x + t.w / 2,
			y: t.y + t.h / 2
		} : null;
	}, i = (t, n, i) => {
		if (t === "us" || t === "ussr") return mn[t];
		let a = Qt[t];
		return a ? e ? hn(a, n, i) : r(t) : null;
	};
	for (let [e, a] of Object.entries(w)) {
		let o = r(e);
		if (o) for (let s of a.adjacent) {
			let a = r(s);
			if (!a) continue;
			let c = [e, s].sort().join("|");
			if (!n.has(c)) {
				if (n.add(c), Math.abs(o.x - a.x) > 4591) {
					let [n, c] = o.x < a.x ? [e, s] : [s, e], l = r(n), u = r(c), d = i(n, l.x - 1e3, l.y), f = i(c, u.x + 1e3, u.y);
					t.push({
						x1: d.x,
						y1: d.y,
						x2: d.x - 420,
						y2: d.y
					}), t.push({
						x1: f.x,
						y1: f.y,
						x2: f.x + 420,
						y2: f.y
					});
				} else {
					let n = i(e, a.x, a.y), r = i(s, o.x, o.y);
					t.push({
						x1: n.x,
						y1: n.y,
						x2: r.x,
						y2: r.y
					});
				}
			}
		}
	}
	return t;
}
var yn = vn(!1), bn = vn(!0);
function xn({ pub: e, tap: t, focus: s, onTapCountry: c, onOpenList: l }) {
	let u = o(), f = i(null), h = i(null), [g, ee] = a({
		w: 0,
		h: 0
	}), [b, x] = a(null), [te, ne] = a("africa"), S = i({
		cx: Xt / 2,
		cy: Zt / 2,
		s: .05
	}), C = i(!1);
	n(() => {
		let e = f.current, t = new ResizeObserver(() => ee({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let w = g.w > 0 ? Math.max(g.w / Xt, g.h / Zt) : .05, re = (e) => {
		let t = Math.min(Math.max(e.s, w), on), n = g.w / 2 / t, r = g.h / 2 / t;
		return {
			cx: n * 2 >= 9182 ? Xt / 2 : Math.min(Math.max(e.cx, n), Xt - n),
			cy: r * 2 >= 5940 ? Zt / 2 : Math.min(Math.max(e.cy, r), Zt - r),
			s: t
		};
	}, ie = i(re);
	n(() => {
		ie.current = re;
	}), n(() => {
		g.w !== 0 && g.h !== 0 && (C.current ? x(ie.current(S.current)) : x({
			cx: Xt / 2,
			cy: Zt / 2,
			s: w
		}));
	}, [g, w]);
	let T = b ?? {
		cx: 4591,
		cy: 2970,
		s: w
	};
	n(() => {
		S.current = T;
	}), n(() => {
		if (!h.current) return;
		let e = h.current.createSVGPoint();
		e.x = T.cx * 2296 / Xt, e.y = T.cy * 1485 / Zt;
		let t = [...h.current.querySelectorAll("path[data-scoring-region]")].reverse().find((t) => t.isPointInFill(e))?.dataset.scoringRegion;
		if (t && t !== "none") {
			ne(t);
			return;
		}
		let n = un(T.cx, T.cy);
		ne((e) => {
			if (e === n.region) return e;
			let t = cn / T.s;
			return n.distanceByRegion[n.region] + t < n.distanceByRegion[e] ? n.region : e;
		});
	}, [
		T.cx,
		T.cy,
		T.s,
		g.w,
		g.h
	]);
	let ae = T.s * nn, oe = (ae >= rn.detail ? "detail" : ae >= rn.influence ? "influence" : "overview") == "detail", se = [
		w,
		rn.detail / nn,
		on
	].filter((e, t) => t === 0 || e > w + 1e-9), le = (e) => se.find((t) => t > e + 1e-6) ?? se[0], E = le(T.s) > T.s, ue = () => {
		C.current = !0;
		let e = S.current, t = re({
			...e,
			s: le(e.s)
		});
		S.current = t, x(t);
	}, de = ae >= rn.influence, fe = g.w > 0 && g.h > 0, pe = _(), [D, O] = a(0), k = i(0), me = i(!1), A = dn(54, 68, ae), j = Te(e, te), M = ce[te];
	r(() => {
		if (!fe) return;
		let e = +!!de;
		if (!me.current || pe) {
			me.current = !0, k.current = e, O(e);
			return;
		}
		let t = k.current;
		if (Math.abs(t - e) < .001) return;
		let n = an * Math.abs(e - t), r = performance.now(), i = 0, a = (o) => {
			let s = Math.min(1, (o - r) / n), c = fn(t, e, dn(0, 1, s));
			k.current = c, O(c), s < 1 && (i = requestAnimationFrame(a));
		};
		return i = requestAnimationFrame(a), () => cancelAnimationFrame(i);
	}, [
		de,
		fe,
		pe
	]);
	let N = i(oe);
	n(() => {
		N.current = oe;
	}), n(() => {
		if (!s) return;
		let e = Qt[s.country];
		if (!e) return;
		let t = requestAnimationFrame(() => {
			let t = ie.current({
				cx: e.x + e.w / 2,
				cy: e.y + e.h / 2,
				s: on
			});
			C.current = !0, S.current = t, x(t);
		});
		return () => cancelAnimationFrame(t);
	}, [s]), n(() => {
		let e = f.current, t = (t) => {
			t.preventDefault(), C.current = !0;
			let n = e.getBoundingClientRect(), r = S.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = ie.current({
				...r,
				s: r.s * i
			}).s, o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = ie.current({
				s: a,
				cx: c - o / a,
				cy: l - s / a
			});
			S.current = u, x(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, []);
	let P = i(/* @__PURE__ */ new Map()), he = i(0), F = i(0), I = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), P.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), P.current.size === 1 && (he.current = 0), P.current.size === 2) {
			let [e, t] = [...P.current.values()];
			F.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, ge = (e) => {
		let t = P.current.get(e.pointerId);
		if (!t) return;
		let n = f.current.getBoundingClientRect();
		if (P.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			he.current += Math.abs(n) + Math.abs(r), he.current > 10 && (C.current = !0);
			let i = S.current, a = re({
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			});
			S.current = a, x(a);
		} else if (P.current.size === 2) {
			C.current = !0, P.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...P.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (F.current > 0 && i > 0) {
				let e = S.current, a = re({
					...e,
					s: e.s * i / F.current
				}).s, o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = re({
					s: a,
					cx: c - o / a,
					cy: l - s / a
				});
				S.current = u, x(u);
			}
			F.current = i, he.current = 99;
			return;
		}
		P.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, _e = (e) => {
		let t = P.current.size === 1 && he.current < 10;
		if (P.current.delete(e.pointerId), F.current = 0, !t) return;
		let n = f.current.getBoundingClientRect(), r = S.current, i = r.cx + (e.clientX - n.left - n.width / 2) / r.s, a = r.cy + (e.clientY - n.top - n.height / 2) / r.s, o = null, s = Infinity;
		for (let [e, t] of Object.entries(Qt)) {
			let n = i >= t.x - 8 && i <= t.x + t.w + 8 && a >= t.y - 8 && a <= t.y + t.h + 8, r = Math.hypot(i - (t.x + t.w / 2), a - (t.y + t.h / 2));
			n ? r < s && (s = r, o = e) : !N.current && r < 240 && r < s && (s = r, o = e);
		}
		if (o) {
			if (!N.current) {
				let e = Qt[o], t = re({
					cx: e.x + e.w / 2,
					cy: e.y + e.h / 2,
					s: on
				});
				C.current = !0, S.current = t, x(t);
				return;
			}
			c(o);
		}
	};
	return /* @__PURE__ */ y("div", {
		className: "ts-map-shell relative h-full w-full",
		children: [
			/* @__PURE__ */ v("div", {
				ref: f,
				className: "ts-map-viewport h-full w-full touch-none overflow-hidden select-none",
				onPointerDown: I,
				onPointerMove: ge,
				onPointerUp: _e,
				onPointerCancel: _e,
				children: g.w > 0 && /* @__PURE__ */ v("svg", {
					width: g.w,
					height: g.h,
					"aria-hidden": "true",
					children: /* @__PURE__ */ y("g", {
						transform: `translate(${g.w / 2 - T.cx * T.s}, ${g.h / 2 - T.cy * T.s}) scale(${T.s})`,
						children: [
							/* @__PURE__ */ v("svg", {
								ref: h,
								width: 9182,
								height: 5940,
								viewBox: "0 0 2296 1485",
								preserveAspectRatio: "none",
								dangerouslySetInnerHTML: { __html: _n }
							}),
							/* @__PURE__ */ v("g", {
								stroke: "#4a3226",
								strokeWidth: 1.25 / T.s,
								strokeLinecap: "round",
								opacity: .72,
								children: yn.map((e, t) => {
									let n = bn[t];
									return /* @__PURE__ */ v("line", {
										x1: fn(e.x1, n.x1, D),
										y1: fn(e.y1, n.y1, D),
										x2: fn(e.x2, n.x2, D),
										y2: fn(e.y2, n.y2, D)
									}, t);
								})
							}),
							Object.entries(Qt).map(([n, r]) => /* @__PURE__ */ v(On, {
								c: n,
								r,
								pub: e,
								scale: T.s,
								frameProgress: D,
								detailMix: A,
								tapKind: t.get(n) ?? null
							}, n))
						]
					})
				})
			}),
			/* @__PURE__ */ y("div", {
				className: "ts-map-heading pointer-events-none absolute inset-x-0 top-0",
				children: [/* @__PURE__ */ v("strong", { children: u("games.twilightstruggle.mapWorldSituation") }), /* @__PURE__ */ v("span", { children: u("games.twilightstruggle.turnLabel", { n: e.turn }) })]
			}),
			/* @__PURE__ */ y("div", {
				className: "ts-map-score pointer-events-none absolute bottom-2 left-2",
				children: [/* @__PURE__ */ v("div", {
					className: "ts-map-score-title",
					children: u("games.twilightstruggle.region." + te)
				}), sn.map((e, t) => /* @__PURE__ */ y("div", {
					className: "ts-map-score-row",
					children: [
						/* @__PURE__ */ y("span", { children: [u("games.twilightstruggle." + e), "："] }),
						/* @__PURE__ */ v("strong", { children: M[t] === null ? u("games.twilightstruggle.autoVictory") : u("games.twilightstruggle.scorePoints", { n: M[t] }) }),
						/* @__PURE__ */ y("span", {
							className: "ts-map-score-sides",
							children: [j.usTier === e && /* @__PURE__ */ v("b", {
								className: "is-us",
								children: u("games.twilightstruggle.sideUs")
							}), j.ussrTier === e && /* @__PURE__ */ v("b", {
								className: "is-ussr",
								children: u("games.twilightstruggle.sideUssr")
							})]
						})
					]
				}, e))]
			}),
			/* @__PURE__ */ y("div", {
				className: "absolute right-2 top-10 flex flex-col gap-2",
				children: [/* @__PURE__ */ v("button", {
					className: "ts-map-control flex h-11 w-11 items-center justify-center",
					onClick: ue,
					"aria-label": u("games.twilightstruggle.zoomCycle"),
					children: v(E ? p : m, { className: "h-5 w-5" })
				}), /* @__PURE__ */ v("button", {
					className: "ts-map-control flex h-11 w-11 items-center justify-center",
					onClick: l,
					"aria-label": u("games.twilightstruggle.listOpen"),
					children: /* @__PURE__ */ v(d, { className: "h-5 w-5" })
				})]
			})
		]
	});
}
var Sn = {
	europe: "#aa9bb9",
	middleEast: "#b9d6df",
	asia: "#eaa33b",
	southeastAsia: "#e6c755",
	africa: "#e8c99a",
	centralAmerica: "#d8ce9b",
	southAmerica: "#9eb984"
}, Cn = {
	bg: "#4b6995",
	plain: "#e4d7bb"
}, wn = {
	bg: "#35516f",
	plain: "#f0e7cf"
};
function Tn(e) {
	let t = w[e].regions;
	return t.includes("southeastAsia") ? "southeastAsia" : t[0];
}
function En(e) {
	return [...e].reduce((e, t) => e + (t.charCodeAt(0) > 11903 ? 1 : .56), 0);
}
function Dn(e, t) {
	return Math.min(38, t / Math.max(En(e), 1));
}
function On({ c: e, r: t, pub: n, scale: r, frameProgress: i, detailMix: a, tapKind: s }) {
	let c = o(), l = w[e], u = n.influence[e] ?? {
		us: 0,
		ussr: 0
	}, d = u.us >= u.ussr + l.stability ? "us" : u.ussr >= u.us + l.stability ? "ussr" : null, f = l.battleground, p = r * nn, m = t.x + t.w / 2, h = t.y + t.h / 2, g = d === "ussr" ? 8.5 : 10, _ = fn(g / r, t.w, i), b = fn(g / r, t.h, i), x = m - _ / 2, te = h - b / 2, ne = 3 / r, S = Math.max(String(u.us).length, String(u.ussr).length), C = 18 + Math.max(0, p - 80) * .15, re = Math.max(0, Math.min(t.h * .58, C / r, (_ / 2 - 4 / r) / (S * .62))), ie = i >= .84, T = pn(d === "us" ? "#286080" : d === "ussr" ? "#af3432" : "#f5edda", Sn[Tn(e)], i), ae = pn(f ? "#dbb960" : "#27343b", d ? tn[d] : "#27343b", i), oe = d === "ussr" ? 45 * (1 - i) : 0, se = (d === "us" ? 5 : d === "ussr" ? 0 : 1) * (1 - i) / r, ce = c("games.twilightstruggle.country." + e), le = t.w - 56 - 28, E = Math.min(9.5, 56 * r / 1.35), ue = Math.max(Dn(ce, le), E / r), de = Math.min(le, En(ce) * ue), fe = dn(78, 108, p) * a, pe = t.y + (t.h + 56) / 2;
	return /* @__PURE__ */ y("g", {
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ v("rect", {
				x,
				y: te,
				width: _,
				height: b,
				rx: se,
				transform: oe ? "rotate(" + oe + " " + m + " " + h + ")" : void 0,
				fill: T,
				stroke: ae,
				strokeWidth: fn(f ? 2.2 : 1.2, d ? 2.4 : 1.4, i) / r
			}),
			ie && /* @__PURE__ */ y(ee, { children: [
				d && /* @__PURE__ */ v("rect", {
					x,
					y: te,
					width: _,
					height: b,
					fill: tn[d],
					fillOpacity: .22 * a
				}),
				d && /* @__PURE__ */ v("rect", {
					x: d === "us" ? x : x + _ - ne,
					y: te,
					width: ne,
					height: b,
					fill: tn[d],
					opacity: 1 - a
				}),
				/* @__PURE__ */ v("line", {
					x1: m,
					y1: fn(t.y + 3 / r, t.y + 56 + 3 / r, a),
					x2: m,
					y2: t.y + t.h - 3 / r,
					stroke: "#57534e",
					strokeWidth: 1 / r,
					strokeDasharray: 3 / r + " " + 2 / r
				}),
				f && /* @__PURE__ */ v("path", {
					d: "M " + (m - 4 / r) + " " + te + " h " + 8 / r + " l " + -4 / r + " " + 5 / r + " Z",
					fill: "#dbb960",
					stroke: "#27343b",
					strokeWidth: .6 / r,
					opacity: 1 - a
				}),
				/* @__PURE__ */ y("g", {
					opacity: a,
					children: [
						/* @__PURE__ */ v("rect", {
							x: t.x,
							y: t.y,
							width: t.w,
							height: 56,
							fill: f ? Cn.bg : Cn.plain,
							stroke: "#3f3f46",
							strokeWidth: 2 / r
						}),
						/* @__PURE__ */ v("rect", {
							x: t.x + t.w - 56,
							y: t.y,
							width: 56,
							height: 56,
							fill: f ? wn.bg : wn.plain,
							stroke: "#3f3f46",
							strokeWidth: 1.5 / r
						}),
						/* @__PURE__ */ v("text", {
							x: t.x + (t.w - 56) / 2,
							y: t.y + 28,
							fontSize: ue,
							fontWeight: 700,
							textAnchor: "middle",
							dominantBaseline: "central",
							textLength: de,
							lengthAdjust: "spacingAndGlyphs",
							fill: f ? "#ffffff" : "#1c1917",
							children: ce
						}),
						/* @__PURE__ */ v("text", {
							x: t.x + t.w - 28,
							y: t.y + 28,
							fontSize: 40,
							fontWeight: 800,
							textAnchor: "middle",
							dominantBaseline: "central",
							fill: f ? "#ffffff" : "#1c1917",
							children: l.stability
						})
					]
				}),
				s && /* @__PURE__ */ y(ee, { children: [/* @__PURE__ */ v("rect", {
					x: x - 2 / r,
					y: te - 2 / r,
					width: _ + 4 / r,
					height: b + 4 / r,
					fill: "none",
					stroke: "#dbb960",
					strokeWidth: 1.8 / r
				}), /* @__PURE__ */ v("path", {
					d: "M " + (x + _ - 8 / r) + " " + (te - 2 / r) + " h " + 8 / r + " v " + 8 / r + " Z",
					fill: "#dbb960"
				})] }),
				/* @__PURE__ */ y("g", {
					opacity: fe,
					children: [/* @__PURE__ */ v("text", {
						x: t.x + 3 / r,
						y: t.y + 56 + 2 / r,
						fontSize: Math.min(25, 6.5 / r),
						fontWeight: 800,
						dominantBaseline: "hanging",
						fill: tn.us,
						children: c("games.twilightstruggle.sideUsShort")
					}), /* @__PURE__ */ v("text", {
						x: t.x + t.w - 3 / r,
						y: t.y + 56 + 2 / r,
						fontSize: Math.min(25, 6.5 / r),
						fontWeight: 800,
						dominantBaseline: "hanging",
						textAnchor: "end",
						fill: tn.ussr,
						children: c("games.twilightstruggle.sideUssrShort")
					})]
				}),
				/* @__PURE__ */ v("text", {
					x: t.x + t.w * .25,
					y: pe,
					fontSize: re,
					fontWeight: 800,
					textAnchor: "middle",
					dominantBaseline: "central",
					fill: tn.us,
					fillOpacity: u.us === 0 ? .3 : 1,
					stroke: "#ffffff",
					strokeWidth: re * .12,
					strokeOpacity: u.us === 0 ? .3 : 1,
					paintOrder: "stroke",
					children: u.us
				}),
				/* @__PURE__ */ v("text", {
					x: t.x + t.w * .75,
					y: pe,
					fontSize: re,
					fontWeight: 800,
					textAnchor: "middle",
					dominantBaseline: "central",
					fill: tn.ussr,
					fillOpacity: u.ussr === 0 ? .3 : 1,
					stroke: "#ffffff",
					strokeWidth: re * .12,
					strokeOpacity: u.ussr === 0 ? .3 : 1,
					paintOrder: "stroke",
					children: u.ussr
				})
			] }),
			s && !ie && /* @__PURE__ */ v("g", {
				transform: "translate(" + m + " " + h + ") scale(" + 1 / r + ")",
				children: /* @__PURE__ */ v("path", {
					d: "M 5 -8 L 11 -8 L 11 -2 Z",
					fill: "#dbb960",
					stroke: "#14212a",
					strokeWidth: .7
				})
			})
		]
	});
}
//#endregion
//#region src/games/twilightstruggle/action-warning.ts
var kn = [
	4,
	50,
	89
];
function An(e, t, n, r) {
	if (e.over) return [];
	let i = [], a = e.current ?? n, o = (t, n = a, r = e, o = !1) => {
		let s = i.length;
		if (kn.includes(t) && r.defcon <= 2) i.push({
			kind: "nuclear",
			loser: n
		});
		else if (t === 20 && r.defcon <= 2) i.push({
			kind: "nuclearRisk",
			loser: n
		});
		else if ((t === 26 && n === "ussr" || t === 62 && n === "us") && Pn(r, T[n])) i.push({
			kind: "nuclearRisk",
			loser: n
		});
		else if ([
			5,
			45,
			49,
			67
		].includes(t) && r.defcon <= 2) {
			let e = t === 5 || t === 67 ? "ussr" : T[n];
			(t === 45 || r.handCounts[e] > 0) && i.push({
				kind: "nuclearRisk",
				loser: t === 5 || t === 67 ? null : n
			});
		} else if (t === 100 && r.defcon === 2) {
			let e = r.vp + (n === "us" ? -6 : 6);
			i.push({
				kind: "gameEnd",
				winner: e > 0 ? "us" : e < 0 ? "ussr" : null,
				reason: "wargames",
				vp: e
			});
		} else if (C[t]?.scoring) {
			let e = Fn(r, t);
			e && i.push(e);
		}
		if (o) for (let e = s; e < i.length; e++) {
			let t = i[e];
			(t.kind === "nuclear" || t.kind === "nuclearRisk") && (t.kind = "nuclearRisk", t.loser = null);
		}
	};
	switch (r.type) {
		case "headline":
			o(r.card, n);
			for (let e of i) e.kind === "nuclear" && (e.kind = "nuclearRisk");
			break;
		case "play": {
			let a = C[r.card], s = r.mode === "event" || r.mode !== "space" && a.side === T[n];
			if (s && o(r.card, n), r.mode === "coup" && r.first !== "event" && a.side === T[n] && kn.includes(r.card) && e.defcon === 3 && i.push({
				kind: "nuclearRisk",
				loser: n
			}), e.phase === "ar" && e.current === n && e.arDone[n] + 1 >= e.arTotal[n]) {
				let a = (t?.hand ?? []).filter((e) => e !== r.card && e !== r.withCard && C[e].scoring), o = s && e.arDone[n] + 1 < 8 && (r.card === 86 && n === "us" || e.space[T[n]] < 8 && (r.card === 18 && e.space[n] === 7 || r.card === 80 && e.space[n] >= 6 && e.space[n] < e.space[T[n]]));
				a.length && !o && i.push({
					kind: "heldScoring",
					cards: a
				});
			}
			break;
		}
		case "coupAt": {
			let t = e.coup;
			if (!t || t.side !== n) break;
			let s = e.mods.cuban !== null && e.mods.cuban !== n, c = w[r.country]?.battleground && !(n === "us" && e.mods.nuclearSubs);
			s || c && e.defcon <= 2 ? i.push({
				kind: "nuclear",
				loser: a
			}) : e.afterEvent && o(e.afterEvent, a, {
				...e,
				defcon: e.defcon - +!!c
			});
			break;
		}
		case "pickOption": {
			let s = e.pending;
			if (s?.kind !== "option" || s.side !== n) break;
			(s.card === 46 && r.option === "1" || s.card === 45 && r.option === "degrade" && e.defcon <= 2 || s.card === 20 && r.option === "boycott" && e.defcon <= 2) && i.push({
				kind: "nuclear",
				loser: a
			}), s.card === 67 && r.option === "use" && t?.offeredCard && C[t.offeredCard].side === "ussr" && o(t.offeredCard, a, e, a !== "us"), r.option === "event" && t?.offeredCard === s.card && o(s.card, a);
			break;
		}
		case "pickCards": {
			let t = e.pending;
			if (t?.kind !== "cards" || t.side !== n) break;
			t.card === 10 && !r.cards.length && (e.influence.westGermany?.us ?? 0) > 0 && i.push({
				kind: "blockade",
				n: e.influence.westGermany.us
			});
			let s = r.cards[0];
			s && (t.card === 85 || t.card === 49 && C[s].side !== T[a]) && o(s, a, e, t.card === 85 && a !== "us");
			break;
		}
		case "allocateInfluence":
			e.afterEvent && o(e.afterEvent, a, it(e, r.countries).view);
			break;
		case "realignAt":
			e.spending?.opsLeft === 1 && e.afterEvent && o(e.afterEvent);
			break;
		case "finishOps":
			e.afterEvent && o(e.afterEvent);
			break;
		case "passAr": {
			let e = (t?.hand ?? []).filter((e) => C[e].scoring);
			e.length && i.push({
				kind: "heldScoring",
				cards: e
			});
			break;
		}
		case "trapDiscard": {
			if (e.arDone[n] + 1 < e.arTotal[n]) break;
			let a = (t?.hand ?? []).filter((e) => e !== r.card && C[e].scoring);
			a.length && i.push({
				kind: "heldScoring",
				cards: a
			});
			break;
		}
	}
	return i.filter((e, t) => i.findIndex((t) => jn(t) === jn(e)) === t);
}
var jn = (e) => JSON.stringify(e), Mn = (e) => JSON.stringify([
	e.turn,
	e.phase,
	e.current,
	e.arDone
]), Nn = (e, t) => JSON.stringify([e, t]);
function Pn(e, t) {
	let n = e.mods.cuban !== null && e.mods.cuban !== t;
	return !n && (e.defcon > 2 || t === "us" && e.mods.nuclearSubs) ? !1 : D.some((r) => {
		let i = w[r];
		return !(e.influence[r]?.[T[t]] ?? 0) || !n && !i.battleground || e.defcon <= 4 && i.regions.includes("europe") || e.defcon <= 3 && i.regions.includes("asia") || e.defcon <= 2 && i.regions.includes("middleEast") || e.mods.usJapan && r === "japan" || e.mods.nato && i.regions.includes("europe") && !e.mods.natoOff.includes(r) && N(e, r) === "us" ? !1 : !(t === "ussr" && e.mods.reformer && i.regions.includes("europe"));
	});
}
function Fn(e, t) {
	let n = C[t].scoring, r = 0;
	if (n === "southeastAsia") for (let t of E) {
		let n = N(e, t);
		n && (r += (n === "us" ? 1 : -1) * (t === "thailand" ? 2 : 1));
	}
	else {
		let { us: t, ussr: i, usTier: a, ussrTier: o } = Te(e, n);
		if (n === "europe" && (a === "control" || o === "control")) return {
			kind: "gameEnd",
			winner: a === "control" ? "us" : "ussr",
			reason: "scoring",
			vp: e.vp
		};
		let [s, c, l] = ce[n], u = (e) => e === "control" ? l ?? 0 : e === "domination" ? c : e === "presence" ? s : 0;
		r = u(a) + t.bg + t.adj - u(o) - i.bg - i.adj;
	}
	let i = e.vp + r;
	return Math.abs(i) >= 20 ? {
		kind: "gameEnd",
		winner: i > 0 ? "us" : "ussr",
		reason: "scoring",
		vp: i
	} : null;
}
//#endregion
//#region src/games/twilightstruggle/warning-dialog.tsx
function In({ warnings: e, onCancel: t, onConfirm: r }) {
	let a = o(), s = i(null);
	n(() => {
		s.current?.showModal();
	}, []);
	let c = (e) => a(e === "us" ? "games.twilightstruggle.sideUs" : "games.twilightstruggle.sideUssr"), l = (e) => {
		switch (e.kind) {
			case "nuclear": return a("games.twilightstruggle.warningNuclear", { side: c(e.loser) });
			case "nuclearRisk": return e.loser ? a("games.twilightstruggle.warningNuclearRisk", { side: c(e.loser) }) : a("games.twilightstruggle.warningNuclearUncertain");
			case "blockade": return a("games.twilightstruggle.warningBlockade", { n: e.n });
			case "heldScoring": return a("games.twilightstruggle.warningHeldScoring", { cards: e.cards.map((e) => a(`games.twilightstruggle.card.${C[e].key}`)).join(" / ") });
			case "gameEnd": return a(e.reason === "wargames" ? "games.twilightstruggle.warningWargames" : "games.twilightstruggle.warningScoring", { result: e.winner ? a("games.twilightstruggle.warningWinner", { side: c(e.winner) }) : a("games.twilightstruggle.warningDraw") });
		}
	};
	return /* @__PURE__ */ y("dialog", {
		ref: s,
		"aria-labelledby": "ts-warning-title",
		className: "m-auto max-h-[85%] w-[calc(100%-2rem)] max-w-sm overflow-y-auto rounded-lg border-2 border-amber-700 bg-amber-50 p-4 text-stone-900 shadow-xl backdrop:bg-ink/50",
		onCancel: (e) => {
			e.preventDefault(), t();
		},
		children: [
			/* @__PURE__ */ v("h2", {
				id: "ts-warning-title",
				className: "mb-3 font-display text-lg font-extrabold",
				children: a("games.twilightstruggle.warningTitle")
			}),
			/* @__PURE__ */ v("div", {
				className: "space-y-3 text-sm",
				children: e.map((e, t) => /* @__PURE__ */ v("p", { children: l(e) }, t))
			}),
			/* @__PURE__ */ y("div", {
				className: "mt-4 flex gap-2",
				children: [/* @__PURE__ */ v("button", {
					type: "button",
					className: "btn-quiet min-h-11 flex-1",
					autoFocus: !0,
					onClick: t,
					children: a("games.twilightstruggle.warningCancel")
				}), /* @__PURE__ */ v("button", {
					type: "button",
					className: "btn-base min-h-12 flex-1 bg-danger text-white",
					onClick: r,
					children: a("games.twilightstruggle.warningProceed")
				})]
			})
		]
	});
}
//#endregion
//#region src/games/twilightstruggle/tracks.tsx
function Ln({ defcon: e }) {
	let t = o();
	return /* @__PURE__ */ y("div", {
		className: "ts-meter ts-meter-defcon",
		children: [
			/* @__PURE__ */ v("span", {
				className: "ts-meter-kicker",
				children: "DEFCON"
			}),
			/* @__PURE__ */ y("div", {
				className: "ts-meter-reading",
				children: [/* @__PURE__ */ v("strong", { children: e }), /* @__PURE__ */ v("span", { children: t("games.twilightstruggle.defconAlert") })]
			}),
			/* @__PURE__ */ v("div", {
				className: "ts-defcon-steps",
				"aria-label": t("games.twilightstruggle.defconLabel"),
				children: [
					5,
					4,
					3,
					2,
					1
				].map((t) => /* @__PURE__ */ v("span", {
					className: t === e ? "is-current" : "",
					children: t
				}, t))
			})
		]
	});
}
function Rn({ vp: e }) {
	let t = o(), n = e > 0 ? "us" : e < 0 ? "ussr" : null, r = Math.max(0, Math.min(100, (e + 20) / 40 * 100));
	return /* @__PURE__ */ y("div", {
		className: "ts-meter ts-meter-vp",
		children: [
			/* @__PURE__ */ v("span", {
				className: "ts-meter-kicker",
				children: t("games.twilightstruggle.vpLabel")
			}),
			/* @__PURE__ */ y("div", {
				className: "ts-meter-reading",
				children: [/* @__PURE__ */ v("strong", { children: e > 0 ? `+${e}` : e }), /* @__PURE__ */ v("span", { children: n ? t(n === "us" ? "games.twilightstruggle.sideUs" : "games.twilightstruggle.sideUssr") : "0" })]
			}),
			/* @__PURE__ */ v("div", {
				className: "ts-vp-scale",
				children: /* @__PURE__ */ v("span", {
					className: "ts-vp-pointer",
					style: { left: `${r}%` }
				})
			}),
			/* @__PURE__ */ y("div", {
				className: "ts-vp-ends",
				children: [/* @__PURE__ */ v("span", { children: "−20" }), /* @__PURE__ */ v("span", { children: "+20" })]
			})
		]
	});
}
var zn = [
	"games.twilightstruggle.spaceTrack.s1",
	"games.twilightstruggle.spaceTrack.s2",
	"games.twilightstruggle.spaceTrack.s3",
	"games.twilightstruggle.spaceTrack.s4",
	"games.twilightstruggle.spaceTrack.s5",
	"games.twilightstruggle.spaceTrack.s6",
	"games.twilightstruggle.spaceTrack.s7",
	"games.twilightstruggle.spaceTrack.s8"
];
function Bn({ space: e, onOpen: t }) {
	let n = o();
	return /* @__PURE__ */ y("div", {
		className: "ts-space-track",
		children: [/* @__PURE__ */ v("button", {
			type: "button",
			className: "ts-track-title ts-track-open",
			onClick: t,
			"aria-label": n("games.twilightstruggle.spaceDetailsTitle"),
			children: n("games.twilightstruggle.spaceLabel")
		}), /* @__PURE__ */ v("span", {
			className: "ts-space-cells",
			children: Array.from({ length: 8 }, (e, t) => t + 1).map((t) => /* @__PURE__ */ y("span", {
				className: "ts-space-cell",
				title: n(zn[t - 1]),
				children: [/* @__PURE__ */ y("span", { children: [
					se(t - 1),
					"/",
					ae[t - 1]
				] }), /* @__PURE__ */ y("span", {
					className: "ts-space-dots",
					children: [/* @__PURE__ */ v("i", { className: e.us >= t ? "is-us" : "" }), /* @__PURE__ */ v("i", { className: e.ussr >= t ? "is-ussr" : "" })]
				})]
			}, t))
		})]
	});
}
var Vn = {
	2: "games.twilightstruggle.spaceBonus2",
	4: "games.twilightstruggle.spaceBonus4",
	6: "games.twilightstruggle.spaceBonus6",
	8: "games.twilightstruggle.spaceBonus8"
};
function Hn({ space: e }) {
	let t = o();
	return /* @__PURE__ */ y("div", {
		className: "ts-space-detail-list",
		children: [/* @__PURE__ */ v("p", {
			className: "ts-space-detail-note",
			children: t("games.twilightstruggle.spaceBonusRule")
		}), Array.from({ length: 8 }, (e, t) => t + 1).map((n) => {
			let [r, i] = oe[n - 1], a = Vn[n];
			return /* @__PURE__ */ y("div", {
				className: "ts-space-detail-row",
				children: [
					/* @__PURE__ */ y("div", {
						className: "ts-space-detail-heading",
						children: [/* @__PURE__ */ y("strong", { children: [
							n,
							". ",
							t(zn[n - 1])
						] }), /* @__PURE__ */ y("span", { children: [
							e.us >= n && t("games.twilightstruggle.sideUsShort"),
							" ",
							e.ussr >= n && t("games.twilightstruggle.sideUssrShort")
						] })]
					}),
					/* @__PURE__ */ v("div", { children: t("games.twilightstruggle.spaceStepReq", {
						ops: se(n - 1),
						roll: ae[n - 1]
					}) }),
					/* @__PURE__ */ v("div", { children: t("games.twilightstruggle.spaceStepVp", {
						first: r,
						second: i
					}) }),
					a && /* @__PURE__ */ v("div", {
						className: "ts-space-detail-bonus",
						children: t(a)
					})
				]
			}, n);
		})]
	});
}
function Un({ milops: e, defcon: t }) {
	let n = o(), r = (r) => /* @__PURE__ */ y("span", {
		className: `ts-milops-row ts-milops-${r}`,
		children: [
			/* @__PURE__ */ v("b", { children: n(r === "us" ? "games.twilightstruggle.sideUsShort" : "games.twilightstruggle.sideUssrShort") }),
			/* @__PURE__ */ v("span", {
				className: "ts-milops-cells",
				children: Array.from({ length: 5 }, (n, i) => /* @__PURE__ */ v("i", { className: i < e[r] ? "is-filled" : i < t ? "is-required" : "" }, i))
			}),
			/* @__PURE__ */ y("span", { children: [
				e[r],
				"/",
				t
			] })
		]
	});
	return /* @__PURE__ */ y("div", {
		className: "ts-milops-track",
		title: n("games.twilightstruggle.milopsReq", { n: t }),
		children: [
			/* @__PURE__ */ v("span", {
				className: "ts-track-title",
				children: n("games.twilightstruggle.milopsLabel")
			}),
			r("us"),
			r("ussr")
		]
	});
}
//#endregion
//#region src/games/twilightstruggle/view-player.tsx
var Wn = {
	us: { num: "text-blue-700" },
	ussr: { num: "text-red-700" }
}, Gn = {
	us: "text-blue-700",
	ussr: "text-red-700",
	both: "text-amber-700"
}, Kn = {
	cuba: "games.twilightstruggle.country.cuba",
	westGermany: "games.twilightstruggle.country.westGermany",
	turkey: "games.twilightstruggle.country.turkey"
}, qn = [
	"westernEurope",
	"easternEurope",
	"middleEast",
	"asia",
	"southeastAsia",
	"africa",
	"centralAmerica",
	"southAmerica"
];
function Jn(e) {
	let t = w[e].regions;
	return t.includes("westernEurope") ? "westernEurope" : t.includes("easternEurope") ? "easternEurope" : t.includes("southeastAsia") ? "southeastAsia" : t[0];
}
function Yn(e, t, n) {
	let r = 0;
	return e.mods.opsPlus === t && (r += 1), e.mods.opsMinus === t && --r, Math.min(4, Math.max(1, n + r));
}
var Xn = {
	event: "games.twilightstruggle.modeEvent",
	influence: "games.twilightstruggle.modeInfluence",
	realign: "games.twilightstruggle.modeRealign",
	coup: "games.twilightstruggle.modeCoup",
	space: "games.twilightstruggle.modeSpace",
	remove: "games.twilightstruggle.optRemoveUs",
	add: "games.twilightstruggle.optAddUssr",
	participate: "games.twilightstruggle.participate",
	boycott: "games.twilightstruggle.boycott",
	improve: "games.twilightstruggle.optImprove",
	noChange: "games.twilightstruggle.optNoChange",
	degrade: "games.twilightstruggle.optDegrade",
	use: "games.twilightstruggle.playIt",
	return: "games.twilightstruggle.returnIt",
	un: "games.twilightstruggle.optUn",
	sa2: "games.twilightstruggle.sa2",
	sa1ang2: "games.twilightstruggle.sa1ang2",
	sa1bot2: "games.twilightstruggle.sa1bot2",
	sa1ang1bot1: "games.twilightstruggle.sa1ang1bot1"
};
function Zn(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ v($n, {
		pub: t,
		priv: n,
		myRid: e.myRid,
		send: e.send
	});
}
function Qn({ pub: e, priv: t, myRid: n, onShowResult: r }) {
	return /* @__PURE__ */ v($n, {
		pub: e,
		priv: t,
		myRid: n,
		send: () => {},
		onShowResult: r
	});
}
function $n({ pub: e, priv: t, myRid: r, send: s, onShowResult: d }) {
	let p = o(), m = e.seats.us === r ? "us" : e.seats.ussr === r ? "ussr" : null, [_, b] = a(null), [x, te] = a("ops"), [ne, S] = a(!1), [w, re] = a([]), [ie, ae] = a(null), [oe, se] = a(!1), [ce, le] = a(!1), [E, ue] = a(null), [de, fe] = a(!1), [pe, O] = a(!1), [k, me] = a(null), [A, j] = a(""), M = i(null), [N, P] = a(0);
	n(() => {
		let e = M.current;
		if (!e) return;
		let t = new ResizeObserver(() => P(e.getBoundingClientRect().height));
		return t.observe(e), () => t.disconnect();
	}, []);
	let [he, F] = a({
		context: "",
		countries: [],
		submitted: !1
	}), [I, ge] = a({
		context: "",
		countries: [],
		removals: [],
		redistributing: !1,
		submitted: !1
	}), [_e, L] = a(null), ve = Mn(e), [ye, be] = a({
		round: ve,
		keys: []
	});
	ye.round !== ve && be({
		round: ve,
		keys: []
	}), _e && _e.context !== Nn(e, t) && L(null);
	let R = (n, r) => {
		let i = ye.round === ve ? ye.keys : [], a = m ? An(e, t, m, n).filter((e) => !i.includes(jn(e))) : [];
		a.length ? L({
			action: n,
			warnings: a,
			context: Nn(e, t),
			onSent: r
		}) : (s(n), r?.());
	}, xe = ir(e), Se = t?.hand ?? [], z = e.over !== null, Ce = !z && m !== null && e.current === m && e.phase === "ar", B = z ? null : e.pending, we = B !== null || e.spending !== null || e.coup !== null, Te = Ce && !we, Ee = !z && e.phase !== "setup" && m !== null && e.mods.cuban !== null && e.mods.cuban !== m, De = Ee && m ? JSON.stringify([
		e.turn,
		m,
		e.mods.cuban,
		ct[m].map((t) => e.influence[t]?.[m] ?? 0)
	]) : "";
	k && k.context !== De && me(null);
	let Oe = B?.side === m && B.kind === "option" ? t?.offeredCard ?? null : null, ke = Oe === null ? null : C[Oe], Ae = m !== null && !!e.headline && (m === "us" ? e.headline.usReady : e.headline.ussrReady), je = !z && e.spending?.mode === "influence" && e.spending.side === m, Me = je ? rt(e) : "";
	he.context !== Me && (je && he.countries.length > 0 && !he.submitted && j(Me), F({
		context: Me,
		countries: [],
		submitted: !1
	}));
	let Ne = he.context === Me ? he.countries : [], Pe = he.context === Me && he.submitted, Fe = it(e, Ne), Ie = !z && m !== null && (e.phase === "setup" && e.setup?.step === m || B?.kind === "countries" && B.side === m && B.mode !== "war"), Le = Ie ? ot(e) : "";
	I.context !== Le && (Ie && (I.countries.length > 0 || I.removals.length > 0) && !I.submitted && j(Le), ge({
		context: Le,
		countries: [],
		removals: [],
		redistributing: !1,
		submitted: !1
	}));
	let V = I.context === Le ? I : {
		context: Le,
		countries: [],
		removals: [],
		redistributing: !1,
		submitted: !1
	}, H = st(e, V.countries, V.removals, V.redistributing), Re = H.destal && !V.redistributing, ze = Re ? V.removals : V.countries, Be = Ie ? H.view : je ? Fe.view : e, Ve = (() => {
		let t = /* @__PURE__ */ new Map();
		if (!m || z) return t;
		if (Ie) {
			if (!V.submitted) for (let n of H.targets) t.set(n, e.phase === "setup" ? "setup" : "pending");
			return t;
		}
		if (e.phase === "setup" && e.setup?.step === m) {
			for (let n of at(m, e.setup.left, e.usBonus, e.influence)) t.set(n, "setup");
			return t;
		}
		let n = e.spending;
		if (n && n.side === m) {
			if (n.mode === "influence") {
				if (!Pe) for (let e of Fe.targets) t.set(e, "place");
				return t;
			}
			for (let r of D) (!n.restricted || n.restricted.includes(r)) && (e.influence[r] ?? {
				us: 0,
				ussr: 0
			})[T[m]] !== 0 && t.set(r, "realign");
			return t;
		}
		if (e.coup && e.coup.side === m) {
			for (let n of D) (!e.coup.restricted || e.coup.restricted.includes(n)) && (e.influence[n] ?? {
				us: 0,
				ussr: 0
			})[T[m]] !== 0 && t.set(n, "coup");
			return t;
		}
		if (e.pending?.kind === "countries" && e.pending.side === m) for (let n of e.pending.pool) t.set(n, "pending");
		return t;
	})(), He = (e) => {
		let t = Ve.get(e);
		if (t) {
			j(""), Ie ? ge({
				...V,
				[Re ? "removals" : "countries"]: [...ze, e]
			}) : t === "setup" ? R({
				type: "setupPlace",
				country: e
			}) : t === "place" ? F({
				context: Me,
				countries: [...Ne, e],
				submitted: !1
			}) : R(t === "realign" ? {
				type: "realignAt",
				country: e
			} : t === "coup" ? {
				type: "coupAt",
				country: e
			} : {
				type: "pickCountries",
				countries: [e]
			});
			return;
		}
	}, U = _ ?? null, W = U === null ? null : C[U], Ue = U === 6, We = U !== null && (Se.includes(U) || Ue && e.china.holder === m), Ge = !!W && W.side === T[m ?? "us"] && !W.scoring && !nr(e, m ?? "us", U), Ke = m ? e.mustOps[m] : null, G = e.trapNow && Ce, qe = (t) => !C[t].scoring && Yn(e, m, C[t].ops) >= 2, Je = (e) => {
		if (!(U === null || !We || Ue && !t?.chinaReady)) {
			if (U === 32 && e === "event") {
				S(!0);
				return;
			}
			R({
				type: "play",
				card: U,
				mode: e,
				first: Ge && e !== "event" ? x : void 0
			}, () => {
				b(null), te("ops");
			});
		}
	}, Ye = /* @__PURE__ */ y("div", {
		className: "ts-dashboard",
		children: [
			/* @__PURE__ */ y("div", {
				className: `ts-command ${Ee ? "is-cuban" : ""}`,
				children: [
					Ee ? /* @__PURE__ */ v("button", {
						type: "button",
						className: "ts-cuban-trigger min-h-11",
						onClick: () => {
							me({
								context: De,
								country: null,
								submitted: !1
							});
						},
						children: p("games.twilightstruggle.cancelCubanShort")
					}) : /* @__PURE__ */ v("div", {
						className: "ts-command-title",
						children: p("games.twilightstruggle.name")
					}),
					/* @__PURE__ */ y("div", {
						className: "ts-command-line",
						children: [
							!z && e.phase === "ar" && e.current && /* @__PURE__ */ y("strong", {
								className: "ts-ar-indicator",
								children: [
									p("games.twilightstruggle.arLabel", { n: e.arDone[e.current] + 1 }),
									"/",
									e.arTotal[e.current]
								]
							}),
							m && /* @__PURE__ */ v("span", { children: p("games.twilightstruggle.youAre", { side: p(m === "us" ? "games.twilightstruggle.sideUs" : "games.twilightstruggle.sideUssr") }) }),
							/* @__PURE__ */ v("span", { children: p("games.twilightstruggle.turnLabel", { n: e.turn }) }),
							!z && e.phase === "ar" && e.current && /* @__PURE__ */ v("span", { children: p(e.current === "us" ? "games.twilightstruggle.sideUs" : "games.twilightstruggle.sideUssr") })
						]
					}),
					/* @__PURE__ */ y("div", {
						className: "ts-command-phase",
						children: [
							!z && e.phase === "setup" && (e.setup?.step === m ? m === "us" && e.usBonus > 0 && H.remaining <= e.usBonus ? p("games.twilightstruggle.phaseSetupPlaceBonus", {
								n: H.remaining,
								bonus: e.usBonus
							}) : p("games.twilightstruggle.phaseSetupPlace", { n: H.remaining - (m === "us" ? e.usBonus : 0) }) : p("games.twilightstruggle.phaseSetupWait")),
							!z && e.phase === "headline" && p(Ae ? "games.twilightstruggle.phaseHeadlineWait" : "games.twilightstruggle.phaseHeadline"),
							!z && e.phase === "ar" && (G ? p("games.twilightstruggle.phaseTrap", { card: p("games.twilightstruggle.card.quagmire") }) : p(Ce ? "games.twilightstruggle.phaseAR" : "games.twilightstruggle.phaseARWait")),
							!z && (e.phase === "turnEnd" || e.phase === "final") && p("games.twilightstruggle.phaseTurnEnd"),
							z && p("games.twilightstruggle.phaseGameOver")
						]
					}),
					d && /* @__PURE__ */ v("button", {
						type: "button",
						className: "ts-final-result-btn",
						"aria-label": p("games.twilightstruggle.viewResults"),
						onClick: d,
						children: p("games.twilightstruggle.viewResultsShort")
					})
				]
			}),
			/* @__PURE__ */ y("div", {
				className: "ts-core-metrics",
				children: [
					/* @__PURE__ */ v(Ln, { defcon: e.defcon }),
					/* @__PURE__ */ v(Rn, { vp: e.vp }),
					/* @__PURE__ */ y("div", {
						className: "ts-meter ts-meter-china",
						children: [/* @__PURE__ */ v("span", {
							className: "ts-meter-kicker",
							children: p("games.twilightstruggle.chinaCardLabel")
						}), /* @__PURE__ */ y("div", {
							className: "ts-meter-reading",
							children: [/* @__PURE__ */ v("strong", { children: e.china.holder === null ? "—" : p(e.china.holder === "us" ? "games.twilightstruggle.sideUsShort" : "games.twilightstruggle.sideUssrShort") }), /* @__PURE__ */ v("span", { children: e.china.holder === null ? p("games.twilightstruggle.chinaUnclaimed") : e.china.faceUp ? p("games.twilightstruggle.chinaFaceUp") : p("games.twilightstruggle.chinaFaceDownShort") })]
						})]
					})
				]
			}),
			/* @__PURE__ */ y("div", {
				className: "ts-secondary-tracks",
				children: [/* @__PURE__ */ v(Bn, {
					space: e.space,
					onOpen: () => fe(!0)
				}), /* @__PURE__ */ v(Un, {
					milops: e.milops,
					defcon: e.defcon
				})]
			})
		]
	}), Xe = /* @__PURE__ */ y("div", {
		className: "relative h-full",
		children: [
			/* @__PURE__ */ v(xn, {
				pub: Be,
				tap: Ve,
				focus: ie,
				onTapCountry: He,
				onOpenList: () => se(!0)
			}),
			t?.oppHand && !(W && We) && /* @__PURE__ */ y("div", {
				className: "ts-task ts-task-intel ts-opponent-hand pointer-events-auto px-2 py-1",
				children: [/* @__PURE__ */ v("div", {
					className: "text-xs opacity-70",
					children: p("games.twilightstruggle.oppHandRevealed")
				}), /* @__PURE__ */ v("div", {
					className: "flex gap-1 overflow-x-auto",
					children: t.oppHand.map((e) => /* @__PURE__ */ v(Cr, {
						id: e,
						onOpen: () => ue(e)
					}, e))
				})]
			}),
			/* @__PURE__ */ v("button", {
				type: "button",
				className: `ts-effects-trigger absolute right-3 z-20 min-h-11 px-2 ${Ie ? "bottom-[144px]" : je ? "bottom-[108px]" : "bottom-3"}`,
				onClick: () => O(!0),
				children: p("games.twilightstruggle.effectsButton", { n: xe.turn.length + xe.lasting.length })
			}),
			oe && /* @__PURE__ */ y("div", {
				className: "ts-index absolute inset-0 z-20 flex flex-col",
				children: [/* @__PURE__ */ y("div", {
					className: "ts-index-head flex flex-none items-center justify-between px-3 py-1",
					children: [/* @__PURE__ */ v("span", { children: p("games.twilightstruggle.listOpen") }), /* @__PURE__ */ v("button", {
						className: "ts-index-close flex h-11 w-11 items-center justify-center",
						onClick: () => se(!1),
						"aria-label": p("games.twilightstruggle.close"),
						children: /* @__PURE__ */ v(l, { className: "h-5 w-5" })
					})]
				}), /* @__PURE__ */ v("div", {
					className: "ts-index-scroll min-h-0 flex-1 overflow-y-auto px-2 pb-2",
					children: qn.map((e) => /* @__PURE__ */ v(Sr, {
						region: e,
						pub: Be,
						tap: Ve,
						onTap: (e) => {
							se(!1), ae((t) => ({
								country: e,
								seq: (t?.seq ?? 0) + 1
							}));
						}
					}, e))
				})]
			})
		]
	}), Ze = /* @__PURE__ */ y("div", {
		ref: M,
		className: "ts-overlays pointer-events-none flex flex-col gap-1 px-1 pb-1",
		children: [!(W && We) && /* @__PURE__ */ y(ee, { children: [
			t?.headlineOpp != null && /* @__PURE__ */ v("div", {
				className: "ts-task ts-task-intel pointer-events-auto px-2 py-1 text-sm",
				children: p("games.twilightstruggle.headlineOppSeen", { card: p(er(t.headlineOpp)) })
			}),
			B?.side === m && B.kind === "option" && /* @__PURE__ */ y("div", {
				className: "ts-task ts-option-task pointer-events-auto px-3 py-2",
				children: [ke && Oe !== null && /* @__PURE__ */ y("div", {
					className: "ts-offered-card",
					children: [
						/* @__PURE__ */ v("div", {
							className: "text-xs font-bold",
							children: p("games.twilightstruggle.grainDrawnCard")
						}),
						/* @__PURE__ */ y("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ v("span", {
								className: `ts-dossier-ops font-mono tabular-nums ${Gn[ke.scoring ? "both" : ke.side]}`,
								children: ke.scoring ? "★" : ke.ops
							}), /* @__PURE__ */ y("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ v("button", {
									type: "button",
									className: "min-h-11 px-2",
									onClick: () => ue(Oe),
									children: p(er(Oe))
								}), /* @__PURE__ */ v("div", {
									className: "text-xs",
									children: p(ke.scoring ? "games.twilightstruggle.sideTagScoring" : ke.side === "us" ? "games.twilightstruggle.sideTagUs" : ke.side === "ussr" ? "games.twilightstruggle.sideTagUssr" : "games.twilightstruggle.sideTagBoth")
								})]
							})]
						}),
						/* @__PURE__ */ v("div", {
							className: "ts-offered-copy",
							children: p(`games.twilightstruggle.cardText.${ke.key}`)
						})
					]
				}), /* @__PURE__ */ v("div", {
					className: "ts-option-actions flex flex-wrap gap-2",
					children: B.options.map((e) => /* @__PURE__ */ v("button", {
						className: "btn-base min-h-11 px-4",
						onClick: () => R({
							type: "pickOption",
							option: e
						}),
						children: vr(p, e)
					}, e))
				})]
			}),
			B?.side === m && B.kind === "cards" && t?.pendingPool && /* @__PURE__ */ y("div", {
				className: "ts-task ts-task-card-choice pointer-events-auto px-3 py-2",
				children: [
					/* @__PURE__ */ y("div", {
						className: "mb-1 text-sm",
						children: [p("games.twilightstruggle.chooseCardsFree", { n: B.max }), /* @__PURE__ */ v("span", {
							className: "ml-2 opacity-70",
							children: p("games.twilightstruggle.cardsSelectedN", { n: w.length })
						})]
					}),
					/* @__PURE__ */ v("div", {
						className: "ts-task-card-pool flex flex-col gap-1",
						children: t.pendingPool.map((e) => /* @__PURE__ */ y("div", {
							className: "flex flex-none gap-1",
							children: [/* @__PURE__ */ y("button", {
								type: "button",
								className: `ts-card-pick min-h-11 ${w.includes(e) ? "is-selected" : ""}`,
								"aria-pressed": w.includes(e),
								onClick: () => re((t) => t.includes(e) ? t.filter((t) => t !== e) : t.length < B.max ? [...t, e] : t),
								children: [/* @__PURE__ */ v("span", {
									className: "ts-card-pick-mark",
									"aria-hidden": "true",
									children: w.includes(e) && /* @__PURE__ */ v(c, { size: 14 })
								}), p(er(e))]
							}), /* @__PURE__ */ v("button", {
								type: "button",
								className: "ts-card-pick-detail flex min-h-11 w-11 flex-none items-center justify-center",
								"aria-label": p("games.twilightstruggle.cardDetails", { card: p(er(e)) }),
								onClick: () => ue(e),
								children: /* @__PURE__ */ v(u, { size: 18 })
							})]
						}, e))
					}),
					/* @__PURE__ */ v("button", {
						className: "btn-base mt-2 min-h-11 w-full",
						disabled: w.length < B.min,
						onClick: () => R({
							type: "pickCards",
							cards: w
						}, () => re([])),
						children: p("games.twilightstruggle.confirm")
					})
				]
			}),
			B?.side === m && B.kind === "countries" && !Ie && /* @__PURE__ */ y("div", {
				className: "ts-task pointer-events-auto flex items-center justify-between px-3 py-2 text-sm",
				children: [/* @__PURE__ */ v("span", { children: yr(p, B) }), !B.exact && /* @__PURE__ */ v("button", {
					className: "btn-quiet min-h-11 px-4",
					onClick: () => R({
						type: "pickCountries",
						countries: []
					}),
					children: p("games.twilightstruggle.confirm")
				})]
			}),
			Ie && /* @__PURE__ */ y("div", {
				className: "ts-task pointer-events-auto px-3 py-2 text-sm",
				children: [
					A === Le && /* @__PURE__ */ v("p", {
						role: "status",
						className: "ts-draft-reset",
						children: p("games.twilightstruggle.draftReset")
					}),
					/* @__PURE__ */ v("div", {
						className: "flex items-center justify-between gap-1",
						children: /* @__PURE__ */ v("span", { children: p(V.submitted ? "games.twilightstruggle.submittingInfluence" : Re ? "games.twilightstruggle.draftDestalRemove" : H.destal ? "games.twilightstruggle.draftDestalAdd" : e.phase === "setup" ? "games.twilightstruggle.draftSetup" : "games.twilightstruggle.draftEvent") })
					}),
					/* @__PURE__ */ y("div", {
						className: "flex items-center justify-between gap-1 text-xs",
						children: [/* @__PURE__ */ v("span", { children: H.view.pending?.kind === "countries" ? yr(p, H.view.pending) : p("games.twilightstruggle.draftPointsLeft", { n: H.remaining }) }), H.destal && V.redistributing && /* @__PURE__ */ v("button", {
							className: "btn-quiet min-h-11 px-2",
							disabled: V.submitted,
							onClick: () => ge({
								...V,
								countries: [],
								redistributing: !1
							}),
							children: p("games.twilightstruggle.backToRemoval")
						})]
					}),
					/* @__PURE__ */ y("div", {
						className: "mt-1 flex gap-2",
						children: [/* @__PURE__ */ v("button", {
							className: "btn-quiet min-h-11 flex-1 px-2",
							disabled: V.submitted || ze.length === 0,
							onClick: () => ge({
								...V,
								[Re ? "removals" : "countries"]: ze.slice(0, -1)
							}),
							children: p("games.twilightstruggle.undoChoice")
						}), /* @__PURE__ */ v("button", {
							className: "btn-base min-h-11 flex-1 px-2",
							disabled: V.submitted || !H.valid || !Re && !H.complete,
							onClick: () => {
								if (Re) {
									ge({
										...V,
										redistributing: !0
									});
									return;
								}
								let t = e.phase === "setup" ? {
									type: "allocateSetup",
									context: Le,
									countries: V.countries
								} : {
									type: "allocateCountries",
									context: Le,
									countries: V.countries,
									removals: H.destal ? V.removals : void 0
								};
								R(t, () => ge({
									...V,
									submitted: !0
								}));
							},
							children: p(Re ? "games.twilightstruggle.continueRedistribution" : "games.twilightstruggle.confirmInfluence")
						})]
					})
				]
			}),
			je && /* @__PURE__ */ y("div", {
				className: "ts-task pointer-events-auto px-3 py-2 text-sm",
				children: [
					A === Me && /* @__PURE__ */ v("p", {
						role: "status",
						className: "ts-draft-reset",
						children: p("games.twilightstruggle.draftReset")
					}),
					/* @__PURE__ */ y("div", {
						className: "flex flex-wrap items-center justify-between gap-1",
						children: [/* @__PURE__ */ v("span", { children: p(Pe ? "games.twilightstruggle.submittingInfluence" : "games.twilightstruggle.influenceDraft") }), /* @__PURE__ */ v("span", {
							className: "font-mono tabular-nums",
							children: p("games.twilightstruggle.opsLeft", { n: Math.max(0, Fe.view.spending?.opsLeft ?? 0) })
						})]
					}),
					/* @__PURE__ */ y("div", {
						className: "mt-1 flex gap-2",
						children: [/* @__PURE__ */ v("button", {
							className: "btn-quiet min-h-11 flex-1 px-2",
							disabled: Pe || Ne.length === 0,
							onClick: () => F({
								context: Me,
								countries: Ne.slice(0, -1),
								submitted: !1
							}),
							children: p("games.twilightstruggle.undoInfluence")
						}), /* @__PURE__ */ v("button", {
							className: "btn-base min-h-11 flex-1 px-2",
							disabled: Pe || !Fe.valid || !Fe.complete,
							onClick: () => {
								R({
									type: "allocateInfluence",
									context: Me,
									countries: Ne
								}, () => {
									F({
										context: Me,
										countries: Ne,
										submitted: !0
									});
								});
							},
							children: p("games.twilightstruggle.confirmInfluence")
						})]
					})
				]
			}),
			Ce && e.spending?.side === m && e.spending.mode === "realign" && /* @__PURE__ */ y("div", {
				className: "ts-task pointer-events-auto flex items-center justify-between px-3 py-2 text-sm",
				children: [/* @__PURE__ */ v("span", { children: p("games.twilightstruggle.opsLeft", { n: e.spending.opsLeft }) }), e.spending.mode === "realign" && /* @__PURE__ */ v("button", {
					className: "btn-quiet min-h-11 px-4",
					onClick: () => R({ type: "finishOps" }),
					children: p("games.twilightstruggle.finishRealign")
				})]
			}),
			Ce && e.coup?.free && e.coup.side === m && /* @__PURE__ */ y("div", {
				className: "ts-task pointer-events-auto flex items-center justify-between px-3 py-2 text-sm",
				children: [/* @__PURE__ */ v("span", { children: p("games.twilightstruggle.chooseCountryOne") }), /* @__PURE__ */ v("button", {
					className: "btn-quiet min-h-11 px-4",
					onClick: () => R({ type: "finishOps" }),
					children: p("games.twilightstruggle.cancel")
				})]
			}),
			Te && m && xr(e, m, Se, t) && /* @__PURE__ */ v("div", {
				className: "ts-task pointer-events-auto px-3 py-2",
				children: /* @__PURE__ */ v("button", {
					className: "btn-quiet min-h-11 px-4",
					onClick: () => R({ type: "passAr" }),
					children: p("games.twilightstruggle.passAr")
				})
			})
		] }), W && We && /* @__PURE__ */ y("div", {
			className: "ts-dossier pointer-events-auto",
			children: [
				/* @__PURE__ */ y("div", {
					className: "ts-dossier-head",
					children: [
						/* @__PURE__ */ v("span", {
							className: `ts-dossier-ops font-mono tabular-nums ${Ue ? "text-amber-800" : Gn[W.scoring ? "both" : W.side]}`,
							children: W.scoring ? "★" : Ue ? 4 : m ? Yn(e, m, W.ops) : W.ops
						}),
						/* @__PURE__ */ y("div", {
							className: "ts-dossier-heading",
							children: [
								/* @__PURE__ */ v("div", {
									className: "ts-dossier-title",
									children: p(er(U))
								}),
								/* @__PURE__ */ v("div", {
									className: "ts-dossier-side",
									children: Ue ? p("games.twilightstruggle.chinaCard") : W.scoring ? p("games.twilightstruggle.sideTagScoring") : p(W.side === "us" ? "games.twilightstruggle.sideTagUs" : W.side === "ussr" ? "games.twilightstruggle.sideTagUssr" : "games.twilightstruggle.sideTagBoth")
								}),
								/* @__PURE__ */ v("div", {
									className: "ts-dossier-fate",
									children: p(tr(U))
								})
							]
						}),
						/* @__PURE__ */ v("button", {
							className: "ts-dossier-close flex h-11 w-11 flex-none items-center justify-center",
							onClick: () => {
								b(null), S(!1);
							},
							"aria-label": p("games.twilightstruggle.close"),
							children: /* @__PURE__ */ v(l, { className: "h-4 w-4" })
						})
					]
				}),
				/* @__PURE__ */ v("div", {
					className: "ts-dossier-copy",
					children: p(`games.twilightstruggle.cardText.${C[U].key}`)
				}),
				/* @__PURE__ */ y("div", {
					className: "ts-dossier-actions",
					children: [
						ne && /* @__PURE__ */ y("div", {
							className: "mt-1 flex items-center gap-2 text-sm",
							children: [/* @__PURE__ */ v("span", {
								className: "flex-1",
								children: p("games.twilightstruggle.cardText.unIntervention")
							}), /* @__PURE__ */ v("button", {
								className: "btn-quiet min-h-11 px-3",
								onClick: () => S(!1),
								children: p("games.twilightstruggle.cancel")
							})]
						}),
						!z && !ne && e.phase === "headline" && !Ae && !Ue && /* @__PURE__ */ v("div", {
							className: "mt-1 flex gap-2",
							children: /* @__PURE__ */ v("button", {
								className: "btn-base min-h-11 flex-1",
								disabled: W.noHeadline === !0 || nr(e, m, U),
								onClick: () => R({
									type: "headline",
									card: U
								}, () => b(null)),
								children: p("games.twilightstruggle.playHeadline")
							})
						}),
						!ne && G && /* @__PURE__ */ y("div", {
							className: "mt-1 flex gap-2",
							children: [qe(U) && /* @__PURE__ */ v("button", {
								className: "btn-base min-h-11 flex-1",
								onClick: () => R({
									type: "trapDiscard",
									card: U
								}, () => b(null)),
								children: p("games.twilightstruggle.trapDiscardAction")
							}), W.scoring && /* @__PURE__ */ v("button", {
								className: "btn-base min-h-11 flex-1",
								onClick: () => R({
									type: "play",
									card: U,
									mode: "event"
								}, () => b(null)),
								children: p("games.twilightstruggle.modeEvent")
							})]
						}),
						!ne && Te && (!Ue || !!t?.chinaReady) && !G && (Ke === null || U === Ke) && /* @__PURE__ */ y("div", {
							className: "ts-dossier-action-grid",
							children: [
								(!W.scoring && !Ue && W.side !== T[m] && !nr(e, m, U) || W.scoring) && /* @__PURE__ */ v("button", {
									className: "btn-base min-h-11 px-3",
									onClick: () => Je("event"),
									children: p("games.twilightstruggle.modeEvent")
								}),
								!W.scoring && /* @__PURE__ */ y(ee, { children: [
									/* @__PURE__ */ v("button", {
										className: "btn-base min-h-11 px-3",
										onClick: () => Je("influence"),
										children: p("games.twilightstruggle.modeInfluence")
									}),
									/* @__PURE__ */ v("button", {
										className: "btn-base min-h-11 px-3",
										onClick: () => Je("coup"),
										children: p("games.twilightstruggle.modeCoup")
									}),
									/* @__PURE__ */ v("button", {
										className: "btn-base min-h-11 px-3",
										onClick: () => Je("realign"),
										children: p("games.twilightstruggle.modeRealign")
									}),
									/* @__PURE__ */ v("button", {
										className: "btn-base min-h-11 px-3",
										disabled: !br(e, m, Yn(e, m, Ue ? 4 : W.ops)),
										onClick: () => Je("space"),
										children: p("games.twilightstruggle.modeSpace")
									})
								] }),
								Ge && /* @__PURE__ */ v("button", {
									className: "btn-quiet min-h-11 px-3",
									onClick: () => te((e) => e === "ops" ? "event" : "ops"),
									children: p(x === "event" ? "games.twilightstruggle.eventFirst" : "games.twilightstruggle.opsFirst")
								})
							]
						})
					]
				})
			]
		})]
	}), Qe = e.log[e.log.length - 1], $e = /* @__PURE__ */ y("div", {
		className: "ts-hand",
		children: [/* @__PURE__ */ y("div", {
			className: "ts-hand-head",
			children: [/* @__PURE__ */ v("strong", { children: p("games.twilightstruggle.handLabel", { n: Se.length + +(e.china.holder === m) }) }), /* @__PURE__ */ y("button", {
				type: "button",
				className: "ts-log-btn",
				"aria-label": p("games.twilightstruggle.logTitle"),
				onClick: () => le(!0),
				children: [/* @__PURE__ */ v(f, {
					size: 12,
					className: "flex-none"
				}), /* @__PURE__ */ v("span", {
					className: "ts-log-btn-text",
					children: Qe ? hr(p, Qe) : p("games.twilightstruggle.logEmpty")
				})]
			})]
		}), /* @__PURE__ */ y("div", {
			className: "ts-hand-scroll scrollbar-none",
			children: [Se.map((t) => {
				let n = C[t], r = n.side === T[m ?? "us"] && !n.scoring && !nr(e, m ?? "us", t), i = z || (ne ? t === 32 || n.side !== T[m ?? "us"] : e.phase === "headline" ? Ae || n.noHeadline === !0 : !Te || Ke !== null && t !== Ke || G && !qe(t) && !n.scoring);
				return /* @__PURE__ */ y("button", {
					className: `ts-hand-card ${_ === t ? "is-selected" : ""} ${i ? "is-muted" : ""}`,
					"data-side": n.scoring ? "both" : n.side,
					title: p(er(t)),
					"aria-pressed": _ === t,
					onClick: () => {
						if (ne) {
							if (t === 32 || n.side !== T[m ?? "us"]) return;
							R({
								type: "play",
								card: 32,
								mode: "event",
								withCard: t
							}, () => {
								S(!1), b(null);
							});
							return;
						}
						b((e) => e === t ? null : t);
					},
					children: [
						/* @__PURE__ */ v("span", { className: "ts-hand-card-mark" }),
						/* @__PURE__ */ y("span", {
							className: "ts-hand-card-top",
							children: [/* @__PURE__ */ v("span", {
								className: `ts-hand-card-ops font-mono tabular-nums ${Gn[n.scoring ? "both" : n.side]}`,
								children: n.scoring ? "★" : m ? Yn(e, m, n.ops) : n.ops
							}), /* @__PURE__ */ v("span", {
								className: "ts-hand-card-side",
								children: n.scoring ? "SC" : n.side === "us" ? "US" : n.side === "ussr" ? "SU" : "BI"
							})]
						}),
						/* @__PURE__ */ y("span", {
							className: "ts-hand-card-title",
							children: [p(er(t)), /* @__PURE__ */ v("small", {
								className: "ts-hand-fate-marker",
								children: p(rr(t))
							})]
						}),
						(r || n.scoring) && /* @__PURE__ */ v("span", {
							className: "ts-hand-card-tag",
							children: p(r ? "games.twilightstruggle.opponentEventShort" : "games.twilightstruggle.mustPlayShort")
						})
					]
				}, t);
			}), e.china.holder === m && /* @__PURE__ */ y("button", {
				className: `ts-hand-card ${_ === 6 ? "is-selected" : ""} ${!Te || !t?.chinaReady || Ke !== null || G || ne ? "is-muted" : ""}`,
				"data-side": "china",
				"aria-pressed": _ === 6,
				onClick: () => b((e) => e === 6 ? null : 6),
				children: [
					/* @__PURE__ */ v("span", { className: "ts-hand-card-mark" }),
					/* @__PURE__ */ y("span", {
						className: "ts-hand-card-top",
						children: [/* @__PURE__ */ v("span", {
							className: "ts-hand-card-ops font-mono tabular-nums text-amber-800",
							children: "4"
						}), /* @__PURE__ */ v("span", {
							className: "ts-hand-card-side",
							children: "CN"
						})]
					}),
					/* @__PURE__ */ v("span", {
						className: "ts-hand-card-title",
						children: p("games.twilightstruggle.chinaCard")
					}),
					/* @__PURE__ */ v("span", {
						className: "ts-hand-card-tag",
						children: p(t?.chinaReady ? "games.twilightstruggle.specialCardShort" : "games.twilightstruggle.chinaFaceDownShort")
					})
				]
			})]
		})]
	});
	return /* @__PURE__ */ y("div", {
		className: "ts-screen",
		style: { "--ts-overlay-height": `${N}px` },
		children: [
			/* @__PURE__ */ v(h, {
				adaptive: !0,
				className: "ts-adaptive",
				banner: Ye,
				scroll: !1,
				children: /* @__PURE__ */ y("div", {
					className: "ts-workspace",
					children: [/* @__PURE__ */ v("div", {
						className: "ts-map-stage",
						children: Xe
					}), /* @__PURE__ */ y("div", {
						className: "ts-control-column",
						children: [/* @__PURE__ */ v("div", {
							className: "ts-overlay-home pointer-events-none",
							children: Ze
						}), $e]
					})]
				})
			}),
			k && k.context === De && Ee && m && /* @__PURE__ */ v("div", {
				className: "ts-inspect",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": p("games.twilightstruggle.cancelCuban"),
				onClick: () => me(null),
				children: /* @__PURE__ */ y("div", {
					className: "ts-inspect-panel ts-info-panel",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ y("div", {
							className: "ts-info-head",
							children: [/* @__PURE__ */ v("strong", { children: p("games.twilightstruggle.cancelCuban") }), /* @__PURE__ */ v("button", {
								className: "ts-dossier-close flex h-11 w-11 items-center justify-center",
								onClick: () => me(null),
								"aria-label": p("games.twilightstruggle.close"),
								children: /* @__PURE__ */ v(l, { className: "h-4 w-4" })
							})]
						}),
						/* @__PURE__ */ y("div", {
							className: "ts-cuban-choices",
							children: [/* @__PURE__ */ v("p", { children: p("games.twilightstruggle.cancelCubanHint") }), ct[m].map((t) => {
								let n = e.influence[t]?.[m] ?? 0;
								return /* @__PURE__ */ y("button", {
									type: "button",
									"aria-pressed": k.country === t,
									disabled: n < 2 || k.submitted,
									className: `ts-cuban-country min-h-11 ${k.country === t ? "is-selected" : ""}`,
									onClick: () => me({
										...k,
										country: t
									}),
									children: [
										/* @__PURE__ */ v("strong", { children: p(Kn[t]) }),
										/* @__PURE__ */ v("span", {
											className: "font-mono tabular-nums",
											children: n >= 2 ? `${n} → ${n - 2}` : `${n}`
										}),
										n < 2 && /* @__PURE__ */ v("small", { children: p("games.twilightstruggle.cancelCubanInsufficient") })
									]
								}, t);
							})]
						}),
						/* @__PURE__ */ v("div", {
							className: "ts-cuban-footer",
							children: /* @__PURE__ */ v("button", {
								type: "button",
								className: "btn-base min-h-12 w-full bg-pop text-white",
								disabled: k.submitted || !k.country || !lt(e, m).includes(k.country),
								onClick: () => {
									k.country && R({
										type: "cancelCuban",
										country: k.country
									}, () => {
										me({
											...k,
											submitted: !0
										});
									});
								},
								children: p(k.submitted ? "games.twilightstruggle.cancelCubanSubmitting" : k.country ? "games.twilightstruggle.cancelCubanConfirm" : "games.twilightstruggle.cancelCubanChoose", { country: k.country ? p(Kn[k.country]) : "" })
							})
						})
					]
				})
			}),
			_e && _e.context === Nn(e, t) && /* @__PURE__ */ v(In, {
				warnings: _e.warnings,
				onCancel: () => L(null),
				onConfirm: () => {
					let e = _e;
					be({
						round: ve,
						keys: [...ye.round === ve ? ye.keys : [], ...e.warnings.map(jn)]
					}), L(null), s(e.action), e.onSent?.();
				}
			}),
			ce && /* @__PURE__ */ v("div", {
				className: "ts-log-sheet",
				children: /* @__PURE__ */ v(g, {
					log: e.log,
					line: _r(p, {
						onCard: ue,
						onCountry: (e) => {
							le(!1), ue(null), ae((t) => ({
								country: e,
								seq: (t?.seq ?? 0) + 1
							}));
						}
					}),
					rowClassName: "ts-log-item",
					onClose: () => le(!1)
				})
			}),
			de && /* @__PURE__ */ v("div", {
				className: "ts-inspect",
				onClick: () => fe(!1),
				children: /* @__PURE__ */ y("div", {
					className: "ts-inspect-panel ts-info-panel",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ y("div", {
						className: "ts-info-head",
						children: [/* @__PURE__ */ v("strong", { children: p("games.twilightstruggle.spaceDetailsTitle") }), /* @__PURE__ */ v("button", {
							className: "ts-dossier-close flex h-11 w-11 items-center justify-center",
							onClick: () => fe(!1),
							"aria-label": p("games.twilightstruggle.close"),
							children: /* @__PURE__ */ v(l, { className: "h-4 w-4" })
						})]
					}), /* @__PURE__ */ v(Hn, { space: e.space })]
				})
			}),
			pe && /* @__PURE__ */ v("div", {
				className: "ts-inspect",
				onClick: () => O(!1),
				children: /* @__PURE__ */ y("div", {
					className: "ts-inspect-panel ts-info-panel",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ y("div", {
						className: "ts-info-head",
						children: [/* @__PURE__ */ v("strong", { children: p("games.twilightstruggle.effectsTitle") }), /* @__PURE__ */ v("button", {
							className: "ts-dossier-close flex h-11 w-11 items-center justify-center",
							onClick: () => O(!1),
							"aria-label": p("games.twilightstruggle.close"),
							children: /* @__PURE__ */ v(l, { className: "h-4 w-4" })
						})]
					}), /* @__PURE__ */ y("div", {
						className: "ts-effects-list",
						children: [
							xe.turn.length === 0 && xe.lasting.length === 0 && /* @__PURE__ */ v("p", { children: p("games.twilightstruggle.effectsEmpty") }),
							xe.turn.length > 0 && /* @__PURE__ */ v(ar, {
								title: p("games.twilightstruggle.effectsTurn"),
								ids: xe.turn,
								onOpen: ue
							}),
							xe.lasting.length > 0 && /* @__PURE__ */ v(ar, {
								title: p("games.twilightstruggle.effectsLasting"),
								ids: xe.lasting,
								onOpen: ue
							})
						]
					})]
				})
			}),
			E !== null && C[E] && /* @__PURE__ */ v("div", {
				className: "ts-inspect",
				onClick: () => ue(null),
				children: /* @__PURE__ */ y("div", {
					className: "ts-inspect-panel",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ y("div", {
						className: "ts-dossier-head",
						children: [
							/* @__PURE__ */ v("span", {
								className: `ts-dossier-ops font-mono tabular-nums ${Gn[C[E].scoring ? "both" : C[E].side]}`,
								children: C[E].scoring ? "★" : C[E].ops
							}),
							/* @__PURE__ */ y("div", {
								className: "ts-dossier-heading",
								children: [
									/* @__PURE__ */ v("div", {
										className: "ts-dossier-title",
										children: p(er(E))
									}),
									/* @__PURE__ */ v("div", {
										className: "ts-dossier-side",
										children: C[E].scoring ? p("games.twilightstruggle.sideTagScoring") : p(C[E].side === "us" ? "games.twilightstruggle.sideTagUs" : C[E].side === "ussr" ? "games.twilightstruggle.sideTagUssr" : "games.twilightstruggle.sideTagBoth")
									}),
									/* @__PURE__ */ v("div", {
										className: "ts-dossier-fate",
										children: p(tr(E))
									})
								]
							}),
							/* @__PURE__ */ v("button", {
								className: "ts-dossier-close flex h-11 w-11 flex-none items-center justify-center",
								onClick: () => ue(null),
								"aria-label": p("games.twilightstruggle.close"),
								children: /* @__PURE__ */ v(l, { className: "h-4 w-4" })
							})
						]
					}), /* @__PURE__ */ v("div", {
						className: "ts-dossier-copy",
						children: p(`games.twilightstruggle.cardText.${C[E].key}`)
					})]
				})
			})
		]
	});
}
function er(e) {
	return `games.twilightstruggle.card.${C[e].key}`;
}
function tr(e) {
	return e === 6 ? "games.twilightstruggle.cardFateChina" : e === 73 ? "games.twilightstruggle.cardFateShuttle" : e === 49 ? "games.twilightstruggle.cardFateMissile" : C[e].unique ? "games.twilightstruggle.cardFateRemoved" : "games.twilightstruggle.cardFateDiscard";
}
function nr(e, t, n) {
	return e.civilWar && e.china.holder === null && (n === 58 || n === 35 || n === 31 && t === "ussr");
}
function rr(e) {
	return e === 6 ? "games.twilightstruggle.cardFateShortChina" : e === 73 ? "games.twilightstruggle.cardFateShortShuttle" : e === 49 ? "games.twilightstruggle.cardFateShortMissile" : C[e].unique ? "games.twilightstruggle.cardFateShortRemoved" : "games.twilightstruggle.cardFateShortDiscard";
}
function ir(e) {
	let t = e.mods, n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Set();
	if (t.opsMinus && n.add(31), t.opsPlus && n.add(t.opsPlus === "us" ? 25 : 51), t.vietnam && n.add(9), t.salt && n.add(43), t.iranContra && n.add(93), t.deathSquads && n.add(69), t.chernobyl && n.add(94), t.nuclearSubs && n.add(41), t.yuri && n.add(109), t.u2 && n.add(60), t.bury && n.add(50), t.northSeaOil && n.add(86), t.cuban && n.add(40), e.trapNow && e.current && n.add(e.current === "us" ? 42 : 44), (e.mustOps.us || e.mustOps.ussr) && n.add(49), t.revealedHand) {
		let r = (e) => t.revealedHand === "ussr" ? e === 26 : e === 62 || e === 98, i = -1;
		for (let t = e.log.length - 1; t >= 0; t--) if (e.log[t].k === "headline") {
			i = t;
			break;
		}
		for (let t of e.log.slice(Math.max(0, i))) if (t.k === "headline") {
			let e = t.us === 103 ? t.ussr : t.ussr === 103 ? t.us : null;
			t.us !== e && r(t.us) && n.add(t.us), t.ussr !== e && r(t.ussr) && n.add(t.ussr);
		} else t.k === "play" && t.mode !== "discard" && r(t.card) && (t.mode === "event" || t.mode !== "space" && C[t.card].side === T[t.side]) && n.add(t.card);
	}
	return t.warsaw && !t.nato && r.add(16), t.marshall && !t.nato && r.add(23), t.nato && r.add(21), t.natoOff.includes("france") && r.add(17), t.natoOff.includes("westGermany") && r.add(55), t.usJapan && r.add(27), t.campDavid && r.add(65), t.formosan && r.add(35), t.flower && r.add(59), t.ironLady && r.add(83), t.reformer && r.add(87), t.tearDown && r.add(96), t.evilEmpire && r.add(97), t.shuttle && r.add(73), t.iranHostage && r.add(82), t.awacs && r.add(110), t.norad && r.add(106), t.johnPaul && r.add(68), e.removed.includes(86) && !t.northSeaOil && r.add(86), {
		turn: [...n].sort((e, t) => e - t),
		lasting: [...r].sort((e, t) => e - t)
	};
}
function ar({ title: e, ids: t, onOpen: n }) {
	let r = o();
	return /* @__PURE__ */ y("section", {
		className: "ts-effects-group",
		children: [/* @__PURE__ */ v("h3", { children: e }), t.map((e) => /* @__PURE__ */ v("button", {
			type: "button",
			onClick: () => n(e),
			children: r(er(e))
		}, e))]
	});
}
var or = {
	event: "games.twilightstruggle.modeEvent",
	influence: "games.twilightstruggle.modeInfluence",
	coup: "games.twilightstruggle.modeCoup",
	realign: "games.twilightstruggle.modeRealign",
	space: "games.twilightstruggle.modeSpace"
}, sr = {
	vp20: "games.twilightstruggle.winVP",
	nuclear: "games.twilightstruggle.winNuclear",
	europe: "games.twilightstruggle.winEurope",
	scoringHeld: "games.twilightstruggle.winScoringHeld",
	wargames: "games.twilightstruggle.winWargames",
	final: "games.twilightstruggle.winFinal"
}, cr = (e) => e > 0 ? `+${e}` : `${e}`, lr = (e, t) => /* @__PURE__ */ v("span", {
	className: e === "us" ? "font-bold text-blue-700" : "font-bold text-red-700",
	children: t
}), ur = (e, t) => t ? /* @__PURE__ */ v("button", {
	type: "button",
	className: "ts-log-place ts-log-placebtn",
	onClick: t,
	children: e
}) : /* @__PURE__ */ v("span", {
	className: "ts-log-place",
	children: e
}), dr = (e) => /* @__PURE__ */ v("span", {
	className: "font-mono tabular-nums",
	children: e
}), fr = (e, t) => /* @__PURE__ */ v("span", {
	className: e ? "text-emerald-700" : "text-rose-700",
	children: t
}), pr = (e) => /* @__PURE__ */ v("span", {
	className: `font-mono tabular-nums font-bold ${e > 0 ? "text-blue-700" : "text-red-700"}`,
	children: `VP ${cr(e)}`
}), mr = (e, t, n) => {
	let r = C[e], i = `font-bold ${Gn[r.scoring ? "both" : r.side]}`;
	return n ? /* @__PURE__ */ v("button", {
		type: "button",
		className: `ts-log-cardbtn ${i}`,
		onClick: () => n(e),
		children: t
	}) : /* @__PURE__ */ v("span", {
		className: i,
		children: t
	});
};
function Z(e, t, n) {
	let r = {};
	n.forEach(([e], t) => {
		r[e] = `${t}`;
	});
	let i = e(t, r), a = /(\d+)/g, o = [], s = 0;
	for (let e of i.matchAll(a)) e.index > s && o.push(i.slice(s, e.index)), o.push(n[Number(e[1])][1]), s = e.index + e[0].length;
	return s < i.length && o.push(i.slice(s)), o.map((e, t) => typeof e == "string" ? /* @__PURE__ */ v("span", { children: e }, `t${t}`) : /* @__PURE__ */ v("span", { children: e }, `s${t}`));
}
function hr(e, t, n) {
	let r = (t) => lr(t, e(t === "us" ? "games.twilightstruggle.sideUs" : "games.twilightstruggle.sideUssr")), i = (t) => ur(e(`games.twilightstruggle.country.${t}`), n?.onCountry ? () => n.onCountry(t) : void 0), a = (t) => ur(e(`games.twilightstruggle.region.${t}`)), o = (t) => mr(t, e(er(t)), n?.onCard);
	switch (t.k) {
		case "turn": return e("games.twilightstruggle.logTurn", { n: t.n });
		case "headline": return Z(e, "games.twilightstruggle.logHeadline", [["us", o(t.us)], ["ussr", o(t.ussr)]]);
		case "play": return t.card === 43 && t.mode === "retrieve" && t.withCard !== void 0 ? Z(e, "games.twilightstruggle.logSaltRetrieve", [
			["name", r(t.side)],
			["event", o(t.card)],
			["card", o(t.withCard)]
		]) : t.card === 49 && t.mode === "exchange" && t.withCard !== void 0 ? Z(e, "games.twilightstruggle.logMissileEnvyExchange", [
			["name", r(t.side)],
			["event", o(t.card)],
			["card", o(t.withCard)]
		]) : t.card === 67 && t.mode !== "discard" && t.withCard !== void 0 ? Z(e, t.mode === "draw" ? "games.twilightstruggle.logGrainDraw" : t.mode === "return" ? "games.twilightstruggle.logGrainReturn" : t.mode === "un" ? "games.twilightstruggle.logGrainUn" : "games.twilightstruggle.logGrainUse", [
			["name", r(t.side)],
			["event", o(t.card)],
			["card", o(t.withCard)],
			["un", o(32)]
		]) : t.mode === "skip" ? Z(e, "games.twilightstruggle.logTrapSkip", [["name", r(t.side)], ["card", o(t.card)]]) : t.mode === "discard" && t.withCard !== void 0 ? Z(e, "games.twilightstruggle.logDiscardForEvent", [
			["name", r(t.side)],
			["card", o(t.card)],
			["event", o(t.withCard)]
		]) : t.mode === "noDiscard" ? Z(e, "games.twilightstruggle.logNoDiscardForEvent", [["name", r(t.side)], ["event", o(t.card)]]) : t.card === 32 && t.withCard !== void 0 ? Z(e, "games.twilightstruggle.logUnIntervention", [
			["name", r(t.side)],
			["card", o(t.card)],
			["withCard", o(t.withCard)]
		]) : Z(e, "games.twilightstruggle.logPlay", [
			["name", r(t.side)],
			["card", o(t.card)],
			["mode", e(or[t.mode] ?? "games.twilightstruggle.modeOps")]
		]);
		case "coup": return Z(e, "games.twilightstruggle.logCoup", [
			["name", r(t.side)],
			["country", i(t.country)],
			["roll", dr(t.roll)],
			["result", fr(t.success, e(t.success ? "games.twilightstruggle.logCoupSuccess" : "games.twilightstruggle.logCoupFail"))]
		]);
		case "realign": return Z(e, "games.twilightstruggle.logRealign", [
			["name", r(t.side)],
			["country", i(t.country)],
			["usRoll", dr(t.usRoll)],
			["ussrRoll", dr(t.ussrRoll)],
			["result", t.removed > 0 ? dr(e("games.twilightstruggle.logRealignRemoved", { n: t.removed })) : e("games.twilightstruggle.logRealignNone")]
		]);
		case "space": return Z(e, "games.twilightstruggle.logSpace", [
			["name", r(t.side)],
			["roll", dr(t.roll)],
			["result", fr(t.success, e(t.success ? "games.twilightstruggle.logSpaceOk" : "games.twilightstruggle.logSpaceFail"))]
		]);
		case "war": return Z(e, "games.twilightstruggle.logWar", [
			["card", o(t.card)],
			["name", r(t.side)],
			["country", i(t.country)],
			["roll", dr(t.roll)],
			["result", fr(t.success, e(t.success ? "games.twilightstruggle.logCoupSuccess" : "games.twilightstruggle.logCoupFail"))]
		]);
		case "score": return Z(e, "games.twilightstruggle.logScore", [
			["region", a(t.region)],
			["us", /* @__PURE__ */ v("span", {
				className: "font-mono tabular-nums font-bold text-blue-700",
				children: t.us
			})],
			["ussr", /* @__PURE__ */ v("span", {
				className: "font-mono tabular-nums font-bold text-red-700",
				children: t.ussr
			})]
		]);
		case "defcon": return Z(e, "games.twilightstruggle.logDefcon", [["n", dr(t.n)]]);
		case "milops": return Z(e, "games.twilightstruggle.logMilops", [["name", r(t.side)], ["n", dr(t.diff)]]);
		case "trap": return Z(e, "games.twilightstruggle.logTrap", [
			["name", r(t.side)],
			["roll", dr(t.roll)],
			["result", fr(t.escaped, e(t.escaped ? "games.twilightstruggle.logTrapEscape" : "games.twilightstruggle.logTrapCaught"))]
		]);
		case "over": return t.winner ? Z(e, "games.twilightstruggle.logOver", [["name", r(t.winner)], ["reason", e(sr[t.reason] ?? "games.twilightstruggle.winFinal")]]) : e("games.twilightstruggle.logOverDraw");
		case "delta": {
			let n = [];
			t.vp !== 0 && n.push(pr(t.vp));
			for (let r of t.inf) n.push(/* @__PURE__ */ y("span", { children: [
				i(r.c),
				" ",
				r.us !== 0 && /* @__PURE__ */ y("span", {
					className: "font-mono tabular-nums text-blue-700",
					children: [e("games.twilightstruggle.sideUsShort"), cr(r.us)]
				}),
				r.us !== 0 && r.ussr !== 0 && " ",
				r.ussr !== 0 && /* @__PURE__ */ y("span", {
					className: "font-mono tabular-nums text-red-700",
					children: [e("games.twilightstruggle.sideUssrShort"), cr(r.ussr)]
				})
			] }, r.c));
			return n.flatMap((e, t) => t === 0 ? [/* @__PURE__ */ v("span", { children: e }, t)] : [/* @__PURE__ */ v("span", { children: " · " }, `sep${t}`), /* @__PURE__ */ v("span", { children: e }, t)]);
		}
	}
}
function gr(e) {
	switch (e.k) {
		case "play":
		case "coup":
		case "realign":
		case "space":
		case "war":
		case "trap":
		case "milops": return e.side;
		default: return null;
	}
}
function _r(e, t) {
	let n = null;
	return (r) => {
		if (r.k === "turn") return /* @__PURE__ */ v("div", {
			className: "ts-log-turn",
			children: hr(e, r, t)
		});
		if (r.k === "headline" || r.k === "score" || r.k === "defcon" || r.k === "over") return /* @__PURE__ */ v("div", {
			className: "ts-log-sys",
			children: hr(e, r, t)
		});
		let i = gr(r);
		i && (n = i);
		let a = i ?? n;
		return a === null ? /* @__PURE__ */ v("div", {
			className: "ts-log-sys ts-log-delta-flat",
			children: hr(e, r, t)
		}) : /* @__PURE__ */ v("div", {
			className: "ts-log-row",
			"data-side": a,
			children: /* @__PURE__ */ v("div", {
				className: `ts-log-bubble ${r.k === "delta" ? "ts-log-bubble-delta" : ""}`,
				children: hr(e, r, t)
			})
		});
	};
}
function vr(e, t) {
	if (Xn[t]) return e(Xn[t]);
	if (/^[1-5]$/.test(t)) return t;
	let n = `games.twilightstruggle.region.${t}`;
	return qn.includes(t) || t === "europe" ? e(n) : e(`games.twilightstruggle.country.${t}`);
}
function yr(e, t) {
	return t.card === 19 ? e("games.twilightstruggle.trumanPick") : t.card === 106 ? e("games.twilightstruggle.noradPick") : e(t.mode === "add" || t.mode === "double" || t.mode === "match" ? "games.twilightstruggle.placeN" : "games.twilightstruggle.removeN", { n: t.n });
}
function br(e, t, n) {
	let r = e.space[t];
	if (r >= 8) return !1;
	let i = 1 + +(r >= 2 && e.space[T[t]] < 2);
	return e.spaceUsed[t] >= i ? !1 : n >= se(r);
}
function xr(e, t, n, r) {
	return e.arDone[t] === 7 && e.arTotal[t] === 8 || e.trapNow && !n.some((n) => C[n].scoring || Yn(e, t, C[n].ops) >= 2) ? !0 : n.length === 0 && !r?.chinaReady;
}
function Sr({ region: e, pub: t, tap: n, onTap: r }) {
	let i = o(), a = D.filter((t) => Jn(t) === e);
	return e === "asia" && t.civilWar && a.push("chineseCivilWar"), a.length === 0 ? null : /* @__PURE__ */ y("div", {
		className: "ts-index-region",
		children: [/* @__PURE__ */ v("div", {
			className: "ts-index-region-title",
			children: i(`games.twilightstruggle.region.${e}`)
		}), /* @__PURE__ */ v("div", {
			className: "grid grid-cols-2 gap-1 wide:grid-cols-3",
			children: a.map((e) => {
				let a = w[e], o = t.influence[e] ?? {
					us: 0,
					ussr: 0
				}, s = o.us >= o.ussr + a.stability ? "us" : o.ussr >= o.us + a.stability ? "ussr" : null, c = n.has(e), l = i(`games.twilightstruggle.country.${e}`);
				return /* @__PURE__ */ y("button", {
					"aria-label": `${l}, ${i("games.twilightstruggle.stabLabel", { n: a.stability })}, ${i("games.twilightstruggle.sideUs")} ${o.us}, ${i("games.twilightstruggle.sideUssr")} ${o.ussr}, ${i(s === "us" ? "games.twilightstruggle.controlUs" : s === "ussr" ? "games.twilightstruggle.controlUssr" : "games.twilightstruggle.uncontrolled")}`,
					className: `ts-index-country flex min-h-11 items-center justify-between gap-1 px-2 py-1 text-left text-xs ${c ? "is-target" : ""} ${s === "us" ? "is-us" : s === "ussr" ? "is-ussr" : ""}`,
					onClick: () => r(e),
					children: [/* @__PURE__ */ y("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ v("span", {
							className: "block truncate font-medium",
							children: l
						}), /* @__PURE__ */ y("span", {
							className: "opacity-60",
							children: [i("games.twilightstruggle.stabLabel", { n: a.stability }), a.battleground ? ` · ${i("games.twilightstruggle.bgLabel")}` : ""]
						})]
					}), /* @__PURE__ */ y("span", {
						className: "flex flex-none gap-1 font-mono tabular-nums",
						children: [/* @__PURE__ */ y("b", {
							className: Wn.us.num,
							children: [i("games.twilightstruggle.sideUsShort"), o.us]
						}), /* @__PURE__ */ y("b", {
							className: Wn.ussr.num,
							children: [i("games.twilightstruggle.sideUssrShort"), o.ussr]
						})]
					})]
				}, e);
			})
		})]
	});
}
function Cr({ id: e, onOpen: t }) {
	let n = o();
	return /* @__PURE__ */ v("button", {
		type: "button",
		className: "ts-revealed-card min-h-11 px-2",
		onClick: t,
		children: n(er(e))
	});
}
//#endregion
//#region src/games/twilightstruggle/bot-scoring.ts
var wr = S.filter((e) => e.scoring);
function Tr(e, t, n, r) {
	let i = { ...n };
	for (let a of wr) {
		let o = a.scoring, s = e.turn >= (a.stage === "early" ? 1 : a.stage === "mid" ? 4 : 8), c = e.removed.includes(a.id), l = !s || c ? 0 : t.includes(a.id) ? r.held : e.discard.includes(a.id) ? 0 : r.available, u = e.turn >= 10 && !a.unique ? r.final : 0;
		i[o] = (a.unique && c ? 0 : n[o] ?? 0) + Math.max(l, u);
	}
	return i;
}
//#endregion
//#region src/games/twilightstruggle/bot-influence.ts
var Er = (e, t) => e.influence[t] ?? {
	us: 0,
	ussr: 0
}, Dr = (e, t, n) => ({
	...e,
	influence: {
		...e.influence,
		[t]: n
	}
});
function Or(e, t, n, r) {
	if (t === "southeastAsia") return E.reduce((t, r) => {
		let i = Er(e, r), a = i[n] - i[T[n]], o = r === "thailand" ? 2 : 1;
		return t + (a >= w[r].stability ? o : a <= -w[r].stability ? -o : 0);
	}, 0);
	let i = Te(e, t), a = (e) => e === "us" ? i.usTier : i.ussrTier;
	if (t === "europe") {
		if (a(n) === "control") return r;
		if (a(T[n]) === "control") return -r;
	}
	let [o, s, c] = ce[t], l = (e, t) => (t === "control" ? c ?? 0 : t === "domination" ? s : t === "presence" ? o : 0) + i[e].bg + i[e].adj;
	return l(n, a(n)) - l(T[n], a(T[n]));
}
function kr(e, t, n, r, i) {
	let a = T[t], o = /* @__PURE__ */ new Map(), s = (e) => w[e].regions.filter((e) => e in ce || e === "southeastAsia"), c = (e, i) => s(i).reduce((i, a) => i + (n[a] ?? 0) * Or(e, a, t, r), 0), l = (r) => {
		let i = o.get(r);
		if (i) return i;
		let l = Dr(e, r, {
			us: 0,
			ussr: 0
		}), u = c(l, r), d = Math.max(0, ...s(r).map((e) => n[e] ?? 0)) * .5, f = {
			[t]: Math.max(d, c(Dr(l, r, {
				...Er(l, r),
				[t]: w[r].stability
			}), r) - u),
			[a]: Math.max(d, u - c(Dr(l, r, {
				...Er(l, r),
				[a]: w[r].stability
			}), r))
		};
		return o.set(r, f), f;
	}, u = (e, t) => new Set(D.filter((n) => w[n].adjacent.includes(t) || Er(e, n)[t] > 0 || w[n].adjacent.some((n) => (e.influence[n]?.[t] ?? 0) > 0))), d = u(e, t), f = (n) => [...n].filter((n) => !d.has(n) && !(t === "ussr" && e.mods.chernobyl && w[n].regions.includes(e.mods.chernobyl))).map((e) => l(e)[t] / (1 + w[e].stability)).sort((e, t) => t - e).slice(0, 2).reduce((e, t) => e + t, 0) * .15, p = (t) => {
		let n = C[t];
		return e.turn >= (n.stage === "early" ? 1 : n.stage === "mid" ? 4 : 8) && !e.discard.includes(t) && !e.removed.includes(t) && !i.includes(t);
	}, m = [
		{
			card: 17,
			country: "france",
			side: "us",
			loss: 2,
			gain: 1
		},
		{
			card: 55,
			country: "westGermany",
			side: "us",
			loss: 0,
			gain: 1
		},
		{
			card: 68,
			country: "poland",
			side: "ussr",
			loss: 2,
			gain: 1
		},
		{
			card: 96,
			country: "eastGermany",
			side: "ussr",
			loss: 0,
			gain: 3
		},
		{
			card: 101,
			country: "poland",
			side: "ussr",
			loss: 0,
			gain: 3
		}
	].filter((t) => p(t.card) && (t.card !== 55 || !e.mods.tearDown) && (t.card !== 101 || e.mods.johnPaul)), h = (e, n) => {
		let r = Er(e, n), i = w[n].stability, o = l(n), s = (e) => {
			let t = r[e] - r[T[e]];
			if (t >= i) return o[e] * (.5 - .2 / (1 + t - i) ** 2);
			if (r[e] === 0) return 0;
			let n = i - t + (t <= -i ? -i - t + 1 : 0);
			return o[e] * .45 / (1 + n);
		};
		return s(t) - s(a);
	}, g = (e, t) => m.filter((e) => e.country === t).reduce((n, r) => {
		let i = Er(e, t), a = {
			...i,
			[r.side]: Math.max(0, i[r.side] - r.loss),
			[T[r.side]]: i[T[r.side]] + r.gain
		};
		return n + .12 * (c(Dr(e, t, a), t) - c(e, t));
	}, 0);
	function _(e, n, r = 1) {
		let i = Er(e, n), a = Dr(e, n, {
			...i,
			[t]: i[t] + r
		});
		if (n === "chineseCivilWar") {
			let e = (e) => Math.min(3, e) / 3;
			return a.influence[n].ussr >= 3 && (a.china = {
				holder: "ussr",
				faceUp: !0
			}), {
				pub: a,
				value: 4 * (e(i[t] + r) - e(i[t]))
			};
		}
		let o = 0;
		if (i[t] === 0) {
			let r = u(e, t), i = /* @__PURE__ */ new Set([
				...r,
				...w[n].adjacent.filter((e) => D.includes(e)),
				n
			]);
			o = f(i) - f(r);
		}
		return {
			pub: a,
			value: c(a, n) - c(e, n) + h(a, n) - h(e, n) + g(a, n) - g(e, n) + o
		};
	}
	return { add: _ };
}
function Ar(e, t, n, r, i, a, o = null, s = () => 0) {
	let c = o ? null : e.spending;
	if (!o && !c) return null;
	let l = kr(e, t, n, r, i), u = o ? o.pool : [...D, "chineseCivilWar"], d = [{
		pub: e,
		left: o ? o.n : c.opsLeft,
		value: 0,
		path: [],
		spending: c,
		used: { ...o?.used }
	}], f = null, p = (e) => {
		e.path.length && (!f || e.value > f.value) && (f = e);
	}, m = Math.max(6, d[0].left);
	for (let e = 0; e < m && d.length; e += 1) {
		let e = /* @__PURE__ */ new Map();
		for (let n of d) {
			let r = !1;
			for (let i of u) {
				if (o ? (n.used[i] ?? 0) >= o.perMax : !a(n.pub, i, n.spending)) continue;
				let c = o ? 1 : Er(n.pub, i)[T[t]] - Er(n.pub, i)[t] >= w[i].stability ? 2 : 1, u = n.spending ? { ...n.spending } : null, d = n.left - c;
				if (u) {
					let e = w[i].regions;
					e.includes("asia") || (u.asiaAll = !1), e.includes("southeastAsia") || (u.seaAll = !1), u.asiaAll && !u.asiaBonus && (u.asiaBonus = !0, d += 1), u.seaAll && !u.seaBonus && (u.seaBonus = !0, d += 1), u.asiaBonus && !u.asiaAll && (u.asiaBonus = !1, --d), u.seaBonus && !u.seaAll && (u.seaBonus = !1, --d), u.opsLeft = d;
				}
				let f = [...n.path, i], m = {
					...n.used,
					[i]: (n.used[i] ?? 0) + 1
				}, h = `${Object.entries(m).sort(([e], [t]) => e.localeCompare(t)).map(([e, t]) => `${e}:${t}`).join(",")}|${d}`, g = l.add(n.pub, i, o?.amt ?? 1), _ = {
					pub: g.pub,
					left: d,
					value: n.value + g.value + s(i),
					path: f,
					spending: u,
					used: m
				};
				r = !0, d <= 0 ? p(_) : (!e.has(h) || _.value > e.get(h).value) && e.set(h, _);
			}
			r || p(n);
		}
		d = [...e.values()].sort((e, t) => t.value - e.value).slice(0, 12);
	}
	for (let e of d) p(e);
	let h = f;
	return h ? {
		country: o ? h.path.reduce((e, t) => s(t) > s(e) ? t : e) : h.path[0],
		value: h.value
	} : null;
}
//#endregion
//#region src/games/twilightstruggle/bot.ts
var Q = (e) => ({ action: e });
function jr(e) {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e;
}
var Mr = (e) => e[jr(e.length)];
function Nr(e, t) {
	let n = e[0], r = -Infinity;
	for (let i of e) {
		let e = t(i);
		e > r && (r = e, n = i);
	}
	return n;
}
function Pr(e, t) {
	let n = e[0], r = Infinity;
	for (let i of e) {
		let e = t(i);
		e < r && (r = e, n = i);
	}
	return n;
}
var $ = (e, t) => e.influence[t] ?? {
	us: 0,
	ussr: 0
};
function Fr(e, t) {
	let { us: n, ussr: r } = $(e, t), i = w[t].stability;
	return n >= r + i ? "us" : r >= n + i ? "ussr" : null;
}
function Ir(e, t, n) {
	let r = 0;
	return e.mods.opsPlus === t && (r += 1), e.mods.opsMinus === t && --r, Math.min(4, Math.max(1, n + r));
}
function Lr(e, t) {
	let n = w[t].regions;
	return !!(e.defcon <= 4 && n.includes("europe") || e.defcon <= 3 && n.includes("asia") || e.defcon <= 2 && n.includes("middleEast"));
}
function Rr(e, t) {
	return e.mods.nato && w[t].regions.includes("europe") && !e.mods.natoOff.includes(t) && Fr(e, t) === "us";
}
function zr(e, t, n, r) {
	return !D.includes(t) || $(e, t)[T[n]] === 0 ? !1 : r ? !0 : Rr(e, t) || e.mods.usJapan && t === "japan" || n === "ussr" && e.mods.reformer && w[t].regions.includes("europe") ? !1 : !Lr(e, t);
}
function Br(e, t, n, r) {
	if (!D.includes(t)) return !1;
	let i = $(e, t);
	return i.us === 0 && i.ussr === 0 || i[n] > 0 && i[T[n]] === 0 ? !1 : r ? !0 : Rr(e, t) || e.mods.usJapan && t === "japan" ? !1 : !Lr(e, t);
}
function Vr(e, t, n, r, i, a) {
	if (t === "chineseCivilWar") return e.civilWar && e.china.holder === null && n === "ussr" && a > 0 && e.mods.chernobyl !== "asia" && (!i || i.includes(t));
	if (!D.includes(t) || i && !i.includes(t) || n === "ussr" && e.mods.chernobyl && w[t].regions.includes(e.mods.chernobyl)) return !1;
	let o = w[t].adjacent.includes(n), s = r.includes(t) || r.some((e) => w[e]?.adjacent.includes(t));
	return !o && !s ? !1 : a >= (Fr(e, t) === T[n] ? 2 : 1);
}
function Hr(e, t, n) {
	let r = e.space[t];
	if (r >= 8) return !1;
	let i = 1 + +(r >= 2 && e.space[T[t]] < 2);
	return e.spaceUsed[t] >= i ? !1 : n >= se(r);
}
function Ur(e, t, n) {
	if (C[t].scoring || t === 6 || t === 32) return !0;
	if (e.civilWar && e.china.holder === null && (t === 58 || t === 35 || t === 31 && n === "ussr")) return !1;
	switch (t) {
		case 7: return !e.mods.ironLady;
		case 13: return !e.mods.campDavid;
		case 21: return e.mods.warsaw || e.mods.marshall;
		case 48: {
			let t = (t) => D.filter((n) => w[n].battleground && Fr(e, n) === t).length;
			return t("us") > t("ussr");
		}
		case 55: return !e.mods.tearDown;
		case 56: return !e.mods.awacs;
		case 59: return !e.mods.evilEmpire;
		case 80: return e.space[n] < e.space[T[n]];
		case 85: return e.space.us > e.space.ussr && e.discard.some((e) => !C[e].scoring);
		case 100: return e.defcon === 2;
		case 101: return e.mods.johnPaul;
		case 104: return e.turn < 8;
		case 105: return Fr(e, "uk") === "us";
		case 108: return O("middleEast").some((t) => Fr(e, t) === "us");
		default: return !0;
	}
}
var Wr = [
	4,
	50,
	89
];
function Gr(e, t) {
	return Wr.includes(e) || e === 26 && t === "ussr" || e === 62 && t === "us";
}
function Kr(e, t, n) {
	return e.defcon <= 2 && (t === 26 && n === "ussr" || t === 62 && n === "us");
}
var qr = {
	wEurope: 1.5,
	wAsia: 1.5,
	wMiddleEast: 2,
	wCentralAmerica: 1.6,
	wSouthAmerica: 2.4,
	wAfrica: 1.4,
	wSeAsia: 1.8,
	wFloor: .8,
	scoringAvailableBonus: 2,
	scoringHeldBonus: 3,
	scoringFinalBonus: 3,
	bgBonus: 2.5,
	addFlip: 5,
	addChipOpp: 1.5,
	addDefend: 2,
	addSafe: .4,
	addTake: 4,
	addChipFree: 1.5,
	rmInfW: .3,
	rmLoseCtrl: 5,
	rmKeepCtrl: 1,
	europeCtrl: 100,
	keepScBase: 5,
	keepScW: 1.5,
	evScBase: 6,
	evScW: 2,
	keepOwnFire: 4,
	keepOwnNoFire: 1,
	keepBoth: 3,
	keepOppFire: -6,
	keepOppNoFire: -2,
	keepSuicide: -50,
	evNoFire: 1,
	evSuicide: -100,
	evWargames: 100,
	evSummit: 7,
	evSummitLow: 1.5,
	evPerBase: 2,
	evPerUnit: 2,
	evAldrich: 4,
	evBigSix: 4,
	evMid: 5.5,
	evBase: 3,
	evOpsW: .5,
	evFireThreshold: 5,
	ceCtrl: 2,
	ceRemInfW: .6,
	ceAddInfW: .2,
	ceMilopsW: 2,
	ceDefconW: -2,
	ceYuri: 2,
	ceAbort: 0,
	coupBias: 0,
	infRefW: 1,
	reBg: 1.5,
	reNb: .5,
	reAdvW: .5,
	reDeficitW: .4,
	reCtrl: 1,
	reThreshold: .5,
	hlScBase: 8,
	hlScW: 2,
	hlOppBase: -10,
	hlOppOpsW: -1,
	hlSuicide: -50,
	hlNoFireOpsW: .5,
	hlBase: 4,
	hlOpsW: 1,
	warFaceW: 10,
	warBg: 3,
	ditchMaxKeep: 7,
	rescueMinKeep: 4,
	dumpBelowKeep: 4,
	warsawRemoveInf: 3,
	evDestal: 3,
	evDecol: 3,
	evMidBig: 2.5,
	evCuban: 2.5,
	meLowDefconPen: -6,
	evCiaEarly: 1,
	evCiaLate: 7,
	wwbyOpsBias: -2,
	hlOppEscape: 2,
	hlDefectorsPen: -3,
	hlMidBig: 1.5,
	decolAfricaBonus: 2,
	destalAvoidCA: -3,
	keepWargames: 2,
	evDuckVpW: 1.2,
	evBlockadeEarly: 2.5,
	hlBlockadePen: -8,
	keepDefectors: 2,
	evNSubs: 2.5,
	evQuagmire: 2,
	evQuagmireNorad: 2,
	evBearTrapCombo: 3.5,
	evNatoPen: -3,
	hlRedScare: 1.5,
	evCultRevChina: 3,
	evCultRevSolo: -1.5,
	evNixonChina: 2.5,
	evUssuriChina: 3,
	evTearDown: 2.5,
	setupUssrItaly: !0,
	setupUsWg4: !0,
	evWarsawHold: -2,
	hlMarshall: 2,
	evMarshallEarly: 2,
	hlContainment: 2.5,
	evUsJapanPen: -3,
	evNtbPen: -3,
	evHiltsw: 2.5,
	hlHiltsw: 1.5,
	hlKal: 2,
	keepAskNot: 2,
	evFlowerPen: -2.5,
	evTerror: 2,
	hlTerror: 1,
	hlChernobyl: 1.5,
	keepChernobyl: 1.5,
	evStarWars: 2,
	hlNorthSea: 2,
	evNorthSea: 2,
	evChe: 2,
	evFidelLate: 2,
	hlSuez: 2,
	evAwacsMr: 3,
	evIhcIran: 2.5,
	evReformer: 2,
	evGlasnost: 2,
	hlGlasnost: 1.5,
	evLadcSa: 2.5,
	evEvilEmpireFp: 3,
	evEvilEmpirePen: -1.5,
	evAldrichLate: 2,
	hlAldrich: 2,
	hlCambridge: 1.5,
	evTehran: 2
}, Jr = (e) => ({
	europe: e.wEurope,
	asia: e.wAsia,
	middleEast: e.wMiddleEast,
	centralAmerica: e.wCentralAmerica,
	southAmerica: e.wSouthAmerica,
	africa: e.wAfrica,
	southeastAsia: e.wSeAsia,
	westernEurope: 0,
	easternEurope: 0
});
function Yr(e) {
	let t = {
		...qr,
		...e
	}, n = Jr(t), r = (e, n) => Math.max(t.wFloor, ...w[e].regions.map((e) => n[e] ?? 0));
	function i(e, n, i, a) {
		if (n === "chineseCivilWar") return i === "ussr" ? t.addTake + 3 : 0;
		let o = w[n], s = $(e, n), c = T[i], l = r(n, a) + (o.battleground ? t.bgBonus : 0), u = Fr(e, n);
		return l += u === c ? s[i] + 1 >= s[c] + o.stability ? t.addFlip : t.addChipOpp : u === i ? s[c] >= s[i] - 1 ? t.addDefend : t.addSafe : s[i] + 1 >= s[c] + o.stability ? t.addTake : t.addChipFree, l;
	}
	function a(e, n, i, a) {
		let o = w[n], s = $(e, n), c = r(n, a) + (o.battleground ? t.bgBonus : 0) + s[i] * t.rmInfW;
		return Fr(e, n) === i && (c += s[i] - 1 < s[T[i]] + o.stability ? t.rmLoseCtrl : t.rmKeepCtrl), c;
	}
	function o(e, n, r) {
		return Or(e, n, r, t.europeCtrl);
	}
	function s(e, t, n) {
		return o(e, C[t].scoring, n);
	}
	function c(e, n, r, i, a = [], o = 1) {
		return kr(e, r, i, t.europeCtrl, a).add(e, n, o).value;
	}
	function l(e, n, r) {
		let i = C[n];
		if (i.scoring) return t.keepScBase + s(e, n, r) * t.keepScW;
		let a = i.ops;
		return i.side === r ? a += Ur(e, n, r) ? t.keepOwnFire : t.keepOwnNoFire : i.side === "both" ? a += t.keepBoth : a += Ur(e, n, r) ? t.keepOppFire : t.keepOppNoFire, Gr(n, r) && e.defcon <= 2 && (a += t.keepSuicide), n === 100 && (a += t.keepWargames), n === 103 && r === "us" && (a += t.keepDefectors), n === 77 && r === "us" && (a += t.keepAskNot), n === 77 && r === "ussr" && (a += t.keepAskNot * 2), n === 94 && r === "us" && (a += t.keepChernobyl), n === 20 && e.defcon <= 2 && (a -= t.evSuicide), n === 49 && e.defcon <= 3 && (a -= t.meLowDefconPen), a;
	}
	function u(e, t, n) {
		if (n !== "us" || $(e, "westGermany").us === 0 || e.removed.includes(10) || !t.includes(10) && (e.discard.includes(10) || e.phase === "ar" && e.arDone.ussr >= e.arTotal.ussr)) return null;
		let r = t.filter((t) => t !== 6 && !C[t].scoring && Ir(e, "us", C[t].ops) >= 3);
		return r.length ? Pr(r, (t) => l(e, t, n)) : null;
	}
	function d(e, n, r) {
		let i = C[n];
		if (i.scoring) return t.evScBase + s(e, n, r) * t.evScW;
		if (!Ur(e, n, r)) return t.evNoFire;
		if (Wr.includes(n) && e.defcon <= 2 || n === 20 && e.defcon <= 2) return t.evSuicide;
		if (n === 26 && r === "us") return e.turn < 7 ? t.evCiaEarly : t.evCiaLate;
		if (n === 100) {
			let n = e.vp + (r === "us" ? -6 : 6);
			return (n > 0 ? "us" : n < 0 ? "ussr" : null) === r ? t.evWargames : -t.evWargames;
		}
		if (n === 39) return e.milops[r] > e.milops[T[r]] ? t.evSummit : t.evSummitLow;
		if (n === 61) {
			let n = [
				"egypt",
				"iran",
				"libya",
				"saudiArabia",
				"iraq",
				"gulfStates",
				"venezuela"
			].filter((t) => Fr(e, t) === "ussr").length;
			return t.evPerBase + n * t.evPerUnit;
		}
		if (n === 78) {
			let n = [...O("centralAmerica"), ...O("southAmerica")].filter((t) => w[t].battleground && Fr(e, t) === "us").length;
			return t.evPerBase + n * t.evPerUnit;
		}
		if (n === 84) return t.evAldrich + Math.floor($(e, "libya").ussr / 2);
		if (n === 31 || n === 34) return t.evBigSix;
		if (n === 26 || n === 62 || n === 46 || n === 94) return t.evMid;
		let a = t.evBase + i.ops * t.evOpsW;
		return n === 30 && r === "ussr" && (a += t.evDecol), n === 33 && r === "ussr" && (a += t.evDestal), n === 40 && (a += t.evCuban), (n === 47 || n === 57) && (a += t.evMidBig), n === 49 && (a += t.evMidBig, e.defcon <= 3 && (a += t.meLowDefconPen)), n === 50 && r === "ussr" && (a += t.wwbyOpsBias), n === 4 && (a += (5 - e.defcon) * t.evDuckVpW), n === 10 && r === "ussr" && e.turn <= 2 && (a += t.evBlockadeEarly), n === 21 && (a += t.evNatoPen), n === 41 && D.some((t) => w[t].battleground && $(e, t).ussr > 0) && (a += t.evNSubs), n === 42 && (a += t.evQuagmire + (e.mods.norad ? t.evQuagmireNorad : 0)), n === 44 && e.mods.opsMinus === "ussr" && (a += t.evBearTrapCombo), n === 58 && (a += e.china.holder === "us" ? t.evCultRevChina : t.evCultRevSolo), n === 71 && e.china.holder === "ussr" && (a += t.evNixonChina), n === 76 && e.china.holder === "us" && e.china.faceUp && (a += t.evUssuriChina), n === 96 && (a += t.evTearDown), n === 16 && r === "ussr" && (a += t.evWarsawHold), n === 23 && r === "us" && (a += e.turn <= 2 ? t.evMarshallEarly : e.turn >= 6 ? -t.evMarshallEarly * .5 : 0), n === 27 && r === "us" && (a += t.evUsJapanPen), n === 34 && (a += t.evNtbPen), n === 46 && (a += t.evHiltsw), n === 59 && r === "ussr" && (a += t.evFlowerPen), n === 92 && (a += t.evTerror), n === 85 && r === "us" && (a += t.evStarWars), n === 86 && r === "us" && (a += t.evNorthSea), n === 107 && r === "ussr" && (a += t.evChe), n === 8 && r === "ussr" && e.turn >= 3 && (a += t.evFidelLate), n === 110 && r === "us" && !e.removed.includes(56) && Fr(e, "saudiArabia") === "ussr" && (a += t.evAwacsMr), n === 82 && r === "ussr" && Fr(e, "iran") === "us" && (a += t.evIhcIran), n === 87 && r === "ussr" && (a += t.evReformer), n === 90 && (a += e.removed.includes(87) ? t.evGlasnost : -t.evGlasnost), n === 95 && r === "ussr" && $(e, "brazil").us + $(e, "argentina").us >= 6 && (a += t.evLadcSa), n === 97 && r === "us" && (a += e.mods.flower ? t.evEvilEmpireFp : t.evEvilEmpirePen), n === 98 && r === "ussr" && (a += t.evAldrichLate), n === 108 && r === "us" && (a += t.evTehran), a;
	}
	function f(e, t, n) {
		return e.phase !== "ar" || e.current === t ? [] : e.mods.cuban && e.mods.cuban !== t ? n : e.defcon <= 2 && !(t === "us" && e.mods.nuclearSubs) ? n.filter((e) => w[e].battleground) : [];
	}
	function p(e, t, n, r, i = e.afterEvent) {
		let a = e.phase === "ar" && e.current !== t;
		if (e.mods.cuban && e.mods.cuban !== t && !a) return [];
		let o = i !== null && Kr({
			...e,
			defcon: e.defcon - 1
		}, i, t), s = (e.defcon <= 2 || o) && !(t === "us" && e.mods.nuclearSubs) && !a;
		return D.filter((i) => !(n && !n.includes(i) || !zr(e, i, t, r) || s && w[i].battleground));
	}
	let m = (e, n) => r(e, n) + (w[e].battleground ? t.bgBonus : 0);
	function h(e, n, r, i, a, o, s) {
		let c = w[n], l = $(e, n), u = T[r], d = c.regions, f = 0;
		e.mods.deathSquads && (d.includes("centralAmerica") || d.includes("southAmerica")) && (f += e.mods.deathSquads === r ? 1 : -1), e.mods.salt && --f, o === 6 && d.includes("asia") && (f += 1), e.mods.vietnam && r === "ussr" && d.includes("southeastAsia") && (f += 1);
		let p = (e) => {
			let n = e.us >= e.ussr + c.stability ? "us" : e.ussr >= e.us + c.stability ? "ussr" : null;
			return n === r ? t.ceCtrl : n === u ? -t.ceCtrl : 0;
		}, h = p(l), g = 0;
		for (let e = 1; e <= 6; e += 1) {
			let n = e + i + f - c.stability * 2;
			if (n <= 0) continue;
			let a = Math.min(n, l[u]), o = n - a, s = {
				us: l.us,
				ussr: l.ussr
			};
			s[u] -= a, s[r] += o, g += p(s) - h + a * t.ceRemInfW + o * t.ceAddInfW;
		}
		let _ = m(n, s) * (g / 6);
		return a || (_ += Math.min(i, Math.max(0, e.defcon - e.milops[r])) * t.ceMilopsW), c.battleground && !(r === "us" && e.mods.nuclearSubs) && (_ -= t.ceDefconW), r === "us" && e.mods.yuri && (_ -= t.ceYuri), _;
	}
	function g(e, i, a, o) {
		let s = $(e, i), c = T[a];
		if (s[c] === 0) return -1;
		let l = 0;
		for (let t of w[i].adjacent) if (t === a) l += 1;
		else if (t === c) --l;
		else {
			let n = Fr(e, t);
			n === a ? l += 1 : n === c && --l;
		}
		let u = (w[i].battleground ? t.reBg : t.reNb) + l * t.reAdvW - Math.max(0, s[c] - s[a] - 1) * t.reDeficitW;
		return Fr(e, i) === c && (u += t.reCtrl), u * Math.min(1.5, r(i, o) / r(i, n));
	}
	let _ = {
		ussr: t.setupUssrItaly ? [
			["poland", 4],
			["eastGermany", 4],
			["austria", 3],
			["yugoslavia", 3],
			["hungary", 3]
		] : [
			["poland", 4],
			["eastGermany", 4],
			["hungary", 3],
			["czechoslovakia", 3],
			["romania", 3]
		],
		us: t.setupUsWg4 ? [
			["westGermany", 4],
			["italy", 2],
			["greece", 1],
			["turkey", 1],
			["france", 1]
		] : [
			["westGermany", 5],
			["italy", 2],
			["greece", 1],
			["turkey", 1],
			["france", 1]
		]
	};
	function ee(e, n, r, i) {
		let a = at(n, e.setup.left, e.usBonus, e.influence);
		if (r) return Mr(a);
		if (n === "us" && e.setup.left <= e.usBonus) {
			let r = kr(e, n, i, t.europeCtrl, []);
			return Nr(a, (t) => r.add(e, t).value);
		}
		for (let [t, r] of _[n]) if ($(e, t)[n] < r) return t;
		return _[n][0][0];
	}
	function v(e, n, r, i) {
		let a = n.filter((t) => !C[t].noHeadline && !(e.civilWar && e.china.holder === null && (t === 58 || t === 35 || t === 31 && r === "ussr"))), o = a.filter((t) => !Kr(e, t, r)), c = o.length > 0 ? o : a;
		if (c.length === 0) return n[0];
		if (i) return Mr(c);
		let l = (n) => {
			let i = C[n];
			if (i.scoring) return t.hlScBase + s(e, n, r) * t.hlScW;
			if (i.side === T[r]) return n === 62 && r === "us" ? e.defcon <= 2 ? t.hlSuicide : t.hlOppEscape : t.hlOppBase + i.ops * t.hlOppOpsW;
			if (Wr.includes(n) && e.defcon <= 2 || n === 20 && e.defcon <= 2) return t.hlSuicide;
			if (n === 10 && r === "ussr") return t.hlBlockadePen;
			if (!Ur(e, n, r) || n === 26 && r === "us" && e.turn < 7) return i.ops * t.hlNoFireOpsW;
			let a = t.hlBase + i.ops * t.hlOpsW;
			return (n === 30 || n === 33) && r === "ussr" && e.turn <= 3 && (a += t.hlDefectorsPen), (n === 40 || n === 47 || n === 57) && (a += t.hlMidBig), n === 49 && (a += e.defcon <= 3 ? t.meLowDefconPen : t.hlMidBig), n === 31 && (a += t.hlRedScare), n === 23 && r === "us" && e.turn <= 2 && (a += t.hlMarshall), n === 25 && r === "us" && (a += t.hlContainment), n === 46 && (a += t.hlHiltsw), n === 89 && r === "us" && (a += t.hlKal), n === 92 && (a += t.hlTerror), n === 94 && r === "us" && (a += t.hlChernobyl), n === 86 && r === "us" && (a += t.hlNorthSea), n === 28 && r === "ussr" && e.turn <= 2 && (a += t.hlSuez), n === 98 && r === "ussr" && (a += t.hlAldrich), n === 90 && r === "ussr" && e.removed.includes(87) && (a += t.hlGlasnost), n === 104 && r === "ussr" && (a += [
				3,
				6,
				7
			].includes(e.turn) ? t.hlCambridge * 2 : t.hlCambridge), a;
		}, d = u(e, n, r), f = c.filter((e) => e !== d && l(e) > t.hlSuicide);
		return Nr(f.length ? f : c, l);
	}
	function y(e, n, r, i) {
		let a = 0;
		for (let t of w[r].adjacent) t !== "us" && t !== "ussr" && Fr(e, t) === T[i] && (a += 1);
		n === 13 && Fr(e, r) === T[i] && (a += 1), n === 11 && i === "ussr" && e.civilWar && e.china.holder === null && (a += 1);
		let o = Math.max(0, 6 - ((n === 36 ? 3 : 4) + a) + 1);
		return o * t.warFaceW + (o > 0 && $(e, r)[T[i]] > 0 && w[r].battleground ? t.warBg : 0);
	}
	function b(e, n, r, i, o) {
		let s = n.target;
		if (n.mode === "add" && s === r) {
			let a = Ar(e, r, i, t.europeCtrl, o, () => !1, n, (e) => (n.card === 30 && w[e].regions.includes("africa") ? t.decolAfricaBonus : 0) + (n.card === 33 && w[e].regions.includes("centralAmerica") ? t.destalAvoidCA : 0));
			if (a) return a.country;
		}
		let l = (l) => {
			switch (n.mode) {
				case "add": {
					let a = s === r ? c(e, l, r, i, o, n.amt ?? 1) : -c(e, l, s, i, o, n.amt ?? 1);
					return n.card === 30 && w[l].regions.includes("africa") && (a += t.decolAfricaBonus), n.card === 33 && w[l].regions.includes("centralAmerica") && (a += t.destalAvoidCA), a;
				}
				case "remove":
				case "removeAll": return s === r ? -a(e, l, r, i) : a(e, l, s, i);
				case "double": return c(e, l, s, i, o, $(e, l)[s]);
				case "match": return $(e, l).ussr;
				case "war": return y(e, n.card, l, s);
			}
		}, u = Nr(n.pool, l);
		if (n.mode !== "war") return u;
		let d = l(u);
		return Nr(n.pool.filter((e) => l(e) === d), (t) => $(e, t)[T[s]]);
	}
	function x(e, t, n, r, i) {
		let a = e.slice(0, r);
		if (a.length >= n) return a;
		let o = t.filter((e) => !a.includes(e)).sort((e, t) => i(e) - i(t));
		return [...a, ...o].slice(0, n);
	}
	function te(e, n, r, i, a) {
		let o = n.pendingPool ?? [];
		if (o.length === 0) return [];
		let s = r.min, c = r.max;
		if (a) {
			let e = Math.min(c, Math.max(s, jr(c + 1))), t = [...o];
			for (let e = t.length - 1; e > 0; --e) {
				let n = jr(e + 1);
				[t[e], t[n]] = [t[n], t[e]];
			}
			return t.slice(0, e);
		}
		let f = u(e, n.hand, i), p = (t) => t === f ? Infinity : l(e, t, i);
		switch (r.card) {
			case 10: return $(e, "westGermany").us > 0 ? [Pr(o, (t) => l(e, t, i))] : [];
			case 95: {
				let e = Pr(o, p);
				return p(e) <= t.ditchMaxKeep ? [e] : [];
			}
			case 43:
			case 85: {
				let e = Nr(o, p);
				return p(e) >= t.rescueMinKeep || s > 0 ? [e] : [];
			}
			case 77: return x(o.filter((e) => p(e) < t.dumpBelowKeep), o, s, c, p);
			case 98: return [Nr(o, (t) => l(e, t, "us"))];
			case 108: return x(o.filter((e) => C[e].side === T[i] || !!C[e].scoring), o, s, c, p);
			case 49: {
				let t = o.filter((e) => C[e].side === i);
				return t.length > 0 ? [Pr(t, p)] : [Pr(o, (t) => d(e, t, T[i]))];
			}
			case 0: {
				let e = Pr(o, p);
				return c >= 1 && (e !== f || s > 0) ? [e] : [];
			}
			default: return o.slice(0, s);
		}
	}
	function ne(e, n, r, i) {
		let a = n.options;
		if (i) return Mr(a);
		let o = (e) => a.includes(e);
		if (o("influence")) return o("coup") && f(e, r, p(e, r, null, !1)).length > 0 || o("coup") && e.milops[r] < e.defcon && p(e, r, null, !1).length > 0 ? "coup" : "influence";
		if (o("coup") || o("realign")) return n.card === 96 && o("realign") ? "realign" : o("coup") ? "coup" : a[0];
		if (o("participate")) return e.defcon <= 2 ? "boycott" : "participate";
		if (o("improve")) return e.defcon <= 3 ? "improve" : "noChange";
		if (o("5")) return "5";
		if (o("sa2")) return "sa1ang2";
		if (o("use") || o("return")) return o("un") ? "un" : "use";
		if (o("remove") && o("add")) {
			let n = O("easternEurope"), r = n.reduce((t, n) => t + $(e, n).us, 0);
			return n.some((t) => Fr(e, t) === "us") || r >= t.warsawRemoveInf ? "remove" : "add";
		}
		return o("europe") || o("asia") || o("middleEast") ? Nr(a, (t) => O(t).filter((t) => $(e, t).ussr > 0).length) : o("turkey") ? "turkey" : a[0];
	}
	function S(e, n, r, a) {
		let o = T[r], c = (e) => C[e].side === o && !C[e].scoring, f = u(e, n.hand, r), m = n.hand.filter((e) => e !== f), g = m.some((t) => !C[t].scoring && (!(e.defcon <= 2 && (c(t) && Gr(t, r) || t === 20) || e.defcon <= 3 && t === 49) || Hr(e, r, Ir(e, r, C[t].ops)))) || n.chinaReady ? m : n.hand, _ = g.filter(c), ee = g.filter((e) => !C[e].scoring), v = ee.filter((t) => !Kr(e, t, r)), y = (t) => Ir(e, r, t === 6 ? 4 : C[t].ops), b = (t) => Pr(t, (t) => l(e, t, r)), x = r === "ussr" && e.turn === 1 || e.turn >= 10, te = g.find((t) => Kr(e, t, r));
		if (te !== void 0 && g.includes(32)) return Q({
			type: "play",
			card: 32,
			mode: "event",
			withCard: te
		});
		if (r === "us" && $(e, "westGermany").us > 0 && g.includes(10) && g.includes(32)) return Q({
			type: "play",
			card: 32,
			mode: "event",
			withCard: 10
		});
		let ne = (t) => t === 20 && e.defcon <= 2 || t === 49 && e.defcon <= 3, S = (e) => (e !== 77 || r !== "ussr") && (e !== 28 || r !== "us"), re = g.filter((t) => (c(t) && S(t) || ne(t)) && Hr(e, r, y(t)));
		if (re.length > 0) return Q({
			type: "play",
			card: b(re),
			mode: "space"
		});
		let ie = () => {
			let t = 0;
			for (let n of D) {
				let o = w[n].adjacent.includes(r), s = $(e, n)[r] > 0 || w[n].adjacent.some((t) => t !== "us" && t !== "ussr" && $(e, t)[r] > 0);
				if (!o && !s) continue;
				let c = i(e, n, r, a);
				c > t && (t = c);
			}
			return t;
		};
		{
			let i = n.chinaReady && !x ? [...v, 6] : v;
			if (i.length > 0) {
				let n = b(i), o = y(n), s = p(e, r, null, !1, n);
				if (s.length > 0 && h(e, Nr(s, (t) => h(e, t, r, o, !1, n, a)), r, o, !1, n, a) >= ie() * o * t.infRefW + t.coupBias) return Q({
					type: "play",
					card: n,
					mode: "coup"
				});
			}
		}
		let ae = g.filter((t) => {
			let n = C[t];
			return !n.scoring && n.side !== o && t !== 32 && Ur(e, t, r);
		});
		if (ae.length > 0) {
			let n = Nr(ae, (t) => d(e, t, r));
			if (d(e, n, r) >= t.evFireThreshold) return Q({
				type: "play",
				card: n,
				mode: "event"
			});
		}
		if (g.includes(32) && _.length > 0) return Q({
			type: "play",
			card: 32,
			mode: "event",
			withCard: Nr(_, y)
		});
		if (!x && n.chinaReady && O("asia").some((t) => w[t].battleground && Fr(e, t) !== r)) return Q({
			type: "play",
			card: 6,
			mode: "influence"
		});
		let oe = v.filter((t) => !(c(t) && Gr(t, r) && e.defcon <= 2));
		if (oe.length > 0) return Q({
			type: "play",
			card: b(oe),
			mode: "influence"
		});
		if (n.chinaReady) return Q({
			type: "play",
			card: 6,
			mode: "influence"
		});
		let se = g.filter((e) => C[e].scoring);
		return se.length > 0 ? Q({
			type: "play",
			card: Nr(se, (t) => s(e, t, r)),
			mode: "event"
		}) : ee.length > 0 ? Q({
			type: "play",
			card: b(ee),
			mode: "influence"
		}) : Q({ type: "passAr" });
	}
	function re(e, t, n) {
		let r = t.hand.find((t) => Kr(e, t, n));
		if (r !== void 0 && t.hand.includes(32)) return Q({
			type: "play",
			card: 32,
			mode: "event",
			withCard: r
		});
		let i = t.chinaReady ? [...t.hand, 6] : [...t.hand], a = i.filter((t) => !Kr(e, t, n) || Hr(e, n, Ir(e, n, C[t].ops))), o = a.length > 0 ? a : i;
		if (o.length === 0) return Q({ type: "passAr" });
		let s = Mr(o), c = C[s];
		if (c.scoring) return Q({
			type: "play",
			card: s,
			mode: "event"
		});
		let l = Ir(e, n, s === 6 ? 4 : c.ops);
		if (Kr(e, s, n) && Hr(e, n, l)) return Q({
			type: "play",
			card: s,
			mode: "space"
		});
		let u = ["influence"];
		return s !== 6 && s !== 32 && c.side !== T[n] && Ur(e, s, n) && u.push("event"), Hr(e, n, l) && u.push("space"), e.defcon > 2 && p(e, n, null, !1, s).length > 0 && u.push("coup"), Q({
			type: "play",
			card: s,
			mode: Mr(u)
		});
	}
	return (e, r) => {
		let i = e.public, a = e.private;
		if (!a || i.over) return null;
		let o = i.seats.us === r.rid ? "us" : i.seats.ussr === r.rid ? "ussr" : null;
		if (!o) return null;
		let c = r.difficulty === "weak", d = T[o], _ = Tr(i, a.hand, n, {
			available: t.scoringAvailableBonus,
			held: t.scoringHeldBonus,
			final: t.scoringFinalBonus
		});
		if (i.pending) {
			if (i.pending.side !== o) return null;
			let e = i.pending;
			return e.kind === "option" ? Q({
				type: "pickOption",
				option: ne(i, e, o, c)
			}) : e.kind === "cards" ? Q({
				type: "pickCards",
				cards: te(i, a, e, o, c)
			}) : e.n <= 0 || e.pool.length === 0 ? Q({
				type: "pickCountries",
				countries: []
			}) : Q({
				type: "pickCountries",
				countries: [c ? Mr(e.pool) : b(i, e, o, _, a.hand)]
			});
		}
		if (i.coup) {
			if (i.coup.side !== o) return null;
			let e = i.coup, n = lt(i, o);
			if (i.current === o && n.length) return Q({
				type: "cancelCuban",
				country: n.includes("turkey") ? "turkey" : n[0]
			});
			let r = p(i, o, e.restricted, e.free);
			if (r.length > 0) {
				let n;
				if (c) n = Mr(r);
				else {
					let a = f(i, o, r);
					if (a.length > 0) return Q({
						type: "coupAt",
						country: Nr(a, (e) => m(e, _))
					});
					let s = (t) => h(i, t, o, e.ops, e.free, e.card, _), c = Nr(r, s);
					if (s(c) <= t.ceAbort && e.free) return Q({ type: "finishOps" });
					n = s(c) > t.ceAbort ? c : Pr(r, (e) => w[e].stability);
				}
				return Q({
					type: "coupAt",
					country: n
				});
			}
			return e.free ? Q({ type: "finishOps" }) : null;
		}
		if (i.spending) {
			if (i.spending.side !== o) return null;
			let e = i.spending;
			if (e.mode === "influence") {
				let n = [...D, "chineseCivilWar"].filter((t) => Vr(i, t, o, e.snapshot, e.restricted, e.opsLeft));
				if (n.length === 0) return Q({ type: "finishOps" });
				let r = c ? null : Ar(i, o, _, t.europeCtrl, a.hand, (e, t, n) => Vr(e, t, o, n.snapshot, n.restricted, n.opsLeft));
				return Q({
					type: "place",
					country: c ? Mr(n) : r?.country ?? n[0]
				});
			}
			let n = D.filter((t) => (!e.restricted || e.restricted.includes(t)) && Br(i, t, o, e.free)), r = c ? n.length > 0 ? Mr(n) : null : n.length > 0 ? Nr(n, (e) => g(i, e, o, _)) : null;
			return r && (c || g(i, r, o, _) > t.reThreshold) ? Q({
				type: "realignAt",
				country: r
			}) : Q({ type: "finishOps" });
		}
		if (i.phase === "setup" && i.setup && i.setup.step === o) return Q({
			type: "setupPlace",
			country: ee(i, o, c, _)
		});
		if (i.phase === "headline" && i.headline) return (o === "us" ? i.headline.usReady : i.headline.ussrReady) ? null : Q({
			type: "headline",
			card: v(i, a.hand, o, c)
		});
		if (i.phase !== "ar" || i.current !== o) return null;
		let y = a.hand;
		if (i.trapNow) {
			let e = y.filter((e) => !C[e].scoring && Ir(i, o, C[e].ops) >= 2);
			if (e.length > 0) {
				let t = u(i, y, o);
				return Q({
					type: "trapDiscard",
					card: c ? Mr(e) : Pr(e, (e) => e === t ? Infinity : l(i, e, o))
				});
			}
			let t = y.filter((e) => C[e].scoring);
			return t.length > 0 ? Q({
				type: "play",
				card: c ? Mr(t) : Nr(t, (e) => s(i, e, o)),
				mode: "event"
			}) : Q({ type: "passAr" });
		}
		if (i.mustOps[o] !== null) {
			let e = i.mustOps[o];
			return i.milops[o] < i.defcon && p(i, o, null, !1).length > 0 ? Q({
				type: "play",
				card: e,
				mode: "coup"
			}) : Q({
				type: "play",
				card: e,
				mode: "influence"
			});
		}
		if (i.mods.bury && o === "us" && y.includes(32)) {
			let e = y.find((e) => Kr(i, e, o)) ?? y.find((e) => C[e].side === d);
			if (e !== void 0) return Q({
				type: "play",
				card: 32,
				mode: "event",
				withCard: e
			});
		}
		let x = y.filter((e) => C[e].scoring), ie = i.arTotal[o] - i.arDone[o];
		if (x.length >= ie && x.length > 0) return Q({
			type: "play",
			card: c ? Mr(x) : Nr(x, (e) => s(i, e, o)),
			mode: "event"
		});
		if (i.mods.cuban && i.mods.cuban !== o) {
			let e = lt(i, o);
			if (e.length) return Q({
				type: "cancelCuban",
				country: e.includes("turkey") ? "turkey" : e[0]
			});
		}
		return c ? re(i, a, o) : S(i, a, o, _);
	};
}
var Xr = Yr();
//#endregion
//#region src/games/twilightstruggle/game-over.tsx
function Zr({ result: e, public: t, private: n, members: r, myRid: i, onPlayAgain: c, onBackToLobby: l, hintCount: u }) {
	let d = o(), [f, p] = a(!1), m = t, h = vt.safeParse(n);
	return /* @__PURE__ */ y("div", {
		className: "ts-final-view",
		children: [/* @__PURE__ */ v("div", {
			className: `ts-final-board ${f ? "is-behind" : ""}`,
			children: /* @__PURE__ */ v(Qn, {
				pub: m,
				priv: h.success ? h.data : void 0,
				myRid: i,
				onShowResult: () => p(!0)
			})
		}), f && /* @__PURE__ */ y("div", {
			className: "ts-final-summary",
			children: [/* @__PURE__ */ v(b, {
				result: e,
				members: r,
				myRid: i,
				accent: tt.accent,
				onPlayAgain: c,
				onBackToLobby: l,
				hintCount: u
			}), /* @__PURE__ */ y("button", {
				type: "button",
				className: "ts-final-back",
				"aria-label": d("games.twilightstruggle.backToSituation"),
				onClick: () => p(!1),
				children: [/* @__PURE__ */ v(s, { size: 18 }), d("games.twilightstruggle.backToSituationShort")]
			})]
		})]
	});
}
//#endregion
//#region src/games/twilightstruggle/options.tsx
var Qr = {
	random: "games.twilightstruggle.optSideRandom",
	us: "games.twilightstruggle.optSideUs",
	ussr: "games.twilightstruggle.optSideUssr"
};
function $r({ value: e, onChange: t }) {
	let n = o(), r = ut.safeParse(e), i = r.success ? r.data : ut.parse(void 0);
	return /* @__PURE__ */ y("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ v(te, {
				title: n("games.twilightstruggle.optSide"),
				columns: 3,
				children: [
					"random",
					"us",
					"ussr"
				].map((e) => /* @__PURE__ */ v(x, {
					name: "twilight-side",
					value: e,
					checked: i.hostSide === e,
					label: n(Qr[e]),
					accent: tt.accent,
					onChange: () => t({
						...i,
						hostSide: e
					})
				}, e))
			}),
			/* @__PURE__ */ y("div", { children: [
				/* @__PURE__ */ v("p", {
					className: "section-label",
					children: n("games.twilightstruggle.optUsBonus")
				}),
				/* @__PURE__ */ v("p", {
					className: "mb-2 text-xs text-ink/65",
					children: n("games.twilightstruggle.optUsBonusHint")
				}),
				/* @__PURE__ */ v("div", {
					className: "grid grid-cols-5 gap-1",
					children: [
						0,
						1,
						2,
						3,
						4
					].map((e) => /* @__PURE__ */ v(x, {
						name: "twilight-us-bonus",
						value: String(e),
						checked: i.usBonus === e,
						label: `+${e}`,
						accent: tt.accent,
						onChange: () => t({
							...i,
							usBonus: e
						})
					}, e))
				})
			] }),
			/* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v(ne, {
				checked: i.civilWar,
				label: n("games.twilightstruggle.optCivilWar"),
				hint: n("games.twilightstruggle.optCivilWarHint"),
				accent: tt.accent,
				onChange: () => t({
					...i,
					civilWar: !i.civilWar
				})
			}), /* @__PURE__ */ y("details", {
				className: "mt-1 text-sm text-ink/85",
				children: [/* @__PURE__ */ v("summary", {
					className: "min-h-11 cursor-pointer py-3 font-semibold",
					children: n("games.twilightstruggle.optCivilWarRules")
				}), /* @__PURE__ */ v("p", {
					className: "pb-3 leading-relaxed",
					children: n("games.twilightstruggle.optCivilWarRulesText")
				})]
			})] }),
			/* @__PURE__ */ v(ne, {
				checked: i.optionalCards,
				label: n("games.twilightstruggle.optCards"),
				hint: n("games.twilightstruggle.optCardsHint"),
				accent: tt.accent,
				onChange: () => t({
					...i,
					optionalCards: !i.optionalCards
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/twilightstruggle/entry.tsx
var ei = {
	definition: Yt,
	View: Zn,
	bot: Xr,
	OverView: Zr,
	Options: $r,
	locales: {
		zh: {
			name: "冷战热斗",
			desc: "扮演美国或苏联,用影响力、政变与事件争夺全球;别让世界陷入核战",
			rules: "目标:扮演美国或苏联,通过区域计分与事件获得胜利分。\n达成以下任一条件时，立即获胜：\n· 率先达到 20 分。\n· 使对手引发核战争。\n· 在欧洲计分时控制欧洲。\n准备:\n· 苏联先放置开局影响力:东欧 6 点;随后美国在西欧放置 7 点。\n· 早期牌堆洗匀,每人发 8 张牌;中国牌正面朝上置于苏联玩家面前。\n流程:每回合先进行头条阶段,双方各暗选一张牌同时亮出,行动值高者的事件先结算;随后苏联先手,双方交替进行行动轮。\n· 行动轮打出一张牌:触发自己或双方的事件,或作为行动值用于放置影响力、发动政变、进行重调、推进太空竞赛。\n· 打出带有对手事件的牌时事件仍会发生,由你决定先结算事件还是先使用行动值。\n· 在战场国发动政变会使 DEFCON 下降 1 级;DEFCON 限制政变与重调的区域。\n· DEFCON 降至 1 时,导致其下降的一方立即输掉游戏。\n· 每回合结束时,军事行动轨未达 DEFCON 需求值的一方,让对手获得差值的胜利分。\n结束:第 10 回合结束后对所有区域计分,中国牌持有者获得 1 分,胜利分高者胜;平分为平局。",
			phaseSetupPlace: "开局布置:点击高亮国家放置影响力(剩余 {{n}} 点)",
			phaseSetupWait: "等待对手布置开局影响力…",
			phaseHeadline: "头条阶段:选择一张牌作为头条",
			phaseHeadlineWait: "等待对手选择头条…",
			phaseAR: "行动轮:打出一张牌",
			phaseARWait: "等待对手行动…",
			phaseTurnEnd: "回合结算中…",
			phaseTrap: "{{card}}:弃置一张行动值不低于 2 的牌并掷骰,掷出 1 至 4 才能解除",
			phaseGameOver: "本局结束",
			modeEvent: "作为事件",
			modeOps: "作为行动值",
			modeInfluence: "放置影响力",
			modeCoup: "政变",
			modeRealign: "重调",
			modeSpace: "太空竞赛",
			eventFirstQ: "这张牌带有对手事件,选择结算顺序",
			eventFirst: "先结算事件",
			opsFirst: "先用行动值",
			opsLeft: "剩余 {{n}} 点行动值",
			influenceDraft: "预分配影响力 · 尚未确认",
			submittingInfluence: "正在确认分配…",
			undoInfluence: "撤回上一点",
			confirmInfluence: "确认分配",
			draftSetup: "开局预分配 · 尚未确认",
			draftEvent: "事件预分配 · 尚未确认",
			draftDestalRemove: "去斯大林化 · 预选移除",
			draftDestalAdd: "去斯大林化 · 预选放置",
			draftPointsLeft: "剩余 {{n}} 点",
			undoChoice: "撤回上一项",
			continueRedistribution: "继续重新放置",
			backToRemoval: "返回移除",
			warningTitle: "确认自动结算后果",
			warningCancel: "返回调整",
			warningProceed: "仍要执行",
			warningNuclear: "此操作会引发核战并立即结束对局。按行动方追责，{{side}}将被判负。",
			warningNuclearRisk: "此操作的事件或后续选择可能引发核战。一旦 DEFCON 降至 1，按行动方追责，{{side}}将被判负。",
			warningNuclearUncertain: "此操作的事件或后续选择可能引发核战，并立即结束对局。请确认能够接受这一风险后再执行。",
			warningWargames: "战争游戏将先让对手获得 6 分，然后立即结束对局。按当前局面结算：{{result}}。",
			warningScoring: "按当前局面计分将直接结束对局：{{result}}。",
			warningWinner: "{{side}}获胜",
			warningDraw: "平局",
			warningHeldScoring: "按当前行动轮安排，这是你本回合最后一次出牌机会，手中仍有：{{cards}}。若未获得额外行动轮，且回合结束时仍持有计分牌，将触发持牌判负。",
			warningBlockade: "你没有选择弃牌。确认后，“封锁”会自动清空西德的全部 {{n}} 点美国影响力。",
			confirm: "确认",
			cancel: "取消",
			finishRealign: "结束重调",
			spaceAttempt: "掷骰推进(需要 ≤{{n}})",
			spaceUsedUp: "本回合太空竞赛次数已用完",
			cannotSpace: "此牌行动值不足以推进太空竞赛",
			turnLabel: "回合 {{n}}/10",
			arLabel: "行动轮 {{n}}",
			defconLabel: "DEFCON",
			defconAlert: "警戒",
			vpLabel: "胜利分",
			milopsLabel: "军事行动",
			spaceLabel: "太空竞赛",
			optSide: "主机执掌阵营",
			optSideRandom: "随机",
			optSideUs: "美国",
			optSideUssr: "苏联",
			optCards: "豪华版可选牌",
			optCardsHint: "加入可选事件牌",
			optCivilWar: "国共内战变体",
			optCivilWarHint: "苏联须先在国共内战格放满 3 点影响力，才能取得中国牌",
			optCivilWarRules: "查看变体完整规则",
			optCivilWarRulesText: "国共内战格与苏联本土相邻，位于亚洲但不属于东南亚，也不参与区域计分。仅苏联可用行动值在此放置影响力；达到 3 点后立即取得正面朝上的中国牌，该格此后不再生效。取得中国牌前，苏联不能触发「红色恐慌／大清洗」和「文化大革命」，美国不能触发「台湾决议案」，但这些牌仍可用于行动值。此期间，美国打出「尼克松打中国牌」或「乌苏里江冲突」事件时视为持有中国牌；苏联进行朝鲜战争掷骰时额外减 1。若终局仍无人取得中国牌，则无人获得持牌的 1 分。",
			optUsBonus: "美国开局额外影响力",
			optUsBonusHint: "常规 7 点限西欧；额外点可放西欧或已有美国影响力的国家",
			phaseSetupPlaceBonus: "开局布置（美国额外 +{{bonus}}）：点击高亮国家放置影响力（剩余 {{n}} 点）",
			spaceDetailsTitle: "太空竞赛详情",
			spaceStepReq: "需要 {{ops}} 点行动值 · 骰点 1–{{roll}} 成功",
			spaceStepVp: "先到 {{first}} 分 · 后到 {{second}} 分",
			spaceBonusRule: "特殊能力仅先到该格的一方持有；对手到达同格后失效。",
			spaceBonus2: "每回合可用至多 2 张牌尝试推进太空竞赛。",
			spaceBonus4: "对手先公开头条牌，你再选择自己的头条牌。",
			spaceBonus6: "回合结束时可弃掉保留的一张牌。",
			spaceBonus8: "每回合可进行第 8 行动轮。",
			trumanPick: "杜鲁门主义：选一个双方均未控制的欧洲国家，移除其全部苏联影响力",
			noradPick: "北美防空司令部：在已有美国影响力的国家增加 1 点",
			effectsButton: "效果 {{n}}",
			effectsTitle: "当前生效效果",
			effectsTurn: "本回合",
			effectsLasting: "持续生效",
			effectsEmpty: "当前没有持续效果",
			cardFateRemoved: "事件发生后移出游戏",
			cardFateDiscard: "事件发生后进入弃牌堆",
			cardFateChina: "打出后移交对手",
			cardFateShuttle: "事件生效后暂留，结算亚洲或中东后移出游戏",
			cardFateMissile: "事件生效后交给对手，下次作为行动值打出后进弃牌堆",
			cardFateShortRemoved: "移出",
			cardFateShortDiscard: "弃牌",
			cardFateShortChina: "移交",
			cardFateShortShuttle: "暂留",
			cardFateShortMissile: "移交",
			chinaCardLabel: "中国牌",
			chinaUnclaimed: "尚未取得",
			chinaHeld: "持有中国牌",
			chinaFaceDown: "中国牌(本回合不可用)",
			chinaFaceUp: "正面",
			chinaFaceDownShort: "背面",
			deckCount: "牌堆余 {{n}}",
			discardLabel: "弃牌堆 {{n}}",
			handLabel: "手牌 {{n}} 张",
			opponentEventShort: "对手事件",
			mustPlayShort: "必须打出",
			specialCardShort: "特殊卡牌",
			mustPlayScoring: "计分牌不可保留,必须打出",
			trappedSkip: "无法弃牌,被迫打出全部计分牌并跳过本回合剩余行动轮",
			chooseCountryOne: "选择一个国家",
			chooseCountriesN: "选择 {{n}} 个国家",
			chooseCardOne: "选择一张牌",
			chooseCardsDiscard: "选择要弃置的牌({{n}} 张)",
			chooseCardsFree: "选择要弃置的牌(至多 {{n}} 张)",
			cardsSelectedN: "已选 {{n}} 张",
			cardDetails: "查看{{card}}的详情",
			chooseOption: "做出选择",
			placeN: "分配影响力(剩余 {{n}} 点)",
			removeN: "移除影响力(剩余 {{n}} 点)",
			skip: "跳过",
			boycott: "抵制",
			participate: "参加",
			optImprove: "DEFCON 上升 1 级",
			optDegrade: "DEFCON 下降 1 级",
			optNoChange: "不变",
			playIt: "打出此牌",
			returnIt: "归还此牌",
			optRemoveUs: "移除美国影响力",
			optAddUssr: "增加苏联影响力",
			optUn: "以联合国干预取消",
			sa2: "南非增加 2 点",
			sa1ang2: "南非 +1,安哥拉 +2",
			sa1bot2: "南非 +1,博茨瓦纳 +2",
			sa1ang1bot1: "南非 +1,安哥拉 +1,博茨瓦纳 +1",
			cancelCuban: "取消古巴导弹危机",
			cancelCubanShort: "解除导弹危机",
			cancelCubanHint: "选择移除本方 2 点影响力的国家。解除不消耗行动轮，当前操作会继续。",
			cancelCubanInsufficient: "不足 2 点影响力",
			cancelCubanChoose: "请选择支付国家",
			cancelCubanConfirm: "移除{{country}}2点影响力并解除",
			cancelCubanSubmitting: "正在解除…",
			grainDrawnCard: "向苏联出售粮食 · 抽到的牌",
			draftReset: "局面已变化，未确认的分配已清空，请重新分配。",
			passAr: "跳过本行动轮",
			chinaCard: "中国牌",
			youAre: "你操控:{{side}}",
			sideUs: "美国",
			sideUssr: "苏联",
			sideUsShort: "美",
			sideUssrShort: "苏",
			oppHandRevealed: "对手手牌(已公开)",
			headlineOppSeen: "对手已选头条:{{card}}",
			stabLabel: "稳定 {{n}}",
			bgLabel: "战场国",
			selectedN: "已选 {{n}} 次",
			listOpen: "国家列表",
			mapWorldSituation: "世界局势",
			zoomCycle: "切换缩放级别",
			playHeadline: "作为头条打出",
			trapDiscardAction: "弃牌并掷骰",
			milopsReq: "需求 {{n}} 点",
			influenceLabel: "影响力",
			controlUs: "美国控制",
			controlUssr: "苏联控制",
			contested: "争夺中",
			uncontrolled: "未控制",
			legalTarget: "可选目标",
			neighborsLabel: "相邻:{{list}}",
			opsTag: "行动值 {{n}}",
			sideTagUs: "美国事件",
			sideTagUssr: "苏联事件",
			sideTagBoth: "双方事件",
			sideTagScoring: "计分牌",
			close: "关闭",
			scoreTitle: "{{region}}计分",
			presence: "存在",
			domination: "支配",
			control: "控制",
			battlegroundBonus: "战场国",
			adjacencyBonus: "邻近敌国本土",
			autoVictory: "直接获胜",
			scorePoints: "{{n}}分",
			logHeadline: "头条:{{us}} / {{ussr}}",
			logPlay: "{{name}}打出「{{card}}」({{mode}})",
			logUnIntervention: "{{name}}打出「{{card}}」，搭配「{{withCard}}」使用行动值",
			logDiscardForEvent: "{{name}}因「{{event}}」弃置「{{card}}」",
			logNoDiscardForEvent: "{{name}}未因「{{event}}」弃牌",
			logMissileEnvyExchange: "{{name}}通过「{{event}}」换得「{{card}}」",
			logSaltRetrieve: "{{name}}通过「{{event}}」从弃牌堆收回「{{card}}」",
			logGrainDraw: "{{name}}通过「{{event}}」从苏联手牌中抽到「{{card}}」",
			logGrainUse: "{{name}}选择打出「{{event}}」抽到的「{{card}}」",
			logGrainReturn: "{{name}}将「{{event}}」抽到的「{{card}}」归还给苏联",
			logGrainUn: "{{name}}搭配「{{un}}」使用「{{event}}」抽到的「{{card}}」的行动值",
			viewResults: "查看结算",
			viewResultsShort: "结算",
			backToSituation: "返回局势",
			backToSituationShort: "局势",
			logScore: "{{region}}计分:美国 {{us}} 分,苏联 {{ussr}} 分",
			logCoup: "{{name}}政变{{country}}:掷出 {{roll}},{{result}}",
			logCoupSuccess: "成功",
			logCoupFail: "失败",
			logRealign: "{{name}}重调{{country}}:{{usRoll}} 比 {{ussrRoll}},{{result}}",
			logRealignRemoved: "移除对方影响力 {{n}} 点",
			logRealignNone: "无变动",
			logSpace: "{{name}}推进太空竞赛:掷出 {{roll}},{{result}}",
			logSpaceOk: "成功",
			logSpaceFail: "失败",
			logDefcon: "DEFCON 降至 {{n}}",
			logMilops: "军事行动结算:{{name}}差 {{n}} 点,对手获得 {{n}} 分",
			logTurn: "第 {{n}} 回合开始",
			logWar: "「{{card}}」战争:{{name}}在{{country}}掷出 {{roll}},{{result}}",
			logTrap: "{{name}}进行陷阱判定:掷出 {{roll}},{{result}}",
			logTrapSkip: "{{name}}因「{{card}}」无法弃置符合条件的牌，跳过本行动轮",
			logTrapEscape: "成功摆脱",
			logTrapCaught: "未能摆脱",
			logOver: "对局结束:{{name}}获胜({{reason}})",
			logOverDraw: "对局结束:平局",
			logEmpty: "对局尚未开始",
			logTitle: "对局记录",
			winVP: "率先达到 20 分",
			winEurope: "控制欧洲",
			winNuclear: "对手引发核战",
			winScoringHeld: "对手持有了计分牌",
			winWargames: "战争游戏结束",
			winFinal: "终局计分获胜",
			winDraw: "平局",
			winCuban: "对手在古巴导弹危机期间发动政变",
			errNotYourTurn: "现在轮不到你",
			errBadCard: "手里没有这张牌",
			errBadMode: "这张牌不能这样打出",
			errBadTarget: "这个目标选不了",
			errBadAlloc: "影响力分配不合法",
			errDefcon: "当前 DEFCON 等级不允许在此区域政变或重调",
			errNoCoupTarget: "政变目标必须有对手影响力",
			errPending: "先完成当前选择",
			errHeadline: "这张牌不能作为头条",
			errTrap: "必须先处理当前的强制弃牌",
			errNato: "北约保护下的国家不能被政变或重调",
			errChernobyl: "本回合不能向该区域放置影响力",
			errReformer: "改革者事件后苏联不能在欧洲政变",
			errOps: "行动值不足",
			errSetup: "只能在当前开局阶段的合法国家放置",
			region: {
				europe: "欧洲",
				westernEurope: "西欧",
				easternEurope: "东欧",
				asia: "亚洲",
				southeastAsia: "东南亚",
				middleEast: "中东",
				africa: "非洲",
				centralAmerica: "中美洲",
				southAmerica: "南美洲"
			},
			spaceTrack: {
				s0: "起点",
				s1: "人造卫星",
				s2: "动物入太空",
				s3: "载人航天",
				s4: "载人地球轨道",
				s5: "绕月轨道",
				s6: "鹰／熊已登陆",
				s7: "航天飞机",
				s8: "空间站"
			},
			country: {
				us: "美国",
				ussr: "苏联",
				afghanistan: "阿富汗",
				algeria: "阿尔及利亚",
				angola: "安哥拉",
				argentina: "阿根廷",
				australia: "澳大利亚",
				austria: "奥地利",
				benelux: "比荷卢",
				bolivia: "玻利维亚",
				botswana: "博茨瓦纳",
				brazil: "巴西",
				bulgaria: "保加利亚",
				burma: "缅甸",
				cameroon: "喀麦隆",
				canada: "加拿大",
				chile: "智利",
				chineseCivilWar: "国共内战",
				colombia: "哥伦比亚",
				costaRica: "哥斯达黎加",
				cuba: "古巴",
				czechoslovakia: "捷克斯洛伐克",
				denmark: "丹麦",
				dominicanRepublic: "多米尼加",
				eastGermany: "东德",
				ecuador: "厄瓜多尔",
				egypt: "埃及",
				elSalvador: "萨尔瓦多",
				ethiopia: "埃塞俄比亚",
				finland: "芬兰",
				france: "法国",
				greece: "希腊",
				guatemala: "危地马拉",
				gulfStates: "海湾国家",
				haiti: "海地",
				honduras: "洪都拉斯",
				hungary: "匈牙利",
				india: "印度",
				indonesia: "印度尼西亚",
				iran: "伊朗",
				iraq: "伊拉克",
				israel: "以色列",
				italy: "意大利",
				ivoryCoast: "科特迪瓦",
				japan: "日本",
				jordan: "约旦",
				kenya: "肯尼亚",
				laosCambodia: "老挝/柬埔寨",
				lebanon: "黎巴嫩",
				libya: "利比亚",
				malaysia: "马来西亚",
				mexico: "墨西哥",
				morocco: "摩洛哥",
				nicaragua: "尼加拉瓜",
				nigeria: "尼日利亚",
				northKorea: "朝鲜",
				norway: "挪威",
				pakistan: "巴基斯坦",
				panama: "巴拿马",
				paraguay: "巴拉圭",
				peru: "秘鲁",
				philippines: "菲律宾",
				poland: "波兰",
				romania: "罗马尼亚",
				saharanStates: "撒哈拉国家",
				saudiArabia: "沙特阿拉伯",
				seAfricanStates: "东南非国家",
				somalia: "索马里",
				southAfrica: "南非",
				southKorea: "韩国",
				spainPortugal: "西班牙/葡萄牙",
				sudan: "苏丹",
				sweden: "瑞典",
				syria: "叙利亚",
				taiwan: "台湾",
				thailand: "泰国",
				tunisia: "突尼斯",
				turkey: "土耳其",
				uk: "英国",
				uruguay: "乌拉圭",
				venezuela: "委内瑞拉",
				vietnam: "越南",
				westAfricanStates: "西非国家",
				westGermany: "西德",
				yugoslavia: "南斯拉夫",
				zaire: "扎伊尔",
				zimbabwe: "津巴布韦"
			},
			card: {
				asiaScoring: "亚洲计分",
				europeScoring: "欧洲计分",
				middleEastScoring: "中东计分",
				duckAndCover: "卧倒与隐蔽",
				fiveYearPlan: "五年计划",
				theChinaCard: "中国牌",
				socialistGovernments: "社会主义政府",
				fidel: "菲德尔",
				vietnamRevolts: "越南起义",
				blockade: "封锁",
				koreanWar: "朝鲜战争",
				romanianAbdication: "罗马尼亚退位",
				arabIsraeliWar: "阿以战争",
				comecon: "经互会",
				nasser: "纳赛尔",
				warsawPactFormed: "华沙条约组织成立",
				deGaulleLeadsFrance: "戴高乐领导法国",
				capturedNaziScientist: "捕获纳粹科学家",
				trumanDoctrine: "杜鲁门主义",
				olympicGames: "奥林匹克运动会",
				nato: "北大西洋公约组织",
				independentReds: "独立红军",
				marshallPlan: "马歇尔计划",
				indoPakistaniWar: "印巴战争",
				containment: "围堵政策",
				ciaCreated: "中央情报局成立",
				usJapanMutualDefensePact: "美日共同防御协定",
				suezCrisis: "苏伊士危机",
				eastEuropeanUnrest: "东欧动乱",
				decolonization: "去殖民化",
				redScarePurge: "红色恐慌/大清洗",
				unIntervention: "联合国干预",
				deStalinization: "去斯大林化",
				nuclearTestBan: "禁止核试验条约",
				formosanResolution: "台湾决议案",
				brushWar: "丛林战争",
				centralAmericaScoring: "中美洲计分",
				southeastAsiaScoring: "东南亚计分",
				armsRace: "军备竞赛",
				cubanMissileCrisis: "古巴导弹危机",
				nuclearSubs: "核潜艇",
				quagmire: "泥潭",
				saltNegotiations: "限制战略武器谈判",
				bearTrap: "熊陷阱",
				summit: "高峰会议",
				howILearnedToStopWorrying: "我如何学会停止担忧",
				junta: "军政府",
				kitchenDebates: "厨房辩论",
				missileEnvy: "导弹嫉妒",
				weWillBuryYou: "我们将埋葬你们",
				brezhnevDoctrine: "勃列日涅夫主义",
				portugueseEmpireCrumbles: "葡萄牙殖民帝国崩溃",
				southAfricanUnrest: "南非动乱",
				allende: "阿连德",
				willyBrandt: "维利·勃兰特",
				muslimRevolution: "穆斯林革命",
				abmTreaty: "反弹道导弹条约",
				culturalRevolution: "文化大革命",
				flowerPower: "花之力",
				u2Incident: "U-2 侦察机事件",
				opec: "石油输出国组织",
				loneGunman: "孤胆枪手",
				colonialRearGuards: "殖民帝国卫队",
				panamaCanalReturned: "巴拿马运河回归",
				campDavidAccords: "戴维营协议",
				puppetGovernments: "傀儡政府",
				grainSalesToSoviets: "向苏联出售粮食",
				johnPaulIIElectedPope: "约翰·保罗二世当选教皇",
				latinAmericanDeathSquads: "拉丁美洲敢死队",
				oasFounded: "美洲国家组织成立",
				nixonPlaysTheChinaCard: "尼克松打中国牌",
				sadatExpelsSoviets: "萨达特驱逐苏联人",
				shuttleDiplomacy: "穿梭外交",
				theVoiceOfAmerica: "美国之音",
				liberationTheology: "解放神学",
				ussuriRiverSkirmish: "乌苏里江冲突",
				askNotWhatYourCountryCanDoForYou: "不要问国家能为你做什么",
				allianceForProgress: "进步联盟",
				africaScoring: "非洲计分",
				oneSmallStep: "个人的一小步",
				southAmericaScoring: "南美洲计分",
				iranianHostageCrisis: "伊朗人质危机",
				theIronLady: "铁娘子",
				reaganBombsLibya: "里根轰炸利比亚",
				starWars: "星球大战计划",
				northSeaOil: "北海油田",
				theReformer: "改革者",
				marineBarracksBombing: "海军陆战队兵营爆炸案",
				sovietsShootDownKAL007: "苏联击落大韩航空 007",
				glasnost: "公开性",
				ortegaElectedInNicaragua: "奥尔特加当选尼加拉瓜总统",
				terrorism: "恐怖主义",
				iranContraScandal: "伊朗门丑闻",
				chernobyl: "切尔诺贝利",
				latinAmericanDebtCrisis: "拉丁美洲债务危机",
				tearDownThisWall: "推倒这堵墙",
				anEvilEmpire: "邪恶帝国",
				aldrichAmesRemix: "奥德里奇·埃姆斯",
				pershingIIDeployed: "潘兴 II 型导弹部署",
				wargames: "战争游戏",
				solidarity: "团结工会",
				iranIraqWar: "两伊战争",
				defectors: "叛逃者",
				theCambridgeFive: "剑桥五杰",
				specialRelationship: "特殊关系",
				norad: "北美防空司令部",
				che: "切·格瓦拉",
				ourManInTehran: "我们的人在德黑兰",
				yuriAndSamantha: "尤里与萨曼莎",
				awacsSaleToSaudis: "向沙特出售预警机"
			},
			cardText: {
				asiaScoring: "存在 3 分\n支配 7 分\n控制 9 分\n每控制一个区域内战场国加 1 分\n每控制一个与敌方超级大国相邻的国家加 1 分\n\n不可保留。",
				europeScoring: "存在 3 分\n支配 7 分\n控制则直接获胜\n每控制一个区域内战场国加 1 分\n每控制一个与敌方超级大国相邻的国家加 1 分\n\n不可保留。",
				middleEastScoring: "存在 3 分\n支配 5 分\n控制 7 分\n每控制一个区域内战场国加 1 分\n\n不可保留。",
				duckAndCover: "DEFCON 下降 1 级。\n美国获得等同于 5 减去当前 DEFCON 等级的胜利分。",
				fiveYearPlan: "苏联随机弃置一张手牌。\n若该牌带有美国关联事件,该事件立即发生;否则直接弃置,事件不发生。",
				theChinaCard: "开局由苏联持有。\n若打出的行动值全部用于亚洲(含东南亚),行动值加 1。\n打出后交给对手。\n第 10 回合结束时持有者获得 1 分。",
				socialistGovernments: "从西欧国家移除共计 3 点美国影响力(每个国家至多移除 2 点)。\n\n「铁娘子」事件发生后此事件不能使用。",
				fidel: "移除古巴的全部美国影响力。\n苏联在古巴增加至足以控制该国的影响力。",
				vietnamRevolts: "在越南增加 2 点苏联影响力。\n本回合内,苏联打出的牌若行动值全部用于东南亚,行动值加 1。",
				blockade: "除非美国立即弃置一张行动值不低于 3 的牌,否则移除西德的全部美国影响力。",
				koreanWar: "朝鲜入侵韩国。\n掷骰:每个与韩国相邻的美国控制国家使点数减 1。\n修正后点数为 4 至 6 时,苏联获得 2 分,并用苏联影响力替换韩国的全部美国影响力。\n苏联军事行动轨增加 2 格。",
				romanianAbdication: "移除罗马尼亚的全部美国影响力。\n苏联在罗马尼亚增加至足以控制该国的影响力。",
				arabIsraeliWar: "泛阿拉伯联军入侵以色列。\n掷骰:若以色列由美国控制,点数减 1;每个与以色列相邻的美国控制国家再使点数减 1。\n修正后点数为 4 至 6 时,苏联获得 2 分,并用苏联影响力替换以色列的全部美国影响力。\n苏联军事行动轨增加 2 格。\n\n「戴维营协议」事件发生后此事件不能使用。",
				comecon: "选择东欧 4 个非美国控制的国家,各增加 1 点苏联影响力。",
				nasser: "在埃及增加 2 点苏联影响力。\n美国移除其在埃及一半的影响力(向上取整)。",
				warsawPactFormed: "二选一:\n选择东欧 4 个国家,移除其中的全部美国影响力;\n或在东欧国家增加共计 5 点苏联影响力(每个国家至多增加 2 点)。\n\n此事件发生后,「北大西洋公约组织」才能作为事件打出。",
				deGaulleLeadsFrance: "从法国移除 2 点美国影响力,并在法国增加 1 点苏联影响力。\n\n此事件取消「北大西洋公约组织」对法国的效果。",
				capturedNaziScientist: "你的太空竞赛标志前进 1 格。",
				trumanDoctrine: "选择欧洲一个双方均未控制的国家,移除其全部苏联影响力。",
				olympicGames: "你主办奥运会,对手必须选择参加或抵制。\n参加:双方各掷一颗骰子,主办方点数加 2,点数高者获得 2 分(平局重掷)。\n抵制:DEFCON 下降 1 级,主办方可执行相当于 4 点行动值的行动。",
				nato: "苏联不能对欧洲的美国控制国家发动政变或重调,它们也不能成为「丛林战争」的目标。\n\n须先发生「华沙条约组织成立」或「马歇尔计划」事件,此牌才能作为事件打出。",
				independentReds: "选择南斯拉夫、罗马尼亚、保加利亚、匈牙利或捷克斯洛伐克之一,增加美国影响力至与该国苏联影响力相等。",
				marshallPlan: "选择西欧 7 个非苏联控制的国家,各增加 1 点美国影响力。\n\n此事件发生后,「北大西洋公约组织」才能作为事件打出。",
				indoPakistaniWar: "印度入侵巴基斯坦或反之(由你选择)。\n掷骰:每个与目标相邻的敌方控制国家使点数减 1。\n修正后点数为 4 至 6 时,你获得 2 分,并用你的影响力替换目标国的全部对方影响力。\n你的军事行动轨增加 2 格。",
				containment: "本回合内,美国打出的牌行动值加 1(每张至多按 4 点计)。",
				ciaCreated: "苏联展示手牌,持续本回合。\n美国可用此牌的行动值执行行动。",
				usJapanMutualDefensePact: "美国在日本增加至足以控制该国的影响力。\n苏联不能对日本发动政变或重调。",
				suezCrisis: "从法国、英国和以色列移除共计 4 点美国影响力(每个国家至多移除 2 点)。",
				eastEuropeanUnrest: "早期或中期:从东欧 3 个国家各移除 1 点苏联影响力。\n晚期:从东欧 3 个国家各移除 2 点苏联影响力。",
				decolonization: "在非洲和/或东南亚选择 4 个国家,各增加 1 点苏联影响力。",
				redScarePurge: "本回合内,对手打出的牌行动值减 1(每张至少按 1 点计)。",
				unIntervention: "与一张带有对手关联事件的牌同时打出:取消该事件,你使用该牌的行动值执行行动。\n\n此事件不能在头条阶段打出。",
				deStalinization: "苏联从一个或多个国家移出共计至多 4 点影响力,重新放置到非美国控制的国家(每个国家至多增加 2 点)。",
				nuclearTestBan: "你获得等同于当前 DEFCON 等级减 2 的胜利分,然后 DEFCON 上升 2 级。",
				formosanResolution: "此事件生效期间,进行亚洲计分时若台湾由美国控制,台湾视为战场国。\n\n美国打出「中国牌」后此事件取消。",
				brushWar: "你攻击任一稳定度为 1 或 2 的国家。\n掷骰:每个与目标相邻的敌方控制国家使点数减 1。\n修正后点数为 3 至 6 时,你获得 1 分,并用你的影响力替换目标国的全部对方影响力。\n你的军事行动轨增加 3 格。",
				centralAmericaScoring: "存在 1 分\n支配 3 分\n控制 5 分\n每控制一个区域内战场国加 1 分\n每控制一个与敌方超级大国相邻的国家加 1 分\n\n不可保留。",
				southeastAsiaScoring: "每控制缅甸、老挝/柬埔寨、越南、马来西亚、印度尼西亚、菲律宾中的一国获得 1 分\n控制泰国获得 2 分\n\n不可保留。",
				armsRace: "比较双方军事行动轨数值。\n若你高于对手,获得 1 分;若你高于对手且已达到本回合军事需求值,改为获得 3 分。",
				cubanMissileCrisis: "DEFCON 设为 2。\n本回合内,对手发动任何政变都将立即输掉游戏。\n\n此事件可随时取消:苏联从古巴移除 2 点影响力,或美国从西德或土耳其移除 2 点影响力。",
				nuclearSubs: "本回合内,美国在战场国的政变不再使 DEFCON 下降。\n\n不影响其他改变 DEFCON 的事件。",
				quagmire: "美国的下个行动轮起,必须弃置一张行动值不低于 2 的牌并掷骰,掷出 1 至 4 时取消此事件,否则下个行动轮重复。\n若美国无法弃牌,必须打出全部计分牌并跳过本回合剩余行动轮。\n\n此事件取消「北美防空司令部」的效果。",
				saltNegotiations: "DEFCON 上升 2 级。\n本回合内,双方政变掷骰减 1。\n打出此事件的玩家可以查看弃牌堆,选一张非计分牌,向对手展示后加入手牌。",
				bearTrap: "苏联的下个行动轮起,必须弃置一张行动值不低于 2 的牌并掷骰,掷出 1 至 4 时取消此事件,否则下个行动轮重复。\n若苏联无法弃牌,必须打出全部计分牌并跳过本回合剩余行动轮。",
				summit: "双方各掷一颗骰子,每支配或控制一个区域点数加 1。\n点数高者获得 2 分,并可将 DEFCON 上升或下降 1 级(平局不重掷)。",
				howILearnedToStopWorrying: "将 DEFCON 设为 1 至 5 的任意值。\n你的军事行动轨增加 5 格。",
				junta: "在中美洲或南美洲的一个国家增加 2 点你的影响力。\n然后可用此牌的行动值在中美洲或南美洲进行免费政变或重调。",
				kitchenDebates: "若美国控制的战场国多于苏联,美国获得 2 分。",
				missileEnvy: "用此牌交换对手手中行动值最高的牌;并列最高时由对手选择。\n若换来的牌带有你或双方关联的事件,该事件立即发生;若带有对手关联事件,只使用其行动值。\n对手必须在其下个行动轮用此牌执行行动。",
				weWillBuryYou: "DEFCON 下降 1 级。\n除非美国在其下个行动轮打出「联合国干预」事件,否则苏联获得 3 分。",
				brezhnevDoctrine: "本回合内,苏联打出的牌行动值加 1(每张至多按 4 点计)。",
				portugueseEmpireCrumbles: "在安哥拉和东南非国家各增加 2 点苏联影响力。",
				southAfricanUnrest: "苏联二选一:\n在南非增加 2 点影响力;\n或在南非增加 1 点影响力,并在与南非相邻的一个国家增加 2 点影响力。",
				allende: "在智利增加 2 点苏联影响力。",
				willyBrandt: "苏联获得 1 分,并在西德增加 1 点影响力。\n\n此事件取消「北大西洋公约组织」对西德的效果。\n「推倒这堵墙」事件发生后此事件不能使用。",
				muslimRevolution: "从以下国家中选择 2 个,移除其全部美国影响力:苏丹、伊朗、伊拉克、埃及、利比亚、沙特阿拉伯、叙利亚、约旦。\n\n「向沙特出售预警机」事件发生后此事件不能使用。",
				abmTreaty: "DEFCON 上升 1 级,然后用此牌的行动值执行行动。",
				culturalRevolution: "若美国持有「中国牌」,必须将其交给苏联(正面朝上,可立即使用)。\n若苏联已持有「中国牌」,苏联获得 1 分。",
				flowerPower: "此牌打出后,美国每将一张战争牌(阿以战争、朝鲜战争、丛林战争、印巴战争、两伊战争)用于行动值或事件,苏联获得 2 分。\n\n「邪恶帝国」事件发生后此事件不能使用。",
				u2Incident: "苏联获得 1 分。\n本回合稍后若「联合国干预」事件被打出,苏联再获得 1 分。",
				opec: "苏联每控制以下国家之一获得 1 分:埃及、伊朗、利比亚、沙特阿拉伯、伊拉克、海湾国家、委内瑞拉。\n\n「北海油田」事件发生后此事件不能使用。",
				loneGunman: "美国展示手牌,持续本回合。\n苏联可用此牌的行动值执行行动。",
				colonialRearGuards: "在非洲和/或东南亚选择 4 个国家,各增加 1 点美国影响力。",
				panamaCanalReturned: "在巴拿马、哥斯达黎加和委内瑞拉各增加 1 点美国影响力。",
				campDavidAccords: "美国获得 1 分,并在以色列、约旦和埃及各增加 1 点影响力。\n\n「阿以战争」不能再作为事件打出。",
				puppetGovernments: "选择 3 个双方都没有影响力的国家,各增加 1 点美国影响力。",
				grainSalesToSoviets: "美国从苏联手牌中随机抽取一张牌(若有),必须选择打出该牌或归还。\n若归还或苏联没有手牌,美国可用此牌的行动值执行行动。",
				johnPaulIIElectedPope: "从波兰移除 2 点苏联影响力,并在波兰增加 1 点美国影响力。\n\n此事件发生后,「团结工会」才能作为事件打出。",
				latinAmericanDeathSquads: "本回合内,你在中美洲和南美洲的政变掷骰加 1,对手在中美洲和南美洲的政变掷骰减 1。",
				oasFounded: "在中美洲或南美洲国家增加共计 2 点美国影响力。",
				nixonPlaysTheChinaCard: "若苏联持有「中国牌」,必须将其交给美国(背面朝下,不能立即使用)。\n若美国已持有「中国牌」,美国获得 2 分。",
				sadatExpelsSoviets: "移除埃及的全部苏联影响力,并在埃及增加 1 点美国影响力。",
				shuttleDiplomacy: "此事件生效期间,下一次中东或亚洲计分(以先到者为准)时,苏联的战场国数量减 1,然后弃置此牌。",
				theVoiceOfAmerica: "从欧洲以外的国家移除共计 4 点苏联影响力(每个国家至多移除 2 点)。",
				liberationTheology: "在中美洲国家增加共计 3 点苏联影响力(每个国家至多增加 2 点)。",
				ussuriRiverSkirmish: "若苏联持有「中国牌」,必须将其交给美国(正面朝上,可立即使用)。\n若美国已持有「中国牌」,在亚洲国家增加共计 4 点美国影响力(每个国家至多增加 2 点)。",
				askNotWhatYourCountryCanDoForYou: "美国可以弃置至多全部手牌(包括计分牌),然后从牌堆抽取等量替换牌。\n弃置数量必须在抽牌前确定。",
				allianceForProgress: "美国每控制中美洲或南美洲的一个战场国,获得 1 分。",
				africaScoring: "存在 1 分\n支配 4 分\n控制 6 分\n每控制一个区域内战场国加 1 分\n\n不可保留。",
				oneSmallStep: "若你在太空竞赛轨上落后,你的标志前进 2 格。\n只获得最终到达格子的胜利分。",
				southAmericaScoring: "存在 2 分\n支配 5 分\n控制 6 分\n每控制一个区域内战场国加 1 分\n\n不可保留。",
				iranianHostageCrisis: "移除伊朗的全部美国影响力,并在伊朗增加 2 点苏联影响力。\n\n此事件发生后,美国被「恐怖主义」要求弃牌时必须弃置 2 张。",
				theIronLady: "在阿根廷增加 1 点苏联影响力,并移除英国的全部苏联影响力。\n美国获得 1 分。\n\n「社会主义政府」不能再作为事件打出。",
				reaganBombsLibya: "利比亚每有 2 点苏联影响力,美国获得 1 分。",
				starWars: "若美国在太空竞赛轨上领先,美国可以查看弃牌堆,选一张非计分牌,立即作为事件打出。",
				northSeaOil: "本回合美国可以打出 8 张牌(进行 8 个行动轮)。\n\n「石油输出国组织」不能再作为事件打出。",
				theReformer: "在欧洲国家增加共计 4 点苏联影响力(每个国家至多增加 2 点);若苏联胜利分领先,改为增加 6 点。\n\n此后苏联不能在欧洲发动政变。",
				marineBarracksBombing: "移除黎巴嫩的全部美国影响力,并从中东国家移除共计 2 点美国影响力。",
				sovietsShootDownKAL007: "DEFCON 下降 1 级,美国获得 2 分。\n若韩国由美国控制,美国可用此牌放置影响力或进行重调。",
				glasnost: "DEFCON 上升 1 级,苏联获得 2 分。\n若「改革者」事件已经发生,苏联可用此牌进行重调或放置影响力。",
				ortegaElectedInNicaragua: "移除尼加拉瓜的全部美国影响力。\n苏联可用此牌的行动值在与尼加拉瓜相邻的一个国家进行一次免费政变。",
				terrorism: "对手随机弃置一张手牌。\n若「伊朗人质危机」事件已经发生,美国(若适用)必须随机弃置 2 张。",
				iranContraScandal: "本回合内,美国的重调掷骰减 1。",
				chernobyl: "美国指定一个区域,本回合内苏联不能用行动值向该区域放置影响力。",
				latinAmericanDebtCrisis: "美国必须立即弃置一张行动值不低于 3 的牌,否则苏联可以选择南美洲 2 个国家,将其中的苏联影响力翻倍。",
				tearDownThisWall: "在东德增加 3 点美国影响力。\n美国可用此牌的行动值在欧洲进行免费政变或重调。\n\n「维利·勃兰特」不能再作为事件打出。",
				anEvilEmpire: "美国获得 1 分。\n\n「花之力」的效果被取消且不能再打出。",
				aldrichAmesRemix: "美国展示手牌,持续本回合,且苏联从美国手牌中选择一张弃置。",
				pershingIIDeployed: "苏联获得 1 分。\n从西欧选择 3 个国家,各移除 1 点美国影响力。",
				wargames: "若 DEFCON 为 2,你可以立即结束游戏:先让对手获得 6 分,然后游戏结束。",
				solidarity: "在波兰增加 3 点美国影响力。\n\n须先发生「约翰·保罗二世当选教皇」事件,此牌才能作为事件打出。",
				iranIraqWar: "伊朗入侵伊拉克或反之(由你选择)。\n掷骰:每个与目标相邻的敌方控制国家使点数减 1。\n修正后点数为 4 至 6 时,你获得 2 分,并用你的影响力替换目标国的全部对方影响力。\n你的军事行动轨增加 2 格。",
				defectors: "美国可在头条阶段打出此牌:取消苏联的头条事件(包括计分牌),被取消的牌进入弃牌堆。\n若苏联在行动轮打出此牌,美国获得 1 分。",
				theCambridgeFive: "美国展示手牌中的全部计分牌。\n苏联可以选择一张被展示计分牌所指名的区域,在其中增加 1 点苏联影响力。\n\n晚期不能作为事件打出。",
				specialRelationship: "若英国由美国控制且「北大西洋公约组织」未生效:在与英国相邻的一个国家增加 1 点美国影响力。\n若英国由美国控制且「北大西洋公约组织」已生效:在西欧一个国家增加 2 点美国影响力,美国获得 2 分。",
				norad: "若加拿大由美国控制,每当 DEFCON 在某行动轮降至 2,该行动轮结束时美国在一个已有美国影响力的国家增加 1 点影响力。\n\n此事件被「泥潭」取消。",
				che: "苏联可用此牌的行动值对中美洲、南美洲或非洲的一个非战场国发动政变。\n若第一次政变移除了美国影响力,可再对另一个非战场国发动一次政变。",
				ourManInTehran: "若美国控制至少一个中东国家,美国抽取牌堆顶的 5 张牌,可以弃置其中任意数量(向苏联展示被弃置的牌,不触发事件),其余放回牌堆并重新洗牌。",
				yuriAndSamantha: "本回合内,美国每发动一次政变,苏联获得 1 分。",
				awacsSaleToSaudis: "在沙特阿拉伯增加 2 点美国影响力。\n\n「穆斯林革命」不能再作为事件打出。"
			}
		},
		en: {
			name: "Twilight Struggle",
			desc: "Play as the US or USSR and contest the globe with influence, coups and events—without triggering nuclear war",
			rules: "Goal: play as the US or USSR and score Victory Points through regional scoring and events.\nYou win immediately by meeting any of the following conditions:\n· Reach 20 VP.\n· Cause your opponent to trigger nuclear war.\n· Control Europe when Europe is scored.\nSetup:\n· The USSR places 6 starting influence in Eastern Europe, then the US places 7 in Western Europe.\n· Shuffle the Early War deck; each player is dealt 8 cards. The China Card starts face up with the USSR player.\nPlay: each turn opens with the Headline Phase—both players secretly select a card and reveal simultaneously; the higher Operations value resolves first. Action Rounds follow, USSR first, alternating.\n· On an Action Round, play a card: trigger its event (yours or shared), or spend its Operations value on influence, a coup, realignment rolls, or the Space Race.\n· When you play a card bearing the opponent's event, the event still occurs; you choose whether it resolves before or after your Operations.\n· Coups in Battleground countries degrade DEFCON by 1; DEFCON restricts coups and realignments by region.\n· If DEFCON reaches 1, the player responsible immediately loses.\n· At the end of each turn, a player short of required Military Operations gives the opponent the difference in VP.\nEnd: after Turn 10 every region is scored, the holder of the China Card gains 1 VP, and the higher score wins; a tie is a draw.",
			phaseSetupPlace: "Setup: tap a highlighted country to place influence ({{n}} left)",
			phaseSetupWait: "Waiting for your opponent to place starting influence…",
			phaseHeadline: "Headline Phase: choose a headline card",
			phaseHeadlineWait: "Waiting for your opponent's headline…",
			phaseAR: "Action Round: play a card",
			phaseARWait: "Waiting for your opponent's action…",
			phaseTurnEnd: "Resolving turn…",
			phaseTrap: "{{card}}: discard a card worth 2+ Ops and roll 1-4 to escape",
			phaseGameOver: "Game over",
			modeEvent: "As Event",
			modeOps: "As Operations",
			modeInfluence: "Place Influence",
			modeCoup: "Coup",
			modeRealign: "Realign",
			modeSpace: "Space Race",
			eventFirstQ: "This card bears the opponent's event—choose the order",
			eventFirst: "Event first",
			opsFirst: "Operations first",
			opsLeft: "{{n}} Operations left",
			influenceDraft: "Influence preview · Not confirmed",
			submittingInfluence: "Confirming allocation…",
			undoInfluence: "Undo last point",
			confirmInfluence: "Confirm allocation",
			draftSetup: "Setup preview · Unconfirmed",
			draftEvent: "Event preview · Unconfirmed",
			draftDestalRemove: "De-Stalinization · Remove",
			draftDestalAdd: "De-Stalinization · Place",
			draftPointsLeft: "{{n}} points left",
			undoChoice: "Undo last choice",
			continueRedistribution: "Continue to placement",
			backToRemoval: "Back to removal",
			warningTitle: "Confirm automatic consequences",
			warningCancel: "Go back",
			warningProceed: "Proceed anyway",
			warningNuclear: "This action will trigger nuclear war and end the game immediately. The phasing player, {{side}}, will lose.",
			warningNuclearRisk: "This event or a later choice may trigger nuclear war. If DEFCON reaches 1, the phasing player, {{side}}, will lose.",
			warningNuclearUncertain: "This event or a later choice may trigger nuclear war and immediately end the game. Proceed only if you accept that risk.",
			warningWargames: "Wargames gives your opponent 6 VP, then immediately ends the game. With the current position: {{result}}.",
			warningScoring: "Scoring the current position will immediately end the game: {{result}}.",
			warningWinner: "{{side}} wins",
			warningDraw: "A draw",
			warningHeldScoring: "Under the current action-round schedule, this is your last card play this turn. You still hold: {{cards}}. Unless you gain another action round, holding scoring cards at turn end triggers the scoring-card loss rule.",
			warningBlockade: "You have not selected a card to discard. Confirming Blockade will remove all {{n}} US influence from West Germany.",
			confirm: "Confirm",
			cancel: "Cancel",
			finishRealign: "End realignments",
			spaceAttempt: "Roll to advance (need ≤{{n}})",
			spaceUsedUp: "No Space Race attempts left this turn",
			cannotSpace: "This card's Ops value is too low for the next space",
			turnLabel: "Turn {{n}}/10",
			arLabel: "AR {{n}}",
			defconLabel: "DEFCON",
			defconAlert: "ALERT",
			vpLabel: "VP",
			milopsLabel: "Mil Ops",
			spaceLabel: "Space",
			optSide: "Host side",
			optSideRandom: "Random",
			optSideUs: "US",
			optSideUssr: "USSR",
			optCards: "Optional deluxe cards",
			optCardsHint: "Include optional event cards",
			optCivilWar: "Chinese Civil War variant",
			optCivilWarHint: "The USSR must place 3 influence in the Civil War space to claim the China Card",
			optCivilWarRules: "Read the full variant rules",
			optCivilWarRulesText: "The Chinese Civil War space is adjacent only to the USSR. It is in Asia, but not Southeast Asia, and does not count for regional scoring. Only the USSR may spend Operations to place influence there. At 3 influence, the USSR immediately claims the China Card face up; the space is then ignored. Until then, the USSR cannot trigger Red Scare/Purge or Cultural Revolution and the US cannot trigger Formosan Resolution, although these cards may still be used for Operations. During this period, the US is deemed to hold the China Card for Nixon Plays the China Card and Ussuri River Skirmish, and the USSR takes an extra -1 on Korean War rolls. If the card is never claimed, neither player scores its endgame VP.",
			optUsBonus: "Extra US setup influence",
			optUsBonusHint: "Normal 7: Western Europe. Extra: Western Europe or countries with US influence",
			phaseSetupPlaceBonus: "Setup (US extra +{{bonus}}): tap a highlighted country ({{n}} left)",
			spaceDetailsTitle: "Space Race details",
			spaceStepReq: "{{ops}} Ops required · succeed on 1–{{roll}}",
			spaceStepVp: "First {{first}} VP · second {{second}} VP",
			spaceBonusRule: "Only the first player to reach a space holds its ability; it ends when the other player reaches it.",
			spaceBonus2: "May attempt the Space Race with up to two cards each turn.",
			spaceBonus4: "The opponent reveals their headline before you choose yours.",
			spaceBonus6: "May discard a held card at the end of the turn.",
			spaceBonus8: "May take an eighth Action Round each turn.",
			trumanPick: "Truman Doctrine: choose an uncontrolled European country and remove all USSR influence there",
			noradPick: "NORAD: add 1 US influence to a country where the US already has influence",
			effectsButton: "Effects {{n}}",
			effectsTitle: "Active effects",
			effectsTurn: "This turn",
			effectsLasting: "Ongoing",
			effectsEmpty: "No active effects",
			cardFateRemoved: "Removed from the game when its Event fires",
			cardFateDiscard: "Discarded when its Event fires",
			cardFateChina: "Passed to the opponent after play",
			cardFateShuttle: "Stays active, then leaves the game after Asia or Middle East scoring",
			cardFateMissile: "Passed to the opponent, then discarded after use as Operations",
			cardFateShortRemoved: "Remove",
			cardFateShortDiscard: "Discard",
			cardFateShortChina: "Pass",
			cardFateShortShuttle: "Hold",
			cardFateShortMissile: "Pass",
			chinaCardLabel: "China Card",
			chinaUnclaimed: "Unclaimed",
			chinaHeld: "Holds the China Card",
			chinaFaceDown: "China Card (unavailable this turn)",
			chinaFaceUp: "Face up",
			chinaFaceDownShort: "Face down",
			deckCount: "{{n}} in deck",
			discardLabel: "Discard {{n}}",
			handLabel: "{{n}} cards in hand",
			opponentEventShort: "Opp. event",
			mustPlayShort: "Must play",
			specialCardShort: "Special",
			mustPlayScoring: "Scoring cards may not be held; you must play them",
			trappedSkip: "Unable to discard: all scoring cards are played and the rest of this turn is skipped",
			chooseCountryOne: "Choose a country",
			chooseCountriesN: "Choose {{n}} countries",
			chooseCardOne: "Choose a card",
			chooseCardsDiscard: "Choose cards to discard ({{n}})",
			chooseCardsFree: "Choose cards to discard (up to {{n}})",
			cardsSelectedN: "{{n}} cards selected",
			cardDetails: "View details for {{card}}",
			chooseOption: "Make a choice",
			placeN: "Place influence ({{n}} left)",
			removeN: "Remove influence ({{n}} left)",
			skip: "Skip",
			boycott: "Boycott",
			participate: "Participate",
			optImprove: "Improve DEFCON by 1",
			optDegrade: "Degrade DEFCON by 1",
			optNoChange: "No change",
			playIt: "Play this card",
			returnIt: "Return it",
			optRemoveUs: "Remove US influence",
			optAddUssr: "Add USSR influence",
			optUn: "Cancel with UN Intervention",
			sa2: "+2 in South Africa",
			sa1ang2: "+1 South Africa, +2 Angola",
			sa1bot2: "+1 South Africa, +2 Botswana",
			sa1ang1bot1: "+1 in each of the three",
			cancelCuban: "Cancel Cuban Missile Crisis",
			cancelCubanShort: "End Missile Crisis",
			cancelCubanHint: "Choose where to remove 2 of your Influence. No Action Round is spent; the current action continues.",
			cancelCubanInsufficient: "Needs 2 Influence",
			cancelCubanChoose: "Choose a country",
			cancelCubanConfirm: "Remove 2 from {{country}} & end crisis",
			cancelCubanSubmitting: "Ending crisis…",
			grainDrawnCard: "Grain Sales · drawn card",
			draftReset: "The board changed. Your unconfirmed allocation was cleared; please allocate again.",
			passAr: "Skip this Action Round",
			chinaCard: "The China Card",
			youAre: "You control: {{side}}",
			sideUs: "US",
			sideUssr: "USSR",
			sideUsShort: "US",
			sideUssrShort: "SU",
			oppHandRevealed: "Opponent's hand (revealed)",
			headlineOppSeen: "Opponent's headline: {{card}}",
			stabLabel: "Stab {{n}}",
			bgLabel: "BG",
			selectedN: "{{n}} chosen",
			listOpen: "Country list",
			mapWorldSituation: "World situation",
			zoomCycle: "Cycle zoom level",
			playHeadline: "Play as headline",
			trapDiscardAction: "Discard and roll",
			milopsReq: "Requires {{n}}",
			influenceLabel: "Influence",
			controlUs: "US control",
			controlUssr: "USSR control",
			contested: "Contested",
			uncontrolled: "Uncontrolled",
			legalTarget: "Legal target",
			neighborsLabel: "Adjacent: {{list}}",
			opsTag: "Ops {{n}}",
			sideTagUs: "US event",
			sideTagUssr: "USSR event",
			sideTagBoth: "Shared event",
			sideTagScoring: "Scoring",
			close: "Close",
			scoreTitle: "{{region}} Scoring",
			presence: "Presence",
			domination: "Domination",
			control: "Control",
			battlegroundBonus: "Battlegrounds",
			adjacencyBonus: "Adjacency",
			autoVictory: "Automatic victory",
			scorePoints: "{{n}} VP",
			logHeadline: "Headlines: {{us}} / {{ussr}}",
			logPlay: "{{name}} plays {{card}} ({{mode}})",
			logUnIntervention: "{{name}} plays {{card}} with {{withCard}} for Operations",
			logDiscardForEvent: "{{name}} discards {{card}} due to {{event}}",
			logNoDiscardForEvent: "{{name}} discards no cards due to {{event}}",
			logMissileEnvyExchange: "{{name}} receives {{card}} in exchange for {{event}}",
			logSaltRetrieve: "{{name}} retrieves {{card}} from the discard pile through {{event}}",
			logGrainDraw: "{{name}} draws {{card}} from the USSR hand through {{event}}",
			logGrainUse: "{{name}} chooses to play {{card}} drawn through {{event}}",
			logGrainReturn: "{{name}} returns {{card}} drawn through {{event}} to the USSR",
			logGrainUn: "{{name}} uses {{card}} drawn through {{event}} for Operations with {{un}}",
			viewResults: "View results",
			viewResultsShort: "Result",
			backToSituation: "Back to situation",
			backToSituationShort: "Map",
			logScore: "{{region}} scoring: US {{us}}, USSR {{ussr}}",
			logCoup: "{{name}} coups {{country}}: rolls {{roll}}, {{result}}",
			logCoupSuccess: "success",
			logCoupFail: "failure",
			logRealign: "{{name}} realigns {{country}}: {{usRoll}} vs {{ussrRoll}}, {{result}}",
			logRealignRemoved: "{{n}} opponent influence removed",
			logRealignNone: "no change",
			logSpace: "{{name}} attempts the Space Race: rolls {{roll}}, {{result}}",
			logSpaceOk: "success",
			logSpaceFail: "failure",
			logDefcon: "DEFCON drops to {{n}}",
			logMilops: "Military Operations: {{name}} is {{n}} short, opponent gains {{n}} VP",
			logTurn: "Turn {{n}} begins",
			logWar: "{{card}} war: {{name}} rolls {{roll}} in {{country}}, {{result}}",
			logTrap: "{{name}} rolls against the trap: {{roll}}, {{result}}",
			logTrapSkip: "{{name}} cannot discard an eligible card for {{card}} and skips this Action Round",
			logTrapEscape: "escaped",
			logTrapCaught: "still trapped",
			logOver: "Game over: {{name}} wins ({{reason}})",
			logOverDraw: "Game over: draw",
			logEmpty: "The game has not started yet",
			logTitle: "Game log",
			winVP: "reached 20 VP",
			winEurope: "controls Europe",
			winNuclear: "opponent triggered nuclear war",
			winScoringHeld: "opponent held a scoring card",
			winWargames: "Wargames",
			winFinal: "wins on final scoring",
			winDraw: "Draw",
			winCuban: "opponent couped during the Cuban Missile Crisis",
			errNotYourTurn: "Not your turn",
			errBadCard: "That card is not in your hand",
			errBadMode: "This card cannot be played that way",
			errBadTarget: "That target is not allowed",
			errBadAlloc: "Invalid influence placement",
			errDefcon: "DEFCON forbids coups and realignments in this region",
			errNoCoupTarget: "The coup target must contain opponent influence",
			errPending: "Finish the current choice first",
			errHeadline: "This card cannot be headlined",
			errTrap: "Resolve the forced discard first",
			errNato: "NATO protects this country from coups and realignments",
			errChernobyl: "Influence cannot be placed in this region this turn",
			errReformer: "After The Reformer, the USSR may not coup in Europe",
			errOps: "Not enough Operations",
			errSetup: "Choose a country allowed in this setup step",
			region: {
				europe: "Europe",
				westernEurope: "Western Europe",
				easternEurope: "Eastern Europe",
				asia: "Asia",
				southeastAsia: "Southeast Asia",
				middleEast: "Middle East",
				africa: "Africa",
				centralAmerica: "Central America",
				southAmerica: "South America"
			},
			spaceTrack: {
				s0: "Start",
				s1: "Earth Satellite",
				s2: "Animal in Space",
				s3: "Man in Space",
				s4: "Man in Earth Orbit",
				s5: "Lunar Orbit",
				s6: "Eagle/Bear has Landed",
				s7: "Space Shuttle",
				s8: "Space Station"
			},
			country: {
				us: "United States",
				ussr: "Soviet Union",
				afghanistan: "Afghanistan",
				algeria: "Algeria",
				angola: "Angola",
				argentina: "Argentina",
				australia: "Australia",
				austria: "Austria",
				benelux: "Benelux",
				bolivia: "Bolivia",
				botswana: "Botswana",
				brazil: "Brazil",
				bulgaria: "Bulgaria",
				burma: "Burma",
				cameroon: "Cameroon",
				canada: "Canada",
				chile: "Chile",
				chineseCivilWar: "Chinese Civil War",
				colombia: "Colombia",
				costaRica: "Costa Rica",
				cuba: "Cuba",
				czechoslovakia: "Czechoslovakia",
				denmark: "Denmark",
				dominicanRepublic: "Dominican Rep.",
				eastGermany: "East Germany",
				ecuador: "Ecuador",
				egypt: "Egypt",
				elSalvador: "El Salvador",
				ethiopia: "Ethiopia",
				finland: "Finland",
				france: "France",
				greece: "Greece",
				guatemala: "Guatemala",
				gulfStates: "Gulf States",
				haiti: "Haiti",
				honduras: "Honduras",
				hungary: "Hungary",
				india: "India",
				indonesia: "Indonesia",
				iran: "Iran",
				iraq: "Iraq",
				israel: "Israel",
				italy: "Italy",
				ivoryCoast: "Ivory Coast",
				japan: "Japan",
				jordan: "Jordan",
				kenya: "Kenya",
				laosCambodia: "Laos/Cambodia",
				lebanon: "Lebanon",
				libya: "Libya",
				malaysia: "Malaysia",
				mexico: "Mexico",
				morocco: "Morocco",
				nicaragua: "Nicaragua",
				nigeria: "Nigeria",
				northKorea: "North Korea",
				norway: "Norway",
				pakistan: "Pakistan",
				panama: "Panama",
				paraguay: "Paraguay",
				peru: "Peru",
				philippines: "Philippines",
				poland: "Poland",
				romania: "Romania",
				saharanStates: "Saharan States",
				saudiArabia: "Saudi Arabia",
				seAfricanStates: "SE African States",
				somalia: "Somalia",
				southAfrica: "South Africa",
				southKorea: "South Korea",
				spainPortugal: "Spain/Portugal",
				sudan: "Sudan",
				sweden: "Sweden",
				syria: "Syria",
				taiwan: "Taiwan",
				thailand: "Thailand",
				tunisia: "Tunisia",
				turkey: "Turkey",
				uk: "United Kingdom",
				uruguay: "Uruguay",
				venezuela: "Venezuela",
				vietnam: "Vietnam",
				westAfricanStates: "West African States",
				westGermany: "West Germany",
				yugoslavia: "Yugoslavia",
				zaire: "Zaire",
				zimbabwe: "Zimbabwe"
			},
			card: {
				asiaScoring: "Asia Scoring",
				europeScoring: "Europe Scoring",
				middleEastScoring: "Middle East Scoring",
				duckAndCover: "Duck and Cover",
				fiveYearPlan: "Five Year Plan",
				theChinaCard: "The China Card",
				socialistGovernments: "Socialist Governments",
				fidel: "Fidel",
				vietnamRevolts: "Vietnam Revolts",
				blockade: "Blockade",
				koreanWar: "Korean War",
				romanianAbdication: "Romanian Abdication",
				arabIsraeliWar: "Arab-Israeli War",
				comecon: "Comecon",
				nasser: "Nasser",
				warsawPactFormed: "Warsaw Pact Formed",
				deGaulleLeadsFrance: "De Gaulle Leads France",
				capturedNaziScientist: "Captured Nazi Scientist",
				trumanDoctrine: "Truman Doctrine",
				olympicGames: "Olympic Games",
				nato: "NATO",
				independentReds: "Independent Reds",
				marshallPlan: "Marshall Plan",
				indoPakistaniWar: "Indo-Pakistani War",
				containment: "Containment",
				ciaCreated: "CIA Created",
				usJapanMutualDefensePact: "US/Japan Mutual Defense Pact",
				suezCrisis: "Suez Crisis",
				eastEuropeanUnrest: "East European Unrest",
				decolonization: "Decolonization",
				redScarePurge: "Red Scare/Purge",
				unIntervention: "UN Intervention",
				deStalinization: "De-Stalinization",
				nuclearTestBan: "Nuclear Test Ban",
				formosanResolution: "Formosan Resolution",
				brushWar: "Brush War",
				centralAmericaScoring: "Central America Scoring",
				southeastAsiaScoring: "Southeast Asia Scoring",
				armsRace: "Arms Race",
				cubanMissileCrisis: "Cuban Missile Crisis",
				nuclearSubs: "Nuclear Subs",
				quagmire: "Quagmire",
				saltNegotiations: "SALT Negotiations",
				bearTrap: "Bear Trap",
				summit: "Summit",
				howILearnedToStopWorrying: "How I Learned to Stop Worrying",
				junta: "Junta",
				kitchenDebates: "Kitchen Debates",
				missileEnvy: "Missile Envy",
				weWillBuryYou: "We Will Bury You",
				brezhnevDoctrine: "Brezhnev Doctrine",
				portugueseEmpireCrumbles: "Portuguese Empire Crumbles",
				southAfricanUnrest: "South African Unrest",
				allende: "Allende",
				willyBrandt: "Willy Brandt",
				muslimRevolution: "Muslim Revolution",
				abmTreaty: "ABM Treaty",
				culturalRevolution: "Cultural Revolution",
				flowerPower: "Flower Power",
				u2Incident: "U2 Incident",
				opec: "OPEC",
				loneGunman: "Lone Gunman",
				colonialRearGuards: "Colonial Rear Guards",
				panamaCanalReturned: "Panama Canal Returned",
				campDavidAccords: "Camp David Accords",
				puppetGovernments: "Puppet Governments",
				grainSalesToSoviets: "Grain Sales to Soviets",
				johnPaulIIElectedPope: "John Paul II Elected Pope",
				latinAmericanDeathSquads: "Latin American Death Squads",
				oasFounded: "OAS Founded",
				nixonPlaysTheChinaCard: "Nixon Plays the China Card",
				sadatExpelsSoviets: "Sadat Expels Soviets",
				shuttleDiplomacy: "Shuttle Diplomacy",
				theVoiceOfAmerica: "The Voice of America",
				liberationTheology: "Liberation Theology",
				ussuriRiverSkirmish: "Ussuri River Skirmish",
				askNotWhatYourCountryCanDoForYou: "Ask Not What Your Country Can Do…",
				allianceForProgress: "Alliance for Progress",
				africaScoring: "Africa Scoring",
				oneSmallStep: "One Small Step…",
				southAmericaScoring: "South America Scoring",
				iranianHostageCrisis: "Iranian Hostage Crisis",
				theIronLady: "The Iron Lady",
				reaganBombsLibya: "Reagan Bombs Libya",
				starWars: "Star Wars",
				northSeaOil: "North Sea Oil",
				theReformer: "The Reformer",
				marineBarracksBombing: "Marine Barracks Bombing",
				sovietsShootDownKAL007: "Soviets Shoot Down KAL-007",
				glasnost: "Glasnost",
				ortegaElectedInNicaragua: "Ortega Elected in Nicaragua",
				terrorism: "Terrorism",
				iranContraScandal: "Iran-Contra Scandal",
				chernobyl: "Chernobyl",
				latinAmericanDebtCrisis: "Latin American Debt Crisis",
				tearDownThisWall: "Tear Down this Wall",
				anEvilEmpire: "An Evil Empire",
				aldrichAmesRemix: "Aldrich Ames Remix",
				pershingIIDeployed: "Pershing II Deployed",
				wargames: "Wargames",
				solidarity: "Solidarity",
				iranIraqWar: "Iran-Iraq War",
				defectors: "Defectors",
				theCambridgeFive: "The Cambridge Five",
				specialRelationship: "Special Relationship",
				norad: "NORAD",
				che: "Che",
				ourManInTehran: "Our Man in Tehran",
				yuriAndSamantha: "Yuri and Samantha",
				awacsSaleToSaudis: "AWACS Sale to Saudis"
			},
			cardText: {
				asiaScoring: "Presence: 3\nDomination: 7\nControl: 9\n+1 VP per controlled Battleground country in the region\n+1 VP per controlled country adjacent to the enemy superpower\n\nMay not be held.",
				europeScoring: "Presence: 3\nDomination: 7\nControl: automatic victory\n+1 VP per controlled Battleground country in the region\n+1 VP per controlled country adjacent to the enemy superpower\n\nMay not be held.",
				middleEastScoring: "Presence: 3\nDomination: 5\nControl: 7\n+1 VP per controlled Battleground country in the region\n\nMay not be held.",
				duckAndCover: "Degrade DEFCON by 1.\nThe US receives VP equal to 5 minus the current DEFCON level.",
				fiveYearPlan: "The USSR randomly discards a card.\nIf it bears a US-associated event, that event occurs immediately; otherwise the card is discarded without triggering.",
				theChinaCard: "Starts with the USSR.\n+1 Operations if all of its points are spent in Asia (including Southeast Asia).\nPassed to the opponent after play.\nIts holder gains 1 VP at the end of Turn 10.",
				socialistGovernments: "Remove a total of 3 US influence from Western Europe (no more than 2 per country).\n\nUnusable after The Iron Lady.",
				fidel: "Remove all US influence from Cuba.\nThe USSR adds enough influence to control Cuba.",
				vietnamRevolts: "Add 2 USSR influence to Vietnam.\nFor the rest of the turn, USSR cards spent entirely in Southeast Asia get +1 Operations.",
				blockade: "Unless the US immediately discards a card worth 3+ Operations, remove all US influence from West Germany.",
				koreanWar: "North Korea invades South Korea.\nRoll a die, -1 per US-controlled country adjacent to South Korea.\nOn a modified 4-6 the USSR gains 2 VP and replaces all US influence in South Korea with USSR influence.\nThe USSR gains 2 Military Operations.",
				romanianAbdication: "Remove all US influence from Romania.\nThe USSR adds enough influence to control Romania.",
				arabIsraeliWar: "Pan-Arab coalition invades Israel.\nRoll a die: -1 if Israel is US-controlled, -1 per adjacent US-controlled country.\nOn a modified 4-6 the USSR gains 2 VP and replaces all US influence in Israel with USSR influence.\nThe USSR gains 2 Military Operations.\n\nUnusable after Camp David Accords.",
				comecon: "Add 1 USSR influence to each of 4 non-US-controlled countries in Eastern Europe.",
				nasser: "Add 2 USSR influence to Egypt.\nThe US removes half (rounded up) of its influence in Egypt.",
				warsawPactFormed: "Choose:\nRemove all US influence from 4 countries in Eastern Europe;\nor add 5 USSR influence to Eastern Europe (no more than 2 per country).\n\nEnables NATO to be played as an event.",
				deGaulleLeadsFrance: "Remove 2 US influence from France and add 1 USSR influence to France.\n\nCancels NATO for France only.",
				capturedNaziScientist: "Advance your Space Race marker by 1 space.",
				trumanDoctrine: "Remove all USSR influence from one uncontrolled country in Europe.",
				olympicGames: "You sponsor the Olympics; your opponent must participate or boycott.\nParticipate: both roll, the sponsor adds 2, the higher roll gains 2 VP (reroll ties).\nBoycott: degrade DEFCON by 1 and the sponsor conducts Operations worth 4 Ops.",
				nato: "The USSR cannot coup or realign any US-controlled country in Europe, and Brush War cannot target them.\n\nRequires Warsaw Pact Formed or Marshall Plan to be played as an event.",
				independentReds: "Add US influence to Yugoslavia, Romania, Bulgaria, Hungary or Czechoslovakia until it equals the USSR influence there.",
				marshallPlan: "Add 1 US influence to each of 7 non-USSR-controlled countries in Western Europe.\n\nEnables NATO to be played as an event.",
				indoPakistaniWar: "India invades Pakistan or vice versa (your choice).\nRoll a die, -1 per enemy-controlled country adjacent to the target.\nOn a modified 4-6 you gain 2 VP and replace all opponent influence in the target with yours.\nGain 2 Military Operations.",
				containment: "For the rest of this turn, US cards get +1 Operations (maximum 4 per card).",
				ciaCreated: "The USSR reveals their hand for the rest of the turn.\nThe US may conduct Operations with this card's value.",
				usJapanMutualDefensePact: "The US adds enough influence to control Japan.\nThe USSR cannot coup or realign Japan.",
				suezCrisis: "Remove a total of 4 US influence from France, the United Kingdom and Israel (no more than 2 per country).",
				eastEuropeanUnrest: "Early or Mid War: remove 1 USSR influence from each of 3 countries in Eastern Europe.\nLate War: remove 2 from each.",
				decolonization: "Add 1 USSR influence to each of any 4 countries in Africa and/or Southeast Asia.",
				redScarePurge: "For the rest of this turn, the opponent's cards get -1 Operations (minimum 1 per card).",
				unIntervention: "Play together with a card bearing an opponent's event: cancel that event and use that card's Operations value.\n\nCannot be played in the Headline Phase.",
				deStalinization: "The USSR may relocate up to 4 influence from any countries to non-US-controlled countries (no more than 2 added per country).",
				nuclearTestBan: "Gain VP equal to the current DEFCON level minus 2, then improve DEFCON by 2.",
				formosanResolution: "While this event is in effect, Taiwan counts as a Battleground country for Asia scoring if the US controls it.\n\nCancelled once the US plays The China Card.",
				brushWar: "Attack any country with stability 1 or 2.\nRoll a die, -1 per adjacent enemy-controlled country.\nOn a modified 3-6 you gain 1 VP and replace all opponent influence in the target with yours.\nGain 3 Military Operations.",
				centralAmericaScoring: "Presence: 1\nDomination: 3\nControl: 5\n+1 VP per controlled Battleground country\n+1 VP per controlled country adjacent to the enemy superpower\n\nMay not be held.",
				southeastAsiaScoring: "1 VP each for controlling Burma, Laos/Cambodia, Vietnam, Malaysia, Indonesia and the Philippines\n2 VP for Thailand\n\nMay not be held.",
				armsRace: "Compare Military Operations.\nIf yours is higher, gain 1 VP; if higher and you have met the requirement, gain 3 VP instead.",
				cubanMissileCrisis: "Set DEFCON to 2.\nFor the rest of the turn, any coup by your opponent loses them the game.\n\nCancel at any time: the USSR removes 2 influence from Cuba, or the US removes 2 from West Germany or Turkey.",
				nuclearSubs: "For the rest of the turn, US coups in Battleground countries do not degrade DEFCON.\n\nDoes not affect other DEFCON-changing events.",
				quagmire: "From the next US Action Round, the US must discard a 2+ Ops card and roll 1-4 to cancel this event, repeating each round.\nIf unable to discard, the US must play all scoring cards and skip the rest of the turn.\n\nCancels NORAD.",
				saltNegotiations: "Improve DEFCON by 2.\nFor the rest of the turn, all coup rolls get -1.\nThe player of this event may take any one non-scoring card from the discard pile into hand, revealing it.",
				bearTrap: "From the next USSR Action Round, the USSR must discard a 2+ Ops card and roll 1-4 to cancel this event, repeating each round.\nIf unable to discard, the USSR must play all scoring cards and skip the rest of the turn.",
				summit: "Both players roll, +1 per region they Dominate or Control.\nThe higher roll gains 2 VP and may improve or degrade DEFCON by 1 (no reroll on ties).",
				howILearnedToStopWorrying: "Set DEFCON to any level (1-5).\nGain 5 Military Operations.",
				junta: "Add 2 of your influence to one country in Central or South America.\nThen conduct free coups or realignments there with this card's Operations value.",
				kitchenDebates: "If the US controls more Battleground countries than the USSR, the US gains 2 VP.",
				missileEnvy: "Exchange this card for the opponent's highest-Ops card (opponent chooses among ties).\nIf the received card bears your or a shared event, it occurs immediately; if it bears the opponent's event, use only its Operations.\nThe opponent must use this card for Operations on their next Action Round.",
				weWillBuryYou: "Degrade DEFCON by 1.\nUnless the US plays UN Intervention on their next Action Round, the USSR gains 3 VP.",
				brezhnevDoctrine: "For the rest of this turn, USSR cards get +1 Operations (maximum 4 per card).",
				portugueseEmpireCrumbles: "Add 2 USSR influence to Angola and to the SE African States.",
				southAfricanUnrest: "The USSR either:\nAdds 2 influence to South Africa;\nor adds 1 to South Africa and 2 to a single country adjacent to South Africa.",
				allende: "Add 2 USSR influence to Chile.",
				willyBrandt: "The USSR gains 1 VP and adds 1 influence to West Germany.\n\nCancels NATO for West Germany only.\nPrevented and cancelled by Tear Down this Wall.",
				muslimRevolution: "Remove all US influence from 2 of: Sudan, Iran, Iraq, Egypt, Libya, Saudi Arabia, Syria, Jordan.\n\nUnusable after AWACS Sale to Saudis.",
				abmTreaty: "Improve DEFCON by 1, then conduct Operations with this card's value.",
				culturalRevolution: "If the US holds The China Card, they give it to the USSR (face up, playable).\nIf the USSR already holds it, the USSR gains 1 VP.",
				flowerPower: "After this is played, the USSR gains 2 VP each time the US plays a War card (Arab-Israeli, Korean, Brush, Indo-Pakistani, Iran-Iraq) for Operations or as an event.\n\nPrevented and cancelled by An Evil Empire.",
				u2Incident: "The USSR gains 1 VP.\nIf UN Intervention is played later this turn, the USSR gains 1 more VP.",
				opec: "The USSR gains 1 VP per controlled country among: Egypt, Iran, Libya, Saudi Arabia, Iraq, Gulf States, Venezuela.\n\nUnusable after North Sea Oil.",
				loneGunman: "The US reveals their hand for the rest of the turn.\nThe USSR may conduct Operations with this card's value.",
				colonialRearGuards: "Add 1 US influence to each of any 4 countries in Africa and/or Southeast Asia.",
				panamaCanalReturned: "Add 1 US influence to Panama, Costa Rica and Venezuela.",
				campDavidAccords: "The US gains 1 VP and adds 1 influence to Israel, Jordan and Egypt.\n\nArab-Israeli War can no longer be played as an event.",
				puppetGovernments: "Add 1 US influence to 3 countries containing no influence from either side.",
				grainSalesToSoviets: "The US takes a random card from the USSR hand (if any) and must either play it or return it.\nIf returned (or the USSR has none), the US may conduct Operations with this card's value.",
				johnPaulIIElectedPope: "Remove 2 USSR influence from Poland and add 1 US influence to Poland.\n\nEnables Solidarity to be played as an event.",
				latinAmericanDeathSquads: "For the rest of the turn, your coups in Central and South America get +1 and the opponent's get -1.",
				oasFounded: "Add a total of 2 US influence to countries in Central or South America.",
				nixonPlaysTheChinaCard: "If the USSR holds The China Card, they give it to the US (face down, not immediately playable).\nIf the US already holds it, the US gains 2 VP.",
				sadatExpelsSoviets: "Remove all USSR influence from Egypt and add 1 US influence to Egypt.",
				shuttleDiplomacy: "While in effect, at the next Middle East or Asia scoring (whichever comes first) subtract 1 from the USSR Battleground total, then discard this card.",
				theVoiceOfAmerica: "Remove a total of 4 USSR influence from countries outside Europe (no more than 2 per country).",
				liberationTheology: "Add a total of 3 USSR influence to countries in Central America (no more than 2 per country).",
				ussuriRiverSkirmish: "If the USSR holds The China Card, they give it to the US (face up, playable).\nIf the US already holds it, add a total of 4 US influence to countries in Asia (no more than 2 per country).",
				askNotWhatYourCountryCanDoForYou: "The US may discard any number of cards (including scoring cards), then draw that many replacements.\nThe number must be decided before drawing.",
				allianceForProgress: "The US gains 1 VP per US-controlled Battleground country in Central and South America.",
				africaScoring: "Presence: 1\nDomination: 4\nControl: 6\n+1 VP per controlled Battleground country\n\nMay not be held.",
				oneSmallStep: "If you are behind on the Space Race track, advance your marker by 2 spaces.\nYou gain VP only from the final space reached.",
				southAmericaScoring: "Presence: 2\nDomination: 5\nControl: 6\n+1 VP per controlled Battleground country\n\nMay not be held.",
				iranianHostageCrisis: "Remove all US influence from Iran and add 2 USSR influence to Iran.\n\nAfterwards, the US discards 2 cards to Terrorism instead of 1.",
				theIronLady: "Add 1 USSR influence to Argentina and remove all USSR influence from the United Kingdom.\nThe US gains 1 VP.\n\nSocialist Governments can no longer be played as an event.",
				reaganBombsLibya: "The US gains 1 VP for every 2 USSR influence in Libya.",
				starWars: "If the US is ahead on the Space Race track, the US picks a non-scoring card from the discard pile and plays it immediately as an event.",
				northSeaOil: "The US may play 8 cards (8 Action Rounds) this turn.\n\nOPEC can no longer be played as an event.",
				theReformer: "Add 4 USSR influence in Europe (no more than 2 per country); if the USSR is ahead in VP, add 6 instead.\n\nThe USSR may no longer coup in Europe.",
				marineBarracksBombing: "Remove all US influence from Lebanon and remove a total of 2 US influence from the Middle East.",
				sovietsShootDownKAL007: "Degrade DEFCON by 1 and the US gains 2 VP.\nIf South Korea is US-controlled, the US may place influence or realign with this card.",
				glasnost: "Improve DEFCON by 1 and the USSR gains 2 VP.\nIf The Reformer has occurred, the USSR may realign or place influence with this card.",
				ortegaElectedInNicaragua: "Remove all US influence from Nicaragua.\nThe USSR may conduct a free coup with this card's Ops value in a country adjacent to Nicaragua.",
				terrorism: "The opponent randomly discards 1 card.\nIf Iranian Hostage Crisis has occurred, the US (if applicable) must randomly discard 2 instead.",
				iranContraScandal: "For the rest of the turn, all US realignment rolls get -1.",
				chernobyl: "The US names one region; the USSR cannot add influence there with Operations for the rest of the turn.",
				latinAmericanDebtCrisis: "The US must immediately discard a 3+ Ops card, or the USSR may double USSR influence in 2 countries in South America.",
				tearDownThisWall: "Add 3 US influence to East Germany.\nThe US may conduct free coups or realignments in Europe with this card.\n\nPrevents and cancels Willy Brandt.",
				anEvilEmpire: "The US gains 1 VP.\n\nFlower Power is cancelled and can no longer be played.",
				aldrichAmesRemix: "The US reveals their hand for the rest of the turn, and the USSR discards one card from the US hand.",
				pershingIIDeployed: "The USSR gains 1 VP.\nRemove 1 US influence from each of any 3 countries in Western Europe.",
				wargames: "If DEFCON is 2, you may end the game immediately after giving the opponent 6 VP. How about a nice game of chess?",
				solidarity: "Add 3 US influence to Poland.\n\nRequires John Paul II Elected Pope to be played as an event.",
				iranIraqWar: "Iran invades Iraq or vice versa (your choice).\nRoll a die, -1 per enemy-controlled country adjacent to the target.\nOn a modified 4-6 you gain 2 VP and replace all opponent influence in the target with yours.\nGain 2 Military Operations.",
				defectors: "The US may play this in the Headline Phase to cancel the USSR headline event (including a scoring card); the cancelled card is discarded.\nIf the USSR plays this during an Action Round, the US gains 1 VP.",
				theCambridgeFive: "The US reveals all scoring cards in hand.\nThe USSR may add 1 USSR influence to one region named on a revealed scoring card.\n\nCannot be played as an event in the Late War.",
				specialRelationship: "If the US controls the UK and NATO is not in effect: add 1 US influence to a country adjacent to the UK.\nIf the US controls the UK and NATO is in effect: add 2 US influence to one Western Europe country and the US gains 2 VP.",
				norad: "If the US controls Canada, whenever DEFCON moves to 2 during an Action Round, the US adds 1 influence to a country already containing US influence at the end of that round.\n\nCancelled by Quagmire.",
				che: "The USSR may coup a non-Battleground country in Central America, South America or Africa with this card's Ops value.\nIf the first coup removed any US influence, a second coup against a different non-Battleground country is allowed.",
				ourManInTehran: "If the US controls at least one Middle East country, the US draws the top 5 cards of the deck, may discard any of them (revealed to the USSR, events do not trigger), and returns the rest, reshuffling the deck.",
				yuriAndSamantha: "For the rest of the turn, the USSR gains 1 VP for each US coup attempt.",
				awacsSaleToSaudis: "Add 2 US influence to Saudi Arabia.\n\nMuslim Revolution can no longer be played as an event."
			}
		}
	}
};
//#endregion
export { ei as default };
