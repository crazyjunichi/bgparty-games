import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { playTurn as u, useSoundEdge as d } from "@bgparty/sdk/sfx";
import { useWakeLock as f } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { seatName as m } from "@bgparty/sdk/ui/player-strip";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { Confetti as v } from "@bgparty/sdk/ui/confetti";
//#region src/games/maskmen/meta.ts
var y = {
	id: "maskmen",
	tier: "alpha",
	mechanics: ["hand-management"],
	interactionTags: [],
	nameKey: "games.maskmen.name",
	descKey: "games.maskmen.desc",
	rulesKey: "games.maskmen.rules",
	icon: "🤼",
	iconImg: "games/maskmen.webp",
	rulesUrl: { en: "https://content.cmpl.org/bg/Maskmen.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [
		4,
		5,
		6
	],
	accent: "#097c87",
	releasedAt: "2026-10-29T20:42:19+08:00",
	hotseat: "cover",
	search: {
		py: "mian ju ren mian ju shuai jiao shou feng kuang jia mian lian meng maskman",
		init: "mjrmjsjsfkjmlm"
	},
	botDelayMs: 650
}, b = t.int().min(0).max(5), x = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		wrestler: b,
		count: t.int().min(1).max(3)
	}),
	t.object({ type: t.literal("pass") }),
	t.object({ type: t.literal("ready") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), S = t.object({
	kind: t.enum([
		"play",
		"pass",
		"bout",
		"finish",
		"season"
	]),
	rid: t.string(),
	wrestler: t.int(),
	count: t.int()
}), C = t.object({
	phase: t.enum([
		"play",
		"resolve",
		"boutEnd",
		"seasonOver",
		"done"
	]),
	season: t.int(),
	turn: t.string(),
	host: t.string(),
	table: t.object({
		wrestler: b,
		count: t.int(),
		rid: t.string()
	}).nullable(),
	strength: t.array(t.array(t.boolean()).length(6)).length(6),
	seen: t.array(t.boolean()).length(6),
	played: t.array(t.int()).length(6),
	players: t.array(t.object({
		rid: t.string(),
		handCount: t.int(),
		score: t.int(),
		wins: t.int(),
		place: t.int().nullable(),
		passed: t.boolean(),
		ready: t.boolean()
	})),
	history: t.array(t.object({
		host: t.string(),
		order: t.array(t.string()),
		deltas: t.record(t.string(), t.int())
	})),
	log: t.array(S)
}), w = t.object({ hand: t.array(t.int().min(0).max(10)).length(6) });
function T(e, t, n) {
	let r = e.map((e) => [...e]);
	r[t][n] = !0;
	for (let e = 0; e < 6; e++) for (let t = 0; t < 6; t++) for (let n = 0; n < 6; n++) r[t][n] ||= r[t][e] && r[e][n];
	return r;
}
function E(e, t, n) {
	if (n < 1 || n > 3) return !1;
	let r = e.table;
	return r ? t === r.wrestler || e.strength[r.wrestler][t] ? !1 : e.strength[t][r.wrestler] ? n === r.count : n === r.count + 1 : e.seen[t] || n === 1;
}
var D = (e) => e.reduce((e, t) => e + t, 0);
function O(e, t, n = !1) {
	for (let r = 1; r <= e.players.length; r++) {
		let i = e.players[(e.players.indexOf(t) + r) % e.players.length];
		if (D(e.hands[i]) && (n || !e.passed.includes(i))) return i;
	}
	return t;
}
function k(t) {
	let n = Array.from({ length: 60 }, (e, t) => Math.floor(t / 10));
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	let r = t.players.length <= 4 ? 15 : t.players.length === 5 ? 12 : 10;
	t.players.forEach((e, i) => {
		t.hands[e] = [
			,
			,
			,
			,
			,
			,
		].fill(0), n.slice(i * r, (i + 1) * r).forEach((n) => t.hands[e][n]++);
	}), t.phase = "play", t.turn = t.host, t.table = null, t.strength = Array.from({ length: 6 }, () => [
		,
		,
		,
		,
		,
		,
	].fill(!1)), t.seen = [
		,
		,
		,
		,
		,
		,
	].fill(!1), t.played = [
		,
		,
		,
		,
		,
		,
	].fill(0), t.order = [], t.passed = [], t.ready = [];
}
function A(e, t, n) {
	let r = {
		seed: n,
		cursor: 0,
		players: t,
		season: 1,
		host: t[0],
		turn: t[0],
		phase: "play",
		table: null,
		strength: [],
		seen: [],
		played: [],
		hands: {},
		scores: Object.fromEntries(t.map((e) => [e, 0])),
		wins: Object.fromEntries(t.map((e) => [e, 0])),
		order: [],
		passed: [],
		ready: [],
		history: [],
		log: []
	};
	return k(r), { state: r };
}
function j(e) {
	let t = e.players.find((t) => !e.order.includes(t));
	e.order.push(t);
	let n = Object.fromEntries(e.players.map((n) => [n, n === e.order[0] ? 2 : n === t ? -1 : +(n === e.order[1])]));
	for (let t of e.players) e.scores[t] += n[t];
	e.wins[e.order[0]]++, e.history.push({
		host: e.host,
		order: [...e.order],
		deltas: n
	}), e.phase = "seasonOver", e.ready = [], e.log.push({
		kind: "season",
		rid: e.order[0],
		wrestler: -1,
		count: e.season
	});
}
function M(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "resolve" && e.phase !== "boutEnd") return { state: e };
		let t = structuredClone(e);
		if (t.phase === "boutEnd") {
			let e = t.table.rid;
			return t.table = null, t.passed = [], t.turn = D(t.hands[e]) ? e : O(t, e, !0), t.phase = "play", { state: t };
		}
		return t.order.length >= t.players.length - 1 ? (j(t), { state: t }) : (t.players.some((e) => e !== t.table.rid && D(t.hands[e]) && !t.passed.includes(e)) ? (t.phase = "play", t.turn = O(t, t.turn)) : (t.phase = "boutEnd", t.log.push({
			kind: "bout",
			rid: t.table.rid,
			wrestler: -1,
			count: 0
		})), { state: t });
	}
	if (!e.players.includes(n.by)) return { code: "games.maskmen.errTurn" };
	if (t.type === "ready") {
		if (e.phase !== "seasonOver" || e.ready.includes(n.by)) return { code: "games.maskmen.errTurn" };
		let t = structuredClone(e);
		return t.ready.push(n.by), t.ready.length === t.players.length && ((t.players.length === 2 ? Math.max(...Object.values(t.wins)) >= 3 : t.season === 4) ? t.phase = "done" : (t.host = t.order[t.order.length - 1], t.season++, k(t))), { state: t };
	}
	if (e.phase !== "play" || e.turn !== n.by || e.order.includes(n.by) || e.passed.includes(n.by)) return { code: "games.maskmen.errTurn" };
	if (t.type === "pass") {
		if (!e.table) return { code: "games.maskmen.errLead" };
		let t = structuredClone(e);
		return t.passed.push(n.by), t.phase = "resolve", t.log.push({
			kind: "pass",
			rid: n.by,
			wrestler: -1,
			count: 0
		}), { state: t };
	}
	if (e.hands[n.by][t.wrestler] < t.count || !E(e, t.wrestler, t.count)) return { code: "games.maskmen.errPlay" };
	let r = structuredClone(e);
	return r.table && !r.strength[t.wrestler][r.table.wrestler] && (r.strength = T(r.strength, t.wrestler, r.table.wrestler)), r.hands[n.by][t.wrestler] -= t.count, r.played[t.wrestler] += t.count, r.seen[t.wrestler] = !0, r.table = {
		wrestler: t.wrestler,
		count: t.count,
		rid: n.by
	}, r.phase = "resolve", r.log.push({
		kind: "play",
		rid: n.by,
		wrestler: t.wrestler,
		count: t.count
	}), D(r.hands[n.by]) || (r.order.push(n.by), r.log.push({
		kind: "finish",
		rid: n.by,
		wrestler: -1,
		count: r.order.length
	})), {
		state: r,
		fx: [{
			kind: "play",
			rid: n.by,
			data: {
				wrestler: t.wrestler,
				count: t.count
			}
		}]
	};
}
function N(e, t) {
	return {
		public: {
			phase: e.phase,
			season: e.season,
			host: e.host,
			turn: e.turn,
			table: e.table,
			strength: e.strength,
			seen: e.seen,
			played: e.played,
			history: e.history,
			log: e.log,
			players: e.players.map((t) => ({
				rid: t,
				handCount: D(e.hands[t]),
				score: e.scores[t],
				wins: e.wins[t],
				place: e.order.includes(t) ? e.order.indexOf(t) + 1 : null,
				passed: e.passed.includes(t),
				ready: e.ready.includes(t)
			}))
		},
		private: { hand: e.hands[t] ?? [
			,
			,
			,
			,
			,
			,
		].fill(0) }
	};
}
function P(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t, n) => e.players.length === 2 ? e.wins[n] - e.wins[t] : e.scores[n] - e.scores[t] || e.wins[n] - e.wins[t] || Number(t === e.host) - Number(n === e.host), n = [...e.players].sort(t);
	return {
		phase: "done",
		ranking: n,
		winner: n.filter((e) => t(e, n[0]) === 0),
		scores: e.players.length === 2 ? { ...e.wins } : { ...e.scores }
	};
}
var F = {
	meta: y,
	saveCompatibility: { version: "1" },
	schemas: {
		action: x,
		publicView: C,
		privateView: w
	},
	setup: A,
	reduce: M,
	viewFor: N,
	status: P,
	nextTickIn: (e) => e.phase === "resolve" || e.phase === "boutEnd" ? 500 : null
}, I = [
	"#f5ad13",
	"#ef8fa8",
	"#92958f",
	"#00b9d5",
	"#61346d",
	"#18bd72"
], L = [
	"games.maskmen.orange",
	"games.maskmen.pink",
	"games.maskmen.silver",
	"games.maskmen.blue",
	"games.maskmen.purple",
	"games.maskmen.green"
];
function R({ wrestler: e, className: t = "" }) {
	let r = n().replaceAll(":", ""), i = [
		"#f58b00",
		"#ffe1ad",
		"#e3e6e4",
		"#007b9f",
		"#ab52a1",
		"#087b41"
	][e];
	return /* @__PURE__ */ _("svg", {
		className: `mm-mask ${t}`,
		viewBox: "0 0 160 202",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ g("defs", { children: /* @__PURE__ */ _("linearGradient", {
				id: r,
				x1: "0",
				x2: "1",
				y2: ".8",
				children: [
					/* @__PURE__ */ g("stop", { stopColor: i }),
					/* @__PURE__ */ g("stop", {
						offset: ".54",
						stopColor: i
					}),
					/* @__PURE__ */ g("stop", {
						offset: "1",
						stopColor: i,
						stopOpacity: ".84"
					})
				]
			}) }),
			/* @__PURE__ */ g("path", {
				d: "M80 14C42 14 21 41 20 82L24 139C26 173 45 188 80 189C115 188 134 173 136 139L140 82C139 41 118 14 80 14Z",
				fill: `url(#${r})`
			}),
			e === 0 && /* @__PURE__ */ _("g", { children: [
				/* @__PURE__ */ g("path", {
					d: "M21 76H43C67 76 68 91 68 103S60 127 43 127H23M139 76H117C93 76 92 91 92 103S100 127 117 127H137",
					fill: "#386d78"
				}),
				/* @__PURE__ */ g("path", {
					d: "M22 80H42C59 80 64 89 64 103S57 123 42 123H23M138 80H118C101 80 96 89 96 103S103 123 118 123H137",
					fill: "none",
					stroke: "#dbb83a",
					strokeWidth: "1.3",
					strokeDasharray: "2 1.6"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "43",
					cy: "101",
					r: "13",
					fill: "#e8b52b",
					stroke: "#e8b52b",
					strokeWidth: "4"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "43",
					cy: "101",
					r: "12",
					fill: "#ffc720",
					stroke: "#386d78",
					strokeWidth: "1.4",
					strokeDasharray: "1.4 1.4"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "117",
					cy: "101",
					r: "13",
					fill: "#e8b52b",
					stroke: "#e8b52b",
					strokeWidth: "4"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "117",
					cy: "101",
					r: "12",
					fill: "#ffc720",
					stroke: "#386d78",
					strokeWidth: "1.4",
					strokeDasharray: "1.4 1.4"
				}),
				/* @__PURE__ */ g("path", {
					d: "M66 134Q80 126 94 134",
					fill: "none",
					stroke: "#ffbf36",
					strokeWidth: "3",
					strokeDasharray: "2 1.5"
				}),
				/* @__PURE__ */ g("ellipse", {
					cx: "80",
					cy: "157",
					rx: "27",
					ry: "29",
					fill: "#316a75"
				}),
				/* @__PURE__ */ g("ellipse", {
					cx: "80",
					cy: "157",
					rx: "23",
					ry: "25",
					fill: "none",
					stroke: "#d7ba36",
					strokeWidth: "1.3",
					strokeDasharray: "2 1.4"
				}),
				/* @__PURE__ */ g("ellipse", {
					cx: "80",
					cy: "157",
					rx: "14",
					ry: "20",
					fill: "#ffae09"
				}),
				/* @__PURE__ */ g("path", {
					d: "M80 136V178",
					stroke: "#366b75",
					strokeWidth: "9"
				}),
				/* @__PURE__ */ g("path", {
					d: "M80 138V176",
					stroke: "#d7ba36",
					strokeWidth: "1.2",
					strokeDasharray: "2 1.3"
				})
			] }),
			e === 1 && /* @__PURE__ */ _("g", { children: [
				/* @__PURE__ */ g("path", {
					d: "M76 14H84V82H76Z",
					fill: "#bc1553"
				}),
				/* @__PURE__ */ g("path", {
					d: "M79 16V83M82 16V83",
					stroke: "#ee91aa",
					strokeWidth: ".8",
					strokeDasharray: "1.5 1.3"
				}),
				/* @__PURE__ */ g("path", {
					d: "M80 88C55 62 28 69 28 89C26 117 57 118 80 95C103 118 134 117 132 89C132 69 105 62 80 88ZM80 96C72 105 64 116 66 127C68 143 92 143 94 127C96 116 88 105 80 96Z",
					fill: "#c11958"
				}),
				/* @__PURE__ */ g("path", {
					d: "M78 90C57 68 33 74 33 90C31 113 57 111 78 92ZM82 90C103 68 127 74 127 90C129 113 103 111 82 92ZM80 103C72 114 68 122 71 129C74 138 86 138 89 129C92 122 88 114 80 103Z",
					fill: "none",
					stroke: "#f8a5b6",
					strokeWidth: "1.1",
					strokeDasharray: "1.7 1.2"
				}),
				/* @__PURE__ */ g("path", {
					d: "M70 90C54 75 38 78 38 91C38 106 54 106 70 90ZM90 90C106 75 122 78 122 91C122 106 106 106 90 90ZM80 112C75 119 72 126 77 130Q80 133 83 130C88 126 85 119 80 112Z",
					fill: "#f7cea9"
				}),
				/* @__PURE__ */ g("path", {
					d: "M80 140C58 137 46 146 46 160C46 178 61 184 80 184C99 184 114 178 114 160C114 146 102 137 80 140Z",
					fill: "#c01655"
				}),
				/* @__PURE__ */ g("path", {
					d: "M80 145C60 142 51 149 51 160C51 174 63 179 80 179C97 179 109 174 109 160C109 149 100 142 80 145Z",
					fill: "none",
					stroke: "#f8a5b6",
					strokeWidth: "1.3",
					strokeDasharray: "2 1.5"
				}),
				/* @__PURE__ */ g("path", {
					d: "M58 151H102V169H58Z",
					fill: "#f386a3"
				}),
				/* @__PURE__ */ g("path", {
					d: "M63 156H97V165H63Z",
					fill: "#bf1451"
				})
			] }),
			e === 2 && /* @__PURE__ */ _("g", { children: [
				/* @__PURE__ */ g("path", {
					d: "M48 20L59 53L39 29M72 15L80 53L90 15M112 20L101 53L121 29",
					fill: "#394c55",
					stroke: "#a7b8b8",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ g("path", {
					d: "M46 22L56 48L42 29M76 17L80 46L86 17M114 22L104 48L118 29",
					fill: "none",
					stroke: "#ba7159",
					strokeWidth: "1",
					strokeDasharray: "2 1.5"
				}),
				/* @__PURE__ */ g("path", {
					d: "M51 57C40 68 26 95 26 113Q27 129 35 134L36 149L45 136L49 147L55 131Q72 119 68 102Q64 77 51 57ZM109 57C120 68 134 95 134 113Q133 129 125 134L124 149L115 136L111 147L105 131Q88 119 92 102Q96 77 109 57Z",
					fill: "#344954"
				}),
				/* @__PURE__ */ g("path", {
					d: "M51 64C42 75 31 98 31 112Q30 128 45 130Q68 129 64 106Q60 81 51 64ZM109 64C118 75 129 98 129 112Q130 128 115 130Q92 129 96 106Q100 81 109 64Z",
					fill: "none",
					stroke: "#ba7159",
					strokeWidth: "1.3",
					strokeDasharray: "2 1.6"
				}),
				/* @__PURE__ */ g("path", {
					d: "M51 77C43 91 38 104 38 113Q39 124 48 123Q59 124 58 112Q57 94 51 77ZM109 77C117 91 122 104 122 113Q121 124 112 123Q101 124 102 112Q103 94 109 77Z",
					fill: "#979f9e"
				}),
				/* @__PURE__ */ g("path", {
					d: "M80 140C58 135 47 145 47 161C47 178 59 183 80 183C101 183 113 178 113 161C113 145 102 135 80 140Z",
					fill: "#30434d"
				}),
				/* @__PURE__ */ g("path", {
					d: "M80 145C60 140 52 149 52 161C52 175 63 178 80 178C97 178 108 175 108 161C108 149 100 140 80 145Z",
					fill: "none",
					stroke: "#ba7159",
					strokeWidth: "1.3",
					strokeDasharray: "2 1.7"
				}),
				/* @__PURE__ */ g("path", {
					d: "M60 154H100V168H60Z",
					fill: "#9ba6a7"
				}),
				/* @__PURE__ */ g("path", {
					d: "M64 157H96V165H64Z",
					fill: "#24363f"
				})
			] }),
			e === 3 && /* @__PURE__ */ _("g", { children: [
				/* @__PURE__ */ g("path", {
					d: "M26 71C42 84 58 84 80 78C102 84 118 84 134 71L131 101C125 115 108 117 92 111L109 138H51L68 111C52 117 35 115 29 101Z",
					fill: "#ecf4ee"
				}),
				/* @__PURE__ */ g("path", {
					d: "M30 78C48 90 63 87 80 83C97 87 112 90 130 78L127 100C120 111 106 111 87 106L101 133H59L73 106C54 111 40 111 33 100Z",
					fill: "none",
					stroke: "#2f9ab8",
					strokeWidth: "1.3",
					strokeDasharray: "1.7 1.3"
				}),
				/* @__PURE__ */ g("path", {
					d: "M42 94H62Q70 94 70 100Q70 106 62 106H42Q34 106 34 100Q34 94 42 94ZM98 94H118Q126 94 126 100Q126 106 118 106H98Q90 106 90 100Q90 94 98 94Z",
					fill: "#ef6461",
					stroke: "#b1e2df",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ g("path", {
					d: "M80 112L67 130H93Z",
					fill: "#007b9f"
				}),
				/* @__PURE__ */ g("path", {
					d: "M80 139C58 139 49 148 49 162C49 180 62 186 80 186C98 186 111 180 111 162C111 148 102 139 80 139Z",
					fill: "#eff5ee"
				}),
				/* @__PURE__ */ g("path", {
					d: "M80 144C61 144 54 151 54 162C54 177 65 181 80 181C95 181 106 177 106 162C106 151 99 144 80 144Z",
					fill: "none",
					stroke: "#2996b2",
					strokeWidth: "1.3",
					strokeDasharray: "1.8 1.2"
				}),
				/* @__PURE__ */ g("path", {
					d: "M61 151H99V172H61Z",
					fill: "#0e9bc2"
				}),
				/* @__PURE__ */ g("path", {
					d: "M65 157H95V167H65Z",
					fill: "#00527d"
				})
			] }),
			e === 4 && /* @__PURE__ */ _("g", { children: [
				/* @__PURE__ */ g("path", {
					d: "M43 24L56 79L28 73L37 119L80 129L123 119L132 73L104 79L117 24L105 18L80 113L55 18Z",
					fill: "#4f2c56"
				}),
				/* @__PURE__ */ g("path", {
					d: "M48 25L61 87L34 80L41 114L76 121M112 25L99 87L126 80L119 114L84 121M53 23L80 118L107 23",
					fill: "none",
					stroke: "#a2b346",
					strokeWidth: "1.1",
					strokeDasharray: "2 1.6"
				}),
				/* @__PURE__ */ g("path", {
					d: "M40 87L59 92L64 111L44 107ZM120 87L101 92L96 111L116 107Z",
					fill: "#b5d63c"
				}),
				/* @__PURE__ */ g("path", {
					d: "M34 134L80 139L126 134L111 176L80 185L49 176Z",
					fill: "#4b2e52"
				}),
				/* @__PURE__ */ g("path", {
					d: "M40 140L80 145L120 140L107 172L80 180L53 172Z",
					fill: "none",
					stroke: "#aab33b",
					strokeWidth: "1.2",
					strokeDasharray: "2 1.4"
				}),
				/* @__PURE__ */ g("path", {
					d: "M49 148L80 152L111 148L103 165L80 172L57 165Z",
					fill: "#b9d63b"
				}),
				/* @__PURE__ */ g("path", {
					d: "M65 153H95V161H65Z",
					fill: "#422343"
				})
			] }),
			e === 5 && /* @__PURE__ */ _("g", { children: [
				/* @__PURE__ */ g("path", {
					d: "M27 67C48 68 65 78 80 92C95 78 112 68 133 67L127 135C124 161 105 179 80 188C55 179 36 161 33 135Z",
					fill: "#bfdf50"
				}),
				/* @__PURE__ */ g("path", {
					d: "M32 72C51 75 67 85 80 98C93 85 109 75 128 72L122 135C119 158 102 174 80 182C58 174 41 158 38 135Z",
					fill: "none",
					stroke: "#4c973c",
					strokeWidth: "1.4",
					strokeDasharray: "2 1.6"
				}),
				/* @__PURE__ */ g("path", {
					d: "M38 79C54 84 68 94 80 106C92 94 106 84 122 79L116 134C114 153 99 168 80 175C61 168 46 153 44 134Z",
					fill: "#174c3b"
				}),
				/* @__PURE__ */ g("path", {
					d: "M42 84C57 89 68 98 80 111C92 98 103 89 118 84L113 134C110 151 98 164 80 171C62 164 50 151 47 134Z",
					fill: "none",
					stroke: "#294f37",
					strokeWidth: "1"
				})
			] }),
			/* @__PURE__ */ g("path", {
				d: "M36 47Q29 68 30 90",
				fill: "none",
				stroke: "#fff",
				strokeOpacity: ".14",
				strokeWidth: "3",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ g("path", {
				d: "M27 144Q31 184 80 185Q129 184 133 144",
				fill: "none",
				stroke: "#14272d",
				strokeOpacity: ".13",
				strokeWidth: "2"
			})
		]
	});
}
function z({ value: e }) {
	if (e === 0) return /* @__PURE__ */ g("span", {
		className: "mm-zero",
		children: "0"
	});
	let t = e === 2, n = e < 0;
	return /* @__PURE__ */ _("svg", {
		viewBox: "0 0 116 44",
		className: "mm-belt",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M3 12L15 5H101L113 12V32L101 39H15L3 32Z",
				fill: t ? "#aa662d" : n ? "#17262b" : "#416572",
				stroke: "#283c41",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M36 7L42 2H74L80 7V37L74 42H42L36 37Z",
				fill: t ? "#fbd020" : n ? "#22292a" : "#d4e1e0",
				stroke: n ? "#785f41" : "#c1a242",
				strokeWidth: "2"
			}),
			[
				18,
				27,
				89,
				98
			].map((e) => /* @__PURE__ */ g("circle", {
				cx: e,
				cy: "22",
				r: "2",
				fill: "#192c32"
			}, e)),
			/* @__PURE__ */ _("text", {
				x: "58",
				y: "29",
				textAnchor: "middle",
				fill: n ? "#e67e4f" : "#343064",
				fontSize: "22",
				fontWeight: "900",
				children: [e > 0 ? "+" : "−", Math.abs(e)]
			})
		]
	});
}
//#endregion
//#region src/games/maskmen/board.tsx
function B({ wrestler: e, count: t }) {
	return /* @__PURE__ */ _("div", {
		className: "mm-card-face",
		style: { "--mm-card-color": I[e] },
		children: [/* @__PURE__ */ g(R, { wrestler: e }), t !== void 0 && /* @__PURE__ */ g("b", {
			className: "mm-card-number font-mono tabular-nums",
			children: t
		})]
	});
}
var V = [
	[82, 80],
	[300, 63],
	[518, 80],
	[518, 218],
	[300, 235],
	[82, 218]
];
function H({ pub: e }) {
	let t = c(), r = n().replaceAll(":", ""), i = e.strength.flatMap((t, n) => t.flatMap((r, i) => r && !t.some((t, n) => t && e.strength[n][i]) ? [[n, i]] : []));
	return /* @__PURE__ */ _("section", {
		className: "mm-strength",
		children: [/* @__PURE__ */ _("header", { children: [/* @__PURE__ */ g("h2", { children: t("games.maskmen.strength") }), /* @__PURE__ */ g("span", { children: t("games.maskmen.direction") })] }), /* @__PURE__ */ _("svg", {
			className: "mm-strength-map",
			viewBox: "0 0 600 310",
			role: "img",
			"aria-label": t("games.maskmen.strength"),
			children: [
				/* @__PURE__ */ g("defs", { children: /* @__PURE__ */ g("marker", {
					id: r,
					markerWidth: "8",
					markerHeight: "8",
					refX: "6",
					refY: "4",
					orient: "auto",
					children: /* @__PURE__ */ g("path", {
						d: "M1 1L6 4L1 7",
						fill: "none",
						stroke: "#31606a",
						strokeWidth: "1.5"
					})
				}) }),
				i.map(([e, n]) => {
					let [i, a] = V[e], [o, s] = V[n], c = Math.hypot(o - i, s - a);
					return /* @__PURE__ */ g("line", {
						x1: i + (o - i) * 51 / c,
						y1: a + (s - a) * 51 / c,
						x2: o - (o - i) * 57 / c,
						y2: s - (s - a) * 57 / c,
						stroke: "#31606a",
						strokeWidth: "2.5",
						markerEnd: `url(#${r})`,
						children: /* @__PURE__ */ _("title", { children: [
							t(L[e]),
							" → ",
							t(L[n])
						] })
					}, `${e}-${n}`);
				}),
				V.map(([n, r], i) => /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("svg", {
					x: n - 38,
					y: r - 51,
					width: "76",
					height: "96",
					opacity: e.seen[i] ? 1 : .55,
					children: /* @__PURE__ */ g(R, { wrestler: i })
				}), /* @__PURE__ */ g("text", {
					x: n,
					y: r + 63,
					textAnchor: "middle",
					fontSize: "16",
					fontWeight: "700",
					fill: "#234d56",
					children: t(L[i])
				})] }, i)),
				!i.length && /* @__PURE__ */ g("text", {
					x: "300",
					y: "158",
					textAnchor: "middle",
					fontSize: "16",
					fill: "#536b6b",
					children: t("games.maskmen.unknown")
				})
			]
		})]
	});
}
function U({ pub: e, nameOf: t }) {
	let n = c(), { ref: r, hidden: i } = o("mm-table");
	return /* @__PURE__ */ _("section", {
		className: "mm-arena",
		"aria-label": n("games.maskmen.arena"),
		children: [
			/* @__PURE__ */ g("div", { className: "mm-rope mm-rope-one" }),
			/* @__PURE__ */ g("div", { className: "mm-rope mm-rope-two" }),
			/* @__PURE__ */ g("div", { className: "mm-rope mm-rope-three" }),
			[
				0,
				1,
				2,
				3
			].map((e) => /* @__PURE__ */ g("i", { className: `mm-corner mm-corner-${e}` }, e)),
			/* @__PURE__ */ g("span", {
				className: "mm-arena-owner",
				children: n(e.table ? "games.maskmen.tableOwner" : "games.maskmen.lead", { name: t(e.table?.rid ?? e.turn) })
			}),
			/* @__PURE__ */ g("div", {
				ref: r,
				className: "mm-table-cards",
				style: { visibility: i ? "hidden" : void 0 },
				children: e.table ? Array.from({ length: e.table.count }, (t, n) => /* @__PURE__ */ g(B, { wrestler: e.table.wrestler }, n)) : /* @__PURE__ */ _("div", {
					className: "mm-ring-seal",
					"aria-hidden": "true",
					children: ["M", /* @__PURE__ */ g("span", { children: "MASKMEN" })]
				})
			})
		]
	});
}
//#endregion
//#region src/games/maskmen/view-player.tsx
function W({ player: e, name: t, color: n, index: r, active: i, mine: a, two: s }) {
	let l = c(), { ref: u } = o(`mm-seat:${e.rid}`);
	return /* @__PURE__ */ _("div", {
		ref: u,
		className: `mm-seat${i ? " mm-seat-active" : ""}${a ? " mm-seat-mine" : ""}${e.passed ? " mm-seat-passed" : ""}`,
		children: [
			/* @__PURE__ */ g("b", {
				className: "mm-seat-number",
				style: { background: n },
				children: r + 1
			}),
			/* @__PURE__ */ _("div", {
				className: "mm-seat-info",
				children: [/* @__PURE__ */ g("strong", {
					title: t,
					children: t
				}), /* @__PURE__ */ _("span", { children: [
					e.place ? l("games.maskmen.place", { n: e.place }) : l("games.maskmen.handCount", { n: e.handCount }),
					e.passed && /* @__PURE__ */ _(h, { children: [" · ", l("games.maskmen.passed")] }),
					e.ready && /* @__PURE__ */ _(h, { children: [" · ", l("games.maskmen.ready")] })
				] })]
			}),
			/* @__PURE__ */ g("b", {
				className: "mm-seat-score font-mono tabular-nums",
				children: s ? e.wins : e.score
			})
		]
	});
}
function G({ w: e, count: t, selected: n, legal: r, onSelect: i }) {
	let a = c(), { ref: s } = o(`mm-hand:${e}`);
	return /* @__PURE__ */ _("button", {
		ref: s,
		type: "button",
		className: `mm-hand-card${n ? " mm-hand-selected" : ""}${r ? " mm-hand-legal" : ""}`,
		disabled: !r,
		onClick: i,
		"aria-pressed": n,
		"aria-label": a("games.maskmen.cardLabel", {
			name: a(L[e]),
			n: t
		}),
		children: [
			/* @__PURE__ */ g(B, {
				wrestler: e,
				count: t
			}),
			/* @__PURE__ */ g("span", {
				className: "mm-hand-label",
				children: a(L[e])
			}),
			r && /* @__PURE__ */ g("svg", {
				className: "mm-march",
				viewBox: "0 0 100 150",
				preserveAspectRatio: "none",
				"aria-hidden": "true",
				children: /* @__PURE__ */ g("rect", {
					x: "2",
					y: "2",
					width: "96",
					height: "146",
					rx: "5",
					pathLength: "100"
				})
			})
		]
	});
}
function K(e) {
	return f(), /* @__PURE__ */ g(q, {
		...e,
		pub: e.public,
		priv: e.private
	}, e.myRid);
}
function q({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let o = c(), f = s((e) => e.locale), [v, y] = a(null), b = v?.key === e.log.length ? v : null, x = t?.hand ?? [
		,
		,
		,
		,
		,
		,
	].fill(0), S = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? m(t, f) : e;
	}, C = e.phase === "play" && e.turn === r, w = e.players.find((e) => e.rid === r), T = e.phase === "seasonOver" && !!w && !w.ready;
	d(C || T, u);
	let D = e.players.length === 2, O = D ? e.players.some((e) => e.wins >= 3) : e.season === 4, k = (t) => [
		1,
		2,
		3
	].filter((n) => n <= x[t] && E(e, t, n)), A = e.phase === "seasonOver" ? o("games.maskmen.seasonOver") : e.phase === "boutEnd" ? o("games.maskmen.boutEnd", { name: S(e.table.rid) }) : e.phase === "resolve" ? o(e.table?.rid === e.turn ? "games.maskmen.resolving" : "games.maskmen.passed") : C ? o(e.table ? "games.maskmen.turnYou" : "games.maskmen.leadYou") : o("games.maskmen.wait", { name: S(e.turn) }), j = /* @__PURE__ */ g("div", {
		className: "mm-actions",
		children: e.phase === "seasonOver" ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("span", {
			className: "mm-action-note",
			children: o(w?.ready ? "games.maskmen.waiting" : "games.maskmen.seasonOver")
		}), /* @__PURE__ */ g("button", {
			className: "mm-primary",
			disabled: !T,
			onClick: () => i({ type: "ready" }),
			children: o(O ? "games.maskmen.final" : "games.maskmen.continue")
		})] }) : /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("div", {
				className: "mm-counts",
				role: "group",
				"aria-label": b ? o("games.maskmen.selected", { name: o(L[b.wrestler]) }) : o("games.maskmen.choose"),
				children: [
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ g("button", {
					className: b?.count === e ? "mm-count mm-count-selected" : "mm-count",
					disabled: !C || !b || !k(b.wrestler).includes(e),
					"aria-pressed": b?.count === e,
					onClick: () => b && y({
						...b,
						count: e
					}),
					children: o("games.maskmen.count", { n: e })
				}, e))
			}),
			/* @__PURE__ */ g("button", {
				className: "mm-pass",
				disabled: !C || !e.table,
				onClick: () => i({ type: "pass" }),
				children: o("games.maskmen.pass")
			}),
			/* @__PURE__ */ g("button", {
				className: "mm-primary",
				disabled: !C || !b,
				onClick: () => b && i({
					type: "play",
					wrestler: b.wrestler,
					count: b.count
				}),
				children: o("games.maskmen.play")
			})
		] })
	});
	return /* @__PURE__ */ g(p, {
		className: "mm-screen",
		scroll: !1,
		actions: j,
		actionsHeight: "mm-actions-slot",
		banner: /* @__PURE__ */ _("div", {
			className: "mm-banner",
			children: [/* @__PURE__ */ g("div", {
				className: "mm-seats",
				style: { "--mm-seats": e.players.length },
				children: e.players.map((t, i) => /* @__PURE__ */ g(W, {
					player: t,
					name: S(t.rid),
					index: i,
					active: e.turn === t.rid && e.phase === "play",
					mine: t.rid === r,
					color: l[(n.find((e) => e.rid === t.rid)?.colorIndex ?? i) % l.length].hex,
					two: D
				}, t.rid))
			}), /* @__PURE__ */ _("div", {
				className: "mm-phase",
				children: [/* @__PURE__ */ g("b", { children: o("games.maskmen.season", { n: e.season }) }), /* @__PURE__ */ g("span", {
					"aria-live": "polite",
					children: A
				})]
			})]
		}),
		children: /* @__PURE__ */ _("div", {
			className: "mm-main",
			children: [
				/* @__PURE__ */ _("div", {
					className: "mm-playfield",
					children: [/* @__PURE__ */ g(H, { pub: e }), /* @__PURE__ */ g(U, {
						pub: e,
						nameOf: S
					})]
				}),
				/* @__PURE__ */ _("section", {
					className: "mm-hand",
					children: [/* @__PURE__ */ _("header", { children: [/* @__PURE__ */ g("h2", { children: o("games.maskmen.hand") }), /* @__PURE__ */ g("span", { children: w && o("games.maskmen.handCount", { n: w.handCount }) })] }), /* @__PURE__ */ g("div", {
						className: "mm-hand-cards",
						children: I.map((t, n) => /* @__PURE__ */ g(G, {
							w: n,
							count: x[n],
							selected: b?.wrestler === n,
							legal: C && k(n).length > 0,
							onSelect: () => y({
								key: e.log.length,
								wrestler: n,
								count: k(n)[0]
							})
						}, n))
					})]
				}),
				e.phase === "seasonOver" && /* @__PURE__ */ g("section", {
					className: "mm-season-overlay",
					"aria-label": o("games.maskmen.seasonOver"),
					children: /* @__PURE__ */ _("div", {
						className: "mm-season-sheet",
						children: [/* @__PURE__ */ _("h2", { children: [
							o("games.maskmen.season", { n: e.season }),
							" · ",
							o("games.maskmen.seasonOver")
						] }), /* @__PURE__ */ g("div", {
							className: "mm-season-list",
							children: e.history.at(-1)?.order.map((t, n) => /* @__PURE__ */ _("div", {
								className: "mm-season-row",
								children: [
									/* @__PURE__ */ g("b", { children: n + 1 }),
									/* @__PURE__ */ g("strong", { children: S(t) }),
									/* @__PURE__ */ g(z, { value: e.history.at(-1).deltas[t] }),
									/* @__PURE__ */ g("span", {
										className: "font-mono tabular-nums",
										children: D ? e.players.find((e) => e.rid === t)?.wins : e.players.find((e) => e.rid === t)?.score
									})
								]
							}, t))
						})]
					})
				})
			]
		})
	});
}
//#endregion
//#region src/games/maskmen/bot.ts
var J = {
	shed: 3,
	weakFirst: .7,
	finishType: 1.8,
	control: .5,
	split: 1.2
};
function Y(e, t) {
	return t.flatMap((t, n) => [
		1,
		2,
		3
	].filter((r) => r <= t && E(e, n, r)).map((e) => ({
		type: "play",
		wrestler: n,
		count: e
	})));
}
function X(e, t, n = J) {
	let r = Y(e, t), i = t.reduce((e, t) => e + t, 0), a = { type: "pass" }, o = -Infinity;
	for (let s of r) {
		let { wrestler: r, count: c } = s, l = e.strength[r].filter(Boolean).length, u = e.strength.filter((e) => e[r]).length, d = t[r] - c, f = i - c === 0 ? 1e4 : c * n.shed + u * n.weakFirst - l * n.control + (d === 0 ? n.finishType : 0) - (d === 1 && t[r] > 1 ? n.split : 0);
		f > o && (o = f, a = s);
	}
	return a;
}
var Z = (e, t) => {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid);
	if (n.phase === "seasonOver") return r && !r.ready ? { action: { type: "ready" } } : null;
	if (n.phase !== "play" || n.turn !== t.rid || !e.private) return null;
	let i = Y(n, e.private.hand);
	if (t.difficulty === "weak") {
		let e = [...i, ...n.table ? [{ type: "pass" }] : []], t = Math.floor(4294967296 / e.length) * e.length, r;
		do
			r = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
		while (r >= t);
		return { action: e[r % e.length] };
	}
	return { action: X(n, e.private.hand) };
}, Q = (e, t, n) => e.type === "play" ? n("games.maskmen.hintPlay", {
	n: e.count,
	name: n(L[e.wrestler])
}) : e.type === "pass" ? n("games.maskmen.pass") : e.type === "ready" ? n("games.maskmen.continue") : "";
//#endregion
//#region src/games/maskmen/fx.tsx
function $({ from: e, to: t, wrestler: n, count: a, ms: o }) {
	let s = i(null);
	return r(() => {
		let n = e.x + e.w / 2 - t.x - t.w / 2, r = e.y + e.h / 2 - t.y - t.h / 2, i = Math.min(e.w / t.w, e.h / t.h), a = s.current?.animate([
			{ transform: `translate(${n}px,${r}px) scale(${i})` },
			{
				transform: `translate(${n * .4}px,${r * .4 - 16}px) scale(${.6 + i * .4})`,
				offset: .6
			},
			{ transform: "translate(0,0) scale(1)" }
		], {
			duration: o,
			easing: "cubic-bezier(.22,.7,.28,1)",
			fill: "both"
		});
		return () => a?.cancel();
	}, [
		e,
		t,
		o
	]), /* @__PURE__ */ g("div", {
		ref: s,
		className: "mm-flying-cards",
		style: {
			position: "absolute",
			left: t.x,
			top: t.y,
			width: t.w,
			height: t.h
		},
		children: Array.from({ length: a }, (e, t) => /* @__PURE__ */ g(B, { wrestler: n }, t))
	});
}
var ee = { play(e, t) {
	let n = e.data;
	if (!n) return null;
	let r = e.rid === t.myRid ? t.anchor(`mm-hand:${n.wrestler}`) : t.anchor(`mm-seat:${e.rid}`), i = t.anchor("mm-table");
	if (!r || !i) return null;
	let a = t.queued ? 120 : 500;
	return {
		ms: a,
		hide: t.queued ? [] : ["mm-table"],
		node: /* @__PURE__ */ g($, {
			from: r,
			to: i,
			ms: a,
			wrestler: n.wrestler,
			count: n.count
		})
	};
} };
//#endregion
//#region src/games/maskmen/game-over.tsx
function te({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let o = t, l = c(), u = s((e) => e.locale), [d, f] = a(!1), p = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? m(t, u) : e;
	}, h = o.players.length === 2;
	return /* @__PURE__ */ _("div", {
		className: "mm-over mm-screen",
		children: [
			/* @__PURE__ */ g(v, {}),
			/* @__PURE__ */ _("header", {
				className: "mm-over-heading",
				children: [
					/* @__PURE__ */ g(z, { value: 2 }),
					/* @__PURE__ */ g("h1", { children: l("games.maskmen.resultTitle") }),
					/* @__PURE__ */ g("span", { children: l("games.maskmen.season", { n: o.season }) })
				]
			}),
			/* @__PURE__ */ _("div", {
				className: "mm-over-content",
				children: [/* @__PURE__ */ _("div", {
					className: "mm-results-panel",
					"aria-hidden": d,
					inert: d,
					children: [/* @__PURE__ */ g("div", {
						className: "mm-podium",
						children: e.ranking.map((t, n) => {
							let r = o.players.find((e) => e.rid === t);
							return /* @__PURE__ */ _("section", {
								className: `mm-result${e.winner.includes(t) ? " mm-result-winner" : ""}`,
								children: [
									/* @__PURE__ */ g("span", {
										className: "mm-result-rank",
										children: n + 1
									}),
									/* @__PURE__ */ g("h2", { children: p(t) }),
									e.winner.includes(t) && /* @__PURE__ */ g("strong", {
										className: "mm-winner-label",
										children: l("games.maskmen.winner")
									}),
									/* @__PURE__ */ g("b", {
										className: "mm-result-total font-mono tabular-nums",
										children: h ? r.wins : r.score
									}),
									/* @__PURE__ */ g("span", { children: l(h ? "games.maskmen.wins" : "games.maskmen.score") }),
									/* @__PURE__ */ g("small", { children: l("games.maskmen.championCount", { n: r.wins }) })
								]
							}, t);
						})
					}), /* @__PURE__ */ _("section", {
						className: "mm-history",
						children: [/* @__PURE__ */ g("h2", { children: l("games.maskmen.history") }), /* @__PURE__ */ g("div", {
							className: "mm-history-scroll",
							children: /* @__PURE__ */ _("table", { children: [/* @__PURE__ */ g("thead", { children: /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", { children: l("games.maskmen.seasonLabel") }), o.players.map((e) => /* @__PURE__ */ g("th", { children: p(e.rid) }, e.rid))] }) }), /* @__PURE__ */ g("tbody", { children: o.history.map((e, t) => /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", { children: t + 1 }), o.players.map((t) => /* @__PURE__ */ g("td", { children: /* @__PURE__ */ g(z, { value: e.deltas[t.rid] }) }, t.rid))] }, t)) })] })
						})]
					})]
				}), /* @__PURE__ */ _("div", {
					className: "mm-review-field",
					"aria-hidden": !d,
					inert: !d,
					children: [/* @__PURE__ */ g(H, { pub: o }), /* @__PURE__ */ g(U, {
						pub: o,
						nameOf: p
					})]
				})]
			}),
			/* @__PURE__ */ _("footer", {
				className: "mm-over-actions",
				children: [
					/* @__PURE__ */ g("button", {
						className: "mm-pass",
						onClick: () => f(!d),
						children: l(d ? "games.maskmen.back" : "games.maskmen.review")
					}),
					r && /* @__PURE__ */ g("button", {
						className: "mm-primary",
						onClick: r,
						children: l("session.result.playAgain")
					}),
					i && /* @__PURE__ */ g("button", {
						className: "mm-pass",
						onClick: i,
						children: l("session.result.backToLobby")
					}),
					!r && !i && /* @__PURE__ */ g("span", { children: l("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/maskmen/entry.tsx
var ne = {
	definition: F,
	View: K,
	bot: Z,
	describe: Q,
	fx: ee,
	OverView: te,
	locales: {
		zh: {
			name: "面具人",
			desc: "面具摔跤手轮番登台，在出牌中决定谁更强",
			rules: "目标:\n2–6 人游玩，六种面具牌各 10 张。多人进行四个赛季，总分最高者获胜；两人以先赢三个赛季者获胜。\n发牌与首家:\n2–4 人每人 15 张，5 人每人 12 张，6 人每人 10 张。其余牌不公开，也不参与本赛季。首季由房主领出，以后由上一季末名领出。每季重新洗全部 60 张牌，清除力量关系。\n出牌:\n轮到你时，可以打出同一种面具的 1–3 张牌，或者弃权。新一轮领出时，若该种面具本赛季尚未登场，只能出 1 张；已经登场的面具可出 1–3 张。\n压牌时不能出相同面具。\n· 若两种面具的强弱关系未知，须比上一手多出 1 张，并确定新面具比上一种强；最多出 3 张。\n· 若已经确定新面具更强，须出与上一手相同的张数。\n已知较弱的面具不能出。力量关系可以传递，例如蓝胜橙、橙胜绿，则蓝也胜绿；没有关系的面具保持未知。\n弃权与收轮:\n弃权后整轮不能再出牌。其他仍持牌的玩家都弃权后，最后出牌者赢下该轮，清空场牌并重新领出。若最后出牌者已出完，则由其顺时针方向下一位仍持牌者领出。出完手牌者退出本赛季，但其他玩家仍能压过其最后一手。\n赛季计分:\n按出完手牌的先后，首名获得 2 分、次名获得 1 分，中间名次 0 分，末名扣 1 分；两人时末名扣 1 分。剩一人持牌时结束该季。所有人确认后进入下一季。\n获胜:\n多人四季后比较总分；相同时比较获得 2 分腰带的次数，仍相同则末季非首家优先；依然相同则共同获胜。两人不限制赛季数，先赢三季获胜。\n图示:\n力量图中的箭头指向较弱者，没有连线不代表相同力量。手牌上的数字是持有张数，选中面具后选择出牌张数。",
			orange: "橙面具",
			pink: "粉面具",
			silver: "银面具",
			blue: "蓝面具",
			purple: "紫面具",
			green: "绿面具",
			season: "第 {{n}} 赛季",
			turnYou: "轮到你出牌",
			leadYou: "请选择面具领出",
			wait: "等待 {{name}}",
			resolving: "登台中",
			boutEnd: "{{name}} 赢下本轮",
			seasonOver: "赛季结算",
			done: "冠军诞生",
			handCount: "{{n}} 张",
			place: "第 {{n}} 名",
			passed: "已弃权",
			ready: "已确认",
			strength: "力量关系",
			direction: "箭头指向较弱者",
			unknown: "尚未确定力量关系",
			arena: "擂台",
			lead: "{{name}} 领出",
			tableOwner: "{{name}} 出牌",
			hand: "你的手牌",
			play: "出牌",
			pass: "弃权",
			count: "{{n}} 张",
			cardLabel: "{{name}}，持有 {{n}} 张",
			selected: "已选 {{name}}",
			choose: "选择手牌",
			continue: "下一赛季",
			final: "查看总成绩",
			waiting: "等待其他玩家确认",
			score: "总分",
			wins: "胜季",
			championCount: "冠军腰带 {{n}} 条",
			resultTitle: "面具联盟冠军",
			winner: "获胜",
			history: "赛季成绩",
			seasonLabel: "赛季",
			review: "回看末季",
			back: "返回成绩",
			delta: "本季得分",
			errTurn: "现在不能执行此操作",
			errLead: "领出时必须出牌",
			errPlay: "这些牌不能压过当前组合",
			hintPlay: "打出 {{n}} 张{{name}}"
		},
		en: {
			name: "Maskmen",
			desc: "Send masked wrestlers into the ring and establish their strength as you play",
			rules: "Goal:\nFor 2–6 players, with ten cards of each of six masks. In multiplayer, play four seasons and score the most points. With two players, win three seasons first.\nDeal and opening player:\nDeal 15 cards each with 2–4 players, 12 with five, and 10 with six. Set unused cards aside unseen. The host opens the first season; the last player of each season opens the next. Shuffle all 60 cards and clear all strength relations each season.\nPlaying cards:\nOn your turn, play 1–3 cards of one mask, or pass. To lead a new bout, a mask that has not appeared this season must be played as a single card. A mask that has appeared may be led with 1–3 cards.\nTo beat the last play, use a different mask.\n· If their relative strength is unknown, play exactly one more card, establishing that your mask is stronger. You may never play more than three cards.\n· If your mask is already known to be stronger, play exactly the same number of cards.\nA known weaker mask cannot be played. Strength is transitive: if blue beats orange and orange beats green, blue beats green. Unconnected masks remain incomparable.\nPassing and ending a bout:\nAfter passing, you cannot rejoin that bout. When all other players still holding cards have passed, the last player to play wins the bout, clears the ring and leads again. If they have no cards left, the next player clockwise who still holds cards leads. Players who empty their hand leave the season, but their last play can still be beaten.\nSeason scoring:\nIn order of emptying hands, first scores 2 points, second scores 1, middle places score 0, and last loses 1. With two players, last loses 1. The season ends when only one player has cards. All players confirm before the next season.\nWinning:\nAfter four multiplayer seasons, compare total points, then the number of +2 belts, then favor anyone who did not open the last season. Remaining ties share victory. With two players, play until someone wins three seasons.\nReading the table:\nArrows in the strength chart point toward the weaker mask. Missing connections do not mean equal strength. Numbers on your cards show how many you hold; select a mask and then the number to play.",
			orange: "Orange mask",
			pink: "Pink mask",
			silver: "Silver mask",
			blue: "Blue mask",
			purple: "Purple mask",
			green: "Green mask",
			season: "Season {{n}}",
			turnYou: "Your turn",
			leadYou: "Choose a mask to lead",
			wait: "Waiting for {{name}}",
			resolving: "Entering the ring",
			boutEnd: "{{name}} wins the bout",
			seasonOver: "Season results",
			done: "The champion is decided",
			handCount: "{{n}} cards",
			place: "Place {{n}}",
			passed: "Passed",
			ready: "Ready",
			strength: "Strength",
			direction: "Arrows point to the weaker mask",
			unknown: "No strength relations yet",
			arena: "The ring",
			lead: "{{name}} leads",
			tableOwner: "{{name}} played",
			hand: "Your hand",
			play: "Play",
			pass: "Pass",
			count: "{{n}} cards",
			cardLabel: "{{name}}, holding {{n}} cards",
			selected: "{{name}} selected",
			choose: "Select a mask",
			continue: "Next season",
			final: "Final results",
			waiting: "Waiting for other players",
			score: "Total",
			wins: "Seasons won",
			championCount: "{{n}} champion belts",
			resultTitle: "Mask League Champions",
			winner: "Winner",
			history: "Season scores",
			seasonLabel: "Season",
			review: "Review last season",
			back: "Back to results",
			delta: "This season",
			errTurn: "You cannot do that now",
			errLead: "You must play a card to lead",
			errPlay: "Those cards cannot beat the current play",
			hintPlay: "Play {{n}} {{name}} cards"
		}
	}
};
//#endregion
export { ne as default };
