import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { LogSheet as c } from "@bgparty/sdk/ui/log-sheet";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { SeatBadgedAvatar as u, seatName as d } from "@bgparty/sdk/ui/player-strip";
import { BottomSheet as f } from "@bgparty/sdk/bottom-sheet";
import { IconCheck as p, IconClose as ee, IconLog as te, IconPile as ne } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as re } from "@bgparty/sdk/player-colors";
import { useFxAnchor as ie, useFxAnchorsMaybe as ae } from "@bgparty/sdk/fx/anchors";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Floater as oe, FlySprite as _, PulseBox as v } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as y } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as se, OptionSection as b } from "@bgparty/sdk/ui/game-options";
//#region src/games/dicetown/data.ts
var x = [
	"9",
	"10",
	"J",
	"Q",
	"K",
	"A"
], S = {
	mine: 0,
	bank: 1,
	store: 2,
	saloon: 3,
	sheriff: 4,
	prairie: 5
}, ce = {
	horse: 8,
	wagon: 5,
	holster: 4,
	hat: 3,
	slingshot: 2,
	boots: 1,
	cattle: 7,
	winchester: 6
}, le = [
	"horse",
	"wagon",
	"holster",
	"hat",
	"slingshot",
	"boots",
	"dynamite",
	"girls",
	"brute",
	"brute",
	"cheater",
	"cheater",
	"credits",
	"joe",
	"marshall",
	"evensplit",
	"wanted",
	"corruption",
	"elixir"
], ue = [
	"cattle",
	"winchester",
	"mule",
	"dog",
	"insurance",
	"desperado",
	"gift",
	"twoguns",
	"whiskey",
	"swindler"
], de = [
	"lasso",
	"herder",
	"recruitment",
	"persuasion",
	"bribe"
], fe = [
	"wealth",
	"charm",
	"fortune",
	"power",
	"protection",
	"friendship",
	"domination"
], C = [
	"gold2",
	"gold3",
	"gold4",
	"gold5",
	"money2",
	"money3",
	"star",
	"coupon",
	"discovery",
	"discovery",
	"nothing",
	"nothing"
], w = [
	{
		pair: 5,
		reward: 5
	},
	{
		pair: 1,
		reward: 5
	},
	{
		pair: 0,
		reward: 5
	},
	{
		pair: 4,
		reward: 5
	},
	{
		pair: 3,
		reward: 5
	},
	{
		pair: 2,
		reward: 5
	},
	{
		pair: 4,
		reward: 5
	},
	{
		pair: 5,
		reward: 5
	},
	{
		pair: 0,
		reward: 3
	}
], T = [
	2,
	2,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	3,
	3,
	3,
	3,
	3,
	2,
	2,
	2,
	2,
	5,
	5,
	5,
	4,
	4,
	4,
	4
], pe = [
	"S",
	"S",
	"S",
	"H",
	"H",
	"H",
	"D",
	"D",
	"D",
	"C",
	"C",
	"C"
], me = [
	"blessing",
	"blessing",
	"ambush",
	"ambush",
	"bodyguard",
	"warpath"
], he = {
	id: "dicetown",
	tier: "beta",
	mechanics: ["dice-rolling"],
	interactionTags: [],
	nameKey: "games.dicetown.name",
	descKey: "games.dicetown.desc",
	rulesKey: "games.dicetown.rules",
	icon: "🤠",
	iconImg: "games/dicetown.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/dicetown/en.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [4, 5],
	playerRange: (e) => ({
		min: 2,
		max: typeof e == "object" && e && e.wildwest === !0 ? 6 : 5
	}),
	accent: "#b45309",
	releasedAt: "2026-10-13",
	search: {
		py: "tou zi zhen",
		init: "tzz"
	},
	hotseat: "cover"
}, E = t.int().min(0).max(5), D = t.string(), ge = t.discriminatedUnion("type", [
	t.object({ type: t.literal("roll") }),
	t.object({
		type: t.literal("keep"),
		idxs: t.array(t.int().min(0).max(4)).max(5)
	}),
	t.object({ type: t.literal("brute") }),
	t.object({
		type: t.literal("cheat"),
		where: t.enum(["kept", "rolled"]),
		i: t.int().min(0).max(4),
		face: E
	}),
	t.object({
		type: t.literal("outlaw"),
		i: t.int().min(0).max(8)
	}),
	t.object({
		type: t.literal("tie"),
		pick: D
	}),
	t.object({
		type: t.literal("locChoice"),
		option: t.string()
	}),
	t.object({
		type: t.literal("pick"),
		i: t.int().min(0)
	}),
	t.object({
		type: t.literal("pickMulti"),
		is: t.array(t.int().min(0)).max(2)
	}),
	t.object({
		type: t.literal("target"),
		rid: D
	}),
	t.object({
		type: t.literal("offer"),
		accept: t.boolean()
	}),
	t.object({
		type: t.literal("cowPlace"),
		place: t.array(t.object({
			id: t.int().min(0),
			n: t.int().min(1)
		})).max(25)
	}),
	t.object({
		type: t.literal("indianChoice"),
		target: D.optional(),
		i: t.int().min(0).max(4).optional(),
		face: E.optional(),
		loc: t.string().optional()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), O = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("tie"),
		loc: t.string(),
		role: t.enum(["first", "second"]),
		candidates: t.array(D)
	}),
	t.object({
		k: t.literal("locChoice"),
		loc: t.string(),
		rid: D,
		options: t.array(t.string())
	}),
	t.object({
		k: t.literal("storePick"),
		rid: D,
		n: t.int()
	}),
	t.object({
		k: t.literal("saloonTarget"),
		rid: D,
		qs: t.int(),
		again: t.boolean()
	}),
	t.object({
		k: t.literal("saloonPick"),
		rid: D,
		from: D,
		n: t.int()
	}),
	t.object({
		k: t.literal("docPick"),
		rid: D
	}),
	t.object({
		k: t.literal("elixirVictim"),
		rid: D,
		elixir: t.string()
	}),
	t.object({
		k: t.literal("giveCard"),
		from: D,
		to: D,
		cardType: t.enum(["gs", "prop"])
	}),
	t.object({
		k: t.literal("protectPick"),
		rid: D
	}),
	t.object({
		k: t.literal("joeTarget"),
		rid: D
	}),
	t.object({
		k: t.literal("offer"),
		rid: D,
		card: t.string()
	}),
	t.object({
		k: t.literal("recruitPick"),
		rid: D,
		n: t.int()
	}),
	t.object({
		k: t.literal("cowPlace"),
		rid: D
	}),
	t.object({
		k: t.literal("indianOffer"),
		rid: D
	}),
	t.object({
		k: t.literal("indianGive"),
		rid: D
	}),
	t.object({
		k: t.literal("coupon"),
		rid: D
	}),
	t.object({
		k: t.literal("indianFx"),
		rid: D,
		face: t.string()
	}),
	t.object({
		k: t.literal("discovery"),
		rid: D
	}),
	t.object({
		k: t.literal("discoveryOrder"),
		rid: D,
		a: t.string(),
		b: t.string()
	}),
	t.object({
		k: t.literal("persuasion"),
		rid: D,
		n: t.int()
	}),
	t.object({
		k: t.literal("smokeSignals"),
		rid: D
	}),
	t.object({
		k: t.literal("finalTie"),
		candidates: t.array(D)
	}),
	t.object({
		k: t.literal("desperadoPick"),
		rid: D
	})
]), k = t.object({
	i: t.int(),
	pair: E,
	reward: t.int()
}), _e = t.object({
	rid: D,
	money: t.int(),
	nuggets: t.int(),
	gs: t.int(),
	props: t.int(),
	protectedProps: t.array(t.int()),
	ranches: t.int(),
	herd: t.int(),
	cowed: t.array(t.object({
		id: t.int(),
		value: t.int(),
		n: t.int()
	})),
	cowboys: t.array(t.string()),
	rodeos: t.int(),
	outlaws: t.array(k),
	captured: t.array(k),
	controlled: t.boolean(),
	done: t.boolean(),
	kept: t.int(),
	rolled: t.int(),
	bodyguard: t.boolean()
}), ve = t.array(t.object({
	rid: D,
	money: t.int(),
	nuggets: t.int(),
	cards: t.int(),
	properties: t.int(),
	herd: t.int(),
	outlaws: t.int().default(0),
	cowboys: t.int().default(0),
	rodeos: t.int().default(0)
})), ye = t.array(t.object({
	k: t.string(),
	p: t.record(t.string(), t.union([t.string(), t.number()])).optional()
})), be = t.object({
	from: t.string(),
	to: t.string(),
	n: t.int().min(1),
	asset: t.enum([
		"money",
		"gold",
		"card",
		"property",
		"badge",
		"outlaw",
		"cowboy",
		"cattle",
		"elixir",
		"river",
		"indian",
		"rodeo"
	]),
	label: t.string().optional()
}), A = t.object({
	round: t.int(),
	sheriffBefore: D,
	sheriffAfter: D,
	gains: ve,
	logs: ye
}), xe = t.object({
	id: t.int(),
	kind: t.enum([
		"reveal",
		"compare",
		"winner",
		"result",
		"prompt",
		"visit",
		"summary"
	]),
	loc: t.string(),
	rid: D.nullable(),
	role: t.enum(["first", "second"]).nullable(),
	logs: ye,
	gains: ve,
	transfers: t.array(be).default([]),
	rolls: t.array(t.object({
		rid: D,
		faces: t.array(E)
	})).default([])
}), Se = t.object({
	cfg: t.object({
		wildwest: t.boolean(),
		cowboys: t.boolean(),
		indians: t.boolean()
	}),
	round: t.int().min(1),
	phase: t.enum([
		"build",
		"resolve",
		"over"
	]),
	closing: t.boolean(),
	closingBy: D.nullable().default(null),
	moment: xe.nullable().default(null),
	lastRound: A.nullable().default(null),
	sheriff: D,
	bank: t.int(),
	stage: t.int(),
	mine: t.int(),
	prairie: t.int(),
	propUp: t.array(t.object({
		id: t.int(),
		value: t.int(),
		ranch: t.boolean()
	})),
	propDeck: t.int(),
	gsDeck: t.int(),
	gsDiscard: t.array(t.string()),
	elixUp: t.array(t.string()),
	riverDeck: t.int(),
	outlawWanted: t.array(k),
	outlawDeck: t.int(),
	cowboyUp: t.array(t.string()),
	rodeos: t.int(),
	indian: t.object({
		holder: D.nullable(),
		armed: t.boolean()
	}),
	step: t.string(),
	pending: O.nullable(),
	hands: t.record(t.string(), t.array(E)).nullable(),
	players: t.array(_e),
	firstRound: t.boolean(),
	log: t.array(t.object({
		k: t.string(),
		p: t.record(t.string(), t.union([t.string(), t.number()])).optional()
	}))
}), Ce = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("storePick"),
		drawn: t.array(t.string())
	}),
	t.object({
		k: t.literal("saloonPick"),
		cards: t.array(t.object({
			t: t.enum([
				"gs",
				"prop",
				"ranch"
			]),
			label: t.string()
		})),
		give: t.array(t.int())
	}),
	t.object({
		k: t.literal("discovery"),
		drawn: t.array(t.string())
	}),
	t.object({
		k: t.literal("persuasion"),
		drawn: t.array(t.int())
	}),
	t.object({
		k: t.literal("desperadoPick"),
		pile: t.array(k)
	}),
	t.object({
		k: t.literal("indianGive"),
		props: t.array(t.object({
			id: t.int(),
			value: t.int()
		}))
	})
]), we = t.object({
	gs: t.array(t.string()),
	props: t.array(t.object({
		id: t.int(),
		value: t.int()
	})),
	dice: t.array(E).nullable(),
	rolled: t.array(E),
	bruteFree: t.boolean(),
	canOutlaw: t.boolean(),
	pendingPriv: Ce.nullable()
}), Te = t.object({
	wildwest: t.boolean().default(!1),
	cowboys: t.boolean().default(!1),
	indians: t.boolean().default(!1)
}).default({
	wildwest: !1,
	cowboys: !1,
	indians: !1
}), j = {
	roll: 600,
	keep: 400,
	reveal: 1800,
	compare: 1200,
	winner: 1e3,
	result: 1e3,
	empty: 500,
	visit: 800,
	summary: 3e3
};
function M(e, t, n) {
	e.logSeq += 1, e.log.push({
		k: t,
		p: n
	}), e.log.length > 150 && (e.log = e.log.slice(-150));
}
function N(e, t, n, r, i = 1, a, o) {
	let s = !!o?.length;
	i > 0 && e.transfers.push({
		from: t,
		to: n,
		asset: r,
		n: i,
		...a && !s ? { label: a } : {},
		card: a,
		known: s ? o : void 0
	});
}
function P(t, n) {
	for (let r = n.length - 1; r > 0; --r) {
		let i = e(t.rngSeed, t.rng, r + 1);
		t.rng += 1, [n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function F(t) {
	let n = e(t.rngSeed, t.rng, 6);
	return t.rng += 1, n;
}
function I(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n, (t.get(n) ?? 0) + 1);
	let n = [...t.entries()].sort((e, t) => t[1] - e[1] || t[0] - e[0]), r = [...e].sort((e, t) => t - e);
	if (n[0][1] === 5) return [6, n[0][0]];
	if (n[0][1] === 4) return [
		5,
		n[0][0],
		n[1][0]
	];
	if (n[0][1] === 3 && n[1]?.[1] === 2) return [
		4,
		n[0][0],
		n[1][0]
	];
	let i = [...t.keys()].sort((e, t) => e - t);
	return i.length === 5 && i[4] - i[0] === 4 ? [3, i[4]] : n[0][1] === 3 ? [
		2,
		n[0][0],
		...r.filter((e) => e !== n[0][0])
	] : n[0][1] === 2 && n[1]?.[1] === 2 ? [
		1,
		n[0][0],
		n[1][0],
		n[2][0]
	] : n[0][1] === 2 ? [
		0,
		n[0][0],
		...r.filter((e) => e !== n[0][0])
	] : [-1, ...r];
}
function Ee(e, t) {
	for (let n = 0; n < Math.max(e.length, t.length); n += 1) {
		let r = (e[n] ?? -1) - (t[n] ?? -1);
		if (r !== 0) return r;
	}
	return 0;
}
function L(e) {
	return e.build.kept;
}
function R(e, t) {
	return e.build.kept.filter((e) => e === t).length;
}
function De(e, t) {
	return e.cowboys.filter((e) => e === t).length;
}
var z = {
	S: "♠",
	H: "♥",
	D: "♦",
	C: "♣"
};
function B(e) {
	return e < T.length ? T[e] : 0;
}
function V(e) {
	return { code: e };
}
function Oe() {
	return {
		part: "win1",
		first: null,
		second: null,
		firstChoice: "",
		execLeft: 0,
		stealN: 0,
		stealVictim: "",
		again: !1,
		againDone: !1,
		girlsOffered: !1,
		doubleMine: !1,
		lassoOn: !1,
		docQueue: [],
		elixQueue: [],
		docChain: !1,
		gained: {},
		indianAsked: [],
		indianRolled: !1,
		thFirst: null,
		thSecond: null
	};
}
function H(e) {
	let t = [
		"mine",
		"bank",
		"store",
		"saloon",
		"sheriff",
		"townhall"
	];
	return e.indians && e.wildwest && t.push("indianOffer"), e.cowboys && t.push("prairie"), t.push("doc", "roundEnd"), t;
}
function ke(t, n, r) {
	let i = Te.parse(t), a = i.wildwest, o = {
		players: [...n],
		cfg: i,
		round: 1,
		phase: "build",
		closing: !1,
		closingBy: null,
		moment: null,
		momentSeq: 0,
		beatMs: 0,
		lastRound: null,
		roundStart: [],
		roundSheriff: "",
		roundLogAt: 0,
		transfers: [],
		sceneRolls: [],
		sheriff: "",
		bank: 3,
		stage: a ? 2 : 0,
		mine: a && n.length > 2 ? 40 : 30,
		prairie: i.cowboys ? 20 : 0,
		gsDeck: [],
		gsDiscard: [],
		elixDeck: [],
		elixUp: [],
		elixDiscard: [],
		propDeck: [],
		propUp: [],
		riverDeck: [],
		outlawDeck: [],
		outlawWanted: [],
		cowboyDeck: [],
		cowboyUp: [],
		rodeos: i.cowboys ? 4 : 0,
		indian: {
			holder: null,
			armed: !1
		},
		warpath: null,
		herderBlock: [],
		docExtra: [],
		pl: {},
		steps: H(i),
		stepIdx: 0,
		res: Oe(),
		pending: null,
		queue: [],
		rngSeed: r,
		rng: 0,
		final: null,
		log: [],
		logSeq: 0
	};
	o.gsDeck = P(o, [
		...le,
		...a ? ue : [],
		...a && i.indians ? ["smokesignals"] : [],
		...i.cowboys ? de : []
	]), o.elixDeck = P(o, [...fe]), o.elixUp = [o.elixDeck.pop(), o.elixDeck.pop()];
	let s = Array.from({ length: T.length }, (e, t) => t);
	if (a) for (let e = 0; e < 10; e += 1) s.push(T.length + e);
	P(o, s), a && n.length === 2 && s.splice(0, 10), o.propDeck = s;
	for (let e = 0; e < 3; e += 1) o.propUp.push(o.propDeck.pop());
	a && (o.riverDeck = P(o, [...C]), o.outlawDeck = P(o, w.map((e, t) => t))), i.cowboys && (o.cowboyDeck = P(o, [...pe]), o.cowboyUp = [o.cowboyDeck.pop(), o.cowboyDeck.pop()]);
	for (let e of n) o.pl[e] = {
		money: 8,
		nuggets: 0,
		gs: [],
		props: [],
		protectedProps: [],
		ranches: 0,
		herd: 0,
		cowed: {},
		cowboys: [],
		rodeos: 0,
		outlaws: [],
		captured: [],
		controlled: !1,
		bodyguard: !1,
		grace: null,
		herdBonus: 0,
		build: {
			kept: [],
			rolled: [],
			done: !1,
			bruteFree: !1,
			preset: [],
			usedOutlaw: !1
		}
	};
	return o.sheriff = n[e(r, o.rng, n.length)], o.rng += 1, M(o, "log.round", { n: 1 }), o.roundStart = Ie(o), o.roundSheriff = o.sheriff, o.roundLogAt = o.logSeq, { state: o };
}
function Ae(e, t) {
	let n = e.pl[t], r = n.build, i = 5 - r.kept.length, a = [...r.preset.splice(0, r.preset.length)];
	for (; a.length < i;) a.push(F(e));
	if (e.closing || n.grace !== null && n.grace <= 1) {
		r.kept = [...r.kept, ...a], r.rolled = [], r.done = !0, je(e);
		return;
	}
	r.rolled = a, n.grace !== null && --n.grace;
}
function je(e) {
	e.players.every((t) => e.pl[t].build.done) && (e.phase = "resolve", e.stepIdx = 0, e.res = Oe(), M(e, "log.resolve", {}), K(e, "reveal", ""));
}
function Me(e, t) {
	if (e.pl[t].build.usedOutlaw && !e.closing) for (let n of e.players) n !== t && !e.pl[n].build.done && e.pl[n].grace === null && (e.pl[n].grace = 2);
	else if (!e.closing) {
		e.closing = !0, e.closingBy = t;
		for (let n of e.players) {
			let r = e.pl[n].build;
			n !== t && !r.done && r.rolled.length > 0 && (r.rolled = []);
		}
	}
	je(e);
}
function U(e, t, n) {
	if (n === "joe" || n === "swindler" || n === "gift") {
		e.queue.push({
			k: "applyCard",
			rid: t,
			card: n
		});
		return;
	}
	e.pl[t].gs.push(n);
}
function Ne(e) {
	return e.gsDeck.length === 0 && e.gsDiscard.length > 0 && (e.gsDeck = P(e, e.gsDiscard.splice(0))), e.gsDeck.pop();
}
function Pe(e, t) {
	let n = Ne(e);
	n && (N(e, "lot:store", `seat:${t}`, "card", 1, `gs.${n}`, [t]), U(e, t, n));
}
function W(e, t, n, r, i = "lot:townhall", a = [t]) {
	let o = e.pl[t];
	n >= T.length ? o.ranches += 1 : o.props.push(n), N(e, i, `seat:${t}`, "property", 1, n >= T.length ? "ranch" : `prop.${B(n)}`, a), r && (e.res.gained[t] || (e.res.gained[t] = []), e.res.gained[t].push(n));
}
function Fe(e, t, n) {
	let r = e.pl[t], i = r.gs.indexOf(n);
	i >= 0 && r.gs.splice(i, 1), e.gsDiscard.push(n), N(e, `seat:${t}`, "lot:store", "card", 1, `gs.${n}`);
}
function G(e) {
	return e.steps[e.stepIdx];
}
function Ie(e) {
	return e.players.map((t) => {
		let n = e.pl[t];
		return {
			rid: t,
			money: n.money,
			nuggets: n.nuggets,
			cards: n.gs.length,
			properties: n.props.length + n.protectedProps.length + n.ranches + Object.keys(n.cowed).length,
			herd: n.herd + Object.values(n.cowed).reduce((e, t) => e + t, 0),
			outlaws: n.outlaws.length + n.captured.length,
			cowboys: n.cowboys.length,
			rodeos: n.rodeos
		};
	});
}
function Le(e, t) {
	return Ie(t).map((t, n) => ({
		rid: t.rid,
		money: t.money - e[n].money,
		nuggets: t.nuggets - e[n].nuggets,
		cards: t.cards - e[n].cards,
		properties: t.properties - e[n].properties,
		herd: t.herd - e[n].herd,
		outlaws: t.outlaws - e[n].outlaws,
		cowboys: t.cowboys - e[n].cowboys,
		rodeos: t.rodeos - e[n].rodeos
	})).filter((e) => e.money || e.nuggets || e.cards || e.properties || e.herd || e.outlaws || e.cowboys || e.rodeos);
}
function K(e, t, n, r = null, i = null, a = [], o = []) {
	e.moment = {
		id: ++e.momentSeq,
		kind: t,
		loc: n,
		rid: r,
		role: i,
		logs: a,
		gains: o,
		rolls: e.sceneRolls,
		transfers: e.transfers.map(({ from: e, to: t, asset: n, n: r, label: i }) => ({
			from: e,
			to: t,
			asset: n,
			n: r,
			...i ? { label: i } : {}
		}))
	}, e.beatMs = t === "prompt" ? 0 : j[t], t === "result" && a.some((e) => e.k === "log.noControl" || e.k === "log.warpath") && (e.beatMs = j.empty);
}
function Re(e) {
	if (e.pending) {
		K(e, "prompt", e.moment?.loc || G(e), "rid" in e.pending ? e.pending.rid : "from" in e.pending ? e.pending.from : e.sheriff);
		return;
	}
	if (G(e) !== "roundEnd" && (e.moment?.kind === "reveal" || e.moment?.loc !== G(e))) {
		K(e, G(e) === "doc" || G(e) === "indianOffer" ? "visit" : "compare", G(e));
		return;
	}
	for (let t = 0; t < 16 && e.phase === "resolve"; t += 1) {
		let t = G(e), n = Ie(e), r = e.logSeq, i = e.res.first, a = e.res.second;
		if (e.queue.length > 0) {
			let t = e.queue.shift();
			t.k === "applyCard" ? (M(e, "log.play", {
				who: t.rid,
				card: `gs.${t.card}`
			}), N(e, `seat:${t.rid}`, "showdown", "card", 1, `gs.${t.card}`), xt(e, t.rid, t.card), t.then && e.queue.unshift(t.then)) : e.pending = t;
		} else Ve(e);
		if (e.phase !== "resolve") {
			e.moment = null;
			return;
		}
		if (e.moment?.kind === "summary") return;
		let o = e.logSeq > r ? e.log.slice(-(e.logSeq - r)) : [], s = Le(n, e);
		if (o.length || s.length || e.transfers.length || e.sceneRolls.length) {
			K(e, "result", t, null, null, o, s);
			return;
		}
		if (e.res.first && e.res.first !== i) {
			K(e, "winner", t, e.res.first, "first");
			return;
		}
		if (e.res.second && e.res.second !== a) {
			K(e, "winner", t, e.res.second, "second");
			return;
		}
		if (e.pending) {
			K(e, "prompt", t, "rid" in e.pending ? e.pending.rid : "from" in e.pending ? e.pending.from : e.sheriff);
			return;
		}
		if (G(e) !== t && G(e) !== "roundEnd") {
			K(e, G(e) === "doc" || G(e) === "indianOffer" ? "visit" : "compare", G(e));
			return;
		}
	}
}
function q(e) {
	e.res.part === "act1" ? e.res.part = "win2" : e.res.part === "act2" && (e.res.part = "done");
}
function ze(e) {
	G(e) === "bank" && e.cfg.wildwest && e.stage > 0 && (N(e, "stage", "lot:bank", "money", e.stage), M(e, "log.stageBank", { n: e.stage }), e.bank += e.stage, e.stage = 0), Be(e);
}
function Be(e) {
	let { gained: t, thFirst: n, thSecond: r } = e.res;
	e.res = Oe(), e.res.gained = t, e.res.thFirst = n, e.res.thSecond = r, e.stepIdx += 1;
}
function Ve(e) {
	let t = G(e);
	if (e.warpath === t) {
		M(e, "log.warpath", { loc: `loc.${t}` }), Be(e);
		return;
	}
	switch (t) {
		case "mine": return We(e, "mine");
		case "bank": return We(e, "bank");
		case "store": return We(e, "store");
		case "saloon": return We(e, "saloon");
		case "sheriff": return We(e, "sheriff");
		case "townhall": return $e(e);
		case "prairie": return it(e);
		case "indianOffer": return rt(e);
		case "doc": return st(e);
		case "roundEnd": return ft(e);
	}
}
function He(e, t, n, r, i) {
	let a = e.players.filter((e) => e !== i).map((t) => ({
		r: t,
		n: R(e.pl[t], n)
	})).sort((e, t) => t.n - e.n);
	if (a[0].n === 0) {
		r === "first" ? (M(e, "log.noControl", { loc: `loc.${t}` }), ze(e)) : e.res.part = "done";
		return;
	}
	let o = a.filter((e) => e.n === a[0].n);
	if (o.length > 1) {
		e.pending = {
			k: "tie",
			loc: t,
			role: r,
			candidates: o.map((e) => e.r)
		};
		return;
	}
	r === "first" ? (e.res.first = o[0].r, e.res.part = "act1") : (e.res.second = o[0].r, e.res.part = "act2");
}
function Ue(e, t) {
	switch (t) {
		case "mine": return e.riverDeck.length > 0 ? ["exploit", "river"] : ["exploit"];
		case "bank": return ["rob", "stage"];
		case "store": return ["draw", "doc"];
		case "saloon": return e.outlawDeck.length > 0 ? ["steal", "recruitOutlaw"] : ["steal"];
		case "sheriff": return e.outlawWanted.length > 0 ? ["badge", "chase"] : ["badge"];
		default: return ["a"];
	}
}
function We(e, t) {
	let n = e.res, r = e.cfg.wildwest;
	if (n.part === "win1") {
		if (t === "mine" && !n.indianRolled) {
			n.indianRolled = !0;
			let t = e.indian;
			if (t.holder && t.armed) {
				t.armed = !1;
				let n = me[F(e)];
				M(e, "log.indianFx", {
					who: t.holder,
					face: `indian.${n}`
				}), n === "bodyguard" ? e.pl[t.holder].bodyguard = !0 : e.pending = {
					k: "indianFx",
					rid: t.holder,
					face: n
				};
			}
			return;
		}
		He(e, t, S[t], "first", null);
		return;
	}
	if (n.part === "act1" && n.first) {
		if (t === "store" && n.execLeft > 0) {
			Je(e, n.first);
			return;
		}
		let i = Ue(e, t);
		if (r && i.length > 1) {
			e.pending = {
				k: "locChoice",
				loc: t,
				rid: n.first,
				options: i
			};
			return;
		}
		n.firstChoice = i[0], Ge(e, t, n.first, i[0]);
		return;
	}
	if (n.part === "win2") {
		if (!r || e.players.length <= 2) {
			n.part = "done";
			return;
		}
		He(e, t, S[t], "second", n.first);
		return;
	}
	if (n.part === "act2" && n.second) {
		if (t === "store" && n.execLeft > 0) {
			Je(e, n.second);
			return;
		}
		let r = Ue(e, t).filter((e) => e !== n.firstChoice);
		if (r.length === 0) {
			q(e);
			return;
		}
		Ge(e, t, n.second, r[0]);
		return;
	}
	ze(e);
}
function Ge(e, t, n, r) {
	let i = e.pl[n];
	i.controlled = !0;
	let a = R(i, S[t]);
	if (t === "mine") {
		if (r === "river") {
			ut(e, n);
			return;
		}
		if (i.gs.includes("dynamite")) {
			e.pending = {
				k: "offer",
				rid: n,
				card: "dynamite"
			};
			return;
		}
		Ke(e, n, a), q(e);
		return;
	}
	if (t === "bank") {
		if (r === "stage") {
			let t = Math.min(a, e.stage);
			e.stage -= t, i.money += t, N(e, "stage", `seat:${n}`, "money", t), M(e, "log.stage", {
				who: n,
				n: t
			}), q(e);
			return;
		}
		let t = e.bank;
		e.bank = 0, i.money += t, N(e, "lot:bank", `seat:${n}`, "money", t), M(e, "log.bank", {
			who: n,
			n: t
		});
		let o = e.players.find((t) => t !== n && e.pl[t].gs.includes("evensplit"));
		if (o && t > 0) {
			e.pending = {
				k: "offer",
				rid: o,
				card: "evensplit",
				data: {
					robber: n,
					take: t
				}
			};
			return;
		}
		qe(e, n), q(e);
		return;
	}
	if (t === "store") {
		if (r === "doc") {
			e.docExtra.push(n), M(e, "log.docPlan", { who: n }), q(e);
			return;
		}
		if (i.gs.includes("credits")) {
			e.pending = {
				k: "offer",
				rid: n,
				card: "credits"
			};
			return;
		}
		e.res.execLeft = e.round === 1 ? 2 : 1, Je(e, n);
		return;
	}
	if (t === "saloon") {
		if (r === "recruitOutlaw") {
			Ye(e, n);
			return;
		}
		if (i.gs.includes("girls") && !e.res.girlsOffered) {
			e.res.girlsOffered = !0, e.pending = {
				k: "offer",
				rid: n,
				card: "girls"
			};
			return;
		}
		e.pending = {
			k: "saloonTarget",
			rid: n,
			qs: a
		};
		return;
	}
	if (r === "chase") {
		Xe(e, n);
		return;
	}
	e.sheriff === n ? M(e, "log.sheriffKeep", { who: n }) : Qe(e, n, "loc"), q(e);
}
function Ke(e, t, n) {
	let r = e.pl[t], i = Math.min(n * (e.res.doubleMine ? 2 : 1) + De(r, "S"), e.mine);
	e.mine -= i, r.nuggets += i, N(e, "lot:mine", `seat:${t}`, "gold", i), M(e, "log.mine", {
		who: t,
		n: i
	});
}
function qe(e, t) {
	let n = De(e.pl[t], "D");
	if (n > 0) for (let r of e.players) {
		if (r === t) continue;
		let i = Math.min(n, e.pl[r].money);
		e.pl[r].money -= i, e.pl[t].money += i, N(e, `seat:${r}`, `seat:${t}`, "money", i);
	}
	!e.cfg.wildwest && e.stage > 0 && (N(e, "stage", "lot:bank", "money", e.stage), M(e, "log.stageBank", { n: e.stage }), e.bank += e.stage, e.stage = 0);
}
function Je(e, t) {
	let n = R(e.pl[t], S.store), r = [];
	for (let t = 0; t < n; t += 1) {
		let t = Ne(e);
		t && r.push(t);
	}
	if (r.length === 0) {
		--e.res.execLeft, e.res.execLeft > 0 ? Je(e, t) : q(e);
		return;
	}
	M(e, "log.store", {
		who: t,
		n
	});
	for (let n of r) N(e, "lot:store", "showdown", "card", 1, `gs.${n}`, [t]);
	e.pending = {
		k: "storePick",
		rid: t,
		drawn: r
	};
}
function Ye(e, t) {
	if (e.pl[t].gs.includes("desperado") && e.outlawDeck.length > 1) {
		e.pending = {
			k: "offer",
			rid: t,
			card: "desperado"
		};
		return;
	}
	let n = e.outlawDeck.pop();
	n !== void 0 && (e.pl[t].outlaws.push(n), N(e, "lot:saloon", `seat:${t}`, "outlaw", 1, `${w[n].reward}`), M(e, "log.recruitOutlaw", { who: t })), q(e);
}
function Xe(e, t) {
	let n = R(e.pl[t], S.sheriff), r = [];
	for (let t = 0; t < n; t += 1) r.push(F(e));
	e.sceneRolls.push({
		rid: t,
		faces: r
	});
	let i = Ze(e, t, r);
	if (M(e, "log.chase", {
		who: t,
		n: n - i.length
	}), i.length > 0 && e.pl[t].gs.includes("twoguns")) {
		e.pending = {
			k: "offer",
			rid: t,
			card: "twoguns"
		};
		return;
	}
	q(e);
}
function Ze(e, t, n) {
	let r = e.pl[t], i = [];
	for (let a of n) {
		let n = e.outlawWanted.findIndex((e) => w[e].pair === a);
		if (n >= 0) {
			let i = e.outlawWanted.splice(n, 1)[0];
			r.captured.push(i), N(e, "lot:sheriff", `seat:${t}`, "outlaw", 1, `${w[i].reward}`), M(e, "log.capture", {
				who: t,
				reward: w[i].reward
			});
		} else i.push(a);
	}
	return i;
}
function Qe(e, t, n) {
	let r = e.sheriff;
	e.sheriff = t, N(e, `seat:${r}`, `seat:${t}`, "badge"), M(e, "log.sheriff", {
		who: t,
		why: n
	}), r !== t && e.pl[r] && e.pl[r].gs.includes("marshall") && e.queue.push({
		k: "offer",
		rid: r,
		card: "marshall",
		data: { old: r }
	});
}
function $e(e) {
	let t = e.res, n = e.cfg.wildwest;
	if (t.part === "win1") {
		let n = [...e.players].sort((t, n) => Ee(I(L(e.pl[n])), I(L(e.pl[t])))), r = n.filter((t) => Ee(I(L(e.pl[t])), I(L(e.pl[n[0]]))) === 0);
		if (r.length > 1) {
			e.pending = {
				k: "tie",
				loc: "townhall",
				role: "first",
				candidates: r
			};
			return;
		}
		t.first = n[0], t.thFirst = n[0], t.part = "act1";
		return;
	}
	if (t.part === "act1" && t.first) {
		let r = [];
		if (e.propUp.length > 0 && r.push("normal"), n && e.propDeck.length > 0 && r.push("mayor"), e.pl[t.first].gs.includes("bribe") && e.propDeck.length > 0 && r.push("bribe"), r.length === 0) {
			M(e, "log.noControl", { loc: "loc.townhall" }), Be(e);
			return;
		}
		if (r.length > 1) {
			e.pending = {
				k: "locChoice",
				loc: "townhall",
				rid: t.first,
				options: r
			};
			return;
		}
		t.firstChoice = r[0], et(e, t.first, r[0]);
		return;
	}
	if (t.part === "win2") {
		if (!n || e.players.length <= 2) {
			t.part = "done";
			return;
		}
		let r = [...e.players.filter((e) => e !== t.first)].sort((t, n) => Ee(I(L(e.pl[n])), I(L(e.pl[t])))), i = r.filter((t) => Ee(I(L(e.pl[t])), I(L(e.pl[r[0]]))) === 0);
		if (i.length > 1) {
			e.pending = {
				k: "tie",
				loc: "townhall",
				role: "second",
				candidates: i
			};
			return;
		}
		t.second = r[0], t.thSecond = r[0], t.part = "act2";
		return;
	}
	if (t.part === "act2" && t.second) {
		t.firstChoice === "normal" ? e.propDeck.length > 0 && nt(e, t.second) : e.propUp.length > 0 && tt(e, t.second), q(e);
		return;
	}
	Be(e);
}
function et(e, t, n) {
	if (n === "bribe") {
		Fe(e, t, "bribe"), M(e, "log.play", {
			who: t,
			card: "gs.bribe"
		}), e.pl[t].controlled = !0;
		for (let n = 0; n < 2; n += 1) {
			let n = e.propDeck.pop();
			n !== void 0 && W(e, t, n, !0);
		}
		M(e, "log.mayor", {
			who: t,
			n: 2
		}), q(e);
		return;
	}
	if (n === "mayor") {
		nt(e, t), q(e);
		return;
	}
	tt(e, t), e.pending || q(e);
}
function tt(e, t) {
	let n = e.pl[t];
	n.controlled = !0;
	let r = e.cfg.cowboys ? 0 : R(n, 5), i = Math.min(1 + r, 3, e.propUp.length);
	for (let n = 0; n < i; n += 1) W(e, t, e.propUp.shift(), !0, "lot:townhall", []);
	for (; e.propUp.length < 3 && e.propDeck.length > 0;) e.propUp.push(e.propDeck.pop());
	if (M(e, "log.townhall", {
		who: t,
		n: i
	}), n.gs.includes("corruption") && e.propDeck.length > 0) {
		e.pending = {
			k: "offer",
			rid: t,
			card: "corruption"
		};
		return;
	}
	if (n.gs.includes("persuasion") && R(n, 5) > 0 && e.propDeck.length > 0) {
		e.pending = {
			k: "offer",
			rid: t,
			card: "persuasion"
		};
		return;
	}
}
function nt(e, t) {
	let n = e.propDeck.pop();
	n !== void 0 && (e.pl[t].controlled = !0, W(e, t, n, !0), M(e, "log.mayor", {
		who: t,
		n: 1
	}));
}
function rt(e) {
	let t = e.res, n = [t.thFirst, t.thSecond].filter((e) => !!e && !t.indianAsked.includes(e)).find((e) => (t.gained[e] ?? []).length > 0);
	if (!n) {
		e.indian.holder && (N(e, `seat:${e.indian.holder}`, "village", "indian"), e.indian = {
			holder: null,
			armed: !1
		}, M(e, "log.indianBack", {})), Be(e);
		return;
	}
	t.indianAsked.push(n), e.pending = {
		k: "indianOffer",
		rid: n
	};
}
function it(e) {
	let t = e.res, n = e.cfg.wildwest;
	if (t.part === "win1") {
		He(e, "prairie", 5, "first", null);
		return;
	}
	if (t.part === "act1" && t.first) {
		let r = [];
		if ((e.prairie > 0 || e.players.some((n) => n !== t.first && e.pl[n].herd > 0)) && r.push("steal"), e.cowboyUp.length > 0 && r.push("recruit"), r.length === 0) {
			M(e, "log.noControl", { loc: "loc.prairie" }), Be(e);
			return;
		}
		if (n && r.length > 1) {
			e.pending = {
				k: "locChoice",
				loc: "prairie",
				rid: t.first,
				options: r
			};
			return;
		}
		t.firstChoice = r[0], at(e, t.first, r[0]);
		return;
	}
	if (t.part === "win2") {
		if (!n || e.players.length <= 2) {
			t.part = "done";
			return;
		}
		He(e, "prairie", 5, "second", t.first);
		return;
	}
	if (t.part === "act2" && t.second) {
		at(e, t.second, t.firstChoice === "steal" ? "recruit" : "steal");
		return;
	}
	Be(e);
}
function at(e, t, n) {
	let r = e.pl[t];
	if (r.controlled = !0, n === "recruit") {
		if (e.cowboyUp.length === 0) {
			q(e);
			return;
		}
		if (r.gs.includes("recruitment")) {
			e.pending = {
				k: "offer",
				rid: t,
				card: "recruitment"
			};
			return;
		}
		e.pending = {
			k: "recruitPick",
			rid: t,
			n: 1
		};
		return;
	}
	let i = R(r, 5);
	if (r.gs.includes("lasso")) {
		e.pending = {
			k: "offer",
			rid: t,
			card: "lasso",
			data: { aces: i }
		};
		return;
	}
	ot(e, t, i);
}
function ot(e, t, n) {
	let r = e.pl[t], i = n > 0 ? n * (e.res.lassoOn ? 2 : 1) + De(r, "C") : e.res.stealN, a = Math.min(i, e.prairie);
	for (e.prairie -= a, r.herd += a, N(e, "lot:prairie", `seat:${t}`, "cattle", a), i -= a; i > 0;) {
		let n = e.players.find((n) => n !== t && e.pl[n].herd > 0 && !e.pl[n].bodyguard && !e.herderBlock.includes(n));
		if (!n) break;
		if (e.pl[n].gs.includes("herder")) {
			e.res.stealN = i, e.res.stealVictim = n, e.pending = {
				k: "offer",
				rid: n,
				card: "herder",
				data: {
					stealer: t,
					left: i
				}
			};
			return;
		}
		let a = Math.min(i, e.pl[n].herd);
		e.pl[n].herd -= a, r.herd += a, N(e, `seat:${n}`, `seat:${t}`, "cattle", a), i -= a;
	}
	if (M(e, "log.prairieSteal", {
		who: t,
		n: r.herd
	}), r.herd > 0 && r.props.length > 0) {
		e.pending = {
			k: "cowPlace",
			rid: t
		};
		return;
	}
	q(e);
}
function st(e) {
	let t = e.res;
	if (t.part === "win1") {
		if (t.docQueue = [...e.docExtra, ...e.players.filter((t) => !e.pl[t].controlled && !e.docExtra.includes(t))], t.part = "act1", t.docQueue.length === 0) {
			Be(e);
			return;
		}
		return;
	}
	if (t.elixQueue.length > 0) {
		let n = t.elixQueue.shift();
		if (e.pl[n].gs.includes("elixir")) {
			e.pending = {
				k: "offer",
				rid: n,
				card: "elixir"
			};
			return;
		}
		return;
	}
	if (t.docQueue.length === 0) {
		Be(e);
		return;
	}
	e.pending = {
		k: "docPick",
		rid: t.docQueue[0]
	};
}
function ct(e) {
	for (e.res.docQueue.shift(); e.elixUp.length < 2 && e.elixDeck.length > 0;) e.elixUp.push(e.elixDeck.pop());
	e.res.elixQueue = e.players.filter((t) => e.pl[t].gs.includes("elixir")), e.res.docChain = !1;
}
function lt(e, t, n) {
	let r = e.pl[t];
	switch (M(e, "log.doc", {
		who: t,
		elixir: `elix.${n}`
	}), N(e, "lot:doc", "showdown", "elixir", 1, `elix.${n}`), n) {
		case "wealth":
			for (let n of e.players) {
				if (n === t) continue;
				let i = Math.min(2, e.pl[n].money);
				e.pl[n].money -= i, r.money += i, N(e, `seat:${n}`, `seat:${t}`, "money", i);
			}
			break;
		case "charm":
			for (let n of e.players) n !== t && e.pl[n].nuggets > 0 && (--e.pl[n].nuggets, r.nuggets += 1, N(e, `seat:${n}`, `seat:${t}`, "gold"));
			break;
		case "fortune":
			Pe(e, t);
			break;
		case "power":
			e.sheriff !== t && Qe(e, t, "elixir");
			break;
		case "protection":
			if (r.props.length > 0) {
				e.res.docChain = !0, e.pending = {
					k: "protectPick",
					rid: t
				};
				return;
			}
			break;
		case "friendship":
		case "domination": if (e.players.filter((r) => r !== t && !e.pl[r].bodyguard && (n === "friendship" ? e.pl[r].gs.length > 0 : e.pl[r].props.length > 0)).length > 0) {
			e.res.docChain = !0, e.pending = {
				k: "elixirVictim",
				rid: t,
				elixir: n
			};
			return;
		}
	}
	ct(e);
}
function ut(e, t) {
	let n = e.riverDeck.pop();
	if (!n) {
		q(e);
		return;
	}
	dt(e, t, n), e.pending || q(e);
}
function dt(e, t, n, r = "lot:mine") {
	let i = e.pl[t];
	switch (i.controlled = !0, M(e, "log.river", {
		who: t,
		card: `river.${n}`
	}), N(e, r, "showdown", "river", 1, `river.${n}`), n) {
		case "gold2":
		case "gold3":
		case "gold4":
		case "gold5": {
			let r = Math.min(Number(n.slice(4)), e.mine);
			e.mine -= r, i.nuggets += r, N(e, "lot:mine", `seat:${t}`, "gold", r);
			break;
		}
		case "money2":
		case "money3": {
			let r = Math.min(Number(n.slice(5)), e.bank);
			e.bank -= r, i.money += r, N(e, "lot:bank", `seat:${t}`, "money", r);
			break;
		}
		case "star":
			e.sheriff !== t && Qe(e, t, "river");
			break;
		case "coupon":
			if (e.gsDiscard.length > 0) {
				e.pending = {
					k: "coupon",
					rid: t
				};
				return;
			}
			break;
		case "discovery": {
			let n = [];
			for (let t = 0; t < 3 && e.riverDeck.length > 0; t += 1) n.push(e.riverDeck.pop());
			if (n.length > 1) for (let r of n) N(e, "lot:mine", "showdown", "river", 1, `river.${r}`, [t]);
			if (n.length === 1) {
				dt(e, t, n[0]);
				return;
			}
			if (n.length > 1) {
				e.pending = {
					k: "discovery",
					rid: t,
					drawn: n
				};
				return;
			}
			break;
		}
	}
}
function ft(e) {
	if (e.cfg.indians && e.cfg.wildwest) {
		let t = e.players.find((t) => e.pl[t].gs.includes("smokesignals") && e.indian.holder !== t && !e.res.indianAsked.includes(t));
		if (t) {
			e.res.indianAsked.push(t), e.pending = {
				k: "smokeSignals",
				rid: t
			};
			return;
		}
	}
	if (e.lastRound?.round !== e.round) {
		let t = Le(e.roundStart, e), n = e.logSeq > e.roundLogAt ? e.log.slice(-(e.logSeq - e.roundLogAt)) : [];
		e.lastRound = {
			round: e.round,
			sheriffBefore: e.roundSheriff,
			sheriffAfter: e.sheriff,
			gains: t,
			logs: n
		}, K(e, "summary", "roundEnd", null, null, [], t);
		return;
	}
	if (e.mine <= 0 || e.propDeck.length === 0 && e.propUp.length === 0) {
		ht(e);
		return;
	}
	e.round += 1, e.phase = "build", e.closing = !1, e.closingBy = null, e.warpath = null, e.herderBlock = [], e.docExtra = [];
	for (let t of e.players) {
		let n = e.pl[t];
		n.controlled = !1, n.bodyguard = !1, n.grace = null, n.build = {
			kept: [],
			rolled: [],
			done: !1,
			bruteFree: !1,
			preset: [],
			usedOutlaw: !1
		};
	}
	e.stepIdx = 0, e.res = Oe(), M(e, "log.round", { n: e.round }), e.roundStart = Ie(e), e.roundSheriff = e.sheriff, e.roundLogAt = e.logSeq;
}
function pt(e, t) {
	let n = e.pl[t], r = n.nuggets + n.herdBonus, i = n.captured.reduce((e, t) => e + w[t].reward, 0);
	r += Math.floor((n.money + i) / 2), e.sheriff === t && (r += 5);
	for (let e of n.gs) r += ce[e] ?? 0, e === "mule" && (r += n.gs.length), e === "dog" && (r += 2 * n.captured.length);
	for (let e of n.props) r += B(e);
	for (let e of n.protectedProps) r += B(e);
	for (let e of Object.keys(n.cowed).map(Number)) r += B(e) + 1;
	return r += n.ranches * (n.ranches + 1) / 2, e.cfg.cowboys && (r += n.rodeos * 10), r;
}
function mt(e, t) {
	let n = e.pl[t];
	return n.props.length + n.protectedProps.length + n.ranches + Object.keys(n.cowed).length;
}
function ht(e) {
	if (e.phase = "over", e.cfg.cowboys) {
		let t = Math.max(...e.players.map((t) => e.pl[t].herd));
		if (t > 0) {
			let n = e.players.filter((n) => e.pl[n].herd === t);
			for (let t of n) e.pl[t].herdBonus = n.length > 1 ? 5 : 10;
		}
	}
	let t = {};
	for (let n of e.players) t[n] = pt(e, n);
	let n = [...e.players].sort((n, r) => t[r] - t[n] || mt(e, r) - mt(e, n)), r = n.filter((r) => t[r] === t[n[0]] && mt(e, r) === mt(e, n[0]));
	if (r.length > 1) {
		e.pending = {
			k: "finalTie",
			candidates: r
		};
		return;
	}
	e.final = {
		winner: [n[0]],
		ranking: n,
		scores: t
	}, M(e, "log.win", { who: n[0] });
}
function gt(e, t, n, r) {
	let i = e.pl[n];
	if (e.pl[t].gs.includes("whiskey") && i.ranches > 0) {
		e.pending = {
			k: "offer",
			rid: t,
			card: "whiskey",
			data: { victim: n }
		};
		return;
	}
	_t(e, t, n, r);
}
function _t(e, t, n, r) {
	let i = e.pl[n], a = Math.max(0, r - De(i, "H")), o = [...i.gs.map((e) => ({
		t: "gs",
		card: e
	})), ...i.props.map((e) => ({
		t: "prop",
		id: e
	}))];
	if (a <= 0 || o.length === 0) {
		M(e, "log.stealFail", {
			who: t,
			from: n
		}), vt(e);
		return;
	}
	let s = P(e, [...o]).slice(0, Math.min(a, o.length));
	for (let r of s) N(e, `seat:${n}`, "showdown", r.t === "gs" ? "card" : "property", 1, r.t === "gs" ? `gs.${r.card}` : `prop.${B(r.id)}`, [t]);
	e.pending = {
		k: "saloonPick",
		rid: t,
		from: n,
		cards: s
	};
}
function vt(e, t) {
	let n = e.res.stealVictim;
	if (t && n && e.pl[n].gs.includes("insurance")) {
		e.pending = {
			k: "offer",
			rid: n,
			card: "insurance",
			data: { type: t }
		};
		return;
	}
	if (e.res.again && !e.res.againDone) {
		e.res.againDone = !0;
		let t = e.res.first ?? "";
		e.pending = {
			k: "saloonTarget",
			rid: t,
			qs: R(e.pl[t], S.saloon)
		};
		return;
	}
	q(e);
}
function yt(e, t, n) {
	let r = ge.safeParse(t);
	if (!r.success) return V("games.dicetown.errBadAction");
	let i = r.data;
	if (i.type === "tick") {
		if (e.phase !== "resolve" || e.pending && e.moment?.kind === "prompt") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return t.transfers = [], t.sceneRolls = [], Re(t), {
			state: t,
			fx: []
		};
	}
	let a = structuredClone(e);
	a.transfers = [], a.sceneRolls = [];
	let o = n.by, s = a.pl[o];
	if (!s) return V("games.dicetown.errBadAction");
	if (a.phase === "build") {
		let e = s.build;
		switch (i.type) {
			case "roll": return e.done ? V("games.dicetown.errBadAction") : e.rolled.length > 0 ? V("games.dicetown.errNeedKeep") : (Ae(a, o), {
				state: a,
				fx: []
			});
			case "keep": {
				if (e.done || e.rolled.length === 0) return V("games.dicetown.errBadAction");
				let t = [...new Set(i.idxs)];
				if (t.some((t) => t >= e.rolled.length)) return V("games.dicetown.errBadAction");
				let n = e.bruteFree ? 0 : t.length === 0 ? 1 : t.length - 1;
				if (s.money < n) return V("games.dicetown.errNoMoney");
				s.money -= n, a.stage += n, e.bruteFree = !1;
				let r = t.map((t) => e.rolled[t]);
				return e.rolled = [], e.kept = [...e.kept, ...r], e.kept.length >= 5 && (e.kept = e.kept.slice(0, 5), e.done = !0, Me(a, o)), {
					state: a,
					fx: []
				};
			}
			case "brute": return e.done || e.bruteFree || !s.gs.includes("brute") ? V("games.dicetown.errBadAction") : (Fe(a, o, "brute"), M(a, "log.play", {
				who: o,
				card: "gs.brute"
			}), e.bruteFree = !0, {
				state: a,
				fx: []
			});
			case "cheat": {
				if (!s.gs.includes("cheater")) return V("games.dicetown.errBadAction");
				let t = i.where === "kept" ? e.kept : e.rolled;
				return i.i >= t.length ? V("games.dicetown.errBadAction") : (Fe(a, o, "cheater"), M(a, "log.play", {
					who: o,
					card: "gs.cheater"
				}), t[i.i] = i.face, {
					state: a,
					fx: []
				});
			}
			case "outlaw": {
				if (e.done || e.rolled.length > 0 || i.i >= s.outlaws.length || e.preset.length + 2 > 5 - e.kept.length) return V("games.dicetown.errBadAction");
				let t = s.outlaws.splice(i.i, 1)[0];
				return a.outlawWanted.push(t), e.preset.push(w[t].pair, w[t].pair), e.usedOutlaw = !0, M(a, "log.useOutlaw", { who: o }), N(a, `seat:${o}`, "lot:sheriff", "outlaw", 1, `${w[t].reward}`), {
					state: a,
					fx: []
				};
			}
			default: return V("games.dicetown.errBadAction");
		}
	}
	let c = a.pending;
	if (!c || a.phase === "resolve" && a.moment?.kind !== "prompt") return V("games.dicetown.errBadAction");
	a.pending = null;
	let l = () => (a.pending = c, V("games.dicetown.errBadAction"));
	switch (c.k) {
		case "tie": return i.type !== "tie" || o !== a.sheriff || !c.candidates.includes(i.pick) ? l() : (M(a, "log.tie", {
			who: o,
			to: i.pick,
			loc: `loc.${c.loc}`
		}), c.role === "first" ? (a.res.first = i.pick, a.res.part = "act1") : (a.res.second = i.pick, a.res.part = "act2"), c.loc === "townhall" && (c.role === "first" ? a.res.thFirst = i.pick : a.res.thSecond = i.pick), {
			state: a,
			fx: []
		});
		case "finalTie": {
			if (i.type !== "tie" || o !== a.sheriff || !c.candidates.includes(i.pick)) return l();
			let e = {};
			for (let t of a.players) e[t] = pt(a, t);
			return a.final = {
				winner: [i.pick],
				ranking: [i.pick, ...a.players.filter((e) => e !== i.pick)],
				scores: e
			}, M(a, "log.win", { who: i.pick }), {
				state: a,
				fx: []
			};
		}
		case "locChoice": return i.type !== "locChoice" || o !== c.rid || !c.options.includes(i.option) ? l() : (a.res.firstChoice = i.option, M(a, "log.choice", {
			who: o,
			action: `ch.${c.loc}.${i.option}`
		}), c.loc === "townhall" ? et(a, o, i.option) : c.loc === "prairie" ? at(a, o, i.option) : Ge(a, c.loc, o, i.option), {
			state: a,
			fx: []
		});
		case "storePick":
			if (i.type !== "pick" || o !== c.rid || i.i >= c.drawn.length) return l();
			for (let [e, t] of c.drawn.entries()) e === i.i ? N(a, "showdown", `seat:${o}`, "card", 1, `gs.${t}`, [o]) : (a.gsDiscard.push(t), N(a, "showdown", "lot:store", "card", 1, `gs.${t}`));
			return U(a, o, c.drawn[i.i]), M(a, "log.storeKeep", {
				who: o,
				n: c.drawn.length - 1
			}), --a.res.execLeft, a.res.execLeft <= 0 && q(a), {
				state: a,
				fx: []
			};
		case "saloonTarget": {
			if (i.type !== "target" || o !== c.rid) return l();
			let e = i.rid;
			return e === o || !a.pl[e] || a.pl[e].bodyguard ? l() : (a.res.stealVictim = e, M(a, "log.target", {
				who: o,
				from: e
			}), gt(a, o, e, c.qs), {
				state: a,
				fx: []
			});
		}
		case "saloonPick": {
			if (i.type !== "pick" || o !== c.rid || i.i >= c.cards.length) return l();
			let e = c.cards[i.i];
			for (let [e, t] of c.cards.entries()) e !== i.i && N(a, "showdown", `seat:${c.from}`, t.t === "gs" ? "card" : "property", 1, t.t === "gs" ? `gs.${t.card}` : `prop.${B(t.id)}`, [o]);
			let t = a.pl[c.from];
			if (e.t === "gs") {
				let n = t.gs.indexOf(e.card);
				n >= 0 && t.gs.splice(n, 1), U(a, o, e.card), N(a, `seat:${c.from}`, `seat:${o}`, "card", 1, `gs.${e.card}`, [o, c.from]);
			} else {
				let n = t.props.indexOf(e.id);
				n >= 0 && t.props.splice(n, 1), W(a, o, e.id, !1, `seat:${c.from}`, [o, c.from]);
			}
			return M(a, "log.saloon", {
				who: o,
				from: c.from,
				n: c.cards.length
			}), vt(a, e.t), {
				state: a,
				fx: []
			};
		}
		case "docPick": {
			if (i.type !== "pick" || o !== c.rid) return l();
			let e;
			return i.i < a.elixUp.length ? e = a.elixUp.splice(i.i, 1)[0] : (a.elixDeck.length === 0 && a.elixDiscard.length > 0 && (a.elixDeck = P(a, a.elixDiscard.splice(0))), e = a.elixDeck.pop()), e ? (a.elixDiscard.push(e), lt(a, o, e), {
				state: a,
				fx: []
			}) : l();
		}
		case "elixirVictim": {
			if (i.type !== "target" || o !== c.rid || i.rid === o || !a.pl[i.rid]) return l();
			let e = a.pl[i.rid];
			return (c.elixir === "friendship" ? e.gs.length > 0 : e.props.length > 0) ? (a.pending = {
				k: "giveCard",
				from: i.rid,
				to: o,
				cardType: c.elixir === "friendship" ? "gs" : "prop"
			}, {
				state: a,
				fx: []
			}) : l();
		}
		case "giveCard": {
			if (i.type !== "pick" || o !== c.from) return l();
			let e = a.pl[c.from];
			if (c.cardType === "gs") {
				if (i.i >= e.gs.length) return l();
				let t = e.gs.splice(i.i, 1)[0];
				U(a, c.to, t), N(a, `seat:${c.from}`, `seat:${c.to}`, "card", 1, `gs.${t}`, [c.from, c.to]);
			} else {
				if (i.i >= e.props.length) return l();
				W(a, c.to, e.props.splice(i.i, 1)[0], !1, `seat:${c.from}`, [c.from, c.to]);
			}
			return M(a, "log.give", {
				from: c.from,
				to: c.to
			}), a.res.docChain && ct(a), {
				state: a,
				fx: []
			};
		}
		case "protectPick": {
			if (i.type !== "pickMulti" || o !== c.rid) return l();
			let e = [...new Set(i.is)].slice(0, 2);
			if (e.length === 0 || e.some((e) => e >= s.props.length)) return l();
			let t = e.map((e) => s.props[e]);
			s.props = s.props.filter((t, n) => !e.includes(n)), s.protectedProps.push(...t);
			for (let e of t) N(a, `seat:${o}`, "showdown", "property", 1, `prop.${B(e)}`);
			return M(a, "log.protect", { who: o }), a.res.docChain && ct(a), {
				state: a,
				fx: []
			};
		}
		case "joeTarget": {
			if (i.type !== "target" || o !== c.rid || i.rid === o || !a.pl[i.rid]) return l();
			let e = Math.min(4, a.pl[i.rid].money);
			return a.pl[i.rid].money -= e, s.money += e, N(a, `seat:${i.rid}`, `seat:${o}`, "money", e), M(a, "log.joe", {
				who: o,
				from: i.rid,
				n: e
			}), {
				state: a,
				fx: []
			};
		}
		case "offer":
			if (i.type !== "offer" || o !== c.rid) return l();
			if (i.accept && c.card !== "wanted") {
				let e = a.players.find((e) => e !== c.rid && a.pl[e].gs.includes("wanted"));
				if (e) return a.pending = {
					k: "offer",
					rid: e,
					card: "wanted",
					then: c
				}, {
					state: a,
					fx: []
				};
			}
			return bt(a, c, i.accept), {
				state: a,
				fx: []
			};
		case "smokeSignals": return i.type !== "offer" || o !== c.rid ? l() : (i.accept && (Fe(a, o, "smokesignals"), N(a, a.indian.holder ? `seat:${a.indian.holder}` : "village", `seat:${o}`, "indian"), a.indian = {
			holder: o,
			armed: !0
		}, M(a, "log.play", {
			who: o,
			card: "gs.smokesignals"
		})), {
			state: a,
			fx: []
		});
		case "indianOffer": return i.type !== "offer" || o !== c.rid ? l() : (i.accept && (a.pending = {
			k: "indianGive",
			rid: o
		}), {
			state: a,
			fx: []
		});
		case "indianGive": {
			if (i.type !== "pick" || o !== c.rid) return l();
			let e = a.res.gained[o] ?? [];
			if (i.i >= e.length) return l();
			let t = e.splice(i.i, 1)[0];
			return t >= T.length ? --s.ranches : s.props.splice(s.props.indexOf(t), 1), N(a, `seat:${o}`, "village", "property", 1, `prop.${B(t)}`, [o]), N(a, a.indian.holder ? `seat:${a.indian.holder}` : "village", `seat:${o}`, "indian"), a.indian = {
				holder: o,
				armed: !0
			}, M(a, "log.indianGive", { who: o }), {
				state: a,
				fx: []
			};
		}
		case "indianFx":
			if (i.type !== "indianChoice" || o !== c.rid) return l();
			if (c.face === "blessing") {
				if (i.i === void 0 || i.face === void 0 || i.i >= s.build.kept.length) return l();
				s.build.kept[i.i] = i.face, a.sceneRolls.push({
					rid: o,
					faces: [i.face]
				}), M(a, "log.blessing", { who: o });
			} else if (c.face === "ambush") {
				if (!i.target || !a.pl[i.target] || i.i === void 0 || i.i >= a.pl[i.target].build.kept.length) return l();
				a.pl[i.target].build.kept[i.i] = F(a), a.sceneRolls.push({
					rid: i.target,
					faces: [a.pl[i.target].build.kept[i.i]]
				}), M(a, "log.ambush", {
					who: o,
					from: i.target
				});
			} else if (c.face === "warpath") {
				if (!i.loc || !a.steps.includes(i.loc)) return l();
				a.warpath = i.loc, M(a, "log.warpathSet", {
					who: o,
					loc: `loc.${i.loc}`
				});
			}
			return {
				state: a,
				fx: []
			};
		case "recruitPick": {
			if (i.type !== "pickMulti" || o !== c.rid) return l();
			let e = [...new Set(i.is)].slice(0, c.n);
			if (e.length === 0 || e.some((e) => e >= a.cowboyUp.length)) return l();
			let t = e.map((e) => a.cowboyUp[e]);
			a.cowboyUp = a.cowboyUp.filter((t, n) => !e.includes(n)), s.cowboys.push(...t);
			for (let e of t) N(a, "lot:prairie", `seat:${o}`, "cowboy", 1, z[e]);
			for (; a.cowboyUp.length < 2 && a.cowboyDeck.length > 0;) a.cowboyUp.push(a.cowboyDeck.pop());
			M(a, "log.recruitCowboy", {
				who: o,
				suit: t.map((e) => z[e]).join("")
			});
			let n = [
				"S",
				"H",
				"D",
				"C"
			];
			if (a.rodeos > 0 && n.every((e) => s.cowboys.includes(e))) {
				for (let e of n) s.cowboys.splice(s.cowboys.indexOf(e), 1), N(a, `seat:${o}`, "lot:prairie", "cowboy", 1, z[e]);
				--a.rodeos, s.rodeos += 1, N(a, "lot:prairie", `seat:${o}`, "rodeo"), M(a, "log.rodeo", { who: o });
			}
			return q(a), {
				state: a,
				fx: []
			};
		}
		case "cowPlace":
			if (i.type !== "cowPlace" || o !== c.rid || i.place.reduce((e, t) => e + t.n, 0) > s.herd) return l();
			for (let { id: e, n: t } of i.place) if (!s.props.includes(e) || t !== B(e)) return l();
			for (let { id: e, n: t } of i.place) s.props.splice(s.props.indexOf(e), 1), s.cowed[e] = t, s.herd -= t, N(a, `seat:${o}`, "showdown", "cattle", t);
			return i.place.length > 0 && M(a, "log.cowPlace", {
				who: o,
				n: i.place.length
			}), q(a), {
				state: a,
				fx: []
			};
		case "discovery": {
			if (i.type !== "pick" || o !== c.rid || i.i >= c.drawn.length) return l();
			let e = c.drawn[i.i], t = c.drawn.filter((e, t) => t !== i.i);
			if (t.length === 2) return a.pending = {
				k: "discoveryOrder",
				rid: o,
				a: t[0],
				b: t[1],
				chosen: e
			}, {
				state: a,
				fx: []
			};
			t.length === 1 && a.riverDeck.push(t[0]);
			for (let e of t) N(a, "showdown", "lot:mine", "river", 1, `river.${e}`, [o]);
			return dt(a, o, e, "showdown"), a.pending || q(a), {
				state: a,
				fx: []
			};
		}
		case "discoveryOrder": {
			if (i.type !== "pick" || o !== c.rid || i.i > 1) return l();
			let e = i.i === 0 ? c.a : c.b, t = i.i === 0 ? c.b : c.a;
			a.riverDeck.push(t, e);
			for (let n of [t, e]) N(a, "showdown", "lot:mine", "river", 1, `river.${n}`, [o]);
			return dt(a, o, c.chosen, "showdown"), a.pending || q(a), {
				state: a,
				fx: []
			};
		}
		case "persuasion": return i.type !== "pick" || o !== c.rid || i.i >= c.drawn.length ? l() : (W(a, o, c.drawn[i.i], !0, "showdown"), M(a, "log.persuasion", { who: o }), q(a), {
			state: a,
			fx: []
		});
		case "desperadoPick": {
			if (i.type !== "pick" || o !== c.rid || i.i >= a.outlawDeck.length) return l();
			let e = a.outlawDeck.splice(i.i, 1)[0];
			return s.outlaws.push(e), N(a, "lot:saloon", `seat:${o}`, "outlaw", 1, `${w[e].reward}`), a.outlawDeck = P(a, a.outlawDeck), M(a, "log.recruitOutlaw", { who: o }), q(a), {
				state: a,
				fx: []
			};
		}
		case "coupon":
			if (i.type !== "pick" || o !== c.rid || i.i >= a.gsDiscard.length) return l();
			{
				let e = a.gsDiscard.splice(i.i, 1)[0];
				N(a, "lot:store", `seat:${o}`, "card", 1, `gs.${e}`), U(a, o, e);
			}
			return q(a), {
				state: a,
				fx: []
			};
		default: return l();
	}
}
function bt(e, t, n) {
	if (t.card === "wanted") {
		let r = t.then;
		if (!r) return;
		n ? (Fe(e, t.rid, "wanted"), Fe(e, r.rid, r.card), M(e, "log.play", {
			who: r.rid,
			card: `gs.${r.card}`
		}), M(e, "log.wanted", {
			who: t.rid,
			card: `gs.${r.card}`
		}), bt(e, r, !1)) : bt(e, r, !0);
		return;
	}
	n && (Fe(e, t.rid, t.card), M(e, "log.play", {
		who: t.rid,
		card: `gs.${t.card}`
	}));
	let r = t.data ?? {};
	switch (t.card) {
		case "dynamite":
			n && (e.res.doubleMine = !0), Ke(e, t.rid, R(e.pl[t.rid], S.mine)), q(e);
			break;
		case "credits":
			e.res.execLeft = (e.round === 1 ? 2 : 1) + +!!n, Je(e, t.rid);
			break;
		case "girls":
			n && (e.res.again = !0), e.pending = {
				k: "saloonTarget",
				rid: t.rid,
				qs: R(e.pl[t.rid], S.saloon)
			};
			break;
		case "whiskey":
			if (n) {
				let n = String(r.victim);
				--e.pl[n].ranches, e.pl[t.rid].ranches += 1, N(e, `seat:${n}`, `seat:${t.rid}`, "property", 1, "ranch"), M(e, "log.saloon", {
					who: t.rid,
					from: n,
					n: 1
				}), vt(e);
			} else _t(e, t.rid, String(r.victim), R(e.pl[t.rid], S.saloon));
			break;
		case "evensplit": {
			let i = String(r.robber);
			if (n) {
				let n = Math.min(Math.floor(Number(r.take) / 2), e.pl[i].money);
				e.pl[i].money -= n, e.pl[t.rid].money += n, N(e, `seat:${i}`, `seat:${t.rid}`, "money", n), M(e, "log.evensplit", {
					who: t.rid,
					n
				});
			}
			qe(e, i), q(e);
			break;
		}
		case "marshall":
			n && (N(e, `seat:${e.sheriff}`, `seat:${String(r.old)}`, "badge"), e.sheriff = String(r.old), M(e, "log.sheriff", {
				who: String(r.old),
				why: "marshall"
			}));
			break;
		case "herder": {
			let i = String(r.stealer);
			if (n) e.herderBlock.push(t.rid), M(e, "log.herder", { who: t.rid });
			else {
				let n = Math.min(Number(r.left), e.pl[t.rid].herd);
				e.pl[t.rid].herd -= n, e.pl[i].herd += n, N(e, `seat:${t.rid}`, `seat:${i}`, "cattle", n);
			}
			ot(e, i, 0);
			break;
		}
		case "lasso":
			n && (e.res.lassoOn = !0), ot(e, t.rid, Number(r.aces));
			break;
		case "recruitment":
			e.pending = {
				k: "recruitPick",
				rid: t.rid,
				n: Math.min(n ? 2 : 1, e.cowboyUp.length)
			};
			break;
		case "corruption":
			if (n) {
				let n = e.propDeck.pop();
				n !== void 0 && W(e, t.rid, n, !0), M(e, "log.corruption", { who: t.rid });
			}
			if (e.pl[t.rid].gs.includes("persuasion") && R(e.pl[t.rid], 5) > 0 && e.propDeck.length > 0) {
				e.pending = {
					k: "offer",
					rid: t.rid,
					card: "persuasion"
				};
				return;
			}
			q(e);
			break;
		case "persuasion":
			if (n) {
				let n = R(e.pl[t.rid], 5), r = [];
				for (let t = 0; t < n && e.propDeck.length > 0; t += 1) r.push(e.propDeck.pop());
				if (r.length > 1) for (let n of r) N(e, "lot:townhall", "showdown", "property", 1, `prop.${B(n)}`, [t.rid]);
				if (r.length > 1) {
					e.pending = {
						k: "persuasion",
						rid: t.rid,
						drawn: r
					};
					return;
				}
				r.length === 1 && W(e, t.rid, r[0], !0);
			}
			q(e);
			break;
		case "desperado":
			if (n) {
				e.pending = {
					k: "desperadoPick",
					rid: t.rid
				};
				return;
			}
			{
				let n = e.outlawDeck.pop();
				n !== void 0 && (e.pl[t.rid].outlaws.push(n), N(e, "lot:saloon", `seat:${t.rid}`, "outlaw", 1, `${w[n].reward}`), M(e, "log.recruitOutlaw", { who: t.rid }));
			}
			q(e);
			break;
		case "twoguns":
			if (n) {
				let n = R(e.pl[t.rid], S.sheriff), r = [];
				for (let t = 0; t < n; t += 1) r.push(F(e));
				e.sceneRolls.push({
					rid: t.rid,
					faces: r
				});
				let i = Ze(e, t.rid, r);
				M(e, "log.chase", {
					who: t.rid,
					n: n - i.length
				});
			}
			q(e);
			break;
		case "elixir":
			n && (e.pl[t.rid].controlled = !0, e.res.docQueue.unshift(t.rid), M(e, "log.docPlan", { who: t.rid }));
			break;
		case "insurance":
			if (n) {
				if (r.type === "prop") {
					let n = e.propDeck.pop();
					n !== void 0 && W(e, t.rid, n, !1);
				} else Pe(e, t.rid);
				M(e, "log.insurance", { who: t.rid });
			}
			vt(e);
	}
}
function xt(e, t, n) {
	let r = e.pl[t];
	switch (n) {
		case "joe":
			e.pending = {
				k: "joeTarget",
				rid: t
			};
			return;
		case "swindler":
			for (let n of e.players) {
				if (n === t) continue;
				let i = Math.min(2, e.pl[n].money);
				e.pl[n].money -= i, r.money += i, N(e, `seat:${n}`, `seat:${t}`, "money", i);
			}
			M(e, "log.swindler", { who: t });
			return;
		case "gift":
			e.players.filter((n) => n !== t && e.pl[n].gs.length > 0).length > 0 && (e.pending = {
				k: "elixirVictim",
				rid: t,
				elixir: "friendship"
			});
			return;
		default: return;
	}
}
function St(e) {
	return {
		i: e,
		pair: w[e].pair,
		reward: w[e].reward
	};
}
function Ct(e) {
	if (!e) return null;
	switch (e.k) {
		case "tie": return {
			k: "tie",
			loc: e.loc,
			role: e.role,
			candidates: e.candidates
		};
		case "locChoice": return {
			k: "locChoice",
			loc: e.loc,
			rid: e.rid,
			options: e.options
		};
		case "storePick": return {
			k: "storePick",
			rid: e.rid,
			n: e.drawn.length
		};
		case "saloonTarget": return {
			k: "saloonTarget",
			rid: e.rid,
			qs: e.qs,
			again: !1
		};
		case "saloonPick": return {
			k: "saloonPick",
			rid: e.rid,
			from: e.from,
			n: e.cards.length
		};
		case "docPick": return {
			k: "docPick",
			rid: e.rid
		};
		case "elixirVictim": return {
			k: "elixirVictim",
			rid: e.rid,
			elixir: e.elixir
		};
		case "giveCard": return {
			k: "giveCard",
			from: e.from,
			to: e.to,
			cardType: e.cardType
		};
		case "protectPick": return {
			k: "protectPick",
			rid: e.rid
		};
		case "joeTarget": return {
			k: "joeTarget",
			rid: e.rid
		};
		case "offer": return {
			k: "offer",
			rid: e.rid,
			card: e.card
		};
		case "recruitPick": return {
			k: "recruitPick",
			rid: e.rid,
			n: e.n
		};
		case "cowPlace": return {
			k: "cowPlace",
			rid: e.rid
		};
		case "indianOffer": return {
			k: "indianOffer",
			rid: e.rid
		};
		case "indianGive": return {
			k: "indianGive",
			rid: e.rid
		};
		case "coupon": return {
			k: "coupon",
			rid: e.rid
		};
		case "indianFx": return {
			k: "indianFx",
			rid: e.rid,
			face: e.face
		};
		case "discovery": return {
			k: "discovery",
			rid: e.rid
		};
		case "discoveryOrder": return {
			k: "discoveryOrder",
			rid: e.rid,
			a: e.a,
			b: e.b
		};
		case "persuasion": return {
			k: "persuasion",
			rid: e.rid,
			n: e.drawn.length
		};
		case "smokeSignals": return {
			k: "smokeSignals",
			rid: e.rid
		};
		case "finalTie": return {
			k: "finalTie",
			candidates: e.candidates
		};
		case "desperadoPick": return {
			k: "desperadoPick",
			rid: e.rid
		};
		case "applyCard": return null;
	}
}
function wt(e, t) {
	let n = e, r = n.pl[t], i = n.phase !== "build", a = {
		cfg: n.cfg,
		round: n.round,
		phase: n.phase,
		closing: n.closing,
		closingBy: n.closingBy,
		moment: n.moment,
		lastRound: n.lastRound,
		sheriff: n.sheriff,
		bank: n.bank,
		stage: n.stage,
		mine: n.mine,
		prairie: n.prairie,
		propUp: n.propUp.map((e) => ({
			id: e,
			value: B(e),
			ranch: e >= T.length
		})),
		propDeck: n.propDeck.length,
		gsDeck: n.gsDeck.length,
		gsDiscard: n.gsDiscard,
		elixUp: n.elixUp,
		riverDeck: n.riverDeck.length,
		outlawWanted: n.outlawWanted.map(St),
		outlawDeck: n.outlawDeck.length,
		cowboyUp: n.cowboyUp,
		rodeos: n.rodeos,
		indian: n.indian,
		step: n.phase === "resolve" ? n.moment ? n.moment.loc : n.stepIdx < n.steps.length ? n.steps[n.stepIdx] : "" : "",
		pending: n.phase === "over" || n.moment?.kind === "prompt" ? Ct(n.pending) : null,
		hands: i ? Object.fromEntries(n.players.map((e) => [e, n.pl[e].build.kept])) : null,
		players: n.players.map((e) => {
			let t = n.pl[e];
			return {
				rid: e,
				money: t.money,
				nuggets: t.nuggets,
				gs: t.gs.length,
				props: t.props.length,
				protectedProps: t.protectedProps.map(B),
				ranches: t.ranches,
				herd: t.herd,
				cowed: Object.entries(t.cowed).map(([e, t]) => ({
					id: Number(e),
					value: B(Number(e)),
					n: t
				})),
				cowboys: t.cowboys,
				rodeos: t.rodeos,
				outlaws: t.outlaws.map(St),
				captured: t.captured.map(St),
				controlled: t.controlled,
				done: t.build.done,
				kept: t.build.kept.length,
				rolled: t.build.rolled.length,
				bodyguard: t.bodyguard
			};
		}),
		firstRound: n.round === 1,
		log: n.log.slice(-40)
	}, o = n.phase === "over" || n.moment?.kind === "prompt" ? n.pending : null;
	return {
		public: a,
		private: {
			gs: r.gs,
			props: r.props.map((e) => ({
				id: e,
				value: B(e)
			})),
			dice: n.phase === "build" ? [...r.build.kept] : null,
			rolled: n.phase === "build" ? [...r.build.rolled] : [],
			bruteFree: r.build.bruteFree,
			canOutlaw: n.phase === "build" && !r.build.done && r.build.rolled.length === 0 && r.outlaws.length > 0 && r.build.preset.length + 2 <= 5 - r.build.kept.length,
			pendingPriv: o?.k === "storePick" && o.rid === t ? {
				k: "storePick",
				drawn: o.drawn
			} : o?.k === "saloonPick" && o.rid === t ? {
				k: "saloonPick",
				cards: o.cards.map((e) => ({
					t: e.t,
					label: e.t === "gs" ? `gs.${e.card}` : `prop.${B(e.id)}`
				})),
				give: []
			} : o?.k === "discovery" && o.rid === t ? {
				k: "discovery",
				drawn: o.drawn
			} : o?.k === "persuasion" && o.rid === t ? {
				k: "persuasion",
				drawn: o.drawn.map(B)
			} : o?.k === "desperadoPick" && o.rid === t ? {
				k: "desperadoPick",
				pile: n.outlawDeck.map(St)
			} : o?.k === "indianGive" && o.rid === t ? {
				k: "indianGive",
				props: (n.res.gained[t] ?? []).map((e) => ({
					id: e,
					value: B(e)
				}))
			} : null
		}
	};
}
function Tt(e, t, n) {
	let r = yt(e, t, n);
	if ("code" in r || r.state === e) return r;
	let i = r.state, a = [];
	if (e.phase === "build") {
		let r = e.pl[n.by]?.build, o = i.pl[n.by]?.build;
		if (r && o && t.type === "roll") {
			let e = o.done ? o.kept.slice(r.kept.length) : o.rolled;
			a.push({
				kind: "roll",
				rid: n.by,
				data: {
					count: e.length,
					kept: r.kept.length,
					revealed: i.phase !== "build"
				},
				for: [n.by],
				secret: { faces: e }
			});
		} else if (r && t.type === "keep") {
			let o = [...new Set(t.idxs)];
			a.push({
				kind: "keep",
				rid: n.by,
				data: {
					count: o.length,
					kept: r.kept.length,
					cost: e.pl[n.by].money - i.pl[n.by].money,
					revealed: i.phase !== "build"
				},
				for: [n.by],
				secret: {
					faces: o.map((e) => r.rolled[e]),
					idxs: o
				}
			});
		}
	} else if (t.type !== "tick" && i.phase === "resolve") {
		let r = e.moment?.loc || G(e), a = i.logSeq > e.logSeq ? i.log.slice(-(i.logSeq - e.logSeq)) : [], o = Le(Ie(e), i);
		t.type === "tie" ? K(i, "winner", r, t.pick, e.pending?.k === "tie" ? e.pending.role : null, a) : (!a.length && !i.transfers.length && a.push({
			k: t.type === "offer" && !t.accept ? "log.decline" : "log.confirm",
			p: { who: n.by }
		}), K(i, "result", r, n.by, null, a, o));
	}
	if (i.moment?.id !== e.moment?.id && i.moment) {
		let e = i.moment;
		e.kind !== "prompt" && a.push({
			kind: "moment",
			rid: e.rid ?? void 0,
			data: e,
			with: a.length > 0
		});
	}
	for (let [e, t] of i.transfers.entries()) {
		let { from: n, to: r, asset: o, n: s, label: c, card: l, known: u } = t, d = i.transfers.filter((e) => e.from === n && e.to === r), f = i.transfers.slice(0, e).filter((e) => e.from === n && e.to === r).length;
		a.push({
			kind: "transfer",
			data: {
				from: n,
				to: r,
				asset: o,
				n: s,
				slot: f,
				slots: d.length,
				...c ? { label: c } : {}
			},
			with: a.length > 0,
			...u && l ? {
				for: u,
				secret: { card: l }
			} : {}
		});
	}
	return {
		state: i,
		fx: a
	};
}
function Et(e) {
	return e.phase === "over" && e.final ? {
		phase: "over",
		winner: e.final.winner,
		ranking: e.final.ranking,
		scores: e.final.scores
	} : { phase: e.phase };
}
function Dt(e) {
	return e.phase !== "resolve" || e.pending && e.moment?.kind === "prompt" ? null : e.beatMs || j.result;
}
var Ot = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: he,
	schemas: {
		action: ge,
		publicView: Se,
		privateView: we,
		config: Te
	},
	setup: ke,
	reduce: Tt,
	viewFor: wt,
	status: Et,
	nextTickIn: Dt
}, kt = {
	9: "M7 4H27V9H24V28H19V33H7V27H17V21H7V4ZM13 10V16H18V10Z",
	1: "M5 7L12 4H17V27H22V33H5V27H10V12H5Z",
	0: "M7 4H24L29 9V28L24 33H7L2 28V9ZM10 11V26H21V11Z",
	J: "M8 4H30V10H26V26L21 33H7L2 28V21H10V26H18V10H8Z",
	Q: "M7 4H25L30 9V27L25 32H23L29 36H18L14 32H7L2 27V9ZM10 11V25H22V11Z",
	K: "M1 4H16V10H12V16L22 9H19V4H33V10H30L20 19L30 27H33V33H18V27H21L12 21V27H16V33H1V27H5V10H1Z",
	A: "M12 4H24L33 27H36V33H20V27H24L22 23H12L10 27H14V33H0V27H3ZM15 17H20L17 10Z"
};
function At({ face: e }) {
	let t = x[e];
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 40 40",
		"aria-hidden": !0,
		className: "dt-face",
		children: t === "10" ? /* @__PURE__ */ g("g", {
			transform: "translate(1 2) scale(.64 .94)",
			children: [/* @__PURE__ */ h("path", { d: kt[1] }), /* @__PURE__ */ h("path", {
				d: kt[0],
				transform: "translate(27 0)"
			})]
		}) : /* @__PURE__ */ h("path", {
			d: kt[t],
			transform: "translate(2 1)"
		})
	});
}
function J({ face: e, selected: t = !1, locked: n = !1, small: r = !1, onClick: i, empty: a = !1, tilt: s = 0, anchorName: c, width: l, height: u }) {
	let d = o(), { ref: f, hidden: ee } = ie(c ?? null), te = e == null ? "" : x[e], ne = d(a ? "games.dicetown.ui.emptyDie" : n ? "games.dicetown.ui.lockedDie" : "games.dicetown.ui.selectDie", { face: te }), re = /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ g("svg", {
			className: "dt-die-body",
			viewBox: "-4 -8 78 82",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ h("path", {
					d: "M10 13L75 19L82 77L16 78Z",
					fill: "#10110f",
					opacity: ".8"
				}),
				/* @__PURE__ */ h("path", {
					d: "M6 60H57L68 69L14 70Z",
					fill: "#817153",
					stroke: "#27251e",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("path", {
					d: "M62 6L70 13V65L62 69L57 60Z",
					fill: "#a09272",
					stroke: "#302b22",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("path", {
					d: "M6 2H56L62 8V56L56 62H6L1 57V7Z",
					fill: a ? "#47463a" : "#dfd1ac",
					stroke: "#29251e",
					strokeWidth: "2.5"
				}),
				!a && /* @__PURE__ */ g(m, { children: [
					/* @__PURE__ */ h("path", {
						d: "M7 5H54L59 10V54L54 59H7L4 55V9Z",
						fill: "#f3e6c3"
					}),
					/* @__PURE__ */ h("path", {
						d: "M7 5H54L59 10V19L5 14Z",
						fill: "#fff0c8"
					}),
					/* @__PURE__ */ h("path", {
						d: "M8 5L11 10M59 47L54 50M7 59L14 56",
						stroke: "#a58d62"
					}),
					/* @__PURE__ */ h("path", {
						d: "M11 6H51",
						stroke: "#fff8db",
						strokeWidth: "2"
					})
				] }),
				t && /* @__PURE__ */ h("path", {
					d: "M-4 16V-3H12M52 75H76V53",
					fill: "none",
					stroke: "#4faec0",
					strokeWidth: "2.5"
				}),
				n && /* @__PURE__ */ g("g", {
					stroke: "#34392e",
					fill: "#bbc3aa",
					children: [/* @__PURE__ */ h("path", {
						d: "M54 64V61a4 4 0 0 1 8 0v3",
						fill: "none",
						stroke: "#bbc3aa",
						strokeWidth: "2"
					}), /* @__PURE__ */ h("rect", {
						x: "52",
						y: "63",
						width: "12",
						height: "9",
						rx: "1"
					})]
				})
			]
		}),
		!a && e != null && /* @__PURE__ */ h("span", {
			className: `dt-die-glyph ${e === 3 ? "dt-queen" : ""}`,
			children: /* @__PURE__ */ h(At, { face: e })
		}),
		t && /* @__PURE__ */ h("span", {
			className: "dt-die-check",
			children: /* @__PURE__ */ h(p, {
				size: 13,
				"aria-hidden": !0
			})
		})
	] }), ae = `dt-die ${r ? "dt-die-small" : ""} ${t ? "dt-die-selected" : ""} ${a ? "dt-die-empty" : ""}`, oe = {
		width: l,
		height: u,
		transform: `rotate(${s}deg)`,
		visibility: ee ? "hidden" : void 0
	};
	return i ? /* @__PURE__ */ h("button", {
		ref: f,
		type: "button",
		className: ae,
		style: oe,
		onClick: i,
		"aria-label": ne,
		"aria-pressed": t,
		children: re
	}) : /* @__PURE__ */ h("span", {
		ref: f,
		className: ae,
		style: oe,
		role: "img",
		"aria-label": ne,
		children: re
	});
}
//#endregion
//#region src/games/dicetown/labels.ts
var Y = {
	"loc.mine": "games.dicetown.loc.mine",
	"loc.bank": "games.dicetown.loc.bank",
	"loc.store": "games.dicetown.loc.store",
	"loc.saloon": "games.dicetown.loc.saloon",
	"loc.sheriff": "games.dicetown.loc.sheriff",
	"loc.townhall": "games.dicetown.loc.townhall",
	"loc.prairie": "games.dicetown.loc.prairie",
	"loc.doc": "games.dicetown.loc.doc",
	"loc.indianOffer": "games.dicetown.loc.indianOffer",
	"loc.roundEnd": "games.dicetown.loc.roundEnd",
	"gs.horse": "games.dicetown.gs.horse",
	"gs.wagon": "games.dicetown.gs.wagon",
	"gs.holster": "games.dicetown.gs.holster",
	"gs.hat": "games.dicetown.gs.hat",
	"gs.slingshot": "games.dicetown.gs.slingshot",
	"gs.boots": "games.dicetown.gs.boots",
	"gs.dynamite": "games.dicetown.gs.dynamite",
	"gs.girls": "games.dicetown.gs.girls",
	"gs.brute": "games.dicetown.gs.brute",
	"gs.cheater": "games.dicetown.gs.cheater",
	"gs.credits": "games.dicetown.gs.credits",
	"gs.joe": "games.dicetown.gs.joe",
	"gs.marshall": "games.dicetown.gs.marshall",
	"gs.evensplit": "games.dicetown.gs.evensplit",
	"gs.wanted": "games.dicetown.gs.wanted",
	"gs.corruption": "games.dicetown.gs.corruption",
	"gs.elixir": "games.dicetown.gs.elixir",
	"gs.cattle": "games.dicetown.gs.cattle",
	"gs.winchester": "games.dicetown.gs.winchester",
	"gs.mule": "games.dicetown.gs.mule",
	"gs.dog": "games.dicetown.gs.dog",
	"gs.insurance": "games.dicetown.gs.insurance",
	"gs.desperado": "games.dicetown.gs.desperado",
	"gs.gift": "games.dicetown.gs.gift",
	"gs.twoguns": "games.dicetown.gs.twoguns",
	"gs.whiskey": "games.dicetown.gs.whiskey",
	"gs.swindler": "games.dicetown.gs.swindler",
	"gs.smokesignals": "games.dicetown.gs.smokesignals",
	"gs.lasso": "games.dicetown.gs.lasso",
	"gs.herder": "games.dicetown.gs.herder",
	"gs.recruitment": "games.dicetown.gs.recruitment",
	"gs.persuasion": "games.dicetown.gs.persuasion",
	"gs.bribe": "games.dicetown.gs.bribe",
	"elix.wealth": "games.dicetown.elix.wealth",
	"elix.charm": "games.dicetown.elix.charm",
	"elix.fortune": "games.dicetown.elix.fortune",
	"elix.power": "games.dicetown.elix.power",
	"elix.protection": "games.dicetown.elix.protection",
	"elix.friendship": "games.dicetown.elix.friendship",
	"elix.domination": "games.dicetown.elix.domination",
	"river.gold2": "games.dicetown.river.gold2",
	"river.gold3": "games.dicetown.river.gold3",
	"river.gold4": "games.dicetown.river.gold4",
	"river.gold5": "games.dicetown.river.gold5",
	"river.money2": "games.dicetown.river.money2",
	"river.money3": "games.dicetown.river.money3",
	"river.star": "games.dicetown.river.star",
	"river.coupon": "games.dicetown.river.coupon",
	"river.discovery": "games.dicetown.river.discovery",
	"river.nothing": "games.dicetown.river.nothing",
	"indian.blessing": "games.dicetown.indian.blessing",
	"indian.ambush": "games.dicetown.indian.ambush",
	"indian.bodyguard": "games.dicetown.indian.bodyguard",
	"indian.warpath": "games.dicetown.indian.warpath",
	"ch.mine.exploit": "games.dicetown.ch.mine.exploit",
	"ch.mine.river": "games.dicetown.ch.mine.river",
	"ch.bank.rob": "games.dicetown.ch.bank.rob",
	"ch.bank.stage": "games.dicetown.ch.bank.stage",
	"ch.store.draw": "games.dicetown.ch.store.draw",
	"ch.store.doc": "games.dicetown.ch.store.doc",
	"ch.saloon.steal": "games.dicetown.ch.saloon.steal",
	"ch.saloon.recruitOutlaw": "games.dicetown.ch.saloon.recruitOutlaw",
	"ch.sheriff.badge": "games.dicetown.ch.sheriff.badge",
	"ch.sheriff.chase": "games.dicetown.ch.sheriff.chase",
	"ch.townhall.normal": "games.dicetown.ch.townhall.normal",
	"ch.townhall.mayor": "games.dicetown.ch.townhall.mayor",
	"ch.townhall.bribe": "games.dicetown.ch.townhall.bribe",
	"ch.prairie.steal": "games.dicetown.ch.prairie.steal",
	"ch.prairie.recruit": "games.dicetown.ch.prairie.recruit"
};
//#endregion
//#region src/games/dicetown/round-summary.tsx
function jt({ gain: e }) {
	let t = o(), n = (e) => `${e > 0 ? "+" : ""}${e}`;
	return e ? /* @__PURE__ */ g("span", {
		className: "dt-gain-line",
		children: [
			!!e.money && /* @__PURE__ */ g("b", {
				className: e.money < 0 ? "dt-gain-loss" : "",
				children: [n(e.money), "$"]
			}),
			!!e.nuggets && /* @__PURE__ */ g("b", {
				className: e.nuggets < 0 ? "dt-gain-loss" : "",
				children: [n(e.nuggets), "◆"]
			}),
			!!e.cards && /* @__PURE__ */ g("span", { children: [n(e.cards), t("games.dicetown.ui.cardsShort")] }),
			!!e.properties && /* @__PURE__ */ g("span", { children: [n(e.properties), t("games.dicetown.ui.propsShort")] }),
			!!e.herd && /* @__PURE__ */ g("span", { children: [n(e.herd), t("games.dicetown.ui.cattleShort")] }),
			!!e.outlaws && /* @__PURE__ */ g("span", { children: [n(e.outlaws), "✦"] }),
			!!e.cowboys && /* @__PURE__ */ g("span", { children: [n(e.cowboys), "♠"] }),
			!!e.rodeos && /* @__PURE__ */ g("span", { children: [n(e.rodeos), " Rodeo"] })
		]
	}) : /* @__PURE__ */ h("span", {
		className: "dt-gain-zero",
		children: "—"
	});
}
function Mt({ summary: e, players: t, nameOf: n, line: r, compact: i = !1 }) {
	let a = o(), s = e.sheriffBefore !== e.sheriffAfter;
	return /* @__PURE__ */ g("div", {
		className: i ? "dt-round-compact" : "dt-round-detail",
		children: [
			!i && /* @__PURE__ */ h("p", { children: a("games.dicetown.ui.netChange") }),
			/* @__PURE__ */ h("div", {
				className: "dt-round-players",
				children: t.map((t) => /* @__PURE__ */ g("div", {
					className: "dt-round-player",
					children: [/* @__PURE__ */ g("strong", {
						title: n(t.rid),
						children: [n(t.rid), s && e.sheriffAfter === t.rid && " ★"]
					}), /* @__PURE__ */ h(jt, { gain: e.gains.find((e) => e.rid === t.rid) })]
				}, t.rid))
			}),
			!i && /* @__PURE__ */ g(m, { children: [s && /* @__PURE__ */ g("p", {
				className: "dt-round-sheriff",
				children: ["★ ", a("games.dicetown.ui.sheriffChange", {
					from: n(e.sheriffBefore),
					to: n(e.sheriffAfter)
				})]
			}), r && /* @__PURE__ */ h("div", {
				className: "dt-round-log",
				children: e.logs.map((e, t) => /* @__PURE__ */ h("div", { children: r(e) }, t))
			})] })
		]
	});
}
//#endregion
//#region src/games/dicetown/showdown.tsx
var Nt = {
	reveal: "games.dicetown.ui.revealed",
	compare: "games.dicetown.ui.comparing",
	winner: "games.dicetown.ui.locationWinner",
	result: "games.dicetown.ui.payout",
	prompt: "games.dicetown.ui.actionAt",
	visit: "games.dicetown.ui.actionAt",
	summary: "games.dicetown.ui.roundSummary"
}, Pt = {
	[-1]: "games.dicetown.rank.high",
	0: "games.dicetown.rank.pair",
	1: "games.dicetown.rank.twoPair",
	2: "games.dicetown.rank.three",
	3: "games.dicetown.rank.straight",
	4: "games.dicetown.rank.full",
	5: "games.dicetown.rank.four",
	6: "games.dicetown.rank.five"
}, Ft = {
	tie: "games.dicetown.tiePrompt",
	locChoice: "games.dicetown.locChoicePrompt",
	storePick: "games.dicetown.storePickPrompt",
	saloonTarget: "games.dicetown.saloonTargetPrompt",
	saloonPick: "games.dicetown.saloonPickPrompt",
	docPick: "games.dicetown.docPickPrompt",
	elixirVictim: "games.dicetown.ui.pickTarget",
	giveCard: "games.dicetown.giveCardPrompt",
	protectPick: "games.dicetown.protectPickPrompt",
	joeTarget: "games.dicetown.joeTargetPrompt",
	offer: "games.dicetown.offerPrompt",
	recruitPick: "games.dicetown.recruitPickPrompt",
	cowPlace: "games.dicetown.cowPlacePrompt",
	indianOffer: "games.dicetown.indianOfferPrompt",
	indianGive: "games.dicetown.indianGivePrompt",
	coupon: "games.dicetown.couponPrompt",
	discovery: "games.dicetown.discoveryPrompt",
	discoveryOrder: "games.dicetown.discoveryOrderPrompt",
	persuasion: "games.dicetown.persuasionPrompt",
	smokeSignals: "games.dicetown.smokeSignalsPrompt",
	finalTie: "games.dicetown.finalTiePrompt",
	desperadoPick: "games.dicetown.desperadoPrompt"
};
function It({ pub: e, nameOf: t, line: n }) {
	let r = o(), { ref: i } = ie("showdown"), a = e.moment, s = e.pending, c = S[a?.loc], l = s?.k === "finalTie" ? r("games.dicetown.finalTiePrompt") : a ? r(Nt[a.kind], {
		n: e.lastRound?.round ?? e.round,
		name: a.rid ? t(a.rid) : "",
		loc: Y[`loc.${a.loc}`] ? r(Y[`loc.${a.loc}`]) : ""
	}) : r("games.dicetown.ui.revealed"), u = a?.kind === "result", d = u && a.loc === "mine" ? a.gains.find((e) => e.nuggets > 0) : null, f = s?.k === "indianFx" ? r(s.face === "blessing" ? "games.dicetown.indianBlessingPrompt" : s.face === "ambush" ? "games.dicetown.indianAmbushPrompt" : "games.dicetown.indianWarpathPrompt") : s && Ft[s.k] ? r(Ft[s.k], {
		n: "n" in s ? s.n : 1,
		card: s.k === "offer" ? r(Y[`gs.${s.card}`]) : ""
	}) : "";
	return /* @__PURE__ */ g("div", {
		ref: i,
		className: `dt-showdown ${u ? "dt-showdown-result" : ""}`,
		children: [/* @__PURE__ */ g("div", {
			className: "dt-showdown-title",
			role: "status",
			children: [/* @__PURE__ */ h("strong", { children: l }), a?.kind === "winner" && /* @__PURE__ */ h("span", { children: r(a.logs.some((e) => e.k === "log.tie") ? "games.dicetown.ui.sheriffDecision" : a.role === "second" ? "games.dicetown.ui.secondPlace" : "games.dicetown.ui.firstPlace") })]
		}), a?.kind === "summary" && e.lastRound ? /* @__PURE__ */ h(Mt, {
			summary: e.lastRound,
			players: e.players,
			nameOf: t,
			compact: !0
		}) : s ? /* @__PURE__ */ g("div", {
			className: "dt-prompt-context",
			children: [
				/* @__PURE__ */ h("strong", { children: a?.rid ? t(a.rid) : t(e.sheriff) }),
				/* @__PURE__ */ h("span", { children: f }),
				s.k === "saloonPick" && /* @__PURE__ */ h("small", { children: r("games.dicetown.ui.cardsFrom", {
					name: t(s.from),
					n: s.n
				}) }),
				s.k === "tie" && /* @__PURE__ */ h("span", {
					className: "dt-tie-candidates",
					children: s.candidates.map(t).join(" · ")
				})
			]
		}) : u ? /* @__PURE__ */ h("div", {
			className: "dt-result-content",
			children: d ? /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("span", {
					className: "dt-result-gold",
					"aria-hidden": !0,
					children: "◆"
				}),
				/* @__PURE__ */ h("strong", { children: t(d.rid) }),
				/* @__PURE__ */ g("b", { children: ["+", d.nuggets] }),
				/* @__PURE__ */ h("span", { children: r("games.dicetown.ui.gold") })
			] }) : /* @__PURE__ */ g("div", {
				className: "dt-result-lines",
				children: [
					a.rolls.map((e, n) => /* @__PURE__ */ g("div", {
						className: "dt-result-roll",
						children: [/* @__PURE__ */ h("strong", { children: t(e.rid) }), e.faces.map((e, t) => /* @__PURE__ */ h(J, {
							face: e,
							small: !0,
							anchorName: `result-die:${n}:${t}`
						}, t))]
					}, n)),
					a.logs.map((e, t) => /* @__PURE__ */ h("div", { children: n(e) }, t)),
					a.gains.map((e) => /* @__PURE__ */ g("div", {
						className: "dt-result-gain",
						children: [/* @__PURE__ */ h("strong", { children: t(e.rid) }), /* @__PURE__ */ h(jt, { gain: e })]
					}, e.rid)),
					!a.logs.length && !a.gains.length && /* @__PURE__ */ h("span", { children: r("games.dicetown.ui.confirmed") })
				]
			})
		}) : /* @__PURE__ */ h("div", {
			className: `dt-showdown-players ${e.players.length <= 2 ? "dt-showdown-two" : ""}`,
			children: e.players.map((n) => {
				let i = e.hands?.[n.rid] ?? [], o = c == null ? [] : i.filter((e) => e === c), s = a?.kind === "winner" && n.rid === a.rid;
				return /* @__PURE__ */ g("div", {
					className: `dt-contender ${s ? "dt-contender-winner" : ""}`,
					children: [
						/* @__PURE__ */ h("strong", {
							title: t(n.rid),
							children: t(n.rid)
						}),
						/* @__PURE__ */ h("span", {
							className: "dt-contender-dice",
							children: i.map((e, t) => /* @__PURE__ */ h("span", {
								className: c != null && e !== c ? "dt-unmatched" : "",
								children: /* @__PURE__ */ h(J, {
									face: e,
									small: !0,
									anchorName: `reveal:${n.rid}:${t}`
								})
							}, t))
						}),
						a?.loc === "townhall" ? /* @__PURE__ */ h("b", {
							className: "dt-rank",
							children: r(Pt[I(i)[0]])
						}) : c != null && /* @__PURE__ */ h("b", { children: o.length })
					]
				}, n.rid);
			})
		})]
	}, a?.id);
}
//#endregion
//#region src/games/dicetown/town-board.tsx
var Lt = {
	mine: [
		4,
		6,
		119,
		143
	],
	bank: [
		127,
		1,
		119,
		157
	],
	store: [
		250,
		9,
		121,
		152
	],
	saloon: [
		7,
		157,
		174,
		146
	],
	sheriff: [
		200,
		160,
		168,
		148
	],
	townhall: [
		6,
		313,
		179,
		132
	],
	doc: [
		200,
		315,
		169,
		131
	],
	prairie: [
		7,
		444,
		357,
		37
	]
};
function Rt(e) {
	if (!e.cfg.indians) return null;
	for (let t = e.log.length - 1; t >= 0; t--) {
		let n = e.log[t];
		if (n.k === "log.round") break;
		if (n.k === "log.warpath" && typeof n.p?.loc == "string") {
			let e = n.p.loc.replace(/^loc\./, "");
			return e in Lt ? e : null;
		}
	}
	return null;
}
var zt = {
	wealth: "games.dicetown.ui.elixWealth",
	charm: "games.dicetown.ui.elixCharm",
	fortune: "games.dicetown.ui.elixFortune",
	power: "games.dicetown.ui.elixPower",
	protection: "games.dicetown.ui.elixProtection",
	friendship: "games.dicetown.ui.elixFriendship",
	domination: "games.dicetown.ui.elixDomination"
};
function Bt({ x: e, y: t, w: n, h: r, children: i, deck: a = !1, tint: o = "#ecd9b1" }) {
	return /* @__PURE__ */ g("g", {
		transform: `translate(${e} ${t - 124})`,
		children: [
			a && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("rect", {
				x: "3",
				y: "-3",
				width: n,
				height: r,
				fill: "#998668",
				stroke: "#695a41"
			}), /* @__PURE__ */ h("rect", {
				x: "1.5",
				y: "-1.5",
				width: n,
				height: r,
				fill: "#d9c39b",
				stroke: "#695a41"
			})] }),
			/* @__PURE__ */ h("path", {
				d: `M2 0H${n - 3}L${n} 3V${r - 4}L${n - 2} ${r}H2L0 ${r - 3}V2Z`,
				fill: o,
				stroke: "#806445"
			}),
			i
		]
	});
}
function Vt({ x: e, y: t, count: n, w: r = 24, h: i = 28 }) {
	return /* @__PURE__ */ g(Bt, {
		x: e,
		y: t,
		w: r,
		h: i,
		deck: !0,
		tint: "#bdbea0",
		children: [/* @__PURE__ */ h("path", {
			d: `M3 5H${r - 3}M3 ${i - 5}H${r - 3}`,
			stroke: "#687965"
		}), /* @__PURE__ */ h("text", {
			className: "dt-board-number",
			x: r / 2,
			y: i / 2 + 5,
			textAnchor: "middle",
			fontSize: "15",
			children: n
		})]
	});
}
function Ht({ pub: e, selected: t, sheriffName: i, onPick: s }) {
	let c = o(), l = r(null), u = ae();
	n(() => {
		if (!u) return;
		let e = (e) => {
			let t = l.current?.querySelectorAll(`[data-dt-lot="${e}"]`);
			if (!t) return null;
			for (let e of t) {
				let t = e.getBoundingClientRect();
				if (t.width && t.height) return {
					x: t.left,
					y: t.top,
					w: t.width,
					h: t.height
				};
			}
			return null;
		};
		for (let t of Object.keys(Lt)) u.registerProbe(`lot:${t}`, () => e(t));
		return u.registerProbe("stage", () => {
			let t = e("bank");
			return t ? {
				x: t.x + t.w * .48,
				y: t.y + t.h * .74,
				w: t.w * .45,
				h: t.h * .2
			} : null;
		}), u.registerProbe("village", () => {
			let t = e("bank");
			return t ? {
				x: t.x + t.w * .45,
				y: t.y + t.h * .08,
				w: t.w * .2,
				h: t.h * .16
			} : null;
		}), () => {
			for (let e of [
				...Object.keys(Lt).map((e) => `lot:${e}`),
				"stage",
				"village"
			]) u.registerProbe(e, null);
		};
	}, [u]);
	let d = a((e) => e.locale), f = Rt(e), p = (n, r, i, a, o) => {
		let s = t.filter((e) => e === S[n]).length, l = e.phase === "resolve" && e.step === n, u = f === n;
		return /* @__PURE__ */ g("g", {
			transform: `translate(${r} ${i - 124})`,
			children: [
				/* @__PURE__ */ h("path", {
					d: `M2 0H${a - 4}L${a} 4L${a - 1} 26L4 28L0 23V3Z`,
					fill: "#494032",
					stroke: "#211f19",
					strokeWidth: "1.2"
				}),
				/* @__PURE__ */ h("path", {
					d: `M6 3H${a - 7}M4 -3L5 3M${a - 5} -2L${a - 6} 3`,
					stroke: "#9c8053"
				}),
				o && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("rect", {
					x: "4",
					y: "4",
					width: n === "townhall" ? 37 : 22,
					height: "21",
					fill: "#f1dcb1",
					stroke: "#a68e60"
				}), /* @__PURE__ */ h("text", {
					x: n === "townhall" ? 22.5 : 15,
					y: "20",
					textAnchor: "middle",
					fontSize: n === "townhall" ? 10 : 14,
					className: "dt-board-number",
					children: o
				})] }),
				/* @__PURE__ */ h("text", {
					x: o ? n === "townhall" ? 48 : 33 : 10,
					y: "20",
					fill: "#f5e0b6",
					fontSize: "14",
					fontWeight: "800",
					textLength: d === "en" ? n === "store" ? 62 : n === "townhall" ? 65 : n === "sheriff" ? 55 : n === "mine" ? 53 : void 0 : void 0,
					lengthAdjust: "spacingAndGlyphs",
					children: c(Y[`loc.${n}`])
				}),
				n === "doc" && /* @__PURE__ */ h("text", {
					x: a - 7,
					y: "19",
					textAnchor: "end",
					fill: "#cbbb98",
					fontSize: "9",
					children: c("games.dicetown.ui.noGain")
				}),
				(s > 0 || l || u) && /* @__PURE__ */ g(m, { children: [
					/* @__PURE__ */ h("path", {
						d: `M0 12V0H13M${a - 13} 29H${a + 1}V17`,
						fill: "none",
						stroke: u ? "#8b432d" : "#46a4b9",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ h("path", {
						d: "M0 -18H14L19 -14V0L15 4L0 2Z",
						fill: u ? "#8b432d" : "#248ba8",
						stroke: "#1b5f72"
					}),
					/* @__PURE__ */ h("text", {
						x: "9",
						y: "-3",
						textAnchor: "middle",
						fill: "#fff0c8",
						fontSize: "14",
						fontWeight: "800",
						children: u ? "×" : l ? "▶" : s
					})
				] })
			]
		});
	}, ee = /* @__PURE__ */ g("svg", {
		width: "375",
		height: "481",
		viewBox: "0 0 375 481",
		className: "dt-board",
		"aria-label": c("games.dicetown.ui.town"),
		role: "img",
		children: [
			/* @__PURE__ */ h("image", {
				href: `games/dicetown/${e.cfg.cowboys ? "board-base" : "board-basic"}.webp`,
				width: "375",
				height: "481"
			}),
			p("mine", 14, 207, 92, "9"),
			p("bank", 134, 211, 94, "10"),
			p("store", 258, 216, 105, "J"),
			p("saloon", 29, 345, 96, "Q"),
			p("sheriff", 210, 349, 104, "K"),
			p("townhall", 19, 494, 129, c("games.dicetown.ui.poker")),
			p("doc", 209, 496, 154),
			/* @__PURE__ */ h("path", {
				d: "M15 124L22 123L26 130L21 134L15 132Z",
				fill: "#b28c39",
				stroke: "#765b28"
			}),
			/* @__PURE__ */ h("text", {
				x: "31",
				y: "136",
				fontSize: "20",
				className: "dt-board-number",
				children: e.mine
			}),
			e.cfg.wildwest && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h(Vt, {
					x: 81,
					y: 240,
					count: e.riverDeck,
					w: 21,
					h: 27
				}),
				/* @__PURE__ */ h("text", {
					x: "106",
					y: "123",
					fontSize: d === "en" ? 7 : 10,
					children: c("games.dicetown.ui.riverLine1")
				}),
				/* @__PURE__ */ h("text", {
					x: "106",
					y: "136",
					fontSize: "10",
					children: c("games.dicetown.ui.riverLine2")
				})
			] }),
			/* @__PURE__ */ g("text", {
				x: "139",
				y: "140",
				fontSize: "22",
				className: "dt-board-number",
				children: ["$", e.bank]
			}),
			/* @__PURE__ */ h("text", {
				x: "185",
				y: "125",
				fontSize: "11",
				children: c("games.dicetown.stageLabel")
			}),
			/* @__PURE__ */ g("text", {
				x: "185",
				y: "145",
				fontSize: "15",
				className: "dt-board-number",
				children: ["$", e.stage]
			}),
			/* @__PURE__ */ h(Vt, {
				x: 265,
				y: 249,
				count: e.gsDeck,
				w: 23,
				h: 27
			}),
			/* @__PURE__ */ h("text", {
				x: "298",
				y: "132",
				fontSize: "12",
				children: c("games.dicetown.ch.store.draw")
			}),
			/* @__PURE__ */ h("text", {
				x: "298",
				y: "151",
				fontSize: "10",
				children: c("games.dicetown.ui.discard", { n: e.gsDiscard.length })
			}),
			/* @__PURE__ */ h("text", {
				x: "24",
				y: "282",
				fontSize: "13",
				children: c("games.dicetown.ch.saloon.steal")
			}),
			e.cfg.wildwest && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(Vt, {
				x: 103,
				y: 384,
				count: e.outlawDeck,
				w: 24,
				h: 31
			}), /* @__PURE__ */ h("text", {
				x: "137",
				y: "282",
				fontSize: "12",
				children: c("games.dicetown.ui.outlaw")
			})] }),
			/* @__PURE__ */ h("text", {
				x: "324",
				y: "244",
				fontSize: "12",
				fill: "#83652f",
				children: "★"
			}),
			/* @__PURE__ */ h("text", {
				x: "337",
				y: "244",
				fontSize: "10",
				textLength: 27,
				lengthAdjust: "spacingAndGlyphs",
				children: i.slice(0, 4)
			}),
			e.cfg.wildwest && e.outlawWanted.slice(0, 2).map((e, t) => /* @__PURE__ */ g(Bt, {
				x: 220 + t * 61,
				y: 387,
				w: 53,
				h: 38,
				tint: "#edcb97",
				children: [
					/* @__PURE__ */ g("text", {
						x: "26.5",
						y: "14",
						textAnchor: "middle",
						fontSize: "11",
						className: "dt-board-number",
						children: [
							x[e.pair],
							" ",
							x[e.pair]
						]
					}),
					/* @__PURE__ */ h("path", {
						d: "M6 18H47",
						stroke: "#a57c50"
					}),
					/* @__PURE__ */ g("text", {
						x: "26.5",
						y: "33",
						fontSize: "16",
						textAnchor: "middle",
						className: "dt-board-number",
						children: ["$", e.reward]
					})
				]
			}, e.i)),
			e.cfg.wildwest && e.outlawWanted.length > 2 && /* @__PURE__ */ g("text", {
				x: "343",
				y: "300",
				fontSize: "10",
				children: ["+", e.outlawWanted.length - 2]
			}),
			e.propUp.map((e, t) => /* @__PURE__ */ g(Bt, {
				x: 22 + t * 38,
				y: 525,
				w: 32,
				h: 39,
				children: [
					/* @__PURE__ */ h("path", {
						d: "M2 3H15L29 11L18 17L2 14Z",
						fill: "#9aa174"
					}),
					/* @__PURE__ */ h("path", {
						d: "M4 13L17 7L28 13",
						stroke: "#555c45",
						fill: "none"
					}),
					/* @__PURE__ */ h("text", {
						x: "16",
						y: "35",
						fontSize: "20",
						textAnchor: "middle",
						className: "dt-board-number",
						children: e.ranch ? "⌂" : e.value
					})
				]
			}, e.id)),
			/* @__PURE__ */ h(Vt, {
				x: 143,
				y: 532,
				count: e.propDeck
			}),
			e.elixUp.map((e, t) => /* @__PURE__ */ g(Bt, {
				x: 216 + t * 51,
				y: 529,
				w: 45,
				h: 39,
				children: [/* @__PURE__ */ h("path", {
					d: "M19 4H26V10H30V21H15V10H19Z",
					fill: e === "wealth" ? "#91a078" : "#b37c5c",
					stroke: "#5c6044"
				}), /* @__PURE__ */ h("text", {
					x: "22.5",
					y: "35",
					textAnchor: "middle",
					fontSize: "11",
					textLength: d === "en" ? 36 : void 0,
					lengthAdjust: "spacingAndGlyphs",
					children: c(zt[e])
				})]
			}, `${e}-${t}`)),
			/* @__PURE__ */ h(Vt, {
				x: 329,
				y: 536,
				count: "?",
				w: 21,
				h: 27
			}),
			e.cfg.cowboys && /* @__PURE__ */ g(m, { children: [
				p("prairie", 50, 575, 85, "A"),
				/* @__PURE__ */ h("text", {
					x: "144",
					y: "469",
					fontSize: "15",
					fontWeight: "800",
					children: c("games.dicetown.ui.cattle", { n: e.prairie })
				}),
				e.cowboyUp.map((e, t) => /* @__PURE__ */ h(Bt, {
					x: 217 + t * 33,
					y: 578,
					w: 26,
					h: 24,
					children: /* @__PURE__ */ h("text", {
						x: "13",
						y: "18",
						fontSize: "19",
						textAnchor: "middle",
						fill: e === "H" || e === "D" ? "#8e432b" : "#30291f",
						children: {
							S: "♠",
							H: "♥",
							D: "♦",
							C: "♣"
						}[e]
					})
				}, t)),
				/* @__PURE__ */ h("text", {
					x: "291",
					y: "463",
					fontSize: "10",
					children: "Rodeo"
				}),
				/* @__PURE__ */ h("text", {
					x: "340",
					y: "471",
					fontSize: "13",
					className: "dt-board-number",
					children: e.rodeos
				})
			] }),
			e.cfg.indians && /* @__PURE__ */ h("text", {
				x: "192",
				y: "25",
				textAnchor: "middle",
				fontSize: "18",
				fill: "#344c4a",
				children: e.indian.armed ? "◆" : "◇"
			})
		]
	}), te = Object.keys(Lt).filter((t) => t !== "prairie" || e.cfg.cowboys);
	return /* @__PURE__ */ g("div", {
		ref: l,
		className: "dt-board-viewport",
		children: [/* @__PURE__ */ g("div", {
			className: "dt-board-canvas",
			children: [ee, Object.entries(Lt).filter(([t]) => t !== "prairie" || e.cfg.cowboys).map(([t, [n, r, i, a]]) => /* @__PURE__ */ h("button", {
				type: "button",
				className: `dt-lot-hit ${e.step === t ? "dt-lot-active" : ""}`,
				"data-dt-lot": t,
				"aria-label": c(Y[`loc.${t}`]),
				onClick: () => s(t),
				style: {
					left: `${n / 375 * 100}%`,
					top: t === "prairie" ? void 0 : `${r / 481 * 100}%`,
					bottom: t === "prairie" ? 0 : void 0,
					width: `${i / 375 * 100}%`,
					height: t === "prairie" ? 44 : `${a / 481 * 100}%`
				}
			}, t))]
		}), /* @__PURE__ */ h("div", {
			className: "dt-board-wide",
			children: te.map((t) => {
				let [n, r, i, a] = Lt[t];
				return /* @__PURE__ */ h("button", {
					type: "button",
					className: `dt-wide-lot ${e.step === t ? "dt-lot-active" : ""}`,
					"data-dt-lot": t,
					onClick: () => s(t),
					"aria-label": c(Y[`loc.${t}`]),
					children: t === "prairie" ? /* @__PURE__ */ g("svg", {
						viewBox: "0 0 145 140",
						role: "img",
						"aria-label": c("games.dicetown.loc.prairie"),
						children: [
							/* @__PURE__ */ h("path", {
								d: "M5 4L138 0L145 14L142 132L128 139L4 135L0 120Z",
								fill: "#e4d3a7",
								stroke: "#927c56"
							}),
							/* @__PURE__ */ h("svg", {
								x: "7",
								y: "8",
								width: "35",
								height: "36",
								viewBox: "7 444 36 37",
								children: /* @__PURE__ */ h("image", {
									href: "games/dicetown/board-base.webp",
									width: "375",
									height: "481"
								})
							}),
							/* @__PURE__ */ h("path", {
								d: "M44 10H138V38H44Z",
								fill: "#494032"
							}),
							/* @__PURE__ */ g("text", {
								x: "52",
								y: "30",
								fill: "#f5e0b6",
								fontWeight: "800",
								fontSize: "14",
								children: ["A · ", c("games.dicetown.loc.prairie")]
							}),
							/* @__PURE__ */ h("text", {
								x: "14",
								y: "65",
								fontSize: "18",
								fontWeight: "800",
								children: c("games.dicetown.ui.cattle", { n: e.prairie })
							}),
							e.cowboyUp.map((e, t) => /* @__PURE__ */ g("g", {
								transform: `translate(${15 + t * 42} 75)`,
								children: [/* @__PURE__ */ h("rect", {
									width: "32",
									height: "29",
									fill: "#f3e3bf",
									stroke: "#817657"
								}), /* @__PURE__ */ h("text", {
									x: "16",
									y: "22",
									textAnchor: "middle",
									fontSize: "22",
									fill: e === "H" || e === "D" ? "#8e432b" : "#30291f",
									children: {
										S: "♠",
										H: "♥",
										D: "♦",
										C: "♣"
									}[e]
								})]
							}, t)),
							/* @__PURE__ */ g("text", {
								x: "15",
								y: "123",
								fontSize: "13",
								children: ["Rodeo · ", e.rodeos]
							})
						]
					}) : /* @__PURE__ */ g("svg", {
						viewBox: `${n - 2} ${r - 2} ${i + 4} ${a + 4}`,
						role: "img",
						"aria-label": c(Y[`loc.${t}`]),
						children: [/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ h("clipPath", {
							id: `dt-wide-${t}`,
							children: /* @__PURE__ */ h("rect", {
								x: n - 2,
								y: r - 2,
								width: i + 4,
								height: a + 4
							})
						}) }), /* @__PURE__ */ h("g", {
							"aria-hidden": !0,
							clipPath: `url(#dt-wide-${t})`,
							children: ee
						})]
					})
				}, t);
			})
		})]
	});
}
//#endregion
//#region src/games/dicetown/view-player.tsx
function Ut(e) {
	return /* @__PURE__ */ h(Xt, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var Wt = {
	"log.round": "games.dicetown.logRound",
	"log.resolve": "games.dicetown.logResolve",
	"log.mine": "games.dicetown.logMine",
	"log.bank": "games.dicetown.logBank",
	"log.stage": "games.dicetown.logStage",
	"log.store": "games.dicetown.logStore",
	"log.noControl": "games.dicetown.logNoControl",
	"log.sheriff": "games.dicetown.logSheriff",
	"log.saloon": "games.dicetown.logSaloon",
	"log.stealFail": "games.dicetown.logStealFail",
	"log.recruitOutlaw": "games.dicetown.logRecruitOutlaw",
	"log.capture": "games.dicetown.logCapture",
	"log.chase": "games.dicetown.logChase",
	"log.townhall": "games.dicetown.logTownhall",
	"log.mayor": "games.dicetown.logMayor",
	"log.corruption": "games.dicetown.logCorruption",
	"log.persuasion": "games.dicetown.logPersuasion",
	"log.prairieSteal": "games.dicetown.logPrairieSteal",
	"log.recruitCowboy": "games.dicetown.logRecruitCowboy",
	"log.rodeo": "games.dicetown.logRodeo",
	"log.cowPlace": "games.dicetown.logCowPlace",
	"log.doc": "games.dicetown.logDoc",
	"log.docPlan": "games.dicetown.logDocPlan",
	"log.protect": "games.dicetown.logProtect",
	"log.give": "games.dicetown.logGive",
	"log.joe": "games.dicetown.logJoe",
	"log.swindler": "games.dicetown.logSwindler",
	"log.evensplit": "games.dicetown.logEvensplit",
	"log.wanted": "games.dicetown.logWanted",
	"log.play": "games.dicetown.logPlay",
	"log.useOutlaw": "games.dicetown.logUseOutlaw",
	"log.herder": "games.dicetown.logHerder",
	"log.insurance": "games.dicetown.logInsurance",
	"log.river": "games.dicetown.logRiver",
	"log.indianFx": "games.dicetown.logIndianFx",
	"log.indianGive": "games.dicetown.logIndianGive",
	"log.indianBack": "games.dicetown.logIndianBack",
	"log.warpath": "games.dicetown.logWarpath",
	"log.win": "games.dicetown.logWin",
	"log.choice": "games.dicetown.logChoice",
	"log.storeKeep": "games.dicetown.logStoreKeep",
	"log.target": "games.dicetown.logTarget",
	"log.tie": "games.dicetown.logTie",
	"log.decline": "games.dicetown.logDecline",
	"log.confirm": "games.dicetown.logConfirm",
	"log.blessing": "games.dicetown.logBlessing",
	"log.ambush": "games.dicetown.logAmbush",
	"log.warpathSet": "games.dicetown.logWarpathSet",
	"log.stageBank": "games.dicetown.logStageBank",
	"log.sheriffKeep": "games.dicetown.logSheriffKeep"
}, Gt = {
	mine: "games.dicetown.loc.mine",
	bank: "games.dicetown.loc.bank",
	store: "games.dicetown.loc.store",
	saloon: "games.dicetown.loc.saloon",
	sheriff: "games.dicetown.loc.sheriff",
	townhall: "games.dicetown.loc.townhall",
	prairie: "games.dicetown.loc.prairie",
	doc: "games.dicetown.loc.doc",
	indianOffer: "games.dicetown.loc.indianOffer",
	roundEnd: "games.dicetown.loc.roundEnd"
}, Kt = {
	"mine.exploit": "games.dicetown.ch.mine.exploit",
	"mine.river": "games.dicetown.ch.mine.river",
	"bank.rob": "games.dicetown.ch.bank.rob",
	"bank.stage": "games.dicetown.ch.bank.stage",
	"store.draw": "games.dicetown.ch.store.draw",
	"store.doc": "games.dicetown.ch.store.doc",
	"saloon.steal": "games.dicetown.ch.saloon.steal",
	"saloon.recruitOutlaw": "games.dicetown.ch.saloon.recruitOutlaw",
	"sheriff.badge": "games.dicetown.ch.sheriff.badge",
	"sheriff.chase": "games.dicetown.ch.sheriff.chase",
	"townhall.normal": "games.dicetown.ch.townhall.normal",
	"townhall.mayor": "games.dicetown.ch.townhall.mayor",
	"townhall.bribe": "games.dicetown.ch.townhall.bribe",
	"prairie.steal": "games.dicetown.ch.prairie.steal",
	"prairie.recruit": "games.dicetown.ch.prairie.recruit"
}, qt = [
	"mine",
	"bank",
	"store",
	"saloon",
	"sheriff",
	"townhall",
	"prairie"
], Jt = [
	0,
	1,
	2,
	3,
	4,
	5
], Yt = {
	S: "♠",
	H: "♥",
	D: "♦",
	C: "♣"
};
function Xt({ pub: e, priv: t, members: oe, myRid: _, send: v }) {
	let y = o(), se = a((e) => e.locale), [b, S] = i(null), [le, ue] = i(""), [de, fe] = i(!1), C = (e) => e.startsWith("prop.") ? `${y("games.dicetown.propsLabel")} ${e.slice(5)}` : Y[e] ? y(Y[e]) : e, w = e.players.find((e) => e.rid === _), T = (e) => {
		let t = oe.find((t) => t.rid === e);
		return t ? d(t, se) : e;
	}, pe = (e, t) => typeof t == "number" ? t : e === "who" || e === "from" || e === "to" ? T(t) : /^(loc|gs|elix|river|indian|ch)\./.test(t) ? C(t) : t, me = (e) => {
		let t = Wt[e.k];
		if (!t) return e.k;
		let n = {};
		for (let [t, r] of Object.entries(e.p ?? {})) n[t] = pe(t, r);
		return y(t, n);
	}, E = `${e.phase}|${e.round}|${e.step}|${JSON.stringify(e.pending)}|${(t?.dice ?? []).join(",")}|${(t?.rolled ?? []).join(",")}`, [D, ge] = i({
		key: E,
		keep: [],
		cheat: !1,
		cheatDie: null,
		multi: [],
		cow: {},
		indianDie: null,
		indianTarget: null
	}), O = D.key === E ? D : {
		key: E,
		keep: [],
		cheat: !1,
		cheatDie: null,
		multi: [],
		cow: {},
		indianDie: null,
		indianTarget: null
	}, k = (e) => ge({
		...O,
		...e,
		key: E
	}), { ref: _e } = ie("dice-area"), { ref: ve } = ie("wallet"), ye = r(null), be = ae();
	if (n(() => {
		if (!be || !ye.current) return;
		let e = ye.current, t = /* @__PURE__ */ new Map(), n = () => {
			let n = e.querySelectorAll(".dt-rolled-group .dt-dice-line > .dt-die");
			if (!e.querySelector(".dt-rolled-group [aria-pressed]")) return;
			let r = e.getBoundingClientRect(), i = e.querySelectorAll(".dt-kept-group .dt-die").length;
			n.forEach((n, a) => {
				let o = n.getBoundingClientRect();
				t.set(`${i}:${a}`, {
					x: o.left - r.left + e.scrollLeft,
					y: o.top - r.top + e.scrollTop,
					w: o.width,
					h: o.height,
					trayWidth: r.width
				});
			});
		}, r = Array.from({ length: 25 }, (e, t) => `${Math.floor(t / 5)}:${t % 5}`);
		for (let n of r) be.registerProbe(`keep-origin:${n}`, () => {
			let r = t.get(n);
			if (!r) return null;
			let i = e.getBoundingClientRect(), a = r.trayWidth > 0 ? i.width / r.trayWidth : 1;
			return {
				x: i.left + r.x * a - e.scrollLeft,
				y: i.top + r.y * a - e.scrollTop,
				w: r.w * a,
				h: r.h * a
			};
		});
		n();
		let i = new ResizeObserver(n), a = new MutationObserver(n);
		return i.observe(e), a.observe(e, {
			childList: !0,
			subtree: !0,
			attributes: !0,
			attributeFilter: [
				"class",
				"style",
				"aria-pressed"
			]
		}), () => {
			i.disconnect(), a.disconnect();
			for (let e of r) be.registerProbe(`keep-origin:${e}`, null);
		};
	}, [be, !!(w && t)]), !w || !t) return null;
	let A = e.pending, xe = A != null && ("rid" in A && A.rid === _ || A.k === "giveCard" && A.from === _ || (A.k === "tie" || A.k === "finalTie") && e.sheriff === _), Se = t.dice ?? [], Ce = t.rolled, we = t.bruteFree ? 0 : Math.max(0, O.keep.length - 1), Te = O.keep.length > 0 && we <= w.money, j = (e) => k({ keep: O.keep.includes(e) ? O.keep.filter((t) => t !== e) : [...O.keep, e] }), M = (e, t, n = {}) => /* @__PURE__ */ h(J, {
		face: t,
		selected: n.picked,
		onClick: n.onClick,
		small: n.small
	}, e), N = /* @__PURE__ */ g("div", {
		className: "dt-choices",
		children: [
			t.gs.includes("brute") && !t.bruteFree && !w.done && e.phase === "build" && /* @__PURE__ */ h("button", {
				type: "button",
				className: "dt-choice",
				onClick: () => {
					v({ type: "brute" }), S(null);
				},
				children: y("games.dicetown.useBrute")
			}),
			t.gs.includes("cheater") && !w.done && e.phase === "build" && /* @__PURE__ */ h("button", {
				type: "button",
				className: "dt-choice",
				"aria-pressed": O.cheat,
				onClick: () => {
					k({
						cheat: !O.cheat,
						cheatDie: null
					}), S(null);
				},
				children: y("games.dicetown.useCheat")
			}),
			t.canOutlaw && w.outlaws.map((e, t) => /* @__PURE__ */ g("button", {
				type: "button",
				className: "dt-choice",
				onClick: () => {
					v({
						type: "outlaw",
						i: t
					}), S(null);
				},
				children: [
					y("games.dicetown.useOutlaw"),
					" ",
					x[e.pair],
					" ",
					x[e.pair]
				]
			}, e.i))
		]
	}), P = e.phase === "build" && !w.done && (t.gs.includes("cheater") || !t.bruteFree && t.gs.includes("brute") || t.canOutlaw), F = e.phase === "build" ? Se : e.hands?.[_] ?? [], I = /* @__PURE__ */ g("div", {
		ref: _e,
		className: "dt-dice-area",
		children: [F.length > 0 && /* @__PURE__ */ g("div", {
			className: "dt-dice-group dt-kept-group",
			children: [/* @__PURE__ */ h("span", {
				className: "dt-dice-caption",
				children: y("games.dicetown.ui.kept", { n: F.length })
			}), /* @__PURE__ */ h("div", {
				className: "dt-dice-line",
				children: F.map((t, n) => /* @__PURE__ */ h(J, {
					face: t,
					small: !0,
					locked: !0,
					anchorName: `kept:${n}`,
					tilt: n % 2 ? 2 : -2,
					onClick: O.cheat && !O.cheatDie && e.phase === "build" && !w.done ? () => k({ cheatDie: {
						where: "kept",
						i: n
					} }) : void 0
				}, n))
			})]
		}), e.phase === "build" && !w.done && /* @__PURE__ */ g("div", {
			className: "dt-dice-group dt-rolled-group",
			children: [/* @__PURE__ */ h("span", {
				className: "dt-dice-caption",
				title: e.closing ? y("games.dicetown.closingHint") : void 0,
				children: O.cheat ? y("games.dicetown.ui.selectCheat") : e.closing ? e.closingBy ? y("games.dicetown.ui.closingBy", { name: T(e.closingBy) }) : y("games.dicetown.ui.lastRoll") : y("games.dicetown.ui.rolled")
			}), /* @__PURE__ */ h("div", {
				className: "dt-dice-line",
				children: Ce.length > 0 ? Ce.map((e, t) => /* @__PURE__ */ h(J, {
					face: e,
					selected: O.keep.includes(t),
					anchorName: `rolled:${t}`,
					tilt: [
						-9,
						7,
						13,
						-5,
						8
					][t],
					onClick: () => O.cheat ? k({ cheatDie: {
						where: "rolled",
						i: t
					} }) : j(t)
				}, t)) : Array.from({ length: 5 - F.length }, (e, t) => /* @__PURE__ */ h(J, {
					empty: !0,
					tilt: [
						-7,
						6,
						-3,
						7,
						-8
					][t]
				}, t))
			})]
		})]
	}), Ee = w.done ? /* @__PURE__ */ h("p", {
		className: "dt-action-message",
		role: "status",
		children: y("games.dicetown.buildDone")
	}) : O.cheatDie ? /* @__PURE__ */ g("div", {
		className: "dt-cheat-faces",
		children: [Jt.map((e) => /* @__PURE__ */ h(J, {
			face: e,
			small: !0,
			onClick: () => {
				v({
					type: "cheat",
					where: O.cheatDie.where,
					i: O.cheatDie.i,
					face: e
				}), k({
					cheat: !1,
					cheatDie: null
				});
			}
		}, e)), /* @__PURE__ */ h("button", {
			type: "button",
			className: "dt-icon-button",
			"aria-label": y("common.close"),
			onClick: () => k({
				cheat: !1,
				cheatDie: null
			}),
			children: /* @__PURE__ */ h(ee, { size: 16 })
		})]
	}) : /* @__PURE__ */ g("div", {
		className: "dt-confirm-row",
		children: [/* @__PURE__ */ h("button", {
			type: "button",
			className: "dt-secondary",
			disabled: Ce.length === 0 || !t.bruteFree && w.money < 1,
			onClick: () => {
				v({
					type: "keep",
					idxs: []
				}), k({ keep: [] });
			},
			children: t.bruteFree ? y("games.dicetown.ui.keepNoneFree") : y("games.dicetown.keepNone")
		}), /* @__PURE__ */ h("button", {
			type: "button",
			className: "dt-primary",
			disabled: Ce.length > 0 && !Te,
			onClick: () => {
				v(Ce.length === 0 ? { type: "roll" } : {
					type: "keep",
					idxs: O.keep
				}), k({ keep: [] });
			},
			children: Ce.length === 0 ? y("games.dicetown.roll") : t.bruteFree ? y("games.dicetown.keepFree") : O.keep.length === 0 ? y("games.dicetown.keepSel") : y("games.dicetown.keepCost", {
				n: O.keep.length,
				c: we
			})
		})]
	}), L = (e) => y("games.dicetown.waiting", { name: T(e) }), R = (e) => /* @__PURE__ */ h("div", {
		className: "flex flex-wrap gap-1.5",
		children: e.map((e, t) => /* @__PURE__ */ h("button", {
			type: "button",
			className: "dt-choice",
			"aria-pressed": e.accent ?? void 0,
			onClick: e.onClick,
			children: e.label
		}, t))
	}), De = (e) => /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-1.5",
		children: [/* @__PURE__ */ h("div", {
			className: "text-sm",
			children: e
		}), R([{
			label: y("games.dicetown.accept"),
			accent: !0,
			onClick: () => v({
				type: "offer",
				accept: !0
			})
		}, {
			label: y("games.dicetown.decline"),
			onClick: () => v({
				type: "offer",
				accept: !1
			})
		}])]
	}), z = null;
	if (e.phase !== "build" && A) {
		if (xe) switch (A.k) {
			case "tie":
			case "finalTie":
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y(A.k === "finalTie" ? "games.dicetown.finalTiePrompt" : "games.dicetown.tiePromptMe")
					}), R(A.candidates.map((e) => ({
						label: T(e),
						onClick: () => v({
							type: "tie",
							pick: e
						})
					})))]
				});
				break;
			case "locChoice":
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.locChoicePrompt")
					}), R(A.options.map((e) => ({
						label: y(Kt[`${A.loc}.${e}`] ?? "games.dicetown.errBadAction"),
						accent: !0,
						onClick: () => v({
							type: "locChoice",
							option: e
						})
					})))]
				});
				break;
			case "storePick": {
				let e = t.pendingPriv?.k === "storePick" ? t.pendingPriv.drawn : [];
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.storePickPrompt")
					}), R(e.map((e, t) => ({
						label: C(`gs.${e}`),
						onClick: () => v({
							type: "pick",
							i: t
						})
					})))]
				});
				break;
			}
			case "saloonTarget":
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.saloonTargetPrompt")
					}), R(e.players.filter((e) => e.rid !== _ && !e.bodyguard).map((e) => ({
						label: T(e.rid),
						onClick: () => v({
							type: "target",
							rid: e.rid
						})
					})))]
				});
				break;
			case "saloonPick": {
				let e = t.pendingPriv?.k === "saloonPick" ? t.pendingPriv.cards : [];
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.saloonPickPrompt")
					}), R(e.map((e, t) => ({
						label: C(e.label),
						onClick: () => v({
							type: "pick",
							i: t
						})
					})))]
				});
				break;
			}
			case "docPick":
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.docPickPrompt")
					}), R([...e.elixUp.map((e, t) => ({
						label: C(`elix.${e}`),
						onClick: () => v({
							type: "pick",
							i: t
						})
					})), {
						label: y("games.dicetown.docPickBlind"),
						onClick: () => v({
							type: "pick",
							i: e.elixUp.length
						})
					}])]
				});
				break;
			case "elixirVictim":
				z = R(e.players.filter((e) => e.rid !== _).map((e) => ({
					label: T(e.rid),
					onClick: () => v({
						type: "target",
						rid: e.rid
					})
				})));
				break;
			case "giveCard": {
				let e = A.cardType === "gs" ? t.gs.map((e, t) => ({
					label: C(`gs.${e}`),
					onClick: () => v({
						type: "pick",
						i: t
					})
				})) : t.props.map((e, t) => ({
					label: String(e.value),
					onClick: () => v({
						type: "pick",
						i: t
					})
				}));
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.giveCardPrompt")
					}), R(e)]
				});
				break;
			}
			case "protectPick":
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [
						/* @__PURE__ */ h("div", {
							className: "text-sm",
							children: y("games.dicetown.protectPickPrompt")
						}),
						R(t.props.map((e, t) => ({
							label: `${O.multi.includes(t) ? "✓ " : ""}${e.value}`,
							accent: O.multi.includes(t),
							onClick: () => k({ multi: O.multi.includes(t) ? O.multi.filter((e) => e !== t) : [...O.multi, t].slice(-2) })
						}))),
						/* @__PURE__ */ h("button", {
							type: "button",
							disabled: O.multi.length === 0,
							className: "dt-choice dt-choice-confirm",
							onClick: () => v({
								type: "pickMulti",
								is: O.multi
							}),
							"aria-label": y("games.dicetown.ui.confirmed"),
							children: /* @__PURE__ */ h(p, { size: 20 })
						})
					]
				});
				break;
			case "joeTarget":
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.joeTargetPrompt")
					}), R(e.players.filter((e) => e.rid !== _).map((e) => ({
						label: `${T(e.rid)} $${e.money}`,
						onClick: () => v({
							type: "target",
							rid: e.rid
						})
					})))]
				});
				break;
			case "offer":
				z = De(y("games.dicetown.offerPrompt", { card: C(`gs.${A.card}`) }));
				break;
			case "smokeSignals":
				z = De(y("games.dicetown.smokeSignalsPrompt"));
				break;
			case "recruitPick":
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [
						/* @__PURE__ */ h("div", {
							className: "text-sm",
							children: y("games.dicetown.recruitPickPrompt", { n: A.n })
						}),
						R(e.cowboyUp.map((e, t) => ({
							label: `${O.multi.includes(t) ? "✓ " : ""}${Yt[e] ?? e}`,
							accent: O.multi.includes(t),
							onClick: () => k({ multi: O.multi.includes(t) ? O.multi.filter((e) => e !== t) : [...O.multi, t].slice(-A.n) })
						}))),
						/* @__PURE__ */ h("button", {
							type: "button",
							disabled: O.multi.length === 0,
							className: "dt-choice dt-choice-confirm",
							onClick: () => v({
								type: "pickMulti",
								is: O.multi
							}),
							"aria-label": y("games.dicetown.ui.confirmed"),
							children: /* @__PURE__ */ h(p, { size: 20 })
						})
					]
				});
				break;
			case "cowPlace": {
				let e = Object.entries(O.cow).filter(([, e]) => e).reduce((e, [n]) => e + (t.props.find((e) => e.id === Number(n))?.value ?? 0), 0);
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [
						/* @__PURE__ */ g("div", {
							className: "text-sm",
							children: [
								y("games.dicetown.cowPlacePrompt"),
								" (",
								e,
								"/",
								w.herd,
								")"
							]
						}),
						R(t.props.map((e) => ({
							label: `${O.cow[e.id] ? "✓ " : ""}${e.value}→${e.value}`,
							accent: !!O.cow[e.id],
							onClick: () => k({ cow: {
								...O.cow,
								[e.id]: !O.cow[e.id]
							} })
						}))),
						/* @__PURE__ */ g("div", {
							className: "flex gap-1.5",
							children: [/* @__PURE__ */ h("button", {
								type: "button",
								className: "dt-choice dt-choice-confirm",
								onClick: () => v({
									type: "cowPlace",
									place: Object.entries(O.cow).filter(([, e]) => e).map(([e]) => ({
										id: Number(e),
										n: t.props.find((t) => t.id === Number(e))?.value ?? 0
									}))
								}),
								"aria-label": y("games.dicetown.ui.confirmed"),
								children: /* @__PURE__ */ h(p, { size: 20 })
							}), /* @__PURE__ */ h("button", {
								type: "button",
								className: "dt-choice",
								onClick: () => v({
									type: "cowPlace",
									place: []
								}),
								children: y("games.dicetown.cowPlaceSkip")
							})]
						})
					]
				});
				break;
			}
			case "indianOffer":
				z = De(y("games.dicetown.indianOfferPrompt"));
				break;
			case "indianGive": {
				let e = t.pendingPriv?.k === "indianGive" ? t.pendingPriv.props : [];
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.indianGivePrompt")
					}), R(e.map((e, t) => ({
						label: String(e.value),
						onClick: () => v({
							type: "pick",
							i: t
						})
					})))]
				});
				break;
			}
			case "coupon":
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.couponPrompt")
					}), R(e.gsDiscard.map((e, t) => ({
						label: C(`gs.${e}`),
						onClick: () => v({
							type: "pick",
							i: t
						})
					})))]
				});
				break;
			case "indianFx": {
				let t = e.hands ?? {};
				if (A.face === "blessing") {
					let e = t[_] ?? [];
					z = /* @__PURE__ */ g("div", {
						className: "flex flex-col gap-1.5",
						children: [
							/* @__PURE__ */ h("div", {
								className: "text-sm",
								children: y("games.dicetown.indianBlessingPrompt")
							}),
							/* @__PURE__ */ h("div", {
								className: "flex flex-wrap items-center gap-1.5",
								children: e.map((e, t) => M(`b${t}`, e, {
									picked: O.indianDie === t,
									onClick: () => k({ indianDie: t })
								}))
							}),
							O.indianDie != null && R(Jt.map((e) => ({
								label: x[e],
								onClick: () => v({
									type: "indianChoice",
									i: O.indianDie,
									face: e
								})
							})))
						]
					});
				} else if (A.face === "ambush") {
					let n = e.players.filter((e) => e.rid !== _);
					z = /* @__PURE__ */ g("div", {
						className: "flex flex-col gap-1.5",
						children: [
							/* @__PURE__ */ h("div", {
								className: "text-sm",
								children: y("games.dicetown.indianAmbushPrompt")
							}),
							R(n.map((e) => ({
								label: T(e.rid),
								accent: O.indianTarget === e.rid,
								onClick: () => k({
									indianTarget: e.rid,
									indianDie: null
								})
							}))),
							O.indianTarget && R((t[O.indianTarget] ?? []).map((e, t) => ({
								label: x[e],
								onClick: () => v({
									type: "indianChoice",
									target: O.indianTarget,
									i: t
								})
							})))
						]
					});
				} else z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.indianWarpathPrompt")
					}), R(qt.filter((t) => t !== "prairie" || e.cfg.cowboys).map((e) => ({
						label: y(Gt[e]),
						onClick: () => v({
							type: "indianChoice",
							loc: e
						})
					})))]
				});
				break;
			}
			case "discovery": {
				let e = t.pendingPriv?.k === "discovery" ? t.pendingPriv.drawn : [];
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.discoveryPrompt")
					}), R(e.map((e, t) => ({
						label: C(`river.${e}`),
						onClick: () => v({
							type: "pick",
							i: t
						})
					})))]
				});
				break;
			}
			case "discoveryOrder":
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.discoveryOrderPrompt")
					}), R([{
						label: C(`river.${A.a}`),
						onClick: () => v({
							type: "pick",
							i: 0
						})
					}, {
						label: C(`river.${A.b}`),
						onClick: () => v({
							type: "pick",
							i: 1
						})
					}])]
				});
				break;
			case "persuasion": {
				let e = t.pendingPriv?.k === "persuasion" ? t.pendingPriv.drawn : [];
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.persuasionPrompt")
					}), R(e.map((e, t) => ({
						label: String(e),
						onClick: () => v({
							type: "pick",
							i: t
						})
					})))]
				});
				break;
			}
			case "desperadoPick": {
				let e = t.pendingPriv?.k === "desperadoPick" ? t.pendingPriv.pile : [];
				z = /* @__PURE__ */ g("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ h("div", {
						className: "text-sm",
						children: y("games.dicetown.desperadoPrompt")
					}), R(e.map((e, t) => ({
						label: `${x[e.pair]}${x[e.pair]} $${e.reward}`,
						onClick: () => v({
							type: "pick",
							i: t
						})
					})))]
				});
				break;
			}
			default: z = null;
		}
		else {
			let t = "rid" in A ? A.rid : A.k === "giveCard" ? A.from : e.sheriff;
			z = /* @__PURE__ */ h("div", {
				className: "flex h-full items-center justify-center text-sm opacity-70",
				children: A.k === "tie" || A.k === "finalTie" ? y("games.dicetown.tiePrompt") : L(t)
			});
		}
	}
	let B = e.phase === "build" && !w.done || xe, V = e.phase === "build" ? y("games.dicetown.ui.build") : e.moment?.kind === "summary" ? y("games.dicetown.ui.roundSummary", { n: e.round }) : e.moment?.kind === "reveal" ? y("games.dicetown.ui.revealed") : e.step ? y(Gt[e.step] ?? "games.dicetown.ui.resolve") : y("games.dicetown.ui.resolve"), Oe = xe && A?.k !== "locChoice" && le !== E && b == null && !de, H = b && b in Lt ? b : null, ke = {
		mine: "games.dicetown.ui.mineInfo",
		bank: "games.dicetown.ui.bankInfo",
		store: "games.dicetown.ui.storeInfo",
		saloon: "games.dicetown.ui.saloonInfo",
		sheriff: "games.dicetown.ui.sheriffInfo",
		townhall: "games.dicetown.ui.townhallInfo",
		doc: "games.dicetown.ui.docInfo",
		prairie: "games.dicetown.ui.prairieInfo"
	}, Ae = (e, t, n) => /* @__PURE__ */ g("div", {
		className: "dt-property-card",
		children: [
			/* @__PURE__ */ h("img", {
				src: "games/dicetown/property.webp",
				alt: ""
			}),
			/* @__PURE__ */ h("strong", { children: e }),
			n && /* @__PURE__ */ h("span", { children: n })
		]
	}, t), je = (e, t) => /* @__PURE__ */ g("div", {
		className: "dt-hand-card",
		children: [
			e === "cheater" || e === "horse" ? /* @__PURE__ */ h("img", {
				src: e === "cheater" ? "games/dicetown/cheater.webp" : "games/dicetown/horse.webp",
				alt: ""
			}) : /* @__PURE__ */ h("div", {
				className: "dt-card-seal",
				"aria-hidden": !0,
				children: "✦"
			}),
			/* @__PURE__ */ h("strong", { children: C(`gs.${e}`) }),
			ce[e] != null && /* @__PURE__ */ h("span", { children: y("games.dicetown.ui.vp", { n: ce[e] }) })
		]
	}, t), Me = b?.startsWith("seat:") ? b.slice(5) : _, U = e.players.find((e) => e.rid === Me) ?? w, Ne = /* @__PURE__ */ g("div", {
		className: "dt-asset-summary",
		children: [
			/* @__PURE__ */ g("span", { children: [
				y("games.dicetown.ui.wallet"),
				" ",
				/* @__PURE__ */ g("b", { children: ["$", U.money] })
			] }),
			/* @__PURE__ */ g("span", { children: [
				y("games.dicetown.ui.gold"),
				" ",
				/* @__PURE__ */ h("b", { children: U.nuggets })
			] }),
			/* @__PURE__ */ g("span", { children: [
				y("games.dicetown.ui.cards"),
				" ",
				/* @__PURE__ */ h("b", { children: U.gs })
			] }),
			/* @__PURE__ */ g("span", { children: [
				y("games.dicetown.ui.properties"),
				" ",
				/* @__PURE__ */ h("b", { children: U.props })
			] }),
			e.cfg.cowboys && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", { children: y("games.dicetown.ui.cattle", { n: U.herd }) }), /* @__PURE__ */ g("span", { children: ["Rodeo ", /* @__PURE__ */ h("b", { children: U.rodeos })] })] }),
			e.cfg.wildwest && /* @__PURE__ */ g("span", { children: [
				y("games.dicetown.ui.ranches"),
				" ",
				/* @__PURE__ */ h("b", { children: U.ranches })
			] }),
			U.rid === e.sheriff && /* @__PURE__ */ g("span", { children: ["★ ", y("games.dicetown.sheriffTag")] }),
			U.bodyguard && /* @__PURE__ */ h("span", { children: y("games.dicetown.bodyguardTag") }),
			e.phase === "resolve" && /* @__PURE__ */ h("span", { children: U.controlled ? y("games.dicetown.controlledTag") : y("games.dicetown.ui.noGain") })
		]
	}), Pe = /* @__PURE__ */ g(m, { children: [
		Ne,
		Me === _ && /* @__PURE__ */ g("div", {
			className: "dt-hand-cards",
			children: [
				t.gs.map(je),
				t.props.map((e) => Ae(e.value, e.id)),
				t.gs.length + t.props.length === 0 && /* @__PURE__ */ h("p", { children: y("games.dicetown.ui.emptyHand") })
			]
		}),
		/* @__PURE__ */ g("div", {
			className: "dt-hand-cards",
			children: [U.protectedProps.map((e, t) => Ae(e, `protect${t}`, y("games.dicetown.ui.protected"))), U.cowed.map((e) => Ae(e.value, e.id, `${y("games.dicetown.ui.cattle", { n: e.n })} +1`))]
		}),
		/* @__PURE__ */ g("div", {
			className: "dt-public-cards",
			children: [
				U.outlaws.map((e) => /* @__PURE__ */ g("span", { children: [
					y("games.dicetown.ui.outlaw"),
					" ",
					x[e.pair],
					" ",
					x[e.pair]
				] }, e.i)),
				U.captured.map((e) => /* @__PURE__ */ g("span", { children: [
					y("games.dicetown.ui.captured"),
					" ",
					x[e.pair],
					" ",
					x[e.pair],
					" $",
					e.reward
				] }, e.i)),
				U.cowboys.map((e, t) => /* @__PURE__ */ g("span", { children: [
					y("games.dicetown.cowboyLabel"),
					" ",
					Yt[e]
				] }, t))
			]
		}),
		e.cfg.indians && /* @__PURE__ */ g("p", { children: [
			y("games.dicetown.ui.indian"),
			" · ",
			e.indian.holder ? T(e.indian.holder) : y("games.dicetown.ui.village"),
			" ",
			e.indian.armed && y("games.dicetown.ui.armed")
		] })
	] }), W = H && /* @__PURE__ */ g(m, { children: [
		Rt(e) === H && /* @__PURE__ */ h("strong", { children: y("games.dicetown.ui.sealed") }),
		/* @__PURE__ */ h("p", { children: y(ke[H]) }),
		e.cfg.wildwest && (H === "mine" || H === "bank" || H === "store" || H === "saloon" || H === "sheriff" || H === "townhall" || H === "prairie") && /* @__PURE__ */ h("p", { children: y("games.dicetown.ui.dualAction") }),
		/* @__PURE__ */ g("div", {
			className: "dt-public-cards",
			children: [
				H === "mine" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("strong", { children: [
					y("games.dicetown.ui.gold"),
					" ",
					e.mine
				] }), e.cfg.wildwest && /* @__PURE__ */ g("span", { children: [
					y("games.dicetown.ui.riverShort"),
					" ",
					e.riverDeck
				] })] }),
				H === "bank" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("strong", { children: [
					y("games.dicetown.bankLabel"),
					" $",
					e.bank
				] }), e.cfg.wildwest && /* @__PURE__ */ g("strong", { children: [
					y("games.dicetown.stageLabel"),
					" $",
					e.stage
				] })] }),
				H === "store" && /* @__PURE__ */ g(m, { children: [
					/* @__PURE__ */ g("strong", { children: [
						y("games.dicetown.ui.deck"),
						" ",
						e.gsDeck
					] }),
					/* @__PURE__ */ h("span", { children: y("games.dicetown.ui.discard", { n: e.gsDiscard.length }) }),
					e.gsDiscard.map((e, t) => /* @__PURE__ */ h("span", { children: C(`gs.${e}`) }, t))
				] }),
				H === "saloon" && e.cfg.wildwest && /* @__PURE__ */ g("strong", { children: [
					y("games.dicetown.ui.outlaw"),
					" ",
					e.outlawDeck
				] }),
				H === "sheriff" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("strong", { children: ["★ ", T(e.sheriff)] }), e.outlawWanted.map((e) => /* @__PURE__ */ g("span", { children: [
					x[e.pair],
					" ",
					x[e.pair],
					" · $",
					e.reward
				] }, e.i))] }),
				H === "townhall" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("strong", { children: [
					y("games.dicetown.ui.deck"),
					" ",
					e.propDeck
				] }), /* @__PURE__ */ h("div", {
					className: "dt-hand-cards",
					children: e.propUp.map((e) => e.ranch ? /* @__PURE__ */ h("span", { children: y("games.dicetown.ranchLabel") }, e.id) : Ae(e.value, e.id))
				})] }),
				H === "doc" && /* @__PURE__ */ g(m, { children: [e.elixUp.map((e, t) => /* @__PURE__ */ h("span", { children: C(`elix.${e}`) }, t)), /* @__PURE__ */ h("span", { children: y("games.dicetown.docPickBlind") })] }),
				H === "prairie" && /* @__PURE__ */ g(m, { children: [
					/* @__PURE__ */ h("strong", { children: y("games.dicetown.ui.cattle", { n: e.prairie }) }),
					e.cowboyUp.map((e, t) => /* @__PURE__ */ h("span", { children: Yt[e] }, t)),
					/* @__PURE__ */ g("span", { children: ["Rodeo ", e.rodeos] })
				] })
			]
		}),
		e.hands && /* @__PURE__ */ h("div", {
			className: "dt-revealed-list",
			children: e.players.map((t) => /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("strong", { children: T(t.rid) }), /* @__PURE__ */ h("span", { children: (e.hands?.[t.rid] ?? []).map((e, t) => /* @__PURE__ */ h(J, {
				face: e,
				small: !0
			}, t)) })] }, t.rid))
		})
	] }), Fe = H ? y(Gt[H]) : b === "summary" ? y("games.dicetown.ui.roundSummary", { n: e.lastRound?.round ?? e.round }) : b === "abilities" ? y("games.dicetown.ui.abilities") : b === "hands" ? y("games.dicetown.ui.revealed") : y("games.dicetown.ui.viewAssets", { name: T(Me) });
	return /* @__PURE__ */ g("div", {
		className: "dt-shell",
		children: [
			/* @__PURE__ */ h(s, {
				adaptive: !0,
				className: "dt-screen",
				scroll: !1,
				banner: /* @__PURE__ */ g("div", {
					className: "dt-top",
					children: [/* @__PURE__ */ g("div", {
						className: "dt-title-row",
						children: [
							/* @__PURE__ */ h("h1", { children: y("games.dicetown.name") }),
							/* @__PURE__ */ h("span", { children: y("games.dicetown.ui.round", { n: e.round }) }),
							/* @__PURE__ */ h("div", {
								className: "dt-phase",
								children: /* @__PURE__ */ h(l, {
									tone: B ? "accent" : "info",
									accent: he.accent,
									text: V
								})
							})
						]
					}), /* @__PURE__ */ h("div", {
						className: "dt-player-strip",
						children: e.players.map((t) => {
							let n = oe.find((e) => e.rid === t.rid);
							return n ? /* @__PURE__ */ g("button", {
								type: "button",
								className: `dt-seat ${e.moment?.kind === "winner" && e.moment.rid === t.rid ? "dt-seat-winner" : ""}`,
								onClick: () => S(`seat:${t.rid}`),
								"aria-label": y("games.dicetown.ui.viewAssets", { name: T(t.rid) }),
								style: { borderTopColor: re[n.colorIndex % re.length].hex },
								children: [
									/* @__PURE__ */ g("div", {
										className: "dt-seat-main",
										children: [/* @__PURE__ */ h(u, {
											m: n,
											myRid: _,
											action: t.done ? "done" : null,
											anchorName: `seat:${t.rid}`,
											box: "size-8",
											img: "size-7"
										}), /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h("strong", { children: T(t.rid) }), /* @__PURE__ */ g("small", { children: [
											t.done ? "✓" : `${t.kept}/5`,
											" ",
											e.phase === "build" && !t.done && y(t.rolled > 0 ? "games.dicetown.ui.choosingDice" : "games.dicetown.ui.readyRoll"),
											" ",
											t.rid === e.sheriff && "★"
										] })] })]
									}),
									/* @__PURE__ */ g("div", {
										className: "dt-seat-assets",
										children: [/* @__PURE__ */ g("span", { children: ["$", t.money] }), /* @__PURE__ */ g("span", { children: ["◆", t.nuggets] })]
									}),
									/* @__PURE__ */ g("div", {
										className: "dt-seat-assets dt-seat-secondary",
										children: [
											/* @__PURE__ */ g("span", { children: [y("games.dicetown.ui.cardsShort"), t.gs] }),
											/* @__PURE__ */ g("span", { children: [y("games.dicetown.ui.propsShort"), t.props + t.protectedProps.length + t.cowed.length] }),
											e.cfg.cowboys && /* @__PURE__ */ g("span", { children: [y("games.dicetown.ui.cattleShort"), t.herd] })
										]
									})
								]
							}, t.rid) : null;
						})
					})]
				}),
				actionsHeight: "dt-actions-slot",
				actions: /* @__PURE__ */ g("div", {
					className: "dt-action-surface",
					children: [/* @__PURE__ */ g("div", {
						ref: ye,
						className: "dt-action-scroll",
						children: [e.phase === "build" ? I : /* @__PURE__ */ h(It, {
							pub: e,
							nameOf: T,
							line: me
						}), /* @__PURE__ */ g("div", {
							className: "dt-tools",
							children: [
								/* @__PURE__ */ g("strong", {
									ref: ve,
									children: ["$", w.money]
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									disabled: !P,
									className: "dt-tool",
									onClick: () => S("abilities"),
									children: [y("games.dicetown.ui.abilities"), P && " ›"]
								}),
								/* @__PURE__ */ h("span", { className: "dt-tools-spacer" }),
								e.lastRound && /* @__PURE__ */ h("button", {
									type: "button",
									className: "dt-tool",
									onClick: () => S("summary"),
									children: y(e.lastRound.round === e.round ? "games.dicetown.ui.thisRound" : "games.dicetown.ui.lastRound")
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "dt-tool",
									onClick: () => S("hand"),
									children: [
										/* @__PURE__ */ h(ne, { size: 16 }),
										" ",
										y("games.dicetown.ui.hand"),
										" ",
										t.gs.length + t.props.length
									]
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "dt-tool",
									onClick: () => fe(!0),
									"aria-label": y("common.log.title"),
									children: [/* @__PURE__ */ h(te, { size: 14 }), /* @__PURE__ */ h("span", { children: y("games.dicetown.ui.records") })]
								})
							]
						})]
					}), /* @__PURE__ */ h("div", {
						className: "dt-action-controls",
						children: e.phase === "build" ? Ee : xe && A?.k === "locChoice" ? z : /* @__PURE__ */ g("div", {
							className: "dt-confirm-row",
							children: [/* @__PURE__ */ h("button", {
								type: "button",
								className: "dt-secondary",
								onClick: () => S("hands"),
								children: y("games.dicetown.ui.revealed")
							}), xe ? /* @__PURE__ */ h("button", {
								type: "button",
								className: "dt-primary",
								onClick: () => ue(""),
								children: y("games.dicetown.ui.choose")
							}) : /* @__PURE__ */ h("p", {
								className: "dt-action-message",
								role: "status",
								children: A && "rid" in A ? L(A.rid) : A?.k === "giveCard" ? L(A.from) : A?.k === "tie" || A?.k === "finalTie" ? y("games.dicetown.tiePrompt") : y("games.dicetown.ui.wait")
							})]
						})
					})]
				}),
				children: /* @__PURE__ */ h(Ht, {
					pub: e,
					selected: O.keep.map((e) => Ce[e]),
					sheriffName: T(e.sheriff),
					onPick: S
				})
			}),
			/* @__PURE__ */ h(f, {
				open: Oe,
				onClose: () => ue(E),
				title: V,
				label: V,
				children: /* @__PURE__ */ h("div", {
					className: "dt-pending-panel",
					children: z
				})
			}),
			/* @__PURE__ */ h(f, {
				open: b != null,
				onClose: () => S(null),
				title: Fe,
				label: Fe,
				children: H ? W : b === "summary" && e.lastRound ? /* @__PURE__ */ h(Mt, {
					summary: e.lastRound,
					players: e.players,
					nameOf: T,
					line: me
				}) : b === "abilities" ? N : b === "hands" ? W || /* @__PURE__ */ h("div", {
					className: "dt-revealed-list",
					children: e.players.map((t) => /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("strong", { children: T(t.rid) }), /* @__PURE__ */ h("span", { children: (e.hands?.[t.rid] ?? []).map((e, t) => /* @__PURE__ */ h(J, {
						face: e,
						small: !0
					}, t)) })] }, t.rid))
				}) : Pe
			}),
			de && /* @__PURE__ */ h(c, {
				log: e.log,
				line: me,
				onClose: () => fe(!1)
			})
		]
	});
}
//#endregion
//#region src/games/dicetown/bot.ts
function X(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Zt = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32, Z = typeof process < "u" ? process.env : {}, Q = {
	sims: Number(Z.DT_SIMS ?? 40),
	futCost: Number(Z.DT_FUTCOST ?? .2),
	docFloor: Number(Z.DT_DOCFLOOR ?? .9),
	badgeDef: Number(Z.DT_BADGEDEF ?? 1),
	storeScale: Number(Z.DT_STORESCALE ?? 0),
	cheatRolled: Number(Z.DT_CHEATROLLED ?? 0),
	cheatThresh: Number(Z.DT_CHEATTHRESH ?? .4),
	ply: Number(Z.DT_PLY ?? 0),
	keepNone: Number(Z.DT_KEEPNONE ?? 0),
	finish: Number(Z.DT_FINISH ?? 0),
	moneyW: Number(Z.DT_MONEYW ?? 1.1),
	tieF: Number(Z.DT_TIEF ?? .1),
	tieFSheriff: Number(Z.DT_TIEFS ?? .9)
}, Qt = {
	dynamite: 4,
	cheater: 4,
	corruption: 4,
	desperado: 4,
	gift: 3,
	swindler: 3,
	joe: 3,
	girls: 3,
	credits: 3,
	lasso: 3,
	recruitment: 3,
	persuasion: 3,
	bribe: 3,
	brute: 2,
	wanted: 2,
	evensplit: 2,
	marshall: 2,
	elixir: 2,
	insurance: 2,
	twoguns: 2,
	mule: 2,
	dog: 2,
	whiskey: 2,
	herder: 2,
	smokesignals: 1
}, $t = (e) => ce[e] ?? Qt[e] ?? 2, en = {
	gold5: 5,
	gold4: 4,
	star: 3.5,
	gold3: 3,
	money3: 2.5,
	gold2: 2,
	discovery: 2,
	coupon: 2,
	money2: 1.5,
	nothing: 0
}, tn = 2.3;
function nn(e, t) {
	switch (e) {
		case "power": return 5.3;
		case "domination": return 4;
		case "wealth": return t;
		case "charm": return t;
		case "fortune": return 2.6;
		case "friendship": return 2.4;
		case "protection": return 2;
		default: return 1.5;
	}
}
function rn(e, t) {
	let n = [...e];
	for (; n.length < 5;) {
		let e = 5 - n.length, r = [];
		for (let n = 0; n < e; n += 1) r.push(t() * 6 | 0);
		if (n.length === 0) {
			n.push(r.reduce((e, t) => t > e ? t : e, 0));
			continue;
		}
		let i = [
			0,
			0,
			0,
			0,
			0,
			0
		];
		for (let e of n) i[e] += 1;
		let a = Math.max(...i), o = new Set(i.map((e, t) => e === a ? t : -1).filter((e) => e >= 0)), s = r.filter((e) => o.has(e));
		s.length === 0 ? n.push(r.reduce((e, t) => t > e ? t : e, 0)) : n.push(...s);
	}
	return n;
}
var an = null;
function on() {
	if (an) return an;
	let e = 2654435769, t = () => (e = e * 1664525 + 1013904223 >>> 0, e / 2 ** 32), n = 4e4, r = [
		0,
		0,
		0,
		0,
		0,
		0
	], i = new Uint32Array(n);
	for (let e = 0; e < n; e += 1) {
		let n = rn([], t);
		r[n.filter((e) => e === 0).length] += 1, i[e] = sn(I(n));
	}
	let a = r.map((e) => e / n), o = [];
	for (let e = 0; e <= 5; e += 1) o.push((o[e - 1] ?? 0) + a[e]);
	return i.sort(), an = {
		cntCmf: o,
		cntPmf: a,
		ranks: i
	}, an;
}
function sn(e) {
	let t = 0;
	for (let n = 0; n < 6; n += 1) t = t * 8 + ((e[n] ?? -1) + 1);
	return t;
}
function cn(e) {
	let t = on().ranks, n = 0, r = t.length;
	for (; n < r;) {
		let i = n + r >> 1;
		t[i] < e ? n = i + 1 : r = i;
	}
	let i = n;
	for (r = t.length; n < r;) {
		let i = n + r >> 1;
		t[i] <= e ? n = i + 1 : r = i;
	}
	return {
		pBeat: (t.length - n) / t.length,
		pTie: (n - i) / t.length
	};
}
function ln(e, t, n, r, i) {
	let a = Math.max(0, 1 - e - t), o = a ** n + r * ((a + t) ** n - a ** n);
	if (!i) return [o, 0];
	let s = (1 - e) ** n + n * e * (1 - e) ** (n - 1);
	return [o, Math.max(0, s - o)];
}
function un(e) {
	let t = 0;
	for (let n of e.pub.elixUp) t = Math.max(t, nn(n, e.nOpp));
	return t > 0 ? t : 2;
}
function dn(e, t, n, r) {
	let { pub: i, me: a, priv: o } = r;
	switch (`${e}.${t}`) {
		case "mine.exploit": return Math.min(n, i.mine);
		case "mine.river": return i.riverDeck > 0 ? tn : 0;
		case "bank.rob": return i.bank / 2;
		case "bank.stage": return Math.min(n, i.stage) / 2;
		case "store.draw": return (Q.storeScale ? Math.min(4.5, 2.2 + .6 * n) : 2.6) * (i.firstRound ? 2 : 1) * (i.gsDeck > 0 ? 1 : .2);
		case "store.doc": return un(r);
		case "saloon.steal": return r.opponents.some((e) => !e.bodyguard && e.gs + e.props + e.ranches > 0) ? Q.storeScale ? 2.6 + .3 * n : 2.8 : .2;
		case "saloon.recruitOutlaw": return i.outlawDeck > 0 ? 2.2 : .1;
		case "sheriff.badge": return Q.badgeDef || i.sheriff !== a.rid ? 5.3 : .2;
		case "sheriff.chase": return i.outlawWanted.length > 0 ? Math.min(2, i.outlawWanted.length) * 1.6 : .2;
		case "townhall.normal": {
			let e = Math.min(1 + n, 3, i.propUp.length), t = 0, r = 0;
			for (let n = 0; n < e; n += 1) {
				let e = i.propUp[n];
				e.ranch ? (t += a.ranches + r + 1, r += 1) : t += e.value;
			}
			return t;
		}
		case "townhall.mayor": return i.propDeck > 0 ? 2.68 : 0;
		case "townhall.bribe": return o.gs.includes("bribe") ? Math.min(2, i.propDeck) * 2.68 : 0;
		case "prairie.steal": {
			let e = i.prairie + r.opponents.reduce((e, t) => e + t.herd, 0);
			return Math.min(n + +!!a.cowboys.includes("C"), e) * 1.1;
		}
		case "prairie.recruit": return i.cowboyUp.length > 0 ? 1.8 : .1;
		default: return 0;
	}
}
function fn(e, t, n, r) {
	let i = r.map((r) => dn(e, r, t, n)).sort((e, t) => t - e);
	return [i[0] ?? 0, i[1] ?? 0];
}
var pn = {
	mine: ["exploit", "river"],
	bank: ["rob", "stage"],
	store: ["draw", "doc"],
	saloon: ["steal", "recruitOutlaw"],
	sheriff: ["badge", "chase"],
	townhall: [
		"normal",
		"mayor",
		"bribe"
	],
	prairie: ["steal", "recruit"]
};
function mn(e, t) {
	let n = on(), r = [
		0,
		0,
		0,
		0,
		0,
		0
	];
	for (let t of e) r[t] += 1;
	let i = 0, a = 1, o = (e, t, n, r) => {
		i += e * n + t * r, a *= Math.max(0, 1 - e - t);
	};
	for (let e of [
		"mine",
		"bank",
		"store",
		"saloon",
		"sheriff"
	]) {
		let a = r[S[e]], [s, c] = ln(1 - n.cntCmf[a], n.cntPmf[a], t.nOpp, t.tieF, t.ww), [l, u] = fn(e, a, t, pn[e]);
		o(s, c, l, u), Q.badgeDef && e === "sheriff" && t.pub.sheriff === t.me.rid && (i -= (1 - s) * 5.3);
	}
	let { pBeat: s, pTie: c } = cn(sn(I(e))), [l, u] = ln(s, c, t.nOpp, t.tieF, t.ww), [d, f] = fn("townhall", r[5], t, pn.townhall);
	if (o(l, u, d, f), t.pub.cfg.cowboys) {
		let e = r[5], [i, a] = ln(1 - n.cntCmf[e], n.cntPmf[e], t.nOpp, t.tieF, t.ww), [s, c] = fn("prairie", e, t, pn.prairie);
		o(i, a, s, c);
	}
	return Q.docFloor && (i += a * un(t) * Q.docFloor), i;
}
function hn(e, t) {
	return e.length >= 5 ? mn(e.slice(0, 5), t) : mn(rn(e, Zt), t);
}
function gn(e, t) {
	let n = [...e];
	for (; n.length < 5;) {
		let e = 5 - n.length, r = [];
		for (let t = 0; t < e; t += 1) r.push(Zt() * 6 | 0);
		let i = [], a = hn(n, t) - .5;
		for (let o = 1; o < 1 << e; o += 1) {
			let s = [];
			for (let t = 0; t < e; t += 1) o & 1 << t && s.push(r[t]);
			let c = hn(n.concat(s), t);
			c > a && (a = c, i = s);
		}
		i.length === 0 && (i = [r.reduce((e, t) => t > e ? t : e, 0)]), n.push(...i);
	}
	return n;
}
function _n(e, t) {
	if (e.length >= 5) return mn(e.slice(0, 5), t);
	let n = 0;
	for (let r = 0; r < Q.sims; r += 1) n += mn(Q.ply ? gn(e, t) : rn(e, Zt), t);
	return n / Q.sims - (5 - e.length) * Q.futCost;
}
var vn = (e, t) => t ? 0 : e === 0 ? 1 : e - 1;
function yn(e, t, n, r, i) {
	let a = t.length, o = [0], s = -Infinity;
	for (let c = +!Q.keepNone; c < 1 << a; c += 1) {
		let l = [];
		for (let e = 0; e < a; e += 1) c & 1 << e && l.push(e);
		let u = vn(l.length, r);
		if (u > n) continue;
		let d = e.concat(l.map((e) => t[e])), f = _n(d, i);
		d.length >= 5 && (f += Q.finish), f -= u * Q.moneyW;
		let p = n - u;
		p < 2 && (f -= (2 - p) * .25), f > s && (s = f, o = l);
	}
	return {
		idxs: o,
		v: s
	};
}
function $(e, t) {
	let n = Math.max(0, ...t.pub.players.map((e) => e.herd));
	return e.nuggets + (e.money + e.captured.reduce((e, t) => e + t.reward, 0)) / 2 + (t.pub.sheriff === e.rid ? 5 : 0) + e.gs * 2.2 + e.props * 2.6 + e.protectedProps.reduce((e, t) => e + t, 0) + e.ranches * (e.ranches + 1) / 2 + e.rodeos * 10 + e.cowed.reduce((e, t) => e + t.value + 1, 0) + (e.herd > 0 && e.herd >= n ? 6 : 0);
}
var bn = (e, t) => {
	let n = e.public, r = e.private, i = n.players.find((e) => e.rid === t.rid);
	if (!i || !r) return null;
	let a = t.difficulty === "weak", o = n.players.filter((e) => e.rid !== t.rid), s = {
		pub: n,
		me: i,
		priv: r,
		opponents: o,
		nOpp: o.length,
		ww: n.cfg.wildwest,
		tieF: n.sheriff === t.rid ? Q.tieFSheriff : Q.tieF
	};
	if (n.phase === "build") {
		if (i.done) return null;
		let e = r.dice ?? [], t = r.rolled;
		if (t.length > 0) {
			if (a) return { action: {
				type: "keep",
				idxs: [X(t.map((e, t) => t))]
			} };
			let n = yn(e, t, i.money, r.bruteFree, s);
			if (Q.cheatRolled && r.gs.includes("cheater") && n.idxs.length < t.length) {
				let a = e.concat(n.idxs.map((e) => t[e])), o = [
					0,
					0,
					0,
					0,
					0,
					0
				];
				for (let e of a) o[e] += 1;
				let c = 5;
				for (let e = 0; e < 6; e += 1) (o[e] > o[c] || o[e] === o[c] && e > c) && (c = e);
				let l = -1, u = n.v + .8;
				for (let e = 0; e < t.length; e += 1) {
					if (n.idxs.includes(e) || t[e] === c) continue;
					let o = vn(n.idxs.length + 1, r.bruteFree) - vn(n.idxs.length, r.bruteFree);
					if (vn(n.idxs.length + 1, r.bruteFree) > i.money) continue;
					let d = _n(a.concat(c), s) - o * Q.moneyW;
					d > u && (u = d, l = e);
				}
				if (l >= 0) return { action: {
					type: "cheat",
					where: "rolled",
					i: l,
					face: c
				} };
			}
			return { action: {
				type: "keep",
				idxs: n.idxs
			} };
		}
		if (!a) {
			if (r.canOutlaw && i.outlaws.length > 0) {
				let t = -1, n = 0;
				if (i.outlaws.forEach((r, i) => {
					let a = e.filter((e) => e === r.pair).length;
					a >= 2 && r.pair + a > n && (n = r.pair + a, t = i);
				}), t >= 0) return { action: {
					type: "outlaw",
					i: t
				} };
			}
			if (r.gs.includes("cheater") && e.length >= 2 && e.length < 5) {
				let t = _n(e, s) + Q.cheatThresh, n = -1, r = 0;
				for (let i = 0; i < e.length; i += 1) for (let a = 0; a < 6; a += 1) {
					if (e[i] === a) continue;
					let o = _n(e.map((e, t) => t === i ? a : e), s);
					o > t && (t = o, n = i, r = a);
				}
				if (n >= 0) return { action: {
					type: "cheat",
					where: "kept",
					i: n,
					face: r
				} };
			}
			if (r.gs.includes("brute") && !r.bruteFree && i.money <= 2) return { action: { type: "brute" } };
		}
		return { action: { type: "roll" } };
	}
	let c = n.pending;
	if (!c) return null;
	if (c.k === "tie" || c.k === "finalTie") return n.sheriff === t.rid ? a ? { action: {
		type: "tie",
		pick: X(c.candidates)
	} } : { action: {
		type: "tie",
		pick: c.candidates.includes(t.rid) ? t.rid : [...c.candidates].sort((e, t) => {
			let r = n.players.find((t) => t.rid === e), i = n.players.find((e) => e.rid === t);
			return (r ? $(r, s) : 0) - (i ? $(i, s) : 0);
		})[0]
	} } : null;
	if (c.k === "giveCard") {
		if (c.from !== t.rid) return null;
		if (c.cardType === "gs") {
			let e = 0;
			for (let t = 1; t < r.gs.length; t += 1) $t(r.gs[t]) < $t(r.gs[e]) && (e = t);
			return { action: {
				type: "pick",
				i: a ? X(r.gs.map((e, t) => t)) : e
			} };
		}
		let e = 0;
		for (let t = 1; t < r.props.length; t += 1) r.props[t].value < r.props[e].value && (e = t);
		return { action: {
			type: "pick",
			i: a ? X(r.props.map((e, t) => t)) : e
		} };
	}
	if (!("rid" in c) || c.rid !== t.rid) return null;
	switch (c.k) {
		case "locChoice": {
			if (a) return { action: {
				type: "locChoice",
				option: X(c.options)
			} };
			let e = n.hands?.[t.rid] ?? [], r = c.loc === "townhall" ? e.filter((e) => e === 5).length : e.filter((e) => e === S[c.loc]).length, i = c.options[0], o = -Infinity;
			for (let e of c.options) {
				let t = dn(c.loc, e, r, s);
				t > o && (o = t, i = e);
			}
			return { action: {
				type: "locChoice",
				option: i
			} };
		}
		case "storePick": {
			let e = r.pendingPriv?.k === "storePick" ? r.pendingPriv.drawn : [];
			if (e.length === 0) return { action: {
				type: "pick",
				i: 0
			} };
			let t = 0;
			for (let n = 1; n < e.length; n += 1) $t(e[n]) > $t(e[t]) && (t = n);
			return { action: {
				type: "pick",
				i: a ? X(e.map((e, t) => t)) : t
			} };
		}
		case "saloonTarget": {
			let e = o.filter((e) => !e.bodyguard && e.gs + e.props + e.ranches > 0);
			return e.length === 0 ? { action: {
				type: "target",
				rid: o[0]?.rid ?? t.rid
			} } : a ? { action: {
				type: "target",
				rid: X(e).rid
			} } : { action: {
				type: "target",
				rid: [...e].sort((e, t) => $(t, s) - $(e, s))[0].rid
			} };
		}
		case "saloonPick": {
			let e = r.pendingPriv?.k === "saloonPick" ? r.pendingPriv.cards : [];
			if (e.length === 0) return { action: {
				type: "pick",
				i: 0
			} };
			let t = (e) => e.t === "gs" ? $t(e.label.slice(3)) : Number(e.label.slice(5)) || 1, n = 0;
			for (let r = 1; r < e.length; r += 1) t(e[r]) > t(e[n]) && (n = r);
			return { action: {
				type: "pick",
				i: a ? X(e.map((e, t) => t)) : n
			} };
		}
		case "docPick": {
			if (a) return { action: {
				type: "pick",
				i: X([...n.elixUp.keys(), n.elixUp.length])
			} };
			let e = -1, t = 2;
			for (let r = 0; r < n.elixUp.length; r += 1) {
				let i = nn(n.elixUp[r], s.nOpp);
				i > t && (t = i, e = r);
			}
			return { action: {
				type: "pick",
				i: e >= 0 ? e : n.elixUp.length
			} };
		}
		case "elixirVictim": {
			let e = c.elixir === "friendship" ? (e) => e.gs > 0 : (e) => e.props > 0, n = o.filter(e);
			return n.length === 0 ? { action: {
				type: "target",
				rid: o[0]?.rid ?? t.rid
			} } : a ? { action: {
				type: "target",
				rid: X(n).rid
			} } : { action: {
				type: "target",
				rid: [...n].sort((e, t) => $(t, s) - $(e, s))[0].rid
			} };
		}
		case "protectPick": return { action: {
			type: "pickMulti",
			is: r.props.map((e, t) => ({
				i: t,
				v: e.value
			})).sort((e, t) => t.v - e.v).slice(0, 2).map((e) => e.i)
		} };
		case "joeTarget": {
			let e = [...o].sort((e, t) => t.money - e.money)[0];
			return { action: {
				type: "target",
				rid: (a ? X(o) : e)?.rid ?? t.rid
			} };
		}
		case "offer": return { action: {
			type: "offer",
			accept: a ? X([!0, !1]) : !(c.card in {
				whiskey: !0,
				wanted: !0,
				twoguns: !0
			})
		} };
		case "recruitPick": {
			let e = n.cowboyUp.map((e, t) => ({
				suit: e,
				i: t
			})), t = e.filter((e) => !i.cowboys.includes(e.suit)), r = (t.length > 0 ? t : e).slice(0, c.n).map((e) => e.i);
			return { action: {
				type: "pickMulti",
				is: a ? [X(e).i] : r
			} };
		}
		case "cowPlace": {
			let e = Math.max(0, ...o.map((e) => e.herd)), t = i.herd, n = [];
			for (let i of [...r.props].sort((e, t) => t.value - e.value)) i.value > t || t > e && t - i.value <= e || (n.push({
				id: i.id,
				n: i.value
			}), t -= i.value);
			return { action: {
				type: "cowPlace",
				place: n
			} };
		}
		case "indianOffer": return a ? { action: {
			type: "offer",
			accept: X([!0, !1])
		} } : { action: {
			type: "offer",
			accept: Math.min(...r.props.map((e) => e.value), 99) <= 2
		} };
		case "indianGive": {
			let e = r.pendingPriv?.k === "indianGive" ? r.pendingPriv.props : [];
			if (e.length === 0) return { action: {
				type: "pick",
				i: 0
			} };
			let t = 0;
			for (let n = 1; n < e.length; n += 1) e[n].value < e[t].value && (t = n);
			return { action: {
				type: "pick",
				i: t
			} };
		}
		case "coupon": {
			let e = 0;
			for (let t = 1; t < n.gsDiscard.length; t += 1) $t(n.gsDiscard[t]) > $t(n.gsDiscard[e]) && (e = t);
			return { action: {
				type: "pick",
				i: a ? X(n.gsDiscard.map((e, t) => t)) : e
			} };
		}
		case "indianFx": {
			let e = n.hands ?? {};
			if (c.face === "blessing") {
				let n = e[t.rid] ?? [], r = [
					0,
					0,
					0,
					0,
					0,
					0
				];
				for (let e of n) r[e] += 1;
				let i = 5;
				for (let e = 0; e < 6; e += 1) (r[e] > r[i] || r[e] === r[i] && e > i) && (i = e);
				let a = n.findIndex((e) => e !== i);
				return { action: {
					type: "indianChoice",
					i: a >= 0 ? a : 0,
					face: i
				} };
			}
			if (c.face === "ambush") {
				let t = o.filter((t) => (e[t.rid] ?? []).length > 0), n = [...t.length > 0 ? t : o].sort((e, t) => $(t, s) - $(e, s))[0];
				if (!n) return { action: { type: "indianChoice" } };
				let r = e[n.rid] ?? [], i = [
					0,
					0,
					0,
					0,
					0,
					0
				];
				for (let e of r) i[e] += 1;
				let a = 5;
				for (let e = 0; e < 6; e += 1) (i[e] > i[a] || i[e] === i[a] && e > a) && (a = e);
				return { action: {
					type: "indianChoice",
					target: n.rid,
					i: Math.max(0, r.indexOf(a))
				} };
			}
			if (c.face === "warpath") {
				let t = [
					"mine",
					"bank",
					"store",
					"saloon",
					"sheriff",
					"townhall"
				], n = e[[...o].sort((e, t) => $(t, s) - $(e, s))[0]?.rid ?? ""] ?? [], r = [
					0,
					0,
					0,
					0,
					0,
					0
				];
				for (let e of n) r[e] += 1;
				let i = 5;
				for (let e = 0; e < 6; e += 1) r[e] > r[i] && (i = e);
				return { action: {
					type: "indianChoice",
					loc: n.length > 0 && i !== 0 ? t[i] : "townhall"
				} };
			}
			return { action: { type: "indianChoice" } };
		}
		case "discovery": {
			let e = r.pendingPriv?.k === "discovery" ? r.pendingPriv.drawn : [];
			if (e.length === 0) return { action: {
				type: "pick",
				i: 0
			} };
			let t = 0;
			for (let n = 1; n < e.length; n += 1) (en[e[n]] ?? 0) > (en[e[t]] ?? 0) && (t = n);
			return { action: {
				type: "pick",
				i: a ? X(e.map((e, t) => t)) : t
			} };
		}
		case "discoveryOrder": {
			let e = (en[c.a] ?? 0) <= (en[c.b] ?? 0) ? 0 : 1;
			return { action: {
				type: "pick",
				i: a ? X([0, 1]) : e
			} };
		}
		case "persuasion": {
			let e = r.pendingPriv?.k === "persuasion" ? r.pendingPriv.drawn : [];
			if (e.length === 0) return { action: {
				type: "pick",
				i: 0
			} };
			let t = 0;
			for (let n = 1; n < e.length; n += 1) e[n] > e[t] && (t = n);
			return { action: {
				type: "pick",
				i: t
			} };
		}
		case "desperadoPick": {
			let e = r.pendingPriv?.k === "desperadoPick" ? r.pendingPriv.pile : [];
			if (e.length === 0) return { action: {
				type: "pick",
				i: 0
			} };
			let t = 0;
			for (let n = 1; n < e.length; n += 1) e[n].reward > e[t].reward && (t = n);
			return { action: {
				type: "pick",
				i: t
			} };
		}
		case "smokeSignals": return { action: {
			type: "offer",
			accept: a ? X([!0, !1]) : n.indian.holder !== t.rid
		} };
		default: return null;
	}
};
//#endregion
//#region src/games/dicetown/fx.tsx
function xn({ at: e, face: t, i }) {
	let a = r(null);
	return n(() => {
		let e = a.current;
		if (!e) return;
		let t = i % 2 ? -1 : 1, n = e.animate([
			{
				transform: `perspective(220px) translate(${t * 18}px,-32px) rotateX(150deg) rotateZ(${t * 135}deg) scale(.72)`,
				opacity: 0
			},
			{
				transform: `perspective(220px) translate(${-t * 9}px,-17px) rotateX(-65deg) rotateZ(${-t * 40}deg) scale(1.06)`,
				opacity: 1,
				offset: .4
			},
			{
				transform: `perspective(220px) translate(0px,3px) rotateX(15deg) rotateZ(${t * 9}deg) scale(.97)`,
				offset: .72
			},
			{ transform: "perspective(220px) translate(0px,0px) rotateX(0deg) rotateZ(0deg) scale(1)" }
		], {
			duration: j.roll,
			easing: "cubic-bezier(.15,.75,.3,1)",
			fill: "both"
		}), r = e.querySelector(".dt-die-glyph")?.animate([
			{ opacity: 0 },
			{
				opacity: 0,
				offset: .62
			},
			{ opacity: 1 }
		], {
			duration: j.roll,
			fill: "both"
		}), o = [...e.querySelectorAll(".dt-tumble-face")].map((e, t) => e.animate([
			{ opacity: 0 },
			{
				opacity: 0,
				offset: t * .18
			},
			{
				opacity: 1,
				offset: t * .18 + .02
			},
			{
				opacity: 1,
				offset: t * .18 + .15
			},
			{
				opacity: 0,
				offset: t * .18 + .17
			},
			{ opacity: 0 }
		], {
			duration: j.roll,
			fill: "both"
		}));
		return () => {
			n.cancel(), r?.cancel(), o.forEach((e) => e.cancel());
		};
	}, [i]), /* @__PURE__ */ g("div", {
		ref: a,
		className: "dt-fx-die",
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: [/* @__PURE__ */ h(J, {
			face: t,
			empty: t == null
		}), t != null && [
			0,
			3,
			4
		].map((e, t) => /* @__PURE__ */ h("span", {
			className: "dt-tumble-face",
			children: /* @__PURE__ */ h(At, { face: e })
		}, t))]
	});
}
function Sn() {
	return /* @__PURE__ */ g("svg", {
		className: "dt-gold-token",
		viewBox: "0 0 32 26",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ h("path", {
				d: "M4 7L13 2L25 5L30 17L20 24L5 20L1 12Z",
				fill: "#c59b42",
				stroke: "#4d3b22",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ h("path", {
				d: "M5 7L13 3L18 10L4 12ZM20 7L26 8L28 15L18 18Z",
				fill: "#f1d186"
			}),
			/* @__PURE__ */ h("path", {
				d: "M5 20L17 17L20 24",
				fill: "#886333"
			})
		]
	});
}
function Cn({ asset: e, n: t, label: n }) {
	let r = o();
	if (e === "gold") return /* @__PURE__ */ h(Sn, {});
	if (e === "money") return /* @__PURE__ */ g("span", {
		className: "dt-cash-token",
		children: ["$", t]
	});
	if (e === "badge") return /* @__PURE__ */ h("span", {
		className: "dt-badge-token",
		children: "★"
	});
	if (e === "indian") return /* @__PURE__ */ h("span", {
		className: "dt-indian-token",
		children: "◆"
	});
	if (e === "cattle") return /* @__PURE__ */ g("span", {
		className: "dt-cattle-token",
		children: ["🐂", /* @__PURE__ */ h("b", { children: t })]
	});
	let i = n ? Y[n] ? r(Y[n]) : n.startsWith("prop.") ? n.slice(5) : n === "ranch" ? "⌂" : n : "";
	return /* @__PURE__ */ g("span", {
		className: `dt-flying-card ${n ? "" : "dt-flying-back"}`,
		children: [n === "gs.horse" || n === "gs.cheater" ? /* @__PURE__ */ h("img", {
			src: n === "gs.horse" ? "games/dicetown/horse.webp" : "games/dicetown/cheater.webp",
			alt: ""
		}) : /* @__PURE__ */ h("b", { children: n ? e === "property" ? "⌂" : e === "elixir" ? "⚗" : e === "outlaw" ? "✦" : e === "rodeo" ? "10" : "✧" : "✧" }), n && /* @__PURE__ */ h("strong", { children: i })]
	});
}
function wn(e) {
	return e === "gold" ? {
		w: 28,
		h: 24
	} : e === "money" ? {
		w: 42,
		h: 24
	} : e === "badge" ? {
		w: 36,
		h: 36
	} : e === "indian" ? {
		w: 30,
		h: 30
	} : e === "cattle" ? {
		w: 48,
		h: 32
	} : {
		w: 40,
		h: 54
	};
}
function Tn({ scale: e, asset: t, n, label: r }) {
	let i = wn(t);
	return /* @__PURE__ */ h("span", {
		style: {
			display: "block",
			width: i.w * e,
			height: i.h * e
		},
		children: /* @__PURE__ */ h("span", {
			style: {
				display: "block",
				width: i.w,
				height: i.h,
				transform: `scale(${e})`,
				transformOrigin: "top left"
			},
			children: /* @__PURE__ */ h(Cn, {
				asset: t,
				n,
				label: r
			})
		})
	});
}
var En = {
	roll(e, t) {
		let n = e.data, r = e.secret;
		if (!r || e.rid !== t.myRid) {
			let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
			return n ? {
				ms: j.roll,
				node: /* @__PURE__ */ h(xn, {
					at: {
						...n,
						w: 28,
						h: 32
					},
					i: 0
				})
			} : null;
		}
		let i = [], a = r.faces.map((r, a) => {
			let o = n.revealed ? `reveal:${e.rid}:${n.kept + a}` : `rolled:${a}`, s = t.anchor(o);
			return s ? (i.push(o), /* @__PURE__ */ h(xn, {
				at: s,
				face: r,
				i: a
			}, a)) : null;
		});
		return i.length ? {
			ms: j.roll,
			node: a,
			hide: i
		} : null;
	},
	keep(e, t) {
		let n = e.data, r = e.secret, i = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		if (!r || e.rid !== t.myRid) return i ? {
			ms: j.keep,
			node: /* @__PURE__ */ h(v, {
				at: i,
				ms: j.keep
			})
		} : null;
		if (!(t.anchor("dice-area") ?? t.anchor("showdown"))) return null;
		let a = [], o = r.faces.map((i, o) => {
			let s = n.revealed ? `reveal:${e.rid}:${n.kept + o}` : `kept:${n.kept + o}`, c = t.anchor(s), l = t.anchor(`keep-origin:${n.kept}:${r.idxs[o]}`);
			return !l || !c ? null : (a.push(s), /* @__PURE__ */ h(_, {
				from: l,
				to: c,
				ms: j.keep,
				children: /* @__PURE__ */ h(J, {
					face: i,
					width: l.w,
					height: l.h
				})
			}, o));
		}), s = t.anchor("wallet"), c = t.anchor("stage");
		return n.cost > 0 && s && c && o.push(/* @__PURE__ */ h(_, {
			from: {
				...s,
				w: 42,
				h: 24
			},
			to: c,
			ms: j.keep,
			children: /* @__PURE__ */ g("span", {
				className: "dt-cash-token",
				children: ["$", n.cost]
			})
		}, "fee")), o.some(Boolean) ? {
			ms: j.keep,
			node: o,
			hide: a
		} : i ? {
			ms: j.keep,
			node: /* @__PURE__ */ h(v, {
				at: i,
				ms: j.keep
			})
		} : null;
	},
	moment(e, t) {
		let n = e.data, r = n.kind === "winner" && n.rid ? t.anchor(`seat:${n.rid}`) : n.kind === "reveal" || n.kind === "summary" || n.kind === "result" ? t.anchor("showdown") : t.anchor(`lot:${n.loc}`) ?? t.anchor("showdown"), i = [], a = n.rolls.flatMap((e, n) => e.faces.map((e, r) => {
			let a = `result-die:${n}:${r}`, o = t.anchor(a);
			return o ? (i.push(a), /* @__PURE__ */ h(xn, {
				at: o,
				face: e,
				i: r
			}, a)) : null;
		}));
		return r ? {
			ms: a.length ? j.roll : j.keep,
			node: /* @__PURE__ */ g(m, { children: [!a.length && /* @__PURE__ */ h(v, {
				at: r,
				ms: j.keep
			}), a] }),
			hide: i
		} : null;
	},
	transfer(e, t) {
		let n = e.data, r = e.secret, i = t.anchor(n.from), a = t.anchor(n.to);
		if (!i || !a) return null;
		let o = r?.card ?? n.label, s = n.asset === "gold" ? Math.min(n.n, 6) : 1, c = t.anchor(`seat:${t.myRid}`), l = c ? Math.max(1, Math.min(2, Math.min(c.w, c.h) / 32)) : 1, u = wn(n.asset), d = u.w * l, f = u.h * l, p = (e, t, r = 0) => ({
			x: e.x + e.w / 2 - d / 2 + r * 3 * l + (t === "showdown" ? (n.slot - (n.slots - 1) / 2) * (d + 3 * l) : 0),
			y: e.y + e.h / 2 - f / 2,
			w: d,
			h: f
		});
		return {
			ms: j.result,
			node: /* @__PURE__ */ g(m, { children: [Array.from({ length: s }, (e, t) => /* @__PURE__ */ h(_, {
				from: p(i, n.from, t),
				to: p(a, n.to),
				ms: j.result * .7,
				delay: t * j.result * .035,
				children: /* @__PURE__ */ h(Tn, {
					scale: l,
					asset: n.asset,
					n: n.n,
					label: o
				})
			}, t)), n.to.startsWith("seat:") && (n.asset === "money" || n.asset === "gold" || n.asset === "cattle") && /* @__PURE__ */ g(oe, {
				at: a,
				ms: j.result,
				children: [
					"+",
					n.asset === "money" ? "$" : "",
					n.n,
					n.asset === "gold" ? " ◆" : n.asset === "cattle" ? " 🐂" : ""
				]
			})] })
		};
	}
};
//#endregion
//#region src/games/dicetown/game-over.tsx
function Dn({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ h("div", {
		className: "dt-game-over",
		children: /* @__PURE__ */ h(y, {
			hintCount: e,
			result: t,
			members: n,
			myRid: r,
			accent: he.accent,
			onPlayAgain: i,
			onBackToLobby: a
		})
	});
}
//#endregion
//#region src/games/dicetown/options.tsx
function On({ value: e, onChange: t }) {
	let n = o(), r = Te.safeParse(e), i = r.success ? r.data : Te.parse(void 0);
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-2",
		children: [
			/* @__PURE__ */ h(b, {
				title: n("games.dicetown.optWildwest"),
				children: [!0, !1].map((e) => /* @__PURE__ */ h(se, {
					name: "dicetown-ww",
					value: String(e),
					checked: i.wildwest === e,
					label: n(e ? "games.dicetown.optOn" : "games.dicetown.optOff"),
					accent: he.accent,
					onChange: () => t({
						...i,
						wildwest: e,
						indians: e ? i.indians : !1
					})
				}, String(e)))
			}),
			i.wildwest && /* @__PURE__ */ h(b, {
				title: n("games.dicetown.optIndiansTitle"),
				children: [!0, !1].map((e) => /* @__PURE__ */ h(se, {
					name: "dicetown-ind",
					value: String(e),
					checked: i.indians === e,
					label: n(e ? "games.dicetown.optOn" : "games.dicetown.optOff"),
					accent: he.accent,
					onChange: () => t({
						...i,
						indians: e
					})
				}, String(e)))
			}),
			/* @__PURE__ */ h(b, {
				title: n("games.dicetown.optCowboysTitle"),
				children: [!0, !1].map((e) => /* @__PURE__ */ h(se, {
					name: "dicetown-cow",
					value: String(e),
					checked: i.cowboys === e,
					label: n(e ? "games.dicetown.optOn" : "games.dicetown.optOff"),
					accent: he.accent,
					onChange: () => t({
						...i,
						cowboys: e
					})
				}, String(e)))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/dicetown/entry.tsx
var kn = {
	definition: Ot,
	View: Ut,
	bot: bn,
	fx: En,
	OverView: Dn,
	Options: On,
	locales: {
		zh: {
			name: "骰子镇",
			desc: "扑克骰抢地盘,金矿银行杂货店,谁的面子大谁说了算",
			rules: "游戏目标：\n游戏结束时，将每名玩家的金块、现金、装备卡和地产等资产换算成分数，总分最高的玩家获胜。\n\n游戏准备：\n· 每名玩家领取5颗扑克骰和8美元。每颗骰子有9、10、J、Q、K、A六种点数。\n· 在金矿放置30块金块，在银行放置3美元。\n· 从地产牌堆翻开3张牌，并从灵药牌堆翻开2张牌，正面朝上展示。随机选择一名玩家担任警长。\n\n组牌阶段：\n所有玩家同时掷骰，通过保留骰子组成各自的5骰牌型。\n· 每次掷骰后，通常至少保留1颗骰子。保留1颗不付费；如果多保留骰子，每多保留1颗就支付1美元。\n· 玩家也可以支付1美元，不保留本次掷出的任何骰子，然后重新掷骰。\n· 当一名玩家保留的骰子达到5颗时，其他尚未完成组牌的玩家各进行最后一次掷骰，并保留所有剩余骰子。\n\n结算阶段：\n所有玩家亮出骰子后，依照以下顺序结算各个地点。地点的胜者由对应骰子的数量或牌型决定，平手时由警长裁决。\n· 金矿：拥有最多9点骰子的玩家，每有1颗9点骰子就获得1块金块。\n· 银行：拥有最多10点骰子的玩家，获得银行中的全部存款。\n· 杂货店：拥有最多J点骰子的玩家，抽取与其J点骰子数量相等的杂货店卡，并保留其中1张。在第一轮，该玩家执行两次这一行动。\n· 沙龙：拥有最多Q点骰子的玩家，从一名对手的卡牌中随机抽取与其Q点骰子数量相等的卡牌，并保留其中1张，将其余卡牌交还。\n· 警长：拥有最多K点骰子的玩家接任警长，之后由新警长裁决平手。\n· 市政厅：牌型最大的玩家领取1张正面朝上的地产牌；每有1颗A点骰子，再多领取1张，但一次合计至多领取3张。\n\n比较牌型时，由大到小依次为五条、四条、葫芦、顺子、三条、两对、一对。含A点的顺子大于不含A点的顺子。\n\n各地点结算后，本轮没有获得任何收获的玩家拜访庸医。该玩家可以选择1张正面朝上的灵药牌，或者从灵药牌堆随机抽取1张牌，并立即结算其效果。\n\n游戏结束与计分：\n当金矿中的金块耗尽，或地产牌全部发完时，完成当前轮次后结束游戏。各项资产按以下方式计分。\n· 每块金块获得1分。\n· 每2美元获得1分。\n· 担任警长的玩家获得5分。\n· 装备卡和地产牌按牌面标示的分值计分。\n如果总分相同，持有地产牌较多的玩家获胜；如果仍然相同，由警长裁定胜者。\n\n扩展规则：\n以下扩展需要在开局选项中开启。\n· Wild West：每个地点提供两个行动。第一名选择并执行其中一个行动，第二名执行剩下的行动。该扩展还加入河流卡、逃犯、牧场及新卡牌，并将人数上限提高到6人。\n· Cowboys：该扩展加入草原地点。拥有最多A点骰子的玩家可以选择偷取牛只或招募牛仔。不同花色的牛仔提供不同增益；集齐4种花色后，可以将其换成1张价值10分的Rodeo卡。\n· 印第安骰：该扩展需要同时开启Wild West。市政厅的胜者可以归还1张刚获得的地产牌，以换取印第安骰。持有者在下一轮金矿结算前掷出这颗骰子，并结算对应效果。",
			loc: {
				mine: "金矿",
				bank: "银行",
				store: "杂货店",
				saloon: "沙龙",
				sheriff: "警长",
				townhall: "市政厅",
				prairie: "草原",
				doc: "庸医",
				indianOffer: "印第安献礼",
				roundEnd: "回合结束"
			},
			gs: {
				horse: "骏马",
				wagon: "篷车",
				holster: "枪套",
				hat: "牛仔帽",
				slingshot: "弹弓",
				boots: "靴子",
				dynamite: "炸药",
				girls: "姑娘们",
				brute: "壮汉",
				cheater: "职业老千",
				credits: "无限赊账",
				joe: "紧张乔",
				marshall: "老警长",
				evensplit: "见者有份",
				wanted: "通缉令",
				corruption: "贪腐",
				elixir: "灵药门路",
				cattle: "牛群",
				winchester: "温彻斯特",
				mule: "骡子",
				dog: "猎犬",
				insurance: "保险",
				desperado: "亡命徒",
				gift: "礼物",
				twoguns: "双枪",
				whiskey: "威士忌",
				swindler: "骗子",
				smokesignals: "狼烟信号",
				lasso: "套索",
				herder: "牧工",
				recruitment: "招募令",
				persuasion: "游说",
				bribe: "贿赂"
			},
			elix: {
				wealth: "财富灵药",
				charm: "魅力灵药",
				fortune: "幸运灵药",
				power: "权力灵药",
				protection: "保护灵药",
				friendship: "友谊灵药",
				domination: "支配灵药"
			},
			river: {
				gold2: "2 块金块",
				gold3: "3 块金块",
				gold4: "4 块金块",
				gold5: "5 块金块",
				money2: "$2",
				money3: "$3",
				star: "警长之星",
				coupon: "礼券",
				discovery: "大发现",
				nothing: "一无所获"
			},
			indian: {
				blessing: "萨满祝福",
				ambush: "伏击",
				bodyguard: "保镖",
				warpath: "征战"
			},
			logRound: "—— 第 {{n}} 轮 ——",
			logResolve: "亮骰!开始结算",
			logMine: "{{who}} 从金矿采得 {{n}} 块金块",
			logBank: "{{who}} 抢走了银行的 ${{n}}",
			logStage: "{{who}} 从驿站马车拿走 ${{n}}",
			logStore: "{{who}} 在杂货店抽了 {{n}} 张卡",
			logNoControl: "{{loc}}无人控制",
			logSheriff: "{{who}} 接任警长",
			logSaloon: "{{who}} 偷看 {{from}} 的 {{n}} 张牌并留下 1 张",
			logStealFail: "{{who}} 没能从 {{from}} 处偷到东西",
			logRecruitOutlaw: "{{who}} 招募了一名逃犯",
			logCapture: "{{who}} 捕获逃犯,赏金 ${{reward}}",
			logChase: "{{who}} 追捕逃犯,捕获 {{n}} 名",
			logTownhall: "{{who}} 在市政厅领走 {{n}} 张地产",
			logMayor: "{{who}} 从地产堆拿走 {{n}} 张",
			logCorruption: "{{who}} 暗中多拿了一张地产",
			logPersuasion: "{{who}} 游说镇长,多挑了一张地产",
			logPrairieSteal: "{{who}} 的牛群现有 {{n}} 头牛",
			logRecruitCowboy: "{{who}} 招募了牛仔 {{suit}}",
			logRodeo: "{{who}} 集齐四花色牛仔,换来 Rodeo 卡",
			logCowPlace: "{{who}} 把牛赶上了地产",
			logDoc: "{{who}} 在庸医处用了{{elixir}}",
			logDocPlan: "{{who}} 打算拜访庸医",
			logProtect: "{{who}} 的地产受到保护",
			logGive: "{{from}} 给了 {{to}} 一张牌",
			logJoe: "{{who}} 从 {{from}} 处要来 ${{n}}",
			logSwindler: "{{who}} 向每人收取 $2",
			logEvensplit: "{{who}} 分走赃款 ${{n}}",
			logWanted: "{{who}} 亮出通缉令,取消了{{card}}",
			logPlay: "{{who}} 打出{{card}}",
			logUseOutlaw: "{{who}} 动用了逃犯",
			logHerder: "{{who}} 的牧工看住了牛群",
			logInsurance: "{{who}} 获得保险赔偿",
			logRiver: "{{who}} 在河边淘到{{card}}",
			logIndianFx: "{{who}} 掷出印第安骰:{{face}}",
			logIndianGive: "{{who}} 把一张地产还给了印第安人",
			logIndianBack: "印第安骰回到了村里",
			logWarpath: "{{loc}}本回合被战火封锁",
			logWin: "{{who}} 赢得胜利",
			logChoice: "{{who}} 选择{{action}}",
			logStoreKeep: "{{who}} 留下 1 张卡，弃掉 {{n}} 张",
			logTarget: "{{who}} 对 {{from}} 出手",
			logTie: "{{who}} 裁定{{loc}}由 {{to}} 胜出",
			logDecline: "{{who}} 放弃了这次机会",
			logConfirm: "{{who}} 完成选择",
			logBlessing: "{{who}} 改变了一颗骰子",
			logAmbush: "{{who}} 让 {{from}} 重掷一颗骰子",
			logWarpathSet: "{{who}} 封锁了{{loc}}",
			logStageBank: "马车上的 ${{n}} 转入银行",
			logSheriffKeep: "{{who}} 继续担任警长",
			rank: {
				high: "散牌",
				pair: "一对",
				twoPair: "两对",
				three: "三条",
				straight: "顺子",
				full: "葫芦",
				four: "四条",
				five: "五条"
			},
			phaseBuild: "组牌阶段:掷骰并留骰,凑出你的 5 骰牌型",
			phaseResolve: "结算阶段",
			roll: "掷骰",
			keepSel: "留下所选",
			keepNone: "全弃($1)",
			keepCost: "留 {{n}} 颗,付 ${{c}}",
			keepFree: "免费留骰",
			useBrute: "壮汉:本次留骰免费",
			useCheat: "老千:改一颗骰",
			useOutlaw: "动用逃犯",
			waitBuild: "等待其他玩家组牌…",
			buildDone: "已组满,等待其他人",
			closingHint: "有人组满了!这是你的最后一掷,骰子将全部保留",
			graceHint: "逃犯已出手!再掷一次后必须全部保留",
			waiting: "等待 {{name}}…",
			tiePrompt: "平手!等待警长裁定",
			tiePromptMe: "平手!你是警长,裁定谁能胜出",
			locChoicePrompt: "选择行动",
			storePickPrompt: "留下 1 张,其余弃掉",
			saloonTargetPrompt: "选择要偷的对手",
			saloonPickPrompt: "留下 1 张,其余还回",
			docPickPrompt: "选 1 张明置灵药,或盲抽堆顶",
			docPickBlind: "盲抽",
			protectPickPrompt: "选至多 2 张地产加以保护",
			joeTargetPrompt: "指定一名玩家给你 $4",
			giveCardPrompt: "选 1 张交给对方",
			recruitPickPrompt: "招募 {{n}} 名牛仔",
			cowPlacePrompt: "把牛赶上地产(数量须恰等于面值)",
			cowPlaceSkip: "不放牛",
			indianOfferPrompt: "把一张新得地产还给印第安人,换印第安骰?",
			indianGivePrompt: "选 1 张还给印第安人",
			indianBlessingPrompt: "萨满祝福:选自己一颗骰,改成任意面",
			indianAmbushPrompt: "伏击:选对手的一颗骰重掷",
			indianWarpathPrompt: "征战:选一个地点,本回合封锁",
			discoveryPrompt: "大发现:留 1 张,其余放回",
			discoveryOrderPrompt: "哪一张放回堆顶?",
			persuasionPrompt: "选 1 张留下,其余移出游戏",
			desperadoPrompt: "任选一名逃犯招募",
			couponPrompt: "从弃牌堆选 1 张收回",
			smokeSignalsPrompt: "打出狼烟信号,拿取印第安骰?",
			offerPrompt: "要打出{{card}}吗?",
			finalTiePrompt: "完全平局!警长裁定胜者",
			accept: "打出",
			decline: "放弃",
			ch: {
				mine: {
					exploit: "开采金块",
					river: "河边淘金"
				},
				bank: {
					rob: "抢银行",
					stage: "劫马车"
				},
				store: {
					draw: "抽卡",
					doc: "拜访庸医"
				},
				saloon: {
					steal: "偷牌",
					recruitOutlaw: "招募逃犯"
				},
				sheriff: {
					badge: "当警长",
					chase: "追捕逃犯"
				},
				townhall: {
					normal: "领取地产",
					mayor: "贿赂市长夫人",
					bribe: "打出贿赂:拿堆顶 2 张"
				},
				prairie: {
					steal: "偷牛",
					recruit: "招募牛仔"
				}
			},
			bankLabel: "银行",
			stageLabel: "马车",
			mineLabel: "金矿",
			prairieLabel: "草原",
			propsLabel: "地产",
			elixLabel: "灵药",
			wantedLabel: "通缉",
			cowboyLabel: "牛仔",
			myHand: "我的手牌",
			myDice: "我的骰子",
			ranchLabel: "牧场",
			sheriffTag: "警长",
			bodyguardTag: "保镖",
			controlledTag: "已有收获",
			optWildwest: "Wild West 扩展(双行动/河流/逃犯/牧场,6 人)",
			optIndiansTitle: "印第安骰(需 Wild West)",
			optCowboysTitle: "Cowboys 扩展",
			optOn: "开启",
			optOff: "关闭",
			ui: {
				roundSummary: "第 {{n}} 轮收获",
				lastRound: "上轮",
				thisRound: "本轮",
				netChange: "本轮净变化（含留骰费用、获得与失去的资产）",
				sheriffChange: "{{from}} → {{to}} 接任警长",
				sheriffDecision: "警长裁定",
				pickTarget: "选择一名对手",
				cardsFrom: "来自 {{name}} 的 {{n}} 张牌",
				comparing: "{{loc}} · 比拼",
				locationWinner: "{{name}}胜出",
				payout: "收益结算",
				actionAt: "{{loc}} · 行动",
				firstPlace: "第一名",
				secondPlace: "第二名",
				unclaimed: "无人控制",
				closingBy: "{{name}}已组满 · 最后一掷",
				readyRoll: "待掷骰",
				choosingDice: "留骰中",
				sealed: "本轮封锁",
				lastRoll: "最后一掷 · 全部保留",
				keepNoneFree: "全弃 · 免费",
				cardsShort: "牌",
				propsShort: "地",
				cattleShort: "牛",
				riverLine1: "河",
				riverLine2: "流",
				elixWealth: "财富",
				elixCharm: "魅力",
				elixFortune: "幸运",
				elixPower: "权力",
				elixProtection: "保护",
				elixFriendship: "友谊",
				elixDomination: "支配",
				dualAction: "第一名选一个行动，第二名执行剩下的行动。",
				town: "城镇版图",
				round: "第 {{n}} 轮",
				build: "掷骰 · 留骰",
				resolve: "结算",
				kept: "已留 {{n}}/5",
				rolled: "本次掷出",
				abilities: "能力",
				hand: "手牌",
				records: "记录",
				emptyDie: "待掷骰子",
				lockedDie: "已留骰 {{face}}",
				selectDie: "选择骰子 {{face}}",
				poker: "牌型",
				noGain: "无收获",
				riverShort: "河流",
				deck: "牌堆",
				discard: "弃牌 {{n}}",
				outlaw: "逃犯",
				cattle: "牛 {{n}}",
				choose: "继续选择",
				revealed: "全员亮骰",
				free: "免费",
				emptyHand: "暂无手牌",
				gold: "金块",
				cards: "杂货店牌",
				properties: "地产",
				wallet: "钱包",
				protected: "受保护地产",
				cowed: "已放牛地产",
				captured: "已捕获",
				ranches: "牧场",
				indian: "印第安骰",
				village: "村落",
				armed: "将在下轮掷出",
				viewAssets: "查看 {{name}} 的资产",
				selectCheat: "先选一颗骰子",
				vp: "{{n}} 分",
				confirmed: "确认",
				wait: "等待结算",
				mineInfo: "9 最多者：每颗 9 获得 1 块金块。",
				bankInfo: "10 最多者：拿走银行全部存款。",
				storeInfo: "J 最多者：抽 J 张，留下 1 张。第一轮执行两次。",
				saloonInfo: "Q 最多者：选对手，抽 Q 张牌，留下 1 张。",
				sheriffInfo: "K 最多者：接任警长。警长裁定所有平手，终局得 5 分。",
				townhallInfo: "最佳牌型领取明置地产；基础版每颗 A 追加 1 张，至多 3 张。",
				docInfo: "本轮无收获者：选 1 张明置灵药，或盲抽 1 张。",
				prairieInfo: "A 最多者：偷牛或招募牛仔。四种花色换取 Rodeo。"
			},
			errBadAction: "现在不能这么做",
			errNeedKeep: "每次掷骰后必须先留骰(或付 $1 全弃)",
			errNoMoney: "钱不够付留骰费"
		},
		en: {
			name: "Dice Town",
			desc: "Poker dice stake claims on the mine, bank and store — highest rollers take all",
			rules: "Goal:\nAt the end of the game, convert each player's nuggets, cash, gear and Properties into points. The player with the highest total wins.\n\nSetup:\n· Each player receives 5 poker dice and $8. Each die has the faces 9, 10, J, Q, K and A.\n· Place 30 nuggets in the Gold Mine and $3 in the Bank.\n· Reveal 3 Property cards and 2 Elixir cards face up. Randomly choose one player to be the Sheriff.\n\nBuilding a hand:\nAll players roll simultaneously and keep dice to form their own five-dice hands.\n· After each roll, a player normally keeps at least 1 die. Keeping 1 die is free; each additional die kept from that roll costs $1.\n· A player may instead pay $1 to keep none of the dice from that roll and roll again.\n· When a player has kept all 5 dice, every player who has not finished their hand makes one final roll and keeps all remaining dice.\n\nResolving locations:\nOnce everyone reveals their dice, resolve the following locations in order. The relevant dice count or poker hand determines each winner. The Sheriff decides ties.\n· Gold Mine: the player with the most 9s gains 1 nugget for each 9.\n· Bank: the player with the most 10s takes all cash in the Bank.\n· General Store: the player with the most Js draws that many General Store cards and keeps 1. In the first round, that player performs this action twice.\n· Saloon: the player with the most Qs randomly draws that many cards from one opponent, keeps 1, and returns the others.\n· Sheriff: the player with the most Ks becomes the new Sheriff and decides subsequent ties.\n· Town Hall: the player with the best poker hand takes 1 face-up Property card, plus 1 additional card for each Ace, up to 3 cards in total.\n\nPoker hands rank from highest to lowest as follows: five of a kind, four of a kind, full house, straight, three of a kind, two pairs and one pair. A straight containing an Ace beats a straight without an Ace.\n\nAfter resolving the locations, each player who gained nothing during the round visits Doc Badluck. That player chooses 1 face-up Elixir or draws 1 Elixir blindly from the deck and immediately resolves its effect.\n\nEnding and scoring:\nIf the Gold Mine runs out of nuggets or all Property cards have been distributed, finish the current round and end the game. Score assets as follows.\n· Each nugget is worth 1 point.\n· Each $2 is worth 1 point.\n· The Sheriff gains 5 points.\n· Gear and Property cards score their printed values.\nIf players tie on points, the tied player with more Property cards wins. If the tie remains, the Sheriff decides the winner.\n\nExpansions:\nEnable the following expansions through the game options before starting.\n· Wild West: each location offers two actions. The winner chooses and performs one action, and the runner-up performs the other. This expansion also adds River cards, Outlaws, Ranches and new cards, and increases the maximum player count to 6.\n· Cowboys: this expansion adds the Prairie. The player with the most Aces chooses whether to steal cattle or recruit cowboys. Different cowboy suits provide different bonuses. A player who collects all four suits may exchange them for a Rodeo card worth 10 points.\n· Indian Die: this expansion requires Wild West. The Town Hall winner may return 1 newly gained Property to receive the Indian Die. Its holder rolls it before the Gold Mine is resolved in the next round and applies the corresponding effect.",
			loc: {
				mine: "Gold Mine",
				bank: "Bank",
				store: "General Store",
				saloon: "Saloon",
				sheriff: "Sheriff",
				townhall: "Town Hall",
				prairie: "Prairie",
				doc: "Doc Badluck",
				indianOffer: "Indian Offering",
				roundEnd: "Round End"
			},
			gs: {
				horse: "Horse",
				wagon: "Covered Wagon",
				holster: "Holster",
				hat: "Cowboy Hat",
				slingshot: "Slingshot",
				boots: "Boots",
				dynamite: "Dynamite",
				girls: "The Girls",
				brute: "The Brute",
				cheater: "Professional Cheater",
				credits: "Unlimited Credits",
				joe: "Nervous Joe",
				marshall: "Marshall",
				evensplit: "Even Split",
				wanted: "Wanted",
				corruption: "Corruption",
				elixir: "Elixir Hookup",
				cattle: "Cattle",
				winchester: "Winchester",
				mule: "Mule",
				dog: "The Dog",
				insurance: "Insurance",
				desperado: "Desperado",
				gift: "Gift",
				twoguns: "Two Guns",
				whiskey: "Whiskey",
				swindler: "Swindler",
				smokesignals: "Smoke Signals",
				lasso: "Lasso",
				herder: "Cattle Herder",
				recruitment: "Recruitment",
				persuasion: "Persuasion",
				bribe: "Bribe"
			},
			elix: {
				wealth: "Elixir of Wealth",
				charm: "Elixir of Charm",
				fortune: "Elixir of Fortune",
				power: "Elixir of Power",
				protection: "Elixir of Protection",
				friendship: "Elixir of Friendship",
				domination: "Elixir of Domination"
			},
			river: {
				gold2: "2 nuggets",
				gold3: "3 nuggets",
				gold4: "4 nuggets",
				gold5: "5 nuggets",
				money2: "$2",
				money3: "$3",
				star: "Sheriff's Star",
				coupon: "Coupon",
				discovery: "Discovery",
				nothing: "Nothing"
			},
			indian: {
				blessing: "Shaman's Blessing",
				ambush: "Ambush",
				bodyguard: "Bodyguard",
				warpath: "Warpath"
			},
			logRound: "—— Round {{n}} ——",
			logResolve: "Dice revealed! Resolving",
			logMine: "{{who}} mined {{n}} nuggets",
			logBank: "{{who}} robbed the bank for ${{n}}",
			logStage: "{{who}} took ${{n}} from the stagecoach",
			logStore: "{{who}} drew {{n}} cards at the store",
			logNoControl: "Nobody controlled {{loc}}",
			logSheriff: "{{who}} became Sheriff",
			logSaloon: "{{who}} peeked at {{n}} cards of {{from}} and kept 1",
			logStealFail: "{{who}} failed to steal from {{from}}",
			logRecruitOutlaw: "{{who}} recruited an outlaw",
			logCapture: "{{who}} captured an outlaw for ${{reward}}",
			logChase: "{{who}} chased outlaws, caught {{n}}",
			logTownhall: "{{who}} claimed {{n}} Properties at Town Hall",
			logMayor: "{{who}} took {{n}} Properties from the deck",
			logCorruption: "{{who}} secretly took an extra Property",
			logPersuasion: "{{who}} persuaded the mayor for an extra Property",
			logPrairieSteal: "{{who}} now herds {{n}} cattle",
			logRecruitCowboy: "{{who}} hired cowboy {{suit}}",
			logRodeo: "{{who}} collected all four suits for a Rodeo card",
			logCowPlace: "{{who}} placed cattle on a Property",
			logDoc: "{{who}} used {{elixir}} at Doc Badluck",
			logDocPlan: "{{who}} plans to visit Doc Badluck",
			logProtect: "{{who}}'s Properties are protected",
			logGive: "{{from}} gave a card to {{to}}",
			logJoe: "{{who}} took ${{n}} from {{from}}",
			logSwindler: "{{who}} collected $2 from everyone",
			logEvensplit: "{{who}} split the loot for ${{n}}",
			logWanted: "{{who}} cancelled {{card}} with a Wanted order",
			logPlay: "{{who}} played {{card}}",
			logUseOutlaw: "{{who}} used an outlaw",
			logHerder: "{{who}}'s herder guards the herd",
			logInsurance: "{{who}} got an insurance payout",
			logRiver: "{{who}} panned {{card}} from the river",
			logIndianFx: "{{who}} rolled the Indian die: {{face}}",
			logIndianGive: "{{who}} returned a Property to the Indians",
			logIndianBack: "The Indian die returned to the village",
			logWarpath: "{{loc}} is blocked by the warpath this round",
			logWin: "{{who}} wins",
			logChoice: "{{who}} chooses {{action}}",
			logStoreKeep: "{{who}} keeps 1 card, discards {{n}}",
			logTarget: "{{who}} targets {{from}}",
			logTie: "{{who}} awards {{loc}} to {{to}}",
			logDecline: "{{who}} passes",
			logConfirm: "{{who}} finishes choosing",
			logBlessing: "{{who}} changes one die",
			logAmbush: "{{who}} makes {{from}} reroll one die",
			logWarpathSet: "{{who}} blocks {{loc}}",
			logStageBank: "${{n}} moves from the stagecoach to the bank",
			logSheriffKeep: "{{who}} keeps the Sheriff badge",
			rank: {
				high: "High",
				pair: "Pair",
				twoPair: "2 pair",
				three: "3 kind",
				straight: "Straight",
				full: "Full",
				four: "4 kind",
				five: "5 kind"
			},
			phaseBuild: "Build phase: roll and keep dice to form your 5-dice hand",
			phaseResolve: "Resolution phase",
			roll: "Roll",
			keepSel: "Keep selected",
			keepNone: "Keep none ($1)",
			keepCost: "Keep {{n}}, pay ${{c}}",
			keepFree: "Keep for free",
			useBrute: "Brute: keep for free",
			useCheat: "Cheater: flip a die",
			useOutlaw: "Use outlaw",
			waitBuild: "Waiting for others to build…",
			buildDone: "Hand locked, waiting",
			closingHint: "Someone locked a hand! This is your last roll — all dice stay",
			graceHint: "An outlaw was used! After one more roll you must keep all",
			waiting: "Waiting for {{name}}…",
			tiePrompt: "Tie! Waiting for the Sheriff to decide",
			tiePromptMe: "Tie! As Sheriff, you decide the winner",
			locChoicePrompt: "Choose an action",
			storePickPrompt: "Keep 1 card, discard the rest",
			saloonTargetPrompt: "Choose a rival to steal from",
			saloonPickPrompt: "Keep 1 card, return the rest",
			docPickPrompt: "Pick a faceup elixir, or draw blind",
			docPickBlind: "Draw blind",
			protectPickPrompt: "Protect up to 2 Properties",
			joeTargetPrompt: "Pick a player to give you $4",
			giveCardPrompt: "Give 1 card to them",
			recruitPickPrompt: "Hire {{n}} cowboys",
			cowPlacePrompt: "Place cattle on Properties (must equal the value exactly)",
			cowPlaceSkip: "Skip",
			indianOfferPrompt: "Return a newly gained Property for the Indian die?",
			indianGivePrompt: "Pick 1 to return to the Indians",
			indianBlessingPrompt: "Shaman's Blessing: flip one of your dice to any face",
			indianAmbushPrompt: "Ambush: pick a rival's die to reroll",
			indianWarpathPrompt: "Warpath: pick a location to block this round",
			discoveryPrompt: "Discovery: keep 1, return the rest",
			discoveryOrderPrompt: "Which one goes back on top?",
			persuasionPrompt: "Keep 1, the rest leave the game",
			desperadoPrompt: "Recruit any outlaw",
			couponPrompt: "Take 1 card from the discard pile",
			smokeSignalsPrompt: "Play Smoke Signals to take the Indian die?",
			offerPrompt: "Play {{card}}?",
			finalTiePrompt: "Dead tie! The Sheriff decides the winner",
			accept: "Play",
			decline: "Pass",
			ch: {
				mine: {
					exploit: "Mine nuggets",
					river: "Pan the river"
				},
				bank: {
					rob: "Rob the bank",
					stage: "Rob the stagecoach"
				},
				store: {
					draw: "Draw cards",
					doc: "Visit Doc Badluck"
				},
				saloon: {
					steal: "Steal cards",
					recruitOutlaw: "Recruit outlaw"
				},
				sheriff: {
					badge: "Take the badge",
					chase: "Chase outlaws"
				},
				townhall: {
					normal: "Claim Property",
					mayor: "Bribe the mayor's wife",
					bribe: "Play Bribe: take top 2"
				},
				prairie: {
					steal: "Steal cattle",
					recruit: "Hire cowboy"
				}
			},
			bankLabel: "Bank",
			stageLabel: "Stage",
			mineLabel: "Mine",
			prairieLabel: "Prairie",
			propsLabel: "Properties",
			elixLabel: "Elixirs",
			wantedLabel: "Wanted",
			cowboyLabel: "Cowboys",
			myHand: "My hand",
			myDice: "My dice",
			ranchLabel: "Ranch",
			sheriffTag: "Sheriff",
			bodyguardTag: "Bodyguard",
			controlledTag: "Gained",
			optWildwest: "Wild West (dual actions/river/outlaws/ranches, 6p)",
			optIndiansTitle: "Indian Die (needs Wild West)",
			optCowboysTitle: "Cowboys (prairie/cowboys/Rodeo)",
			optOn: "On",
			optOff: "Off",
			ui: {
				roundSummary: "Round {{n}} haul",
				lastRound: "Last round",
				thisRound: "This round",
				netChange: "Net change this round, including dice fees, gains and losses.",
				sheriffChange: "{{from}} → {{to}} becomes Sheriff",
				sheriffDecision: "Sheriff decides",
				pickTarget: "Choose an opponent",
				cardsFrom: "{{n}} cards from {{name}}",
				comparing: "{{loc}} · Compare",
				locationWinner: "{{name}} wins",
				payout: "Rewards",
				actionAt: "{{loc}} · Action",
				firstPlace: "First",
				secondPlace: "Second",
				unclaimed: "Unclaimed",
				closingBy: "{{name}} finished · Last roll",
				readyRoll: "To roll",
				choosingDice: "Choosing",
				sealed: "Blocked this round",
				lastRoll: "Last roll · keep all",
				keepNoneFree: "Keep none · free",
				cardsShort: "C",
				propsShort: "P",
				cattleShort: "Cow",
				riverLine1: "River",
				riverLine2: "",
				elixWealth: "Wealth",
				elixCharm: "Charm",
				elixFortune: "Fortune",
				elixPower: "Power",
				elixProtection: "Protect",
				elixFriendship: "Friend",
				elixDomination: "Control",
				dualAction: "The winner chooses one action; the runner-up takes the other.",
				town: "Town board",
				round: "Round {{n}}",
				build: "Roll · Keep",
				resolve: "Resolve",
				kept: "Kept {{n}}/5",
				rolled: "This roll",
				abilities: "Abilities",
				hand: "Hand",
				records: "Log",
				emptyDie: "Die to roll",
				lockedDie: "Kept die {{face}}",
				selectDie: "Select die {{face}}",
				poker: "Poker",
				noGain: "No gain",
				riverShort: "River",
				deck: "Deck",
				discard: "Discard {{n}}",
				outlaw: "Outlaw",
				cattle: "Cows {{n}}",
				choose: "Choose",
				revealed: "Revealed dice",
				free: "Free",
				emptyHand: "No cards yet",
				gold: "Nuggets",
				cards: "Store cards",
				properties: "Properties",
				wallet: "Cash",
				protected: "Protected property",
				cowed: "Property with cattle",
				captured: "Captured",
				ranches: "Ranches",
				indian: "Indian die",
				village: "Village",
				armed: "Rolls next round",
				viewAssets: "View assets of {{name}}",
				selectCheat: "Choose a die first",
				vp: "{{n}} points",
				confirmed: "Confirm",
				wait: "Awaiting resolution",
				mineInfo: "Most 9s: gain one nugget per 9.",
				bankInfo: "Most 10s: take all cash from the bank.",
				storeInfo: "Most Js: draw J cards and keep one. Twice in round one.",
				saloonInfo: "Most Qs: draw Q cards from one rival and keep one.",
				sheriffInfo: "Most Ks: become Sheriff. Settle all ties and score 5 points at game end.",
				townhallInfo: "Best poker hand takes a faceup Property. In the base game, each Ace adds one, up to three total.",
				docInfo: "No gains this round: take one faceup Elixir or draw blind.",
				prairieInfo: "Most Aces: steal cattle or recruit cowboys. All four suits earn a Rodeo."
			},
			errBadAction: "Not allowed right now",
			errNeedKeep: "You must keep dice after each roll (or pay $1 to keep none)",
			errNoMoney: "Not enough money to keep dice"
		}
	}
};
//#endregion
export { kn as default };
