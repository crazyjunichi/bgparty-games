import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useT as n } from "@bgparty/sdk/i18n";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { PhaseBanner as i } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as a } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { useState as s } from "react";
import { jsx as c, jsxs as l } from "react/jsx-runtime";
import { Floater as u, FlySprite as d } from "@bgparty/sdk/fx/primitives";
import { Confetti as f } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as p, OptionSection as m } from "@bgparty/sdk/ui/game-options";
//#region src/games/qe/data.ts
var h = [
	"agri",
	"housing",
	"fin",
	"manuf",
	"gov"
], g = [
	"gold",
	"oil",
	"crypto"
], _ = [
	[
		"fin",
		2,
		3,
		4,
		1
	],
	[
		"agri",
		4,
		1,
		2,
		3
	],
	[
		"housing",
		1,
		2,
		3,
		4
	],
	[
		"manuf",
		3,
		4,
		1,
		2
	]
], v = [
	["fin", {
		US: 2,
		UK: 4,
		EU: 3
	}],
	["agri", {
		US: 4,
		UK: 3,
		CN: 2
	}],
	["housing", {
		EU: 2,
		CN: 3,
		JP: 4
	}],
	["manuf", {
		US: 3,
		EU: 4,
		JP: 2
	}],
	["gov", {
		UK: 2,
		CN: 4,
		JP: 3
	}]
];
function y(e) {
	let t = [];
	if (e >= 5) for (let [e, n] of v) for (let [r, i] of Object.entries(n)) t.push({
		id: `${r}-${e}`,
		nation: r,
		industry: e,
		vp: i
	});
	else {
		let e = [
			"US",
			"EU",
			"CN",
			"JP"
		];
		for (let [n, ...r] of _) e.forEach((e, i) => t.push({
			id: `${e}-${n}`,
			nation: e,
			industry: n,
			vp: r[i]
		}));
	}
	return t;
}
function b(e) {
	return e >= 5 ? [...h] : [
		"agri",
		"housing",
		"fin",
		"manuf"
	];
}
function x(e) {
	return {
		gold: [
			7,
			7,
			7,
			6,
			6,
			6
		],
		oil: [
			5,
			5,
			5,
			4,
			4,
			4
		],
		crypto: e >= 5 ? [
			10,
			8,
			5,
			2,
			0
		] : [
			10,
			8,
			8,
			5,
			2,
			0
		]
	};
}
var S = {
	small: [
		0,
		1,
		3,
		6,
		10
	],
	five: [
		0,
		3,
		6,
		10
	]
}, ee = {
	small: [
		0,
		0,
		3,
		6,
		10
	],
	five: [
		0,
		0,
		6,
		10,
		16
	]
}, te = {
	small: {
		3: 4,
		4: 8
	},
	five: {
		3: 8,
		4: 12,
		5: 17
	}
}, C = {
	small: 6,
	five: 7
}, w = {
	id: "qe",
	tier: "alpha",
	mechanics: ["auction", "set-collection"],
	interactionTags: [],
	nameKey: "games.qe.name",
	descKey: "games.qe.desc",
	rulesKey: "games.qe.rules",
	icon: "💸",
	iconImg: "games/qe.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/qe/en.pdf" },
	minPlayers: 3,
	maxPlayers: 5,
	bestPlayers: [5],
	accent: "#b45309",
	releasedAt: "2026-09-16",
	search: {
		py: "liang hua kuan song",
		init: "lhks"
	},
	hotseat: "cover"
}, T = t.string(), E = 999999999999, D = t.enum([
	"US",
	"EU",
	"CN",
	"JP",
	"UK"
]), O = t.enum([
	"agri",
	"housing",
	"fin",
	"manuf",
	"gov"
]), k = t.enum([
	"gold",
	"oil",
	"crypto"
]), A = t.object({
	id: t.string(),
	nation: D,
	industry: O,
	vp: t.int()
}), ne = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("openBid"),
		amount: t.int().min(1).max(E)
	}),
	t.object({
		type: t.literal("bid"),
		amount: t.int().min(0).max(E)
	}),
	t.object({
		type: t.literal("choosePile"),
		pile: k
	}),
	t.object({
		type: t.literal("discardPile"),
		pile: k
	}),
	t.object({
		type: t.literal("peek"),
		auction: t.int().min(0)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), j = t.object({ commodities: t.boolean().default(!1) }).default({ commodities: !1 }), re = t.object({
	tile: A,
	auctioneer: T.nullable(),
	opening: t.int().nullable(),
	winner: T.nullable(),
	winBid: t.int().nullable(),
	second: T.nullable(),
	pile: k.nullable(),
	zeroBidders: t.array(T),
	flowOut: t.boolean()
}), ie = t.object({
	rid: T,
	tilesVp: t.int(),
	zeroVp: t.int(),
	natVp: t.int(),
	monVp: t.int(),
	divVp: t.int(),
	commVp: t.int(),
	oilBonus: t.int(),
	goldPenalty: t.int(),
	leastBonus: t.int(),
	subtotal: t.int(),
	total: t.int(),
	spent: t.int(),
	eliminated: t.boolean()
}), ae = t.object({
	phase: t.enum([
		"open",
		"bid",
		"choose",
		"discard",
		"reveal",
		"done"
	]),
	commodities: t.boolean(),
	auctionNo: t.int().min(1),
	totalAuctions: t.int().min(1),
	auctioneer: T.nullable(),
	tile: A.nullable(),
	deckLeft: t.int().nonnegative(),
	opening: t.int().nullable(),
	awaiting: t.array(T),
	tied: t.array(T),
	rebidFor: t.enum(["company", "commodity"]).nullable(),
	players: t.array(t.object({
		rid: T,
		nation: D,
		tiles: t.array(A),
		commodities: t.array(k),
		peekUsed: t.boolean()
	})),
	piles: t.record(k, t.int().nonnegative()),
	goldCrash: t.boolean(),
	history: t.array(re),
	final: t.array(ie).nullable()
}), oe = t.object({
	token: O,
	myTiles: t.array(t.object({
		tile: A,
		paid: t.int()
	})),
	myCommodities: t.array(t.object({
		pile: k,
		value: t.int(),
		paid: t.int()
	})),
	saleCredit: t.int(),
	myBid: t.int().nullable(),
	peekResults: t.record(t.string(), t.int()),
	auctioneerBids: t.record(t.string(), t.record(T, t.int()))
});
//#endregion
//#region src/games/qe/score.ts
function M(e) {
	let t = e.playerCount >= 5, n = t ? S.five : S.small, r = t ? ee.five : ee.small, i = t ? te.five : te.small, a = e.tiles.reduce((e, t) => e + t.vp, 0), o = e.tiles.filter((t) => t.nation === e.nation).length, s = n[Math.min(o, n.length - 1)], c = /* @__PURE__ */ new Map();
	for (let e of h) c.set(e, 0);
	for (let t of e.tiles) c.set(t.industry, (c.get(t.industry) ?? 0) + 1);
	c.set(e.token, (c.get(e.token) ?? 0) + 1);
	let l = 0;
	for (let e of c.values()) l += r[Math.min(e, r.length - 1)];
	let u = 0, d = Math.max(...c.values());
	for (let e = 0; e < d; e += 1) {
		let t = 0;
		for (let n of c.values()) n > e && (t += 1);
		u += i[t] ?? 0;
	}
	let f = 0, p = 0;
	for (let t of e.commodities) f += t.value, t.pile === "gold" && (p += 1);
	let m = e.commoditiesOn && e.goldLeft === 0 ? -3 * p : 0, g = e.commoditiesOn && e.myOil > 0 && e.myOil === e.maxOil ? Math.floor(5 / e.oilTied) : 0;
	return {
		tilesVp: a,
		zeroVp: e.zeroVp,
		natVp: s,
		monVp: l,
		divVp: u,
		commVp: f,
		oilBonus: g,
		goldPenalty: m,
		subtotal: a + e.zeroVp + s + l + u + f + g + m
	};
}
function se(e) {
	return e >= 5 ? C.five : C.small;
}
//#endregion
//#region src/games/qe/rules.ts
var ce = {
	resolve: 1200,
	reveal: 2800
}, le = 2;
function N(e) {
	return e.noAuctioneer ? null : e.players[(e.firstAuctioneer + e.auctionIndex) % e.players.length];
}
function P(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.rngSeed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function F(e) {
	let t = e.deck[0];
	return e.deck = e.deck.slice(1), e.tile = t, e.opening = null, e.bids = {}, e.tied = [], e.rebidFor = null, e.tieCount = 0, e.winner = null, e.winBid = null, e.second = null, e.secondBid = null, e.noAuctioneer = e.players.length === 3 && e.auctionIndex === e.totalAuctions - 1, e.noAuctioneer ? (e.phase = "bid", e.awaiting = [...e.players]) : (e.phase = "open", e.awaiting = [N(e)]), [{
		kind: "tile",
		data: { tile: t }
	}];
}
function ue(t, n, r) {
	let i = n.length, a = {
		players: n,
		commodities: t.commodities,
		nations: {},
		tokens: {},
		deck: [],
		totalAuctions: 0,
		firstAuctioneer: 0,
		auctionIndex: 0,
		tile: null,
		phase: "open",
		opening: null,
		bids: {},
		awaiting: [],
		tied: [],
		rebidFor: null,
		tieCount: 0,
		winner: null,
		winBid: null,
		second: null,
		secondBid: null,
		noAuctioneer: !1,
		won: {},
		comm: {},
		saleCredit: {},
		zeroMarks: {},
		peeks: {},
		piles: {
			gold: [],
			oil: [],
			crypto: []
		},
		history: [],
		rngSeed: r,
		rngCursor: 0
	};
	a.deck = P(a, y(i));
	let o = P(a, i >= 5 ? [
		"US",
		"EU",
		"CN",
		"JP",
		"UK"
	] : [
		"US",
		"EU",
		"CN",
		"JP"
	]), s = P(a, b(i));
	if (n.forEach((e, t) => {
		a.nations[e] = o[t], a.tokens[e] = s[t], a.won[e] = [], a.comm[e] = [], a.saleCredit[e] = 0, a.zeroMarks[e] = [], a.peeks[e] = [];
	}), a.commodities) {
		let e = x(i);
		a.piles = {
			gold: P(a, e.gold),
			oil: P(a, e.oil),
			crypto: P(a, e.crypto)
		};
	}
	return a.totalAuctions = a.deck.length, a.firstAuctioneer = e(r, a.rngCursor, i), a.rngCursor += 1, {
		state: a,
		fx: F(a)
	};
}
function I(e, t) {
	if (e.commodities || e.players.length <= 3) return;
	let n = Math.floor(e.auctionIndex / e.players.length);
	for (let r of t) e.zeroMarks[r].includes(n) || e.zeroMarks[r].push(n);
}
function de(e) {
	return Object.entries(e.bids).filter(([, e]) => e === 0).map(([e]) => e);
}
function fe(e, t, n) {
	e.winner = t, e.winBid = n, e.won[t].push({
		tile: e.tile,
		paid: n
	});
	let r = de(e);
	return I(e, r), e.history.push({
		tile: e.tile,
		auctioneer: N(e),
		opening: e.opening,
		bids: { ...e.bids },
		winner: t,
		winBid: n,
		second: null,
		secondBid: null,
		pile: null,
		commodityValue: null,
		zeroBidders: e.commodities || e.players.length <= 3 ? [] : r,
		flowOut: !1
	}), [{
		kind: "award",
		rid: t,
		data: {
			tile: e.tile,
			zeroBidders: r
		}
	}];
}
function pe(e) {
	return I(e, de(e)), e.history.push({
		tile: e.tile,
		auctioneer: N(e),
		opening: e.opening,
		bids: { ...e.bids },
		winner: null,
		winBid: null,
		second: null,
		secondBid: null,
		pile: null,
		commodityValue: null,
		zeroBidders: [],
		flowOut: !0
	}), [{
		kind: "flow",
		data: { tile: e.tile }
	}];
}
function L(e, t) {
	let n = -1;
	for (let r of t) n = Math.max(n, e.bids[r]);
	let r = t.filter((t) => e.bids[t] === n);
	if (r.length === 1) return r[0];
	if (e.tieCount >= le) {
		let n = /* @__PURE__ */ new Map();
		for (let r of t) n.set(e.bids[r], (n.get(e.bids[r]) ?? 0) + 1);
		let r = -1;
		for (let [e, t] of n) t === 1 && e > r && (r = e);
		return r < 0 ? null : t.find((t) => e.bids[t] === r) ?? null;
	}
	return e.tieCount += 1, e.tied = r, "rebid";
}
function me(e) {
	if (e.rebidFor === null) {
		let t = L(e, Object.keys(e.bids));
		if (t === "rebid") return e.awaiting = [...e.tied], [{
			kind: "tie",
			data: {
				rids: e.tied,
				for: "company"
			}
		}];
		if (t === null) return e.phase = "reveal", pe(e);
		let n = fe(e, t, e.bids[t]);
		return e.commodities ? he(e, n) : (e.phase = "reveal", n);
	}
	let t = e.players.filter((t) => t !== e.winner), n = L(e, t);
	return n === "rebid" ? (e.awaiting = [...t], [{
		kind: "tie",
		data: {
			rids: e.tied,
			for: "commodity"
		}
	}]) : n === null ? (e.phase = "discard", e.awaiting = [N(e)], []) : (e.second = n, e.secondBid = e.bids[n], R(e) ? (z(e, n, e.secondBid), e.phase = "reveal", []) : (e.phase = "choose", e.awaiting = [n], []));
}
function he(e, t) {
	e.rebidFor = "commodity", e.tieCount = 0, e.tied = [];
	let n = e.players.filter((t) => t !== e.winner);
	if (e.noAuctioneer) {
		let r = n.map((t) => e.bids[t]), i = Math.max(...r), a = n.filter((t) => e.bids[t] === i);
		return a.length === 1 && !R(e) ? (e.second = a[0], e.secondBid = i, e.phase = "choose", e.awaiting = [a[0]]) : (z(e, a.length === 1 ? a[0] : null, a.length === 1 ? i : null), e.phase = "reveal"), t;
	}
	let r = L(e, n);
	return r === "rebid" ? (e.awaiting = n, e.phase = "bid", [...t, {
		kind: "tie",
		data: {
			rids: e.tied,
			for: "commodity"
		}
	}]) : r === null || R(e) ? (z(e, r, r === null ? null : e.bids[r]), e.phase = "reveal", t) : (e.second = r, e.secondBid = e.bids[r], e.phase = "choose", e.awaiting = [r], t);
}
function R(e) {
	return e.piles.gold.length + e.piles.oil.length + e.piles.crypto.length === 0;
}
function z(e, t, n, r, i) {
	let a = e.history[e.history.length - 1];
	a.second = t, a.secondBid = n, a.pile = r ?? null, a.commodityValue = i ?? null, e.rebidFor = null, e.tied = [], e.tieCount = 0;
}
function ge(e, t, n) {
	if (t.type === "tick") {
		if (e.phase === "bid" && e.awaiting.length === 0) {
			let t = structuredClone(e);
			return {
				state: t,
				fx: me(t)
			};
		}
		if (e.phase === "reveal") {
			let t = structuredClone(e);
			return t.auctionIndex += 1, t.auctionIndex >= t.totalAuctions ? (t.phase = "done", {
				state: t,
				fx: []
			}) : {
				state: t,
				fx: F(t)
			};
		}
		return {
			state: e,
			fx: []
		};
	}
	if (t.type === "openBid") {
		if (e.phase !== "open" || n.by !== N(e)) return { code: "games.qe.errNotOpen" };
		let r = structuredClone(e);
		return r.opening = t.amount, r.phase = "bid", r.awaiting = r.players.filter((e) => e !== n.by), {
			state: r,
			fx: []
		};
	}
	if (t.type === "bid") {
		if (e.phase !== "bid" || !e.awaiting.includes(n.by)) return { code: "games.qe.errNotBidder" };
		if (e.opening !== null && n.by !== N(e) && t.amount === e.opening) return { code: "games.qe.errSameAsOpening" };
		let r = structuredClone(e);
		return r.bids[n.by] = t.amount, r.awaiting = r.awaiting.filter((e) => e !== n.by), {
			state: r,
			fx: []
		};
	}
	if (t.type === "choosePile") {
		if (e.phase !== "choose" || n.by !== e.second) return { code: "games.qe.errNotChooser" };
		if (e.piles[t.pile].length === 0) return { code: "games.qe.errPileEmpty" };
		let r = structuredClone(e), i = r.piles[t.pile].pop(), a = r.secondBid ?? 0;
		r.comm[n.by].push({
			pile: t.pile,
			value: i,
			paid: a
		});
		let o = N(r);
		return o !== null && o !== n.by && (r.saleCredit[o] += a), z(r, n.by, a, t.pile, i), r.phase = "reveal", {
			state: r,
			fx: [{
				kind: "commodity",
				rid: n.by,
				data: { pile: t.pile },
				for: [n.by],
				secret: { value: i }
			}]
		};
	}
	if (t.type === "discardPile") {
		if (e.phase !== "discard" || n.by !== N(e)) return { code: "games.qe.errNotDiscarder" };
		if (e.piles[t.pile].length === 0) return { code: "games.qe.errPileEmpty" };
		let r = structuredClone(e);
		return r.piles[t.pile].pop(), z(r, null, null), r.phase = "reveal", {
			state: r,
			fx: [{
				kind: "discard",
				data: { pile: t.pile }
			}]
		};
	}
	if (t.type === "peek") {
		if (e.players.length < 5) return { code: "games.qe.errNoPeek" };
		if (e.peeks[n.by]?.length) return { code: "games.qe.errPeekUsed" };
		let r = e.history[t.auction];
		if (!r || r.winBid === null) return { code: "games.qe.errNoPeek" };
		let i = structuredClone(e);
		return i.peeks[n.by].push(t.auction), {
			state: i,
			fx: []
		};
	}
	return { code: "games.qe.errBadPhase" };
}
function _e(e, t) {
	let n = N(e), r = e.players.length >= 5, i = e.phase === "done" ? B(e) : null;
	return {
		public: {
			phase: e.phase,
			commodities: e.commodities,
			auctionNo: Math.min(e.auctionIndex + 1, e.totalAuctions),
			totalAuctions: e.totalAuctions,
			auctioneer: n,
			tile: e.phase === "done" ? null : e.tile,
			deckLeft: e.deck.length,
			opening: e.opening,
			awaiting: [...e.awaiting],
			tied: [...e.tied],
			rebidFor: e.rebidFor,
			players: e.players.map((t) => ({
				rid: t,
				nation: e.nations[t],
				tiles: e.won[t].map((e) => e.tile),
				commodities: e.comm[t].map((e) => e.pile),
				peekUsed: (e.peeks[t]?.length ?? 0) > 0
			})),
			piles: {
				gold: e.piles.gold.length,
				oil: e.piles.oil.length,
				crypto: e.piles.crypto.length
			},
			goldCrash: e.commodities && e.piles.gold.length === 0,
			history: e.history.map((e) => ({
				tile: e.tile,
				auctioneer: e.auctioneer,
				opening: e.opening,
				winner: e.winner,
				winBid: e.winner !== null && e.winner === e.auctioneer ? e.winBid : null,
				second: e.second,
				pile: e.pile,
				zeroBidders: e.zeroBidders,
				flowOut: e.flowOut
			})),
			final: i ? i.entries : null
		},
		private: {
			token: e.tokens[t],
			myTiles: structuredClone(e.won[t] ?? []),
			myCommodities: structuredClone(e.comm[t] ?? []),
			saleCredit: e.saleCredit[t] ?? 0,
			myBid: e.bids[t] ?? null,
			peekResults: r ? Object.fromEntries((e.peeks[t] ?? []).map((t) => [String(t), e.history[t].winBid])) : {},
			auctioneerBids: Object.fromEntries(e.history.flatMap((e, n) => e.auctioneer === t ? [[String(n), { ...e.bids }]] : []))
		}
	};
}
function B(e) {
	let t = e.players.map((t) => e.comm[t].filter((e) => e.pile === "oil").length), n = Math.max(0, ...t), r = t.filter((e) => e === n && e > 0).length, i = e.players.map((i, a) => {
		let o = M({
			playerCount: e.players.length,
			commoditiesOn: e.commodities,
			nation: e.nations[i],
			token: e.tokens[i],
			tiles: e.won[i].map((e) => e.tile),
			zeroVp: e.zeroMarks[i].length * 2,
			commodities: e.comm[i],
			goldLeft: e.piles.gold.length,
			myOil: t[a],
			maxOil: n,
			oilTied: Math.max(1, r)
		}), s = e.won[i].reduce((e, t) => e + t.paid, 0) + e.comm[i].reduce((e, t) => e + t.paid, 0) - e.saleCredit[i];
		return {
			rid: i,
			...o,
			leastBonus: 0,
			total: o.subtotal,
			spent: s,
			eliminated: !1
		};
	}), a = Math.max(...i.map((e) => e.spent)), o = Math.min(...i.map((e) => e.spent));
	for (let t of i) t.eliminated = t.spent === a, t.spent === o && (t.leastBonus = se(e.players.length)), t.total = t.subtotal + t.leastBonus;
	let s = i.filter((e) => !e.eliminated).sort((e, t) => t.total - e.total || e.spent - t.spent), c = i.filter((e) => e.eliminated).sort((e, t) => t.total - e.total || e.spent - t.spent), l = [...s, ...c].map((e) => e.rid), u = s[0];
	return {
		entries: i,
		winner: u ? s.filter((e) => e.total === u.total && e.spent === u.spent).map((e) => e.rid) : [],
		ranking: l
	};
}
function ve(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let { entries: t, winner: n, ranking: r } = B(e);
	return {
		phase: "done",
		winner: n,
		ranking: r,
		scores: Object.fromEntries(t.map((e) => [e.rid, e.total]))
	};
}
function ye(e) {
	return e.phase === "bid" && e.awaiting.length === 0 ? ce.resolve : e.phase === "reveal" ? ce.reveal : null;
}
var be = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: w,
	schemas: {
		action: ne,
		publicView: ae,
		privateView: oe,
		config: j
	},
	setup: ue,
	reduce: ge,
	viewFor: _e,
	status: ve,
	nextTickIn: ye
};
//#endregion
//#region src/games/qe/bid-keypad.tsx
function V(e) {
	return e.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
function xe({ min: e, forbid: t, onSubmit: r }) {
	let i = n(), [a, o] = s(""), u = a === "" ? null : Number(a), d = u !== null && u >= e && u !== t;
	function f(e) {
		o((t) => {
			if (t === "") return e === "0" ? "0" : e.startsWith("0") ? t : e;
			if (t === "0") return e.startsWith("0") ? t : e;
			let n = t + e;
			return n.length > 12 ? t : n;
		});
	}
	return /* @__PURE__ */ l("div", {
		className: "qe-keypad",
		children: [
			/* @__PURE__ */ l("div", {
				className: "qe-keypad-display frame px-3 py-1.5",
				children: [/* @__PURE__ */ c("span", {
					className: "qe-keypad-amount font-mono text-2xl font-extrabold tabular-nums",
					"aria-live": "polite",
					children: u === null ? /* @__PURE__ */ c("span", {
						className: "opacity-30",
						children: "0"
					}) : V(u)
				}), t !== void 0 && /* @__PURE__ */ c("span", {
					className: "qe-keypad-hint text-xs font-bold opacity-60",
					children: i("games.qe.notOpening", { n: V(t) })
				})]
			}),
			/* @__PURE__ */ c("div", {
				className: "qe-keypad-digits",
				children: [
					"1",
					"2",
					"3",
					"4",
					"5",
					"6",
					"7",
					"8",
					"9",
					"0",
					"00",
					"000"
				].map((e) => /* @__PURE__ */ c("button", {
					type: "button",
					onClick: () => f(e),
					className: "card min-h-11 cursor-pointer font-mono text-lg font-extrabold tabular-nums active:translate-y-0.5",
					children: e
				}, e))
			}),
			/* @__PURE__ */ l("div", {
				className: "qe-keypad-controls",
				children: [/* @__PURE__ */ c("button", {
					type: "button",
					onClick: () => o((e) => e.slice(0, -1)),
					"aria-label": i("games.qe.backspace"),
					className: "btn-quiet min-h-12 cursor-pointer",
					children: "⌫"
				}), /* @__PURE__ */ c("button", {
					type: "button",
					disabled: !d,
					onClick: () => {
						u !== null && d && r(u);
					},
					className: "btn-base min-h-12 cursor-pointer text-white disabled:opacity-40",
					style: { background: w.accent },
					children: i("games.qe.submitBid")
				})]
			})
		]
	});
}
//#endregion
//#region src/games/qe/tile.tsx
var H = {
	US: "🇺🇸",
	EU: "🇪🇺",
	CN: "🇨🇳",
	JP: "🇯🇵",
	UK: "🇬🇧"
}, U = {
	agri: "🌾",
	housing: "🏠",
	fin: "💰",
	manuf: "🏭",
	gov: "🏛️"
}, W = {
	gold: "🥇",
	oil: "🛢️",
	crypto: "🪙"
}, G = {
	US: "games.qe.nationUS",
	EU: "games.qe.nationEU",
	CN: "games.qe.nationCN",
	JP: "games.qe.nationJP",
	UK: "games.qe.nationUK"
}, K = {
	agri: "games.qe.indAgri",
	housing: "games.qe.indHousing",
	fin: "games.qe.indFin",
	manuf: "games.qe.indManuf",
	gov: "games.qe.indGov"
}, q = {
	gold: "games.qe.pileGold",
	oil: "games.qe.pileOil",
	crypto: "games.qe.pileCrypto"
}, J = {
	agri: "#eab308",
	housing: "#ef4444",
	fin: "#22c55e",
	manuf: "#a16207",
	gov: "#3b82f6"
};
function Y({ tile: e, size: t, paid: r, width: i, height: a }) {
	let o = n(), s = i === void 0 ? void 0 : {
		width: i,
		height: a,
		"--qe-tile-w": `${i}px`
	}, u = `${o(G[e.nation])} ${o(K[e.industry])} ${e.vp} ${o("games.qe.vp")}`;
	return t === "lg" ? /* @__PURE__ */ l("div", {
		"aria-label": u,
		style: s,
		className: "qe-tile qe-tile--lg card relative flex flex-col items-center justify-center gap-0.5 overflow-hidden px-3 py-2 pl-4",
		children: [
			/* @__PURE__ */ c("span", {
				"aria-hidden": !0,
				className: "absolute inset-y-0 left-0 w-1.5",
				style: { background: J[e.industry] }
			}),
			/* @__PURE__ */ c("span", {
				"aria-hidden": !0,
				className: "qe-tile-flag text-3xl leading-none",
				children: H[e.nation]
			}),
			/* @__PURE__ */ c("span", {
				"aria-hidden": !0,
				className: "qe-tile-industry text-xl leading-none",
				children: U[e.industry]
			}),
			/* @__PURE__ */ c("span", {
				className: "qe-tile-vp font-mono text-lg leading-none font-extrabold tabular-nums",
				children: e.vp
			})
		]
	}) : /* @__PURE__ */ l("div", {
		"aria-label": u,
		style: s,
		className: "qe-tile qe-tile--sm card relative flex flex-none flex-col items-center justify-center rounded-md px-1 py-0.5 pl-2",
		children: [
			/* @__PURE__ */ c("span", {
				"aria-hidden": !0,
				className: "absolute inset-y-0 left-0 w-1",
				style: { background: J[e.industry] }
			}),
			/* @__PURE__ */ l("span", {
				"aria-hidden": !0,
				className: "qe-tile-symbols text-xs leading-none",
				children: [H[e.nation], U[e.industry]]
			}),
			/* @__PURE__ */ c("span", {
				className: "qe-tile-vp font-mono text-[11px] leading-tight font-extrabold tabular-nums",
				children: e.vp
			}),
			r != null && /* @__PURE__ */ c("span", {
				className: "qe-tile-paid font-mono text-[11px] font-bold tabular-nums opacity-60",
				children: r
			})
		]
	});
}
function Se({ pile: e, value: t, diameter: r }) {
	let i = n();
	return /* @__PURE__ */ l("span", {
		"aria-label": t === void 0 ? i(q[e]) : `${i(q[e])} ${t} ${i("games.qe.vp")}`,
		className: "qe-commodity inline-flex items-center gap-0.5 rounded-full border-2 border-ink bg-surface px-1.5 py-0.5 text-xs font-extrabold",
		style: r === void 0 ? void 0 : {
			width: r,
			height: r,
			fontSize: r * .4,
			justifyContent: "center",
			padding: 0
		},
		children: [/* @__PURE__ */ c("span", {
			"aria-hidden": !0,
			children: W[e]
		}), t !== void 0 && /* @__PURE__ */ c("span", {
			className: "font-mono tabular-nums",
			children: t
		})]
	});
}
//#endregion
//#region src/games/qe/view-player.tsx
function Ce(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ c(we, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function we({ pub: e, priv: t, members: r, myRid: s, send: u }) {
	let d = n(), f = (e) => r.find((t) => t.rid === e)?.name ?? e, p = e.players.some((e) => e.rid === s), m = e.auctioneer === s, h = e.awaiting.includes(s), _, v;
	e.phase === "open" ? (_ = m ? "accent" : "info", v = m ? d("games.qe.openPrompt") : d("games.qe.openWait", { name: f(e.auctioneer ?? "") })) : e.phase === "bid" ? (_ = h ? "accent" : "info", v = h ? e.rebidFor !== null || e.tied.includes(s) ? d("games.qe.rebidPrompt") : d("games.qe.bidPrompt") : d("games.qe.bidWait")) : e.phase === "choose" ? (_ = h ? "accent" : "info", v = d(h ? "games.qe.choosePrompt" : "games.qe.chooseWait")) : e.phase === "discard" ? (_ = h ? "accent" : "info", v = d(h ? "games.qe.discardPrompt" : "games.qe.discardWait")) : e.phase === "reveal" ? (_ = "done", v = d("games.qe.reveal")) : (_ = "done", v = d("games.qe.done"));
	let y = t ? t.myTiles.reduce((e, t) => e + t.paid, 0) + t.myCommodities.reduce((e, t) => e + t.paid, 0) - t.saleCredit : 0, b = t ? De(e, t, s) : null;
	return /* @__PURE__ */ c(o, {
		adaptive: !0,
		className: "qe-screen",
		actionsHeight: "qe-actions-slot",
		banner: /* @__PURE__ */ l("div", {
			className: "qe-banner",
			children: [
				/* @__PURE__ */ c(i, {
					tone: _,
					text: v,
					chip: d("games.qe.auctionProgress", {
						n: e.auctionNo,
						total: e.totalAuctions
					}),
					accent: w.accent
				}),
				t && p && /* @__PURE__ */ l("div", {
					className: "qe-ledger flex items-center justify-between gap-2 px-1 text-xs font-bold",
					children: [
						/* @__PURE__ */ l("span", {
							className: "font-mono tabular-nums",
							"aria-label": d("games.qe.mySpentAria"),
							children: ["🖨️ ", V(y)]
						}),
						/* @__PURE__ */ c("span", {
							"aria-label": d("games.qe.estimateAria"),
							children: d("games.qe.estimate", { n: b ?? 0 })
						}),
						/* @__PURE__ */ l("span", {
							"aria-label": d("games.qe.tokenAria", { industry: d(K[t.token]) }),
							children: [
								d("games.qe.myToken"),
								" ",
								U[t.token]
							]
						})
					]
				}),
				/* @__PURE__ */ c("div", {
					className: "qe-seats px-1",
					children: /* @__PURE__ */ c(a, {
						variant: "plate",
						members: r,
						myRid: s,
						anchorOf: (e) => `seat:${e}`,
						action: (t) => !e.players.some((e) => e.rid === t) || e.phase === "done" || e.phase === "reveal" ? null : e.awaiting.includes(t) ? "pending" : "done",
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ l("span", {
								className: "qe-seat-status flex items-center gap-1 text-xs font-bold",
								children: [
									/* @__PURE__ */ c("span", {
										"aria-label": d(G[n.nation]),
										children: H[n.nation]
									}),
									n.tiles.length > 0 && /* @__PURE__ */ l("span", {
										className: "font-mono tabular-nums",
										children: ["🏢", n.tiles.length]
									}),
									n.commodities.length > 0 && /* @__PURE__ */ c("span", { children: g.map((e) => {
										let t = n.commodities.filter((t) => t === e).length;
										return t > 0 ? /* @__PURE__ */ l("span", {
											"aria-label": `${d(q[e])} × ${t}`,
											children: [W[e], t]
										}, e) : null;
									}) })
								]
							}) : null;
						},
						trailing: (t) => !e.players.some((e) => e.rid === t) || t !== e.auctioneer ? null : /* @__PURE__ */ c("span", {
							"aria-label": d("games.qe.auctioneerAria"),
							className: "text-lg",
							children: "🔨"
						})
					})
				})
			]
		}),
		overlay: e.phase === "reveal" && e.history.length > 0 ? /* @__PURE__ */ c(je, {
			pub: e,
			nameOf: f
		}) : void 0,
		actions: p && e.phase !== "done" ? /* @__PURE__ */ l("div", {
			className: "qe-actions",
			children: [
				e.phase === "open" && m && /* @__PURE__ */ c(xe, {
					min: 1,
					onSubmit: (e) => u({
						type: "openBid",
						amount: e
					})
				}),
				e.phase === "bid" && h && /* @__PURE__ */ c(xe, {
					min: 0,
					forbid: m ? void 0 : e.opening ?? void 0,
					onSubmit: (e) => u({
						type: "bid",
						amount: e
					})
				}),
				e.phase === "choose" && h && /* @__PURE__ */ c(Ae, {
					pub: e,
					onPick: (e) => u({
						type: "choosePile",
						pile: e
					})
				}),
				e.phase === "discard" && h && /* @__PURE__ */ c(Ae, {
					pub: e,
					discard: !0,
					onPick: (e) => u({
						type: "discardPile",
						pile: e
					})
				}),
				(e.phase === "bid" && !h || e.phase === "open" && !m || e.phase === "reveal" || (e.phase === "choose" || e.phase === "discard") && !h) && /* @__PURE__ */ c("p", {
					className: "qe-waiting text-center text-sm font-bold opacity-60",
					children: t?.myBid !== null && t?.myBid !== void 0 && e.phase === "bid" ? d("games.qe.bidSubmitted", { n: V(t.myBid) }) : d("games.qe.waiting")
				})
			]
		}) : void 0,
		children: /* @__PURE__ */ l("div", {
			className: "qe-board frame p-2",
			children: [
				/* @__PURE__ */ l("div", {
					className: "qe-auction flex items-center justify-center gap-3 pt-1",
					children: [e.tile ? /* @__PURE__ */ c(Oe, { tile: e.tile }) : null, /* @__PURE__ */ l("div", {
						className: "qe-auction-info flex flex-col gap-0.5",
						children: [
							e.opening !== null && /* @__PURE__ */ l("span", {
								className: "qe-opening text-sm font-bold",
								children: [d("games.qe.opening"), /* @__PURE__ */ c("span", {
									className: "font-mono text-lg font-extrabold tabular-nums",
									children: V(e.opening)
								})]
							}),
							e.phase === "bid" && /* @__PURE__ */ c("span", {
								className: "text-xs font-bold opacity-70",
								children: d("games.qe.bidCount", {
									n: e.totalAuctions > 0 ? Te(e) : 0,
									total: Ee(e)
								})
							}),
							e.goldCrash && e.commodities && /* @__PURE__ */ c("span", {
								className: "text-xs font-bold text-danger",
								children: d("games.qe.goldCrash")
							})
						]
					})]
				}),
				e.commodities && /* @__PURE__ */ c("div", {
					className: "qe-piles flex items-center justify-center gap-2",
					children: g.map((t) => /* @__PURE__ */ c(ke, {
						pile: t,
						left: e.piles[t]
					}, t))
				}),
				t && p && (t.myTiles.length > 0 || t.myCommodities.length > 0) && /* @__PURE__ */ l("section", {
					"aria-label": d("games.qe.myLoot"),
					className: "qe-loot border-t-2 border-ink/10 pt-1.5",
					children: [/* @__PURE__ */ c("p", {
						className: "section-label",
						children: d("games.qe.myLoot")
					}), /* @__PURE__ */ l("div", {
						className: "qe-loot-items flex flex-wrap gap-1 pt-1",
						children: [t.myTiles.map((e) => /* @__PURE__ */ c(Y, {
							tile: e.tile,
							size: "sm",
							paid: e.paid
						}, e.tile.id)), t.myCommodities.map((e, t) => /* @__PURE__ */ c(Se, {
							pile: e.pile,
							value: e.value
						}, t))]
					})]
				}),
				e.history.length > 0 && /* @__PURE__ */ l("section", {
					"aria-label": d("games.qe.log"),
					className: "qe-history border-t-2 border-ink/10 pt-1.5",
					children: [/* @__PURE__ */ c("p", {
						className: "section-label",
						children: d("games.qe.log")
					}), /* @__PURE__ */ c("ul", {
						className: "flex flex-col gap-1 pt-1",
						children: e.history.map((n, r) => /* @__PURE__ */ c(Me, {
							index: r,
							pub: e,
							priv: t,
							myRid: s,
							nameOf: f,
							send: u
						}, r))
					})]
				})
			]
		})
	});
}
function Te(e) {
	return e.players.length - e.awaiting.length - +(e.auctioneer !== null && e.rebidFor === null);
}
function Ee(e) {
	return e.players.length - +(e.auctioneer !== null && e.rebidFor === null);
}
function De(e, t, n) {
	let r = e.players.length, i = e.players.find((e) => e.rid === n);
	if (!i) return 0;
	let a = /* @__PURE__ */ new Set();
	e.history.forEach((e, t) => {
		e.zeroBidders.includes(n) && a.add(Math.floor(t / r));
	});
	let o = e.players.map((e) => e.commodities.filter((e) => e === "oil").length), s = Math.max(0, ...o), c = i.commodities.filter((e) => e === "oil").length;
	return M({
		playerCount: r,
		commoditiesOn: e.commodities,
		nation: i.nation,
		token: t.token,
		tiles: t.myTiles.map((e) => e.tile),
		zeroVp: a.size * 2,
		commodities: t.myCommodities,
		goldLeft: e.piles.gold,
		myOil: c,
		maxOil: s,
		oilTied: Math.max(1, o.filter((e) => e === s && e > 0).length)
	}).subtotal;
}
function Oe({ tile: e }) {
	let { ref: t } = r("tile");
	return /* @__PURE__ */ c("div", {
		ref: t,
		className: "qe-current-tile card-flip-in",
		children: /* @__PURE__ */ c(Y, {
			tile: e,
			size: "lg"
		})
	});
}
function ke({ pile: e, left: t }) {
	let i = n(), { ref: a } = r(`pile:${e}`);
	return /* @__PURE__ */ l("span", {
		ref: a,
		"aria-label": `${i(q[e])} × ${t}`,
		className: `qe-pile card flex items-center gap-1 px-2 py-1 text-sm font-extrabold ${t === 0 ? "opacity-40" : ""}`,
		children: [/* @__PURE__ */ c("span", {
			"aria-hidden": !0,
			children: W[e]
		}), /* @__PURE__ */ l("span", {
			className: "font-mono tabular-nums",
			children: ["×", t]
		})]
	});
}
function Ae({ pub: e, discard: t, onPick: r }) {
	let i = n();
	return /* @__PURE__ */ c("div", {
		className: "qe-pile-chooser grid grid-cols-3 gap-1.5",
		children: g.map((n) => /* @__PURE__ */ l("button", {
			type: "button",
			disabled: e.piles[n] === 0,
			onClick: () => r(n),
			className: "card min-h-12 cursor-pointer text-sm font-extrabold active:translate-y-0.5 disabled:opacity-40",
			"aria-label": t ? i("games.qe.discardPileAria", { pile: i(q[n]) }) : i(q[n]),
			children: [
				W[n],
				" ",
				i(q[n]),
				/* @__PURE__ */ l("span", {
					className: "block font-mono text-xs tabular-nums opacity-60",
					children: ["×", e.piles[n]]
				})
			]
		}, n))
	});
}
function je({ pub: e, nameOf: t }) {
	let r = n(), i = e.history[e.history.length - 1];
	return /* @__PURE__ */ l("section", {
		"aria-live": "polite",
		className: "qe-reveal card mx-auto flex w-full max-w-sm flex-col gap-0.5 p-2 text-center text-sm font-bold",
		children: [
			i.flowOut ? /* @__PURE__ */ c("span", {
				className: "text-danger",
				children: r("games.qe.flowOut")
			}) : /* @__PURE__ */ l("span", { children: [r("games.qe.winnerTakes", { name: t(i.winner ?? "") }), i.winBid !== null && /* @__PURE__ */ l("span", {
				className: "font-mono tabular-nums",
				children: [
					" (",
					V(i.winBid),
					")"
				]
			})] }),
			i.second && i.pile && /* @__PURE__ */ c("span", {
				className: "text-xs opacity-80",
				children: r("games.qe.commodityTo", {
					name: t(i.second),
					pile: r(q[i.pile])
				})
			}),
			i.zeroBidders.length > 0 && /* @__PURE__ */ c("span", {
				className: "text-xs opacity-80",
				children: r("games.qe.zeroGain", { names: i.zeroBidders.map(t).join("、") })
			})
		]
	});
}
function Me({ index: e, pub: t, priv: r, myRid: i, nameOf: a, send: o }) {
	let s = n(), u = t.history[e], d = r?.peekResults[String(e)], f = t.players.length >= 5 && r && !t.players.find((e) => e.rid === i)?.peekUsed && u.winner !== null && u.winBid === null && d === void 0, p = u.auctioneer === i ? r?.auctioneerBids[String(e)] : void 0;
	return /* @__PURE__ */ l("li", {
		className: "qe-history-row flex flex-col gap-0.5 text-xs font-bold",
		children: [/* @__PURE__ */ l("div", {
			className: "qe-history-line flex items-center gap-1.5",
			children: [
				/* @__PURE__ */ l("span", {
					className: "font-mono tabular-nums opacity-50",
					children: ["#", e + 1]
				}),
				/* @__PURE__ */ l("span", {
					"aria-hidden": !0,
					children: [H[u.tile.nation], U[u.tile.industry]]
				}),
				/* @__PURE__ */ c("span", {
					className: "font-mono tabular-nums",
					children: u.tile.vp
				}),
				/* @__PURE__ */ l("span", {
					className: "qe-history-owner min-w-0 flex-1",
					children: [u.flowOut ? /* @__PURE__ */ c("span", {
						className: "opacity-50",
						children: s("games.qe.flowOut")
					}) : a(u.winner ?? ""), u.pile && /* @__PURE__ */ l("span", {
						className: "opacity-70",
						children: [
							" ",
							"· ",
							W[u.pile],
							"→",
							a(u.second ?? "")
						]
					})]
				}),
				u.winBid !== null && /* @__PURE__ */ c("span", {
					className: "font-mono tabular-nums",
					children: V(u.winBid)
				}),
				d !== void 0 && /* @__PURE__ */ l("span", {
					className: "font-mono tabular-nums",
					children: [V(d), " 👁"]
				}),
				f && /* @__PURE__ */ c("button", {
					type: "button",
					onClick: () => o({
						type: "peek",
						auction: e
					}),
					"aria-label": s("games.qe.peekAria"),
					className: "card min-h-11 cursor-pointer px-2 font-extrabold active:translate-y-0.5",
					children: "👁"
				})
			]
		}), p && /* @__PURE__ */ c("div", {
			className: "qe-auction-bids flex flex-wrap gap-x-2 pl-6 font-mono tabular-nums opacity-70",
			children: Object.entries(p).map(([e, t]) => /* @__PURE__ */ l("span", { children: [
				a(e),
				" ",
				V(t)
			] }, e))
		})]
	});
}
//#endregion
//#region src/games/qe/bot.ts
function Ne(e, t, n, r) {
	let i = e.players.find((e) => e.rid === n), a = e.players.length, o = /* @__PURE__ */ new Set();
	e.history.forEach((e, t) => {
		e.zeroBidders.includes(n) && o.add(Math.floor(t / a));
	});
	let s = e.players.map((e) => e.commodities.filter((e) => e === "oil").length), c = i?.commodities.filter((e) => e === "oil").length ?? 0, l = Math.max(0, ...s), u = t.myTiles.map((e) => e.tile);
	return r && u.push(r), {
		playerCount: a,
		commoditiesOn: e.commodities,
		nation: i?.nation ?? "US",
		token: t.token,
		tiles: u,
		zeroVp: o.size * 2,
		commodities: t.myCommodities,
		goldLeft: e.piles.gold,
		myOil: c,
		maxOil: l,
		oilTied: Math.max(1, s.filter((e) => e === l && e > 0).length)
	};
}
function Pe(e, t, n, r) {
	return M(Ne(e, t, n, r)).subtotal - M(Ne(e, t, n)).subtotal;
}
function Fe(e, t) {
	let n = 0, r = 0;
	for (let e of t.myTiles) n += e.paid, r += Math.max(1, e.tile.vp);
	for (let t of e.history) t.winBid !== null && (n += t.winBid, r += Math.max(1, t.tile.vp));
	return r > 0 ? Math.max(1, n / r) : 120 + 240 * e.auctionNo / e.totalAuctions;
}
function X(e, t) {
	return e + (t - e) * (crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32);
}
function Ie(e) {
	return Math.max(0, Math.min(E, Math.round(e)));
}
function Le(e, t) {
	let n = e.players.length, r = Math.floor((e.auctionNo - 1) / n);
	return e.history.some((e, i) => Math.floor(i / n) === r && e.zeroBidders.includes(t));
}
function Re(e, t) {
	let n = e.piles[t];
	return n ? x(e.players.length)[t][n - 1] : null;
}
function ze(e, t, n, r) {
	let i = e.players.find((e) => e.rid === n);
	if (r) {
		let t = [
			"gold",
			"oil",
			"crypto"
		].filter((t) => e.piles[t] > 0);
		return t[Math.floor(X(0, t.length))] ?? "crypto";
	}
	let a = i?.commodities.filter((e) => e === "oil").length ?? 0, o = Math.max(0, ...e.players.map((e) => e.commodities.filter((e) => e === "oil").length)), s = "crypto", c = -Infinity;
	for (let n of [
		"gold",
		"oil",
		"crypto"
	]) {
		let r = Re(e, n);
		if (r === null) continue;
		let i = r;
		if (n === "gold") {
			let n = t.myCommodities.filter((e) => e.pile === "gold").length;
			e.piles.gold <= 2 && (i -= 3 * (n + 1) * .6);
		} else n === "oil" && (o === 0 || a + 1 >= o) && (i += 2.5);
		i > c && (c = i, s = n);
	}
	return s;
}
var Be = (e, t) => {
	let n = e.public, r = e.private;
	if (!r || n.phase === "done" || n.phase === "reveal") return null;
	let i = t.rid, a = t.difficulty === "weak";
	if (n.phase === "open" && n.auctioneer === i && n.tile) {
		let e = Pe(n, r, i, n.tile), t = Fe(n, r);
		return { action: {
			type: "openBid",
			amount: Ie(Math.max(1, e * t * X(a ? .3 : .55, a ? .8 : .95)))
		} };
	}
	if (n.phase === "bid" && n.awaiting.includes(i) && n.tile) {
		let e = Pe(n, r, i, n.tile), t = Fe(n, r), o = r.myTiles.reduce((e, t) => e + t.paid, 0) + r.myCommodities.reduce((e, t) => e + t.paid, 0) - r.saleCredit > n.auctionNo * 3 * t;
		if (!n.commodities && n.players.length >= 4 && !Le(n, i) && (e <= 1 || o) && X(0, 1) < (a ? .4 : .65)) return { action: {
			type: "bid",
			amount: 0
		} };
		let s = X(a ? .25 : .55, a ? .85 : 1.15);
		o && (s *= .5), n.rebidFor !== null && (s *= 1.1);
		let c = Ie(e * t * s);
		return n.auctioneer !== i && n.opening !== null && c === n.opening && (c += 1), { action: {
			type: "bid",
			amount: c
		} };
	}
	if (n.phase === "choose" && n.awaiting.includes(i)) return { action: {
		type: "choosePile",
		pile: ze(n, r, i, a)
	} };
	if (n.phase === "discard" && n.awaiting.includes(i)) {
		let e = "crypto", t = -1;
		for (let r of [
			"gold",
			"oil",
			"crypto"
		]) {
			let i = Re(n, r);
			i !== null && i > t && (t = i, e = r);
		}
		return { action: {
			type: "discardPile",
			pile: e
		} };
	}
	return null;
}, Ve = {
	gold: "games.qe.pileGold",
	oil: "games.qe.pileOil",
	crypto: "games.qe.pileCrypto"
}, He = (e, t, n) => {
	switch (e.type) {
		case "openBid": return n("games.qe.hintOpenBid", { n: e.amount });
		case "bid": return e.amount === 0 ? n("games.qe.hintBidZero") : n("games.qe.hintBid", { n: e.amount });
		case "choosePile": return n("games.qe.hintChoosePile", { pile: n(Ve[e.pile]) });
		case "discardPile": return n("games.qe.discardPileAria", { pile: n(Ve[e.pile]) });
		default: return "";
	}
};
//#endregion
//#region src/games/qe/fx.tsx
function Z(e) {
	return e.anchor("tile");
}
function Q(e, t) {
	return (t ? e.anchor(`seat:${t}`) : null) ?? Z(e);
}
function Ue(e, t) {
	return (t ? e.anchor(`pile:${t}`) : null) ?? Z(e);
}
function $(e, t, n) {
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - n) / 2,
		w: t,
		h: n
	};
}
var We = {
	tile() {
		return {
			ms: 400,
			node: null
		};
	},
	award(e, t) {
		let n = e.data, r = Z(t), i = Q(t, e.rid);
		if (!r || !i) return null;
		let a = Math.min(r.w * .55, i.w), o = $(i, a, a * r.h / r.w), s = [/* @__PURE__ */ c(d, {
			from: r,
			to: o,
			ms: 420,
			children: /* @__PURE__ */ c(Y, {
				tile: n?.tile,
				size: "lg",
				width: r.w,
				height: r.h
			})
		}, "tile")], l = Array.isArray(n?.zeroBidders) ? n.zeroBidders : [];
		for (let [e, n] of l.entries()) {
			let r = Q(t, n);
			r && s.push(/* @__PURE__ */ c(u, {
				at: r,
				ms: 1100,
				delay: 300 + e * 120,
				children: /* @__PURE__ */ c("span", {
					className: "font-mono text-lg font-extrabold tabular-nums text-done-ink",
					children: "+2"
				})
			}, `zero-${n}`));
		}
		return {
			ms: 920,
			node: s
		};
	},
	commodity(e, t) {
		let n = e.data?.pile, r = Ue(t, n), i = Q(t, e.rid);
		if (!r || !i) return null;
		let a = Math.min(r.w, r.h);
		return {
			ms: 420,
			node: /* @__PURE__ */ c(d, {
				from: $(r, a, a),
				to: $(i, a, a),
				ms: 420,
				children: /* @__PURE__ */ c(Se, {
					pile: n,
					diameter: a
				})
			})
		};
	},
	flow(e, t) {
		let n = Z(t);
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ c(u, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ c("span", {
					className: "font-display text-2xl font-extrabold text-danger",
					children: "✗"
				})
			})
		} : {
			ms: 800,
			node: null
		};
	},
	tie(e, t) {
		let n = Z(t);
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ c(u, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ c("span", {
					className: "text-xl",
					"aria-hidden": !0,
					children: "🔁"
				})
			})
		} : {
			ms: 900,
			node: null
		};
	},
	discard(e, t) {
		let n = e.data, r = Ue(t, n?.pile);
		return r ? {
			ms: 700,
			node: /* @__PURE__ */ c(u, {
				at: r,
				ms: 700,
				children: /* @__PURE__ */ c("span", {
					className: "font-display text-lg font-extrabold text-danger",
					children: "✗"
				})
			})
		} : {
			ms: 700,
			node: null
		};
	}
};
//#endregion
//#region src/games/qe/game-over.tsx
function Ge({ result: e, public: t, members: r, onPlayAgain: i, onBackToLobby: a }) {
	let o = n(), s = t, u = (e) => r.find((t) => t.rid === e)?.name ?? e, d = i ?? a, p = s.final ?? [], m = new Map(p.map((e) => [e.rid, e]));
	return /* @__PURE__ */ c("div", {
		className: "qe-over",
		children: /* @__PURE__ */ l("div", {
			className: "qe-over-content relative flex h-full min-h-0 flex-col items-center gap-2",
			children: [
				e.winner.length > 0 && /* @__PURE__ */ c(f, {}),
				/* @__PURE__ */ l("h1", {
					className: "flex flex-none items-center gap-2 text-center font-display text-xl font-extrabold",
					children: [/* @__PURE__ */ c("span", {
						"aria-hidden": !0,
						children: w.icon
					}), o("session.result.title")]
				}),
				/* @__PURE__ */ l("div", {
					className: "qe-over-scroll",
					children: [/* @__PURE__ */ c("div", {
						className: "qe-over-ranking flex w-full flex-none flex-col gap-1.5",
						children: e.ranking.map((t, n) => {
							let r = m.get(t);
							if (!r) return null;
							let i = e.winner.includes(t);
							return /* @__PURE__ */ l("section", {
								className: `qe-over-rank frame gap-2 p-2.5 ${r.eliminated ? "opacity-60" : ""}`,
								children: [
									/* @__PURE__ */ c("span", {
										"aria-hidden": !0,
										className: `w-5 flex-none text-center ${i ? "" : "invisible"}`,
										children: "🏆"
									}),
									/* @__PURE__ */ l("span", {
										className: "qe-over-name min-w-0 text-sm font-extrabold",
										children: [
											n + 1,
											". ",
											u(t),
											r.eliminated && /* @__PURE__ */ c("span", {
												className: "ml-1 text-xs font-bold text-danger",
												children: o("games.qe.eliminated")
											})
										]
									}),
									/* @__PURE__ */ l("span", {
										className: "qe-over-spent font-mono text-xs font-bold tabular-nums",
										"aria-label": o("games.qe.spentAria"),
										children: ["🖨️", V(r.spent)]
									}),
									/* @__PURE__ */ c("span", {
										className: "qe-over-total font-mono text-lg font-extrabold tabular-nums",
										children: r.total
									})
								]
							}, t);
						})
					}), /* @__PURE__ */ c("div", {
						className: "qe-over-breakdowns flex w-full flex-none flex-col gap-1.5",
						children: e.ranking.map((e) => {
							let t = m.get(e);
							if (!t) return null;
							let n = [
								[o("games.qe.scTiles"), t.tilesVp],
								[o("games.qe.scZero"), t.zeroVp],
								[o("games.qe.scNat"), t.natVp],
								[o("games.qe.scMon"), t.monVp],
								[o("games.qe.scDiv"), t.divVp],
								[o("games.qe.scComm"), t.commVp],
								[o("games.qe.scOil"), t.oilBonus],
								[o("games.qe.scGold"), t.goldPenalty],
								[o("games.qe.scLeast"), t.leastBonus]
							].filter(([, e]) => e !== 0);
							return /* @__PURE__ */ l("section", {
								className: "qe-over-breakdown frame flex flex-col gap-0.5 px-2.5 py-1.5",
								children: [/* @__PURE__ */ l("p", {
									className: "flex items-center justify-between text-xs font-extrabold",
									children: [/* @__PURE__ */ c("span", {
										className: "qe-over-detail-name",
										children: u(e)
									}), /* @__PURE__ */ l("span", {
										className: "font-mono tabular-nums",
										children: [
											t.subtotal,
											t.leastBonus > 0 && ` + ${t.leastBonus}`,
											" = ",
											t.total
										]
									})]
								}), /* @__PURE__ */ c("p", {
									className: "flex flex-wrap gap-x-2 text-[11px] font-bold opacity-70",
									children: n.map(([e, t]) => /* @__PURE__ */ l("span", {
										className: "font-mono tabular-nums",
										children: [
											e,
											" ",
											t > 0 ? `+${t}` : t
										]
									}, e))
								})]
							}, e);
						})
					})]
				}),
				d ? /* @__PURE__ */ l("div", {
					className: "qe-over-actions safe-b flex w-full flex-none flex-col gap-2 pb-1",
					children: [i && /* @__PURE__ */ c("button", {
						className: "btn-base w-full cursor-pointer text-white",
						style: { background: w.accent },
						onClick: i,
						children: o("session.result.playAgain")
					}), a && /* @__PURE__ */ c("button", {
						className: "btn-quiet w-full cursor-pointer",
						onClick: a,
						children: o("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ c("p", {
					className: "safe-b flex-none pb-1 text-sm font-bold opacity-70",
					children: o("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region src/games/qe/options.tsx
function Ke({ value: e, onChange: t }) {
	let r = n(), i = j.safeParse(e), a = i.success ? i.data : j.parse(void 0);
	return /* @__PURE__ */ c(m, {
		title: r("games.qe.optCommodities"),
		children: [!1, !0].map((e) => /* @__PURE__ */ c(p, {
			name: "qe-commodities",
			value: String(e),
			checked: a.commodities === e,
			label: r(e ? "games.qe.optWithCommodities" : "games.qe.optBase"),
			accent: w.accent,
			onChange: () => t({ commodities: e })
		}, String(e)))
	});
}
//#endregion
//#region src/games/qe/guide.tsx
function qe() {
	let e = n();
	return /* @__PURE__ */ l("div", {
		className: "flex w-full flex-col gap-3",
		children: [
			/* @__PURE__ */ l("section", {
				className: "frame flex flex-col gap-1 p-2",
				children: [/* @__PURE__ */ c("p", {
					className: "text-sm font-extrabold",
					children: e("games.qe.guideTilesSmall")
				}), /* @__PURE__ */ c(Je, { playerCount: 4 })]
			}),
			/* @__PURE__ */ l("section", {
				className: "frame flex flex-col gap-1 p-2",
				children: [/* @__PURE__ */ c("p", {
					className: "text-sm font-extrabold",
					children: e("games.qe.guideTilesFive")
				}), /* @__PURE__ */ c(Je, { playerCount: 5 })]
			}),
			/* @__PURE__ */ l("section", {
				className: "frame flex flex-col gap-1 p-2",
				children: [/* @__PURE__ */ c("p", {
					className: "text-sm font-extrabold",
					children: e("games.qe.guideCommodities")
				}), /* @__PURE__ */ c("ul", {
					className: "flex flex-col gap-1",
					children: g.map((t) => /* @__PURE__ */ l("li", {
						className: "flex items-center gap-2 text-xs font-bold",
						children: [
							/* @__PURE__ */ c("span", {
								"aria-hidden": !0,
								children: W[t]
							}),
							/* @__PURE__ */ c("span", {
								className: "w-10",
								children: e(q[t])
							}),
							/* @__PURE__ */ c("span", {
								className: "font-mono tabular-nums opacity-80",
								children: [...x(4)[t]].sort((e, t) => t - e).join(" · ")
							})
						]
					}, t))
				})]
			})
		]
	});
}
function Je({ playerCount: e }) {
	let t = n(), r = y(e), i = [...new Set(r.map((e) => e.nation))], a = [...new Set(r.map((e) => e.industry))], o = (e, t) => r.find((n) => n.industry === e && n.nation === t)?.vp;
	return /* @__PURE__ */ l("table", {
		className: "w-full border-separate border-spacing-0.5 text-center font-mono text-xs font-bold tabular-nums",
		children: [/* @__PURE__ */ c("thead", { children: /* @__PURE__ */ l("tr", { children: [/* @__PURE__ */ c("th", {}), i.map((e) => /* @__PURE__ */ c("th", {
			"aria-label": t(G[e]),
			className: "font-normal",
			children: H[e]
		}, e))] }) }), /* @__PURE__ */ c("tbody", { children: a.map((e) => /* @__PURE__ */ l("tr", { children: [/* @__PURE__ */ c("th", {
			"aria-label": t(K[e]),
			className: "font-normal",
			children: U[e]
		}), i.map((t) => {
			let n = o(e, t);
			return /* @__PURE__ */ c("td", {
				className: `rounded px-1 py-0.5 ${n === void 0 ? "opacity-30" : "bg-ink/5"}`,
				children: n ?? "—"
			}, t);
		})] }, e)) })]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/qe/entry.tsx
var Ye = {
	definition: be,
	View: Ce,
	bot: Be,
	describe: He,
	fx: We,
	OverView: Ge,
	Options: Ke,
	Guide: qe,
	locales: {
		zh: {
			name: "量化宽松",
			desc: "印钱收购公司,花得最多的人直接出局",
			rules: "目标：每位玩家代表一家中央银行，通过发行货币竞拍公司。游戏结束时，发行货币最多的玩家被淘汰，发行货币最少的玩家获得奖励；其余玩家中，总分最高者获胜。\n准备:\n· 按人数用 16 张(3–4 人)或 15 张(5 人)公司板块洗成牌堆。\n· 每名玩家代表一个国家，并秘密抽取1个产业标记；计算垄断分数时，将该标记视为额外1个对应产业。\n流程：每次拍卖一家公司，3至4人游戏共进行16次拍卖，5人游戏共进行15次拍卖。\n· 拍卖师亮出公司并公开开价(任意正整数)。\n· 其余人秘密出价(0 或正整数,不得等于开价)。\n· 出价最高的玩家获得公司。将成交金额记录在公司板块背面并保密；如果拍卖师自己中标，则必须公开金额。\n· 零出价：出价为0的玩家获得2分。每名玩家每轮最多领取一次此奖励；所有玩家各担任一次拍卖师后，一轮结束。3人游戏不启用此规则。\n· 平局：出价并列最高的玩家重新秘密出价，且仍不得等于开价,连续三次出价相同后，由未参与平局的玩家中出价最高者中标；如果所有玩家仍然平局，则本次拍卖流拍。\n· 拍卖师左移轮转。\n结算:\n总分包括以下五项：\n· 公司板块上标示的分数。\n· 零出价获得的分数。\n· 国有化分数，按本国公司板块计算。\n· 垄断分数，按同一产业的数量计算，暗置产业标记也计入。\n· 多样化分数，按不同产业组成的集合计算。\n· 总花费最多者淘汰(并列则全部淘汰),花费最少者获得 6 分(5 人局 7 分,并列则都获得);平分时花费少者胜。\n财货扩展(可开关):\n· 每次拍卖中，出价第二高的玩家选择一堆财货，取得该堆顶的板块。板块类别公开，面值只有获得者可以查看。该出价计入购买者的总花费；拍卖师记录相同金额的售出收入，用于抵扣自己的总花费。\n· 零出价不再得分。黄金财货堆耗尽后，场上每块黄金财货板块各扣除 3 分;拥有石油财货板块最多的玩家获得5分；多人并列时，平分这5分，并向下取整。\n· 第二高出价相同时，公司仍由出价最高的玩家获得，其余玩家全部重新报价以竞拍财货。连续三次平局后，由拍卖师选择一堆财货，弃置该堆顶的板块。",
			vp: "{{n}} 分",
			nationUS: "美国",
			nationEU: "欧洲",
			nationCN: "中国",
			nationJP: "日本",
			nationUK: "英国",
			indAgri: "农业",
			indHousing: "房产",
			indFin: "金融",
			indManuf: "制造",
			indGov: "政府",
			pileGold: "黄金",
			pileOil: "石油",
			pileCrypto: "加密货币",
			errNotOpen: "现在不能开价",
			errNotBidder: "现在轮不到你出价",
			errSameAsOpening: "出价不能等于开价",
			errNotChooser: "现在轮不到你选财货",
			errPileEmpty: "这堆已经拿完了",
			errNotDiscarder: "现在轮不到你弃板",
			errNoPeek: "只有 5 人局能偷看",
			errPeekUsed: "每局只能偷看一次",
			errBadPhase: "当前阶段不能这么做",
			notOpening: "不能等于开价 {{n}}",
			backspace: "退格",
			submitBid: "确认出价",
			openPrompt: "你是拍卖师:公开开价",
			openWait: "等 {{name}} 开价…",
			bidPrompt: "秘密出价(0 = 弃权)",
			rebidPrompt: "平标重报:再次出价",
			bidWait: "等其他人出价…",
			choosePrompt: "你第二高:选一堆拿顶板",
			chooseWait: "等第二名选财货…",
			discardPrompt: "三连平:选一堆弃掉顶板",
			discardWait: "等拍卖师弃板…",
			reveal: "揭晓中…",
			done: "本局结束",
			auctionProgress: "第 {{n}}/{{total}} 拍",
			opening: "开价",
			bidCount: "已交 {{n}}/{{total}}",
			goldCrash: "⚠ 金市崩盘:金板各 -3 分",
			mySpentAria: "我的总印钱",
			estimateAria: "实时预估分",
			estimate: "预估 {{n}} 分",
			tokenAria: "暗置产业标记:{{industry}}",
			myToken: "暗置",
			auctioneerAria: "拍卖师",
			myLoot: "我的收获",
			log: "拍卖记录",
			peekAria: "偷看这次中标价",
			flowOut: "流拍",
			winnerTakes: "{{name}} 中标",
			commodityTo: "{{pile}} → {{name}}",
			zeroGain: "{{names}} 零出价 +2 分",
			bidSubmitted: "已出 {{n}}",
			waiting: "等待中…",
			discardPileAria: "弃掉 {{pile}} 顶板",
			optCommodities: "财货扩展",
			optBase: "基础",
			optWithCommodities: "含财货",
			eliminated: "印钱最多,淘汰",
			spentAria: "总印钱",
			scTiles: "公司",
			scZero: "零出价",
			scNat: "国有化",
			scMon: "垄断",
			scDiv: "多样化",
			scComm: "财货",
			scOil: "石油奖励",
			scGold: "金市崩盘",
			scLeast: "印钱最少",
			guideTilesSmall: "公司板块(3–4 人局)",
			guideTilesFive: "公司板块(5 人局)",
			guideCommodities: "财货堆面值(财货扩展)",
			hintOpenBid: "开价 {{n}}",
			hintBid: "出价 {{n}}",
			hintBidZero: "零出价",
			hintChoosePile: "拿{{pile}}堆顶板"
		},
		en: {
			name: "QE",
			desc: "Print money to buy companies — the biggest spender is out",
			rules: "Goal: play a central bank printing money to buy companies. Highest score wins — but the biggest spender is eliminated, and the smallest spender gets a bonus.\nSetup:\n· Shuffle 16 company tiles (3–4 players) or 15 (5 players) into a deck.\n· Each player is a nation and secretly draws an industry token (counts as +1 of that industry for monopolies).\nAuction flow: auction one company at a time. Play sixteen auctions with three or four players, or fifteen auctions with five players.\n· The auctioneer reveals a company and openly bids any positive integer.\n· Others bid secretly (0 or any positive integer, never equal to the opening bid).\n· Highest bid wins the company; the amount stays secret on the tile back. If the auctioneer wins, the amount is public.\n· Zero bids: a player who bids zero scores two points, at most once per round. A round ends after every player has been auctioneer once. Do not use this rule with three players.\n· If the highest bid is tied, the tied players secretly bid again; their bids still cannot equal the opening bid. After three consecutive ties, the highest bidder among players outside the tie wins. If all players are still tied, discard the company tile.\n· Auctioneer passes left.\nScoring:\nYour score includes five categories:\n· Points printed on company tiles.\n· Points earned from zero bids.\n· Nationalization points for companies of your nation.\n· Monopoly points for companies of the same industry, including your industry token.\n· Diversification points for sets of different industries.\n· Biggest total spender is eliminated (ties are all eliminated); smallest spender scores 6 VP (7 with 5 players, ties all get it). Tie-break: lower spend wins.\nCommodities expansion (optional):\n· Each auction, the second-highest bidder takes the top tile of one pile (type public, value secret); that bid adds to their spend, and the auctioneer records it as a sale, offsetting their own total.\n· Zero bids no longer score. When the gold pile is empty, each gold commodity tile loses three points. The player with the most oil commodity tiles scores five points; tied players divide these points equally, rounding down.\n· If the second-highest bid is tied, the highest bidder still receives the company. All other players bid again for the commodity. After three consecutive ties, the auctioneer chooses a pile and discards its top tile.",
			vp: "{{n}} VP",
			nationUS: "USA",
			nationEU: "Europe",
			nationCN: "China",
			nationJP: "Japan",
			nationUK: "UK",
			indAgri: "Agriculture",
			indHousing: "Housing",
			indFin: "Finance",
			indManuf: "Manufacturing",
			indGov: "Government",
			pileGold: "Gold",
			pileOil: "Oil",
			pileCrypto: "Crypto",
			errNotOpen: "Cannot open bid now",
			errNotBidder: "Not your turn to bid",
			errSameAsOpening: "Bid cannot equal the opening bid",
			errNotChooser: "Not your turn to choose",
			errPileEmpty: "That pile is empty",
			errNotDiscarder: "Not your turn to discard",
			errNoPeek: "Peek only in 5-player games",
			errPeekUsed: "Only one peek per game",
			errBadPhase: "Not allowed in this phase",
			notOpening: "Cannot equal opening {{n}}",
			backspace: "Backspace",
			submitBid: "Submit bid",
			openPrompt: "You are the auctioneer: open the bidding",
			openWait: "Waiting for {{name}} to open…",
			bidPrompt: "Bid secretly (0 = pass)",
			rebidPrompt: "Tie! Bid again",
			bidWait: "Waiting for bids…",
			choosePrompt: "Second highest: pick a pile",
			chooseWait: "Waiting for runner-up…",
			discardPrompt: "Three ties: discard a pile top",
			discardWait: "Waiting for auctioneer…",
			reveal: "Revealing…",
			done: "Game over",
			auctionProgress: "Auction {{n}}/{{total}}",
			opening: "Opening",
			bidCount: "{{n}}/{{total}} in",
			goldCrash: "⚠ Gold crash: gold tiles −3 VP each",
			mySpentAria: "My total printed",
			estimateAria: "Live VP estimate",
			estimate: "Est. {{n}} VP",
			tokenAria: "Hidden industry token: {{industry}}",
			myToken: "Token",
			auctioneerAria: "Auctioneer",
			myLoot: "My loot",
			log: "Auction log",
			peekAria: "Peek at this winning bid",
			flowOut: "No sale",
			winnerTakes: "{{name}} wins",
			commodityTo: "{{pile}} → {{name}}",
			zeroGain: "{{names}} bid 0 for +2 VP",
			bidSubmitted: "Bid {{n}} in",
			waiting: "Waiting…",
			discardPileAria: "Discard {{pile}} top",
			optCommodities: "Commodities expansion",
			optBase: "Base",
			optWithCommodities: "With commodities",
			eliminated: "Most printed, eliminated",
			spentAria: "Total printed",
			scTiles: "Companies",
			scZero: "Zero bids",
			scNat: "Nationalization",
			scMon: "Monopoly",
			scDiv: "Diversity",
			scComm: "Commodities",
			scOil: "Oil bonus",
			scGold: "Gold crash",
			scLeast: "Least printed",
			guideTilesSmall: "Company tiles (3–4 players)",
			guideTilesFive: "Company tiles (5 players)",
			guideCommodities: "Commodity pile values (expansion)",
			hintOpenBid: "Open at {{n}}",
			hintBid: "Bid {{n}}",
			hintBidZero: "Bid zero",
			hintChoosePile: "Take the {{pile}} pile top"
		}
	}
};
//#endregion
export { Ye as default };
