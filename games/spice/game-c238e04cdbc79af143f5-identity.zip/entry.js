import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { createContext as n, useContext as r, useEffect as i, useRef as a, useState as o } from "react";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as c } from "@bgparty/sdk/fx/delta-number";
import { IconPile as l } from "@bgparty/sdk/icons";
import { useI18nSettings as u, useT as d } from "@bgparty/sdk/i18n";
import { PhaseBanner as f } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as p, seatName as m } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as h } from "@bgparty/sdk/ui/game-screen";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { Floater as y, FlySprite as b } from "@bgparty/sdk/fx/primitives";
import { AVATARS as x } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as S } from "@bgparty/sdk/player-colors";
import { Confetti as C } from "@bgparty/sdk/ui/confetti";
//#region src/games/spice/cards.ts
var w = [
	"y",
	"r",
	"g",
	"b"
], T = {
	y: "r",
	r: "g",
	g: "b",
	b: null
}, E = () => ({
	y: 0,
	r: 0,
	g: 0,
	b: 0
}), D = (e) => w.reduce((t, n) => t + e[n], 0), O = (e) => {
	let t = E();
	for (let n of e) t[n] += 1;
	return t;
}, k = (e, t) => ({
	id: e,
	kind: "spice",
	gain: O(t)
}), A = (e, t, n) => ({
	id: e,
	kind: "trade",
	cost: O(t),
	gain: O(n)
}), j = [{
	id: "create2",
	kind: "spice",
	gain: O("yy")
}, {
	id: "upgrade2",
	kind: "upgrade",
	times: 2
}], M = [
	k("m0", "g"),
	k("m1", "yyy"),
	k("m2", "yyyy"),
	k("m3", "b"),
	k("m4", "gy"),
	k("m5", "ry"),
	k("m6", "rr"),
	k("m7", "ryy"),
	A("m8", "g", "rr"),
	A("m9", "yy", "g"),
	A("m10", "yyy", "b"),
	A("m11", "yyyy", "gb"),
	A("m12", "yyyy", "ggg"),
	A("m13", "b", "ggg"),
	A("m14", "b", "gry"),
	A("m15", "b", "rrr"),
	A("m16", "r", "yyy"),
	A("m17", "g", "rr"),
	A("m18", "b", "rryy"),
	A("m19", "b", "gyyy"),
	A("m20", "g", "ryyyy"),
	A("m21", "ry", "b"),
	A("m22", "yy", "rr"),
	A("m23", "gg", "bb"),
	A("m24", "rr", "gg"),
	A("m25", "rr", "byy"),
	A("m26", "gg", "brr"),
	A("m27", "gg", "bry"),
	A("m28", "rr", "gyy"),
	A("m29", "gg", "rryy"),
	A("m30", "yyy", "rg"),
	A("m31", "gyy", "bb"),
	A("m32", "rrr", "bb"),
	A("m33", "rrr", "bgy"),
	A("m34", "rrr", "bgg"),
	A("m35", "ggg", "bbb"),
	A("m36", "rrr", "ggyy"),
	A("m37", "yy", "rrr"),
	A("m38", "yyy", "gg"),
	A("m39", "yyyy", "bb"),
	A("m40", "bb", "ggrrr"),
	A("m41", "bb", "gggry"),
	{
		id: "m42",
		kind: "upgrade",
		times: 3
	}
], N = [...j, ...M], P = (e) => {
	let t = N.find((t) => t.id === e);
	if (!t) throw Error(`unknown merchant card ${e}`);
	return t;
}, F = [
	{
		id: "p0",
		points: 10,
		cost: O("yybb")
	},
	{
		id: "p1",
		points: 9,
		cost: O("yyrb")
	},
	{
		id: "p2",
		points: 20,
		cost: O("bbbbb")
	},
	{
		id: "p3",
		points: 20,
		cost: O("yrgbbb")
	},
	{
		id: "p4",
		points: 15,
		cost: O("yyrrbb")
	},
	{
		id: "p5",
		points: 12,
		cost: O("rrrgg")
	},
	{
		id: "p6",
		points: 13,
		cost: O("rrggg")
	},
	{
		id: "p7",
		points: 10,
		cost: O("rrgg")
	},
	{
		id: "p8",
		points: 13,
		cost: O("yyrrgg")
	},
	{
		id: "p9",
		points: 7,
		cost: O("yyyrr")
	},
	{
		id: "p10",
		points: 12,
		cost: O("yrgb")
	},
	{
		id: "p11",
		points: 18,
		cost: O("gggbb")
	},
	{
		id: "p12",
		points: 12,
		cost: O("rrbb")
	},
	{
		id: "p13",
		points: 12,
		cost: O("rrgb")
	},
	{
		id: "p14",
		points: 12,
		cost: O("gggg")
	},
	{
		id: "p15",
		points: 11,
		cost: O("yyggg")
	},
	{
		id: "p16",
		points: 9,
		cost: O("yyygg")
	},
	{
		id: "p17",
		points: 19,
		cost: O("rrgggbb")
	},
	{
		id: "p18",
		points: 16,
		cost: O("yrrrgb")
	},
	{
		id: "p19",
		points: 10,
		cost: O("rrrrr")
	},
	{
		id: "p20",
		points: 14,
		cost: O("rrrbb")
	},
	{
		id: "p21",
		points: 17,
		cost: O("ggggb")
	},
	{
		id: "p22",
		points: 15,
		cost: O("ggggg")
	},
	{
		id: "p23",
		points: 12,
		cost: O("yggb")
	},
	{
		id: "p24",
		points: 8,
		cost: O("rrrr")
	},
	{
		id: "p25",
		points: 8,
		cost: O("yygg")
	},
	{
		id: "p26",
		points: 6,
		cost: O("yyrr")
	},
	{
		id: "p27",
		points: 8,
		cost: O("yyrrr")
	},
	{
		id: "p28",
		points: 14,
		cost: O("yybbb")
	},
	{
		id: "p29",
		points: 18,
		cost: O("yrgggb")
	},
	{
		id: "p30",
		points: 16,
		cost: O("rrbbb")
	},
	{
		id: "p31",
		points: 16,
		cost: O("bbbb")
	},
	{
		id: "p32",
		points: 14,
		cost: O("gggb")
	},
	{
		id: "p33",
		points: 17,
		cost: O("yyggbb")
	},
	{
		id: "p34",
		points: 11,
		cost: O("yyybb")
	},
	{
		id: "p35",
		points: 14,
		cost: O("yyrgb")
	}
], I = (e) => {
	let t = F.find((t) => t.id === e);
	if (!t) throw Error(`unknown point card ${e}`);
	return t;
}, L = {
	id: "spice",
	tier: "released",
	mechanics: ["engine-building", "hand-management"],
	interactionTags: [],
	nameKey: "games.spice.name",
	descKey: "games.spice.desc",
	rulesKey: "games.spice.rules",
	icon: "🧂",
	iconImg: "games/spice.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/spice/en.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	accent: "#d97706",
	releasedAt: "2026-09-23",
	search: {
		py: "xiang liao zhi lu",
		init: "xlzl"
	},
	hotseat: "cover"
}, R = t.enum([
	"y",
	"r",
	"g",
	"b"
]), ee = t.union([
	t.object({
		type: t.literal("play"),
		cardId: t.string(),
		times: t.int().nonnegative().optional(),
		upgrades: t.array(R).max(3).optional()
	}),
	t.object({
		type: t.literal("acquire"),
		index: t.int().nonnegative(),
		pay: t.array(R)
	}),
	t.object({ type: t.literal("rest") }),
	t.object({
		type: t.literal("claim"),
		index: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("discard"),
		spices: t.array(R).min(1)
	})
]), z = t.string(), B = t.object({
	y: t.int().nonnegative(),
	r: t.int().nonnegative(),
	g: t.int().nonnegative(),
	b: t.int().nonnegative()
}), te = t.object({
	phase: t.enum([
		"play",
		"discard",
		"done"
	]),
	turn: z,
	merchantRow: t.array(t.object({
		cardId: t.string(),
		spices: B
	})),
	merchantDeck: t.int().nonnegative(),
	pointRow: t.array(t.string()),
	pointDeck: t.int().nonnegative(),
	goldCoins: t.int().nonnegative(),
	silverCoins: t.int().nonnegative(),
	lastRound: t.boolean(),
	mustDiscard: t.int().nonnegative(),
	players: t.array(t.object({
		rid: z,
		caravan: B,
		played: t.array(t.string()),
		handCount: t.int().nonnegative(),
		claimed: t.array(t.string()),
		gold: t.int().nonnegative(),
		silver: t.int().nonnegative()
	}))
}), ne = t.object({ hand: t.array(t.string()) }), re = 6, V = 5, H = (e) => e <= 3 ? 6 : 5;
function U(e, t) {
	let n = e.claimed[t].reduce((e, t) => e + I(t).points, 0), r = e.coins[t].gold * 3 + e.coins[t].silver, i = w.filter((e) => e !== "y").reduce((n, r) => n + e.caravan[t][r], 0);
	return n + r + i;
}
var W = (e, t, n = 1) => {
	for (let r of w) e[r] += t[r] * n;
}, G = (e, t) => w.every((n) => e[n] >= t[n]);
function ie(t, n, r) {
	let i = 0, a = (t) => {
		for (let n = t.length - 1; n > 0; --n) {
			let a = e(r, i, n + 1);
			i += 1, [t[n], t[a]] = [t[a], t[n]];
		}
		return t;
	}, o = {
		players: n,
		turnIdx: 0,
		phase: "play",
		merchantDeck: a(M.map((e) => e.id)),
		merchantRow: [],
		pointDeck: a(F.map((e) => e.id)),
		pointRow: [],
		goldCoins: n.length * 2,
		silverCoins: n.length * 2,
		caravan: {},
		hand: {},
		played: {},
		claimed: {},
		coins: {},
		lastRound: !1,
		mustDiscard: 0
	};
	for (let e = 0; e < re; e += 1) o.merchantRow.push({
		cardId: o.merchantDeck.pop(),
		spices: E()
	});
	for (let e = 0; e < V; e += 1) o.pointRow.push(o.pointDeck.pop());
	return n.forEach((e, t) => {
		let n = E();
		t === 0 ? n.y = 3 : t <= 2 ? n.y = 4 : (n.y = 3, n.r = 1), o.caravan[e] = n, o.hand[e] = ["create2", "upgrade2"], o.played[e] = [], o.claimed[e] = [], o.coins[e] = {
			gold: 0,
			silver: 0
		};
	}), {
		state: o,
		fx: []
	};
}
function ae(e) {
	let t = D(e.caravan[e.players[e.turnIdx]]) - 10;
	if (t > 0) {
		e.phase = "discard", e.mustDiscard = t;
		return;
	}
	oe(e);
}
function oe(e) {
	let t = e.players[e.turnIdx];
	!e.lastRound && e.claimed[t].length >= H(e.players.length) && (e.lastRound = !0);
	let n = (e.turnIdx + 1) % e.players.length;
	if (e.lastRound && n === 0) {
		e.phase = "done";
		return;
	}
	e.turnIdx = n, e.phase = "play";
}
function se(e, t, n) {
	if (e.phase === "done") return { code: "games.spice.errNotYourTurn" };
	let r = n.by;
	if (e.players[e.turnIdx] !== r) return { code: "games.spice.errNotYourTurn" };
	if (t.type === "discard") {
		if (e.phase !== "discard" || t.spices.length !== e.mustDiscard) return { code: "games.spice.errBadDiscard" };
		let n = E();
		for (let e of t.spices) n[e] += 1;
		if (!G(e.caravan[r], n)) return { code: "games.spice.errBadDiscard" };
		let i = structuredClone(e);
		return W(i.caravan[r], n, -1), i.mustDiscard = 0, oe(i), {
			state: i,
			fx: [{
				kind: "discard",
				rid: r,
				data: { spices: t.spices }
			}]
		};
	}
	if (e.phase !== "play") return { code: "games.spice.errNotYourTurn" };
	if (t.type === "play") {
		let n = e.hand[r].includes(t.cardId) ? P(t.cardId) : null;
		if (!n) return { code: "games.spice.errBadCard" };
		let i = structuredClone(e);
		i.hand[r] = i.hand[r].filter((e) => e !== t.cardId), i.played[r].push(t.cardId);
		let a = { cardId: t.cardId };
		if (n.kind === "spice") W(i.caravan[r], n.gain);
		else if (n.kind === "trade") {
			let e = t.times ?? 1, o = E(), s = E();
			if (W(o, n.cost, e), W(s, n.gain, e), !G(i.caravan[r], o)) return { code: "games.spice.errCantAfford" };
			W(i.caravan[r], o, -1), W(i.caravan[r], s), a.times = e;
		} else {
			let e = t.upgrades ?? [];
			if (e.length > n.times) return { code: "games.spice.errBadUpgrade" };
			let o = { ...i.caravan[r] };
			for (let t of e) {
				let e = T[t];
				if (e === null || o[t] <= 0) return { code: "games.spice.errBadUpgrade" };
				--o[t], o[e] += 1;
			}
			i.caravan[r] = o, a.upgrades = e;
		}
		return ae(i), {
			state: i,
			fx: [{
				kind: "play",
				rid: r,
				data: a
			}]
		};
	}
	if (t.type === "acquire") {
		let n = e.merchantRow[t.index];
		if (!n) return { code: "games.spice.errBadCard" };
		if (t.pay.length !== t.index) return { code: "games.spice.errBadPay" };
		let i = E();
		for (let e of t.pay) i[e] += 1;
		if (!G(e.caravan[r], i)) return { code: "games.spice.errBadPay" };
		let a = structuredClone(e);
		W(a.caravan[r], i, -1);
		for (let e = 0; e < t.index; e += 1) a.merchantRow[e].spices[t.pay[e]] += 1;
		W(a.caravan[r], n.spices);
		let o = a.merchantRow.length;
		a.merchantRow.splice(t.index, 1);
		let s = a.merchantDeck.pop();
		return s && a.merchantRow.push({
			cardId: s,
			spices: E()
		}), a.hand[r].push(n.cardId), ae(a), {
			state: a,
			fx: [{
				kind: "acquire",
				rid: r,
				data: {
					cardId: n.cardId,
					slot: t.index,
					rowLen: o
				}
			}]
		};
	}
	if (t.type === "rest") {
		if (e.played[r].length === 0) return { code: "games.spice.errBadRest" };
		let t = structuredClone(e);
		return t.hand[r].push(...t.played[r]), t.played[r] = [], oe(t), {
			state: t,
			fx: [{
				kind: "rest",
				rid: r,
				data: {}
			}]
		};
	}
	if (t.type === "claim") {
		let n = e.pointRow[t.index];
		if (!n) return { code: "games.spice.errBadCard" };
		let i = I(n);
		if (!G(e.caravan[r], i.cost)) return { code: "games.spice.errCantAfford" };
		let a = structuredClone(e);
		W(a.caravan[r], i.cost, -1), a.pointRow.splice(t.index, 1);
		let o = a.pointDeck.pop();
		o && a.pointRow.push(o), a.claimed[r].push(n);
		let s = null;
		return t.index === 0 ? a.goldCoins > 0 ? s = "gold" : a.silverCoins > 0 && (s = "silver") : t.index === 1 && a.goldCoins > 0 && a.silverCoins > 0 && (s = "silver"), s === "gold" ? (--a.goldCoins, a.coins[r].gold += 1) : s === "silver" && (--a.silverCoins, a.coins[r].silver += 1), ae(a), {
			state: a,
			fx: [{
				kind: "claim",
				rid: r,
				data: {
					cardId: n,
					slot: t.index,
					coin: s ?? ""
				}
			}]
		};
	}
	return { code: "games.spice.errBadCard" };
}
function ce(e, t) {
	return {
		public: {
			phase: e.phase,
			turn: e.players[e.turnIdx],
			merchantRow: e.merchantRow.map((e) => ({
				cardId: e.cardId,
				spices: { ...e.spices }
			})),
			merchantDeck: e.merchantDeck.length,
			pointRow: [...e.pointRow],
			pointDeck: e.pointDeck.length,
			goldCoins: e.goldCoins,
			silverCoins: e.silverCoins,
			lastRound: e.lastRound,
			mustDiscard: e.mustDiscard,
			players: e.players.map((t) => ({
				rid: t,
				caravan: { ...e.caravan[t] },
				played: [...e.played[t]],
				handCount: e.hand[t].length,
				claimed: [...e.claimed[t]],
				gold: e.coins[t].gold,
				silver: e.coins[t].silver
			}))
		},
		private: { hand: [...e.hand[t] ?? []] }
	};
}
function le(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = new Map(e.players.map((e, t) => [e, t])), n = [...e.players].sort((n, r) => {
		let i = U(e, r) - U(e, n);
		return i === 0 ? (t.get(r) ?? 0) - (t.get(n) ?? 0) : i;
	}), r = U(e, n[0]), i = t.get(n[0]) ?? 0, a = n.filter((n) => U(e, n) === r && (t.get(n) ?? 0) === i), o = {};
	for (let t of e.players) o[t] = U(e, t);
	return {
		phase: "done",
		winner: a,
		ranking: n,
		scores: o
	};
}
var ue = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: L,
	schemas: {
		action: ee,
		publicView: te,
		privateView: ne
	},
	setup: ie,
	reduce: se,
	viewFor: ce,
	status: le
}, de = {
	y: {
		bg: "#e2ad22",
		fg: "#3f3004",
		deep: "#9b6514"
	},
	r: {
		bg: "#cc4434",
		fg: "#ffffff",
		deep: "#92291f"
	},
	g: {
		bg: "#28865d",
		fg: "#ffffff",
		deep: "#17553c"
	},
	b: {
		bg: "#795035",
		fg: "#ffffff",
		deep: "#4f2d1a"
	}
};
function K({ color: e, size: t = 14 }) {
	let n = de[e];
	return /* @__PURE__ */ v("svg", {
		width: t,
		height: t,
		viewBox: "0 0 16 16",
		"aria-hidden": !0,
		className: "flex-none",
		children: [/* @__PURE__ */ _("rect", {
			x: 1,
			y: 1,
			width: 14,
			height: 14,
			rx: 2.5,
			fill: n.bg,
			stroke: n.deep,
			strokeWidth: 1.6
		}), /* @__PURE__ */ _("path", {
			d: "M3.8 4.6 H12",
			fill: "none",
			stroke: "#fff8df",
			strokeWidth: 1.4,
			strokeLinecap: "round",
			opacity: .65
		})]
	});
}
function fe({ bag: e, size: t = 14, gap: n = 1 }) {
	return /* @__PURE__ */ _("span", {
		className: "inline-flex flex-none items-center",
		style: { gap: n },
		children: w.flatMap((n) => Array.from({ length: e[n] }, (e, r) => /* @__PURE__ */ _(K, {
			color: n,
			size: t
		}, `${n}${r}`)))
	});
}
function pe({ size: e = 20 }) {
	return /* @__PURE__ */ v("svg", {
		width: e,
		height: e,
		viewBox: "0 0 20 20",
		"aria-hidden": !0,
		className: "flex-none",
		children: [/* @__PURE__ */ _("path", {
			d: "M10 1 18 5.5v9L10 19l-8-4.5v-9Z",
			fill: "#d8e9c7",
			stroke: "#397857",
			strokeWidth: "1.5"
		}), /* @__PURE__ */ _("path", {
			d: "m5.5 10.5 4.5-4 4.5 4m-9 4.1 4.5-4 4.5 4",
			fill: "none",
			stroke: "#2c684f",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})]
	});
}
var me = [
	"25% 68%",
	"53% 55%",
	"83% 46%",
	"10% 58%",
	"65% 67%",
	"93% 57%"
];
function q({ id: e, w: t = 134, h: n = 53, tall: r = !1, artShare: i = .42 }) {
	let a = P(e), o = !r && (t < 100 || n < 45), s = r ? Math.min(2, t / 110) : o ? 1 : Math.min(t / 134, n / 53), c = r ? t - 18 : o ? t - 14 * s : t - 57 * s, l = a.kind === "trade" ? Math.max(D(a.cost), D(a.gain)) : a.kind === "spice" ? D(a.gain) : 4, u = a.kind === "trade" ? 13 * s : a.kind === "spice" && r ? 22 * s + 4 : 0, d = Math.max(7 * s, Math.min((o ? 10 : 13) * s, Math.floor((c - u) / Math.max(1, l)))), f = e === "create2" ? 2 : e === "upgrade2" ? 3 : Number(e.slice(1)) % me.length;
	return /* @__PURE__ */ v("span", {
		className: `spice-merchant-card ${o ? "spice-merchant-card--compact" : ""} ${r ? "spice-merchant-card--tall" : ""} spice-merchant-card--${a.kind}`,
		style: {
			width: t,
			height: n,
			"--spice-card-scale": s,
			"--spice-card-art-height": `${i * 100}%`
		},
		"aria-hidden": !0,
		children: [!o && /* @__PURE__ */ _("img", {
			className: "spice-merchant-card__art",
			src: "./games/spice/market.webp",
			alt: "",
			style: { objectPosition: me[f] }
		}), /* @__PURE__ */ v("span", {
			className: "spice-merchant-card__face",
			children: [
				a.kind === "spice" && /* @__PURE__ */ v("span", {
					className: "spice-merchant-card__gain",
					children: [/* @__PURE__ */ _("span", {
						className: "spice-gain-mark",
						children: /* @__PURE__ */ _("svg", {
							width: 14 * s,
							height: 14 * s,
							viewBox: "0 0 14 14",
							children: /* @__PURE__ */ _("path", {
								d: "M7 2v10M2 7h10",
								stroke: "currentColor",
								strokeWidth: "2",
								strokeLinecap: "round"
							})
						})
					}), /* @__PURE__ */ _(fe, {
						bag: a.gain,
						size: d,
						gap: 1
					})]
				}),
				a.kind === "trade" && /* @__PURE__ */ v("span", {
					className: "spice-merchant-card__trade",
					children: [/* @__PURE__ */ v("span", {
						className: "spice-merchant-card__trade-rows",
						children: [/* @__PURE__ */ _(fe, {
							bag: a.cost,
							size: d,
							gap: 1
						}), /* @__PURE__ */ _(fe, {
							bag: a.gain,
							size: d,
							gap: 1
						})]
					}), /* @__PURE__ */ _("svg", {
						className: "spice-merchant-card__trade-arrow",
						width: 13 * s,
						height: 31 * s,
						viewBox: "0 0 13 31",
						children: /* @__PURE__ */ _("path", {
							d: "M6.5 2v25m-5-5 5 5 5-5",
							fill: "none",
							stroke: "#8e4f25",
							strokeWidth: "2",
							strokeLinecap: "round",
							strokeLinejoin: "round"
						})
					})]
				}),
				a.kind === "upgrade" && /* @__PURE__ */ v("span", {
					className: "spice-merchant-card__upgrade",
					children: [/* @__PURE__ */ _("span", {
						className: "spice-merchant-card__upgrade-spices",
						children: w.map((e) => /* @__PURE__ */ _(K, {
							color: e,
							size: (o ? 10 : 11) * s
						}, e))
					}), /* @__PURE__ */ v("span", {
						className: "spice-merchant-card__upgrade-action",
						children: [/* @__PURE__ */ _(pe, { size: (o ? 18 : 20) * s }), /* @__PURE__ */ v("strong", { children: ["×", a.times] })]
					})]
				})
			]
		})]
	});
}
function J({ id: e, w: t = 134, h: n = 53, tall: r = !1, have: i, showNeed: a = !1 }) {
	let o = I(e), s = !r && (t < 100 || n < 45), c = r ? Math.min(2, t / 130) : s ? 1 : Math.min(t / 134, n / 53), l = D(o.cost), u = Math.max((s ? 6 : 7) * c, Math.min((s ? 9 : 12) * c, Math.floor((t - (r ? 18 : (s ? 38 : 57) * c) - (l - 1)) / l)));
	return /* @__PURE__ */ v("span", {
		className: `spice-point-card ${s ? "spice-point-card--compact" : ""} ${r ? "spice-point-card--tall" : ""}`,
		style: {
			width: t,
			height: n,
			"--spice-card-scale": c
		},
		"aria-hidden": !0,
		children: [/* @__PURE__ */ _("span", {
			className: "spice-point-card__score",
			children: o.points
		}), /* @__PURE__ */ _("span", {
			className: "spice-point-card__cost",
			children: w.flatMap((e) => Array.from({ length: o.cost[e] }, (t, n) => /* @__PURE__ */ _("span", {
				className: a ? n < (i?.[e] ?? 0) ? "spice-point-card__have" : "spice-point-card__missing" : void 0,
				children: /* @__PURE__ */ _(K, {
					color: e,
					size: u
				})
			}, `${e}${n}`)))
		})]
	});
}
function he({ kind: e, count: t }) {
	let n = e === "gold" ? "#f5bf36" : "#d0d8d9", r = e === "gold" ? "#a16207" : "#818f97";
	return /* @__PURE__ */ v("span", {
		className: "relative inline-flex flex-none",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("svg", {
			width: 22,
			height: 22,
			viewBox: "0 0 22 22",
			children: [
				/* @__PURE__ */ _("circle", {
					cx: 11,
					cy: 11,
					r: 9.5,
					fill: n,
					stroke: r,
					strokeWidth: 1.8
				}),
				/* @__PURE__ */ _("circle", {
					cx: 11,
					cy: 11,
					r: 6,
					fill: "none",
					stroke: r,
					strokeWidth: 1,
					opacity: .6
				}),
				/* @__PURE__ */ _("path", {
					d: "M5.5 8 Q11 4.8 16.5 8",
					fill: "none",
					stroke: "#ffffff",
					strokeWidth: 1.4,
					strokeLinecap: "round",
					opacity: .5
				})
			]
		}), /* @__PURE__ */ _("span", {
			className: "absolute -top-1.5 -right-1.5 grid size-4 place-items-center rounded-full border-2 border-ink bg-surface font-mono text-[9px] leading-none font-extrabold tabular-nums text-ink",
			children: t
		})]
	});
}
function ge({ w: e = 34, h: t = 48 }) {
	return /* @__PURE__ */ _("span", {
		className: "relative inline-flex flex-none overflow-hidden rounded-md border-2 border-ink",
		style: {
			width: e,
			height: t
		},
		"aria-hidden": !0,
		children: /* @__PURE__ */ v("svg", {
			className: "absolute inset-0 size-full",
			viewBox: "0 0 34 48",
			preserveAspectRatio: "none",
			children: [
				/* @__PURE__ */ _("rect", {
					width: 34,
					height: 48,
					fill: "#6b3f16"
				}),
				/* @__PURE__ */ _("path", {
					d: "M17 8 L27 24 L17 40 L7 24 Z",
					fill: "none",
					stroke: "#e8c86a",
					strokeWidth: 1,
					opacity: .7
				}),
				/* @__PURE__ */ _("path", {
					d: "M17 13 L22.5 24 L17 35 L11.5 24 Z",
					fill: "none",
					stroke: "#e8c86a",
					strokeWidth: .7,
					opacity: .5
				}),
				/* @__PURE__ */ _("path", {
					d: "M17 19.5 L21.5 24 L17 28.5 L12.5 24 Z",
					fill: "#e8c86a",
					opacity: .5
				})
			]
		})
	});
}
//#endregion
//#region src/games/spice/view-player.tsx
function _e(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ _(Ce, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var ve = (e, t) => w.every((n) => e[n] >= t[n]), ye = {
	large: !1,
	merchantW: 134,
	merchantH: 53,
	pointW: 134,
	pointH: 53,
	handW: 84,
	handH: 44,
	previewH: 34
}, Y = n(ye);
function be() {
	let e = a(null), t = a(null), n = a(null), [r, s] = o(ye);
	return i(() => {
		let r = () => {
			if (!e.current || !t.current || !n.current) return;
			let r = e.current.clientWidth, i = e.current.clientHeight;
			if (r < 1e3 || i < 600 || r <= i) {
				s((e) => e.large ? ye : e);
				return;
			}
			let a = Math.min(164, Math.max(100, r * .085)), o = t.current.clientWidth - a - 32, c = Math.max(44, Math.floor((t.current.clientHeight - 22) / 2 - 34)), l = r >= 1600 ? 6 : 5, u = Math.floor((n.current.clientWidth - 20 - (l - 1) * 8) / l), d = Math.floor((n.current.clientHeight - 40) / 2 - 8), f = {
				large: !0,
				merchantW: Math.max(134, Math.floor((o - 50) / 6) - 14),
				merchantH: c,
				pointW: Math.max(134, Math.floor((o - 40) / 5)),
				pointH: c,
				handW: u,
				handH: Math.max(44, d),
				previewH: 52
			};
			s((e) => Object.keys(f).every((t) => e[t] === f[t]) ? e : f);
		}, i = new ResizeObserver(r);
		for (let r of [
			e.current,
			t.current,
			n.current
		]) r && i.observe(r);
		return r(), () => i.disconnect();
	}, []), {
		root: e,
		board: t,
		rack: n,
		sizes: r
	};
}
function xe(e, t) {
	let n = Infinity;
	for (let r of w) e[r] <= 0 || (n = Math.min(n, Math.floor(t[r] / e[r])));
	return n === Infinity ? 0 : n;
}
function Se(e, t, n, r) {
	let i = e.filter((e) => e === t).length;
	return i > 0 && (i >= n || e.length >= r) ? e.filter((e) => e !== t) : i >= n || e.length >= r ? e : [...e, t];
}
function Ce({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let a = d(), { root: s, board: l, rack: u, sizes: m } = be(), g = (e) => n.find((t) => t.rid === e)?.name ?? e, y = e.players.find((e) => e.rid === r), b = e.phase === "play" && e.turn === r, x = e.phase === "discard" && e.turn === r, [S, C] = o(null), [w, E] = o(1), [O, k] = o([]), [A, j] = o([]), [M, N] = o([]), F = `${e.phase}|${e.turn}|${e.lastRound}|${e.merchantRow.map((e) => e.cardId).join(".")}|${e.pointRow.join(".")}`, [R, ee] = o(F);
	R !== F && (ee(F), C(null), E(1), k([]), j([]), N([]));
	let z = (e) => {
		C((t) => t?.kind === e.kind && JSON.stringify(t) === JSON.stringify(e) ? null : e), E(1), k([]), j([]);
	}, B = S?.kind === "play" && t?.hand.includes(S.cardId) ? P(S.cardId) : null, te = B?.kind === "trade" && y ? xe(B.cost, y.caravan) : 0, ne = B?.kind === "upgrade" ? B.times : 0, re = (t) => {
		if (x) {
			if (!y) return;
			N((n) => Se(n, t, y.caravan[t], e.mustDiscard));
			return;
		}
		if (b && y) {
			if (S?.kind === "play" && B?.kind === "upgrade") {
				if (T[t] === null) return;
				k((e) => Se(e, t, y.caravan[t], ne));
				return;
			}
			S?.kind === "acquire" && j((e) => Se(e, t, y.caravan[t], S.index));
		}
	}, V, H;
	x ? (V = "warn", H = a("games.spice.discardPrompt", { n: e.mustDiscard })) : e.phase === "discard" ? (V = "info", H = a("games.spice.discardWait", { name: g(e.turn) })) : b ? (V = "accent", H = a("games.spice.turnYou")) : (V = "info", H = a("games.spice.turnWait", { name: g(e.turn) }));
	let U = (t) => y !== void 0 && ve(y.caravan, I(e.pointRow[t]).cost), W = y && /* @__PURE__ */ v("div", {
		className: "spice-dock safe-b relative flex flex-none flex-col gap-1",
		children: [/* @__PURE__ */ _(Pe, {
			caravan: y.caravan,
			pickable: x || S?.kind === "play" && B?.kind === "upgrade" || S?.kind === "acquire",
			mode: x ? "discard" : S?.kind === "acquire" ? "pay" : B?.kind === "upgrade" ? "upgrade" : null,
			pickedCounts: Te(x ? M : S?.kind === "acquire" ? A : O),
			onPick: re
		}), /* @__PURE__ */ _("div", {
			ref: u,
			className: "spice-hand-area",
			children: /* @__PURE__ */ _(Fe, {
				rid: r,
				hand: t?.hand ?? [],
				played: y.played,
				myTurn: b,
				selected: S?.kind === "play" ? S.cardId : null,
				onPick: (e) => b && z({
					kind: "play",
					cardId: e
				}),
				onRest: () => i({ type: "rest" })
			})
		})]
	}), G = y && /* @__PURE__ */ _("div", {
		className: `spice-confirm-wrap pointer-events-auto ${S?.kind === "claim" ? "spice-confirm-wrap--claim" : ""}`,
		children: /* @__PURE__ */ _(Ee, {
			t: a,
			sel: S,
			selCard: B,
			me: y,
			times: w,
			tradeMax: te,
			upPicks: O,
			upMax: ne,
			payPicks: A,
			discPicks: M,
			discarding: x,
			pub: e,
			onTimes: E,
			onCancel: () => z(S ?? {
				kind: "claim",
				index: 0
			}),
			onClearDisc: () => N([]),
			send: (e) => {
				i(e), C(null), E(1), k([]), j([]), N([]);
			}
		})
	});
	return /* @__PURE__ */ _(Y.Provider, {
		value: m,
		children: /* @__PURE__ */ _("div", {
			ref: s,
			className: "spice-game h-full",
			style: {
				"--spice-player-count": n.length,
				"--spice-hand-w": `${m.handW}px`,
				"--spice-hand-h": `${m.handH}px`,
				"--spice-merchant-w": `${m.merchantW}px`,
				"--spice-market-h": `${m.merchantH}px`,
				"--spice-point-w": `${m.pointW}px`
			},
			children: /* @__PURE__ */ _(h, {
				adaptive: !0,
				className: "spice-screen",
				scroll: !1,
				actions: W,
				actionsHeight: y ? "spice-actions" : void 0,
				overlay: G,
				banner: /* @__PURE__ */ v("div", {
					className: "spice-banner",
					children: [/* @__PURE__ */ _(f, {
						tone: V,
						text: H,
						chip: e.lastRound ? a("games.spice.lastRound") : void 0,
						accent: L.accent
					}), /* @__PURE__ */ _(p, {
						adaptive: !0,
						variant: "plate",
						members: n,
						myRid: r,
						anchorOf: (e) => `seat:${e}`,
						action: (t) => e.phase !== "done" && t === e.turn ? "pending" : null,
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ v("span", {
								className: "spice-player-status flex w-full flex-nowrap items-center justify-between gap-0.5 font-mono text-sm leading-4.5 font-extrabold tabular-nums whitespace-nowrap",
								children: [
									/* @__PURE__ */ v("span", {
										className: "flex items-center gap-px",
										children: [/* @__PURE__ */ _("span", {
											"aria-hidden": !0,
											className: "text-[10px]",
											children: "🏆"
										}), /* @__PURE__ */ _(c, { value: we(e, t) })]
									}),
									/* @__PURE__ */ v("span", {
										className: "flex items-center gap-0.5",
										children: ["🧺", D(n.caravan)]
									}),
									/* @__PURE__ */ _("span", {
										className: "flex items-center gap-0.5",
										children: a("games.spice.stripClaimed", { n: n.claimed.length })
									}),
									(n.gold > 0 || n.silver > 0) && /* @__PURE__ */ v("span", {
										className: "flex items-center gap-0.5",
										style: { color: L.accent },
										children: [n.gold > 0 && `🪙${n.gold}`, n.silver > 0 && `🥈${n.silver}`]
									})
								]
							}) : null;
						}
					})]
				}),
				children: /* @__PURE__ */ v("div", {
					ref: l,
					className: "spice-board",
					children: [
						/* @__PURE__ */ v("div", {
							className: "spice-board__art",
							"aria-hidden": !0,
							children: [/* @__PURE__ */ _("img", {
								src: "./games/spice/market.webp",
								alt: ""
							}), /* @__PURE__ */ _("span", { children: a("games.spice.sceneTitle") })]
						}),
						/* @__PURE__ */ v("div", {
							className: "spice-board__market",
							children: [/* @__PURE__ */ v("div", {
								className: "spice-board__heading",
								children: [/* @__PURE__ */ v("span", {
									className: "spice-board__heading-title",
									children: [/* @__PURE__ */ _(ge, {
										w: 17,
										h: 19
									}), a("games.spice.market")]
								}), /* @__PURE__ */ _("span", { children: e.merchantDeck })]
							}), /* @__PURE__ */ _(Me, {
								pub: e,
								myTurn: b,
								caravan: y?.caravan,
								selected: S?.kind === "acquire" ? S.index : null,
								payPicks: A,
								onPick: (e) => b && z({
									kind: "acquire",
									index: e
								})
							})]
						}),
						/* @__PURE__ */ v("div", {
							className: "spice-board__route",
							"aria-hidden": !0,
							children: [/* @__PURE__ */ _("div", {
								className: "spice-board__heading",
								children: "\xA0"
							}), e.merchantRow.map((e, t) => /* @__PURE__ */ _("span", {
								className: `spice-board__route-stop ${S?.kind === "acquire" && t < S.index ? "spice-board__route-stop--pay" : ""}`,
								children: t === 0 ? a("games.spice.freeShort") : t
							}, t))]
						}),
						/* @__PURE__ */ v("div", {
							className: "spice-board__orders",
							children: [/* @__PURE__ */ v("div", {
								className: "spice-board__heading",
								children: [/* @__PURE__ */ v("span", {
									className: "spice-board__heading-title",
									children: [/* @__PURE__ */ _(ge, {
										w: 17,
										h: 19
									}), a("games.spice.orders")]
								}), /* @__PURE__ */ _("span", { children: e.pointDeck })]
							}), /* @__PURE__ */ _(Ae, {
								pub: e,
								myTurn: b,
								caravan: y?.caravan,
								claimAffordable: U,
								selected: S?.kind === "claim" ? S.index : null,
								onPick: (e) => b && z({
									kind: "claim",
									index: e
								})
							})]
						}),
						/* @__PURE__ */ _("div", {
							className: "spice-board__foot",
							children: S?.kind === "acquire" ? a("games.spice.payHint", { n: S.index }) : S?.kind === "claim" ? a("games.spice.claimHint") : a("games.spice.marketHint")
						})
					]
				})
			})
		})
	});
}
function we(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return n ? n.claimed.reduce((e, t) => e + I(t).points, 0) + n.gold * 3 + n.silver : 0;
}
function Te(e) {
	let t = E();
	for (let n of e) t[n] += 1;
	return t;
}
function Ee({ t: e, sel: t, selCard: n, me: i, times: a, tradeMax: o, upPicks: s, upMax: c, payPicks: l, discPicks: u, discarding: d, pub: f, onTimes: p, onCancel: m, onClearDisc: h, send: y }) {
	let b = r(Y);
	if (d && i) return /* @__PURE__ */ v("div", {
		className: "spice-confirm flex min-h-12 items-center gap-2 px-2 py-1",
		children: [
			/* @__PURE__ */ v("span", {
				className: "flex min-w-0 flex-1 items-center gap-1 text-sm font-extrabold",
				children: [u.map((e, t) => /* @__PURE__ */ _(K, {
					color: e,
					size: 18
				}, `${e}${t}`)), /* @__PURE__ */ v("span", {
					className: "ml-1 font-mono tabular-nums",
					children: [
						u.length,
						"/",
						f.mustDiscard
					]
				})]
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				className: "btn-quiet min-h-11 px-3 text-sm",
				onClick: h,
				children: e("games.spice.cancel")
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				disabled: u.length !== f.mustDiscard,
				className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
				style: { background: L.accent },
				onClick: () => y({
					type: "discard",
					spices: u
				}),
				children: e("games.spice.confirm")
			})
		]
	});
	if (!t || !i) return null;
	if (t.kind === "play") {
		if (!n) return null;
		let t = n.kind === "spice" || n.kind === "trade" && o > 0 || n.kind === "upgrade" && s.length >= 0;
		return /* @__PURE__ */ v("div", {
			className: "spice-confirm flex min-h-12 items-center gap-2 px-2 py-1",
			children: [
				/* @__PURE__ */ _(q, {
					id: n.id,
					w: Math.round(134 * b.previewH / 53),
					h: b.previewH
				}),
				/* @__PURE__ */ v("span", {
					className: "flex min-w-0 flex-1 items-center gap-1.5",
					children: [n.kind === "trade" && /* @__PURE__ */ v(g, { children: [
						/* @__PURE__ */ _("button", {
							type: "button",
							className: "btn-quiet min-h-11 min-w-11 text-base",
							disabled: a <= 1,
							onClick: () => p(a - 1),
							children: "−"
						}),
						/* @__PURE__ */ v("span", {
							className: "font-mono text-base font-extrabold tabular-nums",
							children: ["×", Math.min(a, o)]
						}),
						/* @__PURE__ */ _("button", {
							type: "button",
							className: "btn-quiet min-h-11 min-w-11 text-base",
							disabled: a >= o,
							onClick: () => p(a + 1),
							children: "+"
						}),
						o === 0 && /* @__PURE__ */ _("span", {
							className: "truncate text-xs font-bold text-rose-500",
							children: e("games.spice.errCantAfford")
						})
					] }), n.kind === "upgrade" && /* @__PURE__ */ v("span", {
						className: "truncate text-xs font-bold text-ink/70",
						children: [
							e("games.spice.upgradeHint"),
							" ",
							s.length,
							"/",
							c
						]
					})]
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					className: "btn-quiet min-h-11 px-3 text-sm",
					onClick: m,
					children: e("games.spice.cancel")
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					disabled: !t,
					className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
					style: { background: L.accent },
					onClick: () => {
						n.kind === "spice" ? y({
							type: "play",
							cardId: n.id
						}) : n.kind === "trade" ? y({
							type: "play",
							cardId: n.id,
							times: Math.min(a, o)
						}) : y({
							type: "play",
							cardId: n.id,
							upgrades: s
						});
					},
					children: n.kind === "trade" ? e("games.spice.playTrade", { n: Math.min(a, o) }) : n.kind === "upgrade" ? e("games.spice.playUpgrade", { n: s.length }) : e("games.spice.play")
				})
			]
		});
	}
	if (t.kind === "acquire") {
		let n = t.index === 0, r = n || l.length === t.index;
		return /* @__PURE__ */ v("div", {
			className: "spice-confirm flex min-h-12 items-center gap-2 px-2 py-1",
			children: [
				/* @__PURE__ */ _(q, {
					id: f.merchantRow[t.index].cardId,
					w: Math.round(134 * b.previewH / 53),
					h: b.previewH
				}),
				/* @__PURE__ */ _("span", {
					className: "flex min-w-0 flex-1 items-center gap-1 text-sm font-extrabold",
					children: n ? /* @__PURE__ */ _("span", {
						className: "text-emerald-600",
						children: e("games.spice.acquireFree")
					}) : /* @__PURE__ */ v(g, { children: [l.map((e, t) => /* @__PURE__ */ _(K, {
						color: e,
						size: 18
					}, `${e}${t}`)), /* @__PURE__ */ _("span", {
						className: "ml-1 truncate text-xs font-bold text-ink/70",
						children: e("games.spice.payHint", { n: t.index })
					})] })
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					className: "btn-quiet min-h-11 px-3 text-sm",
					onClick: m,
					children: e("games.spice.cancel")
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					disabled: !r,
					className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
					style: { background: L.accent },
					onClick: () => y({
						type: "acquire",
						index: t.index,
						pay: l
					}),
					children: e("games.spice.acquire")
				})
			]
		});
	}
	let x = I(f.pointRow[t.index]), S = ve(i.caravan, x.cost);
	return /* @__PURE__ */ v("div", {
		className: "spice-confirm flex min-h-12 items-center gap-2 px-2 py-1",
		children: [
			/* @__PURE__ */ _(J, {
				id: x.id,
				w: Math.round(134 * b.previewH / 53),
				h: b.previewH
			}),
			/* @__PURE__ */ _("span", {
				className: "min-w-0 flex-1 truncate text-sm font-extrabold",
				children: !S && /* @__PURE__ */ _("span", {
					className: "text-rose-500",
					children: e("games.spice.errCantAfford")
				})
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				className: "btn-quiet min-h-11 px-3 text-sm",
				onClick: m,
				children: e("games.spice.cancel")
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				disabled: !S,
				className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
				style: { background: L.accent },
				onClick: () => y({
					type: "claim",
					index: t.index
				}),
				children: e("games.spice.claim")
			})
		]
	});
}
function De(e, t) {
	return e(t === "y" ? "games.spice.spice.y" : t === "r" ? "games.spice.spice.r" : t === "g" ? "games.spice.spice.g" : "games.spice.spice.b");
}
function Oe(e, t) {
	return e(t === "y" ? "games.spice.spiceBin.y" : t === "r" ? "games.spice.spiceBin.r" : t === "g" ? "games.spice.spiceBin.g" : "games.spice.spiceBin.b");
}
function X(e, t) {
	return w.filter((e) => t[e] > 0).map((n) => e("games.spice.spiceCount", {
		spice: De(e, n),
		n: t[n]
	})).join(" · ");
}
function ke(e, t) {
	let n = P(t);
	return n.kind === "spice" ? e("games.spice.cardSpiceAria", { gain: X(e, n.gain) }) : n.kind === "trade" ? e("games.spice.cardTradeAria", {
		cost: X(e, n.cost),
		gain: X(e, n.gain)
	}) : e("games.spice.cardUpgradeAria", { n: n.times });
}
function Ae({ pub: e, myTurn: t, caravan: n, claimAffordable: r, selected: i, onPick: a }) {
	let { ref: o } = s("prow");
	return /* @__PURE__ */ _("div", {
		ref: o,
		className: "spice-point-row",
		children: e.pointRow.map((o, s) => {
			let c = s === 0 ? e.goldCoins > 0 ? "gold" : e.silverCoins > 0 ? "silver" : null : s === 1 && e.goldCoins > 0 && e.silverCoins > 0 ? "silver" : null;
			return /* @__PURE__ */ _(je, {
				id: o,
				index: s,
				coin: c,
				count: c === "gold" ? e.goldCoins : e.silverCoins,
				myTurn: t,
				caravan: n,
				affordable: r(s),
				active: i === s,
				onPick: () => a(s)
			}, `${o}-${s}`);
		})
	});
}
function je({ id: e, index: t, coin: n, count: i, myTurn: a, caravan: o, affordable: c, active: l, onPick: u }) {
	let f = d(), p = r(Y), { ref: m } = s(`pcard:${t}`), h = I(e), g = o ? w.reduce((e, t) => e + Math.max(0, h.cost[t] - o[t]), 0) : 0;
	return /* @__PURE__ */ v("button", {
		ref: m,
		type: "button",
		disabled: !a,
		onClick: u,
		"aria-label": f("games.spice.pointAria", {
			points: h.points,
			need: X(f, h.cost)
		}),
		className: `spice-point-slot ${l ? "spice-point-slot--active" : ""} ${c ? "spice-point-slot--ready" : ""}`,
		children: [
			/* @__PURE__ */ _(J, {
				id: e,
				w: p.pointW,
				h: p.pointH,
				tall: p.large && p.pointH >= 95,
				have: o,
				showNeed: l
			}),
			n && /* @__PURE__ */ _("span", {
				className: "spice-point-slot__coin",
				children: /* @__PURE__ */ _(he, {
					kind: n,
					count: i
				})
			}),
			o && /* @__PURE__ */ _("span", {
				className: `spice-point-slot__status ${c ? "spice-point-slot__status--ready" : ""}`,
				children: c ? f("games.spice.readyShort") : f("games.spice.missingShort", { n: g })
			})
		]
	});
}
function Me({ pub: e, myTurn: t, caravan: n, selected: r, payPicks: i, onPick: a }) {
	let { ref: o } = s("mrow");
	return /* @__PURE__ */ _("div", {
		ref: o,
		className: "spice-merchant-row",
		children: e.merchantRow.map((e, o) => /* @__PURE__ */ _(Ne, {
			index: o,
			cardId: e.cardId,
			spices: e.spices,
			myTurn: t,
			affordable: !!n && D(n) >= o,
			active: r === o,
			payPreview: r !== null && o < r ? i[o] : void 0,
			payTarget: r !== null && o < r,
			onPick: () => a(o)
		}, `${e.cardId}-${o}`))
	});
}
function Ne({ index: e, cardId: t, spices: n, myTurn: i, affordable: a, active: o, payPreview: c, payTarget: l, onPick: u }) {
	let f = d(), p = r(Y), { ref: m } = s(`mcard:${e}`), h = w.flatMap((e) => Array.from({ length: n[e] }, () => e));
	return /* @__PURE__ */ v("span", {
		className: "spice-merchant-slot",
		"data-position": e === 0 ? f("games.spice.freeShort") : e,
		children: [/* @__PURE__ */ _("button", {
			ref: m,
			type: "button",
			disabled: !i,
			onClick: u,
			"aria-label": f("games.spice.merchantAria", {
				position: e === 0 ? f("games.spice.freeShort") : String(e),
				card: ke(f, t),
				piled: X(f, n) || f("games.spice.none")
			}),
			className: `spice-merchant-slot__button ${o ? "spice-merchant-slot__button--active" : ""} ${a ? "spice-merchant-slot__button--ready" : ""}`,
			children: /* @__PURE__ */ _(q, {
				id: t,
				w: p.merchantW,
				h: p.merchantH,
				tall: p.large && p.merchantH >= 95
			})
		}), /* @__PURE__ */ v("span", {
			className: "spice-merchant-slot__pile",
			children: [h.map((e, t) => /* @__PURE__ */ _(K, {
				color: e,
				size: 10
			}, t)), l && (c ? /* @__PURE__ */ _(K, {
				color: c,
				size: 13
			}) : /* @__PURE__ */ _("span", { className: "spice-merchant-slot__target" }))]
		})]
	});
}
function Pe({ caravan: e, pickable: t, mode: n, pickedCounts: i, onPick: a }) {
	let o = d(), s = r(Y);
	return /* @__PURE__ */ v("div", {
		className: "spice-caravan",
		children: [/* @__PURE__ */ v("div", {
			className: "spice-caravan__heading",
			children: [/* @__PURE__ */ _("span", { children: o("games.spice.caravan") }), /* @__PURE__ */ v("span", { children: [
				D(e),
				" / ",
				10
			] })]
		}), /* @__PURE__ */ _("div", {
			className: "spice-caravan__bins",
			children: w.map((r) => {
				let c = e[r], l = i[r], u = t && c > 0 && (n !== "upgrade" || r !== "b"), d = /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("span", {
					className: "spice-caravan__bin-main",
					children: [
						/* @__PURE__ */ _(K, {
							color: r,
							size: s.large ? 32 : 18
						}),
						/* @__PURE__ */ _("span", { children: s.large ? De(o, r) : Oe(o, r) }),
						/* @__PURE__ */ _("strong", { children: c })
					]
				}), l > 0 && /* @__PURE__ */ v("span", {
					className: "spice-caravan__bin-preview",
					children: [n === "upgrade" && T[r] ? /* @__PURE__ */ _(K, {
						color: T[r],
						size: 12
					}) : "−", l]
				})] });
				return u ? /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => a(r),
					"aria-label": o("games.spice.caravanPickAria", {
						spice: De(o, r),
						n: c,
						selected: l
					}),
					className: `spice-caravan__bin ${l > 0 ? "spice-caravan__bin--picked" : ""}`,
					children: d
				}, r) : /* @__PURE__ */ _("span", {
					className: `spice-caravan__bin ${l > 0 ? "spice-caravan__bin--picked" : ""}`,
					children: d
				}, r);
			})
		})]
	});
}
function Fe({ rid: e, hand: t, played: n, myTurn: c, selected: u, onPick: f, onRest: p }) {
	let m = d(), h = r(Y), { ref: g } = s(`hand:${e}`), [y, b] = o(!1), x = a(null), S = a(t.length);
	i(() => {
		t.length > S.current && x.current && (x.current.scrollTop = x.current.scrollHeight, x.current.scrollLeft = x.current.scrollWidth), S.current = t.length;
	}, [t.length]);
	let [C, w] = o(n.length);
	C !== n.length && (w(n.length), n.length === 0 && b(!1));
	let T = c && n.length > 0;
	return /* @__PURE__ */ v("div", {
		className: "spice-hand-rack",
		children: [
			/* @__PURE__ */ v("div", {
				className: "spice-hand-rack__heading",
				children: [
					/* @__PURE__ */ _("span", { children: m("games.spice.handCount", { n: t.length }) }),
					/* @__PURE__ */ _("span", {
						className: "spice-hand-rack__more--portrait",
						children: t.length > 11 && m("games.spice.scrollMore")
					}),
					/* @__PURE__ */ _("span", {
						className: "spice-hand-rack__more--wide",
						children: t.length > 9 && m("games.spice.scrollMoreWide")
					})
				]
			}),
			/* @__PURE__ */ _("div", {
				ref: x,
				className: "spice-hand-rack__window",
				children: /* @__PURE__ */ v("div", {
					className: "spice-hand-rack__grid",
					children: [
						/* @__PURE__ */ v("button", {
							ref: g,
							type: "button",
							"aria-label": m("games.spice.playedPile"),
							onClick: () => b((e) => !e),
							className: "spice-hand-rack__pile",
							children: [/* @__PURE__ */ _(l, { className: "size-5" }), /* @__PURE__ */ _("span", { children: m("games.spice.playedCount", { n: n.length }) })]
						}),
						t.map((e) => /* @__PURE__ */ _("button", {
							type: "button",
							disabled: !c,
							onClick: () => f(e),
							"aria-label": ke(m, e),
							className: `spice-hand-rack__card ${u === e ? "spice-hand-rack__card--active" : ""}`,
							children: /* @__PURE__ */ _(q, {
								id: e,
								w: h.handW,
								h: h.handH,
								tall: h.large,
								artShare: .32
							})
						}, e)),
						Array.from({ length: Math.max(0, 11 - t.length) }, (e, t) => /* @__PURE__ */ _("span", {
							className: "spice-hand-rack__empty",
							"aria-hidden": !0
						}, `empty-${t}`))
					]
				})
			}),
			y && /* @__PURE__ */ v("div", {
				className: "spice-hand-rack__popover",
				children: [/* @__PURE__ */ v("div", {
					className: "spice-hand-rack__played",
					children: [n.length === 0 && /* @__PURE__ */ _("span", {
						className: "text-xs font-bold text-ink/60",
						children: m("games.spice.playedEmpty")
					}), n.map((e, t) => /* @__PURE__ */ _(q, {
						id: e,
						w: h.handW,
						h: h.handH,
						tall: h.large,
						artShare: .32
					}, `${e}-${t}`))]
				}), /* @__PURE__ */ _("button", {
					type: "button",
					disabled: !T,
					className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
					style: { background: L.accent },
					onClick: p,
					children: m("games.spice.rest")
				})]
			})
		]
	});
}
//#endregion
//#region src/games/spice/bot.ts
function Ie(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Z = {
	y: 1,
	r: 2,
	g: 3,
	b: 4
}, Q = (e) => w.reduce((t, n) => t + e[n] * Z[n], 0), Le = (e, t) => w.every((n) => e[n] >= t[n]), Re = (e) => e.r + e.g + e.b, ze = (e, t) => ({
	y: e.y * t,
	r: e.r * t,
	g: e.g * t,
	b: e.b * t
});
function Be(e, t, n, r) {
	let i = P(e);
	if (i.kind === "spice") return Q(i.gain);
	if (i.kind === "trade") {
		let e = n ?? 1;
		if (e <= 0) return 0;
		let r = ze(i.cost, e);
		return Le(t, r) ? Q(ze(i.gain, e)) - Q(r) : null;
	}
	let a = r ?? [], o = E();
	for (let e of a) {
		if (T[e] === null) return null;
		o[e] += 1;
	}
	return Le(t, o) ? a.length : null;
}
function Ve(e, t) {
	let n = { ...t }, r = [];
	for (let t = 0; t < e.times; t += 1) {
		let e = w.filter((e) => T[e] !== null && n[e] > 0).sort((e, t) => n[t] - n[e] || Z[e] - Z[t])[0];
		if (!e) break;
		--n[e], n[T[e]] += 1, r.push(e);
	}
	return r;
}
var He = {
	claimPointsW: 1,
	claimCoinW: 4,
	claimCostW: .8,
	playTradeW: 1,
	tradeOverW: 2,
	playUpgradeW: 1.4,
	playSpiceW: 1,
	spiceOverW: 2,
	playBonus: .1,
	deadPlayPenalty: .5,
	acqSpiceW: 1.2,
	acqTradeW: .8,
	acqTradeBonus: 0,
	acqUpgradeW: 1.6,
	acqPiledW: 1,
	acqPayW: .8,
	acqPosW: .3,
	restBase: .6,
	restPerPlayed: .25,
	restHandW: .2,
	raceW: 0,
	endClaimW: 0,
	cubeEndW: 0,
	acqLateW: 2,
	denyW: 0
};
function Ue(e = He) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid);
		if (!i) return null;
		if (r.phase === "discard") {
			if (r.turn !== n.rid || r.mustDiscard <= 0) return null;
			let e = w.filter((e) => i.caravan[e] > 0).sort((e, t) => Z[e] - Z[t]), t = [];
			for (let a = 0; a < r.mustDiscard; a += 1) {
				let r = e.filter((e) => i.caravan[e] > t.filter((t) => t === e).length);
				if (!r.length) break;
				t.push(n.difficulty === "weak" ? Ie(r) : r[0]);
			}
			return { action: {
				type: "discard",
				spices: t
			} };
		}
		if (r.phase !== "play" || r.turn !== n.rid) return null;
		let a = t.private?.hand ?? [], o = [], s = D(i.caravan), c = r.players.length <= 3 ? 6 : 5, l = Math.max(0, ...r.players.filter((e) => e.rid !== n.rid).map((e) => e.claimed.length)), u = Math.max(i.claimed.length, l) / c;
		r.pointRow.forEach((t, a) => {
			let s = I(t);
			if (!Le(i.caravan, s.cost)) return;
			let l = a === 0 ? r.goldCoins > 0 ? 3 : +(r.silverCoins > 0) : +(a === 1 && r.goldCoins > 0 && r.silverCoins > 0), d = w.filter((e) => e !== "y").reduce((e, t) => e + Math.min(s.cost[t], i.caravan[t]), 0), f = s.points * e.claimPointsW + l * e.claimCoinW - d * e.claimCostW;
			f += e.raceW * u * s.points, (r.lastRound || i.claimed.length + 1 >= c) && (f += e.endClaimW), l > 0 && e.denyW > 0 && r.players.some((e) => e.rid !== n.rid && Le(e.caravan, s.cost)) && (f += e.denyW * l), o.push({
				action: {
					type: "claim",
					index: a
				},
				score: f
			});
		});
		for (let t of a) {
			let n = P(t);
			if (n.kind === "trade") {
				let r = null;
				for (let e = 1; e <= 6; e += 1) {
					let a = Be(t, i.caravan, e);
					if (a === null) break;
					let o = Re(ze(n.gain, e)) - Re(ze(n.cost, e));
					(!r || a > r.d) && (r = {
						n: e,
						d: a,
						pts: o
					});
				}
				if (r) {
					let i = Math.max(0, s - D(n.cost) * r.n + D(n.gain) * r.n - 10);
					o.push({
						action: {
							type: "play",
							cardId: t,
							times: r.n
						},
						score: r.d * e.playTradeW + r.pts * e.cubeEndW * u - i * e.tradeOverW + e.playBonus
					});
				} else o.push({
					action: {
						type: "play",
						cardId: t,
						times: 0
					},
					score: -e.deadPlayPenalty
				});
			} else if (n.kind === "upgrade") {
				let r = Ve(n, i.caravan), a = r.filter((e) => e === "y").length;
				o.push({
					action: {
						type: "play",
						cardId: t,
						upgrades: r
					},
					score: r.length * e.playUpgradeW + a * e.cubeEndW * u + e.playBonus
				});
			} else {
				let r = Math.max(0, s + D(n.gain) - 10);
				o.push({
					action: {
						type: "play",
						cardId: t
					},
					score: (Q(n.gain) - r * e.spiceOverW) * e.playSpiceW + Re(n.gain) * e.cubeEndW * u + e.playBonus
				});
			}
		}
		r.merchantRow.forEach((t, n) => {
			if (n > 0 && s < n) return;
			let r = P(t.cardId), a;
			a = r.kind === "spice" ? Q(r.gain) * e.acqSpiceW : r.kind === "trade" ? (Q(r.gain) - Q(r.cost)) * e.acqTradeW + e.acqTradeBonus : r.times * e.acqUpgradeW;
			let c = Q(t.spices), l = w.flatMap((e) => Array.from({ length: i.caravan[e] }, () => e)).sort((e, t) => Z[e] - Z[t]).slice(0, n);
			o.push({
				action: {
					type: "acquire",
					index: n,
					pay: l
				},
				score: a + c * e.acqPiledW - Q(Ge(l)) * e.acqPayW - n * e.acqPosW - e.acqLateW * u
			});
		});
		let d = i.played.length;
		if (d > 0) {
			let t = a.reduce((e, t) => e + Math.max(0, Be(t, i.caravan, void 0, P(t).kind === "upgrade" ? Ve(P(t), i.caravan) : void 0) ?? 0), 0);
			o.push({
				action: { type: "rest" },
				score: e.restBase + d * e.restPerPlayed - t * e.restHandW
			});
		}
		return o.length === 0 ? null : n.difficulty === "weak" ? { action: Ie(o).action } : (o.sort((e, t) => t.score - e.score), { action: o[0].action });
	};
}
var We = Ue();
function Ge(e) {
	let t = E();
	for (let n of e) t[n] += 1;
	return t;
}
var Ke = {
	y: "games.spice.spice.y",
	r: "games.spice.spice.r",
	g: "games.spice.spice.g",
	b: "games.spice.spice.b"
};
function qe(e, t) {
	return w.filter((t) => e[t] > 0).map((n) => e[n] > 1 ? t("games.spice.spiceCount", {
		spice: t(Ke[n]),
		n: e[n]
	}) : t(Ke[n])).join(" ");
}
var Je = (e, t, n) => {
	switch (e.type) {
		case "play": {
			let t = P(e.cardId);
			return t.kind === "spice" ? n("games.spice.hintPlaySpice", { gain: qe(t.gain, n) }) : t.kind === "trade" ? n("games.spice.hintPlayTrade", {
				cost: qe(t.cost, n),
				gain: qe(t.gain, n),
				n: e.times ?? 1
			}) : n("games.spice.hintPlayUpgrade", { n: e.upgrades?.length ?? t.times });
		}
		case "acquire": return e.index === 0 ? n("games.spice.hintAcquireFree") : n("games.spice.hintAcquire", { n: e.index });
		case "rest": return n("games.spice.hintRest");
		case "claim": {
			let r = t.public.pointRow[e.index];
			return n("games.spice.hintClaim", { points: r ? I(r).points : 0 });
		}
		case "discard": return n("games.spice.hintDiscard", { n: e.spices.length });
	}
};
//#endregion
//#region src/games/spice/fx.tsx
function $(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
var Ye = {
	play(e, t) {
		let n = e.data, r = $(t, e.rid);
		if (typeof n?.cardId != "string" || !r) return null;
		let i = t.anchor(`hand:${e.rid}`), a = i?.w ?? Math.min(t.anchor("mcard:0")?.w ?? 134, 240), o = i?.h ?? a * 53 / 134;
		return {
			ms: 520,
			node: /* @__PURE__ */ _(b, {
				from: r,
				to: r,
				ms: 400,
				children: /* @__PURE__ */ _(q, {
					id: n.cardId,
					w: a,
					h: o,
					tall: !!i && i.h > 60 && i.h / i.w > .45,
					artShare: .32
				})
			})
		};
	},
	acquire(e, t) {
		let n = e.data, r = $(t, e.rid);
		if (typeof n?.cardId != "string" || !r) return null;
		let i = typeof n.slot == "number" ? t.anchor(`mcard:${n.slot}`) ?? t.anchor("mrow") : t.anchor("mrow");
		return i ? {
			ms: 600,
			node: /* @__PURE__ */ _(b, {
				from: i,
				to: r,
				ms: 420,
				children: /* @__PURE__ */ _(q, {
					id: n.cardId,
					w: i.w,
					h: i.h,
					tall: i.h >= 95 && i.h / i.w > .5
				})
			})
		} : null;
	},
	rest(e, t) {
		let n = $(t, e.rid);
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ _(y, {
				at: n,
				ms: 650,
				children: "💤"
			})
		} : null;
	},
	claim(e, t) {
		let n = e.data, r = $(t, e.rid);
		if (typeof n?.cardId != "string" || !r) return null;
		let i = typeof n.slot == "number" ? t.anchor(`pcard:${n.slot}`) ?? t.anchor("prow") : t.anchor("prow");
		if (!i) return null;
		let a = I(n.cardId).points + (n.coin === "gold" ? 3 : +(n.coin === "silver"));
		return {
			ms: 1e3,
			node: [/* @__PURE__ */ _(b, {
				from: i,
				to: r,
				ms: 460,
				children: /* @__PURE__ */ _(J, {
					id: n.cardId,
					w: i.w,
					h: i.h,
					tall: i.h >= 95 && i.h / i.w > .5
				})
			}, "card"), /* @__PURE__ */ v(y, {
				at: r,
				ms: 900,
				delay: 400,
				children: ["+", a]
			}, "pts")]
		};
	},
	discard(e, t) {
		let n = $(t, e.rid);
		if (!n) return null;
		let r = e.data?.spices, i = Array.isArray(r) ? r.length : 0;
		return i === 0 ? null : {
			ms: 700,
			node: /* @__PURE__ */ v(y, {
				at: n,
				ms: 650,
				children: ["−", i]
			})
		};
	}
};
//#endregion
//#region src/games/spice/game-over.tsx
function Xe(e, t, n, r, i) {
	let a = {
		cols: 1,
		w: 0
	};
	for (let o = 1; o <= n; o += 1) {
		let s = Math.ceil(n / o), c = Math.min(r, (e - i * (o - 1)) / o, (t - i * (s - 1)) / s * 1.8);
		c > a.w && (a = {
			cols: o,
			w: c
		});
	}
	if (a.w < 160) {
		let t = Math.max(1, Math.min(n, Math.floor((e + i) / (160 + i))));
		a = {
			cols: t,
			w: Math.min(r, (e - i * (t - 1)) / t)
		};
	}
	let o = Math.max(1, Math.floor(a.w * 10) / 10);
	return {
		cols: a.cols,
		w: o,
		h: o / 1.8
	};
}
function Ze({ ids: e, playerCount: t }) {
	let n = d(), r = a(null), [s, c] = o({
		w: 100,
		h: 44,
		cols: 2,
		tall: !1
	});
	return i(() => {
		let n = r.current;
		if (!n) return;
		let i = () => {
			let r = getComputedStyle(n), i = Number(r.getPropertyValue("--spice-result-order-cols")) || 2, a = parseFloat(r.columnGap) || 0, o = r.getPropertyValue("--spice-result-tall").trim() === "1", s, l = n.closest(".spice-result-account"), u = n.closest(".spice-result-rankings");
			if (o && l && u && e.length > 0) {
				let r = (e) => parseFloat(e) || 0, i = getComputedStyle(u), c = getComputedStyle(l), d = Math.ceil(t / 2), f = (u.clientHeight - r(i.paddingTop) - r(i.paddingBottom) - (d - 1) * r(i.rowGap)) / d, p = l.querySelector(".spice-result-player")?.getBoundingClientRect().height ?? 0, m = l.querySelector(".spice-result-summary")?.getBoundingClientRect().height ?? 0, h = r(c.paddingTop) + r(c.paddingBottom) + r(c.borderTopWidth) + r(c.borderBottomWidth) + p + m;
				s = {
					...Xe(n.clientWidth, f - h, e.length, t <= 2 ? 380 : 280, a),
					tall: o
				};
			} else {
				let e = Math.max(40, (n.clientWidth - a * (i - 1)) / i);
				s = {
					w: e,
					h: Math.max(44, Math.min(72, e * .4)),
					cols: i,
					tall: !1
				};
			}
			c((e) => e.w === s.w && e.h === s.h && e.cols === s.cols && e.tall === s.tall ? e : s);
		}, a = new ResizeObserver(i);
		a.observe(n);
		let o = n.closest(".spice-result-account"), s = n.closest(".spice-result-rankings");
		if (o) {
			a.observe(o);
			for (let e of o.children) e !== n && a.observe(e);
		}
		return s && a.observe(s), i(), () => a.disconnect();
	}, [e.length, t]), /* @__PURE__ */ v("ul", {
		ref: r,
		className: "spice-result-orders",
		style: s.tall ? { gridTemplateColumns: `repeat(${s.cols}, ${s.w}px)` } : void 0,
		children: [e.map((e) => {
			let t = I(e), r = D(t.cost), i = Math.max(2, Math.min(4, s.w * .008)), a = {
				"--spice-result-cube": `${Math.max(1, Math.floor(Math.min(s.h * .24, (s.w - 24 - (r - 1) * i) / Math.max(1, r))))}px`,
				"--spice-result-cost-gap": `${i}px`,
				"--spice-result-score-font": `${Math.max(30, Math.min(64, s.h * .28))}px`
			};
			return /* @__PURE__ */ _("li", {
				style: a,
				"aria-label": n("games.spice.finalOrderAria", { n: t.points }),
				children: /* @__PURE__ */ _(J, {
					id: e,
					w: s.w,
					h: s.h,
					tall: s.tall
				})
			}, e);
		}), e.length === 0 && /* @__PURE__ */ _("li", {
			className: "spice-result-empty",
			children: n("games.spice.finalNoOrders")
		})]
	});
}
function Qe({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let o = d(), s = u((e) => e.locale), c = t, l = i ?? a;
	return /* @__PURE__ */ v(h, {
		adaptive: !0,
		scroll: !1,
		className: "spice-result-screen",
		banner: /* @__PURE__ */ v("header", {
			className: "spice-result-heading",
			children: [/* @__PURE__ */ _(K, {
				color: "r",
				size: 32
			}), /* @__PURE__ */ v("span", { children: [/* @__PURE__ */ _("strong", { children: o("session.result.title") }), /* @__PURE__ */ _("small", { children: o("games.spice.finalSubtitle") })] })]
		}),
		actionsHeight: "spice-result-actions-slot",
		actions: l ? /* @__PURE__ */ v("div", {
			className: "spice-result-actions",
			children: [i && /* @__PURE__ */ _("button", {
				type: "button",
				onClick: i,
				style: { background: L.accent },
				children: o("session.result.playAgain")
			}), a && /* @__PURE__ */ _("button", {
				type: "button",
				className: "spice-result-back",
				onClick: a,
				children: o("session.result.backToLobby")
			})]
		}) : /* @__PURE__ */ _("p", {
			className: "spice-result-wait",
			children: o("session.result.waitHost")
		}),
		children: [e.winner.length > 0 && /* @__PURE__ */ _(C, {}), /* @__PURE__ */ _("ol", {
			className: "spice-result-rankings",
			"data-players": e.ranking.length,
			children: e.ranking.map((t, i) => {
				let a = c.players.find((e) => e.rid === t), l = n.find((e) => e.rid === t);
				if (!a) return null;
				let u = e.winner.includes(t), d = a.claimed.reduce((e, t) => e + I(t).points, 0), f = w.filter((e) => e !== "y").reduce((e, t) => e + a.caravan[t], 0), p = e.scores?.[t] ?? d + a.gold * 3 + a.silver + f, h = e.autopilot?.[t];
				return /* @__PURE__ */ v("li", {
					className: `spice-result-account${u ? " spice-result-account--winner" : ""}`,
					children: [
						/* @__PURE__ */ v("header", {
							className: "spice-result-player",
							children: [
								/* @__PURE__ */ _("span", {
									className: "spice-result-rank",
									"aria-label": `${i + 1}`,
									children: u ? "★" : i + 1
								}),
								/* @__PURE__ */ _("span", {
									className: "spice-result-avatar",
									style: { background: S[(l?.colorIndex ?? 0) % S.length].hex },
									children: l && /* @__PURE__ */ _("img", {
										src: x[l.avatar % x.length],
										alt: "",
										draggable: !1
									})
								}),
								/* @__PURE__ */ v("span", {
									className: "spice-result-name",
									children: [/* @__PURE__ */ _("strong", { children: l ? m(l, s) : t }), /* @__PURE__ */ v("small", { children: [t === r && /* @__PURE__ */ _("span", { children: o("lobby.you") }), h !== void 0 && h > 0 && /* @__PURE__ */ _("span", { children: o("session.autopilot.share", { n: Math.round(h * 100) }) })] })]
								}),
								/* @__PURE__ */ v("strong", {
									className: "spice-result-total",
									children: [p, /* @__PURE__ */ _("small", { children: o("games.spice.finalPoints") })]
								})
							]
						}),
						/* @__PURE__ */ v("div", {
							className: "spice-result-summary",
							children: [
								/* @__PURE__ */ v("span", { children: [o("games.spice.finalOrders", { n: a.claimed.length }), /* @__PURE__ */ _("strong", { children: d })] }),
								/* @__PURE__ */ v("span", {
									"aria-label": o("games.spice.finalGold", {
										count: a.gold,
										points: a.gold * 3
									}),
									children: [/* @__PURE__ */ _(he, {
										kind: "gold",
										count: a.gold
									}), /* @__PURE__ */ v("strong", { children: ["+", a.gold * 3] })]
								}),
								/* @__PURE__ */ v("span", {
									"aria-label": o("games.spice.finalSilver", {
										count: a.silver,
										points: a.silver
									}),
									children: [/* @__PURE__ */ _(he, {
										kind: "silver",
										count: a.silver
									}), /* @__PURE__ */ v("strong", { children: ["+", a.silver] })]
								}),
								/* @__PURE__ */ v("span", {
									"aria-label": o("games.spice.finalRemaining", { n: f }),
									children: [/* @__PURE__ */ _("span", {
										className: "spice-result-cubes",
										children: w.filter((e) => e !== "y").map((e) => /* @__PURE__ */ _(K, {
											color: e,
											size: 18
										}, e))
									}), /* @__PURE__ */ v("strong", { children: ["+", f] })]
								})
							]
						}),
						/* @__PURE__ */ _(Ze, {
							ids: a.claimed,
							playerCount: e.ranking.length
						})
					]
				}, t);
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/spice/entry.tsx
var $e = {
	definition: ue,
	View: _e,
	bot: We,
	describe: Je,
	fx: Ye,
	OverView: Qe,
	locales: {
		zh: {
			name: "香料之路",
			desc: "种香料、跑商队、做交易,攒够 5 张订单触发终局",
			rules: "目标:有人拿到第 5 张计分卡(2-3 人局为第 6 张)时触发最后一轮。\n所有玩家完成相同数量的回合后，分数最高的玩家获胜。\n计分：将以下各项得分相加，得到最终总分。\n· 计分卡：获得各张计分卡的牌面分数。\n· 金币：每枚获得3分。\n· 银币：每枚获得1分。\n· 剩余香料：商队中每个非黄色香料获得1分。\n流程：每回合选择以下四项行动之一。\n· 打出一张商人卡：按卡牌类型结算。产香料卡使你获得牌面所示的香料；交易卡允许支付上方所示的香料，换取下方所示的香料，可以连续交易任意次数；升级卡允许按照牌面指定的数量，将商队中的香料各提升一级，顺序为黄色、红色、绿色、棕色。\n· 购买一张商人卡：在它前方的每张卡牌上各放置 1 个任意香料；购买最左侧的卡牌无须放置香料。获得被购买卡牌上放置的全部香料。\n· 休息：将面前所有已打出的商人卡收回手中。\n· 兑换一张计分卡：支付该卡要求的全部香料。最左侧两张计分卡还附带金币或银币。\n规则:\n· 商队最多装 10 个香料,超出的部分须在本回合内弃掉。\n· 起始手牌固定为两张商人卡：Create 2 可以获得 2 个黄色香料；Upgrade 2 可以使最多 2 个香料各提升一级。\n· 金币铺在计分行第 1 张上方、银币在第 2 张上方;金币全部领取完毕后，将银币移到第1张计分卡上方。\n· 总分相同时，行动顺序较后的玩家获胜。",
			turnYou: "轮到你:打牌 / 买卡 / 休息 / 兑换",
			turnWait: "等 {{name}} 行动…",
			discardPrompt: "商队超过 10 格,点选弃掉 {{n}} 个香料",
			discardWait: "等 {{name}} 弃掉超出的香料…",
			lastRound: "最后一轮",
			spice: {
				y: "姜黄",
				r: "藏红花",
				g: "豆蔻",
				b: "肉桂"
			},
			spiceBin: {
				y: "姜黄",
				r: "藏红花",
				g: "豆蔻",
				b: "肉桂"
			},
			spiceCount: "{{spice}}×{{n}}",
			market: "商人市集",
			sceneTitle: "驿站交易桌 · 香料之路",
			orders: "订单柜台",
			caravan: "我的商队",
			handCount: "手牌 {{n}} 张",
			playedCount: "已打出 {{n}} 张",
			scrollMore: "上滑更多 ↑",
			scrollMoreWide: "横滑更多 →",
			freeShort: "免",
			readyShort: "可兑",
			missingShort: "差{{n}}",
			none: "无",
			marketHint: "从免费端选卡，向前方摊位铺料",
			claimHint: "检查订单所需香料并兑换",
			cardSpiceAria: "产出 {{gain}}",
			cardTradeAria: "支付 {{cost}}，获得 {{gain}}",
			cardUpgradeAria: "最多升级 {{n}} 个香料",
			merchantAria: "位置 {{position}}，{{card}}，卡上香料：{{piled}}",
			pointAria: "{{points}} 分订单，需要 {{need}}",
			caravanPickAria: "{{spice}} {{n}} 个，已选 {{selected}} 个",
			play: "打出",
			playTrade: "交易 ×{{n}}",
			playUpgrade: "升级 {{n}} 次",
			acquire: "买卡",
			acquireFree: "免费拿取",
			acquirePay: "铺 {{n}} 个香料",
			rest: "休息",
			playedPile: "已打出的牌",
			playedEmpty: "还没有打出的牌",
			claim: "兑换",
			cancel: "取消",
			confirm: "确认",
			tradeTimes: "次数",
			upgradeHint: "点商队里的香料升级(黄→红→绿→棕)",
			payHint: "点商队里的香料,往它前面铺 {{n}} 个",
			stripCards: "🃏{{n}}",
			stripClaimed: "📜{{n}}",
			deckAria: "商人牌堆,剩 {{n}} 张",
			pointDeckAria: "计分牌堆,剩 {{n}} 张",
			errNotYourTurn: "还没轮到你",
			errBadCard: "这张卡不在那里了",
			errCantAfford: "香料不够",
			errBadPay: "铺的香料数量或种类不对",
			errBadUpgrade: "升级目标不对",
			errBadRest: "面前没有打出的牌",
			errBadDiscard: "弃掉的数量或种类不对",
			hintPlaySpice: "打出产香料卡(+{{gain}})",
			hintPlayTrade: "交易 {{cost}} → {{gain}} ×{{n}}",
			hintPlayUpgrade: "升级 {{n}} 个香料",
			hintAcquire: "买下商人卡(铺 {{n}} 个香料)",
			hintAcquireFree: "免费拿下最左的商人卡",
			hintRest: "休息,收回全部手牌",
			hintClaim: "兑换 {{points}} 分计分卡",
			hintDiscard: "弃掉 {{n}} 个香料",
			finalSubtitle: "订单、钱币与商队结算",
			finalPoints: "分",
			finalOrders: "订单 {{n}} 张",
			finalOrderAria: "已兑换订单，{{n}} 分",
			finalNoOrders: "尚未兑换订单",
			finalGold: "金币 {{count}} 枚，共 {{points}} 分",
			finalSilver: "银币 {{count}} 枚，共 {{points}} 分",
			finalRemaining: "剩余非黄色香料，共 {{n}} 分"
		},
		en: {
			name: "Century: Spice Road",
			desc: "Grow spices, run caravans, trade up — race to 5 order cards",
			rules: "Goal: when someone takes their 5th point card (6th in a 2-3 player game), the final round is triggered.\nAfter everyone has taken an equal number of turns, the highest score wins.\nScoring: point card values, plus 3 per gold coin, 1 per silver coin, and 1 per non-yellow spice in your caravan.\nEach turn, choose one of four actions:\n· Play a merchant card. A spice card grants the spices shown. A trade card lets you pay the spices above for those below, repeating the trade any number of times. An upgrade card raises up to its printed number of caravan spices by one level each, in the order yellow, red, green, brown.\n· Buy a merchant card. Place 1 spice of any color on each card before it; the leftmost card requires no spice. Add all spices on the purchased card to your caravan.\n· Rest. Return all your played merchant cards to your hand.\n· Claim a point card. Pay the spices it requires; the two leftmost cards also grant a gold or silver coin.\nRules:\n· Your caravan holds at most 10 spices; discard the excess within the same turn.\n· You always start with Create 2 (produce 2 yellow) and Upgrade 2.\n· Gold coins sit above the 1st point card, silver above the 2nd; once gold runs out, silver moves to the 1st.\n· Ties go to the player later in turn order.",
			turnYou: "Your turn: play / buy / rest / claim",
			turnWait: "Waiting for {{name}}…",
			discardPrompt: "Caravan over 10 — tap {{n}} spices to discard",
			discardWait: "Waiting for {{name}} to discard…",
			lastRound: "Final round",
			spice: {
				y: "Turmeric",
				r: "Saffron",
				g: "Cardamom",
				b: "Cinnamon"
			},
			spiceBin: {
				y: "Turm.",
				r: "Saff.",
				g: "Card.",
				b: "Cinn."
			},
			spiceCount: "{{spice}}×{{n}}",
			market: "Merchant market",
			sceneTitle: "SPICE ROAD MARKET",
			orders: "Order counter",
			caravan: "My caravan",
			handCount: "{{n}} cards in hand",
			playedCount: "{{n}} played",
			scrollMore: "Scroll for more ↑",
			scrollMoreWide: "Scroll sideways →",
			freeShort: "Free",
			readyShort: "Ready",
			missingShort: "Need {{n}}",
			none: "none",
			marketHint: "Choose from the free end; place spices on each earlier card",
			claimHint: "Check the order costs and claim",
			cardSpiceAria: "Produce {{gain}}",
			cardTradeAria: "Pay {{cost}}, gain {{gain}}",
			cardUpgradeAria: "Upgrade up to {{n}} spices",
			merchantAria: "Position {{position}}, {{card}}, spices on card: {{piled}}",
			pointAria: "{{points}} point order, needs {{need}}",
			caravanPickAria: "{{spice}} {{n}}, selected {{selected}}",
			play: "Play",
			playTrade: "Trade ×{{n}}",
			playUpgrade: "Upgrade ×{{n}}",
			acquire: "Buy",
			acquireFree: "Free take",
			acquirePay: "Place {{n}} spices",
			rest: "Rest",
			playedPile: "Played cards",
			playedEmpty: "Nothing played yet",
			claim: "Claim",
			cancel: "Cancel",
			confirm: "Confirm",
			tradeTimes: "Times",
			upgradeHint: "Tap caravan spices to upgrade (Y→R→G→B)",
			payHint: "Tap caravan spices to place {{n}} on the cards before it",
			stripCards: "🃏{{n}}",
			stripClaimed: "📜{{n}}",
			deckAria: "Merchant deck, {{n}} left",
			pointDeckAria: "Point deck, {{n}} left",
			errNotYourTurn: "Not your turn yet",
			errBadCard: "That card is no longer there",
			errCantAfford: "Not enough spices",
			errBadPay: "Wrong spices or count to place",
			errBadUpgrade: "Invalid upgrade target",
			errBadRest: "No played cards to take back",
			errBadDiscard: "Wrong spices or count to discard",
			hintPlaySpice: "Play a spice card (+{{gain}})",
			hintPlayTrade: "Trade {{cost}} → {{gain}} ×{{n}}",
			hintPlayUpgrade: "Upgrade {{n}} spices",
			hintAcquire: "Buy the merchant card (place {{n}})",
			hintAcquireFree: "Take the leftmost merchant card for free",
			hintRest: "Rest and take back all cards",
			hintClaim: "Claim the {{points}}-pt card",
			hintDiscard: "Discard {{n}} spices",
			finalSubtitle: "Orders, coins and caravan scoring",
			finalPoints: "pts",
			finalOrders: "{{n}} orders",
			finalOrderAria: "Claimed order, {{n}} points",
			finalNoOrders: "No claimed orders",
			finalGold: "{{count}} gold coins, {{points}} points",
			finalSilver: "{{count}} silver coins, {{points}} points",
			finalRemaining: "Remaining non-yellow spices, {{n}} points"
		}
	}
};
//#endregion
export { $e as default };
