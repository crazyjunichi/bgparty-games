import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { botAvatarOf as o } from "@bgparty/sdk/lobby";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { avatarNameAt as l, useI18nSettings as u, useT as d } from "@bgparty/sdk/i18n";
import { Texture as f } from "@bgparty/sdk/texture";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as m } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as h, seatName as g } from "@bgparty/sdk/ui/player-strip";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { botPersonality as b } from "@bgparty/sdk/bot-personality";
import { Flash as x, Floater as S, FlySprite as C, PulseBox as w } from "@bgparty/sdk/fx/primitives";
import { playSettle as T } from "@bgparty/sdk/sfx";
import { AVATARS as E } from "@bgparty/sdk/avatars";
import { IconBot as D } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as O } from "@bgparty/sdk/player-colors";
import { Confetti as k } from "@bgparty/sdk/ui/confetti";
//#region src/games/incan/cards.ts
var A = [
	1,
	2,
	3,
	4,
	5,
	5,
	7,
	7,
	9,
	11,
	11,
	13,
	14,
	15,
	17
], j = [
	"snake",
	"spider",
	"mummy",
	"fire",
	"boulder"
], M = [
	5,
	7,
	8,
	10,
	12
];
function ee(e, t) {
	let n = A.map((e) => ({
		t: "gem",
		value: e
	}));
	for (let e of j) if (!t.includes(e)) for (let t = 0; t < 3; t += 1) n.push({
		t: "hazard",
		hazard: e
	});
	return n.push({
		t: "artifact",
		art: e - 1
	}), n;
}
function N(e) {
	return M[e] ?? 0;
}
//#endregion
//#region src/games/incan/meta.ts
var P = {
	id: "incan",
	tier: "released",
	mechanics: ["push-your-luck"],
	interactionTags: [],
	nameKey: "games.incan.name",
	descKey: "games.incan.desc",
	rulesKey: "games.incan.rules",
	icon: "◆",
	iconImg: "games/incan.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/incan/en.pdf" },
	minPlayers: 3,
	maxPlayers: 8,
	bestPlayers: [
		6,
		7,
		8
	],
	accent: "#b45309",
	releasedAt: "2026-09-12",
	search: {
		py: "yin jia bao zang",
		init: "yjbz"
	},
	hotseat: "cover"
}, F = t.enum([
	"snake",
	"spider",
	"mummy",
	"fire",
	"boulder"
]), I = t.enum(["stay", "leave"]), L = t.discriminatedUnion("type", [t.object({
	type: t.literal("decide"),
	choice: I
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), R = t.string(), z = t.discriminatedUnion("t", [
	t.object({
		t: t.literal("gem"),
		value: t.int().min(1).max(17)
	}),
	t.object({
		t: t.literal("hazard"),
		hazard: F
	}),
	t.object({
		t: t.literal("artifact"),
		art: t.int().min(0).max(4)
	})
]), B = t.object({
	card: z,
	gems: t.int().nonnegative()
}), V = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("depart"),
		leavers: t.array(t.object({
			rid: R,
			gems: t.int().nonnegative(),
			artifacts: t.array(t.int())
		}))
	}),
	t.object({
		kind: t.literal("gem"),
		value: t.int(),
		share: t.int().nonnegative()
	}),
	t.object({
		kind: t.literal("hazard"),
		hazard: F,
		dup: t.boolean()
	}),
	t.object({
		kind: t.literal("artifact"),
		art: t.int()
	}),
	t.object({
		kind: t.literal("collapse"),
		hazard: F,
		lost: t.record(R, t.int().nonnegative())
	}),
	t.object({
		kind: t.literal("roundEnd"),
		reason: t.enum([
			"allLeft",
			"collapse",
			"deckOut"
		])
	})
]), H = t.object({
	round: t.int().min(1).max(5),
	phase: t.enum([
		"decide",
		"depart",
		"reveal",
		"roundEnd",
		"done"
	]),
	deckCount: t.int().nonnegative(),
	path: t.array(B),
	inTemple: t.array(R),
	decided: t.array(R),
	lastDecisions: t.record(R, I).nullable(),
	tents: t.record(R, t.int().nonnegative()),
	carrying: t.record(R, t.int().nonnegative()),
	artifacts: t.record(R, t.array(t.int())),
	hazardsRemoved: t.array(F),
	last: V.nullable()
}), U = t.object({ myDecision: I.nullable() }), W = 45e3, te = 1500, ne = 1500, re = 3600;
function ie(t) {
	let n = ee(t.round, t.hazardsRemoved), r = t.rngCursor;
	for (let i = n.length - 1; i > 0; --i) {
		let a = e(t.seed, r, i + 1);
		r += 1, [n[i], n[a]] = [n[a], n[i]];
	}
	return t.rngCursor = r, n;
}
function ae(e, t, n) {
	let r = {
		players: t,
		round: 1,
		phase: "decide",
		deck: [],
		path: [],
		inTemple: [...t],
		decisions: {},
		lastDecisions: null,
		pendingCollapse: null,
		tents: Object.fromEntries(t.map((e) => [e, 0])),
		carrying: Object.fromEntries(t.map((e) => [e, 0])),
		artifacts: Object.fromEntries(t.map((e) => [e, []])),
		hazardsRemoved: [],
		last: null,
		beatMs: W,
		seed: n,
		rngCursor: 0
	};
	return r.deck = ie(r), {
		state: r,
		fx: [{
			kind: "roundStart",
			data: { round: 1 }
		}]
	};
}
function oe(e) {
	let t = { ...e.decisions };
	e.lastDecisions = t, e.decisions = {};
	let n = e.inTemple.filter((e) => t[e] === "leave");
	e.inTemple = e.inTemple.filter((e) => t[e] !== "leave");
	let r = [], i = [];
	if (n.length) {
		let t = e.path.reduce((e, t) => e + t.gems, 0), a = Math.floor(t / n.length), o = t - a * n.length;
		for (let t of e.path) t.gems = 0;
		let s = n.length === 1, c = [];
		if (s) {
			for (let t of e.path) t.card.t === "artifact" && c.push(t.card.art);
			e.path = e.path.filter((e) => e.card.t !== "artifact");
		}
		o > 0 && e.path.length && (e.path[0].gems = o), n.forEach((t, n) => {
			let o = s ? c : [], l = e.carrying[t], u = l + a;
			e.tents[t] += u, e.carrying[t] = 0, o.length && (e.artifacts[t] = [...e.artifacts[t], ...o]), i.push({
				rid: t,
				gems: u,
				artifacts: o
			}), r.push({
				kind: "depart",
				rid: t,
				data: {
					gems: u,
					carried: l,
					shared: a,
					artifacts: o
				},
				...n > 0 ? { with: !0 } : {}
			});
		});
	}
	return e.last = {
		kind: "depart",
		leavers: i
	}, e.phase = "depart", e.beatMs = n.length ? te : 900, r;
}
function se(e) {
	if (e.inTemple.length === 0 || e.deck.length === 0) return e.phase = "roundEnd", e.beatMs = re, e.last = {
		kind: "roundEnd",
		reason: e.inTemple.length === 0 ? "allLeft" : "deckOut"
	}, [];
	let t = e.deck.pop(), n = e.path.length, r = {
		card: t,
		gems: 0
	};
	if (e.path = [...e.path, r], e.phase = "reveal", e.beatMs = ne, t.t === "gem") {
		let i = e.inTemple.length, a = Math.floor(t.value / i);
		r.gems = t.value - a * i;
		for (let t of e.inTemple) e.carrying[t] += a;
		return e.last = {
			kind: "gem",
			value: t.value,
			share: a
		}, [{
			kind: "reveal",
			data: {
				index: n,
				card: t,
				share: a,
				to: [...e.inTemple]
			}
		}];
	}
	if (t.t === "artifact") return e.last = {
		kind: "artifact",
		art: t.art
	}, [{
		kind: "reveal",
		data: {
			index: n,
			card: t
		}
	}];
	let i = e.path.filter((e) => e.card.t === "hazard" && e.card.hazard === t.hazard).length >= 2;
	return e.pendingCollapse = i ? t.hazard : null, e.last = {
		kind: "hazard",
		hazard: t.hazard,
		dup: i
	}, [{
		kind: "reveal",
		data: {
			index: n,
			card: t,
			dup: i
		}
	}];
}
function ce(e) {
	if (e.pendingCollapse) {
		let t = e.pendingCollapse;
		e.pendingCollapse = null;
		let n = {};
		for (let t of e.inTemple) n[t] = e.carrying[t], e.carrying[t] = 0;
		return e.hazardsRemoved.includes(t) || (e.hazardsRemoved = [...e.hazardsRemoved, t]), e.last = {
			kind: "collapse",
			hazard: t,
			lost: n
		}, e.phase = "roundEnd", e.beatMs = re, [{
			kind: "collapse",
			data: {
				hazard: t,
				lost: n
			}
		}];
	}
	return e.phase = "decide", e.lastDecisions = null, e.beatMs = W, [];
}
function le(e) {
	return e.round >= 5 ? (e.phase = "done", e.beatMs = 0, []) : (e.round += 1, e.deck = ie(e), e.path = [], e.inTemple = [...e.players], e.carrying = Object.fromEntries(e.players.map((e) => [e, 0])), e.decisions = {}, e.lastDecisions = null, e.pendingCollapse = null, e.last = null, e.phase = "decide", e.beatMs = W, [{
		kind: "roundStart",
		data: { round: e.round }
	}]);
}
function ue(e, t, n) {
	if (t.type === "tick") {
		if (e.phase === "done") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		if (t.phase === "decide") {
			for (let e of t.inTemple) e in t.decisions || (t.decisions[e] = "leave");
			return {
				state: t,
				fx: oe(t)
			};
		}
		return t.phase === "depart" ? {
			state: t,
			fx: se(t)
		} : t.phase === "reveal" ? {
			state: t,
			fx: ce(t)
		} : {
			state: t,
			fx: le(t)
		};
	}
	if (e.phase !== "decide") return {
		state: e,
		fx: []
	};
	if (!e.inTemple.includes(n.by)) return { code: "games.incan.errNotInTemple" };
	let r = structuredClone(e);
	return r.decisions[n.by] = t.choice, Object.keys(r.decisions).length < r.inTemple.length ? {
		state: r,
		fx: []
	} : {
		state: r,
		fx: oe(r)
	};
}
function de(e, t) {
	let n = e.phase !== "decide";
	return {
		public: {
			round: e.round,
			phase: e.phase,
			deckCount: e.deck.length,
			path: e.path,
			inTemple: e.inTemple,
			decided: Object.keys(e.decisions),
			lastDecisions: n ? e.lastDecisions : null,
			tents: e.tents,
			carrying: e.carrying,
			artifacts: e.artifacts,
			hazardsRemoved: e.hazardsRemoved,
			last: e.last
		},
		private: { myDecision: e.decisions[t] ?? null }
	};
}
function G(e, t) {
	return e.tents[t] + e.artifacts[t].reduce((e, t) => e + N(t), 0);
}
function fe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => G(e, n) - G(e, t)), n = G(e, t[0]);
	return {
		phase: "done",
		winner: t.filter((t) => G(e, t) === n),
		ranking: t,
		scores: Object.fromEntries(e.players.map((t) => [t, G(e, t)]))
	};
}
function pe(e) {
	return e.phase === "done" ? null : e.beatMs;
}
var me = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: P,
	schemas: {
		action: L,
		publicView: H,
		privateView: U
	},
	setup: ae,
	reduce: ue,
	viewFor: de,
	status: fe,
	nextTickIn: pe
};
//#endregion
//#region src/games/incan/temple-icon.tsx
function K({ size: e = 16, color: t = "var(--color-ink)", className: n }) {
	return /* @__PURE__ */ v("svg", {
		width: e,
		height: e,
		viewBox: "0 0 64 64",
		fill: "none",
		"aria-hidden": !0,
		className: n,
		children: /* @__PURE__ */ v("path", {
			fillRule: "evenodd",
			fill: t,
			d: "M32 8 L41 18 L41 26 L49 26 L49 34 L57 34 L57 54 L7 54 L7 34 L15 34 L15 26 L23 26 L23 18 Z M28 54 L28 42 L36 42 L36 54 Z"
		})
	});
}
//#endregion
//#region src/games/incan/card.tsx
var he = "./games/incan/", ge = {
	snake: "snake.webp",
	spider: "spider.webp",
	mummy: "mummy.webp",
	fire: "fire.webp",
	boulder: "boulder.webp"
}, _e = [
	"urn.webp",
	"idol.webp",
	"crown.webp",
	"ring.webp",
	"necklace.webp"
];
function ve(e) {
	return `${he}${_e[e]}`;
}
function ye({ art: e }) {
	return /* @__PURE__ */ y("span", {
		className: "incan-artifact-token",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("img", {
			src: ve(e),
			alt: "",
			draggable: !1
		}), /* @__PURE__ */ v("b", { children: N(e) })]
	});
}
function q({ card: e, gems: t, danger: n, newest: r, index: i }) {
	return /* @__PURE__ */ y("span", {
		className: `incan-path-card incan-path-card--${e.t} ${n ? "incan-path-card--danger" : ""} ${r ? "incan-path-card--newest card-flip-in" : ""}`,
		children: [e.t === "gem" ? /* @__PURE__ */ y(_, { children: [
			/* @__PURE__ */ v("span", {
				className: "incan-card-original",
				children: e.value
			}),
			/* @__PURE__ */ v(J, { className: `incan-card-gem ${t === 0 ? "incan-card-gem--empty" : ""}` }),
			/* @__PURE__ */ v("span", {
				className: `incan-card-count ${t === 0 ? "incan-card-count--empty" : ""}`,
				children: t
			})
		] }) : /* @__PURE__ */ y(_, { children: [
			/* @__PURE__ */ v("img", {
				src: e.t === "hazard" ? `${he}${ge[e.hazard]}` : ve(e.art),
				alt: "",
				draggable: !1,
				className: "incan-card-art"
			}),
			e.t === "artifact" && /* @__PURE__ */ v("span", {
				className: "incan-card-value",
				children: N(e.art)
			}),
			n && /* @__PURE__ */ v("span", {
				className: "incan-card-danger",
				"aria-hidden": !0,
				children: "×2"
			})
		] }), i !== void 0 && /* @__PURE__ */ v("span", {
			className: "incan-card-index",
			children: String(i + 1).padStart(2, "0")
		})]
	});
}
function J({ className: e = "" }) {
	return /* @__PURE__ */ y("svg", {
		className: e,
		viewBox: "0 0 40 40",
		fill: "none",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ v("path", {
				d: "M9 11h22l6 8-17 17L3 19l6-8Z",
				fill: "#3bb9cd",
				stroke: "#123c42",
				strokeWidth: "2.5",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ v("path", {
				d: "m9 11 5 8h12l5-8M3 19h34M14 19l6 17 6-17",
				stroke: "#e4fbef",
				strokeWidth: "2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ v("path", {
				d: "m14 19 6-8 6 8",
				fill: "#a8f0e8"
			})
		]
	});
}
function be() {
	return /* @__PURE__ */ y("span", {
		"aria-hidden": !0,
		className: "incan-deck-back",
		style: { background: P.accent },
		children: [/* @__PURE__ */ v("svg", {
			className: "absolute inset-0 size-full",
			viewBox: "0 0 44 64",
			preserveAspectRatio: "none",
			"aria-hidden": !0,
			children: /* @__PURE__ */ v("path", {
				d: "M-10 16 L54 -12 M-10 36 L54 8 M-10 56 L54 28 M-10 76 L54 48",
				stroke: "#ffffff",
				strokeWidth: 5,
				opacity: .14,
				fill: "none"
			})
		}), /* @__PURE__ */ v(K, {
			size: 20,
			color: "#ffffff"
		})]
	});
}
//#endregion
//#region src/games/incan/icons.tsx
function Y({ kind: e, size: t = 20, className: n = "" }) {
	return /* @__PURE__ */ v("svg", {
		className: n,
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: {
			explore: /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", { d: "M7 20 19 8" }),
				/* @__PURE__ */ v("path", { d: "M10 7c4-3 9-3 13 1l-5 1-4 4" }),
				/* @__PURE__ */ v("path", { d: "m5 18 3 3" })
			] }),
			camp: /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", { d: "M3 20 12 5l9 15H3Z" }),
				/* @__PURE__ */ v("path", { d: "m9 20 3-7 3 7" }),
				/* @__PURE__ */ v("path", { d: "M2 20h20" })
			] }),
			bank: /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("path", { d: "M3 9h18v11H3zM5 9V5h14v4M3 13h18" }), /* @__PURE__ */ v("path", { d: "M10 13h4v3h-4z" })] })
		}[e]
	});
}
//#endregion
//#region src/games/incan/view-player.tsx
function xe(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ v(Ce, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var X = {
	snake: "games.incan.hazardSnake",
	spider: "games.incan.hazardSpider",
	mummy: "games.incan.hazardMummy",
	fire: "games.incan.hazardFire",
	boulder: "games.incan.hazardBoulder"
};
function Se(e, t, n, r) {
	let i = 0, a = 1;
	for (let o = 1; o <= n; o++) {
		let s = Math.ceil(n / o), c = Math.min((e - (o - 1) * r) / o, (t - (s - 1) * r) * 1.08 / s);
		c > i && (i = c, a = o);
	}
	return i < 96 && (a = Math.max(1, Math.min(n, Math.floor((e + r) / (96 + r))))), {
		columns: a,
		width: Math.floor(Math.max(96, Math.min(480, i)) * 100) / 100
	};
}
function Ce({ pub: e, priv: t, members: n, myRid: o, send: s }) {
	let l = d(), g = u((e) => e.locale), _ = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? we(t, g) : e;
	}, b = (e) => e.map(_).join(g === "zh" ? "、" : ", "), { ref: x } = c("path"), { ref: S } = c("deck"), { ref: C } = c("myBank"), { ref: w } = c("myCarry"), { ref: T } = c("pathPool"), E = i(null), [D, O] = a(null), k = n.filter((t) => e.tents[t.rid] !== void 0);
	r(() => {
		let t = E.current, n = t?.querySelector(".game-screen-adaptive"), r = t?.querySelector(".incan-top"), i = t?.querySelector(".incan-stage"), a = t?.querySelector(".incan-path"), o = r?.querySelector(".overflow-x-auto");
		if (!n || !r || !i || !a || !o) return;
		let s = (e, t, n) => {
			e.style.getPropertyValue(t) !== n && e.style.setProperty(t, n);
		}, c = () => {
			let t = a.querySelector(".incan-path-grid");
			if (getComputedStyle(i).getPropertyValue("--incan-wide").trim() !== "1") {
				r.style.removeProperty("--incan-seat-columns"), r.style.removeProperty("--incan-seat-min"), t && (t.style.removeProperty("--incan-path-columns"), t.style.removeProperty("--incan-path-card-w"));
				return;
			}
			let o = n.clientWidth >= 1680 ? 8 : n.clientWidth >= 1280 ? 6 : 4, c = n.clientHeight < 720, l = c ? 1 : Math.ceil(k.length / o), u = Math.max(1, Math.ceil(k.length / l));
			if (s(r, "--incan-seat-columns", String(u)), s(r, "--incan-seat-min", c ? "220px" : "0px"), !t || e.path.length === 0) return;
			let d = getComputedStyle(t), f = Se(a.clientWidth - Number.parseFloat(d.paddingLeft) - Number.parseFloat(d.paddingRight), a.clientHeight - Number.parseFloat(d.paddingTop) - Number.parseFloat(d.paddingBottom), e.path.length, Number.parseFloat(d.columnGap));
			s(t, "--incan-path-columns", String(f.columns)), s(t, "--incan-path-card-w", `${f.width}px`);
		};
		c();
		let l = new ResizeObserver(c);
		for (let e of [
			n,
			a,
			o
		]) l.observe(e);
		return () => l.disconnect();
	}, [
		g,
		e.path.length,
		k.length
	]);
	let A = e.inTemple.includes(o), j = e.decided.includes(o), M = t?.myDecision ?? null, ee = e.last?.kind === "collapse" ? e.last.hazard : null, F = e.last?.kind === "collapse" || e.last?.kind === "hazard" && e.last.dup ? e.last.hazard : null, I = e.path.reduce((e, t) => e + t.gems, 0), L = (e.tents[o] ?? 0) + (e.artifacts[o] ?? []).reduce((e, t) => e + N(t), 0), R = e.carrying[o] ?? 0, z = D?.round === e.round ? e.path[D.index] : void 0, B = z?.card.t === "hazard" ? z.card.hazard : null, V = "info", H = "", U;
	if (e.phase === "decide") A ? j ? (H = l(M === "leave" ? "games.incan.myChoiceLeave" : "games.incan.myChoiceStay"), U = l("games.incan.decideWaiting", { n: e.inTemple.length - e.decided.length })) : (V = "accent", H = l("games.incan.decideYou"), U = l("games.incan.decideHint")) : H = l("games.incan.decideSpectator");
	else if (e.last?.kind === "depart") {
		if (e.last.leavers.length) {
			V = "done", H = l("games.incan.departSome", {
				names: b(e.last.leavers.map((e) => e.rid)),
				gems: e.last.leavers.reduce((e, t) => e + t.gems, 0)
			});
			let t = e.last.leavers[0];
			e.last.leavers.length === 1 && t.artifacts.length && (U = l("games.incan.departArtifacts", {
				name: _(t.rid),
				n: t.artifacts.length,
				points: t.artifacts.reduce((e, t) => e + N(t), 0)
			}));
		} else H = l("games.incan.departAllStay");
	} else if (e.last?.kind === "gem") V = "done", H = l("games.incan.revealGem", {
		value: e.last.value,
		share: e.last.share
	});
	else if (e.last?.kind === "artifact") V = "done", H = l("games.incan.revealArtifact"), U = l("games.incan.revealArtifactHint");
	else if (e.last?.kind === "hazard") V = "warn", H = e.last.dup ? l("games.incan.hazardDup", { name: l(X[e.last.hazard]) }) : l("games.incan.hazardFirst", { name: l(X[e.last.hazard]) });
	else if (e.last?.kind === "collapse") {
		V = "warn", H = l("games.incan.collapse", { name: l(X[e.last.hazard]) });
		let t = Object.entries(e.last.lost).filter(([, e]) => e > 0).map(([e]) => e);
		t.length && (U = l("games.incan.collapseLost", { names: b(t) }));
	} else e.last?.kind === "roundEnd" && (H = l(e.last.reason === "allLeft" ? "games.incan.roundEndAllLeft" : "games.incan.roundEndDeckOut"));
	return /* @__PURE__ */ y("div", {
		ref: E,
		className: `incan-game-shell${ee ? " stage-shake" : ""}`,
		children: [/* @__PURE__ */ v(p, {
			adaptive: !0,
			banner: /* @__PURE__ */ y("div", {
				className: "incan-top",
				children: [/* @__PURE__ */ v(m, {
					tone: V,
					text: H,
					sub: U,
					chip: l("games.incan.roundShort", {
						n: e.round,
						total: 5
					}),
					accent: P.accent
				}), /* @__PURE__ */ v(h, {
					members: k,
					myRid: o,
					variant: "medal",
					scroll: !0,
					anchorOf: (e) => "seat:" + e,
					action: (t) => e.phase === "decide" && e.inTemple.includes(t) ? e.decided.includes(t) ? "done" : "pending" : null,
					dimmed: (t) => !e.inTemple.includes(t),
					status: (t) => /* @__PURE__ */ v(Te, {
						pub: e,
						rid: t
					})
				})]
			}),
			actionsHeight: "incan-actions-height h-20 short:h-13",
			actions: e.phase === "decide" && A ? /* @__PURE__ */ y("div", {
				className: "incan-actions",
				children: [/* @__PURE__ */ y("button", {
					type: "button",
					"aria-label": l("games.incan.stayAria"),
					"aria-pressed": M === "stay",
					onClick: () => s({
						type: "decide",
						choice: "stay"
					}),
					className: "incan-action incan-action--stay " + (M === "stay" ? "incan-action--selected" : ""),
					children: [/* @__PURE__ */ v("span", {
						className: "incan-action-icon",
						children: /* @__PURE__ */ v(Y, {
							kind: "explore",
							size: 22
						})
					}), /* @__PURE__ */ y("span", {
						className: "incan-action-copy",
						children: [/* @__PURE__ */ v("strong", { children: l("games.incan.stay") }), /* @__PURE__ */ v("small", { children: l("games.incan.stayDetail") })]
					})]
				}), /* @__PURE__ */ y("button", {
					type: "button",
					"aria-label": l("games.incan.leaveAria"),
					"aria-pressed": M === "leave",
					onClick: () => s({
						type: "decide",
						choice: "leave"
					}),
					className: "incan-action incan-action--leave " + (M === "leave" ? "incan-action--selected" : ""),
					children: [/* @__PURE__ */ v("span", {
						className: "incan-action-icon",
						children: /* @__PURE__ */ v(Y, {
							kind: "camp",
							size: 22
						})
					}), /* @__PURE__ */ y("span", {
						className: "incan-action-copy",
						children: [/* @__PURE__ */ v("strong", { children: l("games.incan.leave") }), /* @__PURE__ */ v("small", { children: I > 0 ? l("games.incan.leaveDetail", {
							carry: R,
							pool: I
						}) : l("games.incan.leaveDetailNoPool", { carry: R }) })]
					})]
				})]
			}) : /* @__PURE__ */ v("div", {
				className: "incan-action-wait",
				children: l(e.phase === "decide" ? "games.incan.decideSpectator" : "games.incan.waitingNext")
			}),
			scroll: !1,
			children: /* @__PURE__ */ y("div", {
				className: "incan-stage",
				children: [/* @__PURE__ */ v(f, {
					kind: "sheen",
					base: "#0e3c37",
					className: "incan-stage-texture"
				}), /* @__PURE__ */ y("div", {
					className: "incan-stage-inner",
					children: [
						/* @__PURE__ */ y("div", {
							className: "incan-stage-head",
							children: [
								/* @__PURE__ */ v("span", {
									className: "incan-temple-mark",
									children: /* @__PURE__ */ v(K, {
										size: 26,
										color: "#f0c46d"
									})
								}),
								/* @__PURE__ */ y("span", {
									className: "incan-stage-title",
									children: [/* @__PURE__ */ v("strong", { children: l("games.incan.templeDepth") }), /* @__PURE__ */ y("small", { children: [l("games.incan.pathCount", { n: e.path.length }), e.hazardsRemoved.length > 0 ? " · " + l("games.incan.removedHazards", { kinds: e.hazardsRemoved.map((e) => l(X[e])).join(g === "zh" ? "、" : ", ") }) : ""] })]
								}),
								/* @__PURE__ */ y("div", {
									ref: S,
									"data-incan-anchor": "deck",
									className: "incan-deck",
									role: "img",
									"aria-label": l("games.incan.deckCount", { n: e.deckCount }),
									children: [/* @__PURE__ */ v(be, {}), /* @__PURE__ */ y("span", { children: ["×", e.deckCount] })]
								})
							]
						}),
						/* @__PURE__ */ v("div", {
							ref: x,
							"data-incan-anchor": "path",
							className: "incan-path",
							children: e.path.length ? /* @__PURE__ */ v("ol", {
								className: "incan-path-grid",
								"aria-label": l("games.incan.pathHistory"),
								children: e.path.map((t, n) => /* @__PURE__ */ v(Ee, {
									index: n,
									card: t.card,
									gems: t.gems,
									danger: t.card.t === "hazard" && t.card.hazard === F,
									newest: e.phase === "reveal" && n === e.path.length - 1,
									onPick: () => O({
										round: e.round,
										index: n
									})
								}, n))
							}) : /* @__PURE__ */ y("div", {
								className: "incan-path-empty",
								children: [/* @__PURE__ */ v(K, {
									size: 48,
									color: "#f0c46d"
								}), /* @__PURE__ */ v("span", { children: l("games.incan.pathEmpty") })]
							})
						}),
						/* @__PURE__ */ y("div", {
							className: "incan-camp",
							children: [
								/* @__PURE__ */ v("span", {
									className: "incan-camp-icon",
									children: /* @__PURE__ */ v(Y, {
										kind: "camp",
										size: 27
									})
								}),
								/* @__PURE__ */ v("span", {
									className: "incan-camp-route",
									children: l("games.incan.campRoute")
								}),
								/* @__PURE__ */ y("span", {
									className: "incan-camp-stats",
									children: [
										/* @__PURE__ */ v("span", {
											ref: C,
											"data-incan-anchor": "myBank",
											children: l("games.incan.myBank", { n: L })
										}),
										/* @__PURE__ */ v("span", {
											ref: w,
											"data-incan-anchor": "myCarry",
											children: l("games.incan.myCarry", { n: R })
										}),
										/* @__PURE__ */ v("span", {
											ref: T,
											"data-incan-anchor": "pathPool",
											children: l("games.incan.pathPool", { n: I })
										})
									]
								}),
								/* @__PURE__ */ v(J, { className: "incan-camp-gem" })
							]
						})
					]
				})]
			})
		}), z && D && /* @__PURE__ */ v(De, {
			card: z.card,
			gems: z.gems,
			index: D.index,
			danger: z.card.t === "hazard" && z.card.hazard === F,
			hazardCopies: B ? e.path.filter((e) => e.card.t === "hazard" && e.card.hazard === B).length : 0,
			onClose: () => O(null)
		})]
	});
}
function we(e, t) {
	return o(e.rid) === null ? e.name : l(t, e.avatar);
}
function Te({ pub: e, rid: t }) {
	let n = d(), { ref: r } = c("bank:" + t), { ref: i } = c("carry:" + t), a = e.tents[t] + e.artifacts[t].reduce((e, t) => e + N(t), 0), o = e.carrying[t] ?? 0, l = e.inTemple.includes(t) || e.phase === "depart" && e.last?.kind === "depart" && e.last.leavers.some((e) => e.rid === t);
	return /* @__PURE__ */ y("span", {
		className: "incan-seat-stats",
		children: [
			/* @__PURE__ */ y("span", {
				ref: r,
				"data-incan-anchor": "bank:" + t,
				className: "incan-seat-bank",
				"aria-label": n("games.incan.stripTotal", { n: a }),
				children: [
					/* @__PURE__ */ v(Y, {
						kind: "bank",
						size: 13
					}),
					/* @__PURE__ */ v("span", { children: n("games.incan.stripBankShort") }),
					/* @__PURE__ */ v(s, { value: a })
				]
			}),
			l && /* @__PURE__ */ y("span", {
				ref: i,
				"data-incan-anchor": "carry:" + t,
				className: "incan-seat-carry",
				"aria-label": n("games.incan.stripCarrying", { n: o }),
				children: [
					/* @__PURE__ */ v(J, { className: "incan-seat-gem" }),
					/* @__PURE__ */ v("span", { children: n("games.incan.stripCarryShort") }),
					/* @__PURE__ */ v(s, { value: o })
				]
			}),
			e.lastDecisions?.[t] && e.phase !== "decide" && /* @__PURE__ */ v("span", {
				className: "incan-seat-choice",
				"aria-label": n(e.lastDecisions[t] === "stay" ? "games.incan.choiceStay" : "games.incan.choiceLeave"),
				children: /* @__PURE__ */ v(Y, {
					kind: e.lastDecisions[t] === "stay" ? "explore" : "camp",
					size: 13
				})
			})
		]
	});
}
function Ee({ index: e, card: t, gems: n, danger: r, newest: i, onPick: a }) {
	let o = d(), { ref: s } = c("card:" + e), l = t.t === "gem" ? o("games.incan.cardGemAria", {
		value: t.value,
		n
	}) : t.t === "hazard" ? o("games.incan.cardHazardAria", { name: o(X[t.hazard]) }) : o("games.incan.artifactAria", { n: N(t.art) });
	return /* @__PURE__ */ v("li", {
		ref: s,
		"data-incan-anchor": "card:" + e,
		className: "incan-path-slot",
		children: /* @__PURE__ */ v("button", {
			type: "button",
			className: "incan-path-button",
			"aria-label": o("games.incan.openCard", {
				n: e + 1,
				label: l
			}),
			onClick: a,
			children: /* @__PURE__ */ v(q, {
				card: t,
				gems: n,
				danger: r,
				newest: i,
				index: e
			})
		})
	});
}
function De({ card: e, gems: t, index: r, danger: a, hazardCopies: o, onClose: s }) {
	let c = d(), l = i(null);
	n(() => {
		let e = l.current;
		return e?.showModal(), () => e?.close();
	}, []);
	let u = e.t === "gem" ? c("games.incan.cardGemTitle", { n: e.value }) : e.t === "hazard" ? c(X[e.hazard]) : c("games.incan.cardArtifactTitle", { n: N(e.art) }), f = e.t === "gem" ? c("games.incan.cardGemDetail", { n: t }) : e.t === "hazard" ? c(o > 1 ? "games.incan.cardHazardRepeated" : "games.incan.cardHazardFirst") : c("games.incan.cardArtifactDetail");
	return /* @__PURE__ */ v("dialog", {
		ref: l,
		className: "incan-detail",
		onCancel: s,
		onClick: (e) => {
			e.target === e.currentTarget && s();
		},
		"aria-labelledby": "incan-detail-title",
		children: /* @__PURE__ */ y("div", {
			className: "incan-detail-content",
			children: [
				/* @__PURE__ */ v(q, {
					card: e,
					gems: t,
					danger: a,
					index: r
				}),
				/* @__PURE__ */ y("div", {
					className: "incan-detail-copy",
					children: [/* @__PURE__ */ v("strong", {
						id: "incan-detail-title",
						children: u
					}), /* @__PURE__ */ v("p", { children: f })]
				}),
				/* @__PURE__ */ v("button", {
					type: "button",
					className: "incan-detail-close",
					onClick: s,
					children: c("games.incan.closeCard")
				})
			]
		})
	});
}
//#endregion
//#region src/games/incan/bot.ts
function Oe() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
var Z = (e, t, n) => Math.min(n, Math.max(t, e)), ke = (e) => 1 / (1 + Math.exp(-e));
function Ae(e) {
	let t = 0, n = 0, r = e.path.flatMap((e) => e.card.t === "gem" ? [e.card.value] : []);
	for (let e of A) {
		let i = r.indexOf(e);
		i >= 0 ? r.splice(i, 1) : (t += 1, n += e);
	}
	let i = e.path.flatMap((e) => e.card.t === "hazard" ? [e.card.hazard] : []), a = new Set(i), o = 0;
	for (let t of j) e.hazardsRemoved.includes(t) || a.has(t) && (o += 3 - i.filter((e) => e === t).length);
	return {
		pGem: e.deckCount > 0 ? t / e.deckCount : 0,
		pCollapse: e.deckCount > 0 ? o / e.deckCount : 0,
		gemMean: t > 0 ? n / t : 0
	};
}
function je(e, t, n) {
	let r = e.carrying[t] ?? 0;
	return 1 - ke((n.gemMean * n.pGem / e.inTemple.length - n.pCollapse * r) / 1.5);
}
function Me(e) {
	let t = 0;
	for (let n of e.path) n.card.t === "artifact" && (t += N(n.card.art));
	return t;
}
function Ne(e) {
	return e.path.reduce((e, t) => e + t.gems, 0);
}
function Pe(e, t) {
	return (e.tents[t] ?? 0) + (e.artifacts[t] ?? []).reduce((e, t) => e + N(t), 0);
}
var Fe = (e, t) => {
	let n = e.public;
	if (n.phase !== "decide" || !n.inTemple.includes(t.rid) || n.decided.includes(t.rid)) return null;
	let r = b(o(t.rid));
	if (t.difficulty === "weak") {
		let e = Z(.3 + .55 * r.risk + (r.noise - .5) * .2, .05, .95);
		return { action: {
			type: "decide",
			choice: Oe() < e ? "stay" : "leave"
		} };
	}
	let i = n.carrying[t.rid] ?? 0;
	if (i === 0) return { action: {
		type: "decide",
		choice: "stay"
	} };
	let a = Ae(n), s = n.inTemple.filter((e) => e !== t.rid), c = .35 + .65 * r.herd, l = s.map((e) => je(n, e, a)), u = 1 + l.reduce((e, t) => e + (1 - t), 0), d = n.inTemple.length + (u - n.inTemple.length) * c, f = l.reduce((e, t) => e * t, 1) * c, p = 2 + Math.round(3 * r.patience), m = a.gemMean * a.pGem / d, h = 0, g = 1;
	for (let e = 0; e < p; e += 1) g *= 1 - a.pCollapse, h += m * g;
	let _ = 1 - g, v = Pe(n, t.rid) - Math.max(0, ...s.map((e) => Pe(n, e))), y = 1.5 / (5 - n.round + 1), x = Z(-v / 30 * y, 0, 1) * r.compete, S = Z(v / 20, 0, 1) * r.compete, C = (1.45 - .9 * r.risk) * (1 - .55 * x) * (1 + .4 * S), w = Ne(n) / (1 + l.reduce((e, t) => e + t, 0)), T = h * (.7 + .6 * r.greed), E = f * Me(n) * (.4 + 1.6 * r.greed) * (1 + 1.5 * x), D = (i + w) * _ * (.2 * (1 - r.patience) * (1 - .8 * x) + .25 * S), O = T + x * 1.5 - _ * i * C - E - D;
	return { action: {
		type: "decide",
		choice: Oe() < ke(O / (1.2 + 3 * r.noise)) ? "stay" : "leave"
	} };
}, Ie = (e, t, n) => e.type === "decide" ? n(e.choice === "stay" ? "games.incan.stayAria" : "games.incan.leaveAria") : "", Le = {
	snake: "蛇",
	spider: "蜘蛛",
	mummy: "木乃伊",
	fire: "火",
	boulder: "落石"
}, Re = {
	needsAction(e, t) {
		let n = e.public;
		return n.phase === "decide" && n.inTemple.includes(t.rid) && e.private?.myDecision == null;
	},
	describeView(e, t) {
		let n = e.public, r = [`第 ${n.round}/5 轮。5 轮后宝石最多者胜。规则:翻出路上的牌,宝石由还在神庙里的人平分(余数留在牌上);翻出第二种相同的灾祸,神庙坍塌,还在里面的人丢掉本轮所有携带宝石;选择撤离的人带走携带宝石+顺路捡余数。`, `本轮路径(从入口到深处): ${n.path.map((e) => e.card.t === "gem" ? `宝石${e.card.value}${e.gems > 0 ? `(牌上还剩 ${e.gems} 颗没分完)` : ""}` : e.card.t === "hazard" ? `灾祸:${Le[e.card.hazard]}` : `神器#${e.card.art}(单独撤离时独得,值 5 分)`).join(" → ") || "(刚出发)"}`], i = /* @__PURE__ */ new Set();
		for (let e of n.path) e.card.t === "hazard" && i.add(e.card.hazard);
		return i.size && r.push(`已出现的灾祸(再来一张同种就坍塌): ${[...i].map((e) => Le[e]).join("、")}`), n.hazardsRemoved.length && r.push(`已坍塌移除的灾祸种类(不会再出现): ${n.hazardsRemoved.map((e) => Le[e]).join("、")}`), r.push(`还在神庙里: ${n.inTemple.map((e) => e === t.rid ? "你" : e).join(", ") || "(空了)"}`), r.push(`各人战绩: ${n.tents ? Object.keys(n.tents).map((e) => `${e === t.rid ? "你" : e}: 入库 ${n.tents[e]},本轮携带 ${n.carrying[e]}`).join("; ") : ""}`), r.push(`你本轮携带 ${n.carrying[t.rid] ?? 0} 颗宝石(坍塌全丢,撤离入库)。输出 decide 行动:stay 继续深入 / leave 撤离。`), r.join("\n");
	},
	actionJsonSchema: {
		type: "object",
		properties: {
			type: { const: "decide" },
			choice: { enum: ["stay", "leave"] }
		},
		required: ["type", "choice"],
		additionalProperties: !1
	},
	parseAction(e, t, n) {
		let r = L.safeParse(e);
		if (!r.success) return null;
		let i = r.data;
		if (i.type === "tick") return null;
		let a = t.public;
		return a.phase !== "decide" || !a.inTemple.includes(n.rid) ? null : i;
	}
};
//#endregion
//#region src/games/incan/fx.tsx
function ze(e, t) {
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - t) / 2,
		w: t,
		h: t
	};
}
function Be() {
	let e = document.querySelector(".incan-stage"), t = e?.closest(".game-screen-adaptive");
	return e && t && getComputedStyle(e).getPropertyValue("--incan-wide").trim() === "1" ? Math.round(Math.max(40, Math.min(64, t.clientWidth * .03, t.clientHeight * .065))) : 28;
}
function Ve({ size: e, children: t }) {
	return /* @__PURE__ */ v("div", {
		className: "incan-fx-layer",
		style: {
			"--incan-fx-size": `${e}px`,
			"--incan-fx-art-size": `${e === 28 ? 24 : e}px`,
			"--incan-fx-font": `${e === 28 ? 10 : Math.min(20, Math.round(e * .36))}px`,
			"--incan-fx-gain-font": `${e === 28 ? 14 : Math.round(e * .5)}px`
		},
		children: t
	});
}
function He({ from: e, to: t, count: n, ms: r, delay: i, size: a }) {
	return /* @__PURE__ */ v(C, {
		from: ze(e, a),
		to: ze(t, a),
		ms: r,
		delay: i,
		children: /* @__PURE__ */ y("span", {
			className: "incan-fx-gem",
			children: [/* @__PURE__ */ v(J, {}), /* @__PURE__ */ v("b", { children: n })]
		})
	});
}
function Ue({ at: e, delay: t }) {
	return /* @__PURE__ */ v("span", {
		className: "incan-fx-spark",
		style: {
			left: `calc(${e.x + e.w / 2}px - var(--incan-fx-size) * .607)`,
			top: `calc(${e.y + e.h / 2}px - var(--incan-fx-size) * .607)`,
			animationDelay: `${t}ms`
		}
	});
}
function We({ count: e }) {
	return /* @__PURE__ */ y("span", {
		className: "incan-fx-gain",
		children: [
			"+",
			e,
			/* @__PURE__ */ v(J, {})
		]
	});
}
function Q(e, t) {
	let n = e.anchor(t);
	if (!n) return null;
	let r = Array.from(document.querySelectorAll("[data-incan-anchor]")).find((e) => e.dataset.incanAnchor === t);
	if (!r) return null;
	let i = r.getBoundingClientRect();
	if (i.width <= 0 || i.height <= 0 || getComputedStyle(r).visibility !== "visible") return null;
	let a = 0, o = 0, s = window.innerWidth, c = window.innerHeight;
	for (let e = r.parentElement; e; e = e.parentElement) {
		let t = getComputedStyle(e), n = /^(auto|scroll|hidden|clip)$/.test(t.overflowX), r = /^(auto|scroll|hidden|clip)$/.test(t.overflowY);
		if (!n && !r) continue;
		let i = e.getBoundingClientRect();
		n && (a = Math.max(a, i.left + e.clientLeft), s = Math.min(s, i.left + e.clientLeft + e.clientWidth)), r && (o = Math.max(o, i.top + e.clientTop), c = Math.min(c, i.top + e.clientTop + e.clientHeight));
	}
	return s > a && c > o && i.left >= a - 2 && i.top >= o - 2 && i.right <= s + 2 && i.bottom <= c + 2 ? n : null;
}
function Ge(e, t) {
	return Q(e, `bank:${t}`) ?? (t === e.myRid ? Q(e, "myBank") : null);
}
function $(e, t) {
	return Q(e, `carry:${t}`) ?? (t === e.myRid ? Q(e, "myCarry") : null);
}
var Ke = {
	roundStart(e, t) {
		let n = Q(t, "deck");
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ v(w, {
				at: n,
				ms: 700
			})
		} : null;
	},
	depart(e, t) {
		let n = e.rid;
		if (!n) return null;
		let r = Ge(t, n);
		if (!r) return null;
		let i = e.data, a = typeof i?.carried == "number" && i.carried > 0 ? i.carried : 0, o = typeof i?.shared == "number" && i.shared > 0 ? i.shared : 0, s = typeof i?.gems == "number" && i.gems > 0 ? i.gems : 0, c = Array.isArray(i?.artifacts) ? i.artifacts.filter((e) => Number.isInteger(e) && e >= 0 && e < 5) : [], l = $(t, n), u = Q(t, "pathPool"), d = Be();
		return {
			ms: 1350,
			node: /* @__PURE__ */ y(Ve, {
				size: d,
				children: [
					a > 0 && l && /* @__PURE__ */ v(He, {
						from: l,
						to: r,
						count: a,
						ms: 600,
						delay: 60,
						size: d
					}),
					o > 0 && u && /* @__PURE__ */ v(He, {
						from: u,
						to: r,
						count: o,
						ms: 640,
						delay: 140,
						size: d
					}),
					s > 0 && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(Ue, {
						at: r,
						delay: 770
					}), /* @__PURE__ */ v(S, {
						at: r,
						ms: c.length ? 340 : 470,
						delay: c.length ? 990 : 790,
						children: /* @__PURE__ */ v(We, { count: s })
					})] }),
					c.map((e, t) => /* @__PURE__ */ v(S, {
						at: r,
						ms: 330,
						delay: 630 + t * 80,
						children: /* @__PURE__ */ y("span", {
							className: "incan-fx-art",
							children: [/* @__PURE__ */ v("b", { children: "+" }), /* @__PURE__ */ v(ye, { art: e })]
						})
					}, e)),
					s === 0 && c.length === 0 && /* @__PURE__ */ v(S, {
						at: r,
						ms: 750,
						children: /* @__PURE__ */ v(Y, {
							kind: "camp",
							size: Math.round(d * .8)
						})
					})
				]
			})
		};
	},
	reveal(e, t) {
		let n = e.data, r = typeof n?.index == "number" ? Q(t, `card:${n.index}`) : null, i = Be();
		if (n?.card?.t === "gem") {
			let e = typeof n.share == "number" ? n.share : 0, a = Array.isArray(n.to) ? n.to.filter((e) => typeof e == "string") : [];
			return e <= 0 || !a.length || !r ? r ? {
				ms: 500,
				node: /* @__PURE__ */ v(w, {
					at: r,
					ms: 500
				})
			} : null : {
				ms: 1480,
				node: /* @__PURE__ */ y(Ve, {
					size: i,
					children: [a.map((n, a) => {
						let o = $(t, n);
						if (!o) return null;
						let s = 300 + a * 40;
						return /* @__PURE__ */ v(He, {
							from: r,
							to: o,
							count: e,
							ms: 560,
							delay: s,
							size: i
						}, n);
					}), a.map((n, r) => {
						let i = $(t, n);
						if (!i) return null;
						let a = 790 + r * 35;
						return /* @__PURE__ */ y("span", { children: [/* @__PURE__ */ v(Ue, {
							at: i,
							delay: a
						}), /* @__PURE__ */ v(S, {
							at: i,
							ms: 420,
							delay: a + 10,
							children: /* @__PURE__ */ v(We, { count: e })
						})] }, n);
					})]
				})
			};
		}
		return r ? {
			ms: 800,
			node: /* @__PURE__ */ v(w, {
				at: r,
				ms: 800
			})
		} : null;
	},
	collapse(e, t) {
		T(), navigator.vibrate?.(200);
		let n = e.data?.lost ?? {}, r = Q(t, "path"), i = Be();
		return {
			ms: 1100,
			node: /* @__PURE__ */ y(Ve, {
				size: i,
				children: [
					/* @__PURE__ */ v(x, { ms: 700 }),
					r && /* @__PURE__ */ v(w, {
						at: r,
						ms: 900
					}),
					Object.entries(n).map(([e, n]) => {
						if (typeof n != "number" || n <= 0) return null;
						let r = $(t, e);
						return r ? /* @__PURE__ */ v(S, {
							at: r,
							ms: 950,
							delay: 160,
							children: /* @__PURE__ */ y("span", {
								className: "incan-fx-gain incan-fx-loss",
								children: [
									"-",
									n,
									/* @__PURE__ */ v(J, {})
								]
							})
						}, e) : null;
					})
				]
			})
		};
	}
}, qe = {
	snake: "games.incan.hazardSnake",
	spider: "games.incan.hazardSpider",
	mummy: "games.incan.hazardMummy",
	fire: "games.incan.hazardFire",
	boulder: "games.incan.hazardBoulder"
};
function Je(e, t, n, r) {
	let i = 0, a = 1;
	for (let o = 1; o <= n; o++) {
		let s = Math.ceil(n / o), c = Math.min((e - (o - 1) * r) / o, (t - (s - 1) * r) * 1.08 / s);
		c > i && (i = c, a = o);
	}
	return i < 96 && (a = Math.max(1, Math.min(n, Math.floor((e + r) / (96 + r))))), {
		columns: a,
		width: Math.floor(Math.max(96, Math.min(480, i)) * 100) / 100
	};
}
function Ye({ result: e, public: t, members: n, myRid: a, onPlayAgain: o, onBackToLobby: s }) {
	let c = t, l = d(), p = u((e) => e.locale), m = i(null), h = i(null), _ = i(null), b = i(null), x = (t) => e.scores?.[t] ?? (c.tents[t] ?? 0) + (c.artifacts[t] ?? []).reduce((e, t) => e + N(t), 0), S = /* @__PURE__ */ new Map();
	for (let { card: e } of c.path) e.t === "hazard" && S.set(e.hazard, (S.get(e.hazard) ?? 0) + 1);
	r(() => {
		let t = m.current, n = h.current, r = b.current, i = _.current;
		if (!t || !n || !r) return;
		let a = i?.querySelector(".incan-over-path-grid"), o = (e, t, n) => {
			e.style.getPropertyValue(t) !== n && e.style.setProperty(t, n);
		}, s = () => {
			let s = getComputedStyle(t).getPropertyValue("--incan-over-wide").trim() === "1";
			if (!s) r.style.removeProperty("--incan-over-rank-columns"), r.style.removeProperty("--incan-over-row-h");
			else {
				let i = c.path.length ? 1 : Math.max(1, Math.min(6, Math.floor(t.clientWidth / 300))), a = Math.max(1, Math.ceil(e.ranking.length / i)), s = Math.max(1, Math.ceil(e.ranking.length / a));
				o(r, "--incan-over-rank-columns", String(s)), o(r, "--incan-over-row-h", `${Math.max(90, Math.floor((n.clientHeight - (a - 1) * 10) / a))}px`);
			}
			if (!i || !a) return;
			let l = getComputedStyle(a), u = i.clientWidth - Number.parseFloat(l.paddingLeft) - Number.parseFloat(l.paddingRight), d = s ? i.clientHeight - Number.parseFloat(l.paddingTop) - Number.parseFloat(l.paddingBottom) : 0, f = Number.parseFloat(l.columnGap), p = Je(u, d, c.path.length, f);
			o(a, "--incan-over-path-columns", String(p.columns)), o(a, "--incan-over-card-w", `${p.width}px`);
		};
		s();
		let l = new ResizeObserver(s);
		for (let e of [
			t,
			n,
			i
		]) e && l.observe(e);
		return () => l.disconnect();
	}, [
		p,
		c.path.length,
		e.ranking.length
	]);
	let C = o ?? s;
	return /* @__PURE__ */ v("div", {
		className: "incan-over",
		children: /* @__PURE__ */ y("div", {
			ref: m,
			className: "incan-over-layout",
			children: [
				e.winner.length > 0 && /* @__PURE__ */ v(k, {}),
				/* @__PURE__ */ y("header", {
					className: "incan-over-heading",
					children: [
						/* @__PURE__ */ v(K, {
							size: 40,
							color: "#e2b55e"
						}),
						/* @__PURE__ */ v("h1", { children: l("games.incan.resultTitle") }),
						/* @__PURE__ */ v("span", { children: l("games.incan.roundShort", {
							n: c.round,
							total: 5
						}) })
					]
				}),
				/* @__PURE__ */ y("div", {
					ref: h,
					className: "incan-over-main",
					"data-empty-path": c.path.length === 0,
					children: [/* @__PURE__ */ v("ol", {
						ref: b,
						className: "incan-over-ranking",
						children: e.ranking.map((t) => {
							let r = n.find((e) => e.rid === t), i = r ? g(r, p) : t, o = x(t), s = e.ranking.findIndex((e) => x(e) === o) + 1, u = c.artifacts[t] ?? [], d = u.reduce((e, t) => e + N(t), 0), f = e.winner.includes(t), m = e.autopilot?.[t];
							return /* @__PURE__ */ y("li", {
								className: "incan-over-player",
								"data-winner": f,
								children: [
									/* @__PURE__ */ y("div", {
										className: "incan-over-person",
										children: [
											/* @__PURE__ */ v("span", {
												className: "incan-over-rank",
												"aria-label": l("games.incan.resultRank", { n: s }),
												children: s
											}),
											/* @__PURE__ */ v("span", {
												className: "incan-over-avatar",
												style: { background: O[(r?.colorIndex ?? 0) % O.length].hex },
												children: r && /* @__PURE__ */ v("img", {
													src: E[r.avatar % E.length],
													alt: "",
													draggable: !1
												})
											}),
											/* @__PURE__ */ y("div", {
												className: "incan-over-name",
												children: [/* @__PURE__ */ v("h2", {
													title: i,
													children: i
												}), /* @__PURE__ */ y("div", {
													className: "incan-over-flags",
													children: [t === a && /* @__PURE__ */ v("span", { children: l("lobby.you") }), f && /* @__PURE__ */ v("b", { children: l("games.incan.resultWinner") })]
												})]
											}),
											/* @__PURE__ */ y("div", {
												className: "incan-over-total",
												children: [/* @__PURE__ */ v("span", { children: l("games.incan.resultTotal") }), /* @__PURE__ */ v("strong", { children: o })]
											})
										]
									}),
									/* @__PURE__ */ y("div", {
										className: "incan-over-details",
										children: [
											/* @__PURE__ */ y("span", { children: [/* @__PURE__ */ v(J, {}), l("games.incan.resultGems", { n: c.tents[t] ?? 0 })] }),
											u.length > 0 && /* @__PURE__ */ v("span", { children: l("games.incan.resultArtifacts", { n: d }) }),
											m !== void 0 && m > 0 && /* @__PURE__ */ y("small", { children: [/* @__PURE__ */ v(D, { size: 14 }), l("session.autopilot.share", { n: Math.round(m * 100) })] })
										]
									}),
									u.length > 0 && /* @__PURE__ */ v("div", {
										className: "incan-over-artifacts",
										children: u.map((e) => /* @__PURE__ */ v("span", {
											role: "img",
											"aria-label": l("games.incan.artifactAria", { n: N(e) }),
											children: /* @__PURE__ */ v(ye, { art: e })
										}, e))
									})
								]
							}, t);
						})
					}), c.path.length > 0 && /* @__PURE__ */ y("section", {
						className: "incan-over-path-panel",
						children: [
							/* @__PURE__ */ v(f, {
								kind: "sheen",
								base: "#0e3c37",
								className: "incan-over-texture"
							}),
							/* @__PURE__ */ y("header", { children: [/* @__PURE__ */ v("h2", { children: l("games.incan.resultPath") }), /* @__PURE__ */ v("span", { children: l("games.incan.resultPathCount", { n: c.path.length }) })] }),
							/* @__PURE__ */ v("div", {
								ref: _,
								className: "incan-over-path-scroll",
								children: /* @__PURE__ */ v("ol", {
									className: "incan-over-path-grid",
									"aria-label": l("games.incan.resultPathAria"),
									children: c.path.map(({ card: e, gems: t }, n) => {
										let r = e.t === "hazard" && (S.get(e.hazard) ?? 0) > 1, i = e.t === "gem" ? l("games.incan.cardGemAria", {
											value: e.value,
											n: t
										}) : e.t === "artifact" ? l("games.incan.artifactAria", { n: N(e.art) }) : l("games.incan.cardHazardAria", { name: l(qe[e.hazard]) }) + (r ? " · " + l("games.incan.cardHazardRepeated") : "");
										return /* @__PURE__ */ v("li", {
											role: "img",
											"aria-label": i,
											children: /* @__PURE__ */ v(q, {
												card: e,
												gems: t,
												index: n,
												danger: r
											})
										}, n);
									})
								})
							})
						]
					})]
				}),
				C ? /* @__PURE__ */ y("div", {
					className: "incan-over-actions safe-b",
					children: [o && /* @__PURE__ */ v("button", {
						type: "button",
						onClick: o,
						children: l("session.result.playAgain")
					}), s && /* @__PURE__ */ v("button", {
						type: "button",
						onClick: s,
						children: l("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ v("p", {
					className: "incan-over-wait safe-b",
					children: l("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/incan/entry.tsx
var Xe = {
	definition: me,
	View: xe,
	bot: Fe,
	describe: Ie,
	llm: Re,
	fx: Ke,
	OverView: Ye,
	locales: {
		zh: {
			name: "印加宝藏",
			desc: "深入神庙夺宝:同种灾祸出现第二次前,带着宝石全身而退",
			rules: "目标:5 轮探险后,营地里的宝石加神器价值最高者获胜。\n流程:\n· 每轮全队一起进神庙,逐步深入。\n· 每一步,庙里的人同时暗选「深入」或「撤退」,一齐亮出。\n· 撤退者平分小径上散落的宝石,携带的宝石从此安全;若只有一人撤退,还可拿走小径上的全部神器。\n· 随后翻开一张牌:宝藏由留在庙里的人平分(分不完的留在牌上)。\n· 灾祸若与本轮已出现的同种,神庙坍塌:仍在庙里的人丢掉本轮携带的全部宝石。\n· 该种灾祸从牌堆永久移除。\n· 全员撤退或牌堆翻完时,本轮结束。",
			roundShort: "第 {{n}}/{{total}} 轮",
			decideYou: "深入,还是撤退?",
			decideHint: "全员暗选,一齐亮出",
			decideSpectator: "你在营地休整,等本轮结束",
			decideWaiting: "还等 {{n}} 人，可随时改选…",
			myChoiceStay: "已选:深入",
			myChoiceLeave: "已选:撤退",
			choiceStay: "本轮选择:深入",
			choiceLeave: "本轮选择:撤退",
			atCamp: "已回营地",
			departSome: "{{names}} 撤离，共带回 {{gems}} 颗宝石",
			departArtifacts: "{{name}} 独自撤离，带走 {{n}} 件神器（{{points}} 分）",
			departAllStay: "全员选择继续深入!",
			revealGem: "发现 {{value}} 颗宝石，每人分得 {{share}}",
			revealArtifact: "发现神器!独自撤离的人才能拿走",
			revealArtifactHint: "多人同时撤退,谁也拿不走",
			hazardFirst: "遇到{{name}}！再遇一次就坍塌",
			hazardDup: "第二次遇到{{name}}！神庙要塌了！",
			collapse: "{{name}}引发坍塌！庙里的人丢掉了携带的宝石",
			collapseLost: "{{names}} 空手而归",
			roundEndAllLeft: "全员安全撤离,本轮结束",
			roundEndDeckOut: "神庙探索完毕,本轮结束",
			stay: "深入",
			stayDetail: "下一张牌在等你",
			leave: "撤退",
			leaveDetail: "携带 {{carry}} · 路上待分 {{pool}}",
			leaveDetailNoPool: "携带 {{carry}}",
			stayAria: "留在神庙继续深入",
			leaveAria: "带着已有收获撤回营地",
			stripTotal: "营地宝藏 {{n}}",
			stripCarrying: "携带宝石 {{n}}",
			stripBankShort: "营地",
			stripCarryShort: "携带",
			cardGemAria: "宝藏,原 {{value}},剩 {{n}}",
			cardHazardAria: "{{name}}灾祸",
			openCard: "第 {{n}} 张：{{label}}，查看详情",
			cardGemTitle: "宝藏 {{n}}",
			cardGemDetail: "牌上还留有 {{n}} 颗宝石，撤退者会平分路上的余数。",
			cardArtifactTitle: "神器 · {{n}} 分",
			cardArtifactDetail: "只有一人撤退时，才能带走路上的神器。",
			cardHazardFirst: "本轮已见这种灾祸。再翻到一张同种牌，神庙就会坍塌。",
			cardHazardRepeated: "本轮第二张同种灾祸，触发神庙坍塌。",
			closeCard: "返回石径",
			pathHistory: "本轮已翻开的全部路径牌，按序号从浅到深",
			pathEmpty: "神庙入口,等第一张牌……",
			templeDepth: "神庙深处",
			pathCount: "已翻 {{n}} 张 · 点牌查看",
			removedHazards: "已移除 {{kinds}}",
			deckCount: "牌堆还剩 {{n}} 张",
			campRoute: "营地 → 石径 → 神庙",
			myBank: "已入库 {{n}}",
			myCarry: "携带 {{n}}",
			pathPool: "路上 {{n}}",
			waitingNext: "正在结算，下一步即将开始",
			hazardSnake: "蛇",
			hazardSpider: "蜘蛛",
			hazardMummy: "木乃伊",
			hazardFire: "大火",
			hazardBoulder: "落石",
			hazardRemoved: "已移除",
			hazardSeen: "已出现,再翻到同种灾祸就坍塌",
			hazardIdle: "未出现",
			artifactAria: "神器,价值 {{n}}",
			artifactInDeck: "还埋在牌堆里",
			resultTitle: "探险结束",
			resultWinner: "获胜者",
			resultTotal: "总分",
			resultGems: "宝石 {{n}}",
			resultArtifacts: "神器 {{n}} 分",
			resultPath: "末轮石径",
			resultPathCount: "剩余 {{n}} 张",
			resultPathAria: "末轮剩余的路径牌",
			resultRank: "第 {{n}} 名",
			errNotInTemple: "你已回营地,本轮无需抉择"
		},
		en: {
			name: "Incan Gold",
			desc: "Push into the temple for gems — get out before the same hazard strikes twice",
			rules: "Goal: after 5 expeditions, the richest camp — gems plus artifact values — wins.\nPlay:\n· Each round the whole party enters the temple together and goes deeper step by step.\n· At each step, everyone still inside secretly picks “go deeper” or “turn back”, revealed at once.\n· Those who leave split the loose gems on the path, and the gems they carried are safe; a lone leaver also takes every artifact on the path.\n· Then a card is revealed: treasure is shared evenly among those still inside, and any remainder stays on the card.\n· A hazard matching one already seen this round collapses the temple: everyone still inside drops all gems carried this round.\n· That hazard is removed from the deck for good.\n· The round ends when everyone has left or the deck runs out.",
			roundShort: "Round {{n}}/{{total}}",
			decideYou: "Go deeper, or turn back?",
			decideHint: "Secret picks, revealed together",
			decideSpectator: "You are back at camp, waiting out this round",
			decideWaiting: "Waiting on {{n}}; you can change your pick…",
			myChoiceStay: "Picked: go deeper",
			myChoiceLeave: "Picked: turn back",
			choiceStay: "Chose to go deeper",
			choiceLeave: "Chose to turn back",
			atCamp: "Back at camp",
			departSome: "{{names}} left with {{gems}} gems in total",
			departArtifacts: "{{name}} left alone with {{n}} artifacts ({{points}} points)",
			departAllStay: "Everyone pushes deeper!",
			revealGem: "{{value}} gems found, {{share}} for each explorer",
			revealArtifact: "An artifact! Only a lone leaver can claim it",
			revealArtifactHint: "If several leave at once, nobody gets it",
			hazardFirst: "{{name}} seen. Next one collapses!",
			hazardDup: "A second {{name}}! The temple is collapsing!",
			collapse: "{{name}} triggered a collapse! Explorers inside lost their gems",
			collapseLost: "{{names}} went home empty-handed",
			roundEndAllLeft: "Everyone made it out — round over",
			roundEndDeckOut: "The temple is fully explored — round over",
			stay: "Deeper",
			stayDetail: "See the next card",
			leave: "Leave",
			leaveDetail: "Carrying {{carry}} · {{pool}} on the path",
			leaveDetailNoPool: "Carrying {{carry}}",
			stayAria: "Stay in the temple and go deeper",
			leaveAria: "Return to camp with what you carry",
			stripTotal: "Banked treasure {{n}}",
			stripCarrying: "Carried gems {{n}}",
			stripBankShort: "Bank",
			stripCarryShort: "Carry",
			cardGemAria: "Treasure, was {{value}}, {{n}} left",
			cardHazardAria: "{{name}} hazard",
			openCard: "Card {{n}}: {{label}}. View details",
			cardGemTitle: "Treasure {{n}}",
			cardGemDetail: "{{n}} gems remain on this card. Those who leave split the loose gems on the path.",
			cardArtifactTitle: "Artifact · {{n}} points",
			cardArtifactDetail: "A lone player who leaves takes every artifact on the path.",
			cardHazardFirst: "This hazard has appeared this round. Another of the same kind collapses the temple.",
			cardHazardRepeated: "The second matching hazard triggers the temple collapse.",
			closeCard: "Back to the path",
			pathHistory: "All revealed path cards this round, numbered from entrance to depth",
			pathEmpty: "Temple entrance — waiting for the first card…",
			templeDepth: "Temple depths",
			pathCount: "{{n}} revealed · tap to inspect",
			removedHazards: "Removed: {{kinds}}",
			deckCount: "{{n}} cards left in the deck",
			campRoute: "Camp → path → temple",
			myBank: "Banked {{n}}",
			myCarry: "Carrying {{n}}",
			pathPool: "On path {{n}}",
			waitingNext: "Resolving the step; play resumes shortly",
			hazardSnake: "Snake",
			hazardSpider: "Spider",
			hazardMummy: "Mummy",
			hazardFire: "Fire",
			hazardBoulder: "Boulder",
			hazardRemoved: "removed",
			hazardSeen: "seen — a second one collapses the temple",
			hazardIdle: "not seen yet",
			artifactAria: "Artifact, worth {{n}}",
			artifactInDeck: "Still buried in the deck",
			resultTitle: "Expeditions complete",
			resultWinner: "Winner",
			resultTotal: "Total",
			resultGems: "Gems {{n}}",
			resultArtifacts: "Artifacts {{n}} points",
			resultPath: "Final expedition path",
			resultPathCount: "{{n}} cards remaining",
			resultPathAria: "Remaining path cards from the final expedition",
			resultRank: "Rank {{n}}",
			errNotInTemple: "You are back at camp; nothing to pick this round"
		}
	}
};
//#endregion
export { Xe as default };
