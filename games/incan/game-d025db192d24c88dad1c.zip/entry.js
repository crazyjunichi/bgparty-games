import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { botAvatarOf as o } from "@bgparty/sdk/lobby";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { avatarNameAt as l, useI18nSettings as u, useT as d } from "@bgparty/sdk/i18n";
import { Texture as f } from "@bgparty/sdk/texture";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as m } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as h, seatName as g } from "@bgparty/sdk/ui/player-strip";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { botPersonality as b } from "@bgparty/sdk/bot-personality";
import { Flash as x, Floater as S, FlySprite as C, PulseBox as w } from "@bgparty/sdk/fx/primitives";
import { playSettle as T } from "@bgparty/sdk/sfx";
import { AVATARS as E } from "@bgparty/sdk/avatars";
import { IconBot as D } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as O } from "@bgparty/sdk/player-colors";
import { Confetti as k } from "@bgparty/sdk/ui/confetti";
//#region src/games/incan/cards.ts
var A = [
	1,
	2,
	3,
	4,
	5,
	5,
	7,
	7,
	9,
	11,
	11,
	13,
	14,
	15,
	17
], j = [
	"snake",
	"spider",
	"mummy",
	"fire",
	"boulder"
], M = [
	5,
	7,
	8,
	10,
	12
];
function ee(e, t) {
	let n = A.map((e) => ({
		t: "gem",
		value: e
	}));
	for (let e of j) if (!t.includes(e)) for (let t = 0; t < 3; t += 1) n.push({
		t: "hazard",
		hazard: e
	});
	return n.push({
		t: "artifact",
		art: e - 1
	}), n;
}
function N(e) {
	return M[e] ?? 0;
}
//#endregion
//#region src/games/incan/meta.ts
var te = {
	id: "incan",
	tier: "released",
	mechanics: ["push-your-luck"],
	interactionTags: [],
	nameKey: "games.incan.name",
	descKey: "games.incan.desc",
	rulesKey: "games.incan.rules",
	icon: "◆",
	iconImg: "games/incan.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/incan/en.pdf" },
	minPlayers: 3,
	maxPlayers: 8,
	bestPlayers: [
		6,
		7,
		8
	],
	accent: "#b45309",
	releasedAt: "2026-09-12",
	search: {
		py: "yin jia bao zang",
		init: "yjbz"
	},
	hotseat: "cover"
}, P = t.enum([
	"snake",
	"spider",
	"mummy",
	"fire",
	"boulder"
]), F = t.enum(["stay", "leave"]), I = t.discriminatedUnion("type", [t.object({
	type: t.literal("decide"),
	choice: F
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), L = t.string(), ne = t.discriminatedUnion("t", [
	t.object({
		t: t.literal("gem"),
		value: t.int().min(1).max(17)
	}),
	t.object({
		t: t.literal("hazard"),
		hazard: P
	}),
	t.object({
		t: t.literal("artifact"),
		art: t.int().min(0).max(4)
	})
]), R = t.object({
	card: ne,
	gems: t.int().nonnegative()
}), z = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("depart"),
		leavers: t.array(t.object({
			rid: L,
			gems: t.int().nonnegative(),
			artifacts: t.array(t.int())
		}))
	}),
	t.object({
		kind: t.literal("gem"),
		value: t.int(),
		share: t.int().nonnegative()
	}),
	t.object({
		kind: t.literal("hazard"),
		hazard: P,
		dup: t.boolean()
	}),
	t.object({
		kind: t.literal("artifact"),
		art: t.int()
	}),
	t.object({
		kind: t.literal("collapse"),
		hazard: P,
		lost: t.record(L, t.int().nonnegative())
	}),
	t.object({
		kind: t.literal("roundEnd"),
		reason: t.enum([
			"allLeft",
			"collapse",
			"deckOut"
		])
	})
]), B = t.object({
	round: t.int().min(1).max(5),
	phase: t.enum([
		"decide",
		"depart",
		"reveal",
		"roundEnd",
		"done"
	]),
	deckCount: t.int().nonnegative(),
	path: t.array(R),
	inTemple: t.array(L),
	decided: t.array(L),
	lastDecisions: t.record(L, F).nullable(),
	tents: t.record(L, t.int().nonnegative()),
	carrying: t.record(L, t.int().nonnegative()),
	artifacts: t.record(L, t.array(t.int())),
	hazardsRemoved: t.array(P),
	last: z.nullable()
}), V = t.object({
	myTent: t.int().nonnegative(),
	myDecision: F.nullable()
}), H = 45e3, U = 1500, re = 1500, ie = 3600;
function ae(t) {
	let n = ee(t.round, t.hazardsRemoved), r = t.rngCursor;
	for (let i = n.length - 1; i > 0; --i) {
		let a = e(t.seed, r, i + 1);
		r += 1, [n[i], n[a]] = [n[a], n[i]];
	}
	return t.rngCursor = r, n;
}
function oe(e, t, n) {
	let r = {
		players: t,
		round: 1,
		phase: "decide",
		deck: [],
		path: [],
		inTemple: [...t],
		decisions: {},
		lastDecisions: null,
		pendingCollapse: null,
		tents: Object.fromEntries(t.map((e) => [e, 0])),
		carrying: Object.fromEntries(t.map((e) => [e, 0])),
		artifacts: Object.fromEntries(t.map((e) => [e, []])),
		hazardsRemoved: [],
		last: null,
		beatMs: H,
		seed: n,
		rngCursor: 0
	};
	return r.deck = ae(r), {
		state: r,
		fx: [{
			kind: "roundStart",
			data: { round: 1 }
		}]
	};
}
function se(e) {
	let t = { ...e.decisions };
	e.lastDecisions = t, e.decisions = {};
	let n = e.inTemple.filter((e) => t[e] === "leave");
	e.inTemple = e.inTemple.filter((e) => t[e] !== "leave");
	let r = [], i = [];
	if (n.length) {
		let t = e.path.reduce((e, t) => e + t.gems, 0), a = Math.floor(t / n.length), o = t - a * n.length;
		for (let t of e.path) t.gems = 0;
		let s = n.length === 1, c = [];
		if (s) {
			for (let t of e.path) t.card.t === "artifact" && c.push(t.card.art);
			e.path = e.path.filter((e) => e.card.t !== "artifact");
		}
		o > 0 && e.path.length && (e.path[0].gems = o), n.forEach((t, n) => {
			let o = s ? c : [], l = e.carrying[t], u = l + a;
			e.tents[t] += u, e.carrying[t] = 0, o.length && (e.artifacts[t] = [...e.artifacts[t], ...o]), i.push({
				rid: t,
				gems: u,
				artifacts: o
			}), r.push({
				kind: "depart",
				rid: t,
				data: {
					gems: u,
					carried: l,
					shared: a,
					artifacts: o
				},
				...n > 0 ? { with: !0 } : {}
			});
		});
	}
	return e.last = {
		kind: "depart",
		leavers: i
	}, e.phase = "depart", e.beatMs = n.length ? U : 900, r;
}
function ce(e) {
	if (e.inTemple.length === 0 || e.deck.length === 0) return e.phase = "roundEnd", e.beatMs = ie, e.last = {
		kind: "roundEnd",
		reason: e.inTemple.length === 0 ? "allLeft" : "deckOut"
	}, [];
	let t = e.deck.pop(), n = e.path.length, r = {
		card: t,
		gems: 0
	};
	if (e.path = [...e.path, r], e.phase = "reveal", e.beatMs = re, t.t === "gem") {
		let i = e.inTemple.length, a = Math.floor(t.value / i);
		r.gems = t.value - a * i;
		for (let t of e.inTemple) e.carrying[t] += a;
		return e.last = {
			kind: "gem",
			value: t.value,
			share: a
		}, [{
			kind: "reveal",
			data: {
				index: n,
				card: t,
				share: a,
				to: [...e.inTemple]
			}
		}];
	}
	if (t.t === "artifact") return e.last = {
		kind: "artifact",
		art: t.art
	}, [{
		kind: "reveal",
		data: {
			index: n,
			card: t
		}
	}];
	let i = e.path.filter((e) => e.card.t === "hazard" && e.card.hazard === t.hazard).length >= 2;
	return e.pendingCollapse = i ? t.hazard : null, e.last = {
		kind: "hazard",
		hazard: t.hazard,
		dup: i
	}, [{
		kind: "reveal",
		data: {
			index: n,
			card: t,
			dup: i
		}
	}];
}
function le(e) {
	if (e.pendingCollapse) {
		let t = e.pendingCollapse;
		e.pendingCollapse = null;
		let n = {};
		for (let t of e.inTemple) n[t] = e.carrying[t], e.carrying[t] = 0;
		return e.hazardsRemoved.includes(t) || (e.hazardsRemoved = [...e.hazardsRemoved, t]), e.last = {
			kind: "collapse",
			hazard: t,
			lost: n
		}, e.phase = "roundEnd", e.beatMs = ie, [{
			kind: "collapse",
			data: {
				hazard: t,
				lost: n
			}
		}];
	}
	return e.phase = "decide", e.lastDecisions = null, e.beatMs = H, [];
}
function ue(e) {
	return e.round >= 5 ? (e.phase = "done", e.beatMs = 0, []) : (e.round += 1, e.deck = ae(e), e.path = [], e.inTemple = [...e.players], e.carrying = Object.fromEntries(e.players.map((e) => [e, 0])), e.decisions = {}, e.lastDecisions = null, e.pendingCollapse = null, e.last = null, e.phase = "decide", e.beatMs = H, [{
		kind: "roundStart",
		data: { round: e.round }
	}]);
}
function de(e, t, n) {
	if (t.type === "tick") {
		if (e.phase === "done") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		if (t.phase === "decide") {
			for (let e of t.inTemple) e in t.decisions || (t.decisions[e] = "leave");
			return {
				state: t,
				fx: se(t)
			};
		}
		return t.phase === "depart" ? {
			state: t,
			fx: ce(t)
		} : t.phase === "reveal" ? {
			state: t,
			fx: le(t)
		} : {
			state: t,
			fx: ue(t)
		};
	}
	if (e.phase !== "decide") return {
		state: e,
		fx: []
	};
	if (!e.inTemple.includes(n.by)) return { code: "games.incan.errNotInTemple" };
	let r = structuredClone(e);
	return r.decisions[n.by] = t.choice, Object.keys(r.decisions).length < r.inTemple.length ? {
		state: r,
		fx: []
	} : {
		state: r,
		fx: se(r)
	};
}
function fe(e, t) {
	let n = e.phase !== "decide";
	return {
		public: {
			round: e.round,
			phase: e.phase,
			deckCount: e.deck.length,
			path: e.path,
			inTemple: e.inTemple,
			decided: Object.keys(e.decisions),
			lastDecisions: n ? e.lastDecisions : null,
			tents: e.phase === "done" ? e.tents : {},
			carrying: e.carrying,
			artifacts: e.artifacts,
			hazardsRemoved: e.hazardsRemoved,
			last: e.last
		},
		private: {
			myTent: e.tents[t] ?? 0,
			myDecision: e.decisions[t] ?? null
		}
	};
}
function W(e, t) {
	return e.tents[t] + e.artifacts[t].reduce((e, t) => e + N(t), 0);
}
function pe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => W(e, n) - W(e, t)), n = W(e, t[0]);
	return {
		phase: "done",
		winner: t.filter((t) => W(e, t) === n),
		ranking: t,
		scores: Object.fromEntries(e.players.map((t) => [t, W(e, t)]))
	};
}
function me(e) {
	return e.phase === "done" ? null : e.beatMs;
}
var he = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: te,
	schemas: {
		action: I,
		publicView: B,
		privateView: V
	},
	setup: oe,
	reduce: de,
	viewFor: fe,
	status: pe,
	nextTickIn: me
};
//#endregion
//#region src/games/incan/temple-icon.tsx
function G({ size: e = 16, color: t = "var(--color-ink)", className: n }) {
	return /* @__PURE__ */ v("svg", {
		width: e,
		height: e,
		viewBox: "0 0 64 64",
		fill: "none",
		"aria-hidden": !0,
		className: n,
		children: /* @__PURE__ */ v("path", {
			fillRule: "evenodd",
			fill: t,
			d: "M32 8 L41 18 L41 26 L49 26 L49 34 L57 34 L57 54 L7 54 L7 34 L15 34 L15 26 L23 26 L23 18 Z M28 54 L28 42 L36 42 L36 54 Z"
		})
	});
}
//#endregion
//#region src/games/incan/card.tsx
var K = "./games/incan/", ge = {
	snake: "snake.webp",
	spider: "spider.webp",
	mummy: "mummy.webp",
	fire: "fire.webp",
	boulder: "boulder.webp"
}, _e = [
	"urn.webp",
	"idol.webp",
	"crown.webp",
	"ring.webp",
	"necklace.webp"
];
function ve(e) {
	return `${K}${_e[e]}`;
}
function ye({ art: e }) {
	return /* @__PURE__ */ y("span", {
		className: "incan-artifact-token",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("img", {
			src: ve(e),
			alt: "",
			draggable: !1
		}), /* @__PURE__ */ v("b", { children: N(e) })]
	});
}
function q({ card: e, gems: t, danger: n, newest: r, compact: i }) {
	return /* @__PURE__ */ v("span", {
		className: `incan-path-card incan-path-card--${e.t} ${i ? "incan-path-card--compact" : ""} ${i && e.t === "gem" && t === 0 ? "incan-path-card--empty" : ""} ${n ? "incan-path-card--danger" : ""} ${r ? "incan-path-card--newest card-flip-in" : ""}`,
		children: e.t === "gem" ? i ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(J, { className: "incan-summary-gem" }), /* @__PURE__ */ v("b", {
			className: "incan-summary-count",
			children: t
		})] }) : /* @__PURE__ */ y(_, { children: [
			/* @__PURE__ */ v("img", {
				src: `${K}gem-scene.webp`,
				alt: "",
				draggable: !1,
				className: `incan-card-art${t === 0 ? " incan-card-art--empty" : ""}`
			}),
			/* @__PURE__ */ v("span", {
				className: "incan-card-original",
				children: e.value
			}),
			/* @__PURE__ */ y("span", {
				className: `incan-card-count ${t === 0 ? "incan-card-count--empty" : ""}`,
				children: [/* @__PURE__ */ v(J, { className: "incan-card-count-gem" }), /* @__PURE__ */ v("span", { children: t })]
			})
		] }) : /* @__PURE__ */ y(_, { children: [
			/* @__PURE__ */ v("img", {
				src: e.t === "hazard" ? `${K}${ge[e.hazard]}` : ve(e.art),
				alt: "",
				draggable: !1,
				className: i ? "incan-summary-art" : "incan-card-art"
			}),
			e.t === "artifact" && /* @__PURE__ */ v("span", {
				className: i ? "incan-summary-count" : "incan-card-value",
				children: N(e.art)
			}),
			n && /* @__PURE__ */ v("span", {
				className: "incan-card-danger",
				"aria-hidden": !0,
				children: "×2"
			})
		] })
	});
}
function J({ className: e = "" }) {
	return /* @__PURE__ */ v("img", {
		src: `${K}gem-icon.webp`,
		className: `incan-gem-icon ${e}`,
		width: 40,
		height: 40,
		alt: "",
		"aria-hidden": "true",
		draggable: !1
	});
}
function be() {
	return /* @__PURE__ */ y("span", {
		"aria-hidden": !0,
		className: "incan-deck-back",
		style: { background: te.accent },
		children: [/* @__PURE__ */ v("svg", {
			className: "absolute inset-0 size-full",
			viewBox: "0 0 44 64",
			preserveAspectRatio: "none",
			"aria-hidden": !0,
			children: /* @__PURE__ */ v("path", {
				d: "M-10 16 L54 -12 M-10 36 L54 8 M-10 56 L54 28 M-10 76 L54 48",
				stroke: "#ffffff",
				strokeWidth: 5,
				opacity: .14,
				fill: "none"
			})
		}), /* @__PURE__ */ v(G, {
			size: 20,
			color: "#ffffff"
		})]
	});
}
//#endregion
//#region src/games/incan/icons.tsx
function Y({ kind: e, size: t = 20, className: n = "" }) {
	return /* @__PURE__ */ v("svg", {
		className: n,
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: {
			explore: /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", { d: "M7 20 19 8" }),
				/* @__PURE__ */ v("path", { d: "M10 7c4-3 9-3 13 1l-5 1-4 4" }),
				/* @__PURE__ */ v("path", { d: "m5 18 3 3" })
			] }),
			camp: /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", { d: "M3 20 12 5l9 15H3Z" }),
				/* @__PURE__ */ v("path", { d: "m9 20 3-7 3 7" }),
				/* @__PURE__ */ v("path", { d: "M2 20h20" })
			] }),
			bank: /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("path", { d: "M3 9h18v11H3zM5 9V5h14v4M3 13h18" }), /* @__PURE__ */ v("path", { d: "M10 13h4v3h-4z" })] })
		}[e]
	});
}
//#endregion
//#region src/games/incan/view-player.tsx
function xe(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ v(Se, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var X = {
	snake: "games.incan.hazardSnake",
	spider: "games.incan.hazardSpider",
	mummy: "games.incan.hazardMummy",
	fire: "games.incan.hazardFire",
	boulder: "games.incan.hazardBoulder"
};
function Se({ pub: e, priv: t, members: n, myRid: s, send: l }) {
	let g = d(), _ = u((e) => e.locale), b = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? Ce(t, _) : e;
	}, x = (e) => e.map(b).join(_ === "zh" ? "、" : ", "), { ref: S } = c("path"), { ref: C } = c("deck"), { ref: w } = c("myBank"), { ref: T } = c("myCarry"), { ref: E } = c("pathPool"), D = i(null), O = i(!0), [k, A] = a(null), j = n.filter((t) => e.artifacts[t.rid] !== void 0);
	r(() => {
		let t = D.current, n = t?.querySelector(".game-screen-adaptive"), r = t?.querySelector(".incan-top"), i = t?.querySelector(".incan-stage"), a = t?.querySelector(".incan-path"), o = i?.querySelector(".incan-roster");
		if (!n || !r || !i || !a || !o) return;
		let s = (e, t, n) => {
			e.style.getPropertyValue(t) !== n && e.style.setProperty(t, n);
		}, c = () => {
			let t = a.querySelector(".incan-path-grid"), n = getComputedStyle(i).getPropertyValue("--incan-wide").trim() === "1", r = Math.max(1, Math.floor((o.clientWidth + 8) / (n ? 148 : 154))), c = Math.ceil(j.length / r), l = Math.max(1, Math.ceil(j.length / c));
			if (s(o, "--incan-seat-columns", String(l)), !t || e.path.length === 0) {
				O.current = !0;
				return;
			}
			let u = getComputedStyle(t), d = a.clientWidth - Number.parseFloat(u.paddingLeft) - Number.parseFloat(u.paddingRight), f = a.clientHeight - Number.parseFloat(u.paddingTop) - Number.parseFloat(u.paddingBottom), p = Number.parseFloat(u.columnGap), m = n ? 92 : 40, h = Math.min(e.path.length - 1, n ? 8 : 4), g = Math.min(n ? 480 : 260, f * .94, Math.max(48, d - h * (m + p)));
			s(t, "--incan-path-card-w", `${Math.max(48, Math.floor(g))}px`), s(t, "--incan-summary-w", `${m}px`), s(t, "--incan-summary-h", `${Math.max(40, Math.min(f - 4, n ? 132 : 75))}px`), s(t, "--incan-summary-font", `${n ? 30 : f < 65 ? 14 : 18}px`), O.current && (a.scrollLeft = a.scrollWidth - a.clientWidth);
		};
		c();
		let l = new ResizeObserver(c);
		for (let e of [
			n,
			a,
			o
		]) l.observe(e);
		return () => l.disconnect();
	}, [
		_,
		e.path.length,
		j.length
	]);
	let M = e.inTemple.includes(s), ee = e.decided.includes(s), P = t?.myDecision ?? null, F = e.last?.kind === "collapse" ? e.last.hazard : null, I = e.last?.kind === "collapse" || e.last?.kind === "hazard" && e.last.dup ? e.last.hazard : null, L = e.path.reduce((e, t) => e + t.gems, 0), ne = (t?.myTent ?? e.tents[s] ?? 0) + (e.artifacts[s] ?? []).reduce((e, t) => e + N(t), 0), R = e.carrying[s] ?? 0, z = k?.round === e.round ? e.path[k.index] : void 0, B = z?.card.t === "hazard" ? z.card.hazard : null, V = "info", H = "", U;
	if (e.phase === "decide") M ? ee ? (H = g(P === "leave" ? "games.incan.myChoiceLeave" : "games.incan.myChoiceStay"), U = g("games.incan.decideWaiting", { n: e.inTemple.length - e.decided.length })) : (V = "accent", H = g("games.incan.decideYou"), U = g("games.incan.decideHint")) : H = g("games.incan.decideSpectator");
	else if (e.last?.kind === "depart") {
		if (e.last.leavers.length) {
			V = "done", H = g("games.incan.departSome", {
				names: x(e.last.leavers.map((e) => e.rid)),
				gems: e.last.leavers.reduce((e, t) => e + t.gems, 0)
			});
			let t = e.last.leavers[0];
			e.last.leavers.length === 1 && t.artifacts.length && (U = g("games.incan.departArtifacts", {
				name: b(t.rid),
				n: t.artifacts.length,
				points: t.artifacts.reduce((e, t) => e + N(t), 0)
			}));
		} else H = g("games.incan.departAllStay");
	} else if (e.last?.kind === "gem") V = "done", H = g("games.incan.revealGem", {
		value: e.last.value,
		share: e.last.share
	});
	else if (e.last?.kind === "artifact") V = "done", H = g("games.incan.revealArtifact"), U = g("games.incan.revealArtifactHint");
	else if (e.last?.kind === "hazard") V = "warn", H = e.last.dup ? g("games.incan.hazardDup", { name: g(X[e.last.hazard]) }) : g("games.incan.hazardFirst", { name: g(X[e.last.hazard]) });
	else if (e.last?.kind === "collapse") {
		V = "warn", H = g("games.incan.collapse", { name: g(X[e.last.hazard]) });
		let t = Object.entries(e.last.lost).filter(([, e]) => e > 0).map(([e]) => e);
		t.length && (U = g("games.incan.collapseLost", { names: x(t) }));
	} else e.last?.kind === "roundEnd" && (H = g(e.last.reason === "allLeft" ? "games.incan.roundEndAllLeft" : "games.incan.roundEndDeckOut"));
	return /* @__PURE__ */ y("div", {
		ref: D,
		className: `incan-game-shell${F ? " stage-shake" : ""}`,
		children: [/* @__PURE__ */ v(p, {
			adaptive: !0,
			banner: /* @__PURE__ */ v("div", {
				className: "incan-top",
				children: /* @__PURE__ */ v(m, {
					tone: V,
					text: H,
					sub: U,
					chip: g("games.incan.roundShort", {
						n: e.round,
						total: 5
					}),
					accent: te.accent
				})
			}),
			actionsHeight: "incan-actions-height h-20 short:h-13",
			actions: e.phase === "decide" && M ? /* @__PURE__ */ y("div", {
				className: "incan-actions",
				children: [/* @__PURE__ */ y("button", {
					type: "button",
					"aria-label": g("games.incan.stayAria"),
					"aria-pressed": P === "stay",
					onClick: () => l({
						type: "decide",
						choice: "stay"
					}),
					className: "incan-action incan-action--stay " + (P === "stay" ? "incan-action--selected" : ""),
					children: [/* @__PURE__ */ v("span", {
						className: "incan-action-icon",
						children: /* @__PURE__ */ v(Y, {
							kind: "explore",
							size: 22
						})
					}), /* @__PURE__ */ y("span", {
						className: "incan-action-copy",
						children: [/* @__PURE__ */ v("strong", { children: g("games.incan.stay") }), /* @__PURE__ */ v("small", { children: g("games.incan.stayDetail") })]
					})]
				}), /* @__PURE__ */ y("button", {
					type: "button",
					"aria-label": g("games.incan.leaveAria"),
					"aria-pressed": P === "leave",
					onClick: () => l({
						type: "decide",
						choice: "leave"
					}),
					className: "incan-action incan-action--leave " + (P === "leave" ? "incan-action--selected" : ""),
					children: [/* @__PURE__ */ v("span", {
						className: "incan-action-icon",
						children: /* @__PURE__ */ v(Y, {
							kind: "camp",
							size: 22
						})
					}), /* @__PURE__ */ y("span", {
						className: "incan-action-copy",
						children: [/* @__PURE__ */ v("strong", { children: g("games.incan.leave") }), /* @__PURE__ */ v("small", { children: L > 0 ? g("games.incan.leaveDetail", {
							carry: R,
							pool: L
						}) : g("games.incan.leaveDetailNoPool", { carry: R }) })]
					})]
				})]
			}) : /* @__PURE__ */ v("div", {
				className: "incan-action-wait",
				children: g(e.phase === "decide" ? "games.incan.decideSpectator" : "games.incan.waitingNext")
			}),
			scroll: !1,
			children: /* @__PURE__ */ y("div", {
				className: "incan-stage",
				children: [/* @__PURE__ */ v(f, {
					kind: "sheen",
					base: "#0e3c37",
					className: "incan-stage-texture"
				}), /* @__PURE__ */ y("div", {
					className: "incan-stage-inner",
					children: [
						/* @__PURE__ */ v("div", {
							className: "incan-roster",
							children: /* @__PURE__ */ v(h, {
								members: j.map((e) => o(e.rid) === null ? e : {
									...e,
									online: !0
								}),
								myRid: s,
								variant: "medal",
								anchorOf: (e) => "seat:" + e,
								action: (t) => e.phase === "decide" && e.inTemple.includes(t) ? e.decided.includes(t) ? "done" : "pending" : null,
								status: (t) => /* @__PURE__ */ v(we, {
									pub: e,
									rid: t
								})
							})
						}),
						/* @__PURE__ */ y("div", {
							className: "incan-stage-head",
							children: [
								/* @__PURE__ */ v("span", {
									className: "incan-temple-mark",
									children: /* @__PURE__ */ v(G, {
										size: 26,
										color: "#f0c46d"
									})
								}),
								/* @__PURE__ */ y("span", {
									className: "incan-stage-title",
									children: [/* @__PURE__ */ v("strong", { children: g("games.incan.templeDepth") }), /* @__PURE__ */ y("small", { children: [g("games.incan.pathCount", { n: e.path.length }), e.hazardsRemoved.length > 0 ? " · " + g("games.incan.removedHazards", { kinds: e.hazardsRemoved.map((e) => g(X[e])).join(_ === "zh" ? "、" : ", ") }) : ""] })]
								}),
								/* @__PURE__ */ y("div", {
									ref: C,
									"data-incan-anchor": "deck",
									className: "incan-deck",
									role: "img",
									"aria-label": g("games.incan.deckCount", { n: e.deckCount }),
									children: [/* @__PURE__ */ v(be, {}), /* @__PURE__ */ y("span", { children: ["×", e.deckCount] })]
								})
							]
						}),
						/* @__PURE__ */ v("div", {
							ref: S,
							"data-incan-anchor": "path",
							className: "incan-path",
							onScroll: (e) => {
								let t = e.currentTarget;
								O.current = t.scrollWidth - t.clientWidth - t.scrollLeft < 8;
							},
							children: e.path.length ? /* @__PURE__ */ v("ol", {
								className: "incan-path-grid",
								"aria-label": g("games.incan.pathHistory"),
								children: e.path.map((t, n) => /* @__PURE__ */ v(Te, {
									index: n,
									card: t.card,
									gems: t.gems,
									danger: t.card.t === "hazard" && t.card.hazard === I,
									latest: n === e.path.length - 1,
									newest: e.phase === "reveal" && n === e.path.length - 1,
									onPick: () => A({
										round: e.round,
										index: n
									})
								}, n))
							}) : /* @__PURE__ */ y("div", {
								className: "incan-path-empty",
								children: [/* @__PURE__ */ v(G, {
									size: 48,
									color: "#f0c46d"
								}), /* @__PURE__ */ v("span", { children: g("games.incan.pathEmpty") })]
							})
						}),
						/* @__PURE__ */ y("div", {
							className: "incan-camp",
							children: [
								/* @__PURE__ */ v("span", {
									className: "incan-camp-icon",
									children: /* @__PURE__ */ v(Y, {
										kind: "camp",
										size: 27
									})
								}),
								/* @__PURE__ */ v("span", {
									className: "incan-camp-route",
									children: g("games.incan.campRoute")
								}),
								/* @__PURE__ */ y("span", {
									className: "incan-camp-stats",
									children: [
										/* @__PURE__ */ v("span", {
											ref: w,
											"data-incan-anchor": "myBank",
											children: g("games.incan.myBank", { n: ne })
										}),
										/* @__PURE__ */ v("span", {
											ref: T,
											"data-incan-anchor": "myCarry",
											children: g("games.incan.myCarry", { n: R })
										}),
										/* @__PURE__ */ v("span", {
											ref: E,
											"data-incan-anchor": "pathPool",
											children: g("games.incan.pathPool", { n: L })
										})
									]
								}),
								/* @__PURE__ */ v(J, { className: "incan-camp-gem" })
							]
						})
					]
				})]
			})
		}), z && k && /* @__PURE__ */ v(Ee, {
			card: z.card,
			gems: z.gems,
			danger: z.card.t === "hazard" && z.card.hazard === I,
			hazardCopies: B ? e.path.filter((e) => e.card.t === "hazard" && e.card.hazard === B).length : 0,
			onClose: () => A(null)
		})]
	});
}
function Ce(e, t) {
	return o(e.rid) === null ? e.name : l(t, e.avatar);
}
function we({ pub: e, rid: t }) {
	let n = d(), { ref: r } = c("bank:" + t), { ref: i } = c("carry:" + t), a = e.carrying[t] ?? 0, o = e.artifacts[t] ?? [], l = e.last?.kind === "collapse" && Object.hasOwn(e.last.lost, t), u = !e.inTemple.includes(t) || l, f = e.inTemple.includes(t) || e.phase === "depart" && e.last?.kind === "depart" && e.last.leavers.some((e) => e.rid === t);
	return /* @__PURE__ */ y("span", {
		className: "incan-seat-stats",
		children: [
			/* @__PURE__ */ y("span", {
				ref: r,
				"data-incan-anchor": "bank:" + t,
				className: `incan-seat-state${u ? " incan-seat-state--camp" : ""}`,
				children: [/* @__PURE__ */ v(Y, {
					kind: u ? "camp" : "explore",
					size: 13
				}), /* @__PURE__ */ v("span", { children: n(u ? l ? "games.incan.returnedCamp" : "games.incan.atCamp" : "games.incan.exploring") })]
			}),
			f && /* @__PURE__ */ y("span", {
				ref: i,
				"data-incan-anchor": "carry:" + t,
				className: "incan-seat-carry",
				"aria-label": n("games.incan.stripCarrying", { n: a }),
				children: [/* @__PURE__ */ v(J, { className: "incan-seat-gem" }), /* @__PURE__ */ v(s, { value: a })]
			}),
			o.length > 0 && /* @__PURE__ */ y("span", {
				className: "incan-seat-artifacts",
				"aria-label": n("games.incan.stripArtifacts", { n: o.length }),
				title: n("games.incan.stripArtifacts", { n: o.length }),
				children: [/* @__PURE__ */ v(G, { size: 13 }), /* @__PURE__ */ y("span", { children: ["×", o.length] })]
			})
		]
	});
}
function Te({ index: e, card: t, gems: n, danger: r, latest: i, newest: a, onPick: o }) {
	let s = d(), { ref: l } = c("card:" + e), u = t.t === "gem" ? s("games.incan.cardGemAria", {
		value: t.value,
		n
	}) : t.t === "hazard" ? s("games.incan.cardHazardAria", { name: s(X[t.hazard]) }) : s("games.incan.artifactAria", { n: N(t.art) });
	return /* @__PURE__ */ v("li", {
		ref: l,
		"data-incan-anchor": "card:" + e,
		className: `incan-path-slot${i ? " incan-path-slot--latest" : ""}`,
		children: /* @__PURE__ */ v("button", {
			type: "button",
			className: "incan-path-button",
			"aria-label": s("games.incan.openCard", { label: u }),
			onClick: o,
			children: /* @__PURE__ */ v(q, {
				card: t,
				gems: n,
				danger: r,
				newest: a,
				compact: !i
			})
		})
	});
}
function Ee({ card: e, gems: t, danger: r, hazardCopies: a, onClose: o }) {
	let s = d(), c = i(null);
	n(() => {
		let e = c.current;
		return e?.showModal(), () => e?.close();
	}, []);
	let l = e.t === "gem" ? s("games.incan.cardGemTitle", { n: e.value }) : e.t === "hazard" ? s(X[e.hazard]) : s("games.incan.cardArtifactTitle", { n: N(e.art) }), u = e.t === "gem" ? s("games.incan.cardGemDetail", { n: t }) : e.t === "hazard" ? s(a > 1 ? "games.incan.cardHazardRepeated" : "games.incan.cardHazardFirst") : s("games.incan.cardArtifactDetail");
	return /* @__PURE__ */ v("dialog", {
		ref: c,
		className: "incan-detail",
		onCancel: o,
		onClick: (e) => {
			e.target === e.currentTarget && o();
		},
		"aria-labelledby": "incan-detail-title",
		children: /* @__PURE__ */ y("div", {
			className: "incan-detail-content",
			children: [
				/* @__PURE__ */ v(q, {
					card: e,
					gems: t,
					danger: r
				}),
				/* @__PURE__ */ y("div", {
					className: "incan-detail-copy",
					children: [/* @__PURE__ */ v("strong", {
						id: "incan-detail-title",
						children: l
					}), /* @__PURE__ */ v("p", { children: u })]
				}),
				/* @__PURE__ */ v("button", {
					type: "button",
					className: "incan-detail-close",
					onClick: o,
					children: s("games.incan.closeCard")
				})
			]
		})
	});
}
//#endregion
//#region src/games/incan/bot.ts
function De() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
var Oe = (e, t, n) => Math.min(n, Math.max(t, e)), ke = (e) => 1 / (1 + Math.exp(-e));
function Ae(e) {
	let t = 0, n = 0, r = e.path.flatMap((e) => e.card.t === "gem" ? [e.card.value] : []);
	for (let e of A) {
		let i = r.indexOf(e);
		i >= 0 ? r.splice(i, 1) : (t += 1, n += e);
	}
	let i = e.path.flatMap((e) => e.card.t === "hazard" ? [e.card.hazard] : []), a = new Set(i), o = 0;
	for (let t of j) e.hazardsRemoved.includes(t) || a.has(t) && (o += 3 - i.filter((e) => e === t).length);
	return {
		pGem: e.deckCount > 0 ? t / e.deckCount : 0,
		pCollapse: e.deckCount > 0 ? o / e.deckCount : 0,
		gemMean: t > 0 ? n / t : 0
	};
}
function je(e, t, n) {
	let r = e.carrying[t] ?? 0;
	return 1 - ke((n.gemMean * n.pGem / e.inTemple.length - n.pCollapse * r) / 1.5);
}
function Me(e) {
	let t = 0;
	for (let n of e.path) n.card.t === "artifact" && (t += N(n.card.art));
	return t;
}
function Ne(e) {
	return e.path.reduce((e, t) => e + t.gems, 0);
}
function Pe(e, t) {
	return (e.artifacts[t] ?? []).reduce((e, t) => e + N(t), 0);
}
var Fe = (e, t) => {
	let n = e.public;
	if (n.phase !== "decide" || !n.inTemple.includes(t.rid) || n.decided.includes(t.rid)) return null;
	let r = b(o(t.rid));
	if (t.difficulty === "weak") {
		let e = Oe(.3 + .55 * r.risk + (r.noise - .5) * .2, .05, .95);
		return { action: {
			type: "decide",
			choice: De() < e ? "stay" : "leave"
		} };
	}
	let i = n.carrying[t.rid] ?? 0;
	if (i === 0) return { action: {
		type: "decide",
		choice: "stay"
	} };
	let a = Ae(n), s = n.inTemple.filter((e) => e !== t.rid), c = .35 + .65 * r.herd, l = s.map((e) => je(n, e, a)), u = 1 + l.reduce((e, t) => e + (1 - t), 0), d = n.inTemple.length + (u - n.inTemple.length) * c, f = l.reduce((e, t) => e * t, 1) * c, p = 2 + Math.round(3 * r.patience), m = a.gemMean * a.pGem / d, h = 0, g = 1;
	for (let e = 0; e < p; e += 1) g *= 1 - a.pCollapse, h += m * g;
	let _ = 1 - g, v = Pe(n, t.rid), y = Math.max(0, ...Object.keys(n.artifacts).map((e) => Pe(n, e))) - v, x = (e.private?.myTent ?? 0) + v, S = 1.5 / (5 - n.round + 1), C = Oe(y / 30 * S, 0, 1) * r.compete, w = x / (x + 30) * r.compete, T = (1.45 - .9 * r.risk) * (1 - .55 * C) * (1 + .4 * w), E = Ne(n) / (1 + l.reduce((e, t) => e + t, 0)), D = h * (.7 + .6 * r.greed), O = f * Me(n) * (.4 + 1.6 * r.greed) * (1 + 1.5 * C), k = (i + E) * _ * (.2 * (1 - r.patience) * (1 - .8 * C) + .25 * w), A = D + C * 1.5 - _ * i * T - O - k;
	return { action: {
		type: "decide",
		choice: De() < ke(A / (1.2 + 3 * r.noise)) ? "stay" : "leave"
	} };
}, Ie = (e, t, n) => e.type === "decide" ? n(e.choice === "stay" ? "games.incan.stayAria" : "games.incan.leaveAria") : "", Le = {
	snake: "蛇",
	spider: "蜘蛛",
	mummy: "木乃伊",
	fire: "火",
	boulder: "落石"
}, Re = {
	needsAction(e, t) {
		let n = e.public;
		return n.phase === "decide" && n.inTemple.includes(t.rid) && e.private?.myDecision == null;
	},
	describeView(e, t) {
		let n = e.public, r = [`第 ${n.round}/5 轮。5 轮后宝石最多者胜。规则:翻出路上的牌,宝石由还在神庙里的人平分(余数留在牌上);翻出第二种相同的灾祸,神庙坍塌,还在里面的人丢掉本轮所有携带宝石;选择撤离的人带走携带宝石+顺路捡余数。`, `本轮路径(从入口到深处): ${n.path.map((e) => e.card.t === "gem" ? `宝石${e.card.value}${e.gems > 0 ? `(牌上还剩 ${e.gems} 颗没分完)` : ""}` : e.card.t === "hazard" ? `灾祸:${Le[e.card.hazard]}` : `神器#${e.card.art}(单独撤离时独得,值 5 分)`).join(" → ") || "(刚出发)"}`], i = /* @__PURE__ */ new Set();
		for (let e of n.path) e.card.t === "hazard" && i.add(e.card.hazard);
		return i.size && r.push(`已出现的灾祸(再来一张同种就坍塌): ${[...i].map((e) => Le[e]).join("、")}`), n.hazardsRemoved.length && r.push(`已坍塌移除的灾祸种类(不会再出现): ${n.hazardsRemoved.map((e) => Le[e]).join("、")}`), r.push(`还在神庙里: ${n.inTemple.map((e) => e === t.rid ? "你" : e).join(", ") || "(空了)"}`), r.push(`你的帐篷中有 ${e.private?.myTent ?? 0} 颗宝石。其他人的帐篷宝石保密，不能据此判断总分领先或落后。`), r.push(`公开收获: ${Object.keys(n.artifacts).map((e) => `${e === t.rid ? "你" : e}: 本轮携带 ${n.carrying[e] ?? 0} 颗宝石，已获得神器 ${(n.artifacts[e] ?? []).map((e) => `#${e}`).join("、") || "无"}`).join("; ")}`), r.push(`你本轮携带 ${n.carrying[t.rid] ?? 0} 颗宝石(坍塌全丢,撤离入库)。输出 decide 行动:stay 继续深入 / leave 撤离。`), r.join("\n");
	},
	actionJsonSchema: {
		type: "object",
		properties: {
			type: { const: "decide" },
			choice: { enum: ["stay", "leave"] }
		},
		required: ["type", "choice"],
		additionalProperties: !1
	},
	parseAction(e, t, n) {
		let r = I.safeParse(e);
		if (!r.success) return null;
		let i = r.data;
		if (i.type === "tick") return null;
		let a = t.public;
		return a.phase !== "decide" || !a.inTemple.includes(n.rid) ? null : i;
	}
};
//#endregion
//#region src/games/incan/fx.tsx
function ze(e, t) {
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - t) / 2,
		w: t,
		h: t
	};
}
function Z() {
	let e = document.querySelector(".incan-stage"), t = e?.closest(".game-screen-adaptive");
	return e && t && getComputedStyle(e).getPropertyValue("--incan-wide").trim() === "1" ? Math.round(Math.max(40, Math.min(64, t.clientWidth * .03, t.clientHeight * .065))) : 28;
}
function Be({ size: e, children: t }) {
	return /* @__PURE__ */ v("div", {
		className: "incan-fx-layer",
		style: {
			"--incan-fx-size": `${e}px`,
			"--incan-fx-art-size": `${e === 28 ? 24 : e}px`,
			"--incan-fx-font": `${e === 28 ? 10 : Math.min(20, Math.round(e * .36))}px`,
			"--incan-fx-gain-font": `${e === 28 ? 14 : Math.round(e * .5)}px`
		},
		children: t
	});
}
function Ve({ from: e, to: t, count: n, ms: r, delay: i, size: a }) {
	return /* @__PURE__ */ v(C, {
		from: ze(e, a),
		to: ze(t, a),
		ms: r,
		delay: i,
		children: /* @__PURE__ */ y("span", {
			className: "incan-fx-gem",
			children: [/* @__PURE__ */ v(J, {}), /* @__PURE__ */ v("b", { children: n })]
		})
	});
}
function He({ at: e, delay: t }) {
	return /* @__PURE__ */ v("span", {
		className: "incan-fx-spark",
		style: {
			left: `calc(${e.x + e.w / 2}px - var(--incan-fx-size) * .607)`,
			top: `calc(${e.y + e.h / 2}px - var(--incan-fx-size) * .607)`,
			animationDelay: `${t}ms`
		}
	});
}
function Ue({ count: e }) {
	return /* @__PURE__ */ y("span", {
		className: "incan-fx-gain",
		children: [
			"+",
			e,
			/* @__PURE__ */ v(J, {})
		]
	});
}
function Q(e, t) {
	let n = e.anchor(t);
	if (!n) return null;
	let r = Array.from(document.querySelectorAll("[data-incan-anchor]")).find((e) => e.dataset.incanAnchor === t);
	if (!r) return null;
	let i = r.getBoundingClientRect();
	if (i.width <= 0 || i.height <= 0 || getComputedStyle(r).visibility !== "visible") return null;
	let a = 0, o = 0, s = window.innerWidth, c = window.innerHeight;
	for (let e = r.parentElement; e; e = e.parentElement) {
		let t = getComputedStyle(e), n = /^(auto|scroll|hidden|clip)$/.test(t.overflowX), r = /^(auto|scroll|hidden|clip)$/.test(t.overflowY);
		if (!n && !r) continue;
		let i = e.getBoundingClientRect();
		n && (a = Math.max(a, i.left + e.clientLeft), s = Math.min(s, i.left + e.clientLeft + e.clientWidth)), r && (o = Math.max(o, i.top + e.clientTop), c = Math.min(c, i.top + e.clientTop + e.clientHeight));
	}
	return s > a && c > o && i.left >= a - 2 && i.top >= o - 2 && i.right <= s + 2 && i.bottom <= c + 2 ? n : null;
}
function We(e, t) {
	return Q(e, `bank:${t}`) ?? (t === e.myRid ? Q(e, "myBank") : null);
}
function $(e, t) {
	return Q(e, `carry:${t}`) ?? (t === e.myRid ? Q(e, "myCarry") : null);
}
var Ge = {
	roundStart(e, t) {
		let n = Q(t, "deck");
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ v(w, {
				at: n,
				ms: 700
			})
		} : null;
	},
	depart(e, t) {
		let n = e.rid;
		if (!n) return null;
		let r = We(t, n);
		if (!r) return null;
		let i = e.data, a = typeof i?.carried == "number" && i.carried > 0 ? i.carried : 0, o = typeof i?.shared == "number" && i.shared > 0 ? i.shared : 0, s = typeof i?.gems == "number" && i.gems > 0 ? i.gems : 0, c = Array.isArray(i?.artifacts) ? i.artifacts.filter((e) => Number.isInteger(e) && e >= 0 && e < 5) : [], l = $(t, n), u = Q(t, "pathPool"), d = Z();
		return {
			ms: 1350,
			node: /* @__PURE__ */ y(Be, {
				size: d,
				children: [
					a > 0 && l && /* @__PURE__ */ v(Ve, {
						from: l,
						to: r,
						count: a,
						ms: 600,
						delay: 60,
						size: d
					}),
					o > 0 && u && /* @__PURE__ */ v(Ve, {
						from: u,
						to: r,
						count: o,
						ms: 640,
						delay: 140,
						size: d
					}),
					s > 0 && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(He, {
						at: r,
						delay: 770
					}), /* @__PURE__ */ v(S, {
						at: r,
						ms: c.length ? 340 : 470,
						delay: c.length ? 990 : 790,
						children: /* @__PURE__ */ v(Ue, { count: s })
					})] }),
					c.map((e, t) => /* @__PURE__ */ v(S, {
						at: r,
						ms: 330,
						delay: 630 + t * 80,
						children: /* @__PURE__ */ y("span", {
							className: "incan-fx-art",
							children: [/* @__PURE__ */ v("b", { children: "+" }), /* @__PURE__ */ v(ye, { art: e })]
						})
					}, e)),
					s === 0 && c.length === 0 && /* @__PURE__ */ v(S, {
						at: r,
						ms: 750,
						children: /* @__PURE__ */ v(Y, {
							kind: "camp",
							size: Math.round(d * .8)
						})
					})
				]
			})
		};
	},
	reveal(e, t) {
		let n = e.data, r = typeof n?.index == "number" ? Q(t, `card:${n.index}`) : null, i = Z();
		if (n?.card?.t === "gem") {
			let e = typeof n.share == "number" ? n.share : 0, a = Array.isArray(n.to) ? n.to.filter((e) => typeof e == "string") : [];
			return e <= 0 || !a.length || !r ? r ? {
				ms: 500,
				node: /* @__PURE__ */ v(w, {
					at: r,
					ms: 500
				})
			} : null : {
				ms: 1480,
				node: /* @__PURE__ */ y(Be, {
					size: i,
					children: [a.map((n, a) => {
						let o = $(t, n);
						if (!o) return null;
						let s = 300 + a * 40;
						return /* @__PURE__ */ v(Ve, {
							from: r,
							to: o,
							count: e,
							ms: 560,
							delay: s,
							size: i
						}, n);
					}), a.map((n, r) => {
						let i = $(t, n);
						if (!i) return null;
						let a = 790 + r * 35;
						return /* @__PURE__ */ y("span", { children: [/* @__PURE__ */ v(He, {
							at: i,
							delay: a
						}), /* @__PURE__ */ v(S, {
							at: i,
							ms: 420,
							delay: a + 10,
							children: /* @__PURE__ */ v(Ue, { count: e })
						})] }, n);
					})]
				})
			};
		}
		return r ? {
			ms: 800,
			node: /* @__PURE__ */ v(w, {
				at: r,
				ms: 800
			})
		} : null;
	},
	collapse(e, t) {
		T(), navigator.vibrate?.(200);
		let n = e.data?.lost ?? {}, r = Q(t, "path"), i = Z();
		return {
			ms: 1100,
			node: /* @__PURE__ */ y(Be, {
				size: i,
				children: [
					/* @__PURE__ */ v(x, { ms: 700 }),
					r && /* @__PURE__ */ v(w, {
						at: r,
						ms: 900
					}),
					Object.entries(n).map(([e, n]) => {
						if (typeof n != "number" || n <= 0) return null;
						let r = $(t, e);
						return r ? /* @__PURE__ */ v(S, {
							at: r,
							ms: 950,
							delay: 160,
							children: /* @__PURE__ */ y("span", {
								className: "incan-fx-gain incan-fx-loss",
								children: [
									"-",
									n,
									/* @__PURE__ */ v(J, {})
								]
							})
						}, e) : null;
					})
				]
			})
		};
	}
}, Ke = {
	snake: "games.incan.hazardSnake",
	spider: "games.incan.hazardSpider",
	mummy: "games.incan.hazardMummy",
	fire: "games.incan.hazardFire",
	boulder: "games.incan.hazardBoulder"
};
function qe(e, t, n, r) {
	let i = 0, a = 1;
	for (let o = 1; o <= n; o++) {
		let s = Math.ceil(n / o), c = Math.min((e - (o - 1) * r) / o, (t - (s - 1) * r) * 1.08 / s);
		c > i && (i = c, a = o);
	}
	return i < 96 && (a = Math.max(1, Math.min(n, Math.floor((e + r) / (96 + r))))), {
		columns: a,
		width: Math.floor(Math.max(96, Math.min(480, i)) * 100) / 100
	};
}
function Je({ result: e, public: t, members: n, myRid: a, onPlayAgain: o, onBackToLobby: s }) {
	let c = t, l = d(), p = u((e) => e.locale), m = i(null), h = i(null), _ = i(null), b = i(null), x = (t) => e.scores?.[t] ?? (c.tents[t] ?? 0) + (c.artifacts[t] ?? []).reduce((e, t) => e + N(t), 0), S = /* @__PURE__ */ new Map();
	for (let { card: e } of c.path) e.t === "hazard" && S.set(e.hazard, (S.get(e.hazard) ?? 0) + 1);
	r(() => {
		let t = m.current, n = h.current, r = b.current, i = _.current;
		if (!t || !n || !r) return;
		let a = i?.querySelector(".incan-over-path-grid"), o = (e, t, n) => {
			e.style.getPropertyValue(t) !== n && e.style.setProperty(t, n);
		}, s = () => {
			let s = getComputedStyle(t).getPropertyValue("--incan-over-wide").trim() === "1";
			if (!s) r.style.removeProperty("--incan-over-rank-columns"), r.style.removeProperty("--incan-over-row-h");
			else {
				let i = c.path.length ? 1 : Math.max(1, Math.min(6, Math.floor(t.clientWidth / 300))), a = Math.max(1, Math.ceil(e.ranking.length / i)), s = Math.max(1, Math.ceil(e.ranking.length / a));
				o(r, "--incan-over-rank-columns", String(s)), o(r, "--incan-over-row-h", `${Math.max(90, Math.floor((n.clientHeight - (a - 1) * 10) / a))}px`);
			}
			if (!i || !a) return;
			let l = getComputedStyle(a), u = i.clientWidth - Number.parseFloat(l.paddingLeft) - Number.parseFloat(l.paddingRight), d = s ? i.clientHeight - Number.parseFloat(l.paddingTop) - Number.parseFloat(l.paddingBottom) : 0, f = Number.parseFloat(l.columnGap), p = qe(u, d, c.path.length, f);
			o(a, "--incan-over-path-columns", String(p.columns)), o(a, "--incan-over-card-w", `${p.width}px`);
		};
		s();
		let l = new ResizeObserver(s);
		for (let e of [
			t,
			n,
			i
		]) e && l.observe(e);
		return () => l.disconnect();
	}, [
		p,
		c.path.length,
		e.ranking.length
	]);
	let C = o ?? s;
	return /* @__PURE__ */ v("div", {
		className: "incan-over",
		children: /* @__PURE__ */ y("div", {
			ref: m,
			className: "incan-over-layout",
			children: [
				e.winner.length > 0 && /* @__PURE__ */ v(k, {}),
				/* @__PURE__ */ y("header", {
					className: "incan-over-heading",
					children: [
						/* @__PURE__ */ v(G, {
							size: 40,
							color: "#e2b55e"
						}),
						/* @__PURE__ */ v("h1", { children: l("games.incan.resultTitle") }),
						/* @__PURE__ */ v("span", { children: l("games.incan.roundShort", {
							n: c.round,
							total: 5
						}) })
					]
				}),
				/* @__PURE__ */ y("div", {
					ref: h,
					className: "incan-over-main",
					"data-empty-path": c.path.length === 0,
					children: [/* @__PURE__ */ v("ol", {
						ref: b,
						className: "incan-over-ranking",
						children: e.ranking.map((t) => {
							let r = n.find((e) => e.rid === t), i = r ? g(r, p) : t, o = x(t), s = e.ranking.findIndex((e) => x(e) === o) + 1, u = c.artifacts[t] ?? [], d = u.reduce((e, t) => e + N(t), 0), f = e.winner.includes(t), m = e.autopilot?.[t];
							return /* @__PURE__ */ y("li", {
								className: "incan-over-player",
								"data-winner": f,
								children: [
									/* @__PURE__ */ y("div", {
										className: "incan-over-person",
										children: [
											/* @__PURE__ */ v("span", {
												className: "incan-over-rank",
												"aria-label": l("games.incan.resultRank", { n: s }),
												children: s
											}),
											/* @__PURE__ */ v("span", {
												className: "incan-over-avatar",
												style: { background: O[(r?.colorIndex ?? 0) % O.length].hex },
												children: r && /* @__PURE__ */ v("img", {
													src: E[r.avatar % E.length],
													alt: "",
													draggable: !1
												})
											}),
											/* @__PURE__ */ y("div", {
												className: "incan-over-name",
												children: [/* @__PURE__ */ v("h2", {
													title: i,
													children: i
												}), /* @__PURE__ */ y("div", {
													className: "incan-over-flags",
													children: [t === a && /* @__PURE__ */ v("span", { children: l("lobby.you") }), f && /* @__PURE__ */ v("b", { children: l("games.incan.resultWinner") })]
												})]
											}),
											/* @__PURE__ */ y("div", {
												className: "incan-over-total",
												children: [/* @__PURE__ */ v("span", { children: l("games.incan.resultTotal") }), /* @__PURE__ */ v("strong", { children: o })]
											})
										]
									}),
									/* @__PURE__ */ y("div", {
										className: "incan-over-details",
										children: [
											/* @__PURE__ */ y("span", { children: [/* @__PURE__ */ v(J, {}), l("games.incan.resultGems", { n: c.tents[t] ?? 0 })] }),
											u.length > 0 && /* @__PURE__ */ v("span", { children: l("games.incan.resultArtifacts", { n: d }) }),
											m !== void 0 && m > 0 && /* @__PURE__ */ y("small", { children: [/* @__PURE__ */ v(D, { size: 14 }), l("session.autopilot.share", { n: Math.round(m * 100) })] })
										]
									}),
									u.length > 0 && /* @__PURE__ */ v("div", {
										className: "incan-over-artifacts",
										children: u.map((e) => /* @__PURE__ */ v("span", {
											role: "img",
											"aria-label": l("games.incan.artifactAria", { n: N(e) }),
											children: /* @__PURE__ */ v(ye, { art: e })
										}, e))
									})
								]
							}, t);
						})
					}), c.path.length > 0 && /* @__PURE__ */ y("section", {
						className: "incan-over-path-panel",
						children: [
							/* @__PURE__ */ v(f, {
								kind: "sheen",
								base: "#0e3c37",
								className: "incan-over-texture"
							}),
							/* @__PURE__ */ y("header", { children: [/* @__PURE__ */ v("h2", { children: l("games.incan.resultPath") }), /* @__PURE__ */ v("span", { children: l("games.incan.resultPathCount", { n: c.path.length }) })] }),
							/* @__PURE__ */ v("div", {
								ref: _,
								className: "incan-over-path-scroll",
								children: /* @__PURE__ */ v("ol", {
									className: "incan-over-path-grid",
									"aria-label": l("games.incan.resultPathAria"),
									children: c.path.map(({ card: e, gems: t }, n) => {
										let r = e.t === "hazard" && (S.get(e.hazard) ?? 0) > 1, i = e.t === "gem" ? l("games.incan.cardGemAria", {
											value: e.value,
											n: t
										}) : e.t === "artifact" ? l("games.incan.artifactAria", { n: N(e.art) }) : l("games.incan.cardHazardAria", { name: l(Ke[e.hazard]) }) + (r ? " · " + l("games.incan.cardHazardRepeated") : "");
										return /* @__PURE__ */ v("li", {
											role: "img",
											"aria-label": i,
											children: /* @__PURE__ */ v(q, {
												card: e,
												gems: t,
												danger: r
											})
										}, n);
									})
								})
							})
						]
					})]
				}),
				C ? /* @__PURE__ */ y("div", {
					className: "incan-over-actions safe-b",
					children: [o && /* @__PURE__ */ v("button", {
						type: "button",
						onClick: o,
						children: l("session.result.playAgain")
					}), s && /* @__PURE__ */ v("button", {
						type: "button",
						onClick: s,
						children: l("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ v("p", {
					className: "incan-over-wait safe-b",
					children: l("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/incan/entry.tsx
var Ye = {
	definition: he,
	View: xe,
	bot: Fe,
	describe: Ie,
	llm: Re,
	fx: Ge,
	OverView: Je,
	locales: {
		zh: {
			name: "印加宝藏",
			desc: "深入神庙夺宝:同种灾祸出现第二次前,带着宝石全身而退",
			rules: "游戏目标：完成五轮探险后，将自己营地中的宝石与神器价值相加，总价值最高的玩家获胜。\n流程:\n· 每轮开始时，所有玩家一同进入神庙，随后逐步深入。\n· 每次前进前，仍在神庙内的玩家同时秘密选择「深入」或「撤退」，再同时公开选择。\n· 选择撤退的玩家平分小径上散落的宝石，并将自己携带的宝石带回营地。这些宝石不再受到本轮灾祸的影响。帐篷中的宝石只由本人查看，终局时再公开；已获得的神器与本轮携带的宝石始终公开。如果只有一名玩家撤退，该玩家还会获得小径上的全部神器。\n· 撤退结算后，翻开 1 张牌。若翻出宝藏，由仍在神庙内的玩家平均分配；无法平分的宝石留在该牌上。\n· 若翻出的灾祸与本轮已出现的某张灾祸属于同一种类，神庙便会坍塌：仍在神庙内的玩家失去本轮携带的全部宝石。\n· 神庙坍塌后，将引发坍塌的该种灾祸牌从牌堆中永久移除。\n· 全员撤退或牌堆翻完时,本轮结束。",
			roundShort: "第 {{n}}/{{total}} 轮",
			decideYou: "深入,还是撤退?",
			decideHint: "全员暗选,一齐亮出",
			decideSpectator: "你在营地休整,等本轮结束",
			decideWaiting: "还等 {{n}} 人，可随时改选…",
			myChoiceStay: "已选:深入",
			myChoiceLeave: "已选:撤退",
			choiceStay: "本轮选择:深入",
			choiceLeave: "本轮选择:撤退",
			atCamp: "已撤退",
			returnedCamp: "已回营地",
			exploring: "探险中",
			departSome: "{{names}} 撤离，共带回 {{gems}} 颗宝石",
			departArtifacts: "{{name}} 独自撤离，带走 {{n}} 件神器（{{points}} 分）",
			departAllStay: "全员选择继续深入!",
			revealGem: "发现 {{value}} 颗宝石，每人分得 {{share}}",
			revealArtifact: "发现神器!独自撤离的人才能拿走",
			revealArtifactHint: "多人同时撤退,谁也拿不走",
			hazardFirst: "遇到{{name}}！再遇一次就坍塌",
			hazardDup: "第二次遇到{{name}}！神庙要塌了！",
			collapse: "{{name}}引发坍塌！庙里的人丢掉了携带的宝石",
			collapseLost: "{{names}} 空手而归",
			roundEndAllLeft: "全员安全撤离,本轮结束",
			roundEndDeckOut: "神庙探索完毕,本轮结束",
			stay: "深入",
			stayDetail: "下一张牌在等你",
			leave: "撤退",
			leaveDetail: "携带 {{carry}} · 路上待分 {{pool}}",
			leaveDetailNoPool: "携带 {{carry}}",
			stayAria: "留在神庙继续深入",
			leaveAria: "带着已有收获撤回营地",
			stripTotal: "营地宝藏 {{n}}",
			stripCarrying: "携带宝石 {{n}}",
			stripArtifacts: "已获得 {{n}} 件神器",
			stripBankShort: "营地",
			stripCarryShort: "携带",
			cardGemAria: "宝藏,原 {{value}},剩 {{n}}",
			cardHazardAria: "{{name}}灾祸",
			openCard: "{{label}}，查看详情",
			cardGemTitle: "宝藏 {{n}}",
			cardGemDetail: "牌上还留有 {{n}} 颗宝石，撤退者会平分路上的余数。",
			cardArtifactTitle: "神器 · {{n}} 分",
			cardArtifactDetail: "只有一人撤退时，才能带走路上的神器。",
			cardHazardFirst: "本轮已见这种灾祸。再翻到一张同种牌，神庙就会坍塌。",
			cardHazardRepeated: "本轮第二张同种灾祸，触发神庙坍塌。",
			closeCard: "返回石径",
			pathHistory: "本轮已翻开的全部路径牌，从左到右由浅入深",
			pathEmpty: "神庙入口,等第一张牌……",
			templeDepth: "神庙深处",
			pathCount: "已翻 {{n}} 张 · 点牌查看",
			removedHazards: "已移除 {{kinds}}",
			deckCount: "牌堆还剩 {{n}} 张",
			campRoute: "营地 → 石径 → 神庙",
			myBank: "已入库 {{n}}",
			myCarry: "携带 {{n}}",
			pathPool: "路上 {{n}}",
			waitingNext: "正在结算，下一步即将开始",
			hazardSnake: "蛇",
			hazardSpider: "蜘蛛",
			hazardMummy: "木乃伊",
			hazardFire: "大火",
			hazardBoulder: "落石",
			hazardRemoved: "已移除",
			hazardSeen: "已出现,再翻到同种灾祸就坍塌",
			hazardIdle: "未出现",
			artifactAria: "神器,价值 {{n}}",
			artifactInDeck: "还埋在牌堆里",
			resultTitle: "探险结束",
			resultWinner: "获胜者",
			resultTotal: "总分",
			resultGems: "宝石 {{n}}",
			resultArtifacts: "神器 {{n}} 分",
			resultPath: "末轮石径",
			resultPathCount: "剩余 {{n}} 张",
			resultPathAria: "末轮剩余的路径牌",
			resultRank: "第 {{n}} 名",
			errNotInTemple: "你已回营地,本轮无需抉择"
		},
		en: {
			name: "Incan Gold",
			desc: "Push into the temple for gems — get out before the same hazard strikes twice",
			rules: "Objective: After 5 expeditions, add the gems in your camp to the value of your artifacts. The player with the highest total wins.\nPlay:\n· Each round the whole party enters the temple together and goes deeper step by step.\n· At each step, everyone still inside secretly picks “go deeper” or “turn back”, revealed at once.\n· Players who leave split the loose gems on the path and bring their carried gems back to camp. Those gems are no longer at risk from hazards in this expedition. Only you can see the gems inside your tent until the end of the game; collected artifacts and carried gems remain public. If exactly one player leaves, that player also gains every artifact on the path.\n· Then a card is revealed: treasure is shared evenly among those still inside, and any remainder stays on the card.\n· A hazard matching one already seen this round collapses the temple: everyone still inside drops all gems carried this round.\n· That hazard is removed from the deck for good.\n· The round ends when everyone has left or the deck runs out.",
			roundShort: "Round {{n}}/{{total}}",
			decideYou: "Go deeper, or turn back?",
			decideHint: "Secret picks, revealed together",
			decideSpectator: "You are back at camp, waiting out this round",
			decideWaiting: "Waiting on {{n}}; you can change your pick…",
			myChoiceStay: "Picked: go deeper",
			myChoiceLeave: "Picked: turn back",
			choiceStay: "Chose to go deeper",
			choiceLeave: "Chose to turn back",
			atCamp: "Back at camp",
			returnedCamp: "Back at camp",
			exploring: "Exploring",
			departSome: "{{names}} left with {{gems}} gems in total",
			departArtifacts: "{{name}} left alone with {{n}} artifacts ({{points}} points)",
			departAllStay: "Everyone pushes deeper!",
			revealGem: "{{value}} gems found, {{share}} for each explorer",
			revealArtifact: "An artifact! Only a lone leaver can claim it",
			revealArtifactHint: "If several leave at once, nobody gets it",
			hazardFirst: "{{name}} seen. Next one collapses!",
			hazardDup: "A second {{name}}! The temple is collapsing!",
			collapse: "{{name}} triggered a collapse! Explorers inside lost their gems",
			collapseLost: "{{names}} went home empty-handed",
			roundEndAllLeft: "Everyone made it out — round over",
			roundEndDeckOut: "The temple is fully explored — round over",
			stay: "Deeper",
			stayDetail: "See the next card",
			leave: "Leave",
			leaveDetail: "Carrying {{carry}} · {{pool}} on the path",
			leaveDetailNoPool: "Carrying {{carry}}",
			stayAria: "Stay in the temple and go deeper",
			leaveAria: "Return to camp with what you carry",
			stripTotal: "Banked treasure {{n}}",
			stripCarrying: "Carried gems {{n}}",
			stripArtifacts: "{{n}} artifacts collected",
			stripBankShort: "Bank",
			stripCarryShort: "Carry",
			cardGemAria: "Treasure, was {{value}}, {{n}} left",
			cardHazardAria: "{{name}} hazard",
			openCard: "{{label}}. View details",
			cardGemTitle: "Treasure {{n}}",
			cardGemDetail: "{{n}} gems remain on this card. Those who leave split the loose gems on the path.",
			cardArtifactTitle: "Artifact · {{n}} points",
			cardArtifactDetail: "A lone player who leaves takes every artifact on the path.",
			cardHazardFirst: "This hazard has appeared this round. Another of the same kind collapses the temple.",
			cardHazardRepeated: "The second matching hazard triggers the temple collapse.",
			closeCard: "Back to the path",
			pathHistory: "All revealed path cards this round, from entrance to depth, left to right",
			pathEmpty: "Temple entrance — waiting for the first card…",
			templeDepth: "Temple depths",
			pathCount: "{{n}} revealed · tap to inspect",
			removedHazards: "Removed: {{kinds}}",
			deckCount: "{{n}} cards left in the deck",
			campRoute: "Camp → path → temple",
			myBank: "Banked {{n}}",
			myCarry: "Carrying {{n}}",
			pathPool: "On path {{n}}",
			waitingNext: "Resolving the step; play resumes shortly",
			hazardSnake: "Snake",
			hazardSpider: "Spider",
			hazardMummy: "Mummy",
			hazardFire: "Fire",
			hazardBoulder: "Boulder",
			hazardRemoved: "removed",
			hazardSeen: "seen — a second one collapses the temple",
			hazardIdle: "not seen yet",
			artifactAria: "Artifact, worth {{n}}",
			artifactInDeck: "Still buried in the deck",
			resultTitle: "Expeditions complete",
			resultWinner: "Winner",
			resultTotal: "Total",
			resultGems: "Gems {{n}}",
			resultArtifacts: "Artifacts {{n}} points",
			resultPath: "Final expedition path",
			resultPathCount: "{{n}} cards remaining",
			resultPathAria: "Remaining path cards from the final expedition",
			resultRank: "Rank {{n}}",
			errNotInTemple: "You are back at camp; nothing to pick this round"
		}
	}
};
//#endregion
export { Ye as default };
