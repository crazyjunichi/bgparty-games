import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { IconClose as s, IconInfo as c } from "@bgparty/sdk/icons";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { HintRing as u } from "@bgparty/sdk/ui/hint-ring";
import { gameAssetUrl as d } from "@bgparty/sdk/assets";
import { useI18nSettings as f } from "@bgparty/sdk/i18n";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { SheetView as g } from "@bgparty/sdk/sheet-view";
import { FlySprite as _, PulseBox as v } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as y, OptionSection as b } from "@bgparty/sdk/ui/game-options";
//#region src/games/rivals/data.ts
var x = [
	"wood",
	"brick",
	"wool",
	"grain",
	"ore",
	"gold"
], S = (e, t, n, r, i, a, o = {}) => ({
	key: e,
	zh: t,
	en: n,
	cost: r,
	textZh: i,
	textEn: a,
	type: "building",
	...o
}), C = (e, t, n, r, i) => S(e, t, n, {}, r, i, { type: "action" }), ee = [
	S("storehouse", "仓库", "Storehouse", {
		wood: 1,
		wool: 1
	}, "强盗来袭时，相邻两个地区的库存不计入资源总数。", "Do not count the two neighboring regions when checking for a Brigand Attack."),
	S("tollBridge", "收费桥", "Toll Bridge", {
		wood: 1,
		brick: 1
	}, "丰收时额外获得 2 黄金。", "Receive 2 extra gold on a Plentiful Harvest.", { commerce: 1 }),
	...[
		[
			"lumberCamp",
			"伐木场",
			"Lumber Camp",
			"wood",
			"ore"
		],
		[
			"brickFactory",
			"砖厂",
			"Brick Factory",
			"brick",
			"ore"
		],
		[
			"weaver",
			"织布坊",
			"Weaver’s Shop",
			"wood",
			"wool"
		],
		[
			"grainMill",
			"谷物磨坊",
			"Grain Mill",
			"wood",
			"grain"
		],
		[
			"ironFoundry",
			"炼铁厂",
			"Iron Foundry",
			"brick",
			"ore"
		]
	].map(([e, t, n, r, i], a) => S(e, t, n, {
		[r]: 1,
		[i]: 1
	}, "相邻同类地区的正常生产量加倍。", "Double normal production in neighboring regions of the matching type.", { resource: [
		"wood",
		"brick",
		"wool",
		"grain",
		"ore"
	][a] })),
	S("abbey", "修道院", "Abbey", {
		brick: 1,
		grain: 1,
		ore: 1
	}, "手牌上限增加 1 张。", "Increase your hand limit by 1.", {
		unique: !0,
		progress: 1
	}),
	S("marketplace", "市场", "Marketplace", {
		grain: 1,
		wool: 1
	}, "若本次对手有更多地区生产，获得其本次产出的一种资源。", "If more of your opponent’s regions produce on this roll, receive one resource of a type they produced.", {
		unique: !0,
		commerce: 1
	}),
	S("parishHall", "教区会堂", "Parish Hall", {
		brick: 1,
		grain: 1
	}, "回合结束时搜牌只支付 1 资源。", "Pay only 1 resource when searching for a card at the end of your turn.", { unique: !0 }),
	S("largeShip", "大型商船", "Large Trade Ship", {
		wood: 1,
		wool: 1
	}, "从左侧或右侧相邻的一个地区支付同类 2 资源，换取任意 1 资源。", "Trade 2 resources from one of the two neighboring regions for any 1 resource.", {
		type: "ship",
		commerce: 1
	}),
	...x.map((e) => S(`${e}Ship`, {
		wood: "木材船",
		brick: "砖块船",
		wool: "羊毛船",
		grain: "谷物船",
		ore: "矿石船",
		gold: "黄金船"
	}[e], `${{
		wood: "Lumber",
		brick: "Brick",
		wool: "Wool",
		grain: "Grain",
		ore: "Ore",
		gold: "Gold"
	}[e]} Ship`, {
		wood: 1,
		wool: 1
	}, "支付同类 2 资源，换取任意 1 资源。", "Trade 2 resources of the indicated type for any 1 resource.", {
		type: "ship",
		commerce: 1,
		resource: e
	})),
	...[
		[
			"austin",
			"奥斯汀",
			"Austin",
			{
				grain: 1,
				ore: 1
			},
			1,
			2
		],
		[
			"harald",
			"哈拉尔德",
			"Harald",
			{
				grain: 1,
				ore: 1
			},
			2,
			1
		],
		[
			"inga",
			"英加",
			"Inga",
			{
				grain: 1,
				wool: 1,
				ore: 1
			},
			1,
			3
		],
		[
			"osmund",
			"奥斯蒙德",
			"Osmund",
			{
				grain: 1,
				wool: 1,
				ore: 1
			},
			2,
			2
		],
		[
			"candamir",
			"坎达米尔",
			"Candamir",
			{
				wool: 2,
				grain: 1,
				ore: 1
			},
			4,
			1
		],
		[
			"siglind",
			"西格琳德",
			"Siglind",
			{
				wool: 2,
				grain: 1,
				ore: 1
			},
			2,
			3
		],
		[
			"carl",
			"叉须卡尔",
			"Carl Forkbeard",
			{
				wool: 2,
				grain: 1,
				ore: 2
			},
			5,
			0
		],
		[
			"heinrich",
			"哨兵海因里希",
			"Heinrich the Sentinel",
			{
				grain: 1,
				wool: 1,
				ore: 1
			},
			2,
			0
		],
		[
			"irmgard",
			"守光者伊尔姆加德",
			"Irmgard, Keeper of the Light",
			{
				grain: 1,
				gold: 1
			},
			0,
			2
		]
	].map(([e, t, n, r, i, a]) => S(e, t, n, r, e === "heinrich" ? "对手使用弓箭手、纵火者或叛徒时，可掷骰；3–5 抵御攻击。" : e === "irmgard" ? "因事件或对手行动失去扩展牌时，获得任意 1 资源；自身被移除时不触发。" : "力量与技能按牌面图示计算。", e === "heinrich" ? "Against Archer, Arsonist or Traitor, you may roll once; 3–5 cancels the attack." : e === "irmgard" ? "Receive any 1 resource when an event or opposing action removes an expansion, unless Irmgard herself is removed." : "Count the strength and skill symbols shown.", {
		type: "hero",
		unique: !0,
		strength: i,
		skill: a
	})),
	C("brigitta", "智者布里吉塔", "Brigitta the Wise Woman", "掷骰前指定生产骰结果。", "Before rolling, choose the production die result."),
	C("relocation", "迁移", "Relocation", "交换自己的两个地区或两张扩展牌。库存随地区移动，摆放限制仍须满足。", "Exchange two of your regions or two expansions. Resources travel with their region; placement rules still apply."),
	C("scout", "侦察兵", "Scout", "建造村庄时，从地区堆选择两个地区，然后洗混其余地区。", "When building a settlement, choose two regions and reshuffle the remaining region stack."),
	C("caravan", "商队", "Merchant Caravan", "支付任意 2 资源，获得任意 2 资源。", "Pay any 2 resources and receive any 2 resources."),
	C("goldsmith", "金匠", "Goldsmith", "支付 3 黄金，获得任意 2 资源。", "Pay 3 gold and receive any 2 resources."),
	S("goldCache", "黄金储藏所", "Gold Cache", {}, "放在地区外侧，可存 0–3 黄金。强盗不计入也不夺走其中黄金。建造条件：有至少 1 力量的英雄。", "Place outside a region; stores 0–3 gold. Brigands neither count nor steal it. Requires a hero with strength.", { type: "region" }),
	S("pirate", "海盗船", "Pirate Ship", {
		wood: 1,
		wool: 1
	}, "建成时，对手选择弃掉 1 艘商船。丰收时额外获得 1 黄金。", "When built, your opponent discards one trade ship. Receive 1 extra gold on a Plentiful Harvest.", { type: "unit" }),
	S("merchantGuild", "商人公会", "Merchant Guild", {
		brick: 2,
		wool: 2,
		grain: 1
	}, "贸易大师与货栈的建造条件。", "Required for Trade Master and Staple House.", {
		city: !0,
		unique: !0,
		vp: 1,
		commerce: 2
	}),
	S("moneylender", "放贷人", "Moneylender", {
		wood: 2,
		ore: 2,
		brick: 1
	}, "拥有贸易优势时，贸易事件可拿取对手最多 2 资源。", "With the trade advantage, take up to 2 resources on a Trade event.", {
		city: !0,
		unique: !0,
		vp: 1
	}),
	S("harbor", "港口", "Harbor", {
		brick: 1,
		wool: 1,
		ore: 1
	}, "拥有至少 3 艘商船时，此牌额外提供 1 胜利点。", "Worth 1 victory point while you have at least 3 trade ships.", {
		city: !0,
		commerce: 1
	}),
	S("tradingBase", "贸易基地", "Trading Base", {
		grain: 2,
		wool: 2,
		brick: 1
	}, "每座市场及港口额外提供 1 贸易点。", "Each Marketplace and Harbor gains 1 commerce point.", {
		city: !0,
		vp: 1,
		commerce: 1
	}),
	S("mint", "铸币厂", "Mint", {
		wood: 2,
		ore: 2,
		brick: 1
	}, "每个自己的回合可使用一次：支付 1 黄金，获得其他任意 1 资源。", "Once on each of your turns, trade 1 gold for any 1 other resource.", {
		city: !0,
		vp: 1
	}),
	S("stapleHouse", "货栈", "Staple House", {
		brick: 2,
		ore: 2,
		wool: 1
	}, "建造条件：商人公会。建成后获得任意 2 资源。", "Requires Merchant Guild. When built, receive any 2 resources.", {
		city: !0,
		vp: 1
	}),
	S("saltSilo", "盐仓", "Salt Silo", {
		wool: 2,
		gold: 2,
		brick: 1
	}, "每艘商船额外提供 1 贸易点。", "Each trade ship gains 1 commerce point.", {
		city: !0,
		vp: 1
	}),
	C("tradeMaster", "贸易大师", "Trade Master", "条件：商人公会。从对手拿取最多 2 资源。", "Requires Merchant Guild. Take up to 2 resources from your opponent."),
	C("merchant", "商人", "Merchant", "条件：城市或 3 贸易点。拿取对手最多 2 资源，再返还任意 1 资源。", "Requires a city or 3 commerce points. Take up to 2 resources, then return any 1 resource."),
	C("reiner", "传令官赖纳", "Reiner the Herald", "掷骰前将事件指定为庆典；自己额外获得任意 1 资源。", "Before rolling, set the event die to Celebration; receive 1 extra resource."),
	C("brigands", "强盗", "Brigands", "条件：力量优势。拿取同类资源，数量以自己的一个地区剩余容量为限。", "Requires the strength advantage. Take one resource type, up to the space in one of your regions."),
	C("gudrun", "海上恐惧古德伦", "Gudrun, Terror of the Seas", "每艘海盗船使对手交出最多 2 黄金。", "Take up to 2 gold from your opponent for each Pirate Ship."),
	S("drillGround", "训练场", "Drill Ground", {
		brick: 1,
		ore: 1
	}, "每位英雄的费用任选减少 1 资源。", "Reduce the cost of each hero by any 1 resource.", {
		unique: !0,
		strength: 1
	}),
	S("lookout", "瞭望塔", "Lookout Tower", {
		wood: 1,
		grain: 1
	}, "对手使用弓箭手、纵火者或叛徒时，可掷骰；1–2 抵御攻击。", "Against Archer, Arsonist or Traitor, you may roll once; 1–2 cancels the attack.", { strength: 1 }),
	...["low", "high"].map((e) => S(`chapel${e}`, e === "low" ? "礼拜堂（1–3）" : "礼拜堂（4–6）", e === "low" ? "Chapel (1–3)" : "Chapel (4–6)", {
		ore: 2,
		brick: 1,
		grain: 1
	}, e === "low" ? "生产骰为 1–3 时免受暴乱。" : "生产骰为 4–6 时免受暴乱。", e === "low" ? "Immune to Riots on a production roll of 1–3." : "Immune to Riots on a production roll of 4–6.", {
		city: !0,
		vp: 1
	})),
	S("fairgrounds", "集市广场", "Fairgrounds", {
		wood: 2,
		grain: 1,
		wool: 1
	}, "建成时若技能高于对手，获得任意 2 资源。", "When built, receive any 2 resources if you have more skill than your opponent.", {
		city: !0,
		vp: 1
	}),
	S("hedgeTavern", "篱边酒馆", "Hedge Tavern", {
		gold: 2,
		grain: 1,
		wool: 1
	}, "部分攻击行动牌的使用条件。", "Required by several attack actions.", {
		city: !0,
		unique: !0,
		vp: 1
	}),
	S("titheBarn", "什一税仓", "Tithe Barn", {
		wood: 2,
		brick: 1,
		ore: 1
	}, "建成时选择谷物或羊毛，每位英雄获得该类 1 资源。", "When built, choose grain or wool; receive 1 of that resource for each hero.", {
		city: !0,
		vp: 1
	}),
	S("festivalHall", "大型庆典厅", "Large Festival Hall", {
		grain: 3,
		ore: 3,
		brick: 2
	}, "提供 2 胜利点。", "Worth 2 victory points.", {
		city: !0,
		vp: 2
	}),
	S("fireBrigade", "消防队", "Fire Brigade", {
		wool: 2,
		brick: 1,
		ore: 1
	}, "所在城市的所有建筑免受纵火者攻击。", "All buildings in this city are protected from Arsonist.", {
		city: !0,
		vp: 1
	}),
	C("voyage", "掠夺航行", "Voyage of Plunder", "条件：力量优势。拿取对手 1 资源；若自己的胜利点较少，可拿取 2 资源。", "Requires the strength advantage. Take 1 resource, or up to 2 if you have fewer victory points."),
	C("archer", "弓箭手", "Archer", "条件：篱边酒馆。对手将自己选择的一张有力量的单位牌退回匹配牌堆底。", "Requires Hedge Tavern. Your opponent returns one unit with strength to a matching draw stack."),
	C("arsonist", "纵火者", "Arsonist", "条件：篱边酒馆。将对手一座未保护建筑退回匹配牌堆底。", "Requires Hedge Tavern. Return one unprotected opposing building to a matching draw stack."),
	C("sebastian", "巡回传教士塞巴斯蒂安", "Sebastian the Itinerant Preacher", "事件发生时使用，免受暴乱、世仇或兄弟阋墙影响。", "Play when Riots, Feud or Fraternal Feuds occurs to ignore that event."),
	C("traitor", "叛徒", "Traitor", "条件：篱边酒馆。查看对手手牌，可拿取其中 1 张。", "Requires Hedge Tavern. Inspect your opponent’s hand and optionally take 1 card."),
	S("cannoneer", "首席炮手", "Chief Cannoneer", {
		wood: 1,
		ore: 1
	}, "建造条件：大学。此单位不是英雄。", "Requires University. This unit is not a hero.", {
		type: "unit",
		strength: 4
	}),
	S("townHall", "市政厅", "Town Hall", {
		wool: 2,
		ore: 2,
		brick: 1
	}, "放在城市的教区会堂上。回合结束时搜牌免费。", "Place over a Parish Hall in a city. Searching at the end of your turn is free.", {
		city: !0,
		vp: 1
	}),
	S("university", "大学", "University", {
		wood: 2,
		grain: 2,
		brick: 2
	}, "建造条件：修道院或图书馆。手牌上限增加 1 张。", "Requires Abbey or Library. Increase your hand limit by 1.", {
		city: !0,
		unique: !0,
		vp: 1,
		progress: 1
	}),
	S("library", "图书馆", "Library", {
		wood: 2,
		brick: 1,
		ore: 1
	}, "建成时可免费从一个抽牌堆选择 1 张牌。", "When built, you may search a draw stack for 1 card for free.", {
		city: !0,
		vp: 1
	}),
	S("pharmacy", "药房", "Pharmacy", {
		wool: 2,
		brick: 1,
		gold: 1
	}, "瘟疫发生时获得任意 1 资源，即使未损失资源。", "Receive any 1 resource on Plague, even if you lost no resources.", {
		city: !0,
		vp: 1
	}),
	S("bathHouse", "浴场", "Bath House", {
		brick: 2,
		wool: 1,
		ore: 1
	}, "所在城市相邻的四个地区免受瘟疫。", "Protect the four regions bordering this city from Plague.", {
		city: !0,
		vp: 1
	}),
	S("crane", "建筑起重机", "Building Crane", { wood: 1 }, "建造条件：大学。原价超过 4 资源的城市扩展任选减少 1 资源。", "Requires University. Reduce the cost of a city expansion costing more than 4 by any 1 resource.", { city: !0 }),
	S("parliament", "议会", "Parliament", {
		wood: 3,
		brick: 2,
		wool: 2
	}, "建造条件：至少 2 进步点。", "Requires at least 2 progress points.", {
		city: !0,
		vp: 2
	}),
	C("threeField", "三圃轮作", "Three-Field System", "条件：大学。获得最多 2 谷物。", "Requires University. Receive up to 2 grain."),
	C("mineral", "矿产开采", "Mineral Mining", "条件：大学。获得最多 2 矿石。", "Requires University. Receive up to 2 ore."),
	C("benjamin", "旅行学者本杰明", "Benjamin the Traveling Scholar", "本回合生产骰点数对应的每个己方地区再获得 1 资源，不叠加生产加成。", "Each of your regions matching this turn’s production roll receives 1 resource, without production boosters."),
	C("guido", "大使圭多", "Guido the Ambassador", "条件：市政厅或胜利点落后。从弃牌堆选择 1 张牌。", "Requires Town Hall or fewer victory points. Choose 1 card from the discard pile."),
	C("gustav", "图书管理员古斯塔夫", "Gustav the Librarian", "条件：图书馆或胜利点落后。从弃牌堆选择 1 张牌。", "Requires Library or fewer victory points. Choose 1 card from the discard pile."),
	C("doctor", "医生", "Doctor", "条件：浴场。选择一座浴场，其相邻四个地区各获得 1 资源。", "Requires Bath House. The four regions bordering one Bath House each receive 1 resource.")
], te = Object.fromEntries(ee.map((e) => [e.key, e])), ne = [], w = (e, t, n, r = 1, i = !1, a = !1) => {
	for (let o = 0; o < r; o++) ne.push({
		id: `${e}-${n}-${ne.length}`,
		key: t,
		set: e,
		moon: i,
		atlas: n,
		faceup: a
	});
};
(/* @__PURE__ */ "relocation.scout.brigitta.goldsmith.caravan.harald.austin.candamir.osmund.inga.siglind.largeShip.goldShip.woodShip.brickShip.grainShip.woolShip.oreShip.grainMill.brickFactory.storehouse.ironFoundry.lumberCamp.weaver.tollBridge.marketplace.parishHall.abbey".split(".")).forEach((e, t) => w("basic", e, 4100 + t, [
	1,
	2,
	2,
	2,
	2,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	2,
	1,
	1,
	1,
	1,
	2,
	2,
	2
][t])), [
	"brigands",
	"tradeMaster",
	"reiner",
	"gudrun",
	"goldsmith",
	"merchant",
	"tradeMaster",
	"goldCache",
	"merchantGuild",
	"mint",
	"mint",
	"moneylender",
	"merchantGuild",
	"harbor",
	"saltSilo",
	"stapleHouse",
	"stapleHouse",
	"tradingBase",
	"storehouse",
	"tollBridge",
	"largeShip",
	"pirate"
].forEach((e, t) => w("gold", e, 4200 + t, [5, 21].includes(t) ? 2 : 1, [
	0,
	1,
	2,
	4,
	10,
	12,
	16,
	18,
	19,
	20
].includes(t), e === "merchantGuild")), [
	"traitor",
	"traitor",
	"voyage",
	"voyage",
	"archer",
	"archer",
	"arsonist",
	"arsonist",
	"sebastian",
	"brigands",
	"hedgeTavern",
	"hedgeTavern",
	"fireBrigade",
	"fireBrigade",
	"festivalHall",
	"titheBarn",
	"fairgrounds",
	"chapellow",
	"heinrich",
	"irmgard",
	"carl",
	"lookout",
	"drillGround"
].forEach((e, t) => w("turmoil", e, 4300 + t, 1, [
	1,
	3,
	5,
	7,
	11,
	13,
	20,
	22
].includes(t), e === "hedgeTavern")), w("turmoil", "chapelhigh", 4317), [
	"benjamin",
	"brigitta",
	"mineral",
	"mineral",
	"threeField",
	"threeField",
	"doctor",
	"doctor",
	"relocation",
	"guido",
	"gustav",
	"library",
	"library",
	"bathHouse",
	"bathHouse",
	"parliament",
	"pharmacy",
	"pharmacy",
	"townHall",
	"townHall",
	"university",
	"university",
	"crane",
	"cannoneer",
	"cannoneer"
].forEach((e, t) => w("progress", e, 4400 + t, t === 13 ? 2 : 1, [
	1,
	3,
	5,
	7,
	8,
	12,
	13,
	16,
	19,
	20,
	23
].includes(t), e === "university"));
var T = ne, re = Object.fromEntries(T.map((e) => [e.id, e])), E = (e) => te[re[e]?.key ?? e], D = [], O = (e, t, n, r = 1, i = !1) => {
	for (let a = 0; a < r; a++) D.push({
		id: `event-${e}-${n}-${D.length}`,
		key: t,
		set: e,
		atlas: n,
		moon: i
	});
};
O("basic", "feud", 4e3, 1, !0), O("basic", "fraternal", 4001, 1, !0), O("basic", "invention", 4002), O("basic", "race", 4003, 1, !0), O("basic", "travel", 4004, 2, !0), O("basic", "plenty", 4005), O("basic", "plenty", 4005, 1, !0), O("basic", "yule", 4006), O("gold", "gift", 4007, 1, !0), O("gold", "race", 4008, 1, !0), O("gold", "travel", 4009), O("turmoil", "feud", 4010, 1, !0), O("turmoil", "fraternal", 4011, 1, !0), O("turmoil", "riots", 4012, 1, !0), O("turmoil", "riots", 4013), O("progress", "invention", 4014, 2, !0), O("progress", "plague", 4015, 2, !0), O("progress", "plague", 4016);
var k = Object.fromEntries(D.map((e) => [e.id, e])), ie = {
	wood: [
		3,
		2,
		4,
		6
	],
	brick: [
		2,
		3,
		5,
		1
	],
	wool: [
		1,
		4,
		5,
		6
	],
	grain: [
		5,
		6,
		3,
		1
	],
	ore: [
		6,
		5,
		2,
		4
	],
	gold: [
		4,
		1,
		3,
		2
	]
}, ae = {
	road: {
		brick: 2,
		wood: 1
	},
	settlement: {
		brick: 1,
		grain: 1,
		wool: 1,
		wood: 1
	},
	city: {
		ore: 3,
		grain: 2
	}
}, oe = (e) => e === "intro" ? 7 : e === "duel" ? 13 : 12, A = {
	id: "rivals",
	tier: "alpha",
	mechanics: [
		"hand-management",
		"engine-building",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.rivals.name",
	descKey: "games.rivals.desc",
	rulesKey: "games.rivals.rules",
	icon: "🏰",
	iconImg: "games/rivals.webp",
	rulesUrl: { en: "https://www.catan.com/sites/default/files/2021-06/rivals_for_catan_rules_200309.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#607b43",
	releasedAt: "2026-11-01T01:22:00+08:00",
	search: {
		py: "katandaoduijue katandaoliangrenduijue rivals for catan",
		init: "ktddj ktdlrdj"
	},
	hotseat: "cover"
}, j = t.enum([
	"intro",
	"gold",
	"turmoil",
	"progress",
	"duel"
]), se = t.object({ mode: j.default("intro") }).prefault({}), ce = t.discriminatedUnion("type", [t.object({
	type: t.literal("pick"),
	id: t.string().max(160)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), le = t.enum([
	"wood",
	"brick",
	"wool",
	"grain",
	"ore",
	"gold"
]), ue = t.object({
	id: t.string(),
	resource: le,
	number: t.int().min(0).max(6),
	x: t.int(),
	y: t.int(),
	amount: t.int().min(0).max(3)
}), de = t.object({
	card: t.string(),
	x: t.int(),
	y: t.int(),
	covered: t.string().nullable()
}), fe = t.object({
	strength: t.int(),
	skill: t.int(),
	commerce: t.int(),
	progress: t.int(),
	vp: t.int(),
	towns: t.int(),
	expansions: t.int(),
	advantages: t.int()
}), pe = t.object({
	rid: t.string(),
	towns: t.array(t.object({
		x: t.int(),
		city: t.boolean()
	})),
	roads: t.array(t.int()),
	regions: t.array(ue),
	expansions: t.array(de),
	handCount: t.int(),
	mintUsed: t.array(t.string()),
	stats: fe
}), me = t.object({
	id: t.string(),
	kind: t.enum([
		"card",
		"region",
		"slot",
		"stack",
		"button",
		"resource",
		"die"
	]),
	ref: t.string(),
	owner: t.string().optional(),
	card: t.string().optional(),
	n: t.number().optional(),
	x: t.number().optional(),
	y: t.number().optional(),
	tag: t.string().optional()
}), he = t.object({
	mode: j,
	phase: t.enum([
		"start",
		"preRoll",
		"main",
		"refill",
		"exchange",
		"resolve",
		"done"
	]),
	turn: t.string(),
	actor: t.string(),
	round: t.int(),
	goal: t.int(),
	prompt: t.string(),
	dice: t.object({
		production: t.int().min(0).max(6),
		event: t.string(),
		defense: t.int().min(0).max(6)
	}),
	event: t.string().nullable(),
	strengthOwner: t.string().nullable(),
	tradeOwner: t.string().nullable(),
	players: t.array(pe).length(2),
	stacks: t.array(t.object({
		set: t.enum([
			"basic",
			"gold",
			"turmoil",
			"progress"
		]),
		count: t.int()
	})),
	faceup: t.array(t.string()),
	supply: t.object({
		road: t.int(),
		settlement: t.int(),
		city: t.int(),
		regions: t.int(),
		events: t.int()
	}),
	discardTop: t.string().nullable(),
	discardCount: t.int(),
	log: t.array(t.object({
		key: t.string(),
		rid: t.string(),
		card: t.string().optional(),
		n: t.number().optional()
	}))
}), ge = t.object({
	hand: t.array(t.string()),
	options: t.array(me),
	selected: t.array(t.string()),
	reserved: t.array(t.string()),
	remaining: t.record(t.string(), t.number()),
	preview: t.string().nullable()
}), M = (e, t, n = {}) => ({
	kind: e,
	p: t,
	...n
}), N = (e, ...t) => {
	e.queue.unshift(...t);
}, P = (e, t) => e.expansions.some((e) => E(e.card).key === t || e.covered && E(e.covered).key === t), F = (e, t) => e.expansions.filter((e) => E(e.card).key === t).length, _e = (e) => e.expansions.map((e) => E(e.card)), ve = (e) => e.expansions.filter((e) => [
	"hero",
	"ship",
	"unit"
].includes(E(e.card).type)), ye = (e) => e.expansions.filter((e) => E(e.card).type === "hero"), I = (e, t) => e.regions.filter((e) => !t || e.resource === t).reduce((e, t) => e + 3 - t.amount, 0), L = (e, t) => e.regions.filter((e) => !t || e.resource === t).reduce((e, t) => e + t.amount, 0), be = (e) => Object.values(e).reduce((e, t) => e + t, 0), xe = (e, t) => Math.sign(e) === Math.sign(t), Se = (e, t) => Math.abs(e.x - t.x) === 1 && xe(e.y, t.y), Ce = (e, t) => e.regions.filter((e) => Math.abs(e.x - t) === 1 && e.number > 0), we = (e) => ve(e).filter((e) => (E(e.card).strength ?? 0) > 0 || (E(e.card).commerce ?? 0) > 0), Te = () => ({ code: "games.rivals.errAction" }), Ee = (t, n) => {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}, R = (e, t, n, r, i) => {
	e.log.push({
		key: t,
		rid: e.players[n].rid,
		...r ? { card: r } : {},
		...i === void 0 ? {} : { n: i }
	}), e.log.length > 45 && e.log.shift();
};
function z(e, t) {
	let n = e.players[t], r = _e(n), i = r.filter((e) => e.type === "ship").length, a = r.reduce((e, t) => e + (t.strength ?? 0), 0), o = r.reduce((e, t) => e + (t.skill ?? 0), 0), s = r.reduce((e, t) => e + (t.progress ?? 0), 0), c = r.reduce((e, t) => e + (t.commerce ?? 0), 0) + (P(n, "saltSilo") ? i : 0) + F(n, "tradingBase") * (F(n, "marketplace") + F(n, "harbor")), l = n.towns.reduce((e, t) => e + (t.city ? 2 : 1), 0), u = r.reduce((e, t) => e + (t.vp ?? 0), 0) + (i >= 3 ? F(n, "harbor") : 0), d = Number(e.strengthOwner === t) + Number(e.tradeOwner === t);
	return {
		strength: a,
		skill: o,
		commerce: c,
		progress: s,
		towns: l,
		expansions: u,
		advantages: d,
		vp: l + u + d
	};
}
function De(e) {
	for (let [t, n] of [["strengthOwner", "strength"], ["tradeOwner", "commerce"]]) {
		let r = z(e, 0)[n], i = z(e, 1)[n], a = e[t];
		a !== null && (a === 0 ? r : i) >= 3 && (a === 0 ? r >= i : i >= r) || (e[t] = r >= 3 && r > i ? 0 : i >= 3 && i > r ? 1 : null);
	}
	e.mode !== "intro" && ["preRoll", "main"].includes(e.phase) && z(e, e.turn).vp >= oe(e.mode) && (e.winner = e.turn, e.phase = "done", e.queue = []);
}
function B(e, t, n, r, i, a, o = 1, s = !1) {
	t.push({
		kind: "move",
		rid: e.players[n].rid,
		data: {
			from: r,
			to: i,
			n: o,
			...!s && a ? { card: a } : {}
		},
		...s && a ? {
			for: [e.players[n].rid],
			secret: { card: a }
		} : {},
		...t.length ? { with: !0 } : {}
	});
}
function V(e, t, n, r = "gain") {
	return M("gain", e, {
		n: t,
		tag: r,
		...n ? { ids: [n] } : {}
	});
}
function Oe(e, t) {
	return 3 + z(e, t).progress;
}
function ke(e, t) {
	return x.every((n) => L(e, n) >= (t[n] ?? 0));
}
function Ae(e) {
	return { ...ae[e] ?? E(e)?.cost ?? {} };
}
function je(e, t, n) {
	let r = E(n), i = e.players[t];
	return r && (r.type === "hero" && P(i, "drillGround") || r.city && be(r.cost) > 4 && P(i, "crane")) ? 1 : 0;
}
function Me(e, t, n) {
	let r = Ae(n);
	return ke(e.players[t], r) ? !0 : je(e, t, n) > 0 && x.some((n) => {
		if (!r[n]) return !1;
		let i = {
			...r,
			[n]: r[n] - 1
		};
		return ke(e.players[t], i);
	});
}
function Ne(e, t, n) {
	let r = e.players[t], i = E(n);
	return !(!i || i.unique && P(r, i.key) || [
		"university",
		"stapleHouse",
		"crane",
		"parliament",
		"goldCache",
		"cannoneer"
	].includes(i.key) && (i.key === "university" && !P(r, "abbey") && !P(r, "library") || i.key === "stapleHouse" && !P(r, "merchantGuild") || ["crane", "cannoneer"].includes(i.key) && !P(r, "university") || i.key === "parliament" && z(e, t).progress < 2 || i.key === "goldCache" && !ye(r).some((e) => (E(e.card).strength ?? 0) > 0)));
}
function Pe(e, t, n) {
	let r = e.players[t], i = r.towns.map((e) => e.x), a = Math.min(...i), o = Math.max(...i);
	if (n === "road") return e.supply.road ? [a - 1, o + 1].filter((e) => !r.roads.includes(e)).map((e) => ({
		x: e,
		y: 0
	})) : [];
	if (n === "settlement") return e.supply.settlement && e.regions.length >= 2 ? [a - 2, o + 2].filter((e) => r.roads.includes(e + (e < a ? 1 : -1))).map((e) => ({
		x: e,
		y: 0
	})) : [];
	if (n === "city") return e.supply.city ? r.towns.filter((e) => !e.city).map((e) => ({
		x: e.x,
		y: 0
	})) : [];
	let s = E(n);
	return Ne(e, t, n) ? s.type === "region" ? r.regions.filter((e) => e.number > 0 && !r.regions.some((t) => t.number === 0 && t.x === e.x && t.y === e.y * 2)).map((e) => ({
		x: e.x,
		y: e.y * 2
	})) : s.key === "townHall" ? r.expansions.filter((e) => E(e.card).key === "parishHall" && r.towns.some((t) => t.x === e.x && t.city)).map((e) => ({
		x: e.x,
		y: e.y
	})) : r.towns.flatMap((e) => !s.city || e.city ? [
		-1,
		1,
		...e.city ? [-2, 2] : []
	].filter((t) => !r.expansions.some((n) => n.x === e.x && n.y === t)).map((t) => ({
		x: e.x,
		y: t
	})) : []) : [];
}
function Fe(e) {
	return e.expansions.filter((t) => E(t.card).type === "building" && !e.expansions.some((e) => E(e.card).key === "fireBrigade" && e.x === t.x));
}
function Ie(e, t, n) {
	let r = e.players[t], i = e.players[1 - t], a = E(n).key;
	return ["brigitta", "reiner"].includes(a) ? e.phase === "preRoll" && (a === "brigitta" ? !e.productionChoice : !e.eventChoice) : e.phase !== "main" || ["scout", "sebastian"].includes(a) ? !1 : a === "goldsmith" ? L(r, "gold") >= 3 && I(r) > 0 : a === "caravan" ? L(r) >= 2 : a === "relocation" ? r.regions.filter((e) => e.number > 0).length >= 2 || r.expansions.length >= 2 : a === "tradeMaster" ? P(r, "merchantGuild") && Re(e, t).length > 0 : a === "merchant" ? (r.towns.some((e) => e.city) || z(e, t).commerce >= 3) && Re(e, t).length > 0 : a === "brigands" || a === "voyage" ? e.strengthOwner === t && Re(e, t).length > 0 : a === "gudrun" ? F(r, "pirate") > 0 && L(i, "gold") > 0 && I(r, "gold") > 0 : [
		"archer",
		"arsonist",
		"traitor"
	].includes(a) ? P(r, "hedgeTavern") && (a === "archer" ? ve(i).some((e) => (E(e.card).strength ?? 0) > 0) : a === "arsonist" ? Fe(i).length > 0 : i.hand.length > 0) : ["threeField", "mineral"].includes(a) ? P(r, "university") && I(r, a === "mineral" ? "ore" : "grain") > 0 : a === "doctor" ? P(r, "bathHouse") : a === "guido" || a === "gustav" ? e.discard.length > 0 && (P(r, a === "guido" ? "townHall" : "library") || z(e, t).vp < z(e, 1 - t).vp) : a === "benjamin";
}
var H = (e, t, n = e, r = {}) => ({
	id: e,
	kind: t,
	ref: n,
	...r
});
function U(e, t, n) {
	return e.players[t].regions.filter(n).map((n) => H(n.id, "region", n.id, {
		owner: e.players[t].rid,
		n: n.amount
	}));
}
function Le(e, t) {
	return e.stacks.flatMap((e, n) => e.cards.length && (!t || e.set === t) ? [H(String(n), "stack", String(n), {
		n: e.cards.length,
		tag: e.set
	})] : []);
}
function Re(e, t, n) {
	let r = e.players[t];
	return U(e, 1 - t, (e) => (!n || e.resource === n) && e.amount > 0 && I(r, e.resource) > 0);
}
function ze(e, t, n) {
	N(e, M("site", t, { card: n }));
}
function W(e, t, n, r, i = "pay") {
	N(e, M("payment", t, {
		cost: n,
		pay: [],
		tag: i
	}), r);
}
function Be(e, t, n, r) {
	e.players[t].hand = e.players[t].hand.filter((e) => e !== n), e.discard.push(n), B(e, r, t, `hand:${e.players[t].rid}`, "discard", n);
}
function Ve(e) {
	return [
		"gain",
		"payment",
		"searchStack",
		"removePick",
		"returnStack"
	].includes(e.kind) ? e.tag ?? e.kind : e.kind;
}
function He(e) {
	if (e.phase === "done") return [];
	let t = e.queue[0], n = t?.p ?? e.turn, r = e.players[n];
	if (!t) return e.phase === "preRoll" ? [H("roll", "button"), ...r.hand.filter((t) => Ie(e, n, t)).map((e) => H(`play:${e}`, "card", e, {
		card: e,
		tag: "play"
	}))] : e.phase === "main" ? [
		...[
			"road",
			"settlement",
			"city",
			...r.hand.filter((e) => E(e).type !== "action"),
			...e.faceup
		].filter((t) => Pe(e, n, t).length && Me(e, n, t)).map((e) => H(`build:${e}`, "card", e, {
			card: e,
			tag: "build"
		})),
		...r.hand.filter((t) => E(t).type === "action" && Ie(e, n, t)).map((e) => H(`play:${e}`, "card", e, {
			card: e,
			tag: "play"
		})),
		...We(e, n).length ? [H("trade", "button")] : [],
		...r.expansions.filter((e) => E(e.card).key === "mint" && !r.mintUsed.includes(e.card) && L(r, "gold") > 0 && I(r) > 0).map((e) => H(`mint:${e.card}`, "card", e.card, {
			card: e.card,
			tag: "mint"
		})),
		...e.mode !== "intro" && r.expansions.length ? [H("demolish", "button")] : [],
		H("end", "button")
	] : e.phase === "refill" ? r.hand.length > Oe(e, n) ? r.hand.map((e) => H(e, "card", e, {
		card: e,
		tag: "return"
	})) : r.hand.length < Oe(e, n) && Le(e).length ? Le(e) : [H("continue", "button")] : e.phase === "exchange" ? [...r.hand.map((e) => H(e, "card", e, {
		card: e,
		tag: "exchange"
	})), H("finish", "button")] : [];
	switch (t.kind) {
		case "startStack": return Le(e, "basic").filter((t) => e.mode !== "intro" || Number(t.id) !== e.firstStack);
		case "startCards": return e.stacks[t.stack].cards.filter((e) => !t.ids?.includes(e)).map((e) => H(e, "card", e, {
			card: e,
			tag: "keep"
		}));
		case "arrange": return [...r.regions.filter((e) => e.number > 0).map((e) => H(e.id, "region", e.id, { owner: r.rid })), H("ready", "button")];
		case "arrangeSecond": return U(e, n, (e) => e.number > 0 && e.id !== t.ids[0]);
		case "chooseDie": return [
			1,
			2,
			3,
			4,
			5,
			6
		].map((e) => H(String(e), "die", String(e), { n: e }));
		case "site": return [...Pe(e, n, t.card).map((e) => H(`${e.x},${e.y}`, "slot", t.card, {
			x: e.x,
			y: e.y,
			owner: r.rid,
			card: t.card
		})), H("cancel", "button")];
		case "discount": return x.filter((e) => (t.cost?.[e] ?? 0) > 0 && ke(r, {
			...t.cost,
			[e]: t.cost[e] - 1
		})).map((e) => H(e, "resource", e));
		case "payment": return U(e, n, (e) => e.amount > (t.pay ?? []).filter((t) => t === e.id).length && ((t.cost?.[e.resource] ?? 0) > 0 || t.cost?.gold === void 0 && t.n > 0));
		case "gain": return [...U(e, n, (e) => e.amount < 3 && (!t.ids || t.ids.includes(e.resource))), ...t.tag === "optionalGain" ? [H("skip", "button")] : []];
		case "steal": return [...x.filter((i) => (!t.ids || t.ids[0] === i) && L(e.players[1 - n], i) > 0 && I(r, i) > 0).map((e) => H(e, "resource", e)), ...t.tag === "optionalSteal" ? [H("skip", "button")] : []];
		case "surrender": return U(e, n, (e) => e.resource === t.ids[0] && e.amount > 0);
		case "depositSteal": return U(e, n, (e) => e.amount < 3 && e.resource === t.ids[0]);
		case "brigandsRegion": return U(e, n, (t) => t.amount < 3 && L(e.players[1 - n], t.resource) > 0);
		case "brigandsTake": return Array.from({ length: Math.min(t.n, L(e.players[1 - n], t.tag)) }, (e, t) => H(String(t + 1), "button", "demand", { n: t + 1 }));
		case "tradeType": return [...We(e, n), H("cancel", "button")];
		case "tradeGain": return U(e, n, (e) => e.amount < 3 && e.resource !== t.tag);
		case "removePick": return (t.ids ?? []).map((r) => H(r, "card", r, {
			card: r,
			owner: e.players[t.other ?? n].rid,
			tag: "remove"
		}));
		case "returnStack": return e.stacks.flatMap((e, n) => e.set === re[t.card].set ? [H(String(n), "stack", String(n), {
			tag: e.set,
			n: e.cards.length
		})] : []);
		case "scout": return [...r.hand.filter((e) => E(e).key === "scout").map((e) => H(e, "card", e, {
			card: e,
			tag: "play"
		})), H("skip", "button")];
		case "regionPick": return e.regions.filter((e) => !t.ids?.includes(e.id)).map((e) => H(e.id, "region", e.id, {
			tag: "newRegion",
			n: e.number
		}));
		case "searchStack": return [...Le(e), ...t.tag === "library" ? [H("skip", "button")] : []];
		case "searchCard": return e.stacks[t.stack].cards.map((e) => H(e, "card", e, {
			card: e,
			tag: "keep"
		}));
		case "exchangeMode": return [
			...Le(e).map((e) => ({
				...e,
				id: `random:${e.id}`,
				tag: "random"
			})),
			...L(r) >= Ge(r) ? Le(e).map((e) => ({
				...e,
				id: `search:${e.id}`,
				tag: "search"
			})) : [],
			H("cancel", "button")
		];
		case "defend": return [H("accept", "button"), ...P(r, "heinrich") || P(r, "lookout") ? [H("defend", "button")] : []];
		case "eventDefense": return [...r.hand.filter((e) => E(e).key === "sebastian").map((e) => H(e, "card", e, {
			card: e,
			tag: "play"
		})), H("accept", "button")];
		case "traitorPick": return [...e.players[1 - n].hand.map((e) => H(e, "card", e, {
			card: e,
			tag: "stealCard"
		})), H("skip", "button")];
		case "discardPick": return e.discard.filter((e) => e !== t.card).map((e) => H(e, "card", e, {
			card: e,
			tag: "keep"
		}));
		case "swapFirst": return [...r.regions.filter((e) => e.number > 0).map((e) => H(`r:${e.id}`, "region", e.id, { owner: r.rid })), ...r.expansions.map((e) => H(`e:${e.card}`, "card", e.card, {
			card: e.card,
			owner: r.rid
		}))];
		case "swapSecond": return Ke(e, n, t.ids[0]);
		case "doctor": return r.expansions.filter((e) => E(e.card).key === "bathHouse").map((e) => H(e.card, "card", e.card, {
			card: e.card,
			owner: r.rid
		}));
		case "tithe": return ["wool", "grain"].map((e) => H(e, "resource", e));
		case "market": return U(e, n, (t) => t.amount < 3 && e.productionTypes[1 - n].includes(t.resource));
		case "travel": return [
			H("skip", "button"),
			...L(r, "gold") && I(r) ? [H("1", "button", "buy", { n: 1 })] : [],
			...L(r, "gold") >= 2 && I(r) > 1 ? [H("2", "button", "buy", { n: 2 })] : []
		];
		case "riots": return [...L(r, "gold") >= t.n ? [H("payGold", "button", "pay", { n: t.n })] : [], ...we(r).map((e) => H(e.card, "card", e.card, {
			card: e.card,
			tag: "remove"
		}))];
		case "feudSelect": return e.players[1 - n].expansions.filter((e) => E(e.card).type === "building" && !t.ids?.includes(e.card)).map((t) => H(t.card, "card", t.card, {
			card: t.card,
			owner: e.players[1 - n].rid,
			tag: "select"
		}));
		case "fraternal": return e.players[1 - n].hand.map((e) => H(e, "card", e, {
			card: e,
			tag: "return"
		}));
		case "givePick": return U(e, n, (e) => e.amount > 0);
		case "giveDeposit": return U(e, n, (e) => e.amount < 3 && e.resource === t.ids[0]);
		default: return [];
	}
}
function Ue(e, t, n) {
	return P(e.players[t], `${n}Ship`) ? 2 : 3;
}
function We(e, t) {
	let n = e.players[t];
	return [...x.filter((r) => L(n, r) >= Ue(e, t, r) && x.some((e) => e !== r && I(n, e) > 0)).map((e) => H(e, "resource", e)), ...n.expansions.filter((e) => E(e.card).key === "largeShip").flatMap((e) => n.regions.filter((t) => Se(e, t) && t.amount >= 2 && x.some((e) => e !== t.resource && I(n, e) > 0)).map((t) => H(`large:${t.id}`, "region", t.id, {
		owner: n.rid,
		card: e.card
	})))];
}
function Ge(e) {
	return P(e, "townHall") ? 0 : P(e, "parishHall") ? 1 : 2;
}
function Ke(e, t, n) {
	let r = e.players[t];
	if (n.startsWith("r:")) return U(e, t, (e) => e.number > 0 && e.id !== n.slice(2)).map((e) => ({
		...e,
		id: `r:${e.id}`
	}));
	let i = r.expansions.find((e) => e.card === n.slice(2));
	return r.expansions.filter((e) => e !== i && qe(r, i, e.x, e.y) && qe(r, e, i.x, i.y)).map((e) => H(`e:${e.card}`, "card", e.card, {
		card: e.card,
		owner: r.rid
	}));
}
function qe(e, t, n, r) {
	let i = E(t.card);
	return i.type !== "region" && (!i.city || e.towns.some((e) => e.x === n && e.city)) && (Math.abs(r) <= 1 || e.towns.some((e) => e.x === n && e.city));
}
function Je(e, t, n, r, i, a) {
	let o = e.players[t], s = o.expansions.find((e) => e.card === n);
	if (!s) return;
	let c = `slot:${o.rid}:${s.x}:${s.y}`;
	s.covered ? (s.card = s.covered, s.covered = null) : o.expansions = o.expansions.filter((e) => e !== s), i && E(n).key !== "irmgard" && P(o, "irmgard") && N(e, V(t, 1)), re[n].faceup && e.mode !== "duel" ? (e.faceup.push(n), B(e, r, t, c, "supply", n)) : a ? N(e, M("returnStack", t, {
		card: n,
		tag: "publicReturn",
		ids: [c]
	})) : (e.discard.push(n), B(e, r, t, c, "discard", n)), R(e, "remove", t, n);
}
function Ye(e) {
	let t = e.allEvents.find((e) => k[e].key === "yule"), n = Ee(e, e.allEvents.filter((e) => e !== t));
	e.events = [
		...n.slice(0, 3),
		t,
		...n.slice(3)
	];
}
function Xe(e) {
	e.phase = "preRoll", e.productionChoice = 0, e.eventChoice = "", e.reiner = !1, e.dice.defense = 0, e.players[e.turn].mintUsed = [], e.event = null;
}
function Ze(t, n, r) {
	let i = se.parse(t).mode, a = {
		seed: r,
		cursor: 0,
		mode: i,
		players: [],
		turn: 0,
		round: 1,
		phase: "start",
		queue: [],
		stacks: [],
		faceup: [],
		discard: [],
		events: [],
		allEvents: [],
		regions: [],
		supply: {
			road: 7,
			settlement: 5,
			city: 7
		},
		dice: {
			production: 0,
			event: "",
			defense: 0
		},
		event: null,
		productionChoice: 0,
		eventChoice: "",
		reiner: !1,
		strengthOwner: null,
		tradeOwner: null,
		winner: null,
		firstStack: -1,
		productionTypes: [[], []],
		productionCounts: [0, 0],
		log: []
	};
	for (let e = 0; e < 2; e++) {
		let t = x.map((t) => ({
			id: `${t}-${e}`,
			resource: t,
			number: ie[t][e],
			amount: t === "gold" ? 0 : 1,
			x: {
				wood: -1,
				gold: 1,
				grain: 3,
				brick: -1,
				wool: 1,
				ore: 3
			}[t],
			y: [
				"wood",
				"gold",
				"grain"
			].includes(t) ? -1 : 1
		}));
		a.players.push({
			rid: n[e],
			towns: [{
				x: 0,
				city: !1
			}, {
				x: 2,
				city: !1
			}],
			roads: [1],
			regions: t,
			expansions: [],
			hand: [],
			mintUsed: []
		});
	}
	a.turn = e(r, a.cursor++, 2), a.regions = Ee(a, x.flatMap((e) => [2, 3].map((t) => ({
		id: `${e}-${t}`,
		resource: e,
		number: ie[e][t],
		amount: 0,
		x: 0,
		y: 0
	}))));
	let o = Ee(a, T.filter((e) => e.set === "basic").map((e) => e.id)), s = i === "intro" ? 9 : 12;
	for (let e = 0; e < o.length; e += s) a.stacks.push({
		set: "basic",
		cards: o.slice(e, e + s)
	});
	let c = i === "intro" ? [] : i === "duel" ? [
		"gold",
		"turmoil",
		"progress"
	] : [i];
	for (let e of c) {
		let t = Ee(a, T.filter((t) => t.set === e && (i === "duel" ? !t.moon : !t.faceup)).map((e) => e.id));
		if (i === "duel") a.stacks.push({
			set: e,
			cards: t
		});
		else {
			let n = t.length / 2;
			a.stacks.push({
				set: e,
				cards: t.slice(0, n)
			}, {
				set: e,
				cards: t.slice(n)
			}), a.faceup.push(...T.filter((t) => t.set === e && t.faceup).map((e) => e.id));
		}
	}
	let l = D.filter((e) => e.set === "basic" || c.includes(e.set));
	return a.allEvents = (i === "duel" ? [...l.filter((e) => !e.moon), ...Ee(a, l.filter((e) => e.moon)).slice(0, 6)] : l).map((e) => e.id), Ye(a), a.queue = [
		M("startStack", a.turn),
		M("startStack", 1 - a.turn),
		...i === "intro" ? [] : [M("arrange", a.turn), M("arrange", 1 - a.turn)],
		M("startTurn", a.turn)
	], { state: a };
}
function Qe(e) {
	N(e, M("roll", e.turn));
}
function $e(e) {
	e.productionTypes = e.players.map((t) => [...new Set(t.regions.filter((t) => t.number === e.dice.production).map((e) => e.resource))]), e.productionCounts = e.players.map((t) => t.regions.filter((t) => t.number === e.dice.production).length);
	let t = e.players.flatMap((t, n) => t.regions.filter((t) => t.number === e.dice.production).map((e) => M("produce", n, {
		ids: [e.id],
		n: 1 + t.expansions.filter((t) => E(t.card).resource === e.resource && E(t.card).type === "building" && Se(t, e)).length
	})));
	for (let n = 0; n < 2; n++) P(e.players[n], "marketplace") && e.productionCounts[n] < e.productionCounts[1 - n] && t.push(M("market", n));
	return t;
}
function et(e, t, n, r) {
	let i = E(n).key, a = e.players[t], o = 1 - t;
	switch (Be(e, t, n, r), R(e, "play", t, n), i) {
		case "brigitta":
			N(e, M("chooseDie", t));
			break;
		case "reiner":
			e.eventChoice = "celebration", e.reiner = !0;
			break;
		case "relocation":
			N(e, M("swapFirst", t));
			break;
		case "caravan":
			W(e, t, {}, M("reward", t, { n: 2 }), "caravan"), e.queue[0].n = 2;
			break;
		case "goldsmith":
			W(e, t, { gold: 3 }, M("reward", t, { n: 2 }));
			break;
		case "tradeMaster":
			N(e, M("steal", t, {
				n: 2,
				tag: "demand"
			}));
			break;
		case "merchant":
			N(e, M("steal", t, {
				n: 2,
				tag: "demand"
			}), M("give", t));
			break;
		case "voyage":
			N(e, M("steal", t, {
				n: z(e, t).vp < z(e, o).vp ? 2 : 1,
				tag: "demand"
			}));
			break;
		case "brigands":
			N(e, M("brigandsRegion", t));
			break;
		case "gudrun":
			N(e, M("steal", t, {
				n: 2 * F(a, "pirate"),
				ids: ["gold"],
				tag: "demand"
			}));
			break;
		case "archer":
		case "arsonist":
		case "traitor":
			N(e, M("defend", o, { card: n }), M("attack", t, { card: n }));
			break;
		case "threeField":
			N(e, V(t, 2, "grain"));
			break;
		case "mineral":
			N(e, V(t, 2, "ore"));
			break;
		case "benjamin":
			N(e, ...a.regions.filter((t) => t.number === e.dice.production).map((e) => M("produce", t, {
				ids: [e.id],
				n: 1
			})));
			break;
		case "guido":
		case "gustav":
			N(e, M("discardPick", t, { card: n }));
			break;
		case "doctor": N(e, M("doctor", t));
	}
}
function tt(e, t, n) {
	let r = t.p, i = e.players[r], a = t.card, o = t.x, s = t.y;
	if (a === "road") e.supply.road--, i.roads.push(o), B(e, n, r, "supply", `center:${i.rid}:${o}`, a);
	else if (a === "city") e.supply.city--, i.towns.find((e) => e.x === o).city = !0, B(e, n, r, "supply", `center:${i.rid}:${o}`, a);
	else if (a === "settlement") e.supply.settlement--, i.towns.push({
		x: o,
		city: !1
	}), B(e, n, r, "supply", `center:${i.rid}:${o}`, a), N(e, M("scout", r, { x: o }), M("newRegions", r, { x: o }));
	else {
		let t = E(a), c = i.hand.includes(a) ? `hand:${i.rid}` : "supply";
		if (i.hand = i.hand.filter((e) => e !== a), e.faceup = e.faceup.filter((e) => e !== a), t.type === "region") i.regions.push({
			id: `cache:${a}`,
			resource: "gold",
			number: 0,
			amount: 0,
			x: o,
			y: s
		});
		else {
			let e = t.key === "townHall" ? i.expansions.find((e) => e.x === o && e.y === s).card : null;
			e && (i.expansions = i.expansions.filter((t) => t.card !== e)), i.expansions.push({
				card: a,
				x: o,
				y: s,
				covered: e
			});
		}
		B(e, n, r, c, t.type === "region" ? `region:cache:${a}` : `exp:${a}`, a), t.key === "pirate" && N(e, M("removePick", 1 - r, {
			ids: e.players[1 - r].expansions.filter((e) => E(e.card).type === "ship").map((e) => e.card),
			tag: "pirate"
		})), t.key === "stapleHouse" && N(e, V(r, 2)), t.key === "fairgrounds" && z(e, r).skill > z(e, 1 - r).skill && N(e, V(r, 2)), t.key === "titheBarn" && ye(i).length && N(e, M("tithe", r, { n: ye(i).length })), t.key === "library" && N(e, M("searchStack", r, { tag: "library" }));
	}
	R(e, "build", r, a);
}
function nt(e, t) {
	let n = [];
	if (t === "feud" || t === "fraternal") {
		let r = e.strengthOwner;
		if (r !== null) {
			let i = 1 - r, a = e.players[i];
			(t === "feud" ? a.expansions.some((e) => E(e.card).type === "building") : a.hand.length) && n.push(M("eventDefense", i, { tag: t }), M("eventApply", i, {
				tag: t,
				other: r
			}));
		}
	} else for (let r = 0; r < 2; r++) {
		let i = e.players[r];
		if (t === "riots") {
			if (!we(i).length || P(i, "chapellow") && e.dice.production <= 3 || P(i, "chapelhigh") && e.dice.production >= 4) continue;
			n.push(M("eventDefense", r, { tag: t }), M("eventApply", r, { tag: t }));
		} else n.push(M("eventApply", r, { tag: t }));
	}
	return n;
}
function rt(t, n, r) {
	let i = n.p, a = t.players[i];
	switch (n.kind) {
		case "startTurn":
			Xe(t);
			break;
		case "roll": {
			t.dice.production = t.productionChoice || 1 + e(t.seed, t.cursor++, 6), t.dice.event = t.eventChoice || [
				"brigand",
				"trade",
				"celebration",
				"harvest",
				"event",
				"event"
			][e(t.seed, t.cursor++, 6)], t.phase = "main", R(t, "roll", i, void 0, t.dice.production), r.push({
				kind: "dice",
				rid: a.rid,
				data: {
					production: t.dice.production,
					event: t.dice.event
				}
			});
			let n = $e(t);
			N(t, ...t.dice.event === "brigand" ? [
				M("brigand", 0),
				M("brigand", 1),
				...n
			] : [...n, M("dieEvent", i)]);
			break;
		}
		case "produce": {
			let e = a.regions.find((e) => e.id === n.ids[0]);
			if (!e) break;
			let o = Math.min(n.n, 3 - e.amount);
			e.amount += o, o && (B(t, r, i, "dice", `region:${e.id}`, e.resource, o), R(t, "produce", i, e.resource, o));
			break;
		}
		case "brigand": {
			let e = new Set(a.regions.filter((e) => e.number === 0 || a.expansions.some((t) => E(t.card).key === "storehouse" && Se(t, e))).map((e) => e.id)), n = a.regions.filter((t) => !e.has(t.id)).reduce((e, t) => e + t.amount, 0);
			if (n > 7) for (let e of a.regions.filter((e) => e.number !== 0 && ["wool", "gold"].includes(e.resource))) {
				let n = e.amount;
				e.amount = 0, n && B(t, r, i, `region:${e.id}`, "dice", e.resource, n);
			}
			R(t, "brigand", i, void 0, n);
			break;
		}
		case "dieEvent": {
			let e = t.dice.event;
			if (e === "event" && N(t, M("drawEvent", i)), e === "trade" && t.tradeOwner !== null && N(t, M("steal", t.tradeOwner, {
				n: P(t.players[t.tradeOwner], "moneylender") ? 2 : 1,
				tag: "demand"
			})), e === "celebration") {
				let e = z(t, 0).skill, n = z(t, 1).skill;
				N(t, ...[0, 1].filter((t) => t === 0 ? e >= n : n >= e).map((e) => V(e, 1)), ...t.reiner ? [V(i, 1)] : []);
			}
			e === "harvest" && N(t, ...[0, 1].flatMap((e) => [V(e, 1), V(e, 2 * F(t.players[e], "tollBridge") + F(t.players[e], "pirate"), "gold")]));
			break;
		}
		case "drawEvent": {
			let e = t.events.pop();
			if (!e) break;
			t.event = e, R(t, "event", i, e), r.push({
				kind: "event",
				data: { card: e }
			}), k[e].key === "yule" ? (Ye(t), N(t, M("drawEvent", i))) : (t.events.unshift(e), N(t, ...nt(t, k[e].key)));
			break;
		}
		case "eventApply":
			switch (n.tag) {
				case "invention":
					N(t, V(i, Math.min(2, _e(a).filter((e) => (e.progress ?? 0) > 0).length)));
					break;
				case "plenty":
					N(t, ...a.regions.filter((e) => e.number > 0).map((e) => M("produce", i, {
						ids: [e.id],
						n: a.expansions.filter((t) => ["storehouse", "abbey"].includes(E(t.card).key) && Se(t, e)).length
					})));
					break;
				case "travel":
					N(t, M("travel", i));
					break;
				case "gift":
					N(t, V(i, ve(a).filter((e) => (E(e.card).strength ?? 0) > 0).length, "gold"));
					break;
				case "race": {
					let e = _e(a).filter((e) => e.type === "ship").length;
					e && e >= _e(t.players[1 - i]).filter((e) => e.type === "ship").length && N(t, V(i, 1));
					break;
				}
				case "plague":
					for (let e of a.regions.filter((e) => e.number > 0 && a.towns.some((t) => t.city && Math.abs(t.x - e.x) === 1) && !a.expansions.some((t) => E(t.card).key === "bathHouse" && Math.abs(t.x - e.x) === 1))) e.amount && (e.amount--, B(t, r, i, `region:${e.id}`, "event", e.resource));
					N(t, V(i, F(a, "pharmacy")));
					break;
				case "riots":
					N(t, M("riots", i, { n: we(a).length > 2 ? 2 : 1 }));
					break;
				case "feud":
					N(t, M("feudSelect", n.other, {
						ids: [],
						n: Math.min(3, a.expansions.filter((e) => E(e.card).type === "building").length),
						other: i
					}));
					break;
				case "fraternal": N(t, M("fraternal", n.other, { n: Math.min(2, a.hand.length) }));
			}
			break;
		case "payment":
			for (let e of n.pay ?? []) {
				let n = a.regions.find((t) => t.id === e);
				n.amount--, B(t, r, i, `region:${n.id}`, "supply", n.resource);
			}
			break;
		case "build":
			tt(t, n, r);
			break;
		case "reward":
			n.n > 0 && N(t, V(i, n.n, n.ids?.[0]));
			break;
		case "gain": break;
		case "newRegions": {
			let e = a.towns.map((e) => e.x), i = n.x + (n.x === Math.min(...e) ? -1 : 1), o = n.ids?.length ? n.ids.map((e) => t.regions.find((t) => t.id === e)) : t.regions.slice(-2);
			t.regions = t.regions.filter((e) => !o.includes(e)), o.forEach((e, t) => {
				e.x = i, e.y = t === 0 ? -1 : 1, e.amount = 0, a.regions.push(e);
			}), r.push({
				kind: "regionDeal",
				rid: a.rid,
				data: {
					regions: o.map((e) => ({ ...e })),
					rid: a.rid
				}
			}), n.ids?.length && Ee(t, t.regions);
			break;
		}
		case "attack": {
			let e = E(n.card).key, r = t.players[1 - i];
			e === "archer" && N(t, M("removePick", 1 - i, {
				ids: ve(r).filter((e) => (E(e.card).strength ?? 0) > 0).map((e) => e.card),
				tag: "attack"
			})), e === "arsonist" && N(t, M("removePick", i, {
				ids: Fe(r).map((e) => e.card),
				other: 1 - i,
				tag: "attack"
			})), e === "traitor" && N(t, M("traitorPick", i));
			break;
		}
		case "defenseRoll": {
			let n = 1 + e(t.seed, t.cursor++, 6);
			t.dice.defense = n, r.push({
				kind: "defense",
				rid: a.rid,
				data: { n }
			}), (P(a, "lookout") && n <= 2 || P(a, "heinrich") && n >= 3 && n <= 5) && (t.queue[0]?.kind === "attack" && t.queue.shift(), R(t, "defended", i));
			break;
		}
		case "finishTurn":
			if (t.mode === "intro" && z(t, t.turn).vp >= 7) {
				t.winner = t.turn, t.phase = "done", t.queue = [];
				break;
			}
			t.turn = 1 - t.turn, t.turn === 0 && t.round++, Xe(t);
			break;
		case "exchangeDraw": {
			let e = t.stacks[n.stack].cards.pop();
			e && (a.hand.push(e), B(t, r, i, `stack:${n.stack}`, `hand:${a.rid}`, e, 1, !0)), N(t, M("finishTurn", i));
			break;
		}
		case "give": L(a) && N(t, M("givePick", i));
	}
}
function it(e, t, n, r) {
	let i = t.p, a = e.players[i];
	switch (t.kind) {
		case "startStack": {
			let t = Number(n);
			if (e.mode === "intro") {
				let n = e.stacks[t].cards.splice(-3);
				a.hand.push(...n), e.firstStack = t, n.forEach((n) => B(e, r, i, `stack:${t}`, `hand:${a.rid}`, n, 1, !0));
			} else N(e, M("startCards", i, {
				stack: t,
				ids: [],
				n: 3
			}));
			break;
		}
		case "startCards": {
			let o = [...t.ids ?? [], n];
			o.length < 3 ? N(e, {
				...t,
				ids: o
			}) : (e.stacks[t.stack].cards = e.stacks[t.stack].cards.filter((e) => !o.includes(e)), a.hand.push(...o), o.forEach((n) => B(e, r, i, `stack:${t.stack}`, `hand:${a.rid}`, n, 1, !0)));
			break;
		}
		case "arrange":
			n !== "ready" && N(e, M("arrangeSecond", i, { ids: [n] }), t);
			break;
		case "arrangeSecond": {
			let e = a.regions.find((e) => e.id === t.ids[0]), i = a.regions.find((e) => e.id === n), o = `rslot:${a.rid}:${e.x}:${e.y}`, s = `rslot:${a.rid}:${i.x}:${i.y}`;
			[e.x, i.x] = [i.x, e.x], [e.y, i.y] = [i.y, e.y], r.push({
				kind: "regionSwap",
				rid: a.rid,
				data: {
					a: { ...e },
					b: { ...i },
					rid: a.rid,
					fromA: o,
					fromB: s
				}
			});
			break;
		}
		case "chooseDie":
			e.productionChoice = Number(n);
			break;
		case "site": {
			if (n === "cancel") break;
			let [r, a] = n.split(",").map(Number), o = Ae(t.card), s = M("build", i, {
				card: t.card,
				x: r,
				y: a
			});
			je(e, i, t.card) ? N(e, M("discount", i, { cost: o }), M("payment", i, {
				cost: o,
				pay: []
			}), s) : W(e, i, o, s);
			break;
		}
		case "discount": {
			let t = e.queue[0];
			t.cost = {
				...t.cost,
				[n]: t.cost[n] - 1
			};
			break;
		}
		case "payment": {
			let r = a.regions.find((e) => e.id === n), i = [...t.pay ?? [], n], o = { ...t.cost };
			t.n ? N(e, {
				...t,
				pay: i,
				n: t.n - 1
			}) : (o[r.resource] = (o[r.resource] ?? 0) - 1, N(e, {
				...t,
				pay: i,
				cost: o
			}));
			break;
		}
		case "gain": {
			if (n === "skip") break;
			let o = a.regions.find((e) => e.id === n);
			o.amount++, B(e, r, i, t.tag === "market" ? "dice" : "supply", `region:${n}`, o.resource), R(e, "gain", i, o.resource, 1), t.n > 1 && N(e, {
				...t,
				n: t.n - 1
			});
			break;
		}
		case "steal":
			if (n === "skip") break;
			N(e, M("surrender", 1 - i, {
				ids: [n],
				other: i
			}), ...t.n > 1 ? [{
				...t,
				n: t.n - 1,
				tag: "optionalSteal"
			}] : []);
			break;
		case "surrender": {
			let i = a.regions.find((e) => e.id === n), o = t.other;
			if (i.amount--, t.ids[1]) {
				let a = e.players[o].regions.find((e) => e.id === t.ids[1]);
				a.amount++, B(e, r, o, `region:${n}`, `region:${a.id}`, i.resource);
			} else N(e, M("depositSteal", o, { ids: [i.resource, n] }));
			break;
		}
		case "depositSteal": {
			let o = a.regions.find((e) => e.id === n);
			o.amount++, B(e, r, i, `region:${t.ids[1]}`, `region:${n}`, o.resource), R(e, "steal", i, o.resource);
			break;
		}
		case "brigandsRegion": {
			let t = a.regions.find((e) => e.id === n);
			N(e, M("brigandsTake", i, {
				ids: [n],
				n: 3 - t.amount,
				tag: t.resource
			}));
			break;
		}
		case "brigandsTake":
			N(e, ...Array.from({ length: Number(n) }, () => M("surrender", 1 - i, {
				ids: [t.tag, t.ids[0]],
				other: i
			})));
			break;
		case "tradeType":
			if (n === "cancel") break;
			if (n.startsWith("large:")) {
				let t = a.regions.find((e) => e.id === n.slice(6));
				t.amount -= 2, B(e, r, i, `region:${t.id}`, "supply", t.resource, 2), N(e, M("tradeGain", i, { tag: t.resource }));
			} else W(e, i, { [n]: Ue(e, i, n) }, M("tradeGain", i, { tag: n }));
			break;
		case "tradeGain": {
			let t = a.regions.find((e) => e.id === n);
			t.amount++, B(e, r, i, "supply", `region:${n}`, t.resource), R(e, "trade", i, t.resource);
			break;
		}
		case "removePick":
			Je(e, t.other ?? i, n, r, t.tag !== "demolish", !["demolish", "pirate"].includes(t.tag));
			break;
		case "returnStack":
			e.stacks[Number(n)].cards.unshift(t.card), B(e, r, i, t.ids?.[0] ?? `hand:${a.rid}`, `stack:${n}`, t.card, 1, t.tag !== "publicReturn");
			break;
		case "scout":
			if (n === "skip") break;
			Be(e, i, n, r), e.queue[0]?.kind === "newRegions" && e.queue.shift(), N(e, M("regionPick", i, {
				x: t.x,
				ids: []
			}));
			break;
		case "regionPick": {
			let r = [...t.ids ?? [], n];
			r.length < 2 ? N(e, {
				...t,
				ids: r
			}) : N(e, M("newRegions", i, {
				x: t.x,
				ids: r
			}));
			break;
		}
		case "searchStack":
			n !== "skip" && N(e, M("searchCard", i, {
				stack: Number(n),
				tag: t.tag
			}));
			break;
		case "searchCard":
			e.stacks[t.stack].cards = e.stacks[t.stack].cards.filter((e) => e !== n), a.hand.push(n), B(e, r, i, `stack:${t.stack}`, `hand:${a.rid}`, n, 1, !0), t.tag === "exchange" && N(e, M("finishTurn", i));
			break;
		case "exchangeMode": {
			if (n === "cancel") break;
			let [r, o] = n.split(":"), s = Number(o), c = r === "random" ? M("exchangeDraw", i, { stack: s }) : M("searchCard", i, {
				stack: s,
				tag: "exchange"
			});
			a.hand = a.hand.filter((e) => e !== t.card), N(e, M("returnStack", i, { card: t.card }), ...r === "search" ? [M("payment", i, {
				cost: {},
				pay: [],
				n: Ge(a),
				tag: "searchPay"
			})] : [], c);
			break;
		}
		case "defend":
			n === "defend" && N(e, M("defenseRoll", i));
			break;
		case "eventDefense":
			if (n === "accept") break;
			Be(e, i, n, r), e.queue[0]?.kind === "eventApply" && e.queue[0].p === i && e.queue.shift(), R(e, "defended", i, n);
			break;
		case "traitorPick":
			n !== "skip" && (e.players[1 - i].hand = e.players[1 - i].hand.filter((e) => e !== n), a.hand.push(n), B(e, r, i, `hand:${e.players[1 - i].rid}`, `hand:${a.rid}`, n, 1, !0));
			break;
		case "discardPick":
			e.discard = e.discard.filter((e) => e !== n), a.hand.push(n), B(e, r, i, "discard", `hand:${a.rid}`, n);
			break;
		case "swapFirst":
			N(e, M("swapSecond", i, { ids: [n] }));
			break;
		case "swapSecond": {
			let o = t.ids[0];
			if (o.startsWith("r:")) {
				let e = a.regions.find((e) => e.id === o.slice(2)), t = a.regions.find((e) => e.id === n.slice(2)), i = `rslot:${a.rid}:${e.x}:${e.y}`, s = `rslot:${a.rid}:${t.x}:${t.y}`;
				[e.x, t.x] = [t.x, e.x], [e.y, t.y] = [t.y, e.y], r.push({
					kind: "regionSwap",
					rid: a.rid,
					data: {
						a: { ...e },
						b: { ...t },
						rid: a.rid,
						fromA: i,
						fromB: s
					}
				});
			} else {
				let t = a.expansions.find((e) => e.card === o.slice(2)), s = a.expansions.find((e) => e.card === n.slice(2)), c = `slot:${a.rid}:${t.x}:${t.y}`, l = `slot:${a.rid}:${s.x}:${s.y}`;
				[t.x, s.x] = [s.x, t.x], [t.y, s.y] = [s.y, t.y], B(e, r, i, c, `exp:${t.card}`, t.card), B(e, r, i, l, `exp:${s.card}`, s.card);
			}
			break;
		}
		case "doctor":
			N(e, ...Ce(a, a.expansions.find((e) => e.card === n).x).map((e) => M("produce", i, {
				ids: [e.id],
				n: 1
			})));
			break;
		case "tithe":
			N(e, V(i, t.n, n));
			break;
		case "market": {
			let t = a.regions.find((e) => e.id === n);
			t.amount++, B(e, r, i, "dice", `region:${n}`, t.resource);
			break;
		}
		case "travel":
			n !== "skip" && W(e, i, { gold: Number(n) }, M("reward", i, { n: Number(n) }));
			break;
		case "riots":
			n === "payGold" ? W(e, i, { gold: t.n }, M("noop", i)) : Je(e, i, n, r, !0, !0);
			break;
		case "feudSelect": {
			let r = [...t.ids ?? [], n];
			r.length < t.n ? N(e, {
				...t,
				ids: r
			}) : N(e, M("removePick", t.other, {
				ids: r,
				tag: "feud"
			}));
			break;
		}
		case "fraternal": {
			let r = 1 - i;
			e.players[r].hand = e.players[r].hand.filter((e) => e !== n), N(e, M("returnStack", i, {
				card: n,
				ids: [`hand:${e.players[r].rid}`]
			}), ...t.n > 1 ? [{
				...t,
				n: t.n - 1
			}] : []);
			break;
		}
		case "givePick": {
			let t = a.regions.find((e) => e.id === n);
			t.amount--, N(e, M("giveDeposit", 1 - i, { ids: [t.resource, t.id] }));
			break;
		}
		case "giveDeposit": {
			let o = a.regions.find((e) => e.id === n);
			o.amount++, B(e, r, i, `region:${t.ids[1]}`, `region:${n}`, o.resource);
			break;
		}
	}
}
function at(e, t, n) {
	let r = structuredClone(e), i = [], a = r.queue[0];
	if (r.phase === "done") return Te();
	if (t.type === "tick") {
		if (n.by !== "$engine" || !a || !ot(r, a)) return Te();
		r.queue.shift(), rt(r, a, i);
	} else {
		let e = a?.p ?? r.turn;
		if (n.by !== r.players[e].rid || ot(r, a) || !He(r).some((e) => e.id === t.id)) return Te();
		let o = t.id, s = r.players[e];
		if (a) r.queue.shift(), it(r, a, o, i);
		else if (r.phase === "preRoll") o === "roll" ? Qe(r) : et(r, e, o.slice(5), i);
		else if (r.phase === "main") {
			if (o.startsWith("build:")) ze(r, e, o.slice(6));
			else if (o.startsWith("play:")) et(r, e, o.slice(5), i);
			else if (o.startsWith("mint:")) {
				let t = o.slice(5);
				s.mintUsed.push(t), W(r, e, { gold: 1 }, M("tradeGain", e, { tag: "gold" }));
			} else o === "trade" ? N(r, M("tradeType", e)) : o === "demolish" ? N(r, M("removePick", e, {
				ids: s.expansions.map((e) => e.card),
				tag: "demolish"
			})) : o === "end" && (r.phase = "refill");
		} else if (r.phase === "refill") {
			if (o === "continue") r.phase = "exchange";
			else if (s.hand.length > Oe(r, e)) s.hand = s.hand.filter((e) => e !== o), N(r, M("returnStack", e, { card: o }));
			else {
				let t = Number(o), n = r.stacks[t].cards.pop();
				n && (s.hand.push(n), B(r, i, e, `stack:${t}`, `hand:${s.rid}`, n, 1, !0));
			}
		} else r.phase === "exchange" && (o === "finish" ? N(r, M("finishTurn", e)) : N(r, M("exchangeMode", e, { card: o })));
	}
	return De(r), {
		state: r,
		fx: i
	};
}
function ot(e, t) {
	return t ? t.kind === "payment" ? (t.n ?? 0) <= 0 && be(t.cost ?? {}) <= 0 : t.kind === "gain" ? (t.n ?? 0) <= 0 || He(e).length === 0 : [
		"startTurn",
		"roll",
		"produce",
		"brigand",
		"dieEvent",
		"drawEvent",
		"eventApply",
		"reward",
		"build",
		"newRegions",
		"attack",
		"defenseRoll",
		"finishTurn",
		"exchangeDraw",
		"give",
		"noop"
	].includes(t.kind) || He(e).length === 0 : !1;
}
function st(e, t) {
	let n = e.queue[0], r = n?.p ?? e.turn, i = e.players.find((e) => e.rid === t), a = e.players[r].rid === t;
	return {
		public: {
			mode: e.mode,
			phase: e.phase === "done" ? "done" : n ? "resolve" : e.phase,
			turn: e.players[e.turn].rid,
			actor: e.players[r].rid,
			round: e.round,
			goal: oe(e.mode),
			prompt: n ? Ve(n) : e.phase,
			dice: { ...e.dice },
			event: e.event,
			strengthOwner: e.strengthOwner === null ? null : e.players[e.strengthOwner].rid,
			tradeOwner: e.tradeOwner === null ? null : e.players[e.tradeOwner].rid,
			players: e.players.map((t, n) => ({
				rid: t.rid,
				towns: structuredClone(t.towns),
				roads: [...t.roads],
				regions: structuredClone(t.regions),
				expansions: structuredClone(t.expansions),
				handCount: t.hand.length,
				mintUsed: [...t.mintUsed],
				stats: z(e, n)
			})),
			stacks: e.stacks.map((e) => ({
				set: e.set,
				count: e.cards.length
			})),
			faceup: [...e.faceup],
			supply: {
				...e.supply,
				regions: e.regions.length,
				events: e.events.length
			},
			discardTop: e.discard.at(-1) ?? null,
			discardCount: e.discard.length,
			log: structuredClone(e.log)
		},
		private: {
			hand: [...i?.hand ?? []],
			options: a && !ot(e, n) ? He(e) : [],
			selected: a && n ? [...n.kind === "payment" ? n.pay ?? [] : [
				"startCards",
				"arrangeSecond",
				"swapSecond",
				"regionPick",
				"feudSelect"
			].includes(n.kind) ? n.ids ?? [] : []] : [],
			reserved: a && n?.kind === "payment" ? [...n.pay ?? []] : [],
			remaining: a ? { ...n?.cost } : {},
			preview: a ? n?.card ?? null : null
		}
	};
}
var ct = {
	meta: A,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ce,
		config: se,
		publicView: he,
		privateView: ge
	},
	setup: Ze,
	reduce: at,
	viewFor: st,
	status: (e) => e.winner === null ? { phase: e.phase } : {
		phase: "done",
		winner: [e.players[e.winner].rid],
		ranking: [e.players[e.winner].rid, e.players[1 - e.winner].rid],
		scores: Object.fromEntries(e.players.map((t, n) => [t.rid, z(e, n).vp]))
	},
	nextTickIn: (e) => e.queue[0] && ot(e, e.queue[0]) ? 520 : null
}, lt = {
	name: "卡坦岛：对决",
	desc: "双人卡牌卡坦：经营领地、争夺力量与贸易优势，体验三个时代与王侯对决。",
	roundLabel: "第 {{n}} 回合",
	tradeEvent: "贸易事件",
	demand: "选择拿取资源的数量",
	surrender: "选择交出资源的地区",
	roadText: "连接自己的领地边缘，以继续建造村庄。",
	settlementText: "提供 1 胜利点，上下各有 1 个扩展位置，建成后获得两个新地区。",
	cityText: "升级村庄，共提供 2 胜利点，上下各有 2 个扩展位置。",
	feudText: "力量优势持有者指定对手最多三座建筑，对手选择其中一座退回匹配的牌堆底。",
	fraternalText: "力量优势持有者查看对手的手牌，选择两张退回匹配的牌堆底。",
	inventionText: "每座有进步点的建筑提供任意 1 资源，每人最多获得 2 资源。",
	raceText: "商船最多的玩家获得任意 1 资源。平手时双方各获得 1 资源，但必须至少有一艘商船。",
	travelText: "双方各可支付最多 2 黄金，每支付 1 黄金获得任意 1 资源。",
	plentyText: "每个地区为相邻的每座仓库及修道院各获得 1 资源。",
	yuleText: "按开局方式重新准备事件牌堆，然后重新抽取一张事件牌。",
	giftText: "每位玩家为自己每个有力量点的单位获得 1 黄金。",
	riotsText: "有力量或贸易点的单位为一至两个时支付 1 黄金，三个以上时支付 2 黄金，或选择退回一个这样的单位。礼拜堂与塞巴斯蒂安可抵御。",
	plagueText: "城市相邻的地区各失去 1 资源，重叠地区仅失去一次。浴场保护所在城市相邻地区，每座药房获得任意 1 资源。",
	rules: "目标：\n通过村庄、城市、扩展牌和力量／贸易优势获得胜利点。入门模式在自己回合结束时达到 7 分获胜；单个主题在自己的回合任意时刻达到 12 分获胜；王侯对决的目标为 13 分。优势标记各值 1 分，必须至少有 3 点且高于对手才能取得；持有者平手时保留。\n\n准备：\n每人有 2 座村庄、1 条道路及六类地区。非黄金地区起始各存放 1 份资源，黄金为 0，每个地区最多存放 3 份资源。入门使用基础 36 张手牌，分为 4 堆，每人从不同一堆顶抽 3 张。主题与对决使用 3 堆基础牌；每人从一个基础堆选择 3 张，并可重新排列起始地区。主题加入所选时代的全部内容；对决加入三个主题但移除半月手牌，事件使用全部 6 张无半月牌和随机 6 张半月牌。\n\n回合流程：\n掷骰前可使用指定骰面的行动牌。然后掷生产骰与事件骰。强盗来袭先检查库存：不受仓库保护、且不在黄金储藏所中的资源超过 7 时，失去所有地区中的羊毛与黄金；仓库只影响计数，不保护这些资源不被夺走。之后进行生产。其他骰面先生产再结算事件。生产骰对应的每个地区获得1份资源，相邻对应生产建筑使正常产出加倍。库存满时溢出的资源丢失。\n· 贸易：由贸易优势持有者拿取对手的1份资源；放贷人可将此数量增加至 2 份资源。\n· 庆典：技能较高的玩家获得任意1份资源；技能相同时，双方各获得任意1份资源。\n· 丰收：双方各获得任意1份资源。此外，每座收费桥提供2份黄金，每艘海盗船提供1份黄金。\n事件牌逐张结算；抽到圣诞节时重建牌堆，在底部 3 张之上放置圣诞节，再抽一次。\n\n行动阶段：\n可按任意顺序反复建造、交易、使用合法行动牌，主题与对决还可免费拆除建筑或单位。村庄上下各有 1 个扩展位置，城市上下各有 2 个。红色城市扩展只可放在城市。新村庄须沿道路向外延伸，并获得 2 个库存为 0 的地区。建造费用如下：\n· 道路：支付 2 份砖块和 1 份木材。\n· 村庄：支付木材、砖块、羊毛、谷物各 1 份。\n· 城市：支付 3 份矿石和 2 份谷物。\n牌面费用、图标及条件另行适用，减少费用时自行选择资源。\n通常可以支付3份同类资源，兑换任意1份其他资源；拥有对应商船时，兑换比例改为2比1。大型商船只能使用其左侧或右侧相邻的单个地区支付2份资源。每座铸币厂在自己的每个回合中可以使用一次，以1份黄金兑换1份其他资源。支付、存放或拿取资源时，由玩家选择具体地区。\n\n补牌与换牌：\n行动结束后，将手牌数量调整至“3加进步点数”张。超过此上限时，选择多余的手牌，放回牌背匹配的抽牌堆底部；不足此上限时，自行选择抽牌堆，逐张抽牌补足。然后可以换 1 张手牌：随机抽牌免费；搜索指定卡牌需要支付任意2份资源；拥有教区会堂时，费用减为1份资源，有市政厅时免费。搜索卡牌或选择起始手牌时，都不能改变抽牌堆中卡牌的顺序。空堆的位置保留，仍可放回匹配牌背的卡牌。最后结束回合。\n\n主题与事件：\n黄金时代发展商船、海盗及贸易；动乱时代加入攻击、防御与暴乱；进步时代发展大学、图书馆、浴场及进步行动。单主题的商人公会、篱边酒馆或大学从公开供给建造，不进入手牌；对决把未带半月的相应牌放入主题抽牌堆。名称带唯一标记的建筑每人最多 1 座。英雄不可重复，首席炮手不属于英雄。\n兄弟阋墙仅让力量优势持有者查看并退回对手的 2 张手牌。世仇由优势持有者指定对手最多 3 座建筑，对手选择其中 1 座退回。暴乱按有力量或贸易点的单位数量支付1份或2份黄金，或选择退回其中一个单位；对应礼拜堂及塞巴斯蒂安可提供保护。瘟疫使城市相邻地区各失去1份资源，同一地区只损失一次，浴场保护所在城市相邻地区，每座药房仍获得任意1份资源。更多牌面例外见卡牌详情与官方规则书。",
	intro: "入门",
	gold: "黄金时代",
	turmoil: "动乱时代",
	progress: "进步时代",
	duel: "王侯对决",
	mode: "游戏模式",
	wood: "木材",
	brick: "砖块",
	wool: "羊毛",
	grain: "谷物",
	ore: "矿石",
	goldResource: "黄金",
	strength: "力量",
	skill: "技能",
	commerce: "贸易",
	progressPoint: "进步",
	vp: "胜利点",
	road: "道路",
	settlement: "村庄",
	city: "城市",
	regions: "地区",
	events: "事件",
	basic: "基础",
	supply: "供给",
	discard: "弃牌",
	hand: "手牌",
	start: "准备领地",
	preRoll: "掷骰前",
	main: "行动阶段",
	refill: "补充手牌",
	exchange: "可交换一张手牌",
	resolve: "结算中",
	done: "对局结束",
	roll: "掷骰",
	end: "结束行动",
	finish: "结束回合",
	continue: "继续",
	cancel: "取消",
	skip: "跳过",
	ready: "完成排列",
	trade: "交易",
	demolish: "拆除",
	mint: "使用铸币厂",
	accept: "不使用防御",
	defend: "掷骰防御",
	payGold: "支付黄金",
	pay: "支付资源",
	random: "随机抽取",
	search: "搜选卡牌",
	buy: "兑换资源",
	build: "建造",
	play: "使用",
	keep: "拿取",
	remove: "移除",
	select: "选择",
	return: "退回",
	exchangeCard: "换牌",
	detail: "查看详情",
	close: "关闭",
	waiting: "等待 {name}",
	yourTurn: "轮到你了",
	target: "合法位置",
	view: "查看领地",
	self: "自己的领地",
	opponent: "对手领地",
	fit: "适应大小",
	zoomIn: "放大",
	zoomOut: "缩小",
	startStack: "选择起手牌堆",
	startCards: "选择三张起手牌",
	arrange: "选择地区以交换位置，或完成排列",
	arrangeSecond: "选择交换的另一个地区",
	chooseDie: "选择生产骰结果",
	site: "选择建造位置",
	discount: "选择减免的资源",
	payment: "选择支付资源的地区",
	gain: "选择存放资源的地区",
	optionalGain: "选择存放地区，或跳过",
	steal: "选择对手的资源",
	optionalSteal: "选择对手的资源，或停止拿取",
	depositSteal: "选择存放拿取资源的地区",
	brigandsRegion: "选择一个有空位的地区",
	brigandsTake: "拿取相同种类的资源",
	tradeType: "选择支付的资源",
	tradeGain: "选择获得的资源",
	removePick: "选择移除的扩展牌",
	returnStack: "选择匹配的牌堆",
	scout: "是否使用侦察兵？",
	regionPick: "选择新村庄的两个地区",
	searchStack: "选择搜牌的牌堆",
	searchCard: "选择一张卡牌",
	exchangeMode: "选择随机抽牌或付费搜牌",
	eventDefense: "是否使用塞巴斯蒂安？",
	traitorPick: "选择拿取对手一张手牌，或跳过",
	discardPick: "从弃牌中选择一张",
	swapFirst: "选择迁移的地区或扩展牌",
	swapSecond: "选择交换的另一张牌",
	doctor: "选择一座浴场",
	tithe: "选择谷物或羊毛",
	market: "选择对手本次产出的资源",
	travel: "选择支付的黄金数量",
	riots: "支付黄金或退回一个单位",
	feudSelect: "指定对手的建筑",
	fraternal: "选择退回的对手手牌",
	give: "返还一个资源",
	givePick: "选择返还的资源",
	giveDeposit: "选择存放收到资源的地区",
	caravan: "选择支付的两个资源",
	searchPay: "支付搜牌费用",
	library: "选择免费搜牌的牌堆",
	pirate: "选择弃掉一艘商船",
	attack: "选择受影响的牌",
	feud: "世仇",
	defenseRoll: "掷骰防御",
	brigand: "强盗来袭",
	celebration: "庆典",
	harvest: "丰收",
	event: "事件牌",
	invention: "发明",
	plenty: "丰饶之年",
	yule: "圣诞节",
	race: "商船竞赛",
	gift: "献给王侯的礼物",
	plague: "瘟疫",
	gainLog: "获得资源",
	produce: "生产",
	defended: "抵御影响",
	newRegion: "新地区",
	stealCard: "拿取手牌",
	optional: "可选",
	cost: "费用",
	requires: "条件",
	unique: "每人最多一张",
	normalExpansion: "村庄／城市扩展",
	cityExpansion: "城市扩展",
	regionExpansion: "地区扩展",
	action: "行动",
	hero: "英雄",
	ship: "商船",
	unit: "单位",
	building: "建筑",
	winner: "{name} 获胜",
	finalTitle: "王侯的领地",
	finalScore: "最终胜利点",
	townScore: "村庄与城市",
	expansionScore: "扩展牌",
	advantageScore: "优势标记",
	targetScore: "目标",
	review: "回看领地",
	backToResult: "返回结算",
	playAgain: "再来一局",
	backToLobby: "返回大厅",
	hostWaiting: "等待主机开始下一局",
	log: "对局记录",
	errAction: "当前无法执行该操作，请重新选择。"
}, ut = {
	name: "Rivals for Catan",
	desc: "Build two rival principalities, compete for strength and trade, and explore three eras and the Duel of the Princes.",
	roundLabel: "Turn {{n}}",
	tradeEvent: "Trade event",
	demand: "Choose how many resources to demand",
	surrender: "Choose the region to give resources from",
	roadText: "Extend the edge of your principality to build another settlement.",
	settlementText: "Worth 1 victory point. One expansion site above and below. Receive two new regions when built.",
	cityText: "Upgrade a settlement. Worth 2 victory points in total, with two expansion sites above and below.",
	feudText: "The strength advantage holder nominates up to three opposing buildings. Their opponent returns one to a matching draw stack.",
	fraternalText: "The strength advantage holder inspects their opponent’s hand and returns two cards to matching draw stacks.",
	inventionText: "Each building with a progress point grants any 1 resource, up to 2 resources per player.",
	raceText: "The player with the most trade ships receives any 1 resource. On a tie both receive 1; each must have at least one ship.",
	travelText: "Each player may pay up to 2 gold and receive any 1 resource per gold paid.",
	plentyText: "Each region receives 1 resource per neighboring Storehouse and Abbey.",
	yuleText: "Rebuild the event stack as at the start of the game, then draw another event card.",
	giftText: "Receive 1 gold for each of your units that has strength points.",
	riotsText: "Pay 1 gold with one or two units with strength or commerce; pay 2 with three or more, or return one such unit. Chapel and Sebastian may protect you.",
	plagueText: "Each region bordering a city loses 1 resource, once per region. Bath Houses protect their city’s neighbors; each Pharmacy grants any 1 resource.",
	rules: "Goal:\nEarn victory points from settlements, cities, expansions and the strength and trade advantages. In the Introductory Game, win with 7 points at the end of your turn. In a Theme Game, win with 12 points at any time on your turn; in the Duel of the Princes, the target is 13. Each advantage is worth 1 point. Claim it with at least 3 points and more than your opponent; its holder retains it on a tie.\n\nPreparation:\nEach player starts with 2 settlements, a road and six different regions. Each region stores 0–3 resources; start with 1 of each except gold, which starts at 0. The Introductory Game has four Basic draw stacks of 9 cards; each player takes the top 3 cards from a different stack. Theme Games and the Duel have three Basic stacks. Choose 3 cards from one Basic stack and optionally rearrange your starting regions. A Theme Game includes all cards of that era. The Duel includes all three eras, removes half-moon hand cards, and uses the six event cards without half moons plus six randomly chosen half-moon events.\n\nTurn sequence:\nBefore rolling, you may play a card that sets a die. Roll the production and event dice. Resolve Brigand Attack before production: if your counted resources exceed 7, lose all wool and gold in your regions. Storehouses exclude neighboring regions from the count but do not protect the resources from being stolen. Gold Caches are neither counted nor stolen. Otherwise resolve production before the event. Each region matching the production die gains 1 resource; matching adjacent production boosters double normal production. Excess is lost.\n· Trade: the trade advantage holder takes 1 resource, or up to 2 with Moneylender.\n· Celebration: the player with more skill receives any 1 resource; on a tie both do.\n· Plentiful Harvest: both receive any 1 resource, plus 2 gold per Toll Bridge and 1 gold per Pirate Ship.\nResolve event cards in order. When Yule is drawn, reshuffle the event deck, place Yule above the bottom 3 cards and draw again.\n\nActions:\nBuild, trade and play legal action cards in any order and as often as desired. In Theme Games and the Duel, buildings and units may be removed for free. A settlement has one expansion site above and below it; a city has two above and below. Red city expansions require a city. Extend outward along a road to build a settlement, which receives two new regions with no resources. Roads cost 2 brick and 1 lumber; settlements cost 1 each of brick, grain, wool and lumber; cities cost 3 ore and 2 grain. Card costs, requirements and symbols also apply. Choose the resource saved by a discount.\nNormally trade 3 of one resource for any 1 other resource. The matching trade ship allows 2:1. A Large Trade Ship uses 2 resources from one neighboring region on either side. Each Mint can trade 1 gold for 1 other resource once on each of your turns. Players choose the exact regions used to pay, store or take resources.\n\nReplenish and exchange:\nAfter actions, replenish to 3 cards plus progress points. Return excess cards to the bottom of a matching draw stack; otherwise draw one at a time from chosen stacks. You may then exchange 1 hand card: a random replacement is free, while searching costs any 2 resources, reduced to 1 with Parish Hall or 0 with Town Hall. Searches and starting choices never rearrange a stack. Empty stack positions remain available for returning matching cards. End your turn afterwards.\n\nThemes and events:\nGold develops ships, pirates and trade; Turmoil adds attacks, defenses and Riots; Progress develops universities, libraries, baths and progress actions. A single Theme Game has a face-up supply of Merchant Guilds, Hedge Taverns or Universities; these never enter your hand. In the Duel, their non-half-moon copies enter the draw stacks. Unique buildings are limited to one per player. Heroes cannot be duplicated; Chief Cannoneer is not a hero.\nFor Fraternal Feuds, the strength advantage holder inspects the opponent’s hand and returns 2 cards. For Feud, that player nominates up to 3 opposing buildings; the opponent returns one. Riots costs 1 or 2 gold according to the number of units with strength or commerce, or one such unit must be returned. A matching Chapel or Sebastian may protect you. Plague removes 1 resource from each region bordering a city, at most once per region. Bath Houses protect neighboring regions; each Pharmacy still grants any 1 resource. See card details and the official rulebook for further exceptions.",
	intro: "Introductory Game",
	gold: "Era of Gold",
	turmoil: "Era of Turmoil",
	progress: "Era of Progress",
	duel: "Duel of the Princes",
	mode: "Game mode",
	wood: "Lumber",
	brick: "Brick",
	wool: "Wool",
	grain: "Grain",
	ore: "Ore",
	goldResource: "Gold",
	strength: "Strength",
	skill: "Skill",
	commerce: "Commerce",
	progressPoint: "Progress",
	vp: "Victory points",
	road: "Road",
	settlement: "Settlement",
	city: "City",
	regions: "Regions",
	events: "Events",
	basic: "Basic",
	supply: "Supply",
	discard: "Discard",
	hand: "Hand",
	start: "Prepare your principality",
	preRoll: "Before rolling",
	main: "Action phase",
	refill: "Replenish your hand",
	exchange: "Optionally exchange one hand card",
	resolve: "Resolving",
	done: "Game over",
	roll: "Roll dice",
	end: "End actions",
	finish: "End turn",
	continue: "Continue",
	cancel: "Cancel",
	skip: "Skip",
	ready: "Finish arrangement",
	trade: "Trade",
	demolish: "Remove an expansion",
	mint: "Use Mint",
	accept: "Do not defend",
	defend: "Roll to defend",
	payGold: "Pay gold",
	pay: "Pay resources",
	random: "Draw randomly",
	search: "Search for a card",
	buy: "Exchange resources",
	build: "Build",
	play: "Play",
	keep: "Take",
	remove: "Remove",
	select: "Select",
	return: "Return",
	exchangeCard: "Exchange",
	detail: "View details",
	close: "Close",
	waiting: "Waiting for {name}",
	yourTurn: "Your turn",
	target: "Legal site",
	view: "View principality",
	self: "Your principality",
	opponent: "Opponent’s principality",
	fit: "Fit view",
	zoomIn: "Zoom in",
	zoomOut: "Zoom out",
	startStack: "Choose a starting draw stack",
	startCards: "Choose three starting cards",
	arrange: "Select regions to swap, or finish",
	arrangeSecond: "Choose the other region to swap",
	chooseDie: "Choose the production die result",
	site: "Choose a building site",
	discount: "Choose the discounted resource",
	payment: "Choose regions to pay from",
	gain: "Choose a region to store a resource",
	optionalGain: "Store a resource, or skip",
	steal: "Choose an opposing resource",
	optionalSteal: "Take an opposing resource, or stop",
	depositSteal: "Choose where to store the resource",
	brigandsRegion: "Choose one region with storage space",
	brigandsTake: "Take resources of the same type",
	tradeType: "Choose the resource to pay",
	tradeGain: "Choose the resource to receive",
	removePick: "Choose an expansion to remove",
	returnStack: "Choose a matching draw stack",
	scout: "Play a Scout?",
	regionPick: "Choose two new regions",
	searchStack: "Choose a stack to search",
	searchCard: "Choose one card",
	exchangeMode: "Draw randomly or pay to search",
	eventDefense: "Play Sebastian?",
	traitorPick: "Take one opposing hand card, or skip",
	discardPick: "Choose one discarded card",
	swapFirst: "Choose a region or expansion to relocate",
	swapSecond: "Choose the other card to swap",
	doctor: "Choose one Bath House",
	tithe: "Choose grain or wool",
	market: "Choose a resource produced by your opponent",
	travel: "Choose how much gold to pay",
	riots: "Pay gold or return a unit",
	feudSelect: "Nominate opposing buildings",
	fraternal: "Choose opposing hand cards to return",
	give: "Return one resource",
	givePick: "Choose the resource to return",
	giveDeposit: "Choose where to store the received resource",
	caravan: "Choose two resources to pay",
	searchPay: "Pay the search cost",
	library: "Choose a stack to search for free",
	pirate: "Choose a trade ship to discard",
	attack: "Choose the affected card",
	feud: "Feud",
	defenseRoll: "Roll to defend",
	brigand: "Brigand Attack",
	celebration: "Celebration",
	harvest: "Plentiful Harvest",
	event: "Event card",
	invention: "Invention",
	plenty: "Year of Plenty",
	yule: "Yule",
	race: "Trade Ships Race",
	gift: "Gift for the Prince",
	plague: "Plague",
	gainLog: "Received resources",
	produce: "Production",
	defended: "Protected",
	newRegion: "New region",
	stealCard: "Take a hand card",
	optional: "Optional",
	cost: "Cost",
	requires: "Requirements",
	unique: "One per player",
	normalExpansion: "Settlement / city expansion",
	cityExpansion: "City expansion",
	regionExpansion: "Region expansion",
	action: "Action",
	hero: "Hero",
	ship: "Trade ship",
	unit: "Unit",
	building: "Building",
	winner: "{name} wins",
	finalTitle: "The princely domains",
	finalScore: "Final victory points",
	townScore: "Settlements and cities",
	expansionScore: "Expansions",
	advantageScore: "Advantages",
	targetScore: "Target",
	review: "Review principalities",
	backToResult: "Back to results",
	playAgain: "Play again",
	backToLobby: "Back to lobby",
	hostWaiting: "Waiting for the host to start another game",
	log: "Game log",
	errAction: "That action is unavailable. Please choose again."
}, G = (e, t) => (e === "zh" ? lt : ut)[t] ?? t, K = (e, t) => G(e, t === "gold" ? "goldResource" : t), dt = (e, t) => Object.hasOwn(e === "zh" ? lt : ut, t), q = () => f((e) => e.locale), ft = {
	wood: "#5d7b35",
	brick: "#b9693d",
	wool: "#b8cb76",
	grain: "#d9b653",
	ore: "#858797",
	gold: "#dfbc4d",
	strength: "#ad7754",
	skill: "#bb8b4f",
	commerce: "#ad7754",
	progress: "#6485a4",
	vp: "#b42d2d",
	hand: "#7a8170"
};
function pt(e) {
	switch (e) {
		case "wood": return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M5 17 15 7l7 5-10 11Z",
				fill: "#92704a"
			}),
			/* @__PURE__ */ m("path", { d: "m14 8-7 7m9-5-7 7" }),
			/* @__PURE__ */ m("ellipse", {
				cx: "18",
				cy: "9",
				rx: "4",
				ry: "3",
				transform: "rotate(35 18 9)",
				fill: "#c4a476"
			})
		] });
		case "brick": return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
			d: "m3 14 14-6 8 5-14 7Z",
			fill: "#cb8053"
		}), /* @__PURE__ */ m("path", { d: "M3 14v7l8 5 14-7v-6M11 20v6" })] });
		case "wool": return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
			d: "M6 20c-7-7 0-13 4-12 3-7 10-4 11 0 7 0 8 10 3 13-2 6-11 7-13 3-4 1-6-1-5-4Z",
			fill: "#e9e8cd"
		}), /* @__PURE__ */ m("path", { d: "M9 13c8-6 12 2 7 6m-4-8c4 2 4 7 0 9" })] });
		case "grain": return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M14 28V4m0 9L7 7m7 13-8-6m8 0 7-7m-7 13 8-6" }), /* @__PURE__ */ m("path", {
			d: "m7 7 1 6 5 2m8-8-1 6-5 2M6 14l2 6 5 2m9-8-2 6-5 2",
			stroke: "#f4df83",
			strokeWidth: "3"
		})] });
		case "ore": return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
			d: "m3 23 5-15 13-4 7 18-10 6Z",
			fill: "#9a9ca4"
		}), /* @__PURE__ */ m("path", { d: "m8 8 7 6 6-10m-6 10 3 14m-3-14L3 23m12-9 13 8" })] });
		case "gold": return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("circle", {
				cx: "15",
				cy: "16",
				r: "11",
				fill: "#e9c95c"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "15",
				cy: "16",
				r: "7"
			}),
			/* @__PURE__ */ m("path", { d: "m11 16 4-5 4 5-4 5Z" })
		] });
		case "strength": return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "m9 27 11-22",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ m("path", {
				d: "m15 8 7-5 6 7-3 8-8-6Z",
				fill: "#d2c4a1"
			}),
			/* @__PURE__ */ m("path", { d: "m19 11 6 2" })
		] });
		case "skill": return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
			d: "M6 5c9-4 17 1 18 1l-6 19H8Z",
			fill: "#d9b86a"
		}), /* @__PURE__ */ m("path", { d: "M9 8v14m4-14v14m4-13v13m4-13-3 13" })] });
		case "commerce": return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M16 5v21M6 11h20M10 11 5 21h10Zm13 0-5 10h10ZM9 27h14" }), /* @__PURE__ */ m("circle", {
			cx: "16",
			cy: "7",
			r: "2",
			fill: "#e1ca94"
		})] });
		case "progress": return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
			d: "M3 7c7-3 10-1 13 1 3-2 6-4 13-1v19c-7-2-10-1-13 1-3-2-6-3-13-1Z",
			fill: "#e8e1ba"
		}), /* @__PURE__ */ m("path", { d: "M16 8v19M6 11l7 1m-7 4 7 1m7-5 6-1m-6 6 6-1" })] });
		case "vp": return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
			d: "M8 28V3h17l-4 6 4 6H9",
			fill: "#d04a36"
		}), /* @__PURE__ */ m("path", {
			d: "m16 5 1 3 3 1-3 1-1 3-1-3-3-1 3-1Z",
			fill: "#f5de85",
			stroke: "none"
		})] });
		case "hand": return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
			d: "m3 9 16-5 7 21-16 5Z",
			fill: "#eae4c8"
		}), /* @__PURE__ */ m("path", { d: "m7 9 16 16M9 7l14 15" })] });
	}
}
function J({ kind: e, size: t = 22 }) {
	let n = q(), r = e === "progress" ? G(n, "progressPoint") : K(n, e);
	return ["vp", "hand"].includes(e) ? /* @__PURE__ */ h("svg", {
		width: t,
		height: t,
		viewBox: "0 0 32 32",
		role: "img",
		"aria-label": r,
		className: "rv-symbol",
		children: [/* @__PURE__ */ m("circle", {
			cx: "16",
			cy: "16",
			r: "15",
			fill: ft[e],
			stroke: "#64533c"
		}), /* @__PURE__ */ m("g", {
			fill: "none",
			stroke: "#3f382b",
			strokeWidth: "1.3",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: pt(e)
		})]
	}) : /* @__PURE__ */ m("svg", {
		width: t,
		height: t,
		viewBox: "0 0 32 32",
		role: "img",
		"aria-label": r,
		className: "rv-symbol",
		children: /* @__PURE__ */ m("image", {
			href: d(`games/rivals/icon-${e}.svg`),
			width: "32",
			height: "32"
		})
	});
}
function mt({ n: e }) {
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 32 32",
		className: "rv-die",
		role: "img",
		"aria-label": String(e),
		children: [/* @__PURE__ */ m("rect", {
			x: "1",
			y: "1",
			width: "30",
			height: "30",
			rx: "5",
			fill: "#fff9e9",
			stroke: "#6d6658",
			strokeWidth: "2"
		}), ({
			0: [],
			1: [[16, 16]],
			2: [[9, 9], [23, 23]],
			3: [
				[9, 9],
				[16, 16],
				[23, 23]
			],
			4: [
				[9, 9],
				[23, 9],
				[9, 23],
				[23, 23]
			],
			5: [
				[9, 9],
				[23, 9],
				[16, 16],
				[9, 23],
				[23, 23]
			],
			6: [
				[9, 8],
				[23, 8],
				[9, 16],
				[23, 16],
				[9, 24],
				[23, 24]
			]
		}[e] ?? []).map(([e, t], n) => /* @__PURE__ */ m("circle", {
			cx: e,
			cy: t,
			r: "2.4",
			fill: "#272b24"
		}, n))]
	});
}
//#endregion
//#region src/games/rivals/card.tsx
function Y(e, t) {
	let n = E(e);
	return n ? t === "zh" ? n.zh : n.en : G(t, k[e]?.key ?? e);
}
function ht(e) {
	let t = E(e)?.key ?? k[e]?.key ?? e;
	return t.endsWith("Ship") && t !== "largeShip" ? "tradeShip" : t.startsWith("chapel") ? "chapel" : t === "gift" ? "candamir" : t;
}
function gt({ cost: e }) {
	return /* @__PURE__ */ m("span", {
		className: "rv-cost",
		children: Object.entries(e).filter(([, e]) => e > 0).map(([e, t]) => /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(J, { kind: e }), /* @__PURE__ */ m("b", { children: t })] }, e))
	});
}
function _t({ set: e = "basic" }) {
	let t = q();
	return /* @__PURE__ */ h("div", {
		className: "rv-back",
		"data-set": e,
		children: [/* @__PURE__ */ h("svg", {
			viewBox: "0 0 100 100",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ m("path", { d: "M10 10h80v80H10Zm6 6h68v68H16ZM5 50l45-45 45 45-45 45Z" }), /* @__PURE__ */ m("path", { d: "M25 50c-25-25 50-25 50 0S0 75 25 50s25-50 25-25 25 50 25 25-25 50-25 25-25-50-25-25Z" })]
		}), /* @__PURE__ */ m("span", { children: G(t, e) })]
	});
}
function X({ id: e, target: t = !1, selected: n = !1, anchor: r, onClick: i, onDetail: a, full: s = !1 }) {
	let l = q(), f = E(e), p = k[e], g = Y(e, l), _ = f?.cost ?? ae[e] ?? {}, v = p ? "event" : f?.type === "action" ? "action" : f?.city ? "cityExpansion" : f?.type === "region" ? "regionExpansion" : "normalExpansion", { ref: y, hidden: b } = o(r ?? null);
	return /* @__PURE__ */ h("div", {
		ref: y,
		className: `rv-card${s ? " rv-full-card" : ""}${n ? " rv-selected" : ""}`,
		"data-type": v,
		style: { visibility: b ? "hidden" : void 0 },
		children: [
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "rv-card-face",
				onClick: i,
				disabled: !i,
				"aria-label": g,
				"aria-pressed": i ? n : void 0,
				children: [
					/* @__PURE__ */ h("strong", {
						className: "rv-card-name",
						children: [g, f?.unique && /* @__PURE__ */ m("small", { children: " 1×" })]
					}),
					/* @__PURE__ */ h("div", {
						className: "rv-card-picture",
						children: [
							/* @__PURE__ */ m("img", {
								src: d(`games/rivals/${ht(e)}.svg`),
								alt: "",
								draggable: !1
							}),
							/* @__PURE__ */ m(gt, { cost: _ }),
							re[e]?.moon && /* @__PURE__ */ m("span", {
								className: "rv-moon",
								"aria-hidden": "true",
								children: "◐"
							})
						]
					}),
					/* @__PURE__ */ h("div", {
						className: "rv-card-symbols",
						children: [
							f && [
								"strength",
								"skill",
								"commerce",
								"progress",
								"vp"
							].filter((e) => f[e]).map((e) => /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(J, { kind: e }), /* @__PURE__ */ m("b", { children: f[e] })] }, e)),
							!f && ["settlement", "city"].includes(e) && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(J, { kind: "vp" }), e === "city" ? 2 : 1] }),
							f?.resource && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(J, { kind: f.resource }), f.type === "ship" ? "2:1" : "×2"] }),
							f?.city && /* @__PURE__ */ m("span", {
								className: "rv-city-mark",
								"aria-label": G(l, "cityExpansion"),
								children: "▰"
							})
						]
					}),
					s && /* @__PURE__ */ m("span", {
						className: "rv-card-text",
						children: f ? l === "zh" ? f.textZh : f.textEn : G(l, `${p?.key ?? e}Text`)
					})
				]
			}),
			a && /* @__PURE__ */ m("button", {
				type: "button",
				className: "rv-card-detail",
				onClick: a,
				"aria-label": `${G(l, "detail")} · ${g}`,
				children: /* @__PURE__ */ m(c, { size: 16 })
			}),
			t && /* @__PURE__ */ m(u, {
				radius: 3,
				flash: !1
			})
		]
	});
}
//#endregion
//#region src/games/rivals/realm.tsx
var vt = 154, yt = 148;
function bt({ region: e, target: t, selected: n, reserved: r = 0, onClick: i, anchor: a = !0 }) {
	let s = q(), { ref: c, hidden: l } = o(a ? `region:${e.id}` : null);
	return /* @__PURE__ */ h("div", {
		ref: c,
		className: `rv-region${n ? " rv-selected" : ""}`,
		style: { visibility: l ? "hidden" : void 0 },
		children: [/* @__PURE__ */ h("button", {
			type: "button",
			disabled: !i,
			onClick: i,
			className: "rv-region-face",
			"aria-label": `${K(s, e.resource)} ${e.number} · ${e.amount}/3`,
			children: [
				/* @__PURE__ */ m("img", {
					src: d(`games/rivals/${e.resource}.svg`),
					alt: "",
					draggable: !1
				}),
				/* @__PURE__ */ m("strong", { children: K(s, e.resource) }),
				e.number > 0 && /* @__PURE__ */ m(mt, { n: e.number }),
				/* @__PURE__ */ h("span", {
					className: "rv-stock",
					children: [
						/* @__PURE__ */ m(J, { kind: e.resource }),
						[
							1,
							2,
							3
						].map((t) => /* @__PURE__ */ m("i", { "data-filled": t <= e.amount - r }, t)),
						/* @__PURE__ */ m("b", { children: e.amount - r }),
						r > 0 && /* @__PURE__ */ h("small", { children: ["−", r] })
					]
				})
			]
		}), t && /* @__PURE__ */ m(u, {
			radius: 3,
			flash: !1
		})]
	});
}
function xt({ anchor: e, x: t, y: n, children: r, onActivate: i, label: a }) {
	let { ref: s, hidden: c } = o(e);
	return /* @__PURE__ */ m("foreignObject", {
		x: t,
		y: n,
		width: yt,
		height: yt,
		children: /* @__PURE__ */ m("div", {
			ref: s,
			className: "rv-world-cell",
			style: { visibility: c ? "hidden" : void 0 },
			role: i ? "button" : void 0,
			tabIndex: i ? 0 : void 0,
			"aria-label": a,
			onKeyDown: (e) => {
				i && ["Enter", " "].includes(e.key) && (e.preventDefault(), i());
			},
			children: r
		})
	});
}
function St({ player: e, options: t, selected: n, reserved: r = [], onPick: i, onDetail: a, fitKey: o = "" }) {
	let s = q(), c = e, l = t.filter((e) => e.kind === "slot" && e.owner === c.rid), d = t.filter((e) => e.owner === c.rid), f = [
		...c.regions,
		...c.expansions,
		...c.towns.flatMap((e) => [{
			...e,
			y: e.city ? -2 : -1
		}, {
			...e,
			y: e.city ? 2 : 1
		}]),
		...c.roads.map((e) => ({
			x: e,
			y: 0
		})),
		...l.map((e) => ({
			x: e.x,
			y: e.y
		}))
	], _ = Math.min(...f.map((e) => e.x)), v = Math.max(...f.map((e) => e.x)), y = Math.min(-1, ...f.map((e) => e.y)), b = Math.max(1, ...f.map((e) => e.y)), x = (e) => (e - _) * vt + 7, S = (e) => (e - y) * vt + 7, C = [
		...c.regions.map((e) => ({
			key: `r:${e.id}`,
			x: e.x,
			y: e.y
		})),
		...c.expansions.map((e) => ({
			key: `e:${e.card}`,
			x: e.x,
			y: e.y
		})),
		...c.towns.map((e) => ({
			key: `t:${e.x}`,
			x: e.x,
			y: 0
		})),
		...l.map((e) => ({
			key: `s:${e.id}`,
			x: e.x,
			y: e.y
		}))
	].map((e) => ({
		key: e.key,
		rect: {
			x: x(e.x),
			y: S(e.y),
			w: yt,
			h: yt
		}
	}));
	function ee(e) {
		if (e.startsWith("s:")) {
			let t = l.find((t) => t.id === e.slice(2));
			t && i(t);
			return;
		}
		if (e.startsWith("r:")) {
			let t = d.find((t) => t.kind === "region" && t.ref === e.slice(2));
			t && i(t);
			return;
		}
		let t = e.startsWith("e:") ? e.slice(2) : c.towns.find((t) => t.x === Number(e.slice(2)))?.city ? "city" : "settlement", n = c.expansions.find((e) => e.card === t), r = l.find((t) => t.x === (n?.x ?? Number(e.slice(2))) && t.y === (n?.y ?? 0)), o = d.find((e) => e.kind === "card" && e.ref === t);
		r ? i(r) : o ? i(o) : a(t);
	}
	return /* @__PURE__ */ m("div", {
		className: "rv-realm-canvas",
		children: /* @__PURE__ */ h(g, {
			sheetW: (v - _ + 1) * vt + 8,
			sheetH: (b - y + 1) * vt + 8,
			fitKey: `${c.rid}:${_}:${v}:${y}:${b}:${o}`,
			eligible: C,
			onTapEligible: ee,
			highlight: "off",
			clampToSheet: !0,
			children: [
				c.regions.map((e) => /* @__PURE__ */ m(xt, {
					anchor: `rslot:${c.rid}:${e.x}:${e.y}`,
					x: x(e.x),
					y: S(e.y),
					onActivate: d.some((t) => t.kind === "region" && t.ref === e.id) ? () => ee(`r:${e.id}`) : void 0,
					label: `${K(s, e.resource)} ${e.number} · ${e.amount}/3`,
					children: /* @__PURE__ */ m(bt, {
						region: e,
						target: d.some((t) => t.kind === "region" && t.ref === e.id),
						selected: n.some((t) => t === e.id || t === `r:${e.id}`),
						reserved: r.filter((t) => t === e.id).length
					})
				}, e.id)),
				c.roads.map((e) => /* @__PURE__ */ m(xt, {
					anchor: `center:${c.rid}:${e}`,
					x: x(e),
					y: S(0),
					children: /* @__PURE__ */ m(X, { id: "road" })
				}, `road:${e}`)),
				c.towns.map((e) => /* @__PURE__ */ m(xt, {
					anchor: `center:${c.rid}:${e.x}`,
					x: x(e.x),
					y: S(0),
					onActivate: () => ee(`t:${e.x}`),
					label: G(s, e.city ? "city" : "settlement"),
					children: /* @__PURE__ */ m(X, {
						id: e.city ? "city" : "settlement",
						target: l.some((t) => t.x === e.x && t.y === 0)
					})
				}, `town:${e.x}`)),
				c.towns.flatMap((e) => [
					-1,
					1,
					...e.city ? [-2, 2] : []
				].map((t) => ({
					x: e.x,
					y: t
				}))).map((e) => {
					let t = c.expansions.find((t) => t.x === e.x && t.y === e.y), n = l.find((t) => t.x === e.x && t.y === e.y), r = t && d.some((e) => e.kind === "card" && e.ref === t.card);
					return /* @__PURE__ */ m(xt, {
						anchor: `slot:${c.rid}:${e.x}:${e.y}`,
						x: x(e.x),
						y: S(e.y),
						onActivate: t ? () => ee(`e:${t.card}`) : n ? () => i(n) : void 0,
						label: t ? Y(t.card, s) : n ? Y(n.card, s) : void 0,
						children: t ? /* @__PURE__ */ m(X, {
							id: t.card,
							anchor: `exp:${t.card}`,
							target: !!r || !!n
						}) : /* @__PURE__ */ m("div", {
							className: "rv-empty-site",
							children: n ? /* @__PURE__ */ h(p, { children: [
								/* @__PURE__ */ m(J, { kind: "vp" }),
								/* @__PURE__ */ m("span", { children: n.card ? Y(n.card, s) : G(s, "target") }),
								/* @__PURE__ */ m(u, {
									radius: 3,
									flash: !1
								})
							] }) : /* @__PURE__ */ m("span", { children: "◇" })
						})
					}, `${e.x},${e.y}`);
				}),
				l.filter((e) => !c.towns.some((t) => t.x === e.x && e.y === 0) && !c.towns.some((t) => t.x === e.x && e.y !== 0 && Math.abs(e.y) <= (t.city ? 2 : 1))).map((e) => /* @__PURE__ */ m(xt, {
					anchor: `slot:${c.rid}:${e.x}:${e.y}`,
					x: x(e.x),
					y: S(e.y),
					onActivate: () => i(e),
					label: Y(e.card, s),
					children: /* @__PURE__ */ h("div", {
						className: "rv-empty-site",
						children: [/* @__PURE__ */ m("span", { children: Y(e.card, s) }), /* @__PURE__ */ m(u, {
							radius: 3,
							flash: !1
						})]
					})
				}, `legal:${e.id}`))
			]
		})
	});
}
//#endregion
//#region src/games/rivals/view-player.tsx
function Z({ name: e, className: t = "", children: n }) {
	let { ref: r, hidden: i } = o(e);
	return /* @__PURE__ */ m("div", {
		ref: r,
		className: t,
		style: { visibility: i ? "hidden" : void 0 },
		children: n
	});
}
function Ct({ public: e, private: t, members: r, myRid: o, send: c }) {
	let d = e, f = t ? ge.parse(t) : {
		hand: [],
		options: [],
		selected: [],
		reserved: [],
		remaining: {},
		preview: null
	}, g = q(), [_, v] = a({
		rid: o,
		key: ""
	}), [y, b] = a(null), [S, C] = a(null), [ee, te] = a(!1), [ne, w] = a(0), T = i(null), E = d.phase === "done" ? [] : f.options, D = (e) => r.find((t) => t.rid === e)?.name ?? e, O = [...d.players].sort((e, t) => Number(t.rid === o) - Number(e.rid === o)), k = `${o}:${d.phase}:${d.prompt}:${f.preview}:${d.actor}`, ie = E.find((e) => e.kind === "region" && e.owner), ae = _.key === k ? _.rid : ie?.owner ?? o, oe = d.players.some((e) => e.rid === ae) ? ae : O[0].rid, A = (e) => {
		C(null), c({
			type: "pick",
			id: e.id
		});
	}, j = (e) => E.find((t) => t.kind === "card" && t.ref === e), se = /* @__PURE__ */ new Set([
		...f.hand,
		...d.faceup,
		...d.players.flatMap((e) => e.expansions.map((e) => e.card)),
		"road",
		"settlement",
		"city"
	]), ce = E.filter((e) => e.kind === "card" && !se.has(e.ref)), le = E.filter((e) => e.kind === "region" && e.tag === "newRegion"), ue = E.filter((e) => e.kind === "resource"), de = E.filter((e) => e.kind === "die"), fe = E.filter((e) => e.kind === "button"), pe = dt(g, d.prompt) ? G(g, d.prompt) : G(g, "resolve"), me = d.actor === o && E.length > 0, he = S === null ? [] : E.filter((e) => e.kind === "stack" && Number(e.ref) === S);
	n(() => {
		y === null ? T.current?.close() : T.current?.showModal();
	}, [y]);
	function M(e) {
		let t = E.filter((t) => t.kind === "stack" && Number(t.ref) === e);
		t.length === 1 ? A(t[0]) : t.length && C(e);
	}
	function N(e) {
		return ["buy", "demand"].includes(e.ref) ? `${G(g, e.ref)} ${e.n}` : G(g, e.id === "trade" ? "trade" : e.id);
	}
	let P = O.map((e) => /* @__PURE__ */ h("section", {
		className: "rv-domain",
		"data-visible": e.rid === oe,
		"aria-label": D(e.rid),
		children: [/* @__PURE__ */ h(Z, {
			name: `seat:${e.rid}`,
			className: "rv-domain-header",
			children: [
				/* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => v({
						rid: e.rid,
						key: k
					}),
					"aria-pressed": oe === e.rid,
					children: [/* @__PURE__ */ m("b", { children: D(e.rid) }), d.actor === e.rid && d.phase !== "done" && /* @__PURE__ */ m("span", { className: "rv-actor-dot" })]
				}),
				/* @__PURE__ */ h("span", {
					className: "rv-score",
					children: [
						/* @__PURE__ */ m(J, { kind: "vp" }),
						e.stats.vp,
						/* @__PURE__ */ h("small", { children: ["/", d.goal] })
					]
				}),
				/* @__PURE__ */ h("div", {
					className: "rv-statline",
					children: [[
						"strength",
						"commerce",
						"skill",
						"progress"
					].map((t) => /* @__PURE__ */ h("span", {
						"data-advantage": t === "strength" ? d.strengthOwner === e.rid : t === "commerce" && d.tradeOwner === e.rid,
						children: [/* @__PURE__ */ m(J, { kind: t }), e.stats[t]]
					}, t)), /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(J, { kind: "hand" }), e.handCount] })]
				})
			]
		}), /* @__PURE__ */ m(St, {
			player: e,
			options: E,
			selected: f.selected,
			reserved: f.reserved,
			onPick: A,
			onDetail: b,
			fitKey: String(ne)
		})]
	}, e.rid));
	return /* @__PURE__ */ h("div", {
		className: "rv-root",
		children: [
			/* @__PURE__ */ m(l, {
				adaptive: !0,
				scroll: !1,
				className: "rv-screen",
				actionsHeight: "rv-actions-height",
				banner: /* @__PURE__ */ h("header", {
					className: "rv-top",
					children: [
						/* @__PURE__ */ h("div", {
							className: "rv-title",
							children: [/* @__PURE__ */ h("strong", { children: [
								"RIVALS ",
								/* @__PURE__ */ m("small", { children: "FOR" }),
								" CATAN"
							] }), /* @__PURE__ */ h("span", { children: [
								G(g, d.mode),
								" · ",
								G(g, "roundLabel").replace("{{n}}", String(d.round))
							] })]
						}),
						/* @__PURE__ */ h(Z, {
							name: "dice",
							className: "rv-dice-tray",
							children: [
								/* @__PURE__ */ m(mt, { n: d.dice.production }),
								/* @__PURE__ */ m("span", { children: G(g, d.dice.event === "trade" ? "tradeEvent" : d.dice.event || "preRoll") }),
								d.dice.defense > 0 && /* @__PURE__ */ m(mt, { n: d.dice.defense })
							]
						}),
						/* @__PURE__ */ m("button", {
							type: "button",
							className: "rv-tool",
							onClick: () => w(ne + 1),
							children: G(g, "fit")
						}),
						/* @__PURE__ */ m("button", {
							type: "button",
							className: "rv-tool",
							onClick: () => te(!0),
							children: G(g, "log")
						})
					]
				}),
				actions: /* @__PURE__ */ h("div", {
					className: "rv-actions",
					children: [/* @__PURE__ */ h("div", {
						className: "rv-prompt",
						"aria-live": "polite",
						children: [/* @__PURE__ */ m("span", { children: me ? pe : d.phase === "done" ? G(g, "done") : E.length === 0 && d.actor === o ? pe : G(g, "waiting").replace("{name}", D(d.actor)) }), Object.values(f.remaining).some((e) => e > 0) && /* @__PURE__ */ m(gt, { cost: f.remaining })]
					}), /* @__PURE__ */ m("div", {
						className: "rv-action-buttons",
						children: fe.map((e) => /* @__PURE__ */ m("button", {
							type: "button",
							className: [
								"roll",
								"end",
								"finish",
								"ready",
								"continue"
							].includes(e.id) ? "rv-primary" : "",
							onClick: () => A(e),
							children: N(e)
						}, e.id))
					})]
				}),
				children: /* @__PURE__ */ h("main", {
					className: "rv-main",
					children: [
						/* @__PURE__ */ m("nav", {
							className: "rv-domain-tabs",
							"aria-label": G(g, "view"),
							children: O.map((e) => /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => v({
									rid: e.rid,
									key: k
								}),
								"aria-pressed": oe === e.rid,
								children: [
									D(e.rid),
									" ",
									/* @__PURE__ */ m(J, {
										kind: "vp",
										size: 16
									}),
									e.stats.vp
								]
							}, e.rid))
						}),
						/* @__PURE__ */ m("div", {
							className: "rv-realms",
							children: P
						}),
						/* @__PURE__ */ h("div", {
							className: "rv-bottom",
							children: [/* @__PURE__ */ h(Z, {
								name: "supply",
								className: "rv-supply",
								children: [/* @__PURE__ */ h("div", {
									className: "rv-supply-center",
									children: [
										[
											"road",
											"settlement",
											"city"
										].map((e) => /* @__PURE__ */ h("div", {
											className: "rv-supply-card",
											children: [/* @__PURE__ */ m(X, {
												id: e,
												anchor: `supplycard:${e}`,
												target: !!j(e),
												onClick: () => {
													let t = j(e);
													t ? A(t) : b(e);
												},
												onDetail: () => b(e)
											}), /* @__PURE__ */ m("span", { children: d.supply[e] })]
										}, e)),
										/* @__PURE__ */ m(Z, {
											name: "regions",
											className: "rv-stack-wrap",
											children: /* @__PURE__ */ h("div", {
												className: "rv-small-stack",
												children: [/* @__PURE__ */ m(_t, {}), /* @__PURE__ */ h("span", { children: [
													G(g, "regions"),
													" ",
													d.supply.regions
												] })]
											})
										}),
										/* @__PURE__ */ h(Z, {
											name: "event",
											className: "rv-stack-wrap",
											children: [/* @__PURE__ */ m("div", {
												className: "rv-event-card",
												children: d.event ? /* @__PURE__ */ m(X, {
													id: d.event,
													onClick: () => b(d.event)
												}) : /* @__PURE__ */ m(_t, { set: "events" })
											}), /* @__PURE__ */ h("span", { children: [
												G(g, "events"),
												" ",
												d.supply.events
											] })]
										}),
										/* @__PURE__ */ h(Z, {
											name: "discard",
											className: "rv-stack-wrap",
											children: [/* @__PURE__ */ m("div", {
												className: "rv-event-card",
												children: d.discardTop ? /* @__PURE__ */ m(X, {
													id: d.discardTop,
													onClick: () => b(d.discardTop)
												}) : /* @__PURE__ */ m(_t, { set: "discard" })
											}), /* @__PURE__ */ h("span", { children: [
												G(g, "discard"),
												" ",
												d.discardCount
											] })]
										})
									]
								}), /* @__PURE__ */ h("div", {
									className: "rv-draw-stacks",
									children: [d.stacks.map((e, t) => /* @__PURE__ */ m(Z, {
										name: `stack:${t}`,
										className: "rv-stack-wrap",
										children: /* @__PURE__ */ h("button", {
											type: "button",
											className: "rv-stack-button",
											onClick: () => M(t),
											disabled: !E.some((e) => e.kind === "stack" && Number(e.ref) === t),
											"aria-label": `${G(g, e.set)} ${t + 1} · ${e.count}`,
											children: [
												/* @__PURE__ */ m(_t, { set: e.set }),
												/* @__PURE__ */ m("span", { children: e.count }),
												E.some((e) => e.kind === "stack" && Number(e.ref) === t) && /* @__PURE__ */ m(u, {
													radius: 3,
													flash: !1
												})
											]
										})
									}, t)), d.faceup.map((e) => /* @__PURE__ */ m("div", {
										className: "rv-supply-card",
										children: /* @__PURE__ */ m(X, {
											id: e,
											anchor: `supplycard:${e}`,
											target: !!j(e),
											onClick: () => {
												let t = j(e);
												t ? A(t) : b(e);
											},
											onDetail: () => b(e)
										})
									}, e))]
								})]
							}), /* @__PURE__ */ h(Z, {
								name: `hand:${o}`,
								className: "rv-hand",
								children: [/* @__PURE__ */ h("div", {
									className: "rv-hand-label",
									children: [
										G(g, "hand"),
										/* @__PURE__ */ m("span", { children: f.hand.length }),
										f.preview && /* @__PURE__ */ m("span", { children: Y(f.preview, g) })
									]
								}), /* @__PURE__ */ m("div", {
									className: "rv-hand-cards",
									children: f.hand.map((e) => /* @__PURE__ */ m(X, {
										id: e,
										anchor: `handcard:${e}`,
										selected: f.selected.includes(e) || f.preview === e,
										target: !!j(e),
										onClick: () => {
											let t = j(e);
											t ? A(t) : b(e);
										},
										onDetail: () => b(e)
									}, e))
								})]
							})]
						}),
						(ce.length > 0 || le.length > 0 || ue.length > 0 || de.length > 0 || he.length > 0) && /* @__PURE__ */ h("section", {
							className: "rv-chooser",
							"aria-label": pe,
							children: [/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ m("b", { children: pe }), f.selected.length > 0 && /* @__PURE__ */ m("span", { children: f.selected.length })] }), /* @__PURE__ */ h("div", {
								className: "rv-chooser-content",
								children: [
									ce.map((e) => /* @__PURE__ */ m(X, {
										id: e.card,
										target: !0,
										onClick: () => A(e),
										onDetail: () => b(e.card)
									}, e.id)),
									le.map((e) => {
										let t = x.find((t) => e.ref.startsWith(`${t}-`));
										return /* @__PURE__ */ m("div", {
											className: "rv-choice-region",
											children: /* @__PURE__ */ m(bt, {
												region: {
													id: e.ref,
													resource: t,
													number: Number(e.n ?? 0),
													amount: 0,
													x: 0,
													y: 0
												},
												target: !0,
												onClick: () => A(e)
											})
										}, e.id);
									}),
									ue.map((e) => /* @__PURE__ */ h("button", {
										type: "button",
										className: "rv-resource-choice",
										onClick: () => A(e),
										children: [
											/* @__PURE__ */ m(J, {
												kind: e.ref,
												size: 42
											}),
											K(g, e.ref),
											/* @__PURE__ */ m(u, {
												radius: 5,
												flash: !1
											})
										]
									}, e.id)),
									de.map((e) => /* @__PURE__ */ h("button", {
										type: "button",
										className: "rv-die-choice",
										onClick: () => A(e),
										"aria-label": String(e.n),
										children: [/* @__PURE__ */ m(mt, { n: e.n }), /* @__PURE__ */ m(u, {
											radius: 5,
											flash: !1
										})]
									}, e.id)),
									he.map((e) => /* @__PURE__ */ m("button", {
										type: "button",
										onClick: () => A(e),
										children: G(g, e.tag === "search" ? "search" : "random")
									}, e.id))
								]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ m("dialog", {
				ref: T,
				className: "rv-dialog",
				onCancel: () => b(null),
				onClick: (e) => {
					e.target === e.currentTarget && b(null);
				},
				children: y && /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "rv-close",
						onClick: () => b(null),
						"aria-label": G(g, "close"),
						children: /* @__PURE__ */ m(s, { size: 24 })
					}),
					/* @__PURE__ */ m(X, {
						id: y,
						full: !0
					}),
					/* @__PURE__ */ h("p", {
						className: "rv-detail-type",
						children: [G(g, re[y]?.set ?? "basic"), re[y]?.moon ? " · ◐" : ""]
					}),
					j(y) && /* @__PURE__ */ m("button", {
						type: "button",
						className: "rv-primary",
						onClick: () => {
							A(j(y)), b(null);
						},
						children: G(g, j(y).tag ?? "select")
					})
				] })
			}),
			ee && /* @__PURE__ */ m("div", {
				className: "rv-modal",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": G(g, "log"),
				children: /* @__PURE__ */ h("div", {
					className: "rv-log",
					children: [/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ m("b", { children: G(g, "log") }), /* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => te(!1),
						"aria-label": G(g, "close"),
						children: /* @__PURE__ */ m(s, { size: 22 })
					})] }), [...d.log].reverse().map((e, t) => /* @__PURE__ */ h("p", { children: [
						/* @__PURE__ */ m("b", { children: D(e.rid) }),
						" · ",
						G(g, e.key === "gain" ? "gainLog" : e.key === "roll" ? "roll" : e.key === "steal" ? "steal" : e.key),
						e.card && ` · ${x.includes(e.card) ? K(g, e.card) : Y(e.card, g)}`,
						e.n !== void 0 && ` · ${e.n}`
					] }, t))]
				})
			})
		]
	});
}
//#endregion
//#region src/games/rivals/bot.ts
function wt(e, t) {
	if (e === "city") return 12;
	if (e === "settlement") return 11;
	if (e === "road") return 5;
	let n = E(e);
	return n ? (n.vp ?? 0) * 8 + (n.progress ?? 0) * 6 + (n.strength ?? 0) * 1.8 + (n.commerce ?? 0) * 2.6 + (n.skill ?? 0) * .9 + ([
		"lumberCamp",
		"brickFactory",
		"grainMill",
		"ironFoundry",
		"weaver"
	].includes(n.key) ? Math.max(2, 10 - t * .08) : 0) + ([
		"parishHall",
		"university",
		"merchantGuild",
		"hedgeTavern",
		"library"
	].includes(n.key) ? 3 : 0) + (n.type === "ship" ? 3 : 0) + ({
		brigitta: 4,
		reiner: 3,
		scout: 1,
		caravan: 3,
		goldsmith: 2,
		relocation: .5,
		traitor: 5,
		voyage: 4,
		brigands: 4,
		tradeMaster: 4,
		merchant: 3,
		doctor: 3,
		mineral: 4,
		threeField: 4,
		guido: 4,
		gustav: 4,
		benjamin: 3
	}[n.key] ?? 0) : 0;
}
function Tt(e, t) {
	let n = wt(e, t);
	return Number.isFinite(n) ? n : 0;
}
function Et(e) {
	return Object.fromEntries(x.map((t) => [t, e.regions.filter((e) => e.resource === t).reduce((e, t) => e + t.amount, 0)]));
}
function Dt(e, t, n, r, i = !0) {
	let a = t.prompt, o = Et(r), s = r.regions.find((t) => t.id === e.ref), c = e.card ?? e.ref, l = E(c), u = Object.fromEntries(x.map((e) => [e, Math.max(e === "ore" ? 3 : e === "grain" ? 2 : 1, ...n.hand.map((t) => E(t).cost[e] ?? 0)) - o[e]]));
	if (e.id === "cancel" || e.id === "skip") return -50;
	if (e.id === "ready" || e.id === "roll" || e.id === "continue" || e.id === "finish") return 1;
	if (e.id === "end") return 0;
	if (e.id === "demolish") return -100;
	if (e.id === "defend") return 10;
	if (e.id === "accept") return 0;
	if (e.id === "payGold") return 5;
	if (t.phase === "main" && e.tag === "build") return Tt(c, t.round) + 2;
	if (e.tag === "play") return 3 + Tt(c, t.round);
	if (e.id.startsWith("mint:")) return 4;
	if (e.id === "trade") return Object.values(u).some((e) => e > 0) ? 2 : -2;
	if (e.kind === "slot") return i ? l?.resource ? r.regions.filter((t) => t.resource === l.resource && Math.abs(t.x - e.x) === 1 && Math.sign(t.y) === Math.sign(e.y)).length * 10 : l?.key === "storehouse" || l?.key === "abbey" ? r.regions.filter((t) => Math.abs(t.x - e.x) === 1 && Math.sign(t.y) === Math.sign(e.y)).reduce((e, t) => e + t.amount, 0) : c === "city" ? r.expansions.filter((t) => t.x === e.x).length : 1 : 1;
	if (e.kind === "die") return r.regions.filter((t) => t.number === e.n).reduce((e, t) => e + (3 - t.amount), 0);
	if (e.kind === "stack") return a === "exchangeMode" ? e.tag === "random" ? 2 : 1 : (e.tag === "basic" ? t.round < 10 ? 5 : 1 : 3) + e.n * .01;
	if (e.kind === "resource") return ["tradeType", "discount"].includes(a) ? -(u[e.ref] ?? 0) : u[e.ref] ?? 0;
	if (s) return [
		"payment",
		"caravan",
		"searchPay"
	].includes(a) ? i ? (s.amount === 3 ? 2 : 0) + +(s.number === t.dice.production) : s.amount : a === "tradeType" ? -(u[s.resource] ?? 0) : a === "givePick" ? -u[s.resource] : a === "arrange" ? -1 : (i ? u[s.resource] * 3 : 0) + (3 - s.amount) * .2;
	if (e.kind === "region" && e.owner && e.owner !== r.rid) {
		let n = t.players.find((t) => t.rid === e.owner).regions.find((t) => t.id === e.ref);
		return n ? (u[n.resource] ?? 0) * 2 + n.amount * .1 : 1;
	}
	if (e.kind === "region" && e.tag === "newRegion") return 1;
	if (e.kind === "card") {
		let n = Tt(c, t.round);
		return ["refill", "fraternal"].includes(t.phase) || [
			"fraternal",
			"feudSelect",
			"attack"
		].includes(a) || e.tag === "remove" ? -n : t.phase === "exchange" ? l?.type === "action" ? -5 - n : -n : a === "startCards" ? n + (l?.type === "action" ? 0 : 2) : n;
	}
	return a === "travel" ? e.n ?? 0 : 0;
}
function Ot(e, t, n, r, i = !0) {
	let a = Dt(e, t, n, r, i), o = E(e.card ?? e.ref);
	if (e.tag === "play" && ["guido", "gustav"].includes(o?.key ?? "") && ["guido", "gustav"].includes(E(t.discardTop ?? "")?.key ?? "")) return -1;
	if (t.prompt === "discardPick" && ["guido", "gustav"].includes(o?.key ?? "")) return -100;
	let s = (e) => r.towns.some((t) => (!E(e)?.city || t.city) && [
		-1,
		1,
		...t.city ? [-2, 2] : []
	].some((e) => !r.expansions.some((n) => n.x === t.x && n.y === e))), c = (e) => wt(e, t.round) + (E(e)?.vp ?? 0) * 8, l = n.hand.filter((e) => {
		let t = E(e);
		return t.type !== "action" && (!t.unique || !r.expansions.some((e) => E(e.card).key === t.key)) && (!t.city || r.towns.some((e) => e.city));
	}).filter((e) => !s(e)).flatMap((e) => r.expansions.filter((t) => !E(e).city || r.towns.some((e) => e.x === t.x && e.city)).map((t) => ({
		id: e,
		old: t.card,
		gain: c(e) - c(t.card)
	}))).sort((e, t) => t.gain - e.gain)[0];
	if (e.id === "demolish") return l && l.gain > 6 ? 30 : -100;
	if (t.prompt === "demolish" && e.kind === "card") return l?.old === e.ref ? 100 : -c(e.ref);
	if (t.phase === "exchange" && e.kind === "card") {
		if (!t.stacks.some((e) => e.count > 0)) return -50;
		let n = o?.unique && r.expansions.some((e) => E(e.card).key === o.key), i = !s(e.ref) && l?.id !== e.ref, a = o?.key === "scout" && t.supply.settlement === 0;
		return n || i || a ? 18 - c(e.ref) * .1 : 8 - c(e.ref) * .35;
	}
	return a;
}
var kt = (e, t) => {
	let n = e.public, r = e.private, i = n.players.find((e) => e.rid === t.rid);
	return !i || !r?.options.length || n.actor !== t.rid ? null : { action: {
		type: "pick",
		id: r.options.map((e, a) => ({
			o: e,
			score: Ot(e, n, r, i, t.difficulty !== "weak") - a * 1e-5
		})).sort((e, t) => t.score - e.score)[0].o.id
	} };
}, Q = (e, t, n = t) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - n) / 2,
	w: t,
	h: n
});
function $(e, t, n) {
	let r = e.anchor(t), i = n ? e.anchor(`seat:${n}`) : null;
	return r && r.w > 0 && r.h > 0 ? r : i && i.w > 0 && i.h > 0 ? i : e.anchor("supply");
}
function At({ n: e, event: t }) {
	let n = i(null), a = q();
	return r(() => {
		let e = n.current?.animate([
			{
				transform: "rotate(-18deg) scale(.65)",
				opacity: .2
			},
			{
				transform: "rotate(16deg) scale(1.15)",
				opacity: 1,
				offset: .5
			},
			{
				transform: "rotate(0) scale(1)",
				opacity: 1
			}
		], {
			duration: 460,
			easing: "ease-out"
		});
		return () => e?.cancel();
	}, []), /* @__PURE__ */ h("div", {
		ref: n,
		className: "rv-fx-dice",
		children: [/* @__PURE__ */ m(mt, { n: e }), t && /* @__PURE__ */ m("span", { children: G(a, t === "trade" ? "tradeEvent" : t) })]
	});
}
var jt = {
	move(e, t) {
		let n = e.data, r = e.secret?.card ?? n.card, i = $(t, n.from, e.rid), a = $(t, n.to, e.rid);
		if (r && n.from === "supply" && (i = t.anchor(`supplycard:${r}`) ?? i), r && n.to.startsWith("hand:") && (a = t.anchor(`handcard:${r}`) ?? a), !i || !a) return null;
		let o = x.includes(r), s = t.queued ? 240 : 460;
		if (o) {
			let e = Q(i, 30), t = Q(a, 30);
			return {
				ms: s,
				node: Array.from({ length: Math.min(3, n.n) }, (n, i) => /* @__PURE__ */ m(_, {
					from: {
						...e,
						x: e.x + i * 8
					},
					to: {
						...t,
						x: t.x + i * 8
					},
					ms: s,
					children: /* @__PURE__ */ m("span", {
						className: "rv-fx-resource",
						children: /* @__PURE__ */ m(J, {
							kind: r,
							size: 30
						})
					})
				}, i))
			};
		}
		let c = n.to.startsWith("hand:") && r ? `handcard:${r}` : n.to, l = t.queued ? [] : [c], u = n.to.startsWith("hand:") && !r, d = Math.min(180, i.w, a.w), f = Q(i, d), p = u ? Q(a, d) : Q(a, a.w, a.h);
		return {
			ms: s,
			node: /* @__PURE__ */ m(_, {
				from: f,
				to: p,
				ms: s,
				children: /* @__PURE__ */ m("div", {
					className: "rv-root rv-fx-card",
					style: {
						width: d,
						height: d
					},
					children: r ? /* @__PURE__ */ m(X, { id: r }) : /* @__PURE__ */ m(_t, {})
				})
			}),
			hide: l.filter((e) => !["discard", "supply"].includes(e) && !e.startsWith("stack:") && !e.startsWith("hand:"))
		};
	},
	dice(e, t) {
		let n = e.data, r = t.anchor("dice");
		return r ? {
			ms: 480,
			node: /* @__PURE__ */ m("div", {
				className: "rv-root rv-fx-dice-holder",
				style: {
					left: r.x,
					top: r.y,
					width: r.w,
					height: r.h
				},
				children: /* @__PURE__ */ m(At, {
					n: n.production,
					event: n.event
				})
			}),
			hide: t.queued ? [] : ["dice"]
		} : null;
	},
	defense(e, t) {
		let n = e.data, r = $(t, "dice", e.rid);
		return r ? {
			ms: 480,
			node: /* @__PURE__ */ m("div", {
				className: "rv-root rv-fx-dice-holder",
				style: {
					left: r.x,
					top: r.y,
					width: r.w,
					height: r.h
				},
				children: /* @__PURE__ */ m(At, { n: n.n })
			})
		} : null;
	},
	event(e, t) {
		let n = e.data.card, r = t.anchor("event");
		return r ? {
			ms: 470,
			node: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(v, {
				at: r,
				ms: 470
			}), /* @__PURE__ */ m(_, {
				from: Q(r, r.w * .7),
				to: r,
				ms: 470,
				children: /* @__PURE__ */ m("div", {
					className: "rv-root rv-fx-card",
					style: {
						width: r.w,
						height: r.w
					},
					children: /* @__PURE__ */ m(X, { id: n })
				})
			})] }),
			hide: t.queued ? [] : ["event"]
		} : null;
	},
	regionDeal(e, t) {
		let n = e.data, r = t.queued ? 240 : 460, i = $(t, "regions", n.rid);
		return i ? {
			ms: r,
			node: n.regions.map((e) => {
				let a = $(t, `region:${e.id}`, n.rid);
				return a ? /* @__PURE__ */ m(_, {
					from: Q(i, i.w),
					to: a,
					ms: r,
					children: /* @__PURE__ */ m("div", {
						className: "rv-root rv-fx-card",
						style: {
							width: i.w,
							height: i.w
						},
						children: /* @__PURE__ */ m(bt, {
							region: e,
							anchor: !1
						})
					})
				}, e.id) : null;
			}),
			hide: t.queued ? [] : n.regions.map((e) => `region:${e.id}`)
		} : null;
	},
	regionSwap(e, t) {
		let n = e.data, r = t.queued ? 240 : 460, i = [{
			r: n.a,
			from: n.fromA
		}, {
			r: n.b,
			from: n.fromB
		}];
		return {
			ms: r,
			node: i.map(({ r: e, from: i }) => {
				let a = $(t, i, n.rid), o = $(t, `region:${e.id}`, n.rid);
				return a && o ? /* @__PURE__ */ m(_, {
					from: a,
					to: o,
					ms: r,
					children: /* @__PURE__ */ m("div", {
						className: "rv-root rv-fx-card",
						style: {
							width: a.w,
							height: a.h
						},
						children: /* @__PURE__ */ m(bt, {
							region: e,
							anchor: !1
						})
					})
				}, e.id) : null;
			}),
			hide: t.queued ? [] : i.map(({ r: e }) => `region:${e.id}`)
		};
	}
};
//#endregion
//#region src/games/rivals/game-over.tsx
function Mt(e) {
	let t = q(), n = e.public, [r, i] = a(!1), o = (t) => e.members.find((e) => e.rid === t)?.name ?? t, s = e.result.winner?.[0] ?? [...n.players].sort((e, t) => t.stats.vp - e.stats.vp)[0].rid;
	return r ? /* @__PURE__ */ h("div", {
		className: "rv-review-wrap",
		children: [/* @__PURE__ */ m("button", {
			type: "button",
			className: "rv-review-back",
			onClick: () => i(!1),
			children: G(t, "backToResult")
		}), /* @__PURE__ */ m(Ct, {
			...e,
			send: () => {}
		})]
	}) : /* @__PURE__ */ h("div", {
		className: "rv-root rv-final",
		children: [
			/* @__PURE__ */ h("header", {
				className: "rv-final-heading",
				children: [
					/* @__PURE__ */ h("p", { children: ["RIVALS FOR CATAN · ", G(t, n.mode)] }),
					/* @__PURE__ */ m(J, {
						kind: "vp",
						size: 52
					}),
					/* @__PURE__ */ m("h1", { children: G(t, "winner").replace("{name}", o(s)) }),
					/* @__PURE__ */ h("span", { children: [
						G(t, "targetScore"),
						" ",
						n.goal
					] })
				]
			}),
			/* @__PURE__ */ m("main", {
				className: "rv-final-domains",
				children: [...n.players].sort((e, t) => Number(t.rid === s) - Number(e.rid === s)).map((e) => /* @__PURE__ */ h("section", {
					className: "rv-final-domain",
					"data-winner": e.rid === s,
					children: [
						/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ m("h2", { children: o(e.rid) }), /* @__PURE__ */ h("strong", { children: [/* @__PURE__ */ m(J, {
							kind: "vp",
							size: 34
						}), e.stats.vp] })] }),
						/* @__PURE__ */ m("dl", { children: [
							["townScore", e.stats.towns],
							["expansionScore", e.stats.expansions],
							["advantageScore", e.stats.advantages]
						].map(([e, n]) => /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("dt", { children: G(t, e) }), /* @__PURE__ */ m("dd", { children: n })] }, e)) }),
						/* @__PURE__ */ m("div", {
							className: "rv-final-map",
							children: /* @__PURE__ */ m(St, {
								player: e,
								options: [],
								selected: [],
								onPick: () => {},
								onDetail: () => i(!0)
							})
						})
					]
				}, e.rid))
			}),
			/* @__PURE__ */ h("footer", {
				className: "rv-final-actions",
				children: [
					/* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => i(!0),
						children: G(t, "review")
					}),
					e.onPlayAgain ? /* @__PURE__ */ m("button", {
						type: "button",
						className: "rv-primary",
						onClick: e.onPlayAgain,
						children: G(t, "playAgain")
					}) : /* @__PURE__ */ m("span", { children: G(t, "hostWaiting") }),
					e.onBackToLobby && /* @__PURE__ */ m("button", {
						type: "button",
						onClick: e.onBackToLobby,
						children: G(t, "backToLobby")
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/rivals/options.tsx
function Nt({ value: e, onChange: t }) {
	let n = q(), r = se.safeParse(e), i = r.success ? r.data : se.parse(void 0);
	return /* @__PURE__ */ m(b, {
		title: G(n, "mode"),
		children: /* @__PURE__ */ m(p, { children: [
			"intro",
			"gold",
			"turmoil",
			"progress",
			"duel"
		].map((e) => /* @__PURE__ */ m(y, {
			name: "rivals-mode",
			value: e,
			checked: i.mode === e,
			label: G(n, e),
			onChange: () => t({ mode: e })
		}, e)) })
	});
}
//#endregion
//#region src/games/rivals/guide.tsx
function Pt() {
	let e = q();
	return /* @__PURE__ */ m("section", {
		style: {
			color: "#30372e",
			lineHeight: 1.75,
			fontSize: 14,
			padding: 12,
			background: "#f3efdd"
		},
		children: /* @__PURE__ */ m("div", {
			style: {
				display: "flex",
				flexWrap: "wrap",
				gap: 12,
				marginBottom: 16
			},
			children: [
				"wood",
				"brick",
				"wool",
				"grain",
				"ore",
				"gold",
				"strength",
				"skill",
				"commerce",
				"progress",
				"vp"
			].map((t) => /* @__PURE__ */ h("span", {
				style: {
					display: "inline-flex",
					alignItems: "center",
					gap: 4
				},
				children: [/* @__PURE__ */ m(J, { kind: t }), G(e, t === "gold" ? "goldResource" : t === "progress" ? "progressPoint" : t)]
			}, t))
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/rivals/entry.tsx
var Ft = {
	definition: ct,
	View: Ct,
	bot: kt,
	fx: jt,
	OverView: Mt,
	Options: Nt,
	Guide: Pt,
	locales: {
		zh: lt,
		en: ut
	}
};
//#endregion
export { Ft as default };
