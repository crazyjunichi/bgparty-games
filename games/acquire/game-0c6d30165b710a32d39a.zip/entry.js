import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { BottomSheet as a } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { IconBack as s, IconBot as c, IconCheck as l, IconClose as u, IconExpand as d, IconLog as f, IconWarning as p } from "@bgparty/sdk/icons";
import { useI18nSettings as m, useT as h } from "@bgparty/sdk/i18n";
import { Texture as ee } from "@bgparty/sdk/texture";
import { useWakeLock as g } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as te } from "@bgparty/sdk/ui/game-screen";
import { LogSheet as ne } from "@bgparty/sdk/ui/log-sheet";
import { SeatBadgedAvatar as _, seatName as re } from "@bgparty/sdk/ui/player-strip";
import { Fragment as ie, jsx as v, jsxs as y } from "react/jsx-runtime";
import { usePrefersReducedMotion as b } from "@bgparty/sdk/fx/use-reduced-motion";
import { OptionRadio as x, OptionSection as S } from "@bgparty/sdk/ui/game-options";
var C = 6e3, w = [
	0,
	1,
	2,
	3,
	4,
	5,
	6
], T = [
	{
		key: "games.acquire.tower",
		letter: "T",
		tier: 0,
		color: "#a97916"
	},
	{
		key: "games.acquire.luxor",
		letter: "L",
		tier: 0,
		color: "#b95422"
	},
	{
		key: "games.acquire.american",
		letter: "A",
		tier: 1,
		color: "#3268a0"
	},
	{
		key: "games.acquire.worldwide",
		letter: "W",
		tier: 1,
		color: "#795aa7"
	},
	{
		key: "games.acquire.festival",
		letter: "F",
		tier: 1,
		color: "#52832d"
	},
	{
		key: "games.acquire.imperial",
		letter: "I",
		tier: 2,
		color: "#3c496e"
	},
	{
		key: "games.acquire.continental",
		letter: "C",
		tier: 2,
		color: "#21867b"
	}
];
function E(e) {
	return `${e % 12 + 1}${String.fromCharCode(65 + Math.floor(e / 12))}`;
}
function D(e) {
	let t = [];
	return e % 12 > 0 && t.push(e - 1), e % 12 < 11 && t.push(e + 1), e >= 12 && t.push(e - 12), e < 96 && t.push(e + 12), t;
}
function O(e) {
	return w.map((t) => e.filter((e) => e === t).length);
}
function k(e, t) {
	return t < 2 ? 0 : (t <= 5 ? t * 100 : t <= 10 ? 600 : t <= 20 ? 700 : t <= 30 ? 800 : t <= 40 ? 900 : 1e3) + T[e].tier * 100;
}
function A(e, t) {
	let n = [t], r = new Set(n), i = /* @__PURE__ */ new Set();
	for (let t = 0; t < n.length; t++) for (let a of D(n[t])) e[a] >= 0 ? i.add(e[a]) : e[a] === -1 && !r.has(a) && (r.add(a), n.push(a));
	let a = [...i].sort((e, t) => e - t), o = O(e);
	return {
		group: n,
		companies: a,
		kind: a.filter((e) => o[e] >= 11).length >= 2 ? "permanent" : a.length >= 2 ? "merge" : a.length === 1 ? "expand" : n.length < 2 ? "independent" : o.every((e) => e > 0) ? "blocked" : "found"
	};
}
function j(e) {
	let t = e.filter((e) => e > 0);
	return t.some((e) => e >= 41) || t.length > 0 && t.every((e) => e >= 11);
}
function M(e, t) {
	let n = e.filter((e) => e.n > 0);
	if (!n.length) return [];
	let r = Math.max(...n.map((e) => e.n)), i = n.filter((e) => e.n === r), a = i.map((e) => ({
		rid: e.rid,
		amount: 0
	}));
	if (i.length > 1) return a.map((e) => ({
		...e,
		amount: Math.ceil(t * 15 / i.length / 100) * 100
	}));
	if (n.length === 1) return [{
		rid: i[0].rid,
		amount: t * 15
	}];
	a[0].amount = t * 10;
	let o = Math.max(...n.filter((e) => e.n < r).map((e) => e.n)), s = n.filter((e) => e.n === o);
	return [...a, ...s.map((e) => ({
		rid: e.rid,
		amount: Math.ceil(t * 5 / s.length / 100) * 100
	}))];
}
//#endregion
//#region src/games/acquire/meta.ts
var N = {
	id: "acquire",
	tier: "alpha",
	mechanics: ["tile-placement", "stock-holding"],
	interactionTags: [],
	nameKey: "games.acquire.name",
	descKey: "games.acquire.desc",
	rulesKey: "games.acquire.rules",
	icon: "🏨",
	iconImg: "games/acquire.webp",
	rulesUrl: { en: "https://www.ultraboardgames.com/acquire/game-rules.php" },
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [4],
	accent: "#1b3b46",
	releasedAt: "2026-10-28T19:38:16+08:00",
	search: {
		py: "bing gou",
		init: "bg"
	},
	hotseat: "cover"
}, P = t.int().min(0).max(6), F = t.int().min(0).max(107), I = t.int().nonnegative(), L = t.array(I.max(25)).length(7), R = t.object({ openAssets: t.boolean().default(!0) }).default({ openAssets: !0 }), z = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		tile: F
	}),
	t.object({
		type: t.literal("found"),
		company: P
	}),
	t.object({
		type: t.literal("survivor"),
		company: P
	}),
	t.object({
		type: t.literal("acquire"),
		company: P
	}),
	t.object({
		type: t.literal("dispose"),
		sell: I.max(25),
		trade: I.max(12)
	}),
	t.object({
		type: t.literal("buy"),
		stocks: t.array(I.max(3)).length(7)
	}),
	t.object({
		type: t.literal("replace"),
		tiles: t.array(F).max(6)
	}),
	t.object({ type: t.literal("pass") }),
	t.object({ type: t.literal("declareEnd") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), B = t.object({
	rid: t.string(),
	n: I.max(25)
}), ae = t.object({
	rid: t.string(),
	amount: I
}), oe = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("start"),
		rid: t.string(),
		tile: F
	}),
	t.object({
		type: t.literal("place"),
		rid: t.string(),
		tile: F
	}),
	t.object({
		type: t.literal("found"),
		rid: t.string(),
		company: P,
		size: I,
		bonus: t.boolean()
	}),
	t.object({
		type: t.literal("buy"),
		rid: t.string(),
		stocks: L,
		cost: I
	}),
	t.object({
		type: t.literal("merge"),
		company: P,
		survivor: P,
		price: I,
		holdings: t.array(B)
	}),
	t.object({
		type: t.literal("bonus"),
		company: P,
		awards: t.array(ae)
	}),
	t.object({
		type: t.literal("dispose"),
		rid: t.string(),
		company: P,
		survivor: P,
		sell: I,
		trade: I,
		keep: I,
		cash: I
	}),
	t.object({
		type: t.literal("absorb"),
		company: P,
		survivor: P
	}),
	t.object({
		type: t.literal("discard"),
		rid: t.string(),
		tiles: t.array(F)
	}),
	t.object({
		type: t.literal("declare"),
		rid: t.string()
	}),
	t.object({
		type: t.literal("pass"),
		rid: t.string()
	}),
	t.object({
		type: t.literal("sale"),
		company: P,
		returns: t.array(ae)
	})
]), se = t.enum([
	"place",
	"found",
	"survivor",
	"order",
	"bonus",
	"dispose",
	"absorb",
	"buy",
	"replace",
	"finalBonus",
	"finalSale",
	"done"
]), ce = t.object({
	board: t.array(t.int().min(-2).max(6)).length(108),
	phase: se,
	turn: t.string(),
	actor: t.string().nullable(),
	turnNumber: I,
	openAssets: t.boolean(),
	endDeclared: t.boolean(),
	canDeclare: t.boolean(),
	deckCount: I.max(108),
	discarded: t.array(F),
	players: t.array(t.object({
		rid: t.string(),
		cash: I.nullable(),
		stocks: L.nullable(),
		handCount: I.max(6)
	})),
	companies: t.array(t.object({
		company: P,
		size: I.max(108),
		bank: I.max(25),
		price: I,
		safe: t.boolean()
	})).length(7),
	choices: t.array(P),
	merger: t.object({
		tile: F,
		survivor: P.nullable(),
		current: P.nullable(),
		remaining: t.array(P),
		sizes: t.array(I).length(7),
		price: I,
		holdings: t.array(B)
	}).nullable(),
	finalCompany: P.nullable(),
	final: t.array(t.object({
		rid: t.string(),
		cash: I,
		bonuses: I,
		sales: I,
		total: I
	})),
	log: t.array(oe)
}), le = t.object({
	hand: t.array(F).max(6),
	cash: I,
	stocks: L,
	legalTiles: t.array(F),
	permanentTiles: t.array(F)
});
function V(e) {
	return e.order[e.turnIndex];
}
function ue(e) {
	return e.phase === "dispose" ? e.merger.disposers[e.merger.disposerIndex] : [
		"place",
		"found",
		"survivor",
		"order",
		"buy",
		"replace"
	].includes(e.phase) ? V(e) : null;
}
function H(e, t, n) {
	for (let r = 0; r < n && e.deck.length; r++) e.hands[t].push(e.deck.pop());
	e.hands[t].sort((e, t) => e - t);
}
function U(t, n, r) {
	let i = Array.from({ length: 108 }, (e, t) => t), a = 0;
	for (let t = i.length - 1; t > 0; t--) {
		let n = e(r, a++, t + 1);
		[i[t], i[n]] = [i[n], i[t]];
	}
	let o = n.map((e) => ({
		rid: e,
		tile: i.pop()
	})), s = o.reduce((e, t, n) => t.tile < o[e].tile ? n : e, 0), c = [...n.slice(s), ...n.slice(0, s)], l = Array(108).fill(-2);
	o.forEach((e) => {
		l[e.tile] = -1;
	});
	let u = {
		seed: r,
		rngCursor: a,
		order: c,
		turnIndex: 0,
		turnNumber: 1,
		phase: "place",
		openAssets: t.openAssets,
		board: l,
		deck: i,
		discarded: [],
		hands: Object.fromEntries(n.map((e) => [e, []])),
		cash: Object.fromEntries(n.map((e) => [e, C])),
		stocks: Object.fromEntries(n.map((e) => [e, Array(7).fill(0)])),
		bank: Array(7).fill(25),
		pendingTile: null,
		pendingGroup: [],
		placedThisTurn: !1,
		merger: null,
		endDeclared: !1,
		finalQueue: [],
		finalIndex: 0,
		final: [],
		log: o.map((e) => ({
			type: "start",
			...e
		}))
	};
	for (let e of n) H(u, e, 6);
	return { state: u };
}
function W(e, t) {
	let n = Math.max(...e.map((e) => t[e]));
	return e.filter((e) => t[e] === n);
}
function G(e) {
	let t = e.merger, n = W(t.remaining, t.sizes);
	if (n.length > 1) {
		e.phase = "order";
		return;
	}
	t.current = n[0], e.phase = "bonus";
}
function K(e, t) {
	let n = e.merger;
	n.survivor = t, n.remaining = n.remaining.filter((e) => e !== t), G(e);
}
function q(e, t, n, r) {
	let i = M(n, r);
	for (let t of i) {
		e.cash[t.rid] += t.amount;
		let n = e.final.find((e) => e.rid === t.rid);
		n && (n.bonuses += t.amount, n.total += t.amount);
	}
	return e.log.push({
		type: "bonus",
		company: t,
		awards: i
	}), i.map((e, t) => ({
		kind: "bonus",
		rid: e.rid,
		data: { amount: e.amount },
		...t ? { with: !0 } : {}
	}));
}
function de(e) {
	if (e.endDeclared) {
		let t = O(e.board);
		e.finalQueue = w.filter((e) => t[e] > 0), e.finalIndex = 0, e.final = e.order.map((t) => ({
			rid: t,
			cash: e.cash[t],
			bonuses: 0,
			sales: 0,
			total: e.cash[t]
		})), e.phase = "finalBonus";
		return;
	}
	e.turnIndex = (e.turnIndex + 1) % e.order.length, e.turnNumber++, e.phase = "place", e.pendingTile = null, e.pendingGroup = [], e.placedThisTurn = !1;
}
function J(e) {
	let t = V(e);
	e.placedThisTurn && H(e, t, 1), e.hands[t].some((t) => A(e.board, t).kind === "permanent") ? e.phase = "replace" : de(e);
}
function fe(e) {
	if (![
		"bonus",
		"absorb",
		"finalBonus",
		"finalSale"
	].includes(e.phase)) return { state: e };
	let t = structuredClone(e);
	if (t.phase === "bonus") {
		let e = t.merger, n = e.current, r = k(n, e.sizes[n]);
		e.holdings = t.order.map((e) => ({
			rid: e,
			n: t.stocks[e][n]
		})), t.log.push({
			type: "merge",
			company: n,
			survivor: e.survivor,
			price: r,
			holdings: e.holdings
		});
		let i = q(t, n, e.holdings, r);
		return e.disposers = [...t.order.slice(t.turnIndex), ...t.order.slice(0, t.turnIndex)].filter((e) => t.stocks[e][n] > 0), e.disposerIndex = 0, t.phase = e.disposers.length ? "dispose" : "absorb", {
			state: t,
			fx: i
		};
	}
	if (t.phase === "absorb") {
		let e = t.merger, n = e.current, r = e.survivor;
		if (t.board = t.board.map((e) => e === n ? r : e), t.log.push({
			type: "absorb",
			company: n,
			survivor: r
		}), e.remaining = e.remaining.filter((e) => e !== n), e.current = null, e.holdings = [], e.remaining.length) G(t);
		else {
			for (let n of e.group) t.board[n] = r;
			t.merger = null, t.phase = "buy";
		}
		return {
			state: t,
			fx: [{
				kind: "absorb",
				data: {
					company: n,
					survivor: r
				}
			}]
		};
	}
	let n = t.finalQueue[t.finalIndex], r = O(t.board)[n];
	if (t.phase === "finalBonus") {
		let e = q(t, n, t.order.map((e) => ({
			rid: e,
			n: t.stocks[e][n]
		})), k(n, r));
		return t.phase = "finalSale", {
			state: t,
			fx: e
		};
	}
	let i = t.order.map((e) => ({
		rid: e,
		amount: t.stocks[e][n] * k(n, r)
	}));
	for (let e of i) {
		t.cash[e.rid] += e.amount, t.bank[n] += t.stocks[e.rid][n], t.stocks[e.rid][n] = 0;
		let r = t.final.find((t) => t.rid === e.rid);
		r.sales += e.amount, r.total += e.amount;
	}
	return t.log.push({
		type: "sale",
		company: n,
		returns: i
	}), t.finalIndex++, t.phase = t.finalIndex < t.finalQueue.length ? "finalBonus" : "done", {
		state: t,
		fx: i.filter((e) => e.amount > 0).map((e, t) => ({
			kind: "bonus",
			rid: e.rid,
			data: { amount: e.amount },
			...t ? { with: !0 } : {}
		}))
	};
}
function pe(e, t, n) {
	if (t.type === "tick") return n.by === "$engine" ? fe(e) : { code: "games.acquire.errTurn" };
	if (n.by !== ue(e)) return { code: "games.acquire.errTurn" };
	let r = n.by;
	if (t.type === "declareEnd") {
		if (![
			"place",
			"buy",
			"replace"
		].includes(e.phase) || e.endDeclared || !j(O(e.board))) return { code: "games.acquire.errEnd" };
		let t = structuredClone(e);
		return t.endDeclared = !0, t.log.push({
			type: "declare",
			rid: r
		}), { state: t };
	}
	let i = structuredClone(e);
	if (t.type === "place") {
		if (i.phase !== "place" || !i.hands[r].includes(t.tile) || i.board[t.tile] !== -2) return { code: "games.acquire.errTile" };
		let e = A(i.board, t.tile);
		if (e.kind === "blocked" || e.kind === "permanent") return { code: e.kind === "blocked" ? "games.acquire.errEighth" : "games.acquire.errSafe" };
		let n = O(i.board);
		if (i.hands[r] = i.hands[r].filter((e) => e !== t.tile), i.board[t.tile] = -1, i.pendingTile = t.tile, i.pendingGroup = e.group, i.placedThisTurn = !0, i.log.push({
			type: "place",
			rid: r,
			tile: t.tile
		}), e.kind === "found") i.phase = "found";
		else if (e.kind === "merge") {
			i.merger = {
				tile: t.tile,
				group: e.group,
				survivor: null,
				remaining: e.companies,
				current: null,
				sizes: n,
				holdings: [],
				disposers: [],
				disposerIndex: 0
			};
			let r = W(e.companies, n);
			r.length === 1 ? K(i, r[0]) : i.phase = "survivor";
		} else {
			if (e.kind === "expand") for (let t of e.group) i.board[t] = e.companies[0];
			i.phase = "buy";
		}
		return {
			state: i,
			fx: [{
				kind: "place",
				data: { tile: t.tile }
			}]
		};
	}
	if (t.type === "found") {
		if (i.phase !== "found" || O(i.board)[t.company] !== 0) return { code: "games.acquire.errCompany" };
		for (let e of i.pendingGroup) i.board[e] = t.company;
		let e = i.bank[t.company] > 0;
		return e && (i.stocks[r][t.company]++, i.bank[t.company]--), i.log.push({
			type: "found",
			rid: r,
			company: t.company,
			size: i.pendingGroup.length,
			bonus: e
		}), i.phase = "buy", {
			state: i,
			fx: [{
				kind: "found",
				data: { company: t.company }
			}]
		};
	}
	if (t.type === "survivor") return i.phase !== "survivor" || !W(i.merger.remaining, i.merger.sizes).includes(t.company) ? { code: "games.acquire.errCompany" } : (K(i, t.company), { state: i });
	if (t.type === "acquire") return i.phase !== "order" || !W(i.merger.remaining, i.merger.sizes).includes(t.company) ? { code: "games.acquire.errCompany" } : (i.merger.current = t.company, i.phase = "bonus", { state: i });
	if (t.type === "dispose") {
		if (i.phase !== "dispose") return { code: "games.acquire.errTurn" };
		let e = i.merger, n = e.current, a = e.survivor, o = i.stocks[r][n];
		if (t.sell + t.trade * 2 > o || t.trade > i.bank[a]) return { code: "games.acquire.errDispose" };
		let s = t.sell * k(n, e.sizes[n]);
		return i.stocks[r][n] -= t.sell + t.trade * 2, i.stocks[r][a] += t.trade, i.bank[n] += t.sell + t.trade * 2, i.bank[a] -= t.trade, i.cash[r] += s, i.log.push({
			type: "dispose",
			rid: r,
			company: n,
			survivor: a,
			sell: t.sell,
			trade: t.trade,
			keep: i.stocks[r][n],
			cash: s
		}), e.disposerIndex++, e.disposerIndex >= e.disposers.length && (i.phase = "absorb"), { state: i };
	}
	if (t.type === "buy") {
		if (i.phase !== "buy" || t.stocks.reduce((e, t) => e + t, 0) > 3) return { code: "games.acquire.errBuy" };
		let e = O(i.board), n = t.stocks.reduce((t, n, r) => t + n * k(r, e[r]), 0);
		return n > i.cash[r] || t.stocks.some((t, n) => t > i.bank[n] || t > 0 && e[n] === 0) ? { code: "games.acquire.errBuy" } : (i.cash[r] -= n, t.stocks.forEach((e, t) => {
			i.stocks[r][t] += e, i.bank[t] -= e;
		}), n > 0 && i.log.push({
			type: "buy",
			rid: r,
			stocks: [...t.stocks],
			cost: n
		}), J(i), { state: i });
	}
	return t.type === "replace" ? i.phase !== "replace" || new Set(t.tiles).size !== t.tiles.length || t.tiles.some((e) => !i.hands[r].includes(e) || A(i.board, e).kind !== "permanent") ? { code: "games.acquire.errReplace" } : (i.hands[r] = i.hands[r].filter((e) => !t.tiles.includes(e)), i.discarded.push(...t.tiles), t.tiles.length && (i.log.push({
		type: "discard",
		rid: r,
		tiles: [...t.tiles]
	}), H(i, r, t.tiles.length)), de(i), { state: i }) : i.phase !== "place" || i.hands[r].some((e) => !["blocked", "permanent"].includes(A(i.board, e).kind)) ? { code: "games.acquire.errPass" } : (i.log.push({
		type: "pass",
		rid: r
	}), i.phase = "buy", { state: i });
}
function Y(e, t) {
	let n = O(e.board), r = e.openAssets || e.phase === "done" || e.phase === "finalBonus" || e.phase === "finalSale", i = e.merger, a = e.phase === "found" ? w.filter((e) => n[e] === 0) : e.phase === "survivor" || e.phase === "order" ? W(i.remaining, i.sizes) : [], o = e.hands[t] ?? [];
	return {
		public: {
			board: e.board,
			phase: e.phase,
			turn: V(e),
			actor: ue(e),
			turnNumber: e.turnNumber,
			openAssets: e.openAssets,
			endDeclared: e.endDeclared,
			canDeclare: !e.endDeclared && [
				"place",
				"buy",
				"replace"
			].includes(e.phase) && j(n),
			deckCount: e.deck.length,
			discarded: e.discarded,
			players: e.order.map((t) => ({
				rid: t,
				cash: r ? e.cash[t] : null,
				stocks: r ? e.stocks[t] : null,
				handCount: e.hands[t].length
			})),
			companies: w.map((t) => ({
				company: t,
				size: n[t],
				price: k(t, n[t]),
				bank: e.bank[t],
				safe: n[t] >= 11
			})),
			choices: a,
			merger: i ? {
				tile: i.tile,
				survivor: i.survivor,
				current: i.current,
				remaining: i.remaining,
				sizes: i.sizes,
				price: i.current === null ? 0 : k(i.current, i.sizes[i.current]),
				holdings: i.holdings
			} : null,
			finalCompany: e.phase === "finalBonus" || e.phase === "finalSale" ? e.finalQueue[e.finalIndex] : null,
			final: e.final,
			log: e.log
		},
		private: {
			hand: o,
			cash: e.cash[t] ?? 0,
			stocks: e.stocks[t] ?? Array(7).fill(0),
			legalTiles: o.filter((t) => !["blocked", "permanent"].includes(A(e.board, t).kind)),
			permanentTiles: o.filter((t) => A(e.board, t).kind === "permanent")
		}
	};
}
var me = {
	meta: N,
	saveCompatibility: { version: "1" },
	schemas: {
		action: z,
		publicView: ce,
		privateView: le,
		config: R
	},
	setup: U,
	reduce: pe,
	viewFor: Y,
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.order].sort((t, n) => e.cash[n] - e.cash[t]);
		return {
			phase: "done",
			ranking: t,
			winner: t.filter((n) => e.cash[n] === e.cash[t[0]]),
			scores: { ...e.cash }
		};
	},
	nextTickIn: (e) => [
		"bonus",
		"absorb",
		"finalBonus",
		"finalSale"
	].includes(e.phase) ? 850 : null
}, he = [
	"<path d=\"m10 91 68 0 12-6-68-2Z\" fill=\"#273d46\" opacity=\".16\"/><path d=\"m28 90 44-5V29l-8-7-25 1-11 11Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\" opacity=\".45\"/><path d=\"M23 88V36h10V23h8V12h16v11h7v13h9v52Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"M57 12v11h7v13h9v52H58V36h-7V23h-3V12Z\" fill=\"#273d46\" opacity=\".2\"/><path d=\"M36 36h24M29 48h34M28 81h38\" fill=\"none\" stroke=\"#40545a\" stroke-width=\"1.4\"/><g fill=\"#40545a\"><rect x=\"31\" y=\"43\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"42\" y=\"43\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"53\" y=\"43\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"31\" y=\"54\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"42\" y=\"54\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"53\" y=\"54\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"31\" y=\"65\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"42\" y=\"65\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"53\" y=\"65\" width=\"5\" height=\"6\" rx=\".5\"/><path d=\"M42 88V74a6 6 0 0 1 12 0v14Z\"/></g><path d=\"M39 23h18m-10-10V5\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M12 88h72v4H12Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"M12 88h72\" fill=\"none\" stroke=\"#40545a\" stroke-width=\"1.5\"/>",
	"<path d=\"m10 91 68 0 12-6-68-2Z\" fill=\"#273d46\" opacity=\".16\"/><path d=\"M16 88V38l12-15 10 15v-8l11-11 11 11v8l10-15 12 15v50Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"m70 23 12 15v50H70V42l-9-9Z\" fill=\"#273d46\" opacity=\".23\"/><path d=\"M13 42h27m20 0h24M39 36h22M19 80h55\" fill=\"none\" stroke=\"#40545a\" stroke-width=\"1.4\"/><g fill=\"#40545a\"><rect x=\"24\" y=\"48\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"24\" y=\"59\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"24\" y=\"70\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"68\" y=\"48\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"68\" y=\"59\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"68\" y=\"70\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"43\" y=\"40\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"53\" y=\"40\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"43\" y=\"52\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"53\" y=\"52\" width=\"5\" height=\"6\" rx=\".5\"/><path d=\"M42 88V72a7 7 0 0 1 14 0v16Z\"/></g><path d=\"M28 23v-6m42 6v-6M41 31h16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M12 88h72v4H12Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"M12 88h72\" fill=\"none\" stroke=\"#40545a\" stroke-width=\"1.5\"/>",
	"<path d=\"m10 91 68 0 12-6-68-2Z\" fill=\"#273d46\" opacity=\".16\"/><path d=\"M11 88V37h25V21h37l13 12v55Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"m73 21 13 12v55H73Z\" fill=\"#273d46\" opacity=\".25\"/><path d=\"M10 38h26V22h37M13 52h59M13 67h59M13 80h59\" fill=\"none\" stroke=\"#40545a\" stroke-width=\"2\"/><g fill=\"#40545a\"><rect x=\"19\" y=\"42\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"29\" y=\"42\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"39\" y=\"42\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"49\" y=\"42\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"59\" y=\"42\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"19\" y=\"57\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"29\" y=\"57\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"39\" y=\"57\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"49\" y=\"57\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"59\" y=\"57\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"19\" y=\"72\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"29\" y=\"72\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"39\" y=\"72\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"49\" y=\"72\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"59\" y=\"72\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"42\" y=\"28\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"52\" y=\"28\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"62\" y=\"28\" width=\"5\" height=\"5\" rx=\".5\"/><path d=\"M37 88V76h17v12Z\"/></g><path d=\"M76 42h5m-5 15h5m-5 15h5\" stroke=\"currentColor\" opacity=\".8\"/><path d=\"M12 88h72v4H12Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"M12 88h72\" fill=\"none\" stroke=\"#40545a\" stroke-width=\"1.5\"/>",
	"<path d=\"m10 91 68 0 12-6-68-2Z\" fill=\"#273d46\" opacity=\".16\"/><path d=\"M19 88V37h10V26h10V15h20v11h10v11h10v51Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"M59 15v11h10v11h10v51H63V41H53V28h-4V15Z\" fill=\"#273d46\" opacity=\".22\"/><path d=\"M19 41h44m-38 9h31M24 78h40\" stroke=\"#40545a\" fill=\"none\" stroke-width=\"1.5\"/><g fill=\"#40545a\"><rect x=\"28\" y=\"48\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"39\" y=\"48\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"50\" y=\"48\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"28\" y=\"58\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"39\" y=\"58\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"50\" y=\"58\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"28\" y=\"68\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"39\" y=\"68\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"50\" y=\"68\" width=\"5\" height=\"5\" rx=\".5\"/><path d=\"M40 88V77h13v11Z\"/></g><path d=\"M40 13h18m-9-1V4\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M12 88h72v4H12Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"M12 88h72\" fill=\"none\" stroke=\"#40545a\" stroke-width=\"1.5\"/>",
	"<path d=\"m10 91 68 0 12-6-68-2Z\" fill=\"#273d46\" opacity=\".16\"/><path d=\"M12 88V50l15-18 15 18V29l8-12 8 12v21l15-18 14 18v38Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"m73 32 14 18v38H74V53L60 39v49H50V20l8 9v21Z\" fill=\"#273d46\" opacity=\".19\"/><path d=\"M12 52h30m16 0h29M42 33h16M14 78h62\" fill=\"none\" stroke=\"#40545a\" stroke-width=\"1.5\"/><g fill=\"#40545a\"><rect x=\"20\" y=\"58\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"32\" y=\"58\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"20\" y=\"70\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"32\" y=\"70\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"64\" y=\"58\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"74\" y=\"58\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"64\" y=\"70\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"74\" y=\"70\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"47\" y=\"40\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"47\" y=\"52\" width=\"5\" height=\"6\" rx=\".5\"/><path d=\"M43 88V72a6 6 0 0 1 12 0v16Z\"/></g><path d=\"M12 88h72v4H12Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"M12 88h72\" fill=\"none\" stroke=\"#40545a\" stroke-width=\"1.5\"/>",
	"<path d=\"m10 91 68 0 12-6-68-2Z\" fill=\"#273d46\" opacity=\".16\"/><path d=\"M13 88V47h10V30h13V19h29v11h11v17h10v41Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"M65 19v11h11v17h10v41H70V47H59V30H50V19Z\" fill=\"#273d46\" opacity=\".22\"/><path d=\"M33 22q17-22 34 0M11 49h65M27 35h43M15 79h58\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3\"/><g fill=\"#40545a\"><rect x=\"22\" y=\"54\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"32\" y=\"54\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"42\" y=\"54\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"52\" y=\"54\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"62\" y=\"54\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"22\" y=\"66\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"32\" y=\"66\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"42\" y=\"66\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"52\" y=\"66\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"62\" y=\"66\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"33\" y=\"36\" width=\"5\" height=\"7\" rx=\".5\"/><rect x=\"45\" y=\"36\" width=\"5\" height=\"7\" rx=\".5\"/><rect x=\"57\" y=\"36\" width=\"5\" height=\"7\" rx=\".5\"/><path d=\"M41 88V75h15v13Z\"/></g><path d=\"M13 49h57M24 33h43\" stroke=\"#40545a\" stroke-width=\"1.5\"/><path d=\"M12 88h72v4H12Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"M12 88h72\" fill=\"none\" stroke=\"#40545a\" stroke-width=\"1.5\"/>",
	"<path d=\"m10 91 68 0 12-6-68-2Z\" fill=\"#273d46\" opacity=\".16\"/><path d=\"M13 88V42h18V28h14V18h12v10h13v14h15v46Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"M57 18v10h13v14h15v46H71V46H58V33H51V18Z\" fill=\"#273d46\" opacity=\".22\"/><path d=\"M10 44h63M31 31h28M17 77h55\" fill=\"none\" stroke=\"#40545a\" stroke-width=\"2\"/><g fill=\"#40545a\"><rect x=\"20\" y=\"51\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"30\" y=\"51\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"40\" y=\"51\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"50\" y=\"51\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"60\" y=\"51\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"20\" y=\"64\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"30\" y=\"64\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"40\" y=\"64\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"50\" y=\"64\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"60\" y=\"64\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"36\" y=\"36\" width=\"5\" height=\"7\" rx=\".5\"/><rect x=\"48\" y=\"36\" width=\"5\" height=\"7\" rx=\".5\"/><path d=\"M40 88V73h14v15Z\"/></g><path d=\"M51 17V8m-6 2h12\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M12 88h72v4H12Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"M12 88h72\" fill=\"none\" stroke=\"#40545a\" stroke-width=\"1.5\"/>",
	"<path d=\"m10 91 68 0 12-6-68-2Z\" fill=\"#273d46\" opacity=\".16\"/><path d=\"M16 88V46l31-24 32 24v42Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"m47 22 32 24v42H66V50L42 29Z\" fill=\"#273d46\" opacity=\".21\"/><path d=\"m12 48 35-27 36 27M18 78h49\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3\"/><g fill=\"#40545a\"><rect x=\"25\" y=\"52\" width=\"6\" height=\"7\" rx=\".5\"/><rect x=\"39\" y=\"52\" width=\"6\" height=\"7\" rx=\".5\"/><rect x=\"53\" y=\"52\" width=\"6\" height=\"7\" rx=\".5\"/><rect x=\"25\" y=\"64\" width=\"6\" height=\"7\" rx=\".5\"/><rect x=\"39\" y=\"64\" width=\"6\" height=\"7\" rx=\".5\"/><rect x=\"53\" y=\"64\" width=\"6\" height=\"7\" rx=\".5\"/><path d=\"M40 88V73h14v15Z\"/></g><path d=\"M12 88h72v4H12Z\" fill=\"#e8dfc8\" stroke=\"#40545a\" stroke-width=\"1.25\"/><path d=\"M12 88h72\" fill=\"none\" stroke=\"#40545a\" stroke-width=\"1.5\"/>"
], ge = [
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\" opacity=\".35\"><path d=\"M130 126 18 126.00000000000001\"/><path d=\"M130 126 19.378905853344577 110.35655349597693\"/><path d=\"M130 126 23.481670174942792 95.09830056250527\"/><path d=\"M130 126 30.2072692909028 80.60095002604533\"/><path d=\"M130 126 39.390096630005885 67.2214747707527\"/><path d=\"M130 126 50.80404050710666 55.28932188134526\"/><path d=\"M130 126 64.168051743243 45.09830056250527\"/><path d=\"M130 126 79.15306402917074 36.89934758116323\"/><path d=\"M130 126 95.39009663000587 30.89434837048465\"/><path d=\"M130 126 112.47933991549412 27.231165940486235\"/><path d=\"M130 126 129.99999999999997 26\"/><path d=\"M130 126 147.52066008450583 27.23116594048622\"/><path d=\"M130 126 164.60990336999407 30.894348370484636\"/><path d=\"M130 126 180.84693597082924 36.8993475811632\"/><path d=\"M130 126 195.83194825675696 45.098300562505244\"/><path d=\"M130 126 209.1959594928933 55.28932188134523\"/><path d=\"M130 126 220.6099033699941 67.22147477075266\"/><path d=\"M130 126 229.79273070909719 80.6009500260453\"/><path d=\"M130 126 236.5183298250572 95.09830056250524\"/><path d=\"M130 126 240.62109414665542 110.35655349597688\"/><path d=\"M130 126 242 125.99999999999997\"/><path d=\"M24 177a107 107 0 1 1 212 0M28 177a103 103 0 1 1 204 0\"/></g><path d=\"m89 179 80 0 26-11V60l-15-9h-17V36h-19V21h-29v15H99v25H89Z\" fill=\"#ddd6bf\"/><path d=\"m169 179 26-11V60l-15-9h-17V36l-19-15v158Z\" fill=\"#c3c2b0\"/><g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.1\"><path d=\"M89 179V61h10V36h16V21h29v15h19v15h17l15 9v108l-26 11ZM99 61h64v118m-48-143v25m29-40v158m19-128v128M89 73h80m-80 30h80m-80 34h80M80 180h91l32-12v6l-32 13H80Zm-8 8h101l37-14v7l-37 14H72Z\"/><path d=\"M120 21V12h17v9m-8-9V3m0 0h25l-8 6h-17M115 43h26M92 164h66M105 73v88m35-88v88\"/></g><g fill=\"currentColor\"><path d=\"M96 80h4v7h-4Z\"/><path d=\"M111 80h4v7h-4Z\"/><path d=\"M126 80h4v7h-4Z\"/><path d=\"M141 80h4v7h-4Z\"/><path d=\"M96 93h4v7h-4Z\"/><path d=\"M111 93h4v7h-4Z\"/><path d=\"M126 93h4v7h-4Z\"/><path d=\"M141 93h4v7h-4Z\"/><path d=\"M96 106h4v7h-4Z\"/><path d=\"M111 106h4v7h-4Z\"/><path d=\"M126 106h4v7h-4Z\"/><path d=\"M141 106h4v7h-4Z\"/><path d=\"M96 119h4v7h-4Z\"/><path d=\"M111 119h4v7h-4Z\"/><path d=\"M126 119h4v7h-4Z\"/><path d=\"M141 119h4v7h-4Z\"/><path d=\"M96 132h4v7h-4Z\"/><path d=\"M111 132h4v7h-4Z\"/><path d=\"M126 132h4v7h-4Z\"/><path d=\"M141 132h4v7h-4Z\"/><path d=\"M96 145h4v7h-4Z\"/><path d=\"M111 145h4v7h-4Z\"/><path d=\"M126 145h4v7h-4Z\"/><path d=\"M141 145h4v7h-4Z\"/><path d=\"M120 30h4v7h-4Z\"/><path d=\"M132 30h4v7h-4Z\"/><path d=\"M120 44h4v7h-4Z\"/><path d=\"M132 44h4v7h-4Z\"/><path d=\"M119 179v-17a9 9 0 0 1 18 0v17Z\"/></g><g stroke=\"currentColor\" stroke-width=\".45\" fill=\"none\"><path d=\"m173 72 0 91\"/><path d=\"m174.5 72 0 91\"/><path d=\"m176 72 0 91\"/><path d=\"m177.5 72 0 91\"/><path d=\"m179 72 0 91\"/><path d=\"m180.5 72 0 91\"/><path d=\"m182 72 0 91\"/><path d=\"m183.5 72 0 91\"/><path d=\"m185 72 0 91\"/><path d=\"m186.5 72 0 91\"/><path d=\"m188 72 0 91\"/><path d=\"M84 203h110M63 209h148M50 215h173\"/></g><path d=\"M18 198q9-23 16-49m208 49q-9-23-16-49M20 191q-15-12-10-22 13 2 14 13m3-11q-15-11-9-20 12 4 12 12m210 28q15-12 10-22-13 2-14 13m-3-11q15-11 9-20-12 4-12 12\" stroke=\"currentColor\" stroke-width=\".8\" fill=\"none\"/>",
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\" opacity=\".35\"><path d=\"M130 126 18 126.00000000000001\"/><path d=\"M130 126 19.378905853344577 110.35655349597693\"/><path d=\"M130 126 23.481670174942792 95.09830056250527\"/><path d=\"M130 126 30.2072692909028 80.60095002604533\"/><path d=\"M130 126 39.390096630005885 67.2214747707527\"/><path d=\"M130 126 50.80404050710666 55.28932188134526\"/><path d=\"M130 126 64.168051743243 45.09830056250527\"/><path d=\"M130 126 79.15306402917074 36.89934758116323\"/><path d=\"M130 126 95.39009663000587 30.89434837048465\"/><path d=\"M130 126 112.47933991549412 27.231165940486235\"/><path d=\"M130 126 129.99999999999997 26\"/><path d=\"M130 126 147.52066008450583 27.23116594048622\"/><path d=\"M130 126 164.60990336999407 30.894348370484636\"/><path d=\"M130 126 180.84693597082924 36.8993475811632\"/><path d=\"M130 126 195.83194825675696 45.098300562505244\"/><path d=\"M130 126 209.1959594928933 55.28932188134523\"/><path d=\"M130 126 220.6099033699941 67.22147477075266\"/><path d=\"M130 126 229.79273070909719 80.6009500260453\"/><path d=\"M130 126 236.5183298250572 95.09830056250524\"/><path d=\"M130 126 240.62109414665542 110.35655349597688\"/><path d=\"M130 126 242 125.99999999999997\"/><path d=\"M24 177a107 107 0 1 1 212 0M28 177a103 103 0 1 1 204 0\"/></g><path d=\"M50 183V88l24-30 25 30V69l29-30 30 30v19l25-30 24 30v95Z\" fill=\"#e0d9c2\"/><path d=\"m183 58 24 30v95h-22V95l-28-26v114h-14V60l15 9v19Z\" fill=\"#c2c2b0\"/><g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.15\"><path d=\"M50 183V88l24-30 25 30V69l29-30 30 30v19l25-30 24 30v95ZM45 94h54m59 0h54M99 78h59M52 171h150M128 39V25M74 58V44m109 14V44M43 184h169v6H43Zm-8 7h186v7H35Z\"/><path d=\"M105 79v96m47-96v96M57 107h34m75 0h33M110 96h36M110 127h36M49 137h50m59 0h49M42 205h175M32 211h195\"/></g><g fill=\"currentColor\"><path d=\"M61 104h4v7h-4Z\"/><path d=\"M72 104h4v7h-4Z\"/><path d=\"M83 104h4v7h-4Z\"/><path d=\"M61 117h4v7h-4Z\"/><path d=\"M72 117h4v7h-4Z\"/><path d=\"M83 117h4v7h-4Z\"/><path d=\"M61 130h4v7h-4Z\"/><path d=\"M72 130h4v7h-4Z\"/><path d=\"M83 130h4v7h-4Z\"/><path d=\"M61 143h4v7h-4Z\"/><path d=\"M72 143h4v7h-4Z\"/><path d=\"M83 143h4v7h-4Z\"/><path d=\"M61 156h4v7h-4Z\"/><path d=\"M72 156h4v7h-4Z\"/><path d=\"M83 156h4v7h-4Z\"/><path d=\"M169 104h4v7h-4Z\"/><path d=\"M180 104h4v7h-4Z\"/><path d=\"M191 104h4v7h-4Z\"/><path d=\"M169 117h4v7h-4Z\"/><path d=\"M180 117h4v7h-4Z\"/><path d=\"M191 117h4v7h-4Z\"/><path d=\"M169 130h4v7h-4Z\"/><path d=\"M180 130h4v7h-4Z\"/><path d=\"M191 130h4v7h-4Z\"/><path d=\"M169 143h4v7h-4Z\"/><path d=\"M180 143h4v7h-4Z\"/><path d=\"M191 143h4v7h-4Z\"/><path d=\"M169 156h4v7h-4Z\"/><path d=\"M180 156h4v7h-4Z\"/><path d=\"M191 156h4v7h-4Z\"/><path d=\"M115 86h5v8h-5Z\"/><path d=\"M131 86h5v8h-5Z\"/><path d=\"M115 99h5v8h-5Z\"/><path d=\"M131 99h5v8h-5Z\"/><path d=\"M115 112h5v8h-5Z\"/><path d=\"M131 112h5v8h-5Z\"/><path d=\"M115 125h5v8h-5Z\"/><path d=\"M131 125h5v8h-5Z\"/><path d=\"M117 183v-21a11 11 0 0 1 22 0v21Z\"/></g><g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\"><path d=\"m187 105v64\"/><path d=\"m188.3 105v64\"/><path d=\"m189.6 105v64\"/><path d=\"m190.9 105v64\"/><path d=\"m192.2 105v64\"/><path d=\"m193.5 105v64\"/><path d=\"m194.8 105v64\"/><path d=\"m196.1 105v64\"/><path d=\"m197.4 105v64\"/><path d=\"m198.7 105v64\"/></g><path d=\"M18 198q9-23 16-49m208 49q-9-23-16-49M20 191q-15-12-10-22 13 2 14 13m3-11q-15-11-9-20 12 4 12 12m210 28q15-12 10-22-13 2-14 13m-3-11q15-11 9-20-12 4-12 12\" stroke=\"currentColor\" stroke-width=\".8\" fill=\"none\"/>",
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\" opacity=\".35\"><path d=\"M130 126 18 126.00000000000001\"/><path d=\"M130 126 19.378905853344577 110.35655349597693\"/><path d=\"M130 126 23.481670174942792 95.09830056250527\"/><path d=\"M130 126 30.2072692909028 80.60095002604533\"/><path d=\"M130 126 39.390096630005885 67.2214747707527\"/><path d=\"M130 126 50.80404050710666 55.28932188134526\"/><path d=\"M130 126 64.168051743243 45.09830056250527\"/><path d=\"M130 126 79.15306402917074 36.89934758116323\"/><path d=\"M130 126 95.39009663000587 30.89434837048465\"/><path d=\"M130 126 112.47933991549412 27.231165940486235\"/><path d=\"M130 126 129.99999999999997 26\"/><path d=\"M130 126 147.52066008450583 27.23116594048622\"/><path d=\"M130 126 164.60990336999407 30.894348370484636\"/><path d=\"M130 126 180.84693597082924 36.8993475811632\"/><path d=\"M130 126 195.83194825675696 45.098300562505244\"/><path d=\"M130 126 209.1959594928933 55.28932188134523\"/><path d=\"M130 126 220.6099033699941 67.22147477075266\"/><path d=\"M130 126 229.79273070909719 80.6009500260453\"/><path d=\"M130 126 236.5183298250572 95.09830056250524\"/><path d=\"M130 126 240.62109414665542 110.35655349597688\"/><path d=\"M130 126 242 125.99999999999997\"/><path d=\"M24 177a107 107 0 1 1 212 0M28 177a103 103 0 1 1 204 0\"/></g><g transform=\"translate(42 6) scale(2.2)\"><path d=\"m10 91 68 0 12-6-68-2Z\" fill=\"#132e29\" opacity=\".16\"/><path d=\"M11 88V37h25V21h37l13 12v55Z\" fill=\"#ded7c0\" stroke=\"currentColor\" stroke-width=\".75\"/><path d=\"m73 21 13 12v55H73Z\" fill=\"#172b25\" opacity=\".25\"/><path d=\"M10 38h26V22h37M13 52h59M13 67h59M13 80h59\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/><g fill=\"currentColor\"><rect x=\"19\" y=\"42\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"29\" y=\"42\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"39\" y=\"42\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"49\" y=\"42\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"59\" y=\"42\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"19\" y=\"57\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"29\" y=\"57\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"39\" y=\"57\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"49\" y=\"57\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"59\" y=\"57\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"19\" y=\"72\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"29\" y=\"72\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"39\" y=\"72\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"49\" y=\"72\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"59\" y=\"72\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"42\" y=\"28\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"52\" y=\"28\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"62\" y=\"28\" width=\"5\" height=\"5\" rx=\".5\"/><path d=\"M37 88V76h17v12Z\"/></g><path d=\"M76 42h5m-5 15h5m-5 15h5\" stroke=\"currentColor\" opacity=\".8\"/><path d=\"M12 88h72v4H12Z\" fill=\"#ded7c0\" stroke=\"currentColor\" stroke-width=\".75\"/><path d=\"M12 88h72\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"/></g><path d=\"M18 198q9-23 16-49m208 49q-9-23-16-49M20 191q-15-12-10-22 13 2 14 13m3-11q-15-11-9-20 12 4 12 12m210 28q15-12 10-22-13 2-14 13m-3-11q15-11 9-20-12 4-12 12\" stroke=\"currentColor\" stroke-width=\".8\" fill=\"none\"/>",
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\" opacity=\".35\"><path d=\"M130 126 18 126.00000000000001\"/><path d=\"M130 126 19.378905853344577 110.35655349597693\"/><path d=\"M130 126 23.481670174942792 95.09830056250527\"/><path d=\"M130 126 30.2072692909028 80.60095002604533\"/><path d=\"M130 126 39.390096630005885 67.2214747707527\"/><path d=\"M130 126 50.80404050710666 55.28932188134526\"/><path d=\"M130 126 64.168051743243 45.09830056250527\"/><path d=\"M130 126 79.15306402917074 36.89934758116323\"/><path d=\"M130 126 95.39009663000587 30.89434837048465\"/><path d=\"M130 126 112.47933991549412 27.231165940486235\"/><path d=\"M130 126 129.99999999999997 26\"/><path d=\"M130 126 147.52066008450583 27.23116594048622\"/><path d=\"M130 126 164.60990336999407 30.894348370484636\"/><path d=\"M130 126 180.84693597082924 36.8993475811632\"/><path d=\"M130 126 195.83194825675696 45.098300562505244\"/><path d=\"M130 126 209.1959594928933 55.28932188134523\"/><path d=\"M130 126 220.6099033699941 67.22147477075266\"/><path d=\"M130 126 229.79273070909719 80.6009500260453\"/><path d=\"M130 126 236.5183298250572 95.09830056250524\"/><path d=\"M130 126 240.62109414665542 110.35655349597688\"/><path d=\"M130 126 242 125.99999999999997\"/><path d=\"M24 177a107 107 0 1 1 212 0M28 177a103 103 0 1 1 204 0\"/></g><g transform=\"translate(42 6) scale(2.2)\"><path d=\"m10 91 68 0 12-6-68-2Z\" fill=\"#132e29\" opacity=\".16\"/><path d=\"M19 88V37h10V26h10V15h20v11h10v11h10v51Z\" fill=\"#ded7c0\" stroke=\"currentColor\" stroke-width=\".75\"/><path d=\"M59 15v11h10v11h10v51H63V41H53V28h-4V15Z\" fill=\"#172b25\" opacity=\".22\"/><path d=\"M19 41h44m-38 9h31M24 78h40\" stroke=\"currentColor\" fill=\"none\" stroke-width=\"1.5\"/><g fill=\"currentColor\"><rect x=\"28\" y=\"48\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"39\" y=\"48\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"50\" y=\"48\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"28\" y=\"58\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"39\" y=\"58\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"50\" y=\"58\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"28\" y=\"68\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"39\" y=\"68\" width=\"5\" height=\"5\" rx=\".5\"/><rect x=\"50\" y=\"68\" width=\"5\" height=\"5\" rx=\".5\"/><path d=\"M40 88V77h13v11Z\"/></g><path d=\"M40 13h18m-9-1V4\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M12 88h72v4H12Z\" fill=\"#ded7c0\" stroke=\"currentColor\" stroke-width=\".75\"/><path d=\"M12 88h72\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"/></g><path d=\"M18 198q9-23 16-49m208 49q-9-23-16-49M20 191q-15-12-10-22 13 2 14 13m3-11q-15-11-9-20 12 4 12 12m210 28q15-12 10-22-13 2-14 13m-3-11q15-11 9-20-12 4-12 12\" stroke=\"currentColor\" stroke-width=\".8\" fill=\"none\"/>",
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\" opacity=\".35\"><path d=\"M130 126 18 126.00000000000001\"/><path d=\"M130 126 19.378905853344577 110.35655349597693\"/><path d=\"M130 126 23.481670174942792 95.09830056250527\"/><path d=\"M130 126 30.2072692909028 80.60095002604533\"/><path d=\"M130 126 39.390096630005885 67.2214747707527\"/><path d=\"M130 126 50.80404050710666 55.28932188134526\"/><path d=\"M130 126 64.168051743243 45.09830056250527\"/><path d=\"M130 126 79.15306402917074 36.89934758116323\"/><path d=\"M130 126 95.39009663000587 30.89434837048465\"/><path d=\"M130 126 112.47933991549412 27.231165940486235\"/><path d=\"M130 126 129.99999999999997 26\"/><path d=\"M130 126 147.52066008450583 27.23116594048622\"/><path d=\"M130 126 164.60990336999407 30.894348370484636\"/><path d=\"M130 126 180.84693597082924 36.8993475811632\"/><path d=\"M130 126 195.83194825675696 45.098300562505244\"/><path d=\"M130 126 209.1959594928933 55.28932188134523\"/><path d=\"M130 126 220.6099033699941 67.22147477075266\"/><path d=\"M130 126 229.79273070909719 80.6009500260453\"/><path d=\"M130 126 236.5183298250572 95.09830056250524\"/><path d=\"M130 126 240.62109414665542 110.35655349597688\"/><path d=\"M130 126 242 125.99999999999997\"/><path d=\"M24 177a107 107 0 1 1 212 0M28 177a103 103 0 1 1 204 0\"/></g><g transform=\"translate(42 6) scale(2.2)\"><path d=\"m10 91 68 0 12-6-68-2Z\" fill=\"#132e29\" opacity=\".16\"/><path d=\"M12 88V50l15-18 15 18V29l8-12 8 12v21l15-18 14 18v38Z\" fill=\"#ded7c0\" stroke=\"currentColor\" stroke-width=\".75\"/><path d=\"m73 32 14 18v38H74V53L60 39v49H50V20l8 9v21Z\" fill=\"#172b25\" opacity=\".19\"/><path d=\"M12 52h30m16 0h29M42 33h16M14 78h62\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"/><g fill=\"currentColor\"><rect x=\"20\" y=\"58\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"32\" y=\"58\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"20\" y=\"70\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"32\" y=\"70\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"64\" y=\"58\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"74\" y=\"58\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"64\" y=\"70\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"74\" y=\"70\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"47\" y=\"40\" width=\"5\" height=\"6\" rx=\".5\"/><rect x=\"47\" y=\"52\" width=\"5\" height=\"6\" rx=\".5\"/><path d=\"M43 88V72a6 6 0 0 1 12 0v16Z\"/></g><path d=\"M12 88h72v4H12Z\" fill=\"#ded7c0\" stroke=\"currentColor\" stroke-width=\".75\"/><path d=\"M12 88h72\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"/></g><path d=\"M18 198q9-23 16-49m208 49q-9-23-16-49M20 191q-15-12-10-22 13 2 14 13m3-11q-15-11-9-20 12 4 12 12m210 28q15-12 10-22-13 2-14 13m-3-11q15-11 9-20-12 4-12 12\" stroke=\"currentColor\" stroke-width=\".8\" fill=\"none\"/>",
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\" opacity=\".35\"><path d=\"M130 126 18 126.00000000000001\"/><path d=\"M130 126 19.378905853344577 110.35655349597693\"/><path d=\"M130 126 23.481670174942792 95.09830056250527\"/><path d=\"M130 126 30.2072692909028 80.60095002604533\"/><path d=\"M130 126 39.390096630005885 67.2214747707527\"/><path d=\"M130 126 50.80404050710666 55.28932188134526\"/><path d=\"M130 126 64.168051743243 45.09830056250527\"/><path d=\"M130 126 79.15306402917074 36.89934758116323\"/><path d=\"M130 126 95.39009663000587 30.89434837048465\"/><path d=\"M130 126 112.47933991549412 27.231165940486235\"/><path d=\"M130 126 129.99999999999997 26\"/><path d=\"M130 126 147.52066008450583 27.23116594048622\"/><path d=\"M130 126 164.60990336999407 30.894348370484636\"/><path d=\"M130 126 180.84693597082924 36.8993475811632\"/><path d=\"M130 126 195.83194825675696 45.098300562505244\"/><path d=\"M130 126 209.1959594928933 55.28932188134523\"/><path d=\"M130 126 220.6099033699941 67.22147477075266\"/><path d=\"M130 126 229.79273070909719 80.6009500260453\"/><path d=\"M130 126 236.5183298250572 95.09830056250524\"/><path d=\"M130 126 240.62109414665542 110.35655349597688\"/><path d=\"M130 126 242 125.99999999999997\"/><path d=\"M24 177a107 107 0 1 1 212 0M28 177a103 103 0 1 1 204 0\"/></g><g transform=\"translate(42 6) scale(2.2)\"><path d=\"m10 91 68 0 12-6-68-2Z\" fill=\"#132e29\" opacity=\".16\"/><path d=\"M13 88V47h10V30h13V19h29v11h11v17h10v41Z\" fill=\"#ded7c0\" stroke=\"currentColor\" stroke-width=\".75\"/><path d=\"M65 19v11h11v17h10v41H70V47H59V30H50V19Z\" fill=\"#172b25\" opacity=\".22\"/><path d=\"M33 22q17-22 34 0M11 49h65M27 35h43M15 79h58\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3\"/><g fill=\"currentColor\"><rect x=\"22\" y=\"54\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"32\" y=\"54\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"42\" y=\"54\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"52\" y=\"54\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"62\" y=\"54\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"22\" y=\"66\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"32\" y=\"66\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"42\" y=\"66\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"52\" y=\"66\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"62\" y=\"66\" width=\"4\" height=\"6\" rx=\".5\"/><rect x=\"33\" y=\"36\" width=\"5\" height=\"7\" rx=\".5\"/><rect x=\"45\" y=\"36\" width=\"5\" height=\"7\" rx=\".5\"/><rect x=\"57\" y=\"36\" width=\"5\" height=\"7\" rx=\".5\"/><path d=\"M41 88V75h15v13Z\"/></g><path d=\"M13 49h57M24 33h43\" stroke=\"currentColor\" stroke-width=\"1.5\"/><path d=\"M12 88h72v4H12Z\" fill=\"#ded7c0\" stroke=\"currentColor\" stroke-width=\".75\"/><path d=\"M12 88h72\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"/></g><path d=\"M18 198q9-23 16-49m208 49q-9-23-16-49M20 191q-15-12-10-22 13 2 14 13m3-11q-15-11-9-20 12 4 12 12m210 28q15-12 10-22-13 2-14 13m-3-11q15-11 9-20-12 4-12 12\" stroke=\"currentColor\" stroke-width=\".8\" fill=\"none\"/>",
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\" opacity=\".35\"><path d=\"M130 126 18 126.00000000000001\"/><path d=\"M130 126 19.378905853344577 110.35655349597693\"/><path d=\"M130 126 23.481670174942792 95.09830056250527\"/><path d=\"M130 126 30.2072692909028 80.60095002604533\"/><path d=\"M130 126 39.390096630005885 67.2214747707527\"/><path d=\"M130 126 50.80404050710666 55.28932188134526\"/><path d=\"M130 126 64.168051743243 45.09830056250527\"/><path d=\"M130 126 79.15306402917074 36.89934758116323\"/><path d=\"M130 126 95.39009663000587 30.89434837048465\"/><path d=\"M130 126 112.47933991549412 27.231165940486235\"/><path d=\"M130 126 129.99999999999997 26\"/><path d=\"M130 126 147.52066008450583 27.23116594048622\"/><path d=\"M130 126 164.60990336999407 30.894348370484636\"/><path d=\"M130 126 180.84693597082924 36.8993475811632\"/><path d=\"M130 126 195.83194825675696 45.098300562505244\"/><path d=\"M130 126 209.1959594928933 55.28932188134523\"/><path d=\"M130 126 220.6099033699941 67.22147477075266\"/><path d=\"M130 126 229.79273070909719 80.6009500260453\"/><path d=\"M130 126 236.5183298250572 95.09830056250524\"/><path d=\"M130 126 240.62109414665542 110.35655349597688\"/><path d=\"M130 126 242 125.99999999999997\"/><path d=\"M24 177a107 107 0 1 1 212 0M28 177a103 103 0 1 1 204 0\"/></g><g transform=\"translate(42 6) scale(2.2)\"><path d=\"m10 91 68 0 12-6-68-2Z\" fill=\"#132e29\" opacity=\".16\"/><path d=\"M13 88V42h18V28h14V18h12v10h13v14h15v46Z\" fill=\"#ded7c0\" stroke=\"currentColor\" stroke-width=\".75\"/><path d=\"M57 18v10h13v14h15v46H71V46H58V33H51V18Z\" fill=\"#172b25\" opacity=\".22\"/><path d=\"M10 44h63M31 31h28M17 77h55\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/><g fill=\"currentColor\"><rect x=\"20\" y=\"51\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"30\" y=\"51\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"40\" y=\"51\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"50\" y=\"51\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"60\" y=\"51\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"20\" y=\"64\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"30\" y=\"64\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"40\" y=\"64\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"50\" y=\"64\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"60\" y=\"64\" width=\"4\" height=\"7\" rx=\".5\"/><rect x=\"36\" y=\"36\" width=\"5\" height=\"7\" rx=\".5\"/><rect x=\"48\" y=\"36\" width=\"5\" height=\"7\" rx=\".5\"/><path d=\"M40 88V73h14v15Z\"/></g><path d=\"M51 17V8m-6 2h12\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M12 88h72v4H12Z\" fill=\"#ded7c0\" stroke=\"currentColor\" stroke-width=\".75\"/><path d=\"M12 88h72\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"/></g><path d=\"M18 198q9-23 16-49m208 49q-9-23-16-49M20 191q-15-12-10-22 13 2 14 13m3-11q-15-11-9-20 12 4 12 12m210 28q15-12 10-22-13 2-14 13m-3-11q15-11 9-20-12 4-12 12\" stroke=\"currentColor\" stroke-width=\".8\" fill=\"none\"/>"
], _e = [
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\"><path d=\"M93.00,50.00L92.75,50.75L92.02,51.47L90.88,52.14L89.45,52.76L87.86,53.31L86.26,53.81L84.80,54.27L83.62,54.73L82.84,55.20L82.50,55.73L82.63,56.34L83.21,57.06L84.16,57.89L85.37,58.82L86.71,59.84L88.01,60.90L89.15,61.97L89.99,62.99L90.43,63.92L90.41,64.71L89.92,65.32L88.98,65.75L87.68,66.00L86.13,66.08L84.44,66.06L82.77,65.98L81.24,65.92L79.98,65.94L79.08,66.12L78.58,66.50L78.50,67.12L78.80,67.99L79.40,69.10L80.22,70.39L81.13,71.80L81.99,73.24L82.70,74.64L83.13,75.89L83.23,76.91L82.94,77.64L82.27,78.05L81.25,78.13L79.94,77.92L78.45,77.47L76.87,76.87L75.32,76.22L73.91,75.64L72.72,75.23L71.81,75.09L71.21,75.28L70.92,75.84L70.90,76.76L71.10,78.00L71.43,79.49L71.80,81.13L72.11,82.78L72.30,84.33L72.28,85.66L72.02,86.65L71.50,87.24L70.73,87.39L69.74,87.12L68.59,86.48L67.34,85.54L66.06,84.44L64.83,83.30L63.70,82.27L62.72,81.48L61.91,81.04L61.29,81.01L60.82,81.43L60.49,82.29L60.25,83.53L60.05,85.04L59.84,86.71L59.57,88.37L59.21,89.89L58.74,91.13L58.16,91.97L57.47,92.35L56.69,92.23L55.85,91.64L54.99,90.63L54.13,89.33L53.31,87.86L52.54,86.37L51.83,85.01L51.19,83.93L50.58,83.24L50.00,83.00L49.42,83.24L48.81,83.93L48.17,85.01L47.46,86.37L46.69,87.86L45.87,89.33L45.01,90.63L44.15,91.64L43.31,92.23L42.53,92.35L41.84,91.97L41.26,91.13L40.79,89.89L40.43,88.37L40.16,86.71L39.95,85.04L39.75,83.53L39.51,82.29L39.18,81.43L38.71,81.01L38.09,81.04L37.28,81.48L36.30,82.27L35.17,83.30L33.94,84.44L32.66,85.54L31.41,86.48L30.26,87.12L29.27,87.39L28.50,87.24L27.98,86.65L27.72,85.66L27.70,84.33L27.89,82.78L28.20,81.13L28.57,79.49L28.90,78.00L29.10,76.76L29.08,75.84L28.79,75.28L28.19,75.09L27.28,75.23L26.09,75.64L24.68,76.22L23.13,76.87L21.55,77.47L20.06,77.92L18.75,78.13L17.73,78.05L17.06,77.64L16.77,76.91L16.87,75.89L17.30,74.64L18.01,73.24L18.87,71.80L19.78,70.39L20.60,69.10L21.20,67.99L21.50,67.12L21.42,66.50L20.92,66.12L20.02,65.94L18.76,65.92L17.23,65.98L15.56,66.06L13.87,66.08L12.32,66.00L11.02,65.75L10.08,65.32L9.59,64.71L9.57,63.92L10.01,62.99L10.85,61.97L11.99,60.90L13.29,59.84L14.63,58.82L15.84,57.89L16.79,57.06L17.37,56.34L17.50,55.73L17.16,55.20L16.38,54.73L15.20,54.27L13.74,53.81L12.14,53.31L10.55,52.76L9.12,52.14L7.98,51.47L7.25,50.75L7.00,50.00L7.25,49.25L7.98,48.53L9.12,47.86L10.55,47.24L12.14,46.69L13.74,46.19L15.20,45.73L16.38,45.27L17.16,44.80L17.50,44.27L17.37,43.66L16.79,42.94L15.84,42.11L14.63,41.18L13.29,40.16L11.99,39.10L10.85,38.03L10.01,37.01L9.57,36.08L9.59,35.29L10.08,34.68L11.02,34.25L12.32,34.00L13.87,33.92L15.56,33.94L17.23,34.02L18.76,34.08L20.02,34.06L20.92,33.88L21.42,33.50L21.50,32.88L21.20,32.01L20.60,30.90L19.78,29.61L18.87,28.20L18.01,26.76L17.30,25.36L16.87,24.11L16.77,23.09L17.06,22.36L17.73,21.95L18.75,21.87L20.06,22.08L21.55,22.53L23.13,23.13L24.68,23.78L26.09,24.36L27.28,24.77L28.19,24.91L28.79,24.72L29.08,24.16L29.10,23.24L28.90,22.00L28.57,20.51L28.20,18.87L27.89,17.22L27.70,15.67L27.72,14.34L27.98,13.35L28.50,12.76L29.27,12.61L30.26,12.88L31.41,13.52L32.66,14.46L33.94,15.56L35.17,16.70L36.30,17.73L37.28,18.52L38.09,18.96L38.71,18.99L39.18,18.57L39.51,17.71L39.75,16.47L39.95,14.96L40.16,13.29L40.43,11.63L40.79,10.11L41.26,8.87L41.84,8.03L42.53,7.65L43.31,7.77L44.15,8.36L45.01,9.37L45.87,10.67L46.69,12.14L47.46,13.63L48.17,14.99L48.81,16.07L49.42,16.76L50.00,17.00L50.58,16.76L51.19,16.07L51.83,14.99L52.54,13.63L53.31,12.14L54.13,10.67L54.99,9.37L55.85,8.36L56.69,7.77L57.47,7.65L58.16,8.03L58.74,8.87L59.21,10.11L59.57,11.63L59.84,13.29L60.05,14.96L60.25,16.47L60.49,17.71L60.82,18.57L61.29,18.99L61.91,18.96L62.72,18.52L63.70,17.73L64.83,16.70L66.06,15.56L67.34,14.46L68.59,13.52L69.74,12.88L70.73,12.61L71.50,12.76L72.02,13.35L72.28,14.34L72.30,15.67L72.11,17.22L71.80,18.87L71.43,20.51L71.10,22.00L70.90,23.24L70.92,24.16L71.21,24.72L71.81,24.91L72.72,24.77L73.91,24.36L75.32,23.78L76.87,23.13L78.45,22.53L79.94,22.08L81.25,21.87L82.27,21.95L82.94,22.36L83.23,23.09L83.13,24.11L82.70,25.36L81.99,26.76L81.13,28.20L80.22,29.61L79.40,30.90L78.80,32.01L78.50,32.88L78.58,33.50L79.08,33.88L79.98,34.06L81.24,34.08L82.77,34.02L84.44,33.94L86.13,33.92L87.68,34.00L88.98,34.25L89.92,34.68L90.41,35.29L90.43,36.08L89.99,37.01L89.15,38.03L88.01,39.10L86.71,40.16L85.37,41.18L84.16,42.11L83.21,42.94L82.63,43.66L82.50,44.27L82.84,44.80L83.62,45.27L84.80,45.73L86.26,46.19L87.86,46.69L89.45,47.24L90.88,47.86L92.02,48.53L92.75,49.25L93.00,50.00Z\"/><path d=\"M89.60,50.00L88.42,50.67L87.03,51.29L85.57,51.86L84.17,52.39L82.97,52.88L82.09,53.37L81.61,53.88L81.56,54.44L81.93,55.06L82.69,55.76L83.74,56.56L84.97,57.43L86.23,58.36L87.40,59.33L88.35,60.28L88.96,61.17L89.16,61.97L88.93,62.65L88.26,63.17L87.22,63.55L85.88,63.77L84.36,63.88L82.78,63.92L81.29,63.93L80.00,63.99L79.01,64.15L78.38,64.46L78.14,64.96L78.28,65.68L78.75,66.60L79.46,67.70L80.32,68.94L81.19,70.25L81.96,71.56L82.52,72.77L82.79,73.82L82.71,74.65L82.26,75.20L81.45,75.47L80.34,75.46L79.00,75.21L77.54,74.79L76.05,74.29L74.64,73.79L73.41,73.41L72.42,73.21L71.72,73.29L71.32,73.68L71.21,74.40L71.34,75.43L71.63,76.71L72.01,78.17L72.38,79.70L72.66,81.19L72.77,82.52L72.66,83.60L72.30,84.35L71.69,84.71L70.84,84.69L69.80,84.30L68.63,83.61L67.40,82.72L66.17,81.73L65.02,80.79L63.99,80.00L63.13,79.48L62.44,79.31L61.94,79.55L61.59,80.18L61.35,81.19L61.19,82.50L61.05,84.00L60.87,85.56L60.63,87.05L60.28,88.35L59.80,89.32L59.21,89.90L58.51,90.04L57.72,89.72L56.88,89.00L56.01,87.96L55.16,86.69L54.34,85.35L53.58,84.06L52.88,82.97L52.25,82.19L51.67,81.80L51.11,81.85L50.56,82.33L50.00,83.20L49.40,84.37L48.75,85.73L48.05,87.13L47.31,88.45L46.54,89.55L45.76,90.31L45.01,90.65L44.30,90.53L43.67,89.97L43.12,89.00L42.67,87.72L42.30,86.24L41.99,84.70L41.71,83.23L41.43,81.97L41.10,81.02L40.69,80.46L40.15,80.31L39.47,80.57L38.65,81.19L37.68,82.09L36.61,83.14L35.47,84.23L34.32,85.22L33.22,85.98L32.23,86.43L31.41,86.49L30.78,86.14L30.38,85.39L30.20,84.30L30.21,82.94L30.36,81.42L30.60,79.87L30.85,78.40L31.01,77.11L31.03,76.11L30.83,75.43L30.38,75.11L29.65,75.13L28.66,75.43L27.45,75.94L26.08,76.57L24.64,77.20L23.22,77.73L21.93,78.07L20.85,78.15L20.05,77.93L19.58,77.39L19.46,76.55L19.66,75.46L20.14,74.18L20.80,72.81L21.56,71.43L22.29,70.13L22.89,68.99L23.25,68.05L23.29,67.34L22.97,66.89L22.29,66.65L21.25,66.60L19.94,66.66L18.44,66.78L16.87,66.88L15.35,66.90L14.02,66.78L12.98,66.48L12.30,66.00L12.05,65.33L12.22,64.50L12.78,63.55L13.67,62.51L14.76,61.45L15.94,60.41L17.07,59.44L18.03,58.57L18.69,57.81L18.97,57.16L18.83,56.63L18.26,56.17L17.31,55.76L16.05,55.38L14.60,54.97L13.09,54.53L11.66,54.03L10.45,53.46L9.57,52.83L9.10,52.14L9.09,51.43L9.54,50.71L10.40,50.00L11.58,49.33L12.97,48.71L14.43,48.14L15.83,47.61L17.03,47.12L17.91,46.63L18.39,46.12L18.44,45.56L18.07,44.94L17.31,44.24L16.26,43.44L15.03,42.57L13.77,41.64L12.60,40.67L11.65,39.72L11.04,38.83L10.84,38.03L11.07,37.35L11.74,36.83L12.78,36.45L14.12,36.23L15.64,36.12L17.22,36.08L18.71,36.07L20.00,36.01L20.99,35.85L21.62,35.54L21.86,35.04L21.72,34.32L21.25,33.40L20.54,32.30L19.68,31.06L18.81,29.75L18.04,28.44L17.48,27.23L17.21,26.18L17.29,25.35L17.74,24.80L18.55,24.53L19.66,24.54L21.00,24.79L22.46,25.21L23.95,25.71L25.36,26.21L26.59,26.59L27.58,26.79L28.28,26.71L28.68,26.32L28.79,25.60L28.66,24.57L28.37,23.29L27.99,21.83L27.62,20.30L27.34,18.81L27.23,17.48L27.34,16.40L27.70,15.65L28.31,15.29L29.16,15.31L30.20,15.70L31.37,16.39L32.60,17.28L33.83,18.27L34.98,19.21L36.01,20.00L36.87,20.52L37.56,20.69L38.06,20.45L38.41,19.82L38.65,18.81L38.81,17.50L38.95,16.00L39.13,14.44L39.37,12.95L39.72,11.65L40.20,10.68L40.79,10.10L41.49,9.96L42.28,10.28L43.12,11.00L43.99,12.04L44.84,13.31L45.66,14.65L46.42,15.94L47.12,17.03L47.75,17.81L48.33,18.20L48.89,18.15L49.44,17.67L50.00,16.80L50.60,15.63L51.25,14.27L51.95,12.87L52.69,11.55L53.46,10.45L54.24,9.69L54.99,9.35L55.70,9.47L56.33,10.03L56.88,11.00L57.33,12.28L57.70,13.76L58.01,15.30L58.29,16.77L58.57,18.03L58.90,18.98L59.31,19.54L59.85,19.69L60.53,19.43L61.35,18.81L62.32,17.91L63.39,16.86L64.53,15.77L65.68,14.78L66.78,14.02L67.77,13.57L68.59,13.51L69.22,13.86L69.62,14.61L69.80,15.70L69.79,17.06L69.64,18.58L69.40,20.13L69.15,21.60L68.99,22.89L68.97,23.89L69.17,24.57L69.62,24.89L70.35,24.87L71.34,24.57L72.55,24.06L73.92,23.43L75.36,22.80L76.78,22.27L78.07,21.93L79.15,21.85L79.95,22.07L80.42,22.61L80.54,23.45L80.34,24.54L79.86,25.82L79.20,27.19L78.44,28.57L77.71,29.87L77.11,31.01L76.75,31.95L76.71,32.66L77.03,33.11L77.71,33.35L78.75,33.40L80.06,33.34L81.56,33.22L83.13,33.12L84.65,33.10L85.98,33.22L87.02,33.52L87.70,34.00L87.95,34.67L87.78,35.50L87.22,36.45L86.33,37.49L85.24,38.55L84.06,39.59L82.93,40.56L81.97,41.43L81.31,42.19L81.03,42.84L81.17,43.37L81.74,43.83L82.69,44.24L83.95,44.62L85.40,45.03L86.91,45.47L88.34,45.97L89.55,46.54L90.43,47.17L90.90,47.86L90.91,48.57L90.46,49.29L89.60,50.00Z\"/><path d=\"M84.68,50.00L83.38,50.58L82.21,51.12L81.29,51.64L80.69,52.15L80.49,52.67L80.68,53.22L81.24,53.84L82.12,54.51L83.21,55.26L84.39,56.06L85.55,56.91L86.55,57.77L87.29,58.61L87.68,59.39L87.67,60.09L87.25,60.68L86.46,61.15L85.35,61.49L84.02,61.71L82.59,61.86L81.17,61.96L79.89,62.07L78.84,62.24L78.11,62.52L77.73,62.93L77.72,63.52L78.05,64.29L78.64,65.23L79.40,66.30L80.24,67.46L81.04,68.65L81.69,69.80L82.09,70.84L82.19,71.71L81.95,72.37L81.35,72.78L80.45,72.94L79.29,72.88L77.96,72.64L76.56,72.29L75.20,71.90L73.95,71.57L72.91,71.37L72.13,71.37L71.64,71.64L71.43,72.19L71.47,73.02L71.70,74.10L72.06,75.37L72.45,76.75L72.79,78.14L73.01,79.45L73.03,80.56L72.82,81.41L72.37,81.95L71.67,82.13L70.76,81.97L69.70,81.52L68.53,80.84L67.34,80.03L66.19,79.20L65.13,78.46L64.22,77.92L63.49,77.66L62.93,77.73L62.55,78.18L62.30,78.97L62.15,80.07L62.05,81.39L61.94,82.82L61.79,84.24L61.55,85.54L61.19,86.60L60.70,87.33L60.09,87.67L59.38,87.60L58.58,87.15L57.73,86.36L56.87,85.32L56.02,84.15L55.22,82.98L54.49,81.92L53.82,81.10L53.22,80.60L52.67,80.49L52.15,80.77L51.65,81.43L51.13,82.41L50.59,83.61L50.00,84.92L49.37,86.21L48.70,87.34L48.00,88.22L47.29,88.74L46.60,88.85L45.95,88.54L45.35,87.84L44.83,86.81L44.37,85.54L43.98,84.15L43.63,82.77L43.30,81.53L42.95,80.53L42.56,79.86L42.08,79.56L41.50,79.65L40.80,80.10L39.98,80.84L39.05,81.79L38.06,82.82L37.02,83.81L36.00,84.65L35.05,85.23L34.21,85.47L33.52,85.34L33.01,84.83L32.69,83.97L32.55,82.82L32.56,81.47L32.66,80.03L32.80,78.62L32.92,77.34L32.94,76.28L32.79,75.51L32.45,75.07L31.87,74.95L31.06,75.14L30.03,75.56L28.84,76.13L27.55,76.75L26.24,77.33L25.00,77.77L23.90,77.99L23.03,77.93L22.42,77.58L22.12,76.92L22.12,76.00L22.38,74.87L22.85,73.61L23.44,72.29L24.05,71.01L24.60,69.84L24.98,68.86L25.11,68.09L24.93,67.55L24.43,67.25L23.60,67.14L22.50,67.19L21.18,67.32L19.76,67.46L18.33,67.56L17.01,67.54L15.90,67.37L15.10,67.02L14.66,66.48L14.60,65.76L14.91,64.90L15.54,63.92L16.41,62.89L17.41,61.86L18.43,60.87L19.34,59.96L20.04,59.16L20.42,58.48L20.44,57.92L20.07,57.46L19.33,57.08L18.28,56.74L17.00,56.41L15.61,56.06L14.23,55.67L13.00,55.20L12.02,54.66L11.38,54.06L11.15,53.40L11.34,52.70L11.93,52.00L12.85,51.30L14.02,50.63L15.32,50.00L16.62,49.42L17.79,48.88L18.71,48.36L19.31,47.85L19.51,47.33L19.32,46.78L18.76,46.16L17.88,45.49L16.79,44.74L15.61,43.94L14.45,43.09L13.45,42.23L12.71,41.39L12.32,40.61L12.33,39.91L12.75,39.32L13.54,38.85L14.65,38.51L15.98,38.29L17.41,38.14L18.83,38.04L20.11,37.93L21.16,37.76L21.89,37.48L22.27,37.07L22.28,36.48L21.95,35.71L21.36,34.77L20.60,33.70L19.76,32.54L18.96,31.35L18.31,30.20L17.91,29.16L17.81,28.29L18.05,27.63L18.65,27.22L19.55,27.06L20.71,27.12L22.04,27.36L23.44,27.71L24.80,28.10L26.05,28.43L27.09,28.63L27.87,28.63L28.36,28.36L28.57,27.81L28.53,26.98L28.30,25.90L27.94,24.63L27.55,23.25L27.21,21.86L26.99,20.55L26.97,19.44L27.18,18.59L27.63,18.05L28.33,17.87L29.24,18.03L30.30,18.48L31.47,19.16L32.66,19.97L33.81,20.80L34.87,21.54L35.78,22.08L36.51,22.34L37.07,22.27L37.45,21.82L37.70,21.03L37.85,19.93L37.95,18.61L38.06,17.18L38.21,15.76L38.45,14.46L38.81,13.40L39.30,12.67L39.91,12.33L40.62,12.40L41.42,12.85L42.27,13.64L43.13,14.68L43.98,15.85L44.78,17.02L45.51,18.08L46.18,18.90L46.78,19.40L47.33,19.51L47.85,19.23L48.35,18.57L48.87,17.59L49.41,16.39L50.00,15.08L50.63,13.79L51.30,12.66L52.00,11.78L52.71,11.26L53.40,11.15L54.05,11.46L54.65,12.16L55.17,13.19L55.63,14.46L56.02,15.85L56.37,17.23L56.70,18.47L57.05,19.47L57.44,20.14L57.92,20.44L58.50,20.35L59.20,19.90L60.02,19.16L60.95,18.21L61.94,17.18L62.98,16.19L64.00,15.35L64.95,14.77L65.79,14.53L66.48,14.66L66.99,15.17L67.31,16.03L67.45,17.18L67.44,18.53L67.34,19.97L67.20,21.38L67.08,22.66L67.06,23.72L67.21,24.49L67.55,24.93L68.13,25.05L68.94,24.86L69.97,24.44L71.16,23.87L72.45,23.25L73.76,22.67L75.00,22.23L76.10,22.01L76.97,22.07L77.58,22.42L77.88,23.08L77.88,24.00L77.62,25.13L77.15,26.39L76.56,27.71L75.95,28.99L75.40,30.16L75.02,31.14L74.89,31.91L75.07,32.45L75.57,32.75L76.40,32.86L77.50,32.81L78.82,32.68L80.24,32.54L81.67,32.44L82.99,32.46L84.10,32.63L84.90,32.98L85.34,33.52L85.40,34.24L85.09,35.10L84.46,36.08L83.59,37.11L82.59,38.14L81.57,39.13L80.66,40.04L79.96,40.84L79.58,41.52L79.56,42.08L79.93,42.54L80.67,42.92L81.72,43.26L83.00,43.59L84.39,43.94L85.77,44.33L87.00,44.80L87.98,45.34L88.62,45.94L88.85,46.60L88.66,47.30L88.07,48.00L87.15,48.70L85.98,49.37L84.68,50.00Z\"/><path d=\"M80.40,50.00L79.74,50.52L79.41,51.03L79.44,51.54L79.82,52.09L80.52,52.67L81.45,53.31L82.53,53.99L83.63,54.73L84.64,55.49L85.46,56.25L85.98,56.99L86.17,57.69L85.98,58.31L85.42,58.83L84.55,59.26L83.43,59.59L82.16,59.83L80.85,60.03L79.62,60.20L78.56,60.40L77.77,60.66L77.28,61.02L77.13,61.52L77.31,62.16L77.76,62.95L78.42,63.86L79.20,64.88L79.98,65.94L80.67,67.00L81.18,68.00L81.42,68.88L81.36,69.59L80.97,70.11L80.27,70.41L79.30,70.51L78.13,70.44L76.86,70.24L75.56,69.97L74.35,69.72L73.29,69.54L72.45,69.51L71.87,69.69L71.56,70.10L71.50,70.77L71.66,71.66L71.97,72.75L72.35,73.97L72.72,75.24L73.01,76.47L73.14,77.58L73.07,78.49L72.76,79.14L72.22,79.49L71.46,79.53L70.51,79.30L69.45,78.83L68.32,78.20L67.19,77.51L66.14,76.85L65.20,76.33L64.42,76.01L63.81,75.98L63.38,76.26L63.10,76.87L62.95,77.76L62.86,78.89L62.80,80.17L62.72,81.49L62.57,82.74L62.31,83.83L61.93,84.66L61.43,85.17L60.80,85.31L60.06,85.09L59.26,84.55L58.41,83.74L57.56,82.77L56.75,81.73L55.98,80.75L55.28,79.94L54.65,79.38L54.10,79.14L53.59,79.26L53.12,79.73L52.67,80.52L52.21,81.55L51.72,82.73L51.19,83.94L50.61,85.07L50.00,86.00L49.36,86.65L48.71,86.95L48.07,86.87L47.45,86.42L46.88,85.63L46.36,84.58L45.90,83.38L45.48,82.13L45.10,80.94L44.72,79.94L44.32,79.20L43.88,78.78L43.37,78.72L42.77,79.01L42.07,79.59L41.28,80.40L40.42,81.34L39.51,82.30L38.58,83.16L37.69,83.83L36.86,84.22L36.15,84.28L35.57,83.99L35.15,83.35L34.88,82.42L34.76,81.26L34.73,79.96L34.77,78.64L34.81,77.40L34.80,76.33L34.68,75.49L34.41,74.95L33.95,74.72L33.28,74.78L32.43,75.09L31.41,75.58L30.28,76.17L29.09,76.76L27.93,77.26L26.86,77.58L25.95,77.67L25.26,77.48L24.82,77.00L24.64,76.26L24.71,75.29L24.98,74.16L25.40,72.94L25.89,71.71L26.36,70.55L26.71,69.54L26.89,68.72L26.81,68.12L26.46,67.74L25.82,67.57L24.91,67.57L23.78,67.68L22.52,67.85L21.20,68.00L19.94,68.06L18.82,68.00L17.94,67.77L17.35,67.36L17.10,66.76L17.19,66.00L17.58,65.12L18.23,64.14L19.04,63.14L19.92,62.15L20.75,61.23L21.44,60.40L21.88,59.68L22.02,59.09L21.81,58.62L21.27,58.24L20.41,57.93L19.31,57.65L18.07,57.37L16.78,57.06L15.57,56.69L14.54,56.25L13.79,55.73L13.38,55.15L13.35,54.50L13.69,53.82L14.37,53.12L15.31,52.43L16.42,51.76L17.58,51.13L18.68,50.55L19.60,50.00L20.26,49.48L20.59,48.97L20.56,48.46L20.18,47.91L19.48,47.33L18.55,46.69L17.47,46.01L16.37,45.27L15.36,44.51L14.54,43.75L14.02,43.01L13.83,42.31L14.02,41.69L14.58,41.17L15.45,40.74L16.57,40.41L17.84,40.17L19.15,39.97L20.38,39.80L21.44,39.60L22.23,39.34L22.72,38.98L22.87,38.48L22.69,37.84L22.24,37.05L21.58,36.14L20.80,35.12L20.02,34.06L19.33,33.00L18.82,32.00L18.58,31.12L18.64,30.41L19.03,29.89L19.73,29.59L20.70,29.49L21.87,29.56L23.14,29.76L24.44,30.03L25.65,30.28L26.71,30.46L27.55,30.49L28.13,30.31L28.44,29.90L28.50,29.23L28.34,28.34L28.03,27.25L27.65,26.03L27.28,24.76L26.99,23.53L26.86,22.42L26.93,21.51L27.24,20.86L27.78,20.51L28.54,20.47L29.49,20.70L30.55,21.17L31.68,21.80L32.81,22.49L33.86,23.15L34.80,23.67L35.58,23.99L36.19,24.02L36.62,23.74L36.90,23.13L37.05,22.24L37.14,21.11L37.20,19.83L37.28,18.51L37.43,17.26L37.69,16.17L38.07,15.34L38.57,14.83L39.20,14.69L39.94,14.91L40.74,15.45L41.59,16.26L42.44,17.23L43.25,18.27L44.02,19.25L44.72,20.06L45.35,20.62L45.90,20.86L46.41,20.74L46.88,20.27L47.33,19.48L47.79,18.45L48.28,17.27L48.81,16.06L49.39,14.93L50.00,14.00L50.64,13.35L51.29,13.05L51.93,13.13L52.55,13.58L53.12,14.37L53.64,15.42L54.10,16.62L54.52,17.87L54.90,19.06L55.28,20.06L55.68,20.80L56.12,21.22L56.63,21.28L57.23,20.99L57.93,20.41L58.72,19.60L59.58,18.66L60.49,17.70L61.42,16.84L62.31,16.17L63.14,15.78L63.85,15.72L64.43,16.01L64.85,16.65L65.12,17.58L65.24,18.74L65.27,20.04L65.23,21.36L65.19,22.60L65.20,23.67L65.32,24.51L65.59,25.05L66.05,25.28L66.72,25.22L67.57,24.91L68.59,24.42L69.72,23.83L70.91,23.24L72.07,22.74L73.14,22.42L74.05,22.33L74.74,22.52L75.18,23.00L75.36,23.74L75.29,24.71L75.02,25.84L74.60,27.06L74.11,28.29L73.64,29.45L73.29,30.46L73.11,31.28L73.19,31.88L73.54,32.26L74.18,32.43L75.09,32.43L76.22,32.32L77.48,32.15L78.80,32.00L80.06,31.94L81.18,32.00L82.06,32.23L82.65,32.64L82.90,33.24L82.81,34.00L82.42,34.88L81.77,35.86L80.96,36.86L80.08,37.85L79.25,38.77L78.56,39.60L78.12,40.32L77.98,40.91L78.19,41.38L78.73,41.76L79.59,42.07L80.69,42.35L81.93,42.63L83.22,42.94L84.43,43.31L85.46,43.75L86.21,44.27L86.62,44.85L86.65,45.50L86.31,46.18L85.63,46.88L84.69,47.57L83.58,48.24L82.42,48.87L81.32,49.45L80.40,50.00Z\"/><path d=\"M78.21,50.00L78.43,50.50L78.95,51.01L79.72,51.56L80.67,52.14L81.68,52.77L82.66,53.43L83.50,54.11L84.13,54.80L84.46,55.46L84.46,56.08L84.13,56.63L83.48,57.12L82.58,57.52L81.50,57.85L80.33,58.13L79.19,58.37L78.16,58.61L77.33,58.88L76.77,59.22L76.50,59.65L76.54,60.19L76.86,60.85L77.40,61.63L78.08,62.50L78.82,63.44L79.51,64.40L80.08,65.32L80.43,66.18L80.51,66.91L80.31,67.50L79.80,67.91L79.03,68.14L78.04,68.21L76.91,68.15L75.72,68.01L74.56,67.85L73.52,67.72L72.65,67.69L72.00,67.82L71.61,68.13L71.46,68.65L71.53,69.39L71.77,70.30L72.11,71.35L72.48,72.48L72.81,73.62L73.02,74.69L73.06,75.61L72.89,76.33L72.49,76.81L71.88,77.02L71.07,76.97L70.12,76.70L69.08,76.26L68.01,75.72L66.98,75.17L66.04,74.69L65.23,74.37L64.58,74.27L64.10,74.43L63.78,74.87L63.60,75.58L63.51,76.52L63.48,77.63L63.44,78.82L63.36,80.00L63.19,81.07L62.91,81.95L62.50,82.57L61.97,82.88L61.32,82.87L60.58,82.55L59.78,81.97L58.95,81.20L58.13,80.33L57.35,79.46L56.62,78.69L55.97,78.11L55.40,77.79L54.90,77.78L54.45,78.08L54.03,78.69L53.63,79.54L53.21,80.57L52.77,81.68L52.29,82.76L51.77,83.71L51.20,84.44L50.61,84.88L50.00,84.99L49.39,84.76L48.81,84.21L48.25,83.39L47.74,82.38L47.26,81.28L46.83,80.20L46.41,79.22L46.00,78.46L45.57,77.96L45.10,77.78L44.57,77.91L43.98,78.34L43.30,79.00L42.56,79.83L41.77,80.71L40.95,81.57L40.13,82.28L39.35,82.78L38.64,82.99L38.03,82.88L37.54,82.46L37.18,81.74L36.94,80.78L36.80,79.65L36.73,78.46L36.69,77.29L36.63,76.24L36.51,75.37L36.27,74.76L35.90,74.43L35.36,74.37L34.65,74.57L33.79,74.96L32.81,75.48L31.76,76.05L30.70,76.57L29.69,76.96L28.78,77.16L28.04,77.11L27.51,76.81L27.19,76.24L27.10,75.44L27.20,74.45L27.45,73.35L27.80,72.20L28.16,71.09L28.47,70.08L28.64,69.23L28.63,68.57L28.39,68.13L27.90,67.89L27.17,67.84L26.23,67.91L25.13,68.07L23.95,68.24L22.78,68.36L21.69,68.38L20.77,68.26L20.09,67.97L19.69,67.50L19.59,66.86L19.78,66.07L20.21,65.18L20.83,64.23L21.54,63.27L22.26,62.35L22.90,61.50L23.36,60.77L23.57,60.15L23.50,59.65L23.12,59.26L22.45,58.95L21.54,58.70L20.45,58.47L19.29,58.23L18.14,57.94L17.11,57.59L16.29,57.17L15.75,56.66L15.54,56.08L15.66,55.44L16.10,54.76L16.81,54.07L17.72,53.39L18.72,52.74L19.71,52.12L20.60,51.54L21.28,51.00L21.69,50.49L21.79,50.00L21.57,49.50L21.05,48.99L20.28,48.44L19.33,47.86L18.32,47.23L17.34,46.57L16.50,45.89L15.87,45.20L15.54,44.54L15.54,43.92L15.87,43.37L16.52,42.88L17.42,42.48L18.50,42.15L19.67,41.87L20.81,41.63L21.84,41.39L22.67,41.12L23.23,40.78L23.50,40.35L23.46,39.81L23.14,39.15L22.60,38.37L21.92,37.50L21.18,36.56L20.49,35.60L19.92,34.68L19.57,33.82L19.49,33.09L19.69,32.50L20.20,32.09L20.97,31.86L21.96,31.79L23.09,31.85L24.28,31.99L25.44,32.15L26.48,32.28L27.35,32.31L28.00,32.18L28.39,31.87L28.54,31.35L28.47,30.61L28.23,29.70L27.89,28.65L27.52,27.52L27.19,26.38L26.98,25.31L26.94,24.39L27.11,23.67L27.51,23.19L28.12,22.98L28.93,23.03L29.88,23.30L30.92,23.74L31.99,24.28L33.02,24.83L33.96,25.31L34.77,25.63L35.42,25.73L35.90,25.57L36.22,25.13L36.40,24.42L36.49,23.48L36.52,22.37L36.56,21.18L36.64,20.00L36.81,18.93L37.09,18.05L37.50,17.43L38.03,17.12L38.68,17.13L39.42,17.45L40.22,18.03L41.05,18.80L41.87,19.67L42.65,20.54L43.38,21.31L44.03,21.89L44.60,22.21L45.10,22.22L45.55,21.92L45.97,21.31L46.37,20.46L46.79,19.43L47.23,18.32L47.71,17.24L48.23,16.29L48.80,15.56L49.39,15.12L50.00,15.01L50.61,15.24L51.19,15.79L51.75,16.61L52.26,17.62L52.74,18.72L53.17,19.80L53.59,20.78L54.00,21.54L54.43,22.04L54.90,22.22L55.43,22.09L56.02,21.66L56.70,21.00L57.44,20.17L58.23,19.29L59.05,18.43L59.87,17.72L60.65,17.22L61.36,17.01L61.97,17.12L62.46,17.54L62.82,18.26L63.06,19.22L63.20,20.35L63.27,21.54L63.31,22.71L63.37,23.76L63.49,24.63L63.73,25.24L64.10,25.57L64.64,25.63L65.35,25.43L66.21,25.04L67.19,24.52L68.24,23.95L69.30,23.43L70.31,23.04L71.22,22.84L71.96,22.89L72.49,23.19L72.81,23.76L72.90,24.56L72.80,25.55L72.55,26.65L72.20,27.80L71.84,28.91L71.53,29.92L71.36,30.77L71.37,31.43L71.61,31.87L72.10,32.11L72.83,32.16L73.77,32.09L74.87,31.93L76.05,31.76L77.22,31.64L78.31,31.62L79.23,31.74L79.91,32.03L80.31,32.50L80.41,33.14L80.22,33.93L79.79,34.82L79.17,35.77L78.46,36.73L77.74,37.65L77.10,38.50L76.64,39.23L76.43,39.85L76.50,40.35L76.88,40.74L77.55,41.05L78.46,41.30L79.55,41.53L80.71,41.77L81.86,42.06L82.89,42.41L83.71,42.83L84.25,43.34L84.46,43.92L84.34,44.56L83.90,45.24L83.19,45.93L82.28,46.61L81.28,47.26L80.29,47.88L79.40,48.46L78.72,49.00L78.31,49.51L78.21,50.00Z\"/><circle cx=\"50\" cy=\"50\" r=\"28\" stroke-width=\".8\"/><circle cx=\"50\" cy=\"50\" r=\"25.5\" stroke-width=\".45\"/></g><g transform=\"translate(23 23) scale(.54)\" fill=\"currentColor\" style=\"--seal-paper:var(--ex-paper)\"><path d=\"M27 33V19h10v7h9V15h10v11h9v-7h9v14l-6 4v39H33V37Z\" fill=\"currentColor\"/>\n   <path d=\"M38 73V40h25v33M43 41v10m13-10v10m-6-23V9m0 0h19l-6 5H50\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3\"/>\n   <path d=\"M45 77V65a6 6 0 0 1 12 0v12M41 36h19M38 55h25\" fill=\"none\" stroke=\"var(--seal-paper)\" stroke-width=\"2.5\"/>\n   <path d=\"M24 81h53m-50 5h47\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/></g>",
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\"><path d=\"M93.00,50.00L92.75,50.75L92.02,51.47L90.88,52.14L89.45,52.76L87.86,53.31L86.26,53.81L84.80,54.27L83.62,54.73L82.84,55.20L82.50,55.73L82.63,56.34L83.21,57.06L84.16,57.89L85.37,58.82L86.71,59.84L88.01,60.90L89.15,61.97L89.99,62.99L90.43,63.92L90.41,64.71L89.92,65.32L88.98,65.75L87.68,66.00L86.13,66.08L84.44,66.06L82.77,65.98L81.24,65.92L79.98,65.94L79.08,66.12L78.58,66.50L78.50,67.12L78.80,67.99L79.40,69.10L80.22,70.39L81.13,71.80L81.99,73.24L82.70,74.64L83.13,75.89L83.23,76.91L82.94,77.64L82.27,78.05L81.25,78.13L79.94,77.92L78.45,77.47L76.87,76.87L75.32,76.22L73.91,75.64L72.72,75.23L71.81,75.09L71.21,75.28L70.92,75.84L70.90,76.76L71.10,78.00L71.43,79.49L71.80,81.13L72.11,82.78L72.30,84.33L72.28,85.66L72.02,86.65L71.50,87.24L70.73,87.39L69.74,87.12L68.59,86.48L67.34,85.54L66.06,84.44L64.83,83.30L63.70,82.27L62.72,81.48L61.91,81.04L61.29,81.01L60.82,81.43L60.49,82.29L60.25,83.53L60.05,85.04L59.84,86.71L59.57,88.37L59.21,89.89L58.74,91.13L58.16,91.97L57.47,92.35L56.69,92.23L55.85,91.64L54.99,90.63L54.13,89.33L53.31,87.86L52.54,86.37L51.83,85.01L51.19,83.93L50.58,83.24L50.00,83.00L49.42,83.24L48.81,83.93L48.17,85.01L47.46,86.37L46.69,87.86L45.87,89.33L45.01,90.63L44.15,91.64L43.31,92.23L42.53,92.35L41.84,91.97L41.26,91.13L40.79,89.89L40.43,88.37L40.16,86.71L39.95,85.04L39.75,83.53L39.51,82.29L39.18,81.43L38.71,81.01L38.09,81.04L37.28,81.48L36.30,82.27L35.17,83.30L33.94,84.44L32.66,85.54L31.41,86.48L30.26,87.12L29.27,87.39L28.50,87.24L27.98,86.65L27.72,85.66L27.70,84.33L27.89,82.78L28.20,81.13L28.57,79.49L28.90,78.00L29.10,76.76L29.08,75.84L28.79,75.28L28.19,75.09L27.28,75.23L26.09,75.64L24.68,76.22L23.13,76.87L21.55,77.47L20.06,77.92L18.75,78.13L17.73,78.05L17.06,77.64L16.77,76.91L16.87,75.89L17.30,74.64L18.01,73.24L18.87,71.80L19.78,70.39L20.60,69.10L21.20,67.99L21.50,67.12L21.42,66.50L20.92,66.12L20.02,65.94L18.76,65.92L17.23,65.98L15.56,66.06L13.87,66.08L12.32,66.00L11.02,65.75L10.08,65.32L9.59,64.71L9.57,63.92L10.01,62.99L10.85,61.97L11.99,60.90L13.29,59.84L14.63,58.82L15.84,57.89L16.79,57.06L17.37,56.34L17.50,55.73L17.16,55.20L16.38,54.73L15.20,54.27L13.74,53.81L12.14,53.31L10.55,52.76L9.12,52.14L7.98,51.47L7.25,50.75L7.00,50.00L7.25,49.25L7.98,48.53L9.12,47.86L10.55,47.24L12.14,46.69L13.74,46.19L15.20,45.73L16.38,45.27L17.16,44.80L17.50,44.27L17.37,43.66L16.79,42.94L15.84,42.11L14.63,41.18L13.29,40.16L11.99,39.10L10.85,38.03L10.01,37.01L9.57,36.08L9.59,35.29L10.08,34.68L11.02,34.25L12.32,34.00L13.87,33.92L15.56,33.94L17.23,34.02L18.76,34.08L20.02,34.06L20.92,33.88L21.42,33.50L21.50,32.88L21.20,32.01L20.60,30.90L19.78,29.61L18.87,28.20L18.01,26.76L17.30,25.36L16.87,24.11L16.77,23.09L17.06,22.36L17.73,21.95L18.75,21.87L20.06,22.08L21.55,22.53L23.13,23.13L24.68,23.78L26.09,24.36L27.28,24.77L28.19,24.91L28.79,24.72L29.08,24.16L29.10,23.24L28.90,22.00L28.57,20.51L28.20,18.87L27.89,17.22L27.70,15.67L27.72,14.34L27.98,13.35L28.50,12.76L29.27,12.61L30.26,12.88L31.41,13.52L32.66,14.46L33.94,15.56L35.17,16.70L36.30,17.73L37.28,18.52L38.09,18.96L38.71,18.99L39.18,18.57L39.51,17.71L39.75,16.47L39.95,14.96L40.16,13.29L40.43,11.63L40.79,10.11L41.26,8.87L41.84,8.03L42.53,7.65L43.31,7.77L44.15,8.36L45.01,9.37L45.87,10.67L46.69,12.14L47.46,13.63L48.17,14.99L48.81,16.07L49.42,16.76L50.00,17.00L50.58,16.76L51.19,16.07L51.83,14.99L52.54,13.63L53.31,12.14L54.13,10.67L54.99,9.37L55.85,8.36L56.69,7.77L57.47,7.65L58.16,8.03L58.74,8.87L59.21,10.11L59.57,11.63L59.84,13.29L60.05,14.96L60.25,16.47L60.49,17.71L60.82,18.57L61.29,18.99L61.91,18.96L62.72,18.52L63.70,17.73L64.83,16.70L66.06,15.56L67.34,14.46L68.59,13.52L69.74,12.88L70.73,12.61L71.50,12.76L72.02,13.35L72.28,14.34L72.30,15.67L72.11,17.22L71.80,18.87L71.43,20.51L71.10,22.00L70.90,23.24L70.92,24.16L71.21,24.72L71.81,24.91L72.72,24.77L73.91,24.36L75.32,23.78L76.87,23.13L78.45,22.53L79.94,22.08L81.25,21.87L82.27,21.95L82.94,22.36L83.23,23.09L83.13,24.11L82.70,25.36L81.99,26.76L81.13,28.20L80.22,29.61L79.40,30.90L78.80,32.01L78.50,32.88L78.58,33.50L79.08,33.88L79.98,34.06L81.24,34.08L82.77,34.02L84.44,33.94L86.13,33.92L87.68,34.00L88.98,34.25L89.92,34.68L90.41,35.29L90.43,36.08L89.99,37.01L89.15,38.03L88.01,39.10L86.71,40.16L85.37,41.18L84.16,42.11L83.21,42.94L82.63,43.66L82.50,44.27L82.84,44.80L83.62,45.27L84.80,45.73L86.26,46.19L87.86,46.69L89.45,47.24L90.88,47.86L92.02,48.53L92.75,49.25L93.00,50.00Z\"/><path d=\"M89.60,50.00L88.42,50.67L87.03,51.29L85.57,51.86L84.17,52.39L82.97,52.88L82.09,53.37L81.61,53.88L81.56,54.44L81.93,55.06L82.69,55.76L83.74,56.56L84.97,57.43L86.23,58.36L87.40,59.33L88.35,60.28L88.96,61.17L89.16,61.97L88.93,62.65L88.26,63.17L87.22,63.55L85.88,63.77L84.36,63.88L82.78,63.92L81.29,63.93L80.00,63.99L79.01,64.15L78.38,64.46L78.14,64.96L78.28,65.68L78.75,66.60L79.46,67.70L80.32,68.94L81.19,70.25L81.96,71.56L82.52,72.77L82.79,73.82L82.71,74.65L82.26,75.20L81.45,75.47L80.34,75.46L79.00,75.21L77.54,74.79L76.05,74.29L74.64,73.79L73.41,73.41L72.42,73.21L71.72,73.29L71.32,73.68L71.21,74.40L71.34,75.43L71.63,76.71L72.01,78.17L72.38,79.70L72.66,81.19L72.77,82.52L72.66,83.60L72.30,84.35L71.69,84.71L70.84,84.69L69.80,84.30L68.63,83.61L67.40,82.72L66.17,81.73L65.02,80.79L63.99,80.00L63.13,79.48L62.44,79.31L61.94,79.55L61.59,80.18L61.35,81.19L61.19,82.50L61.05,84.00L60.87,85.56L60.63,87.05L60.28,88.35L59.80,89.32L59.21,89.90L58.51,90.04L57.72,89.72L56.88,89.00L56.01,87.96L55.16,86.69L54.34,85.35L53.58,84.06L52.88,82.97L52.25,82.19L51.67,81.80L51.11,81.85L50.56,82.33L50.00,83.20L49.40,84.37L48.75,85.73L48.05,87.13L47.31,88.45L46.54,89.55L45.76,90.31L45.01,90.65L44.30,90.53L43.67,89.97L43.12,89.00L42.67,87.72L42.30,86.24L41.99,84.70L41.71,83.23L41.43,81.97L41.10,81.02L40.69,80.46L40.15,80.31L39.47,80.57L38.65,81.19L37.68,82.09L36.61,83.14L35.47,84.23L34.32,85.22L33.22,85.98L32.23,86.43L31.41,86.49L30.78,86.14L30.38,85.39L30.20,84.30L30.21,82.94L30.36,81.42L30.60,79.87L30.85,78.40L31.01,77.11L31.03,76.11L30.83,75.43L30.38,75.11L29.65,75.13L28.66,75.43L27.45,75.94L26.08,76.57L24.64,77.20L23.22,77.73L21.93,78.07L20.85,78.15L20.05,77.93L19.58,77.39L19.46,76.55L19.66,75.46L20.14,74.18L20.80,72.81L21.56,71.43L22.29,70.13L22.89,68.99L23.25,68.05L23.29,67.34L22.97,66.89L22.29,66.65L21.25,66.60L19.94,66.66L18.44,66.78L16.87,66.88L15.35,66.90L14.02,66.78L12.98,66.48L12.30,66.00L12.05,65.33L12.22,64.50L12.78,63.55L13.67,62.51L14.76,61.45L15.94,60.41L17.07,59.44L18.03,58.57L18.69,57.81L18.97,57.16L18.83,56.63L18.26,56.17L17.31,55.76L16.05,55.38L14.60,54.97L13.09,54.53L11.66,54.03L10.45,53.46L9.57,52.83L9.10,52.14L9.09,51.43L9.54,50.71L10.40,50.00L11.58,49.33L12.97,48.71L14.43,48.14L15.83,47.61L17.03,47.12L17.91,46.63L18.39,46.12L18.44,45.56L18.07,44.94L17.31,44.24L16.26,43.44L15.03,42.57L13.77,41.64L12.60,40.67L11.65,39.72L11.04,38.83L10.84,38.03L11.07,37.35L11.74,36.83L12.78,36.45L14.12,36.23L15.64,36.12L17.22,36.08L18.71,36.07L20.00,36.01L20.99,35.85L21.62,35.54L21.86,35.04L21.72,34.32L21.25,33.40L20.54,32.30L19.68,31.06L18.81,29.75L18.04,28.44L17.48,27.23L17.21,26.18L17.29,25.35L17.74,24.80L18.55,24.53L19.66,24.54L21.00,24.79L22.46,25.21L23.95,25.71L25.36,26.21L26.59,26.59L27.58,26.79L28.28,26.71L28.68,26.32L28.79,25.60L28.66,24.57L28.37,23.29L27.99,21.83L27.62,20.30L27.34,18.81L27.23,17.48L27.34,16.40L27.70,15.65L28.31,15.29L29.16,15.31L30.20,15.70L31.37,16.39L32.60,17.28L33.83,18.27L34.98,19.21L36.01,20.00L36.87,20.52L37.56,20.69L38.06,20.45L38.41,19.82L38.65,18.81L38.81,17.50L38.95,16.00L39.13,14.44L39.37,12.95L39.72,11.65L40.20,10.68L40.79,10.10L41.49,9.96L42.28,10.28L43.12,11.00L43.99,12.04L44.84,13.31L45.66,14.65L46.42,15.94L47.12,17.03L47.75,17.81L48.33,18.20L48.89,18.15L49.44,17.67L50.00,16.80L50.60,15.63L51.25,14.27L51.95,12.87L52.69,11.55L53.46,10.45L54.24,9.69L54.99,9.35L55.70,9.47L56.33,10.03L56.88,11.00L57.33,12.28L57.70,13.76L58.01,15.30L58.29,16.77L58.57,18.03L58.90,18.98L59.31,19.54L59.85,19.69L60.53,19.43L61.35,18.81L62.32,17.91L63.39,16.86L64.53,15.77L65.68,14.78L66.78,14.02L67.77,13.57L68.59,13.51L69.22,13.86L69.62,14.61L69.80,15.70L69.79,17.06L69.64,18.58L69.40,20.13L69.15,21.60L68.99,22.89L68.97,23.89L69.17,24.57L69.62,24.89L70.35,24.87L71.34,24.57L72.55,24.06L73.92,23.43L75.36,22.80L76.78,22.27L78.07,21.93L79.15,21.85L79.95,22.07L80.42,22.61L80.54,23.45L80.34,24.54L79.86,25.82L79.20,27.19L78.44,28.57L77.71,29.87L77.11,31.01L76.75,31.95L76.71,32.66L77.03,33.11L77.71,33.35L78.75,33.40L80.06,33.34L81.56,33.22L83.13,33.12L84.65,33.10L85.98,33.22L87.02,33.52L87.70,34.00L87.95,34.67L87.78,35.50L87.22,36.45L86.33,37.49L85.24,38.55L84.06,39.59L82.93,40.56L81.97,41.43L81.31,42.19L81.03,42.84L81.17,43.37L81.74,43.83L82.69,44.24L83.95,44.62L85.40,45.03L86.91,45.47L88.34,45.97L89.55,46.54L90.43,47.17L90.90,47.86L90.91,48.57L90.46,49.29L89.60,50.00Z\"/><path d=\"M84.68,50.00L83.38,50.58L82.21,51.12L81.29,51.64L80.69,52.15L80.49,52.67L80.68,53.22L81.24,53.84L82.12,54.51L83.21,55.26L84.39,56.06L85.55,56.91L86.55,57.77L87.29,58.61L87.68,59.39L87.67,60.09L87.25,60.68L86.46,61.15L85.35,61.49L84.02,61.71L82.59,61.86L81.17,61.96L79.89,62.07L78.84,62.24L78.11,62.52L77.73,62.93L77.72,63.52L78.05,64.29L78.64,65.23L79.40,66.30L80.24,67.46L81.04,68.65L81.69,69.80L82.09,70.84L82.19,71.71L81.95,72.37L81.35,72.78L80.45,72.94L79.29,72.88L77.96,72.64L76.56,72.29L75.20,71.90L73.95,71.57L72.91,71.37L72.13,71.37L71.64,71.64L71.43,72.19L71.47,73.02L71.70,74.10L72.06,75.37L72.45,76.75L72.79,78.14L73.01,79.45L73.03,80.56L72.82,81.41L72.37,81.95L71.67,82.13L70.76,81.97L69.70,81.52L68.53,80.84L67.34,80.03L66.19,79.20L65.13,78.46L64.22,77.92L63.49,77.66L62.93,77.73L62.55,78.18L62.30,78.97L62.15,80.07L62.05,81.39L61.94,82.82L61.79,84.24L61.55,85.54L61.19,86.60L60.70,87.33L60.09,87.67L59.38,87.60L58.58,87.15L57.73,86.36L56.87,85.32L56.02,84.15L55.22,82.98L54.49,81.92L53.82,81.10L53.22,80.60L52.67,80.49L52.15,80.77L51.65,81.43L51.13,82.41L50.59,83.61L50.00,84.92L49.37,86.21L48.70,87.34L48.00,88.22L47.29,88.74L46.60,88.85L45.95,88.54L45.35,87.84L44.83,86.81L44.37,85.54L43.98,84.15L43.63,82.77L43.30,81.53L42.95,80.53L42.56,79.86L42.08,79.56L41.50,79.65L40.80,80.10L39.98,80.84L39.05,81.79L38.06,82.82L37.02,83.81L36.00,84.65L35.05,85.23L34.21,85.47L33.52,85.34L33.01,84.83L32.69,83.97L32.55,82.82L32.56,81.47L32.66,80.03L32.80,78.62L32.92,77.34L32.94,76.28L32.79,75.51L32.45,75.07L31.87,74.95L31.06,75.14L30.03,75.56L28.84,76.13L27.55,76.75L26.24,77.33L25.00,77.77L23.90,77.99L23.03,77.93L22.42,77.58L22.12,76.92L22.12,76.00L22.38,74.87L22.85,73.61L23.44,72.29L24.05,71.01L24.60,69.84L24.98,68.86L25.11,68.09L24.93,67.55L24.43,67.25L23.60,67.14L22.50,67.19L21.18,67.32L19.76,67.46L18.33,67.56L17.01,67.54L15.90,67.37L15.10,67.02L14.66,66.48L14.60,65.76L14.91,64.90L15.54,63.92L16.41,62.89L17.41,61.86L18.43,60.87L19.34,59.96L20.04,59.16L20.42,58.48L20.44,57.92L20.07,57.46L19.33,57.08L18.28,56.74L17.00,56.41L15.61,56.06L14.23,55.67L13.00,55.20L12.02,54.66L11.38,54.06L11.15,53.40L11.34,52.70L11.93,52.00L12.85,51.30L14.02,50.63L15.32,50.00L16.62,49.42L17.79,48.88L18.71,48.36L19.31,47.85L19.51,47.33L19.32,46.78L18.76,46.16L17.88,45.49L16.79,44.74L15.61,43.94L14.45,43.09L13.45,42.23L12.71,41.39L12.32,40.61L12.33,39.91L12.75,39.32L13.54,38.85L14.65,38.51L15.98,38.29L17.41,38.14L18.83,38.04L20.11,37.93L21.16,37.76L21.89,37.48L22.27,37.07L22.28,36.48L21.95,35.71L21.36,34.77L20.60,33.70L19.76,32.54L18.96,31.35L18.31,30.20L17.91,29.16L17.81,28.29L18.05,27.63L18.65,27.22L19.55,27.06L20.71,27.12L22.04,27.36L23.44,27.71L24.80,28.10L26.05,28.43L27.09,28.63L27.87,28.63L28.36,28.36L28.57,27.81L28.53,26.98L28.30,25.90L27.94,24.63L27.55,23.25L27.21,21.86L26.99,20.55L26.97,19.44L27.18,18.59L27.63,18.05L28.33,17.87L29.24,18.03L30.30,18.48L31.47,19.16L32.66,19.97L33.81,20.80L34.87,21.54L35.78,22.08L36.51,22.34L37.07,22.27L37.45,21.82L37.70,21.03L37.85,19.93L37.95,18.61L38.06,17.18L38.21,15.76L38.45,14.46L38.81,13.40L39.30,12.67L39.91,12.33L40.62,12.40L41.42,12.85L42.27,13.64L43.13,14.68L43.98,15.85L44.78,17.02L45.51,18.08L46.18,18.90L46.78,19.40L47.33,19.51L47.85,19.23L48.35,18.57L48.87,17.59L49.41,16.39L50.00,15.08L50.63,13.79L51.30,12.66L52.00,11.78L52.71,11.26L53.40,11.15L54.05,11.46L54.65,12.16L55.17,13.19L55.63,14.46L56.02,15.85L56.37,17.23L56.70,18.47L57.05,19.47L57.44,20.14L57.92,20.44L58.50,20.35L59.20,19.90L60.02,19.16L60.95,18.21L61.94,17.18L62.98,16.19L64.00,15.35L64.95,14.77L65.79,14.53L66.48,14.66L66.99,15.17L67.31,16.03L67.45,17.18L67.44,18.53L67.34,19.97L67.20,21.38L67.08,22.66L67.06,23.72L67.21,24.49L67.55,24.93L68.13,25.05L68.94,24.86L69.97,24.44L71.16,23.87L72.45,23.25L73.76,22.67L75.00,22.23L76.10,22.01L76.97,22.07L77.58,22.42L77.88,23.08L77.88,24.00L77.62,25.13L77.15,26.39L76.56,27.71L75.95,28.99L75.40,30.16L75.02,31.14L74.89,31.91L75.07,32.45L75.57,32.75L76.40,32.86L77.50,32.81L78.82,32.68L80.24,32.54L81.67,32.44L82.99,32.46L84.10,32.63L84.90,32.98L85.34,33.52L85.40,34.24L85.09,35.10L84.46,36.08L83.59,37.11L82.59,38.14L81.57,39.13L80.66,40.04L79.96,40.84L79.58,41.52L79.56,42.08L79.93,42.54L80.67,42.92L81.72,43.26L83.00,43.59L84.39,43.94L85.77,44.33L87.00,44.80L87.98,45.34L88.62,45.94L88.85,46.60L88.66,47.30L88.07,48.00L87.15,48.70L85.98,49.37L84.68,50.00Z\"/><path d=\"M80.40,50.00L79.74,50.52L79.41,51.03L79.44,51.54L79.82,52.09L80.52,52.67L81.45,53.31L82.53,53.99L83.63,54.73L84.64,55.49L85.46,56.25L85.98,56.99L86.17,57.69L85.98,58.31L85.42,58.83L84.55,59.26L83.43,59.59L82.16,59.83L80.85,60.03L79.62,60.20L78.56,60.40L77.77,60.66L77.28,61.02L77.13,61.52L77.31,62.16L77.76,62.95L78.42,63.86L79.20,64.88L79.98,65.94L80.67,67.00L81.18,68.00L81.42,68.88L81.36,69.59L80.97,70.11L80.27,70.41L79.30,70.51L78.13,70.44L76.86,70.24L75.56,69.97L74.35,69.72L73.29,69.54L72.45,69.51L71.87,69.69L71.56,70.10L71.50,70.77L71.66,71.66L71.97,72.75L72.35,73.97L72.72,75.24L73.01,76.47L73.14,77.58L73.07,78.49L72.76,79.14L72.22,79.49L71.46,79.53L70.51,79.30L69.45,78.83L68.32,78.20L67.19,77.51L66.14,76.85L65.20,76.33L64.42,76.01L63.81,75.98L63.38,76.26L63.10,76.87L62.95,77.76L62.86,78.89L62.80,80.17L62.72,81.49L62.57,82.74L62.31,83.83L61.93,84.66L61.43,85.17L60.80,85.31L60.06,85.09L59.26,84.55L58.41,83.74L57.56,82.77L56.75,81.73L55.98,80.75L55.28,79.94L54.65,79.38L54.10,79.14L53.59,79.26L53.12,79.73L52.67,80.52L52.21,81.55L51.72,82.73L51.19,83.94L50.61,85.07L50.00,86.00L49.36,86.65L48.71,86.95L48.07,86.87L47.45,86.42L46.88,85.63L46.36,84.58L45.90,83.38L45.48,82.13L45.10,80.94L44.72,79.94L44.32,79.20L43.88,78.78L43.37,78.72L42.77,79.01L42.07,79.59L41.28,80.40L40.42,81.34L39.51,82.30L38.58,83.16L37.69,83.83L36.86,84.22L36.15,84.28L35.57,83.99L35.15,83.35L34.88,82.42L34.76,81.26L34.73,79.96L34.77,78.64L34.81,77.40L34.80,76.33L34.68,75.49L34.41,74.95L33.95,74.72L33.28,74.78L32.43,75.09L31.41,75.58L30.28,76.17L29.09,76.76L27.93,77.26L26.86,77.58L25.95,77.67L25.26,77.48L24.82,77.00L24.64,76.26L24.71,75.29L24.98,74.16L25.40,72.94L25.89,71.71L26.36,70.55L26.71,69.54L26.89,68.72L26.81,68.12L26.46,67.74L25.82,67.57L24.91,67.57L23.78,67.68L22.52,67.85L21.20,68.00L19.94,68.06L18.82,68.00L17.94,67.77L17.35,67.36L17.10,66.76L17.19,66.00L17.58,65.12L18.23,64.14L19.04,63.14L19.92,62.15L20.75,61.23L21.44,60.40L21.88,59.68L22.02,59.09L21.81,58.62L21.27,58.24L20.41,57.93L19.31,57.65L18.07,57.37L16.78,57.06L15.57,56.69L14.54,56.25L13.79,55.73L13.38,55.15L13.35,54.50L13.69,53.82L14.37,53.12L15.31,52.43L16.42,51.76L17.58,51.13L18.68,50.55L19.60,50.00L20.26,49.48L20.59,48.97L20.56,48.46L20.18,47.91L19.48,47.33L18.55,46.69L17.47,46.01L16.37,45.27L15.36,44.51L14.54,43.75L14.02,43.01L13.83,42.31L14.02,41.69L14.58,41.17L15.45,40.74L16.57,40.41L17.84,40.17L19.15,39.97L20.38,39.80L21.44,39.60L22.23,39.34L22.72,38.98L22.87,38.48L22.69,37.84L22.24,37.05L21.58,36.14L20.80,35.12L20.02,34.06L19.33,33.00L18.82,32.00L18.58,31.12L18.64,30.41L19.03,29.89L19.73,29.59L20.70,29.49L21.87,29.56L23.14,29.76L24.44,30.03L25.65,30.28L26.71,30.46L27.55,30.49L28.13,30.31L28.44,29.90L28.50,29.23L28.34,28.34L28.03,27.25L27.65,26.03L27.28,24.76L26.99,23.53L26.86,22.42L26.93,21.51L27.24,20.86L27.78,20.51L28.54,20.47L29.49,20.70L30.55,21.17L31.68,21.80L32.81,22.49L33.86,23.15L34.80,23.67L35.58,23.99L36.19,24.02L36.62,23.74L36.90,23.13L37.05,22.24L37.14,21.11L37.20,19.83L37.28,18.51L37.43,17.26L37.69,16.17L38.07,15.34L38.57,14.83L39.20,14.69L39.94,14.91L40.74,15.45L41.59,16.26L42.44,17.23L43.25,18.27L44.02,19.25L44.72,20.06L45.35,20.62L45.90,20.86L46.41,20.74L46.88,20.27L47.33,19.48L47.79,18.45L48.28,17.27L48.81,16.06L49.39,14.93L50.00,14.00L50.64,13.35L51.29,13.05L51.93,13.13L52.55,13.58L53.12,14.37L53.64,15.42L54.10,16.62L54.52,17.87L54.90,19.06L55.28,20.06L55.68,20.80L56.12,21.22L56.63,21.28L57.23,20.99L57.93,20.41L58.72,19.60L59.58,18.66L60.49,17.70L61.42,16.84L62.31,16.17L63.14,15.78L63.85,15.72L64.43,16.01L64.85,16.65L65.12,17.58L65.24,18.74L65.27,20.04L65.23,21.36L65.19,22.60L65.20,23.67L65.32,24.51L65.59,25.05L66.05,25.28L66.72,25.22L67.57,24.91L68.59,24.42L69.72,23.83L70.91,23.24L72.07,22.74L73.14,22.42L74.05,22.33L74.74,22.52L75.18,23.00L75.36,23.74L75.29,24.71L75.02,25.84L74.60,27.06L74.11,28.29L73.64,29.45L73.29,30.46L73.11,31.28L73.19,31.88L73.54,32.26L74.18,32.43L75.09,32.43L76.22,32.32L77.48,32.15L78.80,32.00L80.06,31.94L81.18,32.00L82.06,32.23L82.65,32.64L82.90,33.24L82.81,34.00L82.42,34.88L81.77,35.86L80.96,36.86L80.08,37.85L79.25,38.77L78.56,39.60L78.12,40.32L77.98,40.91L78.19,41.38L78.73,41.76L79.59,42.07L80.69,42.35L81.93,42.63L83.22,42.94L84.43,43.31L85.46,43.75L86.21,44.27L86.62,44.85L86.65,45.50L86.31,46.18L85.63,46.88L84.69,47.57L83.58,48.24L82.42,48.87L81.32,49.45L80.40,50.00Z\"/><path d=\"M78.21,50.00L78.43,50.50L78.95,51.01L79.72,51.56L80.67,52.14L81.68,52.77L82.66,53.43L83.50,54.11L84.13,54.80L84.46,55.46L84.46,56.08L84.13,56.63L83.48,57.12L82.58,57.52L81.50,57.85L80.33,58.13L79.19,58.37L78.16,58.61L77.33,58.88L76.77,59.22L76.50,59.65L76.54,60.19L76.86,60.85L77.40,61.63L78.08,62.50L78.82,63.44L79.51,64.40L80.08,65.32L80.43,66.18L80.51,66.91L80.31,67.50L79.80,67.91L79.03,68.14L78.04,68.21L76.91,68.15L75.72,68.01L74.56,67.85L73.52,67.72L72.65,67.69L72.00,67.82L71.61,68.13L71.46,68.65L71.53,69.39L71.77,70.30L72.11,71.35L72.48,72.48L72.81,73.62L73.02,74.69L73.06,75.61L72.89,76.33L72.49,76.81L71.88,77.02L71.07,76.97L70.12,76.70L69.08,76.26L68.01,75.72L66.98,75.17L66.04,74.69L65.23,74.37L64.58,74.27L64.10,74.43L63.78,74.87L63.60,75.58L63.51,76.52L63.48,77.63L63.44,78.82L63.36,80.00L63.19,81.07L62.91,81.95L62.50,82.57L61.97,82.88L61.32,82.87L60.58,82.55L59.78,81.97L58.95,81.20L58.13,80.33L57.35,79.46L56.62,78.69L55.97,78.11L55.40,77.79L54.90,77.78L54.45,78.08L54.03,78.69L53.63,79.54L53.21,80.57L52.77,81.68L52.29,82.76L51.77,83.71L51.20,84.44L50.61,84.88L50.00,84.99L49.39,84.76L48.81,84.21L48.25,83.39L47.74,82.38L47.26,81.28L46.83,80.20L46.41,79.22L46.00,78.46L45.57,77.96L45.10,77.78L44.57,77.91L43.98,78.34L43.30,79.00L42.56,79.83L41.77,80.71L40.95,81.57L40.13,82.28L39.35,82.78L38.64,82.99L38.03,82.88L37.54,82.46L37.18,81.74L36.94,80.78L36.80,79.65L36.73,78.46L36.69,77.29L36.63,76.24L36.51,75.37L36.27,74.76L35.90,74.43L35.36,74.37L34.65,74.57L33.79,74.96L32.81,75.48L31.76,76.05L30.70,76.57L29.69,76.96L28.78,77.16L28.04,77.11L27.51,76.81L27.19,76.24L27.10,75.44L27.20,74.45L27.45,73.35L27.80,72.20L28.16,71.09L28.47,70.08L28.64,69.23L28.63,68.57L28.39,68.13L27.90,67.89L27.17,67.84L26.23,67.91L25.13,68.07L23.95,68.24L22.78,68.36L21.69,68.38L20.77,68.26L20.09,67.97L19.69,67.50L19.59,66.86L19.78,66.07L20.21,65.18L20.83,64.23L21.54,63.27L22.26,62.35L22.90,61.50L23.36,60.77L23.57,60.15L23.50,59.65L23.12,59.26L22.45,58.95L21.54,58.70L20.45,58.47L19.29,58.23L18.14,57.94L17.11,57.59L16.29,57.17L15.75,56.66L15.54,56.08L15.66,55.44L16.10,54.76L16.81,54.07L17.72,53.39L18.72,52.74L19.71,52.12L20.60,51.54L21.28,51.00L21.69,50.49L21.79,50.00L21.57,49.50L21.05,48.99L20.28,48.44L19.33,47.86L18.32,47.23L17.34,46.57L16.50,45.89L15.87,45.20L15.54,44.54L15.54,43.92L15.87,43.37L16.52,42.88L17.42,42.48L18.50,42.15L19.67,41.87L20.81,41.63L21.84,41.39L22.67,41.12L23.23,40.78L23.50,40.35L23.46,39.81L23.14,39.15L22.60,38.37L21.92,37.50L21.18,36.56L20.49,35.60L19.92,34.68L19.57,33.82L19.49,33.09L19.69,32.50L20.20,32.09L20.97,31.86L21.96,31.79L23.09,31.85L24.28,31.99L25.44,32.15L26.48,32.28L27.35,32.31L28.00,32.18L28.39,31.87L28.54,31.35L28.47,30.61L28.23,29.70L27.89,28.65L27.52,27.52L27.19,26.38L26.98,25.31L26.94,24.39L27.11,23.67L27.51,23.19L28.12,22.98L28.93,23.03L29.88,23.30L30.92,23.74L31.99,24.28L33.02,24.83L33.96,25.31L34.77,25.63L35.42,25.73L35.90,25.57L36.22,25.13L36.40,24.42L36.49,23.48L36.52,22.37L36.56,21.18L36.64,20.00L36.81,18.93L37.09,18.05L37.50,17.43L38.03,17.12L38.68,17.13L39.42,17.45L40.22,18.03L41.05,18.80L41.87,19.67L42.65,20.54L43.38,21.31L44.03,21.89L44.60,22.21L45.10,22.22L45.55,21.92L45.97,21.31L46.37,20.46L46.79,19.43L47.23,18.32L47.71,17.24L48.23,16.29L48.80,15.56L49.39,15.12L50.00,15.01L50.61,15.24L51.19,15.79L51.75,16.61L52.26,17.62L52.74,18.72L53.17,19.80L53.59,20.78L54.00,21.54L54.43,22.04L54.90,22.22L55.43,22.09L56.02,21.66L56.70,21.00L57.44,20.17L58.23,19.29L59.05,18.43L59.87,17.72L60.65,17.22L61.36,17.01L61.97,17.12L62.46,17.54L62.82,18.26L63.06,19.22L63.20,20.35L63.27,21.54L63.31,22.71L63.37,23.76L63.49,24.63L63.73,25.24L64.10,25.57L64.64,25.63L65.35,25.43L66.21,25.04L67.19,24.52L68.24,23.95L69.30,23.43L70.31,23.04L71.22,22.84L71.96,22.89L72.49,23.19L72.81,23.76L72.90,24.56L72.80,25.55L72.55,26.65L72.20,27.80L71.84,28.91L71.53,29.92L71.36,30.77L71.37,31.43L71.61,31.87L72.10,32.11L72.83,32.16L73.77,32.09L74.87,31.93L76.05,31.76L77.22,31.64L78.31,31.62L79.23,31.74L79.91,32.03L80.31,32.50L80.41,33.14L80.22,33.93L79.79,34.82L79.17,35.77L78.46,36.73L77.74,37.65L77.10,38.50L76.64,39.23L76.43,39.85L76.50,40.35L76.88,40.74L77.55,41.05L78.46,41.30L79.55,41.53L80.71,41.77L81.86,42.06L82.89,42.41L83.71,42.83L84.25,43.34L84.46,43.92L84.34,44.56L83.90,45.24L83.19,45.93L82.28,46.61L81.28,47.26L80.29,47.88L79.40,48.46L78.72,49.00L78.31,49.51L78.21,50.00Z\"/><circle cx=\"50\" cy=\"50\" r=\"28\" stroke-width=\".8\"/><circle cx=\"50\" cy=\"50\" r=\"25.5\" stroke-width=\".45\"/></g><g transform=\"translate(23 23) scale(.54)\" fill=\"currentColor\" style=\"--seal-paper:var(--ex-paper)\"><path d=\"M21 77V37l9-13 9 13v40m22 0V37l9-13 9 13v40M30 24v-9m40 9v-9M39 43l11-11 11 11v34H39\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3\"/>\n   <path d=\"M44 77V59a6 6 0 0 1 12 0v18m-31-8h10m30 0h10M27 42h6m34 0h6M18 80h64M50 17v8m-4-4h8\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\"/>\n   <path d=\"M39 44h22M20 37h20m20 0h20M29 50v8m41-8v8\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/></g>",
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\"><path d=\"M93.00,50.00L92.75,50.75L92.02,51.47L90.88,52.14L89.45,52.76L87.86,53.31L86.26,53.81L84.80,54.27L83.62,54.73L82.84,55.20L82.50,55.73L82.63,56.34L83.21,57.06L84.16,57.89L85.37,58.82L86.71,59.84L88.01,60.90L89.15,61.97L89.99,62.99L90.43,63.92L90.41,64.71L89.92,65.32L88.98,65.75L87.68,66.00L86.13,66.08L84.44,66.06L82.77,65.98L81.24,65.92L79.98,65.94L79.08,66.12L78.58,66.50L78.50,67.12L78.80,67.99L79.40,69.10L80.22,70.39L81.13,71.80L81.99,73.24L82.70,74.64L83.13,75.89L83.23,76.91L82.94,77.64L82.27,78.05L81.25,78.13L79.94,77.92L78.45,77.47L76.87,76.87L75.32,76.22L73.91,75.64L72.72,75.23L71.81,75.09L71.21,75.28L70.92,75.84L70.90,76.76L71.10,78.00L71.43,79.49L71.80,81.13L72.11,82.78L72.30,84.33L72.28,85.66L72.02,86.65L71.50,87.24L70.73,87.39L69.74,87.12L68.59,86.48L67.34,85.54L66.06,84.44L64.83,83.30L63.70,82.27L62.72,81.48L61.91,81.04L61.29,81.01L60.82,81.43L60.49,82.29L60.25,83.53L60.05,85.04L59.84,86.71L59.57,88.37L59.21,89.89L58.74,91.13L58.16,91.97L57.47,92.35L56.69,92.23L55.85,91.64L54.99,90.63L54.13,89.33L53.31,87.86L52.54,86.37L51.83,85.01L51.19,83.93L50.58,83.24L50.00,83.00L49.42,83.24L48.81,83.93L48.17,85.01L47.46,86.37L46.69,87.86L45.87,89.33L45.01,90.63L44.15,91.64L43.31,92.23L42.53,92.35L41.84,91.97L41.26,91.13L40.79,89.89L40.43,88.37L40.16,86.71L39.95,85.04L39.75,83.53L39.51,82.29L39.18,81.43L38.71,81.01L38.09,81.04L37.28,81.48L36.30,82.27L35.17,83.30L33.94,84.44L32.66,85.54L31.41,86.48L30.26,87.12L29.27,87.39L28.50,87.24L27.98,86.65L27.72,85.66L27.70,84.33L27.89,82.78L28.20,81.13L28.57,79.49L28.90,78.00L29.10,76.76L29.08,75.84L28.79,75.28L28.19,75.09L27.28,75.23L26.09,75.64L24.68,76.22L23.13,76.87L21.55,77.47L20.06,77.92L18.75,78.13L17.73,78.05L17.06,77.64L16.77,76.91L16.87,75.89L17.30,74.64L18.01,73.24L18.87,71.80L19.78,70.39L20.60,69.10L21.20,67.99L21.50,67.12L21.42,66.50L20.92,66.12L20.02,65.94L18.76,65.92L17.23,65.98L15.56,66.06L13.87,66.08L12.32,66.00L11.02,65.75L10.08,65.32L9.59,64.71L9.57,63.92L10.01,62.99L10.85,61.97L11.99,60.90L13.29,59.84L14.63,58.82L15.84,57.89L16.79,57.06L17.37,56.34L17.50,55.73L17.16,55.20L16.38,54.73L15.20,54.27L13.74,53.81L12.14,53.31L10.55,52.76L9.12,52.14L7.98,51.47L7.25,50.75L7.00,50.00L7.25,49.25L7.98,48.53L9.12,47.86L10.55,47.24L12.14,46.69L13.74,46.19L15.20,45.73L16.38,45.27L17.16,44.80L17.50,44.27L17.37,43.66L16.79,42.94L15.84,42.11L14.63,41.18L13.29,40.16L11.99,39.10L10.85,38.03L10.01,37.01L9.57,36.08L9.59,35.29L10.08,34.68L11.02,34.25L12.32,34.00L13.87,33.92L15.56,33.94L17.23,34.02L18.76,34.08L20.02,34.06L20.92,33.88L21.42,33.50L21.50,32.88L21.20,32.01L20.60,30.90L19.78,29.61L18.87,28.20L18.01,26.76L17.30,25.36L16.87,24.11L16.77,23.09L17.06,22.36L17.73,21.95L18.75,21.87L20.06,22.08L21.55,22.53L23.13,23.13L24.68,23.78L26.09,24.36L27.28,24.77L28.19,24.91L28.79,24.72L29.08,24.16L29.10,23.24L28.90,22.00L28.57,20.51L28.20,18.87L27.89,17.22L27.70,15.67L27.72,14.34L27.98,13.35L28.50,12.76L29.27,12.61L30.26,12.88L31.41,13.52L32.66,14.46L33.94,15.56L35.17,16.70L36.30,17.73L37.28,18.52L38.09,18.96L38.71,18.99L39.18,18.57L39.51,17.71L39.75,16.47L39.95,14.96L40.16,13.29L40.43,11.63L40.79,10.11L41.26,8.87L41.84,8.03L42.53,7.65L43.31,7.77L44.15,8.36L45.01,9.37L45.87,10.67L46.69,12.14L47.46,13.63L48.17,14.99L48.81,16.07L49.42,16.76L50.00,17.00L50.58,16.76L51.19,16.07L51.83,14.99L52.54,13.63L53.31,12.14L54.13,10.67L54.99,9.37L55.85,8.36L56.69,7.77L57.47,7.65L58.16,8.03L58.74,8.87L59.21,10.11L59.57,11.63L59.84,13.29L60.05,14.96L60.25,16.47L60.49,17.71L60.82,18.57L61.29,18.99L61.91,18.96L62.72,18.52L63.70,17.73L64.83,16.70L66.06,15.56L67.34,14.46L68.59,13.52L69.74,12.88L70.73,12.61L71.50,12.76L72.02,13.35L72.28,14.34L72.30,15.67L72.11,17.22L71.80,18.87L71.43,20.51L71.10,22.00L70.90,23.24L70.92,24.16L71.21,24.72L71.81,24.91L72.72,24.77L73.91,24.36L75.32,23.78L76.87,23.13L78.45,22.53L79.94,22.08L81.25,21.87L82.27,21.95L82.94,22.36L83.23,23.09L83.13,24.11L82.70,25.36L81.99,26.76L81.13,28.20L80.22,29.61L79.40,30.90L78.80,32.01L78.50,32.88L78.58,33.50L79.08,33.88L79.98,34.06L81.24,34.08L82.77,34.02L84.44,33.94L86.13,33.92L87.68,34.00L88.98,34.25L89.92,34.68L90.41,35.29L90.43,36.08L89.99,37.01L89.15,38.03L88.01,39.10L86.71,40.16L85.37,41.18L84.16,42.11L83.21,42.94L82.63,43.66L82.50,44.27L82.84,44.80L83.62,45.27L84.80,45.73L86.26,46.19L87.86,46.69L89.45,47.24L90.88,47.86L92.02,48.53L92.75,49.25L93.00,50.00Z\"/><path d=\"M89.60,50.00L88.42,50.67L87.03,51.29L85.57,51.86L84.17,52.39L82.97,52.88L82.09,53.37L81.61,53.88L81.56,54.44L81.93,55.06L82.69,55.76L83.74,56.56L84.97,57.43L86.23,58.36L87.40,59.33L88.35,60.28L88.96,61.17L89.16,61.97L88.93,62.65L88.26,63.17L87.22,63.55L85.88,63.77L84.36,63.88L82.78,63.92L81.29,63.93L80.00,63.99L79.01,64.15L78.38,64.46L78.14,64.96L78.28,65.68L78.75,66.60L79.46,67.70L80.32,68.94L81.19,70.25L81.96,71.56L82.52,72.77L82.79,73.82L82.71,74.65L82.26,75.20L81.45,75.47L80.34,75.46L79.00,75.21L77.54,74.79L76.05,74.29L74.64,73.79L73.41,73.41L72.42,73.21L71.72,73.29L71.32,73.68L71.21,74.40L71.34,75.43L71.63,76.71L72.01,78.17L72.38,79.70L72.66,81.19L72.77,82.52L72.66,83.60L72.30,84.35L71.69,84.71L70.84,84.69L69.80,84.30L68.63,83.61L67.40,82.72L66.17,81.73L65.02,80.79L63.99,80.00L63.13,79.48L62.44,79.31L61.94,79.55L61.59,80.18L61.35,81.19L61.19,82.50L61.05,84.00L60.87,85.56L60.63,87.05L60.28,88.35L59.80,89.32L59.21,89.90L58.51,90.04L57.72,89.72L56.88,89.00L56.01,87.96L55.16,86.69L54.34,85.35L53.58,84.06L52.88,82.97L52.25,82.19L51.67,81.80L51.11,81.85L50.56,82.33L50.00,83.20L49.40,84.37L48.75,85.73L48.05,87.13L47.31,88.45L46.54,89.55L45.76,90.31L45.01,90.65L44.30,90.53L43.67,89.97L43.12,89.00L42.67,87.72L42.30,86.24L41.99,84.70L41.71,83.23L41.43,81.97L41.10,81.02L40.69,80.46L40.15,80.31L39.47,80.57L38.65,81.19L37.68,82.09L36.61,83.14L35.47,84.23L34.32,85.22L33.22,85.98L32.23,86.43L31.41,86.49L30.78,86.14L30.38,85.39L30.20,84.30L30.21,82.94L30.36,81.42L30.60,79.87L30.85,78.40L31.01,77.11L31.03,76.11L30.83,75.43L30.38,75.11L29.65,75.13L28.66,75.43L27.45,75.94L26.08,76.57L24.64,77.20L23.22,77.73L21.93,78.07L20.85,78.15L20.05,77.93L19.58,77.39L19.46,76.55L19.66,75.46L20.14,74.18L20.80,72.81L21.56,71.43L22.29,70.13L22.89,68.99L23.25,68.05L23.29,67.34L22.97,66.89L22.29,66.65L21.25,66.60L19.94,66.66L18.44,66.78L16.87,66.88L15.35,66.90L14.02,66.78L12.98,66.48L12.30,66.00L12.05,65.33L12.22,64.50L12.78,63.55L13.67,62.51L14.76,61.45L15.94,60.41L17.07,59.44L18.03,58.57L18.69,57.81L18.97,57.16L18.83,56.63L18.26,56.17L17.31,55.76L16.05,55.38L14.60,54.97L13.09,54.53L11.66,54.03L10.45,53.46L9.57,52.83L9.10,52.14L9.09,51.43L9.54,50.71L10.40,50.00L11.58,49.33L12.97,48.71L14.43,48.14L15.83,47.61L17.03,47.12L17.91,46.63L18.39,46.12L18.44,45.56L18.07,44.94L17.31,44.24L16.26,43.44L15.03,42.57L13.77,41.64L12.60,40.67L11.65,39.72L11.04,38.83L10.84,38.03L11.07,37.35L11.74,36.83L12.78,36.45L14.12,36.23L15.64,36.12L17.22,36.08L18.71,36.07L20.00,36.01L20.99,35.85L21.62,35.54L21.86,35.04L21.72,34.32L21.25,33.40L20.54,32.30L19.68,31.06L18.81,29.75L18.04,28.44L17.48,27.23L17.21,26.18L17.29,25.35L17.74,24.80L18.55,24.53L19.66,24.54L21.00,24.79L22.46,25.21L23.95,25.71L25.36,26.21L26.59,26.59L27.58,26.79L28.28,26.71L28.68,26.32L28.79,25.60L28.66,24.57L28.37,23.29L27.99,21.83L27.62,20.30L27.34,18.81L27.23,17.48L27.34,16.40L27.70,15.65L28.31,15.29L29.16,15.31L30.20,15.70L31.37,16.39L32.60,17.28L33.83,18.27L34.98,19.21L36.01,20.00L36.87,20.52L37.56,20.69L38.06,20.45L38.41,19.82L38.65,18.81L38.81,17.50L38.95,16.00L39.13,14.44L39.37,12.95L39.72,11.65L40.20,10.68L40.79,10.10L41.49,9.96L42.28,10.28L43.12,11.00L43.99,12.04L44.84,13.31L45.66,14.65L46.42,15.94L47.12,17.03L47.75,17.81L48.33,18.20L48.89,18.15L49.44,17.67L50.00,16.80L50.60,15.63L51.25,14.27L51.95,12.87L52.69,11.55L53.46,10.45L54.24,9.69L54.99,9.35L55.70,9.47L56.33,10.03L56.88,11.00L57.33,12.28L57.70,13.76L58.01,15.30L58.29,16.77L58.57,18.03L58.90,18.98L59.31,19.54L59.85,19.69L60.53,19.43L61.35,18.81L62.32,17.91L63.39,16.86L64.53,15.77L65.68,14.78L66.78,14.02L67.77,13.57L68.59,13.51L69.22,13.86L69.62,14.61L69.80,15.70L69.79,17.06L69.64,18.58L69.40,20.13L69.15,21.60L68.99,22.89L68.97,23.89L69.17,24.57L69.62,24.89L70.35,24.87L71.34,24.57L72.55,24.06L73.92,23.43L75.36,22.80L76.78,22.27L78.07,21.93L79.15,21.85L79.95,22.07L80.42,22.61L80.54,23.45L80.34,24.54L79.86,25.82L79.20,27.19L78.44,28.57L77.71,29.87L77.11,31.01L76.75,31.95L76.71,32.66L77.03,33.11L77.71,33.35L78.75,33.40L80.06,33.34L81.56,33.22L83.13,33.12L84.65,33.10L85.98,33.22L87.02,33.52L87.70,34.00L87.95,34.67L87.78,35.50L87.22,36.45L86.33,37.49L85.24,38.55L84.06,39.59L82.93,40.56L81.97,41.43L81.31,42.19L81.03,42.84L81.17,43.37L81.74,43.83L82.69,44.24L83.95,44.62L85.40,45.03L86.91,45.47L88.34,45.97L89.55,46.54L90.43,47.17L90.90,47.86L90.91,48.57L90.46,49.29L89.60,50.00Z\"/><path d=\"M84.68,50.00L83.38,50.58L82.21,51.12L81.29,51.64L80.69,52.15L80.49,52.67L80.68,53.22L81.24,53.84L82.12,54.51L83.21,55.26L84.39,56.06L85.55,56.91L86.55,57.77L87.29,58.61L87.68,59.39L87.67,60.09L87.25,60.68L86.46,61.15L85.35,61.49L84.02,61.71L82.59,61.86L81.17,61.96L79.89,62.07L78.84,62.24L78.11,62.52L77.73,62.93L77.72,63.52L78.05,64.29L78.64,65.23L79.40,66.30L80.24,67.46L81.04,68.65L81.69,69.80L82.09,70.84L82.19,71.71L81.95,72.37L81.35,72.78L80.45,72.94L79.29,72.88L77.96,72.64L76.56,72.29L75.20,71.90L73.95,71.57L72.91,71.37L72.13,71.37L71.64,71.64L71.43,72.19L71.47,73.02L71.70,74.10L72.06,75.37L72.45,76.75L72.79,78.14L73.01,79.45L73.03,80.56L72.82,81.41L72.37,81.95L71.67,82.13L70.76,81.97L69.70,81.52L68.53,80.84L67.34,80.03L66.19,79.20L65.13,78.46L64.22,77.92L63.49,77.66L62.93,77.73L62.55,78.18L62.30,78.97L62.15,80.07L62.05,81.39L61.94,82.82L61.79,84.24L61.55,85.54L61.19,86.60L60.70,87.33L60.09,87.67L59.38,87.60L58.58,87.15L57.73,86.36L56.87,85.32L56.02,84.15L55.22,82.98L54.49,81.92L53.82,81.10L53.22,80.60L52.67,80.49L52.15,80.77L51.65,81.43L51.13,82.41L50.59,83.61L50.00,84.92L49.37,86.21L48.70,87.34L48.00,88.22L47.29,88.74L46.60,88.85L45.95,88.54L45.35,87.84L44.83,86.81L44.37,85.54L43.98,84.15L43.63,82.77L43.30,81.53L42.95,80.53L42.56,79.86L42.08,79.56L41.50,79.65L40.80,80.10L39.98,80.84L39.05,81.79L38.06,82.82L37.02,83.81L36.00,84.65L35.05,85.23L34.21,85.47L33.52,85.34L33.01,84.83L32.69,83.97L32.55,82.82L32.56,81.47L32.66,80.03L32.80,78.62L32.92,77.34L32.94,76.28L32.79,75.51L32.45,75.07L31.87,74.95L31.06,75.14L30.03,75.56L28.84,76.13L27.55,76.75L26.24,77.33L25.00,77.77L23.90,77.99L23.03,77.93L22.42,77.58L22.12,76.92L22.12,76.00L22.38,74.87L22.85,73.61L23.44,72.29L24.05,71.01L24.60,69.84L24.98,68.86L25.11,68.09L24.93,67.55L24.43,67.25L23.60,67.14L22.50,67.19L21.18,67.32L19.76,67.46L18.33,67.56L17.01,67.54L15.90,67.37L15.10,67.02L14.66,66.48L14.60,65.76L14.91,64.90L15.54,63.92L16.41,62.89L17.41,61.86L18.43,60.87L19.34,59.96L20.04,59.16L20.42,58.48L20.44,57.92L20.07,57.46L19.33,57.08L18.28,56.74L17.00,56.41L15.61,56.06L14.23,55.67L13.00,55.20L12.02,54.66L11.38,54.06L11.15,53.40L11.34,52.70L11.93,52.00L12.85,51.30L14.02,50.63L15.32,50.00L16.62,49.42L17.79,48.88L18.71,48.36L19.31,47.85L19.51,47.33L19.32,46.78L18.76,46.16L17.88,45.49L16.79,44.74L15.61,43.94L14.45,43.09L13.45,42.23L12.71,41.39L12.32,40.61L12.33,39.91L12.75,39.32L13.54,38.85L14.65,38.51L15.98,38.29L17.41,38.14L18.83,38.04L20.11,37.93L21.16,37.76L21.89,37.48L22.27,37.07L22.28,36.48L21.95,35.71L21.36,34.77L20.60,33.70L19.76,32.54L18.96,31.35L18.31,30.20L17.91,29.16L17.81,28.29L18.05,27.63L18.65,27.22L19.55,27.06L20.71,27.12L22.04,27.36L23.44,27.71L24.80,28.10L26.05,28.43L27.09,28.63L27.87,28.63L28.36,28.36L28.57,27.81L28.53,26.98L28.30,25.90L27.94,24.63L27.55,23.25L27.21,21.86L26.99,20.55L26.97,19.44L27.18,18.59L27.63,18.05L28.33,17.87L29.24,18.03L30.30,18.48L31.47,19.16L32.66,19.97L33.81,20.80L34.87,21.54L35.78,22.08L36.51,22.34L37.07,22.27L37.45,21.82L37.70,21.03L37.85,19.93L37.95,18.61L38.06,17.18L38.21,15.76L38.45,14.46L38.81,13.40L39.30,12.67L39.91,12.33L40.62,12.40L41.42,12.85L42.27,13.64L43.13,14.68L43.98,15.85L44.78,17.02L45.51,18.08L46.18,18.90L46.78,19.40L47.33,19.51L47.85,19.23L48.35,18.57L48.87,17.59L49.41,16.39L50.00,15.08L50.63,13.79L51.30,12.66L52.00,11.78L52.71,11.26L53.40,11.15L54.05,11.46L54.65,12.16L55.17,13.19L55.63,14.46L56.02,15.85L56.37,17.23L56.70,18.47L57.05,19.47L57.44,20.14L57.92,20.44L58.50,20.35L59.20,19.90L60.02,19.16L60.95,18.21L61.94,17.18L62.98,16.19L64.00,15.35L64.95,14.77L65.79,14.53L66.48,14.66L66.99,15.17L67.31,16.03L67.45,17.18L67.44,18.53L67.34,19.97L67.20,21.38L67.08,22.66L67.06,23.72L67.21,24.49L67.55,24.93L68.13,25.05L68.94,24.86L69.97,24.44L71.16,23.87L72.45,23.25L73.76,22.67L75.00,22.23L76.10,22.01L76.97,22.07L77.58,22.42L77.88,23.08L77.88,24.00L77.62,25.13L77.15,26.39L76.56,27.71L75.95,28.99L75.40,30.16L75.02,31.14L74.89,31.91L75.07,32.45L75.57,32.75L76.40,32.86L77.50,32.81L78.82,32.68L80.24,32.54L81.67,32.44L82.99,32.46L84.10,32.63L84.90,32.98L85.34,33.52L85.40,34.24L85.09,35.10L84.46,36.08L83.59,37.11L82.59,38.14L81.57,39.13L80.66,40.04L79.96,40.84L79.58,41.52L79.56,42.08L79.93,42.54L80.67,42.92L81.72,43.26L83.00,43.59L84.39,43.94L85.77,44.33L87.00,44.80L87.98,45.34L88.62,45.94L88.85,46.60L88.66,47.30L88.07,48.00L87.15,48.70L85.98,49.37L84.68,50.00Z\"/><path d=\"M80.40,50.00L79.74,50.52L79.41,51.03L79.44,51.54L79.82,52.09L80.52,52.67L81.45,53.31L82.53,53.99L83.63,54.73L84.64,55.49L85.46,56.25L85.98,56.99L86.17,57.69L85.98,58.31L85.42,58.83L84.55,59.26L83.43,59.59L82.16,59.83L80.85,60.03L79.62,60.20L78.56,60.40L77.77,60.66L77.28,61.02L77.13,61.52L77.31,62.16L77.76,62.95L78.42,63.86L79.20,64.88L79.98,65.94L80.67,67.00L81.18,68.00L81.42,68.88L81.36,69.59L80.97,70.11L80.27,70.41L79.30,70.51L78.13,70.44L76.86,70.24L75.56,69.97L74.35,69.72L73.29,69.54L72.45,69.51L71.87,69.69L71.56,70.10L71.50,70.77L71.66,71.66L71.97,72.75L72.35,73.97L72.72,75.24L73.01,76.47L73.14,77.58L73.07,78.49L72.76,79.14L72.22,79.49L71.46,79.53L70.51,79.30L69.45,78.83L68.32,78.20L67.19,77.51L66.14,76.85L65.20,76.33L64.42,76.01L63.81,75.98L63.38,76.26L63.10,76.87L62.95,77.76L62.86,78.89L62.80,80.17L62.72,81.49L62.57,82.74L62.31,83.83L61.93,84.66L61.43,85.17L60.80,85.31L60.06,85.09L59.26,84.55L58.41,83.74L57.56,82.77L56.75,81.73L55.98,80.75L55.28,79.94L54.65,79.38L54.10,79.14L53.59,79.26L53.12,79.73L52.67,80.52L52.21,81.55L51.72,82.73L51.19,83.94L50.61,85.07L50.00,86.00L49.36,86.65L48.71,86.95L48.07,86.87L47.45,86.42L46.88,85.63L46.36,84.58L45.90,83.38L45.48,82.13L45.10,80.94L44.72,79.94L44.32,79.20L43.88,78.78L43.37,78.72L42.77,79.01L42.07,79.59L41.28,80.40L40.42,81.34L39.51,82.30L38.58,83.16L37.69,83.83L36.86,84.22L36.15,84.28L35.57,83.99L35.15,83.35L34.88,82.42L34.76,81.26L34.73,79.96L34.77,78.64L34.81,77.40L34.80,76.33L34.68,75.49L34.41,74.95L33.95,74.72L33.28,74.78L32.43,75.09L31.41,75.58L30.28,76.17L29.09,76.76L27.93,77.26L26.86,77.58L25.95,77.67L25.26,77.48L24.82,77.00L24.64,76.26L24.71,75.29L24.98,74.16L25.40,72.94L25.89,71.71L26.36,70.55L26.71,69.54L26.89,68.72L26.81,68.12L26.46,67.74L25.82,67.57L24.91,67.57L23.78,67.68L22.52,67.85L21.20,68.00L19.94,68.06L18.82,68.00L17.94,67.77L17.35,67.36L17.10,66.76L17.19,66.00L17.58,65.12L18.23,64.14L19.04,63.14L19.92,62.15L20.75,61.23L21.44,60.40L21.88,59.68L22.02,59.09L21.81,58.62L21.27,58.24L20.41,57.93L19.31,57.65L18.07,57.37L16.78,57.06L15.57,56.69L14.54,56.25L13.79,55.73L13.38,55.15L13.35,54.50L13.69,53.82L14.37,53.12L15.31,52.43L16.42,51.76L17.58,51.13L18.68,50.55L19.60,50.00L20.26,49.48L20.59,48.97L20.56,48.46L20.18,47.91L19.48,47.33L18.55,46.69L17.47,46.01L16.37,45.27L15.36,44.51L14.54,43.75L14.02,43.01L13.83,42.31L14.02,41.69L14.58,41.17L15.45,40.74L16.57,40.41L17.84,40.17L19.15,39.97L20.38,39.80L21.44,39.60L22.23,39.34L22.72,38.98L22.87,38.48L22.69,37.84L22.24,37.05L21.58,36.14L20.80,35.12L20.02,34.06L19.33,33.00L18.82,32.00L18.58,31.12L18.64,30.41L19.03,29.89L19.73,29.59L20.70,29.49L21.87,29.56L23.14,29.76L24.44,30.03L25.65,30.28L26.71,30.46L27.55,30.49L28.13,30.31L28.44,29.90L28.50,29.23L28.34,28.34L28.03,27.25L27.65,26.03L27.28,24.76L26.99,23.53L26.86,22.42L26.93,21.51L27.24,20.86L27.78,20.51L28.54,20.47L29.49,20.70L30.55,21.17L31.68,21.80L32.81,22.49L33.86,23.15L34.80,23.67L35.58,23.99L36.19,24.02L36.62,23.74L36.90,23.13L37.05,22.24L37.14,21.11L37.20,19.83L37.28,18.51L37.43,17.26L37.69,16.17L38.07,15.34L38.57,14.83L39.20,14.69L39.94,14.91L40.74,15.45L41.59,16.26L42.44,17.23L43.25,18.27L44.02,19.25L44.72,20.06L45.35,20.62L45.90,20.86L46.41,20.74L46.88,20.27L47.33,19.48L47.79,18.45L48.28,17.27L48.81,16.06L49.39,14.93L50.00,14.00L50.64,13.35L51.29,13.05L51.93,13.13L52.55,13.58L53.12,14.37L53.64,15.42L54.10,16.62L54.52,17.87L54.90,19.06L55.28,20.06L55.68,20.80L56.12,21.22L56.63,21.28L57.23,20.99L57.93,20.41L58.72,19.60L59.58,18.66L60.49,17.70L61.42,16.84L62.31,16.17L63.14,15.78L63.85,15.72L64.43,16.01L64.85,16.65L65.12,17.58L65.24,18.74L65.27,20.04L65.23,21.36L65.19,22.60L65.20,23.67L65.32,24.51L65.59,25.05L66.05,25.28L66.72,25.22L67.57,24.91L68.59,24.42L69.72,23.83L70.91,23.24L72.07,22.74L73.14,22.42L74.05,22.33L74.74,22.52L75.18,23.00L75.36,23.74L75.29,24.71L75.02,25.84L74.60,27.06L74.11,28.29L73.64,29.45L73.29,30.46L73.11,31.28L73.19,31.88L73.54,32.26L74.18,32.43L75.09,32.43L76.22,32.32L77.48,32.15L78.80,32.00L80.06,31.94L81.18,32.00L82.06,32.23L82.65,32.64L82.90,33.24L82.81,34.00L82.42,34.88L81.77,35.86L80.96,36.86L80.08,37.85L79.25,38.77L78.56,39.60L78.12,40.32L77.98,40.91L78.19,41.38L78.73,41.76L79.59,42.07L80.69,42.35L81.93,42.63L83.22,42.94L84.43,43.31L85.46,43.75L86.21,44.27L86.62,44.85L86.65,45.50L86.31,46.18L85.63,46.88L84.69,47.57L83.58,48.24L82.42,48.87L81.32,49.45L80.40,50.00Z\"/><path d=\"M78.21,50.00L78.43,50.50L78.95,51.01L79.72,51.56L80.67,52.14L81.68,52.77L82.66,53.43L83.50,54.11L84.13,54.80L84.46,55.46L84.46,56.08L84.13,56.63L83.48,57.12L82.58,57.52L81.50,57.85L80.33,58.13L79.19,58.37L78.16,58.61L77.33,58.88L76.77,59.22L76.50,59.65L76.54,60.19L76.86,60.85L77.40,61.63L78.08,62.50L78.82,63.44L79.51,64.40L80.08,65.32L80.43,66.18L80.51,66.91L80.31,67.50L79.80,67.91L79.03,68.14L78.04,68.21L76.91,68.15L75.72,68.01L74.56,67.85L73.52,67.72L72.65,67.69L72.00,67.82L71.61,68.13L71.46,68.65L71.53,69.39L71.77,70.30L72.11,71.35L72.48,72.48L72.81,73.62L73.02,74.69L73.06,75.61L72.89,76.33L72.49,76.81L71.88,77.02L71.07,76.97L70.12,76.70L69.08,76.26L68.01,75.72L66.98,75.17L66.04,74.69L65.23,74.37L64.58,74.27L64.10,74.43L63.78,74.87L63.60,75.58L63.51,76.52L63.48,77.63L63.44,78.82L63.36,80.00L63.19,81.07L62.91,81.95L62.50,82.57L61.97,82.88L61.32,82.87L60.58,82.55L59.78,81.97L58.95,81.20L58.13,80.33L57.35,79.46L56.62,78.69L55.97,78.11L55.40,77.79L54.90,77.78L54.45,78.08L54.03,78.69L53.63,79.54L53.21,80.57L52.77,81.68L52.29,82.76L51.77,83.71L51.20,84.44L50.61,84.88L50.00,84.99L49.39,84.76L48.81,84.21L48.25,83.39L47.74,82.38L47.26,81.28L46.83,80.20L46.41,79.22L46.00,78.46L45.57,77.96L45.10,77.78L44.57,77.91L43.98,78.34L43.30,79.00L42.56,79.83L41.77,80.71L40.95,81.57L40.13,82.28L39.35,82.78L38.64,82.99L38.03,82.88L37.54,82.46L37.18,81.74L36.94,80.78L36.80,79.65L36.73,78.46L36.69,77.29L36.63,76.24L36.51,75.37L36.27,74.76L35.90,74.43L35.36,74.37L34.65,74.57L33.79,74.96L32.81,75.48L31.76,76.05L30.70,76.57L29.69,76.96L28.78,77.16L28.04,77.11L27.51,76.81L27.19,76.24L27.10,75.44L27.20,74.45L27.45,73.35L27.80,72.20L28.16,71.09L28.47,70.08L28.64,69.23L28.63,68.57L28.39,68.13L27.90,67.89L27.17,67.84L26.23,67.91L25.13,68.07L23.95,68.24L22.78,68.36L21.69,68.38L20.77,68.26L20.09,67.97L19.69,67.50L19.59,66.86L19.78,66.07L20.21,65.18L20.83,64.23L21.54,63.27L22.26,62.35L22.90,61.50L23.36,60.77L23.57,60.15L23.50,59.65L23.12,59.26L22.45,58.95L21.54,58.70L20.45,58.47L19.29,58.23L18.14,57.94L17.11,57.59L16.29,57.17L15.75,56.66L15.54,56.08L15.66,55.44L16.10,54.76L16.81,54.07L17.72,53.39L18.72,52.74L19.71,52.12L20.60,51.54L21.28,51.00L21.69,50.49L21.79,50.00L21.57,49.50L21.05,48.99L20.28,48.44L19.33,47.86L18.32,47.23L17.34,46.57L16.50,45.89L15.87,45.20L15.54,44.54L15.54,43.92L15.87,43.37L16.52,42.88L17.42,42.48L18.50,42.15L19.67,41.87L20.81,41.63L21.84,41.39L22.67,41.12L23.23,40.78L23.50,40.35L23.46,39.81L23.14,39.15L22.60,38.37L21.92,37.50L21.18,36.56L20.49,35.60L19.92,34.68L19.57,33.82L19.49,33.09L19.69,32.50L20.20,32.09L20.97,31.86L21.96,31.79L23.09,31.85L24.28,31.99L25.44,32.15L26.48,32.28L27.35,32.31L28.00,32.18L28.39,31.87L28.54,31.35L28.47,30.61L28.23,29.70L27.89,28.65L27.52,27.52L27.19,26.38L26.98,25.31L26.94,24.39L27.11,23.67L27.51,23.19L28.12,22.98L28.93,23.03L29.88,23.30L30.92,23.74L31.99,24.28L33.02,24.83L33.96,25.31L34.77,25.63L35.42,25.73L35.90,25.57L36.22,25.13L36.40,24.42L36.49,23.48L36.52,22.37L36.56,21.18L36.64,20.00L36.81,18.93L37.09,18.05L37.50,17.43L38.03,17.12L38.68,17.13L39.42,17.45L40.22,18.03L41.05,18.80L41.87,19.67L42.65,20.54L43.38,21.31L44.03,21.89L44.60,22.21L45.10,22.22L45.55,21.92L45.97,21.31L46.37,20.46L46.79,19.43L47.23,18.32L47.71,17.24L48.23,16.29L48.80,15.56L49.39,15.12L50.00,15.01L50.61,15.24L51.19,15.79L51.75,16.61L52.26,17.62L52.74,18.72L53.17,19.80L53.59,20.78L54.00,21.54L54.43,22.04L54.90,22.22L55.43,22.09L56.02,21.66L56.70,21.00L57.44,20.17L58.23,19.29L59.05,18.43L59.87,17.72L60.65,17.22L61.36,17.01L61.97,17.12L62.46,17.54L62.82,18.26L63.06,19.22L63.20,20.35L63.27,21.54L63.31,22.71L63.37,23.76L63.49,24.63L63.73,25.24L64.10,25.57L64.64,25.63L65.35,25.43L66.21,25.04L67.19,24.52L68.24,23.95L69.30,23.43L70.31,23.04L71.22,22.84L71.96,22.89L72.49,23.19L72.81,23.76L72.90,24.56L72.80,25.55L72.55,26.65L72.20,27.80L71.84,28.91L71.53,29.92L71.36,30.77L71.37,31.43L71.61,31.87L72.10,32.11L72.83,32.16L73.77,32.09L74.87,31.93L76.05,31.76L77.22,31.64L78.31,31.62L79.23,31.74L79.91,32.03L80.31,32.50L80.41,33.14L80.22,33.93L79.79,34.82L79.17,35.77L78.46,36.73L77.74,37.65L77.10,38.50L76.64,39.23L76.43,39.85L76.50,40.35L76.88,40.74L77.55,41.05L78.46,41.30L79.55,41.53L80.71,41.77L81.86,42.06L82.89,42.41L83.71,42.83L84.25,43.34L84.46,43.92L84.34,44.56L83.90,45.24L83.19,45.93L82.28,46.61L81.28,47.26L80.29,47.88L79.40,48.46L78.72,49.00L78.31,49.51L78.21,50.00Z\"/><circle cx=\"50\" cy=\"50\" r=\"28\" stroke-width=\".8\"/><circle cx=\"50\" cy=\"50\" r=\"25.5\" stroke-width=\".45\"/></g><g transform=\"translate(23 23) scale(.54)\" fill=\"currentColor\" style=\"--seal-paper:var(--ex-paper)\"><path d=\"M46 35C34 33 26 19 14 17c-1 13 9 24 22 28-16-3-20-9-26-10 1 14 16 24 31 25L30 78l20-8 20 8-11-18c15-1 30-11 31-25-6 1-10 7-26 10 13-4 23-15 22-28-12 2-20 16-32 18l1-9 9-3-8-5H44l-3 8Z\" fill=\"currentColor\"/>\n   <path d=\"M40 42h20v14c0 10-10 17-10 17S40 66 40 56Z\" fill=\"var(--seal-paper)\"/>\n   <path d=\"M44 47h12m-12 5h12m-12 5h12m-8-14v20m4-20v20M23 31l13 9m41-9-13 9M19 43l16 9m46-9-16 9\" stroke=\"currentColor\" stroke-width=\"1.8\" fill=\"none\"/></g>",
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\"><path d=\"M93.00,50.00L92.75,50.75L92.02,51.47L90.88,52.14L89.45,52.76L87.86,53.31L86.26,53.81L84.80,54.27L83.62,54.73L82.84,55.20L82.50,55.73L82.63,56.34L83.21,57.06L84.16,57.89L85.37,58.82L86.71,59.84L88.01,60.90L89.15,61.97L89.99,62.99L90.43,63.92L90.41,64.71L89.92,65.32L88.98,65.75L87.68,66.00L86.13,66.08L84.44,66.06L82.77,65.98L81.24,65.92L79.98,65.94L79.08,66.12L78.58,66.50L78.50,67.12L78.80,67.99L79.40,69.10L80.22,70.39L81.13,71.80L81.99,73.24L82.70,74.64L83.13,75.89L83.23,76.91L82.94,77.64L82.27,78.05L81.25,78.13L79.94,77.92L78.45,77.47L76.87,76.87L75.32,76.22L73.91,75.64L72.72,75.23L71.81,75.09L71.21,75.28L70.92,75.84L70.90,76.76L71.10,78.00L71.43,79.49L71.80,81.13L72.11,82.78L72.30,84.33L72.28,85.66L72.02,86.65L71.50,87.24L70.73,87.39L69.74,87.12L68.59,86.48L67.34,85.54L66.06,84.44L64.83,83.30L63.70,82.27L62.72,81.48L61.91,81.04L61.29,81.01L60.82,81.43L60.49,82.29L60.25,83.53L60.05,85.04L59.84,86.71L59.57,88.37L59.21,89.89L58.74,91.13L58.16,91.97L57.47,92.35L56.69,92.23L55.85,91.64L54.99,90.63L54.13,89.33L53.31,87.86L52.54,86.37L51.83,85.01L51.19,83.93L50.58,83.24L50.00,83.00L49.42,83.24L48.81,83.93L48.17,85.01L47.46,86.37L46.69,87.86L45.87,89.33L45.01,90.63L44.15,91.64L43.31,92.23L42.53,92.35L41.84,91.97L41.26,91.13L40.79,89.89L40.43,88.37L40.16,86.71L39.95,85.04L39.75,83.53L39.51,82.29L39.18,81.43L38.71,81.01L38.09,81.04L37.28,81.48L36.30,82.27L35.17,83.30L33.94,84.44L32.66,85.54L31.41,86.48L30.26,87.12L29.27,87.39L28.50,87.24L27.98,86.65L27.72,85.66L27.70,84.33L27.89,82.78L28.20,81.13L28.57,79.49L28.90,78.00L29.10,76.76L29.08,75.84L28.79,75.28L28.19,75.09L27.28,75.23L26.09,75.64L24.68,76.22L23.13,76.87L21.55,77.47L20.06,77.92L18.75,78.13L17.73,78.05L17.06,77.64L16.77,76.91L16.87,75.89L17.30,74.64L18.01,73.24L18.87,71.80L19.78,70.39L20.60,69.10L21.20,67.99L21.50,67.12L21.42,66.50L20.92,66.12L20.02,65.94L18.76,65.92L17.23,65.98L15.56,66.06L13.87,66.08L12.32,66.00L11.02,65.75L10.08,65.32L9.59,64.71L9.57,63.92L10.01,62.99L10.85,61.97L11.99,60.90L13.29,59.84L14.63,58.82L15.84,57.89L16.79,57.06L17.37,56.34L17.50,55.73L17.16,55.20L16.38,54.73L15.20,54.27L13.74,53.81L12.14,53.31L10.55,52.76L9.12,52.14L7.98,51.47L7.25,50.75L7.00,50.00L7.25,49.25L7.98,48.53L9.12,47.86L10.55,47.24L12.14,46.69L13.74,46.19L15.20,45.73L16.38,45.27L17.16,44.80L17.50,44.27L17.37,43.66L16.79,42.94L15.84,42.11L14.63,41.18L13.29,40.16L11.99,39.10L10.85,38.03L10.01,37.01L9.57,36.08L9.59,35.29L10.08,34.68L11.02,34.25L12.32,34.00L13.87,33.92L15.56,33.94L17.23,34.02L18.76,34.08L20.02,34.06L20.92,33.88L21.42,33.50L21.50,32.88L21.20,32.01L20.60,30.90L19.78,29.61L18.87,28.20L18.01,26.76L17.30,25.36L16.87,24.11L16.77,23.09L17.06,22.36L17.73,21.95L18.75,21.87L20.06,22.08L21.55,22.53L23.13,23.13L24.68,23.78L26.09,24.36L27.28,24.77L28.19,24.91L28.79,24.72L29.08,24.16L29.10,23.24L28.90,22.00L28.57,20.51L28.20,18.87L27.89,17.22L27.70,15.67L27.72,14.34L27.98,13.35L28.50,12.76L29.27,12.61L30.26,12.88L31.41,13.52L32.66,14.46L33.94,15.56L35.17,16.70L36.30,17.73L37.28,18.52L38.09,18.96L38.71,18.99L39.18,18.57L39.51,17.71L39.75,16.47L39.95,14.96L40.16,13.29L40.43,11.63L40.79,10.11L41.26,8.87L41.84,8.03L42.53,7.65L43.31,7.77L44.15,8.36L45.01,9.37L45.87,10.67L46.69,12.14L47.46,13.63L48.17,14.99L48.81,16.07L49.42,16.76L50.00,17.00L50.58,16.76L51.19,16.07L51.83,14.99L52.54,13.63L53.31,12.14L54.13,10.67L54.99,9.37L55.85,8.36L56.69,7.77L57.47,7.65L58.16,8.03L58.74,8.87L59.21,10.11L59.57,11.63L59.84,13.29L60.05,14.96L60.25,16.47L60.49,17.71L60.82,18.57L61.29,18.99L61.91,18.96L62.72,18.52L63.70,17.73L64.83,16.70L66.06,15.56L67.34,14.46L68.59,13.52L69.74,12.88L70.73,12.61L71.50,12.76L72.02,13.35L72.28,14.34L72.30,15.67L72.11,17.22L71.80,18.87L71.43,20.51L71.10,22.00L70.90,23.24L70.92,24.16L71.21,24.72L71.81,24.91L72.72,24.77L73.91,24.36L75.32,23.78L76.87,23.13L78.45,22.53L79.94,22.08L81.25,21.87L82.27,21.95L82.94,22.36L83.23,23.09L83.13,24.11L82.70,25.36L81.99,26.76L81.13,28.20L80.22,29.61L79.40,30.90L78.80,32.01L78.50,32.88L78.58,33.50L79.08,33.88L79.98,34.06L81.24,34.08L82.77,34.02L84.44,33.94L86.13,33.92L87.68,34.00L88.98,34.25L89.92,34.68L90.41,35.29L90.43,36.08L89.99,37.01L89.15,38.03L88.01,39.10L86.71,40.16L85.37,41.18L84.16,42.11L83.21,42.94L82.63,43.66L82.50,44.27L82.84,44.80L83.62,45.27L84.80,45.73L86.26,46.19L87.86,46.69L89.45,47.24L90.88,47.86L92.02,48.53L92.75,49.25L93.00,50.00Z\"/><path d=\"M89.60,50.00L88.42,50.67L87.03,51.29L85.57,51.86L84.17,52.39L82.97,52.88L82.09,53.37L81.61,53.88L81.56,54.44L81.93,55.06L82.69,55.76L83.74,56.56L84.97,57.43L86.23,58.36L87.40,59.33L88.35,60.28L88.96,61.17L89.16,61.97L88.93,62.65L88.26,63.17L87.22,63.55L85.88,63.77L84.36,63.88L82.78,63.92L81.29,63.93L80.00,63.99L79.01,64.15L78.38,64.46L78.14,64.96L78.28,65.68L78.75,66.60L79.46,67.70L80.32,68.94L81.19,70.25L81.96,71.56L82.52,72.77L82.79,73.82L82.71,74.65L82.26,75.20L81.45,75.47L80.34,75.46L79.00,75.21L77.54,74.79L76.05,74.29L74.64,73.79L73.41,73.41L72.42,73.21L71.72,73.29L71.32,73.68L71.21,74.40L71.34,75.43L71.63,76.71L72.01,78.17L72.38,79.70L72.66,81.19L72.77,82.52L72.66,83.60L72.30,84.35L71.69,84.71L70.84,84.69L69.80,84.30L68.63,83.61L67.40,82.72L66.17,81.73L65.02,80.79L63.99,80.00L63.13,79.48L62.44,79.31L61.94,79.55L61.59,80.18L61.35,81.19L61.19,82.50L61.05,84.00L60.87,85.56L60.63,87.05L60.28,88.35L59.80,89.32L59.21,89.90L58.51,90.04L57.72,89.72L56.88,89.00L56.01,87.96L55.16,86.69L54.34,85.35L53.58,84.06L52.88,82.97L52.25,82.19L51.67,81.80L51.11,81.85L50.56,82.33L50.00,83.20L49.40,84.37L48.75,85.73L48.05,87.13L47.31,88.45L46.54,89.55L45.76,90.31L45.01,90.65L44.30,90.53L43.67,89.97L43.12,89.00L42.67,87.72L42.30,86.24L41.99,84.70L41.71,83.23L41.43,81.97L41.10,81.02L40.69,80.46L40.15,80.31L39.47,80.57L38.65,81.19L37.68,82.09L36.61,83.14L35.47,84.23L34.32,85.22L33.22,85.98L32.23,86.43L31.41,86.49L30.78,86.14L30.38,85.39L30.20,84.30L30.21,82.94L30.36,81.42L30.60,79.87L30.85,78.40L31.01,77.11L31.03,76.11L30.83,75.43L30.38,75.11L29.65,75.13L28.66,75.43L27.45,75.94L26.08,76.57L24.64,77.20L23.22,77.73L21.93,78.07L20.85,78.15L20.05,77.93L19.58,77.39L19.46,76.55L19.66,75.46L20.14,74.18L20.80,72.81L21.56,71.43L22.29,70.13L22.89,68.99L23.25,68.05L23.29,67.34L22.97,66.89L22.29,66.65L21.25,66.60L19.94,66.66L18.44,66.78L16.87,66.88L15.35,66.90L14.02,66.78L12.98,66.48L12.30,66.00L12.05,65.33L12.22,64.50L12.78,63.55L13.67,62.51L14.76,61.45L15.94,60.41L17.07,59.44L18.03,58.57L18.69,57.81L18.97,57.16L18.83,56.63L18.26,56.17L17.31,55.76L16.05,55.38L14.60,54.97L13.09,54.53L11.66,54.03L10.45,53.46L9.57,52.83L9.10,52.14L9.09,51.43L9.54,50.71L10.40,50.00L11.58,49.33L12.97,48.71L14.43,48.14L15.83,47.61L17.03,47.12L17.91,46.63L18.39,46.12L18.44,45.56L18.07,44.94L17.31,44.24L16.26,43.44L15.03,42.57L13.77,41.64L12.60,40.67L11.65,39.72L11.04,38.83L10.84,38.03L11.07,37.35L11.74,36.83L12.78,36.45L14.12,36.23L15.64,36.12L17.22,36.08L18.71,36.07L20.00,36.01L20.99,35.85L21.62,35.54L21.86,35.04L21.72,34.32L21.25,33.40L20.54,32.30L19.68,31.06L18.81,29.75L18.04,28.44L17.48,27.23L17.21,26.18L17.29,25.35L17.74,24.80L18.55,24.53L19.66,24.54L21.00,24.79L22.46,25.21L23.95,25.71L25.36,26.21L26.59,26.59L27.58,26.79L28.28,26.71L28.68,26.32L28.79,25.60L28.66,24.57L28.37,23.29L27.99,21.83L27.62,20.30L27.34,18.81L27.23,17.48L27.34,16.40L27.70,15.65L28.31,15.29L29.16,15.31L30.20,15.70L31.37,16.39L32.60,17.28L33.83,18.27L34.98,19.21L36.01,20.00L36.87,20.52L37.56,20.69L38.06,20.45L38.41,19.82L38.65,18.81L38.81,17.50L38.95,16.00L39.13,14.44L39.37,12.95L39.72,11.65L40.20,10.68L40.79,10.10L41.49,9.96L42.28,10.28L43.12,11.00L43.99,12.04L44.84,13.31L45.66,14.65L46.42,15.94L47.12,17.03L47.75,17.81L48.33,18.20L48.89,18.15L49.44,17.67L50.00,16.80L50.60,15.63L51.25,14.27L51.95,12.87L52.69,11.55L53.46,10.45L54.24,9.69L54.99,9.35L55.70,9.47L56.33,10.03L56.88,11.00L57.33,12.28L57.70,13.76L58.01,15.30L58.29,16.77L58.57,18.03L58.90,18.98L59.31,19.54L59.85,19.69L60.53,19.43L61.35,18.81L62.32,17.91L63.39,16.86L64.53,15.77L65.68,14.78L66.78,14.02L67.77,13.57L68.59,13.51L69.22,13.86L69.62,14.61L69.80,15.70L69.79,17.06L69.64,18.58L69.40,20.13L69.15,21.60L68.99,22.89L68.97,23.89L69.17,24.57L69.62,24.89L70.35,24.87L71.34,24.57L72.55,24.06L73.92,23.43L75.36,22.80L76.78,22.27L78.07,21.93L79.15,21.85L79.95,22.07L80.42,22.61L80.54,23.45L80.34,24.54L79.86,25.82L79.20,27.19L78.44,28.57L77.71,29.87L77.11,31.01L76.75,31.95L76.71,32.66L77.03,33.11L77.71,33.35L78.75,33.40L80.06,33.34L81.56,33.22L83.13,33.12L84.65,33.10L85.98,33.22L87.02,33.52L87.70,34.00L87.95,34.67L87.78,35.50L87.22,36.45L86.33,37.49L85.24,38.55L84.06,39.59L82.93,40.56L81.97,41.43L81.31,42.19L81.03,42.84L81.17,43.37L81.74,43.83L82.69,44.24L83.95,44.62L85.40,45.03L86.91,45.47L88.34,45.97L89.55,46.54L90.43,47.17L90.90,47.86L90.91,48.57L90.46,49.29L89.60,50.00Z\"/><path d=\"M84.68,50.00L83.38,50.58L82.21,51.12L81.29,51.64L80.69,52.15L80.49,52.67L80.68,53.22L81.24,53.84L82.12,54.51L83.21,55.26L84.39,56.06L85.55,56.91L86.55,57.77L87.29,58.61L87.68,59.39L87.67,60.09L87.25,60.68L86.46,61.15L85.35,61.49L84.02,61.71L82.59,61.86L81.17,61.96L79.89,62.07L78.84,62.24L78.11,62.52L77.73,62.93L77.72,63.52L78.05,64.29L78.64,65.23L79.40,66.30L80.24,67.46L81.04,68.65L81.69,69.80L82.09,70.84L82.19,71.71L81.95,72.37L81.35,72.78L80.45,72.94L79.29,72.88L77.96,72.64L76.56,72.29L75.20,71.90L73.95,71.57L72.91,71.37L72.13,71.37L71.64,71.64L71.43,72.19L71.47,73.02L71.70,74.10L72.06,75.37L72.45,76.75L72.79,78.14L73.01,79.45L73.03,80.56L72.82,81.41L72.37,81.95L71.67,82.13L70.76,81.97L69.70,81.52L68.53,80.84L67.34,80.03L66.19,79.20L65.13,78.46L64.22,77.92L63.49,77.66L62.93,77.73L62.55,78.18L62.30,78.97L62.15,80.07L62.05,81.39L61.94,82.82L61.79,84.24L61.55,85.54L61.19,86.60L60.70,87.33L60.09,87.67L59.38,87.60L58.58,87.15L57.73,86.36L56.87,85.32L56.02,84.15L55.22,82.98L54.49,81.92L53.82,81.10L53.22,80.60L52.67,80.49L52.15,80.77L51.65,81.43L51.13,82.41L50.59,83.61L50.00,84.92L49.37,86.21L48.70,87.34L48.00,88.22L47.29,88.74L46.60,88.85L45.95,88.54L45.35,87.84L44.83,86.81L44.37,85.54L43.98,84.15L43.63,82.77L43.30,81.53L42.95,80.53L42.56,79.86L42.08,79.56L41.50,79.65L40.80,80.10L39.98,80.84L39.05,81.79L38.06,82.82L37.02,83.81L36.00,84.65L35.05,85.23L34.21,85.47L33.52,85.34L33.01,84.83L32.69,83.97L32.55,82.82L32.56,81.47L32.66,80.03L32.80,78.62L32.92,77.34L32.94,76.28L32.79,75.51L32.45,75.07L31.87,74.95L31.06,75.14L30.03,75.56L28.84,76.13L27.55,76.75L26.24,77.33L25.00,77.77L23.90,77.99L23.03,77.93L22.42,77.58L22.12,76.92L22.12,76.00L22.38,74.87L22.85,73.61L23.44,72.29L24.05,71.01L24.60,69.84L24.98,68.86L25.11,68.09L24.93,67.55L24.43,67.25L23.60,67.14L22.50,67.19L21.18,67.32L19.76,67.46L18.33,67.56L17.01,67.54L15.90,67.37L15.10,67.02L14.66,66.48L14.60,65.76L14.91,64.90L15.54,63.92L16.41,62.89L17.41,61.86L18.43,60.87L19.34,59.96L20.04,59.16L20.42,58.48L20.44,57.92L20.07,57.46L19.33,57.08L18.28,56.74L17.00,56.41L15.61,56.06L14.23,55.67L13.00,55.20L12.02,54.66L11.38,54.06L11.15,53.40L11.34,52.70L11.93,52.00L12.85,51.30L14.02,50.63L15.32,50.00L16.62,49.42L17.79,48.88L18.71,48.36L19.31,47.85L19.51,47.33L19.32,46.78L18.76,46.16L17.88,45.49L16.79,44.74L15.61,43.94L14.45,43.09L13.45,42.23L12.71,41.39L12.32,40.61L12.33,39.91L12.75,39.32L13.54,38.85L14.65,38.51L15.98,38.29L17.41,38.14L18.83,38.04L20.11,37.93L21.16,37.76L21.89,37.48L22.27,37.07L22.28,36.48L21.95,35.71L21.36,34.77L20.60,33.70L19.76,32.54L18.96,31.35L18.31,30.20L17.91,29.16L17.81,28.29L18.05,27.63L18.65,27.22L19.55,27.06L20.71,27.12L22.04,27.36L23.44,27.71L24.80,28.10L26.05,28.43L27.09,28.63L27.87,28.63L28.36,28.36L28.57,27.81L28.53,26.98L28.30,25.90L27.94,24.63L27.55,23.25L27.21,21.86L26.99,20.55L26.97,19.44L27.18,18.59L27.63,18.05L28.33,17.87L29.24,18.03L30.30,18.48L31.47,19.16L32.66,19.97L33.81,20.80L34.87,21.54L35.78,22.08L36.51,22.34L37.07,22.27L37.45,21.82L37.70,21.03L37.85,19.93L37.95,18.61L38.06,17.18L38.21,15.76L38.45,14.46L38.81,13.40L39.30,12.67L39.91,12.33L40.62,12.40L41.42,12.85L42.27,13.64L43.13,14.68L43.98,15.85L44.78,17.02L45.51,18.08L46.18,18.90L46.78,19.40L47.33,19.51L47.85,19.23L48.35,18.57L48.87,17.59L49.41,16.39L50.00,15.08L50.63,13.79L51.30,12.66L52.00,11.78L52.71,11.26L53.40,11.15L54.05,11.46L54.65,12.16L55.17,13.19L55.63,14.46L56.02,15.85L56.37,17.23L56.70,18.47L57.05,19.47L57.44,20.14L57.92,20.44L58.50,20.35L59.20,19.90L60.02,19.16L60.95,18.21L61.94,17.18L62.98,16.19L64.00,15.35L64.95,14.77L65.79,14.53L66.48,14.66L66.99,15.17L67.31,16.03L67.45,17.18L67.44,18.53L67.34,19.97L67.20,21.38L67.08,22.66L67.06,23.72L67.21,24.49L67.55,24.93L68.13,25.05L68.94,24.86L69.97,24.44L71.16,23.87L72.45,23.25L73.76,22.67L75.00,22.23L76.10,22.01L76.97,22.07L77.58,22.42L77.88,23.08L77.88,24.00L77.62,25.13L77.15,26.39L76.56,27.71L75.95,28.99L75.40,30.16L75.02,31.14L74.89,31.91L75.07,32.45L75.57,32.75L76.40,32.86L77.50,32.81L78.82,32.68L80.24,32.54L81.67,32.44L82.99,32.46L84.10,32.63L84.90,32.98L85.34,33.52L85.40,34.24L85.09,35.10L84.46,36.08L83.59,37.11L82.59,38.14L81.57,39.13L80.66,40.04L79.96,40.84L79.58,41.52L79.56,42.08L79.93,42.54L80.67,42.92L81.72,43.26L83.00,43.59L84.39,43.94L85.77,44.33L87.00,44.80L87.98,45.34L88.62,45.94L88.85,46.60L88.66,47.30L88.07,48.00L87.15,48.70L85.98,49.37L84.68,50.00Z\"/><path d=\"M80.40,50.00L79.74,50.52L79.41,51.03L79.44,51.54L79.82,52.09L80.52,52.67L81.45,53.31L82.53,53.99L83.63,54.73L84.64,55.49L85.46,56.25L85.98,56.99L86.17,57.69L85.98,58.31L85.42,58.83L84.55,59.26L83.43,59.59L82.16,59.83L80.85,60.03L79.62,60.20L78.56,60.40L77.77,60.66L77.28,61.02L77.13,61.52L77.31,62.16L77.76,62.95L78.42,63.86L79.20,64.88L79.98,65.94L80.67,67.00L81.18,68.00L81.42,68.88L81.36,69.59L80.97,70.11L80.27,70.41L79.30,70.51L78.13,70.44L76.86,70.24L75.56,69.97L74.35,69.72L73.29,69.54L72.45,69.51L71.87,69.69L71.56,70.10L71.50,70.77L71.66,71.66L71.97,72.75L72.35,73.97L72.72,75.24L73.01,76.47L73.14,77.58L73.07,78.49L72.76,79.14L72.22,79.49L71.46,79.53L70.51,79.30L69.45,78.83L68.32,78.20L67.19,77.51L66.14,76.85L65.20,76.33L64.42,76.01L63.81,75.98L63.38,76.26L63.10,76.87L62.95,77.76L62.86,78.89L62.80,80.17L62.72,81.49L62.57,82.74L62.31,83.83L61.93,84.66L61.43,85.17L60.80,85.31L60.06,85.09L59.26,84.55L58.41,83.74L57.56,82.77L56.75,81.73L55.98,80.75L55.28,79.94L54.65,79.38L54.10,79.14L53.59,79.26L53.12,79.73L52.67,80.52L52.21,81.55L51.72,82.73L51.19,83.94L50.61,85.07L50.00,86.00L49.36,86.65L48.71,86.95L48.07,86.87L47.45,86.42L46.88,85.63L46.36,84.58L45.90,83.38L45.48,82.13L45.10,80.94L44.72,79.94L44.32,79.20L43.88,78.78L43.37,78.72L42.77,79.01L42.07,79.59L41.28,80.40L40.42,81.34L39.51,82.30L38.58,83.16L37.69,83.83L36.86,84.22L36.15,84.28L35.57,83.99L35.15,83.35L34.88,82.42L34.76,81.26L34.73,79.96L34.77,78.64L34.81,77.40L34.80,76.33L34.68,75.49L34.41,74.95L33.95,74.72L33.28,74.78L32.43,75.09L31.41,75.58L30.28,76.17L29.09,76.76L27.93,77.26L26.86,77.58L25.95,77.67L25.26,77.48L24.82,77.00L24.64,76.26L24.71,75.29L24.98,74.16L25.40,72.94L25.89,71.71L26.36,70.55L26.71,69.54L26.89,68.72L26.81,68.12L26.46,67.74L25.82,67.57L24.91,67.57L23.78,67.68L22.52,67.85L21.20,68.00L19.94,68.06L18.82,68.00L17.94,67.77L17.35,67.36L17.10,66.76L17.19,66.00L17.58,65.12L18.23,64.14L19.04,63.14L19.92,62.15L20.75,61.23L21.44,60.40L21.88,59.68L22.02,59.09L21.81,58.62L21.27,58.24L20.41,57.93L19.31,57.65L18.07,57.37L16.78,57.06L15.57,56.69L14.54,56.25L13.79,55.73L13.38,55.15L13.35,54.50L13.69,53.82L14.37,53.12L15.31,52.43L16.42,51.76L17.58,51.13L18.68,50.55L19.60,50.00L20.26,49.48L20.59,48.97L20.56,48.46L20.18,47.91L19.48,47.33L18.55,46.69L17.47,46.01L16.37,45.27L15.36,44.51L14.54,43.75L14.02,43.01L13.83,42.31L14.02,41.69L14.58,41.17L15.45,40.74L16.57,40.41L17.84,40.17L19.15,39.97L20.38,39.80L21.44,39.60L22.23,39.34L22.72,38.98L22.87,38.48L22.69,37.84L22.24,37.05L21.58,36.14L20.80,35.12L20.02,34.06L19.33,33.00L18.82,32.00L18.58,31.12L18.64,30.41L19.03,29.89L19.73,29.59L20.70,29.49L21.87,29.56L23.14,29.76L24.44,30.03L25.65,30.28L26.71,30.46L27.55,30.49L28.13,30.31L28.44,29.90L28.50,29.23L28.34,28.34L28.03,27.25L27.65,26.03L27.28,24.76L26.99,23.53L26.86,22.42L26.93,21.51L27.24,20.86L27.78,20.51L28.54,20.47L29.49,20.70L30.55,21.17L31.68,21.80L32.81,22.49L33.86,23.15L34.80,23.67L35.58,23.99L36.19,24.02L36.62,23.74L36.90,23.13L37.05,22.24L37.14,21.11L37.20,19.83L37.28,18.51L37.43,17.26L37.69,16.17L38.07,15.34L38.57,14.83L39.20,14.69L39.94,14.91L40.74,15.45L41.59,16.26L42.44,17.23L43.25,18.27L44.02,19.25L44.72,20.06L45.35,20.62L45.90,20.86L46.41,20.74L46.88,20.27L47.33,19.48L47.79,18.45L48.28,17.27L48.81,16.06L49.39,14.93L50.00,14.00L50.64,13.35L51.29,13.05L51.93,13.13L52.55,13.58L53.12,14.37L53.64,15.42L54.10,16.62L54.52,17.87L54.90,19.06L55.28,20.06L55.68,20.80L56.12,21.22L56.63,21.28L57.23,20.99L57.93,20.41L58.72,19.60L59.58,18.66L60.49,17.70L61.42,16.84L62.31,16.17L63.14,15.78L63.85,15.72L64.43,16.01L64.85,16.65L65.12,17.58L65.24,18.74L65.27,20.04L65.23,21.36L65.19,22.60L65.20,23.67L65.32,24.51L65.59,25.05L66.05,25.28L66.72,25.22L67.57,24.91L68.59,24.42L69.72,23.83L70.91,23.24L72.07,22.74L73.14,22.42L74.05,22.33L74.74,22.52L75.18,23.00L75.36,23.74L75.29,24.71L75.02,25.84L74.60,27.06L74.11,28.29L73.64,29.45L73.29,30.46L73.11,31.28L73.19,31.88L73.54,32.26L74.18,32.43L75.09,32.43L76.22,32.32L77.48,32.15L78.80,32.00L80.06,31.94L81.18,32.00L82.06,32.23L82.65,32.64L82.90,33.24L82.81,34.00L82.42,34.88L81.77,35.86L80.96,36.86L80.08,37.85L79.25,38.77L78.56,39.60L78.12,40.32L77.98,40.91L78.19,41.38L78.73,41.76L79.59,42.07L80.69,42.35L81.93,42.63L83.22,42.94L84.43,43.31L85.46,43.75L86.21,44.27L86.62,44.85L86.65,45.50L86.31,46.18L85.63,46.88L84.69,47.57L83.58,48.24L82.42,48.87L81.32,49.45L80.40,50.00Z\"/><path d=\"M78.21,50.00L78.43,50.50L78.95,51.01L79.72,51.56L80.67,52.14L81.68,52.77L82.66,53.43L83.50,54.11L84.13,54.80L84.46,55.46L84.46,56.08L84.13,56.63L83.48,57.12L82.58,57.52L81.50,57.85L80.33,58.13L79.19,58.37L78.16,58.61L77.33,58.88L76.77,59.22L76.50,59.65L76.54,60.19L76.86,60.85L77.40,61.63L78.08,62.50L78.82,63.44L79.51,64.40L80.08,65.32L80.43,66.18L80.51,66.91L80.31,67.50L79.80,67.91L79.03,68.14L78.04,68.21L76.91,68.15L75.72,68.01L74.56,67.85L73.52,67.72L72.65,67.69L72.00,67.82L71.61,68.13L71.46,68.65L71.53,69.39L71.77,70.30L72.11,71.35L72.48,72.48L72.81,73.62L73.02,74.69L73.06,75.61L72.89,76.33L72.49,76.81L71.88,77.02L71.07,76.97L70.12,76.70L69.08,76.26L68.01,75.72L66.98,75.17L66.04,74.69L65.23,74.37L64.58,74.27L64.10,74.43L63.78,74.87L63.60,75.58L63.51,76.52L63.48,77.63L63.44,78.82L63.36,80.00L63.19,81.07L62.91,81.95L62.50,82.57L61.97,82.88L61.32,82.87L60.58,82.55L59.78,81.97L58.95,81.20L58.13,80.33L57.35,79.46L56.62,78.69L55.97,78.11L55.40,77.79L54.90,77.78L54.45,78.08L54.03,78.69L53.63,79.54L53.21,80.57L52.77,81.68L52.29,82.76L51.77,83.71L51.20,84.44L50.61,84.88L50.00,84.99L49.39,84.76L48.81,84.21L48.25,83.39L47.74,82.38L47.26,81.28L46.83,80.20L46.41,79.22L46.00,78.46L45.57,77.96L45.10,77.78L44.57,77.91L43.98,78.34L43.30,79.00L42.56,79.83L41.77,80.71L40.95,81.57L40.13,82.28L39.35,82.78L38.64,82.99L38.03,82.88L37.54,82.46L37.18,81.74L36.94,80.78L36.80,79.65L36.73,78.46L36.69,77.29L36.63,76.24L36.51,75.37L36.27,74.76L35.90,74.43L35.36,74.37L34.65,74.57L33.79,74.96L32.81,75.48L31.76,76.05L30.70,76.57L29.69,76.96L28.78,77.16L28.04,77.11L27.51,76.81L27.19,76.24L27.10,75.44L27.20,74.45L27.45,73.35L27.80,72.20L28.16,71.09L28.47,70.08L28.64,69.23L28.63,68.57L28.39,68.13L27.90,67.89L27.17,67.84L26.23,67.91L25.13,68.07L23.95,68.24L22.78,68.36L21.69,68.38L20.77,68.26L20.09,67.97L19.69,67.50L19.59,66.86L19.78,66.07L20.21,65.18L20.83,64.23L21.54,63.27L22.26,62.35L22.90,61.50L23.36,60.77L23.57,60.15L23.50,59.65L23.12,59.26L22.45,58.95L21.54,58.70L20.45,58.47L19.29,58.23L18.14,57.94L17.11,57.59L16.29,57.17L15.75,56.66L15.54,56.08L15.66,55.44L16.10,54.76L16.81,54.07L17.72,53.39L18.72,52.74L19.71,52.12L20.60,51.54L21.28,51.00L21.69,50.49L21.79,50.00L21.57,49.50L21.05,48.99L20.28,48.44L19.33,47.86L18.32,47.23L17.34,46.57L16.50,45.89L15.87,45.20L15.54,44.54L15.54,43.92L15.87,43.37L16.52,42.88L17.42,42.48L18.50,42.15L19.67,41.87L20.81,41.63L21.84,41.39L22.67,41.12L23.23,40.78L23.50,40.35L23.46,39.81L23.14,39.15L22.60,38.37L21.92,37.50L21.18,36.56L20.49,35.60L19.92,34.68L19.57,33.82L19.49,33.09L19.69,32.50L20.20,32.09L20.97,31.86L21.96,31.79L23.09,31.85L24.28,31.99L25.44,32.15L26.48,32.28L27.35,32.31L28.00,32.18L28.39,31.87L28.54,31.35L28.47,30.61L28.23,29.70L27.89,28.65L27.52,27.52L27.19,26.38L26.98,25.31L26.94,24.39L27.11,23.67L27.51,23.19L28.12,22.98L28.93,23.03L29.88,23.30L30.92,23.74L31.99,24.28L33.02,24.83L33.96,25.31L34.77,25.63L35.42,25.73L35.90,25.57L36.22,25.13L36.40,24.42L36.49,23.48L36.52,22.37L36.56,21.18L36.64,20.00L36.81,18.93L37.09,18.05L37.50,17.43L38.03,17.12L38.68,17.13L39.42,17.45L40.22,18.03L41.05,18.80L41.87,19.67L42.65,20.54L43.38,21.31L44.03,21.89L44.60,22.21L45.10,22.22L45.55,21.92L45.97,21.31L46.37,20.46L46.79,19.43L47.23,18.32L47.71,17.24L48.23,16.29L48.80,15.56L49.39,15.12L50.00,15.01L50.61,15.24L51.19,15.79L51.75,16.61L52.26,17.62L52.74,18.72L53.17,19.80L53.59,20.78L54.00,21.54L54.43,22.04L54.90,22.22L55.43,22.09L56.02,21.66L56.70,21.00L57.44,20.17L58.23,19.29L59.05,18.43L59.87,17.72L60.65,17.22L61.36,17.01L61.97,17.12L62.46,17.54L62.82,18.26L63.06,19.22L63.20,20.35L63.27,21.54L63.31,22.71L63.37,23.76L63.49,24.63L63.73,25.24L64.10,25.57L64.64,25.63L65.35,25.43L66.21,25.04L67.19,24.52L68.24,23.95L69.30,23.43L70.31,23.04L71.22,22.84L71.96,22.89L72.49,23.19L72.81,23.76L72.90,24.56L72.80,25.55L72.55,26.65L72.20,27.80L71.84,28.91L71.53,29.92L71.36,30.77L71.37,31.43L71.61,31.87L72.10,32.11L72.83,32.16L73.77,32.09L74.87,31.93L76.05,31.76L77.22,31.64L78.31,31.62L79.23,31.74L79.91,32.03L80.31,32.50L80.41,33.14L80.22,33.93L79.79,34.82L79.17,35.77L78.46,36.73L77.74,37.65L77.10,38.50L76.64,39.23L76.43,39.85L76.50,40.35L76.88,40.74L77.55,41.05L78.46,41.30L79.55,41.53L80.71,41.77L81.86,42.06L82.89,42.41L83.71,42.83L84.25,43.34L84.46,43.92L84.34,44.56L83.90,45.24L83.19,45.93L82.28,46.61L81.28,47.26L80.29,47.88L79.40,48.46L78.72,49.00L78.31,49.51L78.21,50.00Z\"/><circle cx=\"50\" cy=\"50\" r=\"28\" stroke-width=\".8\"/><circle cx=\"50\" cy=\"50\" r=\"25.5\" stroke-width=\".45\"/></g><g transform=\"translate(23 23) scale(.54)\" fill=\"currentColor\" style=\"--seal-paper:var(--ex-paper)\"><circle cx=\"50\" cy=\"46\" r=\"25\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3\"/>\n   <ellipse cx=\"50\" cy=\"46\" rx=\"11\" ry=\"25\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/>\n   <path d=\"M25 46h50M29 33h42M29 59h42M50 21v50M18 48c-2 19 7 32 27 36m37-36c2 19-7 32-27 36\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/>\n   <path d=\"M20 55C8 54 8 42 10 37c9 3 13 9 10 18m3 12C11 69 6 60 5 55c10-1 16 3 18 12m8 10C18 82 11 76 8 71c9-4 17-1 23 6m49-22c12-1 12-13 10-18-9 3-13 9-10 18m-3 12c12 2 17-7 18-12-10-1-16 3-18 12m-8 10c13 5 20-1 23-6-9-4-17-1-23 6\" fill=\"currentColor\"/></g>",
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\"><path d=\"M93.00,50.00L92.75,50.75L92.02,51.47L90.88,52.14L89.45,52.76L87.86,53.31L86.26,53.81L84.80,54.27L83.62,54.73L82.84,55.20L82.50,55.73L82.63,56.34L83.21,57.06L84.16,57.89L85.37,58.82L86.71,59.84L88.01,60.90L89.15,61.97L89.99,62.99L90.43,63.92L90.41,64.71L89.92,65.32L88.98,65.75L87.68,66.00L86.13,66.08L84.44,66.06L82.77,65.98L81.24,65.92L79.98,65.94L79.08,66.12L78.58,66.50L78.50,67.12L78.80,67.99L79.40,69.10L80.22,70.39L81.13,71.80L81.99,73.24L82.70,74.64L83.13,75.89L83.23,76.91L82.94,77.64L82.27,78.05L81.25,78.13L79.94,77.92L78.45,77.47L76.87,76.87L75.32,76.22L73.91,75.64L72.72,75.23L71.81,75.09L71.21,75.28L70.92,75.84L70.90,76.76L71.10,78.00L71.43,79.49L71.80,81.13L72.11,82.78L72.30,84.33L72.28,85.66L72.02,86.65L71.50,87.24L70.73,87.39L69.74,87.12L68.59,86.48L67.34,85.54L66.06,84.44L64.83,83.30L63.70,82.27L62.72,81.48L61.91,81.04L61.29,81.01L60.82,81.43L60.49,82.29L60.25,83.53L60.05,85.04L59.84,86.71L59.57,88.37L59.21,89.89L58.74,91.13L58.16,91.97L57.47,92.35L56.69,92.23L55.85,91.64L54.99,90.63L54.13,89.33L53.31,87.86L52.54,86.37L51.83,85.01L51.19,83.93L50.58,83.24L50.00,83.00L49.42,83.24L48.81,83.93L48.17,85.01L47.46,86.37L46.69,87.86L45.87,89.33L45.01,90.63L44.15,91.64L43.31,92.23L42.53,92.35L41.84,91.97L41.26,91.13L40.79,89.89L40.43,88.37L40.16,86.71L39.95,85.04L39.75,83.53L39.51,82.29L39.18,81.43L38.71,81.01L38.09,81.04L37.28,81.48L36.30,82.27L35.17,83.30L33.94,84.44L32.66,85.54L31.41,86.48L30.26,87.12L29.27,87.39L28.50,87.24L27.98,86.65L27.72,85.66L27.70,84.33L27.89,82.78L28.20,81.13L28.57,79.49L28.90,78.00L29.10,76.76L29.08,75.84L28.79,75.28L28.19,75.09L27.28,75.23L26.09,75.64L24.68,76.22L23.13,76.87L21.55,77.47L20.06,77.92L18.75,78.13L17.73,78.05L17.06,77.64L16.77,76.91L16.87,75.89L17.30,74.64L18.01,73.24L18.87,71.80L19.78,70.39L20.60,69.10L21.20,67.99L21.50,67.12L21.42,66.50L20.92,66.12L20.02,65.94L18.76,65.92L17.23,65.98L15.56,66.06L13.87,66.08L12.32,66.00L11.02,65.75L10.08,65.32L9.59,64.71L9.57,63.92L10.01,62.99L10.85,61.97L11.99,60.90L13.29,59.84L14.63,58.82L15.84,57.89L16.79,57.06L17.37,56.34L17.50,55.73L17.16,55.20L16.38,54.73L15.20,54.27L13.74,53.81L12.14,53.31L10.55,52.76L9.12,52.14L7.98,51.47L7.25,50.75L7.00,50.00L7.25,49.25L7.98,48.53L9.12,47.86L10.55,47.24L12.14,46.69L13.74,46.19L15.20,45.73L16.38,45.27L17.16,44.80L17.50,44.27L17.37,43.66L16.79,42.94L15.84,42.11L14.63,41.18L13.29,40.16L11.99,39.10L10.85,38.03L10.01,37.01L9.57,36.08L9.59,35.29L10.08,34.68L11.02,34.25L12.32,34.00L13.87,33.92L15.56,33.94L17.23,34.02L18.76,34.08L20.02,34.06L20.92,33.88L21.42,33.50L21.50,32.88L21.20,32.01L20.60,30.90L19.78,29.61L18.87,28.20L18.01,26.76L17.30,25.36L16.87,24.11L16.77,23.09L17.06,22.36L17.73,21.95L18.75,21.87L20.06,22.08L21.55,22.53L23.13,23.13L24.68,23.78L26.09,24.36L27.28,24.77L28.19,24.91L28.79,24.72L29.08,24.16L29.10,23.24L28.90,22.00L28.57,20.51L28.20,18.87L27.89,17.22L27.70,15.67L27.72,14.34L27.98,13.35L28.50,12.76L29.27,12.61L30.26,12.88L31.41,13.52L32.66,14.46L33.94,15.56L35.17,16.70L36.30,17.73L37.28,18.52L38.09,18.96L38.71,18.99L39.18,18.57L39.51,17.71L39.75,16.47L39.95,14.96L40.16,13.29L40.43,11.63L40.79,10.11L41.26,8.87L41.84,8.03L42.53,7.65L43.31,7.77L44.15,8.36L45.01,9.37L45.87,10.67L46.69,12.14L47.46,13.63L48.17,14.99L48.81,16.07L49.42,16.76L50.00,17.00L50.58,16.76L51.19,16.07L51.83,14.99L52.54,13.63L53.31,12.14L54.13,10.67L54.99,9.37L55.85,8.36L56.69,7.77L57.47,7.65L58.16,8.03L58.74,8.87L59.21,10.11L59.57,11.63L59.84,13.29L60.05,14.96L60.25,16.47L60.49,17.71L60.82,18.57L61.29,18.99L61.91,18.96L62.72,18.52L63.70,17.73L64.83,16.70L66.06,15.56L67.34,14.46L68.59,13.52L69.74,12.88L70.73,12.61L71.50,12.76L72.02,13.35L72.28,14.34L72.30,15.67L72.11,17.22L71.80,18.87L71.43,20.51L71.10,22.00L70.90,23.24L70.92,24.16L71.21,24.72L71.81,24.91L72.72,24.77L73.91,24.36L75.32,23.78L76.87,23.13L78.45,22.53L79.94,22.08L81.25,21.87L82.27,21.95L82.94,22.36L83.23,23.09L83.13,24.11L82.70,25.36L81.99,26.76L81.13,28.20L80.22,29.61L79.40,30.90L78.80,32.01L78.50,32.88L78.58,33.50L79.08,33.88L79.98,34.06L81.24,34.08L82.77,34.02L84.44,33.94L86.13,33.92L87.68,34.00L88.98,34.25L89.92,34.68L90.41,35.29L90.43,36.08L89.99,37.01L89.15,38.03L88.01,39.10L86.71,40.16L85.37,41.18L84.16,42.11L83.21,42.94L82.63,43.66L82.50,44.27L82.84,44.80L83.62,45.27L84.80,45.73L86.26,46.19L87.86,46.69L89.45,47.24L90.88,47.86L92.02,48.53L92.75,49.25L93.00,50.00Z\"/><path d=\"M89.60,50.00L88.42,50.67L87.03,51.29L85.57,51.86L84.17,52.39L82.97,52.88L82.09,53.37L81.61,53.88L81.56,54.44L81.93,55.06L82.69,55.76L83.74,56.56L84.97,57.43L86.23,58.36L87.40,59.33L88.35,60.28L88.96,61.17L89.16,61.97L88.93,62.65L88.26,63.17L87.22,63.55L85.88,63.77L84.36,63.88L82.78,63.92L81.29,63.93L80.00,63.99L79.01,64.15L78.38,64.46L78.14,64.96L78.28,65.68L78.75,66.60L79.46,67.70L80.32,68.94L81.19,70.25L81.96,71.56L82.52,72.77L82.79,73.82L82.71,74.65L82.26,75.20L81.45,75.47L80.34,75.46L79.00,75.21L77.54,74.79L76.05,74.29L74.64,73.79L73.41,73.41L72.42,73.21L71.72,73.29L71.32,73.68L71.21,74.40L71.34,75.43L71.63,76.71L72.01,78.17L72.38,79.70L72.66,81.19L72.77,82.52L72.66,83.60L72.30,84.35L71.69,84.71L70.84,84.69L69.80,84.30L68.63,83.61L67.40,82.72L66.17,81.73L65.02,80.79L63.99,80.00L63.13,79.48L62.44,79.31L61.94,79.55L61.59,80.18L61.35,81.19L61.19,82.50L61.05,84.00L60.87,85.56L60.63,87.05L60.28,88.35L59.80,89.32L59.21,89.90L58.51,90.04L57.72,89.72L56.88,89.00L56.01,87.96L55.16,86.69L54.34,85.35L53.58,84.06L52.88,82.97L52.25,82.19L51.67,81.80L51.11,81.85L50.56,82.33L50.00,83.20L49.40,84.37L48.75,85.73L48.05,87.13L47.31,88.45L46.54,89.55L45.76,90.31L45.01,90.65L44.30,90.53L43.67,89.97L43.12,89.00L42.67,87.72L42.30,86.24L41.99,84.70L41.71,83.23L41.43,81.97L41.10,81.02L40.69,80.46L40.15,80.31L39.47,80.57L38.65,81.19L37.68,82.09L36.61,83.14L35.47,84.23L34.32,85.22L33.22,85.98L32.23,86.43L31.41,86.49L30.78,86.14L30.38,85.39L30.20,84.30L30.21,82.94L30.36,81.42L30.60,79.87L30.85,78.40L31.01,77.11L31.03,76.11L30.83,75.43L30.38,75.11L29.65,75.13L28.66,75.43L27.45,75.94L26.08,76.57L24.64,77.20L23.22,77.73L21.93,78.07L20.85,78.15L20.05,77.93L19.58,77.39L19.46,76.55L19.66,75.46L20.14,74.18L20.80,72.81L21.56,71.43L22.29,70.13L22.89,68.99L23.25,68.05L23.29,67.34L22.97,66.89L22.29,66.65L21.25,66.60L19.94,66.66L18.44,66.78L16.87,66.88L15.35,66.90L14.02,66.78L12.98,66.48L12.30,66.00L12.05,65.33L12.22,64.50L12.78,63.55L13.67,62.51L14.76,61.45L15.94,60.41L17.07,59.44L18.03,58.57L18.69,57.81L18.97,57.16L18.83,56.63L18.26,56.17L17.31,55.76L16.05,55.38L14.60,54.97L13.09,54.53L11.66,54.03L10.45,53.46L9.57,52.83L9.10,52.14L9.09,51.43L9.54,50.71L10.40,50.00L11.58,49.33L12.97,48.71L14.43,48.14L15.83,47.61L17.03,47.12L17.91,46.63L18.39,46.12L18.44,45.56L18.07,44.94L17.31,44.24L16.26,43.44L15.03,42.57L13.77,41.64L12.60,40.67L11.65,39.72L11.04,38.83L10.84,38.03L11.07,37.35L11.74,36.83L12.78,36.45L14.12,36.23L15.64,36.12L17.22,36.08L18.71,36.07L20.00,36.01L20.99,35.85L21.62,35.54L21.86,35.04L21.72,34.32L21.25,33.40L20.54,32.30L19.68,31.06L18.81,29.75L18.04,28.44L17.48,27.23L17.21,26.18L17.29,25.35L17.74,24.80L18.55,24.53L19.66,24.54L21.00,24.79L22.46,25.21L23.95,25.71L25.36,26.21L26.59,26.59L27.58,26.79L28.28,26.71L28.68,26.32L28.79,25.60L28.66,24.57L28.37,23.29L27.99,21.83L27.62,20.30L27.34,18.81L27.23,17.48L27.34,16.40L27.70,15.65L28.31,15.29L29.16,15.31L30.20,15.70L31.37,16.39L32.60,17.28L33.83,18.27L34.98,19.21L36.01,20.00L36.87,20.52L37.56,20.69L38.06,20.45L38.41,19.82L38.65,18.81L38.81,17.50L38.95,16.00L39.13,14.44L39.37,12.95L39.72,11.65L40.20,10.68L40.79,10.10L41.49,9.96L42.28,10.28L43.12,11.00L43.99,12.04L44.84,13.31L45.66,14.65L46.42,15.94L47.12,17.03L47.75,17.81L48.33,18.20L48.89,18.15L49.44,17.67L50.00,16.80L50.60,15.63L51.25,14.27L51.95,12.87L52.69,11.55L53.46,10.45L54.24,9.69L54.99,9.35L55.70,9.47L56.33,10.03L56.88,11.00L57.33,12.28L57.70,13.76L58.01,15.30L58.29,16.77L58.57,18.03L58.90,18.98L59.31,19.54L59.85,19.69L60.53,19.43L61.35,18.81L62.32,17.91L63.39,16.86L64.53,15.77L65.68,14.78L66.78,14.02L67.77,13.57L68.59,13.51L69.22,13.86L69.62,14.61L69.80,15.70L69.79,17.06L69.64,18.58L69.40,20.13L69.15,21.60L68.99,22.89L68.97,23.89L69.17,24.57L69.62,24.89L70.35,24.87L71.34,24.57L72.55,24.06L73.92,23.43L75.36,22.80L76.78,22.27L78.07,21.93L79.15,21.85L79.95,22.07L80.42,22.61L80.54,23.45L80.34,24.54L79.86,25.82L79.20,27.19L78.44,28.57L77.71,29.87L77.11,31.01L76.75,31.95L76.71,32.66L77.03,33.11L77.71,33.35L78.75,33.40L80.06,33.34L81.56,33.22L83.13,33.12L84.65,33.10L85.98,33.22L87.02,33.52L87.70,34.00L87.95,34.67L87.78,35.50L87.22,36.45L86.33,37.49L85.24,38.55L84.06,39.59L82.93,40.56L81.97,41.43L81.31,42.19L81.03,42.84L81.17,43.37L81.74,43.83L82.69,44.24L83.95,44.62L85.40,45.03L86.91,45.47L88.34,45.97L89.55,46.54L90.43,47.17L90.90,47.86L90.91,48.57L90.46,49.29L89.60,50.00Z\"/><path d=\"M84.68,50.00L83.38,50.58L82.21,51.12L81.29,51.64L80.69,52.15L80.49,52.67L80.68,53.22L81.24,53.84L82.12,54.51L83.21,55.26L84.39,56.06L85.55,56.91L86.55,57.77L87.29,58.61L87.68,59.39L87.67,60.09L87.25,60.68L86.46,61.15L85.35,61.49L84.02,61.71L82.59,61.86L81.17,61.96L79.89,62.07L78.84,62.24L78.11,62.52L77.73,62.93L77.72,63.52L78.05,64.29L78.64,65.23L79.40,66.30L80.24,67.46L81.04,68.65L81.69,69.80L82.09,70.84L82.19,71.71L81.95,72.37L81.35,72.78L80.45,72.94L79.29,72.88L77.96,72.64L76.56,72.29L75.20,71.90L73.95,71.57L72.91,71.37L72.13,71.37L71.64,71.64L71.43,72.19L71.47,73.02L71.70,74.10L72.06,75.37L72.45,76.75L72.79,78.14L73.01,79.45L73.03,80.56L72.82,81.41L72.37,81.95L71.67,82.13L70.76,81.97L69.70,81.52L68.53,80.84L67.34,80.03L66.19,79.20L65.13,78.46L64.22,77.92L63.49,77.66L62.93,77.73L62.55,78.18L62.30,78.97L62.15,80.07L62.05,81.39L61.94,82.82L61.79,84.24L61.55,85.54L61.19,86.60L60.70,87.33L60.09,87.67L59.38,87.60L58.58,87.15L57.73,86.36L56.87,85.32L56.02,84.15L55.22,82.98L54.49,81.92L53.82,81.10L53.22,80.60L52.67,80.49L52.15,80.77L51.65,81.43L51.13,82.41L50.59,83.61L50.00,84.92L49.37,86.21L48.70,87.34L48.00,88.22L47.29,88.74L46.60,88.85L45.95,88.54L45.35,87.84L44.83,86.81L44.37,85.54L43.98,84.15L43.63,82.77L43.30,81.53L42.95,80.53L42.56,79.86L42.08,79.56L41.50,79.65L40.80,80.10L39.98,80.84L39.05,81.79L38.06,82.82L37.02,83.81L36.00,84.65L35.05,85.23L34.21,85.47L33.52,85.34L33.01,84.83L32.69,83.97L32.55,82.82L32.56,81.47L32.66,80.03L32.80,78.62L32.92,77.34L32.94,76.28L32.79,75.51L32.45,75.07L31.87,74.95L31.06,75.14L30.03,75.56L28.84,76.13L27.55,76.75L26.24,77.33L25.00,77.77L23.90,77.99L23.03,77.93L22.42,77.58L22.12,76.92L22.12,76.00L22.38,74.87L22.85,73.61L23.44,72.29L24.05,71.01L24.60,69.84L24.98,68.86L25.11,68.09L24.93,67.55L24.43,67.25L23.60,67.14L22.50,67.19L21.18,67.32L19.76,67.46L18.33,67.56L17.01,67.54L15.90,67.37L15.10,67.02L14.66,66.48L14.60,65.76L14.91,64.90L15.54,63.92L16.41,62.89L17.41,61.86L18.43,60.87L19.34,59.96L20.04,59.16L20.42,58.48L20.44,57.92L20.07,57.46L19.33,57.08L18.28,56.74L17.00,56.41L15.61,56.06L14.23,55.67L13.00,55.20L12.02,54.66L11.38,54.06L11.15,53.40L11.34,52.70L11.93,52.00L12.85,51.30L14.02,50.63L15.32,50.00L16.62,49.42L17.79,48.88L18.71,48.36L19.31,47.85L19.51,47.33L19.32,46.78L18.76,46.16L17.88,45.49L16.79,44.74L15.61,43.94L14.45,43.09L13.45,42.23L12.71,41.39L12.32,40.61L12.33,39.91L12.75,39.32L13.54,38.85L14.65,38.51L15.98,38.29L17.41,38.14L18.83,38.04L20.11,37.93L21.16,37.76L21.89,37.48L22.27,37.07L22.28,36.48L21.95,35.71L21.36,34.77L20.60,33.70L19.76,32.54L18.96,31.35L18.31,30.20L17.91,29.16L17.81,28.29L18.05,27.63L18.65,27.22L19.55,27.06L20.71,27.12L22.04,27.36L23.44,27.71L24.80,28.10L26.05,28.43L27.09,28.63L27.87,28.63L28.36,28.36L28.57,27.81L28.53,26.98L28.30,25.90L27.94,24.63L27.55,23.25L27.21,21.86L26.99,20.55L26.97,19.44L27.18,18.59L27.63,18.05L28.33,17.87L29.24,18.03L30.30,18.48L31.47,19.16L32.66,19.97L33.81,20.80L34.87,21.54L35.78,22.08L36.51,22.34L37.07,22.27L37.45,21.82L37.70,21.03L37.85,19.93L37.95,18.61L38.06,17.18L38.21,15.76L38.45,14.46L38.81,13.40L39.30,12.67L39.91,12.33L40.62,12.40L41.42,12.85L42.27,13.64L43.13,14.68L43.98,15.85L44.78,17.02L45.51,18.08L46.18,18.90L46.78,19.40L47.33,19.51L47.85,19.23L48.35,18.57L48.87,17.59L49.41,16.39L50.00,15.08L50.63,13.79L51.30,12.66L52.00,11.78L52.71,11.26L53.40,11.15L54.05,11.46L54.65,12.16L55.17,13.19L55.63,14.46L56.02,15.85L56.37,17.23L56.70,18.47L57.05,19.47L57.44,20.14L57.92,20.44L58.50,20.35L59.20,19.90L60.02,19.16L60.95,18.21L61.94,17.18L62.98,16.19L64.00,15.35L64.95,14.77L65.79,14.53L66.48,14.66L66.99,15.17L67.31,16.03L67.45,17.18L67.44,18.53L67.34,19.97L67.20,21.38L67.08,22.66L67.06,23.72L67.21,24.49L67.55,24.93L68.13,25.05L68.94,24.86L69.97,24.44L71.16,23.87L72.45,23.25L73.76,22.67L75.00,22.23L76.10,22.01L76.97,22.07L77.58,22.42L77.88,23.08L77.88,24.00L77.62,25.13L77.15,26.39L76.56,27.71L75.95,28.99L75.40,30.16L75.02,31.14L74.89,31.91L75.07,32.45L75.57,32.75L76.40,32.86L77.50,32.81L78.82,32.68L80.24,32.54L81.67,32.44L82.99,32.46L84.10,32.63L84.90,32.98L85.34,33.52L85.40,34.24L85.09,35.10L84.46,36.08L83.59,37.11L82.59,38.14L81.57,39.13L80.66,40.04L79.96,40.84L79.58,41.52L79.56,42.08L79.93,42.54L80.67,42.92L81.72,43.26L83.00,43.59L84.39,43.94L85.77,44.33L87.00,44.80L87.98,45.34L88.62,45.94L88.85,46.60L88.66,47.30L88.07,48.00L87.15,48.70L85.98,49.37L84.68,50.00Z\"/><path d=\"M80.40,50.00L79.74,50.52L79.41,51.03L79.44,51.54L79.82,52.09L80.52,52.67L81.45,53.31L82.53,53.99L83.63,54.73L84.64,55.49L85.46,56.25L85.98,56.99L86.17,57.69L85.98,58.31L85.42,58.83L84.55,59.26L83.43,59.59L82.16,59.83L80.85,60.03L79.62,60.20L78.56,60.40L77.77,60.66L77.28,61.02L77.13,61.52L77.31,62.16L77.76,62.95L78.42,63.86L79.20,64.88L79.98,65.94L80.67,67.00L81.18,68.00L81.42,68.88L81.36,69.59L80.97,70.11L80.27,70.41L79.30,70.51L78.13,70.44L76.86,70.24L75.56,69.97L74.35,69.72L73.29,69.54L72.45,69.51L71.87,69.69L71.56,70.10L71.50,70.77L71.66,71.66L71.97,72.75L72.35,73.97L72.72,75.24L73.01,76.47L73.14,77.58L73.07,78.49L72.76,79.14L72.22,79.49L71.46,79.53L70.51,79.30L69.45,78.83L68.32,78.20L67.19,77.51L66.14,76.85L65.20,76.33L64.42,76.01L63.81,75.98L63.38,76.26L63.10,76.87L62.95,77.76L62.86,78.89L62.80,80.17L62.72,81.49L62.57,82.74L62.31,83.83L61.93,84.66L61.43,85.17L60.80,85.31L60.06,85.09L59.26,84.55L58.41,83.74L57.56,82.77L56.75,81.73L55.98,80.75L55.28,79.94L54.65,79.38L54.10,79.14L53.59,79.26L53.12,79.73L52.67,80.52L52.21,81.55L51.72,82.73L51.19,83.94L50.61,85.07L50.00,86.00L49.36,86.65L48.71,86.95L48.07,86.87L47.45,86.42L46.88,85.63L46.36,84.58L45.90,83.38L45.48,82.13L45.10,80.94L44.72,79.94L44.32,79.20L43.88,78.78L43.37,78.72L42.77,79.01L42.07,79.59L41.28,80.40L40.42,81.34L39.51,82.30L38.58,83.16L37.69,83.83L36.86,84.22L36.15,84.28L35.57,83.99L35.15,83.35L34.88,82.42L34.76,81.26L34.73,79.96L34.77,78.64L34.81,77.40L34.80,76.33L34.68,75.49L34.41,74.95L33.95,74.72L33.28,74.78L32.43,75.09L31.41,75.58L30.28,76.17L29.09,76.76L27.93,77.26L26.86,77.58L25.95,77.67L25.26,77.48L24.82,77.00L24.64,76.26L24.71,75.29L24.98,74.16L25.40,72.94L25.89,71.71L26.36,70.55L26.71,69.54L26.89,68.72L26.81,68.12L26.46,67.74L25.82,67.57L24.91,67.57L23.78,67.68L22.52,67.85L21.20,68.00L19.94,68.06L18.82,68.00L17.94,67.77L17.35,67.36L17.10,66.76L17.19,66.00L17.58,65.12L18.23,64.14L19.04,63.14L19.92,62.15L20.75,61.23L21.44,60.40L21.88,59.68L22.02,59.09L21.81,58.62L21.27,58.24L20.41,57.93L19.31,57.65L18.07,57.37L16.78,57.06L15.57,56.69L14.54,56.25L13.79,55.73L13.38,55.15L13.35,54.50L13.69,53.82L14.37,53.12L15.31,52.43L16.42,51.76L17.58,51.13L18.68,50.55L19.60,50.00L20.26,49.48L20.59,48.97L20.56,48.46L20.18,47.91L19.48,47.33L18.55,46.69L17.47,46.01L16.37,45.27L15.36,44.51L14.54,43.75L14.02,43.01L13.83,42.31L14.02,41.69L14.58,41.17L15.45,40.74L16.57,40.41L17.84,40.17L19.15,39.97L20.38,39.80L21.44,39.60L22.23,39.34L22.72,38.98L22.87,38.48L22.69,37.84L22.24,37.05L21.58,36.14L20.80,35.12L20.02,34.06L19.33,33.00L18.82,32.00L18.58,31.12L18.64,30.41L19.03,29.89L19.73,29.59L20.70,29.49L21.87,29.56L23.14,29.76L24.44,30.03L25.65,30.28L26.71,30.46L27.55,30.49L28.13,30.31L28.44,29.90L28.50,29.23L28.34,28.34L28.03,27.25L27.65,26.03L27.28,24.76L26.99,23.53L26.86,22.42L26.93,21.51L27.24,20.86L27.78,20.51L28.54,20.47L29.49,20.70L30.55,21.17L31.68,21.80L32.81,22.49L33.86,23.15L34.80,23.67L35.58,23.99L36.19,24.02L36.62,23.74L36.90,23.13L37.05,22.24L37.14,21.11L37.20,19.83L37.28,18.51L37.43,17.26L37.69,16.17L38.07,15.34L38.57,14.83L39.20,14.69L39.94,14.91L40.74,15.45L41.59,16.26L42.44,17.23L43.25,18.27L44.02,19.25L44.72,20.06L45.35,20.62L45.90,20.86L46.41,20.74L46.88,20.27L47.33,19.48L47.79,18.45L48.28,17.27L48.81,16.06L49.39,14.93L50.00,14.00L50.64,13.35L51.29,13.05L51.93,13.13L52.55,13.58L53.12,14.37L53.64,15.42L54.10,16.62L54.52,17.87L54.90,19.06L55.28,20.06L55.68,20.80L56.12,21.22L56.63,21.28L57.23,20.99L57.93,20.41L58.72,19.60L59.58,18.66L60.49,17.70L61.42,16.84L62.31,16.17L63.14,15.78L63.85,15.72L64.43,16.01L64.85,16.65L65.12,17.58L65.24,18.74L65.27,20.04L65.23,21.36L65.19,22.60L65.20,23.67L65.32,24.51L65.59,25.05L66.05,25.28L66.72,25.22L67.57,24.91L68.59,24.42L69.72,23.83L70.91,23.24L72.07,22.74L73.14,22.42L74.05,22.33L74.74,22.52L75.18,23.00L75.36,23.74L75.29,24.71L75.02,25.84L74.60,27.06L74.11,28.29L73.64,29.45L73.29,30.46L73.11,31.28L73.19,31.88L73.54,32.26L74.18,32.43L75.09,32.43L76.22,32.32L77.48,32.15L78.80,32.00L80.06,31.94L81.18,32.00L82.06,32.23L82.65,32.64L82.90,33.24L82.81,34.00L82.42,34.88L81.77,35.86L80.96,36.86L80.08,37.85L79.25,38.77L78.56,39.60L78.12,40.32L77.98,40.91L78.19,41.38L78.73,41.76L79.59,42.07L80.69,42.35L81.93,42.63L83.22,42.94L84.43,43.31L85.46,43.75L86.21,44.27L86.62,44.85L86.65,45.50L86.31,46.18L85.63,46.88L84.69,47.57L83.58,48.24L82.42,48.87L81.32,49.45L80.40,50.00Z\"/><path d=\"M78.21,50.00L78.43,50.50L78.95,51.01L79.72,51.56L80.67,52.14L81.68,52.77L82.66,53.43L83.50,54.11L84.13,54.80L84.46,55.46L84.46,56.08L84.13,56.63L83.48,57.12L82.58,57.52L81.50,57.85L80.33,58.13L79.19,58.37L78.16,58.61L77.33,58.88L76.77,59.22L76.50,59.65L76.54,60.19L76.86,60.85L77.40,61.63L78.08,62.50L78.82,63.44L79.51,64.40L80.08,65.32L80.43,66.18L80.51,66.91L80.31,67.50L79.80,67.91L79.03,68.14L78.04,68.21L76.91,68.15L75.72,68.01L74.56,67.85L73.52,67.72L72.65,67.69L72.00,67.82L71.61,68.13L71.46,68.65L71.53,69.39L71.77,70.30L72.11,71.35L72.48,72.48L72.81,73.62L73.02,74.69L73.06,75.61L72.89,76.33L72.49,76.81L71.88,77.02L71.07,76.97L70.12,76.70L69.08,76.26L68.01,75.72L66.98,75.17L66.04,74.69L65.23,74.37L64.58,74.27L64.10,74.43L63.78,74.87L63.60,75.58L63.51,76.52L63.48,77.63L63.44,78.82L63.36,80.00L63.19,81.07L62.91,81.95L62.50,82.57L61.97,82.88L61.32,82.87L60.58,82.55L59.78,81.97L58.95,81.20L58.13,80.33L57.35,79.46L56.62,78.69L55.97,78.11L55.40,77.79L54.90,77.78L54.45,78.08L54.03,78.69L53.63,79.54L53.21,80.57L52.77,81.68L52.29,82.76L51.77,83.71L51.20,84.44L50.61,84.88L50.00,84.99L49.39,84.76L48.81,84.21L48.25,83.39L47.74,82.38L47.26,81.28L46.83,80.20L46.41,79.22L46.00,78.46L45.57,77.96L45.10,77.78L44.57,77.91L43.98,78.34L43.30,79.00L42.56,79.83L41.77,80.71L40.95,81.57L40.13,82.28L39.35,82.78L38.64,82.99L38.03,82.88L37.54,82.46L37.18,81.74L36.94,80.78L36.80,79.65L36.73,78.46L36.69,77.29L36.63,76.24L36.51,75.37L36.27,74.76L35.90,74.43L35.36,74.37L34.65,74.57L33.79,74.96L32.81,75.48L31.76,76.05L30.70,76.57L29.69,76.96L28.78,77.16L28.04,77.11L27.51,76.81L27.19,76.24L27.10,75.44L27.20,74.45L27.45,73.35L27.80,72.20L28.16,71.09L28.47,70.08L28.64,69.23L28.63,68.57L28.39,68.13L27.90,67.89L27.17,67.84L26.23,67.91L25.13,68.07L23.95,68.24L22.78,68.36L21.69,68.38L20.77,68.26L20.09,67.97L19.69,67.50L19.59,66.86L19.78,66.07L20.21,65.18L20.83,64.23L21.54,63.27L22.26,62.35L22.90,61.50L23.36,60.77L23.57,60.15L23.50,59.65L23.12,59.26L22.45,58.95L21.54,58.70L20.45,58.47L19.29,58.23L18.14,57.94L17.11,57.59L16.29,57.17L15.75,56.66L15.54,56.08L15.66,55.44L16.10,54.76L16.81,54.07L17.72,53.39L18.72,52.74L19.71,52.12L20.60,51.54L21.28,51.00L21.69,50.49L21.79,50.00L21.57,49.50L21.05,48.99L20.28,48.44L19.33,47.86L18.32,47.23L17.34,46.57L16.50,45.89L15.87,45.20L15.54,44.54L15.54,43.92L15.87,43.37L16.52,42.88L17.42,42.48L18.50,42.15L19.67,41.87L20.81,41.63L21.84,41.39L22.67,41.12L23.23,40.78L23.50,40.35L23.46,39.81L23.14,39.15L22.60,38.37L21.92,37.50L21.18,36.56L20.49,35.60L19.92,34.68L19.57,33.82L19.49,33.09L19.69,32.50L20.20,32.09L20.97,31.86L21.96,31.79L23.09,31.85L24.28,31.99L25.44,32.15L26.48,32.28L27.35,32.31L28.00,32.18L28.39,31.87L28.54,31.35L28.47,30.61L28.23,29.70L27.89,28.65L27.52,27.52L27.19,26.38L26.98,25.31L26.94,24.39L27.11,23.67L27.51,23.19L28.12,22.98L28.93,23.03L29.88,23.30L30.92,23.74L31.99,24.28L33.02,24.83L33.96,25.31L34.77,25.63L35.42,25.73L35.90,25.57L36.22,25.13L36.40,24.42L36.49,23.48L36.52,22.37L36.56,21.18L36.64,20.00L36.81,18.93L37.09,18.05L37.50,17.43L38.03,17.12L38.68,17.13L39.42,17.45L40.22,18.03L41.05,18.80L41.87,19.67L42.65,20.54L43.38,21.31L44.03,21.89L44.60,22.21L45.10,22.22L45.55,21.92L45.97,21.31L46.37,20.46L46.79,19.43L47.23,18.32L47.71,17.24L48.23,16.29L48.80,15.56L49.39,15.12L50.00,15.01L50.61,15.24L51.19,15.79L51.75,16.61L52.26,17.62L52.74,18.72L53.17,19.80L53.59,20.78L54.00,21.54L54.43,22.04L54.90,22.22L55.43,22.09L56.02,21.66L56.70,21.00L57.44,20.17L58.23,19.29L59.05,18.43L59.87,17.72L60.65,17.22L61.36,17.01L61.97,17.12L62.46,17.54L62.82,18.26L63.06,19.22L63.20,20.35L63.27,21.54L63.31,22.71L63.37,23.76L63.49,24.63L63.73,25.24L64.10,25.57L64.64,25.63L65.35,25.43L66.21,25.04L67.19,24.52L68.24,23.95L69.30,23.43L70.31,23.04L71.22,22.84L71.96,22.89L72.49,23.19L72.81,23.76L72.90,24.56L72.80,25.55L72.55,26.65L72.20,27.80L71.84,28.91L71.53,29.92L71.36,30.77L71.37,31.43L71.61,31.87L72.10,32.11L72.83,32.16L73.77,32.09L74.87,31.93L76.05,31.76L77.22,31.64L78.31,31.62L79.23,31.74L79.91,32.03L80.31,32.50L80.41,33.14L80.22,33.93L79.79,34.82L79.17,35.77L78.46,36.73L77.74,37.65L77.10,38.50L76.64,39.23L76.43,39.85L76.50,40.35L76.88,40.74L77.55,41.05L78.46,41.30L79.55,41.53L80.71,41.77L81.86,42.06L82.89,42.41L83.71,42.83L84.25,43.34L84.46,43.92L84.34,44.56L83.90,45.24L83.19,45.93L82.28,46.61L81.28,47.26L80.29,47.88L79.40,48.46L78.72,49.00L78.31,49.51L78.21,50.00Z\"/><circle cx=\"50\" cy=\"50\" r=\"28\" stroke-width=\".8\"/><circle cx=\"50\" cy=\"50\" r=\"25.5\" stroke-width=\".45\"/></g><g transform=\"translate(23 23) scale(.54)\" fill=\"currentColor\" style=\"--seal-paper:var(--ex-paper)\"><path d=\"M50 80V43m0 20C33 64 25 57 22 46c16-1 26 5 28 17m0 9c17 1 25-6 28-17-16-1-26 5-28 17\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3\"/>\n   <path d=\"M50 14c9 3 12 10 8 18 9-3 16 0 20 8-4 8-11 11-20 8 4 8 1 15-8 18-9-3-12-10-8-18-9 3-16 0-20-8 4-8 11-11 20-8-4-8-1-15 8-18Z\" fill=\"currentColor\"/>\n   <circle cx=\"50\" cy=\"40\" r=\"8\" fill=\"var(--seal-paper)\"/>\n   <path d=\"M12 65c3 13 15 23 30 24m46-24C85 78 73 88 58 89M19 72l-8 3m15 4-6 5m61-12 8 3m-15 4 6 5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/></g>",
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\"><path d=\"M93.00,50.00L92.75,50.75L92.02,51.47L90.88,52.14L89.45,52.76L87.86,53.31L86.26,53.81L84.80,54.27L83.62,54.73L82.84,55.20L82.50,55.73L82.63,56.34L83.21,57.06L84.16,57.89L85.37,58.82L86.71,59.84L88.01,60.90L89.15,61.97L89.99,62.99L90.43,63.92L90.41,64.71L89.92,65.32L88.98,65.75L87.68,66.00L86.13,66.08L84.44,66.06L82.77,65.98L81.24,65.92L79.98,65.94L79.08,66.12L78.58,66.50L78.50,67.12L78.80,67.99L79.40,69.10L80.22,70.39L81.13,71.80L81.99,73.24L82.70,74.64L83.13,75.89L83.23,76.91L82.94,77.64L82.27,78.05L81.25,78.13L79.94,77.92L78.45,77.47L76.87,76.87L75.32,76.22L73.91,75.64L72.72,75.23L71.81,75.09L71.21,75.28L70.92,75.84L70.90,76.76L71.10,78.00L71.43,79.49L71.80,81.13L72.11,82.78L72.30,84.33L72.28,85.66L72.02,86.65L71.50,87.24L70.73,87.39L69.74,87.12L68.59,86.48L67.34,85.54L66.06,84.44L64.83,83.30L63.70,82.27L62.72,81.48L61.91,81.04L61.29,81.01L60.82,81.43L60.49,82.29L60.25,83.53L60.05,85.04L59.84,86.71L59.57,88.37L59.21,89.89L58.74,91.13L58.16,91.97L57.47,92.35L56.69,92.23L55.85,91.64L54.99,90.63L54.13,89.33L53.31,87.86L52.54,86.37L51.83,85.01L51.19,83.93L50.58,83.24L50.00,83.00L49.42,83.24L48.81,83.93L48.17,85.01L47.46,86.37L46.69,87.86L45.87,89.33L45.01,90.63L44.15,91.64L43.31,92.23L42.53,92.35L41.84,91.97L41.26,91.13L40.79,89.89L40.43,88.37L40.16,86.71L39.95,85.04L39.75,83.53L39.51,82.29L39.18,81.43L38.71,81.01L38.09,81.04L37.28,81.48L36.30,82.27L35.17,83.30L33.94,84.44L32.66,85.54L31.41,86.48L30.26,87.12L29.27,87.39L28.50,87.24L27.98,86.65L27.72,85.66L27.70,84.33L27.89,82.78L28.20,81.13L28.57,79.49L28.90,78.00L29.10,76.76L29.08,75.84L28.79,75.28L28.19,75.09L27.28,75.23L26.09,75.64L24.68,76.22L23.13,76.87L21.55,77.47L20.06,77.92L18.75,78.13L17.73,78.05L17.06,77.64L16.77,76.91L16.87,75.89L17.30,74.64L18.01,73.24L18.87,71.80L19.78,70.39L20.60,69.10L21.20,67.99L21.50,67.12L21.42,66.50L20.92,66.12L20.02,65.94L18.76,65.92L17.23,65.98L15.56,66.06L13.87,66.08L12.32,66.00L11.02,65.75L10.08,65.32L9.59,64.71L9.57,63.92L10.01,62.99L10.85,61.97L11.99,60.90L13.29,59.84L14.63,58.82L15.84,57.89L16.79,57.06L17.37,56.34L17.50,55.73L17.16,55.20L16.38,54.73L15.20,54.27L13.74,53.81L12.14,53.31L10.55,52.76L9.12,52.14L7.98,51.47L7.25,50.75L7.00,50.00L7.25,49.25L7.98,48.53L9.12,47.86L10.55,47.24L12.14,46.69L13.74,46.19L15.20,45.73L16.38,45.27L17.16,44.80L17.50,44.27L17.37,43.66L16.79,42.94L15.84,42.11L14.63,41.18L13.29,40.16L11.99,39.10L10.85,38.03L10.01,37.01L9.57,36.08L9.59,35.29L10.08,34.68L11.02,34.25L12.32,34.00L13.87,33.92L15.56,33.94L17.23,34.02L18.76,34.08L20.02,34.06L20.92,33.88L21.42,33.50L21.50,32.88L21.20,32.01L20.60,30.90L19.78,29.61L18.87,28.20L18.01,26.76L17.30,25.36L16.87,24.11L16.77,23.09L17.06,22.36L17.73,21.95L18.75,21.87L20.06,22.08L21.55,22.53L23.13,23.13L24.68,23.78L26.09,24.36L27.28,24.77L28.19,24.91L28.79,24.72L29.08,24.16L29.10,23.24L28.90,22.00L28.57,20.51L28.20,18.87L27.89,17.22L27.70,15.67L27.72,14.34L27.98,13.35L28.50,12.76L29.27,12.61L30.26,12.88L31.41,13.52L32.66,14.46L33.94,15.56L35.17,16.70L36.30,17.73L37.28,18.52L38.09,18.96L38.71,18.99L39.18,18.57L39.51,17.71L39.75,16.47L39.95,14.96L40.16,13.29L40.43,11.63L40.79,10.11L41.26,8.87L41.84,8.03L42.53,7.65L43.31,7.77L44.15,8.36L45.01,9.37L45.87,10.67L46.69,12.14L47.46,13.63L48.17,14.99L48.81,16.07L49.42,16.76L50.00,17.00L50.58,16.76L51.19,16.07L51.83,14.99L52.54,13.63L53.31,12.14L54.13,10.67L54.99,9.37L55.85,8.36L56.69,7.77L57.47,7.65L58.16,8.03L58.74,8.87L59.21,10.11L59.57,11.63L59.84,13.29L60.05,14.96L60.25,16.47L60.49,17.71L60.82,18.57L61.29,18.99L61.91,18.96L62.72,18.52L63.70,17.73L64.83,16.70L66.06,15.56L67.34,14.46L68.59,13.52L69.74,12.88L70.73,12.61L71.50,12.76L72.02,13.35L72.28,14.34L72.30,15.67L72.11,17.22L71.80,18.87L71.43,20.51L71.10,22.00L70.90,23.24L70.92,24.16L71.21,24.72L71.81,24.91L72.72,24.77L73.91,24.36L75.32,23.78L76.87,23.13L78.45,22.53L79.94,22.08L81.25,21.87L82.27,21.95L82.94,22.36L83.23,23.09L83.13,24.11L82.70,25.36L81.99,26.76L81.13,28.20L80.22,29.61L79.40,30.90L78.80,32.01L78.50,32.88L78.58,33.50L79.08,33.88L79.98,34.06L81.24,34.08L82.77,34.02L84.44,33.94L86.13,33.92L87.68,34.00L88.98,34.25L89.92,34.68L90.41,35.29L90.43,36.08L89.99,37.01L89.15,38.03L88.01,39.10L86.71,40.16L85.37,41.18L84.16,42.11L83.21,42.94L82.63,43.66L82.50,44.27L82.84,44.80L83.62,45.27L84.80,45.73L86.26,46.19L87.86,46.69L89.45,47.24L90.88,47.86L92.02,48.53L92.75,49.25L93.00,50.00Z\"/><path d=\"M89.60,50.00L88.42,50.67L87.03,51.29L85.57,51.86L84.17,52.39L82.97,52.88L82.09,53.37L81.61,53.88L81.56,54.44L81.93,55.06L82.69,55.76L83.74,56.56L84.97,57.43L86.23,58.36L87.40,59.33L88.35,60.28L88.96,61.17L89.16,61.97L88.93,62.65L88.26,63.17L87.22,63.55L85.88,63.77L84.36,63.88L82.78,63.92L81.29,63.93L80.00,63.99L79.01,64.15L78.38,64.46L78.14,64.96L78.28,65.68L78.75,66.60L79.46,67.70L80.32,68.94L81.19,70.25L81.96,71.56L82.52,72.77L82.79,73.82L82.71,74.65L82.26,75.20L81.45,75.47L80.34,75.46L79.00,75.21L77.54,74.79L76.05,74.29L74.64,73.79L73.41,73.41L72.42,73.21L71.72,73.29L71.32,73.68L71.21,74.40L71.34,75.43L71.63,76.71L72.01,78.17L72.38,79.70L72.66,81.19L72.77,82.52L72.66,83.60L72.30,84.35L71.69,84.71L70.84,84.69L69.80,84.30L68.63,83.61L67.40,82.72L66.17,81.73L65.02,80.79L63.99,80.00L63.13,79.48L62.44,79.31L61.94,79.55L61.59,80.18L61.35,81.19L61.19,82.50L61.05,84.00L60.87,85.56L60.63,87.05L60.28,88.35L59.80,89.32L59.21,89.90L58.51,90.04L57.72,89.72L56.88,89.00L56.01,87.96L55.16,86.69L54.34,85.35L53.58,84.06L52.88,82.97L52.25,82.19L51.67,81.80L51.11,81.85L50.56,82.33L50.00,83.20L49.40,84.37L48.75,85.73L48.05,87.13L47.31,88.45L46.54,89.55L45.76,90.31L45.01,90.65L44.30,90.53L43.67,89.97L43.12,89.00L42.67,87.72L42.30,86.24L41.99,84.70L41.71,83.23L41.43,81.97L41.10,81.02L40.69,80.46L40.15,80.31L39.47,80.57L38.65,81.19L37.68,82.09L36.61,83.14L35.47,84.23L34.32,85.22L33.22,85.98L32.23,86.43L31.41,86.49L30.78,86.14L30.38,85.39L30.20,84.30L30.21,82.94L30.36,81.42L30.60,79.87L30.85,78.40L31.01,77.11L31.03,76.11L30.83,75.43L30.38,75.11L29.65,75.13L28.66,75.43L27.45,75.94L26.08,76.57L24.64,77.20L23.22,77.73L21.93,78.07L20.85,78.15L20.05,77.93L19.58,77.39L19.46,76.55L19.66,75.46L20.14,74.18L20.80,72.81L21.56,71.43L22.29,70.13L22.89,68.99L23.25,68.05L23.29,67.34L22.97,66.89L22.29,66.65L21.25,66.60L19.94,66.66L18.44,66.78L16.87,66.88L15.35,66.90L14.02,66.78L12.98,66.48L12.30,66.00L12.05,65.33L12.22,64.50L12.78,63.55L13.67,62.51L14.76,61.45L15.94,60.41L17.07,59.44L18.03,58.57L18.69,57.81L18.97,57.16L18.83,56.63L18.26,56.17L17.31,55.76L16.05,55.38L14.60,54.97L13.09,54.53L11.66,54.03L10.45,53.46L9.57,52.83L9.10,52.14L9.09,51.43L9.54,50.71L10.40,50.00L11.58,49.33L12.97,48.71L14.43,48.14L15.83,47.61L17.03,47.12L17.91,46.63L18.39,46.12L18.44,45.56L18.07,44.94L17.31,44.24L16.26,43.44L15.03,42.57L13.77,41.64L12.60,40.67L11.65,39.72L11.04,38.83L10.84,38.03L11.07,37.35L11.74,36.83L12.78,36.45L14.12,36.23L15.64,36.12L17.22,36.08L18.71,36.07L20.00,36.01L20.99,35.85L21.62,35.54L21.86,35.04L21.72,34.32L21.25,33.40L20.54,32.30L19.68,31.06L18.81,29.75L18.04,28.44L17.48,27.23L17.21,26.18L17.29,25.35L17.74,24.80L18.55,24.53L19.66,24.54L21.00,24.79L22.46,25.21L23.95,25.71L25.36,26.21L26.59,26.59L27.58,26.79L28.28,26.71L28.68,26.32L28.79,25.60L28.66,24.57L28.37,23.29L27.99,21.83L27.62,20.30L27.34,18.81L27.23,17.48L27.34,16.40L27.70,15.65L28.31,15.29L29.16,15.31L30.20,15.70L31.37,16.39L32.60,17.28L33.83,18.27L34.98,19.21L36.01,20.00L36.87,20.52L37.56,20.69L38.06,20.45L38.41,19.82L38.65,18.81L38.81,17.50L38.95,16.00L39.13,14.44L39.37,12.95L39.72,11.65L40.20,10.68L40.79,10.10L41.49,9.96L42.28,10.28L43.12,11.00L43.99,12.04L44.84,13.31L45.66,14.65L46.42,15.94L47.12,17.03L47.75,17.81L48.33,18.20L48.89,18.15L49.44,17.67L50.00,16.80L50.60,15.63L51.25,14.27L51.95,12.87L52.69,11.55L53.46,10.45L54.24,9.69L54.99,9.35L55.70,9.47L56.33,10.03L56.88,11.00L57.33,12.28L57.70,13.76L58.01,15.30L58.29,16.77L58.57,18.03L58.90,18.98L59.31,19.54L59.85,19.69L60.53,19.43L61.35,18.81L62.32,17.91L63.39,16.86L64.53,15.77L65.68,14.78L66.78,14.02L67.77,13.57L68.59,13.51L69.22,13.86L69.62,14.61L69.80,15.70L69.79,17.06L69.64,18.58L69.40,20.13L69.15,21.60L68.99,22.89L68.97,23.89L69.17,24.57L69.62,24.89L70.35,24.87L71.34,24.57L72.55,24.06L73.92,23.43L75.36,22.80L76.78,22.27L78.07,21.93L79.15,21.85L79.95,22.07L80.42,22.61L80.54,23.45L80.34,24.54L79.86,25.82L79.20,27.19L78.44,28.57L77.71,29.87L77.11,31.01L76.75,31.95L76.71,32.66L77.03,33.11L77.71,33.35L78.75,33.40L80.06,33.34L81.56,33.22L83.13,33.12L84.65,33.10L85.98,33.22L87.02,33.52L87.70,34.00L87.95,34.67L87.78,35.50L87.22,36.45L86.33,37.49L85.24,38.55L84.06,39.59L82.93,40.56L81.97,41.43L81.31,42.19L81.03,42.84L81.17,43.37L81.74,43.83L82.69,44.24L83.95,44.62L85.40,45.03L86.91,45.47L88.34,45.97L89.55,46.54L90.43,47.17L90.90,47.86L90.91,48.57L90.46,49.29L89.60,50.00Z\"/><path d=\"M84.68,50.00L83.38,50.58L82.21,51.12L81.29,51.64L80.69,52.15L80.49,52.67L80.68,53.22L81.24,53.84L82.12,54.51L83.21,55.26L84.39,56.06L85.55,56.91L86.55,57.77L87.29,58.61L87.68,59.39L87.67,60.09L87.25,60.68L86.46,61.15L85.35,61.49L84.02,61.71L82.59,61.86L81.17,61.96L79.89,62.07L78.84,62.24L78.11,62.52L77.73,62.93L77.72,63.52L78.05,64.29L78.64,65.23L79.40,66.30L80.24,67.46L81.04,68.65L81.69,69.80L82.09,70.84L82.19,71.71L81.95,72.37L81.35,72.78L80.45,72.94L79.29,72.88L77.96,72.64L76.56,72.29L75.20,71.90L73.95,71.57L72.91,71.37L72.13,71.37L71.64,71.64L71.43,72.19L71.47,73.02L71.70,74.10L72.06,75.37L72.45,76.75L72.79,78.14L73.01,79.45L73.03,80.56L72.82,81.41L72.37,81.95L71.67,82.13L70.76,81.97L69.70,81.52L68.53,80.84L67.34,80.03L66.19,79.20L65.13,78.46L64.22,77.92L63.49,77.66L62.93,77.73L62.55,78.18L62.30,78.97L62.15,80.07L62.05,81.39L61.94,82.82L61.79,84.24L61.55,85.54L61.19,86.60L60.70,87.33L60.09,87.67L59.38,87.60L58.58,87.15L57.73,86.36L56.87,85.32L56.02,84.15L55.22,82.98L54.49,81.92L53.82,81.10L53.22,80.60L52.67,80.49L52.15,80.77L51.65,81.43L51.13,82.41L50.59,83.61L50.00,84.92L49.37,86.21L48.70,87.34L48.00,88.22L47.29,88.74L46.60,88.85L45.95,88.54L45.35,87.84L44.83,86.81L44.37,85.54L43.98,84.15L43.63,82.77L43.30,81.53L42.95,80.53L42.56,79.86L42.08,79.56L41.50,79.65L40.80,80.10L39.98,80.84L39.05,81.79L38.06,82.82L37.02,83.81L36.00,84.65L35.05,85.23L34.21,85.47L33.52,85.34L33.01,84.83L32.69,83.97L32.55,82.82L32.56,81.47L32.66,80.03L32.80,78.62L32.92,77.34L32.94,76.28L32.79,75.51L32.45,75.07L31.87,74.95L31.06,75.14L30.03,75.56L28.84,76.13L27.55,76.75L26.24,77.33L25.00,77.77L23.90,77.99L23.03,77.93L22.42,77.58L22.12,76.92L22.12,76.00L22.38,74.87L22.85,73.61L23.44,72.29L24.05,71.01L24.60,69.84L24.98,68.86L25.11,68.09L24.93,67.55L24.43,67.25L23.60,67.14L22.50,67.19L21.18,67.32L19.76,67.46L18.33,67.56L17.01,67.54L15.90,67.37L15.10,67.02L14.66,66.48L14.60,65.76L14.91,64.90L15.54,63.92L16.41,62.89L17.41,61.86L18.43,60.87L19.34,59.96L20.04,59.16L20.42,58.48L20.44,57.92L20.07,57.46L19.33,57.08L18.28,56.74L17.00,56.41L15.61,56.06L14.23,55.67L13.00,55.20L12.02,54.66L11.38,54.06L11.15,53.40L11.34,52.70L11.93,52.00L12.85,51.30L14.02,50.63L15.32,50.00L16.62,49.42L17.79,48.88L18.71,48.36L19.31,47.85L19.51,47.33L19.32,46.78L18.76,46.16L17.88,45.49L16.79,44.74L15.61,43.94L14.45,43.09L13.45,42.23L12.71,41.39L12.32,40.61L12.33,39.91L12.75,39.32L13.54,38.85L14.65,38.51L15.98,38.29L17.41,38.14L18.83,38.04L20.11,37.93L21.16,37.76L21.89,37.48L22.27,37.07L22.28,36.48L21.95,35.71L21.36,34.77L20.60,33.70L19.76,32.54L18.96,31.35L18.31,30.20L17.91,29.16L17.81,28.29L18.05,27.63L18.65,27.22L19.55,27.06L20.71,27.12L22.04,27.36L23.44,27.71L24.80,28.10L26.05,28.43L27.09,28.63L27.87,28.63L28.36,28.36L28.57,27.81L28.53,26.98L28.30,25.90L27.94,24.63L27.55,23.25L27.21,21.86L26.99,20.55L26.97,19.44L27.18,18.59L27.63,18.05L28.33,17.87L29.24,18.03L30.30,18.48L31.47,19.16L32.66,19.97L33.81,20.80L34.87,21.54L35.78,22.08L36.51,22.34L37.07,22.27L37.45,21.82L37.70,21.03L37.85,19.93L37.95,18.61L38.06,17.18L38.21,15.76L38.45,14.46L38.81,13.40L39.30,12.67L39.91,12.33L40.62,12.40L41.42,12.85L42.27,13.64L43.13,14.68L43.98,15.85L44.78,17.02L45.51,18.08L46.18,18.90L46.78,19.40L47.33,19.51L47.85,19.23L48.35,18.57L48.87,17.59L49.41,16.39L50.00,15.08L50.63,13.79L51.30,12.66L52.00,11.78L52.71,11.26L53.40,11.15L54.05,11.46L54.65,12.16L55.17,13.19L55.63,14.46L56.02,15.85L56.37,17.23L56.70,18.47L57.05,19.47L57.44,20.14L57.92,20.44L58.50,20.35L59.20,19.90L60.02,19.16L60.95,18.21L61.94,17.18L62.98,16.19L64.00,15.35L64.95,14.77L65.79,14.53L66.48,14.66L66.99,15.17L67.31,16.03L67.45,17.18L67.44,18.53L67.34,19.97L67.20,21.38L67.08,22.66L67.06,23.72L67.21,24.49L67.55,24.93L68.13,25.05L68.94,24.86L69.97,24.44L71.16,23.87L72.45,23.25L73.76,22.67L75.00,22.23L76.10,22.01L76.97,22.07L77.58,22.42L77.88,23.08L77.88,24.00L77.62,25.13L77.15,26.39L76.56,27.71L75.95,28.99L75.40,30.16L75.02,31.14L74.89,31.91L75.07,32.45L75.57,32.75L76.40,32.86L77.50,32.81L78.82,32.68L80.24,32.54L81.67,32.44L82.99,32.46L84.10,32.63L84.90,32.98L85.34,33.52L85.40,34.24L85.09,35.10L84.46,36.08L83.59,37.11L82.59,38.14L81.57,39.13L80.66,40.04L79.96,40.84L79.58,41.52L79.56,42.08L79.93,42.54L80.67,42.92L81.72,43.26L83.00,43.59L84.39,43.94L85.77,44.33L87.00,44.80L87.98,45.34L88.62,45.94L88.85,46.60L88.66,47.30L88.07,48.00L87.15,48.70L85.98,49.37L84.68,50.00Z\"/><path d=\"M80.40,50.00L79.74,50.52L79.41,51.03L79.44,51.54L79.82,52.09L80.52,52.67L81.45,53.31L82.53,53.99L83.63,54.73L84.64,55.49L85.46,56.25L85.98,56.99L86.17,57.69L85.98,58.31L85.42,58.83L84.55,59.26L83.43,59.59L82.16,59.83L80.85,60.03L79.62,60.20L78.56,60.40L77.77,60.66L77.28,61.02L77.13,61.52L77.31,62.16L77.76,62.95L78.42,63.86L79.20,64.88L79.98,65.94L80.67,67.00L81.18,68.00L81.42,68.88L81.36,69.59L80.97,70.11L80.27,70.41L79.30,70.51L78.13,70.44L76.86,70.24L75.56,69.97L74.35,69.72L73.29,69.54L72.45,69.51L71.87,69.69L71.56,70.10L71.50,70.77L71.66,71.66L71.97,72.75L72.35,73.97L72.72,75.24L73.01,76.47L73.14,77.58L73.07,78.49L72.76,79.14L72.22,79.49L71.46,79.53L70.51,79.30L69.45,78.83L68.32,78.20L67.19,77.51L66.14,76.85L65.20,76.33L64.42,76.01L63.81,75.98L63.38,76.26L63.10,76.87L62.95,77.76L62.86,78.89L62.80,80.17L62.72,81.49L62.57,82.74L62.31,83.83L61.93,84.66L61.43,85.17L60.80,85.31L60.06,85.09L59.26,84.55L58.41,83.74L57.56,82.77L56.75,81.73L55.98,80.75L55.28,79.94L54.65,79.38L54.10,79.14L53.59,79.26L53.12,79.73L52.67,80.52L52.21,81.55L51.72,82.73L51.19,83.94L50.61,85.07L50.00,86.00L49.36,86.65L48.71,86.95L48.07,86.87L47.45,86.42L46.88,85.63L46.36,84.58L45.90,83.38L45.48,82.13L45.10,80.94L44.72,79.94L44.32,79.20L43.88,78.78L43.37,78.72L42.77,79.01L42.07,79.59L41.28,80.40L40.42,81.34L39.51,82.30L38.58,83.16L37.69,83.83L36.86,84.22L36.15,84.28L35.57,83.99L35.15,83.35L34.88,82.42L34.76,81.26L34.73,79.96L34.77,78.64L34.81,77.40L34.80,76.33L34.68,75.49L34.41,74.95L33.95,74.72L33.28,74.78L32.43,75.09L31.41,75.58L30.28,76.17L29.09,76.76L27.93,77.26L26.86,77.58L25.95,77.67L25.26,77.48L24.82,77.00L24.64,76.26L24.71,75.29L24.98,74.16L25.40,72.94L25.89,71.71L26.36,70.55L26.71,69.54L26.89,68.72L26.81,68.12L26.46,67.74L25.82,67.57L24.91,67.57L23.78,67.68L22.52,67.85L21.20,68.00L19.94,68.06L18.82,68.00L17.94,67.77L17.35,67.36L17.10,66.76L17.19,66.00L17.58,65.12L18.23,64.14L19.04,63.14L19.92,62.15L20.75,61.23L21.44,60.40L21.88,59.68L22.02,59.09L21.81,58.62L21.27,58.24L20.41,57.93L19.31,57.65L18.07,57.37L16.78,57.06L15.57,56.69L14.54,56.25L13.79,55.73L13.38,55.15L13.35,54.50L13.69,53.82L14.37,53.12L15.31,52.43L16.42,51.76L17.58,51.13L18.68,50.55L19.60,50.00L20.26,49.48L20.59,48.97L20.56,48.46L20.18,47.91L19.48,47.33L18.55,46.69L17.47,46.01L16.37,45.27L15.36,44.51L14.54,43.75L14.02,43.01L13.83,42.31L14.02,41.69L14.58,41.17L15.45,40.74L16.57,40.41L17.84,40.17L19.15,39.97L20.38,39.80L21.44,39.60L22.23,39.34L22.72,38.98L22.87,38.48L22.69,37.84L22.24,37.05L21.58,36.14L20.80,35.12L20.02,34.06L19.33,33.00L18.82,32.00L18.58,31.12L18.64,30.41L19.03,29.89L19.73,29.59L20.70,29.49L21.87,29.56L23.14,29.76L24.44,30.03L25.65,30.28L26.71,30.46L27.55,30.49L28.13,30.31L28.44,29.90L28.50,29.23L28.34,28.34L28.03,27.25L27.65,26.03L27.28,24.76L26.99,23.53L26.86,22.42L26.93,21.51L27.24,20.86L27.78,20.51L28.54,20.47L29.49,20.70L30.55,21.17L31.68,21.80L32.81,22.49L33.86,23.15L34.80,23.67L35.58,23.99L36.19,24.02L36.62,23.74L36.90,23.13L37.05,22.24L37.14,21.11L37.20,19.83L37.28,18.51L37.43,17.26L37.69,16.17L38.07,15.34L38.57,14.83L39.20,14.69L39.94,14.91L40.74,15.45L41.59,16.26L42.44,17.23L43.25,18.27L44.02,19.25L44.72,20.06L45.35,20.62L45.90,20.86L46.41,20.74L46.88,20.27L47.33,19.48L47.79,18.45L48.28,17.27L48.81,16.06L49.39,14.93L50.00,14.00L50.64,13.35L51.29,13.05L51.93,13.13L52.55,13.58L53.12,14.37L53.64,15.42L54.10,16.62L54.52,17.87L54.90,19.06L55.28,20.06L55.68,20.80L56.12,21.22L56.63,21.28L57.23,20.99L57.93,20.41L58.72,19.60L59.58,18.66L60.49,17.70L61.42,16.84L62.31,16.17L63.14,15.78L63.85,15.72L64.43,16.01L64.85,16.65L65.12,17.58L65.24,18.74L65.27,20.04L65.23,21.36L65.19,22.60L65.20,23.67L65.32,24.51L65.59,25.05L66.05,25.28L66.72,25.22L67.57,24.91L68.59,24.42L69.72,23.83L70.91,23.24L72.07,22.74L73.14,22.42L74.05,22.33L74.74,22.52L75.18,23.00L75.36,23.74L75.29,24.71L75.02,25.84L74.60,27.06L74.11,28.29L73.64,29.45L73.29,30.46L73.11,31.28L73.19,31.88L73.54,32.26L74.18,32.43L75.09,32.43L76.22,32.32L77.48,32.15L78.80,32.00L80.06,31.94L81.18,32.00L82.06,32.23L82.65,32.64L82.90,33.24L82.81,34.00L82.42,34.88L81.77,35.86L80.96,36.86L80.08,37.85L79.25,38.77L78.56,39.60L78.12,40.32L77.98,40.91L78.19,41.38L78.73,41.76L79.59,42.07L80.69,42.35L81.93,42.63L83.22,42.94L84.43,43.31L85.46,43.75L86.21,44.27L86.62,44.85L86.65,45.50L86.31,46.18L85.63,46.88L84.69,47.57L83.58,48.24L82.42,48.87L81.32,49.45L80.40,50.00Z\"/><path d=\"M78.21,50.00L78.43,50.50L78.95,51.01L79.72,51.56L80.67,52.14L81.68,52.77L82.66,53.43L83.50,54.11L84.13,54.80L84.46,55.46L84.46,56.08L84.13,56.63L83.48,57.12L82.58,57.52L81.50,57.85L80.33,58.13L79.19,58.37L78.16,58.61L77.33,58.88L76.77,59.22L76.50,59.65L76.54,60.19L76.86,60.85L77.40,61.63L78.08,62.50L78.82,63.44L79.51,64.40L80.08,65.32L80.43,66.18L80.51,66.91L80.31,67.50L79.80,67.91L79.03,68.14L78.04,68.21L76.91,68.15L75.72,68.01L74.56,67.85L73.52,67.72L72.65,67.69L72.00,67.82L71.61,68.13L71.46,68.65L71.53,69.39L71.77,70.30L72.11,71.35L72.48,72.48L72.81,73.62L73.02,74.69L73.06,75.61L72.89,76.33L72.49,76.81L71.88,77.02L71.07,76.97L70.12,76.70L69.08,76.26L68.01,75.72L66.98,75.17L66.04,74.69L65.23,74.37L64.58,74.27L64.10,74.43L63.78,74.87L63.60,75.58L63.51,76.52L63.48,77.63L63.44,78.82L63.36,80.00L63.19,81.07L62.91,81.95L62.50,82.57L61.97,82.88L61.32,82.87L60.58,82.55L59.78,81.97L58.95,81.20L58.13,80.33L57.35,79.46L56.62,78.69L55.97,78.11L55.40,77.79L54.90,77.78L54.45,78.08L54.03,78.69L53.63,79.54L53.21,80.57L52.77,81.68L52.29,82.76L51.77,83.71L51.20,84.44L50.61,84.88L50.00,84.99L49.39,84.76L48.81,84.21L48.25,83.39L47.74,82.38L47.26,81.28L46.83,80.20L46.41,79.22L46.00,78.46L45.57,77.96L45.10,77.78L44.57,77.91L43.98,78.34L43.30,79.00L42.56,79.83L41.77,80.71L40.95,81.57L40.13,82.28L39.35,82.78L38.64,82.99L38.03,82.88L37.54,82.46L37.18,81.74L36.94,80.78L36.80,79.65L36.73,78.46L36.69,77.29L36.63,76.24L36.51,75.37L36.27,74.76L35.90,74.43L35.36,74.37L34.65,74.57L33.79,74.96L32.81,75.48L31.76,76.05L30.70,76.57L29.69,76.96L28.78,77.16L28.04,77.11L27.51,76.81L27.19,76.24L27.10,75.44L27.20,74.45L27.45,73.35L27.80,72.20L28.16,71.09L28.47,70.08L28.64,69.23L28.63,68.57L28.39,68.13L27.90,67.89L27.17,67.84L26.23,67.91L25.13,68.07L23.95,68.24L22.78,68.36L21.69,68.38L20.77,68.26L20.09,67.97L19.69,67.50L19.59,66.86L19.78,66.07L20.21,65.18L20.83,64.23L21.54,63.27L22.26,62.35L22.90,61.50L23.36,60.77L23.57,60.15L23.50,59.65L23.12,59.26L22.45,58.95L21.54,58.70L20.45,58.47L19.29,58.23L18.14,57.94L17.11,57.59L16.29,57.17L15.75,56.66L15.54,56.08L15.66,55.44L16.10,54.76L16.81,54.07L17.72,53.39L18.72,52.74L19.71,52.12L20.60,51.54L21.28,51.00L21.69,50.49L21.79,50.00L21.57,49.50L21.05,48.99L20.28,48.44L19.33,47.86L18.32,47.23L17.34,46.57L16.50,45.89L15.87,45.20L15.54,44.54L15.54,43.92L15.87,43.37L16.52,42.88L17.42,42.48L18.50,42.15L19.67,41.87L20.81,41.63L21.84,41.39L22.67,41.12L23.23,40.78L23.50,40.35L23.46,39.81L23.14,39.15L22.60,38.37L21.92,37.50L21.18,36.56L20.49,35.60L19.92,34.68L19.57,33.82L19.49,33.09L19.69,32.50L20.20,32.09L20.97,31.86L21.96,31.79L23.09,31.85L24.28,31.99L25.44,32.15L26.48,32.28L27.35,32.31L28.00,32.18L28.39,31.87L28.54,31.35L28.47,30.61L28.23,29.70L27.89,28.65L27.52,27.52L27.19,26.38L26.98,25.31L26.94,24.39L27.11,23.67L27.51,23.19L28.12,22.98L28.93,23.03L29.88,23.30L30.92,23.74L31.99,24.28L33.02,24.83L33.96,25.31L34.77,25.63L35.42,25.73L35.90,25.57L36.22,25.13L36.40,24.42L36.49,23.48L36.52,22.37L36.56,21.18L36.64,20.00L36.81,18.93L37.09,18.05L37.50,17.43L38.03,17.12L38.68,17.13L39.42,17.45L40.22,18.03L41.05,18.80L41.87,19.67L42.65,20.54L43.38,21.31L44.03,21.89L44.60,22.21L45.10,22.22L45.55,21.92L45.97,21.31L46.37,20.46L46.79,19.43L47.23,18.32L47.71,17.24L48.23,16.29L48.80,15.56L49.39,15.12L50.00,15.01L50.61,15.24L51.19,15.79L51.75,16.61L52.26,17.62L52.74,18.72L53.17,19.80L53.59,20.78L54.00,21.54L54.43,22.04L54.90,22.22L55.43,22.09L56.02,21.66L56.70,21.00L57.44,20.17L58.23,19.29L59.05,18.43L59.87,17.72L60.65,17.22L61.36,17.01L61.97,17.12L62.46,17.54L62.82,18.26L63.06,19.22L63.20,20.35L63.27,21.54L63.31,22.71L63.37,23.76L63.49,24.63L63.73,25.24L64.10,25.57L64.64,25.63L65.35,25.43L66.21,25.04L67.19,24.52L68.24,23.95L69.30,23.43L70.31,23.04L71.22,22.84L71.96,22.89L72.49,23.19L72.81,23.76L72.90,24.56L72.80,25.55L72.55,26.65L72.20,27.80L71.84,28.91L71.53,29.92L71.36,30.77L71.37,31.43L71.61,31.87L72.10,32.11L72.83,32.16L73.77,32.09L74.87,31.93L76.05,31.76L77.22,31.64L78.31,31.62L79.23,31.74L79.91,32.03L80.31,32.50L80.41,33.14L80.22,33.93L79.79,34.82L79.17,35.77L78.46,36.73L77.74,37.65L77.10,38.50L76.64,39.23L76.43,39.85L76.50,40.35L76.88,40.74L77.55,41.05L78.46,41.30L79.55,41.53L80.71,41.77L81.86,42.06L82.89,42.41L83.71,42.83L84.25,43.34L84.46,43.92L84.34,44.56L83.90,45.24L83.19,45.93L82.28,46.61L81.28,47.26L80.29,47.88L79.40,48.46L78.72,49.00L78.31,49.51L78.21,50.00Z\"/><circle cx=\"50\" cy=\"50\" r=\"28\" stroke-width=\".8\"/><circle cx=\"50\" cy=\"50\" r=\"25.5\" stroke-width=\".45\"/></g><g transform=\"translate(23 23) scale(.54)\" fill=\"currentColor\" style=\"--seal-paper:var(--ex-paper)\"><path d=\"m23 28 14 9 13-20 13 20 14-9-5 25H28Z\" fill=\"currentColor\"/>\n   <path d=\"M28 56h44M32 61h36v11L50 88 32 72Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3\"/>\n   <path d=\"M50 64v17m-9-11h18M32 46h36m-18-19v15\" fill=\"none\" stroke=\"var(--seal-paper)\" stroke-width=\"2.5\"/>\n   <circle cx=\"23\" cy=\"25\" r=\"3\" fill=\"currentColor\"/><circle cx=\"50\" cy=\"14\" r=\"3\" fill=\"currentColor\"/><circle cx=\"77\" cy=\"25\" r=\"3\" fill=\"currentColor\"/>\n   <path d=\"M23 64v12L12 70l4 14 24 4m37-24v12l11-6-4 14-24 4\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/></g>",
	"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\".45\"><path d=\"M93.00,50.00L92.75,50.75L92.02,51.47L90.88,52.14L89.45,52.76L87.86,53.31L86.26,53.81L84.80,54.27L83.62,54.73L82.84,55.20L82.50,55.73L82.63,56.34L83.21,57.06L84.16,57.89L85.37,58.82L86.71,59.84L88.01,60.90L89.15,61.97L89.99,62.99L90.43,63.92L90.41,64.71L89.92,65.32L88.98,65.75L87.68,66.00L86.13,66.08L84.44,66.06L82.77,65.98L81.24,65.92L79.98,65.94L79.08,66.12L78.58,66.50L78.50,67.12L78.80,67.99L79.40,69.10L80.22,70.39L81.13,71.80L81.99,73.24L82.70,74.64L83.13,75.89L83.23,76.91L82.94,77.64L82.27,78.05L81.25,78.13L79.94,77.92L78.45,77.47L76.87,76.87L75.32,76.22L73.91,75.64L72.72,75.23L71.81,75.09L71.21,75.28L70.92,75.84L70.90,76.76L71.10,78.00L71.43,79.49L71.80,81.13L72.11,82.78L72.30,84.33L72.28,85.66L72.02,86.65L71.50,87.24L70.73,87.39L69.74,87.12L68.59,86.48L67.34,85.54L66.06,84.44L64.83,83.30L63.70,82.27L62.72,81.48L61.91,81.04L61.29,81.01L60.82,81.43L60.49,82.29L60.25,83.53L60.05,85.04L59.84,86.71L59.57,88.37L59.21,89.89L58.74,91.13L58.16,91.97L57.47,92.35L56.69,92.23L55.85,91.64L54.99,90.63L54.13,89.33L53.31,87.86L52.54,86.37L51.83,85.01L51.19,83.93L50.58,83.24L50.00,83.00L49.42,83.24L48.81,83.93L48.17,85.01L47.46,86.37L46.69,87.86L45.87,89.33L45.01,90.63L44.15,91.64L43.31,92.23L42.53,92.35L41.84,91.97L41.26,91.13L40.79,89.89L40.43,88.37L40.16,86.71L39.95,85.04L39.75,83.53L39.51,82.29L39.18,81.43L38.71,81.01L38.09,81.04L37.28,81.48L36.30,82.27L35.17,83.30L33.94,84.44L32.66,85.54L31.41,86.48L30.26,87.12L29.27,87.39L28.50,87.24L27.98,86.65L27.72,85.66L27.70,84.33L27.89,82.78L28.20,81.13L28.57,79.49L28.90,78.00L29.10,76.76L29.08,75.84L28.79,75.28L28.19,75.09L27.28,75.23L26.09,75.64L24.68,76.22L23.13,76.87L21.55,77.47L20.06,77.92L18.75,78.13L17.73,78.05L17.06,77.64L16.77,76.91L16.87,75.89L17.30,74.64L18.01,73.24L18.87,71.80L19.78,70.39L20.60,69.10L21.20,67.99L21.50,67.12L21.42,66.50L20.92,66.12L20.02,65.94L18.76,65.92L17.23,65.98L15.56,66.06L13.87,66.08L12.32,66.00L11.02,65.75L10.08,65.32L9.59,64.71L9.57,63.92L10.01,62.99L10.85,61.97L11.99,60.90L13.29,59.84L14.63,58.82L15.84,57.89L16.79,57.06L17.37,56.34L17.50,55.73L17.16,55.20L16.38,54.73L15.20,54.27L13.74,53.81L12.14,53.31L10.55,52.76L9.12,52.14L7.98,51.47L7.25,50.75L7.00,50.00L7.25,49.25L7.98,48.53L9.12,47.86L10.55,47.24L12.14,46.69L13.74,46.19L15.20,45.73L16.38,45.27L17.16,44.80L17.50,44.27L17.37,43.66L16.79,42.94L15.84,42.11L14.63,41.18L13.29,40.16L11.99,39.10L10.85,38.03L10.01,37.01L9.57,36.08L9.59,35.29L10.08,34.68L11.02,34.25L12.32,34.00L13.87,33.92L15.56,33.94L17.23,34.02L18.76,34.08L20.02,34.06L20.92,33.88L21.42,33.50L21.50,32.88L21.20,32.01L20.60,30.90L19.78,29.61L18.87,28.20L18.01,26.76L17.30,25.36L16.87,24.11L16.77,23.09L17.06,22.36L17.73,21.95L18.75,21.87L20.06,22.08L21.55,22.53L23.13,23.13L24.68,23.78L26.09,24.36L27.28,24.77L28.19,24.91L28.79,24.72L29.08,24.16L29.10,23.24L28.90,22.00L28.57,20.51L28.20,18.87L27.89,17.22L27.70,15.67L27.72,14.34L27.98,13.35L28.50,12.76L29.27,12.61L30.26,12.88L31.41,13.52L32.66,14.46L33.94,15.56L35.17,16.70L36.30,17.73L37.28,18.52L38.09,18.96L38.71,18.99L39.18,18.57L39.51,17.71L39.75,16.47L39.95,14.96L40.16,13.29L40.43,11.63L40.79,10.11L41.26,8.87L41.84,8.03L42.53,7.65L43.31,7.77L44.15,8.36L45.01,9.37L45.87,10.67L46.69,12.14L47.46,13.63L48.17,14.99L48.81,16.07L49.42,16.76L50.00,17.00L50.58,16.76L51.19,16.07L51.83,14.99L52.54,13.63L53.31,12.14L54.13,10.67L54.99,9.37L55.85,8.36L56.69,7.77L57.47,7.65L58.16,8.03L58.74,8.87L59.21,10.11L59.57,11.63L59.84,13.29L60.05,14.96L60.25,16.47L60.49,17.71L60.82,18.57L61.29,18.99L61.91,18.96L62.72,18.52L63.70,17.73L64.83,16.70L66.06,15.56L67.34,14.46L68.59,13.52L69.74,12.88L70.73,12.61L71.50,12.76L72.02,13.35L72.28,14.34L72.30,15.67L72.11,17.22L71.80,18.87L71.43,20.51L71.10,22.00L70.90,23.24L70.92,24.16L71.21,24.72L71.81,24.91L72.72,24.77L73.91,24.36L75.32,23.78L76.87,23.13L78.45,22.53L79.94,22.08L81.25,21.87L82.27,21.95L82.94,22.36L83.23,23.09L83.13,24.11L82.70,25.36L81.99,26.76L81.13,28.20L80.22,29.61L79.40,30.90L78.80,32.01L78.50,32.88L78.58,33.50L79.08,33.88L79.98,34.06L81.24,34.08L82.77,34.02L84.44,33.94L86.13,33.92L87.68,34.00L88.98,34.25L89.92,34.68L90.41,35.29L90.43,36.08L89.99,37.01L89.15,38.03L88.01,39.10L86.71,40.16L85.37,41.18L84.16,42.11L83.21,42.94L82.63,43.66L82.50,44.27L82.84,44.80L83.62,45.27L84.80,45.73L86.26,46.19L87.86,46.69L89.45,47.24L90.88,47.86L92.02,48.53L92.75,49.25L93.00,50.00Z\"/><path d=\"M89.60,50.00L88.42,50.67L87.03,51.29L85.57,51.86L84.17,52.39L82.97,52.88L82.09,53.37L81.61,53.88L81.56,54.44L81.93,55.06L82.69,55.76L83.74,56.56L84.97,57.43L86.23,58.36L87.40,59.33L88.35,60.28L88.96,61.17L89.16,61.97L88.93,62.65L88.26,63.17L87.22,63.55L85.88,63.77L84.36,63.88L82.78,63.92L81.29,63.93L80.00,63.99L79.01,64.15L78.38,64.46L78.14,64.96L78.28,65.68L78.75,66.60L79.46,67.70L80.32,68.94L81.19,70.25L81.96,71.56L82.52,72.77L82.79,73.82L82.71,74.65L82.26,75.20L81.45,75.47L80.34,75.46L79.00,75.21L77.54,74.79L76.05,74.29L74.64,73.79L73.41,73.41L72.42,73.21L71.72,73.29L71.32,73.68L71.21,74.40L71.34,75.43L71.63,76.71L72.01,78.17L72.38,79.70L72.66,81.19L72.77,82.52L72.66,83.60L72.30,84.35L71.69,84.71L70.84,84.69L69.80,84.30L68.63,83.61L67.40,82.72L66.17,81.73L65.02,80.79L63.99,80.00L63.13,79.48L62.44,79.31L61.94,79.55L61.59,80.18L61.35,81.19L61.19,82.50L61.05,84.00L60.87,85.56L60.63,87.05L60.28,88.35L59.80,89.32L59.21,89.90L58.51,90.04L57.72,89.72L56.88,89.00L56.01,87.96L55.16,86.69L54.34,85.35L53.58,84.06L52.88,82.97L52.25,82.19L51.67,81.80L51.11,81.85L50.56,82.33L50.00,83.20L49.40,84.37L48.75,85.73L48.05,87.13L47.31,88.45L46.54,89.55L45.76,90.31L45.01,90.65L44.30,90.53L43.67,89.97L43.12,89.00L42.67,87.72L42.30,86.24L41.99,84.70L41.71,83.23L41.43,81.97L41.10,81.02L40.69,80.46L40.15,80.31L39.47,80.57L38.65,81.19L37.68,82.09L36.61,83.14L35.47,84.23L34.32,85.22L33.22,85.98L32.23,86.43L31.41,86.49L30.78,86.14L30.38,85.39L30.20,84.30L30.21,82.94L30.36,81.42L30.60,79.87L30.85,78.40L31.01,77.11L31.03,76.11L30.83,75.43L30.38,75.11L29.65,75.13L28.66,75.43L27.45,75.94L26.08,76.57L24.64,77.20L23.22,77.73L21.93,78.07L20.85,78.15L20.05,77.93L19.58,77.39L19.46,76.55L19.66,75.46L20.14,74.18L20.80,72.81L21.56,71.43L22.29,70.13L22.89,68.99L23.25,68.05L23.29,67.34L22.97,66.89L22.29,66.65L21.25,66.60L19.94,66.66L18.44,66.78L16.87,66.88L15.35,66.90L14.02,66.78L12.98,66.48L12.30,66.00L12.05,65.33L12.22,64.50L12.78,63.55L13.67,62.51L14.76,61.45L15.94,60.41L17.07,59.44L18.03,58.57L18.69,57.81L18.97,57.16L18.83,56.63L18.26,56.17L17.31,55.76L16.05,55.38L14.60,54.97L13.09,54.53L11.66,54.03L10.45,53.46L9.57,52.83L9.10,52.14L9.09,51.43L9.54,50.71L10.40,50.00L11.58,49.33L12.97,48.71L14.43,48.14L15.83,47.61L17.03,47.12L17.91,46.63L18.39,46.12L18.44,45.56L18.07,44.94L17.31,44.24L16.26,43.44L15.03,42.57L13.77,41.64L12.60,40.67L11.65,39.72L11.04,38.83L10.84,38.03L11.07,37.35L11.74,36.83L12.78,36.45L14.12,36.23L15.64,36.12L17.22,36.08L18.71,36.07L20.00,36.01L20.99,35.85L21.62,35.54L21.86,35.04L21.72,34.32L21.25,33.40L20.54,32.30L19.68,31.06L18.81,29.75L18.04,28.44L17.48,27.23L17.21,26.18L17.29,25.35L17.74,24.80L18.55,24.53L19.66,24.54L21.00,24.79L22.46,25.21L23.95,25.71L25.36,26.21L26.59,26.59L27.58,26.79L28.28,26.71L28.68,26.32L28.79,25.60L28.66,24.57L28.37,23.29L27.99,21.83L27.62,20.30L27.34,18.81L27.23,17.48L27.34,16.40L27.70,15.65L28.31,15.29L29.16,15.31L30.20,15.70L31.37,16.39L32.60,17.28L33.83,18.27L34.98,19.21L36.01,20.00L36.87,20.52L37.56,20.69L38.06,20.45L38.41,19.82L38.65,18.81L38.81,17.50L38.95,16.00L39.13,14.44L39.37,12.95L39.72,11.65L40.20,10.68L40.79,10.10L41.49,9.96L42.28,10.28L43.12,11.00L43.99,12.04L44.84,13.31L45.66,14.65L46.42,15.94L47.12,17.03L47.75,17.81L48.33,18.20L48.89,18.15L49.44,17.67L50.00,16.80L50.60,15.63L51.25,14.27L51.95,12.87L52.69,11.55L53.46,10.45L54.24,9.69L54.99,9.35L55.70,9.47L56.33,10.03L56.88,11.00L57.33,12.28L57.70,13.76L58.01,15.30L58.29,16.77L58.57,18.03L58.90,18.98L59.31,19.54L59.85,19.69L60.53,19.43L61.35,18.81L62.32,17.91L63.39,16.86L64.53,15.77L65.68,14.78L66.78,14.02L67.77,13.57L68.59,13.51L69.22,13.86L69.62,14.61L69.80,15.70L69.79,17.06L69.64,18.58L69.40,20.13L69.15,21.60L68.99,22.89L68.97,23.89L69.17,24.57L69.62,24.89L70.35,24.87L71.34,24.57L72.55,24.06L73.92,23.43L75.36,22.80L76.78,22.27L78.07,21.93L79.15,21.85L79.95,22.07L80.42,22.61L80.54,23.45L80.34,24.54L79.86,25.82L79.20,27.19L78.44,28.57L77.71,29.87L77.11,31.01L76.75,31.95L76.71,32.66L77.03,33.11L77.71,33.35L78.75,33.40L80.06,33.34L81.56,33.22L83.13,33.12L84.65,33.10L85.98,33.22L87.02,33.52L87.70,34.00L87.95,34.67L87.78,35.50L87.22,36.45L86.33,37.49L85.24,38.55L84.06,39.59L82.93,40.56L81.97,41.43L81.31,42.19L81.03,42.84L81.17,43.37L81.74,43.83L82.69,44.24L83.95,44.62L85.40,45.03L86.91,45.47L88.34,45.97L89.55,46.54L90.43,47.17L90.90,47.86L90.91,48.57L90.46,49.29L89.60,50.00Z\"/><path d=\"M84.68,50.00L83.38,50.58L82.21,51.12L81.29,51.64L80.69,52.15L80.49,52.67L80.68,53.22L81.24,53.84L82.12,54.51L83.21,55.26L84.39,56.06L85.55,56.91L86.55,57.77L87.29,58.61L87.68,59.39L87.67,60.09L87.25,60.68L86.46,61.15L85.35,61.49L84.02,61.71L82.59,61.86L81.17,61.96L79.89,62.07L78.84,62.24L78.11,62.52L77.73,62.93L77.72,63.52L78.05,64.29L78.64,65.23L79.40,66.30L80.24,67.46L81.04,68.65L81.69,69.80L82.09,70.84L82.19,71.71L81.95,72.37L81.35,72.78L80.45,72.94L79.29,72.88L77.96,72.64L76.56,72.29L75.20,71.90L73.95,71.57L72.91,71.37L72.13,71.37L71.64,71.64L71.43,72.19L71.47,73.02L71.70,74.10L72.06,75.37L72.45,76.75L72.79,78.14L73.01,79.45L73.03,80.56L72.82,81.41L72.37,81.95L71.67,82.13L70.76,81.97L69.70,81.52L68.53,80.84L67.34,80.03L66.19,79.20L65.13,78.46L64.22,77.92L63.49,77.66L62.93,77.73L62.55,78.18L62.30,78.97L62.15,80.07L62.05,81.39L61.94,82.82L61.79,84.24L61.55,85.54L61.19,86.60L60.70,87.33L60.09,87.67L59.38,87.60L58.58,87.15L57.73,86.36L56.87,85.32L56.02,84.15L55.22,82.98L54.49,81.92L53.82,81.10L53.22,80.60L52.67,80.49L52.15,80.77L51.65,81.43L51.13,82.41L50.59,83.61L50.00,84.92L49.37,86.21L48.70,87.34L48.00,88.22L47.29,88.74L46.60,88.85L45.95,88.54L45.35,87.84L44.83,86.81L44.37,85.54L43.98,84.15L43.63,82.77L43.30,81.53L42.95,80.53L42.56,79.86L42.08,79.56L41.50,79.65L40.80,80.10L39.98,80.84L39.05,81.79L38.06,82.82L37.02,83.81L36.00,84.65L35.05,85.23L34.21,85.47L33.52,85.34L33.01,84.83L32.69,83.97L32.55,82.82L32.56,81.47L32.66,80.03L32.80,78.62L32.92,77.34L32.94,76.28L32.79,75.51L32.45,75.07L31.87,74.95L31.06,75.14L30.03,75.56L28.84,76.13L27.55,76.75L26.24,77.33L25.00,77.77L23.90,77.99L23.03,77.93L22.42,77.58L22.12,76.92L22.12,76.00L22.38,74.87L22.85,73.61L23.44,72.29L24.05,71.01L24.60,69.84L24.98,68.86L25.11,68.09L24.93,67.55L24.43,67.25L23.60,67.14L22.50,67.19L21.18,67.32L19.76,67.46L18.33,67.56L17.01,67.54L15.90,67.37L15.10,67.02L14.66,66.48L14.60,65.76L14.91,64.90L15.54,63.92L16.41,62.89L17.41,61.86L18.43,60.87L19.34,59.96L20.04,59.16L20.42,58.48L20.44,57.92L20.07,57.46L19.33,57.08L18.28,56.74L17.00,56.41L15.61,56.06L14.23,55.67L13.00,55.20L12.02,54.66L11.38,54.06L11.15,53.40L11.34,52.70L11.93,52.00L12.85,51.30L14.02,50.63L15.32,50.00L16.62,49.42L17.79,48.88L18.71,48.36L19.31,47.85L19.51,47.33L19.32,46.78L18.76,46.16L17.88,45.49L16.79,44.74L15.61,43.94L14.45,43.09L13.45,42.23L12.71,41.39L12.32,40.61L12.33,39.91L12.75,39.32L13.54,38.85L14.65,38.51L15.98,38.29L17.41,38.14L18.83,38.04L20.11,37.93L21.16,37.76L21.89,37.48L22.27,37.07L22.28,36.48L21.95,35.71L21.36,34.77L20.60,33.70L19.76,32.54L18.96,31.35L18.31,30.20L17.91,29.16L17.81,28.29L18.05,27.63L18.65,27.22L19.55,27.06L20.71,27.12L22.04,27.36L23.44,27.71L24.80,28.10L26.05,28.43L27.09,28.63L27.87,28.63L28.36,28.36L28.57,27.81L28.53,26.98L28.30,25.90L27.94,24.63L27.55,23.25L27.21,21.86L26.99,20.55L26.97,19.44L27.18,18.59L27.63,18.05L28.33,17.87L29.24,18.03L30.30,18.48L31.47,19.16L32.66,19.97L33.81,20.80L34.87,21.54L35.78,22.08L36.51,22.34L37.07,22.27L37.45,21.82L37.70,21.03L37.85,19.93L37.95,18.61L38.06,17.18L38.21,15.76L38.45,14.46L38.81,13.40L39.30,12.67L39.91,12.33L40.62,12.40L41.42,12.85L42.27,13.64L43.13,14.68L43.98,15.85L44.78,17.02L45.51,18.08L46.18,18.90L46.78,19.40L47.33,19.51L47.85,19.23L48.35,18.57L48.87,17.59L49.41,16.39L50.00,15.08L50.63,13.79L51.30,12.66L52.00,11.78L52.71,11.26L53.40,11.15L54.05,11.46L54.65,12.16L55.17,13.19L55.63,14.46L56.02,15.85L56.37,17.23L56.70,18.47L57.05,19.47L57.44,20.14L57.92,20.44L58.50,20.35L59.20,19.90L60.02,19.16L60.95,18.21L61.94,17.18L62.98,16.19L64.00,15.35L64.95,14.77L65.79,14.53L66.48,14.66L66.99,15.17L67.31,16.03L67.45,17.18L67.44,18.53L67.34,19.97L67.20,21.38L67.08,22.66L67.06,23.72L67.21,24.49L67.55,24.93L68.13,25.05L68.94,24.86L69.97,24.44L71.16,23.87L72.45,23.25L73.76,22.67L75.00,22.23L76.10,22.01L76.97,22.07L77.58,22.42L77.88,23.08L77.88,24.00L77.62,25.13L77.15,26.39L76.56,27.71L75.95,28.99L75.40,30.16L75.02,31.14L74.89,31.91L75.07,32.45L75.57,32.75L76.40,32.86L77.50,32.81L78.82,32.68L80.24,32.54L81.67,32.44L82.99,32.46L84.10,32.63L84.90,32.98L85.34,33.52L85.40,34.24L85.09,35.10L84.46,36.08L83.59,37.11L82.59,38.14L81.57,39.13L80.66,40.04L79.96,40.84L79.58,41.52L79.56,42.08L79.93,42.54L80.67,42.92L81.72,43.26L83.00,43.59L84.39,43.94L85.77,44.33L87.00,44.80L87.98,45.34L88.62,45.94L88.85,46.60L88.66,47.30L88.07,48.00L87.15,48.70L85.98,49.37L84.68,50.00Z\"/><path d=\"M80.40,50.00L79.74,50.52L79.41,51.03L79.44,51.54L79.82,52.09L80.52,52.67L81.45,53.31L82.53,53.99L83.63,54.73L84.64,55.49L85.46,56.25L85.98,56.99L86.17,57.69L85.98,58.31L85.42,58.83L84.55,59.26L83.43,59.59L82.16,59.83L80.85,60.03L79.62,60.20L78.56,60.40L77.77,60.66L77.28,61.02L77.13,61.52L77.31,62.16L77.76,62.95L78.42,63.86L79.20,64.88L79.98,65.94L80.67,67.00L81.18,68.00L81.42,68.88L81.36,69.59L80.97,70.11L80.27,70.41L79.30,70.51L78.13,70.44L76.86,70.24L75.56,69.97L74.35,69.72L73.29,69.54L72.45,69.51L71.87,69.69L71.56,70.10L71.50,70.77L71.66,71.66L71.97,72.75L72.35,73.97L72.72,75.24L73.01,76.47L73.14,77.58L73.07,78.49L72.76,79.14L72.22,79.49L71.46,79.53L70.51,79.30L69.45,78.83L68.32,78.20L67.19,77.51L66.14,76.85L65.20,76.33L64.42,76.01L63.81,75.98L63.38,76.26L63.10,76.87L62.95,77.76L62.86,78.89L62.80,80.17L62.72,81.49L62.57,82.74L62.31,83.83L61.93,84.66L61.43,85.17L60.80,85.31L60.06,85.09L59.26,84.55L58.41,83.74L57.56,82.77L56.75,81.73L55.98,80.75L55.28,79.94L54.65,79.38L54.10,79.14L53.59,79.26L53.12,79.73L52.67,80.52L52.21,81.55L51.72,82.73L51.19,83.94L50.61,85.07L50.00,86.00L49.36,86.65L48.71,86.95L48.07,86.87L47.45,86.42L46.88,85.63L46.36,84.58L45.90,83.38L45.48,82.13L45.10,80.94L44.72,79.94L44.32,79.20L43.88,78.78L43.37,78.72L42.77,79.01L42.07,79.59L41.28,80.40L40.42,81.34L39.51,82.30L38.58,83.16L37.69,83.83L36.86,84.22L36.15,84.28L35.57,83.99L35.15,83.35L34.88,82.42L34.76,81.26L34.73,79.96L34.77,78.64L34.81,77.40L34.80,76.33L34.68,75.49L34.41,74.95L33.95,74.72L33.28,74.78L32.43,75.09L31.41,75.58L30.28,76.17L29.09,76.76L27.93,77.26L26.86,77.58L25.95,77.67L25.26,77.48L24.82,77.00L24.64,76.26L24.71,75.29L24.98,74.16L25.40,72.94L25.89,71.71L26.36,70.55L26.71,69.54L26.89,68.72L26.81,68.12L26.46,67.74L25.82,67.57L24.91,67.57L23.78,67.68L22.52,67.85L21.20,68.00L19.94,68.06L18.82,68.00L17.94,67.77L17.35,67.36L17.10,66.76L17.19,66.00L17.58,65.12L18.23,64.14L19.04,63.14L19.92,62.15L20.75,61.23L21.44,60.40L21.88,59.68L22.02,59.09L21.81,58.62L21.27,58.24L20.41,57.93L19.31,57.65L18.07,57.37L16.78,57.06L15.57,56.69L14.54,56.25L13.79,55.73L13.38,55.15L13.35,54.50L13.69,53.82L14.37,53.12L15.31,52.43L16.42,51.76L17.58,51.13L18.68,50.55L19.60,50.00L20.26,49.48L20.59,48.97L20.56,48.46L20.18,47.91L19.48,47.33L18.55,46.69L17.47,46.01L16.37,45.27L15.36,44.51L14.54,43.75L14.02,43.01L13.83,42.31L14.02,41.69L14.58,41.17L15.45,40.74L16.57,40.41L17.84,40.17L19.15,39.97L20.38,39.80L21.44,39.60L22.23,39.34L22.72,38.98L22.87,38.48L22.69,37.84L22.24,37.05L21.58,36.14L20.80,35.12L20.02,34.06L19.33,33.00L18.82,32.00L18.58,31.12L18.64,30.41L19.03,29.89L19.73,29.59L20.70,29.49L21.87,29.56L23.14,29.76L24.44,30.03L25.65,30.28L26.71,30.46L27.55,30.49L28.13,30.31L28.44,29.90L28.50,29.23L28.34,28.34L28.03,27.25L27.65,26.03L27.28,24.76L26.99,23.53L26.86,22.42L26.93,21.51L27.24,20.86L27.78,20.51L28.54,20.47L29.49,20.70L30.55,21.17L31.68,21.80L32.81,22.49L33.86,23.15L34.80,23.67L35.58,23.99L36.19,24.02L36.62,23.74L36.90,23.13L37.05,22.24L37.14,21.11L37.20,19.83L37.28,18.51L37.43,17.26L37.69,16.17L38.07,15.34L38.57,14.83L39.20,14.69L39.94,14.91L40.74,15.45L41.59,16.26L42.44,17.23L43.25,18.27L44.02,19.25L44.72,20.06L45.35,20.62L45.90,20.86L46.41,20.74L46.88,20.27L47.33,19.48L47.79,18.45L48.28,17.27L48.81,16.06L49.39,14.93L50.00,14.00L50.64,13.35L51.29,13.05L51.93,13.13L52.55,13.58L53.12,14.37L53.64,15.42L54.10,16.62L54.52,17.87L54.90,19.06L55.28,20.06L55.68,20.80L56.12,21.22L56.63,21.28L57.23,20.99L57.93,20.41L58.72,19.60L59.58,18.66L60.49,17.70L61.42,16.84L62.31,16.17L63.14,15.78L63.85,15.72L64.43,16.01L64.85,16.65L65.12,17.58L65.24,18.74L65.27,20.04L65.23,21.36L65.19,22.60L65.20,23.67L65.32,24.51L65.59,25.05L66.05,25.28L66.72,25.22L67.57,24.91L68.59,24.42L69.72,23.83L70.91,23.24L72.07,22.74L73.14,22.42L74.05,22.33L74.74,22.52L75.18,23.00L75.36,23.74L75.29,24.71L75.02,25.84L74.60,27.06L74.11,28.29L73.64,29.45L73.29,30.46L73.11,31.28L73.19,31.88L73.54,32.26L74.18,32.43L75.09,32.43L76.22,32.32L77.48,32.15L78.80,32.00L80.06,31.94L81.18,32.00L82.06,32.23L82.65,32.64L82.90,33.24L82.81,34.00L82.42,34.88L81.77,35.86L80.96,36.86L80.08,37.85L79.25,38.77L78.56,39.60L78.12,40.32L77.98,40.91L78.19,41.38L78.73,41.76L79.59,42.07L80.69,42.35L81.93,42.63L83.22,42.94L84.43,43.31L85.46,43.75L86.21,44.27L86.62,44.85L86.65,45.50L86.31,46.18L85.63,46.88L84.69,47.57L83.58,48.24L82.42,48.87L81.32,49.45L80.40,50.00Z\"/><path d=\"M78.21,50.00L78.43,50.50L78.95,51.01L79.72,51.56L80.67,52.14L81.68,52.77L82.66,53.43L83.50,54.11L84.13,54.80L84.46,55.46L84.46,56.08L84.13,56.63L83.48,57.12L82.58,57.52L81.50,57.85L80.33,58.13L79.19,58.37L78.16,58.61L77.33,58.88L76.77,59.22L76.50,59.65L76.54,60.19L76.86,60.85L77.40,61.63L78.08,62.50L78.82,63.44L79.51,64.40L80.08,65.32L80.43,66.18L80.51,66.91L80.31,67.50L79.80,67.91L79.03,68.14L78.04,68.21L76.91,68.15L75.72,68.01L74.56,67.85L73.52,67.72L72.65,67.69L72.00,67.82L71.61,68.13L71.46,68.65L71.53,69.39L71.77,70.30L72.11,71.35L72.48,72.48L72.81,73.62L73.02,74.69L73.06,75.61L72.89,76.33L72.49,76.81L71.88,77.02L71.07,76.97L70.12,76.70L69.08,76.26L68.01,75.72L66.98,75.17L66.04,74.69L65.23,74.37L64.58,74.27L64.10,74.43L63.78,74.87L63.60,75.58L63.51,76.52L63.48,77.63L63.44,78.82L63.36,80.00L63.19,81.07L62.91,81.95L62.50,82.57L61.97,82.88L61.32,82.87L60.58,82.55L59.78,81.97L58.95,81.20L58.13,80.33L57.35,79.46L56.62,78.69L55.97,78.11L55.40,77.79L54.90,77.78L54.45,78.08L54.03,78.69L53.63,79.54L53.21,80.57L52.77,81.68L52.29,82.76L51.77,83.71L51.20,84.44L50.61,84.88L50.00,84.99L49.39,84.76L48.81,84.21L48.25,83.39L47.74,82.38L47.26,81.28L46.83,80.20L46.41,79.22L46.00,78.46L45.57,77.96L45.10,77.78L44.57,77.91L43.98,78.34L43.30,79.00L42.56,79.83L41.77,80.71L40.95,81.57L40.13,82.28L39.35,82.78L38.64,82.99L38.03,82.88L37.54,82.46L37.18,81.74L36.94,80.78L36.80,79.65L36.73,78.46L36.69,77.29L36.63,76.24L36.51,75.37L36.27,74.76L35.90,74.43L35.36,74.37L34.65,74.57L33.79,74.96L32.81,75.48L31.76,76.05L30.70,76.57L29.69,76.96L28.78,77.16L28.04,77.11L27.51,76.81L27.19,76.24L27.10,75.44L27.20,74.45L27.45,73.35L27.80,72.20L28.16,71.09L28.47,70.08L28.64,69.23L28.63,68.57L28.39,68.13L27.90,67.89L27.17,67.84L26.23,67.91L25.13,68.07L23.95,68.24L22.78,68.36L21.69,68.38L20.77,68.26L20.09,67.97L19.69,67.50L19.59,66.86L19.78,66.07L20.21,65.18L20.83,64.23L21.54,63.27L22.26,62.35L22.90,61.50L23.36,60.77L23.57,60.15L23.50,59.65L23.12,59.26L22.45,58.95L21.54,58.70L20.45,58.47L19.29,58.23L18.14,57.94L17.11,57.59L16.29,57.17L15.75,56.66L15.54,56.08L15.66,55.44L16.10,54.76L16.81,54.07L17.72,53.39L18.72,52.74L19.71,52.12L20.60,51.54L21.28,51.00L21.69,50.49L21.79,50.00L21.57,49.50L21.05,48.99L20.28,48.44L19.33,47.86L18.32,47.23L17.34,46.57L16.50,45.89L15.87,45.20L15.54,44.54L15.54,43.92L15.87,43.37L16.52,42.88L17.42,42.48L18.50,42.15L19.67,41.87L20.81,41.63L21.84,41.39L22.67,41.12L23.23,40.78L23.50,40.35L23.46,39.81L23.14,39.15L22.60,38.37L21.92,37.50L21.18,36.56L20.49,35.60L19.92,34.68L19.57,33.82L19.49,33.09L19.69,32.50L20.20,32.09L20.97,31.86L21.96,31.79L23.09,31.85L24.28,31.99L25.44,32.15L26.48,32.28L27.35,32.31L28.00,32.18L28.39,31.87L28.54,31.35L28.47,30.61L28.23,29.70L27.89,28.65L27.52,27.52L27.19,26.38L26.98,25.31L26.94,24.39L27.11,23.67L27.51,23.19L28.12,22.98L28.93,23.03L29.88,23.30L30.92,23.74L31.99,24.28L33.02,24.83L33.96,25.31L34.77,25.63L35.42,25.73L35.90,25.57L36.22,25.13L36.40,24.42L36.49,23.48L36.52,22.37L36.56,21.18L36.64,20.00L36.81,18.93L37.09,18.05L37.50,17.43L38.03,17.12L38.68,17.13L39.42,17.45L40.22,18.03L41.05,18.80L41.87,19.67L42.65,20.54L43.38,21.31L44.03,21.89L44.60,22.21L45.10,22.22L45.55,21.92L45.97,21.31L46.37,20.46L46.79,19.43L47.23,18.32L47.71,17.24L48.23,16.29L48.80,15.56L49.39,15.12L50.00,15.01L50.61,15.24L51.19,15.79L51.75,16.61L52.26,17.62L52.74,18.72L53.17,19.80L53.59,20.78L54.00,21.54L54.43,22.04L54.90,22.22L55.43,22.09L56.02,21.66L56.70,21.00L57.44,20.17L58.23,19.29L59.05,18.43L59.87,17.72L60.65,17.22L61.36,17.01L61.97,17.12L62.46,17.54L62.82,18.26L63.06,19.22L63.20,20.35L63.27,21.54L63.31,22.71L63.37,23.76L63.49,24.63L63.73,25.24L64.10,25.57L64.64,25.63L65.35,25.43L66.21,25.04L67.19,24.52L68.24,23.95L69.30,23.43L70.31,23.04L71.22,22.84L71.96,22.89L72.49,23.19L72.81,23.76L72.90,24.56L72.80,25.55L72.55,26.65L72.20,27.80L71.84,28.91L71.53,29.92L71.36,30.77L71.37,31.43L71.61,31.87L72.10,32.11L72.83,32.16L73.77,32.09L74.87,31.93L76.05,31.76L77.22,31.64L78.31,31.62L79.23,31.74L79.91,32.03L80.31,32.50L80.41,33.14L80.22,33.93L79.79,34.82L79.17,35.77L78.46,36.73L77.74,37.65L77.10,38.50L76.64,39.23L76.43,39.85L76.50,40.35L76.88,40.74L77.55,41.05L78.46,41.30L79.55,41.53L80.71,41.77L81.86,42.06L82.89,42.41L83.71,42.83L84.25,43.34L84.46,43.92L84.34,44.56L83.90,45.24L83.19,45.93L82.28,46.61L81.28,47.26L80.29,47.88L79.40,48.46L78.72,49.00L78.31,49.51L78.21,50.00Z\"/><circle cx=\"50\" cy=\"50\" r=\"28\" stroke-width=\".8\"/><circle cx=\"50\" cy=\"50\" r=\"25.5\" stroke-width=\".45\"/></g><g transform=\"translate(23 23) scale(.54)\" fill=\"currentColor\" style=\"--seal-paper:var(--ex-paper)\"><circle cx=\"50\" cy=\"46\" r=\"26\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\"/>\n   <circle cx=\"50\" cy=\"46\" r=\"20\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1\"/>\n   <path d=\"m50 13 7 26 26 7-26 7-7 26-7-26-26-7 26-7Z\" fill=\"currentColor\"/>\n   <path d=\"m50 24 0 22 17 0m-17 0 0 22-17-22Z\" fill=\"var(--seal-paper)\"/>\n   <path d=\"M15 82q9-7 18 0t18 0 18 0 18 0M20 90q9-7 18 0t18 0 18 0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/></g>"
], ve = "<g stroke=\"currentColor\" fill=\"none\"><rect x=\"3\" y=\"3\" width=\"594\" height=\"254\" stroke-width=\"1.8\"/><rect x=\"8\" y=\"8\" width=\"584\" height=\"244\" stroke-width=\".6\"/><path d=\"M26 27h548v206H26Z\" stroke-width=\".65\"/><g stroke-width=\".35\" opacity=\".65\"><path d=\"M12.00,11.00L15.60,13.43L19.20,13.85L22.80,11.93L26.40,9.24L30.00,8.00L33.60,9.24L37.20,11.93L40.80,13.85L44.40,13.43L48.00,11.00L51.60,8.57L55.20,8.15L58.80,10.07L62.40,12.76L66.00,14.00L69.60,12.76L73.20,10.07L76.80,8.15L80.40,8.57L84.00,11.00L87.60,13.43L91.20,13.85L94.80,11.93L98.40,9.24L102.00,8.00L105.60,9.24L109.20,11.93L112.80,13.85L116.40,13.43L120.00,11.00L123.60,8.57L127.20,8.15L130.80,10.07L134.40,12.76L138.00,14.00L141.60,12.76L145.20,10.07L148.80,8.15L152.40,8.57L156.00,11.00L159.60,13.43L163.20,13.85L166.80,11.93L170.40,9.24L174.00,8.00L177.60,9.24L181.20,11.93L184.80,13.85L188.40,13.43L192.00,11.00L195.60,8.57L199.20,8.15L202.80,10.07L206.40,12.76L210.00,14.00L213.60,12.76L217.20,10.07L220.80,8.15L224.40,8.57L228.00,11.00L231.60,13.43L235.20,13.85L238.80,11.93L242.40,9.24L246.00,8.00L249.60,9.24L253.20,11.93L256.80,13.85L260.40,13.43L264.00,11.00L267.60,8.57L271.20,8.15L274.80,10.07L278.40,12.76L282.00,14.00L285.60,12.76L289.20,10.07L292.80,8.15L296.40,8.57L300.00,11.00L303.60,13.43L307.20,13.85L310.80,11.93L314.40,9.24L318.00,8.00L321.60,9.24L325.20,11.93L328.80,13.85L332.40,13.43L336.00,11.00L339.60,8.57L343.20,8.15L346.80,10.07L350.40,12.76L354.00,14.00L357.60,12.76L361.20,10.07L364.80,8.15L368.40,8.57L372.00,11.00L375.60,13.43L379.20,13.85L382.80,11.93L386.40,9.24L390.00,8.00L393.60,9.24L397.20,11.93L400.80,13.85L404.40,13.43L408.00,11.00L411.60,8.57L415.20,8.15L418.80,10.07L422.40,12.76L426.00,14.00L429.60,12.76L433.20,10.07L436.80,8.15L440.40,8.57L444.00,11.00L447.60,13.43L451.20,13.85L454.80,11.93L458.40,9.24L462.00,8.00L465.60,9.24L469.20,11.93L472.80,13.85L476.40,13.43L480.00,11.00L483.60,8.57L487.20,8.15L490.80,10.07L494.40,12.76L498.00,14.00L501.60,12.76L505.20,10.07L508.80,8.15L512.40,8.57L516.00,11.00L519.60,13.43L523.20,13.85L526.80,11.93L530.40,9.24L534.00,8.00L537.60,9.24L541.20,11.93L544.80,13.85L548.40,13.43L552.00,11.00L555.60,8.57L559.20,8.15L562.80,10.07L566.40,12.76L570.00,14.00L573.60,12.76L577.20,10.07L580.80,8.15L584.40,8.57L588.00,11.00\"/><path d=\"M12.00,11.00L15.60,13.43L19.20,13.85L22.80,11.93L26.40,9.24L30.00,8.00L33.60,9.24L37.20,11.93L40.80,13.85L44.40,13.43L48.00,11.00L51.60,8.57L55.20,8.15L58.80,10.07L62.40,12.76L66.00,14.00L69.60,12.76L73.20,10.07L76.80,8.15L80.40,8.57L84.00,11.00L87.60,13.43L91.20,13.85L94.80,11.93L98.40,9.24L102.00,8.00L105.60,9.24L109.20,11.93L112.80,13.85L116.40,13.43L120.00,11.00L123.60,8.57L127.20,8.15L130.80,10.07L134.40,12.76L138.00,14.00L141.60,12.76L145.20,10.07L148.80,8.15L152.40,8.57L156.00,11.00L159.60,13.43L163.20,13.85L166.80,11.93L170.40,9.24L174.00,8.00L177.60,9.24L181.20,11.93L184.80,13.85L188.40,13.43L192.00,11.00L195.60,8.57L199.20,8.15L202.80,10.07L206.40,12.76L210.00,14.00L213.60,12.76L217.20,10.07L220.80,8.15L224.40,8.57L228.00,11.00L231.60,13.43L235.20,13.85L238.80,11.93L242.40,9.24L246.00,8.00L249.60,9.24L253.20,11.93L256.80,13.85L260.40,13.43L264.00,11.00L267.60,8.57L271.20,8.15L274.80,10.07L278.40,12.76L282.00,14.00L285.60,12.76L289.20,10.07L292.80,8.15L296.40,8.57L300.00,11.00L303.60,13.43L307.20,13.85L310.80,11.93L314.40,9.24L318.00,8.00L321.60,9.24L325.20,11.93L328.80,13.85L332.40,13.43L336.00,11.00L339.60,8.57L343.20,8.15L346.80,10.07L350.40,12.76L354.00,14.00L357.60,12.76L361.20,10.07L364.80,8.15L368.40,8.57L372.00,11.00L375.60,13.43L379.20,13.85L382.80,11.93L386.40,9.24L390.00,8.00L393.60,9.24L397.20,11.93L400.80,13.85L404.40,13.43L408.00,11.00L411.60,8.57L415.20,8.15L418.80,10.07L422.40,12.76L426.00,14.00L429.60,12.76L433.20,10.07L436.80,8.15L440.40,8.57L444.00,11.00L447.60,13.43L451.20,13.85L454.80,11.93L458.40,9.24L462.00,8.00L465.60,9.24L469.20,11.93L472.80,13.85L476.40,13.43L480.00,11.00L483.60,8.57L487.20,8.15L490.80,10.07L494.40,12.76L498.00,14.00L501.60,12.76L505.20,10.07L508.80,8.15L512.40,8.57L516.00,11.00L519.60,13.43L523.20,13.85L526.80,11.93L530.40,9.24L534.00,8.00L537.60,9.24L541.20,11.93L544.80,13.85L548.40,13.43L552.00,11.00L555.60,8.57L559.20,8.15L562.80,10.07L566.40,12.76L570.00,14.00L573.60,12.76L577.20,10.07L580.80,8.15L584.40,8.57L588.00,11.00\" transform=\"translate(0 260) scale(1 -1)\"/><path d=\"M12.00,14.42L15.60,15.60L19.20,14.31L22.80,11.61L26.40,9.73L30.00,10.21L33.60,12.67L37.20,15.06L40.80,15.43L44.40,13.46L48.00,10.78L51.60,9.60L55.20,10.89L58.80,13.59L62.40,15.47L66.00,14.99L69.60,12.53L73.20,10.14L76.80,9.77L80.40,11.74L84.00,14.42L87.60,15.60L91.20,14.31L94.80,11.61L98.40,9.73L102.00,10.21L105.60,12.67L109.20,15.06L112.80,15.43L116.40,13.46L120.00,10.78L123.60,9.60L127.20,10.89L130.80,13.59L134.40,15.47L138.00,14.99L141.60,12.53L145.20,10.14L148.80,9.77L152.40,11.74L156.00,14.42L159.60,15.60L163.20,14.31L166.80,11.61L170.40,9.73L174.00,10.21L177.60,12.67L181.20,15.06L184.80,15.43L188.40,13.46L192.00,10.78L195.60,9.60L199.20,10.89L202.80,13.59L206.40,15.47L210.00,14.99L213.60,12.53L217.20,10.14L220.80,9.77L224.40,11.74L228.00,14.42L231.60,15.60L235.20,14.31L238.80,11.61L242.40,9.73L246.00,10.21L249.60,12.67L253.20,15.06L256.80,15.43L260.40,13.46L264.00,10.78L267.60,9.60L271.20,10.89L274.80,13.59L278.40,15.47L282.00,14.99L285.60,12.53L289.20,10.14L292.80,9.77L296.40,11.74L300.00,14.42L303.60,15.60L307.20,14.31L310.80,11.61L314.40,9.73L318.00,10.21L321.60,12.67L325.20,15.06L328.80,15.43L332.40,13.46L336.00,10.78L339.60,9.60L343.20,10.89L346.80,13.59L350.40,15.47L354.00,14.99L357.60,12.53L361.20,10.14L364.80,9.77L368.40,11.74L372.00,14.42L375.60,15.60L379.20,14.31L382.80,11.61L386.40,9.73L390.00,10.21L393.60,12.67L397.20,15.06L400.80,15.43L404.40,13.46L408.00,10.78L411.60,9.60L415.20,10.89L418.80,13.59L422.40,15.47L426.00,14.99L429.60,12.53L433.20,10.14L436.80,9.77L440.40,11.74L444.00,14.42L447.60,15.60L451.20,14.31L454.80,11.61L458.40,9.73L462.00,10.21L465.60,12.67L469.20,15.06L472.80,15.43L476.40,13.46L480.00,10.78L483.60,9.60L487.20,10.89L490.80,13.59L494.40,15.47L498.00,14.99L501.60,12.53L505.20,10.14L508.80,9.77L512.40,11.74L516.00,14.42L519.60,15.60L523.20,14.31L526.80,11.61L530.40,9.73L534.00,10.21L537.60,12.67L541.20,15.06L544.80,15.43L548.40,13.46L552.00,10.78L555.60,9.60L559.20,10.89L562.80,13.59L566.40,15.47L570.00,14.99L573.60,12.53L577.20,10.14L580.80,9.77L584.40,11.74L588.00,14.42\"/><path d=\"M12.00,14.42L15.60,15.60L19.20,14.31L22.80,11.61L26.40,9.73L30.00,10.21L33.60,12.67L37.20,15.06L40.80,15.43L44.40,13.46L48.00,10.78L51.60,9.60L55.20,10.89L58.80,13.59L62.40,15.47L66.00,14.99L69.60,12.53L73.20,10.14L76.80,9.77L80.40,11.74L84.00,14.42L87.60,15.60L91.20,14.31L94.80,11.61L98.40,9.73L102.00,10.21L105.60,12.67L109.20,15.06L112.80,15.43L116.40,13.46L120.00,10.78L123.60,9.60L127.20,10.89L130.80,13.59L134.40,15.47L138.00,14.99L141.60,12.53L145.20,10.14L148.80,9.77L152.40,11.74L156.00,14.42L159.60,15.60L163.20,14.31L166.80,11.61L170.40,9.73L174.00,10.21L177.60,12.67L181.20,15.06L184.80,15.43L188.40,13.46L192.00,10.78L195.60,9.60L199.20,10.89L202.80,13.59L206.40,15.47L210.00,14.99L213.60,12.53L217.20,10.14L220.80,9.77L224.40,11.74L228.00,14.42L231.60,15.60L235.20,14.31L238.80,11.61L242.40,9.73L246.00,10.21L249.60,12.67L253.20,15.06L256.80,15.43L260.40,13.46L264.00,10.78L267.60,9.60L271.20,10.89L274.80,13.59L278.40,15.47L282.00,14.99L285.60,12.53L289.20,10.14L292.80,9.77L296.40,11.74L300.00,14.42L303.60,15.60L307.20,14.31L310.80,11.61L314.40,9.73L318.00,10.21L321.60,12.67L325.20,15.06L328.80,15.43L332.40,13.46L336.00,10.78L339.60,9.60L343.20,10.89L346.80,13.59L350.40,15.47L354.00,14.99L357.60,12.53L361.20,10.14L364.80,9.77L368.40,11.74L372.00,14.42L375.60,15.60L379.20,14.31L382.80,11.61L386.40,9.73L390.00,10.21L393.60,12.67L397.20,15.06L400.80,15.43L404.40,13.46L408.00,10.78L411.60,9.60L415.20,10.89L418.80,13.59L422.40,15.47L426.00,14.99L429.60,12.53L433.20,10.14L436.80,9.77L440.40,11.74L444.00,14.42L447.60,15.60L451.20,14.31L454.80,11.61L458.40,9.73L462.00,10.21L465.60,12.67L469.20,15.06L472.80,15.43L476.40,13.46L480.00,10.78L483.60,9.60L487.20,10.89L490.80,13.59L494.40,15.47L498.00,14.99L501.60,12.53L505.20,10.14L508.80,9.77L512.40,11.74L516.00,14.42L519.60,15.60L523.20,14.31L526.80,11.61L530.40,9.73L534.00,10.21L537.60,12.67L541.20,15.06L544.80,15.43L548.40,13.46L552.00,10.78L555.60,9.60L559.20,10.89L562.80,13.59L566.40,15.47L570.00,14.99L573.60,12.53L577.20,10.14L580.80,9.77L584.40,11.74L588.00,14.42\" transform=\"translate(0 260) scale(1 -1)\"/><path d=\"M12.00,17.09L15.60,16.55L19.20,14.07L22.80,11.70L26.40,11.39L30.00,13.40L33.60,16.07L37.20,17.20L40.80,15.86L44.40,13.15L48.00,11.31L51.60,11.85L55.20,14.33L58.80,16.70L62.40,17.01L66.00,15.00L69.60,12.33L73.20,11.20L76.80,12.54L80.40,15.25L84.00,17.09L87.60,16.55L91.20,14.07L94.80,11.70L98.40,11.39L102.00,13.40L105.60,16.07L109.20,17.20L112.80,15.86L116.40,13.15L120.00,11.31L123.60,11.85L127.20,14.33L130.80,16.70L134.40,17.01L138.00,15.00L141.60,12.33L145.20,11.20L148.80,12.54L152.40,15.25L156.00,17.09L159.60,16.55L163.20,14.07L166.80,11.70L170.40,11.39L174.00,13.40L177.60,16.07L181.20,17.20L184.80,15.86L188.40,13.15L192.00,11.31L195.60,11.85L199.20,14.33L202.80,16.70L206.40,17.01L210.00,15.00L213.60,12.33L217.20,11.20L220.80,12.54L224.40,15.25L228.00,17.09L231.60,16.55L235.20,14.07L238.80,11.70L242.40,11.39L246.00,13.40L249.60,16.07L253.20,17.20L256.80,15.86L260.40,13.15L264.00,11.31L267.60,11.85L271.20,14.33L274.80,16.70L278.40,17.01L282.00,15.00L285.60,12.33L289.20,11.20L292.80,12.54L296.40,15.25L300.00,17.09L303.60,16.55L307.20,14.07L310.80,11.70L314.40,11.39L318.00,13.40L321.60,16.07L325.20,17.20L328.80,15.86L332.40,13.15L336.00,11.31L339.60,11.85L343.20,14.33L346.80,16.70L350.40,17.01L354.00,15.00L357.60,12.33L361.20,11.20L364.80,12.54L368.40,15.25L372.00,17.09L375.60,16.55L379.20,14.07L382.80,11.70L386.40,11.39L390.00,13.40L393.60,16.07L397.20,17.20L400.80,15.86L404.40,13.15L408.00,11.31L411.60,11.85L415.20,14.33L418.80,16.70L422.40,17.01L426.00,15.00L429.60,12.33L433.20,11.20L436.80,12.54L440.40,15.25L444.00,17.09L447.60,16.55L451.20,14.07L454.80,11.70L458.40,11.39L462.00,13.40L465.60,16.07L469.20,17.20L472.80,15.86L476.40,13.15L480.00,11.31L483.60,11.85L487.20,14.33L490.80,16.70L494.40,17.01L498.00,15.00L501.60,12.33L505.20,11.20L508.80,12.54L512.40,15.25L516.00,17.09L519.60,16.55L523.20,14.07L526.80,11.70L530.40,11.39L534.00,13.40L537.60,16.07L541.20,17.20L544.80,15.86L548.40,13.15L552.00,11.31L555.60,11.85L559.20,14.33L562.80,16.70L566.40,17.01L570.00,15.00L573.60,12.33L577.20,11.20L580.80,12.54L584.40,15.25L588.00,17.09\"/><path d=\"M12.00,17.09L15.60,16.55L19.20,14.07L22.80,11.70L26.40,11.39L30.00,13.40L33.60,16.07L37.20,17.20L40.80,15.86L44.40,13.15L48.00,11.31L51.60,11.85L55.20,14.33L58.80,16.70L62.40,17.01L66.00,15.00L69.60,12.33L73.20,11.20L76.80,12.54L80.40,15.25L84.00,17.09L87.60,16.55L91.20,14.07L94.80,11.70L98.40,11.39L102.00,13.40L105.60,16.07L109.20,17.20L112.80,15.86L116.40,13.15L120.00,11.31L123.60,11.85L127.20,14.33L130.80,16.70L134.40,17.01L138.00,15.00L141.60,12.33L145.20,11.20L148.80,12.54L152.40,15.25L156.00,17.09L159.60,16.55L163.20,14.07L166.80,11.70L170.40,11.39L174.00,13.40L177.60,16.07L181.20,17.20L184.80,15.86L188.40,13.15L192.00,11.31L195.60,11.85L199.20,14.33L202.80,16.70L206.40,17.01L210.00,15.00L213.60,12.33L217.20,11.20L220.80,12.54L224.40,15.25L228.00,17.09L231.60,16.55L235.20,14.07L238.80,11.70L242.40,11.39L246.00,13.40L249.60,16.07L253.20,17.20L256.80,15.86L260.40,13.15L264.00,11.31L267.60,11.85L271.20,14.33L274.80,16.70L278.40,17.01L282.00,15.00L285.60,12.33L289.20,11.20L292.80,12.54L296.40,15.25L300.00,17.09L303.60,16.55L307.20,14.07L310.80,11.70L314.40,11.39L318.00,13.40L321.60,16.07L325.20,17.20L328.80,15.86L332.40,13.15L336.00,11.31L339.60,11.85L343.20,14.33L346.80,16.70L350.40,17.01L354.00,15.00L357.60,12.33L361.20,11.20L364.80,12.54L368.40,15.25L372.00,17.09L375.60,16.55L379.20,14.07L382.80,11.70L386.40,11.39L390.00,13.40L393.60,16.07L397.20,17.20L400.80,15.86L404.40,13.15L408.00,11.31L411.60,11.85L415.20,14.33L418.80,16.70L422.40,17.01L426.00,15.00L429.60,12.33L433.20,11.20L436.80,12.54L440.40,15.25L444.00,17.09L447.60,16.55L451.20,14.07L454.80,11.70L458.40,11.39L462.00,13.40L465.60,16.07L469.20,17.20L472.80,15.86L476.40,13.15L480.00,11.31L483.60,11.85L487.20,14.33L490.80,16.70L494.40,17.01L498.00,15.00L501.60,12.33L505.20,11.20L508.80,12.54L512.40,15.25L516.00,17.09L519.60,16.55L523.20,14.07L526.80,11.70L530.40,11.39L534.00,13.40L537.60,16.07L541.20,17.20L544.80,15.86L548.40,13.15L552.00,11.31L555.60,11.85L559.20,14.33L562.80,16.70L566.40,17.01L570.00,15.00L573.60,12.33L577.20,11.20L580.80,12.54L584.40,15.25L588.00,17.09\" transform=\"translate(0 260) scale(1 -1)\"/><path d=\"M12.00,18.59L15.60,16.54L19.20,13.88L22.80,12.81L26.40,14.20L30.00,16.91L33.60,18.71L37.20,18.11L40.80,15.61L44.40,13.26L48.00,13.01L51.60,15.06L55.20,17.72L58.80,18.79L62.40,17.40L66.00,14.69L69.60,12.89L73.20,13.49L76.80,15.99L80.40,18.34L84.00,18.59L87.60,16.54L91.20,13.88L94.80,12.81L98.40,14.20L102.00,16.91L105.60,18.71L109.20,18.11L112.80,15.61L116.40,13.26L120.00,13.01L123.60,15.06L127.20,17.72L130.80,18.79L134.40,17.40L138.00,14.69L141.60,12.89L145.20,13.49L148.80,15.99L152.40,18.34L156.00,18.59L159.60,16.54L163.20,13.88L166.80,12.81L170.40,14.20L174.00,16.91L177.60,18.71L181.20,18.11L184.80,15.61L188.40,13.26L192.00,13.01L195.60,15.06L199.20,17.72L202.80,18.79L206.40,17.40L210.00,14.69L213.60,12.89L217.20,13.49L220.80,15.99L224.40,18.34L228.00,18.59L231.60,16.54L235.20,13.88L238.80,12.81L242.40,14.20L246.00,16.91L249.60,18.71L253.20,18.11L256.80,15.61L260.40,13.26L264.00,13.01L267.60,15.06L271.20,17.72L274.80,18.79L278.40,17.40L282.00,14.69L285.60,12.89L289.20,13.49L292.80,15.99L296.40,18.34L300.00,18.59L303.60,16.54L307.20,13.88L310.80,12.81L314.40,14.20L318.00,16.91L321.60,18.71L325.20,18.11L328.80,15.61L332.40,13.26L336.00,13.01L339.60,15.06L343.20,17.72L346.80,18.79L350.40,17.40L354.00,14.69L357.60,12.89L361.20,13.49L364.80,15.99L368.40,18.34L372.00,18.59L375.60,16.54L379.20,13.88L382.80,12.81L386.40,14.20L390.00,16.91L393.60,18.71L397.20,18.11L400.80,15.61L404.40,13.26L408.00,13.01L411.60,15.06L415.20,17.72L418.80,18.79L422.40,17.40L426.00,14.69L429.60,12.89L433.20,13.49L436.80,15.99L440.40,18.34L444.00,18.59L447.60,16.54L451.20,13.88L454.80,12.81L458.40,14.20L462.00,16.91L465.60,18.71L469.20,18.11L472.80,15.61L476.40,13.26L480.00,13.01L483.60,15.06L487.20,17.72L490.80,18.79L494.40,17.40L498.00,14.69L501.60,12.89L505.20,13.49L508.80,15.99L512.40,18.34L516.00,18.59L519.60,16.54L523.20,13.88L526.80,12.81L530.40,14.20L534.00,16.91L537.60,18.71L541.20,18.11L544.80,15.61L548.40,13.26L552.00,13.01L555.60,15.06L559.20,17.72L562.80,18.79L566.40,17.40L570.00,14.69L573.60,12.89L577.20,13.49L580.80,15.99L584.40,18.34L588.00,18.59\"/><path d=\"M12.00,18.59L15.60,16.54L19.20,13.88L22.80,12.81L26.40,14.20L30.00,16.91L33.60,18.71L37.20,18.11L40.80,15.61L44.40,13.26L48.00,13.01L51.60,15.06L55.20,17.72L58.80,18.79L62.40,17.40L66.00,14.69L69.60,12.89L73.20,13.49L76.80,15.99L80.40,18.34L84.00,18.59L87.60,16.54L91.20,13.88L94.80,12.81L98.40,14.20L102.00,16.91L105.60,18.71L109.20,18.11L112.80,15.61L116.40,13.26L120.00,13.01L123.60,15.06L127.20,17.72L130.80,18.79L134.40,17.40L138.00,14.69L141.60,12.89L145.20,13.49L148.80,15.99L152.40,18.34L156.00,18.59L159.60,16.54L163.20,13.88L166.80,12.81L170.40,14.20L174.00,16.91L177.60,18.71L181.20,18.11L184.80,15.61L188.40,13.26L192.00,13.01L195.60,15.06L199.20,17.72L202.80,18.79L206.40,17.40L210.00,14.69L213.60,12.89L217.20,13.49L220.80,15.99L224.40,18.34L228.00,18.59L231.60,16.54L235.20,13.88L238.80,12.81L242.40,14.20L246.00,16.91L249.60,18.71L253.20,18.11L256.80,15.61L260.40,13.26L264.00,13.01L267.60,15.06L271.20,17.72L274.80,18.79L278.40,17.40L282.00,14.69L285.60,12.89L289.20,13.49L292.80,15.99L296.40,18.34L300.00,18.59L303.60,16.54L307.20,13.88L310.80,12.81L314.40,14.20L318.00,16.91L321.60,18.71L325.20,18.11L328.80,15.61L332.40,13.26L336.00,13.01L339.60,15.06L343.20,17.72L346.80,18.79L350.40,17.40L354.00,14.69L357.60,12.89L361.20,13.49L364.80,15.99L368.40,18.34L372.00,18.59L375.60,16.54L379.20,13.88L382.80,12.81L386.40,14.20L390.00,16.91L393.60,18.71L397.20,18.11L400.80,15.61L404.40,13.26L408.00,13.01L411.60,15.06L415.20,17.72L418.80,18.79L422.40,17.40L426.00,14.69L429.60,12.89L433.20,13.49L436.80,15.99L440.40,18.34L444.00,18.59L447.60,16.54L451.20,13.88L454.80,12.81L458.40,14.20L462.00,16.91L465.60,18.71L469.20,18.11L472.80,15.61L476.40,13.26L480.00,13.01L483.60,15.06L487.20,17.72L490.80,18.79L494.40,17.40L498.00,14.69L501.60,12.89L505.20,13.49L508.80,15.99L512.40,18.34L516.00,18.59L519.60,16.54L523.20,13.88L526.80,12.81L530.40,14.20L534.00,16.91L537.60,18.71L541.20,18.11L544.80,15.61L548.40,13.26L552.00,13.01L555.60,15.06L559.20,17.72L562.80,18.79L566.40,17.40L570.00,14.69L573.60,12.89L577.20,13.49L580.80,15.99L584.40,18.34L588.00,18.59\" transform=\"translate(0 260) scale(1 -1)\"/><path d=\"M12.00,18.95L15.60,16.23L19.20,14.48L22.80,15.13L26.40,17.66L30.00,19.97L33.60,20.16L37.20,18.08L40.80,15.43L44.40,14.41L48.00,15.85L51.60,18.57L55.20,20.32L58.80,19.67L62.40,17.14L66.00,14.83L69.60,14.64L73.20,16.72L76.80,19.37L80.40,20.39L84.00,18.95L87.60,16.23L91.20,14.48L94.80,15.13L98.40,17.66L102.00,19.97L105.60,20.16L109.20,18.08L112.80,15.43L116.40,14.41L120.00,15.85L123.60,18.57L127.20,20.32L130.80,19.67L134.40,17.14L138.00,14.83L141.60,14.64L145.20,16.72L148.80,19.37L152.40,20.39L156.00,18.95L159.60,16.23L163.20,14.48L166.80,15.13L170.40,17.66L174.00,19.97L177.60,20.16L181.20,18.08L184.80,15.43L188.40,14.41L192.00,15.85L195.60,18.57L199.20,20.32L202.80,19.67L206.40,17.14L210.00,14.83L213.60,14.64L217.20,16.72L220.80,19.37L224.40,20.39L228.00,18.95L231.60,16.23L235.20,14.48L238.80,15.13L242.40,17.66L246.00,19.97L249.60,20.16L253.20,18.08L256.80,15.43L260.40,14.41L264.00,15.85L267.60,18.57L271.20,20.32L274.80,19.67L278.40,17.14L282.00,14.83L285.60,14.64L289.20,16.72L292.80,19.37L296.40,20.39L300.00,18.95L303.60,16.23L307.20,14.48L310.80,15.13L314.40,17.66L318.00,19.97L321.60,20.16L325.20,18.08L328.80,15.43L332.40,14.41L336.00,15.85L339.60,18.57L343.20,20.32L346.80,19.67L350.40,17.14L354.00,14.83L357.60,14.64L361.20,16.72L364.80,19.37L368.40,20.39L372.00,18.95L375.60,16.23L379.20,14.48L382.80,15.13L386.40,17.66L390.00,19.97L393.60,20.16L397.20,18.08L400.80,15.43L404.40,14.41L408.00,15.85L411.60,18.57L415.20,20.32L418.80,19.67L422.40,17.14L426.00,14.83L429.60,14.64L433.20,16.72L436.80,19.37L440.40,20.39L444.00,18.95L447.60,16.23L451.20,14.48L454.80,15.13L458.40,17.66L462.00,19.97L465.60,20.16L469.20,18.08L472.80,15.43L476.40,14.41L480.00,15.85L483.60,18.57L487.20,20.32L490.80,19.67L494.40,17.14L498.00,14.83L501.60,14.64L505.20,16.72L508.80,19.37L512.40,20.39L516.00,18.95L519.60,16.23L523.20,14.48L526.80,15.13L530.40,17.66L534.00,19.97L537.60,20.16L541.20,18.08L544.80,15.43L548.40,14.41L552.00,15.85L555.60,18.57L559.20,20.32L562.80,19.67L566.40,17.14L570.00,14.83L573.60,14.64L577.20,16.72L580.80,19.37L584.40,20.39L588.00,18.95\"/><path d=\"M12.00,18.95L15.60,16.23L19.20,14.48L22.80,15.13L26.40,17.66L30.00,19.97L33.60,20.16L37.20,18.08L40.80,15.43L44.40,14.41L48.00,15.85L51.60,18.57L55.20,20.32L58.80,19.67L62.40,17.14L66.00,14.83L69.60,14.64L73.20,16.72L76.80,19.37L80.40,20.39L84.00,18.95L87.60,16.23L91.20,14.48L94.80,15.13L98.40,17.66L102.00,19.97L105.60,20.16L109.20,18.08L112.80,15.43L116.40,14.41L120.00,15.85L123.60,18.57L127.20,20.32L130.80,19.67L134.40,17.14L138.00,14.83L141.60,14.64L145.20,16.72L148.80,19.37L152.40,20.39L156.00,18.95L159.60,16.23L163.20,14.48L166.80,15.13L170.40,17.66L174.00,19.97L177.60,20.16L181.20,18.08L184.80,15.43L188.40,14.41L192.00,15.85L195.60,18.57L199.20,20.32L202.80,19.67L206.40,17.14L210.00,14.83L213.60,14.64L217.20,16.72L220.80,19.37L224.40,20.39L228.00,18.95L231.60,16.23L235.20,14.48L238.80,15.13L242.40,17.66L246.00,19.97L249.60,20.16L253.20,18.08L256.80,15.43L260.40,14.41L264.00,15.85L267.60,18.57L271.20,20.32L274.80,19.67L278.40,17.14L282.00,14.83L285.60,14.64L289.20,16.72L292.80,19.37L296.40,20.39L300.00,18.95L303.60,16.23L307.20,14.48L310.80,15.13L314.40,17.66L318.00,19.97L321.60,20.16L325.20,18.08L328.80,15.43L332.40,14.41L336.00,15.85L339.60,18.57L343.20,20.32L346.80,19.67L350.40,17.14L354.00,14.83L357.60,14.64L361.20,16.72L364.80,19.37L368.40,20.39L372.00,18.95L375.60,16.23L379.20,14.48L382.80,15.13L386.40,17.66L390.00,19.97L393.60,20.16L397.20,18.08L400.80,15.43L404.40,14.41L408.00,15.85L411.60,18.57L415.20,20.32L418.80,19.67L422.40,17.14L426.00,14.83L429.60,14.64L433.20,16.72L436.80,19.37L440.40,20.39L444.00,18.95L447.60,16.23L451.20,14.48L454.80,15.13L458.40,17.66L462.00,19.97L465.60,20.16L469.20,18.08L472.80,15.43L476.40,14.41L480.00,15.85L483.60,18.57L487.20,20.32L490.80,19.67L494.40,17.14L498.00,14.83L501.60,14.64L505.20,16.72L508.80,19.37L512.40,20.39L516.00,18.95L519.60,16.23L523.20,14.48L526.80,15.13L530.40,17.66L534.00,19.97L537.60,20.16L541.20,18.08L544.80,15.43L548.40,14.41L552.00,15.85L555.60,18.57L559.20,20.32L562.80,19.67L566.40,17.14L570.00,14.83L573.60,14.64L577.20,16.72L580.80,19.37L584.40,20.39L588.00,18.95\" transform=\"translate(0 260) scale(1 -1)\"/><path d=\"M12.00,18.68L15.60,16.40L19.20,16.26L22.80,18.39L26.40,21.02L30.00,21.98L33.60,20.49L37.20,17.77L40.80,16.06L44.40,16.78L48.00,19.32L51.60,21.60L55.20,21.74L58.80,19.61L62.40,16.98L66.00,16.02L69.60,17.51L73.20,20.23L76.80,21.94L80.40,21.22L84.00,18.68L87.60,16.40L91.20,16.26L94.80,18.39L98.40,21.02L102.00,21.98L105.60,20.49L109.20,17.77L112.80,16.06L116.40,16.78L120.00,19.32L123.60,21.60L127.20,21.74L130.80,19.61L134.40,16.98L138.00,16.02L141.60,17.51L145.20,20.23L148.80,21.94L152.40,21.22L156.00,18.68L159.60,16.40L163.20,16.26L166.80,18.39L170.40,21.02L174.00,21.98L177.60,20.49L181.20,17.77L184.80,16.06L188.40,16.78L192.00,19.32L195.60,21.60L199.20,21.74L202.80,19.61L206.40,16.98L210.00,16.02L213.60,17.51L217.20,20.23L220.80,21.94L224.40,21.22L228.00,18.68L231.60,16.40L235.20,16.26L238.80,18.39L242.40,21.02L246.00,21.98L249.60,20.49L253.20,17.77L256.80,16.06L260.40,16.78L264.00,19.32L267.60,21.60L271.20,21.74L274.80,19.61L278.40,16.98L282.00,16.02L285.60,17.51L289.20,20.23L292.80,21.94L296.40,21.22L300.00,18.68L303.60,16.40L307.20,16.26L310.80,18.39L314.40,21.02L318.00,21.98L321.60,20.49L325.20,17.77L328.80,16.06L332.40,16.78L336.00,19.32L339.60,21.60L343.20,21.74L346.80,19.61L350.40,16.98L354.00,16.02L357.60,17.51L361.20,20.23L364.80,21.94L368.40,21.22L372.00,18.68L375.60,16.40L379.20,16.26L382.80,18.39L386.40,21.02L390.00,21.98L393.60,20.49L397.20,17.77L400.80,16.06L404.40,16.78L408.00,19.32L411.60,21.60L415.20,21.74L418.80,19.61L422.40,16.98L426.00,16.02L429.60,17.51L433.20,20.23L436.80,21.94L440.40,21.22L444.00,18.68L447.60,16.40L451.20,16.26L454.80,18.39L458.40,21.02L462.00,21.98L465.60,20.49L469.20,17.77L472.80,16.06L476.40,16.78L480.00,19.32L483.60,21.60L487.20,21.74L490.80,19.61L494.40,16.98L498.00,16.02L501.60,17.51L505.20,20.23L508.80,21.94L512.40,21.22L516.00,18.68L519.60,16.40L523.20,16.26L526.80,18.39L530.40,21.02L534.00,21.98L537.60,20.49L541.20,17.77L544.80,16.06L548.40,16.78L552.00,19.32L555.60,21.60L559.20,21.74L562.80,19.61L566.40,16.98L570.00,16.02L573.60,17.51L577.20,20.23L580.80,21.94L584.40,21.22L588.00,18.68\"/><path d=\"M12.00,18.68L15.60,16.40L19.20,16.26L22.80,18.39L26.40,21.02L30.00,21.98L33.60,20.49L37.20,17.77L40.80,16.06L44.40,16.78L48.00,19.32L51.60,21.60L55.20,21.74L58.80,19.61L62.40,16.98L66.00,16.02L69.60,17.51L73.20,20.23L76.80,21.94L80.40,21.22L84.00,18.68L87.60,16.40L91.20,16.26L94.80,18.39L98.40,21.02L102.00,21.98L105.60,20.49L109.20,17.77L112.80,16.06L116.40,16.78L120.00,19.32L123.60,21.60L127.20,21.74L130.80,19.61L134.40,16.98L138.00,16.02L141.60,17.51L145.20,20.23L148.80,21.94L152.40,21.22L156.00,18.68L159.60,16.40L163.20,16.26L166.80,18.39L170.40,21.02L174.00,21.98L177.60,20.49L181.20,17.77L184.80,16.06L188.40,16.78L192.00,19.32L195.60,21.60L199.20,21.74L202.80,19.61L206.40,16.98L210.00,16.02L213.60,17.51L217.20,20.23L220.80,21.94L224.40,21.22L228.00,18.68L231.60,16.40L235.20,16.26L238.80,18.39L242.40,21.02L246.00,21.98L249.60,20.49L253.20,17.77L256.80,16.06L260.40,16.78L264.00,19.32L267.60,21.60L271.20,21.74L274.80,19.61L278.40,16.98L282.00,16.02L285.60,17.51L289.20,20.23L292.80,21.94L296.40,21.22L300.00,18.68L303.60,16.40L307.20,16.26L310.80,18.39L314.40,21.02L318.00,21.98L321.60,20.49L325.20,17.77L328.80,16.06L332.40,16.78L336.00,19.32L339.60,21.60L343.20,21.74L346.80,19.61L350.40,16.98L354.00,16.02L357.60,17.51L361.20,20.23L364.80,21.94L368.40,21.22L372.00,18.68L375.60,16.40L379.20,16.26L382.80,18.39L386.40,21.02L390.00,21.98L393.60,20.49L397.20,17.77L400.80,16.06L404.40,16.78L408.00,19.32L411.60,21.60L415.20,21.74L418.80,19.61L422.40,16.98L426.00,16.02L429.60,17.51L433.20,20.23L436.80,21.94L440.40,21.22L444.00,18.68L447.60,16.40L451.20,16.26L454.80,18.39L458.40,21.02L462.00,21.98L465.60,20.49L469.20,17.77L472.80,16.06L476.40,16.78L480.00,19.32L483.60,21.60L487.20,21.74L490.80,19.61L494.40,16.98L498.00,16.02L501.60,17.51L505.20,20.23L508.80,21.94L512.40,21.22L516.00,18.68L519.60,16.40L523.20,16.26L526.80,18.39L530.40,21.02L534.00,21.98L537.60,20.49L541.20,17.77L544.80,16.06L548.40,16.78L552.00,19.32L555.60,21.60L559.20,21.74L562.80,19.61L566.40,16.98L570.00,16.02L573.60,17.51L577.20,20.23L580.80,21.94L584.40,21.22L588.00,18.68\" transform=\"translate(0 260) scale(1 -1)\"/></g><path d=\"M3 42h19V22h20V3M558 3v19h20v20h19M3 218h19v20h20v19m516 0v-19h20v-20h19\" stroke-width=\"1.3\"/></g>", ye = "<g fill=\"none\" stroke=\"currentColor\"><path d=\"M50 3 83 17 97 50 83 83 50 97 17 83 3 50 17 17Z\" stroke-width=\"1.1\"/><path d=\"M50 8 80 20 92 50 80 80 50 92 20 80 8 50 20 20Z\" stroke-width=\".6\"/><circle cx=\"50\" cy=\"50\" r=\"33\" stroke-width=\".8\"/><path d=\"M50 13v10m0 54v10M13 50h10m54 0h10M24 24l7 7m38 38 7 7M24 76l7-7m38-38 7-7\" stroke-width=\".7\"/></g><path d=\"m29 73 19-48h6l19 48H61l-4-11H40l-4 11Zm14-18h11l-5-16Z\" fill=\"currentColor\"/><path d=\"M22 76h56\" stroke=\"currentColor\" stroke-width=\"1.5\"/>";
//#endregion
//#region src/games/acquire/art.tsx
function be({ company: e = -1 }) {
	return /* @__PURE__ */ v("svg", {
		viewBox: "0 0 100 100",
		"aria-hidden": "true",
		className: "acquire-hotel ex-hotel",
		dangerouslySetInnerHTML: { __html: he[e < 0 ? 7 : e] }
	});
}
function X({ company: e }) {
	return /* @__PURE__ */ v("svg", {
		className: "acquire-seal ex-rosette",
		viewBox: "0 0 100 100",
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: _e[e] }
	});
}
function xe({ company: e }) {
	return /* @__PURE__ */ v("svg", {
		className: "ex-vignette",
		viewBox: "0 0 260 230",
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: ge[e] }
	});
}
function Se() {
	return /* @__PURE__ */ v("svg", {
		className: "ex-security-border",
		viewBox: "0 0 600 260",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: ve }
	});
}
function Ce({ className: e = "" }) {
	return /* @__PURE__ */ v("svg", {
		className: `ex-brand-seal ${e}`,
		viewBox: "0 0 100 100",
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: ye }
	});
}
function we() {
	return /* @__PURE__ */ y("svg", {
		className: "acquire-safe-mark",
		viewBox: "0 0 12 14",
		"aria-hidden": "true",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.4",
		children: [
			/* @__PURE__ */ v("path", { d: "M3 6V4a3 3 0 0 1 6 0v2" }),
			/* @__PURE__ */ v("rect", {
				x: "1",
				y: "6",
				width: "10",
				height: "7",
				rx: "1"
			}),
			/* @__PURE__ */ v("path", { d: "M6 8v3" })
		]
	});
}
//#endregion
//#region src/games/acquire/board.tsx
function Te({ tile: e, owner: t, selected: i, merging: a }) {
	let { ref: s } = o(`acquire-tile:${e}`), c = r(t), l = r(null), u = b();
	return n(() => {
		let e = c.current;
		if (c.current = t, u || e !== -2 || t === -2) return;
		let n = (l.current?.querySelector(".acquire-hotel"))?.animate([{
			transform: "translateY(-24px)",
			opacity: .5
		}, {
			transform: "translateY(0)",
			opacity: 1
		}], {
			duration: 420,
			easing: "cubic-bezier(.2,.8,.25,1)"
		});
		return () => n?.cancel();
	}, [
		t,
		u,
		s
	]), /* @__PURE__ */ y("div", {
		ref: (e) => {
			s(e), l.current = e;
		},
		className: "acquire-cell ex-cell",
		"data-owner": t,
		"data-occupied": t >= 0,
		"data-selected": i,
		"data-merging": a,
		style: t >= 0 ? { "--company": T[t].color } : void 0,
		children: [
			/* @__PURE__ */ v("span", {
				className: "ex-coord",
				children: E(e)
			}),
			(t !== -2 || i) && /* @__PURE__ */ v(be, { company: t }),
			t >= 0 && /* @__PURE__ */ v("span", {
				className: "ex-company-tab",
				children: T[t].letter
			}),
			i && /* @__PURE__ */ v("i", { className: "ex-lot-corner" })
		]
	});
}
function Ee({ pub: e, selected: t }) {
	let n = h(), { ref: r } = o("acquire-map");
	return /* @__PURE__ */ v("div", {
		ref: r,
		className: "ex-board-space",
		children: /* @__PURE__ */ v("div", {
			className: "acquire-board ex-tray",
			role: "img",
			"aria-label": n("games.acquire.board"),
			children: e.board.map((n, r) => /* @__PURE__ */ v(Te, {
				tile: r,
				owner: n,
				selected: t === r,
				merging: e.merger !== null && (e.merger.tile === r || n >= 0 && (e.merger.remaining.includes(n) || n === e.merger.survivor))
			}, r))
		})
	});
}
//#endregion
//#region src/games/acquire/log.ts
function De(e, t, n) {
	let r = (e) => t(T[e].key), i = (e) => e.length ? e.map((e) => t("games.acquire.playerAward", {
		name: n(e.rid),
		cash: e.amount
	})).join(", ") : t("games.acquire.noBonus");
	switch (e.type) {
		case "start": return t("games.acquire.logStart", {
			name: n(e.rid),
			tile: E(e.tile)
		});
		case "place": return t("games.acquire.logPlace", {
			name: n(e.rid),
			tile: E(e.tile)
		});
		case "found": return `${t("games.acquire.logFound", {
			name: n(e.rid),
			company: r(e.company),
			n: e.size
		})}${e.bonus ? ` · ${t("games.acquire.logFounderBonus")}` : ""}`;
		case "buy": return t("games.acquire.logBuy", {
			name: n(e.rid),
			cash: e.cost,
			stocks: e.stocks.flatMap((e, n) => e ? [t("games.acquire.stockAmount", {
				company: r(n),
				n: e
			})] : []).join(", ")
		});
		case "merge": return t("games.acquire.logMerge", {
			company: r(e.company),
			survivor: r(e.survivor),
			cash: e.price,
			holdings: e.holdings.map((e) => t("games.acquire.playerShares", {
				name: n(e.rid),
				n: e.n
			})).join(", ")
		});
		case "bonus": return t("games.acquire.logBonus", {
			company: r(e.company),
			awards: i(e.awards)
		});
		case "dispose": return t("games.acquire.logDispose", {
			name: n(e.rid),
			company: r(e.company),
			survivor: r(e.survivor),
			sell: e.sell,
			trade: e.trade,
			keep: e.keep
		});
		case "absorb": return t("games.acquire.logAbsorb", {
			company: r(e.company),
			survivor: r(e.survivor)
		});
		case "discard": return t("games.acquire.logDiscard", {
			name: n(e.rid),
			tiles: e.tiles.map(E).join(", ")
		});
		case "declare": return t("games.acquire.logDeclare", { name: n(e.rid) });
		case "pass": return t("games.acquire.logPass", { name: n(e.rid) });
		case "sale": return t("games.acquire.logSale", {
			company: r(e.company),
			awards: i(e.returns)
		});
	}
}
//#endregion
//#region src/games/acquire/securities.tsx
var Z = (e) => `$${e.toLocaleString("en-US")}`, Oe = [
	"TOWER",
	"LUXOR",
	"AMERICAN",
	"WORLDWIDE",
	"FESTIVAL",
	"IMPERIAL",
	"CONTINENTAL"
], ke = [
	4.4,
	4.2,
	6.4,
	7.8,
	5.8,
	6,
	8.5
], Q = (e) => ({ "--company": T[e].color });
function Ae({ company: e, order: t }) {
	let n = h(), r = n(T[e].key);
	return /* @__PURE__ */ y("div", {
		className: "ex-order-qty",
		children: [/* @__PURE__ */ v("span", { children: n("games.acquire.buyLabel") }), /* @__PURE__ */ y("div", {
			className: "ex-quantity",
			children: [
				/* @__PURE__ */ v("button", {
					type: "button",
					onClick: t.remove,
					disabled: !t.quantity,
					"aria-label": n("games.acquire.removeStock", { company: r }),
					children: "−"
				}),
				/* @__PURE__ */ v("b", { children: t.quantity }),
				/* @__PURE__ */ v("button", {
					type: "button",
					onClick: t.add,
					disabled: !t.canAdd,
					"aria-label": n("games.acquire.addStock", { company: r }),
					children: "+"
				})
			]
		})]
	});
}
function je({ quote: e, owned: t, selected: n, mobile: r = !1, order: i }) {
	let a = h(), o = m((e) => e.locale);
	return /* @__PURE__ */ y("article", {
		className: `ex-security${r ? " ex-mobile-cert" : ""}`,
		style: {
			...Q(e.company),
			"--wordmark-width": ke[e.company]
		},
		"data-selected": n,
		"data-inactive": !e.size,
		children: [
			/* @__PURE__ */ v(Se, {}),
			/* @__PURE__ */ y("div", {
				className: "ex-security-top",
				children: [/* @__PURE__ */ v("span", { children: a("games.acquire.certificate") }), /* @__PURE__ */ v("b", { children: a("games.acquire.shares", { n: 1 }) })]
			}),
			/* @__PURE__ */ y("div", {
				className: "ex-security-main",
				children: [
					/* @__PURE__ */ v("div", {
						className: "ex-security-art",
						children: /* @__PURE__ */ v(xe, { company: e.company })
					}),
					/* @__PURE__ */ y("div", {
						className: "ex-security-brand",
						children: [
							/* @__PURE__ */ v("h3", { children: Oe[e.company] }),
							/* @__PURE__ */ v("span", {
								className: "ex-hotels",
								children: "HOTELS"
							}),
							o === "zh" && /* @__PURE__ */ v("strong", {
								className: "ex-security-name",
								children: a(T[e.company].key)
							}),
							/* @__PURE__ */ y("div", {
								className: "ex-security-price",
								children: [/* @__PURE__ */ v("span", { children: a("games.acquire.perShare") }), /* @__PURE__ */ v("b", { children: e.size ? Z(e.price) : "—" })]
							})
						]
					}),
					/* @__PURE__ */ v("span", {
						className: "ex-security-seal",
						children: /* @__PURE__ */ v(X, { company: e.company })
					})
				]
			}),
			/* @__PURE__ */ y("div", {
				className: "ex-security-foot",
				children: [
					/* @__PURE__ */ y("span", { children: [
						a("games.acquire.supplyLabel"),
						" ",
						/* @__PURE__ */ v("b", { children: e.bank })
					] }),
					/* @__PURE__ */ y("span", { children: [
						a("games.acquire.ownedLabel"),
						" ",
						/* @__PURE__ */ v("b", { children: t })
					] }),
					/* @__PURE__ */ y("span", { children: [e.size ? a("games.acquire.size", { n: e.size }) : a("games.acquire.inactive"), e.safe && /* @__PURE__ */ v("span", {
						"aria-label": a("games.acquire.safe"),
						title: a("games.acquire.safe"),
						children: /* @__PURE__ */ v(we, {})
					})] })
				]
			}),
			i && /* @__PURE__ */ v(Ae, {
				company: e.company,
				order: i
			})
		]
	});
}
function Me({ quote: e, owned: t, selected: n, highlighted: r, onSelect: i, order: a }) {
	let s = h(), { ref: c } = o(`acquire-company:${e.company}`);
	return /* @__PURE__ */ y("div", {
		ref: c,
		className: "ex-stock-entry",
		style: Q(e.company),
		"data-selected": n,
		"data-highlighted": r,
		"data-inactive": !e.size,
		children: [/* @__PURE__ */ y("button", {
			type: "button",
			className: "ex-quote-row",
			onClick: i,
			"aria-pressed": n,
			"aria-label": s("games.acquire.chooseCompany", { company: s(T[e.company].key) }),
			children: [
				/* @__PURE__ */ y("span", {
					className: "ex-quote-company",
					children: [/* @__PURE__ */ v("i", { children: T[e.company].letter }), /* @__PURE__ */ y("span", { children: [/* @__PURE__ */ v("strong", { children: s(T[e.company].key) }), /* @__PURE__ */ v("small", { children: Oe[e.company] })] })]
				}),
				/* @__PURE__ */ v("b", {
					className: "ex-quote-price",
					children: e.size ? Z(e.price) : "—"
				}),
				/* @__PURE__ */ y("span", {
					className: "ex-quote-size",
					children: [e.size || "—", e.safe && /* @__PURE__ */ v("small", {
						title: s("games.acquire.safe"),
						"aria-label": s("games.acquire.safe"),
						children: /* @__PURE__ */ v(we, {})
					})]
				}),
				/* @__PURE__ */ v("span", { children: e.bank }),
				/* @__PURE__ */ v("span", {
					className: "ex-quote-owned",
					children: t
				})
			]
		}), /* @__PURE__ */ v(je, {
			quote: e,
			owned: t,
			selected: n,
			mobile: !0,
			order: a
		})]
	});
}
//#endregion
//#region src/games/acquire/view-player.tsx
var Ne = {
	place: "games.acquire.placePrompt",
	found: "games.acquire.foundPrompt",
	survivor: "games.acquire.survivorPrompt",
	order: "games.acquire.orderPrompt",
	bonus: "games.acquire.bonusPrompt",
	dispose: "games.acquire.disposePrompt",
	absorb: "games.acquire.absorbPrompt",
	buy: "games.acquire.buyPrompt",
	replace: "games.acquire.replacePrompt",
	finalBonus: "games.acquire.finalBonusPrompt",
	finalSale: "games.acquire.finalSalePrompt",
	done: "games.acquire.donePrompt"
};
function Pe(e) {
	g();
	let t = e.private;
	return t ? /* @__PURE__ */ v(Ie, {
		...e,
		pub: e.public,
		priv: t
	}, e.myRid) : null;
}
function Fe({ member: e, myRid: t, active: n, cash: r }) {
	let i = m((e) => e.locale), a = h(), { ref: s } = o(`acquire-seat:${e.rid}`);
	return /* @__PURE__ */ y("div", {
		ref: s,
		className: "ex-account",
		"data-active": n,
		children: [
			/* @__PURE__ */ v("span", {
				className: "ex-account-avatar",
				children: /* @__PURE__ */ v(_, {
					m: e,
					myRid: t,
					action: n ? "pending" : null,
					anchorName: null,
					box: "acquire-avatar-box",
					img: "acquire-avatar-img"
				})
			}),
			/* @__PURE__ */ y("div", {
				className: "ex-account-name",
				children: [/* @__PURE__ */ v("strong", { children: re(e, i) }), e.rid === t && /* @__PURE__ */ v("small", { children: a("lobby.you") })]
			}),
			/* @__PURE__ */ v("b", {
				className: "ex-account-cash",
				children: r === null ? "—" : Z(r)
			})
		]
	});
}
function Ie({ pub: e, priv: t, myRid: n, members: r, send: o }) {
	let c = h(), d = m((e) => e.locale), g = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? re(t, d) : e;
	}, _ = (e) => c(T[e].key), b = e.actor === n, x = [
		"found",
		"survivor",
		"order"
	].includes(e.phase), [S, C] = i(null), [w, D] = i(0), [O, k] = i(Array(7).fill(0)), [j, M] = i([...t.permanentTiles]), [N, P] = i(b && (x || e.phase === "dispose") ? "decision" : "none"), [F, I] = i(0), [L, R] = i(0), [z, B] = i(!1), [ae, oe] = i(!1), se = `${e.turnNumber}:${e.phase}:${e.actor}:${e.merger?.current}`, [ce, le] = i(se);
	se !== ce && (le(se), C(null), k(Array(7).fill(0)), M([...t.permanentTiles]), I(0), R(0), B(!1), N !== "assets" && P(b && (x || e.phase === "dispose") ? "decision" : "none"));
	let V = O.reduce((e, t) => e + t, 0), ue = O.reduce((t, n, r) => t + n * e.companies[r].price, 0), H = e.merger, U = H?.current ?? 0, W = H?.survivor ?? 0, G = H?.current === null || !H ? 0 : t.stocks[U], K = G - F - L * 2, q = c(Ne[e.phase], {
		company: _(e.finalCompany ?? H?.current ?? 0),
		survivor: _(W)
	}), de = e.actor && !b ? c("games.acquire.waiting", { name: g(e.actor) }) : q, J = S === null ? null : A(e.board, S), fe = "";
	if (J && S !== null) {
		let e = E(S);
		fe = J.kind === "independent" ? c("games.acquire.previewIndependent", { tile: e }) : J.kind === "found" ? c("games.acquire.previewFound", { tile: e }) : J.kind === "expand" ? c("games.acquire.previewExpand", {
			tile: e,
			company: _(J.companies[0])
		}) : J.kind === "merge" ? c("games.acquire.previewMerge", {
			tile: e,
			companies: J.companies.map(_).join(" / ")
		}) : c(J.kind === "permanent" ? "games.acquire.permanentTile" : "games.acquire.blockedTile", { tile: e });
	}
	let pe = (n) => e.phase === "buy" && b ? {
		quantity: O[n],
		canAdd: V < 3 && O[n] < e.companies[n].bank && e.companies[n].price <= t.cash - ue && e.companies[n].size > 0,
		add: () => {
			D(n), k((e) => e.map((e, t) => t === n ? e + 1 : e));
		},
		remove: () => {
			D(n), k((e) => e.map((e, t) => t === n ? e - 1 : e));
		}
	} : void 0, Y = /* @__PURE__ */ v(s, {
		size: 19,
		className: "acquire-forward"
	}), me = b ? e.phase === "place" ? t.legalTiles.length === 0 ? /* @__PURE__ */ y("button", {
		className: "ex-primary",
		onClick: () => o({ type: "pass" }),
		children: [c("games.acquire.pass"), Y]
	}) : /* @__PURE__ */ y("button", {
		className: "ex-primary",
		disabled: S === null || !t.legalTiles.includes(S),
		onClick: () => S !== null && o({
			type: "place",
			tile: S
		}),
		children: [S === null ? c("games.acquire.placePrompt") : c("games.acquire.playTile", { tile: E(S) }), Y]
	}) : e.phase === "buy" ? /* @__PURE__ */ y("button", {
		className: "ex-primary",
		onClick: () => o({
			type: "buy",
			stocks: O
		}),
		children: [c(V ? "games.acquire.buy" : "games.acquire.skipBuy"), Y]
	}) : e.phase === "replace" ? /* @__PURE__ */ y("button", {
		className: "ex-primary",
		onClick: () => o({
			type: "replace",
			tiles: j
		}),
		children: [j.length ? c("games.acquire.replaceSelected", { n: j.length }) : c("games.acquire.skipReplace"), Y]
	}) : /* @__PURE__ */ y("button", {
		className: "ex-primary",
		onClick: () => P("decision"),
		children: [e.phase === "dispose" ? c("games.acquire.changeDisposal") : q, Y]
	}) : /* @__PURE__ */ v("span", {
		className: "ex-wait",
		children: de
	});
	return /* @__PURE__ */ y("div", {
		className: `acquire-screen ${e.phase === "buy" ? "aq-buy" : ""}${b && e.canDeclare ? " aq-can-end" : ""}`,
		"data-locale": d,
		children: [
			/* @__PURE__ */ v(te, {
				adaptive: !0,
				scroll: !1,
				className: "acquire-shell",
				actionsHeight: "acquire-actions",
				banner: /* @__PURE__ */ y("div", {
					className: "ex-banner",
					children: [
						/* @__PURE__ */ y("header", {
							className: "ex-header",
							children: [
								/* @__PURE__ */ y("div", {
									className: "ex-brand",
									children: [/* @__PURE__ */ v(Ce, {}), /* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("b", { children: "ACQUIRE" }), /* @__PURE__ */ v("span", { children: c("games.acquire.name") })] })]
								}),
								/* @__PURE__ */ y("div", {
									className: "ex-phase",
									children: [/* @__PURE__ */ v("span", { children: c("games.acquire.turn", { n: e.turnNumber }) }), /* @__PURE__ */ v("strong", { children: de })]
								}),
								/* @__PURE__ */ v("div", { className: "acquire-menu-space" })
							]
						}),
						/* @__PURE__ */ v("div", {
							className: "ex-investors",
							children: e.players.map((i) => {
								let a = r.find((e) => e.rid === i.rid);
								return a && /* @__PURE__ */ v(Fe, {
									member: a,
									myRid: n,
									active: e.actor === i.rid,
									cash: i.rid === n ? t.cash : i.cash
								}, i.rid);
							})
						}),
						/* @__PURE__ */ y("div", {
							className: "ex-ticker",
							children: [
								/* @__PURE__ */ v(f, { size: 14 }),
								/* @__PURE__ */ v("span", { children: e.log.length ? De(e.log[e.log.length - 1], c, g) : "" }),
								/* @__PURE__ */ y("button", {
									onClick: () => oe(!0),
									children: [c("common.log.title"), Y]
								})
							]
						})
					]
				}),
				actions: /* @__PURE__ */ y("div", {
					className: "ex-commission",
					children: [
						/* @__PURE__ */ y("div", {
							className: "ex-cash",
							children: [/* @__PURE__ */ v("span", { children: c("games.acquire.availableCash") }), /* @__PURE__ */ v("b", { children: Z(t.cash) })]
						}),
						/* @__PURE__ */ y("div", {
							className: "ex-lots",
							children: [/* @__PURE__ */ v("div", {
								className: "ex-lot-rack",
								role: "group",
								"aria-label": c("games.acquire.hand"),
								children: t.hand.map((n) => {
									let r = t.permanentTiles.includes(n), i = !t.legalTiles.includes(n), a = e.phase === "replace" && b;
									return /* @__PURE__ */ y("button", {
										className: "ex-lot",
										type: "button",
										"data-selected": a ? j.includes(n) : S === n,
										"data-blocked": i && e.phase === "place",
										"data-permanent": r,
										disabled: !b || e.phase !== "place" && !a || a && !r,
										"aria-pressed": a ? j.includes(n) : S === n,
										"aria-label": c(r ? "games.acquire.permanentTile" : i ? "games.acquire.blockedTile" : "games.acquire.selectTile", { tile: E(n) }),
										onClick: () => a ? M((e) => e.includes(n) ? e.filter((e) => e !== n) : [...e, n]) : C(S === n ? null : n),
										children: [/* @__PURE__ */ v("span", { children: E(n) }), r ? /* @__PURE__ */ v(u, { size: 12 }) : i && e.phase === "place" ? /* @__PURE__ */ v(p, { size: 12 }) : null]
									}, n);
								})
							}), /* @__PURE__ */ v("p", { children: e.endDeclared ? c("games.acquire.endDeclared") : e.phase === "buy" && b ? c("games.acquire.cart", {
								n: V,
								cost: ue.toLocaleString("en-US")
							}) : fe || (b && e.phase === "place" && !t.legalTiles.length ? c("games.acquire.noLegalTile") : "") })]
						}),
						/* @__PURE__ */ v("div", {
							className: "ex-submit",
							children: me
						})
					]
				}),
				overlay: /* @__PURE__ */ y(ie, { children: [/* @__PURE__ */ v(a, {
					open: N === "decision" && b && (x || e.phase === "dispose"),
					onClose: () => P("none"),
					label: q,
					title: q,
					tall: !0,
					footer: e.phase === "dispose" ? /* @__PURE__ */ y("div", {
						className: "acquire-sheet-footer",
						children: [/* @__PURE__ */ y("div", {
							className: "ex-deal-total",
							children: [/* @__PURE__ */ v("span", { children: c("games.acquire.saleIncome") }), /* @__PURE__ */ v("b", { children: Z(F * (H?.price ?? 0)) })]
						}), /* @__PURE__ */ y("button", {
							className: "ex-primary",
							onClick: () => {
								o({
									type: "dispose",
									sell: F,
									trade: L
								}), P("none");
							},
							children: [c("games.acquire.confirmDispose"), /* @__PURE__ */ v(l, { size: 19 })]
						})]
					}) : void 0,
					children: x ? /* @__PURE__ */ v("div", {
						className: "acquire-company-choices",
						children: e.choices.map((n) => /* @__PURE__ */ y("button", {
							className: "acquire-choice",
							style: Q(n),
							onClick: () => {
								o({
									type: e.phase === "found" ? "found" : e.phase === "survivor" ? "survivor" : "acquire",
									company: n
								}), P("none");
							},
							"aria-label": c("games.acquire.chooseCompany", { company: _(n) }),
							children: [
								/* @__PURE__ */ v(X, { company: n }),
								/* @__PURE__ */ v("strong", { children: _(n) }),
								/* @__PURE__ */ v("span", { children: c("games.acquire.owned", { n: t.stocks[n] }) })
							]
						}, n))
					}) : e.phase === "dispose" && /* @__PURE__ */ y("div", {
						className: "acquire-disposal",
						children: [
							/* @__PURE__ */ v("div", {
								className: "ex-deal-brands",
								children: [U, W].map((e, t) => /* @__PURE__ */ y("div", {
									className: "ex-deal-company",
									style: Q(e),
									children: [
										/* @__PURE__ */ v(X, { company: e }),
										/* @__PURE__ */ v("strong", { children: _(e) }),
										/* @__PURE__ */ v("small", { children: c(t ? "games.acquire.survivingChain" : "games.acquire.acquiredChain") })
									]
								}, t))
							}),
							/* @__PURE__ */ y("div", {
								className: "ex-deal-security",
								children: [
									/* @__PURE__ */ v("strong", { children: _(U) }),
									/* @__PURE__ */ v("span", { children: c("games.acquire.owned", { n: G }) }),
									/* @__PURE__ */ v("span", { children: Z(H?.price ?? 0) })
								]
							}),
							/* @__PURE__ */ v(Le, {
								label: c("games.acquire.sell"),
								note: c("games.acquire.sellNote"),
								value: F,
								decreaseLabel: c("games.acquire.decreaseSell"),
								increaseLabel: c("games.acquire.increaseSell"),
								onDecrease: () => I(F - 1),
								onIncrease: () => I(F + 1),
								canDecrease: F > 0,
								canIncrease: K > 0
							}),
							/* @__PURE__ */ v(Le, {
								label: `${c("games.acquire.trade")} ${_(W)}`,
								note: c("games.acquire.exchangeNote"),
								value: L,
								decreaseLabel: c("games.acquire.decreaseTrade"),
								increaseLabel: c("games.acquire.increaseTrade"),
								onDecrease: () => R(L - 1),
								onIncrease: () => R(L + 1),
								canDecrease: L > 0,
								canIncrease: K >= 2 && L < e.companies[W].bank
							}),
							/* @__PURE__ */ y("div", {
								className: "ex-deal-row",
								children: [/* @__PURE__ */ y("span", { children: [c("games.acquire.keep"), /* @__PURE__ */ v("small", { children: c("games.acquire.keepNote") })] }), /* @__PURE__ */ v("b", { children: K })]
							}),
							/* @__PURE__ */ v("p", {
								className: "acquire-trade-note",
								children: c("games.acquire.tradeNote", {
									company: _(W),
									n: e.companies[W].bank
								})
							}),
							/* @__PURE__ */ y("div", {
								className: "ex-shareholders",
								children: [/* @__PURE__ */ v("h3", { children: c("games.acquire.shareholderList", { company: _(U) }) }), H?.holdings.map((e) => /* @__PURE__ */ y("div", {
									className: "aq-holding-row",
									"data-my": e.rid === n,
									children: [/* @__PURE__ */ v("span", { children: g(e.rid) }), /* @__PURE__ */ v("b", { children: c("games.acquire.shares", { n: e.n }) })]
								}, e.rid))]
							})
						]
					})
				}), /* @__PURE__ */ v(a, {
					open: N === "assets",
					onClose: () => P("none"),
					label: c("games.acquire.holdings"),
					title: c("games.acquire.holdings"),
					tall: !0,
					children: e.players.map((e) => {
						let r = e.rid === n ? t.stocks : e.stocks, i = e.rid === n ? t.cash : e.cash;
						return /* @__PURE__ */ y("div", {
							className: "acquire-assets-row",
							children: [/* @__PURE__ */ y("header", { children: [/* @__PURE__ */ v("strong", { children: g(e.rid) }), /* @__PURE__ */ v("b", { children: i === null ? "—" : Z(i) })] }), /* @__PURE__ */ v("div", { children: T.map((e, t) => /* @__PURE__ */ y("span", {
								style: Q(t),
								children: [
									_(t),
									" ",
									/* @__PURE__ */ v("b", { children: r?.[t] ?? "—" })
								]
							}, e.letter)) })]
						}, e.rid);
					})
				})] }),
				children: /* @__PURE__ */ y("div", {
					className: "ex-main",
					children: [/* @__PURE__ */ y("section", {
						className: "ex-map",
						children: [/* @__PURE__ */ y("header", {
							className: "ex-map-heading",
							children: [
								/* @__PURE__ */ v("h2", { children: c("games.acquire.board") }),
								/* @__PURE__ */ y("div", { children: [
									c("games.acquire.deck", { n: e.deckCount }),
									/* @__PURE__ */ v("i", {}),
									c("games.acquire.discarded", { n: e.discarded.length })
								] }),
								/* @__PURE__ */ y("button", {
									onClick: () => P("assets"),
									children: [c("games.acquire.holdings"), Y]
								})
							]
						}), /* @__PURE__ */ y("div", {
							className: "ex-map-field",
							children: [
								/* @__PURE__ */ v(ee, {
									kind: "sheen",
									base: "#152e37",
									className: "absolute inset-0 size-full"
								}),
								/* @__PURE__ */ v(Ee, {
									pub: e,
									selected: b && e.phase === "place" && S !== null && t.legalTiles.includes(S) ? S : null
								}),
								/* @__PURE__ */ v("div", { className: "ex-map-corner ex-map-corner-a" }),
								/* @__PURE__ */ v("div", { className: "ex-map-corner ex-map-corner-b" })
							]
						})]
					}), /* @__PURE__ */ y("aside", {
						className: "ex-market",
						"aria-label": c("games.acquire.bank"),
						children: [/* @__PURE__ */ y("header", {
							className: "ex-market-title",
							children: [/* @__PURE__ */ v("h2", { children: c("games.acquire.market") }), /* @__PURE__ */ v("span", { children: e.phase === "buy" && b ? c("games.acquire.buyLimit") : "" })]
						}), /* @__PURE__ */ y("div", {
							className: "ex-market-scroll",
							children: [
								/* @__PURE__ */ v("div", {
									className: "ex-quotes-head",
									children: [
										"companyLabel",
										"priceLabel",
										"sizeLabel",
										"supplyLabel",
										"ownedLabel"
									].map((e) => /* @__PURE__ */ v("span", { children: c(`games.acquire.${e}`) }, e))
								}),
								/* @__PURE__ */ v("div", {
									className: "ex-bank",
									children: e.companies.map((e) => /* @__PURE__ */ v(Me, {
										quote: e,
										owned: t.stocks[e.company],
										selected: w === e.company,
										highlighted: !!H && (H.remaining.includes(e.company) || H.survivor === e.company),
										onSelect: () => D(e.company),
										order: pe(e.company)
									}, e.company))
								}),
								/* @__PURE__ */ v("div", {
									className: "ex-selected-security",
									children: /* @__PURE__ */ v(je, {
										quote: e.companies[w],
										owned: t.stocks[w],
										selected: !0,
										order: pe(w)
									})
								})
							]
						})]
					})]
				})
			}),
			b && e.canDeclare && /* @__PURE__ */ v("button", {
				className: `acquire-end ${z ? "ex-armed" : ""}`,
				onBlur: () => B(!1),
				onClick: () => {
					z ? (o({ type: "declareEnd" }), B(!1)) : B(!0);
				},
				children: c(z ? "games.acquire.confirmEnd" : "games.acquire.declareEnd")
			}),
			ae && /* @__PURE__ */ v(ne, {
				log: e.log,
				line: (e) => De(e, c, g),
				onClose: () => oe(!1)
			})
		]
	});
}
function Le({ label: e, note: t, value: n, canDecrease: r, canIncrease: i, decreaseLabel: a, increaseLabel: o, onDecrease: s, onIncrease: c }) {
	return /* @__PURE__ */ y("div", {
		className: "ex-deal-row",
		children: [/* @__PURE__ */ y("span", { children: [e, /* @__PURE__ */ v("small", { children: t })] }), /* @__PURE__ */ y("div", {
			className: "ex-quantity",
			children: [
				/* @__PURE__ */ v("button", {
					"aria-label": a,
					disabled: !r,
					onClick: s,
					children: "−"
				}),
				/* @__PURE__ */ v("b", { children: n }),
				/* @__PURE__ */ v("button", {
					"aria-label": o,
					disabled: !i,
					onClick: c,
					children: "+"
				})
			]
		})]
	});
}
//#endregion
//#region src/games/acquire/bot-strategy.ts
var Re = {
	growth: .75,
	bonus: .6,
	uncertainty: .8,
	entry: .7,
	liquidity: .35,
	reserve: 1800,
	dormant: .3,
	opponent: .7,
	control: .2
};
function $(e) {
	return {
		...e,
		board: e.board,
		sizes: [...e.sizes],
		bank: [...e.bank],
		cash: [...e.cash],
		stocks: e.stocks.map((e) => [...e]),
		hand: [...e.hand]
	};
}
function ze(e, t) {
	let n = e.filter((e, n) => n !== t);
	return Math.max(...n) * .75 + n.reduce((e, t) => e + t, 0) / n.length * .25;
}
function Be(e, t, n, r) {
	return n ? e[t] - Math.max(...e.filter((e, n) => n !== t)) : e[t] - ze(e, t) * r;
}
function Ve(e) {
	let t = [...e.cash];
	for (let n of w) if (e.sizes[n] > 0) {
		let r = k(n, e.sizes[n]);
		e.stocks.forEach((e, i) => {
			t[i] += e[n] * r;
		});
		for (let i of M(e.stocks.map((e, t) => ({
			rid: String(t),
			n: e[n]
		})), r)) t[Number(i.rid)] += i.amount;
	}
	return t;
}
var He = class {
	params;
	outlooks = /* @__PURE__ */ new WeakMap();
	awards = /* @__PURE__ */ new Map();
	constructor(e) {
		this.params = e;
	}
	outlook(e) {
		let t = this.outlooks.get(e.board);
		if (t) return t;
		let n = Array(7).fill(0), r = Array(7).fill(0), i = /* @__PURE__ */ new Map();
		for (let t = 0; t < 108; t++) if (e.board[t] === -1 && !i.has(t)) {
			let n = [t], r = new Set(n), a = /* @__PURE__ */ new Set();
			for (let t = 0; t < n.length; t++) for (let i of D(n[t])) e.board[i] >= 0 ? a.add(e.board[i]) : e.board[i] === -1 && !r.has(i) && (n.push(i), r.add(i));
			let o = [...a];
			n.forEach((e) => i.set(e, o));
		}
		for (let t = 0; t < 108; t++) if (e.board[t] === -2) {
			let a = /* @__PURE__ */ new Set();
			for (let n of D(t)) if (e.board[n] >= 0) a.add(e.board[n]);
			else for (let e of i.get(n) ?? []) a.add(e);
			if (a.size === 1 && n[[...a][0]]++, a.size > 1 && [...a].filter((t) => e.sizes[t] >= 11).length < 2) {
				let t = Math.max(...[...a].map((t) => e.sizes[t]));
				for (let n of a) e.sizes[n] <= t && e.sizes[n] < 11 && (r[n] += e.sizes[n] < t ? 1 : .5);
			}
		}
		let a = Math.min(.8, e.tilesLeft / Math.max(1, e.board.filter((e) => e === -2).length)), o = w.map((t) => {
			let i = k(t, e.sizes[t]), o = n[t] * a * (r[t] > 0 ? .2 : .65);
			return i + (k(t, e.sizes[t] + o) - i) * this.params.growth;
		}), s = w.map((t) => this.params.uncertainty * Math.min(1, e.tilesLeft / 25) / (1 + r[t] * .7)), c = this.params.reserve * Math.min(1, e.tilesLeft / 24), l = {
			prices: o,
			noise: s,
			restart: Math.min(1, e.tilesLeft / 65),
			reserve: c
		};
		return this.outlooks.set(e.board, l), l;
	}
	bonusValues(e, t, n, r) {
		let i = e.stocks.map((e) => e[t]), a = e.cash.map((e, t) => i[t] > 0 ? 1 : Math.min(1, e / Math.max(1, n * 2)) * this.params.entry), o = `${t}:${n}:${r}:${i.join(",")}:${a.map((e) => e.toFixed(2)).join(",")}`, s = this.awards.get(o);
		if (s) return s;
		let c = i.map(() => 0);
		if (r < .05) for (let e of M(i.map((e, t) => ({
			rid: String(t),
			n: e
		})), n)) c[Number(e.rid)] = e.amount;
		else {
			let e = Math.max(...i), t = i.map((t, n) => Math.exp((t - e) / Math.max(.25, r)) * a[n]), o = t.reduce((e, t) => e + t, 0);
			if (o > 0) {
				for (let e = 0; e < i.length; e++) if (i[e] > 0) {
					let r = t[e] / o, a = 0;
					for (let n = 0; n < i.length; n++) n !== e && o - t[n] > 1e-12 && (a += t[n] / o * t[e] / (o - t[n]));
					t.filter((e) => e > 1e-12).length === 1 && (a = 1), c[e] = n * (10 * r + 5 * a);
				}
			}
		}
		return this.awards.set(o, c), c;
	}
	companyValues(e, t) {
		if (e.end) {
			let n = k(t, e.sizes[t]), r = this.bonusValues(e, t, n, 0);
			return e.stocks.map((e, i) => e[t] * n + r[i]);
		}
		let n = this.outlook(e);
		if (e.sizes[t] === 0) {
			let r = k(t, 3), i = this.bonusValues(e, t, r, this.params.uncertainty * 3), a = this.params.dormant * n.restart;
			return e.stocks.map((e, n) => a * (e[t] * r + i[n] * this.params.bonus));
		}
		let r = n.prices[t], i = this.bonusValues(e, t, r, n.noise[t] * Math.min(4, e.bank[t] / 5));
		return e.stocks.map((e, n) => e[t] * r + i[n] * this.params.bonus);
	}
	cashValue(e, t) {
		if (e.end) return t;
		let n = this.outlook(e).reserve;
		return t + (n > 0 ? this.params.liquidity * n * (1 - Math.exp(-t / n)) : 0);
	}
	values(e) {
		if (e.end) return Ve(e);
		let t = e.cash.map((t) => this.cashValue(e, t));
		for (let n of w) this.companyValues(e, n).forEach((e, n) => {
			t[n] += e;
		});
		return t;
	}
	score(e, t) {
		return Be(this.values(e), t, e.end, this.params.opponent);
	}
	buy(e, t) {
		let n = this.values(e), r = this.cashValue(e, e.cash[t]), i = w.map((n) => {
			let r = this.companyValues(e, n), i = [r.map(() => 0)];
			for (let a = 1; a <= Math.min(3, e.bank[n]) && e.sizes[n]; a++) {
				let o = $(e);
				o.stocks[t][n] += a, o.bank[n] -= a;
				let s = k(n, e.sizes[n]);
				o.cash[t] -= a * s, i.push(this.companyValues(o, n).map((e, t) => e - r[t]));
			}
			return i;
		}), a = Array(7).fill(0), o = [...a], s = -Infinity, c = [...n], l = (n, u, d) => {
			if (n === 7) {
				let n = [...c];
				n[t] += this.cashValue(e, e.cash[t] - d) - r;
				let i = Be(n, t, e.end, this.params.opponent);
				i > s + 1e-7 && (s = i, o = [...a]);
				return;
			}
			let f = k(n, e.sizes[n]), p = e.sizes[n] > 0 ? Math.min(u, e.bank[n], Math.floor((e.cash[t] - d) / f)) : 0;
			for (let e = 0; e <= p; e++) {
				a[n] = e;
				for (let t = 0; t < c.length; t++) c[t] += i[n][e][t];
				l(n + 1, u - e, d + e * f);
				for (let t = 0; t < c.length; t++) c[t] -= i[n][e][t];
			}
			a[n] = 0;
		};
		l(0, 3, 0);
		let u = $(e);
		return o.forEach((n, r) => {
			u.stocks[t][r] += n, u.bank[r] -= n, u.cash[t] -= n * k(r, e.sizes[r]);
		}), {
			action: {
				type: "buy",
				stocks: o
			},
			position: u,
			score: this.score(u, t)
		};
	}
	disposeOptions(e, t, n) {
		let r = t.current, i = e.stocks[n][r], a = k(r, t.sizes[r]), o = $(e), s = new Set(t.remaining);
		o.board = e.board.map((e, n) => s.has(e) || t.group.includes(n) ? t.survivor : e), o.sizes[t.survivor] += t.remaining.reduce((t, n) => t + e.sizes[n], t.group.length);
		for (let e of t.remaining) o.sizes[e] = 0;
		let c = this.values(o), l = this.cashValue(o, e.cash[n]), u = this.companyValues(o, r), d = this.companyValues(o, t.survivor), f = Array.from({ length: i + 1 }, (e, t) => {
			let a = $(o);
			return a.stocks[n][r] = t, a.bank[r] += i - t, this.companyValues(a, r);
		}), p = Math.min(Math.floor(i / 2), e.bank[t.survivor]), m = Array.from({ length: p + 1 }, (e, r) => {
			let i = $(o);
			return i.stocks[n][t.survivor] += r, i.bank[t.survivor] -= r, this.companyValues(i, t.survivor);
		}), h = [];
		for (let t = 0; t <= p; t++) for (let r = 0; r + t * 2 <= i; r++) {
			let s = i - r - t * 2, p = c.map((e, n) => e + f[s][n] - u[n] + m[t][n] - d[n]);
			p[n] += this.cashValue(o, e.cash[n] + r * a) - l, h.push({
				sell: r,
				trade: t,
				score: Be(p, n, e.end, this.params.opponent)
			});
		}
		return h.sort((e, t) => t.score - e.score || t.sell - e.sell || t.trade - e.trade);
	}
	dispose(e, t, n, r, i) {
		let a = $(e), o = t.current;
		return a.stocks[n][o] -= r + i * 2, a.stocks[n][t.survivor] += i, a.bank[o] += r + i * 2, a.bank[t.survivor] -= i, a.cash[n] += r * k(o, t.sizes[o]), a;
	}
	finishMerger(e, t, n, r = 0) {
		if (t.current === null) {
			if (!t.remaining.length) {
				let n = $(e);
				n.board = [...e.board];
				for (let e of t.group) n.board[e] = t.survivor;
				return n.sizes[t.survivor] += t.group.length, n;
			}
			let i = Math.max(...t.remaining.map((e) => t.sizes[e])), a = t.remaining.filter((e) => t.sizes[e] === i), o = (n) => e.stocks[e.turn][n] * k(n, t.sizes[n]);
			return a.sort((e, t) => o(t) - o(e) || e - t), a.slice(0, t.remaining.length + r > 3 ? 1 : 3).map((i) => this.finishMerger(e, {
				...t,
				current: i,
				next: 0,
				paid: !1
			}, n, r + 1)).sort((t, n) => this.score(n, e.turn) - this.score(t, e.turn))[0];
		}
		let i = $(e), a = t.current;
		if (!t.paid) for (let n of M(e.stocks.map((e, t) => ({
			rid: String(t),
			n: e[a]
		})), k(a, t.sizes[a]))) i.cash[Number(n.rid)] += n.amount;
		for (let n = t.next; n < e.cash.length; n++) {
			let r = (e.turn + n) % e.cash.length;
			if (!i.stocks[r][a]) continue;
			let o = this.disposeOptions(i, t, r)[0];
			i = this.dispose(i, t, r, o.sell, o.trade);
		}
		return i.board = i.board.map((e) => e === a ? t.survivor : e), i.sizes[t.survivor] += i.sizes[a], i.sizes[a] = 0, this.finishMerger(i, {
			...t,
			remaining: t.remaining.filter((e) => e !== a),
			current: null
		}, n, r);
	}
	complete(e, t) {
		return this.buy(e, t);
	}
	handValue(e, t) {
		if (e.end || e.handOwner !== t || !this.params.control) return 0;
		let n = 0;
		for (let r of e.hand) {
			let i = A(e.board, r);
			if (i.kind === "found" && (n = Math.max(n, 180)), i.kind === "expand") {
				let r = i.companies[0];
				n = Math.max(n, e.stocks[t][r] * (k(r, e.sizes[r] + i.group.length) - k(r, e.sizes[r])));
			}
			if (i.kind === "merge") {
				let r = Math.max(...i.companies.map((t) => e.sizes[t])), a = i.companies.filter((t) => e.sizes[t] < r).reduce((n, r) => n + (M(e.stocks.map((e, t) => ({
					rid: String(t),
					n: e[r]
				})), k(r, e.sizes[r])).find((e) => Number(e.rid) === t)?.amount ?? 0), 0);
				n = Math.max(n, a * .15);
			}
		}
		return n * this.params.control;
	}
	placePlans(e, t, n = e.hand) {
		let r = [];
		for (let i of n) {
			let n = A(e.board, i);
			if (n.kind === "blocked" || n.kind === "permanent") continue;
			let a = $(e);
			a.board = [...e.board], a.board[i] = -1, e.handOwner === t && (a.hand = a.hand.filter((e) => e !== i));
			let o = [];
			if (n.kind === "found") for (let r of w.filter((t) => e.sizes[t] === 0)) {
				let e = $(a);
				e.board = [...a.board], n.group.forEach((t) => {
					e.board[t] = r;
				}), e.sizes[r] = n.group.length, e.bank[r] && (e.bank[r]--, e.stocks[t][r]++), o.push(e);
			}
			else if (n.kind === "merge") {
				let r = Math.max(...n.companies.map((t) => e.sizes[t]));
				for (let i of n.companies.filter((t) => e.sizes[t] === r)) o.push(this.finishMerger(a, {
					survivor: i,
					remaining: n.companies.filter((e) => e !== i),
					sizes: [...e.sizes],
					group: n.group,
					current: null,
					next: 0,
					paid: !1
				}, t));
			} else {
				if (n.kind === "expand") {
					let e = n.companies[0];
					n.group.forEach((t) => {
						a.board[t] = e;
					}), a.sizes[e] += n.group.length;
				}
				o.push(a);
			}
			let s = o.map((e) => this.complete(e, t)).sort((e, n) => n.score + this.handValue(n.position, t) - e.score - this.handValue(e.position, t))[0];
			r.push({
				...s,
				action: {
					type: "place",
					tile: i
				},
				score: s.score + this.handValue(s.position, t)
			});
		}
		return r.length || r.push({
			...this.complete(e, t),
			action: { type: "pass" }
		}), r.sort((e, t) => t.score - e.score);
	}
	plan(e, t, n) {
		if (t.phase === "place") return this.placePlans(e, n)[0];
		if (t.phase === "buy") return this.buy(e, n);
		if (t.phase === "found") {
			let r = [...t.log].reverse().find((e) => e.type === "place"), i = A(e.board, r.tile).group;
			return t.choices.map((t) => {
				let r = $(e);
				return r.board = [...e.board], i.forEach((e) => {
					r.board[e] = t;
				}), r.sizes[t] = i.length, r.bank[t] && (r.bank[t]--, r.stocks[n][t]++), {
					...this.complete(r, n),
					action: {
						type: "found",
						company: t
					}
				};
			}).sort((e, t) => t.score - e.score)[0];
		}
		if (t.merger) {
			let r = t.merger, i = {
				survivor: r.survivor ?? -1,
				remaining: [...r.remaining],
				sizes: [...r.sizes],
				group: A(e.board, r.tile).group,
				current: r.current,
				next: (n - e.turn + e.cash.length) % e.cash.length,
				paid: !0
			};
			if (t.phase === "survivor" || t.phase === "order") return t.choices.map((r) => {
				let a = t.phase === "survivor" ? {
					...i,
					survivor: r,
					remaining: i.remaining.filter((e) => e !== r),
					current: null,
					paid: !1,
					next: 0
				} : {
					...i,
					current: r,
					paid: !1,
					next: 0
				};
				return {
					...this.complete(this.finishMerger(e, a, n), n),
					action: {
						type: t.phase === "survivor" ? "survivor" : "acquire",
						company: r
					}
				};
			}).sort((e, t) => t.score - e.score)[0];
			if (t.phase === "dispose") return this.disposeOptions(e, i, n).slice(0, 3).map((t) => {
				let r = this.dispose(e, i, n, t.sell, t.trade), a = this.finishMerger(r, {
					...i,
					next: i.next + 1
				}, n), o = n === e.turn ? this.complete(a, n) : { position: this.complete(a, e.turn).position };
				return {
					position: o.position,
					score: this.score(o.position, n),
					action: {
						type: "dispose",
						sell: t.sell,
						trade: t.trade
					}
				};
			}).sort((e, t) => t.score - e.score)[0];
		}
		return {
			action: {
				type: "replace",
				tiles: []
			},
			position: e,
			score: this.score(e, n)
		};
	}
};
function Ue(e, t, n, r, i = Re) {
	let a = e.players.map((e) => e.rid), o = a.indexOf(n), s = {
		board: [...e.board],
		sizes: e.companies.map((e) => e.size),
		bank: e.companies.map((e) => e.bank),
		cash: a.map((e) => e === n ? t.cash : r.cash[e]),
		stocks: a.map((e) => [...e === n ? t.stocks : r.stocks[e]]),
		hand: [...t.hand],
		handOwner: o,
		turn: a.indexOf(e.turn),
		tilesLeft: e.deckCount + e.players.reduce((e, t) => e + t.handCount, 0),
		end: e.endDeclared
	}, c = new He(i);
	if (e.phase === "replace") {
		if (e.canDeclare) {
			let e = Ve(s);
			if (e[o] >= Math.max(...e)) return { type: "declareEnd" };
		}
		return {
			type: "replace",
			tiles: t.permanentTiles
		};
	}
	if (e.canDeclare) {
		let t = Ve(c.plan({
			...s,
			end: !0
		}, e, o).position), n = Math.max(...t.filter((e, t) => t !== o));
		if (t[o] > n || t[o] === n && e.deckCount === 0) return { type: "declareEnd" };
	}
	return e.phase === "place" ? c.placePlans(s, o)[0].action : c.plan(s, e, o).action;
}
//#endregion
//#region src/games/acquire/bot.ts
function We(e) {
	let t = Object.fromEntries(e.players.map((e) => [e.rid, Array(7).fill(0)])), n = Object.fromEntries(e.players.map((e) => [e.rid, 6e3]));
	for (let r of e.log) {
		if (r.type === "found" && r.bonus && t[r.rid][r.company]++, r.type === "buy" && (r.stocks.forEach((e, n) => {
			t[r.rid][n] += e;
		}), n[r.rid] -= r.cost), r.type === "dispose" && (t[r.rid][r.company] -= r.sell + r.trade * 2, t[r.rid][r.survivor] += r.trade, n[r.rid] += r.cash), r.type === "bonus") for (let e of r.awards) n[e.rid] += e.amount;
		if (r.type === "sale") for (let e of r.returns) n[e.rid] += e.amount, t[e.rid][r.company] = 0;
	}
	return {
		stocks: t,
		cash: n
	};
}
function Ge(e) {
	let t = e.length, n = Math.floor(4294967296 / t) * t, r;
	do
		r = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (r >= n);
	return e[r % t];
}
function Ke(e = {}) {
	let t = {
		...Re,
		...e
	};
	return ({ public: e, private: n }, r) => {
		if (!n || e.actor !== r.rid) return null;
		if (r.difficulty !== "weak") return { action: Ue(e, n, r.rid, We(e), t) };
		if (e.canDeclare) return { action: { type: "declareEnd" } };
		if (e.phase === "place") return { action: n.legalTiles.length ? {
			type: "place",
			tile: Ge(n.legalTiles)
		} : { type: "pass" } };
		if (e.phase === "found") return { action: {
			type: "found",
			company: Ge(e.choices)
		} };
		if (e.phase === "survivor" || e.phase === "order") return { action: {
			type: e.phase === "survivor" ? "survivor" : "acquire",
			company: Ge(e.choices)
		} };
		if (e.phase === "dispose") return { action: {
			type: "dispose",
			sell: n.stocks[e.merger.current],
			trade: 0
		} };
		if (e.phase === "buy") {
			let t = Array(7).fill(0), r = n.cash;
			for (let n = 0; n < 3; n++) {
				let n = e.companies.filter((e) => e.size > 0 && e.bank > t[e.company] && e.price <= r);
				if (!n.length) break;
				let i = Ge(n);
				t[i.company]++, r -= i.price;
			}
			return { action: {
				type: "buy",
				stocks: t
			} };
		}
		return e.phase === "replace" ? { action: {
			type: "replace",
			tiles: n.permanentTiles
		} } : null;
	};
}
var qe = Ke(), Je = (e, { public: t }, n) => e.type === "place" ? n("games.acquire.playTile", { tile: E(e.tile) }) : e.type === "declareEnd" ? n("games.acquire.declareEnd") : e.type === "pass" ? n("games.acquire.pass") : e.type === "replace" ? n("games.acquire.replaceSelected", { n: e.tiles.length }) : e.type === "dispose" ? n("games.acquire.disposeSummary", {
	cash: e.sell * (t.merger?.price ?? 0),
	keep: (t.merger?.holdings.find((e) => e.rid === t.actor)?.n ?? 0) - e.sell - e.trade * 2
}) : e.type === "buy" ? e.stocks.some(Boolean) ? e.stocks.flatMap((e, t) => e ? [n("games.acquire.stockAmount", {
	company: n(T[t].key),
	n: e
})] : []).join(", ") : n("games.acquire.skipBuy") : e.type === "found" || e.type === "survivor" || e.type === "acquire" ? n("games.acquire.chooseCompany", { company: n(T[e.company].key) }) : "";
//#endregion
//#region src/games/acquire/fx.tsx
function Ye({ at: e, ms: t, kind: i, amount: a, company: o = 0, survivor: s = 0 }) {
	let c = r(null), l = h();
	return n(() => {
		let e = c.current;
		if (!e) return;
		let n = e.animate(i === "bonus" ? [
			{
				opacity: 0,
				transform: "translate(-50%, 4px)"
			},
			{
				opacity: 1,
				transform: "translate(-50%, -2px)",
				offset: .18
			},
			{
				opacity: 1,
				transform: "translate(-50%, -10px)",
				offset: .72
			},
			{
				opacity: 0,
				transform: "translate(-50%, -16px)"
			}
		] : [
			{ opacity: 0 },
			{
				opacity: 1,
				offset: .15
			},
			{
				opacity: 1,
				offset: .75
			},
			{ opacity: 0 }
		], {
			duration: t,
			fill: "both",
			easing: "ease-out"
		});
		return () => n.cancel();
	}, [t, i]), i === "place" ? /* @__PURE__ */ v("div", {
		ref: c,
		className: "acquire-landing",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		}
	}) : i === "bonus" ? /* @__PURE__ */ v("div", {
		ref: c,
		className: "ex-receipt acquire-fx",
		style: {
			left: e.x + e.w / 2,
			top: Math.max(40, e.y + e.h - 8)
		},
		children: /* @__PURE__ */ y("b", { children: ["+", Z(a ?? 0)] })
	}) : /* @__PURE__ */ y("div", {
		ref: c,
		className: "acquire-fx-notice acquire-fx",
		style: {
			left: e.x + e.w / 2,
			top: Math.max(8, e.y + 10)
		},
		children: [
			/* @__PURE__ */ v("span", {
				style: Q(o),
				children: /* @__PURE__ */ v(X, { company: o })
			}),
			i === "absorb" && /* @__PURE__ */ y(ie, { children: [/* @__PURE__ */ v("span", { children: "→" }), /* @__PURE__ */ v("span", {
				style: Q(s),
				children: /* @__PURE__ */ v(X, { company: s })
			})] }),
			/* @__PURE__ */ v("strong", { children: i === "absorb" ? l("games.acquire.absorbPrompt", {
				company: l(T[o].key),
				survivor: l(T[s].key)
			}) : l(T[o].key) })
		]
	});
}
var Xe = {
	place(e, t) {
		let { tile: n } = e.data, r = t.anchor(`acquire-tile:${n}`);
		return r ? {
			ms: 420,
			node: /* @__PURE__ */ v(Ye, {
				at: r,
				ms: 420,
				kind: "place"
			})
		} : null;
	},
	found(e, t) {
		let { company: n } = e.data, r = t.anchor("acquire-map"), i = t.queued ? 180 : 600;
		return r ? {
			ms: i,
			node: /* @__PURE__ */ v(Ye, {
				at: r,
				ms: i,
				kind: "found",
				company: n
			})
		} : null;
	},
	bonus(e, t) {
		let { amount: n } = e.data, r = e.rid ? t.anchor(`acquire-seat:${e.rid}`) : null, i = t.queued ? 180 : 850;
		return r && r.w > 0 && r.h > 0 ? {
			ms: i,
			node: /* @__PURE__ */ v(Ye, {
				at: r,
				ms: i,
				kind: "bonus",
				amount: n
			})
		} : null;
	},
	absorb(e, t) {
		let { company: n, survivor: r } = e.data, i = t.anchor("acquire-map"), a = t.queued ? 180 : 850;
		return i ? {
			ms: a,
			node: /* @__PURE__ */ v(Ye, {
				at: i,
				ms: a,
				kind: "absorb",
				company: n,
				survivor: r
			})
		} : null;
	}
};
//#endregion
//#region src/games/acquire/game-over.tsx
function Ze({ public: e, result: t, members: n, myRid: a, hintCount: o, onPlayAgain: s, onBackToLobby: l }) {
	let u = e, p = h(), ee = m((e) => e.locale), [g, te] = i(!0), [ie, b] = i(!1), [x, S] = i(null), C = r(null), w = r(null), T = r(null), E = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? re(t, ee) : e;
	}, D = (e) => u.final.find((t) => t.rid === e), O = (e) => {
		S(null), te(e), requestAnimationFrame(() => (e ? C : w).current?.focus({ preventScroll: !0 }));
	}, k = (e) => {
		if (e.key === "Escape" && (e.stopPropagation(), O(!1)), e.key !== "Tab") return;
		let t = [...T.current?.querySelectorAll("button:not(:disabled)") ?? []].filter((e) => e.getClientRects().length), n = t[0], r = t[t.length - 1];
		e.shiftKey && document.activeElement === n && (e.preventDefault(), r?.focus()), !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
	}, A = (e, t) => {
		x === e ? (S(null), t()) : S(e);
	}, j = (e, n) => /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", {
		scope: "row",
		children: e
	}), t.ranking.map((e) => /* @__PURE__ */ v("td", {
		"data-winner": t.winner.includes(e),
		children: D(e) ? Z(D(e)[n]) : "—"
	}, e))] });
	return /* @__PURE__ */ y("div", {
		className: `acquire-screen acquire-endgame${g ? "" : " ex-review"}`,
		"data-locale": ee,
		children: [
			/* @__PURE__ */ v("div", {
				className: "acquire-final-board",
				inert: g,
				children: /* @__PURE__ */ y("section", {
					className: "ex-map",
					children: [/* @__PURE__ */ v("header", {
						className: "ex-map-heading",
						children: /* @__PURE__ */ v("h2", { children: p("games.acquire.board") })
					}), /* @__PURE__ */ v("div", {
						className: "ex-map-field",
						children: /* @__PURE__ */ v(Ee, {
							pub: u,
							selected: null
						})
					})]
				})
			}),
			/* @__PURE__ */ v("div", {
				className: "ex-end-veil",
				hidden: !g,
				children: /* @__PURE__ */ y("section", {
					ref: T,
					className: "ex-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": p("games.acquire.liquidation"),
					onKeyDown: k,
					children: [
						/* @__PURE__ */ y("header", {
							className: "ex-result-heading",
							children: [/* @__PURE__ */ y("div", { children: [
								/* @__PURE__ */ v(Ce, {}),
								/* @__PURE__ */ v("b", { children: "ACQUIRE" }),
								/* @__PURE__ */ v("h1", { children: p("games.acquire.liquidation") })
							] }), /* @__PURE__ */ v("button", {
								ref: C,
								className: "aq-sheet-close",
								"aria-label": p("games.acquire.reviewHide"),
								title: p("games.acquire.reviewHide"),
								onClick: () => O(!1),
								children: /* @__PURE__ */ v(d, { size: 20 })
							})]
						}),
						/* @__PURE__ */ y("div", {
							className: "ex-result-body",
							children: [/* @__PURE__ */ y("aside", {
								className: "ex-award",
								children: [
									/* @__PURE__ */ v(Se, {}),
									/* @__PURE__ */ v(Ce, { className: "ex-award-seal" }),
									/* @__PURE__ */ y("div", {
										className: "ex-award-owner",
										children: [
											/* @__PURE__ */ v("span", { children: p(t.winner.length > 1 ? "games.acquire.sharedWinner" : "games.acquire.winner") }),
											/* @__PURE__ */ v("strong", { children: t.winner.map(E).join(" / ") }),
											/* @__PURE__ */ v("b", { children: t.winner.length && t.scores?.[t.winner[0]] !== void 0 ? Z(t.scores[t.winner[0]]) : "—" })
										]
									}),
									/* @__PURE__ */ v("div", { className: "ex-award-line" })
								]
							}), /* @__PURE__ */ y("div", {
								className: "ex-ledger",
								children: [/* @__PURE__ */ v("div", {
									className: "ex-score-scroll",
									children: /* @__PURE__ */ y("table", {
										className: "ex-score-table",
										"data-six": t.ranking.length > 4,
										"aria-label": p("games.acquire.liquidation"),
										children: [
											/* @__PURE__ */ v("thead", { children: /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", {
												scope: "col",
												children: p("games.acquire.assetItem")
											}), t.ranking.map((e, r) => {
												let i = n.find((t) => t.rid === e), o = t.scores?.[e], s = t.winner.includes(e) ? 1 : o === void 0 ? r + 1 : t.ranking.findIndex((e) => t.scores?.[e] === o) + 1;
												return /* @__PURE__ */ v("th", {
													scope: "col",
													"data-winner": t.winner.includes(e),
													children: /* @__PURE__ */ y("div", {
														className: "ex-final-person",
														children: [
															i && /* @__PURE__ */ v("span", {
																className: "ex-final-avatar",
																children: /* @__PURE__ */ v(_, {
																	m: i,
																	myRid: a,
																	action: null,
																	anchorName: null,
																	box: "acquire-avatar-box",
																	img: "acquire-avatar-img"
																})
															}),
															/* @__PURE__ */ v("strong", {
																title: E(e),
																children: E(e)
															}),
															/* @__PURE__ */ y("small", { children: [p("games.acquire.place", { n: s }), e === a ? ` · ${p("lobby.you")}` : ""] }),
															!!t.autopilot?.[e] && /* @__PURE__ */ y("small", { children: [/* @__PURE__ */ v(c, { size: 10 }), p("session.autopilot.share", { n: Math.round(t.autopilot[e] * 100) })] })
														]
													})
												}, e);
											})] }) }),
											/* @__PURE__ */ y("tbody", { children: [
												j(p("games.acquire.cashItem"), "cash"),
												j(p("games.acquire.bonusItem"), "bonuses"),
												j(p("games.acquire.salesItem"), "sales")
											] }),
											/* @__PURE__ */ v("tfoot", { children: j(p("games.acquire.totalAssets"), "total") })
										]
									})
								}), /* @__PURE__ */ y("div", {
									className: "ex-result-notes",
									children: [/* @__PURE__ */ v("span", { children: o === void 0 ? "" : p("session.hint.usedCount", { n: o }) }), /* @__PURE__ */ y("button", {
										onClick: () => b(!0),
										children: [/* @__PURE__ */ v(f, { size: 16 }), p("common.log.title")]
									})]
								})]
							})]
						}),
						/* @__PURE__ */ y("footer", {
							className: "ex-result-footer",
							children: [
								l && /* @__PURE__ */ v("button", {
									className: `ex-quiet ${x === "lobby" ? "ex-armed" : ""}`,
									onBlur: () => S(null),
									onClick: () => A("lobby", l),
									children: p(x === "lobby" ? "games.acquire.confirmLobby" : "session.result.backToLobby")
								}),
								s && /* @__PURE__ */ v("button", {
									className: `ex-primary ${x === "again" ? "ex-armed" : ""}`,
									onBlur: () => S(null),
									onClick: () => A("again", s),
									children: p(x === "again" ? "games.acquire.confirmAgain" : "session.result.playAgain")
								}),
								!s && !l && /* @__PURE__ */ v("p", { children: p("session.result.waitHost") })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ y("button", {
				ref: w,
				className: "ex-primary ex-review-restore",
				hidden: g,
				onClick: () => O(!0),
				children: [/* @__PURE__ */ v(f, { size: 18 }), p("games.acquire.reviewShow")]
			}),
			ie && /* @__PURE__ */ v(ne, {
				log: u.log,
				line: (e) => De(e, p, E),
				onClose: () => b(!1)
			})
		]
	});
}
//#endregion
//#region src/games/acquire/game-over-row.tsx
function Qe({ public: e, rid: t }) {
	let n = h(), r = e.final.find((e) => e.rid === t);
	return r ? /* @__PURE__ */ y("div", {
		className: "acquire-final-breakdown",
		children: [
			/* @__PURE__ */ v("span", { children: n("games.acquire.finalCash", { cash: r.cash.toLocaleString() }) }),
			/* @__PURE__ */ v("span", { children: n("games.acquire.finalBonuses", { cash: r.bonuses.toLocaleString() }) }),
			/* @__PURE__ */ v("span", { children: n("games.acquire.finalSales", { cash: r.sales.toLocaleString() }) })
		]
	}) : null;
}
//#endregion
//#region src/games/acquire/options.tsx
function $e({ value: e, onChange: t }) {
	let n = h(), r = R.safeParse(e), i = r.success ? r.data : R.parse(void 0);
	return /* @__PURE__ */ y("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ v(S, {
			title: n("games.acquire.assets"),
			children: [!0, !1].map((e) => /* @__PURE__ */ v(x, {
				name: "acquire-assets",
				value: String(e),
				checked: i.openAssets === e,
				label: n(e ? "games.acquire.openAssets" : "games.acquire.hiddenAssets"),
				accent: N.accent,
				onChange: () => t({ openAssets: e })
			}, String(e)))
		}), /* @__PURE__ */ v("p", {
			className: "text-sm text-ink/70",
			children: n("games.acquire.assetsNote")
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/acquire/entry.tsx
var et = {
	definition: me,
	View: Pe,
	bot: qe,
	describe: Je,
	fx: Xe,
	OverView: Ze,
	RowView: Qe,
	Options: $e,
	locales: {
		zh: {
			name: "并购",
			desc: "建设酒店集团，争夺股权，在并购中积累财富",
			rules: "目标：\n终局时现金最多的玩家获胜，同额则共享胜利。\n准备：\n使用经典九行、十二列版图、108 块地块与七家酒店集团，每家公司有 25 股。每人获得 $6,000 和六块私有地块。每人先抽一块地块放在对应坐标，字母优先、数字次之，最靠近 1A 的玩家先手，其余按座位顺序行动。初始相连地块仍为独立地块，直到后续放置将其纳入集团。开局可选择资产公开或隐藏，地块手牌始终私有。\n流程：\n每回合先放置一块手牌地块，处理成立、扩张或并购，再合计购买至多三股，最后补一块地块。无钱仍可放置地块。股票只能向银行购买，不得向玩家交易、借款或随时卖出。\n放置与成立：\n地块必须放在自身坐标，只有上下左右相邻才相连。连接至少两块独立地块时，选择一家未在场的集团成立，并领取一股创始奖励。该公司股票售罄时没有创始奖励。地块连接一家集团时，连通的独立地块一并加入该集团。七家集团均在场时，不能放置会成立第八家集团的地块；这种暂时不可用的地块不能替换。\n安全集团与废块：\n集团达到 11 格后成为安全集团，不能被吞并。会连接两家或更多安全集团的地块永久不可用。正常补牌后，可以选择丢弃任意数量的永久废块，并从剩余牌库补回等量地块；每回合只能替换一次，新抽到的废块须等下回合。牌库不足时仅补现有地块。全部手牌均不可放置时可以跳过放置，仍可购股与替换永久废块。\n并购：\n连接两家以上集团时，并购前规模最大的集团存续；触发并购的地块不计入规模，同规模由发起者选择。被并购集团按并购前规模从大到小逐家处理，同规模顺序由发起者选择。每家先公开所有玩家对该公司的持股并发放奖金，再从发起者开始按座位顺序处置股票。\n股东奖金：\n第一大股东奖金为并购前股价的十倍，第二大股东为五倍。只有一名股东时领取两份奖金；第一并列时合并两份奖金均分，第二不再获奖；第二并列时均分第二奖金。分得的奖金向上取整到 $100，无股票者不参与。存续集团不发并购奖金。\n处置股票：\n被并购股票可以组合选择保留、按并购前股价卖回银行，或每两股换一股存续集团的股票。换股受银行库存限制，先行动者先获得股票。保留的股票可在同名集团重新成立后恢复价值；不能出售其他在场公司的股票。\n购股与价格：\n每回合合计购买零至三股，只能买在场公司且不得超过库存与现金。高塔、卢克索为低价档，美国、环球、庆典为中价档，帝国、大陆为高价档。低价档规模 2、3、4、5、6–10、11–20、21–30、31–40、41 以上格时，股价分别为 $200、$300、$400、$500、$600、$700、$800、$900、$1,000；中价档加 $100，高价档加 $200。界面直接显示现价、规模、库存和本人持股。\n结束：\n任一集团达到 41 格，或至少一家集团在场且所有在场集团均安全时，当前玩家可在放置前、购股时或废块替换时宣布结束，也可继续游戏。宣布后照常完成本回合，再为每家在场集团发放第一、第二股东奖金，按现价出售所有在场集团股票。不在场公司的股票价值为零。现金最多者获胜。",
			certificate: "股票凭证",
			perShare: "每股",
			supplyLabel: "库存",
			ownedLabel: "持有",
			sizeLabel: "酒店",
			priceLabel: "股价",
			companyLabel: "公司",
			market: "股票行情",
			availableCash: "可用现金",
			buyLabel: "购入",
			buyLimit: "最多购买 3 股",
			acquiredChain: "被并购集团",
			survivingChain: "存续集团",
			keepNote: "留待集团再次成立",
			sellNote: "按当前股价变现",
			exchangeNote: "每 2 股换入 1 股",
			shareholderList: "{{company}}股东",
			saleIncome: "卖出收入",
			liquidation: "资产清算",
			assetItem: "资产项目",
			cashItem: "清算前现金",
			bonusItem: "股东奖金",
			salesItem: "股票变现",
			totalAssets: "总资产",
			winner: "本局胜者",
			sharedWinner: "共同胜者",
			place: "第 {{n}} 名",
			reviewHide: "收起清算，回看版图",
			reviewShow: "查看资产清算",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			settling: "结算中",
			tower: "高塔",
			luxor: "卢克索",
			american: "美国",
			worldwide: "环球",
			festival: "庆典",
			imperial: "帝国",
			continental: "大陆",
			assets: "资产",
			openAssets: "公开资产",
			hiddenAssets: "隐藏资产",
			assetsNote: "隐藏模式仅向本人显示现金与持股；交易和并购时需要公开的信息仍会公开。",
			turn: "第 {{n}} 回合",
			placePrompt: "选择一块地块放置",
			foundPrompt: "选择要成立的集团",
			survivorPrompt: "选择存续集团",
			orderPrompt: "选择先被并购的集团",
			disposePrompt: "处置{{company}}股票",
			buyPrompt: "购买至多三股",
			replacePrompt: "选择要替换的永久废块",
			waiting: "等待{{name}}",
			bonusPrompt: "发放{{company}}股东奖金",
			absorbPrompt: "{{company}}并入{{survivor}}",
			finalBonusPrompt: "清算：{{company}}股东奖金",
			finalSalePrompt: "清算：出售{{company}}股票",
			donePrompt: "清算完成",
			board: "酒店版图",
			bank: "股票银行",
			portfolio: "我的持股",
			holdings: "玩家资产",
			cash: "现金",
			size: "{{n}} 格",
			supply: "余 {{n}} 股",
			owned: "持有 {{n}} 股",
			safe: "安全",
			inactive: "未成立",
			deck: "牌库 {{n}}",
			discarded: "废块 {{n}}",
			hand: "我的地块",
			selectTile: "选择地块 {{tile}}",
			playTile: "放置 {{tile}}",
			blockedTile: "{{tile}}：暂时无法成立新集团",
			permanentTile: "{{tile}}：会连接安全集团",
			previewIndependent: "{{tile}}：独立酒店",
			previewFound: "{{tile}}：成立新集团",
			previewExpand: "{{tile}}：扩张{{company}}",
			previewMerge: "{{tile}}：并购 {{companies}}",
			chooseCompany: "选择{{company}}",
			cart: "{{n}}/3 股 · ${{cost}}",
			buy: "确认购股",
			skipBuy: "不购股并继续",
			addStock: "增购一股{{company}}",
			removeStock: "减少一股{{company}}",
			pass: "跳过放置",
			noLegalTile: "所有手牌均无法放置",
			declareEnd: "宣布结束",
			confirmEnd: "确认宣布结束",
			endDeclared: "本回合后结束",
			sell: "卖出",
			trade: "换入",
			keep: "保留",
			shares: "{{n}} 股",
			disposeSummary: "卖出收入 ${{cash}} · 保留 {{keep}} 股",
			tradeNote: "每两股换入一股{{company}}，银行剩余 {{n}} 股。",
			increaseSell: "多卖一股",
			decreaseSell: "少卖一股",
			increaseTrade: "多换入一股",
			decreaseTrade: "少换入一股",
			confirmDispose: "确认处置",
			changeDisposal: "调整处置",
			replaceSelected: "替换 {{n}} 块",
			skipReplace: "不替换并继续",
			waitingDisposal: "{{name}}正在处置股票",
			merger: "集团并购",
			finalCash: "清算前现金 ${{cash}}",
			finalBonuses: "股东奖金 ${{cash}}",
			finalSales: "股票变现 ${{cash}}",
			logStart: "{{name}}起始地块：{{tile}}",
			logPlace: "{{name}}放置 {{tile}}",
			logFound: "{{name}}成立{{company}}（{{n}} 格）",
			logFounderBonus: "领取一股创始奖励",
			logBuy: "{{name}}购入{{stocks}}，支付 ${{cash}}",
			stockAmount: "{{company}} {{n}} 股",
			logMerge: "{{company}}被{{survivor}}并购，原股价 ${{cash}}；持股：{{holdings}}",
			playerShares: "{{name}} {{n}} 股",
			logBonus: "{{company}}奖金：{{awards}}",
			playerAward: "{{name}} ${{cash}}",
			noBonus: "无股东领取",
			logDispose: "{{name}}处置{{company}}：卖出 {{sell}} 股，换入{{survivor}} {{trade}} 股，保留 {{keep}} 股",
			logAbsorb: "{{company}}已并入{{survivor}}",
			logDiscard: "{{name}}丢弃永久废块：{{tiles}}",
			logDeclare: "{{name}}宣布本回合后结束",
			logPass: "{{name}}跳过放置",
			logSale: "{{company}}股票变现：{{awards}}",
			errTurn: "现在轮不到你操作",
			errTile: "这块地块无法放置",
			errEighth: "七家集团均已在场，暂时不能成立新集团",
			errSafe: "不能连接两家安全集团",
			errCompany: "请选择可用的集团",
			errDispose: "持股数量或换股库存不足",
			errBuy: "购股不能超过三股、现金或银行库存",
			errReplace: "只能替换手中的永久废块",
			errPass: "仍有可以放置的地块",
			errEnd: "尚未满足结束条件"
		},
		en: {
			name: "Acquire",
			desc: "Build hotel chains, compete for shares, and profit from mergers",
			rules: "Goal: finish with the most cash. Tied players share the victory.\nSetup: use the classic 9×12 board, 108 tiles and seven hotel chains with 25 shares each. Each player starts with $6,000 and six private tiles. Each player first draws and places a starting tile. Compare letters first, then numbers; the tile closest to 1A determines the first player. Play continues in seating order. Connected starting tiles remain independent until a later placement incorporates them. Assets may be open or hidden; tile hands are always private.\nTurn: place one tile, resolve founding, expansion or mergers, buy a total of up to three shares, then draw one replacement tile. A player without cash still places tiles. Shares are bought only from the bank. Player trades, loans and selling active shares during normal play are not allowed.\nPlacement and founding: place a tile only at its matching coordinate. Only orthogonal adjacency counts. Joining at least two independent tiles founds an available chain and awards one free founder share. If no shares remain, there is no founder reward. Connecting one chain incorporates all connected independent tiles. If all seven chains are active, a tile that would found an eighth cannot be played or exchanged as a permanently unplayable tile.\nSafe chains and replacement: chains of at least 11 tiles are safe and cannot be acquired. A tile joining two or more safe chains is permanently unplayable. After the normal draw, you may discard any of your permanently unplayable tiles and draw the same number, limited by the remaining pool. This exchange is allowed only once per turn; newly drawn unplayable tiles must wait. If no hand tile can be played, skip placement but still buy shares and optionally replace permanently unplayable tiles.\nMergers: the largest chain before placement survives; the merging tile does not count toward chain size. The mergemaker chooses between tied largest chains. Acquired chains are resolved individually from largest to smallest, with ties ordered by the mergemaker. For each acquired chain, reveal everyone's holdings and pay bonuses, then dispose of shares starting with the mergemaker and proceeding in seating order.\nBonuses: the primary bonus is ten times the acquired chain's pre-merger stock price; the secondary bonus is five times that price. A sole stockholder receives both. Tied primary stockholders split both bonuses and no secondary bonus is paid. Tied secondary stockholders split the secondary bonus. Round each split payment up to the next $100. Zero shares never qualify. The surviving chain pays no merger bonus.\nDisposal: combine keeping acquired shares, selling them at their pre-merger price, and trading two for one share of the surviving chain. Exchanges are limited by bank supply and resolved in turn order. Kept shares may regain value if the same chain is founded again. Shares of other active chains cannot be sold.\nBuying and prices: buy zero to three shares in total from active chains, within cash and bank supply. Tower and Luxor are low tier; American, Worldwide and Festival are middle tier; Imperial and Continental are high tier. For chain sizes 2, 3, 4, 5, 6–10, 11–20, 21–30, 31–40 and 41+, low-tier prices are $200, $300, $400, $500, $600, $700, $800, $900 and $1,000. Add $100 for middle tier and $200 for high tier. The bank shows each chain's current size, price, supply and your holdings.\nEnd: when any chain reaches 41 tiles, or at least one chain is active and all active chains are safe, the current player may declare the game over before placement, while buying, or while replacing tiles. Declaring is optional. Finish that turn normally, pay primary and secondary bonuses for every active chain, then sell all active shares at current prices. Inactive shares are worthless. Most cash wins.",
			certificate: "STOCK CERTIFICATE",
			perShare: "Per share",
			supplyLabel: "Supply",
			ownedLabel: "Owned",
			sizeLabel: "Hotels",
			priceLabel: "Price",
			companyLabel: "Company",
			market: "Stock exchange",
			availableCash: "Available cash",
			buyLabel: "Buy",
			buyLimit: "Up to 3 shares",
			acquiredChain: "Acquired chain",
			survivingChain: "Surviving chain",
			keepNote: "Keep for a future founding",
			sellNote: "Sell at the current price",
			exchangeNote: "Trade 2 shares for 1",
			shareholderList: "{{company}} stockholders",
			saleIncome: "Sale proceeds",
			liquidation: "Asset liquidation",
			assetItem: "Asset item",
			cashItem: "Opening cash",
			bonusItem: "Bonuses",
			salesItem: "Share sales",
			totalAssets: "Total assets",
			winner: "Winner",
			sharedWinner: "Joint winners",
			place: "Rank {{n}}",
			reviewHide: "Hide liquidation and review the board",
			reviewShow: "View asset liquidation",
			confirmAgain: "Confirm play again",
			confirmLobby: "Confirm return to lobby",
			settling: "Settling",
			tower: "Tower",
			luxor: "Luxor",
			american: "American",
			worldwide: "Worldwide",
			festival: "Festival",
			imperial: "Imperial",
			continental: "Continental",
			assets: "Assets",
			openAssets: "Open assets",
			hiddenAssets: "Hidden assets",
			assetsNote: "Hidden assets show cash and holdings only to their owner. Trades and merger disclosures remain public.",
			turn: "Turn {{n}}",
			placePrompt: "Choose a tile to place",
			foundPrompt: "Choose a chain to found",
			survivorPrompt: "Choose the surviving chain",
			orderPrompt: "Choose the next acquired chain",
			disposePrompt: "Dispose of {{company}} shares",
			buyPrompt: "Buy up to three shares",
			replacePrompt: "Select unplayable tiles to replace",
			waiting: "Waiting for {{name}}",
			bonusPrompt: "{{company}} stockholder bonuses",
			absorbPrompt: "{{company}} joins {{survivor}}",
			finalBonusPrompt: "Final: {{company}} bonuses",
			finalSalePrompt: "Final: sell {{company}} shares",
			donePrompt: "Liquidation complete",
			board: "Hotel board",
			bank: "Stock bank",
			portfolio: "My portfolio",
			holdings: "Player assets",
			cash: "Cash",
			size: "{{n}} tiles",
			supply: "{{n}} left",
			owned: "{{n}} owned",
			safe: "Safe",
			inactive: "Inactive",
			deck: "Pool {{n}}",
			discarded: "Discarded {{n}}",
			hand: "My tiles",
			selectTile: "Select tile {{tile}}",
			playTile: "Place {{tile}}",
			blockedTile: "{{tile}}: no chain available",
			permanentTile: "{{tile}}: joins safe chains",
			previewIndependent: "{{tile}}: independent hotel",
			previewFound: "{{tile}}: found a chain",
			previewExpand: "{{tile}}: expand {{company}}",
			previewMerge: "{{tile}}: merge {{companies}}",
			chooseCompany: "Choose {{company}}",
			cart: "{{n}}/3 shares · ${{cost}}",
			buy: "Buy shares",
			skipBuy: "Continue without buying",
			addStock: "Buy one more {{company}} share",
			removeStock: "Remove one {{company}} share",
			pass: "Skip placement",
			noLegalTile: "No hand tile can be played",
			declareEnd: "End game",
			confirmEnd: "Confirm end game",
			endDeclared: "Ends after this turn",
			sell: "Sell",
			trade: "Receive",
			keep: "Keep",
			shares: "{{n}} shares",
			disposeSummary: "Receive ${{cash}} · Keep {{keep}}",
			tradeNote: "Trade two for one {{company}} share. Bank supply: {{n}}.",
			increaseSell: "Sell one more",
			decreaseSell: "Sell one fewer",
			increaseTrade: "Receive one more",
			decreaseTrade: "Receive one fewer",
			confirmDispose: "Confirm disposal",
			changeDisposal: "Adjust disposal",
			replaceSelected: "Replace {{n}} tiles",
			skipReplace: "Continue without replacing",
			waitingDisposal: "{{name}} is disposing of shares",
			merger: "Chain merger",
			finalCash: "Cash before liquidation ${{cash}}",
			finalBonuses: "Stockholder bonuses ${{cash}}",
			finalSales: "Share sales ${{cash}}",
			logStart: "{{name}} starts at {{tile}}",
			logPlace: "{{name}} places {{tile}}",
			logFound: "{{name}} founds {{company}} ({{n}} tiles)",
			logFounderBonus: "Receives one founder share",
			logBuy: "{{name}} buys {{stocks}} for ${{cash}}",
			stockAmount: "{{company}} ×{{n}}",
			logMerge: "{{company}} acquired by {{survivor}} at ${{cash}}; holdings: {{holdings}}",
			playerShares: "{{name}} ×{{n}}",
			logBonus: "{{company}} bonuses: {{awards}}",
			playerAward: "{{name}} ${{cash}}",
			noBonus: "No eligible stockholders",
			logDispose: "{{name}} disposes of {{company}}: sells {{sell}}, receives {{trade}} {{survivor}}, keeps {{keep}}",
			logAbsorb: "{{company}} has joined {{survivor}}",
			logDiscard: "{{name}} discards unplayable tiles: {{tiles}}",
			logDeclare: "{{name}} declares the game over after this turn",
			logPass: "{{name}} skips placement",
			logSale: "{{company}} share sales: {{awards}}",
			errTurn: "It is not your turn",
			errTile: "That tile cannot be placed",
			errEighth: "All seven chains are active; no new chain can be founded",
			errSafe: "Safe chains cannot merge",
			errCompany: "Choose an available chain",
			errDispose: "Not enough shares or exchange stock",
			errBuy: "Stay within three shares, your cash and bank supply",
			errReplace: "Only permanently unplayable hand tiles can be replaced",
			errPass: "You still have a playable tile",
			errEnd: "The end condition has not been met"
		}
	}
};
//#endregion
export { et as default };
