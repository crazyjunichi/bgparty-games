import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { useT as i } from "@bgparty/sdk/i18n";
import { GameScreen as a } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as o } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as s } from "@bgparty/sdk/ui/player-strip";
import { jsx as c, jsxs as l } from "react/jsx-runtime";
import { Floater as u, FlySprite as d, PulseBox as f } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as p } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/myfavoritethings/meta.ts
var m = {
	id: "myfavoritethings",
	tier: "alpha",
	mechanics: ["trick-taking"],
	interactionTags: [],
	nameKey: "games.myfavoritethings.name",
	descKey: "games.myfavoritethings.desc",
	rulesKey: "games.myfavoritethings.rules",
	icon: "💝",
	iconImg: "games/myfavoritethings.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/myfavoritethings/en.pdf" },
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [4],
	accent: "#e5007a",
	releasedAt: "2026-09-28",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover"
}, h = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("category"),
		text: t.string().trim().min(1).max(30)
	}),
	t.object({
		type: t.literal("answers"),
		items: t.array(t.string().trim().min(1).max(24)).length(6)
	}),
	t.object({
		type: t.literal("play"),
		card: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), g = t.string(), _ = t.object({
	owner: g,
	writer: g,
	category: t.string(),
	cards: t.array(t.object({
		text: t.string(),
		played: t.boolean(),
		rank: t.int().min(0).max(5).nullable()
	}))
}), v = t.object({
	phase: t.enum([
		"category",
		"answers",
		"play",
		"done"
	]),
	round: t.union([t.literal(1), t.literal(2)]),
	players: t.array(g),
	leader: g,
	turn: g.nullable(),
	hearts: t.record(g, t.int()),
	submitted: t.array(g),
	trickNo: t.int(),
	pendingRoundEnd: t.boolean(),
	hands: t.array(_),
	trick: t.object({
		plays: t.array(t.object({
			rid: g,
			card: t.int()
		})),
		revealed: t.boolean(),
		winner: g.nullable()
	})
}), y = t.object({
	mySubmitted: t.boolean(),
	myCategory: t.string().nullable(),
	answering: t.object({
		owner: g,
		category: t.string()
	}).nullable(),
	writtenFor: g.nullable(),
	writtenRanks: t.array(t.int().min(0).max(5)).nullable()
}), b = 3600, x = (e) => e === 1 ? 1 : -1, S = (e, t, n) => (t + x(n) + e) % e;
function C(t, n, r) {
	let i = {
		players: [...n],
		seed: r,
		cursor: 0,
		round: 1,
		phase: "category",
		submitted: [],
		hands: n.map((e) => ({
			owner: e,
			category: "",
			cards: [],
			played: [],
			revealed: []
		})),
		trick: {
			plays: [],
			revealed: !1,
			winner: null
		},
		tricksPlayed: 0,
		leader: n[e(r, 0, n.length)],
		turn: null,
		hearts: Object.fromEntries(n.map((e) => [e, 0])),
		pendingRoundEnd: !1
	};
	return i.cursor = 1, { state: i };
}
var w = (e, t) => e.players.indexOf(t), T = (e, t) => e.players[(w(e, t) + 1) % e.players.length];
function E(e) {
	let t = (t) => e.hands[w(e, t.rid)].cards[t.card].rank, n = e.trick.plays.some((e) => t(e) === 1), r = e.trick.plays.some((e) => t(e) === 0);
	if (n && r) return e.trick.plays.find((e) => t(e) === 0).rid;
	let i = 0;
	for (let n = 1; n < e.trick.plays.length; n += 1) {
		let r = (e) => e === 0 ? 6 : e;
		r(t(e.trick.plays[n])) < r(t(e.trick.plays[i])) && (i = n);
	}
	return e.trick.plays[i].rid;
}
function D(t, n, r) {
	if (n.type === "tick") {
		if (t.phase !== "play" || !t.pendingRoundEnd) return { state: t };
		let e = structuredClone(t);
		if (e.round === 1) {
			e.round = 2, e.phase = "category";
			for (let t of e.hands) t.category = "", t.cards = [], t.played = [], t.revealed = [];
			e.submitted = [], e.trick = {
				plays: [],
				revealed: !1,
				winner: null
			}, e.tricksPlayed = 0, e.turn = null, e.pendingRoundEnd = !1;
		} else e.phase = "done";
		return { state: e };
	}
	if (n.type === "category") {
		if (t.phase !== "category") return { code: "games.myfavoritethings.errBadPhase" };
		if (t.submitted.includes(r.by)) return { code: "games.myfavoritethings.errAlreadySubmitted" };
		let e = structuredClone(t);
		return e.hands[w(e, r.by)].category = n.text, e.submitted.push(r.by), e.submitted.length === e.players.length && (e.phase = "answers", e.submitted = []), { state: e };
	}
	if (n.type === "answers") {
		if (t.phase !== "answers") return { code: "games.myfavoritethings.errBadPhase" };
		if (t.submitted.includes(r.by)) return { code: "games.myfavoritethings.errAlreadySubmitted" };
		let i = structuredClone(t), a = i.players.length, o = (w(i, r.by) - x(i.round) + a) % a, s = n.items.map((e, t) => ({
			text: e,
			rank: t < 5 ? t + 1 : 0
		}));
		for (let t = s.length - 1; t > 0; --t) {
			let n = e(i.seed, i.cursor, t + 1);
			i.cursor += 1;
			let r = s[t];
			s[t] = s[n], s[n] = r;
		}
		return i.hands[o].cards = s, i.hands[o].played = s.map(() => !1), i.hands[o].revealed = s.map(() => !1), i.submitted.push(r.by), i.submitted.length === a && (i.phase = "play", i.submitted = [], i.trick = {
			plays: [],
			revealed: !1,
			winner: null
		}, i.tricksPlayed = 0, i.turn = i.leader), { state: i };
	}
	if (t.phase !== "play" || t.pendingRoundEnd) return { code: "games.myfavoritethings.errBadPhase" };
	if (t.turn !== r.by) return { code: "games.myfavoritethings.errNotYourTurn" };
	let i = w(t, r.by);
	if (t.hands[i].played[n.card]) return { code: "games.myfavoritethings.errCardPlayed" };
	let a = structuredClone(t);
	a.trick.revealed && (a.trick = {
		plays: [],
		revealed: !1,
		winner: null
	});
	let o = a.hands[i];
	o.played[n.card] = !0, a.trick.plays.push({
		rid: r.by,
		card: n.card
	});
	let s = [{
		kind: "play",
		rid: r.by,
		data: {
			card: n.card,
			text: o.cards[n.card].text
		}
	}];
	if (a.trick.plays.length < a.players.length) return a.turn = T(a, r.by), {
		state: a,
		fx: s
	};
	let c = E(a);
	a.trick.revealed = !0, a.trick.winner = c;
	for (let e of a.trick.plays) a.hands[w(a, e.rid)].revealed[e.card] = !0;
	return a.hearts[c] += 1, a.tricksPlayed += 1, a.leader = T(a, a.leader), a.turn = a.leader, s.push({
		kind: "reveal",
		data: { winner: c }
	}, {
		kind: "heart",
		rid: c,
		with: !0
	}), a.tricksPlayed >= 5 && (a.pendingRoundEnd = !0, a.turn = null), {
		state: a,
		fx: s
	};
}
function O(e, t) {
	let n = e.players.length, r = w(e, t), i = e.phase === "play" || e.phase === "done", a = {
		phase: e.phase,
		round: e.round,
		players: [...e.players],
		leader: e.leader,
		turn: e.turn,
		hearts: { ...e.hearts },
		submitted: [...e.submitted],
		trickNo: Math.min(e.tricksPlayed + 1, 5),
		pendingRoundEnd: e.pendingRoundEnd,
		hands: e.hands.map((r, a) => ({
			owner: r.owner,
			writer: e.players[S(n, a, e.round)],
			category: i || e.phase === "answers" && r.owner === t ? r.category : "",
			cards: i ? r.cards.map((e, t) => ({
				text: e.text,
				played: r.played[t],
				rank: r.revealed[t] ? e.rank : null
			})) : []
		})),
		trick: {
			plays: [...e.trick.plays],
			revealed: e.trick.revealed,
			winner: e.trick.winner
		}
	}, o = e.hands.findIndex((r, i) => e.players[S(n, i, e.round)] === t), s = e.phase === "answers" && o >= 0 ? {
		owner: e.hands[o].owner,
		category: e.hands[o].category
	} : null;
	return {
		public: a,
		private: {
			mySubmitted: e.submitted.includes(t),
			myCategory: (e.phase === "category" || e.phase === "answers") && e.hands[r]?.category || null,
			answering: s,
			writtenFor: i && o >= 0 ? e.hands[o].owner : null,
			writtenRanks: i && o >= 0 ? e.hands[o].cards.map((e) => e.rank) : null
		}
	};
}
function k(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Math.max(...e.players.map((t) => e.hearts[t]));
	return {
		phase: "done",
		winner: e.players.filter((n) => e.hearts[n] === t),
		ranking: [...e.players].sort((t, n) => e.hearts[n] - e.hearts[t]),
		scores: { ...e.hearts }
	};
}
function A(e) {
	return e.phase === "play" && e.pendingRoundEnd ? b : null;
}
var j = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: m,
	schemas: {
		action: h,
		publicView: v,
		privateView: y
	},
	setup: C,
	reduce: D,
	viewFor: O,
	status: k,
	nextTickIn: A
};
function M({ text: e, rank: t, winner: n, variant: r = "trick" }) {
	let i = t === void 0 ? null : /* @__PURE__ */ c("span", {
		className: `mft-rank absolute -top-2 -left-2 grid size-6 place-items-center rounded-full border-2 border-ink font-mono text-xs font-extrabold tabular-nums ${t === null ? "bg-surface text-ink/40" : t === 0 ? "bg-ink text-white" : "bg-surface"}`,
		children: t === null ? "?" : t === 0 ? "💔" : t
	});
	return r === "hand" ? /* @__PURE__ */ c("span", {
		className: "mft-hand-card relative inline-flex min-h-11 max-w-40 flex-none items-center rounded-md border-2 border-ink bg-white px-2 text-xs font-bold",
		children: /* @__PURE__ */ c("span", {
			className: "truncate",
			children: e
		})
	}) : /* @__PURE__ */ l("div", {
		className: "mft-answer-card relative flex flex-none items-center justify-center rounded-md border-2 border-ink bg-white p-1.5 text-center",
		style: {
			width: "var(--mft-card-w, 88px)",
			minHeight: "var(--mft-card-h, 72px)",
			boxShadow: n ? `0 0 0 3px ${m.accent}` : void 0
		},
		children: [i, /* @__PURE__ */ c("span", {
			className: "mft-card-copy line-clamp-3 text-xs leading-4 font-bold break-all",
			children: e
		})]
	});
}
//#endregion
//#region src/games/myfavoritethings/view-player.tsx
function N(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ c(P, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function P({ pub: e, priv: t, members: r, myRid: u, send: d }) {
	let f = i(), p = (e) => r.find((t) => t.rid === e)?.name ?? e, h = e.players.map((e) => r.find((t) => t.rid === e)).filter((e) => e !== void 0), g = e.hands.find((e) => e.owner === u), _ = t?.mySubmitted ?? !1, [v, y] = n(""), [b, x] = n(() => Array.from({ length: 6 }, () => "")), S = `${e.phase}:${e.round}`, [C, w] = n(S);
	C !== S && (w(S), y(""), x(Array.from({ length: 6 }, () => "")));
	let T = v.trim().length > 0, E = b.every((e) => e.trim().length > 0), D = "info", O = "", k;
	if (e.phase === "category") {
		let t = g ? p(g.writer) : "";
		_ ? O = f("games.myfavoritethings.waiting", {
			n: e.submitted.length,
			total: e.players.length
		}) : (D = "accent", O = f("games.myfavoritethings.catPrompt"), k = f(e.round === 1 ? "games.myfavoritethings.catSubR1" : "games.myfavoritethings.catSubR2", { name: t }));
	} else e.phase === "answers" ? _ ? O = f("games.myfavoritethings.waiting", {
		n: e.submitted.length,
		total: e.players.length
	}) : (D = "accent", O = f("games.myfavoritethings.ansPrompt"), k = t?.answering ? f("games.myfavoritethings.ansFor", { name: p(t.answering.owner) }) : void 0) : e.phase === "play" && (e.pendingRoundEnd ? (D = "done", O = f("games.myfavoritethings.roundEnd", { n: e.round })) : e.trick.revealed && e.trick.winner ? (D = "done", O = f("games.myfavoritethings.trickWin", { name: p(e.trick.winner) })) : e.turn === u ? (D = "accent", O = f("games.myfavoritethings.myTurn")) : O = f("games.myfavoritethings.waitTurn", { name: e.turn ? p(e.turn) : "" }));
	let A = e.phase === "play" ? f("games.myfavoritethings.trickChip", {
		n: e.trickNo,
		total: 5
	}) : e.phase === "done" ? void 0 : f("games.myfavoritethings.roundChip", {
		n: e.round,
		total: 2
	});
	return /* @__PURE__ */ l(a, {
		adaptive: !0,
		className: "mft-screen",
		banner: /* @__PURE__ */ l("div", {
			className: "mft-banner",
			style: { "--mft-players": e.players.length },
			children: [/* @__PURE__ */ c(o, {
				tone: D,
				text: O,
				sub: k,
				chip: A,
				accent: m.accent
			}), /* @__PURE__ */ c(s, {
				variant: "plate",
				members: h,
				myRid: u,
				status: (t) => /* @__PURE__ */ l("span", {
					className: "font-mono text-xs font-extrabold tabular-nums",
					children: ["❤️", e.hearts[t] ?? 0]
				}),
				action: (t) => e.phase === "category" || e.phase === "answers" ? e.submitted.includes(t) ? "done" : "pending" : e.phase === "play" && !e.pendingRoundEnd && t === e.turn ? "pending" : null,
				anchorOf: (e) => `seat:${e}`
			})]
		}),
		actionsHeight: "mft-actions",
		actions: e.phase === "category" ? /* @__PURE__ */ c("button", {
			className: "btn-base h-12 w-full cursor-pointer text-white disabled:opacity-40",
			style: { background: m.accent },
			disabled: !T || _,
			onClick: () => d({
				type: "category",
				text: v.trim()
			}),
			children: f("games.myfavoritethings.submit")
		}) : e.phase === "answers" ? /* @__PURE__ */ c("button", {
			className: "btn-base h-12 w-full cursor-pointer text-white disabled:opacity-40",
			style: { background: m.accent },
			disabled: !E || _,
			onClick: () => d({
				type: "answers",
				items: b.map((e) => e.trim())
			}),
			children: f("games.myfavoritethings.submit")
		}) : e.phase === "play" ? /* @__PURE__ */ c(z, {
			pub: e,
			myRid: u,
			send: d
		}) : null,
		children: [
			e.phase === "category" && /* @__PURE__ */ c(F, {
				priv: t,
				mySubmitted: _,
				value: v,
				onChange: y
			}),
			e.phase === "answers" && /* @__PURE__ */ c(I, {
				priv: t,
				mySubmitted: _,
				members: r,
				values: b,
				onChange: x
			}),
			(e.phase === "play" || e.phase === "done") && /* @__PURE__ */ c(L, {
				pub: e,
				priv: t,
				members: r
			})
		]
	});
}
function F({ priv: e, mySubmitted: t, value: n, onChange: r }) {
	let a = i(), o = a("games.myfavoritethings.suggestions").split("\n");
	return t ? /* @__PURE__ */ c("div", {
		className: "mft-wait grid h-full place-items-center",
		children: /* @__PURE__ */ c("p", {
			className: "frame p-3 text-center font-display text-xl font-extrabold",
			children: e?.myCategory
		})
	}) : /* @__PURE__ */ l("div", {
		className: "mft-category flex min-h-full flex-col gap-2",
		children: [
			/* @__PURE__ */ c("input", {
				value: n,
				onChange: (e) => r(e.target.value),
				maxLength: 30,
				placeholder: a("games.myfavoritethings.catPlaceholder"),
				"aria-label": a("games.myfavoritethings.catPrompt"),
				className: "min-h-12 w-full flex-none rounded-xl border-2 border-ink bg-surface px-3 font-bold"
			}),
			/* @__PURE__ */ c("p", {
				className: "flex-none text-xs font-bold opacity-60",
				children: a("games.myfavoritethings.suggestLabel")
			}),
			/* @__PURE__ */ c("div", {
				className: "mft-suggestions flex flex-wrap content-start gap-1.5",
				children: o.map((e) => /* @__PURE__ */ c("button", {
					type: "button",
					onClick: () => r(e),
					className: `min-h-9 cursor-pointer rounded-full border-2 border-ink px-3 text-xs font-bold ${n === e ? "bg-ink text-white" : "bg-surface"}`,
					children: e
				}, e))
			})
		]
	});
}
function I({ priv: e, mySubmitted: t, members: n, values: r, onChange: a }) {
	let o = i(), s = (e) => n.find((t) => t.rid === e)?.name ?? e, u = e?.answering;
	if (t || !u) return /* @__PURE__ */ c("div", {
		className: "mft-wait grid h-full place-items-center gap-2",
		children: /* @__PURE__ */ l("p", {
			className: "frame p-3 text-center",
			children: [/* @__PURE__ */ c("span", {
				className: "block text-xs font-bold opacity-60",
				children: o("games.myfavoritethings.catPrompt")
			}), /* @__PURE__ */ c("span", {
				className: "font-display text-xl font-extrabold",
				children: e?.myCategory
			})]
		})
	});
	let d = (e, t) => a(r.map((n, r) => r === e ? t : n));
	return /* @__PURE__ */ l("div", {
		className: "mft-answers flex min-h-full flex-col gap-1.5",
		children: [/* @__PURE__ */ l("p", {
			className: "frame flex-none p-2.5 text-center",
			children: [/* @__PURE__ */ c("span", {
				className: "block text-[11px] font-bold opacity-60",
				children: o("games.myfavoritethings.ansFor", { name: s(u.owner) })
			}), /* @__PURE__ */ c("span", {
				className: "font-display text-lg leading-6 font-extrabold",
				children: u.category
			})]
		}), r.map((e, t) => /* @__PURE__ */ l("div", {
			className: "flex flex-none items-center gap-2",
			children: [/* @__PURE__ */ c("span", {
				className: "w-20 flex-none text-right text-xs font-extrabold",
				children: t < 5 ? o("games.myfavoritethings.rankN", { n: t + 1 }) : o("games.myfavoritethings.heartbreaker")
			}), /* @__PURE__ */ c("input", {
				value: e,
				onChange: (e) => d(t, e.target.value),
				maxLength: 24,
				placeholder: o("games.myfavoritethings.ansPlaceholder"),
				"aria-label": t < 5 ? o("games.myfavoritethings.rankN", { n: t + 1 }) : o("games.myfavoritethings.heartbreaker"),
				className: "min-h-11 min-w-0 flex-1 rounded-xl border-2 border-ink bg-surface px-3 text-sm font-bold"
			})]
		}, t))]
	});
}
function L({ pub: e, priv: t, members: a }) {
	let o = i(), s = (e) => a.find((t) => t.rid === e)?.name ?? e, [u, d] = n(!1), [f, p] = n(0);
	e.phase === "play" && f !== e.round && (p(e.round), d(!0));
	let { ref: m } = r("trick"), h = (t, n) => e.hands.find((e) => e.owner === t)?.cards[n]?.rank ?? null, g = (t, n) => e.hands.find((e) => e.owner === t)?.cards[n]?.text ?? "";
	return /* @__PURE__ */ l("div", {
		className: "mft-play flex min-h-full flex-col gap-2",
		style: {
			"--mft-trick-columns": e.players.length === 4 ? 2 : 3,
			"--mft-trick-rows": e.players.length === 3 ? 1 : 2
		},
		children: [
			/* @__PURE__ */ c("button", {
				type: "button",
				onClick: () => d(!0),
				className: "mft-overview-open plate min-h-9 w-full flex-none cursor-pointer text-xs font-extrabold",
				children: o("games.myfavoritethings.overview")
			}),
			/* @__PURE__ */ c("div", {
				ref: m,
				className: "mft-trick flex flex-1 items-center justify-center p-2",
				children: /* @__PURE__ */ c("div", {
					className: "mft-trick-grid flex flex-wrap content-center items-center justify-center gap-x-3 gap-y-4",
					children: e.trick.plays.length === 0 ? /* @__PURE__ */ c("p", {
						className: "text-xs font-bold opacity-50",
						children: o("games.myfavoritethings.trickChip", {
							n: e.trickNo,
							total: 5
						})
					}) : e.trick.plays.map((t) => /* @__PURE__ */ c(R, {
						rid: t.rid,
						name: s(t.rid),
						text: g(t.rid, t.card),
						rank: h(t.rid, t.card),
						winner: e.trick.revealed && e.trick.winner === t.rid
					}, t.rid))
				})
			}),
			u && /* @__PURE__ */ c(B, {
				pub: e,
				priv: t,
				members: a,
				onClose: () => d(!1)
			})
		]
	});
}
function R({ rid: e, name: t, text: n, rank: i, winner: a }) {
	let { ref: o } = r(`trickcard:${e}`);
	return /* @__PURE__ */ l("span", {
		className: "mft-trick-slot inline-flex flex-col items-center gap-1",
		children: [/* @__PURE__ */ c("span", {
			ref: o,
			className: "mft-trick-card inline-flex",
			children: /* @__PURE__ */ c(M, {
				text: n,
				rank: i,
				winner: a
			})
		}), /* @__PURE__ */ c("span", {
			className: "mft-trick-name max-w-24 truncate text-[11px] font-bold opacity-70",
			title: t,
			children: t
		})]
	});
}
function z({ pub: e, myRid: t, send: n }) {
	let r = e.hands.find((e) => e.owner === t), i = e.turn === t && !e.pendingRoundEnd;
	return r ? /* @__PURE__ */ c("div", {
		className: "mft-hand flex h-full items-center gap-2 overflow-x-auto px-1 py-1",
		children: r.cards.map((e, t) => e.played ? null : /* @__PURE__ */ c("button", {
			type: "button",
			disabled: !i,
			onClick: () => n({
				type: "play",
				card: t
			}),
			className: "mft-hand-button cursor-pointer disabled:cursor-default disabled:opacity-60",
			"aria-label": e.text,
			children: /* @__PURE__ */ c(M, {
				text: e.text,
				variant: "hand"
			})
		}, t))
	}) : null;
}
function B({ pub: e, priv: t, members: n, onClose: r }) {
	let a = i(), o = (e) => n.find((t) => t.rid === e)?.name ?? e, s = (e, n) => e.cards[n].rank === null ? t?.writtenFor === e.owner && t.writtenRanks ? t.writtenRanks[n] : null : e.cards[n].rank;
	return /* @__PURE__ */ c("div", {
		className: "mft-overview-shade absolute inset-0 z-20 flex items-end justify-center bg-ink/40 p-3",
		onClick: r,
		children: /* @__PURE__ */ l("div", {
			className: "mft-overview card flex max-h-[80%] w-full max-w-md flex-col p-3",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ c("p", {
					className: "flex-none text-sm font-extrabold",
					children: a("games.myfavoritethings.overviewTitle")
				}),
				/* @__PURE__ */ c("div", {
					className: "mft-overview-list mt-2 min-h-0 flex-1 space-y-3 overflow-y-auto",
					children: e.hands.map((e) => /* @__PURE__ */ l("section", { children: [
						/* @__PURE__ */ l("p", {
							className: "text-xs font-extrabold",
							children: [a("games.myfavoritethings.handOf", { name: o(e.owner) }), /* @__PURE__ */ l("span", {
								className: "font-bold opacity-60",
								children: [" · ", a("games.myfavoritethings.answeredBy", { name: o(e.writer) })]
							})]
						}),
						/* @__PURE__ */ c("p", {
							className: "frame mt-1 px-2 py-1 text-xs font-bold",
							children: e.category
						}),
						/* @__PURE__ */ c("div", {
							className: "mt-1.5 flex flex-wrap gap-x-2.5 gap-y-3.5",
							children: e.cards.map((t, n) => /* @__PURE__ */ c("span", {
								className: t.played ? "opacity-45" : void 0,
								children: /* @__PURE__ */ c(M, {
									text: t.text,
									rank: s(e, n)
								})
							}, n))
						})
					] }, e.owner))
				}),
				/* @__PURE__ */ c("button", {
					type: "button",
					onClick: r,
					className: "btn-base mt-2 min-h-11 w-full flex-none cursor-pointer text-white",
					style: { background: m.accent },
					children: a("common.qr.close")
				})
			]
		})
	});
}
//#endregion
//#region src/games/myfavoritethings/bot.ts
var V = [
	"Animals",
	"Food",
	"Movies",
	"Colors",
	"Sports",
	"Books",
	"Snacks",
	"Weather"
], H = (e) => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e, U = (e, t) => {
	let n = e.public, r = e.private;
	if (n.phase === "category") return r?.mySubmitted ? null : { action: {
		type: "category",
		text: V[H(V.length)]
	} };
	if (n.phase === "answers") {
		if (r?.mySubmitted || !r?.answering) return null;
		let e = H(1e3);
		return { action: {
			type: "answers",
			items: [
				1,
				2,
				3,
				4,
				5,
				0
			].map((t) => t === 0 ? `Meh ${e}` : `Pick${t}-${e}`)
		} };
	}
	if (n.phase === "play" && n.turn === t.rid && !n.pendingRoundEnd) {
		let e = n.hands.find((e) => e.owner === t.rid);
		if (!e) return null;
		let r = e.cards.map((e, t) => e.played ? -1 : t).filter((e) => e >= 0);
		return r.length ? { action: {
			type: "play",
			card: r[H(r.length)]
		} } : null;
	}
	return null;
}, W = {
	play(e, t) {
		let n = e.data, r = e.rid, i = r ? t.anchor(`seat:${r}`) : null, a = r ? t.anchor(`trickcard:${r}`) : null;
		return !i || !a ? null : {
			ms: 460,
			node: /* @__PURE__ */ c(d, {
				from: i,
				to: a,
				ms: 420,
				children: /* @__PURE__ */ c("span", {
					style: {
						width: a.w || 88,
						minHeight: a.h || 72,
						"--mft-card-w": `${a.w || 88}px`,
						"--mft-card-h": `${a.h || 72}px`,
						"--mft-card-font": `${Math.max(a.w > 88 ? 14 : 12, Math.min(28, a.w * .065))}px`,
						"--mft-rank-size": `${Math.max(24, Math.min(48, a.w * .12))}px`,
						"--mft-rank-font": `${Math.max(12, Math.min(24, a.w * .06))}px`
					},
					className: "inline-flex",
					children: /* @__PURE__ */ c(M, {
						text: typeof n?.text == "string" ? n.text : "",
						rank: null
					})
				})
			}),
			hide: [`trickcard:${r}`]
		};
	},
	reveal(e, t) {
		let n = e.data?.winner, r = typeof n == "string" ? t.anchor(`trickcard:${n}`) : null;
		return {
			ms: 1e3,
			node: r ? /* @__PURE__ */ c(f, {
				at: r,
				ms: 950
			}) : null
		};
	},
	heart(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 850,
			node: /* @__PURE__ */ c(u, {
				at: n,
				ms: 800,
				children: "❤️+1"
			})
		} : null;
	}
};
//#endregion
//#region src/games/myfavoritethings/game-over.tsx
function G(e) {
	return /* @__PURE__ */ c("div", {
		className: "mft-game-over",
		children: /* @__PURE__ */ c(p, {
			...e,
			accent: m.accent
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/myfavoritethings/entry.tsx
var K = {
	definition: j,
	View: N,
	bot: U,
	fx: W,
	OverView: G,
	locales: {
		zh: {
			name: "My Favourite Things",
			desc: "用邻居填写的最爱清单打牌:排名保密,心碎牌专克第一名",
			rules: "目标:用邻居填写的最爱清单打牌赢墩,两轮后爱心最多者胜。\n流程:\n· 出题:每人为自己的手牌写一个类别,第 1 轮交左邻、第 2 轮交右邻作答。\n· 作答:按收到的类别写下第 1 至第 5 名最爱,另写一样最不喜欢的(心碎牌)。\n· 出牌:共 5 墩,从领出者开始按座位顺序各打一张;排名对持卡人保密。\n· 揭示:数字最小者赢墩;但第 1 名与心碎牌同墩时,心碎牌赢;平手先出者胜。\n· 赢墩获得 1 颗爱心;每墩结束后领出权移交左邻,与谁赢墩无关。\n结束:\n· 每人 6 张牌只打 5 张;两轮结束后爱心最多者获胜,平局共享胜利。",
			roundChip: "第 {{n}}/{{total}} 轮",
			trickChip: "第 {{n}}/{{total}} 墩",
			catPrompt: "给你的手牌出一个类别",
			catSubR1: "写好后交给左边的 {{name}} 作答",
			catSubR2: "写好后交给右边的 {{name}} 作答",
			catPlaceholder: "如:最爱的电影…",
			suggestLabel: "没灵感?点一个",
			ansPrompt: "这个类别下,你的最爱是?",
			ansFor: "{{name}} 出的题",
			rankN: "第 {{n}} 名",
			heartbreaker: "最不喜欢的 💔",
			ansPlaceholder: "写一样事物…",
			submit: "提交",
			waiting: "已提交,等待其他人 {{n}}/{{total}}",
			myTurn: "轮到你出牌",
			waitTurn: "等 {{name}} 出牌…",
			trickWin: "{{name}} 赢得本墩 ❤️+1",
			roundEnd: "第 {{n}} 轮结束",
			overview: "全部答案",
			overviewTitle: "全桌答案总览",
			handOf: "{{name}} 的手牌",
			answeredBy: "{{name}} 作答",
			errBadPhase: "现在不能这么做",
			errNotYourTurn: "还没轮到你",
			errAlreadySubmitted: "已经提交过了",
			errCardPlayed: "这张牌已经打出",
			suggestions: "电视节目\n桌游\n电影\n餐厅\n虚构角色\n交通工具\n动物\n形状\n语言\n度假目的地\n消遣活动\n手机应用\n内容创作者\n品牌\n服装单品\n音乐人\n网络流行语\n零食\n游戏系列\n反派角色\n运动\n口味\n天气\n颜色\n虚构世界\n词语\n作家\n地貌\n神话生物\n成语\n音乐类型\n历史人物\n借口\n学科\n蔬菜\n锻炼方式\n放松方式\n表情包\n电子游戏\n书\n约会点子\n电子设备\n收到过的礼物\n夏天的事物\n问候语\n家庭传统\n发明\n超能力\n球队"
		},
		en: {
			name: "My Favourite Things",
			desc: "Play tricks with lists written by your neighbours — ranks hidden, heartbreaker beats number one",
			rules: "Goal: play tricks with lists of favourites written by your neighbours; the most hearts after two rounds wins.\nPlay:\n· Category: everyone writes a category for their own hand; round 1 is answered by your left neighbour, round 2 by your right.\n· Answers: rank your five favourites in the given category, plus one least favourite (the heartbreaker).\n· Tricks: five tricks per round; from the leader, everyone plays one card in seat order — ranks stay hidden from the holder.\n· Reveal: the lowest number wins; but a 1 loses to a heartbreaker in the same trick; ties go to the earliest play.\n· The winner takes a heart; the lead passes left after each trick, whoever won it.\nEnd:\n· Everyone plays only 5 of their 6 cards; the most hearts after two rounds wins, and ties share the victory.",
			roundChip: "Round {{n}}/{{total}}",
			trickChip: "Trick {{n}}/{{total}}",
			catPrompt: "Write a category for your hand",
			catSubR1: "{{name}} (on your left) will answer it",
			catSubR2: "{{name}} (on your right) will answer it",
			catPlaceholder: "e.g. favourite films…",
			suggestLabel: "Need ideas? Tap one",
			ansPrompt: "What are your favourites in this category?",
			ansFor: "Category by {{name}}",
			rankN: "No. {{n}}",
			heartbreaker: "Least favourite 💔",
			ansPlaceholder: "Name one thing…",
			submit: "Submit",
			waiting: "Submitted — waiting {{n}}/{{total}}",
			myTurn: "Your turn to play",
			waitTurn: "Waiting for {{name}}…",
			trickWin: "{{name}} takes the trick ❤️+1",
			roundEnd: "Round {{n}} complete",
			overview: "All answers",
			overviewTitle: "All lists at the table",
			handOf: "{{name}}'s hand",
			answeredBy: "answered by {{name}}",
			errBadPhase: "Not allowed right now",
			errNotYourTurn: "Not your turn yet",
			errAlreadySubmitted: "Already submitted",
			errCardPlayed: "That card is already played",
			suggestions: "TV Shows\nBoard Games\nFilms\nRestaurants\nFictional Characters\nModes of Transport\nAnimals\nShapes\nLanguages\nHoliday Destinations\nActivities\nApps\nContent Creators\nBrands\nClothing\nMusicians\nSlang Terms\nSnacks\nFranchises\nVillains\nSports\nFlavours\nWeather\nColours\nFictional Worlds\nWords\nAuthors\nGeographical Features\nMythical Beings\nIdioms\nGenres\nHistorical Figures\nExcuses\nSchool Subjects\nVegetables\nWays to Exercise\nWays to Relax\nEmojis\nVideo Games\nBooks\nDate Ideas\nElectronic Devices\nGifts You Have Received\nThings About Summer\nGreetings\nFamily Traditions\nInventions\nSuperpowers\nTeams"
		}
	}
};
//#endregion
export { K as default };
