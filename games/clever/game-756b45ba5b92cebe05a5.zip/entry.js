import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useT as s } from "@bgparty/sdk/i18n";
import { gridCell as c } from "@bgparty/sdk/sheet-geometry";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as ee } from "@bgparty/sdk/ui/player-strip";
import { SheetMark as d } from "@bgparty/sdk/sheet-mark";
import { SheetFxProbe as f, SheetText as te, SheetView as p } from "@bgparty/sdk/sheet-view";
import { Fragment as ne, jsx as m, jsxs as h } from "react/jsx-runtime";
import { Floater as re, FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as v } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/clever/meta.ts
var y = {
	id: "clever",
	tier: "beta",
	mechanics: [
		"roll-and-write",
		"drafting",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.clever.name",
	descKey: "games.clever.desc",
	rulesKey: "games.clever.rules",
	icon: "🦊",
	iconImg: "games/clever.webp",
	rulesUrl: { de: "https://www.schmidtspiele.de/files/Produkte/4/49340%20-%20Ganz%20sch%C3%B6n%20clever/49340_Ganz_schoen_Clever_DE.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#7c3aed",
	releasedAt: "2026-09-16",
	search: {
		py: "jue ding cong ming",
		init: "jdcm"
	},
	hotseat: "cover"
}, b = t.enum([
	"yellow",
	"blue",
	"green",
	"orange",
	"purple",
	"white"
]), x = t.enum([
	"yellow",
	"blue",
	"green",
	"orange",
	"purple"
]), S = t.discriminatedUnion("type", [
	t.object({ type: t.literal("roll") }),
	t.object({ type: t.literal("reroll") }),
	t.object({
		type: t.literal("pick"),
		die: b,
		area: x.optional(),
		cell: t.int().min(0).max(15).optional()
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("extraDie"),
		die: b,
		area: x.optional(),
		cell: t.int().min(0).max(15).optional()
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("passivePick"),
		die: b,
		area: x.optional(),
		cell: t.int().min(0).max(15).optional()
	}),
	t.object({ type: t.literal("passiveDone") }),
	t.object({
		type: t.literal("bonusX"),
		area: t.enum([
			"yellow",
			"blue",
			"green"
		]),
		cell: t.int().min(0).max(15).optional()
	}),
	t.object({
		type: t.literal("bonusSix"),
		area: t.enum(["orange", "purple"])
	}),
	t.object({
		type: t.literal("round4"),
		choice: t.enum(["x", "six"])
	}),
	t.object({
		type: t.literal("tiePick"),
		die: b
	}),
	t.object({ type: t.literal("finalDone") })
]), C = t.union([
	t.object({
		kind: t.literal("x"),
		area: t.enum(["yellow", "blue"])
	}),
	t.object({ kind: t.literal("xAny") }),
	t.object({ kind: t.literal("sixAny") })
]), ie = t.object({
	yellow: t.array(t.boolean()).length(16),
	blue: t.array(t.boolean()).length(11),
	green: t.int().min(0).max(11),
	orange: t.array(t.int().min(1).max(18).nullable()).length(11),
	purple: t.array(t.int().min(1).max(6).nullable()).length(11),
	foxes: t.int().min(0),
	reroll: t.object({
		unlocked: t.int().min(0).max(7),
		used: t.int().min(0).max(7)
	}),
	extra: t.object({
		unlocked: t.int().min(0).max(7),
		used: t.int().min(0).max(7)
	}),
	claimed: t.object({
		yRows: t.array(t.boolean()).length(4),
		yDiag: t.boolean(),
		bRows: t.array(t.boolean()).length(3),
		bCols: t.array(t.boolean()).length(4)
	})
}), ae = t.object({
	players: t.array(t.string()).min(1).max(4),
	round: t.int().min(1),
	roundTotal: t.int().min(4).max(6),
	phase: t.enum([
		"roundBonus",
		"active",
		"passive",
		"finalExtra",
		"done"
	]),
	stage: t.enum([
		"roll",
		"pick",
		"extra"
	]),
	active: t.string(),
	dice: t.array(t.object({
		color: b,
		value: t.int().min(0).max(6),
		loc: t.enum([
			"pool",
			"field",
			"platter"
		])
	})).length(6),
	picks: t.int().min(0).max(3),
	sheets: t.record(t.string(), ie),
	pending: t.record(t.string(), t.array(C)),
	extraUsed: t.record(t.string(), t.array(b)),
	passive: t.record(t.string(), t.object({
		picked: t.boolean(),
		done: t.boolean()
	})),
	soloTie: t.object({
		candidates: t.array(b).min(2),
		need: t.int().min(1)
	}).nullable(),
	round4Waiting: t.array(t.string()),
	finalWaiting: t.array(t.string())
}), w = t.object({}), T = [
	"yellow",
	"blue",
	"green",
	"orange",
	"purple",
	"white"
], E = [
	[
		3,
		6,
		5,
		0
	],
	[
		2,
		1,
		0,
		5
	],
	[
		1,
		0,
		2,
		4
	],
	[
		0,
		3,
		4,
		6
	]
], oe = [
	10,
	14,
	16,
	20
], D = [
	[
		2,
		3,
		4
	],
	[
		5,
		6,
		7,
		8
	],
	[
		9,
		10,
		11,
		12
	]
], O = [
	[
		2,
		5,
		9
	],
	[
		3,
		6,
		10
	],
	[
		4,
		7,
		11
	],
	[8, 12]
], se = [
	1,
	2,
	4,
	7,
	11,
	16,
	22,
	29,
	37,
	46,
	56
], k = [
	1,
	2,
	3,
	4,
	5,
	1,
	2,
	3,
	4,
	5,
	6
], ce = [
	1,
	3,
	6,
	10,
	15,
	21,
	28,
	36,
	45,
	55,
	66
], A = [
	1,
	1,
	1,
	2,
	1,
	1,
	2,
	1,
	2,
	1,
	3
], le = [
	{
		kind: "x",
		area: "blue"
	},
	{
		kind: "num",
		area: "orange",
		value: 4
	},
	{
		kind: "x",
		area: "green"
	},
	{ kind: "fox" }
], ue = [
	{
		kind: "num",
		area: "orange",
		value: 5
	},
	{
		kind: "x",
		area: "yellow"
	},
	{ kind: "fox" }
], de = [
	{ kind: "reroll" },
	{
		kind: "x",
		area: "green"
	},
	{
		kind: "num",
		area: "purple",
		value: 6
	},
	{ kind: "extra" }
], j = {
	3: { kind: "extra" },
	6: {
		kind: "x",
		area: "blue"
	},
	7: { kind: "fox" },
	9: {
		kind: "num",
		area: "purple",
		value: 6
	},
	10: { kind: "reroll" }
}, fe = {
	2: { kind: "reroll" },
	4: {
		kind: "x",
		area: "yellow"
	},
	5: { kind: "extra" },
	7: { kind: "fox" },
	9: {
		kind: "num",
		area: "purple",
		value: 6
	}
}, M = {
	2: { kind: "reroll" },
	3: {
		kind: "x",
		area: "blue"
	},
	4: { kind: "extra" },
	5: {
		kind: "x",
		area: "yellow"
	},
	6: { kind: "fox" },
	7: { kind: "reroll" },
	8: {
		kind: "x",
		area: "green"
	},
	9: {
		kind: "num",
		area: "orange",
		value: 6
	},
	10: { kind: "extra" }
};
function N() {
	return {
		yellow: Array.from({ length: 16 }, (e, t) => E[t / 4 | 0][t % 4] === 0),
		blue: Array.from({ length: 11 }, () => !1),
		green: 0,
		orange: Array.from({ length: 11 }, () => null),
		purple: Array.from({ length: 11 }, () => null),
		foxes: 0,
		reroll: {
			unlocked: 0,
			used: 0
		},
		extra: {
			unlocked: 0,
			used: 0
		},
		claimed: {
			yRows: [
				!1,
				!1,
				!1,
				!1
			],
			yDiag: !1,
			bRows: [
				!1,
				!1,
				!1
			],
			bCols: [
				!1,
				!1,
				!1,
				!1
			]
		}
	};
}
function P(e) {
	return e.indexOf(null);
}
function F(e) {
	return e.yellow.every(Boolean);
}
function I(e) {
	return e.blue.every(Boolean);
}
function L(e, t, n, r) {
	let i = [], a = (t, n) => {
		if (t === "yellow") {
			for (let r = 0; r < 16; r += 1) !e.yellow[r] && E[r / 4 | 0][r % 4] === n && i.push({
				area: t,
				cell: r,
				written: n
			});
			return;
		}
		if (t === "blue") {
			n >= 2 && n <= 12 && !e.blue[n - 2] && i.push({
				area: t,
				cell: n - 2,
				written: n
			});
			return;
		}
		if (t === "green") {
			e.green < 11 && n >= k[e.green] && i.push({
				area: t,
				written: n
			});
			return;
		}
		if (t === "orange") {
			let r = P(e.orange);
			r < 11 && i.push({
				area: t,
				written: n * A[r]
			});
			return;
		}
		let r = P(e.purple);
		r < 11 && (r === 0 || e.purple[r - 1] === 6 || n > (e.purple[r - 1] ?? 0)) && i.push({
			area: t,
			written: n
		});
	};
	return t === "white" ? (a("yellow", n), a("blue", n + r), a("green", n), a("orange", n), a("purple", n)) : t === "blue" ? a("blue", n + r) : a(t, n), i;
}
function R(e, t, n = !1) {
	let r = [];
	if (t.area === "yellow") {
		let n = t.cell ?? -1;
		e.yellow[n] = !0;
		let i = n / 4 | 0, a = n % 4;
		return !e.claimed.yRows[i] && [
			0,
			1,
			2,
			3
		].every((t) => e.yellow[i * 4 + t]) && (e.claimed.yRows[i] = !0, r.push(le[i])), i === a && !e.claimed.yDiag && [
			0,
			5,
			10,
			15
		].every((t) => e.yellow[t]) && (e.claimed.yDiag = !0, r.push({ kind: "extra" })), {
			cell: n,
			triggers: r
		};
	}
	if (t.area === "blue") {
		let n = t.cell ?? -1;
		e.blue[n] = !0;
		let i = n + 2, a = D.findIndex((e) => e.includes(i));
		a >= 0 && !e.claimed.bRows[a] && D[a].every((t) => e.blue[t - 2]) && (e.claimed.bRows[a] = !0, r.push(ue[a]));
		let o = O.findIndex((e) => e.includes(i));
		return o >= 0 && !e.claimed.bCols[o] && O[o].every((t) => e.blue[t - 2]) && (e.claimed.bCols[o] = !0, r.push(de[o])), {
			cell: n,
			triggers: r
		};
	}
	if (t.area === "green") {
		let i = e.green;
		if (!n && t.written < k[i]) throw Error("green below req");
		e.green += 1;
		let a = j[i];
		return a && r.push(a), {
			cell: i,
			triggers: r
		};
	}
	if (t.area === "orange") {
		let n = P(e.orange);
		e.orange[n] = t.written;
		let i = fe[n];
		return i && r.push(i), {
			cell: n,
			triggers: r
		};
	}
	let i = P(e.purple);
	e.purple[i] = t.written;
	let a = M[i];
	return a && r.push(a), {
		cell: i,
		triggers: r
	};
}
function pe(e) {
	return e > 280 ? 0 : e >= 260 ? 1 : e >= 240 ? 2 : e >= 220 ? 3 : e >= 200 ? 4 : e >= 180 ? 5 : e >= 160 ? 6 : e >= 140 ? 7 : 8;
}
function z(e) {
	let t = 0;
	for (let n = 0; n < 4; n += 1) [
		0,
		1,
		2,
		3
	].every((t) => e.yellow[t * 4 + n]) && (t += oe[n]);
	let n = e.blue.filter(Boolean).length, r = n > 0 ? se[n - 1] : 0, i = e.green > 0 ? ce[e.green - 1] : 0, a = e.orange.reduce((e, t) => e + (t ?? 0), 0), o = e.purple.reduce((e, t) => e + (t ?? 0), 0), s = Math.min(t, r, i, a, o), c = e.foxes * s, l = Math.max(t, r, i, a, o);
	return {
		yellow: t,
		blue: r,
		green: i,
		orange: a,
		purple: o,
		foxPts: c,
		total: t + r + i + a + o + c,
		best: l
	};
}
//#endregion
//#region src/games/clever/rules.ts
function me(e) {
	return e >= 4 ? 4 : e === 3 ? 5 : 6;
}
var B = {
	notYourTurn: "games.clever.errNotYourTurn",
	badDie: "games.clever.errBadDie",
	badCell: "games.clever.errBadCell",
	noReroll: "games.clever.errNoReroll",
	noExtra: "games.clever.errNoExtra",
	resolveBonus: "games.clever.errResolveBonus",
	tiePending: "games.clever.errTie",
	mustPick: "games.clever.errMustPick",
	over: "games.clever.errOver"
};
function he(t, n, r) {
	let i = e(r, 0, n.length), a = {}, o = {};
	for (let e of n) {
		let t = N();
		t.reroll.unlocked = 1, a[e] = t, o[e] = [];
	}
	return {
		state: {
			players: n,
			sheets: a,
			round: 1,
			roundTotal: me(n.length),
			activeIdx: i,
			turnsThisRound: 0,
			phase: "active",
			stage: "roll",
			dice: T.map((e) => ({
				color: e,
				value: 0,
				loc: "pool"
			})),
			picks: 0,
			pending: o,
			extraUsed: {},
			passive: {},
			soloTie: null,
			round4: {},
			finalDone: {},
			seed: r,
			rngCursor: 1
		},
		fx: []
	};
}
function V(e, t) {
	return t === "blue" ? e.find((e) => e.color === "white")?.value ?? 0 : t === "white" ? e.find((e) => e.color === "blue")?.value ?? 0 : 0;
}
function ge(e, t, n, r, i) {
	let a = t.find((e) => e.color === n);
	if (!a || a.value === 0) return null;
	let o = L(e, n, a.value, V(t, n)).filter((e) => e.area === r);
	return o.length === 0 ? null : o.length === 1 ? o[0] : o.find((e) => e.cell === i) ?? null;
}
function _e(e, t, n, r, i) {
	let a = [...n];
	for (; a.length > 0;) {
		let n = a.shift();
		if (n.kind === "fox") e.foxes += 1, r.push({
			kind: "gain",
			rid: i,
			data: { what: "fox" }
		});
		else if (n.kind === "reroll") e.reroll.unlocked < 7 && (e.reroll.unlocked += 1), r.push({
			kind: "gain",
			rid: i,
			data: { what: "reroll" }
		});
		else if (n.kind === "extra") e.extra.unlocked < 7 && (e.extra.unlocked += 1), r.push({
			kind: "gain",
			rid: i,
			data: { what: "extra" }
		});
		else if (n.kind === "x") {
			if (n.area === "green") {
				if (e.green < 11) {
					let t = R(e, {
						area: "green",
						written: 0
					}, !0);
					r.push({
						kind: "enter",
						rid: i,
						data: {
							area: "green",
							cell: t.cell,
							value: 0,
							via: "bonus"
						}
					}), a.push(...t.triggers);
				}
			} else (n.area === "yellow" ? F(e) : I(e)) || t.push({
				kind: "x",
				area: n.area
			});
		} else if (P(n.area === "orange" ? e.orange : e.purple) < 11) {
			let t = R(e, {
				area: n.area,
				written: n.value
			});
			r.push({
				kind: "enter",
				rid: i,
				data: {
					area: n.area,
					cell: t.cell,
					value: e[n.area][t.cell],
					via: "bonus"
				}
			}), a.push(...t.triggers);
		}
	}
}
function ve(e, t, n, r, i, a) {
	let o = R(e, n);
	i.push({
		kind: "enter",
		rid: a,
		data: {
			area: n.area,
			cell: o.cell,
			value: n.written,
			via: r
		}
	}), _e(e, t, o.triggers, i, a);
}
function H(e, t) {
	for (; t.length > 0;) {
		let n = t[0];
		if (!(n.kind === "x" ? n.area === "yellow" ? F(e) : I(e) : n.kind === "xAny" ? F(e) && I(e) && e.green >= 11 : P(e.orange) >= 11 && P(e.purple) >= 11)) return;
		t.shift();
	}
}
function U(e) {
	return e.dice.filter((e) => e.loc === "pool");
}
function ye(e, t) {
	let n = e.sheets[t];
	return U(e).every((t) => L(n, t.color, t.value, V(e.dice, t.color)).length === 0);
}
function be(e, t, n) {
	return L(e.sheets[t], n.color, n.value, V(e.dice, n.color)).length > 0;
}
function W(e) {
	e.phase = "active", e.stage = "roll", e.picks = 0, e.extraUsed = {}, e.passive = {};
	for (let t of e.dice) t.loc = "pool", t.value = 0;
}
function xe(e) {
	if (e.turnsThisRound += 1, e.activeIdx = (e.activeIdx + 1) % e.players.length, e.turnsThisRound < e.players.length) {
		W(e);
		return;
	}
	if (e.turnsThisRound = 0, e.round >= e.roundTotal) {
		e.phase = "finalExtra", e.extraUsed = {}, e.finalDone = {};
		return;
	}
	if (e.round += 1, e.round === 2) {
		for (let t of e.players) e.sheets[t].extra.unlocked = Math.min(7, e.sheets[t].extra.unlocked + 1);
		W(e);
	} else if (e.round === 3) {
		for (let t of e.players) e.sheets[t].reroll.unlocked = Math.min(7, e.sheets[t].reroll.unlocked + 1);
		W(e);
	} else e.round === 4 ? (e.phase = "roundBonus", e.round4 = {}, e.stage = "roll") : W(e);
}
function G(e) {
	return e.players[e.activeIdx];
}
function Se(t, n, r) {
	if (t.phase === "done") return { code: B.over };
	if (n.type === "bonusX") {
		let e = t.pending[r.by]?.[0];
		if (!e || e.kind === "x" && e.area !== n.area || e.kind === "sixAny") return { code: B.badCell };
		let i = structuredClone(t), a = i.sheets[r.by], o = [], s;
		if (n.area === "green") {
			if (a.green >= 11) return { code: B.badCell };
			s = {
				area: "green",
				written: 0
			};
		} else if (n.area === "yellow") {
			if (n.cell === void 0 || a.yellow[n.cell]) return { code: B.badCell };
			s = {
				area: "yellow",
				cell: n.cell,
				written: 0
			};
		} else {
			if (n.cell === void 0 || n.cell > 10 || a.blue[n.cell]) return { code: B.badCell };
			s = {
				area: "blue",
				cell: n.cell,
				written: n.cell + 2
			};
		}
		let c = R(a, s, n.area === "green");
		return o.push({
			kind: "enter",
			rid: r.by,
			data: {
				area: s.area,
				cell: c.cell,
				value: s.written,
				via: "bonus"
			}
		}), i.pending[r.by].shift(), _e(a, i.pending[r.by], c.triggers, o, r.by), H(a, i.pending[r.by]), i.phase === "roundBonus" && i.players.every((e) => i.round4[e]) && i.players.every((e) => i.pending[e].length === 0) && W(i), {
			state: i,
			fx: o
		};
	}
	if (n.type === "bonusSix") {
		let e = t.pending[r.by]?.[0];
		if (!e || e.kind !== "sixAny") return { code: B.badCell };
		let i = structuredClone(t), a = i.sheets[r.by];
		if (P(n.area === "orange" ? a.orange : a.purple) >= 11) return { code: B.badCell };
		let o = [], s = R(a, {
			area: n.area,
			written: 6
		});
		return o.push({
			kind: "enter",
			rid: r.by,
			data: {
				area: n.area,
				cell: s.cell,
				value: a[n.area][s.cell],
				via: "bonus"
			}
		}), i.pending[r.by].shift(), _e(a, i.pending[r.by], s.triggers, o, r.by), H(a, i.pending[r.by]), i.phase === "roundBonus" && i.players.every((e) => i.round4[e]) && i.players.every((e) => i.pending[e].length === 0) && W(i), {
			state: i,
			fx: o
		};
	}
	if (n.type === "round4") {
		if (t.phase !== "roundBonus" || t.round4[r.by]) return { code: B.notYourTurn };
		let e = structuredClone(t);
		return e.round4[r.by] = n.choice, e.pending[r.by].push(n.choice === "x" ? { kind: "xAny" } : { kind: "sixAny" }), H(e.sheets[r.by], e.pending[r.by]), e.players.every((t) => e.round4[t]) && e.players.every((t) => e.pending[t].length === 0) && W(e), {
			state: e,
			fx: []
		};
	}
	if (n.type === "roll") {
		if (t.phase !== "active" || t.stage !== "roll" || r.by !== G(t)) return { code: B.notYourTurn };
		if (t.pending[r.by].length > 0) return { code: B.resolveBonus };
		let n = structuredClone(t), i = U(n);
		if (i.length === 0) return { code: B.badDie };
		for (let t of n.dice) t.loc === "pool" && (t.value = e(n.seed, n.rngCursor, 6) + 1, n.rngCursor += 1);
		return n.stage = "pick", {
			state: n,
			fx: [{
				kind: "roll",
				rid: r.by,
				data: { dice: i.map((e) => ({
					color: e.color,
					value: e.value
				})) }
			}]
		};
	}
	if (n.type === "reroll") {
		if (t.phase !== "active" || t.stage !== "pick" || r.by !== G(t)) return { code: B.notYourTurn };
		let n = t.sheets[r.by];
		if (n.reroll.unlocked <= n.reroll.used) return { code: B.noReroll };
		let i = structuredClone(t);
		i.sheets[r.by].reroll.used += 1;
		let a = U(i);
		for (let t of i.dice) t.loc === "pool" && (t.value = e(i.seed, i.rngCursor, 6) + 1, i.rngCursor += 1);
		return {
			state: i,
			fx: [{
				kind: "roll",
				rid: r.by,
				data: { dice: a.map((e) => ({
					color: e.color,
					value: e.value
				})) }
			}]
		};
	}
	if (n.type === "pick" || n.type === "pass") {
		if (t.phase !== "active" || t.stage !== "pick" || r.by !== G(t)) return { code: B.notYourTurn };
		if (t.pending[r.by].length > 0) return { code: B.resolveBonus };
		if (n.type === "pass") {
			if (!ye(t, r.by)) return { code: B.badDie };
			let e = structuredClone(t);
			for (let t of e.dice) t.loc === "pool" && (t.loc = "platter");
			return e.stage = "extra", {
				state: e,
				fx: []
			};
		}
		let e = t.dice.find((e) => e.color === n.die);
		if (!e || e.loc !== "pool") return { code: B.badDie };
		let i = ge(t.sheets[r.by], t.dice, n.die, n.area, n.cell);
		if (!i) return { code: B.badCell };
		let a = structuredClone(t), o = [], s = a.dice.find((e) => e.color === n.die);
		s.loc = "field", a.picks += 1, ve(a.sheets[r.by], a.pending[r.by], i, "pick", o, r.by);
		for (let e of a.dice) e.loc === "pool" && (e.value < s.value || a.picks >= 3) && (e.loc = "platter");
		return a.stage = a.picks >= 3 || U(a).length === 0 ? "extra" : "roll", H(a.sheets[r.by], a.pending[r.by]), {
			state: a,
			fx: o
		};
	}
	if (n.type === "endTurn") {
		if (t.phase !== "active" || t.stage !== "extra" || r.by !== G(t)) return { code: B.notYourTurn };
		if (t.pending[r.by].length > 0) return { code: B.resolveBonus };
		let n = structuredClone(t);
		if (n.players.length === 1) {
			for (let t of n.dice) t.loc = "pool", t.value = e(n.seed, n.rngCursor, 6) + 1, n.rngCursor += 1;
			let t = [...n.dice].sort((e, t) => e.value - t.value), i = t[2].value, a = t.filter((e) => e.value === i), o = 3;
			for (let e of n.dice) e.value < i && (e.loc = "platter", --o);
			if (o > 0 && a.length === o) {
				for (let e of n.dice) e.value === i && (e.loc = "platter");
				o = 0;
			}
			return n.soloTie = o > 0 ? {
				candidates: a.map((e) => e.color),
				need: o
			} : null, n.phase = "passive", n.passive = { [r.by]: {
				picked: !1,
				done: !1
			} }, n.extraUsed = {}, {
				state: n,
				fx: [{
					kind: "roll",
					rid: r.by,
					data: { dice: n.dice.map((e) => ({
						color: e.color,
						value: e.value
					})) }
				}]
			};
		}
		n.phase = "passive", n.passive = {};
		for (let e of n.players) e !== r.by && (n.passive[e] = {
			picked: !1,
			done: !1
		});
		return {
			state: n,
			fx: []
		};
	}
	if (n.type === "tiePick") {
		let e = t.soloTie;
		if (t.phase !== "passive" || t.players.length !== 1 || !e || r.by !== G(t)) return { code: B.notYourTurn };
		if (!e.candidates.includes(n.die)) return { code: B.badDie };
		let i = structuredClone(t), a = i.dice.find((e) => e.color === n.die);
		a.loc = "platter";
		let o = i.soloTie;
		return o.candidates = o.candidates.filter((e) => e !== n.die), --o.need, o.need <= 0 && (i.soloTie = null), {
			state: i,
			fx: []
		};
	}
	if (n.type === "passivePick") {
		let e = t.players.length === 1;
		if (t.phase !== "passive" || !e && r.by === G(t)) return { code: B.notYourTurn };
		if (t.soloTie) return { code: B.tiePending };
		let i = t.passive[r.by];
		if (!i || i.picked) return { code: B.notYourTurn };
		if (t.pending[r.by].length > 0) return { code: B.resolveBonus };
		let a = t.dice.find((e) => e.color === n.die);
		if (!a) return { code: B.badDie };
		if (a.loc === "field") {
			if (t.dice.some((e) => e.loc === "platter" && be(t, r.by, e))) return { code: B.badDie };
		} else if (a.loc !== "platter") return { code: B.badDie };
		let o = ge(t.sheets[r.by], t.dice, n.die, n.area, n.cell);
		if (!o) return { code: B.badCell };
		let s = structuredClone(t), c = [];
		return ve(s.sheets[r.by], s.pending[r.by], o, "passive", c, r.by), s.passive[r.by].picked = !0, H(s.sheets[r.by], s.pending[r.by]), {
			state: s,
			fx: c
		};
	}
	if (n.type === "passiveDone") {
		let e = t.players.length === 1;
		if (t.phase !== "passive" || !e && r.by === G(t)) return { code: B.notYourTurn };
		if (t.soloTie) return { code: B.tiePending };
		let n = t.passive[r.by];
		if (!n || n.done) return { code: B.notYourTurn };
		if (t.pending[r.by].length > 0) return { code: B.resolveBonus };
		if (!n.picked && t.dice.some((e) => (e.loc === "platter" || e.loc === "field") && be(t, r.by, e))) return { code: B.mustPick };
		let i = structuredClone(t);
		return i.passive[r.by].done = !0, Object.values(i.passive).every((e) => e.done) && xe(i), {
			state: i,
			fx: []
		};
	}
	if (n.type === "extraDie") {
		let e = t.players.length === 1, i = t.phase === "active" && t.stage === "extra" && r.by === G(t), a = t.phase === "passive" && (e || r.by !== G(t)) && t.passive[r.by] && !t.passive[r.by].done, o = t.phase === "finalExtra" && !t.finalDone[r.by];
		if (!i && !a && !o) return { code: B.notYourTurn };
		if (t.soloTie) return { code: B.tiePending };
		if (t.pending[r.by].length > 0) return { code: B.resolveBonus };
		let s = t.sheets[r.by];
		if (s.extra.unlocked <= s.extra.used) return { code: B.noExtra };
		if ((t.extraUsed[r.by] ?? []).includes(n.die)) return { code: B.badDie };
		let c = t.dice.find((e) => e.color === n.die);
		if (!c || c.value === 0) return { code: B.badDie };
		let l = ge(s, t.dice, n.die, n.area, n.cell);
		if (!l) return { code: B.badCell };
		let u = structuredClone(t), ee = [];
		return u.sheets[r.by].extra.used += 1, ve(u.sheets[r.by], u.pending[r.by], l, "extra", ee, r.by), (u.extraUsed[r.by] ??= []).push(n.die), H(u.sheets[r.by], u.pending[r.by]), {
			state: u,
			fx: ee
		};
	}
	if (n.type === "finalDone") {
		if (t.phase !== "finalExtra" || t.finalDone[r.by]) return { code: B.notYourTurn };
		if (t.pending[r.by].length > 0) return { code: B.resolveBonus };
		let e = structuredClone(t);
		return e.finalDone[r.by] = !0, e.players.every((t) => e.finalDone[t]) && (e.phase = "done"), {
			state: e,
			fx: []
		};
	}
	return { code: B.notYourTurn };
}
function Ce(e) {
	return {
		public: {
			players: e.players,
			round: e.round,
			roundTotal: e.roundTotal,
			phase: e.phase,
			stage: e.stage,
			active: G(e),
			dice: e.dice.map((e) => ({ ...e })),
			picks: e.picks,
			sheets: e.sheets,
			pending: e.pending,
			extraUsed: e.extraUsed,
			passive: e.passive,
			soloTie: e.soloTie,
			round4Waiting: e.phase === "roundBonus" ? e.players.filter((t) => !e.round4[t]) : [],
			finalWaiting: e.phase === "finalExtra" ? e.players.filter((t) => !e.finalDone[t]) : []
		},
		private: {}
	};
}
function we(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = z(e.sheets[n]);
	let n = [...e.players].sort((n, r) => {
		let i = t[n], a = t[r];
		return a.total === i.total ? a.best === i.best ? e.players.indexOf(n) - e.players.indexOf(r) : a.best - i.best : a.total - i.total;
	}), r = t[n[0]], i = n.filter((e) => t[e].total === r.total && t[e].best === r.best), a = {};
	for (let n of e.players) a[n] = t[n].total;
	return {
		phase: "done",
		winner: i,
		ranking: n,
		scores: a
	};
}
var Te = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: y,
	schemas: {
		action: S,
		publicView: ae,
		privateView: w
	},
	setup: he,
	reduce: Se,
	viewFor: Ce,
	status: we
}, Ee = 1048, De = 1501, Oe = [
	{
		x: 43,
		y: 36,
		w: 114,
		h: 122
	},
	{
		x: 43,
		y: 190,
		w: 114,
		h: 125
	},
	{
		x: 43,
		y: 349,
		w: 114,
		h: 124
	}
], ke = {
	x: 189,
	y: 23,
	w: 100,
	h: 142,
	pitch: 134.8,
	count: 6
}, Ae = {
	reroll: {
		x: 315,
		y: 219,
		w: 66,
		h: 69,
		pitch: 93.83,
		count: 7
	},
	extra: {
		x: 315,
		y: 379,
		w: 66,
		h: 69,
		pitch: 93.83,
		count: 7
	}
}, je = 56, Me = 527, Ne = 87.67, Pe = 83.67, Fe = 65, Ie = 65;
function K(e) {
	return {
		x: je + e % 4 * Ne,
		y: Me + Math.floor(e / 4) * Pe,
		w: Fe,
		h: Ie
	};
}
var Le = 548, Re = 92.67, ze = [
	628,
	713,
	798
], Be = 67, Ve = 67;
function q(e) {
	let t = e + 2, n = t <= 4 ? 0 : t <= 8 ? 1 : 2;
	return {
		x: Le + (t <= 4 ? t - 1 : t <= 8 ? t - 5 : t - 9) * Re,
		y: ze[n],
		w: Be,
		h: Ve
	};
}
var J = {
	x: 138,
	y: 1045,
	w: 66,
	h: 66,
	pitch: 77.9,
	count: 11
}, He = {
	x: 134,
	y: 1189,
	w: 66,
	h: 66,
	pitch: 78.3,
	count: 11
}, Ue = {
	x: 134,
	y: 1328,
	w: 65,
	h: 69,
	pitch: 78.2,
	count: 11
}, Y = {
	yellow: "#facc15",
	blue: "#3b82f6",
	green: "#22c55e",
	orange: "#f97316",
	purple: "#a855f7",
	white: "#ffffff"
}, We = {
	1: [[.5, .5]],
	2: [[.28, .28], [.72, .72]],
	3: [
		[.25, .25],
		[.5, .5],
		[.75, .75]
	],
	4: [
		[.28, .28],
		[.72, .28],
		[.28, .72],
		[.72, .72]
	],
	5: [
		[.25, .25],
		[.75, .25],
		[.5, .5],
		[.25, .75],
		[.75, .75]
	],
	6: [
		[.3, .25],
		[.7, .25],
		[.3, .5],
		[.7, .5],
		[.3, .75],
		[.7, .75]
	]
};
function Ge({ x: e, y: t, size: n, color: r, value: i }) {
	let a = r === "white" || r === "yellow" ? "var(--color-ink)" : "#ffffff";
	return /* @__PURE__ */ h("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ m("rect", {
			x: e,
			y: t,
			width: n,
			height: n,
			rx: n * .18,
			fill: Y[r],
			stroke: "var(--color-ink)",
			strokeWidth: n * .05
		}), i > 0 && We[i].map(([r, i], o) => /* @__PURE__ */ m("circle", {
			cx: e + r * n,
			cy: t + i * n,
			r: n * .09,
			fill: a
		}, o))]
	});
}
function Ke({ sheet: e, round: t, roundTotal: n, fieldDice: r, eligible: i, onTapEligible: a, readOnly: o, fitKey: s }) {
	return /* @__PURE__ */ h(p, {
		image: "games/clever/sheet.webp",
		sheetW: Ee,
		sheetH: De,
		eligible: i,
		onTapEligible: a,
		readOnly: o,
		fitKey: s,
		children: [
			Array.from({ length: n }, (e, n) => {
				let r = c(ke, n);
				return n < t - 1 ? /* @__PURE__ */ m(d, {
					mark: "x",
					rect: r,
					strokeWidth: 10,
					inset: .14
				}, `rd${n}`) : n === t - 1 ? /* @__PURE__ */ m("rect", {
					x: r.x - 6,
					y: r.y - 6,
					width: r.w + 12,
					height: r.h + 12,
					rx: 18,
					fill: "#fbbf24",
					fillOpacity: .35,
					stroke: "var(--color-ink)",
					strokeWidth: 3,
					pointerEvents: "none"
				}, `rd${n}`) : null;
			}),
			["reroll", "extra"].map((t) => Array.from({ length: e[t].unlocked }, (n, r) => {
				let i = c(Ae[t], r);
				return r < e[t].used ? /* @__PURE__ */ m(d, {
					mark: "x",
					rect: i,
					strokeWidth: 8,
					inset: .14
				}, `${t}${r}`) : /* @__PURE__ */ m(d, {
					mark: "circle",
					rect: i,
					strokeWidth: 7,
					inset: .06
				}, `${t}${r}`);
			})),
			r.slice(0, Oe.length).map((e, t) => {
				let n = Oe[t], r = Math.min(n.w, n.h) * .62;
				return /* @__PURE__ */ m(Ge, {
					x: n.x + (n.w - r) / 2,
					y: n.y + (n.h - r) / 2,
					size: r,
					color: e.color,
					value: e.value
				}, `slot${t}`);
			}),
			e.yellow.map((e, t) => e && E[t / 4 | 0][t % 4] !== 0 ? /* @__PURE__ */ m(d, {
				mark: "x",
				rect: K(t),
				strokeWidth: 8,
				inset: .16
			}, `y${t}`) : null),
			e.blue.map((e, t) => e ? /* @__PURE__ */ m(d, {
				mark: "x",
				rect: q(t),
				strokeWidth: 8,
				inset: .16
			}, `b${t}`) : null),
			Array.from({ length: e.green }, (e, t) => /* @__PURE__ */ m(d, {
				mark: "x",
				rect: c(J, t),
				strokeWidth: 8,
				inset: .16
			}, `g${t}`)),
			e.orange.map((e, t) => e === null ? null : /* @__PURE__ */ m(te, {
				r: c(He, t),
				text: String(e)
			}, `o${t}`)),
			e.purple.map((e, t) => e === null ? null : /* @__PURE__ */ m(te, {
				r: c(Ue, t),
				text: String(e)
			}, `p${t}`)),
			e.yellow.map((e, t) => /* @__PURE__ */ m(f, {
				name: `cell:yellow:${t}`,
				r: K(t)
			}, `fy${t}`)),
			e.blue.map((e, t) => /* @__PURE__ */ m(f, {
				name: `cell:blue:${t}`,
				r: q(t)
			}, `fb${t}`)),
			Array.from({ length: 11 }, (e, t) => /* @__PURE__ */ m(f, {
				name: `cell:green:${t}`,
				r: c(J, t)
			}, `fg${t}`)),
			Array.from({ length: 11 }, (e, t) => /* @__PURE__ */ m(f, {
				name: `cell:orange:${t}`,
				r: c(He, t)
			}, `fo${t}`)),
			Array.from({ length: 11 }, (e, t) => /* @__PURE__ */ m(f, {
				name: `cell:purple:${t}`,
				r: c(Ue, t)
			}, `fp${t}`))
		]
	});
}
//#endregion
//#region src/games/clever/view-player.tsx
var qe = {
	yellow: "games.clever.area.yellow",
	blue: "games.clever.area.blue",
	green: "games.clever.area.green",
	orange: "games.clever.area.orange",
	purple: "games.clever.area.purple"
}, Je = {
	...qe,
	white: "games.clever.die.white"
};
function Ye() {
	let e = i(null), [t, r] = a("");
	return n(() => {
		let t = e.current;
		if (!t) return;
		let n = !0, i = new ResizeObserver(([e]) => {
			let t = Math.round(e.contentRect.width), i = Math.round(e.contentRect.height);
			if (!t || !i) return;
			let a = `${t}x${i}`;
			queueMicrotask(() => {
				n && r((e) => e === a ? e : a);
			});
		});
		return i.observe(t), () => {
			n = !1, i.disconnect();
		};
	}, []), [e, t];
}
var Xe = {
	1: [[.5, .5]],
	2: [[.28, .28], [.72, .72]],
	3: [
		[.25, .25],
		[.5, .5],
		[.75, .75]
	],
	4: [
		[.28, .28],
		[.72, .28],
		[.28, .72],
		[.72, .72]
	],
	5: [
		[.25, .25],
		[.75, .25],
		[.5, .5],
		[.25, .75],
		[.75, .75]
	],
	6: [
		[.3, .25],
		[.7, .25],
		[.3, .5],
		[.7, .5],
		[.3, .75],
		[.7, .75]
	]
};
function Ze({ color: e, value: t, selected: n, dim: r, onTap: i, label: a }) {
	let { ref: s } = o(`die:${e}`), c = e === "white" || e === "yellow" ? "var(--color-ink)" : "#ffffff", l = /* @__PURE__ */ h("svg", {
		viewBox: "0 0 48 48",
		role: "img",
		className: "clv-die",
		children: [
			/* @__PURE__ */ m("rect", {
				x: 2,
				y: 2,
				width: 44,
				height: 44,
				rx: 10,
				fill: Y[e],
				stroke: "var(--color-ink)",
				strokeWidth: 2.5
			}),
			t > 0 && Xe[t].map(([e, t], n) => /* @__PURE__ */ m("circle", {
				cx: e * 48,
				cy: t * 48,
				r: 4.6,
				fill: c
			}, n)),
			t === 0 && /* @__PURE__ */ m("circle", {
				cx: 24,
				cy: 24,
				r: 5,
				fill: c,
				opacity: .35
			})
		]
	});
	return /* @__PURE__ */ m("span", {
		ref: s,
		className: "inline-flex shrink-0",
		children: i ? /* @__PURE__ */ m("button", {
			type: "button",
			"aria-label": a,
			onClick: i,
			className: `shrink-0 cursor-pointer rounded-xl transition-transform ${n ? "scale-110 ring-4 ring-sky-400" : ""} ${r ? "opacity-35" : ""}`,
			children: l
		}) : /* @__PURE__ */ m("span", {
			className: `shrink-0 ${r ? "opacity-35" : ""}`,
			"aria-hidden": !0,
			children: l
		})
	});
}
function Qe(e) {
	let t = e.public;
	return /* @__PURE__ */ m($e, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function $e({ pub: e, members: t, myRid: n, send: i }) {
	let o = s(), [d, f] = Ye(), te = (e) => t.find((t) => t.rid === e)?.name ?? e, [p, re] = a(n), [g, _] = a(null), v = e.sheets[n], b = e.sheets[p] ?? v, x = e.pending[n] ?? [], S = e.active === n, C = e.passive[n], ie = e.extraUsed[n] ?? [], ae = v.extra.unlocked > v.extra.used, w = `${e.phase}:${e.stage}:${e.active}:${x.length}:${C?.picked ?? ""}`, [E, oe] = a(w);
	E !== w && (oe(w), _(null));
	let D = (t) => t === "blue" ? e.dice.find((e) => e.color === "white")?.value ?? 0 : t === "white" ? e.dice.find((e) => e.color === "blue")?.value ?? 0 : 0, O = e.phase === "active" && S ? e.stage === "pick" ? "pick" : e.stage === "extra" ? "extraDie" : null : e.phase === "passive" && C && !C.done ? C.picked ? "extraDie" : "passivePick" : e.phase === "finalExtra" && e.finalWaiting.includes(n) ? "extraDie" : null, se = x.length > 0 || e.soloTie !== null, k = (t) => {
		if (se || !O) return !1;
		let n = e.dice.find((e) => e.color === t);
		if (!n || n.value === 0) return !1;
		if (O === "pick") return n.loc === "pool";
		if (O === "passivePick") {
			if (n.loc === "platter") return !0;
			let t = e.dice.some((e) => e.loc === "platter" && L(v, e.color, e.value, D(e.color)).length > 0);
			return n.loc === "field" && !t;
		}
		return ae && !ie.includes(t);
	}, ce = (t) => {
		let n = e.dice.find((e) => e.color === t);
		return !n || n.value === 0 ? [] : L(v, t, n.value, D(t));
	}, A = e.dice.filter((e) => e.loc === "pool"), le = A.length > 0 && A.every((e) => e.value === 0 || L(v, e.color, e.value, D(e.color)).length === 0), ue = (e, t = v) => e === "green" ? t.green : P(e === "orange" ? t.orange : t.purple), de = (e) => {
		let t = e.cell ?? ue(e.area), n = e.area === "yellow" ? K(t) : e.area === "blue" ? q(t) : e.area === "green" ? c(J, t) : e.area === "orange" ? c(He, t) : c(Ue, t);
		return {
			key: `${e.area}:${t}`,
			rect: n
		};
	}, j = r(() => p !== n || !g ? [] : g.mode === "pick" ? ce(g.die).map(de) : g.area === "yellow" ? v.yellow.flatMap((e, t) => e ? [] : [{
		key: `yellow:${t}`,
		rect: K(t)
	}]) : g.area === "blue" ? v.blue.flatMap((e, t) => e ? [] : [{
		key: `blue:${t}`,
		rect: q(t)
	}]) : v.green < 11 ? [{
		key: `green:${v.green}`,
		rect: c(J, v.green)
	}] : [], [
		p,
		n,
		g,
		v,
		e.dice
	]), fe = (e) => {
		if (p !== n || !g) return;
		if (g.mode === "pick") {
			let t = ce(g.die).find((t) => `${t.area}:${t.cell ?? ue(t.area)}` === e);
			t && O && (i({
				type: O,
				die: g.die,
				area: t.area,
				cell: t.cell
			}), _(null));
			return;
		}
		let [t, r] = e.split(":");
		i(t === "green" ? {
			type: "bonusX",
			area: "green"
		} : {
			type: "bonusX",
			area: t,
			cell: Number(r)
		}), _(null);
	}, M = "info", N = "";
	if (x.length > 0) M = "warn", N = o(x[0].kind === "sixAny" ? "games.clever.bonusSixPrompt" : "games.clever.bonusXPrompt");
	else if (e.phase === "roundBonus") {
		let t = e.round4Waiting.includes(n);
		M = t ? "accent" : "info", N = o(t ? "games.clever.round4Prompt" : "games.clever.waitingRound4");
	} else if (e.phase === "active") S ? (M = "accent", N = o(e.stage === "roll" ? "games.clever.rollPrompt" : e.stage === "pick" ? "games.clever.pickPrompt" : "games.clever.extraPrompt")) : N = o("games.clever.waitingActive", { name: te(e.active) });
	else if (e.phase === "passive") e.soloTie ? (M = "accent", N = o("games.clever.tiePrompt", { n: e.soloTie.need })) : C && !C.done ? (M = "accent", N = o(C.picked ? "games.clever.passiveExtraPrompt" : "games.clever.passivePrompt")) : N = o("games.clever.waitingPassive");
	else if (e.phase === "finalExtra") {
		let t = e.finalWaiting.includes(n);
		M = t ? "accent" : "info", N = o(t ? "games.clever.finalPrompt" : "games.clever.waitingFinal");
	}
	let F = v.reroll.unlocked - v.reroll.used, I = e.dice.some((e) => (e.loc === "platter" || e.loc === "field") && e.value > 0 && L(v, e.color, e.value, D(e.color)).length > 0), R = x[0];
	return /* @__PURE__ */ m(l, {
		adaptive: !0,
		scroll: !1,
		className: "clv-screen",
		children: /* @__PURE__ */ h("div", {
			className: "clv-table",
			children: [/* @__PURE__ */ m("div", {
				ref: d,
				className: "frame clv-paper",
				children: /* @__PURE__ */ m(Ke, {
					sheet: b,
					round: e.round,
					roundTotal: e.roundTotal,
					fieldDice: e.phase === "done" ? [] : e.dice.filter((e) => e.loc === "field"),
					eligible: j.length > 0 ? j : void 0,
					onTapEligible: fe,
					readOnly: p !== n,
					fitKey: `${p}:${f}`
				})
			}), /* @__PURE__ */ h("aside", {
				className: "clv-sidebar",
				children: [/* @__PURE__ */ h("div", {
					className: "clv-header",
					children: [/* @__PURE__ */ m(u, {
						tone: M,
						text: N,
						chip: o("games.clever.roundShort", {
							n: e.round,
							total: e.roundTotal
						}),
						accent: y.accent
					}), /* @__PURE__ */ m(ee, {
						variant: "plate",
						members: t.filter((t) => e.players.includes(t.rid)),
						myRid: n,
						anchorOf: (e) => `seat:${e}`,
						onPick: (e) => {
							re(e), _(null);
						},
						picked: (e) => e === p,
						action: (t) => e.phase === "active" ? t === e.active ? "pending" : null : e.phase === "passive" ? t === e.active ? null : e.passive[t]?.done ?? !1 ? "done" : "pending" : e.phase === "roundBonus" ? e.round4Waiting.includes(t) ? "pending" : "done" : e.phase === "finalExtra" ? e.finalWaiting.includes(t) ? "pending" : "done" : null,
						status: (t) => {
							let n = e.sheets[t];
							return n ? /* @__PURE__ */ h("span", {
								className: "flex items-center gap-1.5 font-mono tabular-nums",
								children: [/* @__PURE__ */ m("span", {
									className: "clv-total font-black",
									children: z(n).total
								}), n.foxes > 0 && /* @__PURE__ */ h("span", {
									className: "clv-fox font-bold",
									children: ["🦊", n.foxes]
								})]
							}) : null;
						}
					})]
				}), /* @__PURE__ */ h("div", {
					className: "clv-controls",
					children: [/* @__PURE__ */ h("div", {
						className: "clv-context",
						children: [
							e.soloTie && e.soloTie.candidates.map((t) => /* @__PURE__ */ m(Ze, {
								color: t,
								value: e.dice.find((e) => e.color === t)?.value ?? 0,
								onTap: () => i({
									type: "tiePick",
									die: t
								}),
								label: o("games.clever.dieAria", {
									color: o(Je[t]),
									n: e.dice.find((e) => e.color === t)?.value ?? 0
								})
							}, t)),
							!e.soloTie && R?.kind === "sixAny" && ["orange", "purple"].map((e) => /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => i({
									type: "bonusSix",
									area: e
								}),
								className: "btn-base min-h-11 px-3 text-sm font-black text-white",
								style: { background: Y[e] },
								children: [o(qe[e]), " 6"]
							}, e)),
							!e.soloTie && R && R.kind !== "sixAny" && (R.kind === "xAny" ? [
								"yellow",
								"blue",
								"green"
							] : [R.area]).map((e) => /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => _(g?.mode === "bonusX" && g.area === e ? null : {
									mode: "bonusX",
									area: e
								}),
								className: `btn-base min-h-11 px-3 text-sm font-black text-white ${g?.mode === "bonusX" && g.area === e ? "ring-4 ring-sky-400" : ""}`,
								style: { background: Y[e] },
								children: [o(qe[e]), " ✕"]
							}, e)),
							!e.soloTie && !R && T.map((t) => {
								let n = e.dice.find((e) => e.color === t), r = n?.value ?? 0, i = k(t);
								return /* @__PURE__ */ m(Ze, {
									color: t,
									value: r,
									dim: n?.loc === "field",
									selected: g?.mode === "pick" && g.die === t,
									onTap: i ? () => _(g?.mode === "pick" && g.die === t ? null : {
										mode: "pick",
										die: t
									}) : void 0,
									label: o("games.clever.dieAria", {
										color: o(Je[t]),
										n: r
									})
								}, t);
							})
						]
					}), /* @__PURE__ */ h("div", {
						className: "clv-actions",
						children: [
							g !== null && /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => _(null),
								className: "btn-quiet min-h-11 flex-1 text-sm font-bold",
								children: o("games.clever.cancel")
							}),
							g === null && e.phase === "roundBonus" && e.round4Waiting.includes(n) && /* @__PURE__ */ h(ne, { children: [/* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => i({
									type: "round4",
									choice: "x"
								}),
								className: "card min-h-12 flex-1 px-3 text-sm font-black",
								children: o("games.clever.round4X")
							}), /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => i({
									type: "round4",
									choice: "six"
								}),
								className: "card min-h-12 flex-1 px-3 text-sm font-black",
								children: o("games.clever.round4Six")
							})] }),
							g === null && e.phase === "active" && S && e.stage === "roll" && /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => i({ type: "roll" }),
								className: "btn-base min-h-12 flex-1 text-base font-black text-white",
								style: { background: y.accent },
								children: ["🎲 ", o("games.clever.roll")]
							}),
							g === null && e.phase === "active" && S && e.stage === "pick" && /* @__PURE__ */ h(ne, { children: [/* @__PURE__ */ h("button", {
								type: "button",
								disabled: F <= 0,
								onClick: () => i({ type: "reroll" }),
								className: "card min-h-12 flex-1 px-3 text-sm font-black disabled:opacity-40",
								children: ["↻ ", o("games.clever.reroll", { n: F })]
							}), le && /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => i({ type: "pass" }),
								className: "card min-h-12 flex-1 px-3 text-sm font-black",
								children: o("games.clever.pass")
							})] }),
							g === null && e.phase === "active" && S && e.stage === "extra" && /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => i({ type: "endTurn" }),
								className: "btn-base min-h-12 flex-1 text-base font-black text-white",
								style: { background: y.accent },
								children: o("games.clever.endTurn")
							}),
							g === null && e.phase === "passive" && C && !C.done && !e.soloTie && /* @__PURE__ */ m("button", {
								type: "button",
								disabled: !C.picked && I,
								onClick: () => i({ type: "passiveDone" }),
								className: "btn-base min-h-12 flex-1 text-base font-black text-white disabled:opacity-40",
								style: { background: y.accent },
								children: o("games.clever.done")
							}),
							g === null && e.phase === "finalExtra" && e.finalWaiting.includes(n) && /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => i({ type: "finalDone" }),
								className: "btn-base min-h-12 flex-1 text-base font-black text-white",
								style: { background: y.accent },
								children: o("games.clever.done")
							})
						]
					})]
				})]
			})]
		})
	});
}
//#endregion
//#region src/games/clever/bot.ts
function et(e, t) {
	return t === "blue" ? e.find((e) => e.color === "white")?.value ?? 0 : t === "white" ? e.find((e) => e.color === "blue")?.value ?? 0 : 0;
}
function X(e, t) {
	let n = structuredClone(e), r = z(n).total, i = 0, a = 0, o = R(n, t, t.area === "green" && t.written === 0).triggers;
	for (; o.length > 0;) {
		let e = o.shift();
		e.kind === "fox" ? (n.foxes += 1, i += 1) : e.kind === "reroll" || e.kind === "extra" ? i += 2 : e.kind === "x" ? e.area === "green" ? n.green < 11 && o.push(...R(n, {
			area: "green",
			written: 0
		}, !0).triggers) : (e.area === "yellow" ? F(n) : I(n)) || (a += 1) : P(e.area === "orange" ? n.orange : n.purple) < 11 && o.push(...R(n, {
			area: e.area,
			written: e.value
		}).triggers);
	}
	return z(n).total - r + i + a * 3;
}
function Z(e, t, n) {
	let r = [];
	for (let i of n) {
		let n = t.find((e) => e.color === i);
		if (n && n.value !== 0) for (let a of L(e, i, n.value, et(t, i))) r.push({
			die: i,
			p: a,
			score: X(e, a)
		});
	}
	return r.sort((e, t) => t.score - e.score);
}
function Q(e, t) {
	return {
		type: t,
		die: e.die,
		area: e.p.area,
		cell: e.p.cell
	};
}
function tt(e, t) {
	if (t === "green") return {
		type: "bonusX",
		area: "green"
	};
	if (t === "blue") {
		let t = null;
		for (let n = 0; n < 11; n += 1) {
			if (e.blue[n]) continue;
			let r = {
				die: "white",
				p: {
					area: "blue",
					cell: n,
					written: n + 2
				},
				score: X(e, {
					area: "blue",
					cell: n,
					written: n + 2
				})
			};
			(!t || r.score > t.score) && (t = r);
		}
		return {
			type: "bonusX",
			area: "blue",
			cell: t?.p.cell ?? 0
		};
	}
	let n = null;
	for (let t = 0; t < 16; t += 1) {
		if (e.yellow[t]) continue;
		let r = {
			die: "white",
			p: {
				area: "yellow",
				cell: t,
				written: 0
			},
			score: X(e, {
				area: "yellow",
				cell: t,
				written: 0
			})
		};
		(!n || r.score > n.score) && (n = r);
	}
	return {
		type: "bonusX",
		area: "yellow",
		cell: n?.p.cell ?? 0
	};
}
function nt(e, t) {
	return t === "green" ? e.green < 11 : t === "yellow" ? !F(e) : !I(e);
}
var rt = (e, t) => {
	let n = e.public, r = n.sheets[t.rid];
	if (!r || n.phase === "done") return null;
	let i = t.difficulty === "weak", a = (e) => e[Math.floor(Math.random() * e.length)];
	if (n.soloTie) {
		let e = n.soloTie.candidates;
		if (i) return { action: {
			type: "tiePick",
			die: a(e)
		} };
		let t = e[0], o = Infinity;
		for (let i of e) {
			let e = Z(r, n.dice, [i]), a = e.length > 0 ? e[0].score : 0;
			a < o && (o = a, t = i);
		}
		return { action: {
			type: "tiePick",
			die: t
		} };
	}
	let o = n.pending[t.rid]?.[0];
	if (o) {
		if (o.kind === "sixAny") {
			let e = P(r.orange), t = (e < 11 ? 6 * (e === 3 || e === 6 || e === 8 ? 2 : e === 10 ? 3 : 1) : 0) >= 12 || P(r.purple) >= 11 ? "orange" : "purple";
			return { action: {
				type: "bonusSix",
				area: i ? a(["orange", "purple"]) : t
			} };
		}
		let e = (o.kind === "xAny" ? [
			"yellow",
			"blue",
			"green"
		] : [o.area]).filter((e) => nt(r, e));
		if (e.length === 0) return null;
		if (i) return { action: tt(r, a(e)) };
		let t = null, n = -1;
		for (let i of e) {
			let e = tt(r, i), a = "cell" in e ? e.cell : void 0, o = X(r, i === "green" ? {
				area: "green",
				written: 0
			} : i === "yellow" ? {
				area: "yellow",
				cell: a,
				written: 0
			} : {
				area: "blue",
				cell: a,
				written: (a ?? 0) + 2
			});
			o > n && (n = o, t = e);
		}
		return { action: t ?? tt(r, e[0]) };
	}
	if (n.phase === "roundBonus") {
		if (!n.round4Waiting.includes(t.rid)) return null;
		let e = P(r.orange);
		return { action: {
			type: "round4",
			choice: i ? Math.random() < .5 ? "x" : "six" : (e < 11 ? 6 * (e === 3 || e === 6 || e === 8 ? 2 : e === 10 ? 3 : 1) : 0) >= 12 ? "six" : "x"
		} };
	}
	if (n.phase === "active" && n.active === t.rid) {
		if (n.stage === "roll") return { action: { type: "roll" } };
		if (n.stage === "pick") {
			let e = n.dice.filter((e) => e.loc === "pool").map((e) => e.color), t = Z(r, n.dice, e);
			if (t.length === 0) return r.reroll.unlocked > r.reroll.used ? { action: { type: "reroll" } } : { action: { type: "pass" } };
			if (i) return { action: Q(a(t), "pick") };
			let o = t[0], s = n.dice.find((e) => e.color === o.die)?.value ?? 0, c = n.dice.filter((e) => e.loc === "pool" && e.value < s), l = 0;
			for (let e of c) {
				let t = Z(r, n.dice, [e.color]);
				t.length > 0 && (l += Math.max(1, t[0].score * .4));
			}
			return o.score <= 1 && r.reroll.unlocked > r.reroll.used && e.length >= 3 ? { action: { type: "reroll" } } : { action: Q(o, "pick") };
		}
		let e = T.filter((e) => !(n.extraUsed[t.rid] ?? []).includes(e)), o = Z(r, n.dice, e);
		return r.extra.unlocked > r.extra.used && o.length > 0 && (i ? Math.random() < .5 : o[0].score >= 4) ? { action: Q(i ? a(o) : o[0], "extraDie") } : { action: { type: "endTurn" } };
	}
	if (n.phase === "passive") {
		let e = n.passive[t.rid];
		if (!e || e.done) return null;
		if (!e.picked) {
			let e = n.dice.filter((e) => e.loc === "platter").map((e) => e.color), t = Z(r, n.dice, e);
			if (t.length === 0) {
				let e = n.dice.filter((e) => e.loc === "field").map((e) => e.color);
				t = Z(r, n.dice, e);
			}
			return t.length === 0 ? { action: { type: "passiveDone" } } : { action: Q(i ? a(t) : t[0], "passivePick") };
		}
		let o = T.filter((e) => !(n.extraUsed[t.rid] ?? []).includes(e)), s = Z(r, n.dice, o);
		return r.extra.unlocked > r.extra.used && s.length > 0 && (i ? Math.random() < .4 : s[0].score >= 4) ? { action: Q(i ? a(s) : s[0], "extraDie") } : { action: { type: "passiveDone" } };
	}
	if (n.phase === "finalExtra" && n.finalWaiting.includes(t.rid)) {
		let e = T.filter((e) => !(n.extraUsed[t.rid] ?? []).includes(e)), o = Z(r, n.dice, e);
		return r.extra.unlocked > r.extra.used && o.length > 0 ? { action: Q(i ? a(o) : o[0], "extraDie") } : { action: { type: "finalDone" } };
	}
	return null;
}, $ = {
	yellow: "games.clever.area.yellow",
	blue: "games.clever.area.blue",
	green: "games.clever.area.green",
	orange: "games.clever.area.orange",
	purple: "games.clever.area.purple"
}, it = {
	...$,
	white: "games.clever.die.white"
}, at = (e, t, n) => {
	let r = (e) => ({
		die: n(it[e]),
		n: t.public.dice.find((t) => t.color === e)?.value ?? 0
	});
	switch (e.type) {
		case "roll": return n("games.clever.roll");
		case "reroll": return n("games.clever.hintReroll");
		case "pass": return n("games.clever.pass");
		case "endTurn": return n("games.clever.endTurn");
		case "passiveDone":
		case "finalDone": return n("games.clever.done");
		case "pick":
		case "passivePick": return e.area ? n("games.clever.hintPick", {
			...r(e.die),
			area: n($[e.area])
		}) : "";
		case "extraDie": return e.area ? n("games.clever.hintExtra", {
			...r(e.die),
			area: n($[e.area])
		}) : "";
		case "bonusX": return n("games.clever.hintBonusX", { area: n($[e.area]) });
		case "bonusSix": return n("games.clever.hintBonusSix", { area: n($[e.area]) });
		case "round4": return e.choice === "x" ? n("games.clever.round4X") : n("games.clever.round4Six");
		case "tiePick": return n("games.clever.hintTiePick", { die: n(it[e.die]) });
		default: return "";
	}
}, ot = {
	yellow: "黄",
	blue: "蓝",
	green: "绿",
	orange: "橙",
	purple: "紫",
	white: "白"
}, st = (e, t) => t === "blue" ? e.find((e) => e.color === "white")?.value ?? 0 : t === "white" ? e.find((e) => e.color === "blue")?.value ?? 0 : 0, ct = (e) => {
	let t = [];
	for (let n = 0; n < 4; n += 1) t.push(E[n].map((t, r) => {
		let i = e.yellow[n * 4 + r];
		return t === 0 ? i ? "■" : "□" : i ? `[${t}]` : `${t}`;
	}).join(" "));
	return t.join(" / ");
}, lt = (e) => [
	`  黄区(行主序格 0-15,□/数字=空格可填,■/[n]=已划): ${ct(e)}`,
	`  蓝区(蓝骰+白骰之和,格 = 和-2): ${e.blue.map((e, t) => e ? `[${t + 2}]` : `${t + 2}`).join(" ")}`,
	`  绿区(从左填,下一格要求 ≥${e.green < 11 ? k[e.green] : "已满"}): 已填 ${e.green}/11`,
	`  橙区(从左填,倍率 ${A.join(",")}): ${e.orange.map((e) => e ?? "·").join(" ")}`,
	`  紫区(从左填,必须大于前一格;前格是 6 则任意): ${e.purple.map((e) => e ?? "·").join(" ")}`,
	`  狐狸 ${e.foxes};重掷 ${e.reroll.used}/${e.reroll.unlocked};额外骰 ${e.extra.used}/${e.extra.unlocked}`
], ut = (e, t, n, r, i) => {
	let a = t.find((e) => e.color === n);
	if (!a || a.value === 0) return null;
	let o = L(e, n, a.value, st(t, n)).filter((e) => e.area === r);
	return o.length === 0 ? null : o.length === 1 ? o[0] : o.find((e) => e.cell === i) ?? null;
}, dt = {
	needsAction(e, t) {
		let n = e.public;
		if ((n.pending[t.rid]?.length ?? 0) > 0) return !0;
		if (n.phase === "roundBonus") return n.round4Waiting.includes(t.rid);
		if (n.phase === "active") return n.active === t.rid;
		if (n.phase === "passive") {
			if (n.soloTie) return n.active === t.rid;
			let e = n.passive[t.rid];
			return !!e && !e.done;
		}
		return n.phase === "finalExtra" && n.finalWaiting.includes(t.rid);
	},
	describeView(e, t) {
		let n = e.public, r = [`第 ${n.round}/${n.roundTotal} 轮。五区计分规则:黄=按格值划勾,满行/列有奖励;蓝=两颗骰之和划对应格,满行列有奖励;绿=从左填,每格有最小门槛;橙=从左填,值×格倍率;紫=从左填,必须递增(6 之后任意)。狐狸数=终局每个狐狸抵你最低分区得分。颜色用英文枚举值(yellow/blue/green/orange/purple/white)输出。`], i = n.dice.map((e) => `${e.color}(${ot[e.color]})=${e.value || "未掷"}[${e.loc === "pool" ? "可掷" : e.loc === "field" ? "骰位" : "托盘"}]`).join(" ");
		r.push(`骰子: ${i};本回合已选 ${n.picks}/3`);
		for (let e of n.players) r.push(`${e === t.rid ? "你的表" : `${e} 的表`}:`, ...lt(n.sheets[e]));
		let a = n.pending[t.rid] ?? [];
		if (a.length > 0) r.push(`你有待解奖励: ${a.map((e) => e.kind === "x" ? `在${ot[e.area]}区划一个叉(bonusX, area=${e.area})` : e.kind === "xAny" ? "在任意区划一个叉(bonusX)" : "黑6奖励:写一颗 6 进橙或紫区(bonusSix)").join(";")}。必须先解。`);
		else if (n.phase === "roundBonus" && n.round4Waiting.includes(t.rid)) r.push("第 4 轮开始奖励二选一,输出 round4:choice=x(划一个叉) 或 six(写一颗 6)。");
		else if (n.phase === "active" && n.active === t.rid) n.stage === "roll" ? r.push("轮到你,输出 roll 掷骰。") : n.stage === "pick" ? r.push("选一颗池里的骰子落格(pick),或 reroll(若还有重掷次数);池里骰全无可填才能 pass。") : r.push("额外骰阶段:可 extraDie 用一颗没用过的骰子落格(需有剩余额外骰次数),或 endTurn 结束回合。");
		else if (n.phase === "passive" && n.soloTie && n.active === t.rid) r.push(`并列裁决:从 ${n.soloTie.candidates.join(", ")} 里选 ${n.soloTie.need} 颗上托盘,输出 tiePick(一次一颗)。`);
		else if (n.phase === "passive") {
			let e = n.passive[t.rid];
			e && !e.done && r.push(`被动阶段:可从托盘(或在托盘全不可用时从骰位)选一颗落格 passivePick${e.picked ? "(已选过,可被动额外骰 extraDie 或 passiveDone)" : ""};都不可用则 passiveDone。`);
		} else n.phase === "finalExtra" && n.finalWaiting.includes(t.rid) && r.push("终局前:可用剩余额外骰(extraDie),完成后输出 finalDone。");
		return r.join("\n");
	},
	actionJsonSchema: { oneOf: [
		{
			type: "object",
			properties: { type: { const: "roll" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "reroll" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "pick" },
				die: { enum: [
					"yellow",
					"blue",
					"green",
					"orange",
					"purple",
					"white"
				] },
				area: { enum: [
					"yellow",
					"blue",
					"green",
					"orange",
					"purple"
				] },
				cell: {
					type: "integer",
					minimum: 0,
					maximum: 15,
					description: "黄/蓝区必填(蓝格=和-2)"
				}
			},
			required: [
				"type",
				"die",
				"area"
			],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "pass" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "extraDie" },
				die: { enum: [
					"yellow",
					"blue",
					"green",
					"orange",
					"purple",
					"white"
				] },
				area: { enum: [
					"yellow",
					"blue",
					"green",
					"orange",
					"purple"
				] },
				cell: {
					type: "integer",
					minimum: 0,
					maximum: 15
				}
			},
			required: [
				"type",
				"die",
				"area"
			],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "endTurn" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "passivePick" },
				die: { enum: [
					"yellow",
					"blue",
					"green",
					"orange",
					"purple",
					"white"
				] },
				area: { enum: [
					"yellow",
					"blue",
					"green",
					"orange",
					"purple"
				] },
				cell: {
					type: "integer",
					minimum: 0,
					maximum: 15
				}
			},
			required: [
				"type",
				"die",
				"area"
			],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "passiveDone" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "bonusX" },
				area: { enum: [
					"yellow",
					"blue",
					"green"
				] },
				cell: {
					type: "integer",
					minimum: 0,
					maximum: 15,
					description: "黄/蓝必填"
				}
			},
			required: ["type", "area"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "bonusSix" },
				area: { enum: ["orange", "purple"] }
			},
			required: ["type", "area"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "round4" },
				choice: { enum: ["x", "six"] }
			},
			required: ["type", "choice"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "tiePick" },
				die: { enum: [
					"yellow",
					"blue",
					"green",
					"orange",
					"purple",
					"white"
				] }
			},
			required: ["type", "die"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "finalDone" } },
			required: ["type"],
			additionalProperties: !1
		}
	] },
	parseAction(e, t, n) {
		let r = S.safeParse(e);
		if (!r.success) return null;
		let i = r.data, a = t.public, o = a.sheets[n.rid];
		if (!o) return null;
		let s = a.pending[n.rid] ?? [], c = a.phase === "active" && a.active === n.rid;
		if (i.type === "bonusX") {
			let e = s[0];
			return !e || e.kind === "sixAny" || e.kind === "x" && e.area !== i.area ? null : i.area === "green" ? o.green < 11 ? i : null : i.cell == null ? null : i.area === "yellow" ? o.yellow[i.cell] ? null : i : i.cell <= 10 && !o.blue[i.cell] ? i : null;
		}
		if (i.type === "bonusSix") return s[0]?.kind === "sixAny" && (i.area === "orange" ? o.orange : o.purple).some((e) => e === null) ? i : null;
		if (s.length > 0) return null;
		switch (i.type) {
			case "round4": return a.phase === "roundBonus" && a.round4Waiting.includes(n.rid) ? i : null;
			case "roll": return c && a.stage === "roll" && a.dice.some((e) => e.loc === "pool") ? i : null;
			case "reroll": return c && a.stage === "pick" && o.reroll.unlocked > o.reroll.used ? i : null;
			case "pick": {
				if (!c || a.stage !== "pick") return null;
				let e = a.dice.find((e) => e.color === i.die);
				return !e || e.loc !== "pool" ? null : ut(o, a.dice, i.die, i.area, i.cell) ? i : null;
			}
			case "pass": return !c || a.stage !== "pick" || a.dice.some((e) => e.loc === "pool" && L(o, e.color, e.value, st(a.dice, e.color)).length > 0) ? null : i;
			case "endTurn": return c && a.stage === "extra" ? i : null;
			case "extraDie": {
				let e = c && a.stage === "extra", t = a.phase === "passive" && a.passive[n.rid] && !a.passive[n.rid].done, r = a.phase === "finalExtra" && a.finalWaiting.includes(n.rid);
				return !e && !t && !r || o.extra.unlocked <= o.extra.used || (a.extraUsed[n.rid] ?? []).includes(i.die) ? null : ut(o, a.dice, i.die, i.area, i.cell) ? i : null;
			}
			case "tiePick": return a.phase === "passive" && a.soloTie?.candidates.includes(i.die) && a.active === n.rid ? i : null;
			case "passivePick": {
				let e = a.passive[n.rid];
				if (a.phase !== "passive" || a.soloTie || !e || e.picked) return null;
				let t = a.dice.find((e) => e.color === i.die);
				return !t || t.loc !== "platter" && t.loc !== "field" ? null : ut(o, a.dice, i.die, i.area, i.cell) ? i : null;
			}
			case "passiveDone": {
				let e = a.passive[n.rid];
				return a.phase === "passive" && !a.soloTie && e && !e.done ? i : null;
			}
			case "finalDone": return a.phase === "finalExtra" && a.finalWaiting.includes(n.rid) ? i : null;
		}
	}
}, ft = {
	yellow: "#facc15",
	blue: "#3b82f6",
	green: "#22c55e",
	orange: "#f97316",
	purple: "#a855f7"
};
function pt({ area: e, value: t, size: n = 28 }) {
	return /* @__PURE__ */ m("span", {
		className: `grid place-items-center rounded-md border-2 border-ink font-mono font-black shadow-[2px_2px_0_var(--color-ink)] ${e === "yellow" ? "text-ink" : "text-white"}`,
		style: {
			backgroundColor: ft[e],
			width: n,
			height: n,
			fontSize: n * .43
		},
		children: t > 0 ? t : "✕"
	});
}
var mt = {
	roll(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.dice)) return null;
		let r = n.dice.map((e) => typeof e.color == "string" ? t.anchor(`die:${e.color}`) : null).filter((e) => e !== null);
		return r.length === 0 ? null : {
			ms: 700,
			node: /* @__PURE__ */ m(ne, { children: r.map((e, t) => /* @__PURE__ */ m(_, {
				at: e,
				ms: 600,
				delay: t * 50
			}, t)) })
		};
	},
	enter(e, t) {
		let n = e.data;
		if (typeof n?.area != "string" || typeof n.cell != "number" || typeof n.value != "number") return null;
		let r = n.area, i = t.anchor(`cell:${r}:${n.cell}`), a = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return i && a ? {
			ms: 550,
			node: /* @__PURE__ */ m(g, {
				from: a,
				to: i,
				ms: 450,
				children: /* @__PURE__ */ m(pt, {
					area: r,
					value: n.value,
					size: Math.max(28, Math.min(i.w, i.h))
				})
			})
		} : i ? {
			ms: 600,
			node: /* @__PURE__ */ m(_, {
				at: i,
				ms: 600
			})
		} : a ? {
			ms: 700,
			node: /* @__PURE__ */ m(re, {
				at: a,
				ms: 700,
				children: /* @__PURE__ */ m(pt, {
					area: r,
					value: n.value
				})
			})
		} : null;
	},
	gain(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		if (!r || typeof n?.what != "string") return null;
		let i = n.what === "fox" ? "🦊" : n.what === "reroll" ? "↻" : "+🎲";
		return {
			ms: 800,
			node: /* @__PURE__ */ m(re, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ h("span", {
					className: "text-done-ink",
					children: ["+1 ", i]
				})
			})
		};
	}
}, ht = [
	"#facc15",
	"#3b82f6",
	"#22c55e",
	"#f97316",
	"#a855f7"
], gt = [
	"games.clever.rating.r0",
	"games.clever.rating.r1",
	"games.clever.rating.r2",
	"games.clever.rating.r3",
	"games.clever.rating.r4",
	"games.clever.rating.r5",
	"games.clever.rating.r6",
	"games.clever.rating.r7",
	"games.clever.rating.r8"
];
function _t({ public: e, rid: t }) {
	let n = s(), r = e, i = r.sheets[t];
	if (!i) return null;
	let a = z(i), o = [
		a.yellow,
		a.blue,
		a.green,
		a.orange,
		a.purple
	], c = Math.min(...o), l = r.players.length === 1;
	return /* @__PURE__ */ h("span", {
		className: "clv-over-details flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] font-bold",
		children: [
			o.map((e, t) => /* @__PURE__ */ h("span", {
				className: "flex items-center gap-0.5",
				children: [/* @__PURE__ */ m("span", {
					className: "inline-block size-2.5 rounded-sm border border-ink/60",
					style: { backgroundColor: ht[t] }
				}), /* @__PURE__ */ m("span", {
					className: "font-mono tabular-nums",
					children: e
				})]
			}, t)),
			/* @__PURE__ */ h("span", {
				className: "flex items-center gap-0.5",
				children: [/* @__PURE__ */ m("span", {
					"aria-hidden": !0,
					children: "🦊"
				}), /* @__PURE__ */ h("span", {
					className: "font-mono tabular-nums",
					children: [
						i.foxes,
						"×",
						c,
						"=",
						a.foxPts
					]
				})]
			}),
			l && /* @__PURE__ */ m("span", {
				className: "font-display text-xs font-extrabold",
				children: n(gt[pe(a.total)])
			})
		]
	});
}
//#endregion
//#region src/games/clever/game-over.tsx
function vt(e) {
	return /* @__PURE__ */ m("div", {
		className: "clv-over",
		children: /* @__PURE__ */ m(v, {
			hintCount: e.hintCount,
			result: e.result,
			members: e.members,
			myRid: e.myRid,
			accent: y.accent,
			onPlayAgain: e.onPlayAgain,
			onBackToLobby: e.onBackToLobby,
			renderRowExtra: (t) => /* @__PURE__ */ m(_t, {
				public: e.public,
				rid: t,
				myRid: e.myRid
			})
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/clever/entry.tsx
var yt = {
	definition: Te,
	View: Qe,
	bot: rt,
	describe: at,
	llm: dt,
	fx: mt,
	OverView: vt,
	RowView: _t,
	locales: {
		zh: {
			name: "绝顶聪明",
			desc: "六骰三选填表,连锁奖励滚雪球",
			rules: "目标:用六颗骰子在计分表五个色区填格,终局总分最高者获胜。\n准备:每人一张计分表;4 人打 4 轮、3 人 5 轮、2 人 6 轮。\n流程:\n· 主动玩家掷全部 6 颗骰子,从中选一颗填入色区,点数比它低的骰子进入托盘;再掷再选,至多选三颗,之后其余骰子也进托盘。\n· 其他玩家从托盘各选择1颗骰子，并在计分表中记录其点数;托盘里没有能用的,才可从主动玩家留下的骰位挑一颗。\n· 白色骰子为百搭骰，可以选择任意色区;选择蓝区时，填写蓝色骰子与白色骰子的点数之和。使用蓝色骰子时，必须将其与白色骰子的点数相加，并在蓝色区域记录结果。\n色区:\n· 黄区：在印有对应点数的格子中打叉。完成一列时，获得该列星标所示的分数，四列分别为10、14、16、20分。\n· 蓝区：在印有蓝色骰子与白色骰子点数之和的格子中打叉。根据已打叉的格子总数查表计分，最多获得56分。\n· 绿区：填入的点数不得低于该格的最低要求。分数随填写的格子数量递增，最多获得66分。\n· 橙区：直接填写骰子点数。印有倍数标记的格子，按所示的2倍或3倍计分。\n· 紫区：从左至右依次填写，每个数字必须大于前一个数字；前一个数字为6时，下一个数字不受大小限制。\n奖励：打叉或填写格子会触发计分表上的奖励，包括在任意色区打叉、在紫区或橙区填写6、获得狐狸、获得重掷机会，以及获得额外骰行动。奖励可以连锁触发。\n行动：重掷和额外骰各有7个行动格，通过轮次奖励及色区奖励解锁。\n· 重掷：主动玩家重新投掷全部待选骰子。\n· 额外骰：额外使用一颗骰子；每颗骰子在同一回合的额外骰行动中只能使用一次。\n轮次奖励：第一轮和第三轮开始时，各解锁一次重掷；第二轮开始时，解锁一次额外骰行动。第四轮开始时，所有玩家各选择在任意色区打一次叉，或在紫区或橙区填写一个6。\n结算:五区各自计分;每只狐狸获得的分数等于自己得分最低区域的分数。最后一轮结束后，每名玩家仍可使用剩余的额外骰行动。\n总分最高的玩家获胜。总分相同时，单个区域最高得分较高的玩家获胜；若仍然相同，则共享胜利。\n单人：共进行6轮。每轮先进行主动玩家回合，再进行被动玩家回合。被动玩家回合开始时，重新投掷全部6颗骰子，将点数最低的3颗骰子放入托盘；并列时，由你选择放入的骰子。\n从托盘中选择1颗骰子，并在计分表中记录其点数；此时不能使用重掷行动。终局根据评级表评价本局得分。",
			roundShort: "{{n}}/{{total}}",
			roll: "掷骰",
			rollPrompt: "轮到你:掷骰",
			pickPrompt: "选一颗骰子填表",
			extraPrompt: "可用额外骰,或结束回合",
			reroll: "重掷(剩 {{n}})",
			pass: "无可用,收骰",
			endTurn: "结束回合",
			done: "完成",
			passivePrompt: "从托盘捡一颗骰子",
			passiveExtraPrompt: "可用额外骰,或点完成",
			finalPrompt: "终局收尾:用掉剩余额外骰",
			waitingActive: "等 {{name}} 行动…",
			waitingPassive: "等其他人捡骰…",
			tiePrompt: "同点并列:选 {{n}} 颗上托盘",
			waitingRound4: "等所有人选择奖励…",
			waitingFinal: "等其他人收尾…",
			round4Prompt: "第 4 轮奖励:二选一",
			round4X: "任一色区打叉",
			round4Six: "紫/橙区填 6",
			bonusXPrompt: "奖励:选一区打叉",
			bonusSixPrompt: "奖励:紫或橙填 6",
			cancel: "取消",
			dieAria: "{{color}}骰 {{n}} 点",
			area: {
				yellow: "黄区",
				blue: "蓝区",
				green: "绿区",
				orange: "橙区",
				purple: "紫区"
			},
			die: { white: "百搭" },
			rating: {
				r0: "绝顶聪明!",
				r1: "爱因斯坦再世?",
				r2: "天才!",
				r3: "惊艳!",
				r4: "致敬!",
				r5: "出色的成绩!",
				r6: "相当不错",
				r7: "不错,还能更好",
				r8: "有待提高"
			},
			errNotYourTurn: "现在轮不到你",
			errBadDie: "这颗骰不能选",
			errBadCell: "这个格子不能填",
			errNoReroll: "没有可用的重掷",
			errNoExtra: "没有可用的额外骰",
			errResolveBonus: "先处理奖励",
			errTie: "先决定并列的骰子",
			errMustPick: "还有能用的骰子,必须选一颗",
			errOver: "本局已结束",
			hintReroll: "重掷全部骰子",
			hintPick: "拿{{die}}骰({{n}} 点)填{{area}}",
			hintExtra: "用额外骰:拿{{die}}骰({{n}} 点)填{{area}}",
			hintBonusX: "在{{area}}打叉",
			hintBonusSix: "在{{area}}填 6",
			hintTiePick: "把{{die}}骰送上托盘"
		},
		en: {
			name: "That's Pretty Clever!",
			desc: "Pick dice, mark your sheet, chain the bonuses",
			rules: "Goal: fill the five colored areas of your scoresheet with six dice; highest total at the end wins.\nSetup: one sheet per player; 4 rounds with 4 players, 5 with 3, 6 with 2.\nPlay:\n· The active player rolls all 6 dice, picks one and marks its area; every lower-valued die goes to the silver platter. Roll and pick again, up to three picks, then the rest go to the platter too.\n· Each other player then takes one die from the platter; only if none there is usable may they take one of the dice the active player left behind.\n· The white die is a joker: pick any area; for blue it scores as blue + white. The blue die only scores in blue, also as blue + white.\nAreas:\n· Yellow: cross off the printed number; complete a column for its star points (10/14/16/20).\n· Blue: cross off the blue+white sum; score by total crosses (up to 56).\n· Green: each entry must meet the cell minimum; points grow per cell (up to 66).\n· Orange: write the value as-is; cells with a multiplier mark score double or triple.\n· Purple: each entry must top the previous one; after a 6, anything goes.\nBonuses: marking cells triggers printed bonuses — a free cross, a 6 in purple/orange, foxes, rerolls and extra dice — and bonuses can chain.\nActions: rerolls (active player rerolls all remaining dice) and extra dice (use one more die, each die at most once per turn) have 7 slots each, unlocked by rounds and bonuses.\nRound bonuses: at the start of rounds 1 and 3, unlock one reroll. At the start of round 2, unlock one extra-die action. At the start of round 4, each player chooses either a free cross in any area or a 6 in purple or orange.\nScoring: each area scores separately; each fox scores your lowest area. After the last round everyone may spend leftover extra dice.\nHighest total wins; ties break on the best single area, then shared victory.\nSolo: 6 rounds; each round you play the active player first, then the passive player — reroll all 6 dice, the 3 lowest go to the platter (you break ties), take one of them, no rerolls.\nYour final score is rated on a scale.",
			roundShort: "{{n}}/{{total}}",
			roll: "Roll",
			rollPrompt: "Your turn: roll the dice",
			pickPrompt: "Pick a die to mark",
			extraPrompt: "Spend extra dice, or end your turn",
			reroll: "Reroll ({{n}} left)",
			pass: "Nothing fits — pass",
			endTurn: "End turn",
			done: "Done",
			passivePrompt: "Take one die from the platter",
			passiveExtraPrompt: "Spend extra dice, or tap Done",
			finalPrompt: "Final wrap-up: spend leftover extra dice",
			waitingActive: "Waiting for {{name}}…",
			waitingPassive: "Waiting for others to take dice…",
			tiePrompt: "Tied dice: pick {{n}} for the platter",
			waitingRound4: "Waiting for everyone to pick a bonus…",
			waitingFinal: "Waiting for others to wrap up…",
			round4Prompt: "Round 4 bonus: pick one",
			round4X: "Cross any area",
			round4Six: "Write 6 in purple/orange",
			bonusXPrompt: "Bonus: cross one area",
			bonusSixPrompt: "Bonus: write 6 in purple or orange",
			cancel: "Cancel",
			dieAria: "{{color}} die, {{n}}",
			area: {
				yellow: "Yellow",
				blue: "Blue",
				green: "Green",
				orange: "Orange",
				purple: "Purple"
			},
			die: { white: "White (joker)" },
			rating: {
				r0: "That's pretty clever!",
				r1: "Are you Albert Einstein?",
				r2: "What a genius!",
				r3: "Impressive!",
				r4: "Hats off!",
				r5: "Great result!",
				r6: "Pretty good",
				r7: "Not bad — room to improve",
				r8: "Needs work"
			},
			errNotYourTurn: "Not your turn",
			errBadDie: "That die is not available",
			errBadCell: "That cell is not legal",
			errNoReroll: "No rerolls left",
			errNoExtra: "No extra dice left",
			errResolveBonus: "Resolve your bonus first",
			errTie: "Resolve the tied dice first",
			errMustPick: "A usable die remains — you must take one",
			errOver: "This game is over",
			hintReroll: "Reroll all dice",
			hintPick: "Take the {{die}} die ({{n}}) into {{area}}",
			hintExtra: "Extra die: take the {{die}} die ({{n}}) into {{area}}",
			hintBonusX: "Cross off in {{area}}",
			hintBonusSix: "Write 6 in {{area}}",
			hintTiePick: "Send the {{die}} die to the platter"
		}
	}
};
//#endregion
export { yt as default };
