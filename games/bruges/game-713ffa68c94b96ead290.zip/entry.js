import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { gameAssetUrl as a } from "@bgparty/sdk/assets";
import { useT as o } from "@bgparty/sdk/i18n";
import { useWakeLock as s } from "@bgparty/sdk/use-wake-lock";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { Texture as l } from "@bgparty/sdk/texture";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { IconExpand as m } from "@bgparty/sdk/icons";
import { OptionSwitch as h } from "@bgparty/sdk/ui/game-options";
//#region src/games/bruges/data.ts
var g = [
	"blue",
	"brown",
	"yellow",
	"red",
	"purple"
], _ = [
	"nobles",
	"entertainers",
	"craftsmen",
	"clergy",
	"protectors",
	"scholars",
	"bureaucrats",
	"merchants",
	"court",
	"artists",
	"outcasts",
	"travelers"
], v = {
	y01: {
		id: "y01",
		color: "yellow",
		cost: 9,
		activation: "I",
		group: "clergy",
		effect: "workerVp",
		parameter: "brown,3",
		nameKey: "games.bruges.people.y01",
		textKey: "games.bruges.texts.y01"
	},
	y02: {
		id: "y02",
		color: "yellow",
		cost: 9,
		activation: "I",
		group: "entertainers",
		effect: "activateAll",
		parameter: "",
		nameKey: "games.bruges.people.y02",
		textKey: "games.bruges.texts.y02"
	},
	y03: {
		id: "y03",
		color: "yellow",
		cost: 3,
		activation: "brown",
		group: "bureaucrats",
		effect: "moneyHouse",
		parameter: "brown",
		nameKey: "games.bruges.people.y03",
		textKey: "games.bruges.texts.y03"
	},
	y04: {
		id: "y04",
		color: "yellow",
		cost: 6,
		activation: "I",
		group: "outcasts",
		effect: "attackCanal",
		parameter: "",
		nameKey: "games.bruges.people.y04",
		textKey: "games.bruges.texts.y04"
	},
	y05: {
		id: "y05",
		color: "yellow",
		cost: 3,
		activation: "red",
		group: "scholars",
		effect: "moneyGroup",
		parameter: "scholars",
		nameKey: "games.bruges.people.y05",
		textKey: "games.bruges.texts.y05"
	},
	y06: {
		id: "y06",
		color: "yellow",
		cost: 6,
		activation: "yellow",
		group: "outcasts",
		effect: "attackThreat",
		parameter: "yellow",
		nameKey: "games.bruges.people.y06",
		textKey: "games.bruges.texts.y06"
	},
	y07: {
		id: "y07",
		color: "yellow",
		cost: 3,
		activation: "brown",
		group: "entertainers",
		effect: "canalDouble",
		parameter: "",
		nameKey: "games.bruges.people.y07",
		textKey: "games.bruges.texts.y07"
	},
	y08: {
		id: "y08",
		color: "yellow",
		cost: 9,
		activation: "purple",
		group: "nobles",
		effect: "drawPlay",
		parameter: "",
		nameKey: "games.bruges.people.y08",
		textKey: "games.bruges.texts.y08"
	},
	y09: {
		id: "y09",
		color: "yellow",
		cost: 12,
		activation: "P",
		group: "scholars",
		effect: "personDiscount",
		parameter: "3",
		nameKey: "games.bruges.people.y09",
		textKey: "games.bruges.texts.y09"
	},
	y10: {
		id: "y10",
		color: "yellow",
		cost: 6,
		activation: "I",
		group: "artists",
		effect: "advance",
		parameter: "1",
		nameKey: "games.bruges.people.y10",
		textKey: "games.bruges.texts.y10"
	},
	y11: {
		id: "y11",
		color: "yellow",
		cost: 0,
		activation: "I",
		group: "clergy",
		effect: "workerMoney",
		parameter: "blue,3",
		nameKey: "games.bruges.people.y11",
		textKey: "games.bruges.texts.y11"
	},
	y12: {
		id: "y12",
		color: "yellow",
		cost: 9,
		activation: "E",
		group: "court",
		effect: "endGroup",
		parameter: "court,2",
		nameKey: "games.bruges.people.y12",
		textKey: "games.bruges.texts.y12"
	},
	y13: {
		id: "y13",
		color: "yellow",
		cost: 3,
		activation: "P",
		group: "merchants",
		effect: "moneyDieBonus",
		parameter: "yellow,3",
		nameKey: "games.bruges.people.y13",
		textKey: "games.bruges.texts.y13"
	},
	y14: {
		id: "y14",
		color: "yellow",
		cost: 6,
		activation: "purple",
		group: "artists",
		effect: "vpGroup",
		parameter: "protectors",
		nameKey: "games.bruges.people.y14",
		textKey: "games.bruges.texts.y14"
	},
	y15: {
		id: "y15",
		color: "yellow",
		cost: 6,
		activation: "brown",
		group: "artists",
		effect: "vpGroup",
		parameter: "craftsmen",
		nameKey: "games.bruges.people.y15",
		textKey: "games.bruges.texts.y15"
	},
	y16: {
		id: "y16",
		color: "yellow",
		cost: 3,
		activation: "purple",
		group: "bureaucrats",
		effect: "moneyGroup",
		parameter: "bureaucrats",
		nameKey: "games.bruges.people.y16",
		textKey: "games.bruges.texts.y16"
	},
	y17: {
		id: "y17",
		color: "yellow",
		cost: 3,
		activation: "red",
		group: "court",
		effect: "draw",
		parameter: "1",
		nameKey: "games.bruges.people.y17",
		textKey: "games.bruges.texts.y17"
	},
	y18: {
		id: "y18",
		color: "yellow",
		cost: 9,
		activation: "E",
		group: "protectors",
		effect: "endThreat",
		parameter: "1",
		nameKey: "games.bruges.people.y18",
		textKey: "games.bruges.texts.y18"
	},
	y19: {
		id: "y19",
		color: "yellow",
		cost: 0,
		activation: "P",
		group: "entertainers",
		effect: "diceWorker",
		parameter: "yellow",
		nameKey: "games.bruges.people.y19",
		textKey: "games.bruges.texts.y19"
	},
	y20: {
		id: "y20",
		color: "yellow",
		cost: 3,
		activation: "I",
		group: "scholars",
		effect: "buyWorkers",
		parameter: "5",
		nameKey: "games.bruges.people.y20",
		textKey: "games.bruges.texts.y20"
	},
	y21: {
		id: "y21",
		color: "yellow",
		cost: 3,
		activation: "brown",
		group: "merchants",
		effect: "money",
		parameter: "3",
		nameKey: "games.bruges.people.y21",
		textKey: "games.bruges.texts.y21"
	},
	y22: {
		id: "y22",
		color: "yellow",
		cost: 3,
		activation: "red",
		group: "craftsmen",
		effect: "exchangeWorkers",
		parameter: "",
		nameKey: "games.bruges.people.y22",
		textKey: "games.bruges.texts.y22"
	},
	y23: {
		id: "y23",
		color: "yellow",
		cost: 3,
		activation: "red",
		group: "court",
		effect: "playExtra",
		parameter: "",
		nameKey: "games.bruges.people.y23",
		textKey: "games.bruges.texts.y23"
	},
	y24: {
		id: "y24",
		color: "yellow",
		cost: 9,
		activation: "red",
		group: "nobles",
		effect: "vpMoney",
		parameter: "1,2",
		nameKey: "games.bruges.people.y24",
		textKey: "games.bruges.texts.y24"
	},
	y25: {
		id: "y25",
		color: "yellow",
		cost: 3,
		activation: "red",
		group: "craftsmen",
		effect: "worker",
		parameter: "1",
		nameKey: "games.bruges.people.y25",
		textKey: "games.bruges.texts.y25"
	},
	y26: {
		id: "y26",
		color: "yellow",
		cost: 6,
		activation: "yellow",
		group: "protectors",
		effect: "removeColor",
		parameter: "yellow",
		nameKey: "games.bruges.people.y26",
		textKey: "games.bruges.texts.y26"
	},
	y27: {
		id: "y27",
		color: "yellow",
		cost: 9,
		activation: "F",
		group: "craftsmen",
		effect: "freeCanalAction",
		parameter: "",
		nameKey: "games.bruges.people.y27",
		textKey: "games.bruges.texts.y27"
	},
	y28: {
		id: "y28",
		color: "yellow",
		cost: 12,
		activation: "F",
		group: "protectors",
		effect: "removeAny",
		parameter: "1",
		nameKey: "games.bruges.people.y28",
		textKey: "games.bruges.texts.y28"
	},
	y29: {
		id: "y29",
		color: "yellow",
		cost: 6,
		activation: "brown",
		group: "bureaucrats",
		effect: "vpThreeHouses",
		parameter: "brown",
		nameKey: "games.bruges.people.y29",
		textKey: "games.bruges.texts.y29"
	},
	y30: {
		id: "y30",
		color: "yellow",
		cost: 3,
		activation: "brown",
		group: "clergy",
		effect: "moneyGroup",
		parameter: "clergy",
		nameKey: "games.bruges.people.y30",
		textKey: "games.bruges.texts.y30"
	},
	y31: {
		id: "y31",
		color: "yellow",
		cost: 9,
		activation: "I",
		group: "outcasts",
		effect: "attackHouse",
		parameter: "",
		nameKey: "games.bruges.people.y31",
		textKey: "games.bruges.texts.y31"
	},
	y32: {
		id: "y32",
		color: "yellow",
		cost: 9,
		activation: "purple",
		group: "nobles",
		effect: "vpMoney",
		parameter: "1,2",
		nameKey: "games.bruges.people.y32",
		textKey: "games.bruges.texts.y32"
	},
	y33: {
		id: "y33",
		color: "yellow",
		cost: 9,
		activation: "E",
		group: "merchants",
		effect: "endGroup",
		parameter: "merchants,2",
		nameKey: "games.bruges.people.y33",
		textKey: "games.bruges.texts.y33"
	},
	b01: {
		id: "b01",
		color: "blue",
		cost: 3,
		activation: "red",
		group: "entertainers",
		effect: "canalDouble",
		parameter: "",
		nameKey: "games.bruges.people.b01",
		textKey: "games.bruges.texts.b01"
	},
	b02: {
		id: "b02",
		color: "blue",
		cost: 6,
		activation: "blue",
		group: "protectors",
		effect: "removeColor",
		parameter: "blue",
		nameKey: "games.bruges.people.b02",
		textKey: "games.bruges.texts.b02"
	},
	b03: {
		id: "b03",
		color: "blue",
		cost: 0,
		activation: "I",
		group: "scholars",
		effect: "money",
		parameter: "6",
		nameKey: "games.bruges.people.b03",
		textKey: "games.bruges.texts.b03"
	},
	b04: {
		id: "b04",
		color: "blue",
		cost: 9,
		activation: "I",
		group: "scholars",
		effect: "drawHouses",
		parameter: "2",
		nameKey: "games.bruges.people.b04",
		textKey: "games.bruges.texts.b04"
	},
	b05: {
		id: "b05",
		color: "blue",
		cost: 3,
		activation: "purple",
		group: "court",
		effect: "draw",
		parameter: "1",
		nameKey: "games.bruges.people.b05",
		textKey: "games.bruges.texts.b05"
	},
	b06: {
		id: "b06",
		color: "blue",
		cost: 9,
		activation: "E",
		group: "protectors",
		effect: "endGroup",
		parameter: "protectors,2",
		nameKey: "games.bruges.people.b06",
		textKey: "games.bruges.texts.b06"
	},
	b07: {
		id: "b07",
		color: "blue",
		cost: 0,
		activation: "P",
		group: "entertainers",
		effect: "diceWorker",
		parameter: "blue",
		nameKey: "games.bruges.people.b07",
		textKey: "games.bruges.texts.b07"
	},
	b08: {
		id: "b08",
		color: "blue",
		cost: 3,
		activation: "brown",
		group: "craftsmen",
		effect: "exchangeWorkers",
		parameter: "",
		nameKey: "games.bruges.people.b08",
		textKey: "games.bruges.texts.b08"
	},
	b09: {
		id: "b09",
		color: "blue",
		cost: 3,
		activation: "purple",
		group: "craftsmen",
		effect: "worker",
		parameter: "1",
		nameKey: "games.bruges.people.b09",
		textKey: "games.bruges.texts.b09"
	},
	b10: {
		id: "b10",
		color: "blue",
		cost: 3,
		activation: "blue",
		group: "craftsmen",
		effect: "moneyGroup",
		parameter: "craftsmen",
		nameKey: "games.bruges.people.b10",
		textKey: "games.bruges.texts.b10"
	},
	b11: {
		id: "b11",
		color: "blue",
		cost: 3,
		activation: "P",
		group: "merchants",
		effect: "moneyDieBonus",
		parameter: "blue,3",
		nameKey: "games.bruges.people.b11",
		textKey: "games.bruges.texts.b11"
	},
	b12: {
		id: "b12",
		color: "blue",
		cost: 9,
		activation: "brown",
		group: "nobles",
		effect: "vpMoney",
		parameter: "1,2",
		nameKey: "games.bruges.people.b12",
		textKey: "games.bruges.texts.b12"
	},
	b13: {
		id: "b13",
		color: "blue",
		cost: 9,
		activation: "brown",
		group: "nobles",
		effect: "drawPlay",
		parameter: "",
		nameKey: "games.bruges.people.b13",
		textKey: "games.bruges.texts.b13"
	},
	b14: {
		id: "b14",
		color: "blue",
		cost: 6,
		activation: "blue",
		group: "outcasts",
		effect: "attackThreat",
		parameter: "blue",
		nameKey: "games.bruges.people.b14",
		textKey: "games.bruges.texts.b14"
	},
	b15: {
		id: "b15",
		color: "blue",
		cost: 6,
		activation: "purple",
		group: "clergy",
		effect: "vpDice",
		parameter: "1",
		nameKey: "games.bruges.people.b15",
		textKey: "games.bruges.texts.b15"
	},
	b16: {
		id: "b16",
		color: "blue",
		cost: 3,
		activation: "purple",
		group: "merchants",
		effect: "money",
		parameter: "3",
		nameKey: "games.bruges.people.b16",
		textKey: "games.bruges.texts.b16"
	},
	b17: {
		id: "b17",
		color: "blue",
		cost: 9,
		activation: "E",
		group: "entertainers",
		effect: "endGroup",
		parameter: "entertainers,2",
		nameKey: "games.bruges.people.b17",
		textKey: "games.bruges.texts.b17"
	},
	b18: {
		id: "b18",
		color: "blue",
		cost: 3,
		activation: "brown",
		group: "court",
		effect: "playExtra",
		parameter: "",
		nameKey: "games.bruges.people.b18",
		textKey: "games.bruges.texts.b18"
	},
	b19: {
		id: "b19",
		color: "blue",
		cost: 9,
		activation: "E",
		group: "outcasts",
		effect: "endGroup",
		parameter: "outcasts,2",
		nameKey: "games.bruges.people.b19",
		textKey: "games.bruges.texts.b19"
	},
	b20: {
		id: "b20",
		color: "blue",
		cost: 3,
		activation: "I",
		group: "scholars",
		effect: "moneyPerson",
		parameter: "2",
		nameKey: "games.bruges.people.b20",
		textKey: "games.bruges.texts.b20"
	},
	b21: {
		id: "b21",
		color: "blue",
		cost: 6,
		activation: "purple",
		group: "bureaucrats",
		effect: "vpThreeHouses",
		parameter: "purple",
		nameKey: "games.bruges.people.b21",
		textKey: "games.bruges.texts.b21"
	},
	b22: {
		id: "b22",
		color: "blue",
		cost: 9,
		activation: "E",
		group: "court",
		effect: "endFiveColors",
		parameter: "5",
		nameKey: "games.bruges.people.b22",
		textKey: "games.bruges.texts.b22"
	},
	b23: {
		id: "b23",
		color: "blue",
		cost: 6,
		activation: "I",
		group: "outcasts",
		effect: "stealWorkers",
		parameter: "2",
		nameKey: "games.bruges.people.b23",
		textKey: "games.bruges.texts.b23"
	},
	b24: {
		id: "b24",
		color: "blue",
		cost: 0,
		activation: "I",
		group: "clergy",
		effect: "workerMoney",
		parameter: "red,3",
		nameKey: "games.bruges.people.b24",
		textKey: "games.bruges.texts.b24"
	},
	b25: {
		id: "b25",
		color: "blue",
		cost: 6,
		activation: "P",
		group: "bureaucrats",
		effect: "advanceDiscount",
		parameter: "2",
		nameKey: "games.bruges.people.b25",
		textKey: "games.bruges.texts.b25"
	},
	b26: {
		id: "b26",
		color: "blue",
		cost: 3,
		activation: "red",
		group: "bureaucrats",
		effect: "moneyHouse",
		parameter: "red",
		nameKey: "games.bruges.people.b26",
		textKey: "games.bruges.texts.b26"
	},
	b27: {
		id: "b27",
		color: "blue",
		cost: 6,
		activation: "purple",
		group: "artists",
		effect: "vpGroup",
		parameter: "clergy",
		nameKey: "games.bruges.people.b27",
		textKey: "games.bruges.texts.b27"
	},
	b28: {
		id: "b28",
		color: "blue",
		cost: 3,
		activation: "brown",
		group: "artists",
		effect: "moneyGroup",
		parameter: "artists",
		nameKey: "games.bruges.people.b28",
		textKey: "games.bruges.texts.b28"
	},
	b29: {
		id: "b29",
		color: "blue",
		cost: 3,
		activation: "I",
		group: "merchants",
		effect: "giftMoneyVp",
		parameter: "1",
		nameKey: "games.bruges.people.b29",
		textKey: "games.bruges.texts.b29"
	},
	b30: {
		id: "b30",
		color: "blue",
		cost: 9,
		activation: "I",
		group: "clergy",
		effect: "workerVp",
		parameter: "yellow,3",
		nameKey: "games.bruges.people.b30",
		textKey: "games.bruges.texts.b30"
	},
	b31: {
		id: "b31",
		color: "blue",
		cost: 3,
		activation: "P",
		group: "nobles",
		effect: "advanceWhenForbidden",
		parameter: "4",
		nameKey: "games.bruges.people.b31",
		textKey: "games.bruges.texts.b31"
	},
	b32: {
		id: "b32",
		color: "blue",
		cost: 6,
		activation: "yellow",
		group: "artists",
		effect: "vpGroup",
		parameter: "merchants",
		nameKey: "games.bruges.people.b32",
		textKey: "games.bruges.texts.b32"
	},
	b33: {
		id: "b33",
		color: "blue",
		cost: 3,
		activation: "I",
		group: "protectors",
		effect: "removeAny",
		parameter: "2",
		nameKey: "games.bruges.people.b33",
		textKey: "games.bruges.texts.b33"
	},
	p01: {
		id: "p01",
		color: "purple",
		cost: 9,
		activation: "P",
		group: "scholars",
		effect: "workersBonus",
		parameter: "1",
		nameKey: "games.bruges.people.p01",
		textKey: "games.bruges.texts.p01"
	},
	p02: {
		id: "p02",
		color: "purple",
		cost: 3,
		activation: "yellow",
		group: "craftsmen",
		effect: "exchangeWorkers",
		parameter: "",
		nameKey: "games.bruges.people.p02",
		textKey: "games.bruges.texts.p02"
	},
	p03: {
		id: "p03",
		color: "purple",
		cost: 9,
		activation: "I",
		group: "outcasts",
		effect: "attackPerson",
		parameter: "",
		nameKey: "games.bruges.people.p03",
		textKey: "games.bruges.texts.p03"
	},
	p04: {
		id: "p04",
		color: "purple",
		cost: 12,
		activation: "P",
		group: "outcasts",
		effect: "opponentPersonMoney",
		parameter: "2",
		nameKey: "games.bruges.people.p04",
		textKey: "games.bruges.texts.p04"
	},
	p05: {
		id: "p05",
		color: "purple",
		cost: 3,
		activation: "blue",
		group: "entertainers",
		effect: "canalDouble",
		parameter: "",
		nameKey: "games.bruges.people.p05",
		textKey: "games.bruges.texts.p05"
	},
	p06: {
		id: "p06",
		color: "purple",
		cost: 3,
		activation: "blue",
		group: "court",
		effect: "draw",
		parameter: "1",
		nameKey: "games.bruges.people.p06",
		textKey: "games.bruges.texts.p06"
	},
	p07: {
		id: "p07",
		color: "purple",
		cost: 6,
		activation: "I",
		group: "protectors",
		effect: "removeAny",
		parameter: "3",
		nameKey: "games.bruges.people.p07",
		textKey: "games.bruges.texts.p07"
	},
	p08: {
		id: "p08",
		color: "purple",
		cost: 9,
		activation: "I",
		group: "protectors",
		effect: "removePerPerson",
		parameter: "",
		nameKey: "games.bruges.people.p08",
		textKey: "games.bruges.texts.p08"
	},
	p09: {
		id: "p09",
		color: "purple",
		cost: 9,
		activation: "E",
		group: "clergy",
		effect: "endGroup",
		parameter: "clergy,2",
		nameKey: "games.bruges.people.p09",
		textKey: "games.bruges.texts.p09"
	},
	p10: {
		id: "p10",
		color: "purple",
		cost: 3,
		activation: "brown",
		group: "craftsmen",
		effect: "worker",
		parameter: "1",
		nameKey: "games.bruges.people.p10",
		textKey: "games.bruges.texts.p10"
	},
	p11: {
		id: "p11",
		color: "purple",
		cost: 3,
		activation: "yellow",
		group: "court",
		effect: "playExtra",
		parameter: "",
		nameKey: "games.bruges.people.p11",
		textKey: "games.bruges.texts.p11"
	},
	p12: {
		id: "p12",
		color: "purple",
		cost: 3,
		activation: "P",
		group: "merchants",
		effect: "moneyDieBonus",
		parameter: "purple,3",
		nameKey: "games.bruges.people.p12",
		textKey: "games.bruges.texts.p12"
	},
	p13: {
		id: "p13",
		color: "purple",
		cost: 3,
		activation: "yellow",
		group: "bureaucrats",
		effect: "moneyHouse",
		parameter: "yellow",
		nameKey: "games.bruges.people.p13",
		textKey: "games.bruges.texts.p13"
	},
	p14: {
		id: "p14",
		color: "purple",
		cost: 9,
		activation: "P",
		group: "entertainers",
		effect: "personRemoveThreat",
		parameter: "",
		nameKey: "games.bruges.people.p14",
		textKey: "games.bruges.texts.p14"
	},
	p15: {
		id: "p15",
		color: "purple",
		cost: 0,
		activation: "P",
		group: "entertainers",
		effect: "diceWorker",
		parameter: "purple",
		nameKey: "games.bruges.people.p15",
		textKey: "games.bruges.texts.p15"
	},
	p16: {
		id: "p16",
		color: "purple",
		cost: 3,
		activation: "E",
		group: "scholars",
		effect: "endCanalMilestones",
		parameter: "2",
		nameKey: "games.bruges.people.p16",
		textKey: "games.bruges.texts.p16"
	},
	p17: {
		id: "p17",
		color: "purple",
		cost: 0,
		activation: "I",
		group: "court",
		effect: "moneyHouseColors",
		parameter: "2",
		nameKey: "games.bruges.people.p17",
		textKey: "games.bruges.texts.p17"
	},
	p18: {
		id: "p18",
		color: "purple",
		cost: 6,
		activation: "purple",
		group: "protectors",
		effect: "removeColor",
		parameter: "purple",
		nameKey: "games.bruges.people.p18",
		textKey: "games.bruges.texts.p18"
	},
	p19: {
		id: "p19",
		color: "purple",
		cost: 9,
		activation: "yellow",
		group: "nobles",
		effect: "vpMoney",
		parameter: "1,2",
		nameKey: "games.bruges.people.p19",
		textKey: "games.bruges.texts.p19"
	},
	p20: {
		id: "p20",
		color: "purple",
		cost: 9,
		activation: "E",
		group: "artists",
		effect: "endGroup",
		parameter: "artists,2",
		nameKey: "games.bruges.people.p20",
		textKey: "games.bruges.texts.p20"
	},
	p21: {
		id: "p21",
		color: "purple",
		cost: 9,
		activation: "I",
		group: "clergy",
		effect: "workerVp",
		parameter: "blue,3",
		nameKey: "games.bruges.people.p21",
		textKey: "games.bruges.texts.p21"
	},
	p22: {
		id: "p22",
		color: "purple",
		cost: 9,
		activation: "P",
		group: "scholars",
		effect: "drawLimit",
		parameter: "6",
		nameKey: "games.bruges.people.p22",
		textKey: "games.bruges.texts.p22"
	},
	p23: {
		id: "p23",
		color: "purple",
		cost: 9,
		activation: "P",
		group: "bureaucrats",
		effect: "tieMajority",
		parameter: "",
		nameKey: "games.bruges.people.p23",
		textKey: "games.bruges.texts.p23"
	},
	p24: {
		id: "p24",
		color: "purple",
		cost: 6,
		activation: "yellow",
		group: "bureaucrats",
		effect: "vpThreeHouses",
		parameter: "yellow",
		nameKey: "games.bruges.people.p24",
		textKey: "games.bruges.texts.p24"
	},
	p25: {
		id: "p25",
		color: "purple",
		cost: 3,
		activation: "blue",
		group: "nobles",
		effect: "moneyGroup",
		parameter: "nobles",
		nameKey: "games.bruges.people.p25",
		textKey: "games.bruges.texts.p25"
	},
	p26: {
		id: "p26",
		color: "purple",
		cost: 0,
		activation: "I",
		group: "clergy",
		effect: "workerMoney",
		parameter: "brown,3",
		nameKey: "games.bruges.people.p26",
		textKey: "games.bruges.texts.p26"
	},
	p27: {
		id: "p27",
		color: "purple",
		cost: 6,
		activation: "red",
		group: "artists",
		effect: "vpGroup",
		parameter: "entertainers",
		nameKey: "games.bruges.people.p27",
		textKey: "games.bruges.texts.p27"
	},
	p28: {
		id: "p28",
		color: "purple",
		cost: 3,
		activation: "yellow",
		group: "merchants",
		effect: "moneyGroup",
		parameter: "merchants",
		nameKey: "games.bruges.people.p28",
		textKey: "games.bruges.texts.p28"
	},
	p29: {
		id: "p29",
		color: "purple",
		cost: 9,
		activation: "yellow",
		group: "nobles",
		effect: "drawPlay",
		parameter: "",
		nameKey: "games.bruges.people.p29",
		textKey: "games.bruges.texts.p29"
	},
	p30: {
		id: "p30",
		color: "purple",
		cost: 6,
		activation: "brown",
		group: "craftsmen",
		effect: "moneyGroups",
		parameter: "1",
		nameKey: "games.bruges.people.p30",
		textKey: "games.bruges.texts.p30"
	},
	p31: {
		id: "p31",
		color: "purple",
		cost: 6,
		activation: "blue",
		group: "artists",
		effect: "vpGroup",
		parameter: "bureaucrats",
		nameKey: "games.bruges.people.p31",
		textKey: "games.bruges.texts.p31"
	},
	p32: {
		id: "p32",
		color: "purple",
		cost: 6,
		activation: "purple",
		group: "outcasts",
		effect: "attackThreat",
		parameter: "purple",
		nameKey: "games.bruges.people.p32",
		textKey: "games.bruges.texts.p32"
	},
	p33: {
		id: "p33",
		color: "purple",
		cost: 3,
		activation: "red",
		group: "merchants",
		effect: "money",
		parameter: "3",
		nameKey: "games.bruges.people.p33",
		textKey: "games.bruges.texts.p33"
	},
	r01: {
		id: "r01",
		color: "red",
		cost: 3,
		activation: "E",
		group: "entertainers",
		effect: "endWildGroups",
		parameter: "2",
		nameKey: "games.bruges.people.r01",
		textKey: "games.bruges.texts.r01"
	},
	r02: {
		id: "r02",
		color: "red",
		cost: 3,
		activation: "yellow",
		group: "merchants",
		effect: "money",
		parameter: "3",
		nameKey: "games.bruges.people.r02",
		textKey: "games.bruges.texts.r02"
	},
	r03: {
		id: "r03",
		color: "red",
		cost: 9,
		activation: "E",
		group: "bureaucrats",
		effect: "endGroup",
		parameter: "bureaucrats,2",
		nameKey: "games.bruges.people.r03",
		textKey: "games.bruges.texts.r03"
	},
	r04: {
		id: "r04",
		color: "red",
		cost: 6,
		activation: "blue",
		group: "bureaucrats",
		effect: "vpThreeHouses",
		parameter: "blue",
		nameKey: "games.bruges.people.r04",
		textKey: "games.bruges.texts.r04"
	},
	r05: {
		id: "r05",
		color: "red",
		cost: 9,
		activation: "E",
		group: "craftsmen",
		effect: "endGroup",
		parameter: "craftsmen,2",
		nameKey: "games.bruges.people.r05",
		textKey: "games.bruges.texts.r05"
	},
	r06: {
		id: "r06",
		color: "red",
		cost: 6,
		activation: "red",
		group: "protectors",
		effect: "removeColor",
		parameter: "red",
		nameKey: "games.bruges.people.r06",
		textKey: "games.bruges.texts.r06"
	},
	r07: {
		id: "r07",
		color: "red",
		cost: 12,
		activation: "P",
		group: "scholars",
		effect: "doubleImmediate",
		parameter: "",
		nameKey: "games.bruges.people.r07",
		textKey: "games.bruges.texts.r07"
	},
	r08: {
		id: "r08",
		color: "red",
		cost: 6,
		activation: "E",
		group: "scholars",
		effect: "endMajority",
		parameter: "2",
		nameKey: "games.bruges.people.r08",
		textKey: "games.bruges.texts.r08"
	},
	r09: {
		id: "r09",
		color: "red",
		cost: 3,
		activation: "yellow",
		group: "court",
		effect: "moneyGroup",
		parameter: "court",
		nameKey: "games.bruges.people.r09",
		textKey: "games.bruges.texts.r09"
	},
	r10: {
		id: "r10",
		color: "red",
		cost: 0,
		activation: "P",
		group: "entertainers",
		effect: "diceWorker",
		parameter: "red",
		nameKey: "games.bruges.people.r10",
		textKey: "games.bruges.texts.r10"
	},
	r11: {
		id: "r11",
		color: "red",
		cost: 3,
		activation: "P",
		group: "merchants",
		effect: "moneyDieBonus",
		parameter: "red,3",
		nameKey: "games.bruges.people.r11",
		textKey: "games.bruges.texts.r11"
	},
	r12: {
		id: "r12",
		color: "red",
		cost: 9,
		activation: "red",
		group: "nobles",
		effect: "drawPlay",
		parameter: "",
		nameKey: "games.bruges.people.r12",
		textKey: "games.bruges.texts.r12"
	},
	r13: {
		id: "r13",
		color: "red",
		cost: 9,
		activation: "P",
		group: "scholars",
		effect: "removeActionBonus",
		parameter: "1",
		nameKey: "games.bruges.people.r13",
		textKey: "games.bruges.texts.r13"
	},
	r14: {
		id: "r14",
		color: "red",
		cost: 0,
		activation: "brown",
		group: "court",
		effect: "drawDiscard",
		parameter: "2",
		nameKey: "games.bruges.people.r14",
		textKey: "games.bruges.texts.r14"
	},
	r15: {
		id: "r15",
		color: "red",
		cost: 9,
		activation: "P",
		group: "artists",
		effect: "houseRemoveThreat",
		parameter: "",
		nameKey: "games.bruges.people.r15",
		textKey: "games.bruges.texts.r15"
	},
	r16: {
		id: "r16",
		color: "red",
		cost: 3,
		activation: "blue",
		group: "craftsmen",
		effect: "worker",
		parameter: "1",
		nameKey: "games.bruges.people.r16",
		textKey: "games.bruges.texts.r16"
	},
	r17: {
		id: "r17",
		color: "red",
		cost: 3,
		activation: "yellow",
		group: "entertainers",
		effect: "canalDouble",
		parameter: "",
		nameKey: "games.bruges.people.r17",
		textKey: "games.bruges.texts.r17"
	},
	r18: {
		id: "r18",
		color: "red",
		cost: 3,
		activation: "I",
		group: "outcasts",
		effect: "stealMoney",
		parameter: "3",
		nameKey: "games.bruges.people.r18",
		textKey: "games.bruges.texts.r18"
	},
	r19: {
		id: "r19",
		color: "red",
		cost: 6,
		activation: "blue",
		group: "artists",
		effect: "vpGroup",
		parameter: "outcasts",
		nameKey: "games.bruges.people.r19",
		textKey: "games.bruges.texts.r19"
	},
	r20: {
		id: "r20",
		color: "red",
		cost: 9,
		activation: "I",
		group: "protectors",
		effect: "removeAny",
		parameter: "4",
		nameKey: "games.bruges.people.r20",
		textKey: "games.bruges.texts.r20"
	},
	r21: {
		id: "r21",
		color: "red",
		cost: 3,
		activation: "blue",
		group: "court",
		effect: "playExtra",
		parameter: "",
		nameKey: "games.bruges.people.r21",
		textKey: "games.bruges.texts.r21"
	},
	r22: {
		id: "r22",
		color: "red",
		cost: 3,
		activation: "red",
		group: "protectors",
		effect: "moneyGroup",
		parameter: "protectors",
		nameKey: "games.bruges.people.r22",
		textKey: "games.bruges.texts.r22"
	},
	r23: {
		id: "r23",
		color: "red",
		cost: 0,
		activation: "I",
		group: "clergy",
		effect: "workerMoney",
		parameter: "purple,3",
		nameKey: "games.bruges.people.r23",
		textKey: "games.bruges.texts.r23"
	},
	r24: {
		id: "r24",
		color: "red",
		cost: 0,
		activation: "E",
		group: "clergy",
		effect: "endWorkers",
		parameter: "2",
		nameKey: "games.bruges.people.r24",
		textKey: "games.bruges.texts.r24"
	},
	r25: {
		id: "r25",
		color: "red",
		cost: 9,
		activation: "I",
		group: "clergy",
		effect: "workerVp",
		parameter: "purple,3",
		nameKey: "games.bruges.people.r25",
		textKey: "games.bruges.texts.r25"
	},
	r26: {
		id: "r26",
		color: "red",
		cost: 6,
		activation: "red",
		group: "outcasts",
		effect: "attackThreat",
		parameter: "red",
		nameKey: "games.bruges.people.r26",
		textKey: "games.bruges.texts.r26"
	},
	r27: {
		id: "r27",
		color: "red",
		cost: 6,
		activation: "brown",
		group: "artists",
		effect: "vpGroup",
		parameter: "scholars",
		nameKey: "games.bruges.people.r27",
		textKey: "games.bruges.texts.r27"
	},
	r28: {
		id: "r28",
		color: "red",
		cost: 3,
		activation: "purple",
		group: "bureaucrats",
		effect: "moneyHouse",
		parameter: "purple",
		nameKey: "games.bruges.people.r28",
		textKey: "games.bruges.texts.r28"
	},
	r29: {
		id: "r29",
		color: "red",
		cost: 9,
		activation: "F",
		group: "nobles",
		effect: "vp",
		parameter: "1",
		nameKey: "games.bruges.people.r29",
		textKey: "games.bruges.texts.r29"
	},
	r30: {
		id: "r30",
		color: "red",
		cost: 9,
		activation: "E",
		group: "nobles",
		effect: "endGroup",
		parameter: "nobles,2",
		nameKey: "games.bruges.people.r30",
		textKey: "games.bruges.texts.r30"
	},
	r31: {
		id: "r31",
		color: "red",
		cost: 3,
		activation: "purple",
		group: "outcasts",
		effect: "moneyGroup",
		parameter: "outcasts",
		nameKey: "games.bruges.people.r31",
		textKey: "games.bruges.texts.r31"
	},
	r32: {
		id: "r32",
		color: "red",
		cost: 9,
		activation: "blue",
		group: "merchants",
		effect: "vpCompletedCanals",
		parameter: "2",
		nameKey: "games.bruges.people.r32",
		textKey: "games.bruges.texts.r32"
	},
	r33: {
		id: "r33",
		color: "red",
		cost: 3,
		activation: "purple",
		group: "craftsmen",
		effect: "exchangeWorkers",
		parameter: "",
		nameKey: "games.bruges.people.r33",
		textKey: "games.bruges.texts.r33"
	},
	n01: {
		id: "n01",
		color: "brown",
		cost: 9,
		activation: "P",
		group: "scholars",
		effect: "threatLimit",
		parameter: "4",
		nameKey: "games.bruges.people.n01",
		textKey: "games.bruges.texts.n01"
	},
	n02: {
		id: "n02",
		color: "brown",
		cost: 9,
		activation: "I",
		group: "clergy",
		effect: "workerVp",
		parameter: "red,3",
		nameKey: "games.bruges.people.n02",
		textKey: "games.bruges.texts.n02"
	},
	n03: {
		id: "n03",
		color: "brown",
		cost: 6,
		activation: "brown",
		group: "protectors",
		effect: "removeColor",
		parameter: "brown",
		nameKey: "games.bruges.people.n03",
		textKey: "games.bruges.texts.n03"
	},
	n04: {
		id: "n04",
		color: "brown",
		cost: 6,
		activation: "red",
		group: "bureaucrats",
		effect: "vpThreeHouses",
		parameter: "red",
		nameKey: "games.bruges.people.n04",
		textKey: "games.bruges.texts.n04"
	},
	n05: {
		id: "n05",
		color: "brown",
		cost: 0,
		activation: "I",
		group: "bureaucrats",
		effect: "attackHand",
		parameter: "1",
		nameKey: "games.bruges.people.n05",
		textKey: "games.bruges.texts.n05"
	},
	n06: {
		id: "n06",
		color: "brown",
		cost: 6,
		activation: "I",
		group: "court",
		effect: "draw",
		parameter: "3",
		nameKey: "games.bruges.people.n06",
		textKey: "games.bruges.texts.n06"
	},
	n07: {
		id: "n07",
		color: "brown",
		cost: 3,
		activation: "P",
		group: "merchants",
		effect: "moneyDieBonus",
		parameter: "brown,3",
		nameKey: "games.bruges.people.n07",
		textKey: "games.bruges.texts.n07"
	},
	n08: {
		id: "n08",
		color: "brown",
		cost: 3,
		activation: "F",
		group: "merchants",
		effect: "money",
		parameter: "2",
		nameKey: "games.bruges.people.n08",
		textKey: "games.bruges.texts.n08"
	},
	n09: {
		id: "n09",
		color: "brown",
		cost: 12,
		activation: "red",
		group: "nobles",
		effect: "vpCanals",
		parameter: "3",
		nameKey: "games.bruges.people.n09",
		textKey: "games.bruges.texts.n09"
	},
	n10: {
		id: "n10",
		color: "brown",
		cost: 3,
		activation: "purple",
		group: "entertainers",
		effect: "canalDouble",
		parameter: "",
		nameKey: "games.bruges.people.n10",
		textKey: "games.bruges.texts.n10"
	},
	n11: {
		id: "n11",
		color: "brown",
		cost: 12,
		activation: "E",
		group: "artists",
		effect: "endGroups",
		parameter: "2",
		nameKey: "games.bruges.people.n11",
		textKey: "games.bruges.texts.n11"
	},
	n12: {
		id: "n12",
		color: "brown",
		cost: 0,
		activation: "I",
		group: "protectors",
		effect: "freeCanal",
		parameter: "",
		nameKey: "games.bruges.people.n12",
		textKey: "games.bruges.texts.n12"
	},
	n13: {
		id: "n13",
		color: "brown",
		cost: 6,
		activation: "P",
		group: "protectors",
		effect: "canalRemoveThreat",
		parameter: "",
		nameKey: "games.bruges.people.n13",
		textKey: "games.bruges.texts.n13"
	},
	n14: {
		id: "n14",
		color: "brown",
		cost: 3,
		activation: "purple",
		group: "court",
		effect: "playExtra",
		parameter: "",
		nameKey: "games.bruges.people.n14",
		textKey: "games.bruges.texts.n14"
	},
	n15: {
		id: "n15",
		color: "brown",
		cost: 9,
		activation: "E",
		group: "scholars",
		effect: "endGroup",
		parameter: "scholars,2",
		nameKey: "games.bruges.people.n15",
		textKey: "games.bruges.texts.n15"
	},
	n16: {
		id: "n16",
		color: "brown",
		cost: 3,
		activation: "blue",
		group: "craftsmen",
		effect: "exchangeWorkers",
		parameter: "",
		nameKey: "games.bruges.people.n16",
		textKey: "games.bruges.texts.n16"
	},
	n17: {
		id: "n17",
		color: "brown",
		cost: 3,
		activation: "yellow",
		group: "entertainers",
		effect: "moneyGroup",
		parameter: "entertainers",
		nameKey: "games.bruges.people.n17",
		textKey: "games.bruges.texts.n17"
	},
	n18: {
		id: "n18",
		color: "brown",
		cost: 6,
		activation: "red",
		group: "artists",
		effect: "vpGroup",
		parameter: "court",
		nameKey: "games.bruges.people.n18",
		textKey: "games.bruges.texts.n18"
	},
	n19: {
		id: "n19",
		color: "brown",
		cost: 9,
		activation: "blue",
		group: "nobles",
		effect: "drawPlay",
		parameter: "",
		nameKey: "games.bruges.people.n19",
		textKey: "games.bruges.texts.n19"
	},
	n20: {
		id: "n20",
		color: "brown",
		cost: 6,
		activation: "brown",
		group: "outcasts",
		effect: "attackThreat",
		parameter: "brown",
		nameKey: "games.bruges.people.n20",
		textKey: "games.bruges.texts.n20"
	},
	n21: {
		id: "n21",
		color: "brown",
		cost: 3,
		activation: "I",
		group: "scholars",
		effect: "drawDiscard",
		parameter: "4",
		nameKey: "games.bruges.people.n21",
		textKey: "games.bruges.texts.n21"
	},
	n22: {
		id: "n22",
		color: "brown",
		cost: 0,
		activation: "I",
		group: "clergy",
		effect: "workerMoney",
		parameter: "yellow,3",
		nameKey: "games.bruges.people.n22",
		textKey: "games.bruges.texts.n22"
	},
	n23: {
		id: "n23",
		color: "brown",
		cost: 3,
		activation: "blue",
		group: "merchants",
		effect: "money",
		parameter: "3",
		nameKey: "games.bruges.people.n23",
		textKey: "games.bruges.texts.n23"
	},
	n24: {
		id: "n24",
		color: "brown",
		cost: 3,
		activation: "yellow",
		group: "craftsmen",
		effect: "worker",
		parameter: "1",
		nameKey: "games.bruges.people.n24",
		textKey: "games.bruges.texts.n24"
	},
	n25: {
		id: "n25",
		color: "brown",
		cost: 9,
		activation: "F",
		group: "craftsmen",
		effect: "worker",
		parameter: "1",
		nameKey: "games.bruges.people.n25",
		textKey: "games.bruges.texts.n25"
	},
	n26: {
		id: "n26",
		color: "brown",
		cost: 0,
		activation: "P",
		group: "entertainers",
		effect: "diceWorker",
		parameter: "brown",
		nameKey: "games.bruges.people.n26",
		textKey: "games.bruges.texts.n26"
	},
	n27: {
		id: "n27",
		color: "brown",
		cost: 6,
		activation: "P",
		group: "clergy",
		effect: "advanceRemoveThreat",
		parameter: "",
		nameKey: "games.bruges.people.n27",
		textKey: "games.bruges.texts.n27"
	},
	n28: {
		id: "n28",
		color: "brown",
		cost: 9,
		activation: "blue",
		group: "nobles",
		effect: "vpMoney",
		parameter: "1,2",
		nameKey: "games.bruges.people.n28",
		textKey: "games.bruges.texts.n28"
	},
	n29: {
		id: "n29",
		color: "brown",
		cost: 3,
		activation: "blue",
		group: "bureaucrats",
		effect: "moneyHouse",
		parameter: "blue",
		nameKey: "games.bruges.people.n29",
		textKey: "games.bruges.texts.n29"
	},
	n30: {
		id: "n30",
		color: "brown",
		cost: 6,
		activation: "yellow",
		group: "artists",
		effect: "vpGroup",
		parameter: "nobles",
		nameKey: "games.bruges.people.n30",
		textKey: "games.bruges.texts.n30"
	},
	n31: {
		id: "n31",
		color: "brown",
		cost: 3,
		activation: "yellow",
		group: "court",
		effect: "draw",
		parameter: "1",
		nameKey: "games.bruges.people.n31",
		textKey: "games.bruges.texts.n31"
	},
	n32: {
		id: "n32",
		color: "brown",
		cost: 9,
		activation: "I",
		group: "outcasts",
		effect: "attackAdvance",
		parameter: "1",
		nameKey: "games.bruges.people.n32",
		textKey: "games.bruges.texts.n32"
	},
	n33: {
		id: "n33",
		color: "brown",
		cost: 6,
		activation: "F",
		group: "outcasts",
		effect: "moneyDice",
		parameter: "6",
		nameKey: "games.bruges.people.n33",
		textKey: "games.bruges.texts.n33"
	},
	x00: {
		id: "x00",
		color: "brown",
		cost: 6,
		activation: "I",
		group: "nobles",
		effect: "recruitDiscard",
		parameter: "nobles",
		nameKey: "games.bruges.people.x00",
		textKey: "games.bruges.texts.x00"
	},
	x01: {
		id: "x01",
		color: "red",
		cost: 0,
		activation: "I",
		group: "craftsmen",
		effect: "sellWorkerColors",
		parameter: "",
		nameKey: "games.bruges.people.x01",
		textKey: "games.bruges.texts.x01"
	},
	x02: {
		id: "x02",
		color: "brown",
		cost: 9,
		activation: "yellow",
		group: "travelers",
		effect: "wildNext",
		parameter: "",
		nameKey: "games.bruges.people.x02",
		textKey: "games.bruges.texts.x02"
	},
	x03: {
		id: "x03",
		color: "purple",
		cost: 9,
		activation: "blue",
		group: "travelers",
		effect: "wildNext",
		parameter: "",
		nameKey: "games.bruges.people.x03",
		textKey: "games.bruges.texts.x03"
	},
	x04: {
		id: "x04",
		color: "brown",
		cost: 6,
		activation: "I",
		group: "bureaucrats",
		effect: "recruitDiscard",
		parameter: "bureaucrats",
		nameKey: "games.bruges.people.x04",
		textKey: "games.bruges.texts.x04"
	},
	x05: {
		id: "x05",
		color: "purple",
		cost: 9,
		activation: "purple",
		group: "travelers",
		effect: "moneyWorkerColors",
		parameter: "1",
		nameKey: "games.bruges.people.x05",
		textKey: "games.bruges.texts.x05"
	},
	x06: {
		id: "x06",
		color: "blue",
		cost: 6,
		activation: "brown",
		group: "travelers",
		effect: "discardHouse",
		parameter: "",
		nameKey: "games.bruges.people.x06",
		textKey: "games.bruges.texts.x06"
	},
	x07: {
		id: "x07",
		color: "brown",
		cost: 9,
		activation: "P",
		group: "travelers",
		effect: "advanceVp",
		parameter: "1",
		nameKey: "games.bruges.people.x07",
		textKey: "games.bruges.texts.x07"
	},
	x08: {
		id: "x08",
		color: "yellow",
		cost: 9,
		activation: "red",
		group: "travelers",
		effect: "wildNext",
		parameter: "",
		nameKey: "games.bruges.people.x08",
		textKey: "games.bruges.texts.x08"
	},
	x09: {
		id: "x09",
		color: "yellow",
		cost: 6,
		activation: "I",
		group: "protectors",
		effect: "recruitDiscard",
		parameter: "protectors",
		nameKey: "games.bruges.people.x09",
		textKey: "games.bruges.texts.x09"
	},
	x10: {
		id: "x10",
		color: "yellow",
		cost: 6,
		activation: "I",
		group: "merchants",
		effect: "recruitDiscard",
		parameter: "merchants",
		nameKey: "games.bruges.people.x10",
		textKey: "games.bruges.texts.x10"
	},
	x11: {
		id: "x11",
		color: "blue",
		cost: 0,
		activation: "I",
		group: "travelers",
		effect: "moneyThreatColors",
		parameter: "2",
		nameKey: "games.bruges.people.x11",
		textKey: "games.bruges.texts.x11"
	},
	x12: {
		id: "x12",
		color: "purple",
		cost: 9,
		activation: "P",
		group: "protectors",
		effect: "protectDiceThreat",
		parameter: "",
		nameKey: "games.bruges.people.x12",
		textKey: "games.bruges.texts.x12"
	},
	x13: {
		id: "x13",
		color: "purple",
		cost: 6,
		activation: "I",
		group: "travelers",
		effect: "recruitDiscard",
		parameter: "travelers",
		nameKey: "games.bruges.people.x13",
		textKey: "games.bruges.texts.x13"
	},
	x14: {
		id: "x14",
		color: "brown",
		cost: 6,
		activation: "purple",
		group: "travelers",
		effect: "discardHouse",
		parameter: "",
		nameKey: "games.bruges.people.x14",
		textKey: "games.bruges.texts.x14"
	},
	x15: {
		id: "x15",
		color: "blue",
		cost: 9,
		activation: "F",
		group: "merchants",
		effect: "sellWorkerDie",
		parameter: "",
		nameKey: "games.bruges.people.x15",
		textKey: "games.bruges.texts.x15"
	},
	x16: {
		id: "x16",
		color: "red",
		cost: 6,
		activation: "blue",
		group: "travelers",
		effect: "discardHouse",
		parameter: "",
		nameKey: "games.bruges.people.x16",
		textKey: "games.bruges.texts.x16"
	},
	x17: {
		id: "x17",
		color: "blue",
		cost: 6,
		activation: "brown",
		group: "artists",
		effect: "vpGroup",
		parameter: "travelers",
		nameKey: "games.bruges.people.x17",
		textKey: "games.bruges.texts.x17"
	},
	x18: {
		id: "x18",
		color: "purple",
		cost: 9,
		activation: "I",
		group: "scholars",
		effect: "giveThreats",
		parameter: "",
		nameKey: "games.bruges.people.x18",
		textKey: "games.bruges.texts.x18"
	},
	x19: {
		id: "x19",
		color: "red",
		cost: 6,
		activation: "blue",
		group: "bureaucrats",
		effect: "storeWorker",
		parameter: "",
		nameKey: "games.bruges.people.x19",
		textKey: "games.bruges.texts.x19"
	},
	x20: {
		id: "x20",
		color: "brown",
		cost: 3,
		activation: "I",
		group: "outcasts",
		effect: "stealRandomCards",
		parameter: "",
		nameKey: "games.bruges.people.x20",
		textKey: "games.bruges.texts.x20"
	},
	x21: {
		id: "x21",
		color: "purple",
		cost: 6,
		activation: "I",
		group: "outcasts",
		effect: "recruitDiscard",
		parameter: "outcasts",
		nameKey: "games.bruges.people.x21",
		textKey: "games.bruges.texts.x21"
	},
	x22: {
		id: "x22",
		color: "yellow",
		cost: 6,
		activation: "red",
		group: "travelers",
		effect: "discardHouse",
		parameter: "",
		nameKey: "games.bruges.people.x22",
		textKey: "games.bruges.texts.x22"
	},
	x23: {
		id: "x23",
		color: "blue",
		cost: 3,
		activation: "I",
		group: "nobles",
		effect: "returnPerson",
		parameter: "",
		nameKey: "games.bruges.people.x23",
		textKey: "games.bruges.texts.x23"
	},
	x24: {
		id: "x24",
		color: "purple",
		cost: 6,
		activation: "yellow",
		group: "travelers",
		effect: "discardHouse",
		parameter: "",
		nameKey: "games.bruges.people.x24",
		textKey: "games.bruges.texts.x24"
	},
	x25: {
		id: "x25",
		color: "red",
		cost: 3,
		activation: "yellow",
		group: "travelers",
		effect: "moneyGroup",
		parameter: "travelers",
		nameKey: "games.bruges.people.x25",
		textKey: "games.bruges.texts.x25"
	},
	x26: {
		id: "x26",
		color: "yellow",
		cost: 6,
		activation: "purple",
		group: "clergy",
		effect: "workersDiceOne",
		parameter: "",
		nameKey: "games.bruges.people.x26",
		textKey: "games.bruges.texts.x26"
	},
	x27: {
		id: "x27",
		color: "brown",
		cost: 6,
		activation: "I",
		group: "court",
		effect: "recruitDiscard",
		parameter: "court",
		nameKey: "games.bruges.people.x27",
		textKey: "games.bruges.texts.x27"
	},
	x28: {
		id: "x28",
		color: "red",
		cost: 6,
		activation: "I",
		group: "scholars",
		effect: "recruitDiscard",
		parameter: "scholars",
		nameKey: "games.bruges.people.x28",
		textKey: "games.bruges.texts.x28"
	},
	x29: {
		id: "x29",
		color: "red",
		cost: 9,
		activation: "purple",
		group: "travelers",
		effect: "wildNext",
		parameter: "",
		nameKey: "games.bruges.people.x29",
		textKey: "games.bruges.texts.x29"
	},
	x30: {
		id: "x30",
		color: "red",
		cost: 6,
		activation: "I",
		group: "clergy",
		effect: "recruitDiscard",
		parameter: "clergy",
		nameKey: "games.bruges.people.x30",
		textKey: "games.bruges.texts.x30"
	},
	x31: {
		id: "x31",
		color: "blue",
		cost: 9,
		activation: "brown",
		group: "travelers",
		effect: "wildNext",
		parameter: "",
		nameKey: "games.bruges.people.x31",
		textKey: "games.bruges.texts.x31"
	},
	x32: {
		id: "x32",
		color: "yellow",
		cost: 6,
		activation: "I",
		group: "entertainers",
		effect: "recruitDiscard",
		parameter: "entertainers",
		nameKey: "games.bruges.people.x32",
		textKey: "games.bruges.texts.x32"
	},
	x33: {
		id: "x33",
		color: "yellow",
		cost: 9,
		activation: "red",
		group: "court",
		effect: "playDiscardTop",
		parameter: "",
		nameKey: "games.bruges.people.x33",
		textKey: "games.bruges.texts.x33"
	},
	x34: {
		id: "x34",
		color: "blue",
		cost: 6,
		activation: "I",
		group: "craftsmen",
		effect: "recruitDiscard",
		parameter: "craftsmen",
		nameKey: "games.bruges.people.x34",
		textKey: "games.bruges.texts.x34"
	},
	x35: {
		id: "x35",
		color: "purple",
		cost: 6,
		activation: "I",
		group: "artists",
		effect: "recruitDiscard",
		parameter: "artists",
		nameKey: "games.bruges.people.x35",
		textKey: "games.bruges.texts.x35"
	},
	x36: {
		id: "x36",
		color: "red",
		cost: 6,
		activation: "E",
		group: "travelers",
		effect: "endGroup",
		parameter: "travelers,2",
		nameKey: "games.bruges.people.x36",
		textKey: "games.bruges.texts.x36"
	},
	x37: {
		id: "x37",
		color: "yellow",
		cost: 9,
		activation: "I",
		group: "travelers",
		effect: "copyOpponent",
		parameter: "",
		nameKey: "games.bruges.people.x37",
		textKey: "games.bruges.texts.x37"
	},
	x38: {
		id: "x38",
		color: "blue",
		cost: 6,
		activation: "purple",
		group: "entertainers",
		effect: "readyPerson",
		parameter: "",
		nameKey: "games.bruges.people.x38",
		textKey: "games.bruges.texts.x38"
	}
}, y = Object.keys(v).filter((e) => !e.startsWith("x")), b = Object.keys(v).filter((e) => e.startsWith("x")), x = [
	0,
	1,
	2,
	3,
	4,
	5,
	7,
	9,
	12
], S = [
	[[
		"brown",
		"red",
		"purple",
		"blue",
		"yellow"
	], [
		"yellow",
		"purple",
		"red",
		"brown",
		"blue"
	]],
	[[
		"purple",
		"blue",
		"red",
		"yellow",
		"brown"
	], [
		"red",
		"brown",
		"yellow",
		"purple",
		"blue"
	]],
	[[
		"brown",
		"purple",
		"blue",
		"red",
		"yellow"
	], [
		"blue",
		"yellow",
		"purple",
		"red",
		"brown"
	]],
	[[
		"yellow",
		"red",
		"blue",
		"brown",
		"purple"
	], [
		"blue",
		"brown",
		"yellow",
		"purple",
		"red"
	]],
	[[
		"purple",
		"blue",
		"brown",
		"yellow",
		"red"
	], [
		"red",
		"yellow",
		"brown",
		"blue",
		"purple"
	]]
], C = {
	m00: {
		action: "house",
		uses: 6,
		effect: "freeWorker",
		nameKey: "games.bruges.marketNames.m00",
		textKey: "games.bruges.marketTexts.m00"
	},
	m01: {
		action: "canal",
		uses: 6,
		effect: "anyColor",
		nameKey: "games.bruges.marketNames.m01",
		textKey: "games.bruges.marketTexts.m01"
	},
	m02: {
		action: "canal",
		uses: 5,
		effect: "discount",
		nameKey: "games.bruges.marketNames.m02",
		textKey: "games.bruges.marketTexts.m02"
	},
	m03: {
		action: "money",
		uses: 6,
		effect: "fixedMoney",
		nameKey: "games.bruges.marketNames.m03",
		textKey: "games.bruges.marketTexts.m03"
	},
	m04: {
		action: "workers",
		uses: 5,
		effect: "extraSameWorker",
		nameKey: "games.bruges.marketNames.m04",
		textKey: "games.bruges.marketTexts.m04"
	},
	m05: {
		action: "house",
		uses: 5,
		effect: "bonusVp",
		nameKey: "games.bruges.marketNames.m05",
		textKey: "games.bruges.marketTexts.m05"
	},
	m06: {
		action: "remove",
		uses: 5,
		effect: "extraVpPerThreat",
		nameKey: "games.bruges.marketNames.m06",
		textKey: "games.bruges.marketTexts.m06"
	},
	m07: {
		action: "remove",
		uses: 6,
		effect: "anyColor",
		nameKey: "games.bruges.marketNames.m07",
		textKey: "games.bruges.marketTexts.m07"
	},
	m08: {
		action: "money",
		uses: 5,
		effect: "extraMoney",
		nameKey: "games.bruges.marketNames.m08",
		textKey: "games.bruges.marketTexts.m08"
	},
	m09: {
		action: "person",
		uses: 6,
		effect: "bonusWorker",
		nameKey: "games.bruges.marketNames.m09",
		textKey: "games.bruges.marketTexts.m09"
	},
	m10: {
		action: "person",
		uses: 5,
		effect: "freeActivation",
		nameKey: "games.bruges.marketNames.m10",
		textKey: "games.bruges.marketTexts.m10"
	},
	m11: {
		action: "workers",
		uses: 6,
		effect: "anyColors",
		nameKey: "games.bruges.marketNames.m11",
		textKey: "games.bruges.marketTexts.m11"
	}
}, w = {
	id: "bruges",
	tier: "alpha",
	mechanics: [
		"hand-management",
		"dice-rolling",
		"engine-building",
		"route-building"
	],
	interactionTags: [],
	nameKey: "games.bruges.name",
	descKey: "games.bruges.desc",
	rulesKey: "games.bruges.rules",
	icon: "🏰",
	iconImg: "games/bruges.webp",
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	rulesUrl: { es: "https://steamusercontent-a.akamaihd.net/ugc/1018321379964773481/5ACC5E89C8F22B9A1810CE7CAD1BDA284541B8EB/" },
	playerRange: (e) => ({
		min: 2,
		max: typeof e == "object" && e && "fifthPlayer" in e && e.fifthPlayer === !0 ? 5 : 4
	}),
	accent: "#986526",
	releasedAt: "2026-10-31T14:28:24+08:00",
	search: {
		py: "bu lu ri",
		init: "blr"
	},
	hotseat: "cover"
}, T = t.enum([
	"blue",
	"brown",
	"yellow",
	"red",
	"purple"
]), E = t.object({
	newCitizens: t.boolean().default(!1),
	fifthPlayer: t.boolean().default(!1),
	ships: t.boolean().default(!1),
	market: t.boolean().default(!1)
}).default({
	newCitizens: !1,
	fifthPlayer: !1,
	ships: !1,
	market: !1
}), D = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	key: t.string().max(200)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), O = t.object({
	blue: t.int().nonnegative(),
	brown: t.int().nonnegative(),
	yellow: t.int().nonnegative(),
	red: t.int().nonnegative(),
	purple: t.int().nonnegative()
}), ee = t.object({
	key: t.string(),
	op: t.string(),
	card: t.string().optional(),
	color: T.optional(),
	target: t.string().optional(),
	n: t.number().optional(),
	side: t.number().optional(),
	house: t.string().optional(),
	other: t.string().optional(),
	cost: t.number().optional(),
	market: t.string().optional()
}), te = t.object({
	id: t.string(),
	color: T,
	person: t.string().nullable()
}), ne = t.object({
	points: t.number(),
	people: t.number(),
	houses: t.number(),
	abilities: t.number(),
	majorities: t.number(),
	canals: t.number(),
	statues: t.number(),
	prestige: t.number(),
	total: t.number()
}), re = t.object({
	rid: t.string(),
	money: t.int().nonnegative(),
	vp: t.int().nonnegative(),
	workers: O,
	threats: O,
	houses: t.array(te),
	canals: t.array(t.int().min(0).max(5)).length(2),
	statues: t.array(t.int()),
	statueClaimed: t.array(t.boolean()).length(2),
	prestige: t.int().min(0).max(8),
	majorities: t.array(t.boolean()).length(3),
	used: t.array(t.string()),
	storedWorkers: t.record(t.string(), t.int().nonnegative()),
	protectedColor: T.nullable(),
	handCount: t.int().nonnegative(),
	score: ne.nullable()
}), ie = t.object({
	config: E,
	round: t.int(),
	first: t.string(),
	turn: t.string(),
	turnNumber: t.int(),
	phase: t.string(),
	source: t.string().nullable(),
	played: t.boolean(),
	finalRound: t.int().nullable(),
	dice: O,
	players: t.array(re),
	stacks: t.array(t.object({
		count: t.int(),
		color: T.nullable()
	})).length(2),
	reserveCount: t.int(),
	discard: t.array(t.string()),
	statues: t.array(t.int()),
	ships: t.array(t.object({
		color: T,
		effect: t.int(),
		active: t.boolean(),
		next: t.int().nullable()
	})),
	market: t.object({
		id: t.string(),
		uses: t.int()
	}).nullable(),
	log: t.array(t.object({
		id: t.int(),
		who: t.string(),
		event: t.string(),
		card: t.string().optional(),
		color: T.optional(),
		n: t.number().optional(),
		target: t.string().optional()
	}))
}), k = t.object({
	hand: t.array(t.string()),
	choices: t.array(ee),
	drawnCount: t.int(),
	wildNext: t.boolean()
}), A = () => ({
	blue: 0,
	brown: 0,
	yellow: 0,
	red: 0,
	purple: 0
}), j = (e) => g.reduce((t, n) => t + e[n], 0), M = (e, t) => e.players.find((e) => e.rid === t), N = (e) => e.houses.flatMap((e) => e.person ? [e.person] : []), P = (e, t) => N(e).some((e) => v[e].effect === t), F = (e, t) => N(e).filter((e) => v[e].group === t).length, ae = (e) => new Set(N(e).map((e) => v[e].group)).size, oe = (e) => new Set(e.houses.map((e) => v[e.card].color)).size, I = (e, t) => {
	e.tasks.unshift(...t);
}, L = (e, t, n = {}) => ({
	kind: e,
	who: t,
	...n
});
function R(e, t, n, r = {}) {
	e.log.push({
		id: e.log.length,
		who: t,
		event: n,
		...r
	});
}
function z(t, n) {
	let r = e(t.seed, t.cursor, n);
	return t.cursor += 1, r;
}
function B(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = z(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function se(e) {
	return e.players.map((t, n) => e.players[(e.first + n) % e.players.length]);
}
function ce(e, t) {
	for (let n = 0; n < 2; n++) if (!e.stacks[n].length && (e.reserveUsed || (e.reserveUsed = !0, e.finalRound = e.round + +!t, e.stacks[n] = e.reserve.splice(0), R(e, "", "finalRound", { n: e.finalRound })), !e.stacks[n].length)) {
		let t = e.stacks[1 - n];
		t.length > 1 && (e.stacks[n] = t.splice(0, Math.floor(t.length / 2)));
	}
}
function V(e, t, n, r, i = !0) {
	let a = Math.min(t.threats[n], r);
	t.threats[n] -= a, i && (t.vp += a), a && R(e, t.rid, "remove", {
		color: n,
		n: a
	});
}
function le(e, t) {
	t.prestige >= 8 || (t.prestige += 1, P(t, "advanceVp") && (t.vp += 1), P(t, "advanceRemoveThreat") && I(e, [L("remove", t.rid, { n: 1 })]), R(e, t.rid, "advance"));
}
function ue(e, t, n) {
	t.houses.push({
		id: `house-${e.serial}`,
		card: n,
		person: null
	});
	let r = v[n].color;
	P(t, "houseRemoveThreat") && V(e, t, r, 1), R(e, t.rid, "house", { color: r });
}
function de(e, t, n) {
	let r = S[e.players.indexOf(t)][n][t.canals[n]];
	t.canals[n] += 1, t.canals[n] === 5 && !t.statueClaimed[n] && (t.statueClaimed[n] = !0, e.statues.length && t.statues.push(e.statues.shift())), P(t, "canalRemoveThreat") && V(e, t, r, 1), R(e, t.rid, "canal", {
		color: r,
		n: t.canals[n]
	});
}
function fe(e, t, n, r) {
	t.houses.find((e) => e.card === r).person = n;
	for (let n of e.players) n !== t && P(n, "opponentPersonMoney") && (n.money += 2);
	P(t, "personRemoveThreat") && V(e, t, v[n].color, 1), v[n].activation === "I" && I(e, Array.from({ length: P(t, "doubleImmediate") ? 2 : 1 }, () => L("effect", t.rid, { source: n }))), R(e, t.rid, "person", { card: n });
}
function pe(e, t, n, r = !1) {
	let i = t.houses.find((e) => e.person === n);
	i && (i.person = null, r ? t.hand.push(n) : e.discard.push(n), t.used = t.used.filter((e) => e !== n), delete t.storedWorkers[n], I(e, [L("disasters", t.rid)]));
}
function me(e, t, n) {
	let r = t.houses.find((e) => e.card === n);
	r.person && (t.hand.push(r.person), t.used = t.used.filter((e) => e !== r.person), delete t.storedWorkers[r.person]), t.houses = t.houses.filter((e) => e.card !== n), e.discard.push(n), I(e, [L("disasters", t.rid)]);
}
function he(e) {
	e.round += 1, e.turnNumber = 1, e.played = !1;
	for (let t of e.players) t.used = [], t.wildNext = !1, t.protectedColor = null;
	let t = se(e);
	e.tasks = [
		...t.map((e) => L("refill", e.rid)),
		L("market", ""),
		...t.filter((e) => P(e, "protectDiceThreat")).map((e) => L("protect", e.rid)),
		L("roll", ""),
		...t.map((e) => L("diceThreats", e.rid)),
		L("ports", ""),
		...t.map((e) => L("prestige", e.rid)),
		...Array.from({ length: 4 }, (e, n) => t.map((e) => L("turn", e.rid, { n: n + 1 }))).flat(),
		L("majority", ""),
		L("roundEnd", "")
	];
}
function ge(e, t, n) {
	let r = { ...E.parse(e) };
	t.length === 5 && (r.fifthPlayer = !0, r.newCitizens = !0), r.fifthPlayer && (r.newCitizens = !0);
	let i = {
		seed: n,
		cursor: 0,
		serial: 0,
		config: r,
		players: t.map((e) => ({
			rid: e,
			money: 5,
			vp: 5,
			workers: {
				blue: 1,
				brown: 1,
				yellow: 1,
				red: 1,
				purple: 1
			},
			threats: A(),
			houses: [],
			canals: [0, 0],
			statues: [],
			statueClaimed: [!1, !1],
			prestige: 0,
			majorities: [
				!1,
				!1,
				!1
			],
			used: [],
			storedWorkers: {},
			protectedColor: null,
			handCount: 0,
			score: null,
			hand: [],
			wildNext: !1
		})),
		round: 0,
		first: 0,
		turnNumber: 1,
		tasks: [],
		stacks: [[], []],
		reserve: [],
		reserveUsed: !1,
		discard: [],
		finalRound: null,
		dice: A(),
		statues: r.fifthPlayer ? [
			9,
			8,
			7,
			6,
			5,
			4,
			3,
			2
		] : [
			7,
			6,
			5,
			4,
			3,
			2
		],
		shipDecks: [],
		shipDiscards: [],
		ships: [],
		marketDeck: [],
		market: null,
		played: !1,
		done: !1,
		log: []
	}, a = B(i, r.newCitizens ? [...y, ...b] : y), o = a.splice(0, t.length * (r.newCitizens ? 34 : 33));
	return i.stacks = [o.splice(0, Math.ceil(o.length / 2)), o], i.reserve = a, i.shipDecks = g.map(() => B(i, [
		0,
		1,
		2,
		3,
		4,
		5
	])), i.shipDiscards = g.map(() => []), i.ships = g.map((e, t) => ({
		color: e,
		effect: i.shipDecks[t][0],
		active: !1
	})), i.marketDeck = B(i, Object.keys(C)), i.first = z(i, t.length), he(i), { state: i };
}
function _e(e, t, n) {
	let r = [];
	for (let i of [void 0, ...e.market && e.market.uses > 0 ? [e.market.id] : []]) for (let a of n) {
		let n = (e, t) => {
			(!i || C[i].action === e) && r.push({
				...t,
				...i ? { market: i } : {}
			});
		}, o = v[a];
		for (let r of t.wildNext ? g : [o.color]) {
			if (n("workers", {
				op: "workers",
				card: a,
				color: r,
				n: 2 + +!!P(t, "workersBonus") + +(i === "m04")
			}), n("money", {
				op: "money",
				card: a,
				color: r,
				n: (i === "m03" ? 5 : e.dice[r]) + (i === "m08" ? 2 : 0) + (N(t).some((e) => v[e].effect === "moneyDieBonus" && v[e].parameter.startsWith(r)) ? 3 : 0)
			}), i === "m07") for (let e of g) t.threats[e] && n("remove", {
				op: "removeAction",
				card: a,
				color: r,
				other: e
			});
			else t.threats[r] && n("remove", {
				op: "removeAction",
				card: a,
				color: r,
				other: r
			});
			(t.workers[r] > 0 || i === "m00") && n("house", {
				op: "house",
				card: a,
				color: r,
				cost: i === "m00" ? 0 : 1
			});
			for (let o = 0; o < 2; o++) {
				let s = t.canals[o], c = S[e.players.indexOf(t)][o][s];
				if (s >= 5 || r !== c && i !== "m01") continue;
				let l = Math.max(0, s + 1 - (i === "m02" ? 2 : 0));
				t.money >= l && n("canal", {
					op: "canalAction",
					card: a,
					color: r,
					side: o,
					cost: l
				}), P(t, "freeCanalAction") && !t.used.includes("y27") && n("canal", {
					op: "canalActionFree",
					card: a,
					color: r,
					side: o,
					cost: 0
				});
			}
		}
		let s = Math.max(0, o.cost - (P(t, "personDiscount") ? 3 : 0));
		if (t.money >= s) for (let e of t.houses) e.person || n("person", {
			op: "person",
			card: a,
			house: e.card,
			cost: s
		});
	}
	return r;
}
function ve(e, t) {
	let n = v[t];
	return !e.used.includes(t) && (n.activation === "F" || g.includes(n.activation) && e.workers[n.activation] > 0);
}
function ye(e) {
	let t = e.tasks[0];
	if (!t || !t.who) return [];
	let n = M(e, t.who), r = [], i = { op: "skip" };
	switch (t.kind) {
		case "draw": return e.stacks.forEach((e, t) => {
			e.length && r.push({
				op: "draw",
				side: t,
				color: v[e[e.length - 1]].color
			});
		}), t.mode === "refill" && n.hand.length + (t.cards?.length ?? 0) >= 5 && r.push(i), r;
		case "protect": return [...g.map((e) => ({
			op: "protect",
			color: e
		})), i];
		case "prestige": {
			let t = g.reduce((t, n) => t + (e.dice[n] <= 2 ? e.dice[n] : 0), 0), r = Math.max(0, (t || (P(n, "advanceWhenForbidden") ? 4 : 1e4)) - (P(n, "advanceDiscount") ? 2 : 0));
			return [...n.prestige < 8 && n.money >= r ? [{
				op: "advance",
				cost: r
			}] : [], i];
		}
		case "turn":
			e.played || r.push(..._e(e, n, n.hand));
			for (let e of N(n)) ve(n, e) && v[e].effect !== "freeCanalAction" && r.push({
				op: "activate",
				card: e,
				color: g.includes(v[e].activation) ? v[e].activation : void 0
			});
			return (e.played || !n.hand.length) && r.push({ op: "endTurn" }), r;
		case "playExtra": return [..._e(e, n, n.hand), i];
		case "playForced": return _e(e, n, (t.cards ?? []).filter((e) => n.hand.includes(e)));
		case "remove": return [...g.filter((e) => n.threats[e] && (!t.color || e === t.color)).map((e) => ({
			op: "remove",
			color: e
		})), i];
		case "workers":
		case "buyWorkers": return [...g.filter(() => t.kind !== "buyWorkers" || n.money > 0).map((e) => ({
			op: "worker",
			color: e
		})), ...t.kind === "buyWorkers" ? [i] : []];
		case "discard": return n.hand.map((e) => ({
			op: "discard",
			card: e
		}));
		case "losePerson": return N(n).map((e) => ({
			op: "losePerson",
			card: e
		}));
		case "loseHouse": return n.houses.map((e) => ({
			op: "loseHouse",
			house: e.card
		}));
		case "loseCanal": return [0, 1].filter((e) => n.canals[e] > 0).map((e) => ({
			op: "loseCanal",
			side: e
		}));
		case "fire": return [...n.houses.map((e) => ({
			op: "loseHouse",
			house: e.card
		})), ...[0, 1].filter((e) => n.canals[e] > 0).map((e) => ({
			op: "loseCanal",
			side: e
		}))];
		case "disasters": return g.filter((e) => n.threats[e] >= (P(n, "threatLimit") ? 4 : 3)).map((e) => ({
			op: "disaster",
			color: e
		}));
		case "stealWorkers": return g.filter((e) => n.workers[e]).map((e) => ({
			op: "giveWorker",
			color: e
		}));
		case "canal":
			for (let e = 0; e < 2; e++) {
				if (n.canals[e] >= 5) continue;
				let i = (n.canals[e] + 1) * (t.mode === "double" ? 2 : 0);
				n.money >= i && r.push({
					op: "buildCanal",
					side: e,
					cost: i
				}), i > 0 && P(n, "freeCanalAction") && !n.used.includes("y27") && r.push({
					op: "buildCanalFree",
					side: e,
					cost: 0
				});
			}
			return [...r, i];
		case "recruitDiscard":
			for (let i of e.discard) if (v[i].group === t.group) for (let e of n.houses) e.person || r.push({
				op: "recruitDiscard",
				card: i,
				house: e.card
			});
			return [...r, i];
		case "discardHouse": return [...e.discard.filter((e) => n.workers[v[e].color] > 0).map((e) => ({
			op: "discardHouse",
			card: e,
			color: v[e].color
		})), i];
		case "giveThreats": return [...g.filter((e) => n.threats[e]).map((e) => ({
			op: "giveThreat",
			color: e,
			target: t.target
		})), i];
		case "storeWorker": return [...g.filter((e) => n.workers[e]).map((e) => ({
			op: "storeWorker",
			color: e
		})), i];
		case "sellWorker": return [...g.filter((e) => n.workers[e]).map((t) => ({
			op: "sellWorker",
			color: t,
			n: e.dice[t]
		})), i];
		case "returnPerson": return [...N(n).map((e) => ({
			op: "returnPerson",
			card: e
		})), i];
		case "ready": return [...N(n).filter((e) => e !== t.source && n.used.includes(e) && (v[e].activation === "F" || g.includes(v[e].activation))).map((e) => ({
			op: "ready",
			card: e
		})), i];
		case "copy":
			for (let t of e.players) if (t !== n) for (let e of N(t)) [
				"I",
				"F",
				...g
			].includes(v[e].activation) && r.push({
				op: "copy",
				card: e,
				target: t.rid
			});
			return [...r, i];
		case "activateAll": return [...(t.cards ?? []).filter((e) => N(n).includes(e)).map((e) => ({
			op: "freeActivate",
			card: e
		})), i];
		case "freeActivate": return [...(t.cards ?? []).filter((e) => N(n).includes(e) && (t.mode === "immediate" ? v[e].activation === "I" : ["F", ...g].includes(v[e].activation))).map((e) => ({
			op: "freeActivate",
			card: e
		})), i];
		case "gift": return e.players.filter((e) => e !== n && !t.cards?.includes(e.rid) && n.money > 0).map((e) => ({
			op: "gift",
			target: e.rid
		}));
		case "exchangeGive": return [...g.filter((e) => n.workers[e] > 0).map((e) => ({
			op: "exchangeGive",
			color: e
		})), { op: "exchangeDone" }];
		case "exchangeTake": return g.map((e) => ({
			op: "worker",
			color: e
		}));
		case "sellColors": return [...g.filter((e) => n.workers[e] > 0 && !t.colors?.includes(e)).map((e) => ({
			op: "sellColor",
			color: e
		})), i];
		case "ships": return [...e.ships.filter((e) => e.active && n.workers[e.color] > 0).map((e) => ({
			op: "ship",
			color: e.color,
			n: e.effect
		})), i];
	}
	return [];
}
function be(e) {
	return ye(e).map((t, n) => ({
		...t,
		key: `${e.serial}:${n}`
	}));
}
function xe(e, t, n, r = n.id) {
	let [i, a] = n.parameter.split(","), o = Number(i) || 1, s = r, c = t.rid, l = (e, t = {}) => L(e, c, {
		source: s,
		...t
	}), u = e.players.filter((e) => e !== t);
	switch (n.effect) {
		case "money":
			t.money += o;
			break;
		case "vp":
			t.vp += o;
			break;
		case "workerVp":
			t.workers[i] += 1, t.vp += Number(a);
			break;
		case "workerMoney":
			t.workers[i] += 1, t.money += Number(a);
			break;
		case "vpMoney":
			t.vp += o, t.money += Number(a);
			break;
		case "moneyHouse":
			t.money += 2 * t.houses.filter((e) => v[e.card].color === i).length;
			break;
		case "moneyHouseColors":
			t.money += o * oe(t);
			break;
		case "moneyPerson":
			t.money += o * N(t).length;
			break;
		case "moneyGroup":
			t.money += 2 * F(t, i);
			break;
		case "moneyGroups":
			t.money += ae(t);
			break;
		case "vpGroup":
			t.vp += F(t, i);
			break;
		case "vpThreeHouses":
			t.vp += t.houses.filter((e) => v[e.card].color === i).length >= 3 ? 2 : 0;
			break;
		case "vpDice":
			t.vp += g.filter((t) => e.dice[t] === o).length;
			break;
		case "moneyDice":
			t.money += g.filter((t) => e.dice[t] === o).length;
			break;
		case "vpCanals":
			t.vp += Math.floor((t.canals[0] + t.canals[1]) / 3);
			break;
		case "vpCompletedCanals":
			t.vp += o * t.canals.filter((e) => e === 5).length;
			break;
		case "worker": return [l("workers", { n: o })];
		case "buyWorkers": return [l("buyWorkers", { n: o })];
		case "removeAny": return [l("remove", { n: o })];
		case "removeColor": return [l("remove", {
			n: 1,
			color: i
		})];
		case "removePerPerson": return [l("remove", { n: N(t).length })];
		case "advance":
			le(e, t);
			break;
		case "draw": return [l("draw", {
			n: o,
			cards: []
		})];
		case "drawPlay": return [l("draw", {
			n: 1,
			cards: [],
			mode: "play"
		})];
		case "drawHouses": return [l("draw", {
			n: o,
			cards: [],
			mode: "houses"
		})];
		case "drawDiscard": return [l("draw", {
			n: o,
			cards: []
		}), l("discard", { n: o })];
		case "playExtra": return [l("playExtra")];
		case "canalDouble": return [l("canal", { mode: "double" })];
		case "freeCanal": return [l("canal")];
		case "exchangeWorkers": return [l("exchangeGive", { n: 0 })];
		case "activateAll": return [l("activateAll", { cards: N(t).filter((e) => g.includes(v[e].activation)) })];
		case "attackCanal": return u.map((e) => L("loseCanal", e.rid, { source: s }));
		case "attackHouse": return u.map((e) => L("loseHouse", e.rid, { source: s }));
		case "attackPerson": return u.map((e) => L("losePerson", e.rid, { source: s }));
		case "attackHand": return u.map((e) => L("discard", e.rid, {
			n: o,
			source: s
		}));
		case "attackAdvance":
			for (let e of u) e.prestige = Math.max(0, e.prestige - o);
			break;
		case "attackThreat": return u.map((e) => L("addThreat", e.rid, {
			color: i,
			n: 1,
			source: s
		}));
		case "stealMoney":
			for (let e of u) {
				let n = Math.min(o, e.money);
				e.money -= n, t.money += n;
			}
			break;
		case "stealWorkers": return u.map((e) => L("stealWorkers", e.rid, {
			n: o,
			target: c,
			source: s
		}));
		case "giftMoneyVp": return [l("gift", { cards: [] })];
		case "recruitDiscard": return [l("recruitDiscard", { group: i })];
		case "discardHouse": return [l("discardHouse")];
		case "wildNext":
			t.wildNext = !0;
			break;
		case "moneyWorkerColors":
			t.money += g.filter((e) => t.workers[e] > 0).length;
			break;
		case "moneyThreatColors":
			t.money += o * g.filter((e) => t.threats[e] > 0).length;
			break;
		case "sellWorkerColors": return [l("sellColors", { colors: [] })];
		case "giveThreats": return u.map((e) => l("giveThreats", { target: e.rid }));
		case "storeWorker": return [l("storeWorker")];
		case "sellWorkerDie": return [l("sellWorker")];
		case "returnPerson": return [l("returnPerson")];
		case "workersDiceOne": return g.filter((t) => e.dice[t] === 1).map((e) => l("gainWorker", { color: e }));
		case "playDiscardTop": return e.discard.length ? [l("playTop", { cards: [e.discard[e.discard.length - 1]] })] : [];
		case "copyOpponent": return [l("copy")];
		case "readyPerson": return [l("ready")];
		case "stealRandomCards": for (let n of u) n.hand.length && t.hand.push(n.hand.splice(z(e, n.hand.length), 1)[0]);
	}
	return [];
}
function Se(e) {
	let t = N(e), n = _.map((e) => t.filter((t) => v[t].group === e).length), r = (n) => t.reduce((t, r) => {
		let i = v[r], [a, o] = i.parameter.split(",");
		switch (i.effect) {
			case "endGroup": return t + n[_.indexOf(a)] * Number(o);
			case "endGroups": return t + n.filter((e) => e > 0).length * Number(a);
			case "endWorkers": return t + Math.floor(j(e.workers) / Number(a));
			case "endThreat": return t + j(e.threats);
			case "endMajority": return t + e.majorities.filter(Boolean).length * Number(a);
			case "endCanalMilestones": return t + (e.canals.filter((e) => e >= 3).length + e.statues.length) * Number(a);
			case "endFiveColors": return t + (oe(e) === 5 ? Number(a) : 0);
			default: return t;
		}
	}, Object.values(e.storedWorkers).reduce((e, t) => e + t, 0)), i = r(n);
	if (t.includes("r01")) for (let e = 0; e < _.length; e++) for (let t = e + 1; t < _.length; t++) {
		if (_[e] === "entertainers" || _[t] === "entertainers") continue;
		let a = [...n];
		a[e] += 1, a[t] += 1, i = Math.max(i, r(a));
	}
	let a = {
		points: e.vp,
		people: t.reduce((e, t) => e + v[t].cost / 3, 0),
		houses: e.houses.length,
		abilities: i,
		majorities: e.majorities.filter(Boolean).length * 4,
		canals: e.canals.filter((e) => e >= 3).length * 3,
		statues: e.statues.reduce((e, t) => e + t, 0),
		prestige: x[e.prestige],
		total: 0
	};
	return a.total = a.points + a.people + a.houses + a.abilities + a.majorities + a.canals + a.statues + a.prestige, a;
}
function Ce(e, t) {
	let n = t.who ? M(e, t.who) : null, r = t.who;
	switch (e.tasks.shift(), t.kind) {
		case "refill": {
			ce(e, !0);
			let t = (P(n, "drawLimit") ? 6 : 5) - n.hand.length;
			t > 0 && I(e, [L("draw", r, {
				n: t,
				mode: "refill",
				cards: []
			})]);
			break;
		}
		case "roll":
			for (let t of g) e.dice[t] = z(e, 6) + 1;
			R(e, "", "roll");
			break;
		case "diceThreats":
			for (let t of g) e.dice[t] >= 5 && (P(n, "diceWorker") && N(n).some((e) => v[e].effect === "diceWorker" && v[e].parameter === t) && (n.workers[t] += 1), n.protectedColor !== t && (n.threats[t] += 1));
			I(e, [L("disasters", r)]);
			break;
		case "ports":
			e.config.ships && e.ships.forEach((t, n) => {
				t.active = e.dice[t.color] === 3 || e.dice[t.color] === 4, t.active && (t.effect = e.shipDecks[n].shift());
			});
			break;
		case "market": {
			let t = e.config.market ? e.marketDeck.shift() : void 0;
			e.market = t ? {
				id: t,
				uses: C[t].uses
			} : null;
			break;
		}
		case "effect":
			t.source && I(e, xe(e, n, v[t.source], t.target ?? t.source));
			break;
		case "gainWorker":
			n.workers[t.color] += 1;
			break;
		case "addThreat":
			n.threats[t.color] += t.n ?? 1, I(e, [L("disasters", r)]);
			break;
		case "drawFinish": {
			let i = t.cards ?? [];
			if (t.mode === "houses") {
				I(e, i.map((e) => L("drawnHouse", r, { source: e })));
				break;
			}
			n.hand.push(...i), t.mode === "play" && I(e, [L("playForced", r, { cards: i })]), i.length && R(e, r, "draw", { n: i.length });
			break;
		}
		case "drawnHouse":
			ue(e, n, t.source);
			break;
		case "playTop": {
			let i = t.cards?.[0];
			i && e.discard.includes(i) && (e.discard.splice(e.discard.indexOf(i), 1), n.hand.push(i), I(e, [L("playForced", r, { cards: [i] })]));
			break;
		}
		case "majority": {
			let t = e.players.map((e) => [
				e.prestige,
				N(e).length,
				e.canals[0] + e.canals[1]
			]);
			for (let n = 0; n < 3; n++) {
				let r = Math.max(...t.map((e) => e[n])), i = t.filter((e) => e[n] === r).length > 1;
				e.players.forEach((e, a) => {
					t[a][n] === r && r > 0 && (!i || P(e, "tieMajority")) && (e.majorities[n] = !0);
				});
			}
			R(e, "", "majority");
			break;
		}
		case "roundEnd":
			for (let t = 0; t < e.ships.length; t++) e.ships[t].active && (e.shipDiscards[t].push(e.ships[t].effect), e.ships[t].active = !1, e.shipDecks[t].length || (e.shipDecks[t] = B(e, e.shipDiscards[t]), e.shipDiscards[t] = []), e.ships[t].effect = e.shipDecks[t][0]);
			e.market = null, e.finalRound !== null && e.round >= e.finalRound ? I(e, [...e.players.map((e) => L("score", e.rid)), L("done", "")]) : (e.first = (e.first + 1) % e.players.length, he(e));
			break;
		case "score":
			n.score = Se(n);
			break;
		case "done":
			e.done = !0;
			break;
		default: t.kind === "draw" && I(e, [L("drawFinish", r, {
			cards: t.cards ?? [],
			mode: t.mode
		})]);
	}
}
function we(e, t) {
	let n = e.tasks[0], r = M(e, n.who), i = r.rid, a = n.n ?? 1, o = () => {
		e.tasks.shift();
	}, s = () => {
		a > 1 ? n.n = a - 1 : o();
	};
	if ([
		"workers",
		"money",
		"removeAction",
		"house",
		"canalAction",
		"canalActionFree",
		"person"
	].includes(t.op)) {
		let a = t.card, s = t.color ?? v[a].color;
		r.hand.splice(r.hand.indexOf(a), 1), r.wildNext = !1, n.kind === "turn" ? e.played = !0 : o();
		let c = t.market;
		if (c && --e.market.uses, t.op === "person") r.money -= t.cost, fe(e, r, a, t.house), c === "m09" && I(e, [L("workers", i, { n: 1 })]), c === "m10" && I(e, [L("freeActivate", i, { cards: [a] })]);
		else if (t.op !== "house" && e.discard.push(a), t.op === "workers") {
			let n = t.n;
			c === "m11" ? I(e, [L("workers", i, { n })]) : r.workers[s] += n;
		} else if (t.op === "money") r.money += t.n;
		else if (t.op === "removeAction") {
			let n = Math.min(r.threats[t.other], P(r, "removeActionBonus") ? 2 : 1);
			V(e, r, t.other, n), c === "m06" && (r.vp += n);
		} else t.op === "house" ? (r.workers[s] -= t.cost, ue(e, r, a), c === "m05" && (r.vp += 1)) : (t.op === "canalActionFree" && r.used.push("y27"), r.money -= t.cost, de(e, r, t.side), e.config.ships && I(e, [L("ships", i)]));
		t.op !== "house" && t.op !== "person" && R(e, i, t.op === "canalActionFree" ? "canalAction" : t.op, {
			card: a,
			color: s,
			n: t.n
		});
		return;
	}
	switch (t.op) {
		case "skip":
			o(), n.kind === "draw" && I(e, [L("drawFinish", i, {
				cards: n.cards ?? [],
				mode: n.mode
			})]);
			break;
		case "draw": {
			let r = e.stacks[t.side].pop();
			(n.cards ??= []).push(r), n.n = a - 1, ce(e, n.mode === "refill"), n.n <= 0 && (o(), I(e, [L("drawFinish", i, {
				cards: n.cards,
				mode: n.mode
			})]));
			break;
		}
		case "protect":
			r.protectedColor = t.color, o();
			break;
		case "advance":
			r.money -= t.cost, o(), le(e, r);
			break;
		case "endTurn":
			o(), e.played = !1, e.turnNumber = e.tasks.find((e) => e.kind === "turn")?.n ?? 4;
			break;
		case "activate":
			t.color && --r.workers[t.color], r.used.push(t.card), I(e, [L("effect", i, { source: t.card })]), R(e, i, "activate", { card: t.card });
			break;
		case "freeActivate":
			n.kind === "activateAll" ? (n.cards = n.cards.filter((e) => e !== t.card), n.cards.length || o()) : o(), I(e, Array.from({ length: n.mode === "immediate" && P(r, "doubleImmediate") ? 2 : 1 }, () => L("effect", i, { source: t.card }))), R(e, i, "activate", { card: t.card });
			break;
		case "copy":
			o(), I(e, [L("effect", i, {
				source: t.card,
				target: n.source
			})]);
			break;
		case "ready":
			r.used = r.used.filter((e) => e !== t.card), o();
			break;
		case "remove":
			V(e, r, t.color, 1), s();
			break;
		case "worker":
			r.workers[t.color] += 1, n.kind === "buyWorkers" && --r.money, s();
			break;
		case "discard":
			r.hand.splice(r.hand.indexOf(t.card), 1), e.discard.push(t.card), s(), R(e, i, "discard", { card: t.card });
			break;
		case "losePerson":
			o(), pe(e, r, t.card), R(e, i, "losePerson", { card: t.card });
			break;
		case "loseHouse":
			o(), me(e, r, t.house), R(e, i, "loseHouse", { card: t.house });
			break;
		case "loseCanal":
			--r.canals[t.side], o(), R(e, i, "loseCanal");
			break;
		case "disaster": {
			let n = t.color;
			r.threats[n] = 0, R(e, i, "disaster", { color: n }), n === "blue" && (r.workers = A()), n === "yellow" && (r.money = 0), n === "purple" && (r.vp = Math.max(0, r.vp - 3)), n === "brown" && I(e, [L("losePerson", i)]), n === "red" && I(e, [L("fire", i)]);
			break;
		}
		case "giveWorker":
			--r.workers[t.color], M(e, n.target).workers[t.color] += 1, s();
			break;
		case "buildCanal":
		case "buildCanalFree":
			r.money -= t.cost, t.op === "buildCanalFree" && r.used.push("y27"), o(), de(e, r, t.side);
			break;
		case "recruitDiscard":
			e.discard.splice(e.discard.indexOf(t.card), 1), o(), fe(e, r, t.card, t.house);
			break;
		case "discardHouse":
			e.discard.splice(e.discard.indexOf(t.card), 1), --r.workers[t.color], o(), ue(e, r, t.card);
			break;
		case "giveThreat":
			--r.threats[t.color], o(), I(e, [L("addThreat", t.target, {
				color: t.color,
				n: 1
			})]);
			break;
		case "storeWorker":
			--r.workers[t.color], r.storedWorkers[n.source] = (r.storedWorkers[n.source] ?? 0) + 1, o();
			break;
		case "sellWorker":
			--r.workers[t.color], r.money += t.n, o();
			break;
		case "returnPerson":
			pe(e, r, t.card, !0);
			break;
		case "gift":
			--r.money, r.vp += 1, M(e, t.target).money += 1, (n.cards ??= []).push(t.target), (n.cards.length >= e.players.length - 1 || !r.money) && o();
			break;
		case "exchangeGive":
			--r.workers[t.color], n.n = a + 1;
			break;
		case "exchangeDone":
			o(), a > 0 && I(e, [L("exchangeTake", i, { n: a })]);
			break;
		case "sellColor":
			--r.workers[t.color], r.money += 1, r.vp += 1, (n.colors ??= []).push(t.color);
			break;
		case "ship": --r.workers[t.color], o(), R(e, i, "ship", {
			color: t.color,
			n: t.n
		}), t.n === 0 && I(e, [L("workers", i, { n: 3 })]), t.n === 1 && (r.money += 6), t.n === 2 && I(e, [L("remove", i, { n: 2 })]), t.n === 3 && I(e, [L("freeActivate", i, {
			mode: "immediate",
			cards: N(r).filter((e) => v[e].activation === "I")
		})]), t.n === 4 && I(e, [L("draw", i, {
			n: 1,
			mode: "play",
			cards: []
		})]), t.n === 5 && le(e, r);
	}
}
function Te(e) {
	let t = {};
	e.stacks.forEach((e, n) => e.forEach((e) => {
		t[e] = {
			anchor: `deck:${n}`,
			public: !1,
			deck: !0
		};
	})), e.discard.forEach((e) => {
		t[e] = {
			anchor: "discard",
			public: !0
		};
	});
	for (let n of e.players) {
		for (let e of n.hand) t[e] = {
			anchor: `hand:${n.rid}`,
			public: !1,
			hand: n.rid
		};
		for (let e of n.houses) t[e.card] = {
			anchor: `house:${n.rid}:${e.id}`,
			public: !0
		}, e.person && (t[e.person] = {
			anchor: `person:${n.rid}:${e.person}`,
			public: !0
		});
	}
	for (let n of e.tasks) {
		if (n.kind === "draw" || n.kind === "drawFinish") for (let e of n.cards ?? []) t[e] = {
			anchor: `hand:${n.who}`,
			public: !1,
			hand: n.who
		};
		n.kind === "drawnHouse" && n.source && (t[n.source] = {
			anchor: `hand:${n.who}`,
			public: !1,
			hand: n.who
		});
	}
	return t;
}
function Ee(e, t) {
	let n = [], r = Te(e), i = Te(t);
	for (let [e, t] of Object.entries(i)) {
		let i = r[e];
		if (!i || i.anchor === t.anchor || t.deck) continue;
		let a = t.public && (t.anchor.startsWith("person:") || t.anchor === "discard") ? e : void 0;
		n.push({
			kind: "flight",
			rid: t.hand,
			data: {
				from: i.anchor,
				to: t.anchor,
				...a ? { card: a } : {},
				...t.anchor.startsWith("house:") ? { house: v[e].color } : {}
			}
		});
	}
	for (let r of t.players) {
		let t = M(e, r.rid);
		for (let e of g) for (let i of ["workers", "threats"]) {
			let a = r[i][e] - t[i][e];
			a && n.push({
				kind: "resource",
				rid: r.rid,
				data: {
					anchor: `${i}:${r.rid}:${e}`,
					color: e,
					piece: i === "workers" ? "worker" : "threat",
					delta: a
				}
			});
		}
		for (let e of ["money", "vp"]) {
			let i = r[e] - t[e];
			i && n.push({
				kind: "resource",
				rid: r.rid,
				data: {
					anchor: `${e}:${r.rid}`,
					piece: e,
					delta: i
				}
			});
		}
		r.prestige !== t.prestige && n.push({
			kind: "pulse",
			rid: r.rid,
			data: { anchor: `prestige:${r.rid}` }
		});
		for (let e = 0; e < 2; e++) if (r.canals[e] !== t.canals[e]) {
			let i = r.canals[e] < t.canals[e], a = (i ? t.canals[e] : r.canals[e]) - 1;
			n.push({
				kind: "canal",
				rid: r.rid,
				data: {
					anchor: `canal:${r.rid}:${e}:${a}`,
					loss: i
				}
			});
		}
		for (let e of r.used) !t.used.includes(e) && v[e] && n.push({
			kind: "pulse",
			rid: r.rid,
			data: { anchor: `person:${r.rid}:${e}` }
		});
	}
	for (let r of g) t.dice[r] !== e.dice[r] && n.push({
		kind: "pulse",
		data: { anchor: `die:${r}` }
	});
	return n.map((e, t) => t ? {
		...e,
		with: !0
	} : e);
}
function De(e, t, n) {
	if (e.done) return { code: "games.bruges.errAction" };
	let r = e.tasks[0];
	if (!r) return { code: "games.bruges.errAction" };
	let i = be(e);
	if (t.type === "tick") {
		if (i.length) return { state: e };
		let t = structuredClone(e);
		return Ce(t, r), t.serial += 1, {
			state: t,
			fx: Ee(e, t)
		};
	}
	if (r.who !== n.by) return { code: "games.bruges.errTurn" };
	let a = i.find((e) => e.key === t.key);
	if (!a) return { code: "games.bruges.errAction" };
	let o = structuredClone(e);
	return we(o, a), o.serial += 1, {
		state: o,
		fx: Ee(e, o)
	};
}
function Oe(e, t) {
	let n = e.tasks[0], r = e.players.find((e) => e.rid === t);
	return {
		public: {
			config: e.config,
			round: e.round,
			first: e.players[e.first].rid,
			turn: n?.who ?? "",
			turnNumber: n?.kind === "turn" ? n.n : e.turnNumber,
			phase: e.done ? "done" : n?.kind ?? "settle",
			source: n?.kind === "drawnHouse" ? null : n?.source ?? null,
			played: e.played,
			finalRound: e.finalRound,
			dice: e.dice,
			players: e.players.map(({ hand: e, wildNext: t, houses: n, ...r }) => ({
				...r,
				houses: n.map((e) => ({
					id: e.id,
					color: v[e.card].color,
					person: e.person
				})),
				handCount: e.length
			})),
			stacks: e.stacks.map((e) => ({
				count: e.length,
				color: e.length ? v[e[e.length - 1]].color : null
			})),
			reserveCount: e.reserve.length,
			discard: e.discard,
			statues: e.statues,
			ships: e.config.ships ? e.ships.map((t, n) => ({
				...t,
				next: t.active ? e.shipDecks[n][0] ?? null : t.effect
			})) : [],
			market: e.market,
			log: e.log
		},
		private: {
			hand: r?.hand ?? [],
			choices: n?.who === t ? be(e).map((e) => e.house ? {
				...e,
				house: r.houses.find((t) => t.card === e.house).id
			} : e) : [],
			drawnCount: n?.who === t && n.kind === "draw" ? n.cards?.length ?? 0 : 0,
			wildNext: r?.wildNext ?? !1
		}
	};
}
function ke(e) {
	if (!e.done) return { phase: e.tasks[0]?.kind ?? "settle" };
	let t = [...e.players].sort((e, t) => t.score.total - e.score.total || t.money - e.money);
	return {
		phase: "done",
		ranking: t.map((e) => e.rid),
		winner: t.filter((e) => e.score.total === t[0].score.total && e.money === t[0].money).map((e) => e.rid),
		scores: Object.fromEntries(e.players.map((e) => [e.rid, e.score.total]))
	};
}
var Ae = {
	meta: w,
	saveCompatibility: { version: "1" },
	schemas: {
		action: D,
		publicView: ie,
		privateView: k,
		config: E
	},
	setup: ge,
	reduce: De,
	viewFor: Oe,
	status: ke,
	nextTickIn: (e) => !e.done && e.tasks.length > 0 && !be(e).length ? 360 : null
}, H = {
	blue: "games.bruges.colors.blue",
	brown: "games.bruges.colors.brown",
	yellow: "games.bruges.colors.yellow",
	red: "games.bruges.colors.red",
	purple: "games.bruges.colors.purple"
}, U = {
	workers: "games.bruges.ops.workers",
	money: "games.bruges.ops.money",
	removeAction: "games.bruges.ops.removeAction",
	house: "games.bruges.ops.house",
	canalAction: "games.bruges.ops.canalAction",
	canalActionFree: "games.bruges.ops.canalActionFree",
	person: "games.bruges.ops.person",
	activate: "games.bruges.ops.activate",
	freeActivate: "games.bruges.ops.freeActivate",
	draw: "games.bruges.ops.draw",
	protect: "games.bruges.ops.protect",
	advance: "games.bruges.ops.advance",
	endTurn: "games.bruges.ops.endTurn",
	skip: "games.bruges.ops.skip",
	remove: "games.bruges.ops.remove",
	worker: "games.bruges.ops.worker",
	discard: "games.bruges.ops.discard",
	losePerson: "games.bruges.ops.losePerson",
	loseHouse: "games.bruges.ops.loseHouse",
	loseCanal: "games.bruges.ops.loseCanal",
	disaster: "games.bruges.ops.disaster",
	giveWorker: "games.bruges.ops.giveWorker",
	buildCanal: "games.bruges.ops.buildCanal",
	buildCanalFree: "games.bruges.ops.buildCanalFree",
	recruitDiscard: "games.bruges.ops.recruitDiscard",
	discardHouse: "games.bruges.ops.discardHouse",
	giveThreat: "games.bruges.ops.giveThreat",
	storeWorker: "games.bruges.ops.storeWorker",
	sellWorker: "games.bruges.ops.sellWorker",
	returnPerson: "games.bruges.ops.returnPerson",
	ready: "games.bruges.ops.ready",
	copy: "games.bruges.ops.copy",
	gift: "games.bruges.ops.gift",
	exchangeGive: "games.bruges.ops.exchangeGive",
	exchangeDone: "games.bruges.ops.exchangeDone",
	sellColor: "games.bruges.ops.sellColor",
	ship: "games.bruges.ops.ship"
}, je = {
	draw: "games.bruges.phases.draw",
	protect: "games.bruges.phases.protect",
	prestige: "games.bruges.phases.prestige",
	turn: "games.bruges.phases.turn",
	playExtra: "games.bruges.phases.playExtra",
	playForced: "games.bruges.phases.playForced",
	remove: "games.bruges.phases.remove",
	workers: "games.bruges.phases.workers",
	buyWorkers: "games.bruges.phases.buyWorkers",
	discard: "games.bruges.phases.discard",
	losePerson: "games.bruges.phases.losePerson",
	loseHouse: "games.bruges.phases.loseHouse",
	loseCanal: "games.bruges.phases.loseCanal",
	fire: "games.bruges.phases.fire",
	disasters: "games.bruges.phases.disasters",
	stealWorkers: "games.bruges.phases.stealWorkers",
	canal: "games.bruges.phases.canal",
	recruitDiscard: "games.bruges.phases.recruitDiscard",
	discardHouse: "games.bruges.phases.discardHouse",
	giveThreats: "games.bruges.phases.giveThreats",
	storeWorker: "games.bruges.phases.storeWorker",
	sellWorker: "games.bruges.phases.sellWorker",
	returnPerson: "games.bruges.phases.returnPerson",
	ready: "games.bruges.phases.ready",
	copy: "games.bruges.phases.copy",
	activateAll: "games.bruges.phases.activateAll",
	freeActivate: "games.bruges.phases.freeActivate",
	gift: "games.bruges.phases.gift",
	exchangeGive: "games.bruges.phases.exchangeGive",
	exchangeTake: "games.bruges.phases.exchangeTake",
	sellColors: "games.bruges.phases.sellColors",
	ships: "games.bruges.phases.ships",
	done: "games.bruges.phases.done"
}, Me = [
	"games.bruges.ships.0",
	"games.bruges.ships.1",
	"games.bruges.ships.2",
	"games.bruges.ships.3",
	"games.bruges.ships.4",
	"games.bruges.ships.5"
];
function Ne(e, t) {
	return e.op === "house" && e.color ? t("games.bruges.workerCost", {
		n: e.cost,
		color: t(H[e.color])
	}) : t("games.bruges.cost", { n: e.cost });
}
function Pe(e, t) {
	let n = [t(U[e.op] ?? "games.bruges.confirm")];
	return e.card && n.push(t(v[e.card].nameKey)), e.color && n.push(t(H[e.color])), e.other && e.op === "removeAction" && n.push(t(H[e.other])), e.market && n.push(t(C[e.market].nameKey)), e.n !== void 0 && n.push(String(e.n)), e.cost !== void 0 && n.push(Ne(e, t)), n.join(" · ");
}
//#endregion
//#region src/games/bruges/card.tsx
var W = {
	blue: "#326791",
	brown: "#84512f",
	yellow: "#d5b52f",
	red: "#bc4137",
	purple: "#84509b"
}, Fe = {
	nobles: "games.bruges.groups.nobles",
	entertainers: "games.bruges.groups.entertainers",
	craftsmen: "games.bruges.groups.craftsmen",
	clergy: "games.bruges.groups.clergy",
	protectors: "games.bruges.groups.protectors",
	scholars: "games.bruges.groups.scholars",
	bureaucrats: "games.bruges.groups.bureaucrats",
	merchants: "games.bruges.groups.merchants",
	court: "games.bruges.groups.court",
	artists: "games.bruges.groups.artists",
	outcasts: "games.bruges.groups.outcasts",
	travelers: "games.bruges.groups.travelers"
};
function G({ name: e, color: t, className: n = "" }) {
	return /* @__PURE__ */ f("img", {
		className: `bruges-icon ${n}`,
		src: a(`games/bruges/${e}${t ? "-" + t : ""}.svg`),
		alt: "",
		draggable: !1
	});
}
function Ie({ id: e, anchor: t, selected: n, legal: r, used: i, onClick: s, compact: l = !1 }) {
	let u = v[e], m = o(), { ref: h, hidden: g } = c(t ?? null);
	return /* @__PURE__ */ p("button", {
		type: "button",
		ref: h,
		className: `bruges-card ${l ? "is-compact" : ""} ${n ? "is-selected" : ""} ${r ? "is-legal" : ""} ${i ? "is-used" : ""}`,
		style: {
			"--br-color": W[u.color],
			visibility: g ? "hidden" : void 0
		},
		onClick: s,
		"aria-label": `${m(u.nameKey)} · ${m(H[u.color])} · ${m("games.bruges.cost", { n: u.cost })}`,
		"aria-pressed": n,
		children: [
			/* @__PURE__ */ p("div", {
				className: "bruges-card-top",
				children: [/* @__PURE__ */ f("span", {
					className: "bruges-card-cost",
					children: u.cost
				}), /* @__PURE__ */ f("span", {
					className: "bruges-card-points",
					children: u.cost / 3
				})]
			}),
			/* @__PURE__ */ f("img", {
				className: "bruges-portrait",
				src: a(`games/bruges/people/${e}.svg`),
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ f("strong", {
				className: "bruges-card-name",
				children: m(u.nameKey)
			}),
			/* @__PURE__ */ f("small", { children: m(Fe[u.group]) }),
			/* @__PURE__ */ f("span", {
				className: "bruges-card-activation",
				children: i ? m("games.bruges.used") : u.activation === "I" ? m("games.bruges.immediate") : u.activation === "P" ? m("games.bruges.passive") : u.activation === "E" ? m("games.bruges.endgame") : u.activation === "F" ? m("games.bruges.free") : /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(G, {
					name: "worker",
					color: u.activation
				}), /* @__PURE__ */ f("span", { children: m(H[u.activation]) })] })
			}),
			r && /* @__PURE__ */ f("svg", {
				className: "bruges-march",
				"aria-hidden": !0,
				children: /* @__PURE__ */ f("rect", {
					x: "2",
					y: "2",
					width: "calc(100% - 4px)",
					height: "calc(100% - 4px)",
					rx: "5"
				})
			})
		]
	});
}
//#endregion
//#region src/games/bruges/view-player.tsx
var Le = [
	[[
		[18.4, 23.5],
		[14.4, 28.5],
		[11.1, 33],
		[8.7, 38],
		[7.1, 44.5]
	], [
		[23, 16],
		[28, 12.5],
		[33, 11],
		[37.5, 10],
		[42, 9.5]
	]],
	[[
		[71.5, 13.5],
		[67, 11.5],
		[62.5, 10.5],
		[58, 10],
		[53, 10]
	], [
		[82, 22],
		[85, 28],
		[88, 32],
		[91, 38],
		[92, 44]
	]],
	[[
		[71, 86],
		[66.5, 89],
		[62.5, 91],
		[58, 93],
		[53, 95]
	], [
		[79, 79],
		[82, 74],
		[85, 70],
		[88, 64],
		[91, 59]
	]],
	[[
		[24, 87],
		[29, 90],
		[33, 92],
		[37.5, 94],
		[42.5, 96]
	], [
		[18, 78],
		[15, 74],
		[12, 69],
		[10, 63],
		[8, 57]
	]]
], Re = [
	[47, 59],
	[22, 49],
	[26.5, 46.5],
	[30.7, 44.5],
	[35, 42],
	[38.7, 40],
	[42, 37.5],
	[45, 35.6],
	[48, 34]
], ze = [
	"#d7b32f",
	"#b03e36",
	"#486fad",
	"#6b8c32",
	"#333b43"
], Be = [
	"workers",
	"money",
	"removeAction",
	"house",
	"canalAction",
	"canalActionFree",
	"person"
];
function K({ name: e, children: t, className: n = "" }) {
	let { ref: r, hidden: i } = c(e);
	return /* @__PURE__ */ f("div", {
		ref: r,
		className: n,
		style: { visibility: i ? "hidden" : void 0 },
		children: t
	});
}
function Ve() {
	return /* @__PURE__ */ f("svg", {
		className: "bruges-march",
		"aria-hidden": !0,
		children: /* @__PURE__ */ f("rect", {
			x: "2",
			y: "2",
			width: "calc(100% - 4px)",
			height: "calc(100% - 4px)",
			rx: "5"
		})
	});
}
function q({ anchor: e, legal: t, children: n, onClick: r, title: i, style: a, className: o = "" }) {
	let { ref: s, hidden: l } = c(e);
	return /* @__PURE__ */ p("button", {
		type: "button",
		ref: s,
		className: `bruges-target ${o} ${t ? "is-legal" : ""}`,
		onClick: r,
		"aria-label": i,
		title: i,
		style: {
			...a,
			visibility: l ? "hidden" : void 0
		},
		children: [n, t && /* @__PURE__ */ f(Ve, {})]
	});
}
function He(e) {
	s();
	let t = o(), n = e.public, r = e.private, [c, m] = i(e.myRid), [h, _] = i(null), [y, b] = i(null), [w, T] = i(null), [E, D] = i(null), [O, ee] = i(!1), [te, ne] = i(!1), [re, ie] = i(null), k = r?.choices ?? [], A = n.turn === e.myRid, j = n.players.find((e) => e.rid === c) ?? n.players[0], M = n.players.find((t) => t.rid === e.myRid), N = (t) => e.members.find((e) => e.rid === t)?.name ?? t, P = h && r?.hand.includes(h) ? h : null, F = E && k.some((e) => e.key === E.key) ? E : null, ae = re !== null && k.some((e) => e.key.split(":")[0] === re), oe = (e) => !ae && k.some((t) => t.key === e.key), I = (t, n = !1) => {
		oe(t) && (n ? (ie(t.key.split(":")[0]), e.send({
			type: "choose",
			key: t.key
		}), D(null), T(null), _(null), b(null)) : D(t));
	}, L = w && (r?.hand.includes(w.card) || n.discard.includes(w.card)) ? k.filter((e) => e.card === w.card && e.op === w.op && e.color === w.color && e.market === w.market) : k.filter((e) => !Be.includes(e.op)), R = (e) => L.find(e), z = (e, t = !1) => {
		b(e), t && (_(e), T(null));
	}, B = (y ? k.filter((e) => e.card === y) : []).filter((e, t, n) => n.findIndex((t) => t.op === e.op && t.color === e.color && t.market === e.market && (Be.includes(e.op) ? !0 : t.target === e.target)) === t), se = () => {
		b(null), T(null), _(null), D(null);
	}, ce = n.phase === "done" ? t(je.done) : A ? t(je[n.phase] ?? "games.bruges.settling") : n.turn ? t("games.bruges.waiting", { name: N(n.turn) }) : t("games.bruges.settling"), V = /* @__PURE__ */ p("div", {
		className: "bruges-top",
		children: [/* @__PURE__ */ f("div", {
			className: "bruges-player-tabs",
			children: n.players.map((e, r) => {
				let i = R((t) => t.op === "gift" && t.target === e.rid);
				return /* @__PURE__ */ p("button", {
					type: "button",
					className: `bruges-player-tab ${c === e.rid ? "is-viewed" : ""} ${n.turn === e.rid ? "is-current" : ""}`,
					style: { "--seat-color": ze[r] },
					onClick: () => i ? I(i) : m(e.rid),
					"aria-pressed": c === e.rid,
					children: [
						/* @__PURE__ */ p("span", {
							className: "bruges-player-name",
							children: [N(e.rid), n.first === e.rid && /* @__PURE__ */ f("span", {
								className: "bruges-first",
								"aria-label": t("games.bruges.firstPlayer"),
								children: "1"
							})]
						}),
						/* @__PURE__ */ p("span", { children: [
							/* @__PURE__ */ f("b", { children: e.vp }),
							" ",
							t("games.bruges.points"),
							/* @__PURE__ */ f(G, { name: "coin" }),
							/* @__PURE__ */ f("b", { children: e.money }),
							/* @__PURE__ */ p("span", {
								className: "bruges-hand-count",
								children: [
									e.handCount,
									" ",
									t("games.bruges.hand")
								]
							})
						] }),
						i && /* @__PURE__ */ f(Ve, {})
					]
				}, e.rid);
			})
		}), /* @__PURE__ */ p("div", {
			className: "bruges-phase",
			children: [
				/* @__PURE__ */ f("strong", { children: t("games.bruges.round", { n: n.round }) }),
				/* @__PURE__ */ f("span", { children: ce }),
				n.finalRound !== null && /* @__PURE__ */ f("b", { children: t("games.bruges.finalRound", { n: n.finalRound }) })
			]
		})]
	}), le = /* @__PURE__ */ p("div", {
		className: "bruges-city-column",
		children: [
			/* @__PURE__ */ f("div", {
				className: "bruges-city-wrap",
				children: /* @__PURE__ */ p(K, {
					name: "city",
					className: "bruges-city",
					children: [
						/* @__PURE__ */ f("img", {
							className: "bruges-city-art",
							src: a("games/bruges/city.svg"),
							alt: "",
							draggable: !1
						}),
						n.players.slice(0, 4).flatMap((n, r) => [0, 1].flatMap((i) => Le[r][i].map(([a, o], s) => {
							let c = n.rid === e.myRid ? R((e) => e.side === i && [
								"canalAction",
								"canalActionFree",
								"buildCanal",
								"buildCanalFree",
								"loseCanal"
							].includes(e.op) && s === (e.op === "loseCanal" ? n.canals[i] - 1 : n.canals[i])) : void 0, l = S[r][i][s], u = n.canals[i] > s;
							return /* @__PURE__ */ f(q, {
								anchor: `canal:${n.rid}:${i}:${s}`,
								className: `bruges-map-canal ${u ? "is-built" : ""}`,
								title: `${N(n.rid)} · ${t("games.bruges.side", { n: i + 1 })} · ${t(H[l])} · ${t("games.bruges.canalCost", { n: s + 1 })}`,
								legal: !!c,
								onClick: () => c && I(c),
								style: {
									left: a + "%",
									top: o + "%",
									"--br-color": W[l],
									"--seat-color": ze[r]
								},
								children: /* @__PURE__ */ f("span", { children: s + 1 })
							}, `${r}:${i}:${s}`);
						}))),
						n.players.map((n, r) => {
							let [i, a] = Re[n.prestige], o = n.rid === e.myRid ? R((e) => e.op === "advance") : void 0;
							return /* @__PURE__ */ f(q, {
								anchor: `prestige:${n.rid}`,
								className: "bruges-prestige-pawn",
								title: `${N(n.rid)} · ${t("games.bruges.prestige")} ${n.prestige} · ${x[n.prestige]}`,
								style: {
									left: i + r * 1.4 + "%",
									top: a + "%",
									"--seat-color": ze[r]
								},
								legal: !!o,
								onClick: () => o && I(o),
								children: /* @__PURE__ */ f("span", { children: r + 1 })
							}, n.rid);
						}),
						/* @__PURE__ */ f("div", {
							className: "bruges-statues",
							children: n.statues.map((e, t) => /* @__PURE__ */ p(K, {
								name: `statue:${t}`,
								children: [/* @__PURE__ */ f(G, { name: "statue" }), /* @__PURE__ */ f("b", { children: e })]
							}, e))
						})
					]
				})
			}),
			n.players[4] && /* @__PURE__ */ p("div", {
				className: "bruges-fifth",
				children: [/* @__PURE__ */ f("img", {
					src: a("games/bruges/fifth.svg"),
					alt: ""
				}), [0, 1].map((r) => /* @__PURE__ */ f("div", {
					className: "bruges-fifth-canal",
					children: S[4][r].map((i, a) => {
						let o = n.players[4], s = o.rid === e.myRid ? R((e) => e.side === r && [
							"canalAction",
							"canalActionFree",
							"buildCanal",
							"buildCanalFree",
							"loseCanal"
						].includes(e.op) && a === (e.op === "loseCanal" ? o.canals[r] - 1 : o.canals[r])) : void 0;
						return /* @__PURE__ */ f(q, {
							anchor: `canal:${o.rid}:${r}:${a}`,
							title: `${t("games.bruges.side", { n: r + 1 })} · ${t(H[i])}`,
							legal: !!s,
							onClick: () => s && I(s),
							className: o.canals[r] > a ? "is-built" : "",
							style: { "--br-color": W[i] },
							children: a + 1
						}, a);
					})
				}, r))]
			}),
			/* @__PURE__ */ p("div", {
				className: "bruges-table-supply",
				children: [
					/* @__PURE__ */ f("div", {
						className: "bruges-dice",
						children: g.map((e) => /* @__PURE__ */ f(K, {
							name: `die:${e}`,
							children: /* @__PURE__ */ f("div", {
								className: "bruges-die",
								style: { "--br-color": W[e] },
								"aria-label": `${t(H[e])} ${n.dice[e]}`,
								children: n.dice[e] || "·"
							})
						}, e))
					}),
					/* @__PURE__ */ p("div", {
						className: "bruges-decks",
						children: [n.stacks.map((e, n) => {
							let r = R((e) => e.op === "draw" && e.side === n);
							return /* @__PURE__ */ p(q, {
								anchor: `deck:${n}`,
								className: "bruges-deck",
								title: t("games.bruges.stack", { n: n + 1 }),
								legal: !!r,
								onClick: () => r && I(r, !0),
								style: { "--br-color": e.color ? W[e.color] : "#786853" },
								children: [/* @__PURE__ */ f("span", {
									className: "bruges-deck-crest",
									children: "BRVGGE"
								}), /* @__PURE__ */ f("b", { children: e.count })]
							}, n);
						}), /* @__PURE__ */ f(q, {
							anchor: "discard",
							className: "bruges-discard",
							legal: k.some((e) => e.op === "recruitDiscard" || e.op === "discardHouse"),
							title: t("games.bruges.discardPile"),
							onClick: () => ee(!0),
							children: n.discard.length ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(G, {
								name: "house",
								color: v[n.discard[n.discard.length - 1]].color
							}), /* @__PURE__ */ f("b", { children: n.discard.length })] }) : /* @__PURE__ */ f("span", { children: t("games.bruges.discardPile") })
						})]
					}),
					/* @__PURE__ */ p("small", { children: [t("games.bruges.reserve", { n: n.reserveCount }), r?.drawnCount ? ` · ${t("games.bruges.drawnCount", { n: r.drawnCount })}` : ""] })
				]
			}),
			(n.config.ships || n.config.market) && /* @__PURE__ */ p("div", {
				className: "bruges-expansions",
				children: [n.ships.map((e) => {
					let n = R((t) => t.op === "ship" && t.color === e.color);
					return /* @__PURE__ */ p(q, {
						anchor: `ship:${e.color}`,
						className: `bruges-ship ${e.active ? "has-arrived" : ""}`,
						title: `${t(H[e.color])} · ${t(Me[e.effect])}`,
						style: { "--br-color": W[e.color] },
						legal: !!n,
						onClick: () => n && I(n),
						children: [
							/* @__PURE__ */ f(G, {
								name: "ship",
								color: e.color
							}),
							/* @__PURE__ */ p("span", { children: [
								t(H[e.color]),
								" · ",
								t(e.active ? "games.bruges.arrived" : "games.bruges.atSea")
							] }),
							/* @__PURE__ */ f("strong", { children: t(Me[e.effect]) }),
							e.active && e.next !== null && /* @__PURE__ */ p("small", { children: [
								t("games.bruges.nextShip"),
								": ",
								t(Me[e.next])
							] })
						]
					}, e.color);
				}), n.market && /* @__PURE__ */ p(K, {
					name: "market",
					className: "bruges-market",
					children: [
						/* @__PURE__ */ f("strong", { children: t(C[n.market.id].nameKey) }),
						/* @__PURE__ */ f("span", { children: t(C[n.market.id].textKey) }),
						/* @__PURE__ */ f("small", { children: t("games.bruges.marketLeft", { n: n.market.uses }) })
					]
				})]
			})
		]
	}), ue = /* @__PURE__ */ p("section", {
		className: "bruges-estate",
		children: [
			/* @__PURE__ */ p("div", {
				className: "bruges-estate-heading",
				children: [
					/* @__PURE__ */ f("strong", { children: N(j.rid) }),
					/* @__PURE__ */ p("span", { children: [
						t("games.bruges.houses"),
						" ",
						j.houses.length,
						" · ",
						t("games.bruges.peopleLabel"),
						" ",
						j.houses.filter((e) => e.person).length
					] }),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "bruges-tool",
						onClick: () => ne(!0),
						children: t("games.bruges.log")
					})
				]
			}),
			/* @__PURE__ */ f("div", {
				className: "bruges-resources",
				children: g.map((n) => {
					let r = j.rid === e.myRid ? R((e) => e.color === n && [
						"worker",
						"giveWorker",
						"storeWorker",
						"sellWorker",
						"exchangeGive",
						"sellColor"
					].includes(e.op)) : void 0, i = j.rid === e.myRid ? R((e) => e.color === n && [
						"remove",
						"giveThreat",
						"disaster",
						"protect"
					].includes(e.op) || e.op === "removeAction" && e.other === n) : void 0;
					return /* @__PURE__ */ p("div", {
						className: "bruges-resource-color",
						style: { "--br-color": W[n] },
						children: [/* @__PURE__ */ p(q, {
							anchor: `workers:${j.rid}:${n}`,
							className: "bruges-worker-count",
							title: `${t(H[n])} ${t("games.bruges.workers")} ${j.workers[n]}`,
							legal: !!r,
							onClick: () => r && I(r),
							children: [/* @__PURE__ */ f(G, {
								name: "worker",
								color: n
							}), /* @__PURE__ */ f("b", { children: j.workers[n] })]
						}), /* @__PURE__ */ p(q, {
							anchor: `threats:${j.rid}:${n}`,
							className: `bruges-threat-count ${j.threats[n] >= 2 ? "is-danger" : ""}`,
							title: `${t(H[n])} ${t("games.bruges.threats")} ${j.threats[n]}`,
							legal: !!i,
							onClick: () => i && I(i),
							children: [/* @__PURE__ */ f(G, {
								name: "threat",
								color: n
							}), /* @__PURE__ */ f("b", { children: j.threats[n] })]
						})]
					}, n);
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "bruges-majorities",
				children: [
					[
						"prestige",
						"people",
						"canals"
					].map((e, n) => /* @__PURE__ */ p("span", {
						className: j.majorities[n] ? "is-claimed" : "",
						title: t("games.bruges.majorities"),
						children: [/* @__PURE__ */ f(G, { name: `majority-${e}` }), /* @__PURE__ */ f("b", { children: j.majorities[n] ? 4 : 0 })]
					}, e)),
					/* @__PURE__ */ p(K, {
						name: `money:${j.rid}`,
						children: [/* @__PURE__ */ f(G, { name: "coin" }), /* @__PURE__ */ f("b", { children: j.money })]
					}),
					/* @__PURE__ */ p(K, {
						name: `vp:${j.rid}`,
						children: [
							/* @__PURE__ */ f("b", { children: j.vp }),
							" ",
							t("games.bruges.points")
						]
					})
				]
			}),
			/* @__PURE__ */ p(K, {
				name: `estate:${j.rid}`,
				className: "bruges-houses",
				children: [j.houses.map((n) => {
					let r = j.rid === e.myRid ? R((e) => e.house === n.id && [
						"person",
						"recruitDiscard",
						"loseHouse"
					].includes(e.op)) : void 0, i = n.person ? L.filter((e) => e.card === n.person && (!e.target || e.target === j.rid)) : [];
					return /* @__PURE__ */ p("div", {
						className: "bruges-house",
						style: { "--house-color": W[n.color] },
						children: [
							/* @__PURE__ */ p(q, {
								anchor: `house:${j.rid}:${n.id}`,
								className: "bruges-house-roof",
								legal: !!r,
								title: `${t("games.bruges.houseColor", { color: t(H[n.color]) })}${n.person ? "" : " · " + t("games.bruges.emptyHouse")}`,
								onClick: () => r && I(r),
								children: [/* @__PURE__ */ f(G, {
									name: "house",
									color: n.color
								}), /* @__PURE__ */ f("span", { children: t(H[n.color]) })]
							}),
							n.person ? /* @__PURE__ */ f(Ie, {
								id: n.person,
								anchor: `person:${j.rid}:${n.person}`,
								used: j.used.includes(n.person),
								legal: i.length > 0,
								onClick: () => z(n.person),
								compact: !0
							}) : /* @__PURE__ */ p("button", {
								type: "button",
								className: `bruges-house-empty ${r ? "is-legal" : ""}`,
								onClick: () => r && I(r),
								disabled: !r,
								children: [/* @__PURE__ */ f("span", { children: t("games.bruges.emptyHouse") }), r && /* @__PURE__ */ f(Ve, {})]
							}),
							!!(n.person && j.storedWorkers[n.person]) && /* @__PURE__ */ f("small", { children: t("games.bruges.stored", { n: j.storedWorkers[n.person] }) })
						]
					}, n.id);
				}), !j.houses.length && /* @__PURE__ */ p("div", {
					className: "bruges-empty-estate",
					children: [/* @__PURE__ */ f(G, {
						name: "house",
						color: "brown"
					}), /* @__PURE__ */ f("span", { children: t("games.bruges.noHouses") })]
				})]
			})
		]
	}), de = k.filter((e) => [
		"skip",
		"endTurn",
		"exchangeDone"
	].includes(e.op)), fe = /* @__PURE__ */ p("div", {
		className: "bruges-hand-area",
		children: [/* @__PURE__ */ f(K, {
			name: `hand:${e.myRid}`,
			className: "bruges-hand",
			children: r?.hand.map((t) => /* @__PURE__ */ f(Ie, {
				id: t,
				selected: P === t,
				legal: k.some((e) => e.card === t),
				anchor: `handcard:${e.myRid}:${t}`,
				onClick: () => z(t, !0)
			}, t))
		}), /* @__PURE__ */ p("div", {
			className: "bruges-bottom",
			children: [
				/* @__PURE__ */ f("span", { children: w ? t(U[w.op]) : A ? t("games.bruges.turnCount", { n: n.turnNumber }) : ce }),
				(P || w) && /* @__PURE__ */ f("button", {
					type: "button",
					className: "bruges-tool",
					onClick: se,
					children: t("games.bruges.cancel")
				}),
				de.map((e) => /* @__PURE__ */ f("button", {
					type: "button",
					className: "bruges-control",
					disabled: ae,
					onClick: () => I(e, !0),
					children: t(U[e.op])
				}, e.key))
			]
		})]
	}), pe = (y || F || O || te) && /* @__PURE__ */ f("div", {
		className: "bruges-modal-backdrop",
		onClick: () => {
			se(), ee(!1), ne(!1);
		},
		children: /* @__PURE__ */ p("div", {
			className: "bruges-modal",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": t("games.bruges.details"),
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ f("button", {
				type: "button",
				className: "bruges-close",
				"aria-label": t("games.bruges.close"),
				onClick: () => {
					se(), ee(!1), ne(!1);
				},
				children: "×"
			}), F ? /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("strong", { children: Pe(F, t) }),
				F.target && /* @__PURE__ */ f("span", { children: N(F.target) }),
				F.house && /* @__PURE__ */ f("span", { children: t("games.bruges.houseColor", { color: t(H[M.houses.find((e) => e.id === F.house).color]) }) }),
				F.side !== void 0 && /* @__PURE__ */ f("span", { children: t("games.bruges.side", { n: F.side + 1 }) }),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "bruges-control",
					onClick: () => I(F, !0),
					children: t("games.bruges.confirm")
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "bruges-tool",
					onClick: () => D(null),
					children: t("games.bruges.cancel")
				})
			] }) : y ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("div", {
				className: "bruges-detail-top",
				children: [/* @__PURE__ */ f(Ie, {
					id: y,
					compact: !0
				}), /* @__PURE__ */ p("div", { children: [
					/* @__PURE__ */ f("h2", { children: t(v[y].nameKey) }),
					/* @__PURE__ */ f("p", { children: t(Fe[v[y].group]) }),
					/* @__PURE__ */ f("p", { children: t(v[y].textKey) }),
					g.includes(v[y].activation) && /* @__PURE__ */ f("p", { children: t("games.bruges.onceWorker", { color: t(H[v[y].activation]) }) })
				] })]
			}), /* @__PURE__ */ f("div", {
				className: "bruges-card-tools",
				children: B.map((n) => /* @__PURE__ */ p("button", {
					type: "button",
					className: "bruges-action-object",
					disabled: ae,
					style: { "--br-color": W[n.color ?? v[y].color] },
					onClick: () => {
						(Be.includes(n.op) || n.op === "recruitDiscard") && (n.house || n.side !== void 0 || n.other) ? (T({
							card: y,
							op: n.op,
							color: n.color,
							market: n.market
						}), b(null), (n.house || n.other) && m(e.myRid), ee(!1)) : I(n);
					},
					children: [
						/* @__PURE__ */ f("span", { children: t(U[n.op]) }),
						n.market && /* @__PURE__ */ f("small", { children: t(C[n.market].nameKey) }),
						n.color && /* @__PURE__ */ f("small", { children: t(H[n.color]) }),
						n.cost !== void 0 && /* @__PURE__ */ f("small", { children: Ne(n, t) }),
						n.n !== void 0 && /* @__PURE__ */ f("b", { children: n.n })
					]
				}, n.key))
			})] }) : O ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("h2", { children: t("games.bruges.discardPile") }), /* @__PURE__ */ f("div", {
				className: "bruges-discard-grid",
				children: n.discard.map((e) => /* @__PURE__ */ f(Ie, {
					id: e,
					legal: k.some((t) => t.card === e),
					onClick: () => z(e),
					compact: !0
				}, e))
			})] }) : /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("h2", { children: t("games.bruges.log") }), /* @__PURE__ */ f("div", {
				className: "bruges-log",
				children: n.log.slice(-100).reverse().map((e) => /* @__PURE__ */ p("p", { children: [
					e.who ? N(e.who) + " · " : "",
					t(U[e.event] ?? (e.event === "advance" ? "games.bruges.ops.advance" : e.event === "draw" ? "games.bruges.ops.draw" : e.event === "majority" ? "games.bruges.events.majority" : e.event === "roll" ? "games.bruges.events.roll" : "games.bruges.settling")),
					e.card ? " · " + t(v[e.card].nameKey) : "",
					e.color ? " · " + t(H[e.color]) : "",
					e.n === void 0 ? "" : " · " + e.n
				] }, e.id))
			})] })]
		})
	});
	return /* @__PURE__ */ p("div", {
		className: "bruges-root",
		children: [
			/* @__PURE__ */ f(l, {
				kind: "sheen",
				base: "#583c2c",
				className: "absolute inset-0"
			}),
			/* @__PURE__ */ f(u, {
				adaptive: !0,
				banner: V,
				actions: fe,
				actionsHeight: "bruges-action-slot",
				scroll: !1,
				className: "bruges-screen",
				overlay: pe,
				children: /* @__PURE__ */ p("div", {
					className: "bruges-main",
					children: [le, ue]
				})
			}),
			!M && /* @__PURE__ */ f("span", {
				className: "sr-only",
				children: t("games.bruges.waiting", { name: N(n.turn) })
			})
		]
	});
}
//#endregion
//#region src/games/bruges/bot.ts
var Ue = {
	money: .42,
	worker: .9,
	engine: .6,
	majority: 1.4,
	danger: 1.1,
	keepCard: .3,
	housing: 2,
	canal: .9
}, J = (e) => e.houses.flatMap((e) => e.person ? [e.person] : []), We = (e, t) => J(e).filter((e) => v[e].group === t).length, Ge = (e) => new Set(J(e).map((e) => v[e].group)).size, Ke = (e) => g.reduce((t, n) => t + e.workers[n], 0), qe = (e) => Math.max(.5, (e.finalRound ?? Math.max(e.round + 2, 9)) - e.round + (5 - e.turnNumber) / 4);
function Y(e, t, n) {
	let r = J(e).filter((e) => v[e].activation === t).length;
	return n.worker * (e.workers[t] === 0 ? 1.5 + r * .3 : 1 / (1 + e.workers[t] * .45));
}
function X(e, t, n) {
	return t * n.money * (e.money < 4 ? 1.6 : e.money > 12 ? .5 : 1);
}
function Z(e, t, n) {
	let r = {
		blue: Ke(e) * .7,
		brown: J(e).length ? 4 : 0,
		yellow: e.money * n.money,
		red: e.houses.length || e.canals.some(Boolean) ? 4 : 0,
		purple: Math.min(3, e.vp)
	};
	return 1 + (e.threats[t] >= 2 ? r[t] * n.danger * .65 : .2);
}
function Je(e, t, n, r) {
	let [i, a] = e.parameter.split(","), o = Number(i) || 1, s = Number(a) || 0, c = () => We(n, i) + +(e.group === i), l = (e) => X(n, e, r), u = (e) => g.map((e) => ({
		color: e,
		value: n.threats[e] ? Z(n, e, r) : 0
	})).sort((e, t) => t.value - e.value).slice(0, e).reduce((e, t) => e + t.value, 0);
	switch (e.effect) {
		case "money": return l(o);
		case "vp": return o;
		case "workerVp": return Y(n, i, r) + s;
		case "workerMoney": return Y(n, i, r) + l(s);
		case "vpMoney": return o + l(s);
		case "moneyHouse": return l(2 * n.houses.filter((e) => e.color === i).length);
		case "moneyHouseColors": return l(o * new Set(n.houses.map((e) => e.color)).size);
		case "moneyPerson": return l(o * (J(n).length + 1));
		case "moneyGroup": return l(2 * c());
		case "moneyGroups": return l(Ge(n) + +!J(n).some((t) => v[t].group === e.group));
		case "vpGroup": return c();
		case "vpThreeHouses": return n.houses.filter((e) => e.color === i).length >= 3 ? 2 : .2;
		case "vpDice": return g.filter((e) => t.dice[e] === o).length;
		case "moneyDice": return l(g.filter((e) => t.dice[e] === o).length);
		case "vpCanals": return Math.floor((n.canals[0] + n.canals[1]) / 3);
		case "vpCompletedCanals": return o * n.canals.filter((e) => e === 5).length;
		case "worker": return o * Math.max(...g.map((e) => Y(n, e, r)));
		case "buyWorkers": return Math.min(o, n.money) * .5;
		case "removeAny": return u(o);
		case "removeColor": return n.threats[i] ? Z(n, i, r) : 0;
		case "removePerPerson": return u(J(n).length + 1);
		case "advance": return x[Math.min(8, n.prestige + 1)] - x[n.prestige] + .4;
		case "draw":
		case "drawPlay":
		case "playExtra":
		case "playDiscardTop": return o * 2.2;
		case "drawHouses": return o * (1 + r.housing);
		case "drawDiscard": return o * .5;
		case "canalDouble": return n.money >= 2 ? 1.2 : 0;
		case "freeCanal": return n.canals.some((e) => e < 5) ? 3.8 : 0;
		case "exchangeWorkers": return g.some((e) => n.workers[e] === 0) && Ke(n) > 1 ? 1 : 0;
		case "activateAll": return J(n).filter((e) => g.includes(v[e].activation)).length * 1.5;
		case "attackCanal":
		case "attackHouse":
		case "attackPerson": return t.players.filter((t) => t !== n && (e.effect === "attackCanal" ? t.canals.some(Boolean) : e.effect === "attackHouse" ? t.houses.length : J(t).length)).length * 1.2;
		case "attackHand":
		case "attackAdvance":
		case "attackThreat": return (t.players.length - 1) * .6;
		case "stealMoney": return l(t.players.filter((e) => e.rid !== n.rid).reduce((e, t) => e + Math.min(o, t.money), 0));
		case "stealWorkers": return (t.players.length - 1) * o * r.worker;
		case "giftMoneyVp": return Math.min(n.money, t.players.length - 1) * (1 - r.money);
		case "recruitDiscard": return t.discard.some((e) => v[e].group === i) && n.houses.some((e) => !e.person) ? 4 : .2;
		case "discardHouse": return t.discard.some((e) => n.workers[v[e].color] > 0) ? 1 + r.housing : 0;
		case "wildNext": return 1.2;
		case "moneyWorkerColors": return l(g.filter((e) => n.workers[e]).length);
		case "moneyThreatColors": return l(o * g.filter((e) => n.threats[e]).length);
		case "sellWorkerColors": return g.reduce((e, t) => e + (n.workers[t] ? Math.max(0, 1 + l(1) - Y(n, t, r)) : 0), 0);
		case "giveThreats": return u(t.players.length - 1);
		case "storeWorker": return Math.max(0, 1 - Math.min(...g.map((e) => Y(n, e, r))));
		case "sellWorkerDie": return Math.max(0, ...g.map((e) => n.workers[e] ? l(t.dice[e]) - Y(n, e, r) : 0));
		case "returnPerson": return .1;
		case "workersDiceOne": return g.filter((e) => t.dice[e] === 1).reduce((e, t) => e + Y(n, t, r), 0);
		case "copyOpponent": return 3;
		case "readyPerson": return J(n).some((e) => n.used.includes(e)) ? 1.8 : 0;
		case "stealRandomCards": return t.players.filter((e) => e.rid !== n.rid && e.handCount).length * 2;
		case "endGroup": return s * (c() + qe(t) * .2);
		case "endGroups": return o * (Ge(n) + 1);
		case "endWorkers": return Ke(n) / o;
		case "endThreat": return g.reduce((e, t) => e + n.threats[t], 0);
		case "endMajority": return o * (n.majorities.filter(Boolean).length + .5);
		case "endCanalMilestones": return o * (n.canals.filter((e) => e >= 3).length + n.statues.length + .3);
		case "endFiveColors": return o * new Set(n.houses.map((e) => e.color)).size / 6;
		case "endWildGroups": return 2;
		default: return 1.2;
	}
}
function Q(e, t, n, r) {
	let i = Je(e, t, n, r), a = qe(t), o = e.activation === "I" || e.activation === "E" ? i : e.activation === "P" ? i * a * r.engine : Math.max(0, i - (e.activation === "F" ? 0 : r.worker * .65)) * Math.min(4, a) * r.engine;
	return e.cost / 3 + o;
}
function Ye(e, t, n, r, i, a) {
	let o = e.card ? v[e.card] : null, s = e.color ?? "blue", c = o && [
		"workers",
		"money",
		"removeAction",
		"house",
		"canalAction",
		"canalActionFree",
		"discard"
	].includes(e.op) ? Q(o, t, r, i) * i.keepCard : 0, l = () => {
		let n = r.canals[e.side], a = Math.max(...t.players.filter((e) => e.rid !== r.rid).map((e) => e.canals[0] + e.canals[1]));
		return (n === 2 ? 3 : n === 4 ? t.statues[0] ?? 0 : i.canal * (n + 1)) + (r.canals[0] + r.canals[1] >= a && !r.majorities[2] ? i.majority : 0) - X(r, e.cost ?? 0, i);
	}, u = 0;
	switch (e.op) {
		case "workers":
			u = (e.n ?? 2) * Y(r, s, i);
			break;
		case "money":
			u = X(r, e.n ?? 0, i);
			break;
		case "removeAction":
			u = Z(r, e.other ?? s, i);
			break;
		case "house":
			u = 1 + (r.houses.some((e) => !e.person) ? .2 : i.housing) - (e.cost ?? 1) * Y(r, s, i);
			break;
		case "person":
			u = Q(o, t, r, i) - X(r, e.cost ?? o.cost, i) + (r.majorities[1] ? 0 : .5);
			break;
		case "canalAction":
		case "canalActionFree":
		case "buildCanal":
		case "buildCanalFree":
			u = l();
			break;
		case "activate":
		case "freeActivate":
		case "copy":
			u = Je(o, t, r, i) - (e.op === "activate" && e.color ? Y(r, e.color, i) : 0);
			break;
		case "recruitDiscard":
			u = Q(o, t, r, i);
			break;
		case "discardHouse":
			u = 1 + i.housing - Y(r, s, i);
			break;
		case "draw": {
			let e = t.players.findIndex((e) => e.rid === r.rid);
			u = 1 + (r.canals.some((t, n) => t < 5 && S[e][n][t] === s) ? .5 : 0) + Y(r, s, i) * .15 - n.hand.filter((e) => v[e].color === s).length * .2;
			break;
		}
		case "advance":
			u = x[r.prestige + 1] - x[r.prestige] + (r.majorities[0] ? 0 : i.majority) - X(r, e.cost ?? 0, i);
			break;
		case "protect":
			u = r.threats[s] * Z(r, s, i);
			break;
		case "remove":
		case "giveThreat":
			u = Z(r, s, i);
			break;
		case "worker":
			u = Y(r, s, i) - (t.phase === "buyWorkers" ? X(r, 1, i) : 0);
			break;
		case "storeWorker":
			u = 1 - Y(r, s, i);
			break;
		case "sellWorker":
			u = X(r, e.n ?? 0, i) - Y(r, s, i);
			break;
		case "sellColor":
			u = 1 + X(r, 1, i) - Y(r, s, i);
			break;
		case "gift":
			u = 1 - X(r, 1, i);
			break;
		case "discard":
			u = -Q(o, t, r, i) * .3;
			break;
		case "losePerson":
			u = -Q(o, t, r, i);
			break;
		case "loseHouse": {
			let n = r.houses.find((t) => t.id === e.house);
			u = -1 - (n.person ? Q(v[n.person], t, r, i) * .5 : 0);
			break;
		}
		case "loseCanal":
			u = -(r.canals[e.side] === 3 ? 3 : 1);
			break;
		case "disaster":
			u = s === "blue" && r.threats.brown >= 3 ? -5 : s === "purple" ? -Math.min(3, r.vp) : -1;
			break;
		case "giveWorker":
			u = -Y(r, s, i);
			break;
		case "ready":
			u = Je(o, t, r, i) - (g.includes(o.activation) ? Y(r, o.activation, i) : 0);
			break;
		case "returnPerson":
			u = o.activation === "I" && o.cost <= 3 && qe(t) > 1 ? .2 : -5;
			break;
		case "exchangeGive":
			u = a < 3 && r.workers[s] > 1 && g.some((e) => r.workers[e] === 0) ? 1 : -1;
			break;
		case "ship":
			u = [
				3 * i.worker,
				X(r, 6, i),
				Math.max(...g.map((e) => r.threats[e] ? Z(r, e, i) : 0)) * 1.5,
				Math.max(0, ...J(r).filter((e) => v[e].activation === "I").map((e) => Je(v[e], t, r, i))),
				3,
				2.2
			][e.n] - Y(r, s, i);
			break;
		case "exchangeDone":
		case "endTurn":
		case "skip": u = 0;
	}
	return e.market === "m05" && (u += 1), e.market === "m06" && (u += Math.min(r.threats[e.other ?? s], J(r).some((e) => v[e].effect === "removeActionBonus") ? 2 : 1)), e.market === "m09" && (u += Math.max(...g.map((e) => Y(r, e, i)))), e.market === "m10" && (u += Je(o, t, r, i)), e.market === "m11" && (u = (e.n ?? 2) * Math.max(...g.map((e) => Y(r, e, i)))), u - c;
}
function Xe(e = {}) {
	let t = {
		...Ue,
		...e
	};
	return (e, n) => {
		let r = e.private, i = e.public;
		if (!r) return null;
		let a = r.choices;
		if (!a.length || i.turn !== n.rid) return null;
		let o = i.players.find((e) => e.rid === n.rid), s = n.memory, c = i.phase === "exchangeGive" && s?.phase === "exchangeGive" ? s.exchangeCount ?? 0 : 0, l = a.map((e) => ({
			c: e,
			score: Ye(e, i, r, o, t, c)
		}));
		l.sort((e, t) => t.score - e.score || e.c.key.localeCompare(t.c.key, void 0, { numeric: !0 }));
		let u = n.difficulty === "weak" ? l[Math.floor(crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967296 * Math.min(4, l.length))].c : l[0].c;
		return {
			action: {
				type: "choose",
				key: u.key
			},
			memory: {
				phase: i.phase,
				exchangeCount: c + +(u.op === "exchangeGive")
			}
		};
	};
}
var Ze = Xe(), Qe = (e, t, n) => {
	let r = e.type === "choose" ? t.private?.choices.find((t) => t.key === e.key) : null;
	return r ? Pe(r, n) : n("games.bruges.settling");
}, $ = 320;
function $e({ from: e, to: t, children: i, ms: a }) {
	let o = r(null);
	return n(() => {
		let n = o.current;
		if (!n) return;
		let r = Math.min(1.5, Math.max(.3, Math.min(e.w / t.w, e.h / t.h))), i = n.animate([
			{
				transform: `translate(0,0) scale(${r})`,
				opacity: .8
			},
			{
				transform: `translate(${(t.x - e.x) * .5}px,${(t.y - e.y) * .5 - 18}px) scale(1.05)`,
				opacity: 1,
				offset: .5
			},
			{
				transform: `translate(${t.x - e.x}px,${t.y - e.y}px) scale(1)`,
				opacity: 1
			}
		], {
			duration: a,
			easing: "cubic-bezier(.2,.65,.3,1)",
			fill: "both"
		});
		return () => i.cancel();
	}, [
		e,
		t,
		a
	]), /* @__PURE__ */ f("div", {
		ref: o,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: t.w,
			height: t.h,
			pointerEvents: "none",
			transformOrigin: "center",
			zIndex: 5
		},
		children: i
	});
}
function et({ box: e, loss: t, children: i, ms: a }) {
	let o = r(null);
	return n(() => {
		let e = o.current?.animate([
			{
				transform: "scale(.7)",
				opacity: .2
			},
			{
				transform: "scale(1.08)",
				opacity: 1,
				offset: .35
			},
			{
				transform: t ? "scale(.6) translateY(16px)" : "scale(1)",
				opacity: 0
			}
		], {
			duration: a,
			easing: "ease-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, [t, a]), /* @__PURE__ */ f("div", {
		ref: o,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			border: `3px solid ${t ? "#bb4e32" : "#f5d66b"}`,
			borderRadius: 5,
			boxShadow: "0 0 12px #ffe8a0",
			display: "grid",
			placeItems: "center",
			fontSize: 22,
			fontWeight: 900,
			color: t ? "#9e382c" : "#fff3bf",
			textShadow: "0 1px 3px #2b1a0c",
			pointerEvents: "none"
		},
		children: i
	});
}
var tt = {
	flight(e, t) {
		let n = e.data, r = t.anchor(n.from) ?? t.anchor("city"), i = t.anchor(n.to) ?? t.anchor(n.to.startsWith("person:") || n.to.startsWith("house:") ? "estate:" + n.to.split(":")[1] : n.to);
		if (!r || !i) return null;
		let o = t.queued ? 160 : $, s = {
			...i,
			w: Math.min(i.w, 98),
			h: Math.min(i.h, 140)
		};
		return {
			ms: o,
			hide: !t.queued && (n.to.startsWith("person:") || n.to.startsWith("house:")) ? [n.to] : void 0,
			node: /* @__PURE__ */ f($e, {
				from: r,
				to: s,
				ms: o,
				children: /* @__PURE__ */ f("div", {
					style: {
						height: "100%",
						width: "100%",
						background: n.house ? W[n.house] : "#ead4a6",
						border: "2px solid #5c3c24",
						borderRadius: 5,
						boxShadow: "0 4px 10px #24170d70",
						display: "grid",
						placeItems: "center",
						overflow: "hidden"
					},
					children: n.card ? /* @__PURE__ */ f("img", {
						src: a(`games/bruges/people/${n.card}.svg`),
						style: {
							width: "100%",
							height: "100%",
							objectFit: "cover"
						},
						alt: ""
					}) : n.house ? /* @__PURE__ */ f(G, {
						name: "house",
						color: n.house
					}) : /* @__PURE__ */ f("span", {
						style: {
							color: "#735426",
							font: "bold 12px serif",
							border: "3px double #a28540",
							padding: 6
						},
						children: "BRVGGE"
					})
				})
			})
		};
	},
	resource(e, t) {
		let n = e.data, r = t.anchor(n.anchor) ?? (e.rid ? t.anchor(`estate:${e.rid}`) : null);
		if (!r) return null;
		let i = t.queued ? 150 : $;
		return {
			ms: i,
			node: /* @__PURE__ */ f(et, {
				box: r,
				loss: n.delta < 0,
				ms: i,
				children: /* @__PURE__ */ p("span", {
					style: {
						display: "flex",
						alignItems: "center",
						gap: 3
					},
					children: [
						n.piece === "worker" && /* @__PURE__ */ f(G, {
							name: "worker",
							color: n.color
						}),
						n.delta > 0 ? "+" : "",
						n.delta
					]
				})
			})
		};
	},
	pulse(e, t) {
		let n = e.data, r = t.anchor(n.anchor);
		return r ? {
			ms: $,
			node: /* @__PURE__ */ f(et, {
				box: r,
				ms: $
			})
		} : null;
	},
	canal(e, t) {
		let n = e.data, r = t.anchor(n.anchor);
		if (!r) return null;
		let i = t.anchor("city") ?? r, a = t.queued ? 160 : $;
		return {
			ms: a,
			node: n.loss ? /* @__PURE__ */ f(et, {
				box: r,
				loss: !0,
				ms: a
			}) : /* @__PURE__ */ f($e, {
				from: {
					x: i.x + i.w / 2,
					y: i.y + i.h / 2,
					w: r.w,
					h: r.h
				},
				to: r,
				ms: a,
				children: /* @__PURE__ */ f("span", { style: {
					display: "block",
					width: "100%",
					height: "100%",
					background: "#76afb4",
					border: "2px solid #d8eeec",
					boxShadow: "0 2px 4px #342116"
				} })
			})
		};
	}
}, nt = [
	{
		key: "points",
		label: "games.bruges.points"
	},
	{
		key: "people",
		label: "games.bruges.peopleLabel"
	},
	{
		key: "houses",
		label: "games.bruges.houses"
	},
	{
		key: "abilities",
		label: "games.bruges.abilities"
	},
	{
		key: "majorities",
		label: "games.bruges.majorities"
	},
	{
		key: "canals",
		label: "games.bruges.canals"
	},
	{
		key: "statues",
		label: "games.bruges.statues"
	},
	{
		key: "prestige",
		label: "games.bruges.prestige"
	}
];
function rt(e) {
	let t = o(), n = e.public, [r, s] = i(!1), [c, l] = i(e.myRid), u = (t) => e.members.find((e) => e.rid === t)?.name ?? t, h = e.result.ranking;
	return /* @__PURE__ */ p("div", {
		className: "bruges-over",
		children: [
			/* @__PURE__ */ p("div", {
				className: `bruges-over-content ${r ? "is-hidden" : ""}`,
				style: { backgroundImage: `url("${a("games/bruges/city.svg")}")` },
				children: [/* @__PURE__ */ p("header", { children: [
					/* @__PURE__ */ f(G, { name: "statue" }),
					/* @__PURE__ */ p("div", { children: [
						/* @__PURE__ */ f("span", { children: t("games.bruges.name") }),
						/* @__PURE__ */ f("h1", { children: e.result.winner.length === 1 ? t("games.bruges.winner", { name: u(e.result.winner[0]) }) : t("games.bruges.tieWinner") }),
						e.hintCount !== void 0 && /* @__PURE__ */ f("p", { children: t("session.hint.usedCount", { n: e.hintCount }) })
					] }),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "bruges-tool bruges-review-toggle",
						"aria-label": t("games.bruges.replayBoard"),
						title: t("games.bruges.replayBoard"),
						onClick: () => s(!0),
						children: /* @__PURE__ */ f(m, { size: 24 })
					})
				] }), /* @__PURE__ */ p("div", {
					className: "bruges-over-ledger",
					children: [/* @__PURE__ */ f("div", {
						className: "bruges-over-ranks",
						children: h.map((t, r) => {
							let i = n.players.find((e) => e.rid === t), a = h.findIndex((e) => {
								let t = n.players.find((t) => t.rid === e);
								return t.score.total === i.score.total && t.money === i.money;
							}) + 1;
							return /* @__PURE__ */ p("button", {
								type: "button",
								className: `bruges-rank ${e.result.winner.includes(t) ? "is-winner" : ""} ${c === t ? "is-selected" : ""}`,
								"aria-pressed": c === t,
								onClick: () => l(t),
								children: [
									/* @__PURE__ */ f("span", {
										className: "bruges-rank-number",
										children: a || r + 1
									}),
									/* @__PURE__ */ f("strong", { children: u(t) }),
									/* @__PURE__ */ f("b", { children: i.score?.total ?? 0 }),
									/* @__PURE__ */ p("small", { children: [/* @__PURE__ */ f(G, { name: "coin" }), i.money] })
								]
							}, t);
						})
					}), /* @__PURE__ */ p("section", {
						className: "bruges-score-ledger",
						children: [/* @__PURE__ */ f("h2", { children: t("games.bruges.scoreDetail") }), /* @__PURE__ */ f("div", {
							className: "bruges-score-scroll",
							children: /* @__PURE__ */ p("table", { children: [/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
								scope: "col",
								children: t("games.bruges.points")
							}), h.map((e) => /* @__PURE__ */ f("th", {
								scope: "col",
								className: e === c ? "is-selected" : "",
								children: u(e)
							}, e))] }) }), /* @__PURE__ */ f("tbody", { children: [...nt, {
								key: "total",
								label: "games.bruges.total"
							}].map(({ key: e, label: r }) => /* @__PURE__ */ p("tr", {
								className: e === "total" ? "bruges-total" : "",
								children: [/* @__PURE__ */ f("th", {
									scope: "row",
									children: t(r)
								}), h.map((t) => /* @__PURE__ */ f("td", {
									className: t === c ? "is-selected" : "",
									children: n.players.find((e) => e.rid === t)?.score?.[e] ?? 0
								}, t))]
							}, e)) })] })
						})]
					})]
				})]
			}),
			/* @__PURE__ */ f("div", {
				className: `bruges-over-board ${r ? "" : "is-hidden"}`,
				children: /* @__PURE__ */ f(He, {
					public: n,
					private: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => {}
				})
			}),
			/* @__PURE__ */ p("footer", {
				className: "bruges-over-footer",
				children: [r && /* @__PURE__ */ f("button", {
					type: "button",
					className: "bruges-control",
					onClick: () => s(!1),
					children: t("games.bruges.backResults")
				}), e.onPlayAgain ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
					type: "button",
					className: "bruges-control",
					onClick: e.onPlayAgain,
					children: t("games.bruges.playAgain")
				}), e.onBackToLobby && /* @__PURE__ */ f("button", {
					type: "button",
					className: "bruges-tool",
					onClick: e.onBackToLobby,
					children: t("games.bruges.backLobby")
				})] }) : /* @__PURE__ */ f("span", { children: t("games.bruges.hostWaiting") })]
			})
		]
	});
}
//#endregion
//#region src/games/bruges/options.tsx
function it({ value: e, onChange: t }) {
	let n = o(), r = E.safeParse(e), i = r.success ? r.data : E.parse({});
	return /* @__PURE__ */ p("div", { children: [
		/* @__PURE__ */ f(h, {
			checked: i.newCitizens || i.fifthPlayer,
			disabled: i.fifthPlayer,
			label: n("games.bruges.options.newCitizens"),
			hint: n("games.bruges.options.newCitizensHint"),
			onChange: () => t({
				...i,
				newCitizens: !i.newCitizens
			})
		}),
		/* @__PURE__ */ f(h, {
			checked: i.fifthPlayer,
			label: n("games.bruges.options.fifthPlayer"),
			hint: n("games.bruges.options.fifthPlayerHint"),
			onChange: () => t({
				...i,
				fifthPlayer: !i.fifthPlayer,
				newCitizens: !i.fifthPlayer || i.newCitizens
			})
		}),
		/* @__PURE__ */ f(h, {
			checked: i.ships,
			label: n("games.bruges.options.ships"),
			hint: n("games.bruges.options.shipsHint"),
			onChange: () => t({
				...i,
				ships: !i.ships
			})
		}),
		/* @__PURE__ */ f(h, {
			checked: i.market,
			label: n("games.bruges.options.market"),
			hint: n("games.bruges.options.marketHint"),
			onChange: () => t({
				...i,
				market: !i.market
			})
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/bruges/entry.tsx
var at = {
	definition: Ae,
	View: He,
	bot: Ze,
	describe: Qe,
	fx: tt,
	OverView: rt,
	Options: it,
	locales: {
		zh: {
			firstPlayer: "先手",
			noHouses: "尚未建造房屋",
			drawnCount: "已抽取 {{n}} 张",
			name: "布魯日",
			desc: "在运河古城招募人物、修建房屋与运河，争取声望。",
			errAction: "此选择已经失效，请重新选择。",
			errTurn: "请等待轮到你行动。",
			round: "第 {{n}} 轮",
			turnCount: "第 {{n}} 次行动",
			finalRound: "末轮：第 {{n}} 轮",
			waiting: "等待 {{name}}",
			settling: "正在结算",
			money: "钱",
			points: "分数",
			workers: "工人",
			workerCost: "消耗 {{n}} 名{{color}}工人",
			threats: "威胁",
			hand: "手牌",
			houses: "房屋",
			peopleLabel: "人物",
			canals: "运河",
			prestige: "声望",
			statues: "雕像",
			majorities: "多数标记",
			abilities: "终局能力",
			total: "总分",
			discardPile: "弃牌堆",
			reserve: "预留牌 {{n}}",
			stack: "牌堆 {{n}}",
			cardsLeft: "剩余 {{n}} 张",
			cost: "支付 {{n}} 钱",
			amount: "获得 {{n}}",
			emptyHouse: "空房屋",
			houseColor: "{{color}}房屋",
			side: "第 {{n}} 侧",
			canalCost: "{{n}} 钱",
			used: "本轮已使用",
			immediate: "招募时立即执行",
			passive: "持续生效",
			free: "每轮免费一次",
			endgame: "终局计分",
			onceWorker: "每轮支付 1 个{{color}}工人激活一次",
			details: "牌面详情",
			close: "关闭",
			cancel: "取消选择",
			chooseAction: "选择此牌的用途",
			confirm: "确认行动",
			inspect: "查看",
			selectHouse: "选择空房屋",
			stored: "存放工人 {{n}}",
			log: "行动记录",
			marketLeft: "剩余 {{n}} 次",
			noMarket: "本轮没有市场",
			nextShip: "下一艘",
			arrived: "已到港",
			atSea: "待入港",
			chooseTarget: "选择行动目标",
			replayBoard: "查看终局盘面",
			backResults: "返回计分",
			playAgain: "再玩一局",
			backLobby: "返回大厅",
			hostWaiting: "等待主机开始下一局",
			winner: "{{name}} 获胜",
			tieWinner: "并列获胜",
			scoreDetail: "计分明细",
			rules: "目标：游戏结束时总分最高者获胜，同分时钱较多者优先。\n准备：每人 5 分、5 钱及五色工人各 1 个。每张人物牌有颜色、钱费、阶层与能力。\n每轮：依先手顺序补至 5 张手牌。逐张选择牌堆，只能看牌背颜色，补牌完毕后查看牌面。掷五色骰子：5 或 6 使每人获得同色威胁。将所有 1、2 点骰子相加，每人可支付该钱数前进 1 格声望；没有 1、2 点则不能购买。\n行动：依次轮转四次。轮到你时，必须使用 1 张手牌进行以下一种行动，并可在此前后激活自己尚未使用的主动人物：\n① 获得 2 个牌色工人。② 获得牌色骰子点数的钱。③ 移除 1 枚牌色威胁，获得 1 分。④ 支付 1 个牌色工人，将牌背面建成空房屋。⑤ 选择一侧未完成运河，打出匹配下一段颜色的牌，并支付该段 1～5 钱。⑥ 支付人物钱费，将其放进自己任意空房屋。\n人物能力：一次性能力在招募时执行；工人能力支付标示颜色的 1 个工人，每轮一次；免费主动能力每轮一次；持续能力在场时生效；终局能力在计分时生效。房屋颜色与其中人物颜色可以不同。\n灾难：同色威胁达到 3 枚时，弃回全部该色威胁并承受灾难。蓝色失去全部工人；黄色失去全部钱；紫色失去 3 分，最低 0 分；棕色弃置自己一个人物，房屋保留；红色失去自己一座房屋或一侧末段运河。失去房屋时，其人物返回手牌。多项灾难自行选择次序。\n轮末：分别比较声望、人物数、运河总段数。独自最高且大于 0 者翻面自己的该项多数标记，终局每枚 4 分；已翻面标记不会失去。先手顺延。\n运河与声望：一侧至少 3 段，终局该侧获得 3 分；完成 5 段时拿取最高剩余雕像，按雕像数字计分，失去运河不退雕像，重新完成同侧不再领取。声望轨终局分为 0、1、2、3、4、5、7、9、12。\n结束：首次牌堆耗尽时使用预留牌。若发生在补牌阶段，本轮为最后一轮；若发生在行动阶段，下一轮为最后一轮。最终得分为现有分数、人物钱费的三分之一、每座房屋 1 分、终局能力、多数标记、运河、雕像与声望。\n可选扩展：新人加入 39 张人物与旅人阶层；第五玩家包含新人，支持 5 人。船只在同色骰子为 3 或 4 时到港；只有使用牌建渠后，可支付任意一艘到港船同色的 1 个工人使用该船一次。船效为获得 3 个任意工人、6 钱、移除至多 2 枚威胁、重新执行一个一次性人物、抽 1 牌立即使用、免费前进声望。下一艘船公开，色堆用尽重洗。市场在补牌后、掷骰前揭示一张。对应的打牌行动可选择使用市场改良，也可按普通行动执行；只有使用改良才消耗一次，先到先用，轮末弃置；12 张用尽不重洗。\n牌面详情可点开查看。部分外文版存在歧义：演员、市场免费激活不消耗正常次数；瑞典人只复制主动或一次性能力；弄臣自动选择最优的两种额外阶层。",
			colors: {
				blue: "蓝色",
				brown: "棕色",
				yellow: "黄色",
				red: "红色",
				purple: "紫色"
			},
			groups: {
				nobles: "贵族",
				entertainers: "艺人",
				craftsmen: "工匠",
				clergy: "神职人员",
				protectors: "守卫",
				scholars: "学者",
				bureaucrats: "官员",
				merchants: "商人",
				court: "宫廷成员",
				artists: "艺术家",
				outcasts: "不法之徒",
				travelers: "旅人"
			},
			ops: {
				workers: "获得工人",
				money: "获得钱",
				removeAction: "移除威胁",
				house: "建造房屋",
				canalAction: "建造运河",
				canalActionFree: "免费建造运河",
				person: "招募人物",
				activate: "激活人物",
				freeActivate: "免费激活",
				draw: "抽牌",
				protect: "抵御该色骰子威胁",
				advance: "前进声望",
				endTurn: "结束回合",
				skip: "放弃",
				remove: "移除威胁",
				worker: "获得工人",
				discard: "弃置手牌",
				losePerson: "弃置人物",
				loseHouse: "失去房屋",
				loseCanal: "移除末段运河",
				disaster: "结算灾难",
				giveWorker: "交出工人",
				buildCanal: "建造运河",
				buildCanalFree: "免费建造运河",
				recruitDiscard: "免费招募弃牌人物",
				discardHouse: "从弃牌建房",
				giveThreat: "转移威胁",
				storeWorker: "存放工人",
				sellWorker: "卖出工人",
				returnPerson: "将人物返回手牌",
				ready: "重置人物",
				copy: "复制能力",
				gift: "赠送 1 钱",
				exchangeGive: "交回工人",
				exchangeDone: "完成交回",
				sellColor: "卖出工人",
				ship: "使用船只"
			},
			phases: {
				draw: "选择牌堆",
				protect: "选择防护颜色",
				prestige: "购买声望",
				turn: "使用手牌并激活人物",
				playExtra: "额外使用手牌",
				playForced: "使用刚获得的牌",
				remove: "选择要移除的威胁",
				workers: "选择工人颜色",
				buyWorkers: "购买工人",
				discard: "选择弃置的手牌",
				losePerson: "选择失去的人物",
				loseHouse: "选择失去的房屋",
				loseCanal: "选择失去的末段运河",
				fire: "火灾：失去房屋或末段运河",
				disasters: "选择灾难结算次序",
				stealWorkers: "选择交出的工人",
				canal: "选择要修建的运河",
				recruitDiscard: "从弃牌堆招募人物",
				discardHouse: "从弃牌堆建造房屋",
				giveThreats: "选择要转移的威胁",
				storeWorker: "选择要存放的工人",
				sellWorker: "选择要卖出的工人",
				returnPerson: "选择返回手牌的人物",
				ready: "选择要重置的人物",
				copy: "选择要复制的能力",
				activateAll: "选择免费激活的次序",
				freeActivate: "免费激活新人物",
				gift: "选择赠送钱的对手",
				exchangeGive: "交回要交换的工人",
				exchangeTake: "选择换取的工人",
				sellColors: "每色可卖出一个工人",
				ships: "选择到港船只",
				done: "终局"
			},
			people: {
				y01: "修道院长",
				y02: "演员",
				y03: "海关官员",
				y04: "滋事者",
				y05: "解剖学家",
				y06: "强盗",
				y07: "吟游诗人",
				y08: "女男爵",
				y09: "生物学家",
				y10: "刺绣师",
				y11: "敲钟人",
				y12: "宫务大臣",
				y13: "大理石商人",
				y14: "作曲家",
				y15: "雕塑家",
				y16: "铸币师",
				y17: "农夫",
				y18: "军队统领",
				y19: "杂耍艺人",
				y20: "医生",
				y21: "商人",
				y22: "磨坊主",
				y23: "马夫",
				y24: "贵族",
				y25: "面包师",
				y26: "看门犬",
				y27: "凿井师",
				y28: "旗手",
				y29: "港口领航员",
				y30: "先知",
				y31: "破坏者",
				y32: "男爵",
				y33: "行会会长",
				b01: "杂技演员",
				b02: "海军上将",
				b03: "炼金术士",
				b04: "建筑师",
				b05: "贴身侍从",
				b06: "骑士",
				b07: "歌手",
				b08: "烧炭工",
				b09: "屠夫",
				b10: "锁匠",
				b11: "瓷器商人",
				b12: "伯爵",
				b13: "女伯爵",
				b14: "走私者",
				b15: "牧师",
				b16: "店员",
				b17: "驯兽师",
				b18: "抄写员",
				b19: "骗子",
				b20: "哲学家",
				b21: "陪审员",
				b22: "管家",
				b23: "乞丐",
				b24: "修女",
				b25: "公证人",
				b26: "赞助人",
				b27: "壁画画师",
				b28: "瓷器画师",
				b29: "放贷人",
				b30: "教士",
				b31: "领主",
				b32: "玻璃吹制师",
				b33: "射手",
				p01: "律师",
				p02: "泥瓦匠",
				p03: "刺客",
				p04: "拦路强盗",
				p05: "舞者",
				p06: "女仆",
				p07: "炮手",
				p08: "狱卒",
				p09: "枢机主教",
				p10: "木匠",
				p11: "车夫",
				p12: "宝石商人",
				p13: "市政委员",
				p14: "苦行僧",
				p15: "走绳艺人",
				p16: "地理学家",
				p17: "军械库守卫",
				p18: "守卫",
				p19: "乡绅",
				p20: "插画师",
				p21: "审判官",
				p22: "发明家",
				p23: "法官",
				p24: "地方官",
				p25: "侯爵",
				p26: "辅祭",
				p27: "缪斯",
				p28: "名门望族",
				p29: "公主",
				p30: "马具匠",
				p31: "地毯织工",
				p32: "欺诈者",
				p33: "交易商",
				r01: "弄臣",
				r02: "管理员",
				r03: "市长",
				r04: "执达官",
				r05: "工匠",
				r06: "烟火师",
				r07: "天文学家",
				r08: "植物学家",
				r09: "厨师",
				r10: "说书人",
				r11: "布料商人",
				r12: "宫廷女官",
				r13: "医师",
				r14: "侍女",
				r15: "灰泥匠",
				r16: "铁匠",
				r17: "游吟艺人",
				r18: "窃贼",
				r19: "锻造大师",
				r20: "元帅",
				r21: "信使",
				r22: "雇佣兵",
				r23: "修士",
				r24: "主教",
				r25: "牧羊人",
				r26: "纵火者",
				r27: "诗人",
				r28: "议员",
				r29: "王后",
				r30: "国王",
				r31: "掠夺者",
				r32: "店主",
				r33: "葡萄酒商",
				n01: "药剂师",
				n02: "随军教士",
				n03: "城堡守卫",
				n04: "编目员",
				n05: "认证官",
				n06: "驯鹰人",
				n07: "香料商人",
				n08: "会计",
				n09: "公爵",
				n10: "平衡艺人",
				n11: "雕版师",
				n12: "护栏守卫",
				n13: "瞭望塔守卫",
				n14: "传令官",
				n15: "历史学家",
				n16: "鞋匠",
				n17: "魔术师",
				n18: "圣像雕刻师",
				n19: "王女",
				n20: "庸医",
				n21: "数学家",
				n22: "见习修女",
				n23: "商贸赞助人",
				n24: "毛皮匠",
				n25: "石匠",
				n26: "焰火艺人",
				n27: "传教士",
				n28: "王子",
				n29: "登记官",
				n30: "肖像画师",
				n31: "仆人",
				n32: "告密者",
				n33: "拾荒者",
				x00: "女公爵",
				x01: "制革匠",
				x02: "西班牙人",
				x03: "俄罗斯人",
				x04: "测量员",
				x05: "匈牙利人",
				x06: "意大利人",
				x07: "波斯人",
				x08: "挪威人",
				x09: "侦察兵",
				x10: "市场主管",
				x11: "苏格兰人",
				x12: "民兵",
				x13: "芬兰人",
				x14: "希腊人",
				x15: "兑换商",
				x16: "丹麦人",
				x17: "彩窗画师",
				x18: "战略家",
				x19: "刽子手",
				x20: "蓄意破坏者",
				x21: "绞刑者",
				x22: "英格兰人",
				x23: "勋爵",
				x24: "埃及人",
				x25: "捷克人",
				x26: "托钵修士",
				x27: "宫廷总管",
				x28: "航海家",
				x29: "葡萄牙人",
				x30: "修道院副院长",
				x31: "法国人",
				x32: "占卜师",
				x33: "司仪",
				x34: "酿酒师",
				x35: "模特",
				x36: "瑞士人",
				x37: "瑞典人",
				x38: "木偶师"
			},
			texts: {
				y01: "获得 1 个棕色工人和 3 分。",
				y02: "立即免费额外激活你的所有工人激活人物，可自行选择次序。已用人物也可激活，且不消耗正常次数。",
				y03: "你的每座棕色房屋使你获得 2 钱。",
				y04: "每名对手失去自己选择的一段运河，必须从该侧末端移除。",
				y05: "你的每个学者使你获得 2 钱。",
				y06: "每名对手获得 1 枚黄色威胁，并检查灾难。",
				y07: "建造 1 段运河，支付该段通常钱费的两倍，无须打牌。",
				y08: "抽取 1 张牌并立即将其用于六种行动之一，照常支付行动费用。",
				y09: "招募人物时少支付 3 钱，最低为 0。",
				y10: "免费前进 1 格声望。",
				y11: "获得 1 个蓝色工人和 3 钱。",
				y12: "终局时，你的每个宫廷成员使你获得 2 分。",
				y13: "使用黄色手牌获得钱时，额外获得 3 钱。",
				y14: "你的每个守卫使你获得 1 分。",
				y15: "你的每个工匠使你获得 1 分。",
				y16: "你的每个官员使你获得 2 钱。",
				y17: "从两堆牌中逐张抽取共 1 张牌，全部抽完后加入手牌。",
				y18: "终局时，每枚保留的威胁获得 1 分。",
				y19: "每轮掷骰后，若黄色骰子为 5 或 6，获得 1 个黄色工人。",
				y20: "最多购买 5 个任意颜色工人，每个支付 1 钱。",
				y21: "获得 3 钱。",
				y22: "交回任意数量工人，再获得相同数量的任意颜色工人。",
				y23: "额外使用 1 张手牌进行六种行动之一，照常支付行动费用。",
				y24: "获得 1 分和 2 钱。",
				y25: "获得 1 个任意颜色工人。",
				y26: "移除自己的 1 枚黄色威胁，获得 1 分。",
				y27: "每轮一次，使用手牌建造运河时免钱费；仍须符合牌色。也可免除人物建渠的钱费。",
				y28: "移除自己的至多 1 枚任意颜色威胁，每枚获得 1 分。",
				y29: "若你至少拥有 3 座棕色房屋，获得 2 分。",
				y30: "你的每个神职人员使你获得 2 钱。",
				y31: "每名对手失去自己选择的一座房屋，房内人物返回其手牌。",
				y32: "获得 1 分和 2 钱。",
				y33: "终局时，你的每个商人使你获得 2 分。",
				b01: "建造 1 段运河，支付该段通常钱费的两倍，无须打牌。",
				b02: "移除自己的 1 枚蓝色威胁，获得 1 分。",
				b03: "获得 6 钱。",
				b04: "抽取 2 张牌，免费将它们建成空房屋。",
				b05: "从两堆牌中逐张抽取共 1 张牌，全部抽完后加入手牌。",
				b06: "终局时，你的每个守卫使你获得 2 分。",
				b07: "每轮掷骰后，若蓝色骰子为 5 或 6，获得 1 个蓝色工人。",
				b08: "交回任意数量工人，再获得相同数量的任意颜色工人。",
				b09: "获得 1 个任意颜色工人。",
				b10: "你的每个工匠使你获得 2 钱。",
				b11: "使用蓝色手牌获得钱时，额外获得 3 钱。",
				b12: "获得 1 分和 2 钱。",
				b13: "抽取 1 张牌并立即将其用于六种行动之一，照常支付行动费用。",
				b14: "每名对手获得 1 枚蓝色威胁，并检查灾难。",
				b15: "每颗点数为 1 的骰子使你获得 1 分。",
				b16: "获得 3 钱。",
				b17: "终局时，你的每个艺人使你获得 2 分。",
				b18: "额外使用 1 张手牌进行六种行动之一，照常支付行动费用。",
				b19: "终局时，你的每个不法之徒使你获得 2 分。",
				b20: "你的每个人物使你获得 2 钱。",
				b21: "若你至少拥有 3 座紫色房屋，获得 2 分。",
				b22: "终局时，若你的房屋包含全部五种颜色，获得 5 分。",
				b23: "每名对手交给你至多 2 个由其选择的工人。",
				b24: "获得 1 个红色工人和 3 钱。",
				b25: "每轮购买声望时少支付 2 钱，最低为 0。",
				b26: "你的每座红色房屋使你获得 2 钱。",
				b27: "你的每个神职人员使你获得 1 分。",
				b28: "你的每个艺术家使你获得 2 钱。",
				b29: "可分别给每名对手 1 钱，每给出 1 钱获得 1 分。",
				b30: "获得 1 个黄色工人和 3 分。",
				b31: "若没有骰子点数为 1 或 2，你仍可在声望阶段支付 4 钱前进 1 格。",
				b32: "你的每个商人使你获得 1 分。",
				b33: "移除自己的至多 2 枚任意颜色威胁，每枚获得 1 分。",
				p01: "使用手牌获得工人时，额外获得 1 个同色工人。",
				p02: "交回任意数量工人，再获得相同数量的任意颜色工人。",
				p03: "每名对手弃置自己选择的一个已招募人物，房屋保留。",
				p04: "每当对手招募一个人物，你获得 2 钱。",
				p05: "建造 1 段运河，支付该段通常钱费的两倍，无须打牌。",
				p06: "从两堆牌中逐张抽取共 1 张牌，全部抽完后加入手牌。",
				p07: "移除自己的至多 3 枚任意颜色威胁，每枚获得 1 分。",
				p08: "你的每个人物允许你移除自己的 1 枚任意颜色威胁，每枚获得 1 分。",
				p09: "终局时，你的每个神职人员使你获得 2 分。",
				p10: "获得 1 个任意颜色工人。",
				p11: "额外使用 1 张手牌进行六种行动之一，照常支付行动费用。",
				p12: "使用紫色手牌获得钱时，额外获得 3 钱。",
				p13: "你的每座黄色房屋使你获得 2 钱。",
				p14: "每次招募人物后，移除自己的 1 枚该人物颜色威胁并获得 1 分。",
				p15: "每轮掷骰后，若紫色骰子为 5 或 6，获得 1 个紫色工人。",
				p16: "终局时，每条至少 3 段的运河和每座雕像各额外获得 2 分。",
				p17: "你的房屋每有一种不同颜色，获得 2 钱。",
				p18: "移除自己的 1 枚紫色威胁，获得 1 分。",
				p19: "获得 1 分和 2 钱。",
				p20: "终局时，你的每个艺术家使你获得 2 分。",
				p21: "获得 1 个蓝色工人和 3 分。",
				p22: "每轮补牌时可补至 6 张，也可在达到 5 张时停止。",
				p23: "轮末比较多数时，与对手并列最高也可翻面该项多数标记。",
				p24: "若你至少拥有 3 座黄色房屋，获得 2 分。",
				p25: "你的每个贵族使你获得 2 钱。",
				p26: "获得 1 个棕色工人和 3 钱。",
				p27: "你的每个艺人使你获得 1 分。",
				p28: "你的每个商人使你获得 2 钱。",
				p29: "抽取 1 张牌并立即将其用于六种行动之一，照常支付行动费用。",
				p30: "你的人物每有一种不同阶层，获得 1 钱。",
				p31: "你的每个官员使你获得 1 分。",
				p32: "每名对手获得 1 枚紫色威胁，并检查灾难。",
				p33: "获得 3 钱。",
				r01: "终局时，此人物除艺人外还属于另两种不同阶层，自动选择使总分最高的合法组合。",
				r02: "获得 3 钱。",
				r03: "终局时，你的每个官员使你获得 2 分。",
				r04: "若你至少拥有 3 座蓝色房屋，获得 2 分。",
				r05: "终局时，你的每个工匠使你获得 2 分。",
				r06: "移除自己的 1 枚红色威胁，获得 1 分。",
				r07: "今后招募人物时，其一次性能力执行两次。",
				r08: "终局时，每枚已翻面的多数标记额外获得 2 分。",
				r09: "你的每个宫廷成员使你获得 2 钱。",
				r10: "每轮掷骰后，若红色骰子为 5 或 6，获得 1 个红色工人。",
				r11: "使用红色手牌获得钱时，额外获得 3 钱。",
				r12: "抽取 1 张牌并立即将其用于六种行动之一，照常支付行动费用。",
				r13: "使用手牌移除威胁时，可多移除 1 枚同色威胁，每枚照常获得 1 分。",
				r14: "先抽取 2 张牌加入手牌，再弃置 2 张手牌。",
				r15: "每次建房后，移除自己的 1 枚房屋原色威胁并获得 1 分。",
				r16: "获得 1 个任意颜色工人。",
				r17: "建造 1 段运河，支付该段通常钱费的两倍，无须打牌。",
				r18: "从每名对手处各拿取至多 3 钱。",
				r19: "你的每个不法之徒使你获得 1 分。",
				r20: "移除自己的至多 4 枚任意颜色威胁，每枚获得 1 分。",
				r21: "额外使用 1 张手牌进行六种行动之一，照常支付行动费用。",
				r22: "你的每个守卫使你获得 2 钱。",
				r23: "获得 1 个紫色工人和 3 钱。",
				r24: "终局时，每 2 个未存放的工人获得 1 分。",
				r25: "获得 1 个紫色工人和 3 分。",
				r26: "每名对手获得 1 枚红色威胁，并检查灾难。",
				r27: "你的每个学者使你获得 1 分。",
				r28: "你的每座紫色房屋使你获得 2 钱。",
				r29: "获得 1 分。",
				r30: "终局时，你的每个贵族使你获得 2 分。",
				r31: "你的每个不法之徒使你获得 2 钱。",
				r32: "你每拥有一条完整的 5 段运河，获得 2 分。",
				r33: "交回任意数量工人，再获得相同数量的任意颜色工人。",
				n01: "每色威胁的灾难阈值提高为 4 枚；失去此人物后立即检查灾难。",
				n02: "获得 1 个红色工人和 3 分。",
				n03: "移除自己的 1 枚棕色威胁，获得 1 分。",
				n04: "若你至少拥有 3 座红色房屋，获得 2 分。",
				n05: "每名对手弃置自己选择的 1 张手牌；不足时弃完。",
				n06: "从两堆牌中逐张抽取共 3 张牌，全部抽完后加入手牌。",
				n07: "使用棕色手牌获得钱时，额外获得 3 钱。",
				n08: "获得 2 钱。",
				n09: "你每拥有 3 段运河，获得 1 分。",
				n10: "建造 1 段运河，支付该段通常钱费的两倍，无须打牌。",
				n11: "终局时，你的人物每有一种不同阶层，获得 2 分。",
				n12: "免费建造 1 段运河，无须打牌。",
				n13: "每次建造运河后，移除自己的 1 枚该段颜色威胁并获得 1 分。",
				n14: "额外使用 1 张手牌进行六种行动之一，照常支付行动费用。",
				n15: "终局时，你的每个学者使你获得 2 分。",
				n16: "交回任意数量工人，再获得相同数量的任意颜色工人。",
				n17: "你的每个艺人使你获得 2 钱。",
				n18: "你的每个宫廷成员使你获得 1 分。",
				n19: "抽取 1 张牌并立即将其用于六种行动之一，照常支付行动费用。",
				n20: "每名对手获得 1 枚棕色威胁，并检查灾难。",
				n21: "先抽取 4 张牌加入手牌，再弃置 4 张手牌。",
				n22: "获得 1 个黄色工人和 3 钱。",
				n23: "获得 3 钱。",
				n24: "获得 1 个任意颜色工人。",
				n25: "获得 1 个任意颜色工人。",
				n26: "每轮掷骰后，若棕色骰子为 5 或 6，获得 1 个棕色工人。",
				n27: "每次前进声望时，可移除自己的 1 枚任意颜色威胁并获得 1 分。",
				n28: "获得 1 分和 2 钱。",
				n29: "你的每座蓝色房屋使你获得 2 钱。",
				n30: "你的每个贵族使你获得 1 分。",
				n31: "从两堆牌中逐张抽取共 1 张牌，全部抽完后加入手牌。",
				n32: "每名对手的声望后退 1 格，最低为起点。",
				n33: "每颗点数为 6 的骰子使你获得 1 钱。",
				x00: "从弃牌堆免费招募 1 个贵族到自己的空房屋，无须弃置此人物。",
				x01: "每种颜色最多卖出 1 个工人，每个获得 1 钱和 1 分。",
				x02: "你下一次使用手牌时，可将其视为任意颜色；本轮结束后失效。",
				x03: "你下一次使用手牌时，可将其视为任意颜色；本轮结束后失效。",
				x04: "从弃牌堆免费招募 1 个官员到自己的空房屋，无须弃置此人物。",
				x05: "你的工人每有一种不同颜色，获得 1 钱。",
				x06: "支付 1 个所选弃牌颜色的工人，将该弃牌建成自己的空房屋。",
				x07: "每次前进声望时，额外获得 1 分。",
				x08: "你下一次使用手牌时，可将其视为任意颜色；本轮结束后失效。",
				x09: "从弃牌堆免费招募 1 个守卫到自己的空房屋，无须弃置此人物。",
				x10: "从弃牌堆免费招募 1 个商人到自己的空房屋，无须弃置此人物。",
				x11: "你的威胁每有一种不同颜色，获得 2 钱。",
				x12: "每轮掷骰前选择一种颜色，本次掷骰不获得该色威胁。",
				x13: "从弃牌堆免费招募 1 个旅人到自己的空房屋，无须弃置此人物。",
				x14: "支付 1 个所选弃牌颜色的工人，将该弃牌建成自己的空房屋。",
				x15: "卖出 1 个任意颜色工人，获得该色骰子点数的钱。",
				x16: "支付 1 个所选弃牌颜色的工人，将该弃牌建成自己的空房屋。",
				x17: "你的每个旅人使你获得 1 分。",
				x18: "可向每名对手转移自己的 1 枚任意颜色威胁；对手检查灾难。",
				x19: "在此人物上存放 1 个任意颜色工人，终局每个存放工人获得 1 分；失去此人物时移除存放工人。",
				x20: "从每名有手牌的对手处随机拿取 1 张手牌。",
				x21: "从弃牌堆免费招募 1 个不法之徒到自己的空房屋，无须弃置此人物。",
				x22: "支付 1 个所选弃牌颜色的工人，将该弃牌建成自己的空房屋。",
				x23: "可将任意数量自己的已招募人物返回手牌，房屋保留。",
				x24: "支付 1 个所选弃牌颜色的工人，将该弃牌建成自己的空房屋。",
				x25: "你的每个旅人使你获得 2 钱。",
				x26: "每颗点数为 1 的骰子使你获得 1 个同色工人。",
				x27: "从弃牌堆免费招募 1 个宫廷成员到自己的空房屋，无须弃置此人物。",
				x28: "从弃牌堆免费招募 1 个学者到自己的空房屋，无须弃置此人物。",
				x29: "你下一次使用手牌时，可将其视为任意颜色；本轮结束后失效。",
				x30: "从弃牌堆免费招募 1 个神职人员到自己的空房屋，无须弃置此人物。",
				x31: "你下一次使用手牌时，可将其视为任意颜色；本轮结束后失效。",
				x32: "从弃牌堆免费招募 1 个艺人到自己的空房屋，无须弃置此人物。",
				x33: "立即将弃牌堆顶的牌用于六种行动之一，照常支付行动费用。",
				x34: "从弃牌堆免费招募 1 个工匠到自己的空房屋，无须弃置此人物。",
				x35: "从弃牌堆免费招募 1 个艺术家到自己的空房屋，无须弃置此人物。",
				x36: "终局时，你的每个旅人使你获得 2 分。",
				x37: "免费执行一名对手的一个非终局主动或一次性人物能力，不改变对手的激活状态。",
				x38: "重置自己另一个本轮已使用的主动人物，之后可再次照常支付费用激活。"
			},
			marketNames: {
				m00: "简易房屋",
				m01: "起重机",
				m02: "建筑材料",
				m03: "价格保证",
				m04: "经济复苏",
				m05: "华丽建筑",
				m06: "保险",
				m07: "应急计划",
				m08: "投机",
				m09: "激励",
				m10: "同侪之首",
				m11: "多才多艺"
			},
			marketTexts: {
				m00: "打牌建房免工人费用。",
				m01: "打牌建渠无须符合牌色。",
				m02: "打牌建渠少支付 2 钱，最低 0 钱。",
				m03: "打牌获得钱时，骰子基础收入改为 5 钱。",
				m04: "打牌获得工人时，额外获得 1 个同色工人。",
				m05: "打牌建房时，额外获得 1 分。",
				m06: "打牌移除威胁时，每移除一枚额外获得 1 分。",
				m07: "打牌移除威胁时，可选择任意颜色。",
				m08: "打牌获得钱时，额外获得 2 钱。",
				m09: "打牌招募人物后，获得 1 个任意颜色工人。",
				m10: "打牌招募人物后，可免费额外激活该人物，不消耗正常次数。",
				m11: "打牌获得工人时，可任意选择各个工人的颜色。"
			},
			ships: {
				0: "获得 3 个任意颜色工人",
				1: "获得 6 钱",
				2: "移除至多 2 枚威胁，每枚获得 1 分",
				3: "重新执行自己的一个一次性人物能力",
				4: "抽 1 张牌并立即使用",
				5: "免费前进 1 格声望"
			},
			options: {
				title: "茨温河畔扩展",
				newCitizens: "新人",
				newCitizensHint: "加入 39 张人物与旅人阶层。",
				fifthPlayer: "第五玩家",
				fifthPlayerHint: "开放 5 人，并启用新人。",
				ships: "船只",
				shipsHint: "建渠后可使用到港船只。",
				market: "市场",
				marketHint: "每轮提供有限次数的行动加成。"
			},
			events: {
				draw: "抽牌",
				roll: "掷出骰子",
				majority: "比较多数",
				advance: "前进声望",
				person: "招募人物",
				house: "建造房屋",
				canal: "建造运河",
				finalRound: "第 {{n}} 轮为末轮",
				workers: "获得工人",
				money: "获得钱",
				removeAction: "移除威胁",
				canalAction: "建造运河",
				canalActionFree: "免费建造运河",
				activate: "激活人物",
				freeActivate: "免费激活",
				protect: "抵御该色骰子威胁",
				endTurn: "结束回合",
				skip: "放弃",
				remove: "移除威胁",
				worker: "获得工人",
				discard: "弃置手牌",
				losePerson: "弃置人物",
				loseHouse: "失去房屋",
				loseCanal: "移除末段运河",
				disaster: "结算灾难",
				giveWorker: "交出工人",
				buildCanal: "建造运河",
				buildCanalFree: "免费建造运河",
				recruitDiscard: "免费招募弃牌人物",
				discardHouse: "从弃牌建房",
				giveThreat: "转移威胁",
				storeWorker: "存放工人",
				sellWorker: "卖出工人",
				returnPerson: "将人物返回手牌",
				ready: "重置人物",
				copy: "复制能力",
				gift: "赠送 1 钱",
				exchangeGive: "交回工人",
				exchangeDone: "完成交回",
				sellColor: "卖出工人",
				ship: "使用船只"
			}
		},
		en: {
			firstPlayer: "First player",
			noHouses: "No houses yet",
			drawnCount: "{{n}} drawn",
			name: "Bruges",
			desc: "Recruit people, build houses and canals, and gain prestige in medieval Bruges.",
			errAction: "This choice is no longer available. Choose again.",
			errTurn: "Wait for your turn.",
			round: "Round {{n}}",
			turnCount: "Turn {{n}} of 4",
			finalRound: "Final round: {{n}}",
			waiting: "Waiting for {{name}}",
			settling: "Resolving",
			money: "Guilders",
			points: "Points",
			workers: "Workers",
			workerCost: "Spend {{n}} {{color}} worker(s)",
			threats: "Threats",
			hand: "Hand",
			houses: "Houses",
			peopleLabel: "People",
			canals: "Canals",
			prestige: "Prestige",
			statues: "Statues",
			majorities: "Majorities",
			abilities: "Abilities",
			total: "Total",
			discardPile: "Discard pile",
			reserve: "Reserve: {{n}}",
			stack: "Stack {{n}}",
			cardsLeft: "{{n}} cards left",
			cost: "Pay {{n}} guilders",
			amount: "Gain {{n}}",
			emptyHouse: "Empty house",
			houseColor: "{{color}} house",
			side: "Side {{n}}",
			canalCost: "{{n}} guilders",
			used: "Used this round",
			immediate: "On recruitment",
			passive: "Passive",
			free: "Free once per round",
			endgame: "At game end",
			onceWorker: "Once per round: pay 1 {{color}} worker",
			details: "Card details",
			close: "Close",
			cancel: "Cancel selection",
			chooseAction: "Choose how to use this card",
			confirm: "Confirm action",
			inspect: "Inspect",
			selectHouse: "Choose an empty house",
			stored: "Stored workers: {{n}}",
			log: "History",
			marketLeft: "{{n}} uses left",
			noMarket: "No market this round",
			nextShip: "Next ship",
			arrived: "In port",
			atSea: "At sea",
			chooseTarget: "Choose a target",
			replayBoard: "View final board",
			backResults: "Back to scores",
			playAgain: "Play again",
			backLobby: "Back to lobby",
			hostWaiting: "Waiting for the host",
			winner: "{{name}} wins",
			tieWinner: "Shared victory",
			scoreDetail: "Score breakdown",
			rules: "Goal: score the most points at game end. Ties favor more guilders.\nStart with 5 points, 5 guilders and 1 worker of each of the five colors. Each card has a color, cost, group and ability.\nEach round: refill to 5 cards in turn order. Choose a stack for each draw by its visible back color; see the drawn faces only when refill finishes. Roll all five dice. Each 5 or 6 gives everyone a matching threat. Add all dice showing 1 or 2; each player may pay that total to advance 1 prestige space. With no 1 or 2, prestige cannot normally be bought.\nActions: take four turns each, rotating in order. On your turn use 1 hand card for one of six actions, activating any unused active people before or after it:\n1. Take 2 workers matching the card. 2. Take guilders equal to its die. 3. Remove 1 matching threat and gain 1 point. 4. Pay 1 matching worker and build the card face down as an empty house. 5. Extend either canal using a card matching its next section and pay that section’s cost of 1–5 guilders. 6. Pay the person’s cost and recruit it into any empty house.\nAbilities: immediate abilities resolve upon recruitment. Worker abilities cost 1 worker of the shown color, once per round. Free active abilities are once per round. Passive abilities work while the person remains in play. Endgame abilities score at the end. House and occupant colors need not match.\nDisasters: reaching 3 threats of a color returns all threats of that color and causes its disaster. Blue: lose all workers. Yellow: lose all guilders. Purple: lose 3 points, to a minimum of 0. Brown: discard one person of your choice, keeping the house. Red: lose one house or an end section of either canal. A person in a lost house returns to your hand. Choose the order of simultaneous disasters.\nRound end: compare prestige, number of people, and total canal sections separately. The sole leader with more than zero flips their marker for that category, worth 4 points at game end. Claimed markers are never lost. Pass first player clockwise.\nCanals and prestige: each side with at least 3 sections scores 3 points at game end. Completing 5 takes the highest remaining statue. Keep statues even if a section is lost; completing that same side again gives no further statue. Prestige spaces score 0, 1, 2, 3, 4, 5, 7, 9, 12.\nEnd: the first depleted stack brings in the reserve. If depleted during refill, this is the final round; during actions, the following round is final. Score current points, one third of each recruited person’s printed cost, 1 per house, endgame abilities, majority markers, canals, statues and prestige.\nOptional modules: New Citizens adds 39 people and the travelers group. Fifth Player includes New Citizens and allows five players. Ships enter port when their die shows 3 or 4. After a card canal action, you may pay 1 worker matching any active ship to use that ship once. Effects: 3 workers in any colors; 6 guilders; remove up to 2 threats; reactivate one immediate person; draw and immediately use 1 card; advance prestige for free. The next ship is public; reshuffle exhausted color decks. Market reveals one card after refill and before rolling each round. For matching card actions, choose either the ordinary action or the market improvement. Only using the improvement consumes one of its limited uses. Discard the market at round end. Its 12 cards are not reshuffled.\nOpen a card for its details. Ambiguous edition details: Actor and market bonus activations do not consume normal uses; Swede copies active or immediate abilities only; Jester selects the best two extra groups automatically.",
			colors: {
				blue: "blue",
				brown: "brown",
				yellow: "yellow",
				red: "red",
				purple: "purple"
			},
			groups: {
				nobles: "Nobles",
				entertainers: "Entertainers",
				craftsmen: "Craftsmen",
				clergy: "Clergy",
				protectors: "Protectors",
				scholars: "Scholars",
				bureaucrats: "Bureaucrats",
				merchants: "Merchants",
				court: "Court",
				artists: "Artists",
				outcasts: "Outcasts",
				travelers: "Travelers"
			},
			ops: {
				workers: "Take workers",
				money: "Take money",
				removeAction: "Remove threats",
				house: "Build house",
				canalAction: "Build canal",
				canalActionFree: "Build canal for free",
				person: "Recruit person",
				activate: "Activate person",
				freeActivate: "Activate for free",
				draw: "Draw card",
				protect: "Protect against this die",
				advance: "Advance prestige",
				endTurn: "End turn",
				skip: "Skip",
				remove: "Remove threat",
				worker: "Take worker",
				discard: "Discard card",
				losePerson: "Lose person",
				loseHouse: "Lose house",
				loseCanal: "Lose last canal section",
				disaster: "Resolve disaster",
				giveWorker: "Give worker",
				buildCanal: "Build canal",
				buildCanalFree: "Build canal for free",
				recruitDiscard: "Recruit discarded person",
				discardHouse: "Build discarded house",
				giveThreat: "Transfer threat",
				storeWorker: "Store worker",
				sellWorker: "Sell worker",
				returnPerson: "Return person to hand",
				ready: "Ready person",
				copy: "Copy ability",
				gift: "Give 1 guilder",
				exchangeGive: "Return worker",
				exchangeDone: "Finish returning",
				sellColor: "Sell worker",
				ship: "Use ship"
			},
			phases: {
				draw: "Choose a stack",
				protect: "Choose a protected color",
				prestige: "Buy prestige",
				turn: "Use a card and activate people",
				playExtra: "Use an extra card",
				playForced: "Use the drawn card",
				remove: "Choose a threat to remove",
				workers: "Choose a worker color",
				buyWorkers: "Buy workers",
				discard: "Choose a hand card to discard",
				losePerson: "Choose a person to lose",
				loseHouse: "Choose a house to lose",
				loseCanal: "Choose a canal end to lose",
				fire: "Fire: lose a house or canal end",
				disasters: "Choose disaster order",
				stealWorkers: "Choose a worker to give",
				canal: "Choose a canal to extend",
				recruitDiscard: "Recruit from the discard pile",
				discardHouse: "Build a discarded house",
				giveThreats: "Choose a threat to transfer",
				storeWorker: "Choose a worker to store",
				sellWorker: "Choose a worker to sell",
				returnPerson: "Choose people to return to hand",
				ready: "Choose a person to ready",
				copy: "Choose an ability to copy",
				activateAll: "Choose free activation order",
				freeActivate: "Activate the new person for free",
				gift: "Choose an opponent to give money",
				exchangeGive: "Return workers to exchange",
				exchangeTake: "Choose replacement workers",
				sellColors: "Sell at most one worker per color",
				ships: "Choose an arriving ship",
				done: "Game over"
			},
			people: {
				y01: "Abbot",
				y02: "Actor",
				y03: "Customs Officer",
				y04: "Troublemaker",
				y05: "Anatomist",
				y06: "Bandit",
				y07: "Bard",
				y08: "Baroness",
				y09: "Biologist",
				y10: "Embroiderer",
				y11: "Bell Ringer",
				y12: "Chamberlain",
				y13: "Marble Merchant",
				y14: "Composer",
				y15: "Sculptor",
				y16: "Coin Minter",
				y17: "Farmer",
				y18: "Military Leader",
				y19: "Juggler",
				y20: "Doctor",
				y21: "Merchant",
				y22: "Miller",
				y23: "Stable Boy",
				y24: "Nobleman",
				y25: "Baker",
				y26: "Guard Dog",
				y27: "Well Builder",
				y28: "Standard Bearer",
				y29: "Harbour Pilot",
				y30: "Prophet",
				y31: "Vandal",
				y32: "Baron",
				y33: "Guild Master",
				b01: "Acrobat",
				b02: "Admiral",
				b03: "Alchemist",
				b04: "Architect",
				b05: "Valet",
				b06: "Knight",
				b07: "Singer",
				b08: "Charcoal Burner",
				b09: "Butcher",
				b10: "Locksmith",
				b11: "Porcelain Merchant",
				b12: "Count",
				b13: "Countess",
				b14: "Smuggler",
				b15: "Pastor",
				b16: "Shop Assistant",
				b17: "Animal Tamer",
				b18: "Scribe",
				b19: "Swindler",
				b20: "Philosopher",
				b21: "Juror",
				b22: "Steward",
				b23: "Beggar",
				b24: "Nun",
				b25: "Notary",
				b26: "Patron",
				b27: "Fresco Painter",
				b28: "Porcelain Painter",
				b29: "Moneylender",
				b30: "Priest",
				b31: "Lord",
				b32: "Glassblower",
				b33: "Marksman",
				p01: "Lawyer",
				p02: "Bricklayer",
				p03: "Assassin",
				p04: "Highwayman",
				p05: "Dancer",
				p06: "Maid",
				p07: "Cannoneer",
				p08: "Jailer",
				p09: "Cardinal",
				p10: "Carpenter",
				p11: "Coachman",
				p12: "Gem Merchant",
				p13: "Alderman",
				p14: "Fakir",
				p15: "Tightrope Walker",
				p16: "Geographer",
				p17: "Arsenal Guard",
				p18: "Guard",
				p19: "Squire",
				p20: "Illustrator",
				p21: "Inquisitor",
				p22: "Inventor",
				p23: "Judge",
				p24: "Magistrate",
				p25: "Marquis",
				p26: "Altar Boy",
				p27: "Muse",
				p28: "Patrician",
				p29: "Princess",
				p30: "Saddler",
				p31: "Carpet Weaver",
				p32: "Con Artist",
				p33: "Trader",
				r01: "Jester",
				r02: "Administrator",
				r03: "Mayor",
				r04: "Bailiff",
				r05: "Artisan",
				r06: "Fireworker",
				r07: "Astronomer",
				r08: "Botanist",
				r09: "Cook",
				r10: "Storyteller",
				r11: "Cloth Merchant",
				r12: "Lady in Waiting",
				r13: "Doctor",
				r14: "Handmaid",
				r15: "Plasterer",
				r16: "Blacksmith",
				r17: "Minstrel",
				r18: "Thief",
				r19: "Master Smith",
				r20: "Marshal",
				r21: "Messenger",
				r22: "Mercenary",
				r23: "Monk",
				r24: "Bishop",
				r25: "Shepherd",
				r26: "Arsonist",
				r27: "Poet",
				r28: "Councillor",
				r29: "Queen",
				r30: "King",
				r31: "Looter",
				r32: "Shopkeeper",
				r33: "Vintner",
				n01: "Apothecary",
				n02: "Chaplain",
				n03: "Castellan",
				n04: "Cataloguer",
				n05: "Certifier",
				n06: "Falconer",
				n07: "Spice Merchant",
				n08: "Accountant",
				n09: "Duke",
				n10: "Balancer",
				n11: "Engraver",
				n12: "Fence Guard",
				n13: "Watchtower Guard",
				n14: "Herald",
				n15: "Historian",
				n16: "Shoemaker",
				n17: "Illusionist",
				n18: "Image Carver",
				n19: "Infanta",
				n20: "Quack",
				n21: "Mathematician",
				n22: "Novice",
				n23: "Trade Patron",
				n24: "Furrier",
				n25: "Stonemason",
				n26: "Pyrotechnician",
				n27: "Preacher",
				n28: "Prince",
				n29: "Registrar",
				n30: "Portrait Painter",
				n31: "Servant",
				n32: "Informer",
				n33: "Rag Collector",
				x00: "Duchess",
				x01: "Tanner",
				x02: "Spaniard",
				x03: "Russian",
				x04: "Surveyor",
				x05: "Hungarian",
				x06: "Italian",
				x07: "Persian",
				x08: "Norwegian",
				x09: "Scout",
				x10: "Market Master",
				x11: "Scotsman",
				x12: "Militiaman",
				x13: "Finn",
				x14: "Greek",
				x15: "Moneychanger",
				x16: "Dane",
				x17: "Stained Glass Artist",
				x18: "Strategist",
				x19: "Executioner",
				x20: "Saboteur",
				x21: "Hangman",
				x22: "Englishman",
				x23: "Lord",
				x24: "Egyptian",
				x25: "Czech",
				x26: "Friar",
				x27: "Court Marshal",
				x28: "Navigator",
				x29: "Portuguese",
				x30: "Prior",
				x31: "Frenchwoman",
				x32: "Fortune Teller",
				x33: "Master of Ceremonies",
				x34: "Brewer",
				x35: "Model",
				x36: "Swiss",
				x37: "Swede",
				x38: "Puppeteer"
			},
			texts: {
				y01: "Gain 1 brown worker and 3 points.",
				y02: "Immediately activate all your worker-activated people for free, in any order. This bonus also works on used people and does not consume their normal activation.",
				y03: "Gain 2 guilders per brown house you own.",
				y04: "Each opponent loses one canal section of their choice from the end of either side.",
				y05: "Gain 2 guilders per person in your Scholars group.",
				y06: "Each opponent gains 1 yellow threat and checks for disaster.",
				y07: "Build 1 canal section for twice its usual money cost, without playing a card.",
				y08: "Draw 1 card and immediately use it for one of the six actions, paying its usual costs.",
				y09: "Pay 3 fewer guilders when recruiting a person, to a minimum of 0.",
				y10: "Advance 1 prestige space for free.",
				y11: "Gain 1 blue worker and 3 guilders.",
				y12: "At game end, score 2 points per person in your Court group.",
				y13: "Gain 3 extra guilders when using a yellow card for money.",
				y14: "Gain 1 point per person in your Protectors group.",
				y15: "Gain 1 point per person in your Craftsmen group.",
				y16: "Gain 2 guilders per person in your Bureaucrats group.",
				y17: "Draw 1 cards, choosing a stack for each; add them to your hand after all are drawn.",
				y18: "At game end, score 1 point per remaining threat.",
				y19: "After the dice roll, gain 1 yellow worker if the yellow die shows 5 or 6.",
				y20: "Buy up to 5 workers in any colors, paying 1 guilder each.",
				y21: "Gain 3 guilders.",
				y22: "Return any number of workers, then take the same number in any colors.",
				y23: "Use 1 additional hand card for one of the six actions, paying its usual costs.",
				y24: "Gain 1 points and 2 guilders.",
				y25: "Gain 1 worker(s) in colors of your choice.",
				y26: "Remove 1 yellow threat from yourself and gain 1 point.",
				y27: "Once per round, waive the money cost of a canal action; card color requirements still apply. May also waive a person’s canal cost.",
				y28: "Remove up to 1 threats of any colors from yourself; gain 1 point each.",
				y29: "If you own at least 3 brown houses, gain 2 points.",
				y30: "Gain 2 guilders per person in your Clergy group.",
				y31: "Each opponent loses one house of their choice; its person returns to their hand.",
				y32: "Gain 1 points and 2 guilders.",
				y33: "At game end, score 2 points per person in your Merchants group.",
				b01: "Build 1 canal section for twice its usual money cost, without playing a card.",
				b02: "Remove 1 blue threat from yourself and gain 1 point.",
				b03: "Gain 6 guilders.",
				b04: "Draw 2 cards and build them as empty houses for free.",
				b05: "Draw 1 cards, choosing a stack for each; add them to your hand after all are drawn.",
				b06: "At game end, score 2 points per person in your Protectors group.",
				b07: "After the dice roll, gain 1 blue worker if the blue die shows 5 or 6.",
				b08: "Return any number of workers, then take the same number in any colors.",
				b09: "Gain 1 worker(s) in colors of your choice.",
				b10: "Gain 2 guilders per person in your Craftsmen group.",
				b11: "Gain 3 extra guilders when using a blue card for money.",
				b12: "Gain 1 points and 2 guilders.",
				b13: "Draw 1 card and immediately use it for one of the six actions, paying its usual costs.",
				b14: "Each opponent gains 1 blue threat and checks for disaster.",
				b15: "Gain 1 point per die showing 1.",
				b16: "Gain 3 guilders.",
				b17: "At game end, score 2 points per person in your Entertainers group.",
				b18: "Use 1 additional hand card for one of the six actions, paying its usual costs.",
				b19: "At game end, score 2 points per person in your Outcasts group.",
				b20: "Gain 2 guilders per person you own.",
				b21: "If you own at least 3 purple houses, gain 2 points.",
				b22: "At game end, score 5 points if your houses include all five colors.",
				b23: "Each opponent gives you up to 2 workers in colors of their choice.",
				b24: "Gain 1 red worker and 3 guilders.",
				b25: "Pay 2 fewer guilders when buying prestige each round, to a minimum of 0.",
				b26: "Gain 2 guilders per red house you own.",
				b27: "Gain 1 point per person in your Clergy group.",
				b28: "Gain 2 guilders per person in your Artists group.",
				b29: "You may give each opponent 1 guilder, gaining 1 point per guilder given.",
				b30: "Gain 1 yellow worker and 3 points.",
				b31: "If no die shows 1 or 2, you may still buy 1 prestige space for 4 guilders in the prestige phase.",
				b32: "Gain 1 point per person in your Merchants group.",
				b33: "Remove up to 2 threats of any colors from yourself; gain 1 point each.",
				p01: "Gain 1 additional matching worker when using a card to take workers.",
				p02: "Return any number of workers, then take the same number in any colors.",
				p03: "Each opponent discards one recruited person of their choice, keeping the house.",
				p04: "Gain 2 guilders whenever an opponent recruits a person.",
				p05: "Build 1 canal section for twice its usual money cost, without playing a card.",
				p06: "Draw 1 cards, choosing a stack for each; add them to your hand after all are drawn.",
				p07: "Remove up to 3 threats of any colors from yourself; gain 1 point each.",
				p08: "Remove up to 1 threat per person you own; gain 1 point per threat removed.",
				p09: "At game end, score 2 points per person in your Clergy group.",
				p10: "Gain 1 worker(s) in colors of your choice.",
				p11: "Use 1 additional hand card for one of the six actions, paying its usual costs.",
				p12: "Gain 3 extra guilders when using a purple card for money.",
				p13: "Gain 2 guilders per yellow house you own.",
				p14: "Whenever you recruit a person, remove 1 threat matching their color and gain 1 point.",
				p15: "After the dice roll, gain 1 purple worker if the purple die shows 5 or 6.",
				p16: "At game end, gain 2 extra points per canal with at least 3 sections and per statue.",
				p17: "Gain 2 guilders per distinct house color you own.",
				p18: "Remove 1 purple threat from yourself and gain 1 point.",
				p19: "Gain 1 points and 2 guilders.",
				p20: "At game end, score 2 points per person in your Artists group.",
				p21: "Gain 1 blue worker and 3 points.",
				p22: "During refill, draw up to 6 cards; you may stop after reaching 5.",
				p23: "At the round-end majority check, ties for most also claim your majority marker.",
				p24: "If you own at least 3 yellow houses, gain 2 points.",
				p25: "Gain 2 guilders per person in your Nobles group.",
				p26: "Gain 1 brown worker and 3 guilders.",
				p27: "Gain 1 point per person in your Entertainers group.",
				p28: "Gain 2 guilders per person in your Merchants group.",
				p29: "Draw 1 card and immediately use it for one of the six actions, paying its usual costs.",
				p30: "Gain 1 guilder per distinct group among your people.",
				p31: "Gain 1 point per person in your Bureaucrats group.",
				p32: "Each opponent gains 1 purple threat and checks for disaster.",
				p33: "Gain 3 guilders.",
				r01: "At game end, this person belongs to two additional distinct groups besides entertainers. The best legal pair is selected for scoring.",
				r02: "Gain 3 guilders.",
				r03: "At game end, score 2 points per person in your Bureaucrats group.",
				r04: "If you own at least 3 blue houses, gain 2 points.",
				r05: "At game end, score 2 points per person in your Craftsmen group.",
				r06: "Remove 1 red threat from yourself and gain 1 point.",
				r07: "Execute immediate abilities of people you recruit from now on twice.",
				r08: "At game end, score 2 extra points per claimed majority marker.",
				r09: "Gain 2 guilders per person in your Court group.",
				r10: "After the dice roll, gain 1 red worker if the red die shows 5 or 6.",
				r11: "Gain 3 extra guilders when using a red card for money.",
				r12: "Draw 1 card and immediately use it for one of the six actions, paying its usual costs.",
				r13: "When using a card to remove threats, remove up to 1 additional threat of the same color, gaining 1 point each.",
				r14: "Draw 2 cards into your hand, then discard 2 cards from your hand.",
				r15: "Whenever you build a house, remove 1 threat matching its printed color and gain 1 point.",
				r16: "Gain 1 worker(s) in colors of your choice.",
				r17: "Build 1 canal section for twice its usual money cost, without playing a card.",
				r18: "Take up to 3 guilders from each opponent.",
				r19: "Gain 1 point per person in your Outcasts group.",
				r20: "Remove up to 4 threats of any colors from yourself; gain 1 point each.",
				r21: "Use 1 additional hand card for one of the six actions, paying its usual costs.",
				r22: "Gain 2 guilders per person in your Protectors group.",
				r23: "Gain 1 purple worker and 3 guilders.",
				r24: "At game end, score 1 point per 2 unstored workers.",
				r25: "Gain 1 purple worker and 3 points.",
				r26: "Each opponent gains 1 red threat and checks for disaster.",
				r27: "Gain 1 point per person in your Scholars group.",
				r28: "Gain 2 guilders per purple house you own.",
				r29: "Gain 1 points.",
				r30: "At game end, score 2 points per person in your Nobles group.",
				r31: "Gain 2 guilders per person in your Outcasts group.",
				r32: "Gain 2 points per completed five-section canal.",
				r33: "Return any number of workers, then take the same number in any colors.",
				n01: "Disasters require 4 threats of a color while this person is in play. Check disasters immediately if this person leaves.",
				n02: "Gain 1 red worker and 3 points.",
				n03: "Remove 1 brown threat from yourself and gain 1 point.",
				n04: "If you own at least 3 red houses, gain 2 points.",
				n05: "Each opponent discards 1 hand card(s) of their choice, or all if fewer.",
				n06: "Draw 3 cards, choosing a stack for each; add them to your hand after all are drawn.",
				n07: "Gain 3 extra guilders when using a brown card for money.",
				n08: "Gain 2 guilders.",
				n09: "Gain 1 point per 3 canal sections you own.",
				n10: "Build 1 canal section for twice its usual money cost, without playing a card.",
				n11: "At game end, score 2 points per distinct group among your people.",
				n12: "Build 1 canal section for free, without playing a card.",
				n13: "Whenever you build a canal section, remove 1 threat matching that section and gain 1 point.",
				n14: "Use 1 additional hand card for one of the six actions, paying its usual costs.",
				n15: "At game end, score 2 points per person in your Scholars group.",
				n16: "Return any number of workers, then take the same number in any colors.",
				n17: "Gain 2 guilders per person in your Entertainers group.",
				n18: "Gain 1 point per person in your Court group.",
				n19: "Draw 1 card and immediately use it for one of the six actions, paying its usual costs.",
				n20: "Each opponent gains 1 brown threat and checks for disaster.",
				n21: "Draw 4 cards into your hand, then discard 4 cards from your hand.",
				n22: "Gain 1 yellow worker and 3 guilders.",
				n23: "Gain 3 guilders.",
				n24: "Gain 1 worker(s) in colors of your choice.",
				n25: "Gain 1 worker(s) in colors of your choice.",
				n26: "After the dice roll, gain 1 brown worker if the brown die shows 5 or 6.",
				n27: "Whenever you advance in prestige, you may remove 1 threat and gain 1 point.",
				n28: "Gain 1 points and 2 guilders.",
				n29: "Gain 2 guilders per blue house you own.",
				n30: "Gain 1 point per person in your Nobles group.",
				n31: "Draw 1 cards, choosing a stack for each; add them to your hand after all are drawn.",
				n32: "Each opponent moves back 1 prestige space, stopping at the start.",
				n33: "Gain 1 guilder per die showing 6.",
				x00: "Recruit 1 Nobles person from the discard pile into an empty house for free. Keep this person.",
				x01: "Sell at most 1 worker of each color, gaining 1 guilder and 1 point each.",
				x02: "Treat your next hand card as any color for that action. Expires at the end of the round.",
				x03: "Treat your next hand card as any color for that action. Expires at the end of the round.",
				x04: "Recruit 1 Bureaucrats person from the discard pile into an empty house for free. Keep this person.",
				x05: "Gain 1 guilder per distinct worker color you own.",
				x06: "Pay 1 worker matching a card in the discard pile and build that card as an empty house.",
				x07: "Gain 1 extra point whenever you advance in prestige.",
				x08: "Treat your next hand card as any color for that action. Expires at the end of the round.",
				x09: "Recruit 1 Protectors person from the discard pile into an empty house for free. Keep this person.",
				x10: "Recruit 1 Merchants person from the discard pile into an empty house for free. Keep this person.",
				x11: "Gain 2 guilders per distinct threat color you have.",
				x12: "Before each dice roll, choose a color; ignore the threat from that die this round.",
				x13: "Recruit 1 Travelers person from the discard pile into an empty house for free. Keep this person.",
				x14: "Pay 1 worker matching a card in the discard pile and build that card as an empty house.",
				x15: "Sell 1 worker of any color for guilders equal to its die value.",
				x16: "Pay 1 worker matching a card in the discard pile and build that card as an empty house.",
				x17: "Gain 1 point per person in your Travelers group.",
				x18: "You may transfer 1 of your threats to each opponent; recipients check for disaster.",
				x19: "Store 1 worker of any color on this person. Each stored worker scores 1 point at game end; lose them if this person leaves.",
				x20: "Take 1 random hand card from each opponent who has any.",
				x21: "Recruit 1 Outcasts person from the discard pile into an empty house for free. Keep this person.",
				x22: "Pay 1 worker matching a card in the discard pile and build that card as an empty house.",
				x23: "Return any number of your recruited people to your hand, keeping their houses.",
				x24: "Pay 1 worker matching a card in the discard pile and build that card as an empty house.",
				x25: "Gain 2 guilders per person in your Travelers group.",
				x26: "Gain 1 matching worker for each die showing 1.",
				x27: "Recruit 1 Court person from the discard pile into an empty house for free. Keep this person.",
				x28: "Recruit 1 Scholars person from the discard pile into an empty house for free. Keep this person.",
				x29: "Treat your next hand card as any color for that action. Expires at the end of the round.",
				x30: "Recruit 1 Clergy person from the discard pile into an empty house for free. Keep this person.",
				x31: "Treat your next hand card as any color for that action. Expires at the end of the round.",
				x32: "Recruit 1 Entertainers person from the discard pile into an empty house for free. Keep this person.",
				x33: "Immediately use the top discard for one of the six actions, paying its usual costs.",
				x34: "Recruit 1 Craftsmen person from the discard pile into an empty house for free. Keep this person.",
				x35: "Recruit 1 Artists person from the discard pile into an empty house for free. Keep this person.",
				x36: "At game end, score 2 points per person in your Travelers group.",
				x37: "Execute one opponent’s active or immediate non-endgame person ability for free, without changing their activation state.",
				x38: "Ready another of your active people already used this round; its next normal activation still costs its usual worker."
			},
			marketNames: {
				m00: "Hut",
				m01: "Crane",
				m02: "Building Materials",
				m03: "Price Guarantee",
				m04: "Economic Recovery",
				m05: "Magnificent Building",
				m06: "Insurance",
				m07: "Emergency Plan",
				m08: "Speculation",
				m09: "Motivation",
				m10: "First Among Equals",
				m11: "Jack of All Trades"
			},
			marketTexts: {
				m00: "Card house actions cost no worker.",
				m01: "Card canal actions ignore card color.",
				m02: "Card canal actions cost 2 fewer guilders, minimum 0.",
				m03: "Card money actions have a base income of 5 guilders.",
				m04: "Card worker actions gain 1 extra matching worker.",
				m05: "Card house actions gain 1 extra point.",
				m06: "Card threat-removal actions gain 1 extra point per threat.",
				m07: "Card threat-removal actions may remove any color.",
				m08: "Card money actions gain 2 extra guilders.",
				m09: "After a card recruitment action, gain 1 worker of any color.",
				m10: "After a card recruitment action, activate that person once for free without consuming its normal use.",
				m11: "Choose each worker’s color freely in card worker actions."
			},
			ships: {
				0: "Gain 3 workers in any colors",
				1: "Gain 6 guilders",
				2: "Remove up to 2 threats, gaining 1 point each",
				3: "Reactivate one of your immediate people",
				4: "Draw and immediately use 1 card",
				5: "Advance 1 prestige space for free"
			},
			options: {
				title: "The City on the Zwin",
				newCitizens: "New Citizens",
				newCitizensHint: "Add 39 people and the travelers group.",
				fifthPlayer: "Fifth Player",
				fifthPlayerHint: "Allow 5 players and enable New Citizens.",
				ships: "Ships",
				shipsHint: "Use arriving ships after card canal actions.",
				market: "Market",
				marketHint: "Limited-use action bonuses each round."
			},
			events: {
				draw: "Draw card",
				roll: "Rolled the dice",
				majority: "Checked majorities",
				advance: "Advance prestige",
				person: "Recruit person",
				house: "Build house",
				canal: "Built a canal",
				finalRound: "Round {{n}} is final",
				workers: "Take workers",
				money: "Take money",
				removeAction: "Remove threats",
				canalAction: "Build canal",
				canalActionFree: "Build canal for free",
				activate: "Activate person",
				freeActivate: "Activate for free",
				protect: "Protect against this die",
				endTurn: "End turn",
				skip: "Skip",
				remove: "Remove threat",
				worker: "Take worker",
				discard: "Discard card",
				losePerson: "Lose person",
				loseHouse: "Lose house",
				loseCanal: "Lose last canal section",
				disaster: "Resolve disaster",
				giveWorker: "Give worker",
				buildCanal: "Build canal",
				buildCanalFree: "Build canal for free",
				recruitDiscard: "Recruit discarded person",
				discardHouse: "Build discarded house",
				giveThreat: "Transfer threat",
				storeWorker: "Store worker",
				sellWorker: "Sell worker",
				returnPerson: "Return person to hand",
				ready: "Ready person",
				copy: "Copy ability",
				gift: "Give 1 guilder",
				exchangeGive: "Return worker",
				exchangeDone: "Finish returning",
				sellColor: "Sell worker",
				ship: "Use ship"
			}
		}
	}
};
//#endregion
export { at as default };
