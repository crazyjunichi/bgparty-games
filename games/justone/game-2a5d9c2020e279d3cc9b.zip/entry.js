import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import t from "@bgparty/sdk/word-list";
import { z as n } from "zod";
import { useState as r } from "react";
import { ConfirmButton as i } from "@bgparty/sdk/confirm-button";
import { useT as a } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { useWakeLock as s } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { Fragment as l, jsx as u, jsxs as d } from "react/jsx-runtime";
//#region src/games/justone/meta.ts
var f = {
	id: "justone",
	tier: "alpha",
	nameKey: "games.justone.name",
	descKey: "games.justone.desc",
	rulesKey: "games.justone.rules",
	icon: "✏️",
	iconImg: "games/justone.webp",
	rulesUrl: { en: "https://cdn.svc.asmodee.net/production-rprod/storage/games/justone/NEW/jo-en02-rules-mkt-1749635213L3H57.pdf" },
	minPlayers: 3,
	maxPlayers: 7,
	bestPlayers: [
		5,
		6,
		7
	],
	mechanics: ["word-association"],
	interactionTags: ["cooperative", "communication-limits"],
	accent: "#00a7df",
	releasedAt: "2026-11-03T02:03:10+08:00",
	search: {
		py: "du jia an yu",
		init: "djay"
	},
	hotseat: "cover"
}, p = n.string().trim().min(1).max(40).refine((e) => [...e].every((e) => e.charCodeAt(0) >= 32 && e.charCodeAt(0) !== 127)), m = n.discriminatedUnion("type", [
	n.object({
		type: n.literal("select"),
		number: n.number().int().min(1).max(5)
	}),
	n.object({ type: n.literal("reselect") }),
	n.object({
		type: n.literal("clue"),
		words: n.array(p).min(1).max(2)
	}),
	n.object({
		type: n.literal("cancel"),
		id: n.string(),
		cancelled: n.boolean()
	}),
	n.object({ type: n.literal("confirm") }),
	n.object({
		type: n.literal("guess"),
		word: p
	}),
	n.object({ type: n.literal("pass") }),
	n.object({
		type: n.literal("judge"),
		correct: n.boolean()
	}),
	n.object({ type: n.literal("next") })
]), h = n.enum([
	"select",
	"write",
	"compare",
	"guess",
	"judge",
	"reveal",
	"done"
]), g = n.object({
	id: n.string(),
	by: n.string(),
	slot: n.number().int(),
	word: n.string(),
	cancelled: n.boolean(),
	locked: n.boolean()
}), _ = n.object({
	round: n.number().int(),
	card: n.number().int(),
	active: n.string(),
	target: n.string(),
	guess: n.string().nullable(),
	outcome: n.enum([
		"correct",
		"wrong",
		"pass",
		"cancelled"
	]),
	delta: n.number().int(),
	extraDiscard: n.boolean(),
	clues: n.array(g)
}), v = n.object({
	phase: h,
	players: n.array(n.string()),
	active: n.string(),
	round: n.number().int(),
	card: n.number().int(),
	remaining: n.number().int(),
	score: n.number().int(),
	number: n.number().int().nullable(),
	clueCount: n.number().int(),
	excludedNumber: n.number().int().nullable(),
	submitted: n.array(n.string()),
	confirmed: n.array(n.string()),
	clues: n.array(g),
	target: n.string().nullable(),
	guess: n.string().nullable(),
	votes: n.record(n.string(), n.boolean()),
	history: n.array(_)
}), y = n.object({
	cardWords: n.array(n.string()),
	target: n.string().nullable(),
	myClues: n.array(n.string()),
	compareClues: n.array(g)
}), b = (e) => e.normalize("NFKC").toLowerCase().replace(/\s+/gu, ""), x = (e) => e <= 4 ? 2 : 1, S = (e) => e.players[e.activeIndex], C = (e) => e.number === null ? null : e.cards[e.card]?.[e.number - 1] ?? null, w = (e) => e.players.filter((t) => t !== S(e)), T = () => ({ code: "games.justone.invalidAction" });
function E(e) {
	let t = e.clues.flatMap((e) => e.words.map((t, n) => ({
		id: `${e.by}:${n}`,
		by: e.by,
		slot: n,
		word: t
	}))), n = b(C(e) ?? "");
	return t.map((r) => {
		let i = b(r.word), a = i === n || t.some((e) => e.id !== r.id && b(e.word) === i);
		return {
			...r,
			locked: a,
			cancelled: a || e.cancelled.includes(r.id)
		};
	});
}
function D(e, t) {
	let n = t === "wrong" && e.card < 12, r = t === "correct" ? 1 : t === "wrong" && !n && e.score > 0 ? -1 : 0, i = {
		round: e.history.length + 1,
		card: e.card + 1,
		active: S(e),
		target: C(e),
		guess: e.guess,
		outcome: t,
		delta: r,
		extraDiscard: n,
		clues: E(e)
	};
	return {
		...e,
		phase: "reveal",
		score: e.score + r,
		history: [...e.history, i]
	};
}
var O = {
	meta: f,
	saveCompatibility: { version: "1" },
	schemas: {
		action: m,
		publicView: v,
		privateView: y
	},
	setup(n, r, i) {
		let a = [...new Set(t)], o = 0;
		for (let t = a.length - 1; t > 0; t--) {
			let n = e(i, o++, t + 1);
			[a[t], a[n]] = [a[n], a[t]];
		}
		let s = Array.from({ length: 13 }, (e, t) => a.slice(t * 5, t * 5 + 5));
		return { state: {
			players: [...r],
			cards: s,
			card: 0,
			activeIndex: e(i, o, r.length),
			phase: "select",
			number: null,
			excludedNumber: null,
			clues: [],
			cancelled: [],
			confirmed: [],
			guess: null,
			votes: {},
			score: 0,
			history: []
		} };
	},
	reduce(e, t, { by: n }) {
		if (!e.players.includes(n) || e.phase === "done") return T();
		let r = S(e), i = n !== r;
		if (t.type === "select") return e.phase !== "select" || n !== r || t.number === e.excludedNumber ? T() : { state: {
			...e,
			phase: "write",
			number: t.number,
			excludedNumber: null
		} };
		if (t.type === "reselect") return e.phase !== "write" || !i || e.clues.length > 0 ? T() : { state: {
			...e,
			phase: "select",
			number: null,
			excludedNumber: e.number
		} };
		if (t.type === "clue") {
			if (e.phase !== "write" || !i || t.words.length !== x(e.players.length) || e.clues.some((e) => e.by === n)) return T();
			let r = [...e.clues, {
				by: n,
				words: t.words.map((e) => e.trim())
			}];
			return { state: {
				...e,
				clues: r,
				phase: r.length === e.players.length - 1 ? "compare" : "write"
			} };
		}
		if (t.type === "cancel") {
			if (e.phase !== "compare" || !i) return T();
			let n = E(e).find((e) => e.id === t.id);
			if (!n || n.locked || n.cancelled === t.cancelled) return T();
			let r = t.cancelled ? [...e.cancelled, t.id] : e.cancelled.filter((e) => e !== t.id);
			return { state: {
				...e,
				cancelled: r,
				confirmed: []
			} };
		}
		if (t.type === "confirm") {
			if (e.phase !== "compare" || !i || e.confirmed.includes(n)) return T();
			let t = [...e.confirmed, n], r = {
				...e,
				confirmed: t
			};
			return t.length === e.players.length - 1 ? { state: E(e).some((e) => !e.cancelled) ? {
				...r,
				phase: "guess"
			} : D(r, "cancelled") } : { state: r };
		}
		if (t.type === "guess") {
			if (e.phase !== "guess" || n !== r) return T();
			let i = {
				...e,
				guess: t.word.trim(),
				phase: "judge"
			};
			return { state: b(t.word) === b(C(e)) ? D(i, "correct") : i };
		}
		if (t.type === "pass") return e.phase !== "guess" || n !== r ? T() : { state: D(e, "pass") };
		if (t.type === "judge") {
			if (e.phase !== "judge" || !i || e.votes[n] === t.correct) return T();
			let r = {
				...e.votes,
				[n]: t.correct
			}, a = {
				...e,
				votes: r
			}, o = w(e);
			return o.every((e) => r[e] === !0) ? { state: D(a, "correct") } : o.every((e) => r[e] === !1) ? { state: D(a, "wrong") } : { state: a };
		}
		if (t.type === "next") {
			if (e.phase !== "reveal" || n !== r) return T();
			let t = e.history[e.history.length - 1], i = e.card + (t.extraDiscard ? 2 : 1);
			return { state: {
				...e,
				card: i,
				activeIndex: (e.activeIndex + 1) % e.players.length,
				phase: i >= 13 ? "done" : "select",
				number: null,
				excludedNumber: null,
				clues: [],
				cancelled: [],
				confirmed: [],
				guess: null,
				votes: {}
			} };
		}
		return T();
	},
	viewFor(e, t) {
		let n = e.players.includes(t) && t !== S(e), r = e.phase === "reveal" || e.phase === "done", i = r ? E(e) : e.phase === "guess" || e.phase === "judge" ? E(e).filter((e) => !e.cancelled) : [];
		return {
			public: {
				phase: e.phase,
				players: e.players,
				active: S(e),
				round: e.history.length + (e.phase === "reveal" || e.phase === "done" ? 0 : 1),
				card: Math.min(13, e.card + 1),
				remaining: Math.max(0, 12 - e.card),
				score: e.score,
				number: e.number,
				clueCount: x(e.players.length),
				excludedNumber: e.excludedNumber,
				submitted: e.clues.map((e) => e.by),
				confirmed: e.confirmed,
				clues: i,
				target: r ? C(e) : null,
				guess: e.guess,
				votes: e.votes,
				history: e.history
			},
			private: {
				cardWords: n && e.phase !== "done" ? e.cards[e.card] : [],
				target: n ? C(e) : null,
				myClues: e.clues.find((e) => e.by === t)?.words ?? [],
				compareClues: n && e.phase === "compare" ? E(e) : []
			}
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: e.players,
			ranking: e.players,
			scores: Object.fromEntries(e.players.map((t) => [t, e.score]))
		} : { phase: e.phase };
	}
}, k = [
	"#f7c900",
	"#60b336",
	"#ec4696",
	"#00a7df",
	"#f4a000",
	"#a477bf",
	"#e35a54"
];
function A({ color: e, name: t, children: n, cancelled: r = !1, status: i, onClick: a, label: o, locked: s = !1 }) {
	let c = /* @__PURE__ */ d(l, { children: [
		/* @__PURE__ */ d("div", {
			className: "jo-easel-object",
			"data-cancelled": r,
			children: [/* @__PURE__ */ d("svg", {
				className: "jo-easel-shape",
				viewBox: "0 0 320 210",
				preserveAspectRatio: "none",
				"aria-hidden": !0,
				children: [
					/* @__PURE__ */ u("path", {
						d: "M24 18 L295 18 L311 198 L10 198 Z",
						fill: "#172231",
						opacity: ".1"
					}),
					/* @__PURE__ */ u("path", {
						d: "M22 5 Q160 -2 298 5 L313 180 L7 180 Z",
						fill: "currentColor"
					}),
					/* @__PURE__ */ u("path", {
						d: "M11 170 L309 170 L318 189 Q320 197 311 198 L9 198 Q0 197 2 189 Z",
						fill: "currentColor"
					}),
					/* @__PURE__ */ u("path", {
						d: "M13 183 H307",
						stroke: "#fff",
						strokeWidth: "2",
						opacity: ".42"
					})
				]
			}), /* @__PURE__ */ u("div", {
				className: "jo-easel-face",
				children: n
			})]
		}),
		/* @__PURE__ */ u("div", {
			className: "jo-easel-name",
			children: t
		}),
		i && /* @__PURE__ */ u("div", {
			className: "jo-easel-status",
			children: i
		})
	] }), f = { "--jo-easel": e };
	return a ? /* @__PURE__ */ u("button", {
		type: "button",
		className: "jo-easel jo-easel-button",
		style: f,
		"aria-label": o,
		"aria-pressed": r,
		disabled: s,
		onClick: a,
		children: c
	}) : /* @__PURE__ */ u("div", {
		className: "jo-easel",
		style: f,
		children: c
	});
}
function j({ entry: e }) {
	let t = a(), n = e.outcome === "correct" ? t("games.justone.correct") : e.outcome === "wrong" ? t("games.justone.wrong") : e.outcome === "pass" ? t("games.justone.passed") : t("games.justone.allCancelled");
	return /* @__PURE__ */ d("div", {
		className: "jo-outcome",
		"data-outcome": e.outcome,
		children: [
			/* @__PURE__ */ u("strong", { children: n }),
			/* @__PURE__ */ u("span", { children: e.delta > 0 ? t("games.justone.gain") : e.delta < 0 ? t("games.justone.lose") : t("games.justone.noScore") }),
			e.extraDiscard && /* @__PURE__ */ u("span", { children: t("games.justone.extra") })
		]
	});
}
//#endregion
//#region src/games/justone/view-player.tsx
function M(e) {
	s();
	let t = e.public;
	return /* @__PURE__ */ u(N, { ...e }, `${t.card}:${t.number}:${e.myRid}`);
}
function N({ public: e, private: t, members: n, myRid: s, send: f }) {
	let p = a(), h = e, g = t, [_, v] = r(["", ""]), [y, b] = r(""), x = h.active === s, S = h.players.includes(s) && !x, C = h.players.filter((e) => e !== h.active), w = h.submitted.includes(s), T = (e) => n.find((t) => t.rid === e)?.name ?? e, E = (e) => o[(n.find((t) => t.rid === e)?.colorIndex ?? 0) % o.length].hex, D = h.history.at(-1), O = h.phase === "write" && S && !w, M = h.phase === "guess" && x, N = m.safeParse({
		type: "clue",
		words: _.slice(0, h.clueCount)
	}).success, P = m.safeParse({
		type: "guess",
		word: y
	}).success, F = () => {
		O && N && f({
			type: "clue",
			words: _.slice(0, h.clueCount)
		}), M && P && f({
			type: "guess",
			word: y
		});
	}, I = h.phase === "select" ? x ? p("games.justone.choose") : p("games.justone.waitChoose", { name: T(h.active) }) : h.phase === "write" ? O ? h.clueCount === 2 ? p("games.justone.writeTwo") : p("games.justone.write") : p("games.justone.waitClues", {
		n: h.submitted.length,
		total: C.length
	}) : h.phase === "compare" ? p(S ? "games.justone.compare" : "games.justone.waitCompare") : h.phase === "guess" ? x ? p("games.justone.guessPrompt") : p("games.justone.waitGuess", { name: T(h.active) }) : h.phase === "judge" ? p(S ? "games.justone.judgePrompt" : "games.justone.waitJudge") : h.phase === "reveal" ? p("games.justone.mystery") : p("games.justone.finalTitle");
	return /* @__PURE__ */ u(c, {
		adaptive: !0,
		className: `jo-game jo-phase-${h.phase}`,
		actionsHeight: "jo-actions-slot",
		banner: /* @__PURE__ */ d("header", {
			className: "jo-header",
			children: [
				/* @__PURE__ */ d("div", {
					className: "jo-heading",
					children: [/* @__PURE__ */ u("h1", { children: p("games.justone.name") }), /* @__PURE__ */ u("span", { children: p("games.justone.card", { n: h.card }) })]
				}),
				/* @__PURE__ */ d("div", {
					className: "jo-score",
					children: [/* @__PURE__ */ u("span", { children: p("games.justone.score") }), /* @__PURE__ */ d("strong", { children: [h.score, /* @__PURE__ */ u("small", { children: " / 13" })] }, h.score)]
				}),
				/* @__PURE__ */ d("div", {
					className: "jo-active",
					children: [/* @__PURE__ */ u("i", { style: { background: E(h.active) } }), p("games.justone.active", { name: T(h.active) })]
				}),
				/* @__PURE__ */ u("p", {
					className: "jo-prompt",
					role: "status",
					children: I
				})
			]
		}),
		actions: /* @__PURE__ */ u("div", {
			className: "jo-actions",
			children: O ? /* @__PURE__ */ u("button", {
				type: "button",
				onClick: F,
				className: "jo-button",
				disabled: !N,
				children: p("games.justone.submitClues")
			}) : h.phase === "compare" && S ? /* @__PURE__ */ d("div", {
				className: "jo-action-stack",
				children: [/* @__PURE__ */ u("span", { children: p("games.justone.confirmed", {
					n: h.confirmed.length,
					total: C.length
				}) }), /* @__PURE__ */ u("button", {
					type: "button",
					className: "jo-button",
					disabled: h.confirmed.includes(s),
					onClick: () => f({ type: "confirm" }),
					children: p("games.justone.confirm")
				})]
			}) : M ? /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("button", {
				type: "button",
				onClick: F,
				className: "jo-button",
				disabled: !P,
				children: p("games.justone.submitGuess")
			}), /* @__PURE__ */ u(i, {
				className: "jo-secondary",
				label: p("games.justone.pass"),
				confirmLabel: p("games.justone.confirmPass"),
				onConfirm: () => f({ type: "pass" })
			})] }) : h.phase === "judge" && S ? /* @__PURE__ */ d("div", {
				className: "jo-action-stack",
				children: [/* @__PURE__ */ u("span", { children: p("games.justone.votes", {
					n: Object.keys(h.votes).length,
					total: C.length
				}) }), /* @__PURE__ */ d("div", {
					className: "jo-action-row",
					children: [/* @__PURE__ */ u("button", {
						type: "button",
						className: "jo-button",
						"aria-pressed": h.votes[s] === !0,
						onClick: () => f({
							type: "judge",
							correct: !0
						}),
						disabled: h.votes[s] === !0,
						children: p("games.justone.correctVote")
					}), /* @__PURE__ */ u("button", {
						type: "button",
						className: "jo-button jo-secondary",
						"aria-pressed": h.votes[s] === !1,
						onClick: () => f({
							type: "judge",
							correct: !1
						}),
						disabled: h.votes[s] === !1,
						children: p("games.justone.wrongVote")
					})]
				})]
			}) : h.phase === "reveal" && x ? /* @__PURE__ */ u("button", {
				type: "button",
				className: "jo-button",
				onClick: () => f({ type: "next" }),
				children: p(h.remaining === 0 || D?.extraDiscard && h.remaining === 1 ? "games.justone.finish" : "games.justone.next")
			}) : h.phase === "reveal" ? /* @__PURE__ */ u("p", {
				role: "status",
				children: p("games.justone.waitNext", { name: T(h.active) })
			}) : h.phase === "write" && w ? /* @__PURE__ */ u("p", {
				role: "status",
				children: p("games.justone.submitted")
			}) : null
		}),
		children: /* @__PURE__ */ d("div", {
			className: "jo-table",
			children: [/* @__PURE__ */ d("section", {
				className: "jo-card-area",
				"aria-label": p("games.justone.mystery"),
				children: [
					/* @__PURE__ */ u("div", {
						className: "jo-word-card",
						children: k.slice(0, 5).map((e, t) => {
							let n = g?.cardWords[t] ?? (h.number === t + 1 ? h.target : null), r = x && h.phase === "select", i = r && h.excludedNumber !== t + 1, a = /* @__PURE__ */ d(l, { children: [
								/* @__PURE__ */ d("svg", {
									className: "jo-number",
									viewBox: "0 0 70 74",
									"aria-hidden": !0,
									children: [
										/* @__PURE__ */ u("path", {
											d: "M2 5 L67 2 L48 71 Z",
											fill: "currentColor",
											stroke: "currentColor",
											strokeWidth: "2"
										}),
										/* @__PURE__ */ u("path", {
											d: "M7 9 L61 6 L47 63 Z",
											fill: "none",
											stroke: "white",
											strokeWidth: "2"
										}),
										/* @__PURE__ */ u("text", {
											x: "37",
											y: "40",
											textAnchor: "middle",
											fontSize: "33",
											fontWeight: "850",
											fill: "white",
											children: t + 1
										})
									]
								}),
								/* @__PURE__ */ u("span", {
									className: "jo-card-word",
									children: n || "?"
								}),
								i && /* @__PURE__ */ u("svg", {
									className: "jo-legal",
									preserveAspectRatio: "none",
									viewBox: "0 0 100 100",
									"aria-hidden": !0,
									children: /* @__PURE__ */ u("rect", {
										x: "2",
										y: "2",
										width: "96",
										height: "96",
										rx: "7",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "2",
										strokeDasharray: "6 4",
										vectorEffect: "non-scaling-stroke",
										children: /* @__PURE__ */ u("animate", {
											attributeName: "stroke-dashoffset",
											from: "0",
											to: "-20",
											dur: "1s",
											repeatCount: "indefinite"
										})
									})
								})
							] });
							return r ? /* @__PURE__ */ u("button", {
								type: "button",
								className: "jo-card-row",
								style: { "--jo-row": e },
								disabled: !i,
								onClick: () => f({
									type: "select",
									number: t + 1
								}),
								"aria-label": String(t + 1),
								children: a
							}, t) : /* @__PURE__ */ u("div", {
								className: "jo-card-row",
								"data-selected": h.number === t + 1,
								style: { "--jo-row": e },
								children: a
							}, t);
						})
					}, h.card),
					h.phase === "write" && S && h.submitted.length === 0 && /* @__PURE__ */ u("button", {
						type: "button",
						className: "jo-reselect",
						onClick: () => f({ type: "reselect" }),
						children: p("games.justone.reselect")
					}),
					/* @__PURE__ */ u("span", {
						className: "jo-deck",
						children: p("games.justone.remaining", { n: h.remaining })
					}),
					h.phase === "reveal" && D && /* @__PURE__ */ u(j, { entry: D })
				]
			}), /* @__PURE__ */ u("section", {
				className: "jo-clue-area",
				"aria-label": p("games.justone.clues"),
				children: /* @__PURE__ */ d("div", {
					onKeyDown: (e) => {
						e.key === "Enter" && !e.nativeEvent.isComposing && e.target instanceof HTMLInputElement && (e.preventDefault(), F());
					},
					children: [
						/* @__PURE__ */ u("div", {
							className: "jo-easels",
							"data-count": C.length * h.clueCount,
							children: C.flatMap((e, t) => Array.from({ length: h.clueCount }, (n, r) => {
								let i = `${e}:${r}`, a = (h.phase === "compare" ? g?.compareClues : h.clues)?.find((e) => e.id === i), o = e === s, c = o ? g?.myClues[r] : void 0, l = h.phase === "compare" && S, m = (h.phase === "guess" || h.phase === "judge") && !a;
								return /* @__PURE__ */ u(A, {
									color: k[t % k.length],
									name: T(e),
									cancelled: a?.cancelled || m,
									status: a?.cancelled ? p(a.locked ? "games.justone.locked" : "games.justone.cancelled") : h.phase === "write" && h.submitted.includes(e) ? p("games.justone.submitted") : void 0,
									onClick: l && a ? () => f({
										type: "cancel",
										id: i,
										cancelled: !a.cancelled
									}) : void 0,
									locked: a?.locked,
									label: a ? p(a.cancelled ? "games.justone.restore" : "games.justone.cancel", { word: a.word }) : void 0,
									children: O && o ? /* @__PURE__ */ d("label", {
										className: "jo-write",
										children: [/* @__PURE__ */ u("span", { children: p("games.justone.clueLabel", { n: r + 1 }) }), /* @__PURE__ */ u("input", {
											autoComplete: "off",
											maxLength: 40,
											value: _[r],
											onChange: (e) => v((t) => t.map((t, n) => n === r ? e.target.value : t))
										})]
									}) : /* @__PURE__ */ u("span", {
										className: `jo-clue-word${a?.cancelled ? " jo-struck" : ""}`,
										children: a?.word ?? c ?? p(m ? "games.justone.cancelled" : "games.justone.hidden")
									})
								}, i);
							}))
						}),
						M && /* @__PURE__ */ d("label", {
							className: "jo-guess-input",
							children: [/* @__PURE__ */ u("span", { children: p("games.justone.guessLabel") }), /* @__PURE__ */ u("input", {
								autoComplete: "off",
								maxLength: 40,
								value: y,
								onChange: (e) => b(e.target.value)
							})]
						}),
						h.guess && /* @__PURE__ */ u("p", {
							className: "jo-guess-result",
							children: p("games.justone.guessWas", { word: h.guess })
						})
					]
				})
			})]
		})
	});
}
//#endregion
//#region src/games/justone/bot.ts
var P = (e) => {
	let t = Math.floor(4294967296 / e) * e, n;
	do
		n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (n >= t);
	return n % e;
}, F = ({ public: e, private: n }, { rid: r }) => {
	if (!e.players.includes(r)) return null;
	let i = e.active === r;
	if (e.phase === "select" && i) {
		let t = [
			1,
			2,
			3,
			4,
			5
		].filter((t) => t !== e.excludedNumber);
		return { action: {
			type: "select",
			number: t[P(t.length)]
		} };
	}
	if (e.phase === "write" && !i && !e.submitted.includes(r) && n?.target) {
		let r = b(n.target), i = t.filter((e) => {
			let t = b(e);
			return !t.includes(r) && !r.includes(t);
		}), a = [];
		for (; a.length < e.clueCount;) a.push(i.splice(P(i.length), 1)[0]);
		return { action: {
			type: "clue",
			words: a
		} };
	}
	if (e.phase === "compare" && !i && !e.confirmed.includes(r)) return { action: { type: "confirm" } };
	if (e.phase === "guess" && i) return { action: P(4) === 0 ? { type: "pass" } : {
		type: "guess",
		word: t[P(t.length)]
	} };
	if (e.phase === "judge" && !i && n?.target && e.guess) {
		let t = b(e.guess) === b(n.target);
		if (e.votes[r] !== t) return { action: {
			type: "judge",
			correct: t
		} };
	}
	return e.phase === "reveal" && i ? { action: { type: "next" } } : null;
};
//#endregion
//#region src/games/justone/game-over.tsx
function I({ public: e, members: t, result: n, hintCount: r, onPlayAgain: s, onBackToLobby: c }) {
	let f = a(), p = e, m = (e) => t.find((t) => t.rid === e)?.name ?? e, h = p.score === 13 ? f("games.justone.rating13") : p.score === 12 ? f("games.justone.rating12") : p.score === 11 ? f("games.justone.rating11") : p.score >= 9 ? f("games.justone.rating9") : p.score >= 7 ? f("games.justone.rating7") : p.score >= 4 ? f("games.justone.rating4") : f("games.justone.rating0");
	return /* @__PURE__ */ d("div", {
		className: "jo-final",
		children: [
			/* @__PURE__ */ u("header", {
				className: "jo-final-header",
				children: /* @__PURE__ */ u("h1", { children: f("games.justone.finalTitle") })
			}),
			/* @__PURE__ */ d("div", {
				className: "jo-final-scroll",
				children: [
					/* @__PURE__ */ u("div", {
						className: "jo-final-score",
						children: /* @__PURE__ */ u(A, {
							color: "#00a7df",
							name: h,
							children: /* @__PURE__ */ u("strong", { children: f("games.justone.finalScore", { n: p.score }) })
						})
					}),
					/* @__PURE__ */ u("div", {
						className: "jo-team",
						children: p.players.map((e) => {
							let r = t.find((t) => t.rid === e), i = n.autopilot?.[e];
							return /* @__PURE__ */ d("span", { children: [
								/* @__PURE__ */ u("i", { style: { background: o[(r?.colorIndex ?? 0) % o.length].hex } }),
								m(e),
								i !== void 0 && i > 0 && /* @__PURE__ */ u("small", { children: f("session.autopilot.share", { n: Math.round(i * 100) }) })
							] }, e);
						})
					}),
					r !== void 0 && /* @__PURE__ */ u("p", {
						className: "jo-hints",
						children: f("session.hint.usedCount", { n: r })
					}),
					/* @__PURE__ */ d("section", {
						className: "jo-history",
						"aria-label": f("games.justone.history"),
						children: [/* @__PURE__ */ u("h2", { children: f("games.justone.history") }), p.history.map((e) => /* @__PURE__ */ d("details", {
							className: "jo-history-round",
							children: [/* @__PURE__ */ d("summary", { children: [
								/* @__PURE__ */ u("span", { children: f("games.justone.round", { n: e.round }) }),
								/* @__PURE__ */ u("strong", { children: e.target }),
								/* @__PURE__ */ u(j, { entry: e })
							] }), /* @__PURE__ */ d("div", {
								className: "jo-history-detail",
								children: [
									/* @__PURE__ */ u("span", { children: f("games.justone.active", { name: m(e.active) }) }),
									e.guess && /* @__PURE__ */ u("strong", { children: f("games.justone.guessWas", { word: e.guess }) }),
									/* @__PURE__ */ u("ul", { children: e.clues.map((e) => /* @__PURE__ */ d("li", {
										"data-cancelled": e.cancelled,
										children: [
											/* @__PURE__ */ u("span", { children: m(e.by) }),
											/* @__PURE__ */ u("strong", { children: e.word }),
											e.cancelled && /* @__PURE__ */ u("small", { children: f("games.justone.cancelled") })
										]
									}, e.id)) })
								]
							})]
						}, e.round))]
					})
				]
			}),
			/* @__PURE__ */ u("footer", {
				className: "jo-final-actions",
				children: s || c ? /* @__PURE__ */ d(l, { children: [s && /* @__PURE__ */ u(i, {
					className: "jo-button",
					label: f("session.result.playAgain"),
					confirmLabel: f("games.justone.confirmAgain"),
					onConfirm: s
				}), c && /* @__PURE__ */ u(i, {
					className: "jo-secondary",
					label: f("session.result.backToLobby"),
					confirmLabel: f("games.justone.confirmLobby"),
					onConfirm: c
				})] }) : /* @__PURE__ */ u("p", {
					role: "status",
					children: f("session.result.waitHost")
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/justone/entry.tsx
var L = {
	definition: O,
	View: M,
	bot: F,
	OverView: I,
	locales: {
		zh: {
			name: "独家暗语",
			desc: "写下独一无二的线索，帮助伙伴猜出暗语；相同线索全部消除。",
			rules: "目标：\n全员合作，在13张词卡耗尽前尽量猜中更多暗语。每次只有一名猜词者，其他玩家是提示者。\n准备：\n本游戏采用Repos官方2025版基础规则，词卡内容使用桌游趴已有中文词库。每张卡有五个候选词，每局随机准备13张卡；英文界面同样使用这套中文词库。首位猜词者随机选择，之后按座位顺序轮换。\n流程：\n· 猜词者看不到词卡，选择1至5之间的数字，对应词就是本轮暗语。提示者不认识暗语时，可在任何人提交线索前请求改选其他数字。\n· 提示者独立写一个线索。3至4人局按官方变体，每位提示者写两个不同线索；5至7人局每位提示者写一个。提交后不能修改，也不能提前看其他人的线索。\n· 线索必须是一个词，可以是复合词、专名、数字、拟声词、缩写或特殊符号。不得使用暗语的其他语言翻译、同根词、谐音或自造词。\n· 所有人提交后，只有提示者能看到全部线索。相同线索全部取消；同根词、单复数和拼写错误造成的相同词也算重复。提示者直接点击画架，将重复或非法线索取消。字面相同的线索和暗语本身自动取消且不能恢复；其余语义关系由提示者共同核对。每次调整取消结果后，所有提示者重新确认，再向猜词者公开剩余线索。\n· 若线索全部取消，本张卡直接弃置。否则猜词者只能提交一次猜测，或选择放弃。字面相符自动判为猜中；其他猜测由所有提示者共同判定，意见不一致时讨论后更改判断。猜词者不能再提交第二次猜测。\n结算：\n根据猜词结果，按以下方式结算：\n· 猜中：获得 1 分。\n· 放弃或线索全部取消：弃置当前卡，不得分。\n· 猜错：弃置当前卡及牌堆顶的一张额外卡。如果当前已是最后一张卡，则失去此前获得的 1 分，最低降至 0 分。\n揭晓后，由当前猜词者点击继续，下一位玩家成为猜词者。\n结束：\n13张卡耗尽后，全员查看共同得分：0至3分继续努力，4至6分尚可，7至8分不错，9至10分良好，11分出色，12分接近完美，13分完美。",
			score: "共同得分",
			card: "词卡 {{n}} / 13",
			remaining: "牌堆剩余 {{n}} 张",
			active: "{{name}}猜词",
			you: "你",
			choose: "选择一个数字",
			waitChoose: "等待{{name}}选号",
			write: "写下一个线索",
			writeTwo: "写下两个不同线索",
			waitClues: "等待提示者写线索（{{n}} / {{total}}）",
			submitted: "已提交",
			hidden: "尚未公开",
			compare: "取消重复或非法线索，再确认",
			waitCompare: "提示者正在比较线索",
			guessPrompt: "根据剩余线索猜暗语",
			waitGuess: "等待{{name}}猜词",
			judgePrompt: "共同判定这次猜测是否正确",
			waitJudge: "提示者正在判定你的猜测",
			clueLabel: "线索 {{n}}",
			guessLabel: "你的猜测",
			submitClues: "提交线索",
			submitGuess: "提交唯一猜测",
			pass: "放弃本张卡",
			confirmPass: "确认放弃本张卡",
			reselect: "不认识暗语，请改选其他数字",
			confirm: "确认线索",
			confirmed: "已确认（{{n}} / {{total}}）",
			cancel: "取消线索“{{word}}”",
			restore: "恢复线索“{{word}}”",
			cancelled: "已取消",
			locked: "重复线索或暗语本身",
			correctVote: "猜中了",
			wrongVote: "没有猜中",
			votes: "已判定 {{n}} / {{total}}",
			correct: "猜中暗语",
			wrong: "没有猜中",
			passed: "本轮放弃",
			allCancelled: "线索全部取消",
			gain: "获得 1 分",
			lose: "失去 1 分",
			noScore: "本张卡不得分",
			extra: "额外弃置下一张卡",
			next: "下一轮",
			finish: "查看共同成绩",
			waitNext: "等待{{name}}继续",
			mystery: "本轮暗语",
			guessWas: "猜测：{{word}}",
			clues: "本轮线索",
			history: "本局回顾",
			round: "第 {{n}} 轮",
			finalTitle: "你们的独家默契",
			finalScore: "{{n}} / 13",
			rating0: "继续努力！",
			rating4: "尚可，还有进步空间。",
			rating7: "不错，继续挑战！",
			rating9: "良好，默契正在形成。",
			rating11: "出色，值得自豪！",
			rating12: "接近完美！",
			rating13: "完美的共同成绩！",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			invalidAction: "当前不能执行这个操作，请检查阶段或等待其他玩家。"
		},
		en: {
			name: "Just One",
			desc: "Write a unique clue to help your teammate guess. Matching clues all disappear.",
			rules: "Goal:\nCooperate to guess as many Mystery Words as possible before the 13-card deck runs out. One active player guesses; everyone else writes clues.\nSetup:\nUses the official Repos 2025 base rules with BGParty’s existing Chinese word library replacing the printed words. Each card has five choices; 13 cards are prepared randomly. The English interface also uses this Chinese library. Choose the first active player randomly, then rotate in seating order.\nGameplay:\n· The active player cannot see the card and chooses a number from 1 to 5. That word becomes the Mystery Word. If a clue giver does not know it, they may request a different number before anyone submits a clue.\n· Write clues independently. With 3 or 4 players, each clue giver writes two different clues, using the official variant. With 5 to 7 players, each writes one. Submitted clues cannot be edited or seen by others before everyone has submitted.\n· A clue must be one word. Compounds, proper names, numbers, onomatopoeia, acronyms and special characters are allowed. Translations of the Mystery Word, words in its family, homophones and invented words are invalid.\n· Once everyone submits, only the clue givers see all clues. Cancel every identical clue, including words in the same family, singular/plural forms and spelling variants. Click an easel to cancel or restore a clue. Exact matches and the Mystery Word itself are canceled automatically and cannot be restored; clue givers review semantic relationships together. After any change, every clue giver must confirm again before the surviving clues are revealed.\n· If all clues are canceled, discard this card. Otherwise the active player makes one guess or passes. An exact match is accepted automatically. Other answers are judged by all clue givers; discuss and change votes until everyone agrees. No second guess is allowed.\nScoring:\nResolve the guess as follows:\n· Correct guess: earn 1 point.\n· Pass or all clues canceled: discard the current card without scoring.\n· Incorrect guess: discard the current card and one additional card from the deck. If this was the last card, lose 1 previously earned point instead, to a minimum of zero.\nAfter the reveal, the active player selects Continue, and the next player becomes active.\nEnd:\nWhen all 13 cards are used, check your shared score: 0–3 keep trying, 4–6 not bad, 7–8 a good start, 9–10 good, 11 very good, 12 impressive, 13 perfect.",
			score: "Shared score",
			card: "Card {{n}} / 13",
			remaining: "{{n}} cards in deck",
			active: "{{name}} guesses",
			you: "You",
			choose: "Choose a number",
			waitChoose: "Waiting for {{name}} to choose",
			write: "Write one clue",
			writeTwo: "Write two different clues",
			waitClues: "Waiting for clues ({{n}} / {{total}})",
			submitted: "Submitted",
			hidden: "Not revealed",
			compare: "Cancel matching or invalid clues, then confirm",
			waitCompare: "Clue givers are comparing clues",
			guessPrompt: "Guess from the remaining clues",
			waitGuess: "Waiting for {{name}} to guess",
			judgePrompt: "Agree whether this guess is correct",
			waitJudge: "Clue givers are judging your guess",
			clueLabel: "Clue {{n}}",
			guessLabel: "Your guess",
			submitClues: "Submit clues",
			submitGuess: "Submit your only guess",
			pass: "Pass this card",
			confirmPass: "Confirm passing this card",
			reselect: "Unknown word: request a different number",
			confirm: "Confirm clues",
			confirmed: "Confirmed ({{n}} / {{total}})",
			cancel: "Cancel clue “{{word}}”",
			restore: "Restore clue “{{word}}”",
			cancelled: "Canceled",
			locked: "Matching clue or Mystery Word",
			correctVote: "Correct",
			wrongVote: "Incorrect",
			votes: "{{n}} / {{total}} have voted",
			correct: "Mystery Word guessed",
			wrong: "Incorrect guess",
			passed: "Passed",
			allCancelled: "All clues canceled",
			gain: "Earned 1 point",
			lose: "Lost 1 point",
			noScore: "No point for this card",
			extra: "Next card also discarded",
			next: "Next round",
			finish: "See your shared result",
			waitNext: "Waiting for {{name}} to continue",
			mystery: "Mystery Word",
			guessWas: "Guess: {{word}}",
			clues: "Clues",
			history: "Your game",
			round: "Round {{n}}",
			finalTitle: "Your unique connection",
			finalScore: "{{n}} / 13",
			rating0: "Keep trying!",
			rating4: "Not bad. Room to improve.",
			rating7: "A good start. Try again!",
			rating9: "Good. A step towards glory.",
			rating11: "Very good. Be proud!",
			rating12: "Impressive. Almost champions!",
			rating13: "Incredible. A perfect score!",
			confirmAgain: "Confirm another game",
			confirmLobby: "Confirm return to lobby",
			invalidAction: "That action is unavailable now. Check the phase or wait for the other players."
		}
	}
};
//#endregion
export { L as default };
