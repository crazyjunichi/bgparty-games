import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useI18nSettings as n, useT as r } from "@bgparty/sdk/i18n";
import { seatName as i } from "@bgparty/sdk/ui/player-strip";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { useLayoutEffect as o, useRef as s, useState as c } from "react";
import { useFxAnchor as l } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as u } from "@bgparty/sdk/fx/delta-number";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { Texture as f } from "@bgparty/sdk/texture";
import { botAvatarOf as p } from "@bgparty/sdk/lobby";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as h } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { createDiceRollRenderer as y } from "@bgparty/sdk/fx/dice-roll";
import { Flash as b, Floater as x, FlySprite as S, PulseBox as C } from "@bgparty/sdk/fx/primitives";
import { playSettle as w } from "@bgparty/sdk/sfx";
import { GameOverScreen as T } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/lasvegas-royale/meta.ts
var E = {
	id: "lasvegas-royale",
	tier: "beta",
	mechanics: ["dice-rolling", "area-control"],
	interactionTags: [],
	nameKey: "games.lasvegas-royale.name",
	descKey: "games.lasvegas-royale.desc",
	rulesKey: "games.lasvegas-royale.rules",
	icon: "👑",
	iconImg: "games/lasvegas-royale.webp",
	rulesUrl: { de: "https://rules.bgparty.uuppi.com/lasvegas-royale/de.pdf" },
	minPlayers: 3,
	maxPlayers: 5,
	bestPlayers: [4, 5],
	accent: "#d97706",
	releasedAt: "2026-09-21",
	search: {
		py: "la si wei jia si hao hua ban",
		init: "lswjshhb"
	},
	hotseat: "cover"
}, D = [
	"luckyPunch",
	"jackpot",
	"primeTime",
	"fiftyFifty",
	"highFive",
	"badLuck",
	"payDay",
	"powerPlay",
	"noEntry",
	"knockout",
	"blockIt",
	"handicap",
	"blackBox",
	"doubleDown",
	"niceDice",
	"myChoice"
], O = t.int().min(1).max(6), k = t.string(), A = t.int().min(0).max(5), ee = t.discriminatedUnion("type", [
	t.object({ type: t.literal("roll") }),
	t.object({ type: t.literal("passChip") }),
	t.object({
		type: t.literal("place"),
		value: O
	}),
	t.object({ type: t.literal("forfeit") }),
	t.object({
		type: t.literal("powerPlace"),
		big: t.boolean(),
		value: O
	}),
	t.object({
		type: t.literal("luckyPick"),
		n: t.int().min(1).max(3)
	}),
	t.object({
		type: t.literal("luckyGuess"),
		n: t.int().min(1).max(3)
	}),
	t.object({ type: t.literal("fiftyStop") }),
	t.object({
		type: t.literal("fiftyBet"),
		high: t.boolean()
	}),
	t.object({
		type: t.literal("noEntry"),
		target: A.nullable()
	}),
	t.object({
		type: t.literal("knockout"),
		big: t.boolean()
	}),
	t.object({
		type: t.literal("blockIt"),
		cluster: t.int().nonnegative(),
		target: A
	}),
	t.object({
		type: t.literal("handicap"),
		space: t.int().min(0).max(8),
		fromCasino: A
	}),
	t.object({ type: t.literal("handicapSkip") }),
	t.object({
		type: t.literal("handicapRotate"),
		big: t.boolean(),
		value: O
	}),
	t.object({
		type: t.literal("handicapReturn"),
		fromCasino: A,
		big: t.boolean()
	}),
	t.object({
		type: t.literal("doubleDown"),
		small: t.int().nonnegative(),
		big: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("niceDice"),
		value: O,
		big: t.boolean()
	}),
	t.object({ type: t.literal("niceSkip") }),
	t.object({
		type: t.literal("myChoice"),
		value: O
	}),
	t.object({
		type: t.literal("myTile"),
		target: A
	}),
	t.object({
		type: t.literal("myRotate"),
		big: t.boolean(),
		value: O
	}),
	t.object({
		type: t.literal("myReturn"),
		fromCasino: A,
		big: t.boolean()
	}),
	t.object({
		type: t.literal("myGold"),
		big: t.boolean()
	}),
	t.object({
		type: t.literal("primeTime"),
		place: t.tuple([t.boolean(), t.boolean()])
	}),
	t.object({
		type: t.literal("blackBoxSplit"),
		pileA: t.array(t.int().min(0).max(5))
	}),
	t.object({
		type: t.literal("blackBoxPick"),
		pile: t.union([t.literal(0), t.literal(1)])
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), j = t.object({
	small: t.int().nonnegative(),
	big: t.int().nonnegative()
}), M = t.enum(D), N = t.int().min(30).max(100), P = t.record(t.string(), j), F = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("luckyPick"),
		who: t.tuple([k]),
		guesser: k
	}),
	t.object({
		kind: t.literal("luckyGuess"),
		who: t.tuple([k]),
		picker: k
	}),
	t.object({
		kind: t.literal("fifty"),
		who: t.tuple([k]),
		pos: t.int().min(1).max(5),
		lastSum: t.int()
	}),
	t.object({
		kind: t.literal("noEntry"),
		who: t.tuple([k]),
		mustMove: t.boolean()
	}),
	t.object({
		kind: t.literal("knockout"),
		who: t.array(k)
	}),
	t.object({
		kind: t.literal("blockIt"),
		who: t.tuple([k]),
		clusters: t.array(t.int())
	}),
	t.object({
		kind: t.literal("handicap"),
		who: t.tuple([k]),
		spaces: t.array(t.int())
	}),
	t.object({
		kind: t.literal("handicapChoice"),
		who: t.tuple([k])
	}),
	t.object({
		kind: t.literal("doubleDown"),
		who: t.tuple([k]),
		maxSmall: t.int().nonnegative(),
		maxBig: t.int().nonnegative()
	}),
	t.object({
		kind: t.literal("niceDice"),
		who: t.tuple([k]),
		candidates: t.array(t.object({
			value: O,
			big: t.boolean()
		}))
	}),
	t.object({
		kind: t.literal("myChoice"),
		who: t.tuple([k]),
		dice: t.tuple([O, O])
	}),
	t.object({
		kind: t.literal("myTile"),
		who: t.tuple([k]),
		candidates: t.array(A)
	}),
	t.object({
		kind: t.literal("myRotateOrReturn"),
		who: t.tuple([k])
	}),
	t.object({
		kind: t.literal("myGold"),
		who: t.tuple([k])
	}),
	t.object({
		kind: t.literal("primeTime"),
		who: t.tuple([k]),
		dice: t.tuple([O, O])
	}),
	t.object({
		kind: t.literal("blackBoxSplit"),
		who: t.tuple([k]),
		winner: k
	}),
	t.object({
		kind: t.literal("blackBoxPick"),
		who: t.tuple([k])
	})
]), te = t.object({
	round: t.int().min(1),
	phase: t.enum([
		"play",
		"payout",
		"done"
	]),
	turn: k.nullable(),
	rolled: t.array(t.object({
		value: O,
		big: t.boolean()
	})).nullable(),
	casinos: t.tuple([
		t.array(N),
		t.array(N),
		t.array(N),
		t.array(N),
		t.array(N),
		t.array(N)
	]),
	placed: t.tuple([
		P,
		P,
		P,
		P,
		P,
		P
	]),
	gray: t.tuple([
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative()
	]),
	tiles: t.tuple([
		M.nullable(),
		M.nullable(),
		M.nullable(),
		M.nullable(),
		M.nullable(),
		M.nullable()
	]),
	blocked: A.nullable(),
	players: t.array(t.object({
		rid: k,
		money: t.int(),
		notes: t.int().nonnegative(),
		chips: t.int().nonnegative(),
		small: t.int().nonnegative(),
		big: t.int().nonnegative()
	})),
	tileState: t.object({
		jackpotPos: t.int().min(0).max(5),
		noEntryPos: t.int().min(0).max(5),
		highFiveHolder: k.nullable(),
		powerPlayHolder: k.nullable(),
		bar: t.record(t.string(), j),
		clusters: t.array(t.int()),
		handicapUsed: t.array(t.boolean()),
		doubleDown: t.record(t.string(), j),
		niceDice: t.array(t.object({
			rid: k,
			big: t.boolean()
		}).nullable()),
		gold: t.object({
			rid: k,
			big: t.boolean()
		}).nullable(),
		primeDice: t.array(t.object({
			rid: k,
			casino: A
		}))
	}),
	pending: F.nullable(),
	payoutIdx: t.int()
}), I = t.object({
	luckyHeld: t.int().min(1).max(3).nullable(),
	blackBoxPiles: t.tuple([t.array(t.int()), t.array(t.int())]).nullable()
}), ne = [
	...Array(11).fill(30),
	...Array(11).fill(40),
	...Array(13).fill(50),
	...Array(15).fill(60),
	...Array(13).fill(70),
	...Array(11).fill(80),
	...Array(9).fill(90),
	...Array(7).fill(100)
], re = [
	["luckyPunch", "jackpot"],
	["primeTime", "fiftyFifty"],
	["highFive", "badLuck"],
	["payDay", "powerPlay"],
	["noEntry", "knockout"],
	["blockIt", "handicap"],
	["blackBox", "doubleDown"],
	["niceDice", "myChoice"]
], ie = "$gray", ae = [
	30,
	40,
	50,
	60,
	70,
	80
], L = [
	"start",
	0,
	"chip1",
	30,
	40,
	60
], oe = [
	"start",
	"chip2",
	"empty",
	30,
	"empty",
	"chip1"
], se = [
	"chip1",
	"chip1",
	30,
	30,
	30,
	"choice",
	"choice",
	"choice",
	"choice"
], ce = [
	"chip1",
	"chip2",
	30,
	40,
	50,
	60
], le = [
	0,
	0,
	0,
	20,
	20,
	60
], R = {
	payout: 1300,
	supply: 900,
	tile: 1100
}, z = (e) => e ? e.small + e.big * 2 : 0, B = () => ({
	small: 0,
	big: 0
});
function V(t, n) {
	let r = e(t.seed, t.rngCursor, n);
	return t.rngCursor += 1, r;
}
function ue(e, t) {
	let n = [];
	for (let r = 0; r < t.small; r += 1) n.push({
		value: V(e, 6) + 1,
		big: !1
	});
	for (let r = 0; r < t.big; r += 1) n.push({
		value: V(e, 6) + 1,
		big: !0
	});
	return n;
}
function H(e) {
	return [V(e, 6) + 1, V(e, 6) + 1];
}
function U(e, t, n) {
	e.money[t] += n, e.noteCounts[t] += 1;
}
function W(e, t, n) {
	e.chips[t] += n;
}
function de(e) {
	let t = [];
	for (let n = 0; n < 6; n += 1) {
		let n = e.pile.shift(), r = e.pile.shift();
		t.push([n, r].sort((e, t) => t - e));
	}
	t.sort((e, t) => t[0] + t[1] - (e[0] + e[1]) || t[0] - e[0]), e.casinos = Array.from({ length: 6 }, (e, n) => t[5 - n]);
}
function fe(e) {
	let t = re.map((e, t) => t);
	for (let n = t.length - 1; n > 0; --n) {
		let r = V(e, n + 1);
		[t[n], t[r]] = [t[r], t[n]];
	}
	e.tiles = Array.from({ length: 6 }, (n, r) => r < 3 ? re[t[r]][V(e, 2)] : null);
}
function pe(e) {
	e.blocked = null, e.noEntryPos = 0, e.jackpotPos = 0, e.highFiveHolder = null, e.powerPlayHolder = null, e.bar = {}, e.clusters = e.tiles.includes("blockIt") ? [
		1,
		1,
		2,
		2,
		3
	] : [], e.handicapUsed = Array(9).fill(!1), e.doubleDown = {}, e.niceDice = [
		,
		,
		,
		,
		,
		,
	].fill(null), e.gold = null, e.primeDice = [], e.lostDice = {}, e.grayOut = 0, e.gray = e.tiles.includes("handicap") ? [
		1,
		1,
		1,
		2,
		2,
		2
	] : [
		0,
		0,
		0,
		0,
		0,
		0
	];
}
function me(e, t, n) {
	let r = [...ne], i = {
		players: t,
		round: 1,
		startIdx: 0,
		turnIdx: 0,
		supply: {},
		rolled: null,
		placed: Array.from({ length: 6 }, () => ({})),
		gray: [
			0,
			0,
			0,
			0,
			0,
			0
		],
		grayOut: 0,
		casinos: [],
		pile: r,
		tiles: [
			,
			,
			,
			,
			,
			,
		].fill(null),
		blocked: null,
		noEntryPos: 0,
		jackpotPos: 0,
		highFiveHolder: null,
		powerPlayHolder: null,
		bar: {},
		clusters: [],
		handicapUsed: Array(9).fill(!1),
		doubleDown: {},
		niceDice: [
			,
			,
			,
			,
			,
			,
		].fill(null),
		gold: null,
		primeDice: [],
		lostDice: {},
		money: {},
		noteCounts: {},
		chips: {},
		pending: null,
		payoutIdx: -1,
		payoutStep: "pre",
		badLuckPayers: [],
		fiftyPos: 0,
		fiftyLastSum: 0,
		firstWinners: [
			,
			,
			,
			,
			,
			,
		].fill(null),
		phase: "play",
		beatMs: 0,
		seed: n,
		rngCursor: 0
	};
	for (let e = r.length - 1; e > 0; --e) {
		let t = V(i, e + 1);
		[r[e], r[t]] = [r[t], r[e]];
	}
	for (let e of t) i.supply[e] = {
		small: 7,
		big: 1
	}, i.money[e] = 0, i.noteCounts[e] = 0, i.chips[e] = 2;
	de(i), fe(i), pe(i);
	let a = i.casinos.map((e, t) => ({
		kind: "supply",
		data: {
			casino: t,
			notes: e
		},
		...t > 0 ? { with: !0 } : {}
	}));
	return a.push({
		kind: "tiles",
		data: { tiles: i.tiles },
		with: !0
	}), {
		state: i,
		fx: a
	};
}
function he(e, t) {
	for (let n = 1; n <= e.players.length; n += 1) {
		let r = (t + n) % e.players.length;
		if (z(e.supply[e.players[r]]) > 0) return r;
	}
	return null;
}
function ge(e, t) {
	e.rolled = null;
	let n = he(e, e.turnIdx);
	n === null ? (e.phase = "payout", e.payoutIdx = 0, e.payoutStep = "pre", e.turnIdx = -1, e.beatMs = R.payout) : e.turnIdx = n;
}
function _e(e, t, n, r) {
	e.tiles[t] === "highFive" && e.highFiveHolder === null && (n === "$gray" ? e.gray[t] : z(e.placed[t][n])) >= 5 && (e.highFiveHolder = n, r.push({
		kind: "tile",
		data: {
			tile: "highFive",
			casino: t,
			rid: n
		}
	}));
}
function ve(e, t) {
	let n = e.tiles.indexOf("powerPlay");
	if (n < 0 || e.powerPlayHolder === null) return;
	let r = e.powerPlayHolder, i = xe(e, n), a = i.find((e) => e.who === r)?.count ?? 0, o = i.filter((e) => e.who !== r).map((e) => e.count);
	(a === 0 || o.some((e) => e >= a)) && (e.powerPlayHolder = null, t.push({
		kind: "tile",
		data: {
			tile: "powerPlay",
			casino: n,
			rid: r,
			lost: !0
		}
	}));
}
function G(e, t) {
	ve(e, t);
}
function ye(e, t, n, r, i) {
	let a = e.tiles[t];
	if (a) switch (a) {
		case "luckyPunch":
			e.pending = {
				kind: "luckyPick",
				by: n
			};
			return;
		case "jackpot": {
			let [i, a] = H(e);
			if (i + a === 7 || i === a) {
				let o = ae[e.jackpotPos];
				U(e, n, o), e.jackpotPos = 0, r.push({
					kind: "jackpot",
					rid: n,
					data: {
						casino: t,
						dice: [i, a],
						win: !0,
						amount: o
					}
				});
			} else e.jackpotPos = Math.min(e.jackpotPos + 1, 5), r.push({
				kind: "jackpot",
				rid: n,
				data: {
					casino: t,
					dice: [i, a],
					win: !1,
					pos: e.jackpotPos
				}
			});
			return;
		}
		case "fiftyFifty": {
			let [i, a] = H(e);
			e.fiftyPos = 1, e.fiftyLastSum = i + a, r.push({
				kind: "fifty",
				rid: n,
				data: {
					casino: t,
					dice: [i, a],
					pos: 1
				}
			}), e.pending = {
				kind: "fifty",
				by: n
			};
			return;
		}
		case "highFive":
			i && _e(e, t, n, r);
			return;
		case "badLuck": return;
		case "payDay": {
			let i = e.casinos.filter((t, r) => z(e.placed[r][n]) > 0).length;
			i === 1 ? W(e, n, 1) : i === 2 ? W(e, n, 2) : i > 0 && U(e, n, i * 10), r.push({
				kind: "tile",
				data: {
					tile: "payDay",
					casino: t,
					rid: n,
					casinos: i
				}
			});
			return;
		}
		case "powerPlay": {
			let i = xe(e, t), a = i.find((e) => e.who === n)?.count ?? 0, o = i.filter((e) => e.who !== n).map((e) => e.count);
			a > 0 && o.every((e) => e < a) && e.powerPlayHolder !== n && (e.powerPlayHolder = n, r.push({
				kind: "tile",
				data: {
					tile: "powerPlay",
					casino: t,
					rid: n
				}
			}));
			return;
		}
		case "noEntry":
			e.pending = {
				kind: "noEntry",
				by: n,
				casino: t,
				mustMove: e.blocked === null
			};
			return;
		case "knockout": {
			let t = e.players.filter((t) => {
				if (t === n) return !1;
				let r = e.bar[t], i = r ? r.small + r.big : 0;
				return z(e.supply[t]) > 0 && i < 2;
			});
			t.length > 0 ? e.pending = {
				kind: "knockout",
				by: n,
				waiting: t
			} : be(e, n, r);
			return;
		}
		case "blockIt":
			e.clusters.length > 0 && (e.pending = {
				kind: "blockIt",
				by: n
			});
			return;
		case "handicap": {
			let t = e.gray.some((t, n) => t > 0 && e.blocked !== n), r = e.handicapUsed.some((e) => !e);
			t && r && (e.pending = {
				kind: "handicap",
				by: n
			});
			return;
		}
		case "doubleDown":
			z(e.placed[t][n]) > 0 && (e.pending = {
				kind: "doubleDown",
				by: n,
				casino: t
			});
			return;
		case "niceDice": {
			if (!i) return;
			let r = e.rolled ?? [];
			r.length > 0 && (e.pending = {
				kind: "niceDice",
				by: n,
				casino: t,
				placedValue: t + 1,
				candidates: r
			});
			return;
		}
		case "myChoice": {
			let [i, a] = H(e);
			r.push({
				kind: "tile",
				data: {
					tile: "myChoice",
					casino: t,
					rid: n,
					dice: [i, a]
				}
			}), e.pending = {
				kind: "myChoice",
				by: n,
				casino: t,
				dice: [i, a]
			};
			return;
		}
		case "primeTime":
		case "blackBox": return;
	}
}
function be(e, t, n) {
	let r = e.bar[t];
	r && z(r) > 0 && (e.supply[t].small += r.small, e.supply[t].big += r.big, e.bar[t] = B(), n.push({
		kind: "tile",
		data: {
			tile: "knockout",
			rid: t,
			freed: !0
		}
	}));
}
function K(e, t) {
	e.pending === null && ge(e, t);
}
function xe(e, t) {
	let n = Object.entries(e.placed[t]).map(([e, t]) => ({
		who: e,
		count: z(t)
	})).filter((e) => e.count > 0);
	e.gray[t] > 0 && n.push({
		who: ie,
		count: e.gray[t]
	});
	let r = /* @__PURE__ */ new Map();
	for (let n of e.primeDice) n.casino === t && r.set(n.rid, (r.get(n.rid) ?? 0) + 1);
	for (let [e, t] of r) {
		let r = n.find((t) => t.who === e);
		r ? r.count += t : n.push({
			who: e,
			count: t
		});
	}
	return n;
}
function Se(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n.count, (t.get(n.count) ?? 0) + 1);
	return {
		alive: e.filter((e) => t.get(e.count) === 1).sort((e, t) => t.count - e.count),
		busted: e.filter((e) => (t.get(e.count) ?? 0) > 1)
	};
}
function Ce(e, t, n) {
	let r = e.tiles[t];
	if (r === "badLuck") {
		let r = e.players.map((n) => ({
			rid: n,
			n: z(e.placed[t][n])
		})), i = Math.min(...r.map((e) => e.n));
		e.badLuckPayers = r.filter((e) => e.n === i).map((e) => e.rid), n.push({
			kind: "tile",
			data: {
				tile: "badLuck",
				casino: t,
				payers: e.badLuckPayers
			}
		});
	}
	if (r === "primeTime") {
		let { alive: r } = Se(xe(e, t)), i = r[0]?.who;
		if (i && i !== "$gray") {
			let r = H(e);
			n.push({
				kind: "primeTime",
				rid: i,
				data: {
					casino: t,
					dice: r
				}
			}), e.pending = {
				kind: "primeTime",
				by: i,
				dice: r
			};
			return;
		}
	}
	e.payoutStep = "settle", e.beatMs = R.payout;
}
function we(e, t, n) {
	let r = Object.entries(e.placed[t]).map(([e, t]) => ({
		who: e,
		small: t.small,
		big: t.big
	})), i = e.gray[t], { alive: a, busted: o } = Se(xe(e, t));
	for (let n of o) n.who === "$gray" ? e.gray[t] = 0 : e.placed[t][n.who] = B();
	let s = e.casinos[t], c = [];
	for (let t = 0; t < a.length && t < s.length; t += 1) {
		let n = a[t].who;
		n === "$gray" ? e.pile.push(s[t]) : (e.money[n] += s[t], e.noteCounts[n] += 1, c.push({
			rid: n,
			note: s[t]
		}));
	}
	e.firstWinners[t] = a[0] && a[0].who !== "$gray" ? a[0].who : null;
	let l = s.slice(a.length);
	for (let t of l) e.pile.push(t);
	e.casinos[t] = [], e.placed[t] = {};
	for (let t of r) e.supply[t.who].small += t.small, e.supply[t.who].big += t.big;
	e.grayOut += i, e.gray[t] = 0, e.primeDice = e.primeDice.filter((e) => e.casino !== t), n.push({
		kind: "payout",
		data: {
			casino: t,
			busted: o,
			awards: c,
			leftover: l
		}
	}), e.payoutStep = "post", e.beatMs = R.payout;
}
function Te(e, t, n) {
	if (e.tiles[t] === "blackBox") {
		let r = e.firstWinners[t];
		if (r) {
			let i = e.players.indexOf(r), a = e.players[(i + 1) % e.players.length];
			e.pending = {
				kind: "blackBoxSplit",
				by: a,
				winner: r
			}, n.push({
				kind: "tile",
				data: {
					tile: "blackBox",
					casino: t,
					winner: r,
					splitter: a
				}
			});
			return;
		}
	}
	e.payoutStep = "post2", e.beatMs = R.tile;
}
function Ee(e, t, n) {
	let r = e.tiles[t];
	if (r === "doubleDown") {
		let { alive: r, busted: i } = Se(Object.entries(e.doubleDown).map(([e, t]) => ({
			who: e,
			count: z(t)
		})).filter((e) => e.count > 0)), a = [];
		r[0] && (U(e, r[0].who, 60), a.push({
			rid: r[0].who,
			amount: 60
		})), r[1] && (U(e, r[1].who, 30), a.push({
			rid: r[1].who,
			amount: 30
		}));
		for (let [t, n] of Object.entries(e.doubleDown)) e.supply[t].small += n.small, e.supply[t].big += n.big;
		e.doubleDown = {}, n.push({
			kind: "tile",
			data: {
				tile: "doubleDown",
				casino: t,
				busted: i,
				awards: a
			}
		});
	}
	if (r === "highFive" && e.highFiveHolder && e.highFiveHolder !== "$gray" && (U(e, e.highFiveHolder, 100), n.push({
		kind: "tile",
		data: {
			tile: "highFive",
			casino: t,
			rid: e.highFiveHolder,
			amount: 100
		}
	})), r === "myChoice" && e.gold && (U(e, e.gold.rid, 60), n.push({
		kind: "tile",
		data: {
			tile: "myChoice",
			casino: t,
			rid: e.gold.rid,
			amount: 60
		}
	}), e.supply[e.gold.rid][e.gold.big ? "big" : "small"] += 1, e.gold = null), r === "niceDice") {
		let r = [];
		e.niceDice.forEach((t, n) => {
			if (!t) return;
			let i = ce[n];
			i === "chip1" ? W(e, t.rid, 1) : i === "chip2" ? W(e, t.rid, 2) : U(e, t.rid, i), r.push({
				rid: t.rid,
				value: n + 1,
				reward: i
			}), e.supply[t.rid][t.big ? "big" : "small"] += 1;
		}), e.niceDice = [
			,
			,
			,
			,
			,
			,
		].fill(null), r.length > 0 && n.push({
			kind: "tile",
			data: {
				tile: "niceDice",
				casino: t,
				awards: r
			}
		});
	}
	e.payoutIdx += 1, e.payoutStep = "pre", e.beatMs = R.payout;
}
function De(e, t) {
	for (let t of e.badLuckPayers) {
		let n = 50, r = Math.min(e.money[t], n);
		if (e.money[t] -= r, n -= r, n > 0 && e.chips[t] > 0) {
			let r = Math.min(e.chips[t], Math.ceil(n / 10));
			e.chips[t] -= r;
			let i = r * 10;
			i > n && (e.money[t] += i - n);
		}
	}
	if (e.badLuckPayers.length > 0 && t.push({
		kind: "badLuck",
		data: { payers: e.badLuckPayers }
	}), e.badLuckPayers = [], e.round >= 3) {
		e.phase = "done", e.turnIdx = -1;
		return;
	}
	e.round += 1;
	let n = -1;
	for (let t = 0; t < 6; t += 1) {
		let r = e.firstWinners[t];
		if (r) {
			n = e.players.indexOf(r);
			break;
		}
	}
	n < 0 && (n = (e.startIdx + 1) % e.players.length), e.startIdx = n, e.turnIdx = n, e.firstWinners = [
		,
		,
		,
		,
		,
		,
	].fill(null);
	for (let t of e.players) e.supply[t] = {
		small: 7,
		big: 1
	}, e.chips[t] += 2;
	e.placed = Array.from({ length: 6 }, () => ({})), de(e), fe(e), pe(e), e.phase = "play", e.payoutIdx = -1, e.beatMs = R.supply, t.push(...e.casinos.map((e, t) => ({
		kind: "supply",
		data: {
			casino: t,
			notes: e
		},
		with: !0
	}))), t.push({
		kind: "tiles",
		data: { tiles: e.tiles },
		with: !0
	});
}
function Oe(e, t, n, r) {
	let i = e.placed[t][n] ??= B();
	r ? i.big += 1 : i.small += 1;
}
function ke(e, t, n, r) {
	let i = e.placed[t][n];
	return i ? r && i.big > 0 ? (--i.big, !0) : !r && i.small > 0 && (--i.small, !0) : !1;
}
function Ae(e, t, n) {
	let r = e.supply[t];
	return n && r.big > 0 ? (--r.big, !0) : !n && r.small > 0 && (--r.small, !0);
}
function je(e, t, n, r, i, a) {
	let o = r - 1;
	return e.blocked === o ? { code: "games.lasvegas-royale.errBlocked" } : Ae(e, t, n) ? (Oe(e, o, t, n), i.push({
		kind: "place",
		rid: t,
		data: {
			casino: o,
			small: +!n,
			big: +!!n
		}
	}), G(e, i), a && ye(e, o, t, i, !0), null) : { code: "games.lasvegas-royale.errBadChoice" };
}
function Me(e, t, n, r, i) {
	return e.blocked === n ? { code: "games.lasvegas-royale.errBlocked" } : ke(e, n, t, r) ? (e.supply[t][r ? "big" : "small"] += 1, i.push({
		kind: "tile",
		data: {
			tile: "returnDie",
			casino: n,
			rid: t,
			big: r
		}
	}), G(e, i), null) : { code: "games.lasvegas-royale.errBadChoice" };
}
function Ne(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "payout" || e.pending !== null) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = [];
		if (t.payoutIdx < 6) {
			let e = t.payoutIdx;
			t.payoutStep === "pre" ? Ce(t, e, n) : t.payoutStep === "settle" ? we(t, e, n) : t.payoutStep === "post" ? Te(t, e, n) : Ee(t, e, n);
		} else De(t, n);
		return {
			state: t,
			fx: n
		};
	}
	let r = structuredClone(e), i = [], a = (e) => ({ code: e }), o = r.pending;
	if (o) switch (t.type) {
		case "luckyPick": {
			if (o.kind !== "luckyPick" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			let e = (r.players.indexOf(o.by) + 1) % r.players.length;
			return r.pending = {
				kind: "luckyGuess",
				by: r.players[e],
				picker: o.by,
				held: t.n
			}, {
				state: r,
				fx: i
			};
		}
		case "luckyGuess": {
			if (o.kind !== "luckyGuess" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			let e = t.n === o.held;
			return e || (o.held === 1 ? W(r, o.picker, 2) : U(r, o.picker, o.held === 2 ? 30 : 40)), i.push({
				kind: "luckyPunch",
				rid: o.picker,
				data: {
					held: o.held,
					guess: t.n,
					hit: e
				}
			}), r.pending = null, K(r, i), {
				state: r,
				fx: i
			};
		}
		case "fiftyStop": {
			if (o.kind !== "fifty" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			let e = L[r.fiftyPos];
			return e === "chip1" ? W(r, o.by, 1) : typeof e == "number" && e > 0 && U(r, o.by, e), i.push({
				kind: "fifty",
				rid: o.by,
				data: {
					stop: !0,
					pos: r.fiftyPos,
					reward: e
				}
			}), r.fiftyPos = 0, r.pending = null, K(r, i), {
				state: r,
				fx: i
			};
		}
		case "fiftyBet": {
			if (o.kind !== "fifty" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			let [e, s] = H(r), c = e + s;
			return (t.high ? c > r.fiftyLastSum : c < r.fiftyLastSum) ? (r.fiftyLastSum = c, r.fiftyPos += 1, i.push({
				kind: "fifty",
				rid: o.by,
				data: {
					dice: [e, s],
					pos: r.fiftyPos
				}
			}), r.fiftyPos >= 5 && (U(r, o.by, 60), i.push({
				kind: "fifty",
				rid: o.by,
				data: {
					stop: !0,
					pos: 5,
					reward: 60
				}
			}), r.fiftyPos = 0, r.pending = null, K(r, i)), {
				state: r,
				fx: i
			}) : (i.push({
				kind: "fifty",
				rid: o.by,
				data: {
					dice: [e, s],
					bust: !0,
					pos: r.fiftyPos
				}
			}), r.fiftyPos = 0, r.pending = null, K(r, i), {
				state: r,
				fx: i
			});
		}
		case "noEntry": {
			if (o.kind !== "noEntry" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			if (t.target === null) return o.mustMove ? a("games.lasvegas-royale.errBadChoice") : (r.pending = null, K(r, i), {
				state: r,
				fx: i
			});
			if (t.target === o.casino) return a("games.lasvegas-royale.errBadChoice");
			if (t.target === r.blocked) return r.pending = null, K(r, i), {
				state: r,
				fx: i
			};
			r.blocked = t.target, r.noEntryPos = (r.noEntryPos + 1) % oe.length;
			let e = oe[r.noEntryPos];
			return e === "chip2" ? W(r, o.by, 2) : e === "chip1" ? W(r, o.by, 1) : typeof e == "number" && U(r, o.by, e), i.push({
				kind: "tile",
				data: {
					tile: "noEntry",
					casino: o.casino,
					rid: o.by,
					target: t.target,
					pos: r.noEntryPos
				}
			}), r.pending = null, K(r, i), {
				state: r,
				fx: i
			};
		}
		case "knockout": {
			if (o.kind !== "knockout" || !o.waiting.includes(n.by)) return a("games.lasvegas-royale.errNotYourTurn");
			let e = r.supply[n.by];
			if (t.big && e.big < 1 || !t.big && e.small < 1) return a("games.lasvegas-royale.errBadChoice");
			--e[t.big ? "big" : "small"];
			let s = r.bar[n.by] ??= B();
			return s[t.big ? "big" : "small"] += 1, i.push({
				kind: "tile",
				data: {
					tile: "knockout",
					rid: n.by,
					big: t.big
				}
			}), o.waiting = o.waiting.filter((e) => e !== n.by), r.pending = o.waiting.length > 0 ? o : null, r.pending === null && (be(r, o.by, i), K(r, i)), {
				state: r,
				fx: i
			};
		}
		case "blockIt": {
			if (o.kind !== "blockIt" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			let e = r.clusters[t.cluster];
			return e === void 0 ? a("games.lasvegas-royale.errBadChoice") : r.blocked === t.target ? a("games.lasvegas-royale.errBlocked") : (r.clusters.splice(t.cluster, 1), r.gray[t.target] += e, _e(r, t.target, ie, i), G(r, i), i.push({
				kind: "tile",
				data: {
					tile: "blockIt",
					rid: o.by,
					target: t.target,
					count: e
				}
			}), r.pending = null, K(r, i), {
				state: r,
				fx: i
			});
		}
		case "handicap": {
			if (o.kind !== "handicap" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			if (r.handicapUsed[t.space]) return a("games.lasvegas-royale.errBadChoice");
			if (r.blocked === t.fromCasino) return a("games.lasvegas-royale.errBlocked");
			if (r.gray[t.fromCasino] <= 0) return a("games.lasvegas-royale.errBadChoice");
			--r.gray[t.fromCasino], r.handicapUsed[t.space] = !0, G(r, i);
			let e = se[t.space];
			if (i.push({
				kind: "tile",
				data: {
					tile: "handicap",
					rid: o.by,
					space: t.space,
					fromCasino: t.fromCasino
				}
			}), e === "chip1") W(r, o.by, 1);
			else if (e === 30) U(r, o.by, 30);
			else return r.pending = {
				kind: "handicapChoice",
				by: o.by
			}, {
				state: r,
				fx: i
			};
			return r.pending = null, K(r, i), {
				state: r,
				fx: i
			};
		}
		case "handicapSkip": return o.kind !== "handicap" || n.by !== o.by ? a("games.lasvegas-royale.errNotYourTurn") : (r.pending = null, K(r, i), {
			state: r,
			fx: i
		});
		case "handicapRotate": return o.kind !== "handicapChoice" || n.by !== o.by ? a("games.lasvegas-royale.errNotYourTurn") : je(r, o.by, t.big, t.value, i, !1) || (r.pending = null, K(r, i), {
			state: r,
			fx: i
		});
		case "handicapReturn": return o.kind !== "handicapChoice" || n.by !== o.by ? a("games.lasvegas-royale.errNotYourTurn") : Me(r, o.by, t.fromCasino, t.big, i) || (r.pending = null, K(r, i), {
			state: r,
			fx: i
		});
		case "doubleDown": {
			if (o.kind !== "doubleDown" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			let e = r.placed[o.casino][o.by] ?? B();
			if (t.small > e.small || t.big > e.big) return a("games.lasvegas-royale.errBadChoice");
			e.small -= t.small, e.big -= t.big;
			let s = r.doubleDown[o.by] ??= B();
			return s.small += t.small, s.big += t.big, G(r, i), t.small + t.big > 0 && i.push({
				kind: "tile",
				data: {
					tile: "doubleDown",
					casino: o.casino,
					rid: o.by,
					small: t.small,
					big: t.big
				}
			}), r.pending = null, K(r, i), {
				state: r,
				fx: i
			};
		}
		case "niceDice":
		case "niceSkip": {
			if (o.kind !== "niceDice" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			if (t.type === "niceSkip") return r.pending = null, K(r, i), {
				state: r,
				fx: i
			};
			if (!o.candidates.some((e) => e.value === t.value && e.big === t.big)) return a("games.lasvegas-royale.errBadChoice");
			if (t.value === o.placedValue) {
				if (!ke(r, o.casino, o.by, t.big)) return a("games.lasvegas-royale.errBadChoice");
				G(r, i);
			} else if (!Ae(r, o.by, t.big)) return a("games.lasvegas-royale.errBadChoice");
			let e = t.value - 1, s = r.niceDice[e];
			return s && (r.blocked === e ? r.supply[s.rid][s.big ? "big" : "small"] += 1 : Oe(r, e, s.rid, s.big), G(r, i)), r.niceDice[e] = {
				rid: o.by,
				big: t.big
			}, i.push({
				kind: "tile",
				data: {
					tile: "niceDice",
					casino: o.casino,
					rid: o.by,
					value: t.value,
					displaced: s?.rid ?? null
				}
			}), r.pending = null, K(r, i), {
				state: r,
				fx: i
			};
		}
		case "myChoice":
			if (o.kind !== "myChoice" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			if (t.value !== o.dice[0] && t.value !== o.dice[1]) return a("games.lasvegas-royale.errBadValue");
			if (t.value === 1) W(r, o.by, 1);
			else if (t.value === 2) W(r, o.by, 2);
			else if (t.value === 3) U(r, o.by, 30);
			else if (t.value === 4) return r.pending = {
				kind: "myTile",
				by: o.by
			}, {
				state: r,
				fx: i
			};
			else if (t.value === 5) return r.pending = {
				kind: "myRotateOrReturn",
				by: o.by
			}, {
				state: r,
				fx: i
			};
			else if (r.supply[o.by].small + r.supply[o.by].big > 0) return r.pending = {
				kind: "myGold",
				by: o.by
			}, {
				state: r,
				fx: i
			};
			return i.push({
				kind: "tile",
				data: {
					tile: "myChoice",
					casino: o.casino,
					rid: o.by,
					value: t.value
				}
			}), r.pending = null, K(r, i), {
				state: r,
				fx: i
			};
		case "myTile": {
			if (o.kind !== "myTile" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			let e = t.target, s = r.tiles.indexOf("myChoice");
			return e < 0 || e > 2 || e === s || !r.tiles[e] ? a("games.lasvegas-royale.errBadChoice") : (r.pending = null, ye(r, e, o.by, i, !1), K(r, i), {
				state: r,
				fx: i
			});
		}
		case "myRotate": return o.kind !== "myRotateOrReturn" || n.by !== o.by ? a("games.lasvegas-royale.errNotYourTurn") : je(r, o.by, t.big, t.value, i, !1) || (r.pending = null, K(r, i), {
			state: r,
			fx: i
		});
		case "myReturn": return o.kind !== "myRotateOrReturn" || n.by !== o.by ? a("games.lasvegas-royale.errNotYourTurn") : Me(r, o.by, t.fromCasino, t.big, i) || (r.pending = null, K(r, i), {
			state: r,
			fx: i
		});
		case "myGold": return o.kind !== "myGold" || n.by !== o.by ? a("games.lasvegas-royale.errNotYourTurn") : Ae(r, o.by, t.big) ? (r.gold && (r.supply[r.gold.rid][r.gold.big ? "big" : "small"] += 1), r.gold = {
			rid: o.by,
			big: t.big
		}, i.push({
			kind: "tile",
			data: {
				tile: "myChoice",
				rid: o.by,
				gold: !0
			}
		}), r.pending = null, K(r, i), {
			state: r,
			fx: i
		}) : a("games.lasvegas-royale.errBadChoice");
		case "primeTime": {
			if (o.kind !== "primeTime" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			let e = [];
			return o.dice.forEach((n, i) => {
				if (!t.place[i]) return;
				let a = n - 1;
				r.blocked !== a && (r.primeDice.push({
					rid: o.by,
					casino: a
				}), e.push(n));
			}), G(r, i), i.push({
				kind: "tile",
				data: {
					tile: "primeTime",
					rid: o.by,
					placed: e
				}
			}), r.pending = null, r.payoutStep = "settle", r.beatMs = R.payout, {
				state: r,
				fx: i
			};
		}
		case "blackBoxSplit": {
			if (o.kind !== "blackBoxSplit" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			let e = [...new Set(t.pileA)];
			if (e.length < 1 || e.length > 3 || e.some((e) => e < 0 || e > 5)) return a("games.lasvegas-royale.errBadChoice");
			let s = e.map((e) => le[e]), c = le.filter((t, n) => !e.includes(n));
			return r.pending = {
				kind: "blackBoxPick",
				by: o.winner,
				splitter: o.by,
				piles: [s, c]
			}, {
				state: r,
				fx: i
			};
		}
		case "blackBoxPick": {
			if (o.kind !== "blackBoxPick" || n.by !== o.by) return a("games.lasvegas-royale.errNotYourTurn");
			let e = o.piles[t.pile].reduce((e, t) => e + t, 0);
			return e === 20 ? W(r, o.by, 2) : e >= 30 && U(r, o.by, e), i.push({
				kind: "tile",
				data: {
					tile: "blackBox",
					rid: o.by,
					sum: e
				}
			}), r.pending = null, r.payoutStep = "post2", r.beatMs = R.tile, {
				state: r,
				fx: i
			};
		}
		default: return a("games.lasvegas-royale.errNotYourTurn");
	}
	if (r.phase !== "play") return a("games.lasvegas-royale.errNotYourTurn");
	let s = r.players[r.turnIdx];
	if (n.by !== s) return a("games.lasvegas-royale.errNotYourTurn");
	if (t.type === "roll") {
		if (r.rolled !== null) return a("games.lasvegas-royale.errNotYourTurn");
		let e = ue(r, r.supply[s]);
		return r.rolled = e, {
			state: r,
			fx: [{
				kind: "diceRoll",
				rid: s,
				data: {
					dice: e,
					banner: !0,
					target: "tray"
				}
			}]
		};
	}
	if (t.type === "passChip") return r.rolled === null || r.chips[s] < 1 ? a("games.lasvegas-royale.errNoChip") : (--r.chips[s], i.push({
		kind: "tile",
		data: {
			tile: "passChip",
			rid: s
		}
	}), ge(r, i), {
		state: r,
		fx: i
	});
	if (t.type === "forfeit") {
		let e = r.rolled;
		if (e === null) return a("games.lasvegas-royale.errNotYourTurn");
		if (new Set(e.map((e) => e.value).filter((e) => r.blocked !== e - 1)).size > 0) return a("games.lasvegas-royale.errBadChoice");
		let t = r.lostDice[s] ??= B();
		for (let n of e) --r.supply[s][n.big ? "big" : "small"], t[n.big ? "big" : "small"] += 1;
		return i.push({
			kind: "tile",
			data: {
				tile: "forfeit",
				rid: s,
				count: e.length
			}
		}), ge(r, i), {
			state: r,
			fx: i
		};
	}
	if (t.type === "powerPlace") return r.powerPlayHolder !== s || r.rolled !== null ? a("games.lasvegas-royale.errNotYourTurn") : je(r, s, t.big, t.value, i, !0) || (K(r, i), {
		state: r,
		fx: i
	});
	if (t.type === "place") {
		let e = r.rolled;
		if (e === null) return a("games.lasvegas-royale.errNotYourTurn");
		let n = t.value - 1;
		if (r.blocked === n) return a("games.lasvegas-royale.errBlocked");
		let o = e.filter((e) => e.value === t.value);
		if (o.length === 0) return a("games.lasvegas-royale.errBadValue");
		let c = o.filter((e) => !e.big).length, l = o.length - c, u = r.placed[n][s] ??= B();
		return u.small += c, u.big += l, r.supply[s].small -= c, r.supply[s].big -= l, i.push({
			kind: "place",
			rid: s,
			data: {
				casino: n,
				small: c,
				big: l
			}
		}), G(r, i), ye(r, n, s, i, !0), K(r, i), {
			state: r,
			fx: i
		};
	}
	return a("games.lasvegas-royale.errNotYourTurn");
}
function Pe(e, t) {
	let n = e.pending, r = null;
	if (n) switch (n.kind) {
		case "luckyPick": {
			let t = (e.players.indexOf(n.by) + 1) % e.players.length;
			r = {
				kind: "luckyPick",
				who: [n.by],
				guesser: e.players[t]
			};
			break;
		}
		case "luckyGuess":
			r = {
				kind: "luckyGuess",
				who: [n.by],
				picker: n.picker
			};
			break;
		case "fifty":
			r = {
				kind: "fifty",
				who: [n.by],
				pos: e.fiftyPos,
				lastSum: e.fiftyLastSum
			};
			break;
		case "noEntry":
			r = {
				kind: "noEntry",
				who: [n.by],
				mustMove: n.mustMove
			};
			break;
		case "knockout":
			r = {
				kind: "knockout",
				who: n.waiting
			};
			break;
		case "blockIt":
			r = {
				kind: "blockIt",
				who: [n.by],
				clusters: [...e.clusters]
			};
			break;
		case "handicap":
			r = {
				kind: "handicap",
				who: [n.by],
				spaces: se.map((e, t) => t).filter((t) => !e.handicapUsed[t])
			};
			break;
		case "handicapChoice":
			r = {
				kind: "handicapChoice",
				who: [n.by]
			};
			break;
		case "doubleDown": {
			let t = e.placed[n.casino][n.by] ?? B();
			r = {
				kind: "doubleDown",
				who: [n.by],
				maxSmall: t.small,
				maxBig: t.big
			};
			break;
		}
		case "niceDice":
			r = {
				kind: "niceDice",
				who: [n.by],
				candidates: n.candidates
			};
			break;
		case "myChoice":
			r = {
				kind: "myChoice",
				who: [n.by],
				dice: n.dice
			};
			break;
		case "myTile": {
			let t = e.tiles.indexOf("myChoice");
			r = {
				kind: "myTile",
				who: [n.by],
				candidates: [
					0,
					1,
					2
				].filter((n) => n !== t && e.tiles[n])
			};
			break;
		}
		case "myRotateOrReturn":
			r = {
				kind: "myRotateOrReturn",
				who: [n.by]
			};
			break;
		case "myGold":
			r = {
				kind: "myGold",
				who: [n.by]
			};
			break;
		case "primeTime":
			r = {
				kind: "primeTime",
				who: [n.by],
				dice: n.dice
			};
			break;
		case "blackBoxSplit":
			r = {
				kind: "blackBoxSplit",
				who: [n.by],
				winner: n.winner
			};
			break;
		case "blackBoxPick": r = {
			kind: "blackBoxPick",
			who: [n.by]
		};
	}
	return {
		public: {
			round: e.round,
			phase: e.phase,
			turn: e.phase === "play" ? e.players[e.turnIdx] : null,
			rolled: e.rolled,
			casinos: e.casinos,
			placed: e.placed,
			gray: e.gray,
			tiles: e.tiles,
			blocked: e.blocked,
			players: e.players.map((t) => ({
				rid: t,
				money: e.money[t],
				notes: e.noteCounts[t],
				chips: e.chips[t],
				small: e.supply[t].small,
				big: e.supply[t].big
			})),
			tileState: {
				jackpotPos: e.jackpotPos,
				noEntryPos: e.noEntryPos,
				highFiveHolder: e.highFiveHolder,
				powerPlayHolder: e.powerPlayHolder,
				bar: e.bar,
				clusters: [...e.clusters],
				handicapUsed: [...e.handicapUsed],
				doubleDown: e.doubleDown,
				niceDice: [...e.niceDice],
				gold: e.gold,
				primeDice: [...e.primeDice]
			},
			pending: r,
			payoutIdx: e.payoutIdx
		},
		private: {
			luckyHeld: n?.kind === "luckyGuess" && n.picker === t ? n.held : null,
			blackBoxPiles: n?.kind === "blackBoxPick" && n.splitter === t ? n.piles : null
		}
	};
}
function Fe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => e.noteCounts[t] + e.chips[t], n = [...e.players].sort((n, r) => e.money[r] - e.money[n] || t(r) - t(n)), r = n[0];
	return {
		phase: "done",
		winner: n.filter((n) => e.money[n] === e.money[r] && t(n) === t(r)),
		ranking: n,
		scores: { ...e.money }
	};
}
function Ie(e) {
	return e.phase === "payout" && e.pending === null ? e.beatMs : null;
}
var Le = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: E,
	schemas: {
		action: ee,
		publicView: te,
		privateView: I
	},
	setup: me,
	reduce: Ne,
	viewFor: Pe,
	status: Fe,
	nextTickIn: Ie
};
//#endregion
//#region src/games/lasvegas-royale/view-player.tsx
function Re(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ _(Ke, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function q({ value: e, size: t = 36, hex: n, big: r }) {
	let i = {
		1: [[1, 1]],
		2: [[0, 0], [2, 2]],
		3: [
			[0, 0],
			[1, 1],
			[2, 2]
		],
		4: [
			[0, 0],
			[2, 0],
			[0, 2],
			[2, 2]
		],
		5: [
			[0, 0],
			[2, 0],
			[1, 1],
			[0, 2],
			[2, 2]
		],
		6: [
			[0, 0],
			[2, 0],
			[0, 1],
			[2, 1],
			[0, 2],
			[2, 2]
		]
	}, a = t / 3;
	return /* @__PURE__ */ _("svg", {
		width: t,
		height: t,
		viewBox: `0 0 ${t} ${t}`,
		"aria-hidden": !0,
		className: `lvr-die ${r ? "lvr-die-big" : ""}`,
		style: { background: n ?? "var(--color-surface)" },
		children: i[e].map(([e, t], r) => /* @__PURE__ */ _("circle", {
			cx: e * a + a / 2,
			cy: t * a + a / 2,
			r: a * .28,
			fill: n ? "var(--color-surface)" : "var(--color-ink)"
		}, r))
	});
}
function ze({ members: e, pub: t, myRid: a }) {
	let o = n((e) => e.locale), s = r();
	return /* @__PURE__ */ _("ul", {
		className: "lvr-seats",
		children: e.filter((e) => t.players.some((t) => t.rid === e.rid)).map((e) => {
			let n = t.players.find((t) => t.rid === e.rid), r = i(e, o), c = d[e.colorIndex % d.length], l = t.phase === "play" && (t.pending ? t.pending.who.includes(e.rid) : t.turn === e.rid), u = t.phase === "play" && !l && n && n.small + n.big === 0, f = e.online ? e.rid === a ? s("lobby.you") : p(e.rid) === null ? null : s("lobby.bot") : s("lobby.offline");
			return /* @__PURE__ */ _(Be, {
				avatar: e.avatar,
				rid: e.rid,
				name: r,
				color: c.hex,
				money: n?.money,
				chips: n?.chips,
				dice: n ? n.small + n.big : void 0,
				acting: l,
				done: !!u,
				tag: f
			}, e.rid);
		})
	});
}
function Be({ avatar: e, rid: t, name: n, color: i, money: o, chips: s, dice: c, acting: d, done: f, tag: p }) {
	let m = r(), { ref: h } = l(`seat:${t}`);
	return /* @__PURE__ */ v("li", {
		className: "lvr-seat",
		children: [
			/* @__PURE__ */ _("span", {
				ref: h,
				className: "lvr-seat-avatar",
				style: { backgroundColor: i },
				"aria-hidden": !0,
				children: /* @__PURE__ */ _("img", {
					src: a[e % a.length],
					alt: "",
					draggable: !1,
					style: {
						width: "1.75em",
						height: "1.75em",
						maxWidth: "100%",
						maxHeight: "100%",
						display: "block",
						objectFit: "contain",
						pointerEvents: "none",
						borderRadius: "inherit"
					}
				})
			}),
			/* @__PURE__ */ _("span", {
				className: "lvr-seat-name",
				title: n,
				children: n
			}),
			p && /* @__PURE__ */ _("span", {
				className: "lvr-seat-tag",
				children: p
			}),
			d && /* @__PURE__ */ _("span", {
				className: "lvr-seat-action",
				role: "status",
				"aria-label": m("lobby.thinking"),
				children: "···"
			}),
			f && /* @__PURE__ */ _("span", {
				className: "lvr-seat-action lvr-seat-done",
				role: "img",
				"aria-label": m("lobby.done"),
				children: "✓"
			}),
			o !== void 0 && /* @__PURE__ */ v("span", {
				className: "lvr-seat-money font-mono tabular-nums",
				children: [
					"$",
					/* @__PURE__ */ _(u, {
						value: o,
						className: "font-mono tabular-nums"
					}),
					"k"
				]
			}),
			s !== void 0 && /* @__PURE__ */ v("span", {
				className: "lvr-seat-chips font-mono tabular-nums",
				children: ["🎟", s]
			}),
			c !== void 0 && /* @__PURE__ */ v("span", {
				className: "lvr-seat-dice font-mono tabular-nums",
				children: ["🎲", c]
			})
		]
	});
}
var J = {
	luckyPunch: "games.lasvegas-royale.tileLuckyPunch",
	jackpot: "games.lasvegas-royale.tileJackpot",
	primeTime: "games.lasvegas-royale.tilePrimeTime",
	fiftyFifty: "games.lasvegas-royale.tileFiftyFifty",
	highFive: "games.lasvegas-royale.tileHighFive",
	badLuck: "games.lasvegas-royale.tileBadLuck",
	payDay: "games.lasvegas-royale.tilePayDay",
	powerPlay: "games.lasvegas-royale.tilePowerPlay",
	noEntry: "games.lasvegas-royale.tileNoEntry",
	knockout: "games.lasvegas-royale.tileKnockout",
	blockIt: "games.lasvegas-royale.tileBlockIt",
	handicap: "games.lasvegas-royale.tileHandicap",
	blackBox: "games.lasvegas-royale.tileBlackBox",
	doubleDown: "games.lasvegas-royale.tileDoubleDown",
	niceDice: "games.lasvegas-royale.tileNiceDice",
	myChoice: "games.lasvegas-royale.tileMyChoice"
}, Ve = [
	"games.lasvegas-royale.casinoMiracle",
	"games.lasvegas-royale.casinoKings",
	"games.lasvegas-royale.casinoMarina",
	"games.lasvegas-royale.casinoQueen",
	"games.lasvegas-royale.casinoCleopatra",
	"games.lasvegas-royale.casinoSunset"
], He = {
	luckyPunch: "✊",
	jackpot: "★",
	primeTime: "✦",
	fiftyFifty: "⬍",
	highFive: "✋",
	badLuck: "⚡",
	payDay: "$",
	powerPlay: "♜",
	noEntry: "⊘",
	knockout: "✕",
	blockIt: "◆",
	handicap: "⇄",
	blackBox: "▣",
	doubleDown: "×2",
	niceDice: "⚅",
	myChoice: "?"
}, Ue = {
	luckyPunch: "games.lasvegas-royale.tileDescLuckyPunch",
	jackpot: "games.lasvegas-royale.tileDescJackpot",
	primeTime: "games.lasvegas-royale.tileDescPrimeTime",
	fiftyFifty: "games.lasvegas-royale.tileDescFiftyFifty",
	highFive: "games.lasvegas-royale.tileDescHighFive",
	badLuck: "games.lasvegas-royale.tileDescBadLuck",
	payDay: "games.lasvegas-royale.tileDescPayDay",
	powerPlay: "games.lasvegas-royale.tileDescPowerPlay",
	noEntry: "games.lasvegas-royale.tileDescNoEntry",
	knockout: "games.lasvegas-royale.tileDescKnockout",
	blockIt: "games.lasvegas-royale.tileDescBlockIt",
	handicap: "games.lasvegas-royale.tileDescHandicap",
	blackBox: "games.lasvegas-royale.tileDescBlackBox",
	doubleDown: "games.lasvegas-royale.tileDescDoubleDown",
	niceDice: "games.lasvegas-royale.tileDescNiceDice",
	myChoice: "games.lasvegas-royale.tileDescMyChoice"
}, We = {
	1: "games.lasvegas-royale.myChoiceOpt1",
	2: "games.lasvegas-royale.myChoiceOpt2",
	3: "games.lasvegas-royale.myChoiceOpt3",
	4: "games.lasvegas-royale.myChoiceOpt4",
	5: "games.lasvegas-royale.myChoiceOpt5",
	6: "games.lasvegas-royale.myChoiceOpt6"
};
function Ge(e) {
	return e === "start" ? "▶" : e === "empty" ? "·" : e === "chip1" ? "+1🎟" : e === "chip2" ? "+2🎟" : e === 0 ? "$0" : `$${e}k`;
}
function Ke({ pub: e, priv: t, members: n, myRid: i, send: a }) {
	let u = r(), p = (e) => e === "$gray" ? u("games.lasvegas-royale.grayName") : n.find((t) => t.rid === e)?.name ?? e, g = e.phase === "play" && e.turn === i && !e.pending, y = e.pending, b = y !== null && y.who.includes(i), x = e.players.find((e) => e.rid === i), S = d[(n.find((e) => e.rid === i)?.colorIndex ?? 0) % d.length].hex, C = e.tiles.indexOf("noEntry"), w = y ? `${y.kind}:${y.who.join(",")}` : `turn:${e.turn}:${+!!e.rolled}:${e.round}`, [T, D] = c(null), [O, k] = c(w);
	O !== w && (k(w), D(null));
	let [A, ee] = c(null), j = s(null), { ref: M } = l("lvr:die-size");
	o(() => {
		let t = j.current;
		if (!t) return;
		if (e.phase !== "payout") {
			e.phase === "play" && (t.scrollTop = 0);
			return;
		}
		let n = () => {
			let n = t.querySelector(`[data-casino-index="${e.payoutIdx}"]`), r = t.querySelector("[data-casino-index=\"0\"]");
			if (n && r) {
				if (Math.abs(n.getBoundingClientRect().top - r.getBoundingClientRect().top) < 2) {
					t.scrollTop = 0;
					return;
				}
				t.scrollTop += n.getBoundingClientRect().top - t.getBoundingClientRect().top - 8;
			}
		};
		if (n(), typeof ResizeObserver > "u") return;
		let r = new ResizeObserver(n);
		return r.observe(t), () => r.disconnect();
	}, [
		e.phase,
		e.payoutIdx,
		e.round
	]);
	let N, P;
	if (e.phase === "payout") N = "info", P = e.payoutIdx >= 0 && e.payoutIdx < 6 ? u("games.lasvegas-royale.payoutCasino", { n: e.payoutIdx + 1 }) : u("games.lasvegas-royale.payout");
	else if (y) N = b ? "accent" : "info", P = b ? qe(u, y, p) : u("games.lasvegas-royale.waitingPending", { name: p(y.who[0]) });
	else if (g) N = "accent", P = e.rolled ? u("games.lasvegas-royale.placePrompt") : u("games.lasvegas-royale.rollPrompt", { n: (x?.small ?? 0) + (x?.big ?? 0) });
	else {
		N = "info";
		let t = e.turn ? p(e.turn) : "";
		P = e.rolled ? u("games.lasvegas-royale.waitingPlace", { name: t }) : u("games.lasvegas-royale.waitingRoll", { name: t });
	}
	let F = /* @__PURE__ */ new Map();
	if (g && e.rolled) for (let t of e.rolled) e.blocked !== t.value - 1 && F.set(t.value - 1, (F.get(t.value - 1) ?? 0) + (t.big ? 2 : 1));
	let te = g && e.rolled && T?.mode === "place" && F.has(T.value - 1) ? T.value : null, I = new Set(F.keys());
	if (b && y) {
		if (y.kind === "noEntry") for (let t = 0; t < 6; t += 1) t !== C && t !== e.blocked && I.add(t);
		else if (y.kind === "blockIt" && T?.mode === "blockIt" && T.cluster !== null) for (let t = 0; t < 6; t += 1) t !== e.blocked && I.add(t);
		else if (y.kind === "handicap" && T?.mode === "handicap" && T.space !== null) for (let t = 0; t < 6; t += 1) e.gray[t] > 0 && t !== e.blocked && I.add(t);
		else if ((y.kind === "handicapChoice" || y.kind === "myRotateOrReturn") && T?.mode === "choice" && T.sub === "return") for (let t = 0; t < 6; t += 1) {
			let n = e.placed[t][i];
			n && (n.small > 0 || n.big > 0) && t !== e.blocked && I.add(t);
		}
		else if (y.kind === "myTile") for (let e of y.candidates) I.add(e);
	}
	let ne = e.phase === "play" && I.size > 0, re = (t) => {
		if (I.has(t)) {
			if (b && y) return y.kind === "noEntry" ? a({
				type: "noEntry",
				target: t
			}) : y.kind === "blockIt" && T?.mode === "blockIt" && T.cluster !== null ? a({
				type: "blockIt",
				cluster: T.cluster,
				target: t
			}) : y.kind === "handicap" && T?.mode === "handicap" && T.space !== null ? a({
				type: "handicap",
				space: T.space,
				fromCasino: t
			}) : (y.kind === "handicapChoice" || y.kind === "myRotateOrReturn") && T?.mode === "choice" && T.sub === "return" ? D({
				...T,
				fromCasino: t
			}) : y.kind === "myTile" ? a({
				type: "myTile",
				target: t
			}) : void 0;
			g && e.rolled && D({
				mode: "place",
				value: t + 1
			});
		}
	}, ie = g && e.rolled !== null && e.rolled.every((t) => e.blocked === t.value - 1), ae = g && e.rolled === null && e.tileState.powerPlayHolder === i;
	return /* @__PURE__ */ v("div", {
		className: "lvr-root relative h-full min-h-0",
		children: [/* @__PURE__ */ _(m, {
			adaptive: !0,
			className: "lvr-screen",
			scroll: !1,
			actionsHeight: "lvr-action-height",
			banner: /* @__PURE__ */ v("div", {
				className: "lvr-banner",
				children: [/* @__PURE__ */ _(h, {
					tone: N,
					text: P,
					chip: u("games.lasvegas-royale.roundShort", {
						n: e.round,
						total: 3
					}),
					accent: E.accent
				}), /* @__PURE__ */ _(ze, {
					members: n,
					pub: e,
					myRid: i
				})]
			}),
			actions: /* @__PURE__ */ _($e, {
				pub: e,
				priv: t,
				myRid: i,
				myHex: S,
				myTurn: g,
				myPending: b,
				me: x,
				sel: T,
				setSel: D,
				send: a,
				allBlocked: ie,
				canPower: ae,
				selectedPlace: te
			}),
			children: /* @__PURE__ */ v("div", {
				className: "lvr-table-viewport",
				children: [
					/* @__PURE__ */ _(f, {
						kind: "sheen",
						base: "var(--color-felt)",
						className: "absolute inset-0"
					}),
					/* @__PURE__ */ _("span", {
						ref: M,
						className: "lvr-die-size",
						"aria-hidden": !0
					}),
					/* @__PURE__ */ _("div", {
						ref: j,
						className: "lvr-table-scroll",
						children: /* @__PURE__ */ v("div", {
							className: "lvr-table",
							children: [
								/* @__PURE__ */ v("div", {
									className: "lvr-marquee",
									"aria-hidden": !0,
									children: [
										/* @__PURE__ */ _("span", { children: "◆" }),
										" ",
										u("games.lasvegas-royale.tableTitle"),
										" ",
										/* @__PURE__ */ _("span", { children: "◆" })
									]
								}),
								/* @__PURE__ */ v("div", {
									className: "lvr-casino-grid",
									children: [Array.from({ length: 6 }, (t, r) => /* @__PURE__ */ _(Je, {
										index: r,
										pub: e,
										members: n,
										nameOf: p,
										tappable: I.has(r),
										unavailable: ne && !I.has(r),
										badge: F.get(r) ?? null,
										selected: te === r + 1 || b && T?.mode === "choice" && T.sub === "return" && T.fromCasino === r,
										resolving: e.phase === "payout" && e.payoutIdx === r,
										settled: e.phase === "payout" && e.payoutIdx > r,
										onTap: () => re(r),
										onShowDetail: ee
									}, r)), /* @__PURE__ */ _("div", {
										className: "lvr-well",
										"aria-hidden": !0,
										children: /* @__PURE__ */ v("div", {
											className: "lvr-well-inner",
											children: [/* @__PURE__ */ v("span", {
												className: "lvr-well-dice",
												children: [/* @__PURE__ */ _(q, {
													value: 5,
													size: 19
												}), /* @__PURE__ */ _(q, {
													value: 2,
													size: 19
												})]
											}), /* @__PURE__ */ _("small", { children: u("games.lasvegas-royale.diceWell") })]
										})
									})]
								}),
								/* @__PURE__ */ _("p", {
									className: "lvr-table-motto",
									children: u("games.lasvegas-royale.tableMotto")
								})
							]
						})
					})
				]
			})
		}), A && /* @__PURE__ */ _("div", {
			className: "lvr-detail-backdrop",
			role: "presentation",
			onClick: () => ee(null),
			children: /* @__PURE__ */ v("div", {
				className: "lvr-detail",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": u(J[A]),
				onClick: (e) => e.stopPropagation(),
				children: [
					/* @__PURE__ */ _("span", {
						className: "lvr-detail-icon",
						"aria-hidden": !0,
						children: He[A]
					}),
					/* @__PURE__ */ _("p", {
						className: "font-display text-xl font-extrabold",
						children: u(J[A])
					}),
					Ye(A, e, p) && /* @__PURE__ */ _("p", {
						className: "lvr-detail-status font-mono tabular-nums",
						children: Ye(A, e, p)
					}),
					/* @__PURE__ */ _("p", {
						className: "text-sm leading-6 font-medium",
						children: u(Ue[A])
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => ee(null),
						className: "btn-base mt-2 w-full shrink-0 bg-warn font-bold text-ink",
						children: u("games.lasvegas-royale.close")
					})
				]
			})
		})]
	});
}
function qe(e, t, n) {
	switch (t.kind) {
		case "luckyPick": return e("games.lasvegas-royale.luckyPickPrompt", { name: n(t.guesser) });
		case "luckyGuess": return e("games.lasvegas-royale.luckyGuessPrompt", { name: n(t.picker) });
		case "fifty": return e("games.lasvegas-royale.fiftyPosReward", { reward: Ge(L[t.pos]) });
		case "noEntry": return e("games.lasvegas-royale.noEntryPrompt");
		case "knockout": return e("games.lasvegas-royale.knockoutPrompt");
		case "blockIt": return e("games.lasvegas-royale.blockItPrompt");
		case "handicap": return e("games.lasvegas-royale.handicapPrompt");
		case "handicapChoice": return e("games.lasvegas-royale.handicapChoicePrompt");
		case "doubleDown": return e("games.lasvegas-royale.doubleDownPrompt");
		case "niceDice": return e("games.lasvegas-royale.niceDicePrompt");
		case "myChoice": return e("games.lasvegas-royale.myChoicePrompt");
		case "myTile": return e("games.lasvegas-royale.myTilePrompt");
		case "myRotateOrReturn": return e("games.lasvegas-royale.myRotateOrReturnPrompt");
		case "myGold": return e("games.lasvegas-royale.myGoldPrompt");
		case "primeTime": return e("games.lasvegas-royale.primeTimePrompt");
		case "blackBoxSplit": return e("games.lasvegas-royale.blackBoxSplitPrompt", { name: n(t.winner) });
		case "blackBoxPick": return e("games.lasvegas-royale.blackBoxPickPrompt");
	}
}
function Je({ index: e, pub: t, members: n, nameOf: i, tappable: a, unavailable: o, badge: s, selected: c, resolving: u, settled: f, onTap: p, onShowDetail: m }) {
	let h = r(), { ref: g } = l(`casino:${e}`), y = t.casinos[e], b = t.placed[e], x = t.gray[e], S = t.tiles[e], C = t.blocked === e, w = Object.entries(b).filter(([, e]) => e.small + e.big > 0), T = c && t.rolled ? t.rolled.filter((t) => t.value === e + 1) : [], E = T.reduce((e, t) => e + (t.big ? 2 : 1), 0), D = n.find((e) => e.rid === t.turn), O = d[(D?.colorIndex ?? 0) % d.length], k = h(Ve[e]);
	return /* @__PURE__ */ v("div", {
		ref: g,
		"data-casino-index": e,
		className: `lvr-casino ${e % 2 == 0 ? "lvr-casino-left" : "lvr-casino-right"} ${S ? "lvr-has-tile" : ""} ${S && t.pending && Qe[t.pending.kind] === S ? "lvr-casino-pending-tile" : ""} ${a ? "lvr-casino-legal" : ""} ${o ? "lvr-casino-unavailable" : ""} ${c ? "lvr-casino-selected" : ""} ${u ? "lvr-casino-resolving" : ""} ${f ? "lvr-casino-settled" : ""} ${C ? "lvr-casino-blocked" : ""}`,
		children: [
			/* @__PURE__ */ v("button", {
				type: "button",
				disabled: !a,
				"aria-label": s === null ? h("games.lasvegas-royale.casinoAria", {
					n: e + 1,
					name: k
				}) : h("games.lasvegas-royale.placeDiceAria", {
					count: s,
					value: e + 1,
					name: k
				}),
				"aria-pressed": a ? c : void 0,
				onClick: p,
				className: "lvr-casino-main",
				children: [
					/* @__PURE__ */ v("span", {
						className: "lvr-casino-marquee",
						children: [
							/* @__PURE__ */ _("span", {
								className: "lvr-casino-number",
								children: String(e + 1).padStart(2, "0")
							}),
							/* @__PURE__ */ _("span", {
								className: "lvr-casino-name",
								children: k
							}),
							/* @__PURE__ */ _("span", {
								className: "lvr-casino-diamond",
								"aria-hidden": !0,
								children: "◆"
							})
						]
					}),
					/* @__PURE__ */ v("span", {
						className: "lvr-notes",
						children: [y.map((e, t) => /* @__PURE__ */ v("span", {
							className: `lvr-note lvr-note-${t} font-mono tabular-nums`,
							children: [/* @__PURE__ */ v("strong", { children: [
								"$",
								e,
								"k"
							] }), /* @__PURE__ */ _("small", { children: "CASH" })]
						}, t)), y.length === 0 && !u && !f && /* @__PURE__ */ v("span", {
							className: "lvr-cashed",
							children: ["✓ ", h("games.lasvegas-royale.cashedOut")]
						})]
					}),
					/* @__PURE__ */ v("span", {
						className: "lvr-wagers",
						children: [
							w.map(([t, r]) => {
								let a = n.find((e) => e.rid === t), o = d[(a?.colorIndex ?? 0) % d.length], s = r.small + r.big * 2;
								return /* @__PURE__ */ v("span", {
									className: "lvr-wager",
									title: `${i(t)} ×${s}`,
									"aria-label": `${i(t)} ×${s}`,
									children: [
										/* @__PURE__ */ _(q, {
											value: e + 1,
											size: 19,
											hex: o.hex,
											big: r.big > 0
										}),
										/* @__PURE__ */ v("strong", {
											className: "font-mono tabular-nums",
											children: ["×", s]
										}),
										r.big > 0 && /* @__PURE__ */ _("span", {
											className: "lvr-big-mark",
											"aria-label": h("games.lasvegas-royale.bigDie"),
											children: "2"
										})
									]
								}, t);
							}),
							x > 0 && /* @__PURE__ */ v("span", {
								className: "lvr-wager",
								title: `${i("$gray")} ×${x}`,
								"aria-label": `${i("$gray")} ×${x}`,
								children: [/* @__PURE__ */ _(q, {
									value: e + 1,
									size: 19,
									hex: "var(--color-ink)"
								}), /* @__PURE__ */ v("strong", {
									className: "font-mono tabular-nums",
									children: ["×", x]
								})]
							}),
							y.length > 0 && !w.length && x === 0 && !T.length && /* @__PURE__ */ _("span", {
								className: "lvr-empty-wagers",
								children: h("games.lasvegas-royale.emptyWagers")
							})
						]
					}),
					T.length > 0 && /* @__PURE__ */ v("span", {
						className: "lvr-preview-dice",
						"aria-hidden": !0,
						children: [T.slice(0, 3).map((t, n) => /* @__PURE__ */ _(q, {
							value: e + 1,
							size: 19,
							hex: O.hex,
							big: t.big
						}, n)), /* @__PURE__ */ v("strong", {
							className: "font-mono tabular-nums",
							children: ["×", E]
						})]
					}),
					C && /* @__PURE__ */ v("span", {
						className: "lvr-blocked-mark",
						children: ["⊘ ", h("games.lasvegas-royale.blockedBadge")]
					}),
					a && /* @__PURE__ */ _("span", {
						className: "lvr-legal-mark",
						children: c ? `✓ ${h("games.lasvegas-royale.selected")}` : s === null ? h("games.lasvegas-royale.chooseTarget") : h("games.lasvegas-royale.legalCount", { n: s })
					}),
					u && /* @__PURE__ */ _("span", {
						className: "lvr-settlement-mark",
						children: h("games.lasvegas-royale.resolving")
					}),
					f && /* @__PURE__ */ v("span", {
						className: "lvr-settlement-mark",
						children: ["✓ ", h("games.lasvegas-royale.settled")]
					})
				]
			}),
			(a || u) && /* @__PURE__ */ v("svg", {
				className: "lvr-casino-outline",
				viewBox: "0 0 100 100",
				preserveAspectRatio: "none",
				"aria-hidden": "true",
				focusable: "false",
				children: [/* @__PURE__ */ _("polygon", {
					className: "lvr-outline-portrait",
					points: e % 2 == 0 ? "8,2 98,7 98,93 8,98 2,50" : "2,7 92,2 98,50 92,98 2,93",
					vectorEffect: "non-scaling-stroke"
				}), /* @__PURE__ */ _("polygon", {
					className: "lvr-outline-landscape",
					points: "3,2 97,2 98,50 97,98 3,98 2,50",
					vectorEffect: "non-scaling-stroke"
				})]
			}),
			S && /* @__PURE__ */ _(Ze, {
				tile: S,
				pub: t,
				nameOf: i,
				onShowDetail: m
			}),
			!S && /* @__PURE__ */ v("span", {
				className: "lvr-casino-footer",
				"aria-hidden": !0,
				children: ["◆ ", h("games.lasvegas-royale.cashTable")]
			})
		]
	});
}
function Ye(e, t, n) {
	let r = t.tileState;
	if (e === "jackpot") return `$${ae[r.jackpotPos]}k`;
	if (e === "fiftyFifty") return t.pending?.kind === "fifty" ? Ge(L[t.pending.pos]) : "";
	if (e === "noEntry") return t.blocked === null ? "" : `${t.blocked + 1}`;
	if (e === "highFive") return r.highFiveHolder ? n(r.highFiveHolder) : "";
	if (e === "powerPlay") return r.powerPlayHolder ? n(r.powerPlayHolder) : "";
	if (e === "primeTime") return r.primeDice.length > 0 ? `⚄${r.primeDice.length}` : "";
	if (e === "blockIt") return `×${r.clusters.length}`;
	if (e === "handicap") return `${r.handicapUsed.filter((e) => !e).length}/9`;
	if (e === "doubleDown") {
		let e = Object.values(r.doubleDown).reduce((e, t) => e + t.small + t.big * 2, 0);
		return e > 0 ? `🎲${e}` : "";
	}
	if (e === "niceDice") {
		let e = r.niceDice.filter(Boolean).length;
		return e > 0 ? `${e}/6` : "";
	}
	if (e === "myChoice") return r.gold ? n(r.gold.rid) : "";
	if (e === "knockout") {
		let e = Object.values(r.bar).reduce((e, t) => e + t.small + t.big, 0);
		return e > 0 ? `🎲${e}` : "";
	}
	return "";
}
function Xe(e, t) {
	let n = t.tileState;
	return e === "jackpot" ? ae.map((e, t) => t === n.jackpotPos) : e === "fiftyFifty" ? L.map((e, n) => n === (t.pending?.kind === "fifty" ? t.pending.pos : 0)) : e === "noEntry" ? Array.from({ length: 6 }, (e, t) => t === n.noEntryPos) : e === "niceDice" ? n.niceDice.map(Boolean) : e === "handicap" ? n.handicapUsed : null;
}
function Ze({ tile: e, pub: t, nameOf: n, onShowDetail: i }) {
	let a = r(), o = Ye(e, t, n), s = Xe(e, t);
	return /* @__PURE__ */ v("button", {
		type: "button",
		className: "lvr-tile",
		"aria-label": a("games.lasvegas-royale.tileDetailsAria", { name: a(J[e]) }),
		onClick: () => i(e),
		children: [
			/* @__PURE__ */ _("span", {
				className: "lvr-tile-icon",
				"aria-hidden": !0,
				children: He[e]
			}),
			/* @__PURE__ */ _("span", {
				className: "lvr-tile-name",
				children: a(J[e])
			}),
			s && /* @__PURE__ */ _("span", {
				className: "lvr-tile-track",
				"aria-hidden": !0,
				children: s.map((e, t) => /* @__PURE__ */ _("i", { className: e ? "lvr-tile-track-on" : "" }, t))
			}),
			o && /* @__PURE__ */ _("span", {
				className: "lvr-tile-extra font-mono tabular-nums",
				children: o
			})
		]
	});
}
var Qe = {
	luckyPick: "luckyPunch",
	luckyGuess: "luckyPunch",
	fifty: "fiftyFifty",
	noEntry: "noEntry",
	knockout: "knockout",
	blockIt: "blockIt",
	handicap: "handicap",
	handicapChoice: "handicap",
	doubleDown: "doubleDown",
	niceDice: "niceDice",
	myChoice: "myChoice",
	myTile: "myChoice",
	myRotateOrReturn: "myChoice",
	myGold: "myChoice",
	primeTime: "primeTime",
	blackBoxSplit: "blackBox",
	blackBoxPick: "blackBox"
};
function $e({ pub: e, priv: t, myRid: n, myHex: i, myTurn: a, myPending: o, me: s, sel: c, setSel: u, send: d, allBlocked: f, canPower: p, selectedPlace: m }) {
	let h = r(), { ref: g, hidden: y } = l("tray"), b = e.pending;
	return /* @__PURE__ */ v("div", {
		ref: g,
		className: "lvr-actions",
		style: { visibility: y ? "hidden" : void 0 },
		children: [
			/* @__PURE__ */ v("div", {
				className: "lvr-action-heading",
				children: [
					/* @__PURE__ */ _("span", {
						className: "lvr-action-kicker",
						children: o && b ? `${He[Qe[b.kind]]} ${h(J[Qe[b.kind]])}` : m ? h("games.lasvegas-royale.selectedCasino", { n: m }) : a ? h("games.lasvegas-royale.yourTurn") : e.phase === "payout" ? h("games.lasvegas-royale.payout") : h("games.lasvegas-royale.waitingOthers")
					}),
					a && e.rolled && /* @__PURE__ */ _("span", {
						className: "lvr-action-tip",
						children: m && e.tiles[m - 1] ? h("games.lasvegas-royale.tileWillTrigger", { name: h(J[e.tiles[m - 1]]) }) : h(m ? "games.lasvegas-royale.confirmTip" : "games.lasvegas-royale.tapLegalTip")
					}),
					a && !e.rolled && !o && s && /* @__PURE__ */ _("span", {
						className: "lvr-action-tip lvr-remaining-dice",
						children: h("games.lasvegas-royale.remainingDice", {
							small: s.small,
							big: s.big
						})
					}),
					o && b?.kind === "blackBoxSplit" && /* @__PURE__ */ _("span", {
						className: "lvr-action-tip",
						children: h("games.lasvegas-royale.blackBoxPiles", {
							a: c?.mode === "blackBox" ? c.pileA.length : 0,
							b: 6 - (c?.mode === "blackBox" ? c.pileA.length : 0)
						})
					})
				]
			}),
			/* @__PURE__ */ _("div", {
				className: "lvr-action-body",
				children: o && b ? /* @__PURE__ */ _(nt, {
					pub: e,
					priv: t,
					pending: b,
					myRid: n,
					me: s,
					sel: c,
					setSel: u,
					send: d
				}) : a ? /* @__PURE__ */ _(et, {
					pub: e,
					me: s,
					myHex: i,
					sel: c,
					setSel: u,
					send: d,
					allBlocked: f,
					canPower: p,
					selectedPlace: m
				}) : e.phase === "payout" ? /* @__PURE__ */ v("div", {
					className: "lvr-payout-cue",
					children: [/* @__PURE__ */ v("strong", { children: ["✦ ", e.payoutIdx >= 0 && e.payoutIdx < 6 ? h("games.lasvegas-royale.payoutCasino", { n: e.payoutIdx + 1 }) : h("games.lasvegas-royale.payout")] }), /* @__PURE__ */ _("span", { children: h("games.lasvegas-royale.payoutFlow") })]
				}) : /* @__PURE__ */ v("div", {
					className: "lvr-waiting-cue",
					children: [/* @__PURE__ */ _("span", {
						"aria-hidden": !0,
						children: "◌"
					}), h("games.lasvegas-royale.waitingOthers")]
				})
			}),
			/* @__PURE__ */ _("p", {
				className: "lvr-action-footer",
				children: o ? h("games.lasvegas-royale.pendingHint") : a && !e.rolled ? h("games.lasvegas-royale.rollHint") : m ? h("games.lasvegas-royale.selectedHint") : e.phase === "payout" ? h("games.lasvegas-royale.payoutHint") : h(a ? "games.lasvegas-royale.tapLegalTip" : "games.lasvegas-royale.waitingOthers")
			})
		]
	});
}
function et({ pub: e, me: t, myHex: n, sel: i, setSel: a, send: o, allBlocked: s, canPower: c, selectedPlace: l }) {
	let u = r();
	if (e.rolled) {
		let r = l ? e.rolled.filter((e) => e.value === l) : [], i = r.reduce((e, t) => e + (t.big ? 2 : 1), 0);
		return /* @__PURE__ */ v("div", {
			className: "lvr-turn-rolled",
			children: [/* @__PURE__ */ v("div", {
				className: l === null ? "lvr-rolled-dice" : "lvr-selected-preview",
				"aria-label": u("games.lasvegas-royale.rolledDice"),
				children: [/* @__PURE__ */ _("span", {
					className: "lvr-selected-dice",
					children: (l === null ? [...e.rolled].sort((e, t) => e.value - t.value) : r).map((e, t) => /* @__PURE__ */ _(q, {
						value: e.value,
						big: e.big,
						size: l === null ? 28 : 25,
						hex: n
					}, t))
				}), l !== null && /* @__PURE__ */ _("strong", {
					className: "lvr-selected-summary",
					children: u("games.lasvegas-royale.placeSummary", {
						value: l,
						n: i
					})
				})]
			}), /* @__PURE__ */ v("div", {
				className: "lvr-turn-controls",
				children: [
					l !== null && /* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => a(null),
						className: "btn-quiet lvr-secondary-action lvr-reselect-button",
						children: u("games.lasvegas-royale.reselect")
					}),
					l !== null && /* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => o({
							type: "place",
							value: l
						}),
						className: "btn-base lvr-main-action lvr-confirm-button font-display",
						style: { background: E.accent },
						children: u("games.lasvegas-royale.confirmPlace", {
							value: l,
							n: i
						})
					}),
					l === null && (t?.chips ?? 0) > 0 && /* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => o({ type: "passChip" }),
						className: "btn-quiet lvr-secondary-action",
						children: ["🎟 ", u("games.lasvegas-royale.passChip")]
					}),
					s && /* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => o({ type: "forfeit" }),
						className: "btn-quiet lvr-secondary-action text-danger-ink",
						children: u("games.lasvegas-royale.forfeit")
					}),
					l === null && !s && /* @__PURE__ */ v("span", {
						className: "lvr-place-prompt",
						children: ["↗ ", u("games.lasvegas-royale.tapLegalTip")]
					})
				]
			})]
		});
	}
	return c && i?.mode === "power" ? /* @__PURE__ */ _(tt, {
		pub: e,
		sel: i,
		setSel: a,
		send: o
	}) : /* @__PURE__ */ v("div", {
		className: "lvr-roll-actions",
		children: [/* @__PURE__ */ v("button", {
			type: "button",
			onClick: () => o({ type: "roll" }),
			className: "btn-base lvr-roll-button font-display text-white",
			style: { background: E.accent },
			children: ["🎲 ", u("games.lasvegas-royale.roll")]
		}), c && /* @__PURE__ */ v("button", {
			type: "button",
			onClick: () => a({
				mode: "power",
				big: !1,
				value: [
					1,
					2,
					3,
					4,
					5,
					6
				].find((t) => e.blocked !== t - 1) ?? 1
			}),
			className: "btn-quiet lvr-secondary-action",
			children: ["♜ ", u(J.powerPlay)]
		})]
	});
}
function tt({ pub: e, sel: t, setSel: n, send: i }) {
	let a = r(), o = t?.mode === "power" ? t : {
		mode: "power",
		big: !1,
		value: [
			1,
			2,
			3,
			4,
			5,
			6
		].find((t) => e.blocked !== t - 1) ?? 1
	}, s = e.players.find((t) => t.rid === e.turn);
	return /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("span", {
		className: "lvr-power-controls",
		children: [
			/* @__PURE__ */ _("button", {
				type: "button",
				onClick: () => n(null),
				className: "btn-quiet lvr-secondary-action",
				children: a("games.lasvegas-royale.reselect")
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				"aria-pressed": o.big,
				onClick: () => n({
					...o,
					big: !o.big
				}),
				className: `min-h-11 rounded-lg border-2 px-2 text-xs font-bold ${o.big ? "border-ink bg-warn" : "border-ink/30 bg-surface"}`,
				children: o.big ? `${a("games.lasvegas-royale.pickBig")} ×${s?.big ?? 0}` : `${a("games.lasvegas-royale.pickSmall")} ×${s?.small ?? 0}`
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				disabled: o.big ? (s?.big ?? 0) < 1 : (s?.small ?? 0) < 1,
				onClick: () => i({
					type: "powerPlace",
					big: o.big,
					value: o.value
				}),
				className: "btn-base min-h-11 px-4 text-sm font-extrabold text-white",
				style: { background: E.accent },
				children: a("games.lasvegas-royale.confirm")
			})
		]
	}), /* @__PURE__ */ _("span", {
		className: "lvr-power-controls",
		children: [
			1,
			2,
			3,
			4,
			5,
			6
		].map((t) => /* @__PURE__ */ _("button", {
			type: "button",
			disabled: e.blocked === t - 1,
			"aria-pressed": o.value === t,
			onClick: () => n({
				...o,
				value: t
			}),
			className: `grid size-11 place-items-center rounded-lg border-2 font-mono text-sm font-black ${o.value === t ? "border-ink bg-warn" : "border-ink/30 bg-surface"}`,
			children: t
		}, t))
	})] });
}
function nt({ pub: e, priv: t, pending: n, myRid: i, me: a, sel: o, setSel: s, send: c }) {
	let l = r();
	switch (n.kind) {
		case "luckyPick":
		case "luckyGuess": {
			let e = n.kind;
			return /* @__PURE__ */ _("span", {
				className: "flex gap-2",
				children: [
					1,
					2,
					3
				].map((t) => /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => c(e === "luckyPick" ? {
						type: "luckyPick",
						n: t
					} : {
						type: "luckyGuess",
						n: t
					}),
					className: "btn-base grid size-12 place-items-center font-display text-lg font-black text-white",
					style: { background: E.accent },
					children: t
				}, t))
			});
		}
		case "fifty": return /* @__PURE__ */ v(g, { children: [
			/* @__PURE__ */ _("span", {
				className: "flex items-center gap-1",
				children: L.map((e, t) => /* @__PURE__ */ _("span", {
					className: `rounded-md border-2 px-1 font-mono text-[10px] font-black tabular-nums ${t === n.pos ? "border-ink bg-warn" : "border-ink/25 bg-surface/60"}`,
					children: Ge(e)
				}, t))
			}),
			/* @__PURE__ */ _("span", {
				className: "lvr-pending-step",
				children: l("games.lasvegas-royale.fiftyLastSum", { n: n.lastSum })
			}),
			/* @__PURE__ */ v("span", {
				className: "flex gap-2",
				children: [
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => c({ type: "fiftyStop" }),
						className: "btn-base min-h-11 px-4 text-sm font-extrabold text-white",
						style: { background: E.accent },
						children: l("games.lasvegas-royale.fiftyStop")
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => c({
							type: "fiftyBet",
							high: !0
						}),
						className: "btn-quiet min-h-11 px-3 text-sm font-bold",
						children: ["▲ ", l("games.lasvegas-royale.fiftyBetHigh")]
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => c({
							type: "fiftyBet",
							high: !1
						}),
						className: "btn-quiet min-h-11 px-3 text-sm font-bold",
						children: ["▼ ", l("games.lasvegas-royale.fiftyBetLow")]
					})
				]
			})
		] });
		case "noEntry": return /* @__PURE__ */ v("span", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ _("span", {
					className: "lvr-pending-step",
					children: l("games.lasvegas-royale.noEntryNextReward", { reward: Ge(oe[(e.tileState.noEntryPos + 1) % oe.length]) })
				}),
				!n.mustMove && /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => c({
						type: "noEntry",
						target: null
					}),
					className: "btn-quiet min-h-11 px-4 text-sm font-bold",
					children: l("games.lasvegas-royale.noEntryStay")
				}),
				/* @__PURE__ */ v("span", {
					className: "lvr-pending-step",
					children: ["↗ ", l("games.lasvegas-royale.selectTargetOnTable")]
				})
			]
		});
		case "knockout": {
			let e = (a?.small ?? 0) > 0, t = (a?.big ?? 0) > 0;
			return /* @__PURE__ */ v("span", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ v("button", {
					type: "button",
					disabled: !e,
					onClick: () => c({
						type: "knockout",
						big: !1
					}),
					className: "btn-base min-h-11 px-4 text-sm font-extrabold text-white",
					style: { background: E.accent },
					children: [
						"🎲 ",
						l("games.lasvegas-royale.pickSmall"),
						" ×",
						a?.small ?? 0
					]
				}), /* @__PURE__ */ v("button", {
					type: "button",
					disabled: !t,
					onClick: () => c({
						type: "knockout",
						big: !0
					}),
					className: "btn-base min-h-11 px-4 text-sm font-extrabold text-white",
					style: { background: E.accent },
					children: [
						"🔶 ",
						l("games.lasvegas-royale.pickBig"),
						" ×",
						a?.big ?? 0
					]
				})]
			});
		}
		case "blockIt": {
			let e = o?.mode === "blockIt" ? o : {
				mode: "blockIt",
				cluster: null
			};
			return /* @__PURE__ */ v("span", {
				className: "flex flex-wrap items-center justify-center gap-1.5",
				children: [n.clusters.map((t, n) => /* @__PURE__ */ v("button", {
					type: "button",
					"aria-pressed": e.cluster === n,
					onClick: () => s({
						mode: "blockIt",
						cluster: n
					}),
					className: `grid size-11 place-items-center rounded-lg border-2 font-mono text-sm font-black ${e.cluster === n ? "border-ink bg-warn" : "border-ink/30 bg-surface"}`,
					children: [t, "🎲"]
				}, n)), /* @__PURE__ */ _("span", {
					className: "lvr-pending-step",
					children: e.cluster === null ? l("games.lasvegas-royale.chooseClusterFirst") : `↗ ${l("games.lasvegas-royale.selectTargetOnTable")}`
				})]
			});
		}
		case "handicap": {
			let e = o?.mode === "handicap" ? o : {
				mode: "handicap",
				space: null
			};
			return /* @__PURE__ */ v(g, { children: [
				/* @__PURE__ */ _("span", {
					className: "lvr-handicap-options",
					children: se.map((t, r) => {
						let i = !n.spaces.includes(r), a = t === "chip1" ? "+1🎟" : t === 30 ? "$30k" : "⇄";
						return /* @__PURE__ */ _("button", {
							type: "button",
							disabled: i,
							"aria-pressed": e.space === r,
							"aria-label": l("games.lasvegas-royale.handicapRewardAria", {
								n: r + 1,
								reward: t === "chip1" ? l("games.lasvegas-royale.chips") : t === 30 ? "$30k" : l("games.lasvegas-royale.handicapChoicePrompt")
							}),
							onClick: () => s({
								mode: "handicap",
								space: r
							}),
							className: `grid size-11 place-items-center rounded-lg border-2 font-mono text-[11px] font-black ${i ? "border-ink/15 bg-surface/40 opacity-40" : e.space === r ? "border-ink bg-warn" : "border-ink/30 bg-surface"}`,
							children: a
						}, r);
					})
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => c({ type: "handicapSkip" }),
					className: "btn-quiet min-h-11 px-4 text-sm font-bold",
					children: l("games.lasvegas-royale.handicapSkip")
				}),
				/* @__PURE__ */ _("span", {
					className: "lvr-pending-step",
					children: e.space === null ? l("games.lasvegas-royale.chooseRewardFirst") : `↗ ${l("games.lasvegas-royale.selectGrayCasino")}`
				})
			] });
		}
		case "handicapChoice":
		case "myRotateOrReturn": return /* @__PURE__ */ _(rt, {
			pub: e,
			myRid: i,
			sel: o,
			setSel: s,
			send: c,
			isHandicap: n.kind === "handicapChoice"
		});
		case "doubleDown": {
			let e = o?.mode === "doubleDown" ? o : {
				mode: "doubleDown",
				small: 0,
				big: 0
			}, t = e.small + e.big * 2;
			return /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("span", {
				className: "flex items-center justify-center gap-2",
				children: [/* @__PURE__ */ _(it, {
					label: `🎲×${e.small}`,
					onMinus: () => s({
						...e,
						small: Math.max(0, e.small - 1)
					}),
					onPlus: () => s({
						...e,
						small: Math.min(n.maxSmall, e.small + 1)
					})
				}), /* @__PURE__ */ _(it, {
					label: `🔶×${e.big}`,
					onMinus: () => s({
						...e,
						big: Math.max(0, e.big - 1)
					}),
					onPlus: () => s({
						...e,
						big: Math.min(n.maxBig, e.big + 1)
					})
				})]
			}), /* @__PURE__ */ _("button", {
				type: "button",
				onClick: () => c({
					type: "doubleDown",
					small: e.small,
					big: e.big
				}),
				className: "btn-base min-h-11 px-4 text-sm font-extrabold text-white",
				style: { background: E.accent },
				children: l("games.lasvegas-royale.doubleDownConfirm", { n: t })
			})] });
		}
		case "niceDice": {
			let e = /* @__PURE__ */ new Set(), t = n.candidates.filter((t) => {
				let n = `${t.value}:${t.big}`;
				return !e.has(n) && (e.add(n), !0);
			});
			return /* @__PURE__ */ v("span", {
				className: "flex flex-wrap items-center justify-center gap-1",
				children: [t.map((e, t) => /* @__PURE__ */ v("button", {
					type: "button",
					"aria-label": l("games.lasvegas-royale.dieOptionAria", {
						value: e.value,
						kind: l(e.big ? "games.lasvegas-royale.bigDie" : "games.lasvegas-royale.smallDie")
					}),
					onClick: () => c({
						type: "niceDice",
						value: e.value,
						big: e.big
					}),
					className: "lvr-nice-option rounded-lg border-2 border-ink bg-surface p-0.5 active:translate-y-0.5",
					children: [/* @__PURE__ */ _(q, {
						value: e.value,
						big: e.big,
						size: 22
					}), /* @__PURE__ */ _("span", {
						className: "font-mono text-[10px] leading-3 font-black tabular-nums",
						children: Ge(ce[e.value - 1])
					})]
				}, t)), /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => c({ type: "niceSkip" }),
					className: "btn-quiet min-h-11 px-4 text-sm font-bold",
					children: l("games.lasvegas-royale.niceSkip")
				})]
			});
		}
		case "myChoice": return /* @__PURE__ */ _("span", {
			className: "flex flex-wrap items-center justify-center gap-2",
			children: [...new Set(n.dice)].map((e) => /* @__PURE__ */ v("button", {
				type: "button",
				onClick: () => c({
					type: "myChoice",
					value: e
				}),
				className: "btn-base flex min-h-11 items-center gap-1.5 px-3 text-sm font-extrabold text-white",
				style: { background: E.accent },
				children: [/* @__PURE__ */ _(q, {
					value: e,
					size: 22
				}), l(We[e])]
			}, e))
		});
		case "myTile": return /* @__PURE__ */ v("span", {
			className: "lvr-pending-step",
			children: ["↗ ", l("games.lasvegas-royale.selectTargetOnTable")]
		});
		case "myGold": return /* @__PURE__ */ v("span", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ v("button", {
				type: "button",
				disabled: (a?.small ?? 0) < 1,
				onClick: () => c({
					type: "myGold",
					big: !1
				}),
				className: "btn-base min-h-11 px-4 text-sm font-extrabold text-white",
				style: { background: E.accent },
				children: ["🎲 ", l("games.lasvegas-royale.pickSmall")]
			}), /* @__PURE__ */ v("button", {
				type: "button",
				disabled: (a?.big ?? 0) < 1,
				onClick: () => c({
					type: "myGold",
					big: !0
				}),
				className: "btn-base min-h-11 px-4 text-sm font-extrabold text-white",
				style: { background: E.accent },
				children: ["🔶 ", l("games.lasvegas-royale.pickBig")]
			})]
		});
		case "primeTime": {
			let t = o?.mode === "primeTime" ? o : {
				mode: "primeTime",
				place: [!1, !1]
			};
			return /* @__PURE__ */ v("span", {
				className: "flex items-center gap-2",
				children: [n.dice.map((n, r) => /* @__PURE__ */ _("button", {
					type: "button",
					disabled: e.blocked === n - 1,
					"aria-pressed": t.place[r],
					"aria-label": l("games.lasvegas-royale.primeTimeDieAria", { value: n }),
					onClick: () => {
						let e = [...t.place];
						e[r] = !e[r], s({
							...t,
							place: e
						});
					},
					className: `grid size-11 place-items-center rounded-lg border-2 p-0.5 ${t.place[r] ? "border-ink bg-warn" : "border-ink/30 bg-surface"} ${e.blocked === n - 1 ? "opacity-40" : ""}`,
					children: /* @__PURE__ */ _(q, {
						value: n,
						size: 32
					})
				}, r)), /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => c({
						type: "primeTime",
						place: t.place
					}),
					className: "btn-base min-h-11 px-4 text-sm font-extrabold text-white",
					style: { background: E.accent },
					children: l("games.lasvegas-royale.confirm")
				})]
			});
		}
		case "blackBoxSplit": {
			let e = o?.mode === "blackBox" ? o : {
				mode: "blackBox",
				pileA: []
			}, t = le, n = e.pileA.length >= 1 && e.pileA.length <= 3;
			return /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("span", {
				className: "flex flex-wrap items-center justify-center gap-1.5",
				children: t.map((t, n) => {
					let r = e.pileA.includes(n);
					return /* @__PURE__ */ v("button", {
						type: "button",
						"aria-pressed": r,
						"aria-label": l("games.lasvegas-royale.blackBoxTokenAria", {
							value: t,
							pile: r ? "A" : "B"
						}),
						onClick: () => s({
							mode: "blackBox",
							pileA: r ? e.pileA.filter((e) => e !== n) : [...e.pileA, n]
						}),
						className: `flex size-11 flex-col items-center justify-center rounded-lg border-2 font-mono text-[11px] font-black ${r ? "border-ink bg-warn" : "border-ink/30 bg-surface"}`,
						children: [/* @__PURE__ */ _("small", {
							className: "text-[9px] leading-none",
							children: r ? "A" : "B"
						}), /* @__PURE__ */ _("span", { children: t === 0 ? "—" : `$${t}k` })]
					}, n);
				})
			}), /* @__PURE__ */ v("button", {
				type: "button",
				disabled: !n,
				onClick: () => c({
					type: "blackBoxSplit",
					pileA: e.pileA
				}),
				className: "btn-base min-h-11 px-4 text-sm font-extrabold text-white",
				style: { background: E.accent },
				children: [
					l("games.lasvegas-royale.confirm"),
					" (",
					e.pileA.length,
					"/6)"
				]
			})] });
		}
		case "blackBoxPick": {
			let e = t?.blackBoxPiles;
			return /* @__PURE__ */ _("span", {
				className: "flex gap-2",
				children: [0, 1].map((t) => /* @__PURE__ */ v("button", {
					type: "button",
					onClick: () => c({
						type: "blackBoxPick",
						pile: t
					}),
					className: "btn-base min-h-12 px-6 font-display text-lg font-black text-white",
					style: { background: E.accent },
					children: [
						"▣ ",
						t === 0 ? "A" : "B",
						" ",
						e ? `(${e[t].length})` : ""
					]
				}, t))
			});
		}
	}
}
function rt({ pub: e, myRid: t, sel: n, setSel: i, send: a, isHandicap: o }) {
	let s = r(), c = [
		1,
		2,
		3,
		4,
		5,
		6
	].find((t) => e.blocked !== t - 1) ?? 1, l = n?.mode === "choice" ? n : {
		mode: "choice",
		sub: "rotate",
		big: !1,
		value: c,
		fromCasino: null
	}, u = e.players.find((e) => e.rid === t), d = l.fromCasino === null ? void 0 : e.placed[l.fromCasino][t], f = (d?.big ?? 0) > 0, p = (d?.small ?? 0) > 0, m = l.sub === "rotate" ? l.big ? (u?.big ?? 0) > 0 : (u?.small ?? 0) > 0 : l.fromCasino !== null && (l.big ? f : p);
	return /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("span", {
		className: "flex flex-wrap items-center justify-center gap-1",
		children: [
			/* @__PURE__ */ _("button", {
				type: "button",
				"aria-pressed": l.sub === "rotate",
				onClick: () => i({
					...l,
					sub: "rotate"
				}),
				className: `min-h-11 rounded-lg border-2 px-3 text-xs font-bold ${l.sub === "rotate" ? "border-ink bg-warn" : "border-ink/30 bg-surface"}`,
				children: s("games.lasvegas-royale.handicapRotateAction")
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				"aria-pressed": l.sub === "return",
				onClick: () => i({
					...l,
					sub: "return"
				}),
				className: `min-h-11 rounded-lg border-2 px-3 text-xs font-bold ${l.sub === "return" ? "border-ink bg-warn" : "border-ink/30 bg-surface"}`,
				children: s("games.lasvegas-royale.handicapReturnAction")
			}),
			(l.sub === "rotate" || l.fromCasino !== null) && /* @__PURE__ */ _("button", {
				type: "button",
				"aria-pressed": l.big,
				onClick: () => i({
					...l,
					big: !l.big
				}),
				className: `min-h-11 rounded-lg border-2 px-2 text-xs font-bold ${l.big ? "border-ink bg-warn" : "border-ink/30 bg-surface"}`,
				children: l.big ? s("games.lasvegas-royale.pickBig") : s("games.lasvegas-royale.pickSmall")
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				disabled: !m,
				onClick: () => {
					l.sub === "rotate" ? a(o ? {
						type: "handicapRotate",
						big: l.big,
						value: l.value
					} : {
						type: "myRotate",
						big: l.big,
						value: l.value
					}) : l.fromCasino !== null && a(o ? {
						type: "handicapReturn",
						fromCasino: l.fromCasino,
						big: l.big
					} : {
						type: "myReturn",
						fromCasino: l.fromCasino,
						big: l.big
					});
				},
				className: "btn-base min-h-11 px-3 text-sm font-extrabold text-white",
				style: { background: E.accent },
				children: s("games.lasvegas-royale.confirm")
			})
		]
	}), l.sub === "rotate" ? /* @__PURE__ */ _("span", {
		className: "flex flex-wrap items-center justify-center gap-1",
		children: [
			1,
			2,
			3,
			4,
			5,
			6
		].map((t) => /* @__PURE__ */ _("button", {
			type: "button",
			disabled: e.blocked === t - 1,
			"aria-pressed": l.value === t,
			onClick: () => i({
				...l,
				value: t
			}),
			className: `grid size-11 place-items-center rounded-lg border-2 font-mono text-sm font-black ${l.value === t ? "border-ink bg-warn" : "border-ink/30 bg-surface"}`,
			children: t
		}, t))
	}) : /* @__PURE__ */ _("span", {
		className: "flex items-center gap-2",
		children: /* @__PURE__ */ _("span", {
			className: "lvr-pending-step",
			children: l.fromCasino === null ? `↗ ${s("games.lasvegas-royale.selectOwnCasino")}` : s("games.lasvegas-royale.confirmTip")
		})
	})] });
}
function it({ label: e, onMinus: t, onPlus: n }) {
	return /* @__PURE__ */ v("span", {
		className: "flex items-center gap-1",
		children: [
			/* @__PURE__ */ _("button", {
				type: "button",
				onClick: t,
				className: "grid size-11 place-items-center rounded-lg border-2 border-ink/30 bg-surface text-lg font-black",
				children: "−"
			}),
			/* @__PURE__ */ _("span", {
				className: "min-w-12 text-center font-mono text-sm font-black tabular-nums",
				children: e
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				onClick: n,
				className: "grid size-11 place-items-center rounded-lg border-2 border-ink/30 bg-surface text-lg font-black",
				children: "+"
			})
		]
	});
}
//#endregion
//#region src/games/lasvegas-royale/bot.ts
function Y(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var X = (e) => e ? e.small + e.big * 2 : 0;
function Z(e, t) {
	let n = Object.entries(e.placed[t]).map(([e, t]) => ({
		who: e,
		count: X(t)
	})).filter((e) => e.count > 0);
	return e.gray[t] > 0 && n.push({
		who: "$gray",
		count: e.gray[t]
	}), n;
}
function at(e, t, n, r) {
	let i = Z(e, t), a = (i.find((e) => e.who === n)?.count ?? 0) + r, o = [...i.filter((e) => e.who !== n).map((e) => e.count), a], s = /* @__PURE__ */ new Map();
	for (let e of o) s.set(e, (s.get(e) ?? 0) + 1);
	return (s.get(a) ?? 0) > 1 ? -1 : o.filter((e) => s.get(e) === 1).sort((e, t) => t - e).indexOf(a);
}
var ot = {
	luckyPunch: 9,
	jackpot: 12,
	primeTime: 4,
	fiftyFifty: 9,
	highFive: 6,
	badLuck: -8,
	payDay: 10,
	powerPlay: 7,
	noEntry: 6,
	knockout: 5,
	blockIt: 4,
	handicap: 7,
	blackBox: 6,
	doubleDown: 5,
	niceDice: 7,
	myChoice: 11
};
function st(e, t) {
	let n = null, r = Infinity;
	for (let i = 0; i < 6; i += 1) {
		if (i === e.blocked) continue;
		let a = e.placed[i][t];
		if (!a || a.small + a.big === 0) continue;
		let o = Math.max(0, ...Object.entries(e.placed[i]).filter(([e]) => e !== t).map(([, e]) => X(e))) - X(a);
		o < r && (r = o, n = {
			fromCasino: i,
			big: a.small < 1
		});
	}
	return n;
}
var ct = (e, t) => {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	let i = t.difficulty === "weak", a = n.pending;
	if (a) {
		if (!a.who.includes(t.rid)) return null;
		switch (a.kind) {
			case "luckyPick": return { action: {
				type: "luckyPick",
				n: Y([
					1,
					2,
					3
				])
			} };
			case "luckyGuess": return { action: {
				type: "luckyGuess",
				n: Y([
					1,
					2,
					3
				])
			} };
			case "fifty":
				if (i) {
					let e = Y([
						0,
						1,
						2
					]);
					return e === 0 ? { action: { type: "fiftyStop" } } : { action: {
						type: "fiftyBet",
						high: e === 1
					} };
				}
				return a.pos >= 4 ? { action: { type: "fiftyStop" } } : { action: {
					type: "fiftyBet",
					high: a.lastSum < 7
				} };
			case "noEntry": {
				if (!a.mustMove && !i) return { action: {
					type: "noEntry",
					target: null
				} };
				let e = n.tiles.indexOf("noEntry"), r = null, o = -1;
				for (let i = 0; i < 6; i += 1) {
					if (i === e || i === n.blocked) continue;
					let a = Object.entries(n.placed[i]).filter(([e]) => e !== t.rid).reduce((e, [, t]) => e + X(t), 0) - X(n.placed[i][t.rid]) * 2;
					a > o && (o = a, r = i);
				}
				return r === null ? { action: {
					type: "noEntry",
					target: null
				} } : { action: {
					type: "noEntry",
					target: r
				} };
			}
			case "knockout": return { action: {
				type: "knockout",
				big: r.small < 1
			} };
			case "blockIt": {
				if (i || a.clusters.length === 0) return { action: {
					type: "blockIt",
					cluster: 0,
					target: Y([
						0,
						1,
						2,
						3,
						4,
						5
					].filter((e) => e !== n.blocked))
				} };
				let e = 0;
				a.clusters.forEach((t, n) => {
					t < a.clusters[e] && (e = n);
				});
				let r = 0, o = -Infinity;
				for (let e = 0; e < 6; e += 1) {
					if (e === n.blocked) continue;
					let i = X(n.placed[e][t.rid]), a = Math.max(0, ...Object.entries(n.placed[e]).filter(([e]) => e !== t.rid).map(([, e]) => X(e))) - i;
					a > o && (o = a, r = e);
				}
				return { action: {
					type: "blockIt",
					cluster: e,
					target: r
				} };
			}
			case "handicap": {
				if (i) return { action: { type: "handicapSkip" } };
				let e = a.spaces.find((e) => e >= 2 && e <= 4) ?? a.spaces[0], t = -1, r = 0;
				return n.gray.forEach((e, i) => {
					e > r && i !== n.blocked && (r = e, t = i);
				}), e === void 0 || t < 0 ? { action: { type: "handicapSkip" } } : { action: {
					type: "handicap",
					space: e,
					fromCasino: t
				} };
			}
			case "handicapChoice":
				if (r.small + r.big === 0) {
					let e = st(n, t.rid);
					if (e) return { action: {
						type: "handicapReturn",
						...e
					} };
				}
				return { action: {
					type: "handicapRotate",
					big: r.small < 1,
					value: lt(n, t.rid)
				} };
			case "doubleDown": return i ? { action: {
				type: "doubleDown",
				small: 0,
				big: 0
			} } : { action: {
				type: "doubleDown",
				small: +(a.maxSmall >= 2),
				big: 0
			} };
			case "niceDice": {
				if (i || a.candidates.length === 0) return { action: { type: "niceSkip" } };
				let e = n.tiles.indexOf("niceDice"), t = [...a.candidates].sort((t, n) => n.value - t.value || Number(t.value === e + 1) - Number(n.value === e + 1))[0];
				return { action: {
					type: "niceDice",
					value: t.value,
					big: t.big
				} };
			}
			case "myChoice": {
				let e = {
					1: 10,
					2: 20,
					3: 30,
					4: 14,
					5: 16,
					6: r.small + r.big > 2 ? 24 : 8
				};
				return { action: {
					type: "myChoice",
					value: [...new Set(a.dice)].sort((t, n) => e[n] - e[t])[0]
				} };
			}
			case "myTile": {
				let e = [
					"payDay",
					"jackpot",
					"niceDice",
					"myChoice",
					"fiftyFifty",
					"handicap",
					"luckyPunch",
					"doubleDown",
					"noEntry",
					"knockout",
					"blockIt",
					"powerPlay",
					"highFive",
					"primeTime",
					"blackBox",
					"badLuck"
				];
				return { action: {
					type: "myTile",
					target: [...a.candidates].sort((t, r) => e.indexOf(n.tiles[t]) - e.indexOf(n.tiles[r]))[0]
				} };
			}
			case "myRotateOrReturn":
				if (r.small + r.big === 0) {
					let e = st(n, t.rid);
					if (e) return { action: {
						type: "myReturn",
						...e
					} };
				}
				return { action: {
					type: "myRotate",
					big: r.small < 1,
					value: lt(n, t.rid)
				} };
			case "myGold": return { action: {
				type: "myGold",
				big: r.small < 1
			} };
			case "primeTime": {
				let e = [!1, !1];
				return a.dice.forEach((r, a) => {
					let o = r - 1;
					if (n.blocked === o) return;
					if (i) {
						e[a] = !0;
						return;
					}
					let s = Z(n, o), c = (s.find((e) => e.who === t.rid)?.count ?? 0) + 1, l = s.some((e) => e.who !== t.rid && e.count === c);
					e[a] = !l;
				}), { action: {
					type: "primeTime",
					place: e
				} };
			}
			case "blackBoxSplit": return { action: {
				type: "blackBoxSplit",
				pileA: [
					0,
					1,
					5
				]
			} };
			case "blackBoxPick": return { action: {
				type: "blackBoxPick",
				pile: Y([0, 1])
			} };
		}
	}
	if (n.phase !== "play" || n.turn !== t.rid) return null;
	if (n.rolled === null) return { action: { type: "roll" } };
	let o = n.rolled, s = [...new Set(o.map((e) => e.value))].filter((e) => n.blocked !== e - 1);
	if (s.length === 0) return { action: r.chips > 0 ? { type: "passChip" } : { type: "forfeit" } };
	if (i) return { action: {
		type: "place",
		value: Y(s)
	} };
	let c = r.money, l = Math.max(...n.players.filter((e) => e.rid !== t.rid).map((e) => e.money), 0) - c, u = s[0], d = -Infinity;
	for (let e of s) {
		let r = e - 1, i = o.filter((t) => t.value === e).reduce((e, t) => e + (t.big ? 2 : 1), 0), a = n.casinos[r], s = at(n, r, t.rid, i), c;
		if (s < 0) {
			let e = Z(n, r).filter((e) => e.who !== t.rid).sort((e, t) => t.count - e.count)[0], o = (Z(n, r).find((e) => e.who === t.rid)?.count ?? 0) + i;
			c = -3 + (e && e.count === o ? a[0] ?? 0 : 0) * Math.min(l / 40, 1.5) / 10;
		} else {
			let e = a[s] ?? 0, o = Z(n, r).filter((e) => e.who !== t.rid), l = (Z(n, r).find((e) => e.who === t.rid)?.count ?? 0) + i, u = Math.max(0, ...o.map((e) => e.count));
			c = e + (l > u ? .5 + .3 * Math.min(l - u, 3) : 0) + .05 * a.reduce((e, t) => e + t, 0);
		}
		let f = n.tiles[r];
		if (f && (c += ot[f] / 10), f === "badLuck") {
			let e = n.players.map((e) => e.rid === t.rid ? X(n.placed[r][e.rid]) + i : X(n.placed[r][e.rid]));
			Math.min(...e) === e[n.players.findIndex((e) => e.rid === t.rid)] && (c -= 3);
		}
		c -= i * .08, c > d && (d = c, u = e);
	}
	return { action: {
		type: "place",
		value: u
	} };
};
function lt(e, t) {
	let n = 1, r = -Infinity;
	for (let i = 0; i < 6; i += 1) {
		if (e.blocked === i) continue;
		let a = e.casinos[i], o = at(e, i, t, 1), s = (o >= 0 ? a[o] ?? 0 : 0) + .05 * a.reduce((e, t) => e + t, 0);
		s > r && (r = s, n = i + 1);
	}
	return n;
}
var ut = (e, t, n) => {
	let r = t.public;
	switch (e.type) {
		case "roll": return n("games.lasvegas-royale.describeRoll");
		case "passChip": return n("games.lasvegas-royale.describePassChip");
		case "place": return n("games.lasvegas-royale.describePlace", {
			count: r.rolled?.filter((t) => t.value === e.value).reduce((e, t) => e + (t.big ? 2 : 1), 0) ?? 0,
			value: e.value
		});
		case "forfeit": return n("games.lasvegas-royale.describeForfeit");
		case "powerPlace": return n("games.lasvegas-royale.describePowerPlace", { value: e.value });
		case "luckyPick": return n("games.lasvegas-royale.describeLuckyPick", { n: e.n });
		case "luckyGuess": return n("games.lasvegas-royale.describeLuckyGuess", { n: e.n });
		case "fiftyStop": return n("games.lasvegas-royale.describeFiftyStop");
		case "fiftyBet": return n("games.lasvegas-royale.describeFiftyBet");
		case "noEntry": return e.target === null ? n("games.lasvegas-royale.describeNoEntry", { n: "-" }) : n("games.lasvegas-royale.describeNoEntry", { n: e.target + 1 });
		case "knockout": return n("games.lasvegas-royale.describeKnockout");
		case "blockIt": return n("games.lasvegas-royale.describeBlockIt", {
			n: r.tileState.clusters[e.cluster] ?? 0,
			c: e.target + 1
		});
		case "handicap": return n("games.lasvegas-royale.describeHandicap");
		case "handicapSkip": return n("games.lasvegas-royale.describeHandicapSkip");
		case "handicapRotate": return n("games.lasvegas-royale.describeHandicapRotate");
		case "handicapReturn": return n("games.lasvegas-royale.describeHandicapReturn");
		case "doubleDown": return n("games.lasvegas-royale.describeDoubleDown", { n: e.small + e.big });
		case "niceDice": return n("games.lasvegas-royale.describeNiceDice");
		case "niceSkip": return n("games.lasvegas-royale.describeNiceSkip");
		case "myChoice": return n("games.lasvegas-royale.describeMyChoice", { value: e.value });
		case "myTile": return n("games.lasvegas-royale.describeMyTile");
		case "myRotate": return n("games.lasvegas-royale.describeMyRotate");
		case "myReturn": return n("games.lasvegas-royale.describeMyReturn");
		case "myGold": return n("games.lasvegas-royale.describeMyGold");
		case "primeTime": return n("games.lasvegas-royale.describePrimeTime");
		case "blackBoxSplit": return n("games.lasvegas-royale.describeBlackBoxSplit");
		case "blackBoxPick": return n("games.lasvegas-royale.describeBlackBoxPick");
		default: return "";
	}
};
//#endregion
//#region src/games/lasvegas-royale/fx.tsx
function dt(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function ft(e, t) {
	let n = t ? e.member(t) : null;
	return d[(n?.colorIndex ?? 0) % d.length].hex;
}
function pt(e, t) {
	return /* @__PURE__ */ v("span", {
		style: { fontSize: t },
		className: "rounded-md border-2 border-ink bg-done-soft px-1.5 py-0.5 font-mono text-xs font-extrabold tabular-nums text-done-ink shadow-[2px_2px_0_var(--color-ink)]",
		children: [
			"$",
			e,
			"k"
		]
	});
}
function Q({ k: e, params: t, danger: n }) {
	let i = r();
	return /* @__PURE__ */ _("span", {
		className: `rounded-lg border-2 border-ink px-1.5 py-0.5 font-mono text-xs font-black tabular-nums shadow-[2px_2px_0_var(--color-ink)] ${n ? "bg-danger-soft text-danger-ink" : "bg-surface"}`,
		children: i(e, t)
	});
}
function $(e, t, n, r = 900) {
	let i = e.anchor(t);
	return i ? {
		ms: r,
		node: /* @__PURE__ */ _(x, {
			at: i,
			ms: r,
			children: n
		})
	} : null;
}
var mt = {
	diceRoll: y({
		tintByPlayer: !0,
		parse: (e) => {
			let t = e;
			return typeof t?.value == "number" ? {
				value: t.value,
				scale: t.big === !0 ? 1.3 : 1
			} : null;
		}
	}),
	place(e, t) {
		let n = e.data;
		if (typeof n?.casino != "number") return null;
		let r = t.anchor(`casino:${n.casino}`);
		if (!r) return null;
		let i = ft(t, e.rid), a = n.casino + 1, o = typeof n.small == "number" ? n.small : 0, s = typeof n.big == "number" ? n.big : 0, c = o + s, l = t.queued > 0, u = t.anchor("tray"), d = Math.max(26, t.anchor("lvr:die-size")?.w ?? 19), f = u ? {
			x: u.x + (u.w - d) / 2,
			y: u.y + (u.h - d) / 2,
			w: d,
			h: d
		} : null, p = Math.min(c, 5), m = l ? 250 : 480;
		return {
			ms: l ? 350 : 620,
			node: /* @__PURE__ */ v(g, { children: [
				f && Array.from({ length: p }, (e, t) => /* @__PURE__ */ _(S, {
					from: f,
					to: {
						x: r.x + (r.w - d) / 2 + (t - (p - 1) / 2) * d * .46,
						y: r.y + (r.h - d) / 2,
						w: d,
						h: d
					},
					ms: m,
					delay: l ? 0 : t * 60,
					children: /* @__PURE__ */ _(q, {
						value: a,
						big: t >= p - s,
						size: d,
						hex: i
					})
				}, t)),
				!u && /* @__PURE__ */ _(C, {
					at: r,
					ms: m
				}),
				!l && /* @__PURE__ */ _(x, {
					at: r,
					ms: 800,
					delay: 200,
					children: /* @__PURE__ */ v("span", {
						className: "rounded-lg border-2 border-ink bg-surface px-1.5 font-mono text-sm font-black tabular-nums shadow-[2px_2px_0_var(--color-ink)]",
						children: ["×", c]
					})
				})
			] })
		};
	},
	payout(e, t) {
		let n = e.data;
		if (typeof n?.casino != "number") return null;
		let r = t.anchor(`casino:${n.casino}`);
		if (!r) return null;
		let i = Array.isArray(n.busted) ? n.busted : [], a = Array.isArray(n.awards) ? n.awards : [], o = Math.max(12, (t.anchor("lvr:die-size")?.w ?? 18) / 1.5);
		return w(), {
			ms: 900,
			node: /* @__PURE__ */ v(g, { children: [i.length > 0 && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(C, {
				at: r,
				ms: 600
			}), /* @__PURE__ */ _(x, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ _("span", {
					className: "font-mono text-sm font-black text-danger-ink",
					children: "✕"
				})
			})] }), a.map((e, n) => {
				let a = dt(t, e.rid);
				return a ? /* @__PURE__ */ _(S, {
					from: r,
					to: a,
					ms: 520,
					delay: i.length > 0 ? 250 + n * 160 : n * 160,
					children: pt(e.note, o)
				}, e.rid) : /* @__PURE__ */ _(x, {
					at: r,
					ms: 700,
					delay: n * 120,
					children: pt(e.note, o)
				}, e.rid);
			})] })
		};
	},
	supply(e, t) {
		let n = e.data;
		if (typeof n?.casino != "number") return null;
		let r = t.anchor(`casino:${n.casino}`);
		return r ? {
			ms: 550,
			node: /* @__PURE__ */ _(C, {
				at: r,
				ms: 550
			})
		} : null;
	},
	tiles() {
		return {
			ms: 500,
			node: /* @__PURE__ */ _(b, {
				ms: 500,
				className: "bg-info-soft"
			})
		};
	},
	jackpot(e, t) {
		let n = e.data;
		if (typeof n?.casino != "number" || !Array.isArray(n.dice)) return null;
		let r = t.anchor(`casino:${n.casino}`);
		if (!r) return null;
		let i = n.dice;
		return {
			ms: 950,
			node: /* @__PURE__ */ v(g, { children: [i.map((e, t) => /* @__PURE__ */ _(S, {
				from: {
					x: r.x + r.w / 2 - 18 + t * 36,
					y: r.y - 80,
					w: 30,
					h: 30
				},
				to: {
					x: r.x + r.w / 2 - 18 + t * 36,
					y: r.y + 8,
					w: 30,
					h: 30
				},
				ms: 380,
				delay: t * 80,
				children: /* @__PURE__ */ _(q, {
					value: e,
					size: 30,
					hex: "#1f2937"
				})
			}, t)), /* @__PURE__ */ _(x, {
				at: r,
				ms: 900,
				delay: 350,
				children: n.win && typeof n.amount == "number" ? /* @__PURE__ */ _(Q, {
					k: "games.lasvegas-royale.fxGain",
					params: { n: n.amount }
				}) : /* @__PURE__ */ _(Q, { k: "games.lasvegas-royale.fxJackpotUp" })
			})] })
		};
	},
	fifty(e, t) {
		let n = e.data;
		if (n?.bust) return $(t, `seat:${e.rid ?? ""}`, /* @__PURE__ */ _(Q, {
			k: "games.lasvegas-royale.fxFiftyBust",
			danger: !0
		}));
		if (n?.stop) {
			let r = n.reward;
			return typeof r == "number" && r > 0 ? $(t, `seat:${e.rid ?? ""}`, /* @__PURE__ */ _(Q, {
				k: "games.lasvegas-royale.fxGain",
				params: { n: r }
			})) : r === "chip1" ? $(t, `seat:${e.rid ?? ""}`, /* @__PURE__ */ _(Q, {
				k: "games.lasvegas-royale.fxGainChips",
				params: { n: 1 }
			})) : null;
		}
		return null;
	},
	luckyPunch(e, t) {
		let n = e.data;
		return $(t, `seat:${e.rid ?? ""}`, n?.hit ? /* @__PURE__ */ _(Q, { k: "games.lasvegas-royale.fxLuckyHit" }) : /* @__PURE__ */ _(Q, {
			k: "games.lasvegas-royale.fxLuckyMiss",
			danger: !0
		}));
	},
	primeTime(e, t) {
		let n = e.data;
		if (typeof n?.casino != "number" || !Array.isArray(n.dice)) return null;
		let r = t.anchor(`casino:${n.casino}`);
		if (!r) return null;
		let i = n.dice;
		return {
			ms: 800,
			node: /* @__PURE__ */ _(g, { children: i.map((e, t) => /* @__PURE__ */ _(S, {
				from: {
					x: r.x + r.w / 2 - 18 + t * 36,
					y: r.y - 80,
					w: 30,
					h: 30
				},
				to: {
					x: r.x + r.w / 2 - 18 + t * 36,
					y: r.y + 8,
					w: 30,
					h: 30
				},
				ms: 380,
				delay: t * 80,
				children: /* @__PURE__ */ _(q, {
					value: e,
					size: 30,
					hex: "#1f2937"
				})
			}, t)) })
		};
	},
	badLuck(e, t) {
		let n = e.data, r = Array.isArray(n?.payers) ? n.payers : [];
		return {
			ms: 1e3,
			node: /* @__PURE__ */ _(g, { children: r.map((e, n) => {
				let r = dt(t, e);
				return r ? /* @__PURE__ */ _(x, {
					at: r,
					ms: 950,
					delay: n * 120,
					children: /* @__PURE__ */ _(Q, {
						k: "games.lasvegas-royale.fxLose",
						params: { n: 50 },
						danger: !0
					})
				}, e) : null;
			}) })
		};
	},
	tile(e, t) {
		let n = e.data, r = n?.tile;
		if (typeof r != "string") return null;
		let i = typeof n?.casino == "number" ? n.casino : null, a = `seat:${e.rid ?? n?.rid ?? ""}`, o = i === null ? a : `casino:${i}`;
		switch (r) {
			case "payDay": {
				let e = typeof n?.casinos == "number" ? n.casinos : 0;
				return e <= 2 ? $(t, a, /* @__PURE__ */ _(Q, {
					k: "games.lasvegas-royale.fxGainChips",
					params: { n: e }
				})) : $(t, a, /* @__PURE__ */ _(Q, {
					k: "games.lasvegas-royale.fxGain",
					params: { n: e * 10 }
				}));
			}
			case "powerPlay": return $(t, a, n?.lost ? /* @__PURE__ */ _(Q, {
				k: "games.lasvegas-royale.fxPowerLost",
				danger: !0
			}) : /* @__PURE__ */ _(Q, { k: "games.lasvegas-royale.fxPowerTaken" }));
			case "highFive": return $(t, o, /* @__PURE__ */ _(Q, {
				k: typeof n?.amount == "number" ? "games.lasvegas-royale.fxGain" : "games.lasvegas-royale.fxHighFive",
				params: typeof n?.amount == "number" ? { n: n.amount } : void 0
			}));
			case "noEntry": return i === null ? null : $(t, `casino:${typeof n?.target == "number" ? n.target : i}`, /* @__PURE__ */ _(Q, {
				k: "games.lasvegas-royale.fxNoEntry",
				danger: !0
			}));
			case "knockout": return n?.freed ? $(t, a, /* @__PURE__ */ _(Q, { k: "games.lasvegas-royale.fxBarFreed" })) : $(t, a, /* @__PURE__ */ _(Q, {
				k: "games.lasvegas-royale.fxKnockoutIn",
				danger: !0
			}));
			case "blockIt": return typeof n?.target == "number" ? $(t, `casino:${n.target}`, /* @__PURE__ */ _(Q, {
				k: "games.lasvegas-royale.fxGrayIn",
				params: { n: n?.count ?? 0 }
			})) : null;
			case "handicap": {
				let e = typeof n?.space == "number" ? se[n.space] : void 0;
				return e === "chip1" ? $(t, a, /* @__PURE__ */ _(Q, {
					k: "games.lasvegas-royale.fxGainChips",
					params: { n: 1 }
				})) : e === 30 ? $(t, a, /* @__PURE__ */ _(Q, {
					k: "games.lasvegas-royale.fxGain",
					params: { n: 30 }
				})) : null;
			}
			case "blackBox": {
				let e = typeof n?.sum == "number" ? n.sum : 0;
				return e === 0 ? null : $(t, a, e === 20 ? /* @__PURE__ */ _(Q, {
					k: "games.lasvegas-royale.fxGainChips",
					params: { n: 2 }
				}) : /* @__PURE__ */ _(Q, {
					k: "games.lasvegas-royale.fxGain",
					params: { n: e }
				}));
			}
			case "doubleDown": {
				let e = Array.isArray(n?.awards) ? n.awards : [];
				return e.length === 0 ? null : {
					ms: 900,
					node: /* @__PURE__ */ _(g, { children: e.map((e, n) => {
						let r = dt(t, e.rid);
						return r ? /* @__PURE__ */ _(x, {
							at: r,
							ms: 850,
							delay: n * 140,
							children: /* @__PURE__ */ _(Q, {
								k: "games.lasvegas-royale.fxGain",
								params: { n: e.amount }
							})
						}, e.rid) : null;
					}) })
				};
			}
			case "niceDice": {
				let e = Array.isArray(n?.awards) ? n.awards : [];
				return e.length > 0 ? {
					ms: 900,
					node: /* @__PURE__ */ _(g, { children: e.map((e, n) => {
						let r = dt(t, e.rid);
						if (!r) return null;
						let i = e.reward === "chip1" ? 1 : e.reward === "chip2" ? 2 : 0;
						return /* @__PURE__ */ _(x, {
							at: r,
							ms: 850,
							delay: n * 140,
							children: i > 0 ? /* @__PURE__ */ _(Q, {
								k: "games.lasvegas-royale.fxGainChips",
								params: { n: i }
							}) : /* @__PURE__ */ _(Q, {
								k: "games.lasvegas-royale.fxGain",
								params: { n: e.reward }
							})
						}, `${e.rid}:${n}`);
					}) })
				} : $(t, o, /* @__PURE__ */ _(Q, { k: "games.lasvegas-royale.fxNiceDice" }));
			}
			case "myChoice": return n?.gold ? $(t, a, /* @__PURE__ */ _(Q, { k: "games.lasvegas-royale.fxGold" })) : typeof n?.amount == "number" ? $(t, a, /* @__PURE__ */ _(Q, {
				k: "games.lasvegas-royale.fxGain",
				params: { n: n.amount }
			})) : null;
			case "primeTime": return null;
			case "returnDie": return $(t, a, /* @__PURE__ */ _(Q, { k: "games.lasvegas-royale.fxReturnDie" }));
			case "passChip": return $(t, a, /* @__PURE__ */ _(Q, {
				k: "games.lasvegas-royale.fxGainChips",
				params: { n: -1 },
				danger: !0
			}));
			case "forfeit": return $(t, a, /* @__PURE__ */ _(Q, {
				k: "games.lasvegas-royale.fxBusted",
				danger: !0
			}));
			case "badLuck":
			case "luckyPunch": return null;
			default: return null;
		}
	},
	win() {
		return {
			ms: 600,
			node: /* @__PURE__ */ _(b, {
				ms: 600,
				className: "bg-warn"
			})
		};
	}
};
//#endregion
//#region src/games/lasvegas-royale/game-over-row.tsx
function ht({ public: e, rid: t }) {
	let n = r(), i = e.players.find((e) => e.rid === t);
	return i ? /* @__PURE__ */ v("div", {
		className: "mt-1 flex items-center gap-1.5 text-xs font-bold text-ink-soft",
		children: [/* @__PURE__ */ _("span", {
			className: "grid size-5 place-items-center rounded border border-ink bg-warn-soft font-display text-warn-ink",
			"aria-hidden": !0,
			children: "◆"
		}), /* @__PURE__ */ _("span", {
			className: "font-mono tabular-nums",
			children: n("games.lasvegas-royale.notesLine", { n: i.notes + i.chips })
		})]
	}) : null;
}
//#endregion
//#region src/games/lasvegas-royale/game-over.tsx
function gt(e) {
	return /* @__PURE__ */ _(m, {
		adaptive: !0,
		scroll: !1,
		className: "lvr-over-screen",
		children: /* @__PURE__ */ _("div", {
			className: "lvr-over-content",
			style: { "--lvr-over-count": Math.max(1, e.result.ranking.length) },
			children: /* @__PURE__ */ _(T, {
				hintCount: e.hintCount,
				result: e.result,
				members: e.members,
				myRid: e.myRid,
				accent: E.accent,
				onPlayAgain: e.onPlayAgain,
				onBackToLobby: e.onBackToLobby,
				renderRowExtra: (t) => /* @__PURE__ */ _(ht, {
					public: e.public,
					rid: t,
					myRid: e.myRid
				})
			})
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/lasvegas-royale/entry.tsx
var _t = {
	definition: Le,
	View: Re,
	bot: ct,
	describe: ut,
	fx: mt,
	OverView: gt,
	RowView: ht,
	locales: {
		zh: {
			name: "拉斯维加斯:豪华版",
			desc: "掷骰占据赌场,善用板块效果,三轮后现金最多者获胜",
			rules: "目标:三轮结束后现金最多者获胜,每枚剩余筹码计 $10k。\n· 现金总额相同时比较钞票与筹码的总张数,仍平则并列获胜。\n准备:\n· 六家赌场成对配发钞票,总值较高的一对放 6 号场。\n· 每人 7 颗小骰、1 颗大骰(计 2 颗)与 2 枚筹码。\n· 每轮随机翻 3 块板块,置于 1 至 3 号场旁。\n流程:\n· 轮到你时掷出全部剩余骰,选择一个点数,将该点数的所有骰子放上对应赌场。\n· 掷骰后可花 1 枚筹码跳过本次放置;没有剩余骰子的玩家自动跳过。\n· 全员放完后,自 1 号场起逐家结算。\n结算:\n· 在同一赌场放置相同数量骰子的玩家均退出该赌场的钞票分配;其余按骰数从多到少依次取走钞票。\n· 灰骰假想玩家分得的钞票放回钞票堆底;未分出的钞票也放回堆底。\n· 每轮补发 2 枚筹码;下一轮由 1 号场高值钞票得主先手。\n板块(向 1-3 号场放骰即激活,每次放置仅触发一次):\n幸运拳：\n暗握 1 至 3 枚标记,由左手边玩家猜测枚数。其猜错时你按枚数领奖:1 枚对应 2 枚筹码,2 枚对应 $30k,3 枚对应 $40k。猜中则无事发生。\n\n头奖：\n掷 2 颗黑骰,掷出 7 点或对子即取走累积金并将其复位至 $30k。否则累积金增加 $10k,上限 $80k。\n\n黄金时刻：\n本场结算时,赢家先掷 2 颗黑骰,可将其中任意颗放入对应点数的赌场。被封锁的赌场放不进,该黑骰作废;黑骰计入其骰数后再结算本场。\n\n对半赌：\n掷 2 颗黑骰使计数器沿轨道前进一格。轨道依次为:起点 → $0 → 1 筹码 → $30k → $40k → $60k。可随时停止并领取当前格奖励;也可押「大」或「小」再掷。押中则再进一格并可继续;押错(含与上次同点)则空手离开;到达末格后强制停止。\n\n击掌：\n首位在本场累计放满 5 颗骰子(大骰计 2 颗)的玩家获得标记。结算时持标记者无条件获得 $100k。\n\n霉运：\n本轮全部赌场结算完毕后,本场骰数最少的玩家(含未放骰者)各向银行支付 $50k。现金不足时以筹码按 $10k 抵付,银行找零但不找筹码。\n\n发薪日：\n按含己方骰子的赌场数量(含本场)乘以 $10k 领奖。应得 $10k 或 $20k 时改发 1 或 2 枚筹码。\n\n强攻：\n放置骰子后,若你在本场单独持有多数,获得强攻标记。多数判定包括灰骰假想玩家在内的每一方。持标记者在自己的回合可放弃掷骰,改为将一颗剩余骰转为自选点数放入对应赌场,并触发该场板块。本场不再存在单独多数时,标记立即归还板块。\n\n禁止入内：\n将封锁标记移至另一家赌场(永远不能封锁本板块所在的赌场)。被封锁的赌场不可增删骰子。移动后沿轨道推进一格并领取对应奖励(起点与空格无奖励),也可选择不移动,但无奖励。\n\n击倒：\n每位对手将一颗剩余骰放入禁闭区(每人至多 2 颗,已满者跳过)。你取回自己在禁闭区的全部骰子;禁闭区中的骰子不参与结算,本轮结束时归还。\n\n封锁：\n开局将 9 颗灰骰分成 5 簇(两簇各 1 颗、两簇各 2 颗、一簇 3 颗)。将其中一簇放入任一赌场,充当一名假想玩家;灰骰入场不触发板块。\n\n让分：\n将任一赌场的一颗灰骰移至板块上的空闲奖励格领取奖励。奖励格内容:第 2 格为 1 枚筹码、第 3 格为 $30k。第 4 格提供以下两种奖励，可以选择一种，也可以放弃：\n· 将一颗剩余骰子改为自选点数，并放入对应赌场，不触发板块。\n· 从任一赌场收回自己的一颗骰子。\n\n黑箱：\n6 枚标记的面值为 3 枚空白、2 枚 $20k、1 枚 $60k。赢家左手边的玩家将其分成两堆,赢家在不知内容的情况下选取一堆并获得其总额。总额不足 $30k 时改发筹码;此奖励之外,赢家照常取得本场的高值钞票。\n\n加倍：\n可将本场的任意己方骰子移入加倍区。加倍区视为独立赌场单独结算,平局消除后首名获得 $60k、次名获得 $30k。\n\n佳骰：\n可将刚掷出的一颗骰子按点数放上板块的对应格。格位被占时,原骰送往其点数对应的赌场(不触发板块);板块上的骰子不计入赌场胜负。结算时按格位领奖:1 点对应 1 枚筹码,2 点对应 2 枚筹码。点数为 3、4、5、6 时，分别获得 $30k、$40k、$50k、$60k。\n\n任选：\n掷 2 颗黑骰并择一执行。点数为 1 时，获得一枚筹码；点数为 2 时，获得两枚筹码；点数为 3 时，获得 $30k。4 点:激活另一块在场板块(不产生放骰行为)。5 点:将一颗剩余骰转为自选点数放入对应赌场,或收回一颗己方骰子。6 点:将一颗剩余骰放上金格(被占时原骰归还物主),结算时取回该骰并获得 $60k。",
			roundShort: "第 {{n}}/{{total}} 轮",
			tableTitle: "ROYAL TABLE",
			cashTable: "CASH TABLE",
			tableMotto: "— 现金入桌 · 好运开场 —",
			diceWell: "骰池",
			casinoMiracle: "Miracle",
			casinoKings: "Kings",
			casinoMarina: "Marina",
			casinoQueen: "Queen",
			casinoCleopatra: "Cleopatra",
			casinoSunset: "Sunset",
			cashedOut: "奖金已发放",
			emptyWagers: "待下注",
			selected: "已选",
			selectedCasino: "已选 {{n}} 号赌场",
			legalCount: "可放 ×{{n}}",
			chooseTarget: "可选目标",
			resolving: "开奖中",
			settled: "已结算",
			tileDetailsAria: "查看{{name}}板块说明",
			yourTurn: "你的回合",
			confirmTip: "确认前可改选赌场",
			remainingDice: "剩余 {{small}} 小骰 + {{big}} 大骰",
			tileWillTrigger: "{{name}}板块将触发",
			tapLegalTip: "点亮的赌场可放置",
			rolledDice: "本次掷出的骰子",
			reselect: "重选",
			confirmPlace: "确认放置 ×{{n}}",
			placeSummary: "{{value}} 点全部放置 · 有效 {{n}} 颗",
			dieOptionAria: "把 {{value}} 点{{kind}}放到佳骰板块",
			primeTimeDieAria: "切换 {{value}} 点黑骰是否放入赌场",
			blackBoxTokenAria: "{{value}}k 标记,当前在 {{pile}} 堆",
			selectTargetOnTable: "再点牌桌上亮起的目标赌场",
			chooseClusterFirst: "先选一簇灰骰",
			chooseRewardFirst: "先选一个奖励格",
			selectGrayCasino: "再点有灰骰的赌场",
			selectOwnCasino: "点亮自己有骰子的赌场",
			blackBoxPiles: "A 堆 {{a}} 枚 · B 堆 {{b}} 枚",
			fiftyLastSum: "上一掷合计 {{n}} 点",
			noEntryNextReward: "移动后奖励：{{reward}}",
			handicapRewardAria: "奖励格 {{n}}：{{reward}}",
			moneyShort: "${{n}}k",
			chips: "筹码",
			chipsCount: "筹码 ×{{n}}",
			notesLine: "票据与筹码共 {{n}} 件",
			bigDie: "大骰",
			smallDie: "小骰",
			roll: "掷骰",
			rollPrompt: "轮到你 · 掷出剩余 {{n}} 颗骰子",
			rollHint: "掷出全部剩余骰，再选择对应赌场",
			selectedHint: "可重选赌场；确认后放入所有同点骰",
			pendingHint: "按提示完成板块效果，目标赌场会亮起",
			payoutHint: "请观看结算，下一家赌场即将亮灯",
			payoutFlow: "钞票将从牌桌发往赢家席位",
			passChip: "花 1 枚筹码跳过",
			forfeit: "所有点数均被封锁,弃置本次骰子",
			placePrompt: "选择赌场 · 再确认放置",
			casinoAria: "{{n}} 号 {{name}} 赌场",
			placeDiceAria: "选择 {{value}} 号 {{name}} 赌场,放入本次同点骰,有效 {{count}} 颗",
			waitingRoll: "等待 {{name}} 掷骰…",
			waitingPlace: "等待 {{name}} 选择点数…",
			waitingPending: "等待 {{name}} 决定…",
			waitingOthers: "等待其他玩家行动…",
			payout: "正在逐家结算赌场…",
			payoutCasino: "正在结算 {{n}} 号赌场",
			blockedBadge: "封锁",
			grayName: "灰骰",
			tileLuckyPunch: "幸运拳",
			tileJackpot: "头奖",
			tilePrimeTime: "黄金时刻",
			tileFiftyFifty: "对半赌",
			tileHighFive: "击掌",
			tileBadLuck: "霉运",
			tilePayDay: "发薪日",
			tilePowerPlay: "强攻",
			tileNoEntry: "禁止入内",
			tileKnockout: "击倒",
			tileBlockIt: "封锁",
			tileHandicap: "让分",
			tileBlackBox: "黑箱",
			tileDoubleDown: "加倍",
			tileNiceDice: "佳骰",
			tileMyChoice: "任选",
			tileDescLuckyPunch: "暗握 1 至 3 枚标记,由左手边玩家猜测枚数;其猜错时你按枚数领奖(1 枚→2 枚筹码,2 枚→$30k,3 枚→$40k),猜中则无事发生。",
			tileDescJackpot: "掷 2 颗黑骰,掷出 7 点或对子即取走累积金并将其复位至 $30k;否则累积金增加 $10k,上限 $80k。",
			tileDescPrimeTime: "本场结算时,赢家先掷 2 颗黑骰,可将其中任意颗放入对应点数的赌场(被封锁的赌场放不进,该黑骰作废),黑骰计入其骰数后再结算本场。",
			tileDescFiftyFifty: "掷 2 颗黑骰使计数器沿轨道前进一格(起点 → $0 → 1 筹码 → $30k → $40k → $60k),可随时停止并领取当前格奖励;也可押「大」或「小」再掷,押中则再进一格并可继续,押错(含与上次同点)则空手离开;到达末格后强制停止。",
			tileDescHighFive: "首位在本场累计放满 5 颗骰子(大骰计 2 颗)的玩家获得标记;结算时持标记者无条件获得 $100k。",
			tileDescBadLuck: "本轮全部赌场结算完毕后,本场骰数最少的玩家(含未放骰者)各向银行支付 $50k;现金不足时以筹码按 $10k 抵付,银行找零但不找筹码。",
			tileDescPayDay: "按含己方骰子的赌场数量(含本场)乘以 $10k 领奖;应得 $10k 或 $20k 时改发 1 或 2 枚筹码。",
			tileDescPowerPlay: "放置骰子后,若你在本场单独持有多数(多于包括灰骰假想玩家在内的任何其他一方),获得强攻标记。持标记者在自己的回合可放弃掷骰,改为将一颗剩余骰转为自选点数放入对应赌场,并触发该场板块;本场不再存在单独多数时,标记立即归还板块。",
			tileDescNoEntry: "将封锁标记移至另一家赌场(永远不能封锁本板块所在的赌场),被封锁的赌场不可增删骰子;移动后沿轨道推进一格并领取对应奖励(起点与空格无奖励),也可以选择不移动,但无奖励。",
			tileDescKnockout: "每位对手将一颗剩余骰放入禁闭区(每人至多 2 颗,已满者跳过),你取回自己在禁闭区的全部骰子;禁闭区中的骰子不参与结算,本轮结束时归还。",
			tileDescBlockIt: "开局将 9 颗灰骰分成 5 簇(两簇各 1 颗、两簇各 2 颗、一簇 3 颗);将其中一簇放入任一赌场,充当一名假想玩家;灰骰入场不触发板块。",
			tileDescHandicap: "将任一赌场的一颗灰骰移至板块上的空闲奖励格领取奖励:第 2 格为 1 枚筹码、第 3 格为 $30k;第 4 格为二选一——将一颗剩余骰转为自选点数放入对应赌场(不触发板块),或从任一赌场收回自己的一颗骰子;也可以放弃奖励。",
			tileDescBlackBox: "6 枚标记的面值为 3 枚空白、2 枚 $20k、1 枚 $60k;赢家左手边的玩家将其分成两堆,赢家在不知内容的情况下选取一堆并获得其总额(总额不足 $30k 时改发筹码);此奖励之外,赢家照常取得本场的高值钞票。",
			tileDescDoubleDown: "可将本场的任意己方骰子移入加倍区;加倍区视为独立赌场单独结算,平局消除后首名得 $60k、次名得 $30k。",
			tileDescNiceDice: "可将刚掷出的一颗骰子按点数放上板块的对应格;格位被占时,原骰送往其点数对应的赌场(不触发板块);板块上的骰子不计入赌场胜负;结算时按格位领奖(1 点→1 枚筹码,2 点→2 枚筹码,3 至 6 点→$30k/$40k/$50k/$60k)。",
			tileDescMyChoice: "掷 2 颗黑骰并择一执行:1. 获得 1 枚筹码;2. 获得 2 枚筹码;3. 获得 $30k;4. 激活另一块在场板块(不产生放骰行为);5. 将一颗剩余骰转为自选点数放入对应赌场,或收回一颗己方骰子;6. 将一颗剩余骰放上金格(被占时原骰归还物主),结算时取回该骰并获得 $60k。",
			luckyPickPrompt: "暗握 1-3 枚标记,由 {{name}} 猜测",
			luckyGuessPrompt: "{{name}} 暗握了几枚?",
			fiftyStop: "停止并领取",
			fiftyBetHigh: "押大再掷",
			fiftyBetLow: "押小再掷",
			fiftyPosReward: "当前格:{{reward}}",
			noEntryPrompt: "将封锁标记移至另一家赌场",
			noEntryStay: "留在原位",
			knockoutPrompt: "选择一颗剩余骰放入禁闭区",
			blockItPrompt: "选择一簇灰骰,放入一家赌场",
			handicapPrompt: "将一家赌场的一颗灰骰移至奖励格",
			handicapSkip: "放弃奖励",
			handicapChoicePrompt: "请选择一项奖励",
			handicapRotateAction: "转点放置",
			handicapReturnAction: "收回己骰",
			doubleDownPrompt: "将本场的任意己方骰子移至加倍区",
			doubleDownConfirm: "移入骰力 {{n}}",
			niceDicePrompt: "将一颗骰子放上对应点数格",
			niceSkip: "跳过",
			myChoicePrompt: "选择一个黑骰点数执行",
			myChoiceOpt1: "+1 筹码",
			myChoiceOpt2: "+2 筹码",
			myChoiceOpt3: "+$30k",
			myChoiceOpt4: "激活另一板块",
			myChoiceOpt5: "转点放置或收回己骰",
			myChoiceOpt6: "骰子放上金格(结算 $60k)",
			myTilePrompt: "选择要激活的板块",
			myRotateOrReturnPrompt: "将剩余骰转点放置,或收回一颗己方骰子",
			myGoldPrompt: "将一颗剩余骰放上金格",
			primeTimePrompt: "选择黑骰是否放入对应赌场",
			blackBoxSplitPrompt: "点选标记分成两堆,供 {{name}} 选择",
			blackBoxPickPrompt: "选择其中一堆",
			pickBig: "大骰",
			pickSmall: "小骰",
			confirm: "确定",
			close: "关闭",
			fxGain: "+${{n}}k",
			fxLose: "-${{n}}k",
			fxGainChips: "+{{n}} 筹码",
			fxBusted: "平局全撤",
			fxJackpotWin: "赢得头奖",
			fxJackpotUp: "头奖累积",
			fxLuckyHit: "猜中",
			fxLuckyMiss: "未猜中",
			fxFiftyBust: "猜错清零",
			fxBadLuck: "霉运付款",
			fxPowerTaken: "夺得强攻标记",
			fxPowerLost: "强攻标记归还",
			fxHighFive: "击掌",
			fxBarFreed: "取回禁闭区骰子",
			fxKnockoutIn: "骰子置入禁闭区",
			fxGrayIn: "灰骰入场",
			fxDoubleDown: "加倍区结算",
			fxGold: "金格兑现",
			fxNoEntry: "赌场被封锁",
			fxNiceDice: "佳骰落位",
			fxReturnDie: "收回骰子",
			describeRoll: "掷骰",
			describePassChip: "花筹码跳过",
			describePlace: "将 {{count}} 颗 {{value}} 点放上 {{value}} 号赌场",
			describeForfeit: "弃置本次骰子",
			describePowerPlace: "强攻:将一颗骰转为 {{value}} 点放置",
			describeLuckyPick: "暗握 {{n}} 枚标记",
			describeLuckyGuess: "猜 {{n}} 枚",
			describeFiftyStop: "对半赌停止",
			describeFiftyBet: "对半赌押注",
			describeNoEntry: "封锁 {{n}} 号赌场",
			describeKnockout: "将一颗骰放入禁闭区",
			describeBlockIt: "将 {{n}} 颗灰骰放入 {{c}} 号赌场",
			describeHandicap: "移动灰骰领奖",
			describeHandicapSkip: "放弃让分奖励",
			describeHandicapRotate: "转点放置",
			describeHandicapReturn: "收回骰子",
			describeDoubleDown: "将 {{n}} 颗骰移入加倍区",
			describeNiceDice: "骰子放上佳骰板块",
			describeNiceSkip: "放弃佳骰",
			describeMyChoice: "任选:执行 {{value}} 点奖励",
			describeMyTile: "激活另一板块",
			describeMyRotate: "转点放置",
			describeMyReturn: "收回骰子",
			describeMyGold: "骰子上金格",
			describePrimeTime: "黄金时刻加放黑骰",
			describeBlackBoxSplit: "黑箱分堆",
			describeBlackBoxPick: "黑箱选堆",
			errNotYourTurn: "现在轮不到你",
			errBadValue: "这次没掷出这个点数",
			errBlocked: "该赌场已被封锁",
			errNoChip: "筹码不足",
			errBadChoice: "无效选择"
		},
		en: {
			name: "Las Vegas Royale",
			desc: "Roll dice for casino majorities with action tiles; the richest player after three rounds wins",
			rules: "Goal: after three rounds, the richest player wins; each leftover chip counts $10k.\n· Money ties break on banknote-plus-chip count, then shared.\nSetup:\n· Deal paired banknotes to the six casinos (the richest pair to casino 6).\n· Each player takes 7 small dice, 1 big die (counts as 2) and 2 chips.\n· Each round, 3 random tiles flip beside casinos 1-3.\nPlay:\n· On your turn roll all remaining dice, choose one value and place every die of it on the matching casino.\n· After rolling you may pay 1 chip to skip the placement; out of dice means pass.\n· Once everyone is done, casinos pay out from 1 to 6.\nPayout:\n· Players tied on dice count are all eliminated; the rest take banknotes in descending dice order.\n· The gray dummy’s take returns under the pile; unawarded notes also return to the pile bottom.\n· Each round adds 2 chips; the next round starts with casino 1’s top-card winner.\nTiles (placing dice on casinos 1-3 activates them, once per placement):\nLucky Punch:\nSecretly hold 1-3 tokens; your left neighbor guesses the count. On a wrong guess you collect by count: 1 token pays 2 chips, 2 pay $30k, 3 pay $40k. A correct guess gains nothing.\n\nJackpot:\nRoll the 2 black dice; a total of 7 or doubles takes the jackpot and resets it to $30k. Otherwise the jackpot rises by $10k, up to $80k.\n\nPrime Time:\nWhen this casino pays out, the winner first rolls the 2 black dice and may place any of them on the casinos matching their values. A blocked casino cannot take one (that die is lost); the black dice then count as theirs for this payout.\n\nFifty Fifty:\nRoll the 2 black dice to advance the marker one space. The track runs: Start → $0 → 1 chip → $30k → $40k → $60k. Stop anytime to collect the current space, or bet higher/lower and roll again. Win to advance once more and continue; lose (a tie included) and leave empty-handed; the last space forces a stop.\n\nHigh Five:\nThe first player to have 5 dice here in total (the big die counts as 2) takes the token. Its holder gains $100k at payout, unconditionally.\n\nBad Luck:\nAfter all casinos have paid out, the player(s) with the fewest dice here — zero included — each pay the bank $50k. Chips cover shortfalls at $10k apiece, with change given in cash only.\n\nPay Day:\nGain $10k per casino holding your dice, this one included. A yield of $10k or $20k is paid as 1 or 2 chips instead.\n\nPower Play:\nAfter placing, if you alone hold the majority here, take the token. The gray dummy counts as a rival side for majority. While holding it, your turn may forgo rolling to place one remaining die on a value of your choice, triggering that casino’s tile. The token returns the moment no sole majority remains.\n\nNo Entry:\nMove the block token to another casino (never the one holding this tile). A blocked casino takes no dice in or out. Then advance one track space and collect its reward (start and blank spaces pay nothing); you may leave the token in place for no reward.\n\nKnockout:\nEach opponent places one remaining die into the bar (at most 2 per player; those already full are skipped). You retrieve all of your own barred dice; barred dice do not count at payout and return at the end of the round.\n\nBlock It:\nThe 9 gray dice start in 5 clusters (two of 1, two of 2, one of 3). Place one cluster on any casino, where it plays as a dummy player; gray dice never trigger tiles.\n\nHandicap:\nMove a gray die from any casino onto a free reward space of the tile to collect. Reward spaces: space 2 pays 1 chip, space 3 pays $30k. Space 4 offers either of these rewards; you may also decline the reward:\n· Place one remaining die on a value of your choice without triggering a tile.\n· Retrieve one of your dice from any casino.\n\nBlack Box:\nThe 6 tokens are three blanks, two $20k and one $60k. The winner’s left neighbor splits them into two piles; the winner picks one pile without seeing the contents and gains its total. Totals under $30k pay in chips; the winner still takes the casino’s top banknote as usual.\n\nDouble Down:\nYou may move any of your dice here onto the Double Down area. It pays out as a casino of its own: after ties are removed, first place gains $60k and second $30k.\n\nNice Dice:\nYou may park one die you have just rolled on the space matching its value. If the space is taken, the previous die moves to the casino of its value (no tile triggered); dice on the tile do not count toward the casino majority. At payout each space pays: 1 point → 1 chip, 2 points → 2 chips. Spaces 3, 4, 5 and 6 pay $30k, $40k, $50k and $60k respectively.\n\nMy Choice:\nRoll the 2 black dice and execute one result. A result of 1 gives one chip; a result of 2 gives two chips; a result of 3 gives $30k. 4: activate another tile in play (no dice placed). 5: place one remaining die on a value of your choice, or retrieve one of your dice. 6: place one remaining die on the gold space (an occupant returns to its owner), retrieving it with $60k at payout.",
			roundShort: "Round {{n}}/{{total}}",
			tableTitle: "ROYAL TABLE",
			cashTable: "CASH TABLE",
			tableMotto: "— Cash on the table · Let the dice roll —",
			diceWell: "DICE",
			casinoMiracle: "Miracle",
			casinoKings: "Kings",
			casinoMarina: "Marina",
			casinoQueen: "Queen",
			casinoCleopatra: "Cleopatra",
			casinoSunset: "Sunset",
			cashedOut: "Paid out",
			emptyWagers: "Open table",
			selected: "Selected",
			selectedCasino: "Casino {{n}} selected",
			legalCount: "Place ×{{n}}",
			chooseTarget: "Choose target",
			resolving: "Paying out",
			settled: "Settled",
			tileDetailsAria: "Read the {{name}} tile",
			yourTurn: "Your turn",
			confirmTip: "You can change casinos before confirming",
			remainingDice: "{{small}} small + {{big}} big dice left",
			tileWillTrigger: "{{name}} tile will activate",
			tapLegalTip: "Tap a lit casino to place dice",
			rolledDice: "Dice rolled this turn",
			reselect: "Change",
			confirmPlace: "Place dice ×{{n}}",
			placeSummary: "All {{value}}s · strength {{n}}",
			dieOptionAria: "Place the {{value}} {{kind}} on Nice Dice",
			primeTimeDieAria: "Toggle placing the black die showing {{value}}",
			blackBoxTokenAria: "{{value}}k token, currently in pile {{pile}}",
			selectTargetOnTable: "Now tap a lit casino on the table",
			chooseClusterFirst: "First choose a gray-dice cluster",
			chooseRewardFirst: "First choose a reward space",
			selectGrayCasino: "Now tap a casino with gray dice",
			selectOwnCasino: "Tap a lit casino holding your dice",
			blackBoxPiles: "Pile A {{a}} · Pile B {{b}}",
			fiftyLastSum: "Last total: {{n}}",
			noEntryNextReward: "Reward after moving: {{reward}}",
			handicapRewardAria: "Reward space {{n}}: {{reward}}",
			moneyShort: "${{n}}k",
			chips: "chips",
			chipsCount: "chips ×{{n}}",
			notesLine: "{{n}} banknotes and chips total",
			bigDie: "big die",
			smallDie: "small die",
			roll: "Roll",
			rollPrompt: "Your turn · Roll {{n}} remaining dice",
			rollHint: "Roll all remaining dice, then choose a casino",
			selectedHint: "You can reselect; confirm to place all matching dice",
			pendingHint: "Complete the tile action; eligible casinos light up",
			payoutHint: "Watch the payout; the next casino lights up soon",
			payoutFlow: "Cash moves from the table to winning seats",
			passChip: "Pay 1 chip to skip",
			forfeit: "All values blocked — discard this roll",
			placePrompt: "Choose a casino · Then confirm placement",
			casinoAria: "Casino {{n}}, {{name}}",
			placeDiceAria: "Select casino {{value}}, {{name}}, for dice showing {{value}}, strength {{count}}",
			waitingRoll: "Waiting for {{name}} to roll…",
			waitingPlace: "Waiting for {{name}} to pick a value…",
			waitingPending: "Waiting for {{name}} to decide…",
			waitingOthers: "Waiting for other players…",
			payout: "Paying out the casinos…",
			payoutCasino: "Paying out casino {{n}}",
			blockedBadge: "Blocked",
			grayName: "Gray",
			tileLuckyPunch: "Lucky Punch",
			tileJackpot: "Jackpot",
			tilePrimeTime: "Prime Time",
			tileFiftyFifty: "Fifty Fifty",
			tileHighFive: "High Five",
			tileBadLuck: "Bad Luck",
			tilePayDay: "Pay Day",
			tilePowerPlay: "Power Play",
			tileNoEntry: "No Entry!",
			tileKnockout: "Knockout?",
			tileBlockIt: "Block It!",
			tileHandicap: "Handicap",
			tileBlackBox: "Black Box",
			tileDoubleDown: "Double Down",
			tileNiceDice: "Nice Dice",
			tileMyChoice: "My Choice",
			tileDescLuckyPunch: "Secretly hold 1-3 tokens; your left neighbor guesses the count. On a wrong guess you collect by count (1 → 2 chips, 2 → $30k, 3 → $40k); a correct guess gains nothing.",
			tileDescJackpot: "Roll the 2 black dice. A total of 7 or doubles takes the jackpot and resets it to $30k; otherwise the jackpot rises by $10k, up to $80k.",
			tileDescPrimeTime: "When this casino pays out, the winner first rolls the 2 black dice and may place any of them on the casinos matching their values (a blocked casino cannot take one; that die is lost); the black dice then count as theirs for this payout.",
			tileDescFiftyFifty: "Roll the 2 black dice to advance the marker one space (Start → $0 → 1 chip → $30k → $40k → $60k). Stop anytime to collect the current space, or bet higher/lower and roll again: win to advance once more and continue, lose (a tie included) and leave empty-handed; the last space forces a stop.",
			tileDescHighFive: "The first player to have 5 dice here in total (the big die counts as 2) takes the token; its holder gains $100k at payout, unconditionally.",
			tileDescBadLuck: "After all casinos have paid out, the player(s) with the fewest dice here — zero included — each pay the bank $50k; chips cover shortfalls at $10k apiece, with change given in cash only.",
			tileDescPayDay: "Gain $10k per casino holding your dice, this one included; a yield of $10k or $20k is paid as 1 or 2 chips instead.",
			tileDescPowerPlay: "After placing, if you alone hold the majority here (ahead of every other side, the gray dummy included), take the token. While holding it, your turn may forgo rolling to place one remaining die on a value of your choice, triggering that casino’s tile; the token returns the moment no sole majority remains.",
			tileDescNoEntry: "Move the block token to another casino (never the one holding this tile); a blocked casino takes no dice in or out. Then advance one track space and collect its reward (start and blank spaces pay nothing); you may leave the token in place for no reward.",
			tileDescKnockout: "Each opponent places one remaining die into the bar (at most 2 per player; those already full are skipped), and you retrieve all of your own barred dice. Barred dice do not count at payout and return at the end of the round.",
			tileDescBlockIt: "The 9 gray dice start in 5 clusters (two of 1, two of 2, one of 3). Place one cluster on any casino, where it plays as a dummy player; gray dice never trigger tiles.",
			tileDescHandicap: "Move a gray die from any casino onto a free reward space of the tile to collect: space 2 pays 1 chip, space 3 pays $30k; space 4 offers a choice between placing one remaining die on a value of your choice (no tile triggered) and retrieving one of your dice from any casino. You may decline the reward.",
			tileDescBlackBox: "The 6 tokens are three blanks, two $20k and one $60k. The winner’s left neighbor splits them into two piles; the winner picks one pile without seeing the contents and gains its total (totals under $30k pay in chips). The winner still takes the casino’s top banknote as usual.",
			tileDescDoubleDown: "You may move any of your dice here onto the Double Down area, which pays out as a casino of its own: after ties are removed, first place gains $60k and second $30k.",
			tileDescNiceDice: "You may park one die you have just rolled on the space matching its value; if the space is taken, the previous die moves to the casino of its value (no tile triggered). Dice on the tile do not count toward the casino majority. At payout each space pays: 1 → 1 chip, 2 → 2 chips, 3-6 → $30k/$40k/$50k/$60k.",
			tileDescMyChoice: "Roll the 2 black dice and execute one result: 1. gain 1 chip; 2. gain 2 chips; 3. gain $30k; 4. activate another tile in play (no dice placed); 5. place one remaining die on a value of your choice, or retrieve one of your dice; 6. place one remaining die on the gold space (an occupant returns to its owner), retrieving it with $60k at payout.",
			luckyPickPrompt: "Secretly hold 1-3 tokens for {{name}} to guess",
			luckyGuessPrompt: "How many is {{name}} holding?",
			fiftyStop: "Stop and collect",
			fiftyBetHigh: "Bet higher",
			fiftyBetLow: "Bet lower",
			fiftyPosReward: "Current: {{reward}}",
			noEntryPrompt: "Move the block token to another casino",
			noEntryStay: "Leave it in place",
			knockoutPrompt: "Bar one of your remaining dice",
			blockItPrompt: "Pick a gray cluster and a target casino",
			handicapPrompt: "Move a gray die onto a reward space",
			handicapSkip: "Skip reward",
			handicapChoicePrompt: "Choose your bonus",
			handicapRotateAction: "Place die",
			handicapReturnAction: "Retrieve die",
			doubleDownPrompt: "Move any of your dice here to Double Down",
			doubleDownConfirm: "Move strength {{n}}",
			niceDicePrompt: "Park one die on its value space",
			niceSkip: "Skip",
			myChoicePrompt: "Pick one black-die value to execute",
			myChoiceOpt1: "+1 chip",
			myChoiceOpt2: "+2 chips",
			myChoiceOpt3: "+$30k",
			myChoiceOpt4: "Activate another tile",
			myChoiceOpt5: "Place/retrieve a die",
			myChoiceOpt6: "Die on the gold space ($60k)",
			myTilePrompt: "Choose a tile to activate",
			myRotateOrReturnPrompt: "Place a die on any value, or retrieve one",
			myGoldPrompt: "Park one remaining die on the gold space",
			primeTimePrompt: "Choose whether each black die is placed",
			blackBoxSplitPrompt: "Tap tokens to make two piles for {{name}}",
			blackBoxPickPrompt: "Pick a pile to keep",
			pickBig: "Big die",
			pickSmall: "Small die",
			confirm: "OK",
			close: "Close",
			fxGain: "+${{n}}k",
			fxLose: "-${{n}}k",
			fxGainChips: "+{{n}} chips",
			fxBusted: "Tie — all out",
			fxJackpotWin: "Jackpot!",
			fxJackpotUp: "Jackpot grows",
			fxLuckyHit: "Guessed right",
			fxLuckyMiss: "Guessed wrong",
			fxFiftyBust: "Bust!",
			fxBadLuck: "Bad luck payment",
			fxPowerTaken: "Power Play taken",
			fxPowerLost: "Power Play returned",
			fxHighFive: "High Five!",
			fxBarFreed: "Bar dice freed",
			fxKnockoutIn: "Die barred",
			fxGrayIn: "Gray dice enter",
			fxDoubleDown: "Double Down pays out",
			fxGold: "Gold space pays",
			fxNoEntry: "Casino blocked",
			fxNiceDice: "Nice Dice parked",
			fxReturnDie: "Die retrieved",
			describeRoll: "Roll the dice",
			describePassChip: "Pay a chip to skip",
			describePlace: "Place {{count}} dice showing {{value}} on casino {{value}}",
			describeForfeit: "Discard this roll",
			describePowerPlace: "Power Play: place a die as {{value}}",
			describeLuckyPick: "Hold {{n}} tokens",
			describeLuckyGuess: "Guess {{n}}",
			describeFiftyStop: "Fifty Fifty: stop",
			describeFiftyBet: "Fifty Fifty: bet",
			describeNoEntry: "Block casino {{n}}",
			describeKnockout: "Bar a die",
			describeBlockIt: "Drop {{n}} gray dice on casino {{c}}",
			describeHandicap: "Move a gray die for a reward",
			describeHandicapSkip: "Skip Handicap reward",
			describeHandicapRotate: "Place a die on any value",
			describeHandicapReturn: "Retrieve a die",
			describeDoubleDown: "Move {{n}} dice to Double Down",
			describeNiceDice: "Park a die on Nice Dice",
			describeNiceSkip: "Skip Nice Dice",
			describeMyChoice: "My Choice: take reward {{value}}",
			describeMyTile: "Activate another tile",
			describeMyRotate: "Place a die on any value",
			describeMyReturn: "Retrieve a die",
			describeMyGold: "Park a die on the gold space",
			describePrimeTime: "Prime Time placement",
			describeBlackBoxSplit: "Split the Black Box",
			describeBlackBoxPick: "Pick a Black Box pile",
			errNotYourTurn: "Not your turn",
			errBadValue: "You did not roll that value",
			errBlocked: "That casino is blocked",
			errNoChip: "No chip left",
			errBadChoice: "Invalid choice"
		}
	}
};
//#endregion
export { _t as default };
