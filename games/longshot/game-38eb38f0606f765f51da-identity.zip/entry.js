import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { AVATARS as n } from "@bgparty/sdk/avatars";
import { useState as r } from "react";
import { useFxAnchor as i } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as a } from "@bgparty/sdk/fx/delta-number";
import { useT as o } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as s } from "@bgparty/sdk/player-colors";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { Fragment as l, jsx as u, jsxs as d } from "react/jsx-runtime";
import { Floater as f, FlySprite as p, PulseBox as m } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as h } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as g, OptionSection as _ } from "@bgparty/sdk/ui/game-options";
//#region src/games/longshot/data.ts
var v = [
	1,
	2,
	2,
	2,
	3,
	3
], y = [
	35,
	25,
	15
], b = [
	10,
	10,
	8,
	8,
	6,
	6,
	4,
	4
], x = [
	[
		5,
		4,
		3
	],
	[
		5,
		4,
		3
	],
	[
		6,
		5,
		4
	],
	[
		6,
		5,
		4
	],
	[
		7,
		6,
		5
	],
	[
		7,
		6,
		5
	],
	[
		9,
		8,
		7
	],
	[
		9,
		8,
		7
	]
], ee = [
	"#dc2626",
	"#eab308",
	"#1d4ed8",
	"#ec4899",
	"#16a34a",
	"#38bdf8",
	"#f97316",
	"#8b5cf6"
], S = [
	!1,
	!0,
	!1,
	!1,
	!1,
	!0,
	!1,
	!1
], C = [
	8,
	3,
	5,
	6,
	4,
	7,
	1,
	2,
	2,
	8,
	6,
	3,
	7,
	1,
	4,
	5
], w = [
	"cash7",
	"cash7",
	"cash7",
	"back22",
	"bet3",
	"bet3",
	"fwd22",
	"back3",
	"fwd3",
	"helmet",
	"jersey",
	"horse"
], T = {
	cash7: "games.longshot.bonusCash7",
	back22: "games.longshot.bonusBack22",
	bet3: "games.longshot.bonusBet3",
	fwd22: "games.longshot.bonusFwd22",
	back3: "games.longshot.bonusBack3",
	fwd3: "games.longshot.bonusFwd3",
	helmet: "games.longshot.bonusHelmet",
	jersey: "games.longshot.bonusJersey",
	horse: "games.longshot.bonusHorse"
}, E = [
	{
		cells: [
			0,
			7,
			10,
			13
		],
		bets: [[2, 3], [4, 7]]
	},
	{
		cells: [
			3,
			6,
			9,
			12
		],
		bets: [[2, 2], [4, 5]]
	},
	{
		cells: [
			1,
			6,
			8,
			15
		],
		bets: [[2, 4], [4, 8]]
	},
	{
		cells: [
			3,
			5,
			8,
			14
		],
		bets: [[3, 3], [3, 5]]
	},
	{
		cells: [
			0,
			5,
			11,
			14
		],
		bets: [[2, 1], [4, 6]]
	},
	{
		cells: [
			1,
			4,
			10,
			15
		],
		bets: [[3, 1], [3, 8]]
	},
	{
		cells: [
			2,
			4,
			11,
			13
		],
		bets: [[3, 2], [3, 7]]
	},
	{
		cells: [
			2,
			7,
			9,
			12
		],
		bets: [[3, 4], [3, 6]]
	}
], D = {
	1: [
		{
			ability: "chainReaction",
			marks: [6]
		},
		{
			ability: "tooLucky",
			marks: [5]
		},
		{
			ability: "scatterShot",
			marks: [1]
		},
		{
			ability: "earlyBird",
			marks: [2]
		},
		{
			ability: "charleyHorse",
			marks: [1, 4]
		},
		{
			ability: "miracleWorker",
			marks: [2, 3]
		},
		{
			ability: "betterSafe",
			marks: [1, 3]
		},
		{
			ability: "nitroNellie",
			marks: [2, 4]
		}
	],
	2: [
		{
			ability: "rowYourBoat",
			marks: [6]
		},
		{
			ability: "makeItRain",
			marks: [5]
		},
		{
			ability: "cookTheBooks",
			marks: [1]
		},
		{
			ability: "mintCondition",
			marks: [2]
		},
		{
			ability: "bottomDollar",
			marks: [1, 4]
		},
		{
			ability: "dirtyLaundry",
			marks: [2, 3]
		},
		{
			ability: "cheerUp",
			marks: [1, 3]
		},
		{
			ability: "donutDollie",
			marks: [2, 4]
		}
	],
	3: [
		{
			ability: "strungAlong",
			marks: [6]
		},
		{
			ability: "dollarMenu",
			marks: [5]
		},
		{
			ability: "payItForward",
			marks: [1]
		},
		{
			ability: "flexYourQuads",
			marks: [2]
		},
		{
			ability: "theSting",
			marks: [1, 4]
		},
		{
			ability: "nightMare",
			marks: [2, 3]
		},
		{
			ability: "lineYourPockets",
			marks: [1, 3]
		},
		{
			ability: "purpleRein",
			marks: [2, 4]
		}
	]
}, te = {
	1: [
		"games.longshot.h1_1",
		"games.longshot.h1_2",
		"games.longshot.h1_3",
		"games.longshot.h1_4",
		"games.longshot.h1_5",
		"games.longshot.h1_6",
		"games.longshot.h1_7",
		"games.longshot.h1_8"
	],
	2: [
		"games.longshot.h2_1",
		"games.longshot.h2_2",
		"games.longshot.h2_3",
		"games.longshot.h2_4",
		"games.longshot.h2_5",
		"games.longshot.h2_6",
		"games.longshot.h2_7",
		"games.longshot.h2_8"
	],
	3: [
		"games.longshot.h3_1",
		"games.longshot.h3_2",
		"games.longshot.h3_3",
		"games.longshot.h3_4",
		"games.longshot.h3_5",
		"games.longshot.h3_6",
		"games.longshot.h3_7",
		"games.longshot.h3_8"
	]
}, ne = {
	1: [
		"games.longshot.a1_1",
		"games.longshot.a1_2",
		"games.longshot.a1_3",
		"games.longshot.a1_4",
		"games.longshot.a1_5",
		"games.longshot.a1_6",
		"games.longshot.a1_7",
		"games.longshot.a1_8"
	],
	2: [
		"games.longshot.a2_1",
		"games.longshot.a2_2",
		"games.longshot.a2_3",
		"games.longshot.a2_4",
		"games.longshot.a2_5",
		"games.longshot.a2_6",
		"games.longshot.a2_7",
		"games.longshot.a2_8"
	],
	3: [
		"games.longshot.a3_1",
		"games.longshot.a3_2",
		"games.longshot.a3_3",
		"games.longshot.a3_4",
		"games.longshot.a3_5",
		"games.longshot.a3_6",
		"games.longshot.a3_7",
		"games.longshot.a3_8"
	]
}, O = {
	id: "longshot",
	tier: "beta",
	mechanics: [
		"roll-and-write",
		"betting",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.longshot.name",
	descKey: "games.longshot.desc",
	rulesKey: "games.longshot.rules",
	icon: "🏇",
	iconImg: "games/longshot.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/longshot/en.pdf" },
	precacheAssets: [
		"race.webp",
		"board.webp",
		"horse-1.webp",
		"horse-2.webp",
		"horse-3.webp",
		"horse-4.webp",
		"horse-5.webp",
		"horse-6.webp",
		"horse-7.webp",
		"horse-8.webp"
	],
	minPlayers: 1,
	maxPlayers: 8,
	bestPlayers: [4, 5],
	accent: "#7c3aed",
	releasedAt: "2026-09-28",
	search: {
		py: "kuang ye sai ma tou zi ban",
		init: "kysmtzb"
	},
	hotseat: "open"
}, k = t.int().min(1).max(8), A = t.discriminatedUnion("type", [
	t.object({ type: t.literal("roll") }),
	t.object({
		type: t.literal("act"),
		act: t.enum([
			"concession",
			"helmet",
			"jersey",
			"bet",
			"buy",
			"pass"
		]),
		horse: k.optional(),
		cell: t.int().min(0).max(15).optional(),
		amount: t.int().min(1).max(4).optional(),
		wild: t.boolean().optional(),
		mode: t.enum([
			"cook",
			"strung",
			"lyp"
		]).optional()
	}),
	t.object({
		type: t.literal("choose"),
		bonus: t.int().min(0).max(11).optional(),
		cell: t.int().min(0).max(15).optional(),
		horse: k.optional(),
		mark: t.enum([
			"grid",
			"helmet",
			"jersey"
		]).optional(),
		parity: t.enum(["odd", "even"]).optional(),
		amount: t.int().min(0).max(4).optional(),
		skip: t.boolean().optional()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), j = t.object({ set: t.union([
	t.literal(1),
	t.literal(2),
	t.literal(3)
]).catch(1) }).default({ set: 1 }), M = t.string(), re = t.object({
	cash: t.int(),
	bets: t.array(t.int().nonnegative()).length(8),
	helmets: t.array(k),
	jerseys: t.array(k),
	grid: t.array(t.boolean()).length(16),
	lines: t.array(t.int().min(0).max(7)),
	wilds: t.int().min(0).max(3),
	card: t.int().min(0).max(7)
}), ie = t.object({
	set: t.union([
		t.literal(1),
		t.literal(2),
		t.literal(3)
	]),
	pos: t.array(t.int().min(0).max(15)).length(8),
	finished: t.array(k),
	marks: t.array(t.array(k)).length(8),
	owners: t.array(M.nullable()).length(8),
	players: t.array(t.object({
		rid: M,
		board: re
	})),
	bonusUsed: t.array(t.boolean()).length(12),
	phase: t.enum([
		"roll",
		"move",
		"act",
		"done"
	]),
	roller: M,
	actor: M.nullable(),
	dice: t.object({
		horse: k,
		move: t.int().min(1).max(3)
	}).nullable(),
	pending: t.array(t.unknown()),
	round: t.int().min(1)
}), ae = t.object({}), N = {
	roll: 1e3,
	move: 700,
	sub: 450
}, P = (e, t) => e.finished.includes(t);
function F(e, t) {
	let n = D[e.set].findIndex((e) => e.ability === t);
	return n >= 0 ? e.owners[n] : null;
}
var I = (e, t, n) => F(e, n) === t, L = (e, t) => D[e.set].findIndex((e) => e.ability === t) + 1;
function R(e) {
	let t = -1, n = 16;
	for (let r = 1; r <= 8; r++) P(e, r) || (t = Math.max(t, e.pos[r - 1]), n = Math.min(n, e.pos[r - 1]));
	return {
		front: t,
		back: n
	};
}
function z(e, t, n) {
	P(e, t) || (e.pos[t - 1] = Math.max(0, Math.min(14, e.pos[t - 1] + n)));
}
function B(e, t, n) {
	let r = e.pos[t - 1], i = r + n, a = !1;
	return i >= 15 && (i = 15, a = !0, e.finished.push(t)), e.pos[t - 1] = i, {
		from: r,
		to: i,
		cross: a
	};
}
function V(e, t, n) {
	return P(e, n) ? !1 : e.pos[n - 1] < 11 || e.boards[t].helmets.includes(n) ? !0 : n === 8 && I(e, t, "nightMare");
}
function H(e, t) {
	let n = [];
	for (let r = 0; r < 8; r++) {
		if (t.includes(r)) continue;
		let i = !0;
		for (let t = 0; t < 4; t++) if (!e[r < 4 ? r * 4 + t : t * 4 + (r - 4)]) {
			i = !1;
			break;
		}
		i && n.push(r);
	}
	return n;
}
function U(e, t, n, r) {
	let i = e.boards[t];
	i.grid[n] = !0;
	let a = H(i.grid, i.lines);
	i.lines.push(...a), r.push({
		kind: "mark",
		rid: t,
		data: { cell: n }
	});
	for (let n of a) e.bonusUsed.filter((e) => !e).length - e.pending.filter((e) => e.t === "bonus").length > 0 && e.pending.push({ t: "bonus" }), n < 4 ? (I(e, t, "rowYourBoat") && (i.cash += 2, r.push({
		kind: "money",
		rid: t,
		data: { delta: 2 }
	})), I(e, t, "charleyHorse") && e.pending.push({ t: "charley" })) : I(e, t, "chainReaction") && e.pending.push({ t: "chain" });
}
function W(e, t, n) {
	let r = e.boards[t];
	r.helmets.includes(n) && r.jerseys.includes(n) && I(e, t, "purpleRein") && e.pending.push({
		t: "pr",
		horse: n
	});
}
function oe(e, t, n) {
	e.boards[t].helmets.push(n), I(e, t, "nitroNellie") && z(e, L(e, "nitroNellie"), 1), I(e, t, "mintCondition") && e.pending.push({
		t: "mint",
		horse: n
	}), W(e, t, n);
}
function G(e, t, n) {
	e.boards[t].jerseys.push(n), e.marks[n - 1].length < 8 && e.pending.push({
		t: "jx",
		horse: n
	}), W(e, t, n);
}
function se(e, t, n) {
	let r = D[e.set][n - 1].ability;
	if (r === "miracleWorker") e.pending.push({ t: "miracle" });
	else if (r === "makeItRain") e.pending.push({ t: "mir" });
	else if (r === "nightMare") for (let n of e.players) n !== t && (e.boards[n].bets[7] = Math.max(0, e.boards[n].bets[7] - 1));
}
function ce(t, n, r) {
	let i = 0, a = [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7
	];
	for (let t = a.length - 1; t > 0; t--) {
		let n = e(r, i++, t + 1);
		[a[t], a[n]] = [a[n], a[t]];
	}
	let o = {};
	return n.forEach((e, t) => {
		let n = E[a[t]], r = Array.from({ length: 16 }, () => !1);
		for (let e of n.cells) r[e] = !0;
		let i = Array.from({ length: 8 }, () => 0);
		for (let [e, t] of n.bets) i[t - 1] = e;
		o[e] = {
			cash: 12,
			bets: i,
			helmets: [],
			jerseys: [],
			grid: r,
			lines: [],
			wilds: 3,
			card: a[t]
		};
	}), {
		state: {
			players: n,
			set: t.set,
			seed: r,
			rngCursor: i,
			pos: Array.from({ length: 8 }, () => 0),
			finished: [],
			marks: D[t.set].map((e) => [...e.marks]),
			owners: Array.from({ length: 8 }, () => null),
			boards: o,
			bonusUsed: Array.from({ length: 12 }, () => !1),
			roller: 0,
			dice: null,
			moveQueue: [],
			phase: "roll",
			beatMs: 0,
			actOffset: 0,
			pending: [],
			round: 1,
			scores: null
		},
		fx: []
	};
}
function K(e) {
	let t = {};
	for (let n of e.players) {
		let r = e.boards[n], i = r.cash;
		e.finished.forEach((t, r) => {
			e.owners[t - 1] === n && r < y.length && (i += y[r]);
		});
		for (let t = 1; t <= 8; t++) {
			let n = r.bets[t - 1];
			if (n <= 0) continue;
			let a = e.finished.indexOf(t);
			a >= 0 && a < 3 ? i += n * x[t - 1][a] : a < 0 && e.pos[t - 1] >= 11 && (i += n);
		}
		if (i += 5 * r.helmets.filter((e) => r.jerseys.includes(e)).length, I(e, n, "betterSafe") && (i += 2 * r.bets.filter((e) => e > 0).length), I(e, n, "bottomDollar")) for (let t = 1; t <= 8; t++) !P(e, t) && e.pos[t - 1] >= 11 && (i += r.bets[t - 1]);
		if (I(e, n, "flexYourQuads")) for (let t = 1; t <= 8; t++) r.bets[t - 1] > 0 && !P(e, t) && (i -= 4);
		t[n] = i;
	}
	return t;
}
function q(e) {
	e.actOffset += 1, !(e.actOffset < e.players.length) && (e.actOffset = 0, e.finished.length >= 3 ? (e.phase = "done", e.scores = K(e)) : (e.roller = (e.roller + 1) % e.players.length, e.phase = "roll", e.round += 1));
}
function le(e, t) {
	let n = e.boards[t], r = e.dice?.horse ?? 1, i = n.wilds > 0, a = I(e, t, "scatterShot"), o = (e) => e === r || i;
	for (let e = 0; e < 16; e++) if (!n.grid[e] && (o(C[e]) || a && Math.abs(C[e] - r) === 1)) return !0;
	for (let r = 1; r <= 8; r++) {
		if (o(r) && !n.helmets.includes(r)) return !0;
		let i = I(e, t, "dirtyLaundry") && n.bets[r - 1] > 0;
		if ((o(r) || i) && !n.jerseys.includes(r) || o(r) && e.owners[r - 1] === null && !P(e, r) && n.cash >= b[r - 1]) return !0;
	}
	for (let r = 1; r <= 8; r++) if (V(e, t, r) && (I(e, t, "cookTheBooks") || o(r) && (n.cash >= 1 || I(e, t, "earlyBird") && n.bets[r - 1] === 0 || I(e, t, "dollarMenu") && e.pos[r - 1] === R(e).back))) return !0;
	return !1;
}
function J(t, n, r) {
	if (n.type === "tick") {
		if (t.phase !== "move" || t.moveQueue.length === 0) return {
			state: t,
			fx: []
		};
		let e = structuredClone(t), n = e.moveQueue[0];
		if (e.moveQueue = e.moveQueue.slice(1), P(e, n.horse) && !n.main) e.beatMs = 0;
		else {
			let t = B(e, n.horse, n.steps);
			return e.beatMs = n.main ? N.move : N.sub, e.moveQueue.length === 0 && (e.phase = "act", e.beatMs = 0), {
				state: e,
				fx: [{
					kind: "move",
					data: {
						horse: n.horse,
						from: t.from,
						to: t.to,
						cross: t.cross,
						place: t.cross ? e.finished.length - 1 : -1,
						main: n.main
					}
				}]
			};
		}
		return e.moveQueue.length === 0 && (e.phase = "act"), {
			state: e,
			fx: []
		};
	}
	if (t.phase === "done") return { code: "games.longshot.errOver" };
	if (n.type === "roll") {
		if (t.phase !== "roll" || r.by !== t.players[t.roller]) return { code: "games.longshot.errNotYourTurn" };
		let n = structuredClone(t), i = n.rngCursor, a = e(n.seed, i++, 8) + 1, o = v[e(n.seed, i++, v.length)];
		n.rngCursor = i, n.dice = {
			horse: a,
			move: o
		};
		let s = [{
			kind: "roll",
			rid: r.by,
			data: {
				horse: a,
				move: o
			}
		}], c = L(n, "tooLucky");
		c > 0 && a === c && n.owners[c - 1] === r.by && (n.boards[r.by].cash += 2, s.push({
			kind: "money",
			rid: r.by,
			data: { delta: 2 },
			with: !0
		})), n.moveQueue = [], P(n, a) || n.moveQueue.push({
			horse: a,
			steps: o,
			main: !0
		});
		for (let e of [...n.marks[a - 1]].sort((e, t) => e - t)) P(n, e) || n.moveQueue.push({
			horse: e,
			steps: 1,
			main: !1
		});
		return n.beatMs = N.roll, n.moveQueue.length === 0 ? (n.phase = "act", n.actOffset = 0) : n.phase = "move", {
			state: n,
			fx: s
		};
	}
	if (t.phase !== "act") return { code: "games.longshot.errNotYourTurn" };
	let i = t.players[(t.roller + t.actOffset) % t.players.length];
	if (r.by !== i) return { code: "games.longshot.errNotYourTurn" };
	if (n.type === "choose") {
		if (t.pending.length === 0) return { code: "games.longshot.errNoPending" };
		let e = structuredClone(t), i = e.pending[0], a = e.boards[r.by], o = [];
		if (i.t === "bonus") {
			if (!e.bonusUsed.some((e) => !e)) return e.pending.shift(), e.pending.length === 0 && q(e), {
				state: e,
				fx: o
			};
			if (n.bonus === void 0 || e.bonusUsed[n.bonus]) return { code: "games.longshot.errBadChoice" };
			let t = w[n.bonus];
			e.bonusUsed[n.bonus] = !0, e.pending.shift(), o.push({
				kind: "bonus",
				rid: r.by,
				data: { bonus: n.bonus }
			}), t === "cash7" ? (a.cash += 7, o.push({
				kind: "money",
				rid: r.by,
				data: { delta: 7 },
				with: !0
			})) : e.pending.unshift({
				t: "bt",
				bonus: n.bonus,
				picked: []
			});
		} else if (i.t === "bt") {
			let t = w[i.bonus], s = t === "back22" || t === "fwd22" ? 2 : 1;
			if (n.skip) e.pending.shift();
			else {
				if (n.horse === void 0) return { code: "games.longshot.errBadChoice" };
				let c = n.horse;
				if (t === "back22" || t === "back3" || t === "fwd22" || t === "fwd3") {
					if (P(e, c) || i.picked.includes(c)) return { code: "games.longshot.errBadChoice" };
					if (i.picked.push(c), i.picked.length >= s) {
						let n = t === "back22" ? -2 : t === "fwd22" ? 2 : t === "back3" ? -3 : 3;
						for (let t of i.picked) z(e, t, n + (I(e, r.by, "donutDollie") && t === L(e, "donutDollie") ? Math.sign(n) : 0));
						e.pending.shift(), o.push({
							kind: "bonusMove",
							rid: r.by,
							data: {
								horses: i.picked,
								delta: n
							}
						});
					}
				} else if (t === "bet3") {
					if (!V(e, r.by, c)) return { code: "games.longshot.errBadChoice" };
					a.bets[c - 1] += 3, e.pending.shift(), o.push({
						kind: "bet",
						rid: r.by,
						data: {
							horse: c,
							amount: 3,
							free: !0
						}
					});
				} else if (t === "helmet") {
					if (a.helmets.includes(c)) return { code: "games.longshot.errBadChoice" };
					oe(e, r.by, c), e.pending.shift(), o.push({
						kind: "helmet",
						rid: r.by,
						data: { horse: c }
					});
				} else if (t === "jersey") {
					if (a.jerseys.includes(c)) return { code: "games.longshot.errBadChoice" };
					G(e, r.by, c), e.pending.splice(e.pending.indexOf(i), 1), o.push({
						kind: "jersey",
						rid: r.by,
						data: { horse: c }
					});
				} else {
					if (e.owners[c - 1] !== null || P(e, c)) return { code: "games.longshot.errBadChoice" };
					e.owners[c - 1] = r.by, se(e, r.by, c), e.pending.splice(e.pending.indexOf(i), 1), o.push({
						kind: "buy",
						rid: r.by,
						data: {
							horse: c,
							cost: 0
						}
					});
				}
			}
		} else if (i.t === "chain") {
			if (n.skip) e.pending.shift();
			else {
				if (n.cell === void 0 || a.grid[n.cell]) return { code: "games.longshot.errBadChoice" };
				e.pending.shift(), U(e, r.by, n.cell, o);
			}
		} else if (i.t === "charley") {
			if (n.skip) e.pending.shift();
			else {
				if (n.horse === void 0 || P(e, n.horse)) return { code: "games.longshot.errBadChoice" };
				z(e, n.horse, -1), e.pending.shift(), o.push({
					kind: "bonusMove",
					rid: r.by,
					data: {
						horses: [n.horse],
						delta: -1
					}
				});
			}
		} else if (i.t === "miracle") {
			if (n.skip) e.pending.shift();
			else if (n.mark === "grid") {
				if (n.cell === void 0 || a.grid[n.cell]) return { code: "games.longshot.errBadChoice" };
				e.pending.shift(), U(e, r.by, n.cell, o);
			} else if (n.mark === "helmet") {
				if (n.horse === void 0 || a.helmets.includes(n.horse)) return { code: "games.longshot.errBadChoice" };
				a.helmets.push(n.horse), e.pending.shift(), W(e, r.by, n.horse), o.push({
					kind: "helmet",
					rid: r.by,
					data: { horse: n.horse }
				});
			} else if (n.mark === "jersey") {
				if (n.horse === void 0 || a.jerseys.includes(n.horse)) return { code: "games.longshot.errBadChoice" };
				a.jerseys.push(n.horse), e.pending.shift(), e.pending.unshift({
					t: "jx",
					horse: n.horse
				}), W(e, r.by, n.horse), o.push({
					kind: "jersey",
					rid: r.by,
					data: { horse: n.horse }
				});
			} else return { code: "games.longshot.errBadChoice" };
		} else if (i.t === "mir") {
			if (n.parity === void 0) return { code: "games.longshot.errBadChoice" };
			let t = n.parity === "odd", i = [];
			for (let n = 1; n <= 8; n++) n % 2 == 1 === t && V(e, r.by, n) && (a.bets[n - 1] += 1, i.push(n));
			e.pending.shift(), o.push({
				kind: "bet",
				rid: r.by,
				data: {
					horses: i,
					amount: 1,
					free: !0
				}
			});
		} else if (i.t === "mint") {
			let t = n.amount ?? 0;
			if (t > 0) {
				if (t > 2 || a.cash < t) return { code: "games.longshot.errBadChoice" };
				a.bets[i.horse - 1] += t, a.cash -= t, o.push({
					kind: "bet",
					rid: r.by,
					data: {
						horse: i.horse,
						amount: t
					}
				});
			}
			e.pending.shift();
		} else if (i.t === "jx") {
			if (n.skip) e.pending.shift();
			else {
				if (n.horse === void 0 || e.marks[i.horse - 1].includes(n.horse)) return { code: "games.longshot.errBadChoice" };
				e.marks[i.horse - 1].push(n.horse), e.marks[i.horse - 1].sort((e, t) => e - t), e.pending.shift(), o.push({
					kind: "markX",
					rid: r.by,
					data: {
						horse: i.horse,
						target: n.horse
					}
				});
			}
		} else {
			let t = n.amount ?? 0;
			if (t > 0) {
				if (a.cash < t || !V(e, r.by, i.horse)) return { code: "games.longshot.errBadChoice" };
				a.bets[i.horse - 1] += t, a.cash -= t, o.push({
					kind: "bet",
					rid: r.by,
					data: {
						horse: i.horse,
						amount: t
					}
				});
			}
			e.pending.shift();
		}
		return e.pending.length === 0 && q(e), {
			state: e,
			fx: o
		};
	}
	if (t.pending.length > 0) return { code: "games.longshot.errPendingFirst" };
	let a = t.dice;
	if (!a) return { code: "games.longshot.errNotYourTurn" };
	let o = structuredClone(t), s = o.boards[r.by], c = [], l = (e) => e === a.horse ? null : s.wilds <= 0 ? { code: "games.longshot.errNoWild" } : (--s.wilds, null);
	if (n.act === "pass") {
		if (le(o, r.by)) return { code: "games.longshot.errBadChoice" };
	} else if (n.act === "concession") {
		if (n.cell === void 0 || s.grid[n.cell]) return { code: "games.longshot.errBadCell" };
		let e = C[n.cell], t = I(o, r.by, "scatterShot") && Math.abs(e - a.horse) === 1;
		if (e !== a.horse && !t) {
			let t = l(e);
			if (t) return t;
		}
		U(o, r.by, n.cell, c);
	} else if (n.act === "helmet") {
		if (n.horse === void 0 || s.helmets.includes(n.horse)) return { code: "games.longshot.errBadHorse" };
		let e = l(n.horse);
		if (e) return e;
		oe(o, r.by, n.horse), c.push({
			kind: "helmet",
			rid: r.by,
			data: { horse: n.horse }
		});
	} else if (n.act === "jersey") {
		if (n.horse === void 0 || s.jerseys.includes(n.horse)) return { code: "games.longshot.errBadHorse" };
		if (!(I(o, r.by, "dirtyLaundry") && s.bets[n.horse - 1] > 0)) {
			let e = l(n.horse);
			if (e) return e;
		}
		G(o, r.by, n.horse), c.push({
			kind: "jersey",
			rid: r.by,
			data: { horse: n.horse }
		});
	} else if (n.act === "buy") {
		if (n.horse === void 0 || o.owners[n.horse - 1] !== null || P(o, n.horse)) return { code: "games.longshot.errBadHorse" };
		let e = l(n.horse);
		if (e) return e;
		let t = b[n.horse - 1];
		if (s.cash < t) return { code: "games.longshot.errNoCash" };
		s.cash -= t, o.owners[n.horse - 1] = r.by, se(o, r.by, n.horse), c.push({
			kind: "buy",
			rid: r.by,
			data: {
				horse: n.horse,
				cost: t
			}
		});
	} else {
		if (n.horse === void 0) return { code: "games.longshot.errBadHorse" };
		let e = n.horse, t = n.amount ?? 1, i = t, a = !1;
		if (n.mode === "cook") {
			if (!I(o, r.by, "cookTheBooks")) return { code: "games.longshot.errBadChoice" };
			t = 1, i = 0;
		} else if (n.mode === "strung") {
			if (!I(o, r.by, "strungAlong") || e !== L(o, "strungAlong")) return { code: "games.longshot.errBadChoice" };
			t = 1, i = 1, a = !0;
			let n = l(e);
			if (n) return n;
		} else if (n.mode === "lyp") {
			if (!I(o, r.by, "lineYourPockets") || !C.map((t, n) => t === e && !s.grid[n] ? n : -1).filter((e) => e >= 0).some((e) => {
				let t = [...s.grid];
				return t[e] = !0, H(t, s.lines).length > 0;
			})) return { code: "games.longshot.errBadChoice" };
			t = 1, i = 0;
			let n = l(e);
			if (n) return n;
		} else {
			let n = l(e);
			if (n) return n;
			if (t === 4) {
				if (!I(o, r.by, "flexYourQuads")) return { code: "games.longshot.errBadChoice" };
			} else if (t < 1 || t > 3) return { code: "games.longshot.errBadChoice" };
			I(o, r.by, "earlyBird") && s.bets[e - 1] === 0 ? i = 0 : I(o, r.by, "dollarMenu") && t === 3 && o.pos[e - 1] === R(o).back && (i = 1);
		}
		if (!V(o, r.by, e)) return { code: "games.longshot.errNoBet" };
		if (s.cash < i) return { code: "games.longshot.errNoCash" };
		if (s.bets[e - 1] += t, s.cash -= i, c.push({
			kind: "bet",
			rid: r.by,
			data: {
				horse: e,
				amount: t,
				free: i === 0
			}
		}), a && z(o, e, 1), I(o, r.by, "cheerUp") && e === L(o, "cheerUp") && o.pos[e - 1] === R(o).back && (z(o, e, 3), c.push({
			kind: "bonusMove",
			rid: r.by,
			data: {
				horses: [e],
				delta: 3
			},
			with: !0
		})), I(o, r.by, "payItForward") && t === 3) {
			let t = o.pos[e - 1], n = [];
			for (let e = 1; e <= 8; e++) !P(o, e) && o.pos[e - 1] === t && n.push(e);
			if (n.length >= 2) {
				for (let e of n) z(o, e, 1);
				c.push({
					kind: "bonusMove",
					rid: r.by,
					data: {
						horses: n,
						delta: 1
					},
					with: !0
				});
			}
		}
		if (I(o, r.by, "theSting") && t === 3 && o.pos[e - 1] === R(o).back) {
			let { front: e } = R(o), t = [];
			for (let n = 1; n <= 8; n++) !P(o, n) && o.pos[n - 1] === e && t.push(n);
			for (let e of t) z(o, e, -1);
			t.length > 0 && c.push({
				kind: "bonusMove",
				rid: r.by,
				data: {
					horses: t,
					delta: -1
				},
				with: !0
			});
		}
	}
	return o.pending.length === 0 && q(o), {
		state: o,
		fx: c
	};
}
function Y(e) {
	return {
		public: {
			set: e.set,
			pos: e.pos,
			finished: e.finished,
			marks: e.marks,
			owners: e.owners,
			players: e.players.map((t) => ({
				rid: t,
				board: e.boards[t]
			})),
			bonusUsed: e.bonusUsed,
			phase: e.phase,
			roller: e.players[e.roller],
			actor: e.phase === "act" ? e.players[(e.roller + e.actOffset) % e.players.length] : null,
			dice: e.dice,
			pending: e.pending,
			round: e.round
		},
		private: {}
	};
}
function ue(e) {
	if (e.phase !== "done" || !e.scores) return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]), n = e.scores[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.scores[t] === n),
		ranking: t,
		scores: { ...e.scores }
	};
}
function de(e) {
	return e.phase === "move" && e.moveQueue.length > 0 ? e.beatMs : null;
}
var fe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: O,
	schemas: {
		action: A,
		publicView: ie,
		privateView: ae,
		config: j
	},
	setup: ce,
	reduce: J,
	viewFor: Y,
	status: ue,
	nextTickIn: de
}, X = [
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8
], pe = [
	"race",
	"market",
	"concession",
	"jockey",
	"rewards"
], me = (e) => `./games/longshot/${e}`;
function he({ public: e, members: t, myRid: n, send: i }) {
	let a = e, s = o(), f = a.players.find((e) => e.rid === n)?.board, p = a.phase === "roll" && a.roller === n, m = a.phase === "act" && a.actor === n, h = m ? (a.pending ?? [])[0] ?? null : null, [g, _] = r("race"), [v, y] = r(n), [x, ee] = r(1), [S, T] = r(1), [E, ne] = r(null), [O, k] = r(null), A = a.players.find((e) => e.rid === v)?.board ?? f, j = v === n, M = a.dice?.horse ?? 0, re = (e) => s(te[a.set][e - 1]), ie = (e) => t.find((t) => t.rid === e)?.name ?? e, ae = (e) => D[a.set].findIndex((t) => t.ability === e) + 1, N = (e) => {
		let t = ae(e);
		return t > 0 && a.owners[t - 1] === n;
	}, P = (e) => a.finished.includes(e), F = (e) => e === M || (f?.wilds ?? 0) > 0, I = (e) => !!(f && !P(e) && (a.pos[e - 1] < 11 || f.helmets.includes(e) || e === 8 && N("nightMare"))), L = Math.min(...a.pos.filter((e, t) => !P(t + 1))), R = (e) => {
		if (!m || h || !f || !I(e)) return !1;
		if (E === "cook") return N("cookTheBooks");
		if (!F(e)) return !1;
		if (E === "strung") return N("strungAlong") && e === ae("strungAlong") && f.cash >= 1;
		if (E === "lyp") return N("lineYourPockets") && Me(f, e);
		if (S === 4 && !N("flexYourQuads")) return !1;
		let t = N("earlyBird") && f.bets[e - 1] === 0 ? 0 : N("dollarMenu") && S === 3 && a.pos[e - 1] === L ? 1 : S;
		return f.cash >= t;
	}, z = (e) => !!(m && !h && f && !P(e) && a.owners[e - 1] === null && F(e) && f.cash >= b[e - 1]), B = (e) => !!(m && !h && f && !f.helmets.includes(e) && F(e)), V = (e) => !!(m && !h && f && !f.jerseys.includes(e) && (F(e) || N("dirtyLaundry") && f.bets[e - 1] > 0)), H = (e) => !!(m && f && !f.grid[e] && (h?.t === "chain" || h?.t === "miracle" && O === "grid" || !h && (C[e] === M || f.wilds > 0 || N("scatterShot") && Math.abs(C[e] - M) === 1))), U = (e) => {
		if (!h || !f) return !1;
		if (h.t === "bt") {
			let t = w[h.bonus];
			return t === "back22" || t === "back3" || t === "fwd22" || t === "fwd3" ? !P(e) && !h.picked.includes(e) : t === "bet3" ? I(e) : t === "helmet" ? !f.helmets.includes(e) : t === "jersey" ? !f.jerseys.includes(e) : a.owners[e - 1] === null && !P(e);
		}
		return h.t === "charley" ? !P(e) : h.t === "jx" ? !a.marks[h.horse - 1].includes(e) : h.t === "miracle" && O === "helmet" ? !f.helmets.includes(e) : h.t === "miracle" && O === "jersey" && !f.jerseys.includes(e);
	}, W = h?.t === "bt" ? w[h.bonus] : null, oe = h?.t === "bonus" ? "rewards" : h?.t === "chain" ? "concession" : h?.t === "charley" ? "race" : h?.t === "jx" ? "market" : h?.t === "miracle" ? O === "grid" || O === null ? "concession" : "jockey" : h?.t === "bt" ? W === "helmet" || W === "jersey" ? "jockey" : W === "bet3" || W === "horse" ? "market" : "race" : null, G = `${a.round}:${a.phase}:${a.roller}:${a.actor}`, [se, ce] = r(G);
	G !== se && (ce(G), y(n), ne(null), k(null), (a.phase === "roll" || a.phase === "move") && _("race"));
	let K = h ? JSON.stringify(h) : "", [q, le] = r(K);
	K !== q && (le(K), oe && _(oe));
	let J = a.phase === "move" ? "race" : g, Y = (e) => !h || !U(e) ? !1 : (h.t === "bt" || h.t === "charley" || h.t === "jx" ? i({
		type: "choose",
		horse: e
	}) : h.t === "miracle" && O && i({
		type: "choose",
		mark: O,
		horse: e
	}), !0), ue = (e) => {
		h && Y(e) || h || ee(e);
	}, de = (e, t) => {
		if (h) {
			U(e) && (h.t === "bt" && w[h.bonus] === t || h.t === "miracle" && O === t) && i({
				type: "choose",
				horse: e,
				...h.t === "miracle" ? { mark: t } : {}
			});
			return;
		}
		t === "helmet" && B(e) && i({
			type: "act",
			act: "helmet",
			horse: e,
			wild: e !== M || void 0
		}), t === "jersey" && V(e) && i({
			type: "act",
			act: "jersey",
			horse: e,
			wild: e !== M || void 0
		});
	}, fe = (e) => {
		H(e) && (h?.t === "chain" ? i({
			type: "choose",
			cell: e
		}) : h?.t === "miracle" ? i({
			type: "choose",
			mark: "grid",
			cell: e
		}) : i({
			type: "act",
			act: "concession",
			cell: e,
			wild: C[e] !== M && !(N("scatterShot") && Math.abs(C[e] - M) === 1) || void 0
		}));
	}, he = (e) => {
		R(e) && i({
			type: "act",
			act: "bet",
			horse: e,
			amount: S,
			...E ? { mode: E } : {},
			wild: E !== "cook" && e !== M || void 0
		});
	}, Z = a.phase === "roll" ? p ? s("games.longshot.yourRoll") : s("games.longshot.waitRoll", { name: ie(a.roller) }) : a.phase === "move" ? s("games.longshot.moving") : m ? s("games.longshot.yourAct", { n: M }) : s("games.longshot.waitAct", { name: ie(a.actor ?? a.roller) }), ve = !(!m || h || !f || X.some((e) => B(e) || V(e) || z(e) || R(e)) || C.some((e, t) => H(t)));
	return /* @__PURE__ */ u("div", {
		className: "ls-root h-full",
		children: /* @__PURE__ */ u(c, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ d(l, { children: [
				/* @__PURE__ */ d("div", {
					className: "ls-phase",
					children: [/* @__PURE__ */ u("span", {
						className: "ls-round",
						children: s("games.longshot.roundChip", { n: a.round })
					}), /* @__PURE__ */ u("strong", { children: Z })]
				}),
				/* @__PURE__ */ u("div", {
					className: "ls-seats",
					"aria-label": s("games.longshot.players"),
					children: t.map((e) => {
						let t = a.players.find((t) => t.rid === e.rid)?.board;
						return /* @__PURE__ */ u(ge, {
							avatar: e.avatar,
							rid: e.rid,
							name: e.name,
							colorIndex: e.colorIndex,
							board: t,
							selected: v === e.rid,
							onClick: () => y(e.rid)
						}, e.rid);
					})
				}),
				/* @__PURE__ */ u("nav", {
					className: "ls-tabs",
					"aria-label": s("games.longshot.sections"),
					children: pe.map((e) => /* @__PURE__ */ u("button", {
						type: "button",
						className: `ls-tab ${J === e ? "is-active" : ""}`,
						onClick: () => _(e),
						"aria-current": J === e ? "page" : void 0,
						children: s(e === "race" ? "games.longshot.tabRace" : e === "market" ? "games.longshot.market" : e === "concession" ? "games.longshot.actConcession" : e === "jockey" ? "games.longshot.tabJockey" : "games.longshot.bonuses")
					}, e))
				})
			] }),
			actionsHeight: "ls-actions-height",
			actions: /* @__PURE__ */ u(Ae, {
				pub: a,
				board: f,
				myRoll: p,
				myAct: m,
				pending: h,
				miracleMark: O,
				setMiracleMark: (e) => {
					k(e), e && _(e === "grid" ? "concession" : "jockey");
				},
				passAllowed: ve,
				horseName: re,
				send: i
			}),
			overlay: a.dice && a.phase === "move" ? /* @__PURE__ */ u(je, {
				horse: a.dice.horse,
				move: a.dice.move
			}) : null,
			children: /* @__PURE__ */ d("div", {
				className: `ls-stage ${J === "race" ? "ls-stage-race" : "ls-stage-board"}`,
				style: { backgroundImage: `url("${me(J === "race" ? "race.webp" : "board.webp")}")` },
				children: [
					J === "race" && /* @__PURE__ */ u(_e, {
						pub: a,
						pending: h,
						pendingHorse: U,
						chooseHorse: Y
					}),
					J === "market" && /* @__PURE__ */ u(xe, {
						pub: a,
						board: A,
						me: f,
						isMine: j,
						myAct: m,
						pending: h,
						pendingHorse: U,
						selectedHorse: x,
						selectHorse: ue,
						horseName: re,
						nameOf: ie,
						canBet: R,
						canBuy: z,
						placeBet: he,
						send: i,
						amount: S,
						setAmount: T,
						betMode: E,
						setBetMode: ne,
						ownsAbility: N
					}),
					J === "concession" && A && /* @__PURE__ */ u(Ce, {
						board: A,
						isMine: j,
						canGrid: H,
						markGrid: fe
					}),
					J === "jockey" && A && /* @__PURE__ */ u(Te, {
						board: A,
						pub: a,
						isMine: j,
						pending: h,
						pendingHorse: U,
						horseName: re,
						canHelmet: B,
						canJersey: V,
						markJockey: de,
						chooseHorse: Y
					}),
					J === "rewards" && /* @__PURE__ */ u(De, {
						pub: a,
						pending: h,
						send: i
					})
				]
			})
		})
	});
}
function ge({ avatar: e, rid: t, name: r, colorIndex: o, board: c, selected: l, onClick: f }) {
	let { ref: p } = i(`seat:${t}`);
	return /* @__PURE__ */ d("button", {
		ref: p,
		type: "button",
		className: `ls-seat ${l ? "is-active" : ""}`,
		onClick: f,
		children: [/* @__PURE__ */ u("span", {
			className: "ls-avatar",
			style: { backgroundColor: s[o % s.length].hex },
			children: /* @__PURE__ */ u("img", {
				src: n[e % n.length],
				alt: "",
				draggable: !1,
				style: {
					width: "1.75em",
					height: "1.75em",
					maxWidth: "100%",
					maxHeight: "100%",
					display: "block",
					objectFit: "contain",
					pointerEvents: "none",
					borderRadius: "inherit"
				}
			})
		}), /* @__PURE__ */ d("span", {
			className: "ls-seat-details",
			children: [/* @__PURE__ */ u("strong", { children: r }), /* @__PURE__ */ d("span", { children: [
				"◉ ",
				/* @__PURE__ */ u(a, {
					value: c?.cash ?? 0,
					className: "font-mono tabular-nums"
				}),
				" ",
				" · ",
				"★",
				c?.wilds ?? 0,
				" ",
				" · ",
				c?.lines.length ?? 0,
				"/8"
			] })]
		})]
	});
}
function Z({ h: e, size: t = "size-5 text-[9px]" }) {
	return /* @__PURE__ */ u("span", {
		className: `ls-horse-token ${t} ${S[e - 1] ? "is-dark-text" : ""}`,
		style: { backgroundColor: ee[e - 1] },
		children: e
	});
}
function _e({ pub: e, pending: t, pendingHorse: n, chooseHorse: r }) {
	let i = o();
	return /* @__PURE__ */ d("div", {
		className: "ls-race-page",
		children: [
			/* @__PURE__ */ u("div", {
				className: "ls-prizes",
				children: [
					35,
					25,
					15
				].map((t, n) => /* @__PURE__ */ u(ve, {
					cash: t,
					place: n,
					horse: e.finished[n] ?? null
				}, n))
			}),
			/* @__PURE__ */ d("div", {
				className: "ls-race-caption",
				children: [/* @__PURE__ */ u("span", { children: i("games.longshot.raceLanes") }), /* @__PURE__ */ d("span", { children: [i("games.longshot.noBetZone"), " → 🏁"] })]
			}),
			/* @__PURE__ */ u("div", {
				className: "ls-lanes",
				children: X.map((i) => /* @__PURE__ */ u(ye, {
					horse: i,
					position: e.pos[i - 1],
					finishPlace: e.finished.indexOf(i),
					pending: t,
					targetable: n(i),
					onChoose: () => r(i)
				}, i))
			})
		]
	});
}
function ve({ cash: e, place: t, horse: n }) {
	let { ref: r } = i(`wc:${t}`);
	return /* @__PURE__ */ d("div", {
		ref: r,
		className: "ls-prize",
		children: [
			/* @__PURE__ */ d("strong", { children: [t + 1, /* @__PURE__ */ u("small", { children: [
				"st",
				"nd",
				"rd"
			][t] })] }),
			/* @__PURE__ */ d("span", { children: ["◉ ", e] }),
			n && /* @__PURE__ */ u(Z, {
				h: n,
				size: "size-5 text-xs"
			})
		]
	});
}
function ye({ horse: e, position: t, finishPlace: n, pending: r, targetable: a, onChoose: o }) {
	let { ref: s } = i(`horse:${e}`), c = n >= 0;
	return /* @__PURE__ */ d("div", {
		className: `ls-lane ${a ? "is-target" : ""}`,
		children: [
			/* @__PURE__ */ u(Z, {
				h: e,
				size: "size-7 text-sm"
			}),
			/* @__PURE__ */ d("div", {
				className: "ls-lane-run",
				children: [
					/* @__PURE__ */ u("div", { className: "ls-no-bet" }),
					[
						0,
						3,
						6,
						9,
						12,
						15
					].map((e) => /* @__PURE__ */ u("span", {
						className: "ls-lane-tick",
						style: { left: `${6 + e / 15 * 89}%` }
					}, e)),
					Array.from({ length: 15 }, (t, n) => /* @__PURE__ */ u(be, {
						horse: e,
						pos: n
					}, n)),
					/* @__PURE__ */ u("button", {
						ref: s,
						type: "button",
						className: `ls-runner ${c ? "is-finished" : ""} ${a ? "is-target" : ""}`,
						style: { left: `${6 + Math.min(t, 14) / 15 * 89}%` },
						onClick: o,
						disabled: !r || !a,
						"aria-label": `${e}`,
						children: c ? "🏁" : /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("img", {
							src: me(`horse-${e}.webp`),
							alt: ""
						}), /* @__PURE__ */ u(Z, {
							h: e,
							size: "size-4 text-[9px]"
						})] })
					})
				]
			}),
			c && /* @__PURE__ */ d("span", {
				className: "ls-place",
				children: ["#", n + 1]
			})
		]
	});
}
function be({ horse: e, pos: t }) {
	let { ref: n } = i(`lane:${e}:${t}`);
	return /* @__PURE__ */ u("span", {
		ref: n,
		className: "ls-lane-probe",
		style: { left: `${6 + t / 15 * 89}%` }
	});
}
function xe({ pub: e, board: t, me: n, isMine: r, myAct: i, pending: a, pendingHorse: s, selectedHorse: c, selectHorse: f, horseName: p, nameOf: m, canBet: h, canBuy: g, placeBet: _, send: v, amount: y, setAmount: S, betMode: C, setBetMode: w, ownsAbility: T }) {
	let E = o(), D = c, te = e.owners[D - 1];
	return /* @__PURE__ */ d("div", {
		className: "ls-market-page",
		children: [
			/* @__PURE__ */ u(ke, {
				title: E("games.longshot.market"),
				note: E("games.longshot.marketHint")
			}),
			/* @__PURE__ */ u("div", {
				className: "ls-horse-picker",
				children: X.map((e) => /* @__PURE__ */ u(Se, {
					horse: e,
					selected: e === D,
					targetable: !!(a && s(e)),
					onClick: () => f(e)
				}, e))
			}),
			/* @__PURE__ */ d("div", {
				className: "ls-ticket",
				style: { borderTopColor: ee[D - 1] },
				children: [
					/* @__PURE__ */ d("div", {
						className: "ls-ticket-head",
						children: [
							/* @__PURE__ */ u(Z, {
								h: D,
								size: "size-8 text-base"
							}),
							/* @__PURE__ */ u("strong", { children: p(D) }),
							/* @__PURE__ */ u("span", { children: e.finished.includes(D) ? "🏁" : e.pos[D - 1] >= 11 ? `🚫 ${E("games.longshot.noBetZone")}` : "" })
						]
					}),
					/* @__PURE__ */ d("div", {
						className: "ls-ticket-body",
						children: [/* @__PURE__ */ u("img", {
							className: "ls-portrait",
							src: me(`horse-${D}.webp`),
							alt: ""
						}), /* @__PURE__ */ d("div", {
							className: "ls-ticket-stats",
							children: [
								/* @__PURE__ */ d("span", { children: [
									E("games.longshot.buyPrice"),
									" ",
									/* @__PURE__ */ d("b", { children: ["◉ ", b[D - 1]] })
								] }),
								/* @__PURE__ */ u("span", { children: E("games.longshot.oddsTag", {
									a: x[D - 1][0],
									b: x[D - 1][1],
									c: x[D - 1][2]
								}) }),
								/* @__PURE__ */ u("span", { children: te ? `${E("games.longshot.owner")}: ${m(te)}` : E("games.longshot.unowned") }),
								/* @__PURE__ */ d("span", { children: [
									E("games.longshot.myBet"),
									": ◉ ",
									t?.bets[D - 1] ?? 0,
									" ",
									" · ",
									t?.helmets.includes(D) ? "🪖" : "",
									t?.jerseys.includes(D) ? "👕" : ""
								] })
							]
						})]
					}),
					/* @__PURE__ */ d("div", {
						className: "ls-move-row",
						children: [/* @__PURE__ */ u("span", { children: E("games.longshot.secondaryMove") }), X.map((t) => /* @__PURE__ */ u("span", {
							className: `ls-move-dot ${e.marks[D - 1].includes(t) ? "is-marked" : ""}`,
							children: t
						}, t))]
					}),
					/* @__PURE__ */ u("p", {
						className: "ls-ability",
						children: E(ne[e.set][D - 1])
					}),
					r && i && !a && /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ d("div", {
						className: "ls-bet-controls",
						children: [[
							1,
							2,
							3,
							...T("flexYourQuads") ? [4] : []
						].map((e) => /* @__PURE__ */ d("button", {
							type: "button",
							className: `ls-chip ${y === e && !C ? "is-selected" : ""}`,
							onClick: () => {
								S(e), w(null);
							},
							children: ["$", e]
						}, e)), [
							"cook",
							"strung",
							"lyp"
						].filter((e) => T(e === "cook" ? "cookTheBooks" : e === "strung" ? "strungAlong" : "lineYourPockets")).map((e) => /* @__PURE__ */ u("button", {
							type: "button",
							className: `ls-chip ls-chip-mode ${C === e ? "is-selected" : ""}`,
							onClick: () => w(C === e ? null : e),
							children: E(e === "cook" ? "games.longshot.modeCook" : e === "strung" ? "games.longshot.modeStrung" : "games.longshot.modeLyp")
						}, e))]
					}), /* @__PURE__ */ d("div", {
						className: "ls-ticket-actions",
						children: [/* @__PURE__ */ d("button", {
							type: "button",
							disabled: !h(D),
							onClick: () => _(D),
							children: [
								E("games.longshot.actBet"),
								" ◉ ",
								C ? 1 : y
							]
						}), /* @__PURE__ */ d("button", {
							type: "button",
							disabled: !g(D),
							onClick: () => v({
								type: "act",
								act: "buy",
								horse: D,
								wild: D !== e.dice?.horse || void 0
							}),
							children: [
								E("games.longshot.actBuy"),
								" ◉ ",
								b[D - 1]
							]
						})]
					})] }),
					a && /* @__PURE__ */ u("div", {
						className: "ls-ticket-actions",
						children: /* @__PURE__ */ u("button", {
							type: "button",
							disabled: !s(D),
							onClick: () => f(D),
							children: E("games.longshot.chooseHorse")
						})
					})
				]
			}),
			/* @__PURE__ */ u("p", {
				className: "ls-market-footnote",
				children: E(n && !r ? "games.longshot.viewingBoard" : "games.longshot.marketFootnote")
			})
		]
	});
}
function Se({ horse: e, selected: t, targetable: n, onClick: r }) {
	let { ref: a } = i(`horse:${e}`);
	return /* @__PURE__ */ u("button", {
		ref: a,
		type: "button",
		className: `ls-horse-pick ${t ? "is-selected" : ""} ${n ? "is-target" : ""}`,
		onClick: r,
		children: /* @__PURE__ */ u(Z, {
			h: e,
			size: "size-9 text-lg"
		})
	});
}
function Ce({ board: e, isMine: t, canGrid: n, markGrid: r }) {
	let i = o();
	return /* @__PURE__ */ d("div", {
		className: "ls-concession-page",
		children: [
			/* @__PURE__ */ u(ke, {
				title: i("games.longshot.actConcession"),
				note: i("games.longshot.concessionHint")
			}),
			/* @__PURE__ */ u("div", {
				className: "ls-grid",
				children: C.map((i, a) => /* @__PURE__ */ u(we, {
					cell: a,
					horse: i,
					marked: e.grid[a],
					eligible: t && n(a),
					onClick: () => r(a)
				}, a))
			}),
			/* @__PURE__ */ d("div", {
				className: "ls-concession-ledger",
				children: [/* @__PURE__ */ u("strong", { children: i("games.longshot.lines", { n: e.lines.length }) }), /* @__PURE__ */ u("span", { children: i("games.longshot.gridProgress", { n: e.grid.filter(Boolean).length }) })]
			})
		]
	});
}
function we({ cell: e, horse: t, marked: n, eligible: r, onClick: a }) {
	let { ref: o } = i(`grid:${e}`);
	return /* @__PURE__ */ d("button", {
		ref: o,
		type: "button",
		className: `ls-grid-cell ${r ? "is-eligible" : ""} ${n ? "is-marked" : ""}`,
		disabled: !r,
		onClick: a,
		"aria-label": `${t}`,
		children: [/* @__PURE__ */ u(Z, {
			h: t,
			size: "size-full text-2xl"
		}), n && /* @__PURE__ */ u("span", {
			className: "ls-cross",
			children: "✕"
		})]
	});
}
function Te({ board: e, pub: t, isMine: n, pending: r, pendingHorse: i, horseName: a, canHelmet: s, canJersey: c, markJockey: l, chooseHorse: f }) {
	let p = o();
	return /* @__PURE__ */ d("div", {
		className: "ls-jockey-page",
		children: [/* @__PURE__ */ u(ke, {
			title: p("games.longshot.tabJockey"),
			note: p("games.longshot.jockeyHint")
		}), /* @__PURE__ */ u("div", {
			className: "ls-jockey-list",
			children: X.map((o) => {
				let m = e.helmets.includes(o), h = e.jerseys.includes(o), g = r?.t === "bt" && w[r.bonus] === "helmet" || r?.t === "miracle", _ = r?.t === "bt" && w[r.bonus] === "jersey" || r?.t === "miracle";
				return /* @__PURE__ */ d("div", {
					className: `ls-jockey-row ${m && h ? "is-pair" : ""}`,
					style: { borderLeftColor: ee[o - 1] },
					children: [
						/* @__PURE__ */ d("button", {
							type: "button",
							className: "ls-jockey-id",
							onClick: () => f(o),
							disabled: !n || !i(o),
							children: [/* @__PURE__ */ u(Z, {
								h: o,
								size: "size-8 text-base"
							}), /* @__PURE__ */ d("span", { children: [/* @__PURE__ */ u("strong", { children: a(o) }), /* @__PURE__ */ d("small", { children: [t.marks[o - 1].length, "/8"] })] })]
						}),
						/* @__PURE__ */ d("button", {
							type: "button",
							className: `ls-jockey-mark ${m ? "is-done" : ""}`,
							disabled: !n || m || (r ? !g || !i(o) : !s(o)),
							onClick: () => l(o, "helmet"),
							children: [m ? "✓" : "🪖", /* @__PURE__ */ u("small", { children: p(m ? "games.longshot.marked" : "games.longshot.actHelmet") })]
						}),
						/* @__PURE__ */ d("button", {
							type: "button",
							className: `ls-jockey-mark ${h ? "is-done" : ""}`,
							disabled: !n || h || (r ? !_ || !i(o) : !c(o)),
							onClick: () => l(o, "jersey"),
							children: [h ? "✓" : "👕", /* @__PURE__ */ u("small", { children: p(h ? "games.longshot.marked" : "games.longshot.actJersey") })]
						})
					]
				}, o);
			})
		})]
	});
}
var Ee = {
	cash7: "$",
	back22: "↓",
	bet3: "$",
	fwd22: "↑",
	back3: "↓",
	fwd3: "↑",
	helmet: "🪖",
	jersey: "👕",
	horse: "🐎"
};
function De({ pub: e, pending: t, send: n }) {
	let r = o();
	return /* @__PURE__ */ d("div", {
		className: "ls-rewards-page",
		children: [/* @__PURE__ */ u(ke, {
			title: r("games.longshot.bonuses"),
			note: r("games.longshot.rewardsHint")
		}), /* @__PURE__ */ u("div", {
			className: "ls-reward-grid",
			children: w.map((r, i) => /* @__PURE__ */ u(Oe, {
				index: i,
				kind: r,
				used: e.bonusUsed[i],
				eligible: t?.t === "bonus" && !e.bonusUsed[i],
				onClick: () => n({
					type: "choose",
					bonus: i
				})
			}, i))
		})]
	});
}
function Oe({ index: e, kind: t, used: n, eligible: r, onClick: a }) {
	let s = o(), { ref: c } = i(`bonus:${e}`), l = s(T[t]), [f, p] = t === "cash7" ? [s("games.longshot.bonusCash7"), s("games.longshot.rewardCash")] : t === "back22" ? [s("games.longshot.rewardBack2"), s("games.longshot.rewardTwoHorses")] : t === "fwd22" ? [s("games.longshot.rewardForward2"), s("games.longshot.rewardTwoHorses")] : t === "back3" ? [s("games.longshot.rewardBack3"), s("games.longshot.rewardOneHorse")] : t === "fwd3" ? [s("games.longshot.rewardForward3"), s("games.longshot.rewardOneHorse")] : t === "bet3" ? ["$3", s("games.longshot.rewardFreeBet")] : t === "helmet" ? [s("games.longshot.actHelmet"), s("games.longshot.rewardFree")] : t === "jersey" ? [s("games.longshot.actJersey"), s("games.longshot.rewardFree")] : [s("games.longshot.rewardHorse"), s("games.longshot.rewardFree")];
	return /* @__PURE__ */ d("button", {
		ref: c,
		type: "button",
		className: `ls-reward ${n ? "is-used" : ""} ${r ? "is-eligible" : ""}`,
		disabled: !r,
		onClick: a,
		"aria-label": l,
		children: [
			/* @__PURE__ */ u("span", {
				className: "ls-reward-stamp",
				children: Ee[t]
			}),
			/* @__PURE__ */ u("strong", { children: f }),
			/* @__PURE__ */ u("small", { children: p }),
			n && /* @__PURE__ */ u("span", {
				className: "ls-reward-used",
				children: "✓"
			})
		]
	});
}
function ke({ title: e, note: t }) {
	return /* @__PURE__ */ d("div", {
		className: "ls-title-row",
		children: [/* @__PURE__ */ u("span", {
			className: "ls-title",
			children: e
		}), /* @__PURE__ */ u("span", {
			className: "ls-note",
			children: t
		})]
	});
}
function Ae({ pub: e, board: t, myRoll: n, myAct: r, pending: i, miracleMark: a, setMiracleMark: s, passAllowed: c, horseName: f, send: p }) {
	let m = o(), h = i?.t === "bonus" ? m("games.longshot.bonusPrompt", { n: 1 }) : i?.t === "bt" ? `${m(T[w[i.bonus]])} · ${m(w[i.bonus] === "back22" || w[i.bonus] === "fwd22" ? "games.longshot.btPrompt2" : "games.longshot.btPrompt1", { n: (w[i.bonus] === "back22" || w[i.bonus] === "fwd22" ? 2 : 1) - i.picked.length })}` : i?.t === "chain" ? m("games.longshot.chainPrompt") : i?.t === "charley" ? m("games.longshot.charleyPrompt") : i?.t === "miracle" ? m(a === "grid" ? "games.longshot.mirPickGrid" : a ? "games.longshot.mirPickHorse" : "games.longshot.miraclePrompt") : i?.t === "mir" ? m("games.longshot.mirParity") : i?.t === "mint" ? m("games.longshot.mintPrompt", { name: f(i.horse) }) : i?.t === "jx" ? m("games.longshot.jxPrompt", { name: f(i.horse) }) : i?.t === "pr" ? m("games.longshot.prPrompt", { name: f(i.horse) }) : n ? m("games.longshot.actRoll") : r ? m("games.longshot.actionHint") : e.phase === "move" ? m("games.longshot.moving") : m("games.longshot.waiting"), g = i && [
		"chain",
		"charley",
		"miracle",
		"bt",
		"jx"
	].includes(i.t);
	return /* @__PURE__ */ d("div", {
		className: "ls-footer",
		children: [/* @__PURE__ */ d("div", {
			className: "ls-footer-dice",
			children: [
				/* @__PURE__ */ u("span", { children: m("games.longshot.currentDice") }),
				e.dice ? /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u(Z, {
					h: e.dice.horse,
					size: "size-8 text-base"
				}), /* @__PURE__ */ u("span", {
					className: "ls-move-die",
					children: e.dice.move
				})] }) : /* @__PURE__ */ u("span", {
					className: "ls-empty-die",
					children: "—"
				}),
				/* @__PURE__ */ u("span", { children: m("games.longshot.wilds", { n: t?.wilds ?? 3 }) })
			]
		}), /* @__PURE__ */ d("div", {
			className: "ls-footer-action",
			children: [
				/* @__PURE__ */ u("strong", { children: h }),
				n && /* @__PURE__ */ u("button", {
					type: "button",
					onClick: () => p({ type: "roll" }),
					children: m("games.longshot.actRoll")
				}),
				r && !i && /* @__PURE__ */ u("button", {
					type: "button",
					disabled: !c,
					onClick: () => p({
						type: "act",
						act: "pass"
					}),
					children: m("games.longshot.actPass")
				}),
				g && /* @__PURE__ */ u("button", {
					type: "button",
					onClick: () => p({
						type: "choose",
						skip: !0
					}),
					children: m("games.longshot.skip")
				}),
				i?.t === "miracle" && !a && /* @__PURE__ */ u("div", {
					className: "ls-footer-choices",
					children: [
						"grid",
						"helmet",
						"jersey"
					].map((e) => /* @__PURE__ */ u("button", {
						type: "button",
						onClick: () => s(e),
						children: m(e === "grid" ? "games.longshot.mirGrid" : e === "helmet" ? "games.longshot.mirHelmet" : "games.longshot.mirJersey")
					}, e))
				}),
				i?.t === "mir" && /* @__PURE__ */ d("div", {
					className: "ls-footer-choices",
					children: [/* @__PURE__ */ u("button", {
						type: "button",
						onClick: () => p({
							type: "choose",
							parity: "odd"
						}),
						children: m("games.longshot.odd")
					}), /* @__PURE__ */ u("button", {
						type: "button",
						onClick: () => p({
							type: "choose",
							parity: "even"
						}),
						children: m("games.longshot.even")
					})]
				}),
				(i?.t === "mint" || i?.t === "pr") && /* @__PURE__ */ u("div", {
					className: "ls-footer-choices",
					children: Array.from({ length: i.t === "mint" ? 3 : 4 }, (e, t) => /* @__PURE__ */ d("button", {
						type: "button",
						onClick: () => p({
							type: "choose",
							amount: t
						}),
						children: ["$", t]
					}, t))
				})
			]
		})]
	});
}
function je({ horse: e, move: t }) {
	let { ref: n } = i("dice");
	return /* @__PURE__ */ d("div", {
		ref: n,
		className: "ls-dice-overlay",
		children: [/* @__PURE__ */ u(Z, {
			h: e,
			size: "size-9 text-lg"
		}), /* @__PURE__ */ u("span", {
			className: "ls-move-die",
			children: t
		})]
	});
}
function Me(e, t) {
	for (let n = 0; n < 16; n++) {
		if (C[n] !== t || e.grid[n]) continue;
		let r = Math.floor(n / 4), i = n % 4;
		if (!e.lines.includes(r) && [
			0,
			1,
			2,
			3
		].every((t) => e.grid[r * 4 + t] || r * 4 + t === n) || !e.lines.includes(i + 4) && [
			0,
			1,
			2,
			3
		].every((t) => e.grid[t * 4 + i] || t * 4 + i === n)) return !0;
	}
	return !1;
}
//#endregion
//#region src/games/longshot/bot.ts
function Ne(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Pe = (e, t) => e.players.find((e) => e.rid === t)?.board, Q = (e, t) => e.finished.includes(t);
function Fe(e, t, n) {
	let r = D[e.set].findIndex((e) => e.ability === n);
	return r >= 0 && e.owners[r] === t;
}
function $(e, t, n) {
	if (Q(e, n)) return !1;
	if (e.pos[n - 1] < 11) return !0;
	let r = Pe(e, t);
	return !!r && (r.helmets.includes(n) || n === 8 && Fe(e, t, "nightMare"));
}
function Ie(e, t, n) {
	let r = [...e];
	r[n] = !0;
	let i = Math.floor(n / 4), a = 4 + n % 4, o = (e) => [
		0,
		1,
		2,
		3
	].every((t) => r[e < 4 ? e * 4 + t : t * 4 + (e - 4)]);
	return !t.includes(i) && o(i) || !t.includes(a) && o(a);
}
function Le(e) {
	let t = 0, n = -1;
	for (let r = 1; r <= 8; r++) !Q(e, r) && e.pos[r - 1] > n && (n = e.pos[r - 1], t = r);
	return t;
}
var Re = [
	"horse",
	"cash7",
	"fwd3",
	"bet3",
	"jersey",
	"fwd22",
	"helmet",
	"back3",
	"back22"
];
function ze(e, t, n) {
	let r = Pe(e, t);
	if (!r) return null;
	if (n.t === "bonus") {
		for (let t of Re) {
			let n = w.findIndex((n, r) => n === t && !e.bonusUsed[r]);
			if (n >= 0) return {
				type: "choose",
				bonus: n
			};
		}
		return null;
	}
	if (n.t === "bt") {
		let i = w[n.bonus ?? 0], a = () => {
			let r = (n) => e.owners[n - 1] === t, i = [
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8
			].filter((t) => !Q(e, t) && r(t) && !(n.picked ?? []).includes(t)).sort((t, n) => e.pos[n - 1] - e.pos[t - 1]);
			return i[0] ? i[0] : [
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8
			].filter((t) => !Q(e, t) && !(n.picked ?? []).includes(t)).sort((t, n) => e.pos[n - 1] - e.pos[t - 1])[0] ?? 0;
		};
		if (i === "back22" || i === "back3") {
			let r = [
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8
			].filter((r) => !Q(e, r) && e.owners[r - 1] !== t && !(n.picked ?? []).includes(r)).sort((t, n) => e.pos[n - 1] - e.pos[t - 1]);
			return r.length ? {
				type: "choose",
				horse: r[0]
			} : {
				type: "choose",
				skip: !0
			};
		}
		if (i === "fwd22" || i === "fwd3") {
			let e = a();
			return e > 0 ? {
				type: "choose",
				horse: e
			} : {
				type: "choose",
				skip: !0
			};
		}
		if (i === "bet3") {
			let n = Le(e);
			return $(e, t, n) ? {
				type: "choose",
				horse: n
			} : {
				type: "choose",
				skip: !0
			};
		}
		if (i === "helmet") {
			let e = [
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8
			].filter((e) => !r.helmets.includes(e)).sort((e, t) => r.bets[t - 1] - r.bets[e - 1])[0];
			return e ? {
				type: "choose",
				horse: e
			} : {
				type: "choose",
				skip: !0
			};
		}
		if (i === "jersey") {
			let e = [
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8
			].filter((e) => !r.jerseys.includes(e)).sort((e, t) => r.bets[t - 1] - r.bets[e - 1])[0];
			return e ? {
				type: "choose",
				horse: e
			} : {
				type: "choose",
				skip: !0
			};
		}
		let o = [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8
		].filter((t) => e.owners[t - 1] === null && !Q(e, t)).sort((t, n) => e.pos[n - 1] - e.pos[t - 1])[0];
		return o ? {
			type: "choose",
			horse: o
		} : {
			type: "choose",
			skip: !0
		};
	}
	if (n.t === "chain" || n.t === "miracle") {
		for (let e = 0; e < 16; e++) if (!r.grid[e] && Ie(r.grid, r.lines, e)) return {
			type: "choose",
			mark: "grid",
			cell: e
		};
		if (n.t === "chain") return {
			type: "choose",
			skip: !0
		};
		let e = [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8
		].filter((e) => !r.helmets.includes(e)).sort((e, t) => r.bets[t - 1] - r.bets[e - 1])[0];
		return e ? {
			type: "choose",
			mark: "helmet",
			horse: e
		} : {
			type: "choose",
			skip: !0
		};
	}
	if (n.t === "charley") {
		let n = Le(e);
		return e.owners[n - 1] === t ? {
			type: "choose",
			skip: !0
		} : {
			type: "choose",
			horse: n
		};
	}
	if (n.t === "mir") return {
		type: "choose",
		parity: [
			1,
			3,
			5,
			7
		].filter((t) => !Q(e, t)).length >= [
			2,
			4,
			6,
			8
		].filter((t) => !Q(e, t)).length ? "odd" : "even"
	};
	if (n.t === "mint") return {
		type: "choose",
		amount: Math.min(2, r.cash)
	};
	if (n.t === "jx") {
		let t = e.marks[(n.horse ?? 1) - 1], r = [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8
		].filter((n) => !t.includes(n) && !Q(e, n)).sort((t, n) => e.pos[n - 1] - e.pos[t - 1])[0];
		return r ? {
			type: "choose",
			horse: r
		} : {
			type: "choose",
			skip: !0
		};
	}
	return n.t === "pr" ? $(e, t, n.horse ?? 1) && r.cash >= 2 ? {
		type: "choose",
		amount: 2
	} : {
		type: "choose",
		amount: 0
	} : {
		type: "choose",
		skip: !0
	};
}
function Be(e, t, n) {
	let r = Pe(e, t), i = e.dice?.horse ?? 1;
	if (!r) return {
		type: "act",
		act: "pass"
	};
	let a = Fe(e, t, "scatterShot"), o = C.map((e, t) => ({
		n: e,
		i: t
	})).filter(({ n: e, i: t }) => !r.grid[t] && (e === i || a && Math.abs(e - i) === 1)).map(({ i: e }) => e), s = C.map((e, t) => t).filter((e) => !r.grid[e]);
	if (n) {
		let n = [];
		return o.length && n.push({
			type: "act",
			act: "concession",
			cell: Ne(o)
		}), r.helmets.includes(i) || n.push({
			type: "act",
			act: "helmet",
			horse: i
		}), r.jerseys.includes(i) || n.push({
			type: "act",
			act: "jersey",
			horse: i
		}), $(e, t, i) && r.cash >= 1 && n.push({
			type: "act",
			act: "bet",
			horse: i,
			amount: 1
		}), e.owners[i - 1] === null && !Q(e, i) && r.cash >= b[i - 1] && n.push({
			type: "act",
			act: "buy",
			horse: i
		}), r.wilds > 0 && s.length && n.push({
			type: "act",
			act: "concession",
			cell: Ne(s),
			wild: !0
		}), n.length ? Ne(n) : {
			type: "act",
			act: "pass"
		};
	}
	for (let e of o) if (Ie(r.grid, r.lines, e)) return {
		type: "act",
		act: "concession",
		cell: e
	};
	if (e.owners[i - 1] === null && !Q(e, i) && r.cash - b[i - 1] >= 2 && e.pos[i - 1] >= 3) return {
		type: "act",
		act: "buy",
		horse: i
	};
	if ($(e, t, i)) {
		let n = Fe(e, t, "earlyBird") && r.bets[i - 1] === 0, a = Le(e), o = n ? 3 : i === a ? Math.min(3, r.cash - 2) : Math.min(2, Math.max(1, r.cash - 6));
		if (o >= 1 && r.cash >= (n ? 0 : o)) return {
			type: "act",
			act: "bet",
			horse: i,
			amount: o
		};
	}
	if (o.length) return {
		type: "act",
		act: "concession",
		cell: o[0]
	};
	if (!r.helmets.includes(i)) return {
		type: "act",
		act: "helmet",
		horse: i
	};
	if (!r.jerseys.includes(i)) return {
		type: "act",
		act: "jersey",
		horse: i
	};
	if (r.wilds > 0) {
		let n = [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8
		].filter((t) => e.owners[t - 1] === null && !Q(e, t) && r.cash - b[t - 1] >= 2).sort((t, n) => e.pos[n - 1] - e.pos[t - 1])[0];
		if (n) return {
			type: "act",
			act: "buy",
			horse: n,
			wild: !0
		};
		let i = Le(e);
		if ($(e, t, i) && r.cash >= 3) return {
			type: "act",
			act: "bet",
			horse: i,
			amount: 2,
			wild: !0
		};
		for (let e of s) if (Ie(r.grid, r.lines, e)) return {
			type: "act",
			act: "concession",
			cell: e,
			wild: !0
		};
		if (s.length) return {
			type: "act",
			act: "concession",
			cell: s[0],
			wild: !0
		};
		let a = [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8
		].filter((e) => !r.helmets.includes(e)).sort((e, t) => r.bets[t - 1] - r.bets[e - 1])[0];
		if (a) return {
			type: "act",
			act: "helmet",
			horse: a,
			wild: !0
		};
		let o = [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8
		].filter((e) => !r.jerseys.includes(e)).sort((e, t) => r.bets[t - 1] - r.bets[e - 1])[0];
		if (o) return {
			type: "act",
			act: "jersey",
			horse: o,
			wild: !0
		};
	}
	return {
		type: "act",
		act: "pass"
	};
}
var Ve = (e, t) => {
	let n = e.public, r = t.difficulty === "weak";
	if (n.phase === "roll") return n.roller === t.rid ? { action: { type: "roll" } } : null;
	if (n.phase !== "act" || n.actor !== t.rid) return null;
	let i = n.pending;
	if (i.length > 0) {
		let e = ze(n, t.rid, i[0]);
		return e ? { action: e } : { action: {
			type: "choose",
			skip: !0
		} };
	}
	return { action: Be(n, t.rid, r) };
}, He = (e, t, n) => {
	let r = (e) => n(te[t.public.set][e - 1]);
	return e.type === "roll" ? n("games.longshot.hintRoll") : e.type === "choose" ? n("games.longshot.hintChoose") : e.type === "act" ? e.act === "concession" ? n("games.longshot.hintConcession") : e.act === "helmet" && e.horse ? n("games.longshot.hintHelmet", { name: r(e.horse) }) : e.act === "jersey" && e.horse ? n("games.longshot.hintJersey", { name: r(e.horse) }) : e.act === "bet" && e.horse ? n("games.longshot.hintBet", {
		name: r(e.horse),
		n: e.amount ?? 1
	}) : e.act === "buy" && e.horse ? n("games.longshot.hintBuy", { name: r(e.horse) }) : e.act === "pass" ? n("games.longshot.hintPass") : "" : "";
};
//#endregion
//#region src/games/longshot/fx.tsx
function Ue(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function We(e, t, n) {
	let r = e.anchor(`lane:${t}:${n}`);
	if (!r) return null;
	let i = e.anchor(`horse:${t}`), a = i ? Math.min(i.w, i.h) : 22;
	return {
		x: r.x + r.w / 2 - a / 2,
		y: r.y + r.h / 2 - a / 2,
		w: a,
		h: a
	};
}
function Ge(e, t, n, r, i, a, o) {
	let s = We(e, t, Math.max(0, Math.min(14, n)));
	if (!s) return null;
	let c = null;
	if (i) {
		let t = e.anchor(`wc:${Math.max(0, Math.min(2, a))}`);
		if (t) {
			let e = Math.min(s.w, t.w, t.h * .6);
			c = {
				x: t.x + t.w / 2 - e / 2,
				y: t.y + t.h / 2 - e / 2,
				w: e,
				h: e
			};
		}
	}
	return c ||= We(e, t, Math.max(0, Math.min(14, r))), c ? /* @__PURE__ */ u(p, {
		from: s,
		to: c,
		ms: o,
		children: /* @__PURE__ */ u("span", {
			style: {
				display: "block",
				width: s.w,
				height: s.h,
				fontSize: s.w * .42
			},
			children: /* @__PURE__ */ u(Z, {
				h: t,
				size: "size-full text-inherit"
			})
		})
	}) : null;
}
var Ke = {
	roll(e, t) {
		let n = t.anchor("dice");
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ u(m, {
				at: n,
				ms: 900
			})
		} : null;
	},
	move(e, t) {
		let n = e.data;
		if (typeof n?.horse != "number" || typeof n.from != "number" || typeof n.to != "number") return null;
		let r = n.main ? 650 : 400, i = Ge(t, n.horse, n.from, n.to, n.cross === !0, typeof n.place == "number" ? n.place : 0, r - 150);
		return i ? {
			ms: r,
			node: i
		} : null;
	},
	bet(e, t) {
		let n = e.data, r = Ue(t, e.rid);
		if (!r) return null;
		let i = typeof n?.horse == "number" ? [n.horse] : Array.isArray(n?.horses) ? n.horses.filter((e) => typeof e == "number") : [], a = typeof n?.amount == "number" ? n.amount : 1, o = i.map((e, n) => {
			let i = t.anchor(`horse:${e}`);
			return i ? /* @__PURE__ */ u(p, {
				from: r,
				to: i,
				ms: 450,
				delay: n * 80,
				children: /* @__PURE__ */ d("span", {
					className: "grid min-w-8 place-items-center rounded-full border-2 border-ink bg-surface px-1 font-mono text-xs font-black shadow-[2px_2px_0_var(--color-ink)]",
					children: ["🪙", a]
				})
			}, e) : null;
		}).filter(Boolean);
		return o.length === 0 ? null : {
			ms: 600,
			node: /* @__PURE__ */ u(l, { children: o })
		};
	},
	buy(e, t) {
		let n = e.data, r = Ue(t, e.rid);
		if (typeof n?.horse != "number" || !r) return null;
		let i = t.anchor(`horse:${n.horse}`);
		return i ? {
			ms: 600,
			node: /* @__PURE__ */ u(p, {
				from: i,
				to: r,
				ms: 480,
				children: /* @__PURE__ */ u(Z, {
					h: n.horse,
					size: "size-7 text-xs"
				})
			})
		} : null;
	},
	helmet(e, t) {
		let n = e.data;
		if (typeof n?.horse != "number") return null;
		let r = t.anchor(`horse:${n.horse}`);
		return r ? {
			ms: 600,
			node: /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u(m, {
				at: r,
				ms: 600
			}), /* @__PURE__ */ u(f, {
				at: r,
				ms: 600,
				children: /* @__PURE__ */ u("span", {
					"aria-hidden": !0,
					children: "🪖"
				})
			})] })
		} : null;
	},
	jersey(e, t) {
		let n = e.data;
		if (typeof n?.horse != "number") return null;
		let r = t.anchor(`horse:${n.horse}`);
		return r ? {
			ms: 600,
			node: /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u(m, {
				at: r,
				ms: 600
			}), /* @__PURE__ */ u(f, {
				at: r,
				ms: 600,
				children: /* @__PURE__ */ u("span", {
					"aria-hidden": !0,
					children: "👕"
				})
			})] })
		} : null;
	},
	mark(e, t) {
		let n = e.data;
		if (typeof n?.cell != "number") return null;
		let r = t.anchor(`grid:${n.cell}`);
		return r ? {
			ms: 550,
			node: /* @__PURE__ */ u(m, {
				at: r,
				ms: 550
			})
		} : null;
	},
	markX(e, t) {
		let n = e.data;
		if (typeof n?.horse != "number") return null;
		let r = t.anchor(`horse:${n.horse}`);
		return r ? {
			ms: 550,
			node: /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u(m, {
				at: r,
				ms: 550
			}), /* @__PURE__ */ u(f, {
				at: r,
				ms: 550,
				children: /* @__PURE__ */ u("span", {
					className: "font-black text-ink",
					children: "✕"
				})
			})] })
		} : null;
	},
	bonus(e, t) {
		let n = e.data;
		if (typeof n?.bonus != "number") return null;
		let r = t.anchor(`bonus:${n.bonus}`);
		return r ? {
			ms: 650,
			node: /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u(m, {
				at: r,
				ms: 650
			}), /* @__PURE__ */ u(f, {
				at: r,
				ms: 650,
				children: /* @__PURE__ */ u(qe, { i: n.bonus })
			})] })
		} : null;
	},
	bonusMove(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.horses) || typeof n.delta != "number") return null;
		let r = n.delta, i = n.horses.filter((e) => typeof e == "number").map((e) => {
			let n = t.anchor(`horse:${e}`);
			return n ? /* @__PURE__ */ u(f, {
				at: n,
				ms: 600,
				children: /* @__PURE__ */ d("span", {
					className: r > 0 ? "font-black text-done-ink" : "font-black text-danger-ink",
					children: [r > 0 ? "▲" : "▼", Math.abs(r)]
				})
			}, e) : null;
		}).filter(Boolean);
		return i.length === 0 ? null : {
			ms: 650,
			node: /* @__PURE__ */ u(l, { children: i })
		};
	},
	money(e, t) {
		let n = e.data, r = Ue(t, e.rid);
		return typeof n?.delta != "number" || n.delta === 0 || !r ? null : {
			ms: 800,
			node: /* @__PURE__ */ u(f, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ d("span", {
					className: n.delta > 0 ? "text-done-ink" : "text-danger-ink",
					children: [
						n.delta > 0 ? "+" : "",
						n.delta,
						" 🪙"
					]
				})
			})
		};
	}
};
function qe({ i: e }) {
	let t = o(), n = w[e];
	return /* @__PURE__ */ u("span", {
		className: "text-xs font-black text-ink",
		children: n ? t(T[n]) : ""
	});
}
//#endregion
//#region src/games/longshot/game-over.tsx
function Je(e) {
	return /* @__PURE__ */ u("div", {
		className: "ls-over",
		children: /* @__PURE__ */ u(h, {
			...e,
			accent: O.accent
		})
	});
}
//#endregion
//#region src/games/longshot/options.tsx
var Ye = [
	{
		v: 1,
		name: "games.longshot.set1Name",
		hint: "games.longshot.set1Hint"
	},
	{
		v: 2,
		name: "games.longshot.set2Name",
		hint: "games.longshot.set2Hint"
	},
	{
		v: 3,
		name: "games.longshot.set3Name",
		hint: "games.longshot.set3Hint"
	}
];
function Xe({ value: e, onChange: t }) {
	let n = o(), r = j.safeParse(e), i = r.success ? r.data : j.parse(void 0);
	return /* @__PURE__ */ u(_, {
		title: n("games.longshot.optSet"),
		children: Ye.map((e) => /* @__PURE__ */ u(g, {
			name: "longshot-set",
			value: String(e.v),
			checked: i.set === e.v,
			label: n(e.name),
			hint: n(e.hint),
			accent: O.accent,
			onChange: () => t({ set: e.v })
		}, e.v))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/longshot/entry.tsx
var Ze = {
	definition: fe,
	View: he,
	bot: Ve,
	describe: He,
	fx: Ke,
	OverView: Je,
	Options: Xe,
	locales: {
		zh: {
			name: "狂野赛马骰子版",
			desc: "掷骰赛马加下注:买马、头盔、球衣、小吃摊连成线,3 匹冲线即结算",
			rules: "目标:比赛结束后总财产最多者获胜;最终财产为剩余现金、马主奖金、注金派彩和骑师套奖励的总和。\n准备:\n· 8 匹马从起点出发,赛道 15 格;终点前 4 格为禁注区。\n· 每人起始 12 元现金、3 个百搭马蹄铁,并抽一张起手卡。\n· 起手卡预标 4 格小吃摊与 2 笔起始注。\n回合流程：\n每回合由当前玩家掷骰，马号骰决定移动哪匹马，移动骰决定它前进一至三格。随后，该马次级移动条上已打叉的马各前进一格。\n从当前玩家开始，所有玩家按顺时针方向各选择并执行下列一个行动：\n· 小卖部:在 4 行 4 列网格标一个与马号相同的格;完成整行或整列即从奖励池选一个奖励。\n· 头盔:标该马号的头盔格;有头盔的马过了禁注线你仍可下注。\n· 球衣:标该马号球衣格,并在该马次级移动条上任选一匹马打叉(公共、永久)。\n· 下注:对该马号下注 1 至 3 元,可累加;禁注区内的马需有头盔;已完赛的马不可下注。\n· 买马:按标价从市场买下该马号,立即触发其「买入时」能力。\n百搭马蹄铁:行动前消耗一个,把本次行动的马号当作任意点数(不触发马能力)。\n冲线:只有掷骰与次级移动能让马冲线;奖励或能力的直接移动至多停在终点前,后退至多退回起点。\n结束:3 匹马冲线后,本轮行动全部执行完即结算。\n· 马主奖金:持有第 1、2、3 名的马分别获得 35、25、15 元。\n· 注金:完赛马按注额乘名次赔率;越过禁止下注线但尚未完赛的马，按下注金额的 1 倍结算;未过禁注线的马不得分。\n· 骑师套:同一匹马集齐你的头盔与球衣,每套获得 5 元。",
			optSet: "马卡套装",
			set1Name: "第一套 · 星标",
			set1Hint: "官方推荐首局(能力直白)",
			set2Name: "第二套 · 城堡",
			set2Hint: "下注与小吃摊联动更多",
			set3Name: "第三套 · 三叶草",
			set3Hint: "围绕 $3 注与末名博弈",
			roundChip: "第 {{n}} 轮",
			yourRoll: "轮到你了:掷骰!",
			waitRoll: "等待 {{name}} 掷骰…",
			moving: "马匹前进中…",
			yourAct: "轮到你行动(马号 {{n}})",
			waitAct: "等待 {{name}} 行动…",
			actRoll: "掷骰",
			actConcession: "小卖部",
			actHelmet: "头盔",
			actJersey: "球衣",
			actBet: "下注",
			actBuy: "买马",
			actPass: "跳过",
			players: "玩家",
			sections: "游戏区域",
			tabRace: "赛场",
			tabJockey: "骑师",
			raceLanes: "八马分道赛场",
			marketHint: "选马查看赔率并下注",
			marketFootnote: "切换马号查看其他马卡",
			viewingBoard: "正在查看其他玩家的记录",
			buyPrice: "买入价",
			owner: "马主",
			unowned: "待售",
			myBet: "注额",
			secondaryMove: "次级移动",
			chooseHorse: "选择这匹马",
			concessionHint: "凑满一行或一列，领取奖励",
			gridProgress: "已标 {{n}} / 16",
			jockeyHint: "同马头盔与球衣成套 +$5",
			marked: "已标",
			rewardsHint: "完成一条线，领取一枚奖励牌",
			rewardCash: "现金",
			rewardBack2: "退 2",
			rewardForward2: "进 2",
			rewardBack3: "退 3",
			rewardForward3: "进 3",
			rewardTwoHorses: "两匹马",
			rewardOneHorse: "一匹马",
			rewardFreeBet: "免费注",
			rewardFree: "免费",
			rewardHorse: "买马",
			actionHint: "点上方页签，在游戏物件上行动",
			waiting: "等待其他玩家行动",
			currentDice: "本轮",
			wilds: "百搭 ⭐×{{n}}",
			diceInfo: "🎲 {{h}} 号马走 {{m}} 格",
			pickCell: "点一个高亮格",
			pickHorse: "点一匹马",
			cancel: "取消",
			skip: "跳过",
			modeCook: "$1 免费任选",
			modeStrung: "$1 并前进 1 格",
			modeLyp: "$1 免费(成行)",
			bonusPrompt: "完成了 {{n}} 条线:选一个奖励",
			btPrompt2: "点选两匹未完赛的马(还需 {{n}} 匹)",
			btPrompt1: "点选一匹马",
			chainPrompt: "连锁反应:可再标任意一个网格",
			charleyPrompt: "腿抽筋:选一匹马后退 1 格",
			miraclePrompt: "神医:选择要标记的",
			mirGrid: "网格",
			mirHelmet: "头盔",
			mirJersey: "球衣",
			mirPickGrid: "点一个未标的网格",
			mirPickHorse: "点一匹马标记",
			mirParity: "挥金如雨:给哪组马各下 $1 免费注?",
			odd: "奇数马",
			even: "偶数马",
			mintPrompt: "品相如新:可对 {{name}} 补注至多 $2",
			jxPrompt: "在 {{name}} 的次级条上选一匹马打叉",
			prPrompt: "紫缰:可立即对 {{name}} 下注",
			noBetZone: "禁注区",
			finish: "终点",
			winners: "冠军圈",
			market: "马市",
			myBoard: "我的玩家板",
			lines: "连线 {{n}}/8",
			bonuses: "奖励池",
			oddsTag: "赔率 {{a}}/{{b}}/{{c}}",
			ownerYou: "我的马",
			freeTag: "免费",
			bonusCash7: "+$7",
			bonusBack22: "两马各退 2 格",
			bonusBet3: "$3 免费注",
			bonusFwd22: "两马各进 2 格",
			bonusBack3: "一马退 3 格",
			bonusFwd3: "一马进 3 格",
			bonusHelmet: "免费头盔",
			bonusJersey: "免费球衣",
			bonusHorse: "免费马",
			h1_1: "连锁反应",
			h1_2: "幸运星",
			h1_3: "天女散花",
			h1_4: "早鸟特惠",
			h1_5: "腿抽筋",
			h1_6: "神医",
			h1_7: "稳字当头",
			h1_8: "氮气妮莉",
			h2_1: "划划小船",
			h2_2: "挥金如雨",
			h2_3: "账面游戏",
			h2_4: "品相如新",
			h2_5: "最后一块",
			h2_6: "脏衣篓",
			h2_7: "打起精神",
			h2_8: "甜甜圈妹",
			h3_1: "牵线木偶",
			h3_2: "一元菜单",
			h3_3: "传递善意",
			h3_4: "亮出股四",
			h3_5: "蜇刺",
			h3_6: "夜魇",
			h3_7: "中饱私囊",
			h3_8: "紫缰",
			a1_1: "小吃摊:你完成一整列时,可再标任意一格",
			a1_2: "你的回合掷出 2 号时,获得 $2",
			a1_3: "小卖部:可标比骰号大 1 或小 1 的格",
			a1_4: "你对没有你的注的马下注免费",
			a1_5: "小吃摊:你完成一整行时,可令任一匹马退 1 格",
			a1_6: "买入时:标任意一个网格、头盔或球衣",
			a1_7: "计分时:你每有一匹下过注的马获得 $2",
			a1_8: "你执行头盔行动时,此马前进 1 格",
			a2_1: "小吃摊:你完成一整行时,获得 $2",
			a2_2: "买入时:给全部奇数或全部偶数马各下 $1 免费注",
			a2_3: "下注行动可改为:对任一匹马下 $1 免费注",
			a2_4: "你执行头盔行动时,可再对该马下注至多 $2",
			a2_5: "计分时:额外获得等同于你对过禁注线但未完赛的马下注总额的现金",
			a2_6: "球衣行动可改为:标一匹你有注的马的球衣",
			a2_7: "你下注时若此马在最后(含并列),它前进 3 格",
			a2_8: "你用小吃摊奖励移动此马时,它多移 1 格",
			a3_1: "你对此马下注可改为:下 $1 并让它前进 1 格",
			a3_2: "你对最后一名(含并列)的马下 $3 的注时,只需支付 $1",
			a3_3: "你向与其他马同处一格的马下 $3 注时,该格所有马各前进 1 格",
			a3_4: "你可下注 $4;计分时每匹有你的注且未完赛的马扣 $4",
			a3_5: "你对最后一名(含并列)下 $3 时,领先马群各退 1 格",
			a3_6: "你对 8 号下注无需头盔;买入时其他玩家对 8 号的注各减 $1",
			a3_7: "若所注马号能让你完成行或列,该注改为 $1 免费注",
			a3_8: "你凑齐同马头盔+球衣时,可立即对该马下注",
			errOver: "对局已结束",
			errNotYourTurn: "还没轮到你",
			errNoPending: "没有待处理的选择",
			errPendingFirst: "先处理完当前选择",
			errBadChoice: "这个选择不合法",
			errBadCell: "这个格子不能标",
			errBadHorse: "这匹马不能选",
			errNoWild: "百搭马蹄铁用完了",
			errNoCash: "现金不够",
			errNoBet: "这匹马现在不能下注",
			hintRoll: "掷骰",
			hintConcession: "在小卖部标一格",
			hintHelmet: "标 {{name}} 的头盔",
			hintJersey: "标 {{name}} 的球衣",
			hintBet: "对{{name}}下注 ${{n}}",
			hintBuy: "买下{{name}}",
			hintPass: "跳过行动",
			hintChoose: "处理待决选择"
		},
		en: {
			name: "Long Shot",
			desc: "Dice-driven horse racing: buy horses, bet, and chain concession bonuses before three horses cross the line",
			rules: "Goal: after the race, the player with the most money wins; money = cash + purses + bet payouts + jockey-set bonuses.\nSetup:\n· 8 horses start at the line on a 15-space track; the last 4 spaces form the No Bet zone.\n· Each player starts with $12, 3 wild horseshoes, and a random start card.\n· The start card pre-marks 4 concession squares and 2 starting bets.\nRound sequence:\nThe active player rolls both dice. The horse die selects a horse, and the movement die moves it one to three spaces. Every horse marked on that horse’s secondary movement bar then advances one space.\nStarting with the active player and proceeding clockwise, each player chooses and takes one of the following actions:\n· Concession: mark a square of the rolled number on your 4×4 grid; completing a full row or column grants a bonus of your choice.\n· Helmet: mark that horse’s helmet; you may bet on your helmeted horses even past the No Bet line.\n· Jersey: mark that horse’s jersey and cross any one horse on its secondary movement bar (public, permanent).\n· Bet: bet $1-$3 on the rolled horse, stacking with earlier bets; horses past the No Bet line need your helmet; finished horses cannot be bet on.\n· Buy: pay the listed price to own that horse and trigger its “when bought” ability.\nWild horseshoes: spend one before an action to treat the horse die as any number (does not trigger abilities).\nFinishing: only dice and secondary movement can cross the finish line; direct movement from bonuses or abilities stops at the last space, and backward moves stop at the start.\nGame end: once 3 horses have finished, the current round plays out, then scoring begins.\n· Purses: owning the 1st, 2nd, or 3rd horse pays $35, $25, or $15.\n· Bets: finished horses pay bet × finish-position odds; horses past the No Bet line pay 1×; horses that never crossed it pay nothing.\n· Jockey sets: each horse with both your helmet and jersey pays $5.",
			optSet: "Horse card set",
			set1Name: "Set 1 · Star",
			set1Hint: "Recommended for the first game",
			set2Name: "Set 2 · Castle",
			set2Hint: "More betting and concession combos",
			set3Name: "Set 3 · Clover",
			set3Hint: "Revolves around $3 bets and last place",
			roundChip: "Round {{n}}",
			yourRoll: "Your turn: roll the dice!",
			waitRoll: "Waiting for {{name}} to roll…",
			moving: "Horses are moving…",
			yourAct: "Your action (horse {{n}})",
			waitAct: "Waiting for {{name}}…",
			actRoll: "Roll",
			actConcession: "Concession",
			actHelmet: "Helmet",
			actJersey: "Jersey",
			actBet: "Bet",
			actBuy: "Buy",
			actPass: "Pass",
			players: "Players",
			sections: "Game areas",
			tabRace: "Race",
			tabJockey: "Jockey",
			raceLanes: "Eight-lane racecourse",
			marketHint: "Pick a horse to see odds and bet",
			marketFootnote: "Choose another number to inspect its card",
			viewingBoard: "Viewing another player’s records",
			buyPrice: "Purchase",
			owner: "Owner",
			unowned: "For sale",
			myBet: "Bet",
			secondaryMove: "Secondary move",
			chooseHorse: "Choose this horse",
			concessionHint: "Complete a row or column for a reward",
			gridProgress: "{{n}} / 16 marked",
			jockeyHint: "Helmet and jersey on one horse earn +$5",
			marked: "Marked",
			rewardsHint: "Complete a line to claim one reward tile",
			rewardCash: "Cash",
			rewardBack2: "Back 2",
			rewardForward2: "Ahead 2",
			rewardBack3: "Back 3",
			rewardForward3: "Ahead 3",
			rewardTwoHorses: "Two horses",
			rewardOneHorse: "One horse",
			rewardFreeBet: "Free bet",
			rewardFree: "Free",
			rewardHorse: "Buy horse",
			actionHint: "Choose a tab and act on a game piece",
			waiting: "Waiting for other players",
			currentDice: "This roll",
			wilds: "Wilds ⭐×{{n}}",
			diceInfo: "🎲 Horse {{h}} moves {{m}}",
			pickCell: "Tap a highlighted square",
			pickHorse: "Tap a horse",
			cancel: "Cancel",
			skip: "Skip",
			modeCook: "Free $1 anywhere",
			modeStrung: "$1 and advance 1",
			modeLyp: "Free $1 (makes a line)",
			bonusPrompt: "{{n}} line(s) completed: pick a bonus",
			btPrompt2: "Pick two unfinished horses ({{n}} left)",
			btPrompt1: "Pick one horse",
			chainPrompt: "Chain Reaction: mark any grid square",
			charleyPrompt: "Charley Horse: move any horse back 1",
			miraclePrompt: "Miracle Worker: choose what to mark",
			mirGrid: "Grid",
			mirHelmet: "Helmet",
			mirJersey: "Jersey",
			mirPickGrid: "Tap an unmarked grid square",
			mirPickHorse: "Tap a horse to mark",
			mirParity: "Make It Rain: free $1 bets on which group?",
			odd: "Odd horses",
			even: "Even horses",
			mintPrompt: "Mint Condition: bet up to $2 more on {{name}}",
			jxPrompt: "Cross a horse on {{name}}’s movement bar",
			prPrompt: "Purple Rein: bet on {{name}} right away",
			noBetZone: "No Bet",
			finish: "Finish",
			winners: "Winners’ circle",
			market: "Horse market",
			myBoard: "My board",
			lines: "Lines {{n}}/8",
			bonuses: "Bonuses",
			oddsTag: "Odds {{a}}/{{b}}/{{c}}",
			ownerYou: "My horse",
			freeTag: "Free",
			bonusCash7: "+$7",
			bonusBack22: "Two horses back 2",
			bonusBet3: "Free $3 bet",
			bonusFwd22: "Two horses forward 2",
			bonusBack3: "One horse back 3",
			bonusFwd3: "One horse forward 3",
			bonusHelmet: "Free helmet",
			bonusJersey: "Free jersey",
			bonusHorse: "Free horse",
			h1_1: "Chain Reaction",
			h1_2: "Too Lucky",
			h1_3: "Scatter Shot",
			h1_4: "Early Bird Special",
			h1_5: "Charley Horse",
			h1_6: "Miracle Worker",
			h1_7: "Better Safe Than Sorry",
			h1_8: "Nitro Nellie",
			h2_1: "Row Your Boat",
			h2_2: "Make It Rain",
			h2_3: "Cook the Books",
			h2_4: "Mint Condition",
			h2_5: "Bottom Dollar",
			h2_6: "Dirty Laundry",
			h2_7: "Cheer Up Buttercup",
			h2_8: "Donut Dollie",
			h3_1: "Strung Along",
			h3_2: "Dollar Menu",
			h3_3: "Pay It Forward",
			h3_4: "Flex Your Quads",
			h3_5: "The Sting",
			h3_6: "Night Mare",
			h3_7: "Line Your Pockets",
			h3_8: "Purple Rein",
			a1_1: "Concession: when you complete a column, mark any extra square",
			a1_2: "When you roll a 2 on your turn, gain $2",
			a1_3: "Concession: you may mark squares one number above or below the roll",
			a1_4: "Your bets are free on horses you have not bet on",
			a1_5: "Concession: when you complete a row, move any horse back 1",
			a1_6: "When bought: mark any grid square, helmet, or jersey",
			a1_7: "Scoring: gain $2 per horse you have bet on",
			a1_8: "When you take the Helmet action, this horse advances 1",
			a2_1: "Concession: when you complete a row, gain $2",
			a2_2: "When bought: place a free $1 bet on every odd or every even horse",
			a2_3: "Bet action may instead place a free $1 bet on any horse",
			a2_4: "When you take the Helmet action, bet up to $2 more on that horse",
			a2_5: "Scoring: gain cash equal to your total bets on horses that crossed the No Bet line but did not finish",
			a2_6: "Jersey action may instead mark a horse you have bet on",
			a2_7: "When you bet while this horse is last (or tied), it advances 3",
			a2_8: "When your concession bonus moves this horse, it moves 1 extra",
			a3_1: "Your bet on this horse may instead be $1 and advance it 1",
			a3_2: "Your $3 bet on a last-place (or tied) horse costs $1",
			a3_3: "Your $3 bet on a horse sharing a space with another horse advances every horse on that space by 1",
			a3_4: "You may bet $4; at scoring, lose $4 per unfinished horse you bet on",
			a3_5: "Your $3 bet on a last-place (or tied) horse moves the leaders back 1",
			a3_6: "You may bet on horse 8 without a helmet; when bought, others’ bets on horse 8 drop $1",
			a3_7: "If the bet horse’s number would complete a row or column, the bet is a free $1",
			a3_8: "When you complete a helmet+jersey pair, you may bet on that horse at once",
			errOver: "The game is over",
			errNotYourTurn: "Not your turn",
			errNoPending: "Nothing to resolve",
			errPendingFirst: "Resolve the current choice first",
			errBadChoice: "Invalid choice",
			errBadCell: "Cannot mark this square",
			errBadHorse: "Cannot pick this horse",
			errNoWild: "No wild horseshoes left",
			errNoCash: "Not enough cash",
			errNoBet: "Cannot bet on this horse now",
			hintRoll: "Roll the dice",
			hintConcession: "Mark a concession square",
			hintHelmet: "Mark {{name}}’s helmet",
			hintJersey: "Mark {{name}}’s jersey",
			hintBet: "Bet ${{n}} on {{name}}",
			hintBuy: "Buy {{name}}",
			hintPass: "Pass",
			hintChoose: "Resolve the pending choice"
		}
	}
};
//#endregion
export { Ze as default };
