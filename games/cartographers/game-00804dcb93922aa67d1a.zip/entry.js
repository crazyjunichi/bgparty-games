import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { GameScreen as a } from "@bgparty/sdk/ui/game-screen";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { useWakeLock as c } from "@bgparty/sdk/use-wake-lock";
import { IconBack as l, IconCheck as u, IconClose as d, IconMirror as f, IconRotate as p } from "@bgparty/sdk/icons";
import { seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { ConfirmButton as _ } from "@bgparty/sdk/confirm-button";
import { OptionRadio as te, OptionSection as v, OptionSwitch as y } from "@bgparty/sdk/ui/game-options";
//#region src/games/cartographers/data.ts
var b = [
	1,
	2,
	4,
	8,
	16
], x = [
	8,
	8,
	7,
	6
], S = [
	{
		time: 1,
		terrains: [8],
		shapes: [[
			[0, 0],
			[0, 1],
			[0, 2]
		], [
			[2, 0],
			[1, 1],
			[2, 1],
			[0, 2],
			[1, 2]
		]],
		coin: !0
	},
	{
		time: 1,
		terrains: [4],
		shapes: [[[0, 0], [0, 1]], [
			[1, 0],
			[0, 1],
			[1, 1],
			[2, 1],
			[1, 2]
		]],
		coin: !0
	},
	{
		time: 1,
		terrains: [2],
		shapes: [[
			[0, 0],
			[0, 1],
			[1, 1]
		], [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1],
			[1, 1]
		]],
		coin: !0
	},
	{
		time: 1,
		terrains: [1],
		shapes: [[[0, 0], [1, 1]], [
			[0, 0],
			[0, 1],
			[1, 1],
			[1, 2]
		]],
		coin: !0
	},
	{
		time: 2,
		terrains: [4, 8],
		shapes: [[
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1],
			[0, 2]
		]],
		coin: !1
	},
	{
		time: 2,
		terrains: [2, 4],
		shapes: [[
			[0, 0],
			[0, 1],
			[0, 2],
			[1, 1]
		]],
		coin: !1
	},
	{
		time: 2,
		terrains: [1, 4],
		shapes: [[
			[0, 0],
			[1, 0],
			[2, 0],
			[2, 1]
		]],
		coin: !1
	},
	{
		time: 2,
		terrains: [1, 2],
		shapes: [[
			[1, 0],
			[2, 0],
			[0, 1],
			[1, 1]
		]],
		coin: !1
	},
	{
		time: 2,
		terrains: [1, 8],
		shapes: [[
			[0, 0],
			[0, 1],
			[0, 2],
			[1, 1],
			[2, 1]
		]],
		coin: !1
	},
	{
		time: 2,
		terrains: [2, 8],
		shapes: [[
			[0, 0],
			[1, 0],
			[2, 0],
			[3, 0]
		]],
		coin: !1
	},
	{
		time: 0,
		terrains: [...b],
		shapes: [[[0, 0]]],
		coin: !1
	}
], C = [
	{
		shape: [
			[0, 0],
			[1, 1],
			[2, 2]
		],
		corner: 2,
		clockwise: !1,
		direction: -1
	},
	{
		shape: [
			[0, 0],
			[2, 0],
			[0, 1],
			[2, 1]
		],
		corner: 1,
		clockwise: !0,
		direction: 1
	},
	{
		shape: [
			[0, 0],
			[0, 1],
			[1, 1],
			[0, 2]
		],
		corner: 3,
		clockwise: !0,
		direction: 1
	},
	{
		shape: [
			[0, 0],
			[1, 0],
			[0, 1],
			[0, 2],
			[1, 2]
		],
		corner: 0,
		clockwise: !1,
		direction: -1
	},
	{
		shape: [
			[0, 0],
			[0, 1],
			[1, 1]
		],
		corner: 0,
		clockwise: !1,
		direction: -1
	},
	{
		shape: [
			[1, 0],
			[0, 1],
			[1, 1],
			[0, 2]
		],
		corner: 1,
		clockwise: !0,
		direction: 1
	},
	{
		shape: [
			[0, 0],
			[1, 0],
			[2, 0]
		],
		corner: 2,
		clockwise: !0,
		direction: 1
	},
	{
		shape: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1]
		],
		corner: 3,
		clockwise: !1,
		direction: -1
	}
], w = (e) => e.map(([e, t]) => t * 11 + e), T = {
	A: {
		mountains: w([
			[3, 1],
			[8, 2],
			[5, 5],
			[2, 8],
			[7, 9]
		]),
		ruins: w([
			[5, 1],
			[1, 2],
			[9, 2],
			[1, 8],
			[9, 8],
			[5, 9]
		]),
		wasteland: []
	},
	B: {
		mountains: w([
			[8, 1],
			[3, 2],
			[5, 7],
			[9, 8],
			[2, 9]
		]),
		ruins: w([
			[6, 1],
			[2, 2],
			[6, 4],
			[1, 6],
			[8, 7],
			[3, 9]
		]),
		wasteland: w([
			[5, 3],
			[4, 4],
			[5, 4],
			[4, 5],
			[5, 5],
			[6, 5],
			[5, 6]
		])
	}
}, E = [
	2,
	0,
	1,
	0,
	0,
	1,
	1,
	3
], D = [
	25,
	22,
	17,
	18,
	24,
	22,
	20,
	27,
	16,
	16,
	21,
	20,
	24,
	24,
	24,
	20
], ne = [[0, 0]], O = [[0, 0], [1, 0]], k = [
	[0, 0],
	[1, 0],
	[0, 1],
	[1, 1]
], A = (e) => [
	e % 11 > 0 ? e - 1 : -1,
	e % 11 < 10 ? e + 1 : -1,
	e >= 11 ? e - 11 : -1,
	e < 110 ? e + 11 : -1
].filter((e) => e >= 0);
function j(e, t, n) {
	let r = e.map(([e, r]) => {
		let i = n ? -e : e, a = r;
		for (let e = 0; e < t; e++) [i, a] = [-a, i];
		return [i, a];
	}), i = Math.min(...r.map((e) => e[0])), a = Math.min(...r.map((e) => e[1]));
	return r.map(([e, t]) => [e - i, t - a]);
}
//#endregion
//#region src/games/cartographers/schema.ts
var M = t.object({
	map: t.enum(["A", "B"]).default("A"),
	promos: t.boolean().default(!1),
	skills: t.boolean().default(!1)
}).prefault({}), N = t.object({
	x: t.int().min(-5).max(10),
	y: t.int().min(-5).max(10),
	rotation: t.int().min(0).max(3),
	flip: t.boolean()
}), P = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draw"),
		placement: N,
		shape: t.int().min(0).max(1),
		terrain: t.union([
			t.literal(1),
			t.literal(2),
			t.literal(4),
			t.literal(8),
			t.literal(16)
		]),
		skill: t.int().min(2).max(4).optional()
	}),
	t.object({
		type: t.literal("skill"),
		skill: t.int().min(0).max(7),
		terrain: t.union([
			t.literal(1),
			t.literal(2),
			t.literal(4),
			t.literal(8),
			t.literal(16)
		]).optional()
	}),
	t.object({
		type: t.literal("extra"),
		placement: N
	}),
	t.object({
		type: t.literal("prepare"),
		acrobatics: t.boolean()
	}),
	t.object({ type: t.literal("ready") }),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("tick"),
		now: t.number().finite()
	})
]), F = t.object({
	skill: t.int(),
	shape: t.array(t.tuple([t.int(), t.int()])),
	terrain: t.int(),
	adjacent: t.array(t.int())
}), re = t.object({
	a: t.int(),
	b: t.int(),
	coins: t.int(),
	monsters: t.int(),
	total: t.int()
}), I = t.object({
	rid: t.string(),
	board: t.array(t.int().min(0).max(64)).length(121),
	coins: t.int().nonnegative(),
	claimedMountains: t.array(t.int()),
	usedSkill: t.boolean(),
	acrobatics: t.boolean(),
	prepared: t.boolean(),
	drawn: t.boolean(),
	ready: t.boolean(),
	extra: F.nullable(),
	mainCells: t.array(t.int()),
	mainShape: t.array(t.tuple([t.int(), t.int()])),
	mainTerrain: t.int(),
	seasons: t.array(re),
	total: t.int()
}), L = t.object({
	phase: t.enum([
		"prepare",
		"draw",
		"resolve",
		"season-end",
		"score",
		"season",
		"done"
	]),
	players: t.array(I),
	config: M,
	season: t.int().min(0).max(3),
	elapsed: t.int().nonnegative(),
	round: t.int().nonnegative(),
	card: t.int(),
	ruins: t.boolean(),
	edicts: t.array(t.int().min(0).max(15)).length(4),
	skills: t.array(t.int().min(0).max(7)),
	remaining: t.int().nonnegative(),
	history: t.array(t.int()),
	scoreStep: t.int().min(0).max(4),
	last: t.object({
		rid: t.string(),
		cells: t.array(t.int()),
		terrain: t.int(),
		kind: t.enum([
			"draw",
			"extra",
			"solo",
			"reveal",
			"score"
		]),
		serial: t.int()
	}).nullable()
}), ie = t.object({});
//#endregion
//#region src/games/cartographers/scoring.ts
function R(e, t) {
	let n = /* @__PURE__ */ new Set(), r = [];
	for (let i = 0; i < 121; i++) {
		if (!(e[i] & t) || n.has(i)) continue;
		let a = [i];
		n.add(i);
		for (let r = 0; r < a.length; r++) for (let i of A(a[r])) e[i] & t && !n.has(i) && (n.add(i), a.push(i));
		r.push(a);
	}
	return r;
}
var ae = (e) => e.reduce((t, n, r) => t + (!n && A(r).some((t) => e[t] & 16) ? 1 : 0), 0);
function z(e, t, n) {
	let r = (t, n) => !!(e[t] & n), i = (e, t) => A(e).some((e) => r(e, t)), a = (e) => e % 11 == 0 || e % 11 == 10 || e < 11 || e >= 110, o = (t, n) => e.reduce((e, r, i) => e + (r & t && n(i) ? 1 : 0), 0);
	if (t === 0) return o(1, a);
	if (t === 1) return Array.from({ length: 11 }, (t, n) => Number(e.slice(n * 11, n * 11 + 11).some((e) => e & 1)) + Number(e.some((e, t) => t % 11 === n && !!(e & 1)))).reduce((e, t) => e + t, 0);
	if (t === 2) return o(1, (t) => A(t).every((t) => e[t] !== 0));
	if (t === 3) {
		let t = /* @__PURE__ */ new Set();
		for (let n of R(e, 1)) {
			let e = new Set(n.flatMap(A).filter((e) => r(e, 32)));
			if (e.size >= 2) for (let n of e) t.add(n);
		}
		return t.size * 3;
	}
	if (t === 4) return o(8, (e) => i(e, 4)) + o(4, (e) => i(e, 8));
	if (t === 5) return o(8, (e) => i(e, 32)) * 2 + o(4, (e) => i(e, 32));
	if (t === 6) {
		let e = T[n].ruins;
		return o(8, (t) => A(t).some((t) => e.includes(t))) + o(4, (t) => e.includes(t)) * 3;
	}
	if (t === 7) return [4, 8].reduce((t, n) => t + R(e, n).filter((e) => e.every((e) => !a(e) && !i(e, n === 4 ? 8 : 4))).length * 3, 0);
	let s = () => R(e, 2);
	if (t === 8) return s().filter((e) => e.length >= 6).length * 8;
	if (t === 9) return Math.max(0, ...s().filter((e) => e.every((e) => !i(e, 32))).map((e) => e.length));
	if (t === 10) return s().filter((t) => {
		let n = 0;
		for (let r of t) for (let t of A(r)) n |= e[t] & 61;
		return [
			1,
			4,
			8,
			16,
			32
		].filter((e) => n & e).length >= 3;
	}).length * 3;
	if (t === 11) return (s().map((e) => e.length).sort((e, t) => t - e)[1] ?? 0) * 2;
	if (t === 12) return Array.from({ length: 11 }, (t, n) => Number(e.slice(n * 11, n * 11 + 11).every(Boolean)) + Number(e.every((e, t) => t % 11 !== n || e !== 0))).reduce((e, t) => e + t, 0) * 6;
	if (t === 13) {
		let t = 0, n = Array(121).fill(0);
		for (let r = 0; r < 121; r++) if (e[r]) {
			let e = r % 11, i = Math.floor(r / 11);
			n[r] = 1 + (e && i ? Math.min(n[r - 1], n[r - 11], n[r - 12]) : 0), t = Math.max(t, n[r]);
		}
		return t * 3;
	}
	return t === 14 ? Array.from({ length: 11 }, (t, n) => Array.from({ length: 11 - n }, (t, r) => e[(n + r) * 11 + r]).every(Boolean) ? 3 : 0).reduce((e, t) => e + t, 0) : e.reduce((t, n, r) => t + (!n && A(r).every((t) => e[t] !== 0) ? 1 : 0), 0);
}
//#endregion
//#region src/games/cartographers/meta.ts
var B = {
	id: "cartographers",
	tier: "alpha",
	mechanics: ["roll-and-write", "tile-placement"],
	interactionTags: [],
	nameKey: "games.cartographers.name",
	descKey: "games.cartographers.desc",
	rulesKey: "games.cartographers.rules",
	icon: "🗺️",
	iconImg: "games/cartographers.webp",
	rulesUrl: { en: "https://cdn.shopify.com/s/files/1/0525/7753/4134/files/CART-Rulebook-Web.pdf" },
	minPlayers: 1,
	maxPlayers: 100,
	accent: "#386b57",
	releasedAt: "2026-10-31T12:50:33+08:00",
	search: {
		py: "wang guo zhi tu shi",
		init: "wgzts"
	},
	hotseat: "open",
	botDelayMs: 400
}, V = () => ({ code: "games.cartographers.invalid" });
function H(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var U = (e, t, n, r, i) => {
	e.last = {
		rid: t,
		cells: n,
		terrain: r,
		kind: i,
		serial: (e.last?.serial ?? 0) + 1
	};
};
function W(e, t) {
	let n = e.players.findIndex((e) => e.rid === t);
	if (n < 0) return;
	let r = e.card >= 20 && e.players.length > 1 ? C[e.card - 20].direction : 0;
	return e.players[(n - r + e.players.length) % e.players.length];
}
function G(e, t, n, r = !1, i = []) {
	let a = [];
	for (let [i, o] of j(t, n.rotation, n.flip)) {
		let t = n.x + i, s = n.y + o;
		if (t < 0 || t > 10 || s < 0 || s > 10) {
			if (r) continue;
			return null;
		}
		let c = s * 11 + t;
		if (e[c]) return null;
		a.push(c);
	}
	return a.length && (!i.length || a.some((e) => i.includes(e))) ? a : null;
}
function K(e, t, n = !1, r = [], i = !1) {
	let a = [], o = /* @__PURE__ */ new Set();
	for (let s = 0; s < (i ? 1 : 2); s++) for (let c = 0; c < (i ? 1 : 4); c++) {
		let i = j(t, c, !!s), l = i.map((e) => e.join(",")).sort().join(";");
		if (o.has(l)) continue;
		o.add(l);
		let u = Math.max(...i.map((e) => e[0])) + 1, d = Math.max(...i.map((e) => e[1])) + 1;
		for (let i = n ? 1 - d : 0; i < 11; i++) for (let o = n ? 1 - u : 0; o < 11; o++) {
			let l = {
				x: o,
				y: i,
				rotation: c,
				flip: !!s
			};
			G(e, t, l, n, r) && a.push(l);
		}
	}
	return a;
}
function q(e, t, n) {
	let r = W(e, t), i = e.card >= 20, a = S[e.card], o = !i && e.ruins ? T[e.config.map].ruins.filter((e) => !r.board[e]) : [], s = i ? [r.acrobatics ? O : C[e.card - 20].shape] : a.shapes, c = i ? [16] : a.terrains, l = !i && e.ruins && o.length === 0 || !s.some((e) => K(r.board, e, !1, o).length);
	return n === void 0 && l && (s = [ne], c = i ? [16] : [...b]), n === 2 && (s = [k]), n === 4 && (c = [2]), {
		shapes: s,
		terrains: c,
		fallback: n === void 0 && l,
		clip: n === 3,
		coin: !i && a.coin && n !== 2,
		ruins: n === void 0 && l ? [] : o
	};
}
function J(e, t, n) {
	return e.skills.includes(n) && !t.usedSkill && !t.extra && t.coins >= E[n] && e.phase !== "done" && e.phase !== "score" && e.phase !== "resolve";
}
function Y(e, t) {
	e.coins -= E[t], e.usedSkill = !0, e.ready = !1;
}
function oe(e, t, n, r, i, a) {
	for (let e of n) t.board[e] = r;
	i && t.coins++;
	for (let n of T[e.config.map].mountains) !t.claimedMountains.includes(n) && A(n).every((e) => t.board[e] !== 0) && (t.claimedMountains.push(n), t.coins++);
	U(e, t.rid, n, r, a);
}
function se(e) {
	let t = e.ambushPool.pop();
	e.deck = H(e, [
		...Array.from({ length: 13 }, (e, t) => t),
		...e.deck.filter((e) => e >= 20),
		...t === void 0 ? [] : [t]
	]), e.elapsed = 0, e.ruins = !1;
}
function X(e) {
	for (let t of e.players) t.prepared = !1, t.drawn = !1, t.ready = !1, t.acrobatics = !1, t.extra = null, t.mainCells = [], t.mainShape = [], t.mainTerrain = 0;
	let t = e.deck.pop();
	for (; t === 11 || t === 12;) e.history.push(t), e.ruins = !0, t = e.deck.pop();
	if (t !== void 0) {
		e.card = t, e.history.push(t), e.round++, e.elapsed += t < 11 ? S[t].time : 0, e.phase = t >= 20 ? "prepare" : "draw";
		for (let n of e.players) n.prepared = t < 20 || !J(e, n, 0);
		t >= 20 && e.players.every((e) => e.prepared) && (e.phase = "resolve"), U(e, "", [], 0, "reveal");
	}
}
function ce(t, n, r) {
	let i = {
		phase: "draw",
		players: [],
		config: t,
		season: 0,
		elapsed: 0,
		round: 0,
		card: 0,
		ruins: !1,
		edicts: [],
		skills: [],
		history: [],
		scoreStep: 0,
		last: null,
		seed: r,
		cursor: 0,
		deck: [],
		ambushPool: []
	}, a = T[t.map];
	return i.players = n.map((e) => {
		let t = Array(121).fill(0);
		for (let e of a.mountains) t[e] = 32;
		for (let e of a.wasteland) t[e] = 64;
		return {
			rid: e,
			board: t,
			coins: 0,
			claimedMountains: [],
			usedSkill: !1,
			acrobatics: !1,
			prepared: !1,
			drawn: !1,
			ready: !1,
			extra: null,
			mainCells: [],
			mainShape: [],
			mainTerrain: 0,
			seasons: [],
			total: 0
		};
	}), i.edicts = H(i, [
		0,
		1,
		2,
		3
	].map((t) => t * 4 + e(i.seed, i.cursor++, 4))), i.skills = t.skills ? H(i, [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7
	]).slice(0, 3) : [], i.ambushPool = H(i, Array.from({ length: t.promos ? 8 : 4 }, (e, t) => 20 + t)), se(i), X(i), { state: i };
}
function le(e, t, n) {
	let r = C[n], i = 11 - (Math.max(...t.map((e) => e[0])) + 1), a = 11 - (Math.max(...t.map((e) => e[1])) + 1);
	for (let n = 0; n <= Math.min(i, a) / 2; n++) {
		let o = [], s = n, c = n, l = i - n, u = a - n;
		for (let e = s; e <= l; e++) o.push([e, c]);
		for (let e = c + 1; e <= u; e++) o.push([l, e]);
		for (let e = l - 1; e >= s; e--) o.push([e, u]);
		for (let e = u - 1; e > c; e--) o.push([s, e]);
		let d = [
			[s, c],
			[l, c],
			[l, u],
			[s, u]
		][r.corner], f = o.findIndex(([e, t]) => e === d[0] && t === d[1]);
		for (let n = 0; n < o.length; n++) {
			let [i, a] = o[(f + (r.clockwise ? n : -n) + o.length) % o.length], s = {
				x: i,
				y: a,
				rotation: 0,
				flip: !1
			};
			if (G(e, t, s)) return s;
		}
	}
	return null;
}
function ue(e) {
	if (!e.extra) return [];
	let t = e.extra;
	return K(e.board, t.shape).filter((n) => {
		let r = G(e.board, t.shape, n);
		return !t.adjacent.length || r.some((e) => A(e).some((e) => t.adjacent.includes(e)));
	});
}
function de(e) {
	if (e.phase = "draw", e.players.length === 1) {
		let t = e.players[0], n = t.acrobatics ? O : C[e.card - 20].shape, r = le(t.board, n, e.card - 20);
		if (r) {
			let i = G(t.board, n, r);
			oe(e, t, i, 16, !1, "solo"), t.mainCells = i, t.mainShape = n, t.mainTerrain = 16;
		}
		t.drawn = !0;
	}
}
function fe(e) {
	if (e.phase === "score") {
		if (e.scoreStep === 4) {
			e.phase = e.season === 3 ? "done" : "season";
			for (let t of e.players) t.ready = !1;
			return;
		}
		let t = e.scoreStep;
		for (let n of e.players) {
			let r = n.seasons[e.season], i = t === 0 ? z(n.board, e.edicts[e.season], e.config.map) : t === 1 ? z(n.board, e.edicts[(e.season + 1) % 4], e.config.map) : t === 2 ? n.coins : -ae(n.board);
			t === 0 ? r.a = i : t === 1 ? r.b = i : t === 2 ? r.coins = i : r.monsters = -i, r.total += i, n.total += i;
		}
		e.scoreStep++, U(e, "", [], 0, "score");
		return;
	}
	if (e.phase === "resolve") {
		if (e.card >= 20 && !e.players.some((e) => e.drawn)) {
			de(e);
			return;
		}
		if (e.players.every((e) => e.ready)) {
			if (e.elapsed >= x[e.season]) {
				e.phase = "season-end";
				for (let t of e.players) t.ready = !1;
			} else e.card < 20 && (e.ruins = !1), X(e);
		}
	}
}
function pe(e, t, n) {
	if (t.type === "tick") {
		if (n.by !== "$engine" || e.phase !== "resolve" && e.phase !== "score") return V();
		let t = structuredClone(e);
		return fe(t), { state: t };
	}
	if (e.phase === "done" || e.phase === "score" || e.phase === "resolve") return V();
	let r = structuredClone(e), i = r.players.find((e) => e.rid === n.by);
	if (!i) return V();
	if (t.type === "prepare") {
		if (r.phase !== "prepare" || i.prepared) return V();
		if (t.acrobatics) {
			if (!J(r, i, 0)) return V();
			Y(i, 0), i.acrobatics = !0;
		}
		return i.prepared = !0, r.players.every((e) => e.prepared) && (r.phase = "resolve"), { state: r };
	}
	if (t.type === "skill") {
		let e = t.skill;
		if (!J(r, i, e) || i.ready) return V();
		if (e === 5) {
			if (![
				"draw",
				"prepare",
				"season-end",
				"season"
			].includes(r.phase)) return V();
			i.extra = {
				skill: e,
				shape: ne,
				terrain: 6,
				adjacent: []
			};
		} else if ([
			1,
			6,
			7
		].includes(e) && r.phase === "draw" && i.mainCells.length && (e !== 7 || r.card < 20)) {
			let n = e === 1 ? i.mainCells : e === 6 ? i.board.flatMap((e, t) => e & 16 ? [t] : []) : [];
			if (e === 6 && !n.length) return V();
			let a = r.card >= 20 ? [16] : S[r.card].terrains, o = e === 6 ? t.terrain ?? a[0] : i.mainTerrain;
			if (e === 6 && !a.includes(o)) return V();
			i.extra = {
				skill: e,
				shape: e === 1 ? ne : e === 6 ? O : i.mainShape,
				terrain: o,
				adjacent: n
			};
		} else return V();
		return ue(i).length ? (Y(i, e), { state: r }) : V();
	}
	if (t.type === "extra") {
		if (!i.extra || i.ready) return V();
		let e = i.extra, n = G(i.board, e.shape, t.placement);
		return !n || e.adjacent.length && !n.some((t) => A(t).some((t) => e.adjacent.includes(t))) ? V() : (oe(r, i, n, e.terrain, !1, "extra"), i.extra = null, { state: r });
	}
	if (t.type === "draw") {
		if (r.phase !== "draw" || i.drawn || i.extra || r.card >= 20 && r.players.length === 1) return V();
		let e = W(r, i.rid), n = q(r, i.rid, t.skill);
		if (t.skill !== void 0 && (r.card >= 20 || !J(r, i, t.skill)) || !n.terrains.includes(t.terrain) || !n.shapes[t.shape] || r.ruins && r.card < 20 && !n.fallback && !n.ruins.length) return V();
		let a = n.shapes[t.shape], o = G(e.board, a, t.placement, n.clip, n.ruins);
		return o ? (t.skill !== void 0 && Y(i, t.skill), oe(r, e, o, t.terrain, !n.fallback && n.coin && t.shape === 0, "draw"), i.drawn = !0, e.mainCells = o, e.mainShape = a, e.mainTerrain = t.terrain, { state: r }) : V();
	}
	if (t.type === "pass") return r.phase !== "draw" || i.drawn || i.extra || W(r, i.rid).board.some((e) => !e) ? V() : (i.drawn = !0, { state: r });
	if (t.type === "ready") {
		if (i.extra || i.ready || r.phase === "draw" && !i.drawn || ![
			"draw",
			"season-end",
			"season"
		].includes(r.phase)) return V();
		if (i.ready = !0, r.players.every((e) => e.ready)) {
			if (r.phase === "season-end") {
				r.phase = "score", r.scoreStep = 0;
				for (let e of r.players) e.seasons.push({
					a: 0,
					b: 0,
					coins: 0,
					monsters: 0,
					total: 0
				});
			} else if (r.phase === "season") {
				r.season++;
				for (let e of r.players) e.usedSkill = !1;
				se(r), X(r);
			} else r.phase = "resolve";
		}
		return { state: r };
	}
	return V();
}
function me(e) {
	return {
		public: {
			phase: e.phase,
			players: e.players,
			config: e.config,
			season: e.season,
			elapsed: e.elapsed,
			round: e.round,
			card: e.card,
			ruins: e.ruins,
			edicts: e.edicts,
			skills: e.skills,
			remaining: e.deck.length,
			history: e.history,
			scoreStep: e.scoreStep,
			last: e.last
		},
		private: {}
	};
}
function he(e) {
	let t = Object.fromEntries(e.players.map((e) => [e.rid, e.total]));
	if (e.phase !== "done") return {
		phase: e.phase,
		scores: t
	};
	let n = [...e.players].sort((e, t) => t.total - e.total || e.seasons.reduce((e, t) => e + t.monsters, 0) - t.seasons.reduce((e, t) => e + t.monsters, 0)), r = n[0];
	return {
		phase: e.phase,
		scores: t,
		ranking: n.map((e) => e.rid),
		winner: n.filter((e) => e.total === r.total && e.seasons.reduce((e, t) => e + t.monsters, 0) === r.seasons.reduce((e, t) => e + t.monsters, 0)).map((e) => e.rid)
	};
}
var ge = {
	meta: B,
	saveCompatibility: { version: "1" },
	schemas: {
		action: P,
		publicView: L,
		privateView: ie,
		config: M
	},
	setup: ce,
	reduce: pe,
	viewFor: me,
	status: he,
	nextTickIn: (e) => e.phase === "resolve" ? 550 : e.phase === "score" ? 750 : null
}, _e = [
	"games.cartographers.explore0",
	"games.cartographers.explore1",
	"games.cartographers.explore2",
	"games.cartographers.explore3",
	"games.cartographers.explore4",
	"games.cartographers.explore5",
	"games.cartographers.explore6",
	"games.cartographers.explore7",
	"games.cartographers.explore8",
	"games.cartographers.explore9",
	"games.cartographers.explore10",
	"games.cartographers.explore11",
	"games.cartographers.explore12"
], ve = [
	"games.cartographers.ambush0",
	"games.cartographers.ambush1",
	"games.cartographers.ambush2",
	"games.cartographers.ambush3",
	"games.cartographers.ambush4",
	"games.cartographers.ambush5",
	"games.cartographers.ambush6",
	"games.cartographers.ambush7"
], Z = [
	"games.cartographers.edict0",
	"games.cartographers.edict1",
	"games.cartographers.edict2",
	"games.cartographers.edict3",
	"games.cartographers.edict4",
	"games.cartographers.edict5",
	"games.cartographers.edict6",
	"games.cartographers.edict7",
	"games.cartographers.edict8",
	"games.cartographers.edict9",
	"games.cartographers.edict10",
	"games.cartographers.edict11",
	"games.cartographers.edict12",
	"games.cartographers.edict13",
	"games.cartographers.edict14",
	"games.cartographers.edict15"
], ye = [
	"games.cartographers.score0",
	"games.cartographers.score1",
	"games.cartographers.score2",
	"games.cartographers.score3",
	"games.cartographers.score4",
	"games.cartographers.score5",
	"games.cartographers.score6",
	"games.cartographers.score7",
	"games.cartographers.score8",
	"games.cartographers.score9",
	"games.cartographers.score10",
	"games.cartographers.score11",
	"games.cartographers.score12",
	"games.cartographers.score13",
	"games.cartographers.score14",
	"games.cartographers.score15"
], be = [
	"games.cartographers.skill0",
	"games.cartographers.skill1",
	"games.cartographers.skill2",
	"games.cartographers.skill3",
	"games.cartographers.skill4",
	"games.cartographers.skill5",
	"games.cartographers.skill6",
	"games.cartographers.skill7"
], xe = [
	"games.cartographers.skillRule0",
	"games.cartographers.skillRule1",
	"games.cartographers.skillRule2",
	"games.cartographers.skillRule3",
	"games.cartographers.skillRule4",
	"games.cartographers.skillRule5",
	"games.cartographers.skillRule6",
	"games.cartographers.skillRule7"
], Se = [
	"games.cartographers.spring",
	"games.cartographers.summer",
	"games.cartographers.fall",
	"games.cartographers.winter"
], Ce = {
	0: "games.cartographers.empty",
	1: "games.cartographers.forest",
	2: "games.cartographers.village",
	4: "games.cartographers.farm",
	8: "games.cartographers.water",
	16: "games.cartographers.monster",
	32: "games.cartographers.mountain",
	64: "games.cartographers.wasteland",
	6: "games.cartographers.dual"
}, we = {
	prepare: "games.cartographers.prepare",
	draw: "games.cartographers.draw",
	resolve: "games.cartographers.resolve",
	"season-end": "games.cartographers.season-end",
	score: "games.cartographers.score",
	season: "games.cartographers.season",
	done: "games.cartographers.done"
}, Te = [
	"games.cartographers.title0",
	"games.cartographers.title1",
	"games.cartographers.title2",
	"games.cartographers.title3",
	"games.cartographers.title4",
	"games.cartographers.title5",
	"games.cartographers.title6",
	"games.cartographers.title7"
], Ee = {
	1: "forest",
	2: "village",
	4: "farm",
	8: "water",
	16: "monster",
	32: "mountain"
}, Q = (e) => `games/cartographers/${e}.svg`;
function $({ terrain: e, className: t = "" }) {
	return e === 6 ? /* @__PURE__ */ g("span", {
		className: `ctg-dual-icon ${t}`,
		children: [/* @__PURE__ */ h("img", {
			src: Q("farm"),
			alt: ""
		}), /* @__PURE__ */ h("img", {
			src: Q("village"),
			alt: ""
		})]
	}) : /* @__PURE__ */ h("img", {
		className: `ctg-terrain-icon ${t}`,
		src: Q(Ee[e] ?? "ruin"),
		alt: ""
	});
}
function De({ cells: e, rotation: t = 0, flip: n = !1 }) {
	let r = j(e, t, n), i = Math.max(...r.map((e) => e[0])) + 1, a = Math.max(...r.map((e) => e[1])) + 1;
	return /* @__PURE__ */ h("svg", {
		viewBox: `-2 -2 ${i * 20 + 4} ${a * 20 + 4}`,
		className: "ctg-shape",
		"aria-hidden": !0,
		children: r.map(([e, t]) => /* @__PURE__ */ h("rect", {
			x: e * 20,
			y: t * 20,
			width: "19",
			height: "19",
			rx: "1",
			fill: "currentColor",
			stroke: "#5c5341",
			strokeWidth: "1.5"
		}, `${e},${t}`))
	});
}
function Oe({ cells: e, valid: t, terrain: n }) {
	let r = new Set(e), i = "";
	for (let t of e) {
		let e = t % 11 * 100, n = Math.floor(t / 11) * 100;
		r.has(t - 11) || (i += `M${e},${n}h100`), (t % 11 == 10 || !r.has(t + 1)) && (i += `M${e + 100},${n}v100`), r.has(t + 11) || (i += `M${e + 100},${n + 100}h-100`), (t % 11 == 0 || !r.has(t - 1)) && (i += `M${e},${n + 100}v-100`);
	}
	return /* @__PURE__ */ g("svg", {
		className: "ctg-preview",
		viewBox: "0 0 1100 1100",
		"aria-hidden": !0,
		style: { "--ctg-preview-color": t ? "#226348" : "#a43c38" },
		children: [
			e.map((e) => /* @__PURE__ */ h("rect", {
				x: e % 11 * 100 + 3,
				y: Math.floor(e / 11) * 100 + 3,
				width: "94",
				height: "94",
				rx: "3",
				fill: t ? {
					1: "#3b8a57",
					2: "#b74332",
					4: "#c39a30",
					8: "#377eaa",
					16: "#853e94",
					6: "#b74332"
				}[n] ?? "#7a7765" : "#ad3838",
				opacity: ".52"
			}, e)),
			/* @__PURE__ */ h("path", {
				d: i,
				fill: "none",
				stroke: "white",
				strokeWidth: "9"
			}),
			/* @__PURE__ */ h("path", {
				d: i,
				fill: "none",
				stroke: "var(--ctg-preview-color)",
				strokeWidth: "7",
				strokeDasharray: "17 12",
				children: /* @__PURE__ */ h("animate", {
					attributeName: "stroke-dashoffset",
					from: "58",
					to: "0",
					dur: "1s",
					repeatCount: "indefinite"
				})
			})
		]
	});
}
//#endregion
//#region src/games/cartographers/view-player.tsx
function ke(e) {
	return /* @__PURE__ */ h(Me, {
		...e,
		pub: e.public
	});
}
function Ae({ detail: e, pub: t, onClose: i, onUse: a, allowed: o }) {
	let c = s(), l = r(null);
	n(() => {
		let e = document.activeElement;
		return l.current?.querySelector("button")?.focus(), () => e?.focus();
	}, []);
	let u = e.kind === "edict" ? c(Z[e.id]) : e.kind === "skill" ? c(be[e.id]) : c(e.id >= 20 ? ve[e.id - 20] : _e[e.id]);
	return /* @__PURE__ */ h("div", {
		className: "ctg-modal-mask",
		onClick: i,
		children: /* @__PURE__ */ g("div", {
			ref: l,
			className: "ctg-detail",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": u,
			onClick: (e) => e.stopPropagation(),
			onKeyDown: (e) => {
				if (e.key === "Escape" && i(), e.key === "Tab") {
					let t = [...l.current.querySelectorAll("button:not(:disabled)")], n = t.indexOf(document.activeElement);
					e.preventDefault(), t[(n + (e.shiftKey ? -1 : 1) + t.length) % t.length]?.focus();
				}
			},
			children: [/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("h2", { children: u }), /* @__PURE__ */ h("button", {
				"aria-label": c("games.cartographers.close"),
				onClick: i,
				children: /* @__PURE__ */ h(d, { size: 22 })
			})] }), e.kind === "edict" ? /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h(je, { id: e.id }),
				/* @__PURE__ */ h("p", { children: c(ye[e.id]) }),
				/* @__PURE__ */ h("small", { children: c("games.cartographers.soloRating", { n: D[e.id] }) })
			] }) : e.kind === "skill" ? /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("img", {
					className: "ctg-detail-art",
					src: Q(`skill-${e.id}`),
					alt: ""
				}),
				/* @__PURE__ */ h("p", { children: c(xe[e.id]) }),
				o && (e.id === 6 ? /* @__PURE__ */ h("div", {
					className: "ctg-terrain-choices",
					children: (t.card >= 20 ? [16] : S[t.card].terrains).map((t) => /* @__PURE__ */ h("button", {
						"aria-label": c(Ce[t]),
						onClick: () => {
							a(e.id, t), i();
						},
						children: /* @__PURE__ */ h($, { terrain: t })
					}, t))
				}) : /* @__PURE__ */ h("button", {
					className: "ctg-primary",
					onClick: () => {
						a(e.id), i();
					},
					children: c("games.cartographers.useSkill", { name: u })
				}))
			] }) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("img", {
				className: "ctg-detail-art",
				src: Q(e.id >= 20 ? `ambush-${e.id - 20}` : `explore-${e.id}`),
				alt: ""
			}), /* @__PURE__ */ h("p", { children: c(t.card >= 20 ? "games.cartographers.ambushInstruction" : t.ruins ? "games.cartographers.ruinsRequired" : "games.cartographers.draw", { name: "" }) })] })]
		})
	});
}
function je({ id: e }) {
	return /* @__PURE__ */ h("div", {
		className: "ctg-edict-diagram",
		"aria-hidden": !0,
		children: [
			[
				1,
				1,
				1,
				0,
				0,
				1,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				0
			],
			[
				1,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				0,
				0,
				0,
				1
			],
			[
				1,
				4,
				0,
				0,
				0,
				4,
				1,
				4,
				0,
				0,
				0,
				4,
				0,
				0,
				0
			],
			[
				32,
				1,
				1,
				1,
				32,
				0,
				0,
				1,
				0,
				0,
				0,
				0,
				0,
				0,
				0
			],
			[
				4,
				8,
				4,
				8,
				4,
				8,
				4,
				8,
				4,
				8,
				4,
				8,
				4,
				8,
				4
			],
			[
				8,
				32,
				4,
				0,
				0,
				0,
				8,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0
			],
			[
				0,
				8,
				0,
				0,
				0,
				8,
				4,
				8,
				0,
				0,
				0,
				8,
				0,
				0,
				0
			],
			[
				0,
				0,
				0,
				0,
				0,
				0,
				4,
				4,
				4,
				0,
				0,
				0,
				0,
				0,
				0
			],
			[
				2,
				2,
				2,
				0,
				0,
				2,
				2,
				2,
				0,
				0,
				0,
				0,
				0,
				0,
				0
			],
			[
				2,
				2,
				2,
				0,
				0,
				2,
				2,
				0,
				0,
				32,
				0,
				0,
				0,
				0,
				0
			],
			[
				1,
				8,
				4,
				0,
				0,
				2,
				2,
				2,
				0,
				0,
				0,
				0,
				0,
				0,
				0
			],
			[
				2,
				2,
				2,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				2,
				2,
				0,
				0,
				0
			],
			[
				1,
				2,
				4,
				8,
				1,
				0,
				0,
				0,
				0,
				2,
				0,
				0,
				0,
				0,
				4
			],
			[
				1,
				2,
				4,
				0,
				0,
				8,
				1,
				2,
				0,
				0,
				4,
				8,
				1,
				0,
				0
			],
			[
				1,
				0,
				0,
				0,
				0,
				0,
				2,
				0,
				0,
				0,
				0,
				0,
				4,
				0,
				0
			],
			[
				1,
				2,
				4,
				0,
				0,
				8,
				0,
				1,
				0,
				0,
				1,
				2,
				4,
				0,
				0
			]
		][e].map((e, t) => /* @__PURE__ */ h("span", {
			className: `ctg-mini-cell ctg-terrain-${e}`,
			children: e > 0 && /* @__PURE__ */ h($, { terrain: e })
		}, t))
	});
}
function Me({ pub: e, members: t, myRid: n, send: r, readOnly: d = !1 }) {
	c();
	let _ = s(), te = o((e) => e.locale), v = e.players.find((e) => e.rid === n) ?? e.players[0], y = W(e, v.rid), b = `${e.round}:${n}:${v.extra?.skill ?? ""}:${v.drawn}`, [C, w] = i({
		key: "",
		shape: 0,
		terrain: 1,
		skill: void 0,
		position: null,
		rotation: 0,
		flip: !1
	}), [D, ne] = i({
		key: "",
		rid: ""
	}), [O, k] = i(null), M = !d && e.phase === "draw" && !v.ready, N = M && !v.drawn && !v.extra, P = M && !!v.extra || !d && !!v.extra && !v.ready, F = q(e, v.rid, C.key === b ? C.skill : void 0), re = v.extra?.terrain ?? F.terrains[0], I = C.key === b ? C : {
		key: b,
		shape: 0,
		terrain: re,
		skill: void 0,
		position: null,
		rotation: 0,
		flip: !1
	}, L = (e) => w({
		...I,
		...e,
		key: b
	}), ie = v.extra?.shape ?? F.shapes[I.shape] ?? F.shapes[0], R = v.extra?.terrain ?? I.terrain, ae = P ? v.rid : y.rid, z = e.phase === "draw" && !v.extra ? y.rid : v.rid, B = e.players.find((e) => e.rid === (D.key === b ? D.rid : z)) ?? v, V = (N || P) && B.rid === ae, H = I.position, U = (t) => {
		let n = G(B.board, ie, t, !P && F.clip, P ? [] : F.ruins);
		return !!n && (!v.extra?.adjacent.length || n.some((e) => A(e).some((e) => v.extra.adjacent.includes(e)))) && (P || !e.ruins || e.card >= 20 || F.fallback || F.ruins.length > 0);
	}, K = H !== null && V && U(H), Y = H ? j(ie, H.rotation, H.flip).flatMap(([e, t]) => {
		let n = e + H.x, r = t + H.y;
		return n >= 0 && n < 11 && r >= 0 && r < 11 ? [r * 11 + n] : [];
	}) : [], oe = (t) => !J(e, v, t) || v.ready || d ? !1 : [
		2,
		3,
		4
	].includes(t) ? N && e.card < 20 : t === 0 ? e.phase === "prepare" && !v.prepared : t === 5 ? [
		"draw",
		"prepare",
		"season-end",
		"season"
	].includes(e.phase) : e.phase === "draw" && v.mainCells.length > 0 && (t !== 7 || e.card < 20), se = (e, t) => {
		if ([
			2,
			3,
			4
		].includes(e)) {
			L({
				skill: e,
				shape: 0,
				terrain: e === 4 ? 2 : F.terrains[0],
				position: null
			});
			return;
		}
		if (e === 0) {
			r({
				type: "prepare",
				acrobatics: !0
			});
			return;
		}
		r({
			type: "skill",
			skill: e,
			terrain: t ?? I.terrain
		});
	}, X = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? ee(n, te) : e;
	}, ce = () => {
		K && H && (r(P ? {
			type: "extra",
			placement: H
		} : {
			type: "draw",
			shape: I.shape,
			terrain: R,
			placement: H,
			...I.skill === void 0 ? {} : { skill: I.skill }
		}), L({ position: null }));
	}, le = _(e.card >= 20 ? ve[e.card - 20] : _e[e.card]), ue = d ? _("games.cartographers.done") : v.ready ? _("games.cartographers.waiting") : v.extra ? _("games.cartographers.extra") : e.phase === "draw" && v.drawn ? _("games.cartographers.ready") : _(we[e.phase]), de = /* @__PURE__ */ g("div", {
		className: "ctg-transform-tools",
		children: [
			/* @__PURE__ */ h("button", {
				"aria-label": _("games.cartographers.rotate"),
				disabled: !V,
				onClick: () => {
					let e = (I.rotation + 1) % 4;
					L({
						rotation: e,
						position: H ? {
							...H,
							rotation: e
						} : null
					});
				},
				children: /* @__PURE__ */ h(p, { size: 19 })
			}),
			/* @__PURE__ */ h("button", {
				"aria-label": _("games.cartographers.flip"),
				"aria-pressed": I.flip,
				disabled: !V,
				onClick: () => {
					let e = !I.flip;
					L({
						flip: e,
						position: H ? {
							...H,
							flip: e
						} : null
					});
				},
				children: /* @__PURE__ */ h(f, { size: 19 })
			}),
			I.skill !== void 0 && /* @__PURE__ */ h("button", {
				onClick: () => L({
					skill: void 0,
					shape: 0,
					position: null,
					terrain: S[e.card].terrains[0]
				}),
				children: _("games.cartographers.cancel")
			})
		]
	});
	return /* @__PURE__ */ g(a, {
		adaptive: !0,
		className: "ctg-screen",
		scroll: !1,
		banner: /* @__PURE__ */ g("div", {
			className: "ctg-banner",
			inert: !!O,
			children: [/* @__PURE__ */ g("div", {
				className: "ctg-season-label",
				children: [
					/* @__PURE__ */ h("b", { children: _(Se[e.season]) }),
					/* @__PURE__ */ h("span", { children: _("games.cartographers.time", {
						n: e.elapsed,
						limit: x[e.season]
					}) }),
					/* @__PURE__ */ h("div", {
						className: "ctg-time-track",
						children: Array.from({ length: x[e.season] }, (t, n) => /* @__PURE__ */ h("i", { className: n < e.elapsed ? "ctg-time-filled" : "" }, n))
					})
				]
			}), /* @__PURE__ */ h("div", {
				className: "ctg-seats",
				children: e.players.map((e) => /* @__PURE__ */ g("button", {
					className: `ctg-seat${B.rid === e.rid ? " ctg-seat-selected" : ""}`,
					onClick: () => ne({
						key: b,
						rid: e.rid
					}),
					children: [/* @__PURE__ */ h("b", { children: X(e.rid) }), /* @__PURE__ */ g("span", { children: [
						/* @__PURE__ */ h("img", {
							src: Q("coin"),
							alt: _("games.cartographers.coins")
						}),
						e.coins,
						/* @__PURE__ */ h("em", { children: e.total }),
						e.ready && /* @__PURE__ */ h(u, { size: 16 })
					] })]
				}, e.rid))
			})]
		}),
		actionsHeight: "ctg-actions-height",
		actions: /* @__PURE__ */ g("div", {
			className: "ctg-actions",
			inert: !!O,
			children: [/* @__PURE__ */ h("span", {
				className: "ctg-phase",
				"aria-live": "polite",
				children: ue
			}), !d && e.phase === "prepare" && !v.prepared ? /* @__PURE__ */ h("button", {
				className: "ctg-primary",
				disabled: !!v.extra,
				onClick: () => r({
					type: "prepare",
					acrobatics: !1
				}),
				children: _("games.cartographers.notUsed")
			}) : !d && (e.phase === "season" || e.phase === "season-end") ? /* @__PURE__ */ h("button", {
				className: "ctg-primary",
				disabled: v.ready || !!v.extra,
				onClick: () => r({ type: "ready" }),
				children: _(e.phase === "season" ? "games.cartographers.next" : "games.cartographers.settle")
			}) : N && y.board.every(Boolean) ? /* @__PURE__ */ h("button", {
				className: "ctg-primary",
				onClick: () => r({ type: "pass" }),
				children: _("games.cartographers.skip")
			}) : V ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
				className: "ctg-quiet",
				disabled: !H,
				onClick: () => L({ position: null }),
				children: _("games.cartographers.cancel")
			}), /* @__PURE__ */ h("button", {
				className: "ctg-primary",
				disabled: !K,
				onClick: ce,
				children: _("games.cartographers.confirm")
			})] }) : M && v.drawn && !v.extra ? /* @__PURE__ */ h("button", {
				className: "ctg-primary",
				onClick: () => r({ type: "ready" }),
				children: _("games.cartographers.ready")
			}) : null]
		}),
		children: [/* @__PURE__ */ g("div", {
			className: "ctg-layout",
			inert: !!O,
			children: [
				/* @__PURE__ */ h("aside", {
					className: "ctg-edicts",
					children: e.edicts.map((t, n) => /* @__PURE__ */ g("button", {
						className: `ctg-edict${n === e.season || n === (e.season + 1) % 4 ? " ctg-edict-active" : ""}`,
						onClick: () => k({
							kind: "edict",
							id: t
						}),
						children: [
							/* @__PURE__ */ g("div", {
								className: "ctg-edict-head",
								children: [/* @__PURE__ */ h("span", { children: "ABCD"[n] }), /* @__PURE__ */ h("h3", { children: _(Z[t]) })]
							}),
							/* @__PURE__ */ h(je, { id: t }),
							/* @__PURE__ */ h("p", { children: _(ye[t]) })
						]
					}, n))
				}),
				/* @__PURE__ */ h("section", {
					className: "ctg-map-space",
					children: /* @__PURE__ */ g("div", {
						className: "ctg-paper",
						children: [
							/* @__PURE__ */ g("header", {
								className: "ctg-map-title",
								children: [
									/* @__PURE__ */ h("b", { children: _("games.cartographers.mapName", { name: X(B.rid) }) }),
									/* @__PURE__ */ h("small", { children: e.config.map }),
									B.rid !== n && V && /* @__PURE__ */ h("span", { children: _("games.cartographers.targetMap", { name: X(B.rid) }) })
								]
							}),
							/* @__PURE__ */ g("div", {
								className: "ctg-grid",
								role: "grid",
								"aria-label": _("games.cartographers.mapName", { name: X(B.rid) }),
								children: [B.board.map((t, n) => {
									let r = T[e.config.map].ruins.includes(n), i = V && !t && U({
										x: n % 11,
										y: Math.floor(n / 11),
										rotation: I.rotation,
										flip: I.flip
									}), a = e.last?.rid === B.rid && e.last.cells.includes(n);
									return /* @__PURE__ */ g("button", {
										role: "gridcell",
										className: `ctg-cell ctg-terrain-${t}${r && !t ? " ctg-ruin" : ""}${a ? " ctg-fresh" : ""}`,
										"aria-label": _("games.cartographers.cell", {
											row: Math.floor(n / 11) + 1,
											col: n % 11 + 1,
											terrain: _(Ce[t])
										}) + (r ? ` · ${_("games.cartographers.ruin")}` : ""),
										disabled: !V,
										onClick: () => L({ position: {
											x: n % 11,
											y: Math.floor(n / 11),
											rotation: I.rotation,
											flip: I.flip
										} }),
										children: [
											t && t !== 64 ? /* @__PURE__ */ h($, { terrain: t }) : r && !t ? /* @__PURE__ */ h("img", {
												src: Q("ruin"),
												alt: ""
											}) : null,
											t === 32 && B.claimedMountains.includes(n) && /* @__PURE__ */ h("img", {
												className: "ctg-mountain-coin",
												src: Q("coin"),
												alt: _("games.cartographers.coins")
											}),
											" ",
											i && /* @__PURE__ */ h("i", { className: "ctg-legal-dot" })
										]
									}, `${n}:${a ? e.last?.serial : 0}`);
								}), V && H && /* @__PURE__ */ h(Oe, {
									cells: Y,
									valid: K,
									terrain: R
								})]
							}),
							e.phase === "score" && e.scoreStep > 0 && /* @__PURE__ */ g("div", {
								className: "ctg-score-reveal",
								"aria-live": "polite",
								children: [/* @__PURE__ */ h("b", { children: e.scoreStep === 1 ? _(Z[e.edicts[e.season]]) : e.scoreStep === 2 ? _(Z[e.edicts[(e.season + 1) % 4]]) : _(e.scoreStep === 3 ? "games.cartographers.coins" : "games.cartographers.monsters") }), /* @__PURE__ */ h("strong", { children: e.scoreStep === 1 ? B.seasons[e.season].a : e.scoreStep === 2 ? B.seasons[e.season].b : e.scoreStep === 3 ? B.seasons[e.season].coins : `−${B.seasons[e.season].monsters}` })]
							}, `${e.season}:${e.scoreStep}`),
							/* @__PURE__ */ g("div", {
								className: "ctg-paper-scores",
								children: [B.seasons.map((t, n) => /* @__PURE__ */ g("span", {
									className: e.phase === "score" && n === e.season ? "ctg-scoring" : "",
									children: [/* @__PURE__ */ h("small", { children: _(Se[n]) }), /* @__PURE__ */ h("b", { children: t.total })]
								}, n)), /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h("small", { children: _("games.cartographers.total") }), /* @__PURE__ */ h("b", { children: B.total })] })]
							})
						]
					})
				}),
				/* @__PURE__ */ g("aside", {
					className: "ctg-exploration",
					children: [
						/* @__PURE__ */ g("article", {
							className: "ctg-explore-card",
							children: [
								/* @__PURE__ */ g("button", {
									className: "ctg-explore-hero",
									onClick: () => k({
										kind: "explore",
										id: e.card
									}),
									children: [/* @__PURE__ */ h("img", {
										src: Q(e.card >= 20 ? `ambush-${e.card - 20}` : `explore-${e.card}`),
										alt: ""
									}), /* @__PURE__ */ h("h2", { children: le })]
								}),
								/* @__PURE__ */ g("div", {
									className: "ctg-card-choices",
									children: [
										/* @__PURE__ */ h("div", {
											className: "ctg-terrain-choices",
											children: (v.extra ? [v.extra.terrain] : F.terrains).map((e) => /* @__PURE__ */ h("button", {
												disabled: !V || P,
												"aria-label": _(Ce[e]),
												"aria-pressed": R === e,
												className: R === e ? "ctg-choice-selected" : "",
												onClick: () => L({ terrain: e }),
												children: /* @__PURE__ */ h($, { terrain: e })
											}, e))
										}),
										/* @__PURE__ */ g("div", {
											className: "ctg-shape-and-tools",
											children: [/* @__PURE__ */ h("div", {
												className: "ctg-shape-choices",
												children: (v.extra ? [v.extra.shape] : F.shapes).map((e, t) => /* @__PURE__ */ g("button", {
													className: I.shape === t ? "ctg-choice-selected" : "",
													disabled: !V || P,
													"aria-label": `${_("games.cartographers.selected")} ${t + 1}`,
													"aria-pressed": I.shape === t,
													onClick: () => L({
														shape: t,
														position: null
													}),
													children: [/* @__PURE__ */ h(De, {
														cells: e,
														rotation: I.rotation,
														flip: I.flip
													}), F.coin && !F.fallback && t === 0 && !v.extra && /* @__PURE__ */ h("img", {
														className: "ctg-shape-coin",
														src: Q("coin"),
														alt: _("games.cartographers.coinShape")
													})]
												}, t))
											}), de]
										}),
										I.skill === 3 && V && H && /* @__PURE__ */ h("div", {
											className: "ctg-nudge",
											children: [
												[
													-1,
													0,
													"games.cartographers.left"
												],
												[
													0,
													-1,
													"games.cartographers.up"
												],
												[
													0,
													1,
													"games.cartographers.down"
												],
												[
													1,
													0,
													"games.cartographers.right"
												]
											].map(([e, t, n], r) => /* @__PURE__ */ h("button", {
												"aria-label": _(n),
												disabled: H.x + e < -5 || H.x + e > 10 || H.y + t < -5 || H.y + t > 10,
												onClick: () => L({ position: {
													...H,
													x: H.x + e,
													y: H.y + t
												} }),
												children: /* @__PURE__ */ h(l, {
													size: 16,
													style: { transform: `rotate(${[
														0,
														90,
														270,
														180
													][r]}deg)` }
												})
											}, r))
										})
									]
								}),
								F.fallback && N && /* @__PURE__ */ h("p", {
									className: "ctg-card-note",
									children: _("games.cartographers.fallback")
								}),
								e.ruins && e.card < 20 && !F.fallback && N && /* @__PURE__ */ h("p", {
									className: "ctg-card-note",
									children: _("games.cartographers.ruinsRequired")
								})
							]
						}, e.round),
						e.skills.length > 0 && /* @__PURE__ */ h("div", {
							className: "ctg-skill-row",
							children: e.skills.map((e) => /* @__PURE__ */ g("button", {
								className: `ctg-skill-card${I.skill === e ? " ctg-choice-selected" : ""}`,
								onClick: () => k({
									kind: "skill",
									id: e
								}),
								children: [
									/* @__PURE__ */ h("img", {
										src: Q(`skill-${e}`),
										alt: ""
									}),
									/* @__PURE__ */ h("b", { children: _(be[e]) }),
									/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h("img", {
										src: Q("coin"),
										alt: _("games.cartographers.coins")
									}), E[e]] })
								]
							}, e))
						}),
						v.usedSkill && e.skills.length > 0 && /* @__PURE__ */ h("p", {
							className: "ctg-used-label",
							children: _("games.cartographers.skillUsed")
						}),
						/* @__PURE__ */ g("div", {
							className: "ctg-deck",
							children: [
								/* @__PURE__ */ h("div", {
									className: "ctg-deck-back",
									"aria-hidden": !0
								}),
								/* @__PURE__ */ h("span", { children: _("games.cartographers.remaining", { n: e.remaining }) }),
								/* @__PURE__ */ h("small", { children: e.history.slice(-7).map((e, t) => /* @__PURE__ */ h("span", { children: e >= 20 ? "◆" : e > 10 ? "⌑" : S[e].time }, t)) })
							]
						})
					]
				})
			]
		}), O && /* @__PURE__ */ h(Ae, {
			detail: O,
			pub: e,
			onClose: () => k(null),
			onUse: se,
			allowed: O.kind === "skill" && oe(O.id)
		})]
	});
}
//#endregion
//#region src/games/cartographers/bot.ts
var Ne = {
	score: 1,
	coins: 2.5,
	compact: .28,
	mountain: .6,
	future: .5,
	monster: 1.4,
	breadth: 32
};
function Pe(e, t, n) {
	let r = e.players.find((e) => e.rid === t);
	if (!r || e.phase !== "draw" || r.drawn || r.extra || e.card >= 20 && e.players.length === 1) return [];
	let i = q(e, t, n), a = W(e, t);
	return e.ruins && e.card < 20 && !i.fallback && !i.ruins.length ? [] : i.shapes.flatMap((e, t) => K(a.board, e, i.clip, i.ruins).flatMap((e) => i.terrains.map((r) => ({
		type: "draw",
		placement: e,
		shape: t,
		terrain: r,
		...n === void 0 ? {} : { skill: n }
	}))));
}
function Fe(e, t, n) {
	let r = 0;
	for (let i = 0; i < 4; i++) {
		let a = Array.from({ length: 4 - e.season }, (t, n) => e.season + n).filter((e) => e === i || (e + 1) % 4 === i).length;
		r += z(t.board, e.edicts[i], e.config.map) * n.score * a;
	}
	let i = T[e.config.map].mountains.filter((e) => !t.claimedMountains.includes(e)).reduce((e, n) => e + A(n).filter((e) => t.board[e]).length, 0), a = 0, o = 0;
	for (let e = 0; e < 121; e++) t.board[e] ? a += A(e).filter((e) => t.board[e]).length : A(e).every((e) => t.board[e]) && o++;
	let s = t.board.filter((e) => e & 2).length * n.future;
	return r + t.coins * (4 - e.season) * n.coins + i * n.mountain + a * n.compact + s - ae(t.board) * n.monster * (4 - e.season) - o * .9;
}
function Ie(e, t, n, r, i, a = !1) {
	let o = W(e, t.rid), s = G(o.board, i.shapes[n.shape], n.placement, i.clip, i.ruins), c = [...o.board];
	for (let e of s) c[e] = n.terrain;
	let l = Number(i.coin && !i.fallback && n.shape === 0), u = T[e.config.map].mountains.filter((e) => !o.claimedMountains.includes(e) && A(e).every((e) => c[e])).length;
	if (a) return s.length * .15 + s.reduce((e, t) => e + A(t).filter((e) => o.board[e]).length * r.compact, 0) + (l + u) * (4 - e.season) * r.coins + s.reduce((e, t) => e + A(t).filter((e) => o.board[e] === 32).length * r.mountain, 0);
	let d = Fe(e, {
		...o,
		board: c,
		coins: o.coins + l + u - (n.skill === void 0 ? 0 : E[n.skill])
	}, r);
	return o.rid === t.rid ? d : -d;
}
function Le(e = Ne) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid);
		if (!i || i.ready || [
			"resolve",
			"score",
			"done"
		].includes(r.phase)) return null;
		if (i.extra) {
			let t = ue(i);
			if (!t.length) return null;
			let n = t[0], a = -Infinity;
			for (let o of t) {
				let t = [...i.board], s = G(t, i.extra.shape, o);
				for (let e of s) t[e] = i.extra.terrain;
				let c = Fe(r, {
					...i,
					board: t
				}, e);
				c > a && (a = c, n = o);
			}
			return { action: {
				type: "extra",
				placement: n
			} };
		}
		if (r.phase === "prepare") return i.prepared ? null : { action: {
			type: "prepare",
			acrobatics: n.difficulty === "normal" && J(r, i, 0) && r.season >= 2
		} };
		if (r.phase === "season" || r.phase === "season-end") return { action: { type: "ready" } };
		if (!i.drawn) {
			let t = Pe(r, i.rid);
			if (n.difficulty === "normal" && r.card < 20) for (let e of [
				2,
				3,
				4
			]) J(r, i, e) && (t = t.concat(Pe(r, i.rid, e)));
			if (!t.length) return { action: { type: "pass" } };
			if (n.difficulty === "weak") return { action: t[(r.round * 43 + i.board.filter(Boolean).length * 7) % t.length] };
			let a = /* @__PURE__ */ new Map();
			for (let e of t) a.has(e.skill ?? -1) || a.set(e.skill ?? -1, q(r, i.rid, e.skill));
			let o = t.map((t) => ({
				a: t,
				q: Ie(r, i, t, e, a.get(t.skill ?? -1), !0)
			})).sort((e, t) => t.q - e.q), s = o.slice(0, e.breadth);
			for (let e of [
				1,
				2,
				4,
				8,
				16
			]) s.push(...o.filter((t) => t.a.terrain === e).slice(0, 8));
			let c = s[0].a, l = -Infinity;
			for (let { a: t } of s) {
				let n = Ie(r, i, t, e, a.get(t.skill ?? -1));
				n > l && (l = n, c = t);
			}
			return { action: c };
		}
		if (n.difficulty === "normal" && i.mainCells.length) {
			for (let e of [
				1,
				6,
				7,
				5
			]) if (J(r, i, e) && (e !== 7 || r.card < 20)) {
				let t = e === 6 ? r.card >= 20 ? 16 : S[r.card].terrains[0] : i.mainTerrain, n = e === 1 ? i.mainCells : e === 6 ? i.board.flatMap((e, t) => e & 16 ? [t] : []) : [];
				if (e === 6 && !n.length) continue;
				let a = e === 1 || e === 5 ? [[0, 0]] : e === 6 ? [[0, 0], [1, 0]] : i.mainShape;
				if (ue({
					...i,
					extra: {
						skill: e,
						shape: a,
						terrain: e === 5 ? 6 : t,
						adjacent: n
					}
				}).length && E[e] <= Math.max(0, i.coins - Number(r.season === 0))) return { action: {
					type: "skill",
					skill: e,
					terrain: t
				} };
			}
		}
		return { action: { type: "ready" } };
	};
}
var Re = Le();
//#endregion
//#region src/games/cartographers/game-over.tsx
function ze({ public: e, members: t, myRid: a, result: c, hintCount: l, onPlayAgain: u, onBackToLobby: f }) {
	let p = e, m = s(), te = o((e) => e.locale), [v, y] = i(!0), b = r(null);
	n(() => {
		v && b.current?.querySelector(".ctg-result-layer button")?.focus();
	}, [v]);
	let x = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? ee(n, te) : e;
	}, S = c.ranking.map((e) => p.players.find((t) => t.rid === e)), C = p.players[0].total - p.edicts.reduce((e, t) => e + D[t], 0), w = [
		30,
		20,
		10,
		0,
		-5,
		-10,
		-20,
		-Infinity
	].findIndex((e) => C >= e);
	return /* @__PURE__ */ g("div", {
		ref: b,
		className: "ctg-screen ctg-over",
		onKeyDown: (e) => {
			if (v) {
				if (e.key === "Escape") {
					y(!1);
					return;
				}
				if (e.key === "Tab") {
					let t = [...b.current.querySelectorAll(".ctg-result-layer button,.ctg-result-actions button")].filter((e) => !e.disabled), n = t.indexOf(document.activeElement);
					e.preventDefault(), t[(n + (e.shiftKey ? -1 : 1) + t.length) % t.length]?.focus();
				}
			}
		},
		children: [
			/* @__PURE__ */ h("div", {
				className: "ctg-over-board",
				inert: v,
				children: /* @__PURE__ */ h(Me, {
					pub: p,
					members: t,
					myRid: a,
					send: () => void 0,
					readOnly: !0
				})
			}),
			/* @__PURE__ */ g("div", {
				className: "ctg-result-layer",
				role: "dialog",
				"aria-modal": v,
				"aria-label": m("games.cartographers.resultTitle"),
				hidden: !v,
				inert: !v,
				children: [/* @__PURE__ */ g("header", {
					className: "ctg-result-heading",
					children: [/* @__PURE__ */ h("h1", { children: m("games.cartographers.resultTitle") }), /* @__PURE__ */ h("button", {
						"aria-label": m("games.cartographers.review"),
						onClick: () => y(!1),
						children: /* @__PURE__ */ h(d, { size: 24 })
					})]
				}), /* @__PURE__ */ g("div", {
					className: "ctg-result-scroll",
					children: [
						/* @__PURE__ */ h("div", {
							className: "ctg-winners",
							children: p.players.length > 1 && c.winner.map((e) => /* @__PURE__ */ g("strong", { children: [
								x(e),
								" · ",
								m("games.cartographers.winner")
							] }, e))
						}),
						p.players.length === 1 && /* @__PURE__ */ g("div", {
							className: "ctg-solo-rating",
							children: [m(Te[w]), /* @__PURE__ */ h("p", { children: m("games.cartographers.soloRating", { n: C }) })]
						}),
						/* @__PURE__ */ h("div", {
							className: "ctg-score-scroll",
							children: /* @__PURE__ */ g("table", {
								className: `ctg-score-table${S.length > 4 ? " ctg-score-wide" : ""}`,
								style: S.length > 4 ? { minWidth: `${S.length * 72 + 110}px` } : void 0,
								children: [/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: m("games.cartographers.map") }), S.map((e) => /* @__PURE__ */ h("th", { children: x(e.rid) }, e.rid))] }) }), /* @__PURE__ */ g("tbody", { children: [Se.flatMap((e, t) => [/* @__PURE__ */ g("tr", {
									className: "ctg-score-season",
									children: [/* @__PURE__ */ h("th", { children: m(e) }), S.map((e) => /* @__PURE__ */ h("td", { children: e.seasons[t].total }, e.rid))]
								}, `${t}-heading`), ...[
									"a",
									"b",
									"coins",
									"monsters"
								].map((e) => /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: m(e === "a" ? Z[p.edicts[t]] : e === "b" ? Z[p.edicts[(t + 1) % 4]] : e === "coins" ? "games.cartographers.coins" : "games.cartographers.monsters") }), S.map((n) => /* @__PURE__ */ h("td", { children: e === "monsters" ? `−${n.seasons[t][e]}` : n.seasons[t][e] }, n.rid))] }, `${t}-${e}`))]), /* @__PURE__ */ g("tr", {
									className: "ctg-score-total",
									children: [/* @__PURE__ */ h("th", { children: m("games.cartographers.total") }), S.map((e) => /* @__PURE__ */ h("td", { children: e.total }, e.rid))]
								})] })]
							})
						}),
						/* @__PURE__ */ g("div", {
							className: "ctg-result-notes",
							children: [l !== void 0 && /* @__PURE__ */ h("span", { children: m("session.hint.usedCount", { n: l }) }), c.autopilot && Object.entries(c.autopilot).map(([e, t]) => /* @__PURE__ */ g("span", { children: [
								x(e),
								" · ",
								m("session.autopilot.share", { n: Math.round(t * 100) })
							] }, e))]
						})
					]
				})]
			}),
			/* @__PURE__ */ g("footer", {
				className: "ctg-result-actions",
				children: [
					/* @__PURE__ */ h("button", {
						className: "ctg-primary",
						onClick: () => y(!v),
						children: m(v ? "games.cartographers.review" : "games.cartographers.showResult")
					}),
					u && /* @__PURE__ */ h(_, {
						compact: !0,
						label: m("session.result.playAgain"),
						confirmLabel: m("games.cartographers.confirmAgain"),
						onConfirm: u
					}),
					" ",
					f && /* @__PURE__ */ h(_, {
						compact: !0,
						label: m("session.result.backToLobby"),
						confirmLabel: m("games.cartographers.confirmBack"),
						onConfirm: f
					}),
					" ",
					!u && !f && /* @__PURE__ */ h("span", { children: m("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/cartographers/options.tsx
function Be({ value: e, onChange: t }) {
	let n = s(), r = M.safeParse(e), i = r.success ? r.data : M.parse(void 0);
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ h(v, {
				title: n("games.cartographers.map"),
				children: ["A", "B"].map((e) => /* @__PURE__ */ h(te, {
					name: "ctg-map",
					value: e,
					checked: i.map === e,
					label: n(e === "A" ? "games.cartographers.mapA" : "games.cartographers.mapB"),
					accent: B.accent,
					onChange: () => t({
						...i,
						map: e
					})
				}, e))
			}),
			/* @__PURE__ */ h(y, {
				checked: i.promos,
				label: n("games.cartographers.promos"),
				accent: B.accent,
				onChange: () => t({
					...i,
					promos: !i.promos
				})
			}),
			/* @__PURE__ */ h(y, {
				checked: i.skills,
				label: n("games.cartographers.skillsOption"),
				accent: B.accent,
				onChange: () => t({
					...i,
					skills: !i.skills
				})
			})
		]
	});
}
//#endregion
//#region src/games/cartographers/guide.tsx
function Ve() {
	let e = s();
	return /* @__PURE__ */ g("div", {
		className: "ctg-guide",
		children: [
			/* @__PURE__ */ h("div", {
				className: "ctg-guide-terrain",
				children: b.map((t) => /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h($, { terrain: t }), e(Ce[t])] }, t))
			}),
			/* @__PURE__ */ h("div", {
				className: "ctg-guide-edicts",
				children: Z.map((t, n) => /* @__PURE__ */ g("section", { children: [
					/* @__PURE__ */ h("h3", { children: e(t) }),
					/* @__PURE__ */ h("p", { children: e(ye[n]) }),
					/* @__PURE__ */ h("small", { children: D[n] })
				] }, t))
			}),
			/* @__PURE__ */ h("div", {
				className: "ctg-guide-skills",
				children: be.map((t, n) => /* @__PURE__ */ g("section", { children: [/* @__PURE__ */ h("img", {
					src: Q(`skill-${n}`),
					alt: ""
				}), /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ g("h3", { children: [
					e(t),
					" · ",
					E[n]
				] }), /* @__PURE__ */ h("p", { children: e(xe[n]) })] })] }, t))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/cartographers/entry.tsx
var He = {
	definition: ge,
	View: ke,
	bot: Re,
	OverView: ze,
	Options: Be,
	Guide: Ve,
	locales: {
		zh: {
			name: "王国制图师",
			desc: "依照王国敕令绘制地图，规划村庄、林地与田园，提防邻座绘下的怪物。",
			map: "地图",
			mapA: "地图 A",
			mapB: "地图 B",
			promos: "伏击推广 1",
			skillsOption: "技能推广 1",
			spring: "春季",
			summer: "夏季",
			fall: "秋季",
			winter: "冬季",
			forest: "森林",
			village: "村庄",
			farm: "农田",
			water: "水域",
			monster: "怪物",
			mountain: "山地",
			wasteland: "荒地",
			ruin: "遗迹",
			dual: "农田与村庄",
			empty: "空格",
			coins: "金币",
			total: "总分",
			monsters: "怪物罚分",
			seasonTotal: "季节得分",
			edictA: "敕令 A",
			edictB: "敕令 B",
			edictC: "敕令 C",
			edictD: "敕令 D",
			draw: "选择形状和地形，在地图上放置。",
			prepare: "选择是否使用特技，然后传递地图。",
			resolve: "正在揭示探索牌…",
			"season-end": "本季结束。确认后进行计分。",
			score: "正在计分…",
			season: "本季计分完成。",
			done: "绘制完成",
			waiting: "等待其他玩家",
			ready: "完成本轮",
			continue: "继续",
			confirm: "确认放置",
			left: "向左移动",
			up: "向上移动",
			down: "向下移动",
			right: "向右移动",
			rotate: "旋转",
			flip: "翻转",
			cancel: "取消选择",
			skip: "地图已填满",
			next: "进入下一季",
			settle: "开始计分",
			ruinsRequired: "本次形状必须覆盖一处空遗迹。",
			fallback: "没有可放置的原形状。请选择地形，绘制一格。",
			ambushInstruction: "将此怪物形状绘入收到的地图。",
			targetMap: "正在绘制 {{name}} 的地图",
			yourMap: "你的地图",
			coinShape: "此形状获得 1 金币",
			time: "本季时间 {{n}} / {{limit}}",
			cell: "第 {{row}} 行，第 {{col}} 列：{{terrain}}",
			invalid: "此操作当前不可用，请检查地形、落位及技能条件。",
			hintPlace: "在第 {{row}} 行、第 {{col}} 列放置所选形状。",
			hintSkill: "使用一项可用技能。",
			hintReady: "完成当前步骤。",
			skillCost: "花费 {{n}} 金币",
			skillUsed: "本季已使用技能",
			extra: "放置技能提供的额外形状。",
			noPlacement: "当前形状没有合法落位。",
			review: "回看地图",
			showResult: "查看结果",
			resultTitle: "呈献王国地图",
			winner: "获胜",
			soloRating: "单人评级：{{n}}",
			confirmAgain: "确认再来一局",
			confirmBack: "确认返回大厅",
			seasonScore: "{{season}}：{{n}} 分",
			scorePart: "{{name}}：{{n}}",
			remaining: "探索牌堆 {{n}}",
			details: "卡牌详情",
			close: "关闭",
			skillSelect: "使用技能",
			notUsed: "不使用特技",
			useAcrobatics: "使用特技",
			selected: "已选择",
			useSkill: "使用 {{name}}",
			mapName: "{{name}} 的地图",
			title0: "传奇制图师",
			title1: "制图大师",
			title2: "地形专家",
			title3: "测绘学徒",
			title4: "业余勘测员",
			title5: "生疏绘图者",
			title6: "迟钝制图者",
			title7: "糊涂制图者",
			explore0: "大河",
			explore1: "农田",
			explore2: "村落",
			explore3: "遗忘之森",
			explore4: "内陆溪流",
			explore5: "家园",
			explore6: "果园",
			explore7: "树顶村庄",
			explore8: "湿地",
			explore9: "渔村",
			explore10: "裂隙之地",
			explore11: "神庙遗迹",
			explore12: "哨站遗迹",
			ambush0: "哥布林袭击",
			ambush1: "熊地精突袭",
			ambush2: "狗头人猛攻",
			ambush3: "豺狼人劫掠",
			ambush4: "夺心魔入侵",
			ambush5: "虫族入侵",
			ambush6: "鼠人出击",
			ambush7: "食人魔冲锋",
			edict0: "哨卫之林",
			edict1: "绿枝",
			edict2: "树塔",
			edict3: "山畔森林",
			edict4: "运河湖",
			edict5: "法师谷",
			edict6: "黄金粮仓",
			edict7: "辽阔岸地",
			edict8: "荒野据点",
			edict9: "伟大城市",
			edict10: "绿金平原",
			edict11: "盾门",
			edict12: "边疆",
			edict13: "失落领地",
			edict14: "断路",
			edict15: "坩埚",
			score0: "每个触及地图边缘的森林格获得 1 分。",
			score1: "每行、每列只要含有森林，分别获得 1 分。",
			score2: "每个正交四边均为已填格或地图边界的森林格获得 1 分。",
			score3: "森林区域邻接至少两座山时，每座符合条件的山获得 3 分；同一座山只计一次。",
			score4: "每个邻接农田的水域格获得 1 分，每个邻接水域的农田格获得 1 分。",
			score5: "每个邻接山地的水域格获得 2 分，每个邻接山地的农田格获得 1 分。",
			score6: "每个邻接遗迹的水域格获得 1 分，每个绘在遗迹上的农田格获得 3 分。遗迹是否填入地形不影响邻接。",
			score7: "每个不触及地图边缘且不邻接水域的农田区域获得 3 分；每个不触及地图边缘且不邻接农田的水域区域获得 3 分。",
			score8: "每个至少包含 6 格的村庄区域获得 8 分。",
			score9: "不邻接山地的最大村庄区域，每格获得 1 分。",
			score10: "每个邻接至少三种不同地形的村庄区域获得 3 分。山地与怪物属于地形，荒地不属于地形。",
			score11: "第二大村庄区域每格获得 2 分。若最大区域并列，取其中一个作为第二大区域。",
			score12: "每条填满的行或列获得 6 分。",
			score13: "最大已填满正方形的边长，每格获得 3 分。",
			score14: "每条从左边缘通往下边缘、由西北向东南延伸且填满的对角线获得 3 分。",
			score15: "每个正交四边均为已填格或地图边界的空格获得 1 分。",
			skill0: "特技",
			skill1: "搜寻",
			skill2: "交涉",
			skill3: "潜行",
			skill4: "知识",
			skill5: "外交",
			skill6: "疗伤",
			skill7: "专注",
			skillRule0: "支付2枚金币。发生伏击时，将自己地图上须绘制的怪物形状改为2×1的形状。",
			skillRule1: "无需支付金币。在绘制阶段额外绘制一格，使其与刚绘制的形状正交相邻，并使用相同地形。",
			skillRule2: "支付1枚金币。在绘制阶段，将可选形状替换为2×2的形状，不获得原形状附带的金币。",
			skillRule3: "无需支付金币。绘制形状时可以超出地图边缘，忽略越界部分，但仍须在地图内至少绘制一格。",
			skillRule4: "无需支付金币。将所选形状的地形改为村庄。",
			skillRule5: "支付1枚金币。在确认前的任意时刻，可以额外绘制一格；该格同时属于农田和村庄。",
			skillRule6: "支付1枚金币。使用本次探索牌提供的任意地形，额外绘制一个2×1的形状，其中至少一格须与怪物格相邻。",
			skillRule7: "支付3枚金币。在非伏击的绘制阶段，以相同地形再次绘制同一形状；第二个形状可独立旋转或翻转，不再获得形状附带的金币。",
			rules: "目标：在四季中依照敕令绘制地图，争取最高总分。开局所有人使用同一面 11 行、11 列的地图，从森林、农田水域、村庄、几何四组各随机选一张计分牌，随机排列为敕令 A、B、C、D。每季的计分敕令与时限如下：\n· 春季：敕令A和B，时限为8。\n· 夏季：敕令B和C，时限为8。\n· 秋季：敕令C和D，时限为7。\n· 冬季：敕令D和A，时限为6。\n\n每轮同时探索与绘制。探索牌提供地形和形状，可独立选择；形状可以旋转、翻转，可放在任意空位，不要求邻接已有地形，但不能重叠或超出地图。带金币的较小形状使你获得1枚金币。任意山地的四个正交相邻格全部填满时，永久获得1枚金币，同一座山只奖励一次。山地、荒地、怪物都属于已填格；未填入地形的遗迹仍为空格。\n\n翻出遗迹牌时继续翻牌，下张普通探索所绘形状必须覆盖至少一个空遗迹。若没有任何可放置的原形状，或没有可覆盖的遗迹，改为在任意空格绘制一格，可选森林、村庄、农田、水域或怪物。裂隙之地本来就是任意一种上述地形的一格。没有空格时跳过绘制。\n\n伏击：按牌上箭头将地图传给左邻或右邻，由收到地图的玩家绘制所示怪物形状，可旋转翻转。原形无法放置时，改画一格怪物；地图填满则跳过。画完后地图归还原主，伏击牌永久移除。遗迹后遇到伏击时，先正常处理伏击，遗迹限制保留至下一张普通探索。界面会切换到需要你绘制的邻居地图。\n\n探索牌时间累计达到或超过时限后，先完成本轮，再进行季末确认和计分。每季依次计两张当季敕令、当前金币数，并扣除怪物罚分：每个正交邻接怪物的空格扣 1 分，同一空格只扣一次。区域与邻接均按正交方向。新季重洗全部 13 张探索牌和没有翻出的伏击，再随机加入一张新伏击。冬季计分后总分最高者获胜；平分时比较四季累计怪物罚分，较少者获胜，仍相同则并列。\n\n单人模式：伏击自动依卡牌指定角与箭头方向逐层向内寻找落位，保持卡面朝向，不旋转翻转；完全无法放置则弃牌，不改画单格。终局从总分减去四张敕令的单人基准，按达到的最高分数门槛授予称号：\n· 达到30分：传奇制图师。\n· 达到20分：制图大师。\n· 达到10分：地形专家。\n· 达到0分：测绘学徒。\n· 达到−5分：业余勘测员。\n· 达到−10分：生疏绘图者。\n· 达到−20分：迟钝制图者。\n· 低于−20分：糊涂制图者。\n\n可选推广：伏击推广 1 将四张新伏击混入备用伏击。技能推广 1 从八张技能中随机公开三张，每人每季最多发动其中一张，支付的金币永久减少。额外形状不要求覆盖遗迹；外交格同时参与农田和村庄计分。专注的第二个形状不重复奖励金币。各技能说明及本局敕令的完整计分条件见下列图例。两项推广默认关闭。\n\n操作：点选探索牌上的形状及地形，使用形状旁的旋转、翻转控件，点地图预览，确认后绘制。技能额外形状同样需要预览和确认；完成本轮后等待其他玩家。点击敕令或技能可查看详细说明。"
		},
		en: {
			name: "Cartographers",
			desc: "Map the kingdom under royal edicts, plan thriving settlements, and watch for monsters drawn by your neighbors.",
			map: "Map",
			mapA: "Map A",
			mapB: "Map B",
			promos: "Ambush 1 mini-expansion",
			skillsOption: "Skills 1 mini-expansion",
			spring: "Spring",
			summer: "Summer",
			fall: "Fall",
			winter: "Winter",
			forest: "Forest",
			village: "Village",
			farm: "Farm",
			water: "Water",
			monster: "Monster",
			mountain: "Mountain",
			wasteland: "Wasteland",
			ruin: "Ruin",
			dual: "Farm and village",
			empty: "Empty",
			coins: "Coins",
			total: "Total",
			monsters: "Monster penalty",
			seasonTotal: "Season score",
			edictA: "Edict A",
			edictB: "Edict B",
			edictC: "Edict C",
			edictD: "Edict D",
			draw: "Choose a shape and terrain, then place it on the map.",
			prepare: "Choose whether to use Acrobatics, then pass the maps.",
			resolve: "Revealing the next exploration…",
			"season-end": "Season complete. Confirm to score.",
			score: "Scoring…",
			season: "Season scored.",
			done: "Map complete",
			waiting: "Waiting for other players",
			ready: "Finish round",
			continue: "Continue",
			confirm: "Confirm placement",
			left: "Move left",
			up: "Move up",
			down: "Move down",
			right: "Move right",
			rotate: "Rotate",
			flip: "Flip",
			cancel: "Cancel selection",
			skip: "Map is full",
			next: "Next season",
			settle: "Score season",
			ruinsRequired: "Cover an unfilled ruin with this shape.",
			fallback: "No printed shape fits. Choose a terrain and draw one square.",
			ambushInstruction: "Draw this monster shape on the map you received.",
			targetMap: "Drawing on {{name}}’s map",
			yourMap: "Your map",
			coinShape: "This shape earns 1 coin",
			time: "Season time {{n}} / {{limit}}",
			cell: "Row {{row}}, column {{col}}: {{terrain}}",
			invalid: "This action is unavailable. Check the terrain, placement and skill conditions.",
			hintPlace: "Place the selected shape at row {{row}}, column {{col}}.",
			hintSkill: "Use an available skill.",
			hintReady: "Complete the current step.",
			skillCost: "Spend {{n}} coins",
			skillUsed: "Skill used this season",
			extra: "Place the additional shape from your skill.",
			noPlacement: "This shape has no legal placement.",
			review: "Review maps",
			showResult: "Show results",
			resultTitle: "Maps for the Queen",
			winner: "Winner",
			soloRating: "Solo rating: {{n}}",
			confirmAgain: "Confirm play again",
			confirmBack: "Confirm return to lobby",
			seasonScore: "{{season}}: {{n}} points",
			scorePart: "{{name}}: {{n}}",
			remaining: "Explore deck: {{n}}",
			details: "Card details",
			close: "Close",
			skillSelect: "Use a skill",
			notUsed: "Without Acrobatics",
			useAcrobatics: "Use Acrobatics",
			selected: "Selected",
			useSkill: "Use {{name}}",
			mapName: "{{name}}’s map",
			title0: "Legendary Cartographer",
			title1: "Master Mapsmith",
			title2: "Journeyman Topographer",
			title3: "Apprentice Surveyor",
			title4: "Amateur Assessor",
			title5: "Inept Assistant",
			title6: "Dimwitted Doodler",
			title7: "Oblivious Inkdrinker",
			explore0: "Great River",
			explore1: "Farmland",
			explore2: "Hamlet",
			explore3: "Forgotten Forest",
			explore4: "Hinterland Stream",
			explore5: "Homestead",
			explore6: "Orchard",
			explore7: "Treetop Village",
			explore8: "Marshlands",
			explore9: "Fishing Village",
			explore10: "Rift Lands",
			explore11: "Temple Ruins",
			explore12: "Outpost Ruins",
			ambush0: "Goblin Attack",
			ambush1: "Bugbear Assault",
			ambush2: "Kobold Onslaught",
			ambush3: "Gnoll Raid",
			ambush4: "Flayer Incursion",
			ambush5: "Insectoid Invasion",
			ambush6: "Ratman Strike",
			ambush7: "Ogre Charge",
			edict0: "Sentinel Wood",
			edict1: "Greenbough",
			edict2: "Treetower",
			edict3: "Stoneside Forest",
			edict4: "Canal Lake",
			edict5: "Mages Valley",
			edict6: "The Golden Granary",
			edict7: "Shoreside Expanse",
			edict8: "Wildholds",
			edict9: "Great City",
			edict10: "Greengold Plains",
			edict11: "Shieldgate",
			edict12: "Borderlands",
			edict13: "The Lost Barony",
			edict14: "The Broken Road",
			edict15: "The Cauldrons",
			score0: "Earn 1 point per forest square on the map edge.",
			score1: "Earn 1 point per row and per column containing at least one forest.",
			score2: "Earn 1 point per forest square surrounded on all four sides by filled squares or map edges.",
			score3: "For each forest cluster touching at least two mountains, earn 3 points per mountain. Count each mountain only once.",
			score4: "Earn 1 point per water square adjacent to a farm, and 1 point per farm square adjacent to water.",
			score5: "Earn 2 points per water square adjacent to a mountain and 1 point per farm square adjacent to a mountain.",
			score6: "Earn 1 point per water square adjacent to any ruin and 3 points per farm square on a ruin. Ruins may be filled or empty.",
			score7: "Earn 3 points per farm cluster touching neither water nor the map edge, and 3 points per water cluster touching neither farms nor the map edge.",
			score8: "Earn 8 points per village cluster of at least 6 squares.",
			score9: "Earn 1 point per square in your largest village cluster that touches no mountain.",
			score10: "Earn 3 points per village cluster adjacent to at least three different terrain types. Mountains and monsters count; wasteland does not.",
			score11: "Earn 2 points per square in your second-largest village cluster. If the largest clusters tie, count one as second largest.",
			score12: "Earn 6 points per completely filled row or column.",
			score13: "Earn 3 points per side square of your largest completely filled square.",
			score14: "Earn 3 points per completely filled northwest-to-southeast diagonal connecting the left edge to the bottom edge.",
			score15: "Earn 1 point per empty square surrounded on all four sides by filled squares or map edges.",
			skill0: "Acrobatics",
			skill1: "Search",
			skill2: "Negotiate",
			skill3: "Move Silently",
			skill4: "Knowledge",
			skill5: "Diplomacy",
			skill6: "Cure Wounds",
			skill7: "Concentrate",
			skillRule0: "Spend 2 coins. During an ambush, replace the monster shape on your own map with a 2×1 shape.",
			skillRule1: "No coins are required. Draw an additional square orthogonally adjacent to the shape just drawn, with the same terrain.",
			skillRule2: "Spend 1 coin. Replace an available shape with a 2×2 shape. Do not gain the printed shape coin.",
			skillRule3: "No coins are required. The chosen shape may overhang the map. Ignore overhanging squares; draw at least one square.",
			skillRule4: "No coins are required. Fill the chosen shape with village terrain instead of an available terrain.",
			skillRule5: "Spend 1 coin. At any time before confirmation, draw an additional square that is both farm and village.",
			skillRule6: "Spend 1 coin. Draw an additional 2×1 shape adjacent to at least one monster square, using any terrain available on this exploration card.",
			skillRule7: "Spend 3 coins. During a non-ambush Draw Phase, draw the same shape a second time with the same terrain. It may be independently rotated or flipped; do not gain another shape coin.",
			rules: "Goal: map the kingdom across four seasons and earn the highest total. Everyone uses the same side of an 11×11 map. Randomly choose one scoring card from each of four groups (forest, farm/water, village, geometry), then randomly assign them to edicts A–D. The scoring edicts and time limits are:\n· Spring: score A and B, with a time limit of 8.\n· Summer: score B and C, with a time limit of 8.\n· Fall: score C and D, with a time limit of 7.\n· Winter: score D and A, with a time limit of 6.\n\nExplore and draw simultaneously. Independently choose an available terrain and shape. Rotate or flip the shape and place it anywhere on empty squares; adjacency is not required. Do not overlap filled squares or extend beyond the map. A smaller shape marked with a coin earns 1 coin. Surround a mountain on all four orthogonal sides to permanently gain 1 coin, once per mountain. Mountains, wasteland and monsters are filled; unfilled ruins are empty.\n\nWhen a ruin is revealed, continue revealing cards. The next normal exploration shape must cover at least one empty ruin. If none of the printed shapes can legally fit, or no empty ruin can be covered, draw one square anywhere with forest, village, farm, water or monster terrain. Rift Lands normally offers this same one-square choice. If the map is full, skip drawing.\n\nAmbush: pass your map in the arrow direction. The receiving player draws the depicted monster shape, with rotation and flipping allowed. If it cannot fit, draw one monster square instead; skip on a full map. Return maps to their owners and permanently discard the ambush. An ambush after a ruin is resolved normally; retain the ruin requirement for the next normal exploration. The interface switches to the neighbor’s map you must draw on.\n\nAfter completing the round that reaches or exceeds the season time limit, confirm the season and score its two edicts, plus 1 point per current coin, minus 1 per empty square orthogonally adjacent to monsters. Count each such empty square only once. All adjacency and clusters are orthogonal. For the next season, reshuffle all 13 exploration cards with unrevealed ambushes and add one new random ambush. After winter, the highest total wins. Ties favor fewer monster penalty points across all seasons; further ties share victory.\n\nSolo: ambushes are placed automatically from the indicated corner, following the arrow around concentric layers. Retain the printed orientation without rotation or flipping. If the shape cannot fit anywhere, discard it; do not substitute a single square. Subtract the four scoring cards’ solo baselines from your total for your rating. Use the highest threshold you reach:\n· 30 points: Legendary Cartographer.\n· 20 points: Master Mapsmith.\n· 10 points: Journeyman Topographer.\n· 0 points: Apprentice Surveyor.\n· −5 points: Amateur Assessor.\n· −10 points: Inept Assistant.\n· −20 points: Dimwitted Doodler.\n· Below −20 points: Oblivious Inkdrinker.\n\nOptional mini-expansions: Ambush 1 mixes four additional ambushes into the reserve. Skills 1 reveals three random skills out of eight. Each player may activate one of these skills per season by permanently spending its coin cost. Additional shapes do not need to cover ruins. Diplomacy squares count as both farm and village. Concentrate never duplicates a shape coin. Full edict and skill effects appear in the illustrated reference below. Both expansions are off by default.\n\nControls: choose a shape and terrain on the exploration card. Rotate or flip with the tools beside the shape, click the map to preview and confirm to draw. Preview and confirm additional skill shapes too. Finish the round to wait for other players. Select an edict or skill to read its effect."
		}
	}
};
//#endregion
export { He as default };
