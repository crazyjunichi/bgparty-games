import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useLayoutEffect as r, useMemo as i, useRef as a, useState as o, useSyncExternalStore as s } from "react";
import { useT as c } from "@bgparty/sdk/i18n";
import { BottomSheet as l } from "@bgparty/sdk/bottom-sheet";
import { IconCheck as u, IconInfo as d, IconLog as f, IconMirror as p, IconRecenter as m, IconRotate as h } from "@bgparty/sdk/icons";
import { Texture as g } from "@bgparty/sdk/texture";
import { useWakeLock as _ } from "@bgparty/sdk/use-wake-lock";
import { playSettle as v, playTurn as y, useSoundEdge as b } from "@bgparty/sdk/sfx";
import { useFxAnchor as ee, useFxAnchorsMaybe as te } from "@bgparty/sdk/fx/anchors";
import { GameScreen as ne } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as re } from "@bgparty/sdk/ui/player-strip";
import { LogSheet as ie } from "@bgparty/sdk/ui/log-sheet";
import { useThree as ae } from "@react-three/fiber";
import { BufferGeometry as oe, DoubleSide as se, Float32BufferAttribute as x, OrthographicCamera as ce, Vector3 as le } from "three";
import { ResilientCanvas as S } from "@bgparty/sdk/three/resilient-canvas";
import { Fragment as C, jsx as w, jsxs as T } from "react/jsx-runtime";
import { FlySprite as E } from "@bgparty/sdk/fx/primitives";
import { Confetti as ue } from "@bgparty/sdk/ui/confetti";
import { OptionCheckbox as de, OptionRadio as fe, OptionSection as D } from "@bgparty/sdk/ui/game-options";
//#region src/games/harmonies/cards.ts
var O = (e, t, n = 0, r = 0) => [
	e,
	t,
	n,
	r
], k = (e = 1, t = 0, n = 0) => O("gray", e, t, n), A = (e = 1, t = 0, n = 0) => O("green", e, t, n), j = (e = 0, t = 0) => O("blue", 1, e, t), M = (e = 0, t = 0) => O("yellow", 1, e, t), N = (e = 2, t = 0, n = 0) => O("red", e, t, n);
function P(e, t, n, r, i, a, o) {
	return {
		id: e,
		nameKey: t,
		art: n,
		family: r,
		scores: i,
		pattern: a.map(([e, t, n, r]) => ({
			terrain: e,
			height: t,
			q: n,
			r
		})),
		...e >= 29900 ? { expansion: !0 } : {},
		...o ? { spirit: o } : {}
	};
}
var F = [
	P(29300, "games.harmonies.llama", "llama", "mammal", [5, 12], [
		M(),
		M(-1, 0),
		k(2, -2, 0)
	]),
	P(29301, "games.harmonies.meerkat", "meerkat", "mammal", [
		2,
		5,
		9,
		14
	], [k(), M(-1, 0)]),
	P(29302, "games.harmonies.vulture", "vulture", "bird", [5, 11], [k(3), M(-1, 0)]),
	P(29303, "games.harmonies.bat", "bat", "mammal", [
		3,
		6,
		10,
		15
	], [k(), A(3, -1, 0)]),
	P(29304, "games.harmonies.fennec", "fennec", "mammal", [
		4,
		9,
		16
	], [
		k(),
		k(1, -1, 0),
		M(-2, 0)
	]),
	P(29305, "games.harmonies.polarBear", "polarBear", "mammal", [5, 11], [
		k(2),
		j(-1, 0),
		j(-1, 1)
	]),
	P(29306, "games.harmonies.penguin", "penguin", "bird", [
		4,
		10,
		16
	], [
		k(2),
		j(-1, 1),
		j(1, 0)
	]),
	P(29307, "games.harmonies.lizard", "lizard", "reptile", [
		5,
		10,
		16
	], [
		N(),
		M(-1, 0),
		M(-2, 0)
	]),
	P(29308, "games.harmonies.flamingo", "flamingo", "bird", [
		4,
		10,
		16
	], [
		j(),
		M(-1, 0),
		M(-1, 1)
	]),
	P(29309, "games.harmonies.shrew", "shrew", "mammal", [
		5,
		10,
		17
	], [
		N(),
		M(-1, 1),
		M(1, 0)
	]),
	P(29310, "games.harmonies.peacock", "peacock", "bird", [
		5,
		10,
		17
	], [
		N(),
		j(-1, 1),
		j(1, 0)
	]),
	P(29311, "games.harmonies.heron", "heron", "bird", [
		3,
		6,
		10,
		16
	], [j(), k(3, -1, 0)]),
	P(29312, "games.harmonies.duck", "duck", "bird", [
		2,
		4,
		8,
		13
	], [j(), N(2, -1, 0)]),
	P(29313, "games.harmonies.otter", "otter", "mammal", [
		5,
		10,
		16
	], [
		j(),
		A(1, -1, 0),
		A(1, -2, 0)
	]),
	P(29314, "games.harmonies.giraffe", "giraffe", "mammal", [
		2,
		4,
		6,
		10,
		15
	], [j(), A(1, -1, 0)]),
	P(29315, "games.harmonies.kingfisher", "kingfisher", "bird", [
		5,
		11,
		18
	], [
		A(3),
		j(-1, 1),
		j(1, 0)
	]),
	P(29316, "games.harmonies.crocodile", "crocodile", "reptile", [
		4,
		9,
		15
	], [
		j(),
		j(-1, 0),
		A(3, -2, 0)
	]),
	P(29317, "games.harmonies.salamander", "salamander", "reptile", [
		4,
		10,
		16
	], [
		j(),
		k(1, -1, 0),
		k(1, -1, 1)
	]),
	P(29318, "games.harmonies.squirrel", "squirrel", "mammal", [
		4,
		9,
		15
	], [N(), A(3, -1, 0)]),
	P(29319, "games.harmonies.koala", "koala", "mammal", [
		3,
		6,
		10,
		15
	], [A(2), A(1, -1, 0)]),
	P(29320, "games.harmonies.wolf", "wolf", "mammal", [
		4,
		10,
		16
	], [
		A(2),
		M(-1, 0),
		M(-1, 1)
	]),
	P(29321, "games.harmonies.boar", "boar", "mammal", [
		4,
		8,
		13
	], [A(2), N(2, -1, 0)]),
	P(29322, "games.harmonies.hummingbird", "hummingbird", "bird", [
		4,
		9,
		14
	], [
		A(2),
		j(-1, 0),
		j(-1, 1)
	]),
	P(29323, "games.harmonies.bee", "bee", "insect", [8, 18], [
		A(2),
		M(-1, 1),
		M(0, 1),
		M(1, 0)
	]),
	P(29324, "games.harmonies.hedgehog", "hedgehog", "mammal", [5, 12], [
		N(),
		A(2, -1, 0),
		A(2, -1, 1)
	]),
	P(29325, "games.harmonies.bear", "bear", "mammal", [5, 11], [
		A(),
		k(3, -1, 0),
		k(2, -1, 1)
	]),
	P(29326, "games.harmonies.deer", "deer", "mammal", [
		5,
		10,
		17
	], [
		A(),
		A(1, -1, 0),
		N(2, -2, 0)
	]),
	P(29327, "games.harmonies.ladybug", "ladybug", "insect", [
		2,
		5,
		8,
		12,
		17
	], [M(), A(1, -1, 0)]),
	P(29328, "games.harmonies.swan", "swan", "bird", [
		5,
		10,
		17
	], [
		M(),
		A(2, -1, 1),
		A(2, 1, 0)
	]),
	P(29329, "games.harmonies.lemur", "lemur", "mammal", [6, 12], [
		M(),
		j(-1, 1),
		j(0, 1),
		j(1, 0)
	]),
	P(29330, "games.harmonies.panther", "panther", "mammal", [5, 11], [
		M(),
		A(2, -1, 0),
		A(2, -2, 0)
	]),
	P(29331, "games.harmonies.stork", "stork", "bird", [4, 9], [
		M(),
		N(2, -1, 1),
		N(2, 1, 0)
	]),
	P(29900, "games.harmonies.fish", "fish", "fish", [6, 13], [
		j(),
		A(3, -1, 0),
		M(-2, 1)
	]),
	P(29901, "games.harmonies.axolotl", "axolotl", "reptile", [7, 16], [
		j(),
		A(2, 0, -1),
		k(2, -1, 0)
	]),
	P(29902, "games.harmonies.songbird", "songbird", "bird", [
		4,
		10,
		17
	], [
		N(),
		A(1, -1, 0),
		k(1, -1, 1)
	]),
	P(29903, "games.harmonies.pelican", "pelican", "bird", [5, 11], [
		N(),
		M(-1, 0),
		j(-2, 1)
	]),
	P(29904, "games.harmonies.tiger", "tiger", "mammal", [
		3,
		10,
		16
	], [
		A(),
		k(2, -1, 0),
		j(-2, 1)
	]),
	P(29905, "games.harmonies.chameleon", "chameleon", "reptile", [
		4,
		8,
		15
	], [
		A(2),
		j(-1, 1),
		M(1, 0)
	]),
	P(29906, "games.harmonies.camel", "camel", "mammal", [
		4,
		9,
		16
	], [
		k(2),
		N(1, -1, 1),
		M(1, 0)
	]),
	P(29907, "games.harmonies.yak", "yak", "mammal", [7, 16], [
		k(2),
		j(-1, 0),
		M(1, 0)
	]),
	P(29908, "games.harmonies.panda", "panda", "mammal", [5, 13], [
		M(),
		A(3, -1, 0),
		k(1, -1, 1)
	]),
	P(29909, "games.harmonies.beetle", "beetle", "insect", [5, 12], [
		M(),
		N(2, -1, 0),
		k(1, 1, 0)
	])
], pe = [
	P(29500, "games.harmonies.spiritDeer", "deer", "mammal", [0], [
		A(2),
		A(3, -1, 0),
		A(1, 1, 0)
	], "deer"),
	P(29501, "games.harmonies.spiritCrane", "stork", "bird", [0], [
		N(),
		N(1, -1, 0),
		M(-2, 0)
	], "crane"),
	P(29502, "games.harmonies.spiritOwl", "owl", "bird", [0], [
		A(3),
		A(1, -1, 0),
		A(1, -1, 1)
	], "owl"),
	P(29503, "games.harmonies.spiritCat", "cat", "mammal", [0], [
		N(),
		A(1, -1, 0),
		N(1, -2, 0)
	], "cat"),
	P(29504, "games.harmonies.spiritBear", "bear", "mammal", [0], [
		k(2),
		k(1, -1, 1),
		k(1, 1, 0)
	], "bear"),
	P(29505, "games.harmonies.spiritDragonfly", "dragonfly", "insect", [0], [
		j(),
		A(2, -1, 0),
		A(2, 1, 0)
	], "dragonfly"),
	P(29506, "games.harmonies.spiritIbex", "ibex", "mammal", [0], [k(3), k(2, -1, 0)], "ibex"),
	P(29507, "games.harmonies.spiritTortoise", "tortoise", "reptile", [0], [
		j(),
		k(2, -1, 0),
		j(1, 0)
	], "tortoise"),
	P(29508, "games.harmonies.spiritButterfly", "butterfly", "insect", [0], [
		M(),
		j(-1, 0),
		j(-1, 1),
		M(-2, 1)
	], "butterfly"),
	P(29509, "games.harmonies.spiritLion", "lion", "mammal", [0], [
		M(),
		A(2, -1, 0),
		M(1, 0)
	], "lion")
], me = [
	{
		...P(29600, "games.harmonies.whisperCrystal", "crystal", "mammal", [0, 0], [k(), A(2, 1, 0)]),
		whisper: !0
	},
	{
		...P(29601, "games.harmonies.whisperStars", "stars", "mammal", [0, 0], [j(), M(1, 0)]),
		whisper: !0
	},
	{
		...P(29602, "games.harmonies.whisperWinter", "winter", "mammal", [0, 0], [N(), O("brown", 1, 1, 0)]),
		whisper: !0
	},
	{
		...P(29603, "games.harmonies.whisperSteps", "steps", "mammal", [0, 0], [N(), A(1, 1, 0)]),
		whisper: !0
	},
	{
		...P(29604, "games.harmonies.whisperSunset", "sunset", "mammal", [0, 0], [M(), N(1, 1, 0)]),
		whisper: !0
	},
	{
		...P(29605, "games.harmonies.whisperPond", "pond", "mammal", [0, 0], [A(2), j(1, 0)]),
		whisper: !0
	},
	{
		...P(29606, "games.harmonies.whisperReef", "reef", "mammal", [0, 0], [j(), O("brown", 1, 1, 0)]),
		whisper: !0
	},
	{
		...P(29607, "games.harmonies.whisperGrove", "grove", "mammal", [0, 0], [A(2), k(1, 1, 0)]),
		whisper: !0
	},
	{
		...P(29608, "games.harmonies.whisperMeadow", "meadow", "mammal", [0, 0], [M(), O("brown", 1, 1, 0)]),
		whisper: !0
	},
	{
		...P(29609, "games.harmonies.whisperFalls", "falls", "mammal", [0, 0], [k(), j(1, 0)]),
		whisper: !0
	}
], I = Object.fromEntries([
	...F,
	...pe,
	...me
].map((e) => [e.id, e])), he = {
	deer: "games.harmonies.ruleDeer",
	crane: "games.harmonies.ruleCrane",
	owl: "games.harmonies.ruleOwl",
	cat: "games.harmonies.ruleCat",
	bear: "games.harmonies.ruleBear",
	dragonfly: "games.harmonies.ruleDragonfly",
	ibex: "games.harmonies.ruleIbex",
	tortoise: "games.harmonies.ruleTortoise",
	butterfly: "games.harmonies.ruleButterfly",
	lion: "games.harmonies.ruleLion"
}, ge = {
	azimuth: .18,
	elevation: .88
}, L = .34, _e = .16, ve = {
	gray: {
		top: "#8b9697",
		side: "#596568",
		print: "#e6e4d7"
	},
	blue: {
		top: "#3f9eaf",
		side: "#267387",
		print: "#bde5de"
	},
	brown: {
		top: "#a66c47",
		side: "#734b36",
		print: "#d8a678"
	},
	green: {
		top: "#899c42",
		side: "#596d34",
		print: "#e1e7a0"
	},
	yellow: {
		top: "#e9af44",
		side: "#bb7e29",
		print: "#fff0b1"
	},
	red: {
		top: "#c26050",
		side: "#94483e",
		print: "#f8bd96"
	}
}, R = Array.from({ length: 5 }, (e, t) => Array.from({ length: t % 2 ? 4 : 5 }, (e, n) => ({
	key: `${t - 2},${n - Math.floor(t / 2) - 1}`,
	q: t - 2,
	r: n - Math.floor(t / 2) - 1
}))).flat(), z = (e, t) => e.flatMap((e, n) => e.map((e) => ({
	key: `${n + t},${e}`,
	q: n + t,
	r: e
}))), ye = z([
	[
		1,
		2,
		3
	],
	[
		0,
		1,
		2,
		3
	],
	[
		-1,
		0,
		1,
		2
	],
	[
		-2,
		-1,
		1,
		2
	],
	[
		-2,
		-1,
		0,
		1
	],
	[
		-2,
		-1,
		0,
		1
	],
	[
		-2,
		-1,
		0
	]
], -3), be = z([
	[1, 2],
	[
		0,
		1,
		2
	],
	[
		0,
		1,
		2
	],
	[
		-1,
		0,
		1,
		2
	],
	[
		-1,
		0,
		1
	],
	[
		-2,
		-1,
		0,
		1
	],
	[
		-3,
		-2,
		-1,
		0
	],
	[-3, -2]
], -3), B = (e = "A") => e === "C" ? ye : e === "D" ? be : R, xe = /* @__PURE__ */ new Set([
	"-3,1",
	"-3,2",
	"-2,0",
	"-2,2",
	"3,-3",
	"4,-3",
	"4,-2"
]);
function Se(e, t) {
	return [e * 1.5, Math.sqrt(3) * (t + e / 2)];
}
function Ce(e, t) {
	let [n, r, i] = e, a = n * Math.sin(t.azimuth) + i * Math.cos(t.azimuth);
	return [
		n * Math.cos(t.azimuth) - i * Math.sin(t.azimuth),
		a * Math.sin(t.elevation) - r * Math.cos(t.elevation),
		a * Math.cos(t.elevation) + r * Math.sin(t.elevation)
	];
}
function V(e, t, n, r, i, a = 0) {
	return Array.from({ length: i }, (o, s) => {
		let c = s * Math.PI * 2 / i + a;
		return [
			e + r * Math.cos(c),
			t,
			n + r * Math.sin(c)
		];
	});
}
function we(e, t, n, r, i, a) {
	for (let i = 0; i < t.length; i++) {
		let o = (i + 1) % t.length;
		e.push({
			points: [
				t[i],
				t[o],
				n[o],
				n[i]
			],
			color: r,
			opacity: a
		});
	}
	e.push({
		points: n,
		color: i,
		opacity: a
	});
}
function Te(e, t, n, r, i, a, o, s, c) {
	we(e, V(t, n, r, i, 24), V(t, n + a * .86, r, i, 24), s, o, c), we(e, V(t, n + a * .86, r, i, 24), V(t, n + a, r, i * .94, 24), o, o, c);
}
function Ee(e, t, n, r, i) {
	let a = e.length, o = ve[i].print, s = (i) => e.push({
		points: i.map(([e, i]) => [
			t + e,
			n,
			r + i
		]),
		color: o
	});
	if (i === "green") for (let [e, t] of [
		[-.18, -.1],
		[.14, -.2],
		[.16, .15]
	]) s([
		[e - .14, t],
		[e - .07, t - .16],
		[e + .1, t - .1],
		[e + .14, t + .04],
		[e, t + .12]
	]);
	else if (i === "gray") s([
		[-.36, .16],
		[-.12, -.22],
		[.08, .08],
		[.21, -.1],
		[.38, .19]
	]);
	else if (i === "blue") for (let e of [
		-.18,
		.02,
		.22
	]) s([
		[-.4, e],
		[-.16, e - .08],
		[.1, e + .02],
		[.38, e - .04],
		[.4, e + .02],
		[.1, e + .09],
		[-.16, e - .01],
		[-.38, e + .07]
	]);
	else if (i === "yellow") for (let [i, a] of [
		[0, 0],
		[-.23, -.14],
		[.23, -.14],
		[0, .25]
	]) e.push({
		points: V(t + i, n, r + a, .11, 6),
		color: o
	});
	else if (i === "red") {
		for (let e of [-.22, .08]) s([
			[e, -.22],
			[e + .16, -.22],
			[e + .16, -.02],
			[e, -.02]
		]);
		s([
			[-.16, .1],
			[.16, .1],
			[.16, .22],
			[-.16, .22]
		]);
	} else for (let i of [.18, .37]) {
		let a = V(t, n, r, i, 24), s = V(t, n, r, i - .035, 24);
		for (let t = 0; t < 24; t++) {
			let n = (t + 1) % 24;
			e.push({
				points: [
					a[t],
					a[n],
					s[n],
					s[t]
				],
				color: o
			});
		}
	}
	for (let t = a; t < e.length; t++) e[t].decoration = !0;
}
function De(e, t, n, r, i, a = !1) {
	let o = [
		[
			t - .18,
			n,
			r - .18
		],
		[
			t + .18,
			n,
			r - .18
		],
		[
			t + .18,
			n,
			r + .18
		],
		[
			t - .18,
			n,
			r + .18
		]
	];
	we(e, o, o.map(([e, t, n]) => [
		e,
		t + .37,
		n
	]), a ? "#8558a4" : i ? "#c7bca1" : "#b2602e", a ? "#c89ee1" : i ? "#fff5cc" : "#f2a558"), e.push({
		points: [
			[
				t - .11,
				n + .372,
				r - .11
			],
			[
				t + .06,
				n + .372,
				r - .11
			],
			[
				t + .06,
				n + .372,
				r + .02
			],
			[
				t - .11,
				n + .372,
				r + .02
			]
		],
		color: a ? "#edcefc" : i ? "#fffbee" : "#ffd393"
	});
}
function Oe(e, t = {}) {
	let n = [], r = B(t.side), i = t.side === "C" || t.side === "D", a = r.map((e) => Se(e.q, e.r)), o = Math.min(...a.map(([e]) => e)) - 1.3, s = Math.max(...a.map(([e]) => e)) + 1.3, c = Math.min(...a.map(([, e]) => e)) - 1.25, l = Math.max(...a.map(([, e]) => e)) + 1.25, u = i ? [
		[
			o,
			0,
			c
		],
		[
			s,
			0,
			c
		],
		[
			s,
			0,
			l - .6
		],
		[
			s - .6,
			0,
			l
		],
		[
			o + .6,
			0,
			l
		],
		[
			o,
			0,
			l - .6
		]
	] : [
		[
			-4.35,
			0,
			-4.8
		],
		[
			4.35,
			0,
			-4.8
		],
		[
			4.45,
			0,
			3.5
		],
		[
			4.1,
			0,
			4.25
		],
		[
			3.2,
			0,
			4.7
		],
		[
			-3.2,
			0,
			4.7
		],
		[
			-4.1,
			0,
			4.25
		],
		[
			-4.45,
			0,
			3.5
		]
	];
	we(n, u.map(([e, , t]) => [
		e,
		-.2,
		t
	]), u.map(([e, , t]) => [
		e,
		0,
		t
	]), "#816442", "#c9b187");
	for (let e of n) e.ground = !0, e.sceneHeight = (t.maxLayers ?? 3) * L + .8;
	for (let i of r) {
		let r = n.length, [a, o] = Se(i.q, i.r), s = t.selected === i.key, c = t.legal?.has(i.key), l = V(a, _e, o, .95, 6), u = t.side === "D" && !t.ordinary?.has(i.key);
		if (we(n, V(a, .02, o, .98, 6), l, "#b59664", s ? "#c9e1cf" : c ? "#e8e3bc" : u ? "#b5a08d" : "#ead4a2"), u) for (let e of [
			[
				[-.8, -.3],
				[-.2, -.1],
				[.2, .65]
			],
			[[-.2, -.1], [.3, -.6]],
			[[.2, .65], [.75, .4]]
		]) {
			let [t, r, i] = e;
			n.push({
				points: [
					[
						a + t[0],
						.163,
						o + t[1]
					],
					[
						a + r[0],
						.163,
						o + r[1]
					],
					[
						a + r[0] + .04,
						.163,
						o + r[1]
					],
					...i ? [[
						a + i[0],
						.163,
						o + i[1]
					]] : []
				],
				color: "#786757"
			});
		}
		let d = e[i.key]?.layers ?? [];
		if (s || c) {
			let e = V(a, .166, o, .92, 6), t = V(a, .166, o, s ? .83 : .89, 6);
			for (let r = 0; r < 6; r++) {
				let i = (r + 1) % 6;
				n.push({
					points: [
						e[r],
						e[i],
						t[i],
						t[r]
					],
					color: s ? "#277f88" : "#a6a46b"
				});
			}
		}
		if (t.habitat?.has(i.key)) {
			let e = V(a, .169, o, .94, 6), t = V(a, .169, o, .86, 6);
			for (let r = 0; r < 6; r++) n.push({
				points: [
					e[r],
					e[(r + 1) % 6],
					t[(r + 1) % 6],
					t[r]
				],
				color: "#f8fbdf"
			});
		}
		d.forEach((e, r) => {
			if (r === d.length - 1 && t.hiddenTokens?.has(i.key)) return;
			let s = n.length, c = _e + r * L + .015;
			Te(n, a, c, o, .73, .322, ve[e].top, ve[e].side), r === d.length - 1 && Ee(n, a, c + L - .016, o, e);
			for (let e = s; e < n.length; e++) n[e].paintLayer = r + 1;
		});
		let f = _e + d.length * L, p = n.length, m = e[i.key];
		if (m?.animal && !t.hiddenAnimals?.has(i.key) && De(n, a - (m.whisper ? .24 : 0), f + .02, o, m.animal === "spirit"), m?.whisper && !t.hiddenWhispers?.has(i.key) && De(n, a + (m.animal ? .24 : 0), f + .02, o, !1, !0), m?.sanctuary !== void 0) {
			let e = V(a, f + .005, o, .78, 6), t = V(a, f + .005, o, .72, 6);
			for (let r = 0; r < 6; r++) n.push({
				points: [
					e[r],
					e[(r + 1) % 6],
					t[(r + 1) % 6],
					t[r]
				],
				color: "#f6dfb5"
			});
			for (let e = 0; e < Math.min(m.sanctuaryAnimals ?? 0, 4); e++) De(n, a + (e % 2 ? .26 : -.26), f + .02, o + (e < 2 ? -.25 : .25), !1);
		}
		if (t.preview?.key === i.key) {
			let { terrain: e } = t.preview;
			Te(n, a, f + .09, o, .73, .322, ve[e].top, ve[e].side, .58), Ee(n, a, f + L + .074, o, e);
		}
		if (t.animalPreview?.key === i.key) {
			let e = n.length;
			De(n, a + (t.animalPreview.whisper ? m?.animal ? .24 : 0 : m?.whisper ? -.24 : 0), f + .14, o, t.animalPreview.spirit, t.animalPreview.whisper);
			for (let t = e; t < n.length; t++) n[t].opacity = .65;
		}
		for (let e = p; e < n.length; e++) n[e].paintLayer = d.length + 1;
		for (let e = r; e < n.length; e++) n[e].paintOrigin = [
			a,
			0,
			o
		];
	}
	return n;
}
function ke(e, t, n, r) {
	let i = e.filter((e) => e.ground).flatMap((e) => e.points), a = [0, e.find((e) => e.sceneHeight)?.sceneHeight ?? 1.8].flatMap((e) => i.map(([n, , r]) => Ce([
		n,
		e,
		r
	], t))), o = Math.min(...a.map(([e]) => e)), s = Math.max(...a.map(([e]) => e)), c = Math.min(...a.map(([, e]) => e)), l = Math.max(...a.map(([, e]) => e)), u = Math.min(n / (s - o), r / (l - c)) * .95, d = (o + s) / 2, f = (c + l) / 2, p = (e) => {
		let [i, a, o] = Ce(e, t);
		return [
			n / 2 + (i - d) * u,
			r / 2 + (a - f) * u,
			o
		];
	};
	return {
		scale: u,
		cx: d,
		cy: f,
		toScreen: p,
		polygons: e.map((e) => {
			let n = e.points.map(p);
			return {
				...e,
				projected: n,
				depth: n.reduce((e, t) => e + t[2], 0) / n.length,
				cellDepth: e.paintOrigin ? Ce(e.paintOrigin, t)[2] : 0
			};
		}).sort((e, t) => Number(!!t.ground) - Number(!!e.ground) || e.cellDepth - t.cellDepth || (e.paintLayer ?? 0) - (t.paintLayer ?? 0) || Number(!!e.decoration) - Number(!!t.decoration) || e.depth - t.depth)
	};
}
//#endregion
//#region src/games/harmonies/crescendo.ts
var H = [
	{
		id: 0,
		nameKey: "games.harmonies.sanctuaryWaterfall",
		layers: [
			"gray",
			"gray",
			"blue",
			"blue"
		],
		colors: ["gray", "blue"],
		art: "waterfall"
	},
	{
		id: 1,
		nameKey: "games.harmonies.sanctuaryCanyon",
		layers: [
			"yellow",
			"yellow",
			"gray",
			"gray"
		],
		colors: ["yellow", "gray"],
		art: "canyon"
	},
	{
		id: 2,
		nameKey: "games.harmonies.sanctuaryCity",
		layers: [
			"brown",
			"red",
			"gray",
			"gray"
		],
		colors: ["red", "gray"],
		art: "city"
	},
	{
		id: 3,
		nameKey: "games.harmonies.sanctuaryWindmill",
		layers: [
			"yellow",
			"brown",
			"brown",
			"red"
		],
		colors: ["yellow", "red"],
		art: "windmill"
	},
	{
		id: 4,
		nameKey: "games.harmonies.sanctuaryTerraces",
		layers: [
			"green",
			"green",
			"yellow",
			"yellow"
		],
		colors: ["green", "yellow"],
		art: "terraces"
	},
	{
		id: 5,
		nameKey: "games.harmonies.sanctuaryTree",
		layers: [
			"gray",
			"gray",
			"brown",
			"green"
		],
		colors: ["gray", "green"],
		art: "tree"
	},
	{
		id: 6,
		nameKey: "games.harmonies.sanctuarySprings",
		layers: [
			"yellow",
			"blue",
			"blue",
			"blue"
		],
		colors: ["yellow", "blue"],
		art: "springs"
	},
	{
		id: 7,
		nameKey: "games.harmonies.sanctuaryTreehouse",
		layers: [
			"brown",
			"brown",
			"red",
			"green"
		],
		colors: ["red", "green"],
		art: "treehouse"
	},
	{
		id: 8,
		nameKey: "games.harmonies.sanctuarySeahouse",
		layers: [
			"blue",
			"blue",
			"brown",
			"red"
		],
		colors: ["blue", "red"],
		art: "seahouse"
	},
	{
		id: 9,
		nameKey: "games.harmonies.sanctuaryRainforest",
		layers: [
			"blue",
			"brown",
			"green",
			"green"
		],
		colors: ["blue", "green"],
		art: "rainforest"
	}
], U = [
	[1, 0],
	[0, 1],
	[-1, 1],
	[-1, 0],
	[0, -1],
	[1, -1]
], Ae = new Set(R.map((e) => e.key)), W = (e, t = "A") => {
	let [n, r] = e.split(",").map(Number), i = t === "A" || t === "B" ? Ae : new Set(B(t).map((e) => e.key));
	return U.map(([e, t]) => `${n + e},${r + t}`).filter((e) => i.has(e));
}, G = (e, t) => e[t]?.layers.at(-1);
function je(e, t, n) {
	let r = e[t]?.layers ?? [];
	return r.length === 0 ? !0 : n === "gray" ? r.length < 3 && r.every((e) => e === "gray") : n === "brown" || n === "green" ? r.length < 3 && r.every((e) => e === "brown") && (n === "green" || r.length < 2) : n === "red" && r.length === 1 && [
		"gray",
		"brown",
		"red"
	].includes(r[0]);
}
function Me(e, t, n, r = "A", i = [], a) {
	if (!B(r).some((e) => e.key === t) || e[t]?.animal || e[t]?.whisper) return !1;
	let o = e[t]?.sanctuary, s = o ?? a;
	if (s === void 0) return je(e, t, n);
	if (o !== void 0 && a !== void 0 && o !== a) return !1;
	let c = i.find((e) => e.id === s);
	if (!c || c.completed || c.key !== void 0 && c.key !== t) return !1;
	let l = e[t]?.layers ?? [], u = H[s].layers;
	return l.length < u.length && l.every((e, t) => e === u[t]) && u[l.length] === n;
}
function Ne(e, t, n, r, i) {
	return Me(e, t, n, r, i) ? [void 0] : i.filter((a) => Me(e, t, n, r, i, a.id)).map((e) => e.id);
}
function Pe(e, t, n) {
	return e[t]?.sanctuary === void 0 && !je(e, t, n);
}
var K = (e, t) => e[t]?.sanctuary === void 0 ? G(e, t) : void 0, Fe = (e, t, n) => n !== "D" || xe.has(t) || W(t, n).some((t) => K(e, t) === "blue");
function Ie(e, t, n, r, i) {
	let a = I[r], o = t.find((e) => e.id === r), s = n.find((e) => e.id === i);
	return !!a && !a.spirit && !a.whisper && !!o && o.placed === a.scores.length - 1 && !!s?.completed && !!s.key && e[s.key]?.sanctuary === i && H[i].colors.includes(a.pattern[0].terrain);
}
function Le(e, t, n) {
	let { q: r, r: i } = e;
	n && (i = -r - i);
	for (let e = 0; e < t; e++) [r, i] = [-i, r + i];
	return {
		...e,
		q: r,
		r: i
	};
}
function Re(e, t, n, r, i, a = "A") {
	let o = new Set(B(a).map((e) => e.key));
	if (!o.has(n) || e[n]?.sanctuary !== void 0 || (t.whisper ? e[n]?.whisper : e[n]?.animal)) return null;
	let [s, c] = n.split(",").map(Number), l = [];
	for (let n of t.pattern) {
		let t = Le(n, r, i), a = `${s + t.q},${c + t.r}`, u = e[a]?.layers ?? [];
		if (!o.has(a) || u.length !== t.height || u.at(-1) !== t.terrain) return null;
		l.push(a);
	}
	return {
		key: n,
		keys: l,
		rotation: r,
		mirrored: i
	};
}
function ze(e, t, n, r = "A") {
	let i = [], a = /* @__PURE__ */ new Set();
	for (let { key: o } of B(r)) for (let s = 0; s < (n ? 2 : 1); s++) for (let n = 0; n < 6; n++) {
		let c = Re(e, t, o, n, s === 1, r);
		if (!c) continue;
		let l = `${o}:${[...c.keys].sort().join(";")}`;
		a.has(l) || (a.add(l), i.push(c));
	}
	return i;
}
function q(e, t = "A") {
	let n = new Set(e), r = [];
	for (let i of e) {
		if (!n.delete(i)) continue;
		let e = [i];
		for (let r = 0; r < e.length; r++) for (let i of W(e[r], t)) n.delete(i) && e.push(i);
		r.push(e);
	}
	return r;
}
function Be(e, t = "A") {
	let n = new Set(B(t).filter(({ key: t }) => K(e, t) === "blue").map((e) => e.key)), r = 0;
	for (let e of n) {
		let i = /* @__PURE__ */ new Map([[e, 1]]), a = [e];
		for (let e = 0; e < a.length; e++) {
			let o = i.get(a[e]);
			r = Math.max(r, o);
			for (let r of W(a[e], t)) n.has(r) && !i.has(r) && (i.set(r, o + 1), a.push(r));
		}
	}
	return r;
}
function Ve(e, t, n = "A") {
	let r = B(n).map((e) => e.key), i = (t) => r.filter((n) => K(e, n) === t), a = i("red").filter((t) => e[t].layers.length === 2);
	switch (t) {
		case "deer": return i("green").filter((t) => e[t].layers.length >= 2).length * 4;
		case "crane": return q(a, n).filter((e) => e.length >= 2).length * 6;
		case "owl": return i("green").reduce((t, n) => t + (e[n].layers.length === 3 ? 1 : 3), 0);
		case "cat": return q(a, n).filter((e) => e.length === 1).length * 4;
		case "bear": return i("gray").reduce((t, n) => t + (e[n].layers.length === 3 ? 1 : 3), 0);
		case "dragonfly": return q(i("blue"), n).filter((e) => e.length >= 2).length * 7;
		case "ibex": return i("gray").filter((t) => e[t].layers.length >= 2).length * 4;
		case "tortoise": return i("blue").length * 2;
		case "butterfly": return q(i("yellow"), n).length * 5;
		case "lion": return q(i("yellow"), n).reduce((e, t) => e + (t.length >= 3 ? 10 : 2), 0);
	}
}
function He(e, t, n, r = []) {
	let i = 0, a = 0, o = 0, s = [
		0,
		1,
		3,
		7
	], c = B(n);
	for (let { key: t } of c) {
		let r = e[t]?.layers ?? [], c = K(e, t);
		c === "green" && (i += n === "D" ? Fe(e, t, n) ? [
			0,
			2,
			4,
			9
		][r.length] : 0 : s[r.length]), c === "gray" && W(t, n).some((t) => K(e, t) === "gray") && (a += s[r.length]), c === "red" && r.length === 2 && new Set(W(t, n).map((t) => G(e, t)).filter((e) => e !== void 0)).size >= (n === "C" ? 4 : 3) && (o += n === "C" ? 8 : 5);
	}
	let l = q(c.filter(({ key: t }) => K(e, t) === "yellow").map((e) => e.key), n).filter((t) => t.length >= 2 && (n !== "D" || t.some((t) => Fe(e, t, n)))).length * (n === "D" ? 6 : 5), u = Be(e, n), d = Math.max(1, q(c.filter(({ key: t }) => K(e, t) !== "blue").map((e) => e.key), n).length), f = n === "B" ? d * 5 : u > 6 ? 15 + (u - 6) * 4 : [
		0,
		0,
		2,
		5,
		8,
		11,
		15
	][u], p = 0, m = 0, h = 0;
	for (let r of t) {
		let t = I[r.id];
		t.spirit ? r.placed > 0 && (m += Ve(e, t.spirit, n)) : t.whisper || (p += t.scores[r.placed - 1] ?? 0, h += r.placed);
	}
	let g = c.reduce((t, { key: n }) => t + (e[n]?.whisper ? e[n].animal ? 5 : 2 : 0), 0), _ = r.filter((e) => e.completed && e.key).reduce((t, r) => t + W(r.key, n).filter((t) => {
		let n = G(e, t);
		return n !== void 0 && H[r.id].colors.includes(n);
	}).length * 3, 0);
	return {
		trees: i,
		mountains: a,
		fields: l,
		buildings: o,
		water: f,
		animals: p,
		spirits: m,
		sanctuaries: _,
		whispers: g,
		cubes: h,
		river: u,
		islands: d,
		total: i + a + l + o + f + p + m + _ + g
	};
}
function Ue(e, t, n) {
	let r = [
		40,
		70,
		90,
		110,
		130,
		140,
		150,
		160
	].filter((t) => e >= t).length, i = n === void 0 ? 2 : +!![
		"crane",
		"cat",
		"dragonfly",
		"butterfly",
		"lion"
	].includes(n);
	return r + +(t === "A") + i;
}
//#endregion
//#region src/games/harmonies/meta.ts
var J = {
	id: "harmonies",
	tier: "beta",
	mechanics: [
		"drafting",
		"tile-placement",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.harmonies.name",
	descKey: "games.harmonies.desc",
	rulesKey: "games.harmonies.rules",
	icon: "🌿",
	iconImg: "games/harmonies.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#287e79",
	releasedAt: "2026-10-24T02:56:50+08:00",
	search: {
		py: "zi ran he xian",
		init: "zrhx"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://cdn.svc.asmodee.net/production-libelludv2/uploads/2026/07/HARMONIES_Rules_EN_compressed-1.pdf" }
}, Y = t.enum([
	"gray",
	"blue",
	"brown",
	"green",
	"yellow",
	"red"
]), X = t.object({
	side: t.enum([
		"A",
		"B",
		"C",
		"D"
	]).default("A"),
	pulse: t.boolean().default(!0),
	spirits: t.boolean().default(!0),
	sanctuaries: t.boolean().default(!1),
	whispers: t.boolean().default(!1)
}).default({
	side: "A",
	pulse: !0,
	spirits: !0,
	sanctuaries: !1,
	whispers: !1
}), We = t.string().regex(/^-?\d,-?\d$/).max(5), Ge = t.int().min(29300).max(29909), Ke = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("chooseSpirit"),
		card: Ge
	}),
	t.object({
		type: t.literal("draft"),
		group: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("place"),
		terrain: Y,
		key: We,
		sanctuary: t.int().min(0).max(9).optional()
	}),
	t.object({
		type: t.literal("takeCard"),
		index: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("takeSanctuary"),
		index: t.int().min(0).max(2)
	}),
	t.object({
		type: t.literal("sanctuaryAnimal"),
		card: Ge,
		sanctuary: t.int().min(0).max(9)
	}),
	t.object({
		type: t.literal("animal"),
		card: Ge,
		key: We,
		rotation: t.int().min(0).max(5),
		mirrored: t.boolean()
	}),
	t.object({
		type: t.literal("endTurn"),
		discard: t.int().min(0).max(2).optional()
	})
]), Z = t.object({
	layers: t.array(Y).max(4),
	animal: t.enum(["animal", "spirit"]).optional(),
	whisper: t.boolean().optional(),
	sanctuary: t.int().min(0).max(9).optional(),
	sanctuaryAnimals: t.int().min(0).optional()
}), qe = t.object({
	id: t.int().min(0).max(9),
	key: We.optional(),
	completed: t.boolean()
}), Je = t.object({
	id: Ge,
	placed: t.int().min(0).max(5)
}), Ye = t.object({
	trees: t.number(),
	mountains: t.number(),
	fields: t.number(),
	buildings: t.number(),
	water: t.number(),
	animals: t.number(),
	spirits: t.number(),
	sanctuaries: t.number().default(0),
	whispers: t.number().default(0),
	cubes: t.number(),
	river: t.number(),
	islands: t.number(),
	total: t.number()
}), Q = t.object({
	rid: t.string(),
	kind: t.enum([
		"spirit",
		"draft",
		"place",
		"takeCard",
		"animal",
		"endTurn",
		"takeSanctuary",
		"completeSanctuary",
		"sanctuaryAnimal"
	]),
	card: Ge.optional(),
	sanctuary: t.int().min(0).max(9).optional(),
	terrain: Y.optional(),
	key: t.string().optional(),
	n: t.number().optional()
}), Xe = t.object({
	phase: t.enum(["play", "done"]),
	config: X,
	round: t.int().min(1),
	serial: t.int().min(0),
	current: t.string(),
	bagLeft: t.int().min(0),
	cardsLeft: t.int().min(0),
	lastRound: t.boolean(),
	groups: t.array(t.array(Y).max(3).nullable()).min(3).max(5),
	market: t.array(Ge.nullable()).min(3).max(5),
	sanctuaryMarket: t.array(t.int().min(0).max(9).nullable()).max(3).default([]),
	sanctuariesLeft: t.int().min(0).default(0),
	players: t.array(t.object({
		rid: t.string(),
		board: t.record(t.string(), Z),
		cards: t.array(Je),
		sanctuaries: t.array(qe).default([]),
		spiritChosen: t.boolean(),
		score: Ye
	})),
	turn: t.object({
		drafted: t.boolean(),
		held: t.array(Y).max(3),
		tookCard: t.boolean(),
		tookSanctuary: t.boolean().default(!1)
	}),
	log: t.array(Q),
	suns: t.number().optional()
}), Ze = t.object({ spirits: t.array(Ge).max(2) }), Qe = {
	gray: 23,
	blue: 23,
	brown: 21,
	green: 19,
	yellow: 19,
	red: 15
}, $e = () => ({
	drafted: !1,
	held: [],
	tookCard: !1,
	tookSanctuary: !1
});
function et(t, n, r) {
	let i = 0, a = (t) => {
		for (let n = t.length - 1; n > 0; n--) {
			let a = e(r, i++, n + 1);
			[t[n], t[a]] = [t[a], t[n]];
		}
		return t;
	}, o = a(Object.entries(Qe).flatMap(([e, t]) => Array.from({ length: t }, () => e))), s = a([...F.filter((e) => t.pulse || !e.expansion), ...t.whispers ? me : []].map((e) => e.id)), c = a(pe.map((e) => e.id)), l = t.sanctuaries ? a(H.map((e) => e.id)) : [], u = t.sanctuaries ? [null, ...l.splice(0, 2)] : [];
	t.sanctuaries && (u[0] = l[0] ?? null);
	let d = n.length === 1 ? 3 : 5, f = {
		phase: "play",
		config: t,
		players: [...n],
		boards: {},
		owned: {},
		sanctuaries: {},
		sanctuaryMarket: u,
		sanctuaryDeck: l,
		spiritChoices: {},
		spiritChosen: {},
		bag: o,
		deck: s,
		groups: Array.from({ length: d }, () => o.splice(0, 3)),
		market: s.splice(0, d),
		current: 0,
		round: 1,
		serial: 0,
		lastRound: !1,
		turn: $e(),
		log: []
	};
	for (let e of n) f.boards[e] = {}, f.owned[e] = [], f.sanctuaries[e] = [], f.spiritChoices[e] = t.spirits ? c.splice(0, 2) : [], f.spiritChosen[e] = !t.spirits;
	return { state: f };
}
var $ = () => ({ code: "games.harmonies.invalid" });
function tt(e, t, { by: n }) {
	if (e.phase !== "play" || e.players[e.current] !== n) return { code: "games.harmonies.notYourTurn" };
	if (!e.spiritChosen[n] && t.type !== "chooseSpirit") return { code: "games.harmonies.chooseSpiritFirst" };
	let r = structuredClone(e), i = r.boards[n], a = r.owned[n], o = r.sanctuaries[n], s = () => a.filter((e) => e.placed < I[e.id].scores.length).length + o.filter((e) => !e.completed).length;
	switch (t.type) {
		case "chooseSpirit":
			if (r.spiritChosen[n] || !r.spiritChoices[n].includes(t.card)) return $();
			a.push({
				id: t.card,
				placed: 0
			}), r.spiritChoices[n] = [], r.spiritChosen[n] = !0, r.log.push({
				rid: n,
				kind: "spirit",
				card: t.card
			});
			break;
		case "draft": {
			let e = r.groups[t.group];
			if (r.turn.drafted || !e || e.length !== 3) return $();
			r.turn.drafted = !0, r.turn.held = e, r.groups[t.group] = null, r.log.push({
				rid: n,
				kind: "draft",
				n: t.group + 1
			});
			break;
		}
		case "place": {
			let e = r.turn.held.indexOf(t.terrain);
			if (e < 0 || !Me(i, t.key, t.terrain, r.config.side, o, t.sanctuary)) return $();
			let a = i[t.key]?.sanctuary, s = Pe(i, t.key, t.terrain) ? t.sanctuary : a;
			if (r.turn.held.splice(e, 1), i[t.key] = {
				...i[t.key],
				layers: [...i[t.key]?.layers ?? [], t.terrain],
				...s === void 0 ? {} : { sanctuary: s }
			}, r.log.push({
				rid: n,
				kind: "place",
				terrain: t.terrain,
				key: t.key
			}), s !== void 0) {
				let e = o.find((e) => e.id === s);
				e.key = t.key, i[t.key].layers.length === H[s].layers.length && (e.completed = !0, r.log.push({
					rid: n,
					kind: "completeSanctuary",
					sanctuary: s,
					key: t.key
				}));
			}
			break;
		}
		case "takeCard": {
			let e = r.market[t.index];
			if (r.turn.tookCard || e == null) return $();
			if (s() >= 4) return { code: "games.harmonies.cardLimit" };
			a.push({
				id: e,
				placed: 0
			}), r.market[t.index] = null, r.turn.tookCard = !0, r.log.push({
				rid: n,
				kind: "takeCard",
				card: e
			});
			break;
		}
		case "takeSanctuary": {
			let e = r.sanctuaryMarket[t.index];
			if (!r.config.sanctuaries || r.turn.tookSanctuary || e == null) return $();
			if (s() >= 4) return { code: "games.harmonies.cardLimit" };
			o.push({
				id: e,
				completed: !1
			}), t.index === 0 ? (r.sanctuaryDeck.shift(), r.sanctuaryMarket[0] = r.sanctuaryDeck[0] ?? null) : r.sanctuaryMarket[t.index] = null, r.turn.tookSanctuary = !0, r.log.push({
				rid: n,
				kind: "takeSanctuary",
				sanctuary: e
			});
			break;
		}
		case "sanctuaryAnimal": {
			if (!Ie(i, a, o, t.card, t.sanctuary)) return $();
			let e = a.find((e) => e.id === t.card), s = o.find((e) => e.id === t.sanctuary);
			e.placed++;
			let c = i[s.key];
			c.sanctuaryAnimals = (c.sanctuaryAnimals ?? 0) + 1, r.log.push({
				rid: n,
				kind: "sanctuaryAnimal",
				card: t.card,
				sanctuary: t.sanctuary,
				key: s.key
			});
			break;
		}
		case "animal": {
			let e = a.find((e) => e.id === t.card), o = I[t.card];
			if (!e || !o || e.placed >= o.scores.length || t.mirrored && !r.config.pulse) return $();
			if (!Re(i, o, t.key, t.rotation, t.mirrored, r.config.side)) return { code: "games.harmonies.noHabitat" };
			o.whisper ? i[t.key].whisper = !0 : i[t.key].animal = o.spirit ? "spirit" : "animal", e.placed++, r.log.push({
				rid: n,
				kind: "animal",
				card: o.id,
				key: t.key
			});
			break;
		}
		case "endTurn": {
			if (!r.turn.drafted || r.turn.held.length > 0) return { code: "games.harmonies.placeAll" };
			if (t.discard !== void 0) {
				if (r.players.length !== 1 || r.turn.tookCard || r.market[t.discard] == null) return $();
				r.market[t.discard] = null;
			}
			B(r.config.side).filter(({ key: e }) => !i[e]?.layers.length).length <= 2 && (r.lastRound = !0);
			let e = r.players.length === 1;
			for (let t = 0; t < r.groups.length; t++) {
				if (!e && r.groups[t] !== null) continue;
				r.bag.length < 3 && (r.lastRound = !0);
				let n = r.bag.splice(0, 3);
				r.groups[t] = n.length === 3 ? n : null;
			}
			for (let e = 0; e < r.market.length; e++) r.market[e] === null && (r.market[e] = r.deck.shift() ?? null);
			if (r.config.sanctuaries) {
				for (let e = 1; e < r.sanctuaryMarket.length; e++) r.sanctuaryMarket[e] === null && (r.sanctuaryMarket[e] = r.sanctuaryDeck.shift() ?? null);
				r.sanctuaryMarket[0] = r.sanctuaryDeck[0] ?? null;
			}
			r.log.push({
				rid: n,
				kind: "endTurn"
			}), r.serial++, r.lastRound && r.current === r.players.length - 1 ? r.phase = "done" : (r.current = (r.current + 1) % r.players.length, r.current === 0 && r.round++, r.turn = $e());
			break;
		}
	}
	let c = t.type === "place" ? [{
		kind: "place",
		rid: n,
		data: {
			key: t.key,
			terrain: t.terrain
		}
	}] : t.type === "animal" ? [{
		kind: "animal",
		rid: n,
		data: {
			key: t.key,
			card: t.card,
			spirit: !!I[t.card].spirit,
			whisper: !!I[t.card].whisper
		}
	}] : t.type === "sanctuaryAnimal" ? [{
		kind: "animal",
		rid: n,
		data: {
			key: o.find((e) => e.id === t.sanctuary).key,
			card: t.card,
			sanctuary: !0
		}
	}] : t.type === "takeSanctuary" ? [{
		kind: "takeSanctuary",
		rid: n,
		data: {
			id: o.at(-1).id,
			index: t.index
		}
	}] : t.type === "takeCard" ? [{
		kind: "takeCard",
		rid: n,
		data: {
			id: a.at(-1).id,
			index: t.index
		}
	}] : [];
	return t.type === "place" && r.log.at(-1)?.kind === "completeSanctuary" && c.push({
		kind: "completeSanctuary",
		rid: n,
		data: { id: r.log.at(-1).sanctuary }
	}), {
		state: r,
		fx: c
	};
}
function nt(e, t) {
	let n = e.players.map((t) => ({
		rid: t,
		board: structuredClone(e.boards[t]),
		cards: e.owned[t].map((e) => ({ ...e })),
		sanctuaries: e.sanctuaries[t].map((e) => ({ ...e })),
		spiritChosen: e.spiritChosen[t],
		score: He(e.boards[t], e.owned[t], e.config.side, e.sanctuaries[t])
	})), r = e.owned[e.players[0]].map((e) => I[e.id].spirit).find((e) => e !== void 0);
	return {
		public: {
			phase: e.phase,
			config: e.config,
			round: e.round,
			serial: e.serial,
			current: e.players[e.current],
			bagLeft: e.bag.length,
			cardsLeft: e.deck.length,
			lastRound: e.lastRound,
			groups: e.groups.map((e) => e ? [...e] : null),
			market: [...e.market],
			players: n,
			sanctuaryMarket: [...e.sanctuaryMarket],
			sanctuariesLeft: e.sanctuaryDeck.length,
			turn: {
				...e.turn,
				held: [...e.turn.held]
			},
			log: e.log.slice(-60),
			...e.phase === "done" && e.players.length === 1 ? { suns: Ue(n[0].score.total, e.config.side, r) } : {}
		},
		private: { spirits: e.spiritChoices[t] ?? [] }
	};
}
var rt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: J,
	schemas: {
		action: Ke,
		publicView: Xe,
		privateView: Ze,
		config: X
	},
	setup: et,
	reduce: tt,
	viewFor: nt,
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = Object.fromEntries(e.players.map((t) => [t, He(e.boards[t], e.owned[t], e.config.side, e.sanctuaries[t])])), n = [...e.players].sort((e, n) => t[n].total - t[e].total || t[n].cubes - t[e].cubes), r = t[n[0]];
		return {
			phase: "done",
			ranking: n,
			winner: n.filter((e) => t[e].total === r.total && t[e].cubes === r.cubes),
			scores: Object.fromEntries(e.players.map((e) => [e, t[e].total]))
		};
	}
};
//#endregion
//#region src/games/harmonies/board3d.tsx
function it(e) {
	let t = [];
	for (let n of e) for (let e = 1; e < n.points.length - 1; e++) t.push(...n.points[0], ...n.points[e], ...n.points[e + 1]);
	let n = new oe();
	return n.setAttribute("position", new x(t, 3)), n;
}
function at({ faces: e, color: t, opacity: n }) {
	let a = i(() => it(e), [e]);
	return r(() => () => a.dispose(), [a]), /* @__PURE__ */ w("mesh", {
		geometry: a,
		children: /* @__PURE__ */ w("meshBasicMaterial", {
			color: t,
			side: se,
			transparent: n < 1,
			opacity: n,
			depthWrite: n === 1
		})
	});
}
function ot({ faces: e }) {
	return i(() => {
		let t = /* @__PURE__ */ new Map();
		for (let n of e) {
			let e = `${n.color}:${n.opacity ?? 1}`, r = t.get(e) ?? {
				color: n.color,
				opacity: n.opacity ?? 1,
				faces: []
			};
			r.faces.push(n), t.set(e, r);
		}
		return [...t.entries()];
	}, [e]).map(([e, t]) => /* @__PURE__ */ w(at, { ...t }, e));
}
function st(e, t, n, r) {
	let i = ke(t, n, r.width, r.height), a = Math.sin(n.azimuth), o = Math.cos(n.azimuth), s = Math.sin(n.elevation), c = Math.cos(n.elevation), l = new le(o * i.cx + a * s * i.cy, -c * i.cy, -a * i.cx + o * s * i.cy);
	e.position.copy(l).add(new le(a * c, s, o * c).multiplyScalar(25)), e.left = -r.width / 2, e.right = r.width / 2, e.top = r.height / 2, e.bottom = -r.height / 2, e.zoom = i.scale, e.lookAt(l), e.updateProjectionMatrix();
}
function ct({ faces: e, orbit: t }) {
	let { camera: n, size: i, invalidate: a } = ae(), { width: o, height: s } = i;
	return r(() => {
		n instanceof ce && (st(n, e, t, {
			width: o,
			height: s
		}), a());
	}, [
		n,
		e,
		t,
		o,
		s,
		a
	]), null;
}
function lt() {
	let e = a(null), [t, n] = o({
		width: 1,
		height: 1
	});
	return r(() => {
		let t = e.current;
		if (!t) return;
		let r = () => n({
			width: t.clientWidth,
			height: t.clientHeight
		}), i = new ResizeObserver(r);
		return i.observe(t), r(), () => i.disconnect();
	}, []), {
		ref: e,
		box: t
	};
}
function ut({ rid: e, board: t, side: n = "A", sanctuaries: s = !1, selected: c, legal: l, preview: u, habitat: d, animalPreview: f, label: p, resetLabel: h, cellLabel: g, onSelect: _ }) {
	let { ref: v, box: y } = lt(), b = te();
	ee(null);
	let [ne, re] = o(ge), ie = a(null), ae = a(!1), [oe, se] = o(!1), x = B(n), ce = x.filter(({ key: t }) => e && b?.isBusy(`hm-token:${e}:${t}`)).map((e) => e.key).join(";"), le = x.filter(({ key: t }) => e && b?.isBusy(`hm-animal:${e}:${t}`)).map((e) => e.key).join(";"), C = x.filter(({ key: t }) => e && b?.isBusy(`hm-whisper:${e}:${t}`)).map((e) => e.key).join(";"), E = i(() => Oe(t, {
		side: n,
		maxLayers: s ? 4 : 3,
		ordinary: new Set(x.filter((e) => Fe(t, e.key, n)).map((e) => e.key)),
		selected: c,
		legal: l,
		preview: u,
		habitat: d,
		animalPreview: f,
		hiddenTokens: new Set(ce.split(";")),
		hiddenAnimals: new Set(le.split(";")),
		hiddenWhispers: new Set(C.split(";"))
	}), [
		t,
		n,
		s,
		x,
		c,
		l,
		u,
		d,
		f,
		ce,
		le,
		C
	]), ue = i(() => ke(E, ne, y.width, y.height), [
		E,
		ne,
		y.width,
		y.height
	]);
	r(() => {
		if (!e || !b) return;
		let n = [];
		for (let { key: r, q: i, r: a } of x) for (let o of [
			"token",
			"animal",
			"whisper"
		]) {
			let s = `hm-${o}:${e}:${r}`;
			n.push(s), b.registerProbe(s, () => {
				let e = v.current;
				if (!e) return null;
				let n = e.getBoundingClientRect(), [s, c] = Se(i, a), l = t[r], u = s + (o === "whisper" && l?.animal ? .24 : o === "animal" && l?.whisper ? -.24 : 0), d = _e + (t[r]?.layers.length ?? 0) * L + (o === "token" ? -.1 : .2), [f, p] = ue.toScreen([
					u,
					d,
					c
				]), m = ue.scale * (o === "token" ? 1.46 : .5), h = m * .75;
				return {
					x: n.left + f - m / 2,
					y: n.top + p - h / 2,
					w: m,
					h
				};
			});
		}
		return () => n.forEach((e) => b.registerProbe(e, null));
	}, [
		b,
		e,
		t,
		ue,
		v,
		x
	]);
	let de = (e) => {
		e.button !== 0 || e.target.closest("[data-harmonies-camera]") || (ie.current ||= (ae.current = !1, {
			id: e.pointerId,
			x: e.clientX,
			y: e.clientY,
			origin: ne,
			dragged: !1
		}));
	}, fe = (e) => {
		let t = ie.current;
		if (!t || t.id !== e.pointerId) return;
		let n = e.clientX - t.x, r = e.clientY - t.y;
		!t.dragged && Math.hypot(n, r) < 8 || (t.dragged || e.currentTarget.setPointerCapture(e.pointerId), t.dragged = !0, ae.current = !0, re({
			azimuth: t.origin.azimuth - n * .008,
			elevation: Math.max(.6, Math.min(1.3, t.origin.elevation + r * .005))
		}));
	}, D = (e) => {
		ie.current?.id === e.pointerId && (ie.current = null, e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId));
	};
	return /* @__PURE__ */ T("div", {
		ref: v,
		className: "harmonies-board3d",
		role: "group",
		"aria-label": p,
		onPointerDown: de,
		onPointerMove: fe,
		onPointerUp: D,
		onPointerCancel: D,
		onClickCapture: (e) => {
			ae.current &&= (e.preventDefault(), e.stopPropagation(), !1);
		},
		children: [
			/* @__PURE__ */ T(S, {
				orthographic: !0,
				camera: {
					near: .1,
					far: 100
				},
				frameloop: "demand",
				dpr: [1, 2],
				gl: {
					antialias: !0,
					alpha: !0,
					powerPreference: "low-power"
				},
				onRecoveryChange: se,
				recoveryFallback: /* @__PURE__ */ w("svg", {
					className: "harmonies-board-fallback",
					viewBox: `0 0 ${y.width} ${y.height}`,
					"aria-hidden": "true",
					children: ue.polygons.map((e, t) => /* @__PURE__ */ w("polygon", {
						points: e.projected.map(([e, t]) => `${e},${t}`).join(" "),
						fill: e.color,
						opacity: e.opacity
					}, t))
				}),
				children: [/* @__PURE__ */ w(ct, {
					faces: E,
					orbit: ne
				}), /* @__PURE__ */ w(ot, { faces: E })]
			}),
			/* @__PURE__ */ w("svg", {
				className: "harmonies-board-targets",
				viewBox: `0 0 ${y.width} ${y.height}`,
				"aria-label": p,
				children: x.map(({ key: e, q: n, r }) => {
					let [i, a] = Se(n, r), o = _e + (t[e]?.layers.length ?? 0) * L + .025, s = ue.toScreen([
						i,
						o,
						a
					]), u = Array.from({ length: 6 }, (e, t) => {
						let n = t * Math.PI / 3;
						return ue.toScreen([
							i + .86 * Math.cos(n),
							o,
							a + .86 * Math.sin(n)
						]);
					}).map(([e, t]) => `${e},${t}`).join(" ");
					return /* @__PURE__ */ T("g", { children: [/* @__PURE__ */ w("polygon", {
						points: u,
						role: "button",
						tabIndex: 0,
						"data-cell-key": e,
						"data-legal": l?.has(e),
						"aria-label": g(e),
						"aria-pressed": e === c,
						className: "harmonies-cell-target",
						onClick: () => _(e),
						onKeyDown: (t) => {
							(t.key === "Enter" || t.key === " ") && (t.preventDefault(), _(e));
						},
						children: l?.has(e) && /* @__PURE__ */ w("animate", {
							attributeName: "stroke-dashoffset",
							values: "0;-16",
							dur: "1.2s",
							repeatCount: "indefinite"
						})
					}), (t[e]?.sanctuaryAnimals ?? 0) > 0 && /* @__PURE__ */ w("text", {
						className: "harmonies-sanctuary-count",
						x: s[0],
						y: s[1] - 12,
						textAnchor: "middle",
						children: t[e].sanctuaryAnimals
					})] }, e);
				})
			}),
			/* @__PURE__ */ w("button", {
				type: "button",
				className: "btn-quiet harmonies-camera-reset",
				"data-harmonies-camera": !0,
				"aria-label": h,
				onClick: () => {
					ae.current = !1, re(ge);
				},
				children: /* @__PURE__ */ w(m, { className: "size-5" })
			}),
			oe && /* @__PURE__ */ w("span", {
				className: "sr-only",
				children: p
			})
		]
	});
}
//#endregion
//#region src/games/harmonies/art.tsx
var dt = {
	forest: [
		"#bdd1ae",
		"#7c9c77",
		"#4f7860",
		"#305d51"
	],
	water: [
		"#c1d9ce",
		"#7cafa5",
		"#428b91",
		"#286572"
	],
	desert: [
		"#f0d3a4",
		"#d3a474",
		"#b97e54",
		"#e0b577"
	],
	mountain: [
		"#d1dcce",
		"#9aafa7",
		"#617e7b",
		"#405f62"
	]
};
function ft({ x: e, y: t, scale: n = 1, color: r = "#a5bb89", turn: i = 0 }) {
	return /* @__PURE__ */ T("g", {
		transform: `translate(${e} ${t}) rotate(${i}) scale(${n})`,
		children: [/* @__PURE__ */ w("path", {
			d: "M0 0Q-34-46-13-89 24-64 0 0",
			fill: r
		}), /* @__PURE__ */ w("path", {
			d: "M0 0-10-71",
			stroke: "#f4efda",
			strokeWidth: "2",
			fill: "none"
		})]
	});
}
function pt({ kind: e }) {
	let t = [
		"flamingo",
		"heron",
		"swan",
		"stork",
		"pelican"
	].includes(e);
	if (e === "penguin") return /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M58 165Q43 118 57 83 67 50 87 58 111 61 119 114L136 150 113 135 114 175 94 186 64 182Z",
			fill: "#354f55"
		}),
		/* @__PURE__ */ w("path", {
			d: "M72 91Q98 74 107 117L109 169Q84 181 68 167Z",
			fill: "#f5ebd3"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "88",
			cy: "77",
			r: "3",
			fill: "#f9e5b3"
		}),
		/* @__PURE__ */ w("path", {
			d: "M97 78 119 88 99 92ZM64 177 90 178 78 187 58 186ZM96 178 116 174 128 181 107 189Z",
			fill: "#d7a151"
		})
	] });
	if (e === "owl") return /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M28 78 68 113 89 53 111 112 155 72 137 152 94 179 48 151Z",
			fill: "#516854"
		}),
		/* @__PURE__ */ w("path", {
			d: "M59 106Q91 76 122 106L116 149 91 174 65 149Z",
			fill: "#eee7ce"
		}),
		/* @__PURE__ */ w("path", {
			d: "M91 112Q68 85 65 117T91 144Q112 133 116 111T91 112",
			fill: "#c5c7a5"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "79",
			cy: "118",
			r: "5",
			fill: "#354c43"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "104",
			cy: "118",
			r: "5",
			fill: "#354c43"
		}),
		/* @__PURE__ */ w("path", {
			d: "M86 128 97 128 91 141Z",
			fill: "#c99545"
		})
	] });
	let n = [
		"kingfisher",
		"hummingbird",
		"peacock"
	].includes(e), r = e === "flamingo" ? "#e4a69b" : n ? "#34869a" : e === "songbird" ? "#b68551" : "#e7e7d4";
	return /* @__PURE__ */ T("g", { children: [
		e === "peacock" && /* @__PURE__ */ w("g", {
			fill: "#4b8975",
			stroke: "#bdd2a0",
			strokeWidth: "2",
			children: [
				0,
				1,
				2,
				3,
				4,
				5,
				6
			].map((e) => /* @__PURE__ */ w("ellipse", {
				cx: "89",
				cy: "91",
				rx: "17",
				ry: "56",
				transform: `rotate(${(e - 3) * 22} 89 130)`
			}, e))
		}),
		/* @__PURE__ */ w("path", {
			d: "M0 178 180 108",
			stroke: "#775f45",
			strokeWidth: "8"
		}),
		t ? /* @__PURE__ */ T(C, { children: [
			/* @__PURE__ */ w("path", {
				d: "M51 141Q47 110 77 112L97 122Q109 105 92 85 66 62 90 47 112 33 124 53L113 62Q99 43 94 56 90 67 105 77 135 104 111 137 91 163 51 141Z",
				fill: r
			}),
			/* @__PURE__ */ w("path", {
				d: "M111 52 151 60 115 64Z",
				fill: e === "pelican" ? "#d4a05c" : "#53645d"
			}),
			/* @__PURE__ */ w("path", {
				d: "M74 145 74 176M94 143 101 166",
				stroke: "#5c6858",
				strokeWidth: "3"
			}),
			e === "pelican" && /* @__PURE__ */ w("path", {
				d: "M117 63 149 60Q143 89 119 78Z",
				fill: "#edbd79"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "113",
				cy: "53",
				r: "2.8",
				fill: "#354c43"
			}),
			/* @__PURE__ */ w("path", {
				d: "M57 125Q77 114 97 132L70 144Z",
				fill: n ? "#2a6377" : "#c0cbbb"
			})
		] }) : /* @__PURE__ */ T(C, { children: [
			/* @__PURE__ */ w("path", {
				d: "M72 125Q47 76 71 45 96 37 110 63L137 68 112 76Q108 97 88 114L76 154 59 159Z",
				fill: r
			}),
			/* @__PURE__ */ w("path", {
				d: "M75 92Q102 74 105 63 120 92 89 124L62 145Z",
				fill: n ? "#d3a05d" : "#d4bc88"
			}),
			/* @__PURE__ */ w("path", {
				d: "M68 105 43 159 65 150 85 118Z",
				fill: n ? "#246579" : "#506e68"
			}),
			/* @__PURE__ */ w("path", {
				d: "M111 62 146 67 112 71Z",
				fill: "#354c43"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "102",
				cy: "62",
				r: "3",
				fill: "#263e3b"
			}),
			/* @__PURE__ */ w("path", {
				d: "M79 122 85 135M89 119 96 131",
				stroke: "#354c43",
				strokeWidth: "2"
			})
		] })
	] });
}
function mt({ kind: e }) {
	if (e === "bat") return /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M89 113Q54 49 13 69L29 119Q45 99 57 126 68 106 82 142L95 148 111 128Q124 111 135 128 151 100 170 112L158 65Q113 57 97 111Z",
			fill: "#4c6870"
		}),
		/* @__PURE__ */ w("path", {
			d: "M77 105 78 79 90 92 105 79 108 111 97 145 84 141Z",
			fill: "#d5c99b"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "85",
			cy: "104",
			r: "2.5",
			fill: "#354c43"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "99",
			cy: "104",
			r: "2.5",
			fill: "#354c43"
		})
	] });
	if ([
		"bear",
		"polarBear",
		"panda",
		"koala"
	].includes(e)) {
		let t = e === "bear" ? "#906546" : e === "koala" ? "#97a39b" : "#eee9d5";
		return /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("ellipse", {
				cx: "88",
				cy: "145",
				rx: "49",
				ry: "37",
				fill: t
			}),
			/* @__PURE__ */ w("path", {
				d: "M44 139 35 178 53 184 66 155M109 149 115 180 137 182 133 142",
				fill: e === "panda" ? "#3d5251" : t
			}),
			/* @__PURE__ */ w("circle", {
				cx: "62",
				cy: "87",
				r: "17",
				fill: e === "panda" ? "#3d5251" : t
			}),
			/* @__PURE__ */ w("circle", {
				cx: "114",
				cy: "87",
				r: "17",
				fill: e === "panda" ? "#3d5251" : t
			}),
			/* @__PURE__ */ w("ellipse", {
				cx: "88",
				cy: "111",
				rx: "37",
				ry: "34",
				fill: t
			}),
			e === "panda" && /* @__PURE__ */ T("g", {
				fill: "#405354",
				children: [/* @__PURE__ */ w("ellipse", {
					cx: "74",
					cy: "108",
					rx: "10",
					ry: "13",
					transform: "rotate(25 74 108)"
				}), /* @__PURE__ */ w("ellipse", {
					cx: "104",
					cy: "108",
					rx: "10",
					ry: "13",
					transform: "rotate(-25 104 108)"
				})]
			}),
			/* @__PURE__ */ w("ellipse", {
				cx: "88",
				cy: "125",
				rx: "20",
				ry: "13",
				fill: "#d6c8a7"
			}),
			/* @__PURE__ */ w("ellipse", {
				cx: "88",
				cy: "118",
				rx: e === "koala" ? 10 : 7,
				ry: e === "koala" ? 14 : 5,
				fill: "#354c43"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "73",
				cy: "107",
				r: "3",
				fill: e === "panda" ? "#fff1cc" : "#354c43"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "104",
				cy: "107",
				r: "3",
				fill: e === "panda" ? "#fff1cc" : "#354c43"
			})
		] });
	}
	let t = [
		"llama",
		"giraffe",
		"camel"
	].includes(e), n = [
		"fennec",
		"llama",
		"camel",
		"giraffe",
		"meerkat"
	].includes(e) ? "#e8bf84" : e === "panther" || e === "cat" ? "#405952" : e === "wolf" ? "#9ca8a0" : e === "tiger" ? "#df9b4c" : "#a47a56", r = t ? 65 : 111;
	return /* @__PURE__ */ T("g", { children: [
		[
			"squirrel",
			"lemur",
			"fennec",
			"panther",
			"cat"
		].includes(e) && /* @__PURE__ */ w("path", {
			d: e === "squirrel" ? "M57 144Q9 144 24 97 30 77 50 90 63 104 39 119L65 137Z" : "M60 151Q23 178 21 144 7 155 20 174 47 190 77 157Z",
			fill: e === "lemur" ? "#ede2c0" : n,
			stroke: e === "lemur" ? "#5b6860" : "none",
			strokeWidth: "6",
			strokeDasharray: e === "lemur" ? "9 8" : void 0
		}),
		e === "lion" && /* @__PURE__ */ w("circle", {
			cx: 116,
			cy: r,
			r: "37",
			fill: "#b47a45"
		}),
		e === "hedgehog" && /* @__PURE__ */ w("path", {
			d: "M30 157 22 142 37 135 33 118 50 120 57 105 70 113 83 102 93 118 108 114 119 137 109 163Z",
			fill: "#645e43"
		}),
		/* @__PURE__ */ w("path", {
			d: `M49 143Q47 120 78 116L104 120 ${t ? `103 ${r + 9} 124 ${r + 8}` : "130 125"} 140 151 121 164 118 184 104 183 103 161 70 165 65 184 50 182 55 159Z`,
			fill: n
		}),
		e === "camel" && /* @__PURE__ */ w("path", {
			d: "M51 131Q52 87 76 111 91 78 102 124Z",
			fill: n
		}),
		/* @__PURE__ */ w("path", {
			d: `M96 ${r + 17} 89 ${r - (e === "fennec" ? 49 : 27)}Q92 ${r - 49} 108 ${r - 11}L132 ${r - (e === "fennec" ? 47 : 26)}Q144 ${r - 43} 134 ${r + 7}L141 ${r + 23} 122 ${r + 39} 103 ${r + 31}Z`,
			fill: n
		}),
		/* @__PURE__ */ w("path", {
			d: `M105 ${r + 20} 119 ${r + 31} 138 ${r + 21} 123 ${r + 38} 107 ${r + 31}Z`,
			fill: "#f5e0b6"
		}),
		/* @__PURE__ */ w("path", {
			d: `M100 ${r + 15}l5-1m19-2 5-1`,
			stroke: "#354c43",
			strokeWidth: "2.5",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ w("path", {
			d: `M117 ${r + 28}l7-1-3 6Z`,
			fill: "#354c43"
		}),
		[
			"deer",
			"ibex",
			"yak"
		].includes(e) && /* @__PURE__ */ w("path", {
			d: `M102 ${r - 8}q-23-19-11-40m4 20-17-6m48 27q21-23 8-43m-1 21 16-9`,
			stroke: "#675f43",
			strokeWidth: "5",
			fill: "none"
		}),
		e === "giraffe" && /* @__PURE__ */ w("g", {
			fill: "#af7c46",
			children: [
				[73, 134],
				[93, 145],
				[111, 115],
				[114, 93]
			].map(([e, t], n) => /* @__PURE__ */ w("path", { d: `M${e} ${t}l9-4 5 10-9 6Z` }, n))
		}),
		e === "tiger" && /* @__PURE__ */ w("path", {
			d: "M59 124 66 141 72 121M80 120 88 139 94 123M105 131 112 146 118 136",
			fill: "#4b5b4d"
		})
	] });
}
function ht({ kind: e }) {
	return e === "ladybug" || e === "beetle" ? /* @__PURE__ */ T("g", {
		transform: "translate(91 126) rotate(-22)",
		children: [
			/* @__PURE__ */ w("path", {
				d: "M-25-7-40-17M-27 7-44 10M-21 22-37 35M25-7 40-17M27 7 44 10M21 22 37 35",
				stroke: "#354c43",
				strokeWidth: "4",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ w("ellipse", {
				cy: "-30",
				rx: "14",
				ry: "12",
				fill: "#354c43"
			}),
			/* @__PURE__ */ w("ellipse", {
				rx: "30",
				ry: "38",
				fill: e === "ladybug" ? "#c6654b" : "#377b84"
			}),
			/* @__PURE__ */ w("path", {
				d: "M0-36V36",
				stroke: "#354c43",
				strokeWidth: "3"
			}),
			e === "ladybug" && /* @__PURE__ */ T("g", {
				fill: "#354c43",
				children: [
					/* @__PURE__ */ w("circle", {
						cx: "-15",
						cy: "-13",
						r: "6"
					}),
					/* @__PURE__ */ w("circle", {
						cx: "15",
						cy: "-13",
						r: "6"
					}),
					/* @__PURE__ */ w("circle", {
						cx: "-15",
						cy: "12",
						r: "6"
					}),
					/* @__PURE__ */ w("circle", {
						cx: "15",
						cy: "12",
						r: "6"
					})
				]
			})
		]
	}) : /* @__PURE__ */ T("g", {
		transform: "translate(92 123)",
		children: [
			/* @__PURE__ */ w("path", {
				d: "M0 0Q-58-66-41-69 11-77 0 0M0 0Q58-66 41-69-11-77 0 0M0 0Q-43 29-41-8-27-39 0 0M0 0Q43 29 41-8 27-39 0 0",
				fill: e === "dragonfly" ? "#c6e2c1" : "#f1d594",
				opacity: ".95"
			}),
			e === "bee" ? /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("ellipse", {
				rx: "17",
				ry: "32",
				fill: "#e3b557"
			}), /* @__PURE__ */ w("path", {
				d: "M-16-12H16M-17 1H17M-13 14H13",
				stroke: "#4a5c50",
				strokeWidth: "7"
			})] }) : /* @__PURE__ */ w("path", {
				d: "M0 20V-47",
				stroke: "#4a6555",
				strokeWidth: "6",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ w("path", {
				d: "M0-43-9-57M0-43 9-57",
				stroke: "#4a6555",
				strokeWidth: "2"
			})
		]
	});
}
function gt({ kind: e }) {
	if (e === "tortoise") return /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("ellipse", {
			cx: "89",
			cy: "136",
			rx: "56",
			ry: "37",
			fill: "#697e59",
			stroke: "#e0d49b",
			strokeWidth: "4"
		}),
		/* @__PURE__ */ w("path", {
			d: "M47 153 34 174 53 176 65 158M111 159 124 180 140 174 128 150",
			fill: "#acb68b"
		}),
		/* @__PURE__ */ w("ellipse", {
			cx: "143",
			cy: "144",
			rx: "22",
			ry: "15",
			fill: "#acb68b"
		}),
		/* @__PURE__ */ w("path", {
			d: "M58 124 79 110 105 111 125 132 109 151 80 157 57 143Z",
			fill: "none",
			stroke: "#abb78a",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "151",
			cy: "140",
			r: "3",
			fill: "#354c43"
		})
	] });
	let t = e === "axolotl" ? "#e1a4a3" : e === "salamander" ? "#668d99" : "#8baf6c";
	return /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M51 144Q7 185 22 121 24 108 37 114 22 161 59 133L103 115 145 118 161 134 144 150 100 151 63 158Z",
			fill: t
		}),
		/* @__PURE__ */ w("path", {
			d: "M64 142 56 168 72 166M90 139 101 165 116 157M78 122 72 102 88 106M115 119 127 101 138 107",
			stroke: t,
			strokeWidth: "9",
			fill: "none",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "145",
			cy: "128",
			r: "3",
			fill: "#354c43"
		}),
		e === "axolotl" && /* @__PURE__ */ w("path", {
			d: "M130 118 119 98M140 119 141 95M151 122 163 104M132 150 121 164M145 150 146 169M153 143 167 150",
			stroke: "#c77185",
			strokeWidth: "5"
		}),
		e === "chameleon" && /* @__PURE__ */ w("path", {
			d: "M46 143Q13 169 20 140 30 123 39 141 31 151 28 141",
			fill: "none",
			stroke: t,
			strokeWidth: "8"
		})
	] });
}
function _t({ card: e }) {
	let t = e.art, n = [
		"fennec",
		"camel",
		"giraffe",
		"meerkat",
		"llama",
		"lion"
	].includes(t) ? dt.desert : [
		"polarBear",
		"penguin",
		"vulture",
		"yak",
		"ibex"
	].includes(t) ? dt.mountain : [
		"fish",
		"axolotl",
		"kingfisher",
		"heron",
		"flamingo",
		"swan",
		"otter",
		"duck",
		"pelican",
		"tortoise"
	].includes(t) ? dt.water : dt.forest;
	return /* @__PURE__ */ T(C, { children: [
		/* @__PURE__ */ w("rect", {
			width: "180",
			height: "200",
			fill: n[0]
		}),
		/* @__PURE__ */ w("circle", {
			cx: "139",
			cy: "35",
			r: e.spirit ? 30 : 24,
			fill: "#f8e2a6"
		}),
		/* @__PURE__ */ w("path", {
			d: "M0 90 43 57 91 92 131 65 180 89V200H0Z",
			fill: n[1]
		}),
		/* @__PURE__ */ w("path", {
			d: "M0 130Q69 80 180 120V200H0Z",
			fill: n[2]
		}),
		/* @__PURE__ */ w("path", {
			d: "M0 177Q80 120 180 157V200H0Z",
			fill: n[3]
		}),
		e.spirit && /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("circle", {
			cx: "91",
			cy: "108",
			r: "67",
			stroke: "#e6d7a4",
			strokeWidth: "2",
			fill: "none",
			opacity: ".5"
		}), /* @__PURE__ */ w("circle", {
			cx: "91",
			cy: "108",
			r: "73",
			stroke: "#e6d7a4",
			fill: "none",
			opacity: ".5"
		})] }),
		e.family === "bird" ? /* @__PURE__ */ w(pt, { kind: t }) : e.family === "mammal" ? /* @__PURE__ */ w(mt, { kind: t }) : e.family === "insect" ? /* @__PURE__ */ w(ht, { kind: t }) : e.family === "fish" ? /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "M53 122 23 96 25 149Z",
				fill: "#d5b47a"
			}),
			/* @__PURE__ */ w("ellipse", {
				cx: "97",
				cy: "123",
				rx: "49",
				ry: "29",
				fill: "#6b90a5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M65 104 85 77 108 99M66 142 87 169 110 145",
				fill: "#e0bc73"
			}),
			/* @__PURE__ */ w("path", {
				d: "M77 99 86 148M100 95 109 148",
				stroke: "#52727f",
				strokeWidth: "8"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "130",
				cy: "119",
				r: "4",
				fill: "#f8e7b6"
			})
		] }) : /* @__PURE__ */ w(gt, { kind: t }),
		/* @__PURE__ */ w(ft, {
			x: 15,
			y: 205,
			scale: .65,
			color: n[1],
			turn: -25
		}),
		/* @__PURE__ */ w(ft, {
			x: 171,
			y: 205,
			scale: .52,
			color: n[1],
			turn: 30
		})
	] });
}
//#endregion
//#region src/games/harmonies/crescendo-art.tsx
var vt = {
	waterfall: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='576'%3e%3cpath%20fill='%2377c5e1'%20d='M0%200h320v576H0z'/%3e%3cpath%20fill='%237193c3'%20d='m26%20142%201%202%203-1%202%202%204%204v2l7%201v-4h2l1%206v8l-1%2017-4%201-5-3h-5l-1-1v36l4-14%202-6%203%2016%201%203%201%2019h3l3%2014v2l1%208v8l3%2027h2v-2l1-21%201-8%202-41%203%2012%201%2010v5l1%2012%201-3h2v58h5v-28h2v20h2V160l5%202%201%2031%201-30%2012%202%2025%204h4l5%203%201%208v20l4%202%203%202-1-2q5%203%209%208v2l19-13%202-1%202-2%204-1v-2l3%201%202%206%201%202%205%2015%201%202%207%2015%201%207h2v-3h2v-42q0-3%203-5c5-1%205-1%208%201q3%204%202%208v10l1%209%201-2%2011-16h1v-3c0-14%200-14%204-19%209-8%2025-4%2035-4h4l3%201%2016%202v3l1%2030v36l3%2027v8h2v-83h3q2%204%202%209v45l1%2012v12l2%201v27h2v-3l-1-32v-17l-1-78%204-1%201%2051v51l1%202%201%2052%201%2064v29l1%2069-12-5-2-1-5-4q-5-2-11-1h-2q-13%200-21%209l-1%202%204%201v3h2l1%202%201-2%201-3%205-1%201%202%203-1%201%202%203%201%201-3h7v4l3-2-1-5q5%202%206%206l2%201%202%202v7l3%204c-6%209-6%209-11%2010l-2-2q-3-4-8-3l-10%203-8%202-3%201-7%201v2l-5-1-1%204h-2v3h-2l-5%204h-2l-4-10-2-3-6-17-11-2h-16l-13-1v-3l-1-5v-28l-1-18v-53l-6-1v-2h-3v-3h-2l-1-3-1-3-3-1%204-3-3%201h-3l-3-6h-6l-5-1%201%202v12l1%2014q-1%205-6%208h-5v4l-1%2057v20l-1%209-5%203-2%204-1-1-4-2v-2l-14-1%202%205%206%2016q-4-4-6-10l3%208q2%205%202%2012-4-1-5-5l-1-2-9%201-3-8-1-3-1-3v-7h2q3-7-1-13l-5-1q-7-3-12-10l-2-2h-2l3%202v2h-8l-6%202q-8%201-16-1l1%202%201%207v4l2-4c6%206%207%2018%207%2026h3l-1%204-2-1-7%201h-2l1-4h-2q-3-1-5-5l-1-3-2%202q-7%203-14%200-3-3-3-7l3-13%209%205-2-7h3l1-2h2l-3-8-5-1-3-1-10-2-6-1-3-1-1-2-4-1-3-15H0V246q0-19%202-37h2l2-11v-2l1-10%202-23v-4q1-8%207-14h4l1%205h2v-2z'/%3e%3cpath%20fill='%239db5d0'%20d='M320%20115v461H0V455h2q4%207%203%2015l5%201v2h2c19%202%2019%202%2026%206q3%203%202%208h-2l-1%203h-2l1%206-9-5v3l-2%208%202%206v3l3-1%208%201%204-1%201-2%201%202%201%202%202%202%204%203-1%204h2l3-1%205-1%201%201%201-3h-3l-3-12-4-13-2%204h-1v-7l-1-7h10q5%200%209-2h7l4%201v-2l-4-2-1-2q5%202%209%206%204%206%2012%207l4%203q2%207-1%2012l-2%201q1%209%205%2015v5l3-1%204-1%204%204%204%204-6-18%201-3%205%209-2-3-1-5-2-2v-2l-1-2-1-5h9l5%201v2l3-1%202%203v-5l3%201%204-2%201-6v-49l1-35%203-1%206-4v-18l-1-15%203%202h8l1-3h1v6l1%202h8l-3%204%202%201%201%206h2v3h3v2l6%201%201%2014v18l1%2023v42l1%204-1%206h2c34%200%2034%200%2039%203l1%204%206%2015%202%205%201%202%201%204h2l1-3%205-2%201-3h2l1-3%203-1v2h2v-2h2l3-1h3l2-1%201-2%202%201%205-2c10-4%2010-4%2015-2l4%203%204%201%203-3%201-2%203-4-1-2q-2-2-2-5l-1-6-5-3-1-1-1%202-1%202h-2v-4l-7%201-1%202-4-1v-2h-2l-1%202-1-3-5%201v2l-3%206v-5h-2v-3l-4-1q2-4%206-7l2-2q11-5%2025-3l8%205%208%204%202%201%202%201v-3l-1-68v-3l-3-141V174l-4%201v3l1%2036v2l1%2089h-2v-27l-3-1v-32l-1-37v-3l-1-5-2-1-1%2083h-2v-11c-1-6-1-6-3-8v-7l-1-9v-69l-41-2h-4l-4-1q-5%201-9%206-2%203-2%208l-1%202v13l-2-2-5%207-1%202-6%2014h-1v-10l-1-3c0-17%200-17-3-20h-6q-2%202-2%206v6l-1%2034h-2v3h-2v-2l-5-11-9-23-3-8-3-4v2l-6%204-3%203-2%201-11%208-5%201-4-4-2-3-1-2-1%203-7-6-1-13v-10l-2-6-6-1-3-1h-3v-2q7-3%2015-2h2l18%201%202-5h2v-2l8-4%205-2h7l6%201h8l-1%203h2v2q7%203%2012-1l6-5q2-3%205-4h2v-5l4-2-1-2q9-1%2016%203v2h2l5%203q5%204%2012%202l7-7%2010-4%202%201v-2l8-1h5l6-4q5-5%2012-8l6-3c11-7%2011-7%2014-7'/%3e%3cpath%20fill='%237193c3'%20d='m26%20142%201%202%203-1%202%202%204%204v2l7%201v-4h2l1%206v8l-1%2017-4%201-5-3h-5l-1-1v36l4-14%202-6%203%2016%201%203%201%2019h3l3%2014v2l1%208v8l3%2027h2v-2l1-21%201-8%202-41%203%2012%201%2010v5l1%2012%201-3h2v58h5v-28h2v20h2V160l5%202%201%2031%201-30%2012%202%2025%204h4l3%201q3%204%202%209l1%203v20l1%2030v99h2v-61l4%201%201%2067v30h3l5%203q4%207%203%2018v11q-1%205-6%208h-5v4l-1%2057v20l-1%209-5%203-2%204-1-1-4-2v-2l-14-1%202%205%206%2016q-4-4-6-10l3%208q2%205%202%2012-4-1-5-5l-1-2-9%201-3-8-1-3-1-3v-7h2q3-7-1-13l-5-1q-7-3-12-10l-2-2h-2l3%202v2h-8l-6%202q-8%201-16-1l1%202%201%207v4l2-4c6%206%207%2018%207%2026h3l-1%204-2-1-7%201h-2l1-4h-2q-3-1-5-5l-1-3-2%202q-7%203-14%200-3-3-3-7l3-13%209%205-2-7h3l1-2h2l-3-8-5-1-3-1-10-2-6-1-3-1-1-2-4-1-3-15H0V246q0-19%202-37h2l2-11v-2l1-10%202-23v-4q1-8%207-14h4l1%205h2v-2z'/%3e%3cpath%20fill='%2394caca'%20d='M320%20115v446l-37%203h-3c-7%200-7%200-9-2l-12-1h-2l-6-1h-15l-1-4v3h-2l-1-2-2%201-4-1-2-7a134%20134%200%200%200-11-34v-6l4%201%202%203%201-2%201%202%202%203%208%2017h2l1-3%205-2%201-3h2l1-3%203-1v2h2v-2h2l3-1h3l2-1%201-2%202%201%205-2c10-4%2010-4%2015-2l4%203%204%201%203-3%201-2%203-4-1-2q-2-2-2-5l-1-6-5-3-1-1-1%202-1%202h-2v-4l-7%201-1%202-4-1v-2h-2l-1%202-1-3-5%201v2l-3%206v-5h-2v-3l-4-1q2-4%206-7l2-2q11-5%2025-3l8%205%208%204%202%201%202%201v-3l-1-68v-3l-3-141V174l-4%201v3l1%2036v2l1%2089h-2v-27l-3-1v-32l-1-37v-3l-1-5-2-1-1%2083h-2v-11c-1-6-1-6-3-8v-7l-1-9v-69l-41-2h-4l-4-1q-5%201-9%206-2%203-2%208l-1%202v13l-2-2-5%207-1%202-6%2014h-1v-10l-1-3c0-17%200-17-3-20h-6q-2%202-2%206v6l-1%2034h-2v3h-2v-2l-5-11-9-23-3-8-3-4v2l-6%204-3%203-2%201-11%208-5%201-4-4-2-3-1-2-1%203-7-6-1-13v-10l-2-6-6-1-3-1h-3v-2q7-3%2015-2h2l18%201%202-5h2v-2l8-4%205-2h7l6%201h8l-1%203h2v2q7%203%2012-1l6-5q2-3%205-4h2v-5l4-2-1-2q9-1%2016%203v2h2l5%203q5%204%2012%202l7-7%2010-4%202%201v-2l8-1h5l6-4q5-5%2012-8l6-3c11-7%2011-7%2014-7'/%3e%3cpath%20fill='%231e2840'%20d='m74%20160%205%202%201%2031%201-30%2012%202%2025%204h4l3%201q3%204%202%209l1%203v20l1%2030v99h2v-61l4%201%201%2067v30h3l5%203q4%207%203%2018v11q-1%205-6%208h-5v23l-4%201-1%202h-2l-8-2-1%204h2v2h-3l1%207h-7l-1%204h-6l-4%201-2-3h-4v2h-3v2h-2l-2-3-5%203v-2l-5-1-1%205h-1v-8l-1-2-1-13-1-9v-31h-2v2a362%20362%200%200%201-1%2054v7l-3-3v-2h-4l-2%203-1-18v-11l-5-1-1-117v-11c0-51%200-51%202-76l3%2012%201%2010v5l1%2012%201-3h2v58h5v-28h2v20h2zm227%2014%201%2051v51l1%202%201%2052%201%2064v29l1%2069-5-2v-76h-2l-2%2042-5-1-2%203%201-14q0-17-5-33l-1-9h-2v4l-2%2023-1%205-1%2011-1-2h-6q-5%200-9-3l-3-7-4-1-2%204%202%204-9%206v-2l-8%201-1-2-1-2h-2v-4h2v-2l-4%201q-4%201-7-2v-4l-1-3v-49q-1-28%204-56l1-5v-3q3-8%201-18l-1-5-3-18a236%20236%200%200%201-5-64v-13c0-13%200-13%204-17%206-6%2014-4%2021-4h17l3%201%2016%202v3l1%2030v36l3%2027v8h2v-83h3q2%204%202%209v45l1%2012v12l2%201v27h2v-3l-1-32v-17l-1-61v-17z'/%3e%3cpath%20fill='%23a0c4e8'%20d='M0%200h218q-7%206-16%205h-11q-19-1-36%207l-2%201q-8%203-14%209l-2%202q-7%207-12%2016-10%2019-29%2025-17%203-31-7l-6-6a72%2072%200%200%200-38-19l-6-1%202%203q6%2013%206%2028h2a61%2061%200%200%201%2029%2014q13%2012%2014%2028l1%204q-1%205%203%2010%2015%2012%2032%2010h11q-7%204-15%203h-7v4c0%2025%200%2025-2%2029l-10-2v63h-1v-2l-1-46v-13l-1-3-4-2v143h-2v-20h-2v28h-5v-58h-2l-1%205h-1l-3-37-4%2069-3-1q-5-17-5-35v-8l-1-5-1-11h-3l-5-37-1%202-5%2018h-1v-42h1l1%205h3q4%200%207%203h3l1-21v-10h-2v4l-4%201-3-2v-2l-4-2-3-3-3-1-3%207h-2l-2-5h-2c-8%209-8%2022-9%2034v2l-3%2034H4v-6H2l-1%2017H0z'/%3e%3cpath%20fill='%23a0c4e8'%20d='M227%200h80l-1%202h-10q-26%200-44%2018a92%2092%200%200%200-23%2055c-2%2012-3%2022-12%2032l-2-1%201-2%202-3%202-3q7-12%206-27l1-3v-9q-2-2-6-2-18%200-32%2012-11%2014-13%2033l-2-1%201-6q-8%202-15%207l-2%201-20%2014-4%203-4-1v5l-6%201-5%202h3q16%200%2031%205l4%201%203-3-2%206%202%201q9%205%2016%2013l-1%202-1-1a63%2063%200%200%200-39-21h-35q-13%201-23-8l-2-1-2-2-2-1q-4-4-3-9-2-20-16-33-13-10-29-12l-2-6q0-14-7-27l9%201h2a65%2065%200%200%201%2032%2017l5%206%207%205%202%201%205%202q14%204%2025-2%2016-7%2024-23%2015-25%2044-33l14-1h21q5%201%2010-2%206-3%2013-2'/%3e%3cpath%20fill='%237bc9d0'%20d='m315%2090%203%203v-2h2c2%2016%202%2016%200%2024q-7%207-17%209l-6%204-3%201-5%204h-2l-1%203-3%203-4-1h-10v2h-4q-5%202-9%206-4%205-10%206-6-1-10-5l-5-2v-2q-7-2-15-2l1%202-5%201v5l-6%203-4%205q-4%204-10%204l-5-2v-2h-2v-2h-6l-5-1q-8-1-14%203l-8%202v2h-2l-1%202-3%204h-5l-13-1h-3l-11%201H99c-6-1-6-1-9-4h2v-25l1-6h3l17-2q24-4%2044%206%2011%206%2018%2015-6-8-15-13l-2-2v-3l-3%201-9-4q-10-3-21-2h-9l9-5%205%201v-5h5l1-3%204-1q12-6%2022-16%206-4%2013-4l1%207%201-7q11-2%2022%204l2%202h3l6%204%203%201%205%204q5%205%2013%205h12c16%201%2016%201%2024-1l8-1q11%200%2018-8l6-3v-2l4-3%203-1%204-2h2l1-2z'/%3e%3cpath%20fill='%23fdfdfe'%20d='M0%200h218q-7%206-16%205h-11q-19-1-36%207l-2%201q-8%203-14%209l-2%202q-7%207-12%2016-10%2019-29%2025-17%203-31-7l-6-6a72%2072%200%200%200-38-19l-6-1%202%203q6%2013%206%2028h2a61%2061%200%200%201%2029%2014q13%2012%2014%2028l1%204q-1%205%203%2010%2015%2012%2032%2010h11q-11%205-23%203-11-3-20-12a59%2059%200%200%200-42-16l-12%202h-5q20-9%2040-1l12%207%202%201q-1-22-18-37-13-9-29-11v-3q0-15-7-29v-2H0z'/%3e%3cpath%20fill='%231b2640'%20d='m17%20144%204%203%201%209v40l1%2026v244l-1%203h-5l-3-4%202%204-3%201H5l-3-15H0V246q0-19%202-37h2l2-11v-2l1-10%202-23v-4q2-8%208-15'/%3e%3cpath%20fill='%23f2e2dc'%20d='M150%20500h3l35%201c28%200%2028%200%2032%203l2%204%203%209v6l-5-9-1%203-3-6h-3l4%2013q8%2016%209%2033h5l2-4v6h2l-1-8q2%204%202%209h27q5-1%2010%203h14q10%201%2022-2h11v15H208l-99%201H70l-7-1-4-8h9l3-1%2011-1v-2l-4-1%2013%201%201-8q5%203%204%207v2l8%201v-4h2v2h2l1-4v2l2-1q8-2%2016-1v-3l4%201-1-3v-8q3%201%204%205v4l3%205%204%201v-3l3-1h2l4-1%207-3%202-7q2-4%205-6l3%201-4%204%2011-1%201%204h2v-2q8%203%2011%2010%202%204%206%203h7l11%201-1-3v-5l-4-18-1-2c-5-15-5-15-9-17v2h-2l-2-8h-2v4h-3l1%202v6l-1-1-1%204-4-6%201%2011-3-3-1%204-2-4h-2l-1%203-1-2-4-1%201%2013-3-1h2l-1-5-6%202q-5-7-7-14l-2%201%201%203v4l-2%202-2-7v10q-4-4-6-10l-1-2q-3-5-1-12l-3-7-5-2v-1z'/%3e%3cpath%20fill='%23233450'%20d='M186%20282q3%200%205%202v5l1%204v28l1%2020h3q4%200%206%202%204%207%203%2014v8h3l5%203q5%208%204%2017v13l1%2012%201%2072v4q0%204-2%207l-8-4%202%203-6%201v-4l-2-6-5%201%201%208c-8%201-8%201-11-1l2-2%201-5-6%202v-8l1-4-1-2-1-9v-3l-1-6v-16l-1%2024h-2l-1%202-1-28v-13l-1-11v-56l4-1%201%2059v-81q-2-5-5-7v-7l2-5h2v-27q0-5%205-5'/%3e%3cpath%20fill='%231b2640'%20d='M320%20170v335c-5-1-5-2-8-5l-5-6v-11l-1-15v-16l-1-57v-31l-2-190%207-2%204-1z'/%3e%3cpath%20fill='%239db5d0'%20d='M0%20455h2q4%207%203%2015l5%201v2h2c19%202%2019%202%2026%206q3%203%202%208h-2l-1%203h-2l1%206-9-5v3l-2%208%202%206v3l3-1%208%201%204-1%201-2%201%202%201%202%206%205-1%204h2l3-1%203-1h2l1%201%201-3h-3l-3-12-4-13-1%202-1%202h-1v-7l-1-7h10q5%200%209-2h7l4%201v-2l-4-2-1-2q5%202%209%206%204%206%2012%207l3%203v6l-1%202-1%202h-1l-1%205-3-4-2%205-5-2%205%2017%201%208-6%201%202%206-2-2q-4-4-9-4l-8%204q-4%205-5%2011h-2q-8%201-14%205l-2%201-2-3q-4-6-10-10-4-2-4-5l-2-3-2-3%201-3-3%201-7-1-1%202-8-4-5%204z'/%3e%3cpath%20fill='%23325074'%20d='M72%20390h2v3l1%2013%201%2021v6l1%209%201%205%207%203%205-3%201%204h2v-2h3v-2l4-1%203%203%202-1h7l1-3h7l-1-7h3v-2h-2l1-4%204-1%206%203%201-3h3v58l-1%209-5%203-2%204-1-1-4-2v-2l-14-1%202%205%206%2016q-4-4-6-10l3%208q2%205%202%2012-4-1-5-5l-1-2-9%201-3-8-1-3-1-3v-7h2q3-7-1-13l-5-1q-7-3-12-10l-2-2h-2l3%202v2h-8l-6%202h-8l-3-1v-24l4-2q3%204%202%209h2v-17h7l2%204v-27zm211%2012h2l4%2017%203%2030-1%203v3l2-1%204%202v-14l1-8%201-7v-13h2v20l1%2030v25l-2%201-5-3-3-1-5-4q-5-2-11-1h-2q-13%200-21%209l-1%202%204%201v3h2l1%202%201-2%201-3%205-1%201%202%203-1%201%202%203%201%201-3h7v4l3-2-1-5q5%202%206%206l2%201%202%202v7l3%204q0%203-4%205-10%201-19-5-14-6-29-6v-5l1-6-6-4%203-2%201-2-2-1v2h-2l-2-4-3-3-6-6-2%201-1-25v-15h4l1%202%206-1v2l-1%201%201%202%203%204%202-1%206%202%207-5-1-2-1-3%203-4q4%200%206%203l1%206%209%202%206%201z'/%3e%3cpath%20fill='%23f7e8df'%20d='M127%20165h3q13%200%2025%205l10%201%2017%203c14%204%2014%204%2019%203l4-5q8-6%2018-7%207%202%2013%207l2%203h-2l-2%201h-2q-6%203-9%208l-1%2010v10l-2-2-6%209-6%2014h-1v-10l-1-3c0-17%200-17-3-20h-6q-2%202-2%206l-1%2040h-2v3h-2v-2l-5-11-9-23-2-5-1-3-3-4v2l-6%204-3%203-2%201-11%208-5%201-4-4-2-3-1-2-1%203-7-6-1-13v-10l-2-6-6-1-3-1h-3v-2z'/%3e%3cpath%20fill='%23325074'%20d='m5%20522%201%202%207%203%201-3%2010%201v2l4%206%202%205%202%201q4%202%204%205l2%201q4%201%206%206l2-1q5-5%2012-5l3%201v-2q1-7%207-12%205-3%2010-1l6%204-2-4q4%201%205%204%205%2015%204%2029h-9l1%203-15%201h-9l2%202%202%206H0v-38l-1-3c0-8%200-8%204-11z'/%3e%3cpath%20fill='%23a0d4dc'%20d='M29%20171h1l1%205h3q4%200%207%203h3l1-6h1v5h2q7-1%2012%203h5l2%204v7l6-4%201%2038v77h-2v-20h-2v28h-5v-58h-2l-1%205h-1l-3-37-4%2069-3-1q-5-17-5-35v-8l-1-5-1-11h-3l-5-37-1%202-5%2018h-1z'/%3e%3cpath%20fill='%239db5d0'%20d='m213%20510%204%201%202%203%201-2%201%202%202%203%201%203%204%204%202%208%201%202h2l1-3%205-2%201-3h2l1-3%203-1v2h2v-2h2l3-1h3l2-1%201-2%206%2013h3v2h2l3%205%201%202%201%202-1-5q4%202%204%206v3h2l-2-8%205-1%201%203%203-2%202%201-1-3h3v-2h2l3%206%201%203%201%205h2l-1-3q-2-3-2-7l4%203%202-3%204%203v2l4%201v6l9-3v14q-18%203-37%203h-3c-7%200-7%200-9-2l-12-1h-2l-6-1h-15l-1-4v3h-2l-1-2-2%201-4-1-2-7-5-19-1-2-5-13z'/%3e%3cpath%20fill='%231b2640'%20d='M26%20155h2v15l1%2032v5l1%20127v60q2%205%206%208l7%202v70l-1%205c-9-1-9-1-12-3l-2-5-3-2-1-19V172q-1-8%202-17'/%3e%3cpath%20fill='%23f2e2dc'%20d='m288%20481%205%204%2010%205q8%205%2012%2012l5%203v33l1%202-1%207q-4%204-9%203v-3l-1-3-3-1-4-4-2%204-1-2-3-3%203%2010h-2q-4-6-5-14h-2l1%203h-3v2h-3l-2%203-1-5-5%201%202%208h-2l-2-5-1%202-3-4-1-2-1-4h-3q-5-3-7-10l-1-2%204-3%205-2h2q7-3%2013%200l2%202%201%201%205-1%202-4%203-4-2-2-1-5-1-6-5-3-1-1-1%202-1%202h-2v-4l-7%201-1%202-4-1v-2h-2l-1%202-1-3-5%201v2l-3%206v-5h-2v-3l-4-1q2-4%206-7l2-2c8-5%2020-5%2028-2'/%3e%3cpath%20fill='%23325074'%20d='M178%20355h3v22l1%2010v39l1%202%201%209h2v-2h13l-1%204%206%201%203%201h6l3%201%201-8h1v44l1%204v4q0%204-2%207l-8-4%202%203-6%201v-4l-2-6-5%201%201%208c-8%201-8%201-11-1l2-2%201-5-6%202v-8l1-4-1-2-1-9v-3l-1-6v-16l-1%2024h-2l-1%202-1-28v-13l-1-11v-54z'/%3e%3cpath%20fill='%231b2640'%20d='m40%20231%205%201%202%2012v2l1%208v13l1%203v2l1%205v114q0%203-3%205h-6q-3-3-3-7V236q0-3%202-5'/%3e%3cpath%20fill='%2377c5e1'%20d='m225%2056%203%203v9l-1%204v3a53%2053%200%200%201-9%2029l-5%203-5-3-6-2-4-2q-10-5-21-5%201-16%2012-27c9-8%2024-14%2036-12'/%3e%3cpath%20fill='%23f2e2dc'%20d='m23%20124%203%201v5l1-5%2018%207%208%204c12%204%2012%204%2015%207l2%208%204%207v45h-1l-1-14-3%203h-2v-4l-1-3-1-3h-3l-5-1q-5-4-11-3l-1-20v-10h-2v4l-4%201-3-2v-2l-4-2-3-3h-2l1-12-4-1zm50%20351q5%202%209%206%204%206%2012%207l3%203v6l-1%202-1%202h-1l-1%205-3-4-2%205-5-2%205%2017%201%208H76l-5-6-4-4-1%2011h-2l-2-8v-6h-3l-3-12-4-13-1%202-1%202h-1v-7l-1-7h10q5%200%209-2h7l4%201v-2l-4-2z'/%3e%3cpath%20fill='%231e2840'%20d='m200%20191%205%201q2%204%202%209v54h2l4%202v16l-1%203h-5l1%203v14l1%207v25l-2%204h-5c-4-4-2-19-2-25v-3l-1-22v-3q1-7-4-13v-67q0-6%205-5'/%3e%3cpath%20fill='%237193c3'%20d='m229%20472%202%201v3l3%201%203%203%202%202%201%204h2v-2l3%201-2%204%202%202q3%202%202%206l-2%206%2012%202%201-3v3h4q8%201%2016%206l8%203%206%201-1%203-5%202-2-2q-3-4-8-3l-10%203-8%202-3%201-7%201v2l-5-1-1%204h-2v3h-2l-5%204h-2l-4-10-2-3c-4-9-4-9-3-14l4-2%203%205%202-1v5l2-4-2-3v-5l-3-1h2l-3-2v-22q0-3%202-5M26%20142l1%202%203-1%202%202%204%204v2l7%201v-4h2l1%206v8l-1%2017-4%201-5-3h-5l-1-1-1%2037h-1v-58h-2l-1%2021v281l-1%204%201%203v5l4%202%201%205-16-2h-2l-2-1-1-3%206-1-2-5%203%201%201%204%205-1V163l-1-4q0-9%205-17'/%3e%3cpath%20fill='%23f7e8df'%20d='M286%20170c8%200%208%200%2011%203v9l1%208v28l1%2087h-2v-27l-3-1v-32l-1-37v-3l-1-5-2-1-1%2083h-2v-11c-1-6-1-6-3-8v-9l-1-7v-70h-4q3-9%207-7'/%3e%3cpath%20fill='%23f2e2dc'%20d='M0%20455h2q4%207%203%2015l5%201v2h2c19%202%2019%202%2026%206q3%203%202%208h-2l-1%203h-2l1%206-9-5v3c-2%2013-2%2013-7%2017l-2%201-3-1-1-6-4-1%202-3v-3l-3%201v-2q-3%202-4%207v3l-3-1%201%206H0z'/%3e%3cpath%20fill='%23a0d4dc'%20d='m0%20114%2012%204%202%201c6%202%206%202%208%205v8h-2l-1-4v5l-1%203-1%205v3l-3%207q-4%207-5%2015v3l-4%2046H4v-6H2l-1%2017H0z'/%3e%3cpath%20fill='%235485b2'%20d='M134%20473h1v12l-1%2013-5%203-2%204-1-1-4-2v-2l-14-1%202%205%206%2016q-4-4-6-10l3%208q2%205%202%2012-4-1-5-5l-1-2-9%201-3-8-1-3-1-3v-7h2v-10l1-6%202-2q3%200%205%202l1%201-4%206%206%202v-7l7-1-1-3%202-6-1-3q9-1%2016%203l2%201z'/%3e%3cpath%20fill='%23f2e2dc'%20d='M222%20245h1l2%2013%201%205%204%2022%201%203%201%205q2%2016-2%2031l-1%207-1%203-1%208-2%208h-1l-5-24q-5-26-1-52l1-8%201-4%201-14z'/%3e%3cpath%20fill='%237193c3'%20d='m73%20188%201%2038v77h-2v-20h-2v28h-5v-58h-2v-5l1%204h2v-2l1-15q3-11%200-20-4-12%200-23%205-5%206-4'/%3e%3cpath%20fill='%235485b2'%20d='m5%20522%201%202%207%203%201-3%2010%201v2l4%206%202%205%202%201q4%202%204%205l2%201q7%206%208%2014l1%202c-8%201-8%201-11-1l-4-7-3-3h-2l2-3-4%202%201-7-26%2012v-17c-1-9-1-9%201-12z'/%3e%3cpath%20fill='%23233450'%20d='M24%20315h1l1%20125%2014%201%201%203h2v28l-1%207c-9-1-9-1-12-3l-2-5-3-2-1-13z'/%3e%3cpath%20fill='%235485b2'%20d='M182%20436q3%204%202%209v2l1%2016v4l2%206%201%202-2%201v9l2-2%204%201-3%207h9l-1-3v-4l2-2%205%201%202%209%204-1-2-4%208%206-5%208-16%201-16-1v-3l-1-5v-42h1l1%2011h2z'/%3e%3cpath%20fill='%2377c5e1'%20d='M12%20290h1l2%2017v4l2%2032q4%2027-2%2053-3-4-3-10l-1-3-1-4-1-3-2-10-1-3%201-11v-8l1-7v-7l2-11v-8l1-3z'/%3e%3cpath%20fill='%235485b2'%20d='M301%20175h2l2%20102v54l1%2040v23l1%2099q-3-4-2-10v-3l-1-15-1-74-2-122z'/%3e%3cpath%20fill='%23f2e2dc'%20d='M108%20499h9q3-1%205%202l6%2012%204%209q3%208%202%2017l-3-2v-2h-2v2q-5-2-9-8v-2l-4%201-1-2-1-4-2-3-2-5v-5l5%209-2-3-1-5-2-2v-2l-1-2z'/%3e%3cpath%20fill='%237193c3'%20d='M22%20198h1l1%2046v221l1%202v2l4%202%201%205-16-2h-2l-2-1-1-3%206-1-2-5%203%201%201%204%205-1z'/%3e%3cpath%20fill='%235485b2'%20d='M320%20547v14q-18%203-37%203h-10l-2-3%201-1%207-7q2-2%206-2%205%200%209%202%208%202%2017-2l6-3z'/%3e%3cpath%20fill='%2377c5e1'%20d='M283%20402h2l3%2013%201%204q4%2016%202%2032l-1%204-1%203-1%2012h-2l-3-13-2-4v-3l-1-4q-2-9%200-19v-2l1-7%201-5z'/%3e%3cpath%20fill='%23f2e2dc'%20d='M239%20212h2l2%2013%201%204%201%203v4q4%2018-3%2034h-2l-5-10q-5-10-1-20l1-7%202-8v-4z'/%3e%3cpath%20fill='%23a0d4dc'%20d='M232%20299h1l-3%2025-1%207-1%203-1%208-2%208h-1l-5-25-1-9-1-3-1-13h11l5%201z'/%3e%3cpath%20fill='%237193c3'%20d='M7%20497h2v2h2l1-2%201%204-2%203%204%201%201%206h7v3l2%2013v4l-2-3%201-3-3%201-7-1-1%202-8-4-5%204v-15h3l-1-6%202-1%202-7z'/%3e%3cpath%20fill='%23f2e2dc'%20d='m0%20114%2012%204%202%201c6%202%206%202%208%205v8h-2l-1-4-1%205-4-1v5l-5%201-1-1-1%203-2%204-5%201z'/%3e%3cpath%20fill='%235485b2'%20d='m229%20472%202%201v3l3%201%203%203%202%202%201%204h2v-2l3%201-2%204%202%202q3%202%202%206l-3%206q-8%201-16-1l2-1-3-2v-22q0-3%202-5'/%3e%3cpath%20fill='%23325074'%20d='m5%20522%201%202%204%202%2013%2013v2l-5%203-2%201-3%202-13%206v-16c-1-9-1-9%201-12z'/%3e%3cpath%20fill='%2377c5e1'%20d='M29%20171h1l1%205h3q4%200%207%203h3l1-6h1l1%2011v9l-1%206-6-2-2%206h-1l-1-10-1%202-5%2018h-1zm81-39-1%201q-2%203-2%207%201%204-2%207l-1%204-1%203v2l-1%203-1%206H91l-1-2h2v-25l1-6%207-1h2z'/%3e%3cpath%20fill='%23a0d4dc'%20d='M285%200h22l-1%202h-10q-26%200-44%2018a92%2092%200%200%200-23%2055c-2%2012-3%2022-12%2032l-2-1%201-2%202-3%202-3q7-12%206-26l1-4v-9q-2-2-6-2-18%200-32%2012-11%2014-13%2033l-2-1q2-23%2019-38%2015-8%2032-8l-1-3-1-14h1v3l1%203v4l3%209%201-2c10-25%2023-43%2048-54z'/%3e%3cpath%20fill='%237193c3'%20d='M293%20201h1l1%206h2l1%207v8l1%209v74h-2v-27l-3-1v-22l-1-10z'/%3e%3cpath%20fill='%23325074'%20d='m115%20537%209%207q3%206%203%2013-6%202-13-1l-5%201-4-16q4-4%2010-4'/%3e%3cpath%20fill='%235485b2'%20d='m55%20456%204%203v6h2v7h4q6-1%2011%205l2%204h-8l-6%202h-8l-3-1v-22zm244-42h2v20l1%2030v25l-2%201-4-3v-12l1-26q2-17%202-35m-16-224h1l1%2032%202-1v-5l1-3v-13h1v82h-2v-11c-1-6-1-6-3-8v-9l-1-7z'/%3e%3cpath%20fill='%2377c5e1'%20d='M72%20390h2q3%2039%202%2078h-2l-4-20v-23l2-23z'/%3e%3cpath%20fill='%23233450'%20d='M178%20355h3v89h-2l-1-22v-3l-1-9v-52z'/%3e%3cpath%20fill='%23325074'%20d='M90%20533q8%202%2013%208%206%209%204%2020l-2%201-1%204-8-1-1-8%202%202q-1-11-6-23z'/%3e%3cpath%20fill='%23233450'%20d='m74%20160%205%202%201%2063h-1l-1-27h-1l-1%2018-1%207v18h-1z'/%3e%3cpath%20fill='%23325074'%20d='m161%20444%206%202v34l-5-2v5h-1l-1-14v-21z'/%3e%3cpath%20fill='%237193c3'%20d='m86%20551%203%203h-2q-10-3-19%202l-6%207%2011-2q7-2%2013-1l5%204h-9l1%203-10%201h-3l-2%201H58l-2-4h2l2-1%201-3q3-7%209-9%208-3%2016-1M73%20188l1%2030h-2v5l-3%201c-3-9-6-23-2-32q5-5%206-4m241%2087h2v7l4%204v45l-3-2v-6l-1-4v-16q1-3-2-5z'/%3e%3cpath%20fill='%23a0d4dc'%20d='m17%20358%202%201-1%2012-1%204-2%2021-5-14-2-18h9z'/%3e%3cpath%20fill='%235485b2'%20d='M284%20490q5%202%206%206l2%201%202%202-1%207-6%202v-2l-3-1-5-2-2%204-2-1%201-4-1-9h7v4l3-2zm-180-40%204%201%201%206-4%203-2-1-2%204-4-4v-4h4l2-4zm-6%2013%206%202-1%204h-6l2%201%205%203v5l-4%202-5-4-1-9%204-1z'/%3e%3cpath%20fill='%23325074'%20d='M298%20320h2l1%2063v22h-2z'/%3e%3cpath%20fill='%2394caca'%20d='M241%20249h6q-1%2011-5%2021h-2l-2-4-1-2-1-2-1-3-3-9z'/%3e%3cpath%20fill='%23a0c4e8'%20d='M18%20126q3%202%202%206h2v-3h2l1%202%203%201v8q0%203-3%205l-2%205h-2l-1-2-3-4-1-5%201-1%201-6z'/%3e%3cpath%20fill='%235485b2'%20d='m160%20477%208%203v11l-1%209h-6l-1-8z'/%3e%3cpath%20fill='%23325074'%20d='M320%20552v9l-25%203v-4l15-6h2z'/%3e%3cpath%20fill='%235485b2'%20d='M85%20472q8%202%2012%208l1%202-1%202-6%201-4%201-4-1-3-4-1-4q2-4%206-5'/%3e%3cpath%20fill='%23325074'%20d='M24%20315h1v147h-1z'/%3e%3cpath%20fill='%239db5d0'%20d='M194%20194h1v61l-2%201-7-20-1-2%201-6c5%208%205%208%204%2013h2v-3h2zm70%20292%203%201%205-1-1%209-1-2h-2l-1%202-1-3-5%201v2l-3%206v-5h-2v-3l-4-1q4-7%2012-6M127%20174h1v26l4%202%203%202-1-2q7%204%2010%2011l1%202%203%204-1%202-1-2q-5-6-11-9l-5-4%206%207-8-6-1-12zm156%2016h1l1%2032%202-1v-5l1-3v-13h1v28l-2%2011-1-2-1%205h-1l-1-35z'/%3e%3cpath%20fill='%23f2e2dc'%20d='m281%20445%203%202h4l2-2-2%2025h-2l-2-10-1-2-1-3-1-3z'/%3e%3cpath%20fill='%23a0d4dc'%20d='m153%20132%204%201%203-3-2%206%202%201q9%205%2016%2013l-1%202-1-1a63%2063%200%200%200-39-21h-20l-1-2q20-4%2039%204'/%3e%3cpath%20fill='%239db5d0'%20d='M73%20475q8%203%2012%2010l-1%202-27-3v-1h3l7-3h7l4%201v-2l-4-2z'/%3e%3cpath%20fill='%23a0d4dc'%20d='M291%20436v13l-2-2-2%201h-3l-2-2-2%201-1-8%205-1%203-1z'/%3e%3cpath%20fill='%239db5d0'%20d='m12%20567-1%202H9v2l5%205H0v-9q6-3%2012%200'/%3e%3cpath%20fill='%23f2e2dc'%20d='M70%20441h6v27h-2z'/%3e%3cpath%20fill='%23233450'%20d='m55%20456%204%203v14l-6%202v-17z'/%3e%3cpath%20fill='%239db5d0'%20d='m170%20193%202%201%201%204%204%2015v6l-6-16%202%2011-3-3-1-3v-2l-1-2-5%203%202-6-3-2%208-4z'/%3e%3cpath%20fill='%23325074'%20d='m130%20542%204%201%202%201%204%203-1%2011-5%201v-3l-3-8z'/%3e%3cpath%20fill='%235485b2'%20d='m0%20512%206%202%201%204%203-1%202%204h-2l-2%204-3-2-5%204z'/%3e%3cpath%20fill='%23f2e2dc'%20d='m79%20161%202%201v64h-1z'/%3e%3cpath%20fill='%2378aed8'%20d='M81%20309q4%204%204%209l-3%2012-4-7q0-7%203-14'/%3e%3cpath%20fill='%239db5d0'%20d='M7%20497h2v2h2l1-2%201%204-2%203%201%202-6%202%201%201v6l-6-2%202-1-1-6%202-1%202-7z'/%3e%3cpath%20fill='%23325074'%20d='M29%20307h1v88h-1z'/%3e%3cpath%20fill='%23a0d4dc'%20d='M250%20274h2q4%208%202%2017l-1%202c-6-5-6-5-6-9l1-5%201-3z'/%3e%3cpath%20fill='%23325074'%20d='m92%20405%206%202q4%205%204%2012l-2%201v-4h-2v3l-3-1-2-5-2-2-1-1zm-18%2071%204%203v2h-8l-8%202v-9q6-1%2012%202M22%20329h1v85h-1z'/%3e%3cpath%20fill='%235485b2'%20d='m318%2060%202%201v17c-7-5-7-5-8-9q2-5%206-9'/%3e%3cpath%20fill='%239db5d0'%20d='M220%20201q3%204%202%209h-2q-4%201-6%206t-6%208q1-8%207-15l1-3zm-13%20310%204%203%201%202%201%202%201%202%204%2010%201%203%203%2015-2-1-1-5-11-27z'/%3e%3cpath%20fill='%231b2640'%20d='M177%20356h3v38h-1z'/%3e%3cpath%20fill='%2378aed8'%20d='m71%20203%201%203-1%202h2l1-2v12h-2v5l-3%201q-2-10%201-20z'/%3e%3cpath%20fill='%235485b2'%20d='M23%20166h1v53h-1l-1-33v-3z'/%3e%3cpath%20fill='%239db5d0'%20d='m226%20502%203%201h2l3%209-4%203v-2l-5-7-4%202-2-5z'/%3e%3cpath%20fill='%23325074'%20d='M60%20245h1l1%2011%201-3h2v8q0%203-2%205l-1%201-4-2-1-4%202-2%201-7z'/%3e%3cpath%20fill='%237193c3'%20d='M286%20231h1l1%2020h-1l-1%209h-2z'/%3e%3cpath%20fill='%235485b2'%20d='M121%20557h6v3h-3l-15%202v-5q6-4%2012%200'/%3e%3cpath%20fill='%23325074'%20d='M320%20492v13q-6-1-8-6l1-4z'/%3e%3cpath%20fill='%235485b2'%20d='M298%20258h1v47h-2zM121%20461l5%202%201%205-1%202h-6l-3-5z'/%3e%3cpath%20fill='%239db5d0'%20d='M97%20493q3%203%201%207l-3%204-2%201v-5l2-2zm53%2031%202%201-1%203-2-2z'/%3e%3cpath%20fill='%23325074'%20d='m303%20521%203%201-1%203z'/%3e%3cpath%20fill='%239db5d0'%20d='m164%20499%202%202-3-1zm23%2021h2l-1%202z'/%3e%3c/svg%3e",
	canyon: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='576'%3e%3cpath%20fill='%23b35a69'%20d='M0%200h320v576H0z'/%3e%3cpath%20fill='%23bf392b'%20d='m83%20187-1%20141h-7v28q-1%203%202%204l2%201%2022%208%202%201%204-2%202-2%202-3%206-7%201-2%203-3q4-7%2011-7l18-5q14-4%2030-1h2q10%201%2016%207v7h9l14%202%202-3%202-3%202-2c5-8%205-8%208-9h3q8-1%2016-5l7-1%2018-3%2010-3q14-1%2023-12l3-4q0-2%205-3v270H0V279l17-5h2l5-1v-28l3-5%205-2%202-4%202-2%201-8q-1-8%202-16%208-7%2019-11l9-4c13-6%2013-6%2016-6'/%3e%3cpath%20fill='%23f1ecf5'%20d='M0%200h320v94l-5-4-5-1-4-2-2-6q0-4-4-8v-2l-2%201h-9v5l-3-1v-2l-2%201h-6v4l1%2019c1%2013%201%2013-1%2018l-9%207q-4%203-4%208v26l-14%205-12%202-13%201h-3l-17-1-1%205h-1v-5h-5v7h24q15%202%2030-3l11-1v8q-18%206-38%205c-20-1-37-1-53%2013l-5%205-9%207-2%202q0-4%203-6l5-3%203-4q5-8%2014-11l2-1q6-3%2013-4v-6l-2-1%203-1-1-4q0-12%204-24l4-17h-6l-4-1q-9%200-18-6-6-3-13-1a61%2061%200%200%201-25-2l-5-1-7%208q1-5%204-9l-2-1-3-2-3-1-4-4q-6%201-10%204l-9%204%201%2016v3l3-1%205-1%202-1%202-1h2l6-2q-8%208-21%208v3c-2%2016-13%2030-25%2039a83%2083%200%200%201-49%2015l-14-2-1-4H8l-8-4-1-7v-30l1-14z'/%3e%3cpath%20fill='%23db5c37'%20d='M320%20306v193h-8l-4%202-2%201-4%207-6%208-3%206-1%202-5%201c-6%200-6%200-8%202l-8%201-1-2-2-1q-10-6-14-15l-1-6-2-1%201-2v-8h-3l-2%2010h-2l-1-8%202-3q1-5-3-9l-8-5-4-3-2-2-4%201v2l-10-1v2l-7%207q-3%207-2%2014l3-2%204%201%201%2029%201-2h2v-3h2l1-2q2-4%206-7h2l-4%2014-1%204-1%203h-2v2l2-1%203-2%203-2%208-2q-1%205-5%208l-1%202-2%201h13l-3%206q-10%207-22%206h-4l-9-1-6-2-3-1q-5-1-8-5v-2l2-1-1-3h-2v-3q5%201%209%206v2l5%201-2-4-2-4-1-3c-4-7-4-7-3-11l3-1q5%201%208%206v-8l1-3v-4l1-6h-11q-8%200-15%205v3q-7%200-14-3-5-3-12-2l-4%202q-9%203-19%201h-10l1-2v-3l-4-3v-4l4-1-1-3q-2-4-2-9%206%201%2011%206v-3l1-3v-3l3-6h5l3-1%201-2h4l1%205h2l1-2%205-5q3%2011-3%2022l-1%202%204-3%203-12%203-11q3-6%203-13l1%202%202-2-1-5-1-2v-3l-1-3-2-7-6%206-1%202-12%2015h-2l2-6-2%201v-2h-4l1-8v-12h2v-2c0-8%200-8%203-11l3-1%203-1h14l1%202h2v2q7-3%209-10v-7c0-20%200-20%204-25l8-5%207-4%209-5%204-3%205-2q9-4%2015-14c6-9%206-9%209-10h3q8-1%2016-5l7-1%2018-3%2010-3c12-1%2017-5%2024-14l2-2q1-4%205-3'/%3e%3cpath%20fill='%23944e6c'%20d='M116%20104q5%201%209%204l2%201%205%205-5%207%207-8%208%202%2011%201h2l11-1q7-1%2012%203%2010%205%2022%206l5%201-5%2025-2%2018v2l-2%201%201%201v6l-3%201q-14%203-25%2013l-1%202q-3%206-8%208l-2%202q1%205%204%209l12%2019%206%2010q2%203%202%208%200%209%207%2016l3%205-1%203-5%201v2l-4%201%201%208h-3v3l-1%2049h-3q-14-1-26%203l-10%202c-14%202-14%202-18%207l-4%206-7%208-1%202-2%202-1%202-4%201-28-12v-31h6l2-103v-38l-2%201-9%204-4%202-20%209q-5%201-8%205l-2%2016q0%208-5%2013l-5%203-3%205v28q-12%204-25%206v-98l11%204%201%204q30%206%2057-10l9-7%203-2q13-13%2018-31v-3l1-2%208-3%209-3-2%201-4%201-3%201-7%201v-6l-1-4-1-9%203-2%205-2%202-1%202-1%202-1z'/%3e%3cpath%20fill='%23fba92f'%20d='m229%20471%201%202q3%205%209%207l7%205v10l-1%201v8h2l2-10h3l1%208q0%2010%207%2016%205%206%2011%209v2l4-1%203-1%203-2h11v-2q2-6%205-8l6-9q1-4%205-6l2-1h10v77H9l9-8%207-6%205-2%204-3%207-2%205%202h9l9-9v-2l-4-1v2l-4%205h-1v-6q6-7%2015-11l5-3%202-1%203-3%203%201q12%203%2024-4l2-3-12%201q5-9%2016-12%2013-2%2025%200%205%201%209-2%208-3%2016-1l6%203%209%202-1-3c8-7%2017-5%2027-5l-1%2023-4-5q-2-2-5-2h-2q1%209%206%2016l1%206q-4%200-7-3l-3-3-4-3v3h2l2%204h-3q4%206%2013%208l4%201%209%202%201-4v3q15%202%2026-6l2-5h-5l-3%201-8%201%208-8%203-5-2%201-4%202-3%202-7%202v-2h2l1-4%205-17-4%203-2%202-3%204h-2v3h-2l-1%203h-1l-1-30-6%201q-2-7%201-14l6-7h2l-1-3%2011%202v-2l3-1z'/%3e%3cpath%20fill='%23b35a69'%20d='m83%20187-1%20141h-7v30l-8-2q-25-5-50-7h-3l-14%201v-71l17-5h2l5-1v-28l3-5%205-2%202-4%202-2%201-8q-1-8%202-16%208-7%2019-11l9-4c13-6%2013-6%2016-6'/%3e%3cpath%20fill='%23558ace'%20d='M116%20104q5%201%209%204l2%201%205%205-5%207%207-8%208%202%2011%201h2l11-1q7-1%2012%203%2010%205%2022%206l5%201-5%2025-2%2018v2l-2%201%201%201v6l-3%201q-14%203-25%2013l-1%202q-2%205-5%207l-3%202-4%201v-2l-10-26-6-15-2%201-6%201-2-2-6-1-9-1-1%202-5%206-11%2013q-4%206-7%205l-3%201q-10%202-20%208l-28%2014-1%205-1%2011q0%209-8%2015l-2%201-3%205v28q-12%204-25%206v-98l11%204%201%204q30%206%2057-10l9-7%203-2q13-13%2018-31v-3l1-2%208-3%209-3-2%201-4%201-3%201-7%201v-6l-1-4-1-9%203-2%205-2%202-1%202-1%202-1z'/%3e%3cpath%20fill='%23bb2427'%20d='M233%20191h20l6%201h18l3%201%201%209v8h23l1%2012%201-7h14v65l-12%201-1%201h-7l-4-1-8-2h-12c-10%200-10%200-14%202h-8l-2-7q-12%200-22%203h-4l-1-13-8-1-1%203v-46l15-1z'/%3e%3cpath%20fill='%23db5c37'%20d='m46%20453%204%202v6l-1%202%202%207h2l1-4%202%203%203-5%205%203v5l2%206%205%201%203%202h3l1-2h3v13l1%2014%201-2v-2l1-3%203-4%204%201v10h1v-2q1-8%205-14l3-1-3%2013%203%201v2h2l7-1%205%206q-5%206-12%208l-5%205%203-1h9q-2%205-7%207-11%204-22-1l-1%203-4%203-3%202-3%201-3%202-9%204-1%208h2l2-6%205%201q-3%208-10%2012-5%202-11-1-4-2-9%200l-6%205-2%201-7%205c-8%206-10%208-20%208V458h2l4%206%2011%2016h2l-1-10h2l1%203v5l1%202q0%207%205%2012v3l6-2%204-1%205-3v-4h3l-2-3-1-15q1-3-2-5l-2-1v-5c5-4%205-4%208-3'/%3e%3cpath%20fill='%23922529'%20d='m314%20324%206%201v174h-8l-4%202-2%201-4%207-6%208-4%208h-11l2-3%201-6-3-2%203-1q5%200%207-4h2l-2-3-3-6%203-5q5-6%205-13l-3-5q-1-3%203-6l3-3%202-2%204-4-4-8-1-5h-11q-7%200-13%202l-12-25-1-3v-9l4-4%202-2%202-2-1%201-2%202-2%201-6%204-2-5-1-2q-2-6%201-11l2-4%203-5%202-2%204-8q12-21%2030-38l10-10z'/%3e%3cpath%20fill='%23944e6c'%20d='M300%2071q5%206%206%2014v2h2q8%201%2012%207v121h-14l-1%2016h-1v-21h-23l-2-17-15-1v-25l-20%204-12%201-33-1v-7h5l1%202%201-2h14q16%200%2031-4l13-3v-18c0-12%200-12%203-17l10-6v-12l1-9V75h10l1%202v-5h4l3-1z'/%3e%3cpath%20fill='%23922529'%20d='m232%20343%204%207%201%203%202%207%205%2014%204%2011%201%203%207%2018%201%203%203%207q4%207%201%2016l-1%202-2%205-2%206-2%206%201%201%201-3q2-12%207-22%204%202%204%206l1%203%203%206%203%2011-2%201-3%201-3%201q-3%201-5%204v11h-8l-7%202-3-9c-7-1-7-1-11%202l-4%209h-3v2q-6%202-10-2l-13-11c-17-14-17-14-17-18q-1-12%206-22l2-4%2016-38%203-8%202-5%201-2q3-7%209-13h2v-2l4-6%201-2z'/%3e%3cpath%20fill='%23fbdeb4'%20d='m228%2039%2010%204%203%201%207%207%204%202%203%202%202-4q6%201%2011%205h8c6%206%203%2022%203%2030v10c1%2017%201%2017-2%2022l-8%205-4%204v16l-4%202h-3q-4%201-8-1v-1h-3l-1%203-4%201-5%201c-10%202-10%202-14%205l-3-1-1%202q-2%204-7%205h-4l-1-2-1%202h-6l5-28%201-4%203-11%202-8%201-4%203-12%201-6%201-6%209-33%201-3z'/%3e%3cpath%20fill='%237c2832'%20d='M177%20412h2l3%2020%201%206%201%2010%203%2019h2l-1-4-1-10%2016%2013%2012%2010-2%204-5%205q-3%207-2%2014l3-2%204%201%201%2029%201-2h2v-3h2l1-2q2-4%206-7h2l-4%2014-1%204-1%203h-2v2l2-1%203-2%203-2%208-2q-1%205-5%208l-1%202-2%201h13l-3%206q-10%207-22%206h-4l-9-1-6-2-3-1q-5-1-8-5v-2l2-1-1-3h-2v-3q5%201%209%206v2l5%201-2-4-2-4-1-3c-4-7-4-7-3-11l3-1q5%201%208%206v-8l1-3v-4l1-6h-11q-8%200-15%205v3q-7%200-14-3-5-3-12-2l-4%202q-9%203-19%201h-10l1-2v-3l-4-3v-4l4-1-1-3q-2-4-2-9%206%201%2011%206v-3l1-3v-3l3-6h5l3-1%201-2h4l1%205h2l1-2%205-5q3%2011-3%2022l-1%202%204-3%203-12%203-11q3-6%203-13l1%202%204-1v-2l-2-8-1-2c-3-12-3-12-1-16l5-6%203-4%202-2%202-4z'/%3e%3cpath%20fill='%23655177'%20d='M217%20263h8l1%204v10l2-1%2024-3%202%207h6l4-1q8-2%2016-1h11q4%200%207%203h7l3-1h12v13l1%203-1%2010-6%204-3%204q-5%209-15%2011l-5%201-6%201-39%208-6%201q-5-6-5-13l-3-4-1-3-1-3-3-1-2-1-1-8h-2l-14-5-7-3-1-3h2l-1-8%208-1v-8l1-8h3l3-1z'/%3e%3cpath%20fill='%23922529'%20d='M74%20416q3%201%205%204l1%203%202-3h3l-1%202q-1%2010%206%2019%204%207%2011%2013l2%202h2l1-4%202%201%201%203%202%201v3l3%204%206%202%202%201h6l1%204%203%206h2-2q-3%207-3%2016l-7-5-5-2%204%2013h-5v4l2%201%202%201-1%206h-6l-2-3-2-3h-7l-4-1-1-5%203-10q-6%207-7%2017h-3v-10l-4%201-2%205-1%203-1%202h-1v-28h-3l-1%203q-6-1-7-3h-5l-2-14-4-1-2%206-3-3-1%203h-2l-3-5%201-4%201-4q0-3-4-4-6%201-7%203v5l2%201q3%202%202%205v3q0%208%202%2015h-3l1%205q-7%205-16%205-6-10-8-22l-1-6v-7h4l1-4%203%201-1%206q5-2%207-8l5-9-2-4%203-1q5-2%205-5v-2l1%202h5l1-6%203%201%202%205%203%201-1-9h3l2%205%203-2%204%201v4h2v-2l6%201-1-3v-3l-1-4z'/%3e%3cpath%20fill='%23655177'%20d='m148%20179%205%2011%204%2013q2%207%207%2013l10%2016%206%2010q2%203%202%208%200%209%207%2016l3%205-1%203-5%201v2l-4%201%201%208h-3v3l-1%2049h-3q-12-2-25%202l-6%201-1-7v-21l1-18v-56l1-25v-5z'/%3e%3cpath%20fill='%23db5c37'%20d='M261%20419h2l1%202%204%2010%201%203%207%2016%204-1q9-2%2020%200%205%205%206%2011-2%206-8%2010l-1%201-4%204%204%2010q-2%207-7%2012l-1%203%202%204%202%205-9%206%201%204-6%209-8%201-1-2-2-1q-10-6-14-15l-1-6-2-1%201-2v-8h-3l-2%2010h-2l-1-8%202-3q1-5-3-9l-8-5q-4-2-6-7l2-6q2-3%207-3l5%201%203%208%202-1%207-1h2l4%201-1-2q-2-7%202-12l12-4-10-25-9%2024-2-1%201-2%203-9%201-3%201-4%201-2q3-6%201-12'/%3e%3cpath%20fill='%23922529'%20d='M274%20192h5q2%204%202%2010v8h23l1%2012%201-7h14v65l-12%201-1%201h-7l-4-1q-5-4-12-3h-9v-55l1-26v-3z'/%3e%3cpath%20fill='%23b35a69'%20d='m194%20274%204%206%202%201%202%207v2l-1%205h2l12%204%202%201%207%203%201%208%203%201%204%203%204%208v3l4%208v2l3%201h-2q-6%201-10%204l-6%208-1%202-3%204h-2l-14-2-7-1v-3q-1-4-4-6-7-4-15-4v-39l1-7v-7l2-1-1-2%201-5%204-1v-2c5-2%205-2%208-1'/%3e%3cpath%20fill='%23dce1f2'%20d='M304%200h16v94l-5-4-5-1-4-2-2-6q0-4-4-8v-2l-2%201h-9v5l-3-1v-2l-2%201h-6v-2q1-9-2-16l-3-1-2%203v-2h-2l-4-3q0-4%205-7l1-2%204-1%202-1h5q9-8%2014-21l-1-5%203-2v-3q0-7%206-12'/%3e%3cpath%20fill='%23b98c97'%20d='M320%20129v86h-14l-1%2016h-1v-21h-23l-2-17-5-1%202-4h2l2-4%203-3%202-2%202-2%202-2%202-1%202-2%204-4q6-2%207-8v-20l1-10%203%201z'/%3e%3cpath%20fill='%23922529'%20d='m314%20324%206%201%201%2022c1%2013%201%2013-1%2018q-4%204-9%205-8%203-12%2010l-2%202-14%2014-4%204q-3%205-10%207l-4%204-3%203h-2l-2-5-1-2q-2-6%201-11l2-4%203-5%202-2%204-8q12-21%2030-38l10-10z'/%3e%3cpath%20fill='%23922529'%20d='m310%20324-1%205-3%202-7%208-15%2015q2-8%206-14l2-3%202-3%201-3q4-5%2011-6l2-1zm-14%204q-1%206-6%2011l-19%2033-11%2020-2%202-1%203-1%201h-2l-5-14-2-5-5-15-2-4-5-18%203-1%2013-3h2l34-8%203-1%202-1z'/%3e%3cpath%20fill='%23655177'%20d='m163%20457%201%202%202-1%206%202v2l-3%2010v3l-3%2012-1%202-4%2016h6v-3c0-13%200-30%209-40l2-2%202%201-2%208-2%208-1%205-1%2013%202-3q2-3%205-4h2l-3%2015h6v-13l1-3v-3l2-4v25l-11%205v3q-7%200-14-3-5-3-12-2l-4%202q-9%203-19%201h-10l1-2v-3l-4-3v-4l4-1-1-3q-2-4-2-9%206%201%2011%206v-3l1-3v-3l3-6h5l3-1%201-2h4l1%205h2l1-2%205-5q3%2011-3%2022l-1%202%204-3%203-12%203-11q3-6%203-13'/%3e%3cpath%20fill='%23b98c97'%20d='M68%20193q0%204-3%207l-2%202-5%204q-5%206-4%2014v7l-1%2011-11-5v46l-3%208-1-4q-3%205-4%2011v19h2l1-2v3l4%201%201%207q1%204-2%207h-2v2l-8-1v-2l-5%202-1-8v-71c0-8%200-8%203-12l5-1%202-4%202-2%201-8q-1-8%202-16%2010-8%2022-12l4-2z'/%3e%3cpath%20fill='%23fba92f'%20d='M12%20348h8l42%206h3q9%201%2015%208l-1%207-4%202-4%206q-2%203-5%203h-8l-2-4q-10-4-23-3h-2l-31%201v-24z'/%3e%3cpath%20fill='%23f9f1f5'%20d='M205%20129q2%206-1%2012l-3%2017%205%201%201-6h1v6c8-2%208-2%2010-5l2-5%201%204%202-2%2014-4%205-1h2l2-1%201-2%206-1v2q5%202%209-1h3v14l-14%205-12%202-13%201h-3l-17-1-1%205h-1v-5h-5v7h24q15%202%2030-3l11-1v8q-18%206-38%205c-20-1-37-1-53%2013l-5%205-9%207-2%202q0-4%203-6l5-3%203-4q5-8%2014-11l2-1q6-3%2013-4v-6l-2-1%203-1v-2q-2-11%202-24l1-4z'/%3e%3cpath%20fill='%23655177'%20d='M78%20479h3v13l1%2014%201-2v-2l1-3%203-4%204%201v10h1v-2q1-8%205-14l3-1-3%2013%203%201v2h2l7-1%205%206q-5%206-12%208l-5%205%203-1h9q-2%205-7%207-11%203-24-1l-8%202q-7%201-12-2l-5-5%2014%201v-2l-2%201q-3%200-7-3l-3-2-3-4%2011%201-2-2-2-2%201-4v-11h4v-5h3l2%208%201-2%201-2%201-2%204-3z'/%3e%3cpath%20fill='%23b98c97'%20d='m192%20558%203%201q8%204%2014%2011l2%206h-88q-1-6%204-9c16-15%2045-18%2065-9'/%3e%3cpath%20fill='%237c2832'%20d='M300%2071q8%2010%206%2024v12h-8q-3-1-5%202l-1%202h-3v9l-1%203-1%2012-4%201-1%202-6%202-1%202-2-1-6%201h-2c-2-15-2-15%202-20l10-6v-12l1-9V75h10l1%202v-5h4l3-1z'/%3e%3cpath%20fill='%23558ace'%20d='m209%20497%204%201%201%2029%201-2h2v-3h2l1-2q2-4%206-7h2l-4%2014-1%204-1%203h-2v2l2-1%203-2%203-2%208-2q-1%205-5%208l-1%202-2%201h13l-3%206q-10%207-22%206h-4l-9-1-6-2-3-1q-5-1-8-5v-2l2-1-1-3h-2v-3q5%201%209%206v2l5%201-2-4-2-4-1-3c-4-7-4-7-3-11l3-1q5%201%208%206v-11q1-10%207-18'/%3e%3cpath%20fill='%23db5c37'%20d='m211%20228%205%202v37h-6l-1%2016-8%201q-9-8-13-17l-2-3q-6-8-4-17l3-7%203-1%202%204%201-5h2l3-1%202-5%204%202%202-2%205-2z'/%3e%3cpath%20fill='%23bf392b'%20d='M100%20464h5l4%2014%201%202%202%2013q1%207%206%2010l3%203-2%205h-6l-2-3-2-3h-7l-4-1-1-5%203-10q-6%207-7%2017h-3v-10l-4%201-2%205-1%203-1%202h-1v-23h2l1%202%204%201-1-2-1-9v-5h5l3-1%204-2h3z'/%3e%3cpath%20fill='%23f9f1f5'%20d='M264%20167v8q-18%206-38%205c-20-1-37-1-53%2013l-5%205-9%207-2%202q0-4%203-6l5-3%203-4q5-8%2014-11l2-1q6-3%2013-4v-6l-2-1%204-2v2h24q15%202%2030-3z'/%3e%3cpath%20fill='%23db5c37'%20d='M320%20546v30h-40v-4l4-3%202-1%203-2%205-4%202-1%2013-9c8-6%208-6%2011-6'/%3e%3cpath%20fill='%237c2832'%20d='m160%20436%203%203v3l1%203%201%203%202%2010-3%201-1%206-3%208q-3%206-3%2014l-4%209h-3l2-7%202-9v-7l-6%206h-2l-1-2-3-4-1%202v-3l-3-6-2-1%201-3h4l2-4%203-4%209-12%203-3z'/%3e%3cpath%20fill='%23faa95b'%20d='m266%20128-1%2015c-9%203-9%203-15%201v-1h-3l-1%203q-7%203-15%201l-8-6%201-6v-3l1-3%2029-2h3z'/%3e%3cpath%20fill='%23db5c37'%20d='m118%20428%202%203%203%203v-3h4l-1%209%202-2v2h2l1%209-1%203v2h-3l-2-4%205%2014h3q5%200%208%204%201%205-2%209h-6q-3-1-5-4l-1-5-2%201h-3l-3-3-4-1-3-1v-12l2-8%201-5q4%201%206%205l-1-2c-4-6-4-6-4-9z'/%3e%3cpath%20fill='%23dce1f2'%20d='M213%2090v12l-1%202-5%2025h-2v-4h-2q-16-1-30-9l4-3%205-2q18-7%2031-21'/%3e%3cpath%20fill='%23b98c97'%20d='m228%20513-4%2014-1%204-1%203h-2v2l2-1%203-2%203-2%208-2q-1%205-5%208l-1%202-2%201h13l-3%206q-10%207-22%206h-10v-1h5l-3-1%201-5h2v2l4%201%202-9%201-2%201-13%201-6%202-2%202-2zm-31%2019h2q5%207%206%2015l1%204c-6%200-6%200-9-2l-3-1q-5-1-8-5v-2l2-1-1-3h-2v-3q5%201%209%206v2l5%201z'/%3e%3cpath%20fill='%23b35a69'%20d='m306%2087%2012%204q3%206%202%2011v27l-4%202-2%201-9-2z'/%3e%3cpath%20fill='%23944e6c'%20d='M306%20215h14v37h-10l-1-2-3-2-4-5%201-9%202-11v-3z'/%3e%3cpath%20fill='%23655177'%20d='m46%20453%202%201%202%201v6l-1%202%202%207h2l1-4%202%203%203-5%205%201v7l1%203q1%207-4%2012-2%202-8%203l-6-2q-6-9-5-21%201-3-2-5l-2-1v-5c5-4%205-4%208-3'/%3e%3cpath%20fill='%23558ace'%20d='m277%20304-4%2010%203%201v2h-2l-1%202-4%205-3%206-3-1v-2l-3-4-11-1-2-1v2h2l-2%204-1%202-4%203h-4q-2-2-2-5l-4-8v-4q6%200%2010%204h2v-10h6l2%209%206-9%204-3%202%207%201-1c9-8%209-8%2012-8'/%3e%3cpath%20fill='%23b98c97'%20d='M98%20489h2l-3%2013%203%201v2h2l7-1%205%206q-5%206-12%208l-5%205%203-1h9q-2%205-7%207-6%202-12%201l-1-9-3-6%203-12%203%203v-2c2-11%202-11%206-15'/%3e%3cpath%20fill='%23655177'%20d='m132%20477%205%202v7l-1%204%202%201%201%2011v2l-2%206h-2l-8%201h-8l1-2v-3l-4-3v-4l4-1-1-3q-2-4-2-9%206%201%2011%206v-3l1-3v-3z'/%3e%3cpath%20fill='%23b98c97'%20d='M65%20490q4%202%204%206v3l2-2-2%2011v8-5l4%202%201%205%204%202-1-2%201-9h2v3l4%2016h-4l-7%201q-6%202-12%201-5-2-8-7l14%201v-2l-2%201q-3%200-7-3l-3-2-3-4%2011%201-2-2-2-2%201-4v-11h4v-2z'/%3e%3cpath%20fill='%23655177'%20d='m178%20460%202%201-2%208-2%208-1%205-1%2013%202-3q2-3%205-4h2l-3%2015h6v-13l1-3v-3l2-4v25c-11%205-11%205-19%202q-3-2-4-5l1-4v-3c0-11%201-25%209-33z'/%3e%3cpath%20fill='%23db5c37'%20d='M80%20363q14%200%2025%209l-5%204-3%203q-9%207-22%205l-9-3%202-1%201-3h2l2-4%203-4h3z'/%3e%3cpath%20fill='%23b35a69'%20d='M0%20474q8%204%2012%2012l2-1%204%202q3%203%202%208l-4%201%202%203v11l-4-1%201-5-3%201-3%201-4%201-5%201z'/%3e%3cpath%20fill='%23558ace'%20d='M29%20550c1%208%201%208-2%2012l-3%202-4%204c-10%209-10%209-18%208H0c-1-11-1-11%201-15l6-4%203-2c14-7%2014-7%2019-5'/%3e%3cpath%20fill='%23922529'%20d='m184%20388%2012%2013v9l-2%206-2%204-2%203-1%204-4%209-3-6v-3l-1-2v-3q-3-13%201-27l1-2z'/%3e%3cpath%20fill='%23922529'%20d='m213%20365%202%201-1%202-15%2035h-2l-5-7-2-2-2-3-1-6%205-5%202-1%2013-10%201-1z'/%3e%3cpath%20fill='%23fbdeb4'%20d='M253%20143v1q5%202%209-1h3v14q-10%205-21%205l-3-2-1-7-6-5%203-1h3l3-1%203-1%201-2z'/%3e%3cpath%20fill='%23dce1f2'%20d='m21%2016-1%202c-2%206-2%206-1%2010l3%204h-2l1%203q-7%204-14%202l-6-3q-3-8-1-18z'/%3e%3cpath%20fill='%237c2832'%20d='m128%20467%201%204%203%206h2-2q-3%207-3%2016l-7-5-5-2%204%2013h-5l-1%203q-6-7-4-17%200-5%205-9l4-4q2-5%208-5'/%3e%3cpath%20fill='%23b98c97'%20d='m247%20163%202%207q-8%203-17%202h-2l-31-1v-7h5l1%202%201-2h14c8%200%2020-3%2027-1'/%3e%3cpath%20fill='%23922529'%20d='M177%20412h2l2%2010v6l1%2010c-12%202-12%202-17%201l-2-4q1-7%206-11l3-4%202-2%202-4z'/%3e%3cpath%20fill='%23b98c97'%20d='M38%20534q5%201%207%207v3l4%201%202-6h2q4%206%203%2012h2l2-6%205%201q-3%208-10%2012-6%202-12-1l-7-9v-2l7%203-1-3-1-3-2-3z'/%3e%3cpath%20fill='%23922529'%20d='M263%20427q4%202%204%206l1%203%203%206%203%2011-2%201-3%201-3%201-6%204q-2-3-2-8v-4h-1q1-11%206-21'/%3e%3cpath%20fill='%23944e6c'%20d='m194%20274%204%206%202%201%202%207v2l-1%204-13-4-2-1-5-2v9h-1v-10l2-1-1-2%201-5%204-1v-2c5-2%205-2%208-1'/%3e%3cpath%20fill='%237c2832'%20d='m256%20446%203%201v8l1%204%201%209v3h-8l-7%202-6-20%204%203%201%203%201%203%201%202%201-2%201-3%201-3q1-3%205-4z'/%3e%3cpath%20fill='%23dce1f2'%20d='m164%20101%202%202-4%203%201%202-5%201v7l3%201h-10l-11-1v-3l7-1-11-2%202-5%205-1h2l3-1h6l3-1%205-1z'/%3e%3cpath%20fill='%23fbdeb4'%20d='M239%20486q3-1%206%203l2%202-1%202-1%2011h2l2-10h3l1%208-3%204h-2l-1%205h-2l-2-5-1%201h-9l1-7h2l-1-7h4l-1-2z'/%3e%3cpath%20fill='%23faa95b'%20d='m273%20108%203%201v3l1%205-2%202-3%202-3%202-4%203h-19l1-8%207-1h2l13-1%203-1z'/%3e%3cpath%20fill='%23655177'%20d='m52%20514%207%201v2h2q12%200%2021%209v1c-17%205-17%205-24%201l-5-5%2014%201v-2l-2%201q-3%200-7-3l-3-2zm56-10q4%202%206%206-5%206-12%208l-5%205%203-1h9q-2%205-7%207l-9%201q-2-5%201-10%201-5%206-9l3-3q2-3%205-4'/%3e%3cpath%20fill='%23f39268'%20d='M128%20160q-7%209-15%2014l-14%209-5%202%209-13%207-8q7-9%2018-4'/%3e%3cpath%20fill='%23bf392b'%20d='m197%20404%202%203-3%207-1%204-3%206c-8%2017-8%2017-6%2024l5%205%203%203%2021%2018-2%202-2-2-20-17-3-3%201%2013h-2l-5-28-2-21q3%204%203%2010l1%203v3l4-8%202-4%201-3%201-3z'/%3e%3cpath%20fill='%23944e6c'%20d='m163%20457%201%202%202-1%206%202v2l-2%206v2l-1%203-1%204v3l-3%2011q-2-5-2-11l-6%203%203-12q3-7%203-14'/%3e%3cpath%20fill='%23b98c97'%20d='m142%20473%204%202v4h2l-1%204q-5%2013-7%2028l2%201-9-1%202-1%201-3%201%202q2-8%200-17-2-7-1-14l4-2%201-2z'/%3e%3cpath%20fill='%23655177'%20d='m247%20321%2013%201q4%204%205%209-2%202-5%201l-14%203-6%201-2-4h3l4-1%202-5%202-3h-2zm-2%20215h2l1%207h5l-2%205h6v4q-7%206-18%205v-8l1-3%201-2h2v-3zm-25%201h2v3l4-1%201%202%203-1h11l-3%206q-10%206-21%205l1-6v-4z'/%3e%3cpath%20fill='%23db5c37'%20d='M210%20481q10%2011%2010%2024h-7l-1-7-6%201c-2-9-2-9%200-13z'/%3e%3cpath%20fill='%23944e6c'%20d='m74%20416%204%203q4%208%201%2016l1%205q3%207%202%2014-7-4-7-7v-2h-2l-2-11%206%201-1-3v-3l-1-4z'/%3e%3cpath%20fill='%23b98c97'%20d='m270%20513%205%202%201%203%202-2%205-1%202%201q0%208-6%2012l-8%201-3-4q-2-6%202-12'/%3e%3cpath%20fill='%23558ace'%20d='M0%2016h7l2%204%201%203%202%204v2l2%201h-3l-2%204-3%202-6-4z'/%3e%3cpath%20fill='%23655177'%20d='m32%20478%205%201v10q1%203-2%205l-8%201-3-6-2-3-1-7q4%200%206%203l4%207z'/%3e%3cpath%20fill='%23944e6c'%20d='m178%20460%202%201-2%208-2%208-1%205-2%2014h-1v-10l-4%201q0-15%208-25z'/%3e%3cpath%20fill='%23db5c37'%20d='M153%20379q7%203%207%206v2l3%201%203%204%201%203%201%202-1%202-3-3v-3h-2v2h-2v-4l-6%202v2h-3q-2-3-2-7z'/%3e%3cpath%20fill='%23b35a69'%20d='M265%20159v9l-19%201%201-8%206-2%204-1z'/%3e%3cpath%20fill='%23dce1f2'%20d='M157%20570h14q6%200%2011%202l4%204h-32z'/%3e%3cpath%20fill='%23bf392b'%20d='M320%20357v8l-5%203q-15%208-25%2021l-11%2011-2%202-1%202-2%201-3-1%205-5h2v-2h2v-2h2l1-3%203-3%2012-11%202-2%205-5%208-8%202-2z'/%3e%3cpath%20fill='%23f39268'%20d='M36%20232h3v32l-1%206-3%202v-39z'/%3e%3cpath%20fill='%23faa95b'%20d='M139%20466q3%202%202%205l-2%206h-6q-3-1-5-4l2-8q5-2%209%201'/%3e%3cpath%20fill='%23fba92f'%20d='M4%20528h5v6l2%201v6l-2%201-3-1-1%204-3-1v-2H0v-13l4%201z'/%3e%3cpath%20fill='%23fbdeb4'%20d='M264%20167v8l-12%203-3-3v-6z'/%3e%3cpath%20fill='%23655177'%20d='M3%20449q4%200%206%203l2%205h2v-2l1-3%203-1%203%206-2%201-2%204-1%202-4%201-3-4-1-3c-4-5-4-5-4-9'/%3e%3cpath%20fill='%23922529'%20d='m23%20373%202%201v5l1%203v46l-2%204z'/%3e%3cpath%20fill='%23655177'%20d='m240%20453%204%203%203%208%204-10h2l-1%207v3l-1%202v3l-3%203-2%201z'/%3e%3cpath%20fill='%23faa95b'%20d='m46%20453%202%201%202%201%201%202q-1%206-3%207c-8-1-8-1-10-3v-5c5-4%205-4%208-3'/%3e%3cpath%20fill='%23f39268'%20d='m29%20283%204%205-1%2023-2%201-2-1v-13zm4-46v23l-1%207h-3v-23l1-6z'/%3e%3cpath%20fill='%23655177'%20d='M51%20539h2q4%206%203%2012h2l2-6%205%201-5%208-2%202-6%201-1-12z'/%3e%3cpath%20fill='%237c2832'%20d='m264%20474%203%201%2016%202v2l-3%201-8%207c-8-9-8-9-8-13'/%3e%3cpath%20fill='%23faa95b'%20d='m267%2065%202%201%201%207v7h-8l-1-11%204-2z'/%3e%3cpath%20fill='%23655177'%20d='m185%20534%207%204%201%202%203%204%207%205v2c-13-3-13-3-17-8v-2l2-1-1-3h-2z'/%3e%3cpath%20fill='%23b98c97'%20d='M178%20509v4q-8%200-16-4l-8-2%203-3q11%200%2021%205m19%2023h2q5%207%206%2015l1%204h-3v-2h-2q-4-2-6-5l1-2%203%201zm12%2013h2v2l2%201-1%204h-6v-1h5l-3-1z'/%3e%3cpath%20fill='%23558ace'%20d='M236%20540h5l-3%206q-4%203-9%202l-2-7z'/%3e%3cpath%20fill='%23faa95b'%20d='m271%2067%207%203v12l-6-1z'/%3e%3cpath%20fill='%23f39268'%20d='m246%20299%206%201%201%205h-2v4h-7q-2-3-2-8h4z'/%3e%3cpath%20fill='%23558ace'%20d='M236%20529q-2%207-8%2011h-6l1-5%205-3%203-2zm-76-201h2l1%206h2l-1-3%203%201-1%204q-5%203-10%202v-7q-1-4%204-3'/%3e%3cpath%20fill='%23655177'%20d='m0%20474%207%204-3%209-2%202-1%202H0z'/%3e%3cpath%20fill='%23faa95b'%20d='M215%20507h4l-1%2011-1-3h-2v7l4-2v2h-2v3h-2l-1%203h-1v-18h2zm29-388v7h-14l3-4%202-1%203-1z'/%3e%3cpath%20fill='%23fbdeb4'%20d='M320%20306v4l-5%204-4%205-6%204-3-1%202-1%2011-12q1-3%205-3'/%3e%3cpath%20fill='%23b35a69'%20d='m109%20505%205%205-8%206-2%201-2%201-2-1%201-4h2l1-3z'/%3e%3cpath%20fill='%23db5c37'%20d='M185%20450q7%202%2010%207l10%209%2010%208-2%202-2-2-24-21-2-1zm-21-72%207%203-1%209q-5-2-8-7z'/%3e%3c/svg%3e",
	city: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='576'%3e%3cpath%20fill='%237f544a'%20d='M0%200h320v576H0z'/%3e%3cpath%20fill='%23fee5c3'%20d='M0%200h320c0%20155%200%20155-7%20164l-2%202v4l-1%202v12h-22v-5l-2%201-1%204h-5v-5l-2%201-1%203h-15l-9-2v2h-16v3h3v2l1%208v3l1%206%201%203v9h-3v3h3v5h-25l-1-8h4v-2h-4v-20h-3l-4-4v-2h-7v2q-6%204-13%203l-4-2v2h-2v-2h-2v2h-2l-2-1h-5l-1%201-5%201h-4l1%201v21h3l1%205q-6%203-12%202h-8v-25h-2l-1%202-2-2q-2-4-7-4v2h-3l-4%201-1%202h-8v-3l-5%202v-8h2v-2h-2v-4l2%201-1%202h2l-4-8v-4h-2v4H94l-31-1-1-16H45l-45-2z'/%3e%3cpath%20fill='%237f544a'%20d='M180%20277h15l1%2017%203%201-2%206%204-1%209%201-1%202-1%202%202%203-1%204q3%202%208%201h2l7%201h18l23%201%2039%201v2h-3l-4%203-2%205h4l2-1h2l1-2%203%201v3l-12%201%203%206%201%203%206%208h-2l1%202%202%203%201%203v5h-3l-2-8h-2l-1-3q-4-8-11-14l-3-3-5-4v2l1%20101h3v-2q3-9%2011-16l2-2c6-5%206-5%208-5v-2l3-3%208-9%201-2h1v188H0V381h7l6-2c3%205%203%205%203%208h-2v2q2%207-2%2015l-1%205%207%203%202%201%2011%205%201-3%201-4v-2l2-5%202-1-4%2018q10%204%2022%206l-7-24h2l4%2010%201%203v3l1%203%201%204%204-1%2011-1%201-2%205-1h4v-2l4-5v5l6-1%204-1%208-3-1-2-1-5-2-7-1-8h-2v-6l1%202q0%202%205%203h3l5-26%201-5%206-34v-3l1-2v-2l2-1-4%2029%207-9%201%203-3%205q-6%205-7%2013l-1%204v4l-2%208v4l-3%2013h3l3%201h4l9%202%202%2028a40%2040%200%200%200%205-20v-6h2l1%208%203-8h2l-5%2015c-9%2015-9%2029-9%2046l25%209%201-2%206-8%201-2%205-5q-3%207-8%2012l-3%205%202%204%201%202%201%202%202%205h2l1-2q2-4%207-8l1-1%204-4-1%205-6%205-2%201q-4%205-5%2012v17c0%2012%200%2012%203%2015l5%204%203%204v3l6%2011c4%207%204%207%203%2011l8-1%203%201v-2l2-15%201-22v-5l-1-59v-51h-2v5l-4%201-2-3-2%202-6%201v-2h3v-2l2-1q3-2%204-5v-10l-3%202-4%202-2%201-9%202%203-4%203-2%203-1%205-2h2l1-2-2-1-6-4-2-2-2-2-4-4-1-2-4-2v-3l5-3%2011-8q-5-5-13-5l-3%201v-2l2-1%201-4%202%201q3%200%207-3h2l-4-6-5-7-1-2q-5-4-11-3h-18l-15-1v-4h-3v-2h3v-11h-2v-2h2l1-3h3l1%203h15l1-4h3v5h19l1-4h2v4h4v-6h1l1%205z'/%3e%3cpath%20fill='%23f9cdac'%20d='M0%2012c30%200%2056%205%2078%2027q16%2014%2037%2012l10-2%205-1v2l1%203%202%201%2011%209%2010%209q10%207%2016%2016l11%207c10%205%2013%2011%2017%2022l3%206%201%203q2%206%206%2011l6%2018q3%2010%209%2020%203%206%202%2013v6h6l1%203h-4v28h-10l-1-8h4v-2h-4v-20h-3l-4-4v-2h-7v2q-6%204-13%203l-4-2v2h-2v-2h-2v2h-2l-2-1h-5l-1%201-5%201h-4l1%201v21h3l1%205q-6%203-12%202h-8v-25h-2l-1%202-2-2q-2-4-7-4v2h-3l-4%201-1%202h-8v-3l-5%202v-8h2v-2h-2v-4l2%201-1%202h2l-4-8v-4h-2v4H94l-31-1-1-16H45l-45-2z'/%3e%3cpath%20fill='%23aa373e'%20d='M0%20161h36l8%201h7l11%201%201%2016h3l35%201h11v-4h2l4%2012h-2l-1-3v4h2v2h-2v8l5-2v3h8l1-3h7v-2h5l4%205%203-1v25h8l12-2-1-5h-3v-13l-1-3v-3l-2-4h5l3-1%206-1%207%202v-2h2v2h2v-2l2%201q8%201%2015-2v-2c6%200%206%200%209%202l2%204h3v20h4v2h-4l1%208h25v-5h-3v-3h3l-1-7-1-3-1-21h-3v-3l10-1%206%201v-2h2l7%201h2l3%201h10v-3h2l1%2021%206%201v-5c5%208%203%2019%203%2028h12v2h2q1%208-2%2015h-2v24h4v2h-3v3h-30l-71-1h-23l-12-1h-4l-16-2h3v-2h-4v-4q0-4-4-7l-6-4q-11-7-24-6v2h-3v-9l-2-18H89l-19-1%201%203v14l4%202%202%203-6-3v8h-4v-27h-3v32l-4-1-7-1h-6v-2l-3%201-4-2-1%202h-2v-2h-3v2l-8%201%201-4h-3q-6%201-11-2l4-1v-3l-6%203v2H8l-1%203H4l-4%201z'/%3e%3cpath%20fill='%23bc835c'%20d='M120%20318h1l-4%2029%207-9%201%203-3%205q-6%205-7%2013l-1%204v4l-2%208v4l-3%2013h3l3%201h4l7%203%201%204v57h-2l-3%201h-2l-12%205-2%201-5%202-2-2%201%202q-1%206-4%2011l-1%202-6%2011q-4%207-4%2014l-5%208q-5-1-8-6l-2-2-2-1q3%204%208%207%204%202%204%207v27q0%207%203%2014h14v-2l-3-1-1-3-5-1v-2l-2-1q6-1%2010%203l2%206%2033-1h2q5%200%209%202l1%202%201-2q0-2%205-3h3l3%206%201%204-2%202%202%206h-2v2l2%201H0V381h7l6-2c3%205%203%205%203%208h-2v2q2%207-2%2015l-1%205%207%203%202%201%2011%205%201-3%201-4%202-7%202-1-4%2018q10%204%2022%206l-7-24h2l4%2010%201%203v3l1%203%201%204%204-1%2011-1%201-2%205-1h4v-2l4-5v5l6-1%204-1%208-3-1-2-1-5-2-7-1-8h-2v-6l1%202q0%202%205%203h3l5-28%201-3%206-34v-3l1-2z'/%3e%3cpath%20fill='%23d9a079'%20d='M198%20320h46l11%201h11l9%201v14l1%2037v-52l3%201%201%2015%201%2018v30l1%2054v3q1%2010-5%2017-4%204-9%202-9%204-16%2011l-8%207q-10%207-18%2015l-2%202-1%204%203%2011h2q6%2028%206%2057h-3v-2c-6-48-6-48-11-64l-5%202-2%209%202%2011v2l1%204v13q-4-2-4-8l-1-3v-3l-1-7-1-3-1-5-1%202-2%202-1%202-2%202h-2v-45l-1-16v-3l-1-32zm31%20182h2l3%2014%202%204%201%2012v5l-3-1-2-9-1-2z'/%3e%3cpath%20fill='%23e4a06b'%20d='M17%20238v3l-2%201%2012%202-1%204%208-1v-2h3v2h2v-5l1%203%207%201v2h10l6%202%202%205v2l1%208h-7v8l2%201q6%201%208%206%200%2012-4%2023l-1%204-3%2010-3%2010-5%2021h-8q-4%200-7%203l-7%202-2%206-1%202q-4%2012-3%2025v15h51c-1-34-1-34-9-41v-8l-12-4%205-23%201-5%203-13v-2l6-22h2v5l2%208-1%202h2q3%204%202%207h2l10%201q4%205%205%209l-2-8%205%201%201%205%202-5%209%201h3l5%201%203%201-1%2016-1%203-1%206-1%208-7%2040-1%203v2l-1%202q-4%202-9-1l-1%202h2l1%204%201%204v3l4%2011-13%205h-4l-3%201v-5l-1%203-4%204h-7l-1%203h-3l-12%201-7-21%204%2016%201%206q-12-1-22-6v-2l1-3%201-3v-6l-3%2011-8-1-2-1-2-1-2-1-8-5%202-7q3-7%201-13l1-2h2l-3-7-3%201H0V247l4-1%201-2%202%201%201-2h3l-1-3zm69%20174%201%202Z'/%3e%3cpath%20fill='%23d9a079'%20d='M0%2012c30%200%2056%205%2078%2027l13%208%205%203q1%2017-1%2032l-1%208-2%2016h-2l-2-7-1%2018-3-11v-6l-1%202h-2l-1-1%202%2077%209%201v1l-28-1-1-16H45l-45-2z'/%3e%3cpath%20fill='%23bc835c'%20d='m123%20311%201%203h3v4h2l42%202q7%208%2010%2017c-6%204-6%204-9%204l-2-1-1%204h-2v2l2-1h7l8%204-14%2012h-3v3l4%202%203%203q6%207%2014%2012l-3%204-3%201-2%201-6%202-3%203%206-2%204-2%208-3v10q1%203-2%205l-4%201v2h-3v2l9-4%201%203h3l1-5h2l2%2060v59l-2%2022-2%2013c-7%202-7%202-11%200l-2-6-6-12-1-2-1-2-1-6-4-3q-5-2-6-8v-26q0-7%205-11h2l2-4%203-4%202-2%201-1-6%206-2%202-5%206h-2l-3-5-2-3-2-5%205-7%201-2-4%204-2%203-1%202-7-2h-3l-8-3-7-4-1-13v-4q1-17%2010-32l5-12h-2l-3%2010h-1v-10h-2v3q2%2014-5%2025h-1l-1-30-2%201-10-2-2-1-5-1%202-19%201-4%207-22%204-6-5%207-2-1v-2l2-9v-4l3-14q0-4%202-7'/%3e%3cpath%20fill='%234e333a'%20d='M319%20388h1v134l-4-9v-3l-1-3-8-24-1-7h-2l1%203v10l-1-2h-2l-2-10h-2l6%2024%208%2033v2l1%2015-4%203h-2l-5%201v-3q-4-31-13-63h-1l4%2018%207%2032c2%2017%202%2017%200%2024q-6%208-15%209l-29-1h-6l-11-1%203-2v-7l-1-3v-3l-1-9v-3q-3-21-9-41l-1-8h-2l1%202v9c-4-6-4-6-4-10q9-11%2023-20l8-6c10-9%2010-9%2018-8l4-3q6-12%205-26v-16h1v13h3v-2q3-9%2011-16l2-2c6-5%206-5%208-5v-2l3-3%208-9z'/%3e%3cpath%20fill='%23bc835c'%20d='M64%20218h3v27h4v-8l4%201-2-1q-4-4-3-11v-8l34%201%202%2013v14h3v-2a37%2037%200%200%201%2028%208q6%203%207%2011l-1%202h4l1%208%201%208v7l2%201q5%201%205%206l1%203%201%202h-7v-5l-3%201-1%204h-15l-1-4h-3l-1%204-2-1v2h2v11h-4l-2%206h-1l-1-7-19-2-2%206h-1v-7l-5-1%201%202%201%202v7l-2-5-2-3-1-4h-3l-9-1-2-7h-2l-2-10%201-5h-2v2l-5%2022-1%203-3%2012-1%207-5%2019h3l10%204v6l2%204c10%2010%206%2028%206%2039H25v-20a53%2053%200%200%201%204-25q6-7%2014-9l10%201v-3l4-17%202-6%205-22%202-7%201-3%201-3-2-11-5-2-2-1v-8h7l-1-2-2-28%201-5z'/%3e%3cpath%20fill='%234e333a'%20d='M180%20277h15l1%2017%203%201-2%206%204-1%209%201-1%202-1%202%202%203-1%204q3%202%208%201l9%201h18l23%201%2039%201v2h-3l-4%203-2%205h4l2-1h2l1-2%203%201v3l-12%201%203%206%201%203%206%208h-2l1%202%202%203%201%203v5h-3l-2-8h-2l-1-3q-4-8-11-14l-3-3-5-4v23l1%2011v47l-1%2017h-1v-4l-1-33v-34l-1-7v-11l-1-13-2-1v2l1%2022v47h-1l-2-46v-24h-30l-11-1h-3l-32-1v35l1%2016%201%2055v96h2l1-2q2-4%206-7l5%2025%201%204%201-1q0-12-3-22l-1-11%204-4%201-2%202-2q4%205%204%2011a345%20345%200%200%201%208%2057h3l-4-41v-8q4%208%204%2017h2l1-5h1l4%2037q-11%205-24%203l-6-6-9-6-4-2-9-3%201-2%203%201v-2l2-15%201-22v-5l-1-59v-51h-2v5l-4%201-2-3-2%202-6%201v-2h3v-2l2-1q3-2%204-5v-10l-3%202-4%202-2%201-9%202%203-4%203-2%203-1%205-2h2l1-2-2-1-6-4-2-2-2-2-4-4-1-2-4-2v-3l5-3%2011-8q-5-5-13-5l-3%201v-2l2-1%201-4%202%201q3%200%207-3h2l-4-6-5-7-1-2q-5-4-11-3h-18l-15-1v-4h-3v-2h3v-11h-2v-2h2l1-3h3l1%203h15l1-4h3v5h19l1-4h2v4h4v-6h1l1%205zm47%20217h2l2%2016v4q1%203-2%205l-1-3-1-4-2-1-2-5-1-2%201-8h2l2%206z'/%3e%3cpath%20fill='%23eab086'%20d='M267%200h53v152q1%203-2%205v-2l-4-2-8-5-14-4-3-4-3-13v-4l-1-4-1-16q-2-9-5-14c-7-14-7-30-8-45l-1-9-1-6v-3z'/%3e%3cpath%20fill='%23fef3e3'%20d='M0%200h267q-4%207-12%2010-21%2010-42%201h-2q-21-7-41%204-14%207-23%2020-13%2014-33%2018a49%2049%200%200%201-38-16%2095%2095%200%200%200-41-21l-3-1q-16-4-32-3z'/%3e%3cpath%20fill='%2348343b'%20d='m0%20418%205%208%201%203%202%203%202%205%205%2010q6%2017%2020%2028l4%204-8-5-2-2-1-1%2018%2038%202%204%201%202%206%2010q9%2020%2013%2041l3%2010H0z'/%3e%3cpath%20fill='%236c3235'%20d='M277%20180h2l1%2021%206%201v-5c5%208%203%2019%203%2028h12v2h2q1%208-2%2015h-2v24h4v2h-3v3h-30l-71-1h-23l-12-1h-4l-16-2h3v-2h-4l1-3h10l-1-8-6-1v7l-4-9h7v-10q-1-5%202-9%205-3%209-2t7%204l1%2010v6h6v-9q-1-5%202-9%204-4%207-3h2q4%201%207%206v15h5v-10q0-6%204-9l8-1q5%202%206%206v16h9l5-1h2l4-1v2h22v-11h-5v-3h33v-17l-6-1%201%204q1%204-2%208-3-22-2-45h-31l1%2030h13l2%201%208%202h-15v5h-2l-1-4-6-1v5h-3v-5h-3v-3h3l-1-7-1-3-1-21h-3v-3l10-1%204%201h2v-2h2l7%201h2l3%201h10z'/%3e%3cpath%20fill='%2348343b'%20d='M126%20395h2l2%2028q5-9%205-18v-8h2l1%208%203-8h2l-5%2015c-9%2015-9%2029-9%2046l3%201%208%204%201%205%202%202q2%204%200%209l1%205-2%201v19h2q3%209%201%2018l-1%201v12q0%205-3%2010-2%202-5%202v-2l-3-4-6-2v2h-3l2%203-1%203-5%201v-2l-3%201-3-2%201-1-2-1-2%205-1-3-4%201-1-2-10%202v3h-7v2h5l2%204%202%201v2l-15%201q-4-15-3-31v-15l-4-2-5-4-2-2-2-2q7%201%2010%206l2%202q3%200%205-4l1-8%205-11%208-13%202-9-1-2v-3l4%204%203-2%205-2%202-1%203-1%202-1%2010-1z'/%3e%3cpath%20fill='%23e6a67a'%20d='m123%20311%201%203h3v4h2l42%202q7%208%2010%2017c-6%204-6%204-9%204l-2-1-1%204h-2v2l2-1h7l8%204-14%2012h-3v3l4%202%203%203q6%207%2014%2012l-3%204-3%201-2%201-6%202-3%203%206-2%204-2%208-3c1%2012%201%2012-1%2015l-7%202-1-4h-14l-2-6v6l-4%202h-2q-8%201-17-3l-3%2010h-1v-10h-2v3q2%2014-5%2025h-1l-1-30-2%201-10-2-2-1-5-1%202-19%201-4%207-22%204-6-5%207-2-1v-2l2-9v-4l3-14q0-4%202-7'/%3e%3cpath%20fill='%23c05844'%20d='M148%20269h37l75%201%2012%201h16l12%201v29q-6-1-7-3l-8%202h-4l-1%201%2024%201v3h-32v10h-50l-6-1h-3q-3%201-5-2l1-2-2-6%203-3h-13l2-6h-2l-1%203-1-8v-13h-15v22l-7%201v-4l-2%201-1%203h-12l-4-8-3-3-2-1-1-13z'/%3e%3cpath%20fill='%23fee5c3'%20d='m276%20321%203%201%201%2015v3l1%208v52l-3%201v2c-5%205-5%205-8%205l-1-8v11l-4%202-2%204-4%204-6%205q-4%203-9%202h-21l1-6-3%201-2-1v6h-8q-2-3-1-6v-4l-1-3v-41l1-3h40l18%201v17h2v-17h5l1%201z'/%3e%3cpath%20fill='%233a2426'%20d='M49%20169v3h-2v25l1%204v21l1%2026h-2v-2l-3%201-4-2-1%202h-2v-2h-3v2l-8%201%201-4h-3q-6%201-11-2l4-1v-3l-6%203v2H8l-1%203H4l-4%201v-78z'/%3e%3cpath%20fill='%23aa373e'%20d='M0%20161h36l8%201h7l11%201%201%2016h3l35%201h11v-4h2l4%2012h-2l-1-3v4h2v2h-2l-1%2020H68l21%201h6l10%201v3q-5%202-11%201H64v33l-16-3v-25l-1-3v-20l-1-6%201-21h2v-3H0z'/%3e%3cpath%20fill='%23e6a67a'%20d='M64%20218h3v27h4v-8l4%201-2-1q-4-4-3-11v-8l34%201%202%2013v14h3v-2l17%201%202%2013%201%204%201%207%201%204v8q-11-3-20-9l-2-5v4l-32-4%203-16%201-8v3l-3%2010-1%203v3l-1%202-3%203-4-1q-7-15-5-32z'/%3e%3cpath%20fill='%237f544a'%20d='M166%20450q-1%207-7%2012l-3%205%202%204%201%202%201%202%202%205h2l1-2q2-4%207-8l1-1%204-4-1%205-6%205-2%201q-4%205-5%2012v17c0%2012%200%2012%203%2015l5%204%203%204v3l5%2010%203%206-1%203-2-3-11-22-4-4-1%2033-7%202-2%204-2-4-7%201-2%204-1-3-8-1h-10l-17%201h-3l-6-1-3-6-3-2%202-1%201-3%205-1%203-1h2l1%203%204-1%201%202%202-4%203%201-1%201%205%201v2l4-3-2-6%205%202v-2l3-1q5%202%206%207v2q4-1%206-5v-11l1-2%201-7v-18h-2q-2-5-1-11v-9l2-1-1-3%201-6q0-4-4-8l1-3%205%201h2l7%203%201-2%206-8%201-2z'/%3e%3cpath%20fill='%2348343b'%20d='m62%20349%204%201%202%202v6l2%204c10%2010%206%2028%206%2039H25v-20q-1-12%203-22l1-3c7-11%2022-10%2033-7'/%3e%3cpath%20fill='%23f9cdac'%20d='M194%20399h2l2%2088v31l-2%2022-2%2013h-11l-1-10v-9l-1-11v-24l-1-36v-49c0-7%200-7%203-10l5-3%202%203h3zm95-257q16%202%2029%2013%200%204-4%207c-5%205-4%2015-4%2022h-22v-5l-2%201-1%204h-5v-5l-2%201-1%203h-18l-6-2v2h-12l1-2-2-1q2-4%206-7l6-5%204-1%201-2q3-4%207-5l4-1%204-2v-2h2l1-2q2-4%206-6h2v-2l2-1z'/%3e%3cpath%20fill='%23d9a079'%20d='M281%20325q9%205%2014%2012l4%204q4%204%203%209h2q6%2010%204%2022l-3%207q-3%207%200%2015v11l-4%204-2%202-4%204q-7%205-8%2015l-4-1-1-38v-35l-1-6z'/%3e%3cpath%20fill='%237f544a'%20d='M180%20277h15l1%2017%203%201-2%206%204-1%209%201-1%202-1%202%202%203-1%204%201%202q-7%201-12-3l-1%203h-39l10%201%201%204-42-1v-4h-3v-2h3v-11h-2v-2h2l1-3h3l1%203h15l1-4h3v5h19l1-4h2v4h4v-6h1l1%205z'/%3e%3cpath%20fill='%236c3235'%20d='m297%20476%203%201q3%205%202%2010h3l-1-11h2l6%2019%202%206%201%202%203%2010q3%2010%202%2022v41h-34q2-7%209-12%204-3%204-7%200-11-2-21l-1-4-9-43h3q9%2033%2013%2066l9-4-2-20-1-3-11-45z'/%3e%3cpath%20fill='%23f9cdac'%20d='M215%20446h11l11%201h4l6%202v-2h20l3%201v13l-2%201q-7%202-12%207l-3%202-9%208-3%202-2%202-4%201q-4-1-6-6l-9-9-1-2-4-3q-4-3-4-8v-9z'/%3e%3cpath%20fill='%23fcdabb'%20d='M262%20322h5v10q-4%203-8%203v2l3-1%205-2%201%208v26h-22l-32-1%202-4%205-5q6-6%2015-10l-3-1%208-8%202-2%202-2%202-2%206-3%204-3q3-4%205-3z'/%3e%3cpath%20fill='%236c3235'%20d='M320%20442v80l-4-9v-3l-1-3-8-24-1-7h-2l1%203v10l-1-2h-2l-2-10-4%201-2-6-2-4-1-5h-3l-3-4-2%201q1-8%207-14l6-1%208-1h3q6-2%2013-2'/%3e%3cpath%20fill='%23c05844'%20d='m63%20184%2051%201%201%204h2v2h-2l-1%2020H73l-3-1-7-1z'/%3e%3cpath%20fill='%234e333a'%20d='M203%20189c6%200%206%200%209%202l2%204h3v20h4v2h-3l-41-2h-13v-12l-1-3v-2l-2-4h5l3-1%206-1%207%202v-2h2v2h2v-2l2%201q8%201%2015-2z'/%3e%3cpath%20fill='%23c05844'%20d='M246%20187h31l1%2039h-23v-6l12-1h-10l-6-1h-2l-3-1z'/%3e%3cpath%20fill='%234e333a'%20d='M136%20195h5l4%205%203-1v25h-9v-9h-16l-1%208h-8v-4l-5%201-1%2026h-2v-9l-2-18H89l-19-1%201%203v14l4%202%202%203-6-3v8h-4v-27l-4-1v-1h42v-3H84l-8-1h-2q-5%201-9-2l49%201v-12l6-2v3h8l1-3h7z'/%3e%3cpath%20fill='%233a2426'%20d='M161%20230q4%201%207%204l1%207v13h-12l-1%208h6l1%203%208%201h33l13-1%202%201%2010%201%208-1h38v-7h1l1%207%2017%201v-6h2v5h7v2h-3v3h-30l-71-1h-23l-12-1h-13l-7-2h3v-2h-4l1-3h10l-1-8-6-1v7l-4-9h7v-10q-1-5%202-9%205-3%209-2'/%3e%3cpath%20fill='%23c05844'%20d='M278%20179h2v2l1%202%204%201%201-5h2v5h20l3%201v18l-1%205v12l-21%201-1%203v-3l-1-21-1%202h-6l-1-4z'/%3e%3cpath%20fill='%23f4bd97'%20d='M17%20238v3l-2%201%2012%202-1%204%208-1v-2h3v2h2v-5l1%203%207%201v2h10l6%202%202%205v2l1%208q-16%200-33-4l-8-1-8-1-7-2H8l-8-2v-8h2l2-1%201-2%202%201%201-2h3l-1-3z'/%3e%3cpath%20fill='%23e4a06b'%20d='M198%20320h33l9%203-2%202-5%206-1%203h-3l2%201-1%203h-2q-4%201-6%205h-2l1%203-3%201-9%203v2l-4%204-6%202-1-14z'/%3e%3cpath%20fill='%23f9cdac'%20d='m276%20321%203%201%201%2015v3l1%208v52l-3%201v2c-5%205-5%205-8%205l-1-8v11l-4%202-2%204-3%201-2-1-1-11v-9l2-6h3v-3q0-7%205-12h1v13h2v-17h5l1%201z'/%3e%3cpath%20fill='%23d9a079'%20d='M194%20399h2l1%2063-9-7-7-6-1-7v-28c0-7%200-7%203-10l5-3%202%203h3zM70%20218l34%201%202%2013v14l-1-2H93l-1-2%201-2-1%202-2%201-6-1-3-1-2-1-1%202-4-5-3-2-1-9z'/%3e%3cpath%20fill='%234e333a'%20d='m0%20529%209%201%202%209%203%207v2l8%2017%204%2011H0z'/%3e%3cpath%20fill='%23c05844'%20d='M148%20269h28v31h-3v-4l-2%201-1%203h-12l-4-8-3-3-2-1z'/%3e%3cpath%20fill='%233a2426'%20d='m228%20273%2027%201v27h-6l-1-1h-8l-4%201h-8z'/%3e%3cpath%20fill='%236c3235'%20d='M277%20180h2l1%2021%206%201v-5c5%207%203%2018%203%2027l-1%203v9h-1l-1-15-6-1%201%204q1%204-2%208-3-22-2-45h-31l1%2030h13l2%201%208%202h-15v5h-2l-1-4-6-1v5h-3v-5h-3v-3h3l-1-7-1-3-1-21h-3v-3l10-1%204%201h2v-2h2l7%201h2l3%201h10z'/%3e%3cpath%20fill='%237f544a'%20d='M53%20347c11%202%2011%202%2015%205v6l2%204c8%208%206%2021%206%2031v8H61v-4l-1-14v-15l-1-3-1-12-5-3z'/%3e%3cpath%20fill='%23bc835c'%20d='M163%20520c7%205%207%205%209%209l1%203%202%203%201%203%205%2011%202-1v5h5l-1%201-4%207-3-1v2h-13l-1%203-1-2h-3l-6-1-1-4%201-2-2-1%209-1z'/%3e%3cpath%20fill='%237f544a'%20d='m297%20476%203%201q3%205%202%2010h3l-1-11h2l6%2019c9%2025%209%2025%208%2037v8h-1l-3-10v3l1%203%201%204v9l-4%201-4-18-10-41-1-2-1-6z'/%3e%3cpath%20fill='%23f4bd97'%20d='M236%20321h21v2l-3%203-11%2011-13%2011-7%207-13%2012h-1v-8l-1-3%201-6q5-4%2011-5v-2h2l1-2q1-3%205-4l1-1v-2h3v-2q2-5%207-9z'/%3e%3cpath%20fill='%23f9cdac'%20d='M212%20371h8v42l-1%2015h-8q-2-3-1-6v-4l-1-3v-41q-1-4%203-3'/%3e%3cpath%20fill='%234e333a'%20d='M42%20193v2l2-1h2q2%204%202%2010v17l1%2027h-2v-2l-3%201-4-2-1%202h-2l1-4-2-1%201-13h-3l-1-3%203-1-1-2%202-1v-27z'/%3e%3cpath%20fill='%23f4bd97'%20d='M296%20339q5%203%206%207v4h2q6%2010%204%2022l-3%207q-3%207%200%2015v11l-3%203-2%202-3%201v-34z'/%3e%3cpath%20fill='%23f9cdac'%20d='M199%20371h8l1%2049v2l-1%206h-7l-1-19z'/%3e%3cpath%20fill='%23e4a06b'%20d='M127%20247q6%202%2011%206l3%202q4%203%203%208l-1%202h4l1%207v15l-7-2-4-1-4-3-1-16v-11l-1%2012h-1l-1-8-1-2z'/%3e%3cpath%20fill='%233a2426'%20d='M184%20229h2q4%201%207%206v12l-1%208h-15l-2%203v-14c-1-8-1-8%202-12q4-4%207-3'/%3e%3cpath%20fill='%23c05844'%20d='M0%20161h32l4%201%2021%201-1%205h-2l1%204-2%201-2%202-1-5-33-1H0z'/%3e%3cpath%20fill='%233a2426'%20d='M210%20230q5%202%206%206l1%2011v6h-2v2h-18l-1-4h3v-3l-1-4v-2q0-5%202-9%204-4%2010-3'/%3e%3cpath%20fill='%237f544a'%20d='M199%20316h43l3%201%2030%201q3%2013%202%2028v46h-1l-2-46v-24h-22l-54-2z'/%3e%3cpath%20fill='%23bc835c'%20d='m221%20498%204%208v3l1%202h2q6%2028%206%2057h-3v-2c-6-48-6-48-11-62zm8%204h2l3%2014%202%204%201%2012v5l-3-1-2-9-1-2z'/%3e%3cpath%20fill='%237f544a'%20d='m158%20194%206%202v21h3l1%205q-6%203-12%202h-8v-21l10%201z'/%3e%3cpath%20fill='%23c05844'%20d='M112%20219h2v4h8l2%204h-2l1%202h2l1%205h2v2h-2l-1%203h-3v6l-13-1-1%202v-24q-1-4%204-3m-16%200h8q3%209%202%2018v9l-1-2H93l-1-2%201-2-1%202-2%201-6-1-3-1-2-1-1%202-1-3h15l-1-16%202-1z'/%3e%3cpath%20fill='%2348343b'%20d='M138%20421h19v16l-1%203h-9l-9-1z'/%3e%3cpath%20fill='%237f544a'%20d='M227%20494h2l2%2016v4q1%203-2%205l-1-3-1-4-2-1-2-5-1-2%201-8h2l2%206zm3%2025q4%208%204%2017h2l1-5h1l4%2037-10%201%202-1-4-41z'/%3e%3cpath%20fill='%23f9cdac'%20d='M194%20399h2v29h-6l-1-4v-3l-2%201-1%205h-5v-10l-1-3c0-7%200-7%203-10l5-3%202%203h3z'/%3e%3cpath%20fill='%23bc835c'%20d='M214%20194h17l1%203h-4v28h-10l-1-8h4v-2h-4v-20z'/%3e%3cpath%20fill='%23aa373e'%20d='M278%20179h2v2l1%202%204%201%201-5h2v5h20l3%201v18l-1%205v12l-21%201-1%203v-5h21v-31h-21v7h2v3h-2l-1%202-1%202h-6l-1-4z'/%3e%3cpath%20fill='%2348343b'%20d='M180%20277h15v23h-14z'/%3e%3cpath%20fill='%23aa373e'%20d='M176%20269h40v1l-19%201%201%201v21l-2%205-1-8v-13h-15v22l-4%201v-12l-1-4v-10z'/%3e%3cpath%20fill='%236c3235'%20d='M49%20169v3h-2l-1%203-9%201H24l-24-1v-6z'/%3e%3cpath%20fill='%23f9cdac'%20d='M228%20199q5%201%206%204v3h3l2-4%201%202%203%204v9h-3v3h3v5h-15z'/%3e%3cpath%20fill='%23aa373e'%20d='M263%20241h25v12h-25z'/%3e%3cpath%20fill='%23e4a06b'%20d='m68%20562%2030%201-1%202-2%204h-3q-6%201-7%203v4H71q-3-6-3-14'/%3e%3cpath%20fill='%23f9cdac'%20d='M200%20466q4%203%203%205v3l4%2024c3%2012%203%2012%201%2017l-2%202-2%203-2%202h-2z'/%3e%3cpath%20fill='%23e4a06b'%20d='m186%20351%203%201v26l-4-2-1-1-12-11q3-5%208-9l2-1z'/%3e%3cpath%20fill='%23bc835c'%20d='m297%20476%203%201%202%204v3l1%203%201%203%207%2021v3l1%203%201%202v2l-1%201v4l2%2012h2q3%206%202%2011l-4%201-4-18-10-41-1-2-1-6z'/%3e%3cpath%20fill='%23f9cdac'%20d='M211%20477h2q5%206%205%2013l4-3%205%204-6%209-8%208h-2z'/%3e%3cpath%20fill='%23fcdabb'%20d='m281%20325%208%205v15l-1%2010-1%207v5l-4%201-1-14v-2l-1-8z'/%3e%3cpath%20fill='%233a2426'%20d='M302%20468q7%202%209%209%2010%2021%209%2045l-3-9-1-3-1-3z'/%3e%3cpath%20fill='%23fcdabb'%20d='m274%20330%201%2025v13h-6l-1-27v-8z'/%3e%3cpath%20fill='%23aa373e'%20d='M112%20176h2l4%2012h-2l-1-2h-14l-8-1h-4l-6-2h-9l-6-1h-2l-6-2%209-1h2l25%201h16z'/%3e%3cpath%20fill='%23bc835c'%20d='m70%20218%2026%201q0%203-4%205v4H79l-6-1h-2z'/%3e%3cpath%20fill='%23f4bd97'%20d='M280%20405h1v25l-10-1c-2-13-2-13%200-17%205-4%205-4%208-4z'/%3e%3cpath%20fill='%23aa373e'%20d='M288%20225h13v2h2v7l-2%206-13-1z'/%3e%3cpath%20fill='%237f544a'%20d='M126%20395h2l2%2028a40%2040%200%200%200%205-20v-6h2l1%208%203-8h2l-7%2018q-7%2014-7%2029l-2%208z'/%3e%3cpath%20fill='%233a2426'%20d='M314%20219h2l1%2030v2l1%2069h-2l-2-62z'/%3e%3cpath%20fill='%23f9cdac'%20d='M149%20205h9v19h-10v-16z'/%3e%3cpath%20fill='%237f544a'%20d='m45%20426%202%201%202%207v3l6%2034%201%207%201%205%201%208q1%204%205%207l2%202%201%201q-4%201-6-3l-2-1-2-2-2-2-6-5-3-3-6-5q6%201%2010%206l2%201%204%204-4-25v-3l-3-13-1-9-1-3v-2l-1-3z'/%3e%3cpath%20fill='%23bc835c'%20d='m131%20351%202%204v17h-9v-20z'/%3e%3cpath%20fill='%23e4a06b'%20d='M171%20316h17v17l-5%202-1-2-2-3-2-3-4-5-1-4h-2z'/%3e%3cpath%20fill='%23d9a079'%20d='M192%20316h2l1%2047v32h-2z'/%3e%3cpath%20fill='%23bc835c'%20d='m42%20272-3%2010-2%202-2%205-22%2040-1%202-3%205-2%204-5%209-2-1%206-11%202-4%203-5%201-3%204-6%201-7-1-2v-3l-1-6-1-2-1-12h2l5%2025%205-10%2013-24z'/%3e%3cpath%20fill='%237f544a'%20d='m279%20323%203%202v9l1%204v69l-1%2017h-1z'/%3e%3cpath%20fill='%23fef3e3'%20d='m166%20569%204%201h7q6-2%2012%201l9%204v1h-35q1-6%203-7'/%3e%3cpath%20fill='%23bc835c'%20d='m288%20488%202%201%202%206v2l2%207%206%2028v2l1%2015h-2v-2l-12-58z'/%3e%3cpath%20fill='%236c3235'%20d='m0%20553%206%2010%202%203%201%202%204%208H0z'/%3e%3cpath%20fill='%23bc835c'%20d='m128%20396%207%201q3%2015-5%2028h-1z'/%3e%3cpath%20fill='%237f544a'%20d='m251%20478%204%208v2l1%203%201%203%202%209h2c6%2020%206%2020%205%2031l-2-1-3-11-6-24-3-13z'/%3e%3cpath%20fill='%23c05844'%20d='M74%20212h24l7%201v3l-8%201H75z'/%3e%3cpath%20fill='%23f4bd97'%20d='m288%20401%201%208v2l-1%2015-1%202v2l-4-1v-26z'/%3e%3cpath%20fill='%23fcdabb'%20d='m276%20321%203%201%201%2015v31h-2l-1-7v-9l-1-9z'/%3e%3cpath%20fill='%23e4a06b'%20d='M199%20316h40l6%201%2029%201v1h-29l-46-1z'/%3e%3cpath%20fill='%23f4bd97'%20d='M189%20385c1%2012%201%2012-1%2015l-7%202v-2l-1-2-3-1-1-6%205-3%203-2z'/%3e%3cpath%20fill='%236c3235'%20d='M134%20250h16v1h-7l3%206%201-4h6l1%203v6l-9%201q-3-3-4-7l-4-3-3-2z'/%3e%3cpath%20fill='%23f9cdac'%20d='M224%20200h1l1%2025h-8l-1-8h4l-1-3%201-7%201-3z'/%3e%3cpath%20fill='%23fee5c3'%20d='M223%20431h22l-5%207h-11l-6-1z'/%3e%3cpath%20fill='%233a2426'%20d='M320%20473v25l-4-8-1-3-1-3-1-3-2-9c3-1%203-1%209%201'/%3e%3cpath%20fill='%237f544a'%20d='m27%20233%204%202%204%202-1%208v2l-8%201v-6l-4-1v-4h3v-3z'/%3e%3cpath%20fill='%23aa373e'%20d='M314%20195h6v20h-6z'/%3e%3cpath%20fill='%233a2426'%20d='M264%20195h6v19h-6z'/%3e%3cpath%20fill='%237f544a'%20d='m236%20503%202%201%201%206%201%202%201%209c6%2032%206%2032%206%2047h-2v-2l-9-56z'/%3e%3cpath%20fill='%23bc835c'%20d='M211%20509q4%208%204%2015l1%203v16q-4-2-4-8l-1-6-1-7-1-2-1-6v-2z'/%3e%3cpath%20fill='%23aa373e'%20d='M215%20256v7h-16v-7z'/%3e%3cpath%20fill='%23d9a079'%20d='M267%20321h7l1%203v17h-1l-1-10-6%204-8%202v-2c5-3%205-3%208-3z'/%3e%3cpath%20fill='%23f9cdac'%20d='M257%20431h12v10h-9q-4-5-3-10'/%3e%3cpath%20fill='%23f4bd97'%20d='M283%20372h4l1%2011v8l-5%205z'/%3e%3cpath%20fill='%237f544a'%20d='m83%20548%205%201v2h5l2%204%202%201v2l-15%201v-7zm58-201h8l1%204v8h-3l-6%201z'/%3e%3cpath%20fill='%23d9a079'%20d='M17%20238v3l-2%201%2012%202-1%203q-6%202-13%201h-2q-5%200-9-2h2l1-2%202%201%201-2h3l-1-3z'/%3e%3cpath%20fill='%23f9cdac'%20d='M274%20447h7q-1%207-5%2013h-5v-9q-1-5%203-4'/%3e%3cpath%20fill='%23bc835c'%20d='M69%20284v7l-1%202v3l-1%204-3%2010-2%2010-2%206-5%2022-2-1%206-27%202-7%202-10%202-7%201-3%201-3v-3z'/%3e%3cpath%20fill='%233a2426'%20d='M252%20194h5v20h-5z'/%3e%3cpath%20fill='%23bc835c'%20d='M290%20317h7v3h-6l5%201v5h-2q-3%200-5%202l-6-5v-2l-5-2v-1h7l4%201z'/%3e%3cpath%20fill='%23f4bd97'%20d='m305%20327%203%2017q-5-2-7-6l-4-10z'/%3e%3cpath%20fill='%23f9cdac'%20d='m203%20470%205%204%201%207v17q-6-13-6-28'/%3e%3cpath%20fill='%23f4bd97'%20d='m281%20431%201%2010h-11v-9h4l3-1z'/%3e%3cpath%20fill='%23c05844'%20d='M102%20180v1l-20%201H67q-4%201-7-2c10-5%2031-1%2042%200'/%3e%3cpath%20fill='%237f544a'%20d='M241%20491q4%204%204%208l1%204%202%208c5%2019%205%2019%205%2028q-3-3-3-7l-1-4-1-3-1-7-1-4-4-16z'/%3e%3cpath%20fill='%23f4bd97'%20d='M269%20417v12h-12l6-8%202-2zm-62-63v13h-8v-9c4-4%204-4%208-4'/%3e%3cpath%20fill='%23bc835c'%20d='M280%20571h7l-1%205h-20c6-5%207-5%2014-5'/%3e%3cpath%20fill='%236c3235'%20d='M266%20525h1v2l4%2024%202%2016h-3v-2l-1-8-1-3-3-15-1-6%201-1z'/%3e%3cpath%20fill='%23f9cdac'%20d='M200%20430h7l1%203v7h-6l-2%204z'/%3e%3cpath%20fill='%23aa373e'%20d='M177%20256h12l1%206-13%201z'/%3e%3cpath%20fill='%23f9cdac'%20d='M210%20431h9v10l-8-1z'/%3e%3cpath%20fill='%234e333a'%20d='M128%20351v20l-4%201v-20z'/%3e%3cpath%20fill='%233a2426'%20d='M264%20278h9v9h-8l-1-3z'/%3e%3cpath%20fill='%23bc835c'%20d='m126%20246%202%201%201%207%201%204v3l1-10c5%207%202%2018%201%2026l-2-1-1-5-1-3v-4l-1-3z'/%3e%3cpath%20fill='%237f544a'%20d='m23%20229%201%206-5%201-3%201h-4l-1-4H9v-2l9-1zm240%20269q4%205%205%2012l1%203%203%2021-4-8-1-4v-2l-2-6-1-3z'/%3e%3cpath%20fill='%23bc835c'%20d='M270%20302h34v3h-32z'/%3e%3cpath%20fill='%23aa373e'%20d='M296%20241h3v8l-1%204h-6v-8q-1-5%204-4'/%3e%3cpath%20fill='%23d9a079'%20d='m96%20219-3%204q-8%202-18%202%209-7%2021-6'/%3e%3cpath%20fill='%237f544a'%20d='m217%20541%202%2027h-2l-2-6v-8l-1-12z'/%3e%3cpath%20fill='%23f9cdac'%20d='M159%20196h4v19h-3l-1-12z'/%3e%3cpath%20fill='%237f544a'%20d='M277%20460q6%206%208%2014l1%203%201%203%201%203v6l-2%202v-2l-3-8-1-3z'/%3e%3cpath%20fill='%23d0906b'%20d='M136%20314h15l5%201h12v2h-29q-3%201-7-2z'/%3e%3cpath%20fill='%23f9cdac'%20d='m217%20196%206%201-4%2018h-2z'/%3e%3cpath%20fill='%23bc835c'%20d='M192%20316h2l1%2026h-1l-1%2015h-1z'/%3e%3cpath%20fill='%23f4bd97'%20d='m180%20376%208%205-3%204-2%201-2%201-5-1z'/%3e%3cpath%20fill='%234e333a'%20d='M179%20217h8v5l-12%201v-5z'/%3e%3cpath%20fill='%236c3235'%20d='M67%20182h8l39%201v1H66z'/%3e%3cpath%20fill='%23bc835c'%20d='m79%20242%203%201-4%2020-2%201%203-17z'/%3e%3cpath%20fill='%237f544a'%20d='m158%20194%205%201-4%201v7h-1zm5%202h1v18h-1z'/%3e%3cpath%20fill='%23bc835c'%20d='m79%20242%203%201-1%208-2%201%201-6z'/%3e%3cpath%20fill='%237f544a'%20d='m158%20194%204%201-3%201v7h-1z'/%3e%3cpath%20fill='%23c05844'%20d='m77%20239%203%201-2%202z'/%3e%3cpath%20fill='%236c3235'%20d='M114%20189h3v2h-3z'/%3e%3cpath%20fill='%237f544a'%20d='m79%20242%203%201-1%202zm79-48%202%201-2%201z'/%3e%3c/svg%3e",
	windmill: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='576'%3e%3cpath%20fill='%2359375d'%20d='M0%200h320v576H0z'/%3e%3cpath%20fill='%23512e51'%20d='M196%20176h17l-1%204-11%201v2h2l-1%204%202%202q5%204%206%209l2-1h6l4%204v4l4%201v3h2l1-3h6q0-7-4-13l1-2%202%202%202%203%207%207h-6l17%2069%201%203%201%208%201%204%205%202%2011%209%208%205%203-1%201%202%205%208%2010%208-2-2-2-4-2-3q-4-4-3-7l2-2q4%203%206%208l8%2014%201%202%204%205%208-1v38l-34%206%2012%2044q5%2023%2015%2044%204%206%204%2013l-4%205q-5%204-4%207l2%207%202%208%201%202v8l-1%202-4-4-1%202-3%203h-2l-12-26-4-9q-4-6-5-14l-4%202v14h-2l-6%204-1-4-4%202v9c-13-2-13-2-16-5v-4l-3%204q-6%204-13%203l-1%202-2%201-6-1-4%202-5-1-2-7-1%201q-3%203-7%203l-2%201h-2v27l-2%206h-2l-2-6-5%201-1%202h-2l-1-26-6-1-12-2v-4l-1-3-2-4v-18l-1%202-2%203-14-1v3l-2%2011-1%204-1%203-3-1-7%202-3%201-5-3h-2l-7-3q-4-10-3-22%200-4-4-7h-5l-5%205-3%204h-4l-4%201-5%2012-9%2021-1%202-1%202h-4v-10h-2l-1%204h-2l-2%206h-2q0-6%203-11l1-5%208-19v-7l-1-3v-3h-2q-3-4-2-10l-2-2%204-18%204-12%201-3%206-21%201-3%207-26%204-13%201-2%201-6%204-15%201-3v-2l9-2-4-1q0-10%204-20l3-13%208-32%204-18%205-20%202-9h-12l5-9%201-3%206-1%209%201h2l3%201h9q0%2012-4%2024l-7%2034-6%2023-9%2034v3l-1%208%209%202%203%201%2018%204v-4h116l4%2021%2023-7%208-2q-8-11-19-19l-3-2-18-15-3-2-4-3%203%2010%201%202v3l1%207-31%201h-76l3-19%204-16v-3l2-7%2011-48%201-3%208-35%201-3v-3q3-4%208-3'/%3e%3cpath%20fill='%23fbc330'%20d='M89%20299h3q-2%2011-7%2022l-2%203-3%208%2016%202a212%20212%200%200%201-11%2042l-4%2013-1%203-9%2031-1%203-2%206-1%202-1%203q-1%205%202%209l1%205v4h2q4%209%200%2020l-2%203-3%206-3%208-3%2011h2v-2l2-4h2l1-4h2l1%209h3l1-2%206-13%204-11%205-11h8l2-4%203-4%202-2%201-1q5%201%209%205l1%209%201%207%201%2010h2l13%205%203-2h6l3%201v-3l1-3v-4l2-4%201-7%2014%201%201-4%203-3v18l2%204v9l3-1%202%201%2010%202%204%201v26h2l1-5%202%201%202%201%202-1%201%207h2l1-10v-2l1-6v-15l2-1h3l4-1%202-1%201-3%202%208%209-1h8l2-4%202%201%206-1%202-1%203-4h2v2l4%204%2012%203-1-10%205-1%202%203%201-1q2-2%206-2v-3l-1-4v-7l2-2h3l1%202%207%2016%2012%2029%201%202%204-1%201-5%205%204q1-5-1-11v-2l-3-9-1-6%206-7%202-6-5-12-10-26-1-4-7-24-5-19-1-3-1-3-1-3%201-5%204-1h3l3-1%2015-2%209-1v208H0V318l66%2010%201-4v-5l1-3v-4l1-2%203-1-1%2013%2011-13%202-2z'/%3e%3cpath%20fill='%23d9dbf5'%20d='m0%2096%2018%204%204%201h2l11%203%205%202%207%202%2053%2014%2017%204%207%201%2010%203%203%201%2018%204%203-9%2010%202-7%2012-1%202-4%206-3%204-14%2020-2%205h-2l-1%202-5%209h-2l-1%203-6%209-2%204h12l-6%2030-4%2016-10%2040-6%2026%205%201v1l-10%201v8l-4%208-15-3%203-10%201-3%208-20h-3l-1%202q-2%205-6%209l-1%202-9%2011-2-1%201-12h-2v2l-3%2017q-9%200-19-3l-29-5h-7l-11-3z'/%3e%3cpath%20fill='%23c9745a'%20d='M196%20176h17l-1%204-11%201v2h2l-1%204%202%202q5%204%206%209l2-1h6l4%204v4l4%201v3h2l1-3h6q0-7-4-13l1-2%202%202%202%203%202%203%205%204h-6l17%2069%201%203%201%208%201%204%205%202%2011%209%208%205%203-1%201%202%205%208%2010%208-2-2-2-4-2-3q-4-4-3-7l2-2q4%203%206%208l8%2014%201%202%204%205%208-1v38l-34%206%2012%2044q5%2023%2015%2044%204%206%204%2013l-4%205q-5%204-4%207l2%207%202%208%201%202v8l-1%202-4-4-1%202-3%203h-2l-12-26-4-9q-4-6-5-14l-4%202v14h-2l-6%204-1-4-4%202v9c-13-2-13-2-16-5v-4l-3%204q-6%204-13%203l-1%202-2%201-6-1-4%202-5-1-2-7-1%202-2-1V377l1-7%2041-8%206%2018%201%203%206%2028%202%2017%203-1%206%201%201%202q-1-16-6-31l-1-8-1-2-1-12%206-2-1-2-1-3v-3l-1-8%204-3-2-1h-2l-2-1-4-2-2-7-2-1v-2l14%201%201-4v4l23-7%208-2q-8-11-19-19l-3-2-18-15-3-2-4-3%203%2010%201%202v3l1%207-31%201h-76l3-19%204-16v-3l2-7%2011-48%201-3%208-35%201-3v-3q3-4%208-3m35%20156h42l2%207q-13%200-26-3h-2l-3-1-9-1z'/%3e%3cpath%20fill='%23b7dbfb'%20d='M0%200h195l-4%2023-5%2023-2%204-1%206-4%2022-1%207-3%2015h2l3%201h3l2%201q2%205-1%2011l-4%204h-4l-1%202-2%201-4-1h-3l-5-2%201-11-30%204-6%201-4%201-6-1-3-5q-3-8-10-10h-2%206l1-2h-2l-2-2q-6-5-14-6l-3-1-57-15-20-6-4-1H3l-3-2z'/%3e%3cpath%20fill='%23d7d0f2'%20d='M205%200h115v144l-24-6-4-1h-2l-29-8-44-10-5-1-3%2010c-10-1-10-1-14-3v2q0%207-4%2012l-4%201-2-3-6%201-4-1q-3-5-1-11%201-6%205-9h12v-3l2-9%2012%201v-3l1-4v-2l3-14%203-14%201-3V37l-2-1-8-2-3-1h-3l-3-1-3-3%205%201h3l4%202v-3l1-3v-4l2-6-3-1%202-1%202%201v-2l1-3V7l2-5-5-1zM44%20205c18-1%2036%206%2053%2011l4%201q7%202%2013%206l-2%201v3h-5l-8%2017-1%202-6%2017-1%202-2%205-1%202%202%208%201%2014%2021-48%207-15%208-19h1q0%2010-4%2021l-4%2017-10%2040-6%2026%205%201v1l-10%201v8l-4%208-15-3%203-10%201-3%201-2%207-18h-3l-1%202q-2%205-6%209l-1%202-9%2011-2-1%201-12h-2v2l-3%2017q-9%200-19-3l-29-5h-7l-11-3V213l4%201%207-2q17-6%2033-7'/%3e%3cpath%20fill='%23f3e7ee'%20d='m217%20153%2020%203%203%201%2019%205%2020%205%203%201h2l6%202%2017%205%204%201%209%202v149q1%204-2%204h-7l-5-7-1-2c-10-15-10-15-10-19l-3%201q2%206%206%2011l1%202%203%204q-3%201-5-2l-3-3-3-3-2-2-3-3q-2-1-2-6l-2%201-2%201-5-3-3-2-7-7-2-1q-6-2-7-8l-4-14-1-5-7-28-1-3-4-16-1-6-1-8%2012-1-3-4-2-4-16-23z'/%3e%3cpath%20fill='%2381486c'%20d='M196%20176h17l-1%204-11%201v2h2l-1%204%202%202q5%204%206%209l2-1h6l4%204v4l4%201v3h2l1-3h6q0-7-4-13l1-2%202%202%202%203%202%203%205%204h-6l12%2047%201%205%205%2020%204%2013-1%206-1-2-7-6-2-3-2-2-2-2-5-4%202%204%207%2018%203%206%202%204%201%203%201%205-97%201%203-19%204-16v-3l2-7%2011-48%201-3%208-35%201-3v-3q3-4%208-3'/%3e%3cpath%20fill='%23b4585d'%20d='M187%20368h14v21l-1%2028-3%2039-1%2029h4l1%206%206-1-6%202v27l-2%206h-2l-2-6-5%201-1%202h-2l-1-26-6-1-12-2v-4l-1-3-2-4v-12l-1-4-2%203-14-1v3l-2%2011-1%204-1%203-3-1-7%202-3%201-5-3h-2l-7-3-3-19-1-8h2v-2l14-65%201-6h3l4-1%202-6h1v5l46-9z'/%3e%3cpath%20fill='%23f6a755'%20d='M162%20150a112%20112%200%200%201%2031%207l-2%2017-1%203-1%206-3%209-9%2042-6%2024-6%2027-7%2031h3l73-1h31l-2-7v-3l-3-6v-6q6%202%2011%207l7%206%2024%2020%202%201%203%207c-23%209-23%209-31%209l-2-7-1-3-1-11H156v4l-21-3-2-1-8-3%203-19%202-5v-3l9-36%202-7%2012-56h-12q-8%200-15-2l1-3h2l2-4c3-7%203-7%207-8l6%203c7%203%207%203%2011%203z'/%3e%3cpath%20fill='%23b4585d'%20d='M239%20275q12%207%2019%2018v-6q8%204%2013%2010l9%206%204-1%201%202%205%208%203%202%207%206-2-2-2-4-2-3q-4-4-3-7l2-2q4%203%206%208l8%2014%201%202%204%205%208-1v38l-24%205h-3l-7%201%2012%2044q5%2023%2015%2044%204%206%204%2013l-4%205q-5%204-4%207l2%207%202%208%201%202v8l-1%202-4-4-1%202-3%203h-2l-12-26-4-9q-4-6-5-14l-6%201-6-25-1-3-1-4%201-8%207%201%201%202q-1-16-6-31l-1-8-1-2-1-12%206-2-1-2v-3l-1-3-1-8%204-3-2-1h-2l-2-1-4-2-2-7-2-1v-2l14%201%201-4v4l23-7%208-2q-8-11-19-19l-3-2-18-15-3-2-4-3%201%203v2l2%205%201%202v3l1%207h-10zm-8%2057h42l2%207q-13%200-26-3h-2l-3-1-9-1z'/%3e%3cpath%20fill='%23ed8169'%20d='M89%20299h3q-2%2011-7%2022l-2%203-3%208%2016%202a212%20212%200%200%201-12%2042v4l-1%202-1-2-7-1-15-1-12%2029-1%202-4%2010q-8%2019-19%2037v-5l10-25%2010-23%202-4%209-23h-3l-52-5v-53l66%2010%201-4v-5l1-3v-4l1-2%203-1-1%2013%2011-13%202-2zM0%2061l28%207%2063%2017%203%201q7%201%2012%206v2h2l-1%203h-3l3%201q5%202%207%208l3%205h2l24-4h3l5-1%2011-1q1%208-2%2017l-1%203-1%204-1%203-1%203q-6%201-12-1l-2-1-9-2-11-3-3-1-37-9-2-1h-2l-23-6-2-1-23-6-3-1-6-1-21-6z'/%3e%3cpath%20fill='%23d9dbf5'%20d='M94%2051q7%203%2014%203%2021%205%2033%2023l1%202%206%204%209-1%202-4%204-6%203-3%206-7h5v-2l3-1%203-4-3%2018-1%204-1%207-1%205v2l-2%209%208%201%202%201q2%205-1%2010%200%204-5%204l-3%201-1%202-2%201-5-1-7-2%201-11-36%205-4%201-6-1-3-5q-3-8-10-10h-2%206l1-2h-2l-2-2q-6-5-14-6l-4-1-10-3-4-1-20-5v-1h6l-1-2%201-10%203%201v-3l3-8-1-2%207-1v-3q13-2%2024%204'/%3e%3cpath%20fill='%23f3d7d3'%20d='m103%20228-1%202-12%2030-5%2013-1%202-1%202-5%201%202-21h-2v2c-2%2018-2%2018-4%2020l-5%201h-4l-4%201-42%208-2%201-4%201-13%201v-52a957%20957%200%200%201%2092-12z'/%3e%3cpath%20fill='%23fce6b9'%20d='m243%20229%206%207%202%203h3l3%205%202%203%201%204c43-3%2043-3%2058-11h2v82l1%202-1%206q-2%203-6%202-5-2-8-8l-1-2c-10-15-10-15-10-19l-3%201q2%206%206%2011l1%202%203%204q-3%201-5-2l-3-3-3-3-2-2-3-3q-2-1-2-6l-2%201-2%201-5-3-3-2-7-7-2-1q-6-2-7-8l-5-19-3-13-2-8-1-2-1-5z'/%3e%3cpath%20fill='%23f6a755'%20d='M212%20117a667%20667%200%200%201%2086%2021l2%201h3l7%202%2010%203v34l-22-4-2-1-12-3q-9-4-19-5l-61-16%203-17z'/%3e%3cpath%20fill='%23f3e7ee'%20d='m315%2064%205%203v77l-24-6-4-1h-2l-54-14v-1l3-1%208-5h2v-2q0-10%206-16l2-2c4-5%204-5%208-5h6c17-1%2027-11%2038-22z'/%3e%3cpath%20fill='%23b4585d'%20d='M139%20378h1v5h2l3-1%203-1h9l-3%2034v3l-4%2036v6l-1%203-1%204h5v1h-5v3l-2%2011-1%204-1%203-3-1-7%202-3%201-5-3h-2l-7-3-3-19-1-8h2v-2l14-65%201-6h3l4-1z'/%3e%3cpath%20fill='%23f0c599'%20d='M180%20211q1%206-1%2011v2l-2%207-6%2027-6%2027-7%2031h3l73-1h31l-2-7v-3l-3-6v-6q6%202%2011%207l7%206%2022%2018%202%202%202%201%203%207c-23%209-23%209-31%209l-2-7-1-3-1-11H156v4l-23-4v-2h8l2-8%2013%202v-2h-4l-3-1-5-1%202-9%2012%202-1-2-5-1-3-1h-2v-5l1-3%201-4h5l7%202v-3l-11-1%203-13%2012%202v-2h-4l-7-2%201-11%2012%202v-3l-10-2%202-12%2012%202v-2l-11-2%201-11%201-3h8l3%201%202%201v-3c2-13%202-13%205-16'/%3e%3cpath%20fill='%23b7dbfb'%20d='m0%2096%2018%204%204%201h2l8%203%208%202%204%201%206%201%203%201%207%204-1%207-4%202-1%202-3%203h-7l1%202-2%201q-11%204-21%2013l-6%203v11l6%202v2l2%201q7%202%2013%206v3l-24%2010-13%201zm74%20183-5%2036-1%205v3l-2%206q-9%200-19-3l-29-5h-7l-11-3v-26l9-2%2019-4%2010-2%205-1%208-1%203-1z'/%3e%3cpath%20fill='%23ed8169'%20d='M195%200c11%200%2011%200%2015%202l-1%205v3l-2%205h-3l2%201-1%206v4l-2%206-11-2%205%201%205%202%203%201%203%201h3l3%202q3%2017-1%2034l-1%203-6%2027-1%203v2l-18-2-3-1-9-3%203-23%202-7%205-27q3-6%203-14z'/%3e%3cpath%20fill='%23fccc5b'%20d='m0%20371%2029%202h2l7%201%205%201%2012%201-5%2016-11%2027-1%202-3%206-1%202-4%208h-5l-2-2-3-1-11-7-9-2z'/%3e%3cpath%20fill='%23c7a376'%20d='M127%20212h1q0%2011-4%2021l-4%2017-10%2040-6%2026%205%201v1l-10%201v8l-4%208-15-3%203-10%201-3%201-2%207-18h-3l-1%202q-2%205-6%209l-1%202-9%2011-2-1%201-12h-1l3-28%201-3%204-22h2q1%2011-2%2021l5-1%202-4%206-18%201-3%2015-29-5%2014-13%2041%202%2016%2021-48%207-15z'/%3e%3cpath%20fill='%2381486c'%20d='M219%20332h9l5%201%2010%201%2032%205v4h-8l-6-1v2l3%201%201%207%2010%203v3l-3%201v4l2%2012-5%202q1%2017%206%2032l3%2023-1-2-1-2h-9l-1-3-10-50-5-12-4%201-37%207v-6h2v2h3l1-4%201-4%201-2%203-7h2v-2l1-3%205-2-1-4-5-3v-2z'/%3e%3cpath%20fill='%23c9745a'%20d='m187%20380%201%202h13l-4%2075-1%2028h4l1%206%206-1-6%202v27l-2%206h-2l-2-6-5%201-1%202h-2l-1-26-7-2v-23l1-11v-8l1-15%202-19%201-11v-2z'/%3e%3cpath%20fill='%23f3e7ee'%20d='M52%200h99c-18%2027-18%2027-34%2031q-23%202-41-12l-7-6-12-9-5-3z'/%3e%3cpath%20fill='%23c9745a'%20d='M89%20299h3q-2%2011-7%2022l-2%203-3%208%2016%202a212%20212%200%200%201-12%2042v4l-1%202-1-2-7-1-15-1-12%2029-1%202-4%2010q-8%2019-19%2037v-5l10-25%2010-23%201-2%2022-51-5%206-3-1%201-2c7-26%207-26%208-38l1-5%203-1-1%2013%2011-13%202-2z'/%3e%3cpath%20fill='%23b4585d'%20d='M239%20275q12%207%2019%2018v-6q8%204%2013%2010l9%206%204-1%201%202%205%208%203%202%207%206-2-2-2-4-2-3q-4-4-3-7l2-2q4%203%206%208l8%2014%201%202%204%205%208-1v38c-16%203-16%203-19%202q-4-4-5-10l-2-3-5-11-1-6%208-3%203-1%202-1h2l4-1q-8-11-19-19l-3-2-18-15-3-2-4-3%201%203v2l2%205%201%202v3l1%207h-10z'/%3e%3cpath%20fill='%2347294b'%20d='M174%20240h16l7%201%201%2074h-22v-19h3l-1-1q-4-6-3-13l11%202v-2h-2l-2-1h-3l-4-2v-7l2-7%206%201v-2l-6-1%202-11h3v-4h2v-2h-5v3l-3%2010-5-2z'/%3e%3cpath%20fill='%23d7d0f2'%20d='m274%20270%2024%204%2022%205v49q1%202-2%203h-7l-5-7-1-2-10-16-12-20-4-6-2-3z'/%3e%3cpath%20fill='%23b4585d'%20d='M225%20368c2%2050%202%2050-1%2059l-3%201-3-5%202%2033%201%2033-6%201-2-3-1%202-2-1V377l1-7%204-1%203-1z'/%3e%3cpath%20fill='%23f3d7d3'%20d='M260%20293q6%202%2011%207l7%206%2029%2028c-23%209-23%209-31%209l-2-7-1-3-1-11-62-1v-5h-12v-1h67l-5-16z'/%3e%3cpath%20fill='%23c7a376'%20d='m243%20229%206%207%202%203h3l2%203%201%202%202%203%202%204%202%203%207%2011%201%204h3l2%204%2010%2017%202%202%202%203c3%205%203%205%203%208l-1%202%202%205%202%203%206%209-7-5-4-4-3-3-2-2q-2-2-2-6l-2%201-2%201-5-3-3-2-7-7-2-1q-6-2-7-8l-5-19-3-13-2-8-1-2-1-5z'/%3e%3cpath%20fill='%23f6a755'%20d='M32%20513h2v18h6l3%203%202%201v-7l4-1%201%2012%2026%207v-8l4-1%202%206v5l12%203%204%201%2018%204%206%202v-11h4l1%204v8h2q11%202%2021%207l3%202q7%202%2013%208h-44v-14l-41-10v18l-4%201q-2-2-1-5l-1-9v-7l-8-2-3-1-11-2-3-2v11q1%203-2%205l-1%201-2-4v-17l-3-1-7-4v9l-1%205h-2c-3-27-3-27-2-33z'/%3e%3cpath%20fill='%23f3e7ee'%20d='M66%20303h4c-1%2023-1%2023-4%2026q-9%200-19-3l-47-8v-9q21-4%2043-4h2l4-1z'/%3e%3cpath%20fill='%23ed8169'%20d='M162%20150a112%20112%200%200%201%2031%207q0%2010-3%2020l-1%204-3%2011-3-1-1-2-3%202q-7%202-15%200v-2l3-1-2-1-6-1-3-2%202-15z'/%3e%3cpath%20fill='%2381486c'%20d='m173%20378-1%2012-1%204v10l-3%208h-3v8l2%201v11l-1%205-4-1-1%208-1%202-1%2014%205-1v8q-1%202-6%202l-10-2%206-60v-5l1-7v-2l2-12-2-1%208-2z'/%3e%3cpath%20fill='%23fccc5b'%20d='M320%20368v35l-11%201-1%205-3%204h-6l-3%201-8-27-1-3-1-3-1-3%201-5%204-1h3l3-1%2015-2z'/%3e%3cpath%20fill='%23ed8169'%20d='m212%20117%2013%203%201%209h2l3%203q7%208%2016%2013l13%2012-8%204-15-3-11-3-14-3-8-3%203-15v-2z'/%3e%3cpath%20fill='%2347294b'%20d='m186%20103%207%201v3l-1%203v4l1%205h-2l-8-1h-2q-3%200-5%203-3%208-1%2016l4%202-2%2013-15-2v3l-4%2024-2%205-5%201-7-3-2-1-5-3%207-12%2016-24%201-2%207-10-10-2%202-9%2010%202h3l4-4h6v-2l1-3v-3z'/%3e%3cpath%20fill='%23f3d7d3'%20d='M122%20232h1l-3%2018v2l-14%2056-2%208%205%201v1l-10%201v8l-4%208-15-3%204-13%202-4%209-20%204-11%207-14z'/%3e%3cpath%20fill='%23b4585d'%20d='m196%20423%203%201-2%2034-1%2027h4l1%206%206-1-6%202v27l-2%206h-2l-2-6-5%201-1%202h-2v-12l-1-4v-6l1-34v-7l1-19v-4l1-3v-3l2-5h2v5h2z'/%3e%3cpath%20fill='%23f6a755'%20d='M256%20383q4%202%204%207l1%202%202%2010%201%205%205%2025%201%204%201%207%201%204%201%203v5l-6%202-1-2-1%202q-4%202-8%201l-4-22-1-7-3-36v-3q0-3%202-5l4%201z'/%3e%3cpath%20fill='%23ed8169'%20d='m79%20332%2017%202a212%20212%200%200%201-12%2042v4l-1%202-1-2h-7l-15-3%2013-32z'/%3e%3cpath%20fill='%2381486c'%20d='M295%20444h2l2%205%201%203%201%206%205-2%203%206%204-1%202%205%201%202v8l-4%204q-4%204-3%207l2%207%202%208%201%202v8l-1%202-4-4-1%202-3%203h-2c-13-25-13-25-13-33l12-1-1-2-3-10-6-24h2l1%202z'/%3e%3cpath%20fill='%23fccc5b'%20d='m60%20377%205%201h6l3%201%208%201q-2%2015-7%2030l-4%201-27%204%208-22%203-5z'/%3e%3cpath%20fill='%23fce6b9'%20d='M118%20227h2l-4%2013-1%203-1%203-11%2024-1%203-11%2022h-1v-9l-2-10c-2-6%202-12%204-17l8-21c4-9%204-9%207-11z'/%3e%3cpath%20fill='%2381486c'%20d='M179%20246h5v2h-2v4h-3l-2%2011%206%201v2h-6l-2%2013%2011%203v2l-11-2%201%202v9l3%201v2h-3v19h20v1h-38l3-17%206-27%201-5%202-11%206%203v-2l1-2v-3z'/%3e%3cpath%20fill='%23b4585d'%20d='M239%20275q12%207%2019%2018v-6q8%204%2013%2010l9%206%204-1%201%202%205%208%203%202%207%206-2-2-2-4-2-3q-4-4-3-7l2-2q4%203%206%208l12%2020-1%203q-5-1-8-6l-10-9-28-22-4-3%201%203v2l2%205%201%202v3l1%207h-10z'/%3e%3cpath%20fill='%23f3d7d3'%20d='M205%200h22q-1%2016-6%2032v2l-1%202-2%201%201%203-1%206-1%203-1%203h-1l-2-15-5-1-5-2-3-1h-3l-3-1-3-3%205%201h3l4%202v-3l1-3v-4l2-6-3-1%202-1%202%201v-2l1-3V7l2-5-5-1z'/%3e%3cpath%20fill='%23ed8169'%20d='M282%20370c6%206%207%2017%209%2025l2%207%201%204%203%208%201%205%2013%2043h-2l-4-5-4%201-3-10c-2-6-2-6-1-8l2%201-2-2q-4-4-5-9l-1-4-1-4-2-4-8-32-3-1-1-6-1-3v-2l4%201%201%202z'/%3e%3cpath%20fill='%23c9745a'%20d='m150%20222%2016%203h3l5%202%201%203-12-2-1%206-2%208h4l7%202v2l-12-2-2%2012%2010%202v3l-12-2v3l-1%208%2011%202v2l-12-1-3%2012%2011%201v3l-12-2-2%2012%2010%201%201%203h-4l-3-1-5-1-2%209%2012%202v2l-13-2-1%208h-3l2-9h-2l-3-1h-3l-3-1-1-2%2012%201%201-8-8-1v-3l10%202v-5l2-7-10-2v-2l11%201v-3l2-9-9-2v-3l10%202v-3l3-7h-2l-2-1-5-1-1-3%2010%202%203-12-10-2v-2l11%201%201-5%202-9h-4l-6-2z'/%3e%3cpath%20fill='%23d7d0f2'%20d='m245%20235%2011%2016%202%203c11%2017%2011%2017%2013%2025l4%2014%201%205q-7-2-13-7l-4-3q-4-3-4-9l-1-2-2-8-1-3-3-16-2-6z'/%3e%3cpath%20fill='%23f3d7d3'%20d='M102%2089h2l2%201h3l4%201%2012%203%203%201%205%202%2014%203%203%201%202%201h2l5%203-23%204-6%201-4%201-4%201-6-1-3-5q-3-8-10-10h-2%206l1-2h-2z'/%3e%3cpath%20fill='%23b7dbfb'%20d='M122%20232h1l-3%2018v2l-10%2042-3%206-7%201h-7q5-16%2013-31z'/%3e%3cpath%20fill='%23ed8169'%20d='m254%20128%2018%203%2021%206-1%202-3%205-4%203-9%201-1-1-1%202q-3%204-8%204c-12-18-12-18-12-25'/%3e%3cpath%20fill='%23f3e7ee'%20d='m294%20302%2026%201v24q0%204-2%204h-7l-6-9z'/%3e%3cpath%20fill='%23c9745a'%20d='m288%20341%202%204%205%2010%201%202%205%2013h6v1h-2l-8%201-3%201h-3l-3%201-4%201-3-13-2-4-1-6-1-4-1-5%204-1%203-1z'/%3e%3cpath%20fill='%23f0c599'%20d='M183%20117h3l4%201%204-1%203%204-2%2010-4%208h-5l-1-2-4%201-6-1q-3-5-1-11%201-9%209-9'/%3e%3cpath%20fill='%23b4585d'%20d='M195%200c11%200%2011%200%2015%202l-1%205v3l-2%205h-3l2%201-1%206v4l-2%206-9-2-1-11h-2z'/%3e%3cpath%20fill='%23fce6b9'%20d='M198%20315h68v2l4-1%201%204q-9%203-19%202h-15l-8-1h-19v-5h-12z'/%3e%3cpath%20fill='%23c7a376'%20d='M158%20316h52v5h55v1H156z'/%3e%3cpath%20fill='%23b4585d'%20d='m197%20484%203%201%201%206%206-1-6%202v27l-2%206h-2l-2-6-5%201-1%202h-2v-11h2v-2q0-6%205-11%203-5%202-11z'/%3e%3cpath%20fill='%23c9745a'%20d='M258%20287q8%204%2013%2010l9%206%204-1%201%202%205%208%203%202%207%206-2-2-2-4-2-3q-4-4-3-7l2-2q4%203%206%208l12%2020-1%203q-5-1-8-6l-10-9-28-22-4-3-1%203zm49%20198%205%2011%203%2016-3%202-3-4-1%202-3%203h-2l-5-9-1-3%202-3v-10l3%204v-7l3-1%202%201z'/%3e%3cpath%20fill='%23fccc5b'%20d='M105%20454c7%202%207%202%209%205v9l-4%201-16%205-3%201-7%203%203-9%201-2%201-2h8l2-4%203-4%202-2z'/%3e%3cpath%20fill='%23f3d7d3'%20d='M85%20279c4%206%204%2017%203%2024q-3%207-10%2013l-6%207-2-1%201-5v-2l3-8%206-16%201-3%201-3z'/%3e%3cpath%20fill='%23b4585d'%20d='M179%20246h5v2h-2v4h-3l-2%2011%206%201v2h-6l-2%2013%2011%203v2l-11-2%201%202v9l3%201v2l-8-2%201-3-2-2v-10l-2-1h2v-8l1-3-2-1%201-10%206%203v-2l1-2v-3z'/%3e%3cpath%20fill='%23f6a755'%20d='M44%20465h3v7l13-1v3l-13%201v8h-3v-8l-12%203-4%201h-3l-3%201-9%203%201-2-4%201-1%207H7l-1-7-6%201v-4l6-1v-10h3l1%209h9l5-1%203-1%204-1%206-2h3l4-1z'/%3e%3cpath%20fill='%2381486c'%20d='m186%20103%207%201v3l-1%203v4l1%205h-2l-8-1h-2l-4%201-3%208v3l-1%202-2-1q-6-4-13-5l2-9%2010%202h3l4-4h6v-2l1-3v-3z'/%3e%3cpath%20fill='%23fce6b9'%20d='m245%20235%2012%2017%202%203%202%203%201%202%204%208h-7l-7-1-2-6-1-3-1-4-1-4z'/%3e%3cpath%20fill='%23fbc330'%20d='M127%20563q16%203%2029%2011l1%202h-30z'/%3e%3cpath%20fill='%2347294b'%20d='M135%20177q7%202%2013%206l2%201%205%202-1%205h-12l-14-2z'/%3e%3cpath%20fill='%23fce6b9'%20d='M122%20232h1l-3%2018v2l-6%2022h-9l4-12z'/%3e%3cpath%20fill='%23b4585d'%20d='m305%20456%204%204v2l4-1%202%205%201%202v8l-3%204-1%202-1%201q-5-6-7-13v-2l-2-10z'/%3e%3cpath%20fill='%23f6a755'%20d='m0%2061%207%202%201%2013-4%201%204%201%204-10h1l-1%207-1%204%2010%203%201-5v6l9%202v1q-11%200-21-5L7%2093v-8l1-3v-2l-8-1z'/%3e%3cpath%20fill='%2359375d'%20d='M186%20190h1c-1%2036-1%2036-3%2045l-7-2%202-14%204-16z'/%3e%3cpath%20fill='%23b7dbfb'%20d='M232%200h27l-1%204-7%203h-2l-6%202-4%201-7%201z'/%3e%3cpath%20fill='%23f0c599'%20d='m73%2081%2019%204%202%201q7%201%2012%206v2h2l-1%203-7-1-4-1-7-3%202%204-11-7-1-2z'/%3e%3cpath%20fill='%23512e51'%20d='m250%20347%202%201%2011%203q6%201%207%204v4l-17%203q-3-7-3-15'/%3e%3cpath%20fill='%23fce6b9'%20d='M97%20235h2l-12%2031v2l-2%204-2%205-5%201%202-20%201%203%203-1-1-4%205%202v-4l3-7h2v-2l-2-2%202-2h3z'/%3e%3cpath%20fill='%23f3d7d3'%20d='m274%20279%209%2012%203%205%202%206h2l8%2013%201%202%203%204q-3%201-5-2l-3-3-3-2q-8-6-9-17-2-4-5-6-3-5-3-12'/%3e%3cpath%20fill='%23b4585d'%20d='M231%20332h42l2%207q-13%200-26-3h-2l-3-1-9-1z'/%3e%3cpath%20fill='%23c7a376'%20d='m137%20176%205%202%202%201%205%202%205%201h2l1%202%207%202h3l3%201q-6%204-12%205l-4%203-1%202v-4h-12q-8%200-15-2l2-3%202%201%2014%201h10v-4l-4-2-2-1-2-1-7-3-2-1z'/%3e%3cpath%20fill='%23ed8169'%20d='m291%20458%201%204%206%2015%201%204-9%201-2-11-1-3-1-3-1-3v-4z'/%3e%3cpath%20fill='%23c9745a'%20d='m125%20468%201%202%205%201-1%2014%202-4h1v7l-2%201v-2l-2%201q-4%201-8-2-2-6%201-13z'/%3e%3cpath%20fill='%23ed8169'%20d='M81%20315h2q-1%207-6%2014l-2%206-8%2012h-2q1-14%209-23l5-6zm104%2081h4q3%2014-1%2028l-2%202q-3-2-3-5zM320%2034v24l-7-6-2-2q-2-2-2-5%201-3%205-4l2-4z'/%3e%3cpath%20fill='%23fccc5b'%20d='m314%20142%203%201%203%201v16l-2%205v-4l-11-3h11l-2-3-3-3-2-2q-4-4-6-9%205-1%209%201'/%3e%3cpath%20fill='%23b4585d'%20d='M307%20485q3%204%203%2010l1%203v3l-4-2%201%207-2-1-1-5h-2l-2%207-3-1-1-5%202-1v-10l3%204v-7l3-1%202%201z'/%3e%3cpath%20fill='%23b7dbfb'%20d='M85%20279q3%204%202%207l1%203v12l-3%201h-8l4-14%201-2z'/%3e%3cpath%20fill='%2381486c'%20d='M216%20535h3l1%205-1%201%203%201q2%204%202%209l-2%202-7-2v-7l1-1-5-2q0-7%205-6'/%3e%3cpath%20fill='%23c9745a'%20d='M258%20543h2l1%203%203%207c4%209%204%209%202%2014h-4q-5-9-5-19z'/%3e%3cpath%20fill='%23b7dbfb'%20d='M96%20275h4q-3%2011-9%2020h-1l-1-19z'/%3e%3cpath%20fill='%23f6a755'%20d='m269%20482%202%203%201-2%202-1%204%201v7l-9%203v2l-4-1-1-11z'/%3e%3cpath%20fill='%23c9745a'%20d='M169%20455h2v12l-3%2014-1-2h-2v-19h2l1%201z'/%3e%3cpath%20fill='%23d7d0f2'%20d='m274%20279%209%2012%203%205%202%205-5%201-1-2v-2l-1-2-4-5q-3-5-3-12'/%3e%3cpath%20fill='%2381486c'%20d='m195%20125%2013%203v6h-4l-6-1-2-1-2%202z'/%3e%3cpath%20fill='%23ed8169'%20d='M88%2086q11%200%2018%206v2h2l-1%203-7-3-2-1q-6-1-10-5z'/%3e%3cpath%20fill='%23b4585d'%20d='M317%20541h3v19l-5-1c0-7%200-7%202-10l-2-2z'/%3e%3cpath%20fill='%23f6a755'%20d='m86%2090%208%204-1%204v3l-3%206v-5l-5-1-3-1h-8v-2l-6-1v-1l17%203%206%201c-2-8-2-8-5-10'/%3e%3cpath%20fill='%23f3e7ee'%20d='m245%20235%207%2010%202%202%201%202-1%203h-5q-3-8-4-17'/%3e%3cpath%20fill='%23b4585d'%20d='m217%205%209%201v8l-4%204-2-1-2-8z'/%3e%3cpath%20fill='%23ed8169'%20d='m207%2024%207%201v9l-8-1v-7z'/%3e%3cpath%20fill='%2381486c'%20d='M187%20368h14v4l-14%202zm7%20115h1l1%206v4q1%204-3%207h-2l-2%2011h-1v-16l5-1z'/%3e%3cpath%20fill='%23f3d7d3'%20d='M81%20315h2l-7%2016-6-1%206-8zm117%200h64v1h-64z'/%3e%3c/svg%3e",
	terraces: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='576'%3e%3cpath%20fill='%234b632f'%20d='M0%200h320v576H0z'/%3e%3cpath%20fill='%23c6d055'%20d='M228%20156h30v2l3-1%2016-1-4%2010-1%202q-2%208-2%2017l-1%206-6%204q-3%206-2%2014v9h-3l1%201%203%206%201%204%202%201%201-7h1v7l7-1v-3q1-5%206-9l7%201v-4q3-2%208-2v-2q-1-12%206-20l2-2-1-2-1-6%202%202q3%204%208%204v-12l3-2%201-4h-2c2-7%202-7%205-9h2v411l-3-1h-12a349%20349%200%200%201-114-17c-19-5-41-14-52-33q-4-9-3-18v-3l1-17q-10%203-15%2011l-2%203-4%206q-9-4-13-12-6-12-2-26%203-12%2014-20l5-2q6-2%209-6%202-9%202-19t6-17q6-4%2013-5l2-1%202-5q2-6%205-7l5-2%202-6%201-3%201-2-7-3q-13-4-25-13c-5-3-5-3-8-3v-3l-7-1v-2l-7-2-2-2q-3-4-7-5h-2l-4-5q-4-7-12-9l-1-4-3%203-5%202-3-2v-2l-1-7q-11-8-23-14l-6-4-5-2-8%203-6%201v-2c5-4%205-4%208-4l-1-2h-2l-1%202h-2v-3l-1-3h-2q-6%201-10-2-3-7-2-14v-11q7%207%206%2015%207-3%207-7v-2l2%203%2010-10%201-2%207-12%203%201q1%203-2%205l-1%201-9%2011%2013-5q9-3%2017-3h3l4%201v-3q0-5%204-8l6-1%2016-1h3l7-5h9l1-3q2-7%208-11l18-4c8-1%208-1%2011-4l2-4q2-4%206-5h15v-3q1-5%204-7l1-3q4-7%2010-13l3-1%203-3%201-3q1-6%205-12%2010-4%2021-1'/%3e%3cpath%20fill='%23e4e4ea'%20d='M0%200h320l-1%20112v7l-1%202v8l-4%202h-3l-5%201-1-2-7-3v2l3%201v2l4-1v2c-6%203-6%203-11%203l-2%205-2-1-8%201%201-3h5v-2h-2l-1-3-2%201h-3l-3-3h4l-5-4-1%202-2%202h-3l1-5%202-1h-5l-1%203h-4v4l4%203-5%201%201%203h-3l-2%203-2-2-2%203h-4l-2%203h-2v-4l-2-4-6%201v-4l5-1-1-1-6%201v-2h3l1-4h7l1-2-4%201-1-3%203-2h-3v-3l2-1v-2l5-3%202-1q5-3%2012-2l3%201%201-5-4%201h-7l-2%203-5-1-1%203-6%201v-3l6-1-3-3-4%201-1%205h-2v-2l-1%202-4%201v-5h-2v-2h2v-2h-7v4h-2l-2%201-1%203h-2v3h-4l1%202-1%205h-2v-6l-2-1v3l-5%201v3l-3%201-2%202-3-1-3%204-2-3-1%204-4-1-1%202-2-2q-2-3-8-3l-1%201h4l-1%203-6%202-1%202c-5%203-5%203-8%203l-1%202-1-1q-2-2-5-2l1-3h-8v2l-3%201%203%202h-5l2%206%204%201-2%201v2l3-1%202%2013h2l-1%202v7h-3l-1%203c-5%202-5%202-9%201l1%206-3%201-5%204-2-1%201-2v-6l3-6-2%201-6-2h-4l-2-1%202%204-12-2-1-2h-7l-4%204h-3l-1%209h-3v-4l-2%202-4%201%201-2v-7l3-3H83v-4h3l-1-1q-3-5-2-11l2-5-2%201q-7%204-14%201v2h-8v-2h-3l-1-2-2%201h-5l-1%204h-2v-4l-2-1v2h-2v7l4-1c0%207%200%207-2%2010h-2v2c-5%203-5%203-8%203l-2-1q3-2%207-2l-1-1-3%201-7-1-4%201-4%201v-2h-3l-1-2-6%202v-2h2v-4h3v-2l-2%201-3%201-2%201q-5%202-8-1l-1-1zm274%20123%201%202%201-2z'/%3e%3cpath%20fill='%23769e30'%20d='m297%20358%202%201v7h2l2-2%202-2h2l-2%205%203-1%201%204%202-3%207%202q3%206%202%2013v188l-3-1h-12q-40%201-78-8l-7-1-29-8c-19-5-41-14-52-33q-4-9-3-18v-3l1-17q-10%203-15%2011l-2%203-4%206q-9-4-13-12-6-12-2-26%203-12%2014-20l5-2q6-2%209-6%203-9%202-19%200-10%206-17%206-4%2013-5l2-1%202-5q2-6%205-7l5-2%202-6%201-3%201-2%202%201h33l-2-5h3l1%204h7l-1-8c4%205%204%205%204%208h5l3-5h2v3h4l2-7h2l2%206%209-1%201-2%201%205h6l1%203v-4l4%201%2017-1%2010-1%204%201h7v-3z'/%3e%3cpath%20fill='%2330605c'%20d='m269%20103-2%208-3-1q-8%200-14%204l-2%202h-3v2l3%201h-5v3l3-1v3h-3l1%202h4l-1%203h-7l-1%203h-3v2l8-3-1%204-5%201v2h3q3-1%205%203l2%202-2%203%202-3%203-2%203%201%203-3%201%201%202-2%203%201v-2l-2-1%204-1-3-3%202-3-2-1%203-1%202%201%201-4%202%201%202-2%202%204h-3l-1%204q5-1%207-6v3l4%202%201%202h-4l8%201v3h2v2l-5%201%209-1v2l1-5h3l9-2h-2l-5-4v-2l8%203v2l11-3v-8l1-2%201-13h1v41l1%203c0%208%200%208-3%2012l-3%201-2%205h2l-1%205-2%201-1%206v6l-8-1-1-2%201%202%201%203-3%203q-6%207-5%2016l-1%205q-4%203-8%202v4h-3q-4-1-6%202l-3%206-1%203-7%201-1-4-1%204-3-1-1-6v-2l-3-1v-2h3v-2q-3-10%200-20l5-3%203-6v-4q0-14%208-27l-19%202v-2h-2l-11%201h-11l-9-1c-14-1-14-1-18%202q-4%207-6%2015l-4%203q-9%206-13%2017h-2l-2%209h-3c-12%201-12%201-17%204l-2%204q-2%204-6%205l-14%203q-9%200-16%208l-2%205-1%202-7%201-4%202q-4%204-8%203l-4%201H81l-5%203-2%208h-2q-19%200-36%209l7-11%202-3%202-2h2l-1-3h-2l-3%206q-8%2015-22%2023h-2l-1-3-4-9v17l2%204%201%2011-7-5q-2-4-6-5-4-2-5-6v-33l1-84%203%201q5%201%2010-2h3v2h-3v4h-2v2l2-2%202-1%203%201v2h16l6-1v2l-6%202%209-2v-2l2-1q2-4%201-8h-3l-3-4%203-3h2v-2l3%201-1%204h2l1-5%206%201%201-2%201%203h3v2l2-1%206%201v-2h5l3-1%208-2%201%202-1%202-1%2010%202%204-3%201v2l10%201-1%203-2%201%201%202-2%206%202-1%204-2v4h3l-1-2%202-7h3l1-2%201-2%205-1h4l1%203%203-1%207%202v-3l2%201%205-1v2l3-1v2l5-2-1%202-1%206-2%204-1%203%205-3%202%201%201-2%201-2v-4h2q5%200%209-3l1-2v-2l-1-2%203-4h-2l-3-12h-2v-3l-3-1-1-6%202-1-3-1%204-1h2v-2h9v3h3l1%202%203-2%206-2%201-3%206-2-4-2%202-2q6%200%2010%204l1-2%204%203v-5l4%202%202-3h4l4-1-1-3%204-1h2v-3l3%201-1%206h2v-7h4v-3q4-5%207-4v-4h7v2h-2v2l3-1-1%206h2l1-3h2v2h2v-2l1-3%205-2%202%204-6%202%204%201%203-3h2q3%201%205-2l1-1%202%201%206-2zm5%2020%202%201-2%201z'/%3e%3cpath%20fill='%23e4d01e'%20d='M320%20159v215l-2-4-7-2-3%203-1-4h-2l2-5-8%206-1-9h-1v3l-1%204q-5%202-11%200h-7l-3%201h-6q-8%202-16-1v4l-2-1%201-2h-6l-1-4-1%202-6%201-3-1-2-6h-2l-1%208h-6l1-4h-2l-1%202-3%204-4-1-3-6v6h-7l-1-4-2%201%201%204-34%201v-2h-2l-8-4-3-1q-11-3-20-11c-5-3-5-3-8-3v-3l-7-1v-2l-7-2-2-2q-3-4-7-5h-2l-5-6%201-4%205-2%204-3v-10l-1-3h2l1%202v3l1%203%203%203-2-19h2l3%2017%202-1%201-6v-5h2l1%207%204-1%208-2%204-1%202-4%206-5%202%201v2h2l2%205-2%201%201%202-1%202%204%201v2l4-3%201%205h-3l2%2012%205-1%202-5q2-6%206-10v-4l-3%201v-2l-1-2-5-1-2-2-3%202-1-4h-2l-1-2-4-14h2l3%205%202%205%206-3%203-1%205-5%202%202%202-1%207-1%201-3%207-1%205-2q4-4%207-3l10-2v-3l4%202%202-4v-7h2v4l1%203v2l2%201%202-6%202%203h6l3-1h2v-4h2l1%202q11%201%2021-2l-1-4h3v2l3%201-3%201%203%206%205%201%203-5-3%201v-5l-3-1%202-3%203-12%201-4v-5l-1-3v-2l-2-1h2v-3q1-6%206-10l7%201v-4q3-2%208-2v-2q-1-12%206-20l2-2-1-2-1-6%202%202q3%204%208%204v-12l3-2%201-4h-2c3-9%203-9%207-9'/%3e%3cpath%20fill='%232b3627'%20d='M0%20276c10%207%2010%207%2013%2011l3%202v-8l8-1v2h3l1%202%202-1-2%205h2l1-3%203%201v2c-5%204-5%204-8%204v2l2-1%204-1%203-1%203-1%202-1%205%202%204%204%206%203c18%208%2018%208%2021%2015v6l4%201%204-4h2l1%202%204%203q5%202%208%206l2%203%202%204%202-1%204%201%202%202%202%201%201%204%203-1%204%203v2l3-1%204%202v3l3-1%205%203%203%202%205%203q8%206%2017%208l7%204-4%2012-5%202q-3%203-4%207-2%206-5%206l-6%201-8%205-4%2012v4l-1%204v7l-1%203-1%205-16-1h-3l-11-1v-5l1-3-2%201-2%207h-6v-17h-2v17l-9%202H65l-2-3%201%205-8%204-2%201q-5%203-11%202-18%202-32%2012l-1%202-10%202z'/%3e%3cpath%20fill='%23b2c56c'%20d='m256%2057%207%2010%203-1q14%200%2025%208l3%205h5l3%203%207%2011c4%206%204%206%208%207h3v2l-2%2027-4%202h-3l-5%201-1-2-7-3v2l3%201v2l4-1v2c-7%203-7%203-11%203l-2%205-2-1-8%201%201-3h5v-2h-2l-1-3-2%201h-3l-3-3h4l-5-4-1%202-2%202h-3l1-5%202-1h-5l-1%203h-4v4l4%203-5%201%201%203h-3l-2%203-2-2-2%203h-4l-2%203h-2v-4l-2-4-6%201v-4l5-1-1-1-6%201v-2h3l1-4h7l1-2-4%201-1-3%203-2h-3v-3l2-1v-2l5-3%202-1q5-3%2012-2l3%201%201-5-4%201h-7l-2%203-5-1-1%203-6%201v-3l6-1-3-3-4%201-1%205h-2v-2l-1%202-4%201v-5h-2v-2h2v-2h-7v4h-2l-2%201-1%203h-2v3h-4l1%202-1%205h-2v-6l-2-1v3l-5%201v3l-3%201-2%202-3-1-3%204-2-3-1%204-4-1-1%202-2-2q-2-3-8-3l-1%201h4l-1%203-6%202-1%202c-5%203-5%203-8%203l-1%202-1-1q-2-2-5-2l1-3h-8v2l-3%201%203%202h-5l2%206%204%201-2%201v2l3-1%202%2013h2l-1%202v7h-3l-1%203c-5%202-5%202-9%201l1%206-3%201-5%204-2-1v-2l1-6%203-6-2%201-6-2h-4l-2-1%202%204-12-2-1-2h-7l-4%204h-3l-1%209h-3v-4l-2%202-4%201v-2l1-7%203-3H83v-4h3l-2-1q-2-5-1-11l2-5-2%201q-7%204-14%201v2h-8v-2h-3l-1-2-2%201h-5l-1%204h-2v-4l-2-1v2h-2v7l4-1c0%207%200%207-2%2010h-2v2c-5%203-5%203-8%203l-2-1q3-2%207-2l-1-1-3%201-7-1-4%201-4%201v-2h-3l-1-2-6%202v-2h2v-4h3v-2l-2%201-3%201-2%201q-5%202-8-1-2-3-2-8%201-7%204-11l4-4%203-3q32-32%2075-32l21%203%2024%206c9%202%2016-4%2024-8l6-3%207-4%202-1%202-1%2019-2h2q8%200%2015%203v-3q0-4%202-7l5-3%202-5q4-15%2017-22%2013-4%2023%204m18%2066%201%202%201-2z'/%3e%3cpath%20fill='%23a0c237'%20d='m285%20409%203%206%2024-4h8v108h-10l-1-6-1%206h-5l-1-5h-2v5l-3-4-1%203-5-1-1-4-1%205-5-1-1%202-1-2-2-1q-5-3-5-10l1%2010-5-1-2%204v-2l-1-2-4-1v10q-4-4-3-8l-4-3-3-1v2l-1%2010v7l-1%204v2l-2%201%201-28h-3l-1-2-3%201-4-1-2%205h-1v-2q0-3-5-5l-3-1v8h-1l-1-4-2-5-9-4-7-4-1%2021h-1v-15l2-17-1-5-3-1%202-1%201-4h-3l-3-20%203%204%201%209h2l2%202v-2l-1-24h2l1%203%201%204v3l3%206q4-4%204-10h2v3l2%206%203-3v-2l1-2v-2h5v-3h-2v-2h3l1-3%203-5%201-6v-5l2%201v7l4-2%203-2%203-3v-2h2v2l6-2%203-1q4-2%204-5v-2l3%204%202-1h3l10-3z'/%3e%3cpath%20fill='%23628c36'%20d='m168%20368%201%202q2%204%208%205l2%201%2023%209%201-2v3h3q7%200%2013%203l1-6%203%203%201%203v2l1%207%206-2%201-2%202%201v6l-6%204v3h-2l-1%2014h-4l-2-4-1-2-1-4-4%201-3%207h-2l1%209-4%201-2-2v-4h-2v5l-5%201-1%2010h-2l-1-9-3%201-2-1v2l2%201h-3l-1%203-1-3-2%202v-4h-3v11l-1-4h-2v8l-5-1-1%2010q-3-4-4-10v-2l-1-6v10q1%206-2%2013l-2-1-1-7v-6h-2l1%202v13l-2-2v7l-2%205-2-9h-2v2l-5%204%201%2014-4-9-1%203-4%206-1-2q-10%203-15%2011l-2%203-4%206q-9-4-13-12-6-12-2-26%203-12%2014-20l5-2q6-2%209-6%203-9%202-19%200-10%206-17%206-4%2013-5l2-1%202-5q2-6%205-7l5-2%202-6%201-3z'/%3e%3cpath%20fill='%23fefefe'%20d='M0%200h265l-10%208-2%201q-10%204-18%203h-3l-17-2q-20-7-40%201-19%2011-31%2028-13%2013-30%2014-17%200-31-9l-4-4C60%2020%2031%2015%204%2014H0z'/%3e%3cpath%20fill='%234b632f'%20d='M319%20106h1v41l1%203c0%208%200%208-3%2012l-3%201-2%205h2l-1%205-2%201-1%206v6l-8-1-1-2%201%202%201%203-3%203q-6%207-5%2016l-1%205q-4%203-8%202v4h-3q-4-1-6%202l-3%206-1%203-7%201-1-4-1%204-3-1-1-6v-2l-3-1v-2h3v-2q-3-10%200-20l5-3%203-6v-4q0-11%204-21l1-2%203-4%208-1%201-5v-2l3-7%203-1%201-5h3l9-2h-2l-5-4v-2l8%203v2l11-3v-8l1-2z'/%3e%3cpath%20fill='%239eab34'%20d='M228%20156h30v2l3-1%2016-1-1%202-3%208-1%202q-2%208-2%2017l-1%206-4%202-6-3h-3v-9l-2-1v-3q-1-5-4-9v-2l-9-1-1-4-2%203-2-1v-2l-2%202%201%202h-2v2l4%201v2l-4%201-3%201-5-1-1%2059-14-2-1-55-1%2042-1%2012h-3v-49q0-2-2-3l-2-1q2-9%207-17%2010-4%2021-1'/%3e%3cpath%20fill='%23e4d01e'%20d='M234%20161h2v2l2-1%202-1%201%204h2c6%200%206%200%209%203q3%205%203%2012l2%203-1%207%202-1%205%202%202%202-1%202q-3%205-4%2011l-1%203-4%201q-6%203-6%207l-3%201%202%201-1%203q3%203%208%201l2-1%203%206%201%202-1%202h-4l-2%205q-2-3-2-8h-3v2q-7%200-11-4l-1%201q-3%204-8%203h-5v-53l1-7%2012-1-1-2-3-1z'/%3e%3cpath%20fill='%23a0c237'%20d='M320%20159v28l1%2013v17c0%2012%200%2012-3%2017q-4%204-10%204h-4v-6h-2l-2-4%201%207-6-7-1-2-1-2%202%203%201%205h-2v2h3v2h-2l-7-1v-5l-3%205-3-5-1-2h-3v-2l-3-1c2-6%202-6%205-8l7%201v-4q3-2%208-2v-2q-1-12%206-20l2-2-1-2-1-6%202%202q3%204%208%204v-12l3-2%201-4h-2c3-9%203-9%207-9'/%3e%3cpath%20fill='%23e4d01e'%20d='m197%20557%203%201q9%204%2015%2013l1%205h-90q2-10%2011-16c16-9%2043-11%2060-3'/%3e%3cpath%20fill='%23bec44d'%20d='m155%20213%202%204%204-1%202%2010h2l2%205h-2l-11%206q-7%206-16%208h-4l-6%202-15%204-22%207-6-1v-16l18-3%207-5h9l1-3q2-7%208-11l14-3%207-2h4z'/%3e%3cpath%20fill='%239eab34'%20d='m0%20276%204%203%203%201%206%207%203%202v-8l8-1v2h3l1%202%202-1-2%205h2l1-3%203%201v2c-5%204-5%204-8%204l1%203-1%201%2016%201q-10%206-21%205l-3-2-1%205-1%203v4l2-2c5-5%205-5%208-5h6l-2%202-6%206c-7%208-7%208-12%208l-6-2-3-2-4-4v-10l1-8z'/%3e%3cpath%20fill='%23e4d01e'%20d='M204%20175q2%203%201%206v10l-1%2036h-19v-30q0-11%207-18%205-5%2012-4'/%3e%3cpath%20fill='%23bec44d'%20d='M239%20156h19v2l3-1%2016-1-1%202-3%208-1%202q-2%208-2%2017l-1%206-4%202-6-3h-3v-9l-2-1v-3q0-5-4-9v-2l-9-1-1-4-2%203-2-1v-3l2-1z'/%3e%3cpath%20fill='%23a0c237'%20d='M44%20312h2l4%206%201%202q7%2011%2010%2023l1-2q6-8%2014-14h2l-7%2010-8%2011%202-1%203-2%203-1%202-1%202%201-6%205-1%201q-4%203-8%203-8-3-12-10l-16-13-2-2-6-4%201-2q17%203%2027%2017l-1-2-3-10-1-4-1-3-1-3z'/%3e%3cpath%20fill='%234b632f'%20d='m220%20383%203%203%201%203v2l1%207%206-2%201-2%202%201v6l-6%204v3h-2l-1%2014h-4l-4-7-2-4-1-2-3-4-1-1%202-9%202%201%205-1z'/%3e%3cpath%20fill='%239eab34'%20d='M111%20352h1l1%207%201%203v9l5-1-2%207%201-2%202-2%201-2%205-3q-1%208-7%2014l10-2v2l-18%205-5-6-2-2-7-8-2-5%208%205%201%202%204%203-2-3-2-4-1-2-2-5%201-2c6%207%206%207%206%2012h2v-2z'/%3e%3cpath%20fill='%23769e30'%20d='M57%20386h2c7%2021%207%2021%204%2030q-3%206-6%206l-7-5-10-8h5l2%201-1-1-2-2-1-2-1-2%201-2q8%206%2012%2014l2%201-1-3-2-3-1-4v-6l2%201-1-2-2-3-1-3-1-3%201-2q4%204%204%2010h2z'/%3e%3cpath%20fill='%239eab34'%20d='M185%20188h1l-1%2039-10%202v-26l-2-1h7v-3q1-5%204-7z'/%3e%3cpath%20fill='%23445a2c'%20d='M239%20379h1l4%2020%204-13h2l-2%2020%204-8h2q-2%2011-9%2019h-5q-4-8-3-18v-3q-1-8%202-17'/%3e%3cpath%20fill='%23bec44d'%20d='m266%20357%205%203q7%205%2016%202l6-1%202%204q-6%203-12%201h-5l-3%201h-6q-8%202-16-1v4l-2-1%201-2h-6v-8q10-3%2020-2'/%3e%3cpath%20fill='%23445a2c'%20d='M57%20299c8%203%208%203%2010%206h-2l-1%207-1%202-2%2010%202%2014-1%205-2%201-1-4-2-5-1-2v-3l-1-2-2-4v-10l1-3z'/%3e%3cpath%20fill='%23b2c56c'%20d='m177%20132%205%201h3l2%201%201%202%205%201h4l-1%202h-4v2l7%202-1%204%203-1-2%204h-5v2l-5-1v2h-2l-1-2-3%207h-3l3-10h-3l-3-5-4-2v-2l8%201-4-4%2010%203v-2h-3l-7-3z'/%3e%3cpath%20fill='%23769e30'%20d='m37%20341%203%203v2l1%202v2h2l1-3%201%202-2%203v7l2-2%203-1%203%201-3%204-2%203-3%203-8-1q-7-6-12-14v-5l9%206-1-9q6%203%208%209z'/%3e%3cpath%20fill='%23e4d01e'%20d='m172%20203-1%2027h-5l-1-4h-2l-2-10-4%201v-7q1-4%205-6z'/%3e%3cpath%20fill='%232b3627'%20d='M0%20283q6%202%2010%206l2%201%204%204-1%204-2%208v2l-1%205h-2l-3-6-4-5q-4-6-3-14z'/%3e%3cpath%20fill='%234b7148'%20d='M159%20131v3h2l2%201%201%202%202-1%202%205-5-2v2l2%201-1%205-8%201%205%203-2%202-5-1-2-5h-2v-3l-3-1-1-6%202-1-3-1%204-1h2v-2z'/%3e%3cpath%20fill='%23769e30'%20d='m78%20370%206%209%201%203%201%202%201-2%202-3%201-3q2-3%205-4l-3%206-1%202-1%202-1%206%204-1-1%201q-5%206-8%2013h-2l-8-23q6%203%208%208l-1-2v-3l-1-3z'/%3e%3cpath%20fill='%23628c36'%20d='m12%20371-2%207h3l1-2%202%202%202-1c8-4%208-4%2012-3l-5%203c-10%202-15%2011-21%2019l-4-2v-12l3%203%201-2z'/%3e%3cpath%20fill='%234b632f'%20d='M272%20373h2l1%203v4l1%204%202%204%206-10%202%201c-4%2013-4%2013-8%2016l-6%201q-8-6-11-15l1-2%203%203%202%202%205%206z'/%3e%3cpath%20fill='%23bec44d'%20d='M259%20206h1l1%2012h-3l2%201q2%204%201%209l-4-5-3%201h-6l-2-2%202-1v-2l-3-1%202-1%202-1v-2l3-4%205-2%202%201z'/%3e%3cpath%20fill='%234b7148'%20d='M312%20379h2l1%2012-2%2014-4-1q-6-9-7-19h3l2%204%203%205v-4z'/%3e%3cpath%20fill='%23628c36'%20d='M127%20348q5%201%208%204l-2%202-12%2015-1%202h-4l5-13%201-2zM27%20382v2l-4%202-2%201-2%201%207%201v2l-4%202-2%201-2%201-3%201q-4%203-10%203%202-7%208-11%206-5%2014-6m30-83%202%201-1%203v5l-1%202c-2%2011-2%2011%200%2015l3-4%202%2010v3l1%202v3l-1%204-2%201-1-4-2-5-1-2v-3l-1-2-2-4v-10l1-3z'/%3e%3cpath%20fill='%23e4d01e'%20d='M209%20172h1v55h-3v-41l1-4v-7z'/%3e%3cpath%20fill='%23bec44d'%20d='m311%20358%209%203v13l-2-4-7-2-3%203-1-4h-2l1-3h2z'/%3e%3cpath%20fill='%232b3627'%20d='M0%20270q6%201%209%206l5%2010-4-11h3q5%207%204%2015l-7-5-6-6-4-3z'/%3e%3cpath%20fill='%234b632f'%20d='M0%20256q11%2014%2015%2031l-6-8-1-2-1-4-3-1-4-2z'/%3e%3cpath%20fill='%23bec44d'%20d='m167%20202%208%201v26h-4v-25z'/%3e%3cpath%20fill='%2330605c'%20d='m134%20138%206%202v5l7-1v2q-10%204-22%204v-5q3-2%208-2z'/%3e%3cpath%20fill='%23628c36'%20d='M94%20542q-1%205-5%2010l-12%2016%203-1%204-2%202-1c5-2%205-2%208-1l-3%201-4%202-2%201-9%205q-3%201-5%204l-4-1%203-4h2l2-4z'/%3e%3cpath%20fill='%23769e30'%20d='m87%20334%205%206%202-3h2l-1%205%205-5%202%201-1%201q-7%206-9%2013h-3z'/%3e%3cpath%20fill='%234b632f'%20d='M249%20229h3l2%207%202-3h2l-1%208-2%202q-6-1-8-7l-2-3-1-2%202-1%203%201z'/%3e%3cpath%20fill='%234b7148'%20d='M29%20235h1c1%2025%201%2025-4%2030l-1%201-2-12v-6l-1-3%201-7%204%2013z'/%3e%3cpath%20fill='%23bec44d'%20d='m230%20162%204%201%201%202h-2v2l4%201v2l-4%201-3%201-5-1v-8l4%201z'/%3e%3cpath%20fill='%23628c36'%20d='M65%20523v10l-1%203-8%2040h-1c1-16%203-38%2010-53m146-163c4%205%204%205%204%208h5l3-5h2l-3%209-1%202-1%202q-5-1-7-7l-1-2z'/%3e%3cpath%20fill='%232b3627'%20d='m130%20348%203%202q-1%205-6%209l-2%202-6%206c6-15%206-15%2011-19'/%3e%3cpath%20fill='%23628c36'%20d='m270%20306%203%201%202%206%204-2q0%205-4%209l-3-1q-2-6-2-13'/%3e%3cpath%20fill='%2330605c'%20d='m282%20108%202%201v4l3-1%202%203h3l2-3%202%205-1%202-5%201h-4l1-3-5-1zm-6%201-1%202%206%201-2%208-4%201-2-1v-2l3-1%201-2-3-1-6-4z'/%3e%3cpath%20fill='%23b2c56c'%20d='M215%20117h2l-1%205h-2z'/%3e%3cpath%20fill='%234b7148'%20d='m88%20156%202%203-1%202-2-1z'/%3e%3cpath%20fill='%23b2c56c'%20d='m283%20138%204%201-5%202z'/%3e%3cpath%20fill='%2330605c'%20d='M305%20119h3l-1%203h-2zm-100%200v2l-4%201v-2z'/%3e%3cpath%20fill='%234b7148'%20d='M91%20143h3v2l-4-1z'/%3e%3cpath%20fill='%2330605c'%20d='m46%20141%204%201-4%201z'/%3e%3cpath%20fill='%234b7148'%20d='m290%20121%202%201-2%203-2-1zm-31%204%203%201-4%202z'/%3e%3cpath%20fill='%2330605c'%20d='M143%20148h2l-1%203z'/%3e%3cpath%20fill='%23b2c56c'%20d='m148%20135%203%202-4-1z'/%3e%3cpath%20fill='%234b7148'%20d='M40%20145h2v2h-2z'/%3e%3cpath%20fill='%2330605c'%20d='m137%20136%202%202-3-1z'/%3e%3cpath%20fill='%234b7148'%20d='M294%20127h2v2h-2z'/%3e%3cpath%20fill='%2330605c'%20d='M258%20111h2v2h-2zm-22-9%202%201h-3z'/%3e%3cpath%20fill='%234b7148'%20d='m262%2082%202%202-3-1z'/%3e%3cpath%20fill='%23b2c56c'%20d='M187%20128h2l-1%202z'/%3e%3cpath%20fill='%234b7148'%20d='m272%20127%201%202-2-1z'/%3e%3cpath%20fill='%2330605c'%20d='m218%20102%202%201-2%201z'/%3e%3cpath%20fill='%239eab34'%20d='m40%20297%202%201Z'/%3e%3cpath%20fill='%234b7148'%20d='m34%20161%202%201Z'/%3e%3cpath%20fill='%2330605c'%20d='m97%20143%202%201Z'/%3e%3cpath%20fill='%234b7148'%20d='m260%20129%202%201Zm9-7%202%201Z'/%3e%3cpath%20fill='%2330605c'%20d='m250%20115%202%201Zm-49-1%202%201Z'/%3e%3c/svg%3e",
	tree: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='576'%3e%3cpath%20fill='%23e8cbd6'%20d='M0%200h320v576H0z'/%3e%3cpath%20fill='%232c3068'%20d='M269%20358h3l4%2015v2h2l2%204%201%202%201%204%202-2%204-4v2h3l9%203%201-1c5-8%205-8%2010-10h9v203H0v-72l17-4%201-1h5q6-1%2011-5h5l-1-7%203-1%206-2%2011-2%2010-2%205%201q6%201%2012-2l6-2-2-4-5-1v-2h7q3%200%205-3l4-1%203-1%201-6%202%201%207%201h8l5-1h7q11-1%2019-6l5-2v-2a156%20156%200%200%201%2036-2h3l9-2%203-7%202-2h6q8%200%2014-4l1-7-2-1v-2l7-1h2l14-2%205-2-3-5h-6l-3%205-6%201-1-5q-10%200-20%203l1%203%201%204-5%202h-2l-6%201q-7%200-14%205h-2v4l-2%201-17%208-9%201h-6l-1-3h-6v-2c-8%203-8%203-11%206v9q-9%203-20%202l-3-2%204-8%201%202q5%201%209-2h4l-2-6h-24l-1-5%202-1%201-2-2-7%2016-3v-2l12-7%202-1%205-3%208-1h2l8%201v2l3-2h6v-2l3-1-10-2q2-5%207-7c14-7%2014-7%2019-13l2-3%206%201-2%203q7-3%2010-11l1%202h8l1%201v-2q4-6%2011-10l9-2q4-2%206-5%207-3%2015-1l6-1z'/%3e%3cpath%20fill='%23f08cc3'%20d='M245%200h75v235h-5l1-6h-2l-1%202-2%201-5-1c-3%205-3%205-3%208h9v4h-2l1%205q-7%203-15%202-2-5%201-8-4%202-7%206h-2v2l-6%201-3-4-7-1-1-4%201-8-1-2-5%201%201%203%202%201v2l-11%201-3-4%201-4%201-5q2-9%206-16l-3-3-1%202-1%202h-5l-2-7-1-2v-2h6l1-3%204%201q1-7-2-15-5-3-12-4v6l-4%202-3-2h-3l-4-4v-8h2v-4h-5v-2l-2%201-2%202-2%202-4%201v6h7v2l1%202%205%201v12l4-2%205%201%201%207h-8l-2%201-1-6h-6l-1%205h2l7%205-2%202q-4%203-3%206v2l-4%201v4l-5%201%202%202%202%203-1%203q-6-1-10-6h3l-1-3%209-6-1-1-5-8-1-2h-3v5l-1%203q0%205-4%209l-1-1-4-2q-5%207-4%2015v4l1%203%205%202%2010%208%202%202%206%202q5%201%208%206l16%2012%202%202v2c-9-1-12-5-18-11l-1-2%202%206q-6-1-10-6l-2-3-2-4h-2l-5-5-7-5%2012%2012%2010%209%204%204-2%201-14-12-8-6%2019%2018v2l4%202%203%202q7%205%2016%207v2l3%201%201%206%202%203v7h-2q1%2013%205%2026v6l-6%201c-13-1-13-1-18%202l-6%206-6%203-7-22%203-3v-7l2-5-7%204-1-3c-8-18-8-18-13-21l1-3h2l-2-5-1-3-3-4-1-7-3-1q-3%200-5%202v7l-4%201-5-3%201-3v-3l-1-1v-3l-5-10-1-3q-11-2-22%204l-6%205-4%201-2%203-6%201%201%203-1%205q-2%202-5%202l-3-1v6l-5-1%201-4-3%201-5-1-1-4h2v-2h-7l-1-3h-4q-6%200-10-3-2-3-2-7l1-2%201-3q2-3%206-5h18v-2h-2l-4-4%201-5-12%201-8-1-1%202h-6l-2%201-4-2-2-2%201-4%201-2%201-3v-2l1-2h3v-5l3-1%204-2h6l3%204%205-1q9%200%2016%202v2l4%201v2l-7%201%201%206%203-1%206%201v-2h6l-1-4-2-1-3-1-1-5h-3l-3-1-1-3-3-2%203-6h3l-1-3q4-2%207-1h7l2%203%205%202%202%201-5-7q-11-9-15-22v-5l-3-7-7-4q-3-2-4-5l-1-3h4l-1%204%206-1v-4l8%201%205%202%204%201h4q0%204-3%207-2%204-1%209%203%207%208%2011l5%201%203%201h2v-6q4-2%209-2v2h3v-2l6%201v-5l4-1v-2l-1-9v-3l2-4q0-6-5-11-6-5-15-6c-9-2-18-11-23-18v-4h-2v-2c-1-7-1-7-4-10l-4-2-2-1v-2l-6-2v-2l-2-1-11-7-2-2-13-11-4-1-2%202q-2%204-5%204l-3%205-6%202-2-1v2l-1%205-4%201-6-4v-5h-7l-4-1-1-6q1-5-2-9l3-4h7l2-4q5%202%207%207%204%203%2010%202l2-2%202-1%206%203h3l1-2q5%202%208%206l12%208%203%202%208%205%209%205%205%203q9%205%2013%2017l2%203v3h-4v2l2%201%207%203q10%205%2022%206%208%200%2013%206l6%2011%202%205%201%201h4l4-5%202-4%201-2-1-1-6%204%202-17%202-11-3%201-9%201-2-3h-4l-1%204-6%201-1-7-2%201-5%201v-9l-2-1-4-4%201-3-2-1-3-3%201-3-3-1c2-7%202-7%205-9l6%201%205-1%202-3%202-2q5-5%207-12l-2-3q0-6%202-10%205-2%209-1l5%204%208-5%204-5%203-2%2013-13%2010-9%205-4%203-3%202%202v-5l1-3z'/%3e%3cpath%20fill='%23f08cc3'%20d='M0%200h245c0%2017%200%2017-2%2023l-2-4-2%202-4%203-2%202-21%2020c-11%2011-11%2011-17%2014l-2-2q-5-3-12-2v13l1%202-8%2011-3%203-5%203-3-1h-4c-4%205-4%205-4%208l2%201v2q1%203%204%205v2l1%203%202%201%202%204v7l7-2%201%206h6v-2l1-2%204-1%202%203h6l2-1%205-1-1%209-1%203v2l-1%202-1%203v9l7-5q-1%206-5%2011l-2%203-2%202q-4-1-6-6l-2-2-5-10q-3-5-7-6h-8q-15-2-28-11v-2h4l-3-6-2-4q-3-9-13-13l-12-8-13-8-3-2-14-11-1%203-10-3-1%202-5%201q-5%200-9-4l-2-4-3-1-2%203h-3l-4%201q-2%202-2%205l2%204v7q2%202%207%203h4l1%203q1%203%204%205l4-1%201-3%201-3%207-1%204-6%205-3%202-3q5%202%208%206l2%201%203%204-9-1%202%203v6l-1%202h6l1%204h-7l-1%205h-3l-5%201-2%201-3-2h-3l-1%205h-4l-1-2-4-1v-4l-6-1q-7%205-12%2012l-1%201h-2l-2%204%203%202-2%203h3q6%200%2011%203l-2%205h-2l1%207%2011%201%201-3q4%200%206%203l5%2010%206%207h13l3%201h2q2-1%204%203l4%201h4l-1%204-15%203-7%201q-6%201-12-2l-4-5-1%202h-2l-1%202-1%203-5%201-5-9c-3-5-3-5-3-8l-7-2v17l2%201v2l4%202%201%204-9-1%202%204%203-1q3-1%205%202l2%206-5%207-3-1v3h15v5h-6l-2-1v3h4l2%203h3l2-3h2l-1%207-5%202-5%205-5%203-4%202-3%202q-4-2-6-7-1-4%203-6l2-2%201-4h-2l-1%202-6%201-7-6-1-7%205-1%201%206h10l2-6-9-4-1%203-3-1-1-5%208-2-2-2-2-6h-3l-2-4-3%201c-6-6-6-6-6-10v4l-1%204-5%203-1-3-2-4-7-1-1%203-2%202H0z'/%3e%3cpath%20fill='%23383c7b'%20d='M51%2063q5%202%207%207%204%203%2010%202l2-2%202-1%206%203h3l1-2q5%202%208%206l6%204%203%202%203%202%203%202%208%205%209%205%205%203q9%205%2013%2017l2%203v3h-4v2l2%201%207%203q10%205%2022%206%208%200%2013%206l6%2011%202%205%201%201h4l4-5%202-4%201-2-1-1-6%204v-7l2-10%202-8%201-3%201-5h2l1%206%202-3%206%201-2%208%202-3%202-3h3c0%2017%200%2017-3%2025l-5%2019q12-2%2022-9%208-4%2016-2l6-2h3q6-1%2010-5%208-6%2018-10l5-3h9q-4%2010-15%2014c-8%204-8%204-11%208l1%205c-5%203-5%203-8%203v2l-9%202-9%201-5-1-7-1-3%201-8%204-4%201v6h7v2l1%202%205%201v12l4-2%205%201%201%207h-8l-2%201-1-6h-6l-1%205h2l7%205-2%202q-4%203-3%206v2l-4%201v4l-5%201%202%202%202%203-1%203q-6-1-10-6h3l-1-3%209-6-1-1-5-8-1-2h-3v5l-1%203q0%205-4%209l-1-1-4-2q-5%207-4%2015v4l1%203%205%202%2010%208%202%202%206%202q5%202%208%206l16%2012%202%202v2c-9-1-12-5-18-11l-1-2%202%206q-6-1-10-6l-2-3-2-4h-2l-5-5-7-5%2012%2012%2010%209%204%204-2%201-14-12-8-6%2019%2018v2l4%202%203%202q7%205%2016%207v2l3%201%201%206%202%203v7h-2q1%2013%205%2026v6l-6%201c-13-1-13-1-18%202l-6%206-6%203-7-22%203-3v-7l2-5-7%204-1-3c-8-18-8-18-13-21l1-3h2l-2-5-1-3-3-4-1-7-3-1q-3%200-5%202v7l-4%201-5-3%201-3v-3l-1-1v-3l-5-10-1-3q-11-2-22%204l-6%205-4%201-2%203-6%201%201%203-1%205q-2%202-5%202l-3-1v6l-5-1%201-4-3%201-5-1-1-4h2v-2h-7l-1-3h-4q-6%200-10-3-2-3-2-7l1-2%201-3q2-3%206-5h18v-2h-2l-4-4%201-5-12%201-8-1-1%202h-6l-2%201-4-2-2-2%201-4%201-2%201-3v-2l1-2h3v-5l3-1%204-2h6l3%204%205-1q9%200%2016%202v2l4%201v2l-7%201%201%206%203-1%206%201v-2h6l-1-4-2-1-3-1-1-5h-3l-3-1-1-3-3-2%203-6h3l-1-3q4-2%207-1h7l2%203%205%202%202%201-5-7q-11-9-15-22v-5l-3-7-7-4q-3-2-4-5l-1-3h4l-1%204%206-1v-4l8%201%205%202%204%201h4q0%204-3%207-2%204-1%209%203%207%208%2011l5%201%203%201h2v-6q4-2%209-2v2h3v-2l6%201v-5l4-1v-2l-1-9v-3l2-4q0-6-5-11-6-5-15-6c-9-2-18-11-23-18v-4h-2v-2c-1-7-1-7-4-10l-4-2-2-1v-2l-6-2v-2l-2-1-11-7-2-2-13-11-4-1-2%202q-2%204-5%204l-3%205-6%202-2-1v2l-1%205-4%201-6-4v-5h-7l-4-1-1-6q1-5-2-9l3-4h7z'/%3e%3cpath%20fill='%23faccbe'%20d='M86%2085q12%200%2020%208l6%204%202%201v2l6%202v2l3%201q4%201%206%204l1%205v5h2l1%203q4%207%2010%2011l2%202q7%205%2015%206%208%202%2013%208l1%202%202%203-2%206%201%2017h-4l-1%205-6-1v2h-3v-2l-8%202-1%206c-10%200-10%200-13-3q-6-5-6-14%201-5%204-9l1-3h-4q-4%201-9-2l-5-1-3-1v4l-6%201%201-4h-4q2%206%208%209l2%201q3%201%205%205v8l-7%203q-8%202-13%208l-5%201h-3l1%202%201%202-3%204h-2v2q-3%204-6%203l-1%202-5%208-3%202-23%2022-27%2027-7%207-6%206-4%204-3%203-2%202-3%204H0V181c0-9%200-9%203-13q5-2%209%201l3%206q4-2%203-4l1-2v-4l2-1%204%209h5l1%205h3l4%208-7%202%201%205h2l1-2%209%204-2%206H32l-1-5h-5q1%206%205%2010%204%202%209%202l1-3%203%201q0%204-4%206l-2%206%203%205%203%201%206-4%203-1%205-5q2-3%207-3l-1-3%202-4-2%202-4%202-3-4h-4v-3l7%201%201-5H46v-3h3l4-5q0-5-3-8l-3%201h-3l-2-2v-3h7l2%201-5-6v-2l-3-1v-17l8%202%203%206%205%208v3q6%200%206-4l1-2h2v-5l3%205q7%205%2013%204l23-4%201-3h-8l-1-2-1-2H85c-6%201-6%201-10-2l-8-13-3-5h-3l-1%202-4%201h-3l-5-2-1-5%204-5v-2l-13-3%201-3-3-2%202-2%205-5%201-2h2l1-3%207-6%206%201%201%202-1%203%205%201v2h4v-5l4-1%202%201h5l2-1h4l1-4h6v-3l-6-1%201-3z'/%3e%3cpath%20fill='%23383c7b'%20d='m309%20498%205%201%205%201%201-2v78H157l-2-6-4-1%201-2q2-11-3-22l-2-5v-2l-1-4h-3l-1%204-6-2%201%208q1%207-2%2014l-2%203h-9l-2-1h-6l4-9-6%201h-4l-8%205-1%203q0%204-4%204-4%202-10%200l-7%201-7%202-2%201-1%204-3-1-1%201h-8l-6%202-1-1h-9l-8%201v-2l43-17%203-1%203-1q5-2%207-7l5-8c5-9%205-9%2011-11h10l8%201%2021%201c31%202%2031%202%2039-5l8-10q5-5%2012-7l19-2%2020-1c6%2014%206%2014%206%2019l-7%206h-2v2h-2l-3%2025%2012-3%204-1%201-2%205-7%203-2%204-4%203-4-4-1v-4l-1-3%204-4q7-3%2016-2c11%200%2011%200%2017-3l11-4-1-3q-2-4-2-9zm-54%2050-2%204-9%203-3%202-2%201-5%202-1%204%2029-2%204-10%201-3v-10c-5%200-9%206-12%209'/%3e%3cpath%20fill='%23fa99a5'%20d='m317%2063%203%201v171h-5l1-6h-2l-1%202-2%201-5-1c-3%205-3%205-3%208h9v4h-2l1%205q-7%203-15%202-2-5%201-8-4%202-7%206h-2v2l-6%201-3-4-7-1-1-4%201-8-1-2-5%201%201%203%202%201v2l-11%201-3-4%201-4%201-5q2-9%206-16l-3-3-1%202-1%202h-5l-2-7-1-2v-2h6l1-3%204%201q1-7-2-15-5-3-12-4v6l-4%202-3-2h-3l-4-4v-8h2v-4h-5v-1l7-2%205%201%207%201%203-1h6l7-1v-2l7-3-1-2%201-5%2013-8q8-4%2013-12h-7l-6%204-6%202q-9%204-16%2010-5%203-10%203l-2%201h-7q-8%200-16%205t-19%206c3-21%203-21%206-24l1-7%202-11%207%202h7l6-7%205%204v7l6%202%204-3%201%202%202%201%201%202q2%203%206%203%204-2%205-6l1-8%2014-1v-2h2l2-4%206-4q3-6%203-13l3-1%202-4%203-2v-9q-1-6%202-11l7-5z'/%3e%3cpath%20fill='%23eea7bc'%20d='m0%20374%208%206%203%2012%2016%209%2015%207%203%202q12%206%2016%2019l10%2019v5l-6%201q-7%201-13%206l-3%205%206-3%203-1%205-4%2011-4q6-1%2012-5l3-1q6-2%208-8l7-7%202-2%201-1%203%201%201%204-3%203v5h2l10-1h12q3%203%202%207-6%203-13%203h-2l-3%205q12%202%2023%200l-1-3q0-5%203-9%204-3%209-3v2l7-1v3q13%202%2022-4%206-4%2012-5v-4c7-7%2019-7%2028-8l-1-7q10-4%2020-3l1%204h6l1-2%202-4h6l4%204-2%204q-6%203-13%202l-6%201h-8v2l3%201c0%206%200%206-2%209l-16%203h-4l-3%206q-2%204-5%204l-9%201h-7l-29%201v2c-12%2010-28%2010-43%2010h-3q-4%200-7-3l1%202v3q-4%204-10%205l-2%202h-5l-2-1h-2v2l7%202v3q-8%206-17%206l-2-1h-7l-11%202-9%202-6%201v7l-3%201-5%203-8%202-6%201-5%201-2%201-10%201z'/%3e%3cpath%20fill='%23fbe9d4'%20d='M230%20168v2h5v4h-2v4l2%207h2l8%202%202-7%205%201%208%203%201%205%201%202-1%208h-4l-1%202h-5v2l1%202%201%202v4h5l2-3%203%201%201%204-1%201q-4%206-4%2013l-2%204v7l8%201h4v-2l-4-2%201-3%205-1%202%203-1%204v7h3q6%201%207%205h6v-2l3-3%202-2%204-1-1%207%2015-1-1-5h2v-4l-3%201-4%201-3-2%204-9%207%201%201-3%203%201-2%206h5v138l-11%202-7%208-2%202-9-2v-2h-3v-2l1-3v-2q0-4-3-7l-1-7-1-4%201-5%207-1-1-4-6%201%201-3q1-9-5-16-8-19-10-39l-1-3v-4l-3-8h-8v-4l-2%202-4%202-4-5q-8-11-20-19-7-4-11-10l-6-6-1-4h2v-3l10%204-1-2-2-5%205-1v-4l3-1v-2q0-5%205-8l-8-5v-5l4-1h3l2%206%202-1h4l2%201-1-7-8%201-1-12-4-1-1-3-7-1v-6q4-5%2010-6'/%3e%3cpath%20fill='%232e3772'%20d='M269%20358h3l4%2015v2h2l2%204%201%202%201%204%202-2%204-4v2h3l9%203%201-1c5-8%205-8%2010-10h9v90l-11%202-5%203v-10h-2l-1%202-3%206q-6%207-8%2015l-1%202h-3l1-8-3%205-3-1%204-9%201-7-9%2011q-1-4%201-9l2-3%201-2-6%209q-1-6%202-10l2-3%202-4-4-1-1%202-4%206h-3l-1-2-9%204-1%202h-2l-2%205h-1c0-14%200-14%204-19l8-4v3l1-3%206-15%201-9-4-5-2-4%201-3q0-8-7-13-5-7-14-7-15%201-25%2011l-6%205-3%202-16%208-4%201-11%201-22%206-10%203h-6l12-5-22%204-21%207v-4l-3-1%205-1%202-1%207-1v-2l12-7%202-1%205-3%208-1h2l8%201v2l3-2h6v-2l3-1-10-2q2-5%207-7c14-7%2014-7%2019-13l2-3%206%201-2%203q7-3%2010-11l1%202h8l1%201v-2q4-6%2011-10l9-2q4-2%206-5%207-3%2015-1l6-1z'/%3e%3cpath%20fill='%23fbb2b6'%20d='M86%2085q12%200%2020%208l6%204%202%201v2l6%202v2l3%201q4%201%206%204l1%205v5h2l1%203q4%207%2010%2011l2%202q7%205%2015%206%208%202%2013%208l1%202%202%203-2%206%201%2017h-4l-1%205-6-1v2h-3v-2l-8%202-1%206c-10%200-10%200-13-3q-6-5-6-14%201-5%204-9l1-3h-4q-4%201-9-2l-5-1-3-1v4l-6%201%201-4h-4q2%206%208%209l2%201%205%205-1%204-1-2q-5-6-13-7h-3l3-5h-8l-1-2-1-2H85c-6%201-6%201-10-2l-8-13-3-5h-3l-1%202-4%201h-3l-5-2-1-5%204-5v-2l-13-3%201-3-3-2%202-2%205-5%201-2h2l1-3%207-6%206%201%201%202-1%203%205%201v2h4v-5l4-1%202%201h5l2-1h4l1-4h6v-3l-6-1%201-3z'/%3e%3cpath%20fill='%23eea7bc'%20d='M181%200h64l-2%2023-2-4-2%202-4%203-2%202-21%2020c-11%2011-11%2011-17%2014l-2-2q-5-3-12-2v13l1%202-8%2011-3%203-5%203-3-1h-4c-4%205-4%205-4%208l2%201v2q1%203%204%205v2l1%203%202%201%202%204v7l7-2%201%206h6v-2l1-2%204-1%202%203h5l3-1%205-1-1%209-1%203v2l-1%202-1%203v9l7-5q-1%206-5%2011l-2%203-2%202q-4-2-6-6l-2-2-1-3-3-5-1-2q-3-4-7-6h-8q-15-2-28-11v-2h4l-3-6-2-4q-3-8-11-12l-6-4%205%201v-4l6-1%206-2q6-4%2013-3l-1-4-4%201-6-1q0-8%206-12l2-7c6%201%206%201%208%203l3-3%203%203-1-4%203-1-2-7%201-4v-4l4-3-3-3-2-5h2v-2q-5%201-8%205l-1%204-6%201v-2l-12-4%202-1-1-5%207%202%202-1h6l2-1h7q3%200%205-3h6l2%205%207-2v-5l-1-2-7%201v-7l-3%201h-9l-1-4%201-6%202-1%202-2%204-3q4-5%2012-4'/%3e%3cpath%20fill='%23f5d6ca'%20d='M57%20267q7%203%2011%209l7%207%2019%2018%2010%209%202%202c13%2012%2013%2012%2015%2018v3l2%204%203%202%201%203-6-3%206%205-2%205-5%202-3%201c-10%201-15-3-23-9l-7-5-10-8v-2l-2-1-4-2q-10-1-18%207l-19%2017-3%203-3%204q-7%209-19%2012H0l-1-35v-3l1-8%207-5%2011-8v-2q2-4%206-7l1-2%205-4%206-6%202-2%2010-10%205-6%203-2z'/%3e%3cpath%20fill='%23fa99a5'%20d='m214%20205%204%201%204%206%202%203-1%203q-4%202-7%206v2h-3v4h-2l4%205%203%203%202%203%202%203%2010%208%2015%2013%202%202%204%207%202-2%204-2v4l4-1h4q4%204%204%209l4%2024%208%2024c5%2010%205%2010%203%2016l4-2%203%203-1%204h-2q-3-1-5%202l1%207v4l3%206%201%205-2%203-1%203q-1%203-5%204l-1-2-1-2-1-2-1-2h-2l-4-18h-2l-2%202v-3h-2q-8%203-17%201l-8%201-1%203-9%204q-7%201-11%207l-4%201-1%205-1-2-2%201q-3%201-7-2l-1%202-1%202-6%207-3-1%202-2-5-2%201-9%204-1%201-5%204-5-2-2v-3h5l2%201v-7l3-3%202-1-1-7h-2l1-2c4-11%204-11%202-15l-3-5q-2-3-2-8-1-9-7-15l-4-5c-6-10-6-10-9-11h-2l3-1-1-3%201-6%207-1q3%202%202%205l4%208%202%208-3%203%202%201c7%204%2010%2015%2013%2022l2-1%204-2-2%2013-2%201q1%207%204%2013l3%209%205-4%203-2%204-4%206-1h13l4-1-1-7-1-3-2-7-1-9v-5h2l-1-4v-3l-2-4-1-5-2-1v-2h-5v-2h-3q-12-3-20-14l-3-3-2-1-9-11%208%205%202%202%204%204%202%202%202%202%204%201-4-4-4-3-8-8-2-1-4-4-2-4%2010%207%202%201v2h2l3%204%2010%208-2-2%201-4%203%203%202%202%205%205q4%204%209%204l-12-11-7-6q-5-4-11-5l-9-7-4-3-2-2-4-2q-4-9%200-18l3-5%206%202%203-10z'/%3e%3cpath%20fill='%23f6cbd5'%20d='m243%20504%205%2012%201%202v5q-5%206-14%208h-8l-4-7-3%206-2%203-3%201-2%205-7%203h-2l-5-1-1%202-1%203-1%203-3%205-7%201h-3l-10-1-1%202-2%203-1%203-4%204h-2l-4%203-1%207-3-6-4-1%201-2q2-11-3-22l-2-5v-2l-1-4h-3l-1%204-6-2%201%208q1%207-2%2014l-2%203h-9l-2-1h-6l4-9-6%201h-4l-8%205-1%203q0%204-4%204-4%202-10%200l-7%201-7%202-2%201-1%204-3-1-1%201h-8l-6%202-1-1h-9l-8%201v-2l43-17%203-1%203-1q5-2%207-7l5-8c5-9%205-9%2011-11h10l8%201%2021%201c31%202%2031%202%2039-5l8-10q5-5%2012-7l19-2z'/%3e%3cpath%20fill='%23fa99a5'%20d='m11%20103%202%201-1%202-2%204%202%201q4%201%206%205l3%201-2%208%204%201%203-3%209-3%202-4%202%201-2%202%203%202-2%203h3q6%200%2011%203l-2%205h-2l1%207%2011%201%201-3q4%200%206%203l5%2010%206%207h13l3%201h2q2-1%204%203l4%201h4l-1%204-15%203-7%201q-6%201-12-2l-4-5-1%202h-2l-1%202-1%203-5%201-5-9c-3-5-3-5-3-8l-7-2v17l2%201v2l2%201%202%201%201%204-9-1%202%204%203-1q3-1%205%202l2%206-5%207-3-1v3h15v5h-6l-2-1v3h4l2%203h3l2-3h2l-1%207-5%202-5%205-5%203-4%202-3%202q-4-2-6-7-1-4%203-6l2-2%201-4h-2l-1%202-6%201-7-6-1-7%205-1%201%206h10l2-6-9-4-1%203-3-1-1-5%208-2-2-2-2-6h-3l-2-4-3%201c-6-6-6-6-6-10v4l-1%204-5%203-1-3-2-4-7-1-1%203-2%202H0v-60l5-2%203-4%202-2z'/%3e%3cpath%20fill='%23f67ba7'%20d='m317%2063%203%201v71h-2l-3%204-20%2020-3%203-4%205-3%201q-5%203-8%208-2%204-7%205h-2l-1%202h-3v-4l-2-9-1-2%204-1v-2l7-3-1-2%201-5%2013-8q8-4%2013-12h-7l-6%204-6%202q-9%204-16%2010-5%203-10%203l-2%201h-7q-8%200-16%205t-19%206c3-21%203-21%206-24l1-7%202-11%207%202h7l6-7%205%204v7l6%202%204-3%201%202%202%201%201%202q2%203%206%203%204-2%205-6l1-8%2014-1v-2h2l2-4%206-4q3-6%203-13l3-1%202-4%203-2v-9q-1-6%202-11l7-5z'/%3e%3cpath%20fill='%23d6abc5'%20d='M251%20412q3%200%205%202l2%202-2%204q-6%203-13%202l-6%201h-8v2l3%201c0%206%200%206-2%209l-16%203h-4l-3%205q-2%205-5%205l-9%201h-7l-29%201v2c-12%2010-28%2010-43%2010h-3q-4%200-7-3l1%202v3q-4%204-10%205l-2%202h-5l-2-1h-2v2h2q3-1%205%202v3q-8%206-17%206l-2-1h-7q-9%202-18%200l-3-5-3-1q5-12%2018-16l4-3%2011-4q6-1%2012-5l3-1q6-2%208-8l7-7%202-2%201-1%203%201%201%204-3%203v5h2l10-1h12q3%203%202%207-6%203-13%203h-2l-3%205q12%202%2023%200l-1-3q0-5%203-9%204-3%209-3v2l7-1v3q13%202%2022-4%206-4%2012-5v-4c7-7%2019-7%2028-8l-1-7q10-4%2020-3l1%204h6l1-2q0-5%205-4'/%3e%3cpath%20fill='%23383c7b'%20d='M143%20534h3l4%2010%201%203q4%2011%201%2022l4%201%201%206H0v-26h39c21%201%2021%201%2027%204l2%204q-4%204-9%205l-23%209h18l3-1h12l2-2q7-5%2017-6l1%201%2011-2%201-3q2-5%206-7l9-1h4l-4%209h17c5-11%205-11%203-16l-1-2v-6l7%201z'/%3e%3cpath%20fill='%23656096'%20d='m309%20391%202%201-1%202-2%205-2%202-1%203-2%203-1%207%204%201%203%201q6%202%2011%206%202%2011%201%2021v6l-3%2014-14%205v-10h-2l-1%202-3%206q-5%207-8%2015l-1%202h-3l1-8-3%205-3-1%204-9%201-7-9%2011q-1-4%201-9l2-3%201-2-6%209q-1-6%202-10l2-3%202-4-4-1-1%202-4%206h-3l-1-2-2%201-7%203-1%202h-2l-2%205h-1c0-14%200-14%204-19l8-4v3l1-3%206-16%207-19%204-4%204-1%203-3%2010-5%204-4z'/%3e%3cpath%20fill='%23faccbe'%20d='m309%20498%205%201%205%201%201-2v78H207l-4-2%2021-7%206-2h3l6-2q8-2%2016-1h8l23%201h3c8%200%208%200%2011-3l5-8-4%201%202-2%203-5%207-1q4-3%205-9l-8-1h-3q-3-1-6%203l2-9-3%201q-12%203-22%202v-5l-4-2%202%207-4%201-3%201q-3%201-6-2l-1-4v-3q1-4%207-5%206-2%2013-1c11%200%2011%200%2017-3l11-4-1-3q-2-4-2-9zM20%20164h1l1%203%203%206h5l1%205h3l4%208-7%202%201%205h2l1-2%209%204-2%206H32l-1-5h-5q1%206%205%2010%204%202%209%202l1-3%203%201-4%207-2%202-2%202-2%202-8%207q-4%202-4%206l-3%203%202%202%201%205-5%205-4%203v6q-6%204-13%204v-81q-1-5%203-11%205-2%209%201l3%206q4-2%203-4l1-2z'/%3e%3cpath%20fill='%23fbe9d4'%20d='M55%200h98c-16%2025-16%2025-31%2029q-24%204-43-10l-9-7L55%201z'/%3e%3cpath%20fill='%23fa99a5'%20d='m11%20103%202%201-1%202-2%204%202%201q4%201%206%205l3%201-2%208%204%201%203-3%209-3%202-4%202%201-2%202%203%202-2%203h3q6%200%2011%203l-2%205h-2l1%207%2011%201%201-3q4%200%206%203l5%2010%206%207h13l3%201h2q2-1%204%203l4%201h4l-1%204-15%203-7%201q-6%201-12-2-6-6-7-14v-3l-19-3c-26-2-26-2-30-6l-9-1-8-1v-27l5-2%203-4%202-2z'/%3e%3cpath%20fill='%23e8cbd6'%20d='M176%20465h12l4-1q7%200%2013%202l1%206h-2l-7%202-3%201-5%201-5%203-8%201-6%203h-4l1%202%206-2%2011%203-1%204-18%201-2-4%201-2-2%201h-8l-1%203h-4v2h3q3-1%205%202l-1%204c-20%203-20%203-26%202l-2-4-5%201h-3l-4%202h-10q0-5%204-9%205-4%2011-3l1-1h8v-2h-2q0-6%204-11%204-4%209-5l11%202q4%201%2010-1l3-3z'/%3e%3cpath%20fill='%23656096'%20d='m210%20267%202%201%205%201q5%200%209%205v2l4%202%203%202q7%205%2016%207v2l3%201%201%206%202%203v7h-2q1%2013%205%2026v6l-6%201c-13-1-13-1-18%202l-4%204-5%203%206-25-4%201-2%206-4%207h-2l4-11q5-7%206-15l2-6q3-7%200-13-2-6-6-9l-3%201-4-3-2-1q-5-5-6-13'/%3e%3cpath%20fill='%23c5789d'%20d='M251%20412q3%200%205%202l2%202-2%204q-6%203-13%202l-6%201h-8v2l3%201c0%206%200%206-2%209l-16%203h-4l-3%205q-2%205-5%205l-9%201h-7l-29%201v2c-12%2010-28%2010-43%2010h-3q-4%200-7-3l-1%202H88v-3q8-3%2016-2l9-1%206%202q10%201%2020-1l-1-3q0-5%203-9%204-3%209-3v2l7-1v3q13%202%2022-4%206-4%2012-5v-4c7-7%2019-7%2028-8l-1-7q10-4%2020-3l1%204h6l1-2q0-5%205-4'/%3e%3cpath%20fill='%23fbb2b6'%20d='M44%20151q5%201%209%206l3%206%203%205v3q6%200%206-4l1-2h2v-5l3%205q5%204%2011%204l7-1h7l6%202-2%201-3%203-4%205-2%202-4%201-2%204-2%202q-2%204-2%209l1%204-9%202%201%202v3q-4%204-9%203v-5l1-2-2%202-4%202-3-4h-4v-3l7%201%201-5H46v-3h3l4-5q0-5-3-8l-3%201h-3l-2-2v-3h7l2%201-5-6v-2l-3-1v-17z'/%3e%3cpath%20fill='%23f67ba7'%20d='m161%2086%204%201%205-1%201%202%203-2h5l2%203h2l7-2%201%202%207%206v2h2v2l4-1v2h2l5%206q3%204%202%208l-2%205-5%201-3%203v-7h-2v4l-9%203h-5l-2-3h-4l-1%204-6%201-1-7-2%201-5%201v-9l-2-1-4-4%201-3-2-1-3-3%201-3-3-1c3-9%203-9%207-9'/%3e%3cpath%20fill='%2356427a'%20d='M302%20458h2l1%209%202-1q6-4%2013-3v29l-1%208h-2l-3-1h-5l-1%203v6l-10%202-5-4-3-1q-3-8-1-17l-4%205-10-5-6-4-2-1v-2l4-3%203-3-1-7%203-1%203-4%201-2%201-2%201%202-2%205-2%203-1%202%201%201%201-2%202-2%202-3%204-3q0%207-4%2013l-1%204h2l3-6q1%205-1%2010h3l1-2q2-10%209-18l2-3z'/%3e%3cpath%20fill='%23faccbe'%20d='m309%20391%202%201-1%202-2%205-2%202-1%203-2%203-1%207h2c12%204%2012%204%2016%208q2%209%201%2018l-1%2018-10-11-2-2-5-8q-7-5-15-4-7%200-12%206l-2%202-4%204-4%202%203-12%201-3%202-3%203-6%201-3%203-10%204-4%204-1%203-3%2010-5%204-4z'/%3e%3cpath%20fill='%23fbb2b6'%20d='M320%20373v49l-18-8q0-9%205-16l2-2%201-4q-6%201-10%205t-10%206l-3%203q-3%202-7%202v3l-5%2013-8-12%201-3q0-6-5-11l-8-6-2-2v-2l8%205%202%202%202%201%201-8%207%2010v2l6-6h2q1-7-4-13v-6q5%204%205%2010l2-2%204-4v2h3l9%203%201-1c5-8%205-8%2010-10z'/%3e%3cpath%20fill='%23383c7b'%20d='m303%20529-1%207%202-2h9l6%202q-2%207-8%2011l-5-1v2l-2%203%202%201q-2%206-8%2011l-15%201h-4l-15-2a88%2088%200%200%201%2010-25l6-6%2014-1z'/%3e%3cpath%20fill='%23656096'%20d='m0%20510%2014%202q37%207%2073%202-2%204-7%205h-8v2c-15%2013-34%2011-53%2011H0z'/%3e%3cpath%20fill='%23d6abc5'%20d='m124%20181%202%205q5%2013%2018%2022l-1%203-6-3-3-3h-13v3l-5%203v3l3%202v3l7%201v5h2l5%203-1%204-6-1v2l-9%201-2-6%201-2h7l-1-2-3-1-1-2q-10-3-21%200l-1-3%209-3q-2-8-8-14l-2-2%201-5-2-3h3q5%200%208-3c4-5%2013-10%2019-7'/%3e%3cpath%20fill='%23383c7b'%20d='m249%20521%201%203h13v6l1%202%203%201q-1%206-7%209l-3%203-1%202-5%204q-5%204-11%205l-3%201-4-2q-3-4%200-10l2-6%201-3%202-5h2v-2l3-3%202-2%204-1zm18%2018q1%2012-4%2022-4%202-10%202l-20%201%201-4%208-4%202-1%209-3%202-4%204-4%202-2q2-3%206-3'/%3e%3cpath%20fill='%23656096'%20d='m309%20498%205%201%205%201%201-2v39l-4-2h-9q-3-1-6%203l2-9-3%201q-12%203-22%202v-5l-4-2%202%207-4%201-3%201q-3%201-6-2l-1-4v-3q1-4%207-5%206-2%2013-1c11%200%2011%200%2017-3l11-4-1-3q-2-4-2-9z'/%3e%3cpath%20fill='%23c5789d'%20d='M194%20269q3%202%202%205l4%208%202%208-3%203%202%201c7%204%2010%2015%2013%2022l2-1%204-2-2%2013-2%201q0%206%203%2011c4%209%204%209%204%2013q-7%208-15%2013l1%204h-2v3q-1%2010-10%2017l-3-1%202-2-5-2%201-9%204-1%201-5%204-5-2-2v-3h5l2%201v-7l3-3%202-1-1-7h-2l1-2c4-11%204-11%202-15l-3-5q-2-3-2-8-1-9-7-15l-4-5c-6-10-6-10-9-11h-2l3-1-1-3%201-6z'/%3e%3cpath%20fill='%23f67ba7'%20d='M5%20204q6%203%209%208l7%206%203%203-1%206v3l-4%205%202%202%201%205-5%205-4%203v6q-6%204-13%204v-51l1-4z'/%3e%3cpath%20fill='%23fa99a5'%20d='m214%20205%204%201%204%206%202%203%201%202-2%201q-4%202-7%206v2h-3v4h-2l4%205%203%203%202%203%202%203%2010%208%2015%2013%202%202c4%204%204%204%204%208l-2%204%205%202v2l5%201-1%203-4%201-1%202q-2-3-2-7h-4l-2-4%203-1-12-11-7-6q-5-4-11-5l-9-7-4-3-2-2-4-2q-4-9%200-18l3-5%206%202%203-10z'/%3e%3cpath%20fill='%23c5789d'%20d='m290%20213%205%201h4q5%204%206%2011l-5%203-2%202v4q0%205-3%2010l-7%204v2l-6%201-3-4-7-1-1-4%201-8-1-2-5%201%201%203%202%201v2l-11%201-3-4%201-4%201-5%203-6h4v2l4-1%202%206%203-1%209%202%203%201%203-3-2-4h-2l-3-3-1-2%202-2h2q3%201%205-2z'/%3e%3cpath%20fill='%23f67ba7'%20d='m46%20173%204%201%201%204-9-1%202%204%203-1q3-1%205%202l2%206-5%207-3-1v3h15v5h-6l-2-1v3h4l2%203h3l2-3h2l-1%207-5%202-5%205-5%203-4%202-3%202q-4-2-6-7-1-4%203-6l2-2%201-4h-2l-1%202-6%201-7-6-1-7%205-1%201%206h10l2-6-9-4-1%203-3-1-1-5%208-2-4-5q1-4%204-5l3-1z'/%3e%3cpath%20fill='%2356427a'%20d='m0%20126%203%204q4%206%2013%208l2%201q21%203%2042%201l1-3q4%200%206%203l5%2010%206%207h13l3%201h2q2-1%204%203l4%201h4l-1%204-15%203-7%201q-6%201-12-2-6-6-7-14v-3l-19-3c-26-2-26-2-30-6l-9-1H6l-6-1z'/%3e%3cpath%20fill='%23fa99a5'%20d='m218%20124%2013%203%201%205q2%207%208%2010v2h2l4%204v8l-3-1q-8%200-14%205-9%205-20%206c3-21%203-21%206-24l1-7z'/%3e%3cpath%20fill='%23c5789d'%20d='m243%20504%205%2012%201%202v5q-5%206-14%208h-8l-4-7-4%208-1-2h-15v-8q11-10%2025-15l-1-2z'/%3e%3cpath%20fill='%23fbe9d4'%20d='m38%20235%202%201v2l5%201v4l3%201-15%2016-3%203-8%208-11%2011-2%202-2%202-2%202-3%204H0c-2-17-2-17%203-23l15-15%2015-14z'/%3e%3cpath%20fill='%2356427a'%20d='m216%20419%201%204%202-4%201%205-5%202h-2l-6%201q-7%200-14%205h-2v4l-2%201-17%208-9%201h-6l-1-3h-6v-2l-2-1%208-5%202-1%206-4%203-2q7-3%2013-3l9-2%2014-4h3l2-1h2z'/%3e%3cpath%20fill='%23383c7b'%20d='M235%20293c6%206%206%206%207%2010v6l7%203v2h3l1-2%206%2025q-3%203-7%202c-14-1-14-1-18%202l-5%205q-1-5%201-10l4-26v-5z'/%3e%3cpath%20fill='%2356427a'%20d='M51%2063q5%202%207%207%204%203%2010%202l2-2%202-1%206%203%203%201h2l1%202-7%206q-4%202-5%206l-6%202-2-1v2l-1%205-4%201-6-4v-5h-7l-4-1-1-6q1-5-2-9l3-4h7z'/%3e%3cpath%20fill='%23fa99a5'%20d='m305%20444%209%2010%202%202%204%207h-2c-10%202-10%202-14%205v-10h-2l-1%202-3%206q-6%207-8%2015l-1%202h-3l1-8-3%205-3-1%204-9%201-7-9%2011q-1-4%201-9l2-3%201-2-6%209q-1-6%202-10l1-3%204-5%205-1%209-2%202-1z'/%3e%3cpath%20fill='%23e8cbd6'%20d='m41%20474%202%202%202%202%202%204h3v2l-11%203v7l-3%201-5%203-8%202-6%201-5%201-2%201-10%201v-20h4q21%203%2037-10'/%3e%3cpath%20fill='%2356427a'%20d='M291%20135h7q-4%2010-15%2014c-8%204-8%204-11%208l1%205c-5%203-5%203-8%203v2l-9%202-9%201-5-1q-4-2-10%200%205-9%2014-13l10-3q6-1%2010-5%208-6%2018-10z'/%3e%3cpath%20fill='%23282a5f'%20d='M320%20373v49l-18-8q0-9%205-16l2-2%201-4-11%201q-1-8%204-14%206-7%2017-6'/%3e%3cpath%20fill='%23f67ba7'%20d='M82%2075q5%202%208%206l2%201%203%204-9-1%202%203v6l-1%202h6l1%204h-7l-1%205h-3l-5%201-2%201-3-2h-3l-1%205h-4l-1-2-4-1v-4l-4-3%201-4%202-1%203-1%201-3%201-3%207-1%204-6%205-3z'/%3e%3cpath%20fill='%23656096'%20d='M0%20550h39c21%201%2021%201%2027%204l2%204q-7%206-18%208l-8-1-5-1h-2l-1-2-1-2-6-1-4-2-9-2q-8%206-14%2015z'/%3e%3cpath%20fill='%23d6abc5'%20d='m183%20119%204%203h5l3-1%205-1-1%209-1%203v2l-1%202-1%203v9l7-5q-1%206-5%2011l-2%203-2%202q-4-1-6-6l-7-12q-3-5-7-6l-9-1h-6v-1l9-1%201-3q5-5%2011-5v-2l1-2z'/%3e%3cpath%20fill='%23e8cbd6'%20d='m37%20216%201%203%204%205%205-2%203-2%202%201-8%208-2%203-9%209-8%208-12%2012-4%205-3%202-3%203-3%202v-13l12-4v-3q0-3%202-5l7-5-3-9%202-1%203-4q2-6%207-8l2-3z'/%3e%3cpath%20fill='%23383c7b'%20d='M199%20544q1%206-2%2011l-1%202c-7%2014-7%2014-13%2017h5v2h-30v-8l4-2q6-3%208-10l5-3%205%201q6%201%2013-1l3-6z'/%3e%3cpath%20fill='%23faccbe'%20d='M44%20151q5%201%209%206l3%206%203%205v3h3v2h2q3%202%205%206h2q-1%206-6%2010l-3%202-2%202-2%202q-3%203-7%202h-5v-3h3l4-5q0-5-3-8l-3%201h-3l-2-2v-3h7l2%201-5-6v-2l-3-1v-17z'/%3e%3cpath%20fill='%232c3068'%20d='m70%20519-9%207-2%201q-10%204-22%203H0v-4l13-3%205-1q25-4%2052-3'/%3e%3cpath%20fill='%23f08cc3'%20d='M187%200h23c0%209%200%209-2%2013l-2%201-1%205-9-1-2%202h-2l-2%201-2%206-1-2h-2l-3-1-1-4-4-2q1-6%203-7h6V8z'/%3e%3cpath%20fill='%23d6abc5'%20d='M281%20519h33q-3%207-10%2010-12%204-26%203v-5l-4-2%202%207-7%202q-4%200-6-2l-1-4v-3q1-4%207-5%206-2%2012-1'/%3e%3cpath%20fill='%23656096'%20d='m274%20525%204%201v9l-3%204q-7%2011-11%2023l-2-1%201-2q4-10%204-20-8%204-14%2013h-2q4-7%2011-13l2-2q5-5%2012-5l-2-3zm-34%205-2%201-1%204-3%209-1%209%202%203%2012-3h4l-14%207-3%201-1%203%203%201-14%203q1-6%205-11%203-5%202-11l-1-2-1-8v-5z'/%3e%3cpath%20fill='%23f67ba7'%20d='m11%20103%202%201-1%202-2%204%202%201q4%201%206%205l3%201-2%208h3q1%207-3%2013-5%201-11-2-4-1-6-6l-1-2-1-9v-6l2-1q4-1%206-5l2-2z'/%3e%3cpath%20fill='%23e8cbd6'%20d='M175%20279q9-1%2016%203l6%209%201%202%208%2012v5q1%207%205%2011l2%207-1%205-1%203-2%203-4%208-2%205-2%201%202-8%202-10v-2q1-10-4-19l-1-3q-4-11-12-17l-2-2-2-2-5-4-2-2q-3-2-2-5'/%3e%3cpath%20fill='%23383c7b'%20d='M269%20358h3l3%2011q1%209%207%2017l-1%208h-2l-1%202q-1%203-5%204l-1-2-1-2-2-3-2-3-2%204q-1-15%201-31l-4%202v-5l-4-1c8-2%208-2%2011-1'/%3e%3cpath%20fill='%23d6abc5'%20d='m157%20404%2012%202%204%201h2l-2%202h-3v2l-9%202v-2l-7-1v-3h2zm-10%203%207%203v1h-2q-11%200-20%208c-5%203-5%203-8%203v2q-8%203-16%203%205-13%2018-18l8-1z'/%3e%3cpath%20fill='%23656096'%20d='m231%20383%201%203-3%205%202-1q11-4%2022-3v2h-2q-17%200-29%2011l-6%205-3%202-16%208-4%201-11%201-22%206-7%202-3%201h-6l12-5q-10%200-20%203l-2%201-21%207v-4l-3-1%205-1%202-1%209-1%2012-2q13-4%2026-4l-9-2%201-2h2q15%204%2029-2l7-1h6v-2h-5q3-2%207-2%2011-1%2019-10l8-11zm-32%20157%202%201%2011-1-4%208h-2v-2q-4%201-5%204l-1%202-1%203v6h4l11%203%201%205%202%201-2%201h-3l-3%201-3%201-1%203h-17l-1-1h-6q3-4%207-5l4-7%201-2c7-13%207-13%205-20z'/%3e%3cpath%20fill='%2356427a'%20d='m205%20376%201%202h8q1%205-1%209v3l-2%201-14%205-13%204-5%204h-3l-2-7%202-1c9-6%209-6%2012-10l3-3%206%201-2%203q7-3%2010-11'/%3e%3cpath%20fill='%23f67ba7'%20d='m160%2014%201%205h12v7l2-1%204-1%203%204%201%203q-3%203-7%203h-2l-1-2-1-2h-6l-1%202-4%201h-2l-7%201h-2l-7-9%202-1q7-3%2011-8z'/%3e%3cpath%20fill='%23fa99a5'%20d='M177%20101q9-1%2015%206l-8%2010-3%205-1%202-6%201-1-7-2%201-5%201v-4l-1-3v-4l4-3%203-2%205-1z'/%3e%3cpath%20fill='%2356427a'%20d='M127%20204h7l2%203%204%202-3%201-6%203h-3v8l7-1%202-4h9l-1%209-4%201-1%203-14-4-1-5h-3l-3-1-1-3-3-2%203-6h3l-1-3q4-2%207-1'/%3e%3cpath%20fill='%23656096'%20d='M320%20463v23c-6%201-7%201-12-2l-3-4h-5q-1-7%203-12c6-5%209-5%2017-5'/%3e%3cpath%20fill='%2356427a'%20d='m214%20205%204%201%204%206%202%203%201%202-2%201q-4%202-7%206v2h-3v4h-2v3h-2l-1%203h-2v2h2l1%203-3-1h-3l-2%202q-4-10%201-20l4-2%204%201%203-10z'/%3e%3cpath%20fill='%23656096'%20d='m117%20156%208%201%205%202%204%201h4l-2%207q-3%205-4%2011l-1%202v10l3%204-1%202q-5-4-5-11v-13h-3l1%204h-2v5h-1v-2q0-5-3-10l-7-4q-3-2-4-5l-1-3h4l-1%204%206-1z'/%3e%3cpath%20fill='%23f67ba7'%20d='m18%2064%203%206%203%204-4%201v2q-4%204-10%205v3l2%202q0%205-3%207l-3%202-5-3-1-10v-7l8%204%201-3-2-3q0-5%203-10z'/%3e%3cpath%20fill='%23c5789d'%20d='m253%20388%208%205%202%202%202%201%201-8%207%2010v2l6-6h2l1-3q1%2017-7%2033l-8-12%201-3q0-6-5-11l-8-6-2-2zM131%20119l1%202%205%206%201%202%204%204-10%208-4%204-2%202-2%201-3-1%201-2-2-1q-3-2-4-5-1-5%203-8l3-3%202-2%207-4zm80%20392-2%206-3%202-2%202-3%201-2-11-1%201%201%209%201%202%201%206-14%201-3-1h-6l12-13%202-2q9-9%2019-3'/%3e%3cpath%20fill='%23d6abc5'%20d='M150%20545q8-1%2014%203%203%206%201%2011l2-3%203%201-4%209h-3l-4%203-1%207-3-6-4-1%201-2q1-10-2-18z'/%3e%3cpath%20fill='%2356427a'%20d='M201%20242q7%203%2012%208l3%202%202%202%206%202q5%201%208%206l16%2012%202%202v2c-9-1-12-5-18-11l-1-2%202%206q-6-1-10-6l-2-3-2-4h-2l-5-5-7-5%2012%2012%209%208%201%201%204%204-2%201-14-12c-5-5-5-5-9-5v-4l-5-6-1-2z'/%3e%3cpath%20fill='%23fbb2b6'%20d='m318%20134%202%201v17l-2%201-1%203q0%203-4%205-5%201-8-2l-3%202-6-2%206-8%201-2%204-1%202-4%204-4z'/%3e%3cpath%20fill='%23d6abc5'%20d='M0%20298c16%202%2016%202%2020%207q-1%205-6%209l-2%202-12%206z'/%3e%3cpath%20fill='%23f67ba7'%20d='m138%2080%201%202%204%201h2l4-1%202%203q-2%204-8%204l-8%203q-4%202-9%201l1%202h-2v2q-8-2-15-8l1-2%204%201%208-1%201-3q2-3%206-5z'/%3e%3cpath%20fill='%23fbb2b6'%20d='m165%20111%201%209%207-2v8l-5%206%202%201c-14%201-14%201-20-3v-2l-2-1h2l2-4%203-3%202-2%202-1%201-2z'/%3e%3cpath%20fill='%23faccbe'%20d='m305%20444%209%2010%202%202%204%207h-2c-10%202-10%202-14%205v-10h-2v2h-2v-2h-5c2-10%202-10%205-12z'/%3e%3cpath%20fill='%23c5789d'%20d='m107%20429%203%201%201%204-3%203v5h2l10-1h12q3%203%202%207-6%203-13%203h-3v-4a32%2032%200%200%200-19-2h-5l9-12%202-3z'/%3e%3cpath%20fill='%23fbe9d4'%20d='M318%20537h2v10l-2-1-5%201-2%202h-2l-1%202q-1%205-6%208l-2%205h3-37q-18%200-34%204c-18%206-18%206-27%206l3-3h2l3-1%203-1%209-2%206-2q12-4%2025-3h42l7-10-4%201%202-2%203-5%207-1q4-3%205-8'/%3e%3cpath%20fill='%23d6abc5'%20d='M242%20168h11l-1%202h-2l1%202v8l4%201-8-1v6l-4%202-3-2h-3l-4-4v-8h2v-4h-5v-1q5-2%2012-1'/%3e%3cpath%20fill='%232e3772'%20d='m317%20545%203%202v18h-10l-10-1q3-11%2012-18z'/%3e%3cpath%20fill='%23d6abc5'%20d='M149%20468q3%202%202%205l-3%201-4%201-2%207-5%205h-10l-5-1v-1h8v-2h-2q0-6%204-11%207-6%2017-4m89-129q-1%207-6%209-4%204-6%209-3%208-10%2012l-5-2-2%205h-3l2-5-1-3%202-2%2014-13%207-5%203-3z'/%3e%3cpath%20fill='%23f67ba7'%20d='M194%20269q3%202%202%205l4%208%202%208-3%203%202%201q5%203%206%208v5l-7-10c-9-15-9-15-14-17h-2l3-1-1-3%201-6z'/%3e%3cpath%20fill='%23656096'%20d='M201%20116h2l1%206%202-3%206%201-2%208%202-3%202-3h3v13h-1v-5l-2%201-2%201-3%201-4%201-5%204-2%201-2-1%201-8%201-2z'/%3e%3cpath%20fill='%23fbe9d4'%20d='m175%20279%209%201%204%208%206%208q6%206%209%2013l1%202%202%206%202%207q2%2014-4%2026l-3%203%202-8%202-10v-2q1-10-4-19l-1-3q-4-11-12-17l-2-2-2-2-5-4-2-2q-3-2-2-5'/%3e%3cpath%20fill='%2356427a'%20d='M19%20235q4%204%203%207l-5%205-4%203v6q-6%204-13%204v-6l3-3%208-10c4-6%204-6%208-6m246%20210v3h3v2h8q0%206-4%209h-3l-1-2-9%204-1%202h-2l-2%205h-1c0-14%200-14%204-19%205-4%205-4%208-4'/%3e%3cpath%20fill='%23eea7bc'%20d='m214%20143%201%202%204%203q4%203%204%207l1%202%201%205-5%202-2%201-9%201z'/%3e%3cpath%20fill='%23f67ba7'%20d='M163%2034v2h-2q2%205%206%208l-5%204v4l-10%203-1-5h-2l-1-6%206-1v-2q2-7%209-7'/%3e%3cpath%20fill='%23656096'%20d='M87%20515q-3%204-10%204h-5v2c-15%2013-34%2011-53%2011H0v-2h36l3-1q17%201%2030-9l-10-1%201-2%2014-2z'/%3e%3cpath%20fill='%23fbb2b6'%20d='m268%20274%203%208%201%203v3l1%203%201%2015-7-13-4-6-2-4v-3l-1-6z'/%3e%3cpath%20fill='%23282a5f'%20d='M291%20432q7%200%2012%204l6%208%207%209%204%205-1%203-2-2-5-6-3-5q-4-6-9-5l-5-1v-3l-2%201-6-1-3-4v-2q3-2%207-1'/%3e%3cpath%20fill='%23f08cc3'%20d='M164%20252c7%201%207%201%2010%204q6%2010%205%2021l4%202h-5l-4-3-1-3-9-17-1-2z'/%3e%3cpath%20fill='%23faccbe'%20d='M308%20519h6q-2%207-7%209-7%202-15%201v-2l-3-1%202-4-3-1h5l3-1z'/%3e%3cpath%20fill='%2356427a'%20d='M44%20208q5%201%209%207l2%201q-1%205-6%206l-2%201-5%201-5-5%201-5z'/%3e%3cpath%20fill='%23f08cc3'%20d='M177%20188q6%202%209%206%201%208-4%2014l-4-1-3-6-2-1z'/%3e%3cpath%20fill='%2356427a'%20d='M136%20448q3%204%203%208-10%203-20%202l-3-2%204-8%201%202q5%201%2010-2z'/%3e%3cpath%20fill='%23f67ba7'%20d='M211%20279q5%202%208%206l2%202q3%202%202%205l-3%205h-5l-7-7%202-10z'/%3e%3cpath%20fill='%23fbb2b6'%20d='m247%20519%202%204-4%203-3%202q-6%205-15%203l-2-5%203-3%203-1z'/%3e%3cpath%20fill='%23c5789d'%20d='m205%20248%2010%207%202%201v2h2l3%204%209%208q4%203%203%207h-6q-4-2-7-6l-3-3-2-1-9-11%208%205%206%206%202%202%202%202%204%201-4-4-4-3-8-8-2-1-4-4z'/%3e%3cpath%20fill='%23fa99a5'%20d='m230%20264%209%209q4%204%209%205l-2%203-1%203q-7%202-13-3l-4-4v-2l6%202-1-3-2-5z'/%3e%3cpath%20fill='%23656096'%20d='M201%20201h2q0%206-4%2010l-2%201-15%2013q-11%207-14%2020l-1%207%202%201-5-1q2-17%2014-28l2-2%2019-18z'/%3e%3cpath%20fill='%23f67ba7'%20d='m180%2011%205%201h2l7%203%201%204-2%201q-3%201-4%204l-1%203-1-2h-2l-3-1-1-4-4-2q1-6%203-7'/%3e%3cpath%20fill='%23eea7bc'%20d='M299%20237h3l1%202%206%201%203-1v4h-2l1%205q-7%203-15%202v-9zM137%2032l7%202%202-1h6l2-1h7v3l-4%202-3%206-6%201v-2l-12-4%202-1z'/%3e%3cpath%20fill='%23656096'%20d='M152%20545c8%200%208%200%2012%203l2%208-8%206-3-4-1-3-1-4z'/%3e%3cpath%20fill='%23f5d6ca'%20d='m314%20228%203%201-2%206h5v8l-3-1-5%201v-4l-3%201-4%201-3-2%204-9%207%201z'/%3e%3cpath%20fill='%23c5789d'%20d='m51%20202%201%202h5l2%203h3l2-3h2l-1%207-5%202-4%204q-7-3-11-10z'/%3e%3cpath%20fill='%23d6abc5'%20d='M119%20220h7v5h2l5%203-1%204-6-1v2l-9%201-2-6%201-2h7l-1-2-3-1z'/%3e%3cpath%20fill='%23e8cbd6'%20d='M230%20168v2h5v4h-2v8h-2v2h-3l-1-3-7-1v-6q4-5%2010-6m-16%2037%204%201%204%206%202%203%201%202-2%201-5%204-3%202-4-2%201-5%201-5z'/%3e%3cpath%20fill='%23d6abc5'%20d='M229%20197h3l2%206%204-2%205%204%201%204-2%203h-6l-1-3-4-2-3-3-3-1v-5z'/%3e%3cpath%20fill='%23f5d6ca'%20d='M275%20421h2v3l3%207q1%204-2%206l-8%208-4%202%205-16%201-3z'/%3e%3cpath%20fill='%232e3772'%20d='M320%20463v11l-10%201v-2l-3-3-2-1v-2q7-5%2015-4'/%3e%3cpath%20fill='%23d6abc5'%20d='m144%20215%202%201c1%206%201%206-1%209l-4%201-1%203q-5%200-9-4l2-5h2l1-2%201-2h6z'/%3e%3cpath%20fill='%23f08cc3'%20d='m198%20359%204%204-2%202-3%206-1%202-4%201v2q0%208-6%2015l-6%202%202-3%202-4%201-2%203-5%201-2v-6l4-5z'/%3e%3cpath%20fill='%23fa99a5'%20d='m4%20177%202%201%204-1h2q3%202%202%205l-1%206-8%201-2-1-1-4-2-1v-3l4-2z'/%3e%3cpath%20fill='%23656096'%20d='m304%20551%202%201q-2%206-8%2011l-15%201-15-1v-1h12q7%200%2013-6l6-3%203-1z'/%3e%3cpath%20fill='%23c5789d'%20d='m203%20239%208%201q7%206%2011%2013l2%203q-5%201-8-3l-3-2-2-2-5-4-4-3z'/%3e%3cpath%20fill='%23f08cc3'%20d='M136%2090q4%202%205%205l-1%202-4%201-2%201v3h-6l-3-2-3-2-2-1%202-2%203%202v-4l7-1z'/%3e%3cpath%20fill='%23c5789d'%20d='M71%20193q5%200%208%202l3%206H72l-4%202-4-4q0-7%207-6'/%3e%3cpath%20fill='%23656096'%20d='M269%20358h3l1%205h-3l-1%208-1%202-1%2015-1%206h-1q-1-15%201-31l-4%202v-5l-4-1c8-2%208-2%2011-1'/%3e%3cpath%20fill='%23c5789d'%20d='m244%20280%208%204%201-2%201%203%203%207%201%207h-4q-3-4-3-9l-2-1v-2h-5v-2l-4-1h5z'/%3e%3cpath%20fill='%2356427a'%20d='M92%20216h3l2%203-1%203h-2q-6%200-10%205l-4%201-2-1%201-3h3v-5l3-1z'/%3e%3cpath%20fill='%23c5789d'%20d='m130%20159%208%201-4%209-1%205h-1l-1-3-3-8h-2l-3-3-1-2c4-1%204%200%208%201'/%3e%3cpath%20fill='%23f67ba7'%20d='m0%20140%2017%201v1h-6l-1%202q-1%204-5%206l-5%201z'/%3e%3cpath%20fill='%23c5789d'%20d='M112%20213v2l2%201-1%203h5l1-3v3h6v1h-14q-7-1-14%201l-1-3%206-3%204-2z'/%3e%3cpath%20fill='%23fbe9d4'%20d='M0%20484h16v2h7q-3%204-8%203H0zm199-129%201%203q-4%207-10%2011l-5%206q-1%203-6%204%207-14%2020-24'/%3e%3cpath%20fill='%2356427a'%20d='m281%20494%203%201v7h2v2h-2l-3%201h-2l-7%202q1-5%205-8l1-2z'/%3e%3cpath%20fill='%23d6abc5'%20d='M318%20537h2v10l-2-1-5%201-2%202h-2l-1%202q-1%205-6%208l-3%205-1-2%203-5%202-3%202-2-4%201%202-2%203-5%207-1q4-3%205-8'/%3e%3cpath%20fill='%23656096'%20d='M149%20545q6%2010%203%2022l-1%202q-4-3-3-8l-2-9z'/%3e%3cpath%20fill='%23c5789d'%20d='m220%20389%202%201q1%203-2%205c-8%208-8%208-11%208q0-7%205-12zm39-119c3%2010%203%2010%203%2016l-2-2h-2l-4-3-1-2h-2q1-7%208-9'/%3e%3cpath%20fill='%23fbe9d4'%20d='m69%20454-3%202-4%203-12%207-2-1q7-13%2021-11'/%3e%3cpath%20fill='%23d6abc5'%20d='m253%20388%208%205%202%202%202%201%201-8q5%203%206%208l-1%203-4-1%202%203%201%205h-2l-2-3q-5-7-11-11l-2-2z'/%3e%3cpath%20fill='%2356427a'%20d='M157%20169h6l1%203q0%203-2%205l-8%201-2-4q1-5%205-5'/%3e%3cpath%20fill='%23282a5f'%20d='m0%20512%2020%203%203%201%207%201v1l-30-2z'/%3e%3cpath%20fill='%23e8cbd6'%20d='M193%20142h1c0%2011%200%2011-2%2015l-4-3-1-2-1-2-1-5h2l5-1z'/%3e%3cpath%20fill='%23f67ba7'%20d='m95%20108%206%201%201%206-3%204-6-2-1-2q1-6%203-7'/%3e%3cpath%20fill='%23656096'%20d='m254%20155%202%201-8%205-2%202c-7%205-7%205-11%206l-3-1%209-9%202-2%202-1%203%201-4%204%202-1%203-2%203-2z'/%3e%3cpath%20fill='%232c3068'%20d='m0%20518%2022%201v2l-22%203z'/%3e%3cpath%20fill='%23282a5f'%20d='M320%20429v15q-5-2-8-8v-3q3-3%208-4'/%3e%3cpath%20fill='%23c5789d'%20d='M202%20143v6l-2%203-2%203-6%204-1-2%201-2%202-11%202%204z'/%3e%3cpath%20fill='%23656096'%20d='M255%20310h2l3%208%201%202q3%205%202%2012h2v7q-3-3-4-7l-1-2-1-3-1-5v-2l-2-4z'/%3e%3cpath%20fill='%23eea7bc'%20d='M248%20278q4%200%208%203v2l5%201-1%203-4%201-1%202q-2-3-2-7h-4l-2-4z'/%3e%3cpath%20fill='%2356427a'%20d='m154%20261%203%201v5q-3%203-7%202l-2-1v-5q2-4%206-2'/%3e%3cpath%20fill='%23656096'%20d='M191%20469h4v2h-4z'/%3e%3c/svg%3e",
	springs: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='576'%3e%3cpath%20fill='%23d3deda'%20d='M0%200h320v576H0z'/%3e%3cpath%20fill='%23e2f2f1'%20d='M0%200h320v189l-102-1%201%205-3%2010v2q-3%2010-11%2018l-1%204-5%202-2%201q-9%203-16%202h-8l-1-4-5%202-1-3-2-1-1%202-1-3-6-8-3-1-1-3-6-2v-1h2l9-1%203-5%203-1-4-4%202-4%206-1v-2h4v-3l-41%201%203%2015%201%203-7%206q-2%202-2%205v10h-2l2%205h2q6-1%2012%202l-1%204%203%201-2%207q-4%202-8%201l-3-4v-4l-6-1-1%203q-1%205-7%207l-9%201q-10%202-15%2010-5%2010-5%2021l2%204%202%205-2%203-2%205-2%204-26-4%202-3q3-7%202-15l-8-7h-6l-3-1H29v-1l17-1-5-3-2-3%201-4-1-2-2%201-1-3%203-2v-4q2-10%2010-17%2013-10%2031-9%207%200%2012-4%205-7%205-15-1-5-5-9l-1-7H0z'/%3e%3cpath%20fill='%23f77e3a'%20d='M276%20301q-5%205-11%206-7%201-11%207l-2%204q-2%204-6%206-6%202-7%208-1%207%203%2014%208%207%2019%209l7%204-1%207q-10%2011-25%2012l-15-2q-16-5-29%203h-2q-2%206-1%2012%203%205%207%206l3%206q-1%207-7%2012l-9%205q-6%201-10%206-2%208%202%2014%207%206%2018%205h8l4%201v2h3q6%201%209%206%202%208-3%2014-11%2012-26%2014l-5%205v4l-2%203h-8v4l2%201h2l3%201%205%204q2%205-1%2010a19%2019%200%200%201-20%2011q-5-1-9%203l-2%202-2-1%203-4-3%203-3%202-4-1%201-4%201-3%204-5q-6%206-14%207l1%205%205-1-2%206-2%201v-4l-3%205h5v11l1%2010-1%201%203%201v-4l4%201%205%2010q3%204%208%206l2%201v1h-8v2H0V303l8-1h39l-1%204h-2l1%205h8v2l4%201v3c-2%2016-2%2016%202%2021l7%204-2%208%204%202-1%206h-2l1%204-1%206%202-1%206%202-1%204%203-1%202%202q4%204%2010%203v-2q2-7%208-12l3-2%206-3%201-2%204-1h2l3%201h3c9%201%209%201%2013-2l2-4q5-5%2012-6h3l-1-2v-9q7-7%2016-9h17c6%200%206%200%209-2l-1-5-2-1-3-2-1-7-5-5%2010-1h68l9-1z'/%3e%3cpath%20fill='%23edd7b6'%20d='M0%20190h91l2%206%204%207q2%204%200%2010-3%209-11%2013h-6q-19-2-33%2011l-2%201q-6%208-5%2017l-2%203%203%203v6l6%204v1l4%201q6%201%2010%206%202%206%201%2012l-4%207h2l2%201h2l3%202%2010%201h6l2-4%201-3%202-6-3-5q-2-4-1-10%203-2%206-1h25a154%20154%200%200%200%2054-9c32-10%2070-16%20104-15l1%202%203%208%201%203q3%209%208%2014%206%206%204%2013%200%207-7%2010-6%204-14%202l-12%202v-2h-2l-24%201h-49l-5%201%202%202q4%202%204%207l-1%202h2l5%204-1%205q-5%203-12%202-14-1-27%205-3%205-3%2010l1%204-2%201c-12%204-12%204-16%2010l-4%202h-8c-9-2-9-2-13%201l-2%202-5%202q-5%204-8%2010l-1%207-1-2-3%201q-6-1-10-5h-2v-4l-7-1v-10h2v-2l-1-5-2-1%201-8-2-1-7-6q-2-10%201-21l-4-1v-2l-3%201h-6v-6l2-1v-2H0z'/%3e%3cpath%20fill='%23f26838'%20d='M276%20301q-5%205-11%206-7%201-11%207l-2%204q-2%204-6%206-6%202-7%208-1%207%203%2014%208%207%2019%209l7%204-1%207q-10%2011-25%2012l-15-2q-16-5-29%203h-2q-2%206-1%2012%203%205%207%206l3%206q-1%207-7%2012l-9%205q-6%201-10%206-2%208%202%2014%207%206%2018%205h8l4%201v2h3q6%201%209%206%202%208-3%2014-9%2012-23%2014-8-3-11-10l-5-7-1-2a95%2095%200%200%200-19-20l-39-27-3-1v-3h-2l-4-1h-3l-7-2v-2h-2l-8-2c-24-8-48-8-73-8l-1-3-2-4-1-2%201-2h-3l-12-4v-2H0v-77l8-1h39l-1%204h-2l1%205h8v2l4%201v3c-2%2016-2%2016%202%2021l7%204-2%208%204%202-1%206h-2l1%204-1%206%202-1%206%202-1%204%203-1%202%202q4%204%2010%203v-2q2-7%208-12l3-2%206-3%201-2%204-1h2l3%201h3c9%201%209%201%2013-2l2-4q5-5%2012-6h3l-1-2v-9q7-7%2016-9h17c6%200%206%200%209-2l-1-5-2-1-3-2-1-7-5-5%2010-1h68l9-1z'/%3e%3cpath%20fill='%23afd6db'%20d='M218%20188h97l5%201v31l-7%202-2%201-11%203q-12%204-22%2012l-2%205q0%203-2%205l-5%201-3%201h-7l-10%201a492%20492%200%200%200-100%2020l-5%201q-8%202-17%201H85q2-10%209-18%206-5%2014-5%208-1%2012-6l1-2%201-2h6l1%203%202%205h6l4-7-5-1%202-1v-3h-2l-12-2-1-5h2v-3l-1-4v-3q0-4%203-6l5-2q2-6-1-12c-2-7-2-7-1-10h41v3h-4l1%203h-3l-4%201-2%203%204%202v2l-2%201-3%204-1%202-7%201%203%202v3h2l5%204%204%206%203%201%201%202%204-1%202%203q16%203%2029-5l1-2%206-8q4-6%206-14v-2z'/%3e%3cpath%20fill='%23c9dad8'%20d='M0%20380h2v2l9%202%206%202v3l2-1%201%208h4a186%20186%200%200%201%2079%2011v2h5l3%201%208%202%201%203%204%202c24%2011%2050%2032%2063%2055v2l-8-2c-55-11-121-12-175%204l-4%201zM319%2053h1v136l-102-1-1-8%201-1%201-7-2-1-2-1v-4l5-3%206%201%202-2%203%201q11-5%2016-17l1-6q1-4%204-6%203-4%202-8l1-6h3v-3l1-9h-2v-2l-1-15-2-1-1-6h2l2-2q10-9%2024-11v-2l2-1h4l3-1%205-2%209-3h4l7-1%201-2z'/%3e%3cpath%20fill='%23fbcd83'%20d='m273%20249%201%202%203%208%201%203q3%209%208%2014%206%206%204%2013%200%207-7%2010-6%204-14%202l-12%202v-2h-2l-24%201h-49l-5%201%202%202q4%202%204%207h-4l-1-4q-11%201-20%207-6%203-13%202l-4-3q-2-5%202-11l1-5q-3-3-7-4-12-1-22%205l-8%208q-4%206-12%207-5%200-10-3-3-5-1-12l3-6v-5l-2-4-1-10q3-2%206-1h25a154%20154%200%200%200%2054-9c32-10%2070-16%20104-15'/%3e%3cpath%20fill='%23455e65'%20d='m190%20488-2%205-9%201v4l2%201h2l3%201%205%204q2%205-1%2010a19%2019%200%200%201-20%2011q-5-1-9%203l-2%202-2-1%203-4-3%203-3%202-4-1%201-4%201-3%204-5q-6%206-14%207l1%205%205-1-2%206-2%201v-4l-3%205h5v11l1%2010-1%201%203%201v-4l4%201%205%2010q3%204%208%206l2%201v1h-8v2H18l6-7%201-2-5-1q4-9%2013-13l3-1%203-1%202-1v2l20-14%202-1%202-2%204-2-1-2%201-5%206-3%204-2%2010-5%205-2%205-3q5-3%2010-3l2%201v2h2l16-4-1-6%2012-4%204-1%203-1%203-1%205-1-1%204-2%201%2010-1%201-2h3l1-2q1-3%205-4l9-2z'/%3e%3cpath%20fill='%23f8bd86'%20d='M0%2065q9%201%2015%208l3%2010q1%2010%207%2015l8%201%203-1q7-3%2014-2l6-1%202-4q9-9%2020-13l2-1c8-4%2021-4%2030-2q10%204%2014%2012l6-1h3l5-2h9l-6%208a37%2037%200%200%200-9%2035h2v2q1%205%204%208v1l-90%203H0z'/%3e%3cpath%20fill='%23f77e3a'%20d='M276%20301q-5%205-11%206-7%201-11%207l-2%204q-2%204-6%206-6%202-7%208-1%207%203%2014%208%207%2019%209l7%204-1%207q-10%2011-25%2012l-15-2q-12-2-23%200l-9-2h-3l-6-2q-27-7-55-9v3h-2v-2l-17-4-7-2%202-3h4l3%201h3c9%201%209%201%2013-2l2-4q5-5%2012-6h3l-1-2v-9q7-7%2016-9h17c6%200%206%200%209-2l-1-5-2-1-3-2-1-7-5-5%2010-1h68l9-1z'/%3e%3cpath%20fill='%23edd7b6'%20d='M320%20220v173q-9-2-13-11v-12l-3-2q-6-4-8-13v-2l-1-2-4-1-3-2%201-3-3-1v-2l-6%201h-3l-3%201-1%202-7%201-2-1h-2l-1%202-1%202h-2l2%205q-11-1-20-10-2-6-2-13%202-5%206-8l4-3%205-6q3-6%208-8l10-3%208-5%204-2q6-3%206-6%202-8-3-15l-4-5q-5-4-6-12l-1-2-2-8h-6v-1h7v-3q3-8%2010-13c9-6%2024-12%2036-12'/%3e%3cpath%20fill='%23f8bd86'%20d='M8%20302h39l-1%204h-2l1%205h8v2l4%201v3c-2%2016-2%2016%202%2021l7%204-2%208%204%202-1%206h-2l1%204-1%206%202-1%206%202-1%204%203-1%202%202q4%204%2010%203l3%203c2%209%202%209%200%2012l-5%206-3%204-3-1a154%20154%200%200%200-44-4H20l-1-3-2-4-1-2%201-2h-3l-12-4v-2H0v-77z'/%3e%3cpath%20fill='%23afd6db'%20d='M0%20190h91l2%206%204%207q2%204%200%2010-3%209-11%2013h-6q-19-2-33%2011l-2%201q-6%208-5%2017l-2%203%203%203v6l6%204v1H0z'/%3e%3cpath%20fill='%23f26838'%20d='M283%20409q10%206%2013%2018%203%207%208%2011l16%201v68l-10-3h-10l-6%201h-2l-5-1-1%203q-4%204-8%204-11%200-19-8v-2l-2-1q-6-4-8-12a41%2041%200%200%201%209-33l2-3%205-4q1-6-3-13-2-4%201-8%202-4%208-6h5q-1-4-6-6l2-5q6-2%2011-1'/%3e%3cpath%20fill='%23afd6db'%20d='m127%20138%203-1c7%200%207%200%2010%203l2%203%203%203h2l-1%205c-5%204-5%204-8%204v2l-1%206q-1%204-5%206l-1-1-1%202c-5%205-13%204-20%205l-6%201-12%201H64l-64%201v-37l37-1h2l21-1z'/%3e%3cpath%20fill='%23f78e39'%20d='M75%20465h15a698%20698%200%200%201%2081%205q12%200%2020%207l3%205q-5%206-14%207c-9%201-9%201-13%204l-1%202h-3l-1%203-7%201h-4l1-2h2l1-4-2%201-8%202-2%201-15%204v3l2%201q-4%204-9%205l-4%201h-7l1-2q-7-1-12%203l-4%201-4-18h-2l1%2017-2%201-1-2-7-19-1-2q-6-11-15-21l-1-3z'/%3e%3cpath%20fill='%238dc3be'%20d='m114%20417%203%203%202-1%204%201%202%202v2l10%203v2h2l-1%204%205-2v2h2l-1%204%202-1q5%200%209%205l23%2023%203%203%201%202-1%203h-2c-56-8-117-12-173%204l-4%201v-18q5-2%2010-1h8l-1%204h2l30-1%202-2-2%201-9%201v-1l7-2-3%201q-11%203-23%202v-2h4l5-1h2q10%200%2017-6%202-2%206-2l10%202q29%206%2057%200l-3-1%201-6-3-1-4-4-2-1-2-8h2v-2h-2v-2h-2l-1%203h-1l1-8c4-5%204-5%208-5'/%3e%3cpath%20fill='%23849377'%20d='M132%20524h5l-1%204h2v-3l4-1%201%205%205-1-2%206-2%201v-4l-3%205h5v11l1%2010-1%201%203%201v-4l4%201%205%2010q3%204%208%206l2%201v1h-8v2H54l3-5%202-4%203%203-1-3%205%201v-3h4l3-1h2l1-2-3-1h3l4-1%202-4h3l2-1%201-4%205-5%202%202-4%204%203-2%203-2%202%201v-2l4-2q4-1%206-5l1-3%208-1%201-2h2l1%201q5-1%208-6l3-2z'/%3e%3cpath%20fill='%23e2e5e1'%20d='M320%20220v64q1%203-2%205l-2%205-2%205h-21l-1-3-3-1v-3q2-12-7-21-5-4-6-12l-1-2-2-8h-6v-1h7v-3q3-8%2010-13c9-6%2024-12%2036-12'/%3e%3cpath%20fill='%23455e65'%20d='m309%20514%203%201%208%205v56h-53v-1h2l19-4v2l3-1-2-2%206-2v-2l-2-1%201-2h-3v2l-7%201v-3l-1-6-1-3-3-1v-7l-3%204-5-5v-3h-2l8%2011-6-2-1%202q-3-3-4-7l1-6%204-2%201-2%201-2h4l1-3%204-1v2l10-7-4%201v-6q8-10%2021-6'/%3e%3cpath%20fill='%23f78e39'%20d='m48%20466%206%201%206%2012%203%206%209%2019v2l2%2010h-2l-1%203-7-2-3-9h-4v6l-3-1-1-2-2%202-5-2v-4h-2v3l-13-4-2-4-1%202-18-4-3-1-7-2v-20l41-10zM8%20302h39l-1%204h-2v10q1%206-2%208-6%204-13%204-4%201-7%205v6q3%204%208%205%207%202%2010%209l1%205-7%206h-9l-1-1-7-3h-4v3q-5%202-10%201l-3-2v-59z'/%3e%3cpath%20fill='%23455e65'%20d='M0%20190h91l4%2020-61%201H20q-8%201-16-2v2l-4%201zm218-2h99l-9%207q-2%202-2%205v8h-33l-16%201h-43l1-4%201-5%201-2v-3l1-2z'/%3e%3cpath%20fill='%23fbcd83'%20d='M0%20272h45q10%200%2016%207%202%206%201%2012-3%207-11%2010l-4%203-1-1H0z'/%3e%3cpath%20fill='%23455e65'%20d='M266%20480h10v4l25%201-1-3%201-2h10l9%201v26l-10-3h-10l-6%201h-2l-5-1-1%203q-4%204-8%204-11%200-19-8v-2l-2-1q-5-4-8-12v-7z'/%3e%3cpath%20fill='%23f77e3a'%20d='m123%20467%2044%202c18%202%2018%202%2024%208l3%205q-5%207-13%207c-10%201-10%201-14%204l-1%202h-3l-1%203-7%201h-4l1-2h2l1-4-2%201-7%202-2%201-3%201h-2l-5%201-5-13-1-4-3-6v-2z'/%3e%3cpath%20fill='%23fbcd83'%20d='M320%20172v17l-102-1c-1-9-1-9%201-14l33-1h15z'/%3e%3cpath%20fill='%23f77e3a'%20d='M262%20429c11%200%2011%200%2014%202l2%207%201%203q3%207%203%2014l-3-1v3h2l2%201%201%205h2l1%207%203%203-2%202v3l8%202h5v5h-26l1-5-27%201q1-18%2013-31l3-2q1-6-3-13z'/%3e%3cpath%20fill='%23fbcd83'%20d='m101%20176-5%209-3%205H0v-12l31-1h28l5-1z'/%3e%3cpath%20fill='%23455e65'%20d='m114%20417%203%203%202-1%204%201%202%202v2l10%203v2h2l-1%204%205-2v2h2l-1%204%202-1q5%200%209%205l23%2023%203%203%201%202-1%203-8-1h-3l-6-1-1-3%204-3-5-5-1%201-3%202-1-3%202-3h3l-1-2-4%201-1-2-1-2h-2v2l-3-1v-3h-2v2h-2v-2l-1-2-7-2v-2h-2l1-4h-3l-1%202-9-4v-4l-2%201-1%203c-9-3-9-3-10-6h2v-2h-2v-2h-2l-1%203h-1l1-8c4-5%204-5%208-5'/%3e%3cpath%20fill='%23849377'%20d='m53%20450%2017%203%202%201%206%201q-7%203-15%200l14%204v2h-2v4h-4c-45%205-45%205-67%2011l-4%201v-18q5-2%2010-1h8l-1%204h5l27-1%202-2-2%201-9%201v-1l7-2-26%203v-2h4l5-1h2q10%200%2017-6z'/%3e%3cpath%20fill='%238dc3be'%20d='M82%20402q11%200%2021%205v2h5l3%201%208%202%201%203%204%202c24%2011%2050%2032%2063%2055v2l-7-1-2-5-7-8-5-6q-9-11-21-17h-3l1-4h-2v-2l-5%202%201-4h-2v-2l-4-1q-4%200-7-4l-6-2-2%201-1-3q-4%200-7%203-3%204-3%208l-1-2-4-3h-4l-2-1v-4h-2l-1%203-1-2-6%201%201-3%202-1-1-6-4-2z'/%3e%3cpath%20fill='%23f8bd86'%20d='m303%20319%206%201v3l4%201v2l7-1v20c-9%200-9%200-12-2q-5-2-12-2l-1-2-1-2-1-3-3-5v-6q5-4%2012-3z'/%3e%3cpath%20fill='%23f26838'%20d='M261%20451q6%202%208%209l1%202q5%208%206%2017l-10%201h-2l-15%201q2-17%2012-30'/%3e%3cpath%20fill='%23d3c9b8'%20d='m297%20442%203%202c4%202%204%202%2020%202v32c-10-4-14-7-18-17l-4-14z'/%3e%3cpath%20fill='%23f77e3a'%20d='m91%20467%205%202%202-2%208%2011%203-1%202%206%202%203%204%2018q-2%204-8%204h-3q-6-12-9-25l-5-12z'/%3e%3cpath%20fill='%23f78e39'%20d='M146%20302h26v3h3l6%203v3l-3-1v-2q-11%200-20%207-6%203-13%202l-4-3c-1-12-1-12%205-12'/%3e%3cpath%20fill='%23e7eeee'%20d='M320%20189v22l-2%204-7%202-2%201-9%201%201-2%201-2%202-3%201-10%201-7q6-6%2014-6'/%3e%3cpath%20fill='%23edd7b6'%20d='m174%20175%201%204v3l-1%207h-25l-1-7h2v-6z'/%3e%3cpath%20fill='%23f26838'%20d='M320%20360v33q-9-2-13-11-2-7%201-13c8-9%208-9%2012-9'/%3e%3cpath%20fill='%23f8bd86'%20d='m103%20387%207%202%202%208h3l-5%205%203%206%209-1h3l-1%203-3-1%201%203c-4%201-4%200-8-1l-6-1-3-1h-2v-2l-6-1q-2-7%201-13z'/%3e%3cpath%20fill='%23f26838'%20d='M0%20547q3%202%202%205l3%201%201%203%202%202h4l4%204v2h2q-1%205-5%208l-2%202-2%201-1%201H0z'/%3e%3cpath%20fill='%238dc3be'%20d='m156%20516%203%201-2%201q-5%205-7%2011%206%200%2010-5l2%201-6%207q-7%2011-4%2024h-3l1%205-2-1-5-2%204-1-2-3q-1-9%201-18l-3%201-2-1q2-6%204-6v4l2-5-5%201v-6z'/%3e%3cpath%20fill='%23f26838'%20d='m17%20356%201%201%201-2%2021%201-3%206q-6%204-12%202l-1-1-7-3h-4v3q-5%202-10%201l-3-2v-5q9-2%2017-1'/%3e%3cpath%20fill='%23849377'%20d='m111%20509%201%204-2%201-22%2010-7%203-3%202-8%203-2-3q1-3%204-5l3-1%204-2%202-1%208-4%205-2%205-3q6-4%2012-2'/%3e%3cpath%20fill='%23edd7b6'%20d='M0%20380h2v2l9%202%206%202v3l2-1%201%209-20%201z'/%3e%3cpath%20fill='%23f78e39'%20d='M177%20471q7%201%2013%205l4%206q-5%207-13%207l-7-1h2l-1-2-2-7-1-3v-2l4%204v-3zm143-146v20c-10%200-10%200-14-4v-9q5-7%2014-7'/%3e%3cpath%20fill='%23fbcd83'%20d='m68%20527%202%204q-1%204-6%207l-16%2011-7%203v-2l-2%201-2%202-2%201-2%201-2-1q17-16%2037-27'/%3e%3cpath%20fill='%23edd7b6'%20d='m234%20343%202%202q6%207%2014%2011l3%203q1%205-2%208l-4%202q-4-2-6-6l-3-2-4-6z'/%3e%3cpath%20fill='%23f78e39'%20d='M88%20302h22l-5%207-2%202q-6%204-13%203l-5-3-1-8z'/%3e%3cpath%20fill='%23849377'%20d='m155%20493-1%204-2%201%202%202-2%201-4%203c-6%204-6%204-9%204l-3-4-7%202-1-5%2012-4%204-1%203-1%203-1z'/%3e%3cpath%20fill='%23f26838'%20d='m266%20360%202%201-1%205q-12%2011-29%2012v-2l6-4%203-2%208-5%209-4z'/%3e%3cpath%20fill='%238dc3be'%20d='M269%20542h2l3%205%202%202%204-4v4l1%206%202%201%201%206v4l2%201-7%202-2%201-9%201v-2l2-1%203-1%203-2%205-2-1-1q-2-2-2-5h-2l-5-3v-3h4l-1-1-2-2-2-2z'/%3e%3cpath%20fill='%23849377'%20d='M266%20480h10l-1%205h-2l-7%201h-8l-4%204v-4h-4l-1%202v-7z'/%3e%3cpath%20fill='%23f77e3a'%20d='M298%20445h1l1%203q1%2015%2012%2026l8%204v3h-6l-4-4-3-2q-8-8-10-20-1-5%201-10'/%3e%3cpath%20fill='%23f8bd86'%20d='M86%20176h15l-5%209-2%202-3%203%201-9-2%201-10-1-1-4z'/%3e%3cpath%20fill='%23afd6db'%20d='M166%20498q8%200%2015%205l1%207q-4%203-10%202v-6l-2-1-4-2z'/%3e%3cpath%20fill='%23849377'%20d='m190%20488-2%205-7%201-4%202h-14l3-1%201-2q1-3%205-4l9-2zm111-8h10l9%201v6l-36-1v-1h17l-1-3z'/%3e%3cpath%20fill='%23fbcd83'%20d='M276%20480h25v5h-26z'/%3e%3cpath%20fill='%23c9dad8'%20d='m294%20542%207%204v6q-4%203-7%202l-6%201q-1-7%202-12z'/%3e%3cpath%20fill='%23f77e3a'%20d='M312%20439h8v7l-9%201h-4q-3%201-5-2h3l-3-5q5-2%2010-1'/%3e%3cpath%20fill='%23d3eced'%20d='M28%20212h28v1h-7v3c-5%204-5%204-9%204q-8-2-12-8'/%3e%3cpath%20fill='%23849377'%20d='M41%20550q-1%206-5%208l-3%202-4%204-4%204-5-2q4-9%2013-13l3-1z'/%3e%3cpath%20fill='%238dc3be'%20d='M291%20563h3l1%205-2%201-2%201v3h-3v-2l-3%201q-13%204-28%204v-1h2l21-5%203-1%203-1%202-1z'/%3e%3cpath%20fill='%23e2e5e1'%20d='m267%20267%209%209%202%202%202%205-5%202-6-4q-2-6-2-14'/%3e%3cpath%20fill='%23f77e3a'%20d='m113%20474%203%203%201%202%201%203%201%203%201%203%203%2015h-3l-2-4h-1l-1-6-4-13z'/%3e%3cpath%20fill='%23fbcd83'%20d='M128%20502v2l2%201q-4%204-9%205l-4%201h-7l1-2-2-1c13-6%2013-6%2019-6M22%20566l3%201-7%209H8l3-3%201-2%205-3v-2z'/%3e%3cpath%20fill='%238dc3be'%20d='m50%20458-4%202%206-3%202%201q-9%208-21%206l-5-2%2011-4z'/%3e%3cpath%20fill='%23f26838'%20d='M319%20404h1v19c-5-5-5-5-6-9q1-6%205-10'/%3e%3cpath%20fill='%23fbcd83'%20d='m167%20490%203%201-4%204h-3l-1%203-7%201h-4l1-2h2v-2l1-2%205-1z'/%3e%3cpath%20fill='%23455e65'%20d='M185%20492h2v2h-2z'/%3e%3cpath%20fill='%23849377'%20d='m73%20561%202%201Z'/%3e%3cpath%20fill='%23455e65'%20d='m146%20528%202%201-2%201z'/%3e%3c/svg%3e",
	treehouse: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='576'%3e%3cpath%20fill='%239e7240'%20d='M0%200h320v576H0z'/%3e%3cpath%20fill='%23df8c3d'%20d='M0%200h320v270l-2-4-8-6-2-2v-4h2l2-4%203-5-5-4q-4%201-6%205l-4%203-4-2-3-3-2-1-4-5-6-6-2-2-16-15-3-2-1-4%2011-3-3-5h-4l-2%201-5%201h-6l-10-9-6-6-8-7q-7%201-12%207l-3%204-2%201-10%209-27%2022-2%201-11%209-2-1%202-1c7-6%207-6%208-10v-5q0-2%202-3l6-2h-8v-7l-6-1-15-6q-7-4-15-4-9%200-15-6l-10-3q-5%201-8-3c-3-5-3-5-3-8h-2v-2l-1-2-4-1-4-2q-5-3-11-1h-2l-3-5q-7-19-25-27l-16-3h-7l-6-1v-17l-6%201-8-2z'/%3e%3cpath%20fill='%23a75d36'%20d='m150%20238%203%201-4%204%201%202%2013%2016%208%2011%206%209c4%208%204%208%208%2010q9%202%2020%201l5%202-2%201-4%203q0%203-4%205t-4%205l1%204-2%204v3l7-1v15l-1%203-2%2010-1-2v3l-1%203-3%202q-4%201-4%206l1%204v8h3l2%206%205%201%201%2015h-53v11l-1%208h-7l-1-5h-10v10l-1%203v6l-1%203h-7l-1-21H87c-6%200-6%200-8%202l-1%201h-2l-1%2026%205%201v8l-6%201v6l6%202v6q-6%202-13-1h-8l6%207%202-1h6l1%2013%207%201v6l-7%201v11l7%202v2q-1%205%204%2010l7%204q8%206%2012%2016%201%2010-4%2019l-7%208q-2%202-2%206l4%206%203%206H0V247h68l11%201h37l4%201h7c8%200%208%200%2012-2l2-2h2v-2l3-3%202-1z'/%3e%3cpath%20fill='%23557161'%20d='M90%20406h24l7%201v21l7-1v-9l1-2v-5l1-5h10l1%205h7l2-5h29l91%202v9l1%207v18l1%2039%206-5-7%2011%202%201-1%202v10q4-1%206-4%206-5%2013-8%206-1%208-6l2-11q5-16%2018-27h1v132l-79%201H116c-16%201-16%201-20-2q-6-6-6-15l3-3q10-8%2010-21%200-10-7-18l-9-5-6-5v-9h-3l-5-2v-9l1-3h7v-6h-3l-4-1-1-8v-5l-4%202h-4l-7-8v-1l20%202h2l-2-7-4-1-1-4%201-2%206-1v-7l-5-2v-21q0-4%203-7%205-4%2012-2'/%3e%3cpath%20fill='%23cc7737'%20d='m41%2070%208%206%202%202%202%202%2017%2017q7%209%2018%2013v2h-3l-4%201v7l1%202v2l3-1%2011-2%204-1v-2h2l1-2%204-3%202-3%206-1q2%201%205-3l2-2%207%201%201-7h59v-9l1-3v-4l1-11h29v25l-10%202-4%201h-2l6%209%202-6c8%204%208%204%2010%207v2h3v21l11-1q7%200%2012%202l3-1%206%202%205%203q4%205%207%204h2v-9q4-2%2010-2h8l-1-8q7%200%2012%206l5%202%203%201%201%2016-1%203v6c-16%200-16%200-21-3l-4-5-2-2h-2l-2%209q4%206%2010%2011%204%202%204%206l3%201h5l2%201%207%202v11q-9%2010-21%2016l-8%206q-4%204-10%206l1%201%208%208%209%208%209%209%206%205%201-2q1-4%205-7%204%200%206%203l2%204-2-1-6-2-3%203-5%205-4-2-3-3-2-1-4-5-6-6-2-2-16-15-3-2-1-4%2011-3-3-5h-4l-2%201-5%201h-6l-10-9-6-6-8-7q-7%201-12%207l-3%204-2%201-10%209-27%2022-2%201-11%209-2-1%202-1c7-6%207-6%208-10v-5q0-2%202-3l6-2h-8v-7l-6-1-15-6q-7-4-15-4-9%200-15-6l-10-3q-5%201-8-3c-3-5-3-5-3-8h-2v-2l-1-2-4-1-4-2q-5-3-11-1h-2l-3-5q-7-19-25-27l-16-3h-7l-6-1v-17l-6%201-8-2v-4l14-1v-7l-1-6h2l-2-4h3q6%208%208%2017l30%201h12l4-1h3l-1-3-2-1q-3-1-4-5h-2l-3-3-11-13c-9-9-9-9-9-12'/%3e%3cpath%20fill='%239e7240'%20d='M248%20215q4%202%207%206l11%2010%204%204v2l4%202%204%204%203%203%202%202%203%203%206%206q-5%2013-15%2024l-3%205-8%208h-22l-7-1h-17v2h5l-2%205h7v-3l7-1%204%206%202%204%202%203%206%208%201%204h-2v5h-4v7l9%203-1%2010q-3%203-7%203l-1%2041-10%201-1%201%2046%201%201-3h4v22h2v-17l1-3h7l11-2q2%202%201%205v3l1%203v9l2-22%205%201%201%2024%201%2019%201-17h1v12l1%204c0%2011%200%2011-2%2015l-6%205q-9%2013-13%2029-1%205-5%207l-6%203q-9%205-16%2012l-2-4v-11l5-9-5%204-2-74-3%203-1-3-87-1h-26l-4%202%201-17h53l-1-5v-10h-3l-1%202q-4-4-3-9h-3l-1%202v-11c-1-6-1-6%202-10l5-1v-6l3-2%201-9v-7l1-8-2%201h-6l2-8-1-2v-2l8-7%201-3%201-2%203-1-1-1h-4c-15%201-15%201-20-2l-9-13-6-8-10-16c13-20%2035-24%2057-30l18-6%206-2%202-1z'/%3e%3cpath%20fill='%23cc7737'%20d='m150%20238%203%201-4%204%201%202%2013%2016%208%2011%206%209c4%208%204%208%208%2010q9%202%2020%201l5%202-2%201-4%203q0%203-4%205t-4%205l1%204-2%204v3l7-1v15l-1%203-2%2010-1-2v3l-1%203-3%202q-4%201-4%206l1%204v8h3l2%206%205%201%201%2015h-53v11l-1%207h-2l-1-12-3-1%201-4h2l-3-5v2q-5%203-10%201-4-8-3-17v-38l1%202%203%204%202%204h17q12%201%2022-4h3v-3l1-5q4-5%203-11-2-4-7-5h-22l-15-1h-2l-1-7v-4l-3-1q-3-6-2-13l42-1-9-13-10-16q-7%202-11%207l-1%202q-5%207-13%2012l-11%2011q-3%204-6%203h-2v2h-2l-20%203H76q2-4%206-7l2-2%202-1-2-2%203-2%2018-14%2018-15c8-5%208-5%209-8H56l-14-1H14l4%203%202%202%208%205%203%201%203%201%207%202%204%202%206%203v71h2v2l5%2013%208%2020%201%203v12H55q-7%202-12-2-3-3-3-8v-4l-5-1-1%202c-9-2-22-12-27-20l-2-6-1-7-2-6q-2-14-2-29v-62l79%201h37l4%201h7c8%200%208%200%2012-2l2-2h2v-2l3-3%202-1z'/%3e%3cpath%20fill='%23698960'%20d='M0%200h301q5%2013-1%2024-8%2014-23%2019l-2%201v-2l-1-3-4-1-1%202-2-6h-3l-1%203-4-2-3-3-6-5-3-3-4-3v-3l18-3-1-4h-2l-7%202-3%201h-2l-3%201h-6l-6-5-1-1-4-4-10%209-4%202v2h-2l-2%204q-4%205-10%205h-5v5l4%201-4%204-2%202-2%201-3-1-1-2-4%201%202%207-2%201-18%2015v1h2q7-1%2012%203l2%206q-3%205-9%207l-8%204-2-3-2-3-1-2q-4-8-14-11l-3-3v-2l-2%201q-19%206-37-2-9-6-14-15l-2%201q-11%207-26%205-18-4-29-21l-4-13-3%202q-7%203-14%202v3c1%2016%201%2016-4%2022H3l-2%204H0z'/%3e%3cpath%20fill='%23849881'%20d='M320%20444v132H138c4-9%204-9%208-13l5-7q1-3%206-4l3-3%205-2v-2l12-6q24-14%2052-9h7l5-6q1-4%206-5l3-2%2014-5%203-1%202-5%205-6%201-2q8-8%2019-11l5-5%201-4%201-5v-2c2-6%2011-27%2019-27'/%3e%3cpath%20fill='%236e7249'%20d='m0%20112%2010%201h4l1%207v2l-1%208h2c18%200%2030%202%2043%2015q15%2016%2013%2037%200%209-4%2017l3-1q8-3%2016%201%2011%205%2015%2016l-1%202h2q16%205%2025%2018%204%207%204%2014H77l-11-1H50l-50-1z'/%3e%3cpath%20fill='%23bb8d4a'%20d='M27%2013v2q3%2014%2013%2023%2016%2011%2036%209l12-6%201%202q6%2012%2020%2016%2016%203%2031-1%203%206%203%2011l-1%203h2l-2%208q-4%205-4%2011l2%204v3h-10l-1%207-4%201v-2l-5%204-7%203h-4l-2%203-4%202-1%202h-2v2q-4%203-10%202l-8%202v-3l-2-1-1-6q4-4%207-3l2%201-6-4q-6-3-11-8l-1-2-4-3-6-7-4-4-5-5-2-2-2-2-2-2-4-3%2018%2023%202%201%203%204h2l4%205%202%201v2l2%201q-3%202-8%202H52l-28-1-4-9-2-4-2-5-2%201%201%203h-2l1%202%201%207-1%202v2l-14%201-1-51c0-10%200-10%204-14l3-3%203-14v-8l6-1h3z'/%3e%3cpath%20fill='%23d7c275'%20d='m204%2099%203%205%202%202%201%202%202-6c8%204%208%204%2010%207v2h3v21l11-1q7%200%2012%202l3-1%206%202%205%203q4%205%207%204h2v-9q4-2%2010-2h8l-1-8q7%200%2012%206l5%202%203%201%201%2016-1%203v6c-16%200-16%200-21-3l-4-5-2-2h-2l-2%209q4%206%2010%2011%204%202%204%206l3%201h5l2%201%207%202v11q-9%2010-21%2016l-8%206q-4%204-10%206l1%201%208%208%209%208%209%209%206%205%201-2q1-4%205-7%204%200%206%203l2%204-2-1-6-2-3%203-5%205-4-2-3-3-2-1-4-5-6-6-2-2-16-15-3-2-1-4%2011-3-3-5h-4l-2%201-5%201h-6l-10-9-6-6-8-7q-7%201-12%207l-3%204-2%201-10%209-36%2029-4%203-2-1%202-1c7-6%207-6%208-10v-7l18-6v-22l1-11v-42l3-10%202-1q-2-6-4-6l1-3%205%203%202%202%202%202v2l6-1-1-2-4-7-2-2-2-3-1-2-1-4%204-1%202-1z'/%3e%3cpath%20fill='%234b5c5a'%20d='M149%20448q9%203%2013%2010v2h2l7%204%209%202v-6h8l1%204%201%203v2l1%202v2l-2%202%2011%202%205%202%201%206%206%202v10q-3%203-7%202v2l-4%202h4l1%206-7%203h3l4%201v15l-8%203q-9%202-16%206l-2%201-9%205-6%202v2l-4%204-3%201-4%203q-2-1-4%203l-1%202-6%209-3%205-6%203h-21c-13%201-13%201-17-2q-6-6-6-15l3-3q9-8%2010-19%201-6-3-13v-3l3-3q19-12%2027-32l2-3q6-9%209-20l3-6%202-5zm-15%2025%201%202q-5%2013-14%2023h-2l-2%204-3%204-2%201-2%203-2%202-10%209-3-3v-2l3-3q14-12%2024-25l7-9%202-2z'/%3e%3cpath%20fill='%235b3832'%20d='M248%20215q4%202%207%206l11%2010%204%204v2l4%202%207%207%202%202%203%203%206%206q-5%2013-15%2024l-3%205-8%208h-22l-7-1h-17v2h5l-2%205h7v-3l7-1%204%206%202%204%202%203%206%208%201%204h-2v5h-4l-1-4h-10q-5%200-9-3l-2-4-9%203h2q-1%204-6%207l-9%201v-8l-2%201h-6l2-8-1-2v-2l8-7%201-3%201-2%203-1-1-1h-4c-15%201-15%201-20-2l-9-13-6-8-10-16c13-20%2035-24%2057-30l18-6%206-2%202-1z'/%3e%3cpath%20fill='%23849881'%20d='M0%20405h13l3%205%207%209q4%205%203%2012h2q3-1%205%202v12l-6%201v6l6%202v25l-8%201v3l8%201v7h-5l1%206%204%201v19h-5l-1%203v3l3%201%203%202%201%208v7l3%201%202-1%201-6v-6l7%202%2017%205q4%203%203%209v6h4l1-10%208-1v-5l-4-1-4-3v-28h9l1%203q3%206%209%209%2010%206%2013%2016%201%2010-4%2019l-7%208q-2%202-2%206l4%206%203%206H0z'/%3e%3cpath%20fill='%23665c4b'%20d='M13%20249h31l14%201%2074%201-6%208-3%202-3%202-7%205-27%2022v3l-4%204-6%205%204-1h5l2-1%2015-1h6v85l-1%207H76l-1-11-4%201q-3%200-5-4l-1-2-1-2v-2l-2-5-1-3-5-11q-3-5-3-12h-2l-1-71-16-6c-17-6-17-6-21-14'/%3e%3cpath%20fill='%23df8c3d'%20d='M231%20292h14l69%202h6v87l-1%2053c-5-5-3-15-3-21v-24l-5-1v14l-1%203v5l-2%201-1-20-4%201-7%201h-7l-1%2019h-2v-22l-4%201-1%202h-47l2-3h10v-42l5-1%202-1%201-5v-5h-2l-6-3v-7h4v-5h2l-2-3-3-4-1-2-7-11-2-4h-7v3h-7l1-4-4-1v-2z'/%3e%3cpath%20fill='%23698960'%20d='M205%20406h23l11%201h23l8%201v9l1%207v31l1%2026%206-5-7%2011%202%201-1%202v8l1%205q-3%207-10%2010l-7%203-10%205-2%201q-2%200-3%202l-1%202-4%205-6-1-25-1v-16h-8l8-4v-6l-7%201%203-3h4v-2q3-2%207-2l-1-10-6-2-1-12v-10l1-4z'/%3e%3cpath%20fill='%23a75d36'%20d='M301%200h19l-2%2056-2%2022v12h-21l-1-8-2-1-2-1V65h-62l-27-1v4h-5l-3-4-1-3-1-4-6%207q-5%204-11%201l-5-3-1%201h-5q0-3%202-5c15-13%2015-13%2018-13l-3-7%202-2%204%201%201%202%209-6-3-1v-5h2q10-1%2015-9h2v-2l4-3%202-2%202-2%202-2%204-3%201%201%202%202%202%202%202%202%202%202q5%203%2010%201l2-1%205-1%202-1h6l1%204-18%203v3l4%202%205%204%207%207%202%201v2h2l1-4%204%201%201%202%201%202%203%201h2l1%204q17-6%2024-21l2-9v-3z'/%3e%3cpath%20fill='%23e4e4b9'%20d='M0%20248h12v2l2%201%205%203q12%208%2026%2012l6%203v71h2v2l5%2013%209%2023v12H55q-7%202-12-2-3-3-3-8v-4l-5-1-1%202c-9-2-22-12-27-20l-2-6-1-7-2-6q-2-14-2-29z'/%3e%3cpath%20fill='%23bb8d4a'%20d='M319%2044h1v226l-2-4-8-6-2-2v-4h2l2-4%202-2%201-5-4-5q-4%200-5%203l-2%202-1%202-1%201-7-5-2-2-25-25%202-1q10-4%2017-11l7-5c10-6%2010-6%2013-10v-11h-3l-5-1h-2l-6-2-2-5-4-3c-7-6-7-6-9-10l2-9h4l3%204q5%206%2012%205l11%201v-25l-6-1-4-2-2-2-1-5-3-1-8-5-2-2q-6-5-7-13h9v-3l2-6%2011-1h19v-2q-1-22%203-44'/%3e%3cpath%20fill='%23557161'%20d='m69%20166%203%203q2%2016-4%2030l3-1q8-3%2016%201%2011%205%2015%2016l-1%202h2q16%205%2025%2018%204%207%204%2014H78l-12-1H44l-7-1v-8l-4-5v-2h-3v-2l2-1-4-3h2l-1-4h-2l-3-3q0-6%205-11h2v-2l11-3%201%202%202-1q2-2%206-2l-5-1%207-17q3-3%202-8h2v-3q1-3%204-5c5-3%205-3%208-2'/%3e%3cpath%20fill='%23a75d36'%20d='m32%20432%204%201h4l16%204%2021%203v2h3v3l-6%201v6h2l4%202v6q-6%202-13-1h-8l6%207%202-1h6l1%2013%207%201v6l-7%201v11l7%202v4h-9l1%2028%207%203%201%204-1%203h-8v10l-5%201q-2-3-2-8v-6l-3-1-22-8v12l-5%202q-2-2-2-5v-12l-3-1-4-2v-5l4-2%203%201v-19l-5-1v-6h5v-7h-8l-1-4%201-1h8v-25l-6-1-1-4%201-4h6z'/%3e%3cpath%20fill='%23a75d36'%20d='m0%20328%203%207%203%2014v2q1%207%207%2011l2%202q9%209%2019%2013l1-3%206%202v7q2%204%206%206l13%201h7v-9l8-1%201%2019%205%201-1%208-2%201-2%201-1%206v20l5%201%201%205h-4v-2h-2l-21-3c-16-4-16-4-19-3v-2l-9-1v-3q-4-9-10-16l-3-7H0z'/%3e%3cpath%20fill='%23d7c275'%20d='M174%200h127q5%2013-1%2024-8%2014-23%2019l-2%201v-2l-1-3-4-1-1%202-2-6h-3l-1%203-4-2-9-8-3-3-4-3v-3l18-3-1-4h-2l-7%202-3%201h-2l-3%201h-6l-6-5-1-1-4-4-10%209-4%202v2h-2l-2%204q-4%205-10%205h-5v5l4%201-4%204-2%202-2%201-3-1-1-2-4%201%202%207-2%202-15%2011q-5-2-9-8%201-3%204-5%206-6%208-13l1-2%202-6%201-2q3-10%201-22'/%3e%3cpath%20fill='%23e4e4b9'%20d='M0%20405h10q3%200%205%202l8%2012q4%205%203%2012h2q3-1%205%202v12l-6%201v6l6%202v25l-8%201v3l8%201v7h-5l1%206%204%201v19h-5l-1%203v3l3%201%203%202v7h-3l-21%204-6-1q-3-3-4-8v-32z'/%3e%3cpath%20fill='%239e7240'%20d='m225%20315%201%204%204%201%202%201h13l1%204v8l9%203-1%2010q-3%203-7%203l-1%2041-10%201-2%202h-9l-23-1-1-10v-5h-3l-1%202q-4-4-3-9h-3l-1%202v-11c-1-6-1-6%202-10l5-1v-6l3-2%201-4v-14l2%201%209-1%204-5-1-1%203-3z'/%3e%3cpath%20fill='%23665c4b'%20d='M130%20406h10l1%205h7l2-5h20l35%201%201%2030v16l-1%2013v13q-8%200-17-4l2-3-1-3-1-9-3%201-5-1%201%203-1%206-1-3h-3q-7-1-14-6l-5-7q-4-4-9-4l1-2v-3l3-9-2-1-2-1-2%202-2-7h-4l-2-4-5-1-2-1h-2v-10z'/%3e%3cpath%20fill='%238c442d'%20d='m173%20263%209%201%201%208h6l2-2%206%201%2020%201%208-1%203%203%207-1h7l5-1%201%202%202%202h3l1-3c9-2%209-2%2012%200l2%204h3l1-4%205%201%202%203-5%207-1%203-1%202-2%202q-5%203-11%202h-39v2h5l-2%205h7v-3l7-1%204%206%202%204%202%203%206%208%201%204h-2v5h-4l-1-4h-10q-5%200-9-3l-2-4-9%203h2q-1%204-6%207l-9%201v-8l-2%201h-6l2-8-1-2v-2l8-7%201-3%201-2%203-1-1-1h-4c-15%201-15%201-20-3l-10-14-1-2q-2-6%201-11'/%3e%3cpath%20fill='%23665c4b'%20d='M90%20406h24l7%201v21h6l-2%201q-6%204-7%2013l-10%2026-8%2014-2-3-3-1v2q-3%202-7%202l-2-1v-3l-1%202h-3l-1%203v-4h-3l-4-1-1-8v-5l-4%202h-4l-7-8v-1l20%202h2l-2-7-4-1-1-4%201-2%206-1v-7l-5-2v-21q0-4%203-7%205-4%2012-2'/%3e%3cpath%20fill='%236e7249'%20d='M13%20249h31l14%201%2074%201-6%208-3%202-3%202-7%205-27%2022v3l-4%203-4%203-1-3-5-1h-2q-4%200-7%202l-2%202v-3l-9%201v5h-1l-1-33-7-3-12-4q-12-3-18-13'/%3e%3cpath%20fill='%23cc7737'%20d='m267%20200%203%203v3l-4%202h-2l-5%201q8%2010%2018%2018l13%2013%202%202%206%206q5-1%208-5l2-3q6%202%208%206l-4%206-4%203q3%206%209%209l3%206v24l-52-1%203-5%207-10%209-12%201-2%203-5q-1-5-6-8l-2-2-2-3-3-2-8-7v-2l-2-1q-4-2-6-6l-6-5-3-4-5-4q-17%203-32%209l-7%203h-2q-5%203-11%202l-1-9q12-6%2025-9l7-3c19-6%2019-6%2029-7z'/%3e%3cpath%20fill='%23698960'%20d='m245%20407%2025%201v9l1%207v31l1%2026%206-5-7%2011%202%201-1%202v8l1%205q-3%207-10%2010l-7%203-10%205-2%201%201-9-4-1v6l-2-1-1-5h-3l2-2-1-6%204%203q5-2%205-5z'/%3e%3cpath%20fill='%23df8c3d'%20d='m178%20335%205%201%201%2019%205%202q1%206-2%2010l-2-2v6l3-3%201%209-1%203v3l-4-3v11l-22%201h-13v8l-1%2010h-2l-1-12-3-1%201-4h2l-3-5v2q-5%203-10%201-4-8-3-17v-38l1%202%203%204%202%204h17q12%201%2022-4h3v-3z'/%3e%3cpath%20fill='%23fcf7ce'%20d='M30%200h127l-5%206h-2l-2%204-3%203-2%202-2%202-2%202q-12%2014-31%2014-9%201-18-2l-2-1q-12-5-22-13Q53%207%2038%203zm173%20139h2l3%204q4%207%2012%2010l18-1-1%202q-7%2011-4%2024%203%209%2010%2014l2%202q5%204%2012%203l4-1v2h3l6%201%201%204-2-1-6-1-3%201-4%201h-6l-10-9-6-6-8-7q-7%201-12%207l-3%204-2%201-10%209-36%2029-4%203-2-1%202-1c7-6%207-6%208-10v-7l18-6v-26c0-18%200-18%203-23l6-4q7-5%208-14z'/%3e%3cpath%20fill='%236e7249'%20d='M229%20407h16l1%2011v78c0%207%200%207-2%2010l-5%202-1-1-1%204h2l1%206%201-5%204%201v7l-2%202-16-9v-4h-2l-3-1-1-3q-1-4-5-6l7-1-1-3h2v-7h-2l-1%202-1-1v-8l4-5h5v-15l-1-18-3%201-1-7v-4l3-1v2h2zm4-383%206%205%209%209%208%207%208%206-2%206-1%202-3%206-10%201h-12l-7-1h-21c-7%200-7%200-11-3l-1-3-1-3v-7l5-4%202-3%2010-7%201-1v-3l4-2%201-2%204-3z'/%3e%3cpath%20fill='%238c442d'%20d='M149%20392h33l71%201h27v10l-1%204-8%201h-3l-2%203-1-3-95-1h-18l-4%202z'/%3e%3cpath%20fill='%23df8c3d'%20d='m41%2070%208%206%202%202%202%202%2017%2017q7%209%2018%2013v2H70l-1%2014-7-10-5-6q4%2013%2012%2023v9q0%204-3%206l1%206q-4-1-6-5-9-14-25-17l-14-1-8-1v-17l-6%201-8-2v-4l14-1v-7l-1-6h2l-2-4h3q6%208%208%2017l30%201h12l4-1h3l-1-3-2-1q-3-1-4-5h-2l-3-3-11-13c-9-9-9-9-9-12'/%3e%3cpath%20fill='%23a75d36'%20d='M225%20180q4%202%206%205l16%2014%202%202v2l-2%201-9%202-4%201-18%206-12%204-6%203h-3l1%207%202%201%201%202h-2c-16%205-26%2010-37%2023l-1%201h-2l-3-4-1-1-1-2%203-1%201-7q2-6%208-10l31-26%2024-20q3-4%206-3'/%3e%3cpath%20fill='%236e7249'%20d='M301%200h19l-2%2056-2%2022v12h-21l-1-8-2-1-2-1V65h6l-1-2v-2l3-1h5l4%201v-2q-1-13%205-22-15%200-27%208-4%203-8%203l-2-2q1-3%204-4l3-2q13-5%2018-18l2-9v-3z'/%3e%3cpath%20fill='%23557161'%20d='M188%20460v2l1%202v3l2%204v2l-2%202%2011%202%205%202%201%206%206%202v10q-3%203-7%202v2l-4%202h4l1%206-7%203h3l4%201v15q-4%203-9%203l-16%206q-2-4-1-10v-7l-5%202-3%202-5%203%202%207-5-4-2%201-2%202-3%202-6%205-1-4%204-4%203-2%204-2v-2l-4-2-5-3%202-1%205%203h6l9-6%207-6h2l-2-3v-5q1-6-2-12l1-6-2-1%201-2v-8l1-3v-11z'/%3e%3cpath%20fill='%23bb8d4a'%20d='M301%20192q9%2010%2011%2025l3-3%205%201v55l-2-4-8-6-2-2v-4h2l2-4%202-2%201-5-4-5q-4%200-5%203l-3%204-1%201-7-5-2-2-25-25%202-1q10-4%2017-11l10-7z'/%3e%3cpath%20fill='%23849881'%20d='M246%20349v41l-10%201-2%202h-9l-23-1v-30l15-5%203-1%204-2%204-1c13-4%2013-4%2018-4'/%3e%3cpath%20fill='%23d7c275'%20d='M189%2057h2l3%204%201%203%201%204h5v-4h11l2%207h-23v17l-1%204v6l-6%201h-5l-39-1c-4-8-4-8-2-13l1-3%204-6%201-4h-2V62q11%202%2016%2011l4%208%203-2%203-1%203-2%206-2v-8q3-2%208-2l1-2z'/%3e%3cpath%20fill='%23fcf7ce'%20d='M0%20248h12v2l2%201%205%203q12%208%2026%2012l6%203v17l-1%206c-21-1-21-1-30-6q-8-5-20-5z'/%3e%3cpath%20fill='%238c442d'%20d='M128%20317h40c9%200%209%200%2012%203q3%204%202%209l-4%207v3l-3%204q-11%206-22%204h-4c-13%200-13%200-16-3q-3-5-2-10l4-2-9-6z'/%3e%3cpath%20fill='%23cc7737'%20d='m267%20200%203%203v3l-4%202h-2l-5%201q8%2010%2018%2018l12%2011%202%202%204%205-1%206%202%201-3%206-14-13-4-4-2-2-3-2v-2l-2-1q-4-2-6-6l-6-5-3-4-5-4q-17%203-32%209l-7%203h-2q-5%203-11%202l-1-9q12-6%2025-9l7-3c19-6%2019-6%2029-7z'/%3e%3cpath%20fill='%23d7c275'%20d='m143%20244%204%205q-1%205-5%209l-10%2013-1%201h-3l-4%204-1-6h-2l-1%202-1%201%201%204q0%205-3%208l-8%208-4%204q-6%204-12%204h-3l-14%201q2-4%206-7l2-2%202-1-2-2%203-2%2018-14%2018-15c8-5%208-5%209-8H55l-14-1H12v-2H0v-1l79%201h37l4%201h7q7%201%2013-2z'/%3e%3cpath%20fill='%23cc7737'%20d='m40%2071%2013%2013%204%205%202%204%202%201%203%204h2l6%206v2l2%201q-3%202-8%202H52l-28-1-4-9-2-5-2-3%2015-13%202-2z'/%3e%3cpath%20fill='%23e4e4b9'%20d='M72%20503h9l1%203q3%206%209%209%2010%206%2013%2016%201%2010-4%2019l-9%2010q-4%201-6-2l-2-2-9-7-2-2v-6l8-1v-5l-4-1-4-3z'/%3e%3cpath%20fill='%23cc7737'%20d='m129%20336%201%202%203%204%202%204%2014%201v8h2v10l3%201q5%2010%203%2020h-2l1%203-2%201%207%201v1h-12l-1%2018h-2l-1-12-3-1%201-4h2l-3-5v2q-5%203-10%201-4-8-3-17z'/%3e%3cpath%20fill='%234b5c5a'%20d='m180%20520%201%2017-4%203-2%201-3%202-2%201-5%201v2l-4%204-3%201-4%203q-2-1-4%203l-1%202-6%209-3%205q-2%203-5%202h-9c1-16%2011-26%2022-37l5-1%204-3q3-4%208-6l4%203-3-3q2-4%206-6l3-2z'/%3e%3cpath%20fill='%23557161'%20d='m230%20465%201%202%205-1v2l9-1%201%2031-1%206-6%204-1-1-1%204h2l1%206%201-5%204%201v7l-2%202-16-9v-4h-2l-3-1-1-3q-1-4-5-6l7-1-1-3h2v-7h-2l-1%202-1-1v-8l4-5h5z'/%3e%3cpath%20fill='%238c442d'%20d='M108%20298h4l-1%2093h10v16H80v-7l-5-1v-17h1v9l31-1z'/%3e%3cpath%20fill='%23849881'%20d='m225%20315%201%204%204%201%202%201h13l1%204v9l-11%204-19%207h-2l-5%202-7%201v-20q0-2%202-3l5-1q3%200%205-2l2-3-1-1%203-3z'/%3e%3cpath%20fill='%239e7240'%20d='m0%20328%203%207%203%2014v2q1%207%207%2011l2%202q9%209%2019%2013l1-3%204%201-3%201-1%206c-2%206-2%206-5%208H20l-1-1v-6l-1-1v3h-2l-1%205H0z'/%3e%3cpath%20fill='%238c442d'%20d='m151%20261%204%204%202%202%201%203%2010%2014%204%208h-53v-3l5-4%2011-9%202-2%204-6%204-4%202-2z'/%3e%3cpath%20fill='%23a75d36'%20d='M191%2071h29v25l-10%202-13%203q-5%202-11%202v-4l3-1v-9l1-3v-4z'/%3e%3cpath%20fill='%23665c4b'%20d='m283%20463%206%202%201%202%204-1-1%206h7q2%205%200%2010-5%205-11%208-9%204-16%2012l-2-4v-11l5-9-5%204v-19z'/%3e%3cpath%20fill='%239e7240'%20d='m293%20199%205%2011%202%204%202%205%202%203v7h-3l-1%203h-3l-2%204-2-1%201%203-7-5-8-7q-6-5-11-12l2-1q10-4%2017-11%202-3%206-3'/%3e%3cpath%20fill='%238c442d'%20d='M299%20266q7%204%2013%2010l2%202c6%206%206%206%207%2010l-1%206-39-1%204-8%202-2%201-2%202-2z'/%3e%3cpath%20fill='%23e4e4b9'%20d='M40%20499q13-1%2025%203l1%204v23l-18-6-8-3z'/%3e%3cpath%20fill='%239dab7f'%20d='m245%20407%2025%201v24h-14v2l-11-1z'/%3e%3cpath%20fill='%236e7249'%20d='m38%2060%202%202q9%207%2019%207l-1%2015q-6-2-10-8l-1-1-4-4q-6%202-10%206l-2%203-3%202-12%209-4-3%205-10q2-7%200-15h3l13-2z'/%3e%3cpath%20fill='%23a75d36'%20d='m259%20211%208%207%2010%209%2018%2018-1%206%202%201-3%206-18-17-2-2-3-2v-2l-2-1q-4-2-6-6l-6-5-8-8v-2l4-2%203-1z'/%3e%3cpath%20fill='%238c442d'%20d='m18%20382%202%201v6h10q3%201%205-2l1-1q2%205%200%209v7l-1%203-10%201h-3l-22-1v-15h15l1-5h2z'/%3e%3cpath%20fill='%234b5c5a'%20d='m232%20303%206%207%202%202%204%209-5%201h-2q-6%200-11-3l-2-4-9%203h2q-1%204-6%207l-9%201q-2-6%200-13%205-5%2011-8l2-1q8-5%2017-1'/%3e%3cpath%20fill='%23d7c275'%20d='m312%2037-4%2012-1%206v6h-11v4q-6-2-11-7l-8-7-2-4h3l8-4q12-8%2026-6'/%3e%3cpath%20fill='%238c442d'%20d='m311%20388%205%201%201%2041-3-4-2%202v-2h-2l-1-3v-4l-1-3-1-5-2-1%201-3h-2l-1-2-1%202h-14v-11l1-4h7l11-2q2%203%201%205v3l1%203v9z'/%3e%3cpath%20fill='%235b3832'%20d='m225%20295-2%205h7v-3l7-1%204%206%2011%2019h-2v5h-4l-1-3q-4-11-15-20-9-2-17%203l-2%201q-7%204-10%2010l-4%203h-2q-1-4%201-9l-1-2v-2l8-7%201-4%205%201v2l2-1q6-3%2014-3'/%3e%3cpath%20fill='%236e7249'%20d='m156%2049%209%2010-2%203h2q7-1%2012%203l2%206q-3%205-9%207l-8%204-2-3-2-3-1-2q-4-8-12-11l-4-1%201-5%206-3z'/%3e%3cpath%20fill='%23a5ba8e'%20d='M319%2044h1v58h-6l-1-10h-4l1%2010h-17v-2h-9c0-6%200-6%202-9l11-1h19v-2q-1-22%203-44'/%3e%3cpath%20fill='%236e7249'%20d='M67%20411v20l-1%203q-11%201-21-5l-2-1-3-3v-5l1-4h2l5-1%209-4%203-1z'/%3e%3cpath%20fill='%23e4e4b9'%20d='M41%20456c13-1%2013-1%2019%203l5%207v12H41l-1-13v-3z'/%3e%3cpath%20fill='%23bb8d4a'%20d='M289%2065h1v9q0%206%203%208l2%202v6h-2l-7%202-3%206-2-3%201-2h-6l-2%204-4-2q-5-6-3-13h2v-2l3-5%209-3%208-2z'/%3e%3cpath%20fill='%235b3832'%20d='m224%20190%2011%2010%203%202%201%204-3%201-41%2012z'/%3e%3cpath%20fill='%236e7249'%20d='M304%20539q4%203%203%208v8l8-3%204-1-1-8%202-1v27l-6%201-1-1-20-1v-17q5%202%207%207l2%201-1-8h2z'/%3e%3cpath%20fill='%239e7240'%20d='m32%20432%202%201h6l16%204%2021%203v2h3v3h-3l-3%201-1%202-1-1-4-2-1%205-8-1h-2l-12-3-5-1v-5l-7-1z'/%3e%3cpath%20fill='%23a75d36'%20d='m57%20110%205%204%203%206c4%209%207%2013%2017%2017q7%203%2016%202l-5-2h6q7%203%2013%200l11-6%202-1%202-1%202%201-3%201v2l2%201-7%205%204%201v2h-3l-18%202q-8%202-15-1l-12-2-3-1-2-4-2-1v-2l-2-1c-6-3-9-12-11-18zm218-10h18v2h17v10h-29q-4-4-6-10z'/%3e%3cpath%20fill='%239e7240'%20d='M320%20184v31h-7l-1%203q-3-4-3-9-2-7-6-13l-1-4q0-2%206-4l4%2012%201-6%201-3v-6z'/%3e%3cpath%20fill='%23d7c275'%20d='M315%20569h5v7h-52q2-3%206-4c11-3%2029-9%2041-3'/%3e%3cpath%20fill='%238c442d'%20d='m42%20387%205%202%205%201h6l10%201v7l-4%204q-11%203-22%202z'/%3e%3cpath%20fill='%23a75d36'%20d='M201%20342v10q0%204%202%207l2%201h-2l-1%2027h-1v-10h-3l-1%202q-4-4-3-9h-3l-1%202v-11c-1-6-1-6%202-10l5-1v-6z'/%3e%3cpath%20fill='%23cc7737'%20d='m194%20370%202%206%205%201%201%2015h-26v-1h8v-11l3-1%201-7z'/%3e%3cpath%20fill='%23a75d36'%20d='m311%20388%205%201%201%2041-3-4-2%202v-2h-2l-1-3v-4l-1-3-1-5-2-1%201-2%201-11v-6h1l1%2019z'/%3e%3cpath%20fill='%239dab7f'%20d='M314%20112h6v44h-6z'/%3e%3cpath%20fill='%23a5ba8e'%20d='M40%20484h25v11c-17%200-17%200-25-2z'/%3e%3cpath%20fill='%239dab7f'%20d='M283%20112h26v17q-6%200-10-4l-3-3-2-1-5-2z'/%3e%3cpath%20fill='%23a75d36'%20d='m142%20388%202%201%201%204-2%201%201%203%202%201v12l2%201h-7l-1-5h-10v-15l12-1z'/%3e%3cpath%20fill='%239dab7f'%20d='m205%20406%2024%201%201%2014h-5l-1%202-1-3-1-4-5-1v-2h-2l-1%204c-6%200-6%200-9-2z'/%3e%3cpath%20fill='%23cc7737'%20d='M317%20156h3v28l-5%202%202%202h-3v6l-1%203v3l-2%201q-5-13-3-27l3%204h-2v7h4l-1-4%201-11v-2l1-6%204-2z'/%3e%3cpath%20fill='%23d7c275'%20d='M168%20135q7%201%2014%205v13h-11l-4-1v-10z'/%3e%3cpath%20fill='%238c442d'%20d='M130%2098h23l-1%208-4%201v2h-18z'/%3e%3cpath%20fill='%236e7249'%20d='M104%20218c15%204%2015%204%2018%2010l1%202-2%202-4%204q-6%201-12-2l-2-14z'/%3e%3cpath%20fill='%239e7240'%20d='M30%20406v14l1%203-5%202-6-8-2-2-1-2-2-2-2-5z'/%3e%3cpath%20fill='%23665c4b'%20d='m64%20410%203%201v20l-1%203q-6%201-13-2z'/%3e%3cpath%20fill='%239dab7f'%20d='m0%20247%2084%201h24v1l-62%201H12v-2H0z'/%3e%3cpath%20fill='%23e4e4b9'%20d='M319%20241h1v29l-2-4-8-6-2-2v-4h2l2-4%203-4z'/%3e%3cpath%20fill='%23557161'%20d='M109%20551h1l2%2010%203-1v2l4-2v2h2l-1%202-3%2012h-10l1-6-2-1q0-3%202-5l1-7z'/%3e%3cpath%20fill='%239dab7f'%20d='m0%20225%2011%206%209%209H0z'/%3e%3cpath%20fill='%23a75d36'%20d='m121%20406%205%201%201%204h2v16l-1%201h-7z'/%3e%3cpath%20fill='%23d7c275'%20d='M319%2044h1v48l-4-1q-1-23%203-47M167%20177l11%204%202%201%202%201v5l-6%203-4%201-5%201z'/%3e%3cpath%20fill='%23e4e4b9'%20d='M182%20196v13c-9%203-9%203-15%203v-5l4-4%202-1%202-2%203-2z'/%3e%3cpath%20fill='%23df8c3d'%20d='M309%20267h5l3%201h2q2%204%201%2010v7l-14-13z'/%3e%3cpath%20fill='%238c442d'%20d='M36%2094h11l-1%2014H36z'/%3e%3cpath%20fill='%23fcf7ce'%20d='M182%20166v14c-7-1-7-1-10-3l-2-1q-2-1-2-4v-3l6-1%203-1z'/%3e%3cpath%20fill='%23557161'%20d='m127%20491%201%203-3%204-13%2015-2%202q-4%206-11%208l2-6%204-3%2010-11z'/%3e%3cpath%20fill='%23d7c275'%20d='m41%2070%208%206%202%202%202%202%2017%2017q7%209%2018%2013v2l-7-3v2h-2l-3-3q-6-8-14-15l-2-2-8-8-11-11zm240%20158%208%205%202%202%202%203%204%204%201%202%204%202%201-2q1-4%205-7%204%200%206%203l2%204-2-1-6-2-3%203-5%205-4-1-2-3-3-2-2-3-3-2-6-7zm36%20160h2l1%208v9l-1%2029c-5-5-3-14-3-21z'/%3e%3cpath%20fill='%23a75d36'%20d='m13%2091%202%201v2h-2zm-2%203h2q3%204%202%209l-1%202v2l-14%201%204-7z'/%3e%3cpath%20fill='%23557161'%20d='M230%20517q8%200%2012%206l-6%208-7-1v-7z'/%3e%3cpath%20fill='%238c442d'%20d='M155%2098h6l3%201h2v4l-1%203-1%203h-11v-5l1-3z'/%3e%3cpath%20fill='%23e4e4b9'%20d='m40%20529%207%202%206%202%2013%205v5l-26-9zm0-45h5l1%203%204%202%2011%206q-10%201-21-2z'/%3e%3cpath%20fill='%238c442d'%20d='M130%20391h7q2%208%200%2015h-7z'/%3e%3cpath%20fill='%23d7c275'%20d='m56%2046%2013%201q2%205-1%209l-8%201-1-3-2-1z'/%3e%3cpath%20fill='%23cc7737'%20d='M128%20391h2v16l-1%204h-2v-2l-1-2-5-1-1-3%203-3%202%201v-3z'/%3e%3cpath%20fill='%238c442d'%20d='m311%20388%205%201%201%2010v6l-4%203h-2z'/%3e%3cpath%20fill='%23e4e4b9'%20d='M259%20209q6%200%2010%205l2%203%202%202%205%205%202%202%201%204-10-7-1-2-5-4-2-2-4-4zm-77-18q-3%206-8%209l-2%202-5%203v-10q7-3%2015-4'/%3e%3cpath%20fill='%23698960'%20d='M112%20457q6%200%2011%203l-1%203h-2l-1%202-1%202q-5%201-8-2z'/%3e%3cpath%20fill='%23d7c275'%20d='M167%20155h15v4l-5%202-3%201-7%202z'/%3e%3cpath%20fill='%236e7249'%20d='m184%20406%204%202%201%209-5%205h-2l-1-14z'/%3e%3cpath%20fill='%23a75d36'%20d='M282%20390h4v15l-6%201v-10z'/%3e%3cpath%20fill='%23d7c275'%20d='M281%2065h8v5q-5%204-12%203c1-8%201-8%204-8'/%3e%3cpath%20fill='%23df8c3d'%20d='m249%20202%202%202-16%205-5%202-8%202-3%201-2%201-2%201h-6v-2l25-8%203-1%203-1h3l2-1%202-1z'/%3e%3cpath%20fill='%23d7c275'%20d='M182%20128v9l-10-3-2-2-2-1v-2h5l3-1z'/%3e%3cpath%20fill='%23849881'%20d='m148%20537%202%201-2%202a70%2070%200%200%200-22%2036l-3-1q8-22%2025-38'/%3e%3cpath%20fill='%23d7c275'%20d='M236%20390h19l11%201%201%202h-33zm-54-229v5c-9%203-9%203-14%203v6h-1v-9l6-2%204-2z'/%3e%3cpath%20fill='%238c442d'%20d='M168%2099h10v6l-10%202z'/%3e%3cpath%20fill='%23d7c275'%20d='M171%20274h2l6%208%204%206q3%205%208%204h2l3%201h5v1c-15%201-15%201-19-1l-4-7-4-6z'/%3e%3cpath%20fill='%23bb8d4a'%20d='M102%20216q14%202%2023%2012%205%205%207%2011l-1%204-1-2q-8-16-24-22l-4-2z'/%3e%3cpath%20fill='%238c442d'%20d='M317%20102h3v10h-6l-1-3v-4q0-4%204-3'/%3e%3cpath%20fill='%23a75d36'%20d='M207%20292h16l-3%201v2l-4%202-3%201-4%201-1-2-3-2%203-1z'/%3e%3cpath%20fill='%239e7240'%20d='M269%2058q4%200%207%203l2%204h-13z'/%3e%3cpath%20fill='%23df8c3d'%20d='m81%20109%203%201v2l-4-1z'/%3e%3cpath%20fill='%23cc7737'%20d='m17%20106%203%201Z'/%3e%3c/svg%3e",
	seahouse: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='576'%3e%3cpath%20fill='%23728277'%20d='M0%200h320v576H0z'/%3e%3cpath%20fill='%235fbcb8'%20d='M0%200h320v50l-4%201h-27v-6h-3v6h-3l3%201v15l-21-11q0-7%205-13l7-3%201-2h8v-2h-8l-1-9-1%209h-2l-1-5h-4v-2l-2%201-11%201h-6v-5h-3v7h-4v4h5v20l-8%201-3%202q4%203%2010%203l2%207h2q3%204%203%209l3-1h3l2%209-38%201-2%2011-4%201h-2v-9h-2l1%209h-7V86l-4-1v3h-12v2l2-1h12l-1%203v9h-2l1%205%208%202-2%202h3l5%202v38l-1%2081-1-2h-2l-3-3-1-2-2%203v-4l1-3%201-4h2V112h-16l4-1v-2l-7-1%201-3h-2v2h-2v-2l-5-1v4h-2l-2%201-1%203h-45c-8%200-8%200-11%202l-3%205h3l-2%205h-2l-1-2-3%205h5q2%204-1%209l-1%203-1%203h-7v-2l-2%201-6-1-1%201-9-1-6%201h-3q-5%200-8%205-2%203-5%202h-2v-2h-2l-3%207%207-2-6%209H49l-1%205H31v19l-4%202v2l9%202-2%202v3l1%201%204-1%201-2%205-1-1%204%204%203%204-2%2010-3%203-1v2l2-1%204-2-5%208-2%202-1%201%207-2-2%205h-2l-14%201-14%201H24v3l32%201c0%205%200%205-2%208q-6%204-11%202h-8v8h41v2H24v58H7l-1-3v-8l-6%201z'/%3e%3cpath%20fill='%23118d8f'%20d='M320%20343v233H215l-4-8c-8-10-23-14-35-15-5%200-5%200-8-2l-4-8-2-4-11-21-25-45-2-3-1-3-2-2-1-2h-2l-1%205-11%201v-5l-2%201-1%203-28-1v-2h19v-2H74l1-6h28v4h3l1-5h3v-2h-3v-4h-4v4H75v-6h16v-2H75v-7h28v7h2l1-7h10v-2h-9v-3h97l1%2032%204%201-3%201-2-1v6h-24l-1%207h16l3%201h6q2%205%201%2011v32h4l-1%204v-2h-3l-1%207%204-1-1%202v6l4%203%202%201%201%201v-3l-1-42v-15l1-18v-40h52v70h7v-70h8v-8h-8v-23h-2v6l-23%201v16h-29v-17l-5-1%202-8%202-2%207-9c-9%202-9%202-11%205v-3l-3%201-7%201v6h-64l-9-1h-3l-16-1v2H89l-3-1%201-7%204-2v-2l5%202%205%201%205%201-12-5c8-8%2016-8%2026-8v3l-7%201%207%201v6h-9v2l9%201v4h4v-4h40l2%204%201-13h8v-2h-6l-1-2%2011-1h3c8%200%208%200%2012%202l4%204%201%202%201%201%201%205%204-1%209-1v-10l-11%201%201-3h9v-22h30q-2%207-6%2010l-8%2010-7%208-2%203q9-1%2014-7l4-6%204-6%202-2%202-3%201-2q4-6%207-6h31q6%201%2011-4h2v2l-2%202q11%203%2019-4z'/%3e%3cpath%20fill='%23175864'%20d='M247%2026h3v5h4l4-1h3l8-1v2l2-1h2l1%204v2h2v-9l2-1v10h8v2h-8l-1%203-3%201q-5%203-8%209l-1%205%203%201%208%204%209%205%201-14h-10v-1h10v-6h3v6l31-1v279h-97v2h-5v-79h51v-2h-52V112l-11-1%204-3-7-2v-5h2v-2l-1-3v-5l1-1h-13v-2h12v-3l5%201v13l6%201-1-9h2v9l5-1%202-6%201-5h-13v-1l50-1-1-7h-6l-3-9h-2q-2-3-2-7h-3q-6%200-9-4%206-2%2013-2V37h-5v-4h4z'/%3e%3cpath%20fill='%23175864'%20d='m185%20104%205%201v2h2v-2h2v2l6%202v2l12%201v104h-2l-1%2010-4%208-1%203h3v2h-3l-1%2011-20%201%207%201v3h-42l-1%2033h-2v-33h-37l6%2011%201%203%202%203%201%203%206%2010v5q-4-3-6-8l-2-5-1-2-3-6-1-2-1-2-4-9-3-1v33h-4v-34H68v3h-2l-1-2-6-1h-6v8c-2-3-2-3-2-8H35v-22h41v-2H35v-8h10q5%200%208-3%202-1%203-7H19v-1h5v-3l44-2%201-4-7%202%207-9%202-3-2%202-4%201v-2l-2%201q-3%203-8%203l-8%203-1-2-3-2v-2l-3-1-1%202-1%202h-6l2-3v-5l-7-1v-2l3-2%201-4v-15h10l6-1%202-4-3-1h9l3%201c6%200%206%200%209-3l3-5-1%201h-5l3-7h2v2q5-1%209-5%202-3%206-3h5l5-1%201%201%2010-1%206%201v2h7v-2l1-3v-2l2-7-5-1q2-6%204-6v3l4-5-4%201q2-5%206-8h54l1-4h4z'/%3e%3cpath%20fill='%23ee873d'%20d='M210%20220h1v3l1%204%204%202q3%2010%201%2021h52v2h-51v79h5v-2h97v5H198L0%20333v-53l6-1%201%2010%2017%201v-58h11v22h16l1%205%201-5h12l1%203h2v-3h31v34h4l-1-4%201-21v-8l4%201%203%207%209%2017%204%209%201-2-3-6-2-3-2-4-4-7-1-3-4-9h37v33h2v-20l1-13%2040-1v-1l-6-2v-1h21v-7l1-4h3v-2h-3q1-6%204-10z'/%3e%3cpath%20fill='%23ee873d'%20d='M0%20333h204l38%201h78v7l-2%204q-11%206-23%204l1-3h2v-2l-3%202q-6%205-13%203h-13c-14-1-14-1-19%202l-9%2012-5%208-2%203q-5%205-14%206l5-8h2l1-2%205-7%2010-14-29%201-1%2021h-9l1%202h9v10l-13%202-3-5q-2-5-7-8h-12l-3%201h-7l6%201v2h-8v8h8v1h-8l-1%205-2-1v-4h-40v4h-4v-4l-9-1v-2h9v-6h-7l-1-2h8v-3l-2%201h-6q-9%202-17%206l14%206H98l-7-4-7-3-3-1-5-1v2h-3v2l-2%201-1%207v7q-5-1-9-6v-27h-2q-6-2-10-6l-2-1-5-5-9-1h-9l13%2014%205%204%203%204c10%208%2010%208%2010%2013l-2%206-2-2-22-23-7-8-1%2071h5l-4%201-1%2030H0z'/%3e%3cpath%20fill='%23534841'%20d='m227%20382-4%205-3%203-4%205q-2%202-2%206l7%201-2%201v16h29v-16h-6v-1h29v-6h2v6l4%201-3%201-1%2015h8v8h-8v70h-7v-70h-52l1%2014v49l-1%2019v36l-9-6%201-5v-1h-2l1-7h3l1-2h-4l-1-43h-26l2-8h24v-6h4l-3-1-1-32h-97v3h9v2h-10v8l-3-1v-7H75v7h16v2H75v6h28v-4h4v4h3v2l-3%201-1%204h-3v-4H75v5h11l8%201v2H75v2h3l25%201%201-4h2l1%204h10v-5h4l3%204%202%203%201%204%202%203%2010%2016%208%2015%202%204%207%2014%204%208%202%203%203%206%201%202q3%207%207%207h3q22%202%2037%2017l2%207h-92q2-9%2010-14%2014-9%2029-9h5l-2-3-1-2-3-5-26-48-4-7-2-4-7-12c-2%2017%201%2028%2010%2042l10%2023v3l3%201%202%206-4%201-8-13-1-2-15-33-1-2q-1-3-3-2H75v36h-3v2l-3-1v-2h-2l2-4-3%202h-2l-1-14v-68l-1-8%201-13H44l-1-8h8v-15l-5-1%202-1%203-4v-2h2v6l4%201h-4v16h5v-15h2v15c6-2%206-2%208-5l-1-2h3l-1-3h2l1%2010h7v-10h1v11h6v-9l2%201v7h6v-7l2%201v6l5-1%201-6h1v7h7v-6h2v7h4l6%201%204%201h8l7%201v-2l6-3v2h26v-3h2l2%202%204%201h3l5-1%208%201v-16l-3-1%203-1h7v-15l10-2%201%202%202-3%204-1%202-1z'/%3e%3cpath%20fill='%23e2be7c'%20d='M320%20343v140h-47v-56h8v-8h-8v-23h-2v6l-23%201v16h-29v-17l-5-1%202-8%202-2%207-9c-9%202-9%202-11%205v-3l-3%201-7%201v6h-64l-9-1h-3l-16-1v2H89l-3-1%201-7%204-2v-2l5%202%205%201%205%201-12-5c8-8%2016-8%2026-8v3l-7%201%207%201v6h-9v2l9%201v4h4v-4h40l2%204%201-13h8v-2h-6l-1-2%2011-1h3c8%200%208%200%2012%202l4%204%201%202%201%201%201%205%204-1%209-1v-10l-11%201%201-3h9v-22h30q-2%207-6%2010l-8%2010-7%208-2%203q9-1%2014-7l4-6%204-6%202-2%202-3%201-2q4-6%207-6h31q6%201%2011-4h2v2l-2%202q11%203%2019-4zM30%2075l4%201v12h5v-5h3v5h23c21-1%2021-1%2030%206q6%207%207%2015H42v31c23%201%2023%201%2028-2l5-8-8-1h-3l-2-1h-9q1-4%205-6l3-1%203-1%205-3%203-2%204-3q7-2%2014-1h13l7%201h16l-5%207h3l-2%205h-2l-1-2-3%205h5q2%204-1%209l-1%203-1%203h-7v-2l-2%201-6-1-1%201-9-1-6%201h-3q-5%200-8%205-2%203-5%202h-2v-2h-2l-3%207%207-2-6%209H49l-1%205H31v19l-4%202v2l9%202-2%202v3l1%201%204-1%201-2%205-1-1%204%204%203%204-2%2010-3%203-1v2l2-1%204-2-5%208-2%202-1%201%207-2-2%205h-2l-14%201-14%201H24v3l32%201c0%205%200%205-2%208q-5%204-11%202h-8v8h41v2H24v58H7l-1-3v-8l-6%201V88h30z'/%3e%3cpath%20fill='%23118d8f'%20d='m40%20468%203%201v2h9q5%200%209%202v7H22l1%2046h6l2%204%202%203%202%205h2c2-6%202-6%201-10l3%203v3h2v-2l3-1-1%203%209-3h5l4-1%202-2%204-3%202%201-4%205h2l3%203v-2l2-1v-10l1-8v-17l32-1h3c6%200%206%200%209%202l5%2011%208%2018%201%203%205%209%201%203%202%202%201%202%201%202h3l-2-6h-3v-3l-3-11-1-2-13-24-1-2-1-2-1-8v-18l7%2010%201%202%203%205%205%209%202%204%2026%2046%202%206h-3c-14%202-28%204-37%2016l-4%207H0V471h39z'/%3e%3cpath%20fill='%23175864'%20d='M219%20167q3%204%202%209l1%201v16h72v6l-72-1%201%2036h17l3%201h17l60%201v93h-97v2h-5v-79h51v-2h-52v-37c0-32%200-32%202-46'/%3e%3cpath%20fill='%23ee873d'%20d='M24%20232h11v22h16l1%205%201-5h12l1%203h2v-3h31v34h4l-1-4%201-21v-8l4%201%203%207%209%2017%204%209%201-2-3-6-2-3-2-4-4-7-1-3-4-9h37v33l58%201v-17l1-14v-6h12l-1%2036v10h-9l1-2h4l-12-2v3h5v2l-72%201%204%2010h-3l-4-10H69l-12-1H34v11h2l34%201%201%202%2011%201h3l2%203%207%201h6v-3l2%201-1%202%202-1%2010%201h6v-2h3v2l7-1%203-5h6v3l9%202%201-3%202%204%203-1%207%201h9v-2l4%202h6l1-3%2026-1v-6h9v22l-2%201v-4h-5l-2-10-2%203-11%201h-40L5%20320v11H2q-3-15-2-32v-19l6-1%201%2010%2017%201z'/%3e%3cpath%20fill='%2319747f'%20d='M100%20189h2l-6%2010%202-3%206-2%202%201%202-3%202-3h2l1%203%203-1h5l-3%206%205%201-1%204%202-3%206-4%203-5h2l-2%208h2l1-5h3v2h4l-1%207q6%200%2010-3l-2%208h-32l-6%201-3%206h-2l-1-2-2%202%208%201v-3l3%201-1%202h2v-3h3l1%203%2042%201v-2l2-1-5-1%202-1%204-3-3-2-2%201%204-11%201-3%202-2h5l-2%2010%208-6-1%2010%209-3v6l-10-1%201%203h15l-1-2v-9l1-3%201-7h6l1%205%201-2%201-2h3l1%202v2l1%203%203%204%202-1v16h-2l-1%206v4l-4%208-1%203h3v2h-3l-1%2011-20%201%207%201v3h-42l-1%2033h-2v-33h-37l6%2011%201%203%202%203%201%203%206%2010v5q-4-3-6-8l-2-5-1-2-3-6-1-2-1-2-4-9-3-1v33h-4v-34H68v3h-2l-1-2-6-1h-6v8c-2-3-2-3-2-8H35v-22h41v-2H35v-8h10q5%200%208-3%202-1%203-7H19v-1h5v-3h10v3h2l10-1h4l16%201-3%204h10l1-2q1-3%204-4h3l5-1%201-2-5%201%206-9%202-2%202-2%201%202-1%202%207-7z'/%3e%3cpath%20fill='%23f7f3e6'%20d='M0%200h267q-10%207-23%206h-3c-13%200-13%200-19-3q-25-5-45%208-12%207-19%2018l2%201q4%203%204%207h-9q-6%201-10%204h20l7%201h13l10%201v2h-45l-4%201-18%202-11%201h-2q-20%200-34-15c-9-8-24-17-36-17h-3l1%203%204%2010h2q7-1%2012%203l9%205v1H0z'/%3e%3cpath%20fill='%2319bcad'%20d='M214%20427h52v70h7v-14h47v93h-39c1-10%201-10%204-15q3-10%201-20v-4l-3-12v-7l-9%201v21l-3%205-6%201v-63h-51z'/%3e%3cpath%20fill='%23534841'%20d='M118%20341h24v7h15l-1-6h62l29%201h3l4-1h8l25%201h3l6%202q-4%204-9%204h-18c-14-1-14-1-19%202l-9%2012-5%208-2%203q-6%205-14%206l5-8h2l1-2%205-7%2010-14-29%201-1%2021h-9l1%202h9v10l-13%202-3-5q-2-5-7-8h-12l-3%201h-7l6%201v2h-8v8h8v1h-8l-1%205-2-1v-4h-40v4h-4v-4l-9-1v-2h9v-6h-7l-1-2h8v-3l-2%201h-6q-7%200-12%204l-7%202-7-3-3-1-13-8-3-2-3-2v-7l-1-4-2%208-9-5-3-2-8-7q2-3%205-2h55l7-1h3z'/%3e%3cpath%20fill='%235db8b2'%20d='M228%20392h59l33%201v90h-47v-56h8v-8h-8v-23h-2v6l-23%201v16h-29v-17l-5-1%201-7q6-3%2013-2'/%3e%3cpath%20fill='%23175864'%20d='M247%2026h3v5h4l4-1h3l8-1v2l2-1h2l1%204v2h2v-9l2-1v10h8v2h-8l-1%203-3%201q-5%203-8%209l-1%205%203%201%208%204%209%205%201-14h-10v-1h10v-6h3v6l31-1v51h-38l-1-4v2l-6%203h-12l2%202h-2v2l-9%201-21%201h-5l-3-1h-5l-2%202q-4%203-12%202l4-3-7-2v-5h2v-2l-1-3v-5l1-1h-13v-2h12v-3l5%201v13l6%201-1-9h2v9l5-1%202-6%201-5h-13v-1l50-1-1-7h-6l-3-9h-2q-2-3-2-7h-3q-6%200-9-4%206-2%2013-2V37h-5v-4h4z'/%3e%3cpath%20fill='%23223742'%20d='M218%20252h5l-1%2038%209-2%203%202h9l11%201h11v-15h24l1%203h21l1%209h-3v2h3v2h-91v2h99v35h-97v2h-5z'/%3e%3cpath%20fill='%23cde1d5'%20d='M107%20434h97l1%2032%204%201-3%201-2-1v6l-23-1q1-4%204-6l-3-4q-3-1-7%203l-1%201-3%201-1%202-1%202h-5l3-7h-3v-2l-2-1v3h-2l2%205q-7%206-18%204h-6c-11%200-11%200-14-3l-3-5-1-2h-2l-1%205-11%201v-5l-2%201-1%203-28-1v-2h19v-2H74l1-6h28v4h3l1-5h3v-2h-3v-4h-4v4H75v-6h16v-2H75v-7h28v7h2l1-7h10v-2h-9z'/%3e%3cpath%20fill='%2339adb2'%20d='M30%20165h1v19l-4%202v2l9%202-2%202v3l1%201%204-1%201-2%205-1-1%204%204%203%204-2%2010-3%203-1v2l2-1%204-2-5%208-2%202-1%201%207-2-2%205h-2l-14%201-14%201H24v3l32%201c0%205%200%205-2%208q-5%204-11%202h-8v8h41v2H24v58H7l-1-3v-8l-6%201V167l29-1z'/%3e%3cpath%20fill='%2319747f'%20d='m257%20181%202%201v3h42l3%202h-8v4h3l4%202h-7v9l2-1h11v1l-13%201v5h3l13%204v-2l-4-1%204-1-1-8h3v16h-2v-3l-15%201-1%203h24v19h-72l-6-1h-20v-37h71l1-5h-72l1-8h34z'/%3e%3cpath%20fill='%2339adb2'%20d='m40%20468%203%201v2h9q5%200%209%202v7H22l1%2046h6l2%204%202%203%202%205h2c2-6%202-6%201-10l3%203v3h2v-2l3-1-1%203%209-3h7l5-2v3h2l1%202%203%201%201%204h-2l-2%201-1%202%203%201-2%203h4l3-8%209%207%201%205%203-1%203%203%203%201%201-3v2h2l1-3%202%206%204-1v2l-6%201h-4l-2%204h-2l-1-2-3-1-1%203-2-2%202-3q-5-1-9%204-5%204-10%203l-2-1v-2l-3%202q-7%203-16%202l1-2h4l-8-1v-2l6-2%204%201v-2h-2q-3%201-5-2l-2%203h-2l-3-3-1-2-1-2-6%206-2%203%204%202-5%202v2l-2-1-6%201v-2l-4%202-4-4-2-1-2-8H6l-2-14H0v-67h39z'/%3e%3cpath%20fill='%23c74e31'%20d='M132%20112h53l-7%2010-2%202-2%202c-15%2015-15%2015-19%2022l-3%203-3%207-4%208c-22%202-22%202-29%200H96l-48-1%201-5-3-1%2012%201c6%200%206%200%209-3l3-5-1%201h-5l3-7h2v2q5-1%209-5%202-3%206-3h5l5-1%201%201%2010-1%206%201v2h7v-2l1-3v-2l2-7-5-1q2-6%204-6v3l4-5-4%201q3-9%2012-8m74%20140h10l-1%2036v10h-9l1-2h4l-12-2v3h5v2l-72%201%204%2010h-3l-4-10H69l-12-1H34v11h17l19%201%201%202%2011%201h3l2%203%207%201h6v-3l2%201-1%202%202-1%2010%201h6v-2h3v2l7-1%203-5h6v3l9%202%201-3%202%204%203-1%207%201h9v-2l4%202h6l1-3%2026-1v-6h9v22l-2%201v-4h-5l-2-10-2%203-11%201h-40L5%20320v11H2q-2-12-2-25v-4q0-10%202-19h2l1%209h17l5%201v-13l6%202%201-3v13l51%201h22l27-1%2011%201v-2h4l17%201h4l11%201h26z'/%3e%3cpath%20fill='%23ee873d'%20d='M200%20317h6l2%207%201%202%204%201%201%203h3l6%201v-2h97v5H198L0%20333v-13q3%205%202%2011h3v-11h190l9-1z'/%3e%3cpath%20fill='%2319747f'%20d='M264%20152h56v65h-24l1-4h15v3h2v-16h-3l1%202v6l-3%201%203%201v2l-16-4v-5l8-1h-8v-9l6-1-6-1v-4l7-1-44-1-1-3-1%203-35%201%201-13%204-1h9l7-1%201-3q7-5%2016-5l5-4%202%201v-2l-4-2z'/%3e%3cpath%20fill='%2319bcad'%20d='m162%20461%203%201-1%202h3l-1%202-2%205%205-1%201-2%201-2%205-1%202-4%205%201%203%205-4%201v3l14%201v1h-16l-1%207%2025%201v37l-29%201c-20%201-20%201-25-3q-4-5-7-13l-5-8-3-6-2-3-7-14h25l2-1%207-1%201-4-1-2h2z'/%3e%3cpath%20fill='%23534841'%20d='M0%20342h15l1%204h3q5%200%208%205l11%2012%203%203%205%204c9%208%209%208%209%2013l-2%206-2-2-22-23-7-8-1%2071h5l-4%201-1%2030H0z'/%3e%3cpath%20fill='%23e2be7c'%20d='M210%20220h1v3l1%204%204%202q3%2010%201%2021h52v2h-51v79l-2-1v-4l-1-3v-45l1-8v-18h-12v11l-1%2026h-56l1-34%2040-1v-1l-6-2v-1h21v-7l1-4h3v-2h-3q1-6%204-10z'/%3e%3cpath%20fill='%23ee873d'%20d='M212%20112v56l-11-2v2h-7l-4-1h-7l-34-1q5-16%2017-30l2-2%2010-10%203-5c8-12%2015-7%2031-7'/%3e%3cpath%20fill='%23e2be7c'%20d='M35%20254h16l1%205%201-5h12l1%203h2v-3h31v35l-64-1-1-17v-6l1-3z'/%3e%3cpath%20fill='%23118d8f'%20d='M204%20483h1v41h4l-1%204v-2h-3l-1%207%204-1-1%202v6l5%203%202%202%202%201v-2l4%203%201%202h8l5-4%202%201-2%202%201%206v3l-5-4%202%202v8q-7%202-12-1l-2%203h-6q-2%201-4-3l-6-1-4-2q-10-4-22-6c-5%200-5%200-8-2l-4-8-2-5-6-10-1-2-3-8h52z'/%3e%3cpath%20fill='%2319bcad'%20d='M22%20480h39l1%207v2l2%208v33l-3%202-2-1q-5%200-9%203h-6l1-2h-2v2h-2l-1-2-2%206h-4l-1-3q-2-5-6-8l-5-1v-19l-1-6v-17z'/%3e%3cpath%20fill='%235db8b2'%20d='M214%20427h52l-1%2047-4-2-1-3-7%201v-5l-7-1-2%206h-3l-1-3-3-4-7%202-5%206h-2v2h-8v-2l-1-4z'/%3e%3cpath%20fill='%23f7f3e6'%20d='m30%2075%204%201v12h5v-5h3v5h23c21-1%2021-1%2030%206q6%207%207%2015H68l-68-1V88h30z'/%3e%3cpath%20fill='%23534841'%20d='M320%20490v86h-39c1-10%201-10%204-15q3-10%201-20l-1-8v-6l10-1%201%2012%201%205v6l1%204%201%209%202-10h1l-2-26%202%201%2011-33h3v-2z'/%3e%3cpath%20fill='%23cde1d5'%20d='M61%20426h2v10l1%205v54h-2l-2-16v-6l-12-2h-5l-1-2h-2l-1%202H0v-13h21v-9H1v-1h20v-15h40z'/%3e%3cpath%20fill='%235db8b2'%20d='m21%20355%202%202%2023%2024%2012%2014%204%205h-9v-5h-2v5l-4%202%204%201v15h-8l1%208h17v7H21l1-5-1-1z'/%3e%3cpath%20fill='%23cde1d5'%20d='M261%20371h24l12%201h23v21h-96l-5-2%203-5%202-3q6-4%2011-5l4-2%205-1%202-1z'/%3e%3cpath%20fill='%2319bcad'%20d='M214%20483h51v35l-11%201h-18l-6%201-10-1-6-1z'/%3e%3cpath%20fill='%23c74e31'%20d='M207%20563q7%205%208%2013h-92q2-9%2010-14c22-13%2053-14%2074%201'/%3e%3cpath%20fill='%23223742'%20d='M219%20167q3%204%202%209l1%201v16h72v6l-72-1%201%2036h17l3%201h22l14%201h41v56h-6v-40h2v-2h-2v-9h-2v4l-4%201v2l4-1v2h-11l6-8-2%202-2%202-2%201q-2%202-5%202v-8h-74l1%209h-5v-57z'/%3e%3cpath%20fill='%23534841'%20d='M156%20342h62l29%201h3l4-1h8l23%201h5l6%202q-4%204-9%204h-18c-14-1-14-1-19%202l-9%2012-5%208-2%203q-5%205-14%206l5-8h2l1-2%205-7%2010-14-29%201-1%2021h-8v-22h-18l3%204%203%205%202%202%201%203%205%208h-8l-5-8-9-14-6-1h-5v8q-8-4-12-12z'/%3e%3cpath%20fill='%2375bcb8'%20d='M273%20427h1v25h46v31h-47z'/%3e%3cpath%20fill='%23e2be7c'%20d='M120%20371v3l-7%201%207%201v6h-9v2l9%201v4h4v-4h40l2%204%201-13h8v-2h-6l-1-2%2011-1h3c8%200%208%200%2012%202l4%204%201%202%201%201%201%205%204%201-1%206h-64l-9-1h-3l-16-1v2H89l-3-1%201-7%204-2v-2l5%202%205%201%205%201-12-5c8-8%2016-8%2026-8'/%3e%3cpath%20fill='%23534841'%20d='m40%20468%203%201v2h9q5%200%209%202v7H22l1%2047h-8l-1-5-1-3-1-7H8l-1-9-1-3-1%2013-5%201v-43h39z'/%3e%3cpath%20fill='%235ab0ac'%20d='M0%20222h22v8H2v2h20l-1%2056H6v-9l-6%201z'/%3e%3cpath%20fill='%23728277'%20d='M0%20352h2l1%2023v-23h4q5%2029%203%2057v13l-1%202v2h9l8%201-4%201-1%2030H0z'/%3e%3cpath%20fill='%23534841'%20d='M73%20225h12v29H68v3h-2l-1-2-6-1h-6v8c-2-3-2-3-2-8H35v-22h41v-2H52l2-4q10-2%2019-1'/%3e%3cpath%20fill='%2375bcb8'%20d='M222%20112h42l-10%2018h66v6h-88l-9-1v-2l-3-1v-2h2z'/%3e%3cpath%20fill='%23223742'%20d='M118%20462q5%202%207%207l1%203%203%205%201%202%209%2015%2016%2030%205%2010%202%203%208%2014-3%201q-12-18-21-37l-11-20-4-7-2-4-7-12c-2%2017%201%2028%2010%2042l10%2023v3l3%201%202%206-4%201-8-13-1-2-15-33-1-2q-1-3-3-2H75v9h-6v-11l6-2v-8h28v9h3v-8l4-1%203-1%204-1v-17z'/%3e%3cpath%20fill='%23c74e31'%20d='m0%20333%20320%201v5h-76l-118-1H62l-48-1H8l-8-1z'/%3e%3cpath%20fill='%23e2be7c'%20d='M124%20348h36l1%204%204%202%202%201%201-7h11q8%209%2013%2020%200%203%205%202h3l-5-7-1-2-6-8-1-4h18v24h9v10l-13%202-3-5q-2-5-7-8h-12l-3%201-9%201v-6h2l2-1%201-2h-5v-6l-3-2v2h-40v-3l38-1-38-1z'/%3e%3cpath%20fill='%23534841'%20d='M320%20312v17h-97v-1h39v-10h-14l-21-1v2l-7%201v-4l8-1-8-1v-2h48l35-1h6z'/%3e%3cpath%20fill='%2375bcb8'%20d='M265%20429h1v68h7v44l-2%204-6%201v-63h-51v-16q3%202%202%205l7%201v-2l7-7q2-2%206-2l5%205v3h3v-2q0-3%202-5l7%202v5l3-1h4l5%205z'/%3e%3cpath%20fill='%23175864'%20d='M222%20111h89l9%201v18h-66l9-17-41-1z'/%3e%3cpath%20fill='%23ee873d'%20d='M177%20125v2l3%2010%202%208%201%203v2l2-4q5%203%206%208l-1-5%202-1%203%207h3l1%203%201%203%203%201%201%203-3%201v2h-7l-4-1h-7l-34-1q5-16%2017-30l2-2z'/%3e%3cpath%20fill='%235db8b2'%20d='M0%20108h29c2%2028%202%2028-1%2034q-6%204-14%205l-14%206z'/%3e%3cpath%20fill='%23118d8f'%20d='M294%20240h2v8l7-5%202-2h2q-1%205-6%208h11v-2l-4%201v-2l4-1v-4h2v9h2v2h-2v11l3%201h-3v28h6v2h-99v-2h91v-2h-3v-2h3l-1-9-21%201-1-4h-24v15h-2v-15l4-1h26l-1%202%202%201-1-8h-2v-2h3v-9h-3l-15%201h-36l-1-2h55v-7l-3-1%201-2h2z'/%3e%3cpath%20fill='%2319bcad'%20d='m75%20496%2032-1h3c6%200%206%200%209%203l5%2010%201%203%202%207H78l-3-1z'/%3e%3cpath%20fill='%23f7f3e6'%20d='m0%20211%2056%201q1%205-2%208-6%204-11%202h-8v8h41v2H24v58H7l-1-2h15l1-56H2v-2h20v-8H0zm306%207h14v18h-77q3-7%208-10h19c13%200%2013%200%2016-3l3-3q8-5%2017-2'/%3e%3cpath%20fill='%2339adb2'%20d='M205%20524h4l-1%204v-2h-3l-1%207%204-1-1%202v6l5%203%202%202%202%201v-2l4%203%201%202h8l5-4%202%201-2%202%201%206v3l-5-4%202%202v8q-7%202-12-1l-2%203h-6q-2%201-4-3l-6-1q-8-2-13-8l-1-3-3%203q0-6%204-10v-4l-4-1-4%204%201-5%2012-3%203-1%206%201-1-2q0-4%203-8'/%3e%3cpath%20fill='%23223742'%20d='M281%2093h1v8h13l1-4v4h24v11l-98-1v19h-3v-18l-3-1%204-5h5l1%201h11l26-1-1-5%2017-1z'/%3e%3cpath%20fill='%23cde1d5'%20d='m214%20451%2051%201v22l-4-2-1-3-7%201v-5l-7-1-2%206h-3l-1-3-3-4-7%202-3%203-2%203h-2v2h-8v-2l-1-4z'/%3e%3cpath%20fill='%2319747f'%20d='m257%20181%202%201v3h42l3%202h-8v4h3l4%202h-7v9l2-1h11v1l-13%201v5h3l13%204v-2l-4-1%204-1-1-8h3v16h-2v-3l-15%201-1%203h24v1h-28l2-2v-5l-2-2%202-1v-15h-72l1-8h34z'/%3e%3cpath%20fill='%235db8b2'%20d='M320%20349v23h-63l3-3%202-1h3l3-1%206-2%203-1q16-5%2031-14z'/%3e%3cpath%20fill='%23e2be7c'%20d='M34%20299h68v11l-7%201H69l-35-1z'/%3e%3cpath%20fill='%235db8b2'%20d='M30%20165h1l1%209v3l-1%207-8%205-4%202-4%202-4%202-2%201-9%205v-34l19-1h7z'/%3e%3cpath%20fill='%23ee873d'%20d='M49%20254h2l1%205%201-5h12l1%203h2v-3h17v22H49z'/%3e%3cpath%20fill='%2375bcb8'%20d='m162%20461%203%201-1%202h3l-1%202-2%205%205-1%201-2%201-2%205-1%202-4%205%201%203%205-4%201v3l14%201v1h-16l-1%207%2025%201v2h-58c-14%200-14%200-17-3q-3-4-3-8h25l2-1%207-1%201-4-1-2h2z'/%3e%3cpath%20fill='%235ab0ac'%20d='M106%20426h82l16%201v7h-97l-1%203v-5l3-1h7v-2h-10z'/%3e%3cpath%20fill='%23f7f3e6'%20d='M0%2022c14-1%2014-1%2020%204l1%202h13l14%202h4q5%200%209%203l9%205v1H0z'/%3e%3cpath%20fill='%2339adb2'%20d='M100%20189h2l-6%2010%202-3%206-2%202%201%202-3%202-3h2l1%203%203-1h5l-3%206%205%201-1%204%202-3%206-4%203-5h2l-2%208h2l1-5h3v2h4l-1%207q6%200%2010-3l-2%208H82l6-9%202-2%202-2%201%202-1%202%207-7zm123%2010h31v2h-3l1%206-2%201-5%205h-3v-2q4-5%207-4v-3q-5%201-8%206-4%206-2%2014l1%202v-8l2-1v6l1%204%202%206q-3%203-7%202h-6l-9-1z'/%3e%3cpath%20fill='%23e2be7c'%20d='M210%20220h1v3l1%204%204%202q3%2010%201%2021h52v2h-51v79l-2-1v-4l-1-3v-45l1-8v-18h-12l-2%204h-54v-1l40-1v-1l-6-2v-1h21v-7l1-4h3v-2h-3q1-6%204-10z'/%3e%3cpath%20fill='%23e2be7c'%20d='M145%20299h54l4%201v11h-60z'/%3e%3cpath%20fill='%2339adb2'%20d='M212%20111h5q2%204%201%207v32l-1%2081-1-2h-2l-3-3-1-2-2%203%201-7%201-4h2z'/%3e%3cpath%20fill='%235db8b2'%20d='M320%2052v35c-15%200-15%200-19-4l-3-4-2-2-4-6-2-2%2017-11%202-1c8-5%208-5%2011-5M111%20348h10v6l-5%201%205%201v10h-6v2h6v6l-1-3-2%201h-6q-7%200-12%204l-8%202-6-3%208-13%202-3%204-4%203-5q3-4%208-2'/%3e%3cpath%20fill='%23223742'%20d='M265%20276h24l1%203h21l1%209h-3v2h3v2l-47-1z'/%3e%3cpath%20fill='%23728277'%20d='m1%20420%202%201v3h2v4h17l-1%2030H0v-37z'/%3e%3cpath%20fill='%23c74e31'%20d='M179%20123q4%207%205%2016l3-1h6l1-4%201%202q3%204%209%204l1-2%207%201v29c-7-1-7-1-9-3l-1-3-1-1-3-6-3%201-3-5-1%204-3-5-3-3-1%205q-2-2-2-6l-3-11q-4-6-1-10z'/%3e%3cpath%20fill='%235db8b2'%20d='m271%20348%2018%201q-9%207-19%2012l-2%201-25%2011-3%201-6%202-2-1%209-13%204-5c7-10%2015-9%2026-9'/%3e%3cpath%20fill='%23118d8f'%20d='M22%20517h40q3%207%202%2013l-3%202-2-1q-5%200-9%203h-6l1-2h-2v2h-2l-1-2-2%206h-4l-1-3q-2-5-6-8l-5-1z'/%3e%3cpath%20fill='%23728277'%20d='M62%20432h1l2%206h2l1%207v32l1%2016v12h6v27h-3v2l-3-1v-2h-2l2-4-3%202h-2l-1-14v-68l-1-8z'/%3e%3cpath%20fill='%235ab0ac'%20d='M24%20348c18-1%2018-1%2024%204l4%204%209%205v26l-4-3v-2h-2l-3-3-10-11-2-2-11-11-2-1-3-4z'/%3e%3cpath%20fill='%23cde1d5'%20d='M274%20452h46v20l-5%201%201-3-10-7q-4%205-6%2011h-12l8-4-2-5h-10l-2%203-5-2%201-6-4%201zm19%206-1%203q2%204%207%205%204-1%206-6l-3-3z'/%3e%3cpath%20fill='%23f7f3e6'%20d='M220%20130h100v6h-88l-9-1v-2l-3-1z'/%3e%3cpath%20fill='%23ee873d'%20d='m4%20294%202%201%201%203%2027%201v11l-5%201%201%203-3%202v2h-4v-2h-8l-9-1-1-6v-3zm30%2016h24l9%201%201%203H35z'/%3e%3cpath%20fill='%23cde1d5'%20d='m44%2015-2%202%202%203%201%209H30c-8%201-8%201-12-2l-2-3-10-2H0v-9q22-2%2044%202'/%3e%3cpath%20fill='%23534841'%20d='M251%20201h6l1%205h3q5%201%205%203l1%202%202%203-1%207-2-1-1%202-5%201q-7%200-10%205l-6%204-3-9v-5%209c-3-3-3-3-4-8q1-8%207-14l5-1v3q-4%205-7%204v2q4-1%207-5l2-1z'/%3e%3cpath%20fill='%23e2be7c'%20d='M219%20401h31l-2%202v16h-29z'/%3e%3cpath%20fill='%235db8b2'%20d='m86%20377%205%202v3l-2%202q-3%201-2%207l25%201%201-2v2h7l-1%203h-4v2h6v4H90l-15-1q-2-10%204-19%203-5%207-4'/%3e%3cpath%20fill='%2319bcad'%20d='m121%20471%207%2010%201%202%203%205%205%209%203%205%201%202%203%206c3%205%203%205%203%208q-7%202-14%200-6-8-9-17l-2-4-1-8z'/%3e%3cpath%20fill='%235ab0ac'%20d='M213%20349h30q-3%208-9%2013l-3%205-4%204h-14z'/%3e%3cpath%20fill='%23534841'%20d='M102%20245h43v10h-37l6%2011%201%203%202%203%201%203%206%2010v5q-4-3-6-8l-2-5-1-2-4-8-1-2-4-9-3-3z'/%3e%3cpath%20fill='%23f7f3e6'%20d='M266%20152h54v9h-40q-9%201-16-4l-1-4z'/%3e%3cpath%20fill='%23ee873d'%20d='m42%20347%2010%205%209%207v-4l3-6v3c0%209%200%209%203%2012l4%202%204%203%2029%2013%205%203h-3l-7-1-8-4-7-3-3-1-5-1v2h-3v2l-2%201-1%207v7q-5-1-9-6v-27h-2q-6-1-10-6l-2-1z'/%3e%3cpath%20fill='%23e2be7c'%20d='M38%20320h64v7l-8%201H69l-12-1H34v-6zm255%20180%203%205%203%203%201%206v4l1%204v7l1%204%201%2017v2l-2%205-1%204v4c-7-10-5-27-5-39h-2l-3%201h-5q-4-6-3-14v-4l2%202q4%204%209%203z'/%3e%3cpath%20fill='%23c74e31'%20d='M250%20343v-2h70v2q-11%208-25%206l1-3h2v-2h-2l-40-1h-3l-1%201h-7l-7-1h-16l-49-1h-17l3%206-10%201-4-1h-3v-7h37l17-1h34q11-1%2020%203m-173-4h3l35%202-1%202h-9l-6%201H43l-1%204H30q-7%201-14-2l-1-3H1l-1-3z'/%3e%3cpath%20fill='%23cde1d5'%20d='m196%20375%202%202%202%203%201%205q-12%203-23%203h-3l-8%201v-13h8v-2h-6l-1-2%2010-1h9q5%200%209%204M22%20222h13v8h41v2H24v58H7l-1-2h15l1-56H2v-2h20z'/%3e%3cpath%20fill='%23175864'%20d='M296%20240h24v52h-6v-40h2v-2h-2v-9h-2v4l-4%201v2l4-1v2h-11l6-8-2%202-2%202-2%201q-2%202-5%202z'/%3e%3cpath%20fill='%23534841'%20d='M221%20234h19l3%201h22l14%201h41v4h-37l-63-1z'/%3e%3cpath%20fill='%23118d8f'%20d='m257%20181%202%201v3h42l3%202h-8v4h3l4%202h-7v9l2-1h11v1l-13%201v5h3l13%204v-2l-4-1%204-1-1-8h3v16h-2v-3l-15%201-1%203h24v1h-28l2-2v-5l-2-2%202-1v-15l-5-1v-1h6v-4h-19v5h-16v-1h14v-3l-16-1%201%205-3-1%201-4h-25l-9-1v-1h34z'/%3e%3cpath%20fill='%23728277'%20d='m40%20468%203%201v2h9q5%200%209%202v7H22l-1%202v-11h18z'/%3e%3cpath%20fill='%23e2be7c'%20d='M145%20321h59v5q-4%202-9%202h-46v2h-3zM6%20514q4%201%204%205%203%2017%202%2034l-4%201v-2H6l-2-14H0v-24z'/%3e%3cpath%20fill='%23534841'%20d='M266%20500h7v36c0%206%200%206-2%209l-6%201z'/%3e%3cpath%20fill='%235ab0ac'%20d='m76%20129-3%204-1%202c-5%206-5%206-10%206H41c0-8%200-8%203-11q15-6%2032-1'/%3e%3cpath%20fill='%2319747f'%20d='M35%20232h15v22H35z'/%3e%3cpath%20fill='%23728277'%20d='m3%20537%202%201%201%207v7h2q4%2010%204%2022l-1%202H0v-38z'/%3e%3cpath%20fill='%23ee873d'%20d='M3%20352h4a221%20221%200%200%201%203%2054l-2%201-1-5H3z'/%3e%3cpath%20fill='%235ab0ac'%20d='M75%20348h22l-13%2018-3%205-6-2zm93%2044h36v9h-36v-3h6l-1-2-5-1z'/%3e%3cpath%20fill='%23f7f3e6'%20d='M148%20256h10c1%2024%201%2024-5%2032h-6v-14z'/%3e%3cpath%20fill='%23534841'%20d='m1%20420%202%201v3h2v4h17l-1%2019H9v-15l-3%201-1-2-2%2010-1-4H0v-16z'/%3e%3cpath%20fill='%23728277'%20d='M214%20467q3%202%202%205h12l3%201%2016%201%201%207-34%202z'/%3e%3cpath%20fill='%2319747f'%20d='m32%20563%201%202%205%201q9%202%2014%206l-1%204-34-1%202-4-4-1c10-6%2010-6%2014-5l3%201z'/%3e%3cpath%20fill='%23223742'%20d='M295%20319v9h-19v-2l-3%201h-8v-9h16l1%202%201-2%205-1z'/%3e%3cpath%20fill='%23ee873d'%20d='M210%20220h1v3l1%204%204%202%201%206v15h-8l-5-1v-10h3v-2h-3q1-6%204-10z'/%3e%3cpath%20fill='%23534841'%20d='m185%20104%205%201v2h2v-2h2v2l6%202v2l-8%201h-4l-2%204-5%206-2%202-7%205-2%204-4%205q-11%2011-16%2025l-1%203-8%201h-4v-1h4q5%200%205-2l3-7%203-7h2l1-2q6-12%2017-21l12-14-4-1%201-4h4z'/%3e%3cpath%20fill='%23728277'%20d='M75%20470h24l7%202v-2h11v12h-11l-1-5%203-2H75z'/%3e%3cpath%20fill='%23f7f3e6'%20d='m304%203%205%204q5%202%209%201%203%202%202%206h-33c2-7%202-7%207-10q4-3%2010-1'/%3e%3cpath%20fill='%23223742'%20d='M296%20318h2v2h3v-2h19v11h-24z'/%3e%3cpath%20fill='%2319bcad'%20d='M75%20484h28v9H80l-5-1z'/%3e%3cpath%20fill='%23728277'%20d='M126%20472h26l6%202-2%206-8%201h-3l-3%201h-11z'/%3e%3cpath%20fill='%235ab0ac'%20d='M187%20349h18v20l-2%204c-13-16-13-16-16-24'/%3e%3cpath%20fill='%2375bcb8'%20d='m233%2062-2%201q-12%209-17%2024l10%201-1%205v4l-2%203h-5v-9h-2l1%209h-7V85l3-1%201-5q6-11%2016-17z'/%3e%3cpath%20fill='%23223742'%20d='m263%20210%204%206-2%206-5%201q-7%200-10%205h-2q-2-6-1-13%202-4%206-6z'/%3e%3cpath%20fill='%23c74e31'%20d='M49%20254h2q3%209%202%2019h28v-19h4v22H49z'/%3e%3cpath%20fill='%2319747f'%20d='M103%20188h5l7%201h22l-1%203-1-2h-2l-1%202q-2%205-7%207l-4%206-1-2%202-5-4-1%202-6-8%202v-4h-2l-1%202q-1%203-4%205l-4-1-4%205-2-1%207-10-7%207-1%202h-2l1-8q4-4%2010-2'/%3e%3cpath%20fill='%23cde1d5'%20d='M124%20376h40v7l-40-1z'/%3e%3cpath%20fill='%235ab0ac'%20d='M124%20368h40v6h-40zm44-20h11q8%209%2012%2020-7%200-12-5l-5-2-6-5z'/%3e%3cpath%20fill='%23cde1d5'%20d='m91%20380%205%202%204%201%2014%205v2h-2v2H89l-3-1%201-7%204-2z'/%3e%3cpath%20fill='%23175864'%20d='M260%20202q9%202%2014%209%202%208%201%2015h-22l1-3%2011-1%201-3h2c-1-8-1-8-4-11l-5-2z'/%3e%3cpath%20fill='%2339adb2'%20d='M167%20191h5l-2%2010%208-6-1%2010%209-3v6h-18l-6-2-2%201%204-11%201-3z'/%3e%3cpath%20fill='%23cde1d5'%20d='M120%20371v3l-7%201%207%201v6h-9v2l-17-5q9-8%2021-8z'/%3e%3cpath%20fill='%235ab0ac'%20d='M124%20348h29q3%200%205%202l2%204h-36z'/%3e%3cpath%20fill='%235db8b2'%20d='M289%2052h24q-2%205-8%207l-1%201-4%202-6%203-5%202z'/%3e%3cpath%20fill='%235ab0ac'%20d='M124%20361h39l1%205h-40z'/%3e%3cpath%20fill='%23728277'%20d='M180%20473h24v8h-26z'/%3e%3cpath%20fill='%23e2be7c'%20d='M221%20292h99v2h-99z'/%3e%3cpath%20fill='%23534841'%20d='M0%20460h22v8l-3%201H0z'/%3e%3cpath%20fill='%23cde1d5'%20d='M75%20439h28v7H75z'/%3e%3cpath%20fill='%23e2be7c'%20d='M320%20312v2H220v-2z'/%3e%3cpath%20fill='%23534841'%20d='M194%20373h20v10l-13%202-3-5z'/%3e%3cpath%20fill='%23223742'%20d='M102%20245h43v5h-39l-2-1z'/%3e%3cpath%20fill='%2375bcb8'%20d='M214%20436c7%202%207%202%2010%205l2%205%202%202v3h15v1h-24q-3%201-5-2z'/%3e%3cpath%20fill='%235ab0ac'%20d='M75%20431h24l4%201v5H75z'/%3e%3cpath%20fill='%23e2be7c'%20d='M23%20232h1v58H7l-1-2h15v-30l1-10%201-11z'/%3e%3cpath%20fill='%23534841'%20d='M63%20516h12v16h-3v2l-3-1v-2h-2l2-4-3%202h-2z'/%3e%3cpath%20fill='%23728277'%20d='M84%20476h16l3%201v5H75v-5z'/%3e%3cpath%20fill='%23cde1d5'%20d='M124%20385h40v4h-40z'/%3e%3cpath%20fill='%23534841'%20d='M289%20491q4%202%204%206%202%209%200%2017c-7%200-7%200-10-2v-6l1-3v-2l3-1%201-5%201-2z'/%3e%3cpath%20fill='%23f7f3e6'%20d='M74%20300h17l-1%2010H73l3-9z'/%3e%3cpath%20fill='%23cde1d5'%20d='m75%20448%2027%201%201%205H75z'/%3e%3cpath%20fill='%2319747f'%20d='M222%20198h52l-1%205-3-1-8%201-2-1-1%204-1-2-4-3v-2h-31v36h-1z'/%3e%3cpath%20fill='%23cde1d5'%20d='M175%2049h51v3h-52z'/%3e%3cpath%20fill='%235db8b2'%20d='M6%20299h15l1%203v6l-10%201-6%201z'/%3e%3cpath%20fill='%235ab0ac'%20d='M226%2089h45v12h-8l-1-1v-9l-36-1zM34%20109h5v30l-5%201z'/%3e%3cpath%20fill='%23728277'%20d='m5%20430%201%203h2l1-2%201%204v6l-1%206h12v1l-21%201v-12h2z'/%3e%3cpath%20fill='%23cde1d5'%20d='M212%20112h2v94h-1z'/%3e%3cpath%20fill='%23c74e31'%20d='M30%20109h4v37h-4z'/%3e%3cpath%20fill='%23cde1d5'%20d='M75%20457h27l-1%205-27%201z'/%3e%3cpath%20fill='%2375bcb8'%20d='m25%20454%206%204%202-3%204-1h4q1%204-2%207h-3q-6%201-8%205v3h-7z'/%3e%3cpath%20fill='%2319747f'%20d='M131%20167h15l-5%2012h-9z'/%3e%3cpath%20fill='%2375bcb8'%20d='M124%20391h39v3l-39%201z'/%3e%3cpath%20fill='%23e2be7c'%20d='m115%20384%203%201h2v4h45l1%202h-37l-15-1-1-2-7-2z'/%3e%3cpath%20fill='%235ab0ac'%20d='M168%20360q7%202%2012%206l9%204v2h-2l-11%201h-5l-4%201v-6h2l2-1%201-2h-5z'/%3e%3cpath%20fill='%23223742'%20d='M296%20279h15l1%209h-16z'/%3e%3cpath%20fill='%2375bcb8'%20d='M177%20403h4l3%201-1%2015h-7q-3-7-2-15z'/%3e%3cpath%20fill='%23e2be7c'%20d='m102%20457%201%204h3l1-4v2l1%202%202%201v3l-2%201-2%203v-5l-2%201-1%203-28-1v-2h19l1-3%206-1z'/%3e%3cpath%20fill='%23728277'%20d='M120%20376h1v6h2v-6h1v6h38v1l-6%201v1h-32v4h-4v-4l-9-1v-2h9z'/%3e%3cpath%20fill='%23e2be7c'%20d='M3%20352h4l2%2010v3l1%2018H9l-1-8-3%201v5H4l-1-18z'/%3e%3cpath%20fill='%2375bcb8'%20d='M182%20250h21v5l-3%201h-52v-1l40-1v-1l-6-2z'/%3e%3cpath%20fill='%23e2be7c'%20d='M61%20426h2v10l1%205v54h-2c-4-15-2-32-2-48l1-6z'/%3e%3cpath%20fill='%23223742'%20d='M60%20165h4v10l-1%205%203%201-2%202%201%203q-3%203-7%202l-2-1v-2h-2v-5l6-1z'/%3e%3cpath%20fill='%23175864'%20d='M296%20259h16l-2%205h2v4h-16v-3l4-2-4%201z'/%3e%3cpath%20fill='%23223742'%20d='M114%20207h10l14%201v2l-7%201h-3l-2%201h-9l-1%203h-2v-2l-2-1v3h-9l4-4v3l4-5q1-2%203-2'/%3e%3cpath%20fill='%23118d8f'%20d='m11%20560%206%204%203-1v2l4-2%202%202-9%205%203%201-1%202h-2v2l2-1%207%201v1H11z'/%3e%3cpath%20fill='%23ee873d'%20d='M35%20310h23l9%201%201%203H35z'/%3e%3cpath%20fill='%23175864'%20d='M205%20526h3l1%203%204-1%201%2017-9-6%201-5v-1h-2z'/%3e%3cpath%20fill='%2319747f'%20d='M98%20166h10v12l-10%201z'/%3e%3cpath%20fill='%23118d8f'%20d='M7%20222h15v8H7z'/%3e%3cpath%20fill='%235ab0ac'%20d='M124%20356h40v3h-40z'/%3e%3cpath%20fill='%2375bcb8'%20d='M6%20320h17v7H6z'/%3e%3cpath%20fill='%235ab0ac'%20d='M299%20348h9l-16%209-15%205q1-4%205-6l5-2z'/%3e%3cpath%20fill='%23cde1d5'%20d='M206%20250h63v2h-44l-19-1z'/%3e%3cpath%20fill='%23175864'%20d='M296%20240h18l-2%201v4l-4%201v2l4-1v2h-11l6-8-2%202-2%202-2%201q-2%202-5%202z'/%3e%3cpath%20fill='%235ab0ac'%20d='M112%20403h9l-1%204-4%201%204%201v9h-8z'/%3e%3cpath%20fill='%23175864'%20d='M296%20250h16v8l-16-1z'/%3e%3cpath%20fill='%2375bcb8'%20d='M212%20168h1l1%2061q-3-2-4-5l-2%203%201-7%201-4h2z'/%3e%3cpath%20fill='%23728277'%20d='M265%20429h1v68h7v3h-7v5l2%201h-2v12h-1z'/%3e%3cpath%20fill='%23cde1d5'%20d='M204%20371h23l-10%2011h-3v-9l-11%201z'/%3e%3cpath%20fill='%235db8b2'%20d='M46%20348h17l-2%2011-10-5-2-2z'/%3e%3cpath%20fill='%23c74e31'%20d='M21%20159h7l-1%202%201%204H11l-5-2%204-1-2-2z'/%3e%3cpath%20fill='%2319bcad'%20d='M117%20483v10h-11v-8q5-3%2011-2'/%3e%3cpath%20fill='%23175864'%20d='M296%20270h16l-4%203h4v4h-16z'/%3e%3cpath%20fill='%235ab0ac'%20d='m219%20403%207%201v14h-7z'/%3e%3cpath%20fill='%23e2be7c'%20d='m42%20347%2010%205%209%207v-4l3-6v4l-1%2016-1%2019h-1v-27l-5-1-7-5-2-1z'/%3e%3cpath%20fill='%23c74e31'%20d='M39%20109h3v33l-4%201z'/%3e%3cpath%20fill='%2319747f'%20d='m6%20500%202%201v11h4l3%2011h-2v5h-2l-1-5-1-3-1-5-3-1v-7z'/%3e%3cpath%20fill='%235ab0ac'%20d='M249%20403h6l1%204v12h-6z'/%3e%3cpath%20fill='%23223742'%20d='M320%20274v18h-6v-14h2l1-3z'/%3e%3cpath%20fill='%235ab0ac'%20d='M265%20403h6v15l-1%201h-5zm-8%200h6v15l-1%201h-5z'/%3e%3cpath%20fill='%23cde1d5'%20d='M239%20258h48v2h-47z'/%3e%3cpath%20fill='%23ee873d'%20d='M23%20222h12v7l-3%201h-9z'/%3e%3cpath%20fill='%23534841'%20d='M151%20522q4%201%206%205l2%204%202%204%207%2013%201%202%201%202h-3l-7-11-1-2-4-6-1-3c-3-5-3-5-3-8'/%3e%3cpath%20fill='%2375bcb8'%20d='M86%20111h94v1H86z'/%3e%3cpath%20fill='%23728277'%20d='M0%20460h10l-1%208h11v1H0z'/%3e%3cpath%20fill='%2375bcb8'%20d='m244%20455%206%203%201%203-3%201-2-1-2%203-10-6%201-3q5-2%209%200'/%3e%3cpath%20fill='%23cde1d5'%20d='m233%2062-2%201q-12%209-17%2024h-4q3-15%2016-24%204-3%207-1'/%3e%3cpath%20fill='%23175864'%20d='m122%20371%201%203h14l16%201v1h-30v6h-2v-6h-8l-1-2h9z'/%3e%3cpath%20fill='%2319747f'%20d='M37%20165h11v4l-6%201%203%203-2%201q-3%201-4%205h-2z'/%3e%3cpath%20fill='%2375bcb8'%20d='M225%2092h8l3%201v7h-12z'/%3e%3cpath%20fill='%235ab0ac'%20d='M104%20403h6v15h-6zm-16%200h6v15h-6z'/%3e%3cpath%20fill='%23728277'%20d='m102%20254%203%201h-2v33h-4v-33h1l1%2021z'/%3e%3cpath%20fill='%235ab0ac'%20d='M96%20403h6v11l-1%204h-5z'/%3e%3cpath%20fill='%23cde1d5'%20d='M204%20388v4h-36v-1h2l11-1%204-1h4l3-1%206-1z'/%3e%3cpath%20fill='%2319747f'%20d='M34%20188h13l1%204-6%202-2-1-1%202-1%202h-6l2-3z'/%3e%3cpath%20fill='%2375bcb8'%20d='M254%2092h6v9h-11c2-9%202-9%205-9'/%3e%3cpath%20fill='%23223742'%20d='M245%20204h4v3q-4%205-7%204v2h2l-1%2010h-1l-1-5v9c-3-3-3-3-4-8q2-9%208-15M9%20450h12v8l-12-1z'/%3e%3cpath%20fill='%235ab0ac'%20d='M75%20426h28v3H75z'/%3e%3cpath%20fill='%23223742'%20d='M297%20193h15v5l-9%201h-6z'/%3e%3cpath%20fill='%23728277'%20d='M113%20426h82v1h-82z'/%3e%3cpath%20fill='%235ab0ac'%20d='M157%20409h8v9h-11z'/%3e%3cpath%20fill='%23175864'%20d='M294%20280h2v8h13v2h3v2h-18z'/%3e%3cpath%20fill='%2375bcb8'%20d='M238%2092h11l-3%209h-7z'/%3e%3cpath%20fill='%2319747f'%20d='m69%20525%202%201-4%205h2l3%203v-2l4%202v8l-4%205-3-1%201-3-2-1%201-3h4l-1-4-4-1v-2h-2q1-6%203-7'/%3e%3cpath%20fill='%23cde1d5'%20d='m101%20433%201%204H75l1-3z'/%3e%3cpath%20fill='%235ab0ac'%20d='M243%20403h5v16h-5zm-75%200%205%201v15h-6v-11h3v-2l-3-1z'/%3e%3cpath%20fill='%2319747f'%20d='m282%2090-1%205v3l-2%203h-6V91z'/%3e%3cpath%20fill='%23cde1d5'%20d='M10%20530h1l1%2014v9l-3%201-1-13v-4z'/%3e%3cpath%20fill='%235ab0ac'%20d='M236%20403h5v16h-5z'/%3e%3cpath%20fill='%23728277'%20d='M217%20252h1v79h-1zm24-116h79v1h-79z'/%3e%3cpath%20fill='%23ee873d'%20d='M173%20112h12q-4%207-10%2011-2-5-2-11'/%3e%3cpath%20fill='%2375bcb8'%20d='M22%20480h39v2H22z'/%3e%3cpath%20fill='%235ab0ac'%20d='m200%20403%204%201v15h-5v-15z'/%3e%3cpath%20fill='%23cde1d5'%20d='M124%20372h39v2h-39z'/%3e%3cpath%20fill='%23e2be7c'%20d='m91%20446%2025%201v3l-24-1z'/%3e%3cpath%20fill='%23728277'%20d='M103%20450h4v4h3v2l-3%201-1%204h-3l-1-6H75v-1h28z'/%3e%3cpath%20fill='%235ab0ac'%20d='M81%20403h5v15h-5zm-28%200h5v15h-5z'/%3e%3cpath%20fill='%23728277'%20d='M106%20255h2l3%205%201%203%202%203%203%206%207%2013v5q-4-3-6-8l-2-5-1-2-3-6-1-2-3-5z'/%3e%3cpath%20fill='%23534841'%20d='M221%20291h73v1h-73z'/%3e%3cpath%20fill='%23f7f3e6'%20d='m4%2075%205%201%201%207H0v-7z'/%3e%3cpath%20fill='%2375bcb8'%20d='m70%2038%201%202H0v-1h27l13-1z'/%3e%3cpath%20fill='%23728277'%20d='m64%20353%2010%201-2%202-1%205v5q-7-2-7-5z'/%3e%3cpath%20fill='%23cde1d5'%20d='m21%20252%202%201v35h-2z'/%3e%3cpath%20fill='%23728277'%20d='m204%20106%203%201q3%200%205%202l-2%201%202%202h-16l4-1v-2l-7-1q5-2%2011-2'/%3e%3cpath%20fill='%23cde1d5'%20d='M250%20130h70v1h-70zM21%20418q9-1%2016%203l1%202H21z'/%3e%3cpath%20fill='%2375bcb8'%20d='M124%20398h40v2l-41%201z'/%3e%3cpath%20fill='%23175864'%20d='M13%20232h2v34h-2z'/%3e%3cpath%20fill='%23118d8f'%20d='M254%20199h20l-1%204-3-1-8%201-2-1-1%204-1-2-4-3z'/%3e%3cpath%20fill='%23cde1d5'%20d='M75%20465h27v3l-27-1z'/%3e%3cpath%20fill='%235db8b2'%20d='M228%20404h5v14l-5%201z'/%3e%3cpath%20fill='%235ab0ac'%20d='M193%20403h4v16h-5v-15z'/%3e%3cpath%20fill='%23728277'%20d='M24%20208h10v3h21v1H19v-1h5z'/%3e%3cpath%20fill='%23118d8f'%20d='M217%20184h1v66h-1z'/%3e%3cpath%20fill='%2319747f'%20d='M148%20167h6v7l-4%201v3h-2l-1-2-1%202-2-1zm74-56h47l-1%205-5%202v-5l-41-1zm45%20164h26l-1%203-3%201v-3h-24v15h-2v-15z'/%3e%3cpath%20fill='%2339adb2'%20d='M205%20524h4l-1%204v-2h-3l-1%207-2-1z'/%3e%3cpath%20fill='%23728277'%20d='M173%20406h1l1%2010h-2l-1-4v-5zm-61%2012h6v1h-6zm-32%200h6v1h-6zm33-28%203%201-3%201z'/%3e%3cpath%20fill='%23534841'%20d='M114%20447h2v2h-2zm-1-57%202%201Z'/%3e%3c/svg%3e",
	rainforest: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='576'%3e%3cpath%20fill='%2326362f'%20d='M0%200h320v576H0z'/%3e%3cpath%20fill='%23293f37'%20d='M53%200h267v334l-13-1h-4l-7-1%204-8%202-2%201-1-12-4q-14-3-23-15l-1-2%205-1-1-3q-2-9%203-17%205-9%2013-13h2q0-3-4-5l-9-2v3h-2v-3l-11%209-2%202h-2v-2l-5-2-3-1q-4%200-7%204l-4%205-3%204-2%202-1-2%202-5c5-9%205-9%205-12l-7%209h-2l-2%204-3%203-12%2015-1-2q7-16%2021-28l2-4q-10%200-18%208l-1-3-2%202-4%204%202%202-2%202c-20%2019-34%2049-42%2075l-1%203-3%201q0-8%203-16l1-3%2011-24%202-3c4-9%204-9%207-12l2-3%207-12%201-1%2011-12%204-4-2-7-4%201%201-3q0-6-4-10l-3-3q-1-2-6-2l-6%205-1%201-4%204-1-2%205-8q3-4%203-8l-5-8-15-16-5-4q-13-11-13-29l-2-10-6-32-7-46h13l24-2h2V66l-15%204-14%201h-2c-8%200-8%200-11-2q-4-13-3-28l-1-3v-3l-1-4V17l-2-6q-11%2012-27%2014v3l2%2023q-11-8-19-20%200-4%203-8l-3-2L53%201z'/%3e%3cpath%20fill='%23273a31'%20d='M0%200c53%200%2053%200%2073%2013l17%209-2%202-1%205q6%2012%2017%2021V38l-1-13%203-1c18-6%2018-6%2023-13l1-2h2v11l1%203%202%2017v6l1%207%201%2016%2013%201h2q11%200%2020-3l7-1v17q-19%206-39%202l1%202%201%204v3l6%2042%205%2024%204%2017v3l1%203%201%203-1%206-3-2-4-2-2-2-7-4v-2l-2-1-9-4-3-2-6-4-2%2010h-2v3c-3%2019-18%2036-29%2050l-3%205-4%204-3%203-11%2011-3-1-1-2q-7-2-14-1l-9%2012q-6%207-15%2013l4-1q-2%205-7%207l-2%202q-9%207-21%208z'/%3e%3cpath%20fill='%237dcbba'%20d='m216%2065%204%2016%205%2016%203%2010%206%2015%203%208c5%2012%2012%2026%2024%2033q11%203%2022%200%201%209-3%2017-5%209-4%2018%201%207-2%2014l-1-2q-5%203-8%208l-3%202q-13%2012-20%2029l-7-2-1-2-2-1-7-5-1%204-2-8h-2l-2%2010c-10%201-10%201-13-2l-5-6-9%207-3%202-2%202-1-2%205-8q3-4%203-8l-5-8-13-14-2-2-5-4q-13-11-13-29l-2-10-6-32-7-46h2c29%201%2029%201%2042-4l3-1%2020-11%202-2%202-1z'/%3e%3cpath%20fill='%2337846e'%20d='M84%20268q6%202%208%207l1%202v2l1%203%201%202q4%2012%205%2025l2%2011%208-36q16%207%2029%2020l4%203%205%207-5%2013-9%2021-15%2032-1%203-3%204-3%203-6-2%202%204-5%201%202%202%203%204%203%201%203%201%201%203%204%202%203%203-7%206v-3h-10q-9%200-16%206l-1%201q-8%2011-21%2011h-3l-9%201h-5l-9%203v2h3l45%202v6q-2%205-8%205H71l-4%201H53l-18%201h-3l-8%201v2h17l6%201h17l4-1h9v2l-3%201h-5l-2%201c-7%201-7%201-10%203l-1%202%2029%203-1%203%2014%204v2l-10%201q-16%201-33%206l-9%203q-22%205-42%2012l-4%201V347l12%205%2024%2010%202%201%209%204%206%202%203%201%202%201q8%202%2017-2l2-4%204-4q5-1%2010%202l1-4%203-15%201-2v-5l2-6v-17l-1-6q-2-21-12-38z'/%3e%3cpath%20fill='%232c5447'%20d='M122%20169c6%203%206%203%208%206q8%2013%2020%2023c14%2012%2014%2012%2017%2020v2l-8-4-2-2-5-5q-3-4-7-3l-1%204h-2l-1%203q-5%2024-21%2044h-2l-6-1-4%204-7%205-4%204h-3l-2%207-2-2-4-4%201%202a88%2088%200%200%201%2011%2033c3%2024%203%2024-1%2034l-3%2013-3%2011h-2l-8-1-5%205q-5%205-11%206l-10-2-2-1-3-1-5-2-23-10-8-2q-8-2-14-8-3-14-1-28v-8l1-19%202-1%203-1%203-1q12-4%2021-12h-2l-2-1%202-2q13-8%2020-21%203-4%206-3l11%201%202%203q6-2%2010-7l3-3%203-5%202-1q3-1%205-6l6-9%2015-23%201-2%207-19h2v-3z'/%3e%3cpath%20fill='%236bb783'%20d='m224%2068%205%208c21%2034%2021%2034%2040%2039q8%202%2015-3l4-3%202-1-1%208v3l-2%2016v3l-1%207-1%203v2l1%208%205%205v2l4%202-1%2016%204-3%207-5c5-3%208-12%2010-18l2-21%201-8v-3l2-4v213l-13-1h-4l-7-1%204-8%202-2%201-1-12-4q-14-3-23-15l-1-2%205-1-1-3q-2-9%203-17%205-9%2013-13h2q0-3-4-5l-9-2v3h-2v-3l-11%209-2%202h-2v-2l-5-2-3-1q-4%200-7%204l-4%205-3%204-2%202-1-2%202-5c5-9%205-9%205-12l-7%209h-2l-2%204-3%203-12%2015-1-2q7-16%2021-28l2-4q-10%200-18%208l-1-3-2%202-4%204%202%202-2%202c-20%2019-34%2049-42%2075l-1%203-3%201q0-8%203-16l1-3%2011-24%202-3c4-9%204-9%207-12l2-3%207-12%201-1%2011-12%204-4-2-7-4%201%201-3-2-8h10v-3l2-7h2l2%207%201-3%205%204%203%201%203%203%206%201%201-2q6-11%2014-21l2-2%208-9q2-3%206-4%203-7%202-14%200-10%205-18%203-11%203-22l-2%201q-8%203-16%200c-16-7-21-24-27-39l-2-5-8-23-1-3z'/%3e%3cpath%20fill='%23233a33'%20d='m128%20173%2014%207v2l2%201q17%209%2029%2022l5%205q5%203%208%209l1%201%207%2010q-2%209-8%2017l12-11%209%207%202%203%202%206-1%203h4q3%202%202%206l-4%206-2%202-4%201-2%204-2%203-2%202-3%204-7%2012-2%204q-12%2020-19%2041l-1%204q-3%208-4%2018-2%206-6%2010l-1%202-13%2015-2%202-14%2013-4%203-3%201-5-4q-4-4-10-4v-3l-3-2v-2l4-2-1-3%207%201%202-3%201-2%202-4%2015-32%2011-25%201-2%202-6-4-6-1-2q-15-13-32-23v2l-5%2028-3%2012h-1v-3l-2-11v-3q-1-12-5-24-4-8%200-16l3-1%203-3%2015-11%205%203%201-2%204-7q11-17%2017-38h2l1-5q7%201%2010%206%205%206%2012%209-7-15-21-24-10-9-18-21z'/%3e%3cpath%20fill='%232c5447'%20d='M237%20258q-1%205-5%208-11%209-16%2023l2-2%2011-14%202-2%203-1%201-2q2-6%208-9l-4%2010-1%202-1%202-2%205%209-10q4-5%207-4l8%204v2l2-1c11-10%2011-10%2013-10v3h2v-3q8-1%2013%204v3l-4%203q-11%207-14%2020l1%209%202%202-6%201%203%204%202%203q10%207%2022%209l3%201%206%202-1%202-2%202-1%202-4%206h8l5%201%2011%201v20l-7%204h-2l-1%203v-2l-2%201-13%201h-3q-12%200-22-3l-10-2-4%205-3%201%201-12-3%2012h-2q-4-11-3-23l-2%201-1%204-4-1v-5h-2v-3l2-12v-4l-2-9q-9%202-15%2010l-3-2-3-1-4-4-3-1-13%2035-2%204q-8%2021-28%2032l-5%201q-3%200-5%203l-4%206-1%203-4%208-3%206-14%2034-4%206-2%202q4-21%2014-41l2-4%204-10q-14%209-24%2022l-2%202h-2l-1%203-6%2013-4%2015v4h-2q-4-10%200-20l4-9q-16%2013-20%2032h-2q-1-8%203-16l1-4-39-2h-2l-7-1v-2q4-4%2011-4h2l6-1%206-1h6q7-1%2012-6l2-1%201-2c6-7%206-7%2011-7h17l1%202%202-3%2016-14q17-13%2027-32l1-1%202-11%201-3%204%201v-2l6-16%201-2q11-31%2034-57l2-2%201-1-2-2%205-6h2l1%202%202-1%202-2%203-2q5-4%2011-2'/%3e%3cpath%20fill='%237dcbba'%20d='M53%200h139l5%2015%2014%2031q-9%209-19%2014l-3%201q-8%204-17%206l-5%202-19%202c-8%200-8%200-11-2q-4-13-3-28l-1-3v-3l-1-4V17l-2-6q-11%2012-27%2014v3l2%2023q-11-8-19-20%200-4%203-8l-3-2L53%201z'/%3e%3cpath%20fill='%234f885c'%20d='m89%20490-1%202-6%201-4%201h-2l-11%202-31%206-3%201-22%205%2033-4%2034-5%202-1%2026-1q-4%204-9%203l-4%201-2%201-16%203-19%204h12l29%202v1l-39%201%2032%204%2032%202%2014%203v1h-10l-21%202h3l11%201%204%201q15%202%2029%206v2h-2l-27-2h-3l-81-4%202%201c18%206%2018%206%2026%2011l-2%202%209%204v1q-9%203-18%202H43v2l4%201c32%207%2032%207%2045%2013l1%202-56-14-4-1-3-1h-3l-8-1%205%203%204%202%2010%206%2020%2013v1H0v-72q44-14%2089-14'/%3e%3cpath%20fill='%23326351'%20d='M130%209h2v11l1%203v3l1%207%201%207v6l1%207%201%2016%2013%201h2q11%200%2020-3l7-1v17q-19%206-39%202l1%202%201%204v5l11%2064%204%2017v3l1%203%201%203-1%206-7-4-9-7v-4l-3-11q-4-12-6-25l-2-9-1-4c-2-13-2-13-7-16l-6-3-2-1-1-6%204%202v-1l-2-1q-5-6-5-13l-1-2-2-16-1-5-2-13-2-28%203-1c18-6%2018-6%2023-13z'/%3e%3cpath%20fill='%234f885c'%20d='M237%20258q-1%205-5%208-15%2012-18%2031l-1%203h2l-3%208-1%203-9%2021-6%2015-2%204q-8%2021-28%2032l-5%201q-3%200-5%203l-4%206-1%203-4%208-3%206-14%2034-4%206-2%202q4-21%2014-41l2-4%204-10q-14%209-24%2022l-2%202h-2l-1%203-6%2013-4%2015v4h-2q-4-10%200-20l4-9q-16%2013-20%2032h-2q-1-8%203-16l1-4-39-2h-2l-7-1v-2q4-4%2011-4h2l6-1%206-1h6q7-1%2012-6l2-1%201-2c6-7%206-7%2011-7h17l1%202%202-3%2016-14q17-13%2027-32l1-1%202-11%201-3%204%201v-2l6-16%201-2q11-31%2034-57l2-2%201-1-2-2%205-6h2l1%202%202-1%202-2%203-2q5-4%2011-2'/%3e%3cpath%20fill='%23326351'%20d='M84%20268q6%202%208%207l1%202%201%205%201%202q4%2012%205%2025l2%2011%208-36q16%207%2029%2020l4%203%205%207-5%2013-9%2021-15%2032-1%203-3%204-3%203-6-2%202%204c-6%202-6%202-10%201l-8-5-3-2-16-8-3-1-2-1-5-3%205-1%202-1%205-1%203-3%201-2%204-4q5-1%2010%202l4-19%201-2v-5l2-6v-17l-1-6q-2-21-12-38z'/%3e%3cpath%20fill='%237dcbba'%20d='M264%2010h2l-2%2021-1%207-5%2034q-2%2017%206%2031l3%202%203-21%201-8v-3l1-6%201-8v-4l1-7%205-34%208%208%201%202%202%202%201%201%206%207c4%207%200%2019-1%2026l-2%2016v4l-1%207q1%2013-9%2021-7%206-15%204c-19-5-29-24-39-40-6-11-6-11-6-15l3-3a175%20175%200%200%200%2037-44M103%2064c6%204%206%204%207%209l1%209v2c1%2014%201%2014%207%2019l3%202q-4%200-7-3l1%206%206%202q4%202%207%206l2%207v2l2%208%201%205%204%2016%202%209%201%202%202%209v7q-19-9-30-27-3-6-6-6l-2-5-14-24-21-34-2-5%202-1q16-2%2028-10h2v-2z'/%3e%3cpath%20fill='%23273a31'%20d='M302%200h18v119l-1%204-1%2017q-1%2020-11%2035-4%204-10%206l-4%203v-4l1-4v-3q1-5-2-9l-3-2c-5-5-5-5-5-8l1-7%209%207v2h2v-3l8-60v-2q2-6-3-11l-1-1c-5-5-5-5-5-9v-2l1-3v-2h2l4%205%205%206v-2l1-13%201-11-6-8q-6-9-5-19l3-10%201-6z'/%3e%3cpath%20fill='%232c5447'%20d='m73%2092%209%2012%208%2013%204%206%202%203c4%207%204%207%204%2012l-4%208-4%208-1%202-8%2014-1%202q-3%205-7%208l-1%203c-4%204-4%204-8%204l-1-2-5%204q-1%204-6%206l-1%202-7-4-2-2-1-3c5-5%205-5%209-5l1-4h2l2-4%204-5%202-5h2l1-5h2l2-4v-3l1-5-4%201-1-4q-5%203-8%207-9%2010-22%2016l-2%201-8%202-3-4-2-2-1-4%202-1q13-4%2021-13-5%201-8%205l-5%201v-2l3-2c21-11%2032-36%2040-57m40%20460h12c56%200%2056%200%2074%206h8l2-6%201%207%2027-1c19-1%2043%201%2061%208v2a80%2080%200%200%201-30%203h-31c-14%200-14%200-20%202l-1%202-6%201H108v-3l13-1h3l18-3-11-4h-2l-6-1%203-3-9-2-2-1-3-1h-2l-6-2v-2z'/%3e%3cpath%20fill='%237dcbba'%20d='m18%200%2017-1c11%200%2011%200%2016%203l5%206%203%204%2012%2015q6%2010%2014%2018l3%203%208%209q3%202%202%205-10%209-24%2012l-3%201-9-1q-7-8-11-17l-4-8-14-23L21%206z'/%3e%3cpath%20fill='%2337846e'%20d='M43%20440v2l-3%202-3%201-2%202-2%201-9%204v2h17l6%201h17l4-1h9v2l-3%201h-5l-2%201c-7%201-7%201-10%203l-1%202%2029%203-1%203%2014%204v2l-10%201q-16%201-33%206l-9%203q-22%205-42%2012l-4%201v-40l8-5%203-1%203-2%202-1%203-1%203-1c16-7%2016-7%2021-7M261%200h41l-1%2015q-3%2010-1%2020l5%206q5%204%205%2010%200%2012-3%2023-4-1-6-5l-2-2-1-4h-2v5h-1v-7l1-3%201-10q3-7-1-14l-9-10-7-9-4%2023-1%207-3%2035-1%203v6l-4%2020h-1v-5l-3-1c-8-14-6-28-4-43l4-30%201-9v-2l1-5q0-8-4-14'/%3e%3cpath%20fill='%237dcbba'%20d='m224%2068%205%208c21%2034%2021%2034%2040%2039q8%202%2015-3l4-3%202-1-4%2037v6q-2%204-5%206-8%203-16%200c-16-7-21-24-27-39l-2-5-8-23-1-3z'/%3e%3cpath%20fill='%234f885c'%20d='M273%20210v2l-1%204v3l1%208v9l-3%201v4l2%201-2%202-3%209q-1%208-7%2015l-6-2h-7l-3%204-2%202-2%202-3%204-2%202-1-2%202-5c5-9%205-9%205-12l-7%209h-2l-2%204-3%203-12%2015-1-2q7-16%2021-28l2-4q-10%200-18%208l-1-3-2%202-4%204%202%202-2%202c-20%2019-34%2049-42%2075l-1%203-3%201q0-8%203-16l1-3%2011-24%202-3c4-9%204-9%207-12l2-3%207-12%201-1%2011-12%204-4-2-7-4%201%201-3-2-8h10v-3l2-7h2l2%207%201-3%205%204%203%201%203%203%206%201%201-2q6-11%2014-21l2-2%208-9q3-5%206-4m46%2050h1v74l-13-1h-4l-7-1%204-8%202-2%201-1-12-4q-14-3-23-15l-1-2%205-1-1-3v-10l4-2h5l4%201%202%204%202-1%203%204%201-3%201-3%206-9h2v-4l1-3v-2l2-1%201%2019%204-12%201%208q4-6%205-12z'/%3e%3cpath%20fill='%237dcbba'%20d='M0%20154h1l1%203%205%2010%203%203%202%203c8%2010%208%2010%2010%2016q2%203%206%205l3%204%207%209c9%209%2018%2020%2018%2033v4c-22-5-34-16-48-33l-3-4q-5-5-6-11v-9l1-10z'/%3e%3cpath%20fill='%236bb783'%20d='M104%20497q-4%204-9%203l-4%201-2%201-16%203h-3l-16%204h12l29%202v1l-39%201%2032%204%2032%202%2014%203v1h-10l-18%202%2011%201%204%201q15%202%2029%206v2h-2l-49-3-3-1-32-2h-2l-32-3%203-2%202-3-1-3h-3v-2l-1-2-5-1-3-2-2%201v-2l-3%201v-2q12-4%2024-5l2-1%2033-4%202-1z'/%3e%3cpath%20fill='%23326351'%20d='M280%20313q12%202%2024%207l-1%202-2%202-1%202-4%206h8l5%201%206%201h5v10l1%203-1%207-7%204h-2l-1%203v-2l-2%201-13%201h-3q-12%200-22-3c-9-2-9-2-12-1-2-9-2-9%200-13l9-4-1%205q7-2%2012-7%202-9%201-18v-6z'/%3e%3cpath%20fill='%2390d19c'%20d='M235%20176h1l1%2055-4-9-1-3-1-2q0%2011%205%2020l3%208%201-2q9-23%2029-38l7-2-2%209-1-2q-5%203-8%208l-3%202q-13%2012-20%2029l-7-2-1-2-2-1-7-5-1%204-2-8h-2l-2%2010c-10%201-10%201-13-2l-5-6-9%207-3%202-2%202-1-2%203-5%206-10%205-7h2v-2q6-7%2015-6l11%206q-5-17-20-26-8-2-17%201%208-7%2020-7%209%200%2016%205%204%203%206%208v-3z'/%3e%3cpath%20fill='%231e2b26'%20d='M84%20291h2q2%2040-22%2073-4%204-9%203l-7-3-2-1-11-5-4-2h-2l-4-3v-3l6-3%203-2%206-1%201-3%203-1q5-3%208-8l5-5h2l1-2q2-4%206-7l5-7%207-11z'/%3e%3cpath%20fill='%23a4e2d3'%20d='M53%200h85c-9%2013-17%2021-32%2025h-3v3l2%2023q-11-8-19-20%200-4%203-8l-3-2L53%201z'/%3e%3cpath%20fill='%232c5447'%20d='m198%20236%209%207%202%203%202%206-1%203h4q3%202%202%206l-4%206-2%202-4%201-1%202q-2%204-6%207h-2l-1-3q-5%201-8%204h-2v2l-6%203q-4%202-5%207v2l-1%202v-7l-3%201q-10%200-18-8%202-4%206-7%2013-9%2022-23%207-10%2017-16'/%3e%3cpath%20fill='%2322362f'%20d='M237%20258q-1%205-5%208a98%2098%200%200%200-24%2040q-5%2014-16%2025l-7%208-2%202-2%204h-2l-2%204-9%2011h-2c6-30%2022-64%2044-86l2-2%201-1-2-2%205-6h2l1%202%202-1%202-2%203-2q5-4%2011-2'/%3e%3cpath%20fill='%2321312b'%20d='m51%20281%201%205h3v2h2c-4%2015-19%2029-32%2037l-6%201v2l-8%204-2%201H7l-2%201-5%201v-29l6-1q24-7%2041-23z'/%3e%3cpath%20fill='%23326351'%20d='m73%2092%2010%2012%202%208-6%2011-2%202c-9%2015-20%2033-36%2041l-3%201-2%201-2%201-8%202-3-4-2-2-1-4%202-1q13-4%2021-13-5%201-8%205l-5%201v-2l3-2c21-11%2032-36%2040-57'/%3e%3cpath%20fill='%236bb783'%20d='M319%20241h1v12q1%207-3%2012l-3%2011q-1%204-5%207v-7l-4%2013h-1l-1-21-2%209-4%201-2%206-4%209-4-4-2%202-1-6h-11q1-8%208-14c5-5%205-5%208-5q0-3-4-5l-9-2v3h-2v-3l-11%209-2%202h-2l4-8q4-6%204-15h1v2l1%203%202%201%201-2%2010-4%204-2h7v8l4-1%204-1%204%203%204%201q4-1%206%203v-2z'/%3e%3cpath%20fill='%234f885c'%20d='M53%20250c10%200%2010%200%2013%203l2%204c-8%2022-32%2036-51%2045q-8%204-17%204v-14l5-2q14-4%2024-13h-2l-2-1%202-2q13-8%2020-21%203-4%206-3'/%3e%3cpath%20fill='%231e2b26'%20d='m90%20280%202%201c5%2017%2012%2041%205%2058l-3%2013-3%2011h-2l-8-1-5%205q-5%205-11%206-8%200-15-4l-3-3h2l3%201%204%201q4%200%207-2c15-14%2024-41%2024-61v-4l1-7v-7z'/%3e%3cpath%20fill='%232c5447'%20d='M0%200q9-2%2018%200%207%207%2011%2017l5%208%202%204q-1%204-6%204v2c-5%204-5%204-9%204l1%202%204%2010%202%203q5%209%205%2017-7-5-11-12l-1-2-8-14-5-7C-1%2025-1%2015%200%200m213%20515%203%201%202%208%2014%202v-7l5-1q3%202%202%205v3l2-1h9l6%201v3l3%201-6%201v2l2%201%203%201%201%203-7%202-1%2010h-2l-1-5h-3l2-1%202-1v-4l-7-1%201%209q-2-2-2-5v-3h-7l-6-1%201%202%201%207-1-2-3-3-1%202v-2h-3l1-7-12-1v8l-2%201v-10h-13l-2%209h-2v-8h-14v2h-2c0-6%200-6%203-9l5-2v-2h6l4-1%209-1-1-4%202-1%203%209h2v-3z'/%3e%3cpath%20fill='%2325483b'%20d='M313%20172h1l-1%2030-1%205-1%2013%206-8%202-4h1c1%2015%201%2015-2%2019-5%204-5%204-8%204v-8q-9%204-15%2012-3%203-8%202l2-17q3%201%205%204l-1-3q-5-12%200-25%204-8%2011-15l1%202-1%203q-4%207-3%2015l1-3c5-20%205-20%2011-26'/%3e%3cpath%20fill='%2390d19c'%20d='m310%20223%201%207%209-5q2%2013-3%2025l-2%208-3-1v-2h-3q-5%200-9-3l-1%201h-6v-8q-7%200-12%204h-3l-1%203v-3l-2%202-5%204-1-3-1%203v-8q0-3%203-5l-1-5%202-1%202-5h4v5c12%201%2012%201%2017-2l5-4c6-7%206-7%2010-7'/%3e%3cpath%20fill='%236bb783'%20d='m294%2069%201%202%205%207%202%203%203%203-1%2020-1%203-4%2030v3l-1%207v2l-2%207h-2l-3-4-6-5v-3l3-29%201-7v-2l1-3v-2l1-6zm-179%2039q7%202%2012%206l3%209v2l2%208%201%205%204%2016%202%209%201%202%202%209v7l-8-5-3-1-2-1-2-2q-4-1-6-6v-7a126%20126%200%200%200-4-35z'/%3e%3cpath%20fill='%2325483b'%20d='m0%20470%2036%201h17l3%201%2017%202q-5%204-11%204-26%205-53%2014l-2%201H5l-5%201z'/%3e%3cpath%20fill='%23a4e2d3'%20d='m267%20300%2025%203%2028%205v26l-13-1h-4l-7-1%204-8%202-2%201-1-12-4q-14-3-23-15z'/%3e%3cpath%20fill='%234f885c'%20d='M110%20284q16%207%2029%2020l4%203%205%207-5%2013-2%206-2%204-9-3-2%201-7-2%203-6%203-4v-4l-2-1v-2h-2v-14l-3-1-2-3q-6%201-7%203l-2-4z'/%3e%3cpath%20fill='%23233a33'%20d='M107%20412h8q0%204-3%207l-3%202q-9%206-16%2016-2%203-5%202h-3l-19-1-9-1h-9l-7-1v-2q4-4%2011-4h2l6-1%206-1h6q7-1%2012-6l2-1%201-2q8-9%2020-7'/%3e%3cpath%20fill='%23326351'%20d='m80%20362%205%201%202%201%202%201v3l2-1%206%202%204%203%202%202%2013%2010-3%206-7-2%202%204c-6%202-6%202-10%201l-8-5-3-2-16-8-3-1-2-1-5-3%205-1%202-1%205-1%203-3%201-2z'/%3e%3cpath%20fill='%234f885c'%20d='m89%20490-1%202-6%201-4%201h-2l-11%202-31%206-3%201-22%205%2014-1-2%202h-4l4%202%202-1v2l3%201%204%201%201%204h3v2l2%201-5%204%204%202c-19%200-19%200-24-5l-2-2-2-2c-7-5-7-5-8-8l1-6q44-14%2089-14'/%3e%3cpath%20fill='%2390d19c'%20d='m0%20347%2012%205%2021%209q28%2011%2055%2025l3%201%203%201%202%202%204%204-5%202-10-4a366%20366%200%200%200-55-24l-19-7q-4%200-6-4l-3-1-2-2z'/%3e%3cpath%20fill='%232c473f'%20d='m280%20536%201%202%202-1q7-2%2016%201l15-2%206%201v10q0%206-4%209l-1%207v7q-2-3-2-7l-3-6-2-2-1-2h-8l-20-3q-6-1-7-3v-2h2v-2l3-3%202-1z'/%3e%3cpath%20fill='%2390d19c'%20d='M0%20154h1l1%203%205%2010%203%203%202%203c8%2010%208%2010%2010%2016q2%203%206%205l3%204%207%209c9%209%2018%2020%2018%2033v4l-6-1-2-5q-8-17-20-32l-2-3-10-12-1-2-3-5-2-4-3-1q-7-8-7-19z'/%3e%3cpath%20fill='%23326351'%20d='m198%20236%204%202-1%204q-2%204-2%2010h-3l-1%204h2l-1%203-2-1-1%202-1%202h-4l-1%203q-2%205-6%209l-9%2010q-7-2-11-7l1-5%203-1q10-9%2017-22l6-4%208-7zM48%200q7-1%2012%204l3%203%204%202%2023%2013-1%202-2%205%204%206q3%203%202%207v2l1%209q-3%201-5-2l-3-3-1-2-11-13-2-2c-3-5-3-5-3-8l-4-2-4-4L50%203z'/%3e%3cpath%20fill='%2322362f'%20d='M179%2066v17c-11%204-28%206-39%201l-2-9v-3l2-2h11l21-3z'/%3e%3cpath%20fill='%231e2b26'%20d='m5%20552%2018%2010q12%208%2024%2013v1H0v-24z'/%3e%3cpath%20fill='%237dcbba'%20d='M222%200h28c-20%2032-20%2032-29%2036V16z'/%3e%3cpath%20fill='%234f885c'%20d='M237%20165h2v3c0%2041%200%2041%202%2061l1-3q5-16%2016-29l6-2-3%206q-4%208-5%2017l-5%207q-7%209-12%2021h-1l-1-3-4-9q-4-9-3-19l4%208%201%203%201%202v-56z'/%3e%3cpath%20fill='%2337846e'%20d='M103%2025q4%202%204%206l1%202%204%2010%203%201%201%2010%205%2023%202%2014-12-7-1%202v-4l-1-4v-3l-1-4-1-5-2-13z'/%3e%3cpath%20fill='%2321312b'%20d='M199%20329q2%204-1%207l-3%2010-1%202-2%205q-8%2018-26%2026l-7%202c1-9%209-15%2014-22l20-23z'/%3e%3cpath%20fill='%237dcbba'%20d='M281%200h21q1%209-2%2017v16l-3%201-2-2-16-24z'/%3e%3cpath%20fill='%23a4e2d3'%20d='M319%20121h1l1%2064v6c0%2011%200%2020-8%2029h-2l1-30%201-7v-7l3-11-1-8v-4l1-3v-9l1-2%201-14z'/%3e%3cpath%20fill='%237dcbba'%20d='m0%206%2010%2013%201%203c21%2038%2021%2038%2022%2049q-7-5-11-12l-1-2-8-14-5-7C1%2026-2%2019%200%206m197-6h20v18l-1%202v11l-1%2011c-6-3-10-17-12-23l-2-3-1-3-1-3z'/%3e%3cpath%20fill='%232c5447'%20d='m24%2080%204%205%202%202q3%203%203%207l-5%203-2%202c-7%205-7%205-10%205l-1-2H0V91l3-1%205-2%202-1c5-2%209-7%2014-7'/%3e%3cpath%20fill='%2325483b'%20d='M237%20258q-1%205-5%208-12%2012-19%2027l-5-2v-2h-5l-3-4%205-6%208-8-2-2%205-6h2l1%202%202-1%202-2%203-2q5-4%2011-2'/%3e%3cpath%20fill='%236bb783'%20d='M230%20256v2l-5%204-4%202-2%202-1-3-2%202-4%204%202%202-2%202c-20%2019-34%2049-42%2075l-1%203-3%201q0-8%203-16l1-3%2011-24%202-3c4-9%204-9%207-12l2-3%207-12%201-1%2019-19q5-5%2011-3m64-187%201%202%205%207%202%203%203%203-1%2022-1%203-2%2015h-1v-7h-2c-4-6-4-6-4-9h-2q-3-8-1-16l2-14v-2z'/%3e%3cpath%20fill='%234f885c'%20d='M299%20277v8l-1%203-1%204-3%2012-18-2-3-1h-2v-3l-1-4q0-6%202-10h8l4%201%202%204%202-1%203%204%201-3%201-3z'/%3e%3cpath%20fill='%23326351'%20d='m0%20470%2028%201%201%202%204%201h2l3%201%207%201h2l1%202h-2l-8-1h-8l-4%201%202%202q-5%203-11%202-5%201-9%204l-8-1z'/%3e%3cpath%20fill='%237dcbba'%20d='m11%20382%202%201h10l4%201h14l-7%203-2%201-2%201-5%201h-2l-5%202%2028%201v1l-16%202h-5l12%207-2%201-7-4c-8-4-12-5-21-3l3-3-10-1v-9h5l3-1z'/%3e%3cpath%20fill='%2337846e'%20d='M138%20474h3q14%200%2027%204v2q-25%207-50%200v-4q10-3%2020-2'/%3e%3cpath%20fill='%234f885c'%20d='M299%2035q9%207%2011%2017l-2%2014-1%208q-4-1-6-5l-2-2-1-4h-2v5h-1zm-7%20161v8q-1%2012%203%2020l1%202-1%202-3-5-3-3v3l-2%2014-9-1c4-30%204-30%2014-40'/%3e%3cpath%20fill='%237dcbba'%20d='m94%2022%204%201h2l6%201-3%201v3l2%2023q-11-8-19-20%200-9%208-9'/%3e%3cpath%20fill='%234f885c'%20d='M302%200q6%201%2011%207%202%206%200%2014l-1%206v5h-3l-4-5-2-3-1-2-2%201q-2-6%201-12z'/%3e%3cpath%20fill='%236bb783'%20d='M43%20440v2l-7%204-17%2011C4%20467%204%20467%200%20467v-4l-1-3q1-4%207-6l13-6%203-1c16-7%2016-7%2021-7m41%2033v2l-3%201c-52%2013-52%2013-77%2021l-4%201v-4c64-21%2064-21%2084-21'/%3e%3cpath%20fill='%2390d19c'%20d='m238%20183%203%207v3l1%204v6l1%203%201%204v-12l3-2q3%203%202%208l6-5%202%201-1%202a68%2068%200%200%200-12%2021l-3%207h-1q-2-23-2-47'/%3e%3cpath%20fill='%23326351'%20d='M274%20259v3h2v-3q8-1%2013%204v3l-4%203-5%204-4%203q-3%200-7-3l2-1v-2h-2v-2l-4%201-1-3%204-3%202-2z'/%3e%3cpath%20fill='%234f885c'%20d='M78%20263h2l4%2010c9%2018%205%2043-2%2062q-6%2017-18%2031%200-4%204-9%2017-26%2017-59v-3q1-14-6-27z'/%3e%3cpath%20fill='%23a4e2d3'%20d='m220%20233-2%2012c-9%201-9%201-13-2l-5-6%203-4%203-1%202-1q7-1%2012%202'/%3e%3cpath%20fill='%2322362f'%20d='M34%20481v2h-3v2l-12%204-4%201-9%203-6%201v-9l8%201%201-3c7-4%2017-2%2025-2'/%3e%3cpath%20fill='%234f885c'%20d='m294%20128%205%203q0%2013-3%2025h-2l-3-4-6-6z'/%3e%3cpath%20fill='%2337846e'%20d='m137%20187%2016%2014%202%202q6%204%209%2010l2%203%201%204q-7-2-12-8l-2-2q-10-9-16-21z'/%3e%3cpath%20fill='%234f885c'%20d='M36%20154q5%204%206%2010-1%204-6%204l-3%201-7%202-3-4-2-2-1-4%206-2%204-2z'/%3e%3cpath%20fill='%23273a31'%20d='M313%20172h1c0%2020%200%2020-6%2027l-3%206-1%202h-2q0-19%2011-35'/%3e%3cpath%20fill='%2325483b'%20d='M302%20270h1v13l2%2022h-10v-9l1-3v-3l1-3z'/%3e%3cpath%20fill='%23326351'%20d='m0%20512%2010%208q8%207%2018%206l2%203-3-1h-5l-6-1%206%207-1%202-8-5-2-1-11-8zm12-71h7l-3%203-2%201-6%202h8l1%203-17%208v-16z'/%3e%3cpath%20fill='%23293f37'%20d='M48%200q10%200%2018%208%204%204%204%2010v2l1%206h-2v-3l-4-2-4-4L50%203z'/%3e%3cpath%20fill='%232c5447'%20d='m293%20318%207%201%204%202-1%202-2%202-2%202-3%205h2v2q-3%203-7%203h-2v-6l-4-1%201-3h2l3-1z'/%3e%3cpath%20fill='%236bb783'%20d='M98%20333h1q1%2011-3%2020l-1%204v10l8%205%203%202%203%202%202%202%203%201%202%202%201%201v2l-8-5-2-2-5-3q-7-5-13-6l-1-3-7-2v-2l10%202%201-4%203-15%201-3z'/%3e%3cpath%20fill='%23326351'%20d='M105%20399q6%200%2010%203v2l4%202%203%203-7%206v-3h-9l2-1-1-2-3-5-1-2z'/%3e%3cpath%20fill='%232c5447'%20d='M319%20260h1v31l-6-2c-1-20-1-20%205-29'/%3e%3cpath%20fill='%23273a31'%20d='m1%20563%2012%207%205%203%202%201%201%201v1H0v-12z'/%3e%3cpath%20fill='%234f885c'%20d='m291%2098%204%201%201%202%206%202%201%201-2%2020h-1v-7h-2c-4-6-4-6-4-9h-2l-1-4-1-3v-2z'/%3e%3cpath%20fill='%23326351'%20d='M40%20398h17l1%205-1%203q-6%202-13%201l-5-3%201-2%201-2zM0%20524l13%209%202%202%2014%2012q-4%200-7-3l-11-6c-8-3-8-3-11-6z'/%3e%3cpath%20fill='%234f885c'%20d='M272%20284h8l4%201-2%204-4%207-1%203-1%202h-5v-3l-1-4q0-6%202-10'/%3e%3cpath%20fill='%23326351'%20d='m232%20270%201%204-3%205-11%2016-4%206h-3q4-13%2013-23l2-2zm-36%2069%202%201q-7%2027-30%2042l-9%202-1-4h2q15-3%2024-16h2l1-2%206-14z'/%3e%3cpath%20fill='%234f885c'%20d='M319%20208h1c1%2015%201%2015-2%2019-5%204-5%204-8%204l-1-9h2v-2l1-1%205-7z'/%3e%3cpath%20fill='%23326351'%20d='M311%20194h1l-1%2025h-1l-1-5-3%204q-3-6-2-12z'/%3e%3cpath%20fill='%236bb783'%20d='M84%20268q6%202%208%207l1%202%201%205%201%202q5%2020%205%2042h-1v-3c-5-38-5-38-14-53z'/%3e%3cpath%20fill='%2337846e'%20d='M12%20385h18l-4%203q-13%204-26%203v-5z'/%3e%3cpath%20fill='%236bb783'%20d='m237%20260%202%202-2%204-2%202-1%202h-2l-2%204-3%203-12%2015-1-2q9-17%2023-30M97%20430l2%201q1%205-3%208l-1%203-2%202q-4%207-6%2015h-2q0-13%208-25z'/%3e%3cpath%20fill='%23326351'%20d='m0%20413%2018%201-3%206H0z'/%3e%3cpath%20fill='%232c5447'%20d='M185%2063v17l2%201-8%201-1-17z'/%3e%3cpath%20fill='%2390d19c'%20d='M320%20203q0%206-3%2011l-2%204-2%202h-2v-11l1-5q4-3%208-1'/%3e%3cpath%20fill='%234f885c'%20d='m294%2069%201%202%205%207%202%202%201%202-3%203-1%202-6%205z'/%3e%3cpath%20fill='%2390d19c'%20d='M263%20237q-1%205-6%208l-3%201-7%204-2-1q2-6%208-10%204-2%2010-2'/%3e%3cpath%20fill='%23233a33'%20d='M54%20472q10%200%2019%202l-6%203h-2l-3%201h-2l-12%201%205-2z'/%3e%3cpath%20fill='%23326351'%20d='M59%20176q4%202%207%206l-3%203h-3v5l-8-3%203-6%203%201v-2z'/%3e%3cpath%20fill='%232c5447'%20d='M282%20286q3%202%202%205v6l-1%205h-6q-2-5%201-8l1-3z'/%3e%3cpath%20fill='%23326351'%20d='M94%20345q1%206-1%2011l-1%202-1%205-10-2%202-1%208-11%201-2h2z'/%3e%3cpath%20fill='%237dcbba'%20d='M40%2055h2l7%2012%201%203%203%206%202%202%204%209-1%203-12-21-1-3-2-2-1-3z'/%3e%3cpath%20fill='%234f885c'%20d='m12%20163%206%207v3l-6%202-7-11q4-2%207-1'/%3e%3cpath%20fill='%2325483b'%20d='M319%20241h1c1%2016%201%2016-3%2022l-4%203q-2-4%201-9v-2z'/%3e%3cpath%20fill='%232c5447'%20d='M15%20448q0%203-4%205l-11%205v-7q7-3%2015-3'/%3e%3cpath%20fill='%2325483b'%20d='m313%20297%207%202v9h-6l-1-3z'/%3e%3c/svg%3e",
	crystal: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='507'%3e%3cpath%20fill='%23e7ddea'%20d='M0%200h320v507H0z'/%3e%3cpath%20fill='%23afabdb'%20d='M247%200h73v507H0V383l10%205-1%209v2l-2%2018v4l-3%2032h7v-5h2l1-4%207%202%204-3%203-1%203-2%202-2%208-5h9l4-1h12l-5-5q2-2%205-2h2l-2-5-1-3-1-4h4l3%205%207-4%204%203%201%207%202-1h8l-1%203h2v2l-9%205%204%201v-2h28l5-1%204-6%206-1h49l1-2%201-2%2020-1h4l11-1h26c-6-3-6-3-10-3h-2l-3%201h-5l-2%201c-10%201-10%201-14-1l-4-4v-2l4-2%201%202q9%203%2018%202h3l9-1h10l3-1%202-4%205-1h4-9l-2%204-5%201-13%202-5-1-5%201c-10%201-10%201-14-2l-4-12%2010%201-1-1v-12l3-1v-7l-1-3-1-8%201-6q3-8%202-15-1-6%204-10l2-2v-4h2l5-3q2-4%200-10l-2-15-1-5v-2q0-5-3-9l1-2v-19c-1-27-1-27%206-35l3%207-1-36v-19l-2-30v-12l-1-5v-3l1-5%208-5%203%2061%209-1-1-34a723%20723%200%200%201-3-88V47l-1-2-1-19z'/%3e%3cpath%20fill='%23d4c9e9'%20d='M117%200h130v12l2%2023v12l1%203v13l4%20111v2l-1%207h-9l-2-20v-13l-1-9v-2l-1-16-6%204v27l2%2030v19l1%2038-4-9c-6%206-5%2019-5%2026v28l1%202%203%2016v5l2%208v3c1%205%201%205-1%208q-3%203-8%203l-1%202%202%201-2%202q-5%205-4%2012%201%208-3%2016l1%207v14l-2%201v15l-3-2-7-1%201%202%201%202%201%203%201%205%207%201h2l11-1%202%201%206-1%2014-1%202-5h15v1l-15%201-1%202-1%203-6%201-10%201h-11c-14%200-14%200-18-4l-4%203-1-16h-4l-1-17h4v-3l-9%201-2-14v-5l5-1h3v-12l15-5-1-21q-1-20-10-37-6-15-3-32l-10%202%201%202%201%2011v8l-1%203h-9l-1-8h-2v3l2%2017v2l1%2033%2015-1v15h-13v5l1%2018%201%208v11l1%203v23l-16%206-2-26v-12l-1-12v-5l-1-6v-14h-2l-40%201v-15l41-1v-4l-3-38v-3l-1-7v-17h-20v-12l16-1v-13h-6l-36%202v-11l13-2h26v-20h-4l-23%202h-7l-30%201%201-15-2-1-1-5-2-3-9-1h-8v-6h5l3-1%206-1%201-7-2-1v-3q-1-6-5-9-5-11-6-23l1-1-21-1V93l17-1-1-5%201-4-17%201v-8l14-2%208-2%201-4%201-4-9-1v-4h8l17-3%201-10h2l1-3-8-3v-2h2v-2l-2-1%203-3-1-3%202-4h-7l10-7-13%205-5%201v-9l1-4h3c7%201%2014-5%2019-9q8-4%2018-2'/%3e%3cpath%20fill='%23ae4c68'%20d='M320%20296v211H0V383l10%205-1%209v2l-2%2018v4l-1%207-2%2025h7v-5h2l1-4%202%201%205%201%204-3%203-1%203-2%202-2%208-5h9l4-1h12l-5-5q2-2%205-2h2l-3-8-1-4h4l3%205%207-4%204%203%201%207%202-1h8l-1%203h2v2l-9%205%204%201v-2h28l5-1%204-6%206-1h49l1-2%201-2%2020-1h4l11-1h26c-6-3-6-3-10-3h-2l-3%201h-5l-2%201c-10%201-10%201-14-1l-4-4v-2l4-2%201%202q9%203%2018%202h3l9-1h10l3-1%202-4%2038%206%2011%202-2-3q0-7%205-13l3-7-21%202%202%202v7l-4%202-7-1v-5h2v-11h-2q-5-2-7-6l-1-5%201-2%201-3%201-2%208%204q7%203%2014%201l3-1%2015-1q3-20%200-41c-3-26-3-26-2-32q3-3%208-3'/%3e%3cpath%20fill='%23fdf4cd'%20d='M191%20250h8v2q-1%2022%2010%2043%204%2010%203%2021l1%2024-5%202-3%201-6%202-1%2012-7%201%201%2019%209-1v3h-4l1%203v14h4l1%2010v6l2%201%205%203%2017-1%204-1q8%200%2014%204v1h-23l-7%201h-15l-17%201-2%203h-9l-3%201h-34l-9%201-4%206-8%201h-2l-7-1H89v2l-5-1%203-3%203-1h2l2-1v-2h-2v-2h-9l-1-3q-1-5-3-5l-2-1-2%202h-3l-1%202-3-3v-3h-4l1%202%203%2010-6%202%202%202%204%204h-2c-17%200-27%200-40%2011l-7%204-5-4-1%204h-2v5l-8%201%201-19%201-3%202-11%204-2h2q10-2%2018%202%2011%203%2022%202v-3l-1-76%2016-1h22l-1-9-38%201v-22l29-1%2013-1h18l7-1h20v-28l13%202%202%201%202%201h2l6%202%202%2033-41%201v15h5l37-1%202%2017v9l1%2010%201%2039%203-1c9-5%209-5%2013-5v-2l-1-18-1-7-1-41h13v-15l-2%201h-13l-1-21-1-7v-10l-1-3v-14h2l1%208%209-1-1-23h2z'/%3e%3cpath%20fill='%23b9b5e2'%20d='m6%20112-1%2011h4l3-5%204-1-1%204v3l-2%206-1%203-1%203q0%206%203%2011l1%203%205%209%201%204%204%208%201%202%201%202h3l2-2%202%202%204%201v2h3v6l-3%201c-3%208-7%2019-4%2028q3%205%209%209%204%204%203%2012v6l1%207v10l3%2044%201-15%2027-2h12l13-1h4l31-1v28l-87%203v22l10-1%2015-1h10l4%201v9l-38%201%201%2079q-11%203-23-2-8-3-17-1h-3l-3%201-1%203%203-36-2-1c-6-3-6-3-8-6V172l1-40v-3q-1-9%203-16z'/%3e%3cpath%20fill='%23b197c7'%20d='M247%200h5l2%2038%202%2055%201%2023%205%20112%201%2016v21l3%2062h2l1-2%208-7%201%2013-5%205-1%203q5%201%208-2l3-3%201-2%208-8%2020-16a317%20317%200%200%201%204%2057v2l-2%205-12%203h-4q-10%202-19-3l-3-2-2-1q-3%206-1%2011l3%204v2h5v7l2%201-1%205h-2v3l4%201h4l1-4q0-4-2-7l22-1-6%2014q-2%204%201%2010l-46-8v-1l5-1h-9l-1%202-1%202-5%201-13%202-5-1-5%201c-10%201-10%201-14-2l-4-12%2010%201-1-1v-12l3-1v-7l-1-3-1-8%201-6q3-8%202-15-1-6%204-10l2-2v-4h2l5-3q2-4%200-10l-2-15-1-5v-2q0-5-3-9l1-2v-19c-1-27-1-27%206-35l3%207-1-36v-19l-2-30v-12l-1-5v-3l1-5%208-5%203%2061%209-1-1-34a723%20723%200%200%201-3-88V47l-1-2-1-26z'/%3e%3cpath%20fill='%23ae4c68'%20d='M243%20450h7q14-1%2028%202l-9%206h-2v2h6l7%201q17%200%2035-5l5-1v52H98l-1-9-17-1q4-6%2010-5h14l21-2q-18-8-37-6H75q-7%201-13-3v-2l8-3-62-13%202-6q2-2%205-2h3l6-2h5v2h3l13%201q32%205%2064%204c-8%206-8%206-12%206l8%2010%207%201h2l5%201%2028%203c17%201%2017%201%2022-2q3-4%203-10v-3l6-1%201-4%202%201%208-2%203-2%203-2%206-1%204-1h4l8-2h4l5-2z'/%3e%3cpath%20fill='%237599ca'%20d='M113%200h31v2l1%2011v5l3%2068%202%2051-8%201-3%201h-12l-9%201h-6l-3%201H91v-3l-1-3v-4l-1-3-3-1%202-9h-2l-10%201h-3l-3%201H51V93l17-1-1-5%201-4-17%201v-8l14-2%208-2%201-4%201-4-9-1v-4h10l15-3%201-10h2l1-3-8-3v-2h2v-2l-2-1%202-1%201-2-1-3%202-4h-7l10-7-13%205-5%201v-9l1-4h3c8%201%2014-5%2020-9q5-4%2013-2'/%3e%3cpath%20fill='%23392f50'%20d='m0%20383%2010%205-1%209v2l-2%2018v4l-3%2032h7v-5h2l1-4%202%201%205%201%204-3%203-1%208-5%202-2q5-3%2012-1l7%202q10%205%2021%203l37-1%2012-1q19-1%2037%205l18%203%208%201%203%201h3q-5%204-12%205l-11%207%2021-2q-4%205-10%206l-5-1-1%203-6%202%202%204-1%201-4%206q-2%205-5%205l-8-1h-3l-9-1h-6l-22-2-4-1h-4q-7-2-10-8l-1-4%205-3%203-1%202-1h-3l-60-3-2-1-13-2-1-2-4%201h-3l-5%202h-2q-4%202-6%206l3%201q32%205%2063%2013v1l-12%202v2q7%203%2015%202h13q20-2%2037%207-7%204-16%203H90l-9%203%2016%202%201%209H0z'/%3e%3cpath%20fill='%23ebc9bf'%20d='M68%2083v9l-10%201h-7v-9zM50%2093h1v27h23l-2%203q-1%2014%209%2025l2%206-1%202%202%201%201%206q-2%204-5%204H69v6h19v3l3%207%201%202v2l-1%201-1%205v5h2q31-3%2062-3v20l-39%202v11h5l37-2%201%206v7l-5%201h-12v12h20l1%2014v3l1%2019-15-4-17-2v-2q-2-4-5-5l-2-2q-6-2-12%201l-3%201-11%203-2%201-3%201-5-1%2016-6%203-1%202-1h2l5-1v-2l-14%204-2%201-14%205q-16%207-34%206%204-3%209-3l4-1%204-1q12-2%2026-8l2-1%205-2v-7l-17%204-19%205-2%201H52l-1-3v-17h7l5%201%203-1-4-3v-2l4-2-2-6%202-2-15-1v-4l24-2c0-10-1-13-7-20l-1-2-2-2q-3-8%200-18v-2q1-6%204-10l-1-1v-4q-2-8-8-14-4-3-9-2z'/%3e%3cpath%20fill='%23d8d9f6'%20d='M0%200h40l1%2012v5l1%2013v30l-1%209%202%201q2%205-1%209l-2%202-3%204%202%206h2v3l1%206%201%203%202%201v10h-2v49l-1%2017-1-2h-3v-2H27l-13-26-2-5q-3-9%201-18l2-9-3%201-3%207-1-3H5v-10H3l-2%208H0z'/%3e%3cpath%20fill='%23afabdb'%20d='m180%20152%202%209v2l1%208v5l1%2014%202%2022v5l3%2028v2l2%2028-3%201h-7l-1-8h-2v3l2%2017v2l1%2033%2015-1v15h-13v5l1%2018%201%208v11l1%203v23l-16%206-2-26-2-39v-10h-2l-40%201v-15l41-1v-4l-3-38v-3l-1-7v-17h-20v-12l16-1v-13h-6l-7%201h-4l-25%201v-11l13-2h26v-14l14-1h5v-3l-1-10-1-33zM247%200h5l2%2038%202%2055%201%2023%205%20109v2l4%2090v3l1%2017v3l-2%205q-3%203-7%202v-8l-4-2-3-3-6-6-1-2-2-2h-6l-3%201v-3l-2-12-5-24%201-2v-19c-1-27-1-27%206-35l3%207-1-36v-19l-2-30v-12l-1-5v-3l1-5%208-5%203%2061%209-1-1-34a723%20723%200%200%201-3-88V47l-1-2-1-26z'/%3e%3cpath%20fill='%23d4c9e9'%20d='M252%200h37l4%2044v8l2%2020%202%2028v2l2%2039h-2q-6-1-11%203l-4%204q-7%208-18%2012v2h-3l1%202v2l-3%203-2-18v-3l-3-70V66z'/%3e%3cpath%20fill='%2337457b'%20d='M289%200h31v125l1%20111v43q1%208-5%2014l-5%203-2-12v-13l-1-13-4-55-3-31-9-122-1-17v-4z'/%3e%3cpath%20fill='%23fdf4cd'%20d='m138%20282%2013%202%202%201%202%201h2l6%202%201%2011v3l1%2019-41%201v15h5l37-1v6h-3q-27%200-48%2017l-2%202-36%2026c-19%2014-19%2014-24%2014l-1-36v-21l16-1h22l-1-9-38%201v-22l29-1%2013-1h18l7-1h20z'/%3e%3cpath%20fill='%23c2c4e5'%20d='m88%20118-1%209%201%201q4%204%203%208v5h3l56-4v-8h1l2%2065a137%20137%200%200%201-33%203l-30%201%201-15-2-1-1-5-2-3-9-1h-8v-6h5l3-1%206-1%201-7-2-1v-3q-1-6-5-9-5-11-6-23l1-1-9-1v-1z'/%3e%3cpath%20fill='%23afabdb'%20d='m49%20314%201%206v3l1%203v9h2l23-2h10l4%201v9l-38%201v8l1%2071q-11%203-23-2-8-3-17-1h-3l-3%201-1%203%203-36-2-1-7-4-1-16%201-4v-11l3%201%201-3%201%202h2q5%202%209%206v2c13-4%2013-4%2017-8l1-3q-7-2-14%202l3-15%2023%206-1-3-2-18-1-6z'/%3e%3cpath%20fill='%23392f50'%20d='m0%20383%2010%205-1%209v2l-2%2018v4l-3%2032h8q0%205-4%209l3%201q32%205%2063%2013v1l-12%202v2q7%203%2015%202h13q20-2%2037%207-7%204-16%203H90l-9%203%2016%202%201%209H0z'/%3e%3cpath%20fill='%23637bb4'%20d='M29%20453v2l16%201q32%205%2064%204c-8%206-8%206-12%206l8%2010%207%201h2l5%201%2028%203h19q5-4%206-10l15%202%206%201%207%201%202%201%209%201%206%202%203%205%206%202%204%201%204%201%2020%205-1%202q-11%201-22-1l-3-1-25-4%202%201%201%202-1%203-13-1-2-1-54-5%203%201a89%2089%200%200%201%2031%2013v2l-21-2q-14-3-29-2-20%200-40-3%204-5%2010-5h24l11-2q-18-8-37-6H75q-7%201-13-3v-2l8-3-50-11h-2l-10-2%202-6q2-2%205-2h3l6-2z'/%3e%3cpath%20fill='%23d4c9e9'%20d='M144%200h17l1%2011v3l1%202v22l2%201v8l2%2040%203%2059v3l3%203%202%201-4%201%202%2046-19%201v-6l-4-1h3l-1-24-1-11-2-43-3-54-1-14V31z'/%3e%3cpath%20fill='%23d8d9f6'%20d='M191%20250h8v2q-1%2022%2010%2043%204%2010%203%2021l1%2024-5%202-3%201-6%202-1%2012-7%201%201%2019%209-1v3h-4l1%203v14h4l1%2010v6l2%201%205%203%2017-1%204-1q8%200%2014%204v1h-23l-7%201h-15l-17%201-2%203-4%201h-51l2-2%204-3%204%201c14%201%2022-2%2034-10l8-4%202-1%206-1v-2l-1-18-1-7-1-41h13v-15l-2%201h-13l-1-21-1-7v-10l-1-3v-14h2l1%208%209-1-1-23h2z'/%3e%3cpath%20fill='%23afabdb'%20d='m216%20207%201%203h4v-2h2l-1%2032v2l-1%2011a63%2063%200%200%200%203%2028l2%208h-2v18l1%206v16l-1%204%202%201-2%202q-5%205-4%2012%201%208-3%2016l1%207v14l-2%201v15l-3-2-7-1%201%202%201%202%201%203%201%205%207%201h2l11-1%202%201%206-1%2014-1%202-5h15v1l-15%201-1%202-1%203-6%201-10%201h-11c-14%200-14%200-18-4l-4%203-1-16h-4l-1-17h4v-3l-9%201-2-14v-5l5-1h3v-12l15-5-1-21q-1-20-10-37-5-15-3-30v-4q1-10%207-18%205-7%203-16v-3l4-1h3z'/%3e%3cpath%20fill='%23637bb4'%20d='M64%20413h4l3%205%207-4%204%203%201%207%202-1h8l-1%203h2v2l-9%205%204%201v-2h14l2-1h33l40-2c23-4%2048-1%2072%200l13%201%2024%201-5%209-9-2q-7-4-16-3l1%203-6-3-7-1h-13l-10-1h-6l-3-1c-23-1-23-1-31%203l-1%203%2023%203-1%205h3l16-2h10l7-1c41-2%2041-2%2059%204q7%203%2013%201l5-1%204-1v9l-13%204-3%201q-16%204-31%201l-4-1h-2v-2l10-5-30-2h-2q-21%200-40%204l-17%203-3%201-14%201%205-4%202-2q5-4%2012-4l3-2-8-2q-16-1-33-6l-9-1h-29l-36%201q-10%202-18-2l-5-2h-2l-9-2v-1l22-1-5-5q2-2%205-2h2l-1-2-2-6z'/%3e%3cpath%20fill='%23ebc9bf'%20d='M52%200h51L92%208l-2%202q-6%203-13%202l-1%2012%203-1%203-2%203-2%2011-2-7%205-2%201-2%201%206%201-1%202%201%206-2%203v2h-2l3%203%203%201h3l2%201-4%201v2h-2v11q-13%203-26%202v4h11c-3%209-3%209-6%2011l-8%201h-3l-9%201V15z'/%3e%3cpath%20fill='%23ae4c68'%20d='M239%20328h2l3%204%202%203q4%207%203%2015l-1%203v5h-2l-1%202v3l-1%203-3%206h-2l-1-6c-5%205-5%205-5%208v8l1%203v7l2-1%207%202%203%202%202%201%201-2%203-5q4-8%203-15v-12h1v22l5-3v3l2-2%203-1%202%201-4%205%202-2%205-5v2l1%202%202%201v2l4%202-4%201v2l6-4-1%207-7%204%201%202q-5%205-14%203l-5%201-2%204-5%201-13%202-5-1-5%201c-10%201-10%201-14-2l-4-12%2010%201-1-1v-12l3-1v-7l-1-3-1-8%201-6q2-6%202-13c0-8%200-8%203-11l5-4v3l-2%202-2%202%201%204c9-8%209-8%2012-13z'/%3e%3cpath%20fill='%2337457b'%20d='m254%20406%2031%205%206%201%204%201h4l5%203-1%202q-2%202-2%205%200%205-4%208l-6%201h-4l-4-1h-4l-46-1-33-1h-3l-16%201a204%20204%200%200%201-43%202h-15l3-7%206-1h49l1-2%201-2%2020-1h4l11-1h26c-6-3-6-3-10-3h-2l-8%201-2%201c-10%201-10%201-14-1l-4-4v-2l4-2%201%202q9%203%2018%202h3l9-1h10l3-1z'/%3e%3cpath%20fill='%237599ca'%20d='M138%20282v28l-50%203h-3c-17%200-17%200-25-6l-1%202-1-3%201-2h-3l-4-1-1-10v-7l27-2h12z'/%3e%3cpath%20fill='%23ae4c68'%20d='M320%20455v52c-22%200-22%200-28-5l-2-2-5-4-1%204-2-1-9-1q-4%203-6%208h-2l-1-34%203-1%202%2019%201-1-1-4v-5c-3-14-3-14-1-17l4-2h8q17%201%2035-5z'/%3e%3cpath%20fill='%23ebc9bf'%20d='M124%20334v3h2l40-1v6h-3q-27%200-48%2017l-2%202-36%2026c-19%2014-19%2014-24%2014l-1-35q5-4%2011-4v-2l36-1v-6H80l10-7%203-1c22-11%2022-11%2031-11'/%3e%3cpath%20fill='%2337457b'%20d='M247%200h5l2%2038%202%2055%201%2023%205%20109v2l4%2090v3l1%2020-2%205-5%202-5-108v-6l-1-45v-2l-1-12-1-27-1-37-2-53V47l-1-2-1-26z'/%3e%3cpath%20fill='%23bdacd5'%20d='M310%20308h2a317%20317%200%200%201%204%2057v2l-2%205-12%203h-4q-9%202-19-3l-2-2-2-1v-2l15-7q4-9%203-20h-16l9-9%206-7%2017-15z'/%3e%3cpath%20fill='%23624b7a'%20d='M112%2089v27l-20%202h-7l-10%201h-3l-21%201V93h21l2%203h9l1-2-3-1v-2l12-1h3l3-1z'/%3e%3cpath%20fill='%23c2c4e5'%20d='M304%201q10%200%2016%208v161h-1l-3-30-1-14-2-16v-2l-4-45v-2l-1-6-1-8-7%208-3-1q1-5%205-7%204-3%205-8l-1-10v-5z'/%3e%3cpath%20fill='%23f0e6e3'%20d='M183%20346q8%208%208%2018v2l1%203v8l9-1v3h-4l1%203v14h4l1%2010v6l2%201%205%203%2017-1%204-1q8%200%2014%204v1h-23l-7%201h-15l-17%201-2%203-4%201h-51l2-2%204-3%204%201c14%201%2022-2%2034-10l8-4%202-1%206-1v-2l-1-19-1-7v-10l-1-3z'/%3e%3cpath%20fill='%23faf4e2'%20d='M168%20374h1l1%2024-9%201-3%205-3%203q-5%201-11-2v4h-2l-11%201-11-2-4-1-1-26%2019-1h3l9-1h22z'/%3e%3cpath%20fill='%23bdacd5'%20d='m180%20152%202%209v2l1%208v5l1%2014%202%2022v5l3%2028v2l2%2028-3%201h-7l-1-8h-2l-7-108v-6z'/%3e%3cpath%20fill='%23fdf4cd'%20d='M61%20155q8%207%207%2019l3%201h-2l-3%2012v2l-1%206v2q-1%208%204%2012c7%209%207%209%207%2015v3l-1%203-24%201v-77c7-1%207-1%2010%201'/%3e%3cpath%20fill='%23637bb4'%20d='M113%200h31v20l-8%201-3%201h-8l-10%201-10%201-21%201%2010-7-13%205-5%201v-9l1-4h3c8%201%2014-5%2020-9q5-4%2013-2'/%3e%3cpath%20fill='%23ebc9bf'%20d='M68%2083v9l-10%201h-7v-9zM50%2093h1v27h23l-2%203q-1%2014%209%2025l2%206-1%202%202%201%201%206q-2%204-5%204H69v6l2%201h-3v-3q-2-10-8-15-4-3-9-2z'/%3e%3cpath%20fill='%2337457b'%20d='m245%20200%204%2053%201%2012%201%2014v11l2%2016v14l1%2014-1-1-2-2-2-1-5-4q-4-6-3-12v-13l-1-15-1-3v-22l-2-44v-15z'/%3e%3cpath%20fill='%23d8d9f6'%20d='M30%20231q4%202%204%207v17l4%2033%201%203%205%2040%201%206%201%205-5-1h-3l-5-2-4-21v-6l-1-8-6-60-1-3c0-7%200-7%203-10z'/%3e%3cpath%20fill='%23637bb4'%20d='M161%200h7l2%2014v8l1%209%201%2019%202%2025v3l5%2062-4%201h-5q-2-2-1-6v-2l-2-33v-4l-3-57-1-1-1-7V19z'/%3e%3cpath%20fill='%23e7ddea'%20d='M53%20410h1v14l5%201v-3l9%201v2l-6%202%202%202%204%204h-2c-17%200-27%200-40%2011l-7%204-5-4-1%204h-2v5l-8%201%201-19%201-3%202-11%204-2h2q9-3%2016%202%2012%203%2024%202z'/%3e%3cpath%20fill='%23fdf4cd'%20d='M102%20260q3%202%202%205v3q-24%2010-49%2015%2013%201%2025-4l3-1%2024-9h2l5-2%202%201v2l-13%204-3%201-3%201-6%203%202-1%209-2%206-2%204-1%203-1q7-1%2012%203l3%202%202%201-1%204-80%204v-16l7%201%205-1%203-1%204-1h3l21-7z'/%3e%3cpath%20fill='%23e7ddea'%20d='M144%200h17l1%2011v3l1%202v22l2%201v10l-1%206-4%203V38l-2%208c-5%2017-5%2017-11%2021q-3-33-3-67'/%3e%3cpath%20fill='%2337457b'%20d='M215%20432h4l25%201q7%200%2013%204v-2q17-1%2030%208v1h-2q-28-2-57%201h-3l-22%201%201-5h-2c-16-1-16-1-21-3l-1-3%204-1%202-1q15-4%2029-1'/%3e%3cpath%20fill='%23637bb4'%20d='M289%200h31v9l-2-1-3-2-3-2-8-3%202%2013v4c2%2022%202%2022-1%2027l-7%206v3l2%201%201-2%207-7v6l-1%201-1%205v4h-3q-6%202-9%206v-4l-1-3-2-28v-4zm-61%200h7l6%20105v3c0%207%200%207-2%2010q-3%203-7%203v-3l-2-57v-2z'/%3e%3cpath%20fill='%23bdacd5'%20d='M71%2062h22v2h-2l-1%206h4q3%207%202%2013v7l-11%201h-4v2l4%201q-2%204-4%203h-2l-3%201-3-3-1-2-2%201h-6l1-2h3l-1-2%201-7-17%201v-8l14-2%208-2%201-4%201-2v-2z'/%3e%3cpath%20fill='%23f0e6e3'%20d='m240%20324%203%204%208%208q5%203%205%208l-3%206h2l1%2020q2%2014-6%2024l-2%202-2-1c-9-3-9-3-13-2l-1-10v-3c0-8%200-8%202-12l2-2h2l1%206h2l4-15%203%201q3-16-7-28v-2l-11%2011-7%206-1-5%203-4%203-2%202-2%202-3c6-5%206-5%208-5'/%3e%3cpath%20fill='%23392f50'%20d='M243%20450h7q15%200%2028%202l-9%206h-2v2h8v1h-2q-3%201-5%204v5l1%203%202%2014q1%203-2%207-2-11-2-23-2%202-2%205v30h2v-2q2-5%206-7%205-1%209%201l2%202%201-4%2010%206%204%202%202%202v1h-38v-27l-1-10v-10l-2-1v-2l-3%201-1%205-7-2-2-1-9-4-13-1c-9%201-9%201-12-1q15-5%2030-4'/%3e%3cpath%20fill='%23afabdb'%20d='M315%20338q2%2014%201%2027v4l-4%204-10%202h-4q-9%202-19-3l-2-2-2-1v-2l9-4q7-2%209-8l4-1v-2h2v-2l4-4h2l1-4h3v-2z'/%3e%3cpath%20fill='%2337457b'%20d='m274%20369%208%204q7%203%2014%201l3-1%2015-1-4%2019-22%202%202%202v7l-4%202-7-1v-5h2v-11h-2q-5-2-7-6l-1-5%201-2%201-3z'/%3e%3cpath%20fill='%23d8d9f6'%20d='M319%20288h1v8l-3%201-4%202v4q0%205-3%207l-9%207-13%2013-9%209-5%201-2-1%201-4%202-1q3-6%202-13v-10l-4%201-1-5%202-2q4-2%204-7v-5l5-1%201%207%203-2%204-2%203%201%202-2%202-3h2l1%204-3%203-2%201-2%202-4%203-1%202q-6%203-5%207v10l11-12%2023-22z'/%3e%3cpath%20fill='%2337457b'%20d='M153%20184v10a137%20137%200%200%201-33%203l-30%201v-10q3-2%205-1l3-1h12l9-1z'/%3e%3cpath%20fill='%23ebc9bf'%20d='M178%20268h2l1%208%2011-1q4%2024%204%2047l-9%201h-6l-1-21-1-7v-10l-1-3z'/%3e%3cpath%20fill='%23392f50'%20d='M144%206v14l-8%201-7%201h-4l-20%202-21%201%2011-7%204-2%202-1%204-3q11-6%2024-5l4-1z'/%3e%3cpath%20fill='%2337457b'%20d='M150%20126v11l-8%201-3%201h-12l-9%201h-6l-3%201H91v-11l23-2h10l12-1h4l4-1zm91-4%203%2075-9%201-1-21v-7l-1-21v-14l-1-2%201-6q3-4%208-5'/%3e%3cpath%20fill='%237599ca'%20d='m165%20321%201%204v11l-42%201v-15z'/%3e%3cpath%20fill='%23fdf4cd'%20d='m138%20282%2013%202%202%201%202%201%208%202%201%2017-6%202-6%202q-12%205-23%203l-3-2h12z'/%3e%3cpath%20fill='%23bdacd5'%20d='m96%2018-11%206%206%201-1%202%201%206-2%203v2h-2l1%203-9-3v-6h2l-1-6-3-2%206-3%203-2c7-3%207-3%2010-1m2%2026h-4v2h-2v11q-10%203-21%202l1-5H52v-4l7-1%2013-1%206-2%202-3c4-4%2014-2%2018%201'/%3e%3cpath%20fill='%237599ca'%20d='m309%20391-6%2014q-2%204%201%2010l-46-8v-1l11-1v-3q4-6%2011-9l3%201-1%205h-2v3l4%201h4l1-4q0-4-2-7z'/%3e%3cpath%20fill='%23637bb4'%20d='M247%200h5v3l1%2025%201%2013v17l2%2031v22l-1%201-3%206v13h-1l-2-71V47l-1-2-1-26z'/%3e%3cpath%20fill='%23d4c9e9'%20d='M11%20172q4%205%206%2012v2c5%2017%205%2017%204%2020h-2v3q-4%203-9%202H5l-1-9v-21l2-8z'/%3e%3cpath%20fill='%2337457b'%20d='M307%2052h2l2%2041-3%201v-2l-12%201-2-14v-3c-1-8-1-8%202-12q3-2%207-2h3v-7z'/%3e%3cpath%20fill='%23637bb4'%20d='M157%20215v11l-13%201h-4l-25%201v-11l13-2z'/%3e%3cpath%20fill='%23624b7a'%20d='M255%20362h1v22l5-3v3l2-2%203-1%202%201-4%205%202-2%205-5v2l1%202%202%201v2l4%202-4%201v2l6-4-1%207-8%205-3%203h-13v-2l-4%204-4%203-7-1-1-3%203%201q3%201%205-2l9-12-1-2z'/%3e%3cpath%20fill='%23ae4c68'%20d='m3%20350%202%202h2q5%202%209%206v2l10-3v2l-4%202%202%202q3%202%202%205l-6%201q3%204%208%205v1q-10%200-19-3v8l-9-4v-24l3%201z'/%3e%3cpath%20fill='%23faf4e2'%20d='M183%20346q8%208%208%2018v2l1%203v8l9-1v3h-4v3l1%204v2l-1%208-3%201v3h-7c-3-3-2-12-3-16v-8l-1-12z'/%3e%3cpath%20fill='%23ae4c68'%20d='M51%2093h14l-1%202h-6q1%205%203%205l1%201%203%201%202%201c9%204%209%204%2012%207h-9l2%208q-10%203-21%202z'/%3e%3cpath%20fill='%23ebc9bf'%20d='M51%2054h21l1%204-7%201v4h11c-3%209-3%209-6%2011l-20%202z'/%3e%3cpath%20fill='%23e7ddea'%20d='M22%20336q1%208-2%2015l2-1%209-3%203%202q0%204-3%206-7%205-15%205l-5-5-4-2H1l-1-3v-8h3l3-5%203%201%201%206%202-3q4-5%2010-5'/%3e%3cpath%20fill='%2337457b'%20d='m0%20383%2010%205-2%2018v7l-1%2010-1%206q0%2010-3%2019l-3-1z'/%3e%3cpath%20fill='%23afabdb'%20d='m0%20163%203%201%201%2031v18l-1%2014v13l2%2033q0%207-4%2013H0z'/%3e%3cpath%20fill='%23637bb4'%20d='m238%2065%202%2024v14l1%204c0%208%200%208-2%2011q-3%203-7%203v-14l-1-5V77l-1-4q1-4%204-6zm73%2024h1l1%2016-5%201-3%205-2%202-1%202%209-1v5l-5%205-4%202-2%202-2-1-1-5v-6l-1-23%208-1h4v2l2-1z'/%3e%3cpath%20fill='%23afabdb'%20d='m0%20302%205%208%201%202%201%202%202%205%203%207%202%203%201%202q1%203%206%204v2l-3%201-9%207-1-7-4%203-1%202-3-1z'/%3e%3cpath%20fill='%23ae4c68'%20d='M64%20413h4l3%205%207-4%204%203%201%207%202-1h8l-1%203h2v2l-10%205-4%202-1-2h-3l-2%202-5-2-3-1-5-5q2-2%205-2h2l-1-2-2-6z'/%3e%3cpath%20fill='%23d8d9f6'%20d='m42%20182%202%201%201%2013v28l-4-3-2-1c-6-5-6-5-7-9q-1-15%206-28l3%202z'/%3e%3cpath%20fill='%23c2c4e5'%20d='M90%20334v9l-38%201v18h-1l1-27%2028-2h3z'/%3e%3cpath%20fill='%2337457b'%20d='m128%20201%201%207q-3%202-8%202h-13l-24%201v-7l8-2h15l5-1z'/%3e%3cpath%20fill='%23392f50'%20d='m82%2099%2018%202h12v14l-7-2-23-4z'/%3e%3cpath%20fill='%23d4c9e9'%20d='m240%20324%203%204%208%208q5%203%205%208l-3%206h2v36h-1v-22h-2l-2-2-4%201-1-6%203%201q3-16-7-28v-2l-11%2011-7%206-1-5%203-4%203-2%202-2%202-3c6-5%206-5%208-5'/%3e%3cpath%20fill='%23f0e6e3'%20d='M100%20353v6q-4%202-9%201h-2l-7%201H54l-1-7%2019-1h6l9-1h8z'/%3e%3cpath%20fill='%23392f50'%20d='M263%20473h2v33h2v-2q1-5%206-7%205-1%209%202l2%201%201-4%2010%206%204%202%202%202v1h-38z'/%3e%3cpath%20fill='%237599ca'%20d='M242%20153h1l1%2044-9%201v-19l2-16%205-1z'/%3e%3cpath%20fill='%23624b7a'%20d='m315%20260%204%201%202%2015v3q1%206-3%2012l-6%205h-1q-2-15-2-32h3l1-2v3l2-1z'/%3e%3cpath%20fill='%23637bb4'%20d='m132%20442%203%203v7l9%202h6v-3l4%201v3h2q4%201%207%206l-41-2v-3h2l1-6%204%202v-3z'/%3e%3cpath%20fill='%23624b7a'%20d='M86%2073v9l-12%201h-4l-6%201H51v-8l9-2h10z'/%3e%3cpath%20fill='%237599ca'%20d='m172%20471%2015%202%206%201%207%201%202%201%2015%203v3h-32l-5-1h-12z'/%3e%3cpath%20fill='%23d4c9e9'%20d='m229%20288%204%2029%201%203c1%205%201%205-1%208l-5%203-4-1v-41z'/%3e%3cpath%20fill='%23fdf4cd'%20d='m187%20302%202%201v2l6-1%201%2018q-7%202-15%201v-19z'/%3e%3cpath%20fill='%23624b7a'%20d='M111%209c-7%206-11%209-20%2010q-6%201-10%204l-5%201v-9l1-4h6l4-1z'/%3e%3cpath%20fill='%23ebc9bf'%20d='M196%20329h1l1%2028-8%201q-8-9-7-21h13z'/%3e%3cpath%20fill='%23fdf4cd'%20d='M51%20235h17l-1%203h-3l2%201%201%205-4%204%201-1%202%204q-7%204-14%201l-1-5z'/%3e%3cpath%20fill='%23afabdb'%20d='M313%20105h7v65h-1l-2-24-1-11-1-11-1-4v-6l-1-3z'/%3e%3cpath%20fill='%23fdf4cd'%20d='m161%20257%201%208v13c-13-3-13-3-18-6l4-4-2-1%202-2%201-2q5-6%2012-6'/%3e%3cpath%20fill='%2337457b'%20d='M152%20155v10l-23%201v-7l1-3z'/%3e%3cpath%20fill='%237599ca'%20d='m159%20239%201%206v6l-3%201h-16v-12h8l2-1z'/%3e%3cpath%20fill='%23392f50'%20d='M145%2025v6l-34%202v-6z'/%3e%3cpath%20fill='%23e7ddea'%20d='M71%20405q5%201%209%206v2h2l1-3%204-1q1%207-1%2012l3-2h6l-1%204-11%201-1-3q-1-5-3-5l-2-1-2%202h-3l-1%202-4-5q0-4%203-8z'/%3e%3cpath%20fill='%23bdacd5'%20d='m160%2036%201%208v13l3-2%201%205-5%204-2%202c-7%205-7%205-10%205v7h-1v-8q1-5%204-8%206-12%209-26'/%3e%3cpath%20fill='%23624b7a'%20d='m293%20340-1%2010h-9l-1-3-2-1%201-2%202%201v-3q-7%203-11%208l-13%2011-1-4%208-8%202-3q11-9%2025-6'/%3e%3cpath%20fill='%2337457b'%20d='m0%20383%2010%205-2%2021-8-3z'/%3e%3cpath%20fill='%23ae4c68'%20d='M196%20322v15h-14v-14zM52%200h36q-6%204-14%205l-3%201-14%202-5%202z'/%3e%3cpath%20fill='%23624b7a'%20d='m219%20396%203%203%203%202%206-2%201%202%205%205v3h-9v2q-8%201-16-4l4-1-2-2-1-2%201-2%207%204-1-2z'/%3e%3cpath%20fill='%237599ca'%20d='m238%2065%201%2015v3c1%205%201%205-2%209l-5%201-1-15-1-2%202-8z'/%3e%3cpath%20fill='%23ae4c68'%20d='M255%20362h1v22l5-3v3l2-2%203-1%202%201-4%205%202-2%205-5v2l1%202%202%201v2l4%202-4%201v2l6-4-1%207-6%203v-4h-2v-5l-10%205v-5h-3q-3-3-3-7z'/%3e%3cpath%20fill='%23ebc9bf'%20d='m164%20305%201%2010h-5l-6-1h-2q-14%200-26%206h-6q15-8%2032-12l4-1z'/%3e%3cpath%20fill='%2337457b'%20d='M151%20142v5l-9%202h-21v-5c5-5%2024-2%2030-2'/%3e%3cpath%20fill='%23624b7a'%20d='m47%20478%204%202%201%202q3%204%208%204l7%205v1c-20%201-20%201-27-5l-1-2h7z'/%3e%3cpath%20fill='%23bdacd5'%20d='M216%20368q3%205%202%2010v7l-2%201v15l-3-2-7-1%203%209-4-4-1-7%2010%201v-12l3-1zm38%2036h15v1l-15%201-1%202-1%203-6%201-10%201h-11q-9%200-16-2l-1-2%202-2v3l7%201h2l11-1%202%201%206-1%2014-1z'/%3e%3cpath%20fill='%23ae4c68'%20d='M193%20357h6l1%2019-8%201-2-12v-7z'/%3e%3cpath%20fill='%23afabdb'%20d='M177%20117h1l1%2023-9%201q-2-3-1-8l1-9%207-2z'/%3e%3cpath%20fill='%237599ca'%20d='M85%20229v5l-34%201v-4l11-1h4z'/%3e%3cpath%20fill='%23e7ddea'%20d='m240%20324%203%204%2011%2010%201%206-8-6-1-2c-5-6-5-6-5-8l-11%2011-7%206-1-5%203-4%203-2%202-2%202-3c6-5%206-5%208-5'/%3e%3cpath%20fill='%23624b7a'%20d='M180%20261h10l1%2014-3%201h-7z'/%3e%3cpath%20fill='%23faf4e2'%20d='M123%20311v2l-71%202v7h-1v-9l22-1h8z'/%3e%3cpath%20fill='%23bdacd5'%20d='M103%200%2092%208l-2%202-7%202-2-1V4l-3-1q12-4%2025-3'/%3e%3cpath%20fill='%23fdf4cd'%20d='M143%20275q11%201%2020%205v7l-22-7z'/%3e%3cpath%20fill='%2337457b'%20d='M236%2048q4%208%202%2017-2%203-6%205h-2l-1-11c0-5%200-5%202-8z'/%3e%3cpath%20fill='%23624b7a'%20d='M90%20166v7H69v-6z'/%3e%3cpath%20fill='%23ae4c68'%20d='M59%2075h3l4%201v4h2v2h5v1l-22%201v-8z'/%3e%3cpath%20fill='%23624b7a'%20d='m105%2057-1%204-38%202v-4l13-1h4l6-1z'/%3e%3cpath%20fill='%23637bb4'%20d='m285%20496%2014%208%202%202c-9%203-22-3-30-6v-2q5-2%209-1l4%203z'/%3e%3cpath%20fill='%23d4c9e9'%20d='M134%20420h7l3%201h6v2h31v1l-55%201%202-2z'/%3e%3cpath%20fill='%23afabdb'%20d='M245%20418v1h-50v-1h2l34-4q8%200%2014%204'/%3e%3cpath%20fill='%23c2c4e5'%20d='m51%20300%201%203h8l2%202-3%202h2l4%203q4%203%2010%202v1H51zm75-104-1%201-2%204-9%201h-3l-3%201H96l2-1v-4l10-1h3z'/%3e%3cpath%20fill='%237599ca'%20d='M150%20129h1v13l-24%201-1-2-7-1v-1l31-2z'/%3e%3cpath%20fill='%23637bb4'%20d='M312%20348h3l1%2010v7l-6-1-1-2-3-2-3-3%202-1q4-1%205-5z'/%3e%3cpath%20fill='%23b197c7'%20d='M310%20308h2q0%207-7%2012l-2%201-11%209-1-5%2015-13z'/%3e%3cpath%20fill='%23faf4e2'%20d='m138%20282%204%201-1%2029c-12%200-12%200-15-2h12z'/%3e%3cpath%20fill='%237599ca'%20d='M236%2029h1l1%2022-2-2-6%204-1-16%206-1z'/%3e%3cpath%20fill='%23d4c9e9'%20d='m6%20337%203%201v14l-8%201-1-3v-8h3z'/%3e%3cpath%20fill='%23637bb4'%20d='m293%20418%205%205v2l-27-3v-2l7-1h2z'/%3e%3cpath%20fill='%2337457b'%20d='M244%20183v14l-8%201v-14z'/%3e%3cpath%20fill='%23bdacd5'%20d='M3%20356q5%201%207%205%200%205-4%209H0v-12z'/%3e%3cpath%20fill='%23637bb4'%20d='M141%20240h17l-3%202-1%203-5%203-8%204z'/%3e%3cpath%20fill='%23bdacd5'%20d='m179%20140%201%205v4l-5%203-5-1v-10z'/%3e%3cpath%20fill='%23637bb4'%20d='m0%20394%209%204-1%2011-8-3z'/%3e%3cpath%20fill='%23624b7a'%20d='M284%20390q5%201%206%205v7l-4%202-7-1v-5h2z'/%3e%3cpath%20fill='%23b9b5e2'%20d='m298%20359-4%201v4h-4l-1%202-4%201v2q-3%203-7%202l-2-1-1-3%207-3%202-1%206-3%203-1z'/%3e%3cpath%20fill='%23ae4c68'%20d='M65%2049h8v4l-21%201v-4z'/%3e%3cpath%20fill='%23e7ddea'%20d='m245%20359%202%203%205-1%201%204-3%202-8%207-2%201-4-2-3-2%203-5h2l1%206h2l1-4z'/%3e%3cpath%20fill='%23637bb4'%20d='M244%20173v10l-8%201v14h-1v-10l-1-3%201-8q3-4%209-4'/%3e%3cpath%20fill='%23392f50'%20d='M320%20279v9l-8%208h-1v-10c2-2%206-7%209-7'/%3e%3cpath%20fill='%23bdacd5'%20d='m0%20163%203%201%201%2031v18H3v-4l-1-13v-13l-1-3-1-7z'/%3e%3cpath%20fill='%2337457b'%20d='m270%20499%202%201%208%202%203%201%2015%203v1c-18%201-18%201-26-3l-2-2z'/%3e%3cpath%20fill='%23ae4c68'%20d='m14%20444%206%204v6l-4%202-5-3v-5h2z'/%3e%3cpath%20fill='%23e7ddea'%20d='m78%2025%203%201-1%208v5l-7-2-1-8%206-2z'/%3e%3cpath%20fill='%23ae4c68'%20d='m149%20472%202%202%203-1%201%203%202-1-2%206-12-1%201-3%204-1-4-1q3-4%205-3'/%3e%3cpath%20fill='%23c2c4e5'%20d='M94%20327v2l-37%201v-2z'/%3e%3cpath%20fill='%23b9b5e2'%20d='M192%20260h1l2%2012v25h-1q-4-18-2-37'/%3e%3cpath%20fill='%23d4c9e9'%20d='M298%20291h2l1%204-4%204-2%202-5%201v-4l-1%202h-2v3l-3%201-1-7%201%202%203-2%204-2%203%201%202-2z'/%3e%3cpath%20fill='%23624b7a'%20d='M0%20370c7%200%207%200%2010%202l-1%208-9-4zm179-238v8l-9%201v-8z'/%3e%3cpath%20fill='%23637bb4'%20d='m207%20408%202%202%205%201%202%201h2l-4%201v2h12v1c-13%203-13%203-18%200l-4-4v-2z'/%3e%3cpath%20fill='%23ae4c68'%20d='M197%20379h4l1%2017h-4z'/%3e%3cpath%20fill='%23d4c9e9'%20d='M20%20368h8l4%201%201%202-1%203h-6l-2-1-2-1-2-1z'/%3e%3cpath%20fill='%23637bb4'%20d='M320%20195v6l-11%201v-6z'/%3e%3cpath%20fill='%237599ca'%20d='M255%2096h1v15l-1%201-3%206v13h-1v-25l3-2%201-4z'/%3e%3c/svg%3e",
	stars: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='507'%3e%3cpath%20fill='%2346c8f7'%20d='M0%200h320v507H0z'/%3e%3cpath%20fill='%23182a5b'%20d='M0%200h320v203l-5-1-2-4-1-3-1-2q-9-28-24-52l-2-3-3-5h-2l2%203q17%2024%2026%2051l1%202%203%2014h-28l-11%201h-9q-3-1-6%202l-1%206q0%204-3%206h-2l-8-25a217%20217%200%200%200-32-56l-1-1-1-4h-3l2%202a253%20253%200%200%201%2037%2068c5%2015%205%2015%205%2019h-3l-1-3q-2-12-8-24l-1-3q-11-27-28-49l-2-3c-4-6-4-6-8-7h-2l1%201c20%2027%2038%2057%2045%2090l-5-1-2-7q-12-39-38-73l-4-6q-1-4-6-3h-3l2%203a268%20268%200%200%201%2040%2075c3%207%203%207%203%2012h-12l-4-13a224%20224%200%200%200-37-70l-5-6h-2l2%202c16%2022%2034%2049%2040%2076l-1%203q-6-4-7-11v2l-7-5q-14-12-30-21l-2-2-2-1-2-1-4-1q-4-2-5-6l-1-2-1-2-3-5%205%2011q-9-2-13-11l-10-14-2-1-6-6%202%202%2012%2015%202%203q3%204%203%207l-17-6c-38-17-82-22-124-25z'/%3e%3cpath%20fill='%23becaee'%20d='m194%20133%203%203%201%202%202%203%201%202c16%2023%2032%2049%2038%2077l1%202%204%201q-13-45-41-82l-1-2-2-2-2-5h5q13%2014%2021%2030l1%202%2013%2024%201%203q8%2014%209%2030h3c-8-27-8-27-14-39l-2-4a303%20303%200%200%200-27-42l-1-4h3l4%205%204%206%204%206a227%20227%200%200%201%2030%2069q4-2%204-6v-2l3-6q6-2%2014-1h36l1-2v2h2q-10-38-33-70l3-1q22%2033%2034%2070l4%201v107h-44l-14-1h-24l-7-1v-5q4-5%2011-6h36q3%200%205-3%201-5-2-9-4-5-9-5h-34l-17-1H88c-12%200-12%200-16%204v9l10%201h11l10%201h42q4%200%207%203l1%205q-2%204-7%204h-22l-1-8h-2l-2%204-3%205h-10l-8%201h-2l-87-1-1-2q-1-4-5-6l-3-1V135l23%201h2l7%201h2q50%206%2096%2024l6%202%204%202q-5-10-13-18l-5-8q6%203%209%208l2%202c12%2015%2012%2015%2012%2019l7%202-1-2-2-2-1-3-1-2%201-2c6%208%206%208%207%2013l1%202%206%201%205%203%203%202%203%202%203%201%2029%2023-1-2v-6l1%202%201%204%201%203q1%204%205%207-10-39-36-71l-5-9%205%201%206%208%201%202%2014%2022%201%202q14%2025%2021%2053l12%201q-12-47-43-86l-2-4z'/%3e%3cpath%20fill='%23255b92'%20d='M243%20391q6%204%2010%2011l17%2019-5-22%204-2%207%2016%206%2016%202%206%207%2010%201-12%202-17%203%201v2c1%2025%201%2025%204%2037q4%2010%201%2020l-2%202-6-1v3l6%204v-5l4-2%201-5%205%203%201-4v-4l1-3v-2l1-2%201-5%205-1q3%2026%201%2053H8l7-9%202-2%203-3%203-3%207-7-4%203-9%207-2-1%202-2%205-12%203-4%203-7q3-9%2010-13l7-1q4-1%207-6%205-3%2011-3l5-4v-4l-5-1%201-6h-3l1-4%206-2%202-2%204-2%207%202%201-5h2l2%204%203%203h7l1%202%204%201-1-3-1-15q5%205%207%2012l2%209h2l1-13h1l2%2012%202-4%204-2%203%204-1%202c-7%2011-7%2011-8%2017l1-2%2015-17h1l-1%209%203-2h4l2-4%203-2v6l9%203v3l9%202v-2l4%201-1-4%205-1%201%203h2v-3h4v3l9-1%206-4%208%201v3h2v2l-5%201%201%203%203-4%205-1v-2h7v-2h7l2%201%202%204%207%201v-5q6%202%2011%206l4%202%202%202-2-2-1-5h2v2h2l-2-2-2-3-2-2-1-5%201-2-1-3h-2l-2-1-1-4-1-3v-6l-3-5%201-2q9%203%2014%2011l2%203q7%2011%2020%2015l-2-2-2-3-2-2q-2-3-2-7h-2q-6-4-10-12l-2-3c-4-6-4-6-4-9z'/%3e%3cpath%20fill='%23258ac2'%20d='M85%20278h155l11%201h15q7-1%2014%203%204%204%205%209-1%205-5%207h-24l-9%201-13%202q-3%203-2%207h30l15%201h28l15%201v124h-1l-1-3q-9-26-32-41l-6-6v-2l9%206q6%206%2013%209l-16-19-3-6q-4-4-9-4h-18q-5%200-8-4-2-4-1-9l1-2q3-4%201-10-3-6-10-8h-22l-14-1h-26l-59-1-1%203v5l-1%202q-2%2010-8%2018l-1-2%202-6q4-10%204-20h-9q-6%2028%204%2055l1%201q5-10%202-21%200-8%206-14l3-3%202-2%207-8%203-4%203%201q-1%209-9%2013-9%205-10%2015l-1%206%203-8%203%201q3%209-2%2017l-3%207q-4%2010-5%2022h-1v-2q-2-13-7-26c-12-37-12-37-7-50H86l2%204-1%204-1-3-3-4-8-1H0v-35q6%200%209%205v4l107-1q4-4%205-9l2-1q2%204%201%2010h19l3-1%205-1%201-5-3-3-6-1H97l-13-1h-6l-6-2q-2-4-1-9%206-5%2014-5'/%3e%3cpath%20fill='%23255b92'%20d='M99%20408q5%205%207%2012v2l2%207h2l1-13h1l2%2012%202-4%204-2%203%204-1%202c-7%2011-7%2011-8%2017l1-2%2015-17h1l-1%209-7%205c-9%205-11%2013-15%2022l-6%2012-5%2013-3%205h2l1-2q7-12%2019-19l14-11q-4%2012-14%2020l-17%209v2h-2q-2%202-2%206l2%204h-7v2l71-1h-23l-26-1%201-3%201-6h87v3h2l-1-3h12c10%200%2010%200%2013%202l2%205%201%203%201%202h-9v3H8l7-9%202-2%203-3%203-3%207-7-4%203-9%207-2-1%202-2%205-12%203-4%203-7q3-9%2010-13l7-1q4-1%207-6%205-3%2011-3l5-4v-4l-5-1%201-6h-3l1-4%206-2%202-2%204-2%207%202%201-5h2l2%204%203%203h7l1%202%204%201-1-3z'/%3e%3cpath%20fill='%23c4d1f0'%20d='m0%20135%2023%201h2l7%201h2a393%20393%200%200%201%2084%2019l-2%202-9%2013a249%20249%200%200%200-21%2049l-4%2011h-2v-3l-4%201v-2h-2l-1-2-1%204-1-3h-2l4-18%202-7q-5-5-13-6v-2l-9-1-1%204-10%2023h-3v-2h-4l-1-5-2%205q-5-7-5-16l4-13q-3%201-4%205l-1%202-2%208-1%202-3%203q-4-1-5-5l1-8%201-2%201-3%201-4%201-3h-2l-1%202v2l-1%203q-1%203-5%204l-1%202-2-3-2%203v-9l-2-1-3%2010H0z'/%3e%3cpath%20fill='%233a518f'%20d='M214%20131h2l5-1h8c12%200%2012%200%2015%203l4%205%202%202-5-8q3-2%208-1h12l55%201v71l-5-1-2-4-1-3-1-3q-9-27-24-51l-2-3-3-5h-2l2%203q17%2024%2026%2050l1%203%203%2014h-28l-11%201h-9l-6%202-1%206q0%204-3%206h-2l-1-2-7-23q-11-29-30-53l-2-3-1-1-1-4h-3l2%202q23%2030%2036%2065l1%203c5%2015%205%2015%205%2019h-3l-1-3-8-24-1-3q-14-32-35-58z'/%3e%3cpath%20fill='%234c55a2'%20d='M243%20391q6%204%2010%2011l17%2019-5-22%204-2%207%2016%206%2016%202%206%207%2010%201-12%202-17%203%201v2c1%2025%201%2025%204%2037q4%2010%201%2020l-2%202-6-1v3l6%204v-5l4-2%201-5%205%203%201-4v-4l1-3v-2l1-2%201-5%205-1%201%2010v43l-16%201q-11%201-20-5l-4-4-6-4%202-4h1l-1-11h-3l-15-4-2%203-5-1-3-1-6-4v-2l-3-1-5-5-6-5%201-2%205%201v2h4l1-3h8l2%207%201%203h2l3-4%204%202v2l3-2-14-13-3-1-14-9-3-3%201-5q6%202%2011%206l4%202%202%202-2-2-1-5h2v2h2l-2-2-2-3-2-2-1-5%201-2-1-3-4-1-1-4-1-3v-6l-3-5%201-2q9%203%2014%2011l2%203q7%2011%2020%2015l-2-2-2-3-2-2q-2-3-2-7h-2q-6-4-10-12l-2-3c-4-6-4-6-4-9z'/%3e%3cpath%20fill='%237ecffa'%20d='M0%20242h42l4%201-2%205h-2l1%203h6l1%205-4%201%202%202-8%204v3l-3%202-4%204%203%202%205%204%204%201%207%202q8%202%2011%209h9v2l10%201h11l10%201h42q4%200%207%203l1%205q-2%204-7%204h-22l-1-8h-2l-2%204-3%205-18%201H48l-40-3q-1-4-5-6l-3-1z'/%3e%3cpath%20fill='%23d6d7e2'%20d='M122%20139q6%203%209%208l2%202c12%2015%2012%2015%2012%2019l7%202-1-2-2-2-1-3-1-2%201-2c6%208%206%208%207%2013l1%202h3l8%205%203%202%202%201-5%2010-9%2018-2%203-8%2019h-10l-4-5-1%203-1%204v2l-3%206h-27l1-9-4-1-2%202v-3l-1-6-1%207h-5q0-7%202-13l1-4%202-4%201-3%2010-24%201-2q6-13%2014-24l19%207q-5-10-13-18z'/%3e%3cpath%20fill='%23255b92'%20d='M320%20314v120h-1l-1-3q-9-26-32-41l-6-6v-2l9%206q6%206%2013%209l-16-19-4-6-4-4-1-6h-17q-3%200-5-3%200-5%203-8l2-5q-2-7-8-13l-1-3%208%202%203%205%205%201q0-7-6-12l-5%202v-3l-2-1%205-1h5l1%201h10l7%201h17v-2h-25q9-5%2019-4h9v-4z'/%3e%3cpath%20fill='%23b9567a'%20d='M62%20386h1v10h2l-2%206%201-1%204-1-5%2010%201%201h2l-2%206%205%201-2%205-3%201q-3%200-5%204l-1%203%205-1q-1%206-3%207l-6%201%204%201%206-3h3l-1%205-11%204-5%203-8%205q-7%201-12%206l-3%207-5%2012-3%206q-5%2013-17%2021l-2-16v-84h2v-2h3l-1-1-2-4h4l-1-3%205%201v5l4%201-1%203-4-1v4l4-2v5h4v2l-1%205-1%203%202-1%202-7h2c4%205%204%205%204%208h3l-2-2-2-3-2-3-2-6%201-2%202%201%206-1-1%208h2l1-5q3%205%202%2010h3q-2%206-4%206l-1%205v4h3v-7l-1-2%205-1-1-2%201-6-2-6q-4-6-3-13l3-5%201-2%204%203v14h2v-9h3l1%208h3l-1-4%201-7%205%202v10-3c2-12%202-12%207-17'/%3e%3cpath%20fill='%23d6d7e2'%20d='M118%20157h2l1%202-4%207q-21%2033-29%2072l-1%204-9%201H36l-12-1H0v-38q0-10%204-18l3%201-1%207%201-2%204%202q4-2%205-7l1-2%201-2h2l1-3v5l-1%204c-4%2011-4%2011-3%2015l4%203%201-2%202-7%201-2%201-3%201-2%205-4-3%2011q-2%209%202%2016l4-4v7h4l2%202%202-5%202-3%203-8v-2l4-9q5-1%2010%201v2l3-1q6%203%2011%208l-1%205-1%203-1%203-4%2013h2l1%201%201-3%202%201-1%202%206%201v3h2l1-2%201-5%2010-28%202-5c15-34%2015-34%2022-34'/%3e%3cpath%20fill='%233a518f'%20d='M191%20132v1h-5l2%203a268%20268%200%200%201%2040%2075c3%207%203%207%203%2012h-12l-4-13q-12-37-35-68l-2-2q-2-5-7-7h7l3-1zm-23%202q3%200%205%202l2%203%201%202%204%205%203%204c12%2019%2025%2040%2030%2062l-1%203q-6-4-7-11v2l-7-5q-14-12-30-21l-2-2-2-1-2-1-4-1q-4-2-5-6l-1-2-1-2-3-5%205%2011q-9-2-13-11l-16-20%208-3h3l3-1h4z'/%3e%3cpath%20fill='%23becaee'%20d='m79%20145%2024%206%203%201%2012%205-2%201-5%205-1%202-1%203a197%20197%200%200%200-19%2042l-4%2010-4%2011h-2v-3l-4%201v-2h-2l-1-2-1%204-1-3h-2l4-18%202-7q-5-5-13-6v-2l-9-2q2-9%206-17l2-3%209-18%203-4q2-4%206-4'/%3e%3cpath%20fill='%23559fdf'%20d='M85%20278h25l111%201c1%207%201%207-1%2010l-11%202q-6%200-10%205l-7%201v2l-8%202q-6%200-11%203l-9%201-2%201%201-4-3%201-5-1h-2l-1-3q-2-4-5-4H97l-13-1h-6l-6-2q-2-4-1-9%205-5%2014-5'/%3e%3cpath%20fill='%233a518f'%20d='M266%20131h7l47%201v71l-5-1-2-4-1-3-1-3q-9-27-24-51l-2-3-3-5h-2l2%203q17%2024%2026%2050l1%203q3%207%203%2014h-15l-3-7q-12-34-33-63%202-3%205-2'/%3e%3cpath%20fill='%23258ac2'%20d='M141%20427h1v6h3l6%203v3l9%202v-2l4%201-1-4%205-1%201%203h2v-3h4v3l9-1%206-4%208%201v3h2v2l-5%201%201%203%203-4%205-1v-2h7v-2h7l2%201%202%204%207%202q5%201%209%205l4%202%202%202%202%201c15%2011%2015%2011%2017%2016l-4%201-2-3q-3%201-5%204l-4-3-1-7h-8l-1%202h-4l-1-2h-51l-5%201-2-1h-10l-8%201-8-1-3-1h-2v-1h7l-2-5-2%201v-2l-3-1%201-3h-4l-1-3%201-2h-2v2l-4%202q-5%203-8%208v6h-4v-3l-3-2-2-5-3-2q2-8%2010-11l5-4v2l3-2h4l2-4z'/%3e%3cpath%20fill='%23164476'%20d='M82%20452q10%205%2013%2015l2%209-10-12-2-2q-3-3-3-8zm48-26h1l-1%209-7%205c-9%205-11%2013-15%2022l-6%2012-5%2013-3%205h2l1-2q7-12%2019-19l14-11q-4%2012-14%2020l-17%209v2h-2q-2%202-2%206l2%204h-7v2l71-1h-23l-26-1%201-3%201-6h87v3h2l-1-3h12c10%200%2010%200%2013%202l2%205%201%203%201%202h-9v3H83l7-15%205-10%204-9q6-10%203-21-3-8-9-13v-2h6q3%202%205%206l1%206%201%204v2c3-10%203-10%203-16h3v-3l3%201-1%208%201-2zm-61%2013h1q1%2014-4%2028-3%209-3%2019v4l2%2017H8l7-9%202-2%203-3%203-3%207-7-4%203-9%207-2-1%202-2%205-12%203-4%203-7q3-9%2010-13l7-1q4-1%207-6l8-3q5%200%209-5'/%3e%3cpath%20fill='%237ecffa'%20d='M320%20260v50h-50l-16-1h-16l-7-1v-5q4-5%2011-6h36q3%200%205-3v-9l5-2%205-3v-9l2-7q5-4%209-3h3l3-1z'/%3e%3cpath%20fill='%234c55a2'%20d='M227%20459c13%209%2013%209%2017%2015q5%204%2012%204l2-3%202%201h3l2%201%208%202q3%201%205%204l-1%208%203%201h-4v3l5%204%209%208h-68v-3l8-1-3-8h3q0-6-4-6l-7-2h-5q3-2%207-2l-8-2q-6-1-11-5l2-3h6l1-3%209%202v-2l-2-1h-3l-3-1-3-3v-2l4-1q8%201%2015%206l5%202-1-2-2-3-2-3z'/%3e%3cpath%20fill='%23c4d1f0'%20d='m58%20141%206%201h3c8%202%208%202%2010%204l-1%202q-20%2028-29%2060l-1%202-2%205q0%203-4%205l-1-3h-4l-1-5-2%205q-5-7-5-16l4-13q-3%201-4%205l-1%202-2%208-1%202-3%203q-4-1-5-5l1-8%201-2%205-13%202%201%205%202q4-3%205-8l13-25%202-4q2-6%209-5'/%3e%3cpath%20fill='%23559fdf'%20d='M292%20395q16%2011%2024%2028l2%203q2%206%202%2014v19h-1v-5l-5%201-3%2021-6-4v2l-4%206-1%204-7-4%201-4%206%201q5-10%200-21l-1-3-3-27v-9l-2-1-1%2021-1%2010-4-5-2-3q-4-6-6-13l-4-9-4-13%204-3h8l1-2%204-3h2z'/%3e%3cpath%20fill='%23b9567a'%20d='m319%20454%201%2010v43l-16%201q-11%201-20-5l-4-4-6-4%202-4h1l-1-11h2l-1-4%202-1v3l5-1-1-9-4%201v2l-4%201v-6h-2l1-2h2v2h4v-2l-3-2%202-4%202%202%208%201%202%202q4%200%208-3h3q3%208%200%2016l-2%202-6-1v3l6%204v-5l4-2%201-5%205%203%201-4v-4l1-3v-2l1-2%201-5z'/%3e%3cpath%20fill='%234c55a2'%20d='M293%20347q4%200%207%204v2h2l1%204%204-1q4%204%204%209l1%202%201%203%201%206%201%202%203%207q4%207%202%2015v34h-1l-1-3q-9-26-32-41l-6-6v-2l9%206q6%206%2013%209l-16-19-4-6-4-4-1-6h-2l-1-3q4-2%2010-2l3%201h2v-5l4-1-1-2v-2z'/%3e%3cpath%20fill='%233a518f'%20d='m241%20131%209%209-5-8%205-1h13l-1%202%202%204%202%202%201%202c30%2044%2030%2044%2030%2062h-20l-2-6q-11-34-33-62z'/%3e%3cpath%20fill='%232eb7ed'%20d='M285%20132h35v71l-4-7v-2l-1-3q-12-28-28-54z'/%3e%3cpath%20fill='%233a518f'%20d='M191%20132v1h-5l2%203a268%20268%200%200%201%2040%2075c3%207%203%207%203%2012h-12l-4-13q-12-37-35-68l-3-4-5-5h6l4-1z'/%3e%3cpath%20fill='%23258ac2'%20d='M189%20433h5l4%201v3h2v2l-5%201%201%203%203-4%205-1v-2h7v-2h7l2%201%202%204%207%202q5%201%209%205l4%202%202%202%202%201c15%2011%2015%2011%2017%2016l-4%201-2-3q-3%201-5%204l-4-3-1-7h-8l-1%202h-4l-1-2h-25l-3-1h-7l1-2h25v-2l3-1h-6q-5%202-10-1l3-3h-12l-3-1v5l-4-1-1-8h-4l-1%204h-4v-3l-5-2v-3l-3-2h2l3-1h3z'/%3e%3cpath%20fill='%23559fdf'%20d='M158%20174q9%202%2014%208l-5%2010-9%2018-2%203-8%2019h-8l-4-1q-3-6-1-11%208-24%2023-46'/%3e%3cpath%20fill='%23d6d7e2'%20d='M60%20385h5l-1%2010h2v4l4%201-4%208h-2l4-8-4%201v2l-2-1%203-6-3%201v-10l-4%204zm-24%202%205%201q3%203%202%207l4%201%201-2%202-2%205%201%201-3%202%201-3%2017-1-8v-4l-4-2%201%2012-3-1-1%205q-3-5-1-11l-2-2-1%209h-2l-1-11-1-5-2-1-2%206-1%202%201%209%202%203q4%207%201%2014l-5%201%203%206-4%204-2-1c0-8%200-8%203-11l2-2%201-2h-3l-2-9-1%204h-2l1-8%201%202h3l-1-2v-3l-1-2q0-4%202-7h2v-2zm-32%206%207%201v6l4%201v5l6-3%208%201-4%203-4-2q0%204%202%207l2%203%203%206h-3c-4-5-4-5-4-8h-2v3l-1%204-3%201%201-2v-6l1-2h-4l-1-4-3%201v-4l4%201v-3l-3-1v-5l-4-1v3H2v2l3%201v2H2v2H0v-8l4-1zm59%2015%201%202h4l-2%207h4l-1%207-7%201-1%204h3v5l5%202q0%206-4%208l-6%201c-6%202-6%202-8%205l-2%202-8%203q-6%201-10%206l-4%2010-5%209-5%2012%202-1%202-2%202-2%206-5%202%201-2%202-7%207-4%203-4%205-3%203-3%204H0v-9l3%206q7-5%2011-12l1-2%206-14%204-7%202-5q2-7%209-11l8-2q5-1%207-6l12-3%203-1%201-5-2%201c-6%203-6%203-10%203l-2-1%201-2%203-1q5-1%205-4l1-2-5%201%202-6%207-3%202-4h-6l3-7-4%202z'/%3e%3cpath%20fill='%23559fdf'%20d='M122%20139q6%203%209%208l2%202c12%2015%2012%2015%2012%2019l7%202-1-2-2-2-1-3-1-2%201-2%203%204%201%203%204%207-2%202-7%2010-2%202q-8%2015-13%2031l-3%203-2-1-1%203-2-2-6%201%202-4h-3v-6h2v-3l4-11%201-3%2014-25%202-6-5-8-2-3-10-10z'/%3e%3cpath%20fill='%2388aede'%20d='m0%20135%2023%201h2l5%201-3%201-2%205-3%206q-12%2022-21%2047H0z'/%3e%3cpath%20fill='%23559fdf'%20d='m101%20151%2017%205-2%202-8%2011-1%202-10%2021-5%2010h-5l-2-1v-5l-4%203-2-2q1-8%205-17l1-2q7-15%2016-27'/%3e%3cpath%20fill='%231f2857'%20d='M130%20426h1l-1%209-7%205c-9%205-11%2013-15%2022l-6%2012-5%2013-3%205h2l1-2q7-12%2019-19l14-11q-4%2012-14%2020l-17%209v2h-2q-2%202-2%206l2%204h-3q-4%200-6%204l-1%202-4-1%201-3%2015-30q6-10%203-21-3-8-9-13v-2h6q3%202%205%206l1%206%201%204v2c3-10%203-10%203-16h3v-3l3%201-1%208%201-2zm-48%2026q10%205%2013%2015l2%209-10-12-2-2q-3-3-3-8z'/%3e%3cpath%20fill='%232eb7ed'%20d='m194%20133%203%203%201%202%202%203%201%202q19%2026%2031%2055l2%204%206%2021h-9l-1-4q-13-45-42-82l-2-4z'/%3e%3cpath%20fill='%23559fdf'%20d='m121%20158%2015%205-1%201a140%20140%200%200%200-20%2037l-1%203-4%204v-4h-2l-1%203-6-3-2%203q-2-6%202-13l1-2q7-18%2019-34'/%3e%3cpath%20fill='%23255b92'%20d='m0%20304%203%201v8l49%201v3h-2l1%202-1%204-2%202h-2l-1%203H0z'/%3e%3cpath%20fill='%23559fdf'%20d='m177%20185%2012%208q-1%207-6%2012l-10%2022-3%205h-15q2-9%206-16l1-3z'/%3e%3cpath%20fill='%23255b92'%20d='M169%20436v2h2v-3h4v3l6%202v3l5%201-1%204%204-1%201-3h4l1%207h3l1-3%204%201q4%201%208-2l3%202-1%203h13l2%201q-4%204-9%204h-38l-1-3-5%201-1%202q-8%201-17-1l3-7%207-1%201-3h-3l-1-2-4-1v-3l4%201-1-4z'/%3e%3cpath%20fill='%23258ac2'%20d='M115%20485v2h-2v2l40%201h55l12%201%201-4q5%201%209%204v4l-8-2h-19v2h-2v-3h-87l1%204-2%204%2031%201%2026%201v1H90v-2l6-1-2-2q0-3%203-7h2v-2q7-7%2016-4'/%3e%3cpath%20fill='%23559fdf'%20d='M304%20228h16v22l-1-2h-14q-8%201-15-3l-3-5%202-8q6-5%2015-4'/%3e%3cpath%20fill='%231f2857'%20d='M70%20439q1%2014-4%2028-6%2019-1%2040h-6l-4-4-1-3q-8-9-7-22l3-7h2l1-2%203-6q3-8%200-17l4%201q5%208%203%2018-1%206-6%208l-2%204q0%206%203%2010l1-3%201-4%203-12q3-11%202-22%200-6%205-7'/%3e%3cpath%20fill='%23255b92'%20d='M320%20260v25h-10q-6%200-13-3-5-5-4-12%200-5%205-8l6-1h3l3-1z'/%3e%3cpath%20fill='%23559fdf'%20d='m67%20143%2010%202-2%204q-16%2023-25%2050-1%205-7%206l-2%202-1-4%203-3h-2q3-19%2014-37l2-3q3-8%209-14z'/%3e%3cpath%20fill='%23255b92'%20d='m124%20141%202%203%203%203c9%2011%209%2011%2012%2017l-1%202-13-5q-23-10-48-15v-1h2l5-1%2022-3%202-1%205-1q5%200%209%202'/%3e%3cpath%20fill='%23559fdf'%20d='m193%20197%209%206%202%202%201%201-1-2v-6l2%204%201%207h-2l-1%202-1%203-1%202c-5%2012-5%2012-9%2016q-8%202-16%200l4-12%201-3z'/%3e%3cpath%20fill='%232eb7ed'%20d='M198%20132h5q13%2014%2021%2030l1%202%2013%2024%201%203q7%2015%2010%2031l-5%201-1-2q-13-44-40-80l-1-2-2-2z'/%3e%3cpath%20fill='%23255b92'%20d='m229%20458%205%201v2h4l1-3h8l2%207%201%203h2l3-4%204%202v2l3-2v-2q8%202%2012%208l4%208q-10%200-20-4l-2%203-5-1-3-1-6-4v-2l-3-1-5-5-6-5z'/%3e%3cpath%20fill='%23559fdf'%20d='m56%20142%207%201h2l-9%2014q-11%2020-18%2042l-4-2%201-2-3-1%202-2v-6q0-6%203-10l1-4%202-3%202-4c8-17%208-17%2014-23'/%3e%3cpath%20fill='%237ecffa'%20d='m78%20195%204%203%203-3%201%206%206%201-10%2029h-2v-3l-4%201v-2h-2l-1-2-1%204-1-3h-2q1-13%207-25z'/%3e%3cpath%20fill='%23258ac2'%20d='m241%20131%209%209-5-8h3q10%2011%2016%2025l1%202c19%2033%2019%2033%2019%2044h-7l-1-2q-11-37-34-66z'/%3e%3cpath%20fill='%23255b92'%20d='M193%20132h5l6%208%202%202q27%2037%2038%2081l-5-1-2-7q-12-38-37-71z'/%3e%3cpath%20fill='%23258ac2'%20d='M68%20317q8%201%2013%207c7%2011%207%2011%207%2015l-1%202-1-3-3-4-8-1H0v-4l78-1-9-8z'/%3e%3cpath%20fill='%233a518f'%20d='M247%20131h7l3%205%203%206a292%20292%200%200%201%2030%2061h-6l-7-16q-11-29-30-56'/%3e%3cpath%20fill='%2388aede'%20d='m171%20134%205%201%206%208%201%202%2014%2022%201%202q14%2026%2021%2054h-6l-3%201-7%202%207-13%202%201q-10-39-36-71zm-140%204h7l3%201h3l-2%201-5%205-1%203-2%203-1%202-13%2025-2-1-6%202q0-10%206-19l1-3q5-11%2012-19'/%3e%3cpath%20fill='%23559fdf'%20d='m49%20139%203%201-2%207-2%203-2%203-14%2028-4%203-5-4q5-15%2013-28l1-2c6-11%206-11%2012-11'/%3e%3cpath%20fill='%23258ac2'%20d='m132%20337%203%201q-1%209-9%2013-9%205-10%2015l-1%206%203-8%203%201q3%209-2%2017l-1%204-2%203q-4%2010-5%2022h-1q-3-17%202-32%201-5-1-11%200-8%206-14l3-3%202-2%207-8z'/%3e%3cpath%20fill='%237ecffa'%20d='m101%20203%201%202%205%201%201-2h2q2%203%201%208l-1%203-1%203-1%203-1%203-3%208h-5l-2%202v-3l-1-6-1%207h-5q0-8%204-17l1-3%202-7%202%201z'/%3e%3cpath%20fill='%23255b92'%20d='M65%20444c6%2011-2%2031-6%2042l-1%203q-4-5-4-11%200-5%205-7%205-7%203-14l-3-10-3-1%201%202q3%208-1%2017l-5%205-6-5v-2l6-3-3-2-1%203c-1-8-1-8%202-12q7-5%2016-5'/%3e%3cpath%20fill='%23becaee'%20d='m137%20164%203%201%201%202-2%204-1%202-2%202q-11%2018-17%2037l-2-3-2%201-4%201%2011-27c10-20%2010-20%2015-20'/%3e%3cpath%20fill='%237ecffa'%20d='M0%20135c14%200%2014%200%2018%202l-6%2013-11%2022H0z'/%3e%3cpath%20fill='%23c4d1f0'%20d='M118%20157h2l1%202-4%207q-11%2017-17%2036c-2%206-2%206-6%208h-5c3-10%2017-52%2029-53'/%3e%3cpath%20fill='%23255b92'%20d='M299%20132h21v34l-5-7-1-3-2-2z'/%3e%3cpath%20fill='%233a518f'%20d='m278%20327%203%201%201%206%202%201%203-1%202%201%202%2013-5-3-5-1-1-2v5h-2l-1%203%203%205v2q-4%203-10%202-5-3-7-9v-2l2%201v2l4%201-1-3-1-4%204-1-1-6%204%201%202-6h2l-1-2v-3z'/%3e%3cpath%20fill='%237ecffa'%20d='M292%20132h7l3%203%201%203%209%2013%202%202%201%203%202%203q4%207%203%2015v8l-4-7-2-2-1-4q-9-19-21-37'/%3e%3cpath%20fill='%23258ac2'%20d='M293%20347q4%200%207%204v2h2l1%204%204-1%202%203-2%203h-4l1%2019-9-13-1-4h-9l-1-2h8l-1-2q-2-3-2-7l4-1-1-2v-2zM71%20419l5%201h7l2%2011-9%202-2%204-3%201-3-2-5-1%201-6h-3l1-4%206-2%201-2z'/%3e%3cpath%20fill='%23255b92'%20d='M0%20298q4%200%207%203%202%202%202%206h4l39%201v4H5l-1-6-4-4z'/%3e%3cpath%20fill='%237ecffa'%20d='m116%20216%205%201-3%205%202-2%202-1%204%202h4l-6%2018-2-1h-2l-2%202-4-1q-4-8%200-17z'/%3e%3cpath%20fill='%23255b92'%20d='m206%20131%203%201h-2l2%202a253%20253%200%200%201%2037%2068c5%2015%205%2015%205%2019h-3l-1-3-9-27q-14-32-35-58zM99%20408q5%205%207%2012v2l2%207h2l1-13h1l2%2012%202-4%204-2%203%204-7%2012-4-2v3l-4%201-1-3-3-8q-6-10-5-21m33-270q12%2011%2018%2026l2%204%201%203q-9-2-13-11l-16-20q3-3%208-2m43-4q7%202%2010%208a214%20214%200%200%201%2021%2037c15%2031%2015%2031%2015%2044l-3-1-2-5v-3l-1-3q-13-40-39-74z'/%3e%3cpath%20fill='%237ecffa'%20d='M213%20464q8%200%2013%205l-1%208h-6l-1%205q-10%201-16-4l2-3h6l1-3%209%202v-2l-2-1h-3l-3-1-3-3v-2z'/%3e%3cpath%20fill='%23c4d1f0'%20d='m154%20173%204%201q-1%206-6%2011l-9%2017-1%202-5%2014h-5l4-13%201-3q7-15%2017-29'/%3e%3cpath%20fill='%232eb7ed'%20d='M207%20132h3l5%207%203%204%204%206a227%20227%200%200%201%2031%2070l-2%201-1-2-13-36-2-4a303%20303%200%200%200-27-42z'/%3e%3cpath%20fill='%23c4d1f0'%20d='m22%20180%202%201%207%202-4%2011-1%203-1%203-5%208q-4-2-5-5l1-8%201-2z'/%3e%3cpath%20fill='%23258ac2'%20d='m289%20132%204%201%204%206%201%202%204%206%201%202%2014%2026q4%208%203%2016-4-4-5-10-10-24-24-45z'/%3e%3cpath%20fill='%23255b92'%20d='m284%20132%209%2013%201%202%204%207%201%202%2014%2029%201%203%202%203%201%203%202%209-4-1-2-4-1-3v-2a212%20212%200%200%200-29-58z'/%3e%3cpath%20fill='%23258ac2'%20d='m198%20483%203%201%2016%201q-5%203-12%202h-83v-2q38-2%2076%200zM91%20423h5l1%202h2q3%200%205%202%207%2010%205%2021l-3%209h-1v-3c-2-13-6-19-15-29z'/%3e%3cpath%20fill='%23559fdf'%20d='M279%20132q4%200%205%203l2%202%201%202%202%203%201%202q18%2028%2026%2059h-4l-1-3q-10-35-31-65z'/%3e%3cpath%20fill='%232eb7ed'%20d='m0%20302%204%202%201%207%2082%201q-5%203-11%202H13l-10-1-1-8-2-1z'/%3e%3cpath%20fill='%23becaee'%20d='m12%20136%206%201-6%2013-11%2022H0q-1-10%204-18l1-3z'/%3e%3cpath%20fill='%23258ac2'%20d='M74%20346q18%208%2023%2026l1%202-5-4v-2l-4-2q-9-7-15-17zm73-4h1v6q-4%2010-13%2017l-2%202-8%208q0-10%208-17l3-2q7-4%2010-12z'/%3e%3cpath%20fill='%23becaee'%20d='M53%20141h3l-5%2010q-11%2016-17%2034l-3%203h-2l7-18%201-2c10-21%2010-21%2016-27'/%3e%3cpath%20fill='%23258ac2'%20d='m132%20337%203%201q-1%209-9%2013-11%208-12%2020v2q-3-2-3-8%202-9%2011-16l7-8z'/%3e%3cpath%20fill='%232eb7ed'%20d='M236%20312h74q6%200%2010%202h-71l-13-1z'/%3e%3cpath%20fill='%234c55a2'%20d='M302%20462h7v2h2l1-2-1%2014-6-4v2l-4%206-1%204-7-4%201-4%206%201q3-4%202-10z'/%3e%3cpath%20fill='%23164476'%20d='M82%20416h2l2%203%2015%2017-1%202-7-1-1%202-3-4-2-2-1-4h-2l-1-4-1-3z'/%3e%3cpath%20fill='%23becaee'%20d='m40%20140%204%201-1%202-17%2031-1%202-1%202-4%205-2-1q9-22%2022-42'/%3e%3cpath%20fill='%23258ac2'%20d='M251%20132h3l6%208q20%2029%2030%2063h-2l-1-2a310%20310%200%200%200-33-64l-2-3z'/%3e%3cpath%20fill='%23becaee'%20d='m67%20143-4%208q-7%2010-12%2022l-8%2019h-2l-1%202c1-10%2015-51%2027-51'/%3e%3cpath%20fill='%232eb7ed'%20d='M307%20132h13v20l-9-12-1-1z'/%3e%3cpath%20fill='%23becaee'%20d='m27%20138%203%201-2%203-16%2033-5%2011H5l5-15z'/%3e%3cpath%20fill='%237ecffa'%20d='M9%20171q-1%209-5%2016l-1%203-2%206H0v-24c6-2%206-2%209-1'/%3e%3cpath%20fill='%2388aede'%20d='M44%20428h2l1%2011q-4%207-11%208l-1-7%207-9z'/%3e%3cpath%20fill='%23255b92'%20d='M231%20165h2q6%206%209%2014l1%202%202%204%203%205%202%208v2l-2%204-1-2-8-20zm-3%20331%202%201q8%203%2017%203v2l-6%201%204%203-23%201v-3l8-1z'/%3e%3cpath%20fill='%23258ac2'%20d='m261%20132%207%205%201%203%201%202%202%203c24%2039%2024%2039%2027%2058h-2l-1-3q-12-35-33-65z'/%3e%3cpath%20fill='%2346c8f7'%20d='M119%20328h121v1H119z'/%3e%3cpath%20fill='%23164476'%20d='M115%20381h2l-2%2012-4%2018h-1l-1-13v-3l1-11%204-1z'/%3e%3cpath%20fill='%231f2857'%20d='M71%20473q8%2013%205%2027l-2%206-4%201%203-8-2-13z'/%3e%3cpath%20fill='%23d6d7e2'%20d='m12%20452%202%201%201%205%204-1%201%204-3%205-1%207h-1l-1-6-2%201-2%208-1%202-1%206H7q-2-13%207-23h-3z'/%3e%3cpath%20fill='%237ecffa'%20d='m223%20370%202%201v2h2v6q-3%203-7%203l-4-4%202-7z'/%3e%3cpath%20fill='%23182a5b'%20d='m227%20497%203%204%201%203h-9v3h-11l2-1v-3q4-3%2010-2v-3z'/%3e%3cpath%20fill='%23164476'%20d='m119%20422%204%204-7%2012-4-2v3l-4%201v-5l2%202%202-6h2v-2q1-5%205-7'/%3e%3cpath%20fill='%233a518f'%20d='m253%20145%209%2012%201%203%204%207%201%202c14%2026%2014%2026%2014%2034h-2l-1-2q-9-27-25-52z'/%3e%3cpath%20fill='%23164476'%20d='M68%20317q8%201%2013%207c7%2011%207%2011%207%2015l-1%202-1-2q-4-9-13-15z'/%3e%3cpath%20fill='%23258ac2'%20d='M120%20475h40l5%202-19%201-8%201h-18z'/%3e%3cpath%20fill='%232eb7ed'%20d='M320%20369v20l-5-7-1-4-1-8zm-62%2048h2l1%202%205%208%202%202%201%202-2%201q-10-3-17-11v-1h9z'/%3e%3cpath%20fill='%23258ac2'%20d='M126%20411v3l3-1-5%2012-2-1-3-1-2%201%202-8q1-5%207-5m-52-30%2010%201q10%201%2018%208l-1%202-2-1q-4-3-10-3-8-1-15-6z'/%3e%3cpath%20fill='%232eb7ed'%20d='m279%20318-1%202h-30l-12-1h-23v-1zm-29%2014q7%203%2010%2011v7l-3%203-1%205%202%203%209%201h9q-5%203-12%202l-9-2q-2-5-1-9l2-2q2-4%201-9z'/%3e%3cpath%20fill='%2346c8f7'%20d='M0%20328h79v1H0z'/%3e%3cpath%20fill='%237ecffa'%20d='M260%20325q6%204%208%209l-1%204h-5c-4-5-4-5-4-10zm33%2022q4%200%206%203v6q-5%203-10%201v-4l4-1-1-2v-2z'/%3e%3cpath%20fill='%23164476'%20d='m81%20437%204%201v2l2%201q7%204%209%2012l-1%205-1-2-8-11q-4-3-5-8'/%3e%3cpath%20fill='%233a518f'%20d='M272%20498q6-2%2011%202l7%206q-5%201-11-2l-2-1-6-2z'/%3e%3cpath%20fill='%237ecffa'%20d='M134%20223h1l1%203q1%205%205%207l-2%201-3%204-4%203h-2z'/%3e%3cpath%20fill='%234c55a2'%20d='m317%20436%202%201v5l1%203v14h-1v-5l-5%201%201-2v-7z'/%3e%3cpath%20fill='%23258ac2'%20d='m121%20428%205%202-12%2016v-6l2-3%201-3z'/%3e%3cpath%20fill='%23559fdf'%20d='m282%20143%209%2012%201%203%2010%2020-1%203-1-2-5-10-2-3-9-18z'/%3e%3cpath%20fill='%23d6d7e2'%20d='M10%20469q2%204%200%209l-1%203-1%203H7c0-10%200-10%202-14z'/%3e%3cpath%20fill='%2346c8f7'%20d='m195%20440%203%201-3%203-1-2z'/%3e%3cpath%20fill='%23255b92'%20d='M16%20462v3l-2-1z'/%3e%3cpath%20fill='%2346c8f7'%20d='m245%20443%203%203-3-1z'/%3e%3cpath%20fill='%23258ac2'%20d='M0%20377h1v5H0zm103%2016%202%201-1%202z'/%3e%3cpath%20fill='%2346c8f7'%20d='m166%20439%202%201Z'/%3e%3c/svg%3e",
	winter: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='507'%3e%3cpath%20fill='%23e5b5b3'%20d='M0%200h320v507H0z'/%3e%3cpath%20fill='%233d3f55'%20d='M1%200h319v114l1%2069v132c-1%206-1%206-5%2010q-7%203-16%202l-15%203-3%201v4c-1%205-1%205-5%2010l-1%202q-7%203-15%201l-5%202v2q-19%204-38-1l-13%202-11-1v-2h-5l-4-5%201-3h2l2-6%206-1%201-5h5l-2%203%205%201v-3l3%201%202-3h4l1-4h8v-2l2-2v-2l9-1%201-3c6-2%208-2%2014%200v-2l-5-1%202-3%205%202-1-6%204-2-3-6-2-6-3-1-3-13-1-16v-13h-2v-6c-2-24-5-52-20-71v-2h-2l-2-3-7-9-5-5-3-2v-3l-4-2v-2h-2l-4-5-4-2c-4-3-4-3-7-8l-13-15q-11-9-26-9l-7-2-8-1v-4l9%201v-2l16%202q-8-11-19-17-7-5-11-12v-2h-2l-5-5c-13-13-30-18-48-23l-9-5q-12-8-25-12L16%2011%204%203%201%201z'/%3e%3cpath%20fill='%2369362f'%20d='M320%20344v163H0v-95c11-2%2011-2%2018%201v2l-4%203%2010-1%206%201%207-2h4v-2c7%200%207%200%2014%203l7%202v-2h5v2l7%201-1-4%204-1v2l4%202%203%202%207%201v-2l-3-1v-3l-4%202-2-4%2010-2-1%207%205%201%202%201v2l6%202v-2h2v-3l-4-2-6-3v-2l9-1v-2h3v-2h5l4-2%209-1v-2l6%201h12v-2h2v-2l-2-1v-3l14-2-1%205h3l4-5h6l1-8q0-4%205-7l5%202-1%203%204-2h7l-4-5v-2l9%203v-3c8%200%208%200%2013%203l4%204-1-5h2l1%203%203%203%203-1%201-2-6-1v-1l16%202%201%202%201-3-7-2v-3h5l9-2%201-5q12-3%2023%202h3l-5-1c-6-2-6-2-9-5q9-2%2017%201l2%201%2010-1%202-4%2010-6%201-3%205-1v-2c14-4%2014-4%2019-4'/%3e%3cpath%20fill='%23f29f85'%20d='m0%200%2016%2010%204%203%207%206%2012%204%2022%2012q8%204%2017%206l10%204%206%202q13%208%2025%2018v2h2l4%206q6%208%2015%2012l11%2011v2c-13%200-13%200-16-2v2l-9-1v4h8q2%205%201%2011v9l-1%2065-1%2080-4-5-3-2v-40l-4%205-11%2010v18h-2l1%203-7%201v2l4-1%204%201-1%202-16-1-8%203-1%202h-2v8l-2%202v12l-4%203c0%206%200%206%204%2012v17l-1%209v8h-2v2l-7-1%2010%2015%203%204%206%208-1%202c-11-4-20-19-26-29l-12-1-7-1h-5l10%2011%2016%2018q-11-7-20-18l-3-4-3-3c-3-2-3-2-11-2h-3l-4%201-9-1-4-1-6%204H0z'/%3e%3cpath%20fill='%237c99d9'%20d='M104%20259h6l7%203%204%201q9%204%2012%2012l2%201v2l3%201%201%205-3%202-3-3-4-1-2-5-6-1v-2l-9%204-1%209q-4%200-7-5h-2c-2-6-2-6-1-9v-3h-8v5l-4%201-2%204h-2v-2h-2v10h3l-1%204-2%201-2%203-2-3%204%207v32l2%201%201%203%204%201v-3q3%201%205%204v3h5c5%200%205%200%208%202v2l6-3v-3l3%201v2h3v-2h6l1-3h3l-1%203%201%202%208%201-1-8-5%202%206-12%207%201v-2h5q4%206%204%2012l2-1%205%201-1%2013h3v-4l3-15h6l1-3v3l4%201%2011%204v2l2%201-4%205%202%205%206%202v2l5-1%206%201%207-1q9-2%2018%201h14l10-1%202%201v-2q7-5%2016-2l4-1%202-5%202-2%201-4c1-5%201-5%206-8q10-2%2022-2c4%200%204%200%2010-5h1v18l-1%206-18%203v2l-5%201-1%204-10%206-2%204q-9%202-18-1l-10-1q8%205%2017%206v1q-9%200-19-3h-11v5q-7%203-15%202l1%203%206%202-1%204-4-1h3v-2l-14-1%204%201-1%203-4%201v-3l-3-1v-3l-1%201%201%206-8-7-10-2v3l-9-3%201%204%203%201v2l-11%202v-3l-4-1c-3%203-3%203-4%2010l-2%204h-6l-1%203h-2l-1%203-3-1v-5l-13%202v3l3%201-1%202h-2v2q-9%202-18-1v2l-4%201-9%203-5-1v2h-3v2l-9%201%207%205%203%202v3h-2v2l-7-1%201-3-7-2-1-4%202-3-4%202h-6l3%203%203-1%201%203%203%203c-3%201-3%201-9-1l-7-5h-3l1%204-7-1v-2h-5v2c-11-2-11-2-14-4l-7-1v2q-10%204-21%202l-1%201h-6l3-4h2l-8-4-10%201-1-57v-4l1-12c4-4%204-4%209-5l7%202%2012-2v2l2-1c6%200%206%200%209%202l3%204%204%204%204%204%204%203-16-18c7-4%2018-1%2025%201q9%208%2014%2018c8%2010%208%2010%2012%2011l-13-19-5-9%207%201v-2h2v-12l1-13c0-7-1-9-5-15v-6l4-3v-12l2-4%201-6h2l2-4c7-2%2010-2%2017-1'/%3e%3cpath%20fill='%233d3f55'%20d='M1%200c10-1%2010-1%2017%205l2%204q14%2010%2029%2016l3-1%2034%2011v2h9l1%204%2010%205q9%205%2016%2012l4%203%208%208%209%206q19%2012%2034%2027v2h-2l8%206%201%202%203%201%203%208%2010%204v5l9%203%203%203h6l3%205%209%201v-3l3-1-1-5v-5l12-10h-6l-1-3-2%201-2-1%201-5%205-2%201-2%206-2%2014-6%206-1v-6h1l1%205%208%2052h-2l-1%206-1%204%204-1%202%206q7%209%2016%2014l-6%207h-49v3l23%204c6%202%206%202%2013%201v2l4-3%204%202%205-1v8l-3%201%201%202h3v3l7%2033v9l-6%202-7%206v9l-2-1v-5h-2v-2l-5%202q-5-6-5-14l1-6-1%205-4%201-4-5%2010%2015c2%204%202%204%201%209l-8%206q-7%206-8%2014l-2%201%201%202-1%205c3%202%203%202%2011%202v-3l4-3%203%204%203%201%201-7%202-4h6v4l-6%201v2l7-1%202%201%205-1-1-4h2l2-5%203-1v-4l4%201v3l6-1%201-4%203-3%208%203%201%2024v19c-1%205-1%205-5%209q-7%203-16%202l-15%203-3%201v4c-1%205-1%205-5%2010l-1%202q-7%203-15%201l-5%202v2q-19%204-38-1l-13%202-11-1v-2h-5l-4-5%201-3h2l2-6%206-1%201-5h5l-2%203%205%201v-3l3%201%202-3h4l1-4h8v-2l2-2v-2l9-1%201-3c6-2%208-2%2014%200v-2l-5-1%202-3%205%202-1-6%204-2-3-6-2-6-3-1-3-13-1-16v-13h-2v-6c-2-24-5-52-20-71v-2h-2l-2-3-7-9-5-5-3-2v-3l-4-2v-2h-2l-4-5-4-2c-4-3-4-3-7-8l-13-15q-11-9-26-9l-7-2-8-1v-4l9%201v-2l16%202q-8-11-19-17-7-5-11-12v-2h-2l-5-5c-13-13-30-18-48-23l-9-5q-12-8-25-12L16%2011%204%203%201%201z'/%3e%3cpath%20fill='%23e27459'%20d='M45%2026c12%206%2012%206%2015%209l18%206%2016%206q13%208%2025%2018v2h2l4%206q6%208%2015%2012l11%2011v2c-13%200-13%200-16-2v2l-9-1v4h8q2%205%201%2011v9l-1%2065-1%2080-4-5-3-2v-40l-4%205-11%2010v18h-2l1%203-7%201v2l4-1%204%201-1%202-16-1-8%203-1%202h-2v8l-2%202v12l-4%203c0%206%200%206%204%2012v17l-1%209v8h-2l-1%202a316%20316%200%200%201-5-83l1-27v-83l1-39%203-1%201-7-16%201v-3h-2l1%203-16%203-4%201q-14%203-29%203v-2l18-2v-2l8-1%202%201v-2h6l1-3h-2q0-8%202-15h-2z'/%3e%3cpath%20fill='%236b627a'%20d='M289%209v33c0%204%200%204%204%2010v2l6%201-1-3%203%201v3q10%202%2019-4v221l-5-2h-5l-2%207h-6l-1-3-3-1v4l-4%204-1%202h-2l1%204c-6%202-6%202-9%201h-5v-2l6-1v-4h-6l-1%204-2%207q-4%200-6-4l-3%203%201%202h-2l-1%202v-2l-7%201-4-2%201-7-1-2h3v-5q4-8%2012-12h2c2-4%202-4%201-9l-5-8-7-12h2l4%206h4v-5l2-1-1%206c0%207%200%207%204%2013v2l5-2v2h2l1%205v-8l4-2%201-3c4-3%204-3%209-4l-6-30-1-14-5%201%201-3%202-1%201-8-6%202-3-2-4%202-1-1v1q-9%200-19-4l-16-3v-3q6-2%2013-1h26l6%201c5-1%205-1%209-6l-4-3c-12-10-12-10-14-17h-3l3-11-2-12-1-8-3-14-4-30h2l5%206%203%201%202-4%202-2-3-3-8-9-5-4q-3-15-2-31c19-28%2019-28%2028-28'/%3e%3cpath%20fill='%23e27459'%20d='M233%20204h2c7%2034%207%2034%205%2044h2l2%2016v4l1%2017%201%205%204%201c4%209%204%209%204%2013l-3%202v5l-5-1v2l3%201v2l-4-1-10%202-1%202-9%201%201%203-3%201v2h-8l-1%204-4%201-3%203v-2h-2v3h-6v-3h-2l-1%204-8%202v-2l-9-2v-2l-4%201v-2l-8%201-4%2018h-3v-5l1-6v-6l-1-9-7-2-2-6-5-8q-3-3-4-7%202-9%209-13l12-13%208-8h2l2-4%206-6%203-4%205-2%202-4c6-5%206-5%208-5l2-4%2017-17%201-2h2v-2l10-9z'/%3e%3cpath%20fill='%234b5d8b'%20d='M215%20464c-6%206-20%209-29%2011l-4%201-10%201-5%205q-6%202-13%201v2l-7%202-4%204-8%202%206%204%209%207v3H0v-35q6-2%2014-2h15l14-1%208-1%2040-1%2027-1z'/%3e%3cpath%20fill='%23bd7272'%20d='M58%20185q3%2022%200%2044v6l-3%2063h1l-1%209%206%2015%202%205%206%208%2011%2014%208%2011%202%203-1%202c-11-4-20-19-26-29l-12-1-7-1h-5l10%2011%2016%2018q-11-7-20-18l-3-4-3-3c-3-2-3-2-11-2h-3l-4%201-9-1-4-1-6%204H0V206h1q3%2025%202%2049l2%2060H3c2%206%202%206%205%209l2-7-1-1v-7l-2-49v-42l7%202%203%2073c0%2020%200%2020%203%2023l4-56v-8l3-61h3v2h2v-2c7%201%207%201%2010%205l3-3h3l1-6c4-2%204-2%209-2'/%3e%3cpath%20fill='%23482b2b'%20d='M18%20413v2l-4%203%2010-1%206%201%209-2v2h4l29%207%202%203-14-3-5-1-10-2v2l6%202%2043%2019%206%203%207%202v5l6-5h2v3l20%203q27%205%2054%200l12%201-1-3%2015-3h-19c-10%200-10%200-16-3v-1h6l8-2q18-2%2034%203l7%202%205%202-14-6%201-2%2013-1%208-2h5l4-2%205%201v2l-2%202h7l-1%203-10%204-5%202-9%203v2l19-6q-3%205-10%206l-13%205c-3%202-3%202-10%203v-2l7-2v-2l-16%204-34%201a1817%201817%200%200%200-138%204l-47%203v-60c11-2%2011-2%2018%201'/%3e%3cpath%20fill='%23e5b5b3'%20d='m59%2035%2035%2012q13%208%2025%2018v2h2l4%206q6%208%2015%2012l11%2011v2c-13%200-13%200-16-2v2l-9-1v4h3l1%2021v7l-1%206v39l-1%2012v19c0%205%200%205-3%2011l-5%204-5%205-4%203c-2-8-2-8-1-13v-63l-5-1-1%2032h-1v-12h-2v-16l1-14h-2v-8l-1-10v-11l-1-4-1-8-8-1-3-1v-2l9-1-1-2h-2l-2-5-3-1v5l-6%201-2-6h-4l1%206h-3v-6l-6%201-1-3h-3v2l-4-1%201%208h-2l-2-4-3%202%202-5%201-7-5-1-1-5%204-1%201-5%202-2h3v-4z'/%3e%3cpath%20fill='%23482b2b'%20d='m312%20270%208%203%201%2024v19c-1%205-1%205-5%209q-7%203-16%202l-15%203-3%201v4c-1%205-1%205-5%2010l-1%202q-7%203-15%201l-5%202v2q-19%204-38-1l-13%202-11-1v-2h-5l-4-5%201-3h2l2-6%206-1%201-5h5l-2%203%205%201v-3l3%201%202-3h4l1-4h8v-2l2-2v-2l9-1%201-3c6-2%208-2%2014%200v-2l-5-1%202-3%205%202-1-4h2v3h2l1-6%204-1-1-4%205%201%201-2h3l-2-7%204-3%203%204%203%201%201-7%202-4h6v4l-6%201v2l7-1%202%201%205-1-1-4h2l2-5%203-1v-4l4%201v3l6-1%201-4z'/%3e%3cpath%20fill='%237c99d9'%20d='M289%209v33c0%204%200%204%204%2010v2l6%201-1-3%203%201v3q10%202%2019-4v60l-5%201-7%203v2l2%201v6l-4-1-1%203-3-1-1%204q-5-5-6-12l-7-3v29l5-1-1%205-3%201-2%204c-7%207-7%207-11%208l-1-3h-3l3-11-2-12-1-8-3-14-4-30h2l5%206%203%201%202-4%202-2-3-3-8-9-5-4q-3-15-2-31c19-28%2019-28%2028-28'/%3e%3cpath%20fill='%234b5d8b'%20d='M141%200h138l-6%207-5%206-4%205h-2l-2%204-1%202h-2l-2-14-3%202-5%202-5%203c-5%202-5%202-12%202l-5-3v-2l3-1-1-2%205%201%208-4%206-1-7-1-3%203h-6l-1-1-1%202-7%202-3%205h-3v-2h-3l3%2033%201%2014%201%201%201%209%201%205v9h-2v-2l-5-2v2h-2v-3l-3%201-2-5-5-1-2-5-5-5v-2l-6-2-1-3%201-2-3-1V46h-4l-2-4-2-1-2%206-12-12-5-5q-12-13-16-30'/%3e%3cpath%20fill='%23482b2b'%20d='M320%20344v12l-3%202-4-1q-13%206-25%2015l-23%2017q-12%206-23%204-13%200-23%209l-1-2-3-1-2%204-2%201v-2l-3%201%201%202h2l-1%204c-13%204-13%204-16%203l-1%202q-25%207-51%200l3-2-12-3v-2h3l-1-3h9v-2h2v-2l-2-1v-3l14-2-1%205h3l4-5h6l1-8q0-4%205-7l5%202-1%203%204-2h7l-4-5v-2l9%203v-3c8%200%208%200%2013%203l4%204-1-5h2l1%203%203%203%203-1%201-2-6-1v-1l16%202%201%202%201-3-7-2v-3h5l9-2%201-5q12-3%2023%202h3l-5-1c-6-2-6-2-9-5q9-2%2017%201l2%201%2010-1%202-4%2010-6%201-3%205-1v-2c14-4%2014-4%2019-4'/%3e%3cpath%20fill='%23a7b4e4'%20d='M104%20259h6l7%203%204%201q9%204%2012%2012l2%201v2l3%201%201%205-3%202-3-3-4-1-2-5-6-1v-2l-9%204-1%209q-4%200-7-5h-2c-2-6-2-6-1-9v-3h-8v5l-4%201-2%204h-2v-2h-2v10h3l-1%204-2%201-2%203-2-3%204%207v32l2%201%201%203%204%201v-3q3%201%205%204v3h5c5%200%205%200%208%202v2l6-3v-3l3%201v2h3v-2h6l1-3h3l-1%203%201%202%208%201-1-8-5%202%206-12%207%201v-2h5q4%206%204%2012l2-1%205%201-1%2013h3v-4l3-15h6l1-3v3l4%201%2011%204v2l2%201-4%205-1%204-4%204h-3v2l-5%202-1%204-8-2-2%203h-2v-3h-2l-2%205-2-1v-3l-2%202-3-2-3-1-1%202h-2l-3-3-2%206-9%201v-2l-13%203-10%201-1%203-1-2%201-2h-2v2c-5%201-5%201-12-1l-13-17-4-5-3-7%207%201v-2h2v-12l1-13c0-7-1-9-5-15v-6l4-3v-12l2-4%201-6h2l2-4c7-2%2010-2%2017-1'/%3e%3cpath%20fill='%23f29f85'%20d='m95%2040%2022%204%206%201q14%203%2026%209l16%206q8%202%2012%209l5%202%206%206c6%206%206%206%2010%207l3%205%205%204%209%2013v3h2l1%206%203%201%202%206%204%201c5%204%206%205%207%2012l-1%204h-3l1%203h-10l-3-5h-6l-4-3-4-1c-4-3-4-3-5-8l-8-2c-3-3-3-3-4-10l-4-1v-2l-5-1-3-3v-2h2q-8-10-20-18l-3-2-17-12-9-8-8-7-5-4q-9-7-20-12z'/%3e%3cpath%20fill='%23a7b4e4'%20d='M44%20333c17%200%2017%200%2023%206l10%2014%2012%2017h-2l2%202-1%205-3-1%201%203h-2l-1-2h-7v-2l-3%201-6-1q-6%202-6%204H41l-11-1-7%201-2-4-4%204-7-2v2l-9%201c-3-3-2-16-2-21v-5l1-15c4-4%204-4%209-5l7%202%2012-2v2l2-1c6%200%206%200%209%202l7%208%204%203-12-14z'/%3e%3cpath%20fill='%23e27459'%20d='M58%20185q3%2022%200%2044v6l-2%2037v4l-2%2021h-3c-4-7-4-7-4-10l-2%201%202%206%201%205-6-3-6-1-1-6-2-4H23l1-35%203-59h3v2h2v-2c7%201%207%201%2010%205l3-3h3l1-6c4-2%204-2%209-2'/%3e%3cpath%20fill='%23f08b7b'%20d='m12%200%2072-1h6c14%200%2014%200%2021%206l3%206q15%2014%2033%2024l12%2011q-7%201-14-2-10-4-20-5l-3-1-4%201q-7%201-15-1H88l-2-1v-2l-5-1-11-3-5-2-15-5-1%202C23%2015%2023%2015%2017%206z'/%3e%3cpath%20fill='%234b5d8b'%20d='m284%20194%204%201v5l-3%201%201%202h3v3l7%2033v9l-6%202-7%206v9l-2-1v-5h-2v-2l-5%202q-5-6-5-14l1-6-1%205-4%201-4-5%2010%2015c2%204%202%204%201%209l-8%206q-7%206-8%2014l-2%201%201%202-1%205q5%203%2012%202l1%204h-3l-1%203-1-2-2%202-3%203h-2l-1%206h-2v-3h-2l4-5-3-5-2-6-3-1-3-13-1-16v-13h-2v-7l-2-15-1-16%2010%204q11%206%2023%202%207-3%209-9l-5%203q-11%205-23%203l-12-6-1-3%2013%205q11%203%2022-1%208-5%2011-14'/%3e%3cpath%20fill='%236b627a'%20d='m96%20268%205%202%201%2012%203-1%203%205%204%203%203%203q-1%2010-6%2018l9-7%204-1-1%204%205-4c4-2%204-2%2011-1v3q2%207%206%2012l-6-10q8%204%2012%2014l1%204-2%201-3-1v2l-6%201-1-1-6%2011%205-2%201%208h-4l-1%202v-2l-4-1-1-3h2v-2l-4%203h-6v2h-3l-3-3%201%204-7%202v-2q-7-2-14-1l-1-5-3-3v3c-5-1-5-1-8-5l1-17q1-11-5-20l1-3%202%203%205-7h-3v-10h2v2l4-5h4l-1-5z'/%3e%3cpath%20fill='%233e3139'%20d='M299%20432h1l-5%2020%201%201%204-2-8%2011-1%204%207-5v2l5-2%208-3%205-2%204-1v52h-67c0-18%200-18%205-24l6-3v-2l5-3-2-3%202-1%202-8%203-3%201-3h2v5l5%201%202%201-1-2-1-15%202%201%202%209%202-1-2%208h3l1-4%205-17%202-6z'/%3e%3cpath%20fill='%23f29f85'%20d='m0%200%2016%2010%204%203%207%206%205%202%203%2018v23l1%2030-4%201-2-3-12-1-1%204h-4l-6%202-1-18-4%2016-2-1z'/%3e%3cpath%20fill='%23e5b5b3'%20d='M126%20218h1v33l-1%208%204%202%202%203%201-17%201%204h14l7%201h8l1%2012v5c0%205%200%205-4%2010h-2l-2%204-4%202-2%204-3%203q-3%203-4%207%202%207%208%2012l2%209%207%203q3%207%202%2013h-7l-2%201-1-5q-3-15-13-25l2%203c3%206%203%206%202%2010l-2-5-5-7%201-6c-7-1-7-1-13%203l-3%201v-3l-6%202-1%203-5%202q1-8%205-14v-4l-4-4c0-7%200-7%203-12%203-2%203-2%208-2v2h6l2%206%205%201%203%202%201-4-3-3v-2l-3-1-2-4q-8-9-20-10v-3h-7v-2l6-2v-14c1-6%201-6%206-11l5-4z'/%3e%3cpath%20fill='%23f08b7b'%20d='m45%2026%2014%208%201%2026v6l-4%202-2%205-3%201%201%205%204%201-1%2010%202-1%201%205%201-1v-7l4%201v-2h3l2%202%203-1%202%201v6h3l-1-6h4l2%205h6v-5l4%201%201%205%203-1v3l2%201H86v2l9%201h3q3%2021%202%2042h2c0%208%200%208-2%2011l-1-3-5%203v-2h-2v3l-4-1-2%201v-2l-3-1-2-4h-7v-41l3-1%201-7-16%201v-3h-2l1%203-16%203-4%201q-14%203-29%203v-2l18-2v-2l8-1%202%201v-2h6l1-3h-2q0-8%202-15h-2z'/%3e%3cpath%20fill='%23a7b4e4'%20d='M320%20221v52l-5-2h-5l-2%207h-6l-1-3-3-1v4l-4%204-1%202h-2l1%204c-6%202-6%202-9%201h-5v-2l6-1v-4h-6l-1%204-2%207q-4%200-6-4l-3%203%201%202h-2l-1%202v-2l-7%201-4-2%201-7-1-2h3v-5q4-8%2012-12h2c2-4%202-4%201-9l-5-8-7-12h2l4%206h4v-5l2-1-1%206c0%207%200%207%204%2013v2l5-2v2h2l1%205v-8l4-2%201-3c4-3%204-3%209-4l-1-6-1-11q9-5%2019-6z'/%3e%3cpath%20fill='%23f29f85'%20d='M72%20192h1l1%2018v15l-1%2011v32q0%2034%204%2069c-7%200-7%200-12-4q-6-11-10-24l-1-2v-13l1-19v-13l4-68h13z'/%3e%3cpath%20fill='%2369362f'%20d='M45%20445h8l34%2011q8%203%2016%203l1%202%2014%204v1l-71%203-47%203v-25c35-4%2035-4%2045-2'/%3e%3cpath%20fill='%23f9d7bf'%20d='M159%20168h1c1%207%201%208-3%2015h4l1%2018%201%206v45h-11l-9-1h-9l-1-19v-29c0-13%200-13%204-17l4-1%2015-14z'/%3e%3cpath%20fill='%233d3f55'%20d='M1%200c10-1%2010-1%2017%205l2%204q14%2010%2029%2016l3-1%2034%2011v2h9l1%204%2010%205q9%205%2016%2012l4%203%208%208%209%206q19%2012%2034%2027v2h-2l8%206%201%202%203%201v3l-6%202v2l-6%202-4-4q-12-14-30-14l-7-2-8-1v-4l9%201v-2l16%202q-8-11-19-17-7-5-11-12v-2h-2l-5-5c-13-13-30-18-48-23l-9-5q-12-8-25-12L16%2011%204%203%201%201z'/%3e%3cpath%20fill='%234b5d8b'%20d='M105%200h36l7%2016q6%2010%2014%2017l4%206%204%204q5%205%204%206l5%202%203%205c-2%205-2%205-7%2010v-2l-37-14-24-6-19-4v-3q7-1%2013%201%209%201%2016-1l3%201%206%201%2018%206%205%201%201-1-17-13q-20-13-35-30z'/%3e%3cpath%20fill='%23f9d7bf'%20d='M265%2083h2l7%208%205%205%203%204c4%203%204%203%2011%205l1-3h11v-5c6-3%206-3%2015-4v19l-5%201-7%203v2l2%201v6l-4-1-1%203-3-1-1%204q-5-5-6-12l-7-3v29l5-1-1%205-3%201-2%204c-7%207-7%207-11%208l-1-3h-3l3-11-2-12-1-8-3-14z'/%3e%3cpath%20fill='%236b627a'%20d='M320%200v40l1%207-1%205q-7%205-16%206l-5-5v2c-6-1-6-1-9-5q-5-11-3-23v-5q-1-12%205-19%2014-5%2028-3'/%3e%3cpath%20fill='%23a7b4e4'%20d='m245%20286%201%204%204%201c4%209%204%209%204%2013l-3%202v5l-5-1v2l3%201v2l-4-1-10%202-1%202-9%201%201%203-3%201v2h-8l-1%204-4%201-3%203v-2h-2v3h-6v-3h-2l-1%204h-2c-3-7-3-7-3-13l2-2-1-12v-5c3-3%203-3%209-5v2l7%201-2-4-1-4%202-3%202%206%203-1%204%204c5-1%205-1%209-5h4v3l5-2h6l1-4%204-2z'/%3e%3cpath%20fill='%237c99d9'%20d='m247%20392%203%202v2l4-1%201%203h3q11%202%2018%208l-3%2011%204%201%205%204c-1%205-1%205-6%209l-7%201q4-5%2010-5l-1-5-10-4-1%207-2%204q-7%201-15-2l-3%202-3-1%204-2v-2h6v-3l-4-1v2h-4v-2h-4v2l-6-1-1%202h-2l-1%202-3-1%201-2-6-1-11-8c1-5%201-5%206-9l6-2%201-2h-2v-3q11-5%2023-5'/%3e%3cpath%20fill='%23f9d7bf'%20d='M128%20129h1l-1%2055v21c0%205%200%205-3%2011l-5%204-5%205-4%203c-2-8-2-8-1-13v-25l1-18v-42l17%201z'/%3e%3cpath%20fill='%233d3f55'%20d='M320%20112v46l-4%202-2%202-11%202-5%208-3-1-1-3-5-4-6-7q2-4%206-7t4-7l-6%202%201-30%209%203v5l3%206%202-3h3l1-2%204%201v-6l-3-1q4-9%2013-6'/%3e%3cpath%20fill='%23f9d7bf'%20d='M183%20133c9%205%209%205%2012%2010h2q5%204%204%207l4%202%201%203%204%202%201%206c0%2027%200%2027-2%2032h-2l-1%204-3-3-5%203h-9l-3%201q-3-8-2-16l-1-6%203-9h-6l-3-3%203-3c3-4%203-4%204-9l-3%201z'/%3e%3cpath%20fill='%23a7b4e4'%20d='m173%206%208%202V6l5%201-1%204%207%202%209%207%202%2029v15h3l1%208%203-1%202%205h3l2%204%202%201v5h-2v-2l-5-2v2h-2v-3l-3%201-2-5-5-1-2-5-5-5v-2l-6-2-1-3%201-2-3-1V46h-4l-2-4-3-2-2-5-1-1v-7h2v-7h-3l-2-4%205%201-1-3z'/%3e%3cpath%20fill='%23d2c3c8'%20d='M60%2095h2v3l3-1h13v7l-4%201v33c0%2052%200%2052-2%2056H59v-92z'/%3e%3cpath%20fill='%23b298b0'%20d='M94%200h11l9%2011q15%2014%2033%2024l12%2011q-7%201-14-2-10-4-20-5l-3-1-4%201q-7%201-15-1H88l-2-1v-2l-5-1-1-7%206%202%205-4h3z'/%3e%3cpath%20fill='%23e5b5b3'%20d='m104%2053%2015%2012v2h2l4%206q6%208%2015%2012l11%2011v2c-13%200-13%200-16-2v2l-9-1%201%206-4%202-2-1-1-3-12-2-3-1v2l-3-1%202-1-2-5h-5l1-32%202%202%201-3h2z'/%3e%3cpath%20fill='%23b298b0'%20d='m33%2022%2012%204v10l1%206v12l-1%2025%203-1-2%206-1%2010h2l-1%204-6-1v2H30v2q-6%202-12%201l-6%201v2l7-1%2013-1%208-2v2q-11%207-25%206l-4-1-3%201-5-3v-2H0V92l2-1%202-8%201-5%201-3h1l1%2019%201-1h8l1-4h12l3%203h3v-4l-2-19V43z'/%3e%3cpath%20fill='%236b627a'%20d='M246%20475v1l-7%202-17%206%207%201q10%201%2018%205l4%202v9l-4-1%204%203v4h-94l1-4%205%201%2018%202%202-4c9-10%2025-15%2037-20h3l1-3%206-1q7-4%2016-3'/%3e%3cpath%20fill='%23e27459'%20d='M0%20206h1q3%2025%202%2049l2%2060H3c2%206%202%206%205%209l2-7-1-1v-7l-2-49v-42l7%202%203%2094h-3l3%203v2h-4l8%206v9l-2-3-1%203h-2v2l-4-1c-4%200-4%200-10%204H0z'/%3e%3cpath%20fill='%23f29f85'%20d='m177%20206%201%202%203-1%205%202%201%2036v4l2%201-4%203q-8%207-14%2015-3%204-7%204l-1-21v-7l-1-33h8z'/%3e%3cpath%20fill='%23bd7272'%20d='m116%20481%2014%208%201%204%209%203%2010%208v3H75c4-6%204-6%209-10%204-3%204-3%206-8l7-4%204-2c9-4%209-4%2015-2'/%3e%3cpath%20fill='%23f08b7b'%20d='m45%2026%2014%208%201%2026v6l-4%202-2%205-3%201%201%205%204%201-1%2010%202-1%201%205%201-1v-7l4%201v-2h3l2%202%203-1%202%201v6h3l-1-6h4l2%205h6v-5l4%201%201%205%203-1v3l2%201h-4l-7%201-12%201H62v-3h-2l1%203-16%203-4%201q-14%203-29%203v-2l18-2v-2l8-1%202%201v-2h6l1-3h-2q0-8%202-15h-2z'/%3e%3cpath%20fill='%234b5d8b'%20d='M266%2091h1l1%205%208%2052h-2l-1%204-4-4h-3l-2-1v2l-4%201-1-2-12%202v-6l-3-1%201-2h2l3-6%2015-4v-5h-2v2l-7%201-1%203h-19l-1-2%2018-1%207-5%204-1-1-3h-6l-1%202h-7l-14%206h-2q4-6%2011-10h-6l-1-3-2%201-2-1%201-5%205-2%201-2%206-2%2014-6%206-1z'/%3e%3cpath%20fill='%23482b2b'%20d='M192%20474v5h2l-1%207%203%206v2l-8%205-7%207-14-1-9-2-1%204h-7l-3-5-14-8c4-3%204-3%2011-4l4-5h6v-2h6c6-1%206-1%2011-6l1-1h8c8-3%208-3%2012-2'/%3e%3cpath%20fill='%237c99d9'%20d='M299%20432h1l-5%2020%201%201%204-2-8%2011-1%204%207-5v2l5-2%208-3%205-2%204%201-7%203-18%208h-2v2l-3%203h-5l-1%206-5%2017-1%206-2%205h-23c-1-17-1-17%205-24l6-3v-2l5-3-2-3%202-1%202-8%203-3%201-3h2v5l5%201%202%201-1-2-1-15%202%201%202%209%202-1-2%208h3l1-4%205-17%202-6z'/%3e%3cpath%20fill='%233d3f55'%20d='m241%20243%206%201h5l12%201%205%207%202%203c2%204%202%204%201%209l-8%206q-7%206-8%2014l-2%201%201%202-1%205q5%203%2012%202l1%204h-3l-1%203-1-2-2%202-3%203h-2l-1%206h-2v-3h-2l4-5-3-5-2-6-3-1-3-13-1-16v-13h-2z'/%3e%3cpath%20fill='%23e27459'%20d='M129%20101h5q2%205%201%2011v9l-1%2065-1%2080-4-5-3-2v-40l-4%205-9%209h-2l-1-9%202%203%205-5h2l2-4%204-2q3-9%202-16v-28l1-5v-30l1-9z'/%3e%3cpath%20fill='%23c7daf8'%20d='M184%20102h2l-1%204%205-2%205-1v2l4%202%201%204%204-1h2l1%202c7%200%207%200%2010-2l1%205%203%201%202%206%204%201c5%204%206%205%207%2012l-1%204h-3l1%203h-10l-3-5h-6l-4-3-4-1c-4-3-4-3-5-8l-8-2c-3-3-3-3-4-10l-4-1v-2l-5-1-3-3v-2l3-1%205%203zm-80%20157h6l7%203%204%201q9%204%2012%2012l2%201v2l3%201%201%205-3%202-3-3-4-1-2-5-6-1v-2l-9%204-1%209q-4%200-7-5h-2c-2-6-2-6-1-9v-3h-8v5l-4%201-2%204h-2v-2h-2v10h3l-1%204-2%201-2%203-2-3%204%207v25l-1%2013q-3-5-2-11v-5l1-12c0-7-1-9-5-15v-6l4-3v-12l2-4%201-6h2l2-4c7-2%2010-2%2017-1'/%3e%3cpath%20fill='%23b298b0'%20d='m95%2040%2022%204%206%201q16%203%2030%2011l4%201%201%2029a288%20288%200%200%201-44-34l-14-9-5-2z'/%3e%3cpath%20fill='%234b5d8b'%20d='m284%20194%204%201v5l-3%201%201%202h3l2%2016q-5%207-13%207v2h-6v2q-16%203-33-2l-2-18%2010%204q11%206%2023%202%207-3%209-9l-5%203q-11%205-23%203l-12-6-1-3%2013%205q11%203%2022-1%208-5%2011-14'/%3e%3cpath%20fill='%23b85952'%20d='m313%20355%201%203%206-2v25l-17%204-1%205-3%208q-1-6%202-12h-7l-1%203-1-2c-8%200-8%200-14%205l-5%201-7%202%2015-11%204-3%209-5%205-4%206-2-2-3q-10%204-19%2011l-3%203-6%205-12%206%205%205%202%202%204%201v2l-10-3h-5l-4-1-1-2h-4l-1-3%206-1q11-3%2019-11c33-24%2033-24%2039-24z'/%3e%3cpath%20fill='%233d3f55'%20d='M137%20301v3q2%207%206%2012l-6-10q8%204%2012%2014l1%204-2%201-3-1v2l-6%201-1-1-6%2011%205-2%201%208h-4l-1%202v-2l-4-1-1-3h2v-2h-4l-2-5%201-2h-2v2h-2l-3-4q-3-4-7-6l-3-12%206-3%204-4%204-1-1%204%205-4c4-2%204-2%2011-1'/%3e%3cpath%20fill='%23f08b7b'%20d='M141%200h37l2%204h-8l-1%202h2l1%2011h-4l1%203h3v7h-2c1%207%201%207%203%209v10q-3%201-7-4l-9-11-3-3-9-11-2-5zM20%2014l7%205%205%202%203%2018v23l1%2030-4%201-2-3-6-2-1-18-1-5z'/%3e%3cpath%20fill='%23f29f85'%20d='M160%20107q10%206%2017%2017l6%206q3%2010-2%2017l-9%209-5%205h-2l-2%204-3%201-2-58z'/%3e%3cpath%20fill='%23c7daf8'%20d='m59%2035%2015%206v16c0%2016%200%2016%203%2022l1%207-3%201%201%206h-3v-6l-6%201-1-3h-3v2l-4-1%201%208h-2l-2-4-3%202%202-5%201-7-5-1-1-5%204-1%201-5%202-2h3v-4z'/%3e%3cpath%20fill='%23e5b5b3'%20d='M289%209v33c0%204%200%204%204%2010v2l6%201-1-3%203%201v3q10%202%2019-4v16l-10%202%201-4h-3l-1%203c-7-1-7-1-11-4l-5-2-2-2-1%205-2%207h-3v-4l-2-16v-5l-1-6-2-16v-9c8-8%208-8%2011-8'/%3e%3cpath%20fill='%236b627a'%20d='M276%2018h2l4%2038%201%205v12h3l2-13%204%203%2015%205%201-2h3l-1%204%204-1%206-1v9l-6-1-1%202q-12%206-26%202h-9l-4-31v-5c-2-21-2-21%202-26'/%3e%3cpath%20fill='%23f08b7b'%20d='M74%2041q16%203%2030%2012v10l-1-3h-2l-1%204-2-2-1%203%202%201-1%201v22l-3%202q-3-9-3-19c-3-2-3-2-10-2l-3%202v10q-7-6-6-17v-8l1-5zm-23%2093%208%201%201%2018v13l-1%207v16l-2-3-9%203-2-11h-2v-39c0-6%200-5%207-5'/%3e%3cpath%20fill='%2369362f'%20d='m298%20274%204%201v3l4%202-6%208-5%201%201%206-2%205-3%201-5%205-7%206-4%203c-3%202-3%202-9%202l-1-1%201-7h-2v-11h3l-2-7%204-3%203%204%203%201%201-7%202-4h6v4l-6%201v2l7-1%202%201%205-1-1-4h2l2-5%203-1z'/%3e%3cpath%20fill='%23b298b0'%20d='m181%2071%2010%209q3%204%207%204l3%205%205%204%206%209%203%204v3l2%201-3%203h-7l-1-3-7%202-2-6-2-1v-2l-5%202-5%201%201-4-2%201-1%203-5-2v-2l3-1z'/%3e%3cpath%20fill='%23482b2b'%20d='M305%20427h5v2l10-2v28l-12%205-5%202q-3%203-6%201l-4%204-3-1%209-14-5%203q2-12%206-22l5-1z'/%3e%3cpath%20fill='%237c99d9'%20d='m287%20476%208%205%2014-2%202%202%205-1v3l3%201-1%204-8%204-3-1v3h-3v2l-6%205-2%206h-19l3-9%204-12%202-5z'/%3e%3cpath%20fill='%23d2c3c8'%20d='M272%2023h1l5%2057%209-2%201%2012q-11-7-20-18l-5-4q-3-15-2-31z'/%3e%3cpath%20fill='%23a7b4e4'%20d='M121%20274v2h6l2%206%205%201%203%202%203-1-1%204%202%2012-2-1-2%203-7-1-6%204-3%201v-3l-6%202-1%203-5%202q1-8%205-14v-4l-4-4c0-7%200-7%203-12%203-2%203-2%208-2M320%2093v19l-5%201-7%203v2l2%201v6l-4-1-1%203-3-1-1%204q-5-5-6-12l-7-3q-4-6-5-14l5%203%205%201%201-3h11v-5q8-4%2015-4'/%3e%3cpath%20fill='%23c7daf8'%20d='M6%2075h1l1%2019%201-1h8l1-4h12l3%203%206-1%203%202%205%201-1%204-6-1v2H30v2q-6%202-12%201l-6%201v2l7-1%2013-1%208-2v2q-11%207-25%206l-4-1-3%201-5-3v-2H0V92l2-1%202-8%201-5z'/%3e%3cpath%20fill='%23f08b7b'%20d='M74%200h20l1%2018v8h-5l-4%204-6-3%201%206-7-2-1-11v-6z'/%3e%3cpath%20fill='%23482b2b'%20d='M223%20488h5l8%201%202%203%205-1%203%203-3%204-4%207-3%201v1c-12%201-12%201-19-5l-8-1q-8%201-13-5%2012-8%2027-8'/%3e%3cpath%20fill='%23f08b7b'%20d='M201%2021c11%207%2011%207%2012%2012l3%2029%201%201%201%2014v4l-3-2v-3l-3%201-2-5h-3l-1-8h-3l-2-18z'/%3e%3cpath%20fill='%23b85952'%20d='M74%20256c6%201%206%201%2012%205l-1%203h-2v8l-2%202v12l-4%203c0%206%200%206%204%2012v17l-1%209v8h-2l-1%202q-5-30-5-60v-4q-1-8%202-17'/%3e%3cpath%20fill='%236b627a'%20d='M178%200h34v29l-15-11c-6-5-6-5-12-7l1-4-5-1v2l-10-2%201-3%208%201z'/%3e%3cpath%20fill='%233d3f55'%20d='m88%20309%202%201v2h2v-2c7-1%209%201%2015%204l1%203h-2l4%204v2l2%201-5%204%204%201%2010%204v2l2%201-1%203h-2v3h-3l-1-2c-12-7-12-7-18-7l-12-4v-8l1-6z'/%3e%3cpath%20fill='%23f9d7bf'%20d='M26%20141h1v40l-7%202v-2h-7l-1-39%2014%201z'/%3e%3cpath%20fill='%23b298b0'%20d='m111%2059%208%206v2h2l4%206q6%208%2015%2012l11%2011v2h-13l-1-4-6-2-2-3q-9-3-19-1z'/%3e%3cpath%20fill='%23b85952'%20d='M209%20410c-4%206-4%206-8%208l-1%201h-7l-2%202-4%202-1%203-6%201-4%201h-7l-1%202-1-1-23%204-7%201%201-2%207-2-4-2c2-2%202-2%208-2h21l9-4%204%201v-3l-20%203q-17%200-35-3v-2l10-1h24l24-3h7l1-3%202%201%206-1q6-3%207-1'/%3e%3cpath%20fill='%23b298b0'%20d='M111%20100h9l1%204%205-1%201-2h2c1%209%203%2022-1%2030h-12l-5-1z'/%3e%3cpath%20fill='%23f29f85'%20d='M60%2099v41h-1v-5H44v-22l1-13z'/%3e%3cpath%20fill='%23a7b4e4'%20d='M320%20221v21c-17%207-17%207-24%206l-2-18q9-4%2019-6z'/%3e%3cpath%20fill='%23b298b0'%20d='M11%20107h15l1%2017v5l-1%2014H13c-3-3-1-12-2-16zm2-62h8l4%2044h-7l-1%204h-5l-1-32%201-4z'/%3e%3cpath%20fill='%23c7daf8'%20d='M243%20289h2v2l3%201-6%204v3l5%202-1%204-3%201-2%204h2v2h-5l-5%201h-2l-3-3-4%201-2%204h-6c-4-6-4-6-4-11l2-4%207-2%204-4h4v3l5-2h6l1-4z'/%3e%3cpath%20fill='%233d3f55'%20d='m188%20116%202%205%2010%204v5l4%202%204%202-1%206v7l2%202-2%203-6-2v-3l-4-2v-2h-2l-4-5-4-2c-4-3-4-3-7-8l-5-6%206-2v-2q3-2%207-2'/%3e%3cpath%20fill='%23e5b5b3'%20d='M12%200h32l1%209%201%203%201%2010%203%201-1%203C23%2015%2023%2015%2017%206z'/%3e%3cpath%20fill='%236b627a'%20d='M275%20356h7l-1%204%203-2c4-3%204-3%209-3l-8%207-2%203q-9%202-18-1l-10-1q8%205%2017%206v1q-9%200-19-3h-11v5q-7%203-14%202l2-6h3l3-3%207-2%201-3%2011-4%202%201-1%202%204-4q8-2%2015%201'/%3e%3cpath%20fill='%23bd7272'%20d='M110%200h25l13%2030c-14-6-30-17-38-30'/%3e%3cpath%20fill='%23b298b0'%20d='M299%20432h1l-5%2020%201%201%204-2-8%2011-1%204%207-5v2l5-2%208-3%205-2%204%201-7%203-18%208h-2v2l-3%203h-5l-2%203c-7%201-7%201-14-1l-2-3%202-1%202-8%203-3%201-3h2v5l5%201%202%201-1-2-1-15%202%201%202%209%202-1-2%208h3l1-4%205-17%202-6z'/%3e%3cpath%20fill='%236b627a'%20d='M63%2085h3l2%202%203-1%202%201v6h3l-1-6h4l2%205h6v-5l4%201%201%205%203-1v3l2%201h-4l-7%201-12%201H62v-3h-2l1%203-16%203-4%201q-14%203-29%203v-2l18-2v-2l8-1%202%201v-2h6l5-2%208-2v-7l4%201z'/%3e%3cpath%20fill='%233d3f55'%20d='m175%2040%205%203v3l4-1%201%201v10l2%201v4l6%203%203%205%204%203c1%206%201%206-1%2011l-5%201-6-6q-5-7-12-9l-2-2%201-3h2c3-4%203-4%204-9l-7-6z'/%3e%3cpath%20fill='%23a7b4e4'%20d='m59%2035%2015%206v32h-2l-3-7-9-1z'/%3e%3cpath%20fill='%23c7daf8'%20d='M184%2022v4h3l1-2c2%204%202%204%202%209l-2%202v16l4%201c3%204%203%204%204%2011l-9-1-1-3%201-2-3-1V46h-4l-2-4-3-2-2-5-1-1v-7h2v-2z'/%3e%3cpath%20fill='%23f9d7bf'%20d='m59%20161%201%204h13v21l-1%208H59z'/%3e%3cpath%20fill='%237c99d9'%20d='M288%2046c4%204%204%204%205%208l6%201-1-3%203%201v3q10%202%2019-4v16l-10%202%201-4h-3l-1%203c-7-1-7-1-11-4l-5-2c-3-3-3-3-3-10z'/%3e%3cpath%20fill='%23f29f85'%20d='M240%20261h3l1%209%201%205v14l-4%203-1%203-11%202v-3l-6%202c-1-16-1-16%201-19l8-1%203%206%203%201v-5l1-2v-6l1-5z'/%3e%3cpath%20fill='%234b5d8b'%20d='m208%20133%204%203h6l3%205%204%201q1%209-2%2017l-1%205h-2v-2h-3v2h-2l-7-8-3-3%203-4-2-2zM283%200h16l-19%2016-13%2014-6-10%201-2h2l2-4%206-7%203-3c4-4%204-4%208-4'/%3e%3cpath%20fill='%2369362f'%20d='m187%20375%209%203v-3c8%200%208%200%2013%203l3%205-18%205-6%202-9%202v2l3%201-12-1%201-4v-4q0-4%205-7l5%202-1%203%204-2h7l-4-5z'/%3e%3cpath%20fill='%23bd7272'%20d='M276%2018h2l4%2038%201%205v12h3l2-4v11h-10l-4-31v-5c-2-21-2-21%202-26'/%3e%3cpath%20fill='%23c7daf8'%20d='m130%2089%202%203%207%202-1%202h-3v2l-9-1%201%206-4%202-2-1-1-3-12-2-3-1v2l-3-1%202-1-2-5h-5l-1-3h7l1-2%208-1c8-1%2011%200%2018%202'/%3e%3cpath%20fill='%23f08b7b'%20d='M132%20212h1v54l-4-5-3-2v-40l-4%205-9%209h-2l-1-9%202%203%205-5h2l2-4%204-2%201-3%201%204h2l2-4z'/%3e%3cpath%20fill='%236b627a'%20d='m309%2086%208%201h3v6l-5%201-10%203v5h-11l-1%204c-7-2-7-2-10-5%202-5%202-5%206-9l2%201v-4l5-2v2l7-1h4l1%202z'/%3e%3cpath%20fill='%234b5d8b'%20d='M252%20183h38l-2%209-6%202-3-2-4%202-1-1v1l-19-4-16-3v-3q6-2%2013-1'/%3e%3cpath%20fill='%23d2c3c8'%20d='m135%20102%2023%205%201%2010-10%201-2%204-4-1h-8z'/%3e%3cpath%20fill='%23c7daf8'%20d='M90%2025h4v2l4%201%204%201h3l5%201%205-1%202%203c5%203%205%203%2012%203l1%203h-8l-4%201q-7%201-15-1H88l-2-1v-2l-5-1-1-7%206%202z'/%3e%3cpath%20fill='%2369362f'%20d='M18%20413v2l-4%203%2010-1%206%203-4%201v2l3-1-1%204h-6l2%204%201%204-5%203q-7-3-7-5l-8-2v-2l5%201v-2l4-1%203%202-1%204%202-1v-5l2-1q-3-2-7-2v-2l-5%202-8%201v-12q9-3%2018%201'/%3e%3cpath%20fill='%23c7daf8'%20d='M320%20242v5q-7%206-17%208v3l-5%201-5%203h5l-3%204h-6v-2h2v-2h-8l-1-6%204-2%201-3c4-3%204-3%2010-3q9%200%2018-5z'/%3e%3cpath%20fill='%23d2c3c8'%20d='M139%20287h2l3%2017%203%203c4%204%204%204%205%209l1%204%207%203q3%207%202%2013h-7l-2%201-1-5q-3-15-13-25l2%203c3%206%203%206%202%2010l-2-5-5-7%202-10h2l-2-7z'/%3e%3cpath%20fill='%23e5b5b3'%20d='M206%20290h1l2%206%203-1%204%204-2%201v5l-1%204%201%203h-2l-1-4-4%203c-4%204-4%204-8%205v2l-3%203h-2c-2-14-2-14-1-19l8-4v2l7%201-2-4z'/%3e%3cpath%20fill='%233d3f55'%20d='m290%20219%202%206-12%206-5%203-7%202-2-2-3%203c-18%202-18%202-23-1l-1-8%2033%202v-2h6v-2l8-4z'/%3e%3cpath%20fill='%23d2c3c8'%20d='m89%2069%204%203v9l3%2011-4%201-2-5-3-1v5l-6%201-2-6-2-1%201-6v-8c4-3%204-3%2011-3'/%3e%3cpath%20fill='%234b5d8b'%20d='m314%20489%201%202h5v16h-24c2-7%202-7%206-11h2v-2h3v-3l6-1z'/%3e%3cpath%20fill='%23d2c3c8'%20d='M67%200h7v31l-12-3c1-23%201-23%205-28'/%3e%3cpath%20fill='%23482b2b'%20d='M0%20456q13%202%2022%208%206%204%2013%205v1l-35%202z'/%3e%3cpath%20fill='%23b298b0'%20d='M45%20101v36l-2%208-4-1-2-12v-15l-1-13z'/%3e%3cpath%20fill='%23e5b5b3'%20d='M272%2023h1l1%209%201%205v14h-2l-1-2-4%208h-1v-9l-4%201-2-1c-1-10%201-14%208-21z'/%3e%3cpath%20fill='%23b298b0'%20d='M256%200h23l-6%207-5%206-4%205h-2l-2%204-1%202h-2z'/%3e%3cpath%20fill='%23bd7272'%20d='M184%200h28l-1%2019h-2v-2l-11-5-4-5-10-6z'/%3e%3cpath%20fill='%23e5b5b3'%20d='m13%209%207%204%201%209v23l-9%201z'/%3e%3cpath%20fill='%23482b2b'%20d='M308%20400h2l-7%2011-1%202%205-2v-2l6-3%205-3%202%201v13l-3-1-1%202-5-1-10%201-1-3-2%205-4%202-1-3v3l-3-1%207-11%203%202%201-5h2l1-3z'/%3e%3cpath%20fill='%23a7b4e4'%20d='m177%20103%207%203v3l4%202%201%204%205-1%201%202-1%202%204%201%205%202%201%204%205%202%205%203%201%205%202%201-5%201-4-3-4-1c-4-3-4-3-5-8l-8-2c-3-3-3-3-4-10l-4-1v-2l-5-1-3-3v-2z'/%3e%3cpath%20fill='%236b627a'%20d='m250%20462%202%201v16h2l-1-4h2v-5h2l1-5%201%202h3l1%204%203%202-2%204v3l-6%204c-6%207-5%2015-5%2023h-2l-1-4-6-4%203-1%203%202v-9l2-1%201-8-2-1v-5l-2-1z'/%3e%3cpath%20fill='%234b5d8b'%20d='m82%20328%2030%209%203%205q-1%202-7%203v-2q-7-2-14-1l-1-5-3-3v3c-5-1-5-1-8-5z'/%3e%3cpath%20fill='%233e3139'%20d='M105%200h5l8%209%2013%2010%208%205%204%203%203%202v3l1%203q-25-11-42-33z'/%3e%3cpath%20fill='%23482b2b'%20d='m246%20476%201%202-1%202%203%201c2%203%202%203%202%2010l-2%201-9-4-21-3q13-8%2027-9'/%3e%3cpath%20fill='%23b298b0'%20d='M320%20158v15l-7%201-1%202v-2h-4c-5%200-5%200-9-3l5-8%209-2z'/%3e%3cpath%20fill='%23bd7272'%20d='M169%20296v9h2c1%203%201%203-2%2010l4-5%208-6q-5%208-11%2014l-4%2015-1%206-1%205-1%205h-3l3-22%201-19%202-3z'/%3e%3cpath%20fill='%236b627a'%20d='m288%20115%209%203v5l2%205-5%205%201%207c-2%203-2%203-8%205z'/%3e%3cpath%20fill='%2369362f'%20d='M320%20344v12l-6%202v-3q-9%200-17%204l-2-1%202-2-2-2%201-3%205-1v-2c14-4%2014-4%2019-4'/%3e%3cpath%20fill='%23a7b4e4'%20d='M221%20485q17%200%2030%207v9l-4-1%204%203v4h-15v-3l3%201%202-5%204-6-2-2-6%201-1-4h-5l-10-2z'/%3e%3cpath%20fill='%23b298b0'%20d='M320%20221v12c-7%206-7%206-12%206%201-4%201-4%206-10l-5%203-3-1-4%206-3-1v-2l-5%201v-5q9-5%2019-6z'/%3e%3cpath%20fill='%236b627a'%20d='m250%20278%206%201v5l-2%201%201%202-1%205q5%203%2012%202l1%204h-3l-1%203-1-2-2%202-3%203h-2l-1%206h-2v-3h-2l4-5-3-5-2-6-3-1-2-10%201%203%203%201%201-2h3v-2h-2z'/%3e%3cpath%20fill='%23bd7272'%20d='m110%20239%201%2013h-2l1%203-7%201v2l4-1%204%201-1%202c-7%200-10%200-17-3l10-14h2l1-3z'/%3e%3cpath%20fill='%236b627a'%20d='m223%20398%201%202h2l-1%203h-3l-1%202-5%202-2%202c1%205%201%205%206%209l2%201v3l-6-1-9-1v-2l-4-1%204-5%204-7-3%201v-4l4-1%201%201%202-3%205%201z'/%3e%3cpath%20fill='%23c7daf8'%20d='M298%20109c8%202%208%202%2010%204v5l2%201v6l-4-1-1%203-3-1-1%204q-5-5-6-12l-1-4z'/%3e%3cpath%20fill='%233d3f55'%20d='M289%200h10q-9%209-19%2015c-4-4-4-4-5-8l-2-1q6-8%2016-6'/%3e%3cpath%20fill='%23b298b0'%20d='m275%20279%202%201%201%205-2%203-1%205q-4%200-6-4l-3%203%201%202h-2l-1%202v-2l-7%201-4-2%201-7-1-2%204-1-1%204h2l2%204v-2h3l2-6%206-2z'/%3e%3cpath%20fill='%23f29f85'%20d='M280%2098q6%205%207%2015l1%201v16l-1%205v11l-3-1v-5l-3-26z'/%3e%3cpath%20fill='%23b298b0'%20d='m141%200%203%201%201%203%2011%203v9l1%205%202%209q-8-5-12-14l-2-4z'/%3e%3cpath%20fill='%234b5d8b'%20d='M282%20156c12%2010%2012%2010%2013%2015h2l-1%204-4%202q-9-6-16-15zm-115-56%209%203%201%204%206%203%201%202%203%201v3l-6%202v2l-6%202-6-7c1-7%201-7%205-11l-5-1-2-1z'/%3e%3cpath%20fill='%23f29f85'%20d='m109%20118%202%201v33l-6-1v-19c0-10%200-10%204-14M0%20104h2l1%2024v19l-1%209v41H0z'/%3e%3cpath%20fill='%23e27459'%20d='M131%20493q11%203%2019%2011v3h-19z'/%3e%3cpath%20fill='%23a7b4e4'%20d='m287%20476%208%205%207%201v4h-5l-2%205%203%201-2%202-2-4-3-1-3%203-3%203%202%201v3h-2c-3-5-3-5-2-9l1-4%201-4z'/%3e%3cpath%20fill='%23b298b0'%20d='m245%20286%201%204%204%201c4%209%204%209%204%2013l-3%202v5l-5-1v2l3%201v2l-9-2%203-1v-2h-2l2-5%203-1%201-3-5-2-1%202v-5l5-4-1-1z'/%3e%3cpath%20fill='%23c7daf8'%20d='M289%20143h4l-1%205-3%201-2%204c-7%207-7%207-11%208l-1-3h-3l2-10%209-2z'/%3e%3cpath%20fill='%23a7b4e4'%20d='M136%2029q13%207%2023%2018l-24-6z'/%3e%3cpath%20fill='%23d2c3c8'%20d='m284%2038%202%203%202-1v18c0%2011%200%2011-2%2015h-3l-1-8-1-5V49l3-2-2-6z'/%3e%3cpath%20fill='%236b627a'%20d='M132%20390v3h6v4h-3v2c-14%203-14%203-17%202l-4%202-1-4%204-1%202-6h5c3-2%203-2%208-2'/%3e%3cpath%20fill='%23b298b0'%20d='M12%200h8v5l5%202%203%202%208%205%2011%208%203%201-1%203C23%2015%2023%2015%2017%206z'/%3e%3cpath%20fill='%236b627a'%20d='M18%20413v2l-4%203%204%202-4%201-11%203H0v-12q9-3%2018%201m207-45%201%204-2%201%203%201%201%203%206%202-1%204-4-1h3v-2l-14-1%204%201-1%203-4%201v-3l-3-1v-5h-3q4-9%2014-7m39-299q9%206%2016%2015l-5%206-4-1-1-3-3-1v-2h-3z'/%3e%3cpath%20fill='%23a7b4e4'%20d='m215%20500%208%207h-35q6-4%2012-5zm105-179v22l-4-1-5%201%201-4-1-1c0-8%200-8%203-13z'/%3e%3cpath%20fill='%236b627a'%20d='M320%20144v14l-4%202-2%202-10%202q2-7%207-12l3-4q4-5%206-4'/%3e%3cpath%20fill='%23a7b4e4'%20d='M288%2082c2%202%202%202%202%2010l-8%208-6-6v-2l-3-1%202-1%202-4%204-1%207%205-1-7z'/%3e%3cpath%20fill='%234b5d8b'%20d='m240%20236%204%201h16l3%208h-13l-9-2z'/%3e%3cpath%20fill='%2369362f'%20d='M67%20340h6l17%2023-1%202c-10-4-16-15-22-24z'/%3e%3cpath%20fill='%23b298b0'%20d='M2%20104c5%204%205%204%206%2010v11l-1%206v5H5l-1-4H2z'/%3e%3cpath%20fill='%236b627a'%20d='M282%20239h1v8l5-2h4v2l2%201-3%202-8%206v9l-2-1v-5h-2v-2l-3-1%201-4%204%201-2-7v-6l1%202h2z'/%3e%3cpath%20fill='%23b298b0'%20d='m7%20409%2011%201%201%202h2v-2c7-1%207-1%2012%201l-4%204h5v2q-6%204-14%201l-1%201h-6l3-4h2q-5-4-12-5zM117%201l1%202%2010%201v13q-11-4-16-15z'/%3e%3cpath%20fill='%236b627a'%20d='m126%20403%209%201%201%203h-3v2l-12%203-1-4v4c-12%200-12%200-15-2h3v-2h5l4-2%209-1z'/%3e%3cpath%20fill='%234b5d8b'%20d='m242%20169%205%202%207-2h5v2l-6%201%205%203-1%202h-7l-6%202h-5l-2-4%203-1v-4z'/%3e%3cpath%20fill='%23d2c3c8'%20d='m172%20327%201%203%208%202%207%203v2l2%201q-12%201-25-2l1-6h6zM98%2073h4l1%204h2c2%204%202%204%201%2010l2%201h-4l-1%203-6-1z'/%3e%3cpath%20fill='%234b5d8b'%20d='M1%200c10-1%2010-1%2017%205l2%204%206%204%201%203q-7%200-12-5l-4-3-4-3-6-4z'/%3e%3cpath%20fill='%23e5b5b3'%20d='m38%20140%202%204%203%201%201-3v19q1%206-2%207h-2q-2-7-2-16z'/%3e%3cpath%20fill='%23b298b0'%20d='m173%206%207%202v15l-5%202-1-5h-3l-2-4%205%201-1-3z'/%3e%3cpath%20fill='%23f08b7b'%20d='M20%200h13l1%2012q-8-1-14-7z'/%3e%3cpath%20fill='%23b85952'%20d='m62%20459%203%203-14-3q-19-5-40-4v-1q26-6%2051%205'/%3e%3cpath%20fill='%23e5b5b3'%20d='m21%20337%201%202-8-1%201%206h-2v-3h-3v4l-10-2v-4c7-7%2012-5%2021-2'/%3e%3cpath%20fill='%233d3f55'%20d='m109%20287%206%205q-1%207-5%2013l-2-4h-2l-2-8%202-2h-3l1-3zm170-44%202%2010h-4v5l-3%201c-4-6-5-7-4-15zm-140%2042q2%206%200%2012h-14l-3%201-1-2%204-2%204-7%205%201h3z'/%3e%3cpath%20fill='%23b298b0'%20d='m136%205%207%2014%203%206%202%204q-7%200-12-6z'/%3e%3cpath%20fill='%234b5d8b'%20d='m135%2096%2013%202v6l-14-2-8-1v-4l9%201z'/%3e%3cpath%20fill='%233d3f55'%20d='m295%20235%202%2012-3%201-2-1v-2l-9%202v-6c9-6%209-6%2012-6'/%3e%3cpath%20fill='%23e5b5b3'%20d='M205%2093c10%2013%2010%2013%2010%2016l2%201-3%203h-7z'/%3e%3cpath%20fill='%23e27459'%20d='M89%20495v12H75c8-12%208-12%2014-12'/%3e%3cpath%20fill='%23b298b0'%20d='M184%200h16l3%208h-2v4h-3l-4-5-10-6z'/%3e%3cpath%20fill='%23bd7272'%20d='M299%20432h1l-5%2020%201%201%204-2-8%2011-3%2010h-2l4-16%201-4%202-4z'/%3e%3cpath%20fill='%23e5b5b3'%20d='M2%20132h2l1%204h2v22q-6-8-5-17z'/%3e%3cpath%20fill='%23bd7272'%20d='m126%2022%2010%206-1%2012-5-1q-3-8-4-17'/%3e%3cpath%20fill='%234b5d8b'%20d='m267%20251%203%204q-12%206-25%201l1-4%205%203v-2h5l3-1h3zM201%2077h4c3%206%203%206%202%2011l-2%204c-5-3-5-3-8-9l2-2z'/%3e%3cpath%20fill='%23a7b4e4'%20d='M256%200h5v16c0%205%200%205-2%208h-2z'/%3e%3cpath%20fill='%23e5b5b3'%20d='M150%200h28l2%204h-8l-4%201-10-2h-4l-4-2z'/%3e%3cpath%20fill='%23bd7272'%20d='m259%20392%2011%207%204%201v2l-10-3h-5l-4-1-1-2h-4l-1-3z'/%3e%3cpath%20fill='%233e3139'%20d='M303%20328q-4%205-12%207l-1%202-7%201c1-6%201-6%205-9z'/%3e%3cpath%20fill='%23f29f85'%20d='M126%20213h1q-1%2010-10%2016l-4%204h-2l-1-9%202%203%205-5h2l2-4%204-2z'/%3e%3cpath%20fill='%23e27459'%20d='m0%20149%202%201v47H0z'/%3e%3cpath%20fill='%23e5b5b3'%20d='m153%20321%207%202c2%204%202%204%202%2010l-8%201z'/%3e%3cpath%20fill='%2369362f'%20d='M258%20401q9%201%2015%207l-2%207h-3l-5-8z'/%3e%3cpath%20fill='%234b5d8b'%20d='m250%20278%206%201v5l-2%201%201%202-3%204-6-1-2-10%201%203%203%201%201-2h3v-2h-2z'/%3e%3cpath%20fill='%23b298b0'%20d='M95%2092c7%201%207%201%2010%203l-1%203h-2l-1%203-4-1-8-1-3-1v-2l9-1zm164%20146h2l4%206h4v-5l2-1-1%206c0%209%203%2013%208%2021l-1%202-7-10-11-18z'/%3e%3cpath%20fill='%233e3139'%20d='m289%2028%2012%202-3%204h-2l-2%204-3%203h-2z'/%3e%3cpath%20fill='%23f29f85'%20d='M129%20101h5l1%208v7l-6-1z'/%3e%3cpath%20fill='%236b627a'%20d='m226%20351-1%203c-9%203-14%203-23%200l1-2h5l3-1zm-100-25h2l4%2011%205-2%201%208h-4l-1%202v-2l-4-1-1-3h2l-2-5z'/%3e%3cpath%20fill='%233d3f55'%20d='M131%2022q9%202%2016%208l-1%203%201%202q-8-3-15-9z'/%3e%3cpath%20fill='%2369362f'%20d='M208%20403v3h-4l-9%202h-6v2c-12%200-12%200-17-2h6l19-4%205-1z'/%3e%3cpath%20fill='%23d2c3c8'%20d='M136%20307q6%202%208%209l-1%204-2-5zm21%2026h5v3h-6z'/%3e%3cpath%20fill='%237c99d9'%20d='M301%20327v1h-8c3-2%203-2%208-1'/%3e%3cpath%20fill='%236b627a'%20d='m34%20347%203%201h-3zm3%202%203%201h-3zm3%202%202%201Zm68-4%202%201-5%201zm13-249h3v2h-3z'/%3e%3cpath%20fill='%237c99d9'%20d='M103%20364h2l-1%203z'/%3e%3cpath%20fill='%234b5d8b'%20d='M102%20366v3Zm16-18%203%201h-3z'/%3e%3cpath%20fill='%23a7b4e4'%20d='m139%20297%202%201-1%202z'/%3e%3cpath%20fill='%2369362f'%20d='M286%20282h2v2h-2z'/%3e%3cpath%20fill='%236b627a'%20d='M88%2075h2v2h-2zm-7%200h2v2h-2z'/%3e%3cpath%20fill='%233e3139'%20d='M65%2071h2v2h-2z'/%3e%3cpath%20fill='%23a7b4e4'%20d='m190%2062%203%201h-3z'/%3e%3cpath%20fill='%236b627a'%20d='m139%20303%202%202h-2z'/%3e%3cpath%20fill='%23b298b0'%20d='m310%20266%202%201-2%201z'/%3e%3cpath%20fill='%23c7daf8'%20d='m58%2092%202%202h-2z'/%3e%3cpath%20fill='%234b5d8b'%20d='m177%2029%202%201Zm7-5%202%201Z'/%3e%3c/svg%3e",
	steps: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='507'%3e%3cpath%20fill='%23c01f47'%20d='M0%200h320v507H0z'/%3e%3cpath%20fill='%23398550'%20d='M41%20259q6%204%207%2011l3-2c5-1%205-1%208%201q3%205%203%2010l1%203v23l1%2017%203-2q9-3%2017%201l2%201h2l-1-2-1-3-1-2q0-4%203-8h3l2-4%201-2h3q3%205%203%2010h3l1%2015%203-5%203%201v-2h2v2h4v4l4-1v17l5%201%202%201%201-5h4v-3q1-5%203-5h9l1%2010v9l-1%204%2063-1%201-5h-3l-30%202h-5l-19-2q7-3%2014-2h29l2-1h12q3-8%202-17%200-6%204-11l9%201q5%201%2010-2h2l2-4%203%203v4l9%201-2-1v-2h3l7-2%206%202q4%204%204%209v5l6%201v9l-2%201%201%203%202%2015v2l1%206%202-1q5-3%209-2%205%203%206%207l-1%2021v2l-3%2013h8v-2l3-4h6v-3q1-9%207-16c3-2%203-2%208-2v126H0V291l13%201v-13q-2-10%205-17%2011-7%2023-3'/%3e%3cpath%20fill='%23fc5165'%20d='M73%200h247v339l-8-3q-10-3-19%202l-6%206h-2c-1-9-1-9%201-13l6-5h2l2-6q-3%200-5%202l-2%202-2%201-1%202q-2-1-2-6l-1-3-3-1v-4l3-2v-21l-1-22v-6l-3-74v-11q0-2%202-3l2-1%202-1v-19h2l7-1%203-1%207-2%202-8%206-3%203-7-3%201-27%206h-2a1492%201492%200%200%201-139%2018v-2h3l102-13v-2h-2l-76%2011h-2l-6%201h-3l-7-1%203-2q-3-2-7-1l-5%201-5%201h-6l-16%202v2h-7v-2h-2q-22%204-43%203%209-4%2018-3l43-5%209-1h4l7-1h4q6-2%209-8%203-7%202-14v-7q0-13-10-23-8-8-18-9l-2-1-1-3-3-2-1-3q-4-4-10-3v-3q0-22-10-43l-2-5h-2v-4l-3-1v-2h-2q-4-2-7-6-5-4-11-5h-4l-2-1zm197%20135h-4l-4%201-4%201-9%201%201%202%2032-4v-2z'/%3e%3cpath%20fill='%23f74661'%20d='M169%20166v23l-1%203h-6v2l2%201-2%201-2-1v-2h-27l-1%203-1-1H97v13l1-2h3v2l23-1h4l84-3h3l49-1%201%20116-5-3-6%201h-7v2l3%201h-11l-1-3h2l-3-4-1%202q-6%204-12%205l-4-2h-6q-4%209-3%2017%200%206-3%2011l-15%201h-2l-39%201%2012%201h9l10-1h25v5l-4%201h-60v-23h-9l-2%206v5l-1-3-4%201-1%204-7-2v-17l-4%201v-4h-4v-2h-2v2h-2l-2%201-2%206h-1v-18h-3l-3-10h-3l-1%202-2-32v-27l-1-10v-38l5-3%201-4v-14l51-7h3l8-1h3z'/%3e%3cpath%20fill='%23f5db8a'%20d='m237%20312%203%203v4l9%201-2-1v-2h3l7-2%206%202q4%204%204%209v5l6%201v9l-2%201%201%203%202%2017%201%206%202-1q5-3%209-2%205%203%206%207%203%2026-10%2047h3l2%203h2l3%203%201%206h-4v2l5%203%202-1%202%2012-4%202h-7l-6-1h-6v3h-6l-1%203-5-1v-2l-2%201-13%203v2h-5v2h2q28-4%2056%201l8-1v5q-11%203-23%202h-11l-5%201-5-1h-60l-42%201h-14l-39%201h-4l-12%201H84v-2l-3%201-14-1v-6l30-1h7l33-1h15l6-2h5v3l76-2-6-3h-2l-4%201v-2l-5-1h-2l-7%201%201-4-3%202-6%201-2-1v-3h-2l-3%201-2%201h-8l3-2-7%201v-2l-3%201-9%201q-5%200-8%202l-1-2h-4l-3-1H66v-4l12-1h3l15-1%202-5h2v5h3l18-1h45l-1-3c-1-4-1-4%201-9H96v-6l13-1h7v-2l-2-1%201-2-2-1%206-8%203%201%203-1%205%203v-2l1-2%204-1%204%203%203-5-3%201v-3l-5-1v-7l3-2%201-5v-5l2-8h-3l-5-3v-3h-2l-1-2h-5l-2-4-2-1%201%204-1%2016-15%201%201-2-2-5-1-8v-2q0-8%202-15l5-2%202-4%204-2%204%2012h5v-11h2l1-5h4v-3q1-5%203-5h9l1%2010v9l-1%204%2063-1%201-5h-3l-30%202h-5l-19-2%2014-2h29l2-1h12q3-8%202-17%200-6%204-11l9%201q5%201%2010-2h2z'/%3e%3cpath%20fill='%23fd6873'%20d='M135%200h185l1%2048v30c1%2018%201%2018-4%2024l-9%208-6%206-7%206v2l-20%204-7%201h-3l-3%201h-8v-3q-1-5-6-8-7-5-6-13v-7q0-8-7-14-7-5-15-8-7-4-10-12-5-10-17-13l-14-2q-5%200-9-5v-6l1-12h-2l-5-9v-3h-3v-3l-2-1-8-3-2-1-6-1-4-4z'/%3e%3cpath%20fill='%23f74661'%20d='m264%20203%201%20116-5-3-6%201h-7v2l3%201h-11l-1-3h2l-3-4-1%202q-6%204-12%205l-4-2h-6q-4%209-3%2017%200%206-3%2011l-15%201h-2l-39%201%2012%201h9l10-1h25v5l-4%201h-60v-23h-9l-2%206v5l-1-3-4%201-1%204h-2v-11l4-1%201-4h2l3-5%2015-15%209-9%2013-13%204-3%204-2v-2h2l1-2q5-7%2012-13l7-6%2010-10%209-9%208-7%206-6%2010-9%205-5%202-2%203-3q3-5%209-4'/%3e%3cpath%20fill='%23ac273f'%20d='M313%20131h2q0%205-3%208l-6%202-1%209-8%201-3%201h-2l-2%201h-5l1%2019-6%203%204%20138h-4v4l4%201%201%207%204-2%203-4%202-1%203%201q-1%205-6%209l-3%202q-4%206-3%2014l2-2q8-8%2019-8c11%202%2011%202%2014%205v42l-3%201q-6%201-9%207l-2%209v5h-7l-1%202-2%203h-8v-3c4-28%204-28%201-37l-9-2-6%203v-4l-1-5v-3l-3-15%203-1v-9h-7q-3-39-2-79v-50l-52%202q-1-3%202-5l2-2q5-3%205-6l3-1h-38v-24l1-3%206-1h4l4-1%205-1%2011-1%2017-2%208-2h4l4-1h6l3-1%201-2h2l2%202%203-1%201-2%208-7%202-1v-3l-2-2h2l9-2h4q11-4%2022-5'/%3e%3cpath%20fill='%23561c30'%20d='M282%20134v2l-13%202-3%201h-4l-3%201h-9l-1-2%2021-3%203-1zm-33%205v2a821%20821%200%200%201-105%2013v2h2l10-2h5l60-7%2040-6%204-1%2013-1%201%205-3%201-2%202-2%201-2%201v3l-8%202v-2h-2l-1%203-6%201h-2l-23%204-8%201-33%204-1%2026h11l28-1-1%202h-3v2q-2%204-5%206l-2%202q-11%204-21%204h-20l-64%202h-2l-7-1-3%201v-13l21-1h11l3%201%201-2h27v2h3l-1-3%206-1%201-25-10%202-10%201-3%201-8%201-12%201h-2l-28%203v14l1%202-1%202-3%201q-2%202-2%206v29l1%207v15l1%2018v32l-2%206h-3l-2%2010%202%201%201%204-6-1-9-1h-6v-2l1-26v-7l1-44v-3l1-13v-9l1-6-3%201H54q-2-7-2-15%203-2%205-1h3l3-1h9v-16l-7%201H52v-2l-3-6-6-1q-5-3-8-8l-2-7%207%202v2h2v2l3%201%202%201%2011-1h5l8-1h5l16-3h5v1l12-1h-8v-1l126-16h3l6-1z'/%3e%3cpath%20fill='%23398550'%20d='M320%20381v126h-99l-68%201h-4q-3%200-5-4l-2-3-5-4-2-1-6-4q-4-2-5-7h4l8-2%204%201%2010%201h5v2l7-1%202-1%203%202v-2l14-1%206-1%201%202h2l3-1%203-1%2010%201%207-1c7%200%207%200%2010%202l5-1%208-1h11l19-1v2c15%202%2015%202%2022%200l1-2q1-3%206-4l4-2%201-3h-69l-14%201-108%201H86l-4-2-3%201-1-2-10%201-1-4%2017-2v2h2l28-2h9l16-1h45l26-1h52l8%201h3l18-1%2018-1v-5h-2l-2%201-3%201-4-1-8-1h-47v-2h5v-2l15-4%201%202h4l2-2%201-1%204%201v-3h16l6-1-1-10-4-1-4-3%201-3%204%201-1-5-2-1v-2h-4l-1-4h-3l5-12%209%201%201-4q2-2%205-2h3v-3q1-9%207-16c3-2%203-2%208-2'/%3e%3cpath%20fill='%23fd6c74'%20d='M320%2098v241l-8-3q-10-3-19%202l-6%206h-2c-1-9-1-9%201-13l6-5h2l2-6q-3%200-5%202l-2%202-2%201-1%202q-2-1-2-6l-1-3-3-1v-4l3-2v-21l-1-22v-6l-3-74v-11q0-2%202-3l2-1%202-1v-19h2l7-1%203-1%207-2%202-6v-2l6-3%203-6%201-4%201-3%201-3%201-3h-2l-14%203-3%201-6-1%202-2%2013-13c8-9%208-9%2011-9'/%3e%3cpath%20fill='%23c01f47'%20d='M169%20166v23l-1%203h-6v2l2%201-2%201-2-1v-2h-27l-1%203-1-1H97v13l1-2h3v2h4l29-1%203-1q11%200%2019%209l1%203%203%201c6%207%204%2017%204%2025h2v2h-2l-2%204-3%203-2%202-2%202-3%202-23%2022-8%207-20%2020-4-4v-3h-3l-1%202-2-32v-27l-1-10v-38l5-3%201-4v-14l51-7h3l8-1h3z'/%3e%3cpath%20fill='%2337393e'%20d='m261%20321%201%208q0%2013%205%2024v8h2l-1%204-1-1q-1%205%201%209l3%204h2l-1-4%204-1%203%2012%204-1%202%205-2%201-1%205%201%204-2%207%204%202q-3%2012-13%2017-4%203-6%208-2%204-6%205l-1-3v2l-1%202-4%201-7%202-9%201h-2l-15-1-4%201h-6l-2-4-5-2%201-18v-4l2-6h2v-5h-2v-10l2-14q3-6%202-13l1-5v-3l1-5v-3l2-6v-21q6%201%206%204%200%204-3%207l2%201h2l3%201%204%203q12%201%2022-5l3-1-1-3q0-4%202-7%201-2%206-2'/%3e%3cpath%20fill='%23c98475'%20d='M68%20447h18l13%201h93l-1%202%2012-1%201%203h2l8-2-1%204%202-1q6-2%2012%201v2l2-1h7l4%203q-3%202-8%201h-2l-8%201h-59l-1-2h-5l-2%202h-25l-32%201H67v6h10v1l-9%202v2h2l3-1h5l2%202%203-1%201%203h3l137-3h33l43%201-1%204-4%202q-6%202-6%204l-1%202-4%201h-9l-6-1q-5-2-12-2h-2l-37%201-11%201-6-1-11%202h-2l-2-2-5%201h-14v2l-2-1h-3l-2%202-5-1v-2l-3%201-12-1h-15l2%203v3l2%201q11%204%2017%2013v2H74q2-6%206-9%205-5%205-11l2-1-11-1h-3l-14%201-4-2q-1-6%202-10l2-3%205%201q2-6-1-13v-8q2-3%205-4'/%3e%3cpath%20fill='%23fd6c74'%20d='m264%20203%201%20110h-3l-4-5q-13-9-29-10l-5%201-2-1v2l-9%202-3-10h-2v-2l-1-3-4-1-4-4q-6-6-14-7%203-6%208-9l3-3%202-2%205-5%207-6%209-8%2016-16%2010-9%205-5%202-2%203-3q3-5%209-4'/%3e%3cpath%20fill='%2397bb5a'%20d='M41%20259q5%203%206%208l2%2013v22l1%2021h-2v2l2%201v40l-1%206h-6l3-2v-3H17v-7l30-1v-2l-3-1h3l-1-3%201-6-22%201v2l-8-1v-2l12-1%2018-1-1-5-29%201-1-10%2026-5%201-2h3v-3l-4%201H19l-4-1v10h-1v-5l-14%201v-36l13%201v-13q-2-10%205-17%2011-7%2023-3'/%3e%3cpath%20fill='%23fd6c74'%20d='m286%20172%201%2016%2014-1-2%2014-6%201h-6l1%203v7l1%202v11l2%2027v16l1%205v2l1%2010%207-8%203-3%202-3%203-3%204-2%201-2%207-7v82l-8-3q-10-3-19%202l-6%206h-2c-1-9-1-9%201-13l6-5h2l2-6q-3%200-5%202l-2%202-2%201-1%202q-2-1-2-6l-1-3-3-1v-4l3-2v-21l-1-22v-6l-3-83v-2q0-2%202-3l2-1z'/%3e%3cpath%20fill='%2397bb5a'%20d='M94%20301h3q3%205%203%2010h3l1%2015%203-5%203%201v-2h2v2h4v4l4-1v17l5%201%201%207-1%203v2l-6%201-3-12-7%205-2%202h-2v27l3%201-1%202-1-1-1%203h4l11-1v-9l-1-9%201-2%204%202v3l5-1%201%203h2l1%202q3%203%207%204l-1%206v7l-1%203q1%202-3%204v7h5v3h2l-1%204-3%202-1-3h-5l-2%204-3-1-7-1-3%203-2%202v5l1%203-20%201v6h-1v-3l-4-89-4-15v-4l-1-3v-6l2-3h3l2-4z'/%3e%3cpath%20fill='%23981839'%20d='M0%20221c18%200%2032%202%2045%2014l2%202q11%2010%2015%2025%202%206%206%208%203%202%202%205v41q0%203-4%205l-3%202-1-21v-20l-1-3v-3l-2-7h-6l-5%202-1-2q-2-6-8-10-11-1-21%203l-2%204-1%202-1%207-1%203v14l-13-1z'/%3e%3cpath%20fill='%2337393e'%20d='M251%20490h24l26%201v9h-4q-5%200-8%202l-4%205h-28l-9%201h-93l-9-1-4-6-5-4-7-5%206-1h3l5%201h9l6-1h3l24-1z'/%3e%3cpath%20fill='%23f74661'%20d='m262%20155%201%204v29h-2q-4%201-6%205h-3v-3h-9l-7%201%202%202-4%201h-5l-2-2%201-1h-42v-23l1-4%206-1h4l4-1%205-1%209-1%2012-2%209-1h4z'/%3e%3cpath%20fill='%23981839'%20d='M318%20337q3%205%202%2011v33l-3%201q-6%201-9%207l-2%209v5h-7l-1%202-2%203h-8v-3c4-28%204-28%201-37q-4-2-9-2l-6%203q-2-7%202-15l7-7%203-3q13-15%2032-7'/%3e%3cpath%20fill='%23fd6873'%20d='m300%20473-1%204-4%202q-6%202-6%204l-1%202-4%201h-9l-6-1q-5-2-12-2h-2l-37%201-11%201-6-1-11%202h-2l-2-2-5%201h-14v2l-2-1h-3l-2%202-5-1v-2l-3%201-12-1-8-1v-7l-4%203h-3v-2l-17-1v-2l114-3h34z'/%3e%3cpath%20fill='%23e43652'%20d='m319%20119-3%2012q-5%203-11%203l-3%201-18%203-27%204-9%202-63%209-41%203v-2h3l102-13v-2h-2l-76%2011h-2l-6%201h-3l-7-1%203-2q-3-2-7-1l-5%201-8%201h-3l-6%201h-2l-8%201v2h-7v-2h-2q-22%204-43%203%209-4%2018-3l32-4%2019-2%207-1%2028-2%2034-4%2066-11%209-1%206-1zm-49%2016h-4l-4%201-4%201-9%201%201%202%2032-4v-2z'/%3e%3cpath%20fill='%23fd626e'%20d='m244%20204-3%206h-3v3h-2l-1%203h-2q-3%202-5%206l-5%203-2%203-1%202h-2q-4%202-6%207l-3-1v4h-4q-7%204-9%2011h-3l-1%202q-2%205-7%208l-4-1v-2q-1-4-6-6v-2l-8-2q0-6%206-10l3-2%202-2%202-2%203-1v-2l4-3%2012-12%203-3%203-4-4-2%2016-2z'/%3e%3cpath%20fill='%2337393e'%20d='M208%20465h94l-2%208h-83l-118%202H86l-4-2-3%201-1-2-10%201-1-4%2017-2v2h2q12-3%2025-2h12l19-1h41zm-43-16-1%202%202-1%206-1%2012-1h8l-1%202%2012-1%201%203h2l8-2-1%204%202-1q6-2%2012%201v2l2-1h7l4%203q-3%202-8%201h-2l-8%201h-59l-1-2h-5l-2%202h-25l-16%201H67v-12h27l12-1z'/%3e%3cpath%20fill='%23675d56'%20d='M215%20323q6%201%206%204%200%204-3%207h2q8%202%2012%208v4h-4v3l-3%201-1-2-4%201q-2%203-2%207l1%202%203%201v2l2%201v2l-6%201%203%209-3%201v-2h-2v7l3%203q4%204%206%209l5%203%202%202%205-1v4h3l-1%208-6-1-1%204h-4l-1-9-1-1-8%205%202%207h-2l-2%201-1%203h2v2l5-1%201%203%203-1h8l1%208%201%202-2%201-4%204-4%204-8-1%201-5-5-2%204%209-1%202h-6l-2-4-5-2%201-18v-4l2-6h2v-5h-2v-10l2-14q3-6%202-13l1-5v-3l1-5v-3l2-6z'/%3e%3cpath%20fill='%23f5db8a'%20d='M160%20457h3v3h3l33-1h33l6-1h35c20%200%2020%200%2028%202l8-1v5q-11%203-23%202h-11l-5%201-5-1h-60l-42%201h-31l-15%201h-11l-12%201H84v-2l-3%201-14-1v-6l30-1h7l33-1h15zm77-145%203%203v4l9%201-2-1v-2h3l7-2%206%202q4%204%204%209v5l6%201v9l-2%201%201%203%202%2017%201%206%202-1q5-3%209-2l5%205v5l-3-6q-4-2-9-1l-3%205-3%201v4l-7-6-1-6%203-4-1-1v-3q0-7-4-14-3-11-2-23-6%202-6%204v8l-2%201-3%201-3%202-5%202c-11%202-11%202-16-1l-3-2-6-1%202-3%201-5q-2-3-5-4l1%2013q2%208-3%2015l-2%204-3-3v-4h-3l-30%202h-5l-19-2%2014-2h29l2-1h12q3-8%202-17%200-6%204-11l9%201q5%201%2010-2h2z'/%3e%3cpath%20fill='%23398550'%20d='m14%20278%201%203h31l-1%204H28l14%201h3l1%202-9%201H15v7h4l27-1%201%209v15l-20%201H15v-9l-1%203-1%203-8%201%201%202H4v2H2l-1%202%201-5-2-1v-27h8l5%201z'/%3e%3cpath%20fill='%23e43652'%20d='m286%20172%201%2016%2014-1-2%2014-6%201h-6l1%203v7l1%202v12l3%2052v22l1%203v10c0%207%200%207-2%209l-1%202-2%202-2%201q-2-1-2-6l-1-3-3-1v-4l3-2v-21l-1-22v-6l-3-83v-2q0-2%202-3l2-1z'/%3e%3cpath%20fill='%23675d56'%20d='M301%20480v11H183l-3%201h-46l-7-1-3-6h4l8-2%204%201%2010%201h5v2l7-1%202-1%203%202v-2l14-1%206-1%201%202h2l3-1%203-1%2010%201%207-1c7%200%207%200%2010%202l5-1%208-1h11l19-1v2h22l1-2z'/%3e%3cpath%20fill='%23f74661'%20d='M193%20205h2l12%201-2%201-1%202q-2%204-6%207l-3%203-2%202-3%203-4%202-1%203h-2v2l-4%203-6%206-2%202-2%202-2%201-3-1v-8l-1-2-1-11-2-1-1-3-2-2-1-1v-2l-2-1-9-5v-1l22-2z'/%3e%3cpath%20fill='%23c98475'%20d='m209%20350%202%204%202-3v9l-1%206c-2%2020-2%2020-8%2026l1-19-61%201v-7h36l8-1h7l8-1h-13v-1l-45-1-1-6%2040-1h24z'/%3e%3cpath%20fill='%23675d56'%20d='m265%20350%203%204-1%207h2l-1%204-1-1q-1%205%201%209l3%204h2l-1-4%204-1%203%2012%204-1%202%205-2%201-1%205%201%204-2%207%204%202q-3%2011-12%2017l-2%201-3-1q1-4%205-6l-2-4h-2v-2l-4%201-1-2h2v-3l2-1%201-3h2l1%202%201-2h2v-2h-4l-2-4-3-1v6h-2v-3h-2v-2l-3-3-2-1-1-3-2%201-5%202-2-4%209-6q4-3%205-8l2-2%201-3-1-2-2-5%202-3v-4q0-4%202-7'/%3e%3cpath%20fill='%23f74661'%20d='M169%20166v23l-1%203h-6v2l2%201-2%201-2-1v-2h-27l-1%203q-2-3-2-7l1-3%201-4%201-9%201-3%207-1h2l7-1%205-1z'/%3e%3cpath%20fill='%23398550'%20d='M310%20458h2v15h8v34h-35l7-8h8l1-19-6%202h-6l3-3%202-1q6-1%206-4l1-5%202-5h6z'/%3e%3cpath%20fill='%23f5db8a'%20d='M205%20473h28v1h-16c-9%200-9%200-13%203l-3%206-6%202-4%201h-3l-2-2-5%201h-14v2l-2-1h-3l-2%202-5-1v-2l-3%201-12-1-8-1v-7l-4%203h-3v-2l-17-1v-2z'/%3e%3cpath%20fill='%23f74661'%20d='M319%20293h1v46l-8-3q-10-3-19%202l-6%206h-2c-1-9-1-9%201-13l6-5h2l2-6-2-3%203-2%205-5h2l1-3%202-1%201-3h3l2-4h2l2-4z'/%3e%3cpath%20fill='%23c01f47'%20d='m182%20265%202%201v8l-2%205h-2v2l-3%203-12%2011-2%202-31%2032-2-1-1%205h-3l-1%2010-5-1v-17h2v-2l2-2%208-8%207-7%202-2%2010-10%209-8%202-1v-3l5-4%207-6z'/%3e%3cpath%20fill='%23fd6873'%20d='m87%20486%202%201%201%202q2%206%207%208l4-1h4l6-2h12v-2l1-2%202-1v2h2q11%204%2018%2014v2H74q2-6%206-9%205-5%205-11z'/%3e%3cpath%20fill='%2337393e'%20d='M96%20430h70l-1%207%201%205-66%201v-5l-4%201zm86%2019%2010-1-1%202%2012-1%201%203h2l8-2-1%204%202-1q6-2%2012%201v2l2-1h7l4%203q-3%202-8%201h-2l-8%201h-59l-1-2-7%201-9%201-4-1h-3l5-6%202%201v-3q9-2%2019-2l-1%202%202-1%207-1z'/%3e%3cpath%20fill='%23ac273f'%20d='M168%20387h35v10q0%203-2%205l-8%202v2l-3-1v-2l2-1h-28l-7%201v-2h-9l-1-13z'/%3e%3cpath%20fill='%2337393e'%20d='m53%20382%208%201%201%2017v9l1%2012v2l1%206v15q1%207-2%2014l-9-1-1-22v-3l-2-1h2v-4l-1-13v-22l2-5%201-3-2-1z'/%3e%3cpath%20fill='%2397bb5a'%20d='M41%20259q5%203%206%208v15l-32-1-1%208h-1v-12q-1-8%205-15%2011-7%2023-3'/%3e%3cpath%20fill='%23f5db8a'%20d='M286%20367q4%202%204%205v3h2q2%2024-10%2044h3l2%203h2l3%203%201%206h-4v2l5%203%202-1%201%207h-13l-1-11-2%204-3-3-2-2-1-6%202-1%202-5%204-7v-5l-2-1v-2l1-3v-2l-1-5v-2l3-4-1-4-4%201v-2l-1-3v-2l-2-5%201-4q5-2%209-1'/%3e%3cpath%20fill='%23fd6c74'%20d='M261%20156h2v32l-5%201-3%204h-3v-3h-9l-7%201%202%202-4%201h-5l-2-2q0-4%202-6l2-1%206-6%204-2v-2l3-3%202-2%204-1%201-2q2-4%206-6l2-3z'/%3e%3cpath%20fill='%2397bb5a'%20d='m65%20448%202%201v18h10v1l-9%202v2h2l3-1h5l2%202%203-1%201%203h20q-9%2011-22%2011l-14-1-9%201-4-2q-1-6%202-10l2-3%205%201q2-6-1-13v-8z'/%3e%3cpath%20fill='%23c98475'%20d='M207%20395h1v7l2%201-1%205h-2l-1%204-2-3-1%204-54%201-1-10h40l5%202v-2h10l1-8%203%201z'/%3e%3cpath%20fill='%23675d56'%20d='M16%20409v35l-16%201v-35q8-2%2016-1'/%3e%3cpath%20fill='%2397bb5a'%20d='M49%20381c7%2011%203%2037%203%2050h-2l-1%205H39v2H26l-1-7q3-4%208-5h9l2%201h6v-2l-2-1h2l-1-4-19-1%201-4h-2l-1%202v-3l7-1h14v-6h-7v-1h7z'/%3e%3cpath%20fill='%23398550'%20d='m143%20484%201%201h11v2l7-1%202-1%203%202v-2l14-1%206-1%201%202h2l10-1v7h-16l-5%201h-45l-7-1-3-6h4c10-2%2010-2%2015-1'/%3e%3cpath%20fill='%23c98475'%20d='m202%20429%201%2013h-37l-2-10%205-3h6l11-1z'/%3e%3cpath%20fill='%2397bb5a'%20d='M20%20465h31v15l-31%201%201-2-1-1v-9l4-2z'/%3e%3cpath%20fill='%23981839'%20d='M313%20131h2q0%205-3%208l-6%202-1%209-4%201-6%201h-3l-5%201-6%204v-6l-2-1%202-4%2011%201v-4l-13%201-1-4-2-2h2l9-2h4q11-4%2022-5'/%3e%3cpath%20fill='%23c98475'%20d='m205%20376-1%207-20%201h-37l-1-7z'/%3e%3cpath%20fill='%23e43652'%20d='m95%20222%202%201%201%207v15l1%2044-6%202-1-9v-59l3%201z'/%3e%3cpath%20fill='%2337393e'%20d='m128%20466%201%205%201%203-14%201H90c-6%200-6%200-8-2l-3%201-1-2-10%201-1-4%2017-2v2h2l25-2h6z'/%3e%3cpath%20fill='%23c01f47'%20d='M152%20146h4l1%203q-9%204-20%205h-7l-4%201-17%202h9v1l-25%202-1-1h-3l-7-3v-3l9-1h2l17-1v2h7v-2l-2-1h3l9-1%204-1h6l4-1z'/%3e%3cpath%20fill='%23675d56'%20d='m156%20466%2013-1h3c5%200%205%200%208%203l3%205-36%202-20-1%202-1v-2l-2-1%201-3zm-25-96%201%201%208%204-1%206v7l-1%203q1%202-3%204v9h-2v-2l-7%201v-3h-2l1-3-2-6%201-5v-7l-2-2%201-4%203%201zm144%2078h7l3%201-1%209h9l3-1%202-3%205%201%201-4h2v3l5-1-1%208-1-2h-2l-2%201-3%201-4-1-8-1h-47v-2h5v-2l15-4%201%202h4l2-2%201-1%204%201z'/%3e%3cpath%20fill='%23981839'%20d='M29%2077q5%201%209%204l15%209%206%205h2q4%202%206%205l2%202%202%201-2%205-9-4-2-1-5-4-1-1h-2q-5%200-8-4l-7-4q-4-1-6-6l-1-6z'/%3e%3cpath%20fill='%23c98475'%20d='m144%20342%202%202-1%202q15%205%2029%203l7-1h27v5l-4%201h-60z'/%3e%3cpath%20fill='%23981839'%20d='m87%20486%202%201%201%202q3%207%2010%209l3%201%202%201v7H74q2-6%206-9%205-5%205-11z'/%3e%3cpath%20fill='%23675d56'%20d='m153%20449-6%203-1%203h-2l-4%203%2013%201v1h-26l-2%201q-5%200-9-3l-2-3-4-2%202-2-1-2z'/%3e%3cpath%20fill='%23fc5165'%20d='M320%20257q3%208-1%2014l-10%209-5%205-10%2011-2%202-1-17%202%204%2010-11%202-3%203-3%204-2%201-2c1-2%204-7%207-7'/%3e%3cpath%20fill='%23c98475'%20d='M215%20474h24l1%203-4%201%204%203q-2%204-6%204h-7l-9-1-11%201h-4l-2-2q0-3%204-7%204-3%2010-2'/%3e%3cpath%20fill='%2337393e'%20d='M64%20492h12l8%201-7%2010-3%204H63l-2-2-7%201v-13z'/%3e%3cpath%20fill='%23981839'%20d='M50%20155h18l4-1h10v2l6%202q-4%204-9%204h-5l-5%201h-8l-5%201-12-1-2-4h-2l-1-2-5-1v-1l7-1h3z'/%3e%3cpath%20fill='%2397bb5a'%20d='m90%20352%201%2013-8%202h-5l-2%201-6-1%202-1-4-3%201%204-3%202%202-16z'/%3e%3cpath%20fill='%23398550'%20d='M259%20430v6l-3%203h-2l-7%202q-7%202-15%201h-6c-8%200-8%200-10-3q-2-3-2-8l5%201%201%204-1%202h8l5-6%204-3%205%203%201%209h2v-7l5-1v-2q5-3%2010-1'/%3e%3cpath%20fill='%23561c30'%20d='M96%20430c21-2%2021-2%2026%202q3%204%203%2010l-25%201v-5l-4%201z'/%3e%3cpath%20fill='%23c98475'%20d='M320%2098v30h-3l2-9-4%201-6%201-6%201-3%201-6-1%202-2%2013-13c8-9%208-9%2011-9'/%3e%3cpath%20fill='%23398550'%20d='m303%20464%204%201-3%201v2l1%2039h-20l7-8h8l1-19-6%202h-6l3-3%202-1q6-1%206-4l1-5z'/%3e%3cpath%20fill='%23ca2146'%20d='m281%20136-1%202q-18%205-36%207h-3l-97%2011v-2h3l99-13h3l1-2h6l17-3z'/%3e%3cpath%20fill='%23c98475'%20d='m279%20418%206%201%202%203h2l3%203%201%206h-4v2l5%203%202-1%201%207h-13l-1-11-2%204-3-3-2-2-1-6%202-1z'/%3e%3cpath%20fill='%23f74661'%20d='M319%20293h1q2%207-2%2012l-4%205-4%208-2-1-5%207q-6-1-9-7l3-2%205-5h2l1-3%202-1%201-3h3l2-4h2l2-4z'/%3e%3cpath%20fill='%23561c30'%20d='M275%20179q2%207-2%2012l-7%207-2%202q-3%203-7%203h-8q2-5%206-8l1-2h3l1-3%206-4%205-5z'/%3e%3cpath%20fill='%23398550'%20d='M33%20258q8%200%2012%205l1%201h-3l1%204-27%201%205-7c8-4%208-4%2011-4'/%3e%3cpath%20fill='%2337393e'%20d='m306%20465%203%201%201%2041h-5l-1-31v-10z'/%3e%3cpath%20fill='%23e43652'%20d='M127%20491q12%204%2019%2014v2h-21l2-1z'/%3e%3cpath%20fill='%23fd6c74'%20d='M239%20445v3l8%201-3%204%202%201%202%201v2h-5v2q-4%200-6-3-4-2-10%200v-2l-4-1%201-3%206-2%201-3zM134%20146h6l-1%202-5%201h-3l-3%201h-3l-8%201v2h-7v-2h-2q-22%204-43%203%209-4%2018-3z'/%3e%3cpath%20fill='%2337393e'%20d='M320%20451v22h-8l-1-22z'/%3e%3cpath%20fill='%2397bb5a'%20d='m84%20321%202%203%202%202v10l-9-1-3-7-1-2%201-5h-2l-8%201%201-2q9-3%2017%201'/%3e%3cpath%20fill='%23ca2146'%20d='M301%20187v6l-1%203-1%205h-12v-13z'/%3e%3cpath%20fill='%23ac273f'%20d='m285%20334%201%2011-7%207q-4%203-5%208h-1v-3l-1-3v-4l-2-8%203-1v3l4-3%202-2%204-4z'/%3e%3cpath%20fill='%2397bb5a'%20d='m83%20433%203%201v4l4-1%201%204%204%201q-4%203-10%202l-3%201H67l-1-3%201-2%206-1%203%202v-2l1-3%202-1%203%201z'/%3e%3cpath%20fill='%2337393e'%20d='M319%20424h1v20l-7%201-2-2h4v-2h-4v-14h3l4-1z'/%3e%3cpath%20fill='%23675d56'%20d='M0%20473h17v7q-4%202-10%202H4l-1%202H0z'/%3e%3cpath%20fill='%23c98475'%20d='m94%20386%207%202c4%2010%204%2010%202%2014l-3%202v4l-5-2-1-5z'/%3e%3cpath%20fill='%23fd6873'%20d='M237%20396v4h3l-1%208-6-1-1%204h-4v-14z'/%3e%3cpath%20fill='%23675d56'%20d='M304%20498h1v9h-20l7-8q6-2%2012%202z'/%3e%3cpath%20fill='%23398550'%20d='M259%20430v6l-3%203h-2l-11%203%201-8%205-1v-2q5-3%2010-1'/%3e%3cpath%20fill='%23c98475'%20d='M260%20379h1l1%205%206%201v3l-4%202-4-2-1%203h-2q-5%200-8%203l-2-4%209-7z'/%3e%3cpath%20fill='%2397bb5a'%20d='M111%20477h15l-1%203h3l1-3h3l2%205h-2l1%203q-7%202-14-2l-8-5z'/%3e%3cpath%20fill='%2337393e'%20d='M320%20383v13l-11%201c0-7%200-7%202-10zM96%20431h7v10l2-10%204%201v8l-1%203h-8v-5l-4%201z'/%3e%3cpath%20fill='%23561c30'%20d='m316%20377%202%201v2l2%201-3%201q-6%201-9%208l-1%202h-5v-6h2l1-2%201-2h3v-3q2-4%207-2'/%3e%3cpath%20fill='%2397bb5a'%20d='M284%20433c7%201%207%201%2010%203l2-1%201%207h-13z'/%3e%3cpath%20fill='%23f5db8a'%20d='M168%20401h25l-3%203h-32q4-4%2010-3'/%3e%3cpath%20fill='%23fd6c74'%20d='M318%20301q0%205-3%208-4%204-5%209l-2-1-5%207-4-1q0-3%202-5l2-2%203-3%203-3%202-2z'/%3e%3cpath%20fill='%2397bb5a'%20d='M304%20451h2v3l5-1-1%208-1-2-2%201q-8%202-17-1l6-2%202-3%205%201z'/%3e%3cpath%20fill='%23e43652'%20d='M84%20493h1l1%2014H74l6-10%202-2z'/%3e%3cpath%20fill='%2397bb5a'%20d='M310%20423v11q1%203-2%205l-2%202-7-4%208-1v-9h-8v-3z'/%3e%3cpath%20fill='%23fd6c74'%20d='M189%20416h4l3%201%205%202-1%203h-7l2%201v2c-6%202-6%202-9%201l-2-1%202-4%203-1z'/%3e%3cpath%20fill='%2337393e'%20d='M195%20432v6l-4%202v2h-13l2-1%201-4-1-2%209%203v-2l1-3z'/%3e%3cpath%20fill='%2397bb5a'%20d='m120%20362%204%202v3l5-1%201%203%202%201q-2%205-8%205l-1-1-2%202v-4l-1-3-1-5z'/%3e%3cpath%20fill='%23fd6873'%20d='M286%20367q4%202%204%205v7l-1-2h-3l1-4h-2v2h-3l-1-2h-4l-1-3q4-4%2010-3'/%3e%3cpath%20fill='%23981839'%20d='M87%20207h1v23h-2l-3%203q-2-6%201-13l-1-9%202%201h1z'/%3e%3cpath%20fill='%23fd6c74'%20d='M273%20225h3v9l-1%205-2%201-2%203h-2v-14h3z'/%3e%3cpath%20fill='%2337393e'%20d='M291%20413h5v6l-9%201-2-1h-3l1-4q3-2%208-2'/%3e%3cpath%20fill='%23675d56'%20d='M309%20402h11v7l-10%201z'/%3e%3cpath%20fill='%23c98475'%20d='M273%20482q5%201%208-1h8l-1%204c-15%202-15%202-22-1v-2z'/%3e%3cpath%20fill='%2397bb5a'%20d='M9%20409h7v4l-10%201H0v-4q5-2%209-1m7-18h1v10H3l-1-3%209-3h5z'/%3e%3cpath%20fill='%23675d56'%20d='M255%20336h2l1%202%204-1q2%207-2%2012l-4-3-2-9z'/%3e%3cpath%20fill='%23981839'%20d='M285%20329v5l-5%205-3%203-4%202q0-6%205-10l3-3z'/%3e%3cpath%20fill='%23675d56'%20d='M0%20467h9l8%201v3l-17%201z'/%3e%3cpath%20fill='%23c98475'%20d='M289%20391q0%209-4%2016l-4-2c2-14%202-14%208-14'/%3e%3cpath%20fill='%23f5db8a'%20d='m208%20388-1%209h-2l-1%209-1-2h-6l1-3%204-1v-4l3-6z'/%3e%3cpath%20fill='%23398550'%20d='m214%20431%205%201%201%207-1%202q-4-3-5-7z'/%3e%3cpath%20fill='%23f5db8a'%20d='m204%20363%203%201q-5%203-11%203v-2h3z'/%3e%3cpath%20fill='%23675d56'%20d='m232%20434%204%201v1h-5z'/%3e%3cpath%20fill='%2397bb5a'%20d='M94%20399h1v6h-1z'/%3e%3cpath%20fill='%23675d56'%20d='M136%20368h2v2l-3-1zm-12%200h4l-1%202z'/%3e%3cpath%20fill='%23f5db8a'%20d='M205%20379v3Z'/%3e%3cpath%20fill='%2397bb5a'%20d='m106%20378%202%201-1%202z'/%3e%3cpath%20fill='%23f5db8a'%20d='m188%20450%202%201Z'/%3e%3cpath%20fill='%23398550'%20d='m88%20442%202%201Z'/%3e%3c/svg%3e",
	sunset: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='507'%3e%3cpath%20fill='%23df8a72'%20d='M0%200h320v507H0z'/%3e%3cpath%20fill='%23c2643f'%20d='M0%200h320l1%2096v81c0%2014%200%2014-3%2017l-4%202-2%201v9q-5-9-5-18l3%203%201-2%202-3h2l-1-3h-4l-1-4-5%207-3%201-2%202h-13l-1-3q-13-45-53-67-42-20-87-7-49%2016-76%2061l-5%2012-8-3%201-2q2-6%201-12l-4-2-2-1-1-6q-2-6-6-10l-8%202-2%201-4-3H21v-9l-11%204q3-9%209-15l3-1%203-2q5-3%2010-1%207%200%2012-4l12-3%202-1%208-1q0-9-4-18l-5-1-3%201c-5%200-5%200-8-2q-4-3-7-9-3-3-7-4l-2-2h-5l-4%204-7%203q-7%203-9%209l-1%204q-2%206-7%2010z'/%3e%3cpath%20fill='%23314e72'%20d='M31%2080q3%200%205%203l3%201q5%202%208%208l4%205%206-1c6%200%206%200%209%202q5%208%203%2018l-3%201c-19%205-19%205-22%208h-9q-7%200-15%204-6%206-9%2014l3-2%204-2%204%201v9l2-1c6%200%206%200%209%202l2%201%205-2%205-1%203%204%202%203q3%204%202%2010h2l5%203q1%206-1%2012l-2%202%202%201q11%204%2014%2016l6%2020q1%2012-6%2020c-6%209-6%209-11%2011l-11%201-7%201q-11%203-20-1%203%208%209%2013l2%204h7l11%201v2h2q5%201%207%205v2h2l2%204%202%203%201%203%202%206%202%202%203%207q4%205%201%2012l-9%2021-2%201q-3%205-8%209l-2%203q-2%205-8%206l-22%2013%206%204q8%203%2014%209l2%201q4%203%205%208l3%204%2012%201h3q9%200%2016-4%2014-4%2028%202h2l2-7h15v6h2l9%201%202%202%206%202%205-2%2017-4%206-1h10l4-1h14l-1-5%2010-4%206%203%206%202-4%207%203-1q4-2%2010-2h7l-3%208-2%208v5l-4%201-4%202-3%201-4%201-3%202h-6q-9%200-16%206h-14l-11%201h-58l-35-1v2l-2%209%206-2-3-4h25l59-2%2028%201q-2%203-5%204h-3l4%202-1%203q-2%204-2%209l-4%2014q-2%2010%201%2019l1%203q3%2015%2016%2023l4%202v1H0V114q1-7%206-11l1-6q3-8%2012-11%205-4%2012-6'/%3e%3cpath%20fill='%23fed46a'%20d='M251%20131q26%2022%2035%2054v4l2-1h5c8%200%208%200%2011-3l4-7%202%201%201%203%204%201-1%204-2%202-2%202-1%201-1-1-1%202-3-2v4l-1%204-3%201-1%202-5-3-3-2-3-2v17l-12%201%202%205-11%201q-8%201-14%205l2%201%203%203%202%201q7-1%2011-7l7-3%204%201-3%202q-7%204-8%2013l8-3%202-1h2l2-1%205-3c-1%208-3%2011-8%2019l26-1v4h-18a235%20235%200%200%200-61%201l-2%201h-3q-61%203-120%2020l-3%201-11%204-8%202c-8-7-16-22-17-32l3-4c10-12%2010-12%209-20-2-11-5-26-12-35l-2-2%202-5%203-6%201-3q8-13%2018-23l1-2q23-24%2055-34l4-1c36-10%2074-5%20104%2020'/%3e%3cpath%20fill='%23763a5a'%20d='m66%20247%201%203q6%2014%2015%2027h2l2-1%202-1h9l-2%2013v3l-4%2036h-2v2l4-2%2012-4h-3v-19l5-31h29l9%201-6%2030-2%209%2021-6h3l5-2-1-3%201-4v-3l1-3v-3l4-13h9l8%201-1%203-3%2020%202-1%201-4%201-3v-3l1-5v-3l3-4%202%201v4l1-3%2019%201%207%202h3l10%202%203%205%2012-1%2021-4%2012-1%2018-1v3h-2q-13%204-24%2014h10l-1%202-2%203-2%203-4%207q16-3%2025-15l1-2h2v4l2%2012-7%204h-2l-1%203-4%203-1%202-2%201c11%201%2011%201%2016-3h3l-2%206-5%201q-9%202-16%208l15-1-5%205-2%203q-7%206-15%2010h-2l-1%203h-2l-2%204q-4%208-13%209h-33l-15%201h-61l-81%201H38q-7%200-14-4l11-8%201-2%2013-6q6-2%209-9l2-2q11-12%2015-27l1-2c2-8-3-14-7-20-6-11-6-11-6-15h-2l-4-5-5-2v-2h-4c-12%200-12%200-17-3l-4-6-2-3q-3-3-3-7l2%201q11%203%2021%200l13-2z'/%3e%3cpath%20fill='%234c7aba'%20d='M31%2080q3%200%205%203l3%201q5%202%208%208l4%205%206-1c6%200%206%200%209%202q5%208%203%2018l-3%201c-19%205-19%205-22%208h-9q-7%200-15%204-6%206-9%2014l3-2%204-2%204%201v9l2-1c6%200%206%200%209%202l2%201%205-2%205-1%203%204%202%203q3%204%202%2010h2l5%203q1%206-1%2012l-2%202%202%201q11%204%2014%2016l6%2020q1%2012-6%2020c-6%209-6%209-11%2011l-11%201-7%201q-11%203-20-1%203%208%209%2013l2%204h7l11%201v2h2q5%201%207%205v2h2l2%204%202%203%201%203%202%206%202%202%203%207q4%205%201%2012l-9%2021-2%201q-3%205-8%209l-2%203q-2%205-8%206l-18%2011-2%201-2%201-5%201-12-1H0V121l-1-2q1-10%207-16l1-6q3-8%2012-11%205-4%2012-6'/%3e%3cpath%20fill='%23a14648'%20d='M0%200h249c-2%207-2%207-4%209l-10%205-3%201q-12%206-25%204v3l-5%201v-3l-2-1-1%203-1-2-4-1-6%203-1%204-2-1h-2l-4%204-4%201-9%204-19%207q-21%206-38%2020-7%207-17%208v2l-6%203c-8%204-8%204-11%208q-1%2010%205%2017l2%205-4%204h-3v2h-5l-1-2-1-3-1-3-4-5-6%201c-5%200-5%200-8-2q-4-3-7-9-3-3-7-4l-2-2h-5l-4%204-7%203q-7%203-9%209l-1%204q-2%206-7%2010z'/%3e%3cpath%20fill='%23b75b45'%20d='M249%200h34l1%206h-2v3l-3%201-8%204-2-1-3%202h-5l-1%202q-3%203-7%202v3l-2%201-2%201-1%203-1%203q-6%203-12%202v3l-4%202-11%208-5%202-2%202-8%204-2%201-5-1v3h-2c-11%203-11%203-15%208l-2%204h11l1%204-2%203h-2l-1%203-8%201h-2l-5%201v2h-4q-6%200-10%204-3%203-3%208l1%203%205%202%201%209h-2q-18%205-35%2013l-2%201q-15%207-27%2019l-3%203q-18%2017-28%2041l-8-3%201-2q2-6%201-12l-4-2-2-1-1-6q-2-6-6-10l-8%202-2%201-4-3H21v-9l-11%204q3-9%209-15l3-1%203-2q5-3%2010-1%207%200%2012-4l12-3%202-1%208-1%201-6h5v-2l6-2q0-6-5-11-3-6-2-13l4-2%201-2q2-3%206-5l3-1%204-1v-2l7-4q8-3%2015-8%2014-12%2032-16l15-6h2l11-6h2l5-3%204-2%202%201-1-3%204-3%203-1%202-1%203%202%205%201v2l3-1-1-2h8q13-1%2024-7l3-1%204-2z'/%3e%3cpath%20fill='%235696d4'%20d='m254%20415%203%202c7%203%2016-1%2023-3q12-5%2023%201%209%205%2012%2014l2%206q5%2011%203%2024v48l-86%201c-14%200-26%200-38-10q-9-13-11-29l-1-3%202-9%202-12c1-8%208-17%2013-23q7-4%2014-4l15-4q12-5%2024%201'/%3e%3cpath%20fill='%234c7aba'%20d='M6%20367h5q9-1%2017%203l2%201%202%201%203%202%2010%207%203%202%205%207%202%204%2012%201h3q9%200%2016-4%2014-3%2028%202h2l2-7h15v6h2l9%201%202%202%206%202%205-2%2017-4%206-1h10l8-1h10l-1-5%2010-4%206%203%206%202-4%207%203-1q4-3%2010-2h7l-3%208-2%208v5l-4%201-4%202-3%201-2%201h-2l-3%202h-6q-9%200-16%206h-11l-69%201h-3l-35-1v2l-2%209%206-2-3-4h25l55-2h4l28%201q-2%204-5%204h-3l4%202-3%207-3-1q-6-3-12-2h-2l-9%201-1%203-2-1-13-1h-2q-7-1-12%203l-1%202-7-1-3-4-5-3c-9%201-9%201-12%203l-3%202-2-1-12-1-2-1q-6%200-10%203l-2%203q-7%206-16%208l-2%201a23%2023%200%200%201-21-1l-2-1-5-3v-6l-7-14-1-2%202-3%203%201%201-2%206-1-1-3-7-23-5%201-2-5-5%206v-3H9v-2H7v2l-1%203v3l-2%204%201%206%201%203v3h5l2%203-1%203H5v-4H3l-2%204H0v-52q1-4%206-3'/%3e%3cpath%20fill='%23a95a5a'%20d='m66%20247%201%203q6%2014%2015%2027h2l2-1%202-1h9l-2%2013v3l-4%2036h-2v2l4-2%2012-4h-3v-19l5-31h29l9%201-6%2030-2%209%203-1h3l5%206%201%202%204%206%201%202q13%2020%2018%2043l-92%202H38q-7%200-14-4l11-8%201-2%2013-6q6-2%209-9l2-2q11-12%2015-27l1-2c2-8-3-14-7-20-6-11-6-11-6-15h-2l-4-5-5-2v-2h-4c-12%200-12%200-17-3l-4-6-2-3q-3-3-3-7l2%201q11%203%2021%200l13-2z'/%3e%3cpath%20fill='%23fdc275'%20d='M191%20106v1h-6v2l1%203v3l-1%205-6%202q-5%200-9%203l-4%203-3%201-2%201-7%205-2%202h-2l-1%203-6%2012h-2l-1%202-5%206-6%205-1%202h-2l-5%2012-4%206h-2v2l-5%203-16%2012-5%203-5%2011%202%201q6%203%2010%209%203%208%202%2015h3q6%200%209%204l1%204%205-1%201-3%209-1v-3q2-5%206-8l6-3%205-4q5-2%2011-1%205%202%207%206l5%201q5%200%208%204t3%208h4q9%200%2017%205v3h-3a535%20535%200%200%200-105%2024l-8%202c-8-7-16-22-17-32l3-4c10-12%2010-12%209-20-2-11-5-26-12-35l-2-2%202-5%201-3%202-3%201-3q7-13%2018-23l1-2q23-24%2055-34l4-1q21-5%2044-5'/%3e%3cpath%20fill='%23df8a72'%20d='m274%20247%206%201h3l15%201h9l1%207-6%202v4l-6%202v6h9l-3%207v6h-2q-12%200-22%202l-18%202-19%203-9%201%204-3q-1-3-6-4l-4-1h-5l-2-1-7-1-17-2-1%208h-1l1-9-3%201-1%204-1%203v3l-1%208-1%202-3%201q-1-12%204-23l-17-1-1%206-1%207-1%204-1%203v3l-2%205%203%201-3%201-2%201-15%204-3%201-10%201h2v-2l4-21%201-4%203-12-32-1-1%202v-2l-3%201-2-1-2%2017-3%2033%206-1q-3%204-8%203l-11%204v-2h2v-3q-1-25%206-49h-5l9-5h3l3-1%2021-6%2048-9q29-4%2059-5h3l6-1%2018-1z'/%3e%3cpath%20fill='%23314e72'%20d='m220%20381%203%202%206%202-4%207%203-1q4-2%2010-2h7l-3%208-2%208v5l-8%203-3%201-2%201h-2l-3%202h-6q-9%200-16%206h-14l-11%201h-58l-34-1-2-9q-5-9-16-13l-5-3-2-1-2-1v-1h14q9%200%2016-4%2014-4%2028%202h2l2-7h15v6h2l9%201%202%202%206%202%205-2%2017-4%206-1h10l8-1h10l-1-5c8-4%208-4%2013-3'/%3e%3cpath%20fill='%235eb9ed'%20d='m42%20268%2010%201v2h2q5%201%207%205v2h2l2%204%202%203%201%203%202%206%202%202%203%207q4%205%201%2012l-9%2021-2%201q-3%205-8%209l-2%203q-2%205-8%206l-18%2011-2%201-2%201H0v-65q5%201%205%203l2%202h10l5-1%201-3-7-1q2-5%206-8h3l-1-3%205-5%201-3%203%201%206-3%203-2%203-6%204-1v-2l-9%203%202-4z'/%3e%3cpath%20fill='%235d5486'%20d='M304%20191q3%201%205%204l2%207v-5q4-4%209-5l1%20141q1%2014-7%2024l-2%201-3-1v-3h-3l-1-2-1%202h-6l-5-5-2-1q0-4%202-6l5-4-15%201q7-9%2019-10h3v-2l2-4-3%202q-8%203-17%202l3-3%201-2%202-2h2v-2l3-3%204-1%202-1-1-3v-13h-2v2q-6%2010-16%2013l-10%202q2-8%208-14h-10q9-12%2023-15h4v-2h2l-1-3q0-6%204-10h-9l-1-6q2-2%205-2h2l-1-2v-2q2-2%205-2h2l-1-3%201-8-3%201h-23l4-8%203-10-2%201-9%204-3%201-4%201q0-8%206-13l4-2q-7%202-12%206l-9%204-3-2v-2l-5-1q6-6%2015-7l10-1-1-4%207-1h5l-1-18%2012%207q4-3%204-7z'/%3e%3cpath%20fill='%23a95a5a'%20d='m66%20247%201%203q6%2014%2015%2027h2l2-1%202-1h9l-2%2013v3l-4%2036h-2v2l4-2%201%202%203%204%207%2010%201%203c11%2020%2011%2020%2011%2026l-75%201h-2q-8%200-15-4l11-8%201-2%2013-6q6-2%209-9l2-2q11-12%2015-27l1-2c2-8-3-14-7-20-6-11-6-11-6-15h-2l-4-5-5-2v-2h-4c-12%200-12%200-17-3l-4-6-2-3q-3-3-3-7l2%201q11%203%2021%200l13-2z'/%3e%3cpath%20fill='%234c7aba'%20d='M314%20427c8%2015%207%2031%206%2047v33h-96l-3%201q-9-1-17-5v-2h2v-2l4-3%202-1%202-1-4-3%204-2-1-4%203-1v-2l-8%204q1-3%204-5h3v-2l21-9v2l-4%202-2%201-2%201%203%203%204-1-2%203-2%203%202%204%204-1%201-2%202%201-1%203%206-1v-2h4l2-6h10l2-5-1-2-2%201v-3h-2v-2h-2v-2h-3c-6-6-6-6-6-10l4-1v-3l11-4%203%205%207%201-1%204%204-2%202%204-1%203h-4l1%207%203%201%2010%205v3h2l8%205%202%202%202%201v-2h2l3-1v-8l1-2-3-1v-3l-2-8%209-1v-4l-2-1%201-5h-2v-3l-2%201h-5l2-3-4-1%2010-11%204-5-4%201q5-5%206-4'/%3e%3cpath%20fill='%23e8bbb9'%20d='m260%20370-12%2016-3%203-10%201-10%202%203-7c-7-2-7-2-9-1v-3l-11%203%201%202v3q-3%202-7%201h-4l-7%201-21%202-9%201-8%204q-6%200-11-5l-5-1h-4v-6l-15%201-2%207-8-2q-15-3-28%202l-1%201H57l-4-2-1-3q-3-7-10-11l-7-6%20102-2h4l48-1h20l18-1h19z'/%3e%3cpath%20fill='%235d5486'%20d='M31%2080q3%200%205%203l3%201q5%202%208%208l4%205%206-1c6%200%206%200%209%202q5%208%203%2018l-3%201c-19%205-19%205-22%208h-9q-7%200-15%204-6%206-9%2014l3-2%206-2%202%201v11l-4%202%201%203v2l3%205q2%206%200%2012v17l-2%208q-3-1-4-6l-2-1v7h-2l-3%204q-2%204-5%204H2l1%209%205-1v3l-2%202q-4%203-4%208%205-1%208-6l1%202-6%208q-4%2014-4%2030v16H0V114q1-7%206-11l1-6q3-8%2012-11%205-4%2012-6'/%3e%3cpath%20fill='%23e8bbb9'%20d='m76%20212%201%203h2q8%200%2013%206%207%209%206%2020h3q6%200%209%204l1%204%205-1%201-3%209-1v-3q2-5%206-8l6-3%205-4q5-2%2011-1%205%202%207%206l5%201q5%200%208%204t3%208h4q9%200%2017%205v3h-3q-46%206-91%2019l-3%201-11%204-8%202c-8-7-16-22-17-32l3-4c7-9%2010-15%208-27z'/%3e%3cpath%20fill='%234c7aba'%20d='M145%20465c14%204%2014%204%2017%2010v2h3c11%200%2011%200%2016%203l3%202q4%203%205%207%205%2011%2015%2016l2%201v1H88q8-22%2030-33l14-4z'/%3e%3cpath%20fill='%235eb9ed'%20d='M28%20169h7v2l2%201%2015%207%203%201a32%2032%200%200%201%2018%2022c7%2020%207%2020%204%2027-9%2018-9%2018-16%2021l-11%201-8%201-8%201v-2l-1-2v-2l-3-3%201-2-1-6q-4-3-9-4v-5l3-1v-2h7l1-3h3l-1-4%204%201-1-3v-3l2-2v-5l-1-2%207-3%202-1%202-1%202-1%204-1%202-1%201-2-2%201c-13%202-13%202-17-2l-4-6-1-2v-6l-2%201-1-2v-2l-1-2z'/%3e%3cpath%20fill='%23763a5a'%20d='M0%200h11l1%207%202%204-2%201%201%202%206%2010%204%205q4%204%203%2010h2v3q1%2012%205%2022%204%208%200%2016l-6%202-2%202-8%204q-7%203-9%209l-1%204q-2%206-7%2010zm90%20330c8%2010%2021%2029%2021%2042l-56%201H39q-8%200-15-4l12-10%2013-6q6-2%209-9%208-8%2019-12l2-1%203-1%202-1z'/%3e%3cpath%20fill='%234c7aba'%20d='M31%2080q3%200%205%203l3%201q5%202%208%208l4%205%206-1c6%200%206%200%209%202q5%208%203%2018l-3%201c-19%205-19%205-22%208q-6%202-12%200-5%200-8%203l-4-1%202-2c10-10%2010-10%2011-17q-12%205-17%2018l-5-1%201-13-12%207q-1-8%204-14l2-2%201-6q3-8%2012-11%205-4%2012-6'/%3e%3cpath%20fill='%23b9827a'%20d='M304%20191q3%201%205%204l2%207v-5q4-4%209-5v25l-2%2010h-2l-3%206-2%203-2%206-1%203q-8%202-17%201h-9l4-8%203-10-2%201-9%204-3%201-4%201q0-8%206-13l4-2q-7%202-12%206l-9%204-3-2v-2l-5-1q6-6%2015-7l10-1-1-4%207-1h5l-1-18%2012%207q4-3%204-7z'/%3e%3cpath%20fill='%23314e72'%20d='M320%20365v74l-3-9c-3-7-4-11-11-15q-11-7-23-3l-7%202-10%202-1-4%203-1%201-3%203%201v-2l-11-5-3-1-7-6-4-3q7%201%2014%205l2%201%2010%206%203-6h2v-2l1-3%205-2q-4-9-11-16l-1-5q5%202%208%207l2%203%202%204%201-1%202-4q3-3%207-4h10q6%200%2011-4l1-3q1-4%204-3'/%3e%3cpath%20fill='%23b9827a'%20d='M193%20252c12-1%2012-1%2016%201l3%207%209%2018h-9l-7-2-5-10-7-11h-2l11%2019-2%202q-4%201-8-2l-6-11%204%2011-21-2q-27-3-52-1l-10-1%209-4%204-1%204-1h2q33-9%2067-12'/%3e%3cpath%20fill='%23763a5a'%20d='m132%20318%203%203%202%202c9%2012%2022%2032%2022%2048h-25l-2-5-3-7-1-2q-8-18-19-34%204-3%209-4l4-1%203-1%203-1z'/%3e%3cpath%20fill='%235696d4'%20d='M159%20426h3l33%201q-2%204-5%204h-3l4%202-3%207-3-1-12-2h-2l-9%201-1%203-2-1-13-1h-2q-7-1-12%203l-1%202-7-1-3-4-5-3c-9%201-9%201-12%203l-3%202-2-1-13-2H76l2-5%202%201%206-2-1-4h23l31-2z'/%3e%3cpath%20fill='%23fdc275'%20d='m282%20220-3%202q-7%204-8%2013l8-3%202-1h2l2-1%205-3c-1%208-3%2011-8%2019l26-1v4h-60l-32%201%202-7h4q7%200%2010-4h5l1-3q5-8%2013-12l8%204%201%201q7-1%2011-7%206-4%2011-2'/%3e%3cpath%20fill='%23e8bbb9'%20d='m249%20411%206%203q9%205%2018%200l12-4q14-1%2025%207%209%209%2010%2022v5l-3-6c-5-17-5-17-12-21q-14-6-29-1c-13%204-13%204-19%202l-3-2q-10-6-21-2l-7%203q-7%203-15%202l-8%204-3%202q-11%2010-12%2025l-2%209q-2%209%201%2017l1%203a39%2039%200%200%200%2011%2020l8%205%204%201%202%201v1q-8%201-15-5-12-10-14-26l-1-2q-3-9%201-18l3-13q0-6%203-10l-4-2%208-3-34-1h-3l-44%201h-2l-8%201H85l1%203-7%203%203-12h111q7%200%2012-5l10-1q9-1%2016-5%209-3%2018-1'/%3e%3cpath%20fill='%23c2643f'%20d='m66%20247%201%203%2010%2021%204%207-11%201q-6%201-10-2l-2-3-6-3v-2h-4c-12%200-12%200-17-3l-4-6-2-3q-3-3-3-7l2%201q11%203%2021%200l13-2z'/%3e%3cpath%20fill='%234c7aba'%20d='m20%20257%204%202%203%201q4%202%207%206v2h8l1%203-1%202%207-2v2l-4%202%202%202-5%203-3%202-8%204c-6%206-6%206-6%209l-4%203-5%205%206-1%201%206h-3l-9%201H7l-4-5-3-1v-5l7%201%201-3h2v-2q4-7%2011-13l1-2c-6%202-6%202-8%205l-2-1%201-2%202-3%202-3%201-2-1-2-6%2012-2-1%207-16%201-3z'/%3e%3cpath%20fill='%23a95a5a'%20d='m57%20119%202%206-6%209-1%207-1%206-4%201-1%202-2-1q-3%200-5%202l-2%201-4-2-9-1h-3v-9l-11%204q3-9%209-15l3-1%203-2q5-3%2010-1%207%200%2013-4%204-3%209-2'/%3e%3cpath%20fill='%235696d4'%20d='M0%20423q10%2014%209%2031l2%201q8%203%2012%2011l1%202%202%2014-1%201q-5%200-11-3c-4-3-4-3-14-6z'/%3e%3cpath%20fill='%23a95a5a'%20d='m191%20277%203%201v4l1-3%2019%201%207%202h3l4%201q5%200%208%203l1%203-4%204h-3l-3%201h-6l-24%204-3%201-3%201-5-1%202-10v-3l1-2%201-3z'/%3e%3cpath%20fill='%23763a5a'%20d='m106%20324%203%205%202%203%202%203%2012%2022%201%203q3%205%203%2011l-8%201h-5l-1-2q-6-17-15-32l-3-6-3-1-1-4q7-4%2013-3'/%3e%3cpath%20fill='%235d5486'%20d='M318%20477h2v30h-47l1-5h3l6-12c5%200%205%200%209%203l-6-8q7%202%2011%209l1%201%204%205q9-6%2012-17h2v-4h2z'/%3e%3cpath%20fill='%23df8a72'%20d='m114%20270%202%203h-3l-1%202v-2l-3%201-2-1v2l-2%2015-3%2033%206-1q-3%204-8%204t-11%203v-2h2v-3q0-25%206-49h-5q10-7%2022-5'/%3e%3cpath%20fill='%23763a5a'%20d='m16%20389%203%206%203%201%201-2%206%2016v2l2%209c-6%203-6%203-10%203l-10-7-5-1-3-13h2v-4l2-7h2v2h3l2-3h2z'/%3e%3cpath%20fill='%235eb9ed'%20d='m304%20285-3%208%206-5q4%206%204%2015l-2%203q-5-5-5-11h-2l-1%203q-3%209-14%2013l-12%203q2-8%208-14h-10q12-15%2031-15'/%3e%3cpath%20fill='%23a95a5a'%20d='M171%20276h9l8%201-1%203-2%2021-11%203h-2l-2%201-5-1q2-15%206-28'/%3e%3cpath%20fill='%23314e72'%20d='m289%20212%206%204-2%201v6q-1%204-6%207l-7%203-4%201-5%201q0-8%206-13l4-2q-7%202-12%206l-9%204-3-2v-2l-5-1q6-6%2015-7l10-1-1-4q7-2%2013-1'/%3e%3cpath%20fill='%23fdc275'%20d='M290%20346q5%202%208%206v2l2-1%204%201%201-3%201%203h3l1%203q5-1%207-7l2-4h1v19l-3%202-2%205-3%203h-3q-2-3-2-8l-1%201-5%203q-5-6-4-16l-2%201-2%201-3%201h-5l2-5%201-3z'/%3e%3cpath%20fill='%23314e72'%20d='M319%20224h1v46l-11-6-1%208h-2v-8l2-8-1-3q0-12%207-23l1-2%201-2h2z'/%3e%3cpath%20fill='%235696d4'%20d='M31%2080q3%200%205%203l3%201q5%202%208%208l3%204%201%203h-4l-3%201v2l-8%204-6-3-1-6-2-1-3-1V84q2-4%207-4m-8%20240%2016%208%203%202%2019%2013-5%205-2%203-9%205-4-3-1-3-5-8-1-2%201-2%208%207q-2-6-7-10l-4-8-5-3-4-3zm0-64%204%204h-2l-5-1-2%205-2%202-1%204-2%203-3%207%201%201%206-11%202%201-6%2012%203-3%202-2%204%201-4%207h-2l-2%204-3%203-1%203-3%203-7-1v-16l1%203h3l1-3%201-5v-2l4-13h1l1%205%201-2%201-3%202-3q2-5%207-3'/%3e%3cpath%20fill='%23a95a5a'%20d='m262%20449%203%205%207%201-1%204%204-2%202%204-3%204-9%201-10%201h-2q-4-4-6-10l4-1v-3l2-1%205-2zm-42-68%203%202%206%202-1%202-3%204q-4%209-12%2011h-3v-5h-4v-2h-2q0-4%203-5l1-2-1-4c8-4%208-4%2013-3'/%3e%3cpath%20fill='%23c2643f'%20d='m287%20194%202%202q9%206%2020%206l1%2013-10%201h-4c-5-1-5-1-8-4l-1-9z'/%3e%3cpath%20fill='%235eb9ed'%20d='M306%20256h3l-1%202-2%209v5h2v-9l11%206q0%205-5%209l-2%201q-3%204-7%204h-3q-2-5%201-10l2-3h-9l-1-6q2-2%205-2l1-2v-2q2-2%205-2'/%3e%3cpath%20fill='%23fdc275'%20d='m288%20289-1%208h4l1%205%205%201q-6%2010-17%2010l-5%201q2-8%208-14h-10c9-11%209-11%2015-11'/%3e%3cpath%20fill='%23763a5a'%20d='M143%20312h5l6%207%201%203q14%2023%2021%2048l-4%201-4-9q-6-25-23-45z'/%3e%3cpath%20fill='%235eb9ed'%20d='M304%20191q3%201%205%204l2%207v-5q4-4%209-5v17l-3-2-5%2011q-5-7-4-15l-8-1%202-4%201-4z'/%3e%3cpath%20fill='%23314e72'%20d='m1%20187%209%207%204%206h-2l-3%204q-2%204-5%204H2l1%209%205-1v3l-2%202q-4%203-4%208%205-1%208-6l1%202-6%208-3%2013H1z'/%3e%3cpath%20fill='%235eb9ed'%20d='M41%20148q4%200%207%203c5%209%205%209%204%2014h2l5%203v7l-2%204-5-5-3-2-3-7-1-3-4-1v-2l1-2v-3z'/%3e%3cpath%20fill='%23b9827a'%20d='m278%20381%206%207v3l-2%201-3%201-1%205h-2v2l-3%205-9-5%203-10%206-1%201-4%202%201z'/%3e%3cpath%20fill='%235eb9ed'%20d='M293%20217c0%207%200%207-3%2011l-10%205-4%201-5%201q0-8%206-13%207-5%2016-5'/%3e%3cpath%20fill='%23b9827a'%20d='M311%20312h2q1%207-3%2012l-2%201-1-3-1%201q-9%207-19%204l3-3%201-2%202-2h2v-2l4-3%203-1%203-1%206%202z'/%3e%3cpath%20fill='%23a95a5a'%20d='M149%20310c17%2014%2025%2041%2031%2061h-5v-2q-7-29-25-53l-2-4-3-1z'/%3e%3cpath%20fill='%23403657'%20d='m314%20490%206%202v15h-19v-2h2l2-4%204-5z'/%3e%3cpath%20fill='%23a95a5a'%20d='m217%20281%2011%201q5%200%208%204l1%203q-2%204-5%204h-16v-8z'/%3e%3cpath%20fill='%23b9827a'%20d='m267%20405%205%202v2h-3l-1%202%202%201h-5l1%205h-7l-3-2-14-5q0-2%205-3%209-2%2018%201v-2z'/%3e%3cpath%20fill='%235eb9ed'%20d='M318%20333q3%204%202%207%200%2010-6%2017l-2%201-3-1c-1-13-1-13%203-18l3-3%202-2z'/%3e%3cpath%20fill='%23a95a5a'%20d='M209%20344v4l3%201v2h-2l2%204q-5%203-12%201l-7-7q7-8%2016-5'/%3e%3cpath%20fill='%23763a5a'%20d='m216%20389%201%202%204%201h4q-3%206-9%209l-6%201v-5h-4v-2h-2l2-5%2010%201z'/%3e%3cpath%20fill='%23a95a5a'%20d='m157%20274%205%201-1%203-1%203v2l-3%2012-1%202v5l-2%206-4%201%204-22v-3l1-4v-3z'/%3e%3cpath%20fill='%235eb9ed'%20d='M319%20244h1v23l-11-5%204-9%204-1-2-2z'/%3e%3cpath%20fill='%23b9827a'%20d='M319%20177h1v15l-6%204-3%203%201%207q-5-9-5-18l3%203%201-2%202-3h2v-2z'/%3e%3cpath%20fill='%23fdc275'%20d='m308%20178%202%201%201%203%204%201-1%205-2%201-2%202-1%201-1-1-1%202-3-2-1%208-5%201%201-2-1-4h3l-1-7%202-1q4-3%206-8'/%3e%3cpath%20fill='%23e8bbb9'%20d='M312%20328q-11%2011-27%2011l-2-1q12-12%2029-10'/%3e%3cpath%20fill='%234c7aba'%20d='M188%20468h4v2l2%203q6%206%207%2014-3%203-7%202l-1-6h-2l-3-4%201-4z'/%3e%3cpath%20fill='%23a95a5a'%20d='m0%20154%202%204v53l-1%2022v46H0z'/%3e%3cpath%20fill='%235696d4'%20d='M121%20386h12v6h9v1l-26%201c1-8%201-8%205-8'/%3e%3cpath%20fill='%234c7aba'%20d='M235%20443c10%2010%2010%2010%2010%2014v2l3-1-2%207q-5-1-7-5-4-4-4-10l-2-4%203%201z'/%3e%3cpath%20fill='%23b9827a'%20d='M318%20477h2v15l-6-2-1%202-5%207-5%206h-2v2l-4-1%206-6%201-1q7-7%2010-16h2v-4h2z'/%3e%3cpath%20fill='%23314e72'%20d='m285%20269%2020%201-7%2011-9-7-2-2z'/%3e%3cpath%20fill='%23df8a72'%20d='M230%20188c9%201%209%201%2013%204l2%209q-5%201-9-2-4-2-6-8z'/%3e%3cpath%20fill='%23314e72'%20d='m15%20168%203%203v11l-2-1-3%201-2-2%201-5-4%202q-2-4-2-9z'/%3e%3cpath%20fill='%235d5486'%20d='M165%20422h35v1l-100%201v-1z'/%3e%3cpath%20fill='%235696d4'%20d='m26%20148%209%202h5l2-1q2%207-1%2012l-1-2-1-2-8%201-1-5h-2z'/%3e%3cpath%20fill='%23403657'%20d='M63%20475q9%209%2012%2022h-3l-3-4-2-3-2-2-1-2q-3-3-3-7l2%201zm256-234%201%203-4%206%202%202h-2l-4%203-2%207%2010%205-1%203-10-6-1%208h-2q-2-14%208-23z'/%3e%3cpath%20fill='%235d5486'%20d='m152%20491%204%202%204%2014-5-1-1-5-6-1z'/%3e%3cpath%20fill='%23a95a5a'%20d='M165%20325q4%202%205%206l1%202%201%202%201%203c12%2025%2012%2025%2012%2032h12v1h-14l-1-4-10-26-1-2-4-9z'/%3e%3cpath%20fill='%23fedb72'%20d='M290%20346q4%201%207%205v4l-7%203h-5l2-5%201-3z'/%3e%3cpath%20fill='%23df8a72'%20d='m210%20283%201%202h4l1-2v10l3%201-12%201z'/%3e%3cpath%20fill='%23a95a5a'%20d='M0%20298h9v4l6-1-2%202q-4%203-3%206-4%200-6-3l-1-2-3-1z'/%3e%3cpath%20fill='%23314e72'%20d='M299%20346h7l3%201v7h-3l-1-2-1%202h-6q-2-5%201-8'/%3e%3cpath%20fill='%23763a5a'%20d='M262%20452h3v2l7%201-1%204%204-2%202%204-1%203h-7l-2-1%203-5h-7l-2-5z'/%3e%3cpath%20fill='%235d5486'%20d='M320%20415v24l-4-9v-2l-1-3-1-3v-2q5-6%206-5'/%3e%3cpath%20fill='%235eb9ed'%20d='M300%20338q1%207-2%2013l-7-3q0-4%202-6z'/%3e%3cpath%20fill='%23b9827a'%20d='M319%20346h1v19h-3l-1-5-6-1%201-1q5-5%208-12'/%3e%3cpath%20fill='%23403657'%20d='M35%20361v12l-11-4c7-8%207-8%2011-8'/%3e%3cpath%20fill='%234c7aba'%20d='m30%20308%2031%202h5l3%201h3l1%202q-21%201-43-4z'/%3e%3cpath%20fill='%235eb9ed'%20d='M283%20212h3q4-1%207%202v2l-7%201h-2l-6%201-2-2v-3z'/%3e%3cpath%20fill='%23fece69'%20d='m295%20317%203%201v9h-11l6-7h2z'/%3e%3cpath%20fill='%235d5486'%20d='M319%20463h1v14h-2v2h-2v4l-2-1c0-14%200-14%205-19'/%3e%3cpath%20fill='%23e8bbb9'%20d='m306%20217%205%203-12%203-4-2v-2q5-2%2011-2'/%3e%3c/svg%3e",
	pond: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='507'%3e%3cpath%20fill='%232f5a59'%20d='M0%200h320v507H0z'/%3e%3cpath%20fill='%2325494a'%20d='M186%20145h2l13%2049h2l3%2015%204%2017%208%2029%205%2017%201%207%204%2014v2l2%208%205%2021%202%207q0%205%202%209h2l1%203%207%208%2011%2012h2l1%202h2l1-3h-4l1-3%202-1%201-6-3-1v-2h2l-1-6v-3l-2-7h-3l1-6%203-1v2l3%208q3%2014%202%2028l1-5h2v3l3-1q3-2%208-2l-1-6h2l-1-7%201%202%203%204%202-11h1v15l3-3%204%202-1-6-1-3-1-3-2-1v-5l7%205%201-5h1v2l1%203v3l2%206%203-1%201%202%202-6%202%201v5l2%201v2l7%201v151H0V343l11%205%201-2%201-2%201-2%203-5%201%202%206-7-9-5%201-2%204%202%207%204v-2l2-4-1-6-1-3-1-3q4%201%204%205v2l1%202%201-5%202%204%202-1-2%206%206-3-1-2-2-6%205%204q0-5-3-9l-1-3%203-3%203%206%203-10v-6h2l1%2021%202-7h2l-2%2011%205-1q23-7%2046%200l-1-2-4-25-14%202h-4l-2%201%202-3h4v-2l-7%201-1-5%2011-1h6v-5l-5%202%204-4-11%201v-2l3-1h3l9-2%2010-4%202-1%205-2v-5l-3%202-3%202-3-1h2l1-2q1-3%205-5h14l4%207h7l2%201%201-7h1l1%205v-10l2-2-1-4-5-2-1-3q7%201%2012%204v6l-1%202q-3%207-2%2014h4l1-4%201%206%202%201v-2l1-2v-3l1-2%202-1v7l4-4-2%209q-1%205%202%209l1%202%201%202%203%205h3q9-2%2019-2h2q9%201%2014%206l7%204%201%202%202%201v-21l-1-4q0-7-6-12l-1-2-2-2-5-6-5%205-2-1%202-2q4-7%202-15v-3l-2-30-2%204-2%203-6%208h-2l4-8%202-2%203-4q4-5%203-12l-4-12-2-5v-2l-1-6-2-1%201-1-3-8-1%202-2%2010-1%204-6%2014h-1l4-17%206-22%201-2z'/%3e%3cpath%20fill='%232c332d'%20d='M0%200h101l1%2010v5l2-2q3%202%202%205h2l2%2010h2l2%204%201%203%201%204h-2v8l-5-8-1-1v3h2l6%2015c7%2020%207%2020%205%2027v5h2l1-3q4%204%205%2010l3%2015-1-2h-8l-1%204c-10-1-10-1-14-5q-5-3-12-2-5%200-9-4l-12%202q-4%203-3%208l-1%204%205%203%203%202%205%204v2h2l6%204-3%201-11-1-5%201-2%206h-3c-9-2-9-2-13%201q-3%203-2%207%201%205%206%207l8%203v2h2l1-2%207%201q5%204%205%2010h-2l-10%201-6-2q-5-3-11-1l-2%201-1%203-2%202q-5%204-5%209l4%202-5%209-2%204%207%2010%204%201%204%202%202%206%205%209%201%204h-5v4l4%202%203%203%2012%204v5h2v2l2%201c6%203%2010%2012%2012%2018v3l2-1%2014-4%204-3%202%201-2%203v3q-15%207-32%209v2h2l2-1%203-1%206%201-3%202h2v5l-17%201%201%205%207-1v2l-2%201%204-1%2012-1%203%2015%202%2013h-4l-7-2q-18-2-34%202l-6%201%201-7%201-4h-2l-2%209h-1v-23h-2v9q0%204-3%208l-5-5%203%207v7l-4-4%201%202%201%206-6%202v-3l-2-4v7l-5-11%203%2012-2%201-1%204-2-1-2-1-2-2-3-1%207%205-3%203-1%202-5%203-3%206-1%202q-7%200-12-5zm152%2084q3%202%202%205v24h2V93l11%201%205%2016%201%205%201%204q2%205-1%2010h-2q-7-2-15%200v2l-1%204h-8l-5-2%203-1%203-5q0-4-4-6l1-1v-5l-8-3-3-1h-2l1-4%203-1%201-3%202-2h6l-1-3%202-7h4v-2z'/%3e%3cpath%20fill='%23998a4f'%20d='M186%20145h2l13%2049h2v4l3%2011%204%2017%208%2029%205%2017%201%207%204%2014v2l2%208%205%2021%202%207q0%205%202%209h2l1%203%207%208%2011%2012h2l1%202h2l1-3h-4l1-3%202-1%201-6-3-1v-2h2l-1-6v-3l-2-7h-3l1-6%203-1v2l3%208q3%2014%202%2028l1-5h2v3l3-1q3-2%208-2l-1-6h2l-1-7%201%202%203%204%202-11h1v15l3-3%204%202-1-6-1-3-1-3-2-1v-5l7%205%201-5h1v2l1%203v3l2%206%203-1%201%202%202-6%202%201v5l2%201v2l7%201v109l-7-3v2l-4%201-1-1h-5v3l-4%209-5%201-2-1v6l3%201%201%205h-4l-1-5h-3l-1%205h-7v-4h-2v-2l-3-1-3-5-2-3-1-4-3%201q-4%203-9%203v-2l-7%201-4-7-1-2-3-8-2-1q-3-1-5-4l1-6%202%202-8-11-1-4%201-2%202%201%203-2%206-2%202%201h2v-3l8%201-2-2q-2-3-2-7l-3%201v-6l4-1-1%205%203-3q4-5%209-7h2l-1-2-1-7-6-3q-2-1-2-6l1-8h-4v-2l-2%202-4%201-2%204-3%204-2%201-2%202-1%202q-4%202-10%201h-26v8h-66l7-22%201-6h-2v-7h-2q-4-2-6-6l-2-10-1%207h-2l1-12h-2l-1%2011-2-1-2-8q-1-9-6-15-3-4-2-8l1-2-2-3q0-13%205-27l-3%2010-1%203q-4%2011-1%2022l1%203%201%205q-4-3-5-8l-2-9-1-2-6-26q-10%200-20%203l2-3h4v-2l-7%201-1-5%2011-1h6v-5l-5%202%204-4-11%201v-2l3-1h3l9-2%2010-4%202-1%205-2v-5l-3%202-3%202-3-1h2l1-2q1-3%205-5h14l4%207h7l2%201%201-7h1l1%205v-10l2-2-1-4-5-2-1-3q7%201%2012%204v6l-1%202q-3%207-2%2014h4l1-4%201%206%202%201v-2l1-2v-3l1-2%202-1v7l4-4-2%209q-1%205%202%209l1%202%201%202%203%205h3q9-2%2019-2h2q9%201%2014%206l7%204%201%202%202%201v-21l-1-4q0-7-6-12l-1-2-2-2-5-6-5%205-2-1%202-2q4-7%202-15v-3l-2-30-2%204-2%203-6%208h-2l4-8%202-2%203-4q4-5%203-12l-4-12-2-5v-2l-1-6-2-1%201-1-3-8-1%202-2%2010-1%204-6%2014h-1l4-17%206-22%201-2z'/%3e%3cpath%20fill='%23734a65'%20d='m87%20100%203%202q4%203%209%202%208%200%2012%205l11%203%201-4%206-1%201%201q4%204%208%204c6%201%206%201%208%203l-1%207%203%202v6l-5%203%207%201h5v-5q6-2%2013-2l5%202%201-2%204-6h2l-1%205%204-1%201-4h2l-1%206h-2l2%202q3%202%202%206l-1%203%201%203%203%201v2l-3%201-2%205v3l-1%203-2%207-1%203-5%2016-2%2010%2010-32%204%2011%206%2021q4%207%201%2014l-5%208-1%202-3%203-3%205%2010-12%204-6h1v39q1%208-4%2014l6-5c15%2016%2015%2016%2015%2026v22l-5-3-8-4v-2q-18-6-36-1l-3-6-2-4-1-5-2-1%202-3%201-7-3%203-1-4v-3l-2%2010-4-2v-5l-1%203h-4l-1-11%203-5%201-6h-2l-9-3v2l3%201%203%201%201%205-3%201%201%202v8l-2%202-1-5-1%205h-9c-4-4-4-4-4-8l-13%201-5%204q-6%205-15%206l-1-2c-6-17-6-17-13-20v-2h-2v-5h-2q-10-1-17-9v-4h5l-4-7-1-2-1-2-1-2-1-4-1-2-5-1q-6-3-9-9l-1-5%205-5%202-6-3-2%201-7%206-5%201-2%209-3%204%202q6%204%2013%201l5%201-1-2-1-2-2-2-1-4-10%201-1-2-4-1q-6-2-9-6l-1-7%205-5%201-1h4l9%202v-3q1-3%204-5l6%201h10l-8-5-10-7-2-2v-6q0-5%204-8%206-3%2012-2'/%3e%3cpath%20fill='%232c4b45'%20d='M264%20124h40c1%2029%201%2029-6%2042l-2%205h2l1-2%203-8%204-12%204%203%203%201%202%202%203%202q3%203%203%208v34l-1%2048v109l-7-1v-2l-3-1v-2l-1-4v3l-1%203-2%201-1-2h-2l-2-4q-2-5-8-7l-1-2-1%204%203%201%202%2012-5-1v2h-2l-1-12-1%208h-3l-1-1%201%206h-2v2l-11%203v-3h-2l1%205h-2l-1-11q0-13-5-24l1-3-4%207h3l3%2011v5h-2l2%201%201%205q0%205-4%207h4l-1%204-3-1v-2h-2l-1-2q-5-7-11-11-7-4-7-7l-4-4-2-11-1-6q-4-10-5-21l-7-26-2-11-4-14q-5-16-8-34l2-1%203%203%201-1h7l4%204%202-3h2l-1-7%207-4-5-3%202-3-2-2-2-2%201-3%208-1%201-4-6-5%204-4%205%201%201%205h2l3%201%201%202-7%204v3l7-1%201%205q-2%204-6%204-4%201-4%204l-1%202%202%201%202%201v10l2-1q3-2%207-2l2%209%204-9%201-3%201-5v-7l2-2%202%201v-2q-1-11%206-19l3-10%204-8v-10h3l1%201q-1-15-12-26z'/%3e%3cpath%20fill='%2354664e'%20d='M248%20377h2v2l4-1%201%204-1%201v8l4%203%203%202%202%201-1%202%201%206-2%201-3%202-3%201-4%206h-2l1-5h-2l-1%206h2l1%202%203%207-8-1v3l-9%201-1%202-4%201-1-1q2%206%207%2011l1%206-2%204%203%201q6%206%208%2014l3%205h7l1%201%209-2%202-1%201%202%202%203%201%203%204%204%201%201v2h2v4h7l1-5h3l2%204h2l-1-4-2-1v-6l3%201%204-3%204-10%206-1v2l4-1v-2l7%203v42H160v-1h14l1-2v2h4q-5-11-14-20l-1-2%201-3v-3q6-9%2014-15l-1-2h-26l-21-1v-2h3v-2h-6v4l-12%202h-7l-14%201h28v2l7%201%201%204h-2v2l3%201v8l-2%201%203%201%201%206-11%202h-7v2l3-1%2014%201%201%204h-30v-2l-15-1v-1h14l-1-3%202-1-2-2v-6l2-3%2012-2-25-2%201-4-4-1h4l-1-5-3-1%202-2%201-6v-5l10-2v-2l-13-1q5-2%2011-2v-2H64l-1-2%2028-1v-4h3l-1-2v-4l-1-4-2-2%205-1h33v-2h-3l-18-2-31-5v-1l32-3h7l21-1%201%203h5v-3l5%201%201%204%2022%201%201-7h20l8-1h2l11-2-2-1v-3l-5-1v-1h2c21%201%2021%201%2027-4l8-10%205-5z'/%3e%3cpath%20fill='%23548470'%20d='M115%20291v7l-1%203v3c-4%2014-4%2014-2%2018v4q1%206%204%2011l2%202%201%204%201%202v3l1%202%201%206%202-10h2l-1%2012h2v-8l2-1%201%208v2l2%201%201%206h6l-1%208h2c2%209-5%2019-8%2028h66v-8l34-1-2%204-5%201h-9l-6%201v3l3%201q-7%204-14%203h-28l-1%207h-36v-1l13-1-1-3-4-1%201%203h-6l-1-2q-13-1-27%201h-6l-22%203%2021%203%2026%204v2l-63%201v-2h-2l-3-1-1-4-5-8-1-2%202-3h10l17%201%201-5v-2l-2-7-2%205h-2v-9l-1%204-1%204-3%201-1-4c-2-17-2-17-5-25l-6%206-3%202q-3%203-4%207v3h2l-1%204-2-1v8l-4-4q-8%206-13%2015l-1%202h-1l-1-5q-7%206-12%2014l-3-1c0-24%200-24%207-32l2-2-1-2h-2v-2l-4-4-6-1-2-2v-2l-3-1q-3-1-5-4v-6l-2-3%202-6%204%201v-2l4%201%201-2%201-2%201-2%203-5%201%202%206-7-9-5%201-2%204%202%202%201%205%203v-2l2-4-1-6-1-3-1-3q4%201%204%205v2l1%202%201-5%202%204%202-1-2%206%206-3-1-2-2-6%205%204q0-5-3-9l-1-3%203-3%203%206%203-10v-6h2l1%2021%202-7h2l-2%2011%205-1q23-7%2046%200l-1-2v-3l-1-2-1-8q4%205%204%209l7%2023c-6-15-2-29%204-44'/%3e%3cpath%20fill='%23a16666'%20d='M261%20326h2v2l3%208q3%2014%202%2028l1-5h2v3l3-1q3-2%208-2l-1-6h2l-1-7%201%202%203%204%202-11h1v15l3-3%204%202-1-6-1-3-1-3-2-1v-5l2%202%205%203%201-5h1v2l3%2012%203-1%201%202%202-6%202%201v5l2%201v2l7%201v109l-7-3v2l-4%201-1-1h-5v3l-4%209-5%201-2-1v6l3%201%201%205h-4l-1-5h-3l-1%205h-7v-4h-2v-2l-3-1-3-5-2-3-1-4-3%201q-4%203-9%203v-2l-7%201-4-7-1-2-3-8-2-1q-3-1-5-4l1-6%202%202-8-11-1-4%201-2%202%201%203-2%206-2%202%201h2v-3l8%201-2-2q-2-3-2-7l-3%201v-6l4-1-1%205%203-3q4-5%209-7h2l-1-2-1-7-6-3q-2-1-2-6l1-8h-4l-1-3%205-4%203-2%206-4%203-4h-4l1-3%202-1%201-6-3-1v-2h2l-1-6v-3l-2-7h-3z'/%3e%3cpath%20fill='%23356962'%20d='M208%200h112v159l-13-9-1%203-8%2018h-2l4-11q6-17%204-36h-40v-2h15l5-1h10l14%201q-6-13-15-24l-7-10c-10-14-10-14-14-17h-3l-1%202-8%2015-2%203-2%204-2%203-6%205q1-6%205-11h2v-2l3-7-7-7-2-2-13-11-2%2014h-2l2-21a145%20145%200%200%200%204-37q-4-5-12-7l-5-3-2-1-3-2-2-1-5-3-1-1z'/%3e%3cpath%20fill='%23213532'%20d='m175%20127%202%203-1%202h2l-1%205h2v2l2%208q3%2012-1%2023l-1%203-4%2012-1%207%2010-32%204%2011%206%2021q4%207%201%2014l-5%208-1%202-3%203-3%205%2010-12%204-6h1v39q1%208-4%2014l6-5c15%2016%2015%2016%2015%2026v22l-5-3-8-4v-2q-18-6-36-1l-3-6-2-4-1-5-2-1%202-3%201-7-3%203-1-4v-3l-2%2010-4-2v-5l-1%203h-4l-1-11%203-5%201-6h-2l-6-3q-7-3-15-2t-16-2H99v-3h2l6-1%204-4q13-4%2025-4l1-3v2l4-1-1-4-6-4v-2q-3-2-7-2l-3-1-2-3-5-2h-3l-8-1-3-1-1-3h2q7-1%2012-5l6-2%203%202q10%202%2016-4l2-4q0-5-5-9l-2-1v-2h-2q3-14%2013-23l7-3%203-2q4-3%2010-4l6-4%201-8z'/%3e%3cpath%20fill='%23356962'%20d='M269%2071q4-1%208%203l12%2017%2012%2017c7%2010%207%2010%207%2014h-44l7%2011q7%208%2010%2018l-1%205-3-2v12h-2l-1%203-1%205-1%202-1%202v2l-4%205q-4%207-3%2014l-1%204-3%201%201%202q1%204-2%208l-1%203-1%203-1%203-3%207h-1v-3l-1-8-9%203v-8l-4-4%201-5%206-3%203-3v-4l-7%201-1%202q0-4%202-6l5-4-2-1q-3%200-4-4l-1-2-7%202%201%201%205%205-1%205h-3l-6%201%204%206-2%203%206%203-8%204v7h-2l-2%204-2-3-5-1-2-1h-2l-1%202-1-3h-5l-2-8-1-2-2-11-2-2%207-2v-2h2v-2l1-5%203-6%202-1%201-4h3l5-3%202-10q2-7%207-12h2q1-9-2-18l-1-1q-2-8-1-16l2-1%203-6%201-2h2l2%202%202-2%204-1%202%201%2014-21%202-3z'/%3e%3cpath%20fill='%23734a65'%20d='m87%20100%203%202q4%203%209%202%208%200%2012%205l11%203%201-4%206-1%201%201q4%204%208%204c6%201%206%201%208%203l-1%207%203%202v6l-5%203%207%201h5v-5q6-2%2013-2l5%202%201-2%204-6h2l-1%205%204-1%201-4h2l-1%206h-2l2%202q3%202%202%206l-1%203%201%203%203%201v2l-3%201-2%205v3l-1%202q-4-4-3-10l-1-2-2-1%201-5h-2l1-5h-2l-1-3-2%2013q-5%204-12%205l-8%205-5%203q-6%204-8%2011l-2%204-1%202-3%205h2v2l2%201%205%205-1%202-5-1-1-3-6-1-7-3-9-3-12-4q-13-3-25%201l-6%201-3%201-1%202-2-2-4-1v3H45l-1-5%204-4%203-3%209-3%204%202q6%204%2013%201l5%201-1-2-1-2-2-2-1-4-10%201-1-2-4-1q-6-2-9-6l-1-7%205-5%201-1h4l9%202v-3q1-3%204-5l6%201h10l-8-5-10-7-2-2v-6q0-5%204-8%206-3%2012-2'/%3e%3cpath%20fill='%23356962'%20d='M264%20124h40c1%2029%201%2029-6%2042l-2%205h2l4-10%204-12%204%203%203%201%202%202%203%202%203%205v68l-1%203-4%202q-7%207-7%2018l-2%205-10-1-8%201-1-4-6-1%201-6h-3v3l-4%2014-1%203c-6%2019-6%2019-11%2023l3-10%204-10%202-6c8-19%2010-33%205-53l-4%202%208-12q3-4%203-9l-3-8-1-3-3-6q-2-10-2-21h3l1%201q-1-15-12-26z'/%3e%3cpath%20fill='%23474944'%20d='m136%20407%201%203h5v-3l5%201%201%204-24%201v2h25l6%201-1%2012%204%201v2h2l-2%204h-3v2h5v2q-8%203-17%202l-1-4-4%201-1%203-5%201-2%201h-2q7%206%2015%205v-2l6-1-1-2%2010-1%201%203-5%202%2027%204%203%206-2%204-5-2-2-3%203%205h-17l-30-1v-2h3v-2h-6v4l-12%202h-7l-14%201h28v2l7%201%201%204h-2v2l3%201v8l-2%201%203%201%201%206-11%202h-7v2l3-1%2014%201%201%204h-30v-2l-15-1v-1h14l-1-3%202-1-2-2v-6l2-3%2012-2-25-2%201-4-4-1h4l-1-5-3-1%202-2%201-6v-5l10-2v-2l-13-1q5-2%2011-2v-2H64l-1-2%2028-1v-4h3l-1-2v-4l-1-4-2-2%205-1h33v-2h-3l-18-2-31-5v-1a369%20369%200%200%201%2060-4'/%3e%3cpath%20fill='%23d2c16d'%20d='M208%200q8%201%2015%207l6%203%202%201%2012%207%203%202%2010%205%202%202%202%201v2h-3l2%203%203%204%201%202%205%207%204%203%202%204%204%206%201%205q2%204%206%206v4h2l3%205%204%205%201%203%204%203v-3l2-6v-4l-2-1q-7-2-13-6l2-1%205%203%201-1-2-3-1-3%201-2%201%202%202%203%202%204%205%203v-4l-2-1v-5l4-4h4l-5-9-4-10-1-2c-2-6-2-6-1-9l7%2015%203%205%202%203%201%206h2l-1-3%209%201v101l-13-9-1%203-8%2018h-2l4-11q6-17%204-36h-40v-2h15l5-1h10l14%201q-6-13-15-24l-7-10c-10-14-10-14-14-17h-3l-1%202-8%2015-2%203-2%204-2%203-6%205q1-6%205-11h2v-2l3-7-7-7-2-2-13-11-2%2014h-2l2-21a145%20145%200%200%200%204-37q-4-5-12-7l-5-3-2-1-3-2-2-1-5-3-1-1z'/%3e%3cpath%20fill='%2325494a'%20d='M101%200h36l-4%2022%205-16h3c12%2012%2013%2024%2013%2040v40l-3%201-1%205-2%201v-2h-2l-1%205h5v1l-5%201v3h-3q-3%201-5%204l-1%202h-3l-1%203v-7l-2-1-1-5-5-11-1%202h-2l-1-10h2l-1-3-4-11-2-5-2-7-1-2-2-9h-2v4l-1%209h-1l2-18%205%208v-7l1%202h2l-1-2-1-2-1-3-1-4h-2l-2-10h-2l-2-4-3%202z'/%3e%3cpath%20fill='%232c4b45'%20d='m171%20203%207%203v3h2c4%206%204%206%204%2010l2%201-3%204%2010-12%204-6h1v39q1%208-4%2014l6-5c15%2016%2015%2016%2015%2026v22l-5-3-8-4v-2q-18-6-36-1l-3-6-2-4-1-5-2-1%201-3%203-8q0-5%203-11l-2-1%204-3-1-4-1-3-3-5h-3l-1-5h-2l2-9q2-5%206-7l4-7%201-2z'/%3e%3cpath%20fill='%2354664e'%20d='m0%20343%206%202%201%204H5l-2%201-1%205%202%202v6l1%202%203%201%204%203%201%202h3l4%202%202%201%201%201v4l3-1c0%205%200%205-3%208-7%208-5%2019-5%2029l2%201%201-2%204-6%208-7%201%205%201-2q5-9%2013-15l3%204%201-7h2l1-3-3%201q-1-4%201-8l6-6%201-2%204-3h3q5%2013%206%2028h2l1-9%202%202-1%208h2l2-9h1l2%209-2%209H55l-1%203%203%205c4%205%204%205%204%208l2-1v2h2l3%207%201%206-8-1v2l-7%201h-3l-9-1-5%201h-6v10h-1v-7l-1-2-4-2-1%209h-1v-11l-3-1-15-5%201-23-2%2015H2q-2-12-2-25z'/%3e%3cpath%20fill='%232c332d'%20d='m313%20462%207%203v42H209l2-5%201-2%203-3h2l1-3v-6l3%201%204-3q6-4%2013-6l3%201%201-3%206-1v-4h4v-2h5l1%201%209-2%202-1%201%202%202%203%201%203%204%204%201%201v2h2v4h7l1-5h3l2%204h2l-1-4-2-1v-6l3%201%204-3%204-10%206-1v2l4-1z'/%3e%3cpath%20fill='%2365b3b5'%20d='M6%20397h1l-2%2029h3l13%205%206%203h7l7%201v-6h1v5h42v2l-27%201v8l-2-1v-7H42l3%208v9l-3-3v-2l-1-2v-2h-3v-5h-2l2%206h2v5h-2v-2h-2q-1%207%201%2013l1%2025v11l-1%209H0v-99q3%205%202%2010h2v-7l1-2zm109-106v7l-1%203v3c-4%2014-4%2014-2%2018v4q1%206%204%2011l2%202%201%204%201%202v3l1%202%201%206%202-10h2l-1%2012h2v-8l2-1v5l1%203v2l2%201%201%206h6l-1%208h2c2%209-5%2019-8%2028h66v-8l34-1-2%204-5%201h-9l-6%201v3l3%201q-7%204-14%203h-28l-1%207h-36v-1l13-1-1-3-4-1%201%203h-6l-1-2h-18v-2l-10%201v1h-7v-1h-2l-2-1h-2l-2-1-1-3%2016%201%201-5%202-8q4-28-7-52l-4-12%207%209-1-3-4-17-1-2-1-3v-7q4%205%204%209l7%2023c-6-15-2-29%204-44'/%3e%3cpath%20fill='%23d2c16d'%20d='m111%20320%206%201%204%201%205%202v2h2a120%20120%200%200%201%2041%2022l3%202%205%201%201%203q1%205%203%205l2%201-1%203-4%2029-4-1-3%208h-2l-2-12v-7l-3%203-5-7q-5%204-5%209l-3-1v-3q1-4-2-6l-2-1-1-1v5h-2l-2%203-2-7h-2v-7h-2q-4-2-6-6l-2-10-1%207h-2l1-12h-2l-1%2011-2-1-2-8q-1-9-6-15-3-4-2-8l1-2z'/%3e%3cpath%20fill='%23213532'%20d='M199%200q11-1%2018%205l4%203%202%201%206%204q6%202%2010%206%201%209-1%2017v4l-5%2025-1%2012-8-10-2%201-1-3%201-2-6%201-2-6h2l1-2-1-1v-3l-6%201-1-4h-2l-2-8-1-2%202-7-2-1v-4l-4-16zm37%2063q13%208%2023%2020l-4%209h-2l-1%202-3%206h-3l-9-13-3-5-2-5h2v-4zm82%20169%202%201q1%2010-4%2019l-1%202q-2%206-6%2010c-1-20-1-20%204-27l4-4zm-5%2027%203%201q7%2017%204%2033v63l-7-1v-2l-3-1v-2l-1-4v3l-1%203-2%201-1-2h-2l-2-4q-2-5-8-7l-4-5%201-3-4%203q1-4%204-7h2v3h2l1-2h1l1-4v-3l-1-7c-3-8%203-19%206-26l2-7%201-4%201-2q2-7%206-13z'/%3e%3cpath%20fill='%23383636'%20d='m94%2070%209%202-1%209%202%205%202%202%202-1c6%201%206%201%208%203v3h3v-3l2%201%206-1%202%205%201%203q3%205%202%2012l-1-2h-8l-1%204c-10-1-10-1-14-5q-7-3-15-2l-1-12V72h2zm58%2014q3%202%202%205v24h2V93l11%201%206%2021%201%204q2%205-1%2010h-2q-7-2-15%200v2l-1%204h-8l-5-2%203-1%203-5q0-4-4-6l1-1v-5l-8-3-3-1h-2l1-4%203-1%201-3%202-2h6l-1-3%202-7h4v-2z'/%3e%3cpath%20fill='%232c4b45'%20d='M269%2071q4-1%208%203l12%2017%2012%2017c7%2010%207%2010%207%2014l-26%201c-18%202-18%202-23-2l-4-9-3-3-2-5q1-6%205-11l3-5%202-2%208-13z'/%3e%3cpath%20fill='%23734a65'%20d='m91%20228%2013%203%205%202v2l-10%201v3l2-1q6-1%2012%201l13%201h8l4%202v3l3%201%203%201%201%205-3%201%201%202v8l-2%202-1-5-1%205h-9c-4-4-4-4-4-8l-13%201-5%204q-6%205-15%206l-1-2c-6-17-6-17-13-20v-2h-2v-5h-2q-8-1-14-7v-2c20-6%2020-6%2030-2'/%3e%3cpath%20fill='%23d2c16d'%20d='M186%20145h2l13%2049h2v4l3%2011%204%2017%208%2029%205%2017%202%207%202%2018-7-12-2-3v5l-1%204v2l-2%201v-12q-1-12-10-21l-5-6-5%205-2-1%202-2q4-7%202-15v-35l-2%202-2%204-2%203-6%208h-2l4-8%202-2%203-4q4-5%203-12l-4-12-2-5v-2l-1-6-2-1%201-1-3-8-1%202-2%2010-1%204-6%2014h-1l4-17%206-22%201-2z'/%3e%3cpath%20fill='%2354664e'%20d='m94%20277-3%202h2v5l-17%201%201%205%207-1v2l-2%201%204-1%2012-1%203%2015%202%2013h-4l-7-2q-18-2-34%202l-6%201%201-7%201-4h-2l-2%209h-1c-1-17-1-17%203-25l1%204%206-9%201%203q5-1%207-7l2%201%202-2q5-5%2013-6h3z'/%3e%3cpath%20fill='%23474944'%20d='M250%20377v2l4-1%201%204-1%201v8l4%203%203%202%202%201-1%202%201%206-2%201-3%202-3%201-4%206h-2l1-5h-2l-1%206h2l1%202%203%207-8-1v3l-9%201-1%202-4%201-5-9%201%2011h-13l-5-5%207-14h2v-2q3-7%209-12l1-2%203-1%202-4%203-4%206-7c4-5%204-5%208-5m-114%2089h13l3%201%2020%201q0%204-4%207l-2%206%201%202-2-1%205%207q8%207%209%2017l-40%201h-19l-2-8%2019-1-1%202h4v-2h2v-4h2v-2l-2-1%202-1-2-1-1-6-1-3v-3l6-1-7-1%201-3%204-1h-6z'/%3e%3cpath%20fill='%2365b3b5'%20d='M64%20445h1v3c-2%2010-2%2010%201%2014l3%202q6%204%206%2010l5-1-1%202-5%2023v3l-1%202-1%204H48v-3c4-37%204-37%202-55q5%202%209%206h2z'/%3e%3cpath%20fill='%23998a4f'%20d='M245%20424q4%200%206%203l2%202%202%203q3%205%201%2012l7%203v2l4-1%206%209q3%205%208%209l2%202-1%203h-2l-1%202h-6l-1-2%201-2-4%202v-2l-3%201q-4%203-9%203v-2l-7%201-4-7-1-2-3-8-2-1q-3-1-5-4l1-6%202%202-8-11-1-4%201-2%202%201%203-2%206-2%202%201h2z'/%3e%3cpath%20fill='%23213532'%20d='M264%20124h40c1%2020%200%2032-10%2049q-8-8-11-17l-3%2011-3-1-1-7v-5h3l1%201q-1-15-12-26z'/%3e%3cpath%20fill='%2354664e'%20d='M137%200h3l3%205%206%2010%202%202%201%202%208%2011-1%202-4-5v20l2-1%201-4h5l1%208v2l1%2014%201%201v-8q2%200%203%205l2%205v2q3%2012%203%2023h2v4q0%207%203%2013l3%2015h-3l1-5-5%203c-8-25-8-25-8-30h-7l-4-1v20h-2l-1-72c0-15-3-24-13-35l-3%207-1%202-1%202-2%208h-1q1-13%205-25'/%3e%3cpath%20fill='%23a16666'%20d='m131%20108%201%202%206%202c6%201%206%201%208%203l-1%207%203%202v6l-5%203%207%201h5v-5q6-2%2013-2l5%202%201-2%204-6h2l-1%205%204-1%201-4h2l-1%206h-2l2%202q3%202%202%206l-1%203%201%203%203%201v2l-3%201-2%205v3l-1%202q-4-4-3-10l-1-2-2-1%201-5h-2l1-5h-2l-1-3-2%2013c-5%204-5%204-9%204l-4-2-7-1-6-2-8%201-2%201-4-3-9-3-6-2-7-1c8-5%208-5%2012-5l9%203%207%201%201-2h-2v-2l-6-5%201-3-4%201-3-8h-2l-1%204h-1l1-10z'/%3e%3cpath%20fill='%2354664e'%20d='m0%20343%206%202%201%204H5l-2%201-1%205%202%202v6l1%202%203%201%204%203%201%202h3l4%202%202%201%201%201v4l3-1c0%205-1%205-3%208q-6%209-5%2019v10c0%209%200%209-3%2012l-1-5-2%205-7-1%201-23-2%2015H2q-2-12-2-25z'/%3e%3cpath%20fill='%23d2c16d'%20d='M86%20315h4q7-1%2013%203%205%209%206%2019h-2l-3-5-2-3-1-2%201%202%203%208%201%203%201%202v7l-9-6-5-2q-4-1-6-7l-1-2-1-4-1-2-3-6v5h-2l3%2012h-2l-1%202-1-2-6-2h-3l-7-1-4-3-1-2-2%201%202%202-3%201-4-3v-2h-2l-1%203-4-3%202%204h-4l-2-6h2l1-3%205-2%202%203h2l2%202-2-2-1-3%201-2q17-6%2035-4'/%3e%3cpath%20fill='%23548470'%20d='m296%2031%209%2015%201%203%203%206%201%205h2l-1-3%209%201v63l-7-9-10-14-4-4q-2-4-1-8l3-5v-4l-2-1q-7-1-13-6l2-1%205%203%201-1-2-3-1-3%201-2%201%202%202%203%202%204%205%203v-4l-2-1v-5l4-4h4l-5-9-2-5-1-2-1-3-1-2z'/%3e%3cpath%20fill='%2354664e'%20d='M179%20463c10%204%2016%2020%2021%2029l1%203%202%203%201%203v6h-44v-1h14l1-2v2h4q-5-11-14-20l-1-2%201-3v-3q6-9%2014-15M36%20206v13h2v-5l1-3%202-5v5l2%201v11c5%2027-3%2052-15%2076l-3-1-1-5%203-7%202-10-1%201-8%208%204-15%201-4%201-3c10-28%2010-28%209-41l-1-2-2%204-2%203h-2v-2l-1-5-3-7v-5l4-2z'/%3e%3cpath%20fill='%232f5a59'%20d='m127%20455%207%201v2h-3v2h48l1%203-2%201-3%203-1%202h-7l-5-1-6-1h-11l-9-1%202%204%206%201-1%202h-3l-1%202h3l9%201v1h-11l1%204h5v1h-5v4l2%201-1%202%204%201-2%202v2h-2v4h-2v2l4%201h-15v-1l7-1h-9l-19%202h-5l1%203H93l-3-1-2-5%2018-1%208-1h19v-3h-17v-2h-8v-1l26-1-2-5-6-2%203-3h3v-3h-7v-1h7l-3-3%201-5-7-2v-2l-2%201H95l-1-2h3l9-1h10l4-1%207-1z'/%3e%3cpath%20fill='%23213532'%20d='m306%20149%204%203%203%201%202%202%203%202%203%205v6l-1%206v54l-7-8-1-2-1-2-2%202v-13l-1-21c-7-2-7-2-10-1l-4-9h2l5-11z'/%3e%3cpath%20fill='%23384944'%20d='m81%20471%201%203%202-1q8-1%2015%201h10l11%203h-3l-5%201h-2l-6%201-2%205%202%202v3l2%201-3%201%202%205q-4%202-9%202h-8l2%204%207%201h6v-2l16-1%201%207H72c5-32%205-32%209-36'/%3e%3cpath%20fill='%23233d3b'%20d='m241%2021%206%209%203%205%2013%2018q6%207%206%2015-3%209-9%2014l-8-8-2-2-2-2q-3-4-8-6-4-3-3-5l2-24%201-4z'/%3e%3cpath%20fill='%2354664e'%20d='M232%20398h-4l-2%204-2%203h-2v2l-4%207h-2v2l-2%204-12-3v-2l-2%201v2l3%201-11%201h-9l-8-1-3-1h-11l-3-1-6-1-14-1h-14v-2h46l1-7h20l8-1h2l11-2-2-1v-3l-5-1v-1l12-1h10q3-1%205%202'/%3e%3cpath%20fill='%23383636'%20d='m94%2070%209%202-1%209%202%205%202%202%202-1c6%201%206%201%208%203v3h3v-3l2%201%206-1q5%209%205%2019l-9-1-1%204c-10-1-10-1-14-5q-7-3-15-2l-1-12V72h2z'/%3e%3cpath%20fill='%2354664e'%20d='M42%20437h6v2q-2%207%201%2014c7%2014%204%2040-1%2054H37v-44l-1-4v-3l-2-1%201-7%203%201v2h2v-5l-3%201-1-7h2v5l3-1q3%204%203%209v-6l-2-4z'/%3e%3cpath%20fill='%23d2c16d'%20d='M55%20402h27l11%201v2h4l3%201%206%201v-1h12v2h-2l-10%201h-4l-21%203%2021%203%2026%204v2l-63%201v-2h-2l-3-1-1-4-5-8-1-2z'/%3e%3cpath%20fill='%2354664e'%20d='m146%20373%205%202%201%205h2l2-2%201-2h2l6%206%203-3%201%2020h2l2-9%205%202-3%2010h-43l6-18%201-4%201-2%202%202z'/%3e%3cpath%20fill='%2365b3b5'%20d='M51%20368h1v6l5-3-4%207v5h2l-1%204-2-1v8l-4-4q-8%206-13%2015l-1%202h-1l-1-5q-7%206-12%2014l-3-1c0-13-1-23%208-34l4-2%201-2q2-3%206-4l1%202%204%203%202%203h2v-4l1-3%201-4%203%201z'/%3e%3cpath%20fill='%23998a4f'%20d='M0%20157h6l1%2072v41l-1%206H0z'/%3e%3cpath%20fill='%2365b3b5'%20d='m123%20214%202%205%204%202%202%201%202%201-4%204h-6v2q-6%203-12%202l-1-3-4-1q-6-1-7-3l-1-2q-7-1-12%202l-3-2q-3-4-8-6l1-4c11-8%2036-6%2047%202'/%3e%3cpath%20fill='%23998a4f'%20d='m291%20337%202%202%205%203%201-5h1l1%205v3l2%206%203-1%201%202%202-6%202%201v5l2%201v2l7%201v29l-5-1q-3-4-3-8l1-2v-1h-3l-5-3v-5l-1%203-3-1-2-7v-4l-1-3%201%2013h-3l-9-1q-6%201-10-3l1-3h4l-1-6h2l-1-7%201%202%203%204%202-11h1v15l3-3%204%202-1-6-1-3-1-3-2-1z'/%3e%3cpath%20fill='%23a16666'%20d='M102%20153v16h8l4%201h2l11%204%205%202%204%201v2l2%201%205%205-1%202-5-1-1-3-6-1-7-3-9-3-12-4q-13-3-25%201l-6%201-3%201-1%202-2-2-4-1v3H45l-1-5%204-4%203-3%209-3%204%202q5%203%2012%201l11%201h6v-3q0-6%204-9z'/%3e%3cpath%20fill='%23213532'%20d='m65%20364%203%204%205%2025h2l1-9%202%202-1%208h2l2-9h1v3l2%206-2%209-12%201h-4c-8%200-8%200-11-3q-4-5-3-11v-4h2l1-3-3%201q-1-4%201-8l6-6%202-2%203-3z'/%3e%3cpath%20fill='%23d2c16d'%20d='M234%20337q3%202%202%205l1%202%205%201q7%203%2012%2010l2%202%204%206h2l1%204-3%202-4%203-2%201-10%208-1-2h-2v-3l-9-2%209-23h-10l-1-7h-2v2l-7-1v-4l-2-1%2015%201z'/%3e%3cpath%20fill='%23474944'%20d='M117%20465h7q4%200%207%202v3h-2v2l3%201v8l-2%201%203%201%201%206-11%202h-7v2l3-1%2014%201%201%204h-30v-2l-15-1v-1h14l-1-3%202-1-2-2v-6l2-3%206-1%206-1q3-5%201-11'/%3e%3cpath%20fill='%23998a4f'%20d='M208%200q8%201%2015%207l6%203%202%201%2012%207%203%202%2010%205%202%202%202%201v2h-3l5%207%201%202%203%203%203%204%201%207v9l-1%208h-1v-2q-1-11-9-19l-17-25-2%2012v4l-3%2021%202%201q10%207%2019%2017l2%202v3l-12-11-12-10-2%2014h-2l2-21a145%20145%200%200%200%204-37q-4-5-12-7l-5-3-2-1-3-2-2-1-5-3-1-1zm92%20431c8-1%2012%201%2020%204v30l-7-3v2l-4%201-1-1h-5l2-8h3l-1-2q0-5%203-8-4%203-5%207l-4-2%202%202v7l-2%203-1%202-2%205h-1c-3-28-3-28%203-39'/%3e%3cpath%20fill='%23474944'%20d='M242%20325h4v4h2l1-4h3v3l3-1%204%203v3h3l3%2011v5h-2l2%201%201%205q0%205-4%207h4l-1%204-3-1v-2h-2l-1-2q-5-7-11-11-7-4-7-7l-4-4-1-5-1-3v-2l3-1z'/%3e%3cpath%20fill='%232c332d'%20d='M100%20356q3%201%205%204h7q2%2022-4%2043H94l1-6q2-19%201-38h4z'/%3e%3cpath%20fill='%2354664e'%20d='M49%2073h3q4%206%203%2013l-3%206-2%205-3%207-6%202-3%201-5-1-1-6v-2q-2-8%202-16l3-3%201-2h2l3-3z'/%3e%3cpath%20fill='%23998a4f'%20d='M7%20347q10%206%2019%2014l2%201%208%209v2l-6%204-1%202h-6v-2l-4-4-6-1-2-2v-2l-3-1q-3-1-5-4v-6l-2-3%202-6%204%201z'/%3e%3cpath%20fill='%2365b3b5'%20d='m68%20188%206%204-2%206%206%201q-1%204-6%207H62v5q-7-1-12-8l-3-6%201-2h2q-2-3-5-4%203-4%208-5%208-2%2015%202'/%3e%3cpath%20fill='%23548470'%20d='M94%20290h4l3%2015%202%2013h-3l-14-2h-2l-6-1-1-16%202-1v2l2-1%208-1-2-7z'/%3e%3cpath%20fill='%23998a4f'%20d='M186%20145h2l10%2037%203%2010%201%204-4%205-2%203-3-12-1-4-2-6-1-6-1-3-2-1%201-1-3-8-1%202-2%2010-1%204-6%2014h-1l4-17%206-22%201-2z'/%3e%3cpath%20fill='%2365b3b5'%20d='m91%20228%2013%203%205%202v2l-3%201h-5l-2%201-13%204v-2h-2l-1%202-2%205h-2v-2h-2v-5h-2q-8-1-14-7v-2c20-6%2020-6%2030-2'/%3e%3cpath%20fill='%23998a4f'%20d='m181%20443%206%2011%205%207q4%206%206%2013l2%203c11%2024%2011%2024%209%2030h-5v-2q-2-8-6-14l-1-3q-7-14-17-25l-1-3-2-1-5-5q5%201%208%205v2l4-4-2-9z'/%3e%3cpath%20fill='%23548470'%20d='M4%20455h1v2l1%207%201%203v3l1%202%201%204%2013-13%202%201-3%202-3%204-1%201c-8%208-8%208-8%2012v3l3-2%204-2%202%201-2%201c-6%204-6%204-7%208v2l-4%201v4l2-1%207-4%203-1%202-1%203-1%207-1-9%204-5%202-3%201-3%206v4H0v-21q-2-15%204-31'/%3e%3cpath%20fill='%23998a4f'%20d='m171%20408%205%201-4%202q23%203%2045%202l-3%207-12-3v-2l-2%201v2l3%201-11%201h-9l-8-1-3-1h-11l-3-1-6-1h-10l-4-1h-14v-2h46z'/%3e%3cpath%20fill='%2354664e'%20d='m27%20334%207%204q2%204%201%2010h-2l-1%203v3l-1%203-2%205-7-5-11-7%201-2%204-11%202%202%202-1q3-2%207-2z'/%3e%3cpath%20fill='%23a16666'%20d='m87%20100%203%202q4%203%209%202%206%200%2010%202l2%205h-2v3l-6-2-2-1-2%201-2-3h-7l1%206-7-4%201%204h-4l5%204h-5l-1%202q-6-1-10-7l1-3v-3q1-4%204-6%206-3%2012-2M56%20208q3%200%205%202l1%201%201-2%205%2013%2010%201h8l4-2h8l3%204%207%202%203%203v2l-2%202-7-2-4-1-2-1-4-1-7-2q-10-1-20%203h-7v-4h5l-4-7-1-2-3-6z'/%3e%3cpath%20fill='%23d2c16d'%20d='M0%20157h6l1%2072v41l-1%206H0v-3h4L3%20160l-3-1z'/%3e%3cpath%20fill='%23356962'%20d='m77%20195%2011%201c-1%208-1%208-5%2011l-3%202-4%204%201%204%205%203%204%204c-13%201-13%201-18-1q-4-5-5-11l-1-4v-2h2l12-3%202-3z'/%3e%3cpath%20fill='%23474944'%20d='m94%2070%209%202-1%209%201%204q3%205%202%2010l-1%203-2%201v2h3l1%204H93l-1-12V72h2z'/%3e%3cpath%20fill='%23548470'%20d='M157%20376h2l6%206%203-3%201%2020h2l2-9%205%202-3%2010h-21z'/%3e%3cpath%20fill='%23998a4f'%20d='m237%20426%203%203-3%201%207%2012%2014%2025h-3l-3-5-2-2-2-6-4-4%2013%2021-7%201-4-7-1-2-3-8-2-1q-3-1-5-4l1-6%202%202-8-11-1-4%201-2%202%201z'/%3e%3cpath%20fill='%232f5a59'%20d='M101%200h23l-3%206-2-3-4%2016-1%202-2%205-3-1-1-7h-2l-2-4-3%202z'/%3e%3cpath%20fill='%23998a4f'%20d='M88%20414h9l31%205v2l-62%201v-1h8l-2-4h2v-3z'/%3e%3cpath%20fill='%23233d3b'%20d='M306%20124q7%201%2010%206%207%2012%204%2026l-5-3-4-2-5-4z'/%3e%3cpath%20fill='%23d2c16d'%20d='m199%20447%2010%208%206%206v2h2c4%206%204%206%204%209l3%201%202%204%201%203%201%205-5%202-2-2-3-6-5-8q-7-11-18-19l-2-2q3-4%206-3'/%3e%3cpath%20fill='%23233d3b'%20d='M212%200h23l5%201%203%207%201%202v8q-7-1-13-6l-2-1-5-3-10-6-2-1z'/%3e%3cpath%20fill='%23998a4f'%20d='M137%200h3l3%205%206%2010%202%202%201%202%208%2011-1%202-4-5%201%2044v20l7%201v1h-7v20h-2l-1-72c0-15-3-24-13-35l-3%207-1%202-1%202-2%208h-1q1-13%205-25'/%3e%3cpath%20fill='%23384944'%20d='m200%20217%203%204%201%203v2l9%2033%201%207q-5-1-8-6l-6-8z'/%3e%3cpath%20fill='%23d2c16d'%20d='M283%20444q4%203%205%207l1%203%201%202v3l4%2010q1%203%204%205l4-10q1%206-2%2010l-4%203-4-2-1-7h-3q-9-8-15-18v-3l5-2%203-1z'/%3e%3cpath%20fill='%2354664e'%20d='M271%20469h2l1%203h5v-2l8%201q5%203%205%208v3l3%201%201%205h-4l-1-5h-3l-1%205h-7v-4h-2v-2l-3-1-3-4-1-3z'/%3e%3cpath%20fill='%23998a4f'%20d='m279%20171%204%204v4l3%208%204%2014-2-1v-3h-2l-1%203-3%205-1%207%201%203v3l1%203%202%2011v11l-2-2-1%203-3%2010-1%204c-8%2026-8%2026-14%2032l3-10%204-10%202-6c8-19%2010-33%205-53l-4%202%208-12q3-4%203-9l-3-8q-3-6-3-13'/%3e%3cpath%20fill='%23383636'%20d='m56%20151%205%201%203%201%202%201%201%203h2l1-2%207%201q5%204%205%2010h-2l-10%201-6-2-6-2-2%201-4%201-3-3h3l1-2h3v-3h-2v-2h2l-1-3z'/%3e%3cpath%20fill='%23d2c16d'%20d='M237%20429q5%201%206%204l3%204%201%202%2016%2030-7%201-5-6-2-3c-5-8-5-8-6-13q7%205%209%2012l4%207-5-12-2-3-11-17-2-3z'/%3e%3cpath%20fill='%232f5a59'%20d='M16%20397h1l1%2010v3l-1%2015-2%202-1-5-2%205-7-1q-2-10%204-18l1-3%204-5z'/%3e%3cpath%20fill='%2354664e'%20d='M92%20341q7%200%2012%205l3%202q4%205%205%2012-4%203-7%201l-3-4-2-1v3l-5-1-1-6-1-4z'/%3e%3cpath%20fill='%23474944'%20d='M318%20324h1l1%2020v12l-7-1v-2l-3-1-2-9h2v-3l-1-5%209%201-1-2v-3l-1-5z'/%3e%3cpath%20fill='%23998a4f'%20d='m185%20161%204%205%202%202q10%2012%2010%2029l-4%207h-1l-3-12-1-4-2-6-1-6-1-3-2-1%201-1-1-5-1-3z'/%3e%3cpath%20fill='%23384944'%20d='M47%20460q4%202%204%206c3%2012%201%2029-3%2041h-6v-2q5-23%205-45'/%3e%3cpath%20fill='%232c4b45'%20d='m199%200%203%2012%201%204%201%203v3l1%209%201%204q-4-3-5-7l-3%203q-5-15-5-30z'/%3e%3cpath%20fill='%23998a4f'%20d='M207%20449q4%202%206%205l2%202%202%202%201-3q10%2012%2015%2026l-1%202-4%201-1-2-1-3-2-3-4-6-3-7h-2l-3-4-9-9z'/%3e%3cpath%20fill='%2325494a'%20d='M140%20378q3%202%203%206l-1%202h2l1%204%201%202%202%2010h-16z'/%3e%3cpath%20fill='%23998a4f'%20d='M167%20476q3%201%204%205l12%2019%202%206h9v1h-34v-1h14l1-2v2h4q-5-11-14-20l-1-2%201-3v-3z'/%3e%3cpath%20fill='%2354664e'%20d='M58%20354q6%204%208%2010l-2%202-4%205-8%203%201-7h-1l-3-3%201-5h2v-3q3-4%206-2'/%3e%3cpath%20fill='%23213532'%20d='M155%2053q4%205%203%2011h-2l1%203%202-2%207%2027-10-1q-2-12-1-25z'/%3e%3cpath%20fill='%23998a4f'%20d='m238%2020%203%201-4%2040%202%201q10%207%2019%2017l2%202v3l-12-11-12-10-2%2014h-2l2-21%202-14%201-6v-5z'/%3e%3cpath%20fill='%23548470'%20d='M99%20236v6l-8%203q0%204%203%208v4l-4%203-1-2-2-3-2-3-4-5q0-4%203-8l3%201%205-2z'/%3e%3cpath%20fill='%23a16666'%20d='M81%20130h14v2h-2q-13%200-21%208-2%204-6%204l-11-2h-2l2-5q3-2%208-2l8%202v-3q3-7%2010-4'/%3e%3cpath%20fill='%23998a4f'%20d='m66%20334%2013%202%204%203%201%207-6%207h-2l-3-5-2-5-3%201-3-5%204%201z'/%3e%3cpath%20fill='%232c332d'%20d='m90%20299%202%208%201%202%201%207-13-1v-5l-2%201v-9q5-4%2011-3'/%3e%3cpath%20fill='%23734a65'%20d='M308%20446h2l-1%203-1%207h-3l-7%2019-1-2-2-1q-3-3-4-7l-1-4-1-8%204-1%201%203%201-2h2l1%2015%203-6%201-4v-5l-1-2%204%201%201-3z'/%3e%3cpath%20fill='%23384944'%20d='M48%20437h7l1%207%201-7h4l-3%2017-8-5%201%202v6l-2-4-2-3q-2-6%201-13'/%3e%3cpath%20fill='%23998a4f'%20d='m4%20486%202%203%204-1-1%206-4%201v4l2-1%207-4%203-1%202-1%203-1%207-1-9%204-5%202-3%201-3%206v4H0v-9q0-7%204-12'/%3e%3cpath%20fill='%23356962'%20d='m81%20471%201%203%202-1q8-1%2015%201h10l11%203-28%203h-9l-5-1z'/%3e%3cpath%20fill='%232f5a59'%20d='M103%20497h29l-1%202-8%201h-3l-17%201%201%203H93l-3-1-2-5z'/%3e%3cpath%20fill='%2365b3b5'%20d='m140%20436%204%202-1%203h9l-3%203%202%202h-3l-5%203q-9%200-16-6v-1l10-1%201-4z'/%3e%3cpath%20fill='%232f5a59'%20d='m76%20384%202%202-1%208h2l2-9h1v3l2%206-2%209H69l1-2%201-7v-6h1l1%205h2z'/%3e%3cpath%20fill='%23384944'%20d='M158%20429v2h2l-2%204h-3v2h5v2q-8%203-17%202l-1-6%204-2%202-2q5-3%2010-2'/%3e%3cpath%20fill='%23998a4f'%20d='m272%2052%207%2012q2%204%206%206v4h2v2l-9-4-7-3zm-40%20346h-4l-2%204-2%203h-2v3h-2l-1-2-5-1h-4l2-2-2-1v-3l-5-1v-1l12-1h10q3-1%205%202'/%3e%3cpath%20fill='%2354664e'%20d='m83%20346%202%201%202%208v20l-6-11-1-3-2-2-1-2%201-4z'/%3e%3cpath%20fill='%23d2c16d'%20d='M208%200q8%201%2015%207l6%203%202%201%2012%207%203%202%2010%205%202%202%202%201v2l-13-6-2-1-5-2v6h-1v-4q0-4-3-6l-8-4-12-7-2-1-2-2-3-1-1-1zM85%20284h16v2l-6%201%205%201-1%202-6%201-15%203%202-3h4v-2l-7%201-1-5z'/%3e%3cpath%20fill='%2365b3b5'%20d='m69%20354%207%2011-1%207h-2v-2h-2l1%206-3-1-2-6-1-3-2-9h4z'/%3e%3cpath%20fill='%23734a65'%20d='m108%20227%203%203v2l-2%202-11-3-2-1-4-1q-6-1-7-3%2011-5%2023%201'/%3e%3cpath%20fill='%232c332d'%20d='M137%20255h6q2%205-1%2010h-1l-1-5-1%205h-9l-4-6%201-3z'/%3e%3cpath%20fill='%232f5a59'%20d='M67%20471q3%204%202%209v9l-1%2018h-6l1-10%201-3v-3l1-3%201-5%201-6z'/%3e%3cpath%20fill='%23998a4f'%20d='M41%20476h5q0%2016-4%2031h-3z'/%3e%3cpath%20fill='%2365b3b5'%20d='m88%20363%202%201%201%205v5h2q3%2011-3%2020h-1v-6l-3%202v-10l2-10z'/%3e%3cpath%20fill='%23998a4f'%20d='M205%20461q5%201%207%207l2%203%2010%2017-5%202v2h-2l-2-3-1-2-1-2%201-2%202%203-3-9-2-3-1-2-3-5-1-2z'/%3e%3cpath%20fill='%23384944'%20d='M130%20407h6l1%203h5v-3l5%201%201%204-24%201v2l-2-1-1-4h-2v-2z'/%3e%3cpath%20fill='%232c332d'%20d='m94%20277-3%202h2v5l-22%202q3-5%208-8%208-3%2015-1'/%3e%3cpath%20fill='%23548470'%20d='m127%20455%207%201v2h-3v2h6l-1%202-4%201-8%201H95l-1-2h3l9-1h10l4-1%207-1z'/%3e%3cpath%20fill='%232f5a59'%20d='m78%20452-2%2016%204-4-1%202-1%206v3l-3-1v-2l-1-3-2-1q-4-2-5-7l3-4%202-2q2-3%206-3'/%3e%3cpath%20fill='%23998a4f'%20d='M17%20415q4%202%204%205l3-2v25h-1v-11l-3-1-8-3%201-11h1l2%208zm89-8v-1h12v2l-44%204%202-5%2011-1z'/%3e%3cpath%20fill='%232f5a59'%20d='m158%20442%201%203-5%202%203%201v2h-10l2%202%202%204%202%201h-7q-2-3-2-7l-3-1%201-2h1v-1l6-1-1-2z'/%3e%3cpath%20fill='%23474944'%20d='m153%20253%202%201-3%204h3l1-2h2l-2%2011-1%205-4-2v-5l-1%203h-4q-1-4%202-8z'/%3e%3cpath%20fill='%23233d3b'%20d='m311%20218%204%205%202%203q2%204-1%207l-7%209q-2-4-1-10v-2z'/%3e%3cpath%20fill='%23d2c16d'%20d='m181%20443%205%209q2%205%206%209%207%208%207%2018h-3l-3-6-9-14-1-2%201-3-1-4q-2-3-2-7'/%3e%3cpath%20fill='%23734a65'%20d='M56%20208q3%200%205%202l1%201%201-2%203%206%202%2010-5%201-4-7-1-2-3-6zm81%20290-1%202-5%201%201%202-2%204h-10l-2-8h6l4-1z'/%3e%3cpath%20fill='%23998a4f'%20d='m265%20365%203%201q0%204-3%206l-2%202-6%205h-7l-1-3%205-4%203-2z'/%3e%3cpath%20fill='%2354664e'%20d='M265%20288q7%2016%2011%2033l1%202%201%2012q-3-5-4-11l-2-5-4-14v-3l-4-8-4%206v-5l1-2%201-2z'/%3e%3cpath%20fill='%2365b3b5'%20d='M86%20438h3l16%201v1l-14%201H64l-1-2z'/%3e%3cpath%20fill='%2354664e'%20d='m217%20284%202%201%201%208%202%205%201%2014-3-3v-2l-3-1q-3-10%200-22'/%3e%3cpath%20fill='%23383636'%20d='m132%20161-7%2013-8-3q3-7%2010-9z'/%3e%3cpath%20fill='%23998a4f'%20d='M102%20153v15l-9-2%202-10q3-3%207-3'/%3e%3cpath%20fill='%23384944'%20d='M40%20469h1v26l-2%2012h-2v-18l1-6v-4z'/%3e%3cpath%20fill='%23998a4f'%20d='m221%20441%209%207%202%202%2010%2014%204%205%201%205q-5-1-7-7z'/%3e%3cpath%20fill='%232c332d'%20d='m77%20195%2011%201-2%209H75l2-4z'/%3e%3cpath%20fill='%23a16666'%20d='m316%20454%204%201v10l-7-3v2h-9l1-3%204-1%201-2h3l2-1z'/%3e%3cpath%20fill='%23998a4f'%20d='m182%20158%202%201-4%2019-1%202q-1%207-5%2013h-1l4-17z'/%3e%3cpath%20fill='%23233d3b'%20d='M129%20371h1q1%2016-3%2031h-4z'/%3e%3cpath%20fill='%2354664e'%20d='M94%20290h3v5l-1%203v14q-3-4-4-9l-1-2-1-6-1-2v-2z'/%3e%3cpath%20fill='%23998a4f'%20d='M6%20190h1v85H6zm314%20219v16l-1-2-2-1q-4-3-5-7l1-4z'/%3e%3cpath%20fill='%2354664e'%20d='M282%20185q4%204%204%2011l-7%2010h-3l1-5v-2l3-4v-2h3l-1-4-2-1v-2z'/%3e%3cpath%20fill='%23548470'%20d='m29%20490-9%204-5%202-3%201-3%206v4H0l6-10%206-2%204-2q6-3%2013-3'/%3e%3cpath%20fill='%23474944'%20d='m290%20340%201%202%203%201%202%2012-5-1v2h-2v-15z'/%3e%3cpath%20fill='%2365b3b5'%20d='m124%20413%2045%201q-3%203-7%203h-5l-5-1h-10l-4-1h-14z'/%3e%3cpath%20fill='%23a16666'%20d='M261%20326h2v2l3%208%201%2017-4-2v-2h2l-1-6v-3l-2-7h-3z'/%3e%3cpath%20fill='%23356962'%20d='M7%20478h2v8l3-2%204-2%202%201q-6%205-13%207l-1-3-3%205-1-4%203-5%202-3z'/%3e%3cpath%20fill='%23734a65'%20d='M123%20463v2l-5%201v3l2%201h-2l-1%204h-4v-4l-2-1v-5h5l3-1z'/%3e%3cpath%20fill='%23998a4f'%20d='m3%20459%201%2015v6l-1%203q0%202-3%205c-1-21-1-21%203-29'/%3e%3cpath%20fill='%2365b3b5'%20d='m296%2031%209%2015%201%203%202%203%201%202%202%208q-12-13-15-31'/%3e%3cpath%20fill='%23d2c16d'%20d='M232%20398h-4l-2%204-2%203h-2v3h-2q-3-4-1-8%202-3%207-4%205%200%206%202'/%3e%3cpath%20fill='%23998a4f'%20d='M102%20258h3l-4%208-8%202%201-5h2l2-4z'/%3e%3cpath%20fill='%23a16666'%20d='M137%20242q7%201%2012%204v6l-5%204-2-1%202-4-1-4-5-2z'/%3e%3cpath%20fill='%23d2c16d'%20d='M186%20145h1v2q-3%209%202%2017l2%202%202%204h2l1%205c-5-5-12-11-13-18l1-6%201-3z'/%3e%3cpath%20fill='%2365b3b5'%20d='M48%20301h1l1%2014%202-7h2l-1%203-1%204-1%204%201%205%202%202h-3v-2h-2l-1%202-1-13v-2l1-3z'/%3e%3cpath%20fill='%23548470'%20d='M119%200h5l-3%206-2-3-4%2016-1%202-2%205h-2l5-16%201-3z'/%3e%3cpath%20fill='%23998a4f'%20d='M208%200q9%201%2016%207l3%202%209%206h-5l-3-2-4-2-1-1-6-3-9-6z'/%3e%3cpath%20fill='%23d2c16d'%20d='M302%20464q1%206-2%2010l-4%203-4-2-1-4q3-1%207%203z'/%3e%3cpath%20fill='%2365b3b5'%20d='M6%20397h1l-1%2019-2%201v-7l1-3z'/%3e%3cpath%20fill='%23548470'%20d='m29%20490-9%204-3%201h-4q7-5%2016-5'/%3e%3cpath%20fill='%23998a4f'%20d='M107%20324h2l3%2012q-4-3-5-8z'/%3e%3cpath%20fill='%23548470'%20d='M47%20294h2l-1%2012h-1zm-21%2019%203%203%201%202%201%203-1%205z'/%3e%3cpath%20fill='%23d2c16d'%20d='M126%20351h2l-1%207h-2v-6z'/%3e%3cpath%20fill='%23548470'%20d='M15%20325c7%203%207%203%208%205l-2-1-6-2z'/%3e%3cpath%20fill='%23356962'%20d='m29%20458%202%201-4%203-2-1z'/%3e%3cpath%20fill='%23a16666'%20d='M297%20351q3%202%202%205v2q-2-2-2-5z'/%3e%3cpath%20fill='%23356962'%20d='M17%20505h5v1h-5zm-4%201%204%201Z'/%3e%3cpath%20fill='%23998a4f'%20d='m286%20462%204%202-1%203-3-3z'/%3e%3cpath%20fill='%23548470'%20d='M32%20317h1v6l-2-1z'/%3e%3cpath%20fill='%23998a4f'%20d='M144%20255h2l-1%205-2-4z'/%3e%3cpath%20fill='%232c332d'%20d='m65%20312%201%203h-3z'/%3e%3cpath%20fill='%23998a4f'%20d='m90%20278%202%201-4%202zm219%20141%203%203h-3zm-94-125h1v6h-1zm-58-33%201%202-2%203z'/%3e%3cpath%20fill='%2354664e'%20d='M7%20505h2v2l-3-1zm110-187%201%202-2%202z'/%3e%3cpath%20fill='%23998a4f'%20d='m217%20455%202%201-1%202z'/%3e%3cpath%20fill='%23548470'%20d='m32%20456%202%201h-3z'/%3e%3cpath%20fill='%2365b3b5'%20d='m41%20429%201%204ZM0%20408l1%204Z'/%3e%3cpath%20fill='%23998a4f'%20d='m149%20370%201%203-2-1z'/%3e%3cpath%20fill='%2365b3b5'%20d='m18%20506%203%201Z'/%3e%3cpath%20fill='%23a16666'%20d='M303%20365h2l-1%202z'/%3e%3cpath%20fill='%23548470'%20d='M77%20323h2l-1%202zM18%20481l2%201Z'/%3e%3c/svg%3e",
	reef: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='507'%3e%3cpath%20fill='%232ebdeb'%20d='M0%200h320v507H0z'/%3e%3cpath%20fill='%23207699'%20d='M0%200h320v158l-8-1-1%203h-3l1-4h-2v-4c-7%201-7%201-11%204l-1%204h-2l-2-4h-6v2l-4%201-8%202-3-2-8-1-1%204q-12%203-25%202l-28%201h-21c-25%200-25%200-27-2q-7-2-15%201l-2%202%203%202h-4q-6%201-11%206l-4%208h-2v3l6-4%202%201-4%203q-8%206-9%2015-3%208-9%2015-1-6%202-14c3-12%200-19-6-30l-4-4-1-4-3%201H88l-1-1c-7%200-7%200-12%203l-5-1v-2l-4%201q-18%202-37%200l-27%201v-17l59-1h5l27%201v-2l4%201%201-2%203%206%202-4%2013%201v-4h2l1%202-1-5%201-5q3%206%203%2011h2v-2h2l1%202%203-7%201%209%205-6%202%201-2%203h40v-9h2v9h9v-8h1v8l4-1%2026%201v-7l-1-21h-2l-1-7-1-8-2-1v-2l-3%201-2%2010v5l-1%204-3-9-5%203-3-6-2%204h-3v-3h-2v-2l-4%204-2%202c1-5%201-5%204-8l1-9h-3l-3%209h-1v-5l-3-1-2-5v7l-4-3-1%209-2-1-1-7-8-2-3%2023q-3-6-2-13V98l-1%206v4h-3l-1%204-4%209-2-20-3-1-1%207h-2l-2-2-5%2016h-1l-1-10-3%201-2-7-2-1-1%208c-1%208-1%208-3%2010l-3-11-3%201-1%209-4-9-2-6-3-1%201%204v15q-4-6-5-12h-2l-2%207h-2l-1-9h-2l-3%207h-1l-1-12-5-1-1%205-1%206-1%206q-1%206-3%207v-15c-1-5-1-5-4-8l-2%2012h-2l-1-2-2%2016-4-14-2-12-2-1%201%2022q-4-5-5-11h-2l-1%2016h-2l-1-17-3%201-2%2012h-1v-20l-2-1-2%207h-1l-1-22-2%201-2%2010-2%205-4%2021h-1l-2-23-2%201v-3h-2l-1%2015-3-8-2%201-1%205-4-9-2-1z'/%3e%3cpath%20fill='%2348c6e8'%20d='m308%20152-1%204h2l-1%204h3l1-4%208%202v69l1%2021-1%207v10c-4%203-4%203-8%203l2-4h-2l-1-2-2%205-2%201v-6l-4%203-1-2-1%202-5%201-1-4h-3v-2l-2%203-3-1-3-6-4%204v-5h-2l-1%203h-1l-1-6-6%203-1-4-2%204v-4h-2l-1-2-2%204-3-5-4%202-2-1%201%208h-2l-3-6v6h-2l-3-4-2%201-2-6-2-1-1%207-1-3h-2l-1%202-2-5h-2l-2%204-4-2v5l-2%201v2l-6-1c1-6%201-6%205-10l1-6c-3%203-3%203-5%209h-3l-2%204-1-12%204-7v-2h-2l-2%204v-6h-2v12l-2%201v-4h-2l1%209c-4-3-4-3-7-8l7%2012%201%205h-2v5l-5-8%202%2011-3-1-2%205-4-4%201-6-3-2v3l-3-1v-2h-2l1%206-3-2%201%209q-7-3-7-5l-2%202-4-5h-1l-1%203-4-3%201%204-4-1v2l-6-3%201%203q-7-1-12-6l1%203-3%201%202%201v3l7%202v2h4v5l-6-1%202%204h-5v2l-12%201%205-3v-5l-5-3-1-11-4-2-2%204-3%203c-3%203-3%203-3%209l1%206-3%205h-1l-1-14h-5q-8%200-17-4l-4-4-5-3v-6l-3-1v-11l23-1v-2h-4v-2l13%203h19l4%201-3-4-7-8-6-4-2%202h-6v-2h-2l1-8h-2v-2l-4%204-2-1-1%202%201-8h-2l-1%205-3%203-2-9-2%209-8-10-6%202c-6-11-6-11-7-17h2l4%206v-9l3%203c1-6%201-6-2-12v-2h2l5%208-4-22-7%201H6q1-6%203-7h28l29-1h4v2c7-1%207-1%2010-3l10%201h13v4l4%202c8%2014%2010%2022%206%2037l-1%205-1%203q8-8%209-20c3-5%203-5%209-10l1-1-5%203-2%201%202-5h2l2-6%2012-9%205-5h14l1%201%2033%201h5l23-1h22l17-1%201-4c8%200%208%200%2012%202l5-2h6v-2l6-1q3%202%202%205h2l1-5c5-3%206-4%2012-3'/%3e%3cpath%20fill='%23963172'%20d='m214%20230%201%204-4%205-1%2012%201%201%201-2%203-1%202-6%204-3c-1%207-1%207-6%2013l-1%204%206%201-1-4%203%201v-5l4%201%202-4q3%201%205%204h3l1-4%203%201%202%205h3l1%204h2l-2-6h3l2%206h2l-1-8h2l2-4%201%203%202-1%202%205%202-4%201%203h2l1%202%201-2%202%201%206-1%201%206%201-2h2l1%204%204-5%203%208%202%201%202-4%202-1-1%204%203-1v5l5-1%201-4%202%203%203-4%201%207%203-6%201%203%204-2-2%204h-2v2l8-3v7h-3l-1%204-9%204%203%203v2l-9-1%201%205h-6l-1-4-5%201-3-1-1-5h-5l-1%201h-5l-2-2-8%201%204%204v3h-10l-1-3h-2l-1%203h-2l7%205%207%208-5-2c-5-1-5-1-12%201l-1-2-5-1%202-1v-2l8%202-3-6v-2h-9l1-5-4%201q-6%201-12-1l-1%204-16-2%207%207v-4h2l1%202h3l-2%204%205%201-1%204v3h-17l-1%205h-15v-4l-3%202q-7%204-14%201h-3v-2h-4l-1-6h-7v3h-7l1-5-6%202%201-4-6%202%201-4-4-1%201-3-9%202-3%209-6%202%201%202%201-1h5l1%208-1%205h5l4%208%205%201%201%202%205-5%204%202v12l-7%205q-4%201-6%207l-1%201h4l4%2010c-5%202-5%202-10%201l-4-2c-5%204-5%204-6%208l5%202%201%201q-1%2013-6%2026l9-21c2-6%202-6%206-10h8l2-7%205-1%202%203%204-1%202%204q-5%205-11%205l-1%202%203%201q0%2011-7%2021l-3%207-3%207-6%2014h-6l-3%201%201%203h-5l-4%201-1-1h-5v-2l-6-2%201-5%201-6v-7l1-9-2%207-1%204-2%209-4-1-3%203h-2l-3%208h-2l-2-3-3-4h-4l-2%203-3-7-1%2017c-5%200-5%200-9-3h-2l-3-3h-2l-8-28-6-22-3-13%209%2043-4-1-1-2-6-1-5-10-2-6-2-4%201%209v10l-6%201h-4q-6-15-10-31l-6-21-3-1-1-7%203-3v-8l2-2-2-5%202-1%201-4%204%202v-14h2l1%206-2-15%201-2%205%204%202-14-3-4-2-6%204%202-1-8%201%202h2l1-3%201%204%205%208h-2v5l5-8%202%201-5%2010-3%207%203-1-4%207q-5%207-5%2015l4-3-2%208%207-1-1-5%203-3%204-5%203-2-1%206%204-2-2%207h2l2-4%204-5%205-8c1%203%201%203-1%208q6-1%207-6l1-9v-8h2v-5l3-7h2l1-3-1%208%204-2-1%2011%207-6-1%208%203-2%203%201q-7%209-18%2014v1h2v2l-7%202-4%205%206-1q-5%205-12%207l-6%203h-2v2l3%201v9l1%205%201%2010%205-2h3l-2-3v-3h3v-5c4%203%204%203%206%209l3-1%202-4h3v-11c7-6%2011-5%2020-5v-5l-4-4%206-3-3-10%203-1%201-3%206-1%201-3%204-1%202%202v-6c2-7%202-7%205-9l5%201%202%2013c2-4%202-4%201-10%200-6%200-6%204-11l4-3%201-2%205%202v11l5%202%201%206-3%202%208-1%201-2h4l-1-3%206%201v-5h-4l-1-2-6-2v-3l-3-1%202-2%201-2%209%205%203%201-3-5%208%205-2-4%205%202-1-5%205%204-1-5q3%200%207%207l2-2%202%203%202-2%202%203-1-8%203%202v-5h2l3%203-1-4%202-1%203%204-1%206%202%203%203-5%202%201-2-11%205%207v-4l2-1-7-11-1-5c4%203%204%203%207%208v-8h2l1%203%201-12h2l1%204%201-2h2z'/%3e%3cpath%20fill='%231b93c7'%20d='M153%2087h1v31l1-8%203-12h7l3%205%201-4h4l1-5%202%204%203%203%201%203%203-10%201%203h2c0%207%200%208-4%2014l3-3h2v2h2v3h3l1-5%205%205%204-1%202%206c3-3%203-12%203-16l4-1v2l3%201%201%2015h2l1%2028h-40v-9h-2v9l-24%201-5-1h-11v-3l-4%205-2%202v-8l-2%205-2-1v-2h-2v2h-2l-2-8v8l-2-1v-2h-2v4h-13l-2%204-4-5-4-1v2H2v17l7-1-3%207h25l8-1h45c5%2016%205%2016%205%2024l-6-10h-2l2%203q3%208%201%2014l-3-5v10l-5-8h-2l8%2016%205-3%202%205%203%204h3l1-8q4%204%204%2010l3-7h2v6h2l2-3h2v2h2l-1%208h2v2l9-3c13%2010%2013%2010%2015%2017h-23l-1-1-10-2-2-1v2h4v2H70c-47%200-47%200-60%206l-1%204H7l1%203-3%204-5-1V106l3%201%202%206%202-3h2l2%205%202-12%205%202%201%209%201%205v4l1-5%201-6%206-21h2q3%2010%202%2019l2-4%203%201v16l1-8%204-1q2%209%201%2017h2v-7l1-9h2l4%209v-4c-2-13-2-13%200-16l3%201%204%2022%201-6c1-6%201-6%203-8v4h2v-7l2-5%204%203%201%209v9l1-6%203-17%207%202%201%209%203-5%203%201v9h2l1-7h4l3%209v-16l4%201%204%2012%202-7h4l3%209%201-7%202-9%203%201%202%206h2l2%206%204-12h3v2h2v-9q7%207%207%2019l4-9h3l-1-12h1z'/%3e%3cpath%20fill='%231e4254'%20d='m258%2034-2%2035v5l-4%2023%204%203%208-23%205-11%201%203%204-3-7%209-3%209-1%204-1%204%208-8%202%201-3%203-3%203-4%204-6%207%202%206c4%2014%204%2014%204%2020h2l1-5%203-10%202-6%203-6%202%202%203-7h2l1%2013%202-5h3l1%201%208-26q1%208-2%2016l-2%207-2%205h7l1%203v5l1%204%202%205%201-7%205-15h4q3%205%202%2011l1%202%202-7c2-8%202-8%205-11v61l-8-1-1%203h-3l1-4h-2v-4c-7%201-7%201-11%204l-1%204h-2l-2-4h-6v2l-4%201-8%202-3-2-8-1-1%204q-12%203-25%202l-28%201h-21c-25%200-25%200-27-2q-7-2-15%201l-2%202%203%202h-4q-6%201-11%206l-4%208h-2v3l6-4%202%201-4%203q-8%206-9%2015-3%208-9%2015-1-6%202-14c3-12%200-19-6-30l-4-4-1-4-3%201H88l-1-1c-7%200-7%200-12%203l-5-1v-2l-4%201q-18%202-37%200l-27%201v-17l59-1h5l27%201v-2l4%201%201-2%203%206%202-4%2013%201v-4h2l1%202-1-5%201-5q3%206%203%2011h2v-2h2l1%202%203-7%201%209%205-6%202%201-2%203h40v-9h2v9h9v-8h1v8l4-1%2026%201v-7l-1-21h-2l-1-7-1-8-2-1v-2l-3%201-2%2010v5l-1%204-3-9-5%203v-4l-1-4-3-2c1-5%201-5%207-10l6-1V79l4%201c2%206%202%206%202%2014l2%202%203%2012%202-3v4h2l2-16-2%204q-3-15%206-28h2v5l-1%201c0%208%200%208%202%2011h6q3-1%202-7c0-6%200-6-3-10h-3v-2h-2l7-11%203-4%203-3%204-4c9-11%209-11%2011-11'/%3e%3cpath%20fill='%23393b50'%20d='M0%20337q4%209%206%2019l1%204%2014%2058%203%2011%202%205%203%2013%2017-2q13-3%2025-3l10-2%2024-3%2031-4%2025-3%205-1h4l6-2h6q-1%202-7%203l9%201%201%205%204%201%203%202v2h4l4%201%202%203-3%204c2%2010%202%2010%206%2014l11%205c-7%207-22%209-31%209l-27-2-1%202v-2h-6l1%204-7-1-2%204-3%202%206%202v4q-18%201-35-7l1-4-8-2-2-3-1%202h-2l1%208-13%201v-3l-5-1%201%205-9%202%201-8-10-3-1-2-5%201%202%203h-4l2%205-1%201%204%202v5l-20%202%201%2013H0z'/%3e%3cpath%20fill='%23215767'%20d='M194%200h126v92q0%208-4%2014l-3%2013h-1l-2-17h-4l-2%208-4%2016q-5-9-4-19l-4%201-3-1%204-18-5%2018-4-3-3%2011h-1V96c-3%203-3%203-5%209l-2-3-6%2015-1%204-1%204-1%203h-2l-2-10-2-5-1-10-2-1%208-9%207-8-8%208q-1-7%202-14t9-11l-4%202v-3l-9%2023-4%2010-5-2%201-7q5-29%206-58l-11%2010-3%203-3%203-3%203%207-14%202-5%202-3-6%209q-1-10%203-19l1-5%203-10q-6%2016-10%2034l-6%2017-3%207c-4%204-4%204-10%205l-2-1v7l-3%2013-6-9-16%203z'/%3e%3cpath%20fill='%233f647d'%20d='M100%200h94v57l1%2023%204-1c5-2%205-2%2011-2l5%209%204-19h4c4-1%204-1%209-7l4-10%202-4%202-9%2010-36q2%2010-3%2019l-4%2015%201%201%205-8%201%202-5%2010-4%206-2%204%205-5%2014-14%202%201-3%203q-15%2015-27%2032l6%202q5%207%203%2015l-3%203h-6c-3-4-3-4-3-12l2-6h-2l-2%205-3%206v13l2-1q0%209-3%2017l-5-1-1-4-3-9-1-9-2-6h-3l1%203v11c-3%202-3%202-8%202l-5%205v4l3%202v5l-4-3-1%204h-3v-3h-2v-2l-4%204-2%202c1-5%201-5%204-8l1-9h-3l-3%209h-1v-5l-3-1-2-5v7l-4-3-1%209-2-1-1-7-8-2-3%2023q-3-6-2-13V98l-1%206v4h-3l-1%204-4%209-2-20-3-1-1%207h-2l-2-2-5%2016h-1l-1-10-3%201-2-7-2-1-1%208c-1%208-1%208-3%2010l-3-11-3%201-1%209-4-9-2-6-4-1c1-5%201-5%205-10%204-2%204-2%2012-2l-1-4-3-17-1-6-5-33%205%204-5-5q-4-15-6-32'/%3e%3cpath%20fill='%23bf6a82'%20d='m214%20230%201%204-4%205-1%2012%201%201%201-2%203-1%202-6%204-3c-1%207-1%207-6%2013l-1%204%206%201-1-4%203%201v-5l4%201%202-4q3%201%205%204h3l1-4%203%201%202%205h3l1%204h2l-2-6h3l2%206h2l-1-8h2l2-4%201%203%202-1%202%205%202-4%201%203h2l1%202%201-2%202%201%206-1%201%206%201-2h2l1%204%204-5%203%208%202%201%202-4%202-1-1%204%203-1v5l5-1%201-4%202%203%203-4%201%207%203-6%201%203%204-2-2%204h-2v2l8-3v7h-3l-1%204-9%204%203%203v2l-9-1%201%205h-6l-1-4-5%201-3-1-1-5h-5l-1%201h-5l-2-2-8%201%204%204v3h-10l-1-3h-2l-1%203h-2l7%205%207%208-5-2c-5-1-5-1-12%201l-1-2-5-1%202-1v-2l8%202-3-6v-2h-9l1-5-4%201q-6%201-12-1l-1%204-16-2%207%207v-4h2l1%202h3l-2%204%205%201-1%204v3h-17l-1%205h-15v-4l-3%202q-7%204-14%201h-3v-2h-4l-1-6h-7v3h-7l1-5-6%202%201-4-6%202%201-4-4-1%201-3-9%202-3%209-6%202%201%202%201-1h5l1%208-1%205h5l4%208%205%201%201%202%205-5%204%202v12l-7%205q-4%201-6%207l-1%201h4l4%2010c-5%202-5%202-10%201l-4-2c-5%204-5%204-6%208l5%202%201%201q-1%2013-6%2025l-5-1-2%202c-2-3-2-3-2-8l3%201c1-13%201-13-1-16l5%201-2-4-5-1v-2l-3%201%204-23%201-11c-5-3-5-3-12-2l-7%201c-3%203-2%2012-2%2015v7l-1%203-4%201%201%206h-6v-6l3-3-5-8v-5l-2-3v-3h2v-3l3%201%202%207-2%203v3l3-5%201-1c0-12%200-12-2-17l-3%201v-4c-12%201-12%201-17%204l-1%2013-1-2-4%201%201-2h3v-11c7-6%2011-5%2020-5v-5l-4-4%206-3-3-10%203-1%201-3%206-1%201-3%204-1%202%202v-6c2-7%202-7%205-9l5%201%202%2013c2-4%202-4%201-10%200-6%200-6%204-11l4-3%201-2%205%202v11l5%202%201%206-3%202%208-1%201-2h4l-1-3%206%201v-5h-4l-1-2-6-2v-3l-3-1%202-2%201-2%209%205%203%201-3-5%208%205-2-4%205%202-1-5%205%204-1-5q3%200%207%207l2-2%202%203%202-2%202%203-1-8%203%202v-5h2l3%203-1-4%202-1%203%204-1%206%202%203%203-5%202%201-2-11%205%207v-4l2-1-7-11-1-5c4%203%204%203%207%208v-8h2l1%203%201-12h2l1%204%201-2h2z'/%3e%3cpath%20fill='%231fabe6'%20d='m308%20152-1%204h2l-1%204h3l1-4%208%202v39l-54%207h-7l-30%202q-48%202-96%2011l-8%201-2%204-2%202-4-1%201-4-4%202%201-6h2l4-15h-2q1-8%206-13l4-3%201-1-5%203-2%201%202-5h2l2-6%2012-9%205-5h14l1%201%2033%201h5l23-1h22l17-1%201-4c8%200%208%200%2012%202l5-2h6v-2l6-1q3%202%202%205h2l1-5c5-3%206-4%2012-3'/%3e%3cpath%20fill='%2327b6e7'%20d='M153%2087h1v31l1-8%203-12h7l3%205%201-4h4l1-5%202%204%203%203%201%203%203-10%201%203h2c0%207%200%208-4%2014l3-3h2v2h2v3h3l1-5%205%205%204-1%202%206c3-3%203-12%203-16l4-1v2l3%201%201%2015h2l1%2028h-40v-9h-2v9l-24%201-5-1h-11v-3l-4%205-2%202v-8l-2%205-2-1v-2h-2v2h-2l-2-8v8l-2-1v-2h-2v4h-13l-2%204-4-5-4-1v2H42l-8-1q-4-6-5-13h-2l-1%202c-5-6-5-9-5-17l2-10%201-5%204-13h2q3%2010%202%2019l2-4%203%201v16l1-8%204-1q2%209%201%2017h2v-7l1-9h2l4%209v-4c-2-13-2-13%200-16l3%201%204%2022%201-6c1-6%201-6%203-8v4h2v-7l2-5%204%203%201%209v9l1-6%203-17%207%202%201%209%203-5%203%201v9h2l1-7h4l3%209v-16l4%201%204%2012%202-7h4l3%209%201-7%202-9%203%201%202%206h2l2%206%204-12h3v2h2v-9q7%207%207%2019l4-9h3l-1-12h1z'/%3e%3cpath%20fill='%231e4254'%20d='M317%20272h3v45l-23%201%201%202%201%2010%201%206c1%2013%201%2013-1%2016l-8-1-3-10-1-6-2-17h-4l2%205%205%2026h-6q-5-5-7-12l-2-4-1-7h-13v-5h-8l-5-1q-4%201-6-2l1-3h-6l-2%205h-6l-1-4-2%201%203%206-3%201v6c-4%202-4%202-9%201l-1-2-5%202-7-1h-6l-3%203h-14l-5%201h-1v1l-19%201v-13l-4-2-6%205-1-3h-5l-3-8h-6l1-13-7%201-1-3%207-3%202-8q7-3%2013-3l-2%201-1%203%203%201-1%204%206-2-1%204%206-3%201%204-1%201%206%201v-3h7l2%204-1%202h4v2l6-1%201%201c6%200%206%200%2011-3h2v4l5-1h10l1-4h7c8%200%208%200%2010-2l-1-2h2v-3l-5-1%201-4-3%201v-3h-2v4l-7-5v-2l16%201%201-3%204%201%2012-1-1%205h9l3%208c-5%200-5%200-8-2v3l4%201%201%201%204-1c5-1%205-1%2011%202l-6-5-1-2-2%201v-2l-4-2v-2l3-3h2l1%202%2010%201-5-7c4-2%204-2%209-2l2%202h5l1-1h5l2%204-1%202h8l1%203%206%201-1-5%209%201-5-5%204-2%207-3z'/%3e%3cpath%20fill='%231fabe6'%20d='m56%20243%2034%201v1h-7l1%2011%202%201v2l2%202h-2v2l5%202%204%203v2l14%203-1%2010v6l-5-2-3%203-6%201-1%204-2%201%203%206-1%204-5%202%204%204-1%205-7%201c-8%201-8%201-12%204l-1%2011-3%201-3%205-3-1-3-7-1-1-1%204h-3l2%206-9%203-2-21v-4l-2-1v-2q8-5%2018-8h-2l-3-1%206-7h6v-2l-5%201%208-6%2012-10-7%203%202-5v-4l-6%207v-12l-3%201v-5h-2l-3%2012h-2v13c0%204%200%204-4%2010h-4l1-7-3%205-8%2011h-2l1-6-3%201v-5l-2%203-3%204h-2l-1%207-7%201%201-7-4%203q1-14%2010-23l-5%203%206-12%203-5-1-2-2%203-4%205%201-7-3-4-1-5-3%201%201%207-5-3%206%2010-3%2015-5-5%202%2018-2-1v-6h-2l1%2018-5-5-2%206%202%204-3%201%201%204v4l-3%203v7l4%201%204%2013%202%208c2%206%202%206%201%209-8-19-8-19-8-24H4q-5-14-4-30v-60h5l4-10c14-8%2031-7%2047-7'/%3e%3cpath%20fill='%231f2f3d'%20d='M0%200h44l1%2021%207%2089%201%2016q-4-5-5-11h-2l-1%2016h-2l-1-17-3%201-2%2012h-1v-20l-2-1-2%207h-1l-1-22-2%201-2%2010-2%205-4%2021h-1l-2-23-2%201v-3h-2l-1%2015-3-8-2%201-1%205-4-9-2-1z'/%3e%3cpath%20fill='%233f647d'%20d='M100%200h50l-1%2028v14l-1%207-2%2031h-2l1%2016-1%205v3l-2-1v-2l-3-1-1%207h-2l-2-2-5%2016h-1l-1-10-3%201-2-7-2-1-1%208c-1%208-1%208-3%2010l-3-11-3%201-1%209-4-9-2-6-4-1c1-5%201-5%205-10%204-2%204-2%2012-2l-1-4-3-17-1-6-5-33%205%204-5-5z'/%3e%3cpath%20fill='%23bf6a82'%20d='m255%20245%202%203%202-1%202%205%202-4%201%203h2l1%202%201-2%202%201%206-1%201%206%201-2h2l1%204%204-5%203%208%202%201%202-4%202-1-1%204%203-1v5l5-1%201-4%202%203%203-4%201%207%203-6%201%203%204-2-2%204h-2v2l8-3v7h-3l-1%204-9%204%203%203v2l-9-1%201%205h-6l-1-4-5%201-3-1-1-5h-5l-1%201h-5l-2-2-8%201%204%204v3h-10l-1-3h-2l-1%203h-2l7%205%207%208-5-2c-5-1-5-1-12%201l-1-2-5-1%202-1v-2l8%202-3-6v-2h-9l1-5-4%201q-6%201-12-1l-1%204-16-2%207%207v-4h2l1%202h3l-2%204%205%201-1%204v3h-17l-1%205h-15v-4l-3%202q-7%204-14%201h-3v-2h-4l-1-6h-7v3h-7l1-4%205-2v2h2v-3l4%201v-2c4-2%204-2%2012-2q5%205%204%206l4%202-1%201h6l3%201%205-1%207%202q0-7-3-12l1%205-4-2h-4l3%203-1%202-8-5v5l-8-4%202-9%2015-4v-4q1-6%203-7%203%203%202%207l10-3v-5l1-6-1-7%201%202%206%201-1-4%203%201v-5l4%201%202-4q3%201%205%204h3l1-4%203%201%202%205h3l1%204h2l-2-6h3l2%206h2l-1-8h2z'/%3e%3cpath%20fill='%231f2f3d'%20d='M194%200h66c-1%2031-1%2031-14%2044l-8%208%207-14%202-5%202-3-6%209q-1-10%203-19l1-5%203-10q-6%2016-10%2034l-6%2017-3%207c-4%204-4%204-10%205l-2-1v7l-3%2013-6-9-16%203-1-52z'/%3e%3cpath%20fill='%2330c5ea'%20d='m269%2066%201%203%204-3-7%209-3%209-1%204-1%204%208-8%202%201-3%203-3%203-4%204-6%207%202%206c4%2014%204%2014%204%2020h2l1-5%203-10%202-6%203-6%202%202%203-7h2l1%2013%202-5h3l1%201%208-26q1%208-2%2016l-2%207-2%205h7l1%203%201%209%202%205%201-7%205-15h4q3%205%202%2011l1%202%202-7c2-8%202-8%205-11v50h-97l2-21%202-15c0-5%200-5%202-8l4%201v-2h3l1%2014v-4c1-5%201-5%205-9l2%206%202-7h2v3h2v-7l6%202%208-23z'/%3e%3cpath%20fill='%231e4254'%20d='M0%20337q4%209%206%2019l1%204%2014%2057%2013%2052h7l-6%202%202%206c6%2022%206%2022%206%2030H0z'/%3e%3cpath%20fill='%2348c6e8'%20d='M153%2087h1v31l1-8%203-12h7l3%205%201-4h4l1-5%202%204%203%203%201%203%203-10%201%203h2c0%207%200%208-4%2014l3-3h2v2h2v3h3l1-5%205%205%204-1%202%206c3-3%203-12%203-16l4-1v2l3%201%201%2015h2l1%2028h-40v-9h-2v9l-24%201-5-1h-11v-3l-4%205-2%202v-8l-2-2%201-4-2-1q1-17%207-32l2%201v2h2v-9q7%207%207%2019l4-9h3l-1-12h1z'/%3e%3cpath%20fill='%231b93c7'%20d='m56%20243%2034%201v1h-7l1%2011%202%201v2l2%202h-2v2l5%202%204%204-15%201-1-4h-3l-2-5-3-3v-4H44l4%205v5l4%201-4%203%209%204-17%201h-4l-4%205-3%203%201-7-3-4-1-5-3%201%201%207-5-3%206%2010-3%2015-5-5%202%2018-2-1v-6h-2l1%2018-5-5-2%206%202%204-3%201%201%204v4l-3%203v7l4%201%204%2013%202%208c2%206%202%206%201%209-8-19-8-19-8-24H4q-5-14-4-30v-60h5l4-10c14-8%2031-7%2047-7'/%3e%3cpath%20fill='%231e4254'%20d='M119%20136q3%206%203%2011h2v-2h2l1%202%203-7%201%209%205-6%202%201-3%204q-5%208-7%2016l-2%204%204%202q4-5%205-12l2%201-2%209c5-3%205-3%207-8l2%201v-4q0-4%205-7c0%208-1%2010-6%2016l3%202h-4q-6%201-11%206l-4%208h-2v3l6-4%202%201-4%203q-8%206-9%2015-3%208-9%2015-1-6%202-14c3-12%200-19-6-30l-4-4-1-4-3%201H88l-1-1c-7%200-7%200-12%203l-5-1v-2l-4%201q-18%202-37%200l-27%201v-17l59-1h5l27%201v-2l4%201%201-2%203%206%202-4%2013%201v-4h2l1%202-1-5z'/%3e%3cpath%20fill='%23393b50'%20d='M96%20212q4%204%204%2010l3-7h2v6h2l2-3h2v2h2l-1%208h2v2l9-3c13%2010%2013%2010%2015%2017h-23l-1-1-10-2-2-1v2h4v2H70c-47%200-47%200-60%206l-1%204H7l1%203-3%204-5-1v-2h2v-31l2-2v2l7-1%2031-1v-3q14-5%2030-5l4%202q-5%204-11%205l-2%201%2023%202-1-4%205%202-2-5h7z'/%3e%3cpath%20fill='%23bf6a82'%20d='M182%20427q-1%202-7%203l9%201%201%205%204%201%203%202v2h4l4%201%202%203-3%204-1%205-18-1v-1l14-1-46-1v-1l-9-1v-1l4-1h4l5-1%208-3a500%20500%200%200%200-70%209l20-2h13c-10%207-29%206-41%208h-5l-5%201-4%201H58l-1%201-14%201q7-5%2017-6l-8%201-14%201-6%201c-3-6-3-6-3-10l42-7%2010-1%2024-3%2031-4%2025-3%205-1h4z'/%3e%3cpath%20fill='%231e4254'%20d='M132%200h18l-1%2042-1%207-2%2031h-2l1%207v9l-1%205v3l-2-1v-2l-3-1-1%207h-2l-2-2-5%2016h-1l-1-10-3%201-2-7h-3l-1-8%208-1v-8l-1-33%205%205h1l-3-4q-2-29%204-56'/%3e%3cpath%20fill='%23bf6a82'%20d='m25%20263%204%208%203%204h-2v5l5-8%202%201-5%2010-3%207%203-1-4%207q-5%207-5%2015l4-3-2%208%207-1-1-5%203-3%204-5%203-2-1%206%204-2-2%207h2l2-4%204-5%205-8c1%203%201%203-1%208q6-1%207-6l1-9v-8h2v-5l3-7h2l1-3-1%208%204-2-1%2011%207-6-1%208%203-2%203%201q-7%209-18%2014v1h2v2l-7%202-4%205%206-1q-5%205-12%207l-6%203h-2v2l3%201-1%2011-5%202-2%201-2-9h3l-2-4c-7%201-8%205-12%2010v2l5%203%201%207c-6%204-6%204-13%206v6h2c10%2037%2010%2037%2010%2043h-5q-6-15-10-31l-6-21-3-1-1-7%203-3v-8l2-2-2-5%202-1%201-4%204%202v-14h2l1%206-2-15%201-2%205%204%202-14-3-4-2-6%204%202-1-8%201%202h2z'/%3e%3cpath%20fill='%231f2f3d'%20d='m258%2034-2%2035v5c-3%2022-3%2022-5%2024l-1%207h-2v-3l-2%201-1%2012h-1l-2-11q-4%205-4%2012l-2%201v-15h-3v2l-5%202v10l-2%201-1-2h-3l-2%2015v10q-4-10-3-21h-2l-1-7-1-8-2-1v-2l-3%201-2%2010v5l-1%204-3-9-5%203v-4l-1-4-3-2c1-5%201-5%207-10l6-1V79l4%201c2%206%202%206%202%2014l2%202%203%2012%202-3v4h2l2-16-2%204q-3-15%206-28h2v5l-1%201c0%208%200%208%202%2011h6q3-1%202-7c0-6%200-6-3-10h-3v-2h-2l7-11%203-4%203-3%204-4c9-11%209-11%2011-11'/%3e%3cpath%20fill='%23bf6a82'%20d='m214%20230%201%204-4%205-1%2012%201%201%201-2%203-1%202-6%204-3c-1%207-1%207-6%2013v10h-2l1%2010-11%203-2-6c-2%205-2%205-2%2011-10%203-10%203-16%203v6h-2v3l6%202%201%201%201-4%204%202%204%201-3-4%208%201-1-5q4%201%204%207v7l-4-1-10%201-8-2%201-1-4-2%201-2-3-1-1-2-12%201v2l-4-1v3h-2v-2l-4%202-2-1-5%202%201-4-6%202%201-4-4-1%201-3-9%202-1%202-8-2q6-5%2014-4l8-2%201-2h4l-1-3%206%201v-5h-4l-1-2-6-2v-3l-3-1%202-2%201-2%209%205%203%201-3-5%208%205-2-4%205%202-1-5%205%204-1-5q3%200%207%207l2-2%202%203%202-2%202%203-1-8%203%202v-5h2l3%203-1-4%202-1%203%204-1%206%202%203%203-5%202%201-2-11%205%207v-4l2-1-7-11-1-5c4%203%204%203%207%208v-8h2l1%203%201-12h2l1%204%201-2h2z'/%3e%3cpath%20fill='%23b3daf0'%20d='m243%20256%203%2011h-3v2l4%201%204%204c6%204%206%204%2011%204v3l5%201q3%202%202%205h-10l-1-3h-2l-1%203h-2l7%205%207%208-5-2c-5-1-5-1-12%201l-1-2-5-1%202-1v-2l8%202-3-6v-2h-9l1-5-4%201q-6%201-12-1l-1%204-16-2%207%207v-4h2l1%202h3l-2%204%205%201-1%204v3h-17l-1%205h-15v-4l-3%202q-7%204-14%201h-3v-2h-4l-1-6h-7v3h-7l1-4%205-2v2h2v-3l4%201v-2c4-2%204-2%2012-2q5%205%204%206l4%202-1%201h6l3%201%205-1%207%202q0-7-3-12l1%205-4-2h-4l3%203-1%202-8-5v5l-8-4%202-9%2015-4v-4q1-6%203-7%203%203%202%207l10-3v-9l10%201v2h7l2%204%205-4h2l1-6z'/%3e%3cpath%20fill='%231f2f3d'%20d='M221%200h39v19q0%208-4%2016l-4%203-3%203-3%203-8%208%207-14%202-5%202-3-6%209q-1-10%203-19l1-5%203-10q-6%2016-10%2034l-6%2017-3%207-4%204-6-1z'/%3e%3cpath%20fill='%2342b4db'%20d='m101%20473%203%202v2l5-1%204%203-1%204%206%202%208%203%2012%201%208%201v-4l-9-2%206-2%201-4h7v-3h7l4-1%2013%201%209%201q-4%206-11%208l2%206%203%201%201%203h-9l-1-3v3l-20-1v2l4-1-1%202c-14%205-31%203-46%203v-2l23-2H87l-17-1h-4l-4-1-2-5%201-1-4-2v-6l2-1v-3l5-1%201%203%204-1%202%202%205%202-1%204%201%202h-2v2l6-2v-2h2v-3h5l1%203h12l-2-5%201-3h2z'/%3e%3cpath%20fill='%2327b6e7'%20d='m174%2094%202%204%203%203%201%203%203-10%201%203h2c0%207%200%208-4%2014l3-3h2v2h2v3h3l1-5%205%205%204-1%202%206c3-3%203-12%203-16l4-1v2l3%201%201%2015h2l1%2028h-40v-9h-2l-1-13-3%209h-1l2-16V95z'/%3e%3cpath%20fill='%2342b4db'%20d='m87%20162%203%201h13v4l4%202c9%2018%209%2018%208%2025h-2l-2%205q-2-5-1-11l-3%2013-2-4-2-3-1-8-2-11%201%207v8h-2l2%2015-2-1-1-8-5%203v-5h-2v5l-3-2-1%208%202%201h-2l-1%208-5%201c-6-11-6-11-7-17h2l4%206v-9l3%203c1-6%201-6-2-12v-2h2l5%208-4-22-7%201H6q1-6%203-7h28l29-1h4v2c7-1%2010-3%2017-3m221-10-1%204h2l-1%204h3l1-4%208%202v11h-46l-1%202-2-1-42-1h-31l-60%201v-2l5-3%203-3h14l1%201%2033%201h5l23-1h22l17-1%201-4c8%200%208%200%2012%202l5-2h6v-2l6-1q3%202%202%205h2l1-5c5-3%206-4%2012-3m11-55h1v50h-64l3-5%201-6%204%206%201-2h2l1-5h1l2%209%201-6%203%207h2v-5h2l1-8h1v7h2l1-5%207-2%201%202%204-5%204-5%203-15%203-7h4q3%205%202%2011l1%202%202-7z'/%3e%3cpath%20fill='%233f647d'%20d='M320%20197v13q-7%202-14%201h-12v2l6-1h14q-5%204-12%203l-38%202q-16%202-32%200l3-4h-2v-2l3-1%201-2h-5l1-2%2014-2h5l14-1%2014-2%208-1%2020-2z'/%3e%3cpath%20fill='%23bf6a82'%20d='M119%20136q3%206%203%2011h2v-2h2l1%202%203-7%201%209%205-6%202%201-3%204q-5%208-7%2016l-2%204%204%202q4-5%205-12l2%201-2%209c5-3%205-3%207-8l2%201v-4q0-4%205-7c0%208-1%2010-6%2016l3%202h-4q-6%201-11%206l-4%208h-2v3l6-4%202%201-4%203q-8%206-9%2015-3%208-9%2015-1-6%202-14c3-12%200-19-6-30l-4-4-2-6q3%200%207%207l2%202q-3-9-11-16l-3-6%202-3%203%206%202-4%2013%201v-4h2l1%202-1-5z'/%3e%3cpath%20fill='%23963172'%20d='m277%20304%203%2012h5v-8c4-3%204-3%209-3q5%207%204%2016l1%2014%201%207-1%2010-8-1-3-10-1-6-2-17h-4l2%205%202%207%203%2019h-6c-9-9-13-26-16-38l1-6c4-2%204-2%2010-1'/%3e%3cpath%20fill='%231b93c7'%20d='m54%20274%205%202-2%207h5c1%2012%201%2012-4%2019h-4l1-7-3%205-8%2011h-2l1-6-3%201v-5l-2%204-3%203h-2l-1%207-7%201%201-7-4%203q1-14%2010-23l-5%203q2-9%209-17h16zM13%20103l5%202%201%209c1%209%201%209%203%2013l4%208%203-1%205%2013%203%201H15l-15-1v-41l3%201%202%206%202-3h2l2%205z'/%3e%3cpath%20fill='%23215767'%20d='M212%20313h8l2%206%205%204-3%201v6c-4%202-4%202-9%201l-1-2-5%202-7-1h-6l-3%203h-14l-5%201h-1v1l-19%201%202-15%208-1%204-1%202%202h6l1-2%203%201h5l7%201-4-6q5%202%206%205l14%205-8-5c4-1%204-1%208%201v-3l4-1z'/%3e%3cpath%20fill='%231fabe6'%20d='M28%2091h2q3%2010%202%2019l2-4%203%201v16l1-8%204-1q2%209%201%2017h2v-8h1v6l2%2016h2l-1-3v-10q5%207%206%2016H41l-7-1q-4-6-5-13h-2l-1%202c-5-6-5-9-5-17l2-10%201-5zm205%2011h3l1%2014v-4c1-5%201-5%205-9l2%206%201-6h1v20c0%206%200%206-2%209h-1v7h2v8h-22l2-21%202-15c0-5%200-5%202-8l4%201zm87%20215v37l-9-1v2l-7%201-3-3-6-2%204-3-1-13-1-9v-8z'/%3e%3cpath%20fill='%23bf6a82'%20d='m149%20322%204%201%201%203-2%204h2l-1%205-5%203c-6%204-6%204-7%208l-1%201h4l4%2010c-5%202-5%202-10%201l-4-2c-5%204-5%204-6%208l5%202%201%201q-1%2013-6%2025l-5-1-2%202c-2-3-2-3-2-8l3%201c1-13%201-13-1-16l5%201-2-4-5-1%201-3h4v-5q0-7%204-13l3%201v-2h2c0%205%200%205-2%208q5-6%205-13l1-1v-5c0-6%200-6%203-10l3%201%201%203z'/%3e%3cpath%20fill='%231e4254'%20d='M210%200h11v37l1%2014v14l2%201-3%202-2-1v7l-3%2013q-3-3-4-7V69l-1-30z'/%3e%3cpath%20fill='%233f647d'%20d='M250%201q2%2010-3%2019l-4%2015%201%201%205-8%201%202-5%2010-4%206-2%204%205-5%2014-14%202%201-3%203q-15%2015-27%2032l6%202q5%207%203%2015l-3%203h-6c-3-4-3-4-3-12l2-6h-2l-2%205-3%206v13l2-1q0%209-3%2017l-5-1-1-4-3-9-1-9-5-9%205%201%204%208%204-19h4c4-1%204-1%209-7l4-10%202-4%202-9z'/%3e%3cpath%20fill='%231e4254'%20d='M100%200h31l-3%2032-1%205v5l-1%2011h-1l-1-13-1-7-1-8h-2v-4l-5-1-1%203h-9q-4-11-5-23'/%3e%3cpath%20fill='%23393b50'%20d='m206%2079%204%201c2%206%202%206%202%2014l2%202%203%2012%202-3v4h2l1-5%202-8%203-1%204%202%201-3%205%201v3l5%201-3%208v5l-1%204-2%201v-15h-3v2l-5%202v10l-2%201-1-2h-3l-2%2015v10q-4-10-3-21h-2l-1-7-1-8-2-1v-2l-3%201-2%2010-1%209-3-9-5%203v-4l-1-4-3-2c1-5%201-5%207-10l6-1z'/%3e%3cpath%20fill='%231b93c7'%20d='M236%20169h84v5h-6v-1h-4l-10-1h-17l-22%201-41%201h-89c4-4%205-5%2011-5z'/%3e%3cpath%20fill='%2371cdf0'%20d='M99%20173q5%207%204%2015c1%206%201%206%204%209l2-11q3%201%202%207v5l2-4h2l-4%2020q6-6%207-14h3l-4%2015h-2l-1%206-3-1v-2l-4%204-2-1-1%202%201-8h-2l-1%205-3%203-2-9-2%209c-8-8-8-8-8-14v-13l3%202%201-4h2l1%203%204-1%202%208-1-14h2l-1-6z'/%3e%3cpath%20fill='%231f2f3d'%20d='M11%20465h3v8l3%206%203%206-1%203-2%201%202%201v7l3-1%201%2011H0v-13l-1-8q2-12%2012-21'/%3e%3cpath%20fill='%233f647d'%20d='m60%20474%205%201v2l4-1%202%202%205%202-1%204%201%202h-2v2l3-1c16-2%2033-5%2048%202v3l4%202v1H87l-17-1h-4l-4-1-2-5%201-1-4-2v-6l2-1v-3z'/%3e%3cpath%20fill='%2371cdf0'%20d='M208%20284h1l1%207-3-1v-2h-2l3%207v10l-9%201h-7v-4l-3%202q-7%204-14%201h-3v-2h-4l-1-6h-7v3h-7l1-4%205-2v2h2v-3l4%201v-2c4-2%204-2%2012-2q5%205%204%206l4%202-1%201h6l3%201%205-1%207%202q0-7-3-12l1%205-4-2h-4l3%203-1%202-8-5v5l-8-4%202-9q13-5%2025%200'/%3e%3cpath%20fill='%231f2f3d'%20d='M308%2059q4%205%203%2013l3%2029c1%2013%201%2013-2%2018l-2-17h-4l-2%208-4%2016q-4-7-3-16V97l1-24c1-6%201-6%206-11z'/%3e%3cpath%20fill='%23bf6a82'%20d='M76%20219q-5%204-11%205l-2%201%2018%202q-9%208-22%207h-4q-10%200-19-3l-1%201H19l-7-1H7l-2-4%2022-2h15v-3c11-4%2023-8%2034-3'/%3e%3cpath%20fill='%231f2f3d'%20d='M1%20424h2c2%206%202%206%200%2011l1-2q3%201%205%204l2%208%201%205%201%203%204-6%202-2q5%201%206%204c-1%209-8%2012-15%2018l-9%2012H0v-48z'/%3e%3cpath%20fill='%23207699'%20d='M218%20151c3%204%203%204%204%2010l3-1h13l6-1h18l-1%203q-12%203-25%202h-21l-24%201h-16v-3l9-4%207%205-1-6%205-1%205-4%204%201v6l-2%201%206-1%204%203v-3h2l-1-4z'/%3e%3cpath%20fill='%231b93c7'%20d='M86%20170h9l1%202%202-1q3%2010%203%2019h-2l2%2015-2-1-1-8h-3v-8l-1-8h-2v5c-6-12-6-12-6-15m13%200h8q7%209%209%2019l-1%205h-2l-2%205q-2-5-1-11l-3%2013-2-4-2-3-1-12-3-9z'/%3e%3cpath%20fill='%23215767'%20d='M119%20136q3%206%203%2011l3-1q3%208%201%2015l-2%204-7-13c0%205%200%205%204%2010q4%2012-2%2024-5-7-7-15l1-17-2%208c-5-5-5-5-7-12v-2h12v-4h2l1%202-1-5z'/%3e%3cpath%20fill='%231b93c7'%20d='m239%20318%203%201%2011%201h10l-4%201%201%204h6l6%201%202%208h-7l-9%201h-15v-2h-2v2h-7l1-7-1-5%206-1%201-2h-2z'/%3e%3cpath%20fill='%23393b50'%20d='M131%20393c3%203%203%203%205%209v3l2%201-6%2012h-3l1%203h-5l-4%201-1-1h-5v-2l-6-2%201-9%205-1%203-7%204%201%202%205q4-5%205-11h2zm67-19%207%201c-1%206-3%207-8%2011l-14%2013c-14%2012-14%2012-16%2012l-1%203h-12l13-13%205-4%2018-15z'/%3e%3cpath%20fill='%239ba7b9'%20d='M228%20247q3%201%205%204h3l1-4%203%201%202%205h3l1%207-3-1-4%208-7%205-2-2v-3l-4%201-3-1v-2l-3%201-7-2%201-2-1-7%201%202%206%201-1-4%203%201v-5l4%201z'/%3e%3cpath%20fill='%23207699'%20d='m37%20150%203%201%201%205-4%202q5%205%2012%205l2-4%205%202%205-2%207%201%201-3%202-1%201-4%204-1%203%203v3l4-1v3h2v2h12v-3l6%202c-4%204-4%204-10%204l-6-1c-7%200-7%200-12%203l-5-1v-2l-4%201q-20%203-40%200l1-5%209%203v-3l-5-2q0-4%206-7'/%3e%3cpath%20fill='%2371cdf0'%20d='M147%20353h2v5l-2%202%203%201%202-7%207-1%202%202%205%201%201%205q-5%205-11%204v2h-2l1-3%2010-2-1-5-5%201-1-4-5%201v6l-2%202h-8q-6%208-8%2017l-3%207-2%206h-3l1-4%202-6%202-5%201-11-5-3c1-5%201-5%206-9l8%204%201-2h4zm9%2014h2q1%207-2%2013l-2%206-3%205-2%205-10%2023-3-1%2012-26%202-4c6-15%206-15%206-21'/%3e%3cpath%20fill='%2342b4db'%20d='m312%20156%208%202v8l-29%201h-38l-2-2%205-1%208-2%2013-1h4l1-2c10%201%2010%201%2014%203v-4l5%202h10z'/%3e%3cpath%20fill='%23bf6a82'%20d='M96%20212q4%204%204%2010l3-7h2v6h2l2-3h2v2h2v13h-5v-2h-2v2q-9%202-18%201l-2-2h2v-2l-5%202h-8q7-3%2013-3l-3-6%205%202-2-5h7z'/%3e%3cpath%20fill='%2371cdf0'%20d='M295%2079q1%208-2%2016l-2%207-2%205h7l1%207-9%201-4%203h-8l-1-2-2%202-1-2-2%201-2-1%204-15%203%202%203-7h2l1%2013%202-5h3l1%201z'/%3e%3cpath%20fill='%23bf6a82'%20d='M320%20197v4q-13%204-26%204l1-2-7%202-4-1-2%202-9%201-2-2-7%203-22%203%205-4-10%203v-2h-5l1-2%2014-2h5l14-1%2014-2%208-1%2020-2z'/%3e%3cpath%20fill='%233f647d'%20d='m104%20239-2%201v2h4v2c-54%200-54%200-69-4l1-2%204%201h4l5%201h4l2-3h11l1%201z'/%3e%3cpath%20fill='%231f2f3d'%20d='m206%2079%204%201c2%206%202%206%202%2014h1v8l-2%201v-2l-3%201-2%2010-1%209-3-9-5%203v-4l-1-4-3-2c1-5%201-5%207-10l6-1z'/%3e%3cpath%20fill='%239ba7b9'%20d='M118%20325v2l4%202%202%206%204%201%201-2v2h8l1-3v5l-1%201-1%205-3%208h-2l2-8h-2v2h-3q-4%208-4%2017l-8%202%204-23%201-11-7-5z'/%3e%3cpath%20fill='%23207699'%20d='m11%20233-2%201%206%202-3%203h17l-6%203%204%201v2l-17%205-1%204H7l1%203-3%204-5-1v-2h2v-18l1-7z'/%3e%3cpath%20fill='%239ba7b9'%20d='m129%20261%205%202v11l5%202%201%206-3%203v1h-5l-7%202%205%203v6l-7%203%201%202%201-1h5l1%208-1%205h5l4%208%205%201%201%202%205-5%204%202v8h-2l1-6-4-1-5%205-2-4-3%201-2%208h-1v-8l-7%201%204-2%203-2v-2l-2-1v-4l-6%203-2-1%202-4%201-10-4%201-1%205h-4v7l-4%204h-2v-2l3-2%201-8-7%201%201-3%208-2%201-3-8%201%202-2h3l1-3%209-1v-5h-9c5-7%208-7%2016-9l3-1-1-4-5-1%201-7-2-1%201-3z'/%3e%3cpath%20fill='%231fabe6'%20d='M307%20443h12l1%207v20c-9-1-9-1-14-4q1-4%204-7l-4-3%201-4%205%201v2l2-1v-2h-2v-2l-5-1z'/%3e%3cpath%20fill='%23393b50'%20d='m80%20358%209%204q2%209%201%2017l-3%202v-4h-2v-2h-2c3%208%203%208%205%209l1-3h2v11H80v-7l5%203%201-2-5-2c-4-10-3-16-1-26'/%3e%3cpath%20fill='%2348c6e8'%20d='m87%20176%204%205%203-1q3%209%201%2017l-2%202v-5h-2v5l-3-2-1%208%202%201h-2l-1%208-5%201c-6-11-6-11-7-17h2l4%206v-9l3%203c1-6%201-6-2-12v-2h2l5%208z'/%3e%3cpath%20fill='%231b93c7'%20d='M245%20103h1v20c0%206%200%206-2%209h-1v7h2v8h-17c1-9%201-9%203-11l1%209h2v-19h7q4-11%204-23'/%3e%3cpath%20fill='%23215767'%20d='m135%20146%2012%202%201%204-3%201v8q-4%206-11%208l2-6v-4l-1%204c-2%205-2%205-6%209l-1-3-2-1q2-12%209-22'/%3e%3cpath%20fill='%231b93c7'%20d='m174%2094%202%204%203%203%201%203%203-10%201%203h2c0%207%200%208-4%2014l-2%2012-2%2015h-2l-1-13-3%209h-1l2-16V95z'/%3e%3cpath%20fill='%2371cdf0'%20d='m269%2066%201%203%204-3-7%209-3%209-1%204-1%204%208-8%202%201-3%203-3%203-4%204-6%207%202%206%201%209-2%201v-2l-2%201h-8l-1%202v-17h2v3h2v-7l6%202%208-23z'/%3e%3cpath%20fill='%233f647d'%20d='M122%20227q10%206%2016%2015v2q-15%202-29-2v-4h6v3h2l-2-7v-4l6-2z'/%3e%3cpath%20fill='%23207699'%20d='M320%20317v12h-21v6h-1l-1-17z'/%3e%3cpath%20fill='%2327b6e7'%20d='m151%20203%201%202h4l1-2%204%202q9%203%2019%202-9%205-20%205l-31%206v-3c8-4%208-4%2014-4v-2l2-2v-3z'/%3e%3cpath%20fill='%2371cdf0'%20d='m193%20108%205%205%204-1%202%2016-3%202-3%207q-5-6-5-15l-5-1-1-1v-6l5-1z'/%3e%3cpath%20fill='%231b93c7'%20d='m218%2074%203%201%201%2018%202-1q0%209-3%2017l-5-1-1-4-3-9-1-9-5-9%205%201%204%208z'/%3e%3cpath%20fill='%23207699'%20d='m60%20474%205%201v2l4-1%202%202%205%202-1%204%201%202h-2v2l3%201-3%202%201%202H62l-2-5%201-1-4-2v-6l2-1v-3z'/%3e%3cpath%20fill='%2342b4db'%20d='m218%20390%202%205%202%201-1%205%201%203q-7%202-15%201l-3-2c-6%200-6%200-12%203h-4v-2l9-5%206-2%207-3%201-3z'/%3e%3cpath%20fill='%231b93c7'%20d='M258%20201h4l10%201v1q-41%204-82%204v-2q15-3%2031-3c30-2%2030-2%2037-1'/%3e%3cpath%20fill='%231fabe6'%20d='m13%20103%205%202%201%209v9l-2%202h-2v-3h-3l-1%202-3-2H0v-16l3%201%202%206%202-3h2l2%205z'/%3e%3cpath%20fill='%2342b4db'%20d='m177%20290%204%204-1%204h2l1%207h-11v-2h-4l-1-6h-7v3h-7l1-4%205-2v2h2v-3l4%201v-2c4-2%204-2%2012-2'/%3e%3cpath%20fill='%231b93c7'%20d='M136%20184v2h-3v8l-2%2010c-7%204-7%204-11%204l1-8h-2q1-8%206-13c5-4%205-4%2011-3'/%3e%3cpath%20fill='%23207699'%20d='m169%20474%2015%202q-4%206-11%208l2%206%203%201%201%203h-9l-1-4q-2-7-9-10v-2h-2v-3q6-2%2011-1'/%3e%3cpath%20fill='%23b3daf0'%20d='M0%20147h2v111H0z'/%3e%3cpath%20fill='%239ba7b9'%20d='m209%20284%205%205%203%202v-4h2l1%202h3l-2%204%205%201-1%204v3h-17l-1-7-2-6h2l2%202z'/%3e%3cpath%20fill='%231b93c7'%20d='m308%20152-1%204h2l-1%204c-7%201-7%201-12-2v4l-4-1-10-2-1%203-8%201h-5l-7-1%201-4c8%200%208%200%2012%202l5-2h6v-2l6-1q3%202%202%205h2l1-5c5-3%206-4%2012-3'/%3e%3cpath%20fill='%232ebdeb'%20d='M227%20118c4%204%204%204%204%208l3%201v18h-2l-1-7h-1l-2%209h-5q-1-15%204-29'/%3e%3cpath%20fill='%23bf6a82'%20d='M225%20254h7l3%204%201-3%205%203q0%208-6%2012l-3%202-2-2v-3l-4%201-2-5-2-4%203-1-1-3z'/%3e%3cpath%20fill='%231b93c7'%20d='M42%20116h1v15h2v-8h1v6l2%2016h2l-1-3v-10q5%207%206%2016H39l1-4-1-8h1z'/%3e%3cpath%20fill='%2342b4db'%20d='m289%20273%202%201v3h3v-2l3%201%201%203v-2h4v3h6l2%205-9-1%201%205h-6l-1-4-5%201-3-1-1-9z'/%3e%3cpath%20fill='%23963172'%20d='M213%2096q4%206%204%2012l2-3v4h2l2-10%202%201-2%2014q-4%2012-3%2026-4-10-3-21h-2l-1-7-2-10z'/%3e%3cpath%20fill='%23b3daf0'%20d='M147%20353h2v5l-2%202%203%201%202-7%207-1%202%202%205%201%201%205q-5%205-11%204v2h-2l1-3%2010-2-1-5-5%201-1-4-5%201v6l-2%202h-8l-3%203-2%202%201-5%205-2v-2l3-2zm9%2014h2q1%207-2%2013l-2%206-3%205-2%205-10%2023-3-1%2012-26%202-4c6-15%206-15%206-21'/%3e%3cpath%20fill='%231fabe6'%20d='M85%20175v3c-7%203-18%201-25%201H41q-6%201-7-2l22-3h4z'/%3e%3cpath%20fill='%23b3daf0'%20d='m204%2084%203%203v7c-3%202-3%202-8%202l-2%203-5%201-4-3%202-6h6l1-6z'/%3e%3cpath%20fill='%23215767'%20d='m119%20307-1%209-4%202v2l-4%202-2%204-8%202-1%203h-1v-10l10-1-1-6c4-6%205-7%2012-7'/%3e%3cpath%20fill='%233f647d'%20d='M186%20385q1%203-3%207h-2l-2%204-5%205c-5%205-5%205-5%2010h-2l-1%203h-12l13-13%205-4q6-7%2014-12'/%3e%3cpath%20fill='%2342b4db'%20d='m235%20314%206%201v3h-2v2h2l-1%203-5%201v4h6l-1%203h-7v-2l-9%201v-6l2-1-3-4%201-3h2l1%203%206%201%201-5z'/%3e%3cpath%20fill='%231b93c7'%20d='M314%20129h1v6l1%203h2l2-2v11h-28v-1h11l1-2%202-3%202-8%203%203zm-193%2034q5%2010%200%2019l-2%204q-5-7-7-15v-7c4-2%204-2%209-1'/%3e%3cpath%20fill='%23215767'%20d='M100%20294c3%208%203%208%202%2012l-4-2c-1%206-1%206%201%2010-5%203-5%203-8%203v-5l-4-4%206-3-3-10z'/%3e%3cpath%20fill='%233f647d'%20d='M129%20324v2l8-2v12h-13l-3-7-3-2v-2z'/%3e%3cpath%20fill='%23207699'%20d='M312%20222h8v3c-32%204-32%204-45%202v-1l9-1%205-1z'/%3e%3cpath%20fill='%23b3daf0'%20d='m262%20162%205%202h14l5-1%2016%201%202-1h16v3l-29%201h-38l-2-2%205-1z'/%3e%3cpath%20fill='%233f647d'%20d='m11%20233-2%201%206%202c-5%204-5%204-8%204l1%203-2%204v10l-1%204-5-1v-2h2v-18l1-7z'/%3e%3cpath%20fill='%23207699'%20d='m222%20113%201%202%203-1q1%2010-1%2018l-2%2015-4-1%201-20z'/%3e%3cpath%20fill='%2330c5ea'%20d='M19%20445q5%201%206%204c-1%208-4%209-10%2014h-2l-3-5z'/%3e%3cpath%20fill='%231fabe6'%20d='m51%20243%2020%201v3l1%203H45q2-3%206-5z'/%3e%3cpath%20fill='%239ba7b9'%20d='M44%20345h1l1%206q2%2017%207%2033l1%205%205%2018c3%2011%203%2011%202%2015l-1-5-2-6-2-6-4-10-4-18-2-7z'/%3e%3cpath%20fill='%2371cdf0'%20d='M208%20101h3v2l3%201v14l-2%202h-6q-2-9%201-18z'/%3e%3cpath%20fill='%233f647d'%20d='m262%20159-1%203q-18%204-38%201l-1-2q7-2%2016-2z'/%3e%3cpath%20fill='%2371cdf0'%20d='M138%2098c6%206%206%207%206%2015v5l-2-3-6%201v-2h-2l-3-4%203-6%202%201v2h2z'/%3e%3cpath%20fill='%23b3daf0'%20d='M137%20333h1v5l-1%201-1%205-3%208h-2l2-8h-2v2h-3c-3%207-3%207-3%2013h-2v3h-4l1-8%201-5%202-6h11z'/%3e%3cpath%20fill='%239ba7b9'%20d='m263%20250%204%203%201-2%202%201q1%208-2%2015h-1l-1-8-1%202h-2l2%207-1%204-1-3-3%207q-2-3-2-7h2l-1-13%204%202z'/%3e%3cpath%20fill='%231b93c7'%20d='m108%20416%207%203v2h5l1-2v3l6-2h2v-2l2-2%206%201-1%203-4%201-1%203h-4v2l-7-3-3%203c-5-1-5-1-9-5z'/%3e%3cpath%20fill='%2371cdf0'%20d='M215%20233h6l3%203h-6v7l-3%207h-3l-2%204q-3-9%201-16z'/%3e%3cpath%20fill='%23207699'%20d='M281%20318h4l2%2010%201%206%202%2019-7%203c-3-5-3-5-3-8l8%201-7-28zm-114%2027h4l14%201v2l-31%201v-1l-8-1q10-3%2021-2m-43-108q6%201%207%203h5l2%204q-15%202-29-2v-4h6l1%203%209-2z'/%3e%3cpath%20fill='%231b93c7'%20d='m70%20135%201%203h2l1-2%201%204%203%203v4l-20%201v-7q3%202%202%206h3l-1-2c0-7%200-7%202-9l1%2011h4v-7z'/%3e%3cpath%20fill='%23207699'%20d='m9%20458%205%205-5%205-8%2011H0q-2-9%203-16l4-3z'/%3e%3cpath%20fill='%23215767'%20d='M280%20364q-2%207-7%2013l-8%201%207-14z'/%3e%3cpath%20fill='%239ba7b9'%20d='m109%20275%202%204-1%202%201%2011-1-2h-2v6h-2l-1-7h-3q0%207%203%2014l-1%207h-2v-8l-2-4v-4l-7%201%201-4%206-1%201-3%204-1%202%202v-6z'/%3e%3cpath%20fill='%23393b50'%20d='m72%20401%205%202-1%2023-4-1z'/%3e%3cpath%20fill='%23207699'%20d='M131%200h1l-2%2024q-2%2015-1%2032l4%205-1%202-13-15%201-2%205%206%201-7V35z'/%3e%3cpath%20fill='%23393b50'%20d='M298%20338q3%205%202%2012l-1%202-8-1-2-12%205%201z'/%3e%3cpath%20fill='%2371cdf0'%20d='M28%2091h2l1%2013v4q0%204-2%207v-4h-2v-3h-3zm48%2012%207%202%201%2013-7-2v2h-3l1-7z'/%3e%3cpath%20fill='%23207699'%20d='m101%20473%203%202v2l5-1%204%203-2%205h-11c-2-5-2-5-1-8h2z'/%3e%3cpath%20fill='%239ba7b9'%20d='M108%20438q-11%206-23%208v-2l-5-1-1-3%2012-2z'/%3e%3cpath%20fill='%2342b4db'%20d='M212%20313h8c2%206%202%206%201%2010h-6l-3%201-3-2%201-5h2z'/%3e%3cpath%20fill='%23b3daf0'%20d='M70%20163v2l4-1%209%201%204-1%206%201v2H51q9-6%2019-4'/%3e%3cpath%20fill='%231b93c7'%20d='M299%20329h21v4l-12%201h-9z'/%3e%3cpath%20fill='%2342b4db'%20d='M40%20260v2h-6v4l4%201-2%202h-8l-3-9c7-2%209-2%2015%200'/%3e%3cpath%20fill='%239ba7b9'%20d='m269%2066%201%203%204-3-7%209-3%209-1%204-1%204%208-8%202%201-17%2017-1-2h2l8-23zM118%20200h3l-4%2015h-2l-1%206-3-1v-2l-4%204-2-1-1%202v-5l2%201%202-4%204-2q5-6%206-13'/%3e%3cpath%20fill='%2342b4db'%20d='m281%20217-7%201v1l-19%201h-12v-2l16-1%2014-2c5%200%205%200%208%202'/%3e%3cpath%20fill='%23207699'%20d='M294%20211v2l6-1h14c-9%206-25%204-35%204v-2q7-3%2015-3'/%3e%3cpath%20fill='%2371cdf0'%20d='M153%2087h1v19l-1%2012-8%201%204-11h3l-1-12h1z'/%3e%3cpath%20fill='%23b3daf0'%20d='m233%2075%205%203v7l-2%202h-6c-2-3-2-3-2-8zM112%20387h1q-1%2018-5%2035h-2q-1-17%206-35m121-285h3l-1%2013h-6q-3-5-1-12l5%201z'/%3e%3cpath%20fill='%23207699'%20d='m156%20486%204%201h4l4%201%201%206-17-1%201-3h3z'/%3e%3cpath%20fill='%2342b4db'%20d='M0%20438h5l3%203c-1%207-3%208-7%2013H0z'/%3e%3cpath%20fill='%239ba7b9'%20d='M78%20408c3%203%203%203%204%209h-2l1%204%201%209-9%201-1-6%206%201z'/%3e%3cpath%20fill='%23b3daf0'%20d='M158%2098h7l3%205-3%205-7-1z'/%3e%3cpath%20fill='%23bf6a82'%20d='m250%20284%204%205%206%203%207%208-5-2c-5-1-5-1-12%201l-1-2-5-1%202-1v-2l8%202-2-4z'/%3e%3cpath%20fill='%23207699'%20d='M122%20496h25v1q-20%203-41%202v-2z'/%3e%3cpath%20fill='%2342b4db'%20d='m128%20334%201%202h8l-2%208-12-1%201-7h4zM97%2038v6l-3%204q-9%2018-13%2037h-2q4-18%2011-34l1-8%202%203z'/%3e%3cpath%20fill='%23207699'%20d='M133%20482h5l2%202%206%202v4l-16-2%201-4h2z'/%3e%3cpath%20fill='%23b3daf0'%20d='m129%20359%202%201-2%203%205%202c3%207%203%208%201%2015l-5%2013h-3l1-4%202-6%202-5%201-11-5-3z'/%3e%3cpath%20fill='%23963172'%20d='M11%20334h5l4%209c-4%202-4%202-9%201v-2H9l-1-3z'/%3e%3cpath%20fill='%239ba7b9'%20d='m144%20262%205%202v5l6%201%203%202-1%201%207%203v1q-6%200-13-3l-1-2-6-2v-3l-3-1%202-2z'/%3e%3cpath%20fill='%2342b4db'%20d='m157%20105%201%202%205%201-1%209-7%202z'/%3e%3cpath%20fill='%2348c6e8'%20d='M294%20211h19v1l-19%201z'/%3e%3cpath%20fill='%233f647d'%20d='M154%20112h1v9c-2-3-2-3-2-8z'/%3e%3cpath%20fill='%232ebdeb'%20d='m132%20494%207%201v1h-8z'/%3e%3cpath%20fill='%23207699'%20d='M150%20497h9v1h-9zm42-375c2%203%202%203%202%208z'/%3e%3cpath%20fill='%232ebdeb'%20d='m148%20492%204%201-1%202h-2zm19-6%202%201%201%205-2-1z'/%3e%3cpath%20fill='%233f647d'%20d='M168%20103h1v5l-2-1z'/%3e%3cpath%20fill='%231b93c7'%20d='m90%20496%203%201Zm3%201%203%201Z'/%3e%3cpath%20fill='%2348c6e8'%20d='M234%20205h6v1h-6z'/%3e%3cpath%20fill='%23207699'%20d='M152%20414h2v2l-3-1zm120-34h2v2l-3-1z'/%3e%3cpath%20fill='%2348c6e8'%20d='m102%20240%203%201-3%201z'/%3e%3cpath%20fill='%232ebdeb'%20d='m170%20332%203%201h-3z'/%3e%3cpath%20fill='%2348c6e8'%20d='m134%20284%203%201Z'/%3e%3cpath%20fill='%23207699'%20d='m184%20407%203%201Z'/%3e%3cpath%20fill='%23393b50'%20d='m287%20255%202%201-2%201z'/%3e%3cpath%20fill='%2348c6e8'%20d='m217%20234%202%201Z'/%3e%3c/svg%3e",
	grove: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='507'%3e%3cpath%20fill='%23d77887'%20d='M0%200h320v507H0z'/%3e%3cpath%20fill='%23dbf4da'%20d='M103-1h56l65%201h96v336c0%2013%200%2013-3%2019q-1%203-6%202l-7-2q-3-3-2-8l1-2v-4q-6-1-6%203l-1%202%203%204v9h-6l-5-6%204-2-1-3c0-6%200-6%202-8l-2-1c-9-2-9-2-11-6q-1-5%203-9l2-2q-3-6-9-8l1-7h-3c-18%200-18%200-23-4q-1-4%201-8%201-5-2-9-1-4-6-4l1-9h-3c-16%200-16%200-22-3l-2-7-5-3-14-10-3-2q-8-6-8-17-1-11%201-22h-2v2l-1%203v3l-2%205q-12-5-18-18l-9-16-2-3-1-2-1-4-2-1-6-3-4-2-6%204-2%202-4%204q-2%202-5%202l-3-1-2-10v10q-7-1-12-4l-2-13v-3l-1-20q15-3%2029-1-5-8-13-10-3-1-7%201t-9%202l6-24-1%203-1%204-1%202-4%2011h-1l-2-38-2%201-1-15c5-2%205-2%2010-1h15q-5-8-14-14l-2-2q-13-4-26%202-15%203-22%2015h6l3-1%205-1%207%202%2010-1%205%201q3%2012%202%2026l-3-1-11%201-2%204-1%201%2018%201%201%208v3c2%2014%202%2014%200%2017l-2%202%204%201c4%2025%204%2025%203%2035q-3-1-4-5c-6-17-6-17-13-20l-6-2-16-8v-9l-2%206q-7-1-12-5l-2-7v-9l-1-5c-2-17-2-17%200-23l1-3v-2l1-3%2020-55%204-4%204-5L87%208l4-5q5-5%2012-4'/%3e%3cpath%20fill='%23402f2c'%20d='M235%20393q3%204%203%208l1%203%201%204%201%203%201%208%2011%2050%203%2017%206-12%201-2q4-12%203-22%202-19%208-36l5%201%202%205v3l5%2021%201%208%201%202%203%2015-1-10%205-1-2-3h-4v-4h3l4-1%202-3-5-1-3%203h-2l-5-21-1-3-1-10q4%200%206%203l6%201%201-3-4-2%208-2-1%204h9l-3%202v2l3%201%201-3%204-1-1-2h3q-1%2046-7%2092H23l-6-25-3-11-1-10%204-3%204-2v-2q7-3%2013%200v2h4l3%203%202%201-3-6c-9-9-10-23-11-35H18l-7-1v-2l17-4%204-2%204%201v2l5%201h6l-1-5h-2l-4-4%201-2q10-2%2020%201l-2%205%202%201-3%204h2q10-2%2020%201l5%201-2-4-4-1v-3l-5-1%201-4h2l-1-3%2018-2h3l17%202v2l-8%203v2l4-2v2l2%201h-5l-1%205%207-1%201%207h9l10%201q4%205%204%2011%209-2%2017-7l-2%205h7q5%200%209-4l9-5%206-2%206-4v-8l1%201q4%203%2010%204%208-1%2015-6h2v2l13-2%202-8h2z'/%3e%3cpath%20fill='%23658675'%20d='M187%20209h2v2c-1%2026-1%2026%204%2034l23%2016%203%202%201%203v3q12%205%2025%204v9l2%201q5%201%206%207%201%204-1%207v6l9%203h9l7%201v7l2%201q5%203%207%208l-2%202-4%206q2%204%206%206l9%203-4%203%201%202v6l-3%203q4%206%2010%205c-1-10-1-10-4-13l3-5h5l1%205-1%201%201%207q6%204%2011%202l3-4%202-4v159h-14l2-35%201-14%202-15%202-28-2%201v3h-4l-1%202-4-1%201-3h-7l2-5-6%202%202%202-1%204q-5%200-9-4l-3-1%201%202%202%2011%201%203%203%2018%202-2%206-2%202%201v3q-1%203-6%202h-3l1%204%204-1%201%204-5%201%202%2014-4-12v-2l-2-8-1-5-4-18-1-4v-3l-1-6-5-1v2l-4%2016q-3%209-2%2020%200%2014-7%2026l-2%205-2%204-2-1-1-8q-6-37-16-73l-1-3v-2l-1-2-1-4%202-8%204-12-1%202-1%202h-2l-1-3-2%202-1-6q5-8%2012-11l6-1%201-1-8%201%201-1%2010-15-2%202-7%208-11%2013-3%203%203-12-2%205-3%204h-7l-1%203-2-3-2-2%202-3-3%202v1l-7%202-2-2%201-4-2-2q-1-5%202-11l3-3%203-4%202-1%203-5%204-3q4-2%204-8-5%201-7%205l-1%203-5%209-3%203-4%203-1-30-1%2017-7-8q9%2011%207%2024v3l-1%205-2-1-5%201-2%202h-3l-2-3-2-4-3%201-2-1%204-5%201-3-3-1v-2l-6-2v-2l-12-3h-5l-2%204-2-1-2%201-1%206-4-1v-2l-8%201v-5l1-3%202-3%202-3%202-3%2016-26-3%203q-4-4-5-9l-3-4-2-3%202%205%201%202%205%209q0%206-4%2010l-3%205-2%202-7%2012-3%205h-2q-2-7%201-15v-2l3-7h-2v2l-1%202v3l-3%206q-3-5-3-12l-1-3v-4l-1-4-4-26v18q-10-10-16-24v-4l2-2q5-5%206-11h2v-2h4v2l7%202-1-3%206-4%201%203%201%203%206%202a49%2049%200%200%201%2019%206q9%203%2017-1l5-3%201-5-2-1-17-12-2-1-6-4-3-3q-2-2-2-5v-3l4-1%203%202%202%202%202%201%204%203%202%202%208%205-1-3q-2-3-2-8l3-1%202-7z'/%3e%3cpath%20fill='%23413a2c'%20d='M0%200h94L72%2025q-10%209-12%2023l-3%209-1%206-4%2013-3%209v2q-3%2011-1%2022v4l2%2018q3%2018%202%2036l-5%201v2h2q4%201%206%206l-2%203h2v5h2l-2%208%203%201-4%205v2l2%201v2l-3%201v2l4%201%201%2015v8l-4%202%201%203%205%202q10-8%2013-21l2-6%201-4h3v12l6-6%201-2%207-8%207-6%202-2%204-1q-1%206-6%2010l-2%203-2%202%203-1%207-1-1%203-5%202q-17%208-27%2023l-2%202-9%2012%201%204%204-1%201%204h-2v2l10%203%203-2q4-2%209-2l4%203%209%202q4-1%208%203l5%208%203%205%201%203%2010%2014q7%2012%207%2025l5%2019v12l-3%201-2%207h-10l-1-5-2%203-2%202h-2q-3-10-2-22v-13q-1-6%204-11l1-9q-6%204-5%207v6l-1%201v10l-1%204v13l-3-3v-2l-3-1-2-3q-2-5-8-5l-5-4-10-1-5%203h-2q-4%202-7%206l-10%207-1-12-4%203-2-1-1%202-2-1-2-2-2-2-4-3v-2l-2-1q-3-1-4-5v-3l-1-6%2019%202v-5h-8v-2l-2%201-8-2-3-1-2-1v-2l4-1%202-1q16-6%2032-1l3%203v-2c6%201%206%201%208%203l1%201q-4%205-10%206l-3-1-2%202v-2h-4v5c20-2%2020-2%2027-7l1-5q-3-9-12-14l-5-2-2-1-11-1h-2q-6%200-13%203l-4%202-3%201-3%202-3%201-4-14v-3l-1-2v-3l2-6%204%203%206%203%204-1%202-4-10-2-1%203h-1v-2l-2-25v-12l-1-30-1-9v-3l-2-19q1-11-5-20l-2-2c-7-8-7-8-12-11-6-4-6-4-8-9V88l1-44z'/%3e%3cpath%20fill='%23533e31'%20d='M220%200h100v309l-1%206-6-1v-4l-1%204h-4l-9%201%202-5-4%203-3-7%203-1%203-1%203-1%206-4h2q1-5-2-10-10-6-22-8h-2l-1-8v-21h-6l-4-1q-5%200-10-3%201-8%207-11l7-4-1-4h2v2h4l-1-6-2-1%201-2v-9l1-6v-15h-16q3-6%209-8l6%201-3-88v-2l-1-6q0-7-7-13l-17-25-2-2-20-32-3-4-4-6-1-2z'/%3e%3cpath%20fill='%23d77887'%20d='m235%2022%203%204%202%203%202%203%203%206%202%203%208%2012%201%202%203%203%205%208%2013%2018%202%208v11l1%2010v4l1%2045v23h-7l-7%206%2015%201v32h1v7h-4l-1-1v3l-5%204c-7%204-7%204-8%208v3l15%203%204%201%201%207v21h3c17%204%2017%204%2023%2010l1%206q-1%205-6%207l-12%203%203%206%204-2-1%204h2l3-1h3l4%201%201-6v2l3%204%203%201%201-4v31q0%207-3%2013-1%203-6%202-4%200-7-2-3-3-2-8l1-2v-4q-6-1-6%203l-1%202%203%204v9h-6l-5-6%204-2-1-3c0-6%200-6%202-8l-2-1c-9-2-9-2-11-6q-1-5%203-9l2-2q-3-6-9-8l1-7h-3c-18%200-18%200-23-4q-1-4%201-8%201-5-2-9-1-3-6-4l1-9h-3c-16%200-16%200-22-3l-2-7-5-3-14-10-3-2q-6-6-8-15v-14h1v2q-1%204%203%209l12%2010%203%203%206%205%202%201%2011%208%204-2q10-7%2022-7l2%201v-4l-4-41q-2-48-9-97v-4l-5-18-2-8h-2l-1-3v-4l-1-2-4-21h-30l-12-1h-13l-7-1h-17c20-21%2061-23%2088-23'/%3e%3cpath%20fill='%238bad93'%20d='m111%2066%2011%2011v2l-8%201h-2l-12-1-3%201%202%2014%202-1v3l2%2035%202-8%201-3%201-2v-2l4-5-7%2025%2011-4q9%200%2016%206l2%205h-16l-4%201h-9v3l1%209%201%205v6l1%204v9l3%201%209%203v-2l-1-9%202%201%201%205v5q5%201%209-2l2-3%208-7q7%202%2013%207%204%205%206%2011l3%206%202%202%205%209%201%205%204%202%205%204%203%202q3%202%202%205l-1%203-3-1%201%202%201%203%201%203v4l-2-1-8-6-3-2-2-2-3-2-6-2v6q3%204%208%206l3%202%205%203%2010%208%204%202%202%202-4%208-11%204q-5%200-11-3l-4-1-2-1q-7-3-15-4l-3-1-2-6-4%204v2l-8-1%201-3h-4v2l-2%201-1%204q-2%207-7%209-4-1-5-4v-6q4-5%201-12l-2-3c-4%207-4%207-4%2011l1%203%201%202v2l-3-2q-4-3-8-3l1%205%202%201-12-4-4-1-1%202q-3%203-7%203l-8-4v-2h2l-1-4-5%202v-7l2-2%202-2%2016-19q9-9%2020-13l4-4-11%203%208-11%203-5-13%2011-4%204-8%209-2%202h-1l1-13h-3v2c-3%2013-6%2022-17%2030v-2l-5-1v-4l4-1-1-23-5-1%201-3h3v-2l-3-1q1-3%204-5v-2l-2-1%202-8h-2l-1-3%201-2h-2l1-4-3-2v-2l-5-1%202-4h3l-1-31%2012%205%201-8%202%202v5l-1%202v2l2%201%2011%205%206%202q10%204%2015%2015l2%206%201%203%201%202q1-11-2-23v-11h-5l1-2q2-4%202-9v-11l-1-9H78l6-7h2l3-1%207%202v-4l-1-4v-3l-1-15-10%201-11-2h-2l-1%201H58q5-10%2017-15%2019-9%2036%201'/%3e%3cpath%20fill='%23e1de59'%20d='m108%20241%203%204q2%208-1%2014l-1%203%203%204q5%204%206%2010l11%2016v-19l3%208v3l1%204%206%2035%204-11h2l-1%204-1%205-1%202-1%2013h2l1-2%205-10%201-2%2010-15v-5l-1-3-1-2-3-6-1-3-2-5%202-2%204%2010%202-3v3q0%205%203%2010l2-2%204-4-3%208-3%205-4%205-1%203-14%2023%201%202%208-1v3l3%201v-6q2-2%206-2l1-1%208-2q5%201%209%204v2h2l7%205q-1%205-5%208l7-3-1%202%201%204%202%202v2l7-4%205%202c1-22%201-22-6-30l-1-2%201-2%206%209v-8l1-8%202-1%201%2030%208-11%202-1%201-3q1-6%206-8l3%201-3%207-5%202-1%202q-3%207-8%2012-4%204-4%209%200%203%202%205l-1%204%207-1%201-3%203%201-1%204%203%201v2l1-2h3q5-1%205-3l3-7%202%201-1%202v2l-1%202-1%205%2023-27q-1%207-7%2012l-2%203-2%202%208-1q-2%204-4%203l-2%201q-7%202-12%208l-1%202%201%203%202%201v3h2l2-5v8l-2%203-1%202-2%206-2%205h-2l-1%204-1%204q-6%203-13%202v-2l-2%201q-8%206-18%206l-7-5%201%203-3%206-17%209-6%203q-4%203-9%202h-5l2-5-2%201c-9%206-9%206-14%205l-4-10-20-1v-8l-6%203-2-3%202-4%203-1-5%201%201-4%205-2%202-1%202-1q0-4-3-8l-2-4%204-3h2l-1-2%202-6%203-2v3h3l-3-9h-2l-1%204h-3l2-7q1-6-2-10v-36l1-5v-3q0-6%204-9h2q2%205-1%2010l-3%204v11l1%2030%202-2%205-4v5h4l6%201v-2l3-5q4-7%201-14l-5-23q-2-11-8-20l-7-11-7-11c-4-8-4-8-10-10h-2q-4-2-6-5l1-3%2010%204-1-2v-9z'/%3e%3cpath%20fill='%23413a2c'%20d='M94%20398h3l17%202v2l-8%203v2l4-2v2l2%201h-5l-1%205%207-1%201%209-2%201-3%2010v11h3v2l3%208h-11l-1%205-5%2022q-4%2011%201%2021l2%206H23l-6-25-3-11-1-10%204-3%204-2v-2q7-3%2013%200v2h4l3%203%202%201-3-6c-9-9-10-23-11-35H18l-7-1v-2l17-4%204-2%204%201v2l5%201h6l-1-5h-2l-4-4%201-2q10-2%2020%201l-2%205%202%201-3%204h2q10-2%2020%201l5%201-2-4-4-1v-3l-5-1%201-4h2l-1-3z'/%3e%3cpath%20fill='%23533e31'%20d='m293%20115%205%203h5v2h2l1-3v2l4-1%203%2044%207-6v152l-1%207-6-1v-4l-1%204h-4l-9%201%202-5-4%203-3-7%203-1%203-1%203-1%206-4h2q1-5-2-10-10-6-22-8h-2l-1-8v-21h-6l-4-1q-5%200-10-3%201-8%207-11l7-4-1-4h2v2h4l-1-6-2-1%201-2v-9l1-6v-15h-16q3-6%209-8l6%201-1-62%202%203%202-2q3-4%205-3l2-4z'/%3e%3cpath%20fill='%237f775d'%20d='M0%20124c10%206%2023%2016%2026%2028l2%2020v9l1%202%201%2018%201%2026%201%2015%201%2020%201-2c7%200%207%200%2011%202l-3%205h-8l-4-5-2-1q-2%209%201%2017l1%203%201%207%203-2c14-7%2014-7%2022-7h2q15-1%2025%208%207%206%207%2014-2%205-7%206-10%203-22%203v-5h8q4%200%208-3h2v-3l-8-3v2l-5-3q-19-3-36%203v2l15%203v2l3-1%205%201v5l-19-2%202%2011-5-2q-8-1-17%203l-5%205-3%201-5%205H0z'/%3e%3cpath%20fill='%23658675'%20d='m60%20251%203%201%204-1%201%204h-2v2l10%203%203-2q4-2%209-2l4%203%209%202q4-1%208%203l5%208%203%205%201%203%2010%2014q7%2012%207%2025l5%2019v12l-3%201-2%207h-10l-1-5-2%203-2%202h-2q-3-10-2-22v-13q-1-6%204-11l1-9q-6%204-5%207v6l-1%201v10l-1%204v13l-3-3v-2l-3-1-2-3q-2-5-8-5l-5-4-10-1-5%203h-2q-4%202-7%206l-10%207-1-12-4%203-2-1-1%202-2-1-2-2-2-2-4-3v-2l-2-1q-3-1-4-5v-3l-1-6%2019%202v-5h-8v-2l-2%201-8-2-3-1-2-1v-2l4-1%202-1q16-6%2032-1l3%203v-2c6%201%206%201%208%203l1%201q-4%205-10%206l-3-1-2%202v-2h-4v5c20-2%2020-2%2027-7l1-5q-3-9-12-14l-8-3-7-1v-9l-4%201-6-3%202-4%207%201v-6l2-1%201-3h-6z'/%3e%3cpath%20fill='%23dcf5de'%20d='M262%2076h9q7%206%208%2017v7l1%203v17l1%2042v23h-7l-7%206%2015%201v32h1v7h-4l-1-1v3l-5%204c-7%204-7%204-8%208v3l15%203%204%201v24l-2-2c-8-5-8-5-13-5l-9%203%201-3%207-2%208-3v-8l-14-4v-2h-3l-1-8-1-4v-7l-1-10-1-14v-7l-2-28v-3q-1-4%202-8h2v-3q0-4%203-8v-3l-7%2013h-1v-2l-4-31q-4-25-4-50z'/%3e%3cpath%20fill='%23d77887'%20d='M101%20364h1v6h2v2l6-5%201%201%201-2%201-2h2v7l-1%202%203-1%201-3h2l3%209h-3l-1-2q-3%203-3%207v2l-5%202q0%204%203%207l2%205-1%202h-2q-9-2-19-2h-2q-8%200-15%202v2l-2%201v3h2l2%201%201%203%203%201%203%205-6-1-6-1-10-1h-6l1-2%201-6%201-2H41l3%205h2l1%205h2l-1%202-12-3v-2l-3%201h-2l-1%201h-4l-11%203h-4v2l18%201%201%207q2%2017%2013%2030v4l-5-2v-2h-4v-2q-7-2-12%201l-1%202q-4%204-8%204l7%2029%201%203v2l2%2012H0v-99l3%206%207-1%207-4%201-6%201-3v-3l1-4%201-8%204%201%202%2016%204-6%202-1v-4l2%201v2l1-1q2-2%205-2l1-2%201-2%205-1h12v3h2l9%205v-3l3-9%202-3%203-6%203-1%204-5-1%207-1%202-1%205-2%206%201%201%205-2v-2l3-1%204-3%202-1%202-1%201-6c0-6%200-6%202-8'/%3e%3cpath%20fill='%23beb889'%20d='m235%2022%203%204%202%203%202%203%203%206%202%203%209%2014%203%203%206%209%201%203%204%206-3%201h-23l1%209v5l4%2039%201%205%204%2020%207-9q0%205-3%209v3l-3%204c-4%206-1%2020%200%2027l2%2029v3l2%2029-5-1-4-45q-2-48-9-97v-4l-5-18-2-8h-2l-1-3v-4l-1-2-4-21h-30l-12-1h-13l-7-1h-17c20-21%2061-23%2088-23'/%3e%3cpath%20fill='%23402f2c'%20d='m298%20412-1%204h9l-3%202v2l3%201%201-3%204-1-1-2h3l-2%2037-1%2014-2%2014-2%2027h-30l-2-11-1-10-2-7-1-10-1-3v-3l-1-3-1-5q-1-15%204-29l1-3%202-9%205%201%202%205%205%2024%201%208%204%2017-1-10%205-1-2-3h-4v-4h3l4-1%202-3-5-1-3%203h-2l-5-21-1-3-1-10q4%200%206%203l6%201%201-3-4-2z'/%3e%3cpath%20fill='%238b3a42'%20d='M82%20342h2q9%200%2016%202l2%205%203%201v3h-2l-2%201h-3l-2%201-1%202h-2v-2h-4l-1%204q12-1%2023-6h3l3%208v5h-2v-2h-2l-1%206-2-2-2%202-4%202v-2h-2l-1-5-2%2011q0%202-3%205l-2-1-1%203-6%201v2l-7%204%205-20-1%202-5%201-5%2013-1%203-2%205-11-5v-3h-2l-13%202h-2l-2%203h-3l-1%203h-2l-1-5v3q0%205-5%208v3l-3%201-2-18-3-1v4l-1%205v2c-1%2012-1%2012-4%2016q-6%203-13%202-4-6-3-13v-21l2%201%203%201h3l8%201-1-1-2-4h7l4-1h16l5%201%201%202%201-1h5l3%201h2q-2-9-11-12l-6-2-8-4v-3l2-1v-3q14-3%2027-1l3%202%205%201%2010%205%201-4h2v-3l-2-1v2q-4-1-7-6v-2l-5-2v-2z'/%3e%3cpath%20fill='%23d77887'%20d='M319%20365h1v142h-14l2-30v-5l1-14%202-15%202-28-2%201v3h-4l-1%202-4-1%201-3h-7l2-5-6%202%202%202-1%204q-5%200-9-4l-3-1%201%202%202%2011%201%203%203%2018%202-2%206-2%202%201v3q-1%203-6%202h-3l1%204%204-1%201%204-5%201%202%2014-4-12v-2l-2-8-1-5-4-18-1-4v-3l-1-6h-2l-3-1h-3l-4-3%201-5%207-6v4l10%202%201-5%201-1v-8q1-3-2-5h-5l-12-4q2-6%208-10l1-2q13-4%2025%201v2l4%201%201%206q-5%205-11%206l2%205h9l8%201v-2l1-11%201-4v-3l1-3zm0-142h1v79l-1%2013-6-1v-4l-1%204h-4l-9%201%202-5-4%203-3-7%203-1%203-1%203-1%206-4h2q1-5-2-10-10-6-22-8h-2l-1-8v-21h-6l-4-1q-5%200-10-3%201-8%207-11l7-4-1-4h2v2l2-1q17-6%2034%201l1-2%201-2%201-2z'/%3e%3cpath%20fill='%23dbf4da'%20d='M0%200h11l4%2021%201%206%203%2028%201%2012%201%2012%201%206%203%2043v6L8%20121c-8-7-8-7-8-9z'/%3e%3cpath%20fill='%23beb889'%20d='M0%20124q6%203%206%206l2%209v4l1%204v5l2%2014v2l8%2074%201%2021%201%204v7l1%203v12c-7-1-7-1-22-7z'/%3e%3cpath%20fill='%23dbf4da'%20d='M302%200h18l1%20126v17c0%2011%200%2011-3%2015l-5%205h-1l-1-20-1-4-6-97-1-18z'/%3e%3cpath%20fill='%238bad93'%20d='M0%20408q5%209%206%2019l1%202v4l2%2011%201%204v8h2v-3l4-17%202-17h11l1%203q1%2019%2013%2034v4l-5-2v-2h-4v-2q-7-2-12%201l-1%202q-4%204-8%204l7%2029%201%203v2l2%2012H0z'/%3e%3cpath%20fill='%23dbf4da'%20d='M94%2080q3%2013%202%2026l-3-1-11%201-2%204-1%201%2018%201%201%2011c2%2014%202%2014%200%2018l-2%201%204%201c4%2025%204%2025%203%2035q-3-1-4-5c-6-17-6-17-13-20l-6-2-9-4-4-2-3-2%206-26%202-8%201-3%208-26zm168-4h9l7%2010v4h-5v3c2%2037%202%2037-9%2051l-5%205-6%2011h-1v-2l-4-31q-4-25-4-50z'/%3e%3cpath%20fill='%23533e31'%20d='M249%20298h2v2l3%204%207%202h9l7%201v7l2%201q5%203%207%208l-2%202-4%206q2%204%206%206l9%203-4%203%201%202v6l-3%203q4%206%2010%205c-1-10-1-10-4-13l3-5h5l1%205-1%201%201%207q6%204%2011%202l3-4%202-4-1%2023-2%2011-2%2011h-17l-3-7%204-1%202-1%205-3v-6l-4-1v-2h-2l-3-1h-3l-3-1h-2l-3-3v-2q-8-26-26-47v-2l-2-1q-4-2-7-6l-2-1-3-3%201-5z'/%3e%3cpath%20fill='%23b6d462'%20d='m235%2022%203%205%202%203%202%203%202%203%205%208q-4%203-9%202l-42%201h-12l-15-1-7-1h-17c20-21%2061-23%2088-23'/%3e%3cpath%20fill='%23e1de59'%20d='M200%20439q4%204%203%2010l4%206v-4l1-4%202-1v-7q4%202%207%206v6h2v-2q1-5%205-6h2c0%205%200%205-3%208l-5%201v14l4-4-4%208-1%2015v9l3-1%201%202%202-1%206%202%204%205v-2l6-15v7l1%202-2%201-2%206h2l3%207h-61v-8l-2-6v-4l-1-3-2-7-1-4-1-4-2-1-2-1v-7l2%202%202%201%203-1%201-3%203-4%202-1v2l1%2022%201%203%203%2014%204-1v-2l-3-8v-3l-1-2-1-3%201-6%203%2010%201%203%201%203v3l2%207h4l-3-35-1-18h1l3%2019v6l2%209%201%2014h2l1%202%201-3h-2l1-2-1-7h2v2l1%203v3l1%202%202%201-1-8%202-1%203%203q0-6-3-10l-2-3%201-2h2l2%206h1l1-6v-3l-1-5h-2l-2-3q-2-4-6-5l1%207%202%204v4l-5-1-2-6h3v-2l-1-9-1-3v-3l-1-3z'/%3e%3cpath%20fill='%23b6d462'%20d='m111%2066%2011%2011v2l-8%201h-2l-12-1-3%201%202%2014%202-1v3l2%2035%202-8%201-3%201-2v-2l4-5-7%2025%2011-4q9%200%2016%206l2%205h-30l-1%204-2-3-5-1%201-2q2-4%202-9v-11l-1-9H78l6-7h2l3-1%207%202v-4l-1-4v-3l-1-15-10%201-11-2h-2l-1%201H58q5-10%2017-15%2019-9%2036%201'/%3e%3cpath%20fill='%237f775d'%20d='M34%20454v2h4l3%203%206%205-1%202-3%201-1%202h2l1%2016-6-2%201%207%205%203q2%206%201%2014H23l-1-5-2-7-7-34%204-3%204-2v-2q7-3%2013%200'/%3e%3cpath%20fill='%23e1de59'%20d='M244%200h28q3%2016%203%2031l1%208%201%2025-16-17-3-5a76%2076%200%200%201-14-42'/%3e%3cpath%20fill='%238b3a42'%20d='M82%20342h2q9%200%2016%202l2%205%203%201v3h-2l-2%201h-3l-2%201-1%202h-2v-2h-4l-1%204q12-1%2023-6h3l3%208v5h-2v-2h-2l-1%206-2-2-2%202-4%202v-2h-2l-1-5-2%2011q0%202-3%205l-2-1-1%203-6%201v2l-7%204%205-20-1%202-5%201-1%202-5%2013-5-7%201-5-4-1%201-5%202-1v-2l1-2%208-2%202-1%201-4h2v-3l-2-1v2q-4-1-7-6v-2l-5-2v-2z'/%3e%3cpath%20fill='%23533e31'%20d='M320%20247v61l-1%207-6-1v-4l-1%204h-4l-9%201%202-5-4%203-3-7%203-1%203-1%203-1%206-4h2q1-5-2-10-10-6-22-8h-2l-1-8v-21h4l-2%209%201%202h2l2%201%201%205%201%204%208%201h5l1-4v-2l-2-5v-5l3-1-2-5%204-1%207-3z'/%3e%3cpath%20fill='%23dbf4da'%20d='M0%200h11l4%2023%201%204%204%2045-20%201z'/%3e%3cpath%20fill='%238b3a42'%20d='m70%20297%201-1c5%200%205%200%208%203l1%201q-4%205-10%206l-3-1-2%202v-2h-4v5h4l1%207v4h2v-2l3%201-1%205h-3v5l4%201v2l-4%203-3%202-2%201-3%202-1-12-4%203-2-1-1%202-2-1-2-2-2-2-4-3v-2l-2-1q-3-1-4-5v-3l-1-6%2019%202v-5h-8v-2l-2%201-8-2-3-1-2-1v-2l4-1%202-1c10-4%2026-6%2034%201'/%3e%3cpath%20fill='%23533e31'%20d='m298%20412-1%204h9l-3%202v2l3%201%201-3%204-1-1-2h3l-2%2035-1%206-1%2015-4%201c-4-6-4-6-4-9l3-4-10%201-1-2h2l-2-3h-4v-4h3l4-1%202-3-5-1-3%203h-2l-5-21-1-3-1-10q4%200%206%203l6%201%201-3-4-2z'/%3e%3cpath%20fill='%23d77887'%20d='M81%20285q7%205%209%2013l-1%205q-11%208-26%207h-2v-5h8q4%200%208-3h2v-3l-8-3v2l-5-3q-19-3-36%203v2l15%203v2l3-1%205%201v5q-15%201-28-7l-1-7c4-9%2015-12%2023-16q19-4%2034%205'/%3e%3cpath%20fill='%23533e31'%20d='M187%20209h2v2c-1%2026-1%2026%204%2034l23%2016%203%202%201%206q12%205%2025%204v9l4%201v2l-5%202v-2l-4%201%203%203-7%203-3-3q-12-14-27-24l-2-2-26-18-4-3-11-8-3-2q-2-2-2-5v-3l4-1%203%202%202%202%202%201%204%203%202%202%208%205-1-3q-2-3-2-8l3-1%202-7z'/%3e%3cpath%20fill='%238b3a42'%20d='m33%20336%2015%205q-2%204-5%205h-3l-3%201-7%201%201%202q1%206-3%2012l-9%202-3%203-1%202-5%201-8%207H0v-39c21-4%2021-4%2033-2'/%3e%3cpath%20fill='%237f775d'%20d='M272%200h30c0%2016%200%2016-3%2022l-1%202-2%206-1%203q-1%205-5%208-6%203-13%203v9h-1l-2-20v-7l-1-10v-3l-1-3z'/%3e%3cpath%20fill='%23d77887'%20d='m40%20347-1%202h3l5%201%209%201h5l1-2%207-1%202-1%205%206%204%203v-2l3%201-1%203h-2l-1%205-2-1-15-6-1-1q-13-2-27%201l1%203h-3v3l9%203%202%201q9%203%2014%2011v3l-10-1-1%202-1-3H26l-5%201h-4l-4-1%204%205-1%201q-9%200-16-4v-3h2l6-7%202-1h5v-2l-2-1%205-2%202-1%208-1%201-5%201-2v-7l6-2z'/%3e%3cpath%20fill='%23b6d462'%20d='M32%200h22c0%2033%200%2033-4%2047l-3%2011v2l-1%204-4%208v-4c-6-45-6-45-10-64z'/%3e%3cpath%20fill='%23658675'%20d='M106%20404v3l4-2v2l2%201h-5l-1%205%207-1%201%209-2%201-1%204-1%203-1%203v2l-2%207-3-1H94q-8%204-13%2011l9%202h6l-4%2011-3-2q-4-5-12-4l-1-9v-5h2l5-10q6-9%209-17l1-3%202-6%201-3z'/%3e%3cpath%20fill='%238bad93'%20d='M15%20137q9%206%2012%2016v11l1%204%203%2054v2q0%205-2%208l-2%202-2-1-1%202-4-34-1-10-2-23-1-4z'/%3e%3cpath%20fill='%23d77887'%20d='m90%20324%209%205%203%202%202-1%201%202%201%202%2010%2013q-2%207-8%209-10%204-20%203l1-4h4v2h2l1-3%209-1-3-5-2-2v-2l-21-1-12%202h-6v-6l8-6%205-5%207-3q5-2%209-1'/%3e%3cpath%20fill='%238b3a42'%20d='m61%20404-2%204-4%201%201%203c2%2015%202%2015-1%2022l-2%201v-5l-2%201h-9v5l-1-4h-5l2%206%205%2017q-8-4-10-13-4-11-4-23H18l-7-1v-2l17-4%204-2%204%201v2l5%201h6l-1-5h-2l-4-4%201-2q10-2%2020%201'/%3e%3cpath%20fill='%237f775d'%20d='M220%200h24l2%209q2%2019%2014%2035l2%204-4-1q2%208%206%2015v6l-1-2-35-53-4-6-1-2z'/%3e%3cpath%20fill='%23533e31'%20d='m224%20451%201%206h7l-4%206q1%203%204%205v2h2v2l5%202%201-2h2c1%208%201%208-1%2013h-2l-5%2016h-3l-1-2-4-4-7%201%201-3h-2l-1%202q-2-4-1-10v-3q0-9%205-19l-4%204%201-15z'/%3e%3cpath%20fill='%23d9f0c6'%20d='M165%20104q5%204%204%207h-10l1%203%201%205%203%2012%201%205%205-11q2%206-3%2012-3%2015%200%2029l1%2031-1%204v3q-4-4-4-11v-10q0-27-5-54v-3l-3-14-11-1h-19c12-12%2025-17%2040-7'/%3e%3cpath%20fill='%23413a2c'%20d='M319%20388h1v119h-10q-2-7-1-15v-3l3-22q4-17%203-36-1-22%204-43'/%3e%3cpath%20fill='%23beb889'%20d='M94%2080h3l2%2014%202-1v3l2%2035%201-4%201-4%201-3%201-2v-2l4-5-7%2025%2011-4q9%200%2016%206l2%205h-30l-1%204-2-3-5-1%202-2%201-9v-11l-1-9H78l6-7h2l3-1%207%202v-4l-1-4v-3z'/%3e%3cpath%20fill='%235f715c'%20d='M100%20453h4l-6%2027q-4%2011%201%2021l2%206H81l1-5-2-1v-12l2-1%201-3h-4q0-5%204-8l3-2a30%2030%200%200%200%2013-20z'/%3e%3cpath%20fill='%238b3a42'%20d='M94%20398h3l17%202v2l-18%204-1%203q-4%2019-17%2032-3-5-3-10h-2l1-11%207-1%204-1-2-6-4-1v-3l-5-1%201-4h2l-1-3z'/%3e%3cpath%20fill='%23d77887'%20d='M19%20419h10l1%203q1%2019%2013%2034v4l-5-2v-2h-4v-2q-7-2-12%201l-1%202q-4%204-8%204l-1%203%204-25z'/%3e%3cpath%20fill='%238b3a42'%20d='M34%20454v2h4l3%203%206%205-1%202-3%201-1%202h2l1%2016-6-2v3q-4-1-7-6l-2-2-2-6-2-3-13-1v-7l6-4%202-1v-2q7-3%2013%200'/%3e%3cpath%20fill='%237f775d'%20d='m293%20115%205%203h5v2h2l1-3v2l4-1q1%205-2%209l-3%203-3%203-1%201-8%208-1%202-8%208-2%203h-1l1-29%202-2q3-4%205-3l2-4z'/%3e%3cpath%20fill='%23b6d462'%20d='M171%20333q5%201%209%204v2h2l7%205q-1%205-5%208l7-3-1%202%201%204%202%202v2l6%201-6%203v2h-2l1-4q-6-4-13-2l-2%201h-2l-3-3%202%202%201%203-1%202-1%204-1-1-7-4h-2l-2-1%201-5-7-3v-2l5-1v2l5%202v-2h2l2-5h5v4h2l-2-6-2-1v-2l-2-1v-3l-9%201h-3v2h-2l1-5%205-1%201-2zm50-178%208%206%201%205h-57c6-6%206-6%209-7l2-1%202-1%202-1q17-10%2033-1'/%3e%3cpath%20fill='%235f715c'%20d='M112%20352q4%202%204%206l1%203v5h-2v-2h-2l-1%206-2-2-2%202-4%202v-2h-2l-1-5-2%2011q0%203-3%205l-2-1-1%203-6%201v2l-7%204c3-16%203-16%206-22l1-4%201-5%207-1q9%200%2017-6'/%3e%3cpath%20fill='%237f775d'%20d='m0%20380%203%201%205%201h2l11%203-1%209v2c-1%2012-1%2012-4%2016q-6%203-13%202-4-6-3-13z'/%3e%3cpath%20fill='%23d3f3de'%20d='M244%200h28l2%2021h-3l-23-1q-3-9-4-20m58%200h18v35l-17-7-1-7z'/%3e%3cpath%20fill='%237f775d'%20d='m0%20344%2015%203%209%201%201%2014-7%203-3%204h-2q-6%201-10%206l-1%202H0z'/%3e%3cpath%20fill='%238bad93'%20d='M11%20471h2c8%2026%208%2026%208%2036H0c-1-20-1-20%204-26z'/%3e%3cpath%20fill='%238b3a42'%20d='m307%20147%201%203-4%205-2%203-15%2016c-4%205-4%205-4%209l14-16%203%202-2%203v7l5-2q2%206-1%2011-4%208-11%2011v-2l-2-1%204-11-2%203-2%203h-1v-10l-2%203-2%201-2%207h-16q3-6%209-8l6%201v-21h1l1%2010%2018-21%202-2h2z'/%3e%3cpath%20fill='%23dbf4da'%20d='M248%2044q7%205%2010%2012l2%207h-2q-11-1-20%206l-4%201-6-23q9-5%2020-3'/%3e%3cpath%20fill='%23beb889'%20d='M101%20364h1v6h2v2l6-5%201%201%201-2%201-2h2v7l-1%202%203-1%201-3h2l3%209h-3l-1-2q-3%203-3%207v2l-2%201q-3%200-5%204-4%204-12%204l-6-2q2-3%206-4h-2l-4-2h-4v-2l3-1%204-3%202-1%202-1%201-6c0-6%200-6%202-8'/%3e%3cpath%20fill='%23b6d462'%20d='M319%20365h1q1%2020-2%2039l-2%2026-4%2041-2%2022v14h-4l1-29%201-5%201-13%202-22%201-5%205-56v-3z'/%3e%3cpath%20fill='%23d6f5df'%20d='M0%200h11l4%2019v10l-6%204-2%202-7%204z'/%3e%3cpath%20fill='%23d9f0c6'%20d='M225%2071q3%202%202%206l-6%201%209%2048%204-23%203%204-1%202v4l-2%209q-2%2014%202%2028%205%2013%205%2026l-3-1-2-6v-3l-2-9-4-16q-9-31-12-63l-15-1%202-4q9-6%2020-2'/%3e%3cpath%20fill='%23b6d462'%20d='m159%2069%208%205v2l2%201q4%202%204%206h-10l-7-1-9-1-8-1h-13l1-4c9-6%2022-13%2032-7'/%3e%3cpath%20fill='%23dbf4da'%20d='m97%20112%201%209v2c2%2014%202%2014%200%2018l-2%201%204%201c4%2025%204%2025%203%2035q-3-2-4-5l-1-3-2-3-2-5-1-3-2-4v-26l-1-7v-9zm10-32h6c4%2014-1%2027-6%2040l-4%2012h-1l-2-22v-2q-2-11%203-21l1-2z'/%3e%3cpath%20fill='%237f775d'%20d='M249%20298h2v2l3%204%207%202h9l7%201v7l2%201%203%201%201%203-14%209-9-10v-2l-2-1q-4-2-7-6l-2-1-3-3%201-5z'/%3e%3cpath%20fill='%23d6f5df'%20d='M32%200h22v20l-8%201-11%202z'/%3e%3cpath%20fill='%238bad93'%20d='M188%20219h1v2q-1%204%203%209l12%2010%203%203%2010%207%202%203%206%205-5%205q-7-2-14-7l-2-2-8-6q-7-6-8-15z'/%3e%3cpath%20fill='%23b6d462'%20d='M71%2026q14%205%2024%2015-2%202-7%203h-6l-22%201q2-12%2011-19'/%3e%3cpath%20fill='%23beb889'%20d='m307%20232%201%202%203-1h4l4%205q-7%207-18%206l-9%201q-5%200-9-2v2l-6%201-4%201-8-1%201-3%204-1v-2l6-4v3l2-1%202-1%203-1%202-1%202%201v2l9-3v2l3-1%207-1z'/%3e%3cpath%20fill='%23b6d462'%20d='m260%2062%204%204%202%202%204%206-1%203h-21l-13-2v-5q11-10%2025-8m-95%2042q5%204%204%207h-44c12-12%2025-17%2040-7'/%3e%3cpath%20fill='%23beb889'%20d='m90%20324%209%205%203%202%202-1%206%2010h-10l-4-3-1-2-2%201-20%202-1-4%202-6%207-3q5-2%209-1'/%3e%3cpath%20fill='%237f775d'%20d='M180%20456h2v2l1%2022%201%203%203%2014%204-1v-2l-3-8v-3l-1-2-1-3%201-6%208%2030h-12l-3-7-1-2q-2-10-1-19l-1%205-2-6h-2v-2l-2-1-2-1v-7l2%202%202%201%203-1%202-6z'/%3e%3cpath%20fill='%23dbf4da'%20d='M0%20408q5%209%206%2019l1%202v4l2%2011%201%204v8h2v-3l4-17%202-17%202%202-1%205v3l-1%203v4l-5%2020q0%2013%205%2027l5%2024h-2l-8-36h-2l-1%202-5%209-2%203-2%202-1-3%206-8q4-5%204-10l-1-5-1-3-3-12-1-7-1-5-1-6H0z'/%3e%3cpath%20fill='%238b3a42'%20d='m104%20439%205%204h3v2l3%208h-15v-2h-4v2h-9q-4%200-7-2c5-7%2014-16%2024-12m-18%2019%205%205v3c-7%202-7%202-11%201l-1%205-4%209-2%205q-6-4-9-9l4-5%204%201-1-4-5-1q2-4%206-7l2-2q5-3%2012-1'/%3e%3cpath%20fill='%23b6d462'%20d='m108%20241%203%204q2%208-1%2014l-1%203%203%204q5%204%206%2010l11%2016v-19q4%208%204%2015v4l1%203v3l-1%209h-1l-1-3q-1-7-6-12l-3-5-7-11-2-3-3-5q-2-5-6-6l-4-1q-4-1-6-4l1-3%2010%204-1-2v-9z'/%3e%3cpath%20fill='%23dcf5de'%20d='M258%20255h8q4%200%207%203l-1%203-8%202-2%201-27%203v-2h-7v-2l-4%202%202-4h2v-2l7%201v-3h2v2h2l19-2z'/%3e%3cpath%20fill='%23413a2c'%20d='M34%20308h4l3%201%2012%201v19l-2%204-2-1-2-2-2-2-4-3v-2l-2-1q-3-1-4-5v-3z'/%3e%3cpath%20fill='%237f775d'%20d='M122%20460h2c7%2011%200%2033-1%2045h2l1-2%207-7q-2%207-7%2011h-6v-2q1-13-5-24l-1-5v-5l2%204z'/%3e%3cpath%20fill='%23658675'%20d='M100%20453h4l-6%2027q-4%2011%201%2021l2%206-4-3-1-3-1-3-1-3-3-6-1-2-3-6-1-5%204-5q8-7%2010-18'/%3e%3cpath%20fill='%23b6d462'%20d='M121%20132q6%202%2010%206l2%205h-30l-1%204-2-3-5-1q2-4%206-6l3-1c6-1%2010-5%2017-4M19%2058l1%2014-20%201V60c4-4%2014-2%2019-2'/%3e%3cpath%20fill='%23658675'%20d='M29%20231q4%2010%204%2021v10l1-2c7%200%207%200%2011%202l-3%205h-8l-4-5-2-1-1%203-1-10-1-3c-2-14-2-14%200-18z'/%3e%3cpath%20fill='%23dcf5de'%20d='m75%20282%203%205%202%201v2l-9-3v-2h-4l-1%202h-6v3h-2l-2-2-2%201c-6%200-6%200-10-2v-2l-2%201-5%201v-2l5-3%202-1c9-4%2023-4%2031%201'/%3e%3cpath%20fill='%23402f2c'%20d='M96%20451h4q0%2012-7%2019l-11%209q-3%204-4%209l-3%201-2-6%203-5%201-9h2l1-2h5q4%201%207-3%203-6%204-13'/%3e%3cpath%20fill='%237f775d'%20d='M200%20439q4%204%203%2010l4%206v-4l1-4%202-1v-7q4%202%207%206%201%2011-2%2022l-1-2h-2l-2-3q-2-4-6-5l1%207%202%204v4l-5-1-2-6h3v-2l-1-9-1-3v-3l-1-3z'/%3e%3cpath%20fill='%23b6d462'%20d='m119%20375%201%203h4l1%202%201%203%205%201%201%203-2%203h-4l-1%202h-3l1%205-5%203-6-6-1-2-1-4%201-2%205-1-1-2%202-6z'/%3e%3cpath%20fill='%235f715c'%20d='m75%20403%2015%202q-1%2018-13%2031h-2v-5h-2l1-11%207-1%204-1-2-6-4-1v-3l-5-1z'/%3e%3cpath%20fill='%23533e31'%20d='M272%200h14l-1%204-1%209-4%2010-3%207-3-7v-3l-1-3v-3z'/%3e%3cpath%20fill='%23d9f0c6'%20d='m79%2081%202%203-2%206-4%2012-1%203-2%209-2%205-4%2015h-2l-4-32h-9q2-6%208-7l7%204%201%202-5%201%201%208%201%203%202%207%2011-36z'/%3e%3cpath%20fill='%23658675'%20d='M284%20267h1v9l-1%204-7%201-7%203q-4%200-6-3-3-2-2-5l1-2-1-3q4-3%2010-3l11%207z'/%3e%3cpath%20fill='%23413a2c'%20d='M60%20365h9l-1%205h-2v5l3%201v2q0%203%202%205%202%206%200%2011l-5-2-3-1q-4-2-3-4z'/%3e%3cpath%20fill='%23dcf5de'%20d='M320%20173v29l1%203-1%206-5%203c-4-30-4-30-1-37q5-5%206-4'/%3e%3cpath%20fill='%23beb889'%20d='m63%20342-1%202h2q3%200%205%202l1%202q-13%206-27%202l-5-1%203-5%205-1%203-2q7-1%2014%201'/%3e%3cpath%20fill='%23e1de59'%20d='M224%2023h4v1h-4l-3%201-5%202h-3l-1%202-9%203v2l-9%203v2l-6-1q0-5%203-9l-5-1v-1l10-1%203-1z'/%3e%3cpath%20fill='%23d3f3de'%20d='M72%200h17L75%2016l-3%202-2%203-2%202-2%201%203-15z'/%3e%3cpath%20fill='%23b6d462'%20d='M194%20445h1l3%2019v6l2%209v6l1%202v6h2l1%202%201-3h-2l1-2-1-7h2v2l1%203v3l1%202%202%201-1-8%202-1%203%203%202-3v13h-6l-4%203h-3l1-4h-3l-1%202-2-4h1z'/%3e%3cpath%20fill='%235f715c'%20d='M80%20358h2l-5%2021-1%202q-2%207-4%207c-4-7-4-7-4-10l1-2-4-1%201-5%202-1v-2l1-2%208-2%202-1z'/%3e%3cpath%20fill='%237f775d'%20d='m307%20147%201%203-4%205-2%203-8%209-3%203-4%204q-6%208-5%2018h-16q3-6%209-8l6%201v-21h1l1%2010%2018-21%202-2h2z'/%3e%3cpath%20fill='%23b6d462'%20d='m14%2029%203%2010v7l-9%201v-2l-3%202-5%201v-9c4-4%204-4%208-4l1-3z'/%3e%3cpath%20fill='%23e1de59'%20d='M53%2020v15l-3%203-5-7-8%202-1-11%206-2z'/%3e%3cpath%20fill='%23beb889'%20d='m34%20317%202%202%203%202q3%202%203%206l-3%201-1%203-2-2h2v-3l-10-2-2%202q-3%203-7%202l-2-3%201-2-5-1%202-4q10-4%2019-1'/%3e%3cpath%20fill='%23b6d462'%20d='m241%20182%204%205v2l-10%201h-20q6-8%2016-10%206-1%2010%202'/%3e%3cpath%20fill='%235f715c'%20d='M11%200h8v3q-1%2011%203%2021v3h-2l1%204-4%203q-4-4-3-9v-2l-1-7-1-5zm0%20471h2q3%206%202%2012l-3-1v3q-4%2010-11%2017H0q-2-11%204-21l6-8z'/%3e%3cpath%20fill='%23413a2c'%20d='m65%20310%201%207v4h2v-2l3%201-1%205h-3v5l4%201v2l-4%203-3%202-4%202%201-29z'/%3e%3cpath%20fill='%23b6d462'%20d='m140%20348%203%202%201%207h-2v3q0%206-3%2011h-5l-3-1v2l-6%201%201-3%205-1%201-10-3-1h6v-2z'/%3e%3cpath%20fill='%23533e31'%20d='M249%20298h2v2l3%204%207%202h9l7%201v4q-6%201-10-2c-4%206-4%206-4%2010l-3-1v-2l-2-1q-4-2-7-6l-2-1-3-3%201-5z'/%3e%3cpath%20fill='%23402f2c'%20d='m53%20430%201%208v2q1%206-2%2012h-3l-3-4-4-8v-9h3z'/%3e%3cpath%20fill='%237f775d'%20d='M277%20414h6l-2%201%201%202%202%2011%204%2021%202-2%206-2%202%201v3q-1%203-6%202h-3l1%204%204-1%201%204-5%201%202%2014-4-12v-2l-2-8-1-5-4-18-1-4v-3l-1-6z'/%3e%3cpath%20fill='%23e1de59'%20d='M319%20365h1q1%2021-3%2041l-1%2015c-1%206-1%206-3%208l1-25v-4l3-23v-3z'/%3e%3cpath%20fill='%237f775d'%20d='M249%20284q5%204%205%2010l-8%209-9-11%205-3-3-4h8z'/%3e%3cpath%20fill='%23e1de59'%20d='m304%2028%207%203%203%201%206%203v7l-4%201h-11z'/%3e%3cpath%20fill='%23beb889'%20d='m100%2078%207%202q-2%208-8%2015h-1l-1-7v-8zm7%201h15v1h-7v4q3%2013-3%2026l-2%201%202-9%201-13v-9h-6z'/%3e%3cpath%20fill='%23b6d462'%20d='m216%2098%203%206h-12l-15%201q3-7%209-9%208-3%2015%202m-95%20205q2%205-1%2010l-3%204v11l1%2023v5l-2%204-2-4v-3l-1-2%201-1v-28l1-7v-3q-1-8%206-9'/%3e%3cpath%20fill='%23533e31'%20d='M246%2019h2l1%203q2%2011%209%2018l1%202-1%203q-11-7-18-17l1-6%202-1v3l2%201z'/%3e%3cpath%20fill='%23d3f3de'%20d='M261%2045h15l1%2019q-9-7-16-18z'/%3e%3cpath%20fill='%237f775d'%20d='M38%20467h4v2h2l1%2016q-9-4-13-12l-1-5zm178%208h1v8l2%205%206%201-2-8c6%204%206%204%207%208v2h2v3l1%203%202%201-2%204-5-6-6-1-3%201%201-3h-2l-1%202-1-3z'/%3e%3cpath%20fill='%23b6d462'%20d='M113%20471q4%204%205%209l1%202%202%206q3-4%202-10l3-5-1%2012v4l-2%2016h2l1-2%207-7q-2%207-7%2011h-6v-2q0-15-6-29z'/%3e%3cpath%20fill='%237f775d'%20d='M1%20168h1a392%20392%200%200%201%202%2059l-1%2015-1%2010v7H1z'/%3e%3cpath%20fill='%23beb889'%20d='M207%20112v4l-3%201h-24q12-11%2027-5'/%3e%3cpath%20fill='%23dcf5de'%20d='M320%2042v8l-10%205-4%202-1-9v-5h7l4-1z'/%3e%3cpath%20fill='%23533e31'%20d='m267%20445%203%207v2l2%2011%207%2042h-3v-2l-3-19-2-7-1-10-1-3v-3l-1-3-1-5z'/%3e%3cpath%20fill='%23d9f0c6'%20d='M146%20111h2v3q-1%2018%205%2035v5h-2l-3-14h-1v11l-1%202v2l-2%205-1-12q2-15%200-31l2%203z'/%3e%3cpath%20fill='%23d3f3de'%20d='M0%20408q7%2011%207%2025l1%203%201%2015-2%201-2-10-1-3-1-3-1-3v-5H0z'/%3e%3cpath%20fill='%238b3a42'%20d='M291%20209q2%200%203%205l1%203-5%204%201%202v5l-8%202v-2l-1-3-2-1%201-2h2v-2l4-4-3-3q3-5%207-4'/%3e%3cpath%20fill='%23b6d462'%20d='M225%2071q3%202%202%206h-24q2-6%209-7%206-2%2013%201'/%3e%3cpath%20fill='%23dbf4da'%20d='M39%2046h9l-2%2019-4%207-1-11-1-3v-3l-1-3z'/%3e%3cpath%20fill='%23dcf5de'%20d='m292%20325%201%204h2v2l2-1%205-2%202%208q-10%201-20-3v-4l5-2%202%201z'/%3e%3cpath%20fill='%23e1de59'%20d='m103%2061%202%202-10%204-4%203-4%201-3-1-4-1v-4l-2-1q12-4%2025-3'/%3e%3cpath%20fill='%23beb889'%20d='m21%20385%204%201%201%2020-4%201-1%203-1-2h-2zm277-45-1%203-1%203%203%204v9h-6l-5-6%204-2-1-3v-6z'/%3e%3cpath%20fill='%23b6d462'%20d='M320%2050v12h-14v-5l5-4%203-2z'/%3e%3cpath%20fill='%238b3a42'%20d='m79%20415%202%201%205%201q-3%204-7%204h-4l-2-2H63l-3-1-2-4q11-2%2021%201'/%3e%3cpath%20fill='%237f775d'%20d='M305%2064h1l1%207-5%205-3%203-1%202-3%203-9%209%206-12%202-2%208-12h2z'/%3e%3cpath%20fill='%23beb889'%20d='M94%20470v4l-1%203-1%204%202%209%202%203%201%203%202%205%201%202%201%204-4-3-2-6-1-3-3-6-1-2-4-9%201-4q4-5%207-4'/%3e%3cpath%20fill='%23d9f0c6'%20d='M199%20165h17v1h-10v2q4%2025%204%2050h-1v-3l-2-10v-4l-1-6-1-4-1-5v-2l1-1v-9l-1-2v-6h-5zm15%2025h11l1%2020v3l-1%2032h-1l-1-20v-34h-9z'/%3e%3cpath%20fill='%23b6d462'%20d='M97%20107v5H78q4-7%207-7%207-1%2012%202m97-17%204%204v2l-23%201q8-9%2019-7m79-9%205%205v4h-5v7h-1v-7h-12q5-7%2012-8z'/%3e%3cpath%20fill='%237f775d'%20d='M319%20388h1v33l-3-1v5l-2%201z'/%3e%3cpath%20fill='%238bad93'%20d='m133%20340%204%204%201-2%203%201-1%207-3%201-2%207-6-1%203-8%201-4-2-2h2z'/%3e%3cpath%20fill='%237f775d'%20d='M141%20439h1l-1%2038v6l-1%2013h-6l1-4%204-1zm53%206h1l3%2019v6l2%209v6l1%202v6h2l-1%204h-2l-1%202-2-4h1z'/%3e%3cpath%20fill='%23b6d462'%20d='M226%20443c0%205%200%205-3%208l-5%201v14l4-4-4%208-2%207h-1v-11l1-3v-3l1-9h2v-2q1-6%207-6'/%3e%3cpath%20fill='%23402f2c'%20d='M63%20418h10q2%2010-3%2018l-3%205h-3l3-9%201-11-5-2z'/%3e%3cpath%20fill='%23beb889'%20d='m44%20285%203%204h-4l-2%204-6-1-1%202-6%201%201-6q7-4%2015-4'/%3e%3cpath%20fill='%23d9f0c6'%20d='m3%20457%205%205q0%206-4%2011l-2%203-1%203H0v-16l2-1z'/%3e%3cpath%20fill='%237f775d'%20d='M314%20427c5%207%202%2019%201%2027v2l-3%2017h-1z'/%3e%3cpath%20fill='%23b6d462'%20d='m281%20185%201%207h-16q5-10%2015-7'/%3e%3cpath%20fill='%23d9f0c6'%20d='M272%2097h1c1%2017%202%2033-9%2047l-3%202%201-2%201-5%201-4%201-2%202-1q4-8%204-17z'/%3e%3cpath%20fill='%23b6d462'%20d='m255%20341%201%202-11%2015%208-1q-2%204-4%203l-2%201q-8%201-12%209l-2-2%202-2z'/%3e%3cpath%20fill='%237f775d'%20d='M314%20408v8h-3v3h-4l-1%202-4-1%201-5h2v-5z'/%3e%3cpath%20fill='%238b3a42'%20d='m288%20398-1%202-2%206-8-1-4-2c5-6%207-6%2015-5'/%3e%3cpath%20fill='%23d9f0c6'%20d='M6%2072h14v1h-8v2l1%2012v30h-1l-1-29V73H6z'/%3e%3cpath%20fill='%23b6d462'%20d='m149%20340%204%201v2l2%202h-3v5l-7%202-2-11h5zm49-40c6%204%206%204%207%208l-1%208c-7-4-7-4-8-8z'/%3e%3cpath%20fill='%23dbf4da'%20d='m103%2078%203%201-7%2016h-1l-1-7v-8z'/%3e%3cpath%20fill='%23b6d462'%20d='M241%20373q1%207-2%2012l-1%202-2%205-2-7h-2l3-11%202%201v3h2z'/%3e%3cpath%20fill='%23d9f0c6'%20d='M84%20112h10l-4%201v2l1%2015%201%2025h-2l-2-28v-2l1-12h-5z'/%3e%3cpath%20fill='%23beb889'%20d='M103%20143h8v1h-7v2l1%2023-4-11v-3l-1-11%202%202z'/%3e%3cpath%20fill='%237f775d'%20d='m224%20451%201%206h7l-2%204h-8l-1-3-3-2v-4z'/%3e%3cpath%20fill='%235f715c'%20d='m9%20464%202%202q0%207-5%2012l-2%202-3%204H0q2-11%209-20'/%3e%3cpath%20fill='%23b6d462'%20d='m153%20281%205%2010%202-3v3q0%205%203%2010l2-2%204-4q-1%206-5%2010l-1%203-2%202-2-2%201-2q1-6-3-13l-3-5-1-2zm73%2041%203%201-3%207-5%202-2%205-5%205%202-8%203-1%201-3q1-6%206-8M34%20260c7-1%207-1%2011%202l-3%205h-8l-2-4zM254%2097q6%200%209%205l-4%201h-12q4-7%207-6M61%2096q4%201%206%205l-4%201H51q3-7%2010-6'/%3e%3cpath%20fill='%238bad93'%20d='M312%200h8l-1%207h-2l-1%202-5%202z'/%3e%3cpath%20fill='%23e1de59'%20d='m85%20499%207%201v7H81v-4h2z'/%3e%3cpath%20fill='%238b3a42'%20d='m66%20483%207%206-1%202c-6-1-6-1-8-3h-6l-2-1%201-3q4-2%209-1'/%3e%3cpath%20fill='%23d9f0c6'%20d='m150%2080%205%201%202%2019-4-1z'/%3e%3cpath%20fill='%23533e31'%20d='M265%20468h1l1%2015%201%205v8l1%202v9h-3v-12l-1-3-1-21v-2z'/%3e%3cpath%20fill='%238b3a42'%20d='m311%20317%203%202h2v2q-8%203-17%200v-2c7-4%207-4%2012-2'/%3e%3cpath%20fill='%23beb889'%20d='m107%20403%207%202%202%205h-4v2l-5%203-2-3%202-4%203-1-5%201z'/%3e%3cpath%20fill='%23dbf4da'%20d='M15%20137c6%204%206%204%207%208q0%203-3%205l-3%202-1-9z'/%3e%3cpath%20fill='%23533e31'%20d='M154%20461h1q4%2023%204%2046h-1l-1-13z'/%3e%3cpath%20fill='%23b6d462'%20d='M319%20365h1v20l-2%207v-7h-2l1-9v-2l1-5zm-148-86q3%202%202%206%200%204-2%207l-3%202q-3-5-1-10z'/%3e%3cpath%20fill='%23e1de59'%20d='M198%20323q5%204%206%209c-6-5-6-5-6-9m-55-11h2l-2%206z'/%3e%3cpath%20fill='%235f715c'%20d='M1%20454v3Zm120-95%202%201-2%202z'/%3e%3cpath%20fill='%23e1de59'%20d='m234%20356%202%201-2%201zm-125%2047%202%201Z'/%3e%3cpath%20fill='%23d77887'%20d='M277%20229h2l-1%202z'/%3e%3cpath%20fill='%238b3a42'%20d='m304%20255%202%201Z'/%3e%3c/svg%3e",
	meadow: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='507'%3e%3cpath%20fill='%239b5631'%20d='M0%200h320v507H0z'/%3e%3cpath%20fill='%23926539'%20d='M0%200h320v150c-2%202-9%202-11%202l-21%204%201%205%201%207%201%207c2%2012%202%2012-1%2016l1%204-5-5q-4%202-6%206l-1%206-2-1%202-9-4-1h6v-2h2l-1-6-1-9-1-4-2-13-4%201-4%201-5%201-7%201%205-25h-2l-1%206-2%2010-2%206-1%204-8%202-1-3-4%2022-2%2014-9%202-1-5-1-6-1-6-3-11-2-1v3l-10%205-19%2010c-6%203-6%203-13%202l-28-9-26-7-11-3-24-4-7-2-10-1v-2h-7l-9-2h-5c-18-2-18-2-21-5l-13-2-2-1-18-2z'/%3e%3cpath%20fill='%231765c3'%20d='M74%20379h6l-2%206h-3l-1%204-2%204h2l2-6%205-3-6%2014%204-2%202%202h3v3l3-5h3l3-6h2v6l3-3%203-4h2l-2%207%206-2v6l3-5%202%201-2%204v4l6-12q4-6%2011-11v4l3-2%201%205%204-7c1%204%201%204-2%2011l-2%207%204-5%201%204h3l2-2-1%206v2l3-4%204-5h2l1-4-1%208h2l1-6%205-5-2%209%207-10q2%208-1%2015l2-1v5l4-4%202%201-4%207q6-2%206-4h2l1%202%203-2-2%206v2l5-8q2%207-2%2012l3-5h2v3l3-3h2l2-4%202-1-1%205h6l2-5%203%201-1%202%206-3v2l6-4-2%204-2%206%204-3-2%204%201%203%204-3-6%2016-2%205%205-6%209-4%203-2-1%205%204-1%202-4%202%202%202-3%203-4h3l2-1%202%205h3v-2h2l1%2014%204-2v-7l1-7%206-5%201%2010%205-8%201%202%203-1-3%209h2l2-4%202-2v3h2q3%206%200%2012h2v-2h4v-2h2v3q4%200%207-5l2%201-3%205v5q4-3%204-7l4-1%201%205%201-4%204-2c1%207%201%207-1%2010l4-3%202%201-1%202h2l2-4%203-4h2l2-7h1v79H0V406c17-17%2017-17%2020-18v2h3v4l3-2%202%201%201-2v3l5-5%202-1v4l2-1%201%205%205-4%201%203h-2l2%202%203-3-2%206%205-4h2v3l6-7%203-3h1l-1%207%204-4-1-4%207-7h2z'/%3e%3cpath%20fill='%23428ceb'%20d='M0%2065h16c2%203%202%203%201%2010l67-1%2013-1h40l6-1h10l15-1h57c6%201%206%201%2010%205l2%204%203%203v2l4%202%2011%209%2015%2010%202%2011%201%208%204%2018v4l1%2010-8%202-5%201-7%201%205-25h-2l-1%206-2%2010-2%206-1%204-8%202-1-3-4%2022-2%2014-9%202-1-5-1-6-1-6-3-11-2-1v3l-10%205-19%2010c-6%203-6%203-13%202l-22-7-6-2-26-7-11-3-24-4-7-2-10-1v-2h-7l-9-2h-5c-18-2-18-2-21-5l-13-2-2-1-18-2z'/%3e%3cpath%20fill='%23a26726'%20d='M320%20150v273q-1%2013-13%2022v-3l-4%201%201-7-1-2-3%201-1%209h-1l-1-9h-3l-1%206-3%201c-1-5-1-5%202-10l-6%205-2-1v-3h-2v2h-4v2h-2l1-4-1-8h-4l-2%203h-2l2-8h-4l-4%207-1-10-5%204-1%2014-2%202h-3l-1%202v-16h-2v2l-3%201-3-5-3%202-1-1-5%207-2-2-2%204h-4v-4l-4%203-8%204-2%204h-2l-1%203-1-2q7-19%2020-36l8-13h2l2-4%206-7%203-4%203-4%202-14%201-10-3%201-1-2h2q-5-7-15-7l1-3h5v2l7%202v-2l-3-1c-2-7-2-7-1-10l7%203%205%201%201-4q10-27%2024-53l3-6q-1-4-6-6c-6%200-6%200-11%202l-1-5q-1-7-5-13l-8-1-5%206%206%201q10%2011%2010%2026h-2l-1-3-1-5-2-5-5-11c-7%201-7%201-12%204q2-4%205-6-1-9-6-16l-5-2c0-7%200-7%203-11h4v-13l3%203%205-5-2-10-4-1c0-7%200-7%204-11q6-9%208-22l1-3%208-2%205-1%207-1%204%2024%201%208h-2v2l-2%201-1%209%201%201v-4c1-5%201-5%205-9l6%204-1-3%202-2q0-16-4-33l10-2%206-1zm-64%2043-2%202-6%201%202%203h2l1%208h4l2-4%202-1v-5l-4-4zm2%2012q2%206%206%2011l2-1%202-9-4-4z'/%3e%3cpath%20fill='%2366442f'%20d='M0%20160c7%201%207%201%2010%204%204%2011%204%2011%203%2015l-5%201-1%201%203%2011%201%206c2%205%202%205%208%2012l1-23%203%202q3%2013%202%2025l2%2013%209-7%203-16%203-8h2v9q7-6%2010-15h2q-1%2012-12%2020h-2v5c-2%209-7%2012-14%2018h-2l1%202%201%209v9c10-2%2010-2%2013-4l11-1v-2q8-4%2016-4v-2c5-2%205-2%2010-1l2%201%201-3q5-4%2012-4l6-2%207-1%204-1-3-7v-18l2%201%204%2022h2v-14l2-12h2l2%2010q6-6%209-14l4-4q-1%2012-10%2021-5%205-4%2013l-1%2016%203-3h2l-3%207h-2l-1%2017%2017%202-3%209q-8%2019-11%2040l-1%206-1%204h-3l-1%202h-2l-1%203v-2h-3l-1%203v-2h-2l-1%204h-2l-1%204h-5l-9%201v-5l-2-1h2v-2l-4-1%204-1-1-4%203-3-2-1%201-11h2v-6l-4%208-3%205-5%2011c-9%208-9%208-12%208v3l1-1h7l-3%209-3-1H56l-1%204h-2v2l-6%201v-2l-3-1%202-3-2%201-1%203-4%201-2%201v-3l-5%201-2%204h-3l1-7c5-2%205-2%208-1l-1-3%202-3h-3v3l-5%202-3-3%201-4h-2v-2h-2v2l-4-1%203%205v2h-2v2h-5l3%205-3%201-1%202%203-1v3h-6v3l-4%201-1%204H4v-2l-4%201z'/%3e%3cpath%20fill='%23fdc145'%20d='m0%20150%2029%204%209%202%2021%203%201%201%2015%202v2h4q10%200%2018%203l11%202a275%20275%200%200%201%2053%2014l16%205c7%202%2010%203%2017-1l3-2c21-12%2021-12%2026-12q4%2013%204%2026l-1%201h-5l-2%207%204%201%203%201%202-2-4%2011%205%204%201%203h-2l-3-3-3-2%201-9-2-2c-5%201-5%201-8%205l1%206%204%201-6%205-4%208%205%204%205%2010%202-1-1%205h5l1%202h-4c-5%201-5%201-10%207l-3%203q1-4%204-7c3-4%203-4%203-9l-4-9-9-1-6%208%204%203-1%202-5-3c-5%201-5%201-9%206q-4%208-5%2016h-2l-2-6c-3-6-3-6-7-9l-8%201h-3l3-3v-6l3%202-1%204%205-1c6%204%206%204%2010%2010q6-6%204-15c-1-5-1-5-5-10l-9%201%201-6-1-4%204-5-2-7h-6l-5-1-1%202-2-1v-4h-2l-1%206-2%2012h-2l-3-24h-2v6l-2%208v7l-6%204%202-4%202-6-12%204h-8c0-8%200-8%204-12l4-4c4-9%204-9%204-14l-2%204q-3%208-10%2013l-1-11-2%201-2%2016v9h-2l-5-22v13l2%208v3l-11%203-6%202h-4c-4%201-4%201-9%206l-7-1-5%201v2l-16%204v2l-8%202-8%203h-8l-1-9-1-5v-6l11-9c3-4%203-4%204-9s1-5%205-8q8-7%2010-17h-2l-2%205c-3%206-3%208-9%2011l1-10h-2l-1%204-1%206-1%205c-2%209-5%2012-12%2017q-4-8-3-18c-1-15-1-15-3-22l-1%2023q-9-8-12-21l-1-5v-8l1%202%205-1-1-5-3-11-9-2zm185%2088-3%204%203%208%201-2%207-2c-1-5-1-5-4-8z'/%3e%3cpath%20fill='%233c75de'%20d='M0%2065h16c2%203%202%203%201%2010l67-1%2013-1h40l6-1h10l15-1h57c6%201%206%201%2010%205%202%204%202%204%201%209h-2v3l-5%201-1-5h-13l-11%202-16%201-4-5h-9l-1%203c-8%204-8%204-11%204l-1%202h-3v8l-6-1h-10l-1%201-4%201-9%203q-7%203-16%202-17%200-33%207l-2%202v1l52%201%201%207-7%205q-9%207-10%2017v13l-14%204-4%201q-10%202-21%201v-2h-7l-9-2h-5c-18-2-18-2-21-5l-13-2-2-1-18-2z'/%3e%3cpath%20fill='%23db9180'%20d='M0%200h23l8-1h12c7%201%209%204%2014%209q6%2010%203%2021c9%202%2013-1%2021-5q15-4%2029%203%207%205%209%2012v11l6-1%203%203v4l4-2c7-3%2010-4%2017-3l7%204v-5q0-13%209-22%2012-10%2029-9%209%201%2017%207v2l2%202v2h-3l1%203-2%202v7l-3%201%201%207h-3l-1%207h-2l-1%205-2%208h-21l-19%201h-15l-6%201H91l-13%201-61%201v-4l-1-6-16-1zm289%20218%201%202-2%206q2%2011%209%2019l2-1%201%204%203-3c4-3%204-3%208-3l-5%2013q-6%2013-9%2025l-1%205q-7%2026-9%2051l6-4c15-8%2015-8%2021-8l2%205-5%205q-27%2026-43%2061v4l4-1%203%201-2%205%205-3-4-5v-2l4-1-3-2v-7l5%201-2%204%203%201%203-3%205%203v2h-3l2%205v2l2%202-1%202h2v-2h3v2h-2v3h-2l2%205%201%204h-3l-1%204-7-4-1%204q0%202-6%204v-2h-2l-1%204-2%203h-2l2-8h-4l-4%207-1-10-5%204-1%2014-2%202h-3l-1%202v-16h-2v2l-3%201-3-5-3%202-1-1-5%207-2-2-2%204h-4v-4l-4%203-8%204-2%204h-2l-1%203-1-2q7-19%2020-36l8-13h2l2-4%206-7%203-4%203-4%202-14%201-10-3%201-1-2h2q-5-7-15-7l1-3h5v2l7%202v-2l-3-1c-2-7-2-7-1-10l7%203%205%201%201-4q10-27%2024-53l3-6q-1-4-6-6c-6%200-6%200-11%202l-1-5q-1-7-5-13l-8-1-5%206%206%201q10%2011%2010%2026h-2l-1-3-1-5-7-16c-7%201-7%201-12%204q2-4%205-6-1-9-6-16l-5-2%201-2q8%203%2011%2011l1%203%202-3%2012-1%202%204%204%205%205-13%204-1%204-2h5l-3-15%203%201zm30%20141h1v58q1%209-3%2018l-10%2010v-3l-4%201%201-7-1-2-3%201-1%209h-1q-1-17%204-35l-3%205h-2l-3-17h-3v-3h-2v-2l10%202%201-1h-3l-2-3h-3l1-3-3-3%201-3%207-1%201%203h-2l-1%204h2v2l5-1%201-5%203-3h2l-1%205%201%201%201-4%205-15%202-4z'/%3e%3cpath%20fill='%23926539'%20d='M91%20302c1%203%201%203-1%208l-1%208-1%202%203%201-3%201v6l-2%201%202%201%201%209%202%2014-1%201%202%202-2%202v3h2v-2l3-1c4%204%204%204%204%208h3v-2h6v2l2%201-1%206-5%201%201%203%202%205%202%204%202%207h-3l-1-1-1%203-6%202%203-8h-2l-2%204-5%204%201-7h-2l-2%206-2%201-2-1-1%204-3%202v-3h-4l-1-2-4%202%205-9%201-5-6%208h-2l2-5%201-3h3l1-5-5-1v2l-4%203-5%207%202%201-4%205-2-1%201-6-3%204h-2l-2%205h-2v-3l-5%204h-2v-3h-3v-4l-5%204-1-5-2%201v-4l-4%205-6-1-4%204%202-7-4-1-13%2012-5%205H0v-39q0-5%202-6l3%201-1%202h2l1-4%204-1v-3h6l-1-2h-2l2-4-1-4h5v-2h2l-3-5v-2l4%201v-2h2v2h2l1%205h6v-3h3l-1%206-7%201v3l-2%204%203-1%202-4h5l1%202%203-2%202%201%201-4h2l-1%203%202%201v2l6-1v-2h2l1-4%2014-1h2l2-6h-9l10-8q6-7%209-16z'/%3e%3cpath%20fill='%23428ceb'%20d='m260%20416%202%201v9l5-8%201%202%203-1-3%209h2l2-4%202-2v3h2q3%206%200%2012h2v-2h4v-2h2v3q4%200%207-5l2%201-3%205v5q4-3%204-7l4-1%201%205%201-4%204-2c1%207%201%207-1%2010l4-3%202%201-1%202h2l2-4%203-4h2l2-7h1v48l-5%202-5-4-6%203h-2l1-7c-5%201-5%201-8%205l-1%206c-4%203-4%203-12%203l-7%201-3-3%201-7-10%201-3-1-5%202-8-1-1%203-4-4c-6%200-7%202-12%205h-2l-1-2-4%203-1-3h-2v-3l-6%202-2-1-1%202-3-1-2%201v-3h-2v2l-5-2-8%203v-3h-4l-1%202-7%202v2h-4l-4%201-3%206-1-4-1-2-4%201%201-4-1-2%2011-5-3-2-3%201-1-2c14-7%2014-7%2022-8l-3%203h13v-3l1-4%2012-1%203-3q6-4%2013-6l-7%206q6-2%2011-8l2%201-3%204%205-1v3l2%201c10-10%2010-10%2010-16v-14h2l1%2014%204-2v-7c1-7%201-7%206-12'/%3e%3cpath%20fill='%23234e92'%20d='M74%20379h6l-2%206h-3l-1%204-2%204h2l2-6%205-3-6%2014%204-2%202%202h3v3l3-5h3l3-6h2v6l3-3%203-4h2l-2%207%206-2v6l3-5%202%201-2%204v4l6-12q4-6%2011-11v4l3-2%201%205%204-7c1%204%201%204-2%2011l-2%207%204-5%201%204h3l2-2-1%206v2l3-4%204-5h2l1-4-1%208h2l1-6%205-5-2%209%207-10q2%208-1%2015l2-1v5l4-4%202%201-4%207q6-2%206-4h2l1%202%203-2-2%206v2l5-8q2%207-2%2012l3-5h2v3l3-3h2l2-4%202-1-1%205h6l2-5%203%201-1%202%206-3v2l6-4-2%204-2%206%204-3-2%204%201%203%204-3-5%2012-1%204q-5%206-11%208l-5%204-3-4-4%202-8-1v-2h-4v5h-2l-1-4-9-1-1%203-7-5-1-7-1-3-1-7c-4-3-4-3-10-4l-2%204-2-1v2l-8-3c-8%200-8%200-12%204l-3%207%205%206v5l-4%201-1%204h2v2c-9%200-9%200-15-3l1-5%209%201c-3-6-3-6-8-9l-2-3-3-3-1-2-3%201-6-2-28%203v-3l6%201v-3h6v-4l-6%202-5-2-1%202-1-4h7v-8l2-3-1-2-3%201%201-6-2-2%202-3-1-4%207-7h2z'/%3e%3cpath%20fill='%23fcb189'%20d='M0%200h23l8-1h12c7%201%209%204%2014%209q6%2010%203%2021c9%202%2013-1%2021-5h7c1%208%201%209-3%2016l-7%201-3%202h2v2l-6%202-7%202-1%202-6%202v2l2%202-6%202v2l3%201-3%201v3l2%201h-2v3l2%201h-2l-1%204-35%201v-4l-1-6-16-1z'/%3e%3cpath%20fill='%233c75de'%20d='M50%201h167l-6%205-2%203h-3v2h-3l-2%206-2%203h-13q-12%201-22%2010c-6%2010-7%2015-7%2026l-3-2q-8-3-16-2l-7%204h-3l-2-5-7-1v-5q-1-9-8-16c-8-6-15-5-25-5q-7%201-14%205-5%204-12%200v-8Q58%2010%2050%201'/%3e%3cpath%20fill='%233f2f32'%20d='M261%20136h2l-4%2024-1%207c-4%2014-4%2014-9%2019-3%204-3%204-4%2011l4%201c3%207%203%207%202%2011l-6%205v3l-2%206-5%202-2%209%205%201q6%207%207%2017l-3%203%204-2h5c5%206%209%2017%209%2025h2c-5-18-5-18-9-24l-7-3q2-6%205-7h6q8%208%209%2018l-1%202%205-3c6%200%206%200%2012%204l1%203-6%2011-18%2038-2-1-2-10h-2l-2-5-3-5h-3v2h-8l-1-4-1-3c-3%207-3%2010-1%2017v5l-7-1v2l-3-1%201-5h-2l-1%204h-5l-1%202-2-4q-2-6-4-6l1-15%203-16h8l1%203%206-1c-1-18-1-18-8-25-6-10-5-22-5-34h2l3%2023c1%204%201%204%206%209v2h2l-1-3-1-18c-1-5-1-5-5-9l-2-2%204-9h-4l-4-2%202-7%205-1c0-15%200-15-3-21v-8l3%201q5%2013%205%2028l9-2%201-5v-8l1-7%204-19h1v6l7-2%203-10%201-5%201-5zm-5%2057q3%201%205%204v5l-3%203-2%203-3-1v-4l-1-4-4-2v-1l7-2zm6%209%205%202c1%205%201%205-2%2012l-7-8q1-4%204-6'/%3e%3cpath%20fill='%23fdd652'%20d='m0%20150%2029%204%209%202%205%201%205%201q12%2025%2016%2053l7%2029h-3v2l-16%204v2l-8%202-8%203h-8l-1-9-1-5v-6l11-9c3-4%203-4%204-9s1-5%205-8q8-7%2010-17h-2l-2%205c-3%206-3%208-9%2011l1-10h-2l-1%204-1%206-1%205c-2%209-5%2012-12%2017q-4-8-3-18c-1-15-1-15-3-22l-1%2023q-9-8-12-21l-1-5v-8l1%202%205-1-1-5-3-11-9-2z'/%3e%3cpath%20fill='%23407fe7'%20d='M318%207q3%205%203%2011v6l1%2041c2%2043%202%2043-10%2056l-16%2012-10%208-2-1-10-49-3-10-1-10h6c37-1%2037-1%2040-4q1-8-2-16-9-4-19-4l-1-5-3-10%202-12%207-5%203-3c10-6%2010-6%2015-5'/%3e%3cpath%20fill='%238d89a6'%20d='M171%20123h2v15h3v-2l6-2q-2%205-5%206-7%206-9%2014h4q31%203%2061%2011l11%201-1%2010v5l-3%2016-9%202-1-5-1-6-1-6-3-11-2-1v3l-10%205-19%2010c-6%203-6%203-13%202l-22-7-6-2-26-7-11-3-24-4-5-1-1-2c38-10%2038-10%2054-10l-3-11v-5h2l3%207q4%207%2011%2013l1-13%203-1%201%2010q7-4%2010-11l2-12z'/%3e%3cpath%20fill='%233f2f32'%20d='M133%20193v8q-4%2010-12%2016l-1%2010-1%2016%203-3h2l-3%207h-2l-1%2017%2017%202-3%209q-8%2019-11%2040l-1%206-1%204h-3l-1%202h-2l-1%203v-2h-3l-1%203v-2h-2l-1%204h-2l-1%204h-5l-9%201v-5l-2-1h2v-2l-4-1%204-1-1-4%203-3-2-1%201-11h2v-6l-10%2018-6-1q4-25%2013-48l2-5%202-4h17c5-5%204-16%205-22q-1-8-6-15-2-11-1-22l2%201%204%2022h2v-14l2-12h2l2%2010q6-6%209-14z'/%3e%3cpath%20fill='%238d89a6'%20d='M241%200h55q9-1%2017%203l-5%202v2l-11%206q-1-6%201-12h-2l-2%205-2%205-3-1V5h-3l3%2014-3%2010-4%2015q-4%209-13%2015l-3-1-2-11-3-13q-1%2025%205%2048l2%2016-6-3v-2l-4-1v-2l-4-2q-17-10-22-30l4-5c8-9%206-20%206-31l-1-6z'/%3e%3cpath%20fill='%23a26726'%20d='M306%20285q7%2013%2010%2025l4%205c2%2022%203%2045-9%2065l-2%206-3-1h2l1-5-6%208-5%201v-2h-2l1-4h2l-1-2h-3l-2%202v-2l-2%201v4l3%201v3l2-2%201%205h3l-1%202-10-3v-2l-4-1-2-1-2%203-4-2%203-4-4%201v5h2l1%203-3%201-2-1v2l3%201%202%205-6%202%202-5h-6l-2%203c-2-10%208-24%2013-32a143%20143%200%200%201%2032-37l3-4-1-5-24%2011-3%201q0-16%203-31l1-5%201-5%201-5%201-3zm-20%20107h3v2h2v3h3c3%2011%203%2011%203%2017l2-1%201-4h2l-4%2025-4%201-1%206-3%201c-1-5-1-5%202-10l-6%205-2-1v-3h-2v2h-4v2h-2l1-4-1-8h-2l-1-4h7l2-6%207%203%201-3h3l-3-5v-4h2v-3h2v-2h-3v2h-2z'/%3e%3cpath%20fill='%23428ceb'%20d='M0%20447q8%209%2013%2020l3-1v3l4-3%207-5c6%205%206%205%208%2010l4-4%203-3-1%205h3l-3%207%204-6h3l5-6-2%207c-3%205-3%205-3%209l2-1%201%202h2l2-4%206-5%201-2h2l2-4c9-9%209-9%2015-11q4%200%207%205c0%208-1%2010-6%2016l-5%204-1%202%206-3h5q-2%209-12%2014l-5%202-1%204-5%208-19%201-22-1H0z'/%3e%3cpath%20fill='%23a26726'%20d='m218%20208%206%203-1%209%205%203v2h2l2%2016v9q-2%201-5-3-5-7-5-15l-1-6v-10h-2l2%2022q1%209%208%2016%205%2010%203%2021l-6%201-1-2-8-1v5h-2l-1-3-1%202h-2v-3l-6%201-1-3h-2v4h-2v-3c-10-2-10-2-13-1l-7-1v3h-2v-3h-2v-2l-4%201-3-1-18-2-2%204%202-17%208-5%202-2c1%206%201%206-1%209l4-2c7%201%207%201%2011%206l3%2010%202-7c5-11%205-11%2011-16l8%202-4-4%207-8h7q5%205%207%2013-2%206-7%2011v2l4-6q5-5%2011-4l-5-1v-4l-2%202-2-5c-2-5-2-5-6-9l-2-2%208-13-3-3c1-6%201-6%206-10m-52%206%204%201%203%206q-2%207-8%2012l-3%205c-5%209-5%209-10%2012l2-18%202-16h4zm2%2016%202%202-1%205%204-1h4c5%206%206%209%207%2017q-2%206-6%2011l-2-4c-3-4-3-4-8-7h-5q-2-10%204-19zm17%208c5%201%205%201%208%204v4l-7%202-1%202-3-9z'/%3e%3cpath%20fill='%23fdc145'%20d='M223%20173q4%2013%204%2026l-1%201h-5l-2%207%204%201%203%201%202-2-4%2011%205%204%201%203h-2l-3-3-3-2%201-9-2-2c-5%201-5%201-8%205l1%206%204%201-6%205-4%208%205%204%205%2010%202-1-1%205h5l1%202h-4c-5%201-5%201-10%207l-3%203q1-4%204-7c3-4%203-4%203-9l-4-9-9-1-6%208%204%203-1%202-5-3c-5%201-5%201-9%206q-4%208-5%2016h-2l-2-6c-3-6-3-6-7-9l-8%201h-3l3-3v-6l3%202-1%204%205-1c6%204%206%204%2010%2010q6-6%204-15c-1-5-1-5-5-10l-9%201%201-6-1-4%204-5-1-9c9-4%209-4%2014-4l4-1-2-8-2%201-2-11%204-1%2015-8c16-9%2016-9%2021-9m-38%2065-3%204%203%208%201-2%207-2c-1-5-1-5-4-8z'/%3e%3cpath%20fill='%23db9180'%20d='m289%20218%201%202-2%206q2%2011%209%2019l2-1%201%204%203-3c4-3%204-3%208-3l-5%2013q-6%2013-9%2025l-1%205-7%2033h-2l-2%2020%202%201q-7%202-15%201l-7-1h-5l1-2h23l-1-5%201-5-5%201-16-1v-1h9l5-1%207-1-1-6h-18l-3%204c1-19%2013-38%2023-54q-1-4-6-6c-6%200-6%200-11%202l-1-5q-1-7-5-13l-8-1-5%206%206%201q10%2011%2010%2026h-2l-1-3-1-5-7-16c-7%201-7%201-12%204q2-4%205-6-1-9-6-16l-5-2%201-2q8%203%2011%2011l1%203%202-3%2012-1%202%204%204%205%205-13%204-1%204-2h5l-3-15%203%201z'/%3e%3cpath%20fill='%23a26726'%20d='M91%20302c1%203%201%203-1%208l-1%208-1%202%203%201-3%201v6l-2%201%202%201%201%209%202%2014-1%201%202%202-2%202v3h2v-2l3-1c4%204%204%204%204%208h3v-2h6v2l2%201-1%206-5%201%201%203%202%205%202%204%202%207h-3l-1-1-1%203-6%202%203-8h-2l-2%204-5%204%201-7h-2l-2%206-2%201-2-1-1%204-3%202v-3h-4l-1-2-4%202%205-9%201-5-6%208h-2l2-5%201-3h3l1-5-5-1v2l-4%203-5%207%202%201-4%205-2-1%201-4%203-20-4-2-2-1%201-5h2l1%204h2l-2-5h-2l3-8-3-1%205-2%201-3-3-1%208-1%202-9h-9l10-8q6-7%209-16z'/%3e%3cpath%20fill='%238d89a6'%20d='M48%200h190c-1%2044-1%2044-7%2053q-2%200-3-5l-2-4-3-1q1%2015%207%2029h-32c0-7%200-7%203-13h2l1-7h3l-2-7%204-1-2-5v-3l3-2v-2l2-2q-6-7-14-9l5-10h3V9l3-1%204-5%203-1H49z'/%3e%3cpath%20fill='%23fdc145'%20d='M49%20159h10l1%201%2015%202v2h10v1h-7l3%206q7%2020%2011%2041l1%206%203%2014-11%204-5%204-7-1-2%201-4-15z'/%3e%3cpath%20fill='%23428ceb'%20d='M50%201h102l-9%203v7l-7%206-4%204-11%203-9%206-5-4q-15-5-31%201l-4%202q-5%204-12%200v-8Q58%2010%2050%201'/%3e%3cpath%20fill='%23a26726'%20d='M143%20216h1c3%2014%205%2024%202%2038l-2%2016-4%2023h2v-4h2q1%209-2%2017h-4l-2%2018-3-1-1%205-8-1%202-19-4%2020h-3l2-20%201-5%205-17%207-17%201-3-11-1h-6l-1-1%202-17h2l2-5%201-2h-2l-1%203h-2l1-18h5l4-2%2011-2c0%205%200%205-2%208l3-3v-6z'/%3e%3cpath%20fill='%23fdc145'%20d='m0%20150%2033%204-3%201%2014%2041h-2l-1%204-1%206-1%205c-2%209-5%2012-12%2017q-4-8-3-18c-1-15-1-15-3-22l-1%2023q-9-8-12-21l-1-5v-8l1%202%205-1-1-5-3-11-9-2z'/%3e%3cpath%20fill='%23a26726'%20d='M110%20228c7%2010%204%2022%202%2033-3%203-3%203-8%203h-5l-5-1-8-1h-7l-8-1h-4l-16-1v-2l-5%202-2-1v-2l-6-1v3l-10-1-1-10h1v5c10-2%2010-2%2013-4l11-1v-2q8-4%2016-4v-2c5-2%205-2%2010-1l2%201%201-3q5-4%2012-4l6-2%207-1zm12%20101%203%201v2l6-2%201%202h6l-2%206%205%202-1%204h5l1-3h2v-2h2l2%206h-2v-2h-3v3l3%201v5l-1%201-2%205%203%205%203%2010h-2v2l-5%201-1%204h-3l-1-4-1-4-2-1v2h-2l-2%204-4%205h-2l2-6h-2l-2%205-3-1%202-5-6%204-2-4-3-1v-3h2l-2-10h-3l1-5h2l-1-7h-3l-1-3-3-1%202-1v-6h4v-2l9%201%202-6-2-1z'/%3e%3cpath%20fill='%238d89a6'%20d='M171%20123h2v15h3v-2l6-2q-2%205-5%206-6%206-9%2013l-4%204q-4%203-3%207v13l1%206%202%201-15-4-22-6-11-3-24-4-5-1-1-2c38-10%2038-10%2054-10l-3-11v-5h2l3%207q4%207%2011%2013l1-13%203-1%201%2010q7-4%2010-11l2-12z'/%3e%3cpath%20fill='%23428ceb'%20d='M85%20456c3%204%203%204%203%2011q-4%208-11%2013l-1%202%206-3h5q-2%209-12%2014l-5%202-1%204-5%208-11%201-6-1h-4l3-18v-4h-3l-1%202h-2c-5-15-5-15-2-20l3-3%201%204%202%201-3%207%204-6h3l5-6-2%207c-3%205-3%205-3%209l2-1%201%202h2l2-4%206-5%201-2h2l2-4c12-12%2012-12%2019-10'/%3e%3cpath%20fill='%23a26726'%20d='m229%20318%203%201v3l5%201%203%207h3l3%207%203%201v2l-12-3-1%202h4l9%203%202%204h3l-1%2012v7q-3%2011-12%2018l-3%204-2%203h-2l-1%203v-5l-1-9v-3l-1-2-3-1-1-10%203-2v-3l-5-2v-3l4-1v-3l-7-1-4-10h-2l-1-7%204-1%201-3%202-2-1-2h5v-2h2z'/%3e%3cpath%20fill='%23efb08e'%20d='m148%2097%2010%202%207%201c11%201%2016%205%2024%2012v1c-37%207-78%203-115%203q14-13%2032-12h13q9%200%2016-5l7-1z'/%3e%3cpath%20fill='%23fdc145'%20d='M78%20165q12%200%2024%204c8%2017%2014%2039%2013%2058h-2l-5-22v13l2%208v3l-11%203-3%201-2-7-14-54z'/%3e%3cpath%20fill='%23efb08e'%20d='M287%20313h1l-1%2023%207-4v3l5%205v2h-2v2h-2l-2%204-7%208c-4-1-4-1-9-6l-1%201%204%203%203%203v3h-2l-2%206q-7-3-12-9l1-3-7-1%208-2-6-1v-1h-7l2-7h-2l-1%206-2-1-3%201-1-2h2q-5-7-15-7l1-3h5v2l7%202v-2l-3-1c-2-7-2-7-1-10l7%203%205%201%201-4%204-8%201%201%202-5%201%203%2018-1v9l-9%201h9v10l-23%201%2024%201z'/%3e%3cpath%20fill='%233f2f32'%20d='M144%20206h2l3%2024h2v-5l3-13h2l-1%2015-1%2010-1%2012%209-12%204-7h2q-2%2011-10%2021l-7%203-1%2015%203-3%209%201h3l-5%2019q-5%2015-6%2032l-1%202-11%203q-4-9%200-19l2-15h-2v4h-2l1-4%204-32%201-10q2-14-2-27c-2-10-2-10%200-14'/%3e%3cpath%20fill='%23fdc145'%20d='m70%20344%202%203-5%202-1%204-4%206-1%204h2l2%205h-2l-1-4-2%201-1%204%206%202q2%208-1%2016l-1%202h-3l-2-4-1%205-6%203c1-5%201-5%205-10l-5%206-4%204h-2l2-5%201-3-5-3%201-5c-4%203-4%203-7%209h-3l1-4-3-1-4%204%208-14%207-10-9%203-2-1v-3l-4%202h-3l-1-3%204-2-1-3%203-1%202-4h5l1%202%203-2%202%201%201-4h2l-1%203%202%201v2l6-1v-2h2l1-4q6-2%2014-1'/%3e%3cpath%20fill='%23a26726'%20d='m302%20370%204%202%201%203%203-2v-2h2q1%208-3%2015l-3-1h2l1-5-6%208-5%201v-2h-2l1-4h2l-1-2h-3l-2%202v-2l-2%201v4l3%201v3l2-2%201%205h3l-1%202-10-3v-2l-4-1-2-1-2%203-4-2%203-4-4%201v5h2l1%203-3%201-2-1v2l3%201%202%205-6%202%202-5h-6l-2%203c-2-10%207-23%2012-31l2%201%201%203%205%201-3%203v6l4-1v-11l9%201v-2l4%201zm-16%2022h3v2h2v3h3c3%2011%203%2011%203%2017l2-1%201-4h2l-4%2025-4%201-1%206-3%201c-1-5-1-5%202-10l-6%205-2-1v-3h-2v2h-4v2h-2l1-4-1-8h-2l-1-4h7l2-6%207%203%201-3h3l-3-5v-4h2v-3h2v-2h-3v2h-2z'/%3e%3cpath%20fill='%23fdc145'%20d='m278%20157%204%2019v5l1%208h-2v2h-5q-7%201-12%205l-1%205%205%202v2l5-2-5%2010%203%203-9%203-1-5-3-4h-6c-5%206-5%206-7%2013l4%204%201%205-6-7h-5v-2h4v-13l3%203%205-5-2-10-4-1c0-7%200-7%204-11q6-9%208-22l1-3%208-2%205-1zm-22%2036-2%202-6%201%202%203h2l1%208h4l2-4%202-1v-5l-4-4zm2%2012q2%206%206%2011l2-1%202-9-4-4z'/%3e%3cpath%20fill='%2390a8be'%20d='M319%20359h1v58q1%209-3%2018l-10%2010v-3l-4%201%201-7-1-2-3%201-1%209h-1q0-45%2021-85'/%3e%3cpath%20fill='%233c75de'%20d='M241%200h55q9-1%2017%203l-5%202v2l-11%206q-1-6%201-12h-2l-2%205-2%205-3-1V5h-3l3%2014-3%209-4-1-14%201-1-4q-6-9-16-13l-9-1z'/%3e%3cpath%20fill='%238d89a6'%20d='M290%2029q6%208%205%2018l3-1c7%200%207%200%2013%203%205%205%206%206%206%2013q1%206-2%207-23%204-46%203l-1-8%2013-10c5-4%205-5%206-11l2-7z'/%3e%3cpath%20fill='%23fdc145'%20d='M320%20150v33l-7%201-4%203-5-1-7%202v-3l-5%202-5-32%2010-2%206-1z'/%3e%3cpath%20fill='%2390a8be'%20d='M91%20302c1%203%201%203-1%208l-1%208-1%202%203%201-3%201v6l-2%201%202%201%201%209%202%2014-1%201%202%202c-17%209-17%209-22%209v4l-3%2013%203%201-4%205-1%203%202%201-4%205-2-1%201-4%203-20-4-2-2-1%201-5h2l1%204h2l-2-5h-2l3-8-3-1%205-2%201-3-3-1%208-1%202-9h-9l10-8q6-7%209-16z'/%3e%3cpath%20fill='%23a26726'%20d='m207%20379%205%203h2v2h-2v3h3l1-2%209%203-2%202%206%203%202%204-7%2011-3%205c-4%205-4%205-8%207h-3l1-4-3%201%203-9-4%202h-2l-4%201v-2l-2-1-2%205h-6v-4l-3%203h-2c-1-8-1-8%201-11l6-2v2h3l-2-5%205-2v-4c0-5%200-5%203-8l5%201z'/%3e%3cpath%20fill='%23fdc145'%20d='M299%20381v2h-2l-1%204h2v2l5-1%201-5%203-3h2q-1%2012-5%2023l-2%206-2%202-1%203h-2l-3-17h-3v-3h-2v-2l10%202%201-1h-3l-2-3h-3l1-3-3-3%201-3zm-24%203%205%201-2%204%203%201%203-3%205%203v2h-3l2%205v2l2%202-1%202h2v-2h3v2h-2v3h-2l2%205%201%204h-3l-1%204-7-4-1%204q0%202-6%204v-2h-2l-1%204-2%203h-2l2-8-2-1%202-3h2v-2h-6l-1-3h8v-2h-2l-1-5-5%202-3-3h3v-2h2l2-3%206%201-2%205%205-3-4-5v-2l4-1-3-2z'/%3e%3cpath%20fill='%23efb08e'%20d='M98%20483c-1%207-1%207-4%2011l6-2q8-3%2016-2l5%203v6h-2l-1%204c-6%205-8%204-16%204H67l3-4%206-9%207-6%204-3c5-4%205-4%2011-2M26%200c20-1%2020-1%2028%204q7%209%207%2020l-1%205%207%201%203%203v5h3l-1%203-4-1-1%203h-7v-3l-4%201-4-2-5-1%204-5-6-5-3-7-6-8-1-3h-2V1h-7z'/%3e%3cpath%20fill='%23fdc145'%20d='M0%20164h3v24q0%2013%205%2025l1-1v-4q8%202%2011%209l1%2013v12h-2v-2l-4-2c-8-10-8-10-9-14H4v62H0z'/%3e%3cpath%20fill='%23234e92'%20d='m260%20416%202%201v9l5-8%201%202%203-1-3%209h2l2-4%202-2v3h2q3%206%200%2012h2v-2h4v-2h2v3q4%200%207-5l2%201-3%205%201%207-6%206-2-1%203-4-4%204-15%2012%202-4%202-5%203-4v-3l-5%205-4%204-2-1%203-4c3-4%203-4%204-10l-2%204-11%2014q1-7%206-12l-7%208-2-1%204-6h-2l2-5-2%202h-1v-17c0-5%200-5%205-10'/%3e%3cpath%20fill='%23fdc145'%20d='m46%20207%205%2016%201%207%201%206%202%2010h-3v2l-8%202-8%203h-8l-1-9-1-5v-6l11-9c3-4%203-4%204-9s1-5%205-8'/%3e%3cpath%20fill='%2390a8be'%20d='m70%20272%202%201-7%208h-2l-2%204q-5%2010-14%2012l-6%201%209-1-1%203-15%204%2013-2c-5%209-5%209-10%2011h-4l8-1-1%203-18%206q-11%203-20%209l-2%201c2-9%2010-13%2016-19l4-4q17-14%2035-26l5-3z'/%3e%3cpath%20fill='%23926539'%20d='M92%20336c5%202%205%205%208%209l2%204%205%2011%204-1v2h3l2%2010h-2l5%207%204-3h2l-1%205%202%202-5%206h-2l-2%206-5%207-2%204h-1l1-7v-1l-4%204v-9l2-1%202%202-2-7-4-12%205-1-1-9-3%201-3-1v2h-3l-2-6-5-1v2h-2l-1-4%202-1-3-2%202-1v-3l-2-2h2l-2-10z'/%3e%3cpath%20fill='%23a26726'%20d='M236%20234c5%201%205%201%208%205l4%2013-3%203%204-2h5q8%2011%209%2024l-4%202-1-2-3-1v2l-9-1-3%201-2%209h-3l2-11h-2z'/%3e%3cpath%20fill='%23428ceb'%20d='M320%20116v34l-11%203h-6l-16%202-1-7%209-8%2020-20z'/%3e%3cpath%20fill='%23db9180'%20d='M85%20456c3%204%203%204%203%2011q-11%2017-29%2026l-9%208h-2q3-11%209-21l5-10h2l2-4c12-12%2012-12%2019-10'/%3e%3cpath%20fill='%239b5631'%20d='M304%20340h2v5l1%201v8h2v10h2v5l3%201-1%203-1-2h-2l1%203-4%201-5-5-1%204-4-2v2c-4%201-4%201-9-1l1%207-2%203%202%201-3%202-3-3%202-6-4-2c-1-6-1-6%201-9l2-4%203-3z'/%3e%3cpath%20fill='%238d89a6'%20d='M42%20377h2v5l5%203-4%208%208-10%203-1c0%203%200%203-4%208l-1%203c5-3%205-3%207-8l2%201v3l2%201-3%204h-2l-2%205h-2v-3l-5%204h-2v-3h-3v-4l-5%204-1-5-2%201v-4l-4%205-6-1-4%204%202-7-4-1-13%2012-5%205H0v-16c0-5%200-5%205-10v2h2v3l4-3h2v3h2l2-5h3l-4%207%206-4%202-1%201%203%208-5v2l4-2-3%206h3l2-6z'/%3e%3cpath%20fill='%23428ceb'%20d='M122%20451h7l4%205%204-1q-1%204-6%207l2%203-1%203-4-4v2l4%204%202%208-1%201h-7l-7%201v-2h-2v-2h-2v2h-3v-6l7-2%202-2-1-2h-2q0-3%207-7l-3-5zm-17%201v3l-3%203%203%202-2%202%206-3%207-3%202%201-4%204h5v2l-14%208-2-1%201-2-7%204v-3l-4%202-2-1v-2l-4-1v-8l3-1%205-2%204-2z'/%3e%3cpath%20fill='%23a26726'%20d='m243%20389%207%203-1%2026h-3l-2%204-1-3h-2l-2%204-2-1-5%207-2-2-2%204h-4v-4l-4%203-2-2z'/%3e%3cpath%20fill='%23efb08e'%20d='M0%20447c12%2012%2020%2033%2020%2050-9%202-9%202-11%201-9-17-9-17-9-25z'/%3e%3cpath%20fill='%23a26726'%20d='M260%20244q8%208%209%2018l-1%202%205-3c6%200%206%200%2012%204%201%203%201%203-2%2010l-4%206h-3l-1-2-6%201-5-1v-4q-2-14-11-23l-4-1c3-7%203-7%2011-7'/%3e%3cpath%20fill='%23b56f3b'%20d='m237%20290%203%202v5h6l2%201v-2l3-1c4%206%204%206%205%2011l3-1v6l3%206-2%209h-8l-4-4%205-6-4-1v-2h-2l1%204-5%205-1-2-3%201v-6l-3-6c-2-7-2-10%200-17z'/%3e%3cpath%20fill='%23a26726'%20d='M288%20237q7%205%209%2012-2%2010-9%2016l-10-5-8%201q-1-7%203-15c6-9%206-9%2015-9'/%3e%3cpath%20fill='%23fdc145'%20d='m260%20220-2%2010%204%203%203-3h6l1%201%202-3q3%2013-5%2025l-3-4-5-6h-10l-2%204-2-4q-3-8-11-11l1-7h8l5%207q6-4%209-11z'/%3e%3cpath%20fill='%23db9180'%20d='M255%20488v4l1%204%204%202%201%205-3%204h-32l-1-4%203-4%201-4%209-3%205-2c5-2%205-2%2012-2'/%3e%3cpath%20fill='%23b56f3b'%20d='M132%20283h6l1%203-2%201%204%202-1%204h2v-4h2q1%209-2%2017h-4l-2%2018-3-1-1%205-8-1%202-19%202-6z'/%3e%3cpath%20fill='%23926539'%20d='M171%20123h2v15h3v-2l6-2q-2%205-5%206-6%206-9%2013l-4%204q-4%203-3%207v13l1%206%202%201-9-3-1-7c0-10-5-13-12-19q-5-8-5-17h2l3%207q4%207%2011%2013l1-13%203-1%201%2010q7-4%2010-11l2-12z'/%3e%3cpath%20fill='%2366442f'%20d='M131%20284q1%207-1%2014l-5%2028-1%203-2%201%202%205h-2l-1%203h-4v-2h-5v2h-4l2%207v4h3l1%207h-2v3l-6%203-2-5-9-18v-2l7-1%201-3%202-1%201-3%209-2%201-3%203%201v3h3v-4q3-21%209-40'/%3e%3cpath%20fill='%23a26726'%20d='M199%20207v3l3%203q-2%206-7%2011l-4-8-5-1-1-5zm4%209h6q4%203%204%207l-6%209-2%203-7%204-4%204-2-4-4-3q5-12%2015-20'/%3e%3cpath%20fill='%233f2f32'%20d='m190%20270%2010%203-8%2034-2-3-1%207c-5%202-5%202-9%201l4-20%202-9%201-4%201-4-2-2z'/%3e%3cpath%20fill='%238d89a6'%20d='M291%20287h1l-5%2031-2%2020%202%201q-7%202-15%201l-7-1h-5l1-2h23l-1-5%201-5-5%201-16-1v-1h9l5-1%207-1-1-6h-18l-3%204q1-11%206-21h2l-3%2010%203-3v-2h17l1-6h-15v-1h15l1-5z'/%3e%3cpath%20fill='%23407fe7'%20d='M238%2071h25q4%2013%205%2027l-6-3v-2l-4-1v-2l-4-2q-9-6-16-15z'/%3e%3cpath%20fill='%23fdc145'%20d='m244%20166-1%2010-3%2021-9%202-2-11-1-6-2-11z'/%3e%3cpath%20fill='%23fdd652'%20d='M0%20164h3l1%20122H0z'/%3e%3cpath%20fill='%23a26726'%20d='M320%20415q1%2011-3%2020l-10%2010v-3l-4%201%201-7-1-2-3%201q0-8%203-16c12-4%2012-4%2017-4'/%3e%3cpath%20fill='%233f2f32'%20d='m169%20268%207%201v2l2%201-3%2010-2%206-4%209-2%2013-2%207-4-1%202-16-2-1%205-23v-6h3z'/%3e%3cpath%20fill='%23428ceb'%20d='M185%201h32l-6%205-2%203h-3v2h-3l-2%206-2%203-13-1v-1h6v-2h-2l-4-10-2-1z'/%3e%3cpath%20fill='%239b5631'%20d='m138%20371%203%201%206%2021h2v2l-5%205-5%207c-1-3-1-3%201-9l-4%201-2-3-4%204%204-14-5%206%201-8-4%202c0-7%200-7%202-10h2l-2%206%208-9h2z'/%3e%3cpath%20fill='%233f2f32'%20d='M292%20297q2%200%204%206l2%207%203%208%202%2010-16%208q0-19%205-39'/%3e%3cpath%20fill='%239b5631'%20d='M143%20266h1c-1%2016-1%2016-3%2023h-4l-1-3h3l-1-2h-6q-6%2021-10%2044h-3l2-20%201-5%205-17%207-17%205-2%204%204z'/%3e%3cpath%20fill='%23fdc145'%20d='m289%20218%201%202-2%206q2%2011%209%2019l2-1v6l-2%202-2-4c-2-5-2-5-7-10-7%200-7%200-12%204q-6%209-6%2019l4-2c7%201%207%201%2013%206l-1%202-5-4-8-1-5%202-1-5q-1-7-5-13l-8-1-5%206%206%201q10%2011%2010%2026h-2l-1-3-1-5-7-16c-7%201-7%201-12%204q2-4%205-6-1-9-6-16l-5-2%201-2q8%203%2011%2011l1%203%202-3%2012-1%202%204%204%205%205-13%204-1%204-2h5l-3-15%203%201z'/%3e%3cpath%20fill='%23a26726'%20d='M256%20193q3%201%205%204v5l-3%203-2%203-3-1v-4l-1-4-4-2v-1l7-2zm-12%201%201%203%204%201c3%207%203%207%202%2011l-6%205v3l-2%206h-3l1-4zm18%208%205%202c1%205%201%205-2%2012l-7-8q1-4%204-6'/%3e%3cpath%20fill='%23428ceb'%20d='M105%20452v3l-3%203%203%202-2%202%206-3%207-3%202%201-4%204h5v2l-14%208-2-1%201-2-7%204v-3l-4%202-2-1v-2l-4-1v-8l3-1%205-2%204-2z'/%3e%3cpath%20fill='%23fdc145'%20d='m95%20167%207%202c8%2017%2014%2039%2013%2058h-2l-5-22-2%201-1-5-10-31z'/%3e%3cpath%20fill='%23a26726'%20d='M23%20336h2v2h2l1%205h6v-3h3l-1%206-7%201v3l-1%206%201%202-5%202-1%202h-2l-2%202v-2l-5%202%201-4-6%202-2-2%204-1v-3h6l-1-2h-2l2-4-1-4h5v-2h2l-3-5v-2l4%201z'/%3e%3cpath%20fill='%23b56f3b'%20d='M0%20160c7%201%207%201%2010%204%204%2011%204%2011%203%2015l-5%201-1%201%204%2014v7l-6-15q-1%2011%206%2021H9v4l2%201-4%201q-6-15-4-31v-19H0z'/%3e%3cpath%20fill='%2390a8be'%20d='m70%20272%202%201-7%208h-2l-2%204q-5%2010-14%2012l-6%201%209-1-1%203-10%203-5%201h-7q9-9%2020-17l6-3%205-4%207-5z'/%3e%3cpath%20fill='%23234e92'%20d='M0%20481c9%2012%209%2012%209%2017l6-1%208%201v9H0z'/%3e%3cpath%20fill='%238d89a6'%20d='M235%2054q4%200%207%205l1%205%207-1h11l1%208-12%201h-7l-6-1q-4-6-5-13z'/%3e%3cpath%20fill='%23a26726'%20d='m256%20396%209%205v2l-2%201%203%201%202-2%203%201v5h2v2h-8l1%202%206%201v2h-2l-1%203-3%201-4%207-1-10-5%203zm26%2019%207%203%202-2%202%2014h-2l-2%205-3%202-2-1v-3h-2v2h-4v2h-2l1-4-1-8h-2l-1-4h7z'/%3e%3cpath%20fill='%23efb08e'%20d='M75%20164h10v1h-7l3%206q7%2020%2011%2041l1%206%203%2014-4%201-1-5-5-21-2-8-9-32z'/%3e%3cpath%20fill='%23b56f3b'%20d='M210%20281h2l-4%2025-4%201-1-1v-8h-2l1%204-2%203v2l-4%201c1-20%201-20%206-25l2%202%201-3h4z'/%3e%3cpath%20fill='%23efb08e'%20d='M25%20461q10%204%2013%2014%204%2013%204%2028-4-4-5-9l-2-4-1-8-3-1c-7-12-7-12-7-19z'/%3e%3cpath%20fill='%238d89a6'%20d='M241%200h55q9-1%2017%203l-5%202v2l-11%206q-1-6%201-12h-2l-2%205-2%205-3-1V5h-3v5h-1l-1-9h-43z'/%3e%3cpath%20fill='%23db9180'%20d='m212%20494%202%207%204%204v2h-29l4-6%207-1%204-5z'/%3e%3cpath%20fill='%23fdc145'%20d='M207%20232q7%207%2011%2016l2-1-1%205h5l1%202h-4c-5%201-5%201-10%207l-3%203q1-4%204-7c3-4%203-4%203-9l-4-9-9-1-6%208%204%203-1%202-5-3c-5%201-5%201-9%206q-4%208-5%2016h-2l-2-6c-3-6-3-6-7-9l-8%201h-3l3-3v-6l3%202-1%204%205-1c6%204%206%204%2010%2010q5-6%205-14l10-2v-3z'/%3e%3cpath%20fill='%23fdd652'%20d='m71%20163%204%201q8%2021%2012%2043l1%206%204%2020h-4l-1-6q-6-33-16-64'/%3e%3cpath%20fill='%23926539'%20d='m290%20406%204%202-1%203%203%201%203%201%201-4h2l-4%2025-4%201-1%206-3%201c-1-5-1-5%202-10l-1-2h2l-1-4-2-11h3l-3-5z'/%3e%3cpath%20fill='%238d89a6'%20d='m18%20379%202%201-3%205-1%204-8%208H6v2l-6%204v-14c0-4%200-4%205-9v2h2v3l4-3h2v3h2l2-5z'/%3e%3cpath%20fill='%2366442f'%20d='m157%20370%203%208%202%204%203%201-1%208%205-3-2%205v6h3v6l3%201h-2l-1%203-5%201%202-5v-2l-5%204v-5l-2%201%202-7-1-3%201-5-7%2011c-1-4-1-4%201-11q1-7-2-14h3z'/%3e%3cpath%20fill='%23926539'%20d='m42%20379%203%204%204%202-4%208%208-10%203-1c0%203%200%203-4%208l-1%203c5-3%205-3%207-8l2%201v3l2%201-3%204h-2l-2%205h-2v-3l-5%204h-2v-3h-3v-4l-5%204%202-9-3%202z'/%3e%3cpath%20fill='%23fcb189'%20d='m173%20187%2011%204%202%208%202%202%202%209h-5l-1%202-5-1-3-12-2-7z'/%3e%3cpath%20fill='%23fdc145'%20d='m116%20352%204%201v3l7-1%201%202%209-1v2h3v2l4%201-5%202%201%203h-6v-2l-12-1c-7%200-7%200-11-2l1-5%204-1zM5%20228l6%207%207%209c3%204%203%204%203%2010H6l1-4z'/%3e%3cpath%20fill='%23efb08e'%20d='M91%20302c1%203%201%203-1%208l-1%208-1%202%203%201-3%201-1%203h-2l-2%204-5%204-2%204-11%201%2010-8q6-7%209-16z'/%3e%3cpath%20fill='%23db9180'%20d='M87%20479q-2%209-12%2014l-5%202-1%204-5%208h-8l4-4h4l4-7h-2q4-9%2013-16z'/%3e%3cpath%20fill='%23a26726'%20d='M181%20222q5%206%206%2014l-6%203-3-3-7-2-1-7c6-5%206-5%2011-5'/%3e%3cpath%20fill='%23428ceb'%20d='m27%20415%203%201-10%206-5%203-7%202q3%205%206%205v-4h2l-2%209H9l-2%203H4l-1%203-3%201v-14l23-13z'/%3e%3cpath%20fill='%2366442f'%20d='M304%20340h2v5l1%201v8h2v10h2v5l3%201-1%203-1-2h-2l1%203-4%201-1-4-6-21-1-5z'/%3e%3cpath%20fill='%23fdc145'%20d='m245%20327%207%203%205%201q1%209-2%2017l-2-1-3%201-1-2h2q-5-7-15-7l1-3h5v2l7%202v-2l-3-1c-2-7-2-7-1-10'/%3e%3cpath%20fill='%23926539'%20d='m52%20308%201%202h2l-4%2023-3%2014%207%201-2%201v2l-6%201v-2l-3-1%202-3-4-1%201-2h2l-1-4%203-11z'/%3e%3cpath%20fill='%2366442f'%20d='M309%20284v2h2l4%208%202%204%202%204%201%202v11l-2%202-1-3-10-25-1-4-7%202h-4v-4q8-2%2014%201'/%3e%3cpath%20fill='%23db9180'%20d='M284%20471h7c2%204%202%204%201%209q-7%203-14%202l-3-2c0-9%200-9%209-9'/%3e%3cpath%20fill='%23fdc145'%20d='M112%20336h5v2l6%201c2%207%202%207%201%209h2v5c-6-1-6-1-9-4l1-2h-2v-2l-4%202-6-1%202-2v-6h4z'/%3e%3cpath%20fill='%23fcb189'%20d='m21%20475%204%201q7%2012%207%2025l-6-2-4-10-2-5z'/%3e%3cpath%20fill='%23a26726'%20d='m30%20359%203%201-1%203%207-3%205%201-11%2016-1-2-3-1v-3h-2c-2-4-2-4-1-9zm236-128c5%201%205%201%208%204q1%2010-5%2018l-3-4-4-5c0-9%200-9%204-13'/%3e%3cpath%20fill='%23926539'%20d='M238%20412v3l-3%201-1%207-2%206-2-2-2%204h-4v-4l-4%203-2-2%208-13h6l1-2z'/%3e%3cpath%20fill='%2390a8be'%20d='m60%20413%205%201-4%201%201%202h11v4h-6v3h-6v1l11-1v2l-4%202c-28%2010-28%2010-32%2014l-7%201q14-10%2030-15v-5z'/%3e%3cpath%20fill='%23db9180'%20d='m113%20432%205%201c2%203%202%203%202%208l-4%201-1%204h2v2c-9%200-9%200-15-3l1-5%209%201-1-6z'/%3e%3cpath%20fill='%23a26726'%20d='M238%20224h6q8%209%207%2021l-3%202-1-4q-4-7-11-11z'/%3e%3cpath%20fill='%2366442f'%20d='m141%20380%203%201%203%2012h2v2l-5%205-5%207c-1-3-1-3%201-9l-4%201-2-3-4%204%203-12%201%204%203-1v5h2l1-12z'/%3e%3cpath%20fill='%23b56f3b'%20d='M129%20282h2l-4%2020-5%2026h-3l2-20%201-5%204-13%202-4z'/%3e%3cpath%20fill='%23fdc145'%20d='M15%20360v3l4-1v2l-6%201%201%203-3%203-2%205H5l1-5-3-1v-2l-3%201c0-6%200-6%202-8l3%201-1%202h2l1-3z'/%3e%3cpath%20fill='%23a26726'%20d='M247%20313h2l1%202%203%201-4%206c3%203%203%203%2010%204l-1%207-2%201v-3l-6%201%201-3-4-1-2-1-1%202-3-1v-2l-2-1v-2l3-1%202-2%203-3z'/%3e%3cpath%20fill='%23fdd652'%20d='M93%20167h2c11%2029%2011%2029%2011%2041l-5-15-2-6-1-4%201%204%201%205%202%2014-6-16-2-8c-2-6-2-6-1-10l2%208h2z'/%3e%3cpath%20fill='%2366442f'%20d='m87%20375%201%202-2%205-2%207-4%208-6%202%205-9%201-5-6%208h-2l2-5%201-3h3l1-5-5-1v-1l9-2v3h2z'/%3e%3cpath%20fill='%23926539'%20d='m71%20347-5%2024q-4%201-7-2l1-5h2l1%204h2l-2-5h-2l3-8-3-1%205-2%201-3-3-1z'/%3e%3cpath%20fill='%23a26726'%20d='M227%20195h1l2%2029-7-6%204-9h-4l-4-2%202-7%205-1z'/%3e%3cpath%20fill='%23428ceb'%20d='m289%2082%203%206-1%202h-16l-1%204-1-10%204-1q6-3%2012-1'/%3e%3cpath%20fill='%23fcb189'%20d='m70%20344%202%203-5%202-1%204c-3%203-12%202-16%202l3-6h2l1-4q6-2%2014-1'/%3e%3cpath%20fill='%23fdc145'%20d='m229%20318%203%201v3l5%201v3h-2v-2h-4v-2h-2l1%203%203%201v3l-5-1%202%203v3h2v3l-7-1%201-5h-2v-3l-4%201%202-4-1-2h5v-2h2z'/%3e%3cpath%20fill='%23a26726'%20d='m240%20197-3%2024h-3v-6l-2-16z'/%3e%3cpath%20fill='%23db9180'%20d='m159%20443%205%204%203%202-1%204h-4l-1-4h-3l1%205-6%202-3-2%202-4h2v-2l-3-1v-4z'/%3e%3cpath%20fill='%2366442f'%20d='m301%20425%203%205h3l3-4-3%2012h2l1-3%207-6v6l-10%2010v-3l-4%201%201-7-1-2-3%201z'/%3e%3cpath%20fill='%23fdc145'%20d='M0%20166h1v117H0z'/%3e%3cpath%20fill='%23db9180'%20d='m135%20436%201%206c-3%203-3%203-9%205h-6v-5c8-6%208-6%2014-6m44-8h3l-1%205%203%203-2%204-3%201-2-1-1-4h-3l-1%203-6-2-1-5c4-1%204-1%2010%202l2-4z'/%3e%3cpath%20fill='%23efb08e'%20d='m31%20408%206%202%204-2%201%204h5q0%205-4%206h-3l-1-3-3-1%201%206-6%201%201-5%202-1-3-2z'/%3e%3cpath%20fill='%23234e92'%20d='m15%20387%202%201-9%209H6v2l-6%204%201-13%206-2v3z'/%3e%3cpath%20fill='%238d89a6'%20d='M122%20451h7l4%205%204-1q-1%204-6%207l2%203-1%203-4-5-2-1c-4-7-4-7-4-11'/%3e%3cpath%20fill='%2366442f'%20d='M114%20374q3%201%205%204l4-3h2l-1%205%202%202-5%206h-2l-1%202-6-13h2z'/%3e%3cpath%20fill='%239b5631'%20d='M289%20315q6%208%206%2017l-8%204z'/%3e%3cpath%20fill='%2366442f'%20d='M268%20291h5l-7%2017-5-11q0-7%207-6'/%3e%3cpath%20fill='%23a26726'%20d='m184%20211%201%205-3%202-1%203-7%201-3-8c10-4%2010-4%2013-3'/%3e%3cpath%20fill='%23fcb189'%20d='m99%20168%2011%201v1h-6l3%206q9%2020%208%2042h-1l-1-5c-5-30-5-30-11-41v-3z'/%3e%3cpath%20fill='%238d89a6'%20d='m210%20457%201%204-2%203h-2l-1%203-6-1c-2-5-2-5-1-9z'/%3e%3cpath%20fill='%23a26726'%20d='m219%20202-2%201v5l-4%202-1-1-1%206h-8q1-7%207-12z'/%3e%3cpath%20fill='%23fcb189'%20d='M37%20477c5%205%205%2015%205%2021v5c-5-5-8-15-9-22z'/%3e%3cpath%20fill='%23926539'%20d='m66%20335%201%203%201-1h7l-3%209-3-1h-9q-1-3%203-7z'/%3e%3cpath%20fill='%2366442f'%20d='M284%20364q3%201%202%207l3%207-2%205%202%201-3%202-3-3%202-6-4-2-1-6z'/%3e%3cpath%20fill='%2390a8be'%20d='M91%20302c1%203%201%203-1%208v6l-1%205c-6%204-6%204-9%204q4-12%2011-23'/%3e%3cpath%20fill='%23fdc145'%20d='m254%20163-1%206-1%205c-1%205-1%205-6%209l1-19z'/%3e%3cpath%20fill='%23a26726'%20d='m186%20216%204%201%203%206-6%208-5-12z'/%3e%3cpath%20fill='%233c75de'%20d='M299%201c10%201%2010%201%2012%203l-3%201v2l-11%206q-2-7%202-12'/%3e%3cpath%20fill='%23234e92'%20d='M24%20498c7%202%207%202%2011%206h6v3H24z'/%3e%3cpath%20fill='%23428ceb'%20d='m147%20460%202%201-8%2010-5%207-3-9z'/%3e%3cpath%20fill='%23a26726'%20d='M4%20224h2v6l2%2013-1%2011%201%202H4zm250%208%205%201c2%204%202%204%202%2010h-9v-9z'/%3e%3cpath%20fill='%23db9180'%20d='M296%20495v5c-9%204-9%204-16%203l1-4%208%201v-5z'/%3e%3cpath%20fill='%23428ceb'%20d='M162%20466q-8%2010-20%2013v-3l6-5%204-3c5-3%205-3%2010-2'/%3e%3cpath%20fill='%233c75de'%20d='M236%2052c4%201%204%201%208%206l1%202h16v3h-7l-11%202-2-4q-2-6-5-7z'/%3e%3cpath%20fill='%23428ceb'%20d='M85%20484v3l-7%205-8%2011q-1%203-6%204%206-15%2020-22z'/%3e%3cpath%20fill='%23926539'%20d='M216%20407h5l1%203c-4%208-4%208-9%2010h-3l5-10z'/%3e%3cpath%20fill='%23428ceb'%20d='M265%2082h1l2%2016-6-3v-2l-4-1v-2l-2-1%209-3z'/%3e%3cpath%20fill='%23fcb189'%20d='M13%20210c7%207%207%207%207%2011v14l-5-13-1-6zm-7-33q5%207%207%2017l2%206c2%206%202%206%201%208q-5-6-7-16l-2-6z'/%3e%3cpath%20fill='%238d89a6'%20d='m43%20484%204%201-1%205-2%2013-1%204h-2v-15c0-5%200-5%202-8m230-116%204%201-4%2010-8%2020-3-2v-3h3l1-6%202-8h2l-1-6%204%201z'/%3e%3cpath%20fill='%23efb08e'%20d='m21%20475%204%201c2%204%202%204%201%208l-1%204-3%201c-2-5-2-5-2-13z'/%3e%3cpath%20fill='%23234e92'%20d='m241%20420%202%204%202%201%203-1v6l-6%203%201-3h2v-3l-5%204h-2l1-6-4-1%203-3h2z'/%3e%3cpath%20fill='%238d89a6'%20d='M102%20380h1v5h-2v6l-7%206c0-8%200-8%202-13l4-1z'/%3e%3cpath%20fill='%233f2f32'%20d='M128%20376h2l-2%206%205-5%202-1%202%203-1%204-2%201-4%208v-8l-4%202c0-7%200-7%202-10'/%3e%3cpath%20fill='%23234e92'%20d='M297%20434q1%208-1%2016l-6%204-2-1%207-10-2-1%201-7z'/%3e%3cpath%20fill='%23fdc145'%20d='m68%20244%201%204%206%201%202%204h2l2-5%203-4%202%201-4%206c-2%206-2%206-1%2011h-2l-4-11H64l2-3h2zm72-22%202%204-5%205q0-3%202-5z'/%3e%3cpath%20fill='%23a26726'%20d='M4%20224h2l-1%207H4z'/%3e%3cpath%20fill='%23fdc145'%20d='m62%20363%203%203v2h-2z'/%3e%3cpath%20fill='%23efb08e'%20d='M263%20349h7v1h-7z'/%3e%3cpath%20fill='%233f2f32'%20d='m319%20401%201%202h-5z'/%3e%3cpath%20fill='%23efb08e'%20d='M287%20313h1v5h-1z'/%3e%3cpath%20fill='%233f2f32'%20d='m316%20408%204%201-4%201zm3-4%201%202-4-1z'/%3e%3cpath%20fill='%23efb08e'%20d='m261%20352%204%201Z'/%3e%3cpath%20fill='%23926539'%20d='m72%20361%202%201h-3z'/%3e%3cpath%20fill='%23a26726'%20d='m86%20355%202%201Zm-2%201%202%201Z'/%3e%3cpath%20fill='%2366442f'%20d='m75%20331%202%201h-3z'/%3e%3cpath%20fill='%23a26726'%20d='M4%20224h2v2H4zm30%20127%202%201-2%201z'/%3e%3cpath%20fill='%238d89a6'%20d='m23%20308%203%201Z'/%3e%3cpath%20fill='%233f2f32'%20d='m77%20338%202%201Zm3-1%202%201Zm1-7%202%201Z'/%3e%3cpath%20fill='%238d89a6'%20d='m17%20318%202%201Zm3-1%202%201Zm-2-4%202%201Z'/%3e%3cpath%20fill='%233f2f32'%20d='m36%20299%202%201Z'/%3e%3cpath%20fill='%238d89a6'%20d='m47%20289%202%201Z'/%3e%3c/svg%3e",
	falls: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='320'%20height='507'%3e%3cpath%20fill='%233d2f3d'%20d='M0%200h320v507H0z'/%3e%3cpath%20fill='%23586589'%20d='m175%2057-4%2017v2l-4%2012c-2%208-2%208-1%2012l5%204q5%204%205%2011l-1%2017v6q-1%203%202%205l3%201q7%207%2010%2016l-1%208h14l-2-9%203%206%201%202%204%201-1-2-5-13%205%201q5%206%206%2014h2c20-1%2020-1%2025%202l6%207%206%204-2%202q-6%203-6%209l2%206q3%202%202%205l-1%203-6-3-4-1q-4%204-5%209%201%206%206%208l-1%205-1%203-3%205-1%205h4l8%201c9%201%209%201%2012%204l3%204%205%204v2l-5%202-2%201h-5l-2-1q-6-4-13-6l-10-4q-13-3-25%202l-7%207-5%205-6%207q-7%205-15%206l-6%204v11l11%202-4%206q-3%205-3%2010h-3l-2%2021h3l1-2v2l26-1h28c15-1%2015-1%2022-3l3-6%206-7h2l2-4%2014-16h2v-2l4-3%202-1%204-1v-3q3-23%2020-38l2-2%209-8%207-6v283H157v-23l-4%204h-2l-1%202-1%202h-2l-1%202-3%203h-5l-3%201h-13l-3-4-7-7q-4-3-3-7l1-3h-2l3-4%202-1%202-1%206-1v-13c12%204%2012%204%2014%208l2%206%201-2v-2l1-3%204-5%203%201%201%205h2l1-2q2-7%206-13l11-22h-9l-4%201h-4l-4%201-20%204-6%201-3%201-6-1-7-8-7-8%201-2%205%202v3l4%205%203%203q2%202%205%202h2l1-4-5-4-3%201-5-3v-2l-1-2-9-3-10-4%201-3%2015%201%201-6%205-10c9-13%209-13%209-17l-4-2-4-2-1-5v6h-4v-7l-2%201q-9%203-19%203v-2c-2-23-2-23-9-31l-2-2-5-6%202-4h2l-1-3c-1-10%204-24%208-33l4-2%204-5%201-2q4-7%204-14l-2-6-2-8h3l4-1h2l6-1%202-3%204-2h9c10%200%2010%200%2014-3q7-8%208-19l30-1h23q8%201%2014-5l1-6-1-5-1-4q-2-3-6-5-4%200-5-4l-1-5q-2-7-9-11l-19-5-3-1-5-1q-3-1-5-5-4-7-12-9l-14-6-7-4v-19c0-17%200-17%206-24l5-5%206-7%2013-16%201-2%2011-16z'/%3e%3cpath%20fill='%235e395c'%20d='M156%200h164v163l1%2019v35q0%206-3%2010l-3%202-2%203-3%202-2%202-5%205q-9%207-13%2015l-1%202q-4%208-5%2018-1%205-6%208l-6%202v2l-3%203-11%2012-9%2010-5%207q0%202-5%203l-19%202h-57l1-16%201-3v-2h3v-3q0-6%204-11h2l1-2h-4q-4%201-6-2-3-3-3-7%201-7%207-9l5-1c9-2%2015-10%2021-16l5-5%201-2q10-6%2021-3%2010%200%2018%205l11%206%204%201%205-2%205-1-3-3q-4-2-4-5-6-6-14-5l-3-1-8-1%202-10c3-5%203-5%203-8l-4-4q-2-2-2-5%202-6%207-9l6%202%202%202%201%201v-7l-4-4q-1-4%202-9l6-5-2-1-2-2-2-1-3-4q-2-4-8-4h-12l-9-1-4-9-2-4-4-1%201%202%202%203%201%202%201%207-5-1-1-2v3h-14v-3q-1-11-9-20l-7-4%201-2%201-17c0-11%200-11-3-16l-5-4-3-6%201-3%201-4%201-3v-2l17-55h-2l-3-1-2-5-2-1%202-1-6-4-2-1-1-4-12-11z'/%3e%3cpath%20fill='%234a2f4a'%20d='M0%200h61l28-1h54c11%200%2011%200%2016%203l5%206%204%203%202%202v2l4%202%202%201v2l2%201-1%202%203%205%205%201-9%2029h-3l-13-1v2l-5%209-2%202-24%2030-2%201-3%204q-6%205-5%2014v9l-1%206v12l-3-1q-12-3-22%204l-4%202-2%201c-12%207-12%207-14%2012l-1%207q-7-2-12-7l-23-17-11-9-20-14-6-4z'/%3e%3cpath%20fill='%23ebedf1'%20d='m175%2057-4%2017v2l-4%2012c-2%208-2%208-1%2012l5%204q5%204%205%2011l-1%2017v6q-1%203%202%205l3%201q7%207%2010%2016l-1%208h14l-2-9%203%206%201%202%204%201-1-2-5-13%205%201q5%206%206%2014h2c20-1%2020-1%2025%202l6%207%206%204-2%202q-6%203-6%209l2%206q3%202%202%205l-1%203-6-3-4-1q-4%204-5%209%201%206%206%208l-1%205-1%203-3%205-1%205h4l8%201c9%201%209%201%2012%204l3%204%205%204v2l-5%202-2%201h-5l-2-1q-6-4-13-6l-10-4q-13-3-25%202l-7%207-5%205-6%207q-7%205-15%206l-6%204v11l11%202-4%206q-3%205-3%2010h-3l-2%2021h3l1-2v2h3l69-1-1%203-19%202%2016%201v2l-40%202H88v-1h7l4-1%206-1h-3l-25-1-11-1%202-4h2l-1-3c-1-10%204-24%208-33l4-2%204-5%201-2q4-7%204-14l-2-6-2-8h3l4-1h2l6-1%202-3%204-2h9c10%200%2010%200%2014-3q7-8%208-19l30-1h23q8%201%2014-5l1-6-1-5-1-4q-2-3-6-5-4%200-5-4l-1-5q-2-7-9-11l-19-5-3-1-5-1q-3-1-5-5-4-7-12-9l-14-6-7-4v-19c0-17%200-17%206-24l5-5%206-7%2013-16%201-2%2011-16z'/%3e%3cpath%20fill='%23312431'%20d='M156%200h164v86l-17%206h-3l-3%201q-14%204-27%2011l-3%201-1%202q-2%205-8%207l-5%205q-3%204-7%204h-17l-1%202h-2l-1%203q-2%206-8%2010l-4%209-1%203h-2l-1%203-5%201%201%202%202%203%201%202%201%207-5-1-1-2v3h-14v-3q-1-11-9-20l-7-4%201-2%201-17c0-11%200-11-3-16l-5-4-3-6%201-3%201-4%201-3v-2l17-55h-2l-3-1-2-5-2-1%202-1-6-4-2-1-1-4-12-11z'/%3e%3cpath%20fill='%234a2f4a'%20d='m0%20120%2021%2014%202%201%2049%2036%202-11%203-3%203-1%202-1%202-2c19-11%2019-11%2027-10l10%204%206%203%202%201%208%203%202%201%204%202q6%201%209%207l1%203%201%202%206%201%2013%203%207%202q9%204%2013%2013l1%207%203%201%207%204%202%205v2c2%207%202%207%200%2010q-10%208-21%206l-47%202v3l-1%203q0%204-4%208l-2%202q-4%205-6%204h-12l-8%201-4%205-8%201-2%201-8-2q-5-8-8-17l-1-3-3-9-2-1h2v-2l-3-1%202-1%204-3%204-5-11%204q1-5%205-8%204-7%203-15-9%201-15%207l-3%207-2%203h-2v-2h-2q-7-2-13-6l-19%2027-1%202q-3%204-3%2010l-3%201%202%203v4h3l1%202h2c3%207%200%2020-1%2028v2l-2%2010-1%204H7v-2l-7%202z'/%3e%3cpath%20fill='%23795974'%20d='M320%20224v95l1%202v108c0%2018%200%2018-5%2024q-4%204-7%203-4-4-3-7l-4-2q-6-2-7-7l-3-8h2l-2-9-4%201-2-1-1%202q-1%204-6%205-7-3-12-9t-13-7l-2-1-1-5-6-4-2-5-2-1-3-15v-9l-1-34v-4l2-12h-5v-1h2l7-2%203-6%206-7h2l2-4%2014-16h2v-2l4-3%202-1%204-1v-3q3-23%2020-38l2-2%2011-10z'/%3e%3cpath%20fill='%236989b1'%20d='M238%20327v4l1%2044h-9l-1%203h-2l1%204h-9v-3h-3v2l-1%202v3l-2%204-7%201v2l-9-2-3-9h-3l-1-6-2%202-5%201-3-2-4%202-5%201-1%206%202%201q3%202%204%206v3h-2l1%203h-13l-12-1-6%202-2%202%204%201q-1%205-7%209l-6%202%203%2014v3l-16%204-3%201-6-1-7-8-7-8%201-2%205%202v3l4%205%203%203q2%202%205%202h2l1-4-5-4-3%201-5-3v-2l-1-2-9-3-10-4%201-3%2015%201%201-6%205-10c9-13%209-13%209-17l-4-2-4-2-1-5v6h-4v-7l-2%201q-9%203-19%203v-2c-2-23-2-23-9-31l-3-4-2-2-1-2h17l10%201%2012%201h7v1l-11%201h103l2-1h28v-2h-21v-1l7-1%204-1z'/%3e%3cpath%20fill='%235e395c'%20d='M75%20190q2%209-3%2017l-4%204-1%202%202-1%202-2%203-1h5q-3%207-10%209l2%201%201%205%204%2011%201%203%209%2014q5%208%205%2019-2%207-7%2013l-2%202-4%203-3%208-1%203q-3%2011-4%2023v2l-3%202%209%2013%203%207h-2l-35%208q-4%203-9%202l-3-5-2-4-1-2-4-9-1-2-10-19-2-2-6-11-1-2-2-3v-7l6-1v2l9-1v-3l1-4%202-13%201-23-4%201%201-3h-3l-2-7%202-1v-3l5-11%201-2%2010-14%208-10%202%201%203%202%203%202%207%202v2q5-4%206-9%202-5%207-6l4-1z'/%3e%3cpath%20fill='%23ebedf1'%20d='m175%2057-4%2017v2l-4%2012c-2%208-2%208-1%2012l5%204q5%204%205%2011l-1%2017v6q-1%203%202%205l3%201q7%207%2010%2016l-1%208h14l-2-9%203%206%201%202%204%201-1-2-5-13%205%201q5%206%206%2014h2c20-1%2020-1%2025%202l6%207%206%204-2%202q-6%203-6%209l2%206q3%202%202%205l-1%203-6-3-4-1q-4%204-5%209%201%206%206%208l-1%205-1%203-3%205-1%205h4l8%201c9%201%209%201%2012%204l3%204%205%204v2l-5%202-2%201h-5l-2-1q-6-4-13-6l-10-4q-4-2-9-2v-2q-2-4-5-5l-3-2-4-2h-2l-1-2h-2l-2-1-1-2-5-2-2-1-2-1%207-1q6-1%209-6%201-9-4-16l-4-2q-4%200-5-4l-1-5q-2-7-9-11l-19-5-3-1-5-1q-3-1-5-5-4-7-12-9l-14-6-7-4v-19c0-17%200-17%206-24l5-5%206-7%2025-34z'/%3e%3cpath%20fill='%233d2f3d'%20d='m228%20243%2012%205%2011%206%204%201%2010-4q12-2%2023%202l-1-3%202-1q2%207-2%2012l-3%2015q-1%205-6%208l-6%202v2l-3%203-11%2012-9%2010-5%207q0%202-5%203l-19%202h-57l1-16%201-3v-2h3v-3q0-6%204-11h2l1-2h-4q-4%201-6-2-3-3-3-7%201-7%207-9l5-1c9-2%2015-10%2021-16l5-5%201-2c7-6%2019-4%2027-3'/%3e%3cpath%20fill='%23c2d2e8'%20d='m216%20436%207%202%204%201%201%202-1%202%204%201v2h2v2l2%201%202%201v2l-6%202%202%207q3%202%208%201l7%201v10l1%204v12l1%2018h-93v-23l-4%204h-2l-1%202-1%202h-2l-1%202-3%203h-5l-3%201h-13l-3-4-7-7q-4-3-3-7l1-3h-2l3-4%202-1%202-1%206-1v-13c12%204%2012%204%2014%208l2%206%201-2v-2l1-3%204-5%203%201%201%205h2l1-2%2012-24q6-1%2011%201h8v-3h7q-1%205-5%207h4v-2q2-4%207-5l2-1h5l2%201v-2l1-2q7-2%2012%203'/%3e%3cpath%20fill='%23db5f88'%20d='m0%2070%2012%202%201%202h2l2%202%202%201%202%203%206%205h3v2l3%201v2l4-1v2h2l2%202h2v2l2%201v2l3%201-1%203%203-1%201%207%203-1%203-8%203-8%203-1v2l1%202%203%201h-2l2%203h3l-1-2h4l1-2h2l1%202%202-2%202%201%206%202v2l6%201-3%201v2l4%201-1%209%204%202%201%205h3l-3%203%202%202q4%203%205%208l-1%204v3q-1%205-4%206l-3%201-4%202-2%201c-15%207-15%207-18%2014l-1%207q-7-2-12-7l-23-17-11-9-20-14-6-4zm25%20287q5%201%206%206l1%203%201%204v2l2%207%202%205v3q4%2011%200%2022l2-1%2010-2q4%203%205%207v4h-2v2l-1%206-7%2033-2%206q-1%208-7%2013l-3%205-5%204-6-1-5%202q-4%202-10%202H0l-1-109v-4c0-7%200-7%203-10l7-4%203-2%203-1%202-2z'/%3e%3cpath%20fill='%236989b1'%20d='m293%20264%209%204%201%207%201%203v3-8l3%209v2l2%2031v6l4%2053%201%2012v8l1%203%202%205%203%201%201%2025c0%2017%200%2017-3%2022l-7%206h-2q-4-4-3-7l-4-2q-6-2-7-7l-3-8h2l-2-9-4%201-2-1-1%202-2-7-3%202-1-3q0-3%202-5l1-6-4%203-1-3q-5-5-11-7l-3-5v-21l4%201v-13h1l2%2018h1v-21q0-5%204-7l1%202%204%204%201%205v5l-3-2v4h3v2h3v-2h5v-3q-3-29-3-59v-13l2-1%204%2036v5l1%2013%201-5h4v-2l-2-25z'/%3e%3cpath%20fill='%235a4b66'%20d='m284%20422%203%201h6l1%204v7l2%203%201%203q1%206%207%208%204%202%205%206v2l2-1%202-2%202-2%205-4v60h-70c-4-8-2-20-2-28l-1-4q-1-13%207-23l1-2%205-5%202-3%202-1%202-4q3-5%206-4h3l2%201h2v-3l-3-1%203-1%204-2z'/%3e%3cpath%20fill='%23a1b8d8'%20d='m193%20223%202%201%205%202v2h2l5%203%202%201%2011%207-1%203h7v1h-2c-18%200-18%200-24%205l-4%205-5%205-3%203q-5%207-14%209c-5%200-5%200-8-3l-7%201v2l-14%201h-9v-8l5-1v-2h-4l-6-2-11%202v2h2v4l5%202v3l-4%201v2l3%202-7%203v5h-2v2l-6%201%204%202-3%2011q-3%2012-4%2026H96q-1-17%209-31v-2l-2%203-2%204-1%202-1%202-1%202-3%205q-1-10%204-20%204-3%209-3l-1-2v-9l-3-1q-5%200-5-4l-1-2h3l-5-2-1%203h-4l-2-8-1-3-1-2-1-2v-4h3l4-1h2l6-1%202-3%204-2h9c10%200%2010%200%2014-3q7-8%208-19l37-2h7z'/%3e%3cpath%20fill='%23362834'%20d='m0%20296%2011%2017%2013%2024%201%202%208%2018%202-1c32-9%2032-9%2045-9l1%2020%204%2013v9l6%202-1%2016q-18-1-34-5l1%202-1%207-1-2-3%201-2-3-14%203%202-5q1-13-3-25l-1-4c-4-16-4-16-8-18h-8l-9%205-4%203-2%201-3%201z'/%3e%3cpath%20fill='%235a4b66'%20d='M17%20284h1v7h19l1-2v2l20-1c16-2%2016-2%2019%200l-1%202q-4%2015-6%2031v2l-3%202%209%2013%203%207h-2l-35%208q-4%203-9%202l-3-5-2-4-1-2-4-9-1-2-10-19-2-2-6-11-1-2-2-3v-7l6-1v2l9-1v-3z'/%3e%3cpath%20fill='%23873c68'%20d='m0%2044%202%201v2l6-1%201%205%202-1h2q3%202%202%205l3-1%205%203v2h4l8%204%203%201-1%202%203-1%202%209h2l1-2v4h2l5%204%204%203v3l3-1v3h3v-2q4-10%2013-15l4-6%205-4%203%201v3l4-1%203%204%202%202%201%207h-2l1%202v3l-1%201v5l1%202v2l6%201%202%203h2v3l3%201v3l2%201%201%202-1%206h2v2l6%201v10l-1%2021-3-1-12-2v-7l1-4-7-9%202-3-2%201-1-3-1-4-2-1v-9l-3-1v-3l-3-1-1-2-4-1-3-1-2%202-1-3h-2l-1%203h-3l1%202-5-1c-3-5-3-5-3-8q-5%206-7%2014%200%203-4%205l-3-1h2v-3l-2-1v-2h-2v-3l-2-1v-2l-4-1h2v-2l-3%201-1-3h-2v-2l-4%201v-2l-4-1%201-2-4%202v-2l-3-2-3-3-5-4v-2l-4%201%201-3-2%201q-5%200-10-3z'/%3e%3cpath%20fill='%23362834'%20d='m80%20195%201%204h2l1-3%2017%204%209%202%2011%202c9%202%209%202%2012%206q4%205%204%2011l6-1v2h-6v2q2%208-4%2015c-6%206-6%206-8%206h-12l-8%201-4%205-8%201-2%201-8-2q-5-8-8-17l-1-3-3-9-2-1h2v-2l-3-1%202-1%202-1%202-2%204-5-11%204q2-6%206-10l2-6h4z'/%3e%3cpath%20fill='%235a4b66'%20d='M81%20364h1v6l8-1%202-1%2011-2%201%206h2v-6l2%204%203%203%202%201%202%201%202%201q-1%207-6%2013l-1%202-6%208q-2%205-1%209l-2%202h-8l-2-1h-5v2l12%204q5%201%209%205h-2v2l10%202%204%205-1%204h-6l-7-8q-5-5-4-6h-3l2%202%2011%2013h-3l-2%201h-8l-14%201h-2l-18-2-3-1h-2l-2-1-1-3-5-1-1%207h-1l3-18h2l-2-7%203-2%201-7%202%201%2024%204%208%201v-10l1-6-6-2v-2q0-5-3-10-2-6-1-13'/%3e%3cpath%20fill='%234e3a55'%20d='m71%20222%202%204%201%203%201%202%209%2019q7%209%207%2021-2%207-7%2013l-2%202q-3%203-7%204h-4l-19%201-2%201-9-1h3l-1-11-1%202h-2q1-9%205-17l2-6%201-3%204-10%201-4%206-14%201-2q4-6%2011-4'/%3e%3cpath%20fill='%23db5f88'%20d='M50%20408c5%209%202%2016%200%2025l-3%2011-3%2015-2%204q-1%209-7%2014l-3%205-5%204-6-1-5%202c-3%202-3%202-16%202v-34c10%200%2010%200%2016%202l17-46%202%201%207-3z'/%3e%3cpath%20fill='%23873c68'%20d='m264%20190%201%2013%201-3%205-3%201%208h7l4%2047h-7l-2-1q-8%200-15-4l-1-3q-6-6-14-5l-3-1-8-1%202-10c3-5%203-5%203-8l-4-4q-2-2-2-5%202-6%207-9l6%202%202%202%201%201v-2l1-7%205-2%203-2q3-3%207-3'/%3e%3cpath%20fill='%236989b1'%20d='m216%20436%207%202%204%201%201%202-1%202%204%201v2h2v2l2%201%202%201v2l-6%202%204%209-33%202h-53a99%2099%200%200%201%2013-26q6-1%2011%201h8v-3h7q-1%205-5%207h4v-2q2-4%207-5l2-1h5l2%201v-2l1-2q7-2%2012%203'/%3e%3cpath%20fill='%23db5f88'%20d='M132%20372q4%2010%201%2020l2-2q2-4%206-3h8c0%209%200%209-2%2012l-5%203%204%201q-1%205-7%209l-6%202%203%2014v3l-16%204-3%201-6-1-7-8-7-8%201-2%205%202v3l4%205%203%203q2%202%205%202h2l1-4-5-4-3%201-5-3v-2l-1-2-9-3-10-4%201-3%2015%201%201-6%205-10%203-4%201-1%203-6c4-6%2012-12%2018-10'/%3e%3cpath%20fill='%23c2d2e8'%20d='M214%20183h5l2%204h2v2h2l2%201%201%204%202%202-5%202%202%202%201-2%201%202h2l2%201%201%204-9%202q0%205%202%206l1%201-2%201v2h2v2h2v-2l5-1%204%203-1%205-1%203-3%205-1%205h4l2%201h6c9%201%209%201%2012%204l3%204%205%204v2l-5%202-2%201h-5l-2-1q-6-4-13-6l-10-4q-4-2-9-2v-2q-2-4-5-5l-3-2-4-2h-2l-1-2h-2l-2-1-1-2-5-2-2-1-2-1%207-1q6-1%209-6%201-9-4-16l-6-3-2-1v-6l2%201%206%202v2h4v-2l3-2q4-2%205-7'/%3e%3cpath%20fill='%233d2f3d'%20d='M320%20447v60h-56l2-5v-3q4-7%2010-9l3-2c7-4%207-4%2012-4v-8l5-1v-5l3-1%205-7q3-6%209-9l5-5z'/%3e%3cpath%20fill='%236989b1'%20d='m193%20223%202%201%205%202v2h2l5%203%202%201%2011%207-1%203h7v1h-2c-16%200-16%200-21%203l-4%204-2%202-6-2-2-6-5%201v-2h-2l1-4h-7l-1-3-12%202-3%201-3%201-1%202-5%201c-12%200-12%200-14%202h-8l4-8q4-5%205-14l37-2h7z'/%3e%3cpath%20fill='%235a4b66'%20d='M43%20456h1l1%205%202-1%206%201h2l3%201h3l29%207v2h-4l1%202q0%203-3%207l-3%203q-4%205-3%2012h-7l-3-1q-8-4-18-4h-2l-25%202-7%201-16%201v-5h3q9%200%2016-5h4l4%201%203-3h2v-2l4-5q7-8%207-19'/%3e%3cpath%20fill='%23c2d2e8'%20d='M141%20260v2l-4%202v2l3%202-4%202h16l4-2v2l3-3%208-1%201%203%202%201-3%202q-3%202-4%207l1%207h2v2h-11v2l-3%205v-6l-2%201v-2l-6%202q-3%206-3%2013l1%202h2l-1%2019%205%201v1c-7%200-7%200-10-2v-5l-1-1q-3-4-2-8%202-12%207-22h-10l-11%204q-5%206-6%2014l4-2v9l-1%207v4l-4%201q-3-5-3-11-2%203-2%207v5h-1q-1-18%206-34v-3l-4-2%204-1h3v-2h2v-5l6-3-3-2%201-3h4v-3l-8-2%203-4h-2v-2q11-4%2021%200m17-194v3l1%202-1%206-1%205q-6%2024-5%2049l-2-1-1%202-4-2-1-6v-16l-1-4h-2v2l1%209v9l-1%204h-2v5l-2-2v2l-1%203-4%201-1-2-2%202v-2l-2%201-4-1v2h-3q-4-15%200-29%203-6%209-10l6-7%202-2%204-6%203-3%202-2z'/%3e%3cpath%20fill='%235e395c'%20d='M93%2044q6%200%2011%202l1%207h2l-3%205%202%202h-2l3%205%204%2012%203%203%203%201%204%203%202%201%204%206%202%201v2l3%201-2%203-3%204-2%202q-5%204-6%2011l-6-1v-2h-2v-7l-3-2v-3h-3l1-4h-2l-1%202-1-5-2%201h-3l-2-4v-7l-2-1h3v-2l-1-10-4-4v-2l-6%202%201-2v-2l-2-2%201-1q6-7%208-15'/%3e%3cpath%20fill='%23db5f88'%20d='M121%20457c12%204%2012%204%2014%208l2%206%201-2v-2l1-3%204-5%204%203v12l9%208-2%205-3%201-2%204h-2l-1%202-3%203h-5l-3%201h-13l-3-4-7-7q-4-3-3-7l1-3h-2l3-4%202-1%202-1%206-1z'/%3e%3cpath%20fill='%23a1b8d8'%20d='M232%20170h6q4%200%207%205l8%206-2%202q-6%203-6%209l2%206q2%202%202%205l-1%203-6-3-4-1q-4%204-5%209l2%205-5%201v2h-2v-2h-2l1-3-2-2-2-4q4-4%2010-4v-3l-9-2%201-2%204-1-2-3-1-3-3-1v-2h-2l-2-3-5-1-1%203q-1%204-5%206h-2v2h-4l-1-2-5-1-4-3v-6q2-4%207-3h23l-25-1-1-3%2016-2h9-2l-21-1v-1h13l4-1z'/%3e%3cpath%20fill='%236989b1'%20d='m293%20264%209%204%201%207%201%203v3-8l3%209v11l1%2011%201%2011v8l2%2019v10l1%2020-3-9v-5%2017l-2%201-2%204v-4l-3%201-3-13v-9l-1-8v-12l-2-20z'/%3e%3cpath%20fill='%235e395c'%20d='M3%2027c6%201%206%201%208%204l1%203q3%205%208%207h2v2h3l8%205%208%204%203%203v2h2v2h2l4%202v2h3v2h6v2h2l1-2%201%201q5%204%209%203l2%202-1%201-9%209h-2v2l-2%205h-3v-3l-4%202v-2q-1-4-6-6v-2h-2l-2-1-1-2h-2l-3-8h-2v-2h-3v-2l-2-1h-3l-3-1-4-3h-3l-2-2h-2l-1-2-1-2H9l-1-5-6%201q-3-5-2-11v-8l3%201z'/%3e%3cpath%20fill='%23c2d2e8'%20d='M229%20465a22%2022%200%200%201%208%2021h11l2%2021h-49v-20l6-2%202-4h2l1%202%202-2v5h2l11%201v-3l2-6z'/%3e%3cpath%20fill='%23ebedf1'%20d='M248%20463v23h-11l-1-5q-1-7-5-14l-1%203v6l-2%205-1%206-6-1-1%202-4-1-2-1-3-3v-2l-1%202h-2l-1%203h-7v-7h-2l-1-2-1-3-1-3-3-4v-2l7-1%206-1h10l17-1h9z'/%3e%3cpath%20fill='%23873c68'%20d='M295%20119q5%202%205%205v2l1-7h1v3l2%2018h-2l1%203v7l2%201-1%205h-2v38l1%203c0%208%200%208-4%2012l-2%202q-5-3-6-10%200-5-3-9l1-17%203-27%201-13v-6z'/%3e%3cpath%20fill='%23586589'%20d='M81%20364h1v6l8-1%202-1%2011-2%201%206h2v-6l2%204%203%203%202%201%202%201%202%201q-1%207-6%2013l-1%202-6%208q-2%205-1%209l-4%202h-3l-3-1-3-1v-11l1-6-6-2v-2q0-5-3-10-2-6-1-13m94-76h6l9%201q1%2018-2%2036h-25l1-16%201-3v-2h3v-3q0-6%204-11h2z'/%3e%3cpath%20fill='%23c2d2e8'%20d='m194%20464-1%203%204%206%201%204%202-1v10h6v1h-5v20h-22v-20h5q-2-12-11-21v-1z'/%3e%3cpath%20fill='%23a1b8d8'%20d='m171%20287%202%201h2l-4%206q-3%205-3%2010h-3l-1%2012h-1l-1%209-5-1-1-4h-2l-1-3-2%208h-8l-1-1%202-19-4-1c1-12%201-12%205-16h8v5l2-5h3l6-1zm42%20150h9l6%204-1%202%204%201v2h2v2l2%201%202%201v2l-6%202%204%209-22%201h-2q-5%201-9-2l-10-2-6-4v-2l9-1v-2h-2v-2h7l2%201v2h-2q3%204%208%205l4%201v-2l-6-3-1-2%206-2-3-3-3-1h-2l-2-1v-3q5-3%2011-2z'/%3e%3cpath%20fill='%23873c68'%20d='m33%20398%204%201-2%2012h-2l-3%2010-1%202-1%203-2%206-1%203-9%2023-12-3-1%202-3-2%201-4h2l1-2q8-20%2018-39l3-5%201-2h4v-2z'/%3e%3cpath%20fill='%239692af'%20d='m247%20329%202%202%202-1q4%2012%204%2023v13h2l1%204v4l1%203%201%206%202%201v20l1%206h-3l2%205-10-2-1-12h-2v-2l-1-35z'/%3e%3cpath%20fill='%23c2d2e8'%20d='M134%20288h8l-4%2012-3%2017v9h-14l-1-5-1%202h-2l1-18-4%202q2-11%209-18z'/%3e%3cpath%20fill='%23a1b8d8'%20d='M198%20327h31v1l-10%201%2016%201v2l-40%202H88v-1h7l4-1%206-1-4-2h3l66-1h14z'/%3e%3cpath%20fill='%239692af'%20d='M118%20132h1v8h3c11-1%2011-1%2014%201q4%205%205%209l1-4-6-5v-1q8-1%2015%203l3%201q6%204%208%2012l2%2012h-2l-1-4-1%204-7%201-1-4q-5-7-13-9l-9-4-5-2-7-4z'/%3e%3cpath%20fill='%23586589'%20d='m77%20290-1%202q-4%2013-5%2028l-1%205-5%203-3-6-4-2-7-5q-1-8%204-15v-4l-5%2011q-1-5%201-8l2-3%204-6q11-3%2020%200'/%3e%3cpath%20fill='%23a1b8d8'%20d='M86%20408h10l12%203%2015%201%201%202%208%201q4%207%204%2016l-16%204-3%201-6-1-7-8-7-8%201-2%205%202v3l4%205%203%203q2%202%205%202h2l1-4-5-4-3%201-5-3v-2l-1-2-9-3-10-4z'/%3e%3cpath%20fill='%23db5f88'%20d='m241%20217%205%201v5l7-2v-4l2%201%206-1%203%2014%203%2019q-5%200-8-3l-1-3q-6-6-14-5l-3-1-8-1q1-11%208-20'/%3e%3cpath%20fill='%235e395c'%20d='m239%20284%205%202-2%202-7%2010-2%204c-5%209-5%209-6%2014h2l2%208h-19q-1-5%202-10l1-4%201-2%203-8c7-19%207-19%2020-16'/%3e%3cpath%20fill='%23795974'%20d='m121%20468%203%209-10-3q3%208%2011%2012l6%201v-2h7v2h-2v2h7l1-3h3l-2-2-1-6%203-4%209%208-2%205-3%201-2%204h-2l-1%202-3%203h-5l-3%201h-13l-3-4-7-7q-4-3-3-7l1-3h-2l3-4%202-1%202-1%206-1z'/%3e%3cpath%20fill='%23586589'%20d='M114%20288q2%205-1%209-5%2014-5%2029H96q-1-17%209-31v-2l-2%203-2%204-1%202-1%202-1%202-3%205q-1-10%204-20%207-4%2015-3'/%3e%3cpath%20fill='%23795974'%20d='m143%20408%2018%2012%202%201%204%203v2l-32%206v-5l-1-2-2-7%201-5%206-2z'/%3e%3cpath%20fill='%23a1b8d8'%20d='m303%20331%202%203%202-1%203%201%201%2013v3l1%2022-3-9v-5%2017l-2%201-2%204v-4l-3%201-3-15v-16l-1-13zm-85%2012h6l2%207q-8%205-18%203l-2-2%201-2-28%201v3l-6%201%202%203-43%201v-2h4c16-1%2016-1%2023-3l8-1v-1h-7l3-2v-2h4l31-1zM88%20288l2%201%207-1h2l-1%202-1%204-1%202q-3%2015-2%2030c-9%200-9%200-12-2v2h-2v-13l1-3q2-11%207-22'/%3e%3cpath%20fill='%23db5f88'%20d='m264%20397%2013%208%202%202%203-1v6l-2%202v5l2-5q3%206%202%2013l-5%203q-10-5-17-14l-2-6%205%201-1-2-1-7%201-3z'/%3e%3cpath%20fill='%23873c68'%20d='m0%20120%2021%2014%203%202%207%205%203%202%202%202%202%201q3%202%203%206v3l-4%201-2-4-2%201h-2l-2-2v-3h-2l-1%202-8-4-2-2v-2l-2-1-9-5v-3l-5-1z'/%3e%3cpath%20fill='%23586589'%20d='M178%20139h9v2h2q4%202%205%206%204%206%207%206%205%201%206%206%203%204%202%209l-5-1-1-2v3h-14v-3q-1-11-9-20l-7-4q2-2%205-2'/%3e%3cpath%20fill='%236989b1'%20d='m235%20487%201-1h12l2%2021h-21l-2-19c4-2%204-2%208-1'/%3e%3cpath%20fill='%23db5f88'%20d='M75%20190q2%209-3%2017l-4%204-1%202%202-1%202-2%203-1h5q-3%207-10%209l2%201v2l-7%201-1-2q-2-4-6-7l-2-6q2-9%209-14l6-2z'/%3e%3cpath%20fill='%236989b1'%20d='m164%2097%202%202%204%204q5%204%205%209v17l-1%2010-10-1-2-23v-10z'/%3e%3cpath%20fill='%23ebedf1'%20d='M132%20372q3%207%202%2014l-3%203-3%202-5%202-3%204-2%201-1%202-2-1v-2l-3-4-2-1q2-10%2010-16c8-5%208-5%2012-4'/%3e%3cpath%20fill='%23586589'%20d='M147%20288h6v5l2-2v2l-4%2021v3l-1%208h-7l-1-1%202-19-4-1c1-16%201-16%207-16m8%200%202%201-2%202z'/%3e%3cpath%20fill='%234a2f4a'%20d='M311%20211h9c1%2012%201%2012-2%2016l-3%202-2%203-3%202-3%203-5%203q-3-6-1-12v-2l1-3v-3q1-4%206-7h3z'/%3e%3cpath%20fill='%23586589'%20d='m55%20291-3%209%201-2%202-3h1l-3%2013-2%207-9-3-3-1q-4-3-4-7v-5l2-2%201-3%204-3z'/%3e%3cpath%20fill='%235a4b66'%20d='M189%20289h1q1%2018-2%2036h-21v-14h2l3-8h2l-3%2021h3v-4l2-9%202%201%201%203%203-14%201%209v4-2l2-7v-3z'/%3e%3cpath%20fill='%23586589'%20d='m142%20288-4%2012-3%2019v6h-6q-6-15-1-30%205-9%2014-7'/%3e%3cpath%20fill='%239692af'%20d='M159%20141c6%200%206%200%209%202l2-1q10%206%2013%2016l1%2010h-5l-1-3v-3l-1-4-4-8%201%202q3%208%203%2016h-6l-1-3-1-4-6-12-3-1z'/%3e%3cpath%20fill='%23c2d2e8'%20d='m99%20268%203%201-2%202%201%203%203%201%203%202v9l-14%201h-7l-4-2%201-1%209-15%201%202%201-2zm89-97h2l18%201h15q-5%203-11%203l-15%201v2h38v1l-28%201h-3l-10%201-2%204h-2l-2-3q-7-7-19-9%209-2%2019-2'/%3e%3cpath%20fill='%235a4b66'%20d='M107%2013q3%202%203%207l6%2013%201%206-4%204v3h-2v-2h-2l-1-2q-3-8-9-17v-5h2v-2z'/%3e%3cpath%20fill='%23a1b8d8'%20d='m68%20289-3%209q-5%2011-6%2021l-8-4q-1-8%204-15v-4l-5%2011q-1-5%201-8l2-3%204-6%205-1z'/%3e%3cpath%20fill='%23ebedf1'%20d='M198%20331h37v1l-40%202H88v-1l27-1h3z'/%3e%3cpath%20fill='%23873c68'%20d='m160%20188%203%201%203-1%206%2032-4-1-1-3v4l9%201v1h-17v-1l5-1-1-16h-2l1%202v11h-1l-2-12-1-4v-3l-1-3%201-6%201%201z'/%3e%3cpath%20fill='%239692af'%20d='M132%20415q4%207%204%2016l-16%204-3%201-6-1-7-8-7-8%201-2%205%202v3l4%205%203%203q2%202%205%202h2v-6l9-1%201-5h-2v-2q4-4%207-3'/%3e%3cpath%20fill='%23db5f88'%20d='M96%20382h2q4%204%204%209%200%207-3%2013l1%206h-4l-3-1-3-1c-1-17-1-17%204-24z'/%3e%3cpath%20fill='%23c2d2e8'%20d='m123%20289-1%202q-6%207-7%2015l4-2v9l-1%207v4l-4%201q-3-5-3-11-2%203-2%207v5h-1q-1-18%206-34v-4q5-2%209%201m0-1%203%201Zm106%20177q9%207%208%2018%200%203-2%204l-5%201-2%201%201%2018h-5q-2-9%200-18h-2l1-3%204%201v-3l2-6z'/%3e%3cpath%20fill='%239692af'%20d='m270%20423%202%201%202%202%202%201%203%204v3l-11-1-11-2-6-3v-4l5-1%202-1%203-1%203-1q4%200%206%203'/%3e%3cpath%20fill='%236989b1'%20d='M158%20487h9l1%206v14h-11z'/%3e%3cpath%20fill='%23ebedf1'%20d='M205%20339v1l-30%202H93v-1l32-2z'/%3e%3cpath%20fill='%236989b1'%20d='M262%20436h6l-4%205-4%205c-5%207-5%207-8%208l-12-3%207-4v-2l-2-1%2012-3-3-4z'/%3e%3cpath%20fill='%239692af'%20d='M75%20190c1%2011%201%2011-2%2015l-6%204-1-2-1-2h-4v-10l7-4h3z'/%3e%3cpath%20fill='%23a1b8d8'%20d='M199%20487v20h-9v-10l-3-10%205-1h3zm-57-199%202%202-1%204q-3%206-1%2011h2l-1%2019%205%201v1c-7%200-7%200-10-2v-5l-1-1q-3-4-2-8%202-12%207-22m76%2055h6l2%207q-8%205-18%203l-2-2%201-2h-12v-1l-5-1v-1h7l4-1%208-1z'/%3e%3cpath%20fill='%23ebedf1'%20d='M206%20215v3l3%201v4q2%204%206%204l2%201%202%201-1%202h-5v2l-7-1-2-3-4-1-1-2-5-2-2-1-2-1%207-1q6-1%209-6'/%3e%3cpath%20fill='%239692af'%20d='m27%20292%202%202-2%206v2l-3%208-2%206-1%204v8l1%202v2l2-2%205-4v4l-2%201-2%202q1%207%206%2014l2%204%201%202%201%204h-2l-3-5-1-4-1-2-21-38-1-2-1-2v-5l3%205%202%203%208%2015z'/%3e%3cpath%20fill='%23586589'%20d='M88%20289h3q-1%2015-6%2028l-1%204-1%202-4%201c3-27%203-27%209-35'/%3e%3cpath%20fill='%235a4b66'%20d='m146%2028%204%207%208%2016%203%206-2%203v-3h-3l-4-1-2-6-2-5q-5-6-5-14z'/%3e%3cpath%20fill='%23ebedf1'%20d='M130%20285h32l4%201v2h-11v2l-3%205v-6l-2%201v-2h-3l-15%201h-9l-7-1h-6l1-2z'/%3e%3cpath%20fill='%23a1b8d8'%20d='M169%20487h7l1%2020h-7z'/%3e%3cpath%20fill='%236989b1'%20d='M97%20288h2l-1%202-1%204-1%202q-3%2015-2%2030h-2l-3-11v-7l1-1v-3q0-8%203-15z'/%3e%3cpath%20fill='%23c2d2e8'%20d='M99%20288h6l-5%203-2%205-1%203-1%209%209-16v6l-2%203q-6%2010-6%2022l-2%202-2-1v-11q-1-13%206-25'/%3e%3cpath%20fill='%23a1b8d8'%20d='m126%20289-4%2016-3%2018h-2l1-18-4%202c1-7%204-18%2012-18m-39%2044%2072%201v2l2%201-1%202q-5%201-10-2l-9-1h-16l-38-1z'/%3e%3cpath%20fill='%236989b1'%20d='M201%20487h5c3%203%202%2012%202%2016v4h-7z'/%3e%3cpath%20fill='%235e395c'%20d='m56%20160%206%204%202%202%207%205v6l-2-1-7%202v-2l-2-1-1-4-4-6z'/%3e%3cpath%20fill='%236989b1'%20d='M213%20406q6%201%2010%205v2l-5%202v2l-6%202-8-6%208-6zm-51-117h6l-1%202q-4%2016-5%2034h-2l2-25%201-6q-3%206-3%2011l-2%201v8l-3%201%203-17z'/%3e%3cpath%20fill='%23795974'%20d='m284%20422%203%201h6l1%209-7-3v3h-2v3l2%202h-4l-5-1-2-1%203-1v-3l-3-1%203-1%204-2z'/%3e%3cpath%20fill='%23a1b8d8'%20d='m199%20226%201%202%205%201%202%202%204%202-9%201h-19v-2l5-2%205-3z'/%3e%3cpath%20fill='%23c2d2e8'%20d='m63%20290-1%202q-6%2011-7%2024l-4-1q0-8%204-15v-4l-5%2011q-1-5%201-8l2-3q2-7%2010-6'/%3e%3cpath%20fill='%236989b1'%20d='M179%20487h5l1%203v17h-6z'/%3e%3cpath%20fill='%239692af'%20d='M178%20139h8l-3%201%201%201q7%209%207%2019l2%205-1%203h-3v-3q-1-11-9-20l-7-4q2-2%205-2'/%3e%3cpath%20fill='%23ebedf1'%20d='M39%20469q0%204-3%207l-4%206-5%204-6-1-5%202q-7%203-16%202v-2h3c11-2%2011-2%2016-6l1-2%202%201-1%202h6v-2l1-2%204-1v-2l4-3%201-2z'/%3e%3cpath%20fill='%23a1b8d8'%20d='M83%20290h4l-1%204q-5%2014-7%2030l-3-1%201-1v-3l2-13%201-5-2%201%201-5%201-3z'/%3e%3cpath%20fill='%236989b1'%20d='M148%20288h2v5l-1%202-4%2013-1-3-4-1c1-16%201-16%208-16'/%3e%3cpath%20fill='%239692af'%20d='m242%20351%203%207v3l1%2015v27q-3-3-3-8v-11z'/%3e%3cpath%20fill='%236989b1'%20d='M214%20487h5q3%2010%202%2020h-5l-1-9v-2l-1-3z'/%3e%3cpath%20fill='%23a1b8d8'%20d='M222%20486h9l-3%203v4l1%2014h-5q-2-9%200-18h-2z'/%3e%3cpath%20fill='%239692af'%20d='m22%20484%203%201q-1%204-5%204h-3l-2%201-1%203-14%201v-5h3c10-1%2010-1%2013-3z'/%3e%3cpath%20fill='%236989b1'%20d='m109%20289-2%204h-2l-7%2013-3%205q-1-10%204-20%204-5%2010-2'/%3e%3cpath%20fill='%23a1b8d8'%20d='m162%20439%2012%201q0%204-3%206-5%204-12%201z'/%3e%3cpath%20fill='%23ebedf1'%20d='m172%20464%204%204v2l3%201q6%207%205%2016l-5-1-2-6q-1-8-7-13v-2zm-9-117h57v1l-57%201z'/%3e%3cpath%20fill='%23795974'%20d='M55%20341q12%200%2024%204v2q-13%203-24-5z'/%3e%3cpath%20fill='%239692af'%20d='M35%20381q6%2013%203%2025l-1%203%202-1%2010-2q4%203%205%207l-1%204-3-9-6%202-4%201-6%202%201-2q3-10%201-21l-1-5z'/%3e%3cpath%20fill='%23c2d2e8'%20d='m165%2077%204%205-2%208-1%203-4%2012h-1q0-15%204-28'/%3e%3cpath%20fill='%239692af'%20d='m292%20411%201%2012h-7l-1-9q2-4%207-3'/%3e%3cpath%20fill='%23ebedf1'%20d='M30%20375h2v11l-7%205%201-4-4%201%202-2%201-3%202-3z'/%3e%3cpath%20fill='%23c2d2e8'%20d='M101%20329h29l1%202h-6l-4%201-6%201h-13l3-2zm61-252%202%202-1%206q-4%2017-5%2033h-1l1-26%201-2q0-7%203-13'/%3e%3cpath%20fill='%236989b1'%20d='M86%20408h4l3%201%206%201%201%204q-7%202-13-2l-2-1zm37-102h1v3l1%203v4l2%205v5l-5-1v-6h-2l1-5v-3z'/%3e%3cpath%20fill='%23a1b8d8'%20d='m143%20481%204%202v3h-3l-1%204-7-1v-2h2v-2h-7v-1h5l3-1z'/%3e%3cpath%20fill='%236989b1'%20d='m165%20304%202%201v11l-1%209h-3z'/%3e%3cpath%20fill='%23c2d2e8'%20d='M132%20356h40v1l-40%201z'/%3e%3cpath%20fill='%236989b1'%20d='M164%20296v7l-2%2022h-2l1-21%201-2zm-5%202%201%207-2%201v8l-3%201q0-9%203-16z'/%3e%3cpath%20fill='%23c2d2e8'%20d='M125%20316h2l2%209h6v1h-7zm-6%203h3v2l3%204%202%201h-6z'/%3e%3cpath%20fill='%236989b1'%20d='m130%20288%202%201-4%203v-3z'/%3e%3cpath%20fill='%23586589'%20d='M93%20289h2l-2%204zm55-1%202%201-2%201z'/%3e%3c/svg%3e"
};
function yt({ name: e }) {
	return /* @__PURE__ */ w("image", {
		href: vt[e],
		width: "180",
		height: "200",
		preserveAspectRatio: "xMidYMid slice"
	});
}
//#endregion
//#region src/games/harmonies/pieces.tsx
function bt({ terrain: e, x: t = 0, y: n = 0, scale: r = 1, opacity: i = 1 }) {
	let a = ve[e], o = {
		gray: /* @__PURE__ */ w("path", {
			d: "M-12 5 -4-7 2 1 6-4 13 6Z",
			fill: a.print
		}),
		blue: /* @__PURE__ */ w("path", {
			d: "M-12-3Q-6-8 0-3T12-3M-12 4Q-6-1 0 4T12 4",
			stroke: a.print,
			strokeWidth: "2",
			fill: "none"
		}),
		brown: /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("ellipse", {
			rx: "12",
			ry: "7",
			stroke: a.print,
			strokeWidth: "2",
			fill: "none"
		}), /* @__PURE__ */ w("ellipse", {
			rx: "6",
			ry: "3",
			stroke: a.print,
			strokeWidth: "1.5",
			fill: "none"
		})] }),
		green: /* @__PURE__ */ w("path", {
			d: "M0 7Q-14-1-9-8 3-10 0 7M2 5Q0-7 11-9 16 3 2 5",
			fill: a.print
		}),
		yellow: /* @__PURE__ */ T("g", {
			fill: a.print,
			children: [
				/* @__PURE__ */ w("circle", { r: "4.5" }),
				/* @__PURE__ */ w("circle", {
					cx: "-9",
					cy: "-5",
					r: "3"
				}),
				/* @__PURE__ */ w("circle", {
					cx: "9",
					cy: "-5",
					r: "3"
				}),
				/* @__PURE__ */ w("circle", {
					cy: "7",
					r: "3"
				})
			]
		}),
		red: /* @__PURE__ */ w("path", {
			d: "M-11-7H-3V0H-11ZM3-7H11V0H3ZM-7 4H7V9H-7Z",
			fill: a.print
		})
	};
	return /* @__PURE__ */ T("g", {
		transform: `translate(${t} ${n}) scale(${r})`,
		opacity: i,
		children: [
			/* @__PURE__ */ w("ellipse", {
				cy: "7",
				rx: "23",
				ry: "14",
				fill: a.side
			}),
			/* @__PURE__ */ w("path", {
				d: "M-23 0V7A23 14 0 0 0 23 7V0",
				fill: a.side
			}),
			/* @__PURE__ */ w("ellipse", {
				rx: "23",
				ry: "14",
				fill: a.top,
				stroke: a.print,
				strokeWidth: "0.8"
			}),
			o[e]
		]
	});
}
function xt({ x: e = 0, y: t = 0, spirit: n = !1, whisper: r = !1, opacity: i = 1 }) {
	return /* @__PURE__ */ T("g", {
		transform: `translate(${e} ${t})`,
		opacity: i,
		children: [
			/* @__PURE__ */ w("path", {
				d: "M-8-9 2-14 11-9 1-4Z",
				fill: r ? "#c89ee1" : n ? "#fff5ce" : "#ffd393"
			}),
			/* @__PURE__ */ w("path", {
				d: "M-8-9 1-4V7L-8 2Z",
				fill: r ? "#8558a4" : n ? "#b8aa8e" : "#b9703f"
			}),
			/* @__PURE__ */ w("path", {
				d: "M1-4 11-9V2L1 7Z",
				fill: r ? "#ac7ac8" : n ? "#e2d8b7" : "#e69b52"
			})
		]
	});
}
function St({ layers: e, animal: t, whisper: n, preview: r, x: i = 0, y: a = 0, scale: o = 1 }) {
	return /* @__PURE__ */ T("g", {
		transform: `translate(${i} ${a}) scale(${o})`,
		children: [
			e.map((e, t) => /* @__PURE__ */ w(bt, {
				terrain: e,
				y: -t * 10
			}, t)),
			r && /* @__PURE__ */ w(bt, {
				terrain: r,
				y: -e.length * 10 - 3,
				opacity: .62
			}),
			t && /* @__PURE__ */ w(xt, {
				x: n ? -9 : 0,
				y: -(e.length - 1) * 10 - 8,
				spirit: t === "spirit"
			}),
			n && /* @__PURE__ */ w(xt, {
				x: t ? 9 : 0,
				y: -(e.length - 1) * 10 - 8,
				whisper: !0
			})
		]
	});
}
function Ct(e) {
	return [...Array.from({ length: e.height - 1 }, () => e.terrain === "green" || e.terrain === "red" ? "brown" : e.terrain), e.terrain];
}
function wt({ card: e, rotation: t = 0, mirrored: n = !1, label: r }) {
	let i = e.pattern.map((e, r) => {
		let { q: i, r: a } = e;
		n && (a = -i - a);
		for (let e = 0; e < t; e++) [i, a] = [-a, i + a];
		return {
			part: e,
			target: r === 0,
			x: i * 44,
			y: (a + i / 2) * 34
		};
	}).sort((e, t) => e.y - t.y), a = Math.min(...i.map((e) => e.x)) - 27, o = Math.max(...i.map((e) => e.x)) + 27, s = Math.min(...i.map((e) => e.y - (e.part.height - 1) * 10 - (e.target ? 26 : 16))), c = Math.max(...i.map((e) => e.y)) + 23;
	return /* @__PURE__ */ w("svg", {
		className: "harmonies-habitat-diagram",
		viewBox: `${a} ${s} ${o - a} ${c - s}`,
		role: r ? "img" : void 0,
		"aria-label": r,
		"aria-hidden": !r,
		children: i.map(({ part: t, x: n, y: r, target: i }, a) => /* @__PURE__ */ T("g", { children: [/* @__PURE__ */ w("path", {
			d: `M${n - 26} ${r + 2}l13-16h26l13 16-13 18h-26Z`,
			fill: "#e9d9b2",
			stroke: "#c5b084"
		}), /* @__PURE__ */ w(St, {
			layers: Ct(t),
			x: n,
			y: r,
			animal: i && !e.whisper ? e.spirit ? "spirit" : "animal" : void 0,
			whisper: i && e.whisper
		})] }, a))
	});
}
//#endregion
//#region src/games/harmonies/card.tsx
var Tt = "(orientation: landscape) and (min-width: 1400px) and (min-height: 760px)", Et = (e) => {
	let t = window.matchMedia(Tt);
	return t.addEventListener("change", e), () => t.removeEventListener("change", e);
};
function Dt({ id: e, placed: t = 0, compact: r = !1, selected: i = !1, board: a, side: o = "A", anchorName: l, onClick: u }) {
	let { ref: d, hidden: f } = ee(l ?? null), p = c(), m = n().replace(/:/g, ""), h = I[e], g = s(Et, () => window.matchMedia(Tt).matches, () => !1);
	r &&= !g;
	let _ = r ? 192 : 278, v = r ? 91 : 178, y = h.spirit ? a && t ? Ve(a, h.spirit, o) : 0 : h.scores[t - 1] ?? 0, b = p(h.nameKey), te = /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ T("svg", {
		viewBox: `0 0 180 ${_}`,
		className: "harmonies-card-face",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ w("defs", { children: /* @__PURE__ */ w("clipPath", {
				id: m,
				children: /* @__PURE__ */ w("rect", {
					width: "180",
					height: v,
					rx: "6"
				})
			}) }),
			/* @__PURE__ */ w("rect", {
				x: "1",
				y: "1",
				width: "178",
				height: _ - 2,
				rx: "6",
				fill: "#fff7df",
				stroke: i ? "#287e79" : "#7d8b70",
				strokeWidth: i ? 3 : 1.5
			}),
			/* @__PURE__ */ w("g", {
				clipPath: `url(#${m})`,
				children: /* @__PURE__ */ w("svg", {
					width: "180",
					height: v,
					style: {
						width: 180,
						height: v
					},
					viewBox: "0 0 180 200",
					preserveAspectRatio: "xMidYMid slice",
					children: h.whisper ? /* @__PURE__ */ w(yt, { name: h.art }) : /* @__PURE__ */ w(_t, { card: h })
				})
			}),
			/* @__PURE__ */ w("text", {
				x: "11",
				y: "23",
				fontSize: b.length > 12 ? 13 : 17,
				fontWeight: "750",
				fill: "#fff9de",
				stroke: "#59715d",
				strokeWidth: "2",
				paintOrder: "stroke",
				strokeLinejoin: "round",
				textLength: b.length > 19 ? 156 : void 0,
				lengthAdjust: "spacingAndGlyphs",
				children: b
			}),
			h.expansion && /* @__PURE__ */ w("circle", {
				cx: "166",
				cy: v - 10,
				r: "4",
				fill: "#f3e4b5"
			}),
			Array.from({ length: h.scores.length }, (e, n) => {
				let i = h.scores.length === 1 ? 90 : 22 + n * (136 / (h.scores.length - 1)), a = _ - 17;
				return /* @__PURE__ */ T("g", { children: [
					/* @__PURE__ */ w("circle", {
						cx: i,
						cy: a,
						r: "12",
						fill: !h.whisper && n < t ? "#fff9e7" : "#e5c191",
						stroke: !h.whisper && n === t - 1 ? "#287e79" : "#b29972",
						strokeWidth: !h.whisper && n === t - 1 ? 2 : 1
					}),
					/* @__PURE__ */ w("text", {
						x: i,
						y: a + 5,
						textAnchor: "middle",
						fontSize: r ? 17 : 14,
						fontWeight: "700",
						fill: "#354c43",
						children: h.whisper ? n === 0 ? 2 : 5 : h.spirit ? y : h.scores[n]
					}),
					(h.whisper || n >= t) && /* @__PURE__ */ w("g", {
						transform: `translate(${i} ${a - 18}) scale(.55)`,
						children: /* @__PURE__ */ w(xt, {
							spirit: !!h.spirit,
							whisper: !!h.whisper
						})
					}),
					h.whisper && n === 1 && /* @__PURE__ */ w("g", {
						transform: `translate(${i + 12} ${a - 17}) scale(.35)`,
						children: /* @__PURE__ */ w(xt, {})
					})
				] }, n);
			}),
			h.whisper && /* @__PURE__ */ T("g", { children: [Array.from({ length: h.scores.length - t }, (e, t) => /* @__PURE__ */ w("g", {
				transform: `translate(${82 + t * 16} ${_ - 29}) scale(.5)`,
				children: /* @__PURE__ */ w(xt, { whisper: !0 })
			}, t)), /* @__PURE__ */ w("text", {
				x: "90",
				y: _ - 8,
				textAnchor: "middle",
				fontSize: "10",
				fill: "#354c43",
				children: p("games.harmonies.remaining", { n: h.scores.length - t })
			})] }),
			t === h.scores.length && /* @__PURE__ */ w("path", {
				d: "M151 30 159 38 173 21",
				fill: "none",
				stroke: "#f7e5a8",
				strokeWidth: "5",
				strokeLinecap: "round"
			})
		]
	}), /* @__PURE__ */ w("span", {
		className: "harmonies-card-habitat",
		style: {
			top: `${(v + 2) / _ * 100}%`,
			height: `${(_ - v - 39) / _ * 100}%`
		},
		children: /* @__PURE__ */ w(wt, { card: h })
	})] }), ne = `${b}, ${p("games.harmonies.cardProgress", {
		placed: t,
		n: h.scores.length
	})}, ${h.whisper ? p("games.harmonies.whisperScoring") : p("games.harmonies.points", { n: y })}${h.spirit ? `, ${p(he[h.spirit])}` : ""}`;
	return u ? /* @__PURE__ */ w("button", {
		ref: d,
		style: { visibility: f ? "hidden" : void 0 },
		type: "button",
		className: "harmonies-animal-card",
		"data-selected": i,
		"data-compact": r,
		"aria-label": ne,
		"aria-pressed": i,
		onClick: u,
		children: te
	}) : /* @__PURE__ */ w("div", {
		className: "harmonies-animal-card",
		"data-compact": r,
		role: "img",
		"aria-label": ne,
		children: te
	});
}
//#endregion
//#region src/games/harmonies/labels.ts
var Ot = {
	gray: "games.harmonies.gray",
	blue: "games.harmonies.blue",
	brown: "games.harmonies.brown",
	green: "games.harmonies.green",
	yellow: "games.harmonies.yellow",
	red: "games.harmonies.red"
}, kt = {
	trees: "games.harmonies.trees",
	mountains: "games.harmonies.mountains",
	fields: "games.harmonies.fields",
	buildings: "games.harmonies.buildings",
	water: "games.harmonies.water",
	animals: "games.harmonies.animals",
	spirits: "games.harmonies.spiritScore",
	sanctuaries: "games.harmonies.sanctuaries",
	whispers: "games.harmonies.whispers"
};
//#endregion
//#region src/games/harmonies/sanctuary-card.tsx
function At({ id: e, completed: t = !1, selected: r = !1, compact: i = !1, anchorName: a, onClick: o }) {
	let s = c(), l = n().replace(/:/g, ""), u = H[e], { ref: d, hidden: f } = ee(a ?? null), p = i ? 192 : 278, m = p - 90, h = s(u.nameKey), g = /* @__PURE__ */ T("svg", {
		viewBox: `0 0 180 ${p}`,
		className: "harmonies-card-face",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ w("defs", { children: /* @__PURE__ */ w("clipPath", {
				id: l,
				children: /* @__PURE__ */ w("rect", {
					x: "2",
					y: "2",
					width: "176",
					height: m,
					rx: "6"
				})
			}) }),
			/* @__PURE__ */ w("rect", {
				x: "1",
				y: "1",
				width: "178",
				height: p - 2,
				rx: "7",
				fill: "#fff7df",
				stroke: r ? "#287e79" : "#b49c79",
				strokeWidth: r ? 3 : 1.5
			}),
			/* @__PURE__ */ w("g", {
				clipPath: `url(#${l})`,
				children: /* @__PURE__ */ w("svg", {
					width: "180",
					height: m,
					style: {
						width: 180,
						height: m
					},
					viewBox: "0 0 180 200",
					preserveAspectRatio: "xMidYMid slice",
					children: /* @__PURE__ */ w(yt, { name: u.art })
				})
			}),
			/* @__PURE__ */ w("text", {
				x: "9",
				y: "22",
				fontSize: h.length > 18 ? 10 : 13,
				fill: "#fff9e8",
				stroke: "#4c5965",
				strokeWidth: "2",
				paintOrder: "stroke",
				fontWeight: "750",
				children: h
			}),
			!t && /* @__PURE__ */ w("g", {
				transform: `translate(39 ${p - 28}) scale(.75)`,
				children: /* @__PURE__ */ w(St, { layers: u.layers })
			}),
			t && /* @__PURE__ */ w("path", {
				d: `M19 ${p - 43} 29 ${p - 33} 49 ${p - 58}`,
				fill: "none",
				stroke: "#287e79",
				strokeWidth: "5",
				strokeLinecap: "round"
			}),
			u.colors.map((e, t) => /* @__PURE__ */ w(bt, {
				terrain: e,
				x: 105 + t * 40,
				y: p - 48,
				scale: .66
			}, e)),
			/* @__PURE__ */ w("text", {
				x: "126",
				y: p - 17,
				textAnchor: "middle",
				fill: "#354c43",
				fontSize: "15",
				fontWeight: "750",
				children: "3"
			}),
			t && /* @__PURE__ */ w("path", {
				d: `M142 ${m - 27} 151 ${m - 18} 169 ${m - 40}`,
				fill: "none",
				stroke: "#fff5ce",
				strokeWidth: "5",
				strokeLinecap: "round"
			})
		]
	}), _ = `${h}, ${s(t ? "games.harmonies.sanctuaryComplete" : "games.harmonies.sanctuaryProgress")}, ${u.layers.map((e) => s(Ot[e])).join(" → ")}`;
	return o ? /* @__PURE__ */ w("button", {
		ref: d,
		style: { visibility: f ? "hidden" : void 0 },
		type: "button",
		className: "harmonies-animal-card harmonies-sanctuary-card",
		"data-selected": r,
		"data-compact": i,
		"data-completed": t,
		"aria-label": _,
		"aria-pressed": r,
		onClick: o,
		children: g
	}) : /* @__PURE__ */ w("div", {
		className: "harmonies-animal-card harmonies-sanctuary-card",
		"data-compact": i,
		"data-completed": t,
		role: "img",
		"aria-label": _,
		children: g
	});
}
//#endregion
//#region src/games/harmonies/view-player.tsx
function jt({ public: e, private: t, members: n, myRid: s, send: m }) {
	_();
	let { ref: v } = ee("hm-held"), { ref: ae } = ee("hm-personal-source"), { ref: oe } = ee("hm-market-source"), se = a(null), x = a(null), ce = te();
	r(() => () => {
		x.current && ce?.registerProbe(x.current.name, null);
	}, [ce]);
	let le = (e, t = !1) => {
		x.current && ce?.registerProbe(x.current.name, null);
		let n = se.current?.firstElementChild?.getBoundingClientRect(), r = `hm-take-source:${t ? "sanctuary" : "card"}:${e}`;
		x.current = n ? {
			name: r,
			box: {
				x: n.x,
				y: n.y,
				w: n.width,
				h: n.height
			}
		} : null, n && ce?.registerProbe(r, () => x.current?.box ?? null);
	}, S = c(), E = e, ue = t, [de, fe] = o({
		owner: s,
		rid: s
	});
	de.owner !== s && fe({
		owner: s,
		rid: s
	});
	let D = de.owner === s ? de.rid : s, O = (e) => fe({
		owner: s,
		rid: e
	}), [k, A] = o(null), [j, M] = o(null), [N, P] = o(null), [F, pe] = o(null), [me, ge] = o(null), [L, _e] = o(null), [ve, R] = o(0), [z, ye] = o("market"), [be, xe] = o(!1), [Se, Ce] = o(!1), [V, we] = o(null), [Te, Ee] = o({
		rotation: 0,
		mirrored: !1
	}), [De, Oe] = o(""), ke = `${E.serial}:${D}:${E.turn.held.join(",")}`;
	De !== ke && (De.startsWith(`${E.serial}:${D}:`) || ge(null), Oe(ke), A(null), P(null), pe(null), R(0), M(E.current === s ? E.turn.held[0] ?? null : null), xe(!1));
	let U = E.players.find((e) => e.rid === D) ?? E.players[0], Ae = B(E.config.side), W = U.sanctuaries, G = W.some((e) => e.id === me && !e.completed) ? me ?? void 0 : void 0, je = E.players.find((e) => e.rid === s), Ne = E.current === s && E.phase === "play", Pe = Ne && !!je && !je.spiritChosen, K = Ne && D === s && !Pe;
	b(Ne, y);
	let Le = (e) => n.find((t) => t.rid === e)?.name ?? e, Re = U.cards.filter((e) => e.placed < I[e.id].scores.length), q = U.cards.filter((e) => e.placed >= I[e.id].scores.length), Be = Re.length + W.filter((e) => !e.completed).length, Ve = (je?.cards.filter((e) => e.placed < I[e.id].scores.length).length ?? 0) + (je?.sanctuaries.filter((e) => !e.completed).length ?? 0), He = i(() => F && K && U.cards.some((e) => e.id === F && e.placed < I[F].scores.length) ? ze(U.board, I[F], E.config.pulse, E.config.side) : [], [
		F,
		K,
		U.board,
		U.cards,
		E.config.pulse,
		E.config.side
	]), Ue = F && K ? W.filter((e) => Ie(U.board, U.cards, W, F, e.id)) : [], J = Ue.find((e) => e.key === k), Y = He.filter((e) => e.key === k), X = Y.length ? Y[ve % Y.length] : null, We = K ? F ? /* @__PURE__ */ new Set([...He.map((e) => e.key), ...Ue.map((e) => e.key)]) : j ? new Set(Ae.filter(({ key: e }) => Me(U.board, e, j, E.config.side, W, G)).map((e) => e.key)) : void 0 : void 0, Ge = i(() => X ? new Set(X.keys) : void 0, [X]), Ke = k ? U.board[k] : void 0, Z = K && !F && j && k && We?.has(k) ? {
		key: k,
		terrain: j
	} : null, qe = K && E.turn.drafted && E.turn.held.length === 0, Je = K && !E.turn.drafted && N !== null && E.groups[N]?.length === 3, Ye = !!Z, Q = V ? I[V.id] : null, Xe = V ? U.cards.find((e) => e.id === V.id) : void 0, Ze = K && V?.market !== void 0 && E.market[V.market] === V.id && !E.turn.tookCard && Ve < 4, Qe = L ? H[L.id] : null, $e = W.find((e) => e.id === L?.id), et = K && L?.market !== void 0 && E.sanctuaryMarket[L.market] === L.id && !E.turn.tookSanctuary && Ve < 4, $ = S(z === "sanctuary" && Qe ? Qe.nameKey : z === "card" && Q ? Q.nameKey : z === "market" ? E.config.sanctuaries ? "games.harmonies.taskMarket" : "games.harmonies.market" : z === "completed" ? "games.harmonies.completedCards" : z === "replace" ? "games.harmonies.replaceChoice" : "games.harmonies.scoring"), tt = (e) => {
		ye(e), xe(!0);
	}, nt = (e, t) => {
		we({
			id: e,
			market: t
		}), Ee({
			rotation: 0,
			mirrored: !1
		}), tt("card");
	}, rt = (e, t) => {
		_e({
			id: e,
			market: t
		}), tt("sanctuary");
	}, it = (e) => {
		M(e), pe(null), P(null), R(0);
	}, at = (e) => {
		A(e), R(0);
	}, ot = (e) => {
		pe(e), ge(null), M(null), P(null), A(null), R(0), xe(!1);
	}, st = () => {
		E.players.length === 1 && !E.turn.tookCard && E.market.some((e) => e !== null) ? tt("replace") : m({ type: "endTurn" });
	}, ct = () => {
		if (J && F) {
			m({
				type: "sanctuaryAnimal",
				card: F,
				sanctuary: J.id
			}), A(null);
			return;
		}
		if (X && F) {
			m({
				type: "animal",
				card: F,
				key: X.key,
				rotation: X.rotation,
				mirrored: X.mirrored
			}), A(null);
			return;
		}
		if (Z) {
			m({
				type: "place",
				terrain: Z.terrain,
				key: Z.key,
				...G === void 0 ? {} : { sanctuary: G }
			});
			return;
		}
		if (Je) {
			m({
				type: "draft",
				group: N
			});
			return;
		}
		qe && st();
	}, lt = S(J ? "games.harmonies.shelterConfirm" : X && F ? I[F].whisper ? "games.harmonies.whisperConfirm" : I[F].spirit ? "games.harmonies.spiritConfirm" : "games.harmonies.animalConfirm" : Z ? "games.harmonies.placeConfirm" : Je ? "games.harmonies.draftConfirm" : qe ? "games.harmonies.endTurn" : E.turn.drafted ? "games.harmonies.placeConfirm" : "games.harmonies.draftPrompt"), dt = (e) => {
		let t = U.board[e];
		return [
			t?.layers.length ? t.layers.map((e) => S(Ot[e])).join(" → ") : S("games.harmonies.emptyCell"),
			t?.animal ? S(t.animal === "spirit" ? "games.harmonies.spiritPresent" : "games.harmonies.animalPresent") : "",
			t?.whisper ? S("games.harmonies.whisperPresent") : "",
			t?.sanctuary === void 0 ? "" : S(H[t.sanctuary].nameKey),
			t?.sanctuaryAnimals ? S("games.harmonies.shelterCount", { n: t.sanctuaryAnimals }) : "",
			E.config.side === "D" ? S(Fe(U.board, e, E.config.side) ? "games.harmonies.ordinarySpace" : "games.harmonies.drySpace") : ""
		].filter(Boolean).join(", ");
	}, ft = (e) => {
		let t = Le(e.rid), n = e.card ? I[e.card].nameKey : null, r = e.sanctuary === void 0 ? "" : S(H[e.sanctuary].nameKey);
		switch (e.kind) {
			case "draft": return S("games.harmonies.logDraft", {
				name: t,
				n: e.n ?? 0
			});
			case "place": return S("games.harmonies.logPlace", {
				name: t,
				terrain: e.terrain ? S(Ot[e.terrain]) : ""
			});
			case "takeCard": return S("games.harmonies.logTake", {
				name: t,
				animal: n ? S(n) : ""
			});
			case "animal": return S("games.harmonies.logAnimal", {
				name: t,
				animal: n ? S(n) : ""
			});
			case "spirit": return S("games.harmonies.logSpirit", {
				name: t,
				animal: n ? S(n) : ""
			});
			case "endTurn": return S("games.harmonies.logEnd", { name: t });
			case "takeSanctuary": return S("games.harmonies.logTakeSanctuary", {
				name: t,
				sanctuary: r
			});
			case "completeSanctuary": return S("games.harmonies.logCompleteSanctuary", {
				name: t,
				sanctuary: r
			});
			case "sanctuaryAnimal": return S("games.harmonies.logShelterAnimal", {
				name: t,
				sanctuary: r,
				animal: n ? S(n) : ""
			});
		}
	}, pt = (e = !1) => /* @__PURE__ */ w("div", {
		className: "harmonies-sheet-cards",
		children: E.market.map((t, n) => t === null ? null : /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w(Dt, {
			id: t,
			onClick: () => e ? m({
				type: "endTurn",
				discard: n
			}) : nt(t, n)
		}), e && /* @__PURE__ */ w("button", {
			className: "btn-quiet harmonies-replace-button",
			onClick: () => m({
				type: "endTurn",
				discard: n
			}),
			children: S("games.harmonies.replaceCard")
		})] }, t))
	}), mt = () => /* @__PURE__ */ w("div", {
		className: "harmonies-sheet-cards harmonies-sanctuary-market",
		children: E.sanctuaryMarket.map((e, t) => e === null ? null : /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w(At, {
			id: e,
			compact: !0,
			onClick: () => rt(e, t),
			anchorName: `hm-sanctuary-market:${e}`
		}), t === 0 && /* @__PURE__ */ w("small", { children: S("games.harmonies.sanctuaryDeck") })] }, e))
	});
	return /* @__PURE__ */ T(ne, {
		adaptive: !0,
		scroll: !1,
		className: "harmonies-screen",
		children: [
			/* @__PURE__ */ T("div", {
				className: "harmonies-game",
				children: [
					/* @__PURE__ */ w(g, {
						className: "absolute inset-0 pointer-events-none",
						kind: "sheen",
						base: "#f6f1e3"
					}),
					/* @__PURE__ */ T("header", {
						className: "harmonies-header",
						children: [
							/* @__PURE__ */ T("div", {
								className: "harmonies-brand",
								children: [/* @__PURE__ */ w("strong", { children: S("games.harmonies.name") }), /* @__PURE__ */ w("span", { children: "H A R M O N I E S" })]
							}),
							/* @__PURE__ */ T("div", {
								className: "harmonies-phase",
								"data-active": Ne,
								role: "status",
								children: [/* @__PURE__ */ w("span", { children: S(E.lastRound ? "games.harmonies.finalRound" : "games.harmonies.round", { n: E.round }) }), /* @__PURE__ */ w("strong", { children: S(Ne ? "games.harmonies.yourTurn" : "games.harmonies.waiting", { name: Le(E.current) }) })]
							}),
							/* @__PURE__ */ w("div", {
								className: "harmonies-players",
								children: /* @__PURE__ */ w(re, {
									members: n,
									myRid: s,
									variant: "mini",
									scroll: !0,
									adaptive: !0,
									onPick: O,
									picked: (e) => e === D,
									action: (e) => e === E.current ? "pending" : null,
									status: (e) => /* @__PURE__ */ w("span", {
										className: "harmonies-player-score",
										children: S("games.harmonies.points", { n: E.players.find((t) => t.rid === e)?.score.total ?? 0 })
									})
								})
							})
						]
					}),
					/* @__PURE__ */ T("main", {
						className: "harmonies-main",
						children: [
							/* @__PURE__ */ T("aside", {
								ref: oe,
								className: "harmonies-public",
								children: [
									/* @__PURE__ */ T("div", {
										className: "harmonies-section-title harmonies-public-title",
										children: [/* @__PURE__ */ w("h2", { children: S("games.harmonies.supply") }), /* @__PURE__ */ w("span", { children: S("games.harmonies.bagLeft", { n: E.bagLeft }) })]
									}),
									/* @__PURE__ */ w("div", {
										className: "harmonies-supplies",
										children: E.groups.map((e, t) => /* @__PURE__ */ w("button", {
											type: "button",
											className: "harmonies-supply",
											"data-selected": N === t,
											disabled: !K || E.turn.drafted || !e,
											"aria-label": `${t + 1}. ${e?.map((e) => S(Ot[e])).join(", ") ?? S("games.harmonies.emptyCell")}`,
											"aria-pressed": N === t,
											onClick: () => {
												P(t), M(null), pe(null), A(null);
											},
											children: /* @__PURE__ */ T("svg", {
												viewBox: "0 0 175 45",
												"aria-hidden": "true",
												children: [e?.map((e, t) => /* @__PURE__ */ w(bt, {
													terrain: e,
													x: 34 + t * 53,
													y: 20 + t % 2 * 2,
													scale: .85
												}, t)), N === t && /* @__PURE__ */ w("path", {
													d: "M153 7 159 13 169 3",
													stroke: "#287e79",
													strokeWidth: "3",
													fill: "none"
												})]
											})
										}, t))
									}),
									/* @__PURE__ */ T("div", {
										className: "harmonies-market",
										children: [
											/* @__PURE__ */ w("div", {
												className: "harmonies-section-title",
												children: /* @__PURE__ */ w("h2", { children: S("games.harmonies.market") })
											}),
											/* @__PURE__ */ w("div", {
												className: "harmonies-market-cards",
												children: E.market.map((e, t) => e === null ? /* @__PURE__ */ w("div", { className: "harmonies-card-space" }, `empty-${t}`) : /* @__PURE__ */ w(Dt, {
													id: e,
													compact: !0,
													anchorName: `hm-market:${e}`,
													onClick: () => nt(e, t)
												}, e))
											}),
											E.config.sanctuaries && /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("div", {
												className: "harmonies-section-title",
												children: /* @__PURE__ */ w("h2", { children: S("games.harmonies.sanctuaries") })
											}), mt()] })
										]
									})
								]
							}),
							/* @__PURE__ */ T("section", {
								className: "harmonies-landscape",
								children: [/* @__PURE__ */ T("div", {
									className: "harmonies-section-title harmonies-landscape-title",
									children: [/* @__PURE__ */ w("h2", { children: S("games.harmonies.landscape", { name: Le(U.rid) }) }), /* @__PURE__ */ T("div", {
										className: "harmonies-tools",
										children: [
											/* @__PURE__ */ w("span", { children: E.config.side }),
											/* @__PURE__ */ w("button", {
												className: "btn-quiet",
												"aria-label": S("games.harmonies.scoring"),
												onClick: () => tt("score"),
												children: /* @__PURE__ */ w(d, { size: 20 })
											}),
											/* @__PURE__ */ w("button", {
												className: "btn-quiet",
												"aria-label": S("common.log.title"),
												onClick: () => Ce(!0),
												children: /* @__PURE__ */ w(f, { size: 20 })
											})
										]
									})]
								}), /* @__PURE__ */ w("div", {
									className: "harmonies-board-area",
									children: /* @__PURE__ */ w(ut, {
										rid: U.rid,
										board: U.board,
										side: E.config.side,
										sanctuaries: E.config.sanctuaries,
										selected: k,
										legal: We,
										preview: Z,
										habitat: Ge,
										animalPreview: X && F ? {
											key: X.key,
											spirit: !!I[F].spirit,
											whisper: !!I[F].whisper
										} : null,
										label: S("games.harmonies.boardLabel"),
										resetLabel: S("games.harmonies.resetCamera"),
										cellLabel: (e) => S("games.harmonies.cellLabel", {
											n: Ae.findIndex((t) => t.key === e) + 1,
											stack: dt(e)
										}),
										onSelect: at
									})
								})]
							}),
							/* @__PURE__ */ T("aside", {
								className: "harmonies-personal",
								children: [
									/* @__PURE__ */ T("div", {
										className: "harmonies-section-title",
										children: [
											/* @__PURE__ */ w("h2", { children: S(D === s ? "games.harmonies.myCards" : "games.harmonies.cardsOf", { name: Le(U.rid) }) }),
											/* @__PURE__ */ w("button", {
												className: "btn-quiet harmonies-market-open",
												onClick: () => tt("market"),
												children: S(E.config.sanctuaries ? "games.harmonies.taskMarket" : "games.harmonies.market")
											}),
											/* @__PURE__ */ w("span", {
												className: "harmonies-active-count",
												children: S("games.harmonies.incomplete", { n: Be })
											})
										]
									}),
									/* @__PURE__ */ T("div", {
										ref: ae,
										className: "harmonies-personal-cards",
										children: [
											Re.map((e) => /* @__PURE__ */ w(Dt, {
												id: e.id,
												placed: e.placed,
												board: U.board,
												side: E.config.side,
												anchorName: `hm-card:${U.rid}:${e.id}`,
												selected: F === e.id,
												compact: !0,
												onClick: () => nt(e.id)
											}, e.id)),
											W.map((e) => /* @__PURE__ */ w(At, {
												id: e.id,
												completed: e.completed,
												selected: G === e.id,
												compact: !0,
												anchorName: `hm-sanctuary:${U.rid}:${e.id}`,
												onClick: () => rt(e.id)
											}, e.id)),
											Re.length === 0 && W.length === 0 && /* @__PURE__ */ w("p", {
												className: "harmonies-no-cards",
												children: S("games.harmonies.noCards")
											}),
											q.length > 0 && /* @__PURE__ */ T("button", {
												className: "harmonies-completed",
												onClick: () => tt("completed"),
												children: [/* @__PURE__ */ w("span", {
													"aria-hidden": !0,
													children: "❧"
												}), /* @__PURE__ */ w("strong", { children: S("games.harmonies.completed", { n: q.length }) })]
											})
										]
									}),
									/* @__PURE__ */ T("button", {
										className: "harmonies-score-line",
										onClick: () => tt("score"),
										children: [
											/* @__PURE__ */ T("span", { children: [
												S("games.harmonies.animals"),
												" ",
												U.score.animals
											] }),
											/* @__PURE__ */ T("span", { children: [
												S("games.harmonies.spiritScore"),
												" ",
												U.score.spirits
											] }),
											/* @__PURE__ */ w("strong", { children: S("games.harmonies.points", { n: U.score.total }) })
										]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ T("footer", {
						className: "harmonies-actions",
						children: [/* @__PURE__ */ T("div", {
							className: "harmonies-held",
							children: [/* @__PURE__ */ w("span", { children: S("games.harmonies.held") }), /* @__PURE__ */ w("div", {
								ref: v,
								children: Array.from({ length: 3 }, (e, t) => /* @__PURE__ */ w("button", {
									type: "button",
									className: "harmonies-held-token",
									"data-selected": j !== null && E.turn.held[t] === j,
									disabled: !K || !E.turn.held[t],
									"aria-label": E.turn.held[t] ? S(Ot[E.turn.held[t]]) : S("games.harmonies.emptyCell"),
									"aria-pressed": j !== null && E.turn.held[t] === j,
									onClick: () => it(E.turn.held[t]),
									children: E.turn.held[t] && /* @__PURE__ */ w("svg", {
										viewBox: "-27 -20 54 45",
										"aria-hidden": "true",
										children: /* @__PURE__ */ w(bt, { terrain: E.turn.held[t] })
									})
								}, t))
							})]
						}), /* @__PURE__ */ T("div", {
							className: "harmonies-selection",
							children: [/* @__PURE__ */ w("div", {
								className: "harmonies-selection-info",
								children: k ? /* @__PURE__ */ T(C, { children: [
									/* @__PURE__ */ T("span", { children: [
										S("games.harmonies.selectedCell"),
										" · ",
										Ae.findIndex((e) => e.key === k) + 1
									] }),
									/* @__PURE__ */ T("div", {
										className: "harmonies-stack-detail",
										children: [/* @__PURE__ */ w("svg", {
											viewBox: "-30 -57 60 81",
											"aria-hidden": "true",
											children: /* @__PURE__ */ w(St, {
												layers: Ke?.layers ?? [],
												animal: Ke?.animal,
												whisper: Ke?.whisper,
												preview: Z?.terrain
											})
										}), /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w("strong", { children: S("games.harmonies.layers", { n: (Ke?.layers.length ?? 0) + +!!Z }) }), /* @__PURE__ */ w("small", { children: [...Ke?.layers ?? [], ...Z ? [Z.terrain] : []].map((e) => S(Ot[e])).join(" · ") || S("games.harmonies.emptyCell") })] })]
									}),
									Ke?.sanctuaryAnimals ? /* @__PURE__ */ w("small", { children: S("games.harmonies.shelterCount", { n: Ke.sanctuaryAnimals }) }) : null
								] }) : /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("span", { children: F ? S(I[F].nameKey) : G === void 0 ? S("games.harmonies.stack") : S("games.harmonies.buildingSanctuary", { name: S(H[G].nameKey) }) }), /* @__PURE__ */ w("strong", {
									className: "harmonies-action-prompt",
									children: F ? S(He.length + Ue.length ? "games.harmonies.matchCount" : "games.harmonies.noHabitat", { n: (/* @__PURE__ */ new Set([...He.map((e) => e.key), ...Ue.map((e) => e.key)])).size }) : S(E.turn.drafted ? E.turn.held.length ? "games.harmonies.placePrompt" : "games.harmonies.optionalPrompt" : "games.harmonies.draftPrompt")
								})] })
							}), /* @__PURE__ */ T("div", {
								className: "harmonies-action-buttons",
								children: [
									Y.length > 1 && /* @__PURE__ */ w("button", {
										className: "btn-quiet harmonies-match-cycle",
										"aria-label": S("games.harmonies.nextMatch"),
										onClick: () => R((e) => e + 1),
										children: /* @__PURE__ */ w(h, { size: 20 })
									}),
									G !== void 0 && /* @__PURE__ */ w("button", {
										className: "btn-quiet harmonies-build-cancel",
										onClick: () => ge(null),
										children: S("games.harmonies.stopBuilding")
									}),
									/* @__PURE__ */ w("button", {
										type: "button",
										className: "btn-base harmonies-primary",
										disabled: !K || !(X || J || Ye || Je || qe),
										onClick: ct,
										children: lt
									}),
									qe && (X || Ye) && /* @__PURE__ */ w("button", {
										className: "btn-quiet harmonies-end-secondary",
										onClick: st,
										children: S("games.harmonies.endTurn")
									})
								]
							})]
						})]
					})
				]
			}),
			Se && /* @__PURE__ */ w(ie, {
				log: E.log,
				line: ft,
				onClose: () => Ce(!1)
			}),
			/* @__PURE__ */ T(l, {
				open: be,
				onClose: () => xe(!1),
				label: $,
				title: $,
				tall: !0,
				footer: z === "card" && Q ? /* @__PURE__ */ T("div", {
					className: "harmonies-sheet-footer",
					children: [Ze && /* @__PURE__ */ w("button", {
						className: "btn-base harmonies-primary",
						onClick: () => {
							le(V.id), m({
								type: "takeCard",
								index: V.market
							}), xe(!1);
						},
						children: S("games.harmonies.takeCard")
					}), K && Xe && Xe.placed < Q.scores.length && /* @__PURE__ */ w("button", {
						className: "btn-base harmonies-primary",
						onClick: () => ot(Q.id),
						children: S("games.harmonies.findHabitat")
					})]
				}) : z === "sanctuary" && Qe ? /* @__PURE__ */ T("div", {
					className: "harmonies-sheet-footer",
					children: [et && /* @__PURE__ */ w("button", {
						className: "btn-base harmonies-primary",
						onClick: () => {
							le(L.id, !0), m({
								type: "takeSanctuary",
								index: L.market
							}), xe(!1);
						},
						children: S("games.harmonies.takeSanctuary")
					}), K && $e && !$e.completed && /* @__PURE__ */ w("button", {
						className: "btn-base harmonies-primary",
						onClick: () => {
							ge(Qe.id), pe(null), M(E.turn.held[0] ?? null), A($e.key ?? null), xe(!1);
						},
						children: S("games.harmonies.buildSanctuary")
					})]
				}) : void 0,
				children: [
					z === "market" && /* @__PURE__ */ T(C, { children: [pt(), E.config.sanctuaries && /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("h3", { children: S("games.harmonies.sanctuaries") }), mt()] })] }),
					z === "card" && Q && /* @__PURE__ */ T("div", {
						ref: se,
						className: "harmonies-card-inspect",
						children: [
							/* @__PURE__ */ w(Dt, {
								id: Q.id,
								placed: Xe?.placed,
								board: U.board,
								side: E.config.side
							}),
							Q.spirit && /* @__PURE__ */ w("p", { children: S(he[Q.spirit]) }),
							Q.whisper && /* @__PURE__ */ w("p", { children: S("games.harmonies.whisperScoring") }),
							K && Xe && W.some((e) => Ie(U.board, U.cards, W, Q.id, e.id)) && /* @__PURE__ */ w("button", {
								className: "btn-quiet harmonies-shelter-action",
								onClick: () => ot(Q.id),
								children: S("games.harmonies.shelterAnimal")
							}),
							/* @__PURE__ */ w("div", {
								className: "harmonies-diagram-inspect",
								children: /* @__PURE__ */ w(wt, {
									card: Q,
									rotation: Te.rotation,
									mirrored: Te.mirrored,
									label: S("games.harmonies.target")
								})
							}),
							/* @__PURE__ */ T("div", {
								className: "harmonies-diagram-buttons",
								children: [/* @__PURE__ */ T("button", {
									className: "btn-quiet",
									onClick: () => Ee((e) => ({
										...e,
										rotation: (e.rotation + 1) % 6
									})),
									children: [/* @__PURE__ */ w(h, { size: 20 }), S("games.harmonies.rotate")]
								}), E.config.pulse && /* @__PURE__ */ T("button", {
									className: "btn-quiet",
									"aria-pressed": Te.mirrored,
									onClick: () => Ee((e) => ({
										...e,
										mirrored: !e.mirrored
									})),
									children: [/* @__PURE__ */ w(p, { size: 20 }), S("games.harmonies.mirror")]
								})]
							})
						]
					}),
					z === "sanctuary" && Qe && /* @__PURE__ */ T("div", {
						ref: se,
						className: "harmonies-card-inspect",
						children: [
							/* @__PURE__ */ w(At, {
								id: Qe.id,
								completed: $e?.completed
							}),
							/* @__PURE__ */ w("p", { children: S("games.harmonies.sanctuaryStack") }),
							/* @__PURE__ */ w("p", { children: S("games.harmonies.sanctuaryColors") }),
							/* @__PURE__ */ w("svg", {
								className: "harmonies-sanctuary-colors",
								viewBox: "0 0 120 50",
								"aria-hidden": "true",
								children: Qe.colors.map((e, t) => /* @__PURE__ */ w(bt, {
									terrain: e,
									x: 30 + t * 60,
									y: 22
								}, e))
							}),
							$e?.key && /* @__PURE__ */ w("p", { children: dt($e.key) })
						]
					}),
					z === "completed" && /* @__PURE__ */ w("div", {
						className: "harmonies-sheet-cards",
						children: q.map((e) => /* @__PURE__ */ w(Dt, {
							id: e.id,
							placed: e.placed,
							board: U.board,
							side: E.config.side,
							onClick: () => nt(e.id)
						}, e.id))
					}),
					z === "replace" && /* @__PURE__ */ T(C, { children: [
						/* @__PURE__ */ w("p", { children: S("games.harmonies.soloReplaceHint") }),
						pt(!0),
						/* @__PURE__ */ w("button", {
							className: "btn-quiet",
							onClick: () => m({ type: "endTurn" }),
							children: S("games.harmonies.noReplace")
						})
					] }),
					z === "score" && /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ T("div", {
						className: "harmonies-score-table",
						children: [Object.entries(kt).filter(([e]) => e !== "sanctuaries" && e !== "whispers" || E.config[e]).map(([e, t]) => /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w("span", { children: S(t) }), /* @__PURE__ */ w("strong", { children: U.score[e] })] }, e)), /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w("span", { children: S("games.harmonies.total") }), /* @__PURE__ */ w("strong", { children: U.score.total })] })]
					}), /* @__PURE__ */ w("p", { children: S(E.config.side === "B" ? "games.harmonies.islands" : "games.harmonies.riverLength", { n: E.config.side === "B" ? U.score.islands : U.score.river }) })] })
				]
			}),
			/* @__PURE__ */ w(l, {
				open: Pe,
				label: S("games.harmonies.chooseSpirit"),
				title: S("games.harmonies.chooseSpirit"),
				tall: !0,
				children: /* @__PURE__ */ w("div", {
					className: "harmonies-spirit-choices",
					children: ue?.spirits.map((e) => /* @__PURE__ */ T("div", { children: [
						/* @__PURE__ */ w(Dt, { id: e }),
						/* @__PURE__ */ w("p", { children: S(he[I[e].spirit]) }),
						/* @__PURE__ */ T("button", {
							className: "btn-base harmonies-primary",
							onClick: () => m({
								type: "chooseSpirit",
								card: e
							}),
							children: [/* @__PURE__ */ w(u, { size: 20 }), S("games.harmonies.chooseThisSpirit")]
						})
					] }, e))
				})
			}),
			/* @__PURE__ */ T("span", {
				className: "sr-only",
				children: [/* @__PURE__ */ w(d, { "aria-hidden": !0 }), S("games.harmonies.stackOrder")]
			})
		]
	});
}
//#endregion
//#region src/games/harmonies/crescendo-bot.ts
var Mt = {
	width: 4,
	potential: .65,
	cost: .7,
	sanctuary: 1.3
}, Nt = {
	width: 1,
	potential: 1.9,
	cost: .7,
	sanctuary: 1.3
}, Pt = /* @__PURE__ */ new Map();
function Ft(e, t, n) {
	let r = `${e.id}:${t}:${n}`, i = Pt.get(r);
	if (i) return i;
	let a = B(t), o = new Set(a.map((e) => e.key)), s = [];
	for (let t of a) for (let r = 0; r < (n ? 2 : 1); r++) for (let n = 0; n < 6; n++) {
		let i = e.pattern.map((e) => {
			let i = Le(e, n, !!r);
			return {
				key: `${t.q + i.q},${t.r + i.r}`,
				part: i
			};
		});
		i.every((e) => o.has(e.key)) && s.push({
			key: t.key,
			parts: i
		});
	}
	return Pt.set(r, s), s;
}
function It(e, t, n) {
	let r = e[t], i = r?.layers ?? [];
	return i.length === n.height && i.at(-1) === n.terrain ? 0 : r?.animal || r?.whisper || r?.sanctuary !== void 0 || i.length >= n.height ? Infinity : n.terrain === "gray" ? i.every((e) => e === "gray") ? n.height - i.length : Infinity : n.terrain === "green" ? i.every((e) => e === "brown") ? n.height - i.length : Infinity : n.terrain === "red" && n.height === 2 ? !i.length || i.length === 1 && [
		"gray",
		"brown",
		"red"
	].includes(i[0]) ? n.height - i.length : Infinity : !i.length && n.height === 1 ? 1 : Infinity;
}
function Lt(e) {
	return JSON.stringify([
		e.board,
		e.cards,
		e.sanctuaries,
		e.held,
		e.took,
		e.tookSanctuary
	]);
}
function Rt(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return JSON.stringify([
		e.current,
		e.serial,
		e.config,
		e.turn,
		e.groups,
		e.market,
		e.sanctuaryMarket,
		n.board,
		n.cards,
		n.sanctuaries
	]);
}
function zt(e, t) {
	let n = {
		...e,
		board: { ...e.board },
		cards: e.cards.map((e) => ({ ...e })),
		sanctuaries: e.sanctuaries.map((e) => ({ ...e })),
		held: [...e.held],
		actions: [...e.actions, t]
	};
	if (t.type === "place") {
		let r = Pe(e.board, t.key, t.terrain) ? t.sanctuary : e.board[t.key]?.sanctuary;
		if (n.board[t.key] = {
			...e.board[t.key],
			layers: [...e.board[t.key]?.layers ?? [], t.terrain],
			...r === void 0 ? {} : { sanctuary: r }
		}, n.held.splice(n.held.indexOf(t.terrain), 1), r !== void 0) {
			let e = n.sanctuaries.find((e) => e.id === r);
			e.key = t.key, e.completed = n.board[t.key].layers.length === 4;
		}
	} else if (t.type === "animal") n.cards.find((e) => e.id === t.card).placed++, n.board[t.key] = {
		...e.board[t.key],
		...I[t.card].whisper ? { whisper: !0 } : { animal: I[t.card].spirit ? "spirit" : "animal" }
	};
	else if (t.type === "sanctuaryAnimal") {
		n.cards.find((e) => e.id === t.card).placed++;
		let r = n.sanctuaries.find((e) => e.id === t.sanctuary).key;
		n.board[r] = {
			...e.board[r],
			sanctuaryAnimals: (e.board[r].sanctuaryAnimals ?? 0) + 1
		};
	}
	return n;
}
function Bt(e, t, n) {
	let r = e.players.find((e) => e.rid === t), i = e.config.side, a = B(i), o = {
		board: r.board,
		cards: r.cards,
		sanctuaries: r.sanctuaries,
		held: e.turn.held,
		took: e.turn.tookCard,
		tookSanctuary: e.turn.tookSanctuary,
		actions: []
	}, s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map();
	function l(t, r) {
		let a = I[r.id], o = a.scores.length - r.placed;
		if (!o) return 0;
		let s = JSON.stringify([t, r]), l = c.get(s);
		if (l !== void 0) return l;
		let u = /* @__PURE__ */ new Map();
		for (let n of Ft(a, i, e.config.pulse)) {
			let e = t[n.key];
			if (e?.sanctuary !== void 0 || (a.whisper ? e?.whisper : e?.animal)) continue;
			let r = 0;
			for (let e of n.parts) if (r += It(t, e.key, e.part), !Number.isFinite(r)) break;
			r < (u.get(n.key) ?? Infinity) && u.set(n.key, r);
		}
		let d = [...u.entries()].sort((e, t) => e[1] - t[1]).slice(0, o).reduce((e, [i, o], s) => e + (a.whisper ? t[i]?.animal ? 5 : 3 : a.spirit ? 7 : a.scores[r.placed + s] - (a.scores[r.placed + s - 1] ?? 0)) * .76 ** s / (1 + o * n.cost), 0);
		return c.set(s, d), d;
	}
	function u(e) {
		let t = Lt(e), r = s.get(t);
		if (r !== void 0) return r;
		let o = He(e.board, e.cards, i, e.sanctuaries).total;
		for (let t of e.cards) o += l(e.board, t) * n.potential;
		for (let { key: t } of a) {
			let n = e.board[t];
			n?.layers.length ? n.sanctuary === void 0 && !n.animal && !n.whisper && (n.layers.every((e) => e === "brown") && (o += n.layers.length * 1.15), n.layers.length === 1 && n.layers[0] === "red" && (o += .7)) : o += .15;
		}
		for (let t of e.sanctuaries) if (!t.completed) {
			let r = H[t.id], s = 0;
			for (let { key: o } of a) {
				let a = e.board[o], c = a?.layers ?? [];
				if (t.key && t.key !== o || a?.animal || a?.whisper || a?.sanctuary !== void 0 && a.sanctuary !== t.id || !c.every((e, t) => e === r.layers[t])) continue;
				let l = W(o, i).filter((t) => r.colors.includes(G(e.board, t))).length, u = e.held.filter((e) => r.layers.slice(c.length).includes(e)).length;
				s = Math.max(s, (4 + l * 2.5) / (1 + (4 - c.length) * n.cost) + c.length * .5 + u * .15);
			}
			o += s * n.sanctuary - .7;
		}
		return o -= e.cards.filter((e) => e.placed < I[e.id].scores.length && !I[e.id].spirit).length * .65, s.set(t, o), o;
	}
	function d(e) {
		return [...new Map(e.map((e) => [Lt(e), e])).values()].sort((e, t) => u(t) - u(e)).slice(0, n.width);
	}
	function f(t) {
		let n = [];
		for (let r of t.cards) if (r.placed < I[r.id].scores.length) {
			for (let a of ze(t.board, I[r.id], e.config.pulse, i)) n.push(zt(t, {
				type: "animal",
				card: r.id,
				key: a.key,
				rotation: a.rotation,
				mirrored: a.mirrored
			}));
			for (let e of t.sanctuaries) Ie(t.board, t.cards, t.sanctuaries, r.id, e.id) && n.push(zt(t, {
				type: "sanctuaryAnimal",
				card: r.id,
				sanctuary: e.id
			}));
		}
		return t.cards.filter((e) => e.placed < I[e.id].scores.length).length + t.sanctuaries.filter((e) => !e.completed).length < 4 && (t.took || e.market.forEach((e, r) => {
			e !== null && n.push({
				...t,
				cards: [...t.cards, {
					id: e,
					placed: 0
				}],
				took: !0,
				actions: [...t.actions, {
					type: "takeCard",
					index: r
				}]
			});
		}), t.tookSanctuary || e.sanctuaryMarket.forEach((e, r) => {
			e !== null && n.push({
				...t,
				sanctuaries: [...t.sanctuaries, {
					id: e,
					completed: !1
				}],
				tookSanctuary: !0,
				actions: [...t.actions, {
					type: "takeSanctuary",
					index: r
				}]
			});
		})), n;
	}
	let p = e.turn.drafted ? [o] : e.groups.flatMap((e, t) => e?.length === 3 ? [{
		...o,
		held: e,
		actions: [{
			type: "draft",
			group: t
		}]
	}] : []), m = [];
	for (let e of p) {
		let t = d([e, ...f(e)]);
		for (let n = 0; n < e.held.length; n++) {
			t = d(t.flatMap((e) => [e, ...f(e)]));
			let e = [];
			for (let n of t) for (let t of new Set(n.held)) for (let { key: r } of a) for (let a of Ne(n.board, r, t, i, n.sanctuaries)) e.push(zt(n, {
				type: "place",
				terrain: t,
				key: r,
				...a === void 0 ? {} : { sanctuary: a }
			}));
			t = d(e);
		}
		for (let e = 0; e < 12 && t.length; e++) {
			let e = Lt(t[0]);
			if (t = d(t.flatMap((e) => [e, ...f(e)])), Lt(t[0]) === e) break;
		}
		m.push(...t);
	}
	let h = d(m)[0];
	return h ? [...h.actions, { type: "endTurn" }] : [];
}
function Vt(e = Mt) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid);
		if (!i || r.phase !== "play" || r.current !== n.rid) return null;
		if (!i.spiritChosen) return t.private?.spirits.length ? { action: {
			type: "chooseSpirit",
			card: t.private.spirits[0]
		} } : null;
		let a = n.memory, o = a?.crescendo && a.expected === Rt(r, n.rid) ? a.actions : Bt(r, n.rid, e), s = o[0];
		if (!s) return null;
		let c = structuredClone(r), l = c.players.find((e) => e.rid === n.rid);
		if (s.type === "draft") c.turn.drafted = !0, c.turn.held = c.groups[s.group], c.groups[s.group] = null;
		else if (s.type === "takeCard") l.cards.push({
			id: c.market[s.index],
			placed: 0
		}), c.market[s.index] = null, c.turn.tookCard = !0;
		else if (s.type === "takeSanctuary") l.sanctuaries.push({
			id: c.sanctuaryMarket[s.index],
			completed: !1
		}), c.sanctuaryMarket[s.index] = null, c.turn.tookSanctuary = !0;
		else {
			let e = zt({
				board: l.board,
				cards: l.cards,
				sanctuaries: l.sanctuaries,
				held: c.turn.held,
				took: c.turn.tookCard,
				tookSanctuary: c.turn.tookSanctuary,
				actions: []
			}, s);
			l.board = e.board, l.cards = e.cards, l.sanctuaries = e.sanctuaries, c.turn.held = e.held;
		}
		return {
			action: s,
			memory: s.type === "endTurn" ? null : {
				crescendo: !0,
				expected: Rt(c, n.rid),
				actions: o.slice(1)
			}
		};
	};
}
//#endregion
//#region src/games/harmonies/bot-search.ts
var Ht = {
	width: 6,
	animalWeight: 2.4,
	costWeight: .65,
	futureDiscount: .8,
	materialWeight: .6,
	spaceWeight: .3,
	cardTax: .8,
	finishWeight: .2
}, Ut = [
	"gray",
	"blue",
	"brown",
	"green",
	"yellow",
	"red"
], Wt = [
	[],
	["gray"],
	["gray", "gray"],
	[
		"gray",
		"gray",
		"gray"
	],
	["blue"],
	["brown"],
	["brown", "brown"],
	["green"],
	["brown", "green"],
	[
		"brown",
		"brown",
		"green"
	],
	["yellow"],
	["red"],
	["red", "red"]
], Gt = Wt.map((e) => e.length ? Ut.indexOf(e.at(-1)) : -1), Kt = Wt.map((e) => e.length), qt = [
	0,
	1,
	3,
	7
], Jt = new Map(R.map((e, t) => [e.key, t])), Yt = R.map((e) => W(e.key).map((e) => Jt.get(e))), Xt = Wt.map((e) => Ut.map((t) => Me({ [R[0].key]: { layers: e } }, R[0].key, t) ? t === "red" && e.length === 1 ? 12 : Wt.findIndex((n) => n.join() === [...e, t].join()) : -1)), Zt = Wt.map((e) => Wt.map((t) => {
	if (e.length === t.length && e.at(-1) === t.at(-1)) return 0;
	if (!t.length || e.length >= t.length) return Infinity;
	let n = t.at(-1);
	return n === "green" ? e.every((e) => e === "brown") ? t.length - e.length : Infinity : n === "gray" ? e.every((e) => e === "gray") ? t.length - e.length : Infinity : n === "red" && t.length === 2 ? e.length ? [
		"gray",
		"brown",
		"red"
	].includes(e[0]) ? 1 : Infinity : 2 : e.length ? Infinity : 1;
})), Qt = /* @__PURE__ */ new Map();
function $t(e, t) {
	let n = `${e.id}:${t}`, r = Qt.get(n);
	if (r) return r;
	let i = [], a = /* @__PURE__ */ new Set();
	for (let n = 0; n < R.length; n++) for (let r = 0; r < (t ? 2 : 1); r++) for (let t = 0; t < 6; t++) {
		let o = e.pattern.map((e) => {
			let i = Le(e, t, r === 1);
			return {
				cell: Jt.get(`${R[n].q + i.q},${R[n].r + i.r}`) ?? -1,
				stack: Wt.findIndex((e) => e.length === i.height && e.at(-1) === i.terrain)
			};
		});
		if (o.some((e) => e.cell < 0)) continue;
		let s = `${n}:${o.map((e) => `${e.cell}/${e.stack}`).sort().join(";")}`;
		a.has(s) || (a.add(s), i.push({
			anchor: n,
			parts: o,
			rotation: t,
			mirrored: r === 1
		}));
	}
	return Qt.set(n, i), i;
}
function en(e) {
	let t = 0;
	return {
		cells: R.map(({ key: n }, r) => {
			let i = e[n];
			i?.animal && (t |= 1 << r);
			let a = i?.layers ?? [];
			return a.length === 2 && a[1] === "red" ? 12 : Wt.findIndex((e) => e.join() === a.join());
		}),
		occupied: t
	};
}
function tn(e, t) {
	let n = 0, r = [];
	for (let i = 0; i < e.length; i++) {
		if (n & 1 << i || !t(i)) continue;
		let e = [i];
		n |= 1 << i;
		for (let r = 0; r < e.length; r++) for (let i of Yt[e[r]]) !(n & 1 << i) && t(i) && (n |= 1 << i, e.push(i));
		r.push(e.length);
	}
	return r;
}
function nn(e, t, n) {
	let r = 0, i = 0, a = 0, o = 0, s = tn(e, (t) => Gt[e[t]] === 4), c = tn(e, (t) => e[t] === 12), l = tn(e, (t) => e[t] === 4);
	r += s.filter((e) => e >= 2).length * 5, i += s.filter((e) => e === 1).length;
	for (let t = 0; t < e.length; t++) {
		let s = e[t], c = Gt[s], l = Kt[s];
		if (s || a++, c === 3 && (r += qt[l]), c === 0 && (Yt[t].some((t) => Gt[e[t]] === 0) ? r += qt[l] : i += qt[l] * .5), (s === 5 || s === 6) && (i += s === 5 ? 1.3 : 3.4), s === 11 && (i += 1), s === 12) {
			let n = 0;
			for (let r of Yt[t]) Gt[e[r]] >= 0 && (n |= 1 << Gt[e[r]]);
			let a = 0;
			for (; n; n &= n - 1) a++;
			a >= 3 ? r += 5 : i += a * .8;
		}
		n === "deer" && c === 3 && l >= 2 && (o += 4), n === "owl" && c === 3 && (o += l === 3 ? 1 : 3), n === "bear" && c === 0 && (o += l === 3 ? 1 : 3), n === "ibex" && c === 0 && l >= 2 && (o += 4), n === "tortoise" && c === 1 && (o += 2);
	}
	if (t === "B") r += Math.max(1, tn(e, (t) => Gt[e[t]] !== 1).length) * 5;
	else {
		let t = 0;
		for (let n = 0; n < e.length; n++) if (e[n] === 4) {
			let r = new Int8Array(e.length), i = [n];
			r[n] = 1;
			for (let n = 0; n < i.length; n++) {
				let a = i[n];
				t = Math.max(t, r[a]);
				for (let t of Yt[a]) e[t] === 4 && !r[t] && (r[t] = r[a] + 1, i.push(t));
			}
		}
		r += t > 6 ? 15 + (t - 6) * 4 : [
			0,
			0,
			2,
			5,
			8,
			11,
			15
		][t];
	}
	return n === "crane" && (o = c.filter((e) => e >= 2).length * 6), n === "cat" && (o = c.filter((e) => e === 1).length * 4), n === "dragonfly" && (o = l.filter((e) => e >= 2).length * 7), n === "butterfly" && (o = s.length * 5), n === "lion" && (o = s.reduce((e, t) => e + (t >= 3 ? 10 : 2), 0)), {
		score: r,
		spirit: o,
		material: i,
		empty: a
	};
}
function rn(e, t) {
	if (e.occupied & 1 << t.anchor) return Infinity;
	let n = 0;
	for (let r of t.parts) {
		let t = Zt[e.cells[r.cell]][r.stack];
		if (t && e.occupied & 1 << r.cell || (n += t, !Number.isFinite(n))) return Infinity;
	}
	return n;
}
function an(e) {
	return `${e.cells.map((e) => e.toString(16)).join("")}/${e.occupied}/${e.cards.map((e) => `${e.id}:${e.placed}`).join(",")}/${[...e.held].sort().join("")}/${e.took}`;
}
function on(e, t, n) {
	let r = e.players.find((e) => e.rid === t), i = r.cards.find((e) => I[e.id].spirit), a = i ? I[i.id].spirit : void 0, o = {
		...en(r.board),
		cards: r.cards.map((e) => ({ ...e })),
		held: e.turn.held.map((e) => Ut.indexOf(e)),
		took: e.turn.tookCard,
		actions: [],
		value: 0
	}, s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = (e, t) => e.spirit + t * 1.5;
	function u(t) {
		let r = an(t), i = c.get(r);
		if (i !== void 0) return i;
		let o = t.cells.map((e) => e.toString(16)).join(""), u = s.get(o);
		u || (u = nn(t.cells, e.config.side, a), s.set(o, u));
		let d = e.lastRound || u.empty <= 2 || e.bagLeft < (e.players.length === 1 ? 9 : 3) ? 0 : Math.min(e.bagLeft / (e.players.length === 1 ? 9 : 3 * e.players.length), (u.empty - 2) * .8), f = d > 0 ? n.animalWeight : 1, p = t.cards.find((e) => I[e.id].spirit && e.placed), m = u.score + (p ? l(u, d) * f : 0) + (d ? u.material * n.materialWeight + u.empty * n.spaceWeight : 0), h = [];
		for (let n = 0; n < t.cards.length; n++) {
			let r = t.cards[n], i = I[r.id];
			if (i.spirit || (m += (i.scores[r.placed - 1] ?? 0) * f), r.placed >= i.scores.length) continue;
			let a = Array(R.length).fill(Infinity);
			for (let n of $t(i, e.config.pulse)) {
				let e = rn(t, n);
				e < a[n.anchor] && (a[n.anchor] = e);
			}
			for (let e = 0; e < a.length; e++) Number.isFinite(a[e]) && h.push({
				anchor: e,
				cost: a[e],
				card: n
			});
		}
		let g = /* @__PURE__ */ new Map(), _ = /* @__PURE__ */ new Set();
		for (let e = 0; e < 15; e++) {
			let e, r = 0;
			for (let i of h) {
				if (_.has(i.anchor)) continue;
				let a = t.cards[i.card], o = I[a.id], s = g.get(i.card) ?? 0;
				if (a.placed + s >= o.scores.length) continue;
				let c = o.spirit ? l(u, d) : o.scores[a.placed + s] - (o.scores[a.placed + s - 1] ?? 0), f = d * 1.6 + t.held.length, p = c * (i.cost === 0 ? 1 : Math.max(0, 1 - i.cost / Math.max(1, f))) * n.futureDiscount ** s / (1 + i.cost * n.costWeight);
				p > r && (r = p, e = i);
			}
			if (!e) break;
			_.add(e.anchor), g.set(e.card, (g.get(e.card) ?? 0) + 1), m += r * f;
		}
		return m -= t.cards.filter((e) => e.placed < I[e.id].scores.length && !I[e.id].spirit).length * n.cardTax, c.set(r, m), m;
	}
	function d(e, t = n.width) {
		let r = /* @__PURE__ */ new Map();
		for (let t of e) {
			let e = an(t);
			r.has(e) || (t.value = u(t), r.set(e, t));
		}
		return [...r.values()].sort((e, t) => t.value - e.value).slice(0, t);
	}
	function f(t, n = !0) {
		let r = [];
		for (let n = 0; n < t.cards.length; n++) {
			let i = t.cards[n], a = I[i.id];
			if (i.placed >= a.scores.length) continue;
			let o = 0;
			for (let s of $t(a, e.config.pulse)) !(o & 1 << s.anchor) && rn(t, s) === 0 && (o |= 1 << s.anchor, r.push({
				...t,
				occupied: t.occupied | 1 << s.anchor,
				cards: t.cards.map((e, t) => t === n ? {
					...e,
					placed: e.placed + 1
				} : e),
				actions: [...t.actions, {
					type: "animal",
					card: i.id,
					key: R[s.anchor].key,
					rotation: s.rotation,
					mirrored: s.mirrored
				}]
			}));
		}
		if (n && !t.took && t.cards.filter((e) => e.placed < I[e.id].scores.length).length < 4) for (let n = 0; n < e.market.length; n++) {
			let i = e.market[n];
			i === null || t.cards.some((e) => e.id === i) || r.push({
				...t,
				took: !0,
				cards: [...t.cards, {
					id: i,
					placed: 0
				}],
				actions: [...t.actions, {
					type: "takeCard",
					index: n
				}]
			});
		}
		return r;
	}
	let p, m = e.turn.drafted ? [o] : e.groups.flatMap((e, t) => e?.length === 3 ? [{
		...o,
		held: e.map((e) => Ut.indexOf(e)),
		actions: [{
			type: "draft",
			group: t
		}]
	}] : []);
	for (let t of m) {
		let r = d([t, ...f(t)]);
		for (let e = 0; e < t.held.length && r.length; e++) {
			r = d(r.flatMap((e) => [e, ...f(e)]));
			let e = [];
			for (let t of r) for (let n of new Set(t.held)) for (let r = 0; r < R.length; r++) {
				if (t.occupied & 1 << r) continue;
				let i = Xt[t.cells[r]][n];
				if (i < 0) continue;
				let a = [...t.cells], o = [...t.held];
				a[r] = i, o.splice(o.indexOf(n), 1), e.push({
					...t,
					cells: a,
					held: o,
					actions: [...t.actions, {
						type: "place",
						terrain: Ut[n],
						key: R[r].key
					}]
				});
			}
			r = d(e);
		}
		if (!r.length) continue;
		let i = (t) => {
			let r = nn(t.cells, e.config.side, a), i = r.score + (t.cards.some((e) => I[e.id].spirit && e.placed) ? r.spirit : 0);
			for (let e of t.cards) I[e.id].spirit || (i += I[e.id].scores[e.placed - 1] ?? 0);
			return u(t) + i * n.finishWeight;
		};
		for (let e = 0; e < R.length + 1; e++) {
			let e = r.flatMap((e) => [e, ...f(e)]), t = r[0];
			if (r = [...new Map(e.map((e) => [an(e), e])).values()].map((e) => ({
				...e,
				value: i(e)
			})).sort((e, t) => t.value - e.value).slice(0, n.width), an(r[0]) === an(t)) break;
		}
		let o = r[0];
		(!p || o.value > p.value) && (p = o);
	}
	if (!p) return [];
	let h;
	if (e.players.length === 1 && !p.took) {
		let t = e.market.flatMap((e, t) => e === null ? [] : [{
			i: t,
			value: u({
				...p,
				cards: [...p.cards, {
					id: e,
					placed: 0
				}],
				took: !0
			})
		}]);
		t.sort((e, t) => e.value - t.value), h = t[0]?.i;
	}
	return [...p.actions, {
		type: "endTurn",
		...h === void 0 ? {} : { discard: h }
	}];
}
function sn(e, t) {
	let n = e.players.find((e) => e.rid === t), { cells: r, occupied: i } = en(n.board);
	return JSON.stringify([
		t,
		e.phase,
		e.current,
		e.serial,
		e.config,
		r,
		i,
		n.cards,
		e.turn,
		e.groups,
		e.market,
		e.lastRound,
		e.bagLeft
	]);
}
function cn(e, t, n) {
	let r = structuredClone(e), i = r.players.find((e) => e.rid === t);
	switch (n.type) {
		case "draft":
			r.turn.drafted = !0, r.turn.held = r.groups[n.group], r.groups[n.group] = null;
			break;
		case "takeCard":
			i.cards.push({
				id: r.market[n.index],
				placed: 0
			}), r.market[n.index] = null, r.turn.tookCard = !0;
			break;
		case "place":
			r.turn.held.splice(r.turn.held.indexOf(n.terrain), 1), i.board[n.key] = { layers: [...i.board[n.key]?.layers ?? [], n.terrain] };
			break;
		case "animal": i.cards.find((e) => e.id === n.card).placed++, i.board[n.key].animal = I[n.card].spirit ? "spirit" : "animal";
	}
	return sn(r, t);
}
function ln(e = Ht) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid);
		if (r.phase !== "play" || r.current !== n.rid || !i) return null;
		if (!i.spiritChosen) {
			let a = t.private?.spirits ?? [], o = a[0], s = -Infinity;
			for (let t of a) {
				let a = [...i.cards, {
					id: t,
					placed: 0
				}], c = on({
					...r,
					players: r.players.map((e) => e.rid === n.rid ? {
						...e,
						cards: a,
						spiritChosen: !0
					} : e)
				}, n.rid, e), l = structuredClone(i.board);
				for (let e of c) e.type === "place" && (l[e.key] = { layers: [...l[e.key]?.layers ?? [], e.terrain] });
				let u = nn(en(l).cells, r.config.side, I[t].spirit), d = u.score + u.spirit * .7 + u.material;
				d > s && (s = d, o = t);
			}
			return o === void 0 ? null : {
				action: {
					type: "chooseSpirit",
					card: o
				},
				memory: null
			};
		}
		let a = n.memory, o = a?.harmoniesPlan && a.expected === sn(r, n.rid) ? a.actions : on(r, n.rid, e), s = o[0];
		return s ? {
			action: s,
			memory: s.type === "endTurn" ? null : {
				harmoniesPlan: !0,
				expected: cn(r, n.rid, s),
				actions: o.slice(1)
			}
		} : null;
	};
}
//#endregion
//#region src/games/harmonies/bot.ts
function un(e, t) {
	return e.length === t.height && e.at(-1) === t.terrain ? 0 : e.length >= t.height ? Infinity : t.terrain === "green" ? e.every((e) => e === "brown") ? t.height - e.length : Infinity : t.terrain === "gray" ? e.every((e) => e === "gray") ? t.height - e.length : Infinity : t.terrain === "red" && t.height === 2 ? e.length === 0 ? 2 : [
		"gray",
		"brown",
		"red"
	].includes(e[0]) ? 1 : Infinity : e.length === 0 ? 1 : Infinity;
}
function dn(e, t, n) {
	let r = [];
	for (let i of R) {
		if (e[i.key]?.animal) continue;
		let a = Infinity;
		for (let r = 0; r < (n ? 2 : 1); r++) for (let n = 0; n < 6; n++) {
			let o = 0;
			for (let a of t.pattern) {
				let t = Le(a, n, r === 1), s = `${i.q + t.q},${i.r + t.r}`;
				if (!Ae.has(s)) {
					o = Infinity;
					break;
				}
				let c = un(e[s]?.layers ?? [], t);
				if (c > 0 && e[s]?.animal) {
					o = Infinity;
					break;
				}
				o += c;
			}
			a = Math.min(a, o);
		}
		Number.isFinite(a) && r.push(a);
	}
	r.sort((e, t) => e - t);
	let i = t.spirit ? 7 : t.scores.at(-1) / t.scores.length;
	return r.slice(0, 3).reduce((e, t, n) => e + i * [
		1,
		.4,
		.18
	][n] / (t + 1), 0);
}
var fn = (e, t) => {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid);
	if (n.phase !== "play" || n.current !== t.rid || !r) return null;
	if (!r.spiritChosen) {
		let t = e.private?.spirits ?? [];
		return t.length ? { action: {
			type: "chooseSpirit",
			card: t[n.serial % t.length]
		} } : null;
	}
	let i = r.cards.filter((e) => e.placed < I[e.id].scores.length);
	for (let e of i) {
		let t = ze(r.board, I[e.id], n.config.pulse)[0];
		if (t) return { action: {
			type: "animal",
			card: e.id,
			key: t.key,
			rotation: t.rotation,
			mirrored: t.mirrored
		} };
	}
	if (!n.turn.tookCard && i.length < 4) {
		let e = n.market.flatMap((e, t) => e === null ? [] : [t]);
		if (e.length) return { action: {
			type: "takeCard",
			index: e[n.serial % e.length]
		} };
	}
	if (!n.turn.drafted) {
		let e = n.groups.flatMap((e, t) => e?.length === 3 ? [t] : []);
		return e.length ? { action: {
			type: "draft",
			group: e[n.serial % e.length]
		} } : null;
	}
	if (n.turn.held.length) {
		let e = [...new Set(n.turn.held)].flatMap((e) => R.filter(({ key: t }) => Me(r.board, t, e)).map(({ key: t }) => ({
			terrain: e,
			key: t
		}))), t = e[(n.serial * 7 + r.score.cubes) % e.length];
		return t ? { action: {
			type: "place",
			terrain: t.terrain,
			key: t.key
		} } : null;
	}
	if (n.players.length === 1 && !n.turn.tookCard) {
		let e = n.market.flatMap((e, t) => e === null ? [] : [{
			index: t,
			value: dn(r.board, I[e], n.config.pulse)
		}]).reduce((e, t) => !e || t.value < e.value ? t : e, null);
		if (e) return { action: {
			type: "endTurn",
			discard: e.index
		} };
	}
	return { action: { type: "endTurn" } };
};
function pn(e = Ht) {
	let t = ln(e), n = Vt(), r = Vt(Nt);
	return (e, i) => {
		let a = e.public.config;
		return a.side === "C" || a.side === "D" || a.sanctuaries || a.whispers ? i.difficulty === "weak" ? r(e, i) : n(e, i) : i.difficulty === "weak" ? fn(e, i) : t(e, i);
	};
}
var mn = pn(), hn = (e, t, n) => {
	switch (e.type) {
		case "chooseSpirit": return n(I[e.card].nameKey);
		case "draft": return n("games.harmonies.hintDraft", { n: e.group + 1 });
		case "place": return n("games.harmonies.hintPlace", {
			terrain: n(Ot[e.terrain]),
			n: B(t.public.config.side).findIndex((t) => t.key === e.key) + 1
		});
		case "takeCard": return n("games.harmonies.hintTake", { animal: n(I[t.public.market[e.index]].nameKey) });
		case "animal": return n("games.harmonies.hintAnimal", {
			animal: n(I[e.card].nameKey),
			n: B(t.public.config.side).findIndex((t) => t.key === e.key) + 1
		});
		case "takeSanctuary": return n("games.harmonies.hintTakeSanctuary", { name: n(H[t.public.sanctuaryMarket[e.index]].nameKey) });
		case "sanctuaryAnimal": return n("games.harmonies.hintShelterAnimal", {
			animal: n(I[e.card].nameKey),
			sanctuary: n(H[e.sanctuary].nameKey)
		});
		case "endTurn": return n("games.harmonies.endTurn");
	}
};
//#endregion
//#region src/games/harmonies/fx.tsx
function gn({ id: e, ms: t, width: n }) {
	let i = a(null);
	return r(() => {
		let e = i.current?.animate([{ transform: "perspective(600px) rotateY(-90deg)" }, { transform: "perspective(600px) rotateY(0deg)" }], {
			duration: t,
			easing: "ease-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, [t]), /* @__PURE__ */ w("div", {
		ref: i,
		style: { width: n },
		children: /* @__PURE__ */ w(At, {
			id: e,
			compact: !0,
			completed: !0
		})
	});
}
var _n = (e, t) => {
	let n = e.data, r = e.kind === "takeSanctuary", i = `${r ? "hm-sanctuary" : "hm-card"}:${e.rid}:${n.id}`, a = t.anchor(i);
	if (!a) return null;
	let o = (e.rid === t.myRid ? t.anchor(`hm-take-source:${r ? "sanctuary" : "card"}:${n.id}`) : null) ?? t.anchor("hm-market-source") ?? {
		...a,
		x: a.x - a.w,
		y: a.y - 30
	}, s = t.queued ? 150 : 360;
	return {
		ms: s,
		hide: t.queued ? [] : [i],
		node: /* @__PURE__ */ w(E, {
			from: o,
			to: a,
			ms: s,
			children: /* @__PURE__ */ w("div", {
				style: { width: o.w },
				children: w(r ? At : Dt, {
					id: n.id,
					compact: o.h / o.w < 1.3
				})
			})
		})
	};
}, vn = {
	takeCard: _n,
	takeSanctuary: _n,
	completeSanctuary(e, t) {
		let { id: n } = e.data, r = `hm-sanctuary:${e.rid}:${n}`, i = t.anchor(r);
		if (!i) return null;
		let a = t.queued ? 160 : 420;
		return {
			ms: a,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ w("div", {
				style: {
					position: "absolute",
					left: i.x,
					top: i.y
				},
				children: /* @__PURE__ */ w(gn, {
					id: n,
					ms: a,
					width: i.w
				})
			})
		};
	},
	place(e, t) {
		let n = e.data, r = `hm-token:${e.rid}:${n.key}`, i = t.anchor(r);
		if (!i) return null;
		let a = e.rid === t.myRid ? t.anchor("hm-held") : null, o = a ? {
			x: a.x + a.w / 2 - i.w / 2,
			y: a.y,
			w: i.w,
			h: i.h
		} : {
			...i,
			y: i.y - 45
		}, s = t.queued ? 150 : 320;
		return v(), {
			ms: s,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ w(E, {
				from: o,
				to: i,
				ms: s,
				children: /* @__PURE__ */ w("span", {
					style: {
						display: "block",
						width: i.w,
						height: i.h
					},
					children: /* @__PURE__ */ w("svg", {
						width: "100%",
						height: "100%",
						viewBox: "-27 -18 54 40",
						children: /* @__PURE__ */ w(bt, { terrain: n.terrain })
					})
				})
			})
		};
	},
	animal(e, t) {
		let n = e.data, r = `hm-${n.whisper ? "whisper" : "animal"}:${e.rid}:${n.key}`, i = t.anchor(r);
		if (!i) return null;
		let a = t.queued ? 150 : 320;
		v();
		let o = t.anchor(`hm-card:${e.rid}:${n.card}`) ?? t.anchor("hm-personal-source"), s = o ? {
			x: o.x + o.w / 2 - i.w / 2,
			y: o.y + o.h - i.h,
			w: i.w,
			h: i.h
		} : {
			...i,
			y: i.y - 60
		};
		return {
			ms: a,
			hide: t.queued || n.sanctuary ? [] : [r],
			node: /* @__PURE__ */ w(E, {
				from: s,
				to: i,
				ms: a,
				children: /* @__PURE__ */ w("span", {
					style: {
						display: "block",
						width: i.w,
						height: i.h
					},
					children: /* @__PURE__ */ w("svg", {
						width: "100%",
						height: "100%",
						viewBox: "-13 -16 28 26",
						children: /* @__PURE__ */ w(xt, {
							spirit: !!n.spirit,
							whisper: !!n.whisper
						})
					})
				})
			})
		};
	}
};
//#endregion
//#region src/games/harmonies/game-over.tsx
function yn({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let s = c(), l = t, [u, d] = o(r), [f, p] = o(null), m = l.players.find((e) => e.rid === u) ?? l.players[0], h = (e) => n.find((t) => t.rid === e)?.name ?? e;
	return /* @__PURE__ */ T("div", {
		className: "harmonies-over",
		children: [
			/* @__PURE__ */ w(ue, {}),
			/* @__PURE__ */ T("h1", { children: [
				s("games.harmonies.name"),
				" · ",
				s("session.result.title")
			] }),
			/* @__PURE__ */ w("div", {
				className: "harmonies-over-players",
				children: e.ranking.map((t, n) => /* @__PURE__ */ T("button", {
					"aria-pressed": u === t,
					onClick: () => {
						d(t), p(null);
					},
					children: [/* @__PURE__ */ T("span", { children: [
						e.winner.includes(t) ? "🏆" : n + 1,
						" ",
						h(t)
					] }), /* @__PURE__ */ w("strong", { children: s("games.harmonies.points", { n: e.scores?.[t] ?? 0 }) })]
				}, t))
			}),
			l.suns !== void 0 && /* @__PURE__ */ T("p", {
				className: "harmonies-suns",
				children: ["☀ ", s("games.harmonies.suns", { n: l.suns })]
			}),
			/* @__PURE__ */ T("div", {
				className: "harmonies-over-main",
				children: [/* @__PURE__ */ w("div", {
					className: "harmonies-over-board",
					children: /* @__PURE__ */ w(ut, {
						board: m.board,
						side: l.config.side,
						sanctuaries: l.config.sanctuaries,
						selected: f,
						onSelect: p,
						label: s("games.harmonies.boardLabel"),
						resetLabel: s("games.harmonies.resetCamera"),
						cellLabel: (e) => s("games.harmonies.cellLabel", {
							n: B(l.config.side).findIndex((t) => t.key === e) + 1,
							stack: m.board[e]?.layers.map((e) => s(Ot[e])).join(" → ") || s("games.harmonies.emptyCell")
						})
					})
				}), /* @__PURE__ */ T("div", {
					className: "harmonies-over-detail",
					children: [
						f && /* @__PURE__ */ w("p", { children: m.board[f]?.layers.map((e) => s(Ot[e])).join(" → ") || s("games.harmonies.emptyCell") }),
						f && m.board[f]?.sanctuary !== void 0 && /* @__PURE__ */ T("p", { children: [
							s(H[m.board[f].sanctuary].nameKey),
							" · ",
							s("games.harmonies.shelterCount", { n: m.board[f].sanctuaryAnimals ?? 0 })
						] }),
						f && m.board[f]?.whisper && /* @__PURE__ */ T("p", { children: [
							s("games.harmonies.whisperPresent"),
							" · ",
							s("games.harmonies.points", { n: m.board[f].animal ? 5 : 2 })
						] }),
						/* @__PURE__ */ T("div", {
							className: "harmonies-score-table",
							children: [Object.entries(kt).filter(([e]) => e !== "sanctuaries" && e !== "whispers" || l.config[e]).map(([e, t]) => /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w("span", { children: s(t) }), /* @__PURE__ */ w("strong", { children: m.score[e] })] }, e)), /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w("span", { children: s("games.harmonies.total") }), /* @__PURE__ */ w("strong", { children: m.score.total })] })]
						}),
						/* @__PURE__ */ w("p", { children: s("games.harmonies.animalCubes", { n: m.score.cubes }) }),
						/* @__PURE__ */ T("div", {
							className: "harmonies-over-cards",
							children: [m.cards.map((e) => /* @__PURE__ */ w(Dt, {
								id: e.id,
								placed: e.placed,
								board: m.board,
								side: l.config.side,
								compact: !0
							}, e.id)), m.sanctuaries.map((e) => /* @__PURE__ */ w(At, {
								id: e.id,
								completed: e.completed,
								compact: !0
							}, e.id))]
						})
					]
				})]
			}),
			/* @__PURE__ */ T("div", {
				className: "harmonies-over-controls",
				children: [
					i && /* @__PURE__ */ w("button", {
						className: "btn-base harmonies-primary",
						onClick: i,
						children: s("session.result.playAgain")
					}),
					a && /* @__PURE__ */ w("button", {
						className: "btn-quiet",
						onClick: a,
						children: s("session.result.backToLobby")
					}),
					!i && !a && /* @__PURE__ */ w("p", { children: s("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/harmonies/options.tsx
function bn({ value: e, onChange: t }) {
	let n = c(), r = X.safeParse(e), i = r.success ? r.data : X.parse(void 0);
	return /* @__PURE__ */ T(C, { children: [
		/* @__PURE__ */ T(D, {
			title: n("games.harmonies.side"),
			children: [
				/* @__PURE__ */ w(fe, {
					name: "harmonies-side",
					value: "A",
					checked: i.side === "A",
					accent: J.accent,
					label: n("games.harmonies.sideA"),
					onChange: () => t({
						...i,
						side: "A"
					})
				}),
				/* @__PURE__ */ w(fe, {
					name: "harmonies-side",
					value: "B",
					checked: i.side === "B",
					accent: J.accent,
					label: n("games.harmonies.sideB"),
					onChange: () => t({
						...i,
						side: "B"
					})
				}),
				/* @__PURE__ */ w(fe, {
					name: "harmonies-side",
					value: "C",
					checked: i.side === "C",
					accent: J.accent,
					label: n("games.harmonies.sideC"),
					onChange: () => t({
						...i,
						side: "C"
					})
				}),
				/* @__PURE__ */ w(fe, {
					name: "harmonies-side",
					value: "D",
					checked: i.side === "D",
					accent: J.accent,
					label: n("games.harmonies.sideD"),
					onChange: () => t({
						...i,
						side: "D"
					})
				})
			]
		}),
		/* @__PURE__ */ T(D, {
			title: n("games.harmonies.crescendo"),
			children: [/* @__PURE__ */ w(de, {
				name: "harmonies-sanctuaries",
				value: "sanctuaries",
				checked: i.sanctuaries,
				label: n("games.harmonies.sanctuaries"),
				hint: n("games.harmonies.sanctuariesHint"),
				onChange: () => t({
					...i,
					sanctuaries: !i.sanctuaries
				})
			}), /* @__PURE__ */ w(de, {
				name: "harmonies-whispers",
				value: "whispers",
				checked: i.whispers,
				label: n("games.harmonies.whispers"),
				hint: n("games.harmonies.whispersHint"),
				onChange: () => t({
					...i,
					whispers: !i.whispers
				})
			})]
		}),
		/* @__PURE__ */ T(D, {
			title: n("games.harmonies.options"),
			children: [/* @__PURE__ */ w(de, {
				name: "harmonies-pulse",
				value: "pulse",
				checked: i.pulse,
				label: n("games.harmonies.pulse"),
				hint: n("games.harmonies.pulseHint"),
				onChange: () => t({
					...i,
					pulse: !i.pulse
				})
			}), /* @__PURE__ */ w(de, {
				name: "harmonies-spirits",
				value: "spirits",
				checked: i.spirits,
				label: n("games.harmonies.spirits"),
				hint: n("games.harmonies.spiritsHint"),
				onChange: () => t({
					...i,
					spirits: !i.spirits
				})
			})]
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/harmonies/entry.tsx
var xn = {
	definition: rt,
	View: jt,
	bot: mn,
	describe: hn,
	fx: vn,
	OverView: yn,
	Options: bn,
	locales: {
		zh: {
			crescendo: "Crescendo 扩展",
			sideC: "C 面 · 多彩建筑",
			sideD: "D 面 · 灌溉",
			sanctuaries: "保护区",
			sanctuariesHint: "建造特殊堆叠，接纳动物并获得邻接分数。",
			whispers: "精灵",
			whispersHint: "加入十张精灵牌；精灵与动物共存时获得更多分数。",
			sanctuaryWaterfall: "瀑布保护区",
			sanctuaryCanyon: "峡谷保护区",
			sanctuaryCity: "城市保护区",
			sanctuaryWindmill: "风车保护区",
			sanctuaryTerraces: "梯田保护区",
			sanctuaryTree: "巨树保护区",
			sanctuarySprings: "温泉保护区",
			sanctuaryTreehouse: "树屋保护区",
			sanctuarySeahouse: "海上屋保护区",
			sanctuaryRainforest: "雨林保护区",
			whisperCrystal: "晶林精灵",
			whisperStars: "星湖精灵",
			whisperWinter: "冬林精灵",
			whisperSteps: "石阶精灵",
			whisperSunset: "落日精灵",
			whisperPond: "池畔精灵",
			whisperReef: "珊瑚精灵",
			whisperGrove: "竹林精灵",
			whisperMeadow: "花海精灵",
			whisperFalls: "溪瀑精灵",
			takeSanctuary: "领取保护区",
			buildSanctuary: "建造这个保护区",
			buildingSanctuary: "建造{{name}}",
			stopBuilding: "取消建造选择",
			sanctuaryProgress: "建造中",
			sanctuaryComplete: "已建成",
			sanctuaryStack: "按从底到顶的顺序叠放；首次特殊叠放后，只能在该格继续建造。",
			sanctuaryColors: "每个相邻格的顶片为以下颜色之一时，获得 3 分。",
			shelterAnimal: "将最后一枚动物方块安置到保护区",
			shelterConfirm: "安置到保护区",
			shelterCount: "已有 {{n}} 个动物方块",
			sanctuaryDeck: "保护区牌堆顶",
			whisperScoring: "精灵单独占据一格时获得 2 分，与动物或自然之灵共存时获得 5 分。",
			whisperConfirm: "安置精灵",
			whisperPresent: "已有精灵",
			drySpace: "干旱格",
			ordinarySpace: "普通格",
			taskMarket: "公共卡牌与保护区",
			logTakeSanctuary: "{{name}}领取{{sanctuary}}。",
			logCompleteSanctuary: "{{name}}建成{{sanctuary}}。",
			logShelterAnimal: "{{name}}将{{animal}}的最后一枚方块安置到{{sanctuary}}。",
			hintTakeSanctuary: "领取{{name}}。",
			hintShelterAnimal: "将{{animal}}的最后一枚方块安置到{{sanctuary}}。",
			name: "自然和弦",
			desc: "叠起自然景观，构筑动物栖息地；含律动、Crescendo 扩展与单人挑战。",
			rules: "目标：\n· 放置地形木片，构筑栖息地，以景观、动物与自然之灵得分。\n准备：\n· 每人使用相同一面的版图：A、B 面各 23 格，C 面 26 格，D 面 25 格。多人供给为五组木片、五张动物牌；单人为三组、三张。\n· 木片共 120 枚：灰、蓝各 23，棕 21，绿、黄各 19，红 15。\n· 律动扩展加入 10 张动物牌，并允许镜像栖息地图案。\n· 启用自然之灵时，首回合从私下获得的两张牌中选择一张。\n流程：\n· 每回合必须选择一组三枚木片，并将三枚全部放到自己的版图上。\n· 木片可放空格；叠放仅限山峰、树木或建筑，不得插入已有木片下方。\n· 山峰最多三枚灰色木片；树木为一枚绿色木片，下方可有零至两枚棕色木片。\n· 建筑为一枚红色木片叠在一枚灰、棕或红色木片上。水域和田野不叠放。\n· 有动物、自然之灵或精灵方块的格子不能继续叠放木片。\n· 每回合可领取一张公共动物牌；尚未完成的动物牌、自然之灵牌、精灵牌和保护区合计最多四张。\n· 栖息地符合牌面时，可将牌上一个方块放在图案指定、尚无方块的木片上。\n· 图案可旋转；木片颜色和层数必须相符，建筑底层颜色不限。\n· 动物可在放木片前、两次放片之间或放完后安置，次数不限。\n· 同一木片可参与多个栖息地；动物放置后保留，即使周围地形改变。\n· 放完一张牌的全部方块后，该牌不再占用四张牌的额度。\n· 回合结束时才补充木片和动物牌。\n计分：\n· 高度一、二、三的树木分别为 1、3、7 分。\n· 山峰同样按高度计分，但必须与另一座山峰相邻。\n· 每片至少两格相连的田野计 5 分；整片田野只计一次。\n· 建筑周围顶层木片有至少三种颜色时计 5 分。\n· A 面只计最佳河流；两端间最短路径含一至六枚时计 0、2、5、8、11、15 分。\n· 河流超过六枚后，每多一枚计 4 分；支流不重复计入，环按最短路径判断。\n· B 面每座岛屿计 5 分，空格也属于陆地；至少计一座岛屿。\n· 动物牌按已移走方块对应的最高分计分；未放出方块为零分。\n· 自然之灵方块已放置时，按终局景观追加该牌奖励。\n保护区模块：\n· 每回合可额外领取一个保护区，独立于领取动物或精灵牌的机会。公共区可选牌堆顶与旁边两个保护区；取堆顶立即露出新顶，取旁边的回合末补充。\n· 选择保护区后，按牌面从底到顶建造指定的四层堆叠。首次违反普通叠放规则时，该保护区才绑定该格；之后只能在该格继续，不可另建一处。此前的合法前缀不绑定。\n· 建成后翻面，不再占用四张额度。可以建造多个保护区；未建成不扣分。\n· 普通动物牌恰余最后一个方块，且该牌的动物落点颜色为保护区关联色之一时，可忽略栖息地图案，将该方块放入已建成保护区。每个保护区可接纳任意数量的动物。自然之灵和精灵不能进入保护区。\n· 每个已建成保护区的相邻格顶片若为其关联的两色之一，获得 3 分。建造中及已建成的保护区均不作为普通景观计分，但建筑和保护区计算相邻颜色时仍查看它的顶片。\n新个人版图：\n· C 面中央没有格子，不可放置；建筑周围至少四种顶片颜色时获得 8 分。其他景观沿用 A 面规则。\n· D 面有七个初始普通格，其余为干旱格。干旱格与水域相邻时成为普通格，按终局当前局面判断。\n· D 面普通格上高度一、二、三的树木分别获得 2、4、9 分；干旱格上的树木为零分。至少两格相连的田野中有至少一个普通格时，整片获得 6 分，否则零分。其他景观沿用 A 面规则。\n精灵模块：\n· 将十张精灵牌混入动物牌堆。每张有两个紫色方块；领取精灵牌占用本回合领取动物牌的机会，也计入四张额度。\n· 按牌面图案放置紫色方块，每格至多一个。精灵可与一个动物或自然之灵方块共存，放置顺序不限，但不可放入保护区。紫色方块也禁止该格继续叠片。\n· 精灵单独占据一格时获得 2 分，共存时该格获得 5 分；按棋盘现状逐格计分，牌面 2／5 是两种状态的分值。紫色方块不计入同分时的动物数量。\n· 三个 Crescendo 模块可分别启用或组合，也可与律动和自然之灵搭配。\n结束：\n· 回合结束时版图空格不超过两格，或需要补货时袋中木片不足，即触发最终轮。\n· 完成当前轮，使所有玩家回合数相同，再比较总分。\n· 同分时，动物方块较多者获胜；仍相同则共享胜利。\n单人：\n· 每回合结束弃置供给中剩余六枚木片，再补充三组木片。\n· 本回合未领取动物牌时，可在结束回合时替换一张公共动物牌。\n· 总分达到 40、70、90、110、130、140、150、160 时分别获得一至八枚太阳。\n· A 面额外一枚太阳；未用自然之灵额外两枚，按连通区域奖励的自然之灵额外一枚。",
			options: "游戏组件",
			side: "版图",
			sideA: "A 面 · 河流",
			sideB: "B 面 · 岛屿",
			pulse: "律动扩展",
			pulseHint: "加入十张动物牌，并允许镜像图案。",
			spirits: "自然之灵",
			spiritsHint: "每人首回合从两张自然之灵牌中选择一张。",
			gray: "灰色木片",
			blue: "蓝色木片",
			brown: "棕色木片",
			green: "绿色木片",
			yellow: "黄色木片",
			red: "红色木片",
			trees: "树木",
			mountains: "山峰",
			fields: "田野",
			buildings: "建筑",
			water: "水域",
			animals: "动物",
			spiritScore: "自然之灵",
			total: "总分",
			landscape: "{{name}}的景观",
			supply: "公共供给",
			market: "公共卡牌",
			myCards: "我的卡牌",
			cardsOf: "{{name}}的卡牌",
			completed: "已完成 {{n}} 张",
			completedCards: "已完成的卡牌",
			round: "第 {{n}} 轮",
			yourTurn: "轮到你",
			waiting: "等待{{name}}",
			finalRound: "最终轮",
			bagLeft: "袋中 {{n}} 枚",
			points: "{{n}} 分",
			draftPrompt: "选择一组地形木片",
			placePrompt: "选择木片和放置位置",
			optionalPrompt: "可安置动物，或结束回合",
			draftConfirm: "拿取这一组",
			placeConfirm: "确认放置",
			animalConfirm: "安置动物",
			spiritConfirm: "安置自然之灵",
			endTurn: "结束回合",
			takeCard: "领取这张牌",
			findHabitat: "寻找栖息地",
			viewCard: "查看{{name}}",
			chooseSpirit: "选择自然之灵",
			chooseThisSpirit: "选择这张自然之灵牌",
			held: "待放地形",
			remaining: "剩余 {{n}} 枚",
			selectedCell: "选中格",
			emptyCell: "空格",
			layers: "{{n}} 层",
			preview: "放置后",
			stack: "完整堆叠",
			stackOrder: "从底到顶",
			animalPresent: "已有动物",
			spiritPresent: "已有自然之灵",
			cellLabel: "第 {{n}} 格，{{stack}}",
			resetCamera: "视角归位",
			boardLabel: "景观版图",
			noHabitat: "没有符合的栖息地",
			matchCount: "{{n}} 处栖息地",
			nextMatch: "切换匹配图案",
			rotate: "旋转图案",
			mirror: "镜像图案",
			target: "方块落点",
			cardProgress: "已安置 {{placed}}，共 {{n}} 个",
			scoreTrack: "得分轨道",
			incomplete: "未完成 {{n}} / 4",
			noCards: "尚未领取动物牌",
			completedTag: "已完成",
			expansionTag: "律动",
			spiritTag: "自然之灵",
			replaceCard: "结束回合并替换",
			replaceChoice: "替换公共动物牌",
			noReplace: "保留公共动物牌",
			soloReplaceHint: "本回合未领取动物牌，可替换一张。",
			riverLength: "河流长度 {{n}}",
			islands: "{{n}} 座岛屿",
			suns: "{{n}} 枚太阳",
			animalCubes: "{{n}} 个动物方块",
			scoring: "得分明细",
			invalid: "当前不能执行这项操作。",
			notYourTurn: "尚未轮到你。",
			chooseSpiritFirst: "请先选择自然之灵。",
			cardLimit: "尚未完成的卡牌与保护区合计已达四张。",
			placeAll: "请先拿取并放完三枚木片。",
			hintDraft: "拿取第 {{n}} 组地形木片。",
			hintPlace: "将{{terrain}}放到第 {{n}} 格。",
			hintAnimal: "将{{animal}}安置在第 {{n}} 格。",
			hintTake: "领取{{animal}}。",
			logDraft: "{{name}}拿取第 {{n}} 组木片。",
			logPlace: "{{name}}放置{{terrain}}。",
			logTake: "{{name}}领取{{animal}}。",
			logAnimal: "{{name}}安置{{animal}}。",
			logSpirit: "{{name}}选择{{animal}}。",
			logEnd: "{{name}}结束回合。",
			llama: "羊驼",
			meerkat: "狐獴",
			vulture: "胡兀鹫",
			bat: "蝙蝠",
			fennec: "耳廓狐",
			polarBear: "北极熊",
			penguin: "企鹅",
			lizard: "蜥蜴",
			flamingo: "火烈鸟",
			shrew: "鼩鼱",
			peacock: "孔雀",
			heron: "苍鹭",
			duck: "鸭",
			otter: "水獭",
			giraffe: "长颈鹿",
			kingfisher: "翠鸟",
			crocodile: "鳄鱼",
			salamander: "蝾螈",
			squirrel: "松鼠",
			koala: "考拉",
			wolf: "狼",
			boar: "野猪",
			hummingbird: "蜂鸟",
			bee: "蜜蜂",
			hedgehog: "刺猬",
			bear: "棕熊",
			deer: "鹿",
			ladybug: "瓢虫",
			swan: "天鹅",
			lemur: "狐猴",
			panther: "黑豹",
			stork: "白鹳",
			fish: "热带鱼",
			axolotl: "美西螈",
			songbird: "雀鸟",
			pelican: "鹈鹕",
			tiger: "老虎",
			chameleon: "变色龙",
			camel: "骆驼",
			yak: "牦牛",
			panda: "大熊猫",
			beetle: "甲虫",
			spiritDeer: "鹿之灵",
			spiritCrane: "鹤之灵",
			spiritOwl: "猫头鹰之灵",
			spiritCat: "猫之灵",
			spiritBear: "熊之灵",
			spiritDragonfly: "蜻蜓之灵",
			spiritIbex: "岩羊之灵",
			spiritTortoise: "象龟之灵",
			spiritButterfly: "蝴蝶之灵",
			spiritLion: "狮子之灵",
			ruleDeer: "每棵高度为二或三的树木额外获得 4 分。",
			ruleCrane: "每组至少两座相连的建筑额外获得 6 分。",
			ruleOwl: "高度为一或二的树木各额外获得 3 分，高度为三的各获得 1 分。",
			ruleCat: "每座不与其他建筑相邻的建筑额外获得 4 分。",
			ruleBear: "高度为一或二的山峰各额外获得 3 分，高度为三的各获得 1 分；孤立山峰也计入。",
			ruleDragonfly: "每片至少两格相连的水域额外获得 7 分。",
			ruleIbex: "每座高度为二或三的山峰额外获得 4 分；孤立山峰也计入。",
			ruleTortoise: "每枚蓝色木片额外获得 2 分。",
			ruleButterfly: "每片相连的田野额外获得 5 分；单独一格也计入。",
			ruleLion: "每片一或两格的田野额外获得 2 分，至少三格的田野各获得 10 分。"
		},
		en: {
			crescendo: "Crescendo expansion",
			sideC: "Side C · Diverse buildings",
			sideD: "Side D · Irrigation",
			sanctuaries: "Sanctuaries",
			sanctuariesHint: "Build special stacks, shelter animals and score adjacent colors.",
			whispers: "Whispers",
			whispersHint: "Add ten Whisper cards; sharing spaces with animals scores more.",
			sanctuaryWaterfall: "Waterfall sanctuary",
			sanctuaryCanyon: "Canyon sanctuary",
			sanctuaryCity: "City sanctuary",
			sanctuaryWindmill: "Windmill sanctuary",
			sanctuaryTerraces: "Terrace sanctuary",
			sanctuaryTree: "Great tree sanctuary",
			sanctuarySprings: "Hot spring sanctuary",
			sanctuaryTreehouse: "Treehouse sanctuary",
			sanctuarySeahouse: "Seahouse sanctuary",
			sanctuaryRainforest: "Rainforest sanctuary",
			whisperCrystal: "Crystal whisper",
			whisperStars: "Starlake whisper",
			whisperWinter: "Winter whisper",
			whisperSteps: "Stairway whisper",
			whisperSunset: "Sunset whisper",
			whisperPond: "Pond whisper",
			whisperReef: "Reef whisper",
			whisperGrove: "Grove whisper",
			whisperMeadow: "Meadow whisper",
			whisperFalls: "Waterfall whisper",
			takeSanctuary: "Take sanctuary",
			buildSanctuary: "Build this sanctuary",
			buildingSanctuary: "Building {{name}}",
			stopBuilding: "Cancel build selection",
			sanctuaryProgress: "In progress",
			sanctuaryComplete: "Completed",
			sanctuaryStack: "Stack from bottom to top. The first special placement binds this sanctuary to that space.",
			sanctuaryColors: "Score 3 per adjacent space whose top token matches either color below.",
			shelterAnimal: "Shelter the final animal cube",
			shelterConfirm: "Place in sanctuary",
			shelterCount: "{{n}} animal cubes here",
			sanctuaryDeck: "Top of sanctuary deck",
			whisperScoring: "A space with a lone Whisper scores 2; sharing with an animal or Nature’s Spirit scores 5.",
			whisperConfirm: "Settle whisper",
			whisperPresent: "Whisper present",
			drySpace: "Dry space",
			ordinarySpace: "Ordinary space",
			taskMarket: "Cards and sanctuaries",
			logTakeSanctuary: "{{name}} takes {{sanctuary}}.",
			logCompleteSanctuary: "{{name}} completes {{sanctuary}}.",
			logShelterAnimal: "{{name}} places the final {{animal}} cube in {{sanctuary}}.",
			hintTakeSanctuary: "Take {{name}}.",
			hintShelterAnimal: "Place the final {{animal}} cube in {{sanctuary}}.",
			name: "Harmonies",
			desc: "Build natural landscapes and animal habitats, with Pulse, Crescendo and solo play.",
			rules: "Goal:\n· Build habitats with landscape tokens and score landscapes, animals and Nature’s Spirits.\nSetup:\n· Use the same board side: A and B have 23 spaces, C has 26 and D has 25. Display five token groups and cards, or three of each solo.\n· There are 120 tokens: 23 gray, 23 blue, 21 brown, 19 green, 19 yellow and 15 red.\n· Pulse adds 10 animal cards and allows reflected habitat patterns.\n· With Nature’s Spirits, privately choose one of two cards on your first turn.\nPlay:\n· Each turn, take one group of three tokens and place all three on your board.\n· Place tokens on empty spaces or form legal mountains, trees or buildings; never insert tokens underneath.\n· Mountains contain up to three gray tokens; trees have one green token above zero, one or two brown tokens.\n· Buildings have a red token above one gray, brown or red token. Water and fields cannot be stacked.\n· Never add tokens to a space occupied by an animal, Nature’s Spirit or Whisper cube.\n· You may take one animal card per turn; hold no more than four incomplete Animal, Nature’s Spirit and Whisper cards and Sanctuary tiles combined.\n· When a habitat matches, move a cube from its card onto the indicated, unoccupied token.\n· Rotate patterns freely; colors and heights must match. A building’s bottom token may be any legal color.\n· Settle animals before, between or after placing tokens, as often as you wish.\n· Tokens may serve several habitats. Settled animals remain even if surrounding landscapes change.\n· A card no longer occupies an active-card slot when all its cubes have been placed.\n· Refill token groups and animal cards only at the end of the turn.\nScoring:\n· Trees of heights one, two and three score 1, 3 and 7 points.\n· Mountains score the same, but must be adjacent to another mountain.\n· Each connected field of at least two yellow tokens scores 5 points, once for the whole field.\n· Each building scores 5 points if adjacent top tokens include at least three different colors.\n· Side A scores your best river: shortest paths of one to six tokens score 0, 2, 5, 8, 11 and 15.\n· Beyond six tokens, score 4 per extra token. Do not double-count branches; use shortest paths in loops.\n· Side B scores 5 per island. Empty spaces are land; count at least one island.\n· Animal cards score their highest uncovered value; cards with no placed cubes score zero.\n· A settled Nature’s Spirit adds its bonus based on the final landscape.\nSanctuaries module:\n· Each turn, you may also take one Sanctuary, independently of taking an Animal or Whisper card. Choose the deck’s top tile or one of the two beside it. Taking the top reveals a new top immediately; refill a side position at turn end.\n· Select a Sanctuary and build its four-token stack from bottom to top. The first placement that breaks ordinary stacking rules binds it to that space; continue only there. A legal prefix does not bind it.\n· Flip a completed Sanctuary; it no longer occupies an active slot. You may complete several. Incomplete Sanctuaries have no penalty.\n· When exactly one cube remains on an Animal card and its target-token color matches either Sanctuary color, place it in a completed Sanctuary without matching the habitat. Each Sanctuary holds any number of animals. Nature’s Spirits and Whispers cannot enter.\n· A completed Sanctuary scores 3 per adjacent space whose top token matches either associated color. Neither incomplete nor completed Sanctuaries count as ordinary landscape elements. Buildings and Sanctuaries still consider their top colors when scoring adjacent colors.\nNew personal boards:\n· Side C has no central space. Buildings score 8 only with at least four adjacent top-token colors. Other landscapes follow side A.\n· Side D has seven initially ordinary spaces; the rest are dry. A dry space becomes ordinary when adjacent to Water, according to the final landscape.\n· Side D trees on ordinary spaces score 2, 4 and 9 at heights one, two and three; dry trees score zero. Each field of at least two connected yellow spaces scores 6 if at least one is ordinary, otherwise zero. Other landscapes follow side A.\nWhispers module:\n· Shuffle ten Whisper cards into the Animal deck. Each holds two purple cubes. Taking one uses your Animal-card action for the turn and an active slot.\n· Match the card’s habitat to place a purple cube. Each space holds at most one Whisper, which may coexist with one Animal or Nature’s Spirit cube in either order. Whispers cannot enter Sanctuaries, and also prevent further stacking.\n· Each space with a lone Whisper scores 2; each shared space scores 5. Score the current board, not a cumulative card track. The 2/5 legend depicts these two states. Purple cubes do not count toward the animal tiebreaker.\n· All three Crescendo modules can be used separately or together, including with Pulse and Nature’s Spirits.\nEnding:\n· Trigger the final round with at most two empty board spaces, or insufficient tokens when refilling.\n· Finish the round so everyone has played equally, then compare total scores.\n· Ties favor the player with more animal cubes. Further ties share victory.\nSolo:\n· Discard the six unchosen supply tokens at turn end, then refill all three groups.\n· If you took no animal card this turn, you may replace one public animal card at turn end.\n· Scores of 40, 70, 90, 110, 130, 140, 150 and 160 earn one through eight suns.\n· Add one sun for side A; add two without a spirit, or one for a spirit rewarding connected groups.",
			options: "Components",
			side: "Board",
			sideA: "Side A · Rivers",
			sideB: "Side B · Islands",
			pulse: "Pulse expansion",
			pulseHint: "Add ten animal cards and reflected patterns.",
			spirits: "Nature’s Spirits",
			spiritsHint: "Choose one of two spirit cards on your first turn.",
			gray: "gray token",
			blue: "blue token",
			brown: "brown token",
			green: "green token",
			yellow: "yellow token",
			red: "red token",
			trees: "Trees",
			mountains: "Mountains",
			fields: "Fields",
			buildings: "Buildings",
			water: "Water",
			animals: "Animals",
			spiritScore: "Nature’s Spirit",
			total: "Total",
			landscape: "{{name}}’s landscape",
			supply: "Token supply",
			market: "Card market",
			myCards: "My cards",
			cardsOf: "{{name}}’s cards",
			completed: "{{n}} completed",
			completedCards: "Completed cards",
			round: "Round {{n}}",
			yourTurn: "Your turn",
			waiting: "Waiting for {{name}}",
			finalRound: "Final round",
			bagLeft: "{{n}} in bag",
			points: "{{n}} pts",
			draftPrompt: "Choose a group of tokens",
			placePrompt: "Choose a token and space",
			optionalPrompt: "Settle animals or end your turn",
			draftConfirm: "Take this group",
			placeConfirm: "Place token",
			animalConfirm: "Settle animal",
			spiritConfirm: "Settle spirit",
			endTurn: "End turn",
			takeCard: "Take this card",
			findHabitat: "Find habitats",
			viewCard: "View {{name}}",
			chooseSpirit: "Choose a Nature’s Spirit",
			chooseThisSpirit: "Choose this spirit",
			held: "Tokens to place",
			remaining: "{{n}} left",
			selectedCell: "Selected space",
			emptyCell: "Empty space",
			layers: "{{n}} layers",
			preview: "After placing",
			stack: "Full stack",
			stackOrder: "Bottom to top",
			animalPresent: "Animal present",
			spiritPresent: "Spirit present",
			cellLabel: "Space {{n}}, {{stack}}",
			resetCamera: "Reset view",
			boardLabel: "Landscape board",
			noHabitat: "No matching habitat",
			matchCount: "{{n}} habitats",
			nextMatch: "Next matching pattern",
			rotate: "Rotate pattern",
			mirror: "Reflect pattern",
			target: "Cube’s space",
			cardProgress: "{{placed}} of {{n}} settled",
			scoreTrack: "Scoring track",
			incomplete: "{{n}} / 4 active",
			noCards: "No animal cards yet",
			completedTag: "Completed",
			expansionTag: "Pulse",
			spiritTag: "Nature’s Spirit",
			replaceCard: "End turn & replace",
			replaceChoice: "Replace an animal card",
			noReplace: "Keep the market",
			soloReplaceHint: "You took no animal card, so you may replace one.",
			riverLength: "River length {{n}}",
			islands: "{{n}} islands",
			suns: "{{n}} suns",
			animalCubes: "{{n}} animal cubes",
			scoring: "Score details",
			invalid: "That action is not available.",
			notYourTurn: "It is not your turn.",
			chooseSpiritFirst: "Choose your Nature’s Spirit first.",
			cardLimit: "You already have four incomplete cards and Sanctuary tiles combined.",
			placeAll: "Take and place all three tokens first.",
			hintDraft: "Take token group {{n}}.",
			hintPlace: "Place a {{terrain}} on space {{n}}.",
			hintAnimal: "Settle {{animal}} on space {{n}}.",
			hintTake: "Take {{animal}}.",
			logDraft: "{{name}} took token group {{n}}.",
			logPlace: "{{name}} placed a {{terrain}}.",
			logTake: "{{name}} took {{animal}}.",
			logAnimal: "{{name}} settled {{animal}}.",
			logSpirit: "{{name}} chose {{animal}}.",
			logEnd: "{{name}} ended their turn.",
			llama: "Llama",
			meerkat: "Meerkat",
			vulture: "Bearded vulture",
			bat: "Bat",
			fennec: "Fennec fox",
			polarBear: "Polar bear",
			penguin: "Penguin",
			lizard: "Lizard",
			flamingo: "Flamingo",
			shrew: "Shrew",
			peacock: "Peacock",
			heron: "Heron",
			duck: "Duck",
			otter: "Otter",
			giraffe: "Giraffe",
			kingfisher: "Kingfisher",
			crocodile: "Crocodile",
			salamander: "Salamander",
			squirrel: "Squirrel",
			koala: "Koala",
			wolf: "Wolf",
			boar: "Wild boar",
			hummingbird: "Hummingbird",
			bee: "Bee",
			hedgehog: "Hedgehog",
			bear: "Brown bear",
			deer: "Deer",
			ladybug: "Ladybug",
			swan: "Swan",
			lemur: "Lemur",
			panther: "Panther",
			stork: "Stork",
			fish: "Tropical fish",
			axolotl: "Axolotl",
			songbird: "Songbird",
			pelican: "Pelican",
			tiger: "Tiger",
			chameleon: "Chameleon",
			camel: "Camel",
			yak: "Yak",
			panda: "Giant panda",
			beetle: "Beetle",
			spiritDeer: "Deer Spirit",
			spiritCrane: "Crane Spirit",
			spiritOwl: "Owl Spirit",
			spiritCat: "Cat Spirit",
			spiritBear: "Bear Spirit",
			spiritDragonfly: "Dragonfly Spirit",
			spiritIbex: "Ibex Spirit",
			spiritTortoise: "Tortoise Spirit",
			spiritButterfly: "Butterfly Spirit",
			spiritLion: "Lion Spirit",
			ruleDeer: "Add 4 points per tree of height two or three.",
			ruleCrane: "Add 6 points per connected group of at least two buildings.",
			ruleOwl: "Add 3 points per tree of height one or two, and 1 per tree of height three.",
			ruleCat: "Add 4 points per building with no adjacent building.",
			ruleBear: "Add 3 points per mountain of height one or two, and 1 per height three, including isolated mountains.",
			ruleDragonfly: "Add 7 points per connected water group of at least two tokens.",
			ruleIbex: "Add 4 points per mountain of height two or three, including isolated mountains.",
			ruleTortoise: "Add 2 points per blue token.",
			ruleButterfly: "Add 5 points per connected yellow group, including isolated tokens.",
			ruleLion: "Add 2 points per yellow group of one or two tokens, or 10 per group of three or more."
		}
	}
};
//#endregion
export { xn as default };
