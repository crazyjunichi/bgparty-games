import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useLayoutEffect as r, useMemo as i, useRef as a, useState as o, useSyncExternalStore as s } from "react";
import { useT as c } from "@bgparty/sdk/i18n";
import { BottomSheet as l } from "@bgparty/sdk/bottom-sheet";
import { IconCheck as u, IconInfo as d, IconLog as f, IconMirror as p, IconRecenter as m, IconRotate as h } from "@bgparty/sdk/icons";
import { Texture as g } from "@bgparty/sdk/texture";
import { useWakeLock as _ } from "@bgparty/sdk/use-wake-lock";
import { playSettle as v, playTurn as ee, useSoundEdge as te } from "@bgparty/sdk/sfx";
import { useFxAnchor as ne, useFxAnchorsMaybe as re } from "@bgparty/sdk/fx/anchors";
import { GameScreen as ie } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as ae } from "@bgparty/sdk/ui/player-strip";
import { LogSheet as oe } from "@bgparty/sdk/ui/log-sheet";
import { useThree as se } from "@react-three/fiber";
import { BufferGeometry as ce, DoubleSide as y, Float32BufferAttribute as le, OrthographicCamera as b, Vector3 as x } from "three";
import { ResilientCanvas as S } from "@bgparty/sdk/three/resilient-canvas";
import { Fragment as C, jsx as w, jsxs as T } from "react/jsx-runtime";
import { FlySprite as E } from "@bgparty/sdk/fx/primitives";
import { Confetti as ue } from "@bgparty/sdk/ui/confetti";
import { OptionCheckbox as de, OptionRadio as D, OptionSection as fe } from "@bgparty/sdk/ui/game-options";
//#region src/games/harmonies/cards.ts
var pe = (e, t, n = 0, r = 0) => [
	e,
	t,
	n,
	r
], O = (e = 1, t = 0, n = 0) => pe("gray", e, t, n), k = (e = 1, t = 0, n = 0) => pe("green", e, t, n), A = (e = 0, t = 0) => pe("blue", 1, e, t), j = (e = 0, t = 0) => pe("yellow", 1, e, t), M = (e = 2, t = 0, n = 0) => pe("red", e, t, n);
function N(e, t, n, r, i, a, o) {
	return {
		id: e,
		nameKey: t,
		art: n,
		family: r,
		scores: i,
		pattern: a.map(([e, t, n, r]) => ({
			terrain: e,
			height: t,
			q: n,
			r
		})),
		...e >= 29900 ? { expansion: !0 } : {},
		...o ? { spirit: o } : {}
	};
}
var me = [
	N(29300, "games.harmonies.llama", "llama", "mammal", [5, 12], [
		j(),
		j(-1, 0),
		O(2, -2, 0)
	]),
	N(29301, "games.harmonies.meerkat", "meerkat", "mammal", [
		2,
		5,
		9,
		14
	], [O(), j(-1, 0)]),
	N(29302, "games.harmonies.vulture", "vulture", "bird", [5, 11], [O(3), j(-1, 0)]),
	N(29303, "games.harmonies.bat", "bat", "mammal", [
		3,
		6,
		10,
		15
	], [O(), k(3, -1, 0)]),
	N(29304, "games.harmonies.fennec", "fennec", "mammal", [
		4,
		9,
		16
	], [
		O(),
		O(1, -1, 0),
		j(-2, 0)
	]),
	N(29305, "games.harmonies.polarBear", "polarBear", "mammal", [5, 11], [
		O(2),
		A(-1, 0),
		A(-1, 1)
	]),
	N(29306, "games.harmonies.penguin", "penguin", "bird", [
		4,
		10,
		16
	], [
		O(2),
		A(-1, 1),
		A(1, 0)
	]),
	N(29307, "games.harmonies.lizard", "lizard", "reptile", [
		5,
		10,
		16
	], [
		M(),
		j(-1, 0),
		j(-2, 0)
	]),
	N(29308, "games.harmonies.flamingo", "flamingo", "bird", [
		4,
		10,
		16
	], [
		A(),
		j(-1, 0),
		j(-1, 1)
	]),
	N(29309, "games.harmonies.shrew", "shrew", "mammal", [
		5,
		10,
		17
	], [
		M(),
		j(-1, 1),
		j(1, 0)
	]),
	N(29310, "games.harmonies.peacock", "peacock", "bird", [
		5,
		10,
		17
	], [
		M(),
		A(-1, 1),
		A(1, 0)
	]),
	N(29311, "games.harmonies.heron", "heron", "bird", [
		3,
		6,
		10,
		16
	], [A(), O(3, -1, 0)]),
	N(29312, "games.harmonies.duck", "duck", "bird", [
		2,
		4,
		8,
		13
	], [A(), M(2, -1, 0)]),
	N(29313, "games.harmonies.otter", "otter", "mammal", [
		5,
		10,
		16
	], [
		A(),
		k(1, -1, 0),
		k(1, -2, 0)
	]),
	N(29314, "games.harmonies.giraffe", "giraffe", "mammal", [
		2,
		4,
		6,
		10,
		15
	], [A(), k(1, -1, 0)]),
	N(29315, "games.harmonies.kingfisher", "kingfisher", "bird", [
		5,
		11,
		18
	], [
		k(3),
		A(-1, 1),
		A(1, 0)
	]),
	N(29316, "games.harmonies.crocodile", "crocodile", "reptile", [
		4,
		9,
		15
	], [
		A(),
		A(-1, 0),
		k(3, -2, 0)
	]),
	N(29317, "games.harmonies.salamander", "salamander", "reptile", [
		4,
		10,
		16
	], [
		A(),
		O(1, -1, 0),
		O(1, -1, 1)
	]),
	N(29318, "games.harmonies.squirrel", "squirrel", "mammal", [
		4,
		9,
		15
	], [M(), k(3, -1, 0)]),
	N(29319, "games.harmonies.koala", "koala", "mammal", [
		3,
		6,
		10,
		15
	], [k(2), k(1, -1, 0)]),
	N(29320, "games.harmonies.wolf", "wolf", "mammal", [
		4,
		10,
		16
	], [
		k(2),
		j(-1, 0),
		j(-1, 1)
	]),
	N(29321, "games.harmonies.boar", "boar", "mammal", [
		4,
		8,
		13
	], [k(2), M(2, -1, 0)]),
	N(29322, "games.harmonies.hummingbird", "hummingbird", "bird", [
		4,
		9,
		14
	], [
		k(2),
		A(-1, 0),
		A(-1, 1)
	]),
	N(29323, "games.harmonies.bee", "bee", "insect", [8, 18], [
		k(2),
		j(-1, 1),
		j(0, 1),
		j(1, 0)
	]),
	N(29324, "games.harmonies.hedgehog", "hedgehog", "mammal", [5, 12], [
		M(),
		k(2, -1, 0),
		k(2, -1, 1)
	]),
	N(29325, "games.harmonies.bear", "bear", "mammal", [5, 11], [
		k(),
		O(3, -1, 0),
		O(2, -1, 1)
	]),
	N(29326, "games.harmonies.deer", "deer", "mammal", [
		5,
		10,
		17
	], [
		k(),
		k(1, -1, 0),
		M(2, -2, 0)
	]),
	N(29327, "games.harmonies.ladybug", "ladybug", "insect", [
		2,
		5,
		8,
		12,
		17
	], [j(), k(1, -1, 0)]),
	N(29328, "games.harmonies.swan", "swan", "bird", [
		5,
		10,
		17
	], [
		j(),
		k(2, -1, 1),
		k(2, 1, 0)
	]),
	N(29329, "games.harmonies.lemur", "lemur", "mammal", [6, 12], [
		j(),
		A(-1, 1),
		A(0, 1),
		A(1, 0)
	]),
	N(29330, "games.harmonies.panther", "panther", "mammal", [5, 11], [
		j(),
		k(2, -1, 0),
		k(2, -2, 0)
	]),
	N(29331, "games.harmonies.stork", "stork", "bird", [4, 9], [
		j(),
		M(2, -1, 1),
		M(2, 1, 0)
	]),
	N(29900, "games.harmonies.fish", "fish", "fish", [6, 13], [
		A(),
		k(3, -1, 0),
		j(-2, 1)
	]),
	N(29901, "games.harmonies.axolotl", "axolotl", "reptile", [7, 16], [
		A(),
		k(2, 0, -1),
		O(2, -1, 0)
	]),
	N(29902, "games.harmonies.songbird", "songbird", "bird", [
		4,
		10,
		17
	], [
		M(),
		k(1, -1, 0),
		O(1, -1, 1)
	]),
	N(29903, "games.harmonies.pelican", "pelican", "bird", [5, 11], [
		M(),
		j(-1, 0),
		A(-2, 1)
	]),
	N(29904, "games.harmonies.tiger", "tiger", "mammal", [
		3,
		10,
		16
	], [
		k(),
		O(2, -1, 0),
		A(-2, 1)
	]),
	N(29905, "games.harmonies.chameleon", "chameleon", "reptile", [
		4,
		8,
		15
	], [
		k(2),
		A(-1, 1),
		j(1, 0)
	]),
	N(29906, "games.harmonies.camel", "camel", "mammal", [
		4,
		9,
		16
	], [
		O(2),
		M(1, -1, 1),
		j(1, 0)
	]),
	N(29907, "games.harmonies.yak", "yak", "mammal", [7, 16], [
		O(2),
		A(-1, 0),
		j(1, 0)
	]),
	N(29908, "games.harmonies.panda", "panda", "mammal", [5, 13], [
		j(),
		k(3, -1, 0),
		O(1, -1, 1)
	]),
	N(29909, "games.harmonies.beetle", "beetle", "insect", [5, 12], [
		j(),
		M(2, -1, 0),
		O(1, 1, 0)
	])
], P = [
	N(29500, "games.harmonies.spiritDeer", "deer", "mammal", [0], [
		k(2),
		k(3, -1, 0),
		k(1, 1, 0)
	], "deer"),
	N(29501, "games.harmonies.spiritCrane", "stork", "bird", [0], [
		M(),
		M(1, -1, 0),
		j(-2, 0)
	], "crane"),
	N(29502, "games.harmonies.spiritOwl", "owl", "bird", [0], [
		k(3),
		k(1, -1, 0),
		k(1, -1, 1)
	], "owl"),
	N(29503, "games.harmonies.spiritCat", "cat", "mammal", [0], [
		M(),
		k(1, -1, 0),
		M(1, -2, 0)
	], "cat"),
	N(29504, "games.harmonies.spiritBear", "bear", "mammal", [0], [
		O(2),
		O(1, -1, 1),
		O(1, 1, 0)
	], "bear"),
	N(29505, "games.harmonies.spiritDragonfly", "dragonfly", "insect", [0], [
		A(),
		k(2, -1, 0),
		k(2, 1, 0)
	], "dragonfly"),
	N(29506, "games.harmonies.spiritIbex", "ibex", "mammal", [0], [O(3), O(2, -1, 0)], "ibex"),
	N(29507, "games.harmonies.spiritTortoise", "tortoise", "reptile", [0], [
		A(),
		O(2, -1, 0),
		A(1, 0)
	], "tortoise"),
	N(29508, "games.harmonies.spiritButterfly", "butterfly", "insect", [0], [
		j(),
		A(-1, 0),
		A(-1, 1),
		j(-2, 1)
	], "butterfly"),
	N(29509, "games.harmonies.spiritLion", "lion", "mammal", [0], [
		j(),
		k(2, -1, 0),
		j(1, 0)
	], "lion")
], F = Object.fromEntries([...me, ...P].map((e) => [e.id, e])), he = {
	deer: "games.harmonies.ruleDeer",
	crane: "games.harmonies.ruleCrane",
	owl: "games.harmonies.ruleOwl",
	cat: "games.harmonies.ruleCat",
	bear: "games.harmonies.ruleBear",
	dragonfly: "games.harmonies.ruleDragonfly",
	ibex: "games.harmonies.ruleIbex",
	tortoise: "games.harmonies.ruleTortoise",
	butterfly: "games.harmonies.ruleButterfly",
	lion: "games.harmonies.ruleLion"
}, ge = {
	azimuth: .18,
	elevation: .88
}, I = .34, L = .16, R = {
	gray: {
		top: "#8b9697",
		side: "#596568",
		print: "#e6e4d7"
	},
	blue: {
		top: "#3f9eaf",
		side: "#267387",
		print: "#bde5de"
	},
	brown: {
		top: "#a66c47",
		side: "#734b36",
		print: "#d8a678"
	},
	green: {
		top: "#899c42",
		side: "#596d34",
		print: "#e1e7a0"
	},
	yellow: {
		top: "#e9af44",
		side: "#bb7e29",
		print: "#fff0b1"
	},
	red: {
		top: "#c26050",
		side: "#94483e",
		print: "#f8bd96"
	}
}, z = Array.from({ length: 5 }, (e, t) => Array.from({ length: t % 2 ? 4 : 5 }, (e, n) => ({
	key: `${t - 2},${n - Math.floor(t / 2) - 1}`,
	q: t - 2,
	r: n - Math.floor(t / 2) - 1
}))).flat();
function _e(e, t) {
	return [e * 1.5, Math.sqrt(3) * (t + e / 2)];
}
function ve(e, t) {
	let [n, r, i] = e, a = n * Math.sin(t.azimuth) + i * Math.cos(t.azimuth);
	return [
		n * Math.cos(t.azimuth) - i * Math.sin(t.azimuth),
		a * Math.sin(t.elevation) - r * Math.cos(t.elevation),
		a * Math.cos(t.elevation) + r * Math.sin(t.elevation)
	];
}
function B(e, t, n, r, i, a = 0) {
	return Array.from({ length: i }, (o, s) => {
		let c = s * Math.PI * 2 / i + a;
		return [
			e + r * Math.cos(c),
			t,
			n + r * Math.sin(c)
		];
	});
}
function V(e, t, n, r, i, a) {
	for (let i = 0; i < t.length; i++) {
		let o = (i + 1) % t.length;
		e.push({
			points: [
				t[i],
				t[o],
				n[o],
				n[i]
			],
			color: r,
			opacity: a
		});
	}
	e.push({
		points: n,
		color: i,
		opacity: a
	});
}
function ye(e, t, n, r, i, a, o, s, c) {
	V(e, B(t, n, r, i, 24), B(t, n + a * .86, r, i, 24), s, o, c), V(e, B(t, n + a * .86, r, i, 24), B(t, n + a, r, i * .94, 24), o, o, c);
}
function be(e, t, n, r, i) {
	let a = e.length, o = R[i].print, s = (i) => e.push({
		points: i.map(([e, i]) => [
			t + e,
			n,
			r + i
		]),
		color: o
	});
	if (i === "green") for (let [e, t] of [
		[-.18, -.1],
		[.14, -.2],
		[.16, .15]
	]) s([
		[e - .14, t],
		[e - .07, t - .16],
		[e + .1, t - .1],
		[e + .14, t + .04],
		[e, t + .12]
	]);
	else if (i === "gray") s([
		[-.36, .16],
		[-.12, -.22],
		[.08, .08],
		[.21, -.1],
		[.38, .19]
	]);
	else if (i === "blue") for (let e of [
		-.18,
		.02,
		.22
	]) s([
		[-.4, e],
		[-.16, e - .08],
		[.1, e + .02],
		[.38, e - .04],
		[.4, e + .02],
		[.1, e + .09],
		[-.16, e - .01],
		[-.38, e + .07]
	]);
	else if (i === "yellow") for (let [i, a] of [
		[0, 0],
		[-.23, -.14],
		[.23, -.14],
		[0, .25]
	]) e.push({
		points: B(t + i, n, r + a, .11, 6),
		color: o
	});
	else if (i === "red") {
		for (let e of [-.22, .08]) s([
			[e, -.22],
			[e + .16, -.22],
			[e + .16, -.02],
			[e, -.02]
		]);
		s([
			[-.16, .1],
			[.16, .1],
			[.16, .22],
			[-.16, .22]
		]);
	} else for (let i of [.18, .37]) {
		let a = B(t, n, r, i, 24), s = B(t, n, r, i - .035, 24);
		for (let t = 0; t < 24; t++) {
			let n = (t + 1) % 24;
			e.push({
				points: [
					a[t],
					a[n],
					s[n],
					s[t]
				],
				color: o
			});
		}
	}
	for (let t = a; t < e.length; t++) e[t].decoration = !0;
}
function H(e, t, n, r, i) {
	let a = [
		[
			t - .18,
			n,
			r - .18
		],
		[
			t + .18,
			n,
			r - .18
		],
		[
			t + .18,
			n,
			r + .18
		],
		[
			t - .18,
			n,
			r + .18
		]
	];
	V(e, a, a.map(([e, t, n]) => [
		e,
		t + .37,
		n
	]), i ? "#c7bca1" : "#b2602e", i ? "#fff5cc" : "#f2a558"), e.push({
		points: [
			[
				t - .11,
				n + .372,
				r - .11
			],
			[
				t + .06,
				n + .372,
				r - .11
			],
			[
				t + .06,
				n + .372,
				r + .02
			],
			[
				t - .11,
				n + .372,
				r + .02
			]
		],
		color: i ? "#fffbee" : "#ffd393"
	});
}
function xe(e, t = {}) {
	let n = [], r = [
		[
			-4.35,
			0,
			-4.8
		],
		[
			4.35,
			0,
			-4.8
		],
		[
			4.45,
			0,
			3.5
		],
		[
			4.1,
			0,
			4.25
		],
		[
			3.2,
			0,
			4.7
		],
		[
			-3.2,
			0,
			4.7
		],
		[
			-4.1,
			0,
			4.25
		],
		[
			-4.45,
			0,
			3.5
		]
	];
	V(n, r.map(([e, , t]) => [
		e,
		-.2,
		t
	]), r.map(([e, , t]) => [
		e,
		0,
		t
	]), "#816442", "#c9b187");
	for (let e of n) e.ground = !0;
	for (let r of z) {
		let i = n.length, [a, o] = _e(r.q, r.r), s = t.selected === r.key, c = t.legal?.has(r.key), l = B(a, L, o, .95, 6);
		V(n, B(a, .02, o, .98, 6), l, "#b59664", s ? "#c9e1cf" : c ? "#e8e3bc" : "#ead4a2");
		let u = e[r.key]?.layers ?? [];
		if (s || c) {
			let e = B(a, .166, o, .92, 6), t = B(a, .166, o, s ? .83 : .89, 6);
			for (let r = 0; r < 6; r++) {
				let i = (r + 1) % 6;
				n.push({
					points: [
						e[r],
						e[i],
						t[i],
						t[r]
					],
					color: s ? "#277f88" : "#a6a46b"
				});
			}
		}
		if (t.habitat?.has(r.key)) {
			let e = B(a, .169, o, .94, 6), t = B(a, .169, o, .86, 6);
			for (let r = 0; r < 6; r++) n.push({
				points: [
					e[r],
					e[(r + 1) % 6],
					t[(r + 1) % 6],
					t[r]
				],
				color: "#f8fbdf"
			});
		}
		u.forEach((e, i) => {
			if (i === u.length - 1 && t.hiddenTokens?.has(r.key)) return;
			let s = n.length, c = L + i * I + .015;
			ye(n, a, c, o, .73, .322, R[e].top, R[e].side), i === u.length - 1 && be(n, a, c + I - .016, o, e);
			for (let e = s; e < n.length; e++) n[e].paintLayer = i + 1;
		});
		let d = L + u.length * I, f = n.length;
		if (e[r.key]?.animal && !t.hiddenAnimals?.has(r.key) && H(n, a, d + .02, o, e[r.key].animal === "spirit"), t.preview?.key === r.key) {
			let { terrain: e } = t.preview;
			ye(n, a, d + .09, o, .73, .322, R[e].top, R[e].side, .58), be(n, a, d + I + .074, o, e);
		}
		if (t.animalPreview?.key === r.key) {
			let e = n.length;
			H(n, a, d + .14, o, t.animalPreview.spirit);
			for (let t = e; t < n.length; t++) n[t].opacity = .65;
		}
		for (let e = f; e < n.length; e++) n[e].paintLayer = u.length + 1;
		for (let e = i; e < n.length; e++) n[e].paintOrigin = [
			a,
			0,
			o
		];
	}
	return n;
}
function Se(e, t, n, r) {
	let i = [0, 1.8].flatMap((e) => [-4.5, 4.5].flatMap((n) => [-4.9, 4.9].map((r) => ve([
		n,
		e,
		r
	], t)))), a = Math.min(...i.map(([e]) => e)), o = Math.max(...i.map(([e]) => e)), s = Math.min(...i.map(([, e]) => e)), c = Math.max(...i.map(([, e]) => e)), l = Math.min(n / (o - a), r / (c - s)) * .95, u = (a + o) / 2, d = (s + c) / 2, f = (e) => {
		let [i, a, o] = ve(e, t);
		return [
			n / 2 + (i - u) * l,
			r / 2 + (a - d) * l,
			o
		];
	};
	return {
		scale: l,
		cx: u,
		cy: d,
		toScreen: f,
		polygons: e.map((e) => {
			let n = e.points.map(f);
			return {
				...e,
				projected: n,
				depth: n.reduce((e, t) => e + t[2], 0) / n.length,
				cellDepth: e.paintOrigin ? ve(e.paintOrigin, t)[2] : 0
			};
		}).sort((e, t) => Number(!!t.ground) - Number(!!e.ground) || e.cellDepth - t.cellDepth || (e.paintLayer ?? 0) - (t.paintLayer ?? 0) || Number(!!e.decoration) - Number(!!t.decoration) || e.depth - t.depth)
	};
}
//#endregion
//#region src/games/harmonies/board.ts
var Ce = [
	[1, 0],
	[0, 1],
	[-1, 1],
	[-1, 0],
	[0, -1],
	[1, -1]
], we = new Set(z.map((e) => e.key)), U = (e) => {
	let [t, n] = e.split(",").map(Number);
	return Ce.map(([e, r]) => `${t + e},${n + r}`).filter((e) => we.has(e));
}, W = (e, t) => e[t]?.layers.at(-1);
function Te(e, t, n) {
	if (!we.has(t) || e[t]?.animal) return !1;
	let r = e[t]?.layers ?? [];
	return r.length === 0 ? !0 : n === "gray" ? r.length < 3 && r.every((e) => e === "gray") : n === "brown" || n === "green" ? r.length < 3 && r.every((e) => e === "brown") && (n === "green" || r.length < 2) : n === "red" && r.length === 1 && [
		"gray",
		"brown",
		"red"
	].includes(r[0]);
}
function G(e, t, n) {
	let { q: r, r: i } = e;
	n && (i = -r - i);
	for (let e = 0; e < t; e++) [r, i] = [-i, r + i];
	return {
		...e,
		q: r,
		r: i
	};
}
function Ee(e, t, n, r, i) {
	if (!we.has(n) || e[n]?.animal) return null;
	let [a, o] = n.split(",").map(Number), s = [];
	for (let n of t.pattern) {
		let t = G(n, r, i), c = `${a + t.q},${o + t.r}`, l = e[c]?.layers ?? [];
		if (!we.has(c) || l.length !== t.height || l.at(-1) !== t.terrain) return null;
		s.push(c);
	}
	return {
		key: n,
		keys: s,
		rotation: r,
		mirrored: i
	};
}
function De(e, t, n) {
	let r = [], i = /* @__PURE__ */ new Set();
	for (let { key: a } of z) for (let o = 0; o < (n ? 2 : 1); o++) for (let n = 0; n < 6; n++) {
		let s = Ee(e, t, a, n, o === 1);
		if (!s) continue;
		let c = `${a}:${[...s.keys].sort().join(";")}`;
		i.has(c) || (i.add(c), r.push(s));
	}
	return r;
}
function K(e) {
	let t = new Set(e), n = [];
	for (let r of e) {
		if (!t.delete(r)) continue;
		let e = [r];
		for (let n = 0; n < e.length; n++) for (let r of U(e[n])) t.delete(r) && e.push(r);
		n.push(e);
	}
	return n;
}
function Oe(e) {
	let t = new Set(z.filter(({ key: t }) => W(e, t) === "blue").map((e) => e.key)), n = 0;
	for (let e of t) {
		let r = /* @__PURE__ */ new Map([[e, 1]]), i = [e];
		for (let e = 0; e < i.length; e++) {
			let a = r.get(i[e]);
			n = Math.max(n, a);
			for (let n of U(i[e])) t.has(n) && !r.has(n) && (r.set(n, a + 1), i.push(n));
		}
	}
	return n;
}
function q(e, t) {
	let n = z.map((e) => e.key), r = (t) => n.filter((n) => W(e, n) === t), i = r("red").filter((t) => e[t].layers.length === 2);
	switch (t) {
		case "deer": return r("green").filter((t) => e[t].layers.length >= 2).length * 4;
		case "crane": return K(i).filter((e) => e.length >= 2).length * 6;
		case "owl": return r("green").reduce((t, n) => t + (e[n].layers.length === 3 ? 1 : 3), 0);
		case "cat": return K(i).filter((e) => e.length === 1).length * 4;
		case "bear": return r("gray").reduce((t, n) => t + (e[n].layers.length === 3 ? 1 : 3), 0);
		case "dragonfly": return K(r("blue")).filter((e) => e.length >= 2).length * 7;
		case "ibex": return r("gray").filter((t) => e[t].layers.length >= 2).length * 4;
		case "tortoise": return r("blue").length * 2;
		case "butterfly": return K(r("yellow")).length * 5;
		case "lion": return K(r("yellow")).reduce((e, t) => e + (t.length >= 3 ? 10 : 2), 0);
	}
}
function ke(e, t, n) {
	let r = 0, i = 0, a = 0, o = [
		0,
		1,
		3,
		7
	];
	for (let { key: t } of z) {
		let n = e[t]?.layers ?? [], s = n.at(-1);
		s === "green" && (r += o[n.length]), s === "gray" && U(t).some((t) => W(e, t) === "gray") && (i += o[n.length]), s === "red" && n.length === 2 && new Set(U(t).map((t) => W(e, t)).filter((e) => e !== void 0)).size >= 3 && (a += 5);
	}
	let s = K(z.filter(({ key: t }) => W(e, t) === "yellow").map((e) => e.key)).filter((e) => e.length >= 2).length * 5, c = Oe(e), l = Math.max(1, K(z.filter(({ key: t }) => W(e, t) !== "blue").map((e) => e.key)).length), u = n === "B" ? l * 5 : c > 6 ? 15 + (c - 6) * 4 : [
		0,
		0,
		2,
		5,
		8,
		11,
		15
	][c], d = 0, f = 0, p = 0;
	for (let n of t) {
		let t = F[n.id];
		t.spirit ? n.placed > 0 && (f += q(e, t.spirit)) : (d += t.scores[n.placed - 1] ?? 0, p += n.placed);
	}
	return {
		trees: r,
		mountains: i,
		fields: s,
		buildings: a,
		water: u,
		animals: d,
		spirits: f,
		cubes: p,
		river: c,
		islands: l,
		total: r + i + s + a + u + d + f
	};
}
function Ae(e, t, n) {
	let r = [
		40,
		70,
		90,
		110,
		130,
		140,
		150,
		160
	].filter((t) => e >= t).length, i = n === void 0 ? 2 : +!![
		"crane",
		"cat",
		"dragonfly",
		"butterfly",
		"lion"
	].includes(n);
	return r + +(t === "A") + i;
}
//#endregion
//#region src/games/harmonies/meta.ts
var je = {
	id: "harmonies",
	tier: "beta",
	mechanics: [
		"drafting",
		"tile-placement",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.harmonies.name",
	descKey: "games.harmonies.desc",
	rulesKey: "games.harmonies.rules",
	icon: "🌿",
	iconImg: "games/harmonies.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#287e79",
	releasedAt: "2026-10-24T02:56:50+08:00",
	search: {
		py: "zi ran he xian",
		init: "zrhx"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://cdn.svc.asmodee.net/production-libelludv2/uploads/2026/07/HARMONIES_Rules_EN_compressed-1.pdf" }
}, J = t.enum([
	"gray",
	"blue",
	"brown",
	"green",
	"yellow",
	"red"
]), Me = t.object({
	side: t.enum(["A", "B"]).default("A"),
	pulse: t.boolean().default(!0),
	spirits: t.boolean().default(!0)
}).default({
	side: "A",
	pulse: !0,
	spirits: !0
}), Ne = t.string().regex(/^-?\d,-?\d$/).max(5), Y = t.int().min(29300).max(29909), X = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("chooseSpirit"),
		card: Y
	}),
	t.object({
		type: t.literal("draft"),
		group: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("place"),
		terrain: J,
		key: Ne
	}),
	t.object({
		type: t.literal("takeCard"),
		index: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("animal"),
		card: Y,
		key: Ne,
		rotation: t.int().min(0).max(5),
		mirrored: t.boolean()
	}),
	t.object({
		type: t.literal("endTurn"),
		discard: t.int().min(0).max(2).optional()
	})
]), Pe = t.object({
	layers: t.array(J).max(3),
	animal: t.enum(["animal", "spirit"]).optional()
}), Fe = t.object({
	id: Y,
	placed: t.int().min(0).max(5)
}), Ie = t.object({
	trees: t.number(),
	mountains: t.number(),
	fields: t.number(),
	buildings: t.number(),
	water: t.number(),
	animals: t.number(),
	spirits: t.number(),
	cubes: t.number(),
	river: t.number(),
	islands: t.number(),
	total: t.number()
}), Le = t.object({
	rid: t.string(),
	kind: t.enum([
		"spirit",
		"draft",
		"place",
		"takeCard",
		"animal",
		"endTurn"
	]),
	card: Y.optional(),
	terrain: J.optional(),
	key: t.string().optional(),
	n: t.number().optional()
}), Re = t.object({
	phase: t.enum(["play", "done"]),
	config: Me,
	round: t.int().min(1),
	serial: t.int().min(0),
	current: t.string(),
	bagLeft: t.int().min(0),
	cardsLeft: t.int().min(0),
	lastRound: t.boolean(),
	groups: t.array(t.array(J).max(3).nullable()).min(3).max(5),
	market: t.array(Y.nullable()).min(3).max(5),
	players: t.array(t.object({
		rid: t.string(),
		board: t.record(t.string(), Pe),
		cards: t.array(Fe),
		spiritChosen: t.boolean(),
		score: Ie
	})),
	turn: t.object({
		drafted: t.boolean(),
		held: t.array(J).max(3),
		tookCard: t.boolean()
	}),
	log: t.array(Le),
	suns: t.number().optional()
}), ze = t.object({ spirits: t.array(Y).max(2) }), Be = {
	gray: 23,
	blue: 23,
	brown: 21,
	green: 19,
	yellow: 19,
	red: 15
}, Ve = () => ({
	drafted: !1,
	held: [],
	tookCard: !1
});
function He(t, n, r) {
	let i = 0, a = (t) => {
		for (let n = t.length - 1; n > 0; n--) {
			let a = e(r, i++, n + 1);
			[t[n], t[a]] = [t[a], t[n]];
		}
		return t;
	}, o = a(Object.entries(Be).flatMap(([e, t]) => Array.from({ length: t }, () => e))), s = a(me.filter((e) => t.pulse || !e.expansion).map((e) => e.id)), c = a(P.map((e) => e.id)), l = n.length === 1 ? 3 : 5, u = {
		phase: "play",
		config: t,
		players: [...n],
		boards: {},
		owned: {},
		spiritChoices: {},
		spiritChosen: {},
		bag: o,
		deck: s,
		groups: Array.from({ length: l }, () => o.splice(0, 3)),
		market: s.splice(0, l),
		current: 0,
		round: 1,
		serial: 0,
		lastRound: !1,
		turn: Ve(),
		log: []
	};
	for (let e of n) u.boards[e] = {}, u.owned[e] = [], u.spiritChoices[e] = t.spirits ? c.splice(0, 2) : [], u.spiritChosen[e] = !t.spirits;
	return { state: u };
}
var Z = () => ({ code: "games.harmonies.invalid" });
function Ue(e, t, { by: n }) {
	if (e.phase !== "play" || e.players[e.current] !== n) return { code: "games.harmonies.notYourTurn" };
	if (!e.spiritChosen[n] && t.type !== "chooseSpirit") return { code: "games.harmonies.chooseSpiritFirst" };
	let r = structuredClone(e), i = r.boards[n], a = r.owned[n];
	switch (t.type) {
		case "chooseSpirit":
			if (r.spiritChosen[n] || !r.spiritChoices[n].includes(t.card)) return Z();
			a.push({
				id: t.card,
				placed: 0
			}), r.spiritChoices[n] = [], r.spiritChosen[n] = !0, r.log.push({
				rid: n,
				kind: "spirit",
				card: t.card
			});
			break;
		case "draft": {
			let e = r.groups[t.group];
			if (r.turn.drafted || !e || e.length !== 3) return Z();
			r.turn.drafted = !0, r.turn.held = e, r.groups[t.group] = null, r.log.push({
				rid: n,
				kind: "draft",
				n: t.group + 1
			});
			break;
		}
		case "place": {
			let e = r.turn.held.indexOf(t.terrain);
			if (e < 0 || !Te(i, t.key, t.terrain)) return Z();
			r.turn.held.splice(e, 1), i[t.key] = { layers: [...i[t.key]?.layers ?? [], t.terrain] }, r.log.push({
				rid: n,
				kind: "place",
				terrain: t.terrain,
				key: t.key
			});
			break;
		}
		case "takeCard": {
			let e = r.market[t.index];
			if (r.turn.tookCard || e == null) return Z();
			if (a.filter((e) => e.placed < F[e.id].scores.length).length >= 4) return { code: "games.harmonies.cardLimit" };
			a.push({
				id: e,
				placed: 0
			}), r.market[t.index] = null, r.turn.tookCard = !0, r.log.push({
				rid: n,
				kind: "takeCard",
				card: e
			});
			break;
		}
		case "animal": {
			let e = a.find((e) => e.id === t.card), o = F[t.card];
			if (!e || !o || e.placed >= o.scores.length || t.mirrored && !r.config.pulse) return Z();
			if (!Ee(i, o, t.key, t.rotation, t.mirrored)) return { code: "games.harmonies.noHabitat" };
			i[t.key].animal = o.spirit ? "spirit" : "animal", e.placed++, r.log.push({
				rid: n,
				kind: "animal",
				card: o.id,
				key: t.key
			});
			break;
		}
		case "endTurn": {
			if (!r.turn.drafted || r.turn.held.length > 0) return { code: "games.harmonies.placeAll" };
			if (t.discard !== void 0) {
				if (r.players.length !== 1 || r.turn.tookCard || r.market[t.discard] == null) return Z();
				r.market[t.discard] = null;
			}
			z.filter(({ key: e }) => !i[e]?.layers.length).length <= 2 && (r.lastRound = !0);
			let e = r.players.length === 1;
			for (let t = 0; t < r.groups.length; t++) {
				if (!e && r.groups[t] !== null) continue;
				r.bag.length < 3 && (r.lastRound = !0);
				let n = r.bag.splice(0, 3);
				r.groups[t] = n.length === 3 ? n : null;
			}
			for (let e = 0; e < r.market.length; e++) r.market[e] === null && (r.market[e] = r.deck.shift() ?? null);
			r.log.push({
				rid: n,
				kind: "endTurn"
			}), r.serial++, r.lastRound && r.current === r.players.length - 1 ? r.phase = "done" : (r.current = (r.current + 1) % r.players.length, r.current === 0 && r.round++, r.turn = Ve());
			break;
		}
	}
	return {
		state: r,
		fx: t.type === "place" ? [{
			kind: "place",
			rid: n,
			data: {
				key: t.key,
				terrain: t.terrain
			}
		}] : t.type === "animal" ? [{
			kind: "animal",
			rid: n,
			data: {
				key: t.key,
				spirit: !!F[t.card].spirit
			}
		}] : []
	};
}
function We(e, t) {
	let n = e.players.map((t) => ({
		rid: t,
		board: structuredClone(e.boards[t]),
		cards: e.owned[t].map((e) => ({ ...e })),
		spiritChosen: e.spiritChosen[t],
		score: ke(e.boards[t], e.owned[t], e.config.side)
	})), r = e.owned[e.players[0]].map((e) => F[e.id].spirit).find((e) => e !== void 0);
	return {
		public: {
			phase: e.phase,
			config: e.config,
			round: e.round,
			serial: e.serial,
			current: e.players[e.current],
			bagLeft: e.bag.length,
			cardsLeft: e.deck.length,
			lastRound: e.lastRound,
			groups: e.groups.map((e) => e ? [...e] : null),
			market: [...e.market],
			players: n,
			turn: {
				...e.turn,
				held: [...e.turn.held]
			},
			log: e.log.slice(-60),
			...e.phase === "done" && e.players.length === 1 ? { suns: Ae(n[0].score.total, e.config.side, r) } : {}
		},
		private: { spirits: e.spiritChoices[t] ?? [] }
	};
}
var Ge = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: je,
	schemas: {
		action: X,
		publicView: Re,
		privateView: ze,
		config: Me
	},
	setup: He,
	reduce: Ue,
	viewFor: We,
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = Object.fromEntries(e.players.map((t) => [t, ke(e.boards[t], e.owned[t], e.config.side)])), n = [...e.players].sort((e, n) => t[n].total - t[e].total || t[n].cubes - t[e].cubes), r = t[n[0]];
		return {
			phase: "done",
			ranking: n,
			winner: n.filter((e) => t[e].total === r.total && t[e].cubes === r.cubes),
			scores: Object.fromEntries(e.players.map((e) => [e, t[e].total]))
		};
	}
};
//#endregion
//#region src/games/harmonies/board3d.tsx
function Ke(e) {
	let t = [];
	for (let n of e) for (let e = 1; e < n.points.length - 1; e++) t.push(...n.points[0], ...n.points[e], ...n.points[e + 1]);
	let n = new ce();
	return n.setAttribute("position", new le(t, 3)), n;
}
function qe({ faces: e, color: t, opacity: n }) {
	let a = i(() => Ke(e), [e]);
	return r(() => () => a.dispose(), [a]), /* @__PURE__ */ w("mesh", {
		geometry: a,
		children: /* @__PURE__ */ w("meshBasicMaterial", {
			color: t,
			side: y,
			transparent: n < 1,
			opacity: n,
			depthWrite: n === 1
		})
	});
}
function Je({ faces: e }) {
	return i(() => {
		let t = /* @__PURE__ */ new Map();
		for (let n of e) {
			let e = `${n.color}:${n.opacity ?? 1}`, r = t.get(e) ?? {
				color: n.color,
				opacity: n.opacity ?? 1,
				faces: []
			};
			r.faces.push(n), t.set(e, r);
		}
		return [...t.entries()];
	}, [e]).map(([e, t]) => /* @__PURE__ */ w(qe, { ...t }, e));
}
function Ye(e, t, n, r) {
	let i = Se(t, n, r.width, r.height), a = Math.sin(n.azimuth), o = Math.cos(n.azimuth), s = Math.sin(n.elevation), c = Math.cos(n.elevation), l = new x(o * i.cx + a * s * i.cy, -c * i.cy, -a * i.cx + o * s * i.cy);
	e.position.copy(l).add(new x(a * c, s, o * c).multiplyScalar(25)), e.left = -r.width / 2, e.right = r.width / 2, e.top = r.height / 2, e.bottom = -r.height / 2, e.zoom = i.scale, e.lookAt(l), e.updateProjectionMatrix();
}
function Xe({ faces: e, orbit: t }) {
	let { camera: n, size: i, invalidate: a } = se(), { width: o, height: s } = i;
	return r(() => {
		n instanceof b && (Ye(n, e, t, {
			width: o,
			height: s
		}), a());
	}, [
		n,
		e,
		t,
		o,
		s,
		a
	]), null;
}
function Ze() {
	let e = a(null), [t, n] = o({
		width: 1,
		height: 1
	});
	return r(() => {
		let t = e.current;
		if (!t) return;
		let r = () => n({
			width: t.clientWidth,
			height: t.clientHeight
		}), i = new ResizeObserver(r);
		return i.observe(t), r(), () => i.disconnect();
	}, []), {
		ref: e,
		box: t
	};
}
function Qe({ rid: e, board: t, selected: n, legal: s, preview: c, habitat: l, animalPreview: u, label: d, resetLabel: f, cellLabel: p, onSelect: h }) {
	let { ref: g, box: _ } = Ze(), v = re();
	ne(null);
	let [ee, te] = o(ge), ie = a(null), ae = a(!1), [oe, se] = o(!1), ce = z.filter(({ key: t }) => e && v?.isBusy(`hm-token:${e}:${t}`)).map((e) => e.key).join(";"), y = z.filter(({ key: t }) => e && v?.isBusy(`hm-animal:${e}:${t}`)).map((e) => e.key).join(";"), le = i(() => xe(t, {
		selected: n,
		legal: s,
		preview: c,
		habitat: l,
		animalPreview: u,
		hiddenTokens: new Set(ce.split(";")),
		hiddenAnimals: new Set(y.split(";"))
	}), [
		t,
		n,
		s,
		c,
		l,
		u,
		ce,
		y
	]), b = i(() => Se(le, ee, _.width, _.height), [
		le,
		ee,
		_.width,
		_.height
	]);
	r(() => {
		if (!e || !v) return;
		let n = [];
		for (let { key: r, q: i, r: a } of z) for (let o of ["token", "animal"]) {
			let s = `hm-${o}:${e}:${r}`;
			n.push(s), v.registerProbe(s, () => {
				let e = g.current;
				if (!e) return null;
				let n = e.getBoundingClientRect(), [s, c] = _e(i, a), l = L + (t[r]?.layers.length ?? 0) * I + (o === "animal" ? .2 : -.1), [u, d] = b.toScreen([
					s,
					l,
					c
				]), f = b.scale * (o === "token" ? 1.46 : .5), p = f * .75;
				return {
					x: n.left + u - f / 2,
					y: n.top + d - p / 2,
					w: f,
					h: p
				};
			});
		}
		return () => n.forEach((e) => v.registerProbe(e, null));
	}, [
		v,
		e,
		t,
		b,
		g
	]);
	let x = (e) => {
		e.button !== 0 || e.target.closest("[data-harmonies-camera]") || (ie.current ||= (ae.current = !1, {
			id: e.pointerId,
			x: e.clientX,
			y: e.clientY,
			origin: ee,
			dragged: !1
		}));
	}, C = (e) => {
		let t = ie.current;
		if (!t || t.id !== e.pointerId) return;
		let n = e.clientX - t.x, r = e.clientY - t.y;
		!t.dragged && Math.hypot(n, r) < 8 || (t.dragged || e.currentTarget.setPointerCapture(e.pointerId), t.dragged = !0, ae.current = !0, te({
			azimuth: t.origin.azimuth - n * .008,
			elevation: Math.max(.6, Math.min(1.3, t.origin.elevation + r * .005))
		}));
	}, E = (e) => {
		ie.current?.id === e.pointerId && (ie.current = null, e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId));
	};
	return /* @__PURE__ */ T("div", {
		ref: g,
		className: "harmonies-board3d",
		role: "group",
		"aria-label": d,
		onPointerDown: x,
		onPointerMove: C,
		onPointerUp: E,
		onPointerCancel: E,
		onClickCapture: (e) => {
			ae.current &&= (e.preventDefault(), e.stopPropagation(), !1);
		},
		children: [
			/* @__PURE__ */ T(S, {
				orthographic: !0,
				camera: {
					near: .1,
					far: 100
				},
				frameloop: "demand",
				dpr: [1, 2],
				gl: {
					antialias: !0,
					alpha: !0,
					powerPreference: "low-power"
				},
				onRecoveryChange: se,
				recoveryFallback: /* @__PURE__ */ w("svg", {
					className: "harmonies-board-fallback",
					viewBox: `0 0 ${_.width} ${_.height}`,
					"aria-hidden": "true",
					children: b.polygons.map((e, t) => /* @__PURE__ */ w("polygon", {
						points: e.projected.map(([e, t]) => `${e},${t}`).join(" "),
						fill: e.color,
						opacity: e.opacity
					}, t))
				}),
				children: [/* @__PURE__ */ w(Xe, {
					faces: le,
					orbit: ee
				}), /* @__PURE__ */ w(Je, { faces: le })]
			}),
			/* @__PURE__ */ w("svg", {
				className: "harmonies-board-targets",
				viewBox: `0 0 ${_.width} ${_.height}`,
				"aria-label": d,
				children: z.map(({ key: e, q: r, r: i }) => {
					let [a, o] = _e(r, i), s = L + (t[e]?.layers.length ?? 0) * I + .025, c = b.toScreen([
						a,
						s,
						o
					]), l = Array.from({ length: 6 }, (e, t) => {
						let n = t * Math.PI / 3;
						return b.toScreen([
							a + .86 * Math.cos(n),
							s,
							o + .86 * Math.sin(n)
						]);
					}), u = Math.max(...l.map((e) => e[0])) - Math.min(...l.map((e) => e[0])), d = Math.max(...l.map((e) => e[1])) - Math.min(...l.map((e) => e[1])), f = l.map(([e, t]) => `${c[0] + (e - c[0]) * Math.max(1, 44 / u)},${c[1] + (t - c[1]) * Math.max(1, 44 / d)}`).join(" ");
					return /* @__PURE__ */ w("polygon", {
						points: f,
						role: "button",
						tabIndex: 0,
						"data-cell-key": e,
						"aria-label": p(e),
						"aria-pressed": e === n,
						className: "harmonies-cell-target",
						onClick: () => h(e),
						onKeyDown: (t) => {
							(t.key === "Enter" || t.key === " ") && (t.preventDefault(), h(e));
						}
					}, e);
				})
			}),
			/* @__PURE__ */ w("button", {
				type: "button",
				className: "btn-quiet harmonies-camera-reset",
				"data-harmonies-camera": !0,
				"aria-label": f,
				onClick: () => {
					ae.current = !1, te(ge);
				},
				children: /* @__PURE__ */ w(m, { className: "size-5" })
			}),
			oe && /* @__PURE__ */ w("span", {
				className: "sr-only",
				children: d
			})
		]
	});
}
//#endregion
//#region src/games/harmonies/art.tsx
var $e = {
	forest: [
		"#bdd1ae",
		"#7c9c77",
		"#4f7860",
		"#305d51"
	],
	water: [
		"#c1d9ce",
		"#7cafa5",
		"#428b91",
		"#286572"
	],
	desert: [
		"#f0d3a4",
		"#d3a474",
		"#b97e54",
		"#e0b577"
	],
	mountain: [
		"#d1dcce",
		"#9aafa7",
		"#617e7b",
		"#405f62"
	]
};
function et({ x: e, y: t, scale: n = 1, color: r = "#a5bb89", turn: i = 0 }) {
	return /* @__PURE__ */ T("g", {
		transform: `translate(${e} ${t}) rotate(${i}) scale(${n})`,
		children: [/* @__PURE__ */ w("path", {
			d: "M0 0Q-34-46-13-89 24-64 0 0",
			fill: r
		}), /* @__PURE__ */ w("path", {
			d: "M0 0-10-71",
			stroke: "#f4efda",
			strokeWidth: "2",
			fill: "none"
		})]
	});
}
function tt({ kind: e }) {
	let t = [
		"flamingo",
		"heron",
		"swan",
		"stork",
		"pelican"
	].includes(e);
	if (e === "penguin") return /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M58 165Q43 118 57 83 67 50 87 58 111 61 119 114L136 150 113 135 114 175 94 186 64 182Z",
			fill: "#354f55"
		}),
		/* @__PURE__ */ w("path", {
			d: "M72 91Q98 74 107 117L109 169Q84 181 68 167Z",
			fill: "#f5ebd3"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "88",
			cy: "77",
			r: "3",
			fill: "#f9e5b3"
		}),
		/* @__PURE__ */ w("path", {
			d: "M97 78 119 88 99 92ZM64 177 90 178 78 187 58 186ZM96 178 116 174 128 181 107 189Z",
			fill: "#d7a151"
		})
	] });
	if (e === "owl") return /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M28 78 68 113 89 53 111 112 155 72 137 152 94 179 48 151Z",
			fill: "#516854"
		}),
		/* @__PURE__ */ w("path", {
			d: "M59 106Q91 76 122 106L116 149 91 174 65 149Z",
			fill: "#eee7ce"
		}),
		/* @__PURE__ */ w("path", {
			d: "M91 112Q68 85 65 117T91 144Q112 133 116 111T91 112",
			fill: "#c5c7a5"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "79",
			cy: "118",
			r: "5",
			fill: "#354c43"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "104",
			cy: "118",
			r: "5",
			fill: "#354c43"
		}),
		/* @__PURE__ */ w("path", {
			d: "M86 128 97 128 91 141Z",
			fill: "#c99545"
		})
	] });
	let n = [
		"kingfisher",
		"hummingbird",
		"peacock"
	].includes(e), r = e === "flamingo" ? "#e4a69b" : n ? "#34869a" : e === "songbird" ? "#b68551" : "#e7e7d4";
	return /* @__PURE__ */ T("g", { children: [
		e === "peacock" && /* @__PURE__ */ w("g", {
			fill: "#4b8975",
			stroke: "#bdd2a0",
			strokeWidth: "2",
			children: [
				0,
				1,
				2,
				3,
				4,
				5,
				6
			].map((e) => /* @__PURE__ */ w("ellipse", {
				cx: "89",
				cy: "91",
				rx: "17",
				ry: "56",
				transform: `rotate(${(e - 3) * 22} 89 130)`
			}, e))
		}),
		/* @__PURE__ */ w("path", {
			d: "M0 178 180 108",
			stroke: "#775f45",
			strokeWidth: "8"
		}),
		t ? /* @__PURE__ */ T(C, { children: [
			/* @__PURE__ */ w("path", {
				d: "M51 141Q47 110 77 112L97 122Q109 105 92 85 66 62 90 47 112 33 124 53L113 62Q99 43 94 56 90 67 105 77 135 104 111 137 91 163 51 141Z",
				fill: r
			}),
			/* @__PURE__ */ w("path", {
				d: "M111 52 151 60 115 64Z",
				fill: e === "pelican" ? "#d4a05c" : "#53645d"
			}),
			/* @__PURE__ */ w("path", {
				d: "M74 145 74 176M94 143 101 166",
				stroke: "#5c6858",
				strokeWidth: "3"
			}),
			e === "pelican" && /* @__PURE__ */ w("path", {
				d: "M117 63 149 60Q143 89 119 78Z",
				fill: "#edbd79"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "113",
				cy: "53",
				r: "2.8",
				fill: "#354c43"
			}),
			/* @__PURE__ */ w("path", {
				d: "M57 125Q77 114 97 132L70 144Z",
				fill: n ? "#2a6377" : "#c0cbbb"
			})
		] }) : /* @__PURE__ */ T(C, { children: [
			/* @__PURE__ */ w("path", {
				d: "M72 125Q47 76 71 45 96 37 110 63L137 68 112 76Q108 97 88 114L76 154 59 159Z",
				fill: r
			}),
			/* @__PURE__ */ w("path", {
				d: "M75 92Q102 74 105 63 120 92 89 124L62 145Z",
				fill: n ? "#d3a05d" : "#d4bc88"
			}),
			/* @__PURE__ */ w("path", {
				d: "M68 105 43 159 65 150 85 118Z",
				fill: n ? "#246579" : "#506e68"
			}),
			/* @__PURE__ */ w("path", {
				d: "M111 62 146 67 112 71Z",
				fill: "#354c43"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "102",
				cy: "62",
				r: "3",
				fill: "#263e3b"
			}),
			/* @__PURE__ */ w("path", {
				d: "M79 122 85 135M89 119 96 131",
				stroke: "#354c43",
				strokeWidth: "2"
			})
		] })
	] });
}
function nt({ kind: e }) {
	if (e === "bat") return /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M89 113Q54 49 13 69L29 119Q45 99 57 126 68 106 82 142L95 148 111 128Q124 111 135 128 151 100 170 112L158 65Q113 57 97 111Z",
			fill: "#4c6870"
		}),
		/* @__PURE__ */ w("path", {
			d: "M77 105 78 79 90 92 105 79 108 111 97 145 84 141Z",
			fill: "#d5c99b"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "85",
			cy: "104",
			r: "2.5",
			fill: "#354c43"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "99",
			cy: "104",
			r: "2.5",
			fill: "#354c43"
		})
	] });
	if ([
		"bear",
		"polarBear",
		"panda",
		"koala"
	].includes(e)) {
		let t = e === "bear" ? "#906546" : e === "koala" ? "#97a39b" : "#eee9d5";
		return /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("ellipse", {
				cx: "88",
				cy: "145",
				rx: "49",
				ry: "37",
				fill: t
			}),
			/* @__PURE__ */ w("path", {
				d: "M44 139 35 178 53 184 66 155M109 149 115 180 137 182 133 142",
				fill: e === "panda" ? "#3d5251" : t
			}),
			/* @__PURE__ */ w("circle", {
				cx: "62",
				cy: "87",
				r: "17",
				fill: e === "panda" ? "#3d5251" : t
			}),
			/* @__PURE__ */ w("circle", {
				cx: "114",
				cy: "87",
				r: "17",
				fill: e === "panda" ? "#3d5251" : t
			}),
			/* @__PURE__ */ w("ellipse", {
				cx: "88",
				cy: "111",
				rx: "37",
				ry: "34",
				fill: t
			}),
			e === "panda" && /* @__PURE__ */ T("g", {
				fill: "#405354",
				children: [/* @__PURE__ */ w("ellipse", {
					cx: "74",
					cy: "108",
					rx: "10",
					ry: "13",
					transform: "rotate(25 74 108)"
				}), /* @__PURE__ */ w("ellipse", {
					cx: "104",
					cy: "108",
					rx: "10",
					ry: "13",
					transform: "rotate(-25 104 108)"
				})]
			}),
			/* @__PURE__ */ w("ellipse", {
				cx: "88",
				cy: "125",
				rx: "20",
				ry: "13",
				fill: "#d6c8a7"
			}),
			/* @__PURE__ */ w("ellipse", {
				cx: "88",
				cy: "118",
				rx: e === "koala" ? 10 : 7,
				ry: e === "koala" ? 14 : 5,
				fill: "#354c43"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "73",
				cy: "107",
				r: "3",
				fill: e === "panda" ? "#fff1cc" : "#354c43"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "104",
				cy: "107",
				r: "3",
				fill: e === "panda" ? "#fff1cc" : "#354c43"
			})
		] });
	}
	let t = [
		"llama",
		"giraffe",
		"camel"
	].includes(e), n = [
		"fennec",
		"llama",
		"camel",
		"giraffe",
		"meerkat"
	].includes(e) ? "#e8bf84" : e === "panther" || e === "cat" ? "#405952" : e === "wolf" ? "#9ca8a0" : e === "tiger" ? "#df9b4c" : "#a47a56", r = t ? 65 : 111;
	return /* @__PURE__ */ T("g", { children: [
		[
			"squirrel",
			"lemur",
			"fennec",
			"panther",
			"cat"
		].includes(e) && /* @__PURE__ */ w("path", {
			d: e === "squirrel" ? "M57 144Q9 144 24 97 30 77 50 90 63 104 39 119L65 137Z" : "M60 151Q23 178 21 144 7 155 20 174 47 190 77 157Z",
			fill: e === "lemur" ? "#ede2c0" : n,
			stroke: e === "lemur" ? "#5b6860" : "none",
			strokeWidth: "6",
			strokeDasharray: e === "lemur" ? "9 8" : void 0
		}),
		e === "lion" && /* @__PURE__ */ w("circle", {
			cx: 116,
			cy: r,
			r: "37",
			fill: "#b47a45"
		}),
		e === "hedgehog" && /* @__PURE__ */ w("path", {
			d: "M30 157 22 142 37 135 33 118 50 120 57 105 70 113 83 102 93 118 108 114 119 137 109 163Z",
			fill: "#645e43"
		}),
		/* @__PURE__ */ w("path", {
			d: `M49 143Q47 120 78 116L104 120 ${t ? `103 ${r + 9} 124 ${r + 8}` : "130 125"} 140 151 121 164 118 184 104 183 103 161 70 165 65 184 50 182 55 159Z`,
			fill: n
		}),
		e === "camel" && /* @__PURE__ */ w("path", {
			d: "M51 131Q52 87 76 111 91 78 102 124Z",
			fill: n
		}),
		/* @__PURE__ */ w("path", {
			d: `M96 ${r + 17} 89 ${r - (e === "fennec" ? 49 : 27)}Q92 ${r - 49} 108 ${r - 11}L132 ${r - (e === "fennec" ? 47 : 26)}Q144 ${r - 43} 134 ${r + 7}L141 ${r + 23} 122 ${r + 39} 103 ${r + 31}Z`,
			fill: n
		}),
		/* @__PURE__ */ w("path", {
			d: `M105 ${r + 20} 119 ${r + 31} 138 ${r + 21} 123 ${r + 38} 107 ${r + 31}Z`,
			fill: "#f5e0b6"
		}),
		/* @__PURE__ */ w("path", {
			d: `M100 ${r + 15}l5-1m19-2 5-1`,
			stroke: "#354c43",
			strokeWidth: "2.5",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ w("path", {
			d: `M117 ${r + 28}l7-1-3 6Z`,
			fill: "#354c43"
		}),
		[
			"deer",
			"ibex",
			"yak"
		].includes(e) && /* @__PURE__ */ w("path", {
			d: `M102 ${r - 8}q-23-19-11-40m4 20-17-6m48 27q21-23 8-43m-1 21 16-9`,
			stroke: "#675f43",
			strokeWidth: "5",
			fill: "none"
		}),
		e === "giraffe" && /* @__PURE__ */ w("g", {
			fill: "#af7c46",
			children: [
				[73, 134],
				[93, 145],
				[111, 115],
				[114, 93]
			].map(([e, t], n) => /* @__PURE__ */ w("path", { d: `M${e} ${t}l9-4 5 10-9 6Z` }, n))
		}),
		e === "tiger" && /* @__PURE__ */ w("path", {
			d: "M59 124 66 141 72 121M80 120 88 139 94 123M105 131 112 146 118 136",
			fill: "#4b5b4d"
		})
	] });
}
function rt({ kind: e }) {
	return e === "ladybug" || e === "beetle" ? /* @__PURE__ */ T("g", {
		transform: "translate(91 126) rotate(-22)",
		children: [
			/* @__PURE__ */ w("path", {
				d: "M-25-7-40-17M-27 7-44 10M-21 22-37 35M25-7 40-17M27 7 44 10M21 22 37 35",
				stroke: "#354c43",
				strokeWidth: "4",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ w("ellipse", {
				cy: "-30",
				rx: "14",
				ry: "12",
				fill: "#354c43"
			}),
			/* @__PURE__ */ w("ellipse", {
				rx: "30",
				ry: "38",
				fill: e === "ladybug" ? "#c6654b" : "#377b84"
			}),
			/* @__PURE__ */ w("path", {
				d: "M0-36V36",
				stroke: "#354c43",
				strokeWidth: "3"
			}),
			e === "ladybug" && /* @__PURE__ */ T("g", {
				fill: "#354c43",
				children: [
					/* @__PURE__ */ w("circle", {
						cx: "-15",
						cy: "-13",
						r: "6"
					}),
					/* @__PURE__ */ w("circle", {
						cx: "15",
						cy: "-13",
						r: "6"
					}),
					/* @__PURE__ */ w("circle", {
						cx: "-15",
						cy: "12",
						r: "6"
					}),
					/* @__PURE__ */ w("circle", {
						cx: "15",
						cy: "12",
						r: "6"
					})
				]
			})
		]
	}) : /* @__PURE__ */ T("g", {
		transform: "translate(92 123)",
		children: [
			/* @__PURE__ */ w("path", {
				d: "M0 0Q-58-66-41-69 11-77 0 0M0 0Q58-66 41-69-11-77 0 0M0 0Q-43 29-41-8-27-39 0 0M0 0Q43 29 41-8 27-39 0 0",
				fill: e === "dragonfly" ? "#c6e2c1" : "#f1d594",
				opacity: ".95"
			}),
			e === "bee" ? /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("ellipse", {
				rx: "17",
				ry: "32",
				fill: "#e3b557"
			}), /* @__PURE__ */ w("path", {
				d: "M-16-12H16M-17 1H17M-13 14H13",
				stroke: "#4a5c50",
				strokeWidth: "7"
			})] }) : /* @__PURE__ */ w("path", {
				d: "M0 20V-47",
				stroke: "#4a6555",
				strokeWidth: "6",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ w("path", {
				d: "M0-43-9-57M0-43 9-57",
				stroke: "#4a6555",
				strokeWidth: "2"
			})
		]
	});
}
function it({ kind: e }) {
	if (e === "tortoise") return /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("ellipse", {
			cx: "89",
			cy: "136",
			rx: "56",
			ry: "37",
			fill: "#697e59",
			stroke: "#e0d49b",
			strokeWidth: "4"
		}),
		/* @__PURE__ */ w("path", {
			d: "M47 153 34 174 53 176 65 158M111 159 124 180 140 174 128 150",
			fill: "#acb68b"
		}),
		/* @__PURE__ */ w("ellipse", {
			cx: "143",
			cy: "144",
			rx: "22",
			ry: "15",
			fill: "#acb68b"
		}),
		/* @__PURE__ */ w("path", {
			d: "M58 124 79 110 105 111 125 132 109 151 80 157 57 143Z",
			fill: "none",
			stroke: "#abb78a",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "151",
			cy: "140",
			r: "3",
			fill: "#354c43"
		})
	] });
	let t = e === "axolotl" ? "#e1a4a3" : e === "salamander" ? "#668d99" : "#8baf6c";
	return /* @__PURE__ */ T("g", { children: [
		/* @__PURE__ */ w("path", {
			d: "M51 144Q7 185 22 121 24 108 37 114 22 161 59 133L103 115 145 118 161 134 144 150 100 151 63 158Z",
			fill: t
		}),
		/* @__PURE__ */ w("path", {
			d: "M64 142 56 168 72 166M90 139 101 165 116 157M78 122 72 102 88 106M115 119 127 101 138 107",
			stroke: t,
			strokeWidth: "9",
			fill: "none",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ w("circle", {
			cx: "145",
			cy: "128",
			r: "3",
			fill: "#354c43"
		}),
		e === "axolotl" && /* @__PURE__ */ w("path", {
			d: "M130 118 119 98M140 119 141 95M151 122 163 104M132 150 121 164M145 150 146 169M153 143 167 150",
			stroke: "#c77185",
			strokeWidth: "5"
		}),
		e === "chameleon" && /* @__PURE__ */ w("path", {
			d: "M46 143Q13 169 20 140 30 123 39 141 31 151 28 141",
			fill: "none",
			stroke: t,
			strokeWidth: "8"
		})
	] });
}
function at({ card: e }) {
	let t = e.art, n = [
		"fennec",
		"camel",
		"giraffe",
		"meerkat",
		"llama",
		"lion"
	].includes(t) ? $e.desert : [
		"polarBear",
		"penguin",
		"vulture",
		"yak",
		"ibex"
	].includes(t) ? $e.mountain : [
		"fish",
		"axolotl",
		"kingfisher",
		"heron",
		"flamingo",
		"swan",
		"otter",
		"duck",
		"pelican",
		"tortoise"
	].includes(t) ? $e.water : $e.forest;
	return /* @__PURE__ */ T(C, { children: [
		/* @__PURE__ */ w("rect", {
			width: "180",
			height: "200",
			fill: n[0]
		}),
		/* @__PURE__ */ w("circle", {
			cx: "139",
			cy: "35",
			r: e.spirit ? 30 : 24,
			fill: "#f8e2a6"
		}),
		/* @__PURE__ */ w("path", {
			d: "M0 90 43 57 91 92 131 65 180 89V200H0Z",
			fill: n[1]
		}),
		/* @__PURE__ */ w("path", {
			d: "M0 130Q69 80 180 120V200H0Z",
			fill: n[2]
		}),
		/* @__PURE__ */ w("path", {
			d: "M0 177Q80 120 180 157V200H0Z",
			fill: n[3]
		}),
		e.spirit && /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("circle", {
			cx: "91",
			cy: "108",
			r: "67",
			stroke: "#e6d7a4",
			strokeWidth: "2",
			fill: "none",
			opacity: ".5"
		}), /* @__PURE__ */ w("circle", {
			cx: "91",
			cy: "108",
			r: "73",
			stroke: "#e6d7a4",
			fill: "none",
			opacity: ".5"
		})] }),
		e.family === "bird" ? /* @__PURE__ */ w(tt, { kind: t }) : e.family === "mammal" ? /* @__PURE__ */ w(nt, { kind: t }) : e.family === "insect" ? /* @__PURE__ */ w(rt, { kind: t }) : e.family === "fish" ? /* @__PURE__ */ T("g", { children: [
			/* @__PURE__ */ w("path", {
				d: "M53 122 23 96 25 149Z",
				fill: "#d5b47a"
			}),
			/* @__PURE__ */ w("ellipse", {
				cx: "97",
				cy: "123",
				rx: "49",
				ry: "29",
				fill: "#6b90a5"
			}),
			/* @__PURE__ */ w("path", {
				d: "M65 104 85 77 108 99M66 142 87 169 110 145",
				fill: "#e0bc73"
			}),
			/* @__PURE__ */ w("path", {
				d: "M77 99 86 148M100 95 109 148",
				stroke: "#52727f",
				strokeWidth: "8"
			}),
			/* @__PURE__ */ w("circle", {
				cx: "130",
				cy: "119",
				r: "4",
				fill: "#f8e7b6"
			})
		] }) : /* @__PURE__ */ w(it, { kind: t }),
		/* @__PURE__ */ w(et, {
			x: 15,
			y: 205,
			scale: .65,
			color: n[1],
			turn: -25
		}),
		/* @__PURE__ */ w(et, {
			x: 171,
			y: 205,
			scale: .52,
			color: n[1],
			turn: 30
		})
	] });
}
//#endregion
//#region src/games/harmonies/pieces.tsx
function ot({ terrain: e, x: t = 0, y: n = 0, scale: r = 1, opacity: i = 1 }) {
	let a = R[e], o = {
		gray: /* @__PURE__ */ w("path", {
			d: "M-12 5 -4-7 2 1 6-4 13 6Z",
			fill: a.print
		}),
		blue: /* @__PURE__ */ w("path", {
			d: "M-12-3Q-6-8 0-3T12-3M-12 4Q-6-1 0 4T12 4",
			stroke: a.print,
			strokeWidth: "2",
			fill: "none"
		}),
		brown: /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("ellipse", {
			rx: "12",
			ry: "7",
			stroke: a.print,
			strokeWidth: "2",
			fill: "none"
		}), /* @__PURE__ */ w("ellipse", {
			rx: "6",
			ry: "3",
			stroke: a.print,
			strokeWidth: "1.5",
			fill: "none"
		})] }),
		green: /* @__PURE__ */ w("path", {
			d: "M0 7Q-14-1-9-8 3-10 0 7M2 5Q0-7 11-9 16 3 2 5",
			fill: a.print
		}),
		yellow: /* @__PURE__ */ T("g", {
			fill: a.print,
			children: [
				/* @__PURE__ */ w("circle", { r: "4.5" }),
				/* @__PURE__ */ w("circle", {
					cx: "-9",
					cy: "-5",
					r: "3"
				}),
				/* @__PURE__ */ w("circle", {
					cx: "9",
					cy: "-5",
					r: "3"
				}),
				/* @__PURE__ */ w("circle", {
					cy: "7",
					r: "3"
				})
			]
		}),
		red: /* @__PURE__ */ w("path", {
			d: "M-11-7H-3V0H-11ZM3-7H11V0H3ZM-7 4H7V9H-7Z",
			fill: a.print
		})
	};
	return /* @__PURE__ */ T("g", {
		transform: `translate(${t} ${n}) scale(${r})`,
		opacity: i,
		children: [
			/* @__PURE__ */ w("ellipse", {
				cy: "7",
				rx: "23",
				ry: "14",
				fill: a.side
			}),
			/* @__PURE__ */ w("path", {
				d: "M-23 0V7A23 14 0 0 0 23 7V0",
				fill: a.side
			}),
			/* @__PURE__ */ w("ellipse", {
				rx: "23",
				ry: "14",
				fill: a.top,
				stroke: a.print,
				strokeWidth: "0.8"
			}),
			o[e]
		]
	});
}
function st({ x: e = 0, y: t = 0, spirit: n = !1, opacity: r = 1 }) {
	return /* @__PURE__ */ T("g", {
		transform: `translate(${e} ${t})`,
		opacity: r,
		children: [
			/* @__PURE__ */ w("path", {
				d: "M-8-9 2-14 11-9 1-4Z",
				fill: n ? "#fff5ce" : "#ffd393"
			}),
			/* @__PURE__ */ w("path", {
				d: "M-8-9 1-4V7L-8 2Z",
				fill: n ? "#b8aa8e" : "#b9703f"
			}),
			/* @__PURE__ */ w("path", {
				d: "M1-4 11-9V2L1 7Z",
				fill: n ? "#e2d8b7" : "#e69b52"
			})
		]
	});
}
function ct({ layers: e, animal: t, preview: n, x: r = 0, y: i = 0, scale: a = 1 }) {
	return /* @__PURE__ */ T("g", {
		transform: `translate(${r} ${i}) scale(${a})`,
		children: [
			e.map((e, t) => /* @__PURE__ */ w(ot, {
				terrain: e,
				y: -t * 10
			}, t)),
			n && /* @__PURE__ */ w(ot, {
				terrain: n,
				y: -e.length * 10 - 3,
				opacity: .62
			}),
			t && /* @__PURE__ */ w(st, {
				y: -(e.length - 1) * 10 - 8,
				spirit: t === "spirit"
			})
		]
	});
}
function lt(e) {
	return [...Array.from({ length: e.height - 1 }, () => e.terrain === "green" || e.terrain === "red" ? "brown" : e.terrain), e.terrain];
}
function ut({ card: e, rotation: t = 0, mirrored: n = !1, label: r }) {
	let i = e.pattern.map((e, r) => {
		let { q: i, r: a } = e;
		n && (a = -i - a);
		for (let e = 0; e < t; e++) [i, a] = [-a, i + a];
		return {
			part: e,
			target: r === 0,
			x: i * 44,
			y: (a + i / 2) * 34
		};
	}).sort((e, t) => e.y - t.y), a = Math.min(...i.map((e) => e.x)) - 27, o = Math.max(...i.map((e) => e.x)) + 27, s = Math.min(...i.map((e) => e.y - (e.part.height - 1) * 10 - (e.target ? 26 : 16))), c = Math.max(...i.map((e) => e.y)) + 23;
	return /* @__PURE__ */ w("svg", {
		className: "harmonies-habitat-diagram",
		viewBox: `${a} ${s} ${o - a} ${c - s}`,
		role: r ? "img" : void 0,
		"aria-label": r,
		"aria-hidden": !r,
		children: i.map(({ part: t, x: n, y: r, target: i }, a) => /* @__PURE__ */ T("g", { children: [/* @__PURE__ */ w("path", {
			d: `M${n - 26} ${r + 2}l13-16h26l13 16-13 18h-26Z`,
			fill: "#e9d9b2",
			stroke: "#c5b084"
		}), /* @__PURE__ */ w(ct, {
			layers: lt(t),
			x: n,
			y: r,
			animal: i ? e.spirit ? "spirit" : "animal" : void 0
		})] }, a))
	});
}
//#endregion
//#region src/games/harmonies/card.tsx
var dt = "(orientation: landscape) and (min-width: 1400px) and (min-height: 760px)", ft = (e) => {
	let t = window.matchMedia(dt);
	return t.addEventListener("change", e), () => t.removeEventListener("change", e);
};
function pt({ id: e, placed: t = 0, compact: r = !1, selected: i = !1, board: a, onClick: o }) {
	let l = c(), u = n().replace(/:/g, ""), d = F[e], f = s(ft, () => window.matchMedia(dt).matches, () => !1);
	r &&= !f;
	let p = r ? 192 : 278, m = r ? 91 : 178, h = d.spirit ? a && t ? q(a, d.spirit) : 0 : d.scores[t - 1] ?? 0, g = l(d.nameKey), _ = /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ T("svg", {
		viewBox: `0 0 180 ${p}`,
		className: "harmonies-card-face",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ w("defs", { children: /* @__PURE__ */ w("clipPath", {
				id: u,
				children: /* @__PURE__ */ w("rect", {
					width: "180",
					height: m,
					rx: "6"
				})
			}) }),
			/* @__PURE__ */ w("rect", {
				x: "1",
				y: "1",
				width: "178",
				height: p - 2,
				rx: "6",
				fill: "#fff7df",
				stroke: i ? "#287e79" : "#7d8b70",
				strokeWidth: i ? 3 : 1.5
			}),
			/* @__PURE__ */ w("g", {
				clipPath: `url(#${u})`,
				children: /* @__PURE__ */ w("svg", {
					width: "180",
					height: m,
					viewBox: "0 0 180 200",
					preserveAspectRatio: "xMidYMid slice",
					children: /* @__PURE__ */ w(at, { card: d })
				})
			}),
			/* @__PURE__ */ w("text", {
				x: "11",
				y: "23",
				fontSize: g.length > 12 ? 13 : 17,
				fontWeight: "750",
				fill: "#fff9de",
				stroke: "#59715d",
				strokeWidth: "2",
				paintOrder: "stroke",
				strokeLinejoin: "round",
				textLength: g.length > 19 ? 156 : void 0,
				lengthAdjust: "spacingAndGlyphs",
				children: g
			}),
			d.expansion && /* @__PURE__ */ w("circle", {
				cx: "166",
				cy: m - 10,
				r: "4",
				fill: "#f3e4b5"
			}),
			Array.from({ length: d.scores.length }, (e, n) => {
				let i = d.scores.length === 1 ? 90 : 22 + n * (136 / (d.scores.length - 1)), a = p - 17;
				return /* @__PURE__ */ T("g", { children: [
					/* @__PURE__ */ w("circle", {
						cx: i,
						cy: a,
						r: "12",
						fill: n < t ? "#fff9e7" : "#e5c191",
						stroke: n === t - 1 ? "#287e79" : "#b29972",
						strokeWidth: n === t - 1 ? 2 : 1
					}),
					/* @__PURE__ */ w("text", {
						x: i,
						y: a + 5,
						textAnchor: "middle",
						fontSize: r ? 17 : 14,
						fontWeight: "700",
						fill: "#354c43",
						children: d.spirit ? h : d.scores[n]
					}),
					n >= t && /* @__PURE__ */ w("g", {
						transform: `translate(${i} ${a - 18}) scale(.55)`,
						children: /* @__PURE__ */ w(st, { spirit: !!d.spirit })
					})
				] }, n);
			}),
			t === d.scores.length && /* @__PURE__ */ w("path", {
				d: "M151 30 159 38 173 21",
				fill: "none",
				stroke: "#f7e5a8",
				strokeWidth: "5",
				strokeLinecap: "round"
			})
		]
	}), /* @__PURE__ */ w("span", {
		className: "harmonies-card-habitat",
		style: {
			top: `${(m + 2) / p * 100}%`,
			height: `${(p - m - 39) / p * 100}%`
		},
		children: /* @__PURE__ */ w(ut, { card: d })
	})] }), v = `${g}, ${l("games.harmonies.cardProgress", {
		placed: t,
		n: d.scores.length
	})}, ${l("games.harmonies.points", { n: h })}${d.spirit ? `, ${l(he[d.spirit])}` : ""}`;
	return o ? /* @__PURE__ */ w("button", {
		type: "button",
		className: "harmonies-animal-card",
		"data-selected": i,
		"data-compact": r,
		"aria-label": v,
		"aria-pressed": i,
		onClick: o,
		children: _
	}) : /* @__PURE__ */ w("div", {
		className: "harmonies-animal-card",
		"data-compact": r,
		role: "img",
		"aria-label": v,
		children: _
	});
}
//#endregion
//#region src/games/harmonies/labels.ts
var Q = {
	gray: "games.harmonies.gray",
	blue: "games.harmonies.blue",
	brown: "games.harmonies.brown",
	green: "games.harmonies.green",
	yellow: "games.harmonies.yellow",
	red: "games.harmonies.red"
}, mt = {
	trees: "games.harmonies.trees",
	mountains: "games.harmonies.mountains",
	fields: "games.harmonies.fields",
	buildings: "games.harmonies.buildings",
	water: "games.harmonies.water",
	animals: "games.harmonies.animals",
	spirits: "games.harmonies.spiritScore"
};
//#endregion
//#region src/games/harmonies/view-player.tsx
function ht({ public: e, private: t, members: n, myRid: r, send: a }) {
	_();
	let { ref: s } = ne("hm-held"), m = c(), v = e, re = t, [se, ce] = o({
		owner: r,
		rid: r
	});
	se.owner !== r && ce({
		owner: r,
		rid: r
	});
	let y = se.owner === r ? se.rid : r, le = (e) => ce({
		owner: r,
		rid: e
	}), [b, x] = o(null), [S, E] = o(null), [ue, de] = o(null), [D, fe] = o(null), [pe, O] = o(0), [k, A] = o("market"), [j, M] = o(!1), [N, me] = o(!1), [P, ge] = o(null), [I, L] = o({
		rotation: 0,
		mirrored: !1
	}), [R, _e] = o(""), ve = `${v.serial}:${y}:${v.turn.held.join(",")}`;
	R !== ve && (_e(ve), x(null), de(null), fe(null), O(0), E(v.current === r ? v.turn.held[0] ?? null : null), M(!1));
	let B = v.players.find((e) => e.rid === y) ?? v.players[0], V = v.players.find((e) => e.rid === r), ye = v.current === r && v.phase === "play", be = ye && !!V && !V.spiritChosen, H = ye && y === r && !be;
	te(ye, ee);
	let xe = (e) => n.find((t) => t.rid === e)?.name ?? e, Se = B.cards.filter((e) => e.placed < F[e.id].scores.length), Ce = B.cards.filter((e) => e.placed >= F[e.id].scores.length), we = V?.cards.filter((e) => e.placed < F[e.id].scores.length).length ?? 0, U = i(() => D && H && B.cards.some((e) => e.id === D && e.placed < F[D].scores.length) ? De(B.board, F[D], v.config.pulse) : [], [
		D,
		H,
		B.board,
		B.cards,
		v.config.pulse
	]), W = U.filter((e) => e.key === b), G = W.length ? W[pe % W.length] : null, Ee = i(() => H ? D ? new Set(U.map((e) => e.key)) : S ? new Set(z.filter(({ key: e }) => Te(B.board, e, S)).map((e) => e.key)) : void 0 : void 0, [
		H,
		D,
		U,
		S,
		B.board
	]), K = i(() => G ? new Set(G.keys) : void 0, [G]), Oe = b ? B.board[b] : void 0, q = H && !D && S && b && Ee?.has(b) ? {
		key: b,
		terrain: S
	} : null, ke = H && v.turn.drafted && v.turn.held.length === 0, Ae = H && !v.turn.drafted && ue !== null && v.groups[ue]?.length === 3, je = !!q, J = P ? F[P.id] : null, Me = P ? B.cards.find((e) => e.id === P.id) : void 0, Ne = H && P?.market !== void 0 && v.market[P.market] === P.id && !v.turn.tookCard && we < 4, Y = m(k === "card" && J ? J.nameKey : k === "market" ? "games.harmonies.market" : k === "completed" ? "games.harmonies.completedCards" : k === "replace" ? "games.harmonies.replaceChoice" : "games.harmonies.scoring"), X = (e) => {
		A(e), M(!0);
	}, Pe = (e, t) => {
		ge({
			id: e,
			market: t
		}), L({
			rotation: 0,
			mirrored: !1
		}), X("card");
	}, Fe = (e) => {
		E(e), fe(null), de(null), O(0);
	}, Ie = (e) => {
		x(e), O(0);
	}, Le = (e) => {
		fe(e), E(null), de(null), x(null), O(0), M(!1);
	}, Re = () => {
		v.players.length === 1 && !v.turn.tookCard && v.market.some((e) => e !== null) ? X("replace") : a({ type: "endTurn" });
	}, ze = () => {
		if (G && D) {
			a({
				type: "animal",
				card: D,
				key: G.key,
				rotation: G.rotation,
				mirrored: G.mirrored
			}), x(null);
			return;
		}
		if (q) {
			a({
				type: "place",
				terrain: q.terrain,
				key: q.key
			});
			return;
		}
		if (Ae) {
			a({
				type: "draft",
				group: ue
			});
			return;
		}
		ke && Re();
	}, Be = m(G && D ? F[D].spirit ? "games.harmonies.spiritConfirm" : "games.harmonies.animalConfirm" : q ? "games.harmonies.placeConfirm" : Ae ? "games.harmonies.draftConfirm" : ke ? "games.harmonies.endTurn" : v.turn.drafted ? "games.harmonies.placeConfirm" : "games.harmonies.draftPrompt"), Ve = (e) => {
		let t = B.board[e];
		return t?.layers.length ? `${t.layers.map((e) => m(Q[e])).join(" → ")}${t.animal ? `, ${m(t.animal === "spirit" ? "games.harmonies.spiritPresent" : "games.harmonies.animalPresent")}` : ""}` : m("games.harmonies.emptyCell");
	}, He = (e) => {
		let t = xe(e.rid), n = e.card ? F[e.card].nameKey : null;
		switch (e.kind) {
			case "draft": return m("games.harmonies.logDraft", {
				name: t,
				n: e.n ?? 0
			});
			case "place": return m("games.harmonies.logPlace", {
				name: t,
				terrain: e.terrain ? m(Q[e.terrain]) : ""
			});
			case "takeCard": return m("games.harmonies.logTake", {
				name: t,
				animal: n ? m(n) : ""
			});
			case "animal": return m("games.harmonies.logAnimal", {
				name: t,
				animal: n ? m(n) : ""
			});
			case "spirit": return m("games.harmonies.logSpirit", {
				name: t,
				animal: n ? m(n) : ""
			});
			case "endTurn": return m("games.harmonies.logEnd", { name: t });
		}
	}, Z = (e = !1) => /* @__PURE__ */ w("div", {
		className: "harmonies-sheet-cards",
		children: v.market.map((t, n) => t === null ? null : /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w(pt, {
			id: t,
			onClick: () => e ? a({
				type: "endTurn",
				discard: n
			}) : Pe(t, n)
		}), e && /* @__PURE__ */ w("button", {
			className: "btn-quiet harmonies-replace-button",
			onClick: () => a({
				type: "endTurn",
				discard: n
			}),
			children: m("games.harmonies.replaceCard")
		})] }, t))
	});
	return /* @__PURE__ */ T(ie, {
		adaptive: !0,
		scroll: !1,
		className: "harmonies-screen",
		children: [
			/* @__PURE__ */ T("div", {
				className: "harmonies-game",
				children: [
					/* @__PURE__ */ w(g, {
						className: "absolute inset-0 pointer-events-none",
						kind: "sheen",
						base: "#f6f1e3"
					}),
					/* @__PURE__ */ T("header", {
						className: "harmonies-header",
						children: [
							/* @__PURE__ */ T("div", {
								className: "harmonies-brand",
								children: [/* @__PURE__ */ w("strong", { children: m("games.harmonies.name") }), /* @__PURE__ */ w("span", { children: "H A R M O N I E S" })]
							}),
							/* @__PURE__ */ T("div", {
								className: "harmonies-phase",
								"data-active": ye,
								role: "status",
								children: [/* @__PURE__ */ w("span", { children: m(v.lastRound ? "games.harmonies.finalRound" : "games.harmonies.round", { n: v.round }) }), /* @__PURE__ */ w("strong", { children: m(ye ? "games.harmonies.yourTurn" : "games.harmonies.waiting", { name: xe(v.current) }) })]
							}),
							/* @__PURE__ */ w("div", {
								className: "harmonies-players",
								children: /* @__PURE__ */ w(ae, {
									members: n,
									myRid: r,
									variant: "mini",
									scroll: !0,
									adaptive: !0,
									onPick: le,
									picked: (e) => e === y,
									action: (e) => e === v.current ? "pending" : null,
									status: (e) => /* @__PURE__ */ w("span", {
										className: "harmonies-player-score",
										children: m("games.harmonies.points", { n: v.players.find((t) => t.rid === e)?.score.total ?? 0 })
									})
								})
							})
						]
					}),
					/* @__PURE__ */ T("main", {
						className: "harmonies-main",
						children: [
							/* @__PURE__ */ T("aside", {
								className: "harmonies-public",
								children: [
									/* @__PURE__ */ T("div", {
										className: "harmonies-section-title harmonies-public-title",
										children: [/* @__PURE__ */ w("h2", { children: m("games.harmonies.supply") }), /* @__PURE__ */ w("span", { children: m("games.harmonies.bagLeft", { n: v.bagLeft }) })]
									}),
									/* @__PURE__ */ w("div", {
										className: "harmonies-supplies",
										children: v.groups.map((e, t) => /* @__PURE__ */ w("button", {
											type: "button",
											className: "harmonies-supply",
											"data-selected": ue === t,
											disabled: !H || v.turn.drafted || !e,
											"aria-label": `${t + 1}. ${e?.map((e) => m(Q[e])).join(", ") ?? m("games.harmonies.emptyCell")}`,
											"aria-pressed": ue === t,
											onClick: () => {
												de(t), E(null), fe(null), x(null);
											},
											children: /* @__PURE__ */ T("svg", {
												viewBox: "0 0 175 45",
												"aria-hidden": "true",
												children: [e?.map((e, t) => /* @__PURE__ */ w(ot, {
													terrain: e,
													x: 34 + t * 53,
													y: 20 + t % 2 * 2,
													scale: .85
												}, t)), ue === t && /* @__PURE__ */ w("path", {
													d: "M153 7 159 13 169 3",
													stroke: "#287e79",
													strokeWidth: "3",
													fill: "none"
												})]
											})
										}, t))
									}),
									/* @__PURE__ */ T("div", {
										className: "harmonies-market",
										children: [/* @__PURE__ */ w("div", {
											className: "harmonies-section-title",
											children: /* @__PURE__ */ w("h2", { children: m("games.harmonies.market") })
										}), /* @__PURE__ */ w("div", {
											className: "harmonies-market-cards",
											children: v.market.map((e, t) => e === null ? /* @__PURE__ */ w("div", { className: "harmonies-card-space" }, `empty-${t}`) : /* @__PURE__ */ w(pt, {
												id: e,
												compact: !0,
												onClick: () => Pe(e, t)
											}, e))
										})]
									})
								]
							}),
							/* @__PURE__ */ T("section", {
								className: "harmonies-landscape",
								children: [/* @__PURE__ */ T("div", {
									className: "harmonies-section-title harmonies-landscape-title",
									children: [/* @__PURE__ */ w("h2", { children: m("games.harmonies.landscape", { name: xe(B.rid) }) }), /* @__PURE__ */ T("div", {
										className: "harmonies-tools",
										children: [
											/* @__PURE__ */ w("span", { children: v.config.side }),
											/* @__PURE__ */ w("button", {
												className: "btn-quiet",
												"aria-label": m("games.harmonies.scoring"),
												onClick: () => X("score"),
												children: /* @__PURE__ */ w(d, { size: 20 })
											}),
											/* @__PURE__ */ w("button", {
												className: "btn-quiet",
												"aria-label": m("common.log.title"),
												onClick: () => me(!0),
												children: /* @__PURE__ */ w(f, { size: 20 })
											})
										]
									})]
								}), /* @__PURE__ */ w("div", {
									className: "harmonies-board-area",
									children: /* @__PURE__ */ w(Qe, {
										rid: B.rid,
										board: B.board,
										selected: b,
										legal: Ee,
										preview: q,
										habitat: K,
										animalPreview: G && D ? {
											key: G.key,
											spirit: !!F[D].spirit
										} : null,
										label: m("games.harmonies.boardLabel"),
										resetLabel: m("games.harmonies.resetCamera"),
										cellLabel: (e) => m("games.harmonies.cellLabel", {
											n: z.findIndex((t) => t.key === e) + 1,
											stack: Ve(e)
										}),
										onSelect: Ie
									})
								})]
							}),
							/* @__PURE__ */ T("aside", {
								className: "harmonies-personal",
								children: [
									/* @__PURE__ */ T("div", {
										className: "harmonies-section-title",
										children: [
											/* @__PURE__ */ w("h2", { children: m(y === r ? "games.harmonies.myCards" : "games.harmonies.cardsOf", { name: xe(B.rid) }) }),
											/* @__PURE__ */ w("button", {
												className: "btn-quiet harmonies-market-open",
												onClick: () => X("market"),
												children: m("games.harmonies.market")
											}),
											/* @__PURE__ */ w("span", {
												className: "harmonies-active-count",
												children: m("games.harmonies.incomplete", { n: Se.length })
											})
										]
									}),
									/* @__PURE__ */ T("div", {
										className: "harmonies-personal-cards",
										children: [
											Se.map((e) => /* @__PURE__ */ w(pt, {
												id: e.id,
												placed: e.placed,
												board: B.board,
												selected: D === e.id,
												compact: !0,
												onClick: () => Pe(e.id)
											}, e.id)),
											Se.length === 0 && /* @__PURE__ */ w("p", {
												className: "harmonies-no-cards",
												children: m("games.harmonies.noCards")
											}),
											Ce.length > 0 && /* @__PURE__ */ T("button", {
												className: "harmonies-completed",
												onClick: () => X("completed"),
												children: [/* @__PURE__ */ w("span", {
													"aria-hidden": !0,
													children: "❧"
												}), /* @__PURE__ */ w("strong", { children: m("games.harmonies.completed", { n: Ce.length }) })]
											})
										]
									}),
									/* @__PURE__ */ T("button", {
										className: "harmonies-score-line",
										onClick: () => X("score"),
										children: [
											/* @__PURE__ */ T("span", { children: [
												m("games.harmonies.animals"),
												" ",
												B.score.animals
											] }),
											/* @__PURE__ */ T("span", { children: [
												m("games.harmonies.spiritScore"),
												" ",
												B.score.spirits
											] }),
											/* @__PURE__ */ w("strong", { children: m("games.harmonies.points", { n: B.score.total }) })
										]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ T("footer", {
						className: "harmonies-actions",
						children: [/* @__PURE__ */ T("div", {
							className: "harmonies-held",
							children: [/* @__PURE__ */ w("span", { children: m("games.harmonies.held") }), /* @__PURE__ */ w("div", {
								ref: s,
								children: Array.from({ length: 3 }, (e, t) => /* @__PURE__ */ w("button", {
									type: "button",
									className: "harmonies-held-token",
									"data-selected": S !== null && v.turn.held[t] === S,
									disabled: !H || !v.turn.held[t],
									"aria-label": v.turn.held[t] ? m(Q[v.turn.held[t]]) : m("games.harmonies.emptyCell"),
									"aria-pressed": S !== null && v.turn.held[t] === S,
									onClick: () => Fe(v.turn.held[t]),
									children: v.turn.held[t] && /* @__PURE__ */ w("svg", {
										viewBox: "-27 -20 54 45",
										"aria-hidden": "true",
										children: /* @__PURE__ */ w(ot, { terrain: v.turn.held[t] })
									})
								}, t))
							})]
						}), /* @__PURE__ */ T("div", {
							className: "harmonies-selection",
							children: [/* @__PURE__ */ w("div", {
								className: "harmonies-selection-info",
								children: b ? /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ T("span", { children: [
									m("games.harmonies.selectedCell"),
									" · ",
									z.findIndex((e) => e.key === b) + 1
								] }), /* @__PURE__ */ T("div", {
									className: "harmonies-stack-detail",
									children: [/* @__PURE__ */ w("svg", {
										viewBox: "-30 -48 60 72",
										"aria-hidden": "true",
										children: /* @__PURE__ */ w(ct, {
											layers: Oe?.layers ?? [],
											animal: Oe?.animal,
											preview: q?.terrain
										})
									}), /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w("strong", { children: m("games.harmonies.layers", { n: (Oe?.layers.length ?? 0) + +!!q }) }), /* @__PURE__ */ w("small", { children: [...Oe?.layers ?? [], ...q ? [q.terrain] : []].map((e) => m(Q[e])).join(" · ") || m("games.harmonies.emptyCell") })] })]
								})] }) : /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("span", { children: m(D ? F[D].nameKey : "games.harmonies.stack") }), /* @__PURE__ */ w("strong", {
									className: "harmonies-action-prompt",
									children: D ? m(U.length ? "games.harmonies.matchCount" : "games.harmonies.noHabitat", { n: new Set(U.map((e) => e.key)).size }) : m(v.turn.drafted ? v.turn.held.length ? "games.harmonies.placePrompt" : "games.harmonies.optionalPrompt" : "games.harmonies.draftPrompt")
								})] })
							}), /* @__PURE__ */ T("div", {
								className: "harmonies-action-buttons",
								children: [
									W.length > 1 && /* @__PURE__ */ w("button", {
										className: "btn-quiet harmonies-match-cycle",
										"aria-label": m("games.harmonies.nextMatch"),
										onClick: () => O((e) => e + 1),
										children: /* @__PURE__ */ w(h, { size: 20 })
									}),
									/* @__PURE__ */ w("button", {
										type: "button",
										className: "btn-base harmonies-primary",
										disabled: !H || !(G || je || Ae || ke),
										onClick: ze,
										children: Be
									}),
									ke && (G || je) && /* @__PURE__ */ w("button", {
										className: "btn-quiet harmonies-end-secondary",
										onClick: Re,
										children: m("games.harmonies.endTurn")
									})
								]
							})]
						})]
					})
				]
			}),
			N && /* @__PURE__ */ w(oe, {
				log: v.log,
				line: He,
				onClose: () => me(!1)
			}),
			/* @__PURE__ */ T(l, {
				open: j,
				onClose: () => M(!1),
				label: Y,
				title: Y,
				tall: !0,
				footer: k === "card" && J ? /* @__PURE__ */ T("div", {
					className: "harmonies-sheet-footer",
					children: [Ne && /* @__PURE__ */ w("button", {
						className: "btn-base harmonies-primary",
						onClick: () => {
							a({
								type: "takeCard",
								index: P.market
							}), M(!1);
						},
						children: m("games.harmonies.takeCard")
					}), H && Me && Me.placed < J.scores.length && /* @__PURE__ */ w("button", {
						className: "btn-base harmonies-primary",
						onClick: () => Le(J.id),
						children: m("games.harmonies.findHabitat")
					})]
				}) : void 0,
				children: [
					k === "market" && Z(),
					k === "card" && J && /* @__PURE__ */ T("div", {
						className: "harmonies-card-inspect",
						children: [
							/* @__PURE__ */ w(pt, {
								id: J.id,
								placed: Me?.placed,
								board: B.board
							}),
							J.spirit && /* @__PURE__ */ w("p", { children: m(he[J.spirit]) }),
							/* @__PURE__ */ w("div", {
								className: "harmonies-diagram-inspect",
								children: /* @__PURE__ */ w(ut, {
									card: J,
									rotation: I.rotation,
									mirrored: I.mirrored,
									label: m("games.harmonies.target")
								})
							}),
							/* @__PURE__ */ T("div", {
								className: "harmonies-diagram-buttons",
								children: [/* @__PURE__ */ T("button", {
									className: "btn-quiet",
									onClick: () => L((e) => ({
										...e,
										rotation: (e.rotation + 1) % 6
									})),
									children: [/* @__PURE__ */ w(h, { size: 20 }), m("games.harmonies.rotate")]
								}), v.config.pulse && /* @__PURE__ */ T("button", {
									className: "btn-quiet",
									"aria-pressed": I.mirrored,
									onClick: () => L((e) => ({
										...e,
										mirrored: !e.mirrored
									})),
									children: [/* @__PURE__ */ w(p, { size: 20 }), m("games.harmonies.mirror")]
								})]
							})
						]
					}),
					k === "completed" && /* @__PURE__ */ w("div", {
						className: "harmonies-sheet-cards",
						children: Ce.map((e) => /* @__PURE__ */ w(pt, {
							id: e.id,
							placed: e.placed,
							board: B.board,
							onClick: () => Pe(e.id)
						}, e.id))
					}),
					k === "replace" && /* @__PURE__ */ T(C, { children: [
						/* @__PURE__ */ w("p", { children: m("games.harmonies.soloReplaceHint") }),
						Z(!0),
						/* @__PURE__ */ w("button", {
							className: "btn-quiet",
							onClick: () => a({ type: "endTurn" }),
							children: m("games.harmonies.noReplace")
						})
					] }),
					k === "score" && /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ T("div", {
						className: "harmonies-score-table",
						children: [Object.entries(mt).map(([e, t]) => /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w("span", { children: m(t) }), /* @__PURE__ */ w("strong", { children: B.score[e] })] }, e)), /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w("span", { children: m("games.harmonies.total") }), /* @__PURE__ */ w("strong", { children: B.score.total })] })]
					}), /* @__PURE__ */ w("p", { children: m(v.config.side === "A" ? "games.harmonies.riverLength" : "games.harmonies.islands", { n: v.config.side === "A" ? B.score.river : B.score.islands }) })] })
				]
			}),
			/* @__PURE__ */ w(l, {
				open: be,
				label: m("games.harmonies.chooseSpirit"),
				title: m("games.harmonies.chooseSpirit"),
				tall: !0,
				children: /* @__PURE__ */ w("div", {
					className: "harmonies-spirit-choices",
					children: re?.spirits.map((e) => /* @__PURE__ */ T("div", { children: [
						/* @__PURE__ */ w(pt, { id: e }),
						/* @__PURE__ */ w("p", { children: m(he[F[e].spirit]) }),
						/* @__PURE__ */ T("button", {
							className: "btn-base harmonies-primary",
							onClick: () => a({
								type: "chooseSpirit",
								card: e
							}),
							children: [/* @__PURE__ */ w(u, { size: 20 }), m("games.harmonies.chooseThisSpirit")]
						})
					] }, e))
				})
			}),
			/* @__PURE__ */ T("span", {
				className: "sr-only",
				children: [/* @__PURE__ */ w(d, { "aria-hidden": !0 }), m("games.harmonies.stackOrder")]
			})
		]
	});
}
//#endregion
//#region src/games/harmonies/bot-search.ts
var gt = {
	width: 6,
	animalWeight: 2.4,
	costWeight: .65,
	futureDiscount: .8,
	materialWeight: .6,
	spaceWeight: .3,
	cardTax: .8,
	finishWeight: .2
}, _t = [
	"gray",
	"blue",
	"brown",
	"green",
	"yellow",
	"red"
], $ = [
	[],
	["gray"],
	["gray", "gray"],
	[
		"gray",
		"gray",
		"gray"
	],
	["blue"],
	["brown"],
	["brown", "brown"],
	["green"],
	["brown", "green"],
	[
		"brown",
		"brown",
		"green"
	],
	["yellow"],
	["red"],
	["red", "red"]
], vt = $.map((e) => e.length ? _t.indexOf(e.at(-1)) : -1), yt = $.map((e) => e.length), bt = [
	0,
	1,
	3,
	7
], xt = new Map(z.map((e, t) => [e.key, t])), St = z.map((e) => U(e.key).map((e) => xt.get(e))), Ct = $.map((e) => _t.map((t) => Te({ [z[0].key]: { layers: e } }, z[0].key, t) ? t === "red" && e.length === 1 ? 12 : $.findIndex((n) => n.join() === [...e, t].join()) : -1)), wt = $.map((e) => $.map((t) => {
	if (e.length === t.length && e.at(-1) === t.at(-1)) return 0;
	if (!t.length || e.length >= t.length) return Infinity;
	let n = t.at(-1);
	return n === "green" ? e.every((e) => e === "brown") ? t.length - e.length : Infinity : n === "gray" ? e.every((e) => e === "gray") ? t.length - e.length : Infinity : n === "red" && t.length === 2 ? e.length ? [
		"gray",
		"brown",
		"red"
	].includes(e[0]) ? 1 : Infinity : 2 : e.length ? Infinity : 1;
})), Tt = /* @__PURE__ */ new Map();
function Et(e, t) {
	let n = `${e.id}:${t}`, r = Tt.get(n);
	if (r) return r;
	let i = [], a = /* @__PURE__ */ new Set();
	for (let n = 0; n < z.length; n++) for (let r = 0; r < (t ? 2 : 1); r++) for (let t = 0; t < 6; t++) {
		let o = e.pattern.map((e) => {
			let i = G(e, t, r === 1);
			return {
				cell: xt.get(`${z[n].q + i.q},${z[n].r + i.r}`) ?? -1,
				stack: $.findIndex((e) => e.length === i.height && e.at(-1) === i.terrain)
			};
		});
		if (o.some((e) => e.cell < 0)) continue;
		let s = `${n}:${o.map((e) => `${e.cell}/${e.stack}`).sort().join(";")}`;
		a.has(s) || (a.add(s), i.push({
			anchor: n,
			parts: o,
			rotation: t,
			mirrored: r === 1
		}));
	}
	return Tt.set(n, i), i;
}
function Dt(e) {
	let t = 0;
	return {
		cells: z.map(({ key: n }, r) => {
			let i = e[n];
			i?.animal && (t |= 1 << r);
			let a = i?.layers ?? [];
			return a.length === 2 && a[1] === "red" ? 12 : $.findIndex((e) => e.join() === a.join());
		}),
		occupied: t
	};
}
function Ot(e, t) {
	let n = 0, r = [];
	for (let i = 0; i < e.length; i++) {
		if (n & 1 << i || !t(i)) continue;
		let e = [i];
		n |= 1 << i;
		for (let r = 0; r < e.length; r++) for (let i of St[e[r]]) !(n & 1 << i) && t(i) && (n |= 1 << i, e.push(i));
		r.push(e.length);
	}
	return r;
}
function kt(e, t, n) {
	let r = 0, i = 0, a = 0, o = 0, s = Ot(e, (t) => vt[e[t]] === 4), c = Ot(e, (t) => e[t] === 12), l = Ot(e, (t) => e[t] === 4);
	r += s.filter((e) => e >= 2).length * 5, i += s.filter((e) => e === 1).length;
	for (let t = 0; t < e.length; t++) {
		let s = e[t], c = vt[s], l = yt[s];
		if (s || a++, c === 3 && (r += bt[l]), c === 0 && (St[t].some((t) => vt[e[t]] === 0) ? r += bt[l] : i += bt[l] * .5), (s === 5 || s === 6) && (i += s === 5 ? 1.3 : 3.4), s === 11 && (i += 1), s === 12) {
			let n = 0;
			for (let r of St[t]) vt[e[r]] >= 0 && (n |= 1 << vt[e[r]]);
			let a = 0;
			for (; n; n &= n - 1) a++;
			a >= 3 ? r += 5 : i += a * .8;
		}
		n === "deer" && c === 3 && l >= 2 && (o += 4), n === "owl" && c === 3 && (o += l === 3 ? 1 : 3), n === "bear" && c === 0 && (o += l === 3 ? 1 : 3), n === "ibex" && c === 0 && l >= 2 && (o += 4), n === "tortoise" && c === 1 && (o += 2);
	}
	if (t === "B") r += Math.max(1, Ot(e, (t) => vt[e[t]] !== 1).length) * 5;
	else {
		let t = 0;
		for (let n = 0; n < e.length; n++) if (e[n] === 4) {
			let r = new Int8Array(e.length), i = [n];
			r[n] = 1;
			for (let n = 0; n < i.length; n++) {
				let a = i[n];
				t = Math.max(t, r[a]);
				for (let t of St[a]) e[t] === 4 && !r[t] && (r[t] = r[a] + 1, i.push(t));
			}
		}
		r += t > 6 ? 15 + (t - 6) * 4 : [
			0,
			0,
			2,
			5,
			8,
			11,
			15
		][t];
	}
	return n === "crane" && (o = c.filter((e) => e >= 2).length * 6), n === "cat" && (o = c.filter((e) => e === 1).length * 4), n === "dragonfly" && (o = l.filter((e) => e >= 2).length * 7), n === "butterfly" && (o = s.length * 5), n === "lion" && (o = s.reduce((e, t) => e + (t >= 3 ? 10 : 2), 0)), {
		score: r,
		spirit: o,
		material: i,
		empty: a
	};
}
function At(e, t) {
	if (e.occupied & 1 << t.anchor) return Infinity;
	let n = 0;
	for (let r of t.parts) {
		let t = wt[e.cells[r.cell]][r.stack];
		if (t && e.occupied & 1 << r.cell || (n += t, !Number.isFinite(n))) return Infinity;
	}
	return n;
}
function jt(e) {
	return `${e.cells.map((e) => e.toString(16)).join("")}/${e.occupied}/${e.cards.map((e) => `${e.id}:${e.placed}`).join(",")}/${[...e.held].sort().join("")}/${e.took}`;
}
function Mt(e, t, n) {
	let r = e.players.find((e) => e.rid === t), i = r.cards.find((e) => F[e.id].spirit), a = i ? F[i.id].spirit : void 0, o = {
		...Dt(r.board),
		cards: r.cards.map((e) => ({ ...e })),
		held: e.turn.held.map((e) => _t.indexOf(e)),
		took: e.turn.tookCard,
		actions: [],
		value: 0
	}, s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = (e, t) => e.spirit + t * 1.5;
	function u(t) {
		let r = jt(t), i = c.get(r);
		if (i !== void 0) return i;
		let o = t.cells.map((e) => e.toString(16)).join(""), u = s.get(o);
		u || (u = kt(t.cells, e.config.side, a), s.set(o, u));
		let d = e.lastRound || u.empty <= 2 || e.bagLeft < (e.players.length === 1 ? 9 : 3) ? 0 : Math.min(e.bagLeft / (e.players.length === 1 ? 9 : 3 * e.players.length), (u.empty - 2) * .8), f = d > 0 ? n.animalWeight : 1, p = t.cards.find((e) => F[e.id].spirit && e.placed), m = u.score + (p ? l(u, d) * f : 0) + (d ? u.material * n.materialWeight + u.empty * n.spaceWeight : 0), h = [];
		for (let n = 0; n < t.cards.length; n++) {
			let r = t.cards[n], i = F[r.id];
			if (i.spirit || (m += (i.scores[r.placed - 1] ?? 0) * f), r.placed >= i.scores.length) continue;
			let a = Array(z.length).fill(Infinity);
			for (let n of Et(i, e.config.pulse)) {
				let e = At(t, n);
				e < a[n.anchor] && (a[n.anchor] = e);
			}
			for (let e = 0; e < a.length; e++) Number.isFinite(a[e]) && h.push({
				anchor: e,
				cost: a[e],
				card: n
			});
		}
		let g = /* @__PURE__ */ new Map(), _ = /* @__PURE__ */ new Set();
		for (let e = 0; e < 15; e++) {
			let e, r = 0;
			for (let i of h) {
				if (_.has(i.anchor)) continue;
				let a = t.cards[i.card], o = F[a.id], s = g.get(i.card) ?? 0;
				if (a.placed + s >= o.scores.length) continue;
				let c = o.spirit ? l(u, d) : o.scores[a.placed + s] - (o.scores[a.placed + s - 1] ?? 0), f = d * 1.6 + t.held.length, p = c * (i.cost === 0 ? 1 : Math.max(0, 1 - i.cost / Math.max(1, f))) * n.futureDiscount ** s / (1 + i.cost * n.costWeight);
				p > r && (r = p, e = i);
			}
			if (!e) break;
			_.add(e.anchor), g.set(e.card, (g.get(e.card) ?? 0) + 1), m += r * f;
		}
		return m -= t.cards.filter((e) => e.placed < F[e.id].scores.length && !F[e.id].spirit).length * n.cardTax, c.set(r, m), m;
	}
	function d(e, t = n.width) {
		let r = /* @__PURE__ */ new Map();
		for (let t of e) {
			let e = jt(t);
			r.has(e) || (t.value = u(t), r.set(e, t));
		}
		return [...r.values()].sort((e, t) => t.value - e.value).slice(0, t);
	}
	function f(t, n = !0) {
		let r = [];
		for (let n = 0; n < t.cards.length; n++) {
			let i = t.cards[n], a = F[i.id];
			if (i.placed >= a.scores.length) continue;
			let o = 0;
			for (let s of Et(a, e.config.pulse)) !(o & 1 << s.anchor) && At(t, s) === 0 && (o |= 1 << s.anchor, r.push({
				...t,
				occupied: t.occupied | 1 << s.anchor,
				cards: t.cards.map((e, t) => t === n ? {
					...e,
					placed: e.placed + 1
				} : e),
				actions: [...t.actions, {
					type: "animal",
					card: i.id,
					key: z[s.anchor].key,
					rotation: s.rotation,
					mirrored: s.mirrored
				}]
			}));
		}
		if (n && !t.took && t.cards.filter((e) => e.placed < F[e.id].scores.length).length < 4) for (let n = 0; n < e.market.length; n++) {
			let i = e.market[n];
			i === null || t.cards.some((e) => e.id === i) || r.push({
				...t,
				took: !0,
				cards: [...t.cards, {
					id: i,
					placed: 0
				}],
				actions: [...t.actions, {
					type: "takeCard",
					index: n
				}]
			});
		}
		return r;
	}
	let p, m = e.turn.drafted ? [o] : e.groups.flatMap((e, t) => e?.length === 3 ? [{
		...o,
		held: e.map((e) => _t.indexOf(e)),
		actions: [{
			type: "draft",
			group: t
		}]
	}] : []);
	for (let t of m) {
		let r = d([t, ...f(t)]);
		for (let e = 0; e < t.held.length && r.length; e++) {
			r = d(r.flatMap((e) => [e, ...f(e)]));
			let e = [];
			for (let t of r) for (let n of new Set(t.held)) for (let r = 0; r < z.length; r++) {
				if (t.occupied & 1 << r) continue;
				let i = Ct[t.cells[r]][n];
				if (i < 0) continue;
				let a = [...t.cells], o = [...t.held];
				a[r] = i, o.splice(o.indexOf(n), 1), e.push({
					...t,
					cells: a,
					held: o,
					actions: [...t.actions, {
						type: "place",
						terrain: _t[n],
						key: z[r].key
					}]
				});
			}
			r = d(e);
		}
		if (!r.length) continue;
		let i = (t) => {
			let r = kt(t.cells, e.config.side, a), i = r.score + (t.cards.some((e) => F[e.id].spirit && e.placed) ? r.spirit : 0);
			for (let e of t.cards) F[e.id].spirit || (i += F[e.id].scores[e.placed - 1] ?? 0);
			return u(t) + i * n.finishWeight;
		};
		for (let e = 0; e < z.length + 1; e++) {
			let e = r.flatMap((e) => [e, ...f(e)]), t = r[0];
			if (r = [...new Map(e.map((e) => [jt(e), e])).values()].map((e) => ({
				...e,
				value: i(e)
			})).sort((e, t) => t.value - e.value).slice(0, n.width), jt(r[0]) === jt(t)) break;
		}
		let o = r[0];
		(!p || o.value > p.value) && (p = o);
	}
	if (!p) return [];
	let h;
	if (e.players.length === 1 && !p.took) {
		let t = e.market.flatMap((e, t) => e === null ? [] : [{
			i: t,
			value: u({
				...p,
				cards: [...p.cards, {
					id: e,
					placed: 0
				}],
				took: !0
			})
		}]);
		t.sort((e, t) => e.value - t.value), h = t[0]?.i;
	}
	return [...p.actions, {
		type: "endTurn",
		...h === void 0 ? {} : { discard: h }
	}];
}
function Nt(e, t) {
	let n = e.players.find((e) => e.rid === t), { cells: r, occupied: i } = Dt(n.board);
	return JSON.stringify([
		t,
		e.phase,
		e.current,
		e.serial,
		e.config,
		r,
		i,
		n.cards,
		e.turn,
		e.groups,
		e.market,
		e.lastRound,
		e.bagLeft
	]);
}
function Pt(e, t, n) {
	let r = structuredClone(e), i = r.players.find((e) => e.rid === t);
	switch (n.type) {
		case "draft":
			r.turn.drafted = !0, r.turn.held = r.groups[n.group], r.groups[n.group] = null;
			break;
		case "takeCard":
			i.cards.push({
				id: r.market[n.index],
				placed: 0
			}), r.market[n.index] = null, r.turn.tookCard = !0;
			break;
		case "place":
			r.turn.held.splice(r.turn.held.indexOf(n.terrain), 1), i.board[n.key] = { layers: [...i.board[n.key]?.layers ?? [], n.terrain] };
			break;
		case "animal": i.cards.find((e) => e.id === n.card).placed++, i.board[n.key].animal = F[n.card].spirit ? "spirit" : "animal";
	}
	return Nt(r, t);
}
function Ft(e = gt) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid);
		if (r.phase !== "play" || r.current !== n.rid || !i) return null;
		if (!i.spiritChosen) {
			let a = t.private?.spirits ?? [], o = a[0], s = -Infinity;
			for (let t of a) {
				let a = [...i.cards, {
					id: t,
					placed: 0
				}], c = Mt({
					...r,
					players: r.players.map((e) => e.rid === n.rid ? {
						...e,
						cards: a,
						spiritChosen: !0
					} : e)
				}, n.rid, e), l = structuredClone(i.board);
				for (let e of c) e.type === "place" && (l[e.key] = { layers: [...l[e.key]?.layers ?? [], e.terrain] });
				let u = kt(Dt(l).cells, r.config.side, F[t].spirit), d = u.score + u.spirit * .7 + u.material;
				d > s && (s = d, o = t);
			}
			return o === void 0 ? null : {
				action: {
					type: "chooseSpirit",
					card: o
				},
				memory: null
			};
		}
		let a = n.memory, o = a?.harmoniesPlan && a.expected === Nt(r, n.rid) ? a.actions : Mt(r, n.rid, e), s = o[0];
		return s ? {
			action: s,
			memory: s.type === "endTurn" ? null : {
				harmoniesPlan: !0,
				expected: Pt(r, n.rid, s),
				actions: o.slice(1)
			}
		} : null;
	};
}
//#endregion
//#region src/games/harmonies/bot.ts
function It(e, t) {
	return e.length === t.height && e.at(-1) === t.terrain ? 0 : e.length >= t.height ? Infinity : t.terrain === "green" ? e.every((e) => e === "brown") ? t.height - e.length : Infinity : t.terrain === "gray" ? e.every((e) => e === "gray") ? t.height - e.length : Infinity : t.terrain === "red" && t.height === 2 ? e.length === 0 ? 2 : [
		"gray",
		"brown",
		"red"
	].includes(e[0]) ? 1 : Infinity : e.length === 0 ? 1 : Infinity;
}
function Lt(e, t, n) {
	let r = [];
	for (let i of z) {
		if (e[i.key]?.animal) continue;
		let a = Infinity;
		for (let r = 0; r < (n ? 2 : 1); r++) for (let n = 0; n < 6; n++) {
			let o = 0;
			for (let a of t.pattern) {
				let t = G(a, n, r === 1), s = `${i.q + t.q},${i.r + t.r}`;
				if (!we.has(s)) {
					o = Infinity;
					break;
				}
				let c = It(e[s]?.layers ?? [], t);
				if (c > 0 && e[s]?.animal) {
					o = Infinity;
					break;
				}
				o += c;
			}
			a = Math.min(a, o);
		}
		Number.isFinite(a) && r.push(a);
	}
	r.sort((e, t) => e - t);
	let i = t.spirit ? 7 : t.scores.at(-1) / t.scores.length;
	return r.slice(0, 3).reduce((e, t, n) => e + i * [
		1,
		.4,
		.18
	][n] / (t + 1), 0);
}
var Rt = (e, t) => {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid);
	if (n.phase !== "play" || n.current !== t.rid || !r) return null;
	if (!r.spiritChosen) {
		let t = e.private?.spirits ?? [];
		return t.length ? { action: {
			type: "chooseSpirit",
			card: t[n.serial % t.length]
		} } : null;
	}
	let i = r.cards.filter((e) => e.placed < F[e.id].scores.length);
	for (let e of i) {
		let t = De(r.board, F[e.id], n.config.pulse)[0];
		if (t) return { action: {
			type: "animal",
			card: e.id,
			key: t.key,
			rotation: t.rotation,
			mirrored: t.mirrored
		} };
	}
	if (!n.turn.tookCard && i.length < 4) {
		let e = n.market.flatMap((e, t) => e === null ? [] : [t]);
		if (e.length) return { action: {
			type: "takeCard",
			index: e[n.serial % e.length]
		} };
	}
	if (!n.turn.drafted) {
		let e = n.groups.flatMap((e, t) => e?.length === 3 ? [t] : []);
		return e.length ? { action: {
			type: "draft",
			group: e[n.serial % e.length]
		} } : null;
	}
	if (n.turn.held.length) {
		let e = [...new Set(n.turn.held)].flatMap((e) => z.filter(({ key: t }) => Te(r.board, t, e)).map(({ key: t }) => ({
			terrain: e,
			key: t
		}))), t = e[(n.serial * 7 + r.score.cubes) % e.length];
		return t ? { action: {
			type: "place",
			terrain: t.terrain,
			key: t.key
		} } : null;
	}
	if (n.players.length === 1 && !n.turn.tookCard) {
		let e = n.market.flatMap((e, t) => e === null ? [] : [{
			index: t,
			value: Lt(r.board, F[e], n.config.pulse)
		}]).reduce((e, t) => !e || t.value < e.value ? t : e, null);
		if (e) return { action: {
			type: "endTurn",
			discard: e.index
		} };
	}
	return { action: { type: "endTurn" } };
};
function zt(e = gt) {
	let t = Ft(e);
	return (e, n) => n.difficulty === "weak" ? Rt(e, n) : t(e, n);
}
var Bt = zt(), Vt = (e, t, n) => {
	switch (e.type) {
		case "chooseSpirit": return n(F[e.card].nameKey);
		case "draft": return n("games.harmonies.hintDraft", { n: e.group + 1 });
		case "place": return n("games.harmonies.hintPlace", {
			terrain: n(Q[e.terrain]),
			n: z.findIndex((t) => t.key === e.key) + 1
		});
		case "takeCard": return n("games.harmonies.hintTake", { animal: n(F[t.public.market[e.index]].nameKey) });
		case "animal": return n("games.harmonies.hintAnimal", {
			animal: n(F[e.card].nameKey),
			n: z.findIndex((t) => t.key === e.key) + 1
		});
		case "endTurn": return n("games.harmonies.endTurn");
	}
}, Ht = {
	place(e, t) {
		let n = e.data, r = `hm-token:${e.rid}:${n.key}`, i = t.anchor(r);
		if (!i) return null;
		let a = e.rid === t.myRid ? t.anchor("hm-held") : null, o = a ? {
			x: a.x + a.w / 2 - i.w / 2,
			y: a.y,
			w: i.w,
			h: i.h
		} : {
			...i,
			y: i.y - 45
		}, s = t.queued ? 150 : 320;
		return v(), {
			ms: s,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ w(E, {
				from: o,
				to: i,
				ms: s,
				children: /* @__PURE__ */ w("span", {
					style: {
						display: "block",
						width: i.w,
						height: i.h
					},
					children: /* @__PURE__ */ w("svg", {
						width: "100%",
						height: "100%",
						viewBox: "-27 -18 54 40",
						children: /* @__PURE__ */ w(ot, { terrain: n.terrain })
					})
				})
			})
		};
	},
	animal(e, t) {
		let n = e.data, r = `hm-animal:${e.rid}:${n.key}`, i = t.anchor(r);
		if (!i) return null;
		let a = t.queued ? 150 : 320;
		return v(), {
			ms: a,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ w(E, {
				from: {
					...i,
					y: i.y - 60
				},
				to: i,
				ms: a,
				children: /* @__PURE__ */ w("span", {
					style: {
						display: "block",
						width: i.w,
						height: i.h
					},
					children: /* @__PURE__ */ w("svg", {
						width: "100%",
						height: "100%",
						viewBox: "-13 -16 28 26",
						children: /* @__PURE__ */ w(st, { spirit: n.spirit })
					})
				})
			})
		};
	}
};
//#endregion
//#region src/games/harmonies/game-over.tsx
function Ut({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let s = c(), l = t, [u, d] = o(r), [f, p] = o(null), m = l.players.find((e) => e.rid === u) ?? l.players[0], h = (e) => n.find((t) => t.rid === e)?.name ?? e;
	return /* @__PURE__ */ T("div", {
		className: "harmonies-over",
		children: [
			/* @__PURE__ */ w(ue, {}),
			/* @__PURE__ */ T("h1", { children: [
				s("games.harmonies.name"),
				" · ",
				s("session.result.title")
			] }),
			/* @__PURE__ */ w("div", {
				className: "harmonies-over-players",
				children: e.ranking.map((t, n) => /* @__PURE__ */ T("button", {
					"aria-pressed": u === t,
					onClick: () => {
						d(t), p(null);
					},
					children: [/* @__PURE__ */ T("span", { children: [
						e.winner.includes(t) ? "🏆" : n + 1,
						" ",
						h(t)
					] }), /* @__PURE__ */ w("strong", { children: s("games.harmonies.points", { n: e.scores?.[t] ?? 0 }) })]
				}, t))
			}),
			l.suns !== void 0 && /* @__PURE__ */ T("p", {
				className: "harmonies-suns",
				children: ["☀ ", s("games.harmonies.suns", { n: l.suns })]
			}),
			/* @__PURE__ */ T("div", {
				className: "harmonies-over-main",
				children: [/* @__PURE__ */ w("div", {
					className: "harmonies-over-board",
					children: /* @__PURE__ */ w(Qe, {
						board: m.board,
						selected: f,
						onSelect: p,
						label: s("games.harmonies.boardLabel"),
						resetLabel: s("games.harmonies.resetCamera"),
						cellLabel: (e) => s("games.harmonies.cellLabel", {
							n: z.findIndex((t) => t.key === e) + 1,
							stack: m.board[e]?.layers.map((e) => s(Q[e])).join(" → ") || s("games.harmonies.emptyCell")
						})
					})
				}), /* @__PURE__ */ T("div", {
					className: "harmonies-over-detail",
					children: [
						f && /* @__PURE__ */ w("p", { children: m.board[f]?.layers.map((e) => s(Q[e])).join(" → ") || s("games.harmonies.emptyCell") }),
						/* @__PURE__ */ T("div", {
							className: "harmonies-score-table",
							children: [Object.entries(mt).map(([e, t]) => /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w("span", { children: s(t) }), /* @__PURE__ */ w("strong", { children: m.score[e] })] }, e)), /* @__PURE__ */ T("div", { children: [/* @__PURE__ */ w("span", { children: s("games.harmonies.total") }), /* @__PURE__ */ w("strong", { children: m.score.total })] })]
						}),
						/* @__PURE__ */ w("p", { children: s("games.harmonies.animalCubes", { n: m.score.cubes }) }),
						/* @__PURE__ */ w("div", {
							className: "harmonies-over-cards",
							children: m.cards.map((e) => /* @__PURE__ */ w(pt, {
								id: e.id,
								placed: e.placed,
								board: m.board,
								compact: !0
							}, e.id))
						})
					]
				})]
			}),
			/* @__PURE__ */ T("div", {
				className: "harmonies-over-controls",
				children: [
					i && /* @__PURE__ */ w("button", {
						className: "btn-base harmonies-primary",
						onClick: i,
						children: s("session.result.playAgain")
					}),
					a && /* @__PURE__ */ w("button", {
						className: "btn-quiet",
						onClick: a,
						children: s("session.result.backToLobby")
					}),
					!i && !a && /* @__PURE__ */ w("p", { children: s("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/harmonies/options.tsx
function Wt({ value: e, onChange: t }) {
	let n = c(), r = Me.safeParse(e), i = r.success ? r.data : Me.parse(void 0);
	return /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ T(fe, {
		title: n("games.harmonies.side"),
		children: [/* @__PURE__ */ w(D, {
			name: "harmonies-side",
			value: "A",
			checked: i.side === "A",
			accent: je.accent,
			label: n("games.harmonies.sideA"),
			onChange: () => t({
				...i,
				side: "A"
			})
		}), /* @__PURE__ */ w(D, {
			name: "harmonies-side",
			value: "B",
			checked: i.side === "B",
			accent: je.accent,
			label: n("games.harmonies.sideB"),
			onChange: () => t({
				...i,
				side: "B"
			})
		})]
	}), /* @__PURE__ */ T(fe, {
		title: n("games.harmonies.options"),
		children: [/* @__PURE__ */ w(de, {
			name: "harmonies-pulse",
			value: "pulse",
			checked: i.pulse,
			label: n("games.harmonies.pulse"),
			hint: n("games.harmonies.pulseHint"),
			onChange: () => t({
				...i,
				pulse: !i.pulse
			})
		}), /* @__PURE__ */ w(de, {
			name: "harmonies-spirits",
			value: "spirits",
			checked: i.spirits,
			label: n("games.harmonies.spirits"),
			hint: n("games.harmonies.spiritsHint"),
			onChange: () => t({
				...i,
				spirits: !i.spirits
			})
		})]
	})] });
}
//#endregion
//#region .bgparty/cache/pack-entry/harmonies/entry.tsx
var Gt = {
	definition: Ge,
	View: ht,
	bot: Bt,
	describe: Vt,
	fx: Ht,
	OverView: Ut,
	Options: Wt,
	locales: {
		zh: {
			name: "自然和弦",
			desc: "叠起自然景观，构筑动物栖息地；含律动扩展与单人挑战。",
			rules: "目标：\n· 放置地形木片，构筑栖息地，以景观、动物与自然精灵得分。\n准备：\n· 每人使用相同一面的 23 格版图。多人供给为五组木片、五张动物牌；单人为三组、三张。\n· 木片共 120 枚：灰、蓝各 23，棕 21，绿、黄各 19，红 15。\n· 律动扩展加入 10 张动物牌，并允许镜像栖息地图案。\n· 启用自然精灵时，首回合从私下获得的两张牌中选择一张。\n流程：\n· 每回合必须选择一组三枚木片，并将三枚全部放到自己的版图上。\n· 木片可放空格；叠放仅限山峰、树木或建筑，不得插入已有木片下方。\n· 山峰最多三枚灰色木片；树木为一枚绿色木片，下方可有零至两枚棕色木片。\n· 建筑为一枚红色木片叠在一枚灰、棕或红色木片上。水域和田野不叠放。\n· 有动物或精灵方块的格子不能继续叠放木片。\n· 每回合可领取一张公共动物牌；尚未完成的动物牌和精灵牌合计最多四张。\n· 栖息地符合牌面时，可将牌上一个方块放在图案指定、尚无方块的木片上。\n· 图案可旋转；木片颜色和层数必须相符，建筑底层颜色不限。\n· 动物可在放木片前、两次放片之间或放完后安置，次数不限。\n· 同一木片可参与多个栖息地；动物放置后保留，即使周围地形改变。\n· 放完一张牌的全部方块后，该牌不再占用四张牌的额度。\n· 回合结束时才补充木片和动物牌。\n计分：\n· 高度一、二、三的树木分别为 1、3、7 分。\n· 山峰同样按高度计分，但必须与另一座山峰相邻。\n· 每片至少两格相连的田野计 5 分；整片田野只计一次。\n· 建筑周围顶层木片有至少三种颜色时计 5 分。\n· A 面只计最佳河流；两端间最短路径含一至六枚时计 0、2、5、8、11、15 分。\n· 河流超过六枚后，每多一枚计 4 分；支流不重复计入，环按最短路径判断。\n· B 面每座岛屿计 5 分，空格也属于陆地；至少计一座岛屿。\n· 动物牌按已移走方块对应的最高分计分；未放出方块为零分。\n· 精灵方块已放置时，按终局景观追加该牌奖励。\n结束：\n· 回合结束时版图空格不超过两格，或需要补货时袋中木片不足，即触发最终轮。\n· 完成当前轮，使所有玩家回合数相同，再比较总分。\n· 同分时，动物方块较多者获胜；仍相同则共享胜利。\n单人：\n· 每回合结束弃置供给中剩余六枚木片，再补充三组木片。\n· 本回合未领取动物牌时，可在结束回合时替换一张公共动物牌。\n· 总分达到 40、70、90、110、130、140、150、160 时分别获得一至八枚太阳。\n· A 面额外一枚太阳；未用精灵额外两枚，按连通区域奖励的精灵额外一枚。",
			options: "游戏组件",
			side: "版图",
			sideA: "A 面 · 河流",
			sideB: "B 面 · 岛屿",
			pulse: "律动扩展",
			pulseHint: "加入十张动物牌，并允许镜像图案。",
			spirits: "自然精灵",
			spiritsHint: "每人首回合从两张自然精灵牌中选择一张。",
			gray: "灰色木片",
			blue: "蓝色木片",
			brown: "棕色木片",
			green: "绿色木片",
			yellow: "黄色木片",
			red: "红色木片",
			trees: "树木",
			mountains: "山峰",
			fields: "田野",
			buildings: "建筑",
			water: "水域",
			animals: "动物",
			spiritScore: "自然精灵",
			total: "总分",
			landscape: "{{name}}的景观",
			supply: "公共供给",
			market: "公共动物牌",
			myCards: "我的动物",
			cardsOf: "{{name}}的动物",
			completed: "已完成 {{n}} 张",
			completedCards: "已完成的卡牌",
			round: "第 {{n}} 轮",
			yourTurn: "轮到你",
			waiting: "等待{{name}}",
			finalRound: "最终轮",
			bagLeft: "袋中 {{n}} 枚",
			points: "{{n}} 分",
			draftPrompt: "选择一组地形木片",
			placePrompt: "选择木片和放置位置",
			optionalPrompt: "可安置动物，或结束回合",
			draftConfirm: "拿取这一组",
			placeConfirm: "确认放置",
			animalConfirm: "安置动物",
			spiritConfirm: "安置自然精灵",
			endTurn: "结束回合",
			takeCard: "领取这张牌",
			findHabitat: "寻找栖息地",
			viewCard: "查看{{name}}",
			chooseSpirit: "选择自然精灵",
			chooseThisSpirit: "选择这张精灵牌",
			held: "待放地形",
			remaining: "剩余 {{n}} 枚",
			selectedCell: "选中格",
			emptyCell: "空格",
			layers: "{{n}} 层",
			preview: "放置后",
			stack: "完整堆叠",
			stackOrder: "从底到顶",
			animalPresent: "已有动物",
			spiritPresent: "已有自然精灵",
			cellLabel: "第 {{n}} 格，{{stack}}",
			resetCamera: "视角归位",
			boardLabel: "景观版图",
			noHabitat: "没有符合的栖息地",
			matchCount: "{{n}} 处栖息地",
			nextMatch: "切换匹配图案",
			rotate: "旋转图案",
			mirror: "镜像图案",
			target: "动物落点",
			cardProgress: "已安置 {{placed}}，共 {{n}} 个",
			scoreTrack: "得分轨道",
			incomplete: "未完成 {{n}} / 4",
			noCards: "尚未领取动物牌",
			completedTag: "已完成",
			expansionTag: "律动",
			spiritTag: "自然精灵",
			replaceCard: "结束回合并替换",
			replaceChoice: "替换公共动物牌",
			noReplace: "保留公共动物牌",
			soloReplaceHint: "本回合未领取动物牌，可替换一张。",
			riverLength: "河流长度 {{n}}",
			islands: "{{n}} 座岛屿",
			suns: "{{n}} 枚太阳",
			animalCubes: "{{n}} 个动物方块",
			scoring: "得分明细",
			invalid: "当前不能执行这项操作。",
			notYourTurn: "尚未轮到你。",
			chooseSpiritFirst: "请先选择自然精灵。",
			cardLimit: "尚未完成的卡牌已达四张。",
			placeAll: "请先拿取并放完三枚木片。",
			hintDraft: "拿取第 {{n}} 组地形木片。",
			hintPlace: "将{{terrain}}放到第 {{n}} 格。",
			hintAnimal: "将{{animal}}安置在第 {{n}} 格。",
			hintTake: "领取{{animal}}。",
			logDraft: "{{name}}拿取第 {{n}} 组木片。",
			logPlace: "{{name}}放置{{terrain}}。",
			logTake: "{{name}}领取{{animal}}。",
			logAnimal: "{{name}}安置{{animal}}。",
			logSpirit: "{{name}}选择{{animal}}。",
			logEnd: "{{name}}结束回合。",
			llama: "羊驼",
			meerkat: "狐獴",
			vulture: "胡兀鹫",
			bat: "蝙蝠",
			fennec: "耳廓狐",
			polarBear: "北极熊",
			penguin: "企鹅",
			lizard: "蜥蜴",
			flamingo: "火烈鸟",
			shrew: "鼩鼱",
			peacock: "孔雀",
			heron: "苍鹭",
			duck: "鸭",
			otter: "水獭",
			giraffe: "长颈鹿",
			kingfisher: "翠鸟",
			crocodile: "鳄鱼",
			salamander: "蝾螈",
			squirrel: "松鼠",
			koala: "考拉",
			wolf: "狼",
			boar: "野猪",
			hummingbird: "蜂鸟",
			bee: "蜜蜂",
			hedgehog: "刺猬",
			bear: "棕熊",
			deer: "鹿",
			ladybug: "瓢虫",
			swan: "天鹅",
			lemur: "狐猴",
			panther: "黑豹",
			stork: "白鹳",
			fish: "热带鱼",
			axolotl: "美西螈",
			songbird: "雀鸟",
			pelican: "鹈鹕",
			tiger: "老虎",
			chameleon: "变色龙",
			camel: "骆驼",
			yak: "牦牛",
			panda: "大熊猫",
			beetle: "甲虫",
			spiritDeer: "鹿之灵",
			spiritCrane: "鹤之灵",
			spiritOwl: "猫头鹰之灵",
			spiritCat: "猫之灵",
			spiritBear: "熊之灵",
			spiritDragonfly: "蜻蜓之灵",
			spiritIbex: "岩羊之灵",
			spiritTortoise: "象龟之灵",
			spiritButterfly: "蝴蝶之灵",
			spiritLion: "狮子之灵",
			ruleDeer: "每棵高度为二或三的树木额外获得 4 分。",
			ruleCrane: "每组至少两座相连的建筑额外获得 6 分。",
			ruleOwl: "高度为一或二的树木各额外获得 3 分，高度为三的各获得 1 分。",
			ruleCat: "每座不与其他建筑相邻的建筑额外获得 4 分。",
			ruleBear: "高度为一或二的山峰各额外获得 3 分，高度为三的各获得 1 分；孤立山峰也计入。",
			ruleDragonfly: "每片至少两格相连的水域额外获得 7 分。",
			ruleIbex: "每座高度为二或三的山峰额外获得 4 分；孤立山峰也计入。",
			ruleTortoise: "每枚蓝色木片额外获得 2 分。",
			ruleButterfly: "每片相连的田野额外获得 5 分；单独一格也计入。",
			ruleLion: "每片一或两格的田野额外获得 2 分，至少三格的田野各获得 10 分。"
		},
		en: {
			name: "Harmonies",
			desc: "Build natural landscapes and animal habitats, with Pulse and solo play.",
			rules: "Goal:\n· Build habitats with landscape tokens and score landscapes, animals and Nature’s Spirits.\nSetup:\n· Use the same side of the 23-space boards. Display five token groups and cards, or three of each solo.\n· There are 120 tokens: 23 gray, 23 blue, 21 brown, 19 green, 19 yellow and 15 red.\n· Pulse adds 10 animal cards and allows reflected habitat patterns.\n· With Nature’s Spirits, privately choose one of two cards on your first turn.\nPlay:\n· Each turn, take one group of three tokens and place all three on your board.\n· Place tokens on empty spaces or form legal mountains, trees or buildings; never insert tokens underneath.\n· Mountains contain up to three gray tokens; trees have one green token above zero, one or two brown tokens.\n· Buildings have a red token above one gray, brown or red token. Water and fields cannot be stacked.\n· Never add tokens to a space occupied by an animal or spirit cube.\n· You may take one animal card per turn; hold no more than four incomplete animal and spirit cards.\n· When a habitat matches, move a cube from its card onto the indicated, unoccupied token.\n· Rotate patterns freely; colors and heights must match. A building’s bottom token may be any legal color.\n· Settle animals before, between or after placing tokens, as often as you wish.\n· Tokens may serve several habitats. Settled animals remain even if surrounding landscapes change.\n· A card no longer occupies an active-card slot when all its cubes have been placed.\n· Refill token groups and animal cards only at the end of the turn.\nScoring:\n· Trees of heights one, two and three score 1, 3 and 7 points.\n· Mountains score the same, but must be adjacent to another mountain.\n· Each connected field of at least two yellow tokens scores 5 points, once for the whole field.\n· Each building scores 5 points if adjacent top tokens include at least three different colors.\n· Side A scores your best river: shortest paths of one to six tokens score 0, 2, 5, 8, 11 and 15.\n· Beyond six tokens, score 4 per extra token. Do not double-count branches; use shortest paths in loops.\n· Side B scores 5 per island. Empty spaces are land; count at least one island.\n· Animal cards score their highest uncovered value; cards with no placed cubes score zero.\n· A settled Nature’s Spirit adds its bonus based on the final landscape.\nEnding:\n· Trigger the final round with at most two empty board spaces, or insufficient tokens when refilling.\n· Finish the round so everyone has played equally, then compare total scores.\n· Ties favor the player with more animal cubes. Further ties share victory.\nSolo:\n· Discard the six unchosen supply tokens at turn end, then refill all three groups.\n· If you took no animal card this turn, you may replace one public animal card at turn end.\n· Scores of 40, 70, 90, 110, 130, 140, 150 and 160 earn one through eight suns.\n· Add one sun for side A; add two without a spirit, or one for a spirit rewarding connected groups.",
			options: "Components",
			side: "Board",
			sideA: "Side A · Rivers",
			sideB: "Side B · Islands",
			pulse: "Pulse expansion",
			pulseHint: "Add ten animal cards and reflected patterns.",
			spirits: "Nature’s Spirits",
			spiritsHint: "Choose one of two spirit cards on your first turn.",
			gray: "gray token",
			blue: "blue token",
			brown: "brown token",
			green: "green token",
			yellow: "yellow token",
			red: "red token",
			trees: "Trees",
			mountains: "Mountains",
			fields: "Fields",
			buildings: "Buildings",
			water: "Water",
			animals: "Animals",
			spiritScore: "Nature’s Spirit",
			total: "Total",
			landscape: "{{name}}’s landscape",
			supply: "Token supply",
			market: "Animal market",
			myCards: "My animals",
			cardsOf: "{{name}}’s animals",
			completed: "{{n}} completed",
			completedCards: "Completed cards",
			round: "Round {{n}}",
			yourTurn: "Your turn",
			waiting: "Waiting for {{name}}",
			finalRound: "Final round",
			bagLeft: "{{n}} in bag",
			points: "{{n}} pts",
			draftPrompt: "Choose a group of tokens",
			placePrompt: "Choose a token and space",
			optionalPrompt: "Settle animals or end your turn",
			draftConfirm: "Take this group",
			placeConfirm: "Place token",
			animalConfirm: "Settle animal",
			spiritConfirm: "Settle spirit",
			endTurn: "End turn",
			takeCard: "Take this card",
			findHabitat: "Find habitats",
			viewCard: "View {{name}}",
			chooseSpirit: "Choose a Nature’s Spirit",
			chooseThisSpirit: "Choose this spirit",
			held: "Tokens to place",
			remaining: "{{n}} left",
			selectedCell: "Selected space",
			emptyCell: "Empty space",
			layers: "{{n}} layers",
			preview: "After placing",
			stack: "Full stack",
			stackOrder: "Bottom to top",
			animalPresent: "Animal present",
			spiritPresent: "Spirit present",
			cellLabel: "Space {{n}}, {{stack}}",
			resetCamera: "Reset view",
			boardLabel: "Landscape board",
			noHabitat: "No matching habitat",
			matchCount: "{{n}} habitats",
			nextMatch: "Next matching pattern",
			rotate: "Rotate pattern",
			mirror: "Reflect pattern",
			target: "Animal’s space",
			cardProgress: "{{placed}} of {{n}} settled",
			scoreTrack: "Scoring track",
			incomplete: "{{n}} / 4 active",
			noCards: "No animal cards yet",
			completedTag: "Completed",
			expansionTag: "Pulse",
			spiritTag: "Nature’s Spirit",
			replaceCard: "End turn & replace",
			replaceChoice: "Replace an animal card",
			noReplace: "Keep the market",
			soloReplaceHint: "You took no animal card, so you may replace one.",
			riverLength: "River length {{n}}",
			islands: "{{n}} islands",
			suns: "{{n}} suns",
			animalCubes: "{{n}} animal cubes",
			scoring: "Score details",
			invalid: "That action is not available.",
			notYourTurn: "It is not your turn.",
			chooseSpiritFirst: "Choose your Nature’s Spirit first.",
			cardLimit: "You already have four incomplete cards.",
			placeAll: "Take and place all three tokens first.",
			hintDraft: "Take token group {{n}}.",
			hintPlace: "Place a {{terrain}} on space {{n}}.",
			hintAnimal: "Settle {{animal}} on space {{n}}.",
			hintTake: "Take {{animal}}.",
			logDraft: "{{name}} took token group {{n}}.",
			logPlace: "{{name}} placed a {{terrain}}.",
			logTake: "{{name}} took {{animal}}.",
			logAnimal: "{{name}} settled {{animal}}.",
			logSpirit: "{{name}} chose {{animal}}.",
			logEnd: "{{name}} ended their turn.",
			llama: "Llama",
			meerkat: "Meerkat",
			vulture: "Bearded vulture",
			bat: "Bat",
			fennec: "Fennec fox",
			polarBear: "Polar bear",
			penguin: "Penguin",
			lizard: "Lizard",
			flamingo: "Flamingo",
			shrew: "Shrew",
			peacock: "Peacock",
			heron: "Heron",
			duck: "Duck",
			otter: "Otter",
			giraffe: "Giraffe",
			kingfisher: "Kingfisher",
			crocodile: "Crocodile",
			salamander: "Salamander",
			squirrel: "Squirrel",
			koala: "Koala",
			wolf: "Wolf",
			boar: "Wild boar",
			hummingbird: "Hummingbird",
			bee: "Bee",
			hedgehog: "Hedgehog",
			bear: "Brown bear",
			deer: "Deer",
			ladybug: "Ladybug",
			swan: "Swan",
			lemur: "Lemur",
			panther: "Panther",
			stork: "Stork",
			fish: "Tropical fish",
			axolotl: "Axolotl",
			songbird: "Songbird",
			pelican: "Pelican",
			tiger: "Tiger",
			chameleon: "Chameleon",
			camel: "Camel",
			yak: "Yak",
			panda: "Giant panda",
			beetle: "Beetle",
			spiritDeer: "Deer Spirit",
			spiritCrane: "Crane Spirit",
			spiritOwl: "Owl Spirit",
			spiritCat: "Cat Spirit",
			spiritBear: "Bear Spirit",
			spiritDragonfly: "Dragonfly Spirit",
			spiritIbex: "Ibex Spirit",
			spiritTortoise: "Tortoise Spirit",
			spiritButterfly: "Butterfly Spirit",
			spiritLion: "Lion Spirit",
			ruleDeer: "Add 4 points per tree of height two or three.",
			ruleCrane: "Add 6 points per connected group of at least two buildings.",
			ruleOwl: "Add 3 points per tree of height one or two, and 1 per tree of height three.",
			ruleCat: "Add 4 points per building with no adjacent building.",
			ruleBear: "Add 3 points per mountain of height one or two, and 1 per height three, including isolated mountains.",
			ruleDragonfly: "Add 7 points per connected water group of at least two tokens.",
			ruleIbex: "Add 4 points per mountain of height two or three, including isolated mountains.",
			ruleTortoise: "Add 2 points per blue token.",
			ruleButterfly: "Add 5 points per connected yellow group, including isolated tokens.",
			ruleLion: "Add 2 points per yellow group of one or two tokens, or 10 per group of three or more."
		}
	}
};
//#endregion
export { Gt as default };
