import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { useT as o } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as s } from "@bgparty/sdk/player-colors";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as u } from "@bgparty/sdk/ui/player-strip";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { Floater as m, FlySprite as h, PulseBox as g } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as _ } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as v, OptionSection as y } from "@bgparty/sdk/ui/game-options";
//#region src/games/sail/board.ts
var b = [
	4,
	3,
	2,
	1,
	2,
	3,
	4
], x = [
	22,
	23,
	24,
	25,
	24,
	23,
	22
], S = (e) => `${e.l},${e.n}`, C = (e, t) => e.l === t.l && e.n === t.n;
function w(e, t) {
	return e < 0 || e > 6 ? !1 : t >= b[e] && t <= x[e] && (t - b[e]) % 2 == 0;
}
function T(e, t) {
	let n = {
		l: e.l + t,
		n: e.n + 1
	};
	return w(n.l, n.n) ? n : null;
}
function E(e) {
	let t = {
		l: e.l,
		n: e.n + 2
	};
	return w(t.l, t.n) ? t : null;
}
var D = (e, t) => ({
	l: e,
	n: t
}), O = [
	{
		start: D(3, 1),
		islands: [
			D(3, 3),
			D(0, 8),
			D(2, 8),
			D(0, 10),
			D(2, 10)
		],
		krakens: [
			D(0, 4),
			D(2, 6),
			D(3, 7)
		],
		ends: [
			D(2, 10),
			D(4, 10),
			D(3, 11)
		],
		storms: [5]
	},
	{
		start: D(3, 1),
		islands: [
			D(3, 3),
			D(2, 6),
			D(2, 10),
			D(2, 12),
			D(0, 16),
			D(2, 16)
		],
		krakens: [
			D(6, 4),
			D(0, 6),
			D(2, 8),
			D(2, 12),
			D(0, 14),
			D(5, 15)
		],
		ends: [
			D(2, 16),
			D(4, 16),
			D(3, 17)
		],
		storms: [5, 12]
	},
	{
		start: D(3, 1),
		islands: [
			D(3, 3),
			D(2, 8),
			D(0, 10),
			D(4, 10),
			D(1, 11),
			D(0, 12),
			D(3, 15),
			D(0, 18),
			D(2, 18)
		],
		krakens: [
			D(6, 4),
			D(0, 6),
			D(3, 7),
			D(4, 12),
			D(0, 16),
			D(5, 17)
		],
		ends: [
			D(2, 18),
			D(4, 18),
			D(3, 19)
		],
		storms: [5, 14]
	}
];
function k(e, t) {
	return e.islands.some((e) => C(e, t));
}
function A(e, t) {
	return e.krakens.some((e) => C(e, t));
}
function ee(e, t) {
	return e.ends.some((e) => C(e, t));
}
function j(e, t) {
	let n = /* @__PURE__ */ new Set([S(t)]), r = [t];
	for (; r.length > 0;) {
		let t = r.pop();
		if (ee(e, t)) return !0;
		let i = [
			T(t, -1),
			T(t, 1),
			E(t)
		];
		for (let t of i) {
			if (!t || k(e, t)) continue;
			let i = S(t);
			n.has(i) || (n.add(i), r.push(t));
		}
	}
	return !1;
}
//#endregion
//#region src/games/sail/cards.ts
function M(e) {
	return e.v <= 3 ? "wheelTentacle" : e.v <= 5 ? "cannon" : e.v <= 8 ? "wheel" : "tentacle";
}
var N = (e) => e.s === "gray" && e.v >= 6 && e.v <= 8;
function P() {
	let e = [];
	for (let t of [
		"gray",
		"green",
		"blue"
	]) for (let n of [1, 2]) e.push({
		s: t,
		v: n
	});
	return e;
}
function te() {
	let e = [];
	for (let t of [
		"gray",
		"green",
		"blue"
	]) for (let n = 3; n <= 9; n += 1) e.push({
		s: t,
		v: n
	});
	return e;
}
var ne = (e, t) => e.s === t.s && e.v === t.v, F = {
	id: "sail",
	tier: "beta",
	mechanics: ["trick-taking"],
	interactionTags: ["cooperative"],
	nameKey: "games.sail.name",
	descKey: "games.sail.desc",
	rulesKey: "games.sail.rules",
	icon: "⛵",
	iconImg: "games/sail.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/sail/en.pdf" },
	precacheAssets: [
		"map.webp",
		"ship.webp",
		"card-gray.webp",
		"card-green.webp",
		"card-blue.webp",
		"pirate-1.webp",
		"pirate-2.webp",
		"pirate-3.webp",
		"pirate-4.webp",
		"pirate-5.webp",
		"pirate-6.webp"
	],
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#0e7490",
	releasedAt: "2026-09-15",
	search: {
		py: "shen hai mi tu",
		init: "shmt"
	},
	hotseat: "cover"
}, I = t.object({
	s: t.enum([
		"gray",
		"green",
		"blue"
	]),
	v: t.int().min(1).max(9)
}), L = t.object({
	l: t.int().min(0).max(6),
	n: t.int().min(1).max(25)
}), re = t.int().min(1).max(6), ie = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("pickPirate"),
		pirate: re
	}),
	t.object({
		type: t.literal("give"),
		card: I
	}),
	t.object({
		type: t.literal("chooseGive"),
		card: I
	}),
	t.object({
		type: t.literal("play"),
		card: I
	}),
	t.object({
		type: t.literal("resolve"),
		use: t.boolean()
	}),
	t.object({
		type: t.literal("pickCannon"),
		index: t.int().min(0).max(1)
	}),
	t.object({ type: t.literal("retry") })
]), ae = t.object({
	scenario: t.int().min(0).max(2).catch(0),
	pirates: t.boolean().catch(!0)
}).default({
	scenario: 0,
	pirates: !0
}), R = t.string(), oe = t.array(t.object({
	rid: R,
	card: I
})), se = t.object({
	kind: t.enum([
		"captain",
		"helm",
		"gunner"
	]),
	rid: R,
	cards: t.array(I).optional()
}), ce = t.object({
	phase: t.enum([
		"pirates",
		"exchange",
		"play",
		"won",
		"lost"
	]),
	scenario: t.int().min(0).max(2),
	round: t.int().min(1).max(5),
	ship: L,
	board: t.object({
		start: L,
		islands: t.array(L),
		krakens: t.array(L),
		ends: t.array(L),
		storms: t.array(t.int())
	}),
	krakenTrack: t.int().min(0).max(4),
	krakenDeck: t.array(t.union([I, t.literal("K")])),
	playerDeckCount: t.int().nonnegative(),
	discard: t.array(I),
	players: t.array(t.object({
		rid: R,
		pirate: re.nullable(),
		tricksWon: t.int().nonnegative(),
		handCount: t.int().nonnegative()
	})),
	exchange: t.object({
		waiting: t.array(R),
		round: t.int().min(1),
		total: t.int().min(1)
	}).nullable(),
	trick: t.object({
		leader: R,
		plays: oe
	}),
	lastTrick: t.object({
		plays: oe,
		winner: R
	}).nullable(),
	turn: R.nullable(),
	pending: se.nullable(),
	loseReason: t.enum([
		"storm",
		"round5",
		"krakenCard",
		"krakenDead",
		"deadzone"
	]).nullable()
}), le = t.object({
	hand: t.array(I),
	mustFollow: t.enum([
		"gray",
		"green",
		"blue"
	]).nullable(),
	exchange: t.object({
		stage: t.enum([
			"choose",
			"wait",
			"peek"
		]),
		peek: I.nullable(),
		received: I.nullable()
	}).nullable(),
	pirateChoices: t.array(re).nullable()
}), ue = [
	3,
	3,
	4,
	5
], z = (e) => ({ code: e });
function de(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var fe = (e) => O[e.scenario], pe = (e, t) => e.players.find((e) => e !== t), B = (e, t) => e.pirates[t] ?? null, me = (e) => e.pending;
function he(e) {
	return e.players.map((t, n) => ({
		kind: "deal",
		rid: t,
		data: { count: e.hands[t].length },
		for: [t],
		secret: { cards: e.hands[t] },
		...n > 0 ? { with: !0 } : {}
	}));
}
function ge(e) {
	for (let t of e.players) e.hands[t] = e.playerDeck.splice(0, 9);
}
function _e(e) {
	e.phase = "exchange", e.exchangeRound = 1, e.exchangeTotal = e.players.some((t) => e.pirates[t] === 5) ? 2 : 1, e.given = Object.fromEntries(e.players.map((e) => [e, null])), e.received = Object.fromEntries(e.players.map((e) => [e, null]));
}
function ve(e) {
	e.phase = "play";
	let t = e.round % 2 == 1 ? e.players[0] : e.players[1];
	e.trick = {
		leader: t,
		plays: []
	}, e.turn = t, e.tricksWon = Object.fromEntries(e.players.map((e) => [e, 0])), e.extraTrick = !1, e.lastTrick = null;
}
function ye(e) {
	return e.playerDeck = de(e, [
		...e.playerDeck,
		...e.discard,
		...e.players.flatMap((t) => e.hands[t])
	]), e.discard = [], e.hands = {}, ge(e), _e(e), he(e);
}
function be(e, t) {
	if (e.krakenDeck.length === 1) {
		e.phase = "lost", e.loseReason = "krakenCard";
		return;
	}
	let n = e.krakenDeck.shift();
	n === "K" ? (e.krakenTrack += 1, e.krakenDeck.push("K"), t.push({
		kind: "krakenMeeple",
		data: { track: e.krakenTrack }
	}), e.krakenTrack >= 4 && (e.phase = "lost", e.loseReason = "krakenDead")) : (e.discard.push(n), t.push({
		kind: "krakenHit",
		data: { card: n }
	}));
}
function xe(e, t, n) {
	for (let r = 0; r < t && e.phase !== "lost"; r += 1) be(e, n);
}
function Se(e, t) {
	let n = 0;
	for (; e.phase !== "lost" && n < ue[e.krakenTrack];) be(e, t), n += 1;
}
function Ce(e, t) {
	let n = fe(e);
	if (ee(n, e.ship)) {
		e.phase = "won";
		return;
	}
	A(n, e.ship) && xe(e, 1, t), e.phase !== "lost" && (j(n, e.ship) || (e.phase = "lost", e.loseReason = "deadzone"));
}
function we(e, t, n) {
	t && !k(fe(e), t) && (e.ship = t, n.push({
		kind: "move",
		data: { to: t }
	}), Ce(e, n));
}
function V(e, t, n) {
	let r = t === e.players[0] ? -1 : 1;
	we(e, T(e.ship, r), n);
}
function Te(e, t) {
	we(e, E(e.ship), t);
}
function Ee(e) {
	let t = e[0].card.s;
	return e.filter((e) => e.card.s === t).reduce((e, t) => t.card.v > e.card.v ? t : e).rid;
}
function De(e, t, n) {
	if (e.playerDeck.length === 0) return !0;
	if (B(e, t) === 6 && e.playerDeck.length >= 2) {
		let r = [e.playerDeck.shift(), e.playerDeck.shift()];
		return e.pending = {
			kind: "gunner",
			rid: t,
			cards: r
		}, n.push({
			kind: "flip",
			data: { cards: r }
		}), !1;
	}
	let r = e.playerDeck.shift();
	return n.push({
		kind: "flip",
		data: { cards: [r] }
	}), Oe(e, r, t, n), e.pending === null;
}
function Oe(e, t, n, r) {
	let i = M(t);
	if (i === "wheel") {
		if (e.discard.push(t), N(t) && B(e, n) === 2) {
			e.pending = {
				kind: "helm",
				rid: n
			};
			return;
		}
		V(e, n, r);
	} else i === "wheelTentacle" ? (e.krakenDeck.push(t), r.push({
		kind: "bury",
		data: { card: t }
	})) : i === "tentacle" ? (e.discard.push(t), Te(e, r)) : (e.discard.push(t), De(e, n, r));
}
function ke(e, t, n, r) {
	let [i, a] = t.map((e) => e.card), o = M(i), s = M(a), c = [o, s].sort().join("+"), l = B(e, n);
	if (c === "cannon+wheelTentacle") {
		let t = o === "wheelTentacle" ? i : a, n = o === "wheelTentacle" ? a : i;
		e.krakenDeck.push(t), e.discard.push(n), r.push({
			kind: "bury",
			data: { card: t }
		});
		return;
	}
	if (e.discard.push(i, a), c === "wheel+wheel") {
		if (i.v === a.v && l === 1) {
			e.pending = {
				kind: "captain",
				rid: n
			};
			return;
		}
		if (l === 2 && (N(i) || N(a))) {
			e.pending = {
				kind: "helm",
				rid: n
			};
			return;
		}
		V(e, n, r);
	} else if (c === "wheel+wheelTentacle" || c === "wheelTentacle+wheelTentacle") {
		if (xe(e, c === "wheel+wheelTentacle" ? 1 : 2, r), e.phase === "lost") return;
		let t = o === "wheel" ? i : s === "wheel" ? a : null;
		if (t && N(t) && l === 2) {
			e.pending = {
				kind: "helm",
				rid: n
			};
			return;
		}
		V(e, n, r);
	} else c === "tentacle+tentacle" ? Te(e, r) : c === "cannon+cannon" && De(e, n, r);
}
function Ae(e, t, n) {
	if (e.phase !== "won" && e.phase !== "lost") {
		if (e.tricksWon[t] >= 4) {
			if (B(e, t) === 3 && !e.extraTrick) e.extraTrick = !0;
			else {
				je(e, n);
				return;
			}
		} else if (e.extraTrick) {
			je(e, n);
			return;
		}
		e.trick = {
			leader: t,
			plays: []
		}, e.turn = t;
	}
}
function je(e, t) {
	if (Se(e, t), e.phase === "lost") return;
	let n = fe(e), r = e.round === 2 ? 0 : e.round === 4 ? 1 : -1;
	if (r >= 0 && n.storms[r] !== void 0 && e.ship.n <= n.storms[r]) {
		e.phase = "lost", e.loseReason = "storm";
		return;
	}
	if (e.round >= 5) {
		e.phase = "lost", e.loseReason = "round5";
		return;
	}
	e.round += 1, t.push(...ye(e));
}
function Me(e, t, n) {
	return {
		phase: "pirates",
		seed: n,
		rngCursor: 0,
		players: [...t],
		scenario: e.scenario,
		piratesOn: e.pirates,
		round: 1,
		ship: { ...O[e.scenario].start },
		krakenTrack: 0,
		krakenDeck: [],
		playerDeck: [],
		discard: [],
		hands: {},
		pirates: Object.fromEntries(t.map((e) => [e, null])),
		exchangeRound: 1,
		exchangeTotal: 1,
		given: {},
		received: {},
		trick: {
			leader: t[0],
			plays: []
		},
		tricksWon: Object.fromEntries(t.map((e) => [e, 0])),
		extraTrick: !1,
		lastTrick: null,
		turn: t[0],
		pending: null,
		loseReason: null
	};
}
function Ne(e) {
	e.krakenDeck = [...de(e, P()), "K"], e.playerDeck = de(e, te()), ge(e);
}
var Pe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: F,
	schemas: {
		action: ie,
		publicView: ce,
		privateView: le,
		config: ae
	},
	setup(e, t, n) {
		let r = Me(e, t, n);
		return Ne(r), r.piratesOn || _e(r), {
			state: r,
			fx: he(r)
		};
	},
	reduce(e, t, { by: n }) {
		let r = structuredClone(e);
		switch (t.type) {
			case "pickPirate": {
				if (r.phase !== "pirates") return z("games.sail.errPhase");
				if (!r.players.includes(n)) return z("games.sail.errTurn");
				if (r.pirates[n] !== null) return z("games.sail.errPiratePicked");
				if (r.players.some((e) => e !== n && r.pirates[e] === t.pirate)) return z("games.sail.errPirateTaken");
				r.pirates[n] = t.pirate;
				let e = [{
					kind: "pirate",
					rid: n,
					data: { pirate: t.pirate }
				}];
				return r.players.every((e) => r.pirates[e] !== null) && _e(r), {
					state: r,
					fx: e
				};
			}
			case "give":
			case "chooseGive": {
				if (r.phase !== "exchange") return z("games.sail.errPhase");
				if (!r.players.includes(n)) return z("games.sail.errTurn");
				if (r.given[n] !== null) return z("games.sail.errGiven");
				let e = pe(r, n), i = B(r, n) === 4;
				if (t.type === "chooseGive" && !i) return z("games.sail.errPeek");
				if (i && r.given[e] === null) return z("games.sail.errWaitPartner");
				let a = r.hands[n], o = a.findIndex((e) => ne(e, t.card));
				if (o < 0) return z("games.sail.errCard");
				a.splice(o, 1), r.given[n] = t.card;
				let s = [{
					kind: "give",
					rid: n
				}];
				return r.given[e] !== null && (r.hands[n].push(r.given[e]), r.hands[e].push(r.given[n]), r.received[n] = r.given[e], r.received[e] = r.given[n], s.push({
					kind: "receive",
					rid: n,
					for: [n],
					secret: { card: r.received[n] }
				}), s.push({
					kind: "receive",
					rid: e,
					for: [e],
					secret: { card: r.received[e] }
				}), r.given = Object.fromEntries(r.players.map((e) => [e, null])), r.exchangeRound >= r.exchangeTotal ? ve(r) : r.exchangeRound += 1), {
					state: r,
					fx: s
				};
			}
			case "play": {
				if (r.phase !== "play") return z("games.sail.errPhase");
				if (r.pending !== null) return z("games.sail.errPending");
				if (r.turn !== n) return z("games.sail.errTurn");
				let e = r.hands[n], i = e.findIndex((e) => ne(e, t.card));
				if (i < 0) return z("games.sail.errCard");
				if (r.trick.plays.length > 0) {
					let n = r.trick.plays[0].card.s;
					if (t.card.s !== n && e.some((e) => e.s === n)) return z("games.sail.errFollow");
				}
				e.splice(i, 1), r.trick.plays.push({
					rid: n,
					card: t.card
				});
				let a = [{
					kind: "play",
					rid: n,
					data: {
						card: t.card,
						index: r.trick.plays.length - 1
					}
				}];
				if (r.trick.plays.length < 2) return r.turn = pe(r, n), {
					state: r,
					fx: a
				};
				let o = Ee(r.trick.plays), s = [...r.trick.plays];
				r.tricksWon[o] += 1, r.lastTrick = {
					plays: s,
					winner: o
				}, r.trick = {
					leader: o,
					plays: []
				}, a.push({
					kind: "gather",
					rid: o
				}), ke(r, s, o, a);
				let c = me(r);
				return c === null ? (Ae(r, o, a), {
					state: r,
					fx: a
				}) : (r.turn = c.rid, {
					state: r,
					fx: a
				});
			}
			case "resolve": {
				if (r.phase !== "play") return z("games.sail.errPhase");
				let e = r.pending;
				if (!e || e.kind === "gunner") return z("games.sail.errPhase");
				if (e.rid !== n) return z("games.sail.errTurn");
				r.pending = null;
				let i = [{
					kind: "pirateUse",
					rid: n,
					data: {
						pirate: e.kind,
						use: t.use
					}
				}];
				return e.kind === "captain" ? t.use ? Te(r, i) : V(r, n, i) : V(r, t.use ? pe(r, n) : n, i), Ae(r, n, i), {
					state: r,
					fx: i
				};
			}
			case "pickCannon": {
				if (r.phase !== "play") return z("games.sail.errPhase");
				let e = r.pending;
				if (!e || e.kind !== "gunner" || !e.cards) return z("games.sail.errPhase");
				if (e.rid !== n) return z("games.sail.errTurn");
				let i = e.cards[t.index], a = e.cards[1 - t.index];
				if (!i || !a) return z("games.sail.errCard");
				r.pending = null, r.discard.push(a);
				let o = [{
					kind: "pirateUse",
					rid: n,
					data: {
						pirate: "gunner",
						card: i
					}
				}];
				return Oe(r, i, n, o), me(r) === null && Ae(r, n, o), {
					state: r,
					fx: o
				};
			}
			case "retry": {
				if (r.phase !== "lost") return z("games.sail.errPhase");
				let e = Me({
					scenario: r.scenario,
					pirates: r.piratesOn
				}, r.players, r.seed);
				return e.rngCursor = r.rngCursor, Ne(e), e.piratesOn || _e(e), {
					state: e,
					fx: he(e)
				};
			}
		}
	},
	viewFor(e, t) {
		let n = fe(e), r = e.phase === "pirates" ? [] : e.hands[t] ?? [], i = e.phase === "play" && e.trick.plays.length > 0 ? e.trick.plays[0].card.s : null, a = i !== null && e.turn === t && r.some((e) => e.s === i) ? i : null, o = null;
		if (e.phase === "exchange") {
			let n = pe(e, t), r = e.given[t] !== null, i = !r && B(e, t) === 4 && e.given[n] !== null ? e.given[n] : null;
			o = {
				stage: r ? "wait" : i ? "peek" : "choose",
				peek: i,
				received: e.received[t] ?? null
			};
		}
		return {
			public: {
				phase: e.phase,
				scenario: e.scenario,
				round: e.round,
				ship: { ...e.ship },
				board: {
					start: n.start,
					islands: n.islands,
					krakens: n.krakens,
					ends: n.ends,
					storms: n.storms
				},
				krakenTrack: e.krakenTrack,
				krakenDeck: [...e.krakenDeck],
				playerDeckCount: e.playerDeck.length,
				discard: [...e.discard],
				players: e.players.map((t) => ({
					rid: t,
					pirate: e.pirates[t] ?? null,
					tricksWon: e.tricksWon[t] ?? 0,
					handCount: e.hands[t]?.length ?? 0
				})),
				exchange: e.phase === "exchange" ? {
					waiting: e.players.filter((t) => e.given[t] === null),
					round: e.exchangeRound,
					total: e.exchangeTotal
				} : null,
				trick: {
					leader: e.trick.leader,
					plays: e.trick.plays.map((e) => ({
						rid: e.rid,
						card: e.card
					}))
				},
				lastTrick: e.lastTrick ? {
					plays: e.lastTrick.plays.map((e) => ({
						rid: e.rid,
						card: e.card
					})),
					winner: e.lastTrick.winner
				} : null,
				turn: e.phase === "play" ? e.turn : null,
				pending: e.pending,
				loseReason: e.loseReason
			},
			private: {
				hand: [...r].sort((e, t) => e.s.localeCompare(t.s) || e.v - t.v),
				mustFollow: a,
				exchange: o,
				pirateChoices: e.phase === "pirates" && e.pirates[t] === null ? [
					1,
					2,
					3,
					4,
					5,
					6
				].filter((n) => !e.players.some((r) => r !== t && e.pirates[r] === n)) : null
			}
		};
	},
	status(e) {
		return e.phase === "won" ? {
			phase: e.phase,
			winner: [...e.players],
			ranking: [...e.players]
		} : { phase: e.phase };
	}
}, H = 52, Fe = [
	4,
	3,
	2,
	1,
	2,
	3,
	4
], Ie = [
	22,
	23,
	24,
	25,
	24,
	23,
	22
], U = (e) => [(e.l - 3) * H, -e.n * H], Le = (() => {
	let e = [];
	for (let t = 0; t <= 6; t += 1) for (let n = Fe[t]; n <= Ie[t]; n += 2) e.push({
		l: t,
		n
	});
	return e.filter((e) => w(e.l, e.n));
})(), Re = "0,-25 25,0 0,25 -25,0";
function ze() {
	return /* @__PURE__ */ p("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ f("ellipse", {
			cy: 3,
			rx: 39,
			ry: 27,
			fill: "#fff5d4",
			stroke: "#143b4c",
			strokeWidth: 3
		}), /* @__PURE__ */ f("image", {
			href: "./games/sail/ship.webp",
			x: -37,
			y: -27,
			width: 74,
			height: 57,
			style: { mixBlendMode: "multiply" }
		})]
	});
}
function Be({ board: e, ship: t, sideLabels: o, preview: s }) {
	let c = r(null), { ref: l } = a("board"), [u, d] = i({
		w: 0,
		h: 0
	}), [m, h] = i(null), g = r({
		cx: 0,
		cy: 0,
		s: 1
	});
	n(() => {
		let e = c.current, t = new ResizeObserver(() => d({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let _ = S(t), v = Math.min(u.w / 416, Math.max(1.2, u.h / (5.5 * H))), y = Math.max(2.5, v * 1.5), b = r(y);
	n(() => {
		b.current = y;
	}, [y]);
	let [x, C] = i("");
	if (u.w > 0 && x !== `${_}:${u.w}:${u.h}`) {
		C(`${_}:${u.w}:${u.h}`);
		let [e, n] = U(t), r = v, i = u.w >= 700 && u.h >= 300 ? -u.h * .24 : u.h > 300 ? Math.min(u.h * .16, 68) : 0;
		h({
			cx: e * .4,
			cy: n + i / r,
			s: r
		});
	}
	let w = m ?? {
		cx: 0,
		cy: 0,
		s: 1
	};
	n(() => {
		g.current = w;
	}), n(() => {
		let e = c.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = g.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = Math.min(Math.max(r.s * i, .5), b.current), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			g.current = u, h(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, []);
	let T = r(/* @__PURE__ */ new Map()), E = r(0), D = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), T.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), T.current.size === 2) {
			let [e, t] = [...T.current.values()];
			E.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, O = (e) => {
		let t = T.current.get(e.pointerId);
		if (!t) return;
		let n = c.current.getBoundingClientRect();
		if (T.current.size === 1) {
			let n = g.current, r = {
				...n,
				cx: n.cx - (e.clientX - t.x) / n.s,
				cy: n.cy - (e.clientY - t.y) / n.s
			};
			g.current = r, h(r);
		} else if (T.current.size === 2) {
			T.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...T.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (E.current > 0 && i > 0) {
				let e = g.current, a = Math.min(Math.max(e.s * i / E.current, .5), b.current), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				g.current = u, h(u);
			}
			E.current = i;
			return;
		}
		T.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, k = (e) => {
		T.current.delete(e.pointerId), E.current = 0;
	}, A = new Set(e.islands.map(S)), ee = new Set(e.krakens.map(S)), j = new Set(e.ends.map(S));
	return /* @__PURE__ */ f("div", {
		ref: (e) => {
			c.current = e, l(e);
		},
		className: "sail-board relative h-full w-full overflow-hidden",
		children: /* @__PURE__ */ f("svg", {
			className: "h-full w-full touch-none select-none",
			onPointerDown: D,
			onPointerMove: O,
			onPointerUp: k,
			onPointerCancel: k,
			children: /* @__PURE__ */ p("g", {
				transform: `translate(${u.w / 2 - w.cx * w.s}, ${u.h / 2 - w.cy * w.s}) scale(${w.s})`,
				children: [
					/* @__PURE__ */ f("image", {
						href: "./games/sail/map.webp",
						x: -240,
						y: -1360,
						width: 480,
						height: 1450,
						preserveAspectRatio: "none",
						pointerEvents: "none"
					}),
					e.storms.map((e) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("line", {
						x1: -3.8 * H,
						y1: -(e + .5) * H,
						x2: 3.8 * H,
						y2: -(e + .5) * H,
						stroke: "#e65a56",
						strokeWidth: 4,
						strokeDasharray: "12 8",
						strokeLinecap: "round"
					}), /* @__PURE__ */ f("text", {
						x: -3.4 * H,
						y: -(e + .5) * H - 8,
						fontSize: 13,
						fontWeight: 800,
						fill: "#fff9e8",
						stroke: "#be534c",
						strokeWidth: 3,
						paintOrder: "stroke",
						children: `STORM ${String(e).padStart(2, "0")}`
					})] }, `storm${e}`)),
					Le.map((e) => {
						let [t, n] = U(e), r = S(e), i = A.has(r), a = ee.has(r), o = j.has(r), s = i ? "#ffda78" : a ? "#ef7775" : o ? "#fff0a6" : "#ffffff10";
						return /* @__PURE__ */ p("g", {
							transform: `translate(${t}, ${n})`,
							children: [
								/* @__PURE__ */ f("polygon", {
									points: Re,
									fill: s,
									stroke: i || a || o ? "#174457" : "#176b82",
									strokeOpacity: i || a || o ? 1 : .55,
									strokeWidth: 1.7,
									strokeLinejoin: "round"
								}),
								i && /* @__PURE__ */ p("g", {
									fill: "none",
									stroke: "#204c57",
									strokeWidth: 2.2,
									strokeLinecap: "round",
									children: [/* @__PURE__ */ f("path", { d: "M-12 7c4-7 8-8 12 0m0 0c5-9 10-8 13 0M-15 10h30" }), /* @__PURE__ */ f("circle", {
										cx: "0",
										cy: "-4",
										r: "3",
										fill: "#ffefb8"
									})]
								}),
								a && /* @__PURE__ */ p("g", {
									fill: "none",
									stroke: "#fff9eb",
									strokeWidth: 2.6,
									strokeLinecap: "round",
									children: [/* @__PURE__ */ f("circle", {
										cy: -3,
										r: 6
									}), /* @__PURE__ */ f("path", { d: "M-8 3c-5 2-5 6-7 7m11-5c-3 4-2 7-3 9M4 5c3 4 2 7 3 9M8 3c5 2 5 6 7 7" })]
								}),
								o && /* @__PURE__ */ p("g", {
									stroke: "#174457",
									strokeWidth: 2.2,
									strokeLinecap: "round",
									children: [/* @__PURE__ */ f("path", { d: "M-5 12V-13" }), /* @__PURE__ */ f("path", {
										d: "M-4-12l16 5-16 6z",
										fill: "#fff8de"
									})]
								})
							]
						}, r);
					}),
					s?.kind === "move" && s.target && (() => {
						let [e, n] = U(t), [r, i] = U(s.target);
						return /* @__PURE__ */ p("g", {
							pointerEvents: "none",
							children: [
								/* @__PURE__ */ f("path", {
									d: `M${e} ${n} L${r} ${i}`,
									fill: "none",
									stroke: "#153d50",
									strokeWidth: 8,
									strokeLinecap: "round",
									strokeDasharray: s.risky ? "10 7" : void 0
								}),
								/* @__PURE__ */ f("path", {
									d: `M${e} ${n} L${r} ${i}`,
									fill: "none",
									stroke: "#ffcf58",
									strokeWidth: 4,
									strokeLinecap: "round",
									strokeDasharray: s.risky ? "10 7" : void 0
								}),
								/* @__PURE__ */ f("polygon", {
									points: Re,
									transform: `translate(${r}, ${i})`,
									fill: "#ffcf5855",
									stroke: "#ffe48d",
									strokeWidth: 4
								})
							]
						});
					})(),
					/* @__PURE__ */ f("g", {
						transform: `translate(${U(e.start)[0]}, ${U(e.start)[1] + H * .72})`,
						pointerEvents: "none",
						children: /* @__PURE__ */ f("circle", {
							r: 7,
							fill: "#fff3d5",
							stroke: "#174457",
							strokeWidth: 2
						})
					}),
					/* @__PURE__ */ p("text", {
						x: -1.5 * H,
						y: U(t)[1] + 6,
						textAnchor: "end",
						fontSize: 13,
						fontWeight: 800,
						fill: o.left.color ?? "#173b4d",
						stroke: "#fff8e7",
						strokeWidth: 3,
						paintOrder: "stroke",
						pointerEvents: "none",
						children: [o.left.name, " ◀"]
					}),
					/* @__PURE__ */ p("text", {
						x: 1.5 * H,
						y: U(t)[1] + 6,
						fontSize: 13,
						fontWeight: 800,
						fill: o.right.color ?? "#173b4d",
						stroke: "#fff8e7",
						strokeWidth: 3,
						paintOrder: "stroke",
						pointerEvents: "none",
						children: ["▶ ", o.right.name]
					}),
					/* @__PURE__ */ f("g", {
						transform: `translate(${U(t)[0]}, ${U(t)[1]})`,
						children: /* @__PURE__ */ f(ze, {})
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/sail/card.tsx
var Ve = {
	gray: { art: "card-gray.webp" },
	green: { art: "card-green.webp" },
	blue: { art: "card-blue.webp" }
};
function He(e) {
	return `games.sail.suit.${e}`;
}
var W = (e) => `${e.s}-${e.v}`;
function G({ kind: e }) {
	return e === "wheel" ? /* @__PURE__ */ p("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.2",
		strokeLinecap: "round",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ f("circle", {
				cx: "12",
				cy: "12",
				r: "9"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "12",
				cy: "12",
				r: "2.5"
			}),
			/* @__PURE__ */ f("path", { d: "M12 3v6.5M12 14.5V21M3 12h6.5M14.5 12H21M5.6 5.6l4.6 4.6m3.6 3.6 4.6 4.6m0-12.8-4.6 4.6m-3.6 3.6-4.6 4.6" })
		]
	}) : e === "tentacle" ? /* @__PURE__ */ p("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.4",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ f("path", { d: "M5 20c4-2 1-6 5-8 3-1 5 2 7 0 3-3-1-6-3-4-1 1-.8 2 .2 3M7 18c4 1 5-2 6-4" }), /* @__PURE__ */ f("circle", {
			cx: "17",
			cy: "6",
			r: "2",
			fill: "currentColor",
			stroke: "none"
		})]
	}) : /* @__PURE__ */ p("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.3",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ f("path", { d: "M4 10h12l3-3v7l-3-2H4zM5 12v5h10v-5" }),
			/* @__PURE__ */ f("circle", {
				cx: "7",
				cy: "18",
				r: "2",
				fill: "currentColor"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "15",
				cy: "18",
				r: "2",
				fill: "currentColor"
			})
		]
	});
}
function Ue({ card: e, size: t }) {
	let n = M(e), r = e.s === "gray" && e.v >= 6 && e.v <= 8;
	return /* @__PURE__ */ f("span", {
		className: "sail-card__icons",
		"data-size": t,
		"data-orange": r || void 0,
		"aria-hidden": !0,
		children: n === "wheelTentacle" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(G, { kind: "wheel" }), /* @__PURE__ */ f(G, { kind: "tentacle" })] }) : /* @__PURE__ */ f(G, { kind: n })
	});
}
function K({ card: e, size: t, dimmed: n }) {
	let r = o()(He(e.s), { n: e.v });
	return /* @__PURE__ */ p("span", {
		className: "sail-card",
		"data-size": t,
		"data-suit": e.s,
		"data-dimmed": n || void 0,
		"aria-label": r,
		children: [
			t !== "mini" && /* @__PURE__ */ f("img", {
				className: "sail-card__art",
				src: `./games/sail/${Ve[e.s].art}`,
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ p("span", {
				className: "sail-card__corner",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ f("span", {
					className: "sail-card__number",
					children: e.v
				}), /* @__PURE__ */ f(Ue, {
					card: e,
					size: t
				})]
			}),
			/* @__PURE__ */ f("span", {
				className: "sail-card__stripe",
				"aria-hidden": !0
			})
		]
	});
}
function We({ accent: e }) {
	return /* @__PURE__ */ f("span", {
		className: "sail-card-back",
		style: { backgroundColor: e },
		"aria-hidden": !0,
		children: /* @__PURE__ */ f(G, { kind: "wheel" })
	});
}
//#endregion
//#region src/games/sail/preview.ts
function Ge(e, t) {
	if (e.phase !== "play" || !t) return null;
	if (e.trick.plays.length !== 1) return {
		kind: "waiting",
		damage: 0,
		risky: !1
	};
	let n = e.trick.plays[0], r = n.card.s !== t.s || n.card.v > t.v ? n.rid : e.turn ?? n.rid, i = e.players.find((e) => e.rid === r)?.pirate, a = n.card, o = [M(a), M(t)].sort().join("+"), s = {
		winner: r,
		damage: 0,
		risky: !1
	};
	if (o === "cannon+cannon") return {
		...s,
		kind: "flip"
	};
	if (o === "cannon+wheelTentacle") return {
		...s,
		kind: "bury"
	};
	let c, l = 0;
	if (o === "wheel+wheel" || o === "wheel+wheelTentacle" || o === "wheelTentacle+wheelTentacle") {
		if (o === "wheel+wheel" && a.v === t.v && i === 1 || i === 2 && (N(a) || N(t))) return {
			...s,
			kind: "pending"
		};
		let n = r === e.players[0]?.rid ? -1 : 1;
		c = T(e.ship, n), l = o === "wheel+wheelTentacle" ? 1 : o === "wheelTentacle+wheelTentacle" ? 2 : 0;
	} else if (o === "tentacle+tentacle") c = E(e.ship);
	else return {
		...s,
		kind: "none"
	};
	let u = O[e.scenario];
	return !c || k(u, c) ? {
		...s,
		kind: "blocked",
		damage: l,
		risky: l > 0
	} : {
		...s,
		kind: "move",
		target: c,
		damage: l,
		risky: l > 0 || A(u, c)
	};
}
//#endregion
//#region src/games/sail/view-player.tsx
function Ke(e) {
	return /* @__PURE__ */ f($e, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var qe = [
	1,
	2,
	3,
	4,
	5,
	6
], Je = {
	1: "games.sail.pirate.p1.name",
	2: "games.sail.pirate.p2.name",
	3: "games.sail.pirate.p3.name",
	4: "games.sail.pirate.p4.name",
	5: "games.sail.pirate.p5.name",
	6: "games.sail.pirate.p6.name"
}, Ye = {
	1: "games.sail.pirate.p1.ability",
	2: "games.sail.pirate.p2.ability",
	3: "games.sail.pirate.p3.ability",
	4: "games.sail.pirate.p4.ability",
	5: "games.sail.pirate.p5.ability",
	6: "games.sail.pirate.p6.ability"
}, Xe = {
	storm: "games.sail.loseReason.storm",
	round5: "games.sail.loseReason.round5",
	krakenCard: "games.sail.loseReason.krakenCard",
	krakenDead: "games.sail.loseReason.krakenDead",
	deadzone: "games.sail.loseReason.deadzone"
}, Ze = (e) => "./games/sail/" + e, Qe = (e, t) => String.fromCharCode(65 + e) + t;
function $e({ pub: e, priv: t, members: n, myRid: r, send: m }) {
	let h = o(), g = (e) => n.find((t) => t.rid === e)?.name ?? e, _ = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? s[t.colorIndex % s.length].hex : void 0;
	}, { ref: v } = a("table"), { ref: y } = a("trick"), { ref: b } = a("kraken"), x = t?.hand ?? [], S = e.phase === "play" && !e.pending && e.turn === r, C = e.pending?.rid === r, w = e.phase === "exchange" && (t?.exchange?.stage === "choose" || t?.exchange?.stage === "peek"), T = S || w, [E, D] = i(null), k = [
		e.phase,
		e.round,
		e.turn,
		x.length,
		e.trick.plays.length,
		e.exchange?.round,
		e.pending?.kind
	].join("|"), [A, ee] = i(k);
	A !== k && (ee(k), D(null));
	let j = (n) => T && (e.phase !== "play" || !t?.mustFollow || n.s === t.mustFollow), M = S && E ? Ge(e, E) : null, N, P, te;
	if (e.phase === "pirates") {
		let t = e.players.find((e) => e.rid === r)?.pirate != null;
		N = t ? "info" : "accent", P = h(t ? "games.sail.pickPirateWait" : "games.sail.pickPirateYou");
	} else if (e.phase === "exchange") {
		let n = t?.exchange?.stage ?? "wait";
		N = n === "wait" ? "info" : "accent", P = h(n === "wait" ? "games.sail.exchangeWait" : n === "peek" ? "games.sail.exchangePeek" : "games.sail.exchangeGive"), te = e.exchange && e.exchange.total > 1 ? h("games.sail.exchangeRound", {
			n: e.exchange.round,
			total: e.exchange.total
		}) : void 0;
	} else e.phase === "play" ? e.pending ? (N = C ? "accent" : "info", P = C ? h(e.pending.kind === "captain" ? "games.sail.pendingCaptain" : e.pending.kind === "helm" ? "games.sail.pendingHelm" : "games.sail.pendingGunner") : h("games.sail.pendingWait", { name: g(e.pending.rid) })) : (N = S ? "accent" : "info", P = S ? h("games.sail.turnYou") : h("games.sail.turnWait", { name: g(e.turn ?? "") })) : (N = e.phase === "won" ? "done" : "warn", P = h(e.phase === "won" ? "games.sail.won" : "games.sail.lost"));
	return /* @__PURE__ */ f("div", {
		className: "sail-game",
		children: /* @__PURE__ */ f(c, {
			adaptive: !0,
			className: "sail-layout",
			scroll: !1,
			banner: /* @__PURE__ */ p("div", {
				className: "sail-banner",
				children: [/* @__PURE__ */ f(l, {
					tone: N,
					text: P,
					sub: te,
					chip: h("games.sail.roundChip", { n: e.round }),
					accent: F.accent
				}), /* @__PURE__ */ f(u, {
					variant: "plate",
					members: n,
					myRid: r,
					anchorOf: (e) => "seat:" + e,
					action: (t) => e.phase === "pirates" ? e.players.find((e) => e.rid === t)?.pirate == null ? "pending" : null : e.phase === "exchange" ? e.exchange?.waiting.includes(t) ? "pending" : null : e.phase === "play" && (e.pending?.rid ?? e.turn) === t ? "pending" : null,
					status: (t) => {
						let n = e.players.find((e) => e.rid === t);
						return n ? /* @__PURE__ */ p("span", {
							className: "sail-player-status",
							children: [
								n.pirate != null && /* @__PURE__ */ f("img", {
									src: Ze("pirate-" + n.pirate + ".webp"),
									alt: h(Je[n.pirate])
								}),
								/* @__PURE__ */ p("span", {
									"aria-label": h("games.sail.tricksAria", { n: n.tricksWon }),
									children: ["◆", n.tricksWon]
								}),
								/* @__PURE__ */ p("span", {
									"aria-label": h("games.sail.handAria", { n: n.handCount }),
									children: ["▣", n.handCount]
								})
							]
						}) : null;
					}
				})]
			}),
			actionsHeight: "sail-actions h-[124px] short:h-[104px]",
			actions: /* @__PURE__ */ p("div", {
				className: "sail-hand-tray",
				children: [/* @__PURE__ */ p("div", {
					className: "sail-hand-title",
					children: [/* @__PURE__ */ f("span", { children: h("games.sail.myHand") }), /* @__PURE__ */ f("span", {
						className: "font-mono tabular-nums",
						children: x.length
					})]
				}), x.length > 0 && (e.phase === "exchange" || e.phase === "play" || e.phase === "lost") && /* @__PURE__ */ f("div", {
					className: "sail-hand-scroll",
					children: /* @__PURE__ */ f("div", {
						className: "sail-hand-list",
						children: x.map((n) => {
							let r = e.phase === "play" && S && t?.mustFollow != null && n.s !== t.mustFollow, i = E != null && W(E) === W(n);
							return /* @__PURE__ */ f("button", {
								type: "button",
								disabled: !j(n),
								onClick: () => D(i ? null : n),
								className: "sail-hand-button",
								style: { zIndex: i ? 3 : +!r },
								"aria-pressed": i,
								children: /* @__PURE__ */ f(tt, {
									card: n,
									raised: i,
									dimmed: r
								})
							}, W(n));
						})
					})
				})]
			}),
			overlay: /* @__PURE__ */ p("div", {
				className: "sail-overlays",
				children: [
					C && e.pending && e.pending.kind !== "gunner" && /* @__PURE__ */ p("div", {
						className: "sail-decision pointer-events-auto",
						children: [/* @__PURE__ */ f("strong", { children: h(e.pending.kind === "captain" ? "games.sail.pendingCaptain" : "games.sail.pendingHelm") }), /* @__PURE__ */ p("div", {
							className: "sail-decision-actions",
							children: [/* @__PURE__ */ f("button", {
								type: "button",
								className: "sail-secondary",
								onClick: () => m({
									type: "resolve",
									use: !1
								}),
								children: h(e.pending.kind === "captain" ? "games.sail.pendingCaptainSkip" : "games.sail.pendingHelmSkip")
							}), /* @__PURE__ */ f("button", {
								type: "button",
								className: "sail-primary",
								onClick: () => m({
									type: "resolve",
									use: !0
								}),
								children: h(e.pending.kind === "captain" ? "games.sail.pendingCaptainUse" : "games.sail.pendingHelmUse")
							})]
						})]
					}),
					C && e.pending?.kind === "gunner" && e.pending.cards && /* @__PURE__ */ p("div", {
						className: "sail-decision pointer-events-auto",
						children: [/* @__PURE__ */ f("strong", { children: h("games.sail.pendingGunner") }), /* @__PURE__ */ f("div", {
							className: "sail-decision-actions",
							children: e.pending.cards.map((e, t) => /* @__PURE__ */ f("button", {
								type: "button",
								className: "sail-pick-cannon",
								onClick: () => m({
									type: "pickCannon",
									index: t
								}),
								children: /* @__PURE__ */ f(K, {
									card: e,
									size: "table"
								})
							}, W(e)))
						})]
					}),
					E && T && !C && /* @__PURE__ */ p("div", {
						className: "sail-decision pointer-events-auto",
						children: [/* @__PURE__ */ p("div", {
							className: "sail-preview-copy",
							children: [/* @__PURE__ */ f(K, {
								card: E,
								size: "mini"
							}), /* @__PURE__ */ p("span", { children: [e.phase === "exchange" ? h("games.sail.exchangeGive") : ((e) => e ? e.kind === "waiting" ? h("games.sail.previewWaiting") : e.kind === "pending" ? h("games.sail.previewPending") : e.kind === "flip" ? h("games.sail.previewFlip") : e.kind === "bury" ? h("games.sail.previewBury") : e.kind === "blocked" ? h("games.sail.previewBlocked") : e.kind === "none" ? h("games.sail.previewNone") : e.target ? h(e.risky ? "games.sail.previewRisk" : "games.sail.previewMove", { cell: Qe(e.target.l, e.target.n) }) : null : null)(M), M?.damage ? " · " + h("games.sail.previewDamage", { n: M.damage }) : ""] })]
						}), /* @__PURE__ */ p("div", {
							className: "sail-decision-actions",
							children: [/* @__PURE__ */ f("button", {
								type: "button",
								className: "sail-secondary",
								onClick: () => D(null),
								children: h("games.sail.cancel")
							}), /* @__PURE__ */ f("button", {
								type: "button",
								className: "sail-primary",
								onClick: () => {
									m(e.phase === "exchange" ? t?.exchange?.stage === "peek" ? {
										type: "chooseGive",
										card: E
									} : {
										type: "give",
										card: E
									} : {
										type: "play",
										card: E
									}), D(null);
								},
								children: h(e.phase === "exchange" ? "games.sail.giveCard" : "games.sail.playCard")
							})]
						})]
					})
				]
			}),
			children: /* @__PURE__ */ f("div", {
				ref: v,
				className: "sail-table",
				children: e.phase === "pirates" ? /* @__PURE__ */ f("div", {
					className: "sail-pirate-grid",
					children: qe.map((n) => {
						let i = e.players.find((e) => e.pirate === n)?.rid, a = i === r, o = t?.pirateChoices?.includes(n) ?? !1;
						return /* @__PURE__ */ p("button", {
							type: "button",
							disabled: !o,
							onClick: () => m({
								type: "pickPirate",
								pirate: n
							}),
							className: "sail-pirate-card",
							"data-mine": a || void 0,
							"data-taken": i != null && !a || void 0,
							children: [
								/* @__PURE__ */ f("img", {
									src: Ze("pirate-" + n + ".webp"),
									alt: "",
									draggable: !1
								}),
								/* @__PURE__ */ p("span", {
									className: "sail-pirate-content",
									children: [/* @__PURE__ */ p("strong", { children: [
										String(n).padStart(2, "0"),
										" ",
										h(Je[n])
									] }), /* @__PURE__ */ f("small", { children: h(Ye[n]) })]
								}),
								i && /* @__PURE__ */ f("span", {
									className: "sail-pirate-holder",
									style: { color: _(i) },
									children: g(i)
								})
							]
						}, n);
					})
				}) : /* @__PURE__ */ p(d, { children: [
					/* @__PURE__ */ f(Be, {
						board: O[e.scenario],
						ship: e.ship,
						preview: M,
						sideLabels: {
							left: {
								name: g(e.players[0]?.rid ?? ""),
								color: _(e.players[0]?.rid ?? "")
							},
							right: {
								name: g(e.players[1]?.rid ?? ""),
								color: _(e.players[1]?.rid ?? "")
							}
						}
					}),
					/* @__PURE__ */ p("div", {
						className: "sail-dashboard",
						children: [/* @__PURE__ */ p("div", {
							className: "sail-track",
							"aria-label": h("games.sail.krakenTrackAria", { n: e.krakenTrack + 1 }),
							children: [/* @__PURE__ */ f("span", {
								className: "sail-dashboard-label",
								children: h("games.sail.krakenDamage")
							}), /* @__PURE__ */ p("div", {
								className: "sail-track-spaces",
								children: [ue.map((t, n) => /* @__PURE__ */ f("span", {
									className: n === e.krakenTrack ? "is-current" : "",
									children: t
								}, n)), /* @__PURE__ */ f("span", {
									className: e.krakenTrack === 4 ? "is-current" : "",
									children: "☠"
								})]
							})]
						}), /* @__PURE__ */ p("div", {
							ref: b,
							className: "sail-deck",
							"aria-label": h("games.sail.krakenDeckAria", { n: e.krakenDeck.length }),
							children: [/* @__PURE__ */ f("span", {
								className: "sail-dashboard-label",
								children: h("games.sail.krakenDeck")
							}), /* @__PURE__ */ p("div", {
								className: "sail-deck-row",
								children: [e.krakenDeck[0] === "K" ? /* @__PURE__ */ f("span", {
									className: "sail-kraken-card",
									children: "✦"
								}) : e.krakenDeck[0] && /* @__PURE__ */ f(K, {
									card: e.krakenDeck[0],
									size: "mini"
								}), /* @__PURE__ */ p("b", {
									className: "font-mono tabular-nums",
									children: ["×", e.krakenDeck.length]
								})]
							})]
						})]
					}),
					/* @__PURE__ */ p("div", {
						className: "sail-trick-tray",
						"data-lost": e.phase === "lost" || void 0,
						"data-exchange": e.phase === "exchange" || void 0,
						children: [
							/* @__PURE__ */ f("div", {
								className: "sail-trick-copy",
								children: e.phase === "exchange" ? /* @__PURE__ */ f(d, { children: t?.exchange?.received ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", { children: h("games.sail.exchangeReceived") }), /* @__PURE__ */ f(K, {
									card: t.exchange.received,
									size: "mini"
								})] }) : t?.exchange?.peek ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", { children: h("games.sail.exchangePeekCard") }), /* @__PURE__ */ f(K, {
									card: t.exchange.peek,
									size: "mini"
								})] }) : h("games.sail.exchangeGive") }) : e.phase === "play" ? e.trick.plays.length ? h("games.sail.currentTrick") : e.lastTrick ? h("games.sail.lastTrick", { name: g(e.lastTrick.winner) }) : h("games.sail.trickLead", { name: g(e.trick.leader) }) : e.phase === "lost" ? h(Xe[e.loseReason ?? "round5"]) : h("games.sail.won")
							}),
							/* @__PURE__ */ p("div", {
								ref: y,
								className: "sail-trick-cards",
								children: [e.phase === "play" && e.trick.plays.map((e, t) => /* @__PURE__ */ p("span", {
									className: "sail-trick-play",
									children: [/* @__PURE__ */ f(et, {
										index: t,
										card: e.card
									}), /* @__PURE__ */ f("small", {
										style: { color: _(e.rid) },
										children: g(e.rid)
									})]
								}, e.rid)), e.phase === "play" && e.trick.plays.length === 0 && e.lastTrick?.plays.map((e, t) => /* @__PURE__ */ f(K, {
									card: e.card,
									size: "mini"
								}, e.rid + t))]
							}),
							e.phase === "lost" && /* @__PURE__ */ f("button", {
								type: "button",
								className: "sail-primary",
								onClick: () => m({ type: "retry" }),
								children: h("games.sail.retry")
							})
						]
					})
				] })
			})
		})
	});
}
function et({ index: e, card: t }) {
	let { ref: n, hidden: r } = a("tcard:" + e);
	return /* @__PURE__ */ f("span", {
		ref: n,
		className: "inline-flex",
		style: { visibility: r ? "hidden" : void 0 },
		children: /* @__PURE__ */ f(K, {
			card: t,
			size: "table"
		})
	});
}
function tt({ card: e, raised: t, dimmed: n }) {
	let { ref: r, hidden: i } = a("hand:" + W(e));
	return /* @__PURE__ */ f("span", {
		ref: r,
		className: t ? "sail-hand-raised" : "",
		style: { visibility: i ? "hidden" : void 0 },
		children: /* @__PURE__ */ f(K, {
			card: e,
			size: "hand",
			dimmed: n
		})
	});
}
//#endregion
//#region src/games/sail/bot.ts
var nt = [
	3,
	3,
	4,
	5
], q = (e) => [...e].sort((e, t) => e.v - t.v), J = (e) => M(e) === "wheel", rt = (e) => M(e) === "tentacle", Y = (e) => M(e) === "cannon", X = (e) => M(e) === "wheelTentacle", it = (e) => Y(e) ? 0 : rt(e) ? 1 : J(e) ? 2 : 3, at = (e) => [...e].sort((e, t) => it(e) - it(t) || e.v - t.v);
function ot(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function st(e, t) {
	let n = /* @__PURE__ */ new Set([`${t.l},${t.n}`]), r = [{
		c: t,
		d: 0
	}];
	for (; r.length > 0;) {
		let t = r.shift();
		if (ee(e, t.c)) return t.d;
		for (let i of [
			T(t.c, -1),
			T(t.c, 1),
			E(t.c)
		]) {
			if (!i || k(e, i)) continue;
			let a = `${i.l},${i.n}`;
			n.has(a) || (n.add(a), r.push({
				c: i,
				d: t.d + 1
			}));
		}
	}
	return Infinity;
}
function Z(e, t) {
	if (t === "S") {
		let t = E(e.ship);
		return t && !k(e.board, t) && j(e.board, t) ? 1 + st(e.board, t) : Infinity;
	}
	let n = T(e.ship, t === "L" ? -1 : 1);
	return n && !k(e.board, n) && j(e.board, n) ? 1 + st(e.board, n) : Infinity;
}
function ct(e) {
	let t = (t) => {
		let n = T(e.ship, t === "L" ? -1 : 1);
		return n && A(e.board, n) ? .5 : 0;
	}, n = Z(e, "L") + t("L"), r = Z(e, "R") + t("R"), i = Z(e, "S"), a = e.round <= 2 ? 0 : e.round <= 4 ? 1 : -1, o = a >= 0 ? e.board.storms[a] : void 0, s = !1;
	if (o !== void 0) {
		let t = Math.max(0, (a === 0 ? 2 : 4) - e.round);
		s = o + 1 - e.ship.n > t * 2 + 2;
	}
	if (s) return {
		dir: Number.isFinite(i) ? "S" : null,
		storm: !0
	};
	let c = [];
	if (Number.isFinite(n) && c.push("L"), Number.isFinite(r) && c.push("R"), c.length === 0) return {
		dir: Number.isFinite(i) ? "S" : null,
		storm: !1
	};
	if (c.length === 1) return {
		dir: c[0],
		storm: !1
	};
	let l = e.players[0]?.tricksWon ?? 0, u = e.players[1]?.tricksWon ?? 0;
	if (Math.max(l, u) >= 3) {
		let e = l <= u ? "L" : "R";
		if (Number.isFinite(e === "L" ? n : r)) return {
			dir: e,
			storm: !1
		};
	}
	return Math.max(n, r) - Math.min(n, r) > 1 ? {
		dir: n < r ? "L" : "R",
		storm: !1
	} : {
		dir: l <= u ? "L" : "R",
		storm: !1
	};
}
function lt(e, t) {
	let n = /* @__PURE__ */ new Set(), r = (e) => n.add(`${e.s}-${e.v}`);
	for (let e of t) r(e);
	for (let t of e.discard) r(t);
	for (let t of e.trick.plays) r(t.card);
	for (let t of e.krakenDeck) t !== "K" && r(t);
	return te().filter((e) => !n.has(`${e.s}-${e.v}`));
}
var ut = 3;
function dt(e) {
	return e.krakenDeck.length - 1 <= nt[Math.min(e.krakenTrack, nt.length - 1)] + ut;
}
function ft(e, t, n) {
	let r = ct(e), i = e.players[0].rid === n ? "R" : "L", a = t.filter(J);
	if (a.length > 0) {
		let e = a.filter((e) => a.some((t) => t !== e && t.s === e.s)), t = e.length > 0 ? e : a, n = Math.max(...t.map((e) => a.filter((t) => t.s === e.s).length)), o = t.filter((e) => a.filter((t) => t.s === e.s).length === n);
		return r.dir === i ? o.reduce((e, t) => t.v > e.v ? t : e) : q(o)[0];
	}
	let o = t.filter((e) => !J(e) && !rt(e) && !X(e));
	return q(o.length > 0 ? o : t)[0];
}
var pt = (e, t) => e.filter((e) => e.s === t && J(e)).length;
function mt(e, t, n, r, i, a, o) {
	let s = e.players[0].rid === n ? "L" : "R", c = s === "L" ? "R" : "L", l = lt(e, t), u = t.filter(J), d = t.filter(X), f = t.filter(Y), p = q(f.filter((e) => l.some((t) => t.s === e.s && X(t)))), m = e.krakenDeck.length - 1 <= nt[Math.min(e.krakenTrack, nt.length - 1)];
	if (u.length > 0) {
		if (m && !i.storm && p.length > 0) return p[0];
		let t = /* @__PURE__ */ new Set();
		for (let n of e.discard) t.add(`${n.s}-${n.v}`);
		for (let n of e.trick.plays) t.add(`${n.card.s}-${n.card.v}`);
		let n = i.storm || i.dir === null || i.dir === "S" ? null : i.dir === s;
		for (let r of a) {
			if (!J(r) || t.has(`${r.s}-${r.v}`)) continue;
			let i = q(u.filter((e) => e.s === r.s));
			if (i.length === 0) continue;
			let a = i.filter((e) => e.v > r.v), o = i.filter((e) => e.v < r.v), l = a.length > 0 && Number.isFinite(Z(e, s)), d = o.length > 0 && Number.isFinite(Z(e, c));
			if (n === !0 && l) return a[0];
			if (n === !1 && d) return q(o)[0];
			if (l) return a[0];
			if (d) return q(o)[0];
		}
		let r = (e) => o.cold.has(e) ? -10 : o.voided.has(e) ? 5 : pt(l, e), d = ((e) => q(u.filter((t) => t.s === e)))([...new Set(u.map((e) => e.s))].sort((e, t) => r(t) - r(e))[0]);
		return i.storm || i.dir === null ? d[Math.floor(d.length / 2)] : i.dir === s ? d[d.length - 1] : d[0];
	}
	return i.storm && d.length > 0 ? d[0] : r && p.length > 0 ? p[0] : r && d.length > 0 ? d[0] : f.length > 0 ? q(f)[0] : q(t)[0];
}
function ht(e, t, n, r, i) {
	let a = t.hand, o = e.trick.plays[0], s = M(o.card), c = e.players[0].rid === n ? "L" : "R", l = c === "L" ? "R" : "L", u = i.dir === null || i.dir === "S" ? null : i.dir === c, d = i.dir === null || i.dir === "S" || i.dir === l;
	if (t.mustFollow) {
		let n = a.filter((e) => e.s === t.mustFollow), f = n.filter(J), p = n.filter(Y), m = n.filter((e) => !X(e));
		if (X(o.card)) {
			let t = f.length > 0 && Number.isFinite(Z(e, c));
			return i.storm && t ? f[0] : r ? p.length > 0 ? p[0] : at(m.length > 0 ? m : n)[0] : t ? f[0] : p.length > 0 ? p[0] : at(m.length > 0 ? m : n)[0];
		}
		if (Y(o.card)) {
			if (r) {
				let e = n.filter(X);
				if (e.length > 0) return e[0];
			}
			return p.length > 0 ? p[0] : at(m.length > 0 ? m : n)[0];
		}
		if (s === "wheel") {
			if (f.length > 0) {
				if (u === !1 && d) {
					let e = f.filter((e) => e.v < o.card.v);
					return q(e.length > 0 ? e : f)[0];
				}
				if (u === !0) {
					let t = f.filter((e) => e.v > o.card.v);
					if (t.length > 0) return q(t)[0];
					if (Number.isFinite(Z(e, l))) return q(f)[0];
				}
				if (u === null) {
					let e = f.filter((e) => e.v > o.card.v);
					return q(e.length > 0 ? e : f)[0];
				}
			}
			if (i.storm) {
				let t = n.filter(X);
				if (t.length > 0 && Number.isFinite(Z(e, l))) return t[0];
			}
			return q(m.length > 0 ? m : n)[0];
		}
		if (u === !0) {
			let e = n.filter((e) => e.v > o.card.v);
			if (e.length > 0) return q(e)[0];
		}
		return at(n)[0];
	}
	let f = a.filter(J), p = a.filter(rt);
	if (Y(o.card) && r) {
		let e = a.filter(X);
		if (e.length > 0) return e[0];
	}
	if (s === "tentacle" && p.length > 0) return p[0];
	if (s === "wheel") {
		let t = T(e.ship, l === "L" ? -1 : 1), n = t !== null && !k(e.board, t) && j(e.board, t) && !(r && A(e.board, t));
		if (f.length > 0 && n) return q(f)[0];
	}
	let m = a.filter((e) => !J(e) && !rt(e) && !X(e));
	return m.length > 0 ? q(m)[0] : p.length > 0 ? p[0] : q(a)[0];
}
var gt = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	let i = t.rid, a = r.hand, o = t.difficulty === "weak", s = t.memory, c = s?.round === n.round, l = c ? s.given ?? [] : [], u = new Set(c ? s.cold ?? [] : []), d = new Set(c ? s.voided ?? [] : []), f = c ? s.seen ?? 0 : 0;
	if (n.phase === "pirates") {
		let e = r.pirateChoices;
		return !e || e.length === 0 ? null : { action: {
			type: "pickPirate",
			pirate: [
				1,
				2,
				6,
				3,
				5,
				4
			].find((t) => e.includes(t)) ?? e[0]
		} };
	}
	if (n.phase === "exchange") {
		let e = r.exchange?.stage;
		if (e === "choose" || e === "peek") {
			let t = o ? q(a)[0] : ft(n, a, i), r = c ? l : [];
			return {
				action: {
					type: e === "peek" ? "chooseGive" : "give",
					card: t
				},
				memory: {
					round: n.round,
					given: [...r, t]
				}
			};
		}
		return null;
	}
	if (n.phase !== "play") return null;
	if (n.pending && n.pending.rid === i) {
		if (o) {
			if (n.pending.kind === "gunner" && n.pending.cards) {
				let [e, t] = n.pending.cards, r = (e) => J(e) ? 3 : rt(e) ? 2 : +!!Y(e);
				return { action: {
					type: "pickCannon",
					index: +(r(t) > r(e))
				} };
			}
			return { action: {
				type: "resolve",
				use: !0
			} };
		}
		let e = ct(n), t = n.players[0].rid === i ? "L" : "R";
		if (n.pending.kind === "gunner" && n.pending.cards) {
			let r = dt(n), i = (n) => {
				let i = M(n);
				return i === "wheelTentacle" ? r ? 4 : 1.5 : e.dir === "S" && i === "tentacle" || (e.dir === t || e.dir === null) && i === "wheel" ? 3 : i === "cannon" ? .5 : 1;
			}, [a, o] = n.pending.cards;
			return { action: {
				type: "pickCannon",
				index: +(i(o) > i(a))
			} };
		}
		if (n.pending.kind === "captain") {
			let e = Z(n, "S"), r = Z(n, t);
			return { action: {
				type: "resolve",
				use: Number.isFinite(e) && e <= r
			} };
		}
		let r = t === "L" ? "R" : "L";
		return { action: {
			type: "resolve",
			use: e.dir === r
		} };
	}
	if (n.pending || n.turn !== i || a.length === 0) return null;
	let p = r.mustFollow ? a.filter((e) => e.s === r.mustFollow) : a;
	if (p.length === 0) return null;
	if (o) {
		if (n.trick.plays.length === 0) {
			let e = p.filter(J);
			return { action: {
				type: "play",
				card: (e.length > 0 ? e : p).reduce((e, t) => t.v > e.v ? t : e)
			} };
		}
		return { action: {
			type: "play",
			card: q(p)[0]
		} };
	}
	let m = dt(n), h = ct(n), g = (n.players[0]?.tricksWon ?? 0) + (n.players[1]?.tricksWon ?? 0);
	if (g > f && n.lastTrick) {
		f = g;
		let e = n.lastTrick.plays[0], t = n.lastTrick.plays[1];
		e && t && t.rid !== i && (t.card.s === e.card.s ? J(t.card) || u.add(t.card.s) : d.add(e.card.s));
	}
	let _ = {
		round: n.round,
		given: l,
		cold: [...u],
		voided: [...d],
		seen: f
	}, v = c ? l : [], y = n.trick.plays.length === 0 ? mt(n, a, i, m, h, v, {
		cold: u,
		voided: d
	}) : ht(n, r, i, m, h);
	return {
		action: {
			type: "play",
			card: p.some((e) => e.s === y.s && e.v === y.v) ? y : ot(p)
		},
		memory: _
	};
};
//#endregion
//#region src/games/sail/fx.tsx
function Q(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function _t(e) {
	if (typeof e != "object" || !e) return null;
	let t = e;
	return typeof t.s == "string" && typeof t.v == "number" ? t : null;
}
function vt(e) {
	if (!Array.isArray(e)) return null;
	let t = e.map(_t);
	return t.every((e) => e !== null) ? t : null;
}
function $(e, t, n) {
	let r = e.w / 96, i = 44 * r, a = 64 * r, o = 8 * r, s = n * i + (n - 1) * o;
	return {
		x: e.x + (e.w - s) / 2 + t * (i + o),
		y: e.y + Math.max(0, (e.h - a - 10 * r) / 2),
		w: i,
		h: a
	};
}
function yt({ box: e, card: t, size: n = "table" }) {
	let r = n === "hand" ? 56 : 44, i = n === "hand" ? 80 : 64;
	return /* @__PURE__ */ f("span", {
		style: {
			display: "block",
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ f("span", {
			style: {
				display: "inline-flex",
				width: r,
				height: i,
				transform: `scale(${e.w / r})`,
				transformOrigin: "top left"
			},
			children: t ? /* @__PURE__ */ f(K, {
				card: t,
				size: n
			}) : /* @__PURE__ */ f(We, { accent: F.accent })
		})
	});
}
var bt = {
	deal(e, t) {
		let n = e.secret, r = n ? vt(n.cards) : null, i = t.anchor("table");
		if (r) {
			if (!i) return null;
			let e = [], n = [];
			for (let [a, o] of r.entries()) {
				let r = t.anchor(`hand:${W(o)}`);
				if (!r) continue;
				let s = {
					x: i.x + (i.w - r.w) / 2,
					y: i.y + (i.h - r.h) / 2,
					w: r.w,
					h: r.h
				};
				n.push(`hand:${W(o)}`), e.push(/* @__PURE__ */ f(h, {
					from: s,
					to: r,
					ms: 320,
					delay: a * 45,
					children: /* @__PURE__ */ f(yt, {
						box: s,
						card: o,
						size: "hand"
					})
				}, W(o)));
			}
			return e.length ? {
				ms: 320 + e.length * 45,
				node: e,
				hide: n
			} : null;
		}
		let a = Q(t, e.rid);
		if (!i || !a) return null;
		let o = t.anchor("trick"), s = o ? $(o, 0, 2) : {
			w: 44,
			h: 64
		}, c = {
			x: i.x + (i.w - s.w) / 2,
			y: i.y + (i.h - s.h) / 2,
			w: s.w,
			h: s.h
		}, l = e.data?.count, u = typeof l == "number" ? l : 9;
		return {
			ms: 320 + u * 45,
			node: Array.from({ length: u }, (e, t) => /* @__PURE__ */ f(h, {
				from: c,
				to: a,
				ms: 320,
				delay: t * 45,
				children: /* @__PURE__ */ f(yt, { box: c })
			}, t))
		};
	},
	play(e, t) {
		let n = _t(e.data?.card), r = e.data?.index, i = Q(t, e.rid);
		if (!n || !i || typeof r != "number") return null;
		let a = t.anchor("trick"), o = t.anchor(`tcard:${r}`) ?? (a ? $(a, r, r + 1) : null);
		return o ? {
			ms: 400,
			node: /* @__PURE__ */ f(h, {
				from: i,
				to: o,
				ms: 380,
				children: /* @__PURE__ */ f(yt, {
					box: {
						...i,
						w: o.w,
						h: o.h
					},
					card: n
				})
			}),
			hide: [`tcard:${r}`]
		} : null;
	},
	gather(e, t) {
		let n = Q(t, e.rid), r = t.anchor("trick");
		return !n || !r ? null : {
			ms: 500,
			node: [0, 1].map((e) => /* @__PURE__ */ f(h, {
				from: $(r, e, 2),
				to: n,
				ms: 420,
				delay: e * 50,
				children: /* @__PURE__ */ f(yt, { box: $(r, e, 2) })
			}, e))
		};
	},
	give(e, t) {
		let n = Q(t, e.rid);
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ f(g, {
				at: n,
				ms: 500
			})
		} : null;
	},
	receive(e, t) {
		let n = Q(t, e.rid);
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ f(g, {
				at: n,
				ms: 500
			})
		} : null;
	},
	move(e, t) {
		let n = t.anchor("board");
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ f(g, {
				at: n,
				ms: 500
			})
		} : null;
	},
	krakenHit(e, t) {
		let n = t.anchor("kraken");
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ f(m, {
				at: n,
				ms: 800,
				delay: 60,
				children: "🦑"
			})
		} : null;
	},
	krakenMeeple(e, t) {
		let n = t.anchor("kraken");
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ f(g, {
				at: n,
				ms: 500
			})
		} : null;
	},
	bury(e, t) {
		let n = _t(e.data?.card), r = t.anchor("kraken"), i = t.anchor("trick");
		return !n || !r || !i ? null : {
			ms: 450,
			node: /* @__PURE__ */ f(h, {
				from: $(i, 0, 2),
				to: r,
				ms: 400,
				children: /* @__PURE__ */ f(yt, {
					box: $(i, 0, 2),
					card: n
				})
			})
		};
	},
	flip(e, t) {
		let n = t.anchor("table");
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ f(g, {
				at: n,
				ms: 500
			})
		} : null;
	},
	pirate(e, t) {
		let n = Q(t, e.rid);
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ f(g, {
				at: n,
				ms: 500
			})
		} : null;
	},
	pirateUse(e, t) {
		let n = Q(t, e.rid);
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ f(g, {
				at: n,
				ms: 600
			})
		} : null;
	}
};
//#endregion
//#region src/games/sail/game-over.tsx
function xt(e) {
	return /* @__PURE__ */ f("div", {
		className: "sail-game-over",
		children: /* @__PURE__ */ f(_, {
			...e,
			accent: F.accent
		})
	});
}
//#endregion
//#region src/games/sail/options.tsx
function St({ value: e, onChange: t }) {
	let n = o(), r = ae.safeParse(e), i = r.success ? r.data : ae.parse(void 0);
	return /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ f(y, {
			title: n("games.sail.optScenario"),
			columns: 3,
			children: [
				0,
				1,
				2
			].map((e) => /* @__PURE__ */ f(v, {
				name: "sail-scenario",
				value: String(e),
				checked: i.scenario === e,
				label: n(e === 0 ? "games.sail.scenario.learning" : e === 1 ? "games.sail.scenario.s1" : "games.sail.scenario.s2"),
				accent: F.accent,
				onChange: () => t({
					...i,
					scenario: e
				})
			}, e))
		}), /* @__PURE__ */ f(y, {
			title: n("games.sail.optPirates"),
			children: [!0, !1].map((e) => /* @__PURE__ */ f(v, {
				name: "sail-pirates",
				value: String(e),
				checked: i.pirates === e,
				label: n(e ? "games.sail.piratesOn" : "games.sail.piratesOff"),
				accent: F.accent,
				onChange: () => t({
					...i,
					pirates: e
				})
			}, String(e)))
		})]
	});
}
//#endregion
//#region src/games/sail/guide.tsx
var Ct = [
	{
		icons: ["wheel", "wheel"],
		textKey: "games.sail.guide.c1"
	},
	{
		icons: ["wheel", "wheelTentacle"],
		textKey: "games.sail.guide.c2"
	},
	{
		icons: ["wheelTentacle", "wheelTentacle"],
		textKey: "games.sail.guide.c3"
	},
	{
		icons: ["wheelTentacle", "cannon"],
		textKey: "games.sail.guide.c4"
	},
	{
		icons: ["tentacle", "tentacle"],
		textKey: "games.sail.guide.c5"
	},
	{
		icons: ["cannon", "cannon"],
		textKey: "games.sail.guide.c6"
	}
];
function wt({ kind: e }) {
	return /* @__PURE__ */ f("span", {
		className: "inline-flex items-center gap-0.5 [&_svg]:size-4",
		children: e === "wheelTentacle" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(G, { kind: "wheel" }), /* @__PURE__ */ f(G, { kind: "tentacle" })] }) : /* @__PURE__ */ f(G, { kind: e })
	});
}
function Tt() {
	let e = o();
	return /* @__PURE__ */ p("section", {
		className: "flex w-full flex-col gap-1.5",
		children: [
			/* @__PURE__ */ f("p", {
				className: "section-label",
				children: e("games.sail.guideTitle")
			}),
			/* @__PURE__ */ f("div", {
				className: "frame flex flex-col gap-1 p-2",
				children: Ct.map((t) => /* @__PURE__ */ p("div", {
					className: "flex items-center gap-2 text-xs font-bold",
					children: [/* @__PURE__ */ p("span", {
						"aria-hidden": !0,
						className: "flex w-24 flex-none items-center justify-center gap-1 rounded-lg border-2 border-ink/15 bg-surface py-1 text-sm",
						children: [
							/* @__PURE__ */ f(wt, { kind: t.icons[0] }),
							"+",
							/* @__PURE__ */ f(wt, { kind: t.icons[1] })
						]
					}), /* @__PURE__ */ f("span", {
						className: "min-w-0 flex-1 leading-4",
						children: e(t.textKey)
					})]
				}, t.textKey))
			}),
			/* @__PURE__ */ f("p", {
				className: "text-xs leading-5 font-bold opacity-70",
				children: e("games.sail.guideCaption")
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/sail/entry.tsx
var Et = {
	definition: Pe,
	View: Ke,
	bot: gt,
	fx: bt,
	OverView: xt,
	Options: St,
	Guide: Tt,
	locales: {
		zh: {
			name: "深海迷途",
			desc: "双人合作吃墩:驾船穿越风暴与克拉肯,抵达终点",
			rules: "目标:两人合作驾船,在第 5 轮结束前驶入终点格;触发任一败北条件即失败。\n牌:\n· 玩家牌堆 21 张:灰、绿、蓝三花色各 3~9;另有克拉肯牌堆,由三花色的 1 和 2 各一张组成。\n· 牌面图标决定动作:1~3 为舵+触手,4~5 为炮,6~8 为舵,9 为触手。\n每轮:\n· 重洗全部玩家牌,各发 9 张;随后互递 1 张(收到前看不到对方递出的牌),然后开始吃墩。\n· 必须跟花色;领出花色中数字较大者赢墩,并领出下一墩。\n· 任一玩家赢下第 4 墩时本轮结束:克拉肯按其轨道当前数字对船造成伤害,随后重洗进入下一轮。\n动作:\n· 按一墩两张牌的图标组合结算(见下方速查表)。\n版图:\n· 斜进即朝赢墩方一侧斜向前进,直行即向正前方;岛屿不可驶入,出界则停留原地。\n· 驶入克拉肯格受 1 点伤害。\n· 第 2、4 轮结束时,船必须完全越过风暴线。\n胜负:\n· 船驶入终点格,立即获胜。\n· 以下情况立即失败:克拉肯卡成为克拉肯牌堆唯一一张;克拉肯标记走到骷髅格;终点已无法到达。",
			optScenario: "场景",
			optPirates: "海盗卡",
			piratesOn: "启用",
			piratesOff: "关闭",
			scenario: {
				learning: "教学",
				s1: "场景 1",
				s2: "场景 2"
			},
			pickPirateYou: "选你的海盗",
			pickPirateWait: "等对方选海盗…",
			exchangeGive: "选一张牌递给对方",
			exchangeWait: "等对方递牌…",
			exchangePeek: "先看再递:选一张回递",
			exchangePeekCard: "对方递来了:",
			exchangeReceived: "你收到了:",
			exchangeRound: "第 {{n}}/{{total}} 次交换",
			turnYou: "轮到你出牌",
			turnWait: "等 {{name}} 出牌…",
			trickLead: "等 {{name}} 开墩",
			lastTrick: "上一墩 {{name}} 赢:",
			roundChip: "第 {{n}} 轮",
			pendingCaptain: "船长能力:改为直行?",
			pendingCaptainUse: "直行",
			pendingCaptainSkip: "斜进",
			pendingHelm: "红发能力:改朝队友方向?",
			pendingHelmUse: "朝队友",
			pendingHelmSkip: "朝自己",
			pendingGunner: "双枪能力:选一张生效",
			pendingWait: "等 {{name}} 决定…",
			won: "抵达终点!",
			lost: "本局失败",
			retry: "重开本场景",
			cancel: "取消",
			playCard: "出牌",
			giveCard: "递出",
			myHand: "我的手牌",
			currentTrick: "当前墩",
			previewWaiting: "首张牌已选，落点待队友出牌",
			previewPending: "海盗能力待决，方向待定",
			previewFlip: "翻牌后才能确定行动",
			previewBury: "舵触牌沉入海怪牌堆",
			previewBlocked: "航路受阻，船留在原地",
			previewNone: "这组牌不触发航行动作",
			previewMove: "预计驶向 {{cell}}",
			previewRisk: "可能驶向 {{cell}}，有海怪风险",
			previewDamage: "伤害 ×{{n}}",
			tricksAria: "已赢 {{n}} 墩",
			handAria: "手牌 {{n}} 张",
			krakenTrackAria: "克拉肯轨道第 {{n}} 格",
			krakenDamage: "回合末伤害",
			krakenDeck: "海怪牌堆",
			krakenDeckAria: "克拉肯牌堆 {{n}} 张",
			loseReason: {
				storm: "船没能越过风暴线",
				round5: "第 5 轮结束,船未抵达终点",
				krakenCard: "克拉肯卡成了牌堆唯一一张",
				krakenDead: "克拉肯标记走到了骷髅格",
				deadzone: "终点再也无法到达"
			},
			pirate: {
				p1: {
					name: "红帽船长",
					ability: "你赢墩时用两张同数字的舵推进,可改为直行"
				},
				p2: {
					name: "红发枪手",
					ability: "你赢墩时用灰舵(6/7/8)推进,可改朝队友方向"
				},
				p3: {
					name: "戴帽水手",
					ability: "你赢下第 4 墩时,加打 1 墩再结束本轮"
				},
				p4: {
					name: "蓝衣水手",
					ability: "交换时可先看对方递来的牌,再选自己递哪张"
				},
				p5: {
					name: "羽饰船长",
					ability: "交换阶段进行 2 次(双方都受影响)"
				},
				p6: {
					name: "双枪客",
					ability: "你赢墩时炮+炮翻牌可翻 2 张选 1 张生效"
				}
			},
			guideTitle: "图标组合速查",
			guide: {
				c1: "斜进(朝赢墩方)",
				c2: "斜进 + 克拉肯伤害 ×1",
				c3: "斜进 + 克拉肯伤害 ×2",
				c4: "舵触牌埋到克拉肯堆底",
				c5: "直行 1 格",
				c6: "翻玩家牌堆顶牌,执行其炮击动作"
			},
			guideCaption: "其余组合无动作(墩数照走)。克拉肯轨道:3、3、4、5、☠;每点伤害翻克拉肯堆顶 1 张,翻到克拉肯卡则标记进 1 格。",
			suit: {
				gray: "灰色 {{n}}",
				green: "绿色 {{n}}",
				blue: "蓝色 {{n}}"
			},
			errPhase: "现在不能这么做",
			errTurn: "还没轮到你",
			errCard: "手里没有这张牌",
			errFollow: "必须跟花色",
			errPiratePicked: "你已经选过海盗了",
			errPirateTaken: "这个海盗已被对方选走",
			errGiven: "你已经递过牌了",
			errPeek: "先看再递是蓝衣水手的能力",
			errWaitPartner: "先看再递:等对方先递牌",
			errPending: "先解决当前的能力选择"
		},
		en: {
			name: "Sail",
			desc: "2-player co-op trick-taking: sail past storms and the Kraken to reach the end",
			rules: "Goal: cooperate to sail the ship onto an end space within 5 rounds; triggering any defeat condition ends the game.\nCards:\n· The player deck has 21 cards: three suits (gray/green/blue), 3–9 each; a separate Kraken deck holds the 1s and 2s of all suits.\n· Card icons drive the actions: 1–3 wheel+tentacle, 4–5 cannon, 6–8 wheel, 9 tentacle.\nEach round:\n· Reshuffle and deal 9 cards each, pass 1 card face down (before seeing what you receive), then play tricks.\n· You must follow suit; the highest card of the led suit wins and leads next.\n· The round ends when either player wins their 4th trick: the Kraken deals damage equal to its current track number, then reshuffle for the next round.\nActions:\n· Resolve the icon pair of the two cards in a trick (see the cheat sheet below).\nBoard:\n· Diagonal = forward toward the trick winner; straight = straight ahead. Islands block movement; moving off-board does nothing.\n· Entering a Kraken space deals 1 damage.\n· At the end of rounds 2 and 4 the ship must be fully past the storm line.\nWin/Lose:\n· Sailing onto an end space wins immediately.\n· Immediate defeat: the Kraken card becomes the only card in its deck; the Kraken marker reaches the skull; no end space can ever be reached.",
			optScenario: "Scenario",
			optPirates: "Pirate cards",
			piratesOn: "On",
			piratesOff: "Off",
			scenario: {
				learning: "Learning",
				s1: "Scenario 1",
				s2: "Scenario 2"
			},
			pickPirateYou: "Pick your pirate",
			pickPirateWait: "Waiting for partner to pick…",
			exchangeGive: "Pick a card to pass",
			exchangeWait: "Waiting for partner to pass…",
			exchangePeek: "Peek first: pick a card to pass back",
			exchangePeekCard: "Partner passed you:",
			exchangeReceived: "You received:",
			exchangeRound: "Exchange {{n}}/{{total}}",
			turnYou: "Your turn to play",
			turnWait: "Waiting for {{name}} to play…",
			trickLead: "Waiting for {{name}} to lead",
			lastTrick: "Last trick won by {{name}}:",
			roundChip: "Round {{n}}",
			pendingCaptain: "Captain ability: go straight instead?",
			pendingCaptainUse: "Straight",
			pendingCaptainSkip: "Diagonal",
			pendingHelm: "Gunner ability: move toward partner?",
			pendingHelmUse: "To partner",
			pendingHelmSkip: "To me",
			pendingGunner: "Two-Gun ability: pick one to apply",
			pendingWait: "Waiting for {{name}} to decide…",
			won: "Reached the end!",
			lost: "Voyage failed",
			retry: "Retry this scenario",
			cancel: "Cancel",
			playCard: "Play",
			giveCard: "Pass",
			myHand: "My hand",
			currentTrick: "Current trick",
			previewWaiting: "First card selected; waiting for the other card",
			previewPending: "Pirate ability pending; direction undecided",
			previewFlip: "Action depends on the flipped card",
			previewBury: "Wheel tentacle card goes beneath the Kraken deck",
			previewBlocked: "Route blocked; ship stays put",
			previewNone: "This pair has no sailing action",
			previewMove: "Sail to {{cell}}",
			previewRisk: "May sail to {{cell}}; Kraken risk",
			previewDamage: "damage ×{{n}}",
			tricksAria: "{{n}} tricks won",
			handAria: "{{n}} cards in hand",
			krakenTrackAria: "Kraken track space {{n}}",
			krakenDamage: "dmg per round",
			krakenDeck: "kraken deck",
			krakenDeckAria: "Kraken deck {{n}} cards",
			loseReason: {
				storm: "The ship failed to clear the storm line",
				round5: "Round 5 ended before reaching the end",
				krakenCard: "The Kraken card became the only card in its deck",
				krakenDead: "The Kraken marker reached the skull space",
				deadzone: "No end space can be reached anymore"
			},
			pirate: {
				p1: {
					name: "Red Captain",
					ability: "When you win advancing with two wheels of the same number, you may go straight"
				},
				p2: {
					name: "Red Gunner",
					ability: "When you win advancing with an orange wheel (gray 6/7/8), you may move toward your partner"
				},
				p3: {
					name: "Hatted Sailor",
					ability: "When you win your 4th trick, play one more trick before the round ends"
				},
				p4: {
					name: "Blue Sailor",
					ability: "During the exchange, see the incoming card before choosing yours"
				},
				p5: {
					name: "Feather Captain",
					ability: "The exchange happens twice (affects both players)"
				},
				p6: {
					name: "Two-Gun",
					ability: "When you win with cannon+cannon, flip 2 cards and pick 1 to apply"
				}
			},
			guideTitle: "Icon combo cheat sheet",
			guide: {
				c1: "Diagonal (toward the winner)",
				c2: "Diagonal + 1 Kraken damage",
				c3: "Diagonal + 2 Kraken damage",
				c4: "Bury the wheel-tentacle card under the Kraken deck",
				c5: "Straight 1 space",
				c6: "Flip the player deck top card and do its cannon action"
			},
			guideCaption: "Any other combo does nothing (trick cubes still advance). Kraken track: 3, 3, 4, 5, ☠; each point of damage flips the Kraken deck top, and flipping the Kraken card advances the meeple.",
			suit: {
				gray: "Gray {{n}}",
				green: "Green {{n}}",
				blue: "Blue {{n}}"
			},
			errPhase: "Not allowed right now",
			errTurn: "Not your turn",
			errCard: "You do not have that card",
			errFollow: "You must follow suit",
			errPiratePicked: "You already picked a pirate",
			errPirateTaken: "That pirate is taken by your partner",
			errGiven: "You already passed a card",
			errPeek: "Peek-before-pass is the Blue Sailor ability",
			errWaitPartner: "Peek first: wait for your partner to pass",
			errPending: "Resolve the pending ability first"
		}
	}
};
//#endregion
export { Et as default };
