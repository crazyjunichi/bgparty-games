import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useLayoutEffect as i, useRef as a, useState as o } from "react";
import { botAvatarOf as s } from "@bgparty/sdk/lobby";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as l } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as u, useT as d } from "@bgparty/sdk/i18n";
import { IconBot as f, IconCheck as p, IconDisconnected as m } from "@bgparty/sdk/icons";
import { playTurn as h, useSoundEdge as ee } from "@bgparty/sdk/sfx";
import { GameScreen as te } from "@bgparty/sdk/ui/game-screen";
import { SeatBadgedAvatar as ne, seatName as re } from "@bgparty/sdk/ui/player-strip";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { botPersonality as y } from "@bgparty/sdk/bot-personality";
import { Floater as b, FlySprite as x, PulseBox as ie } from "@bgparty/sdk/fx/primitives";
import { AVATARS as S } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as C } from "@bgparty/sdk/player-colors";
import { Confetti as ae } from "@bgparty/sdk/ui/confetti";
//#region src/games/scout/meta.ts
var w = {
	id: "scout",
	tier: "released",
	mechanics: ["hand-management"],
	interactionTags: [],
	nameKey: "games.scout.name",
	descKey: "games.scout.desc",
	rulesKey: "games.scout.rules",
	icon: "🔍",
	iconImg: "games/scout.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/scout/en.pdf" },
	minPlayers: 3,
	maxPlayers: 5,
	bestPlayers: [4],
	accent: "#4d168f",
	releasedAt: "2026-09-11",
	search: {
		py: "ma xi xing tan",
		init: "mxxt"
	},
	hotseat: "cover"
}, T = t.object({
	id: t.int().min(0).max(44),
	up: t.union([t.literal(0), t.literal(1)])
}), E = t.discriminatedUnion("type", [
	t.object({ type: t.literal("flip") }),
	t.object({ type: t.literal("confirm") }),
	t.object({
		type: t.literal("show"),
		from: t.int().min(0),
		to: t.int().min(0)
	}),
	t.object({
		type: t.literal("scout"),
		side: t.enum(["left", "right"]),
		insertAt: t.int().min(0),
		flip: t.boolean()
	}),
	t.object({
		type: t.literal("scoutShow"),
		side: t.enum(["left", "right"]),
		insertAt: t.int().min(0),
		flip: t.boolean()
	}),
	t.object({ type: t.literal("next") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), D = t.string(), O = t.object({
	round: t.int().min(1),
	rounds: t.int().min(1),
	phase: t.enum([
		"flip",
		"play",
		"settle",
		"roundOver",
		"done"
	]),
	turn: D,
	table: t.object({
		owner: D,
		kind: t.enum(["set", "run"]),
		top: t.int(),
		cards: t.array(T)
	}).nullable(),
	roundDeltas: t.record(t.string(), t.int()).nullable(),
	endReason: t.object({
		kind: t.enum([
			"empty",
			"allScout",
			"stall"
		]),
		rid: D.nullable()
	}).nullable(),
	consecutiveScouts: t.int().nonnegative(),
	pendingShow: D.nullable(),
	players: t.array(t.object({
		rid: D,
		handCount: t.int().nonnegative(),
		captured: t.int().nonnegative(),
		tokens: t.int().nonnegative(),
		score: t.int(),
		scoutShowUsed: t.boolean(),
		decided: t.boolean()
	}))
}), oe = t.object({
	hand: t.array(T),
	needsDecision: t.boolean(),
	hasChip: t.boolean()
}), k = (() => {
	let e = [];
	for (let t = 1; t <= 10; t += 1) for (let n = t + 1; n <= 10; n += 1) e.push([t, n]);
	return e;
})(), A = (e) => k[e.id][e.up], j = (e) => k[e.id][e.up ^ 1];
function M(e) {
	if (e.length === 0) return null;
	let t = e.map(A);
	if (t.every((e) => e === t[0])) return {
		kind: "set",
		top: t[0],
		count: t.length
	};
	let n = !0, r = !0;
	for (let e = 1; e < t.length; e += 1) t[e] !== t[e - 1] + 1 && (n = !1), t[e] !== t[e - 1] - 1 && (r = !1);
	return t.length > 1 && (n || r) ? {
		kind: "run",
		top: Math.max(...t),
		count: t.length
	} : null;
}
function N(e, t) {
	return e.count === t.count ? e.kind === t.kind ? e.top > t.top : e.kind === "set" : e.count > t.count;
}
function P(e) {
	let t = [];
	for (let n = 0; n < e.length; n += 1) for (let r = n; r < e.length; r += 1) {
		let i = M(e.slice(n, r + 1));
		i && t.push({
			from: n,
			to: r,
			combo: i
		});
	}
	return t;
}
function F(e, t) {
	return P(e).some((e) => t === null || N(e.combo, t));
}
var I = (e) => e.players.length * 4, L = {
	fly: 380,
	stagger: 60,
	tail: 40
}, R = {
	gatherFly: 260,
	gatherStagger: 35,
	starFly: 220,
	scorePop: 260,
	tail: 40
};
function z(e) {
	return R.gatherFly + (e - 1) * R.gatherStagger + R.starFly + R.scorePop + R.tail;
}
function se(e) {
	return L.fly + (e - 1) * L.stagger + L.tail;
}
var ce = (e) => ({
	kind: e.kind,
	top: e.top,
	count: e.cards.length
});
function B(e) {
	return k.map((e, t) => t).filter((t) => {
		let [n, r] = k[t];
		return e === 3 ? r !== 10 : e !== 4 || n !== 9 || r !== 10;
	});
}
function V(t) {
	let n = B(t.players.length);
	for (let r = n.length - 1; r > 0; --r) {
		let i = e(t.seed, t.rngCursor, r + 1);
		t.rngCursor += 1, [n[r], n[i]] = [n[i], n[r]];
	}
	let r = Math.floor(n.length / t.players.length), i = [];
	return t.players.forEach((a, o) => {
		let s = [];
		for (let i = 0; i < r; i += 1) s.push({
			id: n[o * r + i],
			up: e(t.seed, t.rngCursor, 2)
		}), t.rngCursor += 1;
		t.hands[a] = s, t.captured[a] = 0, t.tokens[a] = 0, t.scoutShowUsed[a] = !1, t.decided[a] = !1, i.push({
			kind: "deal",
			rid: a,
			data: { count: r },
			for: [a],
			secret: { cards: s },
			...o > 0 ? { with: !0 } : {}
		});
	}), t.table = null, t.consecutiveScouts = 0, t.sinceCapture = 0, t.pendingShow = null, t.roundDeltas = null, t.endReason = null, t.beatMs = 0, t.settleStep = null, t.pendingPlacement = null, t.turnIdx = t.players.findIndex((e) => t.hands[e].some((e) => e.id === 0)), t.phase = "flip", i;
}
function H(e, t, n) {
	e.phase = "settle", e.endReason = t, e.beatMs = n;
}
function U(e, t, n) {
	let r = {};
	for (let n of e.players) {
		let i = e.captured[n] + e.tokens[n] - (n === t ? 0 : e.hands[n].length);
		r[n] = i, e.scores[n] += i, e.decided[n] = !1;
	}
	return e.roundDeltas = r, e.endReason = n, e.phase = "roundOver", [{
		kind: "roundEnd",
		data: {
			round: e.round,
			deltas: r
		}
	}];
}
function W(e, t, n) {
	let r = {};
	for (let e of t) r[e] = 0;
	let i = {
		seed: n,
		rngCursor: 0,
		players: t,
		rounds: t.length,
		round: 1,
		turnIdx: 0,
		phase: "flip",
		hands: {},
		captured: {},
		tokens: {},
		scores: r,
		scoutShowUsed: {},
		decided: {},
		roundDeltas: null,
		endReason: null,
		beatMs: 0,
		settleStep: null,
		table: null,
		pendingPlacement: null,
		consecutiveScouts: 0,
		sinceCapture: 0,
		pendingShow: null
	};
	return {
		state: i,
		fx: V(i)
	};
}
function le(e, t, n) {
	if (e.phase === "done") return { code: "games.scout.errNotYourTurn" };
	if (t.type === "tick") {
		if (e.phase !== "settle") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		if (t.settleStep === "collect") {
			let e = t.pendingPlacement;
			return t.captured[e.table.owner] += e.takenCount, t.table = e.table, t.pendingPlacement = null, t.settleStep = "place", t.beatMs = se(e.table.cards.length), {
				state: t,
				fx: [{
					kind: "show",
					rid: e.table.owner,
					data: { cards: e.table.cards }
				}]
			};
		}
		if (t.settleStep === "place" || t.settleStep === "scout") {
			let e = t.settleStep === "scout";
			if (t.settleStep = null, t.beatMs = 0, !t.endReason) return t.phase = "play", (!e || t.pendingShow === null) && (t.turnIdx = (t.turnIdx + 1) % t.players.length), {
				state: t,
				fx: []
			};
		}
		let n = t.endReason;
		return n ? {
			state: t,
			fx: U(t, n.kind === "allScout" ? n.rid : null, n)
		} : {
			state: t,
			fx: []
		};
	}
	if (t.type === "flip" || t.type === "confirm") {
		if (e.phase !== "flip" || e.decided[n.by] || !e.hands[n.by]) return { code: "games.scout.errNoFlip" };
		let r = structuredClone(e);
		return t.type === "flip" ? (r.hands[n.by] = r.hands[n.by].map((e) => ({
			id: e.id,
			up: e.up ^ 1
		})), {
			state: r,
			fx: [{
				kind: "flipHand",
				rid: n.by
			}]
		}) : (r.decided[n.by] = !0, r.players.every((e) => r.decided[e]) && (r.phase = "play"), {
			state: r,
			fx: []
		});
	}
	if (t.type === "next") {
		if (e.phase !== "roundOver" || e.decided[n.by]) return { code: "games.scout.errNotYourTurn" };
		let t = structuredClone(e);
		return t.decided[n.by] = !0, t.players.every((e) => t.decided[e]) ? t.round >= t.rounds ? (t.phase = "done", {
			state: t,
			fx: []
		}) : (t.round += 1, {
			state: t,
			fx: V(t)
		}) : {
			state: t,
			fx: []
		};
	}
	if (e.phase !== "play") return { code: "games.scout.errNotYourTurn" };
	if (t.type === "show") {
		if (e.pendingShow === null ? n.by !== e.players[e.turnIdx] : e.pendingShow !== n.by) return { code: "games.scout.errNotYourTurn" };
		let r = e.hands[n.by], { from: i, to: a } = t;
		if (i < 0 || a < i || a >= r.length) return { code: "games.scout.errBadShow" };
		let o = r.slice(i, a + 1), s = M(o);
		if (!s) return { code: "games.scout.errBadShow" };
		if (e.table && !N(s, ce(e.table))) return { code: "games.scout.errTooWeak" };
		let c = structuredClone(e), l = c.table ? c.table.cards : [];
		c.sinceCapture = l.length > 0 ? 0 : c.sinceCapture + 1, c.hands[n.by] = [...r.slice(0, i), ...r.slice(a + 1)];
		let u = {
			owner: n.by,
			kind: s.kind,
			top: s.top,
			cards: o
		};
		return c.consecutiveScouts = 0, c.pendingShow = null, c.endReason = c.hands[n.by].length === 0 ? {
			kind: "empty",
			rid: n.by
		} : c.sinceCapture >= I(c) ? {
			kind: "stall",
			rid: null
		} : null, c.phase = "settle", l.length > 0 ? (c.pendingPlacement = {
			table: u,
			takenCount: l.length
		}, c.settleStep = "collect", c.beatMs = z(l.length), {
			state: c,
			fx: [{
				kind: "collect",
				rid: n.by,
				data: { taken: l }
			}]
		}) : (c.table = u, c.settleStep = "place", c.beatMs = se(o.length), {
			state: c,
			fx: [{
				kind: "show",
				rid: n.by,
				data: { cards: o }
			}]
		});
	}
	if (e.pendingShow !== null || n.by !== e.players[e.turnIdx]) return { code: "games.scout.errNotYourTurn" };
	let r = e.table;
	if (!r) return { code: "games.scout.errNoTable" };
	let i = t.type === "scoutShow";
	if (i && e.scoutShowUsed[n.by]) return { code: "games.scout.errChipUsed" };
	let a = e.hands[n.by];
	if (t.insertAt > a.length) return { code: "games.scout.errBadInsert" };
	let o = t.side === "left" ? 0 : r.cards.length - 1, s = r.cards[o], c = {
		id: s.id,
		up: t.flip ? s.up ^ 1 : s.up
	}, l = r.cards.filter((e, t) => t !== o), u = M(l), d = u ? {
		owner: r.owner,
		kind: u.kind,
		top: u.top,
		cards: l
	} : null, f = [
		...a.slice(0, t.insertAt),
		c,
		...a.slice(t.insertAt)
	];
	if (i && !F(f, d ? {
		kind: d.kind,
		top: d.top,
		count: d.cards.length
	} : null)) return { code: "games.scout.errNoFollow" };
	let p = structuredClone(e);
	p.hands[n.by] = f, p.table = d, p.phase = "settle", p.settleStep = "scout", p.beatMs = 600, r.owner !== n.by && (p.tokens[r.owner] += 1);
	let m = [{
		kind: "scout",
		rid: n.by,
		data: {
			card: c,
			fromCard: s,
			side: t.side,
			owner: r.owner,
			tableLenBefore: r.cards.length
		}
	}];
	return i ? (p.scoutShowUsed[n.by] = !0, p.pendingShow = n.by, p.sinceCapture += 1, p.sinceCapture >= I(p) && H(p, {
		kind: "stall",
		rid: null
	}, 600), {
		state: p,
		fx: m
	}) : (p.consecutiveScouts += 1, p.sinceCapture += 1, d || (p.consecutiveScouts = 0), d && p.consecutiveScouts >= p.players.length - 1 ? (H(p, {
		kind: "allScout",
		rid: r.owner
	}, 600), {
		state: p,
		fx: m
	}) : (p.sinceCapture >= I(p) && H(p, {
		kind: "stall",
		rid: null
	}, 600), {
		state: p,
		fx: m
	}));
}
function ue(e, t) {
	return {
		public: {
			round: e.round,
			rounds: e.rounds,
			phase: e.phase,
			turn: e.players[e.turnIdx],
			table: e.table,
			consecutiveScouts: e.consecutiveScouts,
			roundDeltas: e.roundDeltas,
			endReason: e.endReason,
			pendingShow: e.pendingShow,
			players: e.players.map((t) => ({
				rid: t,
				handCount: (e.hands[t]?.length ?? 0) - +(e.phase === "settle" && e.settleStep === "scout" && t === e.players[e.turnIdx]),
				captured: e.captured[t] ?? 0,
				tokens: e.tokens[t] ?? 0,
				score: e.scores[t] ?? 0,
				scoutShowUsed: e.scoutShowUsed[t] ?? !1,
				decided: e.decided[t] ?? !1
			}))
		},
		private: {
			hand: e.hands[t] ?? [],
			needsDecision: e.phase === "flip" && !e.decided[t],
			hasChip: !e.scoutShowUsed[t]
		}
	};
}
function de(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]), n = e.scores[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.scores[t] === n),
		ranking: t,
		scores: { ...e.scores }
	};
}
function fe(e) {
	return e.phase === "settle" ? e.beatMs : null;
}
var G = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: w,
	schemas: {
		action: E,
		publicView: O,
		privateView: oe
	},
	setup: W,
	reduce: le,
	viewFor: ue,
	status: de,
	nextTickIn: fe
}, pe = {
	1: "#e54649",
	2: "#e98c19",
	3: "#d7a416",
	4: "#70a22d",
	5: "#159680",
	6: "#1685ad",
	7: "#376ad3",
	8: "#6942bf",
	9: "#9b37aa",
	10: "#ce357a"
};
function K({ card: e, size: t, selected: n, elevated: r, dimensions: i }) {
	let a = d(), o = A(e), s = j(e);
	return /* @__PURE__ */ v("span", {
		"aria-label": a("games.scout.cardAria", {
			a: o,
			b: s
		}),
		className: `scout-card scout-card-${t} ${n ? "is-selected" : ""} ${r ? "is-elevated" : ""}`,
		style: {
			"--scout-card-color": pe[o],
			"--scout-card-down-color": pe[s],
			...i ? {
				[`--scout-${t}-w`]: `${i.w}px`,
				[`--scout-${t}-h`]: `${i.h}px`
			} : {}
		},
		children: [
			/* @__PURE__ */ _("span", {
				className: "scout-card-top",
				"aria-hidden": !0
			}),
			/* @__PURE__ */ _("span", {
				className: "scout-card-fold",
				"aria-hidden": !0
			}),
			/* @__PURE__ */ _("span", {
				className: "scout-card-watermark",
				"aria-hidden": !0,
				children: "★"
			}),
			/* @__PURE__ */ _("span", {
				className: `scout-card-up ${o === 6 || o === 9 ? "is-underlined" : ""}`,
				children: o
			}),
			/* @__PURE__ */ _("span", {
				className: "scout-card-rule",
				"aria-hidden": !0
			}),
			/* @__PURE__ */ _("span", {
				className: `scout-card-down ${s === 6 || s === 9 ? "is-underlined" : ""}`,
				"aria-hidden": !0,
				children: s
			}),
			/* @__PURE__ */ _("span", {
				className: "scout-card-dot",
				"aria-hidden": !0
			}),
			n && /* @__PURE__ */ _("span", {
				className: "scout-card-select",
				"aria-hidden": !0,
				children: "★"
			})
		]
	});
}
function me({ dimensions: e } = {}) {
	return /* @__PURE__ */ _("span", {
		className: "scout-card-back",
		style: e ? {
			"--scout-table-w": `${e.w}px`,
			"--scout-table-h": `${e.h}px`
		} : void 0,
		"aria-hidden": !0,
		children: /* @__PURE__ */ _("span", { children: "★" })
	});
}
//#endregion
//#region src/games/scout/view-player.tsx
function he(e) {
	return /* @__PURE__ */ _(ge, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ge({ pub: e, priv: t, members: s, myRid: l, send: f }) {
	let m = d(), ne = u((e) => e.locale), y = (e) => {
		let t = s.find((t) => t.rid === e);
		return t ? re(t, ne) : e;
	}, { ref: b } = c("table"), { ref: x } = c("trow"), { ref: ie } = c("table-card"), S = a(null), [C, ae] = o(null), [w, T] = o(null), [E, D] = o(null);
	i(() => {
		if (C !== null) return;
		let e = S.current?.clientWidth;
		if (!e) return;
		let t = Math.ceil((468 - e) / 9);
		ae(Math.min(12, Math.max(10, t)));
	}, [C, t]);
	let O = t?.hand ?? [], oe = e.players.find((e) => e.rid === l)?.handCount ?? O.length, k = e.players.find((e) => e.rid === l)?.decided ?? !1, P = t?.needsDecision ?? !1, F = e.phase === "roundOver" && !k, I = e.pendingShow === l, L = e.phase === "play" && e.turn === l && (e.pendingShow === null || I), R = L && !I && e.table !== null;
	ee(P || F || L, h);
	let z = `${e.phase}|${e.turn}|${e.pendingShow}|${e.table?.owner}|${e.table?.cards.length ?? 0}|${O.length}`, [se, ce] = o(z);
	se !== z && (ce(z), T(null), D(null));
	let B = w ? M(O.slice(w.from, w.to + 1)) : null, V = e.table ? {
		kind: e.table.kind,
		top: e.table.top,
		count: e.table.cards.length
	} : null, H = L && w !== null && B !== null && (V === null || N(B, V)), U = (() => {
		if (!E || !e.table) return null;
		let t = e.table.cards[E.side === "left" ? 0 : e.table.cards.length - 1];
		return {
			id: t.id,
			up: E.flip ? t.up ^ 1 : t.up
		};
	})(), W = E?.insertAt;
	r(() => {
		if (W == null || !S.current) return;
		let e = S.current, t = e.querySelector(`[data-scout-gap="${W}"]`);
		if (!t) return;
		let n = t.offsetLeft - e.offsetLeft - (e.clientWidth - t.clientWidth) / 2;
		e.scrollTo({
			left: Math.max(0, n),
			behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth"
		});
	}, [W]);
	let le = (e) => {
		if (L && !E) {
			if (!w) {
				T({
					from: e,
					to: e
				});
				return;
			}
			if (e >= w.from && e <= w.to) {
				T(null);
				return;
			}
			if (e === w.from - 1) {
				T({
					from: e,
					to: w.to
				});
				return;
			}
			if (e === w.to + 1) {
				T({
					from: w.from,
					to: e
				});
				return;
			}
			T(e < w.from ? {
				from: e,
				to: w.to
			} : {
				from: w.from,
				to: e
			});
		}
	}, ue = e.phase === "flip" ? m(P ? "games.scout.flipPrompt" : "games.scout.flipWaiting") : e.phase === "settle" ? m(e.endReason ? "games.scout.settling" : "games.scout.transitioning") : e.phase === "roundOver" ? m(F ? "games.scout.roundOver" : "games.scout.roundWaiting") : I ? m("games.scout.mustShow") : L ? m(e.table ? "games.scout.turnYou" : "games.scout.turnOpen") : m("games.scout.turnWait", { name: y(e.turn) }), de = w ? B === null ? m("games.scout.badCombo") : !H && V ? m("games.scout.cantBeat") : B.kind === "set" ? m("games.scout.comboSetDesc", {
		v: B.top,
		n: B.count
	}) : m("games.scout.comboRunDesc", {
		a: Math.min(...O.slice(w.from, w.to + 1).map(A)),
		b: B.top
	}) : null, fe = s.length >= 4, G = e.table;
	return /* @__PURE__ */ _("div", {
		className: "scout-screen",
		children: /* @__PURE__ */ _(te, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ v("div", {
				className: "scout-head",
				children: [/* @__PURE__ */ v("div", {
					className: "scout-banner",
					role: "status",
					children: [
						/* @__PURE__ */ _("span", {
							className: "scout-banner-star",
							"aria-hidden": !0,
							children: "★"
						}),
						/* @__PURE__ */ _("span", {
							className: "scout-round",
							children: m("games.scout.roundStage", {
								n: e.round,
								total: e.rounds
							})
						}),
						/* @__PURE__ */ _("span", {
							className: "scout-banner-divider",
							"aria-hidden": !0
						}),
						/* @__PURE__ */ _("span", {
							className: "scout-banner-text",
							children: ue
						})
					]
				}), /* @__PURE__ */ _("div", {
					className: "scout-seats",
					style: { gridTemplateColumns: `repeat(${s.length}, minmax(0, 1fr))` },
					children: s.map((t) => {
						let n = e.players.find((e) => e.rid === t.rid);
						if (!n) return null;
						let r = e.phase === "play" && e.turn === t.rid;
						return /* @__PURE__ */ _(_e, {
							m: t,
							name: re(t, ne),
							myRid: l,
							score: n.score,
							earned: e.phase === "play" || e.phase === "settle" ? n.captured + n.tokens : 0,
							handCount: n.handCount,
							isTurn: r,
							compact: fe,
							action: e.phase === "flip" || e.phase === "roundOver" ? n.decided ? "done" : "pending" : r ? "pending" : null
						}, t.rid);
					})
				})]
			}),
			actionsHeight: "scout-actions-height",
			actions: /* @__PURE__ */ v("div", {
				className: "scout-bottom",
				children: [/* @__PURE__ */ _("div", {
					className: "scout-control",
					children: P ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("button", {
						type: "button",
						className: "scout-button scout-button-quiet",
						onClick: () => f({ type: "flip" }),
						children: m("games.scout.flipDo")
					}), /* @__PURE__ */ _("button", {
						type: "button",
						className: "scout-button scout-button-main",
						onClick: () => f({ type: "confirm" }),
						children: m("games.scout.flipConfirm")
					})] }) : F ? /* @__PURE__ */ _("button", {
						type: "button",
						className: "scout-button scout-button-main",
						onClick: () => f({ type: "next" }),
						children: m(e.round >= e.rounds ? "games.scout.showFinal" : "games.scout.nextRound")
					}) : E ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("button", {
						type: "button",
						className: "scout-button scout-button-quiet",
						onClick: () => D(null),
						children: m("games.scout.cancel")
					}), /* @__PURE__ */ _("button", {
						type: "button",
						className: "scout-button scout-button-main",
						disabled: E.insertAt === null,
						onClick: () => {
							E.insertAt !== null && (f({
								type: E.useChip ? "scoutShow" : "scout",
								side: E.side,
								insertAt: E.insertAt,
								flip: E.flip
							}), D(null));
						},
						children: m(E.useChip ? "games.scout.confirmScoutShow" : "games.scout.confirmScout")
					})] }) : w ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("button", {
						type: "button",
						className: "scout-button scout-button-quiet",
						onClick: () => T(null),
						children: m("games.scout.cancel")
					}), /* @__PURE__ */ _("button", {
						type: "button",
						className: "scout-button scout-button-main",
						disabled: !H,
						onClick: () => {
							f({
								type: "show",
								from: w.from,
								to: w.to
							}), T(null);
						},
						children: m("games.scout.play")
					})] }) : /* @__PURE__ */ _("span", {
						className: "scout-control-idle",
						children: m(L ? "games.scout.pickHand" : "games.scout.handLabel")
					})
				}), t && /* @__PURE__ */ v(g, { children: [
					/* @__PURE__ */ v("div", {
						className: "scout-hand-caption",
						children: [/* @__PURE__ */ _("span", { children: E && E.insertAt !== null ? m("games.scout.insertAtAria", { n: E.insertAt + 1 }) : E ? m("games.scout.insertPick") : m("games.scout.stripHand", { n: oe }) }), /* @__PURE__ */ v("span", {
							className: `scout-chip ${t.hasChip ? "" : "is-used"}`,
							children: ["★ ", m(t.hasChip ? "games.scout.chipReady" : "games.scout.chipUsed")]
						})]
					}),
					/* @__PURE__ */ _("div", {
						className: "scout-hand-hint",
						children: E ? m("games.scout.insertHint") : de ?? "\xA0"
					}),
					/* @__PURE__ */ _("div", {
						ref: S,
						className: `scout-hand-rail ${E ? "is-insert" : ""}`,
						children: /* @__PURE__ */ v("div", {
							className: "scout-hand-cards",
							children: [E && /* @__PURE__ */ _(be, {
								index: 0,
								active: E.insertAt === 0,
								ghost: E.insertAt === 0 ? U : null,
								onPick: () => D({
									...E,
									insertAt: E.insertAt === 0 ? null : 0
								})
							}), O.map((e, t) => {
								let r = w !== null && !E && t >= w.from && t <= w.to, i = !E && t > 0;
								return /* @__PURE__ */ v(n, { children: [/* @__PURE__ */ _("button", {
									type: "button",
									disabled: !L || !!E,
									"aria-label": m("games.scout.cardAria", {
										a: A(e),
										b: j(e)
									}),
									onClick: () => le(t),
									className: `scout-hand-button ${i ? "is-overlapped" : ""}`,
									style: {
										"--scout-phone-overlap": `${C ?? 12}px`,
										zIndex: E ? void 0 : t
									},
									children: /* @__PURE__ */ _(ye, {
										card: e,
										selected: r
									})
								}), E && /* @__PURE__ */ _(be, {
									index: t + 1,
									active: E.insertAt === t + 1,
									ghost: E.insertAt === t + 1 ? U : null,
									onPick: () => D({
										...E,
										insertAt: E.insertAt === t + 1 ? null : t + 1
									})
								})] }, e.id);
							})]
						})
					})
				] })]
			}),
			children: /* @__PURE__ */ v("div", {
				ref: b,
				className: "scout-stage",
				children: [
					/* @__PURE__ */ _("div", {
						className: "scout-tent",
						"aria-hidden": !0,
						children: /* @__PURE__ */ v("div", {
							className: "scout-marquee",
							children: [
								"★ ",
								m("games.scout.name"),
								" ★"
							]
						})
					}),
					/* @__PURE__ */ _("div", {
						className: "scout-bulbs",
						"aria-hidden": !0
					}),
					/* @__PURE__ */ _("div", {
						className: "scout-curtain scout-curtain-left",
						"aria-hidden": !0
					}),
					/* @__PURE__ */ _("div", {
						className: "scout-curtain scout-curtain-right",
						"aria-hidden": !0
					}),
					/* @__PURE__ */ _("div", {
						className: "scout-spot",
						"aria-hidden": !0
					}),
					/* @__PURE__ */ _("div", {
						className: "scout-stage-star",
						"aria-hidden": !0,
						children: "★"
					}),
					/* @__PURE__ */ _("div", {
						className: "scout-apron",
						"aria-hidden": !0
					}),
					/* @__PURE__ */ v("div", {
						className: "scout-stage-content",
						children: [/* @__PURE__ */ _("span", {
							ref: ie,
							className: "scout-table-origin",
							"aria-hidden": !0
						}), e.phase === "roundOver" && e.roundDeltas ? /* @__PURE__ */ v("div", {
							className: "scout-scoreboard",
							children: [/* @__PURE__ */ _("strong", { children: e.endReason?.kind === "empty" ? m("games.scout.endReasonEmpty", { name: y(e.endReason.rid ?? "") }) : e.endReason?.kind === "allScout" ? m("games.scout.endReasonAllScout", { name: y(e.endReason.rid ?? "") }) : m("games.scout.endReasonStall") }), /* @__PURE__ */ _("ul", { children: e.players.map((t) => /* @__PURE__ */ v("li", { children: [
								/* @__PURE__ */ _("span", { children: y(t.rid) }),
								/* @__PURE__ */ v("b", {
									className: (e.roundDeltas?.[t.rid] ?? 0) < 0 ? "is-negative" : "",
									children: [(e.roundDeltas?.[t.rid] ?? 0) > 0 ? "+" : "", e.roundDeltas?.[t.rid] ?? 0]
								}),
								/* @__PURE__ */ v("small", { children: ["★ ", t.score] })
							] }, t.rid)) })]
						}) : /* @__PURE__ */ v(g, { children: [G ? /* @__PURE__ */ v(g, { children: [
							/* @__PURE__ */ v("div", {
								className: "scout-owner",
								children: [
									m("games.scout.ownerLabel", { name: y(G.owner) }),
									" · ",
									m(G.kind === "set" ? "games.scout.comboKindSet" : "games.scout.comboKindRun"),
									" ",
									G.cards.length
								]
							}),
							/* @__PURE__ */ _("div", {
								className: "scout-table-scroll",
								children: /* @__PURE__ */ _("div", {
									ref: x,
									className: "scout-table-row",
									children: G.cards.map((e, t) => {
										let n = G.cards.length, r = t === 0 || t === n - 1, i = t === 0 ? "left" : "right";
										return /* @__PURE__ */ _(ve, {
											index: t,
											card: e,
											tappable: R && r,
											side: i,
											active: E !== null && r && E.side === i,
											onScout: () => {
												T(null), D(E ? {
													...E,
													side: i
												} : {
													side: i,
													insertAt: null,
													flip: !1,
													useChip: !1
												});
											}
										}, e.id);
									})
								})
							}),
							R && /* @__PURE__ */ _("div", {
								className: "scout-end-hint",
								children: m("games.scout.endHint")
							})
						] }) : /* @__PURE__ */ _("div", {
							className: "scout-empty",
							children: m("games.scout.tableEmpty", { name: y(e.turn) })
						}), w && !E && /* @__PURE__ */ _("div", {
							className: `scout-combo-readout ${H ? "is-valid" : ""}`,
							children: de
						})] })]
					}),
					E && U && /* @__PURE__ */ v("div", {
						className: "scout-insert-options",
						children: [/* @__PURE__ */ v("div", {
							className: "scout-insert-face",
							children: [/* @__PURE__ */ _("span", { children: m("games.scout.faceDirection") }), /* @__PURE__ */ v("div", {
								className: "scout-segment",
								children: [/* @__PURE__ */ v("button", {
									type: "button",
									className: E.flip ? "" : "is-active",
									"aria-pressed": !E.flip,
									onClick: () => D({
										...E,
										flip: !1
									}),
									children: [
										!E.flip && /* @__PURE__ */ _(p, { size: 12 }),
										" ",
										m("games.scout.keepFace", { n: E.flip ? j(U) : A(U) })
									]
								}), /* @__PURE__ */ v("button", {
									type: "button",
									className: E.flip ? "is-active" : "",
									"aria-pressed": E.flip,
									onClick: () => D({
										...E,
										flip: !0
									}),
									children: [
										E.flip && /* @__PURE__ */ _(p, { size: 12 }),
										" ",
										m("games.scout.flipFace", { n: E.flip ? A(U) : j(U) })
									]
								})]
							})]
						}), t?.hasChip && /* @__PURE__ */ v("div", {
							className: "scout-segment scout-action-choice",
							children: [/* @__PURE__ */ v("button", {
								type: "button",
								className: E.useChip ? "" : "is-active",
								"aria-pressed": !E.useChip,
								onClick: () => D({
									...E,
									useChip: !1
								}),
								children: [
									!E.useChip && /* @__PURE__ */ _(p, { size: 12 }),
									" ",
									m("games.scout.onlyScout")
								]
							}), /* @__PURE__ */ v("button", {
								type: "button",
								className: E.useChip ? "is-active" : "",
								"aria-pressed": E.useChip,
								onClick: () => D({
									...E,
									useChip: !0
								}),
								children: [
									E.useChip && /* @__PURE__ */ _(p, { size: 12 }),
									" ",
									m("games.scout.scoutShow")
								]
							})]
						})]
					})
				]
			})
		})
	});
}
function _e({ m: e, name: t, myRid: n, score: r, earned: i, handCount: a, isTurn: o, compact: u, action: p }) {
	let h = d(), { ref: ee } = c(u ? `seat:${e.rid}` : null), { ref: te } = c(`score:${e.rid}`), re = e.online ? e.rid === n ? /* @__PURE__ */ _("span", { children: h("lobby.you") }) : s(e.rid) === null ? null : /* @__PURE__ */ _(f, {
		size: 12,
		"aria-label": h("lobby.bot")
	}) : /* @__PURE__ */ _(m, {
		size: 12,
		"aria-label": h("lobby.offline")
	});
	return /* @__PURE__ */ v("div", {
		ref: ee,
		className: `scout-seat ${o ? "is-turn" : ""} ${u ? "is-compact" : ""}`,
		children: [
			u ? /* @__PURE__ */ v("div", {
				className: "scout-seat-meta",
				children: [/* @__PURE__ */ v("span", { children: [o && /* @__PURE__ */ _("span", {
					"aria-hidden": !0,
					children: "★ "
				}), re] }), /* @__PURE__ */ _("span", {
					"aria-label": p ? h(p === "done" ? "lobby.done" : "lobby.thinking") : void 0,
					children: p === "done" ? "✓" : p === "pending" ? "…" : ""
				})]
			}) : /* @__PURE__ */ _(ne, {
				m: e,
				myRid: n,
				action: p,
				anchorName: `seat:${e.rid}`,
				box: "size-9",
				img: "size-7"
			}),
			/* @__PURE__ */ v("div", {
				className: "scout-seat-data",
				children: [/* @__PURE__ */ _("span", {
					className: "scout-seat-name",
					title: t,
					children: t
				}), /* @__PURE__ */ v("span", {
					className: "scout-seat-stats",
					children: [/* @__PURE__ */ v("b", { children: [
						/* @__PURE__ */ _("span", {
							ref: te,
							className: "scout-score-anchor",
							children: "★"
						}),
						" ",
						/* @__PURE__ */ _(l, { value: r }),
						i > 0 && /* @__PURE__ */ v("span", {
							className: "scout-seat-earned",
							children: ["+", i]
						})
					] }), /* @__PURE__ */ v("span", { children: ["▣ ", a] })]
				})]
			}),
			o && !u && /* @__PURE__ */ _("span", {
				className: "scout-seat-star",
				"aria-hidden": !0,
				children: "★"
			})
		]
	});
}
function ve({ index: e, card: t, tappable: n, side: r, active: i, onScout: a }) {
	let o = d(), { ref: s, hidden: l } = c(`tcard:${e}`);
	return /* @__PURE__ */ _("span", {
		ref: s,
		className: "scout-table-slot",
		style: { visibility: l ? "hidden" : void 0 },
		children: n ? /* @__PURE__ */ _("button", {
			type: "button",
			"aria-label": o(r === "left" ? "games.scout.scoutLeftAria" : "games.scout.scoutRightAria"),
			"aria-pressed": i,
			onClick: a,
			className: `scout-table-pick ${i ? "is-active" : ""}`,
			children: /* @__PURE__ */ _(K, {
				card: t,
				size: "table"
			})
		}) : /* @__PURE__ */ _(K, {
			card: t,
			size: "table"
		})
	});
}
function ye({ card: e, selected: t }) {
	let { ref: n, hidden: r } = c(`hand:${e.id}`);
	return /* @__PURE__ */ _("span", {
		ref: n,
		className: "scout-hand-anchor",
		style: { visibility: r ? "hidden" : void 0 },
		children: /* @__PURE__ */ _(K, {
			card: e,
			size: "hand",
			selected: t,
			elevated: !0
		})
	});
}
function be({ index: e, active: t, ghost: n, onPick: r }) {
	let i = d();
	return /* @__PURE__ */ _("button", {
		type: "button",
		"data-scout-gap": e,
		"aria-label": i("games.scout.insertAtAria", { n: e + 1 }),
		"aria-pressed": t,
		onClick: r,
		className: `scout-insert-gap ${t ? "is-active" : ""}`,
		children: t && n ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(K, {
			card: n,
			size: "hand"
		}), /* @__PURE__ */ _("span", {
			className: "scout-gap-star",
			"aria-hidden": !0,
			children: "★"
		})] }) : /* @__PURE__ */ _("span", {
			"aria-hidden": !0,
			children: "＋"
		})
	});
}
//#endregion
//#region src/games/scout/bot.ts
function xe() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function q(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var J = (e, t, n) => Math.min(n, Math.max(t, e)), Se = (e) => e.count * e.count * .45 + e.top * .06 + (e.kind === "set" ? .4 : 0), Ce = (e, t) => e.some((e) => e !== t && e.from <= t.from && e.to >= t.to && (e.from < t.from || e.to > t.to));
function we(e, t) {
	let n = e.map(A), r = 0;
	for (let i of t) {
		if (i.from === 0 || i.to >= e.length - 1 || Ce(t, i)) continue;
		let a = n[i.from - 1], o = n[i.to + 1], s = 0;
		for (let t of [
			0,
			1,
			-1
		]) {
			if (t === 0 ? a !== o : o !== a + t) continue;
			let r = 0;
			for (; i.from - 1 - r >= 0 && n[i.from - 1 - r] === a - t * r;) r += 1;
			let c = 0;
			for (; i.to + 1 + c < e.length && n[i.to + 1 + c] === o + t * c;) c += 1;
			s = Math.max(s, 2 * r * c * .45);
		}
		if (s <= 0) continue;
		let c = i.combo.count >= 2 ? 1 : i.combo.top >= 8 ? .6 : .3;
		r = Math.max(r, s * c);
	}
	return r * .5;
}
function Y(e) {
	let t = P(e), n = 0;
	for (let e of t) Ce(t, e) || (n += Se(e.combo) * (e.combo.count === 1 && e.combo.top <= 4 ? .5 : 1));
	return n + we(e, t);
}
var Te = (e) => e.count * 100 + (e.kind === "set" ? 30 : 0) + e.top, Ee = (e) => J((Te(e) - 150) / 280, .05, .95);
function De(e, t, n) {
	let r = t.players.filter((e) => e.rid !== n), i = J((3 - Math.min(...r.map((e) => e.handCount))) / 3, 0, 1) * (.4 + .6 * e.herd), a = (t.players.find((e) => e.rid === n)?.score ?? 0) - Math.max(...r.map((e) => e.score)), o = t.rounds - t.round + 1, s = J(-a / (8 * o), 0, 1) * e.compete, c = J(a / (8 * o), 0, 1) * e.compete, l = r.reduce((e, t) => e + t.handCount, 0) / Math.max(1, r.length);
	return {
		capture: 1.3 + .7 * e.greed,
		shed: (.9 + .5 * (1 - e.patience)) * (1 + i + .4 * c),
		build: (.4 + .45 * e.patience) * (1 - .75 * i),
		survive: (.55 + .9 * e.risk) * (1 + .5 * s),
		goOut: (2 + l) * (1 + s),
		deny: .6 + .6 * e.compete,
		noise: e.noise * 2
	};
}
function Oe(e, t, n, r, i) {
	let a = [...e.slice(0, t.from), ...e.slice(t.to + 1)], o = n * r.capture + t.combo.count * r.shed + Y(a) - Y(e);
	if (a.length === 0) return o + r.goOut;
	let s = Ee(t.combo);
	return o + s * i * r.survive - (1 - s) * t.combo.count * r.deny;
}
function X(e, t, n, r, i) {
	let a = null;
	for (let o of P(e)) {
		if (t !== null && !N(o.combo, t)) continue;
		let s = Oe(e, o, n, r, i);
		(!a || s > a.score) && (a = {
			from: o.from,
			to: o.to,
			score: s
		});
	}
	return a;
}
function ke(e, t) {
	let n = P(e).filter((e) => t === null || N(e.combo, t));
	if (!n.length) return null;
	let r = Math.min(...n.map((e) => e.combo.count));
	return q(n.filter((e) => e.combo.count === r));
}
function Ae(e, t, n, r, i, a) {
	let o = null, s = (e) => {
		(!o || e.score > o.score) && (o = e);
	};
	for (let o of ["left", "right"]) {
		let c = o === "left" ? 0 : t.cards.length - 1, l = t.cards[c], u = t.cards.filter((e, t) => t !== c), d = M(u);
		for (let t of [!1, !0]) {
			let c = {
				id: l.id,
				up: t ? l.up ^ 1 : l.up
			}, f = (Math.max(A(c), j(c)) * .08 + Math.abs(A(c) - j(c)) * .05) * (.4 + .9 * i.greed);
			for (let i = 0; i <= e.length; i += 1) {
				let l = [
					...e.slice(0, i),
					c,
					...e.slice(i)
				], p = (Y(l) - Y(e)) * r.build + f - r.deny - r.shed - e.length * .12;
				if (s({
					side: o,
					insertAt: i,
					flip: t,
					chip: !1,
					score: p
				}), n) {
					let e = X(l, d, u.length, r, a);
					e && s({
						side: o,
						insertAt: i,
						flip: t,
						chip: !0,
						score: p + e.score
					});
				}
			}
		}
	}
	return o ?? {
		side: "left",
		insertAt: 0,
		flip: !1,
		chip: !1,
		score: 0
	};
}
var je = (e, t) => {
	let n = e.public, r = e.private?.hand ?? [];
	if (e.private?.needsDecision) {
		if (t.difficulty === "weak") return { action: { type: q(["flip", "confirm"]) } };
		let e = y(s(t.rid));
		return { action: { type: Y(r.map((e) => ({
			id: e.id,
			up: e.up ^ 1
		}))) - Y(r) + (xe() - .5) * e.noise * 2 > 0 ? "flip" : "confirm" } };
	}
	if (n.phase === "roundOver") {
		let e = n.players.find((e) => e.rid === t.rid);
		return e && !e.decided ? { action: { type: "next" } } : null;
	}
	if (n.phase !== "play" || r.length === 0) return null;
	let i = n.table ? {
		kind: n.table.kind,
		top: n.table.top,
		count: n.table.cards.length
	} : null, a = n.players.length - 1;
	if (t.difficulty === "weak") {
		if (n.pendingShow !== null) return n.pendingShow === t.rid ? { action: {
			type: "show",
			...ke(r, i) ?? {
				from: 0,
				to: 0
			}
		} } : null;
		if (n.turn !== t.rid) return null;
		if (!n.table) {
			let e = q(P(r));
			return { action: {
				type: "show",
				from: e.from,
				to: e.to
			} };
		}
		let e = ke(r, i);
		return e && q([!0, !1]) ? { action: {
			type: "show",
			...e
		} } : { action: Me(r) };
	}
	let o = y(s(t.rid)), c = De(o, n, t.rid), l = () => (xe() - .5) * c.noise;
	if (n.pendingShow !== null) {
		if (n.pendingShow !== t.rid) return null;
		let e = X(r, i, n.table?.cards.length ?? 0, c, a) ?? {
			from: 0,
			to: 0,
			score: 0
		};
		return { action: {
			type: "show",
			from: e.from,
			to: e.to
		} };
	}
	if (n.turn !== t.rid) return null;
	if (!n.table) {
		let e = X(r, null, 0, c, a);
		return { action: {
			type: "show",
			from: e?.from ?? 0,
			to: e?.to ?? 0
		} };
	}
	let u = X(r, i, n.table.cards.length, c, a), d = Ae(r, n.table, e.private?.hasChip ?? !1, c, o, a);
	if (u) {
		let e = u.score + l();
		if (e >= -1 || e >= d.score + l()) return { action: {
			type: "show",
			from: u.from,
			to: u.to
		} };
	}
	return { action: {
		type: d.chip ? "scoutShow" : "scout",
		side: d.side,
		insertAt: d.insertAt,
		flip: d.flip
	} };
};
function Me(e) {
	return {
		type: "scout",
		side: q(["left", "right"]),
		insertAt: crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % (e.length + 1),
		flip: q([!1, !0])
	};
}
var Ne = {
	left: "games.scout.hintSideLeft",
	right: "games.scout.hintSideRight"
}, Pe = (e, t, n) => {
	if (e.type === "flip") return n("games.scout.flipDo");
	if (e.type === "confirm") return n("games.scout.flipConfirm");
	if (e.type === "next") return n("games.scout.nextRound");
	if (e.type === "show") {
		let r = M((t.private?.hand ?? []).slice(e.from, e.to + 1));
		return r ? n("games.scout.hintShow", { combo: r.kind === "set" ? n("games.scout.comboSetDesc", {
			v: r.top,
			n: r.count
		}) : n("games.scout.comboRunDesc", {
			a: r.top - r.count + 1,
			b: r.top
		}) }) : "";
	}
	if (e.type === "tick") return "";
	let r = n(Ne[e.side]);
	return n(e.type === "scoutShow" ? "games.scout.hintScoutShow" : "games.scout.hintScout", { side: r });
}, Fe = (e) => `${A(e)}(背面${j(e)})`, Ie = (e, t, n) => e === "set" ? `${n} 张 ${t}` : `${n} 张连号到 ${t}`, Le = {
	needsAction(e, t) {
		let n = e.public;
		return n.phase === "flip" ? e.private?.needsDecision === !0 : n.phase === "play" ? n.turn === t.rid : n.phase === "roundOver" && n.players.find((e) => e.rid === t.rid)?.decided === !1;
	},
	describeView(e, t) {
		let n = e.public, r = e.private?.hand ?? [], i = ["目标:出完手牌或压满一轮得分;scout(抽走场上组合的端头牌插进自己手牌)可以调整手牌结构,但会让对手得分。牌是双端的,打出的组合必须来自手牌中相邻的一段(可同值=对子/连号=顺子)。"];
		return i.push(`手牌(下标 0 起,顺序固定不可重排,只能 flip 整体翻面或 scout 插入): ${r.map((e, t) => `${t}:${Fe(e)}`).join(" ")}`), n.table ? i.push(`场上组合(${n.table.owner === t.rid ? "你的" : `${n.table.owner} 的`}): [${n.table.cards.map(Fe).join(" ")}] = ${Ie(n.table.kind, n.table.top, n.table.cards.length)}`) : i.push("场上无组合,你可以开出任意相邻组合。"), i.push(`各玩家: ${n.players.map((e) => `${e.rid === t.rid ? "你" : e.rid}: ${e.score}分,手牌${e.handCount}`).join("; ")}`), n.phase === "flip" && e.private?.needsDecision ? i.push("轮初朝向决策:flip 翻面(全员翻面后才开打)或 confirm 保持当前朝向。") : n.phase === "roundOver" ? i.push("本小局已结算,输出 next 确认进入下一局。") : n.phase === "play" && n.turn === t.rid && (n.pendingShow === t.rid ? i.push("你用了侦查+出牌芯片,本回合必须 show 一个能压过场上的组合。") : i.push(`轮到你:show(from,to 打出相邻区间)/scout(side,insertAt,flip 抽端头牌插入)${e.private?.hasChip ? "/scoutShow(耗芯片:抽完同回合必须打出)" : ""}。`)), i.join("\n");
	},
	actionJsonSchema: { oneOf: [
		{
			type: "object",
			properties: { type: { const: "flip" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "confirm" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "show" },
				from: {
					type: "integer",
					minimum: 0
				},
				to: {
					type: "integer",
					minimum: 0,
					description: "闭区间,from<=to"
				}
			},
			required: [
				"type",
				"from",
				"to"
			],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "scout" },
				side: { enum: ["left", "right"] },
				insertAt: {
					type: "integer",
					minimum: 0
				},
				flip: { type: "boolean" }
			},
			required: [
				"type",
				"side",
				"insertAt",
				"flip"
			],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "scoutShow" },
				side: { enum: ["left", "right"] },
				insertAt: {
					type: "integer",
					minimum: 0
				},
				flip: { type: "boolean" }
			},
			required: [
				"type",
				"side",
				"insertAt",
				"flip"
			],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "next" } },
			required: ["type"],
			additionalProperties: !1
		}
	] },
	parseAction(e, t, n) {
		let r = E.safeParse(e);
		if (!r.success) return null;
		let i = r.data, a = t.public, o = t.private?.hand ?? [], s = a.players.find((e) => e.rid === n.rid);
		if (i.type === "flip" || i.type === "confirm") return a.phase === "flip" && t.private?.needsDecision ? i : null;
		if (i.type === "next") return a.phase === "roundOver" && s && !s.decided ? i : null;
		if (i.type === "tick" || a.phase !== "play" || a.turn !== n.rid) return null;
		if (i.type === "show") {
			if (i.from < 0 || i.to < i.from || i.to >= o.length) return null;
			let e = M(o.slice(i.from, i.to + 1));
			return !e || a.table && !N(e, {
				kind: a.table.kind,
				top: a.table.top,
				count: a.table.cards.length
			}) ? null : i;
		}
		return a.pendingShow !== null || !a.table || i.type === "scoutShow" && !t.private?.hasChip || i.insertAt > o.length ? null : i;
	}
};
//#endregion
//#region src/games/scout/fx.tsx
function Z(e, t, n, r) {
	let i = e.anchor("table-card");
	if (i) {
		let e = i.w * (1 + 4 / 54);
		return {
			x: i.x + (n - (r - 1) / 2) * e,
			y: i.y,
			w: i.w,
			h: i.h
		};
	}
	let a = r * 54 + (r - 1) * 4, o = t.x + (t.w - a) / 2, s = t.y + Math.min(t.h * .35 + 28, t.h - 82 - 8);
	return {
		x: o + n * 58,
		y: s,
		w: 54,
		h: 82
	};
}
function Q(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function $(e) {
	return !Array.isArray(e) || !e.every((e) => typeof e == "object" && !!e && typeof e.id == "number") ? null : e;
}
function Re({ card: e, from: t, to: n, ms: r, delay: o }) {
	let s = a(null);
	return i(() => {
		let e = s.current?.animate([
			{ opacity: 1 },
			{
				opacity: 1,
				offset: .72
			},
			{ opacity: 0 }
		], {
			duration: r,
			delay: o,
			fill: "both"
		});
		return () => e?.cancel();
	}, [r, o]), /* @__PURE__ */ _("div", {
		ref: s,
		className: "absolute inset-0",
		children: /* @__PURE__ */ _(x, {
			from: t,
			to: n,
			ms: r,
			delay: o,
			children: /* @__PURE__ */ _(K, {
				card: e,
				size: "table",
				dimensions: t
			})
		})
	});
}
function ze({ at: e, delay: t, ms: n }) {
	let r = a(null);
	return i(() => {
		let e = r.current?.animate([
			{
				transform: "scale(.5)",
				opacity: 0
			},
			{
				transform: "scale(1)",
				opacity: 1,
				offset: .3
			},
			{
				transform: "scale(1.5)",
				opacity: 0
			}
		], {
			duration: n,
			delay: t,
			easing: "ease-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, [t, n]), /* @__PURE__ */ _("span", {
		ref: r,
		className: "scout-score-impact",
		style: {
			left: e.x + e.w / 2,
			top: e.y + e.h / 2
		}
	});
}
function Be({ before: e, after: t, ms: n, dimensions: r }) {
	let o = a(null);
	return i(() => {
		let e = o.current?.animate([{ transform: "rotateY(0deg)" }, { transform: "rotateY(180deg)" }], {
			duration: n,
			easing: "ease-in-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, [n]), /* @__PURE__ */ v("span", {
		ref: o,
		className: "scout-flip-card",
		style: {
			width: r.w,
			height: r.h
		},
		children: [/* @__PURE__ */ _("span", {
			className: "scout-flip-face",
			children: /* @__PURE__ */ _(K, {
				card: e,
				size: "table",
				dimensions: r
			})
		}), /* @__PURE__ */ _("span", {
			className: "scout-flip-face is-back",
			children: /* @__PURE__ */ _(K, {
				card: t,
				size: "table",
				dimensions: r
			})
		})]
	});
}
var Ve = {
	deal(e, t) {
		let n = t.queued > 0, r = n ? 240 : 320, i = n ? 18 : 45, a = e.secret, o = a ? $(a.cards) : null, s = t.anchor("table");
		if (o) {
			if (!s) return null;
			let e = [], a = [];
			for (let [n, c] of o.entries()) {
				let o = t.anchor(`hand:${c.id}`);
				if (!o) continue;
				let l = {
					x: s.x + (s.w - o.w) / 2,
					y: s.y + (s.h - o.h) / 2,
					w: o.w,
					h: o.h
				};
				a.push(`hand:${c.id}`), e.push(/* @__PURE__ */ _(x, {
					from: l,
					to: o,
					ms: r,
					delay: n * i,
					children: /* @__PURE__ */ _(K, {
						card: c,
						size: "hand",
						elevated: !0,
						dimensions: o
					})
				}, c.id));
			}
			return e.length ? {
				ms: r + e.length * i,
				node: e,
				hide: n ? [] : a
			} : null;
		}
		let c = Q(t, e.rid);
		if (!s || !c) return null;
		let l = Z(t, s, 0, 1), u = e.data?.count, d = typeof u == "number" ? u : 9;
		return {
			ms: r + d * i,
			node: Array.from({ length: d }, (e, t) => /* @__PURE__ */ _(x, {
				from: l,
				to: c,
				ms: r,
				delay: t * i,
				children: /* @__PURE__ */ _(me, { dimensions: l })
			}, t))
		};
	},
	collect(e, t) {
		let n = $(e.data?.taken), r = t.anchor("table"), i = e.rid ? t.anchor(`score:${e.rid}`) : null;
		if (!n?.length || !r || !i) return null;
		let a = t.queued > 0, o = a ? 170 : R.gatherFly, s = a ? 0 : R.gatherStagger, c = a ? 160 : R.starFly, l = a ? 190 : R.scorePop, u = o + (n.length - 1) * s, d = u + c, f = Z(t, r, 0, 1), p = {
			x: f.x + f.w * .2,
			y: f.y + f.h * .2,
			w: f.w * .6,
			h: f.h * .6
		};
		return {
			ms: a ? d + l + R.tail : z(n.length),
			node: /* @__PURE__ */ v(g, { children: [
				n.map((e, i) => /* @__PURE__ */ _(Re, {
					card: e,
					from: t.anchor(`tcard:${i}`) ?? Z(t, r, i, n.length),
					to: p,
					ms: o,
					delay: i * s
				}, e.id)),
				/* @__PURE__ */ _(x, {
					from: p,
					to: i,
					ms: c,
					delay: u,
					children: /* @__PURE__ */ _("span", {
						className: "scout-score-token",
						"aria-hidden": !0,
						children: "★"
					})
				}),
				/* @__PURE__ */ _(ze, {
					at: i,
					delay: d,
					ms: l
				}),
				/* @__PURE__ */ v(b, {
					at: i,
					delay: d,
					ms: l,
					children: ["+", n.length]
				})
			] }),
			hide: n.map((e, t) => `tcard:${t}`)
		};
	},
	show(e, t) {
		let n = e.data, r = $(n?.cards);
		if (!r) return null;
		let i = Q(t, e.rid), a = t.anchor("table");
		if (!i || !a) return null;
		let o = t.queued > 0, s = [], c = [];
		for (let [e, n] of r.entries()) {
			let l = t.anchor(`tcard:${e}`) ?? Z(t, a, e, r.length);
			c.push(`tcard:${e}`), s.push(/* @__PURE__ */ _(x, {
				from: i,
				to: l,
				ms: o ? 220 : L.fly,
				delay: o ? 0 : e * L.stagger,
				children: /* @__PURE__ */ _(K, {
					card: n,
					size: "table",
					dimensions: l
				})
			}, n.id));
		}
		return {
			ms: o ? 220 + L.tail : se(r.length),
			node: s,
			hide: o ? [] : c
		};
	},
	scout(e, t) {
		let n = e.data, r = $(n?.card === void 0 ? null : [n.card]), i = $(n?.fromCard === void 0 ? null : [n.fromCard]), a = t.anchor("table"), o = Q(t, e.rid);
		if (!r || !o || typeof n?.tableLenBefore != "number") return null;
		let s = e.rid === t.myRid ? t.anchor(`hand:${r[0].id}`) : null, c = s ?? o, l = n.tableLenBefore - 1, u = t.anchor("trow"), d = null;
		if (u && l > 0) {
			let e = t.anchor("tcard:0") ?? (a ? Z(t, a, 0, 1) : null);
			if (e) {
				let t = l > 1 ? (u.w - l * e.w) / (l - 1) : e.w * 4 / 54, r = e.w + t;
				d = {
					x: u.x + (n.side === "left" ? -.5 : l - .5) * r,
					y: e.y,
					w: e.w,
					h: e.h
				};
			}
		} else a && (d = Z(t, a, n.side === "left" ? 0 : n.tableLenBefore - 1, n.tableLenBefore));
		if (!d) return null;
		let f = t.queued > 0, p = f ? 220 : 380, m = [/* @__PURE__ */ _(x, {
			from: d,
			to: c,
			ms: p,
			children: i && i[0].up !== r[0].up ? /* @__PURE__ */ _(Be, {
				before: i[0],
				after: r[0],
				ms: p,
				dimensions: d
			}) : /* @__PURE__ */ _(K, {
				card: r[0],
				size: "table",
				dimensions: d
			})
		}, "scout")];
		if (typeof n.owner == "string" && n.owner !== e.rid) {
			let e = Q(t, n.owner);
			e && m.push(/* @__PURE__ */ _(b, {
				at: e,
				ms: 800,
				delay: f ? 100 : 200,
				children: "+1"
			}, "tok"));
		}
		return {
			ms: f ? 320 : 600,
			node: m,
			hide: s && !f ? [`hand:${r[0].id}`] : []
		};
	},
	flipHand(e, t) {
		let n = Q(t, e.rid);
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ _(ie, {
				at: n,
				ms: 600
			})
		} : null;
	},
	roundEnd(e, t) {
		let n = e.data?.deltas;
		if (typeof n != "object" || !n) return null;
		let r = [];
		for (let [e, i] of Object.entries(n)) {
			if (typeof i != "number" || i === 0) continue;
			let n = Q(t, e);
			n && r.push(/* @__PURE__ */ _(b, {
				at: n,
				ms: 1e3,
				delay: 100,
				children: i > 0 ? `+${i}` : `${i}`
			}, e));
		}
		return r.length ? {
			ms: 1100,
			node: r
		} : null;
	}
};
//#endregion
//#region src/games/scout/game-over.tsx
function He({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let o = t, s = d(), c = u((e) => e.locale), l = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? re(t, c) : e;
	}, f = i ?? a;
	return /* @__PURE__ */ _("div", {
		className: "scout-screen scout-over",
		children: /* @__PURE__ */ v("div", {
			className: "scout-over-layout",
			children: [
				/* @__PURE__ */ _(ae, {}),
				/* @__PURE__ */ v("header", {
					className: "scout-over-heading",
					children: [
						/* @__PURE__ */ _("span", {
							"aria-hidden": !0,
							children: "★"
						}),
						/* @__PURE__ */ _("h1", { children: s("games.scout.resultTitle") }),
						/* @__PURE__ */ _("span", { children: s("games.scout.roundStage", {
							n: o.round,
							total: o.rounds
						}) })
					]
				}),
				/* @__PURE__ */ v("div", {
					className: "scout-over-main",
					children: [/* @__PURE__ */ _("div", {
						className: "scout-over-results",
						style: { "--scout-players": e.ranking.length },
						children: e.ranking.map((t) => {
							let i = o.players.find((e) => e.rid === t);
							if (!i) return null;
							let a = n.find((e) => e.rid === t), c = l(t), u = e.winner.includes(t), d = o.roundDeltas?.[t], f = o.endReason?.kind === "allScout" && o.endReason.rid === t ? 0 : i.handCount;
							return /* @__PURE__ */ v("section", {
								className: `scout-over-result${u ? " scout-over-result--winner" : ""}`,
								children: [
									/* @__PURE__ */ v("div", {
										className: "scout-over-person",
										children: [
											/* @__PURE__ */ v("span", {
												className: "scout-over-avatar",
												style: { background: C[(a?.colorIndex ?? 0) % C.length].hex },
												children: [a && /* @__PURE__ */ _("img", {
													src: S[a.avatar % S.length],
													alt: ""
												}), u && /* @__PURE__ */ _("span", {
													"aria-label": s("games.scout.resultWinner"),
													children: "👑"
												})]
											}),
											/* @__PURE__ */ _("h2", {
												title: c,
												children: c
											}),
											t === r && /* @__PURE__ */ _("small", { children: s("lobby.you") })
										]
									}),
									/* @__PURE__ */ v("div", {
										className: "scout-over-total",
										children: [/* @__PURE__ */ _("span", { children: s("games.scout.resultTotal") }), /* @__PURE__ */ v("strong", {
											className: "font-mono tabular-nums",
											children: ["★ ", e.scores?.[t] ?? i.score]
										})]
									}),
									d !== void 0 && /* @__PURE__ */ v("div", {
										className: "scout-over-last",
										children: [/* @__PURE__ */ _("span", { children: s("games.scout.resultLastRound") }), /* @__PURE__ */ v("b", {
											className: "font-mono tabular-nums",
											children: [d > 0 ? "+" : "", d]
										})]
									}),
									/* @__PURE__ */ v("div", {
										className: "scout-over-breakdown",
										children: [
											/* @__PURE__ */ _("span", { children: s("games.scout.resultCaptured", { n: i.captured }) }),
											/* @__PURE__ */ _("span", { children: s("games.scout.resultScouted", { n: i.tokens }) }),
											/* @__PURE__ */ _("span", { children: s("games.scout.resultPenalty", { n: f }) })
										]
									})
								]
							}, t);
						})
					}), o.table && /* @__PURE__ */ v("section", {
						className: "scout-over-table",
						children: [/* @__PURE__ */ _("h2", { children: s("games.scout.resultTable", { name: l(o.table.owner) }) }), /* @__PURE__ */ _("div", {
							className: "scout-over-table-scroll",
							children: /* @__PURE__ */ _("div", {
								className: "scout-over-table-cards",
								children: o.table.cards.map((e) => /* @__PURE__ */ _(K, {
									card: e,
									size: "table"
								}, e.id))
							})
						})]
					})]
				}),
				f ? /* @__PURE__ */ v("div", {
					className: "scout-over-actions safe-b",
					children: [i && /* @__PURE__ */ _("button", {
						type: "button",
						className: "btn-base text-white",
						style: { background: w.accent },
						onClick: i,
						children: s("session.result.playAgain")
					}), a && /* @__PURE__ */ _("button", {
						type: "button",
						className: "btn-quiet bg-surface",
						onClick: a,
						children: s("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ _("p", {
					className: "scout-over-wait safe-b",
					children: s("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region src/games/scout/guide.tsx
var Ue = 21;
function We() {
	let e = d();
	return /* @__PURE__ */ v("section", {
		className: "flex w-full flex-col gap-1.5",
		children: [
			/* @__PURE__ */ _("p", {
				className: "section-label",
				children: e("games.scout.guideTitle")
			}),
			/* @__PURE__ */ v("div", {
				className: "frame flex items-center justify-center gap-4 p-3",
				children: [
					/* @__PURE__ */ _(K, {
						card: {
							id: Ue,
							up: 0
						},
						size: "hand"
					}),
					/* @__PURE__ */ _("span", {
						"aria-hidden": !0,
						className: "text-xl font-extrabold",
						children: "⇄"
					}),
					/* @__PURE__ */ _(K, {
						card: {
							id: Ue,
							up: 1
						},
						size: "hand"
					})
				]
			}),
			/* @__PURE__ */ _("p", {
				className: "text-xs leading-5 font-bold opacity-70",
				children: e("games.scout.guideCaption")
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/scout/entry.tsx
var Ge = {
	definition: G,
	View: he,
	bot: je,
	describe: Pe,
	llm: Le,
	fx: Ve,
	OverView: He,
	Guide: We,
	locales: {
		zh: {
			name: "马戏星探",
			desc: "手牌不许重排!压过场上组合,或抽端牌补强",
			rules: "目标:打满与人数相同的轮数,总分最高者获胜。\n牌与手牌:\n· 全组共 45 张牌,每张牌两端各印一个数字,覆盖 1~10 的全部两两组合。\n· 拿起手牌后，不能改变手牌顺序。每轮开始前，可以将整手牌翻面，使每张牌两端的数字互换；此操作不限次数，确认手牌方向后开始本轮。\n行动(二选一):\n· 出牌：打出手牌中连续相邻的一组牌，组成同点数组或连续点数组，并且须强于场上已有组合。获得被压过的原组合，每张牌计1分。\n· 侦查:抽走场上组合端头的一张牌,以任意位置、任意朝向插入手牌;组合的主人获得 1 分。\n· 每名玩家每轮可以使用一次“侦查与出牌”：完成侦查后，必须立即打出一组能够压过场上组合的牌。\n组合强弱依次按以下标准比较：\n· 先比较张数，张数较多的组合更强。\n· 张数相同时，同点数组强于连续点数组。\n· 张数和牌型均相同时，数字较大的组合更强。\n轮末:\n· 有人出完手牌,或一组牌一圈无人压过时,本轮结束。\n· 结算：将通过出牌赢得的卡牌分数与侦查获得的分数相加，再按每张剩余手牌扣除1分。若本轮因一组牌连续一圈未被压过而结束，该组合的主人无须为剩余手牌扣分。\n· 连续经过相当于玩家人数四倍的行动次数，仍无人打出更强组合时，立即结束本轮，并按当前局面结算(防僵局)。",
			guideTitle: "双端牌",
			guideCaption: "较大的数字是该牌当前使用的数值，淡色小数字是另一端的数值。翻转手牌方向后，两端的数字互换。",
			roundShort: "{{n}}/{{total}}",
			roundStage: "第 {{n}} / {{total}} 幕",
			flipPrompt: "起手翻面",
			flipDo: "翻面",
			flipConfirm: "确定",
			flipWaiting: "等待其他玩家",
			transitioning: "换牌中",
			settling: "谢幕结算",
			roundOver: "本轮结算",
			roundWaiting: "等待其他玩家",
			nextRound: "进入下一轮",
			showFinal: "查看最终结算",
			resultTitle: "谢幕总分",
			resultWinner: "获胜",
			resultTotal: "总分",
			resultLastRound: "末轮得分",
			resultCaptured: "末轮收牌 +{{n}}",
			resultScouted: "末轮侦查 +{{n}}",
			resultPenalty: "末轮余牌罚分 −{{n}}",
			resultTable: "末轮场牌 · {{name}}",
			endReasonEmpty: "{{name}} 出完了手牌",
			endReasonAllScout: "{{name}} 的组合没人压过(主人免罚)",
			endReasonStall: "太久无人压场,强制收轮(防僵局)",
			turnYou: "轮到你",
			turnOpen: "开演",
			turnWait: "等待 {{name}}",
			mustShow: "请出牌",
			tableEmpty: "{{name}} 开演",
			ownerLabel: "{{name}}",
			comboKindSet: "同值",
			comboKindRun: "连号",
			comboSetDesc: "同值 {{v}} ×{{n}}",
			comboRunDesc: "连号 {{a}}–{{b}}",
			badCombo: "这段不是同值/连号",
			cantBeat: "压不过场上组合",
			play: "打出",
			cancel: "取消",
			scout: "插入",
			scoutShow: "插牌＋出牌",
			useChip: "插牌＋出牌",
			insertPick: "点＋选位置",
			insertFlip: "翻面插入",
			faceDirection: "朝向",
			keepFace: "保持 {{n}}",
			flipFace: "翻面成 {{n}}",
			onlyScout: "只插牌",
			confirmScout: "确认插牌",
			confirmScoutShow: "确认插牌＋出牌",
			chipReady: "本轮 1 次",
			chipUsed: "本轮已用",
			insertHint: "点＋换位 · 左右滑动",
			endHint: "点端牌插入手牌",
			pickHand: "选一段手牌",
			handLabel: "手牌",
			stripHand: "{{n}} 张",
			stripEarned: "本轮+{{n}}",
			cardAria: "上 {{a}} 下 {{b}}",
			scoutLeftAria: "抽左端牌",
			scoutRightAria: "抽右端牌",
			insertAtAria: "插到第 {{n}} 位",
			errNotYourTurn: "现在轮不到你",
			errNoFlip: "现在不能翻面",
			errBadShow: "这段牌出不了",
			errTooWeak: "压不过场上组合",
			errNoTable: "场空只能出牌",
			errChipUsed: "本轮芯片已用掉",
			errNoFollow: "抽完也无牌可压,不能侦查+出牌",
			errBadInsert: "插入位置不对",
			hintShow: "打出 {{combo}}",
			hintScout: "抽{{side}}的牌",
			hintScoutShow: "侦查+出牌:抽{{side}}的牌",
			hintSideLeft: "左端",
			hintSideRight: "右端"
		},
		en: {
			name: "SCOUT",
			desc: "No rearranging your hand! Beat the set, or scout an end card",
			rules: "Goal: play as many rounds as there are players; the highest total score wins.\nCards:\n· The deck has 45 double-ended cards, each showing a different pair of numbers — every pairing of 1–10.\n· Your hand may never be rearranged once picked up. At the start of each round you may flip your whole hand (swapping the two ends of every card) as often as you like before confirming.\nOn your turn, choose one:\n· Show: play an adjacent segment of your hand forming a set (equal values) or a run (consecutive values) that beats the current combination; the beaten combination is captured for 1 point per card.\n· Scout: take either end card of the current combination and insert it into your hand at any position, either end up; the combination’s owner scores 1 point.\n· Once per round you may Scout & Show: scout, then immediately play a combination that beats the table.\nBeating: more cards wins; with equal counts a set beats a run; otherwise the higher value wins.\nRound end:\n· A round ends when someone empties their hand, or when a combination goes unbeaten for a full round of the table.\n· Scoring: captured cards and scout income count positive; each card left in hand counts −1. The owner of an unbeaten combination is exempt from the hand penalty.\n· If nobody captures for 4 turns per player in a row, the round is force-ended and scored as-is (anti-stall).",
			guideTitle: "Double-ended cards",
			guideCaption: "The large number is the current value; the small faded number is the other end. Flipping the card swaps the two ends.",
			roundShort: "{{n}}/{{total}}",
			roundStage: "Act {{n}} / {{total}}",
			flipPrompt: "Flip opening hand",
			flipDo: "Flip",
			flipConfirm: "Confirm",
			flipWaiting: "Waiting for players",
			transitioning: "Cards in motion",
			settling: "Curtain call",
			roundOver: "Round score",
			roundWaiting: "Waiting for players",
			nextRound: "Next round",
			showFinal: "See final results",
			resultTitle: "Curtain call",
			resultWinner: "Winner",
			resultTotal: "Total score",
			resultLastRound: "Last round",
			resultCaptured: "Last-round captures +{{n}}",
			resultScouted: "Last-round scout income +{{n}}",
			resultPenalty: "Last-round hand penalty −{{n}}",
			resultTable: "Last table · {{name}}",
			endReasonEmpty: "{{name}} emptied their hand",
			endReasonAllScout: "Nobody beat {{name}}'s set (owner exempt)",
			endReasonStall: "No captures for too long — round forced (anti-stall)",
			turnYou: "Your turn",
			turnOpen: "Open the show",
			turnWait: "Waiting for {{name}}",
			mustShow: "Play a set",
			tableEmpty: "{{name}} opens",
			ownerLabel: "{{name}}",
			comboKindSet: "Set",
			comboKindRun: "Run",
			comboSetDesc: "Set of {{v}} ×{{n}}",
			comboRunDesc: "Run {{a}}–{{b}}",
			badCombo: "Not a set or a run",
			cantBeat: "Can't beat the table",
			play: "Show",
			cancel: "Cancel",
			scout: "Scout",
			scoutShow: "Scout & Show",
			useChip: "Scout & Show",
			insertPick: "Tap + to insert",
			insertFlip: "Flip on insert",
			faceDirection: "Orientation",
			keepFace: "Keep {{n}}",
			flipFace: "Flip to {{n}}",
			onlyScout: "Scout only",
			confirmScout: "Confirm insert",
			confirmScoutShow: "Confirm Scout & Show",
			chipReady: "1 use this round",
			chipUsed: "Used this round",
			insertHint: "Tap + to move · Swipe for more",
			endHint: "Tap an end card to scout",
			pickHand: "Select adjacent cards",
			handLabel: "Your hand",
			stripHand: "{{n}} cards",
			stripEarned: "+{{n}} this round",
			cardAria: "{{a}} up, {{b}} down",
			scoutLeftAria: "Scout left end",
			scoutRightAria: "Scout right end",
			insertAtAria: "Insert at slot {{n}}",
			errNotYourTurn: "Not your move right now",
			errNoFlip: "No flip right now",
			errBadShow: "Those cards cannot be played",
			errTooWeak: "Doesn't beat the table",
			errNoTable: "Empty table — you must show",
			errChipUsed: "Chip already used this round",
			errNoFollow: "No beating set after that scout",
			errBadInsert: "Bad insert position",
			hintShow: "Play {{combo}}",
			hintScout: "Scout the {{side}} card",
			hintScoutShow: "Scout the {{side}} card, then show",
			hintSideLeft: "left end",
			hintSideRight: "right end"
		}
	}
};
//#endregion
export { Ge as default };
