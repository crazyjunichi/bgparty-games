import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as c } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { IconRotate as d } from "@bgparty/sdk/icons";
import { PhaseBanner as f } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as ee, seatName as p } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as te } from "@bgparty/sdk/ui/game-screen";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Floater as _, FlySprite as v, PulseBox as y } from "@bgparty/sdk/fx/primitives";
import { playSettle as b } from "@bgparty/sdk/sfx";
import { AVATARS as ne } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as x } from "@bgparty/sdk/player-colors";
import { Confetti as re } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as S, OptionSection as C } from "@bgparty/sdk/ui/game-options";
//#region src/games/queensgarden/schema.ts
var w = [
	"blue",
	"dpurple",
	"violet",
	"yellow",
	"lgreen",
	"dgreen"
], T = [
	"tree",
	"bird",
	"butterflies",
	"flower",
	"branch",
	"swarm"
], E = t.enum(w), ie = t.enum(T), D = t.object({
	c: E,
	p: ie
}), ae = t.union([D, t.literal("joker")]), O = t.string(), k = t.int().nonnegative(), A = t.object({
	tiles: t.array(k).max(12),
	expansions: t.array(k).max(2)
}), oe = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("acquire"),
		sel: t.union([t.object({
			kind: t.literal("pattern"),
			key: ie
		}), t.object({
			kind: t.literal("color"),
			key: E
		})])
	}),
	t.object({
		type: t.literal("placeTile"),
		item: k,
		pay: A,
		cell: t.string()
	}),
	t.object({
		type: t.literal("placeExpansion"),
		source: t.enum(["storage", "supply"]),
		item: k.optional(),
		recess: t.int().min(0).max(5),
		rot: t.int().min(0).max(5),
		pay: A
	}),
	t.object({
		type: t.literal("pass"),
		discard: A
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), j = t.object({ variant: t.boolean().default(!1) }).default({ variant: !1 }), se = t.object({
	exp: t.int().min(0).max(35),
	tiles: t.array(D).max(4),
	faceUp: t.boolean()
}), ce = t.object({
	cells: t.record(t.string(), D),
	expansions: t.array(t.object({
		recess: t.int().min(0).max(5),
		rot: t.int().min(0).max(5),
		side: t.enum(["pavilion", "plain"]),
		exp: t.int().min(0).max(35).nullable()
	}))
}), M = t.object({
	phase: t.enum([
		"action",
		"score",
		"final",
		"done"
	]),
	round: t.int().min(1).max(4),
	variant: t.boolean(),
	turn: O.nullable(),
	passed: t.array(O),
	firstRid: O,
	firstMarkerInDisplay: t.boolean(),
	display: t.array(se),
	stackTopActive: t.boolean(),
	stackCounts: t.tuple([
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative()
	]),
	supplyCount: t.int().nonnegative(),
	bagCount: t.int().nonnegative(),
	towerCount: t.int().nonnegative(),
	focusRid: O.nullable(),
	evalStep: t.int().min(-1).max(11),
	players: t.array(t.object({
		rid: O,
		score: t.int().nonnegative(),
		storage: t.array(ae).max(12),
		expansions: t.array(t.int().min(0).max(35)).max(2),
		garden: ce
	}))
}), N = t.object({}), le = [
	[1, 0],
	[1, -1],
	[0, -1],
	[-1, 0],
	[-1, 1],
	[0, 1]
];
function ue(e, t) {
	return `${e},${t}`;
}
function de(e) {
	let t = e.indexOf(",");
	return [Number(e.slice(0, t)), Number(e.slice(t + 1))];
}
function P(e) {
	let [t, n] = de(e);
	return le.map(([e, r]) => ue(t + e, n + r));
}
var fe = [
	"0,-1",
	"1,-1",
	"1,0",
	"0,1",
	"-1,1",
	"-1,0"
], F = /* @__PURE__ */ new Map([
	["1,-2", "bench"],
	["2,-1", "statue"],
	["1,1", "bench"],
	["-1,2", "statue"],
	["-2,1", "bench"],
	["-1,-1", "statue"]
]), pe = {
	fountain: 1,
	statue: 2,
	bench: 2,
	pavilion: 3
}, I = [
	[0, -3],
	[3, -3],
	[3, 0],
	[0, 3],
	[-3, 3],
	[-3, 0]
].map(([e, t], n) => ({
	id: n,
	center: ue(e, t),
	cells: [ue(e, t), ...le.map(([n, r]) => ue(e + n, t + r))]
})), me = ["2,-4", "-2,4"], L = T.flatMap((e) => w.map((t) => ({
	c: t,
	p: e
}))), R = (e) => L[e];
function he(e) {
	let t = I[e.recess].cells;
	return e.side === "plain" ? t : t.filter((t, n) => n !== 0 && n !== 1 + e.rot);
}
function ge(e) {
	return e.side === "pavilion" ? I[e.recess].cells[1 + e.rot] : null;
}
//#endregion
//#region src/games/queensgarden/meta.ts
var z = {
	id: "queensgarden",
	tier: "beta",
	mechanics: ["drafting", "tile-placement"],
	interactionTags: [],
	nameKey: "games.queensgarden.name",
	descKey: "games.queensgarden.desc",
	rulesKey: "games.queensgarden.rules",
	icon: "🪴",
	iconImg: "games/queensgarden.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/queensgarden/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#28664c",
	releasedAt: "2026-09-14",
	search: {
		py: "hua zhuan wu yu hua yuan gong dian",
		init: "hzwyhygd"
	},
	hotseat: "cover"
}, B = 3, V = (e) => T.indexOf(e) + 1, _e = {
	2: 5,
	3: 7,
	4: 8
}, H = {
	enter: 600,
	score: 1500,
	refill: 1200,
	settle: 1100,
	eval: 1600
}, ve = [
	{
		kind: "pattern",
		p: "tree",
		pts: 1
	},
	{
		kind: "color",
		c: "blue",
		pts: 1
	},
	{
		kind: "pattern",
		p: "bird",
		pts: 1
	},
	{
		kind: "color",
		c: "dpurple",
		pts: 1
	},
	{
		kind: "pattern",
		p: "butterflies",
		pts: 2
	},
	{
		kind: "color",
		c: "violet",
		pts: 1
	},
	{
		kind: "pattern",
		p: "flower",
		pts: 2
	},
	{
		kind: "color",
		c: "yellow",
		pts: 1
	},
	{
		kind: "pattern",
		p: "branch",
		pts: 3
	},
	{
		kind: "color",
		c: "lgreen",
		pts: 1
	},
	{
		kind: "pattern",
		p: "swarm",
		pts: 3
	},
	{
		kind: "color",
		c: "dgreen",
		pts: 1
	}
], ye = [
	{
		kind: "pattern",
		p: "swarm",
		pts: 6
	},
	{
		kind: "color",
		c: "blue",
		pts: 1
	},
	{
		kind: "pattern",
		p: "branch",
		pts: 5
	},
	{
		kind: "color",
		c: "lgreen",
		pts: 1
	},
	{
		kind: "pattern",
		p: "flower",
		pts: 4
	},
	{
		kind: "color",
		c: "violet",
		pts: 1
	},
	{
		kind: "pattern",
		p: "butterflies",
		pts: 3
	},
	{
		kind: "color",
		c: "dgreen",
		pts: 1
	},
	{
		kind: "pattern",
		p: "bird",
		pts: 2
	},
	{
		kind: "color",
		c: "yellow",
		pts: 1
	},
	{
		kind: "pattern",
		p: "tree",
		pts: 1
	},
	{
		kind: "color",
		c: "dpurple",
		pts: 1
	}
];
function be(e, t) {
	let n = e ? ye : ve, r = (((t - 1) * 3 - 1) % 12 + 12) % 12;
	return [
		0,
		1,
		2
	].map((e) => n[(r + e) % 12]);
}
function U(e, t) {
	return e ? t === 4 ? 3 : t === 5 ? 5 : t === 6 ? 7 : 0 : t === 6 ? 6 : 0;
}
function W(e) {
	let t = new Map(Object.entries(e.cells));
	for (let n of e.expansions) {
		let e = ge(n);
		e !== null && n.exp !== null && t.set(e, R(n.exp));
	}
	return t;
}
function xe(e) {
	let t = new Set(fe);
	for (let n of e.expansions) for (let e of he(n)) t.add(e);
	return t;
}
function G(e, t, n) {
	if (e.has(t)) return !1;
	let r = P(t).filter((t) => e.has(t));
	if (r.length > 0 && !r.some((t) => {
		let r = e.get(t);
		return r.c === n.c || r.p === n.p;
	})) return !1;
	let i = /* @__PURE__ */ new Set([t]), a = /* @__PURE__ */ new Set([`${n.c}:${n.p}`]), o = [t], s = (r) => r === t ? n : e.get(r);
	for (; o.length > 0;) {
		let r = o.pop(), c = s(r);
		for (let s of P(r)) {
			if (i.has(s)) continue;
			let r = s === t ? n : e.get(s);
			if (!r || r.c !== c.c && r.p !== c.p) continue;
			let l = `${r.c}:${r.p}`;
			if (a.has(l)) return !1;
			a.add(l), i.add(s), o.push(s);
		}
	}
	return !0;
}
function Se(e, t, n) {
	return xe(e).has(t) ? G(W(e), t, n) : !1;
}
function Ce(t, n, r) {
	for (let i = t.length - 1; i > 0; --i) {
		let a = e(n, r.n, i + 1);
		r.n += 1, [t[i], t[a]] = [t[a], t[i]];
	}
}
function we(e, t) {
	let n = [];
	for (; n.length < t;) {
		if (e.bag.length === 0) {
			if (e.tower.length === 0) break;
			let t = [...e.tower], n = { n: e.rngCursor };
			Ce(t, e.seed, n), e.rngCursor = n.n, e.bag = t, e.tower = [];
		}
		n.push(e.bag.pop());
	}
	return n;
}
function K(e) {
	let t = e.stacks[e.round - 1], n = t.pop();
	if (n === void 0) {
		e.stackTopActive = !1;
		return;
	}
	let r = we(e, 4);
	if (r.length === 0) {
		for (e.display.push({
			exp: n,
			tiles: [],
			faceUp: !0
		}); t.length > 0;) e.display.push({
			exp: t.pop(),
			tiles: [],
			faceUp: !0
		});
		e.stackTopActive = !1;
		return;
	}
	e.display.unshift({
		exp: n,
		tiles: r,
		faceUp: !1
	}), e.stackTopActive = !0;
}
function Te(t, n, r) {
	let i = { n: 0 }, a = [];
	for (let e of T) for (let t of w) for (let n = 0; n < 3; n += 1) a.push({
		c: t,
		p: e
	});
	Ce(a, r, i);
	let o = L.map((e, t) => t);
	Ce(o, r, i);
	let s = _e[n.length], c = Array.from({ length: 4 }, () => o.splice(0, s)), l = n[e(r, i.n, n.length)];
	i.n += 1;
	let u = {}, d = {}, f = {};
	for (let e of n) u[e] = {
		tiles: Array.from({ length: B }, () => "joker"),
		expansions: []
	}, d[e] = {
		cells: {},
		expansions: [],
		surrounded: []
	}, f[e] = 15;
	let ee = {
		players: n,
		turn: n.indexOf(l),
		round: 1,
		phase: "action",
		variant: t.variant,
		passed: [],
		firstRid: l,
		firstMarkerInDisplay: !0,
		stacks: c,
		display: [],
		stackTopActive: !1,
		supply: o,
		bag: a,
		tower: [],
		storage: u,
		gardens: d,
		scores: f,
		queue: [],
		focusRid: null,
		evalStep: -1,
		beatMs: 0,
		seed: r,
		rngCursor: i.n
	};
	return K(ee), {
		state: ee,
		fx: [{
			kind: "refill",
			data: {}
		}]
	};
}
function Ee(e) {
	let t = e.filter((e) => e !== null), n = t.every((e) => e.p === t[0].p) && new Set(t.map((e) => e.c)).size === t.length, r = t.every((e) => e.c === t[0].c) && new Set(t.map((e) => e.p)).size === t.length;
	return n || r;
}
function De(e, t) {
	return new Set(t.tiles).size !== t.tiles.length || new Set(t.expansions).size !== t.expansions.length || t.tiles.some((t) => t >= e.tiles.length) || t.expansions.some((t) => t >= e.expansions.length) ? null : {
		tiles: t.tiles.map((t) => e.tiles[t]),
		exps: t.expansions.map((t) => e.expansions[t])
	};
}
function Oe(e, t, n, r, i) {
	for (let i of [...n.tiles].sort((e, t) => t - e)) {
		let n = t.tiles[i];
		t.tiles.splice(i, 1), i !== r && n !== "joker" && e.tower.push(n);
	}
	for (let r of [...n.expansions].sort((e, t) => t - e)) {
		let n = t.expansions[r];
		t.expansions.splice(r, 1), r !== i && e.supply.unshift(n);
	}
}
function q(e, t) {
	let n = e.gardens[t], r = W(n), i = [
		{
			id: "0,0",
			kind: "fountain",
			center: "0,0"
		},
		...[...F.entries()].map(([e, t]) => ({
			id: e,
			kind: t,
			center: e
		})),
		...n.expansions.map((e, t) => ({
			id: `pav:${t}`,
			kind: "pavilion",
			center: I[e.recess].center
		})).filter((e, t) => n.expansions[t].side === "pavilion")
	], a = [];
	for (let o of i) {
		if (n.surrounded.includes(o.id) || !P(o.center).every((e) => r.has(e))) continue;
		n.surrounded.push(o.id);
		let i = 0;
		for (let n = 0; n < pe[o.kind]; n += 1) e.storage[t].tiles.length < 12 && (e.storage[t].tiles.push("joker"), i += 1);
		a.push({
			id: o.id,
			kind: o.kind,
			jokers: i
		});
	}
	return a;
}
function J(e) {
	for (let t = 1; t <= e.players.length; t += 1) {
		let n = (e.turn + t) % e.players.length;
		if (!e.passed.includes(e.players[n])) {
			e.turn = n;
			return;
		}
	}
}
function ke(e) {
	e.phase = "score", e.focusRid = null;
	let t = e.players.indexOf(e.firstRid);
	e.queue = e.players.map((n, r) => e.players[(t + r) % e.players.length]), e.beatMs = H.enter;
}
function Ae(e) {
	for (let t of e.display) e.tower.push(...t.tiles), e.supply.unshift(t.exp);
	let t = e.stacks[e.round - 1];
	for (; t.length > 0;) e.supply.unshift(t.pop());
	e.display = [], e.stackTopActive = !1, e.round += 1, e.passed = [], e.firstMarkerInDisplay = !0, e.turn = e.players.indexOf(e.firstRid), e.phase = "action", e.focusRid = null, K(e);
}
function je(e, t, n) {
	let r = be(t, n), i = W(e), a = 0, o = [];
	for (let [e, t] of i) for (let n of r) (n.kind === "color" && t.c === n.c || n.kind === "pattern" && t.p === n.p) && (a += n.pts, o.push(e));
	let s = e.expansions.filter((e) => e.side === "pavilion").length;
	return {
		gained: a + s,
		pavilions: s,
		matched: o
	};
}
function Me(e, t) {
	let n = (e) => t.kind === "color" ? e.c === t.c : e.p === t.p, r = new Set([...e.entries()].filter(([, e]) => n(e)).map(([e]) => e)), i = [];
	for (; r.size > 0;) {
		let e = r.values().next().value;
		r.delete(e);
		let t = [e], n = [e];
		for (; n.length > 0;) for (let e of P(n.pop())) r.has(e) && (r.delete(e), t.push(e), n.push(e));
		t.length >= 3 && i.push(t);
	}
	return i;
}
var Y = (e) => ({ code: e });
function Ne(e, t) {
	let n = (e) => t.kind === "pattern" ? e.p === t.key : e.c === t.key, r = /* @__PURE__ */ new Set(), i = [], a = [];
	for (let t = e.length - 1; t >= 0; --t) e[t].tiles.forEach((e, a) => {
		if (!n(e)) return;
		let o = `${e.c}:${e.p}`;
		r.has(o) || (r.add(o), i.push({
			slot: t,
			idx: a,
			h: e
		}));
	});
	for (let t = e.length - 1; t >= 0; --t) {
		let i = e[t];
		if (!i.faceUp) continue;
		let o = R(i.exp);
		if (!n(o)) continue;
		let s = `${o.c}:${o.p}`;
		r.has(s) || (r.add(s), a.push(t));
	}
	return {
		tiles: i,
		exps: a
	};
}
function Pe(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "score" && e.phase !== "final") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		if (t.phase === "score") {
			let e = t.queue.shift();
			if (!e) {
				if (t.round < 4) return Ae(t), {
					state: t,
					fx: [{
						kind: "refill",
						data: { round: t.round }
					}]
				};
				t.phase = "final", t.evalStep = -1, t.focusRid = null;
				let e = t.players.indexOf(t.firstRid);
				return t.queue = t.players.map((n, r) => t.players[(e + r) % t.players.length]), t.beatMs = H.settle, {
					state: t,
					fx: []
				};
			}
			let n = t.gardens[e], { gained: r, pavilions: i, matched: a } = je(n, t.variant, t.round);
			return t.scores[e] += r, t.focusRid = e, t.beatMs = H.score, {
				state: t,
				fx: [{
					kind: "score",
					rid: e,
					data: {
						round: t.round,
						gained: r,
						pavilions: i,
						matched: a
					}
				}]
			};
		}
		if (t.evalStep === -1) {
			let e = t.queue.shift();
			if (e) {
				let n = t.storage[e], r = 0, i = 0;
				for (let e of n.tiles) e === "joker" ? r += 1 : i += V(e.p);
				for (let e of n.expansions) i += V(R(e).p);
				return t.scores[e] = Math.max(0, t.scores[e] + r - i), n.tiles = [], n.expansions = [], t.focusRid = e, t.beatMs = H.settle, {
					state: t,
					fx: [{
						kind: "settle",
						rid: e,
						data: {
							plus: r,
							minus: i
						}
					}]
				};
			}
			return t.evalStep = 0, t.focusRid = null, t.beatMs = H.eval, {
				state: t,
				fx: []
			};
		}
		let n = t.evalStep, r = n < 6 ? {
			kind: "color",
			c: w[n]
		} : {
			kind: "pattern",
			p: T[n - 6]
		}, i = {}, a = {};
		for (let e of t.players) {
			let n = W(t.gardens[e]), o = Me(n, r), s = 0;
			for (let e of o) s += e.reduce((e, t) => e + V(n.get(t).p), 0) + U(t.variant, e.length);
			i[e] = s, a[e] = o, t.scores[e] += s;
		}
		t.evalStep += 1, t.beatMs = H.eval;
		let o = [{
			kind: "eval",
			data: {
				step: n,
				sym: r.kind === "color" ? {
					kind: "color",
					c: r.c
				} : {
					kind: "pattern",
					p: r.p
				},
				gains: i,
				groups: a
			}
		}];
		return t.evalStep > 11 && (t.phase = "done", o.push({
			kind: "final",
			data: {}
		})), {
			state: t,
			fx: o
		};
	}
	if (e.phase !== "action" || e.players[e.turn] !== n.by) return Y("games.queensgarden.errNotYourTurn");
	let r = structuredClone(e), i = r.storage[n.by], a = r.gardens[n.by];
	if (t.type === "acquire") {
		let e = t.sel, { tiles: a, exps: o } = Ne(r.display, e);
		if (a.length === 0 && o.length === 0) return Y("games.queensgarden.errNoMatch");
		if (i.tiles.length + a.length > 12 || i.expansions.length + o.length > 2) return Y("games.queensgarden.errNotFit");
		let s = r.stackTopActive && a.some((e) => e.slot === 0), c = /* @__PURE__ */ new Map();
		for (let e of a) c.set(e.slot, [...c.get(e.slot) ?? [], e.idx]);
		for (let [e, t] of c) {
			let n = r.display[e];
			for (let e of t.sort((e, t) => t - e)) n.tiles.splice(e, 1);
		}
		for (let e of a) i.tiles.push(e.h);
		let l = [];
		for (let e of [...o].sort((e, t) => t - e)) l.push(r.display[e].exp), i.expansions.push(r.display[e].exp), r.display.splice(e, 1);
		if (s) {
			let e = r.display.shift();
			r.display.push(e), K(r);
		}
		for (let e of r.display) !e.faceUp && e.tiles.length === 0 && (e.faceUp = !0);
		return J(r), {
			state: r,
			fx: [{
				kind: "acquire",
				rid: n.by,
				data: {
					sel: e,
					tiles: a.map((e) => e.h),
					exps: l,
					moved: s
				}
			}]
		};
	}
	if (t.type === "placeTile") {
		let e = i.tiles[t.item];
		if (e === void 0 || e === "joker") return Y("games.queensgarden.errBadItem");
		if (t.pay.tiles.length + t.pay.expansions.length !== V(e.p) || !t.pay.tiles.includes(t.item)) return Y("games.queensgarden.errBadPay");
		let o = De(i, t.pay);
		if (!o || !Ee([...o.tiles.map((e) => e === "joker" ? null : e), ...o.exps.map((e) => R(e))])) return Y("games.queensgarden.errBadPay");
		if (!Se(a, t.cell, e)) return Y("games.queensgarden.errBadCell");
		Oe(r, i, t.pay, t.item, null), a.cells[t.cell] = e;
		let s = q(r, n.by);
		return J(r), {
			state: r,
			fx: [{
				kind: "place",
				rid: n.by,
				data: {
					cell: t.cell,
					hex: e,
					pay: t.pay,
					surrounded: s
				}
			}]
		};
	}
	if (t.type === "placeExpansion") {
		if (a.expansions.some((e) => e.recess === t.recess)) return Y("games.queensgarden.errBadRecess");
		if (t.source === "supply") {
			if (r.scores[n.by] < 6) return Y("games.queensgarden.errPoor");
			if (r.supply.length === 0) return Y("games.queensgarden.errBadSource");
			r.supply.pop(), r.scores[n.by] -= 6, a.expansions.push({
				recess: t.recess,
				rot: t.rot,
				side: "plain",
				exp: null
			});
			let e = q(r, n.by);
			return J(r), {
				state: r,
				fx: [{
					kind: "expand",
					rid: n.by,
					data: {
						recess: t.recess,
						rot: t.rot,
						side: "plain",
						surrounded: e
					}
				}]
			};
		}
		if (t.item === void 0) return Y("games.queensgarden.errBadItem");
		let e = i.expansions[t.item];
		if (e === void 0) return Y("games.queensgarden.errBadItem");
		let o = R(e);
		if (t.pay.tiles.length + t.pay.expansions.length !== V(o.p) || !t.pay.expansions.includes(t.item)) return Y("games.queensgarden.errBadPay");
		let s = De(i, t.pay);
		if (!s || !Ee([...s.tiles.map((e) => e === "joker" ? null : e), ...s.exps.map((e) => R(e))])) return Y("games.queensgarden.errBadPay");
		let c = I[t.recess].cells[1 + t.rot];
		if (!G(W(a), c, o)) return Y("games.queensgarden.errBadCell");
		Oe(r, i, t.pay, null, t.item), a.expansions.push({
			recess: t.recess,
			rot: t.rot,
			side: "pavilion",
			exp: e
		});
		let l = q(r, n.by);
		return J(r), {
			state: r,
			fx: [{
				kind: "expand",
				rid: n.by,
				data: {
					recess: t.recess,
					rot: t.rot,
					side: "pavilion",
					exp: e,
					pay: t.pay,
					surrounded: l
				}
			}]
		};
	}
	let o = De(i, t.discard);
	if (!o || o.tiles.some((e) => e === "joker")) return Y("games.queensgarden.errBadPay");
	let s = 0;
	for (let e of o.tiles) s += V(e.p);
	for (let e of o.exps) s += V(R(e).p);
	Oe(r, i, t.discard, null, null);
	let c = !1;
	return r.firstMarkerInDisplay && (r.firstMarkerInDisplay = !1, r.firstRid = n.by, s += 1, c = !0), r.scores[n.by] = Math.max(0, r.scores[n.by] - s), r.passed.push(n.by), r.passed.length === r.players.length ? ke(r) : J(r), {
		state: r,
		fx: [{
			kind: "pass",
			rid: n.by,
			data: {
				minus: s,
				tookFirst: c
			}
		}]
	};
}
function Fe(e) {
	return {
		public: {
			phase: e.phase,
			round: e.round,
			variant: e.variant,
			turn: e.phase === "action" ? e.players[e.turn] : null,
			passed: e.passed,
			firstRid: e.firstRid,
			firstMarkerInDisplay: e.firstMarkerInDisplay,
			display: e.display,
			stackTopActive: e.stackTopActive,
			stackCounts: [
				e.stacks[0].length,
				e.stacks[1].length,
				e.stacks[2].length,
				e.stacks[3].length
			],
			supplyCount: e.supply.length,
			bagCount: e.bag.length,
			towerCount: e.tower.length,
			focusRid: e.focusRid,
			evalStep: e.evalStep,
			players: e.players.map((t) => ({
				rid: t,
				score: e.scores[t],
				storage: e.storage[t].tiles,
				expansions: e.storage[t].expansions,
				garden: {
					cells: e.gardens[t].cells,
					expansions: e.gardens[t].expansions
				}
			}))
		},
		private: {}
	};
}
function Ie(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]), n = e.scores[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.scores[t] === n),
		ranking: t,
		scores: { ...e.scores }
	};
}
function Le(e) {
	return e.phase === "score" || e.phase === "final" ? e.beatMs : null;
}
var Re = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: z,
	schemas: {
		action: oe,
		publicView: M,
		privateView: N,
		config: j
	},
	setup: Te,
	reduce: Pe,
	viewFor: Fe,
	status: Ie,
	nextTickIn: Le
}, X = {
	ink: "#214539",
	jade: "#28664c",
	jadeDark: "#194c3c",
	gold: "#d4ac64",
	goldLight: "#f4db9e",
	cream: "#fbf7e9",
	grass: "#b4d3a1"
}, ze = {
	blue: "#378fbd",
	dpurple: "#55418a",
	violet: "#a377bf",
	yellow: "#e7b83d",
	lgreen: "#8fbc59",
	dgreen: "#197750"
}, Z = X;
function Q(e) {
	return Array.from({ length: 6 }, (t, n) => {
		let r = (90 - 60 * n) * Math.PI / 180;
		return `${(e * Math.cos(r)).toFixed(2)},${(e * Math.sin(r)).toFixed(2)}`;
	}).join(" ");
}
function Be({ pattern: e, scale: t = 1, color: n = "#fff8e5" }) {
	return /* @__PURE__ */ g("g", {
		transform: `scale(${t})`,
		fill: n,
		stroke: n,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			e === "tree" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", {
					d: "M 0 1 L 0 10 M -5 10 L 5 10",
					fill: "none",
					strokeWidth: "2.7"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "-5",
					cy: "-4",
					r: "4"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "5",
					cy: "-4",
					r: "4"
				}),
				/* @__PURE__ */ h("circle", {
					cy: "-8",
					r: "5"
				})
			] }),
			e === "bird" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", { d: "M -10 2 Q -3 -7 0 -1 Q 4 -7 10 2 Q 3 0 0 5 Q -4 0 -10 2 Z" }), /* @__PURE__ */ h("path", {
				d: "M 0 4 L 0 9",
				fill: "none",
				strokeWidth: "2.2"
			})] }),
			e === "butterflies" && /* @__PURE__ */ g(m, { children: [[-1, 1].map((e) => /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("circle", {
				cx: e * 5,
				cy: "-4",
				r: "3.5"
			}), /* @__PURE__ */ h("circle", {
				cx: e * 5,
				cy: "3",
				r: "2.8"
			})] }, e)), /* @__PURE__ */ h("path", {
				d: "M 0 -5 L 0 6 M -2 -6 L -5 -9 M 2 -6 L 5 -9",
				fill: "none",
				strokeWidth: "1.8"
			})] }),
			e === "flower" && /* @__PURE__ */ g(m, { children: [Array.from({ length: 6 }, (e, t) => {
				let n = t * Math.PI / 3;
				return /* @__PURE__ */ h("circle", {
					cx: Math.sin(n) * 6,
					cy: Math.cos(n) * 6,
					r: "3.7"
				}, t);
			}), /* @__PURE__ */ h("circle", {
				r: "3.2",
				fill: Z.jadeDark,
				stroke: "none"
			})] }),
			e === "branch" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", {
					d: "M -7 9 Q -2 0 6 -9",
					fill: "none",
					strokeWidth: "2.5"
				}),
				/* @__PURE__ */ h("ellipse", {
					cx: "-5",
					cy: "4",
					rx: "2.8",
					ry: "5",
					transform: "rotate(-35 -5 4)"
				}),
				/* @__PURE__ */ h("ellipse", {
					cx: "-1",
					cy: "0",
					rx: "2.8",
					ry: "5",
					transform: "rotate(45 -1 0)"
				}),
				/* @__PURE__ */ h("ellipse", {
					cx: "3",
					cy: "-4",
					rx: "2.8",
					ry: "5",
					transform: "rotate(-35 3 -4)"
				})
			] }),
			e === "swarm" && [
				[-6, -4],
				[5, -5],
				[-5, 5],
				[6, 5]
			].map(([e, t]) => /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("circle", {
				cx: e,
				cy: t,
				r: "2.4"
			}), /* @__PURE__ */ h("path", {
				d: `M ${e - 2} ${t - 3} Q ${e} ${t - 7} ${e + 2} ${t - 3}`,
				fill: "none",
				strokeWidth: "1.3"
			})] }, `${e}:${t}`))
		]
	});
}
function Ve({ pattern: e, px: t = 20 }) {
	return /* @__PURE__ */ h("svg", {
		width: t,
		height: t,
		viewBox: "-12 -12 24 24",
		"aria-hidden": !0,
		children: /* @__PURE__ */ h(Be, {
			pattern: e,
			scale: .9,
			color: Z.jadeDark
		})
	});
}
function He({ hex: e, size: t, ghost: n = !1 }) {
	return /* @__PURE__ */ g("g", {
		className: "qg-tile-art",
		opacity: n ? .65 : 1,
		children: [
			/* @__PURE__ */ h("polygon", {
				points: Q(t),
				transform: "translate(0 3)",
				fill: "#173629",
				opacity: "0.34"
			}),
			/* @__PURE__ */ h("polygon", {
				points: Q(t),
				transform: "translate(0 2)",
				fill: "#d4c9a6",
				stroke: Z.ink,
				strokeWidth: "1.4",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ h("polygon", {
				points: Q(t),
				fill: ze[e.c],
				stroke: Z.ink,
				strokeWidth: "1.5",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ h("polygon", {
				points: Q(t * .78),
				transform: "translate(0 -1)",
				fill: "none",
				stroke: "#fff8df",
				strokeWidth: "1.05",
				opacity: "0.64"
			}),
			/* @__PURE__ */ h("path", {
				d: `M ${(-t * .44).toFixed(1)} ${(-t * .31).toFixed(1)} Q ${(-t * .16).toFixed(1)} ${(-t * .58).toFixed(1)} ${(t * .19).toFixed(1)} ${(-t * .49).toFixed(1)}`,
				fill: "none",
				stroke: "#fff",
				strokeWidth: Math.max(1.1, t * .105),
				opacity: "0.38",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ h(Be, {
				pattern: e.p,
				scale: t / 17 * .8
			})
		]
	});
}
function Ue({ size: e }) {
	return /* @__PURE__ */ g("g", { children: [
		/* @__PURE__ */ h("polygon", {
			points: Q(e),
			transform: "translate(0 3)",
			fill: "#d5c8ab",
			stroke: Z.ink,
			strokeWidth: "1.4"
		}),
		/* @__PURE__ */ h("polygon", {
			points: Q(e),
			fill: Z.cream,
			stroke: Z.ink,
			strokeWidth: "1.5"
		}),
		[
			"blue",
			"violet",
			"yellow",
			"lgreen",
			"dgreen",
			"dpurple"
		].map((t, n) => {
			let r = n * Math.PI / 3;
			return /* @__PURE__ */ h("circle", {
				cx: Math.sin(r) * e * .47,
				cy: Math.cos(r) * e * .47,
				r: e * .18,
				fill: ze[t]
			}, t);
		}),
		/* @__PURE__ */ h("circle", {
			r: e * .17,
			fill: Z.gold
		})
	] });
}
function We({ size: e, inner: t = "#d6e3bd", strong: n = !1, highlight: r = !1 }) {
	return /* @__PURE__ */ g("g", { children: [
		r && /* @__PURE__ */ h("polygon", {
			points: Q(e * 1.13),
			fill: Z.goldLight,
			stroke: Z.jadeDark,
			strokeWidth: "2.5",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ h("polygon", {
			points: Q(e),
			transform: "translate(0 2)",
			fill: "#67876c",
			opacity: "0.42"
		}),
		/* @__PURE__ */ h("polygon", {
			points: Q(e),
			fill: "#fdf8e9",
			stroke: n ? "#55785c" : "#94aa82",
			strokeWidth: n ? 1.7 : 1.2,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ h("polygon", {
			points: Q(e * .8),
			fill: t,
			stroke: "#fffdf0",
			strokeWidth: "1.5",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ h("path", {
			d: `M ${-e * .35} ${e * .16} L ${e * .34} ${-e * .19}`,
			fill: "none",
			stroke: "#7da06f",
			strokeWidth: "1.3",
			opacity: "0.26"
		})
	] });
}
function Ge({ kind: e, scale: t = 1, rewarded: n = !1 }) {
	return /* @__PURE__ */ g("g", {
		transform: `scale(${t})`,
		children: [
			n && /* @__PURE__ */ h("circle", {
				r: "19",
				fill: "#f7df9d",
				stroke: Z.gold,
				strokeWidth: "2",
				opacity: "0.9"
			}),
			/* @__PURE__ */ h("circle", {
				cy: "3",
				r: "13",
				fill: Z.jadeDark,
				opacity: "0.2"
			}),
			e === "fountain" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("circle", {
					r: "15",
					fill: "#f5ecd5",
					stroke: Z.ink,
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ h("circle", {
					r: "11.8",
					fill: "#63b9c6",
					stroke: "#e1d3a6",
					strokeWidth: "2.4"
				}),
				/* @__PURE__ */ h("circle", {
					r: "6.5",
					fill: "#b5e7e6",
					stroke: "#fff8e1",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ h("circle", {
					cy: "-2",
					r: "2.2",
					fill: "#fff"
				}),
				[
					0,
					90,
					180,
					270
				].map((e) => /* @__PURE__ */ h("circle", {
					cx: Math.sin(e * Math.PI / 180) * 10,
					cy: Math.cos(e * Math.PI / 180) * 10,
					r: "1.5",
					fill: "#fff8e1"
				}, e))
			] }),
			e === "statue" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("rect", {
					x: "-9",
					y: "-9",
					width: "18",
					height: "18",
					rx: "3",
					fill: "#e8dfc7",
					stroke: Z.ink,
					strokeWidth: "1.3"
				}),
				/* @__PURE__ */ h("circle", {
					cy: "-2",
					r: "5.2",
					fill: "#fdf8e9",
					stroke: "#bca56f",
					strokeWidth: "1.3"
				}),
				/* @__PURE__ */ h("path", {
					d: "M -5 7 Q 0 1 5 7 Z",
					fill: "#b8b099",
					stroke: "#bca56f"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "-5",
					cy: "-8",
					r: "1.1",
					fill: Z.gold
				}),
				/* @__PURE__ */ h("circle", {
					cx: "5",
					cy: "-8",
					r: "1.1",
					fill: Z.gold
				})
			] }),
			e === "bench" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("rect", {
					x: "-12",
					y: "-8",
					width: "24",
					height: "16",
					rx: "2",
					fill: "#785745",
					stroke: Z.ink,
					strokeWidth: "1.2"
				}),
				[
					-4,
					0,
					4
				].map((e) => /* @__PURE__ */ h("path", {
					d: `M -9 ${e} L 9 ${e}`,
					stroke: "#f1d6a5",
					strokeWidth: "1.8"
				}, e)),
				/* @__PURE__ */ h("rect", {
					x: "-13",
					y: "-10",
					width: "3",
					height: "20",
					rx: "1",
					fill: Z.gold,
					stroke: Z.ink,
					strokeWidth: "0.8"
				}),
				/* @__PURE__ */ h("rect", {
					x: "10",
					y: "-10",
					width: "3",
					height: "20",
					rx: "1",
					fill: Z.gold,
					stroke: Z.ink,
					strokeWidth: "0.8"
				})
			] }),
			e === "pavilion" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("circle", {
					r: "13",
					fill: "#f9ebcb",
					stroke: Z.ink,
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ h("polygon", {
					points: Q(10),
					transform: "translate(0 -2)",
					fill: Z.gold,
					stroke: Z.ink
				}),
				/* @__PURE__ */ h("circle", {
					cy: "-2",
					r: "4",
					fill: "#fff7e2",
					stroke: Z.ink
				}),
				[
					0,
					90,
					180,
					270
				].map((e) => /* @__PURE__ */ h("circle", {
					cx: Math.sin(e * Math.PI / 180) * 10,
					cy: Math.cos(e * Math.PI / 180) * 10,
					r: "1.6",
					fill: Z.jade
				}, e))
			] })
		]
	});
}
function Ke() {
	return /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("path", {
		d: "M -9 5 Q 0 -8 10 6",
		fill: "none",
		stroke: "#327758",
		strokeWidth: "2"
	}), [
		[
			-6,
			-2,
			"#fae4c4"
		],
		[
			0,
			-5,
			"#d47e8c"
		],
		[
			5,
			0,
			"#f6d38d"
		]
	].map(([e, t, n]) => /* @__PURE__ */ g("g", {
		transform: `translate(${e},${t})`,
		children: [Array.from({ length: 5 }, (e, t) => {
			let r = t * Math.PI * 2 / 5;
			return /* @__PURE__ */ h("circle", {
				cx: Math.sin(r) * 3.2,
				cy: Math.cos(r) * 3.2,
				r: "2.2",
				fill: n
			}, t);
		}), /* @__PURE__ */ h("circle", {
			r: "1.5",
			fill: Z.gold
		})]
	}, `${e}:${t}`))] });
}
function qe() {
	return /* @__PURE__ */ g("g", {
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ h("rect", {
				x: "-350",
				y: "-318",
				width: "700",
				height: "636",
				rx: "22",
				fill: "#d9e8c0",
				stroke: Z.gold,
				strokeWidth: "8"
			}),
			/* @__PURE__ */ h("rect", {
				x: "-338",
				y: "-306",
				width: "676",
				height: "612",
				rx: "16",
				fill: "none",
				stroke: "#70986e",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ h("circle", {
				r: "287",
				fill: "#bad5a5",
				opacity: "0.48"
			}),
			/* @__PURE__ */ h("circle", {
				r: "228",
				fill: "#e2eacb",
				opacity: "0.54"
			}),
			Array.from({ length: 28 }, (e, t) => {
				let n = -320 + t * 24;
				return /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("circle", {
					cx: n,
					cy: "-294",
					r: "2.2",
					fill: Z.jade,
					opacity: "0.65"
				}), /* @__PURE__ */ h("circle", {
					cx: n,
					cy: "294",
					r: "2.2",
					fill: Z.jade,
					opacity: "0.65"
				})] }, t);
			}),
			/* @__PURE__ */ h("path", {
				d: "M -305 -284 Q 0 -268 305 -284 M -305 284 Q 0 268 305 284",
				fill: "none",
				stroke: "#7b9f75",
				strokeWidth: "3",
				opacity: "0.56"
			}),
			[
				[-315, -280],
				[315, -280],
				[-315, 280],
				[315, 280]
			].map(([e, t]) => /* @__PURE__ */ h("g", {
				transform: `translate(${e},${t}) scale(.8)`,
				children: /* @__PURE__ */ h(Ke, {})
			}, `${e}:${t}`))
		]
	});
}
function Je({ colors: e }) {
	return /* @__PURE__ */ g("svg", {
		viewBox: "-30 -30 60 60",
		"aria-hidden": !0,
		className: "qg-wheel-art",
		children: [
			/* @__PURE__ */ h("circle", {
				cy: "3",
				r: "28",
				fill: "#604b38",
				opacity: "0.28"
			}),
			/* @__PURE__ */ h("circle", {
				r: "27",
				fill: "#ddbc75",
				stroke: Z.ink,
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ h("circle", {
				r: "22",
				fill: "#f6e9c7",
				stroke: Z.gold,
				strokeWidth: "1.4"
			}),
			e.slice(0, 3).map((e, t) => {
				let n = (90 + t * 120) * Math.PI / 180;
				return /* @__PURE__ */ h("circle", {
					cx: Math.cos(n) * 15,
					cy: Math.sin(n) * 15,
					r: "6.5",
					fill: ze[e],
					stroke: Z.ink
				}, t);
			}),
			/* @__PURE__ */ h("circle", {
				r: "4",
				fill: Z.jadeDark
			})
		]
	});
}
var Ye = Math.sqrt(3);
function $(e) {
	let [t, n] = de(e);
	return [Ye * (t + n / 2) * 40, 1.5 * n * 40];
}
function Xe({ hex: e, size: t, ghost: n }) {
	return /* @__PURE__ */ h(He, {
		hex: e,
		size: t,
		ghost: n
	});
}
function Ze({ size: e }) {
	return /* @__PURE__ */ h(Ue, { size: e });
}
function Qe({ hex: e, px: t, ghost: n }) {
	let r = t / 2;
	return /* @__PURE__ */ h("svg", {
		viewBox: `${-r} ${-r} ${t} ${t}`,
		width: t,
		height: t,
		"aria-hidden": !0,
		children: /* @__PURE__ */ h(Xe, {
			hex: e,
			size: r * .92,
			ghost: n
		})
	});
}
function $e({ px: e }) {
	let t = e / 2;
	return /* @__PURE__ */ h("svg", {
		viewBox: `${-t} ${-t} ${e} ${e}`,
		width: e,
		height: e,
		"aria-hidden": !0,
		children: /* @__PURE__ */ h(Ze, { size: t * .92 })
	});
}
var et = [
	"0,0",
	...fe,
	...F.keys(),
	...I.flatMap((e) => e.cells),
	...me
];
function tt(e) {
	if (e.w === 0) return {
		cx: 0,
		cy: 0,
		s: 1
	};
	let t = et.map($), n = t.map((e) => e[0]), r = t.map((e) => e[1]), i = Math.min(Math.min(...n) - 52, e.large ? -354 : Infinity), a = Math.max(Math.max(...n) + 52, e.large ? 354 : -Infinity), o = Math.min(Math.min(...r) - 52, e.large ? -322 : Infinity), s = Math.max(Math.max(...r) + 52, e.large ? 322 : -Infinity), c = e.large ? 12 : 0, l = Math.min((e.w - c) / (a - i), (e.h - c) / (s - o), e.large ? 2.2 : 1.2);
	return {
		cx: (i + a) / 2,
		cy: (o + s) / 2,
		s: l
	};
}
function nt({ rid: e, garden: t, spots: n, ghost: s, recessSpots: c, ghostExp: l, evalHighlight: d, onTapCell: f, onTapRecess: ee }) {
	let p = u(), te = a(null), [m, _] = o({
		w: 0,
		h: 0,
		large: !1
	}), [v, y] = o(null), b = a({
		cx: 0,
		cy: 0,
		s: 1
	});
	r(() => {
		let e = te.current, t = new ResizeObserver(() => _({
			w: e.clientWidth,
			h: e.clientHeight,
			large: getComputedStyle(e).getPropertyValue("--qg-large").trim() === "1"
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let ne = `${e}:${m.w}:${m.h}:${m.large}`, [x, re] = o("");
	x !== ne && m.w > 0 && (re(ne), y(tt(m)));
	let S = v ?? tt(m);
	r(() => {
		b.current = S;
	}), r(() => {
		let e = te.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = b.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = Math.min(Math.max(r.s * i, .35), 3), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			b.current = u, y(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, []);
	let C = a(/* @__PURE__ */ new Map()), w = a(0), T = a(0), E = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), C.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), C.current.size === 1 && (w.current = 0), C.current.size === 2) {
			let [e, t] = [...C.current.values()];
			T.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, ie = (e) => {
		let t = C.current.get(e.pointerId);
		if (!t) return;
		let n = te.current.getBoundingClientRect();
		if (C.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			w.current += Math.abs(n) + Math.abs(r);
			let i = b.current, a = {
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			};
			b.current = a, y(a);
		} else if (C.current.size === 2) {
			C.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...C.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (T.current > 0 && i > 0) {
				let e = b.current, a = Math.min(Math.max(e.s * i / T.current, .35), 3), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				b.current = u, y(u);
			}
			T.current = i, w.current = 99;
			return;
		}
		C.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, D = (e) => {
		let t = C.current.size === 1 && w.current < 10;
		if (C.current.delete(e.pointerId), T.current = 0, !t) return;
		let r = te.current.getBoundingClientRect(), i = b.current, a = i.cx + (e.clientX - r.left - r.width / 2) / i.s, o = i.cy + (e.clientY - r.top - r.height / 2) / i.s;
		if (ee && c) {
			let e = null, t = Math.max(88, 22 / i.s);
			for (let n of c) {
				let [r, i] = $(I[n].center), s = Math.hypot(r - a, i - o);
				s < t && (t = s, e = n);
			}
			e !== null && ee(e);
			return;
		}
		if (!f) return;
		let s = n ? [...n] : [], l = null, u = Math.max(38, 22 / i.s);
		for (let e of s) {
			let [t, n] = $(e), r = Math.hypot(t - a, n - o);
			r < u && (u = r, l = e);
		}
		l && f(l);
	}, ae = i(() => new Map(t.expansions.map((e) => [e.recess, e])), [t.expansions]), O = i(() => W(t), [t]), k = (e) => P(e).every((e) => O.has(e)), A = (e) => {
		let t = b.current, n = {
			...t,
			s: Math.min(Math.max(t.s * e, .35), 3)
		};
		b.current = n, y(n);
	};
	return /* @__PURE__ */ g("div", {
		ref: te,
		className: "qg-board-viewport",
		children: [
			/* @__PURE__ */ h("svg", {
				className: "qg-board-svg",
				role: "img",
				"aria-label": p("games.queensgarden.gardenTitle"),
				onPointerDown: E,
				onPointerMove: ie,
				onPointerUp: D,
				onPointerCancel: D,
				children: /* @__PURE__ */ g("g", {
					transform: `translate(${m.w / 2 - S.cx * S.s}, ${m.h / 2 - S.cy * S.s}) scale(${S.s})`,
					children: [
						/* @__PURE__ */ h(qe, {}),
						me.map((e) => {
							let [t, n] = $(e);
							return /* @__PURE__ */ h("g", {
								transform: `translate(${t},${n}) scale(1.3)`,
								children: /* @__PURE__ */ h(Ke, {})
							}, `fb${e}`);
						}),
						I.map((e) => {
							if (ae.has(e.id)) return null;
							let t = c?.has(e.id);
							return /* @__PURE__ */ g("g", { children: [e.cells.map((e, n) => {
								let [r, i] = $(e);
								return /* @__PURE__ */ h("g", {
									transform: `translate(${r}, ${i})`,
									children: /* @__PURE__ */ h(We, {
										size: 40 * .94,
										inner: n === 0 ? "#e4e9ca" : "#d5e3bd",
										highlight: t
									})
								}, e);
							}), /* @__PURE__ */ g("g", {
								transform: `translate(${$(e.center)[0]}, ${$(e.center)[1]})`,
								children: [
									/* @__PURE__ */ h("circle", {
										r: "17",
										fill: "#e6d8b7",
										stroke: X.gold,
										strokeWidth: "2"
									}),
									/* @__PURE__ */ h("circle", {
										r: "9",
										fill: "#fdf7e4",
										stroke: X.gold,
										strokeWidth: "1.5"
									}),
									/* @__PURE__ */ h("path", {
										d: "M -6 0 H 6 M 0 -6 V 6",
										stroke: X.jade,
										strokeWidth: "2.5"
									})
								]
							})] }, `rc${e.id}`);
						}),
						fe.map((e) => {
							if (t.cells[e]) return null;
							let [n, r] = $(e);
							return /* @__PURE__ */ h("g", {
								transform: `translate(${n}, ${r})`,
								children: /* @__PURE__ */ h(We, {
									size: 40 * .94,
									inner: "#f4efd9",
									strong: !0
								})
							}, `ring${e}`);
						}),
						t.expansions.map((e, n) => {
							let r = I[e.recess], i = ge(e), a = new Set(he(e));
							return /* @__PURE__ */ g("g", { children: [
								r.cells.map((e) => {
									if (!a.has(e) || t.cells[e]) return null;
									let [n, r] = $(e);
									return /* @__PURE__ */ h("g", {
										transform: `translate(${n}, ${r})`,
										children: /* @__PURE__ */ h(We, {
											size: 40 * .94,
											strong: !0
										})
									}, e);
								}),
								e.side === "pavilion" && /* @__PURE__ */ h("g", {
									transform: `translate(${$(r.center)[0]}, ${$(r.center)[1]})`,
									children: /* @__PURE__ */ h(Ge, {
										kind: "pavilion",
										rewarded: k(r.center),
										scale: 1.3
									})
								}),
								i !== null && e.exp !== null && /* @__PURE__ */ g("g", {
									transform: `translate(${$(i)[0]}, ${$(i)[1]})`,
									opacity: .92,
									children: [d?.has(i) && /* @__PURE__ */ h("polygon", {
										points: Q(40 * 1.07),
										fill: X.goldLight,
										stroke: X.jadeDark,
										strokeWidth: "4"
									}), /* @__PURE__ */ h(Xe, {
										hex: R(e.exp),
										size: 40 * .92
									})]
								})
							] }, `exp${n}`);
						}),
						/* @__PURE__ */ h("circle", {
							r: 35.2,
							fill: "#f2e6c9",
							stroke: X.gold,
							strokeWidth: "4"
						}),
						/* @__PURE__ */ h(Ge, {
							kind: "fountain",
							rewarded: k("0,0"),
							scale: 1.42
						}),
						[...F.entries()].map(([e, t]) => {
							let [n, r] = $(e);
							return /* @__PURE__ */ g("g", {
								transform: `translate(${n}, ${r})`,
								children: [/* @__PURE__ */ h(We, {
									size: 40 * .94,
									inner: "#f4ead0"
								}), /* @__PURE__ */ h(Ge, {
									kind: t,
									rewarded: k(e),
									scale: 1.15
								})]
							}, `el${e}`);
						}),
						Object.entries(t.cells).map(([e, t]) => {
							let [n, r] = $(e);
							return /* @__PURE__ */ g("g", {
								transform: `translate(${n}, ${r})`,
								children: [d?.has(e) && /* @__PURE__ */ h("polygon", {
									points: Q(40 * 1.07),
									fill: X.goldLight,
									stroke: X.jadeDark,
									strokeWidth: "4",
									strokeLinejoin: "round"
								}), /* @__PURE__ */ h(Xe, {
									hex: t,
									size: 40 * .92
								})]
							}, `t${e}`);
						}),
						n && [...n].map((e) => {
							if (t.cells[e]) return null;
							let [n, r] = $(e);
							return /* @__PURE__ */ g("g", {
								transform: `translate(${n}, ${r})`,
								children: [/* @__PURE__ */ h(We, {
									size: 38.4,
									inner: "#fff8dc",
									highlight: !0
								}), /* @__PURE__ */ h("circle", {
									r: "7",
									fill: X.jade
								})]
							}, `sp${e}`);
						}),
						s && (() => {
							let [e, t] = $(s.cell);
							return /* @__PURE__ */ h("g", {
								transform: `translate(${e}, ${t})`,
								children: /* @__PURE__ */ h(Xe, {
									hex: s.hex,
									size: 40 * .92,
									ghost: !0
								})
							});
						})(),
						l && (() => {
							let e = I[l.recess], t = e.cells[1 + l.rot];
							return /* @__PURE__ */ g("g", {
								opacity: .6,
								children: [e.cells.map((e) => {
									let [t, n] = $(e);
									return /* @__PURE__ */ h("g", {
										transform: `translate(${t}, ${n})`,
										children: /* @__PURE__ */ h(We, {
											size: 40 * .94,
											inner: "#fff8dc",
											highlight: !0
										})
									}, `ge${e}`);
								}), l.print && /* @__PURE__ */ h("g", {
									transform: `translate(${$(t)[0]}, ${$(t)[1]})`,
									children: /* @__PURE__ */ h(Xe, {
										hex: l.print,
										size: 40 * .92,
										ghost: !0
									})
								})]
							});
						})()
					]
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "qg-board-title",
				"aria-hidden": !0,
				children: p("games.queensgarden.gardenTitle")
			}),
			/* @__PURE__ */ g("div", {
				className: "qg-board-zoom",
				children: [/* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => A(1.2),
					"aria-label": p("games.queensgarden.zoomIn"),
					children: "+"
				}), /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => A(1 / 1.2),
					"aria-label": p("games.queensgarden.zoomOut"),
					children: "−"
				})]
			})
		]
	});
}
//#endregion
//#region src/games/queensgarden/view-player.tsx
var rt = {
	blue: "games.queensgarden.colorBlue",
	dpurple: "games.queensgarden.colorDpurple",
	violet: "games.queensgarden.colorViolet",
	yellow: "games.queensgarden.colorYellow",
	lgreen: "games.queensgarden.colorLgreen",
	dgreen: "games.queensgarden.colorDgreen"
}, it = {
	tree: "games.queensgarden.patternTree",
	bird: "games.queensgarden.patternBird",
	butterflies: "games.queensgarden.patternButterflies",
	flower: "games.queensgarden.patternFlower",
	branch: "games.queensgarden.patternBranch",
	swarm: "games.queensgarden.patternSwarm"
};
function at(e) {
	let t = e.public;
	return /* @__PURE__ */ h(ot, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ot({ pub: e, members: t, myRid: n, send: r }) {
	let a = u(), s = (e) => t.find((t) => t.rid === e)?.name ?? e, l = e.players.find((e) => e.rid === n), [p, _] = o(n), [v, y] = o(null), [b, ne] = o(!1), [x, re] = o(null), [S, C] = o(null), [E, ie] = o({
		tiles: [],
		exps: []
	}), [D, ae] = o(null), [O, k] = o(null), [A, oe] = o(!1), [j, se] = o({
		tiles: [],
		exps: []
	}), ce = e.phase === "action" && e.turn === n, M = ce && p === n && !!l, N = () => {
		y(null), ne(!1), re(null), C(null), ie({
			tiles: [],
			exps: []
		}), ae(null), k(null), oe(!1), se({
			tiles: [],
			exps: []
		});
	}, le = `${e.phase}|${e.turn}|${e.round}|${p}`, [ue, de] = o(le);
	ue !== le && (de(le), N());
	let [P, fe] = o(null);
	(e.phase === "score" || e.phase === "final") && e.focusRid && e.focusRid !== P && (fe(e.focusRid), _(e.focusRid)), e.phase === "action" && P !== null && (fe(null), _(n));
	let F = e.players.find((e) => e.rid === p) ?? l, pe = be(e.variant, e.round), me = i(() => {
		if (!F || e.phase !== "score" && e.phase !== "final") return;
		let t = W(F.garden);
		if (e.phase === "score") return new Set([...t.entries()].filter(([, e]) => pe.some((t) => t.kind === "color" ? t.c === e.c : t.p === e.p)).map(([e]) => e));
		if (e.evalStep < 0) return;
		let n = e.evalStep < w.length ? {
			kind: "color",
			c: w[e.evalStep]
		} : {
			kind: "pattern",
			p: T[e.evalStep - w.length]
		};
		return new Set(Me(t, n).flat());
	}, [
		F,
		e.phase,
		e.evalStep,
		pe
	]), L = i(() => v && l ? Ne(e.display, v) : null, [
		v,
		l,
		e.display
	]), he = !!l && !!L && l.storage.length + L.tiles.length <= 12 && l.expansions.length + L.exps.length <= 2, ge = l && x !== null ? l.storage[x] : void 0, B = ge && ge !== "joker" ? ge : null, _e = i(() => {
		if (!M || !l || !B) return;
		let e = W(l.garden);
		return new Set([...xe(l.garden)].filter((t) => G(e, t, B)));
	}, [
		M,
		l,
		B
	]), H = B ? V(B.p) : 0, ve = i(() => {
		if (!M || !l || D === null) return;
		let e = new Set(l.garden.expansions.map((e) => e.recess));
		return new Set(I.map((e) => e.id).filter((t) => !e.has(t)));
	}, [
		M,
		l,
		D
	]), ye = l && typeof D == "number" ? l.expansions[D] : void 0, U = ye === void 0 ? null : R(ye), Se = U ? V(U.p) : 0, Ce = !!l && !!U && !!O && G(W(l.garden), I[O.area].cells[1 + O.rot], U), we = !!l && l.score >= 6 && e.supplyCount > 0 && l.garden.expansions.length < I.length, K = x !== null && S ? B : D !== null && D !== "buy" && O ? U : null, Te = x === null ? Se : H, De = !!l && E.tiles.every((e) => e >= 0 && e < l.storage.length) && E.exps.every((e) => e >= 0 && e < l.expansions.length), Oe = K && l ? [
		K,
		...E.tiles.map((e) => l.storage[e]).map((e) => e === "joker" || e === void 0 ? null : e),
		...E.exps.map((e) => l.expansions[e] === void 0 ? null : R(l.expansions[e]))
	] : [], q = K ? Oe.length : 0, J = !!K && De && q === Te && Ee(Oe), ke = (e) => !!K && q < Te && Ee([...Oe, e]), Ae = () => {
		v && L && (L.tiles.length !== 0 || L.exps.length !== 0) && he && (r({
			type: "acquire",
			sel: v
		}), N());
	}, je = () => {
		x !== null && S && B && J && (r({
			type: "placeTile",
			item: x,
			pay: {
				tiles: [x, ...E.tiles],
				expansions: E.exps
			},
			cell: S
		}), N());
	}, Y = () => {
		if (D !== null && O) {
			if (D === "buy") r({
				type: "placeExpansion",
				source: "supply",
				recess: O.area,
				rot: O.rot,
				pay: {
					tiles: [],
					expansions: []
				}
			});
			else {
				if (!Ce || !J) return;
				r({
					type: "placeExpansion",
					source: "storage",
					item: D,
					recess: O.area,
					rot: O.rot,
					pay: {
						tiles: E.tiles,
						expansions: [D, ...E.exps]
					}
				});
			}
			N();
		}
	}, Pe = () => {
		r({
			type: "pass",
			discard: {
				tiles: j.tiles,
				expansions: j.exps
			}
		}), N();
	}, Fe = (e) => {
		if (M && l) {
			if (A) {
				if (l.storage[e] === "joker") return;
				se((t) => ({
					...t,
					tiles: t.tiles.includes(e) ? t.tiles.filter((t) => t !== e) : [...t.tiles, e]
				}));
				return;
			}
			if (x !== null && S !== null) {
				if (e === x || !E.tiles.includes(e) && !ke(l.storage[e] === "joker" ? null : l.storage[e])) return;
				ie((t) => ({
					...t,
					tiles: t.tiles.includes(e) ? t.tiles.filter((t) => t !== e) : [...t.tiles, e]
				}));
				return;
			}
			if (D !== null && D !== "buy" && O) {
				if (!E.tiles.includes(e) && !ke(l.storage[e] === "joker" ? null : l.storage[e])) return;
				ie((t) => ({
					...t,
					tiles: t.tiles.includes(e) ? t.tiles.filter((t) => t !== e) : [...t.tiles, e]
				}));
				return;
			}
			l.storage[e] !== "joker" && (N(), re(e));
		}
	}, Ie = (e) => {
		if (M && l) {
			if (A) {
				se((t) => ({
					...t,
					exps: t.exps.includes(e) ? t.exps.filter((t) => t !== e) : [...t.exps, e]
				}));
				return;
			}
			if (x !== null && S !== null) {
				if (!E.exps.includes(e) && !ke(R(l.expansions[e]))) return;
				ie((t) => ({
					...t,
					exps: t.exps.includes(e) ? t.exps.filter((t) => t !== e) : [...t.exps, e]
				}));
				return;
			}
			if (D !== null && D !== "buy" && O) {
				if (e === D || !E.exps.includes(e) && !ke(R(l.expansions[e]))) return;
				ie((t) => ({
					...t,
					exps: t.exps.includes(e) ? t.exps.filter((t) => t !== e) : [...t.exps, e]
				}));
				return;
			}
			N(), ae(e);
		}
	}, Le = "info", Re, X = "";
	e.phase === "score" ? (Re = a("games.queensgarden.scoring"), X = e.focusRid ? s(e.focusRid) : "") : e.phase === "final" ? (Re = e.evalStep < 0 ? a("games.queensgarden.finalSettle") : a("games.queensgarden.finalEval"), X = e.focusRid ? s(e.focusRid) : "") : ce ? (Le = "accent", Re = b ? a("games.queensgarden.pickSymbol") : x === null ? D === null ? a(A ? "games.queensgarden.passHint" : "games.queensgarden.turnYou") : O ? D === "buy" ? a("games.queensgarden.expandBuyConfirmHint") : a("games.queensgarden.payHint", { cost: Se }) : a("games.queensgarden.pickRecess") : S ? a("games.queensgarden.payHint", { cost: H }) : a("games.queensgarden.placeTileHint")) : Re = e.turn ? a("games.queensgarden.turnWait", { name: s(e.turn) }) : "";
	let ze = l ? j.tiles.reduce((e, t) => {
		let n = l.storage[t];
		return e + (n && n !== "joker" ? V(n.p) : 0);
	}, 0) + j.exps.reduce((e, t) => e + V(R(l.expansions[t]).p), 0) + +!!e.firstMarkerInDisplay : 0;
	return /* @__PURE__ */ h(te, {
		adaptive: !0,
		scroll: !1,
		className: "qg-screen",
		children: /* @__PURE__ */ g("div", {
			className: "qg-shell",
			children: [
				/* @__PURE__ */ h("div", {
					className: "qg-banner",
					children: /* @__PURE__ */ h(f, {
						tone: Le,
						text: Re,
						sub: X,
						chip: a("games.queensgarden.roundShort", { n: e.round }),
						accent: z.accent
					})
				}),
				/* @__PURE__ */ h("div", {
					className: "qg-players",
					children: /* @__PURE__ */ h(ee, {
						adaptive: !0,
						variant: "plate",
						members: t.filter((t) => e.players.some((e) => e.rid === t.rid)),
						myRid: n,
						anchorOf: (e) => `seat:${e}`,
						action: (t) => e.phase === "action" && t === e.turn ? "pending" : e.passed.includes(t) ? "done" : null,
						onPick: (e) => _(e),
						picked: (e) => p === e,
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ g("span", {
								className: "qg-player-status flex items-center gap-1.5 text-xs leading-4.5 font-bold",
								children: [
									/* @__PURE__ */ g("span", {
										className: "qg-score-amount flex items-center gap-0.5 font-mono text-sm tabular-nums",
										children: [
											/* @__PURE__ */ h(c, { value: n.score }),
											" ",
											a("games.queensgarden.pointsShort")
										]
									}),
									/* @__PURE__ */ h("span", {
										className: "qg-stock-amount font-mono tabular-nums",
										children: a("games.queensgarden.stripStorage", { n: n.storage.length })
									}),
									e.firstRid === t && !e.firstMarkerInDisplay && /* @__PURE__ */ h("span", {
										role: "img",
										"aria-label": a("games.queensgarden.markerAria"),
										children: "⚑"
									})
								]
							}) : null;
						}
					})
				}),
				/* @__PURE__ */ g("div", {
					className: "qg-board-frame",
					children: [F && /* @__PURE__ */ h(nt, {
						rid: F.rid,
						garden: F.garden,
						evalHighlight: me,
						spots: M && x !== null && S === null ? _e : void 0,
						ghost: M && B && S ? {
							cell: S,
							hex: B
						} : null,
						recessSpots: M && D !== null && O === null ? ve : void 0,
						ghostExp: M && D !== null && O ? {
							recess: O.area,
							rot: O.rot,
							print: D === "buy" ? null : U
						} : null,
						onTapCell: M && x !== null && S === null ? (e) => C(e) : void 0,
						onTapRecess: M && D !== null && O === null ? (e) => k({
							area: e,
							rot: 0
						}) : void 0
					}), b && l && /* @__PURE__ */ g("div", {
						className: "qg-symbol-panel",
						children: [/* @__PURE__ */ h("div", {
							className: "qg-symbol-row",
							children: w.map((e) => /* @__PURE__ */ h(st, {
								value: {
									kind: "color",
									key: e
								},
								sel: v,
								onPick: y
							}, e))
						}), /* @__PURE__ */ h("div", {
							className: "qg-symbol-row",
							children: T.map((e) => /* @__PURE__ */ h(st, {
								value: {
									kind: "pattern",
									key: e
								},
								sel: v,
								onPick: y
							}, e))
						})]
					})]
				}),
				/* @__PURE__ */ h(ct, {
					pub: e,
					syms: pe,
					acqPreview: L
				}),
				/* @__PURE__ */ h("div", {
					className: "qg-storage",
					children: F && /* @__PURE__ */ g("div", {
						className: "qg-storage-content",
						children: [/* @__PURE__ */ g("span", {
							className: "qg-storage-label",
							children: [/* @__PURE__ */ h("strong", { children: a("games.queensgarden.storageLabel") }), /* @__PURE__ */ g("small", {
								className: "font-mono tabular-nums",
								children: [
									F.storage.length,
									"/",
									12
								]
							})]
						}), /* @__PURE__ */ g("div", {
							className: "qg-storage-items",
							children: [
								F.storage.map((e, t) => {
									let n = A ? j.tiles.includes(t) : x !== null && S !== null ? t === x || E.tiles.includes(t) : D === null ? x === t : E.tiles.includes(t), r = x === t && S !== null, i = M && !r && !(A && e === "joker") && (!K || n || ke(e === "joker" ? null : e));
									return /* @__PURE__ */ h("button", {
										type: "button",
										"aria-label": e === "joker" ? a("games.queensgarden.jokerAria") : a("games.queensgarden.tileAria", {
											color: a(rt[e.c]),
											pattern: a(it[e.p])
										}),
										"aria-pressed": n,
										disabled: !i,
										onClick: () => Fe(t),
										className: `qg-storage-piece ${n ? "is-picked" : ""} ${r ? "is-locked" : ""}`,
										children: e === "joker" ? /* @__PURE__ */ h($e, { px: 34 }) : /* @__PURE__ */ h(Qe, {
											hex: e,
											px: 34
										})
									}, t);
								}),
								/* @__PURE__ */ h("span", {
									"aria-hidden": !0,
									className: "qg-storage-divider"
								}),
								F.expansions.map((e, t) => {
									let n = A ? j.exps.includes(t) : D === t || E.exps.includes(t), r = D === t && O !== null, i = M && !r && (!K || n || ke(R(e)));
									return /* @__PURE__ */ g("button", {
										type: "button",
										"aria-label": a("games.queensgarden.expAria", {
											pattern: a(it[R(e).p]),
											color: a(rt[R(e).c])
										}),
										"aria-pressed": n,
										disabled: !i,
										onClick: () => Ie(t),
										className: `qg-storage-piece qg-exp-piece ${n ? "is-picked" : ""} ${r ? "is-locked" : ""}`,
										children: [/* @__PURE__ */ h("svg", {
											viewBox: "-18 -18 36 36",
											width: "32",
											height: "32",
											"aria-hidden": !0,
											children: /* @__PURE__ */ h(Ge, {
												kind: "pavilion",
												scale: .68
											})
										}), /* @__PURE__ */ h(Qe, {
											hex: R(e),
											px: 21
										})]
									}, t);
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ g("div", {
					className: "qg-actions safe-b",
					children: [K && /* @__PURE__ */ g("div", {
						className: "qg-payment-progress",
						role: "status",
						children: [/* @__PURE__ */ h("span", { style: { width: `${Math.min(100, q / Te * 100)}%` } }), /* @__PURE__ */ h("strong", { children: a("games.queensgarden.paymentProgress", {
							n: q,
							cost: Te
						}) })]
					}), e.phase === "action" && ce ? b ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
						type: "button",
						onClick: N,
						className: "btn-quiet min-h-12 flex-none px-3 text-xs font-bold",
						children: a("games.queensgarden.cancel")
					}), /* @__PURE__ */ h("button", {
						type: "button",
						disabled: !v || !L || L.tiles.length === 0 && L.exps.length === 0 || !he,
						onClick: Ae,
						className: "btn-base min-h-12 flex-1 text-sm text-white",
						style: { background: z.accent },
						children: L && (L.tiles.length > 0 || L.exps.length > 0) ? he ? a("games.queensgarden.acquireConfirm", {
							tiles: L.tiles.length,
							exps: L.exps.length
						}) : a("games.queensgarden.acquireNoFit") : a("games.queensgarden.acquireEmpty")
					})] }) : A ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
						type: "button",
						onClick: N,
						className: "btn-quiet min-h-12 flex-none px-3 text-xs font-bold",
						children: a("games.queensgarden.cancel")
					}), /* @__PURE__ */ h("button", {
						type: "button",
						onClick: Pe,
						className: "btn-base min-h-12 flex-1 text-sm text-white",
						style: { background: z.accent },
						children: a("games.queensgarden.passConfirm", { n: ze })
					})] }) : x === null ? D === null ? /* @__PURE__ */ g(m, { children: [
						/* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => ne(!0),
							className: "btn-base min-h-12 flex-1 text-sm text-white",
							style: { background: z.accent },
							children: a("games.queensgarden.actAcquire")
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							disabled: !we,
							onClick: () => ae("buy"),
							className: "btn-quiet min-h-12 flex-none px-2.5 text-xs font-bold",
							children: a("games.queensgarden.actBuy", { n: 6 })
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => oe(!0),
							className: "btn-quiet min-h-12 flex-none px-3 text-xs font-bold",
							children: a("games.queensgarden.actPass")
						})
					] }) : /* @__PURE__ */ g(m, { children: [
						/* @__PURE__ */ h("button", {
							type: "button",
							onClick: N,
							className: "btn-quiet min-h-12 flex-none px-3 text-xs font-bold",
							children: a("games.queensgarden.cancel")
						}),
						D !== "buy" && O && /* @__PURE__ */ h("button", {
							type: "button",
							"aria-label": a("games.queensgarden.rotate"),
							onClick: () => k((e) => e && {
								...e,
								rot: (e.rot + 1) % 6
							}),
							className: "btn-quiet grid size-12 flex-none place-items-center",
							children: /* @__PURE__ */ h(d, {
								size: 20,
								"aria-hidden": !0
							})
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							disabled: !O || D !== "buy" && (!Ce || !J),
							onClick: Y,
							className: "btn-base min-h-12 flex-1 text-sm text-white",
							style: { background: z.accent },
							children: D === "buy" ? a("games.queensgarden.expandBuyConfirm", { n: 6 }) : O ? Ce ? a("games.queensgarden.placeTileConfirm", {
								n: q,
								cost: Se
							}) : a("games.queensgarden.rotationInvalid") : a("games.queensgarden.pickRecess")
						})
					] }) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
						type: "button",
						onClick: N,
						className: "btn-quiet min-h-12 flex-none px-3 text-xs font-bold",
						children: a("games.queensgarden.cancel")
					}), /* @__PURE__ */ h("button", {
						type: "button",
						disabled: S === null || !J,
						onClick: je,
						className: "btn-base min-h-12 flex-1 text-sm text-white",
						style: { background: z.accent },
						children: S === null ? a("games.queensgarden.placeTileHint") : a("games.queensgarden.placeTileConfirm", {
							n: q,
							cost: H
						})
					})] }) : /* @__PURE__ */ h("p", {
						className: "flex min-h-12 flex-1 items-center justify-center text-xs font-bold opacity-50",
						children: a("games.queensgarden.watchHint")
					})]
				})
			]
		})
	});
}
function st({ value: e, sel: t, onPick: n }) {
	let r = u(), i = t !== null && t.kind === e.kind && t.key === e.key, a = e.kind === "color" ? r(rt[e.key]) : r(it[e.key]);
	return /* @__PURE__ */ g("button", {
		type: "button",
		"aria-label": a,
		"aria-pressed": i,
		onClick: () => n(i ? null : e),
		className: `qg-symbol-chip ${i ? "is-selected" : ""}`,
		children: [e.kind === "color" ? /* @__PURE__ */ h("span", {
			"aria-hidden": !0,
			className: "qg-color-dot",
			style: { background: ze[e.key] }
		}) : /* @__PURE__ */ h(Ve, {
			pattern: e.key,
			px: 20
		}), a]
	});
}
function ct({ pub: e, syms: t, acqPreview: i }) {
	let c = u(), { ref: l } = s("display"), { ref: d } = s("supply"), { ref: f } = s("display-tile-size"), ee = a(null), [p, te] = o({
		w: 0,
		h: 0,
		screenW: 0,
		large: !1
	}), _ = n((e) => {
		ee.current = e, l(e);
	}, [l]);
	r(() => {
		let e = ee.current;
		if (!e) return;
		let t = e.closest(".qg-screen"), n = new ResizeObserver(() => {
			let n = {
				w: e.clientWidth,
				h: e.clientHeight,
				screenW: t?.clientWidth ?? 0,
				large: getComputedStyle(e).getPropertyValue("--qg-large").trim() === "1"
			};
			te((e) => e.w === n.w && e.h === n.h && e.screenW === n.screenW && e.large === n.large ? e : n);
		});
		return n.observe(e), t && n.observe(t), () => n.disconnect();
	}, []);
	let v = lt(p, e.display.length), y = new Set(i?.tiles.map((e) => `${e.slot}:${e.idx}`) ?? []), b = new Set(i?.tiles.map((e) => e.slot) ?? []), ne = new Set(i?.exps ?? []), x = t.map((e) => e.kind === "color" ? e.c : "lgreen");
	return /* @__PURE__ */ g("div", {
		className: "qg-supply",
		style: v,
		children: [
			/* @__PURE__ */ h("span", {
				ref: f,
				className: "qg-fx-tile-size",
				"aria-hidden": !0
			}),
			/* @__PURE__ */ g("div", {
				className: "qg-scoreline",
				children: [/* @__PURE__ */ h(Je, { colors: x }), /* @__PURE__ */ g("div", {
					className: "qg-score-details",
					children: [/* @__PURE__ */ h("strong", { children: c("games.queensgarden.scoreThisRound") }), /* @__PURE__ */ h("div", {
						className: "qg-score-symbols",
						children: t.map((e, t) => /* @__PURE__ */ g("span", {
							className: "qg-score-symbol",
							"aria-label": e.kind === "color" ? c(rt[e.c]) : c(it[e.p]),
							children: [e.kind === "color" ? /* @__PURE__ */ h("span", {
								"aria-hidden": !0,
								className: "qg-color-dot",
								style: { background: ze[e.c] }
							}) : /* @__PURE__ */ h(Ve, {
								pattern: e.p,
								px: 16
							}), /* @__PURE__ */ h("b", {
								className: "font-mono tabular-nums",
								children: e.pts
							})]
						}, t))
					})]
				})]
			}),
			/* @__PURE__ */ g("div", {
				className: "qg-market-heading",
				children: [
					/* @__PURE__ */ h("strong", { children: c("games.queensgarden.displayLabel") }),
					/* @__PURE__ */ h("span", {
						ref: d,
						"aria-label": c("games.queensgarden.supplyAria", { n: e.supplyCount }),
						children: c("games.queensgarden.stackSupply", {
							stack: e.stackCounts[e.round - 1],
							supply: e.supplyCount
						})
					}),
					/* @__PURE__ */ h("span", {
						className: "qg-bag-count",
						children: c("games.queensgarden.bagTower", {
							bag: e.bagCount,
							tower: e.towerCount
						})
					})
				]
			}),
			/* @__PURE__ */ g("div", {
				ref: _,
				className: "qg-market-row",
				children: [e.firstMarkerInDisplay && /* @__PURE__ */ h("span", {
					className: "qg-first-flag",
					role: "img",
					"aria-label": c("games.queensgarden.markerAria"),
					children: /* @__PURE__ */ g("svg", {
						viewBox: "0 0 20 28",
						"aria-hidden": !0,
						children: [/* @__PURE__ */ h("path", {
							d: "M 3 2 V 27",
							stroke: "#214539",
							strokeWidth: "2"
						}), /* @__PURE__ */ h("path", {
							d: "M 4 3 L 18 8 L 4 14 Z",
							fill: "#c25d59",
							stroke: "#214539",
							strokeWidth: "1.5"
						})]
					})
				}), e.display.map((t, n) => /* @__PURE__ */ h("div", {
					className: `qg-market-disc ${n === 0 && e.stackTopActive ? "is-top" : ""} ${t.faceUp ? "is-face-up" : ""} ${ne.has(t.exp) || b.has(n) ? "is-taking" : ""}`,
					children: t.faceUp ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("svg", {
						viewBox: "-18 -18 36 36",
						width: "26",
						height: "26",
						"aria-hidden": !0,
						children: /* @__PURE__ */ h(Ge, {
							kind: "pavilion",
							scale: .8
						})
					}), /* @__PURE__ */ h(Qe, {
						hex: R(t.exp),
						px: 27
					})] }) : /* @__PURE__ */ h("div", {
						className: "qg-market-tiles",
						children: t.tiles.map((e, t) => /* @__PURE__ */ h("span", {
							className: y.has(`${n}:${t}`) ? "is-taking" : "",
							children: /* @__PURE__ */ h(Qe, {
								hex: e,
								px: 22
							})
						}, t))
					})
				}, `${t.exp}:${n}`))]
			})
		]
	});
}
function lt(e, t) {
	if (!e.large || e.w === 0 || e.h === 0) return;
	let n = Math.max(1, t), r = e.w - 10, i = e.h - 12, a = Math.min(76, Math.max(44, e.screenW * .0385 + 8.6)) * 2.35 + 8, o = 1, s = 0, c = -Infinity;
	for (let e = 1; e <= n; e += 1) {
		let t = Math.ceil(n / e), l = Math.min((r - 10 * (e - 1)) / e, (i - 10 * (t - 1)) / t, a), u = l - t * .1 - (e * t - n) * .05;
		u > c && (c = u, o = e, s = l);
	}
	s < 106.7 && (o = Math.min(n, Math.max(1, Math.floor((r + 10) / 116.7))), s = Math.min(a, (r - 10 * (o - 1)) / o));
	let l = Math.max(32, Math.floor((s - 8) / 2.35));
	return {
		"--qg-market-columns": o,
		"--qg-disc-size": `${Math.floor(s)}px`,
		"--qg-display-chip": `${l}px`
	};
}
//#endregion
//#region src/games/queensgarden/bot.ts
var ut = 3.5;
function dt(e, t, n) {
	let r = 0;
	for (let i of be(e, t)) (i.kind === "color" && i.c === n.c || i.kind === "pattern" && i.p === n.p) && (r += i.pts);
	return r;
}
function ft(e, t, n) {
	let r = 0;
	for (let i = t; i <= 4; i++) r += dt(e, i, n) * (i === t ? 1 : .7);
	return r;
}
function pt(e, t) {
	let n = new Set([...e.entries()].filter(([, e]) => t(e)).map(([e]) => e)), r = [];
	for (; n.size > 0;) {
		let e = n.values().next().value;
		n.delete(e);
		let t = [e], i = [e];
		for (; i.length > 0;) for (let e of P(i.pop())) n.has(e) && (n.delete(e), t.push(e), i.push(e));
		r.push(t);
	}
	return r;
}
function mt(e, t, n) {
	return t >= 3 ? n + U(e, t) : t === 2 ? .35 * (n + U(e, 3)) : .12 * (n + U(e, 3));
}
function ht(e, t, n, r) {
	let i = 0, a = V(r.p);
	for (let o of [(e) => e.c === r.c, (e) => e.p === r.p]) {
		let r = pt(e, o).filter((e) => e.some((e) => P(e).includes(n)));
		if (r.length === 0) {
			i += .05 * a;
			continue;
		}
		let s = r.reduce((n, r) => n + mt(t, r.length, r.reduce((t, n) => t + V(e.get(n).p), 0)), 0), c = 1 + r.reduce((e, t) => e + t.length, 0), l = a + r.reduce((t, n) => t + n.reduce((t, n) => t + V(e.get(n).p), 0), 0);
		i += mt(t, c, l) - s;
	}
	return i;
}
function gt(e) {
	let t = [{
		center: "0,0",
		kind: "fountain"
	}];
	for (let [e, n] of F) t.push({
		center: e,
		kind: n
	});
	return e.expansions.forEach((e) => {
		e.side === "pavilion" && t.push({
			center: I[e.recess].center,
			kind: "pavilion"
		});
	}), t;
}
function _t(e, t, n) {
	let r = 0;
	for (let i of gt(t)) {
		let t = P(i.center);
		if (!t.includes(n)) continue;
		let a = t.filter((t) => e.has(t)).length;
		a + 1 >= 6 ? r += pe[i.kind] * ut : r += .25 * (a + 1);
	}
	return r;
}
function vt(e, t, n, r, i, a) {
	let o = 0;
	for (let r of a) {
		if (!G(e, r, i)) continue;
		let a = ht(e, n, r, i) + _t(e, t, r);
		a > o && (o = a);
	}
	return ft(n, r, i) + o;
}
function yt(e, t, n, r, i) {
	if (r === 0) return {
		tiles: [],
		cost: 0
	};
	let a = (e) => i(e) - V(e.p), o = [];
	e.forEach((e, n) => {
		n !== t && e === "joker" && o.push(n);
	});
	let s = null;
	for (let i of ["pattern", "color"]) {
		let c = [], l = /* @__PURE__ */ new Set([n.c]), u = /* @__PURE__ */ new Set([n.p]), d = [];
		e.forEach((e, n) => {
			n !== t && e !== "joker" && d.push({
				i: n,
				h: e,
				w: a(e)
			});
		}), d.sort((e, t) => e.w - t.w);
		for (let e of d) {
			if (i === "pattern") {
				if (e.h.p !== n.p || l.has(e.h.c)) continue;
				l.add(e.h.c);
			} else {
				if (e.h.c !== n.c || u.has(e.h.p)) continue;
				u.add(e.h.p);
			}
			c.push({
				i: e.i,
				w: e.w
			});
		}
		for (let e = Math.max(0, r - o.length); e <= Math.min(r, c.length); e += 1) {
			let t = [...c.slice(0, e).map((e) => e.i), ...o.slice(0, r - e)], n = c.slice(0, e).reduce((e, t) => e + t.w, 0) + (r - e) * ut;
			(!s || n < s.cost) && (s = {
				tiles: t,
				cost: n
			});
		}
	}
	return s;
}
function bt(e, t, n, r, i) {
	if (r === 0) return [];
	let a = [], o = [];
	e.forEach((e, n) => {
		n !== t && (e === "joker" ? a.push(n) : o.push({
			i: n,
			h: e,
			w: i(e)
		}));
	}), o.sort((e, t) => e.w - t.w);
	let s = null;
	for (let t of ["pattern", "color"]) {
		let i = [], c = /* @__PURE__ */ new Set([n.c]), l = /* @__PURE__ */ new Set([n.p]);
		for (let e of o) {
			if (i.length >= r) break;
			if (t === "pattern") {
				if (e.h.p !== n.p || c.has(e.h.c)) continue;
				c.add(e.h.c);
			} else {
				if (e.h.c !== n.c || l.has(e.h.p)) continue;
				l.add(e.h.p);
			}
			i.push(e.i);
		}
		let u = 0;
		for (; i.length < r && u < a.length;) i.push(a[u]), u += 1;
		i.length === r && (!s || i.filter((t) => e[t] === "joker").length > s.filter((t) => e[t] === "joker").length) && (s = i);
	}
	return s;
}
function xt(e, t, n) {
	let r = 0;
	for (let i of [t, t + 1]) if (!(i > 4)) for (let a of be(e, i)) (a.kind === "color" && a.c === n.c || a.kind === "pattern" && a.p === n.p) && (r += a.pts * (i === t ? 2 : 1));
	return r;
}
function St(e, t) {
	let n = t.garden, r = W(n), i = (t) => xt(e.variant, e.round, t), a = new Set(n.expansions.map((e) => e.recess)), o = I.map((e) => e.id).filter((e) => !a.has(e)), s = [...xe(n)].filter((e) => !r.has(e)), c = (e) => i(e);
	for (let e = 0; e < t.expansions.length; e += 1) {
		let n = R(t.expansions[e]), i = bt(t.storage, -1, n, V(n.p) - 1, c);
		if (i) {
			for (let t of o) for (let a = 0; a < 6; a += 1) if (G(r, I[t].cells[1 + a], n)) return {
				type: "placeExpansion",
				source: "storage",
				item: e,
				recess: t,
				rot: a,
				pay: {
					tiles: i,
					expansions: [e]
				}
			};
		}
	}
	if (s.length < 4 && o.length > 0 && t.score >= 6 && e.supplyCount > 0) return {
		type: "placeExpansion",
		source: "supply",
		recess: o[0],
		rot: 0,
		pay: {
			tiles: [],
			expansions: []
		}
	};
	let l = null;
	if (t.storage.forEach((e, n) => {
		if (e === "joker") return;
		let a = bt(t.storage, n, e, V(e.p) - 1, c);
		if (!a) return;
		let o = s.find((t) => G(r, t, e));
		if (!o) return;
		let u = i(e);
		(!l || u > l.w) && (l = {
			i: n,
			cell: o,
			pay: [n, ...a],
			w: u
		});
	}), l !== null) {
		let e = l;
		return {
			type: "placeTile",
			item: e.i,
			pay: {
				tiles: e.pay,
				expansions: []
			},
			cell: e.cell
		};
	}
	let u = null, d = (n) => {
		let r = Ne(e.display, n);
		if (r.tiles.length === 0 && r.exps.length === 0 || t.storage.length + r.tiles.length > 12 || t.expansions.length + r.exps.length > 2) return;
		let a = r.tiles.reduce((e, t) => e + i(t.h) + 1, 0) + r.exps.length * 5;
		(!u || a > u.v) && (u = {
			sel: n,
			v: a
		});
	};
	for (let e of w) d({
		kind: "color",
		key: e
	});
	for (let e of T) d({
		kind: "pattern",
		key: e
	});
	return u === null ? {
		type: "pass",
		discard: {
			tiles: [],
			expansions: []
		}
	} : {
		type: "acquire",
		sel: u.sel
	};
}
var Ct = {
	1: .1,
	2: .2,
	3: .45,
	4: .95
};
function wt(e, t) {
	let n = t.garden, r = W(n), i = [...xe(n)].filter((e) => !r.has(e)), a = new Set(n.expansions.map((e) => e.recess)), o = I.map((e) => e.id).filter((e) => !a.has(e)), s = Ct[e.round] ?? .5, c = (t) => vt(r, n, e.variant, e.round, t, i), l = {
		type: "pass",
		discard: {
			tiles: [],
			expansions: []
		}
	}, u = e.firstMarkerInDisplay ? 1.2 : .6;
	if (t.storage.forEach((a, o) => {
		if (a === "joker") return;
		let s = yt(t.storage, o, a, V(a.p) - 1, c);
		if (s) for (let t of i) {
			if (!G(r, t, a)) continue;
			let i = ft(e.variant, e.round, a) + ht(r, e.variant, t, a) + _t(r, n, t) - s.cost;
			i > u && (u = i, l = {
				type: "placeTile",
				item: o,
				pay: {
					tiles: [o, ...s.tiles],
					expansions: []
				},
				cell: t
			});
		}
	}), t.expansions.forEach((i, a) => {
		let s = R(i), d = V(s.p), f = yt(t.storage, -1, s, d - 1, c);
		if (f) for (let t of o) for (let i = 0; i < 6; i += 1) {
			let o = I[t].cells[1 + i];
			if (!G(r, o, s)) continue;
			let c = ft(e.variant, e.round, s) + ht(r, e.variant, o, s) + _t(r, n, o) + (4 - e.round + 1) * 1 + d * .9 + 3 - f.cost;
			c > u && (u = c, l = {
				type: "placeExpansion",
				source: "storage",
				item: a,
				recess: t,
				rot: i,
				pay: {
					tiles: f.tiles,
					expansions: [a]
				}
			});
		}
	}), i.length <= 3 && o.length > 0 && t.score >= 10 && e.supplyCount > 0) {
		let e = 7 * .8 + 2;
		e > u && (u = e, l = {
			type: "placeExpansion",
			source: "supply",
			recess: o[0],
			rot: 0,
			pay: {
				tiles: [],
				expansions: []
			}
		});
	}
	let d = (n) => {
		let r = Ne(e.display, n);
		if (r.tiles.length === 0 && r.exps.length === 0 || t.storage.length + r.tiles.length > 12 || t.expansions.length + r.exps.length > 2) return;
		let i = 0;
		for (let e of r.tiles) i += c(e.h) - s * V(e.h.p);
		for (let t of r.exps) i += 7 - s * V(R(e.display[t].exp).p);
		e.stackTopActive && r.tiles.some((e) => e.slot === 0) && (i += .5), i > u && (u = i, l = {
			type: "acquire",
			sel: n
		});
	};
	for (let e of w) d({
		kind: "color",
		key: e
	});
	for (let e of T) d({
		kind: "pattern",
		key: e
	});
	return l;
}
var Tt = (e, t) => {
	let n = e.public;
	if (n.phase !== "action" || n.turn !== t.rid) return null;
	let r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	let i = t.difficulty === "weak" ? St(n, r) : wt(n, r);
	return i ? { action: i } : null;
}, Et = {
	blue: "games.queensgarden.colorBlue",
	dpurple: "games.queensgarden.colorDpurple",
	violet: "games.queensgarden.colorViolet",
	yellow: "games.queensgarden.colorYellow",
	lgreen: "games.queensgarden.colorLgreen",
	dgreen: "games.queensgarden.colorDgreen"
}, Dt = {
	tree: "games.queensgarden.patternTree",
	bird: "games.queensgarden.patternBird",
	butterflies: "games.queensgarden.patternButterflies",
	flower: "games.queensgarden.patternFlower",
	branch: "games.queensgarden.patternBranch",
	swarm: "games.queensgarden.patternSwarm"
}, Ot = (e, t, n) => {
	switch (e.type) {
		case "acquire": return e.sel.kind === "color" ? n("games.queensgarden.hintAcquireColor", { color: n(Et[e.sel.key]) }) : n("games.queensgarden.hintAcquirePattern", { pattern: n(Dt[e.sel.key]) });
		case "placeTile": return n("games.queensgarden.hintPlaceTile", { n: e.pay.tiles.length });
		case "placeExpansion": return e.source === "supply" ? n("games.queensgarden.hintBuyExpansion") : n("games.queensgarden.hintPlaceExpansion");
		case "pass": return n("games.queensgarden.actPass");
		case "tick": return "";
	}
}, kt = (e, t) => t ? e.anchor(`seat:${t}`) : null;
function At(e, t, n, r, i = 0) {
	let a = kt(e, t);
	return a ? /* @__PURE__ */ h(_, {
		at: a,
		ms: n,
		delay: i,
		children: r
	}) : null;
}
var jt = {
	acquire(e, t) {
		let n = e.data, r = Array.isArray(n?.tiles) ? n.tiles : [], i = Array.isArray(n?.exps) ? n.exps : [], a = t.anchor("display"), o = kt(t, e.rid);
		if (!a || !o || r.length === 0 && i.length === 0) return null;
		let s = t.anchor("display-tile-size")?.w || 28;
		return {
			ms: 420 + (r.length + i.length) * 70,
			node: /* @__PURE__ */ g(m, { children: [r.map((e, t) => /* @__PURE__ */ h(v, {
				from: a,
				to: o,
				ms: 420,
				delay: t * 70,
				children: /* @__PURE__ */ h(Qe, {
					hex: e,
					px: s
				})
			}, `t${t}`)), i.map((e, t) => /* @__PURE__ */ h(v, {
				from: a,
				to: o,
				ms: 420,
				delay: (r.length + t) * 70,
				children: /* @__PURE__ */ h("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ h("svg", {
						width: s * 1.5,
						height: s * 1.5,
						viewBox: "-18 -18 36 36",
						"aria-hidden": !0,
						children: /* @__PURE__ */ h(Ge, {
							kind: "pavilion",
							scale: .8
						})
					})
				})
			}, `e${e}`))] })
		};
	},
	place(e, t) {
		let n = e.data, r = (Array.isArray(n?.surrounded) ? n.surrounded : []).reduce((e, t) => e + t.jokers, 0), i = kt(t, e.rid);
		return i ? {
			ms: r > 0 ? 1100 : 600,
			node: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(y, {
				at: i,
				ms: 600
			}), r > 0 && /* @__PURE__ */ g(_, {
				at: i,
				ms: 1100,
				delay: 200,
				children: ["🌈+", r]
			})] })
		} : null;
	},
	expand(e, t) {
		let n = e.data, r = (Array.isArray(n?.surrounded) ? n.surrounded : []).reduce((e, t) => e + t.jokers, 0), i = kt(t, e.rid);
		return i ? {
			ms: r > 0 ? 1100 : 700,
			node: /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h(y, {
					at: i,
					ms: 700
				}),
				n?.side === "plain" && /* @__PURE__ */ h(_, {
					at: i,
					ms: 900,
					children: "−6"
				}),
				r > 0 && /* @__PURE__ */ g(_, {
					at: i,
					ms: 1100,
					delay: 200,
					children: ["🌈+", r]
				})
			] })
		} : null;
	},
	pass(e, t) {
		let n = e.data, r = typeof n?.minus == "number" ? n.minus : 0, i = kt(t, e.rid);
		return i ? {
			ms: 800,
			node: /* @__PURE__ */ g(m, { children: [r > 0 && /* @__PURE__ */ g(_, {
				at: i,
				ms: 800,
				children: ["−", r]
			}), n?.tookFirst === !0 && /* @__PURE__ */ h(_, {
				at: i,
				ms: 900,
				delay: 150,
				children: "🚩"
			})] })
		} : null;
	},
	score(e, t) {
		let n = e.data, r = typeof n?.gained == "number" ? n.gained : 0;
		return {
			ms: H.score,
			node: r > 0 ? At(t, e.rid, H.score, `+${r}`) : null
		};
	},
	settle(e, t) {
		let n = e.data, r = typeof n?.plus == "number" ? n.plus : 0, i = typeof n?.minus == "number" ? n.minus : 0, a = [r > 0 ? `+${r}` : "", i > 0 ? `−${i}` : ""].filter(Boolean).join(" ");
		return {
			ms: H.settle,
			node: a ? At(t, e.rid, H.settle, a) : null
		};
	},
	eval(e, t) {
		let n = e.data?.gains ?? {}, r = Object.entries(n).filter(([, e]) => e > 0).map(([e, n], r) => At(t, e, H.eval, `+${n}`, r * 120));
		return b(), {
			ms: H.eval,
			node: r.length > 0 ? /* @__PURE__ */ h(m, { children: r }) : null
		};
	},
	refill(e, t) {
		let n = t.anchor("display");
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ h(y, {
				at: n,
				ms: 700
			})
		} : null;
	},
	final() {
		return null;
	}
};
//#endregion
//#region src/games/queensgarden/game-over.tsx
function Mt({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let s = u(), c = l((e) => e.locale), d = t, [f, ee] = o(r), _ = d.players.find((e) => e.rid === f) ?? d.players.find((t) => t.rid === e.ranking[0]) ?? d.players[0], v = i ?? a, y = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? p(t, c) : e;
	};
	return /* @__PURE__ */ g(te, {
		adaptive: !0,
		scroll: !1,
		className: "qg-result-screen",
		banner: /* @__PURE__ */ g("header", {
			className: "qg-result-heading",
			children: [/* @__PURE__ */ h("svg", {
				viewBox: "-22 -22 44 44",
				"aria-hidden": !0,
				children: /* @__PURE__ */ h(Ge, { kind: "pavilion" })
			}), /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h("strong", { children: s("session.result.title") }), /* @__PURE__ */ h("small", { children: s("games.queensgarden.finalSubtitle") })] })]
		}),
		actionsHeight: "qg-result-actions-slot",
		actions: v ? /* @__PURE__ */ g("div", {
			className: "qg-result-actions",
			children: [i && /* @__PURE__ */ h("button", {
				type: "button",
				style: { background: z.accent },
				onClick: i,
				children: s("session.result.playAgain")
			}), a && /* @__PURE__ */ h("button", {
				type: "button",
				className: "qg-result-back",
				onClick: a,
				children: s("session.result.backToLobby")
			})]
		}) : /* @__PURE__ */ h("p", {
			className: "qg-result-wait",
			children: s("session.result.waitHost")
		}),
		children: [e.winner.length > 0 && /* @__PURE__ */ h(re, {}), /* @__PURE__ */ g("div", {
			className: "qg-result-body",
			children: [/* @__PURE__ */ h("section", {
				className: "qg-result-garden",
				"aria-label": _ ? s("games.queensgarden.finalGarden", { name: y(_.rid) }) : s("games.queensgarden.gardenTitle"),
				children: _ && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("header", {
					className: "qg-result-garden-head",
					children: [/* @__PURE__ */ h("strong", { children: s("games.queensgarden.finalGarden", { name: y(_.rid) }) }), /* @__PURE__ */ g("span", { children: [
						e.scores?.[_.rid] ?? _.score,
						" ",
						s("games.queensgarden.pointsShort")
					] })]
				}), /* @__PURE__ */ h("div", {
					className: "qg-result-garden-board",
					children: /* @__PURE__ */ h(nt, {
						rid: _.rid,
						garden: _.garden
					})
				})] })
			}), /* @__PURE__ */ h("ol", {
				className: "qg-result-rankings",
				"aria-label": s("games.queensgarden.finalRankings"),
				children: e.ranking.map((t, i) => {
					let a = d.players.find((e) => e.rid === t), o = n.find((e) => e.rid === t);
					if (!a) return null;
					let c = e.winner.includes(t), l = _?.rid === t, u = e.autopilot?.[t];
					return /* @__PURE__ */ h("li", {
						className: `qg-result-entry${c ? " qg-result-entry--winner" : ""}${l ? " qg-result-entry--selected" : ""}`,
						children: /* @__PURE__ */ g("button", {
							type: "button",
							className: "qg-result-player",
							"aria-pressed": l,
							onClick: () => ee(t),
							"aria-label": s("games.queensgarden.finalViewGarden", { name: y(t) }),
							children: [
								/* @__PURE__ */ h("span", {
									className: "qg-result-rank",
									"aria-label": `${i + 1}`,
									children: c ? "★" : i + 1
								}),
								/* @__PURE__ */ h("span", {
									className: "qg-result-avatar",
									style: { background: x[(o?.colorIndex ?? 0) % x.length].hex },
									children: o && /* @__PURE__ */ h("img", {
										src: ne[o.avatar % ne.length],
										alt: "",
										draggable: !1
									})
								}),
								/* @__PURE__ */ g("span", {
									className: "qg-result-name",
									children: [/* @__PURE__ */ h("strong", { children: y(t) }), /* @__PURE__ */ g("small", { children: [t === r && /* @__PURE__ */ h("span", { children: s("lobby.you") }), u !== void 0 && u > 0 && /* @__PURE__ */ h("span", { children: s("session.autopilot.share", { n: Math.round(u * 100) }) })] })]
								}),
								/* @__PURE__ */ g("strong", {
									className: "qg-result-score",
									children: [e.scores?.[t] ?? a.score, /* @__PURE__ */ h("small", { children: s("games.queensgarden.pointsShort") })]
								}),
								/* @__PURE__ */ g("span", {
									className: "qg-result-facts",
									children: [
										/* @__PURE__ */ h("span", { children: s("games.queensgarden.finalTiles", { n: W(a.garden).size }) }),
										/* @__PURE__ */ h("span", { children: s("games.queensgarden.finalExpansions", { n: a.garden.expansions.length }) }),
										/* @__PURE__ */ h("em", { children: s(l ? "games.queensgarden.finalViewing" : "games.queensgarden.finalView") })
									]
								})
							]
						})
					}, t);
				})
			})]
		})]
	});
}
//#endregion
//#region src/games/queensgarden/options.tsx
function Nt({ value: e, onChange: t }) {
	let n = u(), r = j.safeParse(e), i = r.success ? r.data : j.parse(void 0);
	return /* @__PURE__ */ h(C, {
		title: n("games.queensgarden.optVariant"),
		children: [!1, !0].map((e) => /* @__PURE__ */ h(S, {
			name: "queensgarden-variant",
			value: String(e),
			checked: i.variant === e,
			label: n(e ? "games.queensgarden.optVariantB" : "games.queensgarden.optVariantA"),
			accent: z.accent,
			onChange: () => t({ variant: e })
		}, String(e)))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/queensgarden/entry.tsx
var Pt = {
	definition: Re,
	View: at,
	bot: Tt,
	describe: Ot,
	fx: jt,
	OverView: Mt,
	Options: Nt,
	locales: {
		zh: {
			name: "花砖物语:花园宫殿",
			desc: "为女王造园:按图案或颜色拿砖,付费造景,围住喷泉雕像赚 joker",
			rules: "目标:四轮结束后总分最高者获胜,平分共享胜利。\n流程(轮到你,四选一):拿取 / 放砖 / 放扩展 / 跳过。\n拿取:\n· 从供应区选一种图案(各色)或一种颜色(各图案),拿走全部匹配的砖与翻面扩展;重复的组合只拿一件。\n· 仓储放不下就不能选:砖 12 格、扩展 2 格。\n· 若从回合堆顶块拿了砖,该块带着剩砖移入供应区,新顶块补 4 砖。\n· 被拿空的扩展翻面,露出凉亭与印刷砖,可被之后的拿取选走。\n放砖:\n· 选仓储里一块砖,支付等于图案值的件数:树 1、鸟 2、蝶 3、花 4、枝 5、蜂 6。\n· 支付方式:从仓储弃掉含该砖在内的等量件,须全是同图案异色,或全同色异图案;🌈 joker(百搭)可顶替其它件。\n· 落点须是空格:孤立,或与相邻砖同图案/同色;且同一连通组里不许出现两块完全相同的砖。\n放扩展:\n· 仓储里的扩展支付其上印刷砖的成本,凉亭面朝上放进花园周围 6 个凹槽之一(6 种朝向任选,印刷砖同样遵守放砖规则)。\n· 或花正好 6 分从供应堆买素面扩展(7 个空格)。\n跳过:\n· 可弃掉仓储里的任意件,按值扣分。\n· 本轮第一个跳过的人拿先手标记并扣 1 分。\n轮末计分:\n· 全员跳过后按转盘计分:花园中每个匹配本轮 3 个符号的砖按徽章得分(图案颜色可双计),每个凉亭获得 1 分。\n· 完全围住喷泉/雕像/长椅/凉亭(相邻 6 格全有砖)立即获得 1/2/2/3 个 joker。\n终局计分:\n· 仓储里的 joker 各获得 1 分,其余件按值扣分。\n· 逐色逐图案评估:至少 3 块的连通组获得成员图案值之和,恰好 6 块再加 6 分。",
			colorBlue: "蓝",
			colorDpurple: "深紫",
			colorViolet: "浅紫",
			colorYellow: "黄",
			colorLgreen: "浅绿",
			colorDgreen: "深绿",
			patternTree: "树",
			patternBird: "鸟",
			patternButterflies: "蝶群",
			patternFlower: "花",
			patternBranch: "枝",
			patternSwarm: "蜂群",
			turnYou: "轮到你 · 选择行动",
			turnWait: "等 {{name}} 行动…",
			scoring: "轮末计分中…",
			finalSettle: "终局:清点仓储…",
			finalEval: "终局评估中…",
			watchHint: "围观中(点上方名牌换看)",
			roundShort: "第 {{n}} 轮",
			wheelLabel: "转盘",
			gardenTitle: "女王花园",
			zoomIn: "放大花园",
			zoomOut: "缩小花园",
			scoreThisRound: "本轮计分",
			displayLabel: "展示区",
			stackSupply: "回合堆 {{stack}} · 扩展 {{supply}}",
			storageLabel: "仓储",
			pointsShort: "分",
			paymentProgress: "支付 {{n}} / {{cost}} · 同色或同图案",
			rotationInvalid: "此朝向不能放置",
			markerAria: "先手标记",
			stripStorage: "◆ {{n}}",
			jokerAria: "joker 百搭",
			tileAria: "{{color}}{{pattern}}",
			expAria: "扩展:{{color}}{{pattern}}",
			supplyAria: "扩展供应堆,余 {{n}} 块",
			bagTower: "袋 {{bag}} · 塔 {{tower}}",
			actAcquire: "拿取花砖",
			actBuy: "{{n}}分扩建",
			actPass: "跳过",
			pickSymbol: "点一个颜色或图案",
			acquireConfirm: "拿走 {{tiles}} 砖 + {{exps}} 扩展",
			acquireNoFit: "仓储放不下",
			acquireEmpty: "选个有货的符号",
			placeTileHint: "点花园高亮格落砖",
			payHint: "支付:点仓储件凑够 {{cost}} 件",
			placeTileConfirm: "放置({{n}}/{{cost}})",
			pickRecess: "点一个凹槽放扩展",
			rotate: "旋转朝向",
			expandBuyConfirm: "买下放置(−{{n}} 分)",
			expandBuyConfirmHint: "确认凹槽后放置",
			passHint: "跳过:可点仓储件弃掉扣分",
			passConfirm: "确认跳过(−{{n}})",
			cancel: "取消",
			optVariant: "计分板",
			optVariantA: "A 面(标准)",
			optVariantB: "B 面(变体)",
			errNotYourTurn: "还没轮到你",
			errNoMatch: "供应区里没有这个符号",
			errNotFit: "仓储放不下这些",
			errBadItem: "这件放不了",
			errBadPay: "支付须同图案异色或同色异图案,数量等于成本",
			errBadCell: "这格放不了:需孤立或与相邻同图案/同色,组内不许重复",
			errBadRecess: "这个凹槽已有扩展",
			errPoor: "分数不够 6 分",
			errBadSource: "供应堆已空",
			hintAcquireColor: "拿取所有 {{color}} 色的件",
			hintAcquirePattern: "拿取所有 {{pattern}} 图案的件",
			hintPlaceTile: "放一块砖进花园(付 {{n}} 件)",
			hintPlaceExpansion: "放下仓储里的扩展",
			hintBuyExpansion: "花 6 分买素面扩展放下",
			finalSubtitle: "查看各位玩家完成的花园",
			finalGarden: "{{name}}的花园",
			finalRankings: "最终排名",
			finalViewGarden: "查看{{name}}的花园",
			finalTiles: "花砖 {{n}} 块",
			finalExpansions: "扩展 {{n}} 块",
			finalViewing: "正在查看",
			finalView: "查看花园"
		},
		en: {
			name: "Azul: Queen's Garden",
			desc: "Draft hexes by pattern or color, pay to plant them, surround fountains for jokers",
			rules: "Goal: after four rounds the highest score wins; ties share the victory.\nOn your turn, choose one: acquire / place a tile / place an expansion / pass.\nAcquire:\n· Pick one pattern (all colors) or one color (all patterns) from the display and take every matching tile and face-up expansion; duplicate combos are taken only once.\n· You must have room in storage: 12 tile slots, 2 expansion slots.\n· Taking from the round stack's top block moves it into the display and deals 4 tiles to the new top.\n· An expansion emptied of tiles flips over, revealing a pavilion and a printed hex that later acquires can claim.\nPlace a tile:\n· Pick a tile in storage and pay its pattern value: tree 1, bird 2, butterflies 3, flower 4, branch 5, swarm 6.\n· Payment: discard that many items including the tile, all sharing its pattern with distinct colors, or all sharing its color with distinct patterns; 🌈 jokers stand in for other items.\n· The target cell must be empty and either isolated or adjacent to a tile of the same pattern or color; no connected group may hold two identical hexes.\nPlace an expansion:\n· Pay the printed hex's cost to place one from storage pavilion-side-up into one of the 6 recesses around the garden (any of 6 rotations; the printed hex follows the same placement rules).\n· Or spend exactly 6 points to buy a plain expansion (7 empty cells) from the supply.\nPass:\n· You may discard stored items to lose their values.\n· The first passer takes the starting marker and loses 1 point.\nRound scoring:\n· Once everyone passes, score the wheel: each garden hex matching one of the round's 3 symbols scores its badge value (pattern and color can both count), plus 1 point per pavilion.\n· Fully surrounding a fountain/statue/bench/pavilion (all 6 neighbors filled) instantly grants 1/2/2/3 jokers.\nEndgame scoring:\n· Jokers in storage score 1 point each; leftover items cost their values.\n· Then colors and patterns are evaluated — each connected group of at least 3 scores the sum of its members' pattern values, and exactly 6 scores 6 more.",
			colorBlue: "Blue",
			colorDpurple: "Deep purple",
			colorViolet: "Violet",
			colorYellow: "Yellow",
			colorLgreen: "Light green",
			colorDgreen: "Dark green",
			patternTree: "Tree",
			patternBird: "Bird",
			patternButterflies: "Butterflies",
			patternFlower: "Flower",
			patternBranch: "Branch",
			patternSwarm: "Swarm",
			turnYou: "Your turn · choose an action",
			turnWait: "Waiting for {{name}}…",
			scoring: "Scoring the round…",
			finalSettle: "Final: clearing storage…",
			finalEval: "Final evaluation…",
			watchHint: "Spectating (tap a nameplate to switch)",
			roundShort: "Round {{n}}",
			wheelLabel: "Wheel",
			gardenTitle: "Queen's Garden",
			zoomIn: "Zoom in on garden",
			zoomOut: "Zoom out on garden",
			scoreThisRound: "Round scoring",
			displayLabel: "Display",
			stackSupply: "Stack {{stack}} · Extras {{supply}}",
			storageLabel: "Storage",
			pointsShort: "pts",
			paymentProgress: "Pay {{n}} / {{cost}} · same color or pattern",
			rotationInvalid: "Cannot place at this angle",
			markerAria: "Starting player marker",
			stripStorage: "◆ {{n}}",
			jokerAria: "Wild joker",
			tileAria: "{{color}} {{pattern}}",
			expAria: "Expansion: {{color}} {{pattern}}",
			supplyAria: "Expansion supply, {{n}} left",
			bagTower: "Bag {{bag}} · Tower {{tower}}",
			actAcquire: "Take tiles",
			actBuy: "Expand · {{n}} pts",
			actPass: "Pass",
			pickSymbol: "Tap a color or pattern",
			acquireConfirm: "Take {{tiles}} tiles + {{exps}} expansions",
			acquireNoFit: "No room in storage",
			acquireEmpty: "Pick a symbol that has stock",
			placeTileHint: "Tap a highlighted cell to plant",
			payHint: "Pay: tap storage items to reach {{cost}}",
			placeTileConfirm: "Place ({{n}}/{{cost}})",
			pickRecess: "Tap a recess for the expansion",
			rotate: "Rotate",
			expandBuyConfirm: "Buy & place (−{{n}} pts)",
			expandBuyConfirmHint: "Confirm a recess to place",
			passHint: "Pass: tap storage items to discard",
			passConfirm: "Confirm pass (−{{n}})",
			cancel: "Cancel",
			optVariant: "Score board",
			optVariantA: "Side A (standard)",
			optVariantB: "Side B (variant)",
			errNotYourTurn: "Not your turn yet",
			errNoMatch: "No such symbol in the display",
			errNotFit: "No room in storage for these",
			errBadItem: "This item cannot be placed",
			errBadPay: "Payment must share one pattern or one color, count equal to cost",
			errBadCell: "Cannot plant here: isolated or matching neighbor, no duplicates in a group",
			errBadRecess: "That recess is occupied",
			errPoor: "Not enough points (need 6)",
			errBadSource: "Supply is empty",
			hintAcquireColor: "Take all {{color}} pieces",
			hintAcquirePattern: "Take all {{pattern}} pieces",
			hintPlaceTile: "Place a tile (pay {{n}} pieces)",
			hintPlaceExpansion: "Place the stored expansion",
			hintBuyExpansion: "Buy a plain expansion for 6 points",
			finalSubtitle: "Explore the completed gardens",
			finalGarden: "{{name}}’s garden",
			finalRankings: "Final rankings",
			finalViewGarden: "View {{name}}’s garden",
			finalTiles: "{{n}} tiles",
			finalExpansions: "{{n}} expansions",
			finalViewing: "Viewing",
			finalView: "View garden"
		}
	}
};
//#endregion
export { Pt as default };
