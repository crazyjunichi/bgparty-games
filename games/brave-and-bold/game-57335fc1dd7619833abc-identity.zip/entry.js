import { z as e } from "zod";
import { randomIntAt as t } from "@bgparty/sdk/engine/prng";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { BottomSheet as a } from "@bgparty/sdk/bottom-sheet";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { HintRing as l } from "@bgparty/sdk/ui/hint-ring";
import { SeatBadgedAvatar as u, seatName as d } from "@bgparty/sdk/ui/player-strip";
import { DeltaNumber as f } from "@bgparty/sdk/fx/delta-number";
import { usePrefersReducedMotion as p } from "@bgparty/sdk/fx/use-reduced-motion";
import { useFxAnchor as m } from "@bgparty/sdk/fx/anchors";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { Floater as v, FlySprite as ee, PulseBox as te } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as y, OptionSection as b, OptionSwitch as ne } from "@bgparty/sdk/ui/game-options";
//#region src/games/brave-and-bold/effects.ts
function x(e, t) {
	e?.effects && e.effects.push({
		...t,
		with: e.effects.length > 0
	});
}
function S(e, t, n, r, i) {
	r !== i && x(e, {
		kind: "move",
		rid: t.rid,
		data: {
			token: { ...n },
			character: t.character,
			from: r,
			to: i
		}
	});
}
//#endregion
//#region src/games/brave-and-bold/model.ts
var C = [
	"C",
	"R",
	"A",
	"F",
	"E",
	"X",
	"U",
	"V",
	"K",
	"S",
	"W",
	"B",
	"D",
	"L",
	"H",
	"M",
	"I",
	"Y",
	"Z",
	"O"
], w = (e) => e.kind === "double" ? 2 : 1, T = (e) => [
	"C",
	"R",
	"A",
	"F"
].includes(e), E = (e) => e.symbol === "X" ? 1 : e.symbol === "K" ? 2 : 0, re = (e) => ![
	"X",
	"K",
	"O"
].includes(e.symbol), D = (e) => e < 17 ? 3 : e < 21 ? 4 : e < 25 ? 5 : e < 32 ? 6 : e < 40 ? 7 : 8;
function O(e) {
	return e.flatMap((e) => E(e) > 0 || ["V", "D"].includes(e.symbol) ? [] : Array.from({ length: w(e) }, (t, n) => ({
		id: `${e.id}:${n}`,
		symbol: e.symbol,
		token: e.id,
		part: n
	})));
}
//#endregion
//#region src/games/brave-and-bold/schema.ts
var k = e.object({
	mode: e.enum([
		"duel",
		"teams",
		"league"
	]).catch("duel"),
	expansion: e.boolean().catch(!1)
}).default({
	mode: "duel",
	expansion: !1
}), A = e.object({
	id: e.int().nonnegative(),
	symbol: e.enum(C),
	kind: e.enum([
		"basic",
		"double",
		"power",
		"critical"
	])
}), ie = e.object({
	id: e.string(),
	symbol: e.enum(C),
	token: e.int().nullable(),
	part: e.int().nonnegative()
}), ae = e.object({
	ability: e.int().min(0).max(6),
	slots: e.array(e.array(e.string()).max(12)).max(6),
	extra: e.array(e.string()).max(12)
}), oe = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("choose"),
		id: e.string().max(240)
	}),
	e.object({
		type: e.literal("allocate"),
		payment: ae,
		character: e.string().max(20),
		target: e.int().min(0).max(5)
	}),
	e.object({
		type: e.literal("tick"),
		now: e.number().finite()
	})
]), j = ae.extend({
	character: e.string(),
	target: e.int(),
	copied: e.boolean()
}), se = e.object({
	id: e.string(),
	label: e.string(),
	params: e.record(e.string(), e.union([e.string(), e.number()])).optional(),
	kind: e.enum([
		"action",
		"token",
		"ability",
		"character",
		"special",
		"gadget",
		"upgrade",
		"target"
	]),
	token: A.optional(),
	ability: e.int().optional(),
	character: e.string().optional(),
	target: e.int().optional(),
	nameKey: e.string().optional(),
	payment: ae.optional(),
	amount: e.number().optional()
}), ce = e.object({
	phase: e.enum([
		"select",
		"watchtower",
		"preparation",
		"combat",
		"powerUp",
		"done"
	]),
	round: e.int(),
	first: e.int(),
	active: e.int().nullable(),
	prompt: e.string().nullable(),
	expansion: e.boolean(),
	challenge: e.int(),
	remainingChallenges: e.int(),
	market: e.array(A),
	marketRemaining: e.int(),
	clay: e.boolean(),
	seats: e.array(e.object({
		rid: e.string(),
		character: e.string(),
		team: e.int(),
		hp: e.int().nonnegative(),
		injured: e.boolean(),
		defeated: e.boolean(),
		bagCount: e.int(),
		bagContents: e.array(A),
		draw: e.array(A),
		discard: e.array(A),
		stored: e.array(e.object({
			token: A,
			release: e.int(),
			place: e.string()
		})),
		supply: e.array(A),
		reverse: A.nullable(),
		marks: e.record(e.string(), e.number()),
		exhausted: e.record(e.string(), e.number()),
		upgrades: e.array(e.string()),
		bonuses: e.array(ie),
		spent: e.array(e.string()),
		plans: e.array(j),
		activated: e.array(e.int()),
		resources: e.int(),
		pool: e.object({
			normal: e.int(),
			indefensible: e.int()
		}),
		contracts: e.array(e.int()),
		nonCrisisDrawn: e.int(),
		tokensDrawn: e.int(),
		stopped: e.boolean(),
		crisis: e.boolean(),
		handCount: e.int(),
		deferred: e.int()
	})),
	hit: e.object({
		source: e.int(),
		target: e.int(),
		normal: e.int(),
		indefensible: e.int(),
		kind: e.string(),
		allowDefer: e.boolean()
	}).nullable(),
	logs: e.array(e.object({
		key: e.string(),
		params: e.record(e.string(), e.union([e.string(), e.number()])),
		actor: e.int().optional(),
		target: e.int().optional(),
		token: A.optional()
	})),
	winner: e.array(e.string())
}), le = e.object({
	choices: e.array(se),
	hand: e.array(e.string()),
	peek: e.array(e.int()),
	units: e.array(ie),
	canAllocate: e.boolean(),
	paymentContext: e.object({
		character: e.string(),
		noSubstitution: e.boolean(),
		redAsCombat: e.boolean(),
		escape: e.int(),
		imitate: e.boolean()
	})
}), ue = {
	id: "brave-and-bold",
	tier: "alpha",
	mechanics: ["deck-bag-building", "push-your-luck"],
	interactionTags: ["team-based"],
	nameKey: "games.brave-and-bold.name",
	descKey: "games.brave-and-bold.desc",
	rulesKey: "games.brave-and-bold.rules",
	icon: "🦸",
	iconImg: "games/brave-and-bold.webp",
	rulesUrl: { en: "https://resurrection.games/cdn/shop/files/Brave_Bold_Rulebook.pdf?v=7256289048056738369" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [2],
	playerRange: (e) => {
		let t = k.safeParse(e).data?.mode, n = t === "teams" ? 4 : t === "league" ? 6 : 2;
		return {
			min: n,
			max: n
		};
	},
	accent: "#edc12d",
	releasedAt: "2026-11-07T01:30:00+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover",
	botDelayMs: 500
}, M = [
	{
		faction: "hero",
		start: "X3 R4 C2 A1 E2",
		specials: {
			darkKnight: 1,
			explosive: 2,
			strategist: 3
		},
		bonus: [
			"R2",
			"A1",
			"R1",
			"C1",
			"gadget1",
			"E1"
		],
		abilities: [
			{
				cost: "C C C C",
				damage: 6,
				nameKey: "games.brave-and-bold.ability_batman_0"
			},
			{
				cost: "C C E E",
				damage: 0,
				dynamic: "resourcePlusGadgets",
				nameKey: "games.brave-and-bold.ability_batman_1"
			},
			{
				cost: "R R A E",
				damage: 3,
				gadgetSelect: 3,
				nameKey: "games.brave-and-bold.ability_batman_2"
			},
			{
				cost: "E E E E|F",
				damage: 4,
				marks: ["darkKnight", "strategist"],
				nameKey: "games.brave-and-bold.ability_batman_3"
			},
			{
				cost: "C R E A",
				damage: 5,
				resource: 3,
				nameKey: "games.brave-and-bold.ability_batman_4"
			},
			{
				cost: "C R E A F",
				damage: 8,
				marks: ["explosive"],
				group: 4,
				nameKey: "games.brave-and-bold.ability_batman_5"
			},
			{
				cost: "E E E E E|F",
				damage: 12,
				marks: [
					"darkKnight",
					"explosive",
					"strategist",
					"strategist"
				],
				gadgetSelect: "any",
				finisher: !0,
				nameKey: "games.brave-and-bold.ability_batman_6"
			}
		],
		id: "batman",
		nameKey: "games.brave-and-bold.character_batman"
	},
	{
		faction: "hero",
		start: "X3 R4 C3 A1 E2 S2",
		specials: {
			strength: 1,
			flight: 1,
			recharge: 1,
			senses: 3
		},
		bonus: [
			"R2",
			"A1",
			"R1",
			"C1",
			"F1",
			"E1"
		],
		abilities: [
			{
				cost: "C C C C",
				damage: 6,
				nameKey: "games.brave-and-bold.ability_superman_0"
			},
			{
				cost: "C C E E",
				damage: 4,
				indefensible: !0,
				marks: ["flight"],
				nameKey: "games.brave-and-bold.ability_superman_1"
			},
			{
				cost: "S S S",
				damage: 5,
				marks: ["strength"],
				nameKey: "games.brave-and-bold.ability_superman_2"
			},
			{
				cost: "E E E E|F",
				damage: 7,
				marks: ["recharge"],
				nameKey: "games.brave-and-bold.ability_superman_3"
			},
			{
				cost: "C R E A",
				damage: 6,
				marks: ["senses"],
				nameKey: "games.brave-and-bold.ability_superman_4"
			},
			{
				cost: "C R E A F",
				damage: 8,
				marks: ["senses", "senses"],
				group: 4,
				nameKey: "games.brave-and-bold.ability_superman_5"
			},
			{
				cost: "E E E E E|F",
				damage: 13,
				marks: [
					"strength",
					"flight",
					"recharge",
					"senses"
				],
				holdKryptonite: !0,
				finisher: !0,
				nameKey: "games.brave-and-bold.ability_superman_6"
			}
		],
		id: "superman",
		nameKey: "games.brave-and-bold.character_superman"
	},
	{
		faction: "hero",
		start: "X3 R2 C3 A2 E2",
		specials: {
			lasso: 1,
			bracelets: 1,
			wrath: 1
		},
		bonus: [
			"R2",
			"C1",
			"R1",
			"A1",
			"heal2",
			"E1"
		],
		abilities: [
			{
				cost: "C C C E",
				damage: 6,
				nameKey: "games.brave-and-bold.ability_wonderWoman_0"
			},
			{
				cost: "C A A",
				damage: 3,
				marks: ["lasso"],
				nameKey: "games.brave-and-bold.ability_wonderWoman_1"
			},
			{
				cost: "C C E F",
				damage: 4,
				indefensible: !0,
				marks: ["bracelets"],
				nameKey: "games.brave-and-bold.ability_wonderWoman_2"
			},
			{
				cost: "C C A|C R|C",
				damage: 7,
				marks: ["wrath"],
				nameKey: "games.brave-and-bold.ability_wonderWoman_3"
			},
			{
				cost: "C R E A",
				damage: 4,
				indefensible: !0,
				marks: ["bracelets"],
				nameKey: "games.brave-and-bold.ability_wonderWoman_4"
			},
			{
				cost: "C R E A F",
				damage: 3,
				marks: ["bracelets"],
				group: 4,
				nameKey: "games.brave-and-bold.ability_wonderWoman_5"
			},
			{
				cost: "E E E E E|AA",
				damage: 12,
				marks: [
					"lasso",
					"bracelets",
					"wrath"
				],
				finisher: !0,
				nameKey: "games.brave-and-bold.ability_wonderWoman_6"
			}
		],
		id: "wonderWoman",
		nameKey: "games.brave-and-bold.character_wonderWoman"
	},
	{
		faction: "hero",
		start: "X3 R3 C2 A2 E2 W4",
		specials: {
			ahead: 2,
			hitFirst: 1,
			analysis: 2,
			reopen: 1
		},
		bonus: [
			"R2",
			"A1",
			"R1",
			"C1",
			"W1",
			"E1"
		],
		abilities: [
			{
				cost: "C C A W",
				damage: 5,
				nameKey: "games.brave-and-bold.ability_flash_0"
			},
			{
				cost: "A A R R",
				damage: 6,
				marks: ["ahead"],
				nameKey: "games.brave-and-bold.ability_flash_1"
			},
			{
				cost: "C C E A",
				damage: 4,
				indefensible: !0,
				marks: ["hitFirst"],
				nameKey: "games.brave-and-bold.ability_flash_2"
			},
			{
				cost: "A A F F",
				damage: 0,
				heal: 2,
				marks: ["analysis"],
				nameKey: "games.brave-and-bold.ability_flash_3"
			},
			{
				cost: "C R E A",
				damage: 6,
				marks: ["reopen"],
				nameKey: "games.brave-and-bold.ability_flash_4"
			},
			{
				cost: "C R E A F",
				damage: 8,
				marks: ["analysis", "reopen"],
				group: 4,
				nameKey: "games.brave-and-bold.ability_flash_5"
			},
			{
				cost: "E E E E E|AA",
				damage: 11,
				marks: [
					"ahead",
					"hitFirst",
					"analysis",
					"reopen"
				],
				finisher: !0,
				nameKey: "games.brave-and-bold.ability_flash_6"
			}
		],
		id: "flash",
		nameKey: "games.brave-and-bold.character_flash"
	},
	{
		faction: "villain",
		start: "X3 R3 C3 A1 E2 B2 U1 D1",
		specials: {
			manipulate: 1,
			subvert: 2,
			destiny: 2,
			fate: 1
		},
		bonus: [
			"R2",
			"damage1",
			"R1",
			"C1",
			"B1",
			"E1"
		],
		abilities: [
			{
				cost: "C C C C",
				damage: 5,
				nameKey: "games.brave-and-bold.ability_darkseid_0"
			},
			{
				cost: "C C E E",
				damage: 2,
				marks: ["subvert"],
				nameKey: "games.brave-and-bold.ability_darkseid_1"
			},
			{
				cost: "C B B B",
				damage: 0,
				dynamic: "matchPool",
				marks: ["fate"],
				nameKey: "games.brave-and-bold.ability_darkseid_2"
			},
			{
				cost: "E E E E|CC",
				damage: 6,
				indefensible: !0,
				marks: ["manipulate"],
				nameKey: "games.brave-and-bold.ability_darkseid_3"
			},
			{
				cost: "C R E A",
				damage: 5,
				marks: ["destiny"],
				nameKey: "games.brave-and-bold.ability_darkseid_4"
			},
			{
				cost: "C R E A F",
				damage: 6,
				marks: ["destiny", "destiny"],
				group: 4,
				nameKey: "games.brave-and-bold.ability_darkseid_5"
			},
			{
				cost: "E E E E E|AA",
				damage: 13,
				marks: [
					"manipulate",
					"subvert",
					"destiny",
					"fate"
				],
				finisher: !0,
				nameKey: "games.brave-and-bold.ability_darkseid_6"
			}
		],
		id: "darkseid",
		nameKey: "games.brave-and-bold.character_darkseid"
	},
	{
		faction: "villain",
		start: "X3 R4 C1 A2 F4 E2",
		specials: {
			upperHand: 1,
			mechano: 2,
			totality: 1
		},
		bonus: [
			"R2",
			"A1",
			"R1",
			"C1",
			"heal2",
			"E1"
		],
		abilities: [
			{
				cost: "C C C R",
				damage: 5,
				nameKey: "games.brave-and-bold.ability_lex_0"
			},
			{
				cost: "F F F A",
				damage: 0,
				selfDamage: 2,
				marks: ["totality"],
				nameKey: "games.brave-and-bold.ability_lex_1"
			},
			{
				cost: "F F C",
				damage: 3,
				indefensible: !0,
				nameKey: "games.brave-and-bold.ability_lex_2"
			},
			{
				cost: "E E E E|RR",
				damage: 0,
				heal: 5,
				marks: ["upperHand"],
				nameKey: "games.brave-and-bold.ability_lex_3"
			},
			{
				cost: "F R E A",
				damage: 4,
				indefensible: !0,
				marks: ["mechano"],
				nameKey: "games.brave-and-bold.ability_lex_4"
			},
			{
				cost: "F R E A C",
				damage: 6,
				marks: ["mechano", "mechano"],
				group: 4,
				nameKey: "games.brave-and-bold.ability_lex_5"
			},
			{
				cost: "E E E E E|FF",
				damage: 10,
				marks: [
					"totality",
					"upperHand",
					"mechano"
				],
				finisher: !0,
				nameKey: "games.brave-and-bold.ability_lex_6"
			}
		],
		id: "lex",
		nameKey: "games.brave-and-bold.character_lex"
	},
	{
		faction: "villain",
		start: "X3 R2 C3 A2 E2 H2",
		specials: {
			distance: 1,
			escape: 2,
			scent: 2,
			fast: 1
		},
		bonus: [
			"R2",
			"C1",
			"R1",
			"A1",
			"damage2",
			"E1"
		],
		abilities: [
			{
				cost: "C C C C",
				damage: 6,
				nameKey: "games.brave-and-bold.ability_cheetah_0"
			},
			{
				cost: "C C E F",
				damage: 4,
				indefensible: !0,
				marks: ["scent"],
				nameKey: "games.brave-and-bold.ability_cheetah_1"
			},
			{
				cost: "C E A",
				damage: 3,
				marks: ["escape"],
				nameKey: "games.brave-and-bold.ability_cheetah_2"
			},
			{
				cost: "E E E A",
				damage: 7,
				marks: ["fast"],
				nameKey: "games.brave-and-bold.ability_cheetah_3"
			},
			{
				cost: "C R E A",
				damage: 4,
				indefensible: !0,
				marks: ["scent"],
				nameKey: "games.brave-and-bold.ability_cheetah_4"
			},
			{
				cost: "C R E A F",
				damage: 8,
				marks: ["fast"],
				group: 4,
				nameKey: "games.brave-and-bold.ability_cheetah_5"
			},
			{
				cost: "E E E E E|FF",
				damage: 12,
				marks: [
					"distance",
					"escape",
					"scent",
					"fast"
				],
				finisher: !0,
				nameKey: "games.brave-and-bold.ability_cheetah_6"
			}
		],
		id: "cheetah",
		nameKey: "games.brave-and-bold.character_cheetah"
	},
	{
		faction: "villain",
		start: "X3 R2 C1 E3 M4 I3",
		specials: {
			living: 3,
			predatory: 1,
			imitation: 1
		},
		bonus: [
			"R2",
			"M1",
			"F1",
			"R1",
			"I1",
			"E1"
		],
		abilities: [
			{
				cost: "C M",
				damage: 0,
				dynamic: "mass",
				extraMass: !0,
				nameKey: "games.brave-and-bold.ability_clayface_0"
			},
			{
				cost: "E E M I",
				damage: 2,
				extraResponse: 1,
				marks: ["living"],
				nameKey: "games.brave-and-bold.ability_clayface_1"
			},
			{
				cost: "C C E I",
				damage: 0,
				indefensible: !0,
				dynamic: "lastTaken",
				marks: ["imitation"],
				nameKey: "games.brave-and-bold.ability_clayface_2"
			},
			{
				cost: "F M M I",
				damage: 5,
				marks: ["predatory"],
				nameKey: "games.brave-and-bold.ability_clayface_3"
			},
			{
				cost: "C R E F",
				damage: 0,
				recoverClay: !0,
				marks: ["imitation"],
				nameKey: "games.brave-and-bold.ability_clayface_4"
			},
			{
				cost: "C R E F A",
				damage: 0,
				heal: 3,
				group: 4,
				nameKey: "games.brave-and-bold.ability_clayface_5"
			},
			{
				cost: "E E E E E|FF",
				damage: 15,
				marks: [
					"living",
					"predatory",
					"imitation"
				],
				opponentChoice: !0,
				finisher: !0,
				nameKey: "games.brave-and-bold.ability_clayface_6"
			}
		],
		id: "clayface",
		nameKey: "games.brave-and-bold.character_clayface"
	},
	{
		faction: "hero",
		expansion: !0,
		start: "X3 R4 C3 A1 E2 Y1 Z1",
		specials: {
			rage: 2,
			fury: 1,
			daughter: 1,
			companion: 2
		},
		bonus: [
			"R2",
			"C1",
			"R1",
			"A1",
			"heal2",
			"E1"
		],
		abilities: [
			{
				cost: "C C C Y",
				damage: 6,
				nameKey: "games.brave-and-bold.ability_supergirl_0"
			},
			{
				cost: "Z Z E F",
				damage: 4,
				indefensible: !0,
				marks: ["fury"],
				nameKey: "games.brave-and-bold.ability_supergirl_1"
			},
			{
				cost: "C E A",
				damage: 3,
				gain: ["Z"],
				marks: ["rage"],
				nameKey: "games.brave-and-bold.ability_supergirl_2"
			},
			{
				cost: "E E Y Y",
				damage: 6,
				gain: ["Y"],
				marks: ["daughter"],
				nameKey: "games.brave-and-bold.ability_supergirl_3"
			},
			{
				cost: "C R E Z",
				damage: 4,
				indefensible: !0,
				gain: ["Y"],
				nameKey: "games.brave-and-bold.ability_supergirl_4"
			},
			{
				cost: "C R E Z A",
				damage: 6,
				gain: ["Y", "Z"],
				group: 4,
				nameKey: "games.brave-and-bold.ability_supergirl_5"
			},
			{
				cost: "E E E E E|YY",
				damage: 12,
				marks: [
					"rage",
					"fury",
					"daughter",
					"companion"
				],
				finisher: !0,
				nameKey: "games.brave-and-bold.ability_supergirl_6"
			}
		],
		id: "supergirl",
		nameKey: "games.brave-and-bold.character_supergirl"
	},
	{
		faction: "villain",
		expansion: !0,
		start: "X3 R3 C4 F1 E2 U1",
		specials: {
			mainMan: 2,
			looseEnds: 1,
			double: 1,
			regeneration: 1
		},
		bonus: [
			"R2",
			"C1",
			"R1",
			"heal2",
			"C1",
			"E1"
		],
		abilities: [
			{
				cost: "C C C C",
				damage: 5,
				nameKey: "games.brave-and-bold.ability_lobo_0"
			},
			{
				cost: "C E R",
				damage: 3,
				marks: ["mainMan"],
				nameKey: "games.brave-and-bold.ability_lobo_1"
			},
			{
				cost: "R R E FF|CC",
				damage: 5,
				marks: ["double"],
				nameKey: "games.brave-and-bold.ability_lobo_2"
			},
			{
				cost: "E|OO E|OO E|CC E|RF",
				damage: 7,
				marks: ["looseEnds"],
				nameKey: "games.brave-and-bold.ability_lobo_3"
			},
			{
				cost: "C R E F",
				damage: 3,
				indefensible: !0,
				marks: ["mainMan"],
				nameKey: "games.brave-and-bold.ability_lobo_4"
			},
			{
				cost: "C R E F A",
				damage: 2,
				heal: 3,
				marks: ["mainMan"],
				group: 4,
				nameKey: "games.brave-and-bold.ability_lobo_5"
			},
			{
				cost: "E E E E E|CC",
				damage: 12,
				marks: [
					"double",
					"regeneration",
					"mainMan",
					"looseEnds"
				],
				finisher: !0,
				nameKey: "games.brave-and-bold.ability_lobo_6"
			}
		],
		id: "lobo",
		nameKey: "games.brave-and-bold.character_lobo"
	}
], de = [
	{
		id: 212,
		character: "batman",
		textKey: "games.brave-and-bold.challenge_212"
	},
	{
		id: 211,
		character: "batman",
		textKey: "games.brave-and-bold.challenge_211"
	},
	{
		id: 210,
		character: "batman",
		textKey: "games.brave-and-bold.challenge_210"
	},
	{
		id: 209,
		character: "batman",
		textKey: "games.brave-and-bold.challenge_209"
	},
	{
		id: 101,
		character: "batman",
		textKey: "games.brave-and-bold.challenge_101"
	},
	{
		id: 247,
		character: "superman",
		textKey: "games.brave-and-bold.challenge_247"
	},
	{
		id: 246,
		character: "superman",
		textKey: "games.brave-and-bold.challenge_246"
	},
	{
		id: 245,
		character: "superman",
		textKey: "games.brave-and-bold.challenge_245"
	},
	{
		id: 243,
		character: "superman",
		textKey: "games.brave-and-bold.challenge_243"
	},
	{
		id: 244,
		character: "superman",
		textKey: "games.brave-and-bold.challenge_244"
	},
	{
		id: 266,
		character: "wonderWoman",
		textKey: "games.brave-and-bold.challenge_266"
	},
	{
		id: 264,
		character: "wonderWoman",
		textKey: "games.brave-and-bold.challenge_264"
	},
	{
		id: 265,
		character: "wonderWoman",
		textKey: "games.brave-and-bold.challenge_265"
	},
	{
		id: 263,
		character: "wonderWoman",
		textKey: "games.brave-and-bold.challenge_263"
	},
	{
		id: 262,
		character: "wonderWoman",
		textKey: "games.brave-and-bold.challenge_262"
	},
	{
		id: 250,
		character: "flash",
		textKey: "games.brave-and-bold.challenge_250"
	},
	{
		id: 252,
		character: "flash",
		textKey: "games.brave-and-bold.challenge_252"
	},
	{
		id: 253,
		character: "flash",
		textKey: "games.brave-and-bold.challenge_253"
	},
	{
		id: 254,
		character: "flash",
		textKey: "games.brave-and-bold.challenge_254"
	},
	{
		id: 251,
		character: "flash",
		textKey: "games.brave-and-bold.challenge_251"
	},
	{
		id: 233,
		character: "darkseid",
		textKey: "games.brave-and-bold.challenge_233"
	},
	{
		id: 232,
		character: "darkseid",
		textKey: "games.brave-and-bold.challenge_232"
	},
	{
		id: 231,
		character: "darkseid",
		textKey: "games.brave-and-bold.challenge_231"
	},
	{
		id: 230,
		character: "darkseid",
		textKey: "games.brave-and-bold.challenge_230"
	},
	{
		id: 229,
		character: "darkseid",
		textKey: "games.brave-and-bold.challenge_229"
	},
	{
		id: 238,
		character: "lex",
		textKey: "games.brave-and-bold.challenge_238"
	},
	{
		id: 240,
		character: "lex",
		textKey: "games.brave-and-bold.challenge_240"
	},
	{
		id: 239,
		character: "lex",
		textKey: "games.brave-and-bold.challenge_239"
	},
	{
		id: 236,
		character: "lex",
		textKey: "games.brave-and-bold.challenge_236"
	},
	{
		id: 237,
		character: "lex",
		textKey: "games.brave-and-bold.challenge_237"
	},
	{
		id: 215,
		character: "cheetah",
		textKey: "games.brave-and-bold.challenge_215"
	},
	{
		id: 216,
		character: "cheetah",
		textKey: "games.brave-and-bold.challenge_216"
	},
	{
		id: 217,
		character: "cheetah",
		textKey: "games.brave-and-bold.challenge_217"
	},
	{
		id: 218,
		character: "cheetah",
		textKey: "games.brave-and-bold.challenge_218"
	},
	{
		id: 219,
		character: "cheetah",
		textKey: "games.brave-and-bold.challenge_219"
	},
	{
		id: 222,
		character: "clayface",
		textKey: "games.brave-and-bold.challenge_222"
	},
	{
		id: 226,
		character: "clayface",
		textKey: "games.brave-and-bold.challenge_226"
	},
	{
		id: 224,
		character: "clayface",
		textKey: "games.brave-and-bold.challenge_224"
	},
	{
		id: 225,
		character: "clayface",
		textKey: "games.brave-and-bold.challenge_225"
	},
	{
		id: 223,
		character: "clayface",
		textKey: "games.brave-and-bold.challenge_223"
	},
	{
		id: 277,
		character: "supergirl",
		textKey: "games.brave-and-bold.challenge_277"
	},
	{
		id: 278,
		character: "supergirl",
		textKey: "games.brave-and-bold.challenge_278"
	},
	{
		id: 280,
		character: "supergirl",
		textKey: "games.brave-and-bold.challenge_280"
	},
	{
		id: 281,
		character: "supergirl",
		textKey: "games.brave-and-bold.challenge_281"
	},
	{
		id: 279,
		character: "supergirl",
		textKey: "games.brave-and-bold.challenge_279"
	},
	{
		id: 273,
		character: "lobo",
		textKey: "games.brave-and-bold.challenge_273"
	},
	{
		id: 272,
		character: "lobo",
		textKey: "games.brave-and-bold.challenge_272"
	},
	{
		id: 271,
		character: "lobo",
		textKey: "games.brave-and-bold.challenge_271"
	},
	{
		id: 270,
		character: "lobo",
		textKey: "games.brave-and-bold.challenge_270"
	},
	{
		id: 269,
		character: "lobo",
		textKey: "games.brave-and-bold.challenge_269"
	}
], N = {
	darkKnight: "games.brave-and-bold.special_darkKnight",
	explosive: "games.brave-and-bold.special_explosive",
	strategist: "games.brave-and-bold.special_strategist",
	strength: "games.brave-and-bold.special_strength",
	flight: "games.brave-and-bold.special_flight",
	recharge: "games.brave-and-bold.special_recharge",
	senses: "games.brave-and-bold.special_senses",
	lasso: "games.brave-and-bold.special_lasso",
	bracelets: "games.brave-and-bold.special_bracelets",
	wrath: "games.brave-and-bold.special_wrath",
	ahead: "games.brave-and-bold.special_ahead",
	hitFirst: "games.brave-and-bold.special_hitFirst",
	analysis: "games.brave-and-bold.special_analysis",
	reopen: "games.brave-and-bold.special_reopen",
	manipulate: "games.brave-and-bold.special_manipulate",
	subvert: "games.brave-and-bold.special_subvert",
	destiny: "games.brave-and-bold.special_destiny",
	fate: "games.brave-and-bold.special_fate",
	upperHand: "games.brave-and-bold.special_upperHand",
	mechano: "games.brave-and-bold.special_mechano",
	totality: "games.brave-and-bold.special_totality",
	distance: "games.brave-and-bold.special_distance",
	escape: "games.brave-and-bold.special_escape",
	scent: "games.brave-and-bold.special_scent",
	fast: "games.brave-and-bold.special_fast",
	living: "games.brave-and-bold.special_living",
	predatory: "games.brave-and-bold.special_predatory",
	imitation: "games.brave-and-bold.special_imitation",
	rage: "games.brave-and-bold.special_rage",
	fury: "games.brave-and-bold.special_fury",
	daughter: "games.brave-and-bold.special_daughter",
	companion: "games.brave-and-bold.special_companion",
	mainMan: "games.brave-and-bold.special_mainMan",
	looseEnds: "games.brave-and-bold.special_looseEnds",
	double: "games.brave-and-bold.special_double",
	regeneration: "games.brave-and-bold.special_regeneration"
}, fe = (e) => M.find((t) => t.id === e.character), P = (e) => e.seats.map((t, n) => (e.first + n) % e.seats.length).filter((t) => !e.seats[t].defeated), F = (e, t) => P(e).filter((n) => e.seats[n].team !== e.seats[t].team), pe = (e, t) => P(e).filter((n) => e.seats[n].team === e.seats[t].team), I = (e) => e.seats.some((e) => e.character === "clayface" && !e.defeated) || e.phase === "combat" && e.clayAttacker >= 0, me = (e) => e.draw.reduce((e, t) => e + E(t), 0), L = (e) => {
	let t = /* @__PURE__ */ new Set([...e.spent, ...e.plans.flatMap((e) => [...e.slots.flat(), ...e.extra])]);
	return [...O(e.draw), ...e.bonuses].filter((e) => !t.has(e.id));
}, R = (e) => [
	...e.bag,
	...e.draw,
	...e.discard
], he = (e) => e.draw.filter((t) => !E(t) && (!O([t]).length || O([t]).some((t) => !e.spent.includes(t.id)))), z = (e, t) => e.supply.some((e) => e.symbol === t), ge = (e, t) => e.filter((e) => e.symbol === t).reduce((e, t) => e + w(t), 0), B = (e, t) => e.flags[t] ?? 0, V = (e, t, n = 1) => {
	e.flags[t] = B(e, t) + n;
}, _e = (e, t) => e.challenge !== 210 && !(t.crisis && t.character === "clayface"), H = (e, t, n) => _e(e, t) && (t.marks[n] ?? 0) > 0;
function U(e, n) {
	if (n.length) return n.splice(t(e.seed, e.cursor++, n.length), 1)[0];
}
function W(e, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = t(e.seed, e.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
}
function ve(e, t, n = "basic") {
	return {
		id: e.serial++,
		symbol: t,
		kind: n
	};
}
function ye(e, t, n, r = {}, i, a) {
	e.logs.push({
		key: t,
		params: r,
		...n === void 0 ? {} : { actor: n },
		...i === void 0 ? {} : { target: i },
		...a ? { token: a } : {}
	}), e.logs.length > 120 && e.logs.shift();
}
function be(e, t, n, r = 1) {
	let i = e.seats[t];
	if (i.character === "clayface" && i.crisis) return;
	let a = Math.max(0, (fe(i).specials[n] ?? 0) - (i.exhausted[n] ?? 0)), o = i.marks[n] ?? 0;
	i.marks[n] = Math.min(a, o + r), i.marks[n] > o && x(e, {
		kind: "marker",
		rid: i.rid,
		data: {
			key: n,
			gain: !0
		}
	});
}
function xe(e, t, n) {
	let r = e.seats[t];
	r.marks[n] = Math.max(0, (r.marks[n] ?? 0) - 1), x(e, {
		kind: "marker",
		rid: r.rid,
		data: {
			key: n,
			gain: !1
		}
	}), V(r, "specialsUsed"), n === "wrath" && (r.exhausted[n] = 1);
}
function Se(e, t, n, r = "bag", i = !1) {
	let a = e.seats[t];
	if (e.challenge === 269 && !i) return;
	let o = a.supply.findIndex((e) => e.symbol === n);
	if (o < 0) return;
	let s = a.supply.splice(o, 1)[0];
	return a[r].push(s), S(e, a, s, `supply:${a.rid}`, `${r}:${a.rid}`), s;
}
function G(e, t, n, r) {
	for (let i of [
		e.draw,
		e.bag,
		e.discard
	]) {
		let a = i.findIndex((e) => e.id === t);
		if (a < 0) continue;
		let o = i.splice(a, 1)[0];
		e[n].push(o);
		let s = i === e.draw ? "draw" : i === e.bag ? "bag" : "discard", c = e.plans.find((e) => e.slots.flat().some((e) => e.startsWith(`${o.id}:`)));
		return S(r, e, o, c ? `ability:${e.rid}:${c.ability}` : `${s}:${e.rid}`, `${n}:${e.rid}`), o;
	}
}
function Ce(e, t, n) {
	e.spent.push(...t);
	for (let t of [...e.draw]) {
		let r = O([t]);
		r.length && r.every((t) => e.spent.includes(t.id)) && G(e, t.id, "discard", n);
	}
	if (B(e, "flightReturns")) for (let t of [...e.discard]) t.symbol === "S" && B(e, "flightReturns") > 0 && O([t]).every((t) => e.spent.includes(t.id)) && (G(e, t.id, "supply", n), V(e, "flightReturns", -1));
}
function we(e, t, n, r) {
	let i = e.seats[t];
	for (let t = 0; t < r; t++) i.bonuses.push({
		id: `b${e.serial++}`,
		symbol: n,
		token: null,
		part: 0
	});
}
function Te(e, t, n) {
	let r = e.seats[t];
	if (r.defeated || e.phase === "combat" && e.challenge === 250) return;
	let i = e.seats.length === 2 ? 60 : e.seats.length === 4 ? 40 : 35, a = Math.min(Math.max(0, n), i - r.hp);
	a <= 0 || (r.hp += a, x(e, {
		kind: "health",
		rid: r.rid,
		data: { n: a }
	}), ye(e, "games.brave-and-bold.logHeal", t, { n: a }));
}
function Ee(e, t, n) {
	let r = e.seats[t];
	if (r.hp === 0 || r.defeated || n <= 0) return;
	let i = r.hp, a = 0;
	if (r.character === "lobo" && (r.marks.regeneration ?? 0) > 0 && n >= r.hp - 1) {
		let i = Math.max(0, r.hp - 1);
		r.hp -= i, n -= i, r.hp += 10, a = 10, r.marks.regeneration = 0, r.exhausted.regeneration = 1, ye(e, "games.brave-and-bold.logRegenerate", t);
	}
	r.hp -= Math.min(r.hp, n);
	let o = i + a - r.hp;
	r.lastTaken = o, o && (x(e, {
		kind: "health",
		rid: r.rid,
		data: { n: -o }
	}), V(r, "tookDamage", o), ye(e, "games.brave-and-bold.logDamage", t, { n: o })), r.hp === 0 && (r.injured ? r.defeated = !0 : r.injured = !0, ye(e, r.defeated ? "games.brave-and-bold.logDefeated" : "games.brave-and-bold.logInjured", t));
}
function K(e) {
	let t = new Set(e.seats.filter((e) => !e.defeated).map((e) => e.team));
	if (t.size > 1) return e.seats[e.first].defeated && (e.first = P(e)[0]), !1;
	let n = [...t][0];
	return e.winner = e.seats.filter((e) => e.team === n).map((e) => e.rid), e.phase = "done", e.tasks = [], e.beat = 0, !0;
}
function De(e) {
	let t = [0, 0];
	for (let n of e.seats) t[n.team] += n.hp;
	let n = t[0] === t[1] ? e.seats[e.first].team : t[0] > t[1] ? 0 : 1;
	e.winner = e.seats.filter((e) => e.team === n).map((e) => e.rid), e.phase = "done", e.tasks = [], e.beat = 0;
}
function Oe(e, t) {
	let n = U(e, e.armoury);
	n ? e.market[t] = n : e.market.splice(t, 1);
}
function ke(e, t) {
	let n = e.seats[t];
	for (let t of [...R(n)]) (B(n, `temporary:${t.id}`) || t.symbol === "L" && n.discard.some((e) => e.id === t.id)) && G(n, t.id, "supply", e);
	if (n.character === "flash" && B(n, "speedSpent") > 2) for (let t = 0; t < 2; t++) {
		let t = R(n).find((e) => e.symbol === "W");
		t && G(n, t.id, "supply", e);
	}
	let r = R(n).filter(re).length, i = D(r), a = B(n, "extraCrisis") + (e.challenge === 231 ? B(n, "specialsUsed") : 0) + +(e.challenge === 272 && n.tokensDrawn >= 10);
	i = Math.min(8, i + a);
	let o = R(n).filter((e) => e.symbol === "X").length;
	for (; o < i && z(n, "X");) Se(e, t, "X", "bag", !0), o++;
	for (; o > i && n.character !== "cheetah";) G(n, R(n).find((e) => e.symbol === "X").id, "supply", e), o--;
	e.challenge === 251 && n.tokensDrawn >= 7 && B(n, "reduceCrisis") && o > 3 && G(n, R(n).find((e) => e.symbol === "X").id, "supply", e);
	for (let t of n.discard) S(e, n, t, `discard:${n.rid}`, `bag:${n.rid}`);
	for (let t of n.draw) S(e, n, t, `draw:${n.rid}`, `bag:${n.rid}`);
	n.bag.push(...n.discard, ...n.draw), n.discard = [], n.draw = [], W(e, n.bag);
}
var q = (e, t, n, r) => ({
	op: e,
	actor: t,
	...n === void 0 ? {} : { n },
	...r === void 0 ? {} : { text: r }
});
//#endregion
//#region src/games/brave-and-bold/payment.ts
function Ae(e, t, n) {
	let r = t.filter((t) => t.symbol === e).map((e) => [e.id]);
	if (n.noSubstitution) return r;
	if (T(e)) for (let i of t) (i.symbol === "U" || i.symbol === "L" || e === "R" && i.symbol === "O" || e === "C" && i.symbol === "Z" && n.redAsCombat) && r.push([i.id]);
	let i = (e) => {
		let n = t.filter((t) => e.includes(t.symbol));
		for (let e = 0; e < n.length; e++) for (let t = e + 1; t < n.length; t++) r.push([n[e].id, n[t].id]);
	};
	if (n.character === "superman" && i(["S"]), n.character === "flash" && e === "A" && i(["W"]), n.character === "clayface" && (T(e) || n.imitate && ![
		"E",
		"X",
		"V",
		"K",
		"D"
	].includes(e)) && i(["M", "I"]), n.character === "cheetah" && T(e) && n.escape > 0 && i(["H"]), n.character === "cheetah" && T(e)) {
		e === "R" && i(["H"]);
		let n = t.filter((e) => e.symbol === "H");
		for (let e = 0; e < n.length; e++) for (let t = e + 1; t < n.length; t++) for (let i = t + 1; i < n.length; i++) r.push([
			n[e].id,
			n[t].id,
			n[i].id
		]);
	}
	return r;
}
function je(e, t, n) {
	if (!e) return [[]];
	let r = [];
	for (let i of Ae(e[0], t, n)) {
		let a = t.filter((e) => !i.includes(e.id));
		for (let t of je(e.slice(1), a, n)) r.push([...i, ...t]);
	}
	return r;
}
function Me(e, t, n, r = "") {
	if (n.character !== "cheetah" || n.noSubstitution) return 0;
	let i = r.split(" ");
	return e.reduce((e, r, a) => {
		let o = t.filter((e) => r.includes(e.id)), s = {
			...n,
			escape: 0
		};
		return i[a]?.split("|").some((e) => je(e, o, s).some((e) => e.length === r.length)) ? e : e + Math.floor(o.filter((e) => e.symbol === "H").length / 2);
	}, 0);
}
function Ne(e, t, n, r) {
	let i = e.cost.split(" ");
	if (i.length !== t.slots.length) return !1;
	let a = [...t.slots.flat(), ...t.extra];
	if (new Set(a).size !== a.length || a.some((e) => !n.some((t) => t.id === e)) || t.extra.length && !e.extraMass || t.extra.some((e) => n.find((t) => t.id === e)?.symbol !== "M")) return !1;
	for (let e = 0; e < i.length; e++) {
		let a = t.slots[e], o = n.filter((e) => a.includes(e.id));
		if (!i[e].split("|").some((e) => je(e, o, r).some((e) => e.length === a.length && e.every((e) => a.includes(e))))) return !1;
	}
	return Me(t.slots, n, r, e.cost) <= r.escape;
}
function Pe(e, t, n, r, i = 24) {
	let a = [], o = e.cost.split(" "), s = (c, l, u) => {
		if (a.length >= i) return;
		if (c === o.length) {
			Me(u, n, r, e.cost) <= r.escape && a.push({
				ability: t,
				slots: u,
				extra: []
			});
			return;
		}
		let d = /* @__PURE__ */ new Set();
		for (let e of o[c].split("|")) for (let t of je(e, l, r)) {
			let e = t.map((e) => l.find((t) => t.id === e)?.symbol).sort().join("");
			if (!d.has(e) && (d.add(e), s(c + 1, l.filter((e) => !t.includes(e.id)), [...u, t]), a.length >= i)) return;
		}
	};
	return s(0, n, []), a;
}
//#endregion
//#region src/games/brave-and-bold/setup.ts
function Fe(e, t, n) {
	let r = {
		seats: [],
		seed: n,
		cursor: 0,
		serial: 0,
		revision: 0,
		round: 1,
		first: 0,
		phase: "select",
		expansion: e.expansion,
		challenge: 0,
		deck: [],
		challengeDiscard: [],
		market: [],
		armoury: [],
		tasks: [],
		beat: 0,
		logs: [],
		winner: [],
		marketPurchased: !1,
		clayAttacker: -1,
		clayResponse: 0,
		clayLast: null,
		turnOrder: [],
		hit: null
	}, i = t.length === 2 ? 60 : t.length === 4 ? 40 : 35;
	return r.seats = t.map((e, t) => ({
		rid: e,
		character: "",
		team: t % 2,
		hp: i,
		injured: !1,
		defeated: !1,
		bag: [],
		draw: [],
		discard: [],
		stored: [],
		supply: [],
		removed: [],
		reverse: null,
		marks: {},
		exhausted: {},
		upgrades: [],
		gadgetDeck: [],
		hand: [],
		peek: [],
		bonuses: [],
		spent: [],
		plans: [],
		activated: [],
		contributions: [],
		flags: {},
		resources: 0,
		pool: {
			normal: 0,
			indefensible: 0
		},
		contracts: [],
		nonCrisisDrawn: 0,
		tokensDrawn: 0,
		stopped: !1,
		crisis: !1,
		bought: [],
		lastTaken: 0,
		deferred: 0
	})), r.tasks = t.map((e, t) => q("select", t)), r.tasks.push({ op: "startGame" }), r;
}
function Ie(e, t, n) {
	let r = e.seats[t];
	r.character = n;
	let i = fe(r), a = {
		C: 8,
		R: n === "batman" ? 14 : 10,
		A: 6,
		F: ["superman", "lex"].includes(n) ? 9 : 5,
		E: 8,
		X: 8,
		U: 5,
		V: 1
	};
	Object.assign(a, {
		superman: {
			S: 6,
			K: 1
		},
		flash: { W: 6 },
		darkseid: {
			B: 6,
			D: 1
		},
		lex: { L: 4 },
		cheetah: { H: 10 },
		clayface: {
			M: 6,
			I: 5
		},
		supergirl: {
			Y: 4,
			Z: 4
		},
		lobo: { O: 6 }
	}[n] ?? {});
	for (let [t, n] of Object.entries(a)) for (let i = 0; i < n; i++) r.supply.push(ve(e, t));
	for (let e of i.start.split(" ")) {
		let t = e[0];
		for (let n = 0; n < Number(e.slice(1)); n++) {
			let e = r.supply.findIndex((e) => e.symbol === t);
			e >= 0 && r.bag.push(r.supply.splice(e, 1)[0]);
		}
	}
	n === "darkseid" && (r.hp -= 10), n === "batman" && (r.gadgetDeck = [
		"batarang",
		"batarang",
		"batarang",
		"batarang",
		"smoke",
		"smoke",
		"smoke",
		"smoke",
		"contingency",
		"contingency",
		"grapple",
		"pulse"
	], W(e, r.gadgetDeck));
}
function Le(e) {
	e.deck = de.filter((t) => e.seats.some((e) => e.character === t.character)).map((e) => e.id), W(e, e.deck);
	for (let t = 0; t < 2; t++) {
		for (let t of [
			"C",
			"R",
			"A"
		]) for (let n = 0; n < 4; n++) e.armoury.push(ve(e, t, "double"));
		for (let t of [
			"C",
			"R",
			"A",
			"F"
		]) for (let n = 0; n < (t === "F" ? 5 : 4); n++) e.armoury.push(ve(e, t, "power"));
	}
	e.armoury.push(ve(e, "C", "critical"), ve(e, "A", "critical")), W(e, e.armoury), e.market = e.armoury.splice(0, 6), e.challenge = e.deck.shift(), e.challengeDiscard.push(e.challenge);
	let t = de.find((t) => t.id === e.challenge).character;
	e.first = e.seats.findIndex((e) => e.character === t), e.tasks.unshift({ op: "challengeStart" }, { op: "preparationStart" });
}
function Re(e, t) {
	return M.filter((n) => (!n.expansion || e.expansion) && !e.seats.some((e) => e.character === n.id) && (e.seats.length === 2 || n.faction === (e.seats[t].team === 0 ? "hero" : "villain")));
}
//#endregion
//#region src/games/brave-and-bold/flow.ts
var ze = /* @__PURE__ */ new Set(/* @__PURE__ */ "select.upgrade.watchStart.recoveryChoice.prepStart.prepare.drawChoice.respondDraw.prepEnd.combatStart.allocate.activate.poolModifier.poolReady.modifyAttack.splitAttack.boost.defend.finisher.powerStart.resupply.refresh.endTurn.rebalanceChoice.afterRebalance.afterResupply.search.gadgetChoice.handLimit.upperHand.declare.contract.clayCombat.clayFinisherChoice.healSplit.crisisAbility.marketSelect".split(".")), Be = (e, t, n = !1) => ({
	character: t.character,
	noSubstitution: e.challenge === 211,
	redAsCombat: B(t, "fury") > 0,
	escape: t.marks.escape ?? 0,
	imitate: n
});
function Ve(e, t) {
	return e.challenge === 264 ? e.seats.reduce((e, t) => e + t.draw.filter((e) => e.symbol === "X").length, 0) + e.seats[t].draw.filter((e) => e.symbol === "K").length * 2 : me(e.seats[t]);
}
function J(e, ...t) {
	e.tasks.unshift(...t);
}
function He(e, t, n, r = 0, i = "special", a) {
	n + r <= 0 || !F(e, t).length || (e.challenge === 246 && (r += n, n = 0), J(e, {
		op: i === "ability" && I(e) ? "modifyAttack" : "splitAttack",
		actor: t,
		normal: n,
		indefensible: r,
		text: i,
		...a === void 0 ? {} : { target: a }
	}));
}
function Ue(e, t, n, r = 0) {
	let i = Se(e, t, n);
	i && (V(e.seats[t], `temporary:${i.id}`), r && (e.seats[t].flags[`challengeTemp:${i.id}`] = r));
}
function We(e, t, n = 1) {
	let r = e.seats[t];
	for (let t = 0; t < n; t++) r.gadgetDeck.length && (r.hand.push(r.gadgetDeck.shift()), x(e, {
		kind: "gadget",
		rid: r.rid,
		data: { gain: !0 }
	}));
	r.hand.length > 3 && J(e, q("handLimit", t));
}
function Ge(e, t) {
	let n = e.seats[t], r = fe(n), i = [
		4,
		7,
		10,
		11,
		13,
		14
	];
	for (let a = 0; a < i.length; a++) {
		if (n.nonCrisisDrawn < i[a]) continue;
		let o = r.bonus[a];
		if (n.crisis && !["C", "R"].includes(o[0]) && !o.startsWith("damage")) continue;
		let s = o[0], c = Number(o.slice(1));
		T(s) || [
			"E",
			"M",
			"I",
			"W",
			"B"
		].includes(s) ? we(e, t, s, c) : o === "heal2" ? Te(e, t, 2) : o === "gadget1" ? We(e, t) : o.startsWith("damage") && V(n, "damageBonus", Number(o.slice(6)));
	}
	if (e.challenge === 229 && we(e, t, "R", 3), e.challenge === 209) {
		let e = 2;
		n.bonuses = n.bonuses.filter((t) => t.symbol === "R" && e > 0 ? (e--, !1) : !0);
	}
	e.challenge === 236 && F(e, t).every((t) => !e.seats[t].crisis) && we(e, t, "R", 2), e.challenge === 281 && Ve(e, t) === 2 && V(n, "damageBonus", 2), n.upgrades.includes("training") && B(n, "combatDrawn") === 2 && we(e, t, "C", 1);
}
function Ke(e, t) {
	let n = e.seats[t];
	if (!n.bag.length) {
		n.stopped = !0, J(e, {
			op: "nextDraw",
			actor: t
		});
		return;
	}
	if (B(n, "manipulate") && e.challenge !== 233 && n.bag.length > 1) {
		J(e, {
			op: "drawChoice",
			actor: t,
			tokens: [U(e, n.bag), U(e, n.bag)],
			text: "manipulate"
		});
		return;
	}
	J(e, {
		op: "drawToken",
		actor: t,
		tokens: [U(e, n.bag)]
	});
}
function qe(e, t, n) {
	let r = e.seats[t];
	r.draw.push(n), r.tokensDrawn++, n.symbol === "C" && V(r, "combatDrawn", w(n)), S(e, r, n, `bag:${r.rid}`, `token:${n.id}`), E(n) || r.nonCrisisDrawn++, ye(e, "games.brave-and-bold.logDraw", t, {}, void 0, n), J(e, {
		op: "beat",
		n: 380
	}, ...P(e).map((e) => ({
		op: "respondDraw",
		actor: e,
		target: t,
		id: n.id
	})), {
		op: "drawFinalize",
		actor: t,
		id: n.id
	}, {
		op: "beat",
		n: 380
	});
}
function Je(e, t, n) {
	let r = e.seats[t], i = r.draw.find((e) => e.id === n);
	if (i) {
		if (E(i) && V(r, "crisisDrawn", E(i)), i.symbol === "V" && (r.reverse = i, r.draw = r.draw.filter((e) => e.id !== n)), i.kind === "power" && i.symbol === "C" && Te(e, t, 2), r.character === "supergirl" && (i.symbol === "Y" && Te(e, t, 1), i.symbol === "Z" && Ee(e, t, 1)), i.kind === "power" && i.symbol === "F" && e.challenge !== 233 && r.draw.some((e) => e.symbol === "X") && J(e, {
			op: "search",
			actor: t,
			text: "focusCrisis",
			names: r.draw.filter((e) => e.symbol === "X").map((e) => String(e.id))
		}), i.kind === "power" && i.symbol === "A" && e.challenge !== 233 && r.bag.length) {
			let n = [U(e, r.bag)];
			r.bag.length && n.push(U(e, r.bag)), J(e, {
				op: "drawChoice",
				actor: t,
				tokens: n,
				text: "agility"
			});
		}
		for (let t of P(e)) Ve(e, t) >= 3 && !e.seats[t].crisis && (e.seats[t].crisis = !0, e.seats[t].stopped = !0, ye(e, "games.brave-and-bold.logCrisis", t));
		K(e);
	}
}
function Ye(e, t) {
	let n = e.seats[t];
	if (B(n, "skipRecovery")) {
		n.injured && n.hp === 0 && (n.defeated = !0, K(e));
		return;
	}
	let r = [], i = n.character === "flash" || n.character === "darkseid" ? 3 : 4;
	for (; i > 0 && n.bag.length;) {
		let t = U(e, n.bag);
		r.push(t), (n.character !== "lex" || t.symbol !== "F") && i--;
	}
	let a = (e) => ge(r, e), o = [], s = (n, r = 1) => {
		for (let i = 0; i < r; i++) {
			let r = Math.max(0, n - +(e.challenge === 219));
			r && o.push({
				op: "healSplit",
				actor: t,
				n: r
			});
		}
	}, c = (e) => {
		e && o.push({
			op: "splitAttack",
			actor: t,
			normal: e,
			indefensible: 0,
			text: "recovery"
		});
	}, l = /* @__PURE__ */ new Set();
	switch (n.character) {
		case "batman":
			s(3, a("E"));
			for (let n = 0; n < a("A"); n++) be(e, t, "strategist");
			We(e, t, Math.floor(a("R") / 2));
			break;
		case "superman":
			s(3, a("E")), c(2 * a("C"));
			for (let e = 0; e < a("S"); e++) o.push({
				op: "search",
				actor: t,
				text: "temporaryBasic"
			});
			break;
		case "wonderWoman":
			s(3, a("E")), c(a("C"));
			for (let e = 0; e < a("X"); e++) o.push({
				op: "recoveryChoice",
				actor: t,
				text: "wonderWoman"
			});
			break;
		case "flash":
			s(2), s(2, a("E") + a("A"));
			for (let e = 0; e < Math.floor(a("W") / 2); e++) o.push({
				op: "search",
				actor: t,
				text: "flashRecovery"
			});
			break;
		case "darkseid":
			s(4), s(2, a("E"));
			for (let e of r) e.symbol === "B" && (n.draw.push(e), l.add(e.id));
			break;
		case "lex":
			s(3, a("E")), c(a("L"));
			break;
		case "cheetah":
			s(2, r.filter((e) => e.symbol !== "H").length);
			for (let e = 0; e < a("H"); e++) o.push({
				op: "recoveryChoice",
				actor: t,
				text: "cheetah"
			});
			break;
		case "clayface":
			c(2 * (a("C") + a("E"))), n.injured && s(8, a("R") + a("A"));
			for (let e of r) ["M", "I"].includes(e.symbol) && (l.add(e.id), o.push({
				op: "recoveryChoice",
				actor: t,
				text: "clayface",
				tokens: [e]
			}));
			break;
		case "supergirl":
			s(3, a("E") + a("Y")), c(a("Z"));
			for (let e of r) e.symbol === "Z" && (n.draw.push(e), l.add(e.id));
			for (let e = 0; e < Math.min(a("Y"), a("Z")); e++) o.push({
				op: "recoveryChoice",
				actor: t,
				text: "supergirl"
			});
			break;
		case "lobo":
			s(3, a("E")), c(2 * a("X"));
			for (let e = 0; e < a("O"); e++) o.push(q("contract", t));
	}
	s(2, r.filter((e) => e.kind === "power" && e.symbol === "C").length);
	for (let [t, i] of r.entries()) l.has(i.id) ? S(e, n, i, `bag:${n.rid}`, `draw:${n.rid}`) : (n.bag.push(i), x(e, {
		kind: "recovery",
		rid: n.rid,
		data: {
			token: { ...i },
			character: n.character,
			i: t,
			n: r.length
		}
	}));
	W(e, n.bag), J(e, {
		op: "beat",
		n: 760
	}, ...o, {
		op: "recoveryCheck",
		actor: t
	});
}
function Xe(e, t, n, r = !1) {
	let i = e.seats[t], a = M.find((e) => e.id === n.character).abilities[n.ability], o = [...n.slots.flat(), ...n.extra], s = [...O(i.draw), ...i.bonuses];
	V(i, "crestActivated", o.filter((e) => s.some((t) => t.id === e && t.symbol === "E" && t.token !== null)).length);
	let c = o.filter((e) => s.find((t) => t.id === e)?.symbol === "L").length, l = a.damage + (e.challenge === 262 ? 0 : 2 * c);
	a.dynamic === "mass" && (l += o.filter((e) => s.find((t) => t.id === e)?.symbol === "M").length), a.dynamic === "lastTaken" && (l += i.lastTaken);
	let u = Me(n.slots, s, Be(e, i, n.copied), a.cost);
	for (let n = 0; n < u; n++) xe(e, t, "escape");
	let d = o.filter((e) => s.find((t) => t.id === e)?.symbol === "W").length;
	if (V(i, "speedSpent", d), Ce(i, o, e), i.plans = i.plans.filter((e) => e !== n), a.finisher ? i.flags.finisherUsed = 1 : i.activated.push(n.ability), a.resource && (i.resources += a.resource, V(i, "abilityResources", a.resource)), a.heal && J(e, {
		op: "healSplit",
		actor: t,
		n: a.heal
	}), a.selfDamage && Ee(e, t, a.selfDamage), !n.copied) {
		for (let n of a.marks ?? []) be(e, t, n);
		for (let n of a.gain ?? []) Se(e, t, n);
	}
	if (a.recoverClay) for (let t of [...i.discard]) ["M", "I"].includes(t.symbol) && (i.discard = i.discard.filter((e) => e.id !== t.id), i.draw.push(t), S(e, i, t, `discard:${i.rid}`, `draw:${i.rid}`), i.spent = i.spent.filter((e) => !e.startsWith(`${t.id}:`)));
	if (a.gadgetSelect && J(e, {
		op: "gadgetChoice",
		actor: t,
		names: a.gadgetSelect === "any" ? [...i.gadgetDeck] : i.gadgetDeck.slice(0, a.gadgetSelect)
	}), a.holdKryptonite) {
		for (let t of R(i)) if (t.symbol === "K") {
			let n = i.draw.some((e) => e.id === t.id) ? "draw" : i.bag.some((e) => e.id === t.id) ? "bag" : "discard";
			G(i, t.id, "discard"), i.discard = i.discard.filter((e) => e.id !== t.id), S(e, i, t, `${n}:${i.rid}`, `stored:${i.rid}`), i.stored.push({
				token: t,
				release: e.round + 1,
				place: "kryptonite"
			});
		}
		for (let t of i.stored) t.token.symbol === "K" && (t.release = e.round + 1);
	}
	I(e) && a.dynamic === "resourcePlusGadgets" && (l += i.resources + B(i, "gadgetsPlayed")), I(e) && a.dynamic === "matchPool" && (l = 0), e.challenge === 237 && B(i, "declared") === (a.group ?? n.ability) + 1 && (l += 2), e.challenge === 240 && B(i, "doubleAbility") === (a.group ?? n.ability) + 1 && (l *= 2), r ? l = B(i, "lastAbilityDamage") : i.flags.lastAbilityDamage = l, a.dynamic === "matchPool" && !I(e) && (i.flags.matchOpponent = n.target + 1);
	let f = a.indefensible || !a.finisher && B(i, "nextIndefensible") || B(i, "allIndefensible") || e.challenge === 246;
	if (a.finisher || (i.flags.nextIndefensible = 0), I(e) && !a.finisher && !n.copied && (e.clayLast = n), a.finisher || I(e) ? B(i, "batchAttack") ? (V(i, f ? "batchIndefensible" : "batchNormal", l), V(i, "batchAttack", -1), B(i, "batchAttack") || (He(e, t, B(i, "batchNormal"), B(i, "batchIndefensible"), "ability", n.target), i.flags.batchNormal = 0, i.flags.batchIndefensible = 0)) : He(e, t, f ? 0 : l, f ? l : 0, a.finisher ? "finisher" : "ability", n.target) : i.contributions.push({
		ability: n.ability,
		character: n.character,
		normal: f ? 0 : l,
		indefensible: f ? l : 0,
		target: n.target,
		copied: n.copied
	}), a.opponentChoice && J(e, {
		op: "clayFinisherChoice",
		actor: n.target,
		target: t
	}), a.extraResponse && i.character === "clayface" && (e.clayResponse += a.extraResponse), i.character === "lobo" && i.contracts.includes(a.group ?? n.ability) && !a.finisher) {
		let r = a.group ?? n.ability, o = i.stored.filter((e) => e.place === `contract:${r}`), s = o.length;
		for (let t of o) i.stored = i.stored.filter((e) => e !== t), i[e.challenge === 269 ? "supply" : "bag"].push(t.token), S(e, i, t.token, `stored:${i.rid}`, `${e.challenge === 269 ? "supply" : "bag"}:${i.rid}`);
		i.contracts = i.contracts.filter((e) => e !== r), V(i, "bountiesCollected", s), H(e, i, "double") && z(i, "O") && J(e, {
			op: "recoveryChoice",
			actor: t,
			text: "doubleBounty"
		});
	}
	x(e, {
		kind: "ability",
		rid: i.rid,
		data: { ability: n.ability }
	}), ye(e, "games.brave-and-bold.logActivate", t, { ability: a.nameKey }), J(e, {
		op: "beat",
		n: 700
	});
}
function Ze(e) {
	for (let t of P(e)) {
		let n = e.seats[t], r = L(n), i = r.filter((e) => e.symbol === "C").length;
		n.character === "supergirl" && Ve(e, t) === 2 && (i *= 2), e.challenge === 265 && (i = Math.min(3, i));
		let a = [
			212,
			277,
			246
		].includes(e.challenge) || B(n, "allIndefensible") > 0;
		n.pool = {
			normal: a ? 0 : i,
			indefensible: a ? i : 0
		}, n.pool.normal += B(n, "damageBonus"), n.pool.normal += B(n, "wrathDamage"), n.flags.poolCalculated = 1, n.character === "supergirl" && B(n, "fury") && n.hp <= 20 && (n.pool.normal += 2 * r.filter((e) => e.symbol === "Z").length);
		for (let t of n.contributions) {
			let r = M.find((e) => e.id === t.character).abilities[t.ability], i = t.normal, a = t.indefensible;
			if (r.dynamic === "resourcePlusGadgets") {
				let o = n.resources + B(n, "gadgetsPlayed");
				e.challenge === 237 && B(n, "declared") === (r.group ?? t.ability) + 1 && (o += 2), e.challenge === 240 && B(n, "doubleAbility") === (r.group ?? t.ability) + 1 && (o *= 2), a ? a += o : i += o;
			}
			B(n, "lasso") && B(n, "lasso") !== t.ability + 1 || (n.pool.normal += i, n.pool.indefensible += a);
		}
		if (n.upgrades.includes("sword")) {
			let e = O([...n.draw, ...n.discard]).filter((e) => e.symbol === "C").map((e) => e.id), t = B(n, "combatAssignedAbility");
			e.length && t > 0 && B(n, "combatAssignedAll") && (n.pool.normal += 3);
		}
		(B(n, "lasso") || B(n, "noUnusedCombat")) && (n.pool.normal = Math.max(0, n.pool.normal - (a ? 0 : i)), n.pool.indefensible = Math.max(0, n.pool.indefensible - (a ? i : 0))), e.challenge === 263 && r.some((e) => e.symbol === "C") && (n.pool = {
			normal: 0,
			indefensible: 0
		});
	}
	for (let t of e.seats) if (B(t, "matchOpponent") && !I(e)) {
		let n = e.seats[B(t, "matchOpponent") - 1];
		t.pool = {
			normal: n.pool.normal + n.pool.indefensible,
			indefensible: 0
		};
	}
}
function Qe(e) {
	for (let t = 0; t < 500 && e.tasks.length && e.phase !== "done"; t++) {
		let t = e.tasks[0];
		if (t.actor !== void 0 && e.seats[t.actor].defeated && (ze.has(t.op) || [
			"recovery",
			"draw",
			"drawToken",
			"activatePayment",
			"poolAttack",
			"rebalance"
		].includes(t.op))) {
			e.tasks.shift(), t.op === "prepare" && J(e, {
				op: "nextDraw",
				actor: t.actor
			});
			continue;
		}
		if (ze.has(t.op)) return;
		e.tasks.shift();
		let n = t.actor ?? 0, r = e.seats[n];
		switch (t.op) {
			case "beat":
				e.beat = t.n ?? 450;
				return;
			case "selectCharacter":
				Ie(e, n, t.text), r.character === "wonderWoman" && J(e, q("upgrade", n, 2));
				break;
			case "takeUpgrade":
				r.upgrades.push(t.text);
				break;
			case "startGame":
				Le(e);
				break;
			case "challengeStart":
				if (e.round === 1 && [239, 280].includes(e.challenge)) {
					e.deck.push(e.challenge), W(e, e.deck), e.challengeDiscard.pop(), e.challenge = e.deck.shift(), e.challengeDiscard.push(e.challenge), J(e, { op: "challengeStart" });
					break;
				}
				for (let t of P(e)) [239, 280].includes(e.challenge) && Te(e, t, 5), e.challenge === 230 && e.seats[t].character === "darkseid" && e.seats[t].hp >= 10 && (e.seats[t].injured = !0, e.seats[t].flags.challengeInjury = 1);
				if ([237, 240].includes(e.challenge) && J(e, ...P(e).map((t) => q("declare", t, void 0, e.challenge === 237 ? "addDamage" : "doubleDamage"))), e.challenge === 238 && J(e, ...P(e).map((e) => q("search", e, 2, "addBasicDraw"))), e.challenge === 279 && J(e, ...P(e).map((t) => q("search", t, void 0, e.seats[t].character === "supergirl" ? "gainSun" : "tweakBag"))), e.challenge === 278 && J(e, ...P(e).map((e) => q("search", e, void 0, "removeBasic"))), e.challenge === 226) {
					let t = e.seats.findIndex((e) => e.character === "clayface");
					t >= 0 && J(e, q("search", t, void 0, "clayChallengeOpponent"));
				}
				e.challenge === 217 && (e.first = P(e).sort((t, n) => R(e.seats[n]).length - R(e.seats[t]).length || R(e.seats[t]).filter((e) => !T(e.symbol) && ![
					"X",
					"U",
					"V"
				].includes(e.symbol)).length - R(e.seats[n]).filter((e) => !T(e.symbol) && ![
					"X",
					"U",
					"V"
				].includes(e.symbol)).length)[0]);
				break;
			case "watchtower": {
				e.phase = "watchtower", e.round++;
				let t = P(e), n = Math.min(...t.map((t) => e.seats[t].hp));
				if ((e.seats[e.first].hp !== n || e.seats[e.first].defeated) && (e.first = t.find((t) => e.seats[t].hp === n)), !e.deck.length) {
					De(e);
					break;
				}
				e.challenge = e.deck.shift(), e.challengeDiscard.push(e.challenge);
				for (let t of e.seats) t.peek = [], t.flags = { flightReturns: B(t, "flightReturns") }, t.resources = 0, t.pool = {
					normal: 0,
					indefensible: 0
				}, t.nonCrisisDrawn = 0, t.tokensDrawn = 0, t.stopped = !1, t.crisis = !1, t.bonuses = [], t.spent = [], t.plans = [], t.activated = [], t.contributions = [], t.bought = [], t.contracts = [];
				e.marketPurchased = !1, J(e, { op: "challengeStart" }, { op: "watchActions" });
				break;
			}
			case "watchActions":
				J(e, ...P(e).map((e) => q("watchStart", e)), ...P(e).map((e) => ({
					op: "recovery",
					actor: e
				})), { op: "preparationStart" });
				break;
			case "recovery":
				Ye(e, n);
				break;
			case "recoveryCheck":
				r.injured && r.hp === 0 && (r.defeated = !0, ye(e, "games.brave-and-bold.logDefeated", n), K(e));
				break;
			case "heal":
				Te(e, t.target ?? n, t.n ?? 0);
				break;
			case "selfDamage":
				Ee(e, n, t.n ?? 0), K(e);
				break;
			case "preparationStart":
				e.phase = "preparation", e.turnOrder = P(e);
				for (let t of e.seats) for (let n of [...t.stored]) n.release <= e.round && ["contingency", "plane"].includes(n.place) && (t.draw.push(n.token), S(e, t, n.token, `stored:${t.rid}`, `draw:${t.rid}`), t.stored = t.stored.filter((e) => e !== n));
				J(e, ...P(e).map((e) => q("prepStart", e)), { op: "preparationCard" }, q("prepare", P(e)[0]));
				break;
			case "preparationCard":
				[253, 223].includes(e.challenge) && J(e, ...P(e).map((e) => q("search", e, 2, "temporaryBasic"))), e.challenge === 225 && J(e, ...P(e).map((e) => ({
					op: "initialPair",
					actor: e
				})));
				break;
			case "initialPair": {
				let t = [];
				for (let n = 0; n < 2; n++) {
					let n = U(e, r.bag);
					n && t.push(n);
				}
				t.length && J(e, {
					op: "drawChoice",
					actor: n,
					tokens: t,
					text: "discardOne"
				});
				break;
			}
			case "draw":
				Ke(e, n);
				break;
			case "drawToken":
				qe(e, n, t.tokens[0]);
				break;
			case "drawFinalize":
				Je(e, n, t.id);
				break;
			case "nextDraw": {
				let t = P(e).filter((t) => !e.seats[t].stopped && !e.seats[t].crisis && e.seats[t].bag.length);
				if (!t.length) {
					J(e, ...P(e).map((e) => q("prepEnd", e)), { op: "preparationEndCard" }, { op: "combatBegin" });
					break;
				}
				J(e, q("prepare", Array.from({ length: e.seats.length }, (t, r) => (n + r + 1) % e.seats.length).find((e) => t.includes(e))));
				break;
			}
			case "stop":
				r.stopped = !0, J(e, {
					op: "nextDraw",
					actor: n
				});
				break;
			case "preparationEndCard":
				if (e.challenge === 101) for (let t of P(e)) {
					let n = U(e, e.seats[t].bag);
					n?.symbol === "X" ? J(e, {
						op: "drawToken",
						actor: t,
						tokens: [n]
					}) : n && (e.seats[t].supply.push(n), S(e, e.seats[t], n, `bag:${e.seats[t].rid}`, `supply:${e.seats[t].rid}`));
				}
				e.challenge === 244 && J(e, ...P(e).map((e) => q("search", e, void 0, "opponentDiscard")));
				break;
			case "combatBegin":
				e.clayAttacker = e.seats.some((e) => e.character === "clayface" && !e.defeated) ? e.first : -1, e.phase = "combat";
				for (let t of P(e)) Ge(e, t);
				J(e, ...P(e).flatMap((t) => e.seats[t].deferred ? [{
					op: "deferred",
					actor: t
				}] : []), ...P(e).map((e) => q("combatStart", e)), { op: "combatAllocate" });
				break;
			case "deferred":
				r.lastTaken = 0, e.hit = {
					source: n,
					target: n,
					normal: 0,
					indefensible: r.deferred,
					kind: "deferred",
					allowDefer: !1
				}, r.deferred = 0, J(e, { op: "damageResolve" });
				break;
			case "combatAllocate":
				for (let t of P(e)) {
					let n = e.seats[t];
					n.resources = ge(n.draw, "R") + n.bonuses.filter((e) => e.symbol === "R").length + B(n, "recoveryResources"), n.flags.powerAvailable = n.draw.filter((e) => e.kind === "power" && e.symbol === "R").length;
				}
				I(e) ? (e.clayAttacker = e.first, e.clayResponse = 0, e.turnOrder = P(e).filter((t) => e.seats[t].character !== "clayface"), J(e, q("clayCombat", e.first))) : J(e, ...P(e).flatMap((t) => e.seats[t].crisis ? [q("crisisAbility", t)] : [q("allocate", t)]), ...P(e).map((e) => q("activate", e)), { op: "pools" });
				break;
			case "reserve": {
				let i = t.payment;
				r.plans.push(i);
				for (let t of r.draw.filter((e) => i.slots.flat().some((t) => t.startsWith(`${e.id}:`)))) S(e, r, t, `draw:${r.rid}`, `allocated:${i.slots.flat().find((e) => e.startsWith(`${t.id}:`))}`);
				let a = [...i.slots.flat(), ...i.extra], o = [...O(r.draw), ...r.bonuses];
				if (a.filter((e) => o.find((t) => t.id === e)?.symbol === "C").length) {
					let e = B(r, "combatAssignedAbility");
					r.flags.combatAssignedAbility = e ? e === i.ability + 1 ? e : -1 : i.ability + 1;
				}
				if (e.challenge === 224) {
					let t = a.map((e) => o.find((t) => t.id === e)).find((e) => e && T(e.symbol) && e.token !== null);
					if (t) for (let r of F(e, n)) B(e.seats[r], "matchedBasic") || (Se(e, r, t.symbol, "draw"), e.seats[r].flags.matchedBasic = 1);
				}
				break;
			}
			case "allocationDone":
				r.resources = ge(r.draw, "R") + r.bonuses.filter((e) => e.symbol === "R").length + B(r, "recoveryResources"), r.flags.combatAssignedAll = +!L(r).some((e) => e.symbol === "C");
				break;
			case "unreserve":
				r.plans = [], r.flags.combatAssignedAbility = 0;
				break;
			case "activatePayment":
				t.payment.slots.length && !r.plans.includes(t.payment) ? J(e, {
					op: "reserve",
					actor: n,
					payment: t.payment
				}, {
					op: "beat",
					n: 380
				}, t) : Xe(e, n, t.payment, t.text === "repeat");
				break;
			case "pools":
				Ze(e), J(e, ...P(e).filter((t) => !e.seats[t].crisis).map((e) => q("poolModifier", e)), ...P(e).filter((t) => !e.seats[t].crisis).flatMap((e) => [q("poolReady", e), {
					op: "poolAttack",
					actor: e
				}]), ...P(e).filter((t) => !e.seats[t].crisis).map((e) => q("finisher", e)), { op: "combatEnd" });
				break;
			case "poolAttack":
				J(e, {
					op: "poolComplete",
					actor: n
				}), He(e, n, r.pool.normal, r.pool.indefensible, "pool");
				break;
			case "poolComplete":
				r.flags.poolResolved = 1;
				break;
			case "setHit":
				e.hit = {
					source: n,
					target: t.target,
					normal: t.normal ?? 0,
					indefensible: t.indefensible ?? 0,
					kind: t.text ?? "special",
					allowDefer: !0
				}, J(e, q("boost", n), ...pe(e, t.target).map((e) => q("defend", e)), { op: "damageResolve" }, {
					op: "beat",
					n: 650
				});
				break;
			case "damageResolve": {
				let t = e.hit;
				t && (e.seats[t.target].lastTaken = 0, Ee(e, t.target, t.normal + t.indefensible), e.hit = null, K(e));
				break;
			}
			case "challengeDamage":
				e.hit = {
					source: n,
					target: n,
					normal: t.n ?? 0,
					indefensible: 0,
					kind: "challenge",
					allowDefer: !0
				}, J(e, ...pe(e, n).map((e) => q("defend", e)), { op: "damageResolve" }, {
					op: "beat",
					n: 650
				});
				break;
			case "combatEnd":
				J(e, { op: "powerBegin" });
				for (let t of P(e)) {
					let n = e.seats[t];
					if (n.character === "cheetah") {
						let n = F(e, t).reduce((t, n) => t + he(e.seats[n]).length, 0), r = 0;
						for (let i = 0; i < n; i++) Se(e, t, "H") && r++;
						r || Se(e, t, "X");
					}
					if (e.challenge === 218) {
						let r = he(n).length;
						r && J(e, {
							op: "challengeDamage",
							actor: t,
							n: r
						});
					}
				}
				K(e);
				break;
			case "powerBegin":
				e.phase = "powerUp", J(e, ...P(e).filter((t) => !e.seats[t].crisis).flatMap((e) => [q("powerStart", e), q("resupply", e)]), { op: "crisisBegin" });
				break;
			case "crisisBegin":
				J(e, ...P(e).filter((t) => e.seats[t].crisis).flatMap((e) => [
					{
						op: "crisisPool",
						actor: e
					},
					q("powerStart", e),
					q("resupply", e)
				]), { op: "refreshBegin" });
				break;
			case "crisisPool":
				I(e) || He(e, n, L(r).filter((e) => e.symbol === "C").length + B(r, "damageBonus"), 0, "crisis");
				break;
			case "refreshBegin":
				e.marketPurchased || J(e, ...P(e).map((e) => q("refresh", e, 2))), J(e, { op: "turnEndBegin" });
				break;
			case "turnEndBegin":
				J(e, ...P(e).map((e) => q("endTurn", e)), { op: "turnEndPenalty" }, ...P(e).flatMap((e) => [
					q("rebalanceChoice", e),
					{
						op: "rebalance",
						actor: e
					},
					q("afterRebalance", e)
				]), { op: "watchtower" });
				break;
			case "turnEndPenalty":
				e.challenge === 215 && J(e, ...P(e).filter((t) => he(e.seats[t]).length > 0).map((e) => ({
					op: "challengeDamage",
					actor: e,
					n: 5
				}))), K(e);
				break;
			case "rebalance":
				for (let t of [...r.stored]) t.place.startsWith("contract:") && (r.supply.push(t.token), S(e, r, t.token, `stored:${r.rid}`, `supply:${r.rid}`), r.stored = r.stored.filter((e) => e !== t));
				for (let t of [...r.stored]) t.place === "heldDiscard" && t.release <= e.round + 1 && (r.discard.push(t.token), S(e, r, t.token, `stored:${r.rid}`, `discard:${r.rid}`), r.stored = r.stored.filter((e) => e !== t));
				ke(e, n);
				for (let t of [...r.stored]) t.place === "kryptonite" && t.release <= e.round && (r.bag.push(t.token), S(e, r, t.token, `stored:${r.rid}`, `bag:${r.rid}`), r.stored = r.stored.filter((e) => e !== t));
				if (B(r, "challengeInjury") && !r.defeated && (r.injured = !1), e.challenge === 254) {
					let t = U(e, r.bag);
					t && (r.bag.push(t), [
						"C",
						"R",
						"A"
					].includes(t.symbol) && Se(e, n, t.symbol));
				}
				break;
			case "gain":
				Se(e, n, t.symbol, t.text === "draw" ? "draw" : "bag", t.n === 1);
				break;
			case "temporary":
				Ue(e, n, t.symbol, t.n);
				break;
			case "returnToken": {
				let i = r.bag.find((e) => e.id === t.id), a = G(r, t.id, t.text === "discard" ? "discard" : t.text === "bag" ? "bag" : "supply", e);
				a && i && !E(a) && !t.text && e.challenge === 270 && !e.seats.some((e) => B(e, "challengeRemoval")) && (r.flags.challengeRemoval = 1, J(e, ...P(e).filter((e) => e !== n).map((e) => q("search", e, void 0, "removeBagNonCrisis"))));
				break;
			}
			case "spendUnits":
				Ce(r, t.names ?? [], e);
				break;
			case "mark":
				be(e, n, t.text, t.n);
				break;
			case "spendMark":
				xe(e, n, t.text);
				break;
			case "flag":
				r.flags[t.text] = t.n ?? 1;
				break;
			case "persistent":
				r.exhausted[t.text] = t.n ?? 1;
				break;
			case "addFlag":
				V(r, t.text, t.n);
				break;
			case "addBonus":
				we(e, n, t.symbol, t.n ?? 1);
				break;
			case "drawGadget":
				We(e, n, t.n);
				break;
			case "gadgetTake": {
				let i = r.gadgetDeck.indexOf(t.text);
				i >= 0 && (r.hand.push(r.gadgetDeck.splice(i, 1)[0]), x(e, {
					kind: "gadget",
					rid: r.rid,
					data: { gain: !0 }
				})), r.hand.length > 3 && J(e, q("handLimit", n));
				break;
			}
			case "gadgetReturn": {
				let i = r.hand.splice(t.id, 1)[0];
				if (r.gadgetDeck.push(i), x(e, {
					kind: "gadget",
					rid: r.rid,
					data: {
						gain: !1,
						card: i
					}
				}), B(r, "poolCalculated") && !B(r, "poolResolved")) for (let t of r.contributions) {
					let i = M.find((e) => e.id === t.character).abilities[t.ability];
					if (i.dynamic !== "resourcePlusGadgets") continue;
					let a = e.challenge === 240 && B(r, "doubleAbility") === (i.group ?? t.ability) + 1 ? 2 : 1;
					t.indefensible ? r.pool.indefensible += a : r.pool.normal += a, e.hit?.source === n && e.hit.kind === "pool" && (t.indefensible ? e.hit.indefensible += a : e.hit.normal += a);
				}
				break;
			}
			case "peek":
				r.peek = e.deck.slice(0, t.n ?? 1);
				break;
			case "reverseDraw": {
				let n = e.seats[t.target], r = n.draw.find((e) => e.id === t.id);
				r && (G(n, r.id, "bag", e), n.tokensDrawn--, E(r) || n.nonCrisisDrawn--, r.symbol === "C" && V(n, "combatDrawn", -w(r)), J(e, {
					op: "draw",
					actor: t.target
				}));
				break;
			}
			case "useReverse":
				r.reverse &&= (S(e, r, r.reverse, `token:${r.reverse.id}`, `discard:${r.rid}`), r.discard.push(r.reverse), null);
				break;
			case "attack":
				He(e, n, t.normal ?? t.n ?? 0, t.indefensible ?? 0, t.text, t.target);
				break;
			case "critical": {
				let n = e.seats[t.target];
				n.injured = !0, Ee(e, t.target, n.hp), K(e);
				break;
			}
			case "defense":
				e.hit && (e.hit.normal = Math.max(0, e.hit.normal - (t.n ?? 2)));
				break;
			case "absorb":
				e.hit && (e.hit.normal = 0, V(r, "extraCrisis"));
				break;
			case "defer":
				if (e.hit) {
					let t = e.hit.normal + e.hit.indefensible;
					r.deferred += t, e.hit.normal = 0, e.hit.indefensible = 0, r.flags.aegisUsed = 1;
				}
				break;
			case "boostDamage":
				e.hit && e.challenge !== 262 && (e.hit.normal ? e.hit.normal += t.n ?? 2 : e.hit.indefensible += t.n ?? 2);
				break;
			case "halfPool":
				if (e.hit) {
					let t = Math.max(1, Math.floor((e.hit.normal + e.hit.indefensible) / 2));
					e.hit.normal = Math.min(e.hit.normal, t), e.hit.indefensible = t - e.hit.normal;
				}
				break;
			case "setFirst":
				e.first = n;
				break;
			case "removeCard": {
				let n = e.challengeDiscard.indexOf(t.id);
				n >= 0 && (e.deck.push(e.challengeDiscard.splice(n, 1)[0]), W(e, e.deck));
				break;
			}
			case "replaceChallenge": {
				let n = e.deck.splice(0, 2);
				e.challengeDiscard.push(...n.filter((e) => e !== t.id)), e.challenge = t.id, e.challengeDiscard.push(t.id);
				let r = e.challengeDiscard.filter((e) => e !== t.id);
				e.challengeDiscard = [t.id], e.deck.push(...r), W(e, e.deck);
				for (let t of e.seats) for (let n of R(t)) B(t, `challengeTemp:${n.id}`) && G(t, n.id, "supply", e);
				J(e, { op: "challengeStart" });
				break;
			}
			case "marketTake": {
				let n = e.market.findIndex((e) => e.id === t.id);
				n >= 0 && (S(e, r, e.market[n], "market", `bag:${r.rid}`), r.bag.push(e.market[n]), Oe(e, n), t.text !== "mechano" && (e.marketPurchased = !0));
				break;
			}
			case "marketSwap": {
				let n = e.market.findIndex((e) => e.id === t.id);
				if (n >= 0) {
					let t = e.market[n];
					Oe(e, n), e.armoury.push(t), W(e, e.armoury);
				}
				break;
			}
			case "payResources": {
				let r = t.n ?? 0;
				for (let t of [n, ...pe(e, n).filter((e) => e !== n)]) {
					let n = Math.min(r, e.seats[t].resources);
					e.seats[t].resources -= n, r -= n;
				}
				break;
			}
			case "recordPurchase":
				r.bought.push(t.text), t.n && V(r, "powerPurchases");
				break;
			case "contractPlace": {
				let n = r.supply.find((e) => e.symbol === "O");
				n && (r.supply = r.supply.filter((e) => e.id !== n.id), r.stored.push({
					token: n,
					place: `contract:${t.id}`,
					release: e.round
				}), r.contracts.push(t.id), S(e, r, n, `supply:${r.rid}`, `stored:${r.rid}`));
				break;
			}
			case "store": {
				let n = R(r).find((e) => e.id === t.id);
				if (n) {
					let i = r.draw.some((e) => e.id === n.id) ? "draw" : r.bag.some((e) => e.id === n.id) ? "bag" : "discard";
					G(r, n.id, "discard"), r.discard = r.discard.filter((e) => e.id !== n.id), S(e, r, n, `${i}:${r.rid}`, `stored:${r.rid}`), r.stored.push({
						token: n,
						release: e.round + (t.text === "heldDiscard" ? 2 : 1),
						place: t.text ?? "contingency"
					});
				}
				break;
			}
			case "retrievePlane":
				for (let t of [...r.stored]) t.place === "plane" && (r.draw.push(t.token), S(e, r, t.token, `stored:${r.rid}`, `draw:${r.rid}`), r.stored = r.stored.filter((e) => e !== t));
				break;
			case "clayAfterAttack": {
				let t = e.seats.findIndex((e) => e.character === "clayface" && !e.defeated);
				if (t < 0) {
					J(e, {
						op: "clayPass",
						actor: n
					});
					break;
				}
				if (n !== t && F(e, n).includes(t)) {
					let r = e.challenge === 222 && !B(e.seats[t], "copyOffered");
					e.seats[t].flags.copyOffered = 1, e.clayAttacker = n, e.clayResponse = 1, J(e, {
						op: "clayCombat",
						actor: t,
						...r && e.clayLast ? { payment: e.clayLast } : {}
					});
				} else if (n !== t) J(e, e.seats[n].defeated ? {
					op: "clayPass",
					actor: n
				} : q("clayCombat", n));
				else if (e.clayResponse > 1) e.clayResponse--, J(e, q("clayCombat", t));
				else {
					e.clayResponse = 0;
					let n = e.clayAttacker === t ? e.turnOrder.find((t) => !e.seats[t].defeated) : e.clayAttacker;
					J(e, n !== void 0 && !e.seats[n].defeated ? q("clayCombat", n) : {
						op: "clayPass",
						actor: e.clayAttacker
					});
				}
				break;
			}
			case "clayPass": {
				let t = e.turnOrder.filter((t) => !e.seats[t].defeated).find((t) => e.turnOrder.indexOf(t) > e.turnOrder.indexOf(n));
				t === void 0 ? J(e, ...P(e).filter((t) => !e.seats[t].crisis).map((e) => q("finisher", e)), { op: "combatEnd" }) : (e.clayAttacker = t, J(e, q("clayCombat", t)));
				break;
			}
			case "supplyTake": {
				let n = r.supply.findIndex((e) => e.id === t.id);
				if (n >= 0) {
					let t = r.supply.splice(n, 1)[0];
					r.bag.push(t), S(e, r, t, `supply:${r.rid}`, `bag:${r.rid}`);
				}
				break;
			}
			case "moveToDraw": {
				let n = r.bag.find((e) => e.id === t.id);
				n && (r.bag = r.bag.filter((e) => e.id !== n.id), r.draw.push(n), S(e, r, n, `bag:${r.rid}`, `draw:${r.rid}`), W(e, r.bag));
				break;
			}
			case "putTokens": {
				let n = t.text === "discard" ? "discard" : t.text === "supply" ? "supply" : t.text === "draw" ? "draw" : "bag";
				r[n].push(...t.tokens ?? []);
				for (let i of t.tokens ?? []) S(e, r, i, `draw:${r.rid}`, `${n}:${r.rid}`);
				break;
			}
			case "exhaustMark":
				r.exhausted[t.text] = (r.exhausted[t.text] ?? 0) + 1;
				break;
			case "discardDiscount": {
				let t = r.draw.find((e) => e.symbol === "D");
				t && G(r, t.id, "discard", e);
				break;
			}
			case "poolAdd":
				r.pool.normal += t.n ?? 0;
				break;
			case "unusedHeal":
				r.flags.unusedHeal = t.n ?? 0;
				break;
			case "convertPool":
				r.pool.indefensible += r.pool.normal, r.pool.normal = 0;
				break;
			case "modifyContribution": {
				let e = r.contributions.find((e) => e.ability === t.id);
				if (!e) break;
				let n = {
					normal: e.normal,
					indefensible: e.indefensible
				};
				t.text === "double" ? (e.normal *= t.n, e.indefensible *= t.n) : t.text === "convert" ? (e.indefensible += e.normal, e.normal = 0) : e.normal ? e.normal += t.n ?? 0 : e.indefensible += t.n ?? 0, r.pool.normal += e.normal - n.normal, r.pool.indefensible += e.indefensible - n.indefensible;
				break;
			}
			case "exchange": {
				let n = r.draw.find((e) => e.id === B(r, "exchangeId") - 1), i = r.bag.find((e) => e.id === t.id);
				n && i && (G(r, n.id, "bag", e), r.bag = r.bag.filter((e) => e.id !== i.id), r.draw.push(i), S(e, r, i, `bag:${r.rid}`, `draw:${r.rid}`), W(e, r.bag));
				break;
			}
			case "selectMarketToken": {
				B(r, "marketSelection") || (e.armoury.push(...e.market), e.market = [], r.flags.marketSelection = 1);
				let n = e.armoury.findIndex((e) => e.id === t.id);
				n >= 0 && e.market.push(e.armoury.splice(n, 1)[0]);
				break;
			}
			default: throw Error(`Unknown Brave & Bold continuation: ${t.op}`);
		}
	}
}
//#endregion
//#region src/games/brave-and-bold/choices.ts
var $e = "games.brave-and-bold.use", et = "games.brave-and-bold.continue", Y = {
	aegis: "games.brave-and-bold.upgradeAegis",
	sword: "games.brave-and-bold.upgradeSword",
	training: "games.brave-and-bold.upgradeTraining",
	plane: "games.brave-and-bold.upgradePlane",
	tiara: "games.brave-and-bold.upgradeTiara"
}, X = {
	batarang: "games.brave-and-bold.gadgetBatarang",
	smoke: "games.brave-and-bold.gadgetSmoke",
	contingency: "games.brave-and-bold.gadgetContingency",
	grapple: "games.brave-and-bold.gadgetGrapple",
	pulse: "games.brave-and-bold.gadgetPulse"
};
function tt(e) {
	let t = e.tasks[0];
	if (!t || e.beat || e.phase === "done") return [];
	let n = t.actor ?? 0, r = e.seats[n], i = [], a = t, o = (t, n, r = {}) => {
		i.push({
			id: `${e.revision}:${i.length}`,
			label: t,
			kind: "action",
			...r,
			steps: n
		});
	}, s = (e = []) => o(et, e), c = (e, t, n = "games.brave-and-bold.chooseToken") => o(n, t, {
		kind: "token",
		token: e
	}), l = (t, i, a = {}) => {
		H(e, r, t) && (o($e, [{
			op: "spendMark",
			actor: n,
			text: t
		}, ...i], {
			kind: "special",
			nameKey: N[t],
			...a
		}), r.upgrades.includes("tiara") && !r.exhausted.tiaraSpent && o("games.brave-and-bold.useTiara", [
			{
				op: "persistent",
				actor: n,
				text: "tiaraSpent",
				n: 1
			},
			{
				op: "addFlag",
				actor: n,
				text: "specialsUsed",
				n: 1
			},
			...i
		], {
			kind: "special",
			nameKey: N[t],
			...a
		}));
	}, u = (e) => e.filter((t, n) => e.findIndex((e) => e.symbol === t.symbol && e.kind === t.kind) === n), d = (e, t) => L(r).filter((t) => t.symbol === e && t.token !== null).slice(0, t).map((e) => e.id), f = (e, t) => d(e, t).length >= t, p = (e, t) => ({
		op: "spendUnits",
		actor: n,
		names: d(e, t)
	}), m = L(r), h = F(e, n), g = (i, s, c = !1, l = r.character) => {
		let u = M.find((e) => e.id === l);
		for (let d = 0; d < u.abilities.length; d++) {
			let f = u.abilities[d];
			if (!!f.finisher !== i || !s && r.plans.some((e) => e.ability === d || (f.group ?? d) === (u.abilities[e.ability].group ?? e.ability)) || B(r, "lasso") && !i && !c && B(r, "lasso") !== (f.group ?? d) + 1) continue;
			let p = Pe(f, d, m, Be(e, r, c), 1)[0];
			if (!p || e.challenge === 271 && [...r.plans.flatMap((e) => e.slots.flat()), ...p.slots.flat()].filter((e) => [...O(r.draw), ...r.bonuses].find((t) => t.id === e)?.symbol === "E" && [...O(r.draw), ...r.bonuses].find((t) => t.id === e)?.token !== null).length + B(r, "crestActivated") > 3 || e.challenge === 266 && B(r, "combatAssignedAbility") && B(r, "combatAssignedAbility") !== d + 1 && p.slots.flat().some((e) => m.find((t) => t.id === e)?.symbol === "C")) continue;
			let g = {
				...p,
				character: l,
				target: h[0] ?? 0,
				copied: c
			}, _ = s ? [{
				op: "activatePayment",
				actor: n,
				payment: g
			}] : [{
				op: "reserve",
				actor: n,
				payment: g
			}];
			if (t.op === "clayCombat" ? _.push({
				op: "clayAfterAttack",
				actor: n
			}) : _.push(a), o(i ? "games.brave-and-bold.finish" : "games.brave-and-bold.allocateAbility", _, {
				kind: "ability",
				ability: d,
				character: l,
				nameKey: f.nameKey,
				payment: p,
				target: g.target
			}), t.op === "clayCombat" && !c && !i && e.challenge === 247 && !B(r, "challengeRepeat")) {
				let e = m.find((e) => e.symbol === "C" && !p.slots.flat().includes(e.id));
				e && o("games.brave-and-bold.repeatAbility", [
					{
						op: "spendUnits",
						actor: n,
						names: [e.id]
					},
					{
						op: "flag",
						actor: n,
						text: "challengeRepeat"
					},
					{
						op: "flag",
						actor: n,
						text: "batchAttack",
						n: 2
					},
					{
						op: "activatePayment",
						actor: n,
						payment: g
					},
					{
						op: "activatePayment",
						actor: n,
						payment: {
							...g,
							slots: [],
							extra: []
						},
						text: "repeat"
					},
					{
						op: "clayAfterAttack",
						actor: n
					}
				], {
					kind: "ability",
					ability: d,
					character: l,
					nameKey: f.nameKey,
					payment: p,
					target: g.target
				});
			}
		}
	};
	switch (t.op) {
		case "select":
			for (let t of Re(e, n)) o("games.brave-and-bold.chooseCharacter", [{
				op: "selectCharacter",
				actor: n,
				text: t.id
			}], {
				kind: "character",
				character: t.id,
				nameKey: t.nameKey
			});
			return i;
		case "upgrade":
			for (let e of Object.keys(Y)) r.upgrades.includes(e) || o("games.brave-and-bold.chooseUpgrade", [{
				op: "takeUpgrade",
				actor: n,
				text: e
			}, ...t.n > 1 ? [q("upgrade", n, t.n - 1)] : []], {
				kind: "upgrade",
				nameKey: Y[e]
			});
			return i;
		case "watchStart":
			if (r.character === "lobo" && !B(r, "contractSet") && r.supply.some((e) => e.symbol === "O") && o("games.brave-and-bold.setContract", [
				{
					op: "flag",
					actor: n,
					text: "contractSet"
				},
				q("contract", n),
				a
			]), r.character === "lex") for (let e = 1; e <= Math.min(3, r.supply.filter((e) => e.symbol === "L").length); e++) l("totality", [...Array.from({ length: e }, () => ({
				op: "gain",
				actor: n,
				symbol: "L"
			})), a], { amount: e });
			for (let e of h) l("darkKnight", [{
				op: "flag",
				actor: e,
				text: "skipRecovery"
			}, a], { target: e });
			H(e, r, "recharge") && l("recharge", [
				{
					op: "flag",
					actor: n,
					text: "skipRecovery",
					n: 0
				},
				{
					op: "healSplit",
					actor: n,
					n: 3
				},
				a
			]), s();
			break;
		case "prepStart":
			e.challenge !== 233 && l("manipulate", [{
				op: "flag",
				actor: n,
				text: "manipulate"
			}, a]), e.challenge !== 269 && l("strength", [
				0,
				1,
				2
			].map(() => ({
				op: "temporary",
				actor: n,
				symbol: "C"
			})).concat([a])), e.challenge !== 269 && r.supply.some((e) => e.symbol === "U") && l("looseEnds", [
				{
					op: "gain",
					actor: n,
					symbol: "U"
				},
				{
					op: "addFlag",
					actor: n,
					text: "looseReturn"
				},
				a
			]);
			for (let e of h) l("lasso", [{
				op: "declare",
				actor: e,
				text: "lasso"
			}, a], { target: e });
			r.upgrades.includes("plane") && !B(r, "planePrepared") && o("games.brave-and-bold.usePlane", [
				{
					op: "flag",
					actor: n,
					text: "planePrepared"
				},
				{
					op: "retrievePlane",
					actor: n
				},
				{
					op: "search",
					actor: n,
					text: "planeStore"
				},
				a
			], {
				kind: "upgrade",
				nameKey: Y.plane
			}), s();
			break;
		case "prepare":
			if (r.stopped || r.crisis || !r.bag.length) return [{
				id: `${e.revision}:0`,
				label: et,
				kind: "action",
				steps: [{
					op: "nextDraw",
					actor: n
				}]
			}];
			o("games.brave-and-bold.draw", [{
				op: "draw",
				actor: n
			}, {
				op: "nextDraw",
				actor: n
			}]), o("games.brave-and-bold.stop", [{
				op: "stop",
				actor: n
			}]);
			break;
		case "drawChoice": {
			let e = t.tokens ?? [], r = t.text === "manipulate" && e.some((e) => e.symbol === "X");
			for (let i of e) {
				if (r && i.symbol !== "X" || t.text === "discardOne" && i.symbol === "X") continue;
				let a = e.filter((e) => e.id !== i.id);
				c(i, t.text === "discardOne" ? [{
					op: "putTokens",
					actor: n,
					tokens: [i],
					text: "discard"
				}, ...a.map((e) => ({
					op: "drawToken",
					actor: n,
					tokens: [e]
				}))] : [{
					op: "putTokens",
					actor: n,
					tokens: a,
					text: "bag"
				}, {
					op: "drawToken",
					actor: n,
					tokens: [i]
				}], t.text === "discardOne" ? "games.brave-and-bold.discardToken" : "games.brave-and-bold.keepToken");
			}
			return i.length || s(e.map((e) => ({
				op: "drawToken",
				actor: n,
				tokens: [e]
			}))), i;
		}
		case "respondDraw": {
			let a = t.target, c = e.seats[a].draw.find((e) => e.id === t.id);
			if (c && e.challenge !== 233) {
				if (n === a && r.reverse && o("games.brave-and-bold.reverse", [{
					op: "useReverse",
					actor: n
				}, {
					op: "reverseDraw",
					actor: n,
					target: a,
					id: c.id
				}], {
					kind: "token",
					token: c
				}), n !== a && h.includes(a) && l("strategist", [{
					op: "reverseDraw",
					actor: n,
					target: a,
					id: c.id
				}], {
					target: a,
					token: c
				}), c.symbol === "X") {
					l("destiny", [{
						op: "returnToken",
						actor: a,
						id: c.id,
						text: "bag"
					}], {
						target: a,
						token: c
					});
					let e = m.filter((e) => ["M", "I"].includes(e.symbol) && e.token !== null);
					e.length >= 2 && l("predatory", [{
						op: "spendUnits",
						actor: n,
						names: e.slice(0, 2).map((e) => e.id)
					}, {
						op: "returnToken",
						actor: a,
						id: c.id,
						text: "bag"
					}], {
						target: a,
						token: c
					});
				}
				l("subvert", [{
					op: "returnToken",
					actor: a,
					id: c.id,
					text: "discard"
				}], {
					target: a,
					token: c
				}), n === a && r.character === "cheetah" && c.symbol === "X" && Ve(e, n) >= 3 && f("H", 3) && o("games.brave-and-bold.huntCrisis", [...m.filter((e) => e.symbol === "H").slice(0, 3).map((e) => ({
					op: "returnToken",
					actor: n,
					id: e.token,
					text: "supply"
				})), {
					op: "returnToken",
					actor: n,
					id: c.id,
					text: "supply"
				}], { token: c }), n === a && e.challenge === 245 && c.symbol === "X" && !B(r, "challengeReverse") && o("games.brave-and-bold.reverse", [{
					op: "flag",
					actor: n,
					text: "challengeReverse"
				}, {
					op: "reverseDraw",
					actor: n,
					target: a,
					id: c.id
				}], { token: c });
			}
			return s(), i;
		}
		case "prepEnd":
			e.challenge !== 233 && l("analysis", [{
				op: "search",
				actor: n,
				text: "exchangeDraw"
			}, a]);
			for (let t = 0; t < r.hand.length; t++) if (r.hand[t] === "pulse" && B(r, "gadgetsPlayed") < 3) for (let r of h) {
				let i = e.seats[r], s = i.draw.at(-1);
				!i.crisis && s && o("games.brave-and-bold.playGadget", [
					{
						op: "gadgetReturn",
						actor: n,
						id: t
					},
					{
						op: "addFlag",
						actor: n,
						text: "gadgetsPlayed"
					},
					{
						op: "returnToken",
						actor: r,
						id: s.id,
						text: "discard"
					},
					a
				], {
					kind: "gadget",
					nameKey: X.pulse,
					target: r
				});
			}
			s();
			break;
		case "combatStart":
			if (!r.crisis) {
				l("fury", [{
					op: "flag",
					actor: n,
					text: "fury"
				}, a]);
				for (let e of h) l("bracelets", [{
					op: "flag",
					actor: e,
					text: "noUnusedCombat"
				}, a], {
					target: e,
					label: "games.brave-and-bold.blockCombat"
				}), l("bracelets", [{
					op: "addFlag",
					actor: e,
					text: "buyReduction"
				}, a], {
					target: e,
					label: "games.brave-and-bold.blockPurchase"
				});
			}
			s();
			break;
		case "allocate":
			g(!1, !1), r.plans.length && o("games.brave-and-bold.clearAllocation", [{
				op: "unreserve",
				actor: n
			}, a]), o("games.brave-and-bold.confirmAllocation", [{
				op: "allocationDone",
				actor: n
			}]);
			break;
		case "crisisAbility":
			if (e.challenge === 243 || H(e, r, "companion")) {
				g(!1, !1);
				for (let t of i) t.kind === "ability" && (e.challenge !== 243 && t.steps.unshift({
					op: "spendMark",
					actor: n,
					text: "companion"
				}), t.steps = t.steps.filter((e) => e !== a), t.steps.push({
					op: "allocationDone",
					actor: n
				}));
			}
			s([{
				op: "allocationDone",
				actor: n
			}]);
			break;
		case "activate":
			for (let t of r.plans) {
				let i = {
					kind: "ability",
					ability: t.ability,
					character: t.character,
					nameKey: M.find((e) => e.id === t.character).abilities[t.ability].nameKey
				};
				o("games.brave-and-bold.activateAbility", [{
					op: "activatePayment",
					actor: n,
					payment: t
				}, a], i), e.challenge === 247 && !B(r, "challengeRepeat") && f("C", 1) && o("games.brave-and-bold.repeatAbility", [
					p("C", 1),
					{
						op: "flag",
						actor: n,
						text: "challengeRepeat"
					},
					{
						op: "activatePayment",
						actor: n,
						payment: t
					},
					{
						op: "activatePayment",
						actor: n,
						payment: {
							...t,
							slots: [],
							extra: []
						},
						text: "repeat"
					},
					a
				], i);
			}
			r.plans.length || s();
			break;
		case "poolReady":
			s();
			break;
		case "modifyAttack": {
			let n = t.normal ?? 0, i = t.indefensible ?? 0;
			e.challenge !== 262 && (n > 0 && f("H", 2) && l("distance", [p("H", 2), {
				...t,
				normal: n * 2,
				indefensible: i
			}]), n > 0 && f("Z", 1) && l("rage", [{
				...t,
				normal: n + (r.hp <= 30 ? 3 : 1),
				indefensible: i
			}]), n > 0 && l("daughter", [{
				...t,
				normal: 0,
				indefensible: n + i
			}])), s([{
				...t,
				op: "splitAttack"
			}]);
			break;
		}
		case "poolModifier":
			if (e.challenge === 232 && !B(r, "healingChosen")) {
				let e = m.filter((e) => e.symbol === "C").length;
				for (let t = 1; t <= e; t++) o("games.brave-and-bold.recover", [
					{
						op: "poolAdd",
						actor: n,
						n: -t
					},
					{
						op: "flag",
						actor: n,
						text: "healingChosen"
					},
					{
						op: "healSplit",
						actor: n,
						n: t
					},
					a
				], { amount: t });
			}
			for (let t of r.contributions) {
				if (t.normal + t.indefensible <= 0) continue;
				let i = t.ability;
				e.challenge !== 262 && (t.normal > 0 && f("H", 2) && l("distance", [
					p("H", 2),
					{
						op: "modifyContribution",
						actor: n,
						id: i,
						n: 2,
						text: "double"
					},
					a
				], { ability: i }), t.normal > 0 && f("Z", 1) && l("rage", [{
					op: "modifyContribution",
					actor: n,
					id: i,
					n: r.hp <= 30 ? 3 : 1,
					text: "add"
				}, a], { ability: i }), t.normal && l("daughter", [{
					op: "modifyContribution",
					actor: n,
					id: i,
					text: "convert"
				}, a], { ability: i }));
			}
			e.challenge !== 262 && r.hp <= 10 && f("Z", 2) && l("daughter", [
				p("Z", 2),
				{
					op: "convertPool",
					actor: n
				},
				{
					op: "flag",
					actor: n,
					text: "allIndefensible"
				},
				a
			]), s();
			break;
		case "splitAttack": {
			let e = t.normal ?? 0, r = t.indefensible ?? 0, a = e + r, s = t.target === void 0 ? h : [t.target];
			for (let i of s) {
				let c = t.text === "finisher" || s.length === 1 ? [a] : Array.from({ length: a }, (e, t) => a - t);
				for (let s of c) {
					let c = Math.min(e, s), l = s - c, u = a > s ? [{
						...t,
						normal: e - c,
						indefensible: r - l
					}] : [];
					o("games.brave-and-bold.dealDamage", [{
						op: "setHit",
						actor: n,
						target: i,
						normal: c,
						indefensible: l,
						text: t.text
					}, ...u], {
						kind: "target",
						target: i,
						amount: s
					});
				}
			}
			return i;
		}
		case "healSplit": {
			let r = t.n ?? 0;
			for (let i of pe(e, n)) {
				let a = e.seats.length === 2 ? [r] : Array.from({ length: r }, (e, t) => r - t);
				for (let e of a) o("games.brave-and-bold.recover", [{
					op: "heal",
					actor: n,
					target: i,
					n: e
				}, ...e < r ? [{
					...t,
					n: r - e
				}] : []], {
					kind: "target",
					target: i,
					amount: e
				});
			}
			return (!r || !i.length) && s(), i;
		}
		case "boost":
			if (e.hit && (e.hit.normal > 0 || e.hit.kind === "pool") && e.challenge !== 262) {
				l("senses", [{
					op: "boostDamage",
					actor: n,
					n: 1
				}, a]);
				for (let e = 0; e < r.hand.length; e++) r.hand[e] === "batarang" && B(r, "gadgetsPlayed") < 3 && o("games.brave-and-bold.playGadget", [
					{
						op: "gadgetReturn",
						actor: n,
						id: e
					},
					{
						op: "addFlag",
						actor: n,
						text: "gadgetsPlayed"
					},
					{
						op: "boostDamage",
						actor: n,
						n: 2
					},
					a
				], {
					kind: "gadget",
					nameKey: X.batarang
				});
			}
			return s(), i;
		case "defend": {
			let t = e.hit;
			if (t && t.normal > 0 && e.challenge !== 262) {
				f("W", 1) && o("games.brave-and-bold.preventDamage", [
					p("W", 1),
					{
						op: "addFlag",
						actor: n,
						text: "speedSpent"
					},
					{
						op: "defense",
						actor: n,
						n: 2
					},
					a
				], { amount: 2 }), f("B", 1) && o("games.brave-and-bold.preventDamage", [
					p("B", 1),
					{
						op: "defense",
						actor: n,
						n: 2
					},
					a
				], { amount: 2 }), l("senses", [{
					op: "defense",
					actor: n,
					n: 2
				}, a]), l("mechano", [{
					op: "defense",
					actor: n,
					n: 2
				}, a]), l("living", [{
					op: "absorb",
					actor: n
				}, a]);
				for (let e = 0; e < r.hand.length; e++) r.hand[e] === "smoke" && B(r, "gadgetsPlayed") < 3 && o("games.brave-and-bold.playGadget", [
					{
						op: "gadgetReturn",
						actor: n,
						id: e
					},
					{
						op: "addFlag",
						actor: n,
						text: "gadgetsPlayed"
					},
					{
						op: "defense",
						actor: n,
						n: 2
					},
					a
				], {
					kind: "gadget",
					nameKey: X.smoke
				});
			}
			return t && t.kind === "pool" && e.challenge !== 262 && f("H", 2) && l("fast", [
				p("H", 2),
				{
					op: "halfPool",
					actor: n
				},
				a
			]), t && t.target === n && t.allowDefer && t.normal + t.indefensible > 3 && e.challenge !== 262 && r.upgrades.includes("aegis") && !B(r, "aegisUsed") && o("games.brave-and-bold.useAegis", [{
				op: "defer",
				actor: n
			}, a], {
				kind: "upgrade",
				nameKey: Y.aegis
			}), s(), i;
		}
		case "finisher":
			B(r, "finisherUsed") || g(!0, !0), s();
			break;
		case "powerStart":
			if (B(r, "looseReturn")) {
				for (let e of u(R(r).filter((e) => ["U", "O"].includes(e.symbol)))) c(e, [
					{
						op: "returnToken",
						actor: n,
						id: e.id
					},
					{
						op: "addFlag",
						actor: n,
						text: "looseReturn",
						n: -1
					},
					a
				], "games.brave-and-bold.returnToken");
				if (i.length) return i;
			}
			if (!r.crisis) {
				l("mainMan", [{
					op: "search",
					actor: n,
					text: "removeNonCrisis"
				}, a]);
				for (let e of r.draw.concat(r.discard).filter((e) => e.symbol === "O")) o("games.brave-and-bold.cleanup", [
					{
						op: "returnToken",
						actor: n,
						id: e.id
					},
					{
						op: "search",
						actor: n,
						text: "removeNonCrisis"
					},
					a
				], {
					kind: "token",
					token: e
				});
				for (let t of e.challengeDiscard) l("reopen", [{
					op: "removeCard",
					actor: n,
					id: t
				}, a], { amount: t });
				l("fate", [{
					op: "marketSelect",
					actor: n,
					n: 6
				}, a]);
			}
			s();
			break;
		case "resupply": {
			let t = (r.crisis ? 2 : 3) - B(r, "buyReduction"), l = B(r, "powerAvailable") - B(r, "powerPurchases"), d = r.bought.length - B(r, "powerPurchases"), f = pe(e, n).reduce((t, n) => t + e.seats[n].resources, 0), p = (e, n) => (n ? l > 0 : d < t) && r.bought.filter((t) => t === e).length < (B(r, "ahead") ? 2 : 1);
			for (let e of u(r.supply)) {
				if ([
					"X",
					"K",
					"L",
					"Y",
					"Z",
					"O"
				].includes(e.symbol)) continue;
				let t = `${e.symbol}:${e.kind}`, r = T(e.symbol) ? 2 : ["U", "V"].includes(e.symbol) ? 5 : 3;
				for (let o of [!1, !0]) {
					let s = r - +!!o;
					!p(t, o) || f < s || (c(e, [
						{
							op: "payResources",
							actor: n,
							n: s
						},
						{
							op: "supplyTake",
							actor: n,
							id: e.id
						},
						{
							op: "recordPurchase",
							actor: n,
							text: t,
							n: +!!o
						},
						a
					], o ? "games.brave-and-bold.buyDiscount" : "games.brave-and-bold.buyToken"), i[i.length - 1].amount = s);
				}
			}
			for (let t of e.market) {
				let e = `${t.symbol}:${t.kind}`;
				if (t.kind === "critical") {
					let i = r.draw.some((e) => e.symbol === "D") ? 3 : 0, o = m.filter((e) => e.symbol === t.symbol && e.token !== t.id).slice(0, 10 - i).map((e) => e.id);
					o.length === 10 - i && p(e, !1) && c(t, [
						{
							op: "spendUnits",
							actor: n,
							names: o
						},
						...i ? [{
							op: "discardDiscount",
							actor: n
						}] : [],
						{
							op: "marketTake",
							actor: n,
							id: t.id
						},
						{
							op: "recordPurchase",
							actor: n,
							text: e
						},
						a
					], "games.brave-and-bold.buyCritical");
					continue;
				}
				for (let r of [!1, !0]) {
					let o = (t.kind === "double" ? 3 : 4) - !!r;
					!p(e, r) || f < o || (c(t, [
						{
							op: "payResources",
							actor: n,
							n: o
						},
						{
							op: "marketTake",
							actor: n,
							id: t.id
						},
						{
							op: "recordPurchase",
							actor: n,
							text: e,
							n: +!!r
						},
						a
					], r ? "games.brave-and-bold.buyDiscount" : "games.brave-and-bold.buyToken"), i[i.length - 1].amount = o);
				}
			}
			if (r.character === "batman" && f >= 2 && r.gadgetDeck.length && o("games.brave-and-bold.buyGadget", [
				{
					op: "payResources",
					actor: n,
					n: 2
				},
				{
					op: "drawGadget",
					actor: n
				},
				a
			]), e.round >= 3 && f >= 6) for (let t of h) e.seats[t].character === "superman" && e.seats[t].supply.some((e) => e.symbol === "K") && o("games.brave-and-bold.buyKryptonite", [
				{
					op: "payResources",
					actor: n,
					n: 6
				},
				{
					op: "gain",
					actor: t,
					symbol: "K",
					n: 1
				},
				a
			], {
				target: t,
				amount: 6
			});
			s([q("afterResupply", n)]);
			break;
		}
		case "refresh":
			for (let r of e.market) c(r, [{
				op: "marketSwap",
				actor: n,
				id: r.id
			}, ...t.n > 1 ? [{
				...t,
				n: t.n - 1
			}] : []], "games.brave-and-bold.replaceToken");
			s();
			break;
		case "rebalanceChoice": return e.challenge === 251 && r.tokensDrawn >= 7 && o("games.brave-and-bold.reduceCrisis", [{
			op: "flag",
			actor: n,
			text: "reduceCrisis"
		}]), s(), i;
		case "afterRebalance":
			if (e.challenge === 252 && r.crisis && !B(r, "crisisRemoved")) {
				for (let e of u(r.bag.filter((e) => !E(e)))) c(e, [
					{
						op: "returnToken",
						actor: n,
						id: e.id
					},
					{
						op: "flag",
						actor: n,
						text: "crisisRemoved"
					},
					a
				], "games.brave-and-bold.returnToken");
				if (i.length) return i;
			}
			return s(), i;
		case "afterResupply":
			if (e.challenge === 216) for (let n of h) for (let r of u(e.seats[n].discard.filter((e) => !E(e)))) c(r, [{
				op: "store",
				actor: n,
				id: r.id,
				text: "heldDiscard"
			}, ...(t.n ?? 2) > 1 ? [{
				...t,
				n: 1
			}] : []], "games.brave-and-bold.storeToken");
			return s(), i;
		case "endTurn":
			if (e.challenge === 273 && r.character === "lobo" && !B(r, "bountiesCollected") && !B(r, "bountyPenalty")) {
				let e = h[0];
				return o("games.brave-and-bold.resolveBounty", [
					{
						op: "flag",
						actor: n,
						text: "bountyPenalty"
					},
					{
						op: "recoveryChoice",
						actor: e,
						target: n,
						text: "loboPenalty"
					},
					a
				]), i;
			}
			s();
			break;
		case "declare":
			for (let e = 0; e < 6; e++) e !== 5 && o("games.brave-and-bold.declareAbility", [{
				op: "flag",
				actor: n,
				text: t.text === "lasso" ? "lasso" : t.text === "doubleDamage" ? "doubleAbility" : "declared",
				n: e + 1
			}], {
				kind: "ability",
				ability: e,
				character: r.character,
				nameKey: fe(r).abilities[e].nameKey
			});
			return i;
		case "contract":
			if (r.supply.some((e) => e.symbol === "O")) for (let e = 0; e < 5; e++) o("games.brave-and-bold.setContract", [{
				op: "contractPlace",
				actor: n,
				id: e
			}], {
				kind: "ability",
				ability: e,
				character: r.character,
				nameKey: fe(r).abilities[e].nameKey
			});
			return s(), i;
		case "upperHand":
			for (let t of e.deck.slice(0, 2)) o("games.brave-and-bold.replaceChallenge", [{
				op: "replaceChallenge",
				actor: n,
				id: t
			}], { amount: t });
			return s(), i;
		case "gadgetChoice":
			for (let e of [...new Set(t.names)]) o("games.brave-and-bold.takeGadget", [{
				op: "gadgetTake",
				actor: n,
				text: e
			}], {
				kind: "gadget",
				nameKey: X[e]
			});
			return i.length || s(), i;
		case "handLimit":
			for (let e = 0; e < r.hand.length; e++) o("games.brave-and-bold.returnGadget", [{
				op: "gadgetReturn",
				actor: n,
				id: e
			}, ...r.hand.length > 4 ? [a] : []], {
				kind: "gadget",
				nameKey: X[r.hand[e]]
			});
			return i;
		case "recoveryChoice":
			switch (t.text) {
				case "wonderWoman":
					for (let e of ["lasso", "bracelets"]) o("games.brave-and-bold.gainSpecial", [{
						op: "mark",
						actor: n,
						text: e
					}], {
						kind: "special",
						nameKey: N[e]
					});
					break;
				case "cheetah":
					o("games.brave-and-bold.dealDamage", [{
						op: "attack",
						actor: n,
						n: 1,
						text: "recovery"
					}], { amount: 1 }), o("games.brave-and-bold.gainResource", [{
						op: "addFlag",
						actor: n,
						text: "recoveryResources"
					}], { amount: 1 });
					break;
				case "clayface":
					t.tokens?.[0] && (c(t.tokens[0], [{
						op: "putTokens",
						actor: n,
						tokens: t.tokens,
						text: "draw"
					}], "games.brave-and-bold.keepToken"), c(t.tokens[0], [{
						op: "putTokens",
						actor: n,
						tokens: t.tokens,
						text: "supply"
					}], "games.brave-and-bold.returnToken"));
					break;
				case "supergirl":
					o("games.brave-and-bold.gainCompanion", [{
						op: "selfDamage",
						actor: n,
						n: 2
					}, {
						op: "mark",
						actor: n,
						text: "companion"
					}]), s();
					break;
				case "doubleBounty":
					l("double", [{
						op: "gain",
						actor: n,
						symbol: "O"
					}]), s();
					break;
				case "loboPenalty":
					o("games.brave-and-bold.dealDamage", [{
						op: "challengeDamage",
						actor: t.target,
						n: 5
					}], {
						target: t.target,
						amount: 5
					}), o("games.brave-and-bold.addCrisis", [{
						op: "addFlag",
						actor: t.target,
						text: "extraCrisis"
					}], { target: t.target });
					break;
				case "clayChallenge": o("games.brave-and-bold.addCrisis", [{
					op: "addFlag",
					actor: n,
					text: "extraCrisis"
				}]), o("games.brave-and-bold.giveClay", [{
					op: "gain",
					actor: t.target,
					symbol: "M"
				}]);
			}
			return i.length || s(), i;
		case "clayFinisherChoice": return o("games.brave-and-bold.dealDamage", [{
			op: "selfDamage",
			actor: t.target,
			n: 5
		}], {
			target: t.target,
			amount: 5
		}), o("games.brave-and-bold.takeFirst", [{
			op: "setFirst",
			actor: n
		}]), i;
		case "search": {
			let a = t.text, l = (e) => (t.n ?? 1) > 1 ? [{
				...t,
				n: t.n - e
			}] : [];
			if (a === "addBasicDraw") for (let e of u(r.bag.filter((e) => T(e.symbol) && e.kind === "basic"))) c(e, [{
				op: "moveToDraw",
				actor: n,
				id: e.id
			}, ...l(1)]);
			else if (["temporaryBasic", "gainSun"].includes(a)) for (let t of u(r.supply.filter((e) => a === "gainSun" ? ["Y", "Z"].includes(e.symbol) : T(e.symbol) && e.kind === "basic"))) c(t, [a === "temporaryBasic" ? {
				op: "temporary",
				actor: n,
				symbol: t.symbol,
				n: e.challenge
			} : {
				op: "gain",
				actor: n,
				symbol: t.symbol
			}, ...l(1)]);
			else if (a === "focusCrisis") for (let e of r.draw.filter((e) => t.names?.includes(String(e.id)))) c(e, [{
				op: "returnToken",
				actor: n,
				id: e.id,
				text: "bag"
			}], "games.brave-and-bold.returnCrisis");
			else if (a === "flashRecovery") {
				if (R(r).filter((e) => e.symbol === "X").length > 3) for (let e of u(r.bag.filter((e) => e.symbol === "X"))) c(e, [{
					op: "returnToken",
					actor: n,
					id: e.id,
					text: "discard"
				}], "games.brave-and-bold.discardToken");
			} else if (a === "planeStore") for (let e of u(r.bag.filter((e) => !E(e)))) c(e, [{
				op: "store",
				actor: n,
				id: e.id,
				text: "plane"
			}], "games.brave-and-bold.storeToken");
			else if (a === "removeNonCrisis" || a === "removeBagNonCrisis" || a === "removeBasic" || a === "tweakBag") {
				let e = a === "removeNonCrisis" ? R(r) : r.bag;
				for (let t of u(e.filter((e) => a === "removeBasic" ? T(e.symbol) && e.kind === "basic" : !E(e)))) c(t, [{
					op: "returnToken",
					actor: n,
					id: t.id
				}], "games.brave-and-bold.returnToken");
				if (a === "tweakBag") for (let e of u(r.supply.filter((e) => T(e.symbol) && e.kind === "basic"))) c(e, [{
					op: "gain",
					actor: n,
					symbol: e.symbol
				}], "games.brave-and-bold.gainToken");
			} else if (a === "opponentDiscard") for (let t of h) for (let n of u(e.seats[t].draw)) c(n, [{
				op: "returnToken",
				actor: t,
				id: n.id,
				text: "discard"
			}], "games.brave-and-bold.discardToken");
			else if (a === "clayChallengeOpponent") for (let e of h) o("games.brave-and-bold.chooseOpponent", [{
				op: "recoveryChoice",
				actor: e,
				target: n,
				text: "clayChallenge"
			}], {
				kind: "target",
				target: e
			});
			else if (a === "exchangeDraw") for (let e of u(r.draw.filter((e) => !E(e)))) c(e, [{
				op: "flag",
				actor: n,
				text: "exchangeId",
				n: e.id + 1
			}, {
				op: "search",
				actor: n,
				text: "exchangeBag"
			}]);
			else if (a === "exchangeBag") for (let e of u(r.bag.filter((e) => !E(e)))) c(e, [{
				op: "exchange",
				actor: n,
				id: e.id
			}]);
			else if (a === "contingency") for (let e of r.draw.filter((e) => L(r).some((t) => t.token === e.id))) c(e, [{
				op: "store",
				actor: n,
				id: e.id,
				text: "contingency"
			}], "games.brave-and-bold.storeToken");
			return (!i.length || !["addBasicDraw", "temporaryBasic"].includes(a)) && s(), i;
		}
		case "marketSelect":
			for (let r of u(e.armoury)) c(r, [{
				op: "selectMarketToken",
				actor: n,
				id: r.id
			}, ...t.n > 1 ? [{
				...t,
				n: t.n - 1
			}] : []]);
			return i.length || s(), i;
		case "clayCombat":
			if ((!r.crisis || r.character === "clayface") && g(!1, !0), r.character === "clayface" && e.challenge === 222 && !B(r, "freeCopy") && t.payment) {
				let r = {
					...t.payment,
					slots: [],
					extra: [],
					target: e.clayAttacker,
					copied: !0
				};
				o("games.brave-and-bold.activateAbility", [
					{
						op: "flag",
						actor: n,
						text: "freeCopy"
					},
					{
						op: "activatePayment",
						actor: n,
						payment: r
					},
					{
						op: "clayAfterAttack",
						actor: n
					}
				], {
					kind: "ability",
					ability: r.ability,
					character: r.character,
					nameKey: M.find((e) => e.id === r.character).abilities[r.ability].nameKey
				});
			}
			r.character === "clayface" ? s([{
				op: "clayAfterAttack",
				actor: n
			}]) : s([{
				op: "clayPass",
				actor: n
			}]);
	}
	if (e.challenge === 215 && ["combat", "powerUp"].includes(e.phase) && r.tokensDrawn > 0 && !B(r, "allUsedReward") && he(r).length === 0 && o("games.brave-and-bold.dealDamage", [
		{
			op: "flag",
			actor: n,
			text: "allUsedReward"
		},
		{
			op: "attack",
			actor: n,
			n: 2
		},
		a
	], { amount: 2 }), ![
		"select",
		"upgrade",
		"drawChoice"
	].includes(t.op)) {
		if (m.some((e) => e.symbol === "F" && e.token !== null) && e.deck.length && o("games.brave-and-bold.peekChallenge", [
			{
				op: "spendUnits",
				actor: n,
				names: [m.find((e) => e.symbol === "F" && e.token !== null).id]
			},
			{
				op: "peek",
				actor: n
			},
			a
		]), e.challenge !== 269) for (let t of e.market.filter((e) => e.kind === "power")) l("mechano", [
			{
				op: "marketTake",
				actor: n,
				id: t.id,
				text: "mechano"
			},
			{
				op: "exhaustMark",
				actor: n,
				text: "mechano"
			},
			a
		], {
			token: t,
			label: "games.brave-and-bold.stealPower"
		});
		if (e.deck.length && t.op !== "upperHand" && l("upperHand", [q("upperHand", n), a]), e.phase === "preparation" && !r.crisis && e.challenge !== 233) {
			if (r.character === "flash" && Ve(e, n) < 3 && f("W", 2)) for (let e of r.draw.filter((e) => e.symbol === "X")) o("games.brave-and-bold.returnCrisis", [
				p("W", 2),
				{
					op: "addFlag",
					actor: n,
					text: "speedSpent",
					n: 2
				},
				{
					op: "returnToken",
					actor: n,
					id: e.id,
					text: "bag"
				},
				a
			], { token: e });
			if (f("M", 2) || m.filter((e) => ["M", "I"].includes(e.symbol) && e.token !== null).length >= 2) for (let t of P(e)) for (let r of e.seats[t].draw.filter((e) => e.symbol === "X")) l("predatory", [
				{
					op: "spendUnits",
					actor: n,
					names: m.filter((e) => ["M", "I"].includes(e.symbol) && e.token !== null).slice(0, 2).map((e) => e.id)
				},
				{
					op: "returnToken",
					actor: t,
					id: r.id,
					text: "bag"
				},
				a
			], {
				target: t,
				token: r
			});
		}
		if (e.challenge !== 233) for (let t of P(e)) {
			for (let n of e.seats[t].draw.filter((e) => e.symbol === "X")) l("destiny", [{
				op: "returnToken",
				actor: t,
				id: n.id,
				text: "bag"
			}, a], {
				target: t,
				token: n
			});
			for (let n of e.seats[t].draw.filter((n) => !e.seats[t].plans.some((e) => e.slots.flat().some((e) => e.startsWith(`${n.id}:`))))) l("subvert", [{
				op: "returnToken",
				actor: t,
				id: n.id,
				text: "discard"
			}, a], {
				target: t,
				token: n
			});
		}
		if (r.character === "flash" && f("W", 3) && o("games.brave-and-bold.speedAttack", [
			p("W", 3),
			{
				op: "addFlag",
				actor: n,
				text: "speedSpent",
				n: 3
			},
			{
				op: "attack",
				actor: n,
				n: 4
			},
			a
		]), e.challenge !== 269 && r.supply.some((e) => e.symbol === "S") && l("flight", [
			{
				op: "gain",
				actor: n,
				symbol: "S"
			},
			{
				op: "gain",
				actor: n,
				symbol: "S"
			},
			{
				op: "addFlag",
				actor: n,
				text: "flightReturns",
				n: 2
			},
			a
		]), e.phase === "combat" && !r.crisis) {
			l("explosive", [{
				op: "attack",
				actor: n,
				normal: 0,
				indefensible: 3
			}, a]), [
				"allocate",
				"activate",
				"clayCombat"
			].includes(t.op) && l("hitFirst", [{
				op: "flag",
				actor: n,
				text: "nextIndefensible"
			}, a]), e.challenge !== 262 && !e.seats.some((e) => e.character === "clayface") && !B(r, "poolResolved") && B(r, "tookDamage") && B(r, "crisisDrawn") > 0 && l("wrath", [
				{
					op: "addFlag",
					actor: n,
					text: "wrathDamage",
					n: 3 * B(r, "crisisDrawn")
				},
				{
					op: "poolAdd",
					actor: n,
					n: B(r, "poolCalculated") ? 3 * B(r, "crisisDrawn") : 0
				},
				a
			]);
			for (let e of r.draw.filter((e) => e.kind === "critical")) {
				let t = r.draw.some((e) => e.symbol === "D") ? 3 : 0, i = m.filter((t) => t.symbol === e.symbol && t.token !== e.id).slice(0, 10 - t).map((e) => e.id);
				if (i.length === 10 - t) for (let r of h) c(e, [
					{
						op: "spendUnits",
						actor: n,
						names: [...i, `${e.id}:0`]
					},
					...t ? [{
						op: "discardDiscount",
						actor: n
					}] : [],
					{
						op: "critical",
						actor: n,
						target: r
					},
					a
				], "games.brave-and-bold.activateCritical");
			}
			for (let e = 0; e < r.hand.length && !(B(r, "gadgetsPlayed") >= 3); e++) r.hand[e] === "grapple" && ["allocate", "crisisAbility"].includes(t.op) && o("games.brave-and-bold.playGadget", [
				{
					op: "gadgetReturn",
					actor: n,
					id: e
				},
				{
					op: "addFlag",
					actor: n,
					text: "gadgetsPlayed"
				},
				{
					op: "addBonus",
					actor: n,
					symbol: "A"
				},
				a
			], {
				kind: "gadget",
				nameKey: X.grapple
			}), r.hand[e] === "contingency" && t.op === "finisher" && o("games.brave-and-bold.playGadget", [
				{
					op: "gadgetReturn",
					actor: n,
					id: e
				},
				{
					op: "addFlag",
					actor: n,
					text: "gadgetsPlayed"
				},
				{
					op: "search",
					actor: n,
					text: "contingency"
				},
				a
			], {
				kind: "gadget",
				nameKey: X.contingency
			});
		}
		if (r.character === "clayface" && H(e, r, "imitation") && (e.phase === "preparation" || e.phase === "combat" || e.phase === "powerUp" && t.op === "powerStart")) for (let r of h) {
			let o = i.length;
			g(!1, !0, !0, e.seats[r].character);
			for (let e = o; e < i.length; e++) i[e].steps = [
				{
					op: "spendMark",
					actor: n,
					text: "imitation"
				},
				...i[e].steps.filter((e) => e.op !== "clayAfterAttack"),
				...t.op === "clayCombat" ? [a] : []
			];
		}
		!(r.crisis && ["combat", "powerUp"].includes(e.phase)) && h.some((t) => e.seats[t].tokensDrawn > 0 && he(e.seats[t]).length === 0) && l("scent", [{
			op: "attack",
			actor: n,
			n: 3
		}, a]), l("ahead", [
			{
				op: "setFirst",
				actor: n
			},
			{
				op: "flag",
				actor: n,
				text: "ahead"
			},
			a
		]);
	}
	return i;
}
//#endregion
//#region src/games/brave-and-bold/rules.ts
function nt() {
	return { code: "games.brave-and-bold.errAction" };
}
function rt(e) {
	for (let t = 0; t < 200; t++) {
		if (Qe(e), e.beat || e.phase === "done") return;
		let t = tt(e);
		if (t.length !== 1 || t[0].label !== "games.brave-and-bold.continue") return;
		e.tasks.shift(), J(e, ...t[0].steps);
	}
}
function it(e, t, n) {
	let r = e.tasks[0];
	if (!r) return !1;
	let i = r.actor, a = e.seats[i];
	if (a.rid !== t || !F(e, i).includes(n.target)) return !1;
	let o = M.find((e) => e.id === n.character), s = n.character !== a.character, c = s && a.character === "clayface" && F(e, i).some((t) => e.seats[t].character === n.character) && H(e, a, "imitation") && (e.phase === "preparation" || e.phase === "combat" || r.op === "powerStart");
	if (!o || s && !c || !s && ![
		"allocate",
		"finisher",
		"clayCombat",
		"crisisAbility"
	].includes(r.op)) return !1;
	let l = o.abilities[n.payment.ability];
	if (!l || !!l.finisher != (!s && r.op === "finisher") || l.finisher && B(a, "finisherUsed") || a.crisis && a.character !== "clayface" && r.op !== "crisisAbility" || r.op === "crisisAbility" && e.challenge !== 243 && !H(e, a, "companion") || B(a, "lasso") && !l.finisher && !s && B(a, "lasso") !== (l.group ?? n.payment.ability) + 1 || !Ne(l, n.payment, L(a), Be(e, a, s)) || r.op === "allocate" && a.plans.some((e) => (o.abilities[e.ability].group ?? e.ability) === (l.group ?? n.payment.ability)) || e.challenge === 271 && [...a.plans.flatMap((e) => e.slots.flat()), ...n.payment.slots.flat()].filter((e) => [...O(a.draw), ...a.bonuses].find((t) => t.id === e)?.symbol === "E" && [...O(a.draw), ...a.bonuses].find((t) => t.id === e)?.token !== null).length + B(a, "crestActivated") > 3 || e.challenge === 266 && B(a, "combatAssignedAbility") && B(a, "combatAssignedAbility") !== n.payment.ability + 1 && n.payment.slots.flat().some((e) => L(a).find((t) => t.id === e)?.symbol === "C")) return !1;
	let u = {
		...n.payment,
		character: o.id,
		target: n.target,
		copied: s
	};
	return e.tasks.shift(), s ? J(e, {
		op: "spendMark",
		actor: i,
		text: "imitation"
	}, {
		op: "activatePayment",
		actor: i,
		payment: u
	}, r) : ["finisher", "clayCombat"].includes(r.op) ? J(e, {
		op: "activatePayment",
		actor: i,
		payment: u
	}, r.op === "clayCombat" ? {
		op: "clayAfterAttack",
		actor: i
	} : r) : r.op === "crisisAbility" ? J(e, ...e.challenge === 243 ? [] : [{
		op: "spendMark",
		actor: i,
		text: "companion"
	}], {
		op: "reserve",
		actor: i,
		payment: u
	}, {
		op: "allocationDone",
		actor: i
	}) : J(e, {
		op: "reserve",
		actor: i,
		payment: u
	}, r), !0;
}
function at(e, t) {
	let n = e.tasks[0], r = n?.actor, i = e.seats.findIndex((e) => e.rid === t), a = e.seats[i];
	return {
		public: {
			phase: e.phase,
			round: e.round,
			first: e.first,
			active: e.beat || r === void 0 ? null : r,
			prompt: e.beat ? null : n?.op ?? null,
			expansion: e.expansion,
			challenge: e.challenge,
			remainingChallenges: e.deck.length,
			market: e.market,
			marketRemaining: e.armoury.length,
			clay: I(e),
			winner: e.winner,
			hit: e.hit,
			logs: e.logs,
			seats: e.seats.map((e) => ({
				rid: e.rid,
				character: e.character,
				team: e.team,
				hp: e.hp,
				injured: e.injured,
				defeated: e.defeated,
				bagCount: e.bag.length,
				bagContents: [...e.bag].sort((e, t) => e.id - t.id),
				draw: e.draw,
				discard: e.discard,
				stored: e.stored,
				supply: e.supply,
				reverse: e.reverse,
				marks: e.marks,
				exhausted: e.exhausted,
				upgrades: e.upgrades,
				bonuses: e.bonuses,
				spent: e.spent,
				plans: e.plans,
				activated: e.activated,
				resources: e.resources,
				pool: e.pool,
				contracts: e.contracts,
				nonCrisisDrawn: e.nonCrisisDrawn,
				tokensDrawn: e.tokensDrawn,
				stopped: e.stopped,
				crisis: e.crisis,
				handCount: e.hand.length,
				deferred: e.deferred
			}))
		},
		private: {
			choices: i === r ? tt(e).map((e) => {
				let { steps: t, ...n } = e;
				return n;
			}) : [],
			hand: a?.hand ?? [],
			peek: a?.peek ?? [],
			units: a ? L(a) : [],
			canAllocate: i === r && !!n && ([
				"allocate",
				"finisher",
				"clayCombat",
				"crisisAbility"
			].includes(n.op) || !(!a || a.character !== "clayface" || !H(e, a, "imitation") || e.phase !== "preparation" && n.op !== "powerStart")),
			paymentContext: a ? Be(e, a) : {
				character: "",
				noSubstitution: !1,
				redAsCombat: !1,
				escape: 0,
				imitate: !1
			}
		}
	};
}
var ot = {
	meta: ue,
	saveCompatibility: { version: "1" },
	schemas: {
		action: oe,
		publicView: ce,
		privateView: le,
		config: k
	},
	setup(e, t, n) {
		let r = Fe(e, t, n);
		return rt(r), { state: r };
	},
	reduce(e, t, n) {
		if (e.phase === "done") return nt();
		let r = structuredClone(e);
		if (r.effects = [], t.type === "tick") {
			if (n.by !== "$engine" || !r.beat) return nt();
			r.beat = 0;
		} else {
			if (r.beat || r.tasks[0]?.actor === void 0 || r.seats[r.tasks[0].actor].rid !== n.by) return nt();
			if (t.type === "allocate") {
				if (!it(r, n.by, t)) return nt();
			} else {
				let e = tt(r).find((e) => e.id === t.id);
				if (!e) return nt();
				r.tasks.shift(), J(r, ...e.steps);
			}
		}
		r.revision++, rt(r);
		let i = r.effects;
		return delete r.effects, i?.length && !r.beat && r.phase !== "done" && (r.beat = 380), {
			state: r,
			...i?.length ? { fx: i } : {}
		};
	},
	viewFor: at,
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.seats].sort((t, n) => Number(e.winner.includes(n.rid)) - Number(e.winner.includes(t.rid)) || n.hp - t.hp).map((e) => e.rid);
		return {
			phase: "done",
			winner: e.winner,
			ranking: t,
			scores: Object.fromEntries(e.seats.map((e) => [e.rid, e.hp]))
		};
	},
	nextTickIn: (e) => e.beat || null
}, Z = (e) => `games.brave-and-bold.${e}`, st = (e) => `games/brave-and-bold/${e}.webp`, ct = {
	batman: "#223e60",
	superman: "#165a9e",
	wonderWoman: "#982f36",
	flash: "#a72d31",
	darkseid: "#3f4350",
	lex: "#465937",
	cheetah: "#754329",
	clayface: "#744831",
	supergirl: "#1c5a80",
	lobo: "#454553"
};
function Q({ symbol: e, kind: t = "basic", character: n = "batman", size: r = 40 }) {
	let i = s();
	return /* @__PURE__ */ _("span", {
		className: `bb-token bb-token--${t}`,
		style: { "--bb-token": `${r}px` },
		title: i(Z("token_" + e)),
		children: [/* @__PURE__ */ g("img", {
			src: `games/brave-and-bold/${e === "E" ? `E-${n}` : e}.webp`,
			alt: i(Z("token_" + e)),
			draggable: !1
		}), t !== "basic" && /* @__PURE__ */ g("b", {
			className: "bb-token-kind",
			title: i(Z(t)),
			children: t === "double" ? "×2" : t === "power" ? "+" : i("games.brave-and-bold.criticalBadge")
		})]
	});
}
function lt({ size: e = 20 }) {
	let t = s();
	return /* @__PURE__ */ g("img", {
		className: "bb-resource-icon",
		src: "games/brave-and-bold/R.webp",
		alt: t("games.brave-and-bold.resources"),
		width: e,
		height: e,
		draggable: !1
	});
}
function $({ name: e, className: t = "", children: n, style: r }) {
	let { ref: i, hidden: a } = m(e);
	return /* @__PURE__ */ g("div", {
		ref: i,
		className: t,
		style: {
			...r,
			visibility: a ? "hidden" : void 0
		},
		children: n
	});
}
function ut({ token: e, character: t, onClick: n, legal: r = !1, selected: i = !1, size: a = 44, anchor: o }) {
	let c = s(), { ref: u, hidden: d } = m(o ?? `token:${e.id}`);
	return /* @__PURE__ */ _("button", {
		type: "button",
		ref: u,
		className: `bb-token-object${i ? " is-selected" : ""}`,
		style: { visibility: d ? "hidden" : void 0 },
		onClick: n,
		"aria-label": c("games.brave-and-bold.tokenLabel", {
			name: c(Z("token_" + e.symbol)),
			kind: c(Z(e.kind))
		}),
		children: [/* @__PURE__ */ g(Q, {
			symbol: e.symbol,
			kind: e.kind,
			character: t,
			size: a
		}), r && /* @__PURE__ */ g(l, {
			radius: 999,
			flash: !1
		})]
	});
}
function dt({ ability: e, character: t }) {
	return /* @__PURE__ */ g("span", {
		className: "bb-cost",
		children: e.cost.split(" ").map((e, n) => /* @__PURE__ */ g("span", {
			className: "bb-cost-slot",
			children: e.split("|").map((e, n) => /* @__PURE__ */ _("span", {
				className: "bb-cost-option",
				children: [n > 0 && /* @__PURE__ */ g("small", { children: "/" }), [...e].map((e, n) => /* @__PURE__ */ g(Q, {
					symbol: e,
					character: t,
					size: 25
				}, n))]
			}, e))
		}, n))
	});
}
function ft({ ability: e, compact: t = !1 }) {
	let n = s();
	return /* @__PURE__ */ _("span", {
		className: "bb-effect",
		children: [
			(e.damage > 0 || e.dynamic) && /* @__PURE__ */ _("strong", {
				className: e.indefensible ? "bb-indefensible" : "",
				children: [
					e.indefensible ? "◆" : "✹",
					" ",
					e.damage || "",
					e.dynamic ? n("games.brave-and-bold.abilityDynamic") : ""
				]
			}),
			!!e.heal && /* @__PURE__ */ _("span", { children: ["♥ +", e.heal] }),
			!!e.resource && /* @__PURE__ */ _("span", { children: [
				/* @__PURE__ */ g(lt, {}),
				" +",
				e.resource
			] }),
			e.marks?.filter((e, t, n) => n.indexOf(e) === t).map((r) => /* @__PURE__ */ _("span", {
				className: "bb-effect-mark",
				title: n(N[r]),
				children: [
					/* @__PURE__ */ g("img", {
						src: `games/brave-and-bold/mark-${r}.webp`,
						alt: t ? n(N[r]) : ""
					}),
					!t && n(N[r]),
					/* @__PURE__ */ _("b", { children: ["×", e.marks.filter((e) => e === r).length] })
				]
			}, r)),
			e.gain?.map((e, t) => /* @__PURE__ */ _("span", { children: ["+", /* @__PURE__ */ g(Q, {
				symbol: e,
				size: 21
			})] }, `${e}:${t}`)),
			e.selfDamage && /* @__PURE__ */ _("span", { children: ["♥ −", e.selfDamage] }),
			e.gadgetSelect && /* @__PURE__ */ g("span", { children: n("games.brave-and-bold.takeGadget") }),
			e.extraResponse && /* @__PURE__ */ g("span", { children: n("games.brave-and-bold.extraResponse") }),
			e.recoverClay && /* @__PURE__ */ g("span", { children: n("games.brave-and-bold.recoverClay") }),
			e.holdKryptonite && /* @__PURE__ */ g("span", { children: n("games.brave-and-bold.holdKryptonite") })
		]
	});
}
//#endregion
//#region src/games/brave-and-bold/feedback.tsx
function pt({ value: e, identity: t }) {
	let i = r({
		value: e,
		identity: t
	}), a = r(null), o = p();
	return n(() => {
		let n = i.current;
		i.current = {
			value: e,
			identity: t
		};
		let r = a.current;
		if (!r || (r.textContent = "", n.identity !== t || n.value === e)) return;
		let s = e - n.value;
		r.textContent = `${s > 0 ? "+" : "−"}${Math.abs(s)}`;
		let c = r.animate(o ? [{ opacity: 1 }, { opacity: 0 }] : [
			{
				opacity: 0,
				transform: "translateY(5px) scale(.9)"
			},
			{
				opacity: 1,
				transform: "translateY(-3px) scale(1)",
				offset: .16
			},
			{
				opacity: 1,
				transform: "translateY(-5px)",
				offset: .72
			},
			{
				opacity: 0,
				transform: "translateY(-13px)"
			}
		], {
			duration: 900,
			easing: "ease-out",
			fill: "both"
		});
		return () => c.cancel();
	}, [
		e,
		t,
		o
	]), /* @__PURE__ */ _("span", {
		className: "bb-number",
		children: [/* @__PURE__ */ g(f, { value: e }, t), /* @__PURE__ */ g("span", {
			ref: a,
			className: "bb-number-delta",
			"aria-hidden": "true"
		})]
	});
}
function mt(e, t) {
	let n = s(), r = t?.choices ?? [], i = r.filter((e) => ![
		"continue",
		"clearAllocation",
		"confirmAllocation"
	].some((t) => e.label.endsWith("." + t)));
	if (e.prompt === "prepare") return n("games.brave-and-bold.instructionDraw");
	if (e.prompt === "allocate") return n(i.some((e) => e.kind === "ability") ? "games.brave-and-bold.instructionAllocate" : "games.brave-and-bold.instructionConfirm");
	if (e.prompt === "activate" && i.some((e) => e.label.endsWith(".activateAbility"))) return n("games.brave-and-bold.instructionActivate");
	if (e.prompt === "defend" && e.hit) return n(i.length ? "games.brave-and-bold.instructionDefend" : "games.brave-and-bold.instructionTakeHit", {
		normal: e.hit.normal,
		indefensible: e.hit.indefensible
	});
	if (i.some((e) => e.kind === "target")) return n(e.prompt === "healSplit" ? "games.brave-and-bold.instructionHeal" : "games.brave-and-bold.instructionTarget");
	if (e.prompt === "resupply") return n(i.some((e) => e.token) ? "games.brave-and-bold.instructionBuy" : "games.brave-and-bold.instructionContinue");
	if (i.length && i.every((e) => e.kind === "ability")) return n("games.brave-and-bold.instructionAbility");
	if (i.length && i.every((e) => e.kind === "token")) return n("games.brave-and-bold.instructionToken", { action: n(Z(i[0].label.split(".").at(-1))) });
	if (i.length && i.every((e) => e.kind === "character")) return n("games.brave-and-bold.selectPrompt");
	if (i.length && i.every((e) => e.kind === "upgrade")) return n("games.brave-and-bold.chooseUpgrade");
	let a = r.some((e) => e.label.endsWith(".continue"));
	return n(i.length ? a ? "games.brave-and-bold.instructionOptional" : "games.brave-and-bold.instructionChoose" : "games.brave-and-bold.instructionContinue");
}
function ht({ pub: e, nameOf: t }) {
	let n = s(), r = [...e.logs].reverse().find((e) => e.key.endsWith(".logActivate")), i = e.logs.at(-1), a = (e) => `${e.actor === void 0 ? "" : t(e.actor) + " · "}${e.key.endsWith(".logActivate") ? n("games.brave-and-bold.logActivate", { ability: n(Z(String(e.params.ability).split(".").at(-1))) }) : n(Z(e.key.split(".").at(-1)), e.params)}`, o = r ? a(r) : "", c = i && i !== r ? a(i) : "";
	return /* @__PURE__ */ _("div", {
		className: "bb-battle-report",
		role: "status",
		"aria-live": "polite",
		children: [/* @__PURE__ */ _("span", {
			className: "bb-last-ability",
			children: [/* @__PURE__ */ g("small", { children: n("games.brave-and-bold.latestAbility") }), /* @__PURE__ */ g("b", { children: o || "—" }, o)]
		}), /* @__PURE__ */ g("span", {
			className: "bb-last-result",
			children: c
		}, c)]
	});
}
//#endregion
//#region src/games/brave-and-bold/view-player.tsx
function gt(e) {
	return /* @__PURE__ */ g(_t, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function _t({ pub: e, priv: t, members: n, myRid: r, send: f }) {
	let p = s(), m = o((e) => e.locale), v = Math.max(0, e.seats.findIndex((e) => e.rid === r)), [ee, te] = i(null), [y, b] = i(null), [ne, x] = i(r);
	ne !== r && (x(r), b(null), te(null));
	let S = ee !== null && e.seats[ee] ? ee : v, C = e.seats[S], w = M.find((e) => e.id === C.character), T = e.phase === "done" ? [] : t?.choices ?? [], re = e.active === v && T.length > 0, D = (t) => {
		let r = n.find((n) => n.rid === e.seats[t].rid);
		return r ? d(r, m) : p("games.brave-and-bold.unselected");
	}, O = (e) => {
		T.some((t) => t.id === e.id) && (f({
			type: "choose",
			id: e.id
		}), b(null));
	}, k = (e, t) => {
		e.length === 1 ? O(e[0]) : e.length && b({
			kind: "choices",
			ids: e.map((e) => e.id),
			title: t
		});
	}, A = (e) => [
		p(Z(e.label.split(".").at(-1)), e.params),
		e.nameKey ? p(Z(e.nameKey.split(".").at(-1))) : e.token ? p(Z("token_" + e.token.symbol)) : "",
		e.target === void 0 ? "" : D(e.target),
		e.amount === void 0 ? "" : String(e.amount)
	].filter(Boolean).join(" · "), ie = e.phase === "done" ? p("games.brave-and-bold.done") : e.active === null ? p("games.brave-and-bold.resolving") : re ? p(Z(e.phase)) : p("games.brave-and-bold.waiting", { name: D(e.active) }), ae = mt(e, t), oe = T.filter((e) => e.kind === "action" && [
		"continue",
		"confirmAllocation",
		"stop",
		"clearAllocation"
	].some((t) => e.label.endsWith("." + t))), j = T.find((e) => e.label === "games.brave-and-bold.draw"), se = (t) => t.kind === "character" && e.phase === "select" || t.kind === "ability" && t.character === w?.id && [
		"allocate",
		"activate",
		"clayCombat",
		"crisisAbility",
		"finisher"
	].includes(e.prompt ?? "") || t.kind === "token" && [
		...C.draw,
		...C.supply,
		...e.market
	].some((e) => e.id === t.token?.id) || t.kind === "special" && Object.keys(w?.specials ?? {}).some((e) => t.nameKey === N[e]) || t.kind === "target", ce = T.filter((e) => e !== j && !oe.includes(e) && !se(e)), le = T.filter((t) => ["upgrade", "target"].includes(t.kind) || t.kind === "ability" && ![
		"allocate",
		"activate",
		"clayCombat",
		"crisisAbility",
		"finisher"
	].includes(e.prompt ?? "")), ue = de.find((t) => t.id === e.challenge), fe = y?.kind === "choices" ? T.filter((e) => y.ids.includes(e.id)) : y?.kind === "special" ? T.filter((e) => e.nameKey === N[y.key]) : [], P = y?.kind === "ability" ? M.find((e) => e.id === y.character)?.abilities[y.ability] : void 0, F = y?.kind === "ability" ? T.filter((e) => e.kind === "ability" && e.character === y.character && e.ability === y.ability) : [], pe = !!(P && t?.canAllocate && F.length && [
		"allocate",
		"finisher",
		"clayCombat",
		"crisisAbility",
		"powerStart",
		"prepare",
		"prepStart",
		"prepEnd"
	].includes(e.prompt ?? "")), I = e.seats[v], me = `${r}:${e.prompt}:${y?.kind === "ability" ? y.character + ":" + y.ability : ""}:${t?.units.map((e) => e.id).join(",")}`, [L, R] = i(null), he = (P && t && y?.kind === "ability" ? Pe(P, y.ability, t.units, {
		...t.paymentContext,
		imitate: y.character !== I.character
	}, 1)[0] : void 0) ?? {
		ability: y?.kind === "ability" ? y.ability : 0,
		slots: P?.cost.split(" ").map(() => []) ?? [],
		extra: []
	}, z = L?.scope === me ? L : {
		scope: me,
		payment: he,
		target: e.seats.findIndex((e) => e.team !== I.team && !e.defeated),
		slot: 0
	}, ge = (e, t = z.slot) => R({
		...z,
		payment: e,
		slot: t
	}), B = !!(P && t && Ne(P, z.payment, t.units, {
		...t.paymentContext,
		imitate: y?.kind === "ability" && y.character !== I.character
	})), V = (e) => T.filter((t) => t.token?.id === e.id), _e = y?.kind === "ability" && P ? p(P.nameKey) : y?.kind === "choices" ? y.title : y?.kind === "special" ? p(N[y.key]) : y?.kind === "tokens" ? p(Z(y.zone === "bagContents" ? "bag" : y.zone)) : y?.kind === "token" ? p(Z("token_" + y.token.symbol)) : y?.kind === "upgrade" ? p(Y[y.key]) : y?.kind === "hand" ? p("games.brave-and-bold.gadgets") : y?.kind === "character" ? p(M.find((e) => e.id === y.character).nameKey) : y?.kind === "logs" ? p("games.brave-and-bold.log") : "", H = (e) => e.filter((t, n) => e.findIndex((e) => e.symbol === t.symbol && e.kind === t.kind) === n);
	return /* @__PURE__ */ _(c, {
		adaptive: !0,
		className: "bb-screen",
		scroll: !1,
		actionsHeight: "bb-actions-height",
		banner: /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ _("div", {
				className: "bb-masthead",
				children: [/* @__PURE__ */ _("strong", { children: [
					"BRAVE ",
					/* @__PURE__ */ g("i", { children: "&" }),
					" BOLD"
				] }), /* @__PURE__ */ _("span", { children: [
					p("games.brave-and-bold.round", { n: e.round }),
					" · ",
					ie
				] })]
			}),
			/* @__PURE__ */ g("div", {
				className: "bb-seats",
				children: e.seats.map((t, i) => {
					let a = n.find((e) => e.rid === t.rid), o = M.find((e) => e.id === t.character), s = T.filter((e) => e.kind === "target" && e.target === i);
					return /* @__PURE__ */ g($, {
						name: `seat:${t.rid}`,
						className: `bb-seat${S === i ? " is-shown" : ""}${e.active === i ? " is-active" : ""}${t.defeated ? " is-defeated" : ""}`,
						children: /* @__PURE__ */ _("button", {
							className: "bb-seat-button",
							onClick: () => {
								s.length ? k(s, D(i)) : te(i);
							},
							"aria-pressed": S === i,
							children: [
								a && /* @__PURE__ */ g(u, {
									m: a,
									myRid: r,
									action: null,
									anchorName: null,
									box: "size-7",
									img: "size-7"
								}),
								/* @__PURE__ */ _("span", {
									className: "bb-seat-person",
									children: [/* @__PURE__ */ g("b", { children: D(i) }), /* @__PURE__ */ _("small", { children: [p(o ? o.nameKey : "games.brave-and-bold.unselected"), e.first === i ? ` · ${p("games.brave-and-bold.first")}` : ""] })]
								}),
								/* @__PURE__ */ _("span", {
									className: "bb-seat-health",
									children: [
										"♥ ",
										/* @__PURE__ */ g(pt, {
											value: t.hp,
											identity: t.rid
										}),
										t.injured && /* @__PURE__ */ g("small", { children: p(t.defeated ? "games.brave-and-bold.defeated" : "games.brave-and-bold.injured") })
									]
								}),
								/* @__PURE__ */ _("span", {
									className: "bb-seat-values",
									children: [/* @__PURE__ */ _("span", { children: [
										/* @__PURE__ */ g(lt, { size: 17 }),
										" ",
										/* @__PURE__ */ g(pt, {
											value: t.resources,
											identity: t.rid
										})
									] }), /* @__PURE__ */ _("span", { children: [
										p("games.brave-and-bold.damagePool"),
										" ",
										/* @__PURE__ */ g(pt, {
											value: t.pool.normal + t.pool.indefensible,
											identity: t.rid
										})
									] })]
								}),
								s.length > 0 && /* @__PURE__ */ g("span", {
									className: "bb-target-tag",
									children: p(Z(s[0].label.split(".").at(-1)))
								}),
								s.length > 0 && /* @__PURE__ */ g(l, {
									radius: 5,
									flash: !1
								})
							]
						})
					}, t.rid);
				})
			}),
			/* @__PURE__ */ g(ht, {
				pub: e,
				nameOf: D
			})
		] }),
		actions: /* @__PURE__ */ _("div", {
			className: "bb-actions",
			children: [
				/* @__PURE__ */ g("span", {
					className: "bb-turn-label",
					role: "status",
					children: re ? ae : ie
				}),
				re && S !== v && /* @__PURE__ */ g("button", {
					onClick: () => te(v),
					children: p("games.brave-and-bold.viewOwnBoard")
				}),
				oe.map((e) => /* @__PURE__ */ g("button", {
					onClick: () => O(e),
					className: e.label.endsWith(".confirmAllocation") ? "bb-primary" : "",
					children: p(Z(e.label.split(".").at(-1)))
				}, e.id)),
				ce.length > 0 && /* @__PURE__ */ _("button", {
					className: "bb-primary",
					onClick: () => k(ce, p("games.brave-and-bold.actions")),
					children: [
						p("games.brave-and-bold.actions"),
						" ",
						/* @__PURE__ */ g("b", { children: ce.length })
					]
				}),
				re && j && /* @__PURE__ */ g("button", {
					className: "bb-primary",
					onClick: () => O(j),
					children: p("games.brave-and-bold.draw")
				}),
				/* @__PURE__ */ g("button", {
					onClick: () => b({ kind: "logs" }),
					"aria-label": p("games.brave-and-bold.log"),
					children: "≡"
				})
			]
		}),
		children: [/* @__PURE__ */ _("div", {
			className: "bb-scroll",
			children: [/* @__PURE__ */ _("div", {
				className: "bb-challenge",
				children: [
					/* @__PURE__ */ g("b", { children: p("games.brave-and-bold.challenge") }),
					/* @__PURE__ */ g("span", { children: p(ue ? ue.textKey : "games.brave-and-bold.selectPrompt") }),
					/* @__PURE__ */ g("small", { children: p("games.brave-and-bold.remaining", { n: e.remainingChallenges }) })
				]
			}), e.phase === "select" ? /* @__PURE__ */ g("div", {
				className: "bb-character-gallery",
				children: M.filter((t) => e.expansion || !t.expansion).map((t) => {
					let n = T.find((e) => e.kind === "character" && e.character === t.id), r = e.seats.some((e) => e.character === t.id);
					return /* @__PURE__ */ _("button", {
						className: `bb-character-card${r ? " is-occupied" : ""}`,
						onClick: () => n ? O(n) : b({
							kind: "character",
							character: t.id
						}),
						style: { "--bb-character": ct[t.id] },
						children: [
							/* @__PURE__ */ g("img", {
								src: st(t.id),
								alt: ""
							}),
							/* @__PURE__ */ g("strong", { children: p(t.nameKey) }),
							/* @__PURE__ */ g("small", { children: p(t.faction === "hero" ? "games.brave-and-bold.heroTeam" : "games.brave-and-bold.villainTeam") }),
							n && /* @__PURE__ */ g(l, {
								radius: 8,
								flash: !1
							})
						]
					}, t.id);
				})
			}) : w && /* @__PURE__ */ _("div", {
				className: "bb-table-layout",
				children: [/* @__PURE__ */ _("section", {
					className: "bb-character-board",
					style: { "--bb-character": ct[w.id] },
					children: [/* @__PURE__ */ _("div", {
						className: "bb-portrait",
						children: [
							/* @__PURE__ */ g("img", {
								src: st(w.id),
								alt: ""
							}),
							/* @__PURE__ */ _("div", {
								className: "bb-character-heading",
								children: [/* @__PURE__ */ g("h1", { children: p(w.nameKey) }), /* @__PURE__ */ g("button", {
									onClick: () => b({
										kind: "character",
										character: w.id
									}),
									children: p("games.brave-and-bold.details")
								})]
							}),
							/* @__PURE__ */ g($, {
								name: `bag:${C.rid}`,
								className: "bb-bag-anchor",
								children: /* @__PURE__ */ _("button", {
									className: `bb-bag${j && S === v ? " is-legal" : ""}`,
									onClick: () => j && S === v ? O(j) : b({
										kind: "tokens",
										seat: S,
										zone: "bagContents"
									}),
									children: [
										/* @__PURE__ */ g("span", { children: p("games.brave-and-bold.bag") }),
										/* @__PURE__ */ g("b", { children: C.bagCount }),
										j && S === v && /* @__PURE__ */ g(l, {
											radius: 28,
											flash: !1
										})
									]
								})
							}),
							/* @__PURE__ */ _("div", {
								className: "bb-crisis-meter",
								"aria-label": p("games.brave-and-bold.crisis"),
								children: [[
									0,
									1,
									2
								].map((e) => /* @__PURE__ */ g("span", {
									className: C.draw.reduce((e, t) => e + E(t), 0) > e ? "is-filled" : "",
									children: /* @__PURE__ */ g(Q, {
										symbol: "X",
										size: 27
									})
								}, e)), C.crisis && /* @__PURE__ */ g("strong", { children: p("games.brave-and-bold.crisis") })]
							})
						]
					}), /* @__PURE__ */ _("div", {
						className: "bb-board-body",
						children: [
							/* @__PURE__ */ _("div", {
								className: "bb-stats",
								children: [
									/* @__PURE__ */ _("span", { children: ["♥ ", /* @__PURE__ */ g("b", { children: /* @__PURE__ */ g(pt, {
										value: C.hp,
										identity: C.rid
									}) })] }),
									/* @__PURE__ */ _("span", { children: [
										/* @__PURE__ */ g(lt, { size: 25 }),
										" ",
										/* @__PURE__ */ g("b", { children: /* @__PURE__ */ g(pt, {
											value: C.resources,
											identity: C.rid
										}) })
									] }),
									/* @__PURE__ */ _("span", { children: [
										p("games.brave-and-bold.damagePool"),
										" ",
										/* @__PURE__ */ _("b", { children: [
											/* @__PURE__ */ g(pt, {
												value: C.pool.normal,
												identity: C.rid
											}),
											" + ◆",
											/* @__PURE__ */ g(pt, {
												value: C.pool.indefensible,
												identity: C.rid
											})
										] })
									] })
								]
							}),
							/* @__PURE__ */ _($, {
								name: `draw:${C.rid}`,
								className: "bb-draw-area",
								children: [
									/* @__PURE__ */ _("h2", { children: [
										p("games.brave-and-bold.drawArea"),
										" ",
										/* @__PURE__ */ g("small", { children: C.nonCrisisDrawn })
									] }),
									/* @__PURE__ */ g("div", {
										className: "bb-bonus-track",
										"aria-label": p("games.brave-and-bold.bonus"),
										children: [
											4,
											7,
											10,
											11,
											13,
											14
										].map((e, t) => {
											let n = w.bonus[t], r = n[0];
											return /* @__PURE__ */ _("span", {
												className: C.nonCrisisDrawn >= e ? "is-earned" : "",
												title: p("games.brave-and-bold.bonusThreshold", { n: e }),
												children: [/* @__PURE__ */ g("small", { children: p("games.brave-and-bold.drawCount", { n: e }) }), /* @__PURE__ */ g("b", { children: /^[CRAFEMIWB]/.test(n) ? /* @__PURE__ */ _(h, { children: [
													"+",
													/* @__PURE__ */ g(Q, {
														symbol: r,
														character: w.id,
														size: 20
													}),
													n.slice(1)
												] }) : n.startsWith("heal") ? `♥ +${n.slice(4)}` : n.startsWith("damage") ? `✹ +${n.slice(6)}` : p("games.brave-and-bold.gadgets") })]
											}, e);
										})
									}),
									/* @__PURE__ */ _("div", {
										className: "bb-token-row",
										children: [
											C.draw.map((e) => {
												let t = V(e), n = C.plans.some((t) => t.slots.flat().some((t) => t.startsWith(`${e.id}:`)));
												return /* @__PURE__ */ g(ut, {
													token: e,
													character: w.id,
													selected: n,
													legal: t.length > 0,
													onClick: () => t.length ? k(t, p(Z("token_" + e.symbol))) : b({
														kind: "token",
														token: e,
														character: w.id
													})
												}, e.id);
											}),
											C.reverse && /* @__PURE__ */ g(ut, {
												token: C.reverse,
												character: w.id,
												onClick: () => k(T.filter((e) => e.label.endsWith(".reverse")), p("games.brave-and-bold.reverse"))
											}),
											C.bonuses.map((e) => /* @__PURE__ */ g("span", {
												className: "bb-bonus-token",
												children: /* @__PURE__ */ g(Q, {
													symbol: e.symbol,
													character: w.id,
													size: 30
												})
											}, e.id)),
											C.draw.length === 0 && /* @__PURE__ */ g("small", { children: p("games.brave-and-bold.noTokens") })
										]
									})
								]
							}),
							/* @__PURE__ */ g("div", {
								className: "bb-abilities",
								children: w.abilities.map((e, t) => {
									let n = T.some((e) => e.kind === "ability" && e.character === w.id && e.ability === t), r = C.plans.find((e) => e.ability === t);
									return /* @__PURE__ */ _($, {
										name: `ability:${C.rid}:${t}`,
										className: `bb-ability${e.finisher ? " bb-finisher" : ""}${r ? " is-assigned" : ""}${C.activated.includes(t) ? " is-activated" : ""}`,
										children: [/* @__PURE__ */ _("button", {
											onClick: () => b({
												kind: "ability",
												character: w.id,
												ability: t
											}),
											children: [
												/* @__PURE__ */ _("span", {
													className: "bb-ability-name",
													children: [p(e.nameKey), C.activated.includes(t) && /* @__PURE__ */ g("b", { children: "✓" })]
												}),
												/* @__PURE__ */ g(dt, {
													ability: e,
													character: w.id
												}),
												/* @__PURE__ */ g("span", {
													className: "bb-actual-payment",
													children: r?.slots.flat().map((e) => {
														let t = [...C.draw.flatMap((e) => [{
															...e,
															id: `${e.id}:0`
														}, {
															...e,
															id: `${e.id}:1`
														}]), ...C.bonuses].find((t) => t.id === e);
														return t && /* @__PURE__ */ g($, {
															name: `allocated:${e}`,
															children: /* @__PURE__ */ g(Q, {
																symbol: t.symbol,
																character: w.id,
																size: 23
															})
														}, e);
													})
												}),
												/* @__PURE__ */ g(ft, {
													ability: e,
													compact: !0
												})
											]
										}), n && /* @__PURE__ */ g(l, {
											radius: 6,
											flash: !1
										})]
									}, t);
								})
							}),
							/* @__PURE__ */ g($, {
								name: `marks:${C.rid}`,
								className: "bb-specials",
								children: Object.keys(w.specials).map((e) => /* @__PURE__ */ _("button", {
									onClick: () => b({
										kind: "special",
										key: e
									}),
									className: `bb-mark${C.marks[e] ?? 0 ? "" : " is-empty"}`,
									children: [
										/* @__PURE__ */ g("img", {
											src: `games/brave-and-bold/mark-${e}.webp`,
											alt: ""
										}),
										/* @__PURE__ */ _("span", { children: [p(N[e]), /* @__PURE__ */ _("b", { children: [" ×", /* @__PURE__ */ g(pt, {
											value: C.marks[e] ?? 0,
											identity: C.rid
										})] })] }),
										T.some((t) => t.nameKey === N[e]) && /* @__PURE__ */ g(l, {
											radius: 6,
											flash: !1
										})
									]
								}, e))
							}),
							C.stored.length > 0 && /* @__PURE__ */ g($, {
								name: `stored:${C.rid}`,
								className: "bb-stored",
								children: C.stored.map((e) => /* @__PURE__ */ g(ut, {
									token: e.token,
									character: w.id,
									onClick: () => b({
										kind: "character",
										character: w.id
									})
								}, e.token.id))
							}),
							/* @__PURE__ */ _("div", {
								className: "bb-bottom-tray",
								children: [
									/* @__PURE__ */ g($, {
										name: `discard:${C.rid}`,
										children: /* @__PURE__ */ _("button", {
											onClick: () => b({
												kind: "tokens",
												seat: S,
												zone: "discard"
											}),
											children: [
												p("games.brave-and-bold.discard"),
												" ",
												/* @__PURE__ */ g("b", { children: C.discard.length })
											]
										})
									}),
									C.upgrades.map((e) => /* @__PURE__ */ g("button", {
										onClick: () => b({
											kind: "upgrade",
											key: e
										}),
										children: p(Y[e])
									}, e)),
									S === v && t && w.id === "batman" && /* @__PURE__ */ g($, {
										name: `hand:${r}`,
										children: /* @__PURE__ */ _("button", {
											onClick: () => b({ kind: "hand" }),
											children: [
												p("games.brave-and-bold.gadgets"),
												" ",
												t.hand.length
											]
										})
									})
								]
							})
						]
					})]
				}), /* @__PURE__ */ _("aside", {
					className: "bb-armoury",
					children: [
						/* @__PURE__ */ _($, {
							name: "market",
							children: [/* @__PURE__ */ g("h2", { children: p("games.brave-and-bold.armoury") }), /* @__PURE__ */ g("div", {
								className: "bb-market-grid",
								children: e.market.map((e) => /* @__PURE__ */ _("div", {
									className: "bb-market-item",
									children: [/* @__PURE__ */ g(ut, {
										token: e,
										character: w.id,
										size: 55,
										legal: V(e).length > 0,
										onClick: () => V(e).length ? k(V(e), p(Z("token_" + e.symbol))) : b({
											kind: "token",
											token: e,
											character: w.id
										})
									}), /* @__PURE__ */ _("small", {
										className: "bb-price",
										children: [
											/* @__PURE__ */ g("span", { children: p("games.brave-and-bold.purchaseCost") }),
											e.kind === "critical" ? /* @__PURE__ */ g(Q, {
												symbol: e.symbol,
												character: w.id,
												size: 18
											}) : /* @__PURE__ */ g(lt, { size: 18 }),
											/* @__PURE__ */ g("b", { children: e.kind === "critical" ? "10" : e.kind === "power" ? "4" : "3" })
										]
									})]
								}, e.id))
							})]
						}),
						/* @__PURE__ */ _($, {
							name: `supply:${C.rid}`,
							children: [/* @__PURE__ */ g("h2", { children: p("games.brave-and-bold.supply") }), /* @__PURE__ */ g("div", {
								className: "bb-market-grid",
								children: H(C.supply.filter((e) => !["X", "K"].includes(e.symbol))).map((e) => /* @__PURE__ */ _("div", {
									className: "bb-market-item",
									children: [/* @__PURE__ */ g(ut, {
										token: e,
										character: w.id,
										size: 48,
										legal: V(e).length > 0,
										onClick: () => V(e).length ? k(V(e), p(Z("token_" + e.symbol))) : b({
											kind: "tokens",
											seat: S,
											zone: "supply"
										})
									}), /* @__PURE__ */ _("small", {
										className: "bb-stock",
										children: [/* @__PURE__ */ g("span", { children: p("games.brave-and-bold.stockCount") }), /* @__PURE__ */ _("b", { children: ["×", C.supply.filter((t) => t.symbol === e.symbol && t.kind === e.kind).length] })]
									})]
								}, `${e.symbol}:${e.kind}`))
							})]
						}),
						/* @__PURE__ */ g("div", {
							className: "bb-context-objects",
							children: le.filter((e) => e.kind === "upgrade").map((e) => /* @__PURE__ */ _("button", {
								onClick: () => O(e),
								children: [
									A(e),
									/* @__PURE__ */ g("small", {
										className: "block",
										children: p(Z("help_upgrade_" + Object.keys(Y).find((t) => Y[t] === e.nameKey)))
									}),
									/* @__PURE__ */ g(l, {
										radius: 5,
										flash: !1
									})
								]
							}, e.id))
						}),
						S === v && t?.peek.map((e) => /* @__PURE__ */ _("div", {
							className: "bb-peek",
							children: [p("games.brave-and-bold.peekedChallenge"), /* @__PURE__ */ g("p", { children: p(de.find((t) => t.id === e).textKey) })]
						}, e))
					]
				})]
			})]
		}), /* @__PURE__ */ g(a, {
			open: y !== null,
			onClose: () => b(null),
			title: _e,
			label: _e,
			tall: !0,
			children: /* @__PURE__ */ _("div", {
				className: "bb-detail",
				children: [
					y?.kind === "character" && /* @__PURE__ */ _(h, { children: [
						/* @__PURE__ */ g("img", {
							className: "bb-detail-portrait",
							src: st(y.character),
							alt: ""
						}),
						/* @__PURE__ */ g("p", {
							className: "whitespace-pre-line",
							children: p(Z("help_" + y.character))
						}),
						T.filter((e) => e.kind === "ability" && e.character === y.character).map((e) => /* @__PURE__ */ g("button", {
							onClick: () => b({
								kind: "ability",
								character: y.character,
								ability: e.ability
							}),
							children: /* @__PURE__ */ _("span", { children: [A(e), e.kind === "upgrade" && /* @__PURE__ */ g("small", {
								className: "block",
								children: p(Z("help_upgrade_" + Object.keys(Y).find((t) => Y[t] === e.nameKey)))
							})] })
						}, e.id))
					] }),
					y?.kind === "token" && /* @__PURE__ */ _(h, { children: [
						/* @__PURE__ */ g(Q, {
							symbol: y.token.symbol,
							kind: y.token.kind,
							character: y.character,
							size: 70
						}),
						/* @__PURE__ */ g("p", { children: p(Z("help_token_" + y.token.symbol)) }),
						/* @__PURE__ */ g("p", { children: p(Z("help_kind_" + y.token.kind)) })
					] }),
					y?.kind === "upgrade" && /* @__PURE__ */ g("p", { children: p(Z("help_upgrade_" + y.key)) }),
					y?.kind === "special" && /* @__PURE__ */ g("p", { children: p(Z("help_" + y.key)) }),
					y?.kind === "ability" && P && /* @__PURE__ */ _(h, { children: [
						/* @__PURE__ */ g(dt, {
							ability: P,
							character: y.character
						}),
						/* @__PURE__ */ g(ft, { ability: P }),
						P.dynamic && /* @__PURE__ */ g("p", { children: p(Z("dynamic_" + P.dynamic)) }),
						pe && t && /* @__PURE__ */ _(h, { children: [
							/* @__PURE__ */ g("div", {
								className: "bb-payment-slots",
								children: P.cost.split(" ").map((e, n) => /* @__PURE__ */ _("button", {
									className: z.slot === n ? "is-selected" : "",
									onClick: () => R({
										...z,
										slot: n
									}),
									children: [
										/* @__PURE__ */ g("small", { children: p("games.brave-and-bold.paymentSlot", { n: n + 1 }) }),
										/* @__PURE__ */ g(dt, {
											ability: {
												...P,
												cost: e
											},
											character: y.character
										}),
										/* @__PURE__ */ g("span", { children: z.payment.slots[n]?.map((e) => {
											let n = t.units.find((t) => t.id === e);
											return n && /* @__PURE__ */ g(Q, {
												symbol: n.symbol,
												character: I.character,
												size: 29
											}, e);
										}) })
									]
								}, n))
							}),
							/* @__PURE__ */ g("div", {
								className: "bb-token-row",
								children: t.units.map((e) => {
									let t = z.payment.slots.flat().includes(e.id) || z.payment.extra.includes(e.id);
									return /* @__PURE__ */ _("button", {
										className: `bb-unit${t ? " is-selected" : ""}`,
										onClick: () => {
											let n = z.payment.slots.map((t) => t.filter((t) => t !== e.id)), r = z.payment.extra.filter((t) => t !== e.id);
											t || (n[z.slot] = [...n[z.slot], e.id]), ge({
												...z.payment,
												slots: n,
												extra: r
											});
										},
										children: [
											/* @__PURE__ */ g(Q, {
												symbol: e.symbol,
												character: I.character,
												size: 38
											}),
											e.part > 0 && /* @__PURE__ */ g("small", { children: "½" }),
											t && /* @__PURE__ */ g("b", { children: "✓" })
										]
									}, e.id);
								})
							}),
							P.extraMass && /* @__PURE__ */ _("div", {
								className: "bb-extra-mass",
								children: [p("games.brave-and-bold.extraMass"), t.units.filter((e) => e.symbol === "M" && !z.payment.slots.flat().includes(e.id)).map((e) => /* @__PURE__ */ g("button", {
									className: z.payment.extra.includes(e.id) ? "is-selected" : "",
									onClick: () => ge({
										...z.payment,
										extra: z.payment.extra.includes(e.id) ? z.payment.extra.filter((t) => t !== e.id) : [...z.payment.extra, e.id]
									}),
									children: /* @__PURE__ */ g(Q, {
										symbol: "M",
										size: 32
									})
								}, e.id))]
							}),
							/* @__PURE__ */ _("div", {
								className: "bb-targets",
								children: [/* @__PURE__ */ g("b", { children: p("games.brave-and-bold.chooseOpponent") }), e.seats.map((e, t) => e.team !== I.team && !e.defeated && /* @__PURE__ */ _("button", {
									className: z.target === t ? "is-selected" : "",
									onClick: () => R({
										...z,
										target: t
									}),
									children: [D(t), /* @__PURE__ */ g(l, {
										radius: 4,
										flash: !1
									})]
								}, e.rid))]
							}),
							/* @__PURE__ */ _("div", {
								className: "bb-detail-actions",
								children: [/* @__PURE__ */ g("button", {
									onClick: () => ge(he),
									children: p("games.brave-and-bold.autoFill")
								}), /* @__PURE__ */ g("button", {
									className: "bb-primary",
									disabled: !B,
									onClick: () => {
										y.kind === "ability" && B && (f({
											type: "allocate",
											character: y.character,
											target: z.target,
											payment: z.payment
										}), b(null));
									},
									children: p("games.brave-and-bold.confirm")
								})]
							})
						] }),
						F.filter((e) => !pe || e.label.endsWith(".repeatAbility")).map((e) => /* @__PURE__ */ g("button", {
							className: "bb-primary",
							onClick: () => O(e),
							children: /* @__PURE__ */ _("span", { children: [A(e), e.kind === "upgrade" && /* @__PURE__ */ g("small", {
								className: "block",
								children: p(Z("help_upgrade_" + Object.keys(Y).find((t) => Y[t] === e.nameKey)))
							})] })
						}, e.id))
					] }),
					(y?.kind === "hand" ? T.filter((e) => e.kind === "gadget") : fe).map((e) => /* @__PURE__ */ _("button", {
						className: "bb-choice",
						onClick: () => O(e),
						children: [e.token && /* @__PURE__ */ g(Q, {
							symbol: e.token.symbol,
							kind: e.token.kind,
							character: I.character
						}), /* @__PURE__ */ _("span", { children: [A(e), e.kind === "upgrade" && /* @__PURE__ */ g("small", {
							className: "block",
							children: p(Z("help_upgrade_" + Object.keys(Y).find((t) => Y[t] === e.nameKey)))
						})] })]
					}, e.id)),
					y?.kind === "tokens" && /* @__PURE__ */ g("div", {
						className: "bb-inventory",
						children: H(e.seats[y.seat][y.zone]).map((t) => /* @__PURE__ */ _("div", { children: [
							/* @__PURE__ */ g(Q, {
								symbol: t.symbol,
								kind: t.kind,
								character: e.seats[y.seat].character,
								size: 48
							}),
							/* @__PURE__ */ g("span", { children: p(Z("token_" + t.symbol)) }),
							/* @__PURE__ */ _("b", { children: ["×", e.seats[y.seat][y.zone].filter((e) => e.symbol === t.symbol && e.kind === t.kind).length] })
						] }, `${t.symbol}:${t.kind}`))
					}),
					y?.kind === "logs" && [...e.logs].reverse().map((t, n) => /* @__PURE__ */ _("p", {
						className: "bb-log",
						children: [
							t.actor !== void 0 && /* @__PURE__ */ _("b", { children: [D(t.actor), " "] }),
							t.key.endsWith(".logActivate") ? p("games.brave-and-bold.logActivate", { ability: p(Z(String(t.params.ability).split(".").at(-1))) }) : p(Z(t.key.split(".").at(-1)), t.params),
							" ",
							t.token && /* @__PURE__ */ g(Q, {
								symbol: t.token.symbol,
								kind: t.token.kind,
								character: e.seats[t.actor ?? 0].character,
								size: 26
							})
						]
					}, n)),
					y?.kind === "choices" && fe.length === 0 && /* @__PURE__ */ g("p", { children: p("games.brave-and-bold.errAction") }),
					S === v && t && y?.kind === "hand" && /* @__PURE__ */ g("div", {
						className: "bb-hand-list",
						children: t.hand.map((e, t) => /* @__PURE__ */ _("p", { children: [
							/* @__PURE__ */ g("b", { children: p(X[e]) }),
							" ",
							p(Z("help_gadget_" + e))
						] }, t))
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/games/brave-and-bold/bot.ts
var vt = (e, t) => {
	let n = e.public, r = e.private;
	if (!r?.choices.length) return null;
	let i = n.seats.find((e) => e.rid === t.rid);
	if (!i) return null;
	let a = r.choices, o = (e) => {
		if (e.label === "games.brave-and-bold.draw") {
			let e = i.draw.reduce((e, t) => e + E(t), 0);
			return i.bagContents.filter((t) => E(t) + e >= 3).length / Math.max(1, i.bagCount) < (t.difficulty === "weak" ? .2 : .29) || i.nonCrisisDrawn < 4 ? 20 : -10;
		}
		if (e.label === "games.brave-and-bold.stop") return 1;
		if (e.label === "games.brave-and-bold.continue" || e.label === "games.brave-and-bold.confirmAllocation") return 0;
		if (e.kind === "character") return e.character === "superman" ? 10 : e.character === "darkseid" ? 9 : 5;
		if (e.kind === "upgrade") return e.nameKey === "games.brave-and-bold.upgradeAegis" ? 12 : e.nameKey === "games.brave-and-bold.upgradeTraining" ? 10 : 5;
		if (e.kind === "ability") {
			let t = M.find((t) => t.id === (e.character ?? i.character))?.abilities[e.ability ?? 0];
			return t ? 3 + (t.damage + (t.heal ?? 0) * (i.hp < 25 ? 1.4 : .55) + (t.marks?.length ?? 0) * 2 + (t.resource ?? 0) * .8 + (t.dynamic === "resourcePlusGadgets" ? i.resources + 4 : 0)) / Math.max(1, e.payment?.slots.flat().length ?? t.cost.split(" ").length) + (t.finisher ? 20 : 0) : 1;
		}
		if (e.label === "games.brave-and-bold.dealDamage" || e.label === "games.brave-and-bold.recover") return 10 + (e.amount ?? 0) - (e.target !== void 0 && n.seats[e.target].hp === 0 ? 100 : 0);
		if (e.label === "games.brave-and-bold.clearAllocation") return -100;
		if (e.label === "games.brave-and-bold.buyToken" || e.label === "games.brave-and-bold.buyDiscount") {
			let t = e.token;
			return (t.symbol === "E" ? 6 : t.symbol === "F" ? 2 : t.symbol === "C" ? 5 : t.symbol === "R" ? i.bagContents.filter((e) => e.symbol === "R").length < 5 ? 5 : 2 : 4) + (t.kind === "double" ? 4 : t.kind === "power" ? 3 : 0);
		}
		return e.label === "games.brave-and-bold.reverse" || e.label === "games.brave-and-bold.huntCrisis" ? e.token && E(e.token) ? 18 : -5 : e.label === "games.brave-and-bold.preventDamage" ? n.hit && n.hit.normal > 0 ? 15 : -2 : e.label === "games.brave-and-bold.returnCrisis" ? 16 : e.label === "games.brave-and-bold.replaceToken" ? -1 : e.kind === "special" ? e.nameKey === "games.brave-and-bold.special_upperHand" || e.nameKey === "games.brave-and-bold.special_fate" ? -2 : e.nameKey === "games.brave-and-bold.special_hitFirst" ? n.prompt === "activate" && i.plans.length ? 6 : -1 : e.nameKey === "games.brave-and-bold.special_ahead" ? -1 : 5 : 2;
	}, s = a[0], c = o(s);
	for (let e of a.slice(1)) {
		let t = o(e);
		t > c && (s = e, c = t);
	}
	return { action: {
		type: "choose",
		id: s.id
	} };
};
//#endregion
//#region src/games/brave-and-bold/fx.tsx
function yt({ from: e, to: t, token: i, character: a }) {
	let o = r(null);
	return n(() => {
		let n = t.x - e.x, r = t.y - e.y, i = o.current?.animate([
			{
				transform: "translate(0,0)",
				opacity: 0
			},
			{
				transform: `translate(${n}px,${r}px)`,
				opacity: 1,
				offset: .32
			},
			{
				transform: `translate(${n}px,${r}px)`,
				opacity: 1,
				offset: .68
			},
			{
				transform: "translate(0,0)",
				opacity: 0
			}
		], {
			duration: 760,
			easing: "ease-in-out",
			fill: "both"
		});
		return () => i?.cancel();
	}, [e, t]), /* @__PURE__ */ g("div", {
		ref: o,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y
		},
		children: /* @__PURE__ */ g(Q, {
			symbol: i.symbol,
			kind: i.kind,
			character: a,
			size: 40
		})
	});
}
function bt({ card: e }) {
	let t = s();
	return /* @__PURE__ */ g("div", {
		style: {
			width: 80,
			minHeight: 65,
			padding: 7,
			background: "#fff6df",
			color: "#13233c",
			border: "3px solid #13233c",
			borderRadius: 5,
			fontSize: 12,
			fontWeight: 850
		},
		children: t(e ? X[e] : "games.brave-and-bold.gadgets")
	});
}
function xt({ marker: e, gain: t }) {
	let n = s();
	return /* @__PURE__ */ _("span", {
		style: {
			display: "inline-flex",
			alignItems: "center",
			gap: 5,
			maxWidth: 240,
			whiteSpace: "normal",
			background: "#fff6df",
			color: "#13233c",
			border: "2px solid #13233c",
			padding: 5,
			fontSize: 13
		},
		children: [/* @__PURE__ */ g("img", {
			src: `games/brave-and-bold/mark-${e}.webp`,
			alt: "",
			style: {
				width: 32,
				height: 32,
				objectFit: "contain"
			}
		}), n(t ? "games.brave-and-bold.markGained" : "games.brave-and-bold.markUsed", { name: n(N[e]) })]
	});
}
var St = {
	recovery(e, t) {
		let n = e.data, r = t.anchor(`bag:${e.rid}`) ?? t.anchor(`seat:${e.rid}`), i = t.anchor(`draw:${e.rid}`) ?? t.anchor(`seat:${e.rid}`);
		if (!r || !i) return null;
		let a = {
			x: r.x + r.w / 2 - 20,
			y: r.y + r.h / 2 - 20,
			w: 40,
			h: 40
		}, o = {
			x: i.x + i.w / 2 - n.n * 22 + n.i * 44,
			y: i.y + i.h / 2 - 20,
			w: 40,
			h: 40
		};
		return {
			ms: 760,
			node: /* @__PURE__ */ g(yt, {
				from: a,
				to: o,
				token: n.token,
				character: n.character
			})
		};
	},
	gadget(e, t) {
		let n = e.data, r = t.anchor(`hand:${e.rid}`) ?? t.anchor(`seat:${e.rid}`), i = t.anchor(`supply:${e.rid}`) ?? t.anchor(`seat:${e.rid}`);
		if (!r || !i) return null;
		let a = (e) => ({
			x: e.x + e.w / 2 - 40,
			y: e.y + e.h / 2 - 32,
			w: 80,
			h: 65
		});
		return {
			ms: 380,
			node: /* @__PURE__ */ g(ee, {
				from: a(n.gain ? i : r),
				to: a(n.gain ? r : i),
				ms: 380,
				children: /* @__PURE__ */ g(bt, { card: n.gain ? void 0 : n.card })
			})
		};
	},
	move(e, t) {
		let n = e.data, r = t.anchor(`seat:${e.rid}`), i = t.anchor(n.to), a = t.anchor(n.from) ?? r, o = i ?? r;
		if (!a || !o) return null;
		let s = (e) => ({
			x: e.x + (e.w - 40) / 2,
			y: e.y + (e.h - 40) / 2,
			w: 40,
			h: 40
		}), c = !!i && (n.to.startsWith("token:") || n.to.startsWith("allocated:")), l = s(a), u = c ? o : s(o);
		return {
			ms: 380,
			hide: c && !t.queued ? [n.to] : [],
			node: /* @__PURE__ */ g(ee, {
				from: l,
				to: u,
				ms: 380,
				children: /* @__PURE__ */ g(Q, {
					symbol: n.token.symbol,
					kind: n.token.kind,
					character: n.character,
					size: 40
				})
			})
		};
	},
	ability(e, t) {
		let n = e.data, r = t.anchor(`ability:${e.rid}:${n.ability}`) ?? t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: 700,
			node: /* @__PURE__ */ g(te, {
				at: r,
				ms: 700
			})
		} : null;
	},
	health(e, t) {
		let n = e.data, r = t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: 650,
			node: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(te, {
				at: r,
				ms: 650
			}), /* @__PURE__ */ g(v, {
				at: r,
				ms: 650,
				children: /* @__PURE__ */ _("strong", {
					style: {
						color: n.n < 0 ? "#b72c2c" : "#286940",
						fontSize: 25,
						background: "#fff6df",
						padding: "2px 7px",
						border: "2px solid #13233c"
					},
					children: [n.n > 0 ? "+" : "", n.n]
				})
			})] })
		} : null;
	},
	marker(e, t) {
		let n = e.data, r = t.anchor(`marks:${e.rid}`) ?? t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: 380,
			node: /* @__PURE__ */ g(v, {
				at: r,
				ms: 380,
				children: /* @__PURE__ */ g(xt, {
					marker: n.key,
					gain: n.gain
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/brave-and-bold/game-over.tsx
function Ct(e) {
	let t = e.public, n = s(), r = o((e) => e.locale), [a, c] = i(!0);
	return /* @__PURE__ */ _("div", {
		className: "relative h-full min-h-0",
		children: [
			/* @__PURE__ */ g("div", {
				className: "h-full min-h-0",
				inert: a,
				children: /* @__PURE__ */ g(gt, {
					public: t,
					private: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => {}
				})
			}),
			/* @__PURE__ */ _("div", {
				className: "bb-over",
				style: { display: a ? void 0 : "none" },
				role: "dialog",
				"aria-modal": "true",
				"aria-label": n("games.brave-and-bold.done"),
				children: [
					/* @__PURE__ */ _("header", {
						className: "bb-over-title",
						children: [/* @__PURE__ */ g("h1", { children: n("games.brave-and-bold.done") }), /* @__PURE__ */ g("button", {
							onClick: () => c(!1),
							"aria-label": n("games.brave-and-bold.reviewTable"),
							children: "×"
						})]
					}),
					/* @__PURE__ */ g("div", {
						className: "bb-over-list",
						children: e.result.ranking.map((i) => {
							let a = t.seats.find((e) => e.rid === i), o = M.find((e) => e.id === a.character), s = e.members.find((e) => e.rid === i), c = e.result.winner.includes(i);
							return /* @__PURE__ */ _("article", {
								className: `bb-over-person${c ? " is-winner" : ""}`,
								children: [
									/* @__PURE__ */ g("img", {
										src: st(o.id),
										alt: ""
									}),
									/* @__PURE__ */ g("h2", { children: s ? d(s, r) : n(o.nameKey) }),
									/* @__PURE__ */ _("p", { children: [
										n(o.nameKey),
										" · ",
										n(c ? "games.brave-and-bold.victory" : a.defeated ? "games.brave-and-bold.defeated" : a.injured ? "games.brave-and-bold.injured" : "games.brave-and-bold.done")
									] }),
									/* @__PURE__ */ _("strong", { children: [
										"♥ ",
										a.hp,
										" ",
										/* @__PURE__ */ g("small", { children: n("games.brave-and-bold.finalHealth") })
									] }),
									e.result.autopilot?.[i] !== void 0 && /* @__PURE__ */ g("p", { children: n("session.autopilot.share", { n: Math.round(e.result.autopilot[i] * 100) }) })
								]
							}, i);
						})
					}),
					e.hintCount !== void 0 && /* @__PURE__ */ g("p", { children: n("session.hint.usedCount", { n: e.hintCount }) }),
					/* @__PURE__ */ _("footer", {
						className: "bb-over-controls",
						children: [
							/* @__PURE__ */ g("button", {
								onClick: () => c(!1),
								children: n("games.brave-and-bold.reviewTable")
							}),
							e.onPlayAgain && /* @__PURE__ */ g("button", {
								className: "bb-primary",
								onClick: e.onPlayAgain,
								children: n("games.brave-and-bold.playAgain")
							}),
							e.onBackToLobby && /* @__PURE__ */ g("button", {
								onClick: e.onBackToLobby,
								children: n("games.brave-and-bold.backLobby")
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ g("p", { children: n("session.result.waitHost") })
						]
					})
				]
			}),
			!a && /* @__PURE__ */ g("button", {
				className: "bb-review-toggle",
				onClick: () => c(!0),
				children: n("games.brave-and-bold.done")
			})
		]
	});
}
//#endregion
//#region src/games/brave-and-bold/options.tsx
function wt({ value: e, onChange: t }) {
	let n = s(), r = k.parse(e);
	return /* @__PURE__ */ _("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ g(b, {
			title: n("games.brave-and-bold.optMode"),
			children: [
				"duel",
				"teams",
				"league"
			].map((e) => /* @__PURE__ */ g(y, {
				name: "brave-bold-mode",
				value: e,
				checked: r.mode === e,
				label: n(`games.brave-and-bold.${e}`),
				accent: ue.accent,
				onChange: () => t({
					...r,
					mode: e
				})
			}, e))
		}), /* @__PURE__ */ g(ne, {
			label: n("games.brave-and-bold.optExpansion"),
			checked: r.expansion,
			accent: ue.accent,
			onChange: () => t({
				...r,
				expansion: !r.expansion
			})
		})]
	});
}
//#endregion
//#region src/games/brave-and-bold/guide.tsx
function Tt() {
	let e = s();
	return /* @__PURE__ */ g("article", {
		className: "bb-guide",
		style: {
			height: "auto",
			overflow: "visible"
		},
		children: /* @__PURE__ */ g("div", {
			className: "bb-guide-legend",
			children: [
				"C",
				"R",
				"A",
				"F",
				"E",
				"X",
				"U",
				"V"
			].map((t) => /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(Q, { symbol: t }), /* @__PURE__ */ g("b", { children: e(`games.brave-and-bold.token_${t}`) })] }, t))
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/brave-and-bold/entry.tsx
var Et = {
	definition: ot,
	View: gt,
	bot: vt,
	fx: St,
	OverView: Ct,
	Options: wt,
	Guide: Tt,
	locales: {
		zh: {
			criticalBadge: "临界",
			purchaseCost: "费用",
			stockCount: "库存",
			drawCount: "抽取 {{n}} 枚",
			latestAbility: "最近激活",
			viewOwnBoard: "查看我的角色",
			instructionDraw: "点击武装袋继续抽取，或停止抽取。",
			instructionAllocate: "点击高亮能力分配筹码，然后确认分配。",
			instructionConfirm: "分配完毕后，请确认分配。",
			instructionActivate: "点击已分配的能力，选择激活顺序。",
			instructionDefend: "即将受到普通伤害 {{normal}} 点、不可防御伤害 {{indefensible}} 点；可防御或继续结算。",
			instructionTakeHit: "即将受到普通伤害 {{normal}} 点、不可防御伤害 {{indefensible}} 点；请继续结算。",
			instructionChoose: "打开当前操作，选择本次使用的选项。",
			instructionHeal: "点击高亮角色，选择恢复的生命值。",
			instructionTarget: "点击高亮角色，选择目标与数量。",
			instructionBuy: "点击高亮筹码购买，或继续结束补给。",
			instructionAbility: "点击高亮能力，选择本次使用的能力。",
			instructionToken: "{{action}}：选择一枚可用筹码。",
			instructionOptional: "选择可用能力或打开当前操作；也可继续。",
			instructionContinue: "点击继续，完成当前步骤。",
			markGained: "获得{{name}}",
			markUsed: "使用{{name}}",
			bonusThreshold: "抽取{{n}}枚筹码",
			reduceCrisis: "将危机筹码需求减少 1 枚",
			help_upgrade_aegis: "每轮一次，单次将受到超过3点伤害时，将该次全部伤害延后至下一轮战斗开始，届时不可防御且不可再次延后。此处采用官方FAQ的全部延后裁定。",
			help_upgrade_sword: "将当前抽区的全部战斗筹码分配给同一个能力，本轮伤害池增加3。必须实际分配至少一枚战斗筹码。",
			help_upgrade_training: "准备阶段恰好抽到2枚战斗筹码，获得1个战斗奖励。",
			help_upgrade_plane: "准备开始时将上轮储存的筹码加入当前抽区，然后可从袋中选择1枚非危机筹码储存在飞机上。",
			help_upgrade_tiara: "每局一次，使用一项特殊能力时保留其标记，之后仍可再次使用，包括通常每局仅限一次的能力。",
			help_kind_basic: "普通筹码提供1个对应符号。",
			help_kind_double: "双倍筹码提供2个对应符号，可以分开支付给不同能力。",
			help_kind_power: "强化筹码仍提供1个符号，另有抽取效果：战斗恢复2生命；敏捷抽2选1；聚焦可将1枚危机送回袋中。每枚资源强化筹码允许额外购买1枚筹码且费用减少1。",
			help_kind_critical: "购买和激活均需要10个同类战斗或敏捷符号；成功激活立即使目标负伤，再造成等于其剩余生命的不可防御伤害。",
			help_token_C: "战斗筹码可支付能力费用。未分配的战斗符号通常每个提供1点伤害。",
			help_token_R: "资源筹码可支付能力费用，同时计入本轮购买资源，包括已用于能力的资源筹码。",
			help_token_A: "敏捷筹码用于支付对应能力费用。",
			help_token_F: "聚焦筹码可支付能力费用，或弃置以查看下一张挑战牌。",
			help_token_E: "徽记用于支付本角色的徽记费用，也会触发本角色的恢复效果。",
			help_token_X: "危机筹码占用1格危机表。累计达到3格时触发危机。",
			help_token_U: "万能筹码可以1比1替代任意基础符号，不能替代徽记或特殊筹码。",
			help_token_V: "逆转筹码可立即撤回刚抽出的筹码，将其送回袋中并重新抽取。",
			help_token_K: "氪石占用2格危机表。第三轮起敌人可花费6资源将氪石加入超人的袋中。",
			help_token_S: "太阳筹码用于超人能力；2枚太阳可替代1个能力费用符号。",
			help_token_W: "2枚神速力可替代1个敏捷符号；弃置1枚可防御2点伤害，3枚可造成4点伤害。准备阶段也可弃置2枚将1枚危机送回袋中。",
			help_token_B: "天启星护盾用于能力费用，或弃置1枚防御2点伤害。",
			help_token_D: "购买或激活临界质量时，可弃置此筹码将所需的匹配符号数从10减少至7。",
			help_token_L: "遗物可替代任意基础符号，每枚用于能力的遗物使该能力增加2点伤害；使用后的遗物在再平衡时返回供应。",
			help_token_H: "2枚狩猎可替代1个资源，3枚可替代任意基础符号；无处可逃标记允许一次2比1替代任意基础符号。",
			help_token_M: "黏土可支付泥脸能力，或与黏土、结构完整共2枚替代1个基础符号。黏土鞭击可额外堆叠黏土增加伤害。",
			help_token_I: "结构完整可支付泥脸能力，或与黏土、结构完整共2枚替代1个基础符号。",
			help_token_Y: "黄太阳抽出时恢复1生命，也可支付超级少女的能力费用。",
			help_token_Z: "红太阳抽出时失去1生命，也可支付超级少女能力费用。冷酷狂怒允许其替代战斗符号。",
			help_token_O: "悬赏可替代资源符号。用它触发大闹一场，或在补给前将抽区或弃置区的悬赏返回供应，再移除1枚非危机筹码。",
			extraResponse: "额外回应一次",
			recoverClay: "取回已用黏土和结构完整",
			holdKryptonite: "暂存氪石",
			extraMass: "追加黏土",
			unselected: "待选角色",
			gadgets: "工具牌",
			peekedChallenge: "已查看的下轮挑战",
			dynamic_resourcePlusGadgets: "伤害等于本轮资源总量，加上本轮已使用的工具牌数。蝙蝠镖另加2伤害。",
			dynamic_mass: "伤害等于本次叠放的黏土筹码数。",
			dynamic_matchPool: "伤害池增加或减少至与所选对手相同。泥脸登场时不创建伤害池。",
			dynamic_lastTaken: "造成等于刚刚实际承受伤害的不可防御伤害。被防御的伤害不计入。",
			help_darkKnight: "在瞭望塔阶段使用，使一名对手跳过本轮恢复。",
			help_explosive: "在战斗阶段使用，造成3点不可防御伤害。",
			help_strategist: "对手刚抽出筹码时，使其将该筹码放回袋中重新抽取。",
			help_strength: "准备阶段开始时，向袋中临时加入3枚基础战斗筹码，再平衡时归还3枚。",
			help_flight: "随时向袋中加入2枚黄太阳；接下来使用的2枚黄太阳归还供应。",
			help_recharge: "恢复3生命，并取消使你跳过恢复的效果。",
			help_senses: "为一次攻击增加1伤害，或防御2点普通伤害。",
			help_lasso: "准备阶段开始时，对手指定一项能力。本轮只有该能力可以贡献伤害池，未用战斗筹码不贡献伤害。",
			help_bracelets: "战斗阶段开始时，使对手未用战斗筹码不贡献伤害，或减少其本轮购买上限1。",
			help_wrath: "每局一次。本轮抽到危机且已经承受伤害时，每枚本轮实际抽到的危机为伤害池增加3伤害。",
			help_ahead: "取得先手，本轮可购买至多2枚同一种筹码。",
			help_hitFirst: "使下一项激活的普通能力造成不可防御伤害；不能用于终结技。",
			help_analysis: "准备阶段结束时，将当前抽区一枚非危机筹码与袋内一枚自选筹码交换。",
			help_reopen: "强化阶段，将一张弃置挑战牌放回挑战牌堆并洗混。",
			help_manipulate: "准备阶段开始时使用。本轮每次抽2枚、选1枚；抽到危机必须选危机。",
			help_subvert: "将任意角色当前抽区中尚未分配的一枚筹码移入其弃置区。",
			help_destiny: "将任意角色当前抽区的一枚危机放回袋中。若在第三枚刚抽出时使用，可以避免危机。",
			help_fate: "强化阶段开始时，从军械库袋中选择6枚替换当前展示。",
			help_upperHand: "查看顶端2张挑战，可选一张替换当前挑战，另一张弃置，并将弃牌洗回牌堆。",
			help_mechano: "防御2点普通伤害，或免费获得一枚强化筹码；选择获得筹码会永久移除本标记。",
			help_totality: "瞭望塔阶段开始时，向袋中加入至多3枚遗物。弃置区遗物在再平衡时归还供应。",
			help_distance: "支付2枚狩猎，使一项激活能力的伤害再次加入伤害池。",
			help_escape: "分配能力时，以2枚狩猎代替1枚任意基础筹码；每个标记只支付一次替代。",
			help_scent: "一名对手用完当前抽区的全部筹码后，造成3伤害。仅用于购买的资源仍属于未用筹码。",
			help_fast: "支付2枚狩猎，将对手伤害池总量减半，向下取整且至少为1。",
			help_living: "防御一次攻击的全部普通伤害。每次使用在再平衡时增加1枚危机。",
			help_predatory: "准备阶段，弃置任意组合的2枚黏土或结构完整，将任意角色一枚危机放回袋中。",
			help_imitation: "支付费用模仿对手一项能力，不占用攻击或回应。可以用自己的徽记；2枚黏土或结构完整可以代替特殊筹码。不获得对手标记或特殊筹码。",
			help_rage: "当前抽区有红太阳时，使一项激活能力增加1伤害；生命不高于30时改为增加3。不消耗红太阳。",
			help_fury: "战斗阶段开始时，本轮红太阳可代替战斗；生命不高于20时，每枚未用红太阳为伤害池增加2伤害。",
			help_daughter: "使一项普通伤害能力改为不可防御。生命不高于10时，可再弃置2枚红太阳，使本轮伤害池及终结技均不可防御。",
			help_companion: "每轮一次，陷入危机后仍可分配并激活角色板的一项普通能力。",
			help_mainMan: "强化阶段开始时，将袋、当前抽区或弃置区一枚非危机筹码归还供应。",
			help_looseEnds: "准备阶段开始时加入一枚万能。强化阶段开始时，必须从袋、抽区或弃置区归还一枚万能或悬赏。",
			help_double: "刚收取悬赏后，再从供应向袋中加入一枚悬赏。",
			help_regeneration: "自动触发且每局一次：生命将降至1或以下时先恢复10，再继续承受同来源的剩余伤害。",
			help_gadget_batarang: "为一次攻击增加2伤害。",
			help_gadget_smoke: "防御2点普通伤害。",
			help_gadget_grapple: "分配前获得1点敏捷奖励。",
			help_gadget_contingency: "终结技步骤存储一枚未用筹码，下轮准备时加入当前抽区。",
			help_gadget_pulse: "准备阶段结束时，弃置一名未陷入危机对手最后抽到的筹码。",
			help_batman: "恢复：抽4枚。每枚徽记恢复3，每枚敏捷获得战略家，每2点资源抽一张工具牌。工具牌至多持有3张，每轮至多用3张。",
			help_superman: "恢复：抽4枚。每枚徽记恢复3，每点战斗造成2伤害，每枚黄太阳临时加入一枚自选基础筹码。2枚黄太阳可代替能力费用中任意1枚筹码。第三轮起，对手可花6资源加入氪石；氪石算2点危机。",
			help_wonderWoman: "开局选择两张永久升级。恢复：抽4枚，每枚徽记恢复3，每枚危机获得一个真言套索或臣服手镯。",
			help_flash: "恢复2，再抽3枚。每枚徽记或每点敏捷再恢复2；每两枚神速力可暂时弃置袋内一枚危机，袋内至少保留3枚。2神速力代替1敏捷；1神速力防御2；2神速力移除危机；3神速力造成4伤害。每轮使用超过2枚，归还2枚神速力。",
			help_darkseid: "起始生命比通常少10。恢复4，再抽3枚；每枚徽记再恢复2，护盾留在当前抽区。每枚护盾防御2。临界质量折扣筹码使购买或激活所需同类单位减少3，一次只用一枚。",
			help_lex: "恢复：抽4枚，聚焦不占抽取次数。每枚徽记恢复3，每枚遗物造成1伤害。遗物代替任意基础费用，并为该能力增加2伤害；已用遗物在再平衡时归还供应。",
			help_cheetah: "恢复：抽4枚，每枚非狩猎恢复2；每枚狩猎选择造成1伤害或获得1资源。2狩猎代替1资源，3狩猎代替任意基础。第三危机抽出时可归还抽区3狩猎并归还该危机。战斗结束按对手未用筹码获得狩猎，完全无法获得时加入危机。再平衡不能减少危机。",
			help_clayface: "黏土与结构完整以2:1代替基础费用。泥脸在场时，所有人逐项激活并单独攻击；每次敌方攻击后泥脸可回应一次，同一能力可重复使用。危机时仍回应，但不能用或获得特殊能力。恢复抽4：战斗和徽记各造成2；受伤时资源或敏捷各恢复8；黏土和结构完整可加入抽区或归还。",
			help_supergirl: "准备时黄太阳恢复1，红太阳承受1。恰好抽到2危机时，每枚未用战斗贡献2伤害。恢复抽4：徽记和黄太阳各恢复3；红太阳各造成1并留在抽区；每组红黄太阳可承受2以获得忠实伙伴。",
			help_lobo: "每轮瞭望塔开始设立悬赏，激活对应能力便收入袋中，否则归还。悬赏可代替资源费用且不计再平衡的非危机数量。强化阶段可归还抽区或弃置的一枚悬赏，并移除另一枚非危机。恢复抽4：徽记恢复3，每枚危机造成2伤害，每枚悬赏可再设一个悬赏。",
			repeatAbility: "额外弃置战斗筹码，再次激活",
			name: "Brave & Bold: Bag Building Combat Game",
			character_batman: "蝙蝠侠",
			ability_batman_0: "猛烈突袭",
			ability_batman_1: "战术反击",
			ability_batman_2: "备战大师",
			ability_batman_3: "世界第一侦探",
			ability_batman_4: "精确打击",
			ability_batman_5: "精确打击 +",
			ability_batman_6: "哥谭守护者",
			character_superman: "超人",
			ability_superman_0: "重拳",
			ability_superman_1: "轨道战斗",
			ability_superman_2: "冲击波拳",
			ability_superman_3: "热视线",
			ability_superman_4: "极速闪击",
			ability_superman_5: "极速闪击 +",
			ability_superman_6: "沐浴太阳",
			character_wonderWoman: "神奇女侠",
			ability_wonderWoman_0: "盾牌重击",
			ability_wonderWoman_1: "战士的反击",
			ability_wonderWoman_2: "奥林匹斯之女",
			ability_wonderWoman_3: "天堂岛之怒",
			ability_wonderWoman_4: "战斗号召",
			ability_wonderWoman_5: "战斗号召 +",
			ability_wonderWoman_6: "不义者的命运",
			character_flash: "闪电侠",
			ability_flash_0: "闪电突袭",
			ability_flash_1: "尾流",
			ability_flash_2: "精准加速",
			ability_flash_3: "闪点",
			ability_flash_4: "动量循环",
			ability_flash_5: "动量循环 +",
			ability_flash_6: "时间巅峰",
			character_darkseid: "达克赛德",
			ability_darkseid_0: "欧米伽射线",
			ability_darkseid_1: "反生命颠覆",
			ability_darkseid_2: "宇宙预见",
			ability_darkseid_3: "不可避免",
			ability_darkseid_4: "天启星军团",
			ability_darkseid_5: "天启星军团 +",
			ability_darkseid_6: "天启星的审判",
			character_lex: "莱克斯·卢瑟",
			ability_lex_0: "战甲冲击波",
			ability_lex_1: "追踪能量讯号",
			ability_lex_2: "声波束",
			ability_lex_3: "莱克斯集团研究",
			ability_lex_4: "第四维度之臂",
			ability_lex_5: "第四维度之臂 +",
			ability_lex_6: "统治世界",
			character_cheetah: "豹女",
			ability_cheetah_0: "凶猛撕咬",
			ability_cheetah_1: "利爪风暴",
			ability_cheetah_2: "捕猎飞扑",
			ability_cheetah_3: "豹女诅咒",
			ability_cheetah_4: "穷追不舍",
			ability_cheetah_5: "穷追不舍 +",
			ability_cheetah_6: "狩猎仪式",
			character_clayface: "泥脸",
			ability_clayface_0: "黏土鞭击",
			ability_clayface_1: "窒息打击",
			ability_clayface_2: "重塑挥击",
			ability_clayface_3: "别打脸",
			ability_clayface_4: "怪物复苏",
			ability_clayface_5: "怪物复苏 +",
			ability_clayface_6: "我只想成为普通人",
			character_supergirl: "超级少女",
			ability_supergirl_0: "黄太阳的力量",
			ability_supergirl_1: "派对女孩",
			ability_supergirl_2: "不会有好结果",
			ability_supergirl_3: "众神并不仁慈",
			ability_supergirl_4: "毫无边界",
			ability_supergirl_5: "毫无边界 +",
			ability_supergirl_6: "复仇的重担",
			character_lobo: "暴狼",
			ability_lobo_0: "碎颅",
			ability_lobo_1: "沉重打击",
			ability_lobo_2: "断脊",
			ability_lobo_3: "不留活口",
			ability_lobo_4: "完成契约",
			ability_lobo_5: "完成契约 +",
			ability_lobo_6: "所有人都得死",
			special_darkKnight: "黑暗骑士",
			special_explosive: "爆破蝙蝠镖",
			special_strategist: "战略家",
			special_strength: "超级力量",
			special_flight: "飞行",
			special_recharge: "太阳充能",
			special_senses: "敏锐感官",
			special_lasso: "真言套索",
			special_bracelets: "臣服手镯",
			special_wrath: "亚马逊之怒",
			special_ahead: "快人一步",
			special_hitFirst: "先发制人",
			special_analysis: "法证分析",
			special_reopen: "重开旧案",
			special_manipulate: "操控",
			special_subvert: "颠覆",
			special_destiny: "命运转移",
			special_fate: "命运主宰",
			special_upperHand: "占据上风",
			special_mechano: "机械人",
			special_totality: "全体集合",
			special_distance: "逼近目标",
			special_escape: "无处可逃",
			special_scent: "血腥气息",
			special_fast: "快到无法锁定",
			special_living: "活体黏土",
			special_predatory: "捕食形态",
			special_imitation: "超凡模仿",
			special_rage: "克制怒火",
			special_fury: "无尽狂怒",
			special_daughter: "最后之女",
			special_companion: "忠实伙伴",
			special_mainMan: "大人物",
			special_looseEnds: "不留后患",
			special_double: "双倍或全无",
			special_regeneration: "扎尼亚再生",
			desc: "操纵英雄与反派的筹码袋，在危机边缘构筑连招。",
			rules: "目标：\n击败对方队伍的全部角色，便赢得游戏。角色的生命值首次降至零时，该角色负伤；如果负伤后的恢复失败，或恢复后生命值再次降至零，该角色被击败。\n挑战牌堆用尽时，比较双方队伍的生命值总和，较高的一方获胜；总和相同时，由持有先手标记的一方获胜。\n游戏准备：\n每位玩家选择一名角色。多人对局中，英雄与反派分别组成队伍。神奇女侠需要选择两张升级牌。公共军械库共有 60 枚筹码，其中展示 6 枚；每名角色向挑战牌堆提供 5 张挑战牌。\n角色的生命值上限根据对局人数确定：\n· 双人对局中，每名角色的生命值上限为 60 点。\n· 四人对局中，每名角色的生命值上限为 40 点。\n· 六人对局中，每名角色的生命值上限为 35 点。\n每轮流程：\n每轮依次进行瞭望塔、准备、战斗和强化阶段，随后进行再平衡。首轮跳过瞭望塔阶段。\n从第二轮开始，由生命值最低的角色取得先手；如果生命值相同，则保留原先的先手标记。揭示一张挑战牌，然后进行角色恢复。\n准备阶段：\n从袋中逐枚抽取筹码，每次抽取后都可以停止。抽出第三枚危机筹码时，你陷入危机，本轮不能正常使用能力，伤害和购买需要延后处理。\n每次抽取后的响应全部完成后，才能继续抽取。逆转筹码可以撤回刚刚抽出的筹码。抽取奖励根据本轮实际抽到的非危机筹码数量计算；移除已抽出的筹码不会扣回奖励。直接加入当前抽区的筹码，以及此前储存的筹码，不产生抽取奖励。\n战斗阶段：\n先为准备使用的全部能力分配费用，再按你选择的顺序激活能力。双倍筹码提供的两个符号可以分别支付。同一项能力的基础模式和加号模式，每轮只能选择其中一种。\n· 能力造成的伤害、未使用的战斗筹码及战斗奖励共同形成伤害池；终结技单独结算。\n· 普通伤害可以防御。不可防御伤害不能通过防御抵消，但仍受针对整个伤害池的效果影响。\n· 泥脸登场时，改为逐次攻击和回应，不形成伤害池；同一项能力可以再次使用。\n强化阶段：\n未陷入危机的玩家先完成强化，陷入危机的玩家随后完成。通常可以购买至多 3 种不同的筹码；陷入危机时，至多购买 2 种。每枚资源强化筹码允许额外购买一次，并使该次购买的费用减少 1 点资源。\n各类筹码的购买费用如下：\n· 基础筹码的费用为 2 点资源。\n· 徽记筹码和特殊筹码的费用为 3 点资源。\n· 双倍筹码的费用为 3 点资源。\n· 强化筹码的费用为 4 点资源。\n· 万能筹码和逆转筹码的费用为 5 点资源。\n购买或激活临界质量，需要支付 10 个同类的战斗符号或敏捷符号。\n再平衡：\n先处理临时筹码，再根据袋中非危机筹码的总数，将危机筹码补至以下数量：\n· 非危机筹码少于 17 枚时，补至 3 枚危机筹码。\n· 非危机筹码为 17 至 20 枚时，补至 4 枚危机筹码。\n· 非危机筹码为 21 至 24 枚时，补至 5 枚危机筹码。\n· 非危机筹码为 25 至 31 枚时，补至 6 枚危机筹码。\n· 非危机筹码为 32 至 39 枚时，补至 7 枚危机筹码。\n· 非危机筹码为 40 枚及以上时，补至 8 枚危机筹码。\n最后，将弃置区和当前抽区的筹码装回袋中。\n团队规则：\n队伍可以将伤害池中的伤害及恢复效果分配给多个目标，也可以共同支付购买所需的资源，并为队友防御。终结技只能指定一名对手。各角色的特殊能力详见角色说明及官方常见问题解答。",
			use: "使用",
			continue: "继续",
			chooseToken: "选择筹码",
			chooseCharacter: "选择角色",
			chooseUpgrade: "选择升级",
			useTiara: "使用头冠保留标记",
			setContract: "设立悬赏契约",
			usePlane: "使用隐形飞机",
			draw: "抽取筹码",
			stop: "停止抽取",
			discardToken: "弃置筹码",
			keepToken: "保留筹码",
			reverse: "撤回并重新抽取",
			huntCrisis: "归还3枚狩猎，移除危机",
			blockCombat: "阻止未用战斗筹码造成伤害",
			blockPurchase: "减少一次购买",
			clearAllocation: "清除分配",
			confirmAllocation: "完成分配",
			allocateAbility: "分配费用",
			activateAbility: "激活能力",
			finish: "发动终结技",
			dealDamage: "造成伤害",
			recover: "恢复生命",
			playGadget: "使用工具牌",
			preventDamage: "防御伤害",
			useAegis: "延后承受伤害",
			returnToken: "归还筹码",
			cleanup: "清理筹码",
			buyDiscount: "减价购买",
			buyToken: "购买筹码",
			buyCritical: "购买临界质量",
			buyGadget: "花费2资源抽取工具牌",
			buyKryptonite: "花费6资源加入氪石",
			replaceToken: "更换筹码",
			resolveBounty: "结算未完成悬赏",
			declareAbility: "指定能力",
			replaceChallenge: "替换挑战牌",
			takeGadget: "获得工具牌",
			returnGadget: "放回工具牌堆底",
			gainSpecial: "获得特殊能力",
			gainResource: "获得资源",
			gainCompanion: "承受2伤害，获得忠实伙伴",
			addCrisis: "增加危机筹码",
			giveClay: "给予泥脸黏土筹码",
			takeFirst: "取得先手",
			returnCrisis: "将危机放回袋中",
			storeToken: "存储筹码",
			gainToken: "获得筹码",
			chooseOpponent: "选择对手",
			peekChallenge: "弃置聚焦，查看下张挑战",
			stealPower: "永久移除机械人，获得强化筹码",
			speedAttack: "弃置3枚神速力，造成4伤害",
			activateCritical: "激活临界质量",
			errAction: "该操作已不可用，请按当前局面重新选择。",
			logDraw: "抽取筹码",
			logHeal: "恢复{{n}}生命",
			logRegenerate: "触发扎尼亚再生",
			logDamage: "承受{{n}}伤害",
			logDefeated: "被击败",
			logInjured: "受伤",
			logCrisis: "陷入危机",
			logActivate: "激活{{ability}}",
			upgradeAegis: "雅典娜神盾",
			upgradeSword: "亚马逊之剑",
			upgradeTraining: "亚马逊战斗训练",
			upgradePlane: "隐形飞机",
			upgradeTiara: "天堂岛头冠",
			gadgetBatarang: "蝙蝠镖",
			gadgetSmoke: "烟雾弹",
			gadgetContingency: "应变预案",
			gadgetGrapple: "钩爪枪",
			gadgetPulse: "电磁脉冲",
			duel: "双人对战",
			teams: "英雄对反派：双方各两人",
			league: "英雄对反派：双方各三人",
			optMode: "对战形式",
			optExpansion: "Supergirl & Lobo 扩展",
			round: "第{{n}}轮",
			health: "生命",
			resources: "资源",
			bag: "武装袋",
			drawArea: "当前抽区",
			discard: "弃置区",
			supply: "角色供应",
			armoury: "正义联盟军械库",
			challenge: "本轮挑战",
			remaining: "剩余{{n}}张挑战",
			first: "先手",
			crisis: "危机",
			injured: "受伤",
			defeated: "已被击败",
			waiting: "等待{{name}}行动",
			resolving: "结算中",
			selectPrompt: "选择你的角色",
			actions: "当前操作",
			abilities: "角色能力",
			specials: "特殊能力",
			bonus: "抽取奖励",
			damagePool: "伤害池",
			finisher: "终结技",
			normalDamage: "普通伤害",
			indefensible: "不可防御伤害",
			heal: "恢复生命",
			cost: "费用",
			target: "目标",
			payment: "分配筹码",
			autoFill: "自动填入",
			confirm: "确认",
			cancel: "取消",
			log: "对战记录",
			viewCharacter: "查看角色",
			victory: "战斗胜利",
			finalHealth: "剩余生命",
			reviewTable: "回看牌桌",
			playAgain: "再战一场",
			backLobby: "返回大厅",
			heroTeam: "英雄阵营",
			villainTeam: "反派阵营",
			watchtower: "瞭望塔",
			preparation: "准备",
			combat: "战斗",
			powerUp: "强化",
			select: "选择角色",
			done: "战斗结束",
			abilityEffect: "伤害{{damage}} · 恢复{{heal}} · 资源{{resource}}",
			paymentSlot: "费用槽{{n}}",
			tokenLabel: "{{name}} · {{kind}}",
			basic: "基础",
			double: "双倍",
			power: "强化",
			critical: "临界质量",
			noTokens: "暂无筹码",
			allocationReady: "分配已就绪",
			needPayment: "请选择费用筹码",
			partialPayment: "费用尚未付齐",
			details: "详情",
			abilityDynamic: "按能力条件结算",
			token_C: "战斗",
			token_R: "资源",
			token_A: "敏捷",
			token_F: "聚焦",
			token_E: "角色徽记",
			token_X: "危机",
			token_U: "万能",
			token_V: "逆转",
			token_K: "氪石",
			token_S: "黄太阳",
			token_W: "神速力",
			token_B: "天启星护盾",
			token_D: "临界质量折扣",
			token_L: "遗物",
			token_H: "狩猎",
			token_M: "黏土",
			token_I: "结构完整性",
			token_Y: "黄太阳",
			token_Z: "红太阳",
			token_O: "悬赏",
			challenge_212: "本轮未用战斗筹码造成的伤害不可防御。",
			challenge_211: "本轮禁止所有筹码替代，包括筹码自身的替代能力。",
			challenge_210: "本轮不能使用特殊能力。",
			challenge_209: "每人本轮获得的资源奖励减少2。",
			challenge_101: "准备结束时，每人随机抽取1枚筹码；若不是危机，则归还供应。",
			challenge_247: "弃置1个未用战斗单位，可以再次触发一项已激活能力。",
			challenge_246: "本轮所有伤害均不可防御。",
			challenge_245: "本轮每人可以将1枚危机放回袋中，并重新抽取。",
			challenge_243: "陷入危机后，可以分配并激活角色板上的1项能力。",
			challenge_244: "准备结束后，每人将对手抽区中的1枚筹码移到其弃置区。",
			challenge_266: "本轮只能将战斗筹码分配给同一项能力。",
			challenge_264: "本轮按玩家顺序抽取，抽到的危机对所有人有效。",
			challenge_265: "每人的未用战斗筹码至多造成3伤害。",
			challenge_263: "未分配全部战斗筹码的人，伤害池变为零。",
			challenge_262: "本轮伤害不能被修改、防御、减少或延后。",
			challenge_250: "战斗阶段的所有生命恢复效果无效。",
			challenge_252: "再平衡后，危机玩家选择袋中1枚非危机筹码归还供应。",
			challenge_253: "准备开始时，将自选2枚基础筹码加入袋中，再平衡时归还。",
			challenge_254: "再平衡后随机抽取1枚；若为战斗、资源或敏捷，则额外加入1枚同类基础筹码。",
			challenge_251: "本轮抽取至少7枚筹码的人，再平衡时可以将袋中危机筹码减少1枚，最少保留3枚。",
			challenge_233: "本轮抽出的筹码不能被逆转、移除、替换或从多个候选中选择。",
			challenge_232: "本轮每个未用战斗单位可以造成1伤害，或恢复1生命。",
			challenge_231: "每使用一次特殊能力，再平衡时额外加入1枚危机，至多8枚。",
			challenge_230: "达克赛德若至少有10生命，本轮获得受伤标记；轮末未被击败则移除。",
			challenge_229: "每人获得3个资源奖励。",
			challenge_238: "从袋中自选2枚基础筹码，加入当前抽区。",
			challenge_240: "选择一项能力，使其伤害翻倍；终结技除外。",
			challenge_239: "每人恢复5生命；首轮时改为重新洗牌并翻出另一张挑战。",
			challenge_236: "若对手没有陷入危机，获得2个资源奖励。",
			challenge_237: "立即指定一项能力；本轮激活该能力时，额外造成2伤害。",
			challenge_215: "用完当前抽区所有筹码后，可额外造成2伤害；否则轮末承受5伤害。",
			challenge_216: "补给后，每人可选对手弃置区至多2枚非危机筹码，使其下轮继续弃置。",
			challenge_217: "武装袋最大的人取得先手；平手时角色筹码较少者优先。",
			challenge_218: "战斗结束时，每个未用抽区筹码使其持有者承受1伤害。",
			challenge_219: "恢复行动中的每个正向恢复效果减少1，最少为零。",
			challenge_222: "泥脸可在首次回应时，免费模仿对手刚激活的能力。",
			challenge_226: "泥脸选择对手；对手选择向自己袋中加入1枚危机，或给予泥脸1枚黏土。",
			challenge_224: "本轮首次有对手分配基础筹码时，从自己的供应取1枚同类筹码加入抽区。",
			challenge_225: "准备开始时随机抽取2枚，选择其中1枚弃置；不能选择危机。",
			challenge_223: "准备开始时加入自选2枚基础筹码，再平衡时归还。",
			challenge_277: "未用战斗筹码造成的伤害不可防御。",
			challenge_278: "每人可以将袋中1枚基础筹码归还供应。",
			challenge_280: "每人恢复5生命；首轮时改为重新洗牌并翻出另一张挑战。",
			challenge_281: "准备结束时恰有2枚危机，获得2伤害。",
			challenge_279: "超级少女获得自选黄太阳或红太阳；对手可加入1枚基础筹码，或移除1枚非危机筹码。",
			challenge_273: "暴狼若没有收取悬赏，对手选择使其承受5点伤害，或在再平衡时多加1枚危机。",
			challenge_272: "准备阶段抽取至少10枚筹码的人，再平衡时额外加入1枚危机。",
			challenge_271: "当前抽区至多可分配3枚徽记。",
			challenge_270: "首次有人移除袋中的非危机筹码时，其他人也可移除1枚。",
			challenge_269: "本轮筹码只能通过补给购买加入袋中。"
		},
		en: {
			criticalBadge: "Critical",
			purchaseCost: "Cost",
			stockCount: "Stock",
			drawCount: "Drawn {{n}}",
			latestAbility: "Last activated",
			viewOwnBoard: "My character",
			instructionDraw: "Click your bag to draw again, or stop drawing.",
			instructionAllocate: "Click a highlighted ability to assign tokens, then confirm allocation.",
			instructionConfirm: "Confirm allocation when you are ready.",
			instructionActivate: "Click an assigned ability to choose the activation order.",
			instructionDefend: "Incoming: {{normal}} normal and {{indefensible}} indefensible damage. Defend or continue resolving.",
			instructionTakeHit: "Incoming: {{normal}} normal and {{indefensible}} indefensible damage. Continue to resolve it.",
			instructionChoose: "Open Current actions and select an option.",
			instructionHeal: "Click a highlighted character to choose how much health to restore.",
			instructionTarget: "Click a highlighted character to choose the target and amount.",
			instructionBuy: "Click a highlighted token to buy it, or continue to finish resupply.",
			instructionAbility: "Click a highlighted ability to choose which one to use.",
			instructionToken: "{{action}}: choose an available token.",
			instructionOptional: "Choose an available ability or open Current actions; you may also continue.",
			instructionContinue: "Click Continue to finish this step.",
			markGained: "Gained {{name}}",
			markUsed: "Used {{name}}",
			bonusThreshold: "Draw {{n}} tokens",
			reduceCrisis: "Reduce the required crisis count by 1",
			help_upgrade_aegis: "Once per turn, defer an instance exceeding 3 damage in full to the start of your next Combat. It becomes indefensible and cannot be deferred again. This follows the official FAQ’s full-deferral ruling.",
			help_upgrade_sword: "Assign every Combat token in your current draw to one ability to add 3 to your damage pool. At least one Combat token must be assigned.",
			help_upgrade_training: "Drawing exactly 2 Combat tokens during Preparation grants 1 Combat bonus.",
			help_upgrade_plane: "At the start of Preparation add the stored token to your current draw, then you may store a chosen non-crisis token from your bag.",
			help_upgrade_tiara: "Once per game, use a special ability without removing its marker. It remains available for another use, even for an ability normally limited to once per game.",
			help_kind_basic: "A basic token provides one matching symbol.",
			help_kind_double: "A double token provides two matching symbols which can be allocated separately.",
			help_kind_power: "A Power-Up provides one symbol and an extra effect: Combat heals 2; Agility draws two to choose one; Focus may return a Crisis to the bag. Each Resource Power-Up permits one extra purchase costing one less.",
			help_kind_critical: "Purchase and activate with ten matching Combat or Agility symbols. Activation immediately injures the opponent and deals indefensible damage equal to their remaining health.",
			help_token_C: "Combat pays ability costs. Each unallocated Combat symbol normally contributes 1 damage.",
			help_token_R: "Resource pays ability costs and also contributes to this turn’s purchase resources, including Resources allocated to abilities.",
			help_token_A: "Agility pays matching ability costs.",
			help_token_F: "Focus pays ability costs, or may be discarded to peek at the next challenge.",
			help_token_E: "A Crest pays your character’s Crest costs and triggers their recovery effects.",
			help_token_X: "A Crisis occupies one crisis-meter space. Reaching three triggers a crisis.",
			help_token_U: "Utility substitutes for any basic symbol at 1:1, but not for Crests or special tokens.",
			help_token_V: "Reverse immediately undoes the token just drawn, returning it to the bag for a redraw.",
			help_token_K: "Kryptonite occupies two crisis-meter spaces. From turn three, an opponent may spend 6 resources to add it to Superman’s bag.",
			help_token_S: "Sun tokens pay Superman’s costs; two may substitute for one required ability symbol.",
			help_token_W: "Two Speedforce substitute for Agility. Discard one to prevent 2 damage, or three to deal 4. During Preparation two may return a Crisis to the bag.",
			help_token_B: "An Apokoliptian Shield pays ability costs or may be discarded to prevent 2 damage.",
			help_token_D: "Discard this token when purchasing or activating Critical Mass to reduce the required matching symbols from ten to seven.",
			help_token_L: "A Relic substitutes for any basic symbol and adds 2 damage to the ability it pays for. Used Relics return to supply during rebalancing.",
			help_token_H: "Two Hunt substitute for Resource; three for any basic symbol. No Escape permits one substitution of two Hunt for any basic symbol.",
			help_token_M: "Mass of Clay pays Clayface costs; any two Mass or Integrity substitute for a basic symbol. Clay Lash may stack extra Mass for damage.",
			help_token_I: "Integrity pays Clayface costs; any two Mass or Integrity substitute for a basic symbol.",
			help_token_Y: "Yellow Sun heals 1 when drawn and pays Supergirl’s ability costs.",
			help_token_Z: "Red Sun costs 1 health when drawn and pays Supergirl costs. Relentless Fury allows it to substitute for Combat.",
			help_token_O: "Bounty substitutes for Resource. It also pays for Party Crasher, or may be returned from current draw or discard before resupply to remove a non-crisis token.",
			extraResponse: "One extra response",
			recoverClay: "Recover used clay and integrity",
			holdKryptonite: "Set Kryptonite aside",
			extraMass: "Additional clay",
			unselected: "Choose a character",
			gadgets: "Gadgets",
			peekedChallenge: "Peeked next challenge",
			dynamic_resourcePlusGadgets: "Damage equals this turn’s resources plus gadgets played. A Batarang adds another 2 damage.",
			dynamic_mass: "Damage equals the number of Mass of Clay tokens stacked for this activation.",
			dynamic_matchPool: "Increase or decrease your damage pool to match the chosen opponent. No damage pool exists when Clayface is in play.",
			dynamic_lastTaken: "Deal indefensible damage equal to the damage just taken. Prevented damage does not count.",
			help_darkKnight: "Use during Watchtower to make an opponent skip recovery.",
			help_explosive: "Use during Combat to deal 3 indefensible damage.",
			help_strategist: "Immediately after an opponent draws a token, return it to their bag and redraw.",
			help_strength: "At the start of Preparation, temporarily add 3 basic Combat tokens. Return 3 during rebalancing.",
			help_flight: "Add 2 Yellow Suns to your bag at any time. Return the next 2 Yellow Suns used to the supply.",
			help_recharge: "Recover 3 health and cancel an effect that makes you skip recovery.",
			help_senses: "Add 1 damage to an attack or prevent 2 normal damage.",
			help_lasso: "At the start of Preparation, an opponent names one ability. Only that ability contributes to their damage pool; unused Combat adds nothing.",
			help_bracelets: "At the start of Combat, prevent unused Combat from adding damage or reduce an opponent’s purchase limit by 1.",
			help_wrath: "Once per game, after taking damage on a turn when you drew Crisis, add 3 to your damage pool per Crisis drawn this turn.",
			help_ahead: "Take first player. This turn you may buy up to 2 copies of the same token.",
			help_hitFirst: "The next normal ability activated deals indefensible damage. Cannot modify a finishing move.",
			help_analysis: "At the end of Preparation, exchange a non-Crisis token in your current draw for one chosen from your bag.",
			help_reopen: "During Power-Up, shuffle a discarded challenge back into the deck.",
			help_manipulate: "Use at the start of Preparation. Draw 2 and select 1 each time; you must select a Crisis if drawn.",
			help_subvert: "Move an unallocated token from any character’s current draw to their discard.",
			help_destiny: "Return a Crisis from any character’s board to their bag. Used immediately on the third Crisis, this prevents the crisis.",
			help_fate: "At the start of Power-Up, choose 6 tokens from the Armoury bag to replace the display.",
			help_upperHand: "Look at the top 2 challenges. You may replace the current challenge with one, discard the other, and shuffle discards into the deck.",
			help_mechano: "Prevent 2 normal damage or gain a Power-Up token for free. Gaining a token permanently removes this marker.",
			help_totality: "At the start of Watchtower add up to 3 Relics. Return discarded Relics to the supply during rebalancing.",
			help_distance: "Spend 2 Hunt to add the damage from an activated ability to the damage pool a second time.",
			help_escape: "When paying an ability, substitute 2 Hunt for 1 basic token. Each marker covers one substitution.",
			help_scent: "After an opponent uses all tokens in their current draw, deal 3 damage. Resources used only for purchases remain unused tokens.",
			help_fast: "Spend 2 Hunt to halve an opponent’s total damage pool, rounded down to a minimum of 1.",
			help_living: "Prevent all normal damage from one attack. Add 1 extra Crisis during rebalancing per use.",
			help_predatory: "During Preparation discard any 2 Mass of Clay and/or Structural Integrity to return a Crisis from any character to their bag.",
			help_imitation: "Pay to imitate an opponent’s ability without using an attack or response. Use your own crests; 2 clay/integrity replace a special token. Gain no opposing markers or special tokens.",
			help_rage: "With a Red Sun in your current draw, add 1 damage to an activated ability, or 3 at 30 health or less. Do not spend the Red Sun.",
			help_fury: "At the start of Combat, Red Suns may replace Combat this turn. At 20 health or less, each unused Red Sun adds 2 damage to the pool.",
			help_daughter: "Convert one normal-damage ability to indefensible. At 10 health or less, discard 2 Red Suns to make the pool and finishing move indefensible this turn.",
			help_companion: "Once per turn, after triggering a crisis, allocate and activate one normal board ability.",
			help_mainMan: "At the start of Power-Up, return a non-Crisis token from your bag, current draw or discard to the supply.",
			help_looseEnds: "At the start of Preparation add a Utility. At the start of Power-Up return a Utility or Bounty from bag, draw or discard.",
			help_double: "Immediately after collecting a Bounty, add another from the supply to your bag.",
			help_regeneration: "Automatically once per game: when health would reach 1 or less, recover 10, then continue taking remaining damage from that source.",
			help_gadget_batarang: "Add 2 damage to an attack.",
			help_gadget_smoke: "Prevent 2 normal damage.",
			help_gadget_grapple: "Gain an Agility bonus before allocating.",
			help_gadget_contingency: "During the finishing-move step store an unused token for next turn’s current draw.",
			help_gadget_pulse: "At the end of Preparation discard the last token drawn by an opponent who did not trigger a crisis.",
			help_batman: "Recovery: draw 4. Each Crest heals 3; each Agility gains Strategist; every 2 Resource draw a gadget. Hold at most 3 gadgets and play at most 3 per turn.",
			help_superman: "Recovery: draw 4. Each Crest heals 3; each Combat deals 2; each Yellow Sun temporarily adds a basic token. 2 Yellow Suns replace any ability token. From turn 3 an opponent may pay 6 to add Kryptonite, worth 2 Crisis.",
			help_wonderWoman: "Choose 2 permanent upgrades at setup. Recovery: draw 4; each Crest heals 3; each Crisis gains a Lasso or Bracelets.",
			help_flash: "Recover 2 and draw 3. Each Crest or Agility heals 2; each pair of Speedforce temporarily discards a bag Crisis, leaving at least 3. 2 Speedforce replace Agility; 1 prevents 2 damage; 2 remove a Crisis; 3 deal 4 damage. Spend over 2 in a turn and return 2 to supply.",
			help_darkseid: "Start with 10 less health. Recover 4 and draw 3; each Crest heals 2 more; Shields stay in the current draw. A Shield prevents 2. A Critical Mass discount token reduces a purchase or activation by 3; use only one at a time.",
			help_lex: "Recovery: draw 4, redrawing Focus. Each Crest heals 3; each Relic deals 1. A Relic replaces a basic cost and adds 2 damage to that ability. Return used Relics during rebalancing.",
			help_cheetah: "Recovery: draw 4; each non-Hunt heals 2; each Hunt deals 1 or grants 1 resource. 2 Hunt replace Resource, 3 replace any basic. On drawing the third Crisis return 3 current Hunt and that Crisis to supply. At combat end gain Hunt per unused opposing token, or add a Crisis if none can be gained. Rebalancing cannot remove Crisis.",
			help_clayface: "2 clay/integrity replace a basic cost. With Clayface in play, abilities attack individually; Clayface may respond to each enemy attack, and abilities may repeat. In crisis he still responds but cannot use or gain specials. Recovery: draw 4; Combat/Crest deal 2; while injured Resource/Agility heal 8; keep clay/integrity in the draw or return them.",
			help_supergirl: "During Preparation Yellow Sun heals 1 and Red Sun deals 1 to you. With exactly 2 Crisis drawn, unused Combat adds 2 damage each. Recovery: draw 4; Crest/Yellow Sun heal 3; Red Sun deals 1 and stays in the draw; each red/yellow pair may take 2 damage to gain a Companion.",
			help_lobo: "Set a Bounty contract at Watchtower. Activate its ability to collect it, otherwise return it. Bounty replaces Resource and does not count for rebalancing. During Power-Up return a drawn/discarded Bounty to remove another non-Crisis. Recovery: draw 4; Crest heals 3, each Crisis deals 2 damage, and each Bounty sets another contract.",
			repeatAbility: "Discard combat to activate again",
			name: "Brave & Bold: Bag Building Combat Game",
			character_batman: "Batman",
			ability_batman_0: "Brutal Assault",
			ability_batman_1: "Tactical Payback",
			ability_batman_2: "Master of Preparation",
			ability_batman_3: "Greatest Detective",
			ability_batman_4: "Surgical Strikes",
			ability_batman_5: "Surgical Strikes +",
			ability_batman_6: "Gotham’s Protector",
			character_superman: "Superman",
			ability_superman_0: "Heavy Punch",
			ability_superman_1: "Orbital Combat",
			ability_superman_2: "Shockwave Punch",
			ability_superman_3: "Heat Vision",
			ability_superman_4: "Speed Blitz",
			ability_superman_5: "Speed Blitz +",
			ability_superman_6: "Sun-Dipped",
			character_wonderWoman: "Wonder Woman",
			ability_wonderWoman_0: "Shielded Blow",
			ability_wonderWoman_1: "Warrior’s Rebuke",
			ability_wonderWoman_2: "Daughter of Olympus",
			ability_wonderWoman_3: "Wrath of the Themyscira",
			ability_wonderWoman_4: "Call to Arms",
			ability_wonderWoman_5: "Call to Arms +",
			ability_wonderWoman_6: "Fate of the Unworthy",
			character_flash: "The Flash",
			ability_flash_0: "Lightning Strike",
			ability_flash_1: "Slipstream",
			ability_flash_2: "Calculated Velocity",
			ability_flash_3: "Flashpoint",
			ability_flash_4: "Momentum Loop",
			ability_flash_5: "Momentum Loop +",
			ability_flash_6: "Temporal Apex",
			character_darkseid: "Darkseid",
			ability_darkseid_0: "Omega Eyes",
			ability_darkseid_1: "Anti-Life Subversion",
			ability_darkseid_2: "Cosmic Foresight",
			ability_darkseid_3: "Inevitable",
			ability_darkseid_4: "Apokoliptian Forces",
			ability_darkseid_5: "Apokoliptian Forces +",
			ability_darkseid_6: "Judgment of Apokolips",
			character_lex: "Lex Luthor",
			ability_lex_0: "Warsuit Shockwave",
			ability_lex_1: "Trace Energy Signatures",
			ability_lex_2: "Zonic Beam",
			ability_lex_3: "LexCorp Research",
			ability_lex_4: "4th Dimensional Arm",
			ability_lex_5: "4th Dimensional Arm +",
			ability_lex_6: "World Domination",
			character_cheetah: "Cheetah",
			ability_cheetah_0: "Ferocious Maul",
			ability_cheetah_1: "Clawstorm",
			ability_cheetah_2: "Predator’s Leap",
			ability_cheetah_3: "Curse of the Cheetah",
			ability_cheetah_4: "Relentless Pursuit",
			ability_cheetah_5: "Relentless Pursuit +",
			ability_cheetah_6: "Rite of the Hunt",
			character_clayface: "Clayface",
			ability_clayface_0: "Clay Lash",
			ability_clayface_1: "Smothering Blow",
			ability_clayface_2: "Re-Formed Swings",
			ability_clayface_3: "Not the Face",
			ability_clayface_4: "Monstrous Resurgence",
			ability_clayface_5: "Monstrous Resurgence +",
			ability_clayface_6: "I Just Want to Be Normal",
			character_supergirl: "Supergirl",
			ability_supergirl_0: "Strength of the Yellow Sun",
			ability_supergirl_1: "Party Girl",
			ability_supergirl_2: "This Will Not End Well",
			ability_supergirl_3: "Gods Are Not That Kind",
			ability_supergirl_4: "No Boundaries",
			ability_supergirl_5: "No Boundaries +",
			ability_supergirl_6: "Burden of Vengeance",
			character_lobo: "Lobo",
			ability_lobo_0: "Skullcracker",
			ability_lobo_1: "Dead Weight",
			ability_lobo_2: "Spinebreaker",
			ability_lobo_3: "Zero Survivors",
			ability_lobo_4: "Contract Fulfilled",
			ability_lobo_5: "Contract Fulfilled +",
			ability_lobo_6: "Everybody Dies",
			special_darkKnight: "Dark Knight",
			special_explosive: "Explosive Batarang",
			special_strategist: "Strategist",
			special_strength: "Super Strength",
			special_flight: "Flight",
			special_recharge: "Solar Recharge",
			special_senses: "Heightened Senses",
			special_lasso: "Lasso of Truth",
			special_bracelets: "Bracelets of Submission",
			special_wrath: "Wrath of the Amazon",
			special_ahead: "One Step Ahead",
			special_hitFirst: "Hit First",
			special_analysis: "Forensic Analysis",
			special_reopen: "Case Reopened",
			special_manipulate: "Manipulation",
			special_subvert: "Subversion",
			special_destiny: "Destiny Shift",
			special_fate: "Master of Fate",
			special_upperHand: "Upper Hand",
			special_mechano: "Mechano-Men",
			special_totality: "The Totality",
			special_distance: "Close the Distance",
			special_escape: "No Escape",
			special_scent: "Scent of Blood",
			special_fast: "Too Fast to Pin Down",
			special_living: "Living Clay",
			special_predatory: "Predatory Form",
			special_imitation: "Uncanny Imitation",
			special_rage: "Controlled Rage",
			special_fury: "Relentless Fury",
			special_daughter: "Last Daughter",
			special_companion: "Loyal Companion",
			special_mainMan: "The Main Man",
			special_looseEnds: "No Loose Ends",
			special_double: "Double or Nothing",
			special_regeneration: "Czarnian Regeneration",
			challenge_212: "Unused combat damage cannot be prevented.",
			challenge_211: "No token substitutions are allowed, including token abilities.",
			challenge_210: "No special abilities may be used.",
			challenge_209: "Each player has 2 fewer resource bonuses this turn.",
			challenge_101: "At the end of preparation each player draws one random token; return it to supply unless it is crisis.",
			challenge_247: "Discard one unused combat to trigger an activated ability again.",
			challenge_246: "All damage dealt is indefensible.",
			challenge_245: "Each player may return one crisis to their bag and redraw.",
			challenge_243: "After triggering a crisis, allocate and activate one board ability.",
			challenge_244: "After preparation, each player moves one opponent token from current draw to discard.",
			challenge_266: "Combat tokens can only be assigned to one ability.",
			challenge_264: "Draw in player order; crisis tokens drawn apply to all players.",
			challenge_265: "Unused combat can deal at most 3 damage.",
			challenge_263: "Unless all combat tokens are allocated, your damage pool becomes zero.",
			challenge_262: "Damage cannot be modified, prevented, reduced or delayed.",
			challenge_250: "Recovery effects during combat are cancelled.",
			challenge_252: "After rebalancing, crisis players return a chosen non-crisis token from their bag to supply.",
			challenge_253: "At start of preparation, add two chosen basic x1 tokens to bag; return them during rebalancing.",
			challenge_254: "After rebalancing randomly draw one token. If combat, resource or agility, add a basic x1 token of its type to bag.",
			challenge_251: "After drawing at least 7 tokens, you may return 1 Crisis from your bag during rebalancing, leaving at least 3.",
			challenge_233: "Drawn tokens cannot be reversed, removed, replaced or selected from.",
			challenge_232: "During combat unused combat can each deal 1 damage or recover 1 damage.",
			challenge_231: "Each special ability used adds an extra crisis during rebalancing, maximum 8.",
			challenge_230: "If Darkseid has at least 10 health, give him an injured marker this turn; remove it at turn end if not defeated.",
			challenge_229: "Gain 3 resource bonuses.",
			challenge_238: "Search bag for 2 basic tokens and add them to current draw.",
			challenge_240: "Select one ability to deal double damage; finishing move excluded.",
			challenge_239: "Recover 5 damage. If first turn, reshuffle and draw another card.",
			challenge_236: "If opponent does not trigger crisis, gain 2 resource bonuses.",
			challenge_237: "Immediately name an ability; if activated this turn it deals 2 additional damage.",
			challenge_215: "Using all current draw tokens allows 2 extra damage. Otherwise take 5 damage at turn end.",
			challenge_216: "After resupply, each player chooses up to 2 non-crisis tokens from opponent discard to remain discarded through next turn.",
			challenge_217: "Largest arsenal takes first-player marker; ties favor fewer character tokens.",
			challenge_218: "At combat end, take 1 damage per unused current draw token.",
			challenge_219: "Each positive recovery effect during recovery is reduced by 1, minimum zero.",
			challenge_222: "Clayface copies first activated opposing ability for free as his response.",
			challenge_226: "Clayface chooses opponent; opponent chooses to add crisis to own bag or give Clayface one Mass of Clay.",
			challenge_224: "First time opponent allocates a basic token, add matching token from own supply to current draw if available.",
			challenge_225: "At start of preparation draw 2 random tokens and choose one to discard. Crisis cannot be discarded.",
			challenge_223: "At start of preparation add 2 chosen basic tokens to bag; return them during rebalancing.",
			challenge_277: "Unused combat damage is indefensible.",
			challenge_278: "May return one basic x1 token from arsenal to supply.",
			challenge_280: "Recover 5 damage. If first turn, reshuffle and draw another card.",
			challenge_281: "Ending preparation with exactly 2 crisis grants 2 damage.",
			challenge_279: "Supergirl gains a chosen yellow/red sun. Opponents may add one basic x1 or remove one non-crisis token from arsenal.",
			challenge_273: "If Lobo collects no bounty, opponents choose for Lobo to take 5 damage or gain one extra crisis during rebalancing.",
			challenge_272: "Drawing at least 10 tokens during preparation adds extra crisis during rebalancing.",
			challenge_271: "At most 3 crest tokens can be allocated from current draw.",
			challenge_270: "First time any player removes a non-crisis token from bag, other players may also remove one.",
			challenge_269: "Tokens may only enter arsenal by resupply purchases.",
			desc: "Build a bag of powers, push your luck, and battle as DC heroes and villains.",
			rules: "Goal:\nDefeat every character on the opposing team to win. A character becomes injured when their health first reaches zero. If their next recovery fails, or their health reaches zero again after recovery, that character is defeated.\nWhen the challenge deck runs out, the team with the higher total health wins. If totals are tied, the team holding the first-player marker wins.\nSetup:\nEach player chooses a character. In team games, heroes and villains form opposing teams. Wonder Woman chooses two upgrades. The Armoury contains 60 tokens, with six revealed. Each character contributes five challenge cards.\nEach character's health limit depends on the player count:\n· In a duel, the health limit is 60.\n· With four players, the health limit is 40.\n· With six players, the health limit is 35.\nRound sequence:\nResolve Watchtower, Preparation, Combat and Power-Up in that order, followed by Rebalance. Skip Watchtower in the first round.\nFrom the second round onward, the character with the lowest health takes the first-player marker; a tie leaves the marker with its current holder. Reveal a challenge, then resolve character recovery.\nPreparation:\nDraw one token at a time from your bag. You may stop after any draw. Drawing a third Crisis token triggers a crisis: normal ability use is skipped, and damage and purchases are delayed.\nResolve all responses to a draw before drawing again. Reverse may undo the token just drawn. Draw bonuses depend on the non-Crisis tokens actually drawn this round; removing a drawn token does not remove its bonus. Stored tokens and tokens added directly to the current draw do not earn draw bonuses.\nCombat:\nAllocate all ability costs before activating abilities in your chosen order. The two symbols on a Double token may be allocated separately. For each ability, choose either its base or plus mode for the round.\n· Ability damage, unused Combat tokens and combat bonuses form the damage pool. Finishing moves resolve separately.\n· Normal damage may be defended. Indefensible damage cannot be prevented through defense, but effects that modify the entire damage pool still apply to it.\n· When Clayface is in play, resolve separate attacks and responses instead of forming a damage pool. The same ability may then be used again.\nPower-Up:\nPlayers without a crisis finish Power-Up before players in crisis. Normally, you may buy up to three distinct token types; in a crisis, you may buy up to two. Each Resource Power-Up token allows one extra purchase and reduces that purchase's cost by 1 resource.\nToken costs are as follows:\n· A Basic token costs 2 resources.\n· A Crest or Special token costs 3 resources.\n· A Double token costs 3 resources.\n· A Power-Up token costs 4 resources.\n· A Utility or Reverse token costs 5 resources.\nPurchasing or activating Critical Mass requires ten matching Combat symbols or ten matching Agility symbols.\nRebalance:\nReturn temporary tokens first. Then bring the number of Crisis tokens up to the amount determined by your non-Crisis token count:\n· Fewer than 17 non-Crisis tokens require 3 Crisis tokens.\n· Between 17 and 20 non-Crisis tokens require 4 Crisis tokens.\n· Between 21 and 24 non-Crisis tokens require 5 Crisis tokens.\n· Between 25 and 31 non-Crisis tokens require 6 Crisis tokens.\n· Between 32 and 39 non-Crisis tokens require 7 Crisis tokens.\n· At least 40 non-Crisis tokens require 8 Crisis tokens.\nFinally, return the tokens in your discard and current draw to your bag.\nTeam rules:\nTeams may split damage from their pool and recovery effects among multiple targets, share purchase resources and defend teammates. A finishing move targets only one opponent. Consult the character instructions and official FAQ for special abilities.",
			use: "Use",
			continue: "Continue",
			chooseToken: "Choose token",
			chooseCharacter: "Select character",
			chooseUpgrade: "Select upgrade",
			useTiara: "Use Tiara to keep marker",
			setContract: "Set a contract",
			usePlane: "Use Invisible Plane",
			draw: "Draw token",
			stop: "Stop drawing",
			discardToken: "Discard token",
			keepToken: "Keep token",
			reverse: "Return and redraw",
			huntCrisis: "Return 3 Hunt to remove crisis",
			blockCombat: "Block unused combat damage",
			blockPurchase: "Reduce purchases by one",
			clearAllocation: "Clear allocation",
			confirmAllocation: "Confirm allocation",
			allocateAbility: "Allocate cost",
			activateAbility: "Activate ability",
			finish: "Finish",
			dealDamage: "Deal damage",
			recover: "Recover health",
			playGadget: "Play gadget",
			preventDamage: "Prevent damage",
			useAegis: "Defer damage",
			returnToken: "Return token",
			cleanup: "Cleanup",
			buyDiscount: "Discount purchase",
			buyToken: "Buy token",
			buyCritical: "Buy Critical Mass",
			buyGadget: "Draw gadget for 2 resources",
			buyKryptonite: "Add Kryptonite for 6 resources",
			replaceToken: "Replace token",
			resolveBounty: "Resolve uncollected bounty",
			declareAbility: "Declare ability",
			replaceChallenge: "Replace challenge",
			takeGadget: "Take gadget",
			returnGadget: "Return gadget to deck bottom",
			gainSpecial: "Gain special ability",
			gainResource: "Gain resource",
			gainCompanion: "Take 2 damage; gain Loyal Companion",
			addCrisis: "Add crisis",
			giveClay: "Give Clayface Mass of Clay",
			takeFirst: "Take first player",
			returnCrisis: "Return crisis to bag",
			storeToken: "Store token",
			gainToken: "Gain token",
			chooseOpponent: "Choose opponent",
			peekChallenge: "Discard Focus to peek at next challenge",
			stealPower: "Remove Mechano-Men to take Power-Up",
			speedAttack: "Discard 3 Speedforce to deal 4 damage",
			activateCritical: "Activate Critical Mass",
			errAction: "That action is no longer available. Choose again from the current position.",
			logDraw: "Drew token",
			logHeal: "Recovered {{n}} health",
			logRegenerate: "Triggered Czarnian Regeneration",
			logDamage: "Took {{n}} damage",
			logDefeated: "Was defeated",
			logInjured: "Became injured",
			logCrisis: "Triggered a crisis",
			logActivate: "Activated {{ability}}",
			upgradeAegis: "Aegis of Athena",
			upgradeSword: "Amazonian Sword",
			upgradeTraining: "Amazonian Combat Training",
			upgradePlane: "Invisible Plane",
			upgradeTiara: "Tiara of Themyscira",
			gadgetBatarang: "Batarang",
			gadgetSmoke: "Smoke Pellet",
			gadgetContingency: "Contingency",
			gadgetGrapple: "Grapple Gun",
			gadgetPulse: "Electro-pulse",
			duel: "Duel",
			teams: "Heroes vs villains: 2v2",
			league: "Heroes vs villains: 3v3",
			optMode: "Battle format",
			optExpansion: "Supergirl & Lobo expansion",
			round: "Turn {{n}}",
			health: "Health",
			resources: "Resources",
			bag: "Arsenal",
			drawArea: "Current draw",
			discard: "Discard",
			supply: "Character supply",
			armoury: "Hall of Justice Armoury",
			challenge: "Current challenge",
			remaining: "{{n}} challenges left",
			first: "First player",
			crisis: "Crisis",
			injured: "Injured",
			defeated: "Defeated",
			waiting: "Waiting for {{name}}",
			resolving: "Resolving",
			selectPrompt: "Choose your character",
			actions: "Available actions",
			abilities: "Character abilities",
			specials: "Special abilities",
			bonus: "Draw bonuses",
			damagePool: "Damage pool",
			finisher: "Finishing move",
			normalDamage: "Normal damage",
			indefensible: "Indefensible damage",
			heal: "Recover health",
			cost: "Cost",
			target: "Target",
			payment: "Allocate tokens",
			autoFill: "Fill payment",
			confirm: "Confirm",
			cancel: "Cancel",
			log: "Battle log",
			viewCharacter: "Inspect character",
			victory: "Victory",
			finalHealth: "Health remaining",
			reviewTable: "Review table",
			playAgain: "Play again",
			backLobby: "Back to lobby",
			heroTeam: "Heroes",
			villainTeam: "Villains",
			watchtower: "Watchtower",
			preparation: "Preparation",
			combat: "Combat",
			powerUp: "Power-Up",
			select: "Character selection",
			done: "Battle ended",
			abilityEffect: "Damage {{damage}} · Heal {{heal}} · Resources {{resource}}",
			paymentSlot: "Cost slot {{n}}",
			tokenLabel: "{{name}} · {{kind}}",
			basic: "Basic",
			double: "Double",
			power: "Power-Up",
			critical: "Critical Mass",
			noTokens: "No tokens",
			allocationReady: "Allocation ready",
			needPayment: "Choose tokens to pay",
			partialPayment: "Payment incomplete",
			details: "Details",
			abilityDynamic: "Resolve the ability condition",
			token_C: "Combat",
			token_R: "Resource",
			token_A: "Agility",
			token_F: "Focus",
			token_E: "Crest",
			token_X: "Crisis",
			token_U: "Utility",
			token_V: "Reverse",
			token_K: "Kryptonite",
			token_S: "Yellow Sun",
			token_W: "Speedforce",
			token_B: "Apokoliptian Shield",
			token_D: "Critical Mass Discount",
			token_L: "Relic",
			token_H: "Hunt",
			token_M: "Mass of Clay",
			token_I: "Structural Integrity",
			token_Y: "Yellow Sun",
			token_Z: "Red Sun",
			token_O: "Bounty"
		}
	}
};
//#endregion
export { Et as default };
