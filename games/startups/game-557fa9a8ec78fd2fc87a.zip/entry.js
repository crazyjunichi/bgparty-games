import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconLog as u } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { Texture as f } from "@bgparty/sdk/texture";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { LogSheet as m } from "@bgparty/sdk/ui/log-sheet";
import { PhaseBanner as h } from "@bgparty/sdk/ui/phase-banner";
import { seatName as g } from "@bgparty/sdk/ui/player-strip";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { Floater as b, FlySprite as x, PulseBox as S } from "@bgparty/sdk/fx/primitives";
import { Confetti as C } from "@bgparty/sdk/ui/confetti";
//#region src/games/startups/companies.ts
var w = [
	{
		id: "giraffe",
		total: 5,
		emoji: "🦒",
		color: "#d97706",
		nameKey: "games.startups.co.giraffe",
		shortKey: "games.startups.coShort.giraffe"
	},
	{
		id: "bowwow",
		total: 6,
		emoji: "🐶",
		color: "#2563eb",
		nameKey: "games.startups.co.bowwow",
		shortKey: "games.startups.coShort.bowwow"
	},
	{
		id: "octo",
		total: 7,
		emoji: "🐙",
		color: "#dc2626",
		nameKey: "games.startups.co.octo",
		shortKey: "games.startups.coShort.octo"
	},
	{
		id: "flamingo",
		total: 8,
		emoji: "🦩",
		color: "#ec4899",
		nameKey: "games.startups.co.flamingo",
		shortKey: "games.startups.coShort.flamingo"
	},
	{
		id: "hippo",
		total: 9,
		emoji: "🦛",
		color: "#16a34a",
		nameKey: "games.startups.co.hippo",
		shortKey: "games.startups.coShort.hippo"
	},
	{
		id: "elephant",
		total: 10,
		emoji: "🐘",
		color: "#7c3aed",
		nameKey: "games.startups.co.elephant",
		shortKey: "games.startups.coShort.elephant"
	}
], T = w.flatMap((e, t) => Array(e.total).fill(t));
function E(e) {
	return T[e];
}
function D(e) {
	return w[T[e]];
}
//#endregion
//#region src/games/startups/meta.ts
var O = {
	id: "startups",
	tier: "released",
	mechanics: ["set-collection", "stock-holding"],
	interactionTags: [],
	nameKey: "games.startups.name",
	descKey: "games.startups.desc",
	rulesKey: "games.startups.rules",
	icon: "🦄",
	iconImg: "games/startups.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/startups/en.pdf" },
	minPlayers: 3,
	maxPlayers: 7,
	bestPlayers: [4],
	accent: "#1d4ed8",
	releasedAt: "2026-09-15",
	search: {
		py: "xin chuang gong si",
		init: "xcgs"
	},
	hotseat: "cover"
}, k = t.int().min(0).max(44), A = t.string(), j = t.discriminatedUnion("type", [t.object({
	type: t.literal("pick"),
	source: t.enum(["deck", "market"]),
	card: k.optional()
}), t.object({
	type: t.literal("play"),
	card: k,
	dest: t.enum(["tableau", "market"])
})]), M = t.object({
	liquid: t.int().nonnegative(),
	banked: t.int().nonnegative(),
	debt: t.int().nonnegative()
}), ee = t.object({
	company: t.string(),
	winner: A.nullable(),
	payments: t.array(t.object({
		from: A,
		shares: t.int().positive()
	})),
	gained: t.int().nonnegative()
}), te = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("draw"),
		rid: A,
		tax: t.int().nonnegative()
	}),
	t.object({
		k: t.literal("take"),
		rid: A,
		company: t.string(),
		coins: t.int().nonnegative()
	}),
	t.object({
		k: t.literal("playT"),
		rid: A,
		company: t.string()
	}),
	t.object({
		k: t.literal("playM"),
		rid: A,
		company: t.string()
	}),
	t.object({
		k: t.literal("chip"),
		company: t.string(),
		to: A
	}),
	t.object({
		k: t.literal("payout"),
		company: t.string(),
		winner: A,
		gained: t.int().nonnegative()
	})
]), ne = t.object({
	deckCount: t.int().nonnegative(),
	turnIdx: t.int().nonnegative(),
	phase: t.enum([
		"pick",
		"play",
		"done"
	]),
	players: t.array(t.object({
		rid: A,
		tableau: t.array(k),
		money: M
	})),
	market: t.array(t.object({
		card: k,
		coins: t.int().nonnegative()
	})),
	chips: t.record(t.string(), A.nullable()),
	pickedCard: k.nullable(),
	payouts: t.array(ee).nullable(),
	log: t.array(te)
}), N = t.object({ hand: t.array(k) }), P = 60;
function F(e, t) {
	e.log.push(t), e.log.length > P && e.log.splice(0, e.log.length - P);
}
function I(e) {
	return e.liquid + 3 * e.banked - e.debt;
}
function L(e, t) {
	return e.market.filter((n) => e.chips[D(n.card).id] !== t).length;
}
function re(t, n, r) {
	let i = Array.from({ length: 45 }, (e, t) => t), a = 0;
	for (let t = i.length - 1; t > 0; --t) {
		let n = e(r, a, t + 1);
		a += 1, [i[t], i[n]] = [i[n], i[t]];
	}
	let o = 5, s = {}, c = {}, l = {};
	for (let e of n) s[e] = i.slice(o, o + 3), o += 3, c[e] = [], l[e] = {
		liquid: 10,
		banked: 0,
		debt: 0
	};
	let u = {};
	for (let e of w) u[e.id] = null;
	return {
		state: {
			players: n,
			turnIdx: e(r, a, n.length),
			phase: "pick",
			deck: i.slice(o),
			hands: s,
			tableaus: c,
			market: [],
			chips: u,
			money: l,
			pickedCard: null,
			payouts: null,
			log: []
		},
		fx: n.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: { count: 3 },
			for: [e],
			secret: { cards: s[e] },
			...t > 0 ? { with: !0 } : {}
		}))
	};
}
function R(e, t) {
	let n = null, r = 0, i = !1;
	for (let a of e.players) {
		let o = e.tableaus[a].filter((e) => D(e).id === t).length;
		o > r ? (n = a, r = o, i = !1) : o === r && (i = !0);
	}
	let a = e.chips[t];
	return i || !n || n === a ? null : (e.chips[t] = n, F(e, {
		k: "chip",
		company: t,
		to: n
	}), {
		kind: "chip",
		data: {
			company: t,
			from: a,
			to: n
		}
	});
}
function z(e) {
	for (let t of e.players) e.tableaus[t].push(...e.hands[t]), e.hands[t] = [];
	let t = [], n = [];
	for (let r of w) {
		let i = (t) => e.tableaus[t].filter((e) => D(e).id === r.id).length, a = null, o = 0, s = !1;
		for (let t of e.players) {
			let e = i(t);
			e > o ? (a = t, o = e, s = !1) : e === o && (s = !0);
		}
		s && (a = null);
		let c = a ? e.players.filter((e) => e !== a && i(e) > 0).map((e) => ({
			from: e,
			shares: i(e)
		})) : [], l = 0;
		if (a && c.length > 0) {
			for (let t of c) {
				let n = Math.min(e.money[t.from].liquid, t.shares);
				e.money[t.from].liquid -= n, e.money[t.from].debt += t.shares - n, l += t.shares * 3;
			}
			e.money[a].banked += l, F(e, {
				k: "payout",
				company: r.id,
				winner: a,
				gained: l
			}), n.push({
				kind: "payout",
				data: {
					company: r.id,
					winner: a,
					gained: l,
					from: c.map((e) => e.from)
				}
			});
		}
		t.push({
			company: r.id,
			winner: a,
			payments: c,
			gained: l
		});
	}
	return e.payouts = t, e.phase = "done", n;
}
function B(e, t, n) {
	if (e.phase === "done" || e.players[e.turnIdx] !== n.by) return { code: "games.startups.errNotYourTurn" };
	if (t.type === "pick") {
		if (e.phase !== "pick") return { code: "games.startups.errNotYourTurn" };
		if (t.source === "deck") {
			let t = L(e, n.by);
			if (e.money[n.by].liquid < t) return { code: "games.startups.errCantAfford" };
			let r = structuredClone(e), i = [];
			for (let e of r.market) r.chips[D(e.card).id] !== n.by && (e.coins += 1, i.push(e.card));
			r.money[n.by].liquid -= t;
			let a = r.deck.pop();
			r.hands[n.by].push(a), r.phase = "play", F(r, {
				k: "draw",
				rid: n.by,
				tax: t
			});
			let o = [];
			return i.length > 0 && o.push({
				kind: "tax",
				rid: n.by,
				data: { cards: i }
			}), o.push({
				kind: "draw",
				rid: n.by,
				for: [n.by],
				secret: { card: a }
			}), {
				state: r,
				fx: o
			};
		}
		let r = e.market.find((e) => e.card === t.card);
		if (!r) return { code: "games.startups.errBadCard" };
		if (e.chips[D(r.card).id] === n.by) return { code: "games.startups.errBlocked" };
		let i = structuredClone(e);
		return i.market = i.market.filter((e) => e.card !== r.card), i.money[n.by].liquid += r.coins, i.hands[n.by].push(r.card), i.pickedCard = r.card, i.phase = "play", F(i, {
			k: "take",
			rid: n.by,
			company: D(r.card).id,
			coins: r.coins
		}), {
			state: i,
			fx: [{
				kind: "take",
				rid: n.by,
				data: {
					card: r.card,
					coins: r.coins
				}
			}]
		};
	}
	if (e.phase !== "play") return { code: "games.startups.errNotYourTurn" };
	if (!e.hands[n.by]?.includes(t.card)) return { code: "games.startups.errBadCard" };
	let r = D(t.card).id;
	if (t.dest === "market" && e.pickedCard !== null && D(e.pickedCard).id === r) return { code: "games.startups.errBadPlay" };
	let i = structuredClone(e);
	i.hands[n.by] = i.hands[n.by].filter((e) => e !== t.card);
	let a = [];
	if (t.dest === "tableau") {
		i.tableaus[n.by].push(t.card), F(i, {
			k: "playT",
			rid: n.by,
			company: r
		}), a.push({
			kind: "playTableau",
			rid: n.by,
			data: { card: t.card }
		});
		let e = R(i, r);
		e && a.push(e);
	} else i.market.push({
		card: t.card,
		coins: 0
	}), F(i, {
		k: "playM",
		rid: n.by,
		company: r
	}), a.push({
		kind: "playMarket",
		rid: n.by,
		data: { card: t.card }
	});
	return i.pickedCard = null, i.deck.length === 0 ? (a.push(...z(i)), {
		state: i,
		fx: a
	}) : (i.turnIdx = (i.turnIdx + 1) % i.players.length, i.phase = "pick", {
		state: i,
		fx: a
	});
}
function ie(e, t) {
	return {
		public: {
			deckCount: e.deck.length,
			turnIdx: e.turnIdx,
			phase: e.phase,
			players: e.players.map((t) => ({
				rid: t,
				tableau: e.tableaus[t],
				money: { ...e.money[t] }
			})),
			market: e.market.map((e) => ({ ...e })),
			chips: { ...e.chips },
			pickedCard: e.pickedCard,
			payouts: e.payouts,
			log: e.log.map((e) => ({ ...e }))
		},
		private: { hand: e.hands[t] ?? [] }
	};
}
function ae(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => I(e.money[n]) - I(e.money[t])), n = I(e.money[t[0]]), r = {};
	for (let t of e.players) r[t] = I(e.money[t]);
	return {
		phase: "done",
		winner: t.filter((t) => I(e.money[t]) === n),
		ranking: t,
		scores: r
	};
}
var oe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: O,
	schemas: {
		action: j,
		publicView: ne,
		privateView: N
	},
	setup: re,
	reduce: B,
	viewFor: ie,
	status: ae
};
//#endregion
//#region src/games/startups/rocket-icon.tsx
function se({ size: e = 16, color: t = "var(--color-ink)", className: n }) {
	return /* @__PURE__ */ y("svg", {
		width: e,
		height: e,
		viewBox: "0 0 64 64",
		fill: "none",
		"aria-hidden": !0,
		className: n,
		children: [
			/* @__PURE__ */ v("path", {
				fillRule: "evenodd",
				fill: t,
				d: "M32 5 C40.5 13.5 42.5 23 42.5 33 L21.5 33 C21.5 23 23.5 13.5 32 5 Z\n           M27.5 23 a4.5 4.5 0 1 0 9 0 a4.5 4.5 0 1 0 -9 0 Z"
			}),
			/* @__PURE__ */ v("path", {
				fill: t,
				d: "M21.5 28 C15.5 32 12.5 38.5 11.5 45.5 L21.5 41 Z M42.5 28 C48.5 32 51.5 38.5 52.5 45.5 L42.5 41 Z"
			}),
			/* @__PURE__ */ v("path", {
				fill: t,
				d: "M28 37 L32 50 L36 37 Z"
			})
		]
	});
}
//#endregion
//#region src/games/startups/stock-card.tsx
function V({ co: e, className: t = "" }) {
	let n;
	switch (e.id) {
		case "giraffe":
			n = /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("rect", {
					x: "8",
					y: "21",
					width: "5",
					height: "12",
					rx: "1"
				}),
				/* @__PURE__ */ v("rect", {
					x: "17",
					y: "13",
					width: "5",
					height: "20",
					rx: "1"
				}),
				/* @__PURE__ */ v("rect", {
					x: "26",
					y: "7",
					width: "5",
					height: "26",
					rx: "1"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "10.5",
					cy: "17",
					r: "2.5"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "19.5",
					cy: "9",
					r: "2.5"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "28.5",
					cy: "4",
					r: "2.5"
				})
			] });
			break;
		case "bowwow":
			n = /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("circle", {
					cx: "10",
					cy: "11",
					r: "3.2"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "18",
					cy: "7",
					r: "3.2"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "27",
					cy: "9",
					r: "3.2"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "32",
					cy: "16",
					r: "3.2"
				}),
				/* @__PURE__ */ v("path", { d: "M9 27 Q12 19 19 20 Q26 18 31 27 Q33 33 27 34 H13 Q7 34 9 27 Z" })
			] });
			break;
		case "octo":
			n = /* @__PURE__ */ y(_, { children: [Array.from({ length: 8 }, (e, t) => {
				let n = t * Math.PI / 4;
				return /* @__PURE__ */ v("circle", {
					cx: 20 + 13 * Math.cos(n),
					cy: 20 + 13 * Math.sin(n),
					r: "2.8"
				}, t);
			}), /* @__PURE__ */ v("circle", {
				cx: "20",
				cy: "20",
				r: "7.2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "3"
			})] });
			break;
		case "flamingo":
			n = /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("path", { d: "M9 27 Q25 4 34 8 Q28 10 20 20 L32 19 Q23 31 9 32 Z" }), /* @__PURE__ */ v("path", {
				d: "M17 32 H24",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.5"
			})] });
			break;
		case "hippo":
			n = /* @__PURE__ */ v("path", { d: "M23 5 L9 21 H18 L14 35 L32 16 H23 Z" });
			break;
		default: n = /* @__PURE__ */ y(_, { children: [
			/* @__PURE__ */ v("circle", {
				cx: "20",
				cy: "20",
				r: "6"
			}),
			/* @__PURE__ */ v("ellipse", {
				cx: "20",
				cy: "20",
				rx: "16",
				ry: "8",
				transform: "rotate(-28 20 20)",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ v("circle", {
				cx: "31",
				cy: "8",
				r: "2.7"
			})
		] });
	}
	return /* @__PURE__ */ v("span", {
		"aria-hidden": !0,
		className: `su-mark ${t}`,
		style: { backgroundColor: e.color },
		children: /* @__PURE__ */ v("svg", {
			viewBox: "0 0 40 40",
			fill: "currentColor",
			className: "size-full",
			focusable: "false",
			children: n
		})
	});
}
function ce(e) {
	return e ? {
		"--su-card-w": `${e.width}px`,
		"--su-card-h": `${e.height}px`
	} : {};
}
function H({ card: e, size: t = "hand", dimensions: n }) {
	let r = l(), i = D(e);
	return /* @__PURE__ */ y("span", {
		className: `su-stock su-stock--${t}`,
		style: {
			"--su-brand": i.color,
			...ce(n)
		},
		children: [
			/* @__PURE__ */ v("span", {
				"aria-hidden": !0,
				className: "su-stock-stripe"
			}),
			/* @__PURE__ */ v(V, {
				co: i,
				className: "su-stock-mark"
			}),
			/* @__PURE__ */ y("span", {
				className: "su-stock-footer",
				children: [/* @__PURE__ */ v("span", {
					className: "su-stock-name",
					children: r(i.shortKey)
				}), /* @__PURE__ */ v("span", {
					className: "su-stock-total font-mono tabular-nums",
					children: i.total
				})]
			})
		]
	});
}
function U({ count: e, size: t = "hand", dimensions: n }) {
	return /* @__PURE__ */ y("span", {
		className: `su-stock-back su-stock-back--${t}`,
		style: {
			"--su-brand": O.accent,
			...ce(n)
		},
		children: [
			/* @__PURE__ */ v("span", {
				"aria-hidden": !0,
				className: "su-stock-back-stripes"
			}),
			/* @__PURE__ */ v(se, {
				size: t === "market" ? 29 : 34,
				color: "var(--color-surface)"
			}),
			e !== void 0 && /* @__PURE__ */ v("span", {
				className: "su-stock-back-count font-display tabular-nums",
				children: e
			})
		]
	});
}
//#endregion
//#region src/games/startups/view-player.tsx
function le(e) {
	return /* @__PURE__ */ v(de, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ue(e, t) {
	return e.market.filter((n) => e.chips[D(n.card).id] !== t).length;
}
function de({ pub: e, priv: t, members: r, myRid: i, send: o }) {
	let s = l(), d = c((e) => e.locale), _ = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? g(t, d) : e;
	}, b = e.players[e.turnIdx]?.rid ?? "", x = e.phase !== "done" && b === i, S = x && e.phase === "pick", C = x && e.phase === "play", T = ue(e, i), E = e.players.find((e) => e.rid === i)?.money.liquid ?? 0, k = S && E >= T, [A, j] = a(null), M = `${e.phase}|${e.turnIdx}|${e.pickedCard}`, [ee, te] = a(M);
	ee !== M && (te(M), j(null));
	let [ne, N] = a(!1), [P, F] = a(null);
	n(() => {
		if (!P) return;
		let e = window.setTimeout(() => F(null), 2500);
		return () => window.clearTimeout(e);
	}, [P]);
	let I = A === null ? null : D(A).id, L = e.pickedCard === null ? null : D(e.pickedCard).id, re = I !== null && I === L, R = "info", z = s("games.startups.waitStep", { name: _(b) });
	S ? (R = "accent", z = s("games.startups.pickStep")) : C && (R = "accent", z = s("games.startups.playStep"));
	let B = (e) => s(w.find((t) => t.id === e)?.nameKey ?? "games.startups.name");
	return /* @__PURE__ */ y("div", {
		className: "relative h-full min-h-0",
		children: [/* @__PURE__ */ v(p, {
			adaptive: !0,
			className: "su-screen",
			scroll: !1,
			actionsHeight: "su-actions",
			banner: /* @__PURE__ */ y("div", {
				className: "su-top",
				children: [/* @__PURE__ */ v(h, {
					tone: R,
					text: z,
					accent: O.accent
				}), /* @__PURE__ */ v(fe, {
					pub: e,
					members: r,
					myRid: i,
					turnRid: b
				})]
			}),
			actions: /* @__PURE__ */ v(_e, {
				hand: t?.hand,
				playing: C,
				selected: A,
				onSelect: (e) => j(A === e ? null : e),
				onCancel: () => j(null)
			}),
			children: /* @__PURE__ */ y("div", {
				className: "su-table",
				children: [
					/* @__PURE__ */ v(f, {
						kind: "sheen",
						base: "var(--color-su-mat)",
						className: "absolute inset-0 size-full"
					}),
					/* @__PURE__ */ y("div", {
						className: "su-table-inner",
						children: [/* @__PURE__ */ v(me, {
							pub: e,
							myRid: i,
							picking: S,
							playing: C,
							canDraw: k,
							tax: T,
							selected: A,
							marketBlocked: re,
							onDraw: () => o({
								type: "pick",
								source: "deck"
							}),
							onTake: (e) => o({
								type: "pick",
								source: "market",
								card: e
							}),
							onPlayMarket: () => {
								A !== null && o({
									type: "play",
									card: A,
									dest: "market"
								});
							},
							onBlocked: F
						}), /* @__PURE__ */ y("div", {
							className: "su-companies",
							children: [/* @__PURE__ */ y("div", {
								className: "su-company-heading",
								children: [/* @__PURE__ */ v("span", { children: s("games.startups.company") }), /* @__PURE__ */ v("span", { children: s("games.startups.sharesShort") })]
							}), /* @__PURE__ */ v("div", {
								className: "su-company-grid",
								children: w.map((t) => /* @__PURE__ */ v(ge, {
									co: t,
									pub: e,
									members: r,
									selected: C && I === t.id,
									onInvest: () => {
										A !== null && o({
											type: "play",
											card: A,
											dest: "tableau"
										});
									}
								}, t.id))
							})]
						})]
					}),
					/* @__PURE__ */ v("div", {
						className: "su-table-footer",
						"aria-hidden": !0,
						children: /* @__PURE__ */ v("span", {
							className: "su-table-stamp",
							children: "STARTUPS"
						})
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "su-history",
						"aria-label": s("games.startups.logAria"),
						onClick: () => N(!0),
						children: /* @__PURE__ */ v(u, {
							size: 19,
							"aria-hidden": !0
						})
					}),
					P && /* @__PURE__ */ v("div", {
						className: "su-rule-hint",
						role: "status",
						children: P
					})
				]
			})
		}), ne && /* @__PURE__ */ v(m, {
			log: e.log,
			line: (e) => {
				switch (e.k) {
					case "draw": return e.tax > 0 ? s("games.startups.logDrawTax", {
						name: _(e.rid),
						n: e.tax
					}) : s("games.startups.logDraw", { name: _(e.rid) });
					case "take": return e.coins > 0 ? s("games.startups.logTakeCoins", {
						name: _(e.rid),
						co: B(e.company),
						n: e.coins
					}) : s("games.startups.logTake", {
						name: _(e.rid),
						co: B(e.company)
					});
					case "playT": return s("games.startups.logPlayT", {
						name: _(e.rid),
						co: B(e.company)
					});
					case "playM": return s("games.startups.logPlayM", {
						name: _(e.rid),
						co: B(e.company)
					});
					case "chip": return s("games.startups.logChip", {
						name: _(e.to),
						co: B(e.company)
					});
					case "payout": return s("games.startups.logPayout", {
						co: B(e.company),
						name: _(e.winner),
						n: e.gained
					});
				}
			},
			onClose: () => N(!1)
		})]
	});
}
function fe({ pub: e, members: t, myRid: n, turnRid: r }) {
	let i = e.players.map((e) => t.find((t) => t.rid === e.rid)).filter((e) => !!e);
	return /* @__PURE__ */ v("div", {
		className: "su-seats",
		children: /* @__PURE__ */ v("ul", {
			className: "su-seat-list",
			style: { "--su-seats": i.length },
			children: i.map((t) => {
				let i = e.players.find((e) => e.rid === t.rid);
				if (!i) return null;
				let a = e.players.findIndex((e) => e.rid === t.rid) + 1;
				return /* @__PURE__ */ v(pe, {
					member: t,
					seat: a,
					cash: i.money.liquid,
					mine: t.rid === n,
					turn: t.rid === r
				}, t.rid);
			})
		})
	});
}
function pe({ member: e, seat: t, cash: n, mine: r, turn: i }) {
	let a = l(), u = c((e) => e.locale), { ref: f } = o(`seat:${e.rid}`), p = d[e.colorIndex % d.length], m = g(e, u);
	return /* @__PURE__ */ y("li", {
		className: `su-seat ${i ? "su-seat--turn" : ""} ${e.online ? "" : "su-seat--offline"}`,
		"aria-label": `${t}. ${m}，${a("games.startups.cash")} ${n}`,
		children: [
			/* @__PURE__ */ v("span", {
				ref: f,
				className: "su-seat-number",
				style: { "--su-player": p.hex },
				children: t
			}),
			/* @__PURE__ */ y("span", {
				className: "su-seat-name",
				title: m,
				children: [m, r ? /* @__PURE__ */ y("span", {
					"aria-label": a("lobby.you"),
					children: [" · ", a("lobby.you")]
				}) : null]
			}),
			/* @__PURE__ */ y("span", {
				className: "su-seat-cash",
				children: [/* @__PURE__ */ v("span", {
					className: "su-coin",
					"aria-hidden": !0,
					children: "$"
				}), /* @__PURE__ */ v(s, {
					value: n,
					className: "font-mono tabular-nums"
				})]
			})
		]
	});
}
function me({ pub: e, myRid: t, picking: n, playing: r, canDraw: i, tax: a, selected: s, marketBlocked: c, onDraw: u, onTake: d, onPlayMarket: f, onBlocked: p }) {
	let m = l(), { ref: h } = o("deck"), { ref: g } = o("market"), { ref: _ } = o("market-card-size"), b = [...e.market].sort((e, t) => E(e.card) - E(t.card)), x = r && s !== null && !c;
	return /* @__PURE__ */ y("div", {
		className: "su-trading",
		children: [
			/* @__PURE__ */ v("span", {
				ref: _,
				className: "su-market-geometry",
				"aria-hidden": !0
			}),
			/* @__PURE__ */ y("div", {
				className: "su-pile",
				children: [/* @__PURE__ */ v("span", {
					className: "su-section-label",
					children: m("games.startups.deck")
				}), /* @__PURE__ */ y("div", {
					ref: h,
					className: "su-deck-wrap",
					children: [
						/* @__PURE__ */ v("button", {
							type: "button",
							className: "su-deck-button",
							disabled: !n,
							"aria-disabled": n && !i,
							"aria-label": m(i ? "games.startups.drawDeck" : n ? "games.startups.errCantAfford" : "games.startups.deck"),
							onClick: () => {
								i ? u() : n && p(m("games.startups.errCantAfford"));
							},
							children: /* @__PURE__ */ v(U, { count: e.deckCount })
						}),
						a > 0 && /* @__PURE__ */ y("span", {
							className: "su-deck-tax",
							"aria-label": m("games.startups.taxNote", { n: a }),
							children: ["−", a]
						}),
						n && !i && /* @__PURE__ */ v("span", {
							className: "su-deck-lock",
							"aria-hidden": !0,
							children: "×"
						})
					]
				})]
			}),
			/* @__PURE__ */ y("div", {
				className: "su-market-area",
				children: [/* @__PURE__ */ v("span", {
					className: "su-section-label",
					children: m("games.startups.market")
				}), /* @__PURE__ */ v("div", {
					ref: g,
					className: "su-market-scroll",
					"aria-label": m("games.startups.market"),
					children: /* @__PURE__ */ y("div", {
						className: "su-market-cards",
						children: [b.length === 0 && /* @__PURE__ */ v("span", {
							className: "su-market-empty",
							"aria-hidden": !0,
							children: "—"
						}), b.map((r) => {
							let i = n && e.chips[D(r.card).id] === t;
							return /* @__PURE__ */ v(he, {
								card: r.card,
								coins: r.coins,
								picking: n,
								blocked: i,
								onTake: () => d(r.card),
								onBlocked: () => p(m("games.startups.marketLocked"))
							}, r.card);
						})]
					})
				})]
			}),
			/* @__PURE__ */ y("button", {
				type: "button",
				disabled: !r || s === null,
				"aria-disabled": c,
				className: `su-market-drop ${x ? "su-market-drop--active" : ""} ${c && r && s !== null ? "su-market-drop--blocked" : ""}`,
				"aria-label": m(c ? "games.startups.marketDropLocked" : "games.startups.destMarket"),
				onClick: () => {
					x ? f() : c && p(m("games.startups.marketDropLocked"));
				},
				children: [/* @__PURE__ */ v("span", {
					className: "su-market-drop-symbol",
					"aria-hidden": !0,
					children: c && r && s !== null ? "×" : "→"
				}), /* @__PURE__ */ v("span", { children: m("games.startups.destMarket") })]
			})
		]
	});
}
function he({ card: e, coins: t, picking: n, blocked: r, onTake: i, onBlocked: a }) {
	let s = l(), { ref: c, hidden: u } = o(`mkt:${e}`), d = D(e);
	return /* @__PURE__ */ y("span", {
		ref: c,
		className: `su-market-card ${r ? "su-market-card--blocked" : ""}`,
		style: { visibility: u ? "hidden" : void 0 },
		children: [
			/* @__PURE__ */ v("button", {
				type: "button",
				className: "su-market-button",
				disabled: !n,
				"aria-disabled": r,
				"aria-label": r ? `${s("games.startups.takeAria", { name: s(d.nameKey) })}：${s("games.startups.marketLocked")}` : s("games.startups.takeAria", { name: s(d.nameKey) }),
				onClick: () => {
					n && r ? a() : n && i();
				},
				children: /* @__PURE__ */ v(H, {
					card: e,
					size: "market"
				})
			}),
			t > 0 && /* @__PURE__ */ v("span", {
				className: "su-market-coins",
				"aria-label": s("games.startups.marketCoins", { n: t }),
				children: t
			}),
			r && /* @__PURE__ */ v("span", {
				className: "su-market-lock",
				"aria-hidden": !0,
				children: "×"
			})
		]
	});
}
function ge({ co: e, pub: t, members: n, selected: r, onInvest: i }) {
	let a = l(), s = c((e) => e.locale), { ref: u } = o(`co:${e.id}`), f = t.players.map((t, n) => ({
		p: t,
		seat: n + 1,
		n: t.tableau.filter((t) => D(t).id === e.id).length
	})).filter(({ n: e }) => e > 0), p = f.reduce((e, t) => e + t.n, 0), m = e.total - p - t.market.filter((t) => D(t.card).id === e.id).length, h = t.chips[e.id], _ = t.players.findIndex((e) => e.rid === h) + 1, b = n.find((e) => e.rid === h), x = b ? d[b.colorIndex % d.length].hex : null;
	return /* @__PURE__ */ y("div", {
		ref: u,
		className: `su-company ${r ? "su-company--target" : ""}`,
		role: "group",
		"aria-label": a("games.startups.companySummary", {
			name: a(e.nameKey),
			held: p,
			total: e.total,
			unseen: m
		}),
		style: { "--su-brand": e.color },
		children: [
			/* @__PURE__ */ y("div", {
				className: "su-company-main",
				children: [/* @__PURE__ */ v(V, { co: e }), /* @__PURE__ */ y("div", {
					className: "su-company-data",
					children: [/* @__PURE__ */ v("span", {
						className: "su-company-name",
						children: a(e.shortKey)
					}), /* @__PURE__ */ y("span", {
						className: "su-company-figures",
						children: [
							/* @__PURE__ */ v("span", {
								className: "su-company-held font-mono tabular-nums",
								children: p
							}),
							/* @__PURE__ */ y("span", {
								className: "su-company-total font-mono tabular-nums",
								children: ["/", e.total]
							}),
							/* @__PURE__ */ v("span", {
								className: "su-company-unseen",
								children: a("games.startups.unseenShort", { n: m })
							})
						]
					})]
				})]
			}),
			b && x && _ > 0 && /* @__PURE__ */ v("span", {
				className: "su-chip",
				role: "img",
				"aria-label": a("games.startups.monopolyHolder", { name: g(b, s) }),
				children: /* @__PURE__ */ v("span", {
					style: { "--su-player": x },
					children: _
				})
			}),
			/* @__PURE__ */ y("div", {
				className: "su-holders",
				children: [f.length === 0 && /* @__PURE__ */ y("span", {
					className: "su-empty-stock",
					"aria-hidden": !0,
					children: [
						/* @__PURE__ */ v("i", {}),
						/* @__PURE__ */ v("i", {}),
						/* @__PURE__ */ v("i", {})
					]
				}), f.map(({ p: e, seat: t, n: r }) => {
					let i = n.find((t) => t.rid === e.rid), o = d[(i?.colorIndex ?? 0) % d.length];
					return /* @__PURE__ */ y("span", {
						className: "su-holder",
						"aria-label": a("games.startups.seatShares", {
							name: i ? g(i, s) : e.rid,
							n: r
						}),
						children: [/* @__PURE__ */ v("span", {
							className: "su-holder-seat",
							style: { "--su-player": o.hex },
							children: t
						}), /* @__PURE__ */ y("span", {
							className: "font-mono tabular-nums",
							children: ["×", r]
						})]
					}, e.rid);
				})]
			}),
			r && /* @__PURE__ */ v("button", {
				type: "button",
				className: "su-invest-hit",
				"aria-label": a("games.startups.hintPlayTableau", { co: a(e.nameKey) }),
				onClick: i,
				children: /* @__PURE__ */ v("span", { children: a("games.startups.destTableau") })
			})
		]
	});
}
function _e({ hand: e, playing: t, selected: n, onSelect: r, onCancel: i }) {
	let a = l(), { ref: s } = o("hand-card-size");
	return /* @__PURE__ */ y("div", {
		className: "su-hand-rail",
		style: { "--su-hand-count": Math.max(1, e?.length ?? 0) },
		children: [
			/* @__PURE__ */ v("span", {
				className: "su-hand-label",
				children: a("games.startups.hand")
			}),
			/* @__PURE__ */ y("div", {
				className: "su-hand-list",
				children: [/* @__PURE__ */ v("span", {
					ref: s,
					className: "su-hand-geometry",
					"aria-hidden": !0
				}), e?.map((e) => /* @__PURE__ */ v(ve, {
					card: e,
					playing: t,
					selected: n === e,
					onSelect: () => r(e)
				}, e))]
			}),
			n !== null && /* @__PURE__ */ v("button", {
				type: "button",
				className: "su-hand-cancel",
				"aria-label": a("games.startups.cancelSelection"),
				onClick: i,
				children: "×"
			})
		]
	});
}
function ve({ card: e, playing: t, selected: n, onSelect: r }) {
	let i = l(), { ref: a, hidden: s } = o(`card:${e}`), c = D(e);
	return /* @__PURE__ */ v("span", {
		ref: a,
		className: "su-hand-anchor",
		style: { visibility: s ? "hidden" : void 0 },
		children: /* @__PURE__ */ v("button", {
			type: "button",
			className: `su-hand-button ${n ? "su-hand-button--selected" : ""}`,
			disabled: !t,
			"aria-pressed": n,
			"aria-label": n ? i("games.startups.selectedCard", { name: i(c.nameKey) }) : i("games.startups.cardAria", {
				name: i(c.nameKey),
				total: c.total
			}),
			onClick: r,
			children: /* @__PURE__ */ v(H, { card: e })
		})
	});
}
//#endregion
//#region src/games/startups/bot.ts
function W(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function ye(e, t, n, r) {
	return w.map((i) => {
		let a = 0, o = 0, s = 0;
		for (let t of e.players) {
			let e = t.tableau.filter((e) => D(e).id === i.id).length;
			t.rid === n ? a = e : o = Math.max(o, e);
		}
		for (let e of r) D(e).id === i.id && (s += 1);
		return {
			id: i.id,
			myTab: a,
			myHand: t.filter((e) => D(e).id === i.id).length,
			oppN: o,
			unseen: i.total - s
		};
	});
}
function be(e, t) {
	let n = (e) => e.myTab + e.myHand + e.unseen > e.oppN, r = t.filter((t) => e.some((e) => e.id === t && n(e))), i = (e) => e.myTab * 3 + e.myHand * 2 - e.oppN + (n(e) ? 0 : -99), a = [...e].sort((e, t) => i(t) - i(e)), o = [...r];
	for (let e of a) {
		if (o.length >= 2) break;
		!o.includes(e.id) && i(e) > 0 && o.push(e.id);
	}
	return o;
}
var xe = (e, t) => {
	let n = e.public;
	if (n.phase === "done") return null;
	let r = n.players[n.turnIdx];
	if (!r || r.rid !== t.rid) return null;
	let i = e.private?.hand ?? [], a = new Set(Object.entries(n.chips).filter(([, e]) => e === t.rid).map(([e]) => e)), o = n.market.filter((e) => !a.has(D(e.card).id)), s = n.market.filter((e) => !a.has(D(e.card).id)).length, c = r.money.liquid >= s;
	if (t.difficulty === "weak") {
		if (n.phase === "pick") {
			let e = o.map((e) => ({
				type: "pick",
				source: "market",
				card: e.card
			}));
			return c && e.push({
				type: "pick",
				source: "deck"
			}), e.length > 0 ? { action: W(e) } : null;
		}
		let e = n.pickedCard === null ? null : D(n.pickedCard).id, t = i.flatMap((t) => {
			let n = [{
				type: "play",
				card: t,
				dest: "tableau"
			}];
			return D(t).id !== e && n.push({
				type: "play",
				card: t,
				dest: "market"
			}), n;
		});
		return t.length > 0 ? { action: W(t) } : null;
	}
	let l = t.memory, u = new Set(Array.isArray(l?.seen) ? l.seen : []);
	for (let e of n.players) for (let t of e.tableau) u.add(t);
	for (let e of n.market) u.add(e.card);
	for (let e of i) u.add(e);
	let d = ye(n, i, t.rid, u), f = be(d, Array.isArray(l?.targets) ? l.targets : []), p = {
		seen: [...u],
		targets: f
	}, m = (e) => d.find((t) => t.id === e), h = n.deckCount <= n.players.length;
	if (n.phase === "pick") {
		let e = h ? 10 : 5, t = null, n = -Infinity;
		for (let r of o) {
			let i = r.coins + (f.includes(D(r.card).id) ? e : 0);
			i > n && (t = r, n = i);
		}
		let r = 3 - s;
		return t && n > r ? {
			action: {
				type: "pick",
				source: "market",
				card: t.card
			},
			memory: p
		} : c ? {
			action: {
				type: "pick",
				source: "deck"
			},
			memory: p
		} : t ? {
			action: {
				type: "pick",
				source: "market",
				card: t.card
			},
			memory: p
		} : {
			action: {
				type: "pick",
				source: "deck"
			},
			memory: p
		};
	}
	let g = n.pickedCard === null ? null : D(n.pickedCard).id, _ = null, v = -Infinity;
	for (let e of i) {
		let r = D(e).id, i = m(r), a = f.includes(r), o = a ? i.myTab + 1 > i.oppN ? 20 : 8 : i.myTab + 1 > i.oppN ? 10 : -4, s = 0, c = n.chips[r];
		c && c !== t.rid && (s += 3), c === t.rid && i.myTab > i.oppN && (s += 2), a || (s += h ? 5 : 2), i.oppN >= i.myTab && i.unseen > 0 && (s -= 6);
		let l = [{
			move: {
				type: "play",
				card: e,
				dest: "tableau"
			},
			score: o
		}];
		r !== g && l.push({
			move: {
				type: "play",
				card: e,
				dest: "market"
			},
			score: s
		});
		for (let e of l) e.score > v && (v = e.score, _ = e.move);
	}
	return _ ? {
		action: _,
		memory: p
	} : null;
}, Se = (e, t, n) => {
	if (e.type === "pick") return e.source === "deck" ? n("games.startups.drawDeck") : n("games.startups.takeAria", { name: n(D(e.card ?? 0).nameKey) });
	let r = n(D(e.card).nameKey);
	return e.dest === "tableau" ? n("games.startups.hintPlayTableau", { co: r }) : n("games.startups.hintPlayMarket", { co: r });
}, G = (e) => {
	let t = D(e);
	return `#${e} ${t.id}${t.emoji}(共${t.total}股)`;
}, Ce = {
	needsAction: (e, t) => e.public.phase !== "done" && e.public.players[e.public.turnIdx]?.rid === t.rid,
	describeView(e, t) {
		let n = e.public, r = [
			`规则:每回合先取牌(pick:抽牌库要付市场税,或免费拿市场一张连同压在上面的硬币)再打牌(play:打到自己面前持股,或放进市场并从持有该公司反垄断筹码的玩家那里收钱)。终局每家公司严格持股最多者(平手无)收其他持股者每股 3 元。公司顺序即股数: ${w.map((e) => `${e.id}${e.emoji}×${e.total}`).join(", ")}。牌 id 与公司的对应已替你标好。`,
			`牌堆剩 ${n.deckCount}。市场: ${n.market.map((e) => `${G(e.card)}+${e.coins}币`).join(" | ") || "(空)"}`,
			`反垄断筹码: ${w.map((e) => {
				let r = n.chips[e.id];
				return `${e.id}→${r ? r === t.rid ? "你" : r : "未发"}`;
			}).join(", ")}`
		];
		for (let e of n.players) {
			let n = e.rid === t.rid ? "你" : e.rid, i = /* @__PURE__ */ new Map();
			for (let t of e.tableau) i.set(D(t).id, (i.get(D(t).id) ?? 0) + 1);
			r.push(`${n}: 持股 ${[...i].map(([e, t]) => `${e}×${t}`).join(", ") || "(无)"};活钱 ${e.money.liquid},利润 ${e.money.banked},欠条 ${e.money.debt}`);
		}
		let i = e.private?.hand ?? [];
		return n.phase === "pick" ? r.push(`你的手牌: ${i.map(G).join(", ")}。第一步取牌:pick(source=deck 付税抽牌 / source=market+card 拿市场牌)。`) : n.phase === "play" && r.push(`你的手牌: ${i.map(G).join(", ")}。第二步打牌:play(card, dest=tableau 持股 / market 放市场)。${n.pickedCard == null ? "" : `注意:你刚从市场拿了 ${G(n.pickedCard)},同公司的牌本回合不能再放回市场。`}`), r.join("\n");
	},
	actionJsonSchema: { oneOf: [{
		type: "object",
		properties: {
			type: { const: "pick" },
			source: { enum: ["deck", "market"] },
			card: {
				type: "integer",
				description: "source=market 时必填,市场里那张牌的 id"
			}
		},
		required: ["type", "source"],
		additionalProperties: !1
	}, {
		type: "object",
		properties: {
			type: { const: "play" },
			card: {
				type: "integer",
				description: "手牌 id"
			},
			dest: { enum: ["tableau", "market"] }
		},
		required: [
			"type",
			"card",
			"dest"
		],
		additionalProperties: !1
	}] },
	parseAction(e, t, n) {
		let r = j.safeParse(e);
		if (!r.success) return null;
		let i = r.data, a = t.public;
		return a.phase === "done" || a.players[a.turnIdx]?.rid !== n.rid ? null : i.type === "pick" ? a.phase === "pick" ? i.source === "deck" ? a.deckCount > 0 ? i : null : i.card != null && a.market.some((e) => e.card === i.card) ? i : null : null : a.phase !== "play" || !(t.private?.hand ?? []).includes(i.card) || i.dest === "market" && a.pickedCard != null && D(a.pickedCard).id === D(i.card).id ? null : i;
	}
};
//#endregion
//#region src/games/startups/fx.tsx
function K(e, t) {
	return {
		x: e.x + (e.w - t.w) / 2,
		y: e.y + (e.h - t.h) / 2,
		w: t.w,
		h: t.h
	};
}
function q(e) {
	return e.anchor("market-card-size") ?? {
		x: 0,
		y: 0,
		w: 54,
		h: 82
	};
}
function J(e, t, n) {
	let r = e.anchor(`card:${t}`);
	if (r) return r;
	let i = Y(e, n), a = e.anchor("hand-card-size") ?? e.anchor("deck");
	return i && a ? K(i, a) : i;
}
function Y(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function X({ from: e, to: t, ms: n, delay: a = 0, children: o }) {
	let s = i(null);
	return r(() => {
		let r = s.current;
		if (!r) return;
		let i = t.x + t.w / 2 - (e.x + e.w / 2), o = t.y + t.h / 2 - (e.y + e.h / 2), c = e.w > 0 ? t.w / e.w : 1, l = e.h > 0 ? t.h / e.h : 1, u = r.animate([
			{ transform: "translate(0px, 0px) scale(1, 1)" },
			{
				transform: `translate(${i * .55}px, ${o * .55 - 14}px) scale(${(1 + c) / 2}, ${(1 + l) / 2})`,
				offset: .55
			},
			{ transform: `translate(${i}px, ${o}px) scale(${c}, ${l})` }
		], {
			duration: n,
			delay: a,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => u.cancel();
	}, [
		e,
		t,
		n,
		a
	]), /* @__PURE__ */ v("div", {
		ref: s,
		className: "absolute",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			transformOrigin: "center"
		},
		children: o
	});
}
function Z({ card: e, size: t, at: n }) {
	return /* @__PURE__ */ v(H, {
		card: e,
		size: t,
		dimensions: {
			width: n.w,
			height: n.h
		}
	});
}
function we({ at: e }) {
	return /* @__PURE__ */ v(U, { dimensions: {
		width: e.w,
		height: e.h
	} });
}
function Q({ at: e }) {
	let t = Math.max(20, Math.min(34, (e?.w ?? 40) * .65));
	return /* @__PURE__ */ v("span", {
		className: "su-coin su-coin--fx",
		style: {
			width: t,
			height: t,
			fontSize: t * .6
		},
		"aria-hidden": !0,
		children: "$"
	});
}
var Te = {
	deal(e, t) {
		let n = e.secret;
		if (n && Array.isArray(n.cards)) {
			let e = t.anchor("deck");
			if (!e) return null;
			let r = [], i = [];
			for (let [a, o] of n.cards.entries()) {
				let n = t.anchor(`card:${o}`);
				n && (i.push(`card:${o}`), r.push(/* @__PURE__ */ v(X, {
					from: e,
					to: n,
					ms: 320,
					delay: a * 45,
					children: /* @__PURE__ */ v(Z, {
						card: o,
						size: "hand",
						at: e
					})
				}, o)));
			}
			return r.length ? {
				ms: 320 + r.length * 45,
				node: r,
				hide: i
			} : null;
		}
		let r = t.anchor("deck"), i = Y(t, e.rid);
		if (!r || !i) return null;
		let a = e.data?.count, o = typeof a == "number" ? a : 3;
		return {
			ms: 320 + o * 45,
			node: Array.from({ length: o }, (e, t) => /* @__PURE__ */ v(X, {
				from: r,
				to: i,
				ms: 320,
				delay: t * 45,
				children: /* @__PURE__ */ v(we, { at: r })
			}, t))
		};
	},
	draw(e, t) {
		let n = e.secret;
		if (n && typeof n.card == "number") {
			let e = t.anchor("deck"), r = t.anchor(`card:${n.card}`);
			return !e || !r ? null : {
				ms: 380,
				node: /* @__PURE__ */ v(X, {
					from: e,
					to: r,
					ms: 380,
					children: /* @__PURE__ */ v(Z, {
						card: n.card,
						size: "hand",
						at: e
					})
				}),
				hide: [`card:${n.card}`]
			};
		}
		let r = t.anchor("deck"), i = Y(t, e.rid);
		return !r || !i ? null : {
			ms: 380,
			node: /* @__PURE__ */ v(X, {
				from: r,
				to: i,
				ms: 380,
				children: /* @__PURE__ */ v(we, { at: r })
			})
		};
	},
	take(e, t) {
		let n = e.data;
		if (typeof n?.card != "number") return null;
		let r = t.anchor("market"), i = t.anchor(`mkt:${n.card}`) ?? (r ? K(r, q(t)) : null);
		if (!i) return null;
		let a = t.anchor(`card:${n.card}`), o = Y(t, e.rid), s = a ?? o;
		if (!s) return null;
		let c = typeof n.coins == "number" ? n.coins : 0;
		return {
			ms: 520,
			hide: a ? [`card:${n.card}`] : void 0,
			node: /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(X, {
				from: i,
				to: s,
				ms: 380,
				children: /* @__PURE__ */ v(Z, {
					card: n.card,
					size: "market",
					at: i
				})
			}), c > 0 && o && /* @__PURE__ */ v(b, {
				at: o,
				ms: 800,
				delay: 300,
				children: /* @__PURE__ */ y("span", {
					className: "inline-flex items-center gap-0.5 font-mono font-extrabold tabular-nums",
					style: { fontSize: Math.max(14, o.w * .5) },
					children: [
						"+",
						c,
						/* @__PURE__ */ v(Q, { at: o })
					]
				})
			})] })
		};
	},
	tax(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.cards) || n.cards.length === 0) return null;
		let r = Y(t, e.rid);
		if (!r) return null;
		let i = [];
		for (let [e, a] of n.cards.entries()) {
			let n = t.anchor(`mkt:${a}`);
			n && i.push(/* @__PURE__ */ v(x, {
				from: r,
				to: n,
				ms: 300,
				delay: e * 70,
				children: /* @__PURE__ */ v(Q, { at: r })
			}, a));
		}
		return i.length ? {
			ms: 300 + i.length * 70,
			node: i
		} : null;
	},
	playTableau(e, t) {
		let n = e.data;
		if (typeof n?.card != "number") return null;
		let r = t.anchor(`co:${D(n.card).id}`), i = J(t, n.card, e.rid);
		if (!r || !i) return null;
		let a = K(r, q(t));
		return {
			ms: 400,
			node: /* @__PURE__ */ v(X, {
				from: i,
				to: a,
				ms: 380,
				children: /* @__PURE__ */ v(Z, {
					card: n.card,
					size: "market",
					at: i
				})
			})
		};
	},
	playMarket(e, t) {
		let n = e.data;
		if (typeof n?.card != "number") return null;
		let r = t.anchor(`mkt:${n.card}`), i = J(t, n.card, e.rid);
		return !r || !i ? null : {
			ms: 400,
			hide: [`mkt:${n.card}`],
			node: /* @__PURE__ */ v(X, {
				from: i,
				to: r,
				ms: 380,
				children: /* @__PURE__ */ v(Z, {
					card: n.card,
					size: "market",
					at: i
				})
			})
		};
	},
	chip(e, t) {
		let n = e.data;
		if (typeof n?.company != "string") return null;
		let r = t.anchor(`co:${n.company}`);
		return r ? {
			ms: 900,
			node: /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(S, {
				at: r,
				ms: 900
			}), /* @__PURE__ */ v(b, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ v("span", {
					className: "su-chip su-chip--fx",
					style: {
						width: Math.max(23, Math.min(38, r.w * .12)),
						height: Math.max(23, Math.min(38, r.w * .12)),
						fontSize: Math.max(14, Math.min(23, r.w * .075))
					},
					"aria-hidden": !0,
					children: "◆"
				})
			})] })
		} : null;
	},
	payout(e, t) {
		let n = e.data;
		if (typeof n?.winner != "string" || typeof n.gained != "number" || !Array.isArray(n.from)) return null;
		let r = t.anchor(`seat:${n.winner}`);
		if (!r) return null;
		let i = [];
		n.from.forEach((e, n) => {
			let a = t.anchor(`seat:${e}`);
			a && i.push(/* @__PURE__ */ v(x, {
				from: a,
				to: r,
				ms: 420,
				delay: n * 120,
				children: /* @__PURE__ */ v(Q, { at: a })
			}, e));
		});
		let a = i.length * 120 + 420;
		return {
			ms: a + 600,
			node: /* @__PURE__ */ y(_, { children: [i, /* @__PURE__ */ v(b, {
				at: r,
				ms: 900,
				delay: a,
				children: /* @__PURE__ */ y("span", {
					className: "inline-flex items-center gap-0.5 font-mono font-extrabold tabular-nums",
					style: { fontSize: Math.max(14, r.w * .5) },
					children: [
						"+",
						n.gained,
						/* @__PURE__ */ v(Q, { at: r })
					]
				})
			})] })
		};
	}
};
//#endregion
//#region src/games/startups/game-over.tsx
function $(e) {
	let t = getComputedStyle(e), n = e.getBoundingClientRect(), r = parseFloat(t.paddingLeft) + parseFloat(t.paddingRight) + parseFloat(t.borderLeftWidth) + parseFloat(t.borderRightWidth), i = parseFloat(t.paddingTop) + parseFloat(t.paddingBottom) + parseFloat(t.borderTopWidth) + parseFloat(t.borderBottomWidth);
	return {
		w: Math.max(0, n.width - r),
		h: Math.max(0, n.height - i),
		insetY: i
	};
}
function Ee(e, t) {
	if (!t) return {
		columns: 1,
		rows: 0
	};
	let n = Math.min(t, Math.max(1, Math.floor((e + 8) / 86))), r = Math.ceil(t / n);
	return {
		columns: Math.ceil(t / r),
		rows: r
	};
}
function De(e, t, n, r, i) {
	if (!e) return Math.max(1, Math.ceil(t.length * n / Math.max(1, i)));
	e.font = `700 ${n}px ${r}`;
	let a = 1, o = "";
	for (let n of t.split(/\s+/)) {
		let t = o ? `${o} ${n}` : n;
		o && e.measureText(t).width > i ? (a += 1, o = n) : o = t;
	}
	return a;
}
function Oe({ result: e, public: t, members: n, onPlayAgain: a, onBackToLobby: o }) {
	let s = l(), u = c((e) => e.locale), f = t, p = i(null);
	r(() => {
		let e = p.current;
		if (!e) return;
		let t = [...e.querySelectorAll(".su-over-rank")], n = [...e.querySelectorAll(".su-over-payout")], r = e.querySelector(".su-over-ranks"), i = e.querySelector(".su-over-payout-grid"), a = matchMedia("(orientation: landscape)"), o = document.createElement("canvas").getContext("2d"), s = /* @__PURE__ */ new Map(), c = null, l = !1, u = (e, t, n, r = "px") => {
			let i = `--su-result-${t}`, a = `${Math.round(n * 100) / 100}${r}`;
			e.style.getPropertyValue(i) !== a && e.style.setProperty(i, a), s.has(e) || s.set(e, /* @__PURE__ */ new Set()), s.get(e).add(i);
		}, d = () => {
			for (let [e, t] of s) for (let n of t) e.style.removeProperty(n);
			s.clear();
		}, f = () => {
			if (!a.matches || e.clientWidth < 960 || e.clientHeight < 600) {
				d();
				return;
			}
			let s = 170;
			for (let e of t) {
				let { w: t, insetY: n } = $(e), { rows: r } = Ee(t, Number(e.dataset.suStocks ?? 0));
				s = Math.max(s, Math.ceil(n + (t < 280 ? 108 : t < 400 ? 66 : 54) + (r ? 8 + r * 32 + (r - 1) * 6 : 0)));
			}
			r && u(r, "rank-min", s);
			let c = 150;
			for (let e of n) {
				let { w: t, insetY: n } = $(e), r = Number(e.dataset.suHolders ?? 0), i = Math.ceil(r / Math.min(Math.max(1, r), t >= 300 ? 2 : 1));
				c = Math.max(c, Math.ceil(n + 44 + 28 + (i ? 16 + i * 28 + (i - 1) * 4 : 8)));
			}
			i && u(i, "payout-min", c);
			for (let e of t) {
				let { w: t, h: n } = $(e), { columns: r, rows: i } = Ee(t, Number(e.dataset.suStocks ?? 0)), a = e.querySelector(".su-over-person small"), s = e.querySelector(".su-over-wealth"), c = a ? getComputedStyle(a).fontFamily : "sans-serif", l = s ? getComputedStyle(s).fontFamily : "monospace";
				o && (o.font = `800 1px ${l}`);
				let d = Math.max(1, o?.measureText(s?.textContent ?? "").width ?? 2);
				o && (o.font = `700 1px ${c}`);
				let f = Math.max(1, ...(a?.textContent ?? "").split(/\s+/).map((e) => o?.measureText(e).width ?? e.length)), p = (e) => {
					let n = Math.max(38, e * 1.15), r = Math.max(20, e * .6), s = Math.max(30, Math.min(e * 1.35, (t - n - 16 - 56) / d)), l = Math.max(56, t - n - s * d - 18), u = Math.max(15, Math.min(e * .38, l / f)), p = De(o, a?.textContent ?? "", u, c, l);
					return {
						seat: n,
						name: r,
						detail: u,
						score: s,
						needed: Math.max(n, s * 1.1, r * 1.2 + u * 1.4 * p) + (i ? 8 + i * e + (i - 1) * 6 : 0)
					};
				}, m = (t - (r - 1) * 8) / r, h = 32, g = Math.max(h, Math.min(68, m * .54, (n - 8 - Math.max(0, i - 1) * 6) / (1.7 + i)));
				for (let e = 0; e < 8; e += 1) {
					let e = (h + g) / 2;
					p(e).needed <= n ? h = e : g = e;
				}
				let _ = p(h);
				u(e, "stock-columns", r, ""), u(e, "stock-mark", h), u(e, "stock-font", Math.max(16, h * .4)), u(e, "rank-seat", _.seat), u(e, "rank-seat-font", _.seat * .53), u(e, "rank-name", _.name), u(e, "rank-detail", _.detail), u(e, "rank-score", _.score);
			}
			for (let e of n) {
				let { w: t, h: n } = $(e), r = Number(e.dataset.suHolders ?? 0), i = Math.min(Math.max(1, r), t >= 300 ? 2 : 1), a = Math.ceil(r / i), s = Math.max(44, Math.min(80, t * .18, n * .32)), c = Math.min(44, Math.max(28, n * .18)), l = a ? 16 + a * 28 + (a - 1) * 4 : 8, d = Math.max(0, n - l - 44 - 28), f = s - 44 + c - 28, p = f > 0 ? Math.min(1, d / f) : 0, m = 44 + (s - 44) * p, h = 28 + (c - 28) * p, g = a ? (n - m - h - 16 - Math.max(0, a - 1) * 4) / a : 0, _ = (t - (i - 1) * 8) / i, v = Math.max(16, Math.min(26, g * .58, _ / 9)), y = e.querySelector(".su-over-no-payout"), b = y ? getComputedStyle(y).fontFamily : "sans-serif", x = 16, S = Math.max(x, Math.min(22, h * .62));
				for (let e = 0; e < 8; e += 1) {
					let e = (x + S) / 2;
					De(o, y?.textContent ?? "", e, b, t) * e * 1.2 <= h ? x = e : S = e;
				}
				u(e, "holder-columns", i, ""), u(e, "company-mark", m), u(e, "company-name", Math.max(20, m * .5)), u(e, "company-result-height", h), u(e, "company-result-seat", Math.max(26, h * .95)), u(e, "company-result-font", Math.max(16, Math.min(26, h * .65))), u(e, "company-gain", Math.max(23, Math.min(36, h * .94))), u(e, "company-none", x), u(e, "holder-font", v), u(e, "holder-seat", v * 1.45), u(e, "holder-seat-font", Math.max(14, v * .85));
			}
		}, m = () => {
			l || c !== null || (c = requestAnimationFrame(() => {
				c = null, f();
			}));
		}, h = new ResizeObserver(m);
		for (let r of [
			e,
			...t,
			...n
		]) h.observe(r);
		return a.addEventListener("change", m), document.fonts.ready.then(m), f(), () => {
			l = !0, h.disconnect(), a.removeEventListener("change", m), c !== null && cancelAnimationFrame(c), d();
		};
	}, [
		u,
		f,
		e
	]);
	let m = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? g(t, u) : e;
	}, h = (e) => d[(n.find((t) => t.rid === e)?.colorIndex ?? f.players.findIndex((t) => t.rid === e)) % d.length].hex, _ = a ?? o;
	return /* @__PURE__ */ v("div", {
		ref: p,
		className: "su-over",
		children: /* @__PURE__ */ y("div", {
			className: "su-over-layout",
			children: [
				e.winner.length > 0 && /* @__PURE__ */ v(C, {}),
				/* @__PURE__ */ y("div", {
					className: "su-over-heading",
					children: [/* @__PURE__ */ v("span", {
						className: "su-over-rocket",
						"aria-hidden": !0,
						children: /* @__PURE__ */ v(se, {
							size: 25,
							color: "white"
						})
					}), /* @__PURE__ */ v("h1", { children: s("session.result.title") })]
				}),
				/* @__PURE__ */ y("div", {
					className: `su-over-content ${e.ranking.length > 3 ? "su-over-content--many" : ""}`,
					children: [/* @__PURE__ */ v("section", {
						className: "su-over-ranks",
						"aria-label": s("games.startups.wealth"),
						children: e.ranking.map((t, r) => {
							let i = f.players.find((e) => e.rid === t);
							if (!i) return null;
							let a = n.find((e) => e.rid === t), o = d[(a?.colorIndex ?? r) % d.length].hex, c = e.winner.includes(t), l = w.map((e) => ({
								co: e,
								n: i.tableau.filter((t) => D(t).id === e.id).length
							})).filter(({ n: e }) => e > 0);
							return /* @__PURE__ */ y("div", {
								"data-su-stocks": l.length,
								className: `su-over-rank ${c ? "su-over-rank--winner" : ""}`,
								children: [
									/* @__PURE__ */ v("span", {
										className: "su-over-seat",
										style: { "--su-player": o },
										children: f.players.findIndex((e) => e.rid === t) + 1
									}),
									/* @__PURE__ */ y("span", {
										className: "su-over-person",
										children: [/* @__PURE__ */ v("strong", { children: m(t) }), /* @__PURE__ */ y("small", { children: [
											s("games.startups.cash"),
											" ",
											i.money.liquid,
											" · ",
											s("games.startups.profitShort"),
											" ",
											i.money.banked,
											i.money.debt > 0 ? ` · ${s("games.startups.debtShort")} ${i.money.debt}` : ""
										] })]
									}),
									/* @__PURE__ */ v("span", {
										className: "su-over-wealth font-mono tabular-nums",
										"aria-label": `${s("games.startups.wealth")} ${e.scores?.[t] ?? I(i.money)}`,
										children: e.scores?.[t] ?? I(i.money)
									}),
									/* @__PURE__ */ v("span", {
										className: "su-over-rank-shares",
										children: l.map(({ co: e, n: t }) => /* @__PURE__ */ y("span", {
											className: "su-over-stock",
											"aria-label": s("games.startups.seatShares", {
												name: s(e.nameKey),
												n: t
											}),
											children: [/* @__PURE__ */ v(V, { co: e }), /* @__PURE__ */ y("span", {
												className: "font-mono tabular-nums",
												children: ["×", t]
											})]
										}, e.id))
									}),
									c && /* @__PURE__ */ v("span", {
										className: "su-over-winner",
										"aria-hidden": !0,
										children: "★"
									})
								]
							}, t);
						})
					}), /* @__PURE__ */ y("section", {
						className: "su-over-payouts",
						"aria-label": s("games.startups.payoutTitle"),
						children: [/* @__PURE__ */ v("h2", { children: s("games.startups.payoutTitle") }), /* @__PURE__ */ v("div", {
							className: "su-over-payout-grid",
							children: f.payouts?.map((e) => {
								let t = w.find((t) => t.id === e.company);
								if (!t) return null;
								let n = f.players.findIndex((t) => t.rid === e.winner) + 1, r = e.winner ? h(e.winner) : null, i = f.players.map((e, n) => ({
									player: e,
									seat: n + 1,
									n: e.tableau.filter((e) => D(e).id === t.id).length
								})).filter(({ n: e }) => e > 0);
								return /* @__PURE__ */ v("div", {
									"data-su-holders": i.length,
									className: "su-over-payout",
									style: { "--su-brand": t.color },
									children: /* @__PURE__ */ y("div", {
										className: "su-over-company-body",
										children: [
											/* @__PURE__ */ y("div", {
												className: "su-over-payout-head",
												children: [/* @__PURE__ */ v(V, { co: t }), /* @__PURE__ */ v("span", {
													className: "su-over-company",
													children: s(t.shortKey)
												})]
											}),
											e.winner && r ? /* @__PURE__ */ y("span", {
												className: "su-over-payout-result",
												children: [
													/* @__PURE__ */ v("span", {
														className: "su-over-seat",
														style: { "--su-player": r },
														"aria-label": m(e.winner),
														children: n
													}),
													/* @__PURE__ */ v("span", {
														className: "su-over-payout-winner",
														children: m(e.winner)
													}),
													/* @__PURE__ */ y("strong", {
														className: "font-mono tabular-nums",
														children: ["+", e.gained]
													})
												]
											}) : /* @__PURE__ */ v("span", {
												className: "su-over-no-payout",
												children: s("games.startups.payoutNone")
											}),
											/* @__PURE__ */ v("div", {
												className: "su-over-holdings",
												children: i.map(({ player: t, seat: n, n: r }) => {
													let i = e.payments.find((e) => e.from === t.rid);
													return /* @__PURE__ */ y("span", {
														className: "su-over-holder",
														"aria-label": s("games.startups.seatShares", {
															name: m(t.rid),
															n: r
														}),
														children: [
															/* @__PURE__ */ v("span", {
																className: "su-over-seat",
																style: { "--su-player": h(t.rid) },
																children: n
															}),
															/* @__PURE__ */ v("span", {
																className: "su-over-holder-name",
																children: m(t.rid)
															}),
															/* @__PURE__ */ y("span", {
																className: "font-mono tabular-nums",
																children: ["×", r]
															}),
															i && /* @__PURE__ */ y("span", {
																className: "su-over-payment",
																children: ["−", i.shares]
															})
														]
													}, t.rid);
												})
											})
										]
									})
								}, t.id);
							})
						})]
					})]
				}),
				_ ? /* @__PURE__ */ y("div", {
					className: "su-over-actions safe-b",
					children: [a && /* @__PURE__ */ v("button", {
						type: "button",
						className: "btn-base text-white",
						style: { background: O.accent },
						onClick: a,
						children: s("session.result.playAgain")
					}), o && /* @__PURE__ */ v("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: s("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ v("p", {
					className: "su-over-wait safe-b",
					children: s("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/startups/entry.tsx
var ke = {
	definition: oe,
	View: le,
	bot: xe,
	describe: Se,
	llm: Ce,
	fx: Te,
	OverView: Oe,
	locales: {
		zh: {
			name: "新创公司",
			desc: "暗持三手牌投资六家新创,争当最大股东赚别人的钱",
			rules: "目标：牌库耗尽后进行结算，持有资金最多的玩家获胜。\n每回合依次执行两个步骤。\n第一步，选择以下一种方式取得卡牌：\n· 从牌库抽取一张牌。抽牌前，须在市场上的每张牌上各放置1枚资金；持有某公司垄断标记时，无须在该公司的牌上支付资金。\n· 从市场拿取一张牌，同时获得该牌上积累的资金。不能拿取自己持有垄断标记的公司牌。\n第二步，打出一张手牌：打出一张手牌，可以放在自己面前作为股份，也可以正面朝上放入市场；刚刚取得的公司牌不能放回市场。\n垄断:\n· 某家公司你持股严格最多时,立即夺得它的垄断标记。\n终局结算:\n· 结算每家公司时，只有持股最多的玩家获得收益。其他持股玩家须按自己每持有 1 股支付 1 枚硬币的标准，将硬币支付给该玩家。\n· 收入按三倍记账,无力支付的差额记为欠条。\n· 六家公司全部结算后，持有资金最多的玩家获胜。",
			co: {
				giraffe: "长颈鹿啤酒",
				bowwow: "汪汪游戏",
				octo: "章鱼咖啡",
				flamingo: "火烈鸟软件",
				hippo: "河马能源",
				elephant: "大象火星旅行"
			},
			coShort: {
				giraffe: "长颈鹿",
				bowwow: "汪汪游戏",
				octo: "章鱼咖啡",
				flamingo: "火烈鸟",
				hippo: "河马能源",
				elephant: "大象旅行"
			},
			pickStep: "取牌",
			playStep: "出牌",
			waitStep: "等 {{name}}",
			deck: "牌堆",
			company: "公司",
			sharesShort: "持股 / 总",
			unseenShort: "未{{n}}",
			hand: "手牌",
			cash: "活钱",
			seatShares: "{{name}}持股 {{n}}",
			companySummary: "{{name}}：持股 {{held}} / 共 {{total}}，未出现 {{unseen}}",
			monopolyHolder: "{{name}}持有垄断标记",
			marketCoins: "牌上资金 {{n}}",
			marketLocked: "你有垄断标记，不能拿这张牌",
			marketDropLocked: "刚从市场拿的公司不能放回市场",
			selectedCard: "已选{{name}}",
			cancelSelection: "取消选牌",
			deckShort: "牌库 {{n}}",
			pickPrompt: "抽牌,或从市场拿一张",
			playPrompt: "打一张牌:持股或放市场",
			waitTurn: "等 {{name}} 行动…",
			drawDeck: "抽牌",
			taxNote: "先付市场税 {{n}}",
			market: "市场",
			takeAria: "从市场拿取{{name}}",
			cardAria: "{{name}},共 {{total}} 股",
			destTableau: "持股",
			destMarket: "放市场",
			chipMark: "垄断标记",
			shares: "已认股 {{held}} / 未出现 {{unseen}}",
			logAria: "对局日志",
			logDraw: "{{name}} 抽了一张牌",
			logDrawTax: "{{name}} 付市场税 {{n}},抽了一张牌",
			logTake: "{{name}} 拿走了市场的{{co}}",
			logTakeCoins: "{{name}} 拿走了市场的{{co}},收 {{n}} 资金",
			logPlayT: "{{name}} 持股{{co}}",
			logPlayM: "{{name}} 把{{co}}放进了市场",
			logChip: "{{name}} 夺得{{co}}的垄断标记",
			logPayout: "{{co}}结算:{{name}} 入账 {{n}}",
			wealth: "财富",
			profitShort: "利润",
			debtShort: "欠条",
			payoutTitle: "公司结算",
			payoutNone: "无控股者,不赔付",
			errNotYourTurn: "现在轮不到你",
			errBadCard: "这张牌动不了",
			errCantAfford: "活钱不够付市场税,只能从市场拿牌",
			errBlocked: "你持有这家公司的垄断标记,不能从市场拿它",
			errBadPlay: "刚拿的公司不能再放回市场",
			hintPlayTableau: "持股{{co}}",
			hintPlayMarket: "把{{co}}放进市场"
		},
		en: {
			name: "Startups",
			desc: "Hold three hidden cards, out-invest rivals in six startups",
			rules: "Goal: when the deck runs out, scoring begins and the richest player wins.\nEach turn has two steps:\nStep 1: Take a card. Choose one of these options:\n· Draw a card from the deck. First place 1 coin on every market card, except cards of companies whose monopoly chip you hold.\n· Or take a card from the market and collect the coins piled on it (you cannot take a company whose chip you hold).\nStep 2: Play a card from your hand. Place it in front of you as a share, or face up in the market. You cannot return a card of the company you just took.\nMonopoly:\n· Whenever you hold strictly the most shares of a company, you seize its monopoly chip at once.\nScoring:\n· For each company, only the majority holder earns: every other shareholder pays them 1 coin per share.\n· Income counts triple; any amount you cannot pay is recorded as debt.\n· After all six companies are settled, the richest player wins.",
			co: {
				giraffe: "Giraffe Beer",
				bowwow: "Bowwow Games",
				octo: "Octo-Coffee",
				flamingo: "Flamingo Soft",
				hippo: "Hippo Powertech",
				elephant: "Elephant Mars Travel"
			},
			coShort: {
				giraffe: "Giraffe",
				bowwow: "Bowwow",
				octo: "Octo",
				flamingo: "Flamingo",
				hippo: "Hippo",
				elephant: "Elephant"
			},
			pickStep: "Take a card",
			playStep: "Play a card",
			waitStep: "Waiting for {{name}}",
			deck: "Deck",
			company: "Companies",
			sharesShort: "Shares / total",
			unseenShort: "Hidden {{n}}",
			hand: "Hand",
			cash: "Cash",
			seatShares: "{{name}} holds {{n}}",
			companySummary: "{{name}}: {{held}} of {{total}} shares held, {{unseen}} unseen",
			monopolyHolder: "{{name}} holds the monopoly chip",
			marketCoins: "{{n}} coins on card",
			marketLocked: "Your monopoly chip blocks this card",
			marketDropLocked: "Cannot return the company just taken from the market",
			selectedCard: "{{name}} selected",
			cancelSelection: "Cancel selection",
			deckShort: "Deck {{n}}",
			pickPrompt: "Draw, or take a card from the market",
			playPrompt: "Play a card: invest or market",
			waitTurn: "Waiting for {{name}}…",
			drawDeck: "Draw",
			taxNote: "Market tax {{n}} first",
			market: "Market",
			takeAria: "Take {{name}} from the market",
			cardAria: "{{name}}, {{total}} shares total",
			destTableau: "Invest",
			destMarket: "To market",
			chipMark: "Monopoly chip",
			shares: "{{held}} claimed / {{unseen}} unseen",
			logAria: "Game log",
			logDraw: "{{name}} drew a card",
			logDrawTax: "{{name}} paid {{n}} market tax and drew",
			logTake: "{{name}} took {{co}} from the market",
			logTakeCoins: "{{name}} took {{co}} from the market, +{{n}} coins",
			logPlayT: "{{name}} invested in {{co}}",
			logPlayM: "{{name}} sent {{co}} to the market",
			logChip: "{{name}} seized the {{co}} monopoly chip",
			logPayout: "{{co}} payout: {{name}} +{{n}}",
			wealth: "Wealth",
			profitShort: "Profit",
			debtShort: "Debt",
			payoutTitle: "Company payouts",
			payoutNone: "No majority, no payout",
			errNotYourTurn: "Not your turn",
			errBadCard: "That card cannot be played",
			errCantAfford: "Not enough cash for the market tax — take from the market",
			errBlocked: "You hold that company’s monopoly chip and cannot take it from the market",
			errBadPlay: "Cannot return the company you just took to the market",
			hintPlayTableau: "Invest in {{co}}",
			hintPlayMarket: "Put {{co}} into the market"
		}
	}
};
//#endregion
export { ke as default };
