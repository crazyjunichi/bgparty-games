import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useState as r } from "react";
import { useT as i } from "@bgparty/sdk/i18n";
import { GameScreen as a } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as o } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as s, jsx as c, jsxs as l } from "react/jsx-runtime";
import { GameOverScreen as u } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as d, OptionSection as f } from "@bgparty/sdk/ui/game-options";
//#region src/games/incubo/data.ts
var p = (e, t, n) => ({
	owner: e,
	a: t,
	t: n
}), m = {
	1: p("a", {
		v: -2,
		pow: "chime",
		arg: 1,
		mandatory: !0
	}, {
		v: 0,
		pow: "discardDraw"
	}),
	2: p("a", { v: -1 }, { v: 1 }),
	3: p("a", { v: -1 }, { v: 1 }),
	4: p("a", { v: -1 }, { v: 1 }),
	5: p("a", {
		v: -1,
		pow: "drawPlay",
		arg: 1
	}, {
		v: 0,
		pow: "negToZero"
	}),
	6: p("a", {
		v: -1,
		pow: "chime",
		arg: 1,
		mandatory: !0
	}, {
		v: 0,
		pow: "drawPlay",
		arg: 2
	}),
	7: p("a", { v: 0 }, { v: 2 }),
	8: p("a", { v: 0 }, {
		v: 1,
		pow: "drawPlay",
		arg: 1
	}),
	9: p("a", { v: 0 }, {
		v: 1,
		pow: "drawPlay",
		arg: 1
	}),
	10: p("a", { v: 0 }, null),
	11: p("a", { v: 0 }, null),
	12: p("a", { v: 0 }, null),
	13: p("a", { v: 0 }, {
		v: 0,
		pow: "fearDiscount"
	}),
	14: p("a", { v: 1 }, null),
	15: p("a", { v: 1 }, null),
	16: p("a", { v: 1 }, null),
	17: p("a", { v: 1 }, null),
	18: p("a", { v: 2 }, null),
	19: p("a", { v: 2 }, null),
	20: p("t", {
		v: 0,
		pow: "look3reorder"
	}, {
		v: -2,
		pow: "drawPlay",
		arg: 1
	}),
	21: p("t", { v: 1 }, { v: -1 }),
	22: p("t", { v: 1 }, { v: -1 }),
	23: p("t", { v: 1 }, { v: -1 }),
	24: p("t", {
		v: 0,
		pow: "x2"
	}, {
		v: -1,
		pow: "chime",
		arg: 1,
		mandatory: !0
	}),
	25: p("t", {
		v: 0,
		pow: "chime",
		arg: 2,
		mandatory: !0
	}, {
		v: -1,
		pow: "drawPlay",
		arg: 1
	}),
	26: p("t", { v: 2 }, { v: 0 }),
	27: p("t", {
		v: 1,
		pow: "drawPlay",
		arg: 1
	}, { v: 0 }),
	28: p("t", {
		v: 1,
		pow: "drawPlay",
		arg: 1
	}, { v: 0 }),
	29: p("t", null, { v: 0 }),
	30: p("t", null, { v: 0 }),
	31: p("t", null, { v: 0 }),
	32: p("t", {
		v: 0,
		pow: "fearDiscount"
	}, { v: 0 }),
	33: p("t", null, { v: 1 }),
	34: p("t", null, { v: 1 }),
	35: p("t", null, { v: 1 }),
	36: p("t", null, { v: 1 }),
	37: p("t", null, { v: 2 }),
	38: p("t", null, { v: 2 })
}, h = {
	39: { v: -2 },
	40: {
		v: 0,
		pow: "max0",
		mandatory: !0
	},
	41: {
		v: -1,
		pow: "loseChime",
		mandatory: !0
	},
	42: { v: -1 },
	43: { v: -1 },
	44: {
		v: 0,
		pow: "minDiscard",
		mandatory: !0
	},
	45: { v: -2 },
	46: {
		v: 0,
		pow: "max0",
		mandatory: !0
	},
	47: {
		v: -1,
		pow: "loseChime",
		mandatory: !0
	},
	48: { v: -1 },
	49: { v: -1 },
	50: {
		v: 0,
		pow: "minDiscard",
		mandatory: !0
	}
}, g = (e, t) => ({
	t: e,
	a: t
}), _ = {
	51: g({
		v: 0,
		sheep: [
			0,
			0,
			1
		],
		free: 1
	}, {
		v: 0,
		sheep: [
			0,
			0,
			1
		],
		free: 1
	}),
	52: g({
		v: 2,
		sheep: [
			0,
			3,
			4
		],
		free: 2,
		pow: "infuse",
		mandatory: !0
	}, {
		v: 0,
		sheep: [
			0,
			0,
			1
		],
		free: 1,
		pow: "playToDeck"
	}),
	53: g({
		v: 2,
		sheep: [
			0,
			3,
			5
		],
		free: 2,
		pow: "chime",
		arg: 1,
		mandatory: !0
	}, {
		v: 0,
		sheep: [
			0,
			0,
			1
		],
		free: 1,
		pow: "look3discard"
	}),
	54: g({
		v: 3,
		sheep: [
			3,
			5,
			6
		],
		free: 4,
		pow: "freePass"
	}, {
		v: 0,
		sheep: [
			0,
			0,
			1
		],
		free: 1,
		pow: "twoN"
	}),
	55: g({
		v: 4,
		sheep: [
			4,
			6,
			8
		],
		free: 5
	}, {
		v: 0,
		sheep: [
			0,
			0,
			1
		],
		free: 1,
		pow: "playToDeckDraw"
	}),
	56: g({
		v: 0,
		sheep: [
			0,
			0,
			1
		],
		free: 1,
		pow: "discardDraw"
	}, {
		v: 1,
		sheep: [
			2,
			2,
			4
		],
		free: 2,
		pow: "playToDeck"
	}),
	57: g({
		v: 0,
		sheep: [
			0,
			0,
			1
		],
		free: 1,
		pow: "chime",
		arg: 2,
		mandatory: !0
	}, {
		v: 1,
		sheep: [
			2,
			2,
			4
		],
		free: 2,
		pow: "chime",
		arg: 2
	}),
	58: g({
		v: 0,
		sheep: [
			1,
			0,
			1
		],
		free: 1,
		pow: "look3box"
	}, {
		v: 1,
		sheep: [
			2,
			2,
			4
		],
		free: 2,
		pow: "discardDraw"
	}),
	59: g({
		v: 1,
		sheep: [
			1,
			2,
			3
		],
		free: 2,
		pow: "chime",
		arg: 2,
		mandatory: !0
	}, {
		v: 1,
		sheep: [
			1,
			2,
			3
		],
		free: 2,
		pow: "playToDeckDraw"
	}),
	60: g({
		v: 1,
		sheep: [
			1,
			2,
			3
		],
		free: 2,
		pow: "terrorShield",
		arg: 3
	}, {
		v: 1,
		sheep: [
			1,
			2,
			3
		],
		free: 2,
		pow: "copy"
	}),
	61: g({
		v: 1,
		sheep: [
			1,
			2,
			3
		],
		free: 2,
		pow: "copy"
	}, {
		v: 1,
		sheep: [
			2,
			2,
			4
		],
		free: 2,
		pow: "chime",
		arg: 2,
		mandatory: !0
	}),
	62: g({
		v: 0,
		sheep: [
			0,
			0,
			1
		],
		free: 1,
		pow: "twoN"
	}, {
		v: 2,
		sheep: [
			2,
			4,
			5
		],
		free: 2,
		pow: "freePass"
	}),
	63: g({
		v: 2,
		sheep: [
			2,
			2,
			4
		],
		free: 2,
		pow: "playToDeck"
	}, {
		v: 2,
		sheep: [
			2,
			4,
			5
		],
		free: 2,
		pow: "look3discard"
	}),
	64: g({
		v: 2,
		sheep: [
			2,
			4,
			5
		],
		free: 2,
		pow: "look3reorder"
	}, {
		v: 2,
		sheep: [
			2,
			2,
			4
		],
		free: 2,
		pow: "freeElim"
	}),
	65: g({
		v: 2,
		sheep: [
			2,
			4,
			5
		],
		free: 2,
		pow: "freeElim"
	}, {
		v: 2,
		sheep: [
			2,
			4,
			5
		],
		free: 2,
		pow: "look3reorder"
	}),
	66: g({
		v: 2,
		sheep: [
			2,
			2,
			4
		],
		free: 2,
		pow: "playToDeck"
	}, {
		v: 2,
		sheep: [
			2,
			2,
			4
		],
		free: 2,
		pow: "freePass"
	}),
	67: g({
		v: 1,
		sheep: [
			2,
			3,
			3
		],
		free: 2,
		pow: "chimeBuy"
	}, {
		v: 3,
		sheep: [
			3,
			5,
			6
		],
		free: 4,
		pow: "chimeBuy"
	}),
	68: g({
		v: 1,
		sheep: [
			1,
			2,
			3
		],
		free: 2,
		pow: "copy"
	}, {
		v: 3,
		sheep: [
			3,
			5,
			6
		],
		free: 4,
		pow: "freePass"
	}),
	69: g({
		v: 2,
		sheep: [
			2,
			2,
			4
		],
		free: 2,
		pow: "drawPlay",
		arg: 1
	}, {
		v: 3,
		sheep: [
			3,
			5,
			6
		],
		free: 4,
		pow: "look2play"
	}),
	70: g({
		v: 3,
		sheep: [
			3,
			5,
			6
		],
		free: 4,
		pow: "infuse"
	}, {
		v: 4,
		sheep: [
			3,
			5,
			6
		],
		free: 4
	}),
	71: g({
		v: 3,
		sheep: [
			3,
			5,
			6
		],
		free: 4,
		pow: "look2play"
	}, {
		v: 3,
		sheep: [
			3,
			5,
			6
		],
		free: 4
	}),
	72: g({
		v: 3,
		sheep: [
			4,
			6,
			6
		],
		free: 5
	}, {
		v: 3,
		sheep: [
			3,
			5,
			6
		],
		free: 4,
		pow: "chimeBuy"
	}),
	73: g({
		v: 1,
		sheep: [
			3,
			4,
			4
		],
		free: 2,
		pow: "chime",
		arg: 3,
		mandatory: !0
	}, {
		v: 4,
		sheep: [
			4,
			6,
			8
		],
		free: 5
	}),
	74: g({
		v: 4,
		sheep: [
			3,
			6,
			8
		],
		free: 5
	}, {
		v: 4,
		sheep: [
			3,
			6,
			8
		],
		free: 5
	})
}, v = {
	75: {
		rem: 1,
		part: "head",
		base: 6,
		need: 3,
		free: 5,
		a: { v: 4 },
		t: { v: 4 }
	},
	76: {
		rem: 1,
		part: "armA",
		rc: 3,
		free: 0,
		a: {
			v: 4,
			pow: "x2"
		},
		t: null
	},
	77: {
		rem: 1,
		part: "armA",
		rc: 2,
		free: 0,
		a: {
			v: 2,
			pow: "look3reorder"
		},
		t: null
	},
	78: {
		rem: 1,
		part: "armT",
		rc: 2,
		free: 0,
		a: null,
		t: {
			v: 0,
			pow: "chime",
			arg: 3,
			mandatory: !0
		}
	},
	79: {
		rem: 1,
		part: "armT",
		rc: 2,
		free: 0,
		a: null,
		t: {
			v: 1,
			pow: "x2"
		}
	},
	80: {
		rem: 2,
		part: "head",
		base: 2,
		need: 3,
		free: 5,
		a: { v: 5 },
		t: { v: 5 }
	},
	81: {
		rem: 2,
		part: "armA",
		rc: 3,
		free: 0,
		a: {
			v: 2,
			pow: "drawPlay",
			arg: 2
		},
		t: null
	},
	82: {
		rem: 2,
		part: "armA",
		rc: 3,
		free: 0,
		a: {
			v: 3,
			pow: "copy"
		},
		t: null
	},
	83: {
		rem: 2,
		part: "armT",
		rc: 3,
		free: 0,
		a: null,
		t: {
			v: 3,
			pow: "drawPlay",
			arg: 1
		}
	},
	84: {
		rem: 2,
		part: "armT",
		rc: 4,
		free: 0,
		a: null,
		t: {
			v: 2,
			pow: "chime",
			arg: 3,
			mandatory: !0
		}
	},
	85: {
		rem: 3,
		part: "head",
		base: 32,
		need: 1,
		free: 5,
		a: null,
		t: null
	}
}, y = {
	1: [
		75,
		76,
		77,
		78,
		79
	],
	2: [
		80,
		81,
		82,
		83,
		84
	],
	3: [85]
}, b = {
	1: {
		faces: 2,
		min: 0
	},
	2: {
		faces: 3,
		min: 1
	},
	3: {
		faces: 5,
		min: 2
	}
}, x = (e) => e >= 39 && e <= 50, S = (e) => e >= 51 && e <= 74, C = (e) => e >= 75 && e <= 85, w = (e) => e >= 90 && e < 96;
function T(e, t) {
	return x(e) ? h[e] : S(e) ? _[e][t] : C(e) ? v[e][t] : w(e) ? null : m[e][t];
}
//#endregion
//#region src/games/incubo/meta.ts
var E = {
	id: "incubo",
	tier: "alpha",
	mechanics: ["deck-bag-building"],
	interactionTags: ["cooperative"],
	nameKey: "games.incubo.name",
	descKey: "games.incubo.desc",
	rulesKey: "games.incubo.rules",
	icon: "🌙",
	iconImg: "games/incubo.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/incubo/en.pdf" },
	minPlayers: 1,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#7c3aed",
	releasedAt: "2026-09-25",
	search: {
		py: "meng yan",
		init: "my"
	},
	hotseat: "cover"
}, D = t.enum(["a", "t"]), O = t.int().min(1).max(95), k = t.int().nonnegative(), A = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("choose"),
		card: O
	}),
	t.object({
		type: t.literal("draw"),
		target: O.optional()
	}),
	t.object({
		type: t.literal("place"),
		row: t.enum([
			"play",
			"pass",
			"elim"
		])
	}),
	t.object({ type: t.literal("removeFear") }),
	t.object({
		type: t.literal("power"),
		uid: k
	}),
	t.object({
		type: t.literal("resolve"),
		order: t.array(t.int().nonnegative()).optional(),
		pick: t.int().nonnegative().optional(),
		uid: k.optional(),
		n: t.int().optional(),
		spend: t.union([t.literal(1), t.literal(2)]).optional()
	}),
	t.object({ type: t.literal("stop") }),
	t.object({ type: t.literal("confirmSettle") }),
	t.object({ type: t.literal("infuse") }),
	t.object({ type: t.literal("companion") })
]), j = t.object({ soloSide: D.catch("a") }).default({ soloSide: "a" }), M = t.object({
	uid: k,
	card: O,
	useSide: D,
	x2: t.int().nonnegative(),
	zero: t.boolean(),
	plus: t.int(),
	powUsed: t.boolean()
}), ee = t.object({
	deck: t.int().nonnegative(),
	discard: t.int().nonnegative(),
	fearDeck: t.int().nonnegative(),
	companion: t.int().nonnegative(),
	play: t.array(M),
	pass: t.array(M),
	elim: t.array(M)
}), te = t.object({
	kind: t.enum([
		"place",
		"look",
		"look2play",
		"pick",
		"twoN",
		"chimeBuy",
		"bothPick"
	]),
	side: D,
	card: O.optional(),
	useSide: D.optional(),
	canRemove: t.boolean().optional(),
	fear: t.boolean().optional(),
	fixedRow: t.enum([
		"play",
		"pass",
		"elim"
	]).nullable().optional(),
	lookCount: t.int().nonnegative().optional(),
	mode: t.enum([
		"reorder",
		"discard",
		"box"
	]).optional(),
	pow: t.string().optional(),
	options: t.array(t.int()).optional(),
	target: O.optional()
}), ne = t.object({
	phase: t.enum([
		"choose",
		"challenge",
		"monster",
		"settle",
		"done"
	]),
	rem: t.union([
		t.literal(1),
		t.literal(2),
		t.literal(3)
	]),
	dreamLeft: t.int().nonnegative(),
	dreamNum: t.int().nonnegative(),
	dreamTotal: t.int().nonnegative(),
	solo: t.boolean(),
	seats: t.object({
		a: t.string().nullable(),
		t: t.string().nullable()
	}),
	growth: D,
	chime: t.object({
		reserve: t.int(),
		discard: t.int().nonnegative(),
		fear: t.int().nonnegative()
	}),
	chimeDeck: t.int().nonnegative(),
	options: t.array(O),
	challenge: t.object({
		dream: O,
		dice: t.object({
			a: t.int(),
			t: t.int()
		}),
		rc: t.object({
			a: t.int(),
			t: t.int()
		}),
		courage: t.object({
			a: t.int(),
			t: t.int()
		}),
		freeLeft: t.object({
			a: t.int(),
			t: t.int()
		}),
		passFree: t.object({
			a: t.int(),
			t: t.int()
		}),
		elimFree: t.object({
			a: t.int(),
			t: t.int()
		}),
		played: t.object({
			a: t.int(),
			t: t.int()
		}),
		infused: t.object({
			a: t.boolean(),
			t: t.boolean()
		}),
		votes: t.array(D)
	}).nullable(),
	monster: t.object({
		parts: t.array(t.object({
			id: O,
			rc: t.int(),
			head: t.boolean(),
			owner: D.nullable(),
			defeated: t.boolean(),
			bonus: t.int(),
			courage: t.int(),
			cards: t.array(M)
		})),
		need: t.int(),
		freeLeft: t.object({
			a: t.int(),
			t: t.int()
		}),
		votes: t.array(D)
	}).nullable(),
	board: t.object({
		a: ee,
		t: ee
	}),
	pending: te.nullable(),
	settle: t.object({
		dream: O,
		winner: D
	}).nullable(),
	result: t.enum(["win", "lose"]).nullable()
}), re = t.object({ peek: t.array(O).nullable() }), N = (e) => e === "a" ? "t" : "a", P = (e) => e.solo ? [e.seats.a ? "a" : "t"] : ["a", "t"], ie = (e, t) => e.seats.a === t ? "a" : e.seats.t === t ? "t" : null;
function F(t, n) {
	for (let r = n.length - 1; r > 0; --r) {
		let i = e(t.seed, t.rng, r + 1);
		t.rng += 1, [n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function ae(t) {
	let n = b[t.rem], r = n.min + e(t.seed, t.rng, n.faces);
	return t.rng += 1, r;
}
function oe(e, t) {
	let n = Math.min(t, e.chime.discard);
	e.chime.discard -= n, e.chime.reserve = Math.min(e.maxChime, e.chime.reserve + n);
}
function I(e, t) {
	e.chime.reserve -= t, e.chime.discard += t;
}
function L(e, t) {
	let n = T(t.card, t.useSide);
	if (!n) return 0;
	let r = e.marks[t.card], i = r?.zero ? 0 : n.v;
	return r?.x2 && (i += n.v * r.x2), i + (r?.plus ?? 0);
}
function R(e, t) {
	return e.phase === "monster" && e.monster ? e.monster.parts.flatMap((e) => e.cards.filter((e) => e.useSide === t)) : e.rows[t].play;
}
function z(e, t) {
	let n = R(e, t).reduce((t, n) => t + L(e, n), 0) + e.infuseBonus[t];
	return e.solo && e.phase !== "monster" && (n += e.rows[t].elim.filter((e) => e.useSide === N(t)).reduce((t, n) => t + L(e, n), 0)), n;
}
function se(e, t) {
	return t.cards.reduce((t, n) => t + L(e, n), 0) + t.bonus;
}
function B(e, t) {
	return R(e, t).some((e) => {
		let t = T(e.card, e.useSide);
		return !e.powUsed && t?.pow === "fearDiscount";
	}) ? 1 : 2;
}
function V(e, t, n) {
	if (e.phase === "monster" && e.monster) {
		for (let r of e.monster.parts) {
			let e = r.cards.findIndex((e) => e.uid === n && e.useSide === t);
			if (e >= 0) return r.cards.splice(e, 1)[0];
		}
		return null;
	}
	let r = e.rows[t];
	for (let e of [
		r.play,
		r.pass,
		r.elim
	]) {
		let t = e.findIndex((e) => e.uid === n);
		if (t >= 0) return e.splice(t, 1)[0];
	}
	return null;
}
var H = (e, t, n) => R(e, t).find((e) => e.uid === n) ?? null;
function U(e, t, n, r, i, a) {
	for (;;) {
		if (e.decks[t].length === 0) {
			if (e.discards[t].length === 0) return !1;
			e.decks[t] = F(e, e.discards[t]), e.discards[t] = [];
		}
		let o = e.decks[t].shift();
		if (w(o)) {
			e.chimeDeck += 1, oe(e, 2);
			continue;
		}
		let s = x(o);
		return e.pending = {
			kind: "place",
			side: t,
			card: o,
			useSide: a ?? t,
			queue: n,
			fixedRow: e.phase === "monster" ? "play" : i,
			target: e.phase === "monster" ? r : null,
			fear: s,
			canRemove: s && e.chime.fear >= B(e, t)
		}, !0;
	}
}
function W(e, t, n, r) {
	n > 0 && U(e, t, n - 1, r, null) || (e.pending = null);
}
function G(e, t, n, r, i) {
	switch (n) {
		case "chime":
			oe(e, r ?? 1);
			return;
		case "infuse":
			if (e.phase === "monster" && e.monster) {
				let t = e.monster.parts.find((e) => e.id === i);
				t && (t.bonus += 1);
			} else e.solo || (e.infuseBonus[N(t)] += 1);
			return;
		case "max0": {
			let n = R(e, t), r = null;
			for (let t of n) (!r || L(e, t) > L(e, r)) && (r = t);
			r && (e.marks[r.card] = {
				...e.marks[r.card],
				zero: !0
			});
			return;
		}
		case "minDiscard": {
			let n = R(e, t).filter((t) => L(e, t) > 0), r = null;
			for (let t of n) (!r || L(e, t) < L(e, r)) && (r = t);
			if (r) {
				let n = V(e, t, r.uid);
				n && e.discards[t].push(n.card);
			}
			return;
		}
		case "loseChime":
			e.chime.reserve > 0 && I(e, 1);
			return;
	}
}
function ce(t, n, r, i, a, o) {
	let s = r.pow;
	if (!s) return { code: "games.incubo.errNoPower" };
	switch (s) {
		case "drawPlay": return U(t, n, a + (r.arg ?? 1) - 1, o, null) || (t.pending = null), null;
		case "chime":
		case "infuse": return G(t, n, s, r.arg, o), W(t, n, a, o), null;
		case "x2": return t.pending = {
			kind: "pick",
			side: n,
			pow: s,
			queue: a,
			target: o
		}, null;
		case "negToZero": return R(t, n).some((e) => (T(e.card, e.useSide)?.v ?? 0) < 0) ? (t.pending = {
			kind: "pick",
			side: n,
			pow: s,
			queue: a,
			target: o
		}, null) : { code: "games.incubo.errNoTarget" };
		case "playToDeck":
		case "playToDeckDraw": return t.phase !== "monster" && t.rows[n].play.length === 0 ? { code: "games.incubo.errNoTarget" } : (t.pending = {
			kind: "pick",
			side: n,
			pow: s,
			queue: a,
			target: o
		}, null);
		case "copy": return R(t, n).some((e) => {
			let t = T(e.card, e.useSide);
			return !!t?.pow && t.pow !== "copy" && t.pow !== "fearDiscount" && t.pow !== "terrorShield";
		}) ? (t.pending = {
			kind: "pick",
			side: n,
			pow: s,
			queue: a,
			target: o
		}, null) : { code: "games.incubo.errNoTarget" };
		case "look3reorder":
		case "look3discard":
		case "look3box": {
			let e = t.decks[n].slice(0, 3);
			return e.length === 0 ? (W(t, n, a, o), null) : (t.pending = {
				kind: "look",
				side: n,
				mode: s === "look3reorder" ? "reorder" : s === "look3discard" ? "discard" : "box",
				cards: e,
				queue: a,
				target: o
			}, null);
		}
		case "look2play": {
			let e = t.decks[n].slice(0, 2);
			return e.length === 0 ? (W(t, n, a, o), null) : (t.pending = {
				kind: "look2play",
				side: n,
				cards: e,
				queue: a,
				target: o
			}, null);
		}
		case "discardDraw": {
			if (t.discards[n].length === 0) return W(t, n, a, o), null;
			let r = e(t.seed, t.rng, t.discards[n].length);
			t.rng += 1;
			let [i] = t.discards[n].splice(r, 1), s = x(i);
			return t.pending = {
				kind: "place",
				side: n,
				card: i,
				useSide: n,
				queue: a,
				fixedRow: t.phase === "monster" ? "play" : null,
				target: t.phase === "monster" ? o : null,
				fear: s,
				canRemove: s && t.chime.fear >= B(t, n)
			}, null;
		}
		case "freePass": return t.passFree[n] += 1, W(t, n, a, o), null;
		case "freeElim": return t.elimFree[n] += 1, W(t, n, a, o), null;
		case "fearDiscount":
		case "terrorShield": return { code: "games.incubo.errPassive" };
		case "twoN": {
			let e = /* @__PURE__ */ new Map();
			for (let r of R(t, n)) {
				let t = T(r.card, r.useSide)?.v ?? 0;
				t >= 1 && e.set(t, (e.get(t) ?? 0) + 1);
			}
			let r = [...e.entries()].filter(([, e]) => e >= 2).map(([e]) => e);
			return r.length === 0 ? { code: "games.incubo.errNoTarget" } : (t.pending = {
				kind: "twoN",
				side: n,
				options: r,
				queue: a,
				target: o
			}, null);
		}
		case "chimeBuy": return t.chime.reserve < 1 ? { code: "games.incubo.errNoChime" } : (t.pending = {
			kind: "chimeBuy",
			side: n,
			srcCard: i,
			queue: a,
			target: o
		}, null);
		case "bothPlayToDeck":
			if (t.phase !== "monster") {
				let e = t.rows[n].play.length > 0, r = !t.solo && t.rows[N(n)].play.length > 0;
				if (!e && !r) return { code: "games.incubo.errNoTarget" };
			}
			return t.pending = {
				kind: "bothPick",
				side: n,
				owner: n,
				firstDone: !1,
				queue: a,
				target: o
			}, null;
		case "max0":
		case "minDiscard":
		case "loseChime": return G(t, n, s, r.arg, o), W(t, n, a, o), null;
	}
}
function K(e, t) {
	let n = _[t];
	e.phase = "challenge", e.dream = t, e.dice = {
		a: 0,
		t: 0
	};
	for (let t of P(e)) e.dice[t] = ae(e);
	e.rc = {
		a: n.a.sheep[e.rem - 1] + e.dice.a,
		t: n.t.sheep[e.rem - 1] + e.dice.t
	}, e.freeLeft = {
		a: n.a.free,
		t: n.t.free
	}, e.passFree = {
		a: 1,
		t: 1
	}, e.elimFree = {
		a: 1,
		t: 1
	}, e.played = {
		a: 0,
		t: 0
	}, e.infused = {
		a: !1,
		t: !1
	}, e.infuseBonus = {
		a: 0,
		t: 0
	}, e.votes = [], e.pending = null;
}
function le(e) {
	if (e.dream = null, e.monster = null, e.dreamDecks[e.rem].length === 0) {
		ue(e);
		return;
	}
	if (e.rem === 1) {
		K(e, e.dreamDecks[1].shift());
		return;
	}
	e.rem === 3 && !e.rem3shuffled && (e.dreamDecks[3] = F(e, e.dreamDecks[3]), e.rem3shuffled = !0);
	let t = Math.min(e.rem === 2 ? 2 : 3, e.dreamDecks[e.rem].length);
	e.options = e.dreamDecks[e.rem].splice(0, t), e.phase = "choose";
}
function ue(e) {
	e.phase = "monster", e.votes = [], e.pending = null;
	for (let t of P(e)) {
		let n = e.fearDecks[t].shift();
		n !== void 0 && e.discards[t].push(n);
	}
	let t = y[e.rem].filter((t) => {
		let n = v[t];
		if (e.solo && (n.part === "armA" || n.part === "armT")) {
			let t = e.seats.a ? "a" : "t";
			return n.part === (t === "a" ? "armA" : "armT");
		}
		return !0;
	}).map((t) => {
		let n = v[t], r = n.part === "head", i = n.rc ?? 0;
		return r && (i = (e.solo ? Math.ceil((n.base ?? 0) / 2) : n.base ?? 0) + ae(e) + (e.solo ? 0 : ae(e))), {
			id: t,
			rc: i,
			head: r,
			owner: n.part === "armA" ? "a" : n.part === "armT" ? "t" : null,
			defeated: !1,
			bonus: 0,
			cards: []
		};
	}), n = v[y[e.rem][0]], r = e.solo ? Math.ceil(n.free / 2) : n.free;
	e.freeLeft = {
		a: r,
		t: r
	}, e.monster = {
		parts: t,
		need: n.need ?? 1
	};
}
function de(e) {
	for (let t of ["a", "t"]) {
		let n = e.rows[t];
		e.discards[t].push(...n.play.map((e) => e.card)), e.solo ? e.companion.push(...n.pass.map((e) => e.card)) : e.discards[N(t)].push(...n.pass.map((e) => e.card)), e.box.push(...n.elim.map((e) => e.card)), e.rows[t] = {
			play: [],
			pass: [],
			elim: []
		};
	}
	e.marks = {};
}
function fe(e) {
	let t = e.dream, n = e.growth;
	e.discards[n].push(t), e.solo || (e.growth = N(e.growth)), de(e), e.dream = null, e.phase = "settle", e.settle = {
		dream: t,
		winner: n
	};
}
function pe(e) {
	let t;
	if (e.solo) {
		let n = e.seats.a ? "a" : "t";
		t = e.rc[n] - Math.min(z(e, n), e.rc[n] + 1);
	} else t = e.rc.a + e.rc.t - Math.min(z(e, "a"), e.rc.a + 1) - Math.min(z(e, "t"), e.rc.t + 1);
	for (let n of P(e)) for (let r of R(e, n)) {
		let e = T(r.card, r.useSide);
		!r.powUsed && e?.pow === "terrorShield" && (r.powUsed = !0, t -= e.arg ?? 3);
	}
	if (t = Math.max(0, t), t > 0) {
		if (e.chime.reserve < t) {
			e.chime.discard += e.chime.reserve, e.chime.reserve = 0, e.phase = "done", e.result = "lose";
			return;
		}
		I(e, t);
		let n = Math.floor(t / 2);
		e.chime.fear += n, e.chime.discard -= n;
	}
	e.dreamDecks[3].unshift(e.dream), de(e), le(e);
}
function me(e) {
	let t = e.monster;
	for (let n of t.parts) {
		if (n.defeated) n.head ? (e.rem < 3 ? e.discards[e.growth].push(n.id) : e.box.push(n.id), e.solo || (e.growth = N(e.growth))) : n.owner && e.discards[n.owner].push(n.id);
		else {
			let t = n.head ? P(e) : n.owner ? [n.owner] : [];
			for (let n of t) {
				let t = e.fearDecks[n].shift();
				t !== void 0 && e.discards[n].push(t);
			}
		}
		for (let t of n.cards) e.discards[t.useSide].push(t.card);
	}
	if (e.monster = null, e.marks = {}, e.rem === 3) {
		e.phase = "done", e.result = "win";
		return;
	}
	e.rem += 1, le(e);
}
function he(e) {
	return P(e).every((t) => e.decks[t].length + e.discards[t].length === 0 && (t !== (e.seats.a ? "a" : "t") || e.companion.length === 0));
}
function ge(t, n, r) {
	let i = n.length === 1, a = {
		players: n,
		seats: i ? {
			a: t.soloSide === "a" ? n[0] : null,
			t: t.soloSide === "t" ? n[0] : null
		} : {
			a: n[0],
			t: n[1] ?? null
		},
		solo: i,
		phase: "choose",
		rem: 1,
		dreamDecks: {
			1: [],
			2: [],
			3: []
		},
		rem3shuffled: !1,
		growth: "a",
		chime: {
			reserve: i ? 35 : 50,
			discard: 0,
			fear: 0
		},
		chimeDeck: 6,
		maxChime: i ? 35 : 50,
		decks: {
			a: [],
			t: []
		},
		discards: {
			a: [],
			t: []
		},
		fearDecks: {
			a: [],
			t: []
		},
		companion: [],
		box: [],
		options: [],
		dream: null,
		dice: {
			a: 0,
			t: 0
		},
		rc: {
			a: 0,
			t: 0
		},
		freeLeft: {
			a: 0,
			t: 0
		},
		passFree: {
			a: 1,
			t: 1
		},
		elimFree: {
			a: 1,
			t: 1
		},
		played: {
			a: 0,
			t: 0
		},
		infused: {
			a: !1,
			t: !1
		},
		infuseBonus: {
			a: 0,
			t: 0
		},
		votes: [],
		rows: {
			a: {
				play: [],
				pass: [],
				elim: []
			},
			t: {
				play: [],
				pass: [],
				elim: []
			}
		},
		marks: {},
		monster: null,
		pending: null,
		settle: null,
		uidSeq: 1,
		seed: r,
		rng: 0,
		result: null
	}, o = (e, t) => Array.from({ length: t - e + 1 }, (t, n) => e + n);
	a.decks.a = F(a, o(1, 19)), a.decks.t = F(a, o(20, 38)), a.fearDecks.a = F(a, o(39, 44)), a.fearDecks.t = F(a, o(45, 50));
	let s = F(a, o(51, 74));
	return a.dreamDecks = {
		1: s.slice(0, 6),
		2: s.slice(6, 18),
		3: s.slice(18, 24)
	}, i ? a.growth = t.soloSide : (a.growth = e(a.seed, a.rng, 2) === 0 ? "a" : "t", a.rng += 1), K(a, a.dreamDecks[1].shift()), { state: a };
}
function _e(e, t, n) {
	let r = ie(e, n.by);
	if (!r || e.phase === "done") return { code: "games.incubo.errPhase" };
	if (t.type === "choose") {
		if (e.phase !== "choose" || !e.options.includes(t.card)) return { code: "games.incubo.errPhase" };
		let n = structuredClone(e), r = n.options.filter((e) => e !== t.card);
		return n.rem === 2 ? n.dreamDecks[3].push(...r) : n.box.push(...r), n.options = [], K(n, t.card), { state: n };
	}
	if (t.type === "confirmSettle") {
		if (e.phase !== "settle") return { code: "games.incubo.errPhase" };
		let t = structuredClone(e);
		return t.settle = null, le(t), { state: t };
	}
	if (e.phase !== "challenge" && e.phase !== "monster") return { code: "games.incubo.errPhase" };
	if (t.type === "place") {
		let n = e.pending;
		if (!n || n.kind !== "place" || n.side !== r) return { code: "games.incubo.errPending" };
		if (n.fear && t.row !== "play") return { code: "games.incubo.errFearRow" };
		if (n.fixedRow && t.row !== n.fixedRow || e.phase === "monster" && t.row !== "play") return { code: "games.incubo.errRow" };
		let i = structuredClone(e), a = i.pending, o = {
			uid: i.uidSeq,
			card: a.card,
			useSide: a.useSide,
			powUsed: !1
		};
		if (i.uidSeq += 1, i.phase === "monster") {
			let e = i.monster?.parts.find((e) => e.id === a.target);
			if (!e || e.defeated) return { code: "games.incubo.errNoTarget" };
			e.cards.push(o);
		} else if (t.row === "pass") {
			if (!T(a.card, N(a.useSide))) return { code: "games.incubo.errNoPass" };
			if (i.passFree[r] > 0) --i.passFree[r];
			else if (i.chime.reserve >= 1) I(i, 1);
			else return { code: "games.incubo.errNoChime" };
			i.rows[r].pass.push(o);
		} else if (t.row === "elim") {
			if (i.elimFree[r] > 0) --i.elimFree[r];
			else if (i.chime.reserve >= 1) I(i, 1);
			else return { code: "games.incubo.errNoChime" };
			i.rows[r].elim.push(o);
		} else i.rows[r].play.push(o);
		i.played[r] += 1, i.pending = null;
		let s = T(a.card, a.useSide);
		if (s?.pow && s.mandatory && G(i, r, s.pow, s.arg, a.target), i.phase === "monster" && i.monster) for (let e of i.monster.parts) !e.defeated && se(i, e) >= e.rc && (e.defeated = !0);
		return W(i, r, a.queue, a.target), { state: i };
	}
	if (t.type === "removeFear") {
		let t = e.pending;
		if (!t || t.kind !== "place" || t.side !== r || !t.fear) return { code: "games.incubo.errPending" };
		let n = structuredClone(e), i = n.pending, a = B(n, r);
		if (n.chime.fear < a) return { code: "games.incubo.errNoChime" };
		if (n.chime.fear -= a, n.chime.discard += a, a === 1) {
			let e = R(n, r).find((e) => {
				let t = T(e.card, e.useSide);
				return !e.powUsed && t?.pow === "fearDiscount";
			});
			e && (e.powUsed = !0);
		}
		return n.box.push(i.card), !n.solo && n.chimeDeck > 0 && (--n.chimeDeck, n.discards[N(r)].push(90 + n.chimeDeck)), n.pending = null, W(n, r, i.queue, i.target), { state: n };
	}
	if (e.pending) return t.type === "resolve" ? ve(e, t, r) : { code: "games.incubo.errPending" };
	if (t.type === "draw") {
		let n = null;
		if (e.phase === "monster") {
			let r = e.monster?.parts.find((e) => e.id === t.target);
			if (!r || r.defeated) return { code: "games.incubo.errNoTarget" };
			n = r.id;
		}
		if (e.decks[r].length + e.discards[r].length === 0) return { code: "games.incubo.errNoCards" };
		let i = structuredClone(e);
		if (i.freeLeft[r] > 0) --i.freeLeft[r];
		else if (i.chime.reserve >= 1) I(i, 1);
		else return { code: "games.incubo.errNoChime" };
		return U(i, r, 0, n, null) ? { state: i } : { code: "games.incubo.errNoCards" };
	}
	if (t.type === "companion") {
		if (!e.solo || e.phase !== "challenge") return { code: "games.incubo.errPhase" };
		if (e.companion.length === 0) return { code: "games.incubo.errNoCards" };
		let t = 1 + (e.freeLeft[r] > 0 ? 0 : 1);
		if (e.chime.reserve < t) return { code: "games.incubo.errNoChime" };
		let n = structuredClone(e);
		return I(n, 1), n.freeLeft[r] > 0 ? --n.freeLeft[r] : I(n, 1), n.companion = F(n, n.companion), n.pending = {
			kind: "place",
			side: r,
			card: n.companion.shift(),
			useSide: N(r),
			queue: 0,
			fixedRow: "elim",
			target: null,
			fear: !1,
			canRemove: !1
		}, { state: n };
	}
	if (t.type === "power") {
		let n = H(e, r, t.uid);
		if (!n) return { code: "games.incubo.errNoTarget" };
		if (n.powUsed) return { code: "games.incubo.errUsed" };
		let i = T(n.card, n.useSide);
		if (!i?.pow) return { code: "games.incubo.errNoPower" };
		if (i.mandatory) return { code: "games.incubo.errUsed" };
		if (e.phase === "monster" && (i.pow === "freePass" || i.pow === "freeElim" || i.pow === "terrorShield")) return { code: "games.incubo.errPhase" };
		let a = structuredClone(e), o = H(a, r, t.uid);
		o.powUsed = !0;
		let s = null;
		return a.phase === "monster" && a.monster && (s = a.monster.parts.find((e) => e.cards.some((e) => e.uid === o.uid))?.id ?? null), ce(a, r, i, o.card, 0, s) || { state: a };
	}
	if (t.type === "infuse") {
		if (e.phase !== "challenge" || e.solo) return { code: "games.incubo.errPhase" };
		if (e.infused[r]) return { code: "games.incubo.errUsed" };
		if (z(e, r) <= e.rc[r]) return { code: "games.incubo.errPhase" };
		let t = structuredClone(e);
		return t.infused[r] = !0, t.infuseBonus[N(r)] += 1, { state: t };
	}
	if (t.type === "stop") {
		let t = structuredClone(e);
		if (t.phase === "challenge") {
			let e = P(t).every((e) => z(t, e) >= t.rc[e]), n = P(t).every((e) => t.played[e] >= 1);
			return e && n ? (fe(t), { state: t }) : e && !n ? { code: "games.incubo.errNeedPlay" } : (t.votes.includes(r) || t.votes.push(r), (P(t).every((e) => t.votes.includes(e)) || he(t)) && pe(t), { state: t });
		}
		let n = t.monster;
		return n.parts.filter((e) => e.defeated).length >= n.need ? (me(t), { state: t }) : (t.votes.includes(r) || t.votes.push(r), (P(t).every((e) => t.votes.includes(e)) || he(t)) && (n.parts.filter((e) => e.defeated).length >= n.need ? me(t) : (t.phase = "done", t.result = "lose")), { state: t });
	}
	return { code: "games.incubo.errPhase" };
}
function ve(e, t, n) {
	if (e.pending.side !== n) return { code: "games.incubo.errPending" };
	let r = structuredClone(e), i = r.pending;
	if (i.kind === "look") {
		let e = i.cards.length;
		if (i.mode === "reorder") {
			if (!t.order || t.order.length !== e || !ye(t.order, e)) return { code: "games.incubo.errBadOrder" };
			let a = t.order.map((e) => i.cards[e]);
			r.decks[n].splice(0, e, ...a);
		} else {
			let a = t.pick;
			if (a === void 0 || a < 0 || a >= e) return { code: "games.incubo.errNoTarget" };
			let o = i.cards.filter((e, t) => t !== a);
			if (t.order && (t.order.length !== o.length || !ye(t.order, o.length))) return { code: "games.incubo.errBadOrder" };
			let s = t.order ? t.order.map((e) => o[e]) : o;
			i.mode === "discard" ? r.discards[n].push(i.cards[a]) : r.box.push(i.cards[a]), r.decks[n].splice(0, e, ...s);
		}
		return W(r, n, i.queue, i.target), { state: r };
	}
	if (i.kind === "look2play") {
		let e = t.pick;
		if (e === void 0 || e < 0 || e >= i.cards.length) return { code: "games.incubo.errNoTarget" };
		let a = i.cards[e];
		r.decks[n].splice(0, i.cards.length);
		for (let t = 0; t < i.cards.length; t += 1) t !== e && r.discards[n].push(i.cards[t]);
		let o = x(a);
		return r.pending = {
			kind: "place",
			side: n,
			card: a,
			useSide: n,
			queue: i.queue,
			fixedRow: r.phase === "monster" ? "play" : null,
			target: r.phase === "monster" ? i.target : null,
			fear: o,
			canRemove: o && r.chime.fear >= B(r, n)
		}, { state: r };
	}
	if (i.kind === "pick") {
		let e = t.uid === void 0 ? null : H(r, n, t.uid);
		if (!e) return { code: "games.incubo.errNoTarget" };
		switch (i.pow) {
			case "x2": return r.marks[e.card] = {
				...r.marks[e.card],
				x2: (r.marks[e.card]?.x2 ?? 0) + 1
			}, W(r, n, i.queue, i.target), { state: r };
			case "negToZero": {
				let t = T(e.card, e.useSide);
				return !t || t.v >= 0 ? { code: "games.incubo.errNoTarget" } : (r.marks[e.card] = {
					...r.marks[e.card],
					zero: !0
				}, W(r, n, i.queue, i.target), { state: r });
			}
			case "playToDeck":
			case "playToDeckDraw": {
				if (r.phase !== "monster" && !r.rows[n].play.some((t) => t.uid === e.uid)) return { code: "games.incubo.errNoTarget" };
				let t = V(r, n, e.uid);
				return r.decks[n].push(t.card), i.pow === "playToDeckDraw" ? U(r, n, i.queue, i.target, null) || (r.pending = null) : W(r, n, i.queue, i.target), { state: r };
			}
			case "copy": {
				let t = T(e.card, e.useSide);
				if (!t?.pow || t.pow === "copy" || t.pow === "fearDiscount" || t.pow === "terrorShield") return { code: "games.incubo.errNoTarget" };
				let a = null;
				return r.phase === "monster" && r.monster && (a = r.monster.parts.find((t) => t.cards.some((t) => t.uid === e.uid))?.id ?? null), ce(r, n, t, e.card, i.queue, a ?? i.target) || { state: r };
			}
		}
	}
	if (i.kind === "twoN") {
		let e = t.n;
		if (e === void 0 || !i.options.includes(e)) return { code: "games.incubo.errNoTarget" };
		let a = R(r, n).find((t) => T(t.card, t.useSide)?.v === e);
		return a ? (r.marks[a.card] = {
			...r.marks[a.card],
			plus: (r.marks[a.card]?.plus ?? 0) + e
		}, W(r, n, i.queue, i.target), { state: r }) : { code: "games.incubo.errNoTarget" };
	}
	if (i.kind === "chimeBuy") {
		let e = t.spend;
		if (!e || r.chime.reserve < e) return { code: "games.incubo.errNoChime" };
		I(r, e);
		let a = e === 1 ? 1 : 3;
		return r.marks[i.srcCard] = {
			...r.marks[i.srcCard],
			plus: (r.marks[i.srcCard]?.plus ?? 0) + a
		}, W(r, n, i.queue, i.target), { state: r };
	}
	if (i.kind === "bothPick") {
		let e = t.uid === void 0 ? null : H(r, n, t.uid);
		if (e) {
			if (r.phase !== "monster" && !r.rows[n].play.some((t) => t.uid === e.uid)) return { code: "games.incubo.errNoTarget" };
			let t = V(r, n, e.uid);
			r.decks[n].push(t.card);
		}
		let a = r.solo ? null : i.side === "a" ? "t" : "a";
		return a && !i.firstDone ? r.phase !== "monster" && r.rows[a].play.length === 0 ? (W(r, i.owner, i.queue, i.target), { state: r }) : (r.pending = {
			...i,
			side: a,
			firstDone: !0
		}, { state: r }) : (W(r, i.owner, i.queue, i.target), { state: r });
	}
	return { code: "games.incubo.errPending" };
}
var ye = (e, t) => e.length === t && new Set(e).size === t && e.every((e) => e >= 0 && e < t);
function q(e, t) {
	let n = e.marks[t.card];
	return {
		uid: t.uid,
		card: t.card,
		useSide: t.useSide,
		x2: n?.x2 ?? 0,
		zero: n?.zero ?? !1,
		plus: n?.plus ?? 0,
		powUsed: t.powUsed
	};
}
function be(e, t) {
	let n = e.rows[t];
	return {
		deck: e.decks[t].length,
		discard: e.discards[t].length,
		fearDeck: e.fearDecks[t].length,
		companion: t === (e.seats.a ? "a" : "t") ? e.companion.length : 0,
		play: n.play.map((t) => q(e, t)),
		pass: n.pass.map((t) => q(e, t)),
		elim: n.elim.map((t) => q(e, t))
	};
}
function xe(e, t) {
	let n = e, r = ie(n, t), i = n.pending;
	return {
		public: {
			phase: n.phase,
			rem: n.rem,
			dreamLeft: n.dreamDecks[n.rem].length,
			dreamNum: n.rem === 1 ? 6 - n.dreamDecks[1].length : n.rem === 2 ? (12 - n.dreamDecks[2].length) / 2 : 0,
			dreamTotal: n.rem === 3 ? 0 : 6,
			solo: n.solo,
			seats: n.seats,
			growth: n.growth,
			chime: { ...n.chime },
			chimeDeck: n.chimeDeck,
			options: [...n.options],
			challenge: n.phase === "challenge" && n.dream !== null ? {
				dream: n.dream,
				dice: { ...n.dice },
				rc: { ...n.rc },
				courage: {
					a: z(n, "a"),
					t: z(n, "t")
				},
				freeLeft: { ...n.freeLeft },
				passFree: { ...n.passFree },
				elimFree: { ...n.elimFree },
				played: { ...n.played },
				infused: { ...n.infused },
				votes: [...n.votes]
			} : null,
			monster: n.phase === "monster" && n.monster ? {
				parts: n.monster.parts.map((e) => ({
					id: e.id,
					rc: e.rc,
					head: e.head,
					owner: e.owner,
					defeated: e.defeated,
					bonus: e.bonus,
					courage: se(n, e),
					cards: e.cards.map((e) => q(n, e))
				})),
				need: n.monster.need,
				freeLeft: { ...n.freeLeft },
				votes: [...n.votes]
			} : null,
			board: {
				a: be(n, "a"),
				t: be(n, "t")
			},
			pending: i ? {
				kind: i.kind,
				side: i.side,
				...i.kind === "place" ? {
					card: i.card,
					useSide: i.useSide,
					canRemove: i.canRemove,
					fear: i.fear,
					fixedRow: i.fixedRow
				} : {},
				...i.kind === "look" ? {
					lookCount: i.cards.length,
					mode: i.mode
				} : {},
				...i.kind === "look2play" ? { lookCount: i.cards.length } : {},
				...i.kind === "pick" ? { pow: i.pow } : {},
				...i.kind === "chimeBuy" ? { card: i.srcCard } : {},
				...i.kind === "twoN" ? { options: [...i.options] } : {},
				..."target" in i && i.target !== null ? { target: i.target } : {}
			} : null,
			settle: n.settle ? { ...n.settle } : null,
			result: n.result
		},
		private: { peek: i && (i.kind === "look" || i.kind === "look2play") && i.side === r ? [...i.cards] : null }
	};
}
function Se(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) {
		let r = ie(e, n);
		r && (t[n] = [
			...e.decks[r],
			...e.discards[r],
			...e.companion
		].reduce((e, t) => x(t) || w(t) ? e : e + (T(t, r)?.v ?? 0), 0));
	}
	return {
		phase: "done",
		winner: e.result === "win" ? [...e.players] : [],
		ranking: [...e.players],
		scores: t
	};
}
var Ce = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: E,
	schemas: {
		action: A,
		publicView: ne,
		privateView: re,
		config: j
	},
	setup: ge,
	reduce: _e,
	viewFor: xe,
	status: Se
}, J = {
	a: "🐾",
	t: "🧢"
}, we = {
	a: "#d97706",
	t: "#0284c7"
}, Y = {
	a: "#fde68a",
	t: "#bae6fd"
}, X = {
	drawPlay: "games.incubo.psDrawPlay",
	chime: "games.incubo.psChime",
	x2: "games.incubo.psX2",
	look3reorder: "games.incubo.psLook3reorder",
	look3discard: "games.incubo.psLook3discard",
	look3box: "games.incubo.psLook3box",
	look2play: "games.incubo.psLook2play",
	discardDraw: "games.incubo.psDiscardDraw",
	freePass: "games.incubo.psFreePass",
	freeElim: "games.incubo.psFreeElim",
	playToDeck: "games.incubo.psPlayToDeck",
	playToDeckDraw: "games.incubo.psPlayToDeckDraw",
	bothPlayToDeck: "games.incubo.psBothPlayToDeck",
	fearDiscount: "games.incubo.psFearDiscount",
	twoN: "games.incubo.psTwoN",
	chimeBuy: "games.incubo.psChimeBuy",
	negToZero: "games.incubo.psNegToZero",
	infuse: "games.incubo.psInfuse",
	terrorShield: "games.incubo.psTerrorShield",
	copy: "games.incubo.psCopy",
	max0: "games.incubo.psMax0",
	minDiscard: "games.incubo.psMinDiscard",
	loseChime: "games.incubo.psLoseChime"
};
function Te({ pow: e, size: t = 14 }) {
	let n = {
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 2,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !0
	};
	switch (e) {
		case "drawPlay": return /* @__PURE__ */ l("svg", {
			...n,
			children: [
				/* @__PURE__ */ c("rect", {
					x: "2.5",
					y: "6",
					width: "9",
					height: "12",
					rx: "1.5"
				}),
				/* @__PURE__ */ c("rect", {
					x: "6",
					y: "3",
					width: "9",
					height: "12",
					rx: "1.5",
					fill: "var(--color-surface)"
				}),
				/* @__PURE__ */ c("path", { d: "M18 10v8M15.5 15.5 18 18l2.5-2.5" })
			]
		});
		case "chime": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("path", { d: "M12 3a6 6 0 0 1 6 6c0 4 1.5 5.5 2 6H4c.5-.5 2-2 2-6a6 6 0 0 1 6-6Z" }), /* @__PURE__ */ c("path", { d: "M10 19a2 2 0 0 0 4 0" })]
		});
		case "x2": return /* @__PURE__ */ l("svg", {
			...n,
			children: [
				/* @__PURE__ */ c("rect", {
					x: "3",
					y: "4",
					width: "11",
					height: "15",
					rx: "1.5"
				}),
				/* @__PURE__ */ c("path", { d: "M15.5 15.5l5 5M20.5 15.5l-5 5" }),
				/* @__PURE__ */ c("text", {
					x: "17.8",
					y: "9.5",
					fontSize: "7",
					fontWeight: "800",
					fill: "currentColor",
					stroke: "none",
					textAnchor: "middle",
					children: "2"
				})
			]
		});
		case "look3reorder": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("path", { d: "M3 6h11M3 11h11M3 16h11" }), /* @__PURE__ */ c("path", { d: "M18 4v13M15.5 14.5 18 17l2.5-2.5M20.5 6.5 18 4l-2.5 2.5" })]
		});
		case "look3discard": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("path", { d: "M3 6h10M3 11h10M3 16h10" }), /* @__PURE__ */ c("path", { d: "M16 14l6 6M22 14l-6 6" })]
		});
		case "look3box": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("path", { d: "M3 5h10M3 9.5h10" }), /* @__PURE__ */ c("path", { d: "M4 14h16l-1.5 7h-13L4 14ZM12 14v7" })]
		});
		case "look2play": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("rect", {
				x: "3",
				y: "4",
				width: "9",
				height: "12",
				rx: "1.5"
			}), /* @__PURE__ */ c("path", { d: "M16 5l5 2.5-5 2.5M16 21v-6M13.5 17.5 16 15l2.5 2.5" })]
		});
		case "discardDraw": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("path", { d: "M4 9a8 8 0 0 1 14-3l2 2M20 15a8 8 0 0 1-14 3l-2-2" }), /* @__PURE__ */ c("path", { d: "M20 4v4h-4M4 20v-4h4" })]
		});
		case "freePass": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("rect", {
				x: "3",
				y: "6",
				width: "10",
				height: "13",
				rx: "1.5"
			}), /* @__PURE__ */ c("path", { d: "M15 12.5h6M18.5 10 21 12.5 18.5 15" })]
		});
		case "freeElim": return /* @__PURE__ */ c("svg", {
			...n,
			children: /* @__PURE__ */ c("path", { d: "M4 7h16M9 7V4h6v3M6.5 7l1 13h9l1-13M10 11v5M14 11v5" })
		});
		case "playToDeck": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("rect", {
				x: "8",
				y: "2.5",
				width: "9",
				height: "11",
				rx: "1.5"
			}), /* @__PURE__ */ c("path", { d: "M12.5 16v5M10 18.5l2.5 2.5 2.5-2.5M4 17.5h3M4 21h3" })]
		});
		case "playToDeckDraw": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("rect", {
				x: "3",
				y: "5",
				width: "9",
				height: "12",
				rx: "1.5"
			}), /* @__PURE__ */ c("path", { d: "M17 4v6M14.5 7.5 17 10l2.5-2.5M17 20v-6M19.5 16.5 17 14l-2.5 2.5" })]
		});
		case "bothPlayToDeck": return /* @__PURE__ */ l("svg", {
			...n,
			children: [
				/* @__PURE__ */ c("circle", {
					cx: "7",
					cy: "6",
					r: "2.5"
				}),
				/* @__PURE__ */ c("circle", {
					cx: "17",
					cy: "6",
					r: "2.5"
				}),
				/* @__PURE__ */ c("path", { d: "M7 11v6M17 11v6M4.5 14.5 7 17l2.5-2.5M14.5 14.5 17 17l2.5-2.5" })
			]
		});
		case "fearDiscount": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("path", { d: "M12 3l1.8 1.6L16 3.6l1.2 2 2.6-.2.4 2.4 2.4 1-.8 2.3 1.6 2-2 1.5.2 2.6-2.6.4-1 2.4-2.3-.8-2 1.6-1.5-2H8.4l-1-2.4-2.6-.4.2-2.6-2-1.5L4.6 11l-.8-2.3 2.4-1L6.6 5.3l2.6.2 1.2-2 2.2 1Z" }), /* @__PURE__ */ c("path", { d: "M9 10h.01M15 10h.01M9.5 14.5c1.5-1 3.5-1 5 0" })]
		});
		case "twoN": return /* @__PURE__ */ l("svg", {
			...n,
			children: [
				/* @__PURE__ */ c("circle", {
					cx: "7.5",
					cy: "9",
					r: "4.5"
				}),
				/* @__PURE__ */ c("circle", {
					cx: "16.5",
					cy: "9",
					r: "4.5",
					fill: "var(--color-surface)"
				}),
				/* @__PURE__ */ c("path", { d: "M12 16v5M9.5 18.5h5" })
			]
		});
		case "chimeBuy": return /* @__PURE__ */ l("svg", {
			...n,
			children: [
				/* @__PURE__ */ c("path", { d: "M7 4a4.5 4.5 0 0 1 4.5 4.5c0 3 1 4 1.5 4.5H3c.5-.5 1.5-1.5 1.5-4.5A4.5 4.5 0 0 1 7 4Z" }),
				/* @__PURE__ */ c("path", { d: "M17.5 5l1.2 2.6 2.8.3-2.1 1.9.6 2.7-2.5-1.4-2.5 1.4.6-2.7-2.1-1.9 2.8-.3Z" }),
				/* @__PURE__ */ c("path", { d: "M5 19h5M17.5 16v5M15 18.5h5" })
			]
		});
		case "negToZero": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("path", { d: "M3 12h5M11 12h4" }), /* @__PURE__ */ c("circle", {
				cx: "19",
				cy: "12",
				r: "3.5"
			})]
		});
		case "infuse": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("path", { d: "M8 12.5C5 10 3.5 8 3.5 6A2.9 2.9 0 0 1 8 4.2 2.9 2.9 0 0 1 12.5 6c0 .8-.2 1.5-.7 2.3" }), /* @__PURE__ */ c("path", { d: "M14 18h7M18.5 15.5 21 18l-2.5 2.5M15 10.5v3" })]
		});
		case "terrorShield": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("path", { d: "M12 3l8 2.5v6c0 5-3.5 8-8 9.5-4.5-1.5-8-4.5-8-9.5v-6Z" }), /* @__PURE__ */ c("path", { d: "M9 10h.01M15 10h.01M9.5 14c1.5-1.2 3.5-1.2 5 0" })]
		});
		case "copy": return /* @__PURE__ */ l("svg", {
			...n,
			children: [
				/* @__PURE__ */ c("rect", {
					x: "3",
					y: "7",
					width: "9",
					height: "12",
					rx: "1.5"
				}),
				/* @__PURE__ */ c("rect", {
					x: "8",
					y: "3",
					width: "9",
					height: "12",
					rx: "1.5",
					fill: "var(--color-surface)"
				}),
				/* @__PURE__ */ c("path", { d: "M18 17.5h4M18 20.5h4" })
			]
		});
		case "max0": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("path", { d: "M8 3.5l1.5 3.3 3.5.4-2.6 2.4.7 3.4-3.1-1.7L4.9 13l.7-3.4L3 7.2l3.5-.4Z" }), /* @__PURE__ */ c("circle", {
				cx: "17",
				cy: "16",
				r: "4.5"
			})]
		});
		case "minDiscard": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("rect", {
				x: "6",
				y: "4",
				width: "9",
				height: "12",
				rx: "1.5"
			}), /* @__PURE__ */ c("path", { d: "M10.5 12.5 8 15l2.5 2.5M16 19l5-5M21 19l-5-5" })]
		});
		case "loseChime": return /* @__PURE__ */ l("svg", {
			...n,
			children: [/* @__PURE__ */ c("path", { d: "M11 3a6 6 0 0 1 6 6c0 4 1.5 5.5 2 6H3c.5-.5 2-2 2-6a6 6 0 0 1 6-6Z" }), /* @__PURE__ */ c("path", { d: "M11 7l-1.5 2.5L12 12l-1.5 3M9 19a2 2 0 0 0 4 0" })]
		});
	}
}
function Z({ x: e, y: t, w: n, h: r, tail: i, fill: a, stroke: o = "var(--color-ink)", children: s }) {
	let u = Math.min(7, r / 2 - 1), d = i === "bl" ? `M${e + 5} ${t + r - 1} l-3 7 l10 -6` : `M${e + n - 5} ${t + 1} l3 -7 l-10 6`;
	return /* @__PURE__ */ l("g", { children: [
		/* @__PURE__ */ c("rect", {
			x: e,
			y: t,
			width: n,
			height: r,
			rx: u,
			fill: a,
			stroke: o,
			strokeWidth: 2
		}),
		/* @__PURE__ */ c("path", {
			d,
			fill: a,
			stroke: o,
			strokeWidth: 2,
			strokeLinejoin: "round"
		}),
		s
	] });
}
function Ee({ glow: e, fear: t }) {
	let r = n();
	return /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ c("defs", { children: /* @__PURE__ */ l("linearGradient", {
			id: r,
			x1: "0",
			y1: "0",
			x2: "0",
			y2: "1",
			children: [/* @__PURE__ */ c("stop", {
				offset: "0",
				stopColor: t ? "#0c0a12" : "#1c1830"
			}), /* @__PURE__ */ c("stop", {
				offset: "1",
				stopColor: t ? "#1f0f18" : "#2d2547"
			})]
		}) }),
		/* @__PURE__ */ c("rect", {
			width: "100",
			height: "100",
			rx: "12",
			fill: `url(#${r})`
		}),
		/* @__PURE__ */ c("circle", {
			cx: "26",
			cy: "18",
			r: "11",
			fill: "#f5ead0",
			opacity: t ? .25 : .9
		}),
		/* @__PURE__ */ c("circle", {
			cx: "30",
			cy: "15",
			r: "9",
			fill: t ? "#0c0a12" : "#1c1830"
		}),
		/* @__PURE__ */ c("path", {
			d: "M52 10l1.2 2.8 2.8 1.2-2.8 1.2L52 18l-1.2-2.8L48 14l2.8-1.2Z",
			fill: "#f5ead0",
			opacity: "0.7"
		}),
		/* @__PURE__ */ c("path", {
			d: "M66 30l.8 1.8 1.8.8-1.8.8-.8 1.8-.8-1.8-1.8-.8 1.8-.8Z",
			fill: "#f5ead0",
			opacity: "0.5"
		}),
		e && /* @__PURE__ */ c("ellipse", {
			cx: "50",
			cy: "104",
			rx: "46",
			ry: "26",
			fill: e,
			opacity: "0.28"
		}),
		t && /* @__PURE__ */ c("rect", {
			width: "100",
			height: "100",
			rx: "12",
			fill: "none",
			stroke: "#e11d48",
			strokeWidth: "2.5",
			strokeDasharray: "4 3"
		})
	] });
}
function Q({ card: e, useSide: t, displaySide: n, marks: r, dim: a, className: o = "w-20" }) {
	let s = i(), u = n ?? t, d = T(e, u), f = T(e, u === "a" ? "t" : "a"), p = x(e), m = d?.v ?? 0;
	r?.zero && (m = 0), r && r.x2 > 0 && (m += (d?.v ?? 0) * r.x2), m += r?.plus ?? 0;
	let h = !!r && (r.x2 > 0 || r.zero || r.plus !== 0);
	return /* @__PURE__ */ l("span", {
		className: `incubo-courage relative inline-flex flex-none ${o} ${a ? "opacity-50" : ""}`,
		style: { aspectRatio: "1" },
		title: d?.pow ? s(X[d.pow], { n: d.arg ?? 0 }) : void 0,
		children: [/* @__PURE__ */ l("svg", {
			viewBox: "0 0 100 100",
			className: "size-full",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ c(Ee, {
					glow: p ? void 0 : Y[u],
					fear: p
				}),
				!p && f && /* @__PURE__ */ c(Z, {
					x: 68,
					y: 6,
					w: 27,
					h: 20,
					tail: "tr",
					fill: Y[u === "a" ? "t" : "a"],
					children: /* @__PURE__ */ c("text", {
						x: 81.5,
						y: 21,
						textAnchor: "middle",
						fontSize: "13",
						fontWeight: "800",
						fill: "var(--color-ink)",
						fontFamily: "inherit",
						className: "tabular-nums",
						children: f.v
					})
				}),
				/* @__PURE__ */ c(Z, {
					x: 5,
					y: p ? 56 : 60,
					w: 35,
					h: 30,
					tail: "bl",
					fill: p ? "#3f1d2e" : we[u],
					stroke: h ? "#f5ead0" : "var(--color-ink)",
					children: /* @__PURE__ */ c("text", {
						x: 22.5,
						y: p ? 78 : 82,
						textAnchor: "middle",
						fontSize: "20",
						fontWeight: "900",
						fill: "#fdf6e3",
						fontFamily: "inherit",
						className: "tabular-nums",
						children: d ? m : "?"
					})
				}),
				p && /* @__PURE__ */ l("g", {
					fill: "#f5ead0",
					opacity: "0.85",
					children: [
						/* @__PURE__ */ c("ellipse", {
							cx: "38",
							cy: "40",
							rx: "6",
							ry: "7"
						}),
						/* @__PURE__ */ c("ellipse", {
							cx: "58",
							cy: "40",
							rx: "6",
							ry: "7"
						}),
						/* @__PURE__ */ c("circle", {
							cx: "38",
							cy: "42",
							r: "2.4",
							fill: "#0c0a12"
						}),
						/* @__PURE__ */ c("circle", {
							cx: "58",
							cy: "42",
							r: "2.4",
							fill: "#0c0a12"
						})
					]
				})
			]
		}), d?.pow && /* @__PURE__ */ l("span", {
			className: `absolute inset-x-1 bottom-1 flex items-center gap-0.5 rounded-md border px-1 py-0.5 text-[9px] leading-none font-extrabold ${p ? "border-rose-300/40 bg-black/60 text-rose-100" : "border-white/25 bg-black/55 text-amber-50"}`,
			children: [
				/* @__PURE__ */ c(Te, {
					pow: d.pow,
					size: 11
				}),
				/* @__PURE__ */ c("span", {
					className: "min-w-0 flex-1 truncate",
					children: s(X[d.pow], { n: d.arg ?? 0 })
				}),
				d.mandatory && /* @__PURE__ */ c("span", {
					"aria-label": s("games.incubo.mandatoryTag"),
					children: "*"
				})
			]
		})]
	});
}
function De({ n: e, caption: t, disabled: n, onClick: r, className: i = "w-20" }) {
	let a = /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ l("svg", {
			viewBox: "0 0 100 100",
			className: "size-full",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ c("rect", {
					x: "6",
					y: "3",
					width: "90",
					height: "90",
					rx: "12",
					fill: "#141021",
					stroke: "var(--color-ink)",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ c("rect", {
					x: "3",
					y: "6",
					width: "90",
					height: "90",
					rx: "12",
					fill: "#241d3d",
					stroke: "var(--color-ink)",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ c("circle", {
					cx: "48",
					cy: "40",
					r: "16",
					fill: "#f5ead0",
					opacity: "0.9"
				}),
				/* @__PURE__ */ c("circle", {
					cx: "54",
					cy: "35",
					r: "13",
					fill: "#241d3d"
				}),
				/* @__PURE__ */ c("path", {
					d: "M30 66l1.5 3.5L35 71l-3.5 1.5L30 76l-1.5-3.5L25 71l3.5-1.5Z",
					fill: "#f5ead0",
					opacity: "0.7"
				}),
				/* @__PURE__ */ c("path", {
					d: "M64 70l1 2.4 2.4 1-2.4 1-1 2.4-1-2.4-2.4-1 2.4-1Z",
					fill: "#f5ead0",
					opacity: "0.5"
				})
			]
		}),
		/* @__PURE__ */ c("span", {
			className: "absolute -top-2 -right-2 grid min-w-6 place-items-center rounded-full border-2 border-ink bg-surface px-1 font-mono text-xs leading-5 font-extrabold tabular-nums",
			children: e
		}),
		/* @__PURE__ */ c("span", {
			className: "absolute inset-x-1 bottom-1 rounded-md border border-white/25 bg-black/55 px-1 py-0.5 text-center text-[9px] leading-none font-extrabold text-amber-50",
			children: t
		})
	] });
	return r ? /* @__PURE__ */ c("button", {
		type: "button",
		onClick: r,
		disabled: n,
		className: `incubo-pile relative inline-flex flex-none ${i} transition-transform active:translate-y-0.5 disabled:opacity-40`,
		style: { aspectRatio: "1" },
		children: a
	}) : /* @__PURE__ */ c("span", {
		className: `incubo-pile relative inline-flex flex-none ${i}`,
		style: { aspectRatio: "1" },
		children: a
	});
}
function Oe({ id: e, rem: t, simple: n, side: r, className: a = "w-32" }) {
	let o = i(), u = _[e], d = r ?? "a", f = d === "a" ? "t" : "a";
	return /* @__PURE__ */ l("span", {
		className: `incubo-dream relative inline-flex flex-none ${a}`,
		style: { aspectRatio: "1" },
		children: [
			/* @__PURE__ */ l("svg", {
				viewBox: "0 0 100 100",
				className: "size-full",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ c(Ee, { glow: n ? Y[d] : void 0 }), n && /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c(Z, {
					x: 68,
					y: 6,
					w: 27,
					h: 20,
					tail: "tr",
					fill: Y[f],
					children: /* @__PURE__ */ c("text", {
						x: 81.5,
						y: 21,
						textAnchor: "middle",
						fontSize: "13",
						fontWeight: "800",
						fill: "var(--color-ink)",
						fontFamily: "inherit",
						className: "tabular-nums",
						children: u[f].v
					})
				}), /* @__PURE__ */ c(Z, {
					x: 5,
					y: 60,
					w: 35,
					h: 30,
					tail: "bl",
					fill: we[d],
					children: /* @__PURE__ */ c("text", {
						x: 22.5,
						y: 82,
						textAnchor: "middle",
						fontSize: "20",
						fontWeight: "900",
						fill: "#fdf6e3",
						fontFamily: "inherit",
						className: "tabular-nums",
						children: u[d].v
					})
				})] })]
			}),
			!n && /* @__PURE__ */ c("span", {
				className: "absolute inset-x-1.5 bottom-3.5 flex flex-col gap-1",
				children: ["a", "t"].map((e) => /* @__PURE__ */ l("span", {
					className: "rounded-md border border-ink/60 px-1 py-0.5 leading-none font-extrabold",
					style: { background: Y[e] },
					children: [/* @__PURE__ */ l("span", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ c("span", {
								"aria-hidden": !0,
								className: "text-[10px]",
								children: J[e]
							}),
							/* @__PURE__ */ c("span", {
								className: "font-mono text-sm tabular-nums",
								title: o("games.incubo.rewardShort"),
								children: u[e].v
							}),
							u[e].pow && /* @__PURE__ */ l("span", {
								className: "ml-auto flex items-center",
								title: o(X[u[e].pow], { n: u[e].arg ?? 0 }),
								children: [/* @__PURE__ */ c(Te, {
									pow: u[e].pow,
									size: 11
								}), u[e].mandatory ? /* @__PURE__ */ c("span", {
									className: "text-[10px]",
									children: "*"
								}) : null]
							})
						]
					}), /* @__PURE__ */ l("span", {
						className: "mt-0.5 flex items-center gap-1 text-[9px] opacity-75",
						children: [/* @__PURE__ */ l("span", {
							className: "font-mono tabular-nums",
							children: [
								o("games.incubo.needShort"),
								"🐑",
								u[e].sheep[t - 1]
							]
						}), /* @__PURE__ */ l("span", {
							className: "ml-auto font-mono tabular-nums",
							children: [o("games.incubo.freeShort"), u[e].free]
						})]
					})]
				}, e))
			}),
			/* @__PURE__ */ l("span", {
				className: "absolute inset-x-0 bottom-0.5 text-center font-mono text-[8px] leading-none text-white/50",
				children: ["#", e]
			})
		]
	});
}
function ke({ id: e, head: t, owner: n, rc: r, courage: a, defeated: o, className: s = "w-20" }) {
	let u = i(), d = v[e], f = n ? d[n]?.pow : void 0, p = n ? d[n]?.arg : void 0, m = Math.max(0, Math.min(1, a / Math.max(1, r)));
	return /* @__PURE__ */ l("span", {
		className: `incubo-monster relative inline-flex flex-none ${s} ${o ? "opacity-60" : ""}`,
		style: { aspectRatio: "1" },
		children: [/* @__PURE__ */ l("svg", {
			viewBox: "0 0 100 100",
			className: "size-full",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ c(Ee, { fear: !o }),
				t ? /* @__PURE__ */ l("g", { children: [
					/* @__PURE__ */ c("ellipse", {
						cx: "50",
						cy: "52",
						rx: "26",
						ry: "20",
						fill: "#0c0a12",
						stroke: "#e11d48",
						strokeWidth: "2.5"
					}),
					[
						36,
						46,
						56,
						66
					].map((e) => /* @__PURE__ */ c("path", {
						d: `M${e} 36 l4 10 l4 -10 Z`,
						fill: "#f5ead0"
					}, `t${e}`)),
					[
						40,
						52,
						64
					].map((e) => /* @__PURE__ */ c("path", {
						d: `M${e} 68 l3 -9 l3 9 Z`,
						fill: "#f5ead0"
					}, `b${e}`))
				] }) : /* @__PURE__ */ c("text", {
					x: "50",
					y: "62",
					textAnchor: "middle",
					fontSize: "38",
					fontFamily: "inherit",
					children: n ? J[n] : ""
				}),
				/* @__PURE__ */ c(Z, {
					x: 60,
					y: 6,
					w: 34,
					h: 22,
					tail: "tr",
					fill: o ? "#3a3157" : "#e11d48",
					children: /* @__PURE__ */ l("text", {
						x: 77,
						y: 22,
						textAnchor: "middle",
						fontSize: "13",
						fontWeight: "900",
						fill: "#fdf6e3",
						fontFamily: "inherit",
						className: "tabular-nums",
						children: [
							a,
							"/",
							r
						]
					})
				}),
				/* @__PURE__ */ c("rect", {
					x: 6,
					y: 90,
					width: 88,
					height: 6,
					rx: 3,
					fill: "#141021",
					stroke: "var(--color-ink)",
					strokeWidth: 1.5
				}),
				m > 0 && /* @__PURE__ */ c("rect", {
					x: 7.5,
					y: 91.5,
					width: 85 * m,
					height: 3,
					rx: 1.5,
					fill: o ? "var(--color-done)" : "#f5ead0"
				}),
				o && /* @__PURE__ */ c("text", {
					x: "50",
					y: "30",
					textAnchor: "middle",
					fontSize: "12",
					fontWeight: "900",
					fill: "var(--color-done)",
					fontFamily: "inherit",
					children: "✓"
				})
			]
		}), f && /* @__PURE__ */ l("span", {
			className: "absolute inset-x-1 bottom-2 flex items-center gap-0.5 rounded-md border border-rose-300/40 bg-black/60 px-1 py-0.5 text-[9px] leading-none font-extrabold text-rose-100",
			children: [/* @__PURE__ */ c(Te, {
				pow: f,
				size: 11
			}), /* @__PURE__ */ c("span", {
				className: "min-w-0 flex-1 truncate",
				children: u(X[f], { n: p ?? 0 })
			})]
		})]
	});
}
//#endregion
//#region src/games/incubo/view-player.tsx
function Ae(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ c(Ne, {
		pub: t,
		priv: n ?? { peek: null },
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var je = (e) => e === "a" ? "t" : "a";
function Me({ c: e, side: t, mySide: n, displaySide: r, actionable: i, onTap: a }) {
	let o = /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ c(Q, {
			card: e.card,
			useSide: e.useSide,
			displaySide: r,
			marks: {
				x2: e.x2,
				zero: e.zero,
				plus: e.plus
			},
			dim: e.powUsed,
			className: "w-14"
		}),
		e.x2 > 0 && /* @__PURE__ */ l("span", {
			className: "absolute -bottom-1.5 -left-1.5 rounded-md border border-ink bg-warn-soft px-0.5 text-[9px] leading-3 font-extrabold",
			children: ["×", e.x2 + 1]
		}),
		e.zero && /* @__PURE__ */ c("span", {
			className: "absolute -bottom-1.5 -left-1.5 rounded-md border border-ink bg-info-soft px-0.5 text-[9px] leading-3 font-extrabold",
			children: "0"
		}),
		e.plus !== 0 && /* @__PURE__ */ l("span", {
			className: "absolute -bottom-1.5 left-1/2 -translate-x-1/2 rounded-md border border-ink bg-done-soft px-0.5 text-[9px] leading-3 font-extrabold",
			children: ["+", e.plus]
		})
	] });
	return !i || t !== n ? /* @__PURE__ */ c("span", {
		className: "relative inline-flex flex-none",
		children: o
	}) : /* @__PURE__ */ c("button", {
		type: "button",
		onClick: () => a(e),
		className: "relative inline-flex min-h-11 min-w-11 flex-none items-center justify-center rounded-lg shadow-[2px_2px_0_var(--color-ink)] transition-transform active:translate-y-0.5",
		children: o
	});
}
function Ne({ pub: e, priv: t, members: n, myRid: u, send: d }) {
	let f = i(), [p, m] = r(!1), h = e.seats.a === u ? "a" : e.seats.t === u ? "t" : null, g = (t) => {
		let r = e.seats[t];
		return r && n.find((e) => e.rid === r)?.name || f(t === "a" ? "games.incubo.sideA" : "games.incubo.sideT");
	}, _ = (e) => d(e), v = e.pending, y = !!(v && v.side === h), b = e.challenge, x = e.monster, S = "info", C = "", w;
	if (e.phase === "done") S = e.result === "win" ? "done" : "warn", C = f(e.result === "win" ? "games.incubo.resultWin" : "games.incubo.resultLose");
	else if (e.settle) S = "done", C = f("games.incubo.settleWin");
	else if (e.phase === "choose") S = "accent", C = f("games.incubo.chooseDream"), w = f(e.rem === 3 ? "games.incubo.chooseHint3" : "games.incubo.chooseHint");
	else if (y) S = "accent", C = $(v, f);
	else if (v) C = f("games.incubo.waitingOther"), w = g(v.side);
	else if (e.phase === "monster" && x) {
		let e = x.parts.filter((e) => e.defeated).length;
		e >= x.need ? (S = "accent", C = f("games.incubo.stopMonster")) : (S = "warn", C = f("games.incubo.monsterTitle")), w = `${f("games.incubo.monsterNeed", { n: x.need })} · ${e}/${x.parts.length}`;
	} else b && (["a", "t"].every((t) => e.solo && t !== h || b.courage[t] >= b.rc[t]) ? (S = "accent", C = f("games.incubo.stopWin")) : C = `${J.a} ${b.courage.a}/${b.rc.a} · ${J.t} ${b.courage.t}/${b.rc.t}`);
	let D = (t, n) => {
		if (!v || v.side !== h) return !1;
		let r = T(t.card, t.useSide);
		if (v.kind === "bothPick") return e.phase === "monster" || n === "play";
		if (v.kind !== "pick") return !1;
		switch (v.pow) {
			case "x2": return !0;
			case "negToZero": return (r?.v ?? 0) < 0;
			case "playToDeck":
			case "playToDeckDraw": return e.phase === "monster" || n === "play";
			case "copy": return !!r?.pow && r.pow !== "copy" && r.pow !== "fearDiscount" && r.pow !== "terrorShield";
			default: return !1;
		}
	}, O = (t) => {
		if (e.pending || t.powUsed) return !1;
		let n = T(t.card, t.useSide);
		return !(!n?.pow || n.mandatory || n.pow === "fearDiscount" || n.pow === "terrorShield" || e.phase === "monster" && (n.pow === "freePass" || n.pow === "freeElim"));
	}, k = (e, t) => {
		D(e, t) ? _({
			type: "resolve",
			uid: e.uid
		}) : O(e) && _({
			type: "power",
			uid: e.uid
		});
	}, A = (e, t) => D(e, t) || O(e);
	return /* @__PURE__ */ c(a, {
		adaptive: !0,
		className: "incubo-screen",
		banner: /* @__PURE__ */ l("div", {
			className: "incubo-banner flex flex-col gap-2",
			children: [/* @__PURE__ */ c(o, {
				tone: S,
				text: C,
				sub: w,
				chip: f("games.incubo.rem", { n: e.rem }),
				accent: E.accent
			}), /* @__PURE__ */ l("div", {
				className: "incubo-resources plate flex min-h-9 items-center gap-3 px-3 text-xs font-extrabold",
				children: [/* @__PURE__ */ l("span", {
					className: e.chime.reserve <= 10 ? "text-danger" : "",
					children: [
						"🔔 ",
						f("games.incubo.chime"),
						" ",
						/* @__PURE__ */ c("span", {
							className: "font-mono tabular-nums",
							children: e.chime.reserve
						})
					]
				}), /* @__PURE__ */ l("span", { children: [
					"😱 ",
					f("games.incubo.fearChime"),
					" ",
					/* @__PURE__ */ c("span", {
						className: "font-mono tabular-nums",
						children: e.chime.fear
					})
				] })]
			})]
		}),
		actions: /* @__PURE__ */ c("div", {
			className: "incubo-actions flex h-full items-center gap-2",
			children: /* @__PURE__ */ c(Fe, {
				pub: e,
				priv: t,
				mySide: h,
				myPending: y,
				confirmSurrender: p,
				setConfirmSurrender: m,
				act: _
			})
		}),
		actionsHeight: "incubo-actions-slot",
		children: /* @__PURE__ */ l("div", {
			className: `incubo-board frame min-h-full p-2 ${b ? "incubo-challenge-phase" : ""}`,
			children: [
				e.phase === "choose" && /* @__PURE__ */ c("div", {
					className: "incubo-choose flex flex-wrap justify-center gap-3 pt-2",
					children: e.options.map((t) => /* @__PURE__ */ c("button", {
						type: "button",
						onClick: () => _({
							type: "choose",
							card: t
						}),
						className: "min-h-11 cursor-pointer transition-transform active:translate-y-0.5",
						children: /* @__PURE__ */ c(Oe, {
							id: t,
							rem: e.rem
						})
					}, t))
				}),
				e.settle && /* @__PURE__ */ l("div", {
					className: "incubo-settle flex flex-col items-center gap-3 pt-6",
					children: [/* @__PURE__ */ c(Oe, {
						id: e.settle.dream,
						rem: e.rem,
						simple: !0,
						side: e.settle.winner,
						className: "w-32"
					}), /* @__PURE__ */ l("p", {
						className: "text-sm font-extrabold",
						children: [
							J[e.settle.winner],
							" ",
							f("games.incubo.settleGain", { name: g(e.settle.winner) })
						]
					})]
				}),
				b && /* @__PURE__ */ l("div", {
					className: "incubo-challenge plate mb-2 flex items-center gap-3 p-2",
					children: [/* @__PURE__ */ l("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ c("p", {
								className: "text-[10px] font-bold opacity-60",
								children: e.dreamTotal > 0 ? f("games.incubo.remProgress", {
									rem: e.rem,
									n: e.dreamNum,
									m: e.dreamTotal
								}) : f("games.incubo.remLeft", {
									rem: e.rem,
									n: e.dreamLeft
								})
							}),
							/* @__PURE__ */ c("p", {
								className: "section-label mt-0.5",
								children: f("games.incubo.targetCourage")
							}),
							/* @__PURE__ */ c("div", {
								className: "mt-0.5 flex gap-3",
								children: ["a", "t"].filter((t) => !e.solo || t === h).map((e) => {
									let t = b.courage[e] >= b.rc[e];
									return /* @__PURE__ */ c("div", {
										className: `rounded-lg px-2 py-1 ${t ? "bg-done-soft" : ""}`,
										children: /* @__PURE__ */ l("p", {
											className: "flex items-center gap-1 text-sm font-extrabold",
											children: [
												/* @__PURE__ */ c("span", { children: J[e] }),
												/* @__PURE__ */ l("span", {
													className: "font-mono text-base tabular-nums",
													children: [
														b.courage[e],
														"/",
														b.rc[e]
													]
												}),
												t && /* @__PURE__ */ c("span", {
													"aria-label": f("games.incubo.courageMet"),
													children: "✅"
												})
											]
										})
									}, e);
								})
							})
						]
					}), /* @__PURE__ */ l("div", {
						className: "flex flex-none flex-col items-center gap-0.5",
						children: [/* @__PURE__ */ c(Oe, {
							id: b.dream,
							rem: e.rem,
							simple: !0,
							side: e.growth,
							className: "w-16"
						}), /* @__PURE__ */ l("span", {
							className: "text-[10px] font-bold whitespace-nowrap opacity-75",
							children: [
								f("games.incubo.rewardLabel"),
								" → ",
								J[e.growth],
								g(e.growth)
							]
						})]
					})]
				}),
				x && /* @__PURE__ */ l("div", {
					className: "incubo-monster-parts mb-2 flex flex-col gap-2",
					children: [x.parts.map((t) => /* @__PURE__ */ c("div", {
						className: `incubo-monster-part plate p-2 ${t.defeated ? "bg-done-soft" : ""}`,
						children: /* @__PURE__ */ l("div", {
							className: "flex items-start gap-2",
							children: [/* @__PURE__ */ c(ke, {
								id: t.id,
								head: t.head,
								owner: t.head ? null : t.owner,
								rc: t.rc,
								courage: t.courage,
								defeated: t.defeated
							}), /* @__PURE__ */ l("div", {
								className: "flex min-w-0 flex-1 flex-col gap-1.5",
								children: [/* @__PURE__ */ l("div", {
									className: "flex items-center gap-2 text-xs font-extrabold",
									children: [
										/* @__PURE__ */ c("span", { children: t.head ? f("games.incubo.headLabel") : t.owner === "a" ? f("games.incubo.armLabelA") : f("games.incubo.armLabelT") }),
										t.defeated && /* @__PURE__ */ c("span", {
											className: "rounded bg-done-soft px-1 text-done-ink",
											children: f("games.incubo.defeatedTag")
										}),
										!t.defeated && h && !e.pending && /* @__PURE__ */ l("button", {
											type: "button",
											onClick: () => _({
												type: "draw",
												target: t.id
											}),
											disabled: x.freeLeft[h] <= 0 && e.chime.reserve < 1,
											className: "btn-base ml-auto min-h-9 px-3 text-xs text-white disabled:opacity-40",
											style: { background: E.accent },
											children: [f("games.incubo.drawTo"), x.freeLeft[h] <= 0 ? " 🔔1" : ""]
										})
									]
								}), t.cards.length > 0 && /* @__PURE__ */ c("div", {
									className: "flex items-end overflow-x-auto p-1 [&>*+*]:-ml-9",
									children: t.cards.map((e) => /* @__PURE__ */ c(Me, {
										c: e,
										side: e.useSide,
										mySide: h,
										actionable: A(e, "part"),
										onTap: (e) => k(e, "part")
									}, e.uid))
								})]
							})]
						})
					}, t.id)), /* @__PURE__ */ c("p", {
						className: "text-center text-xs font-bold opacity-70",
						children: f("games.incubo.freeLeft", { n: h ? x.freeLeft[h] : 0 })
					})]
				}),
				e.phase === "challenge" && [h, je(h ?? "a")].filter((t) => !!t && e.seats[t] !== null).map((t) => /* @__PURE__ */ l("div", {
					className: "incubo-side-group",
					children: [/* @__PURE__ */ c(Pe, {
						pub: e,
						side: t,
						mine: t === h,
						name: g(t),
						mySide: h,
						actionable: (e, t) => A(e, t),
						onTap: k
					}), t === h && b && /* @__PURE__ */ l("div", {
						className: "incubo-draw-zone mb-2 -mt-0.5 flex min-h-24 items-center gap-2 rounded-xl border-2 border-ink/20 px-2 py-1.5",
						children: [
							/* @__PURE__ */ c(De, {
								n: e.board[t].deck,
								className: "w-20",
								caption: b.freeLeft[t] > 0 ? f("games.incubo.freeLeft", { n: b.freeLeft[t] }) : "🔔1",
								disabled: !!e.pending || b.freeLeft[t] <= 0 && e.chime.reserve < 1 || e.board[t].deck + e.board[t].discard === 0,
								onClick: () => _({ type: "draw" })
							}),
							e.solo && e.board[t].companion > 0 && /* @__PURE__ */ c(De, {
								n: e.board[t].companion,
								className: "w-20",
								caption: `${f("games.incubo.companionShort")}🔔${b.freeLeft[t] > 0 ? 1 : 2}`,
								disabled: !!e.pending || e.chime.reserve < (b.freeLeft[t] > 0 ? 1 : 2),
								onClick: () => _({ type: "companion" })
							}),
							y && v.kind === "place" && v.card !== void 0 && v.useSide && /* @__PURE__ */ l(s, { children: [
								/* @__PURE__ */ c("span", {
									"aria-hidden": !0,
									className: "text-sm",
									children: "→"
								}),
								/* @__PURE__ */ c(Q, {
									card: v.card,
									useSide: v.useSide,
									className: "w-20"
								}),
								/* @__PURE__ */ c("span", {
									className: "min-w-0 flex-1 text-xs font-bold",
									children: $(v, f)
								})
							] })
						]
					})]
				}, t))
			]
		})
	});
}
function $(e, t) {
	switch (e.kind) {
		case "place": return e.fear ? t("games.incubo.fearDrawn") : t("games.incubo.placeTitle");
		case "look": return t(e.mode === "discard" ? "games.incubo.lookDiscardTitle" : e.mode === "box" ? "games.incubo.lookBoxTitle" : "games.incubo.lookReorderTitle", { n: e.lookCount ?? 3 });
		case "look2play": return t("games.incubo.look2playTitle");
		case "pick": return t(e.pow === "x2" ? "games.incubo.pickX2" : e.pow === "negToZero" ? "games.incubo.pickNegToZero" : e.pow === "copy" ? "games.incubo.pickCopy" : e.pow === "playToDeckDraw" ? "games.incubo.pickPlayToDeckDraw" : "games.incubo.pickPlayToDeck");
		case "twoN": return t("games.incubo.twoNTitle");
		case "chimeBuy": return t("games.incubo.chimeBuyTitle");
		case "bothPick": return t("games.incubo.bothPickTitle");
	}
}
function Pe({ pub: e, side: t, mine: n, name: r, mySide: a, actionable: o, onTap: s }) {
	let u = i(), d = e.board[t], f = [
		{
			key: "play",
			label: u("games.incubo.playRow")
		},
		{
			key: "pass",
			label: u("games.incubo.passRow")
		},
		{
			key: "elim",
			label: u("games.incubo.elimRow")
		}
	];
	return /* @__PURE__ */ l("section", {
		className: `incubo-side-board mb-2 rounded-xl border-2 p-1.5 ${n ? "border-ink bg-surface" : "border-ink/20"}`,
		children: [/* @__PURE__ */ l("p", {
			className: "incubo-side-header flex items-center gap-2 px-1 text-[11px] font-extrabold opacity-80",
			children: [/* @__PURE__ */ l("span", { children: [
				J[t],
				" ",
				r
			] }), /* @__PURE__ */ l("span", {
				className: "ml-auto flex gap-2 font-mono tabular-nums",
				children: [
					/* @__PURE__ */ c("span", { children: u("games.incubo.deckLabel", { n: d.deck }) }),
					/* @__PURE__ */ c("span", { children: u("games.incubo.discardLabel", { n: d.discard }) }),
					/* @__PURE__ */ c("span", { children: u("games.incubo.fearDeckLabel", { n: d.fearDeck }) }),
					e.solo && n && /* @__PURE__ */ c("span", { children: u("games.incubo.companionLabel", { n: d.companion }) })
				]
			})]
		}), f.map((e) => /* @__PURE__ */ l("div", {
			className: "incubo-card-row mt-1 flex items-center gap-1.5",
			children: [/* @__PURE__ */ c("span", {
				className: "incubo-row-label w-10 flex-none text-[10px] font-bold opacity-60",
				children: e.label
			}), /* @__PURE__ */ c("div", {
				className: "incubo-row-cards flex min-h-16 flex-1 items-end overflow-x-auto rounded-lg border border-dashed border-ink/20 p-1 [&>*+*]:-ml-9",
				children: d[e.key].map((r) => /* @__PURE__ */ c(Me, {
					c: r,
					side: t,
					mySide: a,
					displaySide: e.key === "pass" ? je(t) : void 0,
					actionable: n && o(r, e.key),
					onTap: (t) => s(t, e.key)
				}, r.uid))
			})]
		}, e.key))]
	});
}
function Fe({ pub: e, priv: t, mySide: n, myPending: r, confirmSurrender: a, setConfirmSurrender: o, act: u }) {
	let d = i(), f = e.pending, p = e.challenge, m = e.monster;
	if (!n || e.phase === "done" || e.phase === "choose") return /* @__PURE__ */ c("p", {
		className: "w-full text-center text-sm font-bold opacity-70",
		children: e.phase === "choose" ? d("games.incubo.chooseDream") : ""
	});
	if (e.settle) return /* @__PURE__ */ c("button", {
		type: "button",
		onClick: () => u({ type: "confirmSettle" }),
		className: "btn-base min-h-12 flex-1 px-3 text-base text-white",
		style: { background: E.accent },
		children: d("games.incubo.confirmNext")
	});
	if (f && r) {
		if (f.kind === "place" && f.card !== void 0 && f.useSide) {
			let t = f.fixedRow ?? (e.phase === "monster" ? "play" : null), r = !t && !f.fear && !!T(f.card, je(f.useSide)), i = !t && !f.fear, a = p ? p.passFree[n] > 0 : !1, o = p ? p.elimFree[n] > 0 : !1;
			return /* @__PURE__ */ l("div", {
				className: "flex min-w-0 flex-1 flex-wrap items-center justify-end gap-1.5",
				children: [
					!t || t === "play" ? /* @__PURE__ */ c("button", {
						type: "button",
						onClick: () => u({
							type: "place",
							row: "play"
						}),
						className: "btn-base min-h-11 flex-1 px-2 text-xs text-white",
						style: { background: E.accent },
						children: d("games.incubo.playRow")
					}) : null,
					r && /* @__PURE__ */ c("button", {
						type: "button",
						onClick: () => u({
							type: "place",
							row: "pass"
						}),
						disabled: !a && e.chime.reserve < 1,
						className: "btn-base min-h-11 flex-1 bg-surface px-2 text-xs disabled:opacity-40",
						children: d(a ? "games.incubo.placePassFree" : "games.incubo.placePassPaid")
					}),
					(i || t === "elim") && /* @__PURE__ */ c("button", {
						type: "button",
						onClick: () => u({
							type: "place",
							row: "elim"
						}),
						disabled: !o && e.chime.reserve < 1,
						className: "btn-base min-h-11 flex-1 bg-surface px-2 text-xs disabled:opacity-40",
						children: d(o ? "games.incubo.placeElimFree" : "games.incubo.placeElimPaid")
					}),
					f.fear && f.canRemove && /* @__PURE__ */ c("button", {
						type: "button",
						onClick: () => u({ type: "removeFear" }),
						title: d("games.incubo.removeFearHint"),
						className: "btn-base min-h-11 flex-1 bg-surface px-2 text-xs text-danger",
						children: d("games.incubo.removeFear", { n: Le(e, n) })
					})
				]
			});
		}
		if (f.kind === "look" && t.peek) return /* @__PURE__ */ c(Ie, {
			pub: e,
			peek: t.peek,
			act: u
		}, t.peek.join(","));
		if (f.kind === "look2play" && t.peek) return /* @__PURE__ */ c("div", {
			className: "flex flex-1 items-center gap-2 overflow-x-auto",
			children: t.peek.map((e, t) => /* @__PURE__ */ c("button", {
				type: "button",
				onClick: () => u({
					type: "resolve",
					pick: t
				}),
				className: "min-h-11 flex-none transition-transform active:translate-y-0.5",
				children: /* @__PURE__ */ c(Q, {
					card: e,
					useSide: n,
					className: "w-14"
				})
			}, e))
		});
		if (f.kind === "twoN" && f.options) return /* @__PURE__ */ c("div", {
			className: "flex flex-1 items-center gap-2 overflow-x-auto",
			children: f.options.map((e) => /* @__PURE__ */ l("button", {
				type: "button",
				onClick: () => u({
					type: "resolve",
					n: e
				}),
				className: "btn-base min-h-11 flex-1 bg-surface px-3 font-mono text-sm tabular-nums",
				children: ["+", e]
			}, e))
		});
		if (f.kind === "chimeBuy") return /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("button", {
			type: "button",
			onClick: () => u({
				type: "resolve",
				spend: 1
			}),
			className: "btn-base min-h-11 flex-1 bg-surface px-2 text-xs",
			children: d("games.incubo.chimeBuy1")
		}), /* @__PURE__ */ c("button", {
			type: "button",
			onClick: () => u({
				type: "resolve",
				spend: 2
			}),
			disabled: e.chime.reserve < 2,
			className: "btn-base min-h-11 flex-1 px-2 text-xs text-white disabled:opacity-40",
			style: { background: E.accent },
			children: d("games.incubo.chimeBuy2")
		})] });
		if (f.kind === "bothPick") {
			let t = e.phase !== "monster" && e.board[n].play.length === 0;
			return /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("p", {
				className: "flex-1 text-center text-xs font-bold opacity-70",
				children: d("games.incubo.bothPickTitle")
			}), t && /* @__PURE__ */ c("button", {
				type: "button",
				onClick: () => u({ type: "resolve" }),
				className: "btn-base min-h-11 bg-surface px-3 text-xs",
				children: d("games.incubo.bothPickSkip")
			})] });
		}
		return /* @__PURE__ */ c("p", {
			className: "w-full text-center text-sm font-bold opacity-70",
			children: $(f, d)
		});
	}
	if (f) return /* @__PURE__ */ c("p", {
		className: "w-full text-center text-sm font-bold opacity-70",
		children: d("games.incubo.waitingOther")
	});
	if (e.phase === "monster" && m) return m.parts.filter((e) => e.defeated).length >= m.need ? /* @__PURE__ */ c("button", {
		type: "button",
		onClick: () => u({ type: "stop" }),
		className: "btn-base min-h-12 flex-1 text-base text-white",
		style: { background: E.accent },
		children: d("games.incubo.stopMonster")
	}) : /* @__PURE__ */ l("button", {
		type: "button",
		onClick: () => {
			a ? (o(!1), u({ type: "stop" })) : o(!0);
		},
		className: `btn-base min-h-12 flex-1 px-3 text-sm ${a ? "text-white" : "bg-surface text-danger"}`,
		style: a ? { background: "var(--color-danger)" } : void 0,
		children: [d(a ? "games.incubo.surrenderConfirm" : "games.incubo.surrender"), m.votes.includes(n) ? ` · ${d("games.incubo.votes", { n: m.votes.length })}` : ""]
	});
	if (p) {
		let t = ["a", "t"].every((t) => e.solo && t !== n || p.courage[t] >= p.rc[t]), r = !e.solo && !p.infused[n] && p.courage[n] > p.rc[n], i = p.votes.includes(n);
		return /* @__PURE__ */ l(s, { children: [
			r && /* @__PURE__ */ c("button", {
				type: "button",
				onClick: () => u({ type: "infuse" }),
				className: "btn-base min-h-12 flex-1 bg-surface px-2 text-xs",
				children: d("games.incubo.infuse")
			}),
			/* @__PURE__ */ l("button", {
				type: "button",
				onClick: () => u({ type: "stop" }),
				disabled: i,
				className: `btn-base min-h-12 flex-1 px-2 text-sm disabled:opacity-40 ${t ? "text-white" : "bg-surface text-danger"}`,
				style: t ? { background: E.accent } : void 0,
				children: [d(t ? "games.incubo.stopWin" : i ? "games.incubo.stopVoted" : "games.incubo.stopVote"), !t && p.votes.length > 0 ? ` · ${d("games.incubo.votes", { n: p.votes.length })}` : ""]
			}),
			/* @__PURE__ */ c("button", {
				type: "button",
				onClick: () => u({ type: "draw" }),
				disabled: !!e.pending || p.freeLeft[n] <= 0 && e.chime.reserve < 1 || e.board[n].deck + e.board[n].discard === 0,
				className: "btn-base min-h-12 flex-2 px-3 text-base text-white disabled:opacity-40",
				style: { background: E.accent },
				children: d(p.freeLeft[n] > 0 ? "games.incubo.draw" : "games.incubo.drawPaid")
			})
		] });
	}
	return null;
}
function Ie({ pub: e, peek: t, act: n }) {
	let a = i(), o = e.pending, [s, u] = r(null), [d, f] = r([]);
	if (!o || o.kind !== "look") return null;
	let p = o.mode === "reorder", m = (e) => {
		if (p) {
			if (d.includes(e)) return;
			let r = [...d, e];
			f(r), r.length === t.length && n({
				type: "resolve",
				order: r
			});
			return;
		}
		if (s === null) {
			u(e);
			return;
		}
		if (e === s || d.includes(e)) return;
		let r = [...d, e];
		f(r), r.length === t.length - 1 && n({
			type: "resolve",
			pick: s,
			order: r
		});
	};
	return /* @__PURE__ */ l("div", {
		className: "flex flex-1 items-center gap-2 overflow-x-auto",
		children: [t.map((e, t) => {
			let n = d.indexOf(t), r = s === t;
			return /* @__PURE__ */ l("button", {
				type: "button",
				onClick: () => m(t),
				className: "relative min-h-11 flex-none transition-transform active:translate-y-0.5",
				children: [
					/* @__PURE__ */ c("span", {
						className: r ? "opacity-45" : "",
						children: /* @__PURE__ */ c(Q, {
							card: e,
							useSide: o.side,
							className: "w-14"
						})
					}),
					r && /* @__PURE__ */ c("span", {
						className: "absolute -top-2 -right-2 grid size-5 place-items-center rounded-full border border-ink bg-danger-soft text-[10px] font-extrabold",
						children: "✕"
					}),
					n >= 0 && /* @__PURE__ */ c("span", {
						className: "absolute -top-2 -right-2 grid size-5 place-items-center rounded-full border border-ink bg-surface font-mono text-[10px] font-extrabold",
						children: n + 1
					})
				]
			}, e);
		}), (d.length > 0 || s !== null) && /* @__PURE__ */ c("button", {
			type: "button",
			"aria-label": a("games.incubo.lookReset"),
			onClick: () => {
				u(null), f([]);
			},
			className: "btn-quiet min-h-11 flex-none px-2 text-xs",
			children: "↺"
		})]
	});
}
function Le(e, t) {
	return e.board[t].play.some((e) => !e.powUsed && T(e.card, e.useSide)?.pow === "fearDiscount") ? 1 : 2;
}
//#endregion
//#region src/games/incubo/game-over.tsx
function Re(e) {
	return /* @__PURE__ */ c("div", {
		className: "incubo-over",
		children: /* @__PURE__ */ c(u, {
			...e,
			accent: E.accent
		})
	});
}
//#endregion
//#region src/games/incubo/options.tsx
var ze = {
	a: "games.incubo.optAlpha",
	t: "games.incubo.optTommy"
};
function Be({ value: e, onChange: t }) {
	let n = i(), r = j.safeParse(e), a = r.success ? r.data : j.parse(void 0);
	return /* @__PURE__ */ c(f, {
		title: n("games.incubo.optSoloSide"),
		children: ["a", "t"].map((e) => /* @__PURE__ */ c(d, {
			name: "incubo-solo-side",
			value: e,
			checked: a.soloSide === e,
			label: n(ze[e]),
			accent: E.accent,
			onChange: () => t({
				...a,
				soloSide: e
			})
		}, e))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/incubo/entry.tsx
var Ve = {
	definition: Ce,
	View: Ae,
	OverView: Re,
	Options: Be,
	locales: {
		zh: {
			name: "梦魇",
			desc: "双人合作牌库构筑:在共享铃声耗尽前,协力击败三重梦境怪物",
			rules: "目标:与搭档合作,在共享铃声耗尽前击败三个阶段的怪物。\n· 击败第三阶段怪物即共同获胜;铃声储备需要支付却为空时,双方立即共同失败。\n准备:\n· 双方各持一套勇气牌库与恐惧牌库;共享铃声储备 50 枚(单人 35 枚)。\n· 梦卡洗混后按 6/12/6 分成三个阶段的梦库。\n流程:\n· 每场梦翻一张梦卡:需求勇气为梦卡己方一侧的羊值加自己的骰点。\n· 双方各自达标且都至少打出一张牌,才算击败这场梦。\n· 第一阶段直接翻顶牌;第二阶段抽二选一;第三阶段抽三选一。\n· 打牌不分回合:抽牌并打出到打出区,免费牌用尽后每抽一张花 1 铃声。\n· 也可放入传递行(梦结束交给对方)或淘汰行(移出游戏)。\n· 传递/淘汰行每场第一张免费,之后每张 1 铃声;无对方符号的卡不能传递。\n· 技能每次打出限用一次;标 * 的技能打出时强制立即结算。\n· 勇气超出自己的需求后,可给对方输送 1 点勇气(每场梦限一次)。\n· 恐惧卡只能进打出区,且技能强制发动。\n· 也可花 2 枚恐惧铃声移除恐惧卡,对方获得一张 2 点铃声卡。\n· 双方都同意放弃时结算恐惧:按需求勇气超出已打出勇气的差值失去铃声。\n· 失去的铃声中有一半进入恐惧储备。\n· 未击败的梦卡放入第三阶段梦库。\n· 梦库耗尽后怪物来袭:双方各获得一张恐惧卡,需在五个部位中击败三个。\n· 头部需求为基础值加两颗骰点,双方勇气合计。\n· 未击败的头部使双方各获得 1 张恐惧卡,未击败的手臂使所属方获得 1 张。\n· 单人局:只挑战自己侧的部位;传递行的卡在梦结束时进入同伴牌堆。\n· 可花 1 铃声从同伴牌堆抽 1 张放入淘汰行,按对方侧数值计勇气。\n结算:\n· 击败第三阶段怪物共同获胜,可按各自牌库勇气总值比较贡献。",
			sideA: "Alpha",
			sideT: "Tommy",
			rem: "REM {{n}}",
			chime: "铃声",
			fearChime: "恐惧铃声",
			deckLabel: "牌库 {{n}}",
			discardLabel: "弃牌 {{n}}",
			fearDeckLabel: "恐惧库 {{n}}",
			companionLabel: "同伴 {{n}}",
			freeLeft: "免费 {{n}}",
			waitingOther: "等对方完成操作…",
			votes: "放弃票 {{n}}",
			companionShort: "同伴",
			rewardShort: "奖",
			needShort: "需",
			freeShort: "免",
			chooseDream: "选择本场梦",
			chooseHint: "任一方选择;未选的卡扣置到第三阶段梦库",
			chooseHint3: "任一方选择;未选的卡移出游戏",
			targetCourage: "目标勇气",
			rewardLabel: "奖励",
			remProgress: "REM {{rem}} - {{n}}/{{m}}",
			remLeft: "REM {{rem}} - 剩 {{n}} 场",
			courageMet: "已达标",
			draw: "抽牌",
			drawPaid: "抽牌(花 1 铃声)",
			stopWin: "达成,收工!",
			stopVote: "放弃本梦",
			stopVoted: "已投放弃票,等对方…",
			infuse: "输送 1 点勇气给对方",
			passRow: "传递行",
			elimRow: "淘汰行",
			playRow: "打出区",
			placeTitle: "选择落位",
			placePassFree: "传递(免费)",
			placeElimFree: "淘汰(免费)",
			placePassPaid: "传递(1 铃声)",
			placeElimPaid: "淘汰(1 铃声)",
			fearDrawn: "抽到恐惧卡:只能进打出区,或花恐惧铃声移除",
			removeFear: "移除({{n}} 恐惧铃声)",
			removeFearHint: "移除后对方获得一张 2 点铃声卡",
			lookReorderTitle: "牌库顶 {{n}} 张:按「从顶到底」的顺序逐张点选",
			lookDiscardTitle: "选择 1 张弃掉,其余按点选顺序放回牌库顶",
			lookBoxTitle: "选择 1 张移出游戏,其余按点选顺序放回牌库顶",
			lookReset: "重选",
			look2playTitle: "选择 1 张打出,另一张弃掉",
			pickX2: "选择 1 张卡,其印刷值算两次",
			pickNegToZero: "选择 1 张负值卡升为 0",
			pickPlayToDeck: "选择打出区 1 张卡放回牌库底",
			pickPlayToDeckDraw: "选择打出区 1 张卡放回牌库底,再抽打 1 张",
			pickCopy: "选择要复制技能的卡",
			twoNTitle: "选择一对同值卡,其中一张的数值加 N",
			chimeBuyTitle: "花铃声强化此卡",
			chimeBuy1: "花 1 铃声:勇气加 1",
			chimeBuy2: "花 2 铃声:勇气加 3",
			bothPickTitle: "选择打出区 1 张卡回牌库底",
			bothPickSkip: "跳过(无可回的卡)",
			monsterTitle: "怪物出现!",
			monsterNeed: "击败 {{n}} 个部位即胜",
			headLabel: "头部",
			armLabelA: "Alpha 臂",
			armLabelT: "Tommy 臂",
			defeatedTag: "已击败",
			drawTo: "打牌",
			stopMonster: "结束战斗",
			surrender: "投降",
			surrenderConfirm: "再点一次确认投降(立即输掉本局)",
			settleWin: "梦已击败!",
			settleGain: "{{name}} 获得这张奖励卡",
			confirmNext: "进入下一场梦",
			resultWin: "梦魇消散,天亮了!",
			resultLose: "铃声耗尽,被梦魇吞噬…",
			scoreLabel: "牌库总勇气 {{n}}",
			powDrawPlay: "抽打 {{n}} 张",
			powChime: "获得 {{n}} 铃声",
			powX2: "一张卡值算两次",
			powLook3reorder: "看顶 3 张排序放回",
			powLook3discard: "看顶 3 张弃 1",
			powLook3box: "看顶 3 张回盒 1",
			powLook2play: "看顶 2 张打 1 弃 1",
			powDiscardDraw: "弃牌堆随机抽打 1 张",
			powFreePass: "传递行免费次数加 1",
			powFreeElim: "淘汰行免费次数加 1",
			powPlayToDeck: "打出区 1 张回库底",
			powPlayToDeckDraw: "回库底 1 张再抽打",
			powBothPlayToDeck: "双方各回 1 张",
			powFearDiscount: "被动:移除恐惧只花 1",
			powTwoN: "同值成对则数值加 N",
			powChimeBuy: "花铃声得勇气",
			powNegToZero: "负值卡升为 0",
			powInfuse: "给对方输送 1 点勇气",
			powTerrorShield: "被动:恐惧减 {{n}}",
			powCopy: "复制另一张卡技能",
			powMax0: "最强卡变为 0",
			powMinDiscard: "弃掉最小正值卡",
			powLoseChime: "失去 1 铃声",
			mandatoryTag: "强制",
			psDrawPlay: "抽打{{n}}",
			psChime: "铃+{{n}}",
			psX2: "翻倍",
			psLook3reorder: "看3排序",
			psLook3discard: "看3弃1",
			psLook3box: "看3回盒",
			psLook2play: "看2打1",
			psDiscardDraw: "弃堆抽打",
			psFreePass: "传递免费",
			psFreeElim: "淘汰免费",
			psPlayToDeck: "回库底",
			psPlayToDeckDraw: "回库再抽",
			psBothPlayToDeck: "双方回库",
			psFearDiscount: "除惧折扣",
			psTwoN: "对子+{{n}}",
			psChimeBuy: "铃换勇气",
			psNegToZero: "负归0",
			psInfuse: "输送+1",
			psTerrorShield: "恐惧盾-{{n}}",
			psCopy: "复制技能",
			psMax0: "最强归0",
			psMinDiscard: "弃最小",
			psLoseChime: "失1铃",
			optSoloSide: "扮演角色(单人局)",
			optAlpha: "Alpha(猫)",
			optTommy: "Tommy(小孩)",
			errPhase: "当前阶段不能这么做",
			errPending: "先完成当前操作",
			errNoChime: "铃声不足",
			errNoCards: "无牌可抽",
			errNoPass: "这张卡没有对方数值,不能传递",
			errFearRow: "恐惧卡只能进打出区",
			errRow: "这张卡不能放到这一行",
			errNeedPlay: "双方都至少打出一张牌才能收工",
			errNoTarget: "没有合法目标",
			errUsed: "已经用过了",
			errNoPower: "这张卡没有可发动的技能",
			errPassive: "被动技能无需发动",
			errBadOrder: "顺序无效"
		},
		en: {
			name: "Incubo",
			desc: "Co-op deck-building for two: defeat the monsters of three R.E.M. phases before the shared chimes run out",
			rules: "Goal: cooperate to defeat the monsters of three phases before the shared chimes run out.\n· Defeat the Phase 3 monster to win together; if the supply is empty when chimes must be spent, both lose at once.\nSetup:\n· Each player has a Courage deck and a Fear deck; the shared supply holds 50 chimes (35 solo).\n· Dream Cards are shuffled into three phase decks of 6/12/6.\nFlow:\n· Each dream reveals one Dream Card: your Required Courage is the sheep value on your side of the card plus your die roll.\n· Both players must meet their own requirement and play at least one card to beat the dream.\n· Phase 1 flips the top card; Phase 2 draws 2 and keeps 1; Phase 3 draws 3 and keeps 1.\n· No turns: draw and play into your Play row; once free cards run out, each draw costs 1 chime.\n· Or play to the Pass row (handed over at dream end) or Elimination row (removed from game).\n· First card per row per dream is free, later ones cost 1 chime; no partner symbol, no passing.\n· Each power works once per play; powers marked * are mandatory and resolve at once.\n· Once your courage exceeds your need, you may infuse 1 courage to your partner (once per dream).\n· Fear Cards go to the Play row only, and their powers trigger at once.\n· Or spend 2 fear chimes to remove a Fear Card; your partner gains a 2-chime card.\n· If both vote to abandon, Terror strikes: you lose chimes equal to the courage shortfall below the requirement.\n· Half of the chimes lost go to the fear reserve.\n· An unbeaten Dream Card goes into the Phase 3 deck.\n· When a phase deck runs out, the monster attacks: both gain a Fear Card; defeat 3 of 5 parts.\n· The head’s requirement is its base value plus two dice, with both players’ courage combined.\n· An undefeated head gives both players 1 Fear Card; an undefeated arm gives its owner 1.\n· Solo: face only your own parts; cards in the Pass row go to the Companion deck at dream end.\n· Spend 1 chime to draw 1 card from the Companion deck into the Elimination row, counting its partner-side value.\nScoring:\n· Defeat the Phase 3 monster to win; compare total deck courage for bragging rights.",
			sideA: "Alpha",
			sideT: "Tommy",
			rem: "REM {{n}}",
			chime: "Chimes",
			fearChime: "Fear chimes",
			deckLabel: "Deck {{n}}",
			discardLabel: "Discard {{n}}",
			fearDeckLabel: "Fear {{n}}",
			companionLabel: "Companion {{n}}",
			freeLeft: "Free {{n}}",
			waitingOther: "Waiting for your partner…",
			votes: "Abandon votes {{n}}",
			companionShort: "Buddy",
			rewardShort: "Value",
			needShort: "Need ",
			freeShort: "Free ",
			chooseDream: "Choose this dream",
			chooseHint: "Either player chooses; the rest go face-down into the Phase 3 deck",
			chooseHint3: "Either player chooses; the rest are removed from the game",
			targetCourage: "Target courage",
			rewardLabel: "Reward",
			remProgress: "REM {{rem}} - {{n}}/{{m}}",
			remLeft: "REM {{rem}} - {{n}} left",
			courageMet: "Met",
			draw: "Draw",
			drawPaid: "Draw (1 chime)",
			stopWin: "Dream beaten!",
			stopVote: "Abandon dream",
			stopVoted: "Voted to abandon, waiting…",
			infuse: "Infuse 1 courage to partner",
			passRow: "Pass",
			elimRow: "Elim",
			playRow: "Play",
			placeTitle: "Choose a row",
			placePassFree: "Pass (free)",
			placeElimFree: "Eliminate (free)",
			placePassPaid: "Pass (1 chime)",
			placeElimPaid: "Eliminate (1 chime)",
			fearDrawn: "Fear Card: Play row only, or remove it with fear chimes",
			removeFear: "Remove ({{n}} fear chimes)",
			removeFearHint: "Your partner gains a 2-chime card",
			lookReorderTitle: "Top {{n}} of deck: tap in top-to-bottom order",
			lookDiscardTitle: "Discard 1; tap the rest in top-to-bottom order",
			lookBoxTitle: "Remove 1 from the game; tap the rest in top-to-bottom order",
			lookReset: "Reset",
			look2playTitle: "Play 1, discard the other",
			pickX2: "Choose a card: its printed value counts twice",
			pickNegToZero: "Choose a negative card: raise it to 0",
			pickPlayToDeck: "Return a Play-row card to the deck bottom",
			pickPlayToDeckDraw: "Return a Play-row card, then draw & play",
			pickCopy: "Choose a card whose power to copy",
			twoNTitle: "Choose a matching pair: add N to one of them",
			chimeBuyTitle: "Spend chimes to empower this card",
			chimeBuy1: "Spend 1 chime: +1 courage",
			chimeBuy2: "Spend 2 chimes: +3 courage",
			bothPickTitle: "Return a Play-row card to the deck bottom",
			bothPickSkip: "Skip (nothing to return)",
			monsterTitle: "The monster attacks!",
			monsterNeed: "Defeat {{n}} parts to win",
			headLabel: "Head",
			armLabelA: "Alpha's arm",
			armLabelT: "Tommy's arm",
			defeatedTag: "Defeated",
			drawTo: "Play here",
			stopMonster: "End battle",
			surrender: "Surrender",
			surrenderConfirm: "Tap again to surrender (loses the game)",
			settleWin: "Dream beaten!",
			settleGain: "{{name}} takes this card",
			confirmNext: "Next dream",
			resultWin: "The nightmare fades. Morning comes!",
			resultLose: "Out of chimes… the nightmare devours you.",
			scoreLabel: "Deck courage {{n}}",
			powDrawPlay: "Draw & play {{n}}",
			powChime: "Gain {{n}} chimes",
			powX2: "A card counts twice",
			powLook3reorder: "Reorder top 3",
			powLook3discard: "Top 3: discard 1",
			powLook3box: "Top 3: box 1",
			powLook2play: "Top 2: play 1, discard 1",
			powDiscardDraw: "Random discard draw & play",
			powFreePass: "1 extra free Pass",
			powFreeElim: "1 extra free Elim",
			powPlayToDeck: "Play-row card to deck bottom",
			powPlayToDeckDraw: "Return 1, draw & play",
			powBothPlayToDeck: "Both return 1",
			powFearDiscount: "Passive: fear removal costs 1",
			powTwoN: "Matching pair: add N",
			powChimeBuy: "Chimes into courage",
			powNegToZero: "Negative card becomes 0",
			powInfuse: "Infuse 1 courage to partner",
			powTerrorShield: "Passive: Terror reduced by {{n}}",
			powCopy: "Copy another power",
			powMax0: "Strongest card becomes 0",
			powMinDiscard: "Discard smallest positive",
			powLoseChime: "Lose 1 chime",
			mandatoryTag: "Auto",
			psDrawPlay: "Draw {{n}}",
			psChime: "+{{n}} chime",
			psX2: "Double",
			psLook3reorder: "Top3 sort",
			psLook3discard: "Top3 -1",
			psLook3box: "Top3 box1",
			psLook2play: "Top2 play1",
			psDiscardDraw: "Dig discard",
			psFreePass: "Free pass",
			psFreeElim: "Free elim",
			psPlayToDeck: "To deck",
			psPlayToDeckDraw: "Deck+draw",
			psBothPlayToDeck: "Both to deck",
			psFearDiscount: "Fear -1",
			psTwoN: "Pair +{{n}}",
			psChimeBuy: "Chime buy",
			psNegToZero: "Neg to 0",
			psInfuse: "Infuse +1",
			psTerrorShield: "Shield -{{n}}",
			psCopy: "Copy",
			psMax0: "Max to 0",
			psMinDiscard: "Drop min",
			psLoseChime: "-1 chime",
			optSoloSide: "Play as (solo)",
			optAlpha: "Alpha (cat)",
			optTommy: "Tommy (kid)",
			errPhase: "Not allowed right now",
			errPending: "Finish the current action first",
			errNoChime: "Not enough chimes",
			errNoCards: "No cards to draw",
			errNoPass: "No partner value — cannot pass",
			errFearRow: "Fear Cards go to the Play row only",
			errRow: "This card cannot go there",
			errNeedPlay: "Both must play at least 1 card",
			errNoTarget: "No valid target",
			errUsed: "Already used",
			errNoPower: "No power to activate",
			errPassive: "Passive power — no activation",
			errBadOrder: "Invalid order"
		}
	}
};
//#endregion
export { Ve as default };
