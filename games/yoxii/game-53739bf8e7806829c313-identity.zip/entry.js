import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { useWakeLock as c } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { seatName as u } from "@bgparty/sdk/ui/player-strip";
import { jsx as d, jsxs as f } from "react/jsx-runtime";
import { usePrefersReducedMotion as p } from "@bgparty/sdk/fx/use-reduced-motion";
import { FlySprite as m } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as h } from "@bgparty/sdk/confirm-button";
//#region src/games/yoxii/meta.ts
var g = {
	id: "yoxii",
	tier: "alpha",
	mechanics: ["grid-movement", "area-control"],
	interactionTags: [],
	nameKey: "games.yoxii.name",
	descKey: "games.yoxii.desc",
	rulesKey: "games.yoxii.rules",
	icon: "🟡",
	iconImg: "games/yoxii.webp",
	rulesUrl: { en: "https://cdn.shopify.com/s/files/1/0917/7972/7689/files/Yoxii-ML9-25.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#17844a",
	releasedAt: "2026-11-03T01:31:00+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "open"
}, _ = Array.from({ length: 49 }, (e, t) => t).filter((e) => Math.abs(Math.floor(e / 7) - 3) + Math.abs(e % 7 - 3) <= 4), v = new Set(_), y = [
	-1,
	0,
	1
].flatMap((e) => [
	-1,
	0,
	1
].filter((t) => e !== 0 || t !== 0).map((t) => [e, t])), b = (e, t) => e === 0 ? t : -t, x = (e) => e > 0 ? 0 : 1;
function S(e, t, n) {
	let r = Math.floor(e / 7) + t, i = e % 7 + n, a = r * 7 + i;
	return r >= 0 && r < 7 && i >= 0 && i < 7 && v.has(a) ? a : null;
}
function C(e) {
	return y.flatMap(([t, n]) => {
		let r = S(e, t, n);
		return r === null ? [] : [r];
	});
}
function w(e, t) {
	let n = [];
	for (let [r, i] of y) {
		let a = S(e.totem, r, i);
		for (; a !== null && e.board[a] !== 0 && x(e.board[a]) === t;) a = S(a, r, i);
		a !== null && e.board[a] === 0 && n.push(a);
	}
	return n;
}
function T(e) {
	let t = C(e.totem).filter((t) => e.board[t] === 0);
	return t.length ? t : _.filter((t) => t !== e.totem && e.board[t] === 0);
}
function E(e) {
	let t = [{
		score: 0,
		count: 0,
		cells: []
	}, {
		score: 0,
		count: 0,
		cells: []
	}];
	for (let n of C(e.totem)) {
		let r = e.board[n];
		if (!r) continue;
		let i = t[x(r)];
		i.score += Math.abs(r), i.count += 1, i.cells.push(n);
	}
	return t;
}
function D(e) {
	let [t, n] = E(e);
	return t.score - n.score || t.count - n.count;
}
function O(e, t, n = !0) {
	return (n ? w(e, t) : [e.totem]).flatMap((n) => T({
		...e,
		totem: n
	}).flatMap((r) => e.hands[t].flatMap((e, t) => e > 0 ? [{
		move: n,
		cell: r,
		value: t + 1
	}] : [])));
}
function k(e, t, n) {
	let r = [...e.board], i = [[...e.hands[0]], [...e.hands[1]]];
	return r[n.cell] = b(t, n.value), --i[t][n.value - 1], {
		board: r,
		hands: i,
		totem: n.move
	};
}
//#endregion
//#region src/games/yoxii/schema.ts
var A = t.int().min(0).max(48), j = t.int().nonnegative(), M = t.union([t.literal(0), t.literal(1)]), N = t.tuple([
	t.int().min(0).max(5),
	t.int().min(0).max(5),
	t.int().min(0).max(5),
	t.int().min(0).max(3)
]), P = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("move"),
		cell: A,
		revision: j
	}),
	t.object({
		type: t.literal("place"),
		cell: A,
		value: t.int().min(1).max(4),
		revision: j
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number().finite()
	})
]), F = t.object({
	board: t.array(t.int().min(-4).max(4)).length(49),
	hands: t.tuple([N, N]),
	totem: A,
	players: t.tuple([t.string(), t.string()]),
	turn: M,
	phase: t.enum([
		"move",
		"moving",
		"place",
		"placing",
		"done"
	]),
	revision: j,
	last: t.object({
		type: t.enum(["move", "place"]),
		from: A,
		cell: A,
		value: t.int().min(0).max(4),
		side: M
	}).nullable()
}), I = t.object({}), L = {
	move: 360,
	place: 360
}, R = {
	meta: g,
	saveCompatibility: { version: "1" },
	schemas: {
		action: P,
		publicView: F,
		privateView: I
	},
	setup(t, n, r) {
		let i = e(r, 0, 2) === 0 ? n : [...n].reverse();
		return { state: {
			board: Array(49).fill(0),
			hands: [[
				5,
				5,
				5,
				3
			], [
				5,
				5,
				5,
				3
			]],
			totem: 24,
			players: [i[0], i[1]],
			turn: 0,
			phase: "move",
			revision: 0,
			last: null
		} };
	},
	reduce(e, t, n) {
		if (t.type === "tick") {
			if (n.by !== "$engine") return { code: "games.yoxii.errTurn" };
			if (e.phase === "moving") return { state: {
				...e,
				phase: "place",
				revision: e.revision + 1
			} };
			if (e.phase !== "placing") return { state: e };
			let t = 1 - e.turn;
			return { state: {
				...e,
				turn: t,
				phase: w(e, t).length ? "move" : "done",
				revision: e.revision + 1
			} };
		}
		if (e.players[e.turn] !== n.by || e.phase === "done") return { code: "games.yoxii.errTurn" };
		if (t.revision !== e.revision) return { code: "games.yoxii.errStale" };
		let r = { code: "games.yoxii.errTarget" };
		if (t.type === "move") return e.phase !== "move" || !w(e, e.turn).includes(t.cell) ? r : {
			state: {
				...e,
				totem: t.cell,
				phase: "moving",
				revision: e.revision + 1,
				last: {
					type: "move",
					from: e.totem,
					cell: t.cell,
					value: 0,
					side: e.turn
				}
			},
			fx: [{
				kind: "moveTotem",
				rid: n.by,
				data: {
					from: e.totem,
					cell: t.cell
				}
			}]
		};
		if (e.phase !== "place" || !T(e).includes(t.cell) || e.hands[e.turn][t.value - 1] <= 0) return r;
		let i = [...e.board], a = [[...e.hands[0]], [...e.hands[1]]];
		return i[t.cell] = b(e.turn, t.value), --a[e.turn][t.value - 1], {
			state: {
				...e,
				board: i,
				hands: a,
				phase: "placing",
				revision: e.revision + 1,
				last: {
					type: "place",
					from: e.totem,
					cell: t.cell,
					value: t.value,
					side: e.turn
				}
			},
			fx: [{
				kind: "placePiece",
				rid: n.by,
				data: {
					side: e.turn,
					value: t.value,
					cell: t.cell
				}
			}]
		};
	},
	viewFor(e) {
		return {
			public: structuredClone(e),
			private: {}
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = D(e), n = t >= 0 ? [...e.players] : [...e.players].reverse(), r = E(e);
		return {
			phase: "done",
			ranking: n,
			winner: t === 0 ? [...e.players] : [n[0]],
			scores: Object.fromEntries(e.players.map((e, t) => [e, r[t].score]))
		};
	},
	nextTickIn(e) {
		return e.phase === "moving" ? L.move : e.phase === "placing" ? L.place : null;
	}
};
//#endregion
//#region src/games/yoxii/art.tsx
function z({ value: e }) {
	return e === 1 ? /* @__PURE__ */ d("circle", {
		cx: "50",
		cy: "46",
		r: "17",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "6"
	}) : e === 2 ? /* @__PURE__ */ d("path", {
		d: "M29 39H71M29 53H71",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "6",
		strokeLinecap: "round"
	}) : /* @__PURE__ */ d("path", {
		d: e === 3 ? "M30 26L50 47L70 26M50 47V68" : "M31 27L69 65M69 27L31 65",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "7",
		strokeLinecap: "round",
		strokeLinejoin: "round"
	});
}
function B({ side: e, value: t, style: n }) {
	let r = e === 0;
	return /* @__PURE__ */ f("svg", {
		className: "yoxii-piece",
		viewBox: "0 0 100 100",
		"aria-hidden": "true",
		style: n,
		children: [
			/* @__PURE__ */ d("ellipse", {
				cx: "50",
				cy: "61",
				rx: "43",
				ry: "35",
				fill: "#171c19",
				opacity: ".22"
			}),
			/* @__PURE__ */ d("path", {
				d: "M8 43V53C8 74 26 88 50 88S92 74 92 53V43Z",
				fill: r ? "#a7b0a4" : "#a92c20"
			}),
			/* @__PURE__ */ d("ellipse", {
				cx: "50",
				cy: "44",
				rx: "42",
				ry: "36",
				fill: r ? "#e6e8df" : "#e9563b"
			}),
			/* @__PURE__ */ d("path", {
				d: "M18 31C30 13 59 10 78 26",
				fill: "none",
				stroke: r ? "#fffef5" : "#ff9b78",
				strokeWidth: "3",
				strokeLinecap: "round",
				opacity: ".65"
			}),
			/* @__PURE__ */ d("g", {
				color: "#252a29",
				children: /* @__PURE__ */ d(z, { value: t })
			})
		]
	});
}
function V({ style: e }) {
	return /* @__PURE__ */ f("svg", {
		className: "yoxii-totem",
		viewBox: "0 0 100 100",
		"aria-hidden": "true",
		style: e,
		children: [
			/* @__PURE__ */ d("ellipse", {
				cx: "50",
				cy: "79",
				rx: "35",
				ry: "15",
				fill: "#151c17",
				opacity: ".3"
			}),
			/* @__PURE__ */ d("path", {
				d: "M19 28V71C19 90 81 90 81 71V28Z",
				fill: "#d2af18"
			}),
			/* @__PURE__ */ d("path", {
				d: "M25 30V69C25 78 39 80 45 80V34Z",
				fill: "#f1d827"
			}),
			/* @__PURE__ */ d("ellipse", {
				cx: "50",
				cy: "28",
				rx: "31",
				ry: "19",
				fill: "#0b6135",
				stroke: "#e7ce21",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ d("ellipse", {
				cx: "50",
				cy: "26",
				rx: "27",
				ry: "15",
				fill: "#17844a"
			}),
			/* @__PURE__ */ f("g", {
				transform: "translate(50 26) scale(1 .55)",
				fill: "#f3dc2a",
				children: [[
					0,
					45,
					90,
					135
				].map((e) => /* @__PURE__ */ d("ellipse", {
					rx: "7",
					ry: "23",
					transform: `rotate(${e})`
				}, e)), /* @__PURE__ */ d("circle", { r: "8" })]
			})
		]
	});
}
//#endregion
//#region src/games/yoxii/board.tsx
var H = new Set(_);
function U({ cell: e, pub: t, legal: n, selected: r, onCell: i, scoring: o }) {
	let c = s(), l = p(), { ref: u } = a(`yoxii-cell:${e}`), { ref: m, hidden: h } = a(`yoxii-piece:${e}`), { ref: g, hidden: _ } = a(e === t.totem ? "yoxii-totem" : null), v = t.board[e], y = {
		row: Math.floor(e / 7) + 1,
		col: e % 7 + 1
	}, b = e === t.totem ? c("games.yoxii.totem") : v ? c("games.yoxii.pieceAria", {
		color: c(v > 0 ? "games.yoxii.white" : "games.yoxii.red"),
		n: Math.abs(v)
	}) : c("games.yoxii.empty"), S = n ? t.phase === "move" ? c("games.yoxii.moveAria", y) : c("games.yoxii.placeAria", {
		...y,
		n: r ?? 0
	}) : c("games.yoxii.cellAria", {
		...y,
		piece: b
	});
	return /* @__PURE__ */ d("div", {
		className: "yoxii-square",
		"data-checker": (Math.floor(e / 7) + e % 7) % 2,
		children: H.has(e) && /* @__PURE__ */ f("button", {
			type: "button",
			className: "yoxii-cell",
			ref: u,
			disabled: !n,
			"aria-label": S,
			onClick: () => i(e),
			"data-scoring": o,
			children: [
				/* @__PURE__ */ d("svg", {
					className: "yoxii-cell-ring",
					viewBox: "0 0 100 100",
					"aria-hidden": "true",
					children: /* @__PURE__ */ d("circle", {
						cx: "50",
						cy: "50",
						r: "38"
					})
				}),
				n && /* @__PURE__ */ d("svg", {
					className: "yoxii-target",
					viewBox: "0 0 100 100",
					"aria-hidden": "true",
					children: /* @__PURE__ */ d("circle", {
						cx: "50",
						cy: "50",
						r: "41",
						children: !l && /* @__PURE__ */ d("animate", {
							attributeName: "stroke-dashoffset",
							from: "0",
							to: "-24",
							dur: ".9s",
							repeatCount: "indefinite"
						})
					})
				}),
				/* @__PURE__ */ d("span", {
					className: "yoxii-object",
					ref: m,
					style: { visibility: h ? "hidden" : void 0 },
					children: v !== 0 && /* @__PURE__ */ d(B, {
						side: x(v),
						value: Math.abs(v)
					})
				}),
				e === t.totem && /* @__PURE__ */ d("span", {
					className: "yoxii-object",
					ref: g,
					style: { visibility: _ ? "hidden" : void 0 },
					children: /* @__PURE__ */ d(V, {})
				})
			]
		})
	});
}
function W({ pub: e, targets: t = [], selected: n = null, onCell: r = () => {}, scoring: i = [] }) {
	return /* @__PURE__ */ d("div", {
		className: "yoxii-board-zone",
		children: /* @__PURE__ */ d("div", {
			className: "yoxii-board",
			style: { "--yoxii-board-cols": 7 },
			children: e.board.map((a, o) => /* @__PURE__ */ d(U, {
				cell: o,
				pub: e,
				legal: t.includes(o),
				selected: n,
				onCell: r,
				scoring: i.includes(o)
			}, o))
		})
	});
}
//#endregion
//#region src/games/yoxii/view-player.tsx
function G({ side: e, value: t, count: n, active: r, selected: i, onSelect: o }) {
	let c = s(), { ref: l } = a(`yoxii-stock:${e}:${t}`);
	return /* @__PURE__ */ f("button", {
		type: "button",
		className: "yoxii-stock",
		disabled: !r || n === 0,
		"aria-pressed": i,
		onClick: o,
		"aria-label": c("games.yoxii.reserveAria", {
			color: c(e === 0 ? "games.yoxii.white" : "games.yoxii.red"),
			n: t,
			count: n
		}),
		children: [/* @__PURE__ */ d("span", {
			className: "yoxii-stock-art",
			ref: l,
			children: /* @__PURE__ */ d(B, {
				side: e,
				value: t
			})
		}), /* @__PURE__ */ f("span", {
			className: "yoxii-stock-label",
			children: [/* @__PURE__ */ d("b", { children: t === 1 ? c("games.yoxii.onePoint") : c("games.yoxii.points", { n: t }) }), /* @__PURE__ */ f("span", { children: ["×", n] })]
		})]
	});
}
function K({ public: e, members: t, myRid: n, send: r }) {
	let a = e, p = s(), m = o((e) => e.locale);
	c();
	let [h, g] = i(null), _ = h?.revision === a.revision ? h.value : null, v = a.players[a.turn] === n, y = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? u(n, m) : e;
	}, b = y(a.players[a.turn]), x = a.turn === 0 ? p("games.yoxii.white") : p("games.yoxii.red"), S = a.phase === "moving" ? p("games.yoxii.moving") : a.phase === "placing" ? p("games.yoxii.placing") : a.phase === "move" ? p("games.yoxii.move") : p(_ === null ? "games.yoxii.choose" : "games.yoxii.place"), C = v ? a.phase === "move" ? w(a, a.turn) : a.phase === "place" && _ !== null ? T(a) : [] : [], E = (e) => {
		C.includes(e) && (a.phase === "move" ? r({
			type: "move",
			cell: e,
			revision: a.revision
		}) : _ !== null && r({
			type: "place",
			cell: e,
			value: _,
			revision: a.revision
		}));
	}, D = +(a.players[1] === n), O = [1 - D, D];
	return /* @__PURE__ */ d(l, {
		adaptive: !0,
		scroll: !1,
		className: "yoxii-screen",
		banner: /* @__PURE__ */ f("header", {
			className: "yoxii-header",
			children: [/* @__PURE__ */ d("h1", { children: "YOXII" }), /* @__PURE__ */ f("div", {
				className: "yoxii-turn",
				children: [/* @__PURE__ */ d("span", { children: p("games.yoxii.turn", {
					name: b,
					color: x
				}) }), /* @__PURE__ */ d("strong", {
					"aria-live": "polite",
					children: v || a.phase === "moving" || a.phase === "placing" ? S : p("games.yoxii.waiting", { name: b })
				})]
			})]
		}),
		children: /* @__PURE__ */ f("div", {
			className: "yoxii-stage",
			children: [O.map((e, t) => /* @__PURE__ */ f("section", {
				className: "yoxii-reserve",
				"data-position": t,
				"data-current": a.turn === e,
				"aria-label": p(e === 0 ? "games.yoxii.white" : "games.yoxii.red"),
				children: [/* @__PURE__ */ f("h2", { children: [
					/* @__PURE__ */ d("span", {
						className: "yoxii-side-dot",
						"data-side": e,
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ d("span", { children: y(a.players[e]) }),
					/* @__PURE__ */ d("small", { children: p(e === 0 ? "games.yoxii.white" : "games.yoxii.red") })
				] }), /* @__PURE__ */ d("div", {
					className: "yoxii-stocks",
					children: a.hands[e].map((t, n) => /* @__PURE__ */ d(G, {
						side: e,
						value: n + 1,
						count: t,
						active: v && a.phase === "place" && e === a.turn,
						selected: e === a.turn && _ === n + 1,
						onSelect: () => g({
							revision: a.revision,
							value: n + 1
						})
					}, n))
				})]
			}, e)), /* @__PURE__ */ d(W, {
				pub: a,
				targets: C,
				selected: _,
				onCell: E
			})]
		})
	});
}
//#endregion
//#region src/games/yoxii/bot.ts
var q = {
	points: 4,
	pieces: 1,
	mobility: 1,
	replies: 8
};
function J(e, t, n = q) {
	let r = t === 0 ? 1 : -1, i = 1 - t;
	if (!w(e, i).length) return Math.sign(D(e)) * r * 1e5;
	let a = E(e);
	return (a[t].score - a[i].score) * n.points + (a[t].count - a[i].count) * n.pieces + (w(e, t).length - w(e, i).length) * n.mobility;
}
function Y(e, t, n = !0, r = q) {
	return O(e, t, n).map((n) => ({
		action: n,
		score: J(k(e, t, n), t, r)
	})).sort((e, t) => t.score - e.score);
}
function X(e) {
	let t = Math.floor(2 ** 32 / e.length) * e.length, n = /* @__PURE__ */ new Uint32Array(1);
	do
		crypto.getRandomValues(n);
	while (n[0] >= t);
	return e[n[0] % e.length];
}
function Z(e, t, n = !0, r = q) {
	let i = Y(e, t, n, r);
	if (r.replies <= 0) return i;
	let a = 1 - t;
	return i.slice(0, r.replies).map(({ action: n, score: i }) => {
		let o = k(e, t, n);
		if (!w(o, a).length) return {
			action: n,
			score: i
		};
		let s = Infinity;
		for (let e of O(o, a)) s = Math.min(s, -J(k(o, a, e), a, r));
		return {
			action: n,
			score: s + i * .001
		};
	}).sort((e, t) => t.score - e.score);
}
function Q(e = q) {
	return (t, n) => {
		let r = t.public;
		if (r.players[r.turn] !== n.rid || r.phase !== "move" && r.phase !== "place") return null;
		let i = n.difficulty === "weak" ? O(r, r.turn, r.phase === "move").map((e) => ({
			action: e,
			score: 0
		})) : Z(r, r.turn, r.phase === "move", e);
		if (!i.length) return null;
		let a = n.difficulty === "weak" ? X(i) : X(i.filter((e) => e.score === i[0].score));
		return { action: r.phase === "move" ? {
			type: "move",
			cell: a.action.move,
			revision: r.revision
		} : {
			type: "place",
			cell: a.action.cell,
			value: a.action.value,
			revision: r.revision
		} };
	};
}
var $ = Q(), ee = (e, t, n) => {
	if (e.type === "tick") return "";
	let r = {
		row: Math.floor(e.cell / 7) + 1,
		col: e.cell % 7 + 1
	};
	return e.type === "move" ? n("games.yoxii.hintMove", r) : n("games.yoxii.hintPlace", {
		...r,
		n: e.value
	});
}, te = {
	moveTotem(e, t) {
		let n = e.data, r = t.anchor(`yoxii-cell:${n.from}`), i = t.anchor("yoxii-totem");
		if (!r || !i) return null;
		let a = {
			x: r.x + (r.w - i.w) / 2,
			y: r.y + (r.h - i.h) / 2,
			w: i.w,
			h: i.h
		};
		return {
			ms: L.move,
			hide: ["yoxii-totem"],
			node: /* @__PURE__ */ d(m, {
				from: a,
				to: i,
				ms: L.move,
				children: /* @__PURE__ */ d(V, { style: {
					width: a.w,
					height: a.h
				} })
			})
		};
	},
	placePiece(e, t) {
		let n = e.data, r = t.anchor(`yoxii-stock:${n.side}:${n.value}`), i = t.anchor(`yoxii-piece:${n.cell}`);
		return !r || !i ? null : {
			ms: L.place,
			hide: [`yoxii-piece:${n.cell}`],
			node: /* @__PURE__ */ d(m, {
				from: r,
				to: i,
				ms: L.place,
				children: /* @__PURE__ */ d(B, {
					side: n.side,
					value: n.value,
					style: {
						width: r.w,
						height: r.h
					}
				})
			})
		};
	}
};
//#endregion
//#region src/games/yoxii/game-over.tsx
function ne({ public: e, result: t, members: a, hintCount: c, onPlayAgain: l, onBackToLobby: p }) {
	let m = e, g = s(), _ = o((e) => e.locale), [v, y] = i(!0), b = r(null), x = r(null), S = r(null), C = E(m), w = (e) => {
		let t = a.find((t) => t.rid === e);
		return t ? u(t, _) : e;
	};
	n(() => {
		(v ? x : b).current?.focus();
	}, [v]);
	let T = t.winner.length === 2 ? g("games.yoxii.draw") : g("games.yoxii.won", { name: w(t.winner[0]) });
	return /* @__PURE__ */ f("div", {
		className: "yoxii-result",
		children: [
			/* @__PURE__ */ d("div", {
				className: "yoxii-result-board",
				inert: v,
				"aria-hidden": v,
				children: /* @__PURE__ */ d(W, {
					pub: m,
					scoring: C.flatMap((e) => e.cells)
				})
			}),
			!v && /* @__PURE__ */ d("button", {
				type: "button",
				ref: b,
				className: "yoxii-return",
				onClick: () => y(!0),
				children: g("games.yoxii.showResult")
			}),
			v && /* @__PURE__ */ d("div", {
				className: "yoxii-result-shade",
				children: /* @__PURE__ */ f("div", {
					className: "yoxii-result-dialog",
					ref: S,
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "yoxii-result-title",
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), y(!1)), e.key !== "Tab") return;
						let t = Array.from(S.current?.querySelectorAll("button:not(:disabled)") ?? []);
						e.shiftKey && document.activeElement === t[0] ? (e.preventDefault(), t.at(-1)?.focus()) : !e.shiftKey && document.activeElement === t.at(-1) && (e.preventDefault(), t[0]?.focus());
					},
					children: [
						/* @__PURE__ */ f("header", { children: [/* @__PURE__ */ d("p", { children: g("games.yoxii.final") }), /* @__PURE__ */ d("h1", {
							id: "yoxii-result-title",
							children: T
						})] }),
						/* @__PURE__ */ f("div", {
							className: "yoxii-result-details",
							children: [
								/* @__PURE__ */ d("h2", { children: g("games.yoxii.scoreTitle") }),
								[0, 1].map((e) => /* @__PURE__ */ f("section", {
									className: "yoxii-score",
									"data-winner": t.winner.includes(m.players[e]),
									children: [
										/* @__PURE__ */ f("h3", { children: [
											/* @__PURE__ */ d("span", {
												className: "yoxii-side-dot",
												"data-side": e,
												"aria-hidden": "true"
											}),
											w(m.players[e]),
											/* @__PURE__ */ d("small", { children: g(e === 0 ? "games.yoxii.white" : "games.yoxii.red") })
										] }),
										/* @__PURE__ */ f("div", {
											className: "yoxii-score-numbers",
											children: [/* @__PURE__ */ d("b", { children: C[e].score === 1 ? g("games.yoxii.onePoint") : g("games.yoxii.points", { n: C[e].score }) }), /* @__PURE__ */ d("span", { children: C[e].count === 1 ? g("games.yoxii.onePiece") : g("games.yoxii.count", { n: C[e].count }) })]
										}),
										/* @__PURE__ */ d("div", {
											className: "yoxii-scoring-pieces",
											"aria-label": g("games.yoxii.scoring"),
											children: C[e].cells.map((t) => /* @__PURE__ */ d("span", {
												"aria-label": g("games.yoxii.pieceAria", {
													color: g(e === 0 ? "games.yoxii.white" : "games.yoxii.red"),
													n: Math.abs(m.board[t])
												}),
												children: /* @__PURE__ */ d(B, {
													side: e,
													value: Math.abs(m.board[t])
												})
											}, t))
										}),
										(t.autopilot?.[m.players[e]] ?? 0) > 0 && /* @__PURE__ */ d("small", { children: g("session.autopilot.share", { n: Math.round(t.autopilot[m.players[e]] * 100) }) })
									]
								}, e)),
								C[0].score === C[1].score && /* @__PURE__ */ d("p", { children: C[0].count === C[1].count ? g("games.yoxii.allTie") : g("games.yoxii.scoreTie") }),
								c !== void 0 && /* @__PURE__ */ d("p", { children: g("session.hint.usedCount", { n: c }) })
							]
						}),
						/* @__PURE__ */ f("footer", { children: [
							/* @__PURE__ */ d("button", {
								type: "button",
								className: "yoxii-result-button",
								ref: x,
								onClick: () => y(!1),
								children: g("games.yoxii.review")
							}),
							l && /* @__PURE__ */ d(h, {
								label: g("session.result.playAgain"),
								confirmLabel: g("games.yoxii.confirmAgain"),
								onConfirm: l,
								className: "yoxii-result-button yoxii-result-primary"
							}),
							p && /* @__PURE__ */ d(h, {
								label: g("session.result.backToLobby"),
								confirmLabel: g("games.yoxii.confirmLeave"),
								onConfirm: p,
								className: "yoxii-result-button"
							}),
							!l && !p && /* @__PURE__ */ d("p", { children: g("session.result.waitHost") })
						] })
					]
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/yoxii/entry.tsx
var re = {
	definition: R,
	View: K,
	bot: $,
	describe: ee,
	fx: te,
	OverView: ne,
	locales: {
		zh: {
			name: "Yoxii",
			desc: "移动图腾，围住胜机",
			rules: "目标：让图腾周围自己的棋子总分高于对手。\n准备：棋盘有37格。双方各有18枚棋子：1分（O）、2分（双杠）、3分（Y）各5枚，4分（X）3枚。随机分配红白双方，白棋先手。黄色图腾放在中央，双方棋子放在盘外。\n回合：\n1. 先移动图腾。沿横、竖或斜线移动到相邻空格；也可以沿同一直线跳过一枚或多枚连续的己方棋子，停在紧接这些棋子的第一个空格。不能跳过对手棋子，不能跨过空格继续移动。\n2. 从自己的储备中选择任意一枚棋子，放在图腾周围横、竖或斜向相邻的空格。只有图腾周围没有空格时，才可以放在棋盘上任意空格。不能放在图腾所在格。\n完成两步后，轮到对手。\n终局：轮到一方而该方无法合法移动图腾时，游戏立即结束。只计算图腾周围横、竖或斜向相邻的棋子：总分较高者获胜；同分时，棋子数量较多者获胜；两者均相同则为和棋。",
			white: "白棋",
			red: "红棋",
			move: "移动图腾",
			choose: "选择一枚储备棋子",
			place: "选择落子位置",
			moving: "图腾移动中",
			placing: "棋子落定中",
			waiting: "等待{{name}}",
			turn: "{{name}} · {{color}}",
			turnNumber: "第{{n}}回合",
			moveAria: "将图腾移动到第{{row}}行第{{col}}列",
			placeAria: "将{{n}}分棋子放在第{{row}}行第{{col}}列",
			cellAria: "第{{row}}行第{{col}}列：{{piece}}",
			empty: "空格",
			totem: "图腾",
			pieceAria: "{{color}}{{n}}分棋子",
			reserveAria: "选择{{color}}{{n}}分棋子，剩余{{count}}枚",
			remaining: "剩余{{n}}枚",
			points: "{{n}}分",
			count: "{{n}}枚棋子",
			onePoint: "1分",
			onePiece: "1枚棋子",
			final: "图腾已被围住",
			won: "{{name}}获胜",
			draw: "和棋",
			scoreTitle: "图腾周围",
			scoreTie: "同分，比较棋子数量",
			allTie: "分数与数量均相同",
			review: "回看棋盘",
			showResult: "查看结算",
			scoring: "参与计分的棋子",
			confirmAgain: "确认再来一局",
			confirmLeave: "确认返回大厅",
			hintMove: "将图腾移动到第{{row}}行第{{col}}列。",
			hintPlace: "在第{{row}}行第{{col}}列放置{{n}}分棋子。",
			errTurn: "当前不能执行这个动作。",
			errStale: "局面已更新，请重新选择。",
			errTarget: "这个位置或棋子当前不可选。"
		},
		en: {
			name: "Yoxii",
			desc: "Move the totem. Surround it to win.",
			rules: "Goal: score more points than your opponent around the totem.\nSetup: the board has 37 spaces. Each player has 18 pieces: five each worth 1 (O), 2 (two bars), and 3 (Y), and three worth 4 (X). Colors are assigned randomly. White plays first. Place the yellow totem in the center and keep both reserves off the board.\nOn your turn:\n1. Move the totem to an adjacent empty space horizontally, vertically, or diagonally. You may instead jump in one straight line over one or more consecutive pieces of your own color, landing on the first empty space immediately after them. You cannot jump over an opposing piece or continue past an empty space.\n2. Choose any piece from your reserve and place it on an empty space adjacent to the totem horizontally, vertically, or diagonally. Only if all adjacent spaces are occupied may you place on any empty space on the board. You cannot place under the totem.\nYour opponent then takes a turn.\nEnd: the game ends immediately when the player whose turn it is has no legal totem move. Count only pieces adjacent to the totem in the eight directions. The higher total value wins. If tied, the player with more adjacent pieces wins. If both are tied, the game is a draw.",
			white: "White",
			red: "Red",
			move: "Move the totem",
			choose: "Choose a reserve piece",
			place: "Choose a space",
			moving: "Totem moving",
			placing: "Piece landing",
			waiting: "Waiting for {{name}}",
			turn: "{{name}} · {{color}}",
			turnNumber: "Turn {{n}}",
			moveAria: "Move the totem to row {{row}}, column {{col}}",
			placeAria: "Place a {{n}}-point piece at row {{row}}, column {{col}}",
			cellAria: "Row {{row}}, column {{col}}: {{piece}}",
			empty: "Empty",
			totem: "Totem",
			pieceAria: "{{color}} {{n}}-point piece",
			reserveAria: "Choose a {{color}} {{n}}-point piece; {{count}} left",
			remaining: "{{n}} left",
			points: "{{n}} points",
			count: "{{n}} pieces",
			onePoint: "1 point",
			onePiece: "1 piece",
			final: "The totem is trapped",
			won: "{{name}} wins",
			draw: "Draw",
			scoreTitle: "Around the totem",
			scoreTie: "Equal points: compare piece counts",
			allTie: "Equal points and piece counts",
			review: "Review board",
			showResult: "Show result",
			scoring: "Scoring pieces",
			confirmAgain: "Confirm new game",
			confirmLeave: "Confirm return",
			hintMove: "Move the totem to row {{row}}, column {{col}}.",
			hintPlace: "Place a {{n}}-point piece at row {{row}}, column {{col}}.",
			errTurn: "You cannot take that action now.",
			errStale: "The position changed. Please choose again.",
			errTarget: "That space or piece is not available."
		}
	}
};
//#endregion
export { re as default };
