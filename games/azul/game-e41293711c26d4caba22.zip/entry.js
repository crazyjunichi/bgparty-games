import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as c } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as f } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as p, seatName as m } from "@bgparty/sdk/ui/player-strip";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { Floater as v, FlySprite as y } from "@bgparty/sdk/fx/primitives";
import { playSettle as b } from "@bgparty/sdk/sfx";
import { IconBack as x, IconBot as S, IconExpand as C, IconLog as w } from "@bgparty/sdk/icons";
import { Confetti as T } from "@bgparty/sdk/ui/confetti";
//#region src/games/azul/meta.ts
var E = {
	id: "azul",
	tier: "released",
	mechanics: ["drafting", "tile-placement"],
	interactionTags: [],
	nameKey: "games.azul.name",
	descKey: "games.azul.desc",
	rulesKey: "games.azul.rules",
	icon: "🧱",
	iconImg: "games/azul.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/azul/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#0d9488",
	releasedAt: "2026-09-13",
	search: {
		py: "hua zhuan wu yu",
		init: "hzwy"
	},
	hotseat: "cover"
}, D = t.enum([
	"blue",
	"yellow",
	"red",
	"black",
	"white"
]), O = t.discriminatedUnion("type", [t.object({
	type: t.literal("draft"),
	source: t.union([t.literal("center"), t.int().min(0).max(8)]),
	color: D,
	line: t.int().min(-1).max(4)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), k = t.string(), A = t.union([D, t.literal("first")]), j = t.object({
	color: D.nullable(),
	count: t.int().min(0).max(5)
}), M = t.object({
	lines: t.tuple([
		j,
		j,
		j,
		j,
		j
	]),
	wall: t.tuple([
		t.tuple([
			D.nullable(),
			D.nullable(),
			D.nullable(),
			D.nullable(),
			D.nullable()
		]),
		t.tuple([
			D.nullable(),
			D.nullable(),
			D.nullable(),
			D.nullable(),
			D.nullable()
		]),
		t.tuple([
			D.nullable(),
			D.nullable(),
			D.nullable(),
			D.nullable(),
			D.nullable()
		]),
		t.tuple([
			D.nullable(),
			D.nullable(),
			D.nullable(),
			D.nullable(),
			D.nullable()
		]),
		t.tuple([
			D.nullable(),
			D.nullable(),
			D.nullable(),
			D.nullable(),
			D.nullable()
		])
	]),
	floor: t.array(A).max(8)
}), N = t.object({
	phase: t.enum([
		"draft",
		"tiling",
		"done"
	]),
	round: t.int().min(1),
	turn: k,
	factories: t.array(t.array(D)),
	center: t.array(D),
	firstInCenter: t.boolean(),
	firstRid: k,
	bagCount: t.int().nonnegative(),
	tilingRid: k.nullable(),
	players: t.array(t.object({
		rid: k,
		score: t.int().nonnegative(),
		board: M
	}))
}), P = t.object({}), F = [
	"blue",
	"yellow",
	"red",
	"black",
	"white"
], I = 20, L = {
	2: 5,
	3: 7,
	4: 9
}, R = [
	-1,
	-1,
	-2,
	-2,
	-2,
	-3,
	-3
], z = {
	enter: 500,
	tile: 700,
	floor: 1100,
	refill: 900
}, B = (e, t) => F[(t + e) % 5], V = (e, t) => (F.indexOf(t) - e + 5) % 5;
function H(e, t, n) {
	let r = e.lines[t];
	return r.count >= t + 1 || r.color !== null && r.color !== n ? !1 : !e.wall[t].includes(n);
}
function U(e, t, n) {
	let r = 1;
	for (let i = n - 1; i >= 0 && e[t][i]; --i) r += 1;
	for (let i = n + 1; i < 5 && e[t][i]; i += 1) r += 1;
	let i = 1;
	for (let r = t - 1; r >= 0 && e[r][n]; --r) i += 1;
	for (let r = t + 1; r < 5 && e[r][n]; r += 1) i += 1;
	return r === 1 && i === 1 ? 1 : (r > 1 ? r : 0) + (i > 1 ? i : 0);
}
function ee(e) {
	let t = 0;
	for (let n = 0; n < 5; n += 1) e[n].every((e) => e !== null) && (t += 2);
	for (let n = 0; n < 5; n += 1) e.every((e) => e[n] !== null) && (t += 7);
	for (let n of F) {
		let r = 0;
		for (let t = 0; t < 5; t += 1) e[t][V(t, n)] === n && (r += 1);
		r === 5 && (t += 10);
	}
	return t;
}
var te = () => ({
	lines: [
		{
			color: null,
			count: 0
		},
		{
			color: null,
			count: 0
		},
		{
			color: null,
			count: 0
		},
		{
			color: null,
			count: 0
		},
		{
			color: null,
			count: 0
		}
	],
	wall: [
		[
			null,
			null,
			null,
			null,
			null
		],
		[
			null,
			null,
			null,
			null,
			null
		],
		[
			null,
			null,
			null,
			null,
			null
		],
		[
			null,
			null,
			null,
			null,
			null
		],
		[
			null,
			null,
			null,
			null,
			null
		]
	],
	floor: []
});
function W(t, n) {
	let r = [];
	for (; r.length < n;) {
		if (t.bag.length === 0) {
			if (t.discard.length === 0) break;
			let n = [...t.discard];
			for (let r = n.length - 1; r > 0; --r) {
				let i = e(t.seed, t.rngCursor, r + 1);
				t.rngCursor += 1, [n[r], n[i]] = [n[i], n[r]];
			}
			t.bag = n, t.discard = [];
		}
		r.push(t.bag.pop());
	}
	return r;
}
function ne(t, n, r) {
	let i = 0, a = [];
	for (let e of F) for (let t = 0; t < I; t += 1) a.push(e);
	for (let t = a.length - 1; t > 0; --t) {
		let n = e(r, i, t + 1);
		i += 1, [a[t], a[n]] = [a[n], a[t]];
	}
	let o = {}, s = {};
	for (let e of n) o[e] = te(), s[e] = 0;
	let c = n[e(r, i, n.length)];
	i += 1;
	let l = {
		players: n,
		turn: n.indexOf(c),
		round: 1,
		phase: "draft",
		factories: Array.from({ length: L[n.length] }, () => []),
		center: [],
		firstInCenter: !0,
		firstRid: c,
		boards: o,
		bag: a,
		discard: [],
		scores: s,
		tiling: {
			queue: [],
			stage: "tiles"
		},
		tilingRid: null,
		beatMs: 0,
		seed: r,
		rngCursor: i
	};
	return l.factories = l.factories.map(() => W(l, 4)), {
		state: l,
		fx: [{
			kind: "refill",
			data: {}
		}]
	};
}
function re(e) {
	return e.factories = e.factories.map(() => e.bag.length + e.discard.length >= 4 ? W(e, 4) : []), e.firstInCenter = !0, e.factories.some((e) => e.length > 0);
}
function ie(e) {
	let t = {};
	for (let n of e.players) t[n] = ee(e.boards[n].wall), e.scores[n] += t[n];
	return e.phase = "done", {
		kind: "final",
		data: { bonuses: t }
	};
}
function ae(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "tiling") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = t.tiling;
		if (n.stage === "tiles") {
			let e = n.queue.shift();
			if (!e) return n.stage = "floor", t.beatMs = z.floor, {
				state: t,
				fx: []
			};
			let { rid: r, line: i } = e, a = t.boards[r], o = a.lines[i].color, s = V(i, o);
			a.wall[i][s] = o;
			let c = U(a.wall, i, s);
			t.scores[r] += c;
			for (let e = 0; e < i; e += 1) t.discard.push(o);
			return a.lines[i] = {
				color: null,
				count: 0
			}, t.tilingRid = r, t.beatMs = z.tile, {
				state: t,
				fx: [{
					kind: "tile",
					rid: r,
					data: {
						line: i,
						col: s,
						color: o,
						gained: c
					}
				}]
			};
		}
		if (n.stage === "floor") {
			let e = {};
			for (let n of t.players) {
				let r = t.boards[n].floor;
				if (r.length === 0) continue;
				let i = 0;
				r.forEach((e, t) => {
					i += R[Math.min(t, R.length - 1)];
				}), t.scores[n] = Math.max(0, t.scores[n] + i), e[n] = i, t.discard.push(...r.filter((e) => e !== "first")), t.boards[n].floor = [];
			}
			return n.stage = "refill", t.beatMs = z.refill, {
				state: t,
				fx: [{
					kind: "floor",
					data: { penalties: e }
				}]
			};
		}
		return t.players.some((e) => t.boards[e].wall.some((e) => e.every((e) => e !== null))) || !re(t) ? {
			state: t,
			fx: [ie(t)]
		} : (t.round += 1, t.turn = t.players.indexOf(t.firstRid), t.phase = "draft", t.tilingRid = null, t.beatMs = 0, {
			state: t,
			fx: [{
				kind: "refill",
				data: {}
			}]
		});
	}
	if (e.phase !== "draft" || e.players[e.turn] !== n.by) return { code: "games.azul.errNotYourTurn" };
	if (t.source !== "center" && !e.factories[t.source]) return { code: "games.azul.errBadSource" };
	let r = t.source === "center" ? e.center : e.factories[t.source];
	if (!r.includes(t.color)) return { code: "games.azul.errBadColor" };
	let i = e.boards[n.by];
	if (t.line >= 0 && !H(i, t.line, t.color)) return { code: "games.azul.errBadLine" };
	let a = structuredClone(e), o = a.boards[n.by], s = r.filter((e) => e === t.color), c = !1;
	if (t.source === "center") a.center = a.center.filter((e) => e !== t.color), a.firstInCenter && (a.firstInCenter = !1, a.firstRid = n.by, c = !0, o.floor.push("first"));
	else {
		let e = a.factories[t.source].filter((e) => e !== t.color);
		a.center.push(...e), a.factories[t.source] = [];
	}
	let l = 0;
	if (t.line >= 0) {
		let e = o.lines[t.line];
		l = Math.min(s.length, t.line + 1 - e.count), e.color = t.color, e.count += l;
	}
	for (let e = 0; e < s.length - l; e += 1) o.floor.length < 7 ? o.floor.push(t.color) : a.discard.push(t.color);
	let u = [{
		kind: "draft",
		rid: n.by,
		data: {
			source: t.source,
			color: t.color,
			placed: l,
			dropped: s.length - l,
			line: t.line,
			tookFirst: c
		}
	}];
	if (a.factories.every((e) => e.length === 0) && a.center.length === 0) {
		let e = [];
		for (let t of a.players) for (let n = 0; n < 5; n += 1) a.boards[t].lines[n].count === n + 1 && e.push({
			rid: t,
			line: n
		});
		a.phase = "tiling", a.tiling = {
			queue: e,
			stage: "tiles"
		}, a.beatMs = z.enter;
	} else a.turn = (a.turn + 1) % a.players.length;
	return {
		state: a,
		fx: u
	};
}
function oe(e) {
	return {
		public: {
			phase: e.phase,
			round: e.round,
			turn: e.players[e.turn],
			factories: e.factories,
			center: e.center,
			firstInCenter: e.firstInCenter,
			firstRid: e.firstRid,
			bagCount: e.bag.length,
			tilingRid: e.phase === "tiling" ? e.tilingRid : null,
			players: e.players.map((t) => ({
				rid: t,
				score: e.scores[t],
				board: e.boards[t]
			}))
		},
		private: {}
	};
}
function se(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => e.boards[t].wall.filter((e) => e.every((e) => e !== null)).length, n = [...e.players].sort((n, r) => {
		let i = e.scores[r] - e.scores[n];
		return i === 0 ? t(r) - t(n) : i;
	}), r = n[0];
	return {
		phase: "done",
		winner: n.filter((n) => e.scores[n] === e.scores[r] && t(n) === t(r)),
		ranking: n,
		scores: { ...e.scores }
	};
}
function ce(e) {
	return e.phase === "tiling" ? e.beatMs : null;
}
var le = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: E,
	schemas: {
		action: O,
		publicView: N,
		privateView: P
	},
	setup: ne,
	reduce: ae,
	viewFor: oe,
	status: se,
	nextTickIn: ce
}, ue = {
	blue: {
		base: "#1f5fc9",
		rim: "#7ba7ec",
		motif: "#ffffff"
	},
	yellow: {
		base: "#f5b301",
		rim: "#ffd94d",
		motif: "#7c4a03"
	},
	red: {
		base: "#d63a2f",
		rim: "#f08a7d",
		motif: "#ffffff"
	},
	black: {
		base: "#26282e",
		rim: "#5a5e68",
		motif: "#ffffff"
	},
	white: {
		base: "#f6f8fb",
		rim: "#c9d8e8",
		motif: "#3f7ab5"
	}
}, G = {
	blue: /* @__PURE__ */ _(h, { children: [
		/* @__PURE__ */ g("circle", {
			cx: 16,
			cy: 16,
			r: 11,
			fill: "none",
			strokeWidth: 1.5
		}),
		[
			0,
			45,
			90,
			135,
			180,
			225,
			270,
			315
		].map((e) => /* @__PURE__ */ g("ellipse", {
			cx: 16,
			cy: 9.8,
			rx: 2,
			ry: 4.6,
			transform: `rotate(${e} 16 16)`,
			stroke: "none"
		}, e)),
		/* @__PURE__ */ g("circle", {
			cx: 16,
			cy: 16,
			r: 2.2,
			stroke: "none"
		})
	] }),
	yellow: /* @__PURE__ */ _(h, { children: [
		/* @__PURE__ */ g("path", {
			d: "M4 28 L28 4 M4 4 L28 28",
			fill: "none",
			strokeWidth: 2
		}),
		/* @__PURE__ */ g("path", {
			d: "M16 8.6 L23.4 16 L16 23.4 L8.6 16 Z",
			fill: "none",
			strokeWidth: 2,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ g("path", {
			d: "M16 12.6 L19.4 16 L16 19.4 L12.6 16 Z",
			stroke: "none"
		})
	] }),
	red: /* @__PURE__ */ _(h, { children: [[
		[3.3, 15.3],
		[9.1, 11.1],
		[16, 10],
		[22.9, 11.1],
		[28.7, 15.3]
	].map(([e, t]) => /* @__PURE__ */ g("path", {
		d: `M16 28 L${e} ${t}`,
		fill: "none",
		strokeWidth: 2,
		strokeLinecap: "round"
	}, `${e},${t}`)), /* @__PURE__ */ g("path", {
		d: "M7 12.4 A18 18 0 0 1 25 12.4 M10 17.6 A12 12 0 0 1 22 17.6",
		fill: "none",
		strokeWidth: 1.8
	})] }),
	black: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("circle", {
		cx: 16,
		cy: 16,
		r: 11.2,
		fill: "none",
		strokeWidth: 1.5
	}), /* @__PURE__ */ g("path", {
		d: "M16 7.5 C17.4 12.8 19.2 14.6 24.5 16 C19.2 17.4 17.4 19.2 16 24.5 C14.6 19.2 12.8 17.4 7.5 16 C12.8 14.6 14.6 12.8 16 7.5 Z",
		stroke: "none"
	})] }),
	white: /* @__PURE__ */ _(h, { children: [
		Object.values({
			tl: "M5 12.5 A7.5 7.5 0 0 1 12.5 5 M5 9.5 A4.5 4.5 0 0 1 9.5 5",
			tr: "M27 12.5 A7.5 7.5 0 0 0 19.5 5 M27 9.5 A4.5 4.5 0 0 0 22.5 5",
			bl: "M5 19.5 A7.5 7.5 0 0 0 12.5 27 M5 22.5 A4.5 4.5 0 0 1 9.5 27",
			br: "M27 19.5 A7.5 7.5 0 0 1 19.5 27 M27 22.5 A4.5 4.5 0 0 0 22.5 27"
		}).map((e) => /* @__PURE__ */ g("path", {
			d: e,
			fill: "none",
			strokeWidth: 1.9,
			strokeLinecap: "round"
		}, e)),
		/* @__PURE__ */ g("path", {
			d: "M16 12.2 L19.8 16 L16 19.8 L12.2 16 Z",
			fill: "none",
			strokeWidth: 1.9,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ g("path", {
			d: "M16 14.4 L17.6 16 L16 17.6 L14.4 16 Z",
			stroke: "none"
		})
	] })
};
function K({ skin: e, motif: t, size: n, ghost: r, cutout: i = !1 }) {
	return r ? /* @__PURE__ */ _("svg", {
		width: n,
		height: n,
		viewBox: "0 0 32 32",
		"aria-hidden": !0,
		className: "flex-none",
		children: [
			/* @__PURE__ */ g("rect", {
				x: 1.5,
				y: 1.5,
				width: 29,
				height: 29,
				rx: 6,
				fill: e.base,
				opacity: .22
			}),
			/* @__PURE__ */ g("rect", {
				x: 1.5,
				y: 1.5,
				width: 29,
				height: 29,
				rx: 6,
				fill: "none",
				stroke: e.base,
				strokeWidth: 2,
				strokeDasharray: "4 3",
				opacity: .85
			}),
			/* @__PURE__ */ g("g", {
				fill: e.motif,
				stroke: e.motif,
				opacity: .6,
				children: t
			}),
			i && /* @__PURE__ */ g("circle", {
				cx: 16,
				cy: 16,
				r: 1.6,
				fill: e.base,
				opacity: .6
			})
		]
	}) : /* @__PURE__ */ _("svg", {
		width: n,
		height: n,
		viewBox: "0 0 32 32",
		"aria-hidden": !0,
		className: "flex-none",
		children: [
			/* @__PURE__ */ g("rect", {
				x: 1.5,
				y: 1.5,
				width: 29,
				height: 29,
				rx: 6,
				fill: e.base,
				stroke: "var(--color-ink)",
				strokeWidth: 2.2
			}),
			/* @__PURE__ */ g("rect", {
				x: 4.5,
				y: 4.5,
				width: 23,
				height: 23,
				rx: 3,
				fill: "none",
				stroke: e.rim,
				strokeWidth: 1.1,
				opacity: .6
			}),
			/* @__PURE__ */ g("g", {
				fill: e.motif,
				stroke: e.motif,
				children: t
			}),
			i && /* @__PURE__ */ g("circle", {
				cx: 16,
				cy: 16,
				r: 1.6,
				fill: e.base
			}),
			/* @__PURE__ */ g("path", {
				d: "M7 6.8 Q16 3.8 25 6.8",
				fill: "none",
				stroke: "#ffffff",
				strokeWidth: 1.6,
				strokeLinecap: "round",
				opacity: .45
			})
		]
	});
}
function q({ color: e, size: t = 26, ghost: n = !1 }) {
	return /* @__PURE__ */ g(K, {
		skin: ue[e],
		motif: G[e],
		size: t,
		ghost: n,
		cutout: e === "black"
	});
}
var de = {
	base: "#f8ead0",
	rim: "#e3c98f",
	motif: E.accent
};
function J({ size: e = 26 }) {
	return /* @__PURE__ */ g(K, {
		skin: de,
		motif: G.black,
		size: e,
		ghost: !1,
		cutout: !0
	});
}
//#endregion
//#region src/games/azul/view-player.tsx
var fe = {
	blue: "games.azul.color.blue",
	yellow: "games.azul.color.yellow",
	red: "games.azul.color.red",
	black: "games.azul.color.black",
	white: "games.azul.color.white"
};
function pe(e) {
	return F.map((t) => ({
		color: t,
		count: e.filter((e) => e === t).length
	})).filter((e) => e.count > 0);
}
function me(e, t, n, r, i) {
	let a = t < 0 ? 0 : Math.min(r, t + 1 - e.lines[t].count), o = r - a, s = e.floor.length, c = 0;
	i && (c += R[Math.min(s, R.length - 1)], s += 1);
	for (let e = 0; e < o && s < 7; e += 1, s += 1) c += R[s];
	let l = t >= 0 && e.lines[t].count + a === t + 1, u = 0;
	if (l) {
		let r = structuredClone(e.wall), i = V(t, n);
		r[t][i] = n, u = U(r, t, i);
	}
	return {
		placed: a,
		overflow: o,
		penalty: c,
		completes: l,
		score: u
	};
}
function he(e) {
	return /* @__PURE__ */ g(ge, {
		pub: e.public,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ge({ pub: e, members: t, myRid: n, send: i }) {
	let s = u(), l = (e) => t.find((t) => t.rid === e)?.name ?? e, m = e.players.find((e) => e.rid === n), h = e.phase === "draft" && e.turn === n, [v, y] = o(n), [b, x] = o(null), [S, C] = o(null), w = a(null), T = a(null), D = [
		e.phase,
		e.turn,
		...e.factories.map((e) => e.join("")),
		e.center.join("")
	].join("|"), [O, k] = o(D);
	O !== D && (k(D), C(null), x(null));
	let [A, j] = o(null);
	e.phase === "tiling" && e.tilingRid && e.tilingRid !== A && (j(e.tilingRid), y(e.tilingRid)), e.phase !== "tiling" && A !== null && (j(null), y(n)), r(() => {
		if (b === null) return;
		w.current?.querySelector(".az-color-choice")?.focus();
		let e = (e) => {
			if (e.key === "Escape" && x(null), e.key !== "Tab") return;
			let t = Array.from(w.current?.querySelectorAll("button:not(:disabled)") ?? []);
			t.length !== 0 && (e.shiftKey && document.activeElement === t[0] ? (e.preventDefault(), t[t.length - 1].focus()) : !e.shiftKey && document.activeElement === t[t.length - 1] && (e.preventDefault(), t[0].focus()));
		};
		return document.addEventListener("keydown", e), () => {
			document.removeEventListener("keydown", e), T.current?.focus();
		};
	}, [b]), r(() => {
		S && b === null && document.querySelector(".az-line-target, .az-floor-target")?.focus();
	}, [S, b]);
	let M = (t) => t === "center" ? e.center : e.factories[t] ?? [], N = S ? M(S.source).filter((e) => e === S.color).length : 0, P = S?.source === "center" && e.firstInCenter, F = e.players.find((e) => e.rid === v) ?? m, I = h && S !== null && v === n, L = (e) => {
		h && M(e).length !== 0 && (T.current = document.activeElement instanceof HTMLButtonElement ? document.activeElement : null, C(null), y(n), x(e));
	}, R = (e) => {
		S && m && h && v === n && (e >= 0 && !H(m.board, e, S.color) || (i({
			type: "draft",
			source: S.source,
			color: S.color,
			line: e
		}), C(null)));
	}, z = "info", B = s("games.azul.turnWait", { name: l(e.turn) });
	return e.phase === "done" ? (z = "done", B = s("session.result.title")) : e.phase === "tiling" ? B = s("games.azul.tiling") : h && (z = "accent", B = s(S ? "games.azul.placeHint" : "games.azul.turnYou")), /* @__PURE__ */ g(d, {
		adaptive: !0,
		className: "az-screen",
		scroll: !1,
		actionsHeight: "h-18",
		banner: /* @__PURE__ */ _("div", {
			className: "az-top",
			children: [/* @__PURE__ */ g(f, {
				tone: z,
				text: B,
				chip: s("games.azul.roundShort", { n: e.round }),
				accent: E.accent
			}), /* @__PURE__ */ g(p, {
				adaptive: !0,
				variant: "mini",
				scroll: !0,
				members: t.filter((t) => e.players.some((e) => e.rid === t.rid)),
				myRid: n,
				anchorOf: (e) => "seat:" + e,
				action: (t) => e.phase === "draft" && t === e.turn ? "pending" : null,
				onPick: (e) => {
					x(null), C(null), y(e);
				},
				picked: (e) => v === e,
				status: (t) => {
					let n = e.players.find((e) => e.rid === t);
					return n ? /* @__PURE__ */ _("span", {
						className: "az-player-score",
						children: [
							/* @__PURE__ */ g(c, { value: n.score }),
							" ",
							s("games.azul.pointsShort")
						]
					}) : null;
				}
			})]
		}),
		actions: e.phase === "done" ? /* @__PURE__ */ g("div", {
			className: "az-action-rail",
			role: "status",
			children: /* @__PURE__ */ g("div", {
				className: "az-action-copy",
				children: /* @__PURE__ */ g("strong", { children: s("games.azul.inspectSub") })
			})
		}) : /* @__PURE__ */ g(Se, {
			selection: S,
			count: N,
			myTurn: h,
			tiling: e.phase === "tiling",
			cancel: () => C(null)
		}),
		children: /* @__PURE__ */ _("div", {
			className: "az-table",
			children: [
				/* @__PURE__ */ _("div", {
					className: "az-supply",
					children: [
						/* @__PURE__ */ _("div", {
							className: "az-supply-heading",
							children: [/* @__PURE__ */ g("span", {
								className: "az-eyebrow",
								children: s("games.azul.supplyEyebrow")
							}), /* @__PURE__ */ g("span", {
								className: "az-supply-meta",
								children: s("games.azul.bagRemaining", { n: e.bagCount })
							})]
						}),
						/* @__PURE__ */ g("div", {
							className: "az-factories",
							children: e.factories.map((e, t) => /* @__PURE__ */ g(_e, {
								index: t,
								tiles: e,
								disabled: !h,
								selected: S?.source === t,
								onPick: () => L(t)
							}, t))
						}),
						/* @__PURE__ */ g(ve, {
							tiles: e.center,
							firstInCenter: e.firstInCenter,
							disabled: !h,
							selected: S?.source === "center",
							onPick: () => L("center")
						})
					]
				}),
				F && /* @__PURE__ */ g(ye, {
					rid: F.rid,
					name: l(F.rid),
					score: F.score,
					board: F.board,
					isMine: F.rid === n,
					selection: I ? S : null,
					count: N,
					first: !!P,
					onPlace: I ? R : void 0
				}),
				b !== null && /* @__PURE__ */ g("div", {
					className: "az-picker-backdrop",
					onClick: () => x(null),
					children: /* @__PURE__ */ _("div", {
						ref: w,
						role: "dialog",
						"aria-modal": "true",
						"aria-label": s("games.azul.chooseColor"),
						className: "az-picker",
						onClick: (e) => e.stopPropagation(),
						children: [
							/* @__PURE__ */ _("div", {
								className: "az-picker-head",
								children: [/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("span", {
									className: "az-eyebrow",
									children: s("games.azul.chooseEyebrow")
								}), /* @__PURE__ */ g("h2", { children: b === "center" ? s("games.azul.centerLabel") : s("games.azul.factoryLabel", { n: b + 1 }) })] }), /* @__PURE__ */ g("button", {
									type: "button",
									className: "az-close",
									onClick: () => x(null),
									"aria-label": s("games.azul.cancel"),
									children: "×"
								})]
							}),
							/* @__PURE__ */ g("p", {
								className: "az-picker-hint",
								children: s("games.azul.chooseHint")
							}),
							/* @__PURE__ */ g("div", {
								className: "az-color-grid",
								children: pe(M(b)).map(({ color: e, count: t }) => /* @__PURE__ */ _("button", {
									type: "button",
									className: "az-color-choice",
									onClick: () => {
										C({
											source: b,
											color: e
										}), x(null);
									},
									children: [
										/* @__PURE__ */ g(q, {
											color: e,
											size: 32
										}),
										/* @__PURE__ */ g("span", { children: s(fe[e]) }),
										/* @__PURE__ */ _("strong", { children: ["×", t] })
									]
								}, e))
							}),
							b === "center" && e.firstInCenter && /* @__PURE__ */ _("div", {
								className: "az-marker-note",
								children: [/* @__PURE__ */ g(J, { size: 22 }), s("games.azul.firstMarkerNote")]
							})
						]
					})
				})
			]
		})
	});
}
function _e({ index: e, tiles: t, disabled: n, selected: r, onPick: i }) {
	let a = u(), { ref: o } = s("fac:" + e);
	return /* @__PURE__ */ _("button", {
		ref: o,
		type: "button",
		className: "az-factory" + (t.length === 0 ? " az-factory-empty" : "") + (r ? " az-source-selected" : ""),
		disabled: n || t.length === 0,
		"aria-label": a("games.azul.factoryAria", {
			n: e + 1,
			count: t.length
		}),
		onClick: i,
		children: [/* @__PURE__ */ g("span", {
			className: "az-factory-number",
			children: e + 1
		}), /* @__PURE__ */ g("span", {
			className: "az-factory-tiles",
			children: t.map((e, t) => /* @__PURE__ */ g(q, {
				color: e,
				size: 23
			}, t))
		})]
	});
}
function ve({ tiles: e, firstInCenter: t, disabled: n, selected: r, onPick: i }) {
	let a = u(), { ref: o } = s("center");
	return /* @__PURE__ */ _("button", {
		ref: o,
		type: "button",
		className: "az-center" + (r ? " az-source-selected" : ""),
		disabled: n || e.length === 0,
		onClick: i,
		"aria-label": a("games.azul.centerAria", { n: e.length }),
		children: [
			/* @__PURE__ */ g("span", {
				className: "az-center-name",
				children: a("games.azul.centerLabel")
			}),
			t && /* @__PURE__ */ g(J, { size: 23 }),
			/* @__PURE__ */ _("span", {
				className: "az-center-groups",
				children: [pe(e).map(({ color: e, count: t }) => /* @__PURE__ */ _("span", {
					className: "az-center-group",
					children: [/* @__PURE__ */ g(q, {
						color: e,
						size: 22
					}), /* @__PURE__ */ _("b", { children: ["×", t] })]
				}, e)), e.length === 0 && /* @__PURE__ */ g("span", {
					className: "az-center-empty",
					children: a("games.azul.centerEmpty")
				})]
			})
		]
	});
}
function ye({ rid: e, name: t, score: n, board: r, isMine: i, selection: a, count: o, first: l, onPlace: d }) {
	let f = u(), { ref: p } = s("floor:" + e), m = a ? me(r, -1, a.color, o, l) : null;
	return /* @__PURE__ */ _("div", {
		className: "az-board",
		children: [/* @__PURE__ */ _("div", {
			className: "az-board-head",
			children: [/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("span", {
				className: "az-eyebrow",
				children: f(i ? "games.azul.yourBoard" : "games.azul.viewingBoard")
			}), /* @__PURE__ */ g("h2", { children: t })] }), /* @__PURE__ */ _("div", {
				className: "az-score",
				children: [/* @__PURE__ */ g("strong", {
					className: "font-mono tabular-nums",
					children: /* @__PURE__ */ g(c, { value: n })
				}), /* @__PURE__ */ g("span", { children: f("games.azul.pointsShort") })]
			})]
		}), /* @__PURE__ */ _("div", {
			className: "az-board-content",
			children: [
				/* @__PURE__ */ _("div", {
					className: "az-column-labels",
					children: [/* @__PURE__ */ g("span", { children: f("games.azul.patternLabel") }), /* @__PURE__ */ g("span", { children: f("games.azul.wallLabel") })]
				}),
				/* @__PURE__ */ _("div", {
					className: "az-board-grid",
					children: [/* @__PURE__ */ g("div", {
						className: "az-patterns",
						children: r.lines.map((t, n) => /* @__PURE__ */ g(be, {
							rid: e,
							board: r,
							line: n,
							selection: a,
							count: o,
							first: l,
							onPlace: d
						}, n))
					}), /* @__PURE__ */ g("div", {
						className: "az-wall",
						children: r.wall.map((t, n) => /* @__PURE__ */ g("div", {
							className: "az-wall-row",
							children: t.map((t, i) => /* @__PURE__ */ g(xe, {
								rid: e,
								line: n,
								col: i,
								filled: t,
								highlighted: !!(a && H(r, n, a.color) && r.lines[n].count + Math.min(o, n + 1 - r.lines[n].count) === n + 1 && V(n, a.color) === i)
							}, i))
						}, n))
					})]
				}),
				/* @__PURE__ */ _("div", {
					className: "az-floor-wrap",
					children: [/* @__PURE__ */ _("div", {
						className: "az-floor-title",
						children: [/* @__PURE__ */ g("span", { children: f("games.azul.floorLabel") }), m && /* @__PURE__ */ g("strong", { children: f("games.azul.floorPreview", { n: m.penalty }) })]
					}), /* @__PURE__ */ g("button", {
						type: "button",
						disabled: !a || !d,
						className: "az-floor" + (a && d ? " az-floor-target" : ""),
						onClick: () => d?.(-1),
						"aria-label": f("games.azul.floorAria"),
						children: /* @__PURE__ */ g("div", {
							ref: p,
							className: "az-floor-cells",
							children: Array.from({ length: Math.max(7, r.floor.length) }, (e, t) => {
								let n = r.floor[t];
								return n === "first" ? /* @__PURE__ */ g(J, { size: 23 }, t) : n ? /* @__PURE__ */ g(q, {
									color: n,
									size: 23
								}, t) : /* @__PURE__ */ g("span", {
									className: "az-floor-slot",
									children: R[Math.min(t, R.length - 1)]
								}, t);
							})
						})
					})]
				})
			]
		})]
	});
}
function be({ rid: e, board: t, line: n, selection: r, count: i, first: a, onPlace: o }) {
	let c = u(), { ref: l } = s("pline:" + e + ":" + n), d = n + 1, f = t.lines[n], p = !!(r && o && H(t, n, r.color)), m = p && r ? me(t, n, r.color, i, a) : null;
	return /* @__PURE__ */ _("button", {
		type: "button",
		disabled: !p,
		className: "az-pattern-line" + (p ? " az-line-target" : ""),
		onClick: () => o?.(n),
		"aria-label": c("games.azul.lineAria", { n: d }) + (m ? ". " + c("games.azul.linePreviewAria", {
			placed: m.placed,
			overflow: m.overflow
		}) : ""),
		children: [
			/* @__PURE__ */ g("span", {
				className: "az-line-tag",
				children: d
			}),
			/* @__PURE__ */ g("span", {
				ref: l,
				className: "az-line-tiles",
				children: Array.from({ length: d }, (e, t) => {
					let n = f.color && t >= d - f.count, i = m && r && t >= d - f.count - m.placed && t < d - f.count;
					return n ? /* @__PURE__ */ g(q, {
						color: f.color,
						size: 27
					}, t) : i ? /* @__PURE__ */ g(q, {
						color: r.color,
						size: 27,
						ghost: !0
					}, t) : /* @__PURE__ */ g("span", { className: "az-line-slot" }, t);
				})
			}),
			m && /* @__PURE__ */ _("span", {
				className: "az-line-badge",
				children: [m.completes ? c("games.azul.completePreview", { n: m.score }) : c("games.azul.fillPreview", { n: m.placed }), m.overflow > 0 && /* @__PURE__ */ _("span", {
					className: "az-overflow",
					children: [" ", c("games.azul.overflowPreview", {
						n: m.overflow,
						penalty: m.penalty
					})]
				})]
			})
		]
	});
}
function xe({ rid: e, line: t, col: n, filled: r, highlighted: i }) {
	let { ref: a } = s("wall:" + e + ":" + t + ":" + n);
	return /* @__PURE__ */ g("span", {
		ref: a,
		className: "az-wall-cell" + (i ? " az-wall-highlight" : ""),
		children: /* @__PURE__ */ g(q, {
			color: r ?? B(t, n),
			size: 27,
			ghost: !r
		})
	});
}
function Se({ selection: e, count: t, myTurn: n, tiling: r, cancel: i }) {
	let a = u();
	return /* @__PURE__ */ g("div", {
		className: "az-action-rail",
		role: "status",
		children: e ? /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("span", {
				className: "az-action-tile",
				children: /* @__PURE__ */ g(q, {
					color: e.color,
					size: 32
				})
			}),
			/* @__PURE__ */ _("div", {
				className: "az-action-copy",
				children: [/* @__PURE__ */ _("strong", { children: [
					a(fe[e.color]),
					" ×",
					t
				] }), /* @__PURE__ */ _("span", { children: [
					e.source === "center" ? a("games.azul.centerLabel") : a("games.azul.factoryLabel", { n: e.source + 1 }),
					" · ",
					a("games.azul.pickDestination")
				] })]
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				className: "az-cancel",
				onClick: i,
				children: a("games.azul.cancel")
			})
		] }) : /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("span", {
				className: "az-step-number",
				children: n ? "01" : "◦"
			}),
			/* @__PURE__ */ _("div", {
				className: "az-action-copy",
				children: [/* @__PURE__ */ g("strong", { children: a(r ? "games.azul.tilingStep" : n ? "games.azul.pickSourceStep" : "games.azul.waitStep") }), /* @__PURE__ */ g("span", { children: a(n ? "games.azul.pickSourceSub" : "games.azul.inspectSub") })]
			}),
			/* @__PURE__ */ g("span", {
				className: "az-action-ornament",
				"aria-hidden": !0,
				children: "✦"
			})
		] })
	});
}
//#endregion
//#region src/games/azul/bot.ts
function Ce(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function we(e, t) {
	let n = 0;
	for (let r = 0; r < t; r += 1) n += R[Math.min(e + r, R.length - 1)];
	return n;
}
function Te(e, t, n) {
	let r = V(t, n), i = e.wall.map((e, i) => i === t ? e.map((e, t) => t === r ? n : e) : e), a = U(i, t, r), o = i[t].every((e) => e !== null);
	return o && (a += 2), i.every((e) => e[r] !== null) && (a += 7), i.every((e, t) => e[V(t, n)] === n) && (a += 10), {
		pts: a,
		rowFull: o
	};
}
var Ee = {
	tileW: 1,
	completeW: 6,
	wallPtsW: 1,
	fillW: .8,
	floorW: 1.3,
	feedW: 0,
	endLeadW: 3,
	endTrailW: -1,
	firstW: 0,
	denyW: 4,
	colShapeW: 0,
	searchK: 3,
	searchK2p: 6
};
function De(e = Ee) {
	let t = (t, n) => {
		let r = t.players.find((e) => e.rid === n);
		if (!r) return [];
		let i = t.players.filter((e) => e.rid !== n), a = Math.max(0, ...i.map((e) => e.score)), o = [], s = [...t.factories.map((e, t) => t), "center"];
		for (let n of s) {
			let s = n === "center" ? t.center : t.factories[n], c = [...new Set(s)];
			for (let l of c) {
				let c = s.filter((e) => e === l).length;
				for (let u = -1; u < 5; u += 1) {
					if (u >= 0 && !H(r.board, u, l)) continue;
					let d = u >= 0 ? r.board.lines[u] : null, f = d ? u + 1 - d.count : 0, p = Math.min(c, f), m = c - p, h = n === "center" && t.firstInCenter, g = p * e.tileW + e.floorW * we(r.board.floor.length, m + +!!h);
					if (h && (g += e.firstW), d && d.count + p === u + 1) {
						let { pts: t, rowFull: n } = Te(r.board, u, l);
						g += e.completeW + e.wallPtsW * t, g += e.colShapeW * r.board.wall.filter((e) => e[V(u, l)] !== null).length, n && (g += r.score >= a ? e.endLeadW : e.endTrailW);
					} else if (d && p > 0) {
						let t = (d.count + p) / (u + 1);
						g += p * e.fillW * t;
					}
					if (n !== "center") {
						let t = s.filter((e) => e !== l);
						for (let n of new Set(t)) {
							let r = t.filter((e) => e === n).length;
							for (let t of i) for (let i = 0; i < 5; i += 1) {
								let a = i + 1 - t.board.lines[i].count;
								if (a <= 2 && H(t.board, i, n) && a <= r) {
									g -= e.feedW;
									break;
								}
							}
						}
					}
					if (e.denyW > 0) {
						for (let t of i) for (let n = 0; n < 5; n += 1) if (n + 1 - t.board.lines[n].count <= c && H(t.board, n, l)) {
							g += e.denyW;
							break;
						}
					}
					o.push({
						action: {
							type: "draft",
							source: n,
							color: l,
							line: u
						},
						score: g
					});
				}
			}
		}
		return o;
	}, n = (e, t, n) => {
		let r = e.players.find((e) => e.rid === t).board, i = n.source === "center" ? e.center : e.factories[n.source], a = i.filter((e) => e === n.color).length;
		n.source === "center" ? (e.center = e.center.filter((e) => e !== n.color), e.firstInCenter && (e.firstInCenter = !1, r.floor.push("first"))) : (e.center.push(...i.filter((e) => e !== n.color)), e.factories[n.source] = []);
		let o = 0;
		if (n.line >= 0) {
			let e = r.lines[n.line];
			o = Math.min(a, n.line + 1 - e.count), e.color = n.color, e.count += o;
		}
		for (let e = 0; e < a - o; e += 1) r.floor.length < R.length && r.floor.push(n.color);
	}, r = (t) => {
		let n = e.floorW * we(0, t.floor.length);
		for (let r = 0; r < 5; r += 1) {
			let i = t.lines[r];
			i.count !== 0 && i.color !== null && (n += i.count === r + 1 ? e.completeW + e.wallPtsW * Te(t, r, i.color).pts : i.count * e.tileW * i.count / (r + 1));
		}
		return n;
	};
	return (i, a) => {
		let o = i.public;
		if (o.phase !== "draft" || o.turn !== a.rid) return null;
		let s = t(o, a.rid);
		if (s.length === 0) return null;
		if (a.difficulty === "weak") return { action: Ce(s).action };
		if (s.sort((e, t) => t.score - e.score), e.searchK <= 0 && e.searchK2p <= 0) return { action: s[0].action };
		let c = e.searchK2p > 0 && o.players.length <= 2 ? e.searchK2p : e.searchK;
		if (c <= 0) return { action: s[0].action };
		let l = o.players.map((e) => e.rid), u = s[0], d = -Infinity;
		for (let e of s.slice(0, c)) {
			let i = structuredClone({
				factories: o.factories,
				center: o.center,
				firstInCenter: o.firstInCenter,
				players: o.players
			});
			n(i, a.rid, e.action);
			let s = (l.indexOf(a.rid) + 1) % l.length;
			for (let e = 0; (i.center.length > 0 || i.factories.some((e) => e.length > 0)) && !(e > 100); e += 1) {
				let e = t(i, l[s]);
				if (e.length === 0) break;
				e.sort((e, t) => t.score - e.score), n(i, l[s], e[0].action), s = (s + 1) % l.length;
			}
			let c = r(i.players.find((e) => e.rid === a.rid).board) - Math.max(...i.players.filter((e) => e.rid !== a.rid).map((e) => r(e.board)));
			c > d && (d = c, u = e);
		}
		return { action: u.action };
	};
}
var Oe = De(), ke = {
	blue: "games.azul.color.blue",
	yellow: "games.azul.color.yellow",
	red: "games.azul.color.red",
	black: "games.azul.color.black",
	white: "games.azul.color.white"
}, Ae = (e, t, n) => {
	if (e.type !== "draft") return "";
	let r = e.source === "center" ? n("games.azul.hintSourceCenter") : n("games.azul.hintSourceFactory", { n: e.source + 1 }), i = e.line < 0 ? n("games.azul.hintToFloor") : n("games.azul.hintToLine", { n: e.line + 1 });
	return n("games.azul.hintDraft", {
		source: r,
		color: n(ke[e.color]),
		dest: i
	});
}, je = {
	blue: "蓝",
	yellow: "黄",
	red: "红",
	black: "黑",
	white: "白"
}, Y = (e) => {
	if (e.length === 0) return "(空)";
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n, (t.get(n) ?? 0) + 1);
	return [...t].map(([e, t]) => `${e}(${je[e]})×${t}`).join(", ");
}, Me = (e) => {
	let t = e.lines.map((t, n) => {
		let r = t.color === null ? "空" : `${t.color}(${je[t.color]})×${t.count}`, i = F.filter((t) => H(e, n, t));
		return `花纹行 ${n}(容量 ${n + 1}): ${r};可收颜色: ${i.length ? i.join("/") : "无"}`;
	}), n = e.wall.map((e, t) => {
		let n = F.filter((t) => e.includes(t));
		return `墙行 ${t}: ${n.length ? `已铺 ${n.join(", ")}` : "(全空)"}`;
	}), r = e.floor.length === 0 ? "(空)" : e.floor.map((e) => e === "first" ? "先手标记" : e).join(", ");
	return [
		...t,
		...n,
		`地板: ${r}`
	];
}, Ne = {
	needsAction: (e, t) => e.public.phase === "draft" && e.public.turn === t.rid,
	describeView(e, t) {
		let n = e.public, r = [`第 ${n.round} 轮。颜色一律用英文枚举值(blue/yellow/red/black/white)输出。`];
		if (n.phase !== "draft" || n.turn !== t.rid) return r.push("当前不在你的拿砖回合,无需行动。"), r.join("\n");
		r.push("现在轮到你拿砖:选一个工厂盘(序号)或中央区(center)的某种颜色全部拿走,放上你的一条花纹行(0-4)或直接丢地板(-1)。"), n.factories.forEach((e, t) => {
			e.length && r.push(`工厂盘 ${t}: ${Y(e)}`);
		}), r.push(`中央区: ${Y(n.center)}${n.firstInCenter ? "(含先手标记,第一个从中央拿的人顺带拿走,回合末 -1 分)" : ""}`);
		let i = n.players.find((e) => e.rid === t.rid);
		return i && r.push("你的板面:", ...Me(i.board)), r.push(`各玩家分数: ${n.players.map((e) => `${e.rid === t.rid ? "你" : e.rid}=${e.score}`).join(", ")}`), r.push("输出一个 draft 行动。放不下的砖会掉地板扣分,尽量别让这种情况发生。"), r.join("\n");
	},
	actionJsonSchema: {
		type: "object",
		properties: {
			type: { const: "draft" },
			source: {
				oneOf: [{ const: "center" }, {
					type: "integer",
					minimum: 0,
					maximum: 8
				}],
				description: "工厂盘序号,或 \"center\" 表示中央区"
			},
			color: {
				enum: [
					"blue",
					"yellow",
					"red",
					"black",
					"white"
				],
				description: "必须从该来源里实际存在的颜色中选"
			},
			line: {
				type: "integer",
				minimum: -1,
				maximum: 4,
				description: "花纹行 0-4;-1 = 直接放地板(扣分,尽量避免)"
			}
		},
		required: [
			"type",
			"source",
			"color",
			"line"
		],
		additionalProperties: !1
	},
	parseAction(e, t, n) {
		let r = O.safeParse(e);
		if (!r.success) return null;
		let i = r.data;
		if (i.type === "tick") return null;
		let a = t.public;
		if (a.phase !== "draft" || a.turn !== n.rid || !(i.source === "center" ? a.center : a.factories[i.source])?.includes(i.color)) return null;
		if (i.line >= 0) {
			let e = a.players.find((e) => e.rid === n.rid);
			if (!e || !H(e.board, i.line, i.color)) return null;
		}
		return i;
	}
};
//#endregion
//#region src/games/azul/fx.tsx
function X(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function Z(e, t, n) {
	return e.anchor(t) ?? X(e, n);
}
function Q(e, t, n = !1) {
	return !e || t <= 27 ? e : {
		x: e.x + (n ? e.w - t : (e.w - t) / 2),
		y: e.y + (e.h - t) / 2,
		w: t,
		h: t
	};
}
function $(e, t) {
	let n = e === "first" ? /* @__PURE__ */ g(J, { size: t }) : /* @__PURE__ */ g(q, {
		color: e,
		size: t
	});
	return t > 27 ? /* @__PURE__ */ g("span", {
		style: {
			display: "block",
			width: t,
			height: t
		},
		children: n
	}) : n;
}
var Pe = {
	draft(e, t) {
		let n = e.data;
		if (!n || typeof n.color != "string") return null;
		let r = X(t, e.rid);
		if (!r) return null;
		let i = (typeof n.source == "number" ? t.anchor(`fac:${n.source}`) : t.anchor("center")) ?? r, a = typeof n.line == "number" && n.line >= 0 ? t.anchor(`pline:${e.rid}:${n.line}`) : null, o = t.anchor(`floor:${e.rid}`), s = a && a.h > 27 ? a.h : 26, c = o && o.h > 27 ? o.h : 26, l = n.placed ?? 0, u = n.dropped ?? 0, d = [];
		for (let e = 0; e < l; e += 1) d.push(/* @__PURE__ */ g(y, {
			from: i,
			to: Q(a, s, !0) ?? r,
			ms: 380,
			delay: e * 60,
			children: $(n.color, s)
		}, `p${e}`));
		for (let e = 0; e < u; e += 1) d.push(/* @__PURE__ */ g(y, {
			from: i,
			to: Q(o, c) ?? r,
			ms: 420,
			delay: (l + e) * 60,
			children: $(n.color, c)
		}, `d${e}`));
		return n.tookFirst && d.push(/* @__PURE__ */ g(y, {
			from: i,
			to: Q(o, c) ?? r,
			ms: 420,
			delay: (l + u) * 60,
			children: $("first", c)
		}, "m")), d.length === 0 ? null : {
			ms: 460 + (l + u + +!!n.tookFirst) * 60,
			node: d
		};
	},
	tile(e, t) {
		let n = e.data;
		if (!n || typeof n.line != "number" || typeof n.col != "number" || typeof n.color != "string" || !X(t, e.rid)) return null;
		let r = `wall:${e.rid}:${n.line}:${n.col}`, i = Z(t, r, e.rid), a = Z(t, `pline:${e.rid}:${n.line}`, e.rid);
		if (!i || !a) return null;
		let o = t.anchor(r), s = o && o.w > 27 ? o.w : 26;
		return {
			ms: 750,
			node: [/* @__PURE__ */ g(y, {
				from: Q(a, s, !0) ?? a,
				to: i,
				ms: 420,
				children: $(n.color, s)
			}, "t"), /* @__PURE__ */ _(v, {
				at: i,
				ms: 800,
				delay: 400,
				children: ["+", n.gained ?? 0]
			}, "g")],
			hide: [r]
		};
	},
	floor(e, t) {
		let n = e.data, r = Object.entries(n?.penalties ?? {});
		if (r.length === 0) return null;
		let i = r.map(([e, n], r) => {
			let i = Z(t, `floor:${e}`, e);
			return i ? /* @__PURE__ */ g(v, {
				at: i,
				ms: 900,
				delay: r * 120,
				children: n
			}, e) : null;
		}).filter(Boolean);
		return i.length === 0 ? null : {
			ms: 1100,
			node: i
		};
	},
	refill() {
		return null;
	},
	final() {
		return b(), null;
	}
};
//#endregion
//#region src/games/azul/endgame-review.tsx
function Fe({ board: e, renderResult: t, ...n }) {
	let s = u(), [c, l] = o(!0), [d, f] = o(null), p = a(null), m = a(null), h = a(null);
	r(() => {
		if (!d) return;
		h.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let v = (e) => {
		f(null), l(e), requestAnimationFrame(() => (e ? p : m).current?.focus({ preventScroll: !0 }));
	}, y = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), b = {
		...n,
		...y
	};
	return /* @__PURE__ */ _("div", {
		className: "azul-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ g("div", {
				className: "azul-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ g("div", {
				className: "azul-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ _("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), v(!1));
					},
					className: "azul-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ _("header", {
							className: "azul-endgame-heading",
							children: [/* @__PURE__ */ _("div", {
								className: "azul-endgame-brand",
								children: [/* @__PURE__ */ g("span", {
									"aria-hidden": "true",
									children: E.icon
								}), s(E.nameKey)]
							}), /* @__PURE__ */ g("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": s("games.azul.reviewHide"),
								title: s("games.azul.reviewHide"),
								onClick: () => v(!1),
								children: /* @__PURE__ */ g(C, { size: 19 })
							})]
						}),
						/* @__PURE__ */ g("div", {
							className: "azul-endgame-result",
							inert: d !== null,
							children: t(b)
						}),
						d && /* @__PURE__ */ _("div", {
							className: "azul-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ g("button", {
								type: "button",
								ref: h,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: s(d.label === "again" ? "games.azul.reviewConfirmAgain" : "games.azul.reviewConfirmLobby")
							}), /* @__PURE__ */ g("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: s("games.azul.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ g("div", {
				className: "azul-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ _("button", {
					type: "button",
					className: "btn-base",
					ref: m,
					onClick: () => v(!0),
					children: [
						/* @__PURE__ */ g(w, { size: 18 }),
						s("games.azul.reviewShow"),
						/* @__PURE__ */ g(x, { size: 18 })
					]
				})
			})
		]
	});
}
function Ie({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: c, renderRowExtra: d, summary: f, navigation: p, content: v, afterRanking: y, scoreUnit: b, rankOf: x }) {
	let w = u(), D = l((e) => e.locale), [O, k] = o({}), A = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? m(n, D) : e;
	}, j = (t, n) => x?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), M = e.ranking.some((t) => e.scores?.[t] !== void 0), N = (t, n) => /* @__PURE__ */ _("div", {
		className: "azul-score-identity",
		children: [
			/* @__PURE__ */ _("span", {
				className: "azul-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ g("span", {
					"aria-label": w("games.azul.reviewWinner"),
					children: "♛ "
				}), M && j(t, n)]
			}),
			/* @__PURE__ */ _("span", {
				className: "azul-score-name",
				children: [A(t), t === r && /* @__PURE__ */ g("small", { children: w("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ _("small", {
				className: "azul-score-autopilot",
				children: [
					/* @__PURE__ */ g(S, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), P = (t) => e.ranking.map((n) => /* @__PURE__ */ g("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ _("div", {
		className: "azul-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ g(T, {}),
			p,
			/* @__PURE__ */ _("div", {
				className: "azul-score-body",
				children: [
					f && /* @__PURE__ */ g("div", {
						className: "azul-score-summary",
						children: f
					}),
					i !== void 0 && /* @__PURE__ */ g("p", {
						className: "azul-score-hints",
						children: w("session.hint.usedCount", { n: i })
					}),
					v ?? (c?.length ? /* @__PURE__ */ g("div", {
						className: "azul-score-table-scroll",
						children: /* @__PURE__ */ _("table", {
							className: "azul-score-table",
							"aria-label": w(E.nameKey),
							children: [
								/* @__PURE__ */ g("thead", { children: /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", { scope: "col" }), /* @__PURE__ */ g(h, { children: e.ranking.map((t, n) => /* @__PURE__ */ g("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: N(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ g("tbody", { children: c.map((e, t) => /* @__PURE__ */ _(n, { children: [/* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ _("button", {
										type: "button",
										"aria-expanded": !!O[t],
										onClick: () => k((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ g(C, { size: 15 }), e.label]
									}) : e.label
								}), P(e)] }), O[t] && e.details?.map((e, t) => /* @__PURE__ */ _("tr", {
									className: "azul-score-sub",
									children: [/* @__PURE__ */ g("th", {
										scope: "row",
										children: e.label
									}), P(e)]
								}, t))] }, t)) }),
								M && /* @__PURE__ */ g("tfoot", { children: /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", {
									scope: "row",
									children: w("games.azul.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ g("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ g("ol", {
						className: "azul-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ _("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ _("div", {
								className: "azul-score-rankline",
								children: [N(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ _("strong", {
									className: "azul-score-points",
									children: [e.scores[t], b && /* @__PURE__ */ g("small", { children: b })]
								})]
							}), d?.(t)]
						}, t))
					})),
					y,
					!!c?.length && d && /* @__PURE__ */ g("div", {
						className: "azul-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ _("details", { children: [/* @__PURE__ */ g("summary", { children: A(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ _("footer", {
				className: "azul-score-actions",
				children: [
					s && /* @__PURE__ */ g("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: w("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ g("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: w("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ g("p", { children: w("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/azul/game-over.tsx
function Le(e) {
	return /* @__PURE__ */ g(Ie, {
		...e,
		accent: E.accent
	});
}
function Re(e) {
	return /* @__PURE__ */ g(Fe, {
		...e,
		board: /* @__PURE__ */ g(he, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ g(Le, { ...e })
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/azul/entry.tsx
var ze = {
	definition: le,
	View: he,
	bot: Oe,
	describe: Ae,
	llm: Ne,
	fx: Pe,
	OverView: Re,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "花砖物语",
			desc: "工厂挑彩砖、砌花纹、铺宫墙,横竖连锁得分",
			rules: "目标:有人在自己的墙上铺出一整行 5 块时游戏结束,总分最高者获胜。\n流程(轮到你):\n· 从一个工厂盘或中央区拿走某一色的全部砖;工厂盘里剩下的砖推到中央区。\n· 每轮第一个从中央区拿砖的人,还须把先手标记放到地板上(占 1 格罚分),下轮由你先行动。\n· 将拿到的瓷砖放入一条花纹行：该行必须为空，或已有瓷砖均为所选颜色；放入的数量不得超过容量，且对应墙面横行中不能已有该颜色。\n· 放不下的瓷砖全部放入地板线。地板线从左至右的七个格子依次扣除1、1、2、2、2、3、3分。\n铺墙:\n· 所有工厂盘和中央区被拿空后,进入铺墙:每条摆满的花纹行移一块砖到墙上对应花色格,该花纹行剩余的瓷砖放回盒中。\n· 新铺的砖按横、竖两个方向的连续砖数计分,两个方向都有就两份相加。\n· 横竖都不挨其他砖的孤立砖计 1 分;地板按格子罚分,分数最多扣到 0,不会变负。\n· 随后补满工厂盘开始下一轮;砖袋用尽后，将弃置的瓷砖混合后放回袋中。\n终局计分：\n· 每条完整的横行获得2分。\n· 每条完整的纵列获得7分。\n· 每种集齐5块的颜色获得10分。\n总分相同时，完整横行数量较多的玩家获胜。若仍然相同，则共享胜利。",
			turnYou: "轮到你:点一组同色砖",
			turnWait: "等 {{name}} 拿砖…",
			tiling: "铺墙计分中…",
			roundShort: "第 {{n}} 轮",
			placeHint: "点一条花纹行放置,放不下的放到地板",
			floorAria: "放到地板",
			floorLabel: "地板",
			lineAria: "第 {{n}} 格花纹行",
			tilesAria: "{{color}}砖,共 {{n}} 块",
			markerAria: "先手标记",
			pointsShort: "分",
			supplyEyebrow: "工厂 · 供砖区",
			bagRemaining: "砖袋余 {{n}}",
			factoryLabel: "{{n}} 号工厂",
			factoryAria: "{{n}} 号工厂,共 {{count}} 块砖;点开选色",
			centerLabel: "桌心",
			centerAria: "桌心,共 {{n}} 块砖;点开选色",
			centerEmpty: "等待砖块进入",
			chooseColor: "选择砖色",
			chooseEyebrow: "拿走一种颜色",
			chooseHint: "同色砖会一起拿走,其余砖留在桌上",
			firstMarkerNote: "先拿桌心还会得到先手砖,它落入地板",
			cancel: "取消",
			yourBoard: "你的瓷板",
			viewingBoard: "正在观看",
			patternLabel: "花纹行",
			wallLabel: "宫墙",
			linePreviewAria: "可放 {{placed}} 块,溢出 {{overflow}} 块",
			fillPreview: "放 {{n}}",
			completePreview: "铺墙约 +{{n}}",
			overflowPreview: "溢出 {{n}} · {{penalty}} 分",
			floorPreview: "这次 {{n}} 分",
			pickDestination: "选择落点",
			pickSourceStep: "点一个工厂盘或桌心",
			pickSourceSub: "拿同色砖,再选择花纹行",
			waitStep: "看看大家的瓷板",
			inspectSub: "点玩家名牌可切换视角",
			tilingStep: "正在铺墙计分",
			stripFloor: "🕳{{n}}",
			color: {
				blue: "蓝",
				yellow: "黄",
				red: "红",
				black: "黑",
				white: "白"
			},
			errNotYourTurn: "还没轮到你",
			errBadSource: "那里没有工厂盘",
			errBadColor: "那里没有这个色的砖",
			errBadLine: "这行放不了这个色",
			hintDraft: "从{{source}}拿走全部{{color}}砖,{{dest}}",
			hintSourceCenter: "中央区",
			hintSourceFactory: "{{n}} 号工厂盘",
			hintToFloor: "直接放到地板上",
			hintToLine: "放上第 {{n}} 条花纹行"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Azul",
			desc: "Draft tiles, fill pattern lines, tile the wall — chain rows and columns",
			rules: "Goal: the game ends when someone completes a full row of 5 on their wall; the highest score wins.\nOn your turn:\n· Take all tiles of one color from one factory display or the center; leftovers on a display are pushed to the center.\n· The first player to take from the center each round must also place the starting-player marker onto their floor line (it costs a penalty slot) and goes first next round.\n· Place the taken tiles on one pattern line: the line must be empty or hold only that color, have room, and its wall row must not already show that color.\n· Place overflow tiles on the floor line. Its seven slots deduct 1, 1, 2, 2, 2, 3 and 3 points respectively, from left to right.\nWall-tiling:\n· When every display and the center are empty, each full pattern line moves one tile onto its matching wall space; the rest are boxed.\n· A new tile scores its horizontal and vertical runs (both count when both apply).\n· A lone tile touching no other tile scores 1; floor tiles cost points, and scores stop at 0 and never go negative.\n· Refill the displays and start a new round; when the bag runs out, shuffle the discards back into it.\nFinal scoring:\n· Score 2 points for each full row.\n· Score 7 points for each full column.\n· Score 10 points for each completed color.\nTies go to the player with more full rows. If the tie remains, share victory.",
			turnYou: "Your turn: tap a color group",
			turnWait: "Waiting for {{name}}…",
			tiling: "Tiling the walls…",
			roundShort: "Round {{n}}",
			placeHint: "Tap a pattern line — overflow goes to the floor",
			floorAria: "Place on the floor line",
			floorLabel: "Floor",
			lineAria: "Pattern line of {{n}}",
			tilesAria: "{{color}} tiles, {{n}} in total",
			markerAria: "Starting player marker",
			pointsShort: "pts",
			supplyEyebrow: "Factories · tile supply",
			bagRemaining: "{{n}} in bag",
			factoryLabel: "Factory {{n}}",
			factoryAria: "Factory {{n}}, {{count}} tiles; tap to choose a color",
			centerLabel: "Center",
			centerAria: "Center, {{n}} tiles; tap to choose a color",
			centerEmpty: "Tiles will arrive here",
			chooseColor: "Choose a tile color",
			chooseEyebrow: "Take one color",
			chooseHint: "Take every tile of that color; the others stay on the table",
			firstMarkerNote: "First center pick also takes the starting tile onto your floor",
			cancel: "Cancel",
			yourBoard: "Your tile board",
			viewingBoard: "Viewing",
			patternLabel: "Pattern lines",
			wallLabel: "Wall",
			linePreviewAria: "Place {{placed}}; {{overflow}} overflow",
			fillPreview: "Place {{n}}",
			completePreview: "Wall ~+{{n}}",
			overflowPreview: "{{n}} over · {{penalty}} pts",
			floorPreview: "This pick {{n}} pts",
			pickDestination: "choose a line",
			pickSourceStep: "Tap a factory or the center",
			pickSourceSub: "Choose a color, then a pattern line",
			waitStep: "Explore the tile boards",
			inspectSub: "Tap a player to switch boards",
			tilingStep: "Scoring the walls",
			stripFloor: "🕳{{n}}",
			color: {
				blue: "Blue",
				yellow: "Yellow",
				red: "Red",
				black: "Black",
				white: "White"
			},
			errNotYourTurn: "Not your turn yet",
			errBadSource: "No such factory display",
			errBadColor: "No tiles of that color there",
			errBadLine: "That color cannot go on this line",
			hintDraft: "Take all {{color}} tiles from {{source}}; {{dest}}",
			hintSourceCenter: "the center",
			hintSourceFactory: "factory {{n}}",
			hintToFloor: "drop them to the floor",
			hintToLine: "place on pattern line {{n}}"
		}
	}
};
//#endregion
export { ze as default };
