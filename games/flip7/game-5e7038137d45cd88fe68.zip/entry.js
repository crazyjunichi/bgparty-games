import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { AVATARS as s } from "@bgparty/sdk/avatars";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as l } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as u, useT as d } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { Texture as p } from "@bgparty/sdk/texture";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as h } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as g, seatName as _ } from "@bgparty/sdk/ui/player-strip";
import { Fragment as v, jsx as y, jsxs as b } from "react/jsx-runtime";
import { Flash as x, Floater as S, FlySprite as C, PulseBox as w } from "@bgparty/sdk/fx/primitives";
import { IconBot as T } from "@bgparty/sdk/icons";
import { Confetti as E } from "@bgparty/sdk/ui/confetti";
import { GameOverScreen as D } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/flip7/cards.ts
function O() {
	let e = ["n0"];
	for (let t = 1; t <= 12; t += 1) for (let n = 0; n < t; n += 1) e.push(`n${t}`);
	return e.push("p2", "p4", "p6", "p8", "p10", "x2"), e.push("freeze", "freeze", "freeze", "flip3", "flip3", "flip3", "chance", "chance", "chance"), e;
}
var k = (e) => Number(e.slice(1));
function A() {
	return {
		nums: [],
		mods: [],
		x2: !1,
		chance: !1,
		status: "active",
		flipped7: !1
	};
}
function j(e) {
	if (e.status === "busted") return 0;
	let t = e.nums.reduce((e, t) => e + t, 0), n = e.mods.reduce((e, t) => e + t, 0);
	return (e.x2 ? t * 2 : t) + n + (e.flipped7 ? 15 : 0);
}
function M(e) {
	return e.nums.length + e.mods.length + +!!e.x2 + +!!e.chance;
}
function ee(e) {
	let t = e.nums.map((e) => `n${e}`);
	for (let n of e.mods) t.push(`p${n}`);
	return e.x2 && t.push("x2"), e.chance && t.push("chance"), t;
}
//#endregion
//#region src/games/flip7/meta.ts
var N = {
	id: "flip7",
	tier: "beta",
	mechanics: ["push-your-luck"],
	interactionTags: [],
	nameKey: "games.flip7.name",
	descKey: "games.flip7.desc",
	rulesKey: "games.flip7.rules",
	icon: "🃏",
	iconImg: "games/flip7.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/flip7/en.pdf" },
	minPlayers: 3,
	maxPlayers: 8,
	bestPlayers: [5, 6],
	accent: "#7635d9",
	releasedAt: "2026-09-21",
	search: {
		py: "qi fan tian",
		init: "qft"
	},
	hotseat: "open"
}, P = t.discriminatedUnion("type", [
	t.object({ type: t.literal("hit") }),
	t.object({ type: t.literal("stay") }),
	t.object({
		type: t.literal("target"),
		target: t.string()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), F = t.string(), te = t.object({
	nums: t.array(t.int().min(0).max(12)),
	mods: t.array(t.int()),
	x2: t.boolean(),
	chance: t.boolean(),
	status: t.enum([
		"active",
		"stayed",
		"frozen",
		"busted"
	]),
	flipped7: t.boolean()
}), I = t.object({
	round: t.int().min(1),
	phase: t.enum([
		"deal",
		"play",
		"roundEnd",
		"done"
	]),
	dealer: F,
	turn: F.nullable(),
	pending: t.object({
		kind: t.enum([
			"freeze",
			"flip3",
			"chance"
		]),
		by: F
	}).nullable(),
	flipping: t.object({
		target: F,
		remaining: t.int()
	}).nullable(),
	deckCount: t.int().nonnegative(),
	discard: t.array(t.string()),
	totals: t.record(F, t.number()),
	lastScores: t.record(F, t.number()).nullable(),
	flip7By: F.nullable(),
	players: t.array(te.extend({ rid: F }))
}), ne = t.object({}), re = 3400;
function L(t, n) {
	for (let r = t.length - 1; r > 0; --r) {
		let i = e(n.seed, n.rngCursor, r + 1);
		n.rngCursor += 1, [t[r], t[i]] = [t[i], t[r]];
	}
	return t;
}
function R(e) {
	return Object.fromEntries(e.map((e) => [e, A()]));
}
function ie(t, n, r) {
	let i = {
		players: n,
		seed: r,
		rngCursor: 0,
		round: 1,
		dealer: 0,
		phase: "deal",
		dealPtr: 0,
		dealCount: 0,
		turn: -1,
		deck: [],
		discard: [],
		hands: R(n),
		pending: null,
		flipping: null,
		queue: [],
		totals: Object.fromEntries(n.map((e) => [e, 0])),
		lastScores: null,
		flip7By: null
	};
	return i.deck = L(O(), i), i.dealer = e(i.seed, i.rngCursor, n.length), i.rngCursor += 1, i.dealPtr = (i.dealer + 1) % n.length, {
		state: i,
		fx: [{
			kind: "roundStart",
			data: { round: 1 }
		}]
	};
}
var z = (e) => e.players.filter((t) => e.hands[t].status === "active");
function ae(e, t) {
	return z(e).filter((n) => n !== t && !e.hands[n].chance);
}
function B(e) {
	if (e.deck.length === 0) {
		if (e.discard.length === 0) return null;
		e.deck = L(e.discard, e), e.discard = [];
	}
	return e.deck.pop();
}
function oe(e) {
	e.flipping &&= (e.discard.push(...e.flipping.queued), null);
}
function V(e, t) {
	let n = {};
	for (let t of e.players) {
		let r = e.hands[t];
		n[t] = j(r), e.totals[t] += n[t];
	}
	e.lastScores = n, e.phase = "roundEnd", e.pending = null, e.discard.push(...e.queue.map((e) => e.kind)), e.queue = [], oe(e), t.push({
		kind: "roundEnd",
		data: {
			scores: n,
			flip7By: e.flip7By
		}
	});
}
function H(e, t, n, r, i) {
	let a = e.hands[t];
	if (n === "freeze" || n === "flip3") {
		i && e.flipping ? e.flipping.queued.push(n) : e.pending = {
			kind: n,
			by: t
		}, r.push({
			kind: "actionDrawn",
			rid: t,
			data: { card: n }
		});
		return;
	}
	if (n === "chance") {
		a.chance ? i && e.flipping ? (e.flipping.queued.push("chance"), r.push({
			kind: "actionDrawn",
			rid: t,
			data: { card: n }
		})) : ae(e, t).length > 0 ? (e.pending = {
			kind: "chance",
			by: t
		}, r.push({
			kind: "actionDrawn",
			rid: t,
			data: { card: n }
		})) : (e.discard.push(n), r.push({
			kind: "burn",
			rid: t,
			data: { card: n }
		})) : (a.chance = !0, r.push({
			kind: "land",
			rid: t,
			data: { card: n }
		}));
		return;
	}
	if (n === "x2") {
		a.x2 = !0, r.push({
			kind: "land",
			rid: t,
			data: { card: n }
		});
		return;
	}
	if (n.startsWith("p")) {
		a.mods.push(k(n)), r.push({
			kind: "land",
			rid: t,
			data: { card: n }
		});
		return;
	}
	let o = k(n);
	if (a.nums.includes(o)) {
		a.chance ? (a.chance = !1, e.discard.push("chance", n), r.push({
			kind: "saved",
			rid: t,
			data: { n: o }
		})) : (a.status = "busted", e.discard.push(n), r.push({
			kind: "bust",
			rid: t,
			data: { n: o }
		}), i && e.flipping && (e.discard.push(...e.flipping.queued), e.flipping.remaining = 0, e.flipping.queued = []));
		return;
	}
	a.nums.push(o), a.nums.sort((e, t) => e - t), r.push({
		kind: "land",
		rid: t,
		data: { card: n }
	}), a.nums.length === 7 && (a.flipped7 = !0, e.flip7By = t, r.push({
		kind: "flip7",
		rid: t
	}), V(e, r));
}
function U(e, t) {
	if (e.phase !== "play") return;
	if (z(e).length === 0) {
		V(e, t);
		return;
	}
	let n = e.players.length;
	for (let t = 1; t <= n; t += 1) {
		let r = (e.turn + t) % n;
		if (e.hands[e.players[r]].status === "active") {
			e.turn = r;
			return;
		}
	}
}
function se(e, t) {
	for (; e.dealCount < e.players.length;) {
		let n = e.players[e.dealPtr];
		if (e.dealPtr = (e.dealPtr + 1) % e.players.length, e.dealCount += 1, e.hands[n].status !== "active") continue;
		let r = B(e);
		if (!r) {
			V(e, t);
			return;
		}
		H(e, n, r, t, !1);
		return;
	}
	if (e.dealCount >= e.players.length && !e.pending && !e.flipping && e.phase === "deal") {
		if (z(e).length === 0) {
			V(e, t);
			return;
		}
		e.phase = "play", e.turn = e.dealer, U(e, t);
	}
}
function ce(e, t) {
	let n = e.flipping;
	if (!n) return;
	let r = B(e);
	if (!r) {
		oe(e), e.phase === "play" && U(e, t);
		return;
	}
	--n.remaining, H(e, n.target, r, t, !0), (e.phase === "play" || e.phase === "deal") && (n.remaining > 0 && e.hands[n.target].status === "active" || (e.flipping = null, e.queue.push(...n.queued.map((e) => ({
		kind: e,
		by: n.target
	}))), le(e, t), !e.pending && e.phase === "play" && U(e, t)));
}
function le(e, t) {
	for (; e.queue.length > 0;) {
		let n = e.queue.shift();
		if (e.hands[n.by].status !== "active") {
			e.discard.push(n.kind), t.push({
				kind: "burn",
				rid: n.by,
				data: { card: n.kind }
			});
			continue;
		}
		if (n.kind === "chance") {
			let r = e.hands[n.by];
			if (!r.chance) {
				r.chance = !0, t.push({
					kind: "land",
					rid: n.by,
					data: { card: "chance" }
				});
				continue;
			}
			if (ae(e, n.by).length === 0) {
				e.discard.push("chance"), t.push({
					kind: "burn",
					rid: n.by,
					data: { card: "chance" }
				});
				continue;
			}
			e.pending = n;
			return;
		}
		e.pending = n;
		return;
	}
}
function ue(e, t) {
	let n = Math.max(...e.players.map((t) => e.totals[t])), r = e.players.filter((t) => e.totals[t] === n);
	if (n >= 200 && r.length === 1) {
		e.phase = "done";
		return;
	}
	e.round += 1, e.dealer = (e.dealer + 1) % e.players.length;
	for (let t of e.players) e.discard.push(...ee(e.hands[t]));
	e.hands = R(e.players), e.phase = "deal", e.dealPtr = (e.dealer + 1) % e.players.length, e.dealCount = 0, e.turn = -1, e.flip7By = null, t.push({
		kind: "roundStart",
		data: { round: e.round }
	});
}
function de(e, t, n) {
	if (t.type === "tick") {
		if (e.phase === "done") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = [];
		if (t.flipping) ce(t, n);
		else if (!t.pending && t.phase === "deal") se(t, n);
		else if (!t.pending && t.phase === "roundEnd") ue(t, n);
		else return {
			state: e,
			fx: []
		};
		return {
			state: t,
			fx: n
		};
	}
	if (t.type === "hit" || t.type === "stay") {
		if (e.phase !== "play" || e.pending || e.flipping || e.players[e.turn] !== n.by) return { code: "games.flip7.errNotYourTurn" };
		let r = e.hands[n.by];
		if (!r || r.status !== "active") return { code: "games.flip7.errNotYourTurn" };
		let i = structuredClone(e), a = [];
		if (t.type === "stay") return M(r) === 0 ? { code: "games.flip7.errNoCard" } : (i.hands[n.by].status = "stayed", a.push({
			kind: "stay",
			rid: n.by
		}), U(i, a), {
			state: i,
			fx: a
		});
		let o = B(i);
		return o ? (H(i, n.by, o, a, !1), i.phase === "play" && !i.pending && !i.flipping && U(i, a), {
			state: i,
			fx: a
		}) : (V(i, a), {
			state: i,
			fx: a
		});
	}
	let r = e.pending;
	if (!r || r.by !== n.by) return { code: "games.flip7.errNotYourTurn" };
	let i = e.hands[t.target];
	if (!i) return { code: "games.flip7.errBadTarget" };
	if (r.kind === "chance") {
		if (t.target === n.by || i.status !== "active" || i.chance) return { code: "games.flip7.errBadTarget" };
	} else if (i.status !== "active") return { code: "games.flip7.errBadTarget" };
	let a = structuredClone(e), o = [];
	return a.pending = null, r.kind === "freeze" ? (a.discard.push("freeze"), a.hands[t.target].status = "frozen", o.push({
		kind: "freeze",
		rid: t.target,
		data: { by: n.by }
	})) : r.kind === "flip3" ? (a.discard.push("flip3"), a.flipping = {
		target: t.target,
		remaining: 3,
		queued: []
	}, o.push({
		kind: "flip3Start",
		rid: t.target,
		data: { by: n.by }
	})) : (a.hands[t.target].chance = !0, o.push({
		kind: "land",
		rid: t.target,
		data: {
			card: "chance",
			by: n.by
		}
	})), a.flipping || le(a, o), a.phase === "play" && !a.pending && !a.flipping && U(a, o), a.phase === "deal" && !a.pending && !a.flipping && z(a).length === 0 && V(a, o), {
		state: a,
		fx: o
	};
}
function fe(e) {
	return {
		public: {
			round: e.round,
			phase: e.phase,
			dealer: e.players[e.dealer],
			turn: e.phase === "play" && e.turn >= 0 ? e.players[e.turn] : null,
			pending: e.pending,
			flipping: e.flipping ? {
				target: e.flipping.target,
				remaining: e.flipping.remaining
			} : null,
			deckCount: e.deck.length,
			discard: e.discard,
			totals: e.totals,
			lastScores: e.lastScores,
			flip7By: e.flip7By,
			players: e.players.map((t) => ({
				rid: t,
				...e.hands[t]
			}))
		},
		private: {}
	};
}
function pe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.totals[n] - e.totals[t]);
	return {
		phase: "done",
		winner: [t[0]],
		ranking: t,
		scores: { ...e.totals }
	};
}
function me(e) {
	return e.flipping ? 780 : e.pending ? null : e.phase === "deal" ? 420 : e.phase === "roundEnd" ? re : null;
}
var he = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: N,
	schemas: {
		action: P,
		publicView: I,
		privateView: ne
	},
	setup: ie,
	reduce: de,
	viewFor: fe,
	status: pe,
	nextTickIn: me
};
//#endregion
//#region src/games/flip7/card.tsx
function ge({ light: e = !1 }) {
	let t = e ? "var(--color-surface)" : "var(--color-ink)";
	return /* @__PURE__ */ b("svg", {
		viewBox: "0 0 44 48",
		"aria-hidden": !0,
		focusable: "false",
		children: [
			/* @__PURE__ */ y("path", {
				d: "M22 44 1 12q5-7 11-3L22 44Z",
				fill: "var(--color-f7-coral)",
				stroke: t,
				strokeWidth: "1.7"
			}),
			/* @__PURE__ */ y("path", {
				d: "M22 44 13 5q7-5 12 2L22 44Z",
				fill: "var(--color-f7-gold)",
				stroke: t,
				strokeWidth: "1.7"
			}),
			/* @__PURE__ */ y("path", {
				d: "M22 44 26 6q8-4 11 3L22 44Z",
				fill: "var(--color-f7-cyan)",
				stroke: t,
				strokeWidth: "1.7"
			}),
			/* @__PURE__ */ y("path", {
				d: "M22 44 38 12q7-2 7 6L22 44Z",
				fill: "var(--color-f7-purple)",
				stroke: t,
				strokeWidth: "1.7"
			})
		]
	});
}
function _e() {
	return /* @__PURE__ */ b("span", {
		className: "f7-deck-back",
		children: [/* @__PURE__ */ y(ge, { light: !0 }), /* @__PURE__ */ y("span", {
			className: "f7-deck-seven",
			children: "7"
		})]
	});
}
function ve() {
	return /* @__PURE__ */ b("svg", {
		width: "27",
		height: "31",
		viewBox: "0 0 27 31",
		"aria-hidden": !0,
		focusable: "false",
		children: [/* @__PURE__ */ y("path", {
			d: "M13.5 2 25 6.5 22 21q-3 5-8.5 8Q8 26 5 21L2 6.5Z",
			fill: "var(--color-f7-cyan)",
			stroke: "var(--color-ink)",
			strokeWidth: "2"
		}), /* @__PURE__ */ y("path", {
			d: "m8 15 4 4 7-8",
			fill: "none",
			stroke: "var(--color-ink)",
			strokeWidth: "2.5",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})]
	});
}
function ye() {
	return /* @__PURE__ */ b("svg", {
		width: "28",
		height: "30",
		viewBox: "0 0 28 30",
		"aria-hidden": !0,
		focusable: "false",
		children: [/* @__PURE__ */ y("path", {
			d: "M14 2v26M2 15h24M5.5 6.5l17 17M22.5 6.5l-17 17",
			stroke: "var(--color-f7-felt-deep)",
			strokeWidth: "2.5",
			strokeLinecap: "round"
		}), /* @__PURE__ */ y("circle", {
			cx: "14",
			cy: "15",
			r: "3",
			fill: "var(--color-f7-cyan)",
			stroke: "var(--color-ink)",
			strokeWidth: "1.5"
		})]
	});
}
function W({ code: e }) {
	let t = d(), n = e.startsWith("n"), r = e.startsWith("p"), i = n ? Number(e.slice(1)) : null, a = n ? e.slice(1) : r ? `+${e.slice(1)}` : e === "x2" ? "×2" : e === "flip3" ? "×3" : "", o = n ? i <= 3 ? "low" : i <= 7 ? "mid" : i <= 10 ? "num" : "high" : r ? "mod" : e, s = n ? "FLIP" : r ? "BONUS" : e === "x2" ? "DOUBLE" : e === "chance" ? "CHANCE" : e === "freeze" ? "FREEZE" : "FLIP 3", c = e === "chance" ? t("games.flip7.chanceAria") : e === "freeze" ? t("games.flip7.actionFreeze") : e === "flip3" ? t("games.flip7.actionFlip3") : void 0;
	return /* @__PURE__ */ b("span", {
		className: `f7-card f7-card--${o}`,
		role: c ? "img" : void 0,
		"aria-label": c,
		children: [
			/* @__PURE__ */ y("span", { className: "f7-card-band" }),
			/* @__PURE__ */ y("span", {
				className: "f7-card-corner",
				children: a || (e === "chance" ? "✦" : e === "freeze" ? "❄" : "×3")
			}),
			/* @__PURE__ */ y("span", {
				className: "f7-card-fan",
				children: /* @__PURE__ */ y(ge, {})
			}),
			/* @__PURE__ */ y("span", {
				className: "f7-card-glyph",
				children: e === "chance" ? /* @__PURE__ */ y(ve, {}) : e === "freeze" ? /* @__PURE__ */ y(ye, {}) : a
			}),
			/* @__PURE__ */ y("span", {
				className: "f7-card-foot",
				children: s
			})
		]
	});
}
//#endregion
//#region src/games/flip7/view-player.tsx
function be(e) {
	return /* @__PURE__ */ y(Ce, {
		pub: e.public,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function xe(e, t) {
	let n = t.pending;
	return !n || e.status !== "active" ? !1 : n.kind !== "chance" || e.rid !== n.by && !e.chance;
}
function Se(e) {
	let t = a(null);
	return r(() => {
		let n = t.current;
		if (!n) return;
		let r = n.querySelector(".f7-table");
		if (!r) return;
		let i = window.matchMedia("(orientation: landscape)"), a = [
			"pad",
			"gap",
			"phase-h",
			"seat-h",
			"seat-w",
			"action-h",
			"rail-w",
			"columns",
			"row-h",
			"identity-w",
			"head-h",
			"card-w",
			"card-h",
			"card-unit",
			"card-gap",
			"progress-h",
			"name-font",
			"status-font",
			"score-font",
			"avatar",
			"deck-w",
			"deck-h",
			"rail-font"
		], o = (e, t, n) => Math.min(n, Math.max(e, t)), s = (e, t, r = "px") => {
			let i = `${t.toFixed(4)}${r}`;
			n.style.getPropertyValue(`--f7-${e}`) !== i && n.style.setProperty(`--f7-${e}`, i);
		}, c = () => {
			let t = n.getBoundingClientRect();
			if (!(i.matches && t.width >= 900 && t.height >= 400)) {
				if (n.dataset.f7Layout) {
					delete n.dataset.f7Layout, delete n.dataset.f7Columns;
					for (let e of a) n.style.removeProperty(`--f7-${e}`);
				}
				return;
			}
			n.dataset.f7Layout !== "wide" && (n.dataset.f7Layout = "wide");
			let c = o(6, Math.min(t.width, t.height) * .01, 12), l = o(8, Math.min(t.width, t.height) * .012, 14);
			s("pad", c), s("gap", l), s("phase-h", o(44, t.height * .055, 60)), s("seat-h", o(60, t.height * .076, 82)), s("seat-w", Math.max(212, (t.width - 2 * c - (e - 1) * l - 12) / e)), s("action-h", o(56, t.height * .067, 76));
			let u = r.getBoundingClientRect(), d = o(144, u.width * .12, 216), f = u.width - d - 2 * c - l - 6, p = e >= 5 && f >= 1160 && u.height >= 250 ? 2 : 1, m = Math.ceil(e / p), h = (f - 2 * c - (p - 1) * l - 16) / p, g = p === 2 ? o(218, u.height * .39, 300) : Math.max(146, Math.min(o(164, u.height * .26, 220), u.height - 4 * c - 6)), _ = Math.max(g, (u.height - 4 * c - 6 - (m - 1) * l) / m), v = p === 1 ? o(158, h * .18, 274) : 0, y = p === 2 ? o(42, _ * .2, 58) : 0, b = o(24, _ * .11, 34), x = o(6, h * .009, 12), S = h - 2 * c - 6 - v - (p === 1 ? l : 0), C = Math.max(80, Math.min(_ - 2 * c - 6 - y - b - l - 16, (S - 6 * x - 8) / 7 * 62 / 44)), w = C * 44 / 62, T = o(112, Math.min(u.height * .31, d * 62 / 44 - 12), 268), E = T * 44 / 62, D = String(p);
			n.dataset.f7Columns !== D && (n.dataset.f7Columns = D);
			let O = {
				"rail-w": d,
				"row-h": _,
				"identity-w": v,
				"head-h": y,
				"card-w": w,
				"card-h": C,
				"card-unit": w / 44,
				"card-gap": x,
				"progress-h": b,
				"name-font": o(18, _ * .12, 32),
				"status-font": o(16, _ * .085, 22),
				"score-font": o(28, _ * .19, 52),
				avatar: o(34, _ * .25, 70),
				"deck-w": E,
				"deck-h": T,
				"rail-font": o(14, d * .095, 20)
			};
			n.style.getPropertyValue("--f7-columns") !== D && n.style.setProperty("--f7-columns", D);
			for (let [e, t] of Object.entries(O)) s(e, t, e === "card-unit" ? "" : "px");
		}, l = new ResizeObserver(c);
		return l.observe(n), l.observe(r), i.addEventListener("change", c), c(), () => {
			l.disconnect(), i.removeEventListener("change", c), delete n.dataset.f7Layout, delete n.dataset.f7Columns;
			for (let e of a) n.style.removeProperty(`--f7-${e}`);
		};
	}, [e]), t;
}
function Ce({ pub: e, members: t, myRid: r, send: i }) {
	let o = d(), s = Se(e.players.length), c = e.players.find((e) => e.rid === r), u = (e) => t.find((t) => t.rid === e)?.name ?? e, f = e.pending?.by === r, _ = e.phase === "play" && !e.pending && !e.flipping && e.turn === r && c?.status === "active", x = a(null), S = f ? e.players.find((t) => xe(t, e))?.rid ?? r : e.pending?.by ?? e.flipping?.target ?? e.turn ?? r;
	n(() => {
		let e = () => {
			let e = x.current, t = Array.from(e?.children ?? []).find((e) => e.getAttribute("data-rid") === S);
			if (!e || !t) return;
			let n = e.getBoundingClientRect(), r = t.getBoundingClientRect();
			r.top < n.top + 5 ? e.scrollTop += r.top - n.top - 6 : r.bottom > n.bottom - 5 && (e.scrollTop += r.bottom - n.bottom + 6);
		};
		return e(), window.addEventListener("resize", e), () => window.removeEventListener("resize", e);
	}, [S, e.round]);
	let C = "info", w = "", T;
	return e.phase === "roundEnd" || e.phase === "done" ? (C = "done", w = o("games.flip7.roundEnd", { n: e.round }), e.flip7By && (T = o("games.flip7.flip7Banner", { name: u(e.flip7By) }))) : e.flipping ? (C = "warn", w = o("games.flip7.flipping", { name: u(e.flipping.target) })) : e.pending ? f ? (C = "accent", w = o(e.pending.kind === "freeze" ? "games.flip7.promptFreeze" : e.pending.kind === "flip3" ? "games.flip7.promptFlip3" : "games.flip7.promptChance")) : w = o("games.flip7.waitingTarget", { name: u(e.pending.by) }) : e.phase === "deal" ? w = o("games.flip7.deal") : _ ? (C = "accent", w = o("games.flip7.yourTurn")) : e.turn && (w = o("games.flip7.waitingTurn", { name: u(e.turn) })), /* @__PURE__ */ y("div", {
		ref: s,
		className: "f7-screen",
		children: /* @__PURE__ */ y(m, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ b("div", {
				className: "f7-banner flex flex-col gap-2",
				children: [/* @__PURE__ */ y(h, {
					tone: C,
					text: w,
					sub: T,
					chip: o("games.flip7.roundShort", { n: e.round }),
					accent: N.accent
				}), /* @__PURE__ */ y("div", {
					className: "f7-score-strip",
					children: /* @__PURE__ */ y(g, {
						variant: "medal",
						scroll: !0,
						members: t,
						myRid: r,
						anchorOf: (e) => `seat:${e}`,
						dimmed: (t) => e.players.find((e) => e.rid === t)?.status === "busted",
						action: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return !n || e.phase === "roundEnd" || e.phase === "done" ? null : e.pending?.by === t || e.phase === "play" && !e.pending && !e.flipping && e.turn === t && n.status === "active" ? "pending" : n.status === "stayed" || n.status === "frozen" ? "done" : null;
						},
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ b("span", {
								className: "flex items-center gap-0.5 text-xs font-extrabold whitespace-nowrap",
								children: [
									/* @__PURE__ */ y(l, {
										value: e.totals[t] ?? 0,
										className: "font-mono tabular-nums"
									}),
									(e.phase === "roundEnd" || e.phase === "done") && (e.lastScores?.[t] ?? 0) > 0 && /* @__PURE__ */ b("span", {
										className: "text-done-ink",
										children: ["+", e.lastScores?.[t]]
									}),
									n.status === "busted" && /* @__PURE__ */ y("span", {
										"aria-label": o("games.flip7.tagBusted"),
										children: "✕"
									})
								]
							}) : null;
						}
					})
				})]
			}),
			actionsHeight: "f7-action-slot",
			actions: /* @__PURE__ */ y("div", {
				className: "f7-footer",
				children: f ? /* @__PURE__ */ y("div", {
					className: "f7-footer-hint",
					children: o("games.flip7.pickSeat")
				}) : _ ? /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ b("button", {
					type: "button",
					"aria-label": o("games.flip7.stayAria"),
					disabled: !c || M(c) === 0,
					onClick: () => i({ type: "stay" }),
					className: "btn-base min-w-0 flex-1 bg-surface text-ink disabled:opacity-40",
					children: [
						o("games.flip7.stay"),
						" ",
						c && M(c) > 0 ? `+${j(c)}` : ""
					]
				}), /* @__PURE__ */ b("button", {
					type: "button",
					"aria-label": o("games.flip7.hitAria"),
					onClick: () => i({ type: "hit" }),
					className: "btn-base min-w-0 flex-2 text-white",
					style: { background: N.accent },
					children: [
						o("games.flip7.hit"),
						" ",
						/* @__PURE__ */ y("span", {
							"aria-hidden": !0,
							children: "›"
						})
					]
				})] }) : /* @__PURE__ */ y("div", {
					className: "f7-footer-hint f7-footer-wait",
					children: c && c.status !== "busted" && (e.phase === "play" || e.phase === "deal") ? o("games.flip7.potential", { n: j(c) }) : c?.status === "busted" ? o("games.flip7.bustZero") : o("games.flip7.targetChip", { n: 200 })
				})
			}),
			children: /* @__PURE__ */ b("div", {
				className: "f7-table",
				children: [/* @__PURE__ */ y(p, {
					kind: "sheen",
					base: "var(--color-f7-felt)",
					className: "absolute inset-0"
				}), /* @__PURE__ */ b("div", {
					className: "f7-table-layout",
					children: [/* @__PURE__ */ y(Te, {
						pub: e,
						myTurn: _,
						pendingMine: f,
						send: i
					}), /* @__PURE__ */ y("ul", {
						ref: x,
						className: "f7-mats",
						children: e.players.map((n) => /* @__PURE__ */ y(Ee, {
							p: n,
							pub: e,
							member: t.find((e) => e.rid === n.rid),
							isTurn: e.turn === n.rid && e.phase === "play" && !e.pending && !e.flipping,
							isFlipping: e.flipping?.target === n.rid,
							pendingMine: f,
							send: i
						}, n.rid))
					})]
				})]
			})
		})
	});
}
function we() {
	return /* @__PURE__ */ b("svg", {
		className: "f7-marquee-fan",
		viewBox: "0 0 54 42",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ y("path", {
				d: "M27 40 2 10q7-8 13-3L27 40Z",
				fill: "var(--color-f7-coral)",
				stroke: "var(--color-ink)",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ y("path", {
				d: "M27 40 17 3q7-5 13 3L27 40Z",
				fill: "var(--color-f7-gold)",
				stroke: "var(--color-ink)",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ y("path", {
				d: "M27 40 31 4q8-4 12 3L27 40Z",
				fill: "var(--color-f7-cyan)",
				stroke: "var(--color-ink)",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ y("path", {
				d: "M27 40 44 9q8-1 9 6L27 40Z",
				fill: "var(--color-f7-purple)",
				stroke: "var(--color-ink)",
				strokeWidth: "2"
			})
		]
	});
}
function Te({ pub: e, myTurn: t, pendingMine: n, send: r }) {
	let i = d(), { ref: a } = c("deck"), o = e.pending, s = /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(_e, {}), /* @__PURE__ */ y("span", {
		className: "f7-deck-count",
		children: e.deckCount
	})] }), l = o?.kind === "freeze" ? i("games.flip7.actionFreeze") : o?.kind === "flip3" ? i("games.flip7.actionFlip3") : i("games.flip7.actionChance");
	return /* @__PURE__ */ b("div", {
		className: "f7-head",
		children: [/* @__PURE__ */ b("div", {
			className: "f7-deck-anchor",
			children: [/* @__PURE__ */ y("div", {
				ref: a,
				className: "f7-deck-face",
				children: t ? /* @__PURE__ */ y("button", {
					type: "button",
					className: "f7-deck",
					"aria-label": i("games.flip7.hitAria"),
					onClick: () => r({ type: "hit" }),
					children: s
				}) : /* @__PURE__ */ y("div", {
					className: "f7-deck",
					children: s
				})
			}), /* @__PURE__ */ y("span", {
				className: "f7-deck-caption",
				children: t ? i("games.flip7.hitDeck") : i("games.flip7.deckLeft", { n: e.deckCount })
			})]
		}), /* @__PURE__ */ y("div", {
			className: "f7-head-aux",
			children: o ? /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ b("div", {
				className: "f7-action-card",
				"aria-label": l,
				children: [/* @__PURE__ */ y("span", {
					className: "f7-action-symbol",
					"aria-hidden": !0,
					children: o.kind === "freeze" ? "❄" : o.kind === "flip3" ? "×3" : "✦"
				}), /* @__PURE__ */ y("span", {
					className: "f7-action-card-label",
					children: l
				})]
			}), /* @__PURE__ */ b("div", {
				className: "f7-action-hint",
				children: [/* @__PURE__ */ y("strong", { children: i(n ? "games.flip7.pickSeat" : "games.flip7.waitingTag") }), /* @__PURE__ */ y("span", { children: l })]
			})] }) : /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ b("div", {
				className: "f7-discard",
				children: [/* @__PURE__ */ y("span", {
					className: "f7-discard-label",
					children: i("games.flip7.discard")
				}), /* @__PURE__ */ y("span", {
					className: "f7-discard-count",
					children: e.discard.length
				})]
			}), /* @__PURE__ */ b("div", {
				className: "f7-marquee",
				children: [
					/* @__PURE__ */ y(we, {}),
					/* @__PURE__ */ b("span", {
						className: "f7-marquee-name",
						children: ["FLIP ", /* @__PURE__ */ y("b", { children: "7" })]
					}),
					/* @__PURE__ */ y("span", {
						className: "f7-marquee-sub",
						children: i("games.flip7.sevenBonus")
					}),
					/* @__PURE__ */ y("span", {
						className: "f7-marquee-goal",
						children: i("games.flip7.targetChip", { n: 200 })
					})
				]
			})] })
		})]
	});
}
function Ee({ p: e, pub: t, member: n, isTurn: i, isFlipping: o, pendingMine: l, send: u }) {
	let p = d(), { ref: m } = c(`row:${e.rid}`), h = a(null), g = a([]), _ = [
		...e.nums.map((e) => `n${e}`),
		...e.mods.map((e) => `p${e}`),
		...e.x2 ? ["x2"] : [],
		...e.chance ? ["chance"] : []
	].join(",");
	r(() => {
		let e = _ ? _.split(",") : [], t = e.find((e) => !g.current.includes(e));
		g.current = e;
		let n = h.current, r = t ? Array.from(n?.children ?? []).find((e) => e.getAttribute("data-code") === t) : null;
		if (!n || !r) return;
		let i = n.getBoundingClientRect(), a = r.getBoundingClientRect();
		a.left < i.left + 4 ? n.scrollLeft += a.left - i.left - 4 : a.right > i.right - 4 && (n.scrollLeft += a.right - i.right + 4);
	}, [_]);
	let x = f[(n?.colorIndex ?? 0) % f.length], S = l && xe(e, t), C = l && !S, w = S ? p("games.flip7.pickThis") : e.status === "busted" ? p("games.flip7.tagBusted") : e.status === "frozen" ? p("games.flip7.tagFrozen") : e.status === "stayed" ? p("games.flip7.tagStayed") : C && t.pending?.kind === "chance" && e.rid === t.pending.by ? p("games.flip7.notSelf") : C && t.pending?.kind === "chance" && e.chance ? p("games.flip7.alreadyChance") : o ? p("games.flip7.flippingLeft", { n: t.flipping?.remaining ?? 0 }) : p(i ? "games.flip7.turnTag" : "games.flip7.waitingTag"), T = `f7-mat ${S ? "f7-mat--eligible" : ""} ${C ? "f7-mat--ineligible" : ""} ${i ? "f7-mat--turn" : ""} ${o ? "f7-mat--flipping" : ""} ${e.status === "busted" ? "f7-mat--busted" : ""}`, E = /* @__PURE__ */ b(v, { children: [
		/* @__PURE__ */ b("div", {
			className: "f7-mat-head",
			children: [
				/* @__PURE__ */ y("span", {
					className: "f7-avatar",
					style: { background: x.hex },
					children: n && /* @__PURE__ */ y("img", {
						src: s[n.avatar % s.length],
						alt: "",
						draggable: !1
					})
				}),
				/* @__PURE__ */ y("span", {
					className: "f7-mat-name",
					children: n?.name ?? e.rid
				}),
				/* @__PURE__ */ y("span", {
					className: `f7-mat-status ${S ? "f7-mat-status--eligible" : i ? "f7-mat-status--hot" : e.status === "busted" ? "f7-mat-status--busted" : ""}`,
					children: w
				}),
				/* @__PURE__ */ b("span", {
					className: "f7-mat-score",
					children: [
						p("games.flip7.roundScoreLabel"),
						" ",
						/* @__PURE__ */ y("strong", {
							className: "font-mono tabular-nums",
							children: j(e)
						})
					]
				})
			]
		}),
		/* @__PURE__ */ b("div", {
			ref: h,
			className: "f7-card-row",
			children: [
				e.nums.map((t) => /* @__PURE__ */ y(G, {
					rid: e.rid,
					code: `n${t}`
				}, `n${t}`)),
				e.mods.map((t) => /* @__PURE__ */ y(G, {
					rid: e.rid,
					code: `p${t}`
				}, `p${t}`)),
				e.x2 && /* @__PURE__ */ y(G, {
					rid: e.rid,
					code: "x2"
				}),
				e.chance && /* @__PURE__ */ y(G, {
					rid: e.rid,
					code: "chance"
				}),
				M(e) === 0 && /* @__PURE__ */ y("span", {
					className: "f7-card-slot",
					children: p("games.flip7.emptyHand")
				})
			]
		}),
		/* @__PURE__ */ b("div", {
			className: "f7-progress",
			"aria-label": `${e.nums.length}/7`,
			children: [
				/* @__PURE__ */ b("span", {
					className: "f7-progress-label",
					children: [e.nums.length, "/7"]
				}),
				Array.from({ length: 7 }, (t, n) => /* @__PURE__ */ y("span", {
					className: `f7-progress-dot ${n < e.nums.length ? "f7-progress-dot--filled" : ""}`,
					"aria-hidden": !0,
					children: n < e.nums.length ? "✦" : ""
				}, n)),
				e.flipped7 && /* @__PURE__ */ y("span", {
					className: "f7-flip7-tag",
					children: "FLIP 7!"
				}),
				(t.phase === "roundEnd" || t.phase === "done") && (t.lastScores?.[e.rid] ?? 0) > 0 && /* @__PURE__ */ b("span", {
					className: "f7-round-gain",
					children: ["+", t.lastScores?.[e.rid]]
				}),
				t.dealer === e.rid && /* @__PURE__ */ y("span", {
					className: "f7-dealer",
					"aria-label": p("games.flip7.dealer"),
					children: p("games.flip7.dealer")
				})
			]
		})
	] });
	return /* @__PURE__ */ y("li", {
		ref: m,
		"data-rid": e.rid,
		className: "f7-mat-li",
		children: S ? /* @__PURE__ */ y("button", {
			type: "button",
			className: T,
			"aria-label": `${p("games.flip7.pickThis")} ${n?.name ?? e.rid}`,
			onClick: () => u({
				type: "target",
				target: e.rid
			}),
			children: E
		}) : /* @__PURE__ */ y("div", {
			className: T,
			children: E
		})
	});
}
function G({ rid: e, code: t }) {
	let { ref: n, hidden: r } = c(`fcard:${e}:${t}`);
	return /* @__PURE__ */ y("span", {
		ref: n,
		"data-code": t,
		className: "inline-flex flex-none",
		style: { visibility: r ? "hidden" : void 0 },
		children: /* @__PURE__ */ y(W, { code: t })
	});
}
//#endregion
//#region src/games/flip7/bot.ts
var De = {
	base: .4,
	behindGain: .002,
	behindCap: .3,
	chanceRiskFactor: .3,
	chaseThreshold: .75
};
function Oe(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function ke(e) {
	let t = Array.from({ length: 13 }, (e, t) => t === 0 ? 1 : t), n = (e) => {
		--t[e];
	};
	for (let t of e.players) for (let e of t.nums) n(e);
	for (let t of e.discard) t.startsWith("n") && n(Number(t.slice(1)));
	return t.map((e) => Math.max(0, e));
}
function K(e, t) {
	if (e.deckCount === 0) return 1;
	let n = ke(e);
	return t.nums.reduce((e, t) => e + n[t], 0) / e.deckCount;
}
function q(e, t) {
	return (e.totals[t.rid] ?? 0) + j(t);
}
function Ae(e = De) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid);
		if (!i || i.status !== "active") return null;
		if (r.pending && r.pending.by === n.rid) {
			let e = r.players.filter((e) => e.status === "active"), t = e.filter((e) => e.rid !== n.rid);
			if (n.difficulty === "weak") {
				let n = r.pending.kind === "chance" ? t.filter((e) => !e.chance) : e;
				return n.length ? { action: {
					type: "target",
					target: Oe(n).rid
				} } : null;
			}
			if (r.pending.kind === "chance") {
				let e = t.filter((e) => !e.chance);
				return e.length ? { action: {
					type: "target",
					target: e.reduce((e, t) => q(r, e) <= q(r, t) ? e : t).rid
				} } : null;
			}
			if (r.pending.kind === "freeze") return { action: {
				type: "target",
				target: (t.length ? t : e).reduce((e, t) => q(r, e) + (e.nums.length >= 5 ? 12 * (e.nums.length - 4) : 0) >= q(r, t) + (t.nums.length >= 5 ? 12 * (t.nums.length - 4) : 0) ? e : t).rid
			} };
			if (!t.length) return { action: {
				type: "target",
				target: n.rid
			} };
			let a = t.reduce((e, t) => K(r, e) >= K(r, t) ? e : t);
			return { action: {
				type: "target",
				target: (K(r, a) < .25 && i.nums.length <= 3 ? i : a).rid
			} };
		}
		if (r.phase !== "play" || r.turn !== n.rid || r.pending || r.flipping) return null;
		let a = M(i) > 0;
		if (n.difficulty === "weak") return a ? { action: { type: Oe([
			"hit",
			"hit",
			"stay"
		]) } } : { action: { type: "hit" } };
		if (!a) return { action: { type: "hit" } };
		let o = j(i), s = (r.totals[n.rid] ?? 0) + o, c = Math.max(0, ...r.players.filter((e) => e.rid !== n.rid).map((e) => r.totals[e.rid] ?? 0));
		if (s >= 200 && s > c) return { action: { type: "stay" } };
		let l = Math.max(0, c - s), u = e.base + Math.min(e.behindCap, l * e.behindGain);
		return i.nums.length === 6 && (u = Math.max(u, e.chaseThreshold)), { action: { type: K(r, i) * (i.chance ? e.chanceRiskFactor : 1) < u ? "hit" : "stay" } };
	};
}
var je = Ae(), Me = (e, t, n) => {
	if (e.type === "hit") return n("games.flip7.hintHit");
	if (e.type === "stay") return n("games.flip7.hintStay");
	if (e.type === "target") {
		let e = t.public.pending?.kind;
		return n(e === "freeze" ? "games.flip7.hintFreeze" : e === "flip3" ? "games.flip7.hintFlip3" : "games.flip7.hintChance");
	}
	return "";
}, Ne = {
	needsAction(e, t) {
		let n = e.public;
		return n.phase === "play" ? n.pending ? n.pending.by === t.rid : n.turn === t.rid && !n.flipping : !1;
	},
	describeView(e, t) {
		let n = e.public, r = ["目标:先攒到 200 分。每轮翻数字牌(0-12)累加;翻到已有数字就爆掉(本轮 0 分);主动停牌(stay)保住当前分;集齐 7 张不同数字牌立即得 15 分奖励并收轮。修正牌(+n 与 ×2)在数字牌基础上结算。"];
		r.push(`第 ${n.round} 轮,牌堆剩 ${n.deckCount}。`);
		for (let e of n.players) {
			let i = e.rid === t.rid ? "你" : e.rid, a = {
				active: "行动中",
				stayed: "已停牌",
				frozen: "被冻结",
				busted: "已爆"
			}[e.status], o = [...e.mods.map((e) => `+${e}`), ...e.x2 ? ["×2"] : []];
			r.push(`  ${i}: 总分${n.totals[e.rid] ?? 0};本轮数字 [${e.nums.join(", ")}]${o.length ? ` 修正 ${o.join(" ")}` : ""}${e.chance ? " 有第二次机会" : ""} — ${a}`);
		}
		r.push(`弃牌堆(明牌,可用于估算剩余牌分布): ${n.discard.join(", ") || "(空)"}`);
		let i = n.players.find((e) => e.rid === t.rid);
		if (n.pending?.by === t.rid) {
			let e = {
				freeze: "冻结:选一名玩家立即停牌收轮(可指自己)",
				flip3: "连翻三张:选一名玩家强制连翻 3 张牌(可指自己)",
				chance: "第二次机会:转赠给一名没有第二次机会的玩家"
			}[n.pending.kind];
			r.push(`你抽到了行动牌「${n.pending.kind}」:${e}。输出 target 行动。`);
		} else n.turn === t.rid && i && r.push(`轮到你:hit 再翻一张(你现在有数字 [${i.nums.join(", ")}],翻到重复数字就爆)或 stay 停牌保分。`);
		return r.join("\n");
	},
	actionJsonSchema: { oneOf: [
		{
			type: "object",
			properties: { type: { const: "hit" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "stay" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "target" },
				target: {
					type: "string",
					description: "目标玩家 rid"
				}
			},
			required: ["type", "target"],
			additionalProperties: !1
		}
	] },
	parseAction(e, t, n) {
		let r = P.safeParse(e);
		if (!r.success) return null;
		let i = r.data;
		if (i.type === "tick") return null;
		let a = t.public;
		if (a.phase !== "play") return null;
		if (i.type === "target") {
			let e = a.pending;
			if (!e || e.by !== n.rid) return null;
			let t = a.players.find((e) => e.rid === i.target);
			return t ? e.kind === "chance" ? t.status === "active" && !t.chance ? i : null : t.status === "active" ? i : null : null;
		}
		if (a.pending || a.flipping) return null;
		let o = a.players.find((e) => e.rid === n.rid);
		return a.turn === n.rid && o?.status === "active" ? i : null;
	}
};
//#endregion
//#region src/games/flip7/fx.tsx
function Pe({ size: e }) {
	let t = d();
	return /* @__PURE__ */ y("span", {
		className: "f7-fx-stamp f7-fx-stamp--bust",
		style: { fontSize: e },
		children: t("games.flip7.tagBusted")
	});
}
function Fe({ size: e }) {
	let t = d();
	return /* @__PURE__ */ y("span", {
		className: "f7-fx-stamp f7-fx-stamp--saved",
		style: { fontSize: e },
		children: t("games.flip7.actionChance")
	});
}
function J(e, t) {
	return t ? e.anchor(`row:${t}`) : null;
}
function Y(e) {
	return Math.min(36, Math.max(17, e * .13));
}
function X({ code: e, width: t, height: n }) {
	let r = {
		width: t,
		height: n,
		"--f7-card-w": `${t}px`,
		"--f7-card-h": `${n}px`,
		"--f7-card-unit": t / 44
	};
	return /* @__PURE__ */ y("span", {
		className: "f7-fx-card",
		style: r,
		children: /* @__PURE__ */ y(W, { code: e })
	});
}
var Ie = {
	land(e, t) {
		let n = e.data, r = typeof n?.card == "string" ? n.card : null;
		if (!r || !e.rid) return null;
		let i = t.anchor(`fcard:${e.rid}:${r}`), a = t.anchor("deck");
		if (!i || !a) return null;
		let o = t.queued > 0 ? 180 : 380;
		return {
			ms: o,
			node: /* @__PURE__ */ y(C, {
				from: a,
				to: i,
				ms: o,
				children: /* @__PURE__ */ y(X, {
					code: r,
					width: a.w,
					height: a.w * i.h / i.w
				})
			}),
			hide: t.queued > 0 ? [] : [`fcard:${e.rid}:${r}`]
		};
	},
	actionDrawn(e, t) {
		let n = e.data, r = typeof n?.card == "string" && [
			"freeze",
			"flip3",
			"chance"
		].includes(n.card) ? n.card : null, i = J(t, e.rid);
		if (!r || !i) return null;
		let a = t.anchor("deck");
		return {
			ms: 750,
			node: /* @__PURE__ */ y(S, {
				at: i,
				ms: 750,
				children: /* @__PURE__ */ y(X, {
					code: r,
					width: a?.w ?? 44,
					height: a?.h ?? 62
				})
			})
		};
	},
	burn(e, t) {
		let n = J(t, e.rid);
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ y(S, {
				at: n,
				ms: 700,
				children: /* @__PURE__ */ y("span", {
					className: "f7-fx-stamp f7-fx-stamp--bust",
					style: { fontSize: Y(n.h) },
					children: "×"
				})
			})
		} : null;
	},
	bust(e, t) {
		let n = J(t, e.rid);
		return {
			ms: 900,
			node: /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(x, { ms: 700 }), n && /* @__PURE__ */ y(S, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ y(Pe, { size: Y(n.h) })
			})] })
		};
	},
	saved(e, t) {
		let n = J(t, e.rid);
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(S, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ y(Fe, { size: Y(n.h) })
			}), /* @__PURE__ */ y(w, {
				at: n,
				ms: 900
			})] })
		} : null;
	},
	flip7(e, t) {
		let n = J(t, e.rid);
		return {
			ms: 1400,
			node: /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(x, {
				ms: 1e3,
				className: "bg-done"
			}), n && /* @__PURE__ */ y(S, {
				at: n,
				ms: 1300,
				children: /* @__PURE__ */ y("span", {
					className: "f7-fx-stamp f7-fx-stamp--flip7",
					style: { fontSize: Y(n.h) },
					children: "FLIP 7 · +15"
				})
			})] })
		};
	},
	freeze(e, t) {
		let n = J(t, e.rid);
		if (!n) return null;
		let r = t.anchor("deck");
		return {
			ms: 800,
			node: /* @__PURE__ */ y(S, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ y(X, {
					code: "freeze",
					width: r?.w ?? 44,
					height: r?.h ?? 62
				})
			})
		};
	},
	flip3Start(e, t) {
		let n = J(t, e.rid);
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ y(w, {
				at: n,
				ms: 900
			})
		} : null;
	}
}, Z = 44 / 62, Q = (e, t, n) => Math.min(n, Math.max(e, t));
function $(e, t, n) {
	if (e === 0) return [[]];
	let r = [];
	for (let i = t; i <= Math.min(n, e); i++) for (let a of $(e - i, t, n)) r.push([i, ...a]);
	return r;
}
function Le(e) {
	return e.reduce((e, t) => e.flatMap((e) => t.map((t) => [...e, t])), [[]]);
}
function Re(e) {
	return [
		...e.nums.map((e) => "n" + e),
		...e.mods.map((e) => "p" + e),
		...e.x2 ? ["x2"] : [],
		...e.chance ? ["chance"] : []
	];
}
function ze(e, t, n, r, i) {
	let a = Q(128, t * .2, 168), o = Q(16, a * .115, 20), s = Q(44, a * .35, 64), c = Q(24, a * .19, 32), l = Q(44, a - Math.max(s, c * 1.2 + 4 + o * 1.2) - 12 - o * 1.2, 72), u = t - 2 * r - 6 - a - i - 36;
	if (n.every((e) => e === 0)) return {
		height: 2 * r + 6 + a + 40,
		widths: n.map(() => (e - (n.length - 1) * i) / n.length),
		cols: n.map(() => 1),
		rows: n.map(() => 1),
		cardHeights: n.map(() => 0),
		head: a,
		meta: o,
		avatar: s,
		score: l,
		name: c,
		cardArea: 0,
		density: 0,
		fit: 1,
		holes: 0,
		quality: 0,
		kind: "vertical-grid"
	};
	let d = null;
	for (let f of Le(n.map((e) => Array.from({ length: Math.min(e || 1, 7) }, (e, t) => t + 1)))) {
		let p = f.map((e, t) => Math.ceil(Math.max(1, n[t]) / e)), m = e - (n.length - 1) * i, h = (e, t) => n[t] === 0 ? 0 : f[t] * Z * ((e - (p[t] - 1) * i) / p[t]) + (f[t] - 1) * i, g = (e) => p.reduce((t, n, i) => t + Math.max(228, h(e, i) + 2 * r + 10), 0), _ = 0, v = Math.max(0, u);
		for (let e = 0; e < 28; e++) {
			let e = (_ + v) / 2;
			g(e) > m ? v = e : _ = e;
		}
		let y = _, b = p.map((e, t) => n[t] === 0 ? 0 : (y - (e - 1) * i) / e);
		if (Math.min(...b.filter((e, t) => n[t] > 0)) < 100) continue;
		let x = p.map((e, t) => Math.max(228, h(y, t) + 2 * r + 10)), S = m - x.reduce((e, t) => e + t, 0), C = x.reduce((e, t, r) => e + (n[r] > 0 ? t : 0), 0), w = x.map((e, t) => e + (n[t] > 0 ? S * e / C : 0)), T = 2 * r + 6 + a + i + 36 + y, E = n.reduce((e, t, n) => e + t * Z * b[n] ** 2, 0), D = E / (e * (n.includes(0) ? t : T)), O = 1 - Math.max(0, S) / m, k = n.reduce((e, t, n) => e + (t ? f[n] * p[n] - t : 0), 0), A = D + Math.min(...b.filter((e, t) => n[t] > 0)) * .002 + O * .13 - k * .012 + (n.includes(0) ? T / t * .05 : 0);
		(!d || A > d.quality) && (d = {
			height: T,
			widths: w,
			cols: f,
			rows: p,
			cardHeights: b,
			head: a,
			meta: o,
			avatar: s,
			score: l,
			name: c,
			cardArea: E,
			density: D,
			fit: O,
			holes: k,
			quality: A,
			kind: "vertical-grid"
		});
	}
	return d;
}
function Be(e, t, n, r, i) {
	if (n.includes(0)) return n.length === 1 ? {
		height: Math.min(t, 144),
		widths: [e],
		cols: [1],
		rows: [1],
		cardHeights: [0],
		head: 0,
		identity: 0,
		meta: 14,
		avatar: 40,
		score: 36,
		name: 18,
		cardArea: 0,
		density: 0,
		fit: 1,
		holes: 0,
		quality: 0,
		kind: "horizontal-scroll"
	} : null;
	let a = Q(n.some((e) => e >= 7) ? 134 : 120, e * .14, 152), o = n.map((e) => Math.min(7, Math.max(1, e))), s = (e - (n.length * (a + i + 2 * r + 10) + (n.length - 1) * i + o.reduce((e, t) => e + Math.max(0, t - 1) * i, 0))) / (o.reduce((e, t) => e + t, 0) * Z), c = e - (n.length - 1) * i, l = (e) => o.reduce((t, n) => t + Math.max(228, a + i + 2 * r + 10 + n * Z * e + (n - 1) * i), 0), u = 0, d = Math.min(220, t - 2 * r - 42, s);
	for (let e = 0; e < 28; e++) {
		let e = (u + d) / 2;
		l(e) > c ? d = e : u = e;
	}
	let f = u;
	if (f < 80) return null;
	let p = o.map((e) => Math.max(228, a + i + 2 * r + 10 + e * Z * f + (e - 1) * i)), m = e - (n.length - 1) * i - p.reduce((e, t) => e + t, 0), h = p.map((e) => e + m * e / p.reduce((e, t) => e + t, 0)), g = Math.max(125.6 + 2 * r + 6, f + 2 * r + 42), _ = n.reduce((e, t) => e + Math.min(t, 7) * Z * f ** 2, 0), v = _ / (e * g), y = v + f * 4e-4;
	return {
		height: g,
		widths: h,
		cols: o,
		rows: n.map(() => 1),
		cardHeights: n.map(() => f),
		head: 0,
		identity: a,
		meta: 14,
		avatar: 40,
		score: 36,
		name: 18,
		cardArea: _,
		density: v,
		fit: 1,
		holes: 0,
		quality: y,
		kind: "horizontal-scroll"
	};
}
function Ve(e, t, n, r) {
	let i = Q(6, Math.min(e, t) * .01, 12), a = Q(8, Math.min(e, t) * .012, 14), o = r && e >= 760 && t >= 300, s = r ? Q(52, t * .075, 84) : 88, c = r ? Q(56, t * .07, 76) : 64, l = t - 2 * i - s - c - 2 * a, u = e - 4 * i - 22, d = l - 2 * i - 6, f = () => {
		let e = 230 - 2 * i - 6 - 72 - a - 36, t = n.map((t, r) => ({
			start: r,
			count: 1,
			height: 230,
			widths: [u],
			cols: [Math.max(1, n[r])],
			rows: [1],
			cardHeights: [Math.max(78, Math.min(112, e))],
			head: 72,
			meta: 14,
			avatar: 40,
			score: 44,
			name: 18,
			identity: 0,
			kind: "phone-scroll",
			density: 0,
			cardArea: 0,
			fit: 1,
			holes: 0,
			quality: 0
		}));
		return {
			pad: i,
			gap: a,
			top: s,
			bottom: c,
			body: l,
			listW: u,
			listH: d,
			landscape: r,
			wide: !1,
			low: !1,
			rows: t,
			totalH: n.length * 230 + (n.length - 1) * a
		};
	};
	if (!o) return f();
	let p = t < 540, m = n.length === 3 && !p ? [[3]] : $(n.length, p ? 1 : 2, 3), h = [], g = /* @__PURE__ */ new Map(), _ = (e) => {
		for (let t of e) {
			let e = 0, r = [];
			for (let o of t) {
				let t = n.slice(e, e + o), s = t.join(","), c = p || o === 1 ? Be : ze, l;
				if (g.has(s) ? l = g.get(s) ?? null : (l = c(u, d, t, i, a), g.set(s, l)), !l) break;
				r.push({
					...l,
					start: e,
					count: o
				}), e += o;
			}
			if (e !== n.length) continue;
			let o = r.reduce((e, t) => e + t.height, 0) + (r.length - 1) * a, s = r.reduce((e, t) => e + t.cardArea, 0) / (u * o), c = r.flatMap((e) => e.cardHeights).filter((e) => e > 0), l = c.length ? Math.min(...c) : 0, f = s + Math.min(l, 350) * 45e-5 - Math.max(0, o / d - 1) * .04 - r.length * .012;
			h.push({
				rows: r,
				totalH: o,
				score: f,
				density: s,
				minCard: l,
				partition: t
			});
		}
	};
	_(m), h.length || _($(n.length, 1, 3)), h.sort((e, t) => t.score - e.score);
	let v = h[0];
	return v ? {
		pad: i,
		gap: a,
		top: s,
		bottom: c,
		body: l,
		listW: u,
		listH: d,
		landscape: r,
		wide: !0,
		low: p,
		...v
	} : f();
}
function He(e) {
	let t = a(null), [n, s] = o({
		width: 343,
		height: 736,
		landscape: !1
	});
	return r(() => {
		let e = t.current;
		if (!e) return;
		let n = window.matchMedia("(orientation: landscape)"), r = !0, i = () => {
			if (!r) return;
			let { width: t, height: i } = e.getBoundingClientRect();
			t <= 0 || i <= 0 || s((e) => e.width === t && e.height === i && e.landscape === n.matches ? e : {
				width: t,
				height: i,
				landscape: n.matches
			});
		}, a = new ResizeObserver(i);
		return a.observe(e), n.addEventListener("change", i), queueMicrotask(i), () => {
			r = !1, a.disconnect(), n.removeEventListener("change", i);
		};
	}, []), {
		ref: t,
		plan: i(() => Ve(n.width, n.height, e.split(",").map(Number), n.landscape), [
			n.width,
			n.height,
			n.landscape,
			e
		])
	};
}
function Ue(e) {
	let t = I.safeParse(e.public);
	return t.success && t.data.phase === "done" && e.result.ranking.length > 0 && e.result.ranking.every((e) => t.data.players.some((t) => t.rid === e)) ? /* @__PURE__ */ y(We, {
		...e,
		pub: t.data
	}) : /* @__PURE__ */ y(D, {
		result: e.result,
		members: e.members,
		myRid: e.myRid,
		accent: N.accent,
		onPlayAgain: e.onPlayAgain,
		onBackToLobby: e.onBackToLobby
	});
}
function We({ pub: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let o = d(), c = u((e) => e.locale), l = t.ranking.map((t) => e.players.find((e) => e.rid === t)), { ref: p, plan: h } = He(l.map((e) => Re(e).length).join(",")), g = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? _(t, c) : e;
	}, x = t.winner.map(g).join(" / "), S = {
		"--f7-over-pad": `${h.pad}px`,
		"--f7-over-gap": `${h.gap}px`,
		"--f7-over-top": `${h.top}px`,
		"--f7-over-bottom": `${h.bottom}px`
	};
	return /* @__PURE__ */ b("div", {
		ref: p,
		className: "f7-over",
		"data-orientation": h.landscape ? "landscape" : "portrait",
		"data-layout": h.wide ? "wide" : "stack",
		style: S,
		children: [t.winner.length > 0 && /* @__PURE__ */ y(E, {}), /* @__PURE__ */ y(m, {
			adaptive: !0,
			scroll: !1,
			actionsHeight: "f7-over-action-height",
			banner: /* @__PURE__ */ b("header", {
				className: "f7-over-heading",
				children: [/* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y("h1", { children: o("session.result.title") }), /* @__PURE__ */ y("p", { children: o("games.flip7.finalRound", { n: e.round }) })] }), x && /* @__PURE__ */ y("strong", {
					className: "f7-over-winner",
					title: x,
					children: o("games.flip7.matchWinner", { name: x })
				})]
			}),
			actions: i || a ? /* @__PURE__ */ b("div", {
				className: "f7-over-actions",
				children: [i && /* @__PURE__ */ y("button", {
					type: "button",
					className: "btn-base text-white",
					style: { background: N.accent },
					onClick: i,
					children: o("session.result.playAgain")
				}), a && /* @__PURE__ */ y("button", {
					type: "button",
					className: "btn-quiet",
					onClick: a,
					children: o("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ y("p", {
				className: "f7-over-wait",
				children: o("session.result.waitHost")
			}),
			children: /* @__PURE__ */ y("div", {
				className: "f7-over-mats",
				role: "list",
				"aria-label": o("games.flip7.finalRankAria"),
				children: h.rows.map((i) => /* @__PURE__ */ y("div", {
					className: "f7-over-row",
					role: "presentation",
					style: { gridTemplateColumns: i.widths.map((e) => `minmax(0, ${e}fr)`).join(" ") },
					children: l.slice(i.start, i.start + i.count).map((a, c) => {
						let l = i.start + c, u = t.ranking[l], d = n.find((e) => e.rid === u), p = t.winner.includes(u), m = t.autopilot?.[u], _ = g(u), x = t.scores?.[u], S = e.lastScores?.[u], C = Re(a), w = C.length === 0, E = a.flipped7 ? "FLIP 7!" : a.status === "busted" ? o("games.flip7.tagBusted") : a.status === "frozen" ? o("games.flip7.tagFrozen") : a.status === "stayed" ? o("games.flip7.tagStayed") : "", D = i.cardHeights[c], O = {
							"--f7-over-card-viewport": `${Math.max(0, i.widths[c] - 2 * h.pad - 10 - (i.identity ?? 0) - (i.identity ? h.gap : 0))}px`,
							"--f7-over-row-h": `${i.height}px`,
							"--f7-over-head-h": `${i.head}px`,
							"--f7-over-identity-w": `${i.identity ?? 0}px`,
							"--f7-over-card-h": `${D}px`,
							"--f7-over-card-w": `${D * 44 / 62}px`,
							"--f7-over-card-unit": D / 62,
							"--f7-over-card-cols": i.cols[c],
							"--f7-over-avatar": `${i.avatar}px`,
							"--f7-over-name-font": `${i.name}px`,
							"--f7-over-meta-font": `${i.meta}px`,
							"--f7-over-score-font": `${i.score}px`
						}, k = /* @__PURE__ */ b("div", {
							className: "f7-over-avatar-box",
							children: [/* @__PURE__ */ b("span", {
								className: "f7-over-avatar",
								style: { background: f[(d?.colorIndex ?? 0) % f.length].hex },
								children: [d && /* @__PURE__ */ y("img", {
									src: s[d.avatar % s.length],
									alt: "",
									draggable: !1
								}), /* @__PURE__ */ y("b", {
									className: "f7-over-rank",
									"aria-hidden": !0,
									children: p ? "👑" : l + 1
								})]
							}), i.kind !== "vertical-grid" && !w && /* @__PURE__ */ y("span", {
								className: "f7-over-status",
								"aria-hidden": !E,
								children: E || "\xA0"
							})]
						}), A = /* @__PURE__ */ b("div", {
							className: "f7-over-person",
							children: [
								/* @__PURE__ */ b("div", {
									className: "f7-over-name",
									children: [/* @__PURE__ */ y("strong", {
										title: _,
										children: _
									}), u === r && /* @__PURE__ */ y("small", { children: o("lobby.you") })]
								}),
								/* @__PURE__ */ b("div", {
									className: "f7-over-person-meta",
									children: [(i.kind === "vertical-grid" || w) && E && /* @__PURE__ */ y("span", {
										className: "f7-over-status",
										children: E
									}), m !== void 0 && m > 0 && /* @__PURE__ */ b("small", {
										className: "f7-over-autopilot",
										children: [/* @__PURE__ */ y(T, { size: 14 }), /* @__PURE__ */ y("span", {
											title: o("session.autopilot.share", { n: Math.round(m * 100) }),
											children: o("session.autopilot.share", { n: Math.round(m * 100) })
										})]
									})]
								}),
								w && /* @__PURE__ */ y("span", {
									className: "f7-over-empty",
									children: o("games.flip7.finalEmpty")
								})
							]
						}), j = /* @__PURE__ */ b("div", {
							className: "f7-over-score-block",
							children: [/* @__PURE__ */ b("div", {
								className: "f7-over-score",
								children: [/* @__PURE__ */ y("span", { children: o("games.flip7.totalScoreLabel") }), /* @__PURE__ */ y("strong", {
									className: "font-mono tabular-nums",
									children: x ?? "—"
								})]
							}), /* @__PURE__ */ b("div", {
								className: "f7-over-gain",
								children: [/* @__PURE__ */ y("span", { children: o("games.flip7.lastRoundGain") }), /* @__PURE__ */ y("b", {
									className: "font-mono tabular-nums",
									children: S === void 0 ? "—" : `+${S}`
								})]
							})]
						});
						return /* @__PURE__ */ y("div", {
							role: "listitem",
							"aria-posinset": l + 1,
							"aria-setsize": t.ranking.length,
							className: "f7-over-player",
							"data-kind": i.kind,
							"data-empty": w,
							"data-winner": p,
							"data-busted": a.status === "busted",
							style: O,
							children: w ? /* @__PURE__ */ b("div", {
								className: "f7-over-zero",
								children: [
									k,
									A,
									j
								]
							}) : /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ b("div", {
								className: "f7-over-identity",
								children: [
									k,
									A,
									j
								]
							}), /* @__PURE__ */ y("div", {
								className: "f7-over-card-row",
								"aria-label": o("games.flip7.finalCardsAria", { name: _ }),
								children: C.map((e) => /* @__PURE__ */ y(W, { code: e }, e))
							})] })
						}, u);
					})
				}, i.start))
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/flip7/entry.tsx
var Ge = {
	definition: he,
	View: be,
	bot: je,
	describe: Me,
	llm: Ne,
	fx: Ie,
	OverView: Ue,
	locales: {
		zh: {
			name: "七翻天",
			desc: "别翻到重复数字,集齐 7 张立赚 15 分",
			rules: "目标:按轮累计得分,一轮结束后有玩家总分达到 200 且独居第一时游戏结束,总分最高者获胜。\n准备:\n· 牌堆共 94 张:数字牌 0 有一张。\n· 数字牌 1 至 12 各有多少数字就有多少张(1 一张、2 两张……12 十二张)。\n· 修正牌为加 2、加 4、加 6、加 8、加 10 与翻倍,各一张。\n· 行动牌「冻结」「连翻三张」「第二次机会」各三张。\n· 每轮先给每人发一张明牌;发到行动牌时立即结算,然后再继续发牌。\n流程:\n· 从发牌员左手边开始,轮流向每位活跃玩家发牌:轮到你时选择「要牌」再翻一张,或「停牌」。\n· 停牌即锁定本轮得分并退出本轮;面前至少有一张牌才能停牌。\n· 翻到与面前已有数字重复的数字牌即爆掉:本轮出局,获得 0 分。\n· 集齐 7 张不同数字牌立即结束本轮,并额外获得 15 分(修正牌与行动牌不计入这 7 张)。\n· 冻结:指定一名活跃玩家(可以是自己),其立即按停牌结算并退出本轮。\n· 连翻三张:指定一名活跃玩家连续翻三张牌,爆掉或集齐 7 张即提前停止。\n· 连翻期间翻出的冻结与连翻三张,在翻完后才结算。\n· 第二次机会:抵消一次爆牌,弃掉它与那张重复数字牌;同时只能持有一张。\n· 再次获得第二次机会须转赠其他活跃玩家,无人可赠则弃掉;一轮结束时一律弃掉。\n计分:\n· 先算数字牌总和,有翻倍牌则总和翻倍,再加修正牌分值,最后加 Flip 7 的 15 分奖励。\n· 停牌与冻结都按上述方式保留得分;爆掉者本轮获得 0 分。\n结束:\n· 一轮结束后,若有玩家总分达到 200 且无人与其并列第一,游戏结束。\n· 若并列第一则继续下一轮,直到出现唯一胜者。",
			roundShort: "第 {{n}} 轮",
			deal: "发牌中…",
			yourTurn: "轮到你:要牌还是停牌?",
			waitingTurn: "等 {{name}} 决定…",
			hit: "要牌",
			stay: "停牌",
			hitAria: "要牌,再翻一张",
			stayAria: "停牌,锁定本轮得分",
			promptFreeze: "冻结谁?(可以是自己)",
			promptFlip3: "让谁连翻三张?",
			promptChance: "把第二次机会转赠给谁?",
			waitingTarget: "等 {{name}} 选择目标…",
			flipping: "{{name}} 连翻三张中…",
			tagBusted: "爆了",
			tagFrozen: "冻结",
			tagStayed: "停牌",
			chanceAria: "第二次机会:可抵消一次爆牌",
			flip7Banner: "{{name}} 集齐 7 张,Flip 7!",
			roundEnd: "第 {{n}} 轮结束",
			deckLeft: "牌堆 {{n}}",
			discard: "弃牌",
			sevenBonus: "7 个不同数字  +15 分",
			roundScoreLabel: "本轮",
			hitDeck: "点击要牌",
			pickSeat: "点选可用桌位",
			pickThis: "选此玩家",
			notSelf: "须转赠他人",
			alreadyChance: "已有机会",
			turnTag: "行动中",
			waitingTag: "等待中",
			flippingLeft: "还需翻 {{n}} 张",
			emptyHand: "等待发牌",
			dealer: "庄",
			actionFreeze: "冻结",
			actionFlip3: "连翻三张",
			actionChance: "第二次机会",
			targetChip: "{{n}} 分获胜",
			potential: "本轮 {{n}}",
			bustZero: "本轮 0 分",
			errNotYourTurn: "现在轮不到你",
			errBadTarget: "不能选这个目标",
			errNoCard: "面前还没有牌,不能停牌",
			hintHit: "要牌,再翻一张",
			hintStay: "停牌,锁定当前分数",
			hintFreeze: "冻结一名活跃玩家(含自己)",
			hintFlip3: "让一名活跃玩家连翻三张(含自己)",
			hintChance: "把第二次机会转赠给一名活跃玩家",
			matchWinner: "{{name}} 获胜",
			finalRound: "第 {{n}} 轮的最终牌桌",
			totalScoreLabel: "总分",
			lastRoundGain: "本轮入账",
			finalEmpty: "无手牌",
			finalCardsAria: "{{name}} 的末轮手牌",
			finalRankAria: "最终排名"
		},
		en: {
			name: "Flip 7",
			desc: "Don't flip a duplicate — collect 7 numbers for +15",
			rules: "Goal: scores accumulate over rounds. The game ends after a round in which a player reaches 200 points and holds the sole lead; the highest total wins.\nSetup:\n· The deck has 94 cards: a single 0 among the number cards.\n· Number cards 1–12 each have as many copies as their number (one 1, two 2s … twelve 12s).\n· Modifier cards: +2, +4, +6, +8, +10 and ×2, one each.\n· Action cards: Freeze, Flip Three and Second Chance, three each.\n· At the start of each round every player is dealt one face-up card; any action card dealt is resolved immediately before dealing continues.\nPlay:\n· Starting from the dealer's left, each active player is offered a card in turn: choose Hit to flip another card, or Stay.\n· Staying banks your round score and leaves the round; you need at least one card in front of you to Stay.\n· Flipping a number you already have in front of you is a bust: you're out of the round and score 0.\n· Collecting 7 different number cards ends the round immediately and scores +15 (modifier and action cards don't count toward the 7).\n· Freeze: pick an active player (maybe yourself); they bank their score and leave the round at once.\n· Flip Three: pick an active player who must flip three cards in a row, stopping early on a bust or a Flip 7.\n· Freeze and Flip Three cards revealed along the way resolve only after all three flips.\n· Second Chance: cancels one bust — discard it together with the duplicate number card. You may hold only one at a time.\n· A second Second Chance must be passed to another active player, or discarded if nobody can take it; all unused ones are discarded at the end of the round.\nScoring:\n· Add up your number cards, double the sum if you have the ×2 card, then add any modifier cards, and finally the +15 Flip 7 bonus.\n· Staying and being frozen both keep this score; busting scores 0 for the round.\nEnd:\n· After a round, if any player has 200 or more points with no tie for first place, the game ends.\n· On a tie for the lead, play continues until there is a single winner.",
			roundShort: "Round {{n}}",
			deal: "Dealing…",
			yourTurn: "Your call: hit or stay?",
			waitingTurn: "Waiting for {{name}}…",
			hit: "Hit",
			stay: "Stay",
			hitAria: "Hit — flip another card",
			stayAria: "Stay — bank your round score",
			promptFreeze: "Freeze whom? (yourself allowed)",
			promptFlip3: "Who flips three cards?",
			promptChance: "Pass the Second Chance to whom?",
			waitingTarget: "Waiting for {{name}} to pick a target…",
			flipping: "{{name}} is flipping three…",
			tagBusted: "Bust",
			tagFrozen: "Frozen",
			tagStayed: "Stayed",
			chanceAria: "Second Chance: cancels one bust",
			flip7Banner: "{{name}} collected 7 — Flip 7!",
			roundEnd: "Round {{n}} over",
			deckLeft: "Deck {{n}}",
			discard: "Discard",
			sevenBonus: "7 unique numbers  +15 pts",
			roundScoreLabel: "Round",
			hitDeck: "Tap to hit",
			pickSeat: "Tap an eligible player",
			pickThis: "Choose player",
			notSelf: "Pass to another",
			alreadyChance: "Has a chance",
			turnTag: "Acting",
			waitingTag: "Waiting",
			flippingLeft: "{{n}} flips left",
			emptyHand: "Awaiting cards",
			dealer: "D",
			actionFreeze: "Freeze",
			actionFlip3: "Flip Three",
			actionChance: "Second Chance",
			targetChip: "{{n}} to win",
			potential: "Round {{n}}",
			bustZero: "0 this round",
			errNotYourTurn: "Not your move right now",
			errBadTarget: "Invalid target",
			errNoCard: "No card in front of you — cannot stay",
			hintHit: "Hit — flip another card",
			hintStay: "Stay and bank your score",
			hintFreeze: "Freeze an active player (yourself allowed)",
			hintFlip3: "Make an active player flip three (yourself allowed)",
			hintChance: "Pass the Second Chance to an active player",
			matchWinner: "{{name}} wins",
			finalRound: "Final table · Round {{n}}",
			totalScoreLabel: "Total",
			lastRoundGain: "Last round",
			finalEmpty: "No cards",
			finalCardsAria: "Final-round cards of {{name}}",
			finalRankAria: "Final ranking"
		}
	}
};
//#endregion
export { Ge as default };
