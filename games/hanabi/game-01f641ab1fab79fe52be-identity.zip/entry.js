import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { useT as i } from "@bgparty/sdk/i18n";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { LogTicker as c } from "@bgparty/sdk/ui/log-sheet";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { Floater as p, FlySprite as m, PulseBox as h } from "@bgparty/sdk/fx/primitives";
import { Confetti as g } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as _, OptionSection as v } from "@bgparty/sdk/ui/game-options";
//#region src/games/hanabi/meta.ts
var y = {
	id: "hanabi",
	tier: "alpha",
	mechanics: ["deduction", "hand-management"],
	interactionTags: ["cooperative", "communication-limits"],
	nameKey: "games.hanabi.name",
	descKey: "games.hanabi.desc",
	rulesKey: "games.hanabi.rules",
	icon: "🎆",
	iconImg: "games/hanabi.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/hanabi/en.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [4],
	accent: "#7c3aed",
	releasedAt: "2026-09-21",
	search: {
		py: "hua huo",
		init: "hh"
	},
	hotseat: "off"
}, b = [
	"white",
	"yellow",
	"red",
	"blue",
	"green"
], x = t.enum([
	"white",
	"yellow",
	"red",
	"blue",
	"green",
	"rainbow"
]), S = t.int().min(1).max(5), C = t.object({
	id: t.int(),
	color: x,
	num: S
}), ee = t.object({
	pos: t.array(x),
	posN: t.array(S),
	neg: t.array(x),
	negN: t.array(S)
}), w = t.object({ variant: t.enum([
	"base",
	"rainbow",
	"rainbowWild"
]).default("base") }).default({ variant: "base" }), te = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("hint"),
		target: t.string(),
		hint: t.discriminatedUnion("kind", [t.object({
			kind: t.literal("color"),
			color: x
		}), t.object({
			kind: t.literal("number"),
			num: S
		})])
	}),
	t.object({
		type: t.literal("play"),
		index: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("discard"),
		index: t.int().nonnegative()
	})
]), T = t.string(), ne = t.discriminatedUnion("kind", [t.object({
	kind: t.literal("color"),
	color: x
}), t.object({
	kind: t.literal("number"),
	num: S
})]), re = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("hint"),
		from: T,
		to: T,
		hint: ne
	}),
	t.object({
		k: t.literal("play"),
		rid: T,
		card: C,
		complete: t.boolean()
	}),
	t.object({
		k: t.literal("bust"),
		rid: T,
		card: C
	}),
	t.object({
		k: t.literal("discard"),
		rid: T,
		card: C
	})
]), ie = t.object({
	variant: t.enum([
		"base",
		"rainbow",
		"rainbowWild"
	]),
	fireworks: t.record(t.string(), t.int().min(0).max(5)),
	clues: t.int().min(0).max(8),
	fuses: t.int().min(0).max(3),
	deckCount: t.int().nonnegative(),
	discard: t.array(C),
	turn: T,
	lastRound: t.boolean(),
	players: t.array(t.object({
		rid: T,
		handCount: t.int().nonnegative()
	})),
	result: t.object({
		score: t.int().nonnegative(),
		reason: t.enum([
			"score",
			"bust",
			"perfect"
		])
	}).nullable(),
	log: t.array(re)
}), ae = t.object({
	others: t.record(T, t.array(C)),
	myMarks: t.array(ee)
}), oe = {
	1: 3,
	2: 2,
	3: 2,
	4: 2,
	5: 1
};
function E(e) {
	return e === "base" ? [...b] : [...b, "rainbow"];
}
var D = () => ({
	pos: [],
	posN: [],
	neg: [],
	negN: []
}), O = 60;
function k(e, t) {
	e.log.push(t), e.log.length > O && e.log.splice(0, e.log.length - O);
}
function se(e, t, n) {
	return t.color === n || e === "rainbowWild" && t.color === "rainbow";
}
function ce(t, n, r) {
	let i = t.variant, a = E(i), o = [], s = 0;
	for (let e of a) for (let [t, n] of Object.entries(oe)) for (let r = 0; r < n; r += 1) o.push({
		id: s++,
		color: e,
		num: Number(t)
	});
	let c = 0;
	for (let t = o.length - 1; t > 0; --t) {
		let n = e(r, c, t + 1);
		c += 1, [o[t], o[n]] = [o[n], o[t]];
	}
	let l = n.length <= 3 ? 5 : 4, u = {}, d = {}, f = 0;
	for (let e of n) u[e] = o.slice(f, f + l), d[e] = u[e].map(D), f += l;
	let p = {};
	for (let e of a) p[e] = 0;
	return {
		state: {
			players: n,
			variant: i,
			hands: u,
			marks: d,
			deck: o.slice(f),
			discard: [],
			fireworks: p,
			clues: 8,
			fuses: 0,
			turn: 0,
			lastRound: null,
			phase: "play",
			result: null,
			log: []
		},
		fx: n.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: { count: l },
			for: n.filter((t) => t !== e),
			secret: { cards: u[e] },
			...t > 0 ? { with: !0 } : {}
		}))
	};
}
function A(e) {
	return Object.values(e.fireworks).reduce((e, t) => e + t, 0);
}
function j(e, t, n) {
	if (e.lastRound !== null || e.deck.length === 0) return !1;
	let r = e.deck[0];
	return e.deck = e.deck.slice(1), e.hands[t].push(r), e.marks[t].push(D()), n.push({
		kind: "draw",
		rid: t,
		data: { index: e.hands[t].length - 1 },
		for: e.players.filter((e) => e !== t),
		secret: { card: r }
	}), e.deck.length === 0;
}
function M(e, t) {
	if (t) e.lastRound = e.players.length;
	else if (e.lastRound !== null && (--e.lastRound, e.lastRound === 0)) {
		e.phase = "done", e.result = {
			score: A(e),
			reason: "score"
		};
		return;
	}
	e.turn = (e.turn + 1) % e.players.length;
}
function le(e, t, n) {
	if (e.phase !== "play") return { code: "games.hanabi.errDone" };
	let r = e.players[e.turn];
	if (n.by !== r) return { code: "games.hanabi.errNotYourTurn" };
	if (t.type === "hint") {
		if (e.clues === 0) return { code: "games.hanabi.errNoClues" };
		if (t.target === n.by || !e.players.includes(t.target)) return { code: "games.hanabi.errBadTarget" };
		let r = e.hands[t.target];
		if (t.hint.kind === "color" && t.hint.color === "rainbow" && e.variant === "rainbowWild") return { code: "games.hanabi.errRainbowColor" };
		let i = (n) => t.hint.kind === "color" ? se(e.variant, n, t.hint.color) : n.num === t.hint.num, a = r.map((e, t) => i(e) ? t : -1).filter((e) => e >= 0);
		if (a.length === 0) return { code: "games.hanabi.errEmptyHint" };
		let o = structuredClone(e), s = o.marks[t.target], c = t.hint.kind === "color", l = t.hint.kind === "color" ? t.hint.color : t.hint.num;
		return o.hands[t.target].forEach((e, t) => {
			let n = s[t], r = i(e);
			if (c) {
				let e = r ? n.pos : n.neg;
				e.includes(l) || e.push(l);
			} else {
				let e = r ? n.posN : n.negN;
				e.includes(l) || e.push(l);
			}
		}), --o.clues, k(o, {
			k: "hint",
			from: n.by,
			to: t.target,
			hint: t.hint
		}), M(o, !1), {
			state: o,
			fx: [{
				kind: "hint",
				rid: n.by,
				data: {
					target: t.target,
					hint: t.hint,
					indices: a
				}
			}]
		};
	}
	let i = e.hands[n.by];
	if (t.index < 0 || t.index >= i.length) return { code: "games.hanabi.errBadIndex" };
	if (t.type === "discard") {
		if (e.clues >= 8) return { code: "games.hanabi.errCluesFull" };
		let r = structuredClone(e), [i] = r.hands[n.by].splice(t.index, 1);
		r.marks[n.by].splice(t.index, 1), r.discard.push(i), r.clues += 1, k(r, {
			k: "discard",
			rid: n.by,
			card: i
		});
		let a = [{
			kind: "discard",
			rid: n.by,
			data: { card: i }
		}];
		return M(r, j(r, n.by, a)), {
			state: r,
			fx: a
		};
	}
	let a = structuredClone(e), [o] = a.hands[n.by].splice(t.index, 1);
	a.marks[n.by].splice(t.index, 1);
	let s = (a.fireworks[o.color] ?? 0) + 1 === o.num, c = [];
	if (s) {
		a.fireworks[o.color] = o.num;
		let e = o.num === 5;
		if (e && a.clues < 8 && (a.clues += 1), k(a, {
			k: "play",
			rid: n.by,
			card: o,
			complete: e
		}), c.push({
			kind: "play",
			rid: n.by,
			data: {
				card: o,
				complete: e
			}
		}), E(a.variant).every((e) => a.fireworks[e] === 5)) return a.phase = "done", a.result = {
			score: A(a),
			reason: "perfect"
		}, {
			state: a,
			fx: c
		};
	} else if (a.discard.push(o), a.fuses += 1, k(a, {
		k: "bust",
		rid: n.by,
		card: o
	}), c.push({
		kind: "bust",
		rid: n.by,
		data: {
			card: o,
			fuses: a.fuses
		}
	}), a.fuses >= 3) return a.phase = "done", a.result = {
		score: 0,
		reason: "bust"
	}, {
		state: a,
		fx: c
	};
	return M(a, j(a, n.by, c)), {
		state: a,
		fx: c
	};
}
function ue(e, t) {
	let n = {};
	for (let r of e.players) r !== t && (n[r] = e.hands[r]);
	return {
		public: {
			variant: e.variant,
			fireworks: e.fireworks,
			clues: e.clues,
			fuses: e.fuses,
			deckCount: e.deck.length,
			discard: e.discard,
			turn: e.players[e.turn],
			lastRound: e.lastRound !== null,
			players: e.players.map((t) => ({
				rid: t,
				handCount: e.hands[t].length
			})),
			result: e.result,
			log: e.log
		},
		private: {
			others: n,
			myMarks: e.marks[t] ?? []
		}
	};
}
function de(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.result?.score ?? 0;
	return {
		phase: "done",
		winner: [...e.players],
		ranking: [...e.players],
		scores: Object.fromEntries(e.players.map((e) => [e, t]))
	};
}
var fe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: y,
	schemas: {
		action: te,
		publicView: ie,
		privateView: ae,
		config: w
	},
	setup: ce,
	reduce: le,
	viewFor: ue,
	status: de
}, N = {
	white: {
		bg: "#f8fafc",
		fg: "#334155"
	},
	yellow: {
		bg: "#fde047",
		fg: "#713f12"
	},
	red: {
		bg: "#ef4444",
		fg: "#ffffff"
	},
	blue: {
		bg: "#3b82f6",
		fg: "#ffffff"
	},
	green: {
		bg: "#22c55e",
		fg: "#ffffff"
	},
	rainbow: {
		bg: "linear-gradient(135deg,#ef4444,#fde047,#22c55e,#3b82f6,#a855f7)",
		fg: "#ffffff"
	}
}, P = {
	white: "games.hanabi.suit.white",
	yellow: "games.hanabi.suit.yellow",
	red: "games.hanabi.suit.red",
	blue: "games.hanabi.suit.blue",
	green: "games.hanabi.suit.green",
	rainbow: "games.hanabi.suit.rainbow"
};
function F({ card: e, size: t }) {
	let n = i(), r = N[e.color];
	return /* @__PURE__ */ d("span", {
		className: `hnb-card-face grid place-items-center border-2 border-ink shadow-[2px_2px_0_var(--color-ink)] ${t === "sm" ? "h-14 w-10 rounded" : "h-20 w-14 rounded"}`,
		style: { background: r.bg },
		children: /* @__PURE__ */ f("span", {
			className: "hnb-card-content flex flex-col items-center leading-none",
			style: { color: r.fg },
			children: [/* @__PURE__ */ d("span", {
				className: `hnb-card-number font-mono font-extrabold tabular-nums ${t === "sm" ? "text-lg" : "text-2xl"}`,
				children: e.num
			}), /* @__PURE__ */ d("span", {
				className: `hnb-card-suit ${t === "sm" ? "text-[8px]" : "text-[10px]"} font-bold`,
				children: n(P[e.color])
			})]
		})
	});
}
function I() {
	return /* @__PURE__ */ d("span", {
		className: "hnb-card-back grid h-20 w-14 place-items-center rounded border-2 border-ink bg-indigo-950 shadow-[2px_2px_0_var(--color-ink)]",
		children: /* @__PURE__ */ d("span", {
			"aria-hidden": !0,
			className: "hnb-card-symbol text-xl",
			children: "🎆"
		})
	});
}
//#endregion
//#region src/games/hanabi/view-player.tsx
function pe(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ d(he, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var me = {
	2: "hnb-players-2",
	3: "hnb-players-3",
	4: "hnb-players-4",
	5: "hnb-players-5"
};
function he({ pub: e, priv: t, members: r, myRid: a, send: o }) {
	let u = i(), [p, m] = n(null), h = (e) => r.find((t) => t.rid === e)?.name ?? e, g = e.turn === a && !e.result, _ = "info", v = u("games.hanabi.turnWait", { name: h(e.turn) });
	g && (_ = "accent", v = u("games.hanabi.turnYou"));
	let b = e.players.map((e) => e.rid).filter((e) => e !== a), x = (e) => u("games.hanabi.cardName", {
		suit: u(P[e.color]),
		num: e.num
	});
	return /* @__PURE__ */ f("div", {
		className: `hnb-view relative h-full min-h-0 ${me[e.players.length]}`,
		"data-hnb-private": t ? "yes" : "no",
		style: {
			"--hnb-team-count": b.length,
			"--hnb-hand-count": e.players.length <= 3 ? 5 : 4
		},
		children: [
			/* @__PURE__ */ d(s, {
				adaptive: !0,
				className: "hnb-screen",
				scroll: !1,
				banner: /* @__PURE__ */ f("div", {
					className: "hnb-banner",
					children: [/* @__PURE__ */ d(l, {
						tone: _,
						text: v,
						chip: e.lastRound ? u("games.hanabi.lastRound") : u("games.hanabi.deckLeft", { n: e.deckCount }),
						accent: y.accent
					}), /* @__PURE__ */ d(c, {
						log: e.log,
						line: (e) => {
							if (e.k === "hint") {
								let t = e.hint.kind === "color" ? u(P[e.hint.color]) : String(e.hint.num);
								return u("games.hanabi.logHint", {
									from: h(e.from),
									to: h(e.to),
									what: t
								});
							}
							return e.k === "play" ? u(e.complete ? "games.hanabi.logPlayComplete" : "games.hanabi.logPlay", {
								name: h(e.rid),
								card: x(e.card)
							}) : e.k === "bust" ? u("games.hanabi.logBust", {
								name: h(e.rid),
								card: x(e.card)
							}) : u("games.hanabi.logDiscard", {
								name: h(e.rid),
								card: x(e.card)
							});
						}
					})]
				}),
				actionsHeight: t ? "hnb-action-height" : void 0,
				actions: t && /* @__PURE__ */ f("div", {
					className: "hnb-self safe-b flex flex-none flex-col gap-1 pb-1",
					children: [/* @__PURE__ */ d("p", {
						className: "hnb-self-label section-label",
						children: u("games.hanabi.myHand")
					}), /* @__PURE__ */ d(Se, {
						myRid: a,
						marks: t.myMarks,
						onPick: (e) => m({
							kind: "slot",
							index: e
						})
					})]
				}),
				children: /* @__PURE__ */ f("div", {
					className: "hnb-main flex h-full min-h-0 flex-col gap-2 overflow-y-auto",
					children: [/* @__PURE__ */ d("div", {
						className: "hnb-teammates",
						children: b.map((n) => /* @__PURE__ */ d(ge, {
							rid: n,
							cards: t?.others[n] ?? [],
							member: r.find((e) => e.rid === n),
							isTurn: e.turn === n,
							canClue: g && e.clues > 0,
							onHint: () => m({
								kind: "hint",
								target: n
							})
						}, n))
					}), /* @__PURE__ */ d(ve, {
						pub: e,
						onOpenDiscard: () => m({ kind: "discard" })
					})]
				})
			}),
			p?.kind === "slot" && t && /* @__PURE__ */ d(we, {
				mark: t.myMarks[p.index],
				index: p.index,
				myTurn: g,
				cluesFull: e.clues >= 8,
				onPlay: () => {
					o({
						type: "play",
						index: p.index
					}), m(null);
				},
				onDiscard: () => {
					o({
						type: "discard",
						index: p.index
					}), m(null);
				},
				onClose: () => m(null)
			}),
			p?.kind === "hint" && t && /* @__PURE__ */ d(Te, {
				target: p.target,
				targetName: h(p.target),
				cards: t.others[p.target] ?? [],
				variant: e.variant,
				onPick: (e) => {
					o({
						type: "hint",
						target: p.target,
						hint: e
					}), m(null);
				},
				onClose: () => m(null)
			}),
			p?.kind === "discard" && /* @__PURE__ */ d(Ee, {
				discard: e.discard,
				onClose: () => m(null)
			})
		]
	});
}
function ge({ rid: e, cards: t, member: n, isTurn: s, canClue: c, onHint: l }) {
	let u = i(), { ref: p } = r(`hand:${e}`), m = o[(n?.colorIndex ?? 0) % o.length];
	return /* @__PURE__ */ f("div", {
		ref: p,
		className: "hnb-teammate frame flex flex-col gap-1.5 p-2",
		style: s ? { borderColor: y.accent } : void 0,
		children: [/* @__PURE__ */ f("div", {
			className: "hnb-seat flex items-center gap-2",
			children: [
				n && /* @__PURE__ */ d("img", {
					src: a[n.avatar % a.length],
					alt: "",
					draggable: !1,
					className: "hnb-avatar size-6 rounded-full border-2 border-ink object-contain",
					style: { backgroundColor: m.hex }
				}),
				/* @__PURE__ */ d("span", {
					className: "hnb-name min-w-0 flex-1 truncate text-sm font-bold",
					children: n?.name ?? e
				}),
				/* @__PURE__ */ d("button", {
					type: "button",
					className: "hnb-hint btn-quiet min-h-11 cursor-pointer px-3 text-sm disabled:opacity-40",
					disabled: !c,
					onClick: l,
					children: u("games.hanabi.hintBtn")
				})
			]
		}), /* @__PURE__ */ d("div", {
			className: "hnb-tm-cards flex gap-1.5",
			children: t.map((t, n) => /* @__PURE__ */ d(_e, {
				rid: e,
				index: n,
				card: t
			}, t.id))
		})]
	});
}
function _e({ rid: e, index: t, card: n }) {
	let { ref: i, hidden: a } = r(`tmCard:${e}:${t}`);
	return /* @__PURE__ */ d("span", {
		ref: i,
		className: "hnb-tm-card inline-flex",
		style: { visibility: a ? "hidden" : void 0 },
		children: /* @__PURE__ */ d(F, {
			card: n,
			size: "sm"
		})
	});
}
function ve({ pub: e, onOpenDiscard: t }) {
	let n = i(), r = E(e.variant);
	return /* @__PURE__ */ f("div", {
		className: "hnb-center frame flex flex-col gap-2 p-2",
		children: [/* @__PURE__ */ d("div", {
			className: "hnb-fireworks flex justify-around",
			children: r.map((t) => /* @__PURE__ */ d(ye, {
				suit: t,
				height: e.fireworks[t] ?? 0
			}, t))
		}), /* @__PURE__ */ f("div", {
			className: "hnb-supplies flex items-center justify-between gap-2 border-t-2 border-ink/10 pt-2 text-xs font-bold",
			children: [
				/* @__PURE__ */ d(L, {
					anchor: "clues",
					label: n("games.hanabi.clueTokens"),
					total: 8,
					left: e.clues,
					tone: "clue"
				}),
				/* @__PURE__ */ d(be, { count: e.deckCount }),
				/* @__PURE__ */ d(L, {
					anchor: "fuses",
					label: n("games.hanabi.fuseTokens"),
					total: 3,
					left: 3 - e.fuses,
					tone: "fuse"
				}),
				/* @__PURE__ */ d(xe, {
					count: e.discard.length,
					onOpen: t
				})
			]
		})]
	});
}
function ye({ suit: e, height: t }) {
	let n = i(), { ref: a } = r(`firework:${e}`), o = N[e];
	return /* @__PURE__ */ f("div", {
		ref: a,
		className: "hnb-firework flex flex-col items-center gap-0.5",
		children: [/* @__PURE__ */ d("div", {
			className: `hnb-firework-box grid h-16 w-11 place-items-center rounded-lg border-2 ${t > 0 ? "border-ink" : "border-dashed border-ink/40"}`,
			style: t > 0 ? { background: o.bg } : void 0,
			children: t > 0 && /* @__PURE__ */ d("span", {
				className: "hnb-firework-number font-mono text-xl font-extrabold tabular-nums",
				style: { color: o.fg },
				children: t
			})
		}), /* @__PURE__ */ d("span", {
			className: "hnb-firework-label text-[10px] font-bold",
			children: n(P[e])
		})]
	});
}
function L({ anchor: e, label: t, total: n, left: i, tone: a }) {
	let { ref: o } = r(e);
	return /* @__PURE__ */ f("span", {
		ref: o,
		className: "hnb-token flex flex-col items-center gap-0.5",
		"aria-label": `${t} ${i}/${n}`,
		children: [/* @__PURE__ */ d("span", {
			className: "hnb-token-dots flex gap-0.5",
			children: Array.from({ length: n }, (e, t) => /* @__PURE__ */ d("span", {
				"aria-hidden": !0,
				className: `hnb-token-dot grid size-2.5 place-items-center rounded-full border ${t < i ? a === "clue" ? "border-sky-600 bg-sky-400" : "border-ink bg-ink" : "border-ink/30 bg-transparent"}`
			}, t))
		}), /* @__PURE__ */ f("span", {
			className: "hnb-token-label text-[10px] opacity-70",
			children: [a === "fuse" ? "💥" : "", t]
		})]
	});
}
function be({ count: e }) {
	let t = i(), { ref: n } = r("deck");
	return /* @__PURE__ */ f("span", {
		ref: n,
		className: "hnb-deck flex flex-col items-center gap-0.5",
		children: [/* @__PURE__ */ d("span", {
			className: "hnb-deck-back grid h-8 w-6 place-items-center rounded border-2 border-ink bg-indigo-950 text-[10px] text-white",
			children: "🎆"
		}), /* @__PURE__ */ d("span", {
			className: "hnb-deck-label font-mono text-[10px] tabular-nums opacity-70",
			children: t("games.hanabi.deckLeft", { n: e })
		})]
	});
}
function xe({ count: e, onOpen: t }) {
	let n = i(), { ref: a } = r("discardPile");
	return /* @__PURE__ */ d("button", {
		ref: a,
		type: "button",
		onClick: t,
		className: "hnb-discard btn-quiet min-h-11 cursor-pointer px-2 text-[11px]",
		children: n("games.hanabi.discardPile", { n: e })
	});
}
function Se({ myRid: e, marks: t, onPick: n }) {
	let a = i(), { ref: o } = r(`hand:${e}`);
	return /* @__PURE__ */ d("div", {
		ref: o,
		className: "hnb-my-strip overflow-x-auto",
		children: /* @__PURE__ */ d("div", {
			className: "hnb-my-cards mx-auto flex w-max items-start gap-2 px-2",
			children: t.map((e, t) => /* @__PURE__ */ d(Ce, {
				index: t,
				mark: e,
				aria: a("games.hanabi.slotAria", { n: t + 1 }),
				onPick: () => n(t)
			}, t))
		})
	});
}
function Ce({ index: e, mark: t, aria: n, onPick: i }) {
	let { ref: a, hidden: o } = r(`myCard:${e}`);
	return /* @__PURE__ */ f("button", {
		ref: a,
		type: "button",
		"aria-label": n,
		onClick: i,
		className: "hnb-my-slot flex flex-none cursor-pointer flex-col items-center gap-1",
		style: { visibility: o ? "hidden" : void 0 },
		children: [
			/* @__PURE__ */ d(I, {}),
			/* @__PURE__ */ d("span", {
				className: "hnb-marks-colors flex h-3 items-center gap-0.5",
				children: t.pos.map((e) => /* @__PURE__ */ d("span", {
					"aria-hidden": !0,
					className: "hnb-mark-color size-2.5 rounded-full border border-ink",
					style: { background: N[e].bg }
				}, e))
			}),
			/* @__PURE__ */ d("span", {
				className: "hnb-marks-numbers flex h-4 items-center gap-0.5",
				children: t.posN.map((e) => /* @__PURE__ */ d("span", {
					className: "hnb-mark-number grid size-4 place-items-center rounded border border-ink bg-surface font-mono text-[10px] font-bold tabular-nums",
					children: e
				}, e))
			})
		]
	});
}
function R({ children: e, onClose: t }) {
	return /* @__PURE__ */ d("div", {
		className: "hnb-sheet absolute inset-0 z-20 flex items-end justify-center bg-ink/40 p-3",
		onClick: t,
		children: /* @__PURE__ */ d("div", {
			className: "hnb-sheet-body card w-full max-w-sm p-3",
			onClick: (e) => e.stopPropagation(),
			children: e
		})
	});
}
function z({ label: e, colors: t, nums: n, dim: r }) {
	let a = i();
	return /* @__PURE__ */ f("span", {
		className: `hnb-mark-chips flex items-center gap-1 ${r ? "opacity-50" : ""}`,
		children: [
			/* @__PURE__ */ d("span", {
				className: "text-xs font-bold",
				children: e
			}),
			t.map((e) => /* @__PURE__ */ d("span", {
				className: "grid size-5 place-items-center rounded border border-ink text-[9px] font-bold",
				style: {
					background: N[e].bg,
					color: N[e].fg
				},
				children: a(P[e])
			}, e)),
			n.map((e) => /* @__PURE__ */ d("span", {
				className: "grid size-5 place-items-center rounded border border-ink bg-surface font-mono text-xs font-bold tabular-nums",
				children: e
			}, e))
		]
	});
}
function we({ mark: e, index: t, myTurn: n, cluesFull: r, onPlay: a, onDiscard: o, onClose: s }) {
	let c = i(), l = e.pos.length === 0 && e.posN.length === 0 && e.neg.length === 0 && e.negN.length === 0;
	return /* @__PURE__ */ f(R, {
		onClose: s,
		children: [
			/* @__PURE__ */ d("p", {
				className: "text-sm font-extrabold",
				children: c("games.hanabi.slotAria", { n: t + 1 })
			}),
			/* @__PURE__ */ d("div", {
				className: "mt-2 flex flex-col gap-1.5",
				children: l ? /* @__PURE__ */ d("p", {
					className: "text-xs opacity-70",
					children: c("games.hanabi.marksNone")
				}) : /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(z, {
					label: c("games.hanabi.marksKnown"),
					colors: e.pos,
					nums: e.posN
				}), /* @__PURE__ */ d(z, {
					label: c("games.hanabi.marksExcluded"),
					colors: e.neg,
					nums: e.negN,
					dim: !0
				})] })
			}),
			n && /* @__PURE__ */ f("div", {
				className: "hnb-slot-actions mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ d("button", {
					type: "button",
					className: "btn-base min-h-12 cursor-pointer text-white",
					style: { background: y.accent },
					onClick: a,
					children: c("games.hanabi.play")
				}), /* @__PURE__ */ d("button", {
					type: "button",
					className: "btn-base min-h-12 cursor-pointer text-white disabled:opacity-40",
					style: { background: "var(--color-danger)" },
					disabled: r,
					onClick: o,
					children: c("games.hanabi.discardAction")
				})]
			})
		]
	});
}
function Te({ target: e, targetName: t, cards: n, variant: r, onPick: a, onClose: o }) {
	let s = i(), c = E(r).filter((e) => r !== "rainbowWild" || e !== "rainbow"), l = (e) => n.filter((t) => t.color === e || r === "rainbowWild" && t.color === "rainbow").length, u = (e) => n.filter((t) => t.num === e).length;
	return /* @__PURE__ */ f(R, {
		onClose: o,
		children: [
			/* @__PURE__ */ d("p", {
				className: "text-sm font-extrabold",
				children: s("games.hanabi.hintMode", { name: t })
			}),
			/* @__PURE__ */ d("div", {
				className: "hnb-hint-options mt-2 flex flex-wrap gap-1.5",
				children: c.map((e) => /* @__PURE__ */ d("button", {
					type: "button",
					disabled: l(e) === 0,
					onClick: () => a({
						kind: "color",
						color: e
					}),
					className: "grid min-h-11 min-w-11 cursor-pointer place-items-center rounded-lg border-2 border-ink text-xs font-bold disabled:opacity-30",
					style: {
						background: N[e].bg,
						color: N[e].fg
					},
					children: s(P[e])
				}, e))
			}),
			/* @__PURE__ */ d("div", {
				className: "hnb-hint-options mt-2 flex flex-wrap gap-1.5",
				children: [
					1,
					2,
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ d("button", {
					type: "button",
					disabled: u(e) === 0,
					onClick: () => a({
						kind: "number",
						num: e
					}),
					className: "grid min-h-11 min-w-11 cursor-pointer place-items-center rounded-lg border-2 border-ink bg-surface font-mono text-base font-extrabold tabular-nums disabled:opacity-30",
					children: e
				}, e))
			}),
			/* @__PURE__ */ d("button", {
				type: "button",
				className: "btn-quiet mt-3 w-full cursor-pointer",
				onClick: o,
				children: s("games.hanabi.hintCancel")
			})
		]
	});
}
function Ee({ discard: e, onClose: t }) {
	let n = i();
	return /* @__PURE__ */ f(R, {
		onClose: t,
		children: [/* @__PURE__ */ d("p", {
			className: "text-sm font-extrabold",
			children: n("games.hanabi.discardTitle")
		}), e.length === 0 ? /* @__PURE__ */ d("p", {
			className: "mt-2 text-xs opacity-70",
			children: n("games.hanabi.discardEmpty")
		}) : /* @__PURE__ */ d("div", {
			className: "hnb-discard-cards mt-2 flex max-h-64 flex-wrap gap-1.5 overflow-y-auto",
			children: e.map((e) => /* @__PURE__ */ d(F, {
				card: e,
				size: "sm"
			}, e.id))
		})]
	});
}
//#endregion
//#region src/games/hanabi/bot.ts
var De = {
	white: "games.hanabi.suit.white",
	yellow: "games.hanabi.suit.yellow",
	red: "games.hanabi.suit.red",
	blue: "games.hanabi.suit.blue",
	green: "games.hanabi.suit.green",
	rainbow: "games.hanabi.suit.rainbow"
}, B = [
	1,
	2,
	3,
	4,
	5
], V = {
	1: 3,
	2: 2,
	3: 2,
	4: 2,
	5: 1
}, H = (e, t) => `${e}:${t}`, U = (e, t) => (e.fireworks[t.color] ?? 0) + 1 === t.num;
function W(e, t) {
	let n = E(e.variant), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
	for (let e of n) for (let t of B) r.set(H(e, t), V[t]), i.set(H(e, t), V[t]);
	let a = (e, t) => {
		let n = H(t.color, t.num);
		e.set(n, (e.get(n) ?? 0) - 1);
	};
	for (let t of n) for (let n = 1; n <= (e.fireworks[t] ?? 0); n += 1) a(r, {
		color: t,
		num: n
	}), a(i, {
		color: t,
		num: n
	});
	for (let t of e.discard) a(r, t), a(i, t);
	for (let e of Object.values(t.others)) for (let t of e) a(i, t);
	let o = /* @__PURE__ */ new Map();
	for (let t of n) {
		let n = 5;
		for (let i = (e.fireworks[t] ?? 0) + 1; i <= 5; i += 1) if ((r.get(H(t, i)) ?? 0) === 0) {
			n = i - 1;
			break;
		}
		o.set(t, n);
	}
	return {
		suits: n,
		left: r,
		unseen: i,
		cap: o
	};
}
var G = (e, t, n) => n.num <= (e.fireworks[n.color] ?? 0) || n.num > (t.cap.get(n.color) ?? 5), Oe = (e, t, n) => !G(e, t, n) && (t.left.get(H(n.color, n.num)) ?? 0) === 1;
function ke(e, t, n) {
	let r = e === "rainbowWild" && n.color === "rainbow";
	return !((r ? t.neg.length > 0 : t.neg.includes(n.color)) || !r && t.pos.length > 0 && !t.pos.includes(n.color) || t.negN.includes(n.num) || t.posN.length > 0 && !t.posN.includes(n.num));
}
function K(e, t, n) {
	let r = [];
	for (let i of t.suits) for (let a of B) {
		let o = t.unseen.get(H(i, a)) ?? 0;
		o > 0 && ke(e.variant, n, {
			color: i,
			num: a
		}) && r.push({
			color: i,
			num: a,
			w: o
		});
	}
	return r;
}
function Ae(e) {
	let t = e.map((e) => e.map((e) => ({ ...e }))), n = !0;
	for (; n;) {
		n = !1;
		let e = /* @__PURE__ */ new Map();
		for (let n of t) if (n.length === 1) {
			let t = H(n[0].color, n[0].num);
			e.set(t, (e.get(t) ?? 0) + 1);
		}
		for (let r of t) if (!(r.length <= 1)) for (let t = r.length - 1; t >= 0; --t) {
			let i = r[t], a = e.get(H(i.color, i.num)) ?? 0;
			a !== 0 && (i.w <= a ? (r.splice(t, 1), n = !0) : i.w -= a);
		}
	}
	return t;
}
var q = (e, t, n) => t.kind === "color" ? n.color === t.color || e === "rainbowWild" && n.color === "rainbow" : n.num === t.num;
function je(e, t, n) {
	let r = [];
	for (let i of t.suits) (e.variant !== "rainbowWild" || i !== "rainbow") && n.some((t) => q(e.variant, {
		kind: "color",
		color: i
	}, t)) && r.push({
		kind: "color",
		color: i
	});
	for (let e of B) n.some((t) => t.num === e) && r.push({
		kind: "number",
		num: e
	});
	return r;
}
function Me(e, t, n, r) {
	for (let i of t.suits) for (let a of B) {
		let o = {
			color: i,
			num: a
		};
		if (!q(e.variant, n, o)) continue;
		let s = r.filter((e) => e.color === i && e.num === a).length;
		if ((t.unseen.get(H(i, a)) ?? 0) + s > 0 && !U(e, o)) return !1;
	}
	return !0;
}
function Ne(e, t, n) {
	return e.log.some((r) => r.k === "hint" && r.to === t && q(e.variant, r.hint, n));
}
function Pe(e) {
	let t = /* @__PURE__ */ new Map();
	e.log.forEach((e, n) => {
		e.k !== "hint" && t.set(e.rid, n);
	});
	let n = /* @__PURE__ */ new Map();
	return e.log.forEach((e, r) => {
		if (e.k === "hint" && r > (t.get(e.to) ?? -1)) {
			let t = n.get(e.to) ?? [];
			t.push(e.hint), n.set(e.to, t);
		}
	}), n;
}
function Fe(e, t, n, r, i) {
	for (let a of t.suits) for (let o of B) {
		let s = {
			color: a,
			num: o
		};
		if (!q(e.variant, n, s) || !q(e.variant, r, s)) continue;
		let c = i.filter((e) => e.color === a && e.num === o).length;
		if ((t.unseen.get(H(a, o)) ?? 0) + c > 0 && !U(e, s)) return !1;
	}
	return !0;
}
function Ie(e, t, n) {
	if (G(e, t, n)) return 0;
	let r = t.left.get(H(n.color, n.num)) ?? 0;
	return (r === 1 ? 6 : r === 2 ? 2 : 1) * (U(e, n) ? 4 : 1);
}
function J(e, t, n, r) {
	let i = -1, a = 99;
	for (let o = 0; o < n.length; o++) {
		let s = n[o];
		if (s.length === 0 || s.some((n) => !U(e, n) && !G(e, t, n) && (t.left.get(H(n.color, n.num)) ?? 0) <= 1)) continue;
		let c = s.reduce((e, t) => e + t.w, 0), l = s.filter((t) => U(e, t)).reduce((e, t) => e + t.w, 0);
		if (l === 0 || l / c < r) continue;
		let u = Math.min(...s.filter((t) => U(e, t)).map((e) => e.num));
		u < a && (a = u, i = o);
	}
	return i;
}
function Le(e, t, n) {
	let r = W(e, t), i = Ae(t.myMarks.map((t) => K(e, r, t))), a = J(e, r, i, 1);
	if (a >= 0) return {
		type: "play",
		index: a
	};
	let o = e.players.map((e) => e.rid), s = Math.max(0, o.indexOf(n)), c = (e) => (o.indexOf(e) - s + o.length) % o.length, l = Pe(e), u = [], d = [], f = null;
	for (let [n, i] of Object.entries(t.others)) {
		if (i.length === 0) continue;
		let t = l.get(n) ?? [];
		for (let a of je(e, r, i)) {
			let o = i.filter((t) => q(e.variant, a, t)), s = o.some((e) => e.num === 5) ? 5 : 0;
			if (Me(e, r, a, i)) {
				u.push({
					target: n,
					hint: a,
					score: o.length * 10 + s - c(n),
					touches: o.length
				});
				continue;
			}
			let l = t.length === 0 ? [] : o.filter((n) => U(e, n) && t.some((t) => q(e.variant, t, n) && Fe(e, r, t, a, i)));
			if (l.length > 0) {
				u.push({
					target: n,
					hint: a,
					score: l.length * 10 + s - c(n),
					touches: o.length
				});
				continue;
			}
			let p = i.filter((t, i) => q(e.variant, a, t) && Oe(e, r, t) && (i <= 1 || t.num === 5) && !Ne(e, n, t));
			p.length > 0 && d.push({
				target: n,
				hint: a,
				score: p.length * 100 - o.length - c(n),
				touches: o.length
			});
			let m = o.filter((t) => U(e, t)).length * 10 + o.length;
			(!f || m > f.score) && (f = {
				target: n,
				hint: a,
				score: m,
				touches: o.length
			});
		}
	}
	if (d.sort((e, t) => t.score - e.score), e.clues > 0 && u.length > 0) return u.sort((e, t) => t.score - e.score), {
		type: "hint",
		target: u[0].target,
		hint: u[0].hint
	};
	if (e.fuses <= 1) {
		let t = J(e, r, i, .4);
		if (t >= 0) return {
			type: "play",
			index: t
		};
	}
	if (e.clues >= 6 && f && f.score >= 10) return {
		type: "hint",
		target: f.target,
		hint: f.hint
	};
	if (e.lastRound && e.fuses <= 1) {
		let t = 0, n = -1;
		for (let r = 0; r < i.length; r++) {
			let a = i[r].reduce((e, t) => e + t.w, 0);
			if (a === 0) continue;
			let o = i[r].filter((t) => U(e, t)).reduce((e, t) => e + t.w, 0) / a;
			o > t && (t = o, n = r);
		}
		if (n >= 0 && t >= .5) return {
			type: "play",
			index: n
		};
	}
	if (e.clues >= 3 && d.length > 0) return {
		type: "hint",
		target: d[0].target,
		hint: d[0].hint
	};
	if (e.clues < 8) {
		for (let t = 0; t < i.length; t++) {
			let n = i[t];
			if (n.length > 0 && n.every((t) => G(e, r, t))) return {
				type: "discard",
				index: t
			};
		}
		let n = t.myMarks.map((e) => e.pos.length > 0 || e.posN.length > 0), a = i.map((e, t) => t).filter((e) => !n[e]), o = a.length > 0 ? a : i.map((e, t) => t), s = o[0], c = Infinity;
		for (let t of o) {
			let n = i[t], a = n.reduce((e, t) => e + t.w, 0), o = a === 0 ? 1 : n.reduce((t, n) => t + n.w / a * Ie(e, r, n), 0);
			o < c && (c = o, s = t);
		}
		return {
			type: "discard",
			index: s
		};
	}
	let p = d[0] ?? f;
	return p ? {
		type: "hint",
		target: p.target,
		hint: p.hint
	} : {
		type: "play",
		index: 0
	};
}
function Re(e, t) {
	let n = W(e, t), r = t.myMarks.map((t) => K(e, n, t));
	for (let t = 0; t < r.length; t++) {
		let n = r[t];
		if (n.length === 1 && U(e, n[0])) return {
			type: "play",
			index: t
		};
	}
	if (e.clues < 8) {
		for (let t = 0; t < r.length; t++) {
			let i = r[t];
			if (i.length > 0 && i.every((t) => G(e, n, t))) return {
				type: "discard",
				index: t
			};
		}
		let i = -1;
		for (let e = 0; e < t.myMarks.length; e++) {
			let n = t.myMarks[e];
			i < 0 && n.pos.length === 0 && n.posN.length === 0 && (i = e);
		}
		return {
			type: "discard",
			index: i >= 0 ? i : 0
		};
	}
	for (let [n, r] of Object.entries(t.others)) {
		let t = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
		for (let n of r) i.set(n.num, (i.get(n.num) ?? 0) + 1), (e.variant !== "rainbowWild" || n.color !== "rainbow") && t.set(n.color, (t.get(n.color) ?? 0) + 1);
		let a = [...t.entries()].sort((e, t) => t[1] - e[1])[0];
		if (a) return {
			type: "hint",
			target: n,
			hint: {
				kind: "color",
				color: a[0]
			}
		};
		let o = [...i.entries()].sort((e, t) => t[1] - e[1])[0];
		if (o) return {
			type: "hint",
			target: n,
			hint: {
				kind: "number",
				num: o[0]
			}
		};
	}
	return {
		type: "play",
		index: 0
	};
}
var ze = (e, t) => {
	let n = e.public, r = e.private;
	return !r || n.result || n.turn !== t.rid ? null : { action: t.difficulty === "weak" ? Re(n, r) : Le(n, r, t.rid) };
}, Be = (e, t, n) => e.type === "play" ? n("games.hanabi.dPlay", { n: e.index + 1 }) : e.type === "discard" ? n("games.hanabi.dDiscard", { n: e.index + 1 }) : n("games.hanabi.dHint", { what: e.hint.kind === "color" ? n(De[e.hint.color]) : String(e.hint.num) }), Y = 40, Ve = 56;
function X(e, t = Y, n = Ve) {
	return {
		x: e.x + e.w / 2 - t / 2,
		y: e.y + e.h / 2 - n / 2,
		w: t,
		h: n
	};
}
function He(e) {
	return {
		...e,
		h: Math.min(e.h, e.w * 80 / 56)
	};
}
function Ue(e) {
	let t = e.w >= 84, n = t ? Math.max(0, e.h - 28) : Math.min(64, e.h), r = Math.min(t ? e.w : 44, n * 5 / 7);
	return {
		x: e.x + (e.w - r) / 2,
		y: e.y + (n - r * 1.4) / 2,
		w: r,
		h: r * 1.4
	};
}
function Z(e, t) {
	let n = (t ? e.anchor(`hand:${t}`) : null) ?? e.anchor("deck");
	if (!n) return null;
	let r = t ? e.anchor(t === e.myRid ? "myCard:0" : `tmCard:${t}:0`) : null, i = r && r.w > 0 ? r.w : Y;
	return X(n, i, i * 1.4);
}
function Q({ card: e, width: t, nativeWidth: n }) {
	let r = e ? 1.4 : 80 / 56, i = Math.max(1, n);
	return /* @__PURE__ */ d("span", {
		className: "relative block",
		style: {
			width: t,
			height: t * r
		},
		children: /* @__PURE__ */ d("span", {
			className: "hnb-fx-target absolute top-0 left-0",
			"data-hnb-large": i >= 100 ? "true" : void 0,
			style: {
				"--hnb-fx-native-w": i + "px",
				width: i,
				height: i * r,
				transform: `scale(${t / i})`,
				transformOrigin: "top left"
			},
			children: e ? /* @__PURE__ */ d(F, {
				card: e,
				size: "sm"
			}) : /* @__PURE__ */ d(I, {})
		})
	});
}
var We = {
	deal(e, t) {
		let n = t.anchor("deck");
		if (!n || !e.rid) return null;
		let r = e.secret;
		if (r && Array.isArray(r.cards)) {
			let i = [], a = [];
			for (let [o, s] of r.cards.entries()) {
				let r = t.anchor(`tmCard:${e.rid}:${o}`);
				r && (a.push(`tmCard:${e.rid}:${o}`), i.push(/* @__PURE__ */ d(m, {
					from: X(n),
					to: r,
					ms: 320,
					delay: o * 45,
					children: /* @__PURE__ */ d(Q, {
						card: s,
						width: Y,
						nativeWidth: r.w
					})
				}, s.id)));
			}
			return i.length ? {
				ms: 320 + i.length * 45,
				node: i,
				hide: a
			} : null;
		}
		let i = e.data?.count, a = typeof i == "number" ? i : 4, o = [], s = [];
		for (let e = 0; e < a; e += 1) {
			let r = t.anchor(`myCard:${e}`);
			if (!r) continue;
			let i = He(r);
			s.push(`myCard:${e}`), o.push(/* @__PURE__ */ d(m, {
				from: X(n, 56, 80),
				to: i,
				ms: 320,
				delay: e * 45,
				children: /* @__PURE__ */ d(Q, {
					width: 56,
					nativeWidth: i.w
				})
			}, e));
		}
		return o.length ? {
			ms: 320 + o.length * 45,
			node: o,
			hide: s
		} : null;
	},
	draw(e, t) {
		let n = t.anchor("deck");
		if (!n || !e.rid) return null;
		let r = e.data, i = typeof r?.index == "number" ? r.index : 0, a = e.secret;
		if (a?.card) {
			let r = t.anchor(`tmCard:${e.rid}:${i}`);
			return r ? {
				ms: 350,
				node: /* @__PURE__ */ d(m, {
					from: X(n),
					to: r,
					ms: 350,
					children: /* @__PURE__ */ d(Q, {
						card: a.card,
						width: Y,
						nativeWidth: r.w
					})
				}),
				hide: [`tmCard:${e.rid}:${i}`]
			} : null;
		}
		let o = t.anchor(`myCard:${i}`);
		if (!o) return null;
		let s = He(o);
		return {
			ms: 350,
			node: /* @__PURE__ */ d(m, {
				from: X(n, 56, 80),
				to: s,
				ms: 350,
				children: /* @__PURE__ */ d(Q, {
					width: 56,
					nativeWidth: s.w
				})
			}),
			hide: [`myCard:${i}`]
		};
	},
	play(e, t) {
		let n = e.data;
		if (!n?.card) return null;
		let r = Z(t, e.rid), i = t.anchor(`firework:${n.card.color}`);
		if (!r || !i) return null;
		let a = Ue(i), o = n.complete === !0;
		return {
			ms: o ? 800 : 450,
			node: /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(m, {
				from: r,
				to: a,
				ms: 400,
				children: /* @__PURE__ */ d(Q, {
					card: n.card,
					width: r.w,
					nativeWidth: a.w
				})
			}), o && /* @__PURE__ */ d(p, {
				at: a,
				ms: 700,
				delay: 380,
				children: /* @__PURE__ */ d("span", {
					className: "text-sm font-extrabold",
					style: { fontSize: Math.max(14, Math.min(36, a.w * .16)) },
					children: "+1 💡"
				})
			})] })
		};
	},
	bust(e, t) {
		let n = e.data;
		if (!n?.card) return null;
		let r = Z(t, e.rid), i = t.anchor("discardPile"), a = t.anchor("fuses");
		return !r || !i ? null : {
			ms: 700,
			node: /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(m, {
				from: r,
				to: X(i),
				ms: 350,
				children: /* @__PURE__ */ d(Q, {
					card: n.card,
					width: r.w,
					nativeWidth: r.w
				})
			}), a && /* @__PURE__ */ d(h, {
				at: a,
				ms: 700,
				delay: 320
			})] })
		};
	},
	discard(e, t) {
		let n = e.data;
		if (!n?.card) return null;
		let r = Z(t, e.rid), i = t.anchor("discardPile");
		return !r || !i ? null : {
			ms: 400,
			node: /* @__PURE__ */ d(m, {
				from: r,
				to: X(i),
				ms: 350,
				children: /* @__PURE__ */ d(Q, {
					card: n.card,
					width: r.w,
					nativeWidth: r.w
				})
			})
		};
	},
	hint(e, t) {
		let n = e.data;
		if (typeof n?.target != "string" || !Array.isArray(n.indices)) return null;
		let r = n.target === t.myRid, i = [];
		for (let e of n.indices) {
			if (typeof e != "number") continue;
			let a = t.anchor(r ? `myCard:${e}` : `tmCard:${n.target}:${e}`);
			a && i.push(/* @__PURE__ */ d(h, {
				at: a,
				ms: 900
			}, e));
		}
		return i.length ? {
			ms: 900,
			node: i
		} : null;
	}
}, $ = [
	{
		min: 25,
		key: "rateLegendary"
	},
	{
		min: 21,
		key: "rateAmazing"
	},
	{
		min: 16,
		key: "rateExcellent"
	},
	{
		min: 11,
		key: "rateHonorable"
	},
	{
		min: 6,
		key: "rateMediocre"
	},
	{
		min: 0,
		key: "rateHorrible"
	}
], Ge = {
	rateHorrible: "games.hanabi.rateHorrible",
	rateMediocre: "games.hanabi.rateMediocre",
	rateHonorable: "games.hanabi.rateHonorable",
	rateExcellent: "games.hanabi.rateExcellent",
	rateAmazing: "games.hanabi.rateAmazing",
	rateLegendary: "games.hanabi.rateLegendary"
};
function Ke({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: c }) {
	let l = i(), u = t, p = e.scores?.[e.ranking[0]], m = p ?? 0, h = E(u.variant), _ = h.length * 5, v = p !== void 0 && u.result?.score === m ? u.result.reason : "score", b = v === "perfect" && m !== _ ? "score" : v, x = $.find((e) => m >= e.min) ?? $[$.length - 1], S = (e) => n.find((t) => t.rid === e)?.name ?? e, C = r ?? c;
	return /* @__PURE__ */ f("div", {
		className: "hnb-over relative h-full min-h-0",
		style: {
			"--hnb-over-count": h.length,
			"--hnb-over-players": Math.max(1, e.ranking.length)
		},
		children: [b === "perfect" && /* @__PURE__ */ d(g, {}), /* @__PURE__ */ d(s, {
			adaptive: !0,
			scroll: !1,
			className: "hnb-over-screen",
			banner: /* @__PURE__ */ f("header", {
				className: "hnb-over-heading flex flex-none flex-col items-center gap-3",
				children: [
					/* @__PURE__ */ f("div", {
						className: "hnb-over-title-group flex flex-col items-center gap-3",
						children: [/* @__PURE__ */ d("span", {
							"aria-hidden": !0,
							className: "hnb-over-symbol mt-6 text-5xl",
							children: b === "bust" ? "💥" : b === "perfect" ? "🎆" : "🎇"
						}), /* @__PURE__ */ d("h1", {
							className: "hnb-over-title text-center font-display text-2xl font-extrabold",
							children: l(b === "bust" ? "games.hanabi.overBust" : b === "perfect" ? "games.hanabi.overPerfect" : "games.hanabi.overScore")
						})]
					}),
					/* @__PURE__ */ d("p", {
						className: "hnb-over-score font-mono text-lg font-extrabold tabular-nums",
						children: l("games.hanabi.overScoreLine", {
							score: m,
							max: _
						})
					}),
					/* @__PURE__ */ d("p", {
						className: "hnb-over-rate text-center text-sm font-bold opacity-70",
						children: l(Ge[x.key])
					})
				]
			}),
			actionsHeight: "hnb-over-action-height",
			actions: C ? /* @__PURE__ */ f("div", {
				className: "hnb-over-actions safe-b flex h-full flex-col justify-center gap-2 pb-1",
				children: [r && /* @__PURE__ */ d("button", {
					type: "button",
					className: "btn-base w-full cursor-pointer text-white",
					style: { background: y.accent },
					onClick: r,
					children: l("session.result.playAgain")
				}), c && /* @__PURE__ */ d("button", {
					type: "button",
					className: "btn-quiet w-full cursor-pointer",
					onClick: c,
					children: l("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ d("p", {
				className: "hnb-over-wait safe-b flex h-full items-center justify-center pb-1 text-sm font-bold opacity-70",
				children: l("session.result.waitHost")
			}),
			children: /* @__PURE__ */ f("div", {
				className: "hnb-over-body flex h-full min-h-0 flex-col items-center gap-3 overflow-y-auto",
				children: [/* @__PURE__ */ d("div", {
					className: "hnb-over-fireworks flex flex-none justify-center gap-2",
					children: h.map((e) => {
						let t = u.fireworks[e] ?? 0;
						return /* @__PURE__ */ f("div", {
							className: "hnb-over-firework flex flex-col items-center gap-0.5",
							children: [/* @__PURE__ */ d("div", {
								className: `hnb-over-firework-box grid h-14 w-10 place-items-center rounded-lg border-2 ${t > 0 ? "border-ink" : "border-dashed border-ink/40"}`,
								style: t > 0 ? { background: N[e].bg } : void 0,
								children: t > 0 && /* @__PURE__ */ d("span", {
									className: "hnb-over-firework-number font-mono text-lg font-extrabold tabular-nums",
									style: { color: N[e].fg },
									children: t
								})
							}), /* @__PURE__ */ d("span", {
								className: "hnb-over-firework-label text-[10px] font-bold",
								children: l(P[e])
							})]
						}, e);
					})
				}), /* @__PURE__ */ d("ul", {
					className: "hnb-over-members flex w-full max-w-xs flex-none flex-col gap-1",
					children: e.ranking.map((e) => {
						let t = n.find((t) => t.rid === e);
						return /* @__PURE__ */ f("li", {
							className: "hnb-over-member frame flex items-center gap-2 px-3 py-1.5 text-sm font-bold",
							children: [/* @__PURE__ */ d("span", {
								className: "hnb-over-avatar grid size-8 flex-none place-items-center overflow-hidden rounded-full border-2 border-ink",
								style: { background: o[(t?.colorIndex ?? 0) % o.length].hex },
								children: t ? /* @__PURE__ */ d("img", {
									src: a[t.avatar % a.length],
									alt: "",
									draggable: !1,
									className: "size-full object-contain"
								}) : /* @__PURE__ */ d("span", {
									"aria-hidden": !0,
									children: "🧨"
								})
							}), /* @__PURE__ */ d("span", {
								className: "hnb-over-name min-w-0 flex-1 truncate",
								children: S(e)
							})]
						}, e);
					})
				})]
			})
		})]
	});
}
//#endregion
//#region src/games/hanabi/options.tsx
var qe = [
	{
		id: "base",
		label: "games.hanabi.optBase",
		hint: "games.hanabi.optBaseHint"
	},
	{
		id: "rainbow",
		label: "games.hanabi.optRainbow",
		hint: "games.hanabi.optRainbowHint"
	},
	{
		id: "rainbowWild",
		label: "games.hanabi.optRainbowWild",
		hint: "games.hanabi.optRainbowWildHint"
	}
];
function Je({ value: e, onChange: t }) {
	let n = i(), r = w.safeParse(e), a = r.success ? r.data : w.parse(void 0);
	return /* @__PURE__ */ d(v, {
		title: n("games.hanabi.optVariant"),
		children: qe.map((e) => /* @__PURE__ */ d(_, {
			name: "hanabi-variant",
			value: e.id,
			checked: a.variant === e.id,
			label: n(e.label),
			hint: n(e.hint),
			accent: y.accent,
			onChange: () => t({
				...a,
				variant: e.id
			})
		}, e.id))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/hanabi/entry.tsx
var Ye = {
	definition: fe,
	View: pe,
	bot: ze,
	describe: Be,
	fx: We,
	OverView: Ke,
	Options: Je,
	locales: {
		zh: {
			name: "花火 Hanabi",
			desc: "合作放烟花:你看得见所有人的牌,唯独看不见自己的,只能靠队友的提示出牌",
			rules: "游戏目标：全队合作，分别按数字 1 至 5 的顺序搭建五种颜色的烟花，争取获得尽可能高的总分。\n准备:\n· 两人或三人游戏中，每名玩家获得 5 张手牌；四人或五人游戏中，每名玩家获得 4 张手牌。\n· 将手牌正面朝向其他玩家。你不能查看自己的手牌，只能查看其他玩家的手牌。\n· 桌面有 8 枚提示标记与 3 格引信。\n流程:\n轮到你时，必须选择以下三种行动之一。\n· 给出提示：消耗 1 枚提示标记，选择一名队友，并指出其手牌中的一种颜色或一个数字。\n给出提示时，必须指出该队友手牌中所有符合条件的牌，不能只指出其中一部分，也不能提示其手牌中不存在的颜色或数字。\n· 弃置手牌：弃置 1 张手牌，并收回 1 枚提示标记。全部提示标记均可用时，不能执行此行动。\n· 打出手牌：打出 1 张手牌。如果它的数字恰好是对应颜色烟花所需的下一个数字，将其加入该烟花；否则弃置该牌，并消耗 1 格引信。\n· 打出数字 5 完成一条烟花时,免费收回 1 枚提示标记。\n· 行动后从牌堆摸一张牌(末轮除外)。\n结束:\n· 三格引信全部消耗后，全队立即失败，本局获得 0 分。\n· 在抽牌堆耗尽前完成全部烟花，即以满分获胜。\n· 牌堆抽空后,每位玩家（包括抽走最后一张牌的玩家）再行动一次,随后结算:得分为各条烟花顶端数字之和。",
			turnYou: "轮到你:给提示、弃牌或出牌",
			turnWait: "等 {{name}} 行动…",
			lastRound: "末轮:牌堆已抽空,每人再行动一次",
			deckLeft: "牌堆 {{n}}",
			clueTokens: "提示",
			fuseTokens: "引信",
			discardPile: "弃牌堆({{n}})",
			discardEmpty: "弃牌堆是空的",
			discardTitle: "弃牌堆",
			myHand: "我的手牌(只能看提示)",
			handOf: "{{name}} 的手牌",
			hintBtn: "给提示",
			hintMode: "提示 {{name}}:选一种颜色或一个数字",
			hintCancel: "取消",
			play: "打出",
			discardAction: "弃牌",
			cardActions: "这张牌要…",
			cardMarks: "已知 / 排除",
			marksKnown: "已知",
			marksExcluded: "排除",
			marksNone: "还没有任何提示",
			slotAria: "手牌第 {{n}} 张",
			optVariant: "牌套变体",
			optBase: "基础五套",
			optBaseHint: "25 分封顶",
			optRainbow: "彩虹第六套",
			optRainbowHint: "独立烟花,30 分封顶",
			optRainbowWild: "彩虹百搭",
			optRainbowWildHint: "任何颜色提示都命中彩虹牌,30 分封顶",
			overPerfect: "完美演出!全场起立鼓掌",
			overScore: "演出落幕",
			overBust: "烟花炸了…",
			overScoreLine: "团队得分 {{score}} / {{max}}",
			rateHorrible: "观众嘘声一片…",
			rateMediocre: "稀稀拉拉的掌声",
			rateHonorable: "可圈可点的尝试,但很快被遗忘",
			rateExcellent: "精彩!观众很尽兴",
			rateAmazing: "惊艳!大家会念叨好几周",
			rateLegendary: "传奇!全场目瞪口呆",
			errDone: "本局已结束",
			errNotYourTurn: "还没轮到你",
			errNoClues: "没有提示标记了",
			errCluesFull: "提示标记全满,先给提示再弃牌",
			errBadTarget: "不能提示自己",
			errBadIndex: "手里没有这张牌",
			errEmptyHint: "对方没有符合条件的牌,不能这样提示",
			errRainbowColor: "百搭变体里彩虹不能作为提示色",
			suit: {
				white: "白",
				yellow: "黄",
				red: "红",
				blue: "蓝",
				green: "绿",
				rainbow: "彩虹"
			},
			dPlay: "打出第 {{n}} 张手牌",
			dDiscard: "弃掉第 {{n}} 张手牌",
			dHint: "提示队友:{{what}}",
			cardName: "{{suit}}{{num}}",
			logHint: "{{from}} 提示 {{to}}:{{what}}",
			logPlay: "{{name}} 打出 {{card}}",
			logPlayComplete: "{{name}} 打出 {{card}},完成一条烟花(+1 提示)",
			logBust: "{{name}} 打出 {{card}} 失败,引信烧掉一格",
			logDiscard: "{{name}} 弃掉 {{card}}"
		},
		en: {
			name: "Hanabi",
			desc: "Co-op fireworks: you can see everyone’s cards but your own — play yours off your teammates’ clues",
			rules: "Goal: work together to build 5 fireworks, each color rising from 1 to 5, and score as high as possible.\nSetup:\n· With 2–3 players each holds 5 cards; with 4–5 players, 4 cards.\n· Hold them facing away — you never see your own cards, only everyone else’s.\n· The table starts with 8 clue tokens and 3 fuse marks.\nPlay:\n· On your turn, do exactly one of: give a clue, discard a card, or play a card.\n· Give a clue: spend 1 clue token, name one color or one number held by a teammate.\n· Every matching card is pointed out; you may not point to only some of them, and “you have zero of something” is not allowed.\n· Discard: discard 1 card from your hand to recover 1 clue token. You cannot choose this action while all clue tokens are available.\n· Play: play a card from your hand; if it is exactly the next number of its color’s firework it is added.\n· Otherwise the card is lost and 1 fuse burns.\n· Playing a 5 completes a firework and returns 1 clue token for free.\n· After acting, draw a replacement card (except in the final round).\nEnd:\n· When the third fuse is consumed, the team immediately loses and scores 0 points.\n· If the team completes every firework before the deck runs out, the team wins with the maximum score.\n· Once the deck is empty, everyone (including the player who emptied it) acts once more, then the team scores the sum of the top card of each firework.",
			turnYou: "Your turn: clue, discard, or play",
			turnWait: "Waiting for {{name}}…",
			lastRound: "Final round: the deck is empty — one last turn each",
			deckLeft: "Deck {{n}}",
			clueTokens: "Clues",
			fuseTokens: "Fuses",
			discardPile: "Discards ({{n}})",
			discardEmpty: "The discard pile is empty",
			discardTitle: "Discard pile",
			myHand: "My hand (clues only)",
			handOf: "{{name}}’s hand",
			hintBtn: "Clue",
			hintMode: "Clue for {{name}}: pick a color or a number",
			hintCancel: "Cancel",
			play: "Play",
			discardAction: "Discard",
			cardActions: "This card…",
			cardMarks: "Known / ruled out",
			marksKnown: "Known",
			marksExcluded: "Ruled out",
			marksNone: "No clues yet",
			slotAria: "Hand card {{n}}",
			optVariant: "Suit variant",
			optBase: "Base five suits",
			optBaseHint: "Max score 25",
			optRainbow: "Rainbow sixth suit",
			optRainbowHint: "A separate firework, max 30",
			optRainbowWild: "Rainbow wild",
			optRainbowWildHint: "Every color clue hits rainbow cards, max 30",
			overPerfect: "A perfect show! Standing ovation",
			overScore: "The show is over",
			overBust: "The fireworks exploded…",
			overScoreLine: "Team score {{score}} / {{max}}",
			rateHorrible: "Booed by the crowd…",
			rateMediocre: "Mediocre, a hint of scattered applause",
			rateHonorable: "An honorable attempt, quickly forgotten",
			rateExcellent: "Excellent, crowd pleasing",
			rateAmazing: "Amazing — talked about for weeks",
			rateLegendary: "Legendary! Everyone left speechless",
			errDone: "This game is over",
			errNotYourTurn: "Not your turn yet",
			errNoClues: "No clue tokens left",
			errCluesFull: "All clue tokens are available — clue before discarding",
			errBadTarget: "You cannot clue yourself",
			errBadIndex: "No such card in hand",
			errEmptyHint: "They hold no matching card — clue not allowed",
			errRainbowColor: "Rainbow cannot be named as a color in the wild variant",
			suit: {
				white: "White",
				yellow: "Yellow",
				red: "Red",
				blue: "Blue",
				green: "Green",
				rainbow: "Rainbow"
			},
			dPlay: "Play hand card {{n}}",
			dDiscard: "Discard hand card {{n}}",
			dHint: "Clue a teammate: {{what}}",
			cardName: "{{suit}} {{num}}",
			logHint: "{{from}} clued {{to}}: {{what}}",
			logPlay: "{{name}} played {{card}}",
			logPlayComplete: "{{name}} played {{card}} — firework complete (+1 clue)",
			logBust: "{{name}} played {{card}} and failed — fuse burns",
			logDiscard: "{{name}} discarded {{card}}"
		}
	}
};
//#endregion
export { Ye as default };
