import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import t from "@bgparty/sdk/word-list";
import { z as n } from "zod";
import { useEffect as r, useRef as i, useState as a } from "react";
import { useT as o } from "@bgparty/sdk/i18n";
import { IconBack as s, IconClose as c, IconRotate as l, IconZoomIn as u } from "@bgparty/sdk/icons";
import { useWakeLock as d } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { useFxAnchor as p } from "@bgparty/sdk/fx/anchors";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { FlySprite as _, PulseBox as v } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as y } from "@bgparty/sdk/confirm-button";
import { OptionRadio as b, OptionSection as x } from "@bgparty/sdk/ui/game-options";
//#region src/games/soclover/data.ts
var S = [
	[
		"Dream",
		"Jump",
		"Cinema",
		"Cup"
	],
	[
		"Shelter",
		"Lighter",
		"Ireland",
		"Medusa"
	],
	[
		"Whip",
		"Uniform",
		"Human",
		"Window"
	],
	[
		"Performance",
		"Orchard",
		"Mass",
		"Photo"
	],
	[
		"Earth",
		"Toilet",
		"Mouse",
		"Yellow"
	],
	[
		"Heritage",
		"Apprentice",
		"Bedroom",
		"Mustard"
	],
	[
		"Revolution",
		"Mail",
		"Fry",
		"Ruler"
	],
	[
		"Sport",
		"Airport",
		"Currency",
		"Mirage"
	],
	[
		"Desert",
		"Honey",
		"Paper",
		"Virus"
	],
	[
		"Tower",
		"Barn",
		"Explore",
		"Giant"
	],
	[
		"Gas",
		"Heart",
		"Appetite",
		"War"
	],
	[
		"Covered",
		"Brown",
		"Furniture",
		"Comforter"
	],
	[
		"Table",
		"Church",
		"Truck",
		"Mushroom"
	],
	[
		"Jelly",
		"Computer",
		"Demon",
		"Revolver"
	],
	[
		"Powder",
		"Assassin",
		"Labyrinth",
		"Party"
	],
	[
		"Forecast",
		"Grey",
		"Screw",
		"Tomato"
	],
	[
		"Water",
		"Queen",
		"Attic",
		"Dough"
	],
	[
		"Craft",
		"Cookie",
		"Shell",
		"Flea"
	],
	[
		"Bomb",
		"Library",
		"Food",
		"Gift"
	],
	[
		"Whirlwind",
		"Wine",
		"Boat",
		"Iron"
	],
	[
		"Small",
		"Car",
		"Humor",
		"Garbage"
	],
	[
		"Country",
		"Stick",
		"Secret",
		"Cigarette"
	],
	[
		"Hand",
		"Crow",
		"River",
		"Radio"
	],
	[
		"Ambulance",
		"Dictator",
		"Fox",
		"Mountain"
	],
	[
		"Scissors",
		"Snow",
		"Palace",
		"Wing"
	],
	[
		"Tree",
		"Night",
		"School",
		"Ball"
	],
	[
		"Fountain",
		"Chick",
		"Ice",
		"Walk"
	],
	[
		"Piano",
		"Defense",
		"Sense",
		"Bridge"
	],
	[
		"Light",
		"Fast",
		"Case",
		"Pepper"
	],
	[
		"Padlock",
		"Fish",
		"Inside",
		"Astronaut"
	],
	[
		"Gamble",
		"Port",
		"Mask",
		"Sugar"
	],
	[
		"Major",
		"Reptile",
		"Dead",
		"Radar"
	],
	[
		"Spider",
		"Tornado",
		"Transport",
		"Shelf"
	],
	[
		"America",
		"Robot",
		"Wand",
		"Pigeon"
	],
	[
		"Donkey",
		"Park",
		"Virgin",
		"Mug"
	],
	[
		"Fire",
		"Drum",
		"Sister",
		"Hotel"
	],
	[
		"Poison",
		"Soft",
		"Diamond",
		"Book"
	],
	[
		"Kitchen",
		"Hard",
		"Finger",
		"Note"
	],
	[
		"Bottom",
		"Swing",
		"Leaf",
		"Career"
	],
	[
		"Board",
		"Axe",
		"Button",
		"Union"
	],
	[
		"Chain",
		"Fur",
		"Cold",
		"Advocate"
	],
	[
		"Cotton",
		"Salt",
		"Chef",
		"Square"
	],
	[
		"Office",
		"Chocolate",
		"Pair",
		"Protect"
	],
	[
		"Summit",
		"Jewel",
		"Bug",
		"Genius"
	],
	[
		"Noodle",
		"Tent",
		"Weapon",
		"Bakery"
	],
	[
		"Recent",
		"Mint",
		"Layer",
		"Devil"
	],
	[
		"Cavern",
		"Ear",
		"Shark",
		"Feed"
	],
	[
		"Mouth",
		"Bowl",
		"Blade",
		"Peace"
	],
	[
		"Roll",
		"Luck",
		"Hook",
		"Fuel"
	],
	[
		"Blanket",
		"Lady",
		"Pearl",
		"Carrot"
	],
	[
		"Africa",
		"Patio",
		"Liquid",
		"Twins"
	],
	[
		"Moist",
		"Guardian",
		"Sunday",
		"Wolf"
	],
	[
		"Award",
		"Skull",
		"Fly",
		"Calendar"
	],
	[
		"Sea",
		"Eye",
		"Bouquet",
		"Box"
	],
	[
		"Camp",
		"Size",
		"Crescent",
		"Outlet"
	],
	[
		"Double",
		"Police",
		"Silence",
		"Air"
	],
	[
		"Suite",
		"Pocket",
		"Missile",
		"Comedy"
	],
	[
		"Train",
		"Grave",
		"Bear",
		"Solitary"
	],
	[
		"Hall",
		"Tool",
		"Heroine",
		"Hair"
	],
	[
		"Closet",
		"Race",
		"Rain",
		"Asset"
	],
	[
		"First",
		"Boxing",
		"Fever",
		"Building"
	],
	[
		"Champagne",
		"Landscape",
		"Switzerland",
		"Cockroach"
	],
	[
		"Court",
		"Candy",
		"Danger",
		"Grass"
	],
	[
		"Dinosaur",
		"Military",
		"Birthday",
		"Press"
	],
	[
		"Roast",
		"Hospital",
		"Essence",
		"Joke"
	],
	[
		"Tame",
		"Charm",
		"Flour",
		"Sail"
	],
	[
		"Fault",
		"Rabbit",
		"France",
		"Physical"
	],
	[
		"Fairy",
		"Violin",
		"Cuddle",
		"New"
	],
	[
		"Cream",
		"Work",
		"Laser",
		"Arm"
	],
	[
		"Watch",
		"Revenge",
		"Motor",
		"Heel"
	],
	[
		"Cheese",
		"Cloud",
		"Illness",
		"Column"
	],
	[
		"Animal",
		"Fool",
		"Map",
		"Waiter"
	],
	[
		"Exhibition",
		"Common",
		"Ship",
		"Apple"
	],
	[
		"God",
		"Dessert",
		"Bank",
		"Lava"
	],
	[
		"Blue",
		"Vision",
		"Tunnel",
		"Dress"
	],
	[
		"Arrow",
		"Market",
		"Shadow",
		"Picture"
	],
	[
		"Species",
		"Summer",
		"Temple",
		"Suit"
	],
	[
		"Road",
		"Butterfly",
		"Cocktail",
		"Face"
	],
	[
		"Edge",
		"Technology",
		"Beer",
		"Marker"
	],
	[
		"Dresser",
		"Herbs",
		"Suitcase",
		"Judge"
	],
	[
		"Master",
		"Log",
		"Skin",
		"Border"
	],
	[
		"Porcelain",
		"Card",
		"Pump",
		"Season"
	],
	[
		"Weak",
		"Basket",
		"Knight",
		"Toy"
	],
	[
		"Island",
		"Winter",
		"High",
		"Foot"
	],
	[
		"Group",
		"Bottle",
		"Beard",
		"North"
	],
	[
		"Poetry",
		"Bubble",
		"Sweet",
		"Nest"
	],
	[
		"Trash",
		"Gernade",
		"Claw",
		"Mud"
	],
	[
		"Match",
		"Paradise",
		"Mother",
		"Rope"
	],
	[
		"Slide",
		"Pliers",
		"Snail",
		"Dynamite"
	],
	[
		"Ink",
		"Spear",
		"Stitches",
		"Garden"
	],
	[
		"Candle",
		"Plant",
		"Antiquity",
		"Exit"
	],
	[
		"Blood",
		"String",
		"Telescope",
		"Report"
	],
	[
		"Giant",
		"Explore",
		"Bucket",
		"Barn"
	],
	[
		"Shield",
		"Day",
		"Inspection",
		"History"
	],
	[
		"Slow",
		"Magic",
		"Bay",
		"Pipe"
	],
	[
		"Tennis",
		"Magnet",
		"Shop",
		"File"
	],
	[
		"Limit",
		"Instrument",
		"Pirate",
		"Intersection"
	],
	[
		"Pad",
		"Storm",
		"Soldier",
		"Ghost"
	],
	[
		"Dish",
		"Business",
		"Myth",
		"Big"
	],
	[
		"Cross",
		"Science",
		"Hot",
		"Dwarf"
	],
	[
		"Cube",
		"Apron",
		"Degree",
		"Siren"
	],
	[
		"Marine",
		"Bone",
		"Spring",
		"Band"
	],
	[
		"Right",
		"Octopus",
		"Forest",
		"Display"
	],
	[
		"Dirty",
		"Fair",
		"Medal",
		"Wave"
	],
	[
		"Straw",
		"Thunder",
		"Religion",
		"Promotion"
	],
	[
		"Red",
		"Adventure",
		"Line",
		"Umbrella"
	],
	[
		"Horse",
		"Drink",
		"Polar",
		"Short"
	],
	[
		"Bag",
		"Balcony",
		"Thin",
		"Rice"
	],
	[
		"Pie",
		"Green",
		"Cage",
		"Bump"
	],
	[
		"Recipient",
		"Voice",
		"Cell",
		"Console"
	],
	[
		"Music",
		"Phone",
		"Cantina",
		"Lightning"
	],
	[
		"Alarm",
		"Brain",
		"Space",
		"Accessory"
	],
	[
		"Ring",
		"Dungeon",
		"Cane",
		"Wool"
	],
	[
		"Hammer",
		"Forbidden",
		"Drawing",
		"Bin"
	],
	[
		"Bed",
		"Key",
		"Zoo",
		"Angel"
	],
	[
		"Sewer",
		"Safari",
		"Engine",
		"Letter"
	],
	[
		"Napkin",
		"Limb",
		"Perfume",
		"Chariot"
	],
	[
		"Hardware",
		"Sausage",
		"Ticket",
		"Witness"
	],
	[
		"Soap",
		"Quilt",
		"Full",
		"Branch"
	],
	[
		"Triangle",
		"Elastic",
		"Weather",
		"Order"
	],
	[
		"Caterpillar",
		"Knife",
		"Bar",
		"Strong"
	],
	[
		"Morning",
		"Beach",
		"Head",
		"Device"
	],
	[
		"Sky",
		"Town",
		"Spice",
		"Detective"
	],
	[
		"Tea",
		"Heavy",
		"Room",
		"Life"
	],
	[
		"Wind",
		"Bark",
		"China",
		"Belt"
	],
	[
		"Duck",
		"Kiss",
		"Trim",
		"Barracks"
	],
	[
		"Helmet",
		"Farm",
		"Strength",
		"Couch"
	],
	[
		"Feather",
		"Tiny",
		"Pan",
		"Orange"
	],
	[
		"Ladybug",
		"Speaker",
		"Restaurant",
		"Painting"
	],
	[
		"Carton",
		"Sharp",
		"Snake",
		"Belgium"
	],
	[
		"Wood",
		"March",
		"Skeleton",
		"Hole"
	],
	[
		"Universe",
		"Balance",
		"Chameleon",
		"Wheel"
	],
	[
		"Curtain",
		"Armor",
		"Charge",
		"Antarctica"
	],
	[
		"Door",
		"Sock",
		"Cow",
		"Circle"
	],
	[
		"Nut",
		"Plane",
		"Bath",
		"Nerve"
	],
	[
		"Boss",
		"Post",
		"Color",
		"Rifle"
	],
	[
		"Bench",
		"Camera",
		"Patron",
		"Stud"
	],
	[
		"Spy",
		"Electricity",
		"Tube",
		"Berry"
	],
	[
		"Owl",
		"Bang",
		"Ruin",
		"Stamp"
	],
	[
		"Black",
		"Sponge",
		"Hunt",
		"Thread"
	],
	[
		"Dragon",
		"Victory",
		"Europe",
		"Repair"
	],
	[
		"Recipe",
		"Decor",
		"Blond",
		"Trailer"
	],
	[
		"Place",
		"King",
		"Glasses",
		"Syrup"
	],
	[
		"Doctor",
		"Beef",
		"Mark",
		"Chair"
	],
	[
		"Sticky",
		"Nurse",
		"Bird",
		"Treasure"
	],
	[
		"Casino",
		"Hide",
		"Mind",
		"Moon"
	],
	[
		"Bus",
		"Newspaper",
		"Egg",
		"Nail"
	],
	[
		"Clean",
		"Chimney",
		"Story",
		"Jar"
	],
	[
		"Television",
		"Ramp",
		"Lemon",
		"Dog"
	],
	[
		"Underground",
		"Curry",
		"Autumn",
		"Machine"
	],
	[
		"Game",
		"Soup",
		"Canvas",
		"Punch"
	],
	[
		"Vegetable",
		"Talent",
		"Foam",
		"Handle"
	],
	[
		"Round",
		"Entry",
		"Sand",
		"Oven"
	],
	[
		"Base",
		"Sight",
		"Subway",
		"Baby"
	],
	[
		"Glass",
		"Series",
		"Turn",
		"Hobbies"
	],
	[
		"Month",
		"Stunt",
		"Stroke",
		"Cabbage"
	],
	[
		"Feline",
		"Clown",
		"Garage",
		"Tobacco"
	],
	[
		"Tank",
		"Bill",
		"Challenge",
		"Friend"
	],
	[
		"Basement",
		"Cable",
		"Sun",
		"Concert"
	],
	[
		"Crown",
		"Matter",
		"Dance",
		"Prison"
	],
	[
		"Delivery",
		"Throat",
		"Song",
		"Station"
	],
	[
		"Circus",
		"Skate",
		"Ladder",
		"Pilot"
	],
	[
		"Weight",
		"Frame",
		"Pumpkin",
		"Jungle"
	],
	[
		"Deep",
		"Bracelet",
		"Region",
		"Cemetery"
	],
	[
		"Lock",
		"Thermometer",
		"Schedule",
		"Guitar"
	],
	[
		"Studio",
		"Magician",
		"Cave",
		"Mosquito"
	],
	[
		"Nightmare",
		"Paintbrush",
		"Chest",
		"Pit"
	],
	[
		"Attraction",
		"Wizard",
		"Rake",
		"Tongue"
	],
	[
		"Top",
		"Explosion",
		"Show",
		"Diet"
	],
	[
		"Hen",
		"Ballroom",
		"Bike",
		"Mirror"
	],
	[
		"Moustache",
		"Pizza",
		"Surgeon",
		"Silver"
	],
	[
		"Bread",
		"Flight",
		"Chess",
		"Mummy"
	],
	[
		"Cactus",
		"Princess",
		"Bulb",
		"Cake"
	],
	[
		"Lake",
		"Melon",
		"Sound",
		"Gold"
	],
	[
		"Oasis",
		"Plank",
		"Cereal",
		"Evening"
	],
	[
		"Knot",
		"Needle",
		"Butcher",
		"Smoke"
	],
	[
		"Club",
		"Pyramid",
		"Loop",
		"Stylist"
	],
	[
		"Hell",
		"Taste",
		"Track",
		"Milk"
	],
	[
		"Cork",
		"Archeology",
		"Distributor",
		"Plush"
	],
	[
		"Shape",
		"Glove",
		"Ground",
		"Asia"
	],
	[
		"Museum",
		"Wheat",
		"Roof",
		"Canal"
	],
	[
		"Architecture",
		"Sleeve",
		"Family",
		"Flame"
	],
	[
		"Stocks",
		"Lazy",
		"Crane",
		"District"
	],
	[
		"Tradition",
		"Broom",
		"Bronze",
		"Saber"
	],
	[
		"Carpet",
		"Battery",
		"Laugh",
		"Luxury"
	],
	[
		"Travel",
		"Brush",
		"Flower",
		"Fishing"
	],
	[
		"Statue",
		"Turtle",
		"Grain",
		"Shed"
	],
	[
		"Oil",
		"Necklace",
		"Vampire",
		"Cushion"
	],
	[
		"Brother",
		"Turnip",
		"Grate",
		"Envelop"
	],
	[
		"Hood",
		"House",
		"Pear",
		"Lamp"
	],
	[
		"Climbing",
		"Sheep",
		"Pond",
		"Firefighter"
	],
	[
		"Doe",
		"Tattoo",
		"Clothing",
		"Banana"
	],
	[
		"Shirt",
		"Child",
		"Tail",
		"Menu"
	],
	[
		"Guide",
		"Down",
		"Love",
		"Memory"
	],
	[
		"Internet",
		"Father",
		"Snack",
		"Captain"
	],
	[
		"Field",
		"Passion",
		"Flute",
		"Crab"
	],
	[
		"Tiger",
		"Old",
		"Alliance",
		"Cabin"
	],
	[
		"Marriage",
		"Flask",
		"Target",
		"Leak"
	],
	[
		"Permanent",
		"Champion",
		"Cannon",
		"Potato"
	],
	[
		"Star",
		"Rich",
		"Handicap",
		"Lion"
	],
	[
		"Hat",
		"Spicy",
		"Large",
		"Pine"
	],
	[
		"Suspect",
		"Raft",
		"Mobile",
		"Oak"
	],
	[
		"Hearing",
		"Stage",
		"Ladle",
		"Hearth"
	],
	[
		"Frost",
		"Castle",
		"Plastic",
		"Detergent"
	],
	[
		"Lighthouse",
		"Metal",
		"Hero",
		"Emergency"
	],
	[
		"Ray",
		"Gate",
		"Boot",
		"Rat"
	],
	[
		"White",
		"Minor",
		"Fable",
		"Cavalry"
	],
	[
		"Screen",
		"Root",
		"Beast",
		"Volcano"
	],
	[
		"Wild",
		"Whale",
		"Bell",
		"Fruit"
	],
	[
		"Shovel",
		"Trophy",
		"End",
		"Commerce"
	],
	[
		"Volume",
		"Rose",
		"Ammo",
		"Vacation"
	],
	[
		"Grape",
		"Middle",
		"Shower",
		"Utensil"
	],
	[
		"Pig",
		"Rail",
		"Sage",
		"Trade"
	],
	[
		"Theatre",
		"Thief",
		"Smell",
		"Oar"
	],
	[
		"Movie",
		"Fashion",
		"Tile",
		"Bite"
	],
	[
		"Monster",
		"Record",
		"Body",
		"Cat"
	],
	[
		"Flash",
		"Past",
		"Capital",
		"Doll"
	],
	[
		"Ocean",
		"Young",
		"Camouflage",
		"Salad"
	],
	[
		"Well",
		"Nude",
		"Rooster",
		"Alcohol"
	],
	[
		"Stone",
		"Cougar",
		"Coffee",
		"Puzzle"
	]
], C = {
	id: "soclover",
	tier: "alpha",
	nameKey: "games.soclover.name",
	descKey: "games.soclover.desc",
	rulesKey: "games.soclover.rules",
	icon: "🍀",
	iconImg: "games/soclover.webp",
	minPlayers: 3,
	maxPlayers: 6,
	mechanics: [
		"word-association",
		"deduction",
		"tile-placement"
	],
	interactionTags: ["cooperative", "communication-limits"],
	accent: "#75b62e",
	releasedAt: "2026-11-03T15:25:55+08:00",
	search: {
		py: "mi yu xing yun cao mi yu si ye cao",
		init: "myxyc mysyc"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/1742323198246185870/1DDC1695461840A6544AD8BF0E3625E8F887BEB0/" }
}, w = n.string().trim().min(1).max(40).refine((e) => !/[\p{Cc}\p{Cf}\s]/u.test(e)), T = n.object({
	extraCards: n.number().int().min(1).max(5).catch(1),
	wordLanguage: n.enum(["zh", "en"]).optional()
}).default({
	extraCards: 1,
	wordLanguage: "zh"
}), E = n.record(n.string(), n.tuple([
	n.string(),
	n.string(),
	n.string(),
	n.string()
])), D = n.object({
	card: n.number().int().min(0).max(219),
	rotation: n.number().int().min(0).max(3)
}), O = n.discriminatedUnion("type", [
	n.object({
		type: n.literal("clues"),
		clues: n.array(w).length(4)
	}),
	n.object({
		type: n.literal("place"),
		card: n.number().int().min(0).max(219),
		rotation: n.number().int().min(0).max(3),
		slot: n.number().int().min(0).max(3)
	}),
	n.object({
		type: n.literal("remove"),
		slot: n.number().int().min(0).max(3)
	}),
	n.object({ type: n.literal("check") }),
	n.object({ type: n.literal("next") }),
	n.object({
		type: n.literal("tick"),
		now: n.number()
	})
]), k = n.object({
	tiles: n.array(D.nullable()).length(4),
	correct: n.array(n.boolean()).length(4)
}), A = n.object({
	owner: n.string(),
	clues: n.array(n.string()).length(4),
	solution: n.array(D).length(4),
	attempts: n.array(k),
	score: n.number().int()
}), j = n.object({
	phase: n.enum([
		"write",
		"solve",
		"result",
		"done"
	]),
	players: n.array(n.string()),
	ready: n.array(n.string()),
	round: n.number().int(),
	spectator: n.string(),
	captain: n.string(),
	attempt: n.number().int(),
	extraCards: n.number().int(),
	clues: n.array(n.string()),
	pool: n.array(n.number().int()),
	tiles: n.array(D.nullable()).length(4),
	orientations: n.record(n.string(), n.number().int().min(0).max(3)),
	locked: n.array(n.boolean()).length(4),
	results: n.array(A),
	total: n.number().int(),
	wordLanguage: n.enum(["zh", "en"]),
	cards: E
}), M = n.object({
	tiles: n.array(D),
	clues: n.array(n.string()).nullable(),
	cards: E
}), N = () => [
	null,
	null,
	null,
	null
], P = () => [
	!1,
	!1,
	!1,
	!1
], F = () => ({ code: "games.soclover.invalidAction" }), I = (e, t, n = S) => n[e.card][(t - e.rotation + 4) % 4];
function L(e, t = S) {
	return [
		[I(e[0], 0, t), I(e[1], 0, t)],
		[I(e[1], 1, t), I(e[3], 1, t)],
		[I(e[3], 2, t), I(e[2], 2, t)],
		[I(e[2], 3, t), I(e[0], 3, t)]
	];
}
var R = (e, t) => Object.fromEntries(t.map((t) => [t, [...e[t]]])), z = (e) => e.normalize("NFKC").toLocaleLowerCase("en-US");
function B(t, n) {
	let r = [...t];
	for (let t = r.length - 1; t > 0; t--) {
		let i = e(n.seed, n.cursor++, t + 1);
		[r[t], r[i]] = [r[i], r[t]];
	}
	return r;
}
var V = {
	meta: C,
	saveCompatibility: { version: "1" },
	schemas: {
		action: O,
		publicView: j,
		privateView: M,
		config: T
	},
	setup(n, r, i) {
		let a = {
			seed: i,
			cursor: 0
		}, o = n.wordLanguage === "zh" ? B([...new Set(t)], a).slice(0, 880) : null, s = o ? Array.from({ length: 220 }, (e, t) => o.slice(t * 4, t * 4 + 4)) : S.map((e) => [
			e[0],
			e[1],
			e[2],
			e[3]
		]), c = B(Array.from({ length: S.length }, (e, t) => t), a), l = r.map((t) => ({
			owner: t,
			clues: null,
			pool: [],
			solution: Array.from({ length: 4 }, () => ({
				card: c.pop(),
				rotation: e(i, a.cursor++, 4)
			}))
		}));
		return { state: {
			players: [...r],
			...a,
			deck: c,
			boards: l,
			config: n,
			cards: s,
			phase: "write",
			round: 0,
			attempt: 1,
			tiles: N(),
			locked: P(),
			attempts: [],
			results: [],
			orientations: {}
		} };
	},
	reduce(e, t, { by: n }) {
		if (!e.players.includes(n) || t.type === "tick" || e.phase === "done") return F();
		let r = e.players[e.round], i = e.players[(e.round + 1) % e.players.length];
		if (t.type === "clues") {
			let r = e.boards.find((e) => e.owner === n);
			if (e.phase !== "write" || r.clues || !t.clues.every((e) => w.safeParse(e).success)) return F();
			if (t.clues.some((t) => L(r.solution, e.cards).flat().some((e) => z(e) === z(t)))) return { code: "games.soclover.keywordClue" };
			let i = {
				...e,
				deck: [...e.deck]
			}, a = B([...r.solution.map((e) => e.card), ...Array.from({ length: e.config.extraCards }, () => i.deck.pop())], i);
			return i.boards = e.boards.map((e) => e.owner === n ? {
				...e,
				clues: t.clues.map((e) => e.trim()),
				pool: a
			} : e), i.boards.every((e) => e.clues) && (i.phase = "solve"), { state: i };
		}
		if (t.type === "next") return e.phase !== "result" || n !== i ? F() : { state: {
			...e,
			phase: e.round + 1 === e.players.length ? "done" : "solve",
			round: e.round + 1 === e.players.length ? e.round : e.round + 1,
			attempt: 1,
			tiles: N(),
			locked: P(),
			attempts: [],
			orientations: {}
		} };
		if (e.phase !== "solve" || n === r) return F();
		let a = e.boards[e.round];
		if (t.type === "place") {
			if (!a.pool.includes(t.card) || e.locked[t.slot] || e.tiles.some((n, r) => n?.card === t.card && e.locked[r])) return F();
			let n = e.tiles.findIndex((e) => e?.card === t.card), r = e.tiles.map((e, n) => n === t.slot ? {
				card: t.card,
				rotation: t.rotation
			} : e?.card === t.card ? null : e), i = e.tiles[t.slot]?.card === t.card ? null : e.tiles[t.slot];
			return {
				state: {
					...e,
					tiles: r,
					orientations: {
						...e.orientations,
						[t.card]: t.rotation
					}
				},
				fx: [{
					kind: "cloverPlace",
					data: {
						card: t.card,
						rotation: t.rotation,
						from: n,
						to: t.slot,
						displaced: i,
						cards: R(e.cards, [t.card, ...i ? [i.card] : []])
					}
				}]
			};
		}
		if (t.type === "remove") {
			let n = e.tiles[t.slot];
			return !n || e.locked[t.slot] ? F() : {
				state: {
					...e,
					tiles: e.tiles.map((e, n) => n === t.slot ? null : e)
				},
				fx: [{
					kind: "cloverPlace",
					data: {
						...n,
						from: t.slot,
						to: -1,
						cards: R(e.cards, [n.card])
					}
				}]
			};
		}
		if (t.type === "check") {
			if (n !== i || e.tiles.some((e) => !e)) return F();
			let t = e.tiles.map((e, t) => e?.card === a.solution[t].card && e.rotation === a.solution[t].rotation), o = [...e.attempts, {
				tiles: e.tiles,
				correct: t
			}], s = t.filter(Boolean).length, c = R(e.cards, e.tiles.flatMap((e) => e ? [e.card] : []));
			if (e.attempt === 1 && s !== 4) return {
				state: {
					...e,
					attempt: 2,
					attempts: o,
					locked: t,
					tiles: e.tiles.map((e, n) => t[n] ? e : null)
				},
				fx: [{
					kind: "cloverCheck",
					data: {
						correct: t,
						removed: e.tiles.map((e, n) => t[n] ? null : e),
						cards: c
					}
				}]
			};
			let l = s === 4 && e.attempt === 1 ? 6 : s, u = {
				owner: r,
				clues: a.clues,
				solution: a.solution,
				attempts: o,
				score: l
			};
			return {
				state: {
					...e,
					phase: "result",
					tiles: e.tiles.map((e, n) => t[n] ? e : null),
					locked: t,
					attempts: o,
					results: [...e.results, u]
				},
				fx: [{
					kind: "cloverCheck",
					data: {
						correct: t,
						removed: e.tiles.map((e, n) => t[n] ? null : e),
						cards: c
					}
				}]
			};
		}
		return F();
	},
	viewFor(e, t) {
		let n = e.boards[e.round], r = e.boards.find((e) => e.owner === t), i = e.phase !== "write";
		return {
			public: {
				phase: e.phase,
				players: e.players,
				ready: e.boards.filter((e) => e.clues).map((e) => e.owner),
				round: e.round,
				spectator: n.owner,
				captain: e.players[(e.round + 1) % e.players.length],
				attempt: e.attempt,
				extraCards: e.config.extraCards,
				clues: i ? n.clues : [],
				pool: i ? n.pool : [],
				tiles: i ? e.tiles : N(),
				orientations: i ? e.orientations : {},
				locked: i ? e.locked : P(),
				results: e.results,
				total: e.results.reduce((e, t) => e + t.score, 0),
				wordLanguage: e.config.wordLanguage ?? "en",
				cards: R(e.cards, [...i ? n.pool : [], ...e.results.flatMap((e) => [...e.solution, ...e.attempts.flatMap((e) => e.tiles)].flatMap((e) => e ? [e.card] : []))])
			},
			private: {
				tiles: r && e.phase === "write" && !r.clues ? r.solution : [],
				clues: r && e.phase === "write" ? r.clues : null,
				cards: R(e.cards, r && e.phase === "write" && !r.clues ? r.solution.map((e) => e.card) : [])
			}
		};
	},
	status(e) {
		let t = e.results.reduce((e, t) => e + t.score, 0);
		return e.phase === "done" ? {
			phase: "done",
			winner: [...e.players],
			ranking: [...e.players],
			scores: Object.fromEntries(e.players.map((e) => [e, t]))
		} : { phase: e.phase };
	}
};
//#endregion
//#region src/games/soclover/components.tsx
function H({ label: e, onClose: t, children: n }) {
	let a = i(null);
	return r(() => {
		let e = a.current;
		return e?.showModal(), () => e?.close();
	}, []), /* @__PURE__ */ h("dialog", {
		ref: a,
		className: "sc-modal",
		"aria-label": e,
		onCancel: (e) => {
			e.preventDefault(), t();
		},
		children: n
	});
}
function U({ tile: e, cards: t }) {
	return /* @__PURE__ */ g("svg", {
		className: "sc-card",
		viewBox: "0 0 100 100",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ h("rect", {
				x: "1",
				y: "1",
				width: "98",
				height: "98",
				rx: "5",
				fill: "#fffef8",
				stroke: "#c2c3b6",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ h("path", {
				d: "M38 38Q50 45 62 38Q55 50 62 62Q50 55 38 62Q45 50 38 38",
				fill: "#a2cd61",
				opacity: ".65"
			}),
			[
				[50, 14],
				[76, 50],
				[50, 86],
				[24, 50]
			].map(([n, r], i) => {
				let a = t[e.card][(i - e.rotation + 4) % 4], o = i % 2 == 1 && /\p{Script=Han}/u.test(a), s = o ? 64 : i % 2 ? 43 : 88, c = Array.from(a).reduce((e, t) => e + (o || t.codePointAt(0) > 127 ? 10.5 : 6.3), 0);
				return /* @__PURE__ */ h("text", {
					x: o ? i === 1 ? 86 : 14 : n,
					y: r,
					style: o ? {
						writingMode: "vertical-rl",
						textOrientation: "upright"
					} : void 0,
					dominantBaseline: "central",
					textAnchor: "middle",
					fill: "#1d281c",
					fontSize: "10.5",
					fontFamily: "Arial, Microsoft YaHei, PingFang SC, sans-serif",
					fontWeight: "700",
					textLength: c > s ? s : void 0,
					lengthAdjust: "spacingAndGlyphs",
					children: a
				}, i);
			})
		]
	});
}
function W(e, t) {
	return Array.from({ length: 4 }, (n, r) => t[e.card][(r - e.rotation + 4) % 4]).join(" · ");
}
function G({ tile: e, cards: t, index: n, locked: r, target: i, selected: a, onClick: s, anchored: c }) {
	let l = o(), { ref: u, hidden: d } = p(c ? `slot:${n}` : null);
	return /* @__PURE__ */ g("button", {
		type: "button",
		ref: u,
		className: `sc-slot${i ? " sc-target" : ""}${a ? " sc-selected" : ""}`,
		disabled: !s,
		"aria-pressed": a,
		"aria-label": l("games.soclover.slot", { n: n + 1 }) + (e ? ": " + W(e, t) : "") + (r ? " · " + l("games.soclover.locked") : ""),
		onClick: s,
		children: [/* @__PURE__ */ h("span", {
			className: "sc-slot-face",
			style: { visibility: d ? "hidden" : void 0 },
			children: e ? /* @__PURE__ */ h(U, {
				tile: e,
				cards: t
			}) : /* @__PURE__ */ h("span", {
				className: "sc-slot-number",
				children: n + 1
			})
		}), r && /* @__PURE__ */ h("span", {
			className: "sc-lock",
			children: "✓"
		})]
	});
}
function K({ tiles: e, cards: t, clues: n, locked: r = [], selected: i, targets: s = !1, onSlot: c, onClue: l, anchored: u = !1 }) {
	let d = o(), [f, p] = a(null);
	return /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("div", {
		className: "sc-board",
		children: [
			/* @__PURE__ */ g("svg", {
				className: "sc-board-shape",
				viewBox: "0 0 600 600",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ h("path", {
						d: "M300 75C160-55 5 70 65 230C-50 355 75 565 245 530L300 580L355 530C525 565 650 355 535 230C595 70 440-55 300 75Z",
						fill: "#478b24"
					}),
					/* @__PURE__ */ h("path", {
						d: "M300 85C165-40 20 78 78 232C-32 356 85 550 247 518L300 565L353 518C515 550 632 356 522 232C580 78 435-40 300 85Z",
						fill: "#86bd37",
						stroke: "#b6dc64",
						strokeWidth: "5"
					}),
					/* @__PURE__ */ h("path", {
						d: "M300 100V500M100 300H500",
						stroke: "#6ea32e",
						strokeWidth: "2"
					})
				]
			}),
			[
				0,
				1,
				2,
				3
			].map((e) => /* @__PURE__ */ h("label", {
				className: `sc-clue sc-side-${e}${e % 2 == 1 && /\p{Script=Han}/u.test(n[e] || (l ? d("games.soclover.clueSide", { n: e + 1 }) : "")) ? " sc-clue-vertical" : ""}`,
				children: l ? /* @__PURE__ */ h("textarea", {
					rows: 1,
					"aria-label": d("games.soclover.clueSide", { n: e + 1 }),
					placeholder: d("games.soclover.clueSide", { n: e + 1 }),
					value: n[e] ?? "",
					maxLength: 40,
					onChange: (t) => l(e, t.target.value),
					autoComplete: "off",
					spellCheck: !1,
					onKeyDown: (e) => {
						e.key === "Enter" && !e.nativeEvent.isComposing && e.preventDefault();
					}
				}) : /* @__PURE__ */ h("button", {
					type: "button",
					disabled: !n[e],
					"aria-label": d("games.soclover.clueSide", { n: e + 1 }) + ": " + (n[e] ?? ""),
					onClick: () => p(e),
					children: n[e]
				})
			}, e)),
			/* @__PURE__ */ h("div", {
				className: "sc-slots",
				children: e.map((e, n) => /* @__PURE__ */ h(G, {
					tile: e,
					cards: t,
					index: n,
					locked: r[n],
					target: s && !r[n],
					selected: e !== null && i === e.card,
					onClick: c && !r[n] ? () => c(n) : void 0,
					anchored: u
				}, n))
			})
		]
	}), f !== null && /* @__PURE__ */ g(H, {
		label: d("games.soclover.clueSide", { n: f + 1 }),
		onClose: () => p(null),
		children: [/* @__PURE__ */ h("button", {
			autoFocus: !0,
			type: "button",
			className: "sc-secondary",
			onClick: () => p(null),
			children: d("games.soclover.close")
		}), /* @__PURE__ */ h("p", {
			className: "sc-clue-full",
			children: n[f]
		})]
	})] });
}
function q({ tile: e, cards: t, used: n, selected: r, disabled: i, onClick: a, children: s }) {
	let c = o(), { ref: l, hidden: u } = p(`tray:${e.card}`);
	return /* @__PURE__ */ g("div", {
		className: `sc-tray-item${r ? " sc-selected" : ""}`,
		children: [/* @__PURE__ */ g("button", {
			type: "button",
			ref: l,
			className: "sc-card-button",
			disabled: i,
			"aria-label": W(e, t),
			"aria-pressed": r,
			onClick: a,
			children: [/* @__PURE__ */ h("span", {
				style: {
					visibility: u ? "hidden" : void 0,
					opacity: n === void 0 ? 1 : .32
				},
				children: /* @__PURE__ */ h(U, {
					tile: e,
					cards: t
				})
			}), n !== void 0 && /* @__PURE__ */ h("b", {
				className: "sc-used",
				children: c("games.soclover.inSlot", { n: n + 1 })
			})]
		}), s]
	});
}
//#endregion
//#region src/games/soclover/view-player.tsx
function J(e) {
	return d(), /* @__PURE__ */ h(Y, { ...e }, e.myRid);
}
function Y({ public: e, private: t, members: n, myRid: r, send: i }) {
	let d = e, p = t, _ = o(), [v, y] = a([
		"",
		"",
		"",
		""
	]), [b, x] = a(null), [S, C] = a(!1), T = b?.round === d.round && b.phase === d.phase ? b.tile : null, E = (e) => n.find((t) => t.rid === e)?.name ?? e, D = d.phase === "write", O = d.ready.includes(r), k = d.phase === "solve" && d.spectator !== r && d.players.includes(r), A = T && !d.tiles.some((e, t) => e?.card === T.card && d.locked[t]) ? T : null, j = D ? p?.cards ?? {} : d.cards, M = p?.clues ?? v, N = D ? p?.tiles.length ? p.tiles : [
		null,
		null,
		null,
		null
	] : d.tiles, P = () => {
		A && x({
			round: d.round,
			phase: d.phase,
			tile: {
				...A,
				rotation: (A.rotation + 1) % 4
			}
		});
	}, F = (e) => {
		C(!1), x({
			round: d.round,
			phase: d.phase,
			tile: e
		});
	}, I = A ? d.tiles.findIndex((e) => e?.card === A.card) : -1, L = () => {
		M.every((e) => w.safeParse(e).success) && i({
			type: "clues",
			clues: M.map((e) => e.trim())
		});
	}, R = d.results.find((e) => e.owner === d.spectator);
	return /* @__PURE__ */ g(f, {
		adaptive: !0,
		scroll: !1,
		className: "sc-game",
		banner: /* @__PURE__ */ g("header", {
			className: "sc-header",
			children: [/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("strong", { children: D ? _("games.soclover.write") : _("games.soclover.boardOf", { name: E(d.spectator) }) }), /* @__PURE__ */ h("span", { children: D ? _("games.soclover.readyCount", {
				n: d.ready.length,
				total: d.players.length
			}) : _("games.soclover.round", {
				n: d.round + 1,
				total: d.players.length
			}) })] }), /* @__PURE__ */ h("b", { children: _("games.soclover.points", { n: d.total }) })]
		}),
		children: [/* @__PURE__ */ g("main", {
			className: "sc-main",
			children: [/* @__PURE__ */ h("section", {
				className: "sc-board-zone",
				"aria-label": _("games.soclover.board"),
				children: /* @__PURE__ */ h(K, {
					tiles: N,
					cards: j,
					clues: D ? M : d.clues,
					locked: D ? [] : d.locked,
					selected: A?.card,
					targets: k && A !== null,
					anchored: !D,
					onClue: D && !O && p?.tiles.length ? (e, t) => y(v.map((n, r) => r === e ? t : n)) : void 0,
					onSlot: D && !O && p?.tiles.length ? (e) => {
						F(p.tiles[e]), C(!0);
					} : k ? (e) => {
						A ? (i({
							type: "place",
							...A,
							slot: e
						}), x(null)) : d.tiles[e] && F(d.tiles[e]);
					} : void 0
				})
			}), /* @__PURE__ */ h("aside", {
				className: "sc-sidebar",
				children: D ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("div", {
					className: "sc-writing",
					children: [
						/* @__PURE__ */ h("h2", { children: _(d.wordLanguage === "zh" ? "games.soclover.chineseCards" : "games.soclover.englishCards") }),
						/* @__PURE__ */ h("p", { children: _(O ? "games.soclover.waitWriters" : "games.soclover.writePrompt") }),
						/* @__PURE__ */ h("button", {
							type: "button",
							className: "sc-primary",
							disabled: O || !p?.tiles.length || !M.every((e) => w.safeParse(e).success),
							onClick: L,
							children: _(O ? "games.soclover.submitted" : "games.soclover.submitClues")
						})
					]
				}), /* @__PURE__ */ h("div", {
					className: "sc-ready-list",
					children: d.players.map((e) => /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h("b", { children: E(e) }), /* @__PURE__ */ h("span", { children: _(d.ready.includes(e) ? "games.soclover.submitted" : "games.soclover.writing") })] }, e))
				})] }) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("div", {
					className: "sc-solving",
					children: [
						/* @__PURE__ */ g("div", {
							className: "sc-turn",
							children: [/* @__PURE__ */ h("strong", { children: d.phase === "result" ? _("games.soclover.scored", { n: R?.score ?? 0 }) : _("games.soclover.attempt", { n: d.attempt }) }), /* @__PURE__ */ h("span", { children: _(d.wordLanguage === "zh" ? "games.soclover.chineseCards" : "games.soclover.englishCards") })]
						}),
						/* @__PURE__ */ h("p", {
							role: "status",
							children: d.phase === "result" ? _("games.soclover.verifiedLayout") : d.spectator === r ? _("games.soclover.spectator") : _(A ? "games.soclover.chooseSlot" : "games.soclover.chooseCard")
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							className: "sc-primary",
							disabled: r !== d.captain || d.phase === "solve" && d.tiles.some((e) => !e) || d.phase !== "solve" && d.phase !== "result",
							onClick: () => i({ type: d.phase === "result" ? "next" : "check" }),
							children: _(d.phase === "result" ? d.round + 1 === d.players.length ? "games.soclover.finish" : "games.soclover.next" : "games.soclover.check")
						}),
						/* @__PURE__ */ h("small", { children: _("games.soclover.captain", { name: E(d.captain) }) })
					]
				}), /* @__PURE__ */ h("section", {
					className: "sc-tray",
					"aria-label": _("games.soclover.cards"),
					children: d.pool.map((e) => {
						let t = d.tiles.findIndex((t) => t?.card === e), n = t >= 0 && d.locked[t], r = A?.card === e ? A : t >= 0 ? d.tiles[t] : {
							card: e,
							rotation: d.orientations[e] ?? 0
						};
						return /* @__PURE__ */ h(q, {
							tile: r,
							cards: j,
							used: t >= 0 ? t : void 0,
							selected: A?.card === e,
							disabled: !k || n,
							onClick: () => F(r),
							children: A?.card === e && k && /* @__PURE__ */ g("div", {
								className: "sc-tools",
								children: [
									/* @__PURE__ */ h("button", {
										type: "button",
										"aria-label": _("games.soclover.rotate"),
										onClick: P,
										children: /* @__PURE__ */ h(l, { size: 19 })
									}),
									/* @__PURE__ */ h("button", {
										type: "button",
										"aria-label": _("games.soclover.inspect"),
										onClick: () => C(!0),
										children: /* @__PURE__ */ h(u, { size: 19 })
									}),
									I >= 0 && /* @__PURE__ */ h("button", {
										type: "button",
										"aria-label": _("games.soclover.remove"),
										onClick: () => {
											i({
												type: "remove",
												slot: I
											}), x(null);
										},
										children: /* @__PURE__ */ h(s, { size: 19 })
									}),
									/* @__PURE__ */ h("button", {
										type: "button",
										"aria-label": _("games.soclover.cancel"),
										onClick: () => x(null),
										children: /* @__PURE__ */ h(c, { size: 19 })
									})
								]
							})
						}, e);
					})
				})] })
			})]
		}), S && A && /* @__PURE__ */ g(H, {
			label: _("games.soclover.inspect"),
			onClose: () => C(!1),
			children: [
				/* @__PURE__ */ h("button", {
					autoFocus: !0,
					type: "button",
					className: "sc-secondary",
					onClick: () => C(!1),
					children: _("games.soclover.close")
				}),
				/* @__PURE__ */ h("div", {
					className: "sc-large-card",
					children: /* @__PURE__ */ h(U, {
						tile: A,
						cards: j
					})
				}),
				/* @__PURE__ */ h("p", { children: W(A, j) }),
				k && /* @__PURE__ */ h("button", {
					type: "button",
					className: "sc-primary",
					onClick: P,
					children: _("games.soclover.rotate")
				})
			]
		})]
	});
}
//#endregion
//#region src/games/soclover/bot.ts
var X = () => null, Z = {
	cloverPlace(e, t) {
		let n = e.data, r = t.anchor(n.from < 0 ? `tray:${n.card}` : `slot:${n.from}`), i = n.to < 0 ? `tray:${n.card}` : `slot:${n.to}`, a = t.anchor(i);
		if (!r || !a) return null;
		let o = n.displaced ? t.anchor(`tray:${n.displaced.card}`) : null;
		return {
			ms: 360,
			hide: [i, ...n.displaced && o ? [`tray:${n.displaced.card}`] : []],
			node: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(_, {
				from: r,
				to: a,
				ms: 360,
				children: /* @__PURE__ */ h("div", {
					style: {
						width: r.w,
						height: r.h
					},
					children: /* @__PURE__ */ h(U, {
						tile: n,
						cards: n.cards
					})
				})
			}), n.displaced && o && /* @__PURE__ */ h(_, {
				from: a,
				to: o,
				ms: 360,
				children: /* @__PURE__ */ h("div", {
					style: {
						width: a.w,
						height: a.h
					},
					children: /* @__PURE__ */ h(U, {
						tile: n.displaced,
						cards: n.cards
					})
				})
			})] })
		};
	},
	cloverCheck(e, t) {
		let { correct: n, removed: r, cards: i } = e.data, a = r.flatMap((e, n) => {
			let r = t.anchor(`slot:${n}`), i = e ? t.anchor(`tray:${e.card}`) : null;
			return e && r && i ? [{
				tile: e,
				from: r,
				to: i
			}] : [];
		});
		return {
			ms: 600,
			hide: a.map(({ tile: e }) => `tray:${e.card}`),
			node: /* @__PURE__ */ g(m, { children: [n.map((e, n) => {
				let r = t.anchor(`slot:${n}`);
				return e && r ? /* @__PURE__ */ h(v, {
					at: r,
					ms: 600
				}, n) : null;
			}), a.map(({ tile: e, from: t, to: n }) => /* @__PURE__ */ h(_, {
				from: t,
				to: n,
				ms: 450,
				children: /* @__PURE__ */ h("div", {
					style: {
						width: t.w,
						height: t.h
					},
					children: /* @__PURE__ */ h(U, {
						tile: e,
						cards: i
					})
				})
			}, e.card))] })
		};
	}
};
//#endregion
//#region src/games/soclover/game-over.tsx
function Q({ public: e, members: t, result: n, hintCount: r, onPlayAgain: i, onBackToLobby: s }) {
	let l = e, u = o(), [d, f] = a(!0), [p, m] = a(0), [_, v] = a(-1), b = (e) => t.find((t) => t.rid === e)?.name ?? e, x = l.results[p];
	return /* @__PURE__ */ g("div", {
		className: "sc-final",
		children: [
			/* @__PURE__ */ h("header", {
				className: "sc-header",
				children: /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("strong", { children: u("games.soclover.teamScore") }), /* @__PURE__ */ g("span", { children: [
					u("games.soclover.points", { n: l.total }),
					" / ",
					l.players.length * 6
				] })] })
			}),
			/* @__PURE__ */ g("div", {
				className: "sc-review",
				inert: d,
				children: [/* @__PURE__ */ g("div", {
					className: "sc-review-toolbar",
					children: [/* @__PURE__ */ g("label", { children: [u("games.soclover.board"), /* @__PURE__ */ h("select", {
						value: p,
						onChange: (e) => {
							m(Number(e.target.value)), v(-1);
						},
						children: l.results.map((e, t) => /* @__PURE__ */ g("option", {
							value: t,
							children: [
								b(e.owner),
								" · ",
								e.score
							]
						}, e.owner))
					})] }), /* @__PURE__ */ g("label", { children: [u("games.soclover.layout"), /* @__PURE__ */ g("select", {
						value: _,
						onChange: (e) => v(Number(e.target.value)),
						children: [/* @__PURE__ */ h("option", {
							value: -1,
							children: u("games.soclover.originalLayout")
						}), x?.attempts.map((e, t) => /* @__PURE__ */ h("option", {
							value: t,
							children: u("games.soclover.attempt", { n: t + 1 })
						}, t))]
					})] })]
				}), /* @__PURE__ */ h("div", {
					className: "sc-final-board",
					children: x && /* @__PURE__ */ h(K, {
						cards: l.cards,
						tiles: _ < 0 ? x.solution : x.attempts[_].tiles,
						clues: x.clues,
						locked: _ < 0 ? [] : x.attempts[_].correct
					})
				})]
			}),
			/* @__PURE__ */ g("section", {
				className: `sc-score-panel${d ? " sc-open" : ""}`,
				"aria-label": u("games.soclover.teamScore"),
				children: [
					/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("h1", { children: u("games.soclover.teamScore") }), /* @__PURE__ */ h("button", {
						type: "button",
						className: "sc-icon-button",
						"aria-label": u("games.soclover.review"),
						onClick: () => f(!1),
						children: /* @__PURE__ */ h(c, {})
					})] }),
					/* @__PURE__ */ g("strong", {
						className: "sc-total",
						children: [l.total, /* @__PURE__ */ g("small", { children: [" / ", l.players.length * 6] })]
					}),
					/* @__PURE__ */ g("div", {
						className: "sc-score-scroll",
						children: [l.results.map((e) => /* @__PURE__ */ g("div", {
							className: "sc-score-row",
							children: [
								/* @__PURE__ */ g("span", { children: [b(e.owner), (n.autopilot?.[e.owner] ?? 0) > 0 && /* @__PURE__ */ h("small", { children: u("session.autopilot.share", { n: Math.round(n.autopilot[e.owner] * 100) }) })] }),
								/* @__PURE__ */ h("span", { children: u(e.attempts.length === 1 ? "games.soclover.firstPerfect" : "games.soclover.secondCorrect", { n: e.score }) }),
								/* @__PURE__ */ h("b", { children: e.score })
							]
						}, e.owner)), r !== void 0 && /* @__PURE__ */ h("p", { children: u("session.hint.usedCount", { n: r }) })]
					})
				]
			}),
			/* @__PURE__ */ g("footer", {
				className: "sc-final-actions",
				children: [
					/* @__PURE__ */ h("button", {
						type: "button",
						className: "sc-secondary",
						onClick: () => f(!d),
						children: u(d ? "games.soclover.review" : "games.soclover.showScore")
					}),
					i && /* @__PURE__ */ h(y, {
						className: "sc-primary",
						label: u("games.soclover.again"),
						confirmLabel: u("games.soclover.confirmAgain"),
						onConfirm: i
					}),
					s && /* @__PURE__ */ h(y, {
						className: "sc-secondary",
						label: u("games.soclover.lobby"),
						confirmLabel: u("games.soclover.confirmLobby"),
						onConfirm: s
					}),
					!i && !s && /* @__PURE__ */ h("span", { children: u("games.soclover.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/soclover/options.tsx
function $({ value: e, onChange: t }) {
	let n = o(), r = T.safeParse(e), i = r.success ? r.data : T.parse(void 0);
	return /* @__PURE__ */ g("div", { children: [
		/* @__PURE__ */ h("p", { children: n("games.soclover.humanPlayers") }),
		/* @__PURE__ */ h(x, {
			title: n("games.soclover.wordLanguage"),
			columns: 2,
			children: ["zh", "en"].map((e) => /* @__PURE__ */ h(b, {
				name: "soclover-language",
				value: e,
				checked: (i.wordLanguage ?? "en") === e,
				label: n(e === "zh" ? "games.soclover.chineseCards" : "games.soclover.englishCards"),
				accent: C.accent,
				onChange: () => t({
					...i,
					wordLanguage: e
				})
			}, e))
		}),
		/* @__PURE__ */ h(x, {
			title: n("games.soclover.extraCards"),
			columns: 3,
			children: [
				1,
				2,
				3,
				4,
				5
			].map((e) => /* @__PURE__ */ h(b, {
				name: "soclover-extra",
				value: String(e),
				checked: i.extraCards === e,
				label: n(e === 1 ? "games.soclover.extraStandard" : "games.soclover.extraCount", { n: e }),
				accent: C.accent,
				onChange: () => t({
					...i,
					extraCards: e
				})
			}, e))
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/soclover/entry.tsx
var ee = {
	definition: V,
	View: J,
	bot: X,
	fx: Z,
	OverView: Q,
	Options: $,
	locales: {
		zh: {
			name: "密语幸运草",
			desc: "为相邻词语写下共同线索，合作还原每个人的幸运草。可选中文或英文词卡，需要真人参与。",
			rules: "目标：\n3–6 人合作，通过四条线索还原每位玩家的四叶草板，合计得分并挑战团队纪录。开局可选择中文或英文词卡，默认中文。中文词卡从项目公共中文词库抽取不同词语组成 220 张四边词卡，英文使用原版 220 张词卡；所选词库整局固定，切换界面语言不会改变牌面。词语联想需要真人参与，规则机器人不支持本游戏。\n\n准备：\n洗混词卡，每人秘密抽取四张，随机放入四叶草板的四个位置及朝向。每张牌有四个词，外侧的八个词两两相邻，形成上、右、下、左四组。\n\n编写线索：\n所有人同时为自己的四组词各写一个能联系两者的词。线索可以是普通名词、专有名词、缩略词、数字或拟声词，也允许复合词。每条线索只写一个词，不使用空格；复合词可使用连字符。不得直接使用自己的外侧关键词、这些词的翻译或同词族词语，也不得使用虚构词。翻译、词族和词义限制由玩家共同遵守。提交后不能修改；系统将自己的四张词卡取下，盲抽一张干扰牌并混洗。所有人完成后进入合作还原阶段。\n\n合作还原：\n从第一位玩家开始，依座位顺序，每人担任一次旁观者。旁观者不得以任何方式提示、评论或参与讨论。其他玩家根据板上的四条线索，共同将五张候选词卡中的四张放回板上，并调整朝向。可以点选词卡，再在词卡旁旋转、放大查看，或点击板上目标位置摆放；已放置的词卡可以再次选择、移动或取回。有争议时，由旁观者左侧的下一位玩家作最终决定，并提交本次摆放。系统代替旁观者核对答案。\n\n两次核对与计分：\n· 第一次全部四张的位置及朝向正确：每张 1 分，另获 2 分奖励，共 6 分。\n· 第一次有误：移除错误词卡，保留并锁定正确词卡；团队只有一次重新摆放的机会。\n· 第二次核对：每张位置及朝向正确的词卡获得 1 分，共 0–4 分，没有额外奖励。\n每位旁观者完成后显示正确词卡与本轮得分，由其左侧的下一位玩家继续。所有人都担任一次旁观者后，将各轮得分相加。终局可以回看每个人的线索、原布局及两次摆放。\n\n增加难度：\n开局可将每人盲抽的干扰牌从标准的 1 张增加至 2–5 张，整局所有玩家使用相同数量。无论干扰牌多少，每次仍只摆放四张。",
			write: "编写线索",
			readyCount: "{{n}} / {{total}} 人已完成",
			round: "第 {{n}} / {{total}} 块四叶草板",
			points: "{{n}} 分",
			board: "四叶草板",
			boardOf: "{{name}}的四叶草板",
			englishCards: "英文词卡",
			chineseCards: "中文词卡",
			wordLanguage: "本局词库",
			writePrompt: "为四叶草外侧的每组词填写一个线索。",
			waitWriters: "等待其他玩家完成线索。",
			submitted: "已提交",
			writing: "编写中",
			submitClues: "提交四条线索",
			clueSide: "线索 {{n}}",
			slot: "位置 {{n}}",
			locked: "已核对正确",
			inSlot: "位于位置 {{n}}",
			cards: "候选词卡",
			attempt: "第 {{n}} 次摆放",
			chooseCard: "选择词卡，再点击板上的目标位置。",
			chooseSlot: "可以旋转词卡，或点击板上的目标位置。",
			spectator: "你是旁观者，请勿提示或参与讨论。",
			captain: "由{{name}}提交最终摆放",
			rotate: "顺时针旋转",
			inspect: "放大查看词卡",
			remove: "取回词卡",
			cancel: "取消选择",
			close: "关闭",
			check: "核对摆放",
			scored: "本轮获得 {{n}} 分",
			originalLayout: "原布局",
			next: "下一位旁观者",
			finish: "查看团队得分",
			humanPlayers: "本游戏需要 3–6 位真人。",
			extraCards: "每人加入的干扰牌",
			extraStandard: "1 张（标准）",
			extraCount: "{{n}} 张",
			teamScore: "团队得分",
			layout: "查看布局",
			firstPerfect: "首次全部正确，含 2 分奖励",
			secondCorrect: "第二次有 {{n}} 张正确",
			review: "回看四叶草板",
			showScore: "查看得分",
			again: "再来一局",
			lobby: "返回大厅",
			confirmAgain: "开始新的一局？",
			confirmLobby: "返回大厅？",
			waitHost: "等待主机开始新的一局",
			verifiedLayout: "正确词卡已保留，原布局可在终局回看。",
			invalidAction: "当前无法执行此操作，请检查阶段、位置与操作权限。",
			keywordClue: "线索不能直接使用自己四叶草外侧的关键词。"
		},
		en: {
			name: "So Clover!",
			desc: "Link pairs of words with clues, then rebuild each player’s clover together. Chinese or English word cards; human players required.",
			rules: "Goal:\n3–6 players cooperate to rebuild everyone’s clover from four clues. Add the points together and try to beat your team record. Choose Chinese or English word cards before starting; Chinese is the default. Chinese cards use distinct words from the project’s shared Chinese word list to form 220 four-sided cards. English uses the original 220 cards. The deck stays fixed for the entire game, even when the interface language changes. Word association requires human players; rules bots do not support this game.\n\nSetup:\nShuffle the cards. Each player secretly receives four cards in random positions and orientations on a clover board. Every card has four words. The eight words along the outside edges form four pairs: top, right, bottom and left.\n\nChoosing clues:\nEveryone simultaneously writes one word linking each of their four pairs. Common nouns, proper nouns, acronyms, numbers, onomatopoeia and compound words are allowed. Write a single word without spaces; compounds may use hyphens. Your outside keywords, their translations, words from the same family and made-up words are forbidden. Players enforce translation, word-family and meaning restrictions. Submitted clues cannot be changed. Your four cards are removed, one unseen extra card is drawn, and the five cards are shuffled. Resolution starts when everyone is ready.\n\nResolution:\nStarting with the first player and proceeding in seat order, everyone is the Spectator once. The Spectator must not communicate, comment or join the discussion. Everyone else uses the four clues to choose four of the five cards and restore their positions and orientations. Select a card, use its nearby tools to rotate or inspect it, then click a space to place it. Placed cards can be selected again, moved or returned to the tray. In a disagreement, the next player to the Spectator’s left makes the final decision and submits the arrangement. The game checks it on behalf of the Spectator.\n\nTwo attempts and scoring:\n· All four cards correctly placed and oriented on the first attempt: 1 point per card plus a 2-point bonus, for 6 points.\n· Any errors on the first attempt: incorrect cards are removed, correct cards stay and are locked. The team has one final attempt.\n· Second attempt: 1 point per correctly placed and oriented card, for 0–4 points, without a bonus.\nCorrect cards and points are shown after each Spectator’s round. The next player to their left continues. Once everyone has been the Spectator, add all round scores. At the end you can review every player’s clues, original layout and both attempts.\n\nAdd a challenge:\nSettings can increase the unseen extra cards per player from the standard 1 to 2–5. Everyone uses the same number throughout the game. Always place exactly four cards, regardless of the number of extra cards.",
			write: "Choose your clues",
			readyCount: "{{n}} / {{total}} ready",
			round: "Clover {{n}} / {{total}}",
			points: "{{n}} points",
			board: "Clover board",
			boardOf: "{{name}}’s clover",
			englishCards: "English word cards",
			chineseCards: "Chinese word cards",
			wordLanguage: "Word deck",
			writePrompt: "Write one clue for each pair along the outside edges.",
			waitWriters: "Waiting for everyone to finish their clues.",
			submitted: "Submitted",
			writing: "Writing",
			submitClues: "Submit four clues",
			clueSide: "Clue {{n}}",
			slot: "Space {{n}}",
			locked: "Correct and locked",
			inSlot: "In space {{n}}",
			cards: "Candidate cards",
			attempt: "Attempt {{n}}",
			chooseCard: "Select a card, then click its space on the board.",
			chooseSlot: "Rotate this card, or click a space on the board.",
			spectator: "You are the Spectator. Do not give hints or join the discussion.",
			captain: "{{name}} submits the final layout",
			rotate: "Rotate clockwise",
			inspect: "Inspect card",
			remove: "Return card to tray",
			cancel: "Cancel selection",
			close: "Close",
			check: "Check arrangement",
			scored: "{{n}} points this round",
			originalLayout: "Original layout",
			next: "Next Spectator",
			finish: "View team score",
			humanPlayers: "Requires 3–6 human players.",
			extraCards: "Extra cards per player",
			extraStandard: "1 (standard)",
			extraCount: "{{n}} cards",
			teamScore: "Team score",
			layout: "Layout",
			firstPerfect: "Perfect first attempt, including 2 bonus points",
			secondCorrect: "{{n}} correct on the second attempt",
			review: "Review clovers",
			showScore: "Show score",
			again: "Play again",
			lobby: "Back to lobby",
			confirmAgain: "Start a new game?",
			confirmLobby: "Return to lobby?",
			waitHost: "Waiting for the host to start again",
			verifiedLayout: "Correct cards remain. Review the original at the end.",
			invalidAction: "This action is unavailable. Check the phase, space and player permissions.",
			keywordClue: "A clue cannot be one of your outside keywords."
		}
	}
};
//#endregion
export { ee as default };
