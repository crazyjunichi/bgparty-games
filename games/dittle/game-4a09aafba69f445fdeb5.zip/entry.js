import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { useWakeLock as l } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { seatName as d } from "@bgparty/sdk/ui/player-strip";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { IconEye as h } from "@bgparty/sdk/icons";
import { OptionRadio as g, OptionSection as _ } from "@bgparty/sdk/ui/game-options";
//#region src/games/dittle/board.ts
var v = (e) => Math.floor(e / 7), y = (e) => e % 7, b = (e) => e === 0 ? 0 : 6, x = (e) => v(e.at) === b(e.owner), S = (e) => `${"ABCDEFG"[y(e)]}${7 - v(e)}`;
function C(e, t) {
	return t === "forward" ? [0, e === 0 ? -1 : 1] : [t === "left" ? -1 : 1, 0];
}
function w(e, t, n) {
	let r = y(e) + t, i = v(e) + n;
	return r >= 0 && r < 7 && i >= 0 && i < 7 ? i * 7 + r : null;
}
function T(e, t, n) {
	return n < 0 ? {
		...e,
		top: 7 - e.north,
		north: e.top
	} : n > 0 ? {
		...e,
		top: e.north,
		north: 7 - e.top
	} : t < 0 ? {
		...e,
		top: e.east,
		east: 7 - e.top
	} : {
		...e,
		top: 7 - e.east,
		east: e.top
	};
}
function E(e, t) {
	let n = { ...e };
	if (t.tilt) {
		let [r, i] = C(e.owner, t.tilt);
		n = {
			...T(n, r, i),
			at: w(n.at, r, i)
		};
	}
	return t.jumps.length && (n.at = t.jumps[t.jumps.length - 1]), n;
}
function D(e, t) {
	return {
		...t.tilt ? T(e, ...C(e.owner, t.tilt)) : e,
		at: t.at
	};
}
function O(e, t, n, r) {
	let i = new Set(e.map((e) => e.at)), a = [];
	for (let o of e.filter((e) => e.owner === t && (!r || e.id === r.die))) for (let e of [
		"forward",
		"left",
		"right"
	]) {
		let [s, c] = C(t, e), l = w(o.at, s, c);
		if (!r && l !== null && !i.has(l) && a.push({
			type: "step",
			die: o.id,
			at: l,
			tilt: e
		}), n || l === null || !i.has(l) || r && !r.tilted && r.axis === "vertical" != (e === "forward")) continue;
		let u = w(o.at, s * 2, c * 2);
		u !== null && !i.has(u) && !r?.visited.includes(u) && a.push({
			type: "step",
			die: o.id,
			at: u,
			tilt: null
		});
	}
	return a;
}
function k(e, t, n) {
	let r = new Set(e.map((e) => e.at)), i = [], a = [
		"forward",
		"left",
		"right"
	];
	for (let o of e.filter((e) => e.owner === t)) {
		let e = new Set(r);
		e.delete(o.at);
		let s = [{
			at: o.at,
			tilt: null
		}];
		for (let n of a) {
			let [r, a] = C(t, n), c = w(o.at, r, a);
			c === null || e.has(c) || (i.push({
				type: "move",
				die: o.id,
				tilt: n,
				jumps: []
			}), s.push({
				at: c,
				tilt: n
			}));
		}
		if (!n) for (let n of s) {
			let r = n.tilt ? ["mixed"] : ["vertical", "horizontal"];
			for (let s of r) {
				let r = /* @__PURE__ */ new Set([o.at, n.at]), c = [{
					at: n.at,
					path: []
				}];
				for (let l = 0; l < c.length; l++) {
					let u = c[l];
					for (let l of a) {
						if (s === "vertical" && l !== "forward" || s === "horizontal" && l === "forward") continue;
						let [a, d] = C(t, l), f = w(u.at, a, d), p = w(u.at, a * 2, d * 2);
						if (f === null || p === null || !e.has(f) || e.has(p) || r.has(p)) continue;
						r.add(p);
						let m = [...u.path, p];
						i.push({
							type: "move",
							die: o.id,
							tilt: n.tilt,
							jumps: m
						}), c.push({
							at: p,
							path: m
						});
					}
				}
			}
		}
	}
	return i;
}
function A(e) {
	let t = /* @__PURE__ */ new Set(), n = e.map((t) => ({
		die: t,
		enemies: e.filter((e) => e.owner !== t.owner && Math.abs(v(e.at) - v(t.at)) + Math.abs(y(e.at) - y(t.at)) === 1)
	})), r = /* @__PURE__ */ new Set(), i = (e, t) => [e, t].sort((e, t) => e - t).join(":"), a = (e, n) => {
		let r = n.reduce((e, t) => e + t.top, 0);
		if (e.top <= r && t.add(e.id), e.top >= r) for (let e of n) t.add(e.id);
	};
	for (let { die: e, enemies: t } of n.filter((e) => e.enemies.length >= 2)) {
		a(e, t);
		for (let n of t) r.add(i(e.id, n.id));
	}
	for (let { die: e, enemies: t } of n) t.length === 1 && !r.has(i(e.id, t[0].id)) && a(e, t);
	return e.filter((e) => t.has(e.id));
}
//#endregion
//#region src/games/dittle/meta.ts
var j = {
	id: "dittle",
	tier: "alpha",
	mechanics: ["grid-movement", "race"],
	interactionTags: [],
	nameKey: "games.dittle.name",
	descKey: "games.dittle.desc",
	rulesKey: "games.dittle.rules",
	icon: "🎲",
	iconImg: "games/dittle.webp",
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#8c432e",
	releasedAt: "2026-11-02T19:09:00+08:00",
	rulesUrl: { en: "https://images.thdstatic.com/catalog/pdfImages/7c/7c6a22a5cf90448088f971028622e237.pdf" },
	search: {
		py: "",
		init: ""
	},
	hotseat: "open"
}, M = t.int().min(1).max(6), N = t.int().min(0).max(48), P = t.enum([
	"forward",
	"left",
	"right"
]), F = t.object({ clash: t.boolean().default(!1) }).default({ clash: !1 }), I = t.object({
	type: t.literal("move"),
	die: t.int().min(0).max(13),
	tilt: P.nullable(),
	jumps: t.array(N).max(24)
}), L = t.object({
	type: t.literal("step"),
	die: t.int().min(0).max(13),
	at: N,
	tilt: P.nullable()
}), R = t.discriminatedUnion("type", [
	I,
	L,
	t.object({ type: t.literal("finish") }),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), ee = t.object({
	id: t.int().min(0).max(13),
	owner: t.int().min(0).max(1),
	at: N,
	top: M,
	north: M,
	east: M
}), z = t.object({
	players: t.array(t.string()).length(2),
	active: t.int().min(0).max(1),
	turn: t.int().positive(),
	clash: t.boolean(),
	phase: t.enum([
		"play",
		"moving",
		"clash",
		"done"
	]),
	dice: t.array(ee).max(14),
	scores: t.array(t.int().min(0).max(42)).length(2),
	arrived: t.array(t.int().min(0).max(7)).length(2),
	toss: t.array(t.array(M).length(2)).length(2),
	winners: t.array(t.int().min(0).max(1)).max(2),
	reason: t.enum([
		"crossed",
		"eliminated",
		"blocked",
		"repetition"
	]).nullable(),
	moves: t.array(I),
	canPass: t.boolean(),
	steps: t.array(L),
	chainDie: t.int().min(0).max(13).nullable(),
	canFinish: t.boolean()
}), B = t.object({}), V = (e) => JSON.stringify([e.active, e.dice.map((e) => [
	e.id,
	e.at,
	e.top,
	e.north,
	e.east
])]), H = (e) => [0, 1].map((t) => e.filter((e) => e.owner === t && x(e)).reduce((e, t) => e + t.top, 0)), U = (e) => [0, 1].map((t) => e.filter((e) => e.owner === t && x(e)).length);
function W(e, t, n) {
	e.phase = "done", e.reason = t;
	let r = H(e.dice);
	e.winners = n === void 0 ? t === "repetition" || r[0] === r[1] ? [0, 1] : [r[0] > r[1] ? 0 : 1] : [n];
}
function G(e) {
	e.chain = null;
	let t = U(e.dice);
	if (e.clash) {
		let t = e.dice.find((e) => x(e));
		if (t) {
			W(e, "crossed", t.owner);
			return;
		}
		let n = [0, 1].map((t) => e.dice.some((e) => e.owner === t));
		if (!n[0] || !n[1]) {
			W(e, "eliminated", n[0] ? 0 : n[1] ? 1 : void 0);
			return;
		}
	} else if (t.includes(7)) {
		W(e, "crossed");
		return;
	}
	if (e.passes >= 2) {
		W(e, "blocked");
		return;
	}
	e.active = 1 - e.active, e.turn++, e.phase = "play";
	let n = V(e);
	e.seen[n] = (e.seen[n] ?? 0) + 1, e.seen[n] >= 3 && W(e, "repetition");
}
function K(e) {
	let t = e.pending.shift(), n = e.dice.findIndex((e) => e.id === t.die), r = { ...e.dice[n] }, i = t.tilt ? T(r, ...C(r.owner, t.tilt)) : { ...r };
	return i.at = t.at, e.dice[n] = i, [{
		kind: "dittleMove",
		data: {
			before: r,
			after: i,
			tilt: t.tilt !== null
		}
	}];
}
function q(t, n, r) {
	let { clash: i } = F.parse(t), a = 0, o;
	do
		o = [0, 1].map(() => [e(r, a++, 6) + 1, e(r, a++, 6) + 1]);
	while (o[0][0] + o[0][1] === o[1][0] + o[1][1]);
	let s = o[0][0] + o[0][1] > o[1][0] + o[1][1] ? 0 : 1, c = Array.from({ length: 14 }, (e, t) => {
		let n = t < 7 ? 0 : 1;
		return {
			id: t,
			owner: n,
			at: n === 0 ? 42 + t : t - 7,
			top: 6,
			north: n === 0 ? 4 : 3,
			east: n === 0 ? 2 : 5
		};
	}), l = {
		players: [...n],
		dice: c,
		active: s,
		turn: 1,
		clash: i,
		toss: o,
		phase: "play",
		winners: [],
		reason: null,
		pending: [],
		passes: 0,
		seen: {},
		chain: null
	};
	return l.seen[V(l)] = 1, { state: l };
}
function J(e, t, { by: n }) {
	let r = () => ({ code: "games.dittle.invalid" });
	if (e.phase === "done") return r();
	if (t.type === "tick") {
		if (n !== "$engine" || e.phase === "play") return r();
		let t = structuredClone(e);
		if (t.pending.length) return {
			state: t,
			fx: K(t)
		};
		if (t.phase === "moving" && t.clash) {
			let e = A(t.dice);
			if (e.length) return t.dice = t.dice.filter((t) => !e.some((e) => e.id === t.id)), t.phase = "clash", {
				state: t,
				fx: [{
					kind: "dittleClash",
					data: { dice: e }
				}]
			};
		}
		return t.chain && !U(t.dice).includes(7) && O(t.dice, t.active, t.clash, t.chain).length ? t.phase = "play" : G(t), { state: t };
	}
	if (e.phase !== "play" || e.players[e.active] !== n) return r();
	let i = k(e.dice, e.active, e.clash), a = structuredClone(e);
	if (t.type === "finish") return a.chain ? (G(a), { state: a }) : r();
	if (t.type === "step") {
		let n = O(e.dice, e.active, e.clash, e.chain).find((e) => e.die === t.die && e.at === t.at && e.tilt === t.tilt);
		if (!n) return r();
		let i = a.dice.find((e) => e.id === n.die);
		return a.clash || (a.chain ||= {
			die: i.id,
			tilted: n.tilt !== null,
			axis: n.tilt ? null : v(n.at) === v(i.at) ? "horizontal" : "vertical",
			visited: [i.at]
		}, a.chain.visited.push(n.at)), a.passes = 0, a.pending.push(n), a.phase = "moving", {
			state: a,
			fx: K(a)
		};
	}
	if (t.type === "pass") return a.chain || i.length ? r() : (a.passes++, G(a), { state: a });
	if (a.chain) return r();
	let o = i.find((e) => e.die === t.die && e.tilt === t.tilt && e.jumps.length === t.jumps.length && e.jumps.every((e, n) => e === t.jumps[n]));
	if (!o) return r();
	a.passes = 0;
	let s = a.dice.find((e) => e.id === o.die);
	o.tilt && a.pending.push({
		die: s.id,
		at: w(s.at, ...C(s.owner, o.tilt)),
		tilt: o.tilt
	});
	for (let e of o.jumps) a.pending.push({
		die: s.id,
		at: e,
		tilt: null
	});
	return a.phase = "moving", {
		state: a,
		fx: K(a)
	};
}
var Y = {
	meta: j,
	saveCompatibility: { version: "1" },
	schemas: {
		action: R,
		publicView: z,
		privateView: B,
		config: F
	},
	setup: q,
	reduce: J,
	nextTickIn: (e) => e.phase === "moving" ? 280 : e.phase === "clash" ? 320 : null,
	viewFor(e, t) {
		let n = e.phase === "play" && e.players[e.active] === t, r = n && !e.chain ? k(e.dice, e.active, e.clash) : [], i = n ? O(e.dice, e.active, e.clash, e.chain) : [];
		return {
			public: {
				players: e.players,
				dice: e.dice,
				active: e.active,
				turn: e.turn,
				clash: e.clash,
				phase: e.phase,
				toss: e.toss,
				winners: e.winners,
				reason: e.reason,
				scores: H(e.dice),
				arrived: U(e.dice),
				moves: r,
				steps: i,
				chainDie: e.chain?.die ?? null,
				canFinish: n && !!e.chain,
				canPass: n && !e.chain && !r.length
			},
			private: {}
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: e.winners.map((t) => e.players[t]),
			ranking: [...e.winners, ...[0, 1].filter((t) => !e.winners.includes(t))].map((t) => e.players[t]),
			scores: Object.fromEntries(e.players.map((t, n) => [t, e.clash ? Number(e.winners.includes(n) && e.winners.length === 1) : H(e.dice)[n]]))
		} : { phase: e.phase };
	}
}, X = {
	1: [[50, 50]],
	2: [[27, 27], [73, 73]],
	3: [
		[27, 27],
		[50, 50],
		[73, 73]
	],
	4: [
		[27, 27],
		[73, 27],
		[27, 73],
		[73, 73]
	],
	5: [
		[27, 27],
		[73, 27],
		[50, 50],
		[27, 73],
		[73, 73]
	],
	6: [
		[27, 24],
		[73, 24],
		[27, 50],
		[73, 50],
		[27, 76],
		[73, 76]
	]
};
function Z({ n: e, transform: t, color: n }) {
	return /* @__PURE__ */ p("g", {
		transform: t,
		fill: n,
		children: X[e].map(([e, t], n) => /* @__PURE__ */ p("circle", {
			cx: e,
			cy: t,
			r: "7.2"
		}, n))
	});
}
function Q({ die: e, className: t = "" }) {
	let n = r(), i = e.owner === 1, a = i ? "#eee9dc" : "#252721";
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 100 100",
		className: `dittle-die ${t}`,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ p("defs", { children: /* @__PURE__ */ m("linearGradient", {
				id: n,
				x1: "0",
				y1: "0",
				x2: "1",
				y2: "1",
				children: [/* @__PURE__ */ p("stop", { stopColor: i ? "#484d46" : "#fffdf2" }), /* @__PURE__ */ p("stop", {
					offset: "1",
					stopColor: i ? "#262e27" : "#eae4d5"
				})]
			}) }),
			/* @__PURE__ */ p("path", {
				d: "M19 7H75Q82 7 85 10L89 15Q90.5 17 90.5 23V81Q90.5 90 81 90H24Q17 90 14 87L11 83Q9 81 9 74V17Q9 7 19 7Z",
				fill: i ? "#20271f" : "#bdb49e",
				stroke: i ? "#656d5c" : "#d7cebb",
				strokeWidth: ".9"
			}),
			/* @__PURE__ */ m("g", {
				transform: "matrix(.055 .07 0 .76 85 7)",
				children: [/* @__PURE__ */ p("rect", {
					width: "100",
					height: "100",
					rx: "12",
					fill: i ? "#1c241d" : "#c9bea6"
				}), /* @__PURE__ */ p(Z, {
					n: e.east,
					transform: "",
					color: a
				})]
			}),
			/* @__PURE__ */ m("g", {
				transform: "matrix(.76 0 .055 .07 9 83)",
				children: [/* @__PURE__ */ p("rect", {
					width: "100",
					height: "100",
					rx: "12",
					fill: i ? "#30392d" : "#dfd5bf"
				}), /* @__PURE__ */ p(Z, {
					n: 7 - e.north,
					transform: "",
					color: a
				})]
			}),
			/* @__PURE__ */ m("g", {
				transform: "matrix(.76 0 0 .76 9 7)",
				children: [/* @__PURE__ */ p("rect", {
					width: "100",
					height: "100",
					rx: "13",
					fill: `url(#${n})`,
					stroke: i ? "#737b68" : "#fffbed",
					strokeWidth: "1.7"
				}), /* @__PURE__ */ p(Z, {
					n: e.top,
					transform: "",
					color: a
				})]
			})
		]
	});
}
//#endregion
//#region src/games/dittle/view-player.tsx
function te({ at: e, die: t, selected: n, outcomes: r, source: i, onSelect: a, onMove: s }) {
	let l = c(), { ref: u } = o(`dittle-square:${e}`), { ref: d, hidden: h } = o(t ? `dittle-die:${t.id}` : null);
	return /* @__PURE__ */ m("div", {
		ref: u,
		className: "dittle-square",
		"data-selected": n,
		"data-goal": v(e) === 0 || v(e) === 6,
		children: [
			y(e) === 0 && /* @__PURE__ */ p("span", {
				className: "dittle-row-coordinate",
				children: 7 - v(e)
			}),
			v(e) === 6 && /* @__PURE__ */ p("span", {
				className: "dittle-column-coordinate",
				children: "ABCDEFG"[y(e)]
			}),
			!r.length && /* @__PURE__ */ p("button", {
				className: "dittle-square-hit",
				type: "button",
				onClick: a,
				"aria-label": t ? l("games.dittle.die", {
					color: l(t.owner === 0 ? "games.dittle.white" : "games.dittle.black"),
					square: S(e),
					n: t.top
				}) : l("games.dittle.destination", { square: S(e) }),
				"aria-pressed": n,
				children: t && /* @__PURE__ */ p("span", {
					ref: d,
					className: "dittle-piece",
					style: { visibility: h ? "hidden" : void 0 },
					children: /* @__PURE__ */ p(Q, { die: t })
				})
			}),
			!!r.length && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("svg", {
				viewBox: "0 0 100 100",
				className: "dittle-target",
				"aria-hidden": "true",
				children: /* @__PURE__ */ p("rect", {
					x: "4",
					y: "4",
					width: "92",
					height: "92",
					rx: "10"
				})
			}), /* @__PURE__ */ p("div", {
				className: "dittle-destinations",
				"data-count": r.length,
				children: r.map(({ move: t, die: n }, r) => /* @__PURE__ */ p("button", {
					className: "dittle-destination",
					type: "button",
					onClick: () => s(t),
					"aria-label": l("games.dittle.move", {
						from: S(i.at),
						to: S(e),
						n: n.top
					}),
					children: /* @__PURE__ */ p(Q, { die: n })
				}, r))
			})] })
		]
	});
}
function $({ public: e, members: t, myRid: n, send: r }) {
	l();
	let i = e, o = c(), h = s((e) => e.locale), [g, _] = a(null), v = i.chainDie === null ? g?.turn === i.turn ? i.dice.find((e) => e.id === g.die) : void 0 : i.dice.find((e) => e.id === i.chainDie), y = i.phase === "play" && i.players[i.active] === n, b = v && y ? i.steps.filter((e) => e.die === v.id) : [], x = b.map((e) => ({
		move: e,
		die: D(v, e)
	})), C = (e) => {
		let n = t.find((t) => t.rid === i.players[e]);
		return n ? d(n, h) : i.players[e];
	}, w = i.phase === "done" ? o("games.dittle.result") : i.phase === "moving" ? o("games.dittle.moving") : i.phase === "clash" ? o("games.dittle.clashing") : y ? o("games.dittle.yours") : o("games.dittle.waiting", { name: C(i.active) });
	function T(e) {
		if (i.chainDie !== null) return;
		let t = i.dice.find((t) => t.at === e);
		_(t && t.id !== v?.id ? {
			turn: i.turn,
			die: t.id
		} : null);
	}
	let E = i.clash ? "games.dittle.clash" : "games.dittle.battle";
	function O(e) {
		y && b.includes(e) && (_(null), r(e));
	}
	return /* @__PURE__ */ p(u, {
		adaptive: !0,
		scroll: !1,
		className: "dittle-screen",
		banner: /* @__PURE__ */ m("header", {
			className: "dittle-header",
			children: [
				/* @__PURE__ */ p("h1", { children: o("games.dittle.name") }),
				/* @__PURE__ */ m("span", { children: [
					o(E),
					" · ",
					o("games.dittle.turn", { n: i.turn })
				] }),
				/* @__PURE__ */ p("strong", {
					role: "status",
					children: w
				})
			]
		}),
		children: /* @__PURE__ */ m("div", {
			className: "dittle-layout",
			children: [/* @__PURE__ */ p("div", {
				className: "dittle-board-stage",
				children: /* @__PURE__ */ p("div", {
					className: "dittle-board",
					children: /* @__PURE__ */ p("div", {
						className: "dittle-grid",
						children: Array.from({ length: 49 }, (e, t) => /* @__PURE__ */ p(te, {
							at: t,
							die: i.dice.find((e) => e.at === t),
							selected: v?.at === t,
							source: v,
							outcomes: x.filter((e) => e.die.at === t),
							onSelect: () => T(t),
							onMove: O
						}, t))
					})
				})
			}), /* @__PURE__ */ m("aside", {
				className: "dittle-sidebar",
				children: [
					/* @__PURE__ */ p("div", {
						className: "dittle-players",
						children: [0, 1].map((e) => /* @__PURE__ */ m("section", {
							className: "dittle-player",
							"data-active": i.active === e && i.phase !== "done",
							children: [
								/* @__PURE__ */ p(Q, { die: {
									owner: e,
									top: 6,
									north: e === 0 ? 4 : 3,
									east: e === 0 ? 2 : 5
								} }),
								/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ m("strong", { children: [C(e), i.players[e] === n && /* @__PURE__ */ m("small", { children: [" · ", o("games.dittle.you")] })] }), /* @__PURE__ */ m("span", { children: [
									o(e === 0 ? "games.dittle.white" : "games.dittle.black"),
									" · ",
									o(i.clash ? "games.dittle.remaining" : "games.dittle.arrived", { n: i.clash ? i.dice.filter((t) => t.owner === e).length : i.arrived[e] })
								] })] }),
								!i.clash && /* @__PURE__ */ p("b", {
									"aria-label": o("games.dittle.score"),
									children: i.scores[e]
								})
							]
						}, e))
					}),
					/* @__PURE__ */ p("div", {
						className: "dittle-inspector",
						children: v ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("div", {
							className: "dittle-inspect-dice",
							children: /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Q, { die: v }), /* @__PURE__ */ m("span", { children: [
								S(v.at),
								" · ",
								o("games.dittle.top", { n: v.top })
							] })] })
						}), /* @__PURE__ */ m("p", { children: [
							o("games.dittle.north", { n: v.north }),
							" · ",
							o("games.dittle.east", { n: v.east })
						] })] }) : /* @__PURE__ */ p("div", {
							className: "dittle-inspect-empty",
							children: /* @__PURE__ */ p(Q, { die: {
								owner: i.active,
								top: 6,
								north: 4,
								east: 2
							} })
						})
					}),
					/* @__PURE__ */ m("div", {
						className: "dittle-controls",
						children: [i.phase !== "done" && /* @__PURE__ */ p("span", {
							className: "dittle-instruction",
							children: y ? i.canFinish ? o("games.dittle.continueJump") : v?.owner === i.active ? o("games.dittle.target") : o("games.dittle.select") : ""
						}), y && i.canFinish ? /* @__PURE__ */ p("button", {
							className: "dittle-confirm",
							type: "button",
							onClick: () => {
								_(null), r({ type: "finish" });
							},
							children: o("games.dittle.finish")
						}) : y && i.canPass ? /* @__PURE__ */ p("button", {
							className: "dittle-confirm",
							type: "button",
							onClick: () => r({ type: "pass" }),
							children: o("games.dittle.pass")
						}) : /* @__PURE__ */ p("button", {
							className: "dittle-cancel",
							type: "button",
							disabled: !v || i.chainDie !== null,
							onClick: () => _(null),
							children: o("games.dittle.cancel")
						})]
					}),
					i.turn === 1 && !v && /* @__PURE__ */ m("div", {
						className: "dittle-toss",
						children: [/* @__PURE__ */ p("span", { children: o("games.dittle.toss") }), [0, 1].map((e) => /* @__PURE__ */ m("span", { children: [
							o(e === 0 ? "games.dittle.white" : "games.dittle.black"),
							" ",
							i.toss[e].join(" + "),
							" = ",
							i.toss[e][0] + i.toss[e][1]
						] }, e))]
					})
				]
			})]
		})
	});
}
//#endregion
//#region src/games/dittle/bot.ts
var ne = {
	progress: 4,
	top: .6,
	score: 12,
	material: 20,
	repetition: 30
};
function re(e = ne) {
	return ({ public: t }, n) => {
		if (t.phase !== "play" || t.players[t.active] !== n.rid) return null;
		if (t.canPass) return { action: { type: "pass" } };
		let r = t.canFinish ? [{ type: "finish" }, ...t.steps] : t.moves;
		if (!r.length) return null;
		if (n.difficulty === "weak") {
			let e = Math.floor(4294967296 / r.length) * r.length, t;
			do
				t = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
			while (t >= e);
			return { action: r[t % r.length] };
		}
		let i = { ...n.memory?.positions }, a = JSON.stringify(t.dice.map((e) => [
			e.id,
			e.at,
			e.top,
			e.north,
			e.east
		]));
		i[a] = (i[a] ?? 0) + 1;
		let o = r[0], s = -Infinity;
		for (let n of r) {
			let r = n.type === "move" || n.type === "step" ? t.dice.find((e) => e.id === n.die) : null, a = r && (n.type === "move" ? E(r, n) : n.type === "step" ? D(r, n) : null), c = a ? t.dice.map((e) => e.id === a.id ? a : e) : t.dice;
			if (t.clash) {
				let e = A(c);
				c = c.filter((t) => !e.some((e) => e.id === t.id));
			}
			let l = 0, u = [0, 0], d = [0, 0];
			for (let n of c) {
				let r = n.owner === t.active ? 1 : -1, i = n.owner === 0 ? 6 - v(n.at) : v(n.at);
				l += r * (e.progress * i + e.top * n.top + (t.clash ? e.material : 0)), x(n) && (u[n.owner] += n.top, d[n.owner]++, l += r * (t.clash ? 1e5 : e.score * n.top));
			}
			t.clash && !c.some((e) => e.owner === 1 - t.active) && (l += 1e5), t.clash && !c.some((e) => e.owner === t.active) && (l -= 1e5), !t.clash && d.includes(7) && (l += Math.sign(u[t.active] - u[1 - t.active]) * 1e5), l -= e.repetition * (i[JSON.stringify(c.map((e) => [
				e.id,
				e.at,
				e.top,
				e.north,
				e.east
			]))] ?? 0), l > s && (s = l, o = n);
		}
		return {
			action: o,
			memory: { positions: i }
		};
	};
}
var ie = re(), ae = (e, t, n) => {
	if (e.type !== "move" && e.type !== "step") return e.type === "pass" ? n("games.dittle.pass") : e.type === "finish" ? n("games.dittle.finish") : "";
	let r = t.public.dice.find((t) => t.id === e.die);
	if (!r) return "";
	let i = e.type === "move" ? E(r, e) : D(r, e);
	return n("games.dittle.move", {
		from: S(r.at),
		to: S(i.at),
		n: i.top
	});
};
//#endregion
//#region src/games/dittle/fx.tsx
function oe({ from: e, to: t, before: r, after: a, tilt: o }) {
	let s = i(null), c = i(null), l = i(null);
	return n(() => {
		let n = t.x - e.x, r = t.y - e.y, i = Math.abs(n) > Math.abs(r) ? "Y" : "X", a = (i === "Y" ? n : -r) > 0 ? 1 : -1, u = [s.current.animate([
			{ transform: "translate(0,0)" },
			{ transform: `translate(${n / 2}px,${r / 2 - (o ? 0 : e.h * .35)}px)` },
			{ transform: `translate(${n}px,${r}px)` }
		], {
			duration: 280,
			fill: "forwards",
			easing: "ease-in-out"
		})];
		return o && (u.push(c.current.animate([
			{
				transform: `rotate${i}(0deg)`,
				opacity: 1
			},
			{
				transform: `rotate${i}(${a * 90}deg)`,
				opacity: 0,
				offset: .5
			},
			{ opacity: 0 }
		], {
			duration: 280,
			fill: "forwards"
		})), u.push(l.current.animate([
			{
				transform: `rotate${i}(${-a * 90}deg)`,
				opacity: 0
			},
			{
				transform: `rotate${i}(${-a * 90}deg)`,
				opacity: 0,
				offset: .5
			},
			{
				transform: `rotate${i}(0deg)`,
				opacity: 1
			}
		], {
			duration: 280,
			fill: "forwards"
		}))), () => u.forEach((e) => e.cancel());
	}, [
		e,
		t,
		r,
		a,
		o
	]), /* @__PURE__ */ m("div", {
		ref: s,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			perspective: "500px"
		},
		children: [/* @__PURE__ */ p("div", {
			ref: c,
			style: {
				position: "absolute",
				inset: 0
			},
			children: /* @__PURE__ */ p(Q, { die: r })
		}), o && /* @__PURE__ */ p("div", {
			ref: l,
			style: {
				position: "absolute",
				inset: 0,
				opacity: 0
			},
			children: /* @__PURE__ */ p(Q, { die: a })
		})]
	});
}
function se({ box: e, die: t }) {
	let r = i(null);
	return n(() => {
		let e = r.current.animate([
			{
				transform: "scale(1)",
				opacity: 1
			},
			{
				transform: "scale(1.14)",
				opacity: .9,
				offset: .25
			},
			{
				transform: "scale(.2)",
				opacity: 0
			}
		], {
			duration: 320,
			fill: "forwards",
			easing: "ease-in"
		});
		return () => e.cancel();
	}, []), /* @__PURE__ */ p("div", {
		ref: r,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ p(Q, { die: t })
	});
}
var ce = {
	dittleMove(e, t) {
		let n = e.data, r = t.anchor(`dittle-square:${n.before.at}`), i = t.anchor(`dittle-square:${n.after.at}`);
		return !r || !i ? null : {
			ms: 280,
			hide: t.queued ? [] : [`dittle-die:${n.after.id}`],
			node: /* @__PURE__ */ p(oe, {
				from: r,
				to: i,
				...n
			})
		};
	},
	dittleClash(e, t) {
		return {
			ms: 320,
			node: e.data.dice.map((e) => {
				let n = t.anchor(`dittle-square:${e.at}`);
				return n ? /* @__PURE__ */ p(se, {
					box: n,
					die: e
				}, e.id) : null;
			})
		};
	}
};
//#endregion
//#region src/games/dittle/game-over.tsx
function le({ public: e, members: t, myRid: r, result: i, hintCount: o, onPlayAgain: l, onBackToLobby: u }) {
	let g = e, _ = c(), v = s((e) => e.locale), [y, b] = a(!0), [C, w] = a(null);
	n(() => {
		if (!C) return;
		let e = setTimeout(() => w(null), 3e3);
		return () => clearTimeout(e);
	}, [C]);
	let T = (e) => {
		let n = t.find((t) => t.rid === g.players[e]);
		return n ? d(n, v) : g.players[e];
	}, E = g.reason === "eliminated" ? "games.dittle.endingEliminated" : g.reason === "blocked" ? "games.dittle.endingBlocked" : g.reason === "repetition" ? "games.dittle.endingRepetition" : "games.dittle.endingCrossed", D = [0, 1].map((e) => g.dice.filter((t) => t.owner === e && x(t)).sort((e, t) => e.at - t.at));
	return /* @__PURE__ */ m("div", {
		className: "dittle-result-root",
		children: [
			/* @__PURE__ */ p("div", {
				style: { height: "100%" },
				inert: y,
				children: /* @__PURE__ */ p($, {
					public: g,
					members: t,
					myRid: r,
					send: () => void 0
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "dittle-result-shade",
				hidden: !y,
				children: /* @__PURE__ */ m("section", {
					className: "dittle-result-panel",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": _("games.dittle.result"),
					children: [
						/* @__PURE__ */ m("header", {
							className: "dittle-result-heading",
							children: [/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("h1", { children: g.winners.length === 1 ? _("games.dittle.won", { name: T(g.winners[0]) }) : _("games.dittle.draw") }), /* @__PURE__ */ p("p", { children: _(E) })] }), /* @__PURE__ */ p("button", {
								type: "button",
								className: "dittle-cancel",
								"aria-label": _("games.dittle.review"),
								onClick: () => {
									w(null), b(!1);
								},
								children: /* @__PURE__ */ p(h, { size: 22 })
							})]
						}),
						/* @__PURE__ */ m("div", {
							className: "dittle-result-scroll",
							children: [
								/* @__PURE__ */ m("table", {
									className: "dittle-score-table",
									children: [/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { children: _(g.clash ? "games.dittle.clash" : "games.dittle.score") }), [0, 1].map((e) => /* @__PURE__ */ m("th", { children: [T(e), /* @__PURE__ */ p("small", {
										style: {
											display: "block",
											fontWeight: 400
										},
										children: _(e === 0 ? "games.dittle.white" : "games.dittle.black")
									})] }, e))] }) }), /* @__PURE__ */ p("tbody", { children: g.clash ? /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { children: _("games.dittle.remainingLabel") }), [0, 1].map((e) => /* @__PURE__ */ p("td", {
										className: "dittle-score-total",
										children: g.dice.filter((t) => t.owner === e).length
									}, e))] }) : /* @__PURE__ */ m(f, { children: [Array.from({ length: Math.max(...D.map((e) => e.length)) }, (e, t) => /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { children: t + 1 }), [0, 1].map((e) => /* @__PURE__ */ p("td", { children: D[e][t] ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(Q, { die: D[e][t] }), /* @__PURE__ */ m("small", { children: [
										S(D[e][t].at),
										" · ",
										D[e][t].top
									] })] }) : "—" }, e))] }, t)), /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { children: _("games.dittle.total") }), [0, 1].map((e) => /* @__PURE__ */ p("td", {
										className: "dittle-score-total",
										children: g.scores[e]
									}, e))] })] }) })]
								}),
								o !== void 0 && /* @__PURE__ */ p("p", {
									className: "dittle-result-extra",
									children: _("session.hint.usedCount", { n: o })
								}),
								g.players.map((e, t) => i.autopilot?.[e] ? /* @__PURE__ */ m("p", {
									className: "dittle-result-extra",
									children: [
										T(t),
										" · ",
										_("session.autopilot.share", { n: Math.round(i.autopilot[e] * 100) })
									]
								}, e) : null)
							]
						}),
						l || u ? /* @__PURE__ */ m("footer", {
							className: "dittle-result-actions",
							children: [
								l && /* @__PURE__ */ p("button", {
									className: "dittle-confirm",
									"data-armed": C === "again",
									type: "button",
									onBlur: () => w(null),
									onClick: () => C === "again" ? l() : w("again"),
									children: _(C === "again" ? "games.dittle.againConfirm" : "session.result.playAgain")
								}),
								u && /* @__PURE__ */ p("button", {
									className: "dittle-cancel",
									"data-armed": C === "lobby",
									type: "button",
									onBlur: () => w(null),
									onClick: () => C === "lobby" ? u() : w("lobby"),
									children: _(C === "lobby" ? "games.dittle.lobbyConfirm" : "session.result.backToLobby")
								}),
								C && /* @__PURE__ */ p("button", {
									className: "dittle-cancel",
									type: "button",
									onClick: () => w(null),
									children: _("games.dittle.cancelConfirm")
								})
							]
						}) : /* @__PURE__ */ p("p", {
							className: "dittle-result-extra",
							children: _("session.result.waitHost")
						})
					]
				})
			}),
			!y && /* @__PURE__ */ p("button", {
				className: "dittle-result-restore dittle-confirm",
				type: "button",
				onClick: () => b(!0),
				children: _("games.dittle.closeReview")
			})
		]
	});
}
//#endregion
//#region src/games/dittle/options.tsx
function ue({ value: e, onChange: t }) {
	let n = c(), r = F.safeParse(e), i = r.success ? r.data : F.parse(void 0);
	return /* @__PURE__ */ p(_, {
		title: n("games.dittle.mode"),
		children: [!1, !0].map((e) => /* @__PURE__ */ p(g, {
			name: "dittle-mode",
			value: String(e),
			checked: i.clash === e,
			label: n(e ? "games.dittle.clashOption" : "games.dittle.battleOption"),
			accent: j.accent,
			onChange: () => t({ clash: e })
		}, String(e)))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/dittle/entry.tsx
var de = {
	definition: Y,
	View: $,
	bot: ie,
	describe: ae,
	fx: ce,
	OverView: le,
	Options: ue,
	locales: {
		zh: {
			name: "Dittle: Dice Battle",
			desc: "翻滚或跳跃，让七枚骰子抵达对岸，以朝上点数决胜。",
			rules: "游戏目标:\n双方各有七枚骰子。当一方的七枚骰子全部到达对方底线时，游戏立即结束。分别合计双方已到达对方底线的骰子朝上点数，总分较高的玩家获胜。因此，率先让全部骰子抵达对岸并不一定获胜；总分相同时，双方平局。\n\n开局准备:\n使用七行七列的棋盘。白方从下方向上推进，黑方从上方向下推进。各自在靠近自己的一行摆满七枚骰子，使六点朝上、三点朝向自己。双方各掷两枚骰子，点数合计较高者先行；点数相同时重新掷骰。开局后，不再随机掷骰。\n\n每回合的移动:\n每个回合选择一枚己方骰子，按以下规则移动：\n· 翻滚：向前、向左或向右翻滚一格，落点必须为空。骰子的朝上点数随实际骰面朝向改变。\n· 跳跃：越过紧邻的一枚己方或对方骰子，落在紧接着的空格中，骰子的朝向保持不变。你可以连续跳跃，但相邻的两枚被跳骰子之间必须有空格，不能越过挤在一起的骰子。\n· 如果没有先翻滚，连续跳跃必须沿同一条纵轴或横轴进行。你也可以先翻滚一次，再连续跳跃；此时可以组合向前与横向的跳跃。\n· 骰子不得后退、斜走或原地转动，同一回合也不得翻滚多次。骰子到达对方底线后，仍可横向翻滚或跳跃来调整朝上点数，但不能越出棋盘。\n\n数字版操作:\n· 点选一枚己方骰子，查看一次翻滚或一次跳跃能够到达的格子，以及到达后的朝上骰面。点击目标位置的骰面，执行这一步移动。\n· 如果仍有合法的后续跳跃，可以继续点击跳跃落点，或点击“结束移动”结束本回合。没有后续跳跃时，回合自动结束。\n· 整段移动算作一个回合。翻滚只能作为第一步；没有先翻滚的连续跳跃不能改变纵轴或横轴。\n· 开始移动前，再次点击已选骰子或点击“取消选择”，可以撤销选择。棋盘始终以白方的方向显示，因此黑方向屏幕下方推进。\n\nDittle Clash（可选，默认关闭）:\n这一模式只允许翻滚，不允许跳跃。翻滚后，与敌方骰子在横向或纵向上相邻的骰子会发生碰撞，按以下规则结算：\n· 一枚骰子与一枚敌方骰子碰撞时，朝上点数较低的骰子出局；点数相同时，两枚骰子均出局。\n· 一枚骰子被多枚敌方骰子包围时，先合计这些敌方骰子的朝上点数，再与被围骰子的朝上点数比较。总点数较低的一方全部出局；点数相同时，参与这次包围的骰子全部出局。\n· 先结算包围，同一组骰子不再拆成一对一碰撞重复结算。相互重叠的包围都以移除前的同一盘面为准，确定结果后同时移除出局骰子。\n· 任意一枚幸存的骰子到达对方底线，该玩家立即获胜。一方骰子全部出局时，另一方获胜；双方骰子均全部出局时，双方平局。\n\n无法推进与重复局面:\n原版规则未规定以下情况，本数字版采用下列处理方式：\n· 只有没有合法走法时，才可以跳过回合。双方连续跳过时，按当时已经到达对方底线的骰子朝上点数结算。\n· 同一骰子位置、完整朝向及行棋方构成的局面出现三次时，双方平局。\n· Dittle Clash中的同时包围，按上一节所述的统一方式结算。",
			invalid: "当前不能执行这一步，请重新选择。",
			white: "白方",
			black: "黑方",
			battle: "Dice Battle",
			clash: "Dittle Clash",
			mode: "游戏模式",
			battleOption: "Dice Battle · 对岸点数决胜",
			clashOption: "Dittle Clash · 碰撞淘汰",
			turn: "第 {{n}} 回合",
			yours: "轮到你了",
			waiting: "等待 {{name}} 行棋",
			moving: "骰子移动中",
			clashing: "碰撞结算中",
			arrived: "抵达 {{n}}/7",
			score: "对岸点数",
			remaining: "剩余 {{n}} 枚",
			remainingLabel: "剩余骰子",
			select: "选择一枚骰子",
			target: "点击落点骰面移动",
			confirm: "确认移动",
			cancel: "取消选择",
			pass: "无路可走，跳过回合",
			continueJump: "继续跳跃或结束移动",
			finish: "结束移动",
			top: "朝上 {{n}} 点",
			north: "向上 {{n}} 点",
			east: "向右 {{n}} 点",
			selected: "选中骰子",
			preview: "落点预览",
			die: "{{color}}骰子 {{square}}，朝上 {{n}} 点",
			destination: "移动至 {{square}}",
			move: "从 {{from}} 移动到 {{to}}，朝上 {{n}} 点",
			tilt: "翻滚",
			jump: "跳跃",
			tiltJump: "翻滚后跳跃",
			toss: "先手掷骰",
			goesFirst: "{{name}} 先行",
			you: "你",
			review: "查看棋盘",
			closeReview: "返回结算",
			result: "对局结束",
			won: "{{name}} 获胜",
			draw: "平局",
			endingCrossed: "骰子抵达对方底线",
			endingEliminated: "碰撞淘汰结束",
			endingBlocked: "双方均无合法走法",
			endingRepetition: "同一局面出现三次",
			againConfirm: "确认再来一局",
			lobbyConfirm: "确认返回大厅",
			cancelConfirm: "取消",
			total: "总分"
		},
		en: {
			name: "Dittle: Dice Battle",
			desc: "Tilt and jump seven dice across the board. The upward faces decide the winner.",
			rules: "Objective:\nEach player has seven dice. When either player has all seven dice in the opponent's base row, the game ends immediately. Add the upward-facing values of each player's dice in the opposite base row. The player with the higher total wins, so finishing first does not guarantee victory. Equal totals result in a draw.\n\nSetup:\nUse a board with seven rows and seven columns. White advances from the bottom toward the top; Black advances from the top toward the bottom. Fill your nearest row with seven dice, with six facing upward and three facing you. Each player rolls two dice, and the player with the higher total takes the first turn. Roll again if the totals are equal. There are no random rolls after setup.\n\nMoving on your turn:\nChoose one of your dice and move it according to the following rules:\n· You may tilt it one square forward, left or right into an empty square. Its upward face changes according to its actual orientation.\n· You may jump over one adjacent friendly or opposing die into the empty square immediately beyond it, preserving your die's orientation. You may make consecutive jumps, but there must be an empty landing space between the dice being jumped. You cannot jump over a solid cluster.\n· Without an initial tilt, consecutive jumps must remain on the same vertical or horizontal axis. You may instead tilt once and then jump, combining forward and sideways jumps.\n· You cannot move backward or diagonally, rotate a die in place or tilt more than once during the same turn. Dice in the opposite base row may continue moving sideways to improve their upward-facing values, but they cannot leave the board.\n\nDigital controls:\n· Select one of your dice to see the destinations for a single tilt or jump, together with the resulting upward face. Click the die face shown at a destination to take that step.\n· If another legal jump is available, click its destination to continue or choose End move to end your turn. If no further jump is available, your turn ends automatically.\n· The entire movement sequence counts as one turn. A tilt is allowed only as the first step. A sequence of jumps without an initial tilt must remain on one axis.\n· Before moving, click the selected die again or choose Cancel selection to clear your selection. The board always uses White's perspective, so Black advances toward the bottom of the screen.\n\nDittle Clash (optional, off by default):\nIn this mode, dice may tilt but cannot jump. After a tilt, dice clash with opposing dice that are adjacent horizontally or vertically. Resolve these clashes as follows:\n· When one die clashes with one opposing die, remove the die with the lower upward-facing value. If the values are equal, remove both dice.\n· When a die is surrounded by multiple opposing dice, add the upward-facing values of those opposing dice and compare their total with the surrounded die's upward-facing value. Remove all dice on the side with the lower value. If the values are equal, remove every die involved in that surround.\n· Resolve surrounds before one-on-one clashes, and do not resolve the same group again as separate pairs. Determine all overlapping surrounds from the same board before removing any dice, then remove the casualties simultaneously.\n· A player wins immediately when one of their surviving dice reaches the opponent's base row. A player also wins if all opposing dice are removed. If both players lose all their dice, the game is a draw.\n\nBlocked and repeated positions:\nThe original leaflet does not specify the following cases, so this digital edition handles them as follows:\n· You may pass only if you have no legal moves. Two consecutive passes end the game, with scores determined by the upward-facing values of dice already in the opposite base row.\n· If the same positions, complete die orientations and player to move occur three times, the game is a draw.\n· Simultaneous surrounds in Dittle Clash are resolved using the procedure in the previous section.",
			invalid: "That move is unavailable. Please choose again.",
			white: "White",
			black: "Black",
			battle: "Dice Battle",
			clash: "Dittle Clash",
			mode: "Game mode",
			battleOption: "Dice Battle · Highest crossing score",
			clashOption: "Dittle Clash · Elimination",
			turn: "Turn {{n}}",
			yours: "Your turn",
			waiting: "Waiting for {{name}}",
			moving: "Moving dice",
			clashing: "Resolving clashes",
			arrived: "{{n}}/7 across",
			score: "Crossing score",
			remaining: "{{n}} dice left",
			remainingLabel: "Dice remaining",
			select: "Choose a die",
			target: "Click a destination die to move",
			confirm: "Confirm move",
			cancel: "Cancel selection",
			pass: "No legal moves · Pass",
			continueJump: "Continue jumping or end your move",
			finish: "End move",
			top: "{{n}} on top",
			north: "{{n}} toward top",
			east: "{{n}} toward right",
			selected: "Selected die",
			preview: "Destination preview",
			die: "{{color}} die at {{square}}, {{n}} on top",
			destination: "Move to {{square}}",
			move: "Move from {{from}} to {{to}}, {{n}} on top",
			tilt: "Tilt",
			jump: "Jump",
			tiltJump: "Tilt then jump",
			toss: "Opening roll",
			goesFirst: "{{name}} starts",
			you: "You",
			review: "View board",
			closeReview: "Back to results",
			result: "Game over",
			won: "{{name}} wins",
			draw: "Draw",
			endingCrossed: "The opposite base row was reached",
			endingEliminated: "Elimination ended the game",
			endingBlocked: "Neither player can move",
			endingRepetition: "The same position appeared three times",
			againConfirm: "Confirm another game",
			lobbyConfirm: "Confirm return to lobby",
			cancelConfirm: "Cancel",
			total: "Total"
		}
	}
};
//#endregion
export { de as default };
