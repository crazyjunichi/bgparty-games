import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Component as n, createElement as r, useCallback as i, useLayoutEffect as a, useRef as o, useState as s } from "react";
import { useT as c } from "@bgparty/sdk/i18n";
import { useWakeLock as l } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { gameAssetUrl as d } from "@bgparty/sdk/assets";
import { useFxAnchor as f, useFxAnchorsMaybe as p } from "@bgparty/sdk/fx/anchors";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Floater as _, PulseBox as v } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as y, OptionSection as b } from "@bgparty/sdk/ui/game-options";
//#region src/games/friday/data.ts
var x = [
	"none",
	"life1",
	"life2",
	"draw1",
	"draw2",
	"destroy",
	"double",
	"copy",
	"step",
	"sort",
	"exchange1",
	"exchange2",
	"below",
	"lose1",
	"lose2",
	"highest",
	"stop"
], S = [
	...Array.from({ length: 5 }, (e, t) => ({
		id: `s-negative-${t}`,
		kind: "starting",
		power: -1,
		ability: "none",
		art: "14500",
		title: "distracted"
	})),
	...Array.from({ length: 8 }, (e, t) => ({
		id: `s-zero-${t}`,
		kind: "starting",
		power: 0,
		ability: "none",
		art: "14600",
		title: "weak"
	})),
	{
		id: "s-food",
		kind: "starting",
		power: 0,
		ability: "life2",
		art: "14700",
		title: "eating"
	},
	{
		id: "s-genius",
		kind: "starting",
		power: 2,
		ability: "none",
		art: "14800",
		title: "genius"
	},
	...Array.from({ length: 3 }, (e, t) => ({
		id: `s-one-${t}`,
		kind: "starting",
		power: 1,
		ability: "none",
		art: "14900",
		title: "focused"
	}))
], C = [
	[0, "step"],
	[0, "below"],
	[0, "destroy"],
	[0, "copy"],
	[0, "life1"],
	[0, "life1"],
	[0, "draw2"],
	[0, "draw2"],
	[0, "exchange2"],
	[0, "exchange2"],
	[1, "copy"],
	[1, "destroy"],
	[1, "double"],
	[1, "below"],
	[1, "life1"],
	[1, "life1"],
	[2, "none"],
	[2, "none"],
	[2, "draw1"],
	[2, "destroy"],
	[2, "sort"],
	[2, "exchange1"],
	[2, "life1"],
	[2, "double"],
	[3, "destroy"],
	[3, "draw1"],
	[3, "sort"],
	[3, "exchange1"],
	[4, "none"],
	[4, "none"]
].map(([e, t], n) => {
	let r = n < 10 ? 0 : n < 18 ? 1 : n < 24 ? 2 : n < 28 ? 3 : 4, i = String(11500 + n * 100);
	return {
		id: `h-${n}`,
		kind: "knowledge",
		power: e,
		ability: t,
		art: i,
		title: [
			"raft",
			"island",
			"explore",
			"animals",
			"cannibals"
		][r],
		free: r + 1,
		hazard: [
			[
				0,
				1,
				3
			],
			[
				1,
				3,
				6
			],
			[
				2,
				5,
				8
			],
			[
				4,
				7,
				11
			],
			[
				5,
				9,
				14
			]
		][r]
	};
}), w = [
	{
		id: "a-hungry2",
		kind: "aging",
		power: 0,
		ability: "lose2",
		art: "15000",
		title: "veryHungry",
		difficult: !0
	},
	{
		id: "a-hungry",
		kind: "aging",
		power: 0,
		ability: "lose1",
		art: "15100",
		title: "hungry"
	},
	{
		id: "a-distracted",
		kind: "aging",
		power: -1,
		ability: "none",
		art: "15200",
		title: "distracted"
	},
	...[0, 1].map((e) => ({
		id: `a-scared-${e}`,
		kind: "aging",
		power: 0,
		ability: "highest",
		art: "15300",
		title: "scared"
	})),
	{
		id: "a-tired",
		kind: "aging",
		power: 0,
		ability: "stop",
		art: "15400",
		title: "veryTired"
	},
	...[0, 1].map((e) => ({
		id: `a-stupid-${e}`,
		kind: "aging",
		power: -2,
		ability: "none",
		art: "15500",
		title: "stupid"
	})),
	{
		id: "a-suicidal",
		kind: "aging",
		power: -5,
		ability: "none",
		art: "15600",
		title: "suicidal",
		difficult: !0
	},
	{
		id: "a-moronic",
		kind: "aging",
		power: -4,
		ability: "none",
		art: "15700",
		title: "moronic",
		difficult: !0
	},
	{
		id: "a-veryStupid",
		kind: "aging",
		power: -3,
		ability: "none",
		art: "15800",
		title: "veryStupid"
	}
], T = S.map((e) => e.id), E = w.map((e) => e.id), D = Object.fromEntries([
	...S,
	...C,
	...w
].map((e) => [e.id, e])), O = [
	{
		id: "5500",
		free: 8,
		target: 30,
		effect: "normal"
	},
	{
		id: "5700",
		free: 6,
		target: 20,
		effect: "normal"
	},
	{
		id: "5900",
		free: 9,
		target: 35,
		effect: "normal"
	},
	{
		id: "6000",
		free: 7,
		target: 25,
		effect: "normal"
	},
	{
		id: "6300",
		free: 10,
		target: 40,
		effect: "normal"
	},
	{
		id: "11000",
		free: 7,
		target: 16,
		effect: "cost2"
	},
	{
		id: "11100",
		free: 0,
		target: 0,
		effect: "hazards"
	},
	{
		id: "11200",
		free: 5,
		target: 0,
		effect: "aging"
	},
	{
		id: "11300",
		free: 9,
		target: 22,
		effect: "half"
	},
	{
		id: "11400",
		free: 10,
		target: 52,
		effect: "plus"
	}
];
function k(e) {
	return O.find((t) => t.id === e);
}
var A = x.filter((e) => ![
	"none",
	"lose1",
	"lose2",
	"highest",
	"stop"
].includes(e)), j = {
	id: "friday",
	tier: "alpha",
	mechanics: ["deck-bag-building", "push-your-luck"],
	interactionTags: [],
	nameKey: "games.friday.name",
	descKey: "games.friday.desc",
	rulesKey: "games.friday.rules",
	icon: "🏝️",
	iconImg: "games/friday.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/1769322157335372539/1B00A5333C080820FE88D978176DC9DED5F12A2F/" },
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#709344",
	releasedAt: "2026-10-31T10:33:28+08:00",
	search: {
		py: "xing qi wu",
		init: "xqw"
	},
	hotseat: "open"
}, M = t.object({ level: t.int().min(1).max(4).default(1) }).default({ level: 1 }), N = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("choose"),
		id: t.string()
	}),
	t.object({ type: t.literal("skip") }),
	t.object({ type: t.literal("draw") }),
	t.object({
		type: t.literal("use"),
		card: t.string(),
		copy: t.string().optional(),
		target: t.string().optional()
	}),
	t.object({ type: t.literal("continue") }),
	t.object({ type: t.literal("stop") }),
	t.object({
		type: t.literal("exchange"),
		target: t.string()
	}),
	t.object({
		type: t.literal("sortDone"),
		order: t.array(t.string()).max(3),
		discard: t.string().optional()
	}),
	t.object({ type: t.literal("finish") }),
	t.object({
		type: t.literal("destroy"),
		card: t.string()
	}),
	t.object({ type: t.literal("next") })
]), ee = t.object({
	id: t.string(),
	lane: t.enum(["free", "paid"]),
	used: t.boolean(),
	destroyed: t.boolean()
}), P = t.object({
	kind: t.enum([
		"draw",
		"sort",
		"exchange"
	]),
	left: t.int(),
	count: t.int(),
	source: t.string()
}), F = t.object({
	cards: t.int(),
	pirates: t.int(),
	life: t.int(),
	hazards: t.int(),
	total: t.int()
}), I = t.object({
	rid: t.string(),
	level: t.int(),
	phase: t.enum([
		"choose",
		"fight",
		"cull",
		"pirates",
		"done"
	]),
	step: t.int(),
	life: t.int(),
	maxLife: t.int(),
	offers: t.array(t.string()),
	active: t.string().nullable(),
	pirate: t.boolean(),
	pirates: t.array(t.string()),
	defeated: t.array(t.string()),
	table: t.array(ee),
	discard: t.array(t.string()),
	hazardDiscard: t.array(t.string()),
	destroyed: t.array(t.string()),
	deckCount: t.int(),
	hazardCount: t.int(),
	agingCount: t.int(),
	agingAdded: t.int(),
	free: t.int(),
	freeUsed: t.int(),
	target: t.int(),
	powers: t.record(t.string(), t.int()),
	counted: t.array(t.string()),
	power: t.int(),
	penalty: t.int(),
	drawCost: t.int(),
	canFree: t.boolean(),
	doubles: t.array(t.object({
		source: t.string(),
		target: t.string()
	})),
	doubleTargets: t.array(t.string()),
	steps: t.array(t.string()),
	pending: P.nullable(),
	budget: t.int(),
	lastLoss: t.int(),
	won: t.boolean().nullable(),
	reason: t.string().nullable(),
	score: F.nullable()
}), te = t.object({ sort: t.array(t.string()) }), L = () => ({ code: "games.friday.errAction" });
function R(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function z(e, t) {
	e.phase = "done", e.won = !1, e.reason = t, e.life = 0;
}
function ne(e, t) {
	return e.life < t ? (z(e, "life"), !1) : (e.life -= t, !0);
}
function B(e) {
	if (e.deck.length) return !0;
	if (!e.aging.length) return z(e, "aging"), !1;
	let t = e.aging.shift();
	return e.agingAdded++, e.deck = R(e, [...e.discard, t]), e.discard = [], !0;
}
function V(e, t, n, r) {
	if (!B(e)) return !1;
	let i = e.deck.shift(), a = {
		id: i,
		lane: t,
		used: !1,
		destroyed: !1
	};
	return r === void 0 ? e.table.push(a) : e.table.splice(r, 0, a), n.push({
		kind: "move",
		data: {
			id: i,
			from: "deck",
			to: `card:${i}`
		},
		with: n.length > 0
	}), !0;
}
var H = (e) => e.table.filter((e) => !e.destroyed);
function re(e) {
	let t = e.table.filter((e) => !e.destroyed), n = Object.fromEntries(e.table.map((e) => [e.id, e.destroyed ? 0 : D[e.id].power])), r = t.filter((e) => D[e.id].ability === "highest").length, i = t.filter((e) => D[e.id].power > 0).sort((e, t) => D[t.id].power - D[e.id].power || e.id.localeCompare(t.id));
	for (let e of i.slice(0, r)) n[e.id] = 0;
	for (let r of e.doubles) t.some((e) => e.id === r.source) && t.some((e) => e.id === r.target) && (n[r.target] *= 2);
	let a = e.table.map((e) => e.id);
	if (e.pirate && e.active && k(e.active).effect === "half") {
		let r = t.filter((e) => D[e.id].kind === "aging").map((e) => e.id), i = Math.max(0, Math.ceil(e.table.length / 2) - r.length), o = e.table.filter((e) => !r.includes(e.id)).sort((e, t) => n[t.id] - n[e.id] || e.id.localeCompare(t.id)).slice(0, i).map((e) => e.id);
		a = [...r, ...o];
	}
	let o = e.pirate && e.active && k(e.active).effect === "plus" ? e.table.length : 0;
	return {
		powers: n,
		counted: a,
		power: a.reduce((e, t) => e + n[t], 0) + o
	};
}
function ie(e) {
	if (e.pirate || !e.active) return e.baseTarget;
	let t = e.steps.filter((t) => H(e).some((e) => e.id === t)).length;
	return D[e.active].hazard[Math.max(0, e.step - t)];
}
function U(e) {
	return e.pirate && e.active && k(e.active).effect === "cost2" ? 2 : 1;
}
function ae(e) {
	return e.freeUsed < e.free && !e.table.some((e) => !e.destroyed && e.lane === "free" && D[e.id].ability === "stop");
}
function W(e) {
	return H(e).reduce((e, t) => e + (D[t.id].ability === "lose1" ? 1 : D[t.id].ability === "lose2" ? 2 : 0), 0);
}
function G(e) {
	if (e.active = null, e.table = [], e.doubles = [], e.doubleTargets = [], e.steps = [], e.pending = null, e.freeUsed = 0, e.budget = 0, e.step < 3 && (e.hazards.length || (e.step++, e.step < 3 && (e.hazards = R(e, e.hazardDiscard), e.hazardDiscard = [])), e.step < 3)) {
		e.offers = e.hazards.splice(0, 2), e.phase = "choose", e.pirate = !1;
		return;
	}
	e.pirate = !0, e.offers = [], e.phase = "pirates";
}
function oe(e, t) {
	for (let n of e.table) n.destroyed ? e.destroyed.push(n.id) : (e.discard.push(n.id), t.push({
		kind: "move",
		data: {
			id: n.id,
			from: `card:${n.id}`,
			to: "discard"
		},
		with: t.length > 0
	}));
}
function se(e, t) {
	oe(e, t), G(e);
}
function ce(e) {
	let t = [
		...e.deck,
		...e.discard,
		...e.table.filter((e) => !e.destroyed).map((e) => e.id),
		...e.pending?.cards ?? []
	].reduce((e, t) => e + (D[t].kind === "aging" ? -5 : D[t].power), 0), n = e.defeated.length * 15, r = e.won ? e.life * 5 : 0, i = e.hazardDiscard.length * -3;
	return {
		cards: t,
		pirates: n,
		life: r,
		hazards: i,
		total: t + n + r + i
	};
}
function le(e, t, n) {
	let r = {
		rid: t[0],
		seed: n,
		cursor: 0,
		level: e.level,
		phase: "choose",
		step: 0,
		life: e.level === 4 ? 18 : 20,
		maxLife: e.level === 4 ? 20 : 22,
		deck: [],
		discard: [],
		aging: [],
		agingAdded: 0,
		hazards: [],
		hazardDiscard: [],
		offers: [],
		active: null,
		pirates: [],
		defeated: [],
		pirate: !1,
		table: [],
		destroyed: [],
		free: 0,
		freeUsed: 0,
		baseTarget: 0,
		doubles: [],
		doubleTargets: [],
		steps: [],
		pending: null,
		budget: 0,
		lastLoss: 0,
		won: null,
		reason: null
	};
	r.aging = [...R(r, E.filter((t) => !D[t].difficult && (e.level >= 3 || t !== "a-veryStupid"))), ...R(r, E.filter((e) => D[e].difficult))];
	let i = [...T];
	return e.level >= 2 && (i.push(r.aging.shift()), r.agingAdded++), r.deck = R(r, i), r.hazards = R(r, C.map((e) => e.id)), r.pirates = R(r, O.map((e) => e.id)).slice(0, 2), G(r), {
		state: r,
		fx: []
	};
}
function ue(e, t, n) {
	let r = H(e).find((e) => e.id === t.card);
	if (!r || r.used) return !1;
	let i = D[r.id].ability;
	if (i === "copy") {
		let n = H(e).find((e) => e.id === t.copy && e.id !== r.id);
		if (!n || !A.includes(D[n.id].ability) || D[n.id].ability === "copy") return !1;
		i = D[n.id].ability;
	} else if (t.copy) return !1;
	if (!A.includes(i)) return !1;
	let a = H(e).find((e) => e.id === t.target && e.id !== r.id);
	if ([
		"destroy",
		"double",
		"below"
	].includes(i) && !a || i === "double" && e.doubleTargets.includes(a.id) || i === "step" && (e.pirate || e.step === 0)) return !1;
	if (r.used = !0, n.push({
		kind: "ability",
		data: { id: r.id }
	}), (i === "life1" || i === "life2") && (e.life = Math.min(e.maxLife, e.life + (i === "life1" ? 1 : 2)), n.push({
		kind: "life",
		data: { value: i === "life1" ? 1 : 2 },
		with: !0
	})), i === "destroy" && (a.destroyed = !0, K(e, a.id), n.push({
		kind: "move",
		data: {
			id: a.id,
			from: `card:${a.id}`,
			to: "destroyed"
		},
		with: !0
	})), i === "double" && (e.doubles.push({
		source: r.id,
		target: a.id
	}), e.doubleTargets.push(a.id)), i === "step" && e.steps.push(r.id), (i === "draw1" || i === "draw2") && (e.pending = {
		kind: "draw",
		left: i === "draw1" ? 1 : 2,
		cards: [],
		source: r.id
	}), i === "sort" && (e.pending = {
		kind: "sort",
		left: 3,
		cards: [],
		source: r.id
	}), (i === "exchange1" || i === "exchange2") && (e.pending = {
		kind: "exchange",
		left: i === "exchange1" ? 1 : 2,
		cards: [],
		source: r.id
	}), i === "below") {
		if (!B(e)) return !0;
		let t = e.table.findIndex((e) => e.id === a.id);
		e.table.splice(t, 1), K(e, a.id), e.deck.push(a.id), n.push({
			kind: "move",
			data: {
				id: a.id,
				from: `card:${a.id}`,
				to: "deck"
			},
			with: !0
		}), a.lane === "free" && (e.pending = {
			kind: "draw",
			left: 1,
			cards: [],
			source: r.id,
			index: t
		});
	}
	return !0;
}
function K(e, t) {
	e.doubles = e.doubles.filter((e) => e.source !== t && e.target !== t), e.steps = e.steps.filter((e) => e !== t);
}
function de(e, t, n) {
	if (n.by !== e.rid || e.phase === "done") return L();
	let r = structuredClone(e), i = [];
	if (r.pending) {
		let e = r.pending;
		if (t.type === "stop" && e.kind !== "sort") return r.pending = null, {
			state: r,
			fx: i
		};
		if (t.type === "continue" && (e.kind === "draw" || e.kind === "sort") && e.left > 0) {
			if (e.kind === "draw") V(r, e.index === void 0 ? "paid" : "free", i, e.index);
			else if (B(r)) {
				let t = r.deck.shift();
				e.cards.push(t), i.push({
					kind: "move",
					data: {
						id: t,
						from: "deck",
						to: `sort:${t}`
					},
					for: [r.rid]
				});
			}
			return e.left--, e.kind === "draw" && e.left === 0 && (r.pending = null), {
				state: r,
				fx: i
			};
		}
		if (t.type === "exchange" && e.kind === "exchange") {
			let n = r.table.findIndex((n) => !n.destroyed && n.id === t.target && n.id !== e.source);
			if (n < 0) return L();
			let a = r.table[n];
			return r.table.splice(n, 1), K(r, a.id), r.discard.push(a.id), i.push({
				kind: "move",
				data: {
					id: a.id,
					from: `card:${a.id}`,
					to: "discard"
				}
			}), V(r, a.lane, i, n), e.left--, e.left === 0 && (r.pending = null), {
				state: r,
				fx: i
			};
		}
		if (t.type === "sortDone" && e.kind === "sort") {
			let n = [...t.order, ...t.discard ? [t.discard] : []];
			if (n.length !== e.cards.length || new Set(n).size !== n.length || n.some((t) => !e.cards.includes(t))) return L();
			r.deck = [...t.order, ...r.deck];
			for (let e of t.order) i.push({
				kind: "move",
				data: {
					id: e,
					from: `sort:${e}`,
					to: "deck"
				},
				for: [r.rid],
				with: i.length > 0
			});
			return t.discard && (r.discard.push(t.discard), i.push({
				kind: "move",
				data: {
					id: t.discard,
					from: `sort:${t.discard}`,
					to: "discard"
				},
				with: i.length > 0
			})), r.pending = null, {
				state: r,
				fx: i
			};
		}
		return L();
	}
	if (t.type === "choose") {
		if (r.phase === "choose" && r.offers.includes(t.id)) r.active = t.id, r.hazardDiscard.push(...r.offers.filter((e) => e !== t.id)), r.offers = [], r.free = D[t.id].free, r.baseTarget = D[t.id].hazard[r.step];
		else if (r.phase === "pirates" && r.pirates.includes(t.id) && !r.defeated.includes(t.id)) {
			r.active = t.id;
			let e = k(t.id);
			r.free = e.free, r.baseTarget = e.target, e.effect === "hazards" && (r.free = r.hazardDiscard.reduce((e, t) => e + D[t].free, 0), r.baseTarget = r.hazardDiscard.reduce((e, t) => e + D[t].hazard[2], 0)), e.effect === "aging" && (r.baseTarget = r.agingAdded * 2);
		} else return L();
		r.phase = "fight", i.push({
			kind: "move",
			data: {
				id: t.id,
				from: r.pirate ? `pirate:${t.id}` : `offer:${t.id}`,
				to: "active",
				hazard: !r.pirate,
				pirate: r.pirate
			}
		});
	} else if (t.type === "skip" && r.phase === "choose" && r.offers.length === 1) r.hazardDiscard.push(...r.offers), r.offers = [], G(r);
	else if (t.type === "draw" && r.phase === "fight") {
		let e = ae(r);
		if (!e && !ne(r, U(r))) return {
			state: r,
			fx: [{
				kind: "life",
				data: { value: -U(r) }
			}]
		};
		e && r.freeUsed++, V(r, e ? "free" : "paid", i), e || i.push({
			kind: "life",
			data: { value: -U(r) },
			with: !0
		});
	} else if (t.type === "use" && r.phase === "fight") {
		if (!ue(r, t, i)) return L();
	} else if (t.type === "finish" && r.phase === "fight" && r.table.length > 0) {
		let t = Math.max(0, ie(r) - re(r).power);
		if (r.pirate && t > 0) return L();
		if (!ne(r, t + W(r))) return {
			state: r,
			fx: [{
				kind: "life",
				data: { value: -(t + W(e)) }
			}]
		};
		t === 0 ? (r.pirate ? r.defeated.push(r.active) : (r.discard.push(r.active), i.push({
			kind: "move",
			data: {
				id: r.active,
				from: "active",
				to: "discard"
			}
		})), i.push({
			kind: "victory",
			data: { pirate: r.pirate },
			with: i.length > 0
		}), r.defeated.length === 2 ? (r.phase = "done", r.won = !0, r.reason = "escaped") : se(r, i)) : (r.lastLoss = t, r.budget = t, r.phase = "cull", r.hazardDiscard.push(r.active), i.push({
			kind: "life",
			data: { value: -(t + W(e)) }
		}));
	} else if (t.type === "destroy" && r.phase === "cull") {
		let e = H(r).find((e) => e.id === t.card);
		if (!e) return L();
		let n = D[e.id].kind === "aging" ? 2 : 1;
		if (n > r.budget) return L();
		r.budget -= n, e.destroyed = !0, K(r, e.id), i.push({
			kind: "move",
			data: {
				id: e.id,
				from: `card:${e.id}`,
				to: "destroyed"
			}
		});
	} else if (t.type === "next" && r.phase === "cull") se(r, i);
	else return L();
	return {
		state: r,
		fx: i
	};
}
function fe(e, t) {
	return {
		public: {
			rid: e.rid,
			level: e.level,
			phase: e.phase,
			step: e.step,
			life: e.life,
			maxLife: e.maxLife,
			offers: e.offers,
			active: e.active,
			pirate: e.pirate,
			pirates: e.pirates,
			defeated: e.defeated,
			table: e.table,
			discard: e.discard,
			hazardDiscard: e.hazardDiscard,
			destroyed: e.destroyed,
			deckCount: e.deck.length,
			hazardCount: e.hazards.length,
			agingCount: e.aging.length,
			agingAdded: e.agingAdded,
			free: e.free,
			freeUsed: e.freeUsed,
			target: ie(e),
			...re(e),
			penalty: W(e),
			drawCost: U(e),
			canFree: ae(e),
			doubles: e.doubles,
			doubleTargets: e.doubleTargets,
			steps: e.steps,
			pending: e.pending ? {
				kind: e.pending.kind,
				left: e.pending.left,
				count: e.pending.cards.length,
				source: e.pending.source
			} : null,
			budget: e.budget,
			lastLoss: e.lastLoss,
			won: e.won,
			reason: e.reason,
			score: e.phase === "done" ? ce(e) : null
		},
		private: { sort: t === e.rid && e.pending?.kind === "sort" ? e.pending.cards : [] }
	};
}
var pe = {
	meta: j,
	saveCompatibility: { version: "1" },
	schemas: {
		action: N,
		config: M,
		publicView: I,
		privateView: te
	},
	setup: le,
	reduce: de,
	viewFor: fe,
	status: (e) => e.phase === "done" ? {
		phase: "done",
		winner: e.won ? [e.rid] : [],
		ranking: [e.rid],
		scores: { [e.rid]: ce(e).total }
	} : { phase: e.phase }
}, q = /* @__PURE__ */ new Map(), J = /* @__PURE__ */ new Map(), me = /* @__PURE__ */ new Map();
function Y(e) {
	if (!e.classList.contains("fr-card")) return null;
	let t = e.getBoundingClientRect();
	if (!t.width || !t.height) return null;
	let n = e.cloneNode(!0), r = [e, ...e.querySelectorAll("*")], i = [n, ...n.querySelectorAll("*")];
	return r.forEach((e, t) => {
		let n = i[t], r = getComputedStyle(e);
		for (let e of r) n.style.setProperty(e, r.getPropertyValue(e));
		n.removeAttribute("id"), n.removeAttribute("autofocus"), n.tabIndex = -1, n.style.animation = "none", n.style.transition = "none", n.style.visibility = "visible";
	}), n.querySelectorAll(".fr-ants").forEach((e) => e.remove()), n.classList.remove("fr-candidate", "fr-selected"), Object.assign(n.style, {
		width: `${t.width}px`,
		height: `${t.height}px`,
		boxSizing: "border-box",
		margin: "0",
		position: "relative",
		inset: "auto",
		transform: "none",
		pointerEvents: "none"
	}), n.inert = !0, {
		node: n,
		w: t.width,
		h: t.height
	};
}
function he(e, t = !1) {
	let n = q.get(e);
	return n ? t ? me.get(e) ?? Y(n) : Y(n) : J.get(e) ?? null;
}
var ge = class extends n {
	root = null;
	getSnapshotBeforeUpdate(e) {
		if (e.frame === this.props.frame) return null;
		let t = /* @__PURE__ */ new Map();
		for (let [e, n] of q) if (this.root?.contains(n)) {
			let r = Y(n);
			r && t.set(e, r);
		}
		return t;
	}
	componentDidUpdate(e, t, n) {
		n && (me = n);
	}
	render() {
		return r("div", {
			style: { display: "contents" },
			ref: (e) => {
				this.root = e;
			}
		}, this.props.children);
	}
};
function _e(e) {
	let { ref: t, hidden: n } = f(e), r = p(), a = o(null), s = o(null);
	return {
		bind: i((n) => {
			if (!n && a.current && e) {
				let t = a.current.getBoundingClientRect();
				t.width && t.height && (s.current = {
					x: t.x,
					y: t.y,
					w: t.width,
					h: t.height
				});
				let n = s.current;
				r?.registerProbe(e, () => n);
				let i = Y(a.current);
				for (i && J.set(e, i), q.get(e) === a.current && q.delete(e); J.size > 128;) J.delete(J.keys().next().value);
			}
			if (a.current = n, t(n), n) {
				let t = n.getBoundingClientRect();
				s.current = {
					x: t.x,
					y: t.y,
					w: t.width,
					h: t.height
				}, e && (q.set(e, n), J.delete(e));
			}
		}, [
			t,
			e,
			r
		]),
		hidden: n
	};
}
//#endregion
//#region src/games/friday/card.tsx
var X = (e) => `games.friday.${e}`;
function ve({ name: e, children: t, className: n }) {
	let { bind: r, hidden: i } = _e(e);
	return /* @__PURE__ */ h("div", {
		ref: r,
		className: n,
		style: { visibility: i ? "hidden" : void 0 },
		children: t
	});
}
function Z({ id: e, hazard: t = !1, pirate: n = !1, back: r = !1, anchorName: i, selected: a = !1, candidate: o = !1, used: s = !1, power: l, onInspect: u, onChoose: f, children: p }) {
	let _ = c(), { bind: v, hidden: y } = _e(i ?? null), b = D[e], x = n ? k(e) : null, S = _(x ? "games.friday.pirateStage" : X(`title_${b?.title}`)), C = x ? `art-${e}` : t ? `hazard-${[
		11500,
		12500,
		13300,
		13900,
		14300
	][Math.min(4, (b?.free ?? 1) - 1)]}` : `art-${b?.art}`;
	return /* @__PURE__ */ g("div", {
		ref: v,
		className: `fr-card${t ? " fr-hazard" : ""}${x ? " fr-ship" : ""}${r ? " fr-card-back" : ""}${o ? " fr-candidate" : ""}${a ? " fr-selected" : ""}${s ? " fr-used" : ""}`,
		style: { visibility: y ? "hidden" : void 0 },
		children: [o && /* @__PURE__ */ h("svg", {
			className: "fr-ants",
			"aria-hidden": "true",
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ h("rect", {
				x: "1",
				y: "1",
				width: "calc(100% - 2px)",
				height: "calc(100% - 2px)",
				rx: "9",
				pathLength: "100"
			})
		}), r ? /* @__PURE__ */ g("div", {
			className: "fr-back-design",
			children: [
				/* @__PURE__ */ h("span", { children: "FRIDAY" }),
				/* @__PURE__ */ h("i", {}),
				/* @__PURE__ */ h("small", { children: _("games.friday.turned") })
			]
		}) : /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ g("button", {
				type: "button",
				className: "fr-card-face",
				onClick: f ?? u,
				disabled: !f && !u,
				"aria-label": f ? `${S} · ${_("games.friday.selectTarget")}` : S,
				children: [
					/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("b", { children: x ? x.target || "?" : t ? b.free : l ?? b.power }), /* @__PURE__ */ h("span", { children: S })] }),
					/* @__PURE__ */ h("img", {
						src: d(`games/friday/live/${C}.svg`),
						alt: "",
						draggable: !1
					}),
					t ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("div", {
						className: "fr-hazard-values",
						children: b.hazard.map((e, t) => /* @__PURE__ */ h("b", {
							"data-step": t,
							children: e
						}, t))
					}), /* @__PURE__ */ g("div", {
						className: "fr-reward",
						children: [/* @__PURE__ */ h("b", { children: b.power }), /* @__PURE__ */ h("span", { children: _(X(`ability_${b.ability}`)) })]
					})] }) : x ? /* @__PURE__ */ g("div", {
						className: "fr-ship-values",
						children: [
							/* @__PURE__ */ h("b", { children: x.effect === "hazards" ? "?" : x.free }),
							/* @__PURE__ */ h("span", { children: _("games.friday.free") }),
							/* @__PURE__ */ h("b", { children: x.target || "?" })
						]
					}) : /* @__PURE__ */ h("div", {
						className: "fr-card-ability",
						children: _(X(`ability_${b.ability}`))
					})
				]
			}),
			p,
			s && /* @__PURE__ */ h("span", {
				className: "fr-used-mark",
				children: _("games.friday.used")
			})
		] })]
	});
}
//#endregion
//#region src/games/friday/view-player.tsx
function ye(e) {
	l();
	let t = c(), n = e.public, r = e.private, [i, a] = s(null), [o, d] = s(null), [f, p] = s([]), [_, v] = s(), y = n.rid === e.myRid && n.phase !== "done", b = y && n.phase === "fight" && !n.pending, x = (t) => {
		a(null), e.send(t);
	}, S = Math.max(0, n.target - n.power), C = n.table.length > 0, w = r?.sort ?? [], T = [...f.filter((e) => w.includes(e)), ...w.filter((e) => !f.includes(e))], E = w.includes(_ ?? "") ? _ : void 0, O = n.table.filter((e) => e.lane === "free"), j = n.table.filter((e) => e.lane === "paid"), M = (e) => !i || e === i.source || n.table.find((t) => t.id === e)?.destroyed ? !1 : i.ability === "copy" ? A.includes(D[e].ability) && D[e].ability !== "copy" && (D[e].ability !== "step" || !n.pirate && n.step !== 0) : i.ability === "double" ? !n.doubleTargets.includes(e) : ["destroy", "below"].includes(i.ability), N = (e, t, n) => {
		[
			"copy",
			"destroy",
			"double",
			"below"
		].includes(t) ? a({
			source: e,
			ability: t,
			copy: n
		}) : x({
			type: "use",
			card: e,
			copy: n
		});
	}, ee = (e) => {
		i && (i.ability === "copy" ? N(i.source, D[e].ability, e) : x({
			type: "use",
			card: i.source,
			copy: i.copy,
			target: e
		}));
	}, P = (e) => e.map((e) => {
		let r = D[e.id], a = r.kind === "aging" ? 2 : 1, o = y && n.pending?.kind === "exchange" && !e.destroyed && e.id !== n.pending.source, s = b && M(e.id), c = y && n.phase === "cull" && !e.destroyed && a <= n.budget;
		return /* @__PURE__ */ g(Z, {
			id: e.id,
			anchorName: `card:${e.id}`,
			back: e.destroyed,
			used: e.used,
			selected: i?.source === e.id,
			candidate: s || c || !!o,
			power: n.powers[e.id],
			onInspect: () => d({
				ids: [e.id],
				title: t("games.friday.details")
			}),
			onChoose: s ? () => ee(e.id) : c ? () => x({
				type: "destroy",
				card: e.id
			}) : o && !e.destroyed ? () => x({
				type: "exchange",
				target: e.id
			}) : void 0,
			children: [b && !i && !e.destroyed && !e.used && A.includes(r.ability) && (r.ability !== "step" || !n.pirate && n.step !== 0) && /* @__PURE__ */ h("button", {
				type: "button",
				className: "fr-use",
				onClick: () => N(e.id, r.ability),
				children: t("games.friday.use")
			}), n.phase === "fight" && n.pirate && !n.counted.includes(e.id) && /* @__PURE__ */ h("small", {
				className: "fr-card-note",
				children: t("games.friday.ignored")
			})]
		}, e.id);
	}), F = (e, n, r, i) => /* @__PURE__ */ h(ve, {
		name: e,
		className: "fr-pile-wrap",
		children: /* @__PURE__ */ g("button", {
			type: "button",
			className: `fr-pile${i ? " fr-open-pile" : ""}`,
			onClick: i ? () => d({
				ids: i,
				title: t(X(n)),
				hazard: e === "hazardDiscard"
			}) : void 0,
			disabled: !i,
			"aria-label": `${t(X(n))} ${r}`,
			children: [
				/* @__PURE__ */ h("span", {
					className: "fr-pile-emblem",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ h("strong", { children: r }),
				/* @__PURE__ */ h("span", { children: t(X(n)) })
			]
		})
	}), I = !!o || y && n.pending?.kind === "sort", te = /* @__PURE__ */ h("div", {
		className: "fr-actions",
		inert: I,
		children: y ? i ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", { children: t(i.ability === "copy" ? "games.friday.copyTarget" : "games.friday.selectTarget") }), /* @__PURE__ */ h("button", {
			type: "button",
			onClick: () => a(null),
			children: t("games.friday.cancel")
		})] }) : n.pending ? /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("span", { children: t(n.pending.kind === "exchange" ? "games.friday.exchange" : n.pending.kind === "sort" ? "games.friday.sortTitle" : "games.friday.remainingDraw", {
				n: n.pending.left,
				max: 2
			}) }),
			n.pending.kind === "draw" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
				type: "button",
				className: "fr-primary",
				onClick: () => x({ type: "continue" }),
				children: t("games.friday.continue")
			}), /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => x({ type: "stop" }),
				children: t("games.friday.stop")
			})] }),
			n.pending.kind === "exchange" && /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => x({ type: "stop" }),
				children: t("games.friday.stop")
			})
		] }) : n.phase === "fight" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
			type: "button",
			className: "fr-primary",
			onClick: () => x({ type: "draw" }),
			children: t(n.canFree ? "games.friday.drawFree" : "games.friday.drawPaid", { n: n.drawCost })
		}), C && (!n.pirate || S === 0) ? /* @__PURE__ */ h("button", {
			type: "button",
			className: S ? "fr-danger" : "fr-win",
			onClick: () => x({ type: "finish" }),
			children: t(S ? "games.friday.finishLose" : "games.friday.finishWin", { n: S + n.penalty })
		}) : /* @__PURE__ */ h("span", { children: t(C ? "games.friday.pirateDeficit" : "games.friday.drawFirst", { n: S }) })] }) : n.phase === "cull" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", { children: t("games.friday.cull", { n: n.budget }) }), /* @__PURE__ */ h("button", {
			type: "button",
			className: "fr-primary",
			onClick: () => x({ type: "next" }),
			children: t("games.friday.next")
		})] }) : /* @__PURE__ */ h("span", { children: t(n.phase === "choose" ? "games.friday.choose" : "games.friday.choosePirate") }) : /* @__PURE__ */ h("span", { children: t(n.phase === "done" ? "games.friday.details" : "games.friday.watching") })
	});
	return /* @__PURE__ */ h(ge, {
		frame: n,
		children: /* @__PURE__ */ g(u, {
			adaptive: !0,
			className: "friday",
			actionsHeight: "fr-actions-height",
			actions: te,
			banner: /* @__PURE__ */ g("header", {
				className: "fr-banner",
				inert: I,
				children: [
					/* @__PURE__ */ h("strong", {
						className: "fr-brand",
						children: "FRIDAY"
					}),
					/* @__PURE__ */ h("span", {
						className: "fr-step",
						"data-step": n.step,
						children: t(X([
							"green",
							"yellow",
							"red",
							"pirateStage"
						][n.step]))
					}),
					/* @__PURE__ */ h("span", { children: t("games.friday.level", { n: n.level }) }),
					/* @__PURE__ */ g(ve, {
						name: "life",
						className: "fr-life",
						children: [
							/* @__PURE__ */ h("span", { children: t("games.friday.life") }),
							/* @__PURE__ */ h("b", { children: n.life }),
							/* @__PURE__ */ g("small", { children: ["/ ", n.maxLife] })
						]
					})
				]
			}),
			children: [
				/* @__PURE__ */ g("div", {
					className: "fr-tabletop",
					inert: I,
					children: [
						/* @__PURE__ */ h("aside", {
							className: "fr-supplies",
							children: /* @__PURE__ */ g("div", {
								className: "fr-piles",
								children: [
									F("deck", "deck", n.deckCount),
									F("discard", "discard", n.discard.length, n.discard),
									F("hazards", "hazards", n.hazardCount),
									F("hazardDiscard", "hazardDiscard", n.hazardDiscard.length, n.hazardDiscard),
									F("aging", "aging", n.agingCount),
									F("destroyed", "destroyed", n.destroyed.length, n.destroyed)
								]
							})
						}),
						/* @__PURE__ */ g("main", {
							className: "fr-main",
							children: [/* @__PURE__ */ h("section", {
								className: "fr-encounter",
								children: n.phase === "choose" ? /* @__PURE__ */ g("div", {
									className: "fr-offers",
									children: [n.offers.map((e) => /* @__PURE__ */ h(Z, {
										id: e,
										hazard: !0,
										anchorName: `offer:${e}`,
										candidate: y,
										onChoose: y ? () => x({
											type: "choose",
											id: e
										}) : void 0,
										onInspect: () => d({
											ids: [e],
											title: t("games.friday.details"),
											hazard: !0
										})
									}, e)), n.offers.length === 1 && y && /* @__PURE__ */ h("button", {
										type: "button",
										className: "fr-text-btn",
										onClick: () => x({ type: "skip" }),
										children: t("games.friday.skip")
									})]
								}) : n.active ? /* @__PURE__ */ g("div", {
									className: "fr-active-row",
									children: [/* @__PURE__ */ h(Z, {
										id: n.active,
										hazard: !n.pirate,
										pirate: n.pirate,
										anchorName: "active",
										onInspect: () => d({
											ids: [n.active],
											title: t("games.friday.details"),
											hazard: !n.pirate,
											pirate: n.pirate
										})
									}), /* @__PURE__ */ g("div", {
										className: "fr-fight-status",
										children: [
											/* @__PURE__ */ g("div", {
												className: "fr-comparison",
												children: [
													/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("small", { children: t("games.friday.power") }), /* @__PURE__ */ h("b", { children: n.power })] }),
													/* @__PURE__ */ h("span", { children: "/" }),
													/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("small", { children: t("games.friday.target") }), /* @__PURE__ */ h("b", { children: n.target })] })
												]
											}),
											/* @__PURE__ */ h("span", { children: t("games.friday.freeCount", {
												n: n.freeUsed,
												max: n.free
											}) }),
											n.pirate && /* @__PURE__ */ h("p", { children: t(X(`pirate_${k(n.active).effect}`)) }),
											n.penalty > 0 && /* @__PURE__ */ h("p", {
												className: "fr-warning",
												children: t("games.friday.penalty", { n: n.penalty })
											}),
											n.phase === "cull" && /* @__PURE__ */ h("p", { children: t("games.friday.cullHelp") })
										]
									})]
								}) : /* @__PURE__ */ h("div", {
									className: "fr-sea-heading",
									children: t("games.friday.choosePirate")
								})
							}), /* @__PURE__ */ g("div", {
								className: "fr-battle",
								children: [/* @__PURE__ */ g("section", {
									className: "fr-lane",
									children: [/* @__PURE__ */ h("h2", { children: t("games.friday.free") }), /* @__PURE__ */ h("div", {
										className: "fr-card-grid",
										children: P(O)
									})]
								}), /* @__PURE__ */ g("section", {
									className: "fr-lane",
									children: [/* @__PURE__ */ h("h2", { children: t("games.friday.paid") }), /* @__PURE__ */ h("div", {
										className: "fr-card-grid",
										children: P(j)
									})]
								})]
							})]
						}),
						/* @__PURE__ */ h("aside", {
							className: "fr-pirates",
							children: n.pirates.map((e) => /* @__PURE__ */ g("div", {
								className: n.defeated.includes(e) ? "fr-defeated" : "",
								children: [/* @__PURE__ */ h(Z, {
									id: e,
									pirate: !0,
									anchorName: `pirate:${e}`,
									candidate: y && n.phase === "pirates" && !n.defeated.includes(e),
									onChoose: y && n.phase === "pirates" && !n.defeated.includes(e) ? () => x({
										type: "choose",
										id: e
									}) : void 0,
									onInspect: () => d({
										ids: [e],
										title: t("games.friday.pirateStage"),
										pirate: !0
									})
								}), /* @__PURE__ */ h("p", { children: t(X(`pirate_${k(e).effect}`)) })]
							}, e))
						})
					]
				}),
				y && n.pending?.kind === "sort" && /* @__PURE__ */ h("div", {
					className: "fr-modal-backdrop",
					children: /* @__PURE__ */ g("section", {
						className: "fr-modal fr-sort",
						role: "dialog",
						"aria-modal": "true",
						"aria-labelledby": "fr-sort-heading",
						children: [
							/* @__PURE__ */ h("h2", {
								id: "fr-sort-heading",
								children: t("games.friday.sortTitle")
							}),
							/* @__PURE__ */ h("p", { children: t("games.friday.sortHelp") }),
							/* @__PURE__ */ h("div", {
								className: "fr-sort-cards",
								children: T.map((e, n) => /* @__PURE__ */ g("div", {
									className: E === e ? "fr-sort-discard" : "",
									children: [/* @__PURE__ */ h(Z, {
										id: e,
										anchorName: `sort:${e}`
									}), /* @__PURE__ */ g("div", {
										className: "fr-sort-tools",
										children: [
											/* @__PURE__ */ h("button", {
												type: "button",
												disabled: n === 0,
												"aria-label": t("games.friday.sortLeft"),
												onClick: () => {
													let e = [...T];
													[e[n - 1], e[n]] = [e[n], e[n - 1]], p(e);
												},
												children: "←"
											}),
											/* @__PURE__ */ h("button", {
												type: "button",
												"aria-label": t(E === e ? "games.friday.sortKeep" : "games.friday.sortDiscard"),
												onClick: () => v(E === e ? void 0 : e),
												children: E === e ? "↶" : "×"
											}),
											/* @__PURE__ */ h("button", {
												type: "button",
												disabled: n === T.length - 1,
												"aria-label": t("games.friday.sortRight"),
												onClick: () => {
													let e = [...T];
													[e[n + 1], e[n]] = [e[n], e[n + 1]], p(e);
												},
												children: "→"
											})
										]
									})]
								}, e))
							}),
							/* @__PURE__ */ g("footer", { children: [n.pending.left > 0 && /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => x({ type: "continue" }),
								children: t("games.friday.sortDraw")
							}), /* @__PURE__ */ h("button", {
								type: "button",
								autoFocus: !0,
								className: "fr-primary",
								onClick: () => {
									x({
										type: "sortDone",
										order: T.filter((e) => e !== E),
										discard: E
									}), p([]), v(void 0);
								},
								children: t("games.friday.sortDone")
							})] })
						]
					})
				}),
				o && /* @__PURE__ */ h("div", {
					className: "fr-modal-backdrop",
					onClick: () => d(null),
					children: /* @__PURE__ */ g("section", {
						className: "fr-modal",
						role: "dialog",
						"aria-modal": "true",
						"aria-label": o.title,
						onClick: (e) => e.stopPropagation(),
						onKeyDown: (e) => {
							e.key === "Escape" && d(null);
						},
						children: [/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("h2", { children: o.title }), /* @__PURE__ */ h("button", {
							type: "button",
							autoFocus: !0,
							onClick: () => d(null),
							children: t("games.friday.close")
						})] }), o.ids.length ? /* @__PURE__ */ h("div", {
							className: "fr-inspect-grid",
							children: o.ids.map((e, n) => /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h(Z, {
								id: e,
								hazard: o.hazard,
								pirate: o.pirate
							}), o.pirate ? /* @__PURE__ */ h("p", { children: t(X(`pirate_${k(e).effect}`)) }) : o.hazard ? /* @__PURE__ */ g("p", { children: [
								t("games.friday.knowledge"),
								": ",
								D[e].power,
								" · ",
								t(X(`ability_${D[e].ability}`))
							] }) : null] }, `${e}-${n}`))
						}) : /* @__PURE__ */ h("p", { children: t("games.friday.empty") })]
					})
				})
			]
		})
	});
}
//#endregion
//#region src/games/friday/bot.ts
var be = {
	clean: 0,
	reward: 0,
	earlyLoss: 0,
	paidLimit: 3
}, xe = {
	clean: 1.8,
	reward: 1.4,
	earlyLoss: 1,
	paidLimit: 2
}, Q = (e) => ({
	destroy: 4,
	copy: 3,
	double: 2.5,
	life1: 2.5,
	life2: 4,
	draw1: 2.5,
	draw2: 4,
	exchange1: 2,
	exchange2: 3,
	sort: 2,
	below: 2,
	step: 1.5
})[e] ?? 0, $ = (e) => {
	let t = D[e];
	return t.kind === "aging" ? t.power - 4 : t.power + Q(t.ability);
};
function Se(e) {
	return ((t, n) => {
		let r = t.public, i = t.private;
		if (r.rid !== n.rid || r.phase === "done") return null;
		let a = (e) => ({ action: e }), o = r.table.filter((e) => !e.destroyed), s = [...o].sort((e, t) => $(e.id) - $(t.id) || e.id.localeCompare(t.id));
		if (r.pending) {
			if (r.pending.kind === "draw") return a({ type: "continue" });
			if (r.pending.kind === "exchange") {
				let e = s.find((e) => e.id !== r.pending.source && (D[e.id].power < 1 || D[e.id].kind === "aging" || e.used && D[e.id].power === 0));
				return a(e ? {
					type: "exchange",
					target: e.id
				} : { type: "stop" });
			}
			if (r.pending.kind === "sort") {
				if (r.pending.left > 0) return a({ type: "continue" });
				let e = [...i?.sort ?? []].sort((e, t) => $(t) - $(e)), t = e.at(-1);
				return a({
					type: "sortDone",
					order: e,
					discard: t && $(t) < 2 ? e.pop() : void 0
				});
			}
		}
		if (r.phase === "choose") {
			let t = [...r.offers].sort((t, n) => {
				let i = (t) => {
					let n = D[t];
					return n.free * 1.4 - n.hazard[r.step] + e.reward * (n.power + Q(n.ability));
				};
				return i(n) - i(t);
			})[0];
			return a({
				type: "choose",
				id: t
			});
		}
		if (r.phase === "pirates") {
			let e = r.pirates.filter((e) => !r.defeated.includes(e)), t = (e) => {
				let t = k(e);
				return t.effect === "aging" ? r.agingAdded * 2 - t.free : t.effect === "half" ? 25 : t.effect === "hazards" ? r.hazardDiscard.reduce((e, t) => e + D[t].hazard[2] - D[t].free, 0) : t.target - t.free * 1.5;
			};
			return a({
				type: "choose",
				id: e.sort((e, n) => t(e) - t(n))[0]
			});
		}
		if (r.phase === "cull") {
			let e = s.find((e) => (D[e.id].kind === "aging" ? 2 : 1) <= r.budget && ($(e.id) <= 1 || D[e.id].kind === "aging"));
			return a(e ? {
				type: "destroy",
				card: e.id
			} : { type: "next" });
		}
		if (r.phase !== "fight") return null;
		let c = o.filter((e) => !e.used && A.includes(D[e.id].ability)), l = (e, t, n) => {
			let i = s.filter((t) => t.id !== e);
			if (t === "life1" || t === "life2") return r.life < r.maxLife ? {
				type: "use",
				card: e,
				copy: n
			} : null;
			if (t === "destroy") {
				let t = i.find((e) => $(e.id) <= 1 || D[e.id].kind === "aging");
				return t ? {
					type: "use",
					card: e,
					copy: n,
					target: t.id
				} : null;
			}
			if (t === "double") {
				let t = i.filter((e) => !r.doubleTargets.includes(e.id)).sort((e, t) => r.powers[t.id] - r.powers[e.id])[0];
				return t && r.powers[t.id] > 0 ? {
					type: "use",
					card: e,
					copy: n,
					target: t.id
				} : null;
			}
			if (t === "below") {
				let t = i.find((e) => D[e.id].power < 0 || D[e.id].kind === "aging");
				return t ? {
					type: "use",
					card: e,
					copy: n,
					target: t.id
				} : null;
			}
			return t === "step" ? !r.pirate && r.step > r.steps.length && r.power < r.target ? {
				type: "use",
				card: e,
				copy: n
			} : null : t === "exchange1" || t === "exchange2" ? i.some((e) => $(e.id) <= 1 || e.used && D[e.id].power === 0) ? {
				type: "use",
				card: e,
				copy: n
			} : null : t === "draw1" || t === "draw2" || t === "sort" && r.power < r.target ? {
				type: "use",
				card: e,
				copy: n
			} : null;
		}, u = [...c].sort((e, t) => {
			let n = (e) => {
				let t = D[e].ability;
				return t === "life1" || t === "life2" ? 9 : t === "destroy" ? 8 : t === "copy" ? 5 : t === "double" ? 4 : 3;
			};
			return n(t.id) - n(e.id);
		});
		for (let e of u) if (D[e.id].ability === "copy") {
			let t = [...o].filter((t) => t.id !== e.id && D[t.id].ability !== "copy").sort((e, t) => Q(D[t.id].ability) - Q(D[e.id].ability));
			for (let n of t) {
				let t = l(e.id, D[n.id].ability, n.id);
				if (t) return a(t);
			}
		} else {
			let t = l(e.id, D[e.id].ability);
			if (t) return a(t);
		}
		if (r.table.length && r.power >= r.target) return a({ type: "finish" });
		if (r.canFree || !r.table.length) return a({ type: "draw" });
		let d = Math.max(0, r.target - r.power), f = s.filter((e) => $(e.id) <= 1).length;
		return !r.pirate && r.table.length && e.earlyLoss && r.step === 0 && d <= Math.min(4, f * e.clean) && d + r.penalty < r.life ? a({ type: "finish" }) : r.pirate || d > r.life - r.penalty || d > e.paidLimit ? a({ type: "draw" }) : a({ type: "finish" });
	});
}
var Ce = (e, t) => Se(t.difficulty === "weak" ? be : xe)(e, t), we = (e, { public: t }, n) => e.type === "choose" ? t.phase === "pirates" ? n("games.friday.choosePirate") : n("games.friday.choose") + " · " + n(`games.friday.title_${D[e.id].title}`) : e.type === "draw" ? n(t.canFree ? "games.friday.drawFree" : "games.friday.drawPaid", { n: t.drawCost }) : e.type === "use" ? n(`games.friday.ability_${D[e.copy ?? e.card].ability}`) : e.type === "finish" ? n(t.power >= t.target ? "games.friday.finishWin" : "games.friday.finishLose", { n: Math.max(0, t.target - t.power) + t.penalty }) : n(`games.friday.${{
	skip: "skip",
	continue: "continue",
	stop: "stop",
	exchange: "ability_exchange1",
	sortDone: "sortDone",
	destroy: "destroyCard",
	next: "next"
}[e.type]}`);
//#endregion
//#region src/games/friday/fx.tsx
function Te({ from: e, to: t, appearance: n, ms: r, incoming: i }) {
	let s = o(null);
	return a(() => {
		let a = s.current;
		if (!a) return;
		a.replaceChildren(n.node.cloneNode(!0));
		let o = t.x + t.w / 2 - e.x - e.w / 2, c = t.y + t.h / 2 - e.y - e.h / 2, l = e.w / n.w, u = t.w / n.w, d = a.animate([
			{
				transform: `translate(0,0) scale(${l})`,
				opacity: 1
			},
			{
				transform: `translate(${o * .55}px,${c * .55 - 14}px) scale(${l + (u - l) * .55})`,
				opacity: 1,
				offset: .55
			},
			{
				transform: `translate(${o}px,${c}px) scale(${u})`,
				opacity: +!!i
			}
		], {
			duration: r,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => d.cancel();
	}, [
		e,
		t,
		n,
		r,
		i
	]), /* @__PURE__ */ h("div", {
		ref: s,
		"data-fr-sprite": !0,
		style: {
			position: "absolute",
			left: e.x + (e.w - n.w) / 2,
			top: e.y + (e.h - n.h) / 2,
			width: n.w,
			height: n.h,
			pointerEvents: "none"
		}
	});
}
var Ee = {
	move(e, t) {
		let n = e.data, r = t.anchor(n.from), i = t.anchor(n.to);
		if (!r || !i) return null;
		let a = t.queued ? 160 : 420, o = n.to.startsWith("card:") || n.to === "active" || n.to.startsWith("sort:"), s = he(o ? n.to : n.from, !o);
		return s ? {
			ms: a,
			node: /* @__PURE__ */ h(Te, {
				from: r,
				to: i,
				appearance: s,
				ms: a,
				incoming: o
			}),
			hide: t.queued ? [] : o ? [n.to] : n.from.startsWith("card:") ? [n.from] : []
		} : null;
	},
	ability(e, t) {
		let n = t.anchor(`card:${e.data.id}`);
		return n ? {
			ms: 280,
			node: /* @__PURE__ */ h(v, {
				at: n,
				ms: 280
			})
		} : null;
	},
	life(e, t) {
		let n = t.anchor("life"), r = e.data.value;
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ h(_, {
				at: n,
				ms: 600,
				children: /* @__PURE__ */ g("span", {
					style: {
						color: r > 0 ? "#d7eda5" : "#ffb38a",
						fontSize: 22,
						fontWeight: 700
					},
					children: [r > 0 ? "+" : "", r]
				})
			})
		} : null;
	},
	victory(e, t) {
		let n = t.anchor("active");
		return n ? {
			ms: 430,
			node: /* @__PURE__ */ h(v, {
				at: n,
				ms: 430
			})
		} : null;
	}
};
//#endregion
//#region src/games/friday/game-over.tsx
function De(e) {
	let t = c(), n = e.public, [r, i] = s(!0), [a, l] = s(null), u = o(null), f = o(null), p = (e) => {
		l(null), i(e), requestAnimationFrame(() => {
			(e ? u : f).current?.focus();
		});
	}, m = () => {
		a === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.(), l(null);
	};
	return /* @__PURE__ */ g("div", {
		className: "friday fr-result-wrap",
		children: [
			/* @__PURE__ */ h("div", {
				className: "fr-result-board",
				inert: r,
				children: /* @__PURE__ */ h(ye, {
					...e,
					send: () => {}
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "fr-result-overlay",
				hidden: !r,
				children: /* @__PURE__ */ g("section", {
					className: "fr-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("session.result.title"),
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), p(!1));
					},
					children: [
						/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("strong", { children: "FRIDAY" }), /* @__PURE__ */ h("button", {
							type: "button",
							ref: u,
							"aria-label": t("games.friday.hideResult"),
							onClick: () => p(!1),
							children: "↙"
						})] }),
						/* @__PURE__ */ g("div", {
							className: "fr-result-body",
							inert: a !== null,
							children: [
								/* @__PURE__ */ h("div", {
									className: "fr-result-hero",
									children: /* @__PURE__ */ h("img", {
										src: d(`games/friday/live/art-${n.pirates[0]}.svg`),
										alt: ""
									})
								}),
								/* @__PURE__ */ h("h1", { children: t(n.won ? "games.friday.win" : "games.friday.loss") }),
								/* @__PURE__ */ h("p", {
									className: "fr-result-lead",
									children: t(n.won ? "games.friday.escaped" : n.reason === "aging" ? "games.friday.reasonAging" : "games.friday.reasonLife")
								}),
								n.score && /* @__PURE__ */ g("table", {
									"aria-label": t("games.friday.score"),
									children: [/* @__PURE__ */ h("tbody", { children: [
										"cards",
										"pirates",
										"life",
										"hazards"
									].map((e) => /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
										scope: "row",
										children: t(X(`score${e[0].toUpperCase() + e.slice(1)}`))
									}), /* @__PURE__ */ h("td", { children: n.score[e] })] }, e)) }), /* @__PURE__ */ h("tfoot", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
										scope: "row",
										children: t("games.friday.score")
									}), /* @__PURE__ */ h("td", { children: n.score.total })] }) })]
								}),
								/* @__PURE__ */ g("div", {
									className: "fr-result-meta",
									children: [
										/* @__PURE__ */ h("span", { children: t("games.friday.level", { n: n.level }) }),
										e.hintCount !== void 0 && /* @__PURE__ */ h("span", { children: t("session.hint.usedCount", { n: e.hintCount }) }),
										!!e.result.autopilot?.[n.rid] && /* @__PURE__ */ h("span", { children: t("games.friday.autopilot", { n: Math.round(e.result.autopilot[n.rid] * 100) }) })
									]
								})
							]
						}),
						a ? /* @__PURE__ */ g("div", {
							className: "fr-result-confirm",
							children: [/* @__PURE__ */ h("button", {
								type: "button",
								autoFocus: !0,
								onClick: m,
								children: t(a === "again" ? "games.friday.confirmAgain" : "games.friday.confirmLobby")
							}), /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => l(null),
								children: t("games.friday.cancel")
							})]
						}) : /* @__PURE__ */ g("footer", { children: [
							e.onBackToLobby && /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => l("lobby"),
								children: t("session.result.backToLobby")
							}),
							e.onPlayAgain && /* @__PURE__ */ h("button", {
								type: "button",
								className: "fr-primary",
								onClick: () => l("again"),
								children: t("session.result.playAgain")
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ h("span", { children: t("session.result.waitHost") })
						] })
					]
				})
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "fr-result-restore",
				ref: f,
				hidden: r,
				onClick: () => p(!0),
				children: t("games.friday.showResult")
			})
		]
	});
}
//#endregion
//#region src/games/friday/options.tsx
function Oe({ value: e, onChange: t }) {
	let n = c(), r = M.safeParse(e), i = r.success ? r.data : M.parse(void 0);
	return /* @__PURE__ */ h(b, {
		title: n("games.friday.difficulty"),
		columns: 2,
		children: [
			1,
			2,
			3,
			4
		].map((e) => /* @__PURE__ */ h(y, {
			name: "friday-level",
			value: String(e),
			label: `${n("games.friday.level", { n: e })} · ${n(X(`level${e}`))}`,
			checked: i.level === e,
			accent: "#709344",
			onChange: () => t({ level: e })
		}, e))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/friday/entry.tsx
var ke = {
	definition: pe,
	View: ye,
	bot: Ce,
	describe: we,
	fx: Ee,
	OverView: De,
	Options: Oe,
	locales: {
		zh: {
			name: "星期五",
			desc: "帮助鲁滨逊磨炼本领，战胜荒岛危机与两艘海盗船。",
			errAction: "当前无法执行这个行动。",
			level: "难度 {{n}}",
			difficulty: "难度",
			level1: "初次登岛",
			level2: "岁月渐长",
			level3: "艰难求生",
			level4: "真正挑战",
			green: "绿色阶段",
			yellow: "黄色阶段",
			red: "红色阶段",
			pirateStage: "海盗决战",
			life: "生命",
			deck: "鲁滨逊牌堆",
			discard: "鲁滨逊弃牌",
			hazards: "冒险牌堆",
			hazardDiscard: "未战胜的冒险",
			aging: "衰老牌堆",
			destroyed: "已销毁",
			choose: "选择一项冒险",
			choosePirate: "选择一艘海盗船",
			free: "免费抽牌",
			paid: "额外抽牌",
			drawFree: "抽一张免费牌",
			drawPaid: "支付 {{n}} 生命抽牌",
			finishWin: "战胜对手",
			finishLose: "认输并支付 {{n}} 生命",
			remainingDraw: "还可抽 {{n}} 张牌",
			drawFirst: "至少抽一张战斗牌后才能结算。",
			pirateDeficit: "还差 {{n}} 战斗力",
			skip: "放弃这项冒险",
			continue: "继续抽牌",
			stop: "结束这个能力",
			sortDraw: "查看下一张",
			sortDone: "按此顺序放回",
			sortTitle: "排列牌堆顶端",
			sortHelp: "从左到右依次放回牌堆顶端，可选择弃掉其中一张。",
			sortLeft: "向前移动",
			sortRight: "向后移动",
			sortDiscard: "弃掉这张牌",
			sortKeep: "保留这张牌",
			exchange: "选择要替换的牌，剩余 {{n}} 次",
			selectTarget: "选择目标牌",
			copyTarget: "选择要复制的能力",
			cancel: "取消",
			use: "使用能力",
			used: "已使用",
			turned: "已翻背",
			doubled: "战斗力翻倍",
			ignored: "不计入本次战斗力",
			cull: "可以销毁的剩余费用：{{n}}",
			cullHelp: "普通牌每张消耗 1，衰老牌每张消耗 2。",
			next: "结束清理",
			destroyCard: "销毁这张牌",
			penalty: "战斗结束时另付 {{n}} 生命",
			freeCount: "免费牌 {{n}} / {{max}}",
			power: "战斗力",
			target: "目标",
			knowledge: "获得后的能力",
			starting: "起始牌",
			agingCard: "衰老牌",
			knowledgeCard: "知识牌",
			fight: "战斗中",
			details: "查看卡牌",
			close: "关闭",
			empty: "暂无卡牌",
			watching: "正在观战",
			win: "扬帆离岛",
			loss: "荒岛上的最后一天",
			escaped: "鲁滨逊击败了两艘海盗船。",
			reasonLife: "无法支付所需生命，冒险结束。",
			reasonAging: "需要重洗牌时，衰老牌堆已经耗尽。",
			score: "冒险得分",
			scoreCards: "剩余战斗牌",
			scorePirates: "战胜海盗",
			scoreLife: "剩余生命",
			scoreHazards: "未战胜的冒险",
			hideResult: "收起结算",
			showResult: "查看结算",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			autopilot: "托管占比 {{n}}%",
			pirate_normal: "战胜这艘海盗船。",
			pirate_cost2: "每张额外牌需要支付 2 生命。",
			pirate_hazards: "目标等于剩余冒险牌的红色值之和；免费牌数等于其白框值之和。",
			pirate_aging: "开战时，每张已加入牌库的衰老牌使目标增加 2。",
			pirate_half: "仅一半战斗牌计分，向上取整；衰老牌必须计入。",
			pirate_plus: "每张已出战斗牌额外增加 1 战斗力，包括翻背的牌。",
			title_raft: "乘木筏前往沉船",
			title_island: "探索岛屿",
			title_explore: "深入探索岛屿",
			title_animals: "野生动物",
			title_cannibals: "食人族",
			title_distracted: "心不在焉",
			title_weak: "虚弱",
			title_eating: "进食",
			title_genius: "灵光乍现",
			title_focused: "专注",
			title_veryHungry: "饥肠辘辘",
			title_hungry: "饥饿",
			title_scared: "恐惧",
			title_veryTired: "筋疲力尽",
			title_stupid: "愚笨",
			title_suicidal: "自暴自弃",
			title_moronic: "迟钝",
			title_veryStupid: "十分愚笨",
			ability_none: "无特殊能力",
			ability_life1: "恢复 1 生命",
			ability_life2: "恢复 2 生命",
			ability_draw1: "额外抽 1 张牌",
			ability_draw2: "额外抽至多 2 张牌",
			ability_destroy: "销毁另一张牌",
			ability_double: "另一张牌战斗力翻倍",
			ability_copy: "复制另一张牌的能力",
			ability_step: "降低一档冒险难度",
			ability_sort: "查看并排列至多 3 张牌",
			ability_exchange1: "替换另一张牌",
			ability_exchange2: "依次替换至多 2 张牌",
			ability_below: "另一张牌放到牌堆底",
			ability_lose1: "战斗结束时失去 1 生命",
			ability_lose2: "战斗结束时失去 2 生命",
			ability_highest: "最高原始战斗力归零",
			ability_stop: "停止抽取免费牌",
			rules: "目标：\n帮助鲁滨逊战胜两个海盗。在绿色、黄色和红色三个阶段中改善牌库，迎接最后两场战斗。\n准备：\n分别将 18 张起始牌和 30 张冒险牌洗成牌堆，随机公开 2 艘海盗船。难度 1 移除「十分愚笨」，普通衰老牌洗匀放在困难衰老牌上。难度 2 起始牌库多加入一张暗衰老牌；难度 3 再加入「十分愚笨」；难度 4 同难度 3，但以 18 点生命值开始，生命值上限为 20 点。其他难度以 20 点生命值开始，生命值上限为 22 点。\n冒险：\n揭开两张冒险牌，选择一张，另一张弃掉。轮末只剩一张时可以直接弃掉。按当前阶段的颜色确定目标战斗力。\n抽牌：\n逐张抽取白框数量的免费牌，放在左侧。可以提前停止。免费牌抽完或被「停止」能力阻止后，每支付 1 点生命值，可以抽取一张额外牌，放在右侧。至少抽一张牌才能结算。即使战斗力已经足够，也可以继续抽牌和使用能力。\n能力：\n· 每张牌每场战斗可以主动使用一次，顺序自选。一个能力必须执行完才能开启另一个。恢复生命不能超过本难度的上限。额外抽牌放右侧。\n· 「销毁」将另一张牌翻背，其战斗力和持续能力取消，战后移出游戏。\n· 「翻倍」只能用于另一张牌，同一张牌每战只能翻倍一次。\n· 复制可以复制已使用过的能力，不能复制复制能力或衰老能力。\n· 降低阶段仅影响冒险牌，最低降到绿色。\n排列：\n· 逐张查看至多三张牌，可以提前停止，至多弃掉一张，其余自选顺序放回牌堆顶端。\n· 替换：将另一张已出牌弃掉，在原位置抽一张替代牌；两次替换依次完成，中间不能使用新牌的能力。\n· 置底：将另一张牌放到牌堆底，来自左侧时可以在原位置补一张。置底前牌堆必须有牌，必要时先重洗。\n衰老：\n衰老牌的负面能力强制生效。战末失去生命不能计入销毁预算。「最高归零」先按原始正战斗力选择一张，再计算翻倍；多个归零分别影响不同的最高牌。「停止」只在免费区阻止普通免费抽牌，能力抽牌不受影响。移走或销毁衰老牌会取消其持续能力。\n胜负：\n手动结束战斗，战斗力达到目标则获得该冒险牌作为知识牌，放入鲁滨逊弃牌堆。战斗力不足则支付差值生命，可以用这笔费用销毁本场已出牌：每销毁一张普通牌消耗 1 点销毁预算，每销毁一张衰老牌消耗 2 点销毁预算；不能额外支付生命扩大预算。其他牌进入鲁滨逊弃牌堆，未战胜的冒险进入冒险弃牌堆。\n重洗：\n需要抽牌而鲁滨逊牌堆为空时，将一张暗衰老牌与鲁滨逊弃牌洗成新牌堆。暗牌顺序不可查看。衰老牌耗尽后再需要重洗会失败。生命降到零仍可继续，无法支付所需生命时立即失败。\n阶段：\n冒险牌堆用完后，洗匀冒险弃牌并进入下一阶段。红色阶段结束后，自选海盗战斗顺序。必须战胜两艘海盗船，不能主动认输。海盗特殊规则写在船牌上；「半数计分」自动使用战斗力最高的合法组合，所有正面衰老牌必须计入。\n计分：\n以现存战斗牌的原始战斗力之和作为基础分数，衰老牌每张统一计为负 5 分。再按以下项目计算总分：\n· 每战胜一艘海盗船，增加 15 分。\n· 获胜时每剩余 1 点生命值，增加 5 分。\n· 冒险弃牌堆中每张未战胜的冒险牌，扣除 3 分。\n两堆弃牌、已销毁牌和三个牌堆数量可随时查看。"
		},
		en: {
			name: "Friday",
			desc: "Help Robinson build his deck, survive the island and defeat two pirate ships.",
			errAction: "This action is not available now.",
			level: "Level {{n}}",
			difficulty: "Difficulty",
			level1: "First landing",
			level2: "Growing older",
			level3: "Hard survival",
			level4: "The real challenge",
			green: "Green step",
			yellow: "Yellow step",
			red: "Red step",
			pirateStage: "Pirate battles",
			life: "Life",
			deck: "Robinson stack",
			discard: "Robinson discard",
			hazards: "Hazard stack",
			hazardDiscard: "Undefeated hazards",
			aging: "Aging stack",
			destroyed: "Destroyed",
			choose: "Choose a hazard",
			choosePirate: "Choose a pirate",
			free: "Free cards",
			paid: "Additional cards",
			drawFree: "Draw a free card",
			drawPaid: "Pay {{n}} life to draw",
			finishWin: "Win the fight",
			finishLose: "Lose and pay {{n}} life",
			remainingDraw: "Up to {{n}} more cards",
			drawFirst: "Draw at least one fighting card before ending the fight.",
			pirateDeficit: "Need {{n}} more fighting points",
			skip: "Discard this hazard",
			continue: "Draw another card",
			stop: "Finish this ability",
			sortDraw: "Look at the next card",
			sortDone: "Return in this order",
			sortTitle: "Arrange the top of the stack",
			sortHelp: "Cards return to the top from left to right. You may discard one.",
			sortLeft: "Move earlier",
			sortRight: "Move later",
			sortDiscard: "Discard this card",
			sortKeep: "Keep this card",
			exchange: "Choose a card to exchange · {{n}} remaining",
			selectTarget: "Choose a target card",
			copyTarget: "Choose an ability to copy",
			cancel: "Cancel",
			use: "Use ability",
			used: "Used",
			turned: "Turned face down",
			doubled: "Fighting value doubled",
			ignored: "Not counted in this fight",
			cull: "Remaining destruction allowance: {{n}}",
			cullHelp: "Each ordinary card costs 1; each aging card costs 2.",
			next: "Finish cleanup",
			destroyCard: "Destroy this card",
			penalty: "Pay {{n}} additional life at the end of the fight",
			freeCount: "Free cards {{n}} / {{max}}",
			power: "Fighting value",
			target: "Target",
			knowledge: "Knowledge reward",
			starting: "Starting card",
			agingCard: "Aging card",
			knowledgeCard: "Knowledge card",
			fight: "Fighting",
			details: "Inspect card",
			close: "Close",
			empty: "No cards yet",
			watching: "Spectating",
			win: "Sail away",
			loss: "The last day on the island",
			escaped: "Robinson has defeated both pirate ships.",
			reasonLife: "The required life payment could not be made.",
			reasonAging: "The aging stack ran out when another reshuffle was needed.",
			score: "Adventure score",
			scoreCards: "Remaining fighting cards",
			scorePirates: "Defeated pirates",
			scoreLife: "Remaining life",
			scoreHazards: "Undefeated hazards",
			hideResult: "Hide result",
			showResult: "Show result",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm return to lobby",
			autopilot: "Autopilot {{n}}%",
			pirate_normal: "Defeat this pirate ship.",
			pirate_cost2: "Each paid additional card costs 2 life.",
			pirate_hazards: "Target: sum of remaining hazards’ red values. Free cards: sum of their white boxes.",
			pirate_aging: "Target: 2 for each aging card added before this fight.",
			pirate_half: "Only half the cards count, rounded up. All aging cards must count.",
			pirate_plus: "Every drawn fighting card adds 1 point, including face-down cards.",
			title_raft: "With the raft to the wreck",
			title_island: "Exploring the island",
			title_explore: "Further exploring the island",
			title_animals: "Wild animals",
			title_cannibals: "Cannibals",
			title_distracted: "Distracted",
			title_weak: "Weak",
			title_eating: "Eating",
			title_genius: "Genius",
			title_focused: "Focused",
			title_veryHungry: "Very hungry",
			title_hungry: "Hungry",
			title_scared: "Scared",
			title_veryTired: "Very tired",
			title_stupid: "Stupid",
			title_suicidal: "Suicidal",
			title_moronic: "Moronic",
			title_veryStupid: "Very stupid",
			ability_none: "No special ability",
			ability_life1: "Recover 1 life",
			ability_life2: "Recover 2 life",
			ability_draw1: "Draw 1 additional card",
			ability_draw2: "Draw up to 2 additional cards",
			ability_destroy: "Destroy another card",
			ability_double: "Double another card",
			ability_copy: "Copy another card’s ability",
			ability_step: "Reduce the hazard by one step",
			ability_sort: "Look at and sort up to 3 cards",
			ability_exchange1: "Exchange another card",
			ability_exchange2: "Exchange up to 2 cards, one at a time",
			ability_below: "Place another card below the stack",
			ability_lose1: "Lose 1 life at the end of the fight",
			ability_lose2: "Lose 2 life at the end of the fight",
			ability_highest: "Highest original fighting value becomes 0",
			ability_stop: "Stop drawing free cards",
			rules: "Goal:\nHelp Robinson improve his deck through the green, yellow and red steps, then defeat both pirates.\nSetup:\nShuffle 18 starting cards and 30 hazards. Reveal 2 random pirates. For level 1, remove Very stupid; shuffle normal aging cards above the separately shuffled difficult cards. Level 2 adds one unseen aging card to the starting deck. Level 3 includes Very stupid. Level 4 uses the level 3 setup but starts with 18 life and a maximum of 20; other levels start with 20 and have a maximum of 22.\nHazards:\nReveal two and choose one; discard the other. A final single hazard may be discarded without fighting. The current step colour determines the target.\nDraw:\nDraw free fighting cards one at a time, up to the white-box number, on the left. You may stop early. After free draws are exhausted or stopped, each additional card costs 1 life and goes on the right. At least one fighting card must be drawn before ending a fight. Reaching the target never ends a fight automatically.\nAbilities:\n· Use each face-up card once per fight, in any order, completing one ability before starting another. Healing is limited by the level’s life supply. Ability draws go on the right.\n· Destroy turns another card face down, cancelling its points and ongoing effects; remove it after the fight.\n· Double affects another card, at most once per target per fight.\n· Copy may reuse an already-used ability but cannot copy Copy or an aging ability.\n· Step reduction only affects hazards, down to green.\nSort:\n· Look at up to three cards one by one, discard at most one, then return the others in any order.\n· Exchange discards another played card and draws its replacement in the same position. Complete both exchanges before using any newly drawn ability.\n· Below the stack moves another card to the bottom; a card from the free side may be replaced in its original position. If the stack is empty, reshuffle before placing the card below it.\nAging:\nNegative abilities are compulsory. End-of-fight life costs do not increase the destruction allowance. Highest card = 0 affects one card with the highest original positive value before doubling; multiple such effects affect distinct cards. Stop prevents ordinary free draws only while on the free side; ability draws remain possible. Removing or destroying an aging card cancels its ongoing effect.\nFight result:\nEnd manually. Meet the target to gain the hazard as a knowledge card in your Robinson discard. Otherwise pay the shortfall in life and use that amount to destroy played cards: destroying an ordinary card uses 1 point of this allowance, and destroying an aging card uses 2. You cannot pay extra life to increase this allowance. Discard remaining fighting cards; undefeated hazards enter the hazard discard.\nReshuffle:\nOnly when another card is needed and the Robinson stack is empty, shuffle the Robinson discard with one unseen aging card. You lose if another reshuffle is required after aging cards run out. Zero life is allowed; an unaffordable required payment loses immediately.\nSteps:\nWhen the hazard stack runs out, shuffle its discard for the next colour. After red, choose which pirate to fight first. Both must be defeated; pirates cannot be deliberately lost. Ship cards show their special rules. The half-counting pirate automatically uses the strongest legal combination, including all face-up aging cards.\nScore:\nSum original values of all remaining fighting cards (each aging card is −5), add 15 per defeated pirate and 5 per life remaining in a win, then subtract 3 per undefeated hazard in the hazard discard. Both discard piles, destroyed cards and all three stack counts may be inspected at any time."
		}
	}
};
//#endregion
export { ke as default };
