import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useT as o } from "@bgparty/sdk/i18n";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { Fragment as l, jsx as u, jsxs as d } from "react/jsx-runtime";
import { FlySprite as f, PulseBox as p } from "@bgparty/sdk/fx/primitives";
//#region src/games/gotfive/meta.ts
var m = {
	id: "gotfive",
	tier: "alpha",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.gotfive.name",
	descKey: "games.gotfive.desc",
	rulesKey: "games.gotfive.rules",
	icon: "🔢",
	iconImg: "games/gotfive.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	accent: "#932486",
	releasedAt: "2026-11-02T15:55:00+08:00",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/9521153913773157988/CD3C8D38BDD29C718E55408E0CBC226F9385C4DF/" },
	search: {
		py: "wu cai bin fen",
		init: "wcbf"
	},
	hotseat: "cover"
}, h = t.int().min(1).max(60), g = t.int().min(0).max(4), _ = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draw"),
		color: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("categorise"),
		tile: h
	}),
	t.object({
		type: t.literal("compare"),
		tile: h,
		slot: g
	}),
	t.object({
		type: t.literal("guess"),
		numbers: t.array(h).length(5)
	})
]), v = t.discriminatedUnion("type", [t.object({
	type: t.literal("categorise"),
	rid: t.string(),
	tile: h,
	notch: t.int().min(0).max(5)
}), t.object({
	type: t.literal("compare"),
	rid: t.string(),
	tile: h,
	slot: g,
	equal: t.boolean()
})]), y = t.object({
	phase: t.enum([
		"draw",
		"ask",
		"exhausted",
		"done"
	]),
	activeRid: t.string(),
	turn: t.int().positive(),
	players: t.array(t.object({
		rid: t.string(),
		colors: t.array(t.int().min(0).max(4)).length(5),
		eliminated: t.boolean()
	})),
	supply: t.array(t.int().min(0).max(12)).length(5),
	pool: t.array(h).max(6),
	clues: t.array(v),
	guesses: t.array(t.object({
		rid: t.string(),
		numbers: t.array(h).length(5),
		correct: t.boolean()
	})),
	winner: t.string().nullable(),
	finalRacks: t.record(t.string(), t.array(h).length(5)).nullable()
}), b = t.object({ visibleRacks: t.record(t.string(), t.array(h).length(5)) }), x = [
	"green",
	"pink",
	"blue",
	"red",
	"orange"
], S = [
	"#55ad59",
	"#cd8cb9",
	"#67acc5",
	"#d83b3d",
	"#f4b13d"
], C = [
	"#009347",
	"#de88b9",
	"#4aa8c8",
	"#dc1f26",
	"#f39d1f"
], w = Array.from({ length: 60 }, (e, t) => t + 1), T = (e) => (e - 1) % 5, E = (e) => Math.floor((e - 1) / 5) % 3 + 1;
//#endregion
//#region src/games/gotfive/rules.ts
function D(t, n, r) {
	let i = [...w], a = 0;
	for (let t = i.length - 1; t > 0; t--) {
		let n = e(r, a++, t + 1);
		[i[t], i[n]] = [i[n], i[t]];
	}
	let o = (e) => i.splice(i.findIndex((t) => T(t) === e), 1)[0], s = Object.fromEntries(n.map((e) => [e, Array.from({ length: 5 }, (e, t) => o(t)).sort((e, t) => e - t)])), c = Array.from({ length: 5 }, (e, t) => o(t));
	return {
		state: {
			players: [...n],
			racks: s,
			deck: i,
			pool: c,
			clues: [],
			guesses: [],
			eliminated: [],
			phase: "draw",
			active: 0,
			turn: 1,
			winner: null
		},
		fx: n.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: { colors: s[e].map(T) },
			...t ? { with: !0 } : {}
		}))
	};
}
function O(e) {
	do
		e.active = (e.active + 1) % e.players.length;
	while (e.eliminated.includes(e.players[e.active]));
	e.turn++, e.phase = e.pool.length === 6 ? "ask" : e.deck.length ? "draw" : "exhausted";
}
function k(e, t, { by: n }) {
	let r = () => ({ code: "games.gotfive.invalid" });
	if (e.phase === "done" || !e.players.includes(n) || e.eliminated.includes(n) || t.type !== "guess" && e.players[e.active] !== n) return r();
	let i = structuredClone(e);
	if (t.type === "guess") {
		if (t.numbers.some((e, n) => n > 0 && e <= t.numbers[n - 1])) return r();
		let e = t.numbers.every((e, t) => e === i.racks[n][t]);
		if (i.guesses.push({
			rid: n,
			numbers: [...t.numbers],
			correct: e
		}), e) i.winner = n;
		else {
			i.eliminated.push(n);
			let e = i.players.filter((e) => !i.eliminated.includes(e));
			e.length === 1 ? i.winner = e[0] : i.players[i.active] === n && O(i);
		}
		return i.winner && (i.phase = "done"), {
			state: i,
			fx: [{
				kind: "guess",
				rid: n,
				data: {
					correct: e,
					ended: i.phase === "done"
				}
			}]
		};
	}
	if (t.type === "draw") {
		if (i.phase !== "draw") return r();
		let e = i.deck.findIndex((e) => T(e) === t.color);
		if (e < 0) return r();
		let a = i.deck.splice(e, 1)[0];
		return i.pool.push(a), i.phase = "ask", {
			state: i,
			fx: [{
				kind: "draw",
				rid: n,
				data: {
					tile: a,
					color: t.color
				}
			}]
		};
	}
	if (i.phase !== "ask" || !i.pool.includes(t.tile)) return r();
	let a = i.pool.indexOf(t.tile);
	i.pool = i.pool.filter((e) => e !== t.tile);
	let o = t.type === "categorise" ? {
		type: "categorise",
		rid: n,
		tile: t.tile,
		notch: i.racks[n].filter((e) => e < t.tile).length
	} : {
		type: "compare",
		rid: n,
		tile: t.tile,
		slot: t.slot,
		equal: E(t.tile) === E(i.racks[n][t.slot])
	};
	return i.clues.push(o), O(i), {
		state: i,
		fx: [{
			kind: "clue",
			rid: n,
			data: {
				tile: t.tile,
				poolIndex: a,
				index: i.clues.length - 1
			}
		}]
	};
}
var A = {
	meta: m,
	saveCompatibility: { version: "1" },
	schemas: {
		action: _,
		publicView: y,
		privateView: b
	},
	setup: D,
	reduce: k,
	viewFor(e, t) {
		return {
			public: {
				phase: e.phase,
				activeRid: e.players[e.active],
				turn: e.turn,
				players: e.players.map((t) => ({
					rid: t,
					colors: e.racks[t].map(T),
					eliminated: e.eliminated.includes(t)
				})),
				supply: Array.from({ length: 5 }, (t, n) => e.deck.filter((e) => T(e) === n).length),
				pool: e.pool,
				clues: e.clues,
				guesses: e.guesses,
				winner: e.winner,
				finalRacks: e.phase === "done" ? e.racks : null
			},
			private: { visibleRacks: Object.fromEntries(e.players.filter((n) => n !== t && e.players.includes(t)).map((t) => [t, e.racks[t]])) }
		};
	},
	status(e) {
		return e.winner ? {
			phase: "done",
			winner: [e.winner],
			ranking: [e.winner, ...e.players.filter((t) => t !== e.winner)],
			scores: Object.fromEntries(e.players.map((t) => [t, +(t === e.winner)]))
		} : { phase: e.phase };
	}
};
//#endregion
//#region src/games/gotfive/tile.tsx
function j({ color: e }) {
	let t = "#511447";
	return e === 0 ? /* @__PURE__ */ d("g", {
		fill: "white",
		children: [/* @__PURE__ */ u("path", { d: "M9 24H39A15 13 0 0 1 9 24ZM45 24H75A15 13 0 0 1 45 24Z" }), /* @__PURE__ */ u("path", {
			d: "M23 24H35A6 6 0 0 1 23 24ZM53 24H65A6 6 0 0 1 53 24Z",
			fill: t
		})]
	}) : e === 1 ? /* @__PURE__ */ u("g", { children: [29, 60].map((e) => /* @__PURE__ */ d("g", {
		fill: "white",
		children: [
			/* @__PURE__ */ u("circle", {
				cx: e,
				cy: "25",
				r: "12"
			}),
			Array.from({ length: 8 }, (t, n) => /* @__PURE__ */ u("circle", {
				cx: e + Math.cos(n * Math.PI / 4) * 11,
				cy: 25 + Math.sin(n * Math.PI / 4) * 11,
				r: "4.5"
			}, n)),
			/* @__PURE__ */ u("circle", {
				cx: e,
				cy: "25",
				r: "5.5",
				fill: t
			})
		]
	}, e)) }) : e === 2 ? /* @__PURE__ */ d("g", {
		fill: "white",
		children: [/* @__PURE__ */ u("path", { d: "M29 10L44 25 29 40 14 25ZM61 10L76 25 61 40 46 25Z" }), /* @__PURE__ */ u("path", {
			d: "M29 10L40 21 29 32 18 21ZM61 10L72 21 61 32 50 21Z",
			fill: t
		})]
	}) : e === 3 ? /* @__PURE__ */ d("g", {
		fill: "white",
		children: [
			/* @__PURE__ */ u("circle", {
				cx: "29",
				cy: "25",
				r: "13"
			}),
			/* @__PURE__ */ u("ellipse", {
				cx: "22",
				cy: "25",
				rx: "7",
				ry: "10",
				fill: t
			}),
			/* @__PURE__ */ u("path", { d: "M47 25H77A15 13 0 0 1 47 25Z" }),
			/* @__PURE__ */ u("path", {
				d: "M57 25H70A6.5 8 0 0 1 57 25Z",
				fill: t
			})
		]
	}) : /* @__PURE__ */ d("g", {
		fill: "white",
		children: [/* @__PURE__ */ u("path", { d: "M23 41V18A9 9 0 0 1 41 18V41ZM49 41V18A9 9 0 0 1 67 18V41Z" }), /* @__PURE__ */ u("path", {
			d: "M28 41V32A4 4 0 0 1 36 32V41ZM54 41V32A4 4 0 0 1 62 32V41Z",
			fill: t
		})]
	});
}
function M({ n: e, color: t, selected: n = !1, crossed: r = !1, legal: i = !1 }) {
	let a = e ? E(e) : 0;
	return /* @__PURE__ */ d("svg", {
		className: "gf-tile",
		viewBox: "0 0 90 88",
		"aria-hidden": "true",
		"data-selected": n,
		children: [
			/* @__PURE__ */ u("path", {
				d: "M14 3H76Q87 3 87 16V73Q87 85 75 85H15Q3 85 3 73V16Q3 3 14 3Z",
				fill: e ? S[t] : C[t],
				stroke: "#511447",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ u("path", {
				d: "M12 17Q12 10 20 10H71",
				fill: "none",
				stroke: "#fff",
				strokeOpacity: ".38",
				strokeWidth: "3",
				strokeLinecap: "round"
			}),
			e ? /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("text", {
				x: "45",
				y: "57",
				textAnchor: "middle",
				fill: "#fff5ce",
				stroke: "#511447",
				strokeWidth: "5",
				paintOrder: "stroke",
				fontFamily: "Arial Rounded MT Bold,Arial,sans-serif",
				fontSize: "47",
				fontWeight: "900",
				children: e
			}), Array.from({ length: a }, (e, t) => /* @__PURE__ */ u("circle", {
				cx: 45 + (t - (a - 1) / 2) * 13,
				cy: "72",
				r: "4",
				fill: "#fff5ce",
				stroke: "#511447",
				strokeWidth: "1.6"
			}, t))] }) : /* @__PURE__ */ u(j, { color: t }),
			r && /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("path", {
				d: "M13 12L77 77M77 12L13 77",
				stroke: "#fff5ce",
				strokeWidth: "9"
			}), /* @__PURE__ */ u("path", {
				d: "M13 12L77 77M77 12L13 77",
				stroke: "#511447",
				strokeWidth: "4"
			})] }),
			i && /* @__PURE__ */ u("rect", {
				x: "2",
				y: "2",
				width: "86",
				height: "84",
				rx: "13",
				fill: "none",
				stroke: "white",
				strokeWidth: "3",
				strokeDasharray: "6 5",
				children: /* @__PURE__ */ u("animate", {
					attributeName: "stroke-dashoffset",
					from: "0",
					to: "-22",
					dur: ".8s",
					repeatCount: "indefinite"
				})
			})
		]
	});
}
//#endregion
//#region src/games/gotfive/view-player.tsx
var N = [
	"games.gotfive.green",
	"games.gotfive.pink",
	"games.gotfive.blue",
	"games.gotfive.red",
	"games.gotfive.orange"
];
function P({ n: e, color: t, selected: n, onClick: r, disabled: i, legal: a, crossed: o, label: c, anchor: l }) {
	let { ref: d, hidden: f } = s(l);
	return /* @__PURE__ */ u("button", {
		ref: d,
		type: "button",
		className: "gf-piece",
		style: f ? { opacity: 0 } : void 0,
		"aria-label": c,
		"aria-pressed": r ? !!(n || o) : void 0,
		disabled: i || !r,
		onClick: r,
		"data-selected": n,
		children: /* @__PURE__ */ u(M, {
			n: e,
			color: t,
			selected: n,
			crossed: o,
			legal: a
		})
	});
}
function F({ rid: e, colors: t, numbers: n, clues: r, name: i, compare: a, onCompare: c, eliminated: l }) {
	let f = o(), { ref: p } = s(`rack:${e}`);
	return /* @__PURE__ */ d("section", {
		className: "gf-rack",
		ref: p,
		"data-eliminated": l,
		children: [
			/* @__PURE__ */ d("header", { children: [
				/* @__PURE__ */ u("strong", { children: i }),
				l && /* @__PURE__ */ u("span", { children: f("games.gotfive.lost") }),
				/* @__PURE__ */ u("span", {
					"aria-hidden": "true",
					children: "− → +"
				})
			] }),
			/* @__PURE__ */ u("div", {
				className: "gf-rack-tiles",
				children: t.map((t, r) => /* @__PURE__ */ u(P, {
					anchor: `rack:${e}:${r}`,
					color: t,
					n: n?.[r],
					legal: a,
					onClick: a ? () => c?.(r) : void 0,
					label: n ? f("games.gotfive.tile", {
						color: f(N[t]),
						n: n[r],
						dots: E(n[r])
					}) : f("games.gotfive.hidden", {
						n: r + 1,
						color: f(N[t])
					})
				}, r))
			}),
			/* @__PURE__ */ u("div", {
				className: "gf-notches",
				children: Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ u("div", {
					className: "gf-notch",
					"aria-label": f("games.gotfive.notch", { n: t + 1 }),
					children: r.filter((e) => e.type === "categorise" && e.notch === t).map((e) => /* @__PURE__ */ u(I, {
						clue: e,
						index: r.indexOf(e)
					}, e.tile))
				}, t))
			}),
			/* @__PURE__ */ u("div", {
				className: "gf-comparisons",
				children: Array.from({ length: 5 }, (e, t) => /* @__PURE__ */ u("div", { children: r.filter((e) => e.type === "compare" && e.slot === t).map((e) => /* @__PURE__ */ u(I, {
					clue: e,
					index: r.indexOf(e)
				}, e.tile)) }, t))
			})
		]
	});
}
function I({ clue: e }) {
	let t = o(), { ref: n, hidden: r } = s(`clue:${e.tile}`), i = t("games.gotfive.tile", {
		n: e.tile,
		color: t(N[T(e.tile)]),
		dots: E(e.tile)
	}), a = e.type === "compare" ? t(e.equal ? "games.gotfive.equal" : "games.gotfive.different") : "";
	return /* @__PURE__ */ d("div", {
		ref: n,
		className: "gf-clue",
		role: "img",
		"aria-label": `${i}${a ? `，${a}` : ""}`,
		style: r ? { opacity: 0 } : void 0,
		"data-no": e.type === "compare" && !e.equal,
		title: a || void 0,
		children: [/* @__PURE__ */ u(M, {
			n: e.tile,
			color: T(e.tile)
		}), e.type === "compare" && /* @__PURE__ */ u("b", { children: e.equal ? "=" : "×" })]
	});
}
function L({ index: e, children: t }) {
	let { ref: n } = s(`pool-slot:${e}`);
	return /* @__PURE__ */ u("div", {
		className: "gf-pool-slot",
		ref: n,
		children: t
	});
}
function R(e) {
	let [t, n] = a({});
	return /* @__PURE__ */ u(z, {
		...e,
		marks: t[e.myRid] ?? [],
		onMarksChange: (t) => n((n) => ({
			...n,
			[e.myRid]: t
		}))
	}, e.myRid);
}
function z({ public: e, private: t, members: r, myRid: l, send: f, review: p = !1, marks: m = [], onMarksChange: h }) {
	let g = e, _ = t, v = o(), [y, b] = a(null), [S, C] = a(null), [D, O] = a(!1), [k, A] = a([
		"",
		"",
		"",
		"",
		""
	]), [j, M] = a(!1), [I, R] = a(!1), z = i(null), B = i(null), { ref: V } = s("pool"), H = g.players.find((e) => e.rid === l), U = g.activeRid === l && !H?.eliminated && !p, W = g.phase === "ask" && U && y !== null && g.pool.includes(y) ? y : null, G = W !== null && S === W;
	n(() => {
		G && z.current?.scrollIntoView({
			block: "nearest",
			behavior: "smooth"
		});
	}, [G]), n(() => {
		if (!D) return;
		let e = B.current, t = document.activeElement;
		return e?.showModal(), () => {
			e?.close(), t?.focus();
		};
	}, [D]);
	let K = /* @__PURE__ */ new Set([
		...Object.values(_?.visibleRacks ?? {}).flat(),
		...g.pool,
		...g.clues.map((e) => e.tile),
		...Object.values(g.finalRacks ?? {}).flat()
	]), q = (e) => r.find((t) => t.rid === e)?.name ?? e, J = (e) => v("games.gotfive.tile", {
		n: e,
		color: v(N[T(e)]),
		dots: E(e)
	}), Y = () => {
		if (Z && !p) {
			if (!j) {
				M(!0);
				return;
			}
			f({
				type: "guess",
				numbers: k.map(Number)
			}), O(!1), M(!1);
		}
	}, X = k.map(Number), Z = X.every((e, t) => Number.isInteger(e) && e >= 1 && e <= 60 && (t === 0 || e > X[t - 1]));
	return /* @__PURE__ */ d(c, {
		adaptive: !0,
		scroll: !1,
		className: "gf-screen",
		banner: /* @__PURE__ */ d("header", {
			className: "gf-banner",
			children: [
				/* @__PURE__ */ u("b", { children: v("games.gotfive.name") }),
				/* @__PURE__ */ u("span", { children: v("games.gotfive.turn", { n: g.turn }) }),
				/* @__PURE__ */ u("strong", { children: p ? v("games.gotfive.review") : H?.eliminated ? v("games.gotfive.eliminated") : g.phase === "exhausted" ? v("games.gotfive.exhausted") : U ? v(g.phase === "draw" ? "games.gotfive.draw" : "games.gotfive.ask") : v("games.gotfive.waiting", { name: q(g.activeRid) }) })
			]
		}),
		actionsHeight: "gf-actions-height",
		actions: /* @__PURE__ */ d("div", {
			className: "gf-footer",
			children: [/* @__PURE__ */ u("span", { children: G ? v("games.gotfive.compareTarget") : "" }), !p && /* @__PURE__ */ u("button", {
				className: "gf-button gf-call",
				disabled: !H || H.eliminated || g.phase === "done",
				onClick: () => {
					O(!0), M(!1);
				},
				children: v("games.gotfive.guess")
			})]
		}),
		children: [/* @__PURE__ */ d("div", {
			className: "gf-worktable",
			children: [/* @__PURE__ */ d("div", {
				className: "gf-shared",
				children: [
					/* @__PURE__ */ u("div", {
						className: "gf-opponents",
						children: g.players.filter((e) => e.rid !== l).map((e) => /* @__PURE__ */ u(F, {
							rid: e.rid,
							name: q(e.rid),
							colors: e.colors,
							numbers: g.finalRacks?.[e.rid] ?? _?.visibleRacks[e.rid],
							clues: g.clues.filter((t) => t.rid === e.rid),
							eliminated: e.eliminated
						}, e.rid))
					}),
					/* @__PURE__ */ d("section", {
						className: "gf-supply",
						children: [/* @__PURE__ */ u("h2", { children: v("games.gotfive.supply") }), /* @__PURE__ */ u("div", {
							className: "gf-supply-tiles",
							children: x.map((e, t) => /* @__PURE__ */ d("div", { children: [/* @__PURE__ */ u(P, {
								color: t,
								anchor: `supply:${t}`,
								disabled: !U || g.phase !== "draw" || !g.supply[t],
								onClick: () => f({
									type: "draw",
									color: t
								}),
								legal: U && g.phase === "draw" && g.supply[t] > 0,
								label: v("games.gotfive.drawColor", {
									color: v(N[t]),
									n: g.supply[t]
								})
							}), /* @__PURE__ */ u("b", { children: g.supply[t] })] }, t))
						})]
					}),
					/* @__PURE__ */ d("section", {
						className: "gf-pool",
						ref: V,
						children: [
							/* @__PURE__ */ u("h2", { children: v("games.gotfive.pool") }),
							/* @__PURE__ */ u("div", {
								className: "gf-pool-tiles",
								children: Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ u(L, {
									index: t,
									children: g.pool[t] !== void 0 && /* @__PURE__ */ u(P, {
										n: g.pool[t],
										color: T(g.pool[t]),
										anchor: `pool:${g.pool[t]}`,
										selected: W === g.pool[t],
										disabled: !U || g.phase !== "ask",
										onClick: () => {
											b(g.pool[t]), C(null);
										},
										legal: U && g.phase === "ask",
										label: J(g.pool[t])
									})
								}, t))
							}),
							/* @__PURE__ */ d("div", {
								className: "gf-question-tools",
								children: [/* @__PURE__ */ u("button", {
									className: "gf-button",
									disabled: W === null,
									onClick: () => {
										f({
											type: "categorise",
											tile: W
										}), b(null);
									},
									children: v("games.gotfive.categorise")
								}), /* @__PURE__ */ u("button", {
									className: "gf-button",
									"aria-pressed": G,
									disabled: W === null,
									onClick: () => C(G ? null : W),
									children: v("games.gotfive.compare")
								})]
							})
						]
					})
				]
			}), /* @__PURE__ */ d("div", {
				className: "gf-personal",
				children: [/* @__PURE__ */ u("div", {
					ref: z,
					children: H && /* @__PURE__ */ u(F, {
						rid: l,
						name: v("games.gotfive.myRack"),
						colors: H.colors,
						numbers: g.finalRacks?.[l],
						eliminated: H.eliminated,
						clues: g.clues.filter((e) => e.rid === l),
						compare: G && !p,
						onCompare: (e) => {
							f({
								type: "compare",
								tile: W,
								slot: e
							}), b(null), C(null);
						}
					})
				}), /* @__PURE__ */ d("section", {
					className: "gf-notebook",
					children: [/* @__PURE__ */ d("header", { children: [/* @__PURE__ */ u("h2", { children: v("games.gotfive.notebook") }), !p && /* @__PURE__ */ u("button", {
						className: "gf-text-button",
						onClick: () => {
							I ? (h?.([]), R(!1)) : R(!0);
						},
						children: v(I ? "games.gotfive.clearConfirm" : "games.gotfive.clear")
					})] }), /* @__PURE__ */ u("div", {
						className: "gf-number-grid",
						children: w.map((e) => /* @__PURE__ */ u(P, {
							n: e,
							color: T(e),
							anchor: `note:${e}`,
							label: J(e),
							disabled: K.has(e) || p,
							crossed: K.has(e) || m.includes(e),
							onClick: () => {
								h?.(m.includes(e) ? m.filter((t) => t !== e) : [...m, e]), R(!1);
							}
						}, e))
					})]
				})]
			})]
		}), D && /* @__PURE__ */ d("dialog", {
			ref: B,
			"aria-labelledby": "gf-guess-title",
			className: "gf-modal",
			onCancel: () => O(!1),
			children: [
				/* @__PURE__ */ u("h2", {
					id: "gf-guess-title",
					children: v("games.gotfive.guessTitle")
				}),
				/* @__PURE__ */ u("p", { children: v("games.gotfive.guessWarning") }),
				/* @__PURE__ */ u("div", {
					className: "gf-guess-inputs",
					children: k.map((e, t) => /* @__PURE__ */ d("label", { children: [/* @__PURE__ */ u("span", { children: t + 1 }), /* @__PURE__ */ u("input", {
						"aria-label": v("games.gotfive.slot", { n: t + 1 }),
						inputMode: "numeric",
						type: "number",
						min: "1",
						max: "60",
						value: e,
						onChange: (e) => {
							A((n) => n.map((n, r) => t === r ? e.target.value : n)), M(!1);
						}
					})] }, t))
				}),
				/* @__PURE__ */ u("p", {
					className: "gf-guess-validation",
					children: !Z && v("games.gotfive.invalidGuess")
				}),
				/* @__PURE__ */ d("div", {
					className: "gf-modal-actions",
					children: [/* @__PURE__ */ u("button", {
						className: "gf-button",
						onClick: () => O(!1),
						children: v("games.gotfive.cancel")
					}), /* @__PURE__ */ u("button", {
						className: `gf-button ${j ? "danger-stripes" : ""}`,
						disabled: !Z,
						onClick: Y,
						children: v(j ? "games.gotfive.confirm" : "games.gotfive.guess")
					})]
				})
			]
		})]
	});
}
//#endregion
//#region src/games/gotfive/solver.ts
function B(e, t, n) {
	let r = e.players.find((e) => e.rid === n)?.colors;
	if (!r) return [];
	let i = /* @__PURE__ */ new Set([
		...Object.values(t.visibleRacks).flat(),
		...e.pool,
		...e.clues.map((e) => e.tile)
	]), a = e.clues.filter((e) => e.rid === n), o = r.map((e, t) => w.filter((n) => T(n) === e && !i.has(n) && a.every((e) => e.type === "categorise" ? t < e.notch ? n < e.tile : n > e.tile : e.slot !== t || E(n) === E(e.tile) === e.equal))), s = [], c = [];
	function l(e) {
		if (e === 5) {
			s.push([...c]);
			return;
		}
		for (let t of o[e]) e && t <= c[e - 1] || (c.push(t), l(e + 1), c.pop());
	}
	return l(0), s;
}
function V(e, t, n) {
	let r = {
		type: "categorise",
		tile: t[0]
	}, i = Infinity;
	for (let a of t) {
		let t = [{
			type: "categorise",
			tile: a
		}, ...Array.from({ length: 5 }, (e, t) => ({
			type: "compare",
			tile: a,
			slot: t
		}))];
		for (let o of t) {
			let t = /* @__PURE__ */ new Map();
			for (let n of e) {
				let e = o.type === "compare" ? Number(E(n[o.slot]) === E(a)) : n.filter((e) => e < a).length;
				t.set(e, (t.get(e) ?? 0) + 1);
			}
			let s = n ? [...t.values()].reduce((e, t) => e + t * t, 0) : Math.max(...t.values());
			s < i && (i = s, r = o);
		}
	}
	return r;
}
//#endregion
//#region src/games/gotfive/bot.ts
function H(e, t, n, r = !1) {
	if (e.phase === "done" || e.players.find((e) => e.rid === n)?.eliminated) return null;
	let i = B(e, t, n);
	if (i.length === 1) return {
		type: "guess",
		numbers: i[0]
	};
	if (e.activeRid !== n) return null;
	if (e.phase === "ask") return V(i, e.pool, r);
	if (e.phase === "draw") {
		let n = /* @__PURE__ */ new Set([
			...Object.values(t.visibleRacks).flat(),
			...e.pool,
			...e.clues.map((e) => e.tile)
		]), r = e.supply.findIndex((e) => e > 0), a = -Infinity;
		for (let t = 0; t < 5; t++) {
			if (!e.supply[t]) continue;
			let o = w.filter((e) => T(e) === t && !n.has(e)), s = o.reduce((e, t) => e + i.filter((e) => e.includes(t)).length, 0) / Math.max(1, o.length);
			s > a && (a = s, r = t);
		}
		return r < 0 ? null : {
			type: "draw",
			color: r
		};
	}
	return null;
}
var U = ({ public: e, private: t }, n) => {
	if (!t) return null;
	let r = H(e, t, n.rid);
	return r ? { action: r } : null;
};
//#endregion
//#region src/games/gotfive/fx.tsx
function W({ tile: e, width: t, ms: n }) {
	let a = i(null), o = i(null);
	return r(() => {
		let e = a.current?.animate([{ transform: "scaleX(1)" }, { transform: "scaleX(0)" }], {
			duration: n / 2,
			fill: "forwards",
			easing: "ease-in"
		}), t = o.current?.animate([{ transform: "scaleX(0)" }, { transform: "scaleX(1)" }], {
			duration: n / 2,
			delay: n / 2,
			fill: "both",
			easing: "ease-out"
		});
		return () => {
			e?.cancel(), t?.cancel();
		};
	}, [n]), /* @__PURE__ */ d("div", {
		style: {
			width: t,
			position: "relative",
			aspectRatio: "90 / 88"
		},
		children: [/* @__PURE__ */ u("div", {
			ref: a,
			style: {
				position: "absolute",
				inset: 0
			},
			children: /* @__PURE__ */ u(M, { color: T(e) })
		}), /* @__PURE__ */ u("div", {
			ref: o,
			style: {
				position: "absolute",
				inset: 0
			},
			children: /* @__PURE__ */ u(M, {
				color: T(e),
				n: e
			})
		})]
	});
}
var G = {
	deal(e, t) {
		let n = e.data, r = [];
		return {
			ms: 600,
			node: n.colors.map((n, i) => {
				let a = t.anchor(`supply:${n}`), o = `rack:${e.rid}:${i}`, s = t.anchor(o);
				return !a || !s ? null : (r.push(o), /* @__PURE__ */ u(f, {
					from: a,
					to: s,
					ms: 400,
					delay: i * 45,
					children: /* @__PURE__ */ u("div", {
						style: { width: s.w },
						children: /* @__PURE__ */ u(M, { color: n })
					})
				}, i));
			}),
			hide: r
		};
	},
	draw(e, t) {
		let { tile: n, color: r } = e.data, i = t.anchor(`supply:${r}`), a = t.anchor(`pool:${n}`);
		return !i || !a ? null : {
			ms: 450,
			hide: [`pool:${n}`],
			node: /* @__PURE__ */ u(f, {
				from: i,
				to: a,
				ms: 450,
				children: /* @__PURE__ */ u(W, {
					tile: n,
					width: a.w,
					ms: 450
				})
			})
		};
	},
	clue(e, t) {
		let { tile: n, poolIndex: r } = e.data, i = t.anchor(`pool-slot:${r}`), a = t.anchor(`clue:${n}`);
		return !i || !a ? null : {
			ms: 450,
			hide: [`clue:${n}`],
			node: /* @__PURE__ */ u(f, {
				from: i,
				to: a,
				ms: 450,
				children: /* @__PURE__ */ u("div", {
					style: { width: i.w },
					children: /* @__PURE__ */ u(M, {
						color: T(n),
						n
					})
				})
			})
		};
	},
	guess(e, t) {
		let { ended: n } = e.data, r = t.anchor(`${n ? "ending-rack" : "rack"}:${e.rid}`);
		return r ? {
			ms: 600,
			node: /* @__PURE__ */ u(p, {
				at: r,
				ms: 600
			})
		} : null;
	}
};
//#endregion
//#region src/games/gotfive/game-over.tsx
function K({ rid: e, rack: t, label: n }) {
	let { ref: r } = s(`ending-rack:${e}`);
	return /* @__PURE__ */ u("div", {
		ref: r,
		className: "gf-ending-tiles",
		role: "img",
		"aria-label": n,
		children: t.map((e) => /* @__PURE__ */ u(M, {
			n: e,
			color: T(e)
		}, e))
	});
}
function q(e) {
	let t = e.public, n = o(), [r, i] = a(!1), [s, c] = a(null), l = e.result.winner[0], f = e.members.find((e) => e.rid === l)?.name ?? l, p = t.guesses.some((e) => e.rid === l && e.correct);
	return /* @__PURE__ */ d("div", {
		className: "gf-review-shell",
		children: [
			/* @__PURE__ */ u("div", {
				className: "gf-review-board",
				inert: !r,
				children: /* @__PURE__ */ u(z, {
					...e,
					send: () => {},
					review: !0
				})
			}),
			r && /* @__PURE__ */ u("button", {
				className: "gf-button gf-review-close",
				onClick: () => i(!1),
				children: n("games.gotfive.closeReview")
			}),
			/* @__PURE__ */ d("div", {
				className: "gf-ending",
				hidden: r,
				inert: r,
				children: [
					/* @__PURE__ */ d("header", {
						className: "gf-ending-heading",
						children: [
							/* @__PURE__ */ u("h1", { children: n(p ? "games.gotfive.won" : "games.gotfive.lastStanding", { name: f }) }),
							e.hintCount !== void 0 && /* @__PURE__ */ u("p", { children: n("session.hint.usedCount", { n: e.hintCount }) }),
							/* @__PURE__ */ u("button", {
								className: "gf-button",
								onClick: () => i(!0),
								children: n("games.gotfive.review")
							})
						]
					}),
					/* @__PURE__ */ u("div", {
						className: "gf-ending-racks",
						children: e.result.ranking.map((r) => {
							let i = t.finalRacks?.[r] ?? [], a = t.guesses.find((e) => e.rid === r), o = e.result.autopilot?.[r];
							return /* @__PURE__ */ d("section", { children: [
								/* @__PURE__ */ d("h2", { children: [e.members.find((e) => e.rid === r)?.name ?? r, r === l ? " ★" : ""] }),
								o !== void 0 && o > 0 && /* @__PURE__ */ u("p", { children: n("session.autopilot.share", { n: Math.round(o * 100) }) }),
								/* @__PURE__ */ u(K, {
									rid: r,
									rack: i,
									label: `${n("games.gotfive.answer")}：${i.join(" · ")}`
								}),
								a && /* @__PURE__ */ d("p", { children: [
									n("games.gotfive.guessed"),
									"：",
									a.numbers.join(" · "),
									" ",
									a.correct ? "✓" : "×"
								] })
							] }, r);
						})
					}),
					/* @__PURE__ */ d("footer", {
						className: "gf-ending-controls",
						children: [
							e.onPlayAgain && /* @__PURE__ */ u("button", {
								className: `gf-button ${s === "again" ? "danger-stripes" : ""}`,
								onClick: () => {
									s === "again" ? e.onPlayAgain?.() : c("again");
								},
								children: n(s === "again" ? "games.gotfive.againConfirm" : "session.result.playAgain")
							}),
							e.onBackToLobby && /* @__PURE__ */ u("button", {
								className: `gf-button ${s === "lobby" ? "danger-stripes" : ""}`,
								onClick: () => {
									s === "lobby" ? e.onBackToLobby?.() : c("lobby");
								},
								children: n(s === "lobby" ? "games.gotfive.lobbyConfirm" : "session.result.backToLobby")
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ u("p", { children: n("session.result.waitHost") })
						]
					})
				]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/gotfive/entry.tsx
var J = {
	definition: A,
	View: R,
	bot: U,
	fx: G,
	OverView: q,
	locales: {
		zh: {
			name: "五猜缤纷",
			desc: "看得见别人的数字，却看不见自己的。利用分类与点数比较，率先猜出五个数字。",
			rules: "目标：\n率先按升序猜出自己牌架上的五个数字。每人只有一次猜答机会。\n准备：\n共有 60 张数字牌，号码为 1—60，分为绿、粉、蓝、红、橙五种颜色，每张有 1—3 个点。每位玩家每色抽取一张，系统按数字升序摆入五槽。你只能看到自己牌背的颜色，可以看到所有对手的号码和点数。中央另公开每色一张牌。数字版由首席先手。\n回合：\n先从仍有余牌的颜色中选择一种，随机公开一张牌。再从中央六张公开牌中选一张，进行以下一项提问。用过的牌留作公开线索，轮到下一位未淘汰玩家。\n· 分类：系统将所选牌放在自己五张牌之间的正确缺口，表示它在升序中的位置。\n· 比较：选择自己牌架上的一个槽位，系统回答该牌与所选公开牌的点数是否相同，颜色无需相同。\n记录：\n记录板显示全部牌的颜色、数字及点数。可见的牌自动划去；点击其他牌可以添加或取消个人排除记号。所有公开线索保留到终局，随时可以重新推理。\n结束：\n未淘汰玩家随时都能点击“五猜缤纷！”并按升序输入五个数字。全部猜对立即获胜；有任何错误即淘汰。只剩一位未淘汰玩家时，该玩家自动获胜。淘汰者的牌架仍可见，但不再进行回合。\n特殊情况：\n若当前玩家在翻牌后猜错，下一位玩家沿用这六张公开牌直接提问，不再翻牌。牌堆用尽后不补牌，此时本人五个数字已可从全部可见牌中排除得出，所有未淘汰玩家继续有权猜答。",
			invalid: "当前无法进行这项操作。",
			draw: "选择一种颜色翻牌",
			ask: "选择公开牌获取线索",
			waiting: "等待 {{name}}",
			exhausted: "牌已全部公开，请完成推理并猜答。",
			eliminated: "你已淘汰，可以继续观看。",
			turn: "第 {{n}} 回合",
			myRack: "我的牌架",
			supply: "牌堆",
			pool: "公开牌",
			notebook: "记录板",
			green: "绿色",
			pink: "粉色",
			blue: "蓝色",
			red: "红色",
			orange: "橙色",
			drawColor: "翻开{{color}}牌，剩余 {{n}} 张",
			tile: "{{color}} {{n}}，{{dots}} 个点",
			hidden: "第 {{n}} 槽，{{color}}，号码隐藏",
			categorise: "分类",
			compare: "比较点数",
			compareTarget: "点击我的牌架选择比较对象",
			notch: "第 {{n}} 个分类缺口",
			slot: "第 {{n}} 槽",
			equal: "点数相同",
			different: "点数不同",
			guess: "五猜缤纷！",
			guessTitle: "按升序猜出五个数字",
			guessWarning: "每人只有一次机会，任何错误都会淘汰。",
			confirm: "确认猜答",
			cancel: "取消",
			invalidGuess: "请填写五个互不相同且递增的数字（1—60）。",
			clear: "清除个人记号",
			clearConfirm: "确认清除",
			notes: "点击牌面标记排除；可见牌已自动划去。",
			won: "{{name}} 猜对了！",
			lastStanding: "{{name}} 是最后一位未淘汰玩家",
			lost: "猜答错误",
			answer: "正确牌架",
			guessed: "猜答",
			review: "查看本局",
			closeReview: "返回结果",
			againConfirm: "确认再来一局",
			lobbyConfirm: "确认返回大厅",
			history: "公开线索",
			none: "暂无公开线索"
		},
		en: {
			name: "Got Five!",
			desc: "See everyone’s numbers except your own. Categorise, compare dots, and be first to identify your five numbers.",
			rules: "Goal:\nBe first to guess your five numbers in ascending order. Each player gets one attempt.\nSetup:\nThere are 60 unique tiles numbered 1–60, in green, pink, blue, red, and orange, each bearing 1–3 dots. Each player receives one tile of each colour, sorted in ascending order. You see only the colours of your own tiles and the numbers and dots on everyone else’s. One tile of each colour starts face up in the centre. The first seat starts in this digital edition.\nTurn:\nChoose a colour with tiles remaining and reveal a random tile. Choose one of the six central face-up tiles and ask for one clue. The chosen tile remains as a public clue, then the next surviving player takes a turn.\n· Categorise: the system puts the chosen tile in the correct notch among your five numbers, showing its relative position.\n· Compare: choose a slot on your rack. The system says whether its tile and the chosen face-up tile have the same number of dots. Their colours need not match.\nNotes:\nYour board lists every tile’s colour, number, and dots. Visible tiles are crossed out automatically. Click other tiles to add or remove private elimination marks. Public clues remain available until the game ends, so you can reconsider your deductions.\nEnd:\nAny surviving player may declare “Got Five!” at any time and enter their five numbers in ascending order. A fully correct guess wins immediately. Any mistake eliminates that player. The last surviving player wins automatically. Eliminated players’ racks remain visible, but they take no further turns.\nEdge cases:\nIf the current player guesses incorrectly after revealing a tile, the next player asks using those six tiles without another draw. When the supply runs out, no tiles are recycled: every hidden number is deducible by elimination, and all surviving players may still guess.",
			invalid: "That action is not available now.",
			draw: "Choose a colour to reveal",
			ask: "Choose a tile for a clue",
			waiting: "Waiting for {{name}}",
			exhausted: "Every tile has been revealed. Complete your deductions and guess.",
			eliminated: "You are out. You can keep watching.",
			turn: "Turn {{n}}",
			myRack: "My rack",
			supply: "Supply",
			pool: "Face-up tiles",
			notebook: "Notes",
			green: "Green",
			pink: "Pink",
			blue: "Blue",
			red: "Red",
			orange: "Orange",
			drawColor: "Reveal {{color}}, {{n}} left",
			tile: "{{color}} {{n}}, dots: {{dots}}",
			hidden: "Slot {{n}}, {{color}}, number hidden",
			categorise: "Categorise",
			compare: "Compare dots",
			compareTarget: "Choose a tile on your rack to compare",
			notch: "Categorisation notch {{n}}",
			slot: "Slot {{n}}",
			equal: "Same dots",
			different: "Different dots",
			guess: "Got Five!",
			guessTitle: "Guess five numbers in ascending order",
			guessWarning: "You get one attempt. Any mistake eliminates you.",
			confirm: "Confirm guess",
			cancel: "Cancel",
			invalidGuess: "Enter five distinct, increasing numbers from 1 to 60.",
			clear: "Clear private marks",
			clearConfirm: "Confirm clear",
			notes: "Click a tile to rule it out. Visible tiles are already crossed out.",
			won: "{{name}} got five!",
			lastStanding: "{{name}} is the last surviving player",
			lost: "Incorrect guess",
			answer: "Correct rack",
			guessed: "Guess",
			review: "Review game",
			closeReview: "Back to results",
			againConfirm: "Confirm play again",
			lobbyConfirm: "Confirm lobby",
			history: "Public clues",
			none: "No public clues yet"
		}
	}
};
//#endregion
export { J as default };
