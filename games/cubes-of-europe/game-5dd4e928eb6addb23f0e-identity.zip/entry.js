import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { GameScreen as a } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as o } from "@bgparty/sdk/ui/phase-banner";
import { seatName as s } from "@bgparty/sdk/ui/player-strip";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { useFxAnchor as u } from "@bgparty/sdk/fx/anchors";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { FlySprite as m, PulseBox as h } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as ee } from "@bgparty/sdk/confirm-button";
import { OptionSection as te, OptionSwitch as g } from "@bgparty/sdk/ui/game-options";
//#region src/games/cubes-of-europe/data.ts
var _ = [
	"y",
	"r",
	"b",
	"g",
	"w"
], v = {
	y: "#e9bf36",
	r: "#c44b4c",
	b: "#64adbb",
	g: "#5a9865",
	w: "#f4ecdc"
}, y = {
	y: "◆",
	r: "▲",
	b: "●",
	g: "✦",
	w: "■"
}, b = "ABCDEFGHIJKLMNOPQ".split(""), x = [
	{
		q: -2,
		r: 0,
		dice: [
			2,
			3,
			6
		]
	},
	{
		q: -1,
		r: -1,
		dice: [
			5,
			6,
			4,
			2
		]
	},
	{
		q: 0,
		r: -2,
		dice: [
			6,
			1,
			5,
			3,
			1
		]
	},
	{
		q: 1,
		r: -2,
		dice: [
			3,
			2,
			6,
			4
		]
	},
	{
		q: 2,
		r: -2,
		dice: [
			4,
			1,
			5
		]
	}
].flatMap((e) => e.dice.map((t, n) => ({
	q: e.q,
	r: e.r + n,
	die: t,
	x: 180 + e.q * 57,
	y: 202 + ((e.r + n) * 2 + e.q) * 33
}))), S = x.map((e) => x.flatMap((t, n) => Math.max(Math.abs(e.q - t.q), Math.abs(e.r - t.r), Math.abs(e.q + e.r - t.q - t.r)) === 1 ? [n] : [])), C = [
	["ybg wwrr ggrby rgbw ybw", "rwy"],
	["gyg bbrg rbwwb ywgy wrr", "byw"],
	["rwy bgwr yggbb rwgb wry", "ygr"],
	["wbb ygby rrwrr ggww gyb", "gwb"],
	["wwy rrwb ygbgg bbwg rry", "wbg"],
	["ywg rwbg wbbrg yrby rgw", "grb"],
	["ryg bwrg bwbbr ywgr wgy", "rbw"],
	["bbg ywgy grrww gbrr byw", "wrg"],
	["bww ybby ggwwr grrg ybr", "bgr"],
	["yrb rwbg ggbgy rbww yrw", "gby"],
	["wwy gbgw ggrwb yrry brb", "byr"],
	["gyw rbgw bbggy yrrb wwr", "ywg"],
	["ggy ybwr bbrbr wggr wwy", "rby"],
	["wgg yrgy grbwb bbww rry", "bgw"],
	["byr bgrb bwggw ygwy rwr", "rgw"],
	["ybb rwby brwrg rggw ygw", "wrb"],
	["bby ggrg gwwwb yrrb rwy", "gwr"]
].map(([e, t], n) => ({
	id: b[n],
	land: e.replaceAll(" ", "").split(""),
	market: t.split("")
}));
function w(e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < 19; r++) {
		if (t.has(r)) continue;
		let i = [r];
		t.add(r);
		for (let n = 0; n < i.length; n++) for (let a of S[i[n]]) !t.has(a) && C[e].land[a] === C[e].land[r] && (t.add(a), i.push(a));
		n.push(i);
	}
	return n;
}
//#endregion
//#region src/games/cubes-of-europe/meta.ts
var T = {
	id: "cubes-of-europe",
	tier: "alpha",
	mechanics: [
		"dice-rolling",
		"tile-placement",
		"engine-building"
	],
	interactionTags: [],
	nameKey: "games.cubes-of-europe.name",
	descKey: "games.cubes-of-europe.desc",
	rulesKey: "games.cubes-of-europe.rules",
	icon: "🎲",
	iconImg: "games/cubes-of-europe.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [1],
	playerRange: (e) => ({
		min: 1,
		max: e?.rivals ? 4 : 1
	}),
	accent: "#31575a",
	releasedAt: "2026-11-04T01:03:10+08:00",
	search: {
		py: "fang kuai ou lu",
		init: "fkol"
	},
	hotseat: "open",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/13162440330839787950/61C9330856B5870E8729241F04A85510E6398332/" }
}, E = t.object({ rivals: t.boolean().default(!1) }).prefault({}), D = t.int().min(0).max(18), O = t.int().min(0).max(1), k = t.int().min(0).max(16), A = t.int().min(-1).max(50).default(-1), j = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("start"),
		cell: D
	}),
	t.object({ type: t.literal("roll") }),
	t.object({
		type: t.literal("adjust"),
		die: O,
		delta: t.union([t.literal(-1), t.literal(1)]),
		effect: A
	}),
	t.object({
		type: t.literal("take"),
		slot: t.int().min(0).max(5),
		die: O,
		effect: A,
		replace: t.int().min(-1).max(2).default(-1)
	}),
	t.object({
		type: t.literal("place"),
		cell: D,
		die: O,
		effect: A
	}),
	t.object({
		type: t.literal("worker"),
		die: O,
		effect: A
	}),
	t.object({
		type: t.literal("use"),
		effect: t.int().min(0).max(50),
		choice: t.enum(["red", "white"]).default("red")
	}),
	t.object({
		type: t.literal("skip"),
		effect: t.int().min(0).max(50)
	}),
	t.object({ type: t.literal("finish") }),
	t.object({
		type: t.literal("tuck"),
		accept: t.boolean()
	}),
	t.object({
		type: t.literal("copy"),
		card: k
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), M = t.object({
	kind: t.enum([
		"red",
		"white",
		"blue",
		"worker",
		"shift",
		"k",
		"m",
		"n",
		"p",
		"q"
	]),
	die: O.optional()
}), N = t.object({
	rid: t.string(),
	card: k,
	filled: t.array(t.boolean()).length(19),
	holding: t.array(t.enum([
		"y",
		"r",
		"b",
		"g",
		"w"
	])).max(3),
	workers: t.int().min(0).max(6),
	tucked: t.array(k),
	copy: k.nullable(),
	yellow: t.int().nonnegative(),
	dice: t.array(t.int().min(1).max(6)).length(2),
	used: t.array(t.boolean()).length(2)
}), ne = t.object({
	territories: t.int(),
	colors: t.int(),
	workers: t.int(),
	green: t.int(),
	cards: t.int(),
	total: t.int()
}), re = t.object({
	config: E,
	players: t.array(N),
	phase: t.enum([
		"setup",
		"startTurn",
		"roll",
		"act",
		"settle",
		"tuck",
		"done"
	]),
	actor: t.int(),
	first: t.int(),
	round: t.int(),
	pass: t.int(),
	main: k.nullable(),
	side: k.nullable(),
	mainCount: t.int(),
	sideCount: t.int(),
	occupied: t.array(t.int().nonnegative()).length(6),
	effects: t.array(M),
	tuckLeft: t.int(),
	copyOpen: t.boolean(),
	scores: t.record(t.string(), ne),
	event: t.object({
		kind: t.string(),
		rid: t.string(),
		n: t.int(),
		card: t.int()
	}).nullable()
}), P = t.object({}), F = (e) => e.players[e.actor], I = (t, n) => e(t.seed, t.cursor++, n);
function L(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = I(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
var ie = (e) => (e + 5) % 6 + 1, ae = (e) => [...e.tucked.filter((e) => e !== 14), ...e.tucked.includes(14) && e.copy !== null && e.tucked.includes(e.copy) ? [e.copy] : []], R = (e, t) => ae(e).filter((e) => e === t).length;
function z(e, t) {
	return (t === "y" ? 3 : 4) - e.holding.filter((e) => e === t).length - e.filled.filter((n, r) => n && C[e.card].land[r] === t).length;
}
function oe(e, t) {
	return !e.filled[t] && e.holding.includes(C[e.card].land[t]) && S[t].some((t) => e.filled[t]);
}
function se(e, t) {
	return [
		1,
		2,
		3,
		6,
		5,
		4
	].map((n, r) => {
		let i = r < 3 ? e : t;
		return {
			value: n,
			color: i === null ? "w" : C[i].market[r % 3],
			card: i
		};
	});
}
function B(e) {
	let t = w(e.card).filter((t) => t.every((t) => e.filled[t])), n = C[e.card].land, r = Object.fromEntries(_.map((t) => [t, e.filled.filter((e, r) => e && n[r] === t).length])), i = _.filter((t) => n.every((n, r) => n !== t || e.filled[r])).length, a = {
		territories: t.reduce((e, t) => e + t.length * (t.length + 1) / 2, 0),
		colors: i,
		workers: Math.floor(e.workers / 2),
		green: r.g,
		cards: 0,
		total: 0
	};
	for (let n of ae(e)) n === 3 && (a.cards += 1 + Math.floor(e.workers / 2)), n === 4 && (a.cards += r.r), n === 5 && (a.cards += i), n === 6 && (a.cards += r.g), n === 7 && (a.cards += r.b), n === 8 && (a.cards += r.w), n === 9 && (a.cards += 1 + Math.floor(t.filter((e) => e.length >= 2).length / 2)), n === 11 && (a.cards += Math.floor(t.filter((e) => e.length === 1).length / 2));
	return e.tucked.includes(14) && e.copy === null && (a.cards += 2), a.total = a.territories + a.colors + a.workers + a.green + a.cards, a;
}
function V(e, t, n = 0, r = -1) {
	e.event = {
		kind: t,
		rid: F(e).rid,
		n,
		card: r
	}, e.serial++;
}
function ce(e, t = !0) {
	let n = F(e);
	if (n.workers = Math.min(6, n.workers + 1), t) for (let t = 0; t < R(n, 1); t++) e.effects.push({ kind: "worker" });
}
function le(e, t) {
	for (let n = 0; n < R(F(e), t); n++) e.effects.push({ kind: "shift" });
}
function H(e) {
	e.effects = [], e.copyOpen = !0;
	let t = F(e);
	t.used = [!1, !1], t.dice = [1, 1], e.phase = "roll";
}
function ue(e, t, n) {
	let r = E.parse(e), i = {
		config: r,
		players: [],
		seed: n,
		cursor: 0,
		phase: "setup",
		actor: 0,
		first: 0,
		round: 1,
		pass: 1,
		main: [],
		side: [],
		occupied: [
			0,
			0,
			0,
			0,
			0,
			0
		],
		effects: [],
		tuckLeft: 0,
		settleAt: 0,
		settleStep: "tuck",
		skipLeft: 0,
		event: null,
		serial: 0,
		copyOpen: !1
	}, a = L(i, C.slice(0, r.rivals ? 17 : 9).map((e, t) => t)), o;
	return t.length > 1 ? (o = a.splice(0, 4), i.side.push(a.shift()), o = o.slice(0, t.length)) : (r.rivals && (a = a.slice(4)), i.side.push(a.shift()), o = [a.shift()]), i.main = a, i.first = I(i, t.length), i.actor = i.first, i.players = t.map((e, n) => ({
		rid: e,
		card: o[n],
		filled: Array(19).fill(!1),
		holding: [],
		workers: (n - i.first + t.length) % t.length + 1,
		tucked: [],
		copy: null,
		yellow: 0,
		dice: [1, 1],
		used: [!1, !1]
	})), { state: i };
}
var U = () => ({ code: "games.cubes-of-europe.invalid" });
function W(e, t, n) {
	return !e.effects[t] || n && e.effects[t].kind !== n ? !1 : (e.effects.splice(t, 1), !0);
}
function G(e) {
	e.phase === "startTurn" && e.effects.length === 0 && (e.phase = "act");
}
function de(e, t) {
	let n = F(e), r = C[n.card].land[t], i = n.holding.indexOf(r);
	n.holding.splice(i, 1), n.filled[t] = !0, r === "y" && n.yellow++, r === "r" && e.effects.push({ kind: "red" }), r === "w" && e.effects.push({ kind: "white" }), r === "b" && e.effects.push({ kind: "blue" });
	let a = r === "g" ? 12 : r === "r" ? 13 : r === "w" ? 15 : -1;
	if (a >= 0) for (let t = 0; t < R(n, a); t++) e.effects.push({ kind: r === "g" ? "m" : r === "r" ? "n" : "p" });
	return le(e, 0), V(e, "place", t), {
		kind: "cube",
		rid: n.rid,
		data: {
			color: r,
			from: `hold:${n.rid}:${i}`,
			to: `cell:${n.rid}:${t}`,
			target: `cube:${n.rid}:${t}`
		}
	};
}
function K(e) {
	e.round++, e.players.length > 1 && (e.first = (e.first + 1) % e.players.length), e.actor = e.first;
	for (let t of e.players) t.yellow = 0;
	e.occupied.fill(0), H(e);
}
function fe(e) {
	if (e.settleStep === "tuck") return e.settleAt >= e.players.length ? (e.settleStep = "refresh", []) : (e.actor = (e.first + e.settleAt) % e.players.length, e.tuckLeft = F(e).yellow, e.tuckLeft && e.side.length ? e.phase = "tuck" : e.settleAt++, []);
	if (e.settleStep === "refresh" || e.settleStep === "skip") {
		let t = e.main[0];
		return e.main.length && e.side.unshift(e.main.shift()), V(e, "refresh"), e.settleStep === "skip" ? (e.skipLeft--, (e.skipLeft <= 0 || !e.main.length) && (e.main.length ? K(e) : e.phase = "done")) : e.settleStep = "check", [{
			kind: "refresh",
			data: { card: t ?? -1 }
		}];
	}
	return e.main.length ? (K(e), []) : e.players.length > 1 || e.config.rivals || e.pass === 2 ? (e.phase = "done", []) : (e.pass = 2, e.main = L(e, e.side), e.side = [], e.skipLeft = F(e).filled.filter((t, n) => !t && C[F(e).card].land[n] === "y").length, e.skipLeft ? e.settleStep = "skip" : K(e), [{
		kind: "refresh",
		data: {}
	}]);
}
function pe(e, t, n) {
	if (e.phase === "done") return U();
	if (t.type === "tick") {
		if (n.by !== "$engine" || e.phase !== "settle") return U();
		let t = structuredClone(e);
		return {
			state: t,
			fx: fe(t)
		};
	}
	if (n.by !== F(e).rid) return U();
	let r = structuredClone(e), i = F(r), a = [];
	if (r.phase === "setup") return t.type !== "start" || i.filled.some(Boolean) || C[i.card].land[t.cell] !== "y" ? U() : (i.filled[t.cell] = !0, V(r, "start", t.cell), r.actor = (r.actor + 1) % r.players.length, r.actor === r.first && H(r), {
		state: r,
		fx: [{
			kind: "cube",
			rid: i.rid,
			data: {
				color: "y",
				from: `supply:${i.rid}:y`,
				to: `cell:${i.rid}:${t.cell}`,
				target: `cube:${i.rid}:${t.cell}`
			}
		}]
	});
	if (t.type === "copy") return !r.copyOpen || !["roll", "startTurn"].includes(r.phase) || !i.tucked.includes(14) || t.card === 14 || !i.tucked.includes(t.card) ? U() : (i.copy = t.card, { state: r });
	if (r.phase === "tuck") {
		if (t.type !== "tuck") return U();
		if (t.accept && r.side.length) {
			let e = r.side.shift();
			i.tucked.push(e), V(r, "tuck", 0, e), i.tucked.includes(14) && i.copy === null && (i.copy = i.tucked.find((e) => e !== 14) ?? null), a.push({
				kind: "tuck",
				rid: i.rid,
				data: { card: e }
			});
		}
		return r.tuckLeft--, (!r.tuckLeft || !r.side.length) && (r.phase = "settle", r.settleAt++), {
			state: r,
			fx: a
		};
	}
	if (t.type === "roll" && r.phase === "roll") {
		r.copyOpen = !1, i.dice = [I(r, 6) + 1, I(r, 6) + 1];
		for (let e = 0; e < R(i, 16); e++) r.effects.push({ kind: "q" });
		return r.phase = r.effects.length ? "startTurn" : "act", V(r, "roll"), {
			state: r,
			fx: [{
				kind: "roll",
				rid: i.rid,
				data: { dice: i.dice }
			}]
		};
	}
	if (!["act", "startTurn"].includes(r.phase)) return U();
	if (t.type === "skip") return r.copyOpen = !1, W(r, t.effect) ? (G(r), { state: r }) : U();
	if (t.type === "use") {
		r.copyOpen = !1;
		let e = r.effects[t.effect];
		if (!e) return U();
		if ([
			"m",
			"n",
			"p",
			"q"
		].includes(e.kind)) {
			let n = e.kind === "q" ? 2 : 1;
			return i.workers < n ? U() : (i.workers -= n, W(r, t.effect), r.effects.push({ kind: e.kind === "n" ? "red" : e.kind === "p" ? "white" : t.choice }), {
				state: r,
				fx: [{
					kind: "worker",
					rid: i.rid,
					data: {}
				}]
			});
		}
		return U();
	}
	if (t.type === "adjust") {
		if (!["act", "startTurn"].includes(r.phase) || i.used[t.die]) return U();
		if (t.effect >= 0) {
			let e = r.effects[t.effect];
			if (!e || e.kind !== "shift" && e.kind !== "k" || e.kind === "k" && e.die !== t.die) return U();
			W(r, t.effect);
		} else {
			if (r.effects.length || i.workers < 1) return U();
			i.workers--;
			for (let e = 0; e < R(i, 10); e++) r.effects.push({
				kind: "k",
				die: t.die
			});
		}
		return i.dice[t.die] = ie(i.dice[t.die] + t.delta), G(r), {
			state: r,
			fx: [{
				kind: "adjust",
				rid: i.rid,
				data: { die: t.die }
			}]
		};
	}
	if (t.type === "take" || t.type === "place" || t.type === "worker") {
		let e = t.effect >= 0, n = r.effects[t.effect];
		if (!e && (r.phase !== "act" || r.effects.length || i.used[t.die])) return U();
		if (t.type === "take") {
			if (e && n?.kind !== "white") return U();
			let o = se(r.main[0] ?? null, r.side[0] ?? null)[t.slot];
			if (o.card === null || !e && (o.value !== i.dice[t.die] || r.occupied[t.slot] >= (r.players.length === 2 ? 1 : 2)) || i.holding.length === 3 && (t.replace < 0 || t.replace >= 3)) return U();
			if (e ? W(r, t.effect) : (i.used[t.die] = !0, r.occupied[t.slot]++), i.holding.length === 3 && i.holding.splice(t.replace, 1), z(i, o.color) > 0) {
				let e = i.holding.length;
				i.holding.push(o.color), le(r, 2), a.push({
					kind: "cube",
					rid: i.rid,
					data: {
						color: o.color,
						from: `market-cube:${t.slot}`,
						to: `hold:${i.rid}:${e}`,
						target: `holdcube:${i.rid}:${e}`
					}
				});
			}
			V(r, "take", t.slot);
		} else if (t.type === "place") {
			if (e && n?.kind !== "red" || !oe(i, t.cell) || !e && x[t.cell].die !== i.dice[t.die]) return U();
			e ? W(r, t.effect) : i.used[t.die] = !0, a.push(de(r, t.cell));
		} else {
			if (e && n?.kind !== "blue" && n?.kind !== "worker") return U();
			let o = !e || n?.kind === "blue";
			e ? W(r, t.effect) : i.used[t.die] = !0, ce(r, o), V(r, "worker"), a.push({
				kind: "worker",
				rid: i.rid,
				data: {}
			});
		}
		return G(r), {
			state: r,
			fx: a
		};
	}
	if (t.type === "finish" && r.phase === "act" && i.used.every(Boolean) && !r.effects.length) {
		let e = (r.actor + 1) % r.players.length;
		return e === r.first ? (r.phase = "settle", r.settleAt = 0, r.settleStep = "tuck", r.occupied.fill(0)) : (r.actor = e, H(r)), { state: r };
	}
	return U();
}
function me(e) {
	return {
		public: {
			config: e.config,
			players: structuredClone(e.players),
			phase: e.phase,
			actor: e.actor,
			first: e.first,
			round: e.round,
			pass: e.pass,
			main: e.main[0] ?? null,
			side: e.side[0] ?? null,
			mainCount: e.main.length,
			sideCount: e.side.length,
			occupied: [...e.occupied],
			effects: structuredClone(e.effects),
			tuckLeft: e.tuckLeft,
			copyOpen: e.copyOpen,
			scores: Object.fromEntries(e.players.map((e) => [e.rid, B(e)])),
			event: e.event
		},
		private: {}
	};
}
var q = {
	meta: T,
	saveCompatibility: { version: "1" },
	schemas: {
		action: j,
		publicView: re,
		privateView: P,
		config: E
	},
	setup: ue,
	reduce: pe,
	viewFor: me,
	nextTickIn: (e) => e.phase === "settle" ? 480 : null,
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = Object.fromEntries(e.players.map((e) => [e.rid, B(e).total])), n = [...e.players].sort((e, n) => t[n.rid] - t[e.rid] || e.filled.filter(Boolean).length - n.filled.filter(Boolean).length), r = n[0], i = e.players.length === 1 ? t[r.rid] >= 30 ? [r.rid] : [] : n.filter((e) => t[e.rid] === t[r.rid] && e.filled.filter(Boolean).length === r.filled.filter(Boolean).length).map((e) => e.rid);
		return {
			phase: "done",
			scores: t,
			ranking: n.map((e) => e.rid),
			winner: i
		};
	}
}, he = {
	name: "games.cubes-of-europe.name",
	desc: "games.cubes-of-europe.desc",
	rules: "games.cubes-of-europe.rules",
	rivals: "games.cubes-of-europe.rivals",
	rivalsInfo: "games.cubes-of-europe.rivalsInfo",
	round: "games.cubes-of-europe.round",
	pass: "games.cubes-of-europe.pass",
	market: "games.cubes-of-europe.market",
	main: "games.cubes-of-europe.main",
	side: "games.cubes-of-europe.side",
	land: "games.cubes-of-europe.land",
	workers: "games.cubes-of-europe.workers",
	holding: "games.cubes-of-europe.holding",
	supply: "games.cubes-of-europe.supply",
	permanent: "games.cubes-of-europe.permanent",
	score: "games.cubes-of-europe.score",
	start: "games.cubes-of-europe.start",
	roll: "games.cubes-of-europe.roll",
	act: "games.cubes-of-europe.act",
	effects: "games.cubes-of-europe.effects",
	waiting: "games.cubes-of-europe.waiting",
	settle: "games.cubes-of-europe.settle",
	take: "games.cubes-of-europe.take",
	place: "games.cubes-of-europe.place",
	chooseDie: "games.cubes-of-europe.chooseDie",
	used: "games.cubes-of-europe.used",
	worker: "games.cubes-of-europe.worker",
	finish: "games.cubes-of-europe.finish",
	skip: "games.cubes-of-europe.skip",
	use: "games.cubes-of-europe.use",
	redChoice: "games.cubes-of-europe.redChoice",
	whiteChoice: "games.cubes-of-europe.whiteChoice",
	red: "games.cubes-of-europe.red",
	white: "games.cubes-of-europe.white",
	blue: "games.cubes-of-europe.blue",
	bonus: "games.cubes-of-europe.bonus",
	shift: "games.cubes-of-europe.shift",
	k: "games.cubes-of-europe.k",
	m: "games.cubes-of-europe.m",
	n: "games.cubes-of-europe.n",
	p: "games.cubes-of-europe.p",
	q: "games.cubes-of-europe.q",
	tuck: "games.cubes-of-europe.tuck",
	decline: "games.cubes-of-europe.decline",
	replace: "games.cubes-of-europe.replace",
	returnCube: "games.cubes-of-europe.returnCube",
	adjustUp: "games.cubes-of-europe.adjustUp",
	adjustDown: "games.cubes-of-europe.adjustDown",
	copy: "games.cubes-of-europe.copy",
	empty: "games.cubes-of-europe.empty",
	y: "games.cubes-of-europe.y",
	r: "games.cubes-of-europe.r",
	b: "games.cubes-of-europe.b",
	g: "games.cubes-of-europe.g",
	w: "games.cubes-of-europe.w",
	invalid: "games.cubes-of-europe.invalid",
	A: "games.cubes-of-europe.A",
	B: "games.cubes-of-europe.B",
	C: "games.cubes-of-europe.C",
	D: "games.cubes-of-europe.D",
	E: "games.cubes-of-europe.E",
	F: "games.cubes-of-europe.F",
	G: "games.cubes-of-europe.G",
	H: "games.cubes-of-europe.H",
	I: "games.cubes-of-europe.I",
	J: "games.cubes-of-europe.J",
	K: "games.cubes-of-europe.K",
	L: "games.cubes-of-europe.L",
	M: "games.cubes-of-europe.M",
	N: "games.cubes-of-europe.N",
	O: "games.cubes-of-europe.O",
	P: "games.cubes-of-europe.P",
	Q: "games.cubes-of-europe.Q",
	result: "games.cubes-of-europe.result",
	victory: "games.cubes-of-europe.victory",
	soloVictory: "games.cubes-of-europe.soloVictory",
	soloDefeat: "games.cubes-of-europe.soloDefeat",
	total: "games.cubes-of-europe.total",
	territories: "games.cubes-of-europe.territories",
	colors: "games.cubes-of-europe.colors",
	green: "games.cubes-of-europe.green",
	cards: "games.cubes-of-europe.cards",
	review: "games.cubes-of-europe.review",
	title0: "games.cubes-of-europe.title0",
	title1: "games.cubes-of-europe.title1",
	title2: "games.cubes-of-europe.title2",
	title3: "games.cubes-of-europe.title3",
	title4: "games.cubes-of-europe.title4",
	again: "games.cubes-of-europe.again",
	lobby: "games.cubes-of-europe.lobby",
	confirmAgain: "games.cubes-of-europe.confirmAgain",
	confirmLobby: "games.cubes-of-europe.confirmLobby",
	confirm: "games.cubes-of-europe.confirm",
	cancel: "games.cubes-of-europe.cancel",
	waitHost: "games.cubes-of-europe.waitHost"
};
function J() {
	let e = l();
	return (t, n) => e(he[t], n);
}
//#endregion
//#region src/games/cubes-of-europe/effect-glyph-data.ts
var ge = {
	A: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M432,85 427,88 422,93 422,102 424,102 430,97 432,98 432,144 433,145 441,145 442,144 442,86 441,85ZM262,59 253,66 246,70 246,72 251,79 252,82 255,85 274,114 273,118 246,158 247,161 262,171 265,168 272,156 275,153 293,126 294,123 299,117 298,112 268,68 267,65Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M406,192 406,194 407,194 409,197 415,200 414,197 411,194 409,194ZM449,163 425,163 422,165 422,169 420,172 405,172 404,173 414,185 415,188 419,192 421,196 435,214 439,211 448,198 453,193 460,182 467,174 467,172 452,172 450,170 450,164ZM141,147 138,148 135,151 134,154 138,151ZM102,127 102,131 103,133 106,135 110,140 113,140 108,131ZM162,126 159,128 158,127 153,128 146,136 144,140 151,139 155,136 154,135 158,132 159,130 158,129 159,128 162,128ZM436,16 431,21 415,44 404,57 405,58 419,58 421,60 421,66 422,67 449,67 450,66 450,60 452,58 467,58 463,51 459,47 454,39 450,35 448,31Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M506,179 503,179 499,181 494,181 489,183 483,183 482,184 474,185 473,186 467,186 464,188 465,187 466,190 465,191 464,190 461,192 452,205 456,205 456,203 461,198 463,198 470,192 474,192 476,190 478,191 482,189 494,188 496,186 499,187 501,184 504,184 505,183ZM85,176 91,184 94,185 96,187 99,187 101,189 126,189 127,190 128,189 129,190 134,190 135,189 140,190 142,188 143,189 151,189 152,188 157,188 158,189 160,188 163,184 166,184 168,181 173,177 173,176 171,176 160,183 156,183 155,184 105,184 104,183 99,183 90,177ZM368,170 368,171 373,175 373,177 377,180 379,180 382,183 388,185 391,188 393,188 396,192 402,195 404,198 409,202 411,202 418,208 421,209 422,211 425,213 415,198 416,199 415,201 409,198 408,196 405,194 406,191 407,192ZM154,127 144,129 143,130 129,132 126,134 126,135 127,134 132,135 133,134 138,134 139,133 143,133 146,135 149,131ZM170,124 163,126 162,129 159,129 160,130 159,132 155,135 156,136 151,140 144,141 143,140 145,137 143,141 137,148 141,146 142,148 134,155 133,154 129,159 126,158 124,160 122,160 125,160 126,162 130,164 134,162 143,153 143,151 149,147 147,146 147,143 149,141 155,141 162,133 165,132 166,129 168,128ZM89,119 91,122 91,125 99,133 100,136 104,139 104,141 108,141 109,142 109,146 108,147 109,149 111,150 111,153 109,155 112,154 116,149 114,148 118,146 121,149 112,137 114,140 113,141 110,141 109,139 102,133 101,131 101,127 102,126 93,121 90,121ZM431,74 432,76 437,76 438,77 439,76 443,76 445,75 445,74Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M403,189 411,193 407,188 406,190ZM402,154 400,156 400,164 401,165 407,165 408,164 408,160 406,156 404,154ZM448,151 444,153 442,152 433,152 431,153 431,154 434,157 441,157 442,156 445,156 444,155 446,154ZM158,142 156,141 155,142 149,142 148,143 148,146 151,147 153,143ZM108,142 104,142 103,141 101,142 103,142 105,144 102,148 79,161 79,163 88,169 90,166 96,164 100,160 104,159 110,153 110,150 109,150 107,147 108,146ZM106,128 111,133 112,136 117,143 116,141 119,139 129,141 131,140 133,137 135,138 137,137 143,139 145,135 143,134 133,135 132,136 127,135 126,136 125,134 128,132 126,133 115,133 108,130ZM467,123 462,123 460,124 456,129 455,133 456,136 459,139 464,139 469,135 471,129 470,126ZM425,109 421,111 422,115 424,117 426,113 426,110ZM495,89 487,90 484,93 483,95 483,101 485,104 487,105 491,105 496,101 498,97 498,93ZM370,78 369,80 369,88 371,92 373,94 375,94 377,92 376,82 373,78ZM408,66 408,69 409,69 414,75 417,76 421,80 426,80 429,78 445,78 449,80 453,75 457,75 461,73 465,68 464,65 458,65 456,68 456,70 453,73 451,74 446,74 445,76 443,77 439,77 438,78 437,77 432,77 430,74 431,73 444,73 428,73 427,74 420,74 416,71 414,65 409,65ZM118,62 118,67 120,67 121,69 122,68 123,69 123,68 121,67 121,65 119,62ZM115,60 110,63 112,63 113,65 114,65 114,61ZM88,54 86,60 86,64 87,65 86,66 86,72 87,73 86,74 86,104 86,90 91,83 93,78 95,77 96,73 99,70 100,66 104,63 102,63Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M395,184 404,189 406,189 407,187 411,192 401,180 399,179 400,180 400,185 399,186ZM153,146 157,147 157,145 160,143 155,143 153,144ZM104,144 103,143 99,143 98,146 99,148 92,153 99,148 102,147ZM142,139 138,139 137,138 135,139 133,138 132,140 129,142 121,141 120,140 117,141 117,142 122,149 121,148 122,146 125,147 126,146 130,146 129,145 132,143 138,143 139,144ZM467,122 471,126 472,131 470,135 466,139 464,140 459,140 455,136 454,133 455,129 460,123 462,122ZM483,102 485,105 484,107 480,110 483,110 486,106ZM499,97 501,98 501,101 500,102 497,100ZM171,80 168,87 166,89 162,97 159,100 158,104 146,123 155,120 165,119 170,115 171,113ZM502,82 494,82 494,85 493,86 491,86 489,89 485,89 482,86 478,85 475,81 471,80 468,77 469,76 468,72 471,69 471,67 469,65 465,65 466,68 461,74 457,76 453,76 449,81 445,79 442,79 445,79 449,83 449,94 450,95 449,97 449,147 446,151 443,152 447,150 449,151 447,154 445,155 446,156 445,157 434,158 430,154 430,153 432,152 430,152 426,147 426,114 426,116 424,118 421,115 420,112 421,110 419,110 417,108 415,109 414,106 413,107 413,111 416,112 417,128 419,133 418,136 419,150 422,156 424,155 430,160 427,162 422,162 421,163 422,162 432,162 433,161 441,161 442,162 450,162 451,163 450,162 451,161 450,159 451,158 456,158 458,160 463,155 466,156 469,154 474,154 478,152 478,149 480,147 480,135 484,130 480,125 480,123 482,120 478,118 476,119 474,117 474,114 470,114 468,116 468,120 466,122 463,121 464,119 464,105 466,103 468,103 467,101 465,103 464,102 464,99 465,98 464,97 467,94 471,94 474,96 473,97 470,97 474,102 477,102 480,100 482,100 482,95 487,89 495,88 499,93 499,97 497,101 493,105 488,106 490,107 489,108 490,109 490,116 491,115 493,116 492,117 493,118 491,119 491,120 499,119 501,118 499,115 500,114 502,115 503,99 508,94 507,90 504,87ZM402,66 403,67 403,71 405,72 406,76 412,80 415,78 418,81 423,83 425,81 431,79 429,79 426,81 421,81 417,77 414,76 409,70 407,69 407,66 408,65 403,65ZM115,59 116,60 115,61 115,65 113,66 112,64 109,63ZM138,43 131,43 126,45 113,47 106,57 106,59 103,62 101,61 114,68 116,67 120,69 120,68 117,67 117,62 119,61 122,65 122,67 125,69 124,68 126,66 129,59 132,56 133,52 138,45Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M428,212 429,215 433,220 433,217 432,216 433,214 431,211 430,213ZM92,173 93,177 99,181 117,181 117,179 104,179ZM87,151 86,151 84,154 81,154 74,159 73,164 75,165 79,170 82,171 82,170 78,167 74,162 76,161 76,160 81,156 82,154 86,153ZM186,162 184,158 177,154 174,151 172,151 168,148 163,147 163,149 167,151 172,156 169,159 166,160 135,179 131,179 131,181 160,181 176,171 174,170 172,167 172,165 174,163 176,164 178,170 179,170 186,164ZM85,114 90,118 102,124 107,128 113,131 116,131 115,130 117,128 114,128 112,126 110,126 107,123 102,121 99,118 92,115 93,116 91,117 88,114 87,116ZM173,94 174,95 174,99 173,100 172,99 172,95ZM262,57 266,60 267,63 279,80 280,83 283,86 296,107 302,114 301,118 299,119 298,122 293,128 288,137 285,140 282,146 267,167 266,170 263,173 260,172 243,160 244,156 247,154 250,148 255,142 256,139 261,133 272,116 271,112 266,106 243,71 250,65 253,64 257,60 260,59ZM261,54 259,56 252,59 251,61 249,61 247,64 244,65 240,69 240,73 246,80 246,82 251,88 255,96 257,97 261,105 263,106 268,115 267,118 264,121 263,125 256,133 256,135 252,139 251,142 242,154 240,158 240,161 244,165 253,170 257,174 261,176 264,176 268,173 269,170 274,164 273,163 277,159 277,157 281,153 286,144 291,139 291,137 297,130 299,125 305,116 305,113 303,111 303,109 299,105 298,102 292,95 291,92 288,89 288,87 280,77 278,72 272,65 267,56 264,54ZM108,43 112,44 113,45 112,47 116,45 115,43ZM131,39 127,42 128,43 131,42 139,42 145,44 147,46 150,46 153,49 155,49 159,53 161,53 168,57 172,62 172,113 167,119 164,120 165,121 164,124 165,123 168,123 174,118 176,113 176,64 175,63 175,60 173,57 166,51 158,48 152,43 150,43 144,39 141,39 140,38ZM421,26 423,24 429,22 433,16 436,14 441,18 441,20 444,23 447,28 450,28 451,29 450,30 452,30 453,32 455,33 453,31 453,29 447,23 447,22 445,21 442,15 436,10 432,12 424,22 425,23Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M449,206 447,205 446,206 445,205 436,217 434,215 433,216 434,217 434,220 439,219ZM468,176 467,176 462,182 458,189 456,190 447,203 449,202 451,203 453,201 455,197 466,184 468,179 470,178 469,178ZM174,164 173,167 174,169 177,171 177,168 175,164ZM451,162 452,163 452,169 453,170 466,170 465,167 463,167 462,170 455,170 454,169 455,167 459,167 457,167 455,164 455,167 453,168 452,167 452,162ZM401,153 405,153 407,155 410,164 408,166 401,166 399,164 398,161 399,160 399,155ZM98,147 94,147 91,149 89,152 88,151 86,154 82,155 82,156 80,157 76,162 75,162 85,173 92,177 91,172 79,165 77,162 81,158 91,153 98,148ZM138,144 132,144 130,147 126,147 125,149 124,147 122,147 125,153 129,157ZM513,122 505,125 503,129 503,141 504,142 504,154 505,155 505,159 510,159 512,162 508,164 510,167 504,171 502,174 503,175 501,178 507,176 512,171 515,164 515,123ZM164,121 163,120 155,121 151,123 147,123 146,124 138,125 133,127 129,127 124,129 117,129 116,132 125,132 134,129 140,129 141,128 145,128 154,125 159,125 161,122 162,124 163,124ZM82,99 82,108 83,111 87,115 88,113 92,116 91,114 87,111 85,107 85,99ZM511,85 512,101 513,99 512,97 513,91ZM431,83 442,83 444,85 444,145 442,147 432,147 431,146 431,100 430,99 422,105 420,103 420,92ZM370,76 372,76 377,81 378,84 378,93 375,96 373,96 368,90 367,80ZM112,45 110,44 103,44 98,46 90,47 84,51 82,56 82,73 83,74 83,81 82,82 82,97 85,97 85,58 86,55 89,53 99,60 103,61 105,59 105,57ZM424,23 425,24 419,29 417,33 414,36 416,37 412,42 411,40 411,41 406,45 401,45 397,47 395,46 387,49 374,50 370,53 369,52 368,53 365,53 361,57 357,63 357,74 356,75 357,78 357,115 356,116 357,121 356,124 357,125 357,154 361,162 365,166 398,185 399,185 399,180 398,179 400,178 411,190 412,193 417,198 427,212 428,211 430,212 429,208 422,200 420,196 416,192 405,176 401,172 403,170 419,170 420,169 420,163 422,161 427,161 428,160 425,158 422,158 418,154 417,151 417,135 418,134 416,128 416,118 415,117 415,113 411,110 411,106 413,104 416,105 415,108 417,107 419,109 423,109 425,107 427,109 427,147 430,151 444,151 447,149 448,147 448,83 445,80 442,80 441,79 439,80 432,79 425,82 423,84 417,82 415,80 412,81 404,76 405,74 404,72 402,71 401,69 402,67 401,66 403,64 415,64 417,66 417,70 419,72 452,72 455,70 455,66 457,64 469,64 473,67 471,71 472,70 473,71 472,74 478,78 489,77 493,75 503,75 504,76 507,76 512,80 514,79 515,80 515,77 512,69 503,61 500,60 498,58 493,57 486,51 481,50 478,47 473,44 471,44 470,42 468,42 465,39 462,39 459,37 457,37 456,36 457,35 454,34 452,31 449,30 450,29 448,29 470,58 468,60 453,60 452,61 452,67 450,69 422,69 420,67 420,61 419,60 404,60 402,57 414,42 413,41 417,38 428,23 426,24Z\"/><path fill=\"#a63441\" fill-rule=\"evenodd\" d=\"M139,163 127,171 130,170 131,171 132,170 133,172 132,173 129,173 130,173 131,175 134,171 137,170 138,171 138,169 140,167 138,166ZM133,116 134,117 134,121 133,122 132,121 132,117ZM137,106 139,106 141,108 139,111 137,111 135,109ZM153,104 152,103 153,104 152,105 150,104 147,106 141,106 136,103 136,100 134,100 119,126 121,127 122,126 127,126 128,125 132,125 133,124 137,124 138,123 145,122 152,111 152,109 154,107 154,106 152,105ZM157,78 158,79 158,83 157,84 156,83 156,79ZM156,63 157,63 154,65 153,68 146,78 146,80 144,82 147,82 149,84 154,83 158,88 161,89 162,91 163,91 170,79 167,79 166,78 166,81 164,82 164,85 163,86 159,83 162,79 160,77 158,72 154,69 156,68 157,66 155,65Z\"/><path fill=\"#e73d4e\" fill-rule=\"evenodd\" d=\"M169,155 163,151 160,151 143,162 141,162 139,164 139,166 141,167 139,169 138,172 137,171 134,172 131,176 130,174 128,173 129,172 132,172 133,170 131,172 130,171 129,172 126,171 124,173 119,175 118,177 135,177 154,165 159,163 164,159 169,157ZM136,109 139,110 141,107 140,108 137,107ZM144,83 134,99 136,99 137,100 137,103 141,105 147,105 150,103 153,105 155,105 158,101 162,92 161,90 158,89 154,84 149,85 147,83ZM168,61 163,63 158,63 156,64 156,65 158,66 157,68 155,69 159,72 161,77 163,79 160,82 160,83 163,85 163,82 165,81 165,78 166,77 167,78 170,78 170,63Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M161,55 155,63 156,62 163,62 168,60 171,63 171,79 160,98 171,79 171,63 167,58Z\"/><path fill=\"#1f9c4f\" fill-rule=\"evenodd\" d=\"M113,154 114,162 115,163 119,161 118,158 117,160Z\"/><path fill=\"#3dae58\" fill-rule=\"evenodd\" d=\"M112,155 108,156 104,160 100,161 96,165 90,167 89,169 96,173 99,173 106,168 114,164ZM122,70 114,70 105,64 103,64 101,66 100,70 97,73 96,77 94,78 92,83 87,90 87,107 91,112 96,115 99,113 100,109 104,104 104,102 110,94 112,88 117,82 122,72Z\"/><path fill=\"#255255\" fill-rule=\"evenodd\" d=\"M115,148 117,149 114,153 117,159 118,157 119,160 124,159 125,158 125,155 118,147Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M118,179 118,181 130,181 130,179ZM494,175 497,174 498,177 495,178ZM468,167 470,166 471,168 469,169ZM454,164 455,163 457,166 460,167 459,168 455,168 454,167ZM488,156 490,155 491,158 490,159ZM158,145 158,147 162,149 163,146 167,147 161,144ZM511,84 513,86 513,90 514,91 514,94 513,95 514,99 512,102 511,101 511,95 510,94 510,85ZM514,80 512,81 507,77 504,77 503,76 493,76 489,78 478,79 474,77 471,74 472,71 469,72 470,75 469,77 471,79 475,80 478,84 482,85 485,88 489,88 491,85 493,85 493,82 494,81 502,81 505,87 508,90 509,94 504,99 503,115 501,116 499,114 502,118 501,119 499,118 500,119 496,121 491,121 490,119 492,118 491,117 492,116 490,117 489,116 489,109 488,108 489,107 487,106 483,111 480,111 479,110 482,108 484,105 482,103 482,101 480,101 477,103 474,103 469,97 470,96 473,96 471,95 467,95 465,97 466,98 465,99 465,102 467,100 469,103 465,105 465,119 464,121 467,120 467,116 470,113 474,113 476,118 478,117 483,120 481,123 481,125 485,130 481,135 481,147 479,149 479,152 474,155 469,155 466,157 463,156 458,161 456,159 451,159 450,160 451,159 453,162 453,167 454,167 455,169 462,169 462,167 465,166 466,169 470,172 467,175 471,178 469,179 467,184 464,187 466,185 480,183 482,181 490,181 495,179 500,179 500,177 502,175 501,174 503,171 509,167 507,164 509,162 511,162 510,160 505,160 503,154 502,129 503,126 505,124 509,123 512,121 515,122 515,81ZM131,38 126,40 122,40 118,42 113,42 115,42 117,44 116,46 117,45 126,44 127,43 126,42Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M280,156 278,157 278,159 275,162 275,164 272,167 269,173 264,177 261,177 257,175 254,172 251,171 248,168 246,168 239,161 239,158 239,161 243,166 247,168 250,171 252,171 260,177 264,177 269,173ZM263,122 255,132 255,134 249,141 249,143 245,147 243,152 240,156 255,134 256,131 261,126ZM98,117 102,120 107,122 110,125 112,125 114,127 117,127 111,125 108,122 106,122ZM255,97 258,101 258,103 263,108 266,114 264,120 266,117 266,113 264,109 260,105 256,97ZM239,69 239,73 241,77 244,79 244,81 246,83 247,86 253,93 253,95 254,95 250,88 245,82 245,80 240,75 239,73ZM261,53 255,57 261,53 264,53 269,57 271,60 271,62 277,69 280,75 289,87 289,89 292,92 306,113 306,116 304,119 304,121 302,122 298,130 292,137 292,139 287,144 285,149 281,154 282,154 283,151 291,141 293,136 298,130 300,125 304,121 306,117 306,112 301,106 301,104 297,100 296,97 291,91 286,82 282,78 281,75 270,58 266,54ZM160,54 151,48 149,48 145,45 141,45 139,43 139,45 134,52 133,56 130,59 127,66 125,68 126,69 127,68 132,68 137,66 141,66 145,64 154,63ZM112,42 101,43 100,44 92,45 84,49 83,52 81,54 80,59 81,60 81,54 87,47 93,45ZM141,37 147,39 163,49 155,43 145,38ZM441,12 445,17 446,20 459,36 465,38 472,43 477,45 480,48 486,50 493,55 503,60 513,69 516,77 516,162 516,76 514,70 511,66 504,60 497,56 495,56 487,50 481,48 478,45 473,43 468,39 461,37 451,26 446,19 445,16ZM434,10 431,11 407,43 404,44 401,43 399,45 387,46 386,47 380,48 385,48 389,46 394,46 395,45 399,45 400,44 405,44 407,43 410,40 412,36 414,35 430,13Z\"/>",
	B: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M110,147 110,165 113,166 114,165 120,165 123,163 123,154ZM393,146 392,147 392,166 396,166 397,165 404,164 405,163 405,154 399,151ZM447,129 438,129 434,126 430,126 430,128 429,129 427,128 425,133 425,144 420,150 420,182 421,183 424,181 432,181 437,179 442,179 443,178 452,177 455,176 457,173 457,145 456,144 453,144 449,141 448,139 448,130ZM179,124 172,124 169,126 161,126 158,124 156,127 153,127 150,130 148,128 145,128 144,126 143,127 143,144 138,150 138,183 141,181 149,181 150,180 154,180 160,178 170,177 174,175 174,142 178,139 180,134 180,125ZM462,99 456,99 455,100 455,112 453,114 441,114 440,115 440,121 441,122 453,122 455,124 455,136 456,137 463,136 463,124 465,122 477,122 478,121 478,115 477,114 465,114 463,112 463,100ZM497,85 487,93 487,102 489,102 495,97 497,98 497,145 498,146 506,146 507,145 507,86 506,85ZM453,74 451,74 452,75 451,76 448,74 444,76 437,76 435,78 426,79 422,81 420,80 419,81 416,80 417,81 417,92 413,99 415,100 416,99 421,99 426,96 429,97 431,95 433,96 435,93 438,95 440,93 448,94 448,91 453,85 453,81 454,80 453,79ZM170,71 167,68 166,69 164,68 163,69 160,69 160,72 161,73 159,75 156,75 147,80 135,80 135,90 132,98 140,97 141,96 142,97 145,96 151,96 152,97 156,95 167,94 166,91 171,85 171,75 170,74ZM282,60 274,66 268,69 266,72 275,84 276,87 283,96 286,102 291,108 292,111 294,113 294,117 286,130 283,133 271,151 266,160 276,166 279,169 284,170 292,159 293,156 301,145 302,142 308,135 311,129 318,120 320,114 284,60Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M428,116 425,118 426,119 425,132 425,130 427,127 430,129 429,126 430,125 434,125 433,124 433,118 429,118ZM180,113 178,110 177,111 173,111 172,109 163,113 162,112 159,112 158,113 155,112 151,115 145,115 143,119 143,126 144,125 145,127 148,127 150,129 153,126 156,126 158,123 161,125 169,125 172,123 179,123 180,124ZM130,99 133,101 137,102 139,100 150,99 151,97 145,97 144,98 141,97 140,98 132,99 131,97 133,94ZM451,89 449,91 449,94 448,95 440,94 438,96 435,94 433,97 432,96 429,98 426,97 421,100 416,100 414,101 412,99 414,96 412,99 414,101 417,102 418,101 422,101 424,99 428,101 429,98 435,98 441,96 446,97 450,94 449,91ZM170,70 166,62 153,63 150,64 148,66 146,63 142,65 140,64 135,68 133,67 132,68 129,67 131,70 131,73 133,77 134,83 134,80 135,79 147,79 156,74 159,74 160,73 159,72 159,69 160,68 163,68 164,67 166,68 167,67ZM450,65 444,58 441,60 441,63 439,65 435,66 434,68 432,65 430,65 429,63 423,62 425,64 423,66 422,65 419,68 417,67 415,69 412,69 415,78 419,80 420,79 422,80 426,78 435,77 437,75 444,75 448,73 451,75 450,74 453,73Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M455,183 442,185 437,187 432,187 423,190 415,190 413,188 411,188 410,190 412,190 418,194 424,195 425,194 428,194 431,192 433,193 434,192 438,192 441,190 446,190 448,188 450,188 453,186ZM173,183 169,183 164,185 160,185 159,186 155,186 154,187 150,187 149,188 145,188 139,190 133,190 126,185 126,187 128,191 133,190 134,191 134,194 137,193 148,193 152,191 161,191 162,190 165,191 172,186ZM384,173 387,175 392,176 393,179 395,178 398,180 400,178 400,173 399,172 397,173 393,173 392,174 386,172ZM99,170 99,172 101,172 104,176 107,177 113,177 116,179 118,179 117,177 118,176 118,173 117,172 114,173 105,173ZM469,140 463,145 463,151 463,148 468,144ZM474,129 471,129 470,130 470,135 471,136 470,138 471,138 470,137 473,134 475,130ZM433,107 434,104 437,104 438,105 434,108ZM432,47 427,47 426,48 422,48 417,50 406,51 405,52 401,52 400,53 389,55 385,59 383,64 383,71 386,80 383,83 378,83 375,85 373,90 374,116 379,124 379,160 391,167 393,167 391,166 391,147 393,145 407,154 407,163 406,164 407,166 407,176 412,180 418,183 420,183 419,182 419,150 424,144 424,126 425,125 425,119 424,118 427,115 428,115 429,117 433,117 434,118 434,110 438,107 447,107 448,105 448,97 450,95 446,98 441,97 435,99 429,99 428,102 424,100 422,102 418,102 416,103 411,99 414,95 416,90 416,82 413,73 411,70 412,68 415,68 417,66 419,67 422,64 423,65 424,64 422,62 423,61 429,62 430,64 432,64 433,66 436,68 435,68 434,66 440,63 440,60 444,57 450,64 441,52 437,49ZM150,47 145,47 144,48 135,49 138,49 139,50 135,52 133,52 132,51 133,50 129,50 128,51 118,52 117,53 107,55 102,60 101,63 101,73 102,74 102,77 104,80 101,83 95,83 91,88 91,114 94,121 96,123 96,159 99,162 104,164 106,166 111,167 108,166 108,147 110,145 113,146 118,150 121,151 124,154 124,163 123,164 124,166 124,175 128,179 137,183 136,182 136,150 142,143 142,119 145,114 151,114 155,111 158,112 159,111 162,111 163,112 172,108 173,110 177,110 178,109 180,112 179,107 176,102 174,102 172,104 170,102 174,100 167,92 169,89 167,91 169,94 168,95 164,95 160,97 157,96 156,98 152,98 150,100 139,101 136,103 131,101 129,99 133,93 134,90 133,89 134,84 132,80 130,70 128,67 129,66 131,67 133,66 135,67 140,63 142,64 146,62 148,65 150,63 153,62 166,61 155,49Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M457,143 458,144 458,151 461,149 462,151 462,145 464,143Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M401,173 401,176 404,181 407,182 410,185 416,188 418,188 418,185 407,179 405,177 405,175 402,177 401,176ZM462,171 458,171 458,177 457,178 452,178 451,180 452,181 459,181 461,179 462,176ZM179,171 176,171 177,179 176,180 173,179 172,181 174,179 175,181 179,178ZM178,159 176,165 176,169 179,169 179,161ZM460,154 459,156 459,160 458,161 460,160 462,163 460,164 460,169 460,165 461,164 462,165 462,156ZM374,150 374,153 373,154 373,160 374,162 377,165 384,169 384,168 383,169 382,167 385,165 380,163 377,160 377,150ZM91,150 91,153 92,154 91,160 92,163 104,171 109,172 109,168 107,168 95,161 95,155 91,153 91,151 94,150ZM492,135 492,146 494,150 496,151 510,151 513,148 513,142 511,141 509,142 509,145 506,148 505,147 498,147 496,145 496,140 495,141 493,138 494,136ZM373,131 374,134 374,144 373,147 374,148 377,148 377,133 374,133ZM483,120 479,120 480,122 479,123 474,124 475,127 480,127 483,123ZM475,108 475,111 474,112 478,112 480,114 479,117 483,117 483,112 482,110 479,108ZM509,102 509,104 513,104 513,102ZM482,102 482,106 484,108 487,109 485,107 485,104ZM462,94 461,97 463,97 465,99 465,103 467,103 469,101 468,97 465,94ZM370,84 368,86 368,112 372,124 372,123 375,122 373,118 373,115 372,114 372,86ZM512,82 510,80 504,80 503,79 494,80 491,83 488,84 488,85 483,89 482,97 483,97 483,95 485,92 496,83 507,83 509,85 509,91 511,91 512,93 513,93ZM196,78 193,81 193,94 191,96 190,95 186,97 184,96 182,99 182,101 183,99 186,99 187,100 188,99 189,100 190,99 196,99 197,98 197,83 199,82 219,97 223,99 243,115 241,118 237,120 224,131 213,138 199,149 197,148 197,132 196,131 189,131 189,133 191,133 193,137 193,150 196,153 200,153 231,129 243,121 246,118 246,113 240,107 237,106 236,104 231,102 225,96 206,83 202,79ZM100,71 98,73 96,72 96,75 97,76 94,79 92,79 89,81 86,86 86,114 87,115 88,121 91,125 91,130 92,131 91,132 91,138 92,139 91,144 92,143 92,140 93,139 95,140 94,142 95,138 93,136 95,135 95,129 94,128 95,127 95,124 90,116 90,111 89,110 89,89 90,86 94,82 96,81 101,81 102,80 100,75ZM283,57 286,60 306,91 309,94 312,100 315,103 316,106 322,114 322,117 298,152 300,153 298,155 297,154 286,171 282,173 267,163 264,159 292,117 292,113 287,107 286,104 283,101 282,98 264,71 268,67ZM285,54 281,54 271,62 266,64 261,69 261,74 266,80 266,82 271,87 273,90 273,92 281,102 283,107 286,110 288,114 288,118 273,139 272,143 269,147 267,148 266,152 261,157 261,161 271,170 283,177 286,176 288,174 301,153 305,149 305,147 308,142 315,134 315,131 319,128 318,127 320,126 326,117 326,114 323,108 319,104 312,92 309,89 308,86 305,83 300,74 293,65 290,59ZM407,48 408,47 412,47 413,48 412,49 408,49ZM428,45 429,44 432,44 433,45 432,46 429,46ZM140,44 135,44 131,46 127,46 122,48 118,47 117,48 106,50 102,52 98,56 97,60 100,61 104,54 107,54 112,52 116,52 121,50 126,50 131,48 140,47ZM378,61 378,66 379,66 380,64 381,66 383,60 382,59 387,54 394,53 395,52 399,52 404,50 408,50 409,49 413,49 414,48 418,48 419,47 423,47 424,46 434,46 441,50 448,58 453,67 455,73 455,77 456,78 455,84 458,85 459,83 459,74 455,66 455,64 452,60 452,58 443,47 435,43 424,43 423,44 422,43 414,46 403,47 400,49 388,50 385,53 383,53 381,55ZM150,43 151,45 155,46 156,47 155,48 156,47 157,49 165,57 167,61 168,59 171,63 170,67 173,74 173,84 172,86 175,86 177,82 177,78 176,77 176,73 174,69 174,66 171,61 171,59 164,50 161,49 158,45 153,43Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M451,179 443,180 438,182 433,182 432,183 425,183 419,185 419,188 448,183 451,181 450,180ZM176,177 174,178 170,178 170,181 172,180 174,181 174,180 173,181 172,180 173,178 175,178 177,180ZM383,167 383,168 384,167 385,168 385,170 389,172 399,170 402,173 402,176 405,174 405,167 404,166 396,167 395,168 389,168 386,166ZM110,168 110,171 115,171 117,170 119,172 120,179 128,185 134,188 140,188 141,187 152,186 157,184 165,183 168,181 168,179 166,179 165,180 155,181 149,183 143,183 140,185 135,185 123,177 123,166 118,166 117,167ZM458,162 458,170 461,170 461,165 461,169 460,170 459,169 459,164 461,163 460,161ZM94,140 95,141 93,140 92,149 94,149 95,147 95,144 93,142ZM376,122 373,123 374,126 373,130 374,132 377,132 377,124ZM509,105 509,141 511,140 513,141 513,105ZM465,104 465,111 466,112 473,112 474,111 474,108 473,109 469,106 469,103ZM495,99 488,105 486,105 487,108 490,107 492,109 492,114 494,115 492,116 492,117 494,118 494,121 492,124 494,125 494,131 492,134 495,136 494,137 495,140 496,139 495,138 496,137 496,100ZM485,94 484,97 482,98 482,101 485,103ZM509,92 509,96 511,97 509,98 509,101 513,101 513,98 511,97 513,96 513,94 512,94 511,92ZM172,87 169,90 169,92 178,102 181,108 181,112 182,113 182,134 181,135 181,138 176,143 176,164 176,161 178,158 179,160 180,144 183,141 185,135 185,110 184,107 181,107 180,106 183,105 181,101 181,99 183,96 179,96 174,91 174,88 175,87ZM455,85 451,91 452,94 450,96 449,99 449,106 447,108 438,108 435,111 435,124 438,127 447,127 450,129 449,130 449,138 452,141 454,142 456,141 458,142 465,142 468,140 469,137 469,128 470,127 474,127 473,124 466,124 465,125 465,136 462,139 456,139 453,137 453,125 452,124 440,124 438,122 438,114 440,112 452,112 453,111 453,99 455,97 460,97 461,94 456,92 458,86ZM381,64 380,66 378,67 378,73 379,76 376,79 372,81 371,83 373,86 376,82 383,81 384,80 382,74 382,65ZM97,61 96,64 96,71 98,72 99,71 99,63 100,62ZM141,44 141,47 146,45 147,46 152,46 156,48 153,46 151,46 149,43 146,43 145,45 144,44Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M199,83 198,84 198,99 196,101 184,101 185,107 186,108 186,118 187,119 187,124 186,125 187,126 187,130 196,130 198,132 198,147 204,144 213,136 220,132 240,116 240,114 235,111 223,101 219,99 215,95 207,90Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M186,130 186,136 187,135 190,135 191,136 191,134 189,134 188,131Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M261,163 262,165 268,168 270,171 272,171 278,176 282,177 280,177ZM283,124 281,125 280,128 276,132 275,135 261,156 262,154 264,153 266,148 269,145 272,139ZM326,118 324,122 321,125 320,128 318,129 316,132 316,134 312,138 306,147 306,149 298,159 294,167 291,170 289,174 286,177 284,177 286,177 293,169 299,158 302,155 307,146 311,142 313,137 319,130ZM247,116 247,118 243,122 231,130 229,133 227,133 223,137 211,145 206,150 203,151 200,154 196,154 193,151 196,154 200,154 222,137 229,133 237,126 240,125 247,118ZM283,108 287,115 285,118 285,120 283,122 284,122 287,117 287,114ZM309,87 320,104 325,110 321,105 316,96 311,90 310,87ZM266,83 270,88 271,91 274,94 274,96 276,99 278,100 282,106 280,102 272,92 269,86ZM192,81 192,92 190,94 192,93 192,81 196,77 202,78 206,82 221,92 233,102 235,102 237,105 240,106 247,113 247,114 242,107 238,105 211,84 209,84 208,82 204,80 203,78 201,77 195,77ZM286,54 291,59 296,68 308,85 302,77 296,66 293,63 293,61 290,57ZM280,54 277,55 268,62 262,65 260,68 260,73 260,69 266,63 269,62ZM443,46 449,52 453,58 458,70 456,62 449,53 448,50ZM420,43 417,43 416,44 415,43 412,45 406,45 405,46 396,47 392,49 388,49 383,52 379,57 383,52 385,52 388,49 394,49 403,46 413,45 417,43ZM143,42 147,42 149,41 158,44 167,52 169,56 172,59 174,65 173,61 170,56 160,45 150,41 145,41Z\"/>",
	C: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M445,85 435,93 435,102 437,102 443,97 446,99 446,145 447,146 455,146 456,145 456,86 455,85ZM283,60 277,65 268,70 268,73 287,100 288,103 292,107 296,114 296,117 274,149 273,152 268,158 268,160 285,171 322,115 291,68 288,65 287,62 285,60Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M488,187 487,186 479,187 473,194 473,196 477,193 479,193 481,190 485,189ZM480,172 465,172 463,170 463,164 454,164 451,163 450,164 436,164 435,165 435,170 433,172 418,172 417,173 424,181 425,184 432,192 447,213 450,214 463,197 465,193 469,189 474,181 481,173ZM418,57 418,58 428,58 429,59 433,58 435,61 435,66 436,67 462,67 463,66 463,60 464,59 468,59 469,58 472,59 480,59 481,58 450,17 448,17 446,19 438,31 434,35Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M519,179 513,181 508,181 503,183 497,183 492,185 488,185 489,187 487,189 481,191 479,194 477,194 473,197 472,196 466,203 464,207 465,208 465,207 467,206 468,203 472,202 479,196 483,195 495,188 498,189 500,188 501,189 503,187 507,188 509,186 513,185 518,181ZM378,169 379,171 388,179 394,181 397,184 399,184 403,188 405,188 418,199 427,204 435,212 438,213 440,216 439,213 436,210 434,206 424,194 410,187 405,183 398,180 384,171ZM80,162 81,163 82,162 84,166 89,168 92,172 95,172 98,175 101,176 104,175 105,177 108,179 108,181 113,181 121,185 127,183 133,183 137,181 147,181 148,180 151,180 155,177 160,177 161,178 165,176 169,177 171,175 179,174 182,171 185,170 186,168 175,169 174,170 170,170 169,171 165,171 164,172 160,172 154,174 149,174 144,176 139,176 138,177 134,177 128,179 114,179 113,178 110,178 90,165 82,161ZM205,87 206,88 211,85 216,84 218,81 217,80 206,80 205,81ZM440,75 442,75 444,77 447,76 448,78 457,78 461,76 455,74 441,74Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M415,154 413,157 413,163 414,165 421,165 422,164 419,156 417,154ZM441,152 447,157 456,157 457,156 456,153 443,153ZM481,123 475,123 473,124 469,129 469,136 472,139 478,139 483,135 484,127ZM433,111 433,113 434,113 436,116 439,117 439,110 438,109 436,111ZM197,103 191,103 192,104 192,107 188,113 191,111 190,110 193,107 195,106 196,107 196,104ZM502,89 500,90 496,95 496,102 500,105 506,105 511,99 511,92 508,89ZM163,80 163,82 164,82 167,86 168,85 167,82 169,81 169,80ZM383,78 382,79 382,88 385,94 388,95 390,92 390,84 386,78ZM78,73 77,73 75,76 75,122 80,115 83,108 86,105 86,102 92,94 94,88 97,85 97,84 95,84 93,82 88,80ZM478,67 475,65 471,65 470,66 470,70 466,74 456,74 462,76 458,78 462,78 467,75 470,75 474,71 476,71 476,69ZM419,66 421,72 425,75 429,75 435,80 440,80 443,78 447,78 447,77 444,78 442,76 440,76 439,75 440,74 433,74 428,69 428,66 427,65 421,65Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M411,186 416,188 418,190 421,189 425,193 416,183 414,184 413,187ZM440,152 441,151 443,152 456,152 458,154 458,156 456,158 447,158ZM195,107 191,110 192,111 187,115 179,130 174,137 172,142 164,154 162,159 156,167 165,164 170,164 171,163 175,163 180,161 184,161 189,157 190,155 190,151 191,150 191,115 192,114 195,114 196,115 196,108ZM417,65 414,69 415,72 418,75 419,74 420,76 427,81 432,81 433,84 435,84 443,79 458,79 462,83 462,94 460,96 459,95 459,99 460,98 462,100 462,147 458,152 443,152 440,149 439,147 439,118 436,117 435,115 432,113 433,110 436,110 432,110 430,108 429,109 429,114 431,116 430,117 430,120 433,121 431,126 433,127 433,138 430,143 433,146 433,152 434,154 438,156 442,160 441,162 438,162 463,162 464,163 460,160 461,158 464,157 467,154 471,148 474,146 474,141 477,140 472,140 468,136 468,129 470,126 475,122 471,115 471,113 473,111 473,108 474,107 473,94 475,89 477,87 477,84 480,82 480,80 477,79 476,81 474,78 481,72 483,66 481,65 476,65 479,67 477,69 477,71 474,72 470,76 467,76 462,79 443,79 440,81 435,81 429,76 425,76 419,71 418,66 420,65ZM146,58 135,58 134,59 130,59 122,62 111,63 107,68 106,72 99,81 98,84 106,88 111,92 116,94 125,94 128,93 128,91 131,85 135,80 137,74 145,62ZM198,35 199,36 198,35 184,35 183,36 183,56 181,58 161,58 160,59 160,73 161,74 181,74 183,76 183,96 184,97 183,96 183,75 182,74 162,74 160,72 160,60 162,58 182,58 183,57 183,37 185,35Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M433,201 432,202 447,220 451,220 455,216 455,213 454,212 453,215 448,216 436,200 435,202ZM470,196 467,196 466,195 466,198 464,200 463,199 458,205 460,204 463,206 460,207 461,208 467,200 465,199 467,196ZM160,168 158,167 157,168 148,169 150,171 149,173 155,171 158,171ZM71,149 78,157 85,160 88,163 93,165 95,167 111,176 114,177 129,177 132,176 132,173 133,172 132,173 121,174 120,175 113,173 109,171 106,168 102,167 97,163 95,163 90,159 79,153 76,150 75,146 73,149ZM70,135 70,143 72,144 73,146 74,144 73,136ZM70,117 70,123 72,124 74,122 71,121 71,118ZM195,115 192,115 192,150 191,151 191,155 190,157 184,162 180,162 174,164 172,166 174,168 175,167 180,167 181,166 185,166 190,163 195,157 196,154 196,116ZM180,85 179,86 179,90 182,90 182,85ZM155,68 155,73 156,76 158,78 169,78 169,75 161,75 159,73 159,68 158,69ZM285,57 324,115 321,121 318,124 310,136 309,139 302,148 286,173 282,172 265,160 267,156 272,150 273,147 284,132 285,129 288,126 287,124 289,120 290,122 294,117 293,112 290,109 289,106 284,100 283,97 280,94 266,72 266,70 268,68 281,60 282,58ZM139,55 140,54 144,54 145,55 144,56 140,56ZM283,54 280,57 278,57 275,60 272,61 269,64 265,66 262,69 262,73 270,83 272,88 278,96 279,99 280,99 283,103 290,116 288,118 288,120 278,133 278,135 268,148 267,151 262,158 262,161 264,164 267,165 271,169 276,171 281,175 286,176 289,174 295,166 296,163 302,155 303,152 306,149 307,146 313,139 320,127 326,120 327,113 321,105 319,100 311,90 311,88 302,77 302,75 295,67 295,65 292,60 287,55ZM209,54 210,57 222,57 224,59 224,67 225,67 226,69 226,62 227,61 226,60 226,57 223,54ZM203,35 202,33 199,31 182,31 179,35 179,52 177,54 159,54 156,55 151,53 137,53 136,54 132,54 131,55 123,56 122,57 115,57 112,59 110,59 111,62 115,62 116,61 122,61 125,59 145,56 146,57 153,58 155,60 155,66 156,65 159,65 159,59 161,57 181,57 182,56 182,36 184,34 198,34 200,36 200,41 203,40ZM468,32 465,29 464,26 460,23 460,21 456,17 453,12 448,10 445,12 437,22 436,25 431,30 427,37 421,44 409,46 421,45 425,42 427,42 435,32 436,29 444,20 444,18 449,14 453,17 454,20 464,32 467,31Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M462,206 460,205 458,206 452,214 453,214 452,213 454,211 456,214 460,209 459,207ZM149,171 148,170 143,170 142,171 134,172 133,173 133,176 148,173ZM174,166 172,165 173,164 161,166 160,167 161,169 159,171 161,170 165,170 166,169 170,169 173,168 172,167ZM416,152 421,156 423,162 423,165 421,167 414,167 412,165 412,155ZM427,107 428,108 428,111 427,112 426,111 426,108ZM371,93 372,94 372,97 371,98 370,97 370,94ZM526,92 527,93 527,96 526,97 525,96 525,93ZM444,83 456,83 458,85 458,146 456,148 453,147 452,148 451,147 445,147 443,145 444,144 444,100 443,99 436,105 433,103 433,92ZM383,76 385,76 388,78 391,83 391,88 392,90 391,91 391,94 389,96 385,96 382,92 380,87 380,81ZM170,75 170,78 177,78 179,80 179,85 182,84 182,76 181,75ZM225,68 224,68 224,73 222,75 201,75 200,76 200,96 198,98 184,98 182,96 182,91 179,91 179,98 180,100 184,102 188,102 189,101 191,102 198,102 201,101 203,99 203,80 205,78 223,78 226,76 226,70ZM110,60 104,60 99,62 92,62 87,64 82,64 79,65 73,70 70,77 70,116 72,118 72,121 74,118 74,75 77,71 97,83 101,78 101,76 105,71 107,66 110,63ZM200,42 200,56 201,57 209,57 208,54 207,55 204,53 203,54 202,53 202,50 203,49 203,41ZM462,31 466,35 483,58 481,61 466,61 465,62 465,67 463,69 435,69 433,67 433,62 432,61 421,61 420,60 417,60 415,58 426,43 421,46 405,47 402,49 397,49 396,50 394,49 393,50 389,50 387,52 386,51 380,53 373,59 370,64 370,153 372,159 379,167 386,170 401,180 405,181 408,184 413,186 413,184 416,182 422,188 432,201 433,200 435,201 435,199 415,173 417,170 432,170 433,169 433,164 436,161 441,161 440,159 438,159 435,156 434,156 433,158 432,156 429,154 430,152 429,150 432,146 429,143 429,141 431,139 431,129 432,127 430,126 431,125 429,124 432,122 432,121 429,120 428,109 430,107 432,109 437,109 438,108 440,109 440,147 443,151 458,151 461,147 461,104 460,103 460,100 458,99 458,93 459,92 460,94 461,94 461,83 458,80 443,80 435,85 433,85 432,83 430,82 426,82 423,80 418,74 417,75 413,72 414,71 413,69 417,64 428,64 430,70 433,72 466,72 469,68 468,66 470,64 482,64 485,66 483,70 484,70 485,68 486,69 486,77 489,78 495,78 496,77 516,76 519,78 522,82 522,84 525,87 524,90 525,93 524,94 527,100 526,102 527,110 525,113 525,116 527,118 525,123 526,130 524,132 524,137 522,140 521,146 520,147 517,146 514,151 511,148 502,144 500,145 498,142 495,148 490,151 483,147 480,147 478,143 478,147 476,150 473,151 470,155 467,156 465,158 463,158 461,160 465,163 465,169 466,170 481,170 483,172 475,184 468,192 467,195 470,195 482,181 485,184 488,184 489,183 493,183 496,181 503,181 504,180 514,179 517,177 519,177 525,171 527,168 527,165 528,164 528,122 527,121 528,119 528,77 527,76 527,72 526,70 516,61 513,61 510,58 504,56 503,54 497,50 491,49 490,47 486,44 480,41 478,41 472,37 471,38 467,32 464,33Z\"/><path fill=\"#a63441\" fill-rule=\"evenodd\" d=\"M148,121 151,122 158,122 155,120 158,118 155,116 154,114 152,114 150,119ZM172,80 170,83 170,85 166,88 166,90 161,98 161,100 165,102 168,106 172,109 174,113 180,116 180,119 182,120 186,113 189,110 191,104 190,103 181,103 178,100 177,98 177,81 176,80Z\"/><path fill=\"#e73d4e\" fill-rule=\"evenodd\" d=\"M162,101 160,100 153,113 159,118 156,120 159,122 158,123 147,122 146,126 143,129 141,134 139,136 139,138 136,141 132,150 125,160 125,162 123,164 122,168 120,169 121,172 127,172 126,171 127,170 132,171 133,170 137,170 146,167 153,167 155,166 162,156 165,149 173,137 173,135 176,132 180,123 182,121 179,119 179,116 174,114 172,112 171,109Z\"/><path fill=\"#1f9c4f\" fill-rule=\"evenodd\" d=\"M185,85 185,86 187,87 187,95 186,96 185,95 186,96 189,96 188,95 189,94 194,94 195,92 193,91 193,87 194,86 198,87 198,86 195,84 194,85 193,84 187,84ZM189,70 191,72 189,74 187,72ZM209,61 208,60 200,60 197,58 195,60 196,62 192,65 192,67 189,70 187,70 187,74 186,75 185,74 186,75 185,78 186,78 187,76 193,75 194,77 197,77 198,79 198,75 200,73 207,73 208,72 209,73 209,72 205,72 204,71 205,65 206,64 209,64Z\"/><path fill=\"#3dae58\" fill-rule=\"evenodd\" d=\"M198,88 194,87 194,91 196,92 194,95 189,95 190,96 193,96 194,95 197,96 198,95ZM98,85 95,88 93,94 87,102 87,105 84,108 81,115 75,123 75,144 76,147 79,151 89,157 92,154 96,145 100,140 102,135 111,121 112,117 118,109 120,104 122,102 122,100 125,97 125,95 116,95 113,94ZM197,36 186,36 185,37 185,42 184,43 184,57 182,59 162,59 161,60 161,72 162,73 182,73 184,75 184,95 185,96 186,95 186,87 184,86 185,84 187,83 193,83 194,84 195,83 198,85 198,80 197,78 194,78 193,76 187,77 186,79 184,78 184,76 186,74 186,70 189,69 191,67 191,65 195,62 194,60 197,57 200,59 208,59 210,61 210,64 209,65 206,65 205,71 209,71 210,73 220,73 221,72 221,60 220,59 200,59 197,56 198,54 198,37Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M432,147 430,150 431,152 430,154 432,155 433,157 434,155 432,152ZM74,123 72,125 70,124 70,134 72,134 74,136 74,139 74,130 73,129 73,124ZM507,87 510,89 513,95 512,100 506,106 504,107 500,107 498,106 495,102 495,99 494,98 495,95 501,88 503,87ZM518,78 516,77 507,77 506,78 489,79 485,77 485,69 484,71 482,71 482,72 475,78 476,80 477,78 480,79 481,82 478,84 478,87 476,89 474,94 475,107 474,108 473,107 474,108 474,111 472,113 472,115 476,122 481,122 484,125 485,127 485,133 484,136 478,140 477,142 475,141 475,146 472,148 465,157 467,155 470,154 473,150 475,150 477,147 477,143 478,142 480,146 483,146 490,150 494,148 496,143 498,141 500,144 501,143 505,144 511,147 514,150 515,147 517,145 520,146 520,143 523,137 523,132 525,130 525,126 524,125 525,122 525,117 524,116 524,113 525,112 525,97 523,94 524,93 523,90 524,87 521,84 521,82Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M312,89 320,100 322,105 328,113 328,117 328,113 325,109 320,99ZM153,59 147,58 146,62 138,74 136,80 132,85 129,91 129,93 158,87 158,85 156,83 155,80 157,78 158,79 161,79 158,79 154,74 154,61ZM286,54 287,54 293,60 296,66 299,69 300,72 311,87 300,70 296,66 296,64 291,57 288,54ZM283,53 284,53 269,61 261,69 261,73 263,77 273,90 273,92 275,93 275,95 277,97 278,100 285,108 285,110 287,112 288,115 286,121 278,131 277,134 275,136 275,138 273,139 272,142 270,143 267,149 261,157 261,162 273,172 275,172 276,174 278,174 282,177 287,177 289,176 295,169 296,165 304,155 308,147 317,135 317,133 324,124 321,127 314,139 308,146 307,149 304,152 303,155 297,163 294,169 288,176 283,177 279,175 276,172 271,170 267,166 264,165 262,163 261,158 263,156 267,148 277,135 277,133 287,120 287,118 289,115 280,100 278,99 277,96 271,88 269,83 261,73 261,69 265,65 269,63 272,60 275,59 278,56 280,56ZM179,32 178,37 178,35 182,30 200,30 204,34 204,52 205,53 223,53 227,57 227,60 226,55 223,53 206,53 204,51 204,34 202,31 200,30 182,30ZM426,36 444,12 448,9 454,12 461,21 461,23 465,26 466,29 473,37 483,41 485,43 490,45 493,48 499,50 507,56 514,60 516,60 520,63 508,55 503,53 498,49 494,48 488,43 481,40 477,37 474,37 471,35 463,23 457,16 458,15 457,15 456,13 451,9 446,10 443,14 440,16 435,25 428,32 428,34Z\"/>",
	D: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M448,165 447,166 447,184 448,185 449,184 458,183 460,181 460,173 457,170ZM516,142 513,144 509,143 506,145 494,146 491,148 481,147 481,154 480,155 481,159 480,160 480,164 475,168 475,180 476,181 475,183 476,184 475,200 476,201 483,200 484,199 488,199 489,198 493,198 498,196 508,195 512,193 512,160 517,154 517,144ZM526,135 524,136 524,146 527,145 527,136ZM397,127 391,131 390,133 390,140 396,145 401,145 407,140 407,133 403,128ZM584,105 583,106 580,105 575,109 563,110 556,113 547,113 547,126 542,132 542,164 543,165 549,164 550,163 554,163 555,162 559,162 560,161 564,161 565,160 575,159 578,157 578,149 579,148 579,124 583,120 584,117ZM190,101 189,102 189,108 187,110 181,110 180,112 181,113 187,113 189,115 189,122 192,123 193,122 193,115 195,113 201,113 202,111 201,110 195,110 193,108 193,102ZM507,90 506,89 503,93 501,92 498,93 493,92 490,93 490,94 487,96 482,95 481,96 475,96 473,98 472,97 472,112 468,118 472,118 474,115 478,117 479,116 486,116 488,115 489,113 492,114 493,112 499,112 500,111 503,112 503,110 508,104 508,101 509,100 509,96ZM397,86 394,87 390,91 390,98 394,103 400,104 403,103 406,100 407,98 407,92 403,87 401,86ZM300,82 291,85 288,85 287,86 282,86 281,88 287,93 287,130 284,133 281,134 282,137 306,137 307,136 306,133 303,133 301,131 301,86 302,84ZM94,82 91,82 88,84 85,84 80,86 76,86 75,87 75,89 78,90 80,92 80,131 74,135 75,137 99,137 100,136 100,134 97,133 94,130 94,97 95,96 95,83ZM573,51 570,52 570,55 569,56 566,56 564,58 562,58 559,60 539,64 539,73 535,80 535,82 541,82 547,80 547,79 550,77 551,78 556,78 557,77 562,77 564,75 568,75 570,74 575,67 575,56 573,53Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M516,126 512,126 513,127 512,128 510,127 509,128 501,129 500,130 499,129 497,131 495,130 493,132 492,131 491,133 488,135 483,135 482,134 483,132 481,133 480,154 480,147 481,146 491,147 494,145 501,145 502,144 506,144 509,142 513,143 516,141 517,143 517,129ZM469,119 474,120 475,119 481,119 483,117 485,117 479,117 477,118 474,116 472,119ZM504,110 503,113 501,112 499,113 493,113 492,115 489,114 489,115 487,116 489,117 490,116 497,116 501,113 503,113ZM583,91 581,90 578,94 566,95 562,97 555,96 553,98 551,97 547,100 548,102 547,105 547,112 556,112 563,109 575,108 580,104 583,105 584,104 584,94ZM508,91 504,81 500,76 490,79 485,84 481,84 480,83 472,84 470,82 466,85 469,91 471,99 471,97 472,96 473,97 475,95 481,95 482,94 487,95 489,94 490,92 493,91 496,91 497,92 501,91 503,92 504,90 506,91 507,89ZM572,76 569,75 568,76 564,76 562,78 557,78 556,79 551,79 550,78 548,79 547,81 542,82 548,80 555,80 560,78 562,79 567,79 570,78ZM571,45 566,39 565,40 562,39 559,41 558,44 557,43 558,44 557,45 555,44 555,42 552,42 548,46 544,45 539,51 535,51 535,54 537,58 537,62 538,64 541,62 546,62 551,60 556,60 562,57 564,57 566,55 569,55 569,52 571,50 573,50Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M507,202 505,203 499,203 498,204 489,205 488,206 484,206 479,208 473,208 470,209 473,211 475,210 477,211 481,211 484,209 486,211 491,211 492,210 496,211 498,209 500,209 503,206 505,206ZM439,190 439,192 450,196 454,196 455,197 455,191 454,190 448,192 444,192ZM577,166 565,167 564,168 555,169 554,170 546,171 545,172 537,172 534,170 532,171 533,173 537,176 541,176 542,177 545,175 550,175 551,173 553,174 555,173 557,174 560,173 568,174 571,171 573,171ZM291,145 292,145 293,147 298,147 300,145 297,144 292,144ZM83,144 83,146 86,148 89,148 93,146 93,144ZM489,66 479,66 474,68 470,68 469,69 464,69 463,70 444,73 439,78 438,81 438,87 439,88 439,92 441,96 441,99 439,101 434,101 429,105 429,133 434,143 434,178 436,180 438,180 441,183 447,185 446,184 446,165 449,164 453,166 455,168 458,169 462,173 462,181 459,183 462,185 462,194 465,197 470,199 474,202 475,202 474,200 474,168 479,163 480,133 483,131 484,132 483,134 488,134 490,133 492,130 493,131 495,129 497,130 499,128 500,129 501,128 505,128 510,126 512,127 511,126 512,125 516,125 517,128 517,126 511,116 505,111 503,114 501,114 497,117 490,117 489,118 486,117 483,118 481,120 475,120 473,121 472,120 469,120 466,117 470,112 470,109 471,108 471,100 465,85 470,81 472,83 475,82 485,83 490,78 492,78 495,76 500,75 502,77 496,71ZM553,29 545,30 544,31 536,32 535,33 530,33 525,35 520,35 519,36 516,36 510,38 507,41 505,45 506,58 508,63 505,65 501,65 511,79 513,83 513,86 515,89 516,99 515,100 515,105 513,109 517,113 522,122 523,129 524,130 524,134 525,133 528,136 528,144 529,145 526,147 528,149 529,158 532,161 537,163 539,165 542,165 541,164 541,132 546,126 546,105 547,104 546,100 551,96 553,97 555,95 562,96 566,94 573,94 574,93 578,93 581,89 583,90 577,79 571,74 573,76 570,79 567,80 562,80 560,79 555,81 548,81 540,84 537,84 534,82 534,80 537,75 537,67 538,66 536,62 536,58 534,54 534,51 535,50 539,50 544,44 548,45 552,41 555,41 556,44 557,44 558,41 562,38 564,39 566,38 568,40 559,31Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M523,130 523,147 524,148 524,152 523,153 523,156 521,159 523,158 524,159 524,162 528,165 524,162 525,157 526,156 527,157 527,149 523,146ZM230,91 227,95 224,93 223,94 226,97 225,96 226,95 230,94Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M459,194 458,198 465,203 466,202 464,200 466,199 464,198 465,199 463,200 462,199 462,196ZM441,185 441,188 444,190 447,190 448,189 448,187 443,187 442,185ZM517,178 516,178 515,181 514,180 514,188 515,187 516,189 514,190 514,194 512,196 504,197 503,198 495,199 494,200 490,200 490,203 488,204 490,203 500,202 501,201 505,201 506,200 510,200 515,198 517,196ZM514,163 514,176 514,173 515,172 516,173 516,176 517,176 517,163 515,164ZM429,159 429,179 433,184 436,186 438,186 437,184 439,183 435,181 432,178 432,159ZM234,152 237,155 239,152 238,151ZM352,150 351,151 350,150 350,156 354,153 354,151ZM145,150 143,150 144,152 144,155 143,156 147,153 147,151ZM29,149 27,152 31,156 32,155 32,151ZM232,137 230,138 230,139 233,142 234,141 234,138ZM149,136 147,138 148,139 148,143 153,139ZM26,136 25,139 24,137 23,138 24,140 25,139 27,142 26,143 27,142 27,139 26,138 28,137ZM580,130 580,140 581,138 583,138 584,140 584,130 582,131ZM397,125 400,125 405,127 409,132 409,140 405,145 401,147 396,147 392,145 387,138 388,137 387,134 388,132 394,126ZM97,126 96,129 97,131 100,131 102,133 102,138 101,139 100,138 99,139 95,138 96,139 94,140 96,142 103,142 106,138 106,133 104,129 101,129 100,128 101,127ZM360,123 357,124 358,129 359,129 362,125 362,124ZM152,123 150,125 152,131 152,128 155,125 155,124 154,125ZM75,123 75,127 69,131 69,139 72,142 79,142 78,139 79,138 82,138 74,139 72,137 72,134 75,131 78,130 78,123ZM20,124 23,129 24,129 25,124 24,123ZM402,122 393,123 389,126 385,131 385,134 384,135 385,137 385,141 386,143 394,150 405,149 411,143 413,137 413,133 410,127ZM303,122 303,130 306,131 309,134 309,136 306,139 305,138 304,139 303,138 298,138 299,139 298,142 309,142 313,137 313,133 312,131 307,127 306,122ZM229,122 226,124 226,125 227,125 230,128 230,130 231,130 231,126 232,125 231,123ZM589,119 588,119 585,123 584,122 582,124 585,124 586,125 585,126ZM361,109 360,110 359,109 357,111 360,113 359,114 362,111ZM152,109 152,112 153,115 154,115 154,113 157,110 154,109 153,110ZM23,109 19,111 22,114 23,114 24,111ZM189,99 193,99 195,101 195,107 196,108 202,108 204,110 204,113 202,115 196,115 195,116 195,123 193,125 189,125 188,124 188,120 187,119 188,116 187,115 180,115 178,113 178,110 179,109 187,108 188,106 187,102ZM188,96 185,98 184,103 181,107 179,105 175,107 175,115 177,118 182,119 184,121 184,124 187,128 195,128 198,124 197,122 200,119 203,118 204,119 207,116 207,107 204,105 199,105 197,102 196,97 194,96ZM434,95 432,97 428,98 424,104 424,108 423,109 423,119 423,112 427,109 427,105 428,103 431,100 434,100 433,97ZM358,95 356,97 359,101 360,101 362,96ZM152,95 150,97 152,100 153,100 156,96ZM22,95 21,96 22,101 24,98 24,96ZM396,84 401,84 405,86 410,92 409,93 409,96 411,97 409,98 409,99 403,105 400,106 394,105 388,99 388,91 392,86ZM233,82 230,82 230,86 231,88 232,85 234,84ZM394,81 391,84 389,84 387,86 387,88 385,89 384,92 385,96 384,98 385,101 391,106 392,108 397,108 398,109 403,108 411,102 411,100 413,97 413,91 408,84 402,81ZM356,81 355,84 358,86 360,82ZM150,81 150,82 148,83 150,86 151,86 152,82ZM26,81 22,82 24,86 27,84ZM97,77 90,77 81,81 75,81 70,85 70,92 75,96 75,102 76,102 77,100 78,102 78,92 75,91 73,89 73,87 77,84 82,84 91,80 95,80 97,82 97,95 100,97 100,81ZM303,77 300,77 299,76 286,81 281,81 276,85 276,90 278,93 281,95 281,119 282,120 281,123 282,124 281,127 278,129 276,132 276,139 280,142 292,142 293,140 289,138 286,138 285,139 284,138 281,138 279,136 279,134 281,132 284,131 285,129 285,93 280,90 280,86 282,84 288,84 297,80 301,80 304,82 304,87 303,88 306,89 306,97 304,101 303,98 303,102 306,102 306,98 307,97 306,96 307,95 307,81 306,79ZM223,73 224,76 222,78 221,76ZM37,69 38,68 42,71 39,72ZM488,61 483,61 482,62 477,62 476,63 468,63 467,64 463,64 460,66 458,65 454,67 441,69 434,77 434,81 433,82 433,85 434,86 433,89 434,88 437,89 435,88 437,87 437,80 438,77 443,72 446,72 451,70 455,70 456,69 460,69 461,68 469,67 470,66 480,65 476,65 475,64 480,62 483,64 485,64 487,63 486,62ZM348,55 350,55 352,57 355,62 355,65 356,66 359,64 361,64 363,66 364,69 364,78 367,81 367,84 368,85 368,89 366,93 367,93 370,97 370,102 369,105 367,107 370,110 370,117 366,122 366,123 369,125 369,129 367,134 365,136 366,139 365,146 360,152 362,154 360,160 355,165 352,166 349,166 346,163 344,163 341,159 341,153 342,150 346,147 346,143 345,142 346,141 346,137 350,133 348,129 349,127 348,126 349,123 351,121 353,121 350,117 350,110 353,108 350,104 350,101 349,100 349,97 351,94 349,92 347,86 348,81 345,77 343,72 346,69 349,69 347,67 346,64 346,57ZM140,55 143,55 149,62 149,68 152,64 154,64 156,66 158,72 157,78 159,79 161,82 160,83 161,84 160,93 163,95 163,102 162,103 162,106 160,108 163,110 163,118 162,120 159,122 162,125 161,133 158,136 159,144 158,147 154,151 155,155 153,160 146,166 143,166 141,164 141,162 138,163 134,158 134,154 136,148 137,147 140,147 139,145 139,138 140,136 143,134 142,131 142,123 145,121 143,117 143,110 146,107 143,103 143,99 142,98 144,95 140,85 142,81 138,77 137,74 137,71 139,69 143,69 140,66 139,63 139,56ZM34,55 36,57 36,64 33,69 36,69 38,71 38,74 37,75 38,76 36,79 33,81 35,84 35,87 31,94 33,97 33,101 30,107 32,110 32,117 30,121 33,123 34,126 33,134 36,138 37,141 36,142 37,144 36,147 38,147 40,150 41,158 40,161 37,164 34,163 33,166 29,166 22,160 20,155 22,151 17,146 16,143 16,139 18,136 14,132 13,129 13,125 16,122 12,117 12,110 14,108 12,102 12,98 13,95 16,93 14,89 14,83 15,80 18,78 18,69 19,67 22,64 26,67 27,61 33,55ZM345,52 342,56 342,64 343,65 340,69 340,75 344,81 343,83 346,92 346,104 348,108 346,111 347,120 345,123 345,132 343,135 342,143 340,145 340,149 337,154 337,159 339,163 342,166 348,169 354,169 357,168 363,162 364,157 366,154 365,151 368,148 369,145 370,135 372,131 372,120 373,119 373,113 374,112 372,106 373,104 373,95 371,91 371,82 370,81 370,78 368,76 368,70 367,67 363,61 359,61 358,59 356,58 356,56 351,52ZM138,52 136,55 136,58 135,59 136,66 133,71 133,73 134,74 134,77 137,81 138,91 140,94 139,102 141,105 141,108 140,109 140,120 139,121 138,132 137,133 137,136 136,137 136,140 134,146 131,152 131,158 132,159 132,162 136,166 139,167 141,169 147,169 150,168 155,164 158,158 159,151 163,142 163,135 165,132 165,129 166,128 165,127 166,126 165,121 167,115 167,111 165,106 166,104 166,96 165,94 166,93 165,92 165,84 164,83 164,80 161,76 161,70 159,67 159,64 156,61 152,60 150,58 150,56 145,52ZM240,51 234,55 229,61 225,61 221,69 221,76 218,81 218,85 217,86 217,90 218,91 217,92 218,91 221,92 221,83 222,80 225,78 224,72 226,66 229,64 233,68 234,73 235,73 236,71 233,69 233,64 235,59 239,55 241,55 243,57 243,63 239,69 243,69 245,71 245,74 244,77 240,81 242,84 241,85 241,89 238,94 239,97 239,104 236,107 239,110 239,117 237,121 240,123 240,131 238,134 240,134 242,136 243,139 243,147 247,150 248,157 247,160 239,166 234,165 228,159 228,156 227,155 228,151 224,147 223,144 223,138 224,136 221,132 220,126 219,125 222,123 218,114 219,113 219,110 221,107 219,103 219,98 217,98 216,96 216,109 215,110 216,113 215,116 217,120 216,129 217,130 217,133 219,136 219,142 223,151 223,155 227,164 230,167 234,169 239,169 249,164 251,160 251,152 249,147 246,144 246,136 244,133 243,120 242,119 242,104 243,103 243,96 242,94 245,85 245,81 247,79 247,77 249,74 249,70 246,66 246,61 247,60 246,55 243,52ZM35,51 30,52 22,61 19,61 17,63 14,72 14,75 15,76 12,79 11,82 11,92 9,95 9,119 10,120 10,123 9,124 10,125 9,126 10,127 10,133 12,135 13,145 14,148 17,151 16,155 18,158 19,162 23,167 28,169 33,169 38,167 42,164 45,158 45,155 43,154 44,149 40,143 39,135 37,131 37,125 35,120 35,116 36,115 36,111 35,110 36,92 38,88 38,81 40,79 42,74 42,71 40,68 40,55 39,53ZM502,38 502,40 500,42 500,55 500,53 504,51 503,50 503,47 505,41 510,36 516,35 517,34 521,34 522,33 526,33 529,29 537,28 538,29 536,31 535,31 537,30 541,30 542,29 547,29 548,28 555,28 556,29 558,28 559,30 570,39 569,40 573,45 573,47 577,55 577,67 573,74 580,81 585,89 585,93 586,94 586,100 587,99 589,100 589,93 588,92 587,85 585,83 585,81 578,73 580,69 580,64 581,63 580,62 580,55 579,54 578,48 576,46 573,38 570,34 565,30 565,29 562,28 560,26 548,25 547,26 542,26 537,28 535,27 531,29 529,28 526,30 524,29 523,30 519,30 517,32 514,31 506,34Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M463,197 463,199 467,202 466,203 473,207 475,206 485,205 489,203 489,200 488,202 485,201 484,202 479,202 478,203 472,203 470,201 465,200 464,199 465,198 464,199ZM446,186 449,187 448,190 449,189 453,189 455,188 457,190 457,196 459,193 461,195 460,194 460,185 459,184 452,185 451,186ZM584,141 583,139 581,139 580,141 580,158 578,160 570,161 569,162 561,163 560,164 556,164 555,165 544,166 543,167 539,167 528,160 526,160 526,161 529,165 532,167 533,165 534,168 535,167 536,169 538,170 552,169 557,167 562,167 563,166 567,166 572,164 580,163 583,160 583,157 584,156 583,153 583,142ZM290,138 292,138 294,140 293,142 297,142 298,139 297,138ZM79,139 80,142 95,142 96,141 95,142 93,140 95,139 94,138 91,139 87,139 86,138 84,139ZM427,110 424,112 424,121 423,122 424,125 423,126 424,127 424,135 425,138 429,143 429,158 432,158 432,142 430,140 427,131ZM303,106 303,121 306,121 306,106ZM77,101 77,102 75,103 75,122 78,122 78,103ZM587,100 586,101 586,115 587,116 584,121 585,122 587,119 589,118 589,117 587,116 589,115 589,101ZM97,96 96,98 96,126 97,125 100,126 100,98ZM222,91 221,93 220,92 217,93 216,95 217,97 219,97 222,93ZM305,89 303,89 303,97 304,100 305,97ZM437,88 434,89 434,94 435,95 434,97 435,99 438,99 439,96 437,90 435,89ZM501,53 500,56 501,58 499,60 500,61 499,62 497,61 495,62 487,62 488,63 486,64 489,64 499,71 506,81 510,91 511,100 510,101 510,104 506,110 514,118 518,125 518,128 519,129 519,155 514,161 515,163 518,162 520,160 523,152 523,148 522,147 522,126 521,123 519,121 518,117 511,109 513,106 513,103 514,102 514,92 508,77 499,66 500,64 506,62 504,57 504,52ZM537,29 529,30 528,32 531,32Z\"/><path fill=\"#a63441\" fill-rule=\"evenodd\" d=\"M359,154 354,155 349,163 350,164 355,163 359,158ZM229,154 231,160 234,163 238,164 239,163 238,159 233,154ZM152,153 148,154 146,156 143,161 143,164 147,164 151,160 153,155ZM23,153 22,155 25,161 29,164 32,164 33,162 31,159 26,154ZM345,149 343,153 343,159 346,161 348,158 348,151ZM138,149 136,153 136,159 138,161 140,161 142,156 142,152 140,149ZM38,149 36,149 34,151 34,159 36,161 39,159 39,152ZM243,148 241,150 240,156 241,159 244,161 246,158 246,153 245,150ZM364,139 360,140 357,143 357,145 355,148 356,150 360,149 363,146 365,140ZM225,139 224,141 226,146 230,150 233,150 234,149 231,143 227,139ZM157,139 153,140 151,142 150,146 148,148 149,150 152,150 157,145 157,142 158,141ZM18,139 18,144 19,146 23,150 26,151 27,150 26,145 22,140ZM349,136 347,140 347,143 348,146 351,148 353,144 353,140 352,138ZM240,136 238,136 236,138 236,145 238,149 241,146 241,137ZM142,136 141,137 141,146 144,149 146,145 146,139ZM33,136 29,139 29,145 30,148 32,148 35,144 35,140ZM366,125 364,125 361,128 359,134 360,137 366,133 367,130 367,126ZM222,125 223,128 222,131 229,137 230,135 229,134 229,130 226,126ZM159,125 156,126 154,128 153,134 152,135 153,137 156,136 159,133 160,131 160,126ZM15,125 15,130 17,133 22,137 23,136 23,133 21,131 21,128 19,126ZM352,123 350,129 352,131 352,134 354,135 356,133 356,127 355,125ZM237,123 233,126 232,129 233,135 235,135 238,131 239,127ZM145,123 144,124 144,131 147,135 149,135 149,132 150,131 149,130 149,126ZM30,123 29,123 26,127 26,134 27,135 29,135 30,132 32,130 32,127ZM367,110 363,113 361,117 361,122 364,122 367,119 368,117 368,111ZM353,110 352,111 352,118 357,122 358,121 358,115 357,113ZM236,110 231,114 231,121 232,122 234,121 237,117 237,111ZM222,110 221,111 221,117 224,122 227,122 228,121 227,120 227,115 225,112ZM160,110 158,111 155,115 155,121 157,122 161,117 161,111ZM146,110 145,111 145,116 146,119 150,122 151,121 151,114ZM28,110 24,115 24,120 25,121 27,121 30,117 30,111ZM15,110 14,111 14,117 18,122 21,122 21,117 19,113ZM352,97 351,98 352,104 357,108 358,107 358,102 354,97ZM236,97 233,98 231,101 231,105 230,106 231,108 233,108 237,104 237,98ZM146,97 145,98 145,103 149,108 151,108 152,107 151,106 151,101ZM28,97 24,102 24,107 25,108 30,104 30,98ZM366,95 362,100 362,107 363,108 367,105 368,102 368,99ZM222,95 221,96 221,104 223,107 226,108 227,107 227,100 226,98ZM160,95 157,97 155,101 155,107 156,108 160,105 161,102 161,96ZM16,95 14,97 14,102 15,105 19,108 20,107 20,100ZM350,84 349,85 350,90 356,95 357,93 356,88 352,84ZM239,84 236,84 233,87 232,94 235,94 238,91 240,85ZM143,84 142,85 143,86 143,89 145,92 149,95 150,94 150,91 148,86 145,84ZM32,84 29,84 26,87 25,90 25,93 26,94 28,94 32,90 32,87 33,86ZM365,81 363,81 361,83 360,86 360,90 362,94 365,91 366,88ZM18,81 16,84 16,88 17,91 20,94 22,91 22,85 21,83ZM225,80 223,83 223,90 224,92 227,94 229,88 228,87 228,83ZM157,80 153,86 154,93 155,94 158,92 160,88 159,86 159,82ZM346,71 345,72 347,75 347,77 351,81 354,81 355,80 353,75 350,72ZM242,71 236,74 234,79 235,81 239,80 242,77 243,74ZM140,71 139,72 140,77 143,80 147,81 148,79 146,74 144,72ZM36,71 32,72 28,76 28,79 27,80 28,81 31,81 35,77ZM360,66 359,66 357,70 357,77 359,80 362,77 362,69ZM229,66 226,70 226,76 227,78 230,80 232,76 232,70ZM153,66 150,70 150,76 152,80 153,80 156,76 156,71 155,68ZM22,66 20,69 19,74 20,77 23,80 25,77 25,69ZM348,57 347,58 348,64 349,66 353,69 354,68 354,64 352,60ZM241,57 239,57 235,62 235,69 237,69 240,66 242,61ZM142,57 141,58 141,63 143,67 146,69 147,68 147,63 145,59ZM34,57 29,61 28,64 28,68 29,69 33,66 35,62 35,58Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M230,115 228,116 228,120 229,121 227,123 221,125 221,128 222,129 221,125 222,124 225,125 224,124 227,123 230,120ZM160,109 159,110 160,109 162,111 162,117 161,119 156,123 154,121 154,117 153,117 152,115 152,118 154,119 154,122 156,123 157,125 159,124 161,126 161,128 161,125 158,123 162,117 162,110ZM237,105 233,109 231,109 229,107 230,102 228,103 228,107 226,109 224,108 220,110 220,117 222,120 220,117 220,111 223,108 225,109 224,110 227,114 224,110 229,107 233,110 231,113 235,109 237,110 234,108ZM361,101 361,102 359,103 359,107 357,109 352,105 355,108 351,110 351,116 351,111 353,109 355,110 358,114 355,110 359,108 362,108 361,107ZM148,97 152,101 152,106 153,107 150,109 153,107 155,108 154,107 154,103 153,103ZM14,103 14,105 18,109 17,110 19,112 17,110 21,108 26,109 27,110 24,114 24,113 29,109 31,111 31,116 31,110 27,108 31,104 31,97 30,96 31,98 31,104 26,109 23,107 23,103 21,102 20,99 21,100 21,107 19,109 14,105Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M355,137 357,139 355,142 354,141 354,138ZM223,134 225,136 224,139 225,138 229,139 234,145 234,142 233,143 229,138 233,136 235,139 238,135 234,137 231,135 231,136 228,138ZM357,127 358,130 357,135 354,137 350,134 354,139 354,146 351,150 352,149 353,150 356,142 360,139 360,138 358,137 358,132 359,130 357,129ZM367,108 363,109 363,111 360,114 359,113 360,114 359,115 359,121 357,123 354,122 351,122 350,123 353,122 356,125 358,122 361,123 360,122 360,116 361,113ZM228,108 226,110 228,111 227,113 228,115 229,115 232,111ZM348,80 349,81 348,86 349,83 353,83 357,87 358,91 359,91 359,85 359,86 357,87 354,84 355,82 350,82ZM240,67 237,70 237,72 233,75 231,81 233,81 234,75 239,70 243,70 244,71 243,70 239,70 238,69Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M413,138 412,143 405,150 394,151 387,146 394,151 404,151 411,145ZM385,130 389,125 393,122 396,122 397,121 402,121 408,124 411,127 411,128 408,124 402,121 396,121 390,123 386,127ZM97,76 101,81 101,97 101,81 100,79 97,76 89,76 88,77 85,77 83,79 74,80 70,82 69,84 69,88 68,89 69,92 74,97 74,102 74,96 69,92 69,84 75,80 80,80 89,76ZM499,59 494,61 484,59 483,60 479,60 474,62 469,62 475,62 476,61 482,61 483,60 495,61ZM246,53 242,50 239,50 235,52 235,53 233,54 229,59 225,60 221,66 220,69 220,75 220,69 223,62 225,60 230,59 231,57 239,50 243,51 247,55 247,58 248,59ZM536,27 542,25 545,25 546,24 554,24 555,23 557,25 560,25 562,27 565,28 555,23 548,23 545,25 537,26Z\"/>",
	E: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M313,127 308,130 306,134 306,137 309,143 313,145 317,145 322,142 324,138 324,134 321,129 317,127ZM313,86 307,91 306,97 309,102 313,104 316,104 322,101 324,97 324,93 321,88 317,86ZM180,84 176,84 173,86 167,87 166,88 162,88 161,89 162,91 164,91 166,93 166,133 164,135 161,136 162,139 186,139 187,138 186,135 183,135 181,133 181,85Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M464,126 460,126 459,127 452,128 449,131 443,141 447,141 450,138 453,137 459,131 461,130 460,129 462,127 464,127ZM394,124 398,129 404,134 402,135 406,140 412,141 412,139 407,133 406,130 402,127 396,124Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M385,176 385,178 388,181 388,183 393,184 398,187 403,187 405,189 410,189 411,190 414,190 415,189 416,190 420,190 421,189 424,190 427,189 428,190 440,190 441,191 443,191 445,189 448,190 451,188 457,188 466,182 469,182 468,181 474,177 474,176 472,176 457,184 400,184ZM165,146 165,147 170,151 170,150 168,149 169,148 175,148 176,147 175,146ZM451,128 449,129 445,129 444,130 439,130 434,132 430,132 429,133 425,133 424,134 420,134 419,135 414,135 417,135 420,137 421,136 425,137 427,135 430,135 435,132 437,133 440,132 443,132 444,133 446,132 447,133 445,136ZM467,125 465,126 464,128 462,128 461,129 462,130 447,142 443,142 442,141 439,146 445,146 447,147 446,147 445,145 448,142 457,139 460,134 464,131ZM388,120 388,122 391,125 391,127 396,133 409,145 407,147 405,147 417,146 420,149 416,145 413,140 412,142 406,141 401,135 403,134 401,133 393,124 395,123 392,122 390,120Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M446,146 452,146 455,147 453,147 452,145 454,143 458,142 450,142 448,143ZM401,142 403,145 402,147 408,145 404,142ZM407,130 409,132 410,135 413,137 414,141 420,148 417,145 418,143 420,142 421,143 424,141 425,142 428,142 429,140 435,140 436,139 441,141 446,133 444,134 443,133 440,133 439,134 435,133 430,136 427,136 425,138 423,137 420,138 417,136 414,136 413,135 414,134 424,133 413,133Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M459,143 454,144 453,146 456,147 455,146ZM401,143 399,143 400,145 399,148 402,146ZM440,141 437,141 436,140 435,141 429,141 428,143 425,143 424,142 421,144 420,143 418,144 418,145 420,147 424,145 425,146 427,144 430,146 433,144 437,144 438,145 437,146Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M232,152 230,153 230,157 234,155ZM116,151 114,153 114,155 118,158 118,152ZM372,162 372,164 375,168 385,173 395,180 397,180 403,183 448,183 447,181 448,180 451,180 450,179 402,179 380,167 376,162 379,159 392,152 397,148 396,147 393,147 380,154 380,155 377,156ZM484,159 481,156 479,156 469,149 465,148 462,146 458,146 459,148 478,159 481,163 477,167 474,168 462,176 456,178 455,179 455,182 458,182 469,175 481,169 485,165 485,161ZM112,138 110,139 109,141 113,144 114,139ZM237,137 233,140 234,141 234,146 238,141ZM313,125 320,126 326,133 326,139 325,141 320,146 317,147 312,147 310,146 305,141 304,138 304,133 305,131 310,126ZM240,125 236,126 237,131 238,131 241,127ZM108,125 107,127 108,129 110,130 110,127 112,126ZM312,122 307,124 303,128 303,130 301,133 301,139 302,140 302,143 310,150 319,150 322,149 327,144 329,141 329,135 328,134 327,128 320,122 314,122 313,123ZM239,111 237,112 237,113 239,115 239,117 240,117 242,113ZM107,111 106,114 108,117 109,117 109,115 111,112ZM118,105 117,108 115,110 117,110 119,112 119,116 118,117 117,123 119,125 119,119 120,118 122,124 121,125 122,125 122,121 121,120 122,118 122,111 121,108 120,109 117,108ZM183,100 183,132 184,133 187,133 189,135 189,138 187,140 179,140 179,144 188,144 192,141 192,133 186,129 186,100ZM238,97 236,99 240,102 241,98ZM110,97 107,98 108,102 109,102 111,99ZM313,84 320,85 325,90 326,93 326,98 325,100 321,104 317,106 310,105 306,101 304,97 305,90 309,86ZM237,83 234,85 237,88 237,91 238,91 238,86 239,84ZM112,83 109,84 110,89 111,89 113,86ZM305,84 301,92 301,97 303,103 309,108 312,108 313,109 314,108 315,109 322,108 327,103 329,99 328,98 329,97 329,92 326,86 319,81 311,81 307,84ZM184,79 175,79 169,82 160,83 156,86 156,94 161,98 161,128 157,131 155,134 155,141 158,144 174,144 174,140 161,140 159,138 159,135 161,133 164,132 164,94 161,93 159,91 159,88 161,86 166,86 177,82 181,82 183,84 183,89 186,88 187,90 187,84ZM471,60 470,60 472,67 472,112 471,115 466,120 458,121 456,122 456,125 460,125 461,124 468,123 474,117 475,114 475,66ZM226,53 223,54 222,56 222,68 220,70 219,73 220,74 220,78 223,83 223,87 226,95 226,107 227,108 226,111 226,124 225,125 225,132 223,135 223,138 221,142 221,146 218,150 218,153 217,154 217,161 218,164 222,168 228,171 233,171 238,169 242,165 243,161 245,158 245,153 247,151 248,148 249,139 252,131 252,121 253,120 252,117 253,116 253,111 253,113 250,115 250,118 246,124 246,125 249,127 249,129 247,135 244,138 246,141 246,143 244,149 240,153 242,156 240,159 240,161 238,164 234,167 229,167 226,165 224,165 220,159 220,156 222,150 224,148 226,148 225,146 225,141 226,138 229,135 228,127 231,123 229,116 230,115 230,112 233,110 229,104 229,99 231,97 227,90 227,86 229,84 225,80 225,78 223,76 223,73 225,71 228,71 225,64 225,58 227,56 233,60 235,64 235,69 240,65 243,69 243,72 244,73 244,78 243,80 246,82 248,88 246,95 249,97 249,99 252,99 252,95 251,94 251,84 249,81 249,79 247,77 247,71 245,66 242,63 238,62 233,55 230,53ZM120,53 115,55 115,56 109,62 106,62 103,65 103,68 101,71 101,74 100,75 101,77 97,85 97,94 95,99 95,105 96,106 96,110 95,111 95,121 96,122 96,132 99,139 99,146 101,151 103,153 103,158 105,163 110,169 114,171 120,171 124,168 126,168 130,164 131,154 129,151 129,149 126,145 126,140 123,133 123,127 121,130 120,128 119,135 121,137 123,142 123,146 122,148 126,151 128,158 126,163 124,165 121,165 119,167 114,167 110,164 106,156 107,155 107,152 104,149 102,143 102,141 104,138 100,134 99,127 102,125 102,124 98,119 99,118 98,116 98,112 101,110 99,107 99,97 101,95 103,95 101,93 101,84 102,82 105,80 104,79 104,72 105,69 108,66 112,68 114,62 120,56 123,59 123,63 122,64 122,67 119,71 123,71 125,73 125,75 123,78 123,80 120,83 121,89 117,97 119,99 119,102 122,102 122,94 124,90 124,84 128,77 128,70 126,68 126,57 124,54 121,54ZM442,39 425,40 424,41 420,41 414,43 409,43 408,44 399,45 395,47 390,47 387,48 381,55 381,109 382,112 387,117 392,119 396,122 398,122 399,124 413,132 425,132 426,131 431,131 436,129 445,128 445,125 446,124 439,125 438,126 434,126 429,128 425,128 424,129 416,129 404,123 399,119 397,119 394,116 389,114 386,111 384,106 384,56 389,51 395,50 396,49 401,49 402,48 406,48 407,47 411,47 417,45 422,45 423,44 431,43 432,42 441,42 452,49 457,51 460,54 462,54 468,58 469,57 469,55 459,48 455,47 452,44 449,44 446,41Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M454,179 451,179 452,180 451,181 448,181 449,183 453,183 454,182ZM436,145 434,147 424,148 422,149 427,157 431,154ZM175,140 175,144 178,144 178,140ZM455,122 447,124 446,127 454,126 455,125ZM122,103 119,103 118,108 121,107ZM249,100 248,109 250,110 249,111 250,114 252,113 252,100ZM183,95 184,96 183,99 186,99 186,97 184,96 186,95ZM184,89 183,90 183,93 186,93 186,89 185,90Z\"/><path fill=\"#a63441\" fill-rule=\"evenodd\" d=\"M239,155 236,155 231,160 229,164 230,166 234,165 238,161ZM109,155 108,156 110,161 114,165 118,166 119,164 117,160 113,156ZM122,151 120,153 120,160 122,163 124,163 126,156 124,153 124,151ZM225,150 223,152 223,155 222,156 222,160 224,163 226,163 228,158 228,154ZM404,148 407,150 408,152 407,154 410,156 410,158 416,164 419,165 420,163 424,166 423,168 425,170 426,173 425,177 429,177 430,176 430,173 437,166 438,166 442,161 444,161 444,160 446,159 448,156 448,151 450,149 452,149 452,147 451,148 448,147 447,148 445,147 438,147 430,158 427,159 417,147ZM243,141 238,143 234,151 235,152 238,152 241,150 243,147 243,144 244,143ZM105,141 104,142 105,148 109,152 113,152 113,149 110,144 108,142ZM228,139 227,141 227,146 228,149 231,150 233,146 232,144 232,140ZM120,138 118,138 116,140 115,143 116,149 118,151 121,146ZM247,127 244,127 240,131 239,138 241,138 245,135ZM102,126 101,127 101,130 103,135 109,138 109,133 107,129ZM231,125 230,126 230,132 231,135 234,137 236,134 236,129 234,126ZM117,125 115,125 112,129 112,135 114,137 117,135 116,134 118,132 118,126ZM247,112 245,112 243,114 241,119 241,124 243,124 247,120 248,118 248,113ZM232,112 231,117 232,120 236,124 237,123 237,115 234,112ZM115,112 114,112 110,117 110,121 111,123 113,123 116,120 117,114ZM101,112 100,113 101,121 103,123 106,124 107,123 107,118 104,113ZM232,99 231,100 232,107 234,109 237,110 238,109 237,102 234,99ZM116,99 114,99 110,104 110,109 111,110 113,110 117,105 117,100ZM246,97 243,99 241,103 241,109 242,110 245,109 247,105 247,98ZM102,97 101,98 101,107 103,109 106,110 107,109 106,101 105,99ZM229,86 229,90 234,96 236,96 237,94 235,89 232,86ZM118,86 116,86 112,89 112,92 111,93 112,96 114,96 117,94 119,89ZM244,82 243,82 240,86 240,95 241,96 245,93 246,90 246,87ZM104,82 102,86 102,90 103,93 107,96 108,95 108,86 107,84ZM226,73 225,74 226,78 231,83 233,83 234,82 233,77 230,74ZM122,73 118,74 115,77 114,79 114,82 115,83 117,83 121,79 123,75ZM240,68 239,68 236,72 236,77 238,82 242,79 242,72ZM108,68 106,71 106,79 109,82 111,80 112,73 110,69ZM121,59 119,59 115,64 114,69 116,71 120,67ZM228,58 227,59 227,65 232,71 233,70 233,64Z\"/><path fill=\"#d2263b\" fill-rule=\"evenodd\" d=\"M467,61 463,63 457,63 450,66 444,66 443,67 434,68 431,70 430,69 423,70 418,74 415,79 415,104 414,105 415,113 413,117 413,122 415,124 416,127 423,127 432,124 438,124 446,121 458,120 462,118 465,118 469,114 469,63Z\"/><path fill=\"#e73d4e\" fill-rule=\"evenodd\" d=\"M479,162 475,159 470,157 465,153 463,153 460,150 456,148 453,148 452,150 449,151 449,156 447,159 445,160 444,162 442,162 442,163 431,173 431,176 430,177 455,177 466,171 468,169 477,165ZM378,162 380,165 383,166 385,168 387,168 392,172 394,172 402,177 424,177 425,175 424,170 422,168 423,166 420,164 419,166 416,165 409,158 409,156 406,154 407,153 406,150 403,148 399,149ZM442,45 434,44 433,45 428,45 422,47 416,47 415,48 411,48 406,50 392,52 386,56 386,107 391,113 396,115 413,126 414,126 414,124 412,122 412,117 414,113 414,109 413,108 413,105 414,104 414,79 417,74 423,69 427,69 428,68 431,69 434,67 438,67 444,65 450,65 457,62 463,62 467,60 469,62 465,58Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M238,116 238,123 237,124 239,123 243,126 240,130 244,126 246,126 245,126 244,124 247,121 243,125 241,125 240,124 240,120 238,119Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M421,148 424,147 430,147 435,145 433,145 430,147 427,145 425,147 424,146 421,147ZM399,145 396,144 391,147 396,146 398,148 397,149 399,147ZM118,134 115,138 114,144 112,145 115,151 114,141 118,136 120,137ZM238,102 239,103 239,110 238,111 239,110 242,112 246,111 247,108 242,112 240,110 240,103ZM228,69 229,72 235,77 235,71 236,70 232,73ZM119,72 118,71 114,76 113,75 113,68 112,69 113,71 113,78 112,81 110,83 108,83 106,81 103,82 105,81 108,84 112,82 114,76ZM465,57 469,60 471,59 474,62 475,65 473,58 470,55 470,57 468,59Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M300,132 300,140 301,142 300,139 300,133 302,130 302,128 307,123 311,121 313,122 314,121 320,121 328,128 329,134 330,135 330,140 330,133 328,130 328,128 325,124 320,121 311,121 304,125 302,128 302,130ZM300,91 300,99 304,106 312,110 319,110 326,106 327,104 322,109 318,109 317,110 309,109 302,103 300,97 300,92 301,91ZM126,54 123,52 118,52 116,53 109,61 107,61 109,61 115,54 119,52 124,53 126,55ZM421,40 431,39 432,38 442,38 446,40 449,43 452,43 455,46 459,47 464,51 470,54 473,57 464,50 443,38 434,37 431,39Z\"/>",
	F: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M304,127 297,129 294,133 294,139 295,141 300,145 305,145 307,144 311,140 311,137 312,136 311,135 311,132 307,128ZM301,86 295,90 294,92 294,98 298,103 305,104 311,99 311,91 307,87ZM168,82 165,82 155,86 150,86 149,88 154,92 154,131 152,133 149,133 148,134 149,137 173,137 174,136 174,134 171,133 168,130 168,98 169,97 169,83Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M427,178 429,179 435,179 436,180 435,181 432,181 447,181 449,178ZM506,138 503,138 502,137 496,148 500,148 502,146ZM503,89 501,91 501,93 505,98 506,101 508,102 509,106 514,106 510,106 509,105 511,101 509,99 505,90ZM466,53 474,53 480,55 477,52 478,51 477,50 467,50Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M408,188 408,189 411,189 413,190 414,192 419,194 420,193 430,194 433,191 436,193 445,193 446,194 447,193 469,193 470,192 475,192 477,190 480,189 480,188ZM500,92 493,100 494,101 497,99 498,96 500,94 502,95Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M501,95 503,97 500,95 494,104 500,99 500,96ZM509,82 500,91 503,88 505,88 507,92 508,89 511,89 508,85ZM433,55 410,55 405,59 404,62 402,64 391,85 389,87 380,104 377,107 374,113 374,118 381,129 383,134 385,136 387,135 397,119 397,117 399,115 402,108 406,103 409,96 414,90 416,84 418,82 424,70 428,66 428,64 431,60Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M228,101 226,102 227,103 227,108 230,109 228,108ZM501,96 501,99 494,105 494,107 489,113 493,108 495,107 497,108 499,103 502,102 503,100 505,101ZM508,90 508,93 510,97 509,94 510,93 513,93 511,90Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M220,150 217,151 217,156 221,153ZM512,139 509,140 509,142 507,143 505,147 508,146 510,141ZM99,137 97,139 100,143 101,143 101,139 102,137ZM224,136 222,137 222,140 223,141 222,142 226,139ZM301,125 304,125 309,127 313,132 314,135 312,142 309,145 305,147 300,147 294,143 292,137 291,138 289,137 289,134 292,133 291,132 298,126ZM94,124 97,129 98,129 99,124 98,123ZM299,122 291,127 289,132 289,141 295,148 300,150 306,150 311,148 317,141 317,133 315,128 309,123 306,122ZM227,122 224,124 225,130 226,130 226,128 229,125ZM110,114 105,118 104,121 107,123 107,126 108,127 106,133 108,134 109,136 111,135 113,137 113,135 111,133 111,124 109,119 110,117 109,115ZM225,110 226,113 228,114 229,111 228,110ZM511,115 497,115 495,112 496,111 498,112 498,111 500,110 499,109 490,113 485,122 481,127 477,136 464,157 462,162 457,169 454,175 455,176 475,176 481,171 490,154 502,135 505,128 510,121 512,116ZM97,109 96,110 95,109 93,111 95,114 98,112ZM516,100 515,102 514,101 514,103 516,107 517,105 520,109 519,110 517,109 520,111 519,112 519,118 520,119 522,118 522,110 520,106 516,103 517,101ZM373,97 371,98 372,99 370,100 367,104 364,113 366,113 367,110 368,112 368,109 371,105 369,104 370,101 372,99 371,98ZM226,95 225,98 226,100 227,100 229,97ZM94,96 95,99 98,99 99,98 99,96 99,98 98,99 97,98 97,95ZM496,95 493,96 492,94 486,99 485,102 489,102ZM301,84 304,84 309,86 312,89 314,94 313,100 309,104 305,106 298,105 292,99 292,97 290,95 290,92 298,85ZM299,81 295,83 291,87 289,91 289,100 292,105 296,108 299,109 309,108 313,105 316,101 317,98 317,91 313,85 309,82 306,81ZM225,81 223,84 222,83 223,85 226,84ZM99,81 97,82 97,85 98,86 101,84ZM114,78 111,83 110,82 110,79 107,81 109,85 108,86 108,89 105,94 105,96 106,97 106,102 106,100 108,99 110,104 110,92 112,88 112,82ZM170,77 162,77 160,79 154,81 148,81 144,85 144,88 148,90 147,87 149,85 156,84 165,80 168,80 171,83 170,107 172,105 173,106 174,117 172,118 174,120 172,123 170,122 170,130 171,131 174,131 176,133 176,136 174,138 165,138 164,139 161,138 154,139 153,138 147,138 146,137 146,134 152,130 152,98 151,97 152,96 149,97 146,94 149,97 149,126 143,132 143,139 146,142 176,142 180,139 180,132 179,130 174,126 174,120 173,119 174,117 174,81 173,79ZM475,62 471,62 469,63 459,75 459,79 460,81 467,87 469,84 462,78 463,77 462,75 463,74 464,75 471,67 470,63 471,62 474,62 475,63ZM108,55 111,59 109,66 103,71 100,67 101,61 105,56ZM104,52 100,56 99,59 97,61 93,61 91,63 90,67 88,70 88,76 86,79 86,82 85,83 85,92 83,95 83,119 84,120 83,125 84,126 84,131 86,135 87,145 91,152 91,157 93,162 97,167 101,169 108,169 114,166 118,160 118,151 115,145 114,145 113,148 110,142 110,147 112,147 114,150 115,158 111,163 109,163 107,165 101,165 96,160 94,155 96,151 91,146 90,143 91,135 88,132 87,129 87,125 89,122 86,117 86,110 88,108 86,102 86,96 89,93 88,84 89,83 89,80 92,78 92,70 93,67 96,64 100,68 101,70 101,74 102,74 105,70 110,69 112,71 113,76 114,75 115,76 116,74 116,69 113,66 114,63 114,56 111,52ZM213,51 211,52 209,55 210,67 207,70 207,73 211,82 211,89 213,92 213,102 215,107 214,108 214,121 213,122 213,130 209,139 209,144 206,147 206,150 205,151 205,160 206,163 209,166 215,169 222,169 226,167 230,162 232,158 233,150 235,148 237,142 237,135 240,126 239,120 241,115 241,110 240,109 241,108 240,107 240,94 239,93 239,84 235,76 234,78 233,78 232,76 231,78 232,78 235,82 235,90 234,93 237,95 237,102 235,106 235,108 237,110 237,117 233,122 236,125 236,129 234,134 232,136 233,139 233,145 228,151 229,155 227,160 221,166 216,166 212,163 208,158 209,150 212,147 214,147 213,145 213,138 217,133 216,131 216,123 219,121 217,116 217,110 220,107 217,103 217,96 218,94 215,89 215,83 216,81 212,77 211,74 211,71 213,69 217,69 213,64 213,56 214,55 217,55 221,59 223,63 223,68 225,65 228,64 231,68 231,71 232,70 235,74 235,70 233,64 230,61 227,61 220,54 220,53 217,51ZM476,45 479,45 481,50 484,52 486,51 488,53 488,51 482,46ZM416,44 409,44 403,47 398,51 395,55 392,62 390,64 390,66 386,72 387,73 385,74 381,82 382,82 383,79 386,78 387,76 386,74 388,72 387,71 388,68 391,66 394,61 395,62 397,61 397,59 401,53 407,48 409,48 408,47 411,44ZM514,41 514,42 524,49 529,55 529,56 525,59 526,60 523,62 521,61 517,66 518,68 516,70 518,68 519,69 529,58 529,55 516,41ZM512,41 511,41 507,46 504,48 504,49 498,55 498,57 502,54 503,55 505,53 504,51 505,48 507,51 505,48 509,43 510,44 509,43 511,41 512,42Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M103,150 103,154 105,156 105,153 104,150ZM110,136 110,141 112,143 111,146 112,144 113,147 114,144 112,143 114,142 113,141 113,138ZM364,114 364,120 366,125 368,127 371,134 376,141 381,151 383,152 383,155 389,163 396,177 403,184 407,186 429,186 430,187 441,187 442,186 445,186 446,187 455,187 456,186 459,186 460,187 463,187 464,186 466,187 476,187 484,184 490,177 493,170 498,163 498,161 500,160 502,155 504,153 504,151 507,147 505,148 504,146 506,143 508,142 508,140 510,138 513,137 519,125 521,123 521,120 522,119 520,120 519,119 510,136 507,139 507,141 504,145 503,149 501,150 486,177 482,181 478,183 408,183 406,182 397,172 394,165 389,158 382,144 378,139 376,134 370,125 367,119 367,111 367,113ZM172,106 170,108 170,121 172,122 173,120 171,118 173,117ZM107,100 106,105 104,107 106,110 106,116 108,115 109,116 110,115 109,114 110,113 109,112 110,110 109,109 109,103 108,100ZM511,94 510,95 513,102 514,100 515,101 516,99 515,98 514,99 513,98 514,96 513,94ZM144,89 145,93 152,97 151,96 152,95 152,92ZM469,85 468,88 484,101 486,98 479,93 473,87ZM385,78 386,79 383,80 383,82 380,83 380,85 378,88 376,89 377,90 375,91 375,93 373,96 374,97 371,99 372,100 370,104 372,104 373,101 375,99 378,92 380,90 386,79ZM112,74 110,78 111,79 111,82 112,79 114,77 114,76 113,77 112,76ZM232,71 232,75 233,77 234,77 235,75ZM516,67 492,93 494,96 518,70ZM395,61 392,66 389,68 388,71 389,72 387,74 386,73 388,76 387,77 395,64 394,62ZM503,56 502,55 499,58 497,57 496,59 492,59 491,57 489,56 489,53 488,54 485,52 488,59 490,61 490,64 486,69 483,69 476,63 475,64 474,63 471,63 471,65 472,66 473,64 484,74 486,74ZM454,46 455,45 458,45 459,46 458,47 455,47ZM409,47 410,48 478,48 479,49 479,46 476,46 475,45 472,45 471,46 468,45 411,45ZM513,41 512,43 511,42 508,45 503,53 505,51 506,52 506,50 507,49 508,50 512,45 514,45 525,55 525,57 522,60 523,61 522,62 525,60 524,59 526,58 528,55 524,50 514,43Z\"/><path fill=\"#a63441\" fill-rule=\"evenodd\" d=\"M226,153 220,156 217,161 217,164 222,163 226,159 227,156ZM97,153 96,155 98,160 101,163 106,164 105,159 100,154ZM212,149 210,153 210,159 212,161 214,161 216,157 216,152ZM110,149 108,151 107,155 108,156 108,159 111,161 113,158 113,152 112,150ZM231,139 226,141 224,143 224,145 222,148 223,150 226,150 230,146 232,140ZM93,139 92,140 92,144 93,146 97,150 100,150 101,148 98,142ZM216,137 215,138 215,146 218,149 220,145 220,140 218,137ZM107,136 103,139 103,145 105,149 106,149 108,146 108,137ZM233,125 230,126 228,128 226,134 227,137 230,136 233,133 234,131 234,126ZM89,125 90,128 89,131 90,131 91,133 96,137 97,136 97,133 95,128 92,125ZM219,123 218,124 218,131 221,135 223,132 223,126ZM104,123 100,126 100,135 102,135 106,129 106,126ZM234,110 232,111 229,115 229,118 228,119 229,122 231,122 235,117 235,111ZM220,110 219,111 219,117 220,119 224,122 225,121 225,114ZM103,110 101,111 98,115 98,121 100,122 104,117 104,111ZM89,110 88,111 88,117 92,122 94,122 95,121 94,115 93,113ZM219,97 218,99 220,105 223,108 225,108 225,101 221,97ZM103,97 98,101 98,107 99,108 104,104 104,98ZM233,95 229,100 229,107 230,108 234,105 235,102 235,96ZM90,95 88,97 88,102 89,105 93,108 94,107 94,100ZM468,98 469,99 468,101 470,100 476,103 480,109 483,107 485,107 489,110 494,103 493,101 489,104 485,104 472,93ZM217,84 216,85 218,91 221,94 224,95 223,87 221,85ZM106,84 103,84 100,87 99,90 99,94 100,95 105,91 107,86ZM92,81 90,84 90,89 94,94 96,90 96,86 95,83ZM231,80 228,83 227,86 227,90 229,94 233,90 233,82ZM213,71 214,77 217,80 221,81 222,79 220,74 216,71ZM110,71 106,72 103,75 101,80 102,81 105,81 109,77 109,75 111,73ZM227,66 224,70 224,77 226,80 227,80 230,76 230,71 229,68ZM96,66 94,69 93,75 94,78 97,80 99,77 99,69ZM216,57 215,58 216,66 219,69 221,69 221,63ZM108,57 103,61 102,64 102,68 104,69 108,64 109,61 109,58Z\"/><path fill=\"#e73d4e\" fill-rule=\"evenodd\" d=\"M489,111 485,108 482,109 480,108 479,109 477,107 476,104 470,101 468,102 467,101 468,99 463,109 454,123 452,128 450,130 448,135 439,149 437,154 433,159 431,164 425,173 425,175 423,176 428,176 429,175 433,175 434,176 436,175 439,176 452,176 461,158 464,155 465,151 472,141 484,118 487,115 487,113Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M105,97 104,96 105,98 105,104 100,109 97,107 97,103 96,103 95,101 95,107 92,109 89,106 91,108 87,110 87,114 87,111 89,109 93,112 91,110 94,109 96,107 100,110 98,114 98,113 103,109 105,111 105,116 105,110 101,108 105,104Z\"/><path fill=\"#1f9c4f\" fill-rule=\"evenodd\" d=\"M498,66 496,66 488,75 489,78 490,78 494,83 492,84 494,86 496,86 505,76 504,74 501,74 500,72 498,71 498,69 500,68Z\"/><path fill=\"#3dae58\" fill-rule=\"evenodd\" d=\"M472,68 465,76 465,78 485,96 488,96 498,85 496,87 494,87 491,84 493,83 491,80 488,78 488,76 485,77 475,68ZM463,55 434,55 432,60 429,64 429,66 425,70 423,75 417,84 415,90 410,96 407,103 403,108 400,115 398,117 398,119 388,135 385,137 390,146 394,151 394,153 400,163 402,160 403,156 414,139 422,123 427,117 428,113 436,101 440,92 447,82 457,63ZM514,47 508,52 497,65 501,68 499,69 499,71 500,71 501,73 504,73 506,75 501,81 523,56 523,55Z\"/><path fill=\"#255255\" fill-rule=\"evenodd\" d=\"M500,149 495,149 482,173 478,177 475,178 450,178 448,181 478,181 484,177ZM515,109 511,109 513,111 514,116 503,137 507,137 517,119 517,115 516,114 517,113ZM478,50 479,51 478,52 481,55 480,56 484,61 485,64 487,65 488,64 487,59 485,56ZM466,50 408,50 401,56 399,61 395,66 392,73 390,75 388,80 383,87 381,92 379,94 369,112 369,119 373,127 388,151 391,158 393,160 401,175 408,181 411,181 412,179 413,181 431,181 432,180 435,180 429,180 426,178 411,178 408,176 404,175 402,173 401,170 402,169 399,164 399,162 388,145 388,143 384,138 373,118 373,113 382,96 387,90 387,88 393,79 393,77 396,74 402,62 407,55 409,54 413,54 414,53 429,53 430,54 462,54 465,53Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M92,136 92,138 95,138 99,142 96,139 100,136 99,134 98,134 98,136 96,138ZM226,131 225,131 225,133 223,136 224,135 227,139 222,143 221,146 222,146 223,143 227,139 229,138 232,139 231,136 229,138 227,138 225,136ZM97,114 96,115 96,122 95,123 97,122ZM491,111 496,110 499,108 501,110 499,111 498,113 496,112 497,114 511,114 512,115 509,108 504,101 503,101 502,103 499,104 499,107 497,109 495,108ZM101,75 98,81 99,80 102,84 99,87 97,86 97,90 98,90 98,88 104,83 104,82 102,83 100,81Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M174,78 171,76 162,76 161,77 158,77 156,79 153,80 147,80 144,82 142,88 143,89 142,90 148,97 148,100 148,97 143,92 143,85 148,80 157,79 160,78 162,76 170,76 172,77 175,81 175,91 175,80ZM114,53 112,51 109,51 108,50 107,51 106,50 101,53 97,59 93,59 91,61 94,59 97,59 104,51 111,51 114,55ZM417,44 428,44 429,43 431,44 451,44 452,43 453,44 462,44 464,43 461,43 460,44 457,43 456,44 453,43 451,44 449,43 448,44 435,44 434,43 433,44 430,43 427,44 420,44 417,43Z\"/>",
	G: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M312,127 307,131 307,134 306,135 307,140 311,144 319,144 324,139 324,132 318,127ZM312,86 310,87 307,91 307,98 308,100 312,103 319,103 324,98 324,91 319,86ZM180,83 168,87 164,87 161,89 162,91 165,91 167,93 167,131 161,136 162,138 186,138 187,137 186,135 183,134 181,132 181,84Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M460,126 458,127 453,127 448,132 447,135 445,137 445,139 449,140 455,134 456,131ZM399,126 402,131 410,139 410,140 412,141 412,139 407,131 403,127Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M473,175 456,184 403,184 402,183 396,182 389,177 387,177 387,178 388,178 391,182 393,182 397,185 400,185 401,186 400,187 402,188 409,188 411,187 412,189 415,189 416,190 417,189 423,189 424,188 427,190 430,189 438,190 439,189 446,189 447,188 452,188 453,187 454,188 457,188 459,184 462,185 469,180 473,178ZM168,147 169,148 175,148 176,149 178,149 180,147 178,145 169,145ZM433,131 427,133 420,133 417,135 426,136 428,134 431,134ZM469,124 468,125 462,125 457,131 456,134 449,141 445,140 444,138 441,143 437,147 440,145 441,146 448,146 446,144 449,141 455,141 455,140 457,139 458,136 466,129ZM389,119 391,122 391,125 393,126 396,133 399,135 404,141 408,141 410,142 413,145 412,146 417,145 419,147 415,143 414,140 412,138 413,139 412,142 410,141 401,131 398,126 400,125 401,126Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M447,144 449,146 454,146 453,145 457,142 449,142ZM399,142 402,145 401,147 403,146 411,146 412,145 408,142ZM451,127 450,128 445,128 444,129 435,130 431,135 428,135 426,137 417,136 416,135 419,133 414,133 409,131 407,129 409,132 411,133 412,137 415,141 416,139 418,140 419,139 422,139 423,140 426,140 427,139 432,140 435,138 438,139 440,137 443,139 441,141 447,133 447,130Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M113,146 114,149 117,151 119,150 120,152 122,149 121,148 118,151 115,147ZM399,143 398,144 398,148 401,146ZM442,139 440,138 438,140 435,139 432,141 429,141 428,140 426,141 419,140 418,141 416,140 416,142 420,147 422,145 433,145 432,144 433,143 435,144 437,143 438,144 437,146Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M473,169 465,173 466,174 464,176 466,177 468,175 470,175 473,172ZM373,165 381,171 380,168 381,167 380,166 379,167 378,165 375,164ZM471,153 472,155 475,156 477,158 483,160 480,156 477,155 473,152ZM115,151 114,154 118,157 118,152ZM396,147 391,148 382,154 388,150 391,152 395,149ZM110,138 109,140 113,142 114,139 111,139ZM312,125 319,125 321,126 324,129 326,133 326,139 324,142 319,146 311,146 305,140 305,137 304,136 305,131ZM109,124 107,127 108,127 110,130 111,129 111,125ZM308,123 302,129 302,132 301,133 301,139 307,147 313,150 314,149 319,149 324,147 328,142 328,139 329,138 329,131 327,127 324,124 320,122 310,122ZM389,114 390,117 393,120 392,119 392,115ZM253,113 250,113 250,118 246,123 249,126 249,128 248,129 248,133 244,138 246,141 245,147 242,151 240,152 242,155 240,161 235,166 233,167 229,167 227,165 225,165 221,161 221,159 219,156 220,155 219,154 217,156 217,160 218,163 220,164 222,168 224,168 227,170 234,170 237,169 242,164 245,157 245,153 249,146 249,142 250,141 249,138 252,132ZM108,97 107,99 110,101 111,98ZM239,96 237,99 239,102 240,102 241,99ZM472,88 472,103 474,104 472,105 475,106 474,105 475,104 475,88ZM315,83 321,85 326,91 326,98 324,101 319,105 312,105 310,104 305,99 305,96 304,95 305,90 310,85ZM381,83 381,106 384,107 383,106 384,105 384,96 383,95 384,92 384,83ZM237,82 235,83 234,85 238,88 239,83ZM111,82 110,83 110,87 111,88 114,85 114,84ZM314,80 313,81 310,81 303,87 301,91 302,93 301,98 303,102 307,106 311,108 315,108 317,109 323,106 327,102 329,98 329,91 328,88 320,81ZM182,78 172,79 168,82 163,82 158,84 156,86 156,92 161,98 161,128 156,133 156,141 159,143 167,143 166,141 167,140 161,140 159,138 159,135 165,130 165,119 164,118 164,113 165,112 165,94 163,92 161,92 159,89 161,86 169,85 179,81 181,81 184,85 183,87 184,89 183,90 183,131 189,135 189,138 187,140 181,140 181,143 190,143 192,141 192,133 191,131 188,130 186,128 186,96 187,95 187,84 185,82 185,80ZM121,56 123,58 123,64 121,68 118,71 123,71 125,74 122,81 120,83 121,85 121,90 118,94 119,105 116,109 119,111 119,117 117,120 117,122 120,126 120,132 119,135 122,138 123,141 123,146 122,148 124,148 126,150 128,157 127,158 127,161 123,165 122,164 119,167 115,167 109,162 108,158 106,156 108,152 104,148 103,142 102,141 104,139 106,139 106,138 100,133 100,126 102,123 99,119 98,112 101,109 99,105 99,96 102,94 101,91 101,84 102,82 105,80 104,78 104,72 105,69 108,65 113,69 113,64 115,60 119,56ZM228,52 226,52 222,56 222,68 220,71 220,76 223,82 223,87 224,88 224,91 226,94 226,98 225,100 227,105 227,109 226,110 226,122 225,123 225,132 223,135 223,140 222,141 223,142 225,142 226,138 229,135 228,126 229,124 232,122 230,120 230,111 232,108 229,102 229,98 231,95 229,93 227,88 228,82 225,79 225,77 223,74 225,71 229,71 225,63 225,58 227,56 229,56 235,63 235,70 239,66 243,69 244,72 244,78 243,80 245,80 247,82 247,86 248,87 247,92 249,94 250,87 251,86 248,77 248,72 246,66 243,63 238,61 232,54ZM121,52 117,53 109,62 105,62 101,69 101,76 97,84 98,93 96,95 95,98 95,104 96,105 96,108 95,109 95,119 97,122 96,124 96,131 97,132 97,135 99,138 100,148 103,153 103,157 105,162 111,169 114,170 122,170 124,168 126,168 129,165 131,160 131,154 129,148 127,146 126,139 123,132 124,131 123,130 122,109 121,108 123,102 122,100 122,94 124,91 124,84 128,77 129,72 126,68 126,63 127,62 126,61 127,60 125,55ZM419,43 417,42 414,43 412,42 411,43 408,43 403,45 399,45 398,46 390,46 388,48 386,48 385,50 383,51 381,57 383,58 385,56 385,54 389,50 414,46 415,45 418,45ZM427,42 429,43 431,42 432,40 436,40 439,38 441,40 442,39 443,41 446,43 445,44 461,53 463,52 472,57 475,61 475,72 475,61 474,59 463,50 461,50 458,47 452,45 449,43 448,41 441,38 433,38 430,39 430,40Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M381,166 383,172 391,176 394,179 396,179 398,181 401,182 456,182 464,178 463,176 465,174 454,179 404,179 398,176 396,176 393,173 386,170ZM390,152 388,151 382,155 381,154 378,158 375,158 373,160 373,164 375,163 377,164 376,161 381,157 383,157ZM437,144 433,146 424,146 421,147 426,155 429,156ZM167,141 168,143 180,143 180,140 168,140ZM475,107 472,106 472,112 470,116 465,120 455,121 454,122 450,122 441,125 436,125 435,126 431,126 425,128 420,128 419,129 412,127 393,115 393,119 412,131 415,132 423,132 424,131 428,131 429,130 433,130 434,129 443,128 444,127 449,127 453,125 457,125 458,124 462,124 463,123 469,122 475,115 475,109 473,108ZM463,53 462,54 466,56 471,61 471,65 472,66 472,87 475,87 472,86 475,85 475,80 474,79 475,78 475,75 474,74 475,73 474,72 474,61 472,58ZM432,41 432,42 442,42 445,43 443,42 442,40 441,41 439,39 436,41Z\"/><path fill=\"#a63441\" fill-rule=\"evenodd\" d=\"M239,155 234,156 231,159 229,164 230,165 235,164 239,159ZM109,155 109,158 111,162 115,165 118,165 119,163 117,159 114,157 113,155ZM226,150 224,150 222,155 222,159 225,163 228,159 228,152ZM122,150 120,153 120,158 121,161 124,162 126,158 126,155 125,152ZM243,140 240,141 237,144 235,149 236,152 239,151 243,147 243,144 244,143ZM105,140 104,143 106,148 109,151 113,152 113,148 111,144 109,143 108,141ZM229,137 227,140 227,146 228,148 231,150 233,145 233,141 231,138ZM119,137 117,138 115,142 116,148 118,150 121,147 121,140ZM246,126 243,127 241,129 239,134 239,137 240,138 243,137 246,133 246,129 247,128ZM102,126 101,128 103,132 105,133 104,135 106,137 109,138 109,134 106,134 104,132 104,131 107,130 107,129 104,126ZM230,125 230,131 231,134 234,137 236,134 236,128 233,125ZM116,124 112,129 112,134 113,136 115,136 118,131 118,125ZM247,111 244,112 241,118 241,123 242,124 244,123 248,118 248,112ZM233,111 231,116 232,117 232,120 236,123 238,121 238,116 237,114ZM116,111 113,112 111,115 110,119 112,123 116,120 117,117 117,112ZM101,111 100,112 100,118 101,120 106,124 107,123 107,117 106,115ZM232,98 231,99 231,103 233,107 237,110 238,109 238,103 235,99ZM116,98 111,102 110,105 110,109 111,110 113,109 117,104 117,99ZM246,96 243,99 241,104 242,106 241,109 242,110 244,109 247,105 247,97ZM102,96 101,97 101,106 106,110 107,109 107,102 105,98ZM230,85 229,86 229,89 231,93 233,95 236,96 237,95 236,89 233,86ZM118,85 115,86 113,88 111,93 112,96 115,95 118,92 119,89 119,86ZM244,82 240,85 240,95 242,95 246,90 246,86ZM103,82 102,89 103,92 107,95 108,94 108,85 105,82ZM226,72 225,75 227,79 230,82 233,83 234,82 234,79 232,75 230,73ZM122,72 118,73 116,75 114,80 115,82 118,82 121,79 123,75ZM108,68 106,72 106,78 108,81 110,81 112,77 112,72 111,70ZM239,67 237,70 236,74 237,75 237,79 240,81 242,78 242,71 241,68ZM228,58 227,59 227,64 228,66 233,70 234,67 233,66 233,63 231,60ZM119,58 115,63 115,70 116,71 119,68 121,64 121,59Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M106,127 108,130 105,131 104,133 102,132 101,129 103,135 105,132 106,133 109,133 108,129Z\"/><path fill=\"#007d43\" fill-rule=\"evenodd\" d=\"M427,73 428,72 431,72 433,76 432,77 428,77 427,76ZM455,63 453,64 452,66 450,64 444,66 441,66 440,67 443,69 440,71 436,71 435,70 437,69 438,67 436,68 425,69 422,70 420,72 421,74 422,74 423,72 426,73 426,79 422,82 422,109 421,110 421,114 422,115 422,125 429,125 430,124 439,123 440,122 443,122 445,120 446,121 449,121 450,120 460,119 463,118 461,117 464,113 466,116 468,115 466,115 465,112 469,110 469,81 466,81 460,83 459,80 456,77 458,74 454,70 451,72 447,72 445,70 446,68 450,68 450,67 453,66 454,64 455,64 456,66Z\"/><path fill=\"#1f9c4f\" fill-rule=\"evenodd\" d=\"M410,149 413,156 418,161 428,166 430,166 436,162 440,161 445,155 445,153 444,153 444,154 437,160 429,163 428,162 424,163 418,159ZM428,73 428,76 432,76 431,73ZM468,61 464,61 463,62 456,63 457,66 456,67 455,65 454,65 454,66 451,67 450,69 446,69 444,68 445,68 447,71 451,71 454,69 459,74 457,77 460,80 460,82 466,80 469,80 470,81 470,110 468,112 466,112 465,115 464,114 462,117 464,118 468,116 466,117 465,115 466,114 469,114 470,112 470,64ZM387,55 386,57 386,105 388,108 388,110 415,126 424,126 421,125 421,115 420,114 420,110 421,109 421,82 425,79 425,73 423,73 423,74 421,75 419,72 420,71 417,74 412,68 394,58 391,55Z\"/><path fill=\"#3dae58\" fill-rule=\"evenodd\" d=\"M378,162 381,165 384,166 386,168 388,168 393,172 396,173 398,175 400,175 402,177 454,177 468,170 479,163 477,160 455,147 447,147 446,155 441,161 430,167 423,165 421,163 418,162 412,156 409,150 409,147 403,147 400,148ZM469,61 465,57 463,57 458,53 453,51 451,49 449,49 444,45 441,44 432,44 431,45 418,46 417,47 409,48 404,50 399,50 398,51 390,52 388,54 391,54 394,57 412,67 417,73 420,70 425,68 440,66 447,63 459,62 464,60 468,60Z\"/><path fill=\"#255255\" fill-rule=\"evenodd\" d=\"M410,148 411,150 414,152 415,155 424,162 426,161 429,162 437,159 443,154 446,150 445,147 441,147 440,146 435,150 433,154 428,159 417,146 415,147 411,147Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M481,156 484,160 483,161 480,160 481,163 478,166 473,168 474,169 474,172 472,174 480,169 485,164 485,160ZM233,151 231,152 229,151 230,152 230,158 232,156 233,153 235,154ZM455,145 458,147 460,147 461,149 463,149 466,152 471,154 470,153 472,151 465,146 463,146 461,144 457,144ZM226,140 225,143 222,142 221,146 218,149 218,153 217,155 219,153 221,155 220,156 221,158 222,150 224,148 226,148ZM236,138 237,139 234,141 233,140ZM231,118 231,120 233,122 232,123 235,124 237,127 237,130 238,131 237,136 235,138 233,138 234,141 234,147 235,144 239,140 243,139 246,135 242,139 239,139 237,137 238,135 238,131 240,129 240,126 241,125 242,127 243,125 238,124 237,127 231,120ZM241,110 236,111 239,115 239,118 240,118 240,116 243,112 243,111ZM381,107 383,113 390,118 388,114 389,113 386,110 384,106ZM107,100 108,101 108,109 106,113 105,111 102,109 99,112 99,115 99,112 101,110 103,110 106,113 107,112 108,113 107,115 108,118 109,118 109,116 112,111 109,109 109,102ZM112,99 111,100 112,98 110,96 110,92 109,92 109,95 107,97 103,94 100,96 103,95 106,98 108,96 110,96ZM237,89 238,96 236,99 238,101 236,98 239,95 241,98 245,95 247,95 249,97 249,105 246,109 250,112 253,112 254,115 254,111 253,110 253,96 251,93 251,87 250,94 249,95 246,92 242,97 239,95 239,92 238,89ZM113,72 114,71 116,74 114,75ZM120,68 116,72 114,70 112,70 113,71 112,82 114,76 118,72 117,71ZM381,58 381,82 384,82 384,58 383,59ZM429,40 425,39 424,40 418,41 418,42 420,43 419,45 421,43 422,44 425,44 427,43 426,42Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M305,83 302,87 307,82 313,79 320,80 323,83 327,85 330,91 330,98 329,101 323,107 325,106 328,103 330,98 330,90 326,83 321,80 317,80 316,79 313,79ZM446,39 458,46 461,49 463,49 470,54 475,60 473,56 470,53 464,49 462,49 460,47 457,46 453,42 451,42Z\"/>",
	H: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M313,127 308,130 306,137 309,143 313,145 317,145 322,142 324,138 324,133 321,129 317,127ZM313,86 308,89 306,93 306,96 307,99 311,103 317,104 323,99 324,97 324,93 323,90 320,87 318,86ZM180,84 176,84 161,89 162,91 164,91 166,93 166,129 167,130 166,133 164,135 161,136 162,138 186,138 187,137 186,135 183,135 181,133 181,85Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M460,127 454,127 451,128 444,139 445,140 451,139 454,135 455,136 454,135 454,132 456,130 459,130ZM396,125 399,127 399,130 404,135 405,138 407,140 413,141 405,129 399,125Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M385,180 387,180 390,184 393,186 397,186 398,188 404,187 408,189 422,189 423,190 425,189 433,189 435,190 439,188 442,188 444,190 447,190 452,188 458,188 462,184 466,185 467,183 472,180 473,176 471,176 469,178 467,178 463,181 456,184 401,184 394,181 387,176 385,177ZM171,146 171,148 175,148 177,147 177,146ZM389,120 391,126 394,129 394,131 396,132 401,138 404,140 404,141 408,141 412,145 411,147 408,147 407,149 410,149 411,150 410,151 416,158 415,159 416,161 424,167 429,167 438,159 439,160 442,159 443,157 445,156 444,155 445,152 449,148 448,147 445,147 444,144 447,141 455,141 463,131 466,130 466,127 469,125 459,126 461,127 459,131 456,131 455,132 455,135 454,136 452,135 453,135 454,137 451,140 448,141 445,141 443,139 450,128 431,132 431,133 434,135 437,133 445,132 446,135 432,155 427,159 416,145 414,141 413,142 407,141 404,138 403,135 398,130 398,127 395,125 397,124Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M378,162 379,164 390,170 392,172 397,174 399,176 402,177 424,177 425,178 434,178 435,177 438,178 443,178 444,177 456,177 465,171 467,171 469,169 477,165 479,163 479,162 474,158 470,157 467,154 462,152 455,147 451,147 450,146 451,143 453,142 458,142 447,142 445,144 445,146 448,146 450,148 446,152 445,155 446,156 444,157 442,160 440,161 438,160 429,168 424,168 419,165 415,161 414,159 415,158 409,151 410,150 407,150 406,149 408,146 411,146 408,142 400,142 402,142 405,145 402,148 398,149 392,154 383,158ZM428,132 429,135 427,137 426,136 426,133ZM406,129 418,146 416,143 418,141 422,142 424,140 426,140 427,142 434,139 436,140 441,138 442,139 441,141 445,135 445,133 443,133 442,134 437,134 434,136 432,135 430,132 427,132 426,133 414,133 413,132 410,132ZM469,61 466,58 452,51 441,44 431,44 430,45 425,45 424,46 419,46 414,48 410,48 405,50 400,50 395,52 391,52 386,56 386,59 386,56 388,54 394,56 401,61 405,62 406,65 410,65 416,70 416,72 425,68 435,67 438,65 446,65 450,63 461,62 466,60Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M451,144 451,146 455,146 464,152 457,147 457,145 459,144 459,143 453,143ZM404,145 402,143 397,143 396,145 397,146 396,147 397,149 392,153 386,156 392,153 398,148 402,147ZM441,139 436,141 434,140 427,143 426,141 424,141 422,143 420,142 417,143 421,149 419,147 421,144 424,145 425,144 433,145 436,143 438,145 437,146ZM109,119 108,119 108,123 106,125 104,125 101,122 104,126 107,125 109,123 111,124 109,122Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M233,152 230,153 230,157 234,154ZM386,151 373,159 385,153ZM116,151 113,154 118,157 118,152ZM112,138 110,139 109,141 113,144 114,139ZM237,137 233,139 234,140 234,146 235,146 235,144 238,141ZM313,125 320,126 326,133 325,141 321,145 316,147 310,146 306,142 304,137 305,131 309,127ZM240,125 236,126 238,130 241,127ZM109,124 107,127 109,130 111,129 111,125ZM312,122 309,123 303,128 301,133 301,139 303,144 309,149 312,150 319,150 322,149 327,144 330,135 329,134 329,131 322,123ZM161,112 161,128 155,133 155,138 156,141 160,144 167,144 166,143 167,140 164,140 163,141 159,138 159,135 161,133 164,132 164,112ZM239,111 237,113 239,115 239,117 240,117 240,115 242,113ZM107,111 106,113 107,115 109,116 110,112ZM228,98 229,99 229,102 228,103 227,102 227,99ZM238,97 236,99 239,102 242,98ZM110,97 107,97 108,103 111,99ZM313,84 318,84 322,86 326,93 326,98 321,104 316,106 309,104 306,101 304,97 305,90 310,85ZM236,83 235,86 237,88 237,90 238,90 238,83ZM112,83 109,84 110,89 111,89 114,85ZM311,81 306,84 301,90 301,98 304,104 309,107 310,109 313,108 318,109 321,108 328,102 329,100 329,91 327,87 325,85 323,85 322,83 320,83 319,81ZM160,83 156,86 156,93 157,95 161,98 161,108 164,108 164,94 161,93 159,91 159,88 161,86 170,85 176,82 181,82 183,84 183,132 184,133 187,133 189,135 189,138 187,140 181,140 182,143 179,144 188,144 192,141 192,133 186,129 186,83 184,80 180,78 172,80 169,82ZM227,56 233,60 235,65 235,69 239,66 243,69 243,72 244,73 243,80 246,82 248,87 246,95 249,97 249,105 247,110 250,111 250,117 249,120 246,123 249,128 248,129 248,133 244,138 246,141 245,146 240,152 241,155 240,161 234,167 229,167 227,165 224,165 220,159 220,156 222,150 224,148 226,148 225,146 225,141 226,140 226,137 229,135 228,127 231,123 229,115 230,112 232,110 229,104 229,99 231,96 227,90 228,83 225,80 223,75 223,73 225,71 229,71 231,72 229,71 225,64 225,58ZM120,56 123,59 123,63 119,71 123,71 125,73 125,75 123,79 119,83 121,86 121,88 117,96 119,98 119,104 116,108 116,110 118,111 118,115 119,117 116,122 119,124 120,127 119,135 122,138 122,142 123,143 122,148 123,148 127,153 127,161 123,165 121,165 119,167 114,167 112,166 108,161 106,156 108,153 104,149 102,143 102,141 104,138 101,135 99,130 100,128 99,126 102,124 99,121 98,112 101,110 99,106 99,96 102,95 101,92 101,84 102,82 105,80 104,79 104,72 105,69 109,66 112,69 113,71 113,76 114,76 116,73 113,71 113,64 115,60ZM225,53 222,55 222,68 220,71 220,77 222,80 224,91 226,95 226,106 227,107 226,110 226,123 225,124 225,133 223,135 222,138 222,144 219,148 217,154 217,162 222,168 229,171 233,171 239,168 243,163 244,157 245,156 245,152 247,150 249,145 249,138 250,137 250,134 252,132 252,125 251,123 253,120 252,118 253,117 253,110 252,109 253,96 251,93 250,81 247,77 246,66 243,63 239,62 232,54 230,53ZM122,53 119,53 115,55 109,62 103,64 100,73 100,79 98,81 97,84 97,94 95,97 95,103 96,104 95,120 96,121 96,132 99,138 99,146 101,149 101,151 103,153 103,158 105,163 110,169 114,171 120,171 126,168 129,165 131,161 131,155 129,152 129,149 126,144 126,140 123,133 123,124 122,123 122,111 121,110 121,107 122,106 122,94 124,89 124,85 128,76 128,71 126,68 126,57 125,55ZM401,45 391,46 387,48 382,52 381,57 388,49 390,49 392,47 393,48ZM444,40 449,44 453,45 460,51 470,56 475,63 473,58 466,52 460,50 457,47 454,46 452,44 450,44ZM442,39 432,39 431,40 425,40 424,41 419,41 418,42 410,43 417,43 426,40Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M484,164 484,161 481,157 476,155 469,150 468,151 467,149 461,145 458,145 458,147 468,154 478,159 481,163 478,166 468,171 458,178 455,178 454,179 402,179 394,175 389,171 379,166 376,162 383,156 385,156 387,154 396,149 395,148 391,148 391,149 389,151 388,150 385,154 373,160 374,166 379,170 382,171 385,174 390,176 399,182 404,182 405,183 452,183 453,182 457,182 472,174 475,171 480,169ZM436,144 433,146 428,146 422,148 422,150 427,157 429,157 433,150 436,147ZM167,141 167,143 181,143 180,140 168,140ZM443,43 448,47 465,56 471,63 471,114 470,116 465,120 461,120 456,122 452,122 451,123 447,123 442,125 437,125 436,126 427,127 421,129 414,128 403,122 398,118 388,113 384,107 384,57 389,51 392,51 393,50 397,50 406,47 412,47 413,46 427,44 432,42ZM443,40 426,41 417,44 405,44 399,47 393,49 392,48 390,50 388,50 381,58 381,79 382,80 382,83 381,84 381,108 384,113 388,117 409,129 411,131 414,131 415,132 424,132 425,131 429,131 435,129 440,129 441,128 450,127 454,125 463,124 469,122 471,119 473,118 472,117 474,116 474,113 475,112 475,64 474,62 472,61 470,57 460,52 453,46 449,45Z\"/><path fill=\"#a63441\" fill-rule=\"evenodd\" d=\"M238,155 233,157 231,159 231,161 229,163 230,166 234,165 238,161 239,158ZM109,155 108,156 110,161 114,165 117,166 119,164 117,160 113,156ZM225,150 222,156 222,159 225,163 227,161 228,158 228,154ZM122,150 120,153 120,160 121,162 123,163 125,161 126,156 124,151ZM243,141 241,141 238,143 234,151 235,152 241,150 243,147 243,144 244,143ZM105,141 104,142 104,145 106,149 108,151 112,152 113,151 112,147 107,141ZM120,138 118,138 115,142 115,146 117,150 121,147 121,140ZM229,137 227,140 227,146 230,150 232,148 232,140ZM246,126 243,127 241,129 239,133 239,138 242,138 245,135 246,133 246,129 247,128ZM102,126 101,127 103,134 108,138 109,137 109,134 106,134 104,132 105,131 108,132 107,129ZM231,125 230,126 230,132 231,135 234,137 236,134 236,129 234,126ZM117,125 115,125 112,129 112,135 114,137 118,131 118,127ZM233,112 231,115 232,120 236,123 237,122 237,116ZM116,112 114,112 111,115 110,120 112,123 116,120 117,117ZM247,111 242,115 241,118 241,123 243,124 248,118 248,112ZM101,111 100,112 101,121 103,123 106,124 107,123 107,118 105,114ZM232,99 231,100 231,105 237,110 238,109 237,102 234,99ZM116,99 114,99 110,104 110,109 111,110 117,105 117,100ZM246,97 242,100 241,103 241,109 244,109 247,105 247,98ZM102,97 101,98 101,106 103,109 106,110 107,109 107,103 105,99ZM230,85 229,86 229,90 230,92 234,96 236,96 237,95 235,89ZM118,85 113,88 111,93 112,96 115,95 118,92 119,89 119,86ZM243,82 240,86 240,95 243,95 245,93 246,90 245,84ZM104,82 102,86 102,90 103,93 105,95 107,95 108,94 108,86 107,84ZM226,73 225,74 226,78 231,83 233,83 234,80 232,75 229,73ZM122,73 119,73 115,77 114,79 114,82 115,83 117,83 121,79 123,75ZM240,68 239,68 236,72 236,77 237,80 239,82 242,79 242,72ZM108,68 106,72 106,79 109,82 111,80 112,73 111,70ZM121,59 119,59 115,63 114,69 116,71 120,67ZM228,58 227,59 227,64 228,67 232,71 233,70 233,64Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M235,113 238,116 238,122 236,124 240,123 241,125 242,125 240,123 240,119 239,120 238,119 238,116Z\"/><path fill=\"#19a0b8\" fill-rule=\"evenodd\" d=\"M387,56 387,59 386,60 386,107 391,113 396,115 411,125 416,127 423,127 424,126 433,125 438,123 449,122 454,120 463,119 469,115 470,112 470,66 469,65 469,62 466,61 461,63 454,63 446,66 438,66 435,68 425,69 416,73 415,70 410,66 406,66 405,63 401,62 392,56 389,55Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M239,153 234,153 235,154 231,158 229,157 229,160 235,154 239,154 240,155ZM420,147 421,148 424,146 427,146 428,145 425,145 424,146 421,145ZM247,108 244,111 242,111 240,109 240,102 239,103 239,110 238,111 235,111 232,108 235,112 237,112 239,110 243,112 246,110ZM114,77 112,78 112,81 111,82 115,85 112,88 115,85 118,84 118,83 117,84 114,84 112,82Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M391,147 379,153 372,159 371,164 376,169 371,163 372,159 377,155ZM460,144 462,144 464,146 482,156 486,161 486,164 483,168 486,164 486,160 483,156 479,155 473,150 466,147 462,144ZM312,121 322,122 326,125 329,130 327,126 324,123 319,121 312,121 304,124 300,132 300,139 303,146 309,150 317,151 312,151 306,148 302,144 300,139 300,133 302,128 306,124ZM127,56 124,53 119,52 112,56 108,61 104,62 102,64 102,66 100,69 101,69 102,64 104,62 109,61 115,54 119,52 122,52 126,55 127,57 127,68 127,63 128,62 127,60ZM443,39 445,39 450,43 452,43 460,49 466,51 473,57 471,54 469,54 465,50 463,50 453,43 451,43 447,40Z\"/>",
	I: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M317,127 313,127 309,129 306,133 306,139 307,141 313,145 319,144 323,140 324,137 322,130ZM312,86 307,90 306,92 306,98 309,102 316,104 319,103 323,99 324,94 323,91 319,87 317,86ZM180,83 178,83 170,87 162,88 161,89 162,91 164,91 166,93 166,132 160,137 161,138 186,138 187,137 186,135 182,135 180,133 180,100 181,99 181,84Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M455,128 453,128 450,130 445,138 447,137 449,134 454,132 454,129ZM397,125 398,129 401,131 402,133 401,134 402,136 405,138 405,140 407,141 412,140 407,132 402,127Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M385,176 390,182 395,186 400,187 403,189 406,189 407,188 411,188 412,189 413,188 414,189 419,188 422,190 433,190 436,188 453,189 456,187 461,186 465,181 466,182 468,180 467,179 469,178 456,184 401,184ZM455,127 456,128 455,129 455,132 449,135 448,137 446,138 445,136 447,134 447,132 453,127ZM468,125 448,128 445,130 439,130 434,132 429,132 428,134 430,135 432,133 436,133 437,134 438,133 439,134 441,132 443,132 444,133 442,134 445,136 443,140 440,143 440,145 435,150 433,155 439,151 440,147 442,146 443,144 445,145 446,143 450,140 455,139ZM388,119 387,121 389,122 395,130 397,131 397,134 403,138 402,141 406,142 409,145 411,149 416,150 421,153 413,140 411,138 413,140 410,142 405,141 404,140 405,137 404,138 401,136 400,131 399,131 396,127 397,124 392,121 390,121Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M401,141 401,142 406,146 407,150 416,159 418,164 420,164 422,166 425,166 426,167 432,163 433,164 441,159 443,155 450,148 450,146 455,142 454,141 450,141 447,143 445,146 443,145 443,146 441,147 441,149 439,152 434,156 432,155 433,153 428,159 418,147 422,152 421,154 416,151 411,150 406,143ZM406,129 417,145 416,144 417,141 422,142 425,140 434,140 441,137 443,138 444,136 441,134 443,133 441,133 439,135 438,134 437,135 436,134 432,134 430,136 427,134 428,132 426,133 413,133 410,131 408,131Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M397,144 399,144 402,147 403,149 401,150 403,152 403,154 409,160 410,159 414,164 414,167 420,169 423,172 426,172 427,173 430,173 431,171 433,171 431,170 432,169 437,168 437,167 441,165 442,163 443,164 445,162 444,160 449,156 449,153 453,151 454,149 453,146 456,143 458,144 457,143 454,143 451,146 451,148 444,155 443,158 441,160 433,165 432,164 427,168 418,165 415,159 406,150 405,146 402,143 398,143ZM442,138 434,141 425,141 422,143 417,142 417,144 420,148 419,145 421,143 423,144 427,144 430,142 436,142 439,140 440,141 439,143Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M393,164 395,163 398,166 396,167 394,166ZM399,161 398,162 396,161 395,162 392,162 391,160 391,161 388,163 389,164 384,168 383,166 384,165 383,166 384,168 382,169 381,171 391,177 392,175 394,175 395,172 398,172 399,170 402,172 400,171 401,169 399,167 401,165 400,166 398,163 400,162ZM229,152 230,157 231,157 234,154 232,152ZM115,152 114,155 118,158 118,153ZM484,160 477,154 475,154 469,149 462,146 462,149 463,150 460,156 457,156 458,158 455,161 453,161 451,167 452,168 450,169 452,172 451,173 452,174 451,175 451,183 460,181 465,177 472,174 483,167 485,162ZM237,138 235,138 233,140 234,141 234,145 235,145 238,141ZM111,138 109,141 113,144 114,139ZM155,134 155,139 157,143 164,144 166,142 165,140 162,140 158,142 156,140 156,136ZM312,125 320,126 325,131 326,134 326,137 324,142 321,145 316,147 313,147 309,145 305,141 304,138 304,133 305,131ZM240,125 236,126 237,128 237,133 241,127ZM109,124 107,127 109,131 110,131 111,126 110,126ZM311,122 308,124 306,124 302,128 301,131 301,141 304,146 308,149 318,150 321,149 327,144 329,139 329,132 325,126 321,123 318,122ZM238,111 237,113 239,117 240,117 241,112ZM107,111 106,113 107,115 109,116 110,112ZM237,97 236,99 239,102 241,98ZM107,97 106,98 108,101 108,103 109,103 109,101 111,98 110,97ZM312,84 318,84 320,85 325,90 325,93 326,94 324,101 321,104 316,106 309,104 306,101 304,97 305,90ZM238,83 236,83 235,86 234,85 236,87 237,90 239,84ZM112,82 109,84 110,88 113,86ZM309,82 303,86 301,90 301,99 302,102 307,107 311,109 318,109 321,108 328,101 328,98 329,97 329,93 328,92 329,91 327,87 323,83 319,81ZM160,83 156,86 156,94 161,98 161,124 164,124 164,94 161,93 159,91 159,88 161,86 170,85 176,82 181,82 183,84 183,132 184,132 186,129 187,132 188,131 191,134 191,138 189,141 183,144 188,144 190,143 192,140 192,133 186,128 186,82 184,80 178,78 169,82 163,82ZM226,57 229,57 234,62 235,68 238,66 240,66 243,69 243,74 244,75 243,80 244,80 247,84 246,95 249,97 249,104 248,107 246,109 249,112 249,119 245,124 248,126 248,132 244,138 245,140 244,148 242,151 240,152 241,158 239,162 234,167 229,167 226,165 224,165 221,162 220,159 221,152 222,150 225,148 225,140 226,137 229,135 228,132 228,125 231,123 229,118 229,114 232,110 229,105 229,99 231,96 227,90 227,85 228,83 225,80 223,75 223,73 225,71 228,71 225,65 225,58ZM120,56 123,59 123,62 121,68 118,71 123,71 125,74 120,82 120,85 121,86 120,91 116,96 116,97 119,99 119,104 115,110 118,112 117,123 119,124 119,127 120,128 119,134 118,135 120,136 122,139 122,148 126,151 127,154 127,161 123,165 121,164 119,167 114,167 109,163 106,156 108,153 104,149 102,145 102,141 104,138 100,134 100,131 99,130 99,126 101,123 98,119 98,112 101,109 99,107 98,100 99,99 99,96 101,95 100,86 101,85 101,82 104,80 104,71 107,66 109,66 112,69 113,63 115,60ZM411,54 412,53 415,53 416,54 415,55 412,55ZM225,53 223,54 221,59 222,62 222,68 219,74 223,83 223,89 225,94 225,103 227,109 226,110 226,122 225,123 225,128 224,129 225,130 224,131 224,135 222,139 221,145 217,153 217,161 218,164 222,168 229,171 232,171 237,169 242,164 244,160 245,152 248,149 249,137 252,131 252,125 251,122 253,118 253,112 252,111 252,95 250,91 251,90 251,86 250,85 250,82 248,80 247,77 247,71 245,66 242,63 240,63 232,54ZM122,53 118,53 116,54 110,61 104,63 101,68 100,78 98,80 98,83 97,84 97,93 95,97 95,106 96,108 94,113 95,121 97,122 96,123 96,132 98,136 99,147 103,153 103,159 106,165 110,169 115,171 118,171 126,168 130,163 130,152 126,145 126,141 123,133 123,126 122,125 122,111 121,110 121,107 122,106 122,94 124,89 124,84 128,76 128,71 125,67 126,65 126,58 125,55ZM443,39 440,39 439,38 436,39 429,39 428,40 424,40 423,41 419,41 413,43 408,43 404,45 388,47 382,52 380,57 380,106 381,107 381,110 387,117 392,119 409,130 415,132 415,130 417,128 421,128 416,127 412,123 409,118 409,115 405,107 397,107 396,104 393,103 393,97 391,92 389,73 387,70 389,68 391,69 394,65 396,65 399,69 407,73 410,72 414,72 415,73 418,70 422,68 432,68 440,64 448,65 451,63 452,64 455,62 458,62 459,61 468,61 470,63 471,66 471,90 472,91 470,95 470,99 471,100 471,113 469,117 465,120 460,120 455,122 450,122 445,124 434,125 431,127 428,127 428,128 426,129 427,129 428,131 429,130 445,128 454,125 467,123 471,120 475,111 474,108 475,105 475,82 474,81 475,78 474,77 475,74 475,71 474,70 475,68 474,67 474,61 470,55 461,49 454,46 452,44 450,44Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M448,160 449,159 451,162 449,163ZM455,155 456,157 453,160 451,160 450,157ZM462,150 461,149 461,145 457,145 456,146 456,149 451,153 450,158 446,160 446,162 448,165 445,169 438,175 435,175 430,177 419,176 418,175 417,169 413,172 412,171 412,169 414,168 412,166 413,164 406,159 404,160 401,157 400,155 402,154 400,151 401,149 400,147 398,146 391,147 387,151 384,152 385,153 384,155 382,153 375,157 372,161 372,163 374,164 373,165 374,167 380,171 382,168 388,164 387,163 388,162 390,163 389,162 391,159 392,161 395,161 396,160 398,161 399,160 401,162 399,163 401,166 399,168 393,163 394,165 397,166 400,170 398,173 395,173 395,175 392,176 392,178 395,179 397,177 398,179 400,180 399,181 400,182 403,182 404,181 405,183 450,183 450,175 451,174 450,173 451,172 449,169 451,168 450,167 451,166 451,163 453,160 455,160 457,158 456,157 457,155 460,155ZM439,142 436,143 430,143 424,146 421,144 420,147 426,156 428,157 437,146ZM190,132 187,133 186,130 184,133 187,133 189,135 188,138 186,140 166,140 167,142 165,144 170,144 171,143 182,144 188,141 190,138 190,134 189,133ZM427,127 421,129 417,129 416,132 427,131 427,130 425,129 427,128ZM164,125 161,125 161,129 156,133 157,140 158,141 161,140 159,138 159,135 161,133 164,132Z\"/><path fill=\"#a63441\" fill-rule=\"evenodd\" d=\"M238,155 234,156 231,159 229,164 230,166 234,165 237,162 239,158ZM109,155 108,156 109,157 109,160 114,165 118,165 119,164 117,160 115,159 113,156ZM224,150 222,156 222,159 225,163 228,158 228,154 227,152ZM122,150 120,153 119,157 120,160 123,163 125,161 125,155 124,154 124,151ZM243,141 241,141 237,144 234,150 235,152 238,152 242,148 244,143ZM105,141 104,142 105,148 109,152 112,152 113,151 112,147 108,142ZM228,138 227,139 227,147 229,150 231,150 232,148 232,141ZM119,138 117,138 115,141 115,147 117,150 118,150 121,146 121,141ZM105,134 105,136 109,137 108,134 106,135ZM246,127 244,127 241,129 238,136 239,138 241,138 245,134 246,132ZM101,127 103,133 105,131 107,131 104,127ZM231,125 230,126 230,132 232,136 235,136 235,128ZM117,125 115,125 112,129 113,132 112,136 114,137 118,132 118,127ZM247,112 245,112 242,115 241,118 241,123 243,124 247,119ZM233,112 231,114 232,120 235,123 237,123 237,116ZM116,112 114,112 110,116 110,122 111,123 113,123 116,119ZM101,111 100,112 100,119 103,123 106,124 107,123 106,116 104,113ZM232,99 231,100 231,104 234,109 236,110 237,109 237,103 234,99ZM116,99 114,99 110,103 110,109 112,110 117,104 117,100ZM246,97 243,99 241,103 241,109 242,110 246,107 247,104 247,98ZM102,97 100,99 100,104 102,108 105,110 106,109 106,101 105,99ZM229,86 229,90 230,92 235,96 236,95 235,89 232,86ZM118,85 115,86 112,89 111,92 111,95 112,96 115,95 117,93 119,89 119,86ZM243,82 240,86 240,94 241,95 245,92 245,84ZM104,82 103,83 102,90 103,93 106,96 108,93 108,87ZM226,73 225,74 226,78 230,82 233,83 234,81 232,76 230,74ZM122,73 119,73 115,76 113,82 114,83 117,83 121,79 123,74ZM239,68 236,72 237,81 239,81 242,78 241,70ZM108,68 106,71 106,79 109,82 111,79 112,74 111,71ZM121,59 119,59 115,63 114,69 116,71 120,67ZM228,58 227,59 227,65 231,70 233,70 233,65 231,61Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M105,127 108,131 105,132 103,134 101,130 101,132 105,137 109,138 107,138 104,136 105,133 106,134 108,133 109,135 109,133ZM246,111 248,112 248,119 246,122 242,125 240,123 240,119 239,119 238,117 238,122 239,122 241,125 243,125 244,126 243,127 246,126 247,127 247,131 247,127 243,125 248,119 248,112ZM239,87 239,91 237,92 236,90 237,95 235,97 230,93 234,97 231,98 230,101 232,98 235,98 237,96 237,94 239,93Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M447,165 446,163 443,165 442,164 442,165 438,167 437,169 432,170 434,171 431,172 430,174 423,173 420,170 418,170 419,175 430,176 431,175 438,174 441,172ZM401,155 404,159 406,158 408,160 403,155ZM234,146 233,149 231,151 235,154 234,155 236,153 240,155 239,153 234,153 233,152 233,149 235,146ZM114,141 114,144 112,145 115,151 113,153 109,153 105,149 109,153 107,155 108,154 113,154 113,153 116,151 114,147ZM101,134 105,138 104,140 107,140 109,142 108,140 111,137 110,132 109,132 110,133 110,138 108,140ZM113,125 111,125 109,123 109,118 107,116 108,117 108,124 107,125 102,124 100,126 101,125 105,125 107,128 106,126 109,123 112,126ZM119,82 117,84 114,84 113,83 114,86 111,89 109,88 109,86 110,89 109,93 110,93 110,90 115,85 118,84 120,87ZM114,77 112,78 112,80 109,83 107,82 105,79 102,83 105,81 108,84 113,80ZM227,68 229,70 229,72 233,75 235,79 235,82 232,84 232,85 235,87 233,85 237,82 235,79 235,70 238,67 234,70 235,73 233,75ZM468,62 459,62 458,63 455,63 452,65 451,64 448,66 440,65 432,69 422,69 418,71 415,74 414,73 407,74 399,70 396,66 394,66 391,70 389,69 388,70 390,73 390,79 391,80 392,92 394,97 394,103 396,103 397,106 405,106 408,110 411,120 413,123 418,127 431,126 434,124 440,124 441,123 445,123 450,121 455,121 456,120 467,118 470,113 470,100 469,99 469,95 471,91 470,90 470,66Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M390,147 382,152 380,152 371,160 371,164 376,170 377,170 375,169 371,164 372,159 375,156 388,149ZM307,123 311,121 318,121 324,124 330,132 330,138 330,132 328,127 323,123 316,120ZM157,83 155,86 155,93 155,86 160,82 172,80 178,77 184,79 187,82 187,128 192,132 187,127 187,82 186,80 183,78 178,77 177,78 174,78 171,80 163,81ZM117,52 113,55 108,61 104,62 102,64 101,67 102,64 104,62 110,60 116,53 118,52 122,52 126,55 127,58 127,65 126,67 129,71 129,76 126,82 129,76 129,70 127,68 127,58 126,55 123,52ZM410,42 418,41 423,39 439,37 440,38 443,38 450,43 452,43 454,45 461,48 470,54 474,58 464,49 462,49 460,47 456,46 453,43 441,37 428,38 427,39 417,40 416,41Z\"/>",
	J: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M550,167 549,168 549,177 547,179 537,179 536,182 537,184 547,184 549,186 549,195 550,196 553,196 554,195 554,186 556,184 566,184 567,183 567,180 566,179 556,179 554,177 554,168 553,167ZM485,137 489,145 495,150 499,150 500,151 499,152 525,152 528,153 533,158 541,172 542,171 542,165 534,152 530,149 527,148 499,148 495,150 494,149 493,143 489,135 487,135ZM393,127 387,132 386,137 387,140 391,144 396,145 402,142 404,139 404,133 400,128 398,127ZM435,123 434,126 430,131 431,132 429,133 422,146 422,154 429,167 433,172 436,179 438,181 441,181 443,183 447,183 448,184 450,183 470,184 475,182 480,193 485,200 490,210 497,215 528,215 535,210 542,198 542,192 541,191 535,202 533,204 533,206 529,210 526,211 500,211 495,209 493,207 488,197 483,190 480,184 480,180 479,179 476,181 475,179 472,180 446,180 443,179 437,173 431,161 427,156 426,148 430,141 429,135 432,130 442,119 445,118 448,119 450,121 462,121 465,117 443,117 440,118ZM187,101 186,102 186,108 184,110 178,110 177,112 178,113 184,113 186,115 186,121 189,122 189,115 191,113 198,113 199,111 198,110 191,110 189,108 189,102ZM392,86 388,89 386,96 387,99 391,103 396,104 402,101 404,98 404,92 400,87 398,86ZM504,84 505,89 517,110 521,114 526,116 552,116 553,115 556,115 561,112 569,100 569,93 568,92 565,96 565,98 562,102 560,107 557,110 553,112 527,112 523,110 519,106 511,91 508,87ZM297,82 294,82 287,85 279,86 278,88 283,92 283,102 284,103 283,131 281,133 278,134 279,137 303,137 304,136 304,134 301,133 298,130 298,83ZM91,82 87,82 72,87 72,88 77,92 77,130 74,133 71,134 72,137 96,137 97,136 97,134 94,133 91,130 91,93 92,92 92,83ZM577,67 576,68 576,78 574,80 565,80 564,83 565,84 573,84 576,86 576,96 577,97 580,97 581,96 581,86 584,84 593,85 594,84 594,81 593,80 583,80 581,78 581,68 580,67ZM524,50 526,53 554,53 560,58 562,61 562,63 565,66 566,70 569,72 569,66 563,55 559,51 555,49 527,49ZM514,35 512,39 520,51 521,50 521,45 518,41 516,36ZM456,34 449,47 449,55 462,78 469,84 496,84 495,80 488,80 487,81 486,80 472,80 468,78 465,75 464,72 460,67 459,63 456,60 456,58 453,54 453,48 457,42 457,39 456,38 457,34ZM492,17 487,17 486,18 481,18 480,17 477,18 476,17 473,17 472,18 469,18 462,24 461,27 459,29 459,31 465,25 465,24 471,19 474,19 477,21 481,21 483,22 484,21 489,21Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M515,45 517,47 517,50 518,51 517,57 516,58 518,58 525,53 523,50 526,49 524,49 522,47 522,50 520,52Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M486,224 495,231 530,231 529,230 533,228 532,226 530,227 497,227 496,226 493,226 488,223ZM434,194 438,197 441,197 444,199 448,199 449,200 454,200 457,202 462,200 467,204 472,205 474,207 473,203 468,195 454,195 451,196 450,195 440,195 436,193ZM540,191 537,191 534,196 534,199 531,203 531,205 524,210 503,210 491,201 495,207 498,209 501,209 502,210 525,210 530,207ZM436,167 438,172 443,177 445,178 456,178 447,178 443,174 441,174 438,171ZM431,140 431,142 428,146 428,154 430,157 429,156 430,154 429,150 430,149ZM483,139 481,142 482,142 483,144 483,143 485,142 488,145 487,143 484,141 484,139ZM488,133 492,135 490,136 496,147 528,147 532,149 538,155 540,160 542,162 542,164 545,161 539,150 531,144 528,144 527,143 499,143 497,141 494,134 491,130ZM522,128 523,130 525,130 527,132 530,132 531,134 536,132 547,132 548,131 549,132 550,131 553,132 555,131 557,128 559,129 559,127 556,127 555,128 527,128 526,129 523,127ZM434,116 432,120 429,123 426,130 422,135 417,146 417,155 430,179 435,185 441,188 452,188 453,189 458,189 459,188 470,189 471,188 478,198 486,213 490,217 497,220 529,220 535,217 539,213 545,204 545,202 543,200 543,191 542,191 543,192 543,199 537,209 531,215 525,216 524,217 501,217 500,216 496,216 494,215 488,209 474,184 473,185 443,185 439,183 433,177 421,155 420,152 421,144 425,139 433,124 438,118 444,115 465,115 467,116 469,112 441,112ZM465,97 475,101 479,101 483,98 487,98 504,113 503,109 501,107 497,98 495,96 467,96 466,95ZM464,70 467,75 473,79 484,79 474,79ZM545,54 550,54 556,58 563,66 561,62 556,56 551,54ZM458,40 458,42 454,49 454,53 459,61 459,58 457,56 457,53 458,52 457,46 459,43ZM511,38 506,44 509,46 514,46 516,48 511,40ZM515,34 518,37 519,41 524,48 532,48 533,47 534,48 557,48 564,54 570,65 570,67 570,64 572,61 567,52 561,46 559,46 556,44 527,44 524,41 519,31ZM461,17 457,22 447,41 445,43 444,46 444,56 449,66 455,74 458,81 464,87 469,89 499,89 505,98 505,100 507,102 512,112 518,118 524,121 555,121 558,119 562,118 566,114 572,104 570,101 570,92 569,91 567,91 564,93 564,97 561,100 556,108 552,110 556,109 564,98 564,95 569,91 570,92 570,100 568,102 564,110 559,115 555,117 524,117 520,115 516,111 508,96 506,94 503,87 501,85 498,86 472,86 466,84 461,79 455,67 448,56 447,53 448,46 454,35 456,33 457,29 460,26 461,23 466,18 470,16 492,16 494,17 496,14 496,12 483,12 482,13 474,12 473,13 467,13Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M482,183 483,187 488,193 488,195 491,198 491,200 503,209 524,209 530,205 530,203 532,201 533,196 536,191 533,192 534,193 531,197 531,199 526,204 520,205 519,206 506,206 503,204 498,203 493,198 493,196 490,193 489,189 486,187 486,185ZM494,157 496,155 501,155 502,156 509,156 510,157 522,158 527,161 535,170 535,172 539,172 540,173 537,170 535,164 527,155 524,154 498,154ZM489,148 485,143 484,143 483,145 482,143 480,142 482,140 461,163 458,163 452,159 432,141 431,149 430,150 431,153 430,156 435,166 437,167 439,171 441,173 443,173 447,177 456,177 457,178 459,177 469,177 471,178 475,176 472,177 467,175 459,176 455,174 447,174 440,168 441,167 440,168 439,167 438,160 439,159 442,159 445,161 447,160 450,161 453,164 457,164 459,166 461,166 463,165 464,163 468,163 477,153 484,148 489,152 489,154ZM496,125 495,127 492,129 495,135 494,130 496,128 497,129 496,128ZM467,117 461,123 452,123 451,122 455,125 458,125ZM509,79 509,85 512,89 514,94 516,95 518,101 527,109 532,109 533,110 551,110 553,108 555,108 560,100 563,97 563,93 566,91 564,91 560,95 559,98 551,107 532,108 521,100 517,94 517,91 511,83 509,82ZM525,55 526,56 531,56 537,58 549,58 559,65 559,67 563,73 567,73 568,74 570,73 569,74 566,73 565,70 560,63 550,55 545,55 544,54 542,55ZM458,46 458,49 459,50 458,56 460,58 460,62 464,69 474,78 484,78 485,79 487,78 495,78 497,79 494,77 493,78 492,76 488,76 487,77 484,77 483,76 481,77 475,76 467,69 466,67 467,65 466,66 465,65 465,63 467,60 469,59 473,59 477,61 482,67 486,68 490,63 492,64 491,65 495,62 504,52 507,51 509,49 513,49 516,52 516,54 516,49 514,47 509,47 505,45 497,55 488,64 485,64 477,58 467,48 461,44 459,41 460,43ZM493,19 488,24 480,24 479,23 481,25 485,26Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M545,201 547,203 543,209 546,211 546,213 544,216 551,203 547,203ZM482,179 482,182 485,183 487,185 487,187 490,189 490,191 494,196 494,198 498,202 503,203 506,205 519,205 520,204 526,203 530,199 530,197 533,193 532,192 534,190 539,190 533,190 530,189 530,191 527,197 521,202 518,203 510,203 507,202 506,203 501,200 497,196 491,188 491,186 489,183ZM492,161 494,159 499,161 502,160 504,161 510,161 511,160 518,161 519,160 523,164 526,165 534,173 539,173 535,173 531,166 527,162 522,159 496,156ZM488,152 484,149 477,154 468,164 464,164 464,165 461,167 459,167 457,165 453,165 450,162 447,161 445,162 442,160 439,160 440,167 447,173 455,173 459,175 467,174 468,175 474,176 477,174 480,169 477,171 474,167 475,166 475,161 476,159 479,158 480,156 482,156 484,154 486,154 487,157ZM496,129 495,130 495,133 497,138 496,134 497,133 498,134 499,131ZM577,104 574,104 570,109 572,108 573,109 574,108 575,110ZM510,78 510,82 512,83 518,91 518,94 522,100 532,107 551,106 563,91 557,90 556,92 556,96 549,104 546,105 542,105 541,104 538,105 536,103 533,103 532,104 530,102 527,102 524,99 523,95 520,92 521,91 518,88 516,84 511,80ZM520,60 523,59 526,61 529,61 530,62 537,62 538,61 544,61 545,60 547,62 551,63 560,74 562,73 559,69 558,65 549,59 537,59 536,58 532,58 531,57 526,57 524,56ZM515,52 513,50 509,50 507,52 504,53 495,63 492,65 490,64 486,69 482,68 481,67 484,66 481,67 477,62 473,60 469,60 467,61 466,65 468,69 475,75 478,75 479,76 482,75 484,76 492,75 493,77 494,76 496,78 499,78 502,77 505,73 503,74 498,72 499,70 497,69 498,64 509,54 513,54 515,56ZM522,26 520,28 522,29 522,34 524,38 524,34 525,32 522,28Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M450,194 466,194 465,191 451,191ZM559,165 556,169 556,176 557,177 567,177 569,179 569,184 567,186 565,186 565,188 566,189 569,189 572,186 572,177 569,174 561,174 559,172ZM233,150 231,152 235,155 235,150ZM142,150 140,150 140,155 141,156 141,155 144,153 144,151ZM26,150 24,152 28,155 29,150ZM349,149 347,150 347,155 351,153 351,151ZM537,141 537,142 544,148 546,154 551,160 544,148ZM504,138 504,139 508,139 509,140 508,141 527,141 528,140 530,141 529,142 532,141 532,139 530,138ZM351,137 351,139 352,141 353,141 355,138 354,137ZM148,137 145,137 145,142 149,139ZM228,136 226,139 231,143 231,137ZM22,136 20,139 23,143 24,143 24,138ZM418,132 411,146 411,153 411,151 413,148 415,147 414,143 417,142 416,141 416,138 418,135 417,134ZM393,125 400,126 406,133 406,139 405,141 401,145 396,147 389,145 384,138 385,135 383,134 385,133 387,129 390,126ZM97,123 97,126 102,132 101,133 98,132 99,133 99,136 97,139 96,138 93,139 90,138 89,140 90,142 89,140 91,138 93,142 100,142 103,138 103,133 97,126ZM72,123 71,127 66,131 66,139 70,142 75,142 76,138 71,138 69,136 69,133 71,131 74,131 75,130 75,123ZM355,122 353,123 355,127 355,129 356,129 359,124ZM226,122 224,125 226,128 227,128 229,124ZM150,122 146,123 148,126 148,129 149,129 152,125ZM19,122 17,125 20,129 21,129 22,124ZM400,122 396,122 395,121 394,122 391,122 386,125 382,129 381,139 383,143 390,150 400,150 405,147 408,143 410,137 408,129 406,126ZM356,109 354,110 354,111 356,113 356,116 357,117 357,114 359,111ZM224,109 223,111 224,113 226,114 227,110ZM149,109 148,111 150,114 151,114 152,110ZM18,109 16,111 18,114 19,114 21,110ZM441,107 436,108 430,113 420,128 425,124 426,120 429,116 433,113 437,108ZM186,99 189,99 191,101 191,107 192,108 199,108 201,110 201,113 199,115 192,115 191,116 191,120 193,119 194,121 191,122 189,125 186,125 184,123 184,116 183,115 177,115 175,113 175,110 177,108 183,108 184,107 184,101ZM184,96 181,99 182,100 181,103 179,105 174,106 172,108 173,110 172,111 172,116 174,118 179,119 181,121 181,125 184,128 191,128 194,126 195,120 197,118 201,118 204,115 204,107 201,105 197,105 194,102 195,101 194,98 192,96ZM355,95 354,98 357,100 358,96ZM227,95 224,96 225,101 226,101 229,97 229,96ZM150,95 147,96 149,101 151,99 151,96ZM19,94 17,97 18,99 20,100 22,96ZM301,87 302,88 302,100 301,101 300,100 300,88ZM392,84 398,84 400,85 406,92 406,98 405,100 401,104 396,106 389,104 385,99 385,96 384,95 386,89ZM146,82 145,84 148,87 148,90 149,90 148,82ZM391,81 387,83 382,89 381,99 384,104 389,108 392,109 399,109 403,107 407,102 409,98 409,90 402,82 400,81ZM353,81 352,84 355,86 356,82ZM228,81 227,82 227,86 230,84 230,82ZM22,81 19,82 21,86 20,88 21,88 24,84ZM597,79 598,80 598,85 597,86 596,85 596,80ZM301,77 295,76 287,80 277,81 273,84 273,91 274,93 278,96 278,107 279,108 278,110 278,126 273,131 273,134 272,135 273,140 276,142 284,142 285,141 284,138 277,138 276,137 276,133 282,129 282,113 281,112 282,109 282,102 281,101 282,99 282,92 281,91 278,91 276,89 276,87 279,84 284,84 294,80 298,80 300,82 300,130 301,131 304,131 306,133 306,136 304,138 294,138 294,142 306,142 309,139 309,132 307,129 303,127 303,87 304,86 304,81ZM96,79 92,76 88,76 85,78 79,79 75,81 74,80 73,81 70,81 68,82 66,85 66,91 68,94 71,95 71,99 71,94 67,91 69,89 71,90 69,87 72,84 78,84 87,80 91,80 94,84 93,92 94,92 93,91 94,90 97,92 97,82ZM591,75 592,78 594,78 596,80 596,84 593,87 591,87 590,90 596,90 596,89 599,87 599,78 597,77 596,75ZM586,67 583,68 583,70 586,71 587,70ZM344,55 346,55 350,58 352,62 352,67 356,64 360,67 361,70 361,77 360,78 364,81 364,85 365,86 363,93 366,95 366,103 364,108 367,110 367,115 365,120 363,122 363,123 366,125 366,127 364,133 361,136 363,139 363,142 361,147 357,151 359,154 356,161 353,164 348,166 343,163 341,163 338,159 338,151 339,148 341,146 343,146 342,139 343,138 343,135 346,133 345,125 348,121 347,110 349,108 346,100 347,92 345,90 345,86 344,85 346,82 343,79 340,73 340,71 342,69 345,69 345,67 343,65 343,62 342,61 342,57ZM238,55 240,57 240,63 236,69 240,69 242,71 242,73 240,78 237,81 238,88 234,94 236,97 236,103 233,107 236,110 236,116 234,119 234,121 235,121 237,124 236,134 239,136 240,139 240,145 239,146 241,146 243,148 244,151 244,159 241,163 238,163 236,165 231,165 225,159 224,156 225,151 221,147 220,141 219,140 221,136 217,130 217,126 216,124 219,122 216,118 216,110 218,108 216,103 216,96 219,93 218,90 218,82 219,80 222,78 221,76 221,71 223,66 226,64 230,67 230,62 231,60 236,55ZM136,52 132,56 132,63 133,66 130,69 130,74 132,79 134,81 134,89 136,93 136,103 138,106 137,108 137,121 135,124 134,134 132,136 132,142 128,150 128,159 130,164 132,166 134,166 138,169 144,169 147,168 153,162 153,160 155,157 156,150 158,148 160,142 160,135 162,131 163,107 162,106 162,100 160,99 160,102 157,108 160,110 160,117 156,122 156,123 159,125 158,132 155,136 156,138 156,143 155,146 150,151 152,153 150,160 145,165 139,165 137,163 135,163 131,158 131,152 132,149 136,146 136,137 137,135 140,133 139,131 139,123 141,121 143,121 140,117 140,110 143,107 140,103 140,99 139,98 142,94 138,90 138,85 137,84 139,81 135,77 135,75 133,72 135,69 140,69 137,66 137,64 135,61 136,60 136,57 138,55 140,55 145,61 146,67 149,64 151,64 153,66 154,72 155,73 154,77 157,80 158,88 161,88 161,80 158,76 157,66 152,61 150,61 143,53 141,52ZM343,51 339,55 339,63 340,66 337,69 337,74 340,81 340,85 343,93 344,112 343,113 343,121 342,122 342,131 339,137 339,142 334,152 334,159 336,163 339,166 341,166 343,168 346,169 348,168 350,169 355,167 360,162 362,156 362,151 365,147 365,143 367,139 367,134 369,129 369,119 370,118 370,107 369,104 370,103 370,96 368,92 368,82 367,79 365,77 365,72 362,63 359,61 357,61 353,56 348,52ZM238,51 232,53 226,60 222,61 218,68 219,70 218,71 218,75 215,79 215,82 214,83 213,107 212,108 213,129 214,130 214,133 216,136 216,144 220,151 221,159 223,161 224,164 227,167 231,169 236,169 243,166 246,163 248,159 248,151 244,144 243,136 241,133 241,129 240,128 241,127 240,126 240,121 239,120 239,106 238,105 239,104 239,93 242,86 242,81 246,71 243,66 243,63 244,62 243,54 241,52ZM33,51 28,51 19,60 14,62 11,70 11,75 8,81 8,91 6,95 6,110 5,111 5,114 7,120 7,133 9,136 9,143 13,151 13,154 16,162 20,167 22,167 25,169 29,169 36,166 40,162 41,159 41,151 39,148 39,146 37,144 37,140 34,132 34,125 32,120 32,99 29,99 29,103 26,107 26,108 29,110 29,117 27,121 30,123 30,127 32,126 34,128 32,132 31,130 30,130 29,133 33,137 33,146 36,148 36,150 38,153 38,157 37,160 34,163 32,162 29,165 26,165 25,166 18,158 17,155 18,150 14,146 13,140 12,139 15,136 11,132 11,129 10,128 10,125 13,123 13,122 9,117 9,110 11,108 11,106 9,103 9,96 12,92 11,89 11,83 12,80 15,78 14,71 16,68 16,66 18,64 20,64 22,67 23,67 23,63 25,59 29,55 31,55 34,58 32,66 29,69 33,69 35,71 35,74 33,78 30,81 32,85 31,87 32,86 33,89 33,88 35,87 35,81 39,73 39,70 36,66 37,63 37,56ZM445,33 440,42 438,48 438,53 439,54 440,60 442,53 440,52 441,51 440,49 442,48 441,44 443,41 443,39 445,37 444,36ZM451,22 458,14 462,13 466,10 468,11 471,10 491,10 493,7 469,7 466,8 462,12 454,17ZM509,2 512,4 513,2 516,2 514,0 511,0Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M466,191 466,193 470,195 481,215 488,222 495,225 530,225 537,222 545,213 545,211 543,210 535,219 531,221 526,221 525,222 499,222 498,221 494,221 489,218 484,213 471,190ZM486,155 480,157 477,161 477,162 479,163 478,165 476,166 477,170 478,170 482,165 486,158ZM413,147 414,148 412,151 412,157 413,160 416,163 416,165 425,179 427,184 432,189 439,193 442,193 443,194 449,194 451,190 457,190 442,190 435,187 430,182 426,174 421,167 419,162 417,160 415,154 415,148ZM536,141 533,140 531,143 533,143 540,149 546,159 546,162 544,164 544,172 542,174 534,174 532,173 531,171 520,162 515,162 514,161 511,161 510,162 504,162 502,161 499,162 494,160 491,163 486,173 484,175 484,178 483,179 487,180 491,184 495,192 496,192 498,194 498,196 505,201 509,201 510,200 512,202 518,202 521,201 526,197 529,191 529,189 532,188 533,189 542,189 544,191 544,198 547,202 556,202 559,199 559,191 561,189 565,189 564,186 557,186 556,187 556,197 554,199 549,199 547,197 547,187 546,186 536,186 535,185 535,179 537,177 546,177 547,176 547,167 549,165 554,165 556,168 558,165 556,162 553,162 548,158 545,154 543,148 539,145ZM285,138 286,139 285,142 288,142 289,140 290,142 293,142 293,138 290,138 289,140 288,138ZM76,142 89,142 90,140 91,142 92,142 91,139 93,138 90,140 89,138 77,138ZM498,136 498,139 500,141 507,141 508,140 504,140 503,138 501,138ZM497,114 494,119 488,125 476,140 460,157 458,157 435,137 436,133 438,132 438,131 445,124 449,126 455,132 458,133 485,104 494,110ZM501,113 498,109 487,100 483,100 483,101 476,107 442,107 439,108 430,116 427,120 426,124 420,129 418,134 419,135 415,144 416,145 415,143 418,140 419,137 423,132 430,118 435,113 442,110 470,110 472,112 471,114 469,115 461,125 457,128 456,128 450,122 447,120 445,120 440,123 431,135 431,138 433,141 434,141 457,161 461,161 477,144 483,136 495,124 501,116ZM94,91 95,92 93,93 93,130 101,132 96,126 96,93 95,91ZM69,90 68,91 72,94 72,122 75,122 75,92ZM32,87 30,89 30,91 27,94 30,94 31,95 29,98 32,98 30,97 34,90 34,88 33,90ZM583,71 583,77 584,78 591,78 590,75 589,76 585,71ZM513,55 509,55 506,57 506,58 500,64 499,64 498,69 500,70 499,72 504,73 506,71 514,57ZM442,55 442,59 441,60 442,64 451,78 453,83 458,89 462,92 468,94 495,94 500,100 507,114 512,120 520,125 523,125 524,126 556,126 565,122 571,116 572,112 574,110 572,112 571,111 572,109 570,110 568,114 563,119 557,122 522,122 518,120 510,112 504,100 498,91 469,91 466,89 464,89 454,78ZM525,37 525,39 527,42 555,42 562,45 569,52 569,54 574,61 571,65 571,73 569,75 564,75 563,74 560,75 551,64 549,64 545,61 544,62 538,62 537,63 530,63 521,60 515,69 511,77 511,79 517,84 519,88 522,91 521,92 524,95 525,99 527,101 530,101 532,103 533,102 536,102 538,104 540,103 542,104 546,104 549,103 551,100 553,99 555,96 555,92 557,89 560,89 561,90 569,90 571,92 571,99 574,103 579,103 580,102 582,103 584,102 586,99 586,92 589,90 590,87 583,87 583,97 581,99 576,99 574,97 574,87 573,86 567,86 565,87 562,84 562,80 564,78 573,78 574,77 574,67 576,65 581,65 583,67 585,67 586,65 580,62 575,57 572,51 568,48 567,45 559,40 556,39 530,39 527,37ZM467,11 464,12 462,14 458,15 451,23 452,24 450,25 448,28 448,30 446,32 446,35 445,36 446,37 444,39 442,46 443,46 443,43 447,38 448,34 452,29 458,18 463,13 465,13 467,12ZM517,3 513,3 513,4 514,3 515,4 515,6 524,14 524,16 487,58 485,58 472,47 470,44 465,41 462,38 462,36 472,24 480,31 485,34 501,17 511,4 508,3 502,10 498,7 494,7 491,11 471,11 497,11 499,13 485,28 483,28 474,21 469,22 459,33 458,36 459,40 484,62 488,62 525,21 527,17 527,13 525,12Z\"/><path fill=\"#a63441\" fill-rule=\"evenodd\" d=\"M356,153 352,154 348,158 346,162 347,164 351,163 355,159 357,154ZM227,153 226,154 227,159 231,163 234,164 236,162 235,159 230,154ZM149,153 145,154 140,160 140,164 145,163 148,160 150,155ZM20,153 19,155 21,160 24,163 28,163 29,162 28,158 22,153ZM343,149 340,150 340,153 339,154 339,157 342,161 345,158 345,151ZM134,149 133,158 134,160 136,161 138,158 139,153 136,149ZM240,148 237,151 237,156 238,159 241,161 242,160 243,153ZM33,148 31,150 30,156 31,159 34,161 36,158 36,153 35,150ZM360,139 355,141 352,147 353,150 356,150 359,147 361,142ZM222,139 221,141 225,149 230,150 231,149 228,143 225,140ZM153,139 150,140 147,143 147,145 145,148 146,150 149,150 153,146 154,143 154,140ZM16,139 15,140 15,144 16,146 20,150 23,150 24,149 23,146 21,144 21,142ZM345,136 344,143 345,146 348,148 349,147 350,141 348,137ZM237,136 235,136 232,140 232,143 234,148 236,148 238,145 238,138ZM138,136 137,139 138,140 138,146 140,148 142,148 143,140 140,136ZM30,136 28,136 26,139 27,142 26,146 27,148 29,148 31,145 31,138ZM226,135 225,132 222,134 223,135ZM364,125 361,125 357,129 356,136 359,136 362,133ZM218,126 220,128 220,130 223,129 225,130 221,125ZM157,125 154,125 151,128 149,134 150,136 152,136 156,132 157,130ZM12,125 13,128 15,127 16,129 18,130 18,132 15,133 15,134 19,136 20,133 18,128 14,125ZM349,123 347,125 347,130 348,133 351,135 353,133 353,127 352,125ZM234,123 232,123 230,125 229,128 229,131 231,135 234,133 233,132 235,129 235,124ZM141,123 140,125 140,129 141,132 144,135 146,133 146,127 143,123ZM28,123 25,123 23,126 23,134 24,135 27,133 29,129ZM364,110 361,111 358,117 358,121 359,122 361,122 365,116 365,111ZM350,110 348,113 349,118 353,122 355,119 355,115 354,113ZM233,110 231,110 228,113 228,121 229,122 234,116 234,111ZM218,110 217,111 218,118 220,121 223,122 224,121 224,115 220,110ZM157,110 153,112 153,114 151,117 151,121 152,122 154,122 158,117 158,111ZM143,110 142,111 142,118 147,122 148,121 148,114ZM26,110 24,110 21,114 21,121 24,121 27,117 27,111ZM12,110 11,111 11,117 15,122 17,122 18,121 17,115 16,113ZM349,97 348,98 348,102 349,104 354,108 355,107 355,102 351,97ZM233,97 231,97 228,100 227,103 227,107 228,108 230,108 234,103 234,98ZM142,97 141,98 143,105 147,108 148,107 148,101 144,97ZM26,97 24,97 21,101 21,105 20,106 21,108 23,108 27,103 27,98ZM363,95 360,97 358,102 358,107 359,108 363,106 365,101 365,97ZM219,95 218,96 218,104 220,107 223,108 224,107 224,100 223,98ZM156,95 152,100 152,107 153,108 157,105 158,102 158,96ZM12,95 11,96 11,103 12,105 16,108 17,107 17,100 16,98ZM346,84 346,88 347,90 351,94 353,94 354,91 352,86 349,84ZM235,84 233,84 229,88 228,94 231,94 234,92 236,88 236,85ZM28,84 25,85 23,87 22,90 22,93 23,94 27,92 29,88 29,85ZM140,83 139,84 140,89 144,94 146,94 147,93 146,87 143,84ZM221,81 220,82 220,90 221,92 224,94 225,93 226,87 224,82ZM361,80 360,80 357,84 357,92 358,94 362,91 363,88 363,84ZM154,80 150,85 150,92 152,94 155,92 156,89 156,82ZM15,80 13,82 13,89 14,92 17,94 18,93 19,87 18,86 18,83ZM343,71 342,73 344,77 348,81 350,81 351,80 350,75 347,72ZM239,71 235,72 232,75 231,78 232,81 234,81 237,79 240,73ZM136,71 135,73 137,77 140,80 144,81 145,80 144,79 144,76 142,73 139,71ZM33,71 30,71 26,74 24,80 25,81 27,81 31,78 33,74ZM357,66 355,67 353,72 354,74 354,79 355,80 359,77 359,70ZM225,66 223,70 223,77 226,80 228,78 229,71 228,68ZM150,66 147,69 147,77 149,80 153,75 152,73 152,68ZM19,66 17,68 16,71 16,76 17,78 20,80 22,75 22,69ZM344,57 345,64 349,69 350,68 350,62 346,57ZM138,57 138,63 139,66 142,69 144,67 144,64 141,58ZM31,57 30,57 25,63 25,68 27,69 30,65ZM237,56 232,62 232,68 233,69 238,63 238,57Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M221,134 225,131 227,135 226,136 223,136ZM218,127 219,132 223,136 226,137 228,135 230,135 229,132 228,133 226,132 225,128 222,125 225,128 226,130 225,131 223,130 220,131ZM12,120 15,123 11,125 12,132 16,136 19,137 20,136 19,137 14,134 15,132 17,132 17,130 16,130 15,128 13,129 11,127 12,124 14,124 18,127 14,124 18,122 15,123ZM151,101 151,103 149,104 149,107 147,109 150,107 152,108 151,107Z\"/><path fill=\"#1f9c4f\" fill-rule=\"evenodd\" d=\"M479,33 480,34 477,40 478,42 478,39 481,37 481,34Z\"/><path fill=\"#3dae58\" fill-rule=\"evenodd\" d=\"M495,114 489,108 485,106 458,136 446,126 441,130 437,136 458,155 460,155 472,142 478,134 487,125ZM476,43 477,45 475,47 473,45ZM490,37 492,36 493,39 492,40ZM481,33 482,34 482,37 479,39 479,42 478,43 476,40 478,35ZM522,14 521,14 514,7 512,7 505,14 498,23 485,36 480,33 475,28 472,27 464,37 486,56 522,16Z\"/><path fill=\"#255255\" fill-rule=\"evenodd\" d=\"M499,151 494,151 493,149 490,148 491,152 487,160 483,165 478,175 474,178 476,179 479,178 480,179 488,165 490,163 492,158 496,154 495,152 497,151 498,153 501,153 499,153 498,152ZM523,55 518,59 515,58 516,56 505,76 500,80 496,80 497,82 496,85 472,85 498,85 501,84 504,88 503,84 505,83 508,86 507,80 510,76 510,74 512,72 513,69 517,64 519,59Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M24,146 25,150 23,152 29,158 31,162 29,157 29,154 29,155 27,156 23,152 27,149 25,146ZM347,132 344,136 346,134 348,135 350,138 350,136ZM354,127 354,134 352,136 354,136 356,139 353,142 352,142 351,140 351,146 352,143 356,139 354,136 356,130 354,129ZM146,110 149,113 149,121 148,122 150,121 150,116 151,115 150,115 147,110ZM356,101 356,108 355,109 357,108 360,111 359,112 362,108 363,109 364,106 359,110 357,108 357,101ZM162,84 162,88 161,89 157,89 157,91 153,95 151,95 149,93 149,91 148,91 149,94 150,94 152,97 157,93 159,95 159,102 159,99 160,98 163,100 163,102ZM349,82 349,83 354,87 355,90 355,94 353,97 355,94 357,94 359,97 360,95 358,95 356,93 356,89 355,87 351,84 351,82ZM156,80 153,78 150,81 146,80 143,82 143,83 146,81 148,81 149,82 149,87 149,83 153,79Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M416,134 413,139 411,136 409,143 406,147 411,141 412,142ZM464,105 444,105 443,106 439,106 434,108 434,109 426,116 417,132 427,115 436,107 439,106 449,106 450,105 451,106 452,105ZM205,107 205,114 205,107 203,105 197,103 195,100 196,99 195,97 192,95 189,95 188,94 187,95 184,95 181,97 180,102 178,104 174,104 171,107 171,116 174,119 176,119 174,119 171,116 171,108 174,105 179,104 181,100 180,99 184,95 192,95 195,98 196,101 195,102 197,104 201,104ZM304,79 304,80 301,76 298,75 294,75 293,76 292,75 286,79 276,80 274,81 272,84 272,90 272,84 277,80 287,79 295,75 301,76ZM81,78 85,77 88,75 92,75 94,76 97,79 98,82 98,90 98,81 97,78 93,75 86,75ZM587,71 589,74 596,74 599,76 599,73 596,74 589,74ZM574,52 576,57 580,61 584,62 587,65 587,69 588,69 587,64 583,61 580,61 577,58ZM339,52 338,54 338,63 339,66 336,69 336,74 336,69 339,66 338,63 338,55 343,50 346,50 351,53 357,60 359,60 362,62 364,65 364,67 365,67 364,64 360,60 357,60 355,58 354,55 346,50 342,50ZM146,54 142,51 134,50 131,55 131,63 132,65 130,68 130,67 132,66 131,63 131,56 136,51 141,51 147,56ZM34,50 28,50 25,52 19,59 15,60 12,63 12,65 10,68 10,75 8,78 6,87 7,86 7,81 10,75 10,69 13,62 15,60 19,59 28,50 33,50 38,56 38,63 37,65 40,70 40,73 36,81 36,86 36,81 39,77 40,70 37,65 38,63 38,55ZM525,31 530,37 535,37 536,38 543,38 544,37 558,38 561,40 563,40 567,43 573,50 573,49 566,42 561,39 555,38 554,37 530,37ZM516,0 517,2 529,13 529,17 524,23 528,19 529,17 529,13 528,11 524,8 517,0ZM509,0 507,0 506,1 507,2 503,6 469,6 468,7 465,7 463,9 458,11 452,19 454,16 462,11 466,7 469,6 503,6 506,4Z\"/>",
	K: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M135,147 134,148 134,166 139,166 140,165 144,165 147,163 147,155 144,152 139,150ZM204,118 200,118 200,120 197,123 188,126 185,128 179,128 178,127 167,128 167,143 166,146 162,150 162,182 163,183 166,181 175,181 180,179 185,179 190,177 195,177 198,175 198,142 203,138 204,135ZM459,85 449,93 449,102 451,102 457,97 459,99 459,145 460,146 468,146 469,145 469,86 468,85ZM194,71 193,70 189,70 190,71 190,74 189,75 185,75 184,76 181,76 180,75 177,77 166,77 164,76 161,78 159,78 158,79 159,82 159,93 156,97 158,98 160,96 162,97 166,96 168,98 171,98 172,97 175,97 176,94 180,94 181,95 183,92 190,92 195,85 195,81 196,80 195,79ZM289,60 281,66 275,69 273,72 300,112 301,117 274,157 273,160 284,167 287,170 290,171 326,118 327,115 292,62Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M432,193 437,198 440,199 443,202 442,199 438,194ZM494,188 491,189 487,195 489,195 489,194 492,192 491,190ZM431,172 431,174 439,183 440,186 462,214 467,210 494,173 494,172 479,172 477,170 477,165 476,164 449,164 448,165 448,170 446,172ZM203,109 199,108 197,110 193,110 191,112 187,112 186,113 183,113 182,112 180,114 177,113 176,114 173,114 171,115 167,121 167,127 172,127 173,126 185,127 188,125 195,123 199,120 200,117 204,117ZM193,89 190,93 183,93 181,96 180,95 176,95 175,98 168,99 166,97 164,98 160,97 158,99 155,98 155,100 159,102 161,100 165,100 167,101 179,97 183,97 184,98 187,96 191,96 192,95 191,91ZM194,70 190,62 187,59 185,61 183,60 177,63 173,63 172,62 167,62 166,64 163,63 161,64 158,68 157,67 155,68 153,67 155,70 157,80 159,77 161,77 164,75 166,76 177,76 180,74 181,75 184,75 185,74 189,74 189,71 188,70 189,69 193,69ZM494,57 490,53 489,50 481,41 479,37 475,33 473,29 463,16 458,21 453,29 437,49 435,53 431,57 431,59 446,59 448,61 448,66 449,67 476,67 477,66 477,61 479,59 494,59Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M193,185 185,185 184,186 171,188 170,189 166,189 165,190 157,190 152,187 152,188 158,193 160,192 169,192 174,194 177,192 182,191 181,190 182,189 186,190 190,187 193,187ZM532,180 519,182 518,183 511,183 502,186 493,187 492,188 493,187 495,188 492,190 493,192 491,193 489,196 486,195 479,205 485,203 488,199 494,196 496,193 502,191 511,190 515,188 518,188 522,185 523,185 524,187 525,184 530,183ZM126,172 126,174 130,175 131,177 142,180 142,173 141,172 135,174 130,174ZM395,171 397,174 402,177 406,181 408,181 412,185 416,185 419,189 426,195 428,195 431,198 433,198 437,202 440,203 441,205 445,207 446,209 452,214 443,200 444,201 443,203 440,200 437,199 431,193 433,192 421,186 397,171ZM460,77 461,78 463,77 464,78 468,75 472,75 472,74 460,74ZM172,47 170,48 166,48 165,49 161,49 160,50 156,50 155,51 151,51 150,52 146,52 145,53 140,53 139,54 131,55 126,60 125,63 125,71 128,80 124,83 120,83 117,85 115,89 115,112 118,121 120,123 120,133 121,134 120,137 120,159 128,165 134,167 133,166 133,147 136,146 143,151 145,151 148,154 148,163 145,165 148,166 149,177 159,182 161,184 162,184 161,182 161,150 165,146 166,143 166,121 170,115 173,113 176,113 177,112 180,113 182,111 183,112 191,111 193,109 197,109 199,107 203,108 199,100 192,93 193,95 191,97 187,97 184,99 183,98 179,98 167,102 165,101 161,101 159,103 156,102 154,100 154,98 157,93 158,86 157,85 157,81 155,77 154,70 152,67 153,66 155,67 157,66 158,67 161,63 163,62 166,63 167,61 177,62 183,59 185,60 187,58 190,61 181,51 176,48 173,48Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M427,188 434,192 438,193 434,189 431,190ZM429,154 427,156 427,164 428,165 434,165 435,164 433,157ZM457,153 458,155 461,156 463,158 466,156 471,156 472,155 471,153ZM493,123 489,123 487,124 483,129 482,135 483,137 487,140 490,140 494,138 497,134 498,128 497,126ZM452,110 448,111 450,117 452,117ZM521,89 516,89 514,90 511,93 509,97 510,98 510,102 511,104 514,106 520,105 523,102 525,98 525,93 524,91ZM397,78 395,82 396,90 400,95 402,95 404,92 404,86 400,78ZM437,66 436,69 437,71 438,71 439,73 443,74 446,78 449,79 451,81 460,78 459,77 459,74 458,76 457,76 456,74 446,74 442,71 442,67 441,66ZM492,67 491,66 486,66 485,65 483,67 483,71 480,74 473,74 472,76 468,76 465,78 469,78 470,79 476,80 488,72Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M428,182 429,183 428,184 428,188 431,189 434,188 437,191 430,184 430,183ZM456,153 457,152 471,152 473,155 471,157 466,157 463,159 461,157 458,156ZM114,136 114,130 113,131 108,131 110,131 111,132 111,135ZM481,124 483,123 485,125 482,126ZM497,66 494,65 486,65 491,65 493,67 488,73 480,79 478,79 476,81 473,80 475,82 476,85 476,97 475,98 476,100 476,132 475,133 476,135 476,144 475,145 475,149 472,152 456,152 453,148 453,110 452,109 449,110 451,109 453,110 453,117 452,118 449,117 449,115 446,110 444,109 442,110 444,113 443,115 443,119 445,123 444,124 446,127 446,130 447,131 445,134 446,136 446,144 445,146 447,148 447,152 448,154 454,158 455,162 472,162 474,158 482,152 483,150 483,147 484,146 483,144 485,143 486,141 481,135 482,129 485,125 483,122 485,120 485,117 483,114 483,108 484,107 483,91 487,84 487,82 486,83 483,80 487,76 493,75 493,74 496,72 498,68ZM430,66 430,69 429,70 430,72 434,74 433,76 437,78 438,80 440,81 445,81 449,83 452,82 446,79 443,75 439,74 438,72 436,71 435,69 437,65 441,65 442,66 441,65 433,65Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M468,216 464,216 465,220ZM145,180 152,185 153,181 151,180 149,181 148,180 149,179ZM116,161 120,166 123,167 124,164 121,165 120,164 121,162 120,161ZM118,145 119,147 117,150 116,147ZM115,143 115,150 119,150 119,143ZM208,139 205,139 201,143 201,147 202,147 204,150 204,161 204,145 207,142ZM206,105 206,107 205,108 204,106 205,109 207,110 206,111 208,113 208,119 209,118 209,115 208,114 209,113 209,108 208,106ZM111,84 110,89 111,88 114,89 112,86 114,84 112,85ZM93,78 96,79 96,82 100,82 101,83 101,94 100,95 101,95 103,98 101,100 99,100 106,100 105,99 108,98 110,94 107,97 102,96 101,95 101,81 97,78 93,78 85,85 78,89 68,98 65,99 60,104 56,106 51,111 49,111 47,115 48,118 54,124 57,125 69,135 72,136 73,138 76,139 92,152 97,154 100,152 97,154 95,153 96,152 95,150 94,152 93,151 92,152 89,149 89,145 79,138 78,136 74,133 71,132 51,116 55,111 66,104 70,100 93,83 92,81ZM385,69 385,82 389,82 391,81 391,69 388,71ZM289,58 294,62 329,115 329,117 326,120 291,173 287,172 271,161 271,159 276,152 277,149 280,146 285,137 288,134 291,128 300,116 271,72 272,69ZM287,55 278,61 276,64 271,65 267,69 267,73 281,92 282,95 289,103 290,107 295,113 295,116 293,120 290,123 289,127 284,132 283,135 280,138 280,140 277,143 276,146 268,157 267,161 268,163 273,167 285,174 288,177 291,177 293,176 298,170 299,167 302,164 305,157 311,150 316,141 328,125 332,118 332,114 330,110 327,107 325,102 320,98 319,96 320,95 318,93 317,90 307,77 307,75 304,73 298,62 292,55ZM133,50 128,51 123,55 121,58 120,66 121,66 122,64 123,65 122,63 124,62 125,58 131,54ZM417,48 411,50 398,51 397,53 396,52 398,55 400,56 402,60 404,59 405,57 408,58 410,52 414,55 415,54 415,51ZM150,46 151,47 152,46 161,46 162,47 160,48 165,47 163,46 164,45 166,45 167,47 170,46 168,45 169,44 174,44 175,45 174,46 177,45 178,48 183,50 184,52 191,58 190,59 193,63 196,71 197,70 200,73 200,71 194,58 189,51 182,45 179,45 178,43 165,43 156,46ZM488,38 487,38 481,32 471,19 470,16 466,12 461,11 454,18 448,26 447,29 443,34 441,35 439,39 434,45 437,41 439,43 441,42 453,25 463,14 470,19 469,21 467,19 479,35 482,34Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M125,164 123,168 130,172 135,172 141,170 143,172 144,179 148,178 147,177 147,167 146,166 138,167 137,168 131,168ZM428,153 431,153 434,156 436,160 436,166 435,167 428,167 425,164 425,157ZM115,151 115,154 118,155 118,156 115,157 116,160 119,160 119,157 118,156 119,151ZM202,148 200,149 200,176 198,178 191,179 190,180 186,180 185,181 181,181 180,182 176,182 175,183 168,183 163,185 159,185 157,183 154,182 153,185 155,187 158,188 165,188 166,187 171,187 172,186 177,186 178,185 182,185 187,183 191,183 193,181 200,181 203,178 203,172 204,171 203,170 204,169 203,168 203,164 204,162 203,161 203,150ZM90,146 90,149 92,151 93,150 94,151 94,149ZM106,131 105,132 103,131 102,132 101,131 98,131 97,133 97,148 96,149 97,152 96,153 100,151 100,144 99,143 101,140 101,137 103,135 107,135 108,134ZM206,110 205,110 205,112 207,115 207,118 206,119 206,135 204,139 205,138 208,138 209,135 209,119 208,120 207,119 207,113 205,111ZM111,89 110,90 111,95 108,99 106,99 108,99 110,101 110,114 111,115 112,121 115,125 115,142 119,142 119,125 117,123 114,115 114,90ZM518,87 523,89 526,93 526,99 520,106 518,107 514,107 508,102 508,96 514,89ZM460,83 466,83 467,84 468,83 471,85 471,146 469,148 459,148 457,146 457,100 449,105 447,104 447,92 454,86ZM100,83 97,83 97,99 98,100 102,98 101,96 99,95 100,94ZM397,77 400,77 403,80 405,85 405,93 402,96 399,96 396,93 394,88 394,81ZM197,71 196,72 197,73 197,85 193,91 193,93 194,93 200,99 203,105 204,105 206,108 205,105 207,104 203,99 203,97 198,91 198,89 200,87 200,74ZM385,68 388,70 390,68 392,69 392,81 389,83 385,83 384,82 384,69ZM123,63 122,66 120,67 121,70 120,71 120,75 121,76 119,79 116,79 115,82 112,84 113,83 115,84 113,86 114,87 118,82 125,81 126,80 124,75 123,66 122,65ZM161,47 152,47 151,48 149,47 146,48 145,50 144,49 138,49 137,50 134,50 132,54 133,53 142,52 147,50 157,49ZM482,35 480,36 497,59 495,61 480,61 479,62 479,67 477,69 448,69 446,67 446,62 445,61 430,61 429,58 439,45 437,42 434,46 433,45 432,46 427,46 426,47 418,48 416,51 416,54 414,56 410,53 410,57 408,59 405,58 405,59 402,61 399,56 397,55 396,53 397,52 391,54 388,57 384,64 384,70 383,71 383,87 384,88 383,91 383,99 384,100 384,113 383,114 384,117 383,120 384,122 384,131 383,132 383,136 384,137 384,143 383,145 384,146 384,154 385,155 385,158 390,165 401,171 416,181 418,181 421,184 423,184 426,186 428,183 426,182 429,181 446,201 457,217 462,221 464,220 463,217 460,215 445,194 438,186 437,183 432,178 428,172 430,170 446,170 447,169 447,163 448,162 454,162 453,159 446,153 446,149 444,146 445,144 445,141 444,140 444,137 445,136 444,135 445,133 445,130 444,129 445,127 443,125 443,122 442,121 442,115 443,114 441,111 442,109 444,108 448,110 452,108 454,110 454,148 456,151 471,151 474,149 474,145 475,144 475,135 474,134 475,132 475,100 474,99 475,97 475,85 474,82 472,80 456,80 450,84 447,84 443,82 442,83 439,82 432,76 433,74 431,74 429,72 428,67 432,64 441,64 443,66 443,70 447,73 478,73 482,70 482,66 484,64 494,64 497,65 499,67 498,71 495,75 494,74 495,75 494,76 490,76 487,78 491,81 491,83 486,94 487,95 487,108 485,111 485,113 488,119 486,120 485,123 488,122 494,122 496,123 499,127 499,133 493,140 491,141 487,141 486,144 487,146 485,148 483,153 479,156 477,156 473,161 473,162 477,162 478,163 478,169 479,170 483,170 484,171 486,170 494,170 496,173 465,215 469,215 484,195 493,185 504,184 505,183 508,183 510,181 518,181 519,180 528,179 531,177 533,177 539,171 542,164 542,126 541,125 541,122 542,121 542,100 541,99 541,96 542,95 542,87 541,86 542,85 542,79 541,78 542,77 541,74 535,65 528,61 526,61 524,59 522,59 519,56 512,53 510,50 508,50 505,47 503,47 500,44 493,41 489,38 487,39Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M96,84 94,84 66,106 60,109 56,112 53,116 55,118 57,118 63,124 71,129 83,139 86,140 95,148 96,147 96,132 98,130 113,130 114,129 114,126 111,122 109,116 109,105 108,104 109,102 108,101 98,101 96,99Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M488,77 484,80 486,82 487,81 488,82 487,87 484,91 484,98 485,99 484,114 486,117 486,119 487,119 484,113 484,111 486,108 486,95 485,94 490,83 490,81 486,78Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M268,164 275,170 277,170 278,172 287,177ZM311,151 306,157 303,164 300,167 296,174 293,177 290,178 297,174 301,166 304,163 304,161 308,157ZM279,139 277,140 272,150 270,151 266,158 266,160 267,157 275,146 275,144ZM102,85 102,94 103,95 108,95 109,94 109,88 109,92 105,95 102,92ZM92,78 85,82 71,94 64,98 60,102 50,109 46,113 46,117 52,124 56,126 60,130 62,130 72,139 79,143 87,150 95,155 95,154 92,153 76,140 73,139 72,137 69,136 57,126 54,125 47,118 46,115 47,112 49,110 51,110 56,105 60,103 65,98 68,97 78,88 85,84ZM270,65 266,69 266,73 270,78 271,81 277,88 278,91 281,94 287,105 290,108 288,104 286,103 287,102 281,95 280,92 278,91 277,88 266,73 266,69ZM286,55 280,58 279,60 277,60 272,64 276,63 278,60ZM288,54 292,54 296,58 304,71 308,75 309,78 318,90 319,93 321,95 320,96 322,99 326,102 328,107 331,110 333,114 333,118 316,143 320,139 321,136 326,130 326,128 330,124 330,122 333,118 333,112 318,91 317,87 316,87 311,81 311,79 308,76 307,73 298,61 298,59 292,54ZM178,42 170,41 169,42 165,42 160,44 155,44 149,46 138,47 134,49 127,50 121,57 126,51 131,49 145,47 150,45 156,45 165,42ZM443,32 433,44 429,44 423,46 418,46 417,47 411,47 409,49 397,50 389,54 387,56 383,65 386,58 391,53 397,50 410,49 418,46 424,46 425,45 433,44ZM444,30 445,30 453,18 461,10 464,10 471,16 472,19 478,27 487,37 489,37 495,40 497,42 510,49 513,52 515,52 517,54 533,63 533,62 530,60 526,59 516,52 514,52 496,40 486,36 482,32 467,11 465,10 461,10 459,11 455,15 453,19Z\"/>",
	L: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M237,128 233,133 233,139 237,144 239,145 244,145 250,140 250,137 251,136 250,132 246,128 243,127ZM240,86 237,87 234,90 233,92 233,99 237,103 243,104 246,103 250,99 250,92 246,87 244,86ZM107,82 103,82 100,84 94,85 93,86 89,86 88,88 93,92 93,131 87,135 88,137 112,137 113,136 112,133 109,133 107,131 107,92 108,91 108,83ZM328,64 320,75 317,82 306,99 306,101 301,108 299,113 300,121 306,130 306,132 310,137 312,142 317,149 325,164 328,167 332,169 382,169 383,168 387,168 394,162 396,157 401,150 403,145 405,143 418,120 418,111 414,105 411,98 407,92 404,94 405,98 409,103 414,113 414,119 408,130 404,135 391,159 386,164 383,165 335,165 332,164 328,161 327,158 324,155 323,152 321,150 321,148 319,146 314,136 307,126 305,120 303,118 304,111 311,100 311,98 316,92 317,88 322,81 322,79 328,70 331,67 334,66 383,66 386,67 388,69 389,69 391,66 385,62 332,62ZM480,58 476,62 473,69 469,74 469,76 465,81 463,86 461,88 451,106 451,113 452,116 463,133 474,154 480,161 484,163 536,163 541,161 547,154 553,142 555,140 560,130 564,125 564,123 566,121 568,116 570,114 570,106 564,95 562,93 559,86 555,89 566,107 566,112 565,115 560,122 559,126 556,129 546,148 543,151 541,155 536,159 486,159 482,157 477,151 455,112 455,107 458,103 461,96 463,94 466,87 474,75 474,73 476,71 478,66 483,61 487,61 488,60 535,60 541,63 543,60 541,58 535,56 526,56 525,57 515,57 514,56 512,57 506,57 505,56 500,56 499,57 483,57Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M396,177 389,180 384,180 383,181 333,181 323,178 323,179 330,185 334,187 337,185 342,185 344,187 350,185 353,187 356,187 357,186 363,187 365,186 368,188 370,186 374,187 375,186 390,185 390,183 394,181ZM548,174 547,171 542,174 539,174 538,175 483,175 474,172 476,174 476,176 479,178 480,177 483,179 482,180 485,181 492,180 493,179 496,179 498,181 537,180 536,179 537,178 541,178 542,179 543,177ZM402,96 400,100 403,100 407,103ZM554,90 552,92 554,94 556,94 559,97ZM325,60 321,64 317,72 309,84 306,91 298,103 298,105 294,113 294,119 302,135 307,142 309,147 314,154 316,159 321,167 325,171 332,174 386,174 391,172 396,168 400,162 401,158 407,150 407,148 409,146 411,141 413,139 423,121 423,110 414,93 412,91 412,89 410,87 407,90 409,88 411,89 411,91 409,92 409,93 411,95 413,101 419,110 420,117 416,127 411,134 409,139 404,146 404,148 400,153 394,164 390,168 386,170 331,170 326,167 320,159 316,150 311,143 308,136 306,134 298,119 298,112 299,109 308,95 315,81 317,79 323,68 328,63 332,61 386,61 392,65 392,67 390,69 394,64 394,62 391,59 385,58 384,57 332,57ZM477,54 472,59 458,85 452,93 452,95 449,99 446,106 447,117 459,138 461,140 471,159 474,163 478,166 484,168 538,168 546,164 550,159 553,152 561,140 563,135 565,133 567,128 569,126 575,115 575,105 574,102 572,100 564,84 562,82 564,85 562,87 562,90 564,92 564,94 568,99 571,105 571,114 564,127 562,129 559,136 550,150 548,155 542,162 538,164 483,164 480,163 475,158 450,114 450,106 451,103 474,63 480,57 486,55 536,55 541,57 544,60 546,56 542,53 535,52 534,51 515,51 514,52 511,51 508,52 505,51 496,52 494,51 492,52 490,51 489,52 481,52Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M416,80 409,87 410,86 413,89 414,92 416,89 418,89 414,84 414,82ZM570,83 565,77 566,76 557,85 561,81 565,84 566,87 567,84ZM332,69 328,73 326,78 324,80 324,82 319,88 317,94 311,102 310,105 308,107 308,109 306,111 305,118 307,120 308,124 311,127 311,129 318,139 318,141 328,157 335,163 383,163 389,159 391,154 393,152 395,147 397,145 403,133 407,128 412,118 412,113 409,110 409,107 405,102 400,101 399,100 400,98 386,113 381,112 365,98 362,99 364,103 364,106 370,109 373,114 378,116 387,116 390,113 392,113 395,111 398,107 402,107 403,106 409,111 410,114 409,117 410,119 408,121 406,127 399,136 397,142 389,154 386,157 378,161 373,161 372,162 349,161 348,160 345,162 341,162 340,161 337,161 332,158 326,152 326,150 323,146 322,142 320,141 321,140 319,139 316,131 311,126 311,123 309,120 309,111 311,109 311,106 313,102 318,96 318,94 326,80 332,73 338,69 341,70 343,69 348,69 349,70 357,70 358,69 366,70 367,69 373,69 374,70 383,71 385,73 389,70 387,71 382,68 334,68ZM484,63 479,69 478,72 470,84 468,89 466,91 464,96 462,98 460,103 458,105 458,108 457,109 458,115 464,123 466,129 469,132 471,137 475,142 476,146 480,152 486,157 534,157 538,155 541,152 547,141 549,139 563,113 562,111 563,106 559,98 556,95 554,95 552,93 551,93 538,107 534,107 532,106 520,95 516,93 517,94 517,98 521,103 524,104 525,106 529,108 532,111 536,111 538,109 542,109 546,106 547,103 549,101 556,100 560,104 560,109 561,111 558,120 555,123 554,127 547,136 546,141 543,144 542,148 534,155 530,155 529,156 497,156 494,154 491,155 488,153 486,153 481,149 477,144 476,141 473,138 472,133 469,130 467,125 464,122 462,118 462,116 460,113 460,106 462,104 462,102 464,100 465,96 470,90 470,88 473,85 474,80 477,77 477,75 480,71 487,65 494,65 495,64 505,65 506,64 511,64 512,63 513,64 525,63 526,64 532,64 536,67 540,65 538,65 532,62 488,62 487,63Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M358,93 356,95 357,104 362,108 361,109 362,108 368,114 368,116 373,117 376,121 377,120 380,122 382,122 384,120 386,121 396,115 397,116 401,115 403,117 402,116 403,115 405,116 405,119 404,120 403,119 405,122 405,124 398,133 398,135 397,136 396,135 397,136 391,143 391,146 387,151 387,153 384,157 388,154 396,142 398,136 405,127 405,125 409,119 408,117 409,116 408,111 403,107 402,108 398,108 395,112 392,114 390,114 387,117 378,117 375,116 371,113 370,110 363,106 363,103 361,99 363,97 365,97 369,101 365,97ZM510,88 511,91 508,93 512,98 511,101 513,102 514,104 515,103 519,108 522,109 525,113 531,116 534,116 533,115 534,114 536,115 542,115 546,113 545,111 549,109 552,106 553,108 556,107 558,109 558,117 560,110 559,109 559,104 556,101 549,102 547,106 542,110 538,110 536,112 532,112 529,109 525,107 524,105 522,105 516,98 516,94 515,93 517,92 519,94 512,88ZM375,71 381,76 385,75 388,72 385,74 383,72ZM338,70 332,74 327,80 322,90 320,92 319,96 316,99 312,106 312,109 310,111 310,120 312,123 312,126 317,131 320,139 322,140 321,141 323,142 323,144 327,150 327,152 335,159 341,161 345,161 347,159 349,160 363,160 364,161 378,160 382,158 378,158 377,159 372,159 371,158 366,159 365,158 361,160 360,159 357,160 356,158 353,159 351,158 346,160 344,160 342,158 339,159 332,154 331,151 327,147 326,144 324,142 324,140 320,136 321,135 319,133 320,132 317,131 318,128 314,124 314,120 311,117 311,113 312,110 314,108 314,105 315,104 314,103 319,99 319,97 321,96 321,92 323,91 322,90 329,82 332,77 335,74 338,73 344,73 345,72 347,73 354,72 355,74 359,74 360,75 368,70 366,71 363,71 362,70 358,70 357,71 343,70 341,71ZM525,64 534,70 538,67 536,68 532,65 526,65ZM487,66 484,68 478,75 478,77 475,80 474,85 471,88 471,90 466,96 465,100 461,106 461,113 465,122 468,125 470,130 473,133 474,138 477,141 480,147 486,152 488,152 491,154 494,153 497,155 529,155 530,154 534,154 540,148 541,148 542,144 545,141 546,136 553,127 554,123 557,119 555,120 551,125 550,128 551,129 547,132 544,136 544,138 541,141 542,143 538,147 537,145 538,148 534,151 528,153 520,153 519,152 511,152 510,151 505,151 504,152 500,151 497,153 490,153 487,152 481,145 482,143 476,138 477,135 472,129 472,127 470,125 469,121 465,119 462,110 463,106 465,104 468,95 473,91 475,88 475,84 479,79 479,77 484,72 484,70 488,67 491,68 493,66 495,66 496,68 500,66 502,66 505,68 506,67 511,67 512,66 516,66 518,65 513,65 512,64 511,65 506,65 505,66 501,66 500,65Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M160,151 156,151 157,153 156,156 160,153ZM42,150 40,153 44,155 45,151ZM160,138 161,142 166,139 166,138 164,137 161,137ZM37,136 35,139 40,143 40,139 41,138ZM576,124 574,125 572,124 571,126 573,127 573,128 571,129 572,130 571,131 568,130 569,133 565,135 560,145 561,144 563,145 565,143 566,140 571,133 572,129ZM166,123 163,124 164,129 165,129 168,125 168,124ZM245,122 238,122 231,126 228,131 228,141 236,150 241,148 233,143 231,140 231,133 237,126 240,125 247,126 251,130 253,136 252,137 252,140 249,144 250,145 252,145 252,143 255,141 256,138 255,132 253,130 253,128 249,124ZM35,122 33,125 35,127 36,130 37,130 37,126 38,124ZM441,111 441,116 443,119 443,121 443,115 445,114 444,111ZM580,110 579,112 577,112 575,118 575,122 578,121 580,115ZM163,110 164,112 167,114 168,111 165,109ZM36,109 34,109 32,111 34,114 35,114 37,111ZM346,108 344,111 342,109 344,107 341,108 340,106 337,109 338,111 335,113 333,113 333,115 335,117 334,118 339,117 340,118 337,119 337,120 342,120 341,119 342,118 346,119 347,118 346,117 347,115 349,114 347,113 347,109ZM418,97 422,102 424,103 426,109 425,111 426,114 425,115 425,119 426,118 427,120 428,120 429,117 429,114 427,110 428,109 426,107 425,103 420,97ZM165,95 164,96 164,99 166,100 168,97ZM35,95 35,96 33,97 34,99 36,100 37,99 37,96ZM300,90 296,98 294,100 295,101 292,103 292,105 290,108 290,111 291,112 290,111 291,108 293,106 292,105 294,103 297,95 298,94 299,95ZM240,84 244,84 248,86 252,91 252,98 251,101 248,104 243,106 237,105 232,101 232,99 230,97 231,96 230,94 232,90 237,85ZM162,82 161,84 164,86 165,82ZM235,82 231,85 228,91 228,100 230,104 238,109 245,109 250,107 255,100 255,94 256,93 255,90 253,88 252,85 248,82 245,81ZM107,76 104,76 102,78 101,77 99,79 96,79 92,81 89,81 88,82 87,81 85,82 82,86 82,90 83,92 88,97 88,127 86,129 84,129 82,132 82,139 85,142 116,142 118,140 119,133 116,129 114,129 112,127 113,123 112,124 111,123 111,121 113,119 113,111 112,110 113,107 111,104 111,101 109,105 109,122 110,121 111,123 109,124 109,130 113,131 115,133 115,137 111,139 109,138 106,138 105,139 104,138 87,138 85,136 85,134 88,131 91,130 91,93 86,89 86,86 89,84 94,84 103,80 107,80 110,83 110,90 111,91 113,89 113,82 112,79 109,78ZM159,58 161,61 162,67 163,67 165,64 169,67 170,69 170,78 173,80 174,83 173,93 175,94 176,102 175,105 173,107 176,110 176,117 172,122 175,125 175,129 173,134 171,136 172,138 172,142 170,148 167,151 168,155 166,160 159,166 150,163 148,161 147,158 147,153 148,152 148,148 152,146 151,143 152,141 152,136 154,134 156,134 155,132 155,123 158,121 156,117 156,110 159,107 157,105 155,100 155,97 158,95 154,90 154,86 153,84 155,81 151,77 150,74 150,71 152,69 156,70 156,69 153,66 153,64 151,61 148,61 150,65 146,69 146,74 150,82 149,85 152,93 152,102 154,105 154,107 153,108 153,113 152,114 153,115 153,119 151,124 151,132 149,136 149,140 144,151 144,156 143,157 144,158 144,162 145,162 148,166 154,169 160,169 164,167 169,162 171,157 171,153 175,146 175,143 176,142 176,136 179,127 178,120 180,117 180,114 179,113 179,94 177,91 178,90 177,89 178,87 177,86 176,78 174,76 174,71 173,70 172,64ZM372,52 383,52 386,54 388,54 390,56 389,55 391,54 386,52ZM339,52 336,52 333,54 331,53 329,55 327,54 328,55 330,54 337,54 339,53ZM49,51 44,52 41,54 35,61 32,61 29,64 27,69 27,72 28,70 31,70 31,68 34,64 39,67 39,63 42,58 45,55 48,55 49,56 49,63 48,66 45,69 46,70 49,69 51,71 51,74 50,77 46,81 47,83 47,89 44,94 45,96 45,104 43,106 43,108 45,110 45,117 43,121 46,123 46,131 44,134 46,134 49,138 49,146 51,147 53,150 54,157 53,160 50,163 47,163 44,166 40,165 35,160 33,155 34,151 31,148 29,144 30,135 28,134 26,129 26,125 29,123 29,122 27,121 25,118 25,110 27,108 25,102 25,97 26,95 29,93 27,87 26,90 25,87 24,87 24,91 22,94 22,120 23,121 22,123 22,127 25,136 25,143 27,149 29,151 29,156 32,162 40,169 47,169 49,167 53,166 57,160 57,151 55,146 53,144 52,136 50,133 50,126 49,125 50,124 48,120 48,112 49,111 48,110 48,94 51,87 51,81 53,79 55,73 55,70 52,66 53,63 53,56ZM406,52 405,54 401,57 404,55 406,58 410,54 412,54 413,56 422,64 421,68 419,69 413,76 415,79 425,68 426,63 424,60 418,55 415,55 413,50ZM488,47 489,48 488,49 489,49 490,46 491,49 533,49 531,48 532,47 542,48 538,46 536,47 535,46 523,46 522,47 515,47 514,46 511,47 509,46 503,46 502,47 501,46 497,46 496,47 491,47 490,46ZM486,46 483,46 477,49 475,49 467,57 465,61 466,61 466,59 469,58 473,53 474,54 478,48 483,46 486,48 485,47ZM562,45 557,47 559,51 563,48 574,58 574,60 565,70 566,74 577,62 578,57 571,50 567,49 565,46Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M563,146 561,145 558,147 551,161 543,168 537,170 506,170 506,172 507,173 539,173 545,171 553,164 554,161 559,154 559,151 561,150 561,148ZM443,114 444,115 444,122 447,128 449,129 451,135 458,145 465,159 472,168 482,173 504,173 504,170 485,170 484,169 478,168 474,165 465,152 458,138 449,124 446,117 444,116 445,115ZM346,107 348,109 348,113 350,114 348,115 347,117 348,118 346,120 342,119 343,120 342,121 337,121 336,119 339,118 336,118 335,119 333,118 334,117 332,115 332,113 337,111 336,109 340,105 341,106 340,108 343,107 344,110ZM419,99 425,110 423,103 422,103ZM569,88 569,89 571,90 570,93 572,95 576,103 577,111 579,111 580,109 578,105 577,99 574,97 575,95 573,94 572,91ZM37,81 36,83 38,86 39,83ZM30,71 28,71 27,76 25,79 25,83 26,84 24,86 26,87 26,89 28,80 31,78ZM326,55 323,58 319,60 318,63 315,65 316,66 315,69 306,79 305,83 301,89 300,95 299,96 298,95 296,101 295,102 294,101 295,102 293,105 294,106 290,112 290,123 291,126 293,128 294,131 297,133 296,134 299,140 314,164 314,166 322,175 331,179 387,179 393,177 401,170 402,167 410,155 413,148 421,136 424,129 428,123 428,121 427,121 426,119 424,121 422,127 409,148 406,155 403,158 403,160 400,164 400,166 396,169 394,172 387,175 381,175 380,176 334,176 324,172 318,166 311,152 307,147 304,140 302,138 295,124 293,122 292,114 295,105 300,98 311,77 315,72 319,64 325,58 330,56 334,56 335,55 341,55 342,56 344,55 348,55 349,56 351,55 385,55 391,57 396,61 396,64 389,71 389,72 383,77 381,77 377,73 372,70 369,70 360,76 359,75 355,75 353,73 351,73 349,75 346,74 343,74 342,75 341,74 338,74 335,75 326,86 324,91 322,93 322,97 320,98 318,102 315,103 316,104 315,105 315,108 313,110 313,118 315,119 315,123 322,132 322,137 325,140 325,142 334,155 338,156 339,158 342,157 345,159 353,156 356,157 357,156 363,156 364,155 366,156 366,158 369,158 370,157 372,158 376,158 379,157 386,152 386,150 390,146 390,143 394,139 395,135 400,130 400,126 396,122 394,122 392,120 390,120 390,121 386,124 385,122 380,123 377,121 376,122 373,120 374,119 371,117 369,118 367,116 367,114 365,112 364,113 362,109 361,110 359,109 360,107 356,105 356,102 355,103 354,102 354,99 355,98 354,94 357,92 362,94 382,111 386,111 412,83 414,80 413,77 411,78 394,98 385,107 381,106 374,99 365,92 360,87 360,85 370,74 375,77 381,83 383,83 405,59 405,57 404,56 402,58 399,59 393,55 390,55 389,56 383,53 372,53 371,52 368,53 340,52 340,53 337,55 330,55 329,56ZM557,49 555,51 556,52 555,53 553,52 550,53 547,52 544,49 532,48 534,49 535,48 536,50 542,51 548,56 544,63 535,71 524,64 521,64 519,66 515,67 513,69 511,68 509,70 507,70 506,68 503,69 501,67 500,67 499,69 496,69 495,67 493,67 491,69 490,68 487,69 480,77 480,79 476,84 477,88 469,95 469,97 467,99 467,102 464,107 465,108 464,109 464,113 465,115 467,116 466,117 468,120 471,122 471,125 473,127 473,129 479,137 478,139 482,141 483,143 482,145 488,151 491,152 497,152 499,150 502,151 505,150 511,150 512,151 523,151 524,152 528,152 530,150 534,150 537,148 536,145 541,143 540,141 543,138 543,136 546,132 545,130 547,127 549,128 550,125 554,121 553,119 555,118 554,115 553,116 551,114 545,114 541,117 538,117 537,116 536,117 530,117 528,115 525,114 522,110 520,110 516,105 514,105 513,103 512,103 513,104 511,105 509,103 511,98 508,94 507,96 505,93 505,86 506,85 511,86 535,106 541,103 554,87 563,78 565,75 565,72 564,71 560,76 558,77 546,92 537,101 534,101 530,98 512,81 512,79 521,69 524,69 529,73 530,75 535,78 542,69 558,52ZM487,47 485,48 483,47 478,49 476,53 475,52 469,59 467,59 467,61 465,62 463,65 462,70 455,79 456,80 454,85 451,86 450,89 448,91 448,93 446,94 446,98 445,100 442,102 443,103 441,106 441,110 444,110 445,103 447,99 452,92 456,83 464,71 470,59 477,52 482,50 487,50 488,48Z\"/><path fill=\"#a63441\" fill-rule=\"evenodd\" d=\"M165,154 161,154 158,157 156,161 156,164 159,164 164,160 165,158ZM36,154 35,155 37,160 40,163 45,164 44,159 39,154ZM150,149 149,152 149,159 152,161 154,159 154,151 152,149ZM49,149 46,153 46,156 47,159 50,161 52,158 52,153 51,150ZM170,139 166,140 163,143 163,145 161,148 162,150 165,150 170,145 170,141 171,140ZM31,139 31,144 32,146 36,150 39,150 39,146 33,139ZM155,137 153,143 154,146 157,148 159,145 159,140 157,137ZM46,136 44,136 42,139 43,142 43,148 45,148 47,145 47,138ZM172,125 170,125 167,128 165,133 165,136 166,137 169,136 171,134 173,130 173,126ZM28,125 29,128 28,131 32,135 36,136 34,128 31,125ZM158,123 156,127 157,128 157,132 161,135 162,133 162,126ZM43,123 39,126 38,129 39,135 41,135 45,129 45,126ZM173,110 169,113 167,117 167,121 168,122 170,122 174,117 174,111ZM159,110 158,111 158,118 163,122 164,121 164,114ZM42,110 37,114 37,121 39,122 43,117 43,111ZM28,110 27,111 27,117 31,122 33,122 34,121 33,115 31,112ZM158,97 157,98 158,104 163,108 164,107 164,102 160,97ZM42,97 37,101 37,105 36,106 37,108 39,108 43,104 43,98ZM173,95 168,99 168,107 169,108 173,105 174,102 174,96ZM29,95 27,97 27,103 29,107 32,108 33,107 33,100ZM156,84 155,85 156,86 156,90 161,95 163,94 162,87 160,85ZM45,84 43,84 39,87 38,94 41,94 44,91 46,86ZM170,81 169,81 166,85 166,90 168,94 171,92 172,89 172,83ZM31,80 29,83 29,90 30,92 33,94 35,90 35,86 34,83ZM152,71 152,75 153,77 157,81 160,81 161,80 160,79 160,76 156,72ZM48,71 42,74 40,80 41,81 44,81 48,77 48,74 49,73ZM165,66 163,69 163,77 164,79 166,80 169,75 169,72 168,71 168,68ZM35,66 32,72 32,76 33,78 36,80 38,76 38,70ZM154,57 153,58 154,64 158,69 160,68 160,64 158,59ZM46,57 41,63 41,68 43,69 47,63 48,59Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M43,105 39,109 37,109 35,107 36,102 36,103 34,104 34,107 32,109 30,108 27,109 26,111 28,109 31,111 30,110 35,107 37,109 40,110 37,113 41,109 43,110 40,108ZM168,108 167,107 167,101 167,102 165,103 165,107 163,109 158,105 162,109 164,109 166,107Z\"/><path fill=\"#1f9c4f\" fill-rule=\"evenodd\" d=\"M544,71 539,77 540,79 543,77 545,79 546,83 545,84 542,82 542,84 544,83 546,84 547,87 554,80 553,80 552,78 550,78 550,79 548,80 545,77 546,76 545,77 544,75 546,74ZM404,64 398,69 388,82 382,86 382,90 383,92 379,98 378,96 377,96 377,99 382,104 385,105 413,73 412,71 408,70 405,67 406,66 405,66Z\"/><path fill=\"#3dae58\" fill-rule=\"evenodd\" d=\"M541,84 542,81 545,83 543,85ZM370,77 363,84 362,87 372,95 381,104 376,99 376,96 378,95 379,97 380,94 382,92 381,90 381,85 372,77ZM522,71 514,79 514,81 535,100 536,100 547,88 546,87 547,86 544,84 545,81 543,78 540,80 538,77 539,76 534,80 526,73ZM410,56 402,65 404,63 405,65 407,66 406,67 408,69 410,69 414,72 420,66 420,64 415,59ZM563,50 562,50 555,57 544,70 545,72 547,73 545,76 548,79 549,79 550,77 552,77 553,79 555,79 563,69 571,61 572,58Z\"/><path fill=\"#255255\" fill-rule=\"evenodd\" d=\"M561,82 559,84 561,86 561,88 563,85Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M365,156 363,157 357,157 357,159 359,158 361,159 362,157 364,158ZM255,142 253,143 252,146 250,146 248,144 249,143 246,146 241,147 242,148 240,150 238,150 246,150 251,147ZM165,140 162,143 160,142 160,140 160,147 157,150 153,147 153,145 152,147 155,150 160,150 161,144ZM391,119 394,121 396,121 401,126 401,128 404,124 403,121 404,116 402,117 401,116 398,117 396,116ZM165,114 165,122 167,123 166,122 166,116 167,115ZM546,111 547,113 551,113 553,115 554,114 556,118 554,119 557,118 557,109 556,108 553,109 552,107 549,110ZM418,91 416,94 417,94 418,96 420,96 425,102ZM113,90 111,92 109,91 109,99 110,100 109,101 109,104 111,100 113,106ZM509,86 506,86 506,93 507,95 507,90 508,89 510,90 510,91 510,90 507,88 508,87 511,87ZM41,74 40,74 38,79 41,84 38,87 36,86 36,88 44,82 46,83 45,81 41,83 39,81 39,78ZM157,70 161,75 162,78 162,81 160,84 162,81 165,81 166,83 169,79 172,80 169,78 166,81 164,81 162,78 162,75 160,74ZM148,55 148,60 151,60 152,62 152,57 154,55 159,59 158,58 160,57 165,60 159,53 155,51 150,52Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M228,129 231,125 238,121 245,121 249,123 254,128 256,134 256,131 252,125 245,121 234,122ZM252,84 246,80 238,80 232,83 227,89 227,92 226,93 227,94 227,99 227,91 230,85 235,81 245,80ZM334,52 333,51 332,52 329,52 323,54 316,60 313,66 316,61 321,56 324,55 326,53ZM44,51 42,52 36,59 32,59 29,62 28,65 32,60 35,60 37,57ZM579,57 579,60 575,65 578,62 579,57 565,44 560,44 556,46 556,47 551,51 540,45 482,45 479,46 477,48 473,49 469,53 464,60 461,67 457,72 455,78 452,81 448,88 455,78 458,71 461,68 466,57 475,48 477,48 483,45 486,45 487,46 490,45 491,46 496,46 497,45 501,45 502,46 503,45 539,45 545,49 547,49 549,51 552,51 556,48 558,45 560,44 565,44 567,48 571,49Z\"/>",
	M: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M227,152 226,153 226,171 227,172 228,171 237,170 239,168 239,160ZM293,130 291,132 288,131 287,132 280,132 274,134 271,134 270,133 268,135 260,135 260,140 259,141 260,145 259,146 259,150 258,152 254,155 254,187 255,188 268,186 269,185 274,185 275,184 279,184 285,182 289,182 291,180 291,148 296,142 296,132ZM288,83 286,80 280,80 277,82 273,82 271,81 267,84 260,84 259,85 251,86 251,93 252,94 250,100 247,103 247,105 251,105 252,103 256,104 257,102 258,104 259,103 264,103 268,100 274,101 276,99 278,100 279,99 282,99 282,97 287,91ZM339,65 328,73 325,74 322,77 338,101 341,104 342,107 351,120 350,124 347,127 323,163 323,166 338,176 341,175 376,122 376,119 354,87 353,84ZM506,20 503,20 502,19 499,19 498,20 497,28 495,32 495,35 493,39 493,42 490,50 489,57 487,61 484,76 482,79 482,83 480,87 477,102 473,113 473,117 471,120 468,136 462,154 462,158 458,169 457,177 455,181 455,184 453,188 451,199 449,203 449,207 447,210 447,213 445,218 445,220 448,222 453,223 455,219 455,216 458,208 462,189 464,185 464,182 467,174 468,167 470,163 472,152 476,141 479,126 481,122 483,111 486,104 491,81 493,77 493,74 495,70 498,55 500,51 503,37 505,33 505,30 507,25 507,21Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M101,132 93,133 89,138 89,140 86,143 85,146 89,146 91,145 90,143 95,137 98,136 98,134 101,133ZM39,131 40,134 45,140 48,146 53,146 53,144 49,138 44,133ZM296,115 293,114 292,112 289,115 286,115 285,116 284,115 277,115 276,117 273,117 268,121 264,121 263,122 262,120 260,121 260,124 259,125 259,140 259,135 260,134 268,134 270,132 271,133 274,133 275,132 287,131 288,130 291,131 293,129 296,131ZM283,97 282,100 279,100 278,101 276,100 274,102 268,101 264,104 259,104 258,105 257,103 256,105 252,104 251,106 248,106 255,107 259,105 263,105 265,103 269,103 270,102 273,103 279,100 282,101 284,100ZM283,68 281,65 279,64 278,65 271,65 270,66 262,66 258,70 246,71 245,72 247,75 250,86 254,84 267,83 271,80 273,81 277,81 280,79 286,79 288,82Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M291,189 285,189 284,190 274,191 269,193 259,194 257,197 259,198 275,198 281,196 288,190ZM475,186 479,191 484,195 489,196 501,204 509,204 510,205 512,205 514,203 522,205 525,204 527,201 530,202 533,199 538,199 540,197 541,198 545,198 550,193 551,194 554,193 554,191 553,192 548,192 547,193 542,193 541,194 522,197 517,199 503,200 494,196 478,186ZM114,181 105,185 99,189 96,189 95,190 41,190 39,188 31,184 29,185 30,184 32,186 31,187 35,188 38,191 40,190 43,193 46,194 59,194 61,196 63,196 69,193 71,195 75,195 76,194 85,194 88,195 89,194 98,193 102,190 107,189 113,184ZM218,177 218,179 224,183 227,183 228,182 234,184 233,182 234,178 233,177 227,179 221,179ZM76,139 81,137 82,138 82,137 80,136 79,137 78,136ZM107,130 106,131 101,131 102,133 99,134 99,136 94,139 91,143 92,144 91,146 89,147 85,147 84,146 85,144 78,153 80,151 81,152 92,152 87,152 86,150 88,148 96,144 99,140 101,140 106,134ZM29,125 29,127 36,134 36,135 40,138 39,140 42,141 44,143 45,146 47,146 50,148 50,151 48,152 58,151 61,154 56,149 54,145 53,147 48,147 46,145 42,137 39,134 38,132 39,130ZM400,113 401,116 407,122 413,124 421,130 428,131 429,132 428,133 431,134 434,134 436,132 439,131 442,131 443,132 444,131 448,131 450,129 454,130 459,127 463,129 464,128 467,128 468,131 469,122 471,119 469,121 465,121 464,122 460,122 459,123 455,123 449,125 444,125 438,127 425,127ZM267,53 259,53 254,55 249,55 248,56 229,59 221,62 219,64 217,70 217,75 218,76 218,80 220,86 218,88 211,89 208,93 208,120 210,125 213,129 213,165 222,171 226,172 225,171 225,152 226,151 230,152 238,157 241,160 241,168 239,170 241,172 241,182 253,189 255,189 253,187 253,155 258,149 258,125 259,124 259,121 262,119 263,121 264,120 268,120 271,117 276,116 277,114 284,114 285,115 286,114 289,114 292,111 293,113 296,114 292,106 288,101 284,98 284,96 286,94 284,96 285,100 282,102 279,101 273,104 271,103 269,104 265,104 263,106 259,106 255,108 248,107 245,104 248,101 250,96 250,87 247,81 246,75 244,72 246,70 258,69 262,65 270,65 271,64 278,64 279,63 281,64 272,55Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M509,205 511,208 513,206 521,207 521,206 515,204 512,206ZM87,150 87,151 92,151 93,152 96,152 99,154 96,152 94,152 92,150 94,148 98,147 92,147ZM49,148 44,148 43,147 45,150 39,155 32,159 45,151 49,151ZM75,139 77,136 78,137 79,136 81,138 76,140ZM89,137 89,134 85,134 84,135 80,135 78,137 77,136 74,136 73,137 65,138 64,139 56,139 48,135 53,139 52,141 59,151 57,149 58,146 59,147 60,146 64,147 65,146 74,145 78,143 81,143 83,145ZM445,135 444,133 439,132 436,133 433,136 439,133Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M93,150 98,152 102,155 99,152 100,150 98,148ZM44,150 42,148 39,149 40,152 37,155ZM82,145 81,144 78,144 74,146 65,147 64,148 62,147 59,148 58,147 58,149 61,153 63,150 66,151 67,150 70,150 73,148 79,150ZM202,136 204,138 203,141 206,141 206,137ZM446,136 439,134 436,135 433,139 434,141 434,139 436,137 442,136 446,138 445,137Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M512,217 514,215 516,216 517,214 518,216 521,218 518,220 517,218 514,218 513,219ZM519,212 516,212 516,213 512,216 511,219 510,217 511,219 511,227 514,231 518,231 521,227 521,221 522,219 520,217 521,216 519,215 520,214 517,213ZM468,198 463,198 460,204 460,207 461,208 465,209 469,206 470,200ZM564,198 562,200 562,205 566,208 571,208 573,205 572,200 570,198 567,197ZM296,171 293,171 293,181 289,184 286,184 287,187 291,187 296,183ZM484,159 485,162 482,163 481,162ZM101,152 103,155 110,159 112,159 123,168 117,173 116,175 114,174 113,176 111,176 112,178 110,181 115,178 116,175 117,177 125,172 126,170 126,166 124,163 116,158 114,158 105,152 102,153ZM208,147 208,167 212,171 222,177 221,176 223,173 220,172 211,165 211,147ZM571,150 572,154 576,157 590,157 595,154 595,149 592,147 589,147 588,146 574,147 572,148ZM439,142 442,143 442,146 440,148 436,146ZM442,138 437,139 435,142 434,150 435,151 435,155 438,158 442,158 445,154 445,141ZM298,135 298,140 301,140 301,135ZM392,125 390,124 387,125 383,129 383,134 385,136 390,136 393,133 394,128ZM116,111 113,111 113,120 110,125 109,124 107,126 106,125 106,127 108,128 106,129 111,127 116,121ZM530,105 517,105 512,107 507,107 503,109 498,109 497,110 492,110 491,111 485,111 485,114 484,115 484,118 483,119 483,122 481,126 480,132 481,131 482,133 486,133 491,141 497,141 500,139 504,139 510,135 516,135 521,132 524,132 527,130 535,131 539,129 540,130 543,128 546,128 549,126 556,127 559,130 559,178 558,181 554,185 549,186 547,188 544,187 543,188 538,188 537,189 530,190 529,192 528,191 523,191 522,192 518,192 513,194 507,194 500,188 500,180 498,178 499,175 496,175 495,174 495,159 493,155 493,151 491,149 490,149 491,150 490,151 487,151 486,150 484,153 481,151 479,151 477,153 475,151 473,156 473,158 474,156 475,157 475,161 474,162 475,163 474,164 471,163 471,166 469,171 469,174 471,179 477,184 482,186 494,194 503,198 512,198 513,197 521,196 522,195 527,195 528,194 533,194 534,193 547,191 548,190 553,190 556,189 562,183 563,180 563,129 562,126 555,118 549,116 544,112 542,112 540,110 538,110 535,107 533,107ZM571,95 567,95 562,99 562,103 565,106 567,106 572,103 573,98ZM292,91 287,94 286,98 295,108 298,116 298,125 301,125 302,124 301,122 302,120 301,119 301,113 299,111 299,108 297,104 291,97ZM187,83 184,84 175,92 167,97 159,104 152,108 149,112 142,116 140,118 139,121 142,126 150,132 153,133 162,141 164,141 176,151 179,152 184,157 186,158 191,158 193,155 193,143 195,141 200,140 201,137 191,137 189,138 189,153 187,155 183,151 175,146 171,142 143,121 148,116 161,107 165,103 176,96 187,87 189,89 189,93 190,94 189,95 189,104 190,105 198,105 197,104 199,102 200,104 202,99 200,102 197,102 193,98 193,86 190,83ZM361,78 362,82 366,84 381,84 385,81 385,78 382,74 365,74 362,76ZM392,70 393,101 394,102 394,105 396,108 401,112 406,114 418,122 427,126 435,126 436,125 440,125 446,123 451,123 460,120 466,120 469,119 471,117 470,115 469,116 465,116 464,117 456,118 455,119 450,119 444,121 431,122 429,123 420,119 415,115 413,115 408,111 403,109 399,106 396,100 396,87 393,87 392,86ZM22,70 22,108 24,107 25,108 25,70ZM337,60 334,63 329,65 328,67 320,71 318,73 317,78 322,85 322,87 328,95 329,94 330,95 332,94 325,85 320,76 334,66 340,63 342,66 344,67 344,69 349,75 352,81 355,84 356,87 365,99 366,102 369,105 374,114 379,120 379,122 375,126 363,144 362,147 359,150 358,153 343,174 343,176 340,178 338,178 330,172 324,169 320,164 323,161 349,122 349,120 337,102 335,103 333,100 329,97 332,100 332,102 336,106 339,112 344,118 345,121 343,125 340,128 336,136 333,139 327,149 324,152 323,155 318,161 317,167 318,169 330,176 334,180 338,182 341,182 345,179 349,172 349,170 351,169 353,165 356,162 367,143 375,134 382,123 382,119 377,111 374,108 368,97 364,93 362,88 359,85 359,83 355,79 348,67 342,60ZM255,51 256,50 259,50 260,51 259,52 256,52ZM293,82 292,81 291,73 285,61 279,54 270,48 258,48 257,49 253,49 244,52 238,52 237,53 232,53 227,55 222,55 214,62 212,66 212,69 214,65 222,59 225,58 236,57 241,55 246,55 251,53 260,52 261,49 262,50 265,50 266,49 269,51 268,52 273,54 280,60 284,66 287,73 288,71 291,76 290,77 291,79 290,81ZM113,62 108,58 101,55 85,45 82,45 81,44 73,44 72,45 68,45 62,47 56,47 55,48 41,50 38,52 37,51 35,53 29,53 27,54 22,60 22,68 25,68 25,66 23,64 24,62 26,61 29,57 33,55 44,54 45,51 57,47 64,47 65,49 68,49 69,48 72,48 69,47 74,45 80,45 81,47 83,46 86,48 88,48 93,54 100,57 101,59 106,58ZM487,55 482,48 480,48 478,46 473,44 468,40 452,32 450,33 447,32 446,33 438,33 435,35 430,35 425,37 420,37 411,40 404,40 398,42 393,48 393,67 396,67 396,50 401,45 407,43 412,43 413,42 417,42 422,40 431,39 432,38 442,37 443,36 453,36 456,37 461,41 478,50 483,56 484,65 485,65ZM495,22 489,23 486,27 486,31 489,34 492,34 493,33 496,24ZM385,22 383,24 383,29 388,34 391,34 395,29 394,26 389,22ZM437,12 439,10 444,10 445,11 444,13 438,13ZM443,0 437,0 435,3 434,18 435,21 439,25 442,24 445,21 446,9Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M521,217 520,218 518,217 517,215 516,217 514,216 513,218 514,217 517,217 518,219 519,219ZM111,178 109,177 97,184 80,185 80,188 96,188 104,185 107,183ZM222,176 223,177 234,176 236,178 236,184 239,187 251,194 255,194 256,193 260,193 265,191 270,191 271,190 280,189 286,187 286,185 284,184 283,185 278,185 277,186 273,186 272,187 259,189 258,190 251,190 247,187 242,185 239,182 239,172 238,171 233,173 223,174ZM14,165 14,170 17,173 20,172 21,173 20,175 22,177 24,177 29,181 40,187 43,187 44,188 73,188 73,185 49,185 48,184 42,184 36,180 34,180 17,169 17,167 19,165 25,162 30,158 35,156 37,153 33,153 31,154 30,156 28,156 27,159 22,160ZM78,150 73,149 71,151 67,151 66,152 64,151 62,152 62,154 65,157 67,161 70,162ZM441,143 439,143 437,146 440,147 441,146ZM301,141 298,141 297,144 293,148 293,170 296,170 296,150 300,146ZM298,126 298,134 301,134 301,126ZM22,109 23,116 27,121 41,129 46,133 57,138 63,138 72,135 77,135 78,134 82,134 88,132 104,130 107,128 106,128 105,126 101,126 100,127 96,127 90,129 85,129 84,130 75,131 74,132 66,133 65,134 56,134 30,119 27,116 25,109 24,108ZM330,94 329,96 330,96 334,101 336,102 335,98ZM512,91 513,90 515,93 513,94ZM515,73 511,79 511,89 513,95 514,96 517,96 520,93 521,83 522,82 521,81 521,77 520,75 517,73ZM288,72 287,74 289,79 289,91 288,92 292,90 292,86 291,85 292,82 289,81 290,80 289,78 290,76ZM393,68 393,86 396,86 396,68ZM218,63 214,66 213,68 213,84 207,86 208,88 205,90 203,93 203,100 201,103 201,105 203,107 202,110 202,113 203,114 203,122 208,132 208,136 207,137 208,140 208,146 211,146 211,130 206,120 206,93 211,87 217,86 218,85 216,79 216,67ZM104,59 103,60 106,61 111,66 113,72 113,110 116,110 116,69 112,62 106,59ZM64,48 57,48 53,50 47,51 45,52 45,53 48,52 49,53 50,52 58,51 59,50 64,50ZM70,47 73,48 75,47 84,48 86,50 88,50 89,52 92,51 94,53 92,51 90,52 88,49 86,49 83,47 81,48 80,46Z\"/><path fill=\"#d2263b\" fill-rule=\"evenodd\" d=\"M479,55 473,57 470,57 469,58 457,59 445,63 434,64 431,66 428,72 427,92 426,93 427,96 427,107 428,108 427,119 428,120 444,119 445,118 454,117 455,116 463,115 468,113 471,113 472,114 473,106 475,102 475,99 477,95 477,91 482,76 481,74 481,57Z\"/><path fill=\"#e73d4e\" fill-rule=\"evenodd\" d=\"M453,38 437,39 436,40 427,41 422,43 403,46 398,50 398,100 399,103 405,108 410,110 426,120 427,120 426,119 427,108 426,107 426,96 425,93 426,92 427,72 430,66 434,63 445,62 457,58 469,57 478,54 481,56 477,52Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M187,89 146,120 146,122 183,149 187,153 188,152 188,137 190,135 205,135 206,134 206,131 201,121 202,120 201,119 201,107 200,106 189,106 188,105 188,90Z\"/><path fill=\"#007d43\" fill-rule=\"evenodd\" d=\"M98,90 81,90 74,86 74,91 71,94 68,94 67,95 64,94 67,99 64,103 62,100 62,108 64,110 68,110 71,107 72,108 72,113 71,115 69,116 66,114 66,124 66,121 67,120 68,121 68,125 70,127 75,127 76,120 74,119 79,116 82,116 79,115 76,111 76,107 77,106 81,106 84,108 87,108 90,112 94,112 95,111 96,114 99,113 98,110 95,109 95,108 98,106Z\"/><path fill=\"#1f9c4f\" fill-rule=\"evenodd\" d=\"M46,154 53,163 54,163 61,170 65,170 69,173 74,172 80,168 81,166 85,164 87,161 87,158 91,154 93,154 92,153 88,153 88,154 86,155 85,158 82,160 81,163 77,167 73,169 65,168 64,167 65,165 64,166 60,166 57,162 51,157 52,156 51,153 47,153ZM99,110 100,109 107,109 108,110 102,112ZM98,89 99,90 99,106 97,107 96,109 98,109 100,113 98,115 96,115 95,112 94,113 90,113 87,109 84,109 81,107 77,107 77,111 78,113 83,116 75,119 77,120 77,124 75,128 70,128 67,125 67,121 67,124 66,125 65,124 65,114 66,113 70,115 71,113 71,108 68,111 64,111 61,108 61,100 62,99 64,102 66,99 64,95 68,93 71,93 73,91 73,86 74,85 81,89ZM28,62 27,64 27,112 31,117 47,127 57,132 64,132 68,130 69,131 70,130 74,130 80,128 85,128 86,127 91,127 96,125 101,125 107,123 110,120 111,118 111,70 109,67 103,67 102,68 94,69 90,71 79,72 78,73 64,75 58,80 54,75 45,69 40,67 31,61Z\"/><path fill=\"#3dae58\" fill-rule=\"evenodd\" d=\"M19,168 31,176 33,176 36,179 46,183 94,183 100,181 102,179 107,177 113,172 120,169 119,166 114,164 102,156 96,153 93,153 94,154 91,155 88,158 88,161 85,165 81,167 81,168 76,172 69,174 65,171 61,171 54,164 53,164 45,154 47,152 43,153 41,155 22,165ZM110,67 104,62 99,60 94,56 92,56 87,52 85,52 83,50 80,49 75,49 74,50 70,50 64,52 59,52 50,55 43,55 42,56 31,58 27,62 27,63 29,60 35,62 40,66 45,68 54,74 58,79 62,75 68,73 73,73 79,71 85,71 86,70 90,70 94,68 102,67 103,66 109,66Z\"/><path fill=\"#255255\" fill-rule=\"evenodd\" d=\"M52,157 55,159 60,165 64,165 65,167 73,168 77,166 80,163 81,160 84,158 85,155 87,154 87,153 81,153 80,152 72,161 70,165 67,165 66,164 67,163 58,152 52,153 53,155Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M520,209 514,208 511,211 510,216 512,213 515,212 517,210 519,210 521,213ZM497,161 499,164 499,167 500,168 499,170 496,167 496,162ZM543,149 544,148 545,149 545,146 546,145 548,148 549,147 552,148 554,151 554,153 553,154 548,154 547,151 545,154ZM189,137 191,136 201,136 202,137 201,140 198,141 202,141 203,140 203,138 201,136 190,136ZM556,128 549,127 546,129 543,129 540,131 539,130 535,132 527,131 524,133 521,133 516,136 510,136 504,140 500,140 497,142 491,142 486,134 482,134 481,132 479,133 479,136 477,140 477,144 475,150 477,152 479,150 481,150 484,152 486,149 487,150 490,150 489,149 491,148 494,151 494,155 496,159 496,174 499,174 500,175 499,178 501,180 501,188 505,192 507,193 513,193 514,192 522,191 523,190 528,190 529,191 530,189 533,189 538,187 543,187 544,186 547,187 549,185 554,184 557,181 558,178 558,130Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M510,210 508,211 507,213 504,214 502,217 502,221 507,231 512,231 513,230 510,227 510,224 509,223 509,211ZM521,209 523,215 523,222 522,223 522,228 519,230 520,231 524,231 523,230 529,222 529,218 530,217 528,213ZM565,196 569,196 574,201 574,205 573,207 569,210 565,209 561,205 560,202 561,199ZM563,194 561,196 560,199 561,206 564,210 562,211 565,209 566,210 573,211 574,210 573,208 575,204 574,203 574,198 575,196 569,195 568,194ZM464,192 462,197 463,196 468,196 471,200 471,204 470,206 465,210 461,209 459,207 459,209 460,210 461,209 463,210 469,209 470,210 471,209 470,207 472,204 474,203 474,201 470,195ZM360,157 350,171 346,179 341,183 338,183 334,181 330,177 327,176 324,173 317,169 317,168 321,173 323,173 327,177 328,176 329,178 338,183 341,183 347,178 348,175 351,172ZM545,153 547,150 549,152 547,154ZM34,151 29,153 23,158 16,161 14,163 13,166 17,161 20,160 27,155 29,155ZM99,148 104,151 106,151 109,154 124,162 127,166 127,170 125,173 127,170 127,166 122,160 120,160 117,157 115,157 108,152 104,151 102,149ZM546,146 546,149 545,150 544,149 546,154 545,155 547,157 545,155 547,154 550,157 547,154 548,153 553,153 553,151 552,149 549,148 548,149ZM570,149 573,146 577,146 578,145 582,145 584,144 589,146 593,146 596,149 596,154 593,157 588,159 585,158 576,158 570,153ZM580,137 578,138 575,142 577,141 578,143 571,146 570,151 568,152 568,154 574,162 573,163 576,164 578,166 581,165 582,166 591,165 593,164 592,159 595,157 597,158 599,155 599,147 597,145 596,146 595,145 596,143 594,143 591,139 585,137ZM446,137 447,138 446,140 446,143 447,144 446,155 442,159 438,159 436,158 434,155 434,152 433,151 433,142 432,141 433,140 432,138 431,140 429,140 430,142 426,147 427,154 429,157 430,155 431,157 433,157 434,159 438,162 436,163 441,164 440,162 441,161 446,160 451,156 451,151 454,148 454,145 452,143 452,141ZM148,131 163,142 164,144 167,146 169,146 171,149 179,154 184,159 188,160 189,159 192,159 194,157 194,143 194,155 191,159 186,159 179,153 176,152 164,142 162,142 153,134 150,133ZM390,123 394,126 395,131 390,137 385,137 382,134 382,129 387,124ZM397,126 395,126 393,124 394,123 391,124 390,121 388,121 390,122 389,123 386,123 385,124 383,122 383,120 383,123 381,127 368,143 361,155 362,155 362,153 368,146 371,140 378,132 379,132 383,137 386,138 389,138 393,136 394,137 395,136 394,133 396,130ZM570,93 574,97 574,102 569,107 565,107 561,104 561,99 565,95ZM566,92 567,91 571,91 572,92 571,93 567,93ZM569,89 566,90 562,96 561,95 560,96 561,99 559,101 561,103 560,107 561,108 566,107 567,108 566,109 568,110 570,109 569,107 571,105 573,106 572,105 575,101 575,97 576,96 575,97 573,94 574,92ZM194,85 191,82 183,83 180,87 175,89 172,93 169,94 159,103 157,103 145,113 140,116 138,119 140,125 146,130 140,125 138,121 139,118 146,112 149,111 152,107 159,103 167,96 175,91 184,83 190,82 194,86 194,98ZM514,72 518,72 522,75 522,78 523,79 523,90 522,91 522,94 517,98 514,98 511,95 510,88 509,87 510,77ZM520,72 522,71 524,73 522,74ZM504,76 502,80 502,88 503,89 503,92 506,95 509,95 510,97 509,98 507,97 509,98 510,97 514,101 513,104 511,106 508,106 512,106 517,104 530,104 552,116 549,115 545,111 543,111 541,109 533,105 524,102 525,101 524,99 527,96 530,90 530,80 525,72 520,69 513,68 511,69 511,70 514,69 515,70 512,72 509,71 510,72 508,74 507,73ZM380,66 366,65 362,69 363,70 362,72 358,76 356,76 349,68 346,63 342,59 339,59 338,58 329,64 325,68 323,68 316,74 316,79 320,84 320,86 324,90 325,93 330,99 332,104 343,119 343,122 340,125 340,127 334,135 333,138 331,139 331,141 326,146 326,148 316,162 316,166 317,161 322,155 323,152 326,149 332,139 335,136 336,133 344,121 343,118 338,112 335,106 331,102 331,100 321,87 321,85 316,78 317,73 320,70 328,66 329,64 334,62 337,59 342,59 349,67 354,76 358,80 360,80 360,77 364,73 375,73 376,72 377,73 382,73 386,77 386,82 380,86 373,86 372,85 368,86 367,85 361,84 365,91 365,93 368,96 369,93 368,94 367,91 369,89 371,89 373,92 374,90 377,89 378,90 382,88 386,83 388,82 387,79 388,77 387,75 382,71 382,68ZM291,72 287,62 280,53 274,49 272,49 270,47 263,46 262,47 246,49 242,51 238,51 237,52 232,52 231,53 226,53 224,54 227,54 232,52 237,52 238,51 244,51 245,50 248,50 253,48 257,48 258,47 270,47 272,49 274,49 283,57 286,61ZM22,58 22,59 24,56 29,52 35,52 37,50 38,51 41,49 45,49 46,48 50,48 56,46 62,46 63,45 67,45 73,43 81,43 89,46 101,54 111,59 116,65 116,67 116,65 112,59 109,58 107,56 105,56 97,50 83,43 70,43 69,44 65,44 64,45 60,45 59,46 55,46 49,48 44,48 32,52 28,52 26,53ZM456,33 461,35 463,37 468,39 473,43 481,47 475,44 472,41 470,41 469,39 466,37ZM484,29 486,33 484,36 482,34 482,31ZM495,20 493,19 486,23 485,22 484,23 484,29 483,30 481,28 482,34 484,36 486,33 489,35 491,38 493,34 492,35 489,35 485,31 485,27 487,24 491,21 495,21 496,22ZM385,19 389,19 390,20 389,21 386,21 391,22 395,26 396,29 391,35 388,35 382,29 382,26 382,29 383,30 380,34 381,34 382,36 383,36 385,33 387,36 390,36 396,32 397,34 395,31 396,29 397,30 398,29 396,28 397,27 397,24 395,22 393,24 392,22 390,22 389,21 391,19 390,18ZM449,0 445,0 446,2 446,6 447,7 447,13 446,14 447,17 446,18 446,22 444,24 438,26 433,19 433,5 435,2 435,0 430,0 430,2 426,7 426,9 429,11 429,14 427,15 427,16 434,22 435,24 434,25 435,26 435,31 432,34 429,34 425,36 419,36 418,37 414,37 413,38 406,39 411,39 415,37 425,36 433,33 434,34 438,32 445,32 446,31 448,32 451,31 447,30 446,29 447,27 446,26 447,24 452,20 452,17 455,12 453,8 452,10 450,9 451,8 451,4 450,5 449,4Z\"/>",
	N: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M251,152 251,171 253,172 254,171 263,170 265,168 265,160 261,158 258,155ZM320,131 317,133 314,133 313,134 303,132 294,136 285,136 285,148 284,151 279,156 279,187 280,188 293,186 294,185 298,185 299,184 304,184 310,182 314,182 316,180 316,148 321,142 321,132ZM312,78 309,75 306,75 302,80 296,80 295,81 291,81 289,80 287,83 285,83 281,86 278,86 277,88 276,85 277,95 273,104 275,105 277,104 284,104 287,101 289,102 291,100 294,102 294,101 299,97 300,100 301,99 302,100 303,99 307,99 313,88ZM379,65 365,74 363,77 390,117 391,122 364,162 363,165 380,176 416,123 417,120 406,104 405,101 402,98 399,92 396,89 384,71 383,68Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M124,133 119,133 116,136 112,143 119,140 121,137 124,135ZM61,129 61,130 63,131 64,136 66,137 71,143 79,147 79,145 76,142 73,136 68,132ZM321,115 319,113 318,114 314,114 316,116 315,117 308,117 307,118 297,120 295,122 294,122 292,119 291,120 287,120 285,121 285,135 294,135 303,131 306,131 311,133 317,132 320,130 321,131ZM301,100 300,101 299,98 296,100 294,103 291,101 289,103 287,102 284,105 277,105 276,106 272,104 273,102 272,105 273,106 279,106 281,107 282,106 285,106 290,103 299,102ZM288,67 291,65 294,67 291,69ZM270,72 274,80 275,87 276,84 277,87 278,85 281,85 283,83 287,82 289,79 291,80 302,79 306,74 309,74 312,77 306,65 304,65 301,67 295,67 293,64 290,64 289,65 288,64 284,69 283,68 279,68 278,69 275,69 276,71 275,72 273,72 272,71 273,70 271,70Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M314,189 295,192 290,194 284,194 283,195 274,195 268,192 269,195 274,198 276,197 277,198 280,198 282,200 284,200 285,199 289,199 294,196 296,196 297,197 296,198 303,196 305,194 310,193 313,191ZM142,180 136,182 125,189 121,189 120,190 70,190 69,189 63,188 53,182 51,182 51,183 57,190 61,190 67,194 69,193 71,193 73,195 78,195 79,194 86,195 87,194 90,194 93,196 95,194 97,195 98,194 102,194 103,195 105,193 109,193 110,194 116,193 119,194 120,193 128,192 134,189ZM239,175 244,181 249,184 252,184 253,183 255,185 260,184 259,182 259,178 258,177 253,179 248,179 243,177 241,175ZM467,154 468,154 477,164 479,164 485,169 486,168 488,171 489,170 493,173 498,173 499,174 502,174 503,173 506,173 507,174 511,172 521,173 525,170 529,169 530,167 533,168 534,167 541,166 550,161 549,160 548,161 537,162 532,164 526,164 525,165 512,167 507,169 496,169 487,165 482,161 470,155 468,153ZM132,132 131,131 121,132 124,132 125,135 123,136 119,141 112,144 111,142 118,133 108,135 107,136 103,136 100,137 99,139 98,138 97,140 98,141 103,141 106,140 107,138 110,138 111,139 110,144 108,146 107,149 103,153 104,152 115,152 112,152 111,150 116,146 120,146 121,144 130,136ZM55,126 58,128 59,132 63,134 62,138 63,138 68,145 74,150 73,152 84,152 86,154 82,150 80,146 80,147 78,148 76,146 71,144 67,139 63,136 62,131 60,130 61,128 63,129 60,128 58,126ZM293,53 285,53 284,54 273,55 272,56 264,57 259,59 255,59 246,62 244,64 243,71 242,72 245,86 243,88 236,89 233,93 233,120 238,130 238,165 245,170 251,172 250,171 250,152 252,150 257,154 263,157 266,160 266,168 264,170 266,172 266,181 269,184 278,189 281,189 278,187 278,155 281,153 283,150 283,142 284,141 284,121 287,119 291,119 292,118 294,121 295,121 297,119 300,118 303,118 308,116 315,116 313,114 319,112 321,114 315,103 309,98 309,96 312,92 309,96 309,99 306,101 301,101 299,103 290,104 285,107 282,107 281,108 279,107 273,107 271,105 275,96 275,88 274,87 273,80 269,72 270,70 273,69 274,70 273,71 275,71 274,69 279,67 283,67 284,68 283,69 288,63 289,64 290,63 293,63 295,66 301,66 304,64 306,64 297,55Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M515,174 514,173 511,173 507,175 506,174 503,174 505,177 503,178 506,177 508,175 511,175 514,177 513,176ZM112,151 119,151 120,149 125,148 122,147 116,147 114,148ZM64,148 66,148 69,151 68,152 72,152 73,150 69,147ZM72,134 78,141 82,148 84,146 90,146 91,145 94,146 97,144 103,145 105,143 107,143 108,145 110,141 110,139 107,139 106,141 98,142 96,139 98,137 99,138 100,136 102,136 95,137 94,138 90,138 89,139 81,139 74,136Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M502,179 505,180 508,178 509,180 511,177 515,179 515,178 511,176 508,176 506,178ZM63,149 63,150 65,150 66,152 68,151 66,149ZM107,144 105,144 103,146 97,145 94,147 91,146 90,147 84,147 83,149 89,157 86,153 87,151 90,151 91,152 93,150 100,150 103,149 104,150 102,153 106,148ZM231,130 232,131 232,135 230,137 229,136 226,136 229,139 227,141 230,141 232,144 231,141 232,131Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M261,183 265,188 272,191 274,193 280,194 281,191 282,191 283,193 283,190 281,191 280,190 276,190 269,185 266,184 264,182 264,180ZM458,169 460,172 459,174 461,175 460,176 458,176 456,172ZM560,166 555,170 555,172 557,176 561,178 564,178 567,175 567,172 563,167ZM461,166 458,166 455,168 452,172 453,176 455,178 459,178 463,175 464,170ZM538,157 531,158 530,159 526,159 525,160 521,160 520,161 516,161 515,162 511,162 512,163 512,166 513,165 518,165 523,163 528,163 529,162 537,161 538,160 537,159ZM38,166 38,170 42,174 45,175 47,177 68,188 76,188 76,185 67,184 61,181 56,177 54,177 52,175 49,174 43,169 43,167 46,164 57,157 62,155 63,153 58,153 56,155 50,157 46,160 45,162 42,162ZM151,166 148,162 141,159 133,153 126,151 125,153 143,163 147,167 147,169 139,175 134,177 123,184 119,184 118,185 91,185 91,188 122,188 125,187 146,174 148,174 151,170ZM324,146 322,147 321,146 318,148 318,181 316,183 311,184 312,187 318,186 321,183 321,150ZM233,143 233,167 237,171 247,177 252,177 252,174 253,173 252,174 247,173 245,171 240,169 236,165 236,143ZM437,120 442,118 445,118 448,120 446,122 442,122ZM589,119 586,116 579,116 583,121 582,123 580,124 572,124 570,121 569,121 569,123 570,123 572,126 573,125 584,126 588,123ZM431,118 431,123 434,126 449,126 452,125 455,121 454,118 451,116 434,116ZM141,113 139,114 138,113 137,120 133,125 126,126 125,127 121,127 120,128 116,128 111,130 105,130 104,131 96,132 98,133 97,136 103,134 113,133 118,131 123,131 124,130 128,130 129,129 135,128 140,122 141,119ZM557,108 555,109 557,110 557,112 555,114 553,113 553,134 554,131 556,133 557,136 555,138 553,137 553,149 552,151 548,155 542,156 541,157 541,160 550,158 554,155 554,153 556,150 556,141 557,140ZM47,106 47,113 49,118 53,122 55,122 58,125 71,132 73,129 68,127 63,123 55,119 51,114 50,106ZM138,102 138,105 141,105 141,102ZM319,100 319,102 317,104 320,107 321,111 320,109 321,107 323,110 325,111 326,114 325,110ZM404,91 405,92 403,95 402,93 401,93 419,119 419,122 412,131 412,132 413,130 414,131 414,133 411,138 412,138 416,131 421,125 423,120 422,117 417,111 416,108 413,105ZM138,85 138,90 139,91 138,93 141,94 138,95 138,96 141,96 141,92 139,91 141,90 141,85ZM212,83 208,85 202,91 199,92 191,99 165,118 165,123 179,135 182,136 194,145 199,150 205,153 211,158 216,158 218,155 218,142 220,140 222,140 223,137 215,137 215,150 213,155 169,122 169,120 173,116 181,111 190,103 193,102 197,98 201,96 212,87 214,89 214,92 215,93 215,103 216,104 218,101 217,100 218,97 218,85 215,83ZM554,92 547,88 544,85 538,83 528,76 523,74 512,74 503,77 502,76 501,77 491,78 490,79 482,80 481,81 471,82 467,84 464,87 462,91 462,141 464,147 470,153 480,158 479,157 480,155 471,149 467,145 466,142 466,136 465,136 464,138 462,135 464,131 465,133 466,133 466,91 469,87 474,85 484,84 485,83 499,81 504,79 514,78 513,76 515,74 516,75 522,76 523,77 522,78 525,78 530,82 547,91 553,97 553,103 556,103 556,96ZM457,68 459,67 461,69 459,70ZM455,64 453,66 453,70 454,72 457,75 462,74 464,72 462,66 460,64ZM563,63 559,64 555,68 555,72 558,76 562,75 567,69 566,65ZM381,59 377,60 369,66 366,67 357,75 358,79 363,85 367,93 370,96 371,99 385,119 385,122 379,130 378,133 375,136 374,139 370,143 370,145 362,157 360,158 360,160 357,164 358,167 377,181 378,181 375,177 377,176 368,171 365,168 364,169 361,165 361,163 359,162 362,159 363,161 371,148 374,145 379,136 384,130 388,123 385,121 385,118 388,117 379,104 377,105 371,99 370,96 372,94 373,95 366,84 365,86 362,82 363,80 364,81 363,79 362,80 361,79 361,76 365,72 369,70 372,67 375,66 376,63 378,64 381,63 384,67 385,66 389,69 388,70 385,69 391,78 393,77 397,80 393,75 389,67 385,62ZM315,69 312,66 308,58 302,52 294,48 283,48 273,52 270,51 269,52 265,52 260,54 254,54 253,55 246,56 240,61 240,63 238,65 237,68 238,82 236,84 234,84 231,86 228,91 228,95 229,96 228,97 228,100 224,103 222,103 222,105 224,103 227,106 225,102 228,100 228,97 231,95 232,91 236,87 240,87 244,85 241,79 241,67 243,64 243,62 247,59 250,59 255,57 260,57 261,56 266,56 267,55 271,55 272,54 276,54 277,53 281,53 287,51 292,51 295,53 297,53 300,55 308,64 314,77 315,87 318,88 318,79 315,73ZM507,47 507,52 505,53 505,57 507,58 507,63 509,63 511,60 510,60 505,54 511,49 510,49 509,47ZM141,69 140,68 140,65 135,59 131,58 128,55 126,55 123,52 118,50 113,46 107,44 101,44 100,45 97,44 96,45 92,45 91,46 87,46 86,47 67,50 62,52 56,52 52,54 49,57 47,62 47,78 50,78 50,63 51,60 54,57 59,55 69,54 70,53 74,53 75,52 79,52 80,51 84,51 85,50 94,49 95,48 101,48 102,47 109,48 121,56 133,62 136,65 138,70 138,80 141,80Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M77,185 77,188 90,188 90,185ZM311,185 309,184 308,185 304,185 303,186 299,186 298,187 285,189 284,190 284,193 294,191 295,190 309,188 311,187ZM512,180 511,181 506,181 504,185 505,197 507,199 512,199 514,196 514,189 515,186 514,185 514,182ZM254,173 253,174 253,177 254,176 255,177 256,176 260,176 261,177 261,182 264,179 264,172ZM480,157 482,160 486,161 489,164 491,163 492,166 495,166 496,167 507,167 508,166 511,166 511,163 497,164 491,162 490,160 487,159 485,157 484,159 481,155ZM103,150 101,150 97,153 93,153 92,154 89,154 88,153 88,155 93,162 95,162ZM554,132 553,136 555,137 556,135ZM413,131 413,132 411,133 412,134 409,136 407,140 404,143 384,174 380,178 375,176 379,181 382,181 384,178 384,176 386,174 387,175 391,168 391,165 397,160 398,157 401,154 401,151 404,149 405,146 408,144 407,143 410,141 411,139 410,138 413,133 414,134ZM72,132 73,134 75,134 78,137 82,137 83,138 93,137 97,135 97,133 82,134 73,130ZM438,120 441,120 442,121 446,121 447,120 445,119ZM386,118 386,121 389,122 389,119ZM566,119 566,123 569,126 571,126 570,124 568,123 569,120 570,120 572,123 580,123 582,122 578,116 576,117 575,116 570,116ZM321,108 322,110 322,114 323,115 323,142 320,146 321,147 319,148 321,147 322,148 321,147 323,145 325,146 327,141 327,126 325,121 325,116 326,115 324,111 323,111ZM141,106 138,106 138,112 139,113 141,112ZM553,104 553,108 554,109 553,112 555,113 556,110 554,109 556,107 555,105 556,104ZM228,96 229,97 229,100 227,102 227,105 228,106 228,121 230,127 233,131 233,136 232,137 233,139 232,140 233,142 236,142 236,129 233,125 232,119 231,118 231,96 230,97ZM372,93 371,94 372,95 371,97 378,105 377,104 378,102 374,96 371,94ZM315,88 313,93 310,97 313,99 316,103 318,102 318,99 315,98 317,92 317,88 316,89ZM47,79 47,105 50,105 50,79ZM393,78 392,79 399,90 402,92 404,95 403,94 404,92 401,86 400,86 398,84 397,81ZM507,46 509,46 510,48 512,49 506,54 506,55 512,60 509,64 506,63 506,58 504,57 504,53 506,52 506,47ZM511,43 509,43 506,46 504,51 505,63 509,66 513,64 514,62 514,58 515,57 514,55 514,47Z\"/><path fill=\"#a63441\" fill-rule=\"evenodd\" d=\"M70,153 70,154 74,157 74,161 79,163 79,166 85,171 86,170 88,171 89,173 90,172 93,172 95,174 94,175 96,175 98,173 101,173 106,170 115,160 116,156 118,154 118,153 104,153 94,165 84,153Z\"/><path fill=\"#d2263b\" fill-rule=\"evenodd\" d=\"M550,97 546,97 545,98 537,99 536,100 531,100 528,102 522,102 521,104 520,103 516,103 515,104 505,105 500,108 500,110 498,112 498,116 497,117 497,120 498,121 497,122 497,127 496,128 498,133 497,134 497,141 496,142 496,145 497,146 497,151 496,152 497,153 495,157 493,158 496,161 498,162 505,162 506,161 515,160 520,158 525,158 530,156 535,156 536,155 545,154 550,150 551,148 551,99ZM134,67 130,67 129,68 125,68 124,69 117,70 115,72 114,71 111,71 106,73 102,73 101,74 88,76 82,82 80,85 79,91 81,95 81,109 80,110 80,114 82,120 82,129 81,130 83,132 95,131 99,129 106,129 110,127 115,127 116,126 130,124 135,120 136,117 136,70Z\"/><path fill=\"#e73d4e\" fill-rule=\"evenodd\" d=\"M45,167 46,170 50,171 58,177 70,183 120,183 132,177 137,173 142,171 145,168 144,166 134,161 127,156 119,153 117,156 116,160 106,171 101,174 98,174 96,176 94,176 93,173 90,173 89,174 88,172 85,170 84,171 78,166 78,163 75,163 73,161 73,157 70,155 69,153 64,155 59,159 52,162ZM523,80 518,79 517,80 505,81 500,83 495,83 494,84 475,87 468,91 468,143 471,147 484,154 494,161 495,161 492,158 494,157 496,153 495,152 496,151 495,142 496,141 496,134 497,133 495,128 496,127 496,122 497,121 496,120 496,117 499,108 505,104 515,103 516,102 520,102 521,103 522,101 528,101 531,99 536,99 537,98 541,98 546,96 550,96 541,90 536,88 533,85 531,85ZM105,49 100,49 99,50 91,51 90,52 85,52 84,53 79,53 78,54 56,58 52,63 52,110 54,115 60,120 65,122 75,129 82,132 80,130 81,129 81,120 79,114 79,110 80,109 80,95 78,91 78,88 81,82 88,75 101,73 102,72 106,72 111,70 114,70 115,71 117,69 120,69 125,67 129,67 130,66 134,66 135,67 132,64 129,63 124,59Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M212,89 205,95 197,100 193,104 175,116 171,120 171,122 187,133 192,138 203,145 207,149 213,152 213,137 215,135 230,135 231,134 231,131 227,124 227,121 226,120 226,107 225,106 219,107 218,106 215,106 213,104 213,90Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M99,151 93,151 91,153 90,152 87,152 87,153 88,152 89,153 92,153 93,152 97,152ZM228,139 225,136 215,136 214,137 214,150 214,137 215,136 223,136 224,137 223,140 219,142 219,148 219,143 221,141 226,141ZM214,93 214,104 215,105 219,105 220,106 222,102 225,103 226,102 225,103 219,100 219,92 219,97 218,98 219,101 216,105 214,103Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M520,180 519,181 516,179 515,181 516,187 517,188 516,189 516,195 514,199 511,201 508,201 504,198 503,190 502,189 503,181 501,180 497,183 495,187 495,191 498,197 503,203 506,203 507,202 511,205 513,204 511,203 512,202 514,202 515,204 519,200 518,198 521,196 523,191ZM357,166 358,170 379,183 383,182 386,179 394,167 388,176 382,182 377,182 360,170ZM559,163 557,165 554,166 554,172 554,169 557,166 560,165 563,166 568,171 568,175 564,179 561,179 563,181 562,180 568,175 568,171 563,165 561,165ZM462,163 461,164 460,163 458,164 457,166 453,167 453,170 451,172 452,175 451,178 452,179 453,177 454,178 452,176 451,172 453,169 458,165 461,165 464,168 465,173 461,178 457,179 459,180 460,178 462,179 464,176 465,177 465,169 464,168 464,165ZM135,153 136,155 148,161 151,164 152,166 152,170 149,174 152,170 152,165 149,161 145,160 140,156 138,156ZM409,145 405,149 399,160 395,165 398,162 401,156 406,150 406,148 408,147ZM563,120 565,117 569,114 574,114 575,115 577,114 581,114 582,115 586,115 590,119 589,124 585,127 568,127 564,123ZM429,120 430,118 435,114 438,115 439,114 445,114 446,115 447,114 450,114 456,119 455,123 452,126 449,127 434,127 430,123ZM558,117 558,123 562,122 564,124 565,129 567,132 570,134 586,133 590,130 591,127 590,129 589,128 589,125 591,124 593,121 593,119 590,118 589,116 584,112 583,110 584,109 581,107 572,107 570,110 569,108 568,112 565,116 562,117 561,120 560,120ZM458,124 456,118 450,108 446,108 445,107 443,108 438,106 435,107 429,112 429,113 430,111 432,111 433,113 432,115 426,119 425,116 424,118 422,116 423,115 422,116 421,115 423,117 424,120 422,125 416,133 423,125 424,125 425,127 425,126 427,125 430,127 429,128 430,131 435,134 440,134 441,133 448,134 453,131 453,128 455,126 455,124 456,123ZM367,94 374,104 378,112 381,114 384,120 384,122 380,126 372,138 372,140 369,142 368,146 362,153 362,155 357,161 357,163 359,160 359,158 361,157 362,154 369,145 369,143 373,139 374,136 377,133 378,130 384,122 383,117ZM211,82 200,91 197,92 197,93 192,96 191,98 188,99 169,113 164,118 164,123 169,129 176,133 181,138 188,142 189,144 192,145 204,155 206,155 211,159 216,159 219,156 219,149 219,155 216,159 211,159 205,154 199,151 186,140 179,136 164,123 164,118 167,115 176,109 180,105 183,104 199,91 202,90 208,84 212,82 217,83 219,85 219,91 219,85 216,82ZM555,74 555,76 557,76 560,78 563,78 564,77 563,76 564,75 558,77ZM455,63 460,63 463,66 465,70 465,72 460,76 457,76 453,73 452,66ZM555,63 556,66 555,67 559,63 562,62 565,63 568,67 568,69 565,73 568,72 569,67 567,66 570,64 569,63 569,64 567,65 563,61 564,59 561,59 562,61 560,63 557,64ZM456,59 451,63 449,63 451,65 449,67 447,66 446,71 451,77 451,73 452,72 455,76 460,78 462,80 461,81 464,82 463,84 464,86 462,90 463,87 467,83 471,81 475,81 470,81 468,79 468,75 470,73 470,71 466,72 465,71 465,68 463,65 459,62 461,61 458,62 457,61 458,60ZM356,74 357,80 360,83 365,92 366,92 362,85 357,79 356,75 363,68 369,65 379,58 383,59 390,67 394,75 397,78 398,81 420,113 403,88 402,85 399,82 393,71 382,58 378,58 367,66 365,66ZM280,48 283,47 294,47 302,51 308,57 306,54 298,48 295,48 290,46 288,47 281,47ZM88,45 96,44 97,43 99,44 101,43 107,43 113,45 118,49 123,51 127,54 126,52 122,51 114,45 109,43 96,43 95,44ZM509,40 511,40 515,44 515,47 516,48 516,61 512,67 508,67 504,64 503,57 502,56 503,55 502,54 503,53 503,47 504,44ZM504,40 498,51 497,49 496,51 496,60 497,62 499,63 498,64 501,63 502,65 506,67 508,69 507,71 508,72 506,74 505,73 504,75 499,76 507,75 511,73 524,73 525,74 519,71 519,65 525,56 524,55 525,53 521,43 517,41 516,44 515,41 514,42 511,40 508,40 507,41Z\"/>",
	O: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M469,89 464,93 461,99 461,105 462,108 465,111 472,111 474,109 474,95 478,90 484,90 488,94 489,97 489,103 488,104 487,110 480,121 462,139 462,141 463,142 501,142 505,130 504,127 501,127 500,129 495,133 476,133 475,132 480,128 489,123 498,115 503,105 503,99 501,95 495,89 486,86 478,86Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M218,181 218,184 220,183 222,184 237,184 238,183 239,184 264,184 267,182 268,184 271,184 274,182 275,183 278,183 277,181ZM88,181 88,182 91,182 93,185 102,182 106,182 112,184 122,184 125,182 128,184 131,184 132,185 131,186 140,186 138,185 139,184 150,184 151,182 153,183 157,183 158,184 160,183 163,183 164,184 171,184 172,183 174,184 176,183 179,183 180,184 193,184 195,183 194,181Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M291,180 290,181 278,181 279,182 278,184 275,184 274,183 271,185 268,185 267,183 264,185 239,185 238,184 237,185 222,185 221,184 218,185 217,184 217,181 215,181 214,183 212,183 211,181 195,181 196,183 193,185 180,185 179,184 176,184 175,185 173,184 171,185 160,184 158,185 157,184 153,184 151,183 150,185 139,185 141,186 140,187 131,187 130,186 131,185 128,185 125,183 122,185 112,185 111,184 102,183 93,186 91,183 88,183 87,181 78,181 78,182 81,184 80,186 83,188 88,188 90,186 92,186 93,188 101,188 102,189 107,189 108,190 110,190 112,188 118,190 123,187 125,187 126,189 129,187 136,187 137,188 143,187 145,189 149,189 150,190 161,190 162,188 164,189 166,187 172,187 173,188 174,186 176,187 180,187 181,188 180,189 184,188 185,189 193,189 195,190 197,188 200,188 201,187 202,189 212,190 213,189 221,189 224,185 231,185 232,186 231,187 225,187 227,188 225,189 228,188 239,189 241,187 245,187 246,186 248,186 250,188 252,187 255,189 256,186 259,187 263,187 265,186 268,189 272,189 273,190 274,189 283,189 289,187ZM469,149 470,152 476,153 478,155 479,153 483,153 484,155 486,155 487,153 493,152 493,149ZM195,147 196,147 200,142 202,143 204,142 206,139 205,138 195,138 194,139 194,145ZM154,139 157,140 162,144 163,143 164,145 166,145 166,139 165,138 155,138Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M481,97 480,98 480,102 481,104 482,104 482,98Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M156,178 157,177 161,177 162,178 161,179 157,179ZM147,178 148,177 151,177 152,178 151,179 148,179ZM115,178 116,177 119,177 120,178 119,179 116,179ZM543,156 540,156 539,157 539,161 540,161ZM422,157 427,161 428,156 425,155ZM463,144 468,147 468,144ZM421,142 419,145 423,148 423,144 424,142 423,143ZM510,132 507,134 506,133 505,134 504,141 501,144 494,144 494,147 502,147 504,146 507,143 508,136ZM547,128 546,131 547,134 548,134 548,132 550,131 550,129ZM414,129 418,132 419,135 421,129 420,128 418,128 416,130ZM473,124 470,123 467,127 460,133 460,137 469,130ZM535,121 536,122 536,125 534,129 534,137 531,144 532,147 530,149 531,150 528,153 527,159 526,160 527,161 528,168 532,172 534,172 536,174 542,174 544,172 542,171 538,171 536,169 534,169 530,164 530,158 533,152 535,152 535,143 536,140 539,139 539,137 537,135 537,132 538,131 538,128 540,126 540,123 539,122 538,123ZM562,118 559,119 559,122 556,127 558,130 558,135 556,139 553,142 555,144 555,147 558,147 559,145 559,141 560,140 561,132 562,131 561,129ZM416,115 415,116 416,118 418,119 420,116 419,115ZM549,114 547,116 549,120 550,119 550,115ZM205,113 206,115 208,116 211,115 213,117 212,118 213,120 212,123 213,125 214,124 216,127 215,114 212,112 207,112ZM461,110 461,113 464,116 467,117 465,114 466,113ZM418,100 416,101 416,103 418,105 420,104 420,101ZM480,91 476,95 476,102 479,103 479,97 481,95 484,99 483,104 487,104 487,97 485,93 482,91ZM300,91 298,90 298,97 296,100 296,105 297,106 297,117 296,118 297,119 296,120 297,123 297,139 296,140 296,151 297,152 297,155 296,156 296,161 297,163 296,164 296,171 292,175 289,175 288,176 192,176 192,179 292,179 296,177 300,171ZM190,89 172,89 168,94 168,111 165,114 162,112 158,112 157,113 156,112 155,113 153,112 151,113 150,112 147,113 145,116 145,122 147,121 148,122 148,117 150,115 160,114 161,116 167,116 171,114 171,106 170,107 169,106 169,102 171,101 171,97 170,96 172,91 178,93 178,92 181,90 183,92 187,92 189,94 189,104 190,105 192,103 192,94ZM420,87 419,88 421,91 423,88ZM479,82 478,84 487,84 493,86 498,89 504,96 504,99 505,100 505,105 503,111 506,113 508,107 508,97 505,91 497,84 491,83 490,82ZM146,81 147,80 157,80 158,81 157,82 147,82ZM74,81 75,80 79,80 80,81 79,82 75,82ZM243,80 247,80 250,82 274,82 274,81 277,79 278,80 282,80 280,79 277,79 276,80 274,78 252,78 247,80ZM203,79 204,82 226,82 228,80 232,80 232,79 227,79 226,78 207,78 206,79ZM70,81 70,97 69,98 69,101 70,102 70,135 69,136 70,146 69,147 69,150 70,153 72,154 72,156 70,157 72,159 70,160 70,171 71,173 78,179 113,179 114,177 115,179 164,179 163,176 80,176 73,170 73,135 72,134 72,128 71,127 72,111 73,110 72,108 72,102 73,101 73,84 76,82 185,82 186,81 187,82 191,82 190,81 191,79 190,78 150,78 149,79 148,78 74,78ZM430,60 432,62 432,69 427,75 432,75 434,77 434,79 432,84 429,86 430,94 427,99 429,103 428,104 428,109 425,112 428,115 428,122 426,125 429,128 429,137 428,139 432,143 432,152 435,154 437,158 437,163 433,168 430,168 428,171 424,171 422,170 417,164 416,161 417,156 414,153 412,148 412,143 413,141 410,138 410,135 409,134 409,130 411,127 409,125 408,122 408,115 410,113 408,108 408,101 412,98 410,95 410,88 411,85 414,83 413,77 415,71 418,69 422,72 422,68 423,66 429,60ZM533,57 531,61 531,72 529,75 530,82 531,80 533,81 532,80 533,79 533,76 535,74 537,75 538,74 536,72 535,69 535,62 538,60 544,66 544,72 549,69 553,74 553,80 555,79 559,85 557,81 557,76 555,70 551,66 548,66 545,63 545,61 543,59 537,56 536,57ZM431,56 428,56 425,58 418,66 415,66 412,69 410,75 410,82 408,84 407,92 406,93 407,96 405,99 405,112 404,113 405,114 404,120 406,126 405,128 405,134 406,135 406,138 408,141 408,147 409,148 409,151 411,153 413,163 415,165 416,169 422,174 430,174 436,171 438,169 440,163 440,156 435,146 435,142 433,137 433,130 431,125 431,120 432,119 432,115 431,114 431,109 432,108 432,96 433,95 434,86 436,84 437,81 437,74 435,70 436,68 436,61 435,59Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M164,176 165,179 191,179 191,176ZM469,144 469,147 493,147 493,144ZM145,123 146,124 145,125 145,133 148,136 151,136 152,137 153,136 166,136 168,138 168,155 171,159 174,160 176,159 187,160 191,158 192,156 192,138 194,136 213,136 216,132 216,128 214,125 213,126 212,124 212,131 210,133 190,133 189,134 189,154 187,156 173,156 171,154 171,134 170,133 150,133 148,131 148,127 146,126 148,125 148,123 147,122ZM510,124 506,121 502,121 501,120 505,114 504,112 502,112 492,123 480,130 480,131 495,131 501,125 505,125 507,127 506,130 507,133 510,131ZM189,105 189,115 190,116 207,116 206,116 204,113 194,112 192,109 192,104 190,106ZM487,105 483,105 483,106 480,108 479,107 479,104 476,103 476,109 472,113 467,113 466,114 468,117 469,116 471,117 474,115 476,116 471,123 474,124 479,119 484,112ZM546,86 544,89 547,91 548,87ZM555,80 553,81 556,83 555,84 557,90 556,98 559,101 559,107 557,113 559,115 559,118 562,117 562,113 561,112 562,109 561,107 562,106 561,102 562,101 560,97 560,89 558,84 556,83ZM533,80 531,81 531,83 532,85 534,86 533,87 533,92 535,98 535,109 537,111 536,112 536,116 538,117 536,118 537,119 535,120 538,122 539,121 539,115 541,112 539,109 539,106 538,105 538,102 540,99 537,95 537,91 536,90 537,87 535,86 536,85 534,83Z\"/><path fill=\"#a63441\" fill-rule=\"evenodd\" d=\"M549,160 548,159 545,159 542,161 538,168 539,169 544,168 548,164 548,161ZM419,159 418,161 420,165 423,168 427,169 428,167 426,163 422,159ZM534,154 532,158 532,164 535,166 537,163 537,156ZM432,154 430,156 429,161 430,164 433,166 435,163 435,158 434,155ZM553,144 548,146 544,153 545,156 551,153 553,149ZM414,144 413,145 414,150 417,154 422,156 423,154 421,151 421,149 417,145ZM538,141 536,145 536,148 537,151 540,154 542,150 542,145 540,142ZM428,141 425,144 425,151 427,154 430,151 430,144ZM555,130 550,134 548,138 548,141 549,142 552,141 554,139 556,135 556,131ZM412,130 411,131 412,133 411,136 414,140 418,142 419,139 417,137 416,138 414,136 417,135 416,133ZM540,129 539,132 540,134 540,138 542,140 544,140 545,139 545,132 542,129ZM426,128 422,131 421,134 422,140 425,140 426,139 428,133ZM556,115 551,119 551,123 550,124 550,127 551,128 557,123 557,116ZM542,115 541,116 541,123 546,127 547,126 547,119ZM425,115 420,119 420,126 422,127 426,122 426,116ZM411,115 410,116 410,122 412,126 416,128 417,126 416,121 414,117ZM541,102 540,103 541,109 542,111 546,114 547,113 547,107 544,103ZM424,102 420,107 420,112 422,113 426,108 426,103ZM410,101 410,109 413,113 415,113 416,112 416,105 413,101ZM555,100 551,105 551,113 553,113 556,110 556,107 557,106 557,101ZM539,89 538,90 539,95 545,100 546,99 545,93 542,90ZM428,89 426,89 422,92 421,94 421,100 424,99 427,96 429,90ZM554,86 552,86 550,88 549,91 549,95 551,99 552,99 555,95 555,88ZM413,86 412,88 412,95 413,97 416,99 418,95 418,91 417,88 415,86ZM535,76 534,78 536,82 540,86 543,86 543,82 542,80 539,77ZM432,76 428,77 425,79 423,85 424,86 428,85 431,82 431,80 433,77ZM550,72 548,72 546,75 546,82 548,85 551,83 552,80ZM417,72 415,76 415,82 419,85 421,81 421,75 419,72ZM537,62 536,63 537,69 538,71 542,74 543,73 543,69 541,65ZM430,62 425,66 424,68 424,74 426,74 429,71 431,66 431,63Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M550,106 550,107 548,108 548,113 547,114 548,113 552,114 550,113ZM423,102 419,107 417,106 417,112 415,114 413,114 411,112 413,114 412,115 415,114 417,112 422,115 421,117 424,115 423,113 425,111 422,114 419,112 419,107Z\"/><path fill=\"#255255\" fill-rule=\"evenodd\" d=\"M175,94 173,99 174,102 173,105 174,116 172,118 151,118 150,119 150,130 151,131 172,131 174,133 174,139 173,140 174,154 186,155 187,154 187,133 189,131 209,131 210,130 210,119 209,118 189,118 187,116 187,95 186,94Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M546,157 544,157 541,161 539,162 536,168 534,168 532,166 538,170 537,169 538,164 544,158 546,158ZM422,149 424,153 423,156 425,154 429,155 431,153 431,151 431,152 427,155 424,152 423,149ZM559,146 558,148 554,148 553,152 548,156 550,159 549,165 544,170 542,170 545,172 542,175 539,175 542,175 547,173 552,168 553,163 555,160 555,156 558,152ZM411,138 414,141 413,144 414,143 418,144 421,141 423,142 421,139 420,139 420,141 418,143 416,143ZM548,135 547,135 546,140 544,142 540,139 537,140 539,140 542,143 545,141 546,142 544,147 543,145 543,151 541,155 539,155 536,152 536,150 535,153 536,153 538,156 543,155 544,149 549,144 551,143 554,144 552,142 549,143 547,141 547,137ZM459,134 456,138 456,141 458,144 457,145 461,148 468,148 460,142ZM548,120 548,127 549,128 549,122 550,121ZM73,111 72,127 73,127ZM417,100 418,99 420,100 421,103 423,101 426,101 428,103 426,100 427,98 423,101 421,101 419,98ZM420,86 424,88 423,90 422,89 423,90 421,92 418,88ZM483,81 475,81 469,83 461,88 459,91 458,96 456,98 456,107 458,112 461,115 463,116 460,113 460,110 461,109 462,110 460,107 460,104 459,103 460,102 460,97 463,93 462,94 461,92 473,85 476,85 479,81ZM236,80 237,79 241,79 242,80 241,81 237,81ZM276,79 277,78 280,78 283,80 282,81 278,81ZM275,78 277,80 275,81 275,82 277,81 278,82 294,82 296,84 296,93 297,94 296,99 297,97 297,90 298,89 300,90 300,81 298,79 295,78 294,79 293,78 284,78 283,79 282,78ZM227,82 249,82 247,81 243,81 242,80 243,79 251,78 227,78 232,78 233,79 232,81 228,81ZM191,81 192,82 203,82 192,82 191,81 192,80 202,80 203,78 206,78 199,78 198,79 191,78 192,79ZM423,73 422,73 422,76 424,76 425,78 422,80 421,85 420,86 417,86 414,84 419,90 419,95 420,95 420,93 424,89 422,86 423,80 428,76 425,76Z\"/><path fill=\"#ccae42\" fill-rule=\"evenodd\" d=\"M411,166 412,173 414,175 415,174 417,177 416,178 424,184 430,184 437,178 436,176 437,173 435,173 430,176 423,176 419,174 415,169ZM168,158 171,161 169,165 172,167 171,168 173,168 176,170 179,174 184,174 186,170 186,167 188,165 191,165 189,164 193,159 194,160 192,159 188,162 181,162 180,161 171,161ZM64,156 65,154 68,155 65,157ZM559,149 559,152 556,156 556,161 554,163 554,166 547,174 543,176 538,176 529,172 527,175 526,174 528,176 528,178 533,184 539,186 542,186 548,184 554,176 553,174 554,173 552,171 554,168 558,165 557,164 557,158 556,157 558,154 559,155 560,154 559,155 558,154ZM507,147 501,149 494,149 494,152 493,153 487,154 486,156 484,156 483,154 479,154 478,156 476,154 470,153 468,151 468,149 459,149 460,152 458,154 460,155 462,158 464,158 467,160 477,160 478,161 482,161 489,158 499,159 501,156 506,155 505,153 507,152ZM214,138 206,138 207,139 204,143 202,144 200,143 196,148 195,148 194,146 194,154 195,155 195,154 202,148 205,148 207,145 212,144ZM145,137 145,139 147,141 145,144 147,143 149,145 149,147 150,145 151,148 158,150 162,152 165,155 166,154 167,156 166,146 164,146 163,144 162,145 157,141 155,141 153,139 154,138 148,138ZM564,131 563,131 562,139 561,140 562,142 563,140 562,135 564,133ZM68,117 68,118 61,123 60,125 62,128 62,130 64,131 64,133 66,133 68,135 68,146ZM508,112 506,114 506,116 504,117 504,120 509,118 509,116 507,113ZM457,111 458,114 457,115 458,116 456,117 456,119 460,124 463,126 465,126 472,119 472,118 465,118 462,117 457,113ZM41,55 45,50 58,50 59,49 62,50 66,50 67,49 70,50 95,50 96,49 107,49 108,50 124,50 125,49 128,50 129,49 133,49 134,50 136,49 139,49 140,50 143,49 144,50 156,50 157,49 162,49 163,50 169,50 170,49 173,50 175,49 176,50 183,50 184,49 187,49 188,50 194,50 195,49 197,50 200,50 201,49 204,50 208,50 209,49 212,50 215,49 218,50 219,49 220,50 221,49 252,50 253,49 257,49 258,50 261,50 263,49 264,50 270,50 274,54 275,57 274,58 274,62 275,63 274,65 274,72 275,73 274,75 275,77 298,77 301,80 301,83 302,84 302,170 301,173 297,178 294,179 295,181 293,182 292,180 291,185 289,188 283,190 274,190 273,189 272,190 268,190 265,187 263,188 256,187 255,190 252,188 250,189 248,187 241,188 239,190 232,190 231,189 225,190 224,189 226,188 223,187 221,190 213,190 212,191 202,190 201,188 200,189 197,189 195,191 193,190 185,190 184,189 180,190 179,189 180,188 176,188 174,187 173,189 172,188 166,188 164,190 162,189 161,191 150,191 149,190 145,190 143,188 140,188 139,189 136,188 129,188 127,190 126,190 125,188 123,188 118,191 113,189 110,191 102,190 101,189 93,189 92,187 90,187 88,189 83,189 79,186 80,184 77,182 77,181 79,180 76,180 73,178 68,172 68,154 67,153 49,153 46,151 42,146 40,140 40,135 41,134ZM0,0 0,231 323,231 323,226 328,212 329,204 333,193 333,189 335,186 336,178 338,174 340,163 344,152 348,133 351,126 352,117 356,107 358,96 360,92 360,88 362,84 364,73 368,62 368,58 371,51 372,44 377,29 377,25 379,21 381,10 383,6 383,3 385,0Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M43,112 44,113 44,126 43,127 42,126 42,113ZM538,56 543,58 546,61 546,63 548,65 551,65 556,70 557,74 556,70 552,65 549,65 545,59 540,56ZM194,53 195,54 201,54 202,55 217,54 221,56 222,54 224,55 230,55 231,54 253,54 254,55 261,54 262,55 266,55 267,54 269,56 269,66 270,67 269,68 269,74 270,75 268,77 262,77 274,77 273,76 273,55 270,51 195,51ZM158,53 159,54 168,54 169,52 173,52 174,53 172,54 172,55 175,53 177,53 174,53 171,51 165,51 164,52 159,51ZM136,54 149,54 152,53 143,51 141,53 137,52ZM46,51 43,53 42,55 42,142 44,147 50,152 65,152 66,151 64,152 63,149 60,148 52,148 50,147 46,142 46,120 47,119 46,116 46,109 47,108 46,105 46,73 47,72 46,69 47,66 46,65 46,61 47,58 51,55 66,55 67,54 73,54 74,53 71,51 65,51 64,52 62,51ZM86,53 93,56 95,56 93,56 92,55 93,54 97,54 98,55 109,55 114,53 111,51 102,51 101,50 98,51 90,51Z\"/>",
	P: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M247,147 247,165 250,166 251,165 259,164 260,163 260,154 251,148ZM316,124 313,125 311,124 308,128 306,128 303,131 298,133 297,132 283,133 281,136 280,134 280,144 275,150 275,182 276,183 277,182 281,182 282,181 286,181 287,180 306,177 311,175 311,151 312,150 312,142 317,136 317,125ZM309,79 308,77 305,75 300,77 294,77 293,78 290,77 284,77 282,79 279,80 272,80 272,91 270,96 268,98 271,100 276,98 279,99 282,97 285,97 287,95 290,94 293,95 301,94 303,93 303,91 307,87 308,85 308,80ZM376,59 359,70 359,72 371,89 372,92 375,95 376,98 387,113 386,118 375,133 374,136 359,158 359,160 374,170 376,170 392,147 393,144 412,117 412,113Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M124,126 114,128 111,131 111,133 107,137 106,140 109,138 111,138 113,135 117,133 118,130 121,130ZM57,124 61,127 60,129 65,134 64,136 65,136 69,141 72,140 75,141 67,129 59,124ZM316,108 314,107 315,109 311,111 309,110 305,112 301,111 300,114 294,114 293,115 289,114 288,115 281,116 280,117 280,121 281,122 280,125 280,133 281,135 283,132 291,132 292,131 297,131 298,132 301,131 306,127 308,127 311,123 312,124 314,123 317,124 317,111ZM294,96 290,95 287,96 285,98 282,98 286,99 287,98 290,98 292,96ZM309,76 308,75 307,69 300,57 299,57 299,58 301,59 299,61 297,61 296,59 295,61 293,59 294,58 293,59 291,58 288,61 287,60 286,61 287,62 284,65 282,66 281,65 277,65 268,70 270,73 270,79 271,81 272,79 279,79 282,78 284,76 290,76 293,77 294,76 300,76 306,74 309,78Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M309,184 304,184 302,186 301,185 298,185 297,186 287,187 286,188 282,188 276,190 271,190 265,187 272,193 275,194 276,193 278,194 284,194 286,192 288,193 293,189 297,189 298,188 299,189 302,186 304,187 305,186 306,187ZM45,175 50,182 52,182 53,184 54,183 57,187 59,186 62,189 68,188 73,190 76,189 79,189 80,190 90,190 92,188 93,189 95,188 97,190 98,189 101,189 102,190 103,189 111,189 112,190 114,189 116,190 118,187 120,186 122,187 124,184 126,184 128,183 129,181 132,180 134,176 119,184 62,184 52,179 47,175ZM236,169 236,170 244,177 245,176 247,177 252,177 253,176 254,177 255,174 254,172 251,173 242,173ZM464,149 468,151 467,152 469,153 470,155 476,159 479,159 480,160 479,161 481,163 484,163 488,167 492,167 493,168 499,168 504,166 512,167 515,165 521,165 522,164 525,164 528,162 530,163 536,161 537,162 536,161 537,160 539,160 543,157 543,156 534,156 529,158 510,161 505,163 493,164 492,163 489,163 487,161 482,159 474,153 472,153 466,149ZM129,126 128,125 125,126 121,131 118,131 117,134 113,136 111,139 109,139 107,141 105,140 106,137 110,133 110,131 114,127 116,127 114,127 111,130 110,129 106,129 105,130 96,131 91,133 87,133 86,134 87,136 95,136 94,135 95,134 100,133 103,131 106,131 107,132 108,131 109,132 105,140 97,150 98,152 96,153 94,156 98,155 99,153 102,153 102,151 105,148 105,146 110,142 112,142 117,139 121,134 128,129ZM50,120 51,124 56,128 57,131 80,153 83,155 85,155 81,148 77,144 75,140 76,141 75,142 72,141 69,142 67,139 63,136 64,134 65,135 66,134 65,133 64,134 59,129 60,127 56,124 58,123 52,120ZM288,47 281,47 272,50 267,50 266,51 252,53 248,55 244,55 242,56 239,60 239,63 238,64 239,75 241,80 237,83 236,82 231,84 229,87 229,115 231,120 234,124 234,160 240,163 245,167 248,167 246,166 246,147 248,145 255,150 257,150 262,154 262,163 261,164 262,166 262,176 273,183 274,183 274,150 279,144 279,125 280,124 279,117 281,115 284,115 289,113 291,114 294,113 300,113 301,110 304,111 308,109 311,110 314,109 314,108 316,107 311,98 304,92 305,93 301,96 295,96 292,97 290,99 287,99 286,100 281,99 280,100 277,100 275,102 270,102 266,99 269,95 271,90 271,82 269,79 269,73 267,70 274,65 277,64 281,64 282,65 286,62 285,61 287,59 288,60 291,57 295,60 296,58 297,60 299,60 301,58 302,59 301,58 299,59 298,57 300,56 295,51Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M498,169 499,172 502,170 509,170 511,172 510,169 506,167ZM118,141 115,141 112,143 110,143 106,146 106,148 103,151 102,154 99,154 98,156 94,157 93,155 97,152 96,151 90,159 84,152 86,155 85,156 83,156 80,154 73,147 72,147 68,142 62,142 60,143 63,143 72,150 72,153 74,153 76,155 77,159 78,160 79,159 80,162 82,162 84,164 83,165 84,167 91,169 93,167 95,167 101,163 105,157 109,154 109,151 113,147 113,145 117,143ZM67,128 70,131 77,142 78,140 82,140 87,142 88,141 97,141 102,139 104,140 103,141 108,133 108,132 107,133 106,132 103,132 100,134 95,135 96,136 95,137 87,137 85,135 86,133 82,133 81,134 80,133 78,134 69,130Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M499,175 500,176 502,173 509,173 510,174 511,173 509,171 502,171 499,173ZM122,143 118,142 117,144 114,145 114,147 110,151 110,154 106,157 102,163 99,166 93,168 91,170 84,168 82,166 83,164 80,163 79,160 78,161 76,159 75,155 71,153 71,150 63,144 58,144 61,144 63,147 69,151 70,153 69,154 71,155 74,159 73,161 72,160 72,161 74,163 76,162 78,164 80,169 79,170 82,173 84,173 87,175 90,175 91,174 94,174 96,171 99,170 100,168 101,169 104,168 101,167 103,165 104,162 108,157 111,157 113,154 112,151 115,150 116,147 119,144ZM103,140 97,142 88,142 87,143 82,141 78,141 78,143 81,146 80,145 81,144 85,146 90,146 91,145 93,146 96,149 94,153ZM227,130 225,131 226,134 225,135 227,135Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M501,185 501,187 503,188 503,191 505,191 502,187 504,185ZM288,186 286,185 287,182 286,183 276,184 275,185 272,185 271,183 272,185 271,188 277,188 283,186ZM107,178 108,179 108,182 107,183 111,183 111,182 109,181 111,180 111,179ZM65,173 62,175 58,180 61,182 66,182 67,183 67,174 68,173ZM554,168 555,167 560,169 559,170 555,170ZM554,162 552,165 552,168 555,171 560,171 561,170 560,168 561,166 559,165 560,164 558,162 557,163ZM458,162 452,162 449,167 449,170 451,171 455,171 459,168 459,163ZM229,157 230,160 229,161 233,166 232,165 233,163 235,162 232,160 232,157ZM127,147 124,148 125,150 125,154 123,155 119,159 120,160 118,161 118,162 121,164 120,167 122,170 121,171 121,177 120,178 121,181 127,177 134,174 136,172 141,170 147,165 147,160 140,154 139,155ZM445,117 442,115 440,119 443,119 443,118ZM561,114 561,118 563,120 577,121 582,119 584,117 583,113 581,111 578,110 565,110 563,111ZM550,106 550,115 549,116 549,124 548,125 548,131 548,125 549,124 550,125 550,143 548,144 548,146 546,148 543,148 537,152 533,152 532,151 530,153 525,152 522,154 517,154 515,156 514,155 511,155 502,158 497,158 495,157 492,158 492,159 494,160 495,158 496,159 495,162 500,162 501,161 505,161 506,160 510,160 511,159 515,159 521,157 526,157 527,156 541,154 546,152 550,148 552,144 552,131 553,130 552,129 552,110 550,108ZM314,94 315,96 312,97 314,99 318,107 318,111 319,112 319,135 318,138 314,142 314,175 311,178 303,179 303,183 304,182 313,181 317,177 317,145 318,143 320,142 322,138 322,110 320,108 321,105 318,99ZM542,82 539,85 540,89 547,90 548,92 552,95 550,88 544,82ZM231,78 225,83 224,86 225,89 227,89 227,86 232,82ZM208,77 202,81 201,83 195,86 193,89 189,91 185,95 183,95 180,98 176,100 174,103 171,104 167,108 163,110 160,114 160,117 168,124 171,125 178,132 180,132 202,150 205,151 207,153 211,153 214,150 214,137 216,135 220,134 220,133 222,132 221,131 211,131 210,132 210,147 208,149 190,135 186,133 182,129 178,127 174,123 170,121 164,115 181,101 188,97 200,87 203,86 208,81 210,83 210,98 211,99 217,99 213,92 214,90 213,87 214,86 214,81 212,78ZM528,74 525,71 517,68 512,68 511,69 505,69 500,71 496,71 495,74 492,75 492,77 490,80 493,81 496,79 498,81 499,84 493,89 483,89 480,87 478,87 476,84 474,83 471,83 470,84 468,83 465,84 464,83 466,82 467,80 468,81 469,79 471,80 471,77 466,77 462,79 458,85 458,127 458,121 462,119 463,121 465,121 468,118 469,112 470,111 472,111 477,115 477,118 484,123 485,125 486,124 486,118 487,117 487,108 498,99 501,99 504,97 507,97 508,98 510,97 516,97 520,95 520,88 522,85 523,81 528,77ZM45,64 45,94 44,95 45,97 44,99 45,105 44,106 44,110 46,114 61,124 76,132 83,132 81,131 85,128 78,128 75,126 71,121 68,121 66,118 61,117 60,115 57,113 53,113 51,111 51,109 48,106 47,104 47,100 48,99 47,74 48,73 47,72 47,64ZM559,59 554,60 552,62 551,67 553,69 559,68 561,65 561,61ZM451,58 448,61 448,64 453,69 457,69 460,66 460,64 456,59ZM373,54 367,59 355,66 353,68 353,73 361,83 369,97 380,111 379,112 382,114 380,117 380,119 382,120 385,116 383,110 380,107 360,76 359,78 356,75 357,73 356,70 375,57 379,60 386,72 389,75 396,87 398,88 399,91 409,105 410,108 415,114 415,116 412,119 411,122 408,125 405,131 402,134 397,143 390,152 377,172 374,172 357,160 357,158 365,146 365,144 364,144 355,154 353,158 354,163 363,169 367,170 368,172 369,171 370,174 377,176 381,173 388,161 393,155 397,147 403,140 405,135 409,131 413,124 416,121 416,119 418,117 418,112 410,102 409,99 404,93 404,91 400,87 400,85 397,82 394,76 384,63 384,61 378,54ZM278,44 277,45 271,45 270,46 264,46 263,47 261,46 260,47 254,47 248,50 243,50 241,51 234,59 233,62 233,71 235,68 237,69 236,70 237,69 236,67 237,60 242,54 244,53 248,53 249,52 253,52 258,50 271,48 270,47 272,45 273,48 276,47ZM282,42 283,43 286,42 287,44 289,45 287,46 289,45 291,47 293,47 294,49 295,49 301,55 308,67 310,73 310,78 311,77 312,78 313,76 313,70 311,67 311,65 309,63 309,61 303,52 298,47 292,43 289,42ZM60,46 61,53 67,58 73,60 78,60 86,55 88,57 90,57 91,59 95,62 95,64 98,66 114,64 115,63 118,63 121,61 130,61 133,65 133,88 134,89 133,91 133,112 132,115 129,118 122,121 116,121 115,124 116,126 117,125 125,124 131,122 135,118 136,116 136,112 137,111 137,67 136,66 137,64 133,56 130,53 126,52 121,48 119,48 118,46 112,44 108,40 105,39 90,39 89,40 85,40 82,42 77,42 72,44 68,44 67,45ZM503,37 500,41 501,58 503,60 508,60 511,52 511,46 509,42 509,38 508,37Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M502,188 503,187 506,191 503,192 502,191ZM500,187 501,184 504,184 505,185 502,188ZM302,179 301,180 297,180 292,182 288,182 287,185 293,185 298,183 302,183ZM503,175 500,178 500,189 503,193 506,194 508,193 510,190 510,182 511,181 511,178 510,176ZM68,174 68,183 106,183 107,182 107,179 103,177 96,177 95,178 88,179 87,178 81,177 74,172 70,172ZM233,162 234,163 233,165 242,171 252,171 255,170 257,172 257,178 259,181 269,187 271,186 270,183 262,179 260,177 260,167 259,166 255,166 250,168 244,168ZM82,145 83,149 88,156 90,157 94,152 93,147 91,148 85,148 84,146ZM93,127 96,125 97,126 96,128ZM116,124 115,122 106,123 103,124 101,126 96,125 95,126 88,127 83,130 84,132 86,131 91,131 92,130 111,127 113,124 114,126 115,126ZM439,119 442,114 446,117 444,118 443,120 440,120ZM427,113 427,117 429,119 432,120 446,120 448,118 448,114 443,110 431,110ZM225,90 223,92 223,96 224,97 223,100 221,97 220,98 217,96 218,99 221,98 223,100 223,113 224,114 225,120 227,122 229,127 229,130 228,131 228,136 229,137 229,156 232,156 232,124 229,120 229,118 227,115 227,90ZM311,78 310,79 311,80 310,81 310,85 306,92 311,96 314,96 313,93 311,91 311,89 313,86 313,82 312,81 313,79ZM498,84 496,80 493,82 489,80 491,77 491,75 494,74 494,72 490,72 487,74 471,76 472,77 472,80 471,81 469,80 468,82 467,81 467,82 465,83 468,82 470,83 471,82 474,82 476,83 478,86 480,86 483,88 493,88ZM236,69 234,70 233,73 234,74 234,78 233,79 232,78 233,81 237,81 239,79 237,74 237,70ZM277,47 278,46 279,47 280,46 286,46 287,45 289,46 287,45 286,43 285,44 281,43 279,44Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M208,83 196,93 181,103 166,115 167,117 178,124 179,126 182,127 186,131 208,147 209,146 208,132 211,129 216,129 217,130 218,129 222,129 223,130 226,130 226,124 224,122 224,119 222,115 222,103 221,101 211,101 209,99 209,84Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M555,161 562,166 561,167 562,170 560,172 555,172 552,169 555,172 560,172 562,170 562,165 559,162 558,163 557,161ZM36,163 38,162 39,160 42,162 38,165ZM125,149 124,150 123,149 124,147 123,144 119,145 117,147 116,150 113,151 114,153 113,156 111,158 108,158 102,167 105,168 101,170 100,169 100,170 97,171 94,175 91,175 90,176 87,176 84,174 82,174 78,170 79,169 77,164 74,162 73,163 71,161 72,159 73,160 72,157 68,154 69,153 68,151 63,148 61,145 58,145 49,150 47,150 46,152 43,153 37,158 36,162 34,164 38,169 42,170 45,173 55,178 57,180 57,179 65,172 74,171 79,175 88,178 95,177 96,176 109,177 112,179 112,180 110,181 111,181 112,183 115,183 117,180 118,182 120,182 119,178 120,177 120,171 121,170 119,167 120,164 118,163 117,161 119,160 118,159 124,154 124,150ZM224,131 222,131 223,132 221,133 220,135 218,135 224,135 225,134ZM548,124 549,125 549,131 548,132 547,131 547,125ZM379,118 375,124 374,128 369,133 368,137 364,140 359,148 364,143 366,144 368,142 369,139 372,136 379,124 382,121 381,121ZM553,96 551,96 547,91 540,90 538,87 538,85 542,81 539,80 537,78 535,78 527,72 529,74 529,77 527,78 523,83 523,85 521,88 521,95 516,98 510,98 509,99 504,98 501,100 498,100 494,104 490,106 488,108 487,124 485,126 484,124 476,118 476,115 472,112 470,112 469,118 465,122 463,122 462,120 459,121 458,138 459,140 459,138 460,137 461,138 460,143 463,146 460,143 460,142 462,141 465,145 468,146 465,147 475,152 487,160 492,162 494,162 495,159 494,161 492,160 491,158 495,156 497,157 502,157 511,154 514,154 515,155 517,153 522,153 525,151 530,152 532,150 533,151 537,151 543,147 546,147 547,144 549,143 549,125 548,124 548,116 549,115 549,106 550,105 551,108 553,110 553,129ZM43,54 42,57 42,60 43,61 42,64 42,68 43,69 43,74 42,75 42,81 43,82 43,88 42,89 42,104 43,105 43,110 45,113 43,110 43,106 44,105 44,102 43,101 44,98 43,96 44,94 44,64 47,63 48,64 48,72 49,73 48,74 48,89 49,90 48,104 52,109 53,112 57,112 59,113 61,116 66,117 68,120 71,120 72,122 78,127 87,127 96,124 102,124 106,122 110,122 116,120 122,120 129,117 131,115 132,112 132,91 133,89 132,88 132,65 130,62 121,62 118,64 115,64 114,65 98,67 94,64 94,62 93,62 90,58 88,58 86,56 78,61 73,61 67,59 60,53 59,46 53,46 49,48Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M515,174 511,174 513,179 513,182 512,183 512,189 508,195 503,195 499,191 499,187 498,186 499,176 498,175 498,176 495,178 493,184 495,187 495,189 497,190 498,193 497,194 498,195 500,194 504,196 505,198 508,198 506,197 512,193 514,194 513,195 515,193 515,191 519,188 519,183 520,182 518,177ZM554,159 551,161 549,167 552,171 553,175 555,173 559,173 560,174 561,172 562,173 563,172 562,171 564,170 563,169 563,165 561,163 562,162 561,163 558,161 563,165 563,170 560,173 555,173 550,167 551,163 555,160ZM457,158 455,158 454,160 458,160 461,163 460,166 461,168 457,172 454,173 451,173 447,169 448,165 451,161 450,161 449,159 446,161 447,160 449,163 446,166 446,170 445,171 449,173 450,172 451,175 454,177 453,175 455,174 456,172 457,174 459,174 457,173 460,170 461,165 462,164 463,165 463,164 460,162 460,160ZM123,143 125,146 129,147 134,151 137,152 139,154 140,153 142,155 140,153 134,151 130,147 128,147ZM179,133 182,136 189,140 194,146 198,147 202,151 205,152 207,154 212,154 214,152 214,151 211,154 207,154ZM411,129 386,166 391,160 394,154 396,153 402,142 406,138ZM160,118 166,124 177,132 171,126 168,125ZM560,113 565,109 570,109 571,108 574,109 576,108 583,111 585,114 585,117 581,121 578,121 577,122 569,122 568,121 563,121 560,118ZM425,114 426,112 430,109 433,109 434,108 435,109 437,108 445,108 450,112 451,117 450,119 446,122 433,122 432,121 429,121 425,117ZM555,105 555,110 554,111 555,123 555,118 557,117 559,121 562,123 561,124 562,127 564,128 567,128 568,127 569,128 572,128 573,127 576,127 580,124 581,125 586,117 588,116 583,110 585,109 579,105 572,105 571,104 573,103 567,103 561,108 560,111 558,113 557,113 555,110 557,109 557,108 555,107ZM215,80 213,77 207,76 199,83 197,83 194,85 193,87 187,92 174,100 172,103 163,108 160,113 163,109 167,107 171,103 174,102 176,99 180,97 183,94 186,93 190,89 193,88 195,85 199,83 208,76 212,77 215,81 215,83ZM353,74 357,81 360,84 361,87 365,91 365,93 371,100 372,103 378,111 374,104 368,97 360,83 356,79 355,76ZM560,58 563,57 564,60 563,61ZM451,57 456,58 461,64 461,67 456,71 453,71 452,69 447,65 447,61ZM561,55 555,55 558,55 559,56 558,57 555,57 554,59 553,58 554,59 560,56 561,57 560,58 563,61 563,65 561,68 558,70 555,70 557,72 556,73 559,69 562,69 561,67 563,65 563,62 564,61 565,62 564,58 560,56ZM451,53 454,53 455,54 454,55 449,55 448,56 448,59 446,60 445,63 449,69 448,70 445,69 445,71 453,76 457,76 460,78 458,84 459,81 462,78 466,76 473,75 470,76 464,76 463,75 463,71 462,73 460,71 465,65 464,60 463,59 462,61 455,54 455,53ZM352,68 352,72 352,68 355,65 364,60 373,53 378,53 383,58 385,61 385,63 395,76 396,79 401,85 402,88 405,91 406,94 419,112 419,117 417,119 417,121 412,127 418,120 420,120 421,122 424,122 428,127 433,129 447,128 453,123 453,118 454,117 457,119 457,122 457,102 457,111 454,113 453,112 453,108 451,108 445,101 429,102 426,103 424,105 425,109 422,112 421,110 419,110 413,104 411,101 411,99 408,96 401,84 396,78 395,75 389,68 383,57 378,53 373,53 369,55 363,60 356,64ZM295,44 304,52 310,61 313,69 312,64 305,52 300,47 297,46 296,44ZM287,41 280,41 276,43 271,43 266,45 262,45 267,45 268,44 278,43 282,41ZM117,45 106,38 90,38 89,39 83,39 79,41 65,43 60,45 55,45 62,45 63,44 72,43 77,41 82,41 85,39 89,39 90,38 105,38ZM504,35 507,35 510,38 510,41 512,45 511,59 509,61 503,61 499,56 500,54 499,53 499,47 498,46 499,45 499,41ZM510,33 505,32 503,33 504,34 497,40 496,39 497,37 496,36 492,40 490,45 490,51 495,58 501,63 501,66 499,67 500,68 499,70 491,71 495,71 503,68 513,67 510,67 509,66 510,65 509,62 512,61 512,59 514,58 513,56 515,55 518,51 519,45 518,42 516,40 515,40 514,42 512,39 507,35Z\"/>",
	Q: "<path fill=\"#1e1e1e\" fill-rule=\"evenodd\" d=\"M106,166 105,184 107,185 108,184 118,182 118,173 110,167ZM141,143 141,144 139,145 140,149 138,155 139,156 138,163 137,165 133,168 133,173 134,174 133,175 133,179 134,180 134,200 137,201 138,200 142,200 143,199 156,197 157,196 168,195 170,193 170,160 173,158 175,155 175,146 167,146 166,145 163,146 162,145 160,147 144,147 142,145 144,144 144,143ZM183,136 183,143 182,145 184,146 185,145 185,137ZM242,111 229,110 227,108 225,108 217,112 210,112 207,114 205,120 205,126 204,127 205,128 200,132 200,164 201,165 203,164 213,163 218,161 223,161 228,159 233,159 236,157 236,151 237,150 237,147 236,146 237,144 237,124 242,118ZM293,92 283,96 278,101 275,107 269,112 268,116 269,119 272,122 277,123 282,119 282,113 279,108 287,99 294,96 299,96 307,99 313,105 316,111 316,120 313,126 307,132 300,135 294,135 288,133 284,130 281,132 283,135 292,139 302,139 309,136 313,133 317,128 320,120 320,110 317,103 310,96 301,92ZM166,90 165,89 160,89 158,92 148,93 145,96 143,96 140,98 135,98 130,100 130,111 127,117 129,116 130,117 132,116 137,117 138,116 142,116 144,114 147,113 148,115 157,111 160,111 161,112 162,109 165,106 167,102ZM307,60 293,69 290,72 299,85 305,86 312,89 320,96 325,103 326,106 327,119 326,120 325,128 320,135 312,142 300,146 290,159 291,161 303,168 306,171 309,170 310,167 313,164 345,116 335,100 324,85 323,82 312,67 311,64ZM233,56 225,56 223,58 218,59 215,61 205,62 201,64 198,63 197,64 197,74 193,80 193,82 203,81 211,76 217,77 223,74 227,74 230,72 234,64ZM490,20 485,19 483,21 483,24 479,35 479,38 478,39 477,47 475,51 473,62 469,73 469,76 464,91 461,106 458,113 458,117 456,121 453,136 449,147 445,166 443,169 443,173 440,181 438,192 436,196 433,210 431,214 430,220 432,222 438,223 441,216 441,213 442,212 444,201 446,197 447,190 449,186 453,167 459,149 460,140 462,137 462,134 464,130 464,127 467,119 471,100 475,89 475,86 478,78 478,75 479,74 481,63 483,59 483,56 485,52 490,29 492,25 492,22Z\"/><path fill=\"#424542\" fill-rule=\"evenodd\" d=\"M151,141 152,142 151,144 148,145 147,143ZM175,130 174,129 171,131 166,131 164,129 164,127 158,127 155,129 150,129 148,132 145,133 141,136 140,134 139,136 139,144 140,144 141,142 144,142 145,144 143,145 144,146 160,146 162,144 163,145 165,144 167,145 175,145 175,141 176,140ZM164,112 161,113 160,112 157,112 148,116 147,115 148,113 142,117 138,117 137,118 135,117 132,117 131,118 129,117 127,118 126,117 127,115 126,118 129,120 134,120 135,119 138,119 140,117 145,117 153,114 156,114 157,115 164,114ZM242,92 239,92 236,94 224,95 219,97 217,96 215,98 211,97 207,99 205,101 205,119 205,116 208,112 210,111 217,111 225,107 227,107 229,109 242,110ZM166,89 158,75 148,76 146,77 145,79 143,78 141,80 142,81 141,83 136,82 134,84 132,84 126,87 129,96 129,99 135,97 140,97 143,95 145,95 148,92 158,91 160,88 165,88ZM229,73 227,75 223,75 217,78 211,77 203,82 200,82 201,83 204,83 205,82 206,83 209,81 219,80 222,77 223,78 226,78 229,76ZM229,45 225,41 222,45 214,46 207,42 205,42 201,44 203,44 205,46 204,47 199,47 197,45 196,46 192,46 191,48 196,63 198,62 201,63 205,61 211,61 223,57 225,55 233,55Z\"/><path fill=\"#696c69\" fill-rule=\"evenodd\" d=\"M168,202 157,203 156,204 143,206 142,207 138,207 137,208 128,208 122,204 124,208 129,212 140,211 142,213 146,213 150,210 161,208 165,206ZM98,190 98,193 99,194 104,194 110,198 112,198 113,196 113,191 112,190 106,192 101,192ZM459,185 467,194 475,197 482,203 487,203 493,206 502,203 511,204 526,199 530,199 531,200 540,192 540,191 539,192 533,192 532,193 518,195 517,196 504,198 503,199 499,199 498,200 488,200 479,196 465,187ZM233,166 228,166 223,168 219,168 218,169 214,169 213,170 209,170 203,172 195,172 193,171 194,173 199,173 201,176 206,176 214,173 215,174 218,173 220,174 230,170 230,168 233,167ZM384,113 386,116 393,120 396,125 399,126 400,128 403,128 405,130 411,130 416,133 427,132 429,130 434,130 436,131 439,129 443,129 446,127 449,127 448,126 449,125 453,125 454,128 454,124 456,120 455,121 441,123 436,125 430,125 429,126 421,127 420,128 412,128 401,123 396,119ZM147,66 138,66 137,67 133,67 127,69 122,69 121,70 107,72 100,75 100,76 98,77 97,80 97,92 98,93 99,99 97,101 92,101 90,102 87,106 87,133 89,139 92,143 92,178 101,184 105,185 104,184 104,165 106,163 108,165 113,167 120,173 120,181 118,183 120,185 120,194 123,197 132,202 134,202 132,200 132,168 136,165 137,162 137,151 138,150 137,146 138,145 138,136 140,133 141,135 148,131 150,128 155,128 158,126 164,126 166,130 171,130 174,128 175,129 175,126 172,120 165,112 164,115 160,115 159,116 153,115 145,118 140,118 138,120 135,120 134,121 129,121 125,118 125,116 129,110 129,100 128,99 128,96 125,87 127,85 134,83 136,81 141,82 140,80 143,77 145,78 145,77 148,75 157,74 154,70ZM210,29 208,30 204,30 203,31 199,31 198,32 194,32 193,33 189,33 188,34 184,34 183,35 178,35 177,36 174,36 168,38 165,41 163,46 163,53 164,54 164,57 166,63 164,65 160,65 159,66 164,71 171,83 171,86 173,89 174,102 171,109 175,113 181,124 182,134 183,133 187,138 187,145 184,147 187,148 187,158 193,163 200,166 199,164 199,132 204,126 204,101 207,98 211,96 215,97 217,95 219,96 224,94 236,93 239,91 242,91 236,80 230,75 230,76 226,79 223,79 222,78 219,81 209,82 206,84 205,83 204,84 201,84 200,83 197,83 196,84 192,82 192,80 196,74 196,64 192,55 192,53 190,50 191,46 197,44 199,46 204,46 200,44 202,42 207,41 214,45 217,45 218,44 222,44 225,40 229,44 218,32Z\"/><path fill=\"#969991\" fill-rule=\"evenodd\" d=\"M506,204 502,204 498,206 495,206 495,207 493,208 494,209 493,211 500,206 504,206 507,208 507,207 505,206ZM430,131 427,133 419,134 418,136 421,136 423,134 426,134 428,136 430,136 429,135 429,132Z\"/><path fill=\"#cdc9b9\" fill-rule=\"evenodd\" d=\"M495,211 502,208 504,208 506,210 507,209 504,207 500,207ZM418,137 419,138 423,136 424,137 430,137 428,137 426,135 423,135 421,137ZM181,129 181,147 183,150 180,158 182,159 182,161 184,163 183,159 185,158 187,160 185,158 185,149 181,146Z\"/><path fill=\"#f9f3e2\" fill-rule=\"evenodd\" d=\"M455,200 453,198 450,198 449,197 447,199 445,205 445,208 451,208 454,205ZM170,196 165,197 167,198 165,199 165,201 170,199ZM117,197 117,198 125,204 126,204 127,202 128,203 126,200 123,198 121,199 119,196ZM172,167 172,179 174,179 175,177 175,167ZM429,148 427,149 426,148 421,150 420,149 419,150 419,153 423,158 426,158 429,156 431,151ZM580,150 579,148 577,147 570,147 569,149 567,149 568,151 571,152 570,153 565,154 564,151 559,151 558,150 559,148 558,149 558,152 560,156 561,155 569,155 570,156 569,157 570,156 577,156 580,153ZM546,140 547,141 547,145 546,146 545,145 545,141ZM86,140 87,141 86,142 87,144 87,179 90,183 96,187 96,183 90,178 90,142 88,142ZM335,136 331,139 311,170 308,173 306,173 291,163 289,161 290,155 288,157 285,158 286,163 289,166 293,167 297,171 299,171 305,176 309,176 311,175 314,172 319,163 323,159 323,156 328,151 332,145 333,141 335,140 334,139ZM376,126 373,126 370,128 371,130 370,134 371,135 375,135 379,131 379,129ZM247,116 247,117 245,118 244,121 243,118 242,122 239,125 239,152 240,153 242,151 242,127 246,122ZM392,111 392,115 411,126 422,126 423,125 432,124 437,122 442,122 443,121 452,120 456,117 456,116 451,116 446,118 440,118 434,120 429,120 421,123 413,123ZM515,105 503,105 502,106 497,106 492,108 488,108 487,109 488,110 488,114 491,116 490,117 494,117 499,125 505,129 506,134 516,132 517,130 518,131 523,131 525,129 526,130 527,129 532,129 538,127 541,128 544,131 544,149 545,150 544,152 544,178 543,179 543,182 539,186 535,186 534,187 526,188 525,189 512,190 509,192 504,192 502,194 495,194 492,195 492,198 499,198 504,196 514,195 515,194 519,194 520,193 525,193 530,191 539,190 545,186 548,180 548,152 546,151 548,150 548,148 545,147 547,145 548,146 548,141 546,140 548,139 548,129 547,126 544,122 539,118 535,117 532,114ZM557,95 552,95 550,96 547,99 547,104 550,106 553,106 558,101 558,96ZM239,81 243,91 244,89 245,91 247,92 247,94 247,90 244,84 242,82ZM65,78 53,88 50,89 46,93 41,96 36,101 21,111 19,113 19,117 22,121 32,128 36,132 39,133 46,139 49,140 50,142 52,142 64,153 69,153 72,149 72,137 74,135 77,134 77,132 74,131 69,132 69,135 68,136 69,148 66,149 23,117 23,115 27,111 66,82 69,83 69,99 70,100 77,100 78,96 74,96 72,94 72,82 69,78ZM499,73 497,75 496,78 496,90 497,91 497,95 498,96 504,96 506,91 506,76 504,74ZM104,68 99,69 99,70 92,76 92,86 94,85 95,86 95,80 98,74 100,72 101,73 100,71ZM151,62 149,61 135,61 134,62 131,62 129,64 122,64 119,66 109,67 117,67 118,68 117,69 114,69 118,69 119,68 123,68 124,67 128,67 134,65 139,65 140,64 147,64 149,65 149,63 150,62 151,63ZM308,54 303,56 300,59 297,60 286,68 285,70 285,74 291,81 292,86 290,88 286,90 285,89 279,93 272,101 272,103 270,104 264,111 263,114 263,118 269,126 275,128 276,130 276,134 278,136 281,136 279,132 283,128 290,132 293,132 294,133 298,133 299,132 300,133 299,132 300,130 296,132 295,131 296,130 294,131 292,129 290,129 289,128 290,127 289,128 286,124 286,120 287,119 286,107 290,102 292,103 291,102 293,100 298,100 296,99 299,98 288,100 281,107 281,109 284,112 284,119 279,124 274,125 270,123 266,117 266,114 274,105 276,101 282,95 291,91 301,91 301,87 299,87 296,84 288,71 306,58 308,58 311,61 312,64 317,70 320,76 326,83 327,86 337,100 338,103 347,115 345,119 348,118 350,115 347,109 343,105 340,99 340,97 339,97 336,92 331,88 331,85 325,81 326,79 323,75 321,70 318,68 318,66 312,57ZM472,55 466,48 464,48 463,46 459,45 457,43 439,33 427,33 426,34 413,35 409,38 396,39 394,41 393,40 390,40 384,42 379,47 378,50 378,80 381,80 381,52 382,49 386,45 389,45 394,43 398,43 399,42 403,42 404,41 408,41 409,40 413,40 414,39 418,39 419,38 424,38 428,36 437,36 444,39 454,46 464,51 468,56 468,63 469,65 470,65ZM185,29 181,29 178,31 168,32 161,37 159,40 159,43 158,44 158,53 159,54 162,54 161,47 164,39 171,35 175,35 176,34 183,33 183,32 185,31ZM187,28 190,30 190,32 191,30 194,31 195,30 205,29 206,28 207,29 208,28 214,28 222,33 228,40 233,49 235,55 235,68 238,67 239,65 239,58 238,57 238,53 236,47 234,45 233,41 229,37 227,33 220,27 214,25 205,25 204,26ZM480,23 474,23 471,27 471,31 473,33 476,34 479,32 479,28 481,24ZM370,23 368,25 369,30 373,34 378,33 379,32 379,26 374,23ZM426,0 425,2 421,2 420,3 420,22 424,25 428,24 430,21 430,4 429,2 427,2Z\"/><path fill=\"#f3f1e7\" fill-rule=\"evenodd\" d=\"M166,198 162,197 161,198 152,199 151,200 138,202 137,203 130,203 127,201 128,202 127,205 128,206 138,206 144,204 154,203 156,202 157,199 158,202 159,201 164,201 164,199ZM97,183 97,187 102,190 113,189 115,191 115,196 116,197 119,195 121,198 118,194 118,185 117,184 116,185 111,185 110,186 103,187ZM185,162 185,163 190,167 196,170 204,170 210,168 216,168 217,167 225,166 229,164 229,162 224,162 218,164 213,164 212,165 207,165 206,166 198,167 195,166 188,161ZM558,148 559,150 564,150 565,153 570,152 568,152 566,150 566,149 569,148 569,147 559,147ZM308,139 305,139 303,143 305,143 306,140ZM80,99 81,98 85,98 86,99 85,100 81,100ZM244,90 243,92 244,94 244,120 243,121 244,118 246,117 247,115 247,104 246,103 247,101 247,95 246,92 245,92ZM302,87 302,91 306,92 313,96 316,99 320,106 322,112 322,119 321,120 321,123 319,129 321,129 323,127 325,122 325,110 324,109 324,106 321,100 312,91ZM94,86 92,87 91,89 92,94 90,96 79,96 78,100 81,100 83,102 81,107 82,108 81,109 81,112 82,113 82,117 81,118 82,121 81,128 82,130 81,132 84,137 84,140 85,141 87,140 89,141 87,138 86,131 85,130 85,107 86,104 90,100 94,100 98,98ZM101,71 104,72 109,70 113,70 114,68 117,68 105,68ZM158,54 159,58 156,61 152,62 151,64 150,63 149,66 151,66 158,72 163,79 168,91 168,96 169,97 168,104 164,110 170,115 177,127 177,155 172,161 172,166 175,166 175,163 179,159 180,153 182,150 180,147 180,126 177,118 169,109 172,104 172,92 168,80 162,71 157,66 158,64 164,62 163,58 161,56 162,55 159,55ZM189,30 186,29 186,31 184,32 184,33 185,32 189,32Z\"/><path fill=\"#d2263b\" fill-rule=\"evenodd\" d=\"M464,55 458,57 455,57 454,58 451,58 450,59 440,60 439,62 436,61 435,62 427,63 426,64 420,64 414,69 412,72 412,79 411,80 412,90 413,91 413,107 411,111 411,115 409,116 410,118 413,120 424,120 425,119 435,118 436,117 444,116 445,115 450,115 455,113 457,114 458,107 460,103 461,95 464,89 464,85 467,78 466,75 466,64 467,62 466,61 466,57Z\"/><path fill=\"#e73d4e\" fill-rule=\"evenodd\" d=\"M438,38 429,38 424,40 419,40 418,41 414,41 413,42 409,42 408,43 404,43 398,45 388,46 384,49 383,52 383,100 384,103 388,107 390,107 393,110 398,112 403,116 413,121 420,121 413,121 408,117 408,116 410,115 410,111 412,107 412,91 411,90 410,80 411,79 411,72 413,69 420,63 426,63 427,62 431,62 436,60 439,61 440,59 450,58 451,57 454,57 463,54 466,56 462,52 459,51 447,43 445,43Z\"/><path fill=\"#cc6789\" fill-rule=\"evenodd\" d=\"M67,84 64,85 25,115 29,120 65,147 67,147 67,132 69,130 80,130 80,105 81,104 81,101 69,101 67,99Z\"/><path fill=\"#e2cfb4\" fill-rule=\"evenodd\" d=\"M507,210 506,211 504,209 502,209 496,211 495,221 497,224 497,229 498,231 504,231 506,228 506,223 505,221 507,216 506,215 507,214 506,213ZM548,198 546,200 546,204 550,208 555,209 559,204 558,201 555,198ZM175,178 174,180 172,180 172,194 171,195 171,199 169,200 174,198 175,196ZM501,167 505,168 508,171 508,173 506,176 506,182 507,183 506,184 502,181 503,178 503,171 500,168ZM242,152 240,154 239,153 239,156 236,160 233,160 232,161 233,164 237,164 241,161 242,159ZM419,139 419,145 420,146 419,149 420,148 421,149 422,148 425,148 426,147 427,148 429,147 430,149 432,150 431,149 432,143 429,138 424,138 423,137ZM275,132 275,134 277,137 284,142 287,142 292,145 290,151 287,156 290,154 291,156 297,146 299,144 302,144 304,139 303,140 298,140 296,141 295,140 287,139 283,136 278,137 275,134ZM80,132 75,131 77,131 78,134 73,137 73,143 73,138 75,136 81,134 83,137ZM323,128 321,130 319,130 318,128 316,132 309,138 307,138 309,139 307,140 306,143 315,138ZM373,125 376,125 380,129 380,131 375,136 371,136 369,134 370,131 369,128ZM376,125 373,125 369,128 368,134 372,137 374,137 377,135 380,131 380,129ZM350,116 348,119 343,121 333,136 333,137 334,135 336,136 335,139 337,138 338,135 347,123 348,120 350,118ZM471,111 467,122 465,133 463,137 463,141 461,145 461,148 457,159 457,163 454,171 454,174 456,179 460,183 463,184 468,188 487,198 491,198 491,195 495,193 502,193 504,191 509,191 508,188 507,190 506,189 506,185 507,184 506,182 506,177 508,172 510,170 509,167 507,165 508,164 510,165 507,163 503,163 504,164 503,165 498,165 496,160 497,159 497,150 502,144 506,144 507,146 508,145 516,151 515,152 512,151 514,153 514,159 512,161 510,159 508,159 511,160 513,163 514,162 513,161 514,159 517,161 515,159 516,157 518,158 520,155 521,156 520,155 521,153 522,154 521,152 522,151 520,150 521,149 534,149 536,152 539,152 540,153 540,157 539,158 536,158 536,160 533,165 534,164 535,166 533,168 532,167 534,169 530,171 528,175 524,178 523,181 520,181 519,182 520,185 518,186 517,188 518,187 519,188 525,188 526,187 530,187 535,185 539,185 542,182 542,179 543,178 543,131 541,129 538,128 537,129 527,130 526,131 525,130 523,132 518,132 517,131 516,133 506,135 504,129 498,125 494,118 490,118 489,117 490,116 487,114 487,110 486,109 484,110 479,110 478,111ZM303,99 297,99 299,100 298,101 293,101 290,103 290,104 292,102 293,103 294,102 298,102 299,103 300,102 303,103 308,107 310,112 310,120 302,129 299,129 296,131 295,129 289,127 296,131 300,129 301,131 299,133 300,132 304,132 307,130 312,125 314,120 314,111 312,106 308,102ZM378,81 378,103 380,107 383,110 391,115 391,110 387,108 382,102 381,99 381,81ZM346,78 347,83 350,85 366,85 369,83 369,76 368,75 364,75 363,74 356,74 355,75 354,74 351,74 348,75ZM234,68 231,74 235,77 238,81 239,80 242,81 244,83 236,73 238,68 237,69Z\"/><path fill=\"#f1db9d\" fill-rule=\"evenodd\" d=\"M492,212 489,217 490,219 490,223 493,226 493,228 495,230 494,231 497,231 496,229 496,224 494,221 494,215 495,212ZM508,209 507,212 508,214 507,215 508,216 506,221 507,223 507,228 505,231 508,231 511,227 511,223 510,222 510,215 511,214 509,212ZM452,195 453,196 452,197 450,196 448,197 449,196 454,197 456,199 457,202 456,205 451,209 444,209 444,210 448,210 450,211 451,209 455,207 457,208 457,207 455,206 457,204 457,201 456,200 457,199 455,198 456,197ZM507,173 508,176 507,177 507,182 506,183 505,182 505,176ZM513,159 515,162 513,164 511,162ZM507,159 510,158 512,160 509,161ZM286,154 284,158 284,162 286,165 292,168 302,176 307,178 308,177 309,178 314,174 314,173 309,177 305,177 297,172 293,168 289,167 284,161 284,158 289,151ZM555,151 559,146 568,146 569,145 571,146 572,145 573,146 578,146 581,150 581,153 580,155 577,157 566,159 565,158 560,158 556,155ZM502,145 498,150 498,159 497,160 498,161 498,164 503,164 502,163 503,162 507,162 510,164 508,165 510,167 511,170 508,174 507,171 505,169 501,168 504,171 504,178 503,181 505,183 507,182 508,183 507,185 507,189 508,187 510,190 512,189 518,189 517,186 519,185 518,182 520,180 523,180 523,178 527,175 529,172 530,174 529,171 530,170 531,171 530,170 534,168 533,167 535,164 534,165 533,163 535,160 535,158 536,157 539,157 539,153 536,153 534,150 521,150 523,151 522,152 523,154 522,155 521,154 520,156 519,155 520,157 518,159 517,159 515,156 517,160 515,161 513,159 513,153 512,152 515,151 516,153 517,151 516,152 508,146 507,147 506,145ZM556,143 557,144 557,147 554,150 552,150 551,148 552,147 553,148 553,146 555,145ZM585,148 581,143 573,140 572,142 570,140 571,139 569,138 566,138 561,140 560,139 558,142 557,141 553,145 551,143 551,148 550,149 551,160 552,159 551,158 551,155 554,153 559,158 558,159 559,162 561,162 562,160 563,162 564,161 565,162 566,161 571,161 575,158 576,159 578,157 579,158 580,156 583,157 585,153 583,150 585,149ZM417,138 417,143 416,144 415,143 415,145 414,146 413,145 412,147 413,148 413,154 418,158 420,161 423,160 426,162 428,162 430,160 429,159 434,155 433,152 436,151 435,149 436,147 433,145 434,144 431,140 431,138 430,138 433,143 433,146 432,147 433,150 431,153 431,155 427,159 424,160 418,153 418,147 419,146 418,145 418,138ZM368,124 369,127 368,128 368,131 366,132 366,133 372,138 371,139 372,140 375,140 380,132 380,133 374,138 370,137 367,134 367,132 368,131 368,128 372,125 370,126ZM19,111 17,114 17,117 20,121 24,123 48,142 51,143 64,154 69,155 72,153 73,150 73,144 73,149 72,151 69,154 64,154 53,144 50,143 39,134 36,133 18,118 17,115 18,113 25,107ZM516,105 522,107 527,111 532,113 535,116 539,117 541,119 539,117 531,113 528,110 518,105ZM557,94 559,96 559,102 553,107 548,106 546,104 546,99 551,94 554,93ZM558,92 555,93 553,92 551,93 550,95 546,96 545,98 546,99 544,100 544,101 546,102 545,103 546,107 549,106 551,107 553,110 555,110 557,108 556,106 557,104 561,101 561,98 562,97 561,95 561,98 560,99 559,98 559,95 557,94 559,93ZM284,89 275,94 271,99 270,103 267,104 262,113 262,119 264,123 267,126 266,123 262,119 263,111 271,102 272,99 274,98 279,92ZM64,78 60,80 52,87 45,91 42,95 40,95 36,98 34,101 30,102 27,106ZM66,77 69,77 73,82 73,94 74,95 87,95 75,95 73,93 73,87 74,86 73,85 73,80 70,77ZM373,78 372,80 370,76 371,75 370,76 369,75 370,76 370,83 366,86 350,86 345,84 351,89 354,89 356,91 361,91 364,90 363,89 364,87 366,87 373,82ZM499,72 502,72 507,76 507,92 506,95 503,98 502,97 498,97 496,95 496,91 494,87 494,83 495,82 494,80 496,77 496,75ZM511,74 506,73 502,70 500,71 499,69 498,71 497,70 495,71 496,70 497,72 494,75 491,76 492,78 490,80 489,77 487,80 487,87 491,95 492,94 494,96 495,95 499,99 499,100 497,101 498,104 496,106 490,107 496,106 497,105 502,105 503,104 514,104 506,104 504,102 507,101 507,99 507,100 505,101 504,98 506,96 509,90 511,91 515,87 516,84 516,81 514,77ZM345,73 348,71 350,73 349,74 351,73 354,73 355,74 356,73 367,74 365,72 367,71 360,67 354,67 349,69ZM311,55 314,58 319,67 323,71 323,73 325,74 315,59ZM307,54 305,54 299,57 285,67 284,74 289,80 284,74 284,70 285,68 295,60 298,59 303,55ZM440,33 442,33 447,37 466,47 472,53 472,54 467,47 465,47 460,43 454,41 451,38 446,36 444,34ZM383,25 380,29 380,32 378,34 380,34 381,31 383,32 384,30ZM471,21 471,24 469,28 470,29 469,32 470,32 472,35 477,35 478,34 477,35 473,34 470,31 470,27 471,25 476,21 481,23 481,22 478,21 473,21 472,22ZM414,0 412,3 412,8 411,9 412,16 415,23 421,28 420,31 422,32 419,34 416,34 425,33 426,32 438,32 430,32 429,31 430,29 429,27 430,26 431,27 433,26 432,22 436,15 436,8 437,7 432,0 429,0 431,3 431,21 428,25 424,26 419,22 419,8 418,7 418,4 422,0Z\"/>"
};
//#endregion
//#region src/games/cubes-of-europe/art.tsx
function Y({ color: e }) {
	return /* @__PURE__ */ p("svg", {
		width: "100%",
		height: "100%",
		viewBox: "0 0 64 66",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M6 17 32 4 58 17 58 48 32 62 6 48Z",
				fill: v[e],
				stroke: "#31575a",
				strokeWidth: "2.5",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M6 17 32 30 58 17 32 4Z",
				fill: "white",
				opacity: ".27"
			}),
			/* @__PURE__ */ f("path", {
				d: "M32 30 58 17 58 48 32 62Z",
				fill: "#173f40",
				opacity: ".21"
			}),
			/* @__PURE__ */ f("path", {
				d: "M6 17 32 30 32 62M32 30 58 17",
				fill: "none",
				stroke: "#31575a",
				strokeWidth: "1.4",
				opacity: ".5"
			}),
			/* @__PURE__ */ f("text", {
				x: "18",
				y: "43",
				textAnchor: "middle",
				fontSize: "15",
				fill: "#234648",
				children: y[e]
			})
		]
	});
}
function X({ value: e }) {
	return /* @__PURE__ */ p("svg", {
		width: "100%",
		height: "100%",
		viewBox: "0 0 64 64",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("rect", {
				x: "4",
				y: "6",
				width: "56",
				height: "55",
				rx: "10",
				fill: "#d2c2a9"
			}),
			/* @__PURE__ */ f("rect", {
				x: "4",
				y: "3",
				width: "56",
				height: "55",
				rx: "10",
				fill: "#fff9eb",
				stroke: "#31575a",
				strokeWidth: "2"
			}),
			(e === 1 ? [[32, 32]] : e === 2 ? [[19, 19], [45, 45]] : e === 3 ? [
				[19, 19],
				[32, 32],
				[45, 45]
			] : e === 4 ? [
				[19, 19],
				[45, 19],
				[19, 45],
				[45, 45]
			] : e === 5 ? [
				[19, 19],
				[45, 19],
				[32, 32],
				[19, 45],
				[45, 45]
			] : [
				[19, 18],
				[45, 18],
				[19, 32],
				[45, 32],
				[19, 46],
				[45, 46]
			]).map(([e, t], n) => /* @__PURE__ */ f("circle", {
				cx: e,
				cy: t - 2,
				r: "4.5",
				fill: "#31575a"
			}, n))
		]
	});
}
function _e() {
	return /* @__PURE__ */ f("svg", {
		viewBox: "82 39 104 151",
		"aria-hidden": "true",
		children: /* @__PURE__ */ f("g", { dangerouslySetInnerHTML: { __html: ge.B } })
	});
}
function ve({ card: e }) {
	return /* @__PURE__ */ f("svg", {
		className: "ce-effect-glyph",
		viewBox: "0 0 600 232",
		"aria-hidden": "true",
		children: /* @__PURE__ */ f("g", { dangerouslySetInnerHTML: { __html: ge[C[e].id] } })
	});
}
function Z({ card: e }) {
	let t = J();
	return /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("b", { children: C[e].id }),
		/* @__PURE__ */ f(ve, { card: e }),
		/* @__PURE__ */ f("span", {
			className: "ce-effect-description",
			children: t(C[e].id)
		})
	] });
}
var ye = "3,33 20,3 54,3 71,33 54,63 20,63";
function be({ player: e, index: t, legal: n, onClick: r }) {
	let i = J(), a = C[e.card].land[t], o = x[t], { ref: s } = u(`cell:${e.rid}:${t}`), { ref: c, hidden: l } = u(`cube:${e.rid}:${t}`);
	return /* @__PURE__ */ p("button", {
		ref: s,
		type: "button",
		className: "ce-cell",
		"data-legal": n,
		"data-filled": e.filled[t],
		disabled: !n,
		"aria-label": i("place", {
			n: t + 1,
			color: i(a),
			value: o.die
		}),
		onClick: () => r?.(t),
		style: {
			left: `${o.x / 3.6}%`,
			top: `${o.y / 4}%`
		},
		children: [
			/* @__PURE__ */ p("svg", {
				className: "ce-hex",
				viewBox: "0 0 74 66",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ f("polygon", {
						points: ye,
						fill: v[a],
						stroke: "#31575a",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ f("polygon", {
						points: "7,33 22,7 52,7 67,33 52,59 22,59",
						fill: "white",
						opacity: ".13"
					}),
					n && /* @__PURE__ */ f("polygon", {
						points: ye,
						fill: "none",
						stroke: "#fffdf2",
						strokeWidth: "3",
						strokeDasharray: "7 5",
						children: /* @__PURE__ */ f("animate", {
							attributeName: "stroke-dashoffset",
							values: "24;0",
							dur: "1s",
							repeatCount: "indefinite"
						})
					})
				]
			}),
			/* @__PURE__ */ f("span", {
				className: "ce-cell-die",
				children: /* @__PURE__ */ f(X, { value: o.die })
			}),
			/* @__PURE__ */ f("span", {
				className: "ce-cell-mark",
				children: y[a]
			}),
			e.filled[t] && /* @__PURE__ */ f("span", {
				className: "ce-land-cube",
				ref: c,
				style: { visibility: l ? "hidden" : void 0 },
				children: /* @__PURE__ */ f(Y, { color: a })
			})
		]
	});
}
function xe({ player: e, legal: t = [], onClick: n }) {
	return /* @__PURE__ */ p("div", {
		className: "ce-land",
		children: [/* @__PURE__ */ p("svg", {
			viewBox: "0 0 360 400",
			className: "ce-land-paper",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ f("rect", {
					x: "3",
					y: "3",
					width: "354",
					height: "394",
					rx: "14",
					fill: "#f6edd9",
					stroke: "#c8b897",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ f("path", {
					d: "M5 327Q60 300 120 325T240 325T355 315V395H5Z",
					fill: "#b9d1b5"
				}),
				/* @__PURE__ */ f("path", {
					d: "M5 362Q65 330 135 353T260 355T355 350V395H5Z",
					fill: "#8fb5a4",
					opacity: ".45"
				}),
				/* @__PURE__ */ f("text", {
					x: "325",
					y: "47",
					fontSize: "33",
					fill: "#ad8a50",
					fontFamily: "Georgia,serif",
					textAnchor: "middle",
					children: C[e.card].id
				})
			]
		}), x.map((r, i) => /* @__PURE__ */ f(be, {
			player: e,
			index: i,
			legal: t.includes(i),
			onClick: n
		}, i))]
	});
}
//#endregion
//#region src/games/cubes-of-europe/view-player.tsx
function Q({ name: e, children: t, className: n = "" }) {
	let { ref: r, hidden: i } = u(e);
	return /* @__PURE__ */ f("span", {
		ref: r,
		className: n,
		style: { visibility: i ? "hidden" : void 0 },
		children: t
	});
}
function Se({ name: e, children: t }) {
	let { ref: n, hidden: r } = u(e);
	return /* @__PURE__ */ f("div", {
		className: "ce-market-card",
		ref: n,
		style: { visibility: r ? "hidden" : void 0 },
		children: t
	});
}
var Ce = {
	red: "red",
	white: "white",
	blue: "blue",
	worker: "bonus",
	shift: "shift",
	k: "k",
	m: "m",
	n: "n",
	p: "p",
	q: "q"
};
function we({ player: e }) {
	let t = J();
	return /* @__PURE__ */ p("div", {
		className: "ce-permanents",
		children: [/* @__PURE__ */ f("h3", { children: t("permanent") }), /* @__PURE__ */ f("div", {
			className: "ce-permanent-list",
			children: e.tucked.map((n) => /* @__PURE__ */ f(Q, {
				name: `permanent-card:${e.rid}:${n}`,
				children: /* @__PURE__ */ p("details", {
					className: "ce-effect-card",
					children: [/* @__PURE__ */ f("summary", { children: /* @__PURE__ */ f(Z, { card: n }) }), n === 14 && e.copy !== null && /* @__PURE__ */ p("p", { children: [
						t("copy"),
						"：",
						C[e.copy].id,
						" · ",
						t(C[e.copy].id)
					] })]
				})
			}, n))
		})]
	});
}
function Te({ public: e, members: t, myRid: n, send: r }) {
	let l = e, u = J(), m = c((e) => e.locale), [h, ee] = i(0), [te, g] = i(0), [v, y] = i(-1), [b, S] = i(""), w = l.players[l.actor], T = w.rid === n, E = l.players.find((e) => e.rid === (b || n)) ?? w, D = T && E.rid === n, O = w.used[h] ? Math.max(0, w.used.findIndex((e) => !e)) : h, k = l.effects.length ? Math.min(te, l.effects.length - 1) : -1, A = l.effects[k], j = l.phase === "act" && !A && !w.used[O], M = A?.kind === "red", N = A?.kind === "white", ne = D ? l.phase === "setup" ? C[E.card].land.flatMap((e, t) => e === "y" ? [t] : []) : j || M ? x.flatMap((e, t) => oe(E, t) && (M || e.die === w.dice[O]) ? [t] : []) : [] : [], re = se(l.main, l.side), P = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? s(n, m) : e;
	}, F = (e) => {
		r(e), y(-1), g(0);
	}, I = T ? l.phase === "setup" ? u("start") : l.phase === "settle" ? u("settle") : l.phase === "tuck" ? u("tuck", { card: C[l.side ?? 0].id }) : w.holding.length === 3 && (j || N) ? u("replace") : l.effects.length ? u("effects") : l.phase === "roll" ? u("roll") : u("act") : u("waiting", { name: P(w.rid) }), L = T && ["act", "startTurn"].includes(l.phase) && !w.used[O] && (j && w.workers > 0 || A?.kind === "shift" || A?.kind === "k" && A.die === O);
	return /* @__PURE__ */ f("div", {
		className: "ce-root",
		children: /* @__PURE__ */ f(a, {
			className: "ce-screen",
			banner: /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ p("header", {
					className: "ce-header",
					children: [/* @__PURE__ */ f("h1", { children: u("name") }), /* @__PURE__ */ p("span", { children: [u("round", { n: l.round }), !l.config.rivals && /* @__PURE__ */ p(d, { children: [" · ", u("pass", { n: l.pass })] })] })]
				}),
				/* @__PURE__ */ f("div", {
					className: "ce-seats",
					children: l.players.map((e) => /* @__PURE__ */ p("button", {
						type: "button",
						className: "ce-seat",
						"data-current": e.rid === w.rid,
						"data-selected": e.rid === E.rid,
						onClick: () => S(e.rid),
						children: [
							/* @__PURE__ */ f("span", { children: P(e.rid) }),
							/* @__PURE__ */ f("b", { children: l.scores[e.rid].total }),
							/* @__PURE__ */ f("small", { children: e.rid === w.rid ? "◆" : "◇" })
						]
					}, e.rid))
				}),
				/* @__PURE__ */ f("div", {
					className: "ce-banner",
					children: /* @__PURE__ */ f(o, {
						tone: T && l.phase !== "settle" ? "accent" : "info",
						text: I,
						accent: "#31575a"
					})
				})
			] }),
			overlay: T && l.effects.length > 0 ? /* @__PURE__ */ f("div", {
				className: "ce-effect-choice",
				children: l.effects.map((e, t) => /* @__PURE__ */ f("button", {
					type: "button",
					"data-selected": t === k,
					onClick: () => g(t),
					children: u(Ce[e.kind])
				}, `${t}:${e.kind}`))
			}) : void 0,
			actionsHeight: "ce-actions-height",
			actions: /* @__PURE__ */ p("div", {
				className: "ce-actions",
				children: [/* @__PURE__ */ f("div", {
					className: "ce-dice",
					children: w.dice.map((e, t) => /* @__PURE__ */ p("button", {
						type: "button",
						className: "ce-die",
						"data-selected": t === O,
						"data-used": w.used[t] || l.phase === "setup" || l.phase === "roll",
						disabled: !T || w.used[t] || !["act", "startTurn"].includes(l.phase),
						onClick: () => ee(t),
						"aria-label": u("chooseDie", { n: t + 1 }),
						children: [/* @__PURE__ */ f(Q, {
							name: `die:${w.rid}:${t}`,
							children: /* @__PURE__ */ f(X, { value: e })
						}), w.used[t] && /* @__PURE__ */ f("span", {
							className: "ce-used",
							children: "✓"
						})]
					}, t))
				}), /* @__PURE__ */ p("div", {
					className: "ce-action-tools",
					children: [/* @__PURE__ */ p("div", {
						className: "ce-adjust",
						children: [
							/* @__PURE__ */ f("button", {
								type: "button",
								disabled: !L,
								onClick: () => F({
									type: "adjust",
									die: O,
									delta: -1,
									effect: k
								}),
								"aria-label": u("adjustDown"),
								children: "−"
							}),
							/* @__PURE__ */ p(Q, {
								name: `workers:${w.rid}`,
								className: "ce-worker-read",
								children: [/* @__PURE__ */ f(_e, {}), /* @__PURE__ */ f("b", { children: w.workers })]
							}),
							/* @__PURE__ */ f("button", {
								type: "button",
								disabled: !L,
								onClick: () => F({
									type: "adjust",
									die: O,
									delta: 1,
									effect: k
								}),
								"aria-label": u("adjustUp"),
								children: "+"
							})
						]
					}), T && l.phase === "roll" ? /* @__PURE__ */ f("button", {
						type: "button",
						className: "ce-primary",
						onClick: () => F({ type: "roll" }),
						children: u("roll")
					}) : T && l.phase === "tuck" ? /* @__PURE__ */ p("div", {
						className: "ce-tuck-actions",
						children: [/* @__PURE__ */ f("button", {
							type: "button",
							className: "ce-primary",
							onClick: () => F({
								type: "tuck",
								accept: !0
							}),
							children: u("tuck", { card: C[l.side ?? 0].id })
						}), /* @__PURE__ */ f("button", {
							type: "button",
							className: "ce-quiet",
							onClick: () => F({
								type: "tuck",
								accept: !1
							}),
							children: u("decline")
						})]
					}) : T && A ? /* @__PURE__ */ p("div", {
						className: "ce-effect-tools",
						children: [
							(A.kind === "blue" || A.kind === "worker") && /* @__PURE__ */ f("button", {
								type: "button",
								className: "ce-primary",
								onClick: () => F({
									type: "worker",
									die: O,
									effect: k
								}),
								children: u("worker")
							}),
							[
								"m",
								"n",
								"p",
								"q"
							].includes(A.kind) && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
								type: "button",
								className: "ce-primary",
								disabled: w.workers < (A.kind === "q" ? 2 : 1),
								onClick: () => F({
									type: "use",
									effect: k,
									choice: A.kind === "p" ? "white" : "red"
								}),
								children: u(A.kind === "p" ? "whiteChoice" : "redChoice")
							}), (A.kind === "m" || A.kind === "q") && /* @__PURE__ */ f("button", {
								type: "button",
								className: "ce-primary",
								disabled: w.workers < (A.kind === "q" ? 2 : 1),
								onClick: () => F({
									type: "use",
									effect: k,
									choice: "white"
								}),
								children: u("whiteChoice")
							})] }),
							/* @__PURE__ */ f("button", {
								type: "button",
								className: "ce-quiet",
								onClick: () => F({
									type: "skip",
									effect: k
								}),
								children: u("skip")
							})
						]
					}) : T && l.phase === "act" && w.used.every(Boolean) ? /* @__PURE__ */ f("button", {
						type: "button",
						className: "ce-primary",
						onClick: () => F({ type: "finish" }),
						children: u("finish")
					}) : /* @__PURE__ */ f("button", {
						type: "button",
						className: "ce-primary",
						disabled: !T || !j,
						onClick: () => F({
							type: "worker",
							die: O,
							effect: -1
						}),
						children: u("worker")
					})]
				})]
			}),
			children: /* @__PURE__ */ p("div", {
				className: "ce-table",
				children: [
					/* @__PURE__ */ p("section", {
						className: "ce-market-area",
						children: [/* @__PURE__ */ p("div", {
							className: "ce-market-heading",
							children: [/* @__PURE__ */ f("h2", { children: u("market") }), /* @__PURE__ */ p("span", { children: [
								l.mainCount,
								" / ",
								l.sideCount
							] })]
						}), /* @__PURE__ */ f("div", {
							className: "ce-market",
							children: [0, 1].map((e) => /* @__PURE__ */ p(Se, {
								name: e ? "pile:side" : "pile:main",
								children: [
									/* @__PURE__ */ f("div", {
										className: "ce-pile-label",
										children: /* @__PURE__ */ p(Q, {
											name: e ? "side" : "main",
											children: [
												u(e ? "side" : "main"),
												" · ",
												(e ? l.side : l.main) === null ? "—" : C[e ? l.side : l.main].id
											]
										})
									}),
									[
										0,
										1,
										2
									].map((t) => {
										let n = e * 3 + t, r = re[n], i = z(w, r.color), a = T && r.card !== null && (j && r.value === w.dice[O] && l.occupied[n] < (l.players.length === 2 ? 1 : 2) || N) && (w.holding.length < 3 || v >= 0);
										return /* @__PURE__ */ f(Q, {
											name: `market:${n}`,
											className: "ce-market-anchor",
											children: /* @__PURE__ */ p("button", {
												type: "button",
												className: "ce-market-slot",
												"data-legal": a,
												disabled: !a,
												onClick: () => F({
													type: "take",
													slot: n,
													die: O,
													effect: k,
													replace: v
												}),
												"aria-label": u("take", {
													color: u(r.color),
													n: r.value
												}),
												children: [
													/* @__PURE__ */ f("svg", {
														className: "ce-marching",
														viewBox: "0 0 160 60",
														preserveAspectRatio: "none",
														"aria-hidden": "true",
														children: /* @__PURE__ */ f("rect", {
															x: "2",
															y: "2",
															width: "156",
															height: "56",
															rx: "5",
															fill: "none",
															stroke: "#31575a",
															strokeWidth: "2",
															strokeDasharray: "8 5",
															children: /* @__PURE__ */ f("animate", {
																attributeName: "stroke-dashoffset",
																values: "26;0",
																dur: "1s",
																repeatCount: "indefinite"
															})
														})
													}),
													/* @__PURE__ */ f(X, { value: r.value }),
													/* @__PURE__ */ f(Q, {
														name: `market-cube:${n}`,
														className: "ce-market-cube",
														children: /* @__PURE__ */ f(Y, { color: r.color })
													}),
													/* @__PURE__ */ f("span", {
														className: "ce-market-count",
														children: i
													}),
													/* @__PURE__ */ f("span", {
														className: "ce-occupied",
														children: l.occupied[n] > 0 ? "●".repeat(l.occupied[n]) : ""
													})
												]
											})
										}, n);
									}),
									/* @__PURE__ */ f(Q, {
										name: e ? "effect:side" : "effect:main",
										className: "ce-effect-anchor",
										children: /* @__PURE__ */ f("details", {
											className: "ce-market-effect",
											children: /* @__PURE__ */ f("summary", { children: (e ? l.side : l.main) === null ? "—" : /* @__PURE__ */ f(Z, { card: e ? l.side : l.main }) })
										})
									})
								]
							}, e))
						})]
					}),
					/* @__PURE__ */ p("section", {
						className: "ce-estate",
						children: [
							/* @__PURE__ */ p("div", {
								className: "ce-land-heading",
								children: [/* @__PURE__ */ f("h2", { children: u("land", { card: C[E.card].id }) }), /* @__PURE__ */ f("span", { children: P(E.rid) })]
							}),
							/* @__PURE__ */ f(xe, {
								player: E,
								legal: ne,
								onClick: (e) => F(l.phase === "setup" ? {
									type: "start",
									cell: e
								} : {
									type: "place",
									cell: e,
									die: O,
									effect: k
								})
							}),
							/* @__PURE__ */ p("div", {
								className: "ce-holding",
								children: [/* @__PURE__ */ f("h3", { children: u("holding") }), [
									0,
									1,
									2
								].map((e) => /* @__PURE__ */ f(Q, {
									name: `hold:${E.rid}:${e}`,
									className: "ce-hold",
									children: /* @__PURE__ */ f("button", {
										type: "button",
										className: "ce-hold-button",
										"data-selected": e === v,
										disabled: !D || w.holding.length !== 3,
										"aria-label": E.holding[e] ? u("returnCube", { color: u(E.holding[e]) }) : u("empty"),
										onClick: () => y(e === v ? -1 : e),
										children: E.holding[e] && /* @__PURE__ */ f(Q, {
											name: `holdcube:${E.rid}:${e}`,
											children: /* @__PURE__ */ f(Y, { color: E.holding[e] })
										})
									})
								}, e))]
							})
						]
					}),
					/* @__PURE__ */ p("aside", {
						className: "ce-info",
						children: [
							/* @__PURE__ */ p("div", {
								className: "ce-supply",
								children: [/* @__PURE__ */ f("h3", { children: u("supply") }), _.map((e) => /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f(Q, {
									name: `supply:${E.rid}:${e}`,
									children: /* @__PURE__ */ f(Y, { color: e })
								}), /* @__PURE__ */ f("span", { children: z(E, e) })] }, e))]
							}),
							/* @__PURE__ */ f(we, { player: E }),
							D && l.copyOpen && ["roll", "startTurn"].includes(l.phase) && E.tucked.includes(14) && /* @__PURE__ */ p("label", {
								className: "ce-copy",
								children: [u("copy"), /* @__PURE__ */ f("select", {
									value: E.copy ?? "",
									onChange: (e) => F({
										type: "copy",
										card: Number(e.target.value)
									}),
									children: E.tucked.filter((e) => e !== 14).map((e) => /* @__PURE__ */ p("option", {
										value: e,
										children: [
											C[e].id,
											" · ",
											u(C[e].id)
										]
									}, e))
								})]
							})
						]
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/cubes-of-europe/bot.ts
function Ee(e) {
	return {
		...structuredClone(e),
		seed: 0,
		cursor: 0,
		main: e.main === null ? [] : [e.main],
		side: e.side === null ? [] : [e.side],
		serial: 0,
		settleAt: 0,
		settleStep: "tuck",
		skipLeft: 0
	};
}
function De(e) {
	let t = e.players[e.actor];
	if (e.phase === "setup") return C[t.card].land.flatMap((e, t) => e === "y" ? [{
		type: "start",
		cell: t
	}] : []);
	if (e.phase === "roll") return [{ type: "roll" }];
	if (e.phase === "tuck") return [{
		type: "tuck",
		accept: !0
	}, {
		type: "tuck",
		accept: !1
	}];
	if (e.phase !== "act" && e.phase !== "startTurn") return [];
	let n = [], r = (r) => {
		"code" in q.reduce(Ee(e), r, { by: t.rid }) || n.push(r);
	}, i = e.effects.length ? e.effects.map((e, t) => t) : [-1];
	for (let e of i) {
		e >= 0 && (r({
			type: "skip",
			effect: e
		}), r({
			type: "use",
			effect: e,
			choice: "red"
		}), r({
			type: "use",
			effect: e,
			choice: "white"
		}));
		for (let n = 0; n < 2; n++) {
			r({
				type: "worker",
				die: n,
				effect: e
			});
			for (let t of [-1, 1]) r({
				type: "adjust",
				die: n,
				delta: t,
				effect: e
			});
			for (let t = 0; t < 19; t++) r({
				type: "place",
				cell: t,
				die: n,
				effect: e
			});
			for (let i = 0; i < 6; i++) for (let a of t.holding.length === 3 ? [
				0,
				1,
				2
			] : [-1]) r({
				type: "take",
				slot: i,
				die: n,
				effect: e,
				replace: a
			});
		}
	}
	return r({ type: "finish" }), n;
}
var Oe = {
	progress: .85,
	yellow: 2.8,
	holding: 1.25,
	worker: .12,
	lookahead: !0
};
function $(e, t, n) {
	let r = B(e).total + e.filled.filter(Boolean).length * .5 + e.workers * n.worker, i = t.config.rivals ? t.mainCount : t.pass === 1 ? t.mainCount + t.sideCount : t.mainCount, a = w(e.card);
	for (let t of a) {
		let i = t.filter((t) => e.filled[t]).length;
		i < t.length && (r += n.progress * (t.length * (t.length + 1) / 2) * (i / t.length) ** 2);
	}
	r += e.yellow * n.yellow * Math.min(1, i / 4);
	for (let [t, i] of e.holding.entries()) {
		let o = C[e.card].land.flatMap((t, n) => t === i && !e.filled[n] ? [n] : []), s = o.some((t) => S[t].some((t) => e.filled[t])), c = e.holding.slice(0, t).filter((e) => e === i).length, l = Math.max(1, ...a.filter((e) => e.some((e) => o.includes(e))).map((e) => e.length));
		r += n.holding * (s ? 1 + l * .25 : .45) * .6 ** c + (i === "r" || i === "w" ? .45 : i === "g" ? .2 : 0);
	}
	return r;
}
function ke(e, t = Oe) {
	let n = De(e), r = e.players[e.actor];
	if (!n.length) return null;
	if (e.phase === "roll" || e.phase === "tuck") return n[0];
	let i = $(r, e, t), a = se(e.main, e.side);
	function o(n) {
		if (n.type === "start") return S[n.cell].length + S[n.cell].filter((e) => C[r.card].land[e] === "r" || C[r.card].land[e] === "w").length * .3;
		let o = q.reduce(Ee(e), n, { by: r.rid });
		if ("code" in o) return -1e6;
		let s = $(o.state.players[e.actor], e, t) - i;
		n.type === "take" && z(r, a[n.slot].color) === 0 && (s -= .2), n.type === "skip" && (s -= .01), n.type === "finish" && (s += .01), n.type === "use" && (s += .1), n.type === "adjust" && (s -= .03);
		let c = q.viewFor(o.state, r.rid).public;
		if (t.lookahead && (n.type === "take" || n.type === "adjust" || n.type === "use" || n.type === "place")) {
			let n = De(c).filter((e) => e.type === "place" || e.type === "worker" || e.type === "take" || e.type === "adjust"), i = 0;
			for (let a of n) {
				let n = q.reduce(o.state, a, { by: r.rid });
				"code" in n || (i = Math.max(i, $(n.state.players[e.actor], e, t) - $(o.state.players[e.actor], e, t)));
			}
			s += i * .82;
		}
		return s;
	}
	return n.map((e) => ({
		a: e,
		v: o(e)
	})).sort((e, t) => t.v - e.v)[0].a;
}
var Ae = (e, t) => {
	if (e.public.players[e.public.actor]?.rid !== t.rid) return null;
	let n = De(e.public), r = t.difficulty === "weak" && n.length ? n[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % n.length] : ke(e.public);
	return r ? { action: r } : null;
};
//#endregion
//#region src/games/cubes-of-europe/fx.tsx
function je(e) {
	let t = Math.min(e.w, e.h * 64 / 66), n = t * 66 / 64;
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - n) / 2,
		w: t,
		h: n
	};
}
function Me({ from: e, to: t, card: i }) {
	let a = r(null);
	return n(() => {
		let n = a.current?.animate([{
			left: `${e.x}px`,
			top: `${e.y}px`,
			width: `${e.w}px`,
			height: `${e.h}px`
		}, {
			left: `${t.x}px`,
			top: `${t.y}px`,
			width: `${t.w}px`,
			height: `${t.h}px`
		}], {
			duration: 480,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => n?.cancel();
	}, [e, t]), /* @__PURE__ */ f("div", {
		ref: a,
		className: "ce-fx-effect",
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ f(Z, { card: i })
	});
}
function Ne({ card: e }) {
	return /* @__PURE__ */ p("div", {
		className: "ce-fx-market",
		children: [
			/* @__PURE__ */ f("strong", { children: C[e].id }),
			C[e].market.map((e, t) => /* @__PURE__ */ p("div", {
				className: "ce-fx-market-row",
				children: [/* @__PURE__ */ f(X, { value: 6 - t }), /* @__PURE__ */ f(Y, { color: e })]
			}, t)),
			/* @__PURE__ */ f("div", {
				className: "ce-fx-market-effect",
				children: /* @__PURE__ */ f(Z, { card: e })
			})
		]
	});
}
function Pe({ at: e, value: t }) {
	let i = r(null);
	return n(() => {
		let e = i.current?.animate([
			{ transform: "translateY(-25px) rotate(-150deg) scale(.8)" },
			{
				transform: "translateY(-7px) rotate(35deg)",
				offset: .6
			},
			{ transform: "translateY(0) rotate(0)" }
		], {
			duration: 480,
			easing: "ease-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, []), /* @__PURE__ */ f("div", {
		ref: i,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ f(X, { value: t })
	});
}
var Fe = {
	cube(e, t) {
		let n = e.data, r = t.anchor(n.from), i = t.anchor(n.target) ?? t.anchor(n.to);
		if (!r || !i) return null;
		let a = je(r), o = je(i);
		return {
			ms: 480,
			hide: t.queued ? [] : [n.target],
			node: /* @__PURE__ */ f(m, {
				from: a,
				to: o,
				ms: 480,
				children: /* @__PURE__ */ f("div", {
					style: {
						width: a.w,
						height: a.h
					},
					children: /* @__PURE__ */ f(Y, { color: n.color })
				})
			})
		};
	},
	roll(e, t) {
		let n = e.data, r = n.dice.map((n, r) => t.anchor(`die:${e.rid}:${r}`));
		return r.some((e) => !e) ? null : {
			ms: 480,
			hide: t.queued ? [] : n.dice.map((t, n) => `die:${e.rid}:${n}`),
			node: /* @__PURE__ */ f(d, { children: n.dice.map((e, t) => /* @__PURE__ */ f(Pe, {
				at: r[t],
				value: e
			}, t)) })
		};
	},
	adjust(e, t) {
		let n = e.data, r = t.anchor(`die:${e.rid}:${n.die}`);
		return r ? {
			ms: 480,
			node: /* @__PURE__ */ f(h, {
				at: r,
				ms: 480
			})
		} : null;
	},
	worker(e, t) {
		let n = t.anchor(`workers:${e.rid}`);
		return n ? {
			ms: 480,
			node: /* @__PURE__ */ f(h, {
				at: n,
				ms: 480
			})
		} : null;
	},
	tuck(e, t) {
		let n = e.data, r = t.anchor("effect:side"), i = t.anchor(`permanent-card:${e.rid}:${n.card}`);
		return !r || !i ? null : {
			ms: 480,
			hide: t.queued ? [] : [`permanent-card:${e.rid}:${n.card}`],
			node: /* @__PURE__ */ f(Me, {
				from: r,
				to: i,
				card: n.card
			})
		};
	},
	refresh(e, t) {
		let n = t.anchor("pile:main"), r = t.anchor("pile:side"), i = e.data;
		return !n || !r ? null : i.card === void 0 || i.card < 0 ? {
			ms: 480,
			node: /* @__PURE__ */ f(h, {
				at: n,
				ms: 480
			})
		} : {
			ms: 480,
			hide: t.queued ? [] : ["pile:side"],
			node: /* @__PURE__ */ f(m, {
				from: n,
				to: r,
				ms: 480,
				children: /* @__PURE__ */ f("div", {
					style: {
						width: n.w,
						height: n.h
					},
					children: /* @__PURE__ */ f(Ne, { card: i.card })
				})
			})
		};
	}
}, Ie = [
	"territories",
	"colors",
	"workers",
	"green",
	"cards"
];
function Le({ public: e, result: t, members: n, myRid: r, onPlayAgain: a, onBackToLobby: o }) {
	let l = e, u = J(), m = c((e) => e.locale), [h, te] = i(r), [g, _] = i(!0), v = l.players.find((e) => e.rid === h) ?? l.players[0], y = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? s(t, m) : e;
	}, b = t.ranking.map((e) => l.players.find((t) => t.rid === e)), x = b.length === 1, S = l.scores[v.rid].total, C = S >= 34 ? "title4" : S >= 30 ? "title3" : S >= 26 ? "title2" : S >= 22 ? "title1" : "title0";
	return /* @__PURE__ */ p("div", {
		className: "ce-result",
		children: [
			/* @__PURE__ */ p("header", {
				className: "ce-result-header",
				children: [/* @__PURE__ */ f("h1", { children: u("result") }), /* @__PURE__ */ f("p", { children: x ? u(t.winner.length ? "soloVictory" : "soloDefeat") : u("victory", { name: t.winner.map(y).join(" · ") }) })]
			}),
			/* @__PURE__ */ p("div", {
				className: "ce-result-body",
				children: [/* @__PURE__ */ p("section", {
					className: "ce-result-land",
					children: [
						/* @__PURE__ */ p("label", { children: [u("review"), /* @__PURE__ */ f("select", {
							"aria-label": u("review"),
							value: v.rid,
							onChange: (e) => te(e.target.value),
							children: b.map((e) => /* @__PURE__ */ f("option", {
								value: e.rid,
								children: y(e.rid)
							}, e.rid))
						})] }),
						/* @__PURE__ */ f(xe, { player: v }),
						/* @__PURE__ */ f(we, { player: v })
					]
				}), /* @__PURE__ */ p("section", { children: [/* @__PURE__ */ p("p", {
					className: "ce-result-title",
					children: [
						x ? u(C) : y(v.rid),
						" · ",
						S
					]
				}), /* @__PURE__ */ p("div", {
					className: "ce-result-scores",
					children: [/* @__PURE__ */ f("button", {
						type: "button",
						className: "ce-quiet",
						"aria-expanded": g,
						onClick: () => _(!g),
						children: u("score")
					}), /* @__PURE__ */ p("table", { children: [
						/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { children: u("score") }), b.map((e) => /* @__PURE__ */ p("th", { children: [y(e.rid), t.winner.includes(e.rid) ? " ◆" : ""] }, e.rid))] }) }),
						g && /* @__PURE__ */ f("tbody", { children: Ie.map((e) => /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { children: u(e) }), b.map((t) => /* @__PURE__ */ f("td", { children: l.scores[t.rid][e] }, t.rid))] }, e)) }),
						/* @__PURE__ */ f("tfoot", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { children: u("total") }), b.map((e) => /* @__PURE__ */ f("td", { children: l.scores[e.rid].total }, e.rid))] }) })
					] })]
				})] })]
			}),
			/* @__PURE__ */ f("footer", {
				className: "ce-result-footer",
				children: a || o ? /* @__PURE__ */ p(d, { children: [a && /* @__PURE__ */ f(ee, {
					label: u("again"),
					confirmLabel: u("confirmAgain"),
					onConfirm: a
				}), o && /* @__PURE__ */ f(ee, {
					label: u("lobby"),
					confirmLabel: u("confirmLobby"),
					onConfirm: o
				})] }) : /* @__PURE__ */ f("p", { children: u("waitHost") })
			})
		]
	});
}
//#endregion
//#region src/games/cubes-of-europe/options.tsx
function Re({ value: e, onChange: t }) {
	let n = J(), r = E.safeParse(e).data ?? E.parse(void 0);
	return /* @__PURE__ */ p(te, {
		title: n("rivals"),
		children: [/* @__PURE__ */ f(g, {
			checked: r.rivals,
			label: n("rivals"),
			accent: T.accent,
			onChange: () => t({
				...r,
				rivals: !r.rivals
			})
		}), /* @__PURE__ */ f("p", {
			className: "text-sm",
			children: n("rivalsInfo")
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/cubes-of-europe/entry.tsx
var ze = {
	definition: q,
	View: Te,
	bot: Ae,
	fx: Fe,
	OverView: Le,
	Options: Re,
	locales: {
		zh: {
			name: "方块欧陆",
			desc: "用两颗骰子拓展十九格领地，连锁方块效果并建立永久能力。",
			rules: "目标：\n用方块填满同色相邻领地，争取最高分。基础版为单人游戏，取得30分获胜。启用官方Rivals扩展后支持1–4人；多人比较总分，同分者中空格最多的玩家获胜，仍相同则共享胜利。\n准备：\n基础版使用A–I共9张双面牌。洗牌后先移一张至副牌堆，再取一张作为个人领地，其余形成主牌堆。每人有两颗骰子、黄色方块3个，以及红、白、蓝、绿方块各4个。选择一个黄色格放置起始方块，不触发效果。持有区最多容纳3个方块，工人上限为6。\n启用Rivals时使用全部17张牌。多人先留出4张领地牌，余下牌堆顶牌移至副牌堆；每人从留出的牌中获得一张，未用领地牌移出。单人扩展变体先移除4张，再按单人方式设置。先手获得1名工人，其后依次获得2、3、4名。\n流程：\n每回合掷两颗骰子，各使用一次，以任意组合执行以下行动。\n· 获得方块：把一颗骰子放到市场中点数相同的位置，从个人供应获得该处颜色的方块，放入持有区。市场只使用两堆交界处的六个骰位。2人局每位限一颗骰；单人及3–4人局每位可叠两颗。供应耗尽仍可占位，但不获得方块。持有区已满时，先选一个方块退回供应。\n· 放置方块：从持有区把一个方块放到颜色相同、点数与骰子相同的空格，且该格须与已占格相邻。\n· 获得工人：使用任意点数的骰子获得1名工人，超过6名的部分失去。\n每支付1名工人，可将一颗尚未使用的骰子增加或减少1点；1和6可循环调整，允许多次支付。\n颜色效果：\n· 放置红色方块后，可立即从持有区再放置一个方块；忽略骰子限制，仍须满足颜色与相邻要求。\n· 放置白色方块后，可从当前市场任意颜色获得一个方块，忽略骰子和占位限制。\n· 放置蓝色方块后，可获得1名工人。\n红白效果可继续触发连锁。所有颜色及永久效果均可跳过。\n本轮每放置一个新的黄色方块，轮末可从副牌堆顶取得一张永久效果牌；按先手顺序逐张取得，副牌堆空则停止。起始黄色方块不计。绿色方块每个在终局获得1分。\n轮末与结束：\n所有玩家用完两骰及效果后收回骰子，依次取得黄色奖励，再把主牌堆顶牌移到副牌堆顶刷新市场。多人若主牌堆空，游戏结束；否则先手移交下一位。基础单人第一次主牌堆空时，洗副牌堆作为新主牌堆，再按个人领地尚空的黄色格数量刷新市场；第二次用完主牌堆结束。Rivals单人变体第一次用完主牌堆即结束。\n计分：\n· 完整同色相邻领地按大小计分：1格1分，2格3分，3格6分，4格10分；未填满的领地不计分。\n· 每种颜色全部填满获得1分。\n· 每2名剩余工人获得1分，向下取整。\n· 每个绿色方块获得1分，再加永久牌提供的额外分。\n单人0–21分为初晋贵族，22–25分为男爵，26–29分为伯爵，30–33分为侯爵，34分以上为公爵。达到侯爵或更高爵位获得胜利。\n永久效果：\n· A：每放置一个方块后，可以将一颗可用骰子的点数调整1点。\n· B：每获得工人后，可以额外获得1名工人；本效果不触发自身。\n· C：每获得一个方块后，可以将一颗可用骰子的点数调整1点。\n· D：终局获得1分，每2名工人额外获得1分。\n· E：终局每个红色方块额外获得1分。\n· F：每种完成的颜色额外获得1分。\n· G：终局每个绿色方块额外获得1分。\n· H：终局每个蓝色方块额外获得1分。\n· I：终局每个白色方块额外获得1分。\nRivals永久效果：\n· J：终局获得1分，每2个已完成且至少有2格的领地额外获得1分。\n· K：支付工人调整骰子后，可以将同一颗骰子的点数再调整1点。\n· L：每2个已完成的单格领地获得1分。\n· M：放置绿色方块后，可以支付1名工人，执行红色或白色方块的效果。\n· N：放置红色方块后，可以支付1名工人，再执行一次红色方块的效果。\n· P：放置白色方块后，可以支付1名工人，再执行一次白色方块的效果。\n· Q：回合开始掷骰后、使用骰子前，可以支付2名工人，执行红色或白色方块的效果。\n· O：复制自己另一张永久牌；没有可复制牌时终局获得2分。数字版在取得O时先复制已有第一张牌，之后可在自己掷骰前改选已拥有的牌，回合内保持不变。",
			rivals: "Rivals 官方扩展",
			rivalsInfo: "加入J–Q八张牌；支持1–4人。单人使用扩展变体。",
			round: "第 {{n}} 轮",
			pass: "第 {{n}} 趟",
			market: "共享市场",
			main: "主牌堆",
			side: "副牌堆",
			land: "领地 {{card}}",
			workers: "工人",
			holding: "持有区",
			supply: "供应",
			permanent: "永久效果",
			score: "分数",
			start: "选择一个黄色起始格",
			roll: "掷骰",
			act: "选择骰子，再选择市场或领地",
			effects: "处理或跳过可选效果",
			waiting: "等待 {{name}}",
			settle: "轮末结算",
			take: "获得{{color}}方块 · 骰点{{n}}",
			place: "格{{n}}：{{color}}，骰点{{value}}",
			chooseDie: "选择骰子 {{n}}",
			used: "已使用",
			worker: "获得1名工人",
			finish: "结束回合",
			skip: "跳过效果",
			use: "使用效果",
			redChoice: "免费放置",
			whiteChoice: "免费获得",
			red: "红色：免费放置方块",
			white: "白色：免费获得方块",
			blue: "蓝色：获得1名工人",
			bonus: "额外获得1名工人",
			shift: "免费调整一颗可用骰",
			k: "免费再调整同一颗骰",
			m: "支付1工人：红或白效果",
			n: "支付1工人：再执行红色效果",
			p: "支付1工人：再执行白色效果",
			q: "支付2工人：红或白效果",
			tuck: "取得永久牌 {{card}}",
			decline: "放弃此次收牌",
			replace: "持有区已满：选择要退回的方块",
			returnCube: "退回{{color}}方块",
			adjustUp: "骰子增加1点",
			adjustDown: "骰子减少1点",
			copy: "O复制的效果",
			empty: "空",
			y: "黄色",
			r: "红色",
			b: "蓝色",
			g: "绿色",
			w: "白色",
			invalid: "当前无法执行这个行动，请重新选择。",
			A: "放置方块后，可将一颗尚未使用的骰子调整1点。",
			B: "获得工人后，可额外获得1名工人，不触发自身。",
			C: "获得方块后，可将一颗尚未使用的骰子调整1点。",
			D: "终局获得1分，每2名工人额外获得1分。",
			E: "终局每个红色方块额外获得1分。",
			F: "终局每种完成的颜色额外获得1分。",
			G: "终局每个绿色方块额外获得1分。",
			H: "终局每个蓝色方块额外获得1分。",
			I: "终局每个白色方块额外获得1分。",
			J: "终局获得1分，每2个完成的至少2格领地额外获得1分。",
			K: "支付工人调骰后，可将同一颗骰子再调整1点。",
			L: "终局每2个完成的单格领地获得1分。",
			M: "放置绿色方块后，可支付1名工人执行红或白效果。",
			N: "放置红色方块后，可支付1名工人再执行红色效果。",
			O: "复制自己的另一张永久牌；无法复制时终局获得2分。",
			P: "放置白色方块后，可支付1名工人再执行白色效果。",
			Q: "回合掷骰后、使用骰子前，可支付2名工人执行红或白效果。",
			result: "领地结算",
			victory: "{{name}}获胜",
			soloVictory: "领地繁荣，挑战成功",
			soloDefeat: "挑战结束",
			total: "总分",
			territories: "完整领地",
			colors: "完成颜色",
			green: "绿色方块",
			cards: "永久牌奖励",
			review: "查看领地",
			title0: "初晋贵族",
			title1: "男爵",
			title2: "伯爵",
			title3: "侯爵",
			title4: "公爵",
			again: "再来一局",
			lobby: "返回大堂",
			confirmAgain: "确认重新开始？",
			confirmLobby: "确认离开结算？",
			confirm: "确认",
			cancel: "取消",
			waitHost: "等待主机继续"
		},
		en: {
			name: "The Cubes of Europe",
			desc: "Build a nineteen-hex estate with two dice, chain cube effects and earn permanent abilities.",
			rules: "Goal:\nComplete connected territories of matching colors to score. The base game is for one player; 30 points wins. The official Rivals expansion supports 1–4 players. In multiplayer, highest score wins; ties favor the player with more empty hexes, then share the win.\nSetup:\nThe base game uses nine double-sided cards A–I. Shuffle, move the top card to the side pile, then take the next card as your land. The rest is the main deck. Each player has two dice, three yellow cubes and four each of red, white, blue and green. Place a starting cube on any yellow hex without triggering its effect. Your holding area has three spaces and your worker limit is six.\nRivals uses all 17 cards. In multiplayer set aside four land cards, then move the next card to the side pile. Deal each player one of the four lands and remove unused lands. For the solo variant remove four cards first, then follow solo setup. The first player starts with one worker; following players receive two, three or four.\nTurn:\nRoll two dice and spend each once, in any combination of these actions.\n· Gain a cube: claim a matching die symbol in the market and take that color from your own supply into your holding area. Only the six symbols along the join of the two piles are available. In two-player games each symbol holds one die; solo and 3–4 players allow a stack of two. An exhausted supply still lets you claim a symbol without gaining a cube. If your holding area is full, return one cube to your supply first.\n· Place a cube: move a held cube onto an empty hex of the same color and matching die value, adjacent to an occupied hex.\n· Gain a worker: spend a die of any value for one worker. Workers beyond six are lost.\nSpend one worker to modify an unused die by one, wrapping between one and six. You may spend multiple workers.\nColor effects:\n· After placing red, you may place another held cube, ignoring dice rules but respecting color and adjacency.\n· After placing white, you may gain any color in the current market, ignoring dice and occupancy.\n· After placing blue, you may gain one worker.\nRed and white can chain. All color and permanent effects are optional.\nEach new yellow cube placed this round lets you take one card from the top of the side pile at round end as a permanent effect, in first-player order. Stop when the pile is empty. The starting yellow cube does not count. Each placed green cube scores one point at game end.\nRound end and game end:\nAfter everyone spends both dice and resolves effects, retrieve dice, take yellow rewards, then move the top main-deck card to the side pile to refresh the market. Multiplayer ends when the main deck is empty; otherwise pass first player clockwise. In base solo, when it empties the first time, shuffle the side pile into a new main deck, then refresh the market once for each empty yellow hex. End after the second pass. The Rivals solo variant ends after the first pass.\nScoring:\n· Each completed connected territory scores by size: 1 hex = 1 point, 2 = 3, 3 = 6, 4 = 10. Incomplete territories score nothing.\n· One point for every color completely filled.\n· One point per two remaining workers, rounded down.\n· One point per placed green cube, plus permanent-card bonuses.\nSolo titles: 0–21 Newly Ennobled, 22–25 Baron, 26–29 Count, 30–33 Marquis, 34+ Duke. Marquis or higher wins.\nPermanent effects:\n· A: after placing any cube, modify an unused die by one.\n· B: after gaining a worker, gain one more. This effect never triggers itself.\n· C: after gaining any cube, modify an unused die by one.\n· D: score one point plus one per two workers.\n· E: score one extra point per red cube.\n· F: score one extra point per completed color.\n· G: score one extra point per green cube.\n· H: score one extra point per blue cube.\n· I: score one extra point per white cube.\nRivals permanent effects:\n· J: score one point plus one per two completed territories of at least two hexes.\n· K: after modifying a die with a worker, modify that die by one again.\n· L: score one point per two completed single-hex territories.\n· M: after placing green, pay one worker to use a red or white effect.\n· N: after placing red, pay one worker to repeat the red effect.\n· P: after placing white, pay one worker to repeat the white effect.\n· Q: after rolling at turn start and before spending dice, pay two workers to use a red or white effect.\n· O: copy another permanent card of yours, or scores two points if there is none. The digital edition initially copies your first eligible card, then lets you change the copy to another owned card before rolling on your turn. The copy remains fixed during the turn.",
			rivals: "Rivals expansion",
			rivalsInfo: "Adds cards J–Q and supports 1–4 players. Solo uses the expansion variant.",
			round: "Round {{n}}",
			pass: "Pass {{n}}",
			market: "Shared market",
			main: "Main deck",
			side: "Side pile",
			land: "Estate {{card}}",
			workers: "Workers",
			holding: "Holding area",
			supply: "Supply",
			permanent: "Permanent effects",
			score: "Score",
			start: "Choose a yellow starting hex",
			roll: "Roll dice",
			act: "Select a die, then a market space or land hex",
			effects: "Resolve or skip optional effects",
			waiting: "Waiting for {{name}}",
			settle: "Round end",
			take: "Gain a {{color}} cube · die {{n}}",
			place: "Hex {{n}}: {{color}}, die {{value}}",
			chooseDie: "Select die {{n}}",
			used: "Used",
			worker: "Gain 1 worker",
			finish: "End turn",
			skip: "Skip effect",
			use: "Use effect",
			redChoice: "Free placement",
			whiteChoice: "Free cube",
			red: "Red: place a cube for free",
			white: "White: gain a cube for free",
			blue: "Blue: gain 1 worker",
			bonus: "Gain 1 extra worker",
			shift: "Modify any unused die for free",
			k: "Modify the same die again",
			m: "Pay 1 worker: red or white effect",
			n: "Pay 1 worker: repeat red effect",
			p: "Pay 1 worker: repeat white effect",
			q: "Pay 2 workers: red or white effect",
			tuck: "Take permanent card {{card}}",
			decline: "Decline this card",
			replace: "Holding area full: choose a cube to return",
			returnCube: "Return a {{color}} cube",
			adjustUp: "Increase die by 1",
			adjustDown: "Decrease die by 1",
			copy: "Effect copied by O",
			empty: "Empty",
			y: "yellow",
			r: "red",
			b: "blue",
			g: "green",
			w: "white",
			invalid: "That action is unavailable now. Please choose again.",
			A: "After placing a cube, modify an unused die by 1.",
			B: "After gaining a worker, gain 1 extra worker. Never triggers itself.",
			C: "After gaining a cube, modify an unused die by 1.",
			D: "Score 1 point plus 1 per 2 workers.",
			E: "Score 1 extra point per red cube.",
			F: "Score 1 extra point per completed color.",
			G: "Score 1 extra point per green cube.",
			H: "Score 1 extra point per blue cube.",
			I: "Score 1 extra point per white cube.",
			J: "Score 1 point plus 1 per 2 completed territories of 2+ hexes.",
			K: "After paying a worker to modify a die, modify the same die by 1 again.",
			L: "Score 1 point per 2 completed single-hex territories.",
			M: "After placing green, pay 1 worker for a red or white effect.",
			N: "After placing red, pay 1 worker to repeat the red effect.",
			O: "Copy another permanent card of yours, or score 2 points if unable.",
			P: "After placing white, pay 1 worker to repeat the white effect.",
			Q: "After rolling at turn start, before spending dice, pay 2 workers for a red or white effect.",
			result: "Estate results",
			victory: "{{name}} wins",
			soloVictory: "A prosperous estate — victory",
			soloDefeat: "Challenge complete",
			total: "Total",
			territories: "Completed territories",
			colors: "Completed colors",
			green: "Green cubes",
			cards: "Permanent bonuses",
			review: "Inspect estate",
			title0: "Newly Ennobled",
			title1: "Baron",
			title2: "Count",
			title3: "Marquis",
			title4: "Duke",
			again: "Play again",
			lobby: "Back to lobby",
			confirmAgain: "Start a new game?",
			confirmLobby: "Leave these results?",
			confirm: "Confirm",
			cancel: "Cancel",
			waitHost: "Waiting for host"
		}
	}
};
//#endregion
export { ze as default };
