import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { BottomSheet as a } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { IconBot as l, IconCheck as u } from "@bgparty/sdk/icons";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { LogTicker as f } from "@bgparty/sdk/ui/log-sheet";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as m, seatName as h } from "@bgparty/sdk/ui/player-strip";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { Floater as y, FlySprite as b, PulseBox as x } from "@bgparty/sdk/fx/primitives";
import { AVATARS as S } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as C } from "@bgparty/sdk/player-colors";
import { Confetti as w } from "@bgparty/sdk/ui/confetti";
import { GameOverScreen as T } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/tagiron/meta.ts
var E = {
	id: "tagiron",
	tier: "released",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.tagiron.name",
	descKey: "games.tagiron.desc",
	rulesKey: "games.tagiron.rules",
	icon: "🔢",
	iconImg: "games/tagiron.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/tagiron/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#0e7490",
	releasedAt: "2026-09-25",
	search: {
		py: "luo ji dui jue",
		init: "ljdj"
	},
	hotseat: "cover"
}, D = t.object({
	n: t.int().min(0).max(9),
	c: t.enum([
		"b",
		"w",
		"g"
	])
}), O = t.union([t.int().min(0).max(9), t.enum(["ge5", "le4"])]), k = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("ask"),
		card: t.int().min(0).max(20),
		option: O.optional()
	}),
	t.object({
		type: t.literal("declare"),
		tiles: t.array(D).min(4).max(5)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), A = t.string(), j = t.discriminatedUnion("t", [
	t.object({
		t: t.literal("pos"),
		at: t.array(t.int().min(0).max(4))
	}),
	t.object({
		t: t.literal("num"),
		n: t.int()
	}),
	t.object({
		t: t.literal("pairs"),
		at: t.array(t.tuple([t.int(), t.int()]))
	}),
	t.object({
		t: t.literal("bool"),
		yes: t.boolean()
	})
]), M = t.discriminatedUnion("k", [t.object({
	k: t.literal("ask"),
	by: A,
	card: t.int(),
	option: O.optional(),
	answers: t.record(A, j)
}), t.object({
	k: t.literal("declare"),
	by: A,
	ok: t.boolean()
})]), N = t.object({
	phase: t.enum([
		"play",
		"counter",
		"done"
	]),
	turn: A,
	tileCount: t.int(),
	field: t.array(t.int()),
	deckCount: t.int().nonnegative(),
	players: t.array(t.object({
		rid: A,
		state: t.enum([
			"active",
			"done",
			"out"
		]),
		declared: t.boolean(),
		turns: t.int().nonnegative()
	})),
	closing: t.int().nullable(),
	log: t.array(M),
	reveal: t.record(A, t.array(D)).nullable()
}), P = t.object({ hand: t.array(D) }), F = [
	...[
		0,
		1,
		2,
		3,
		4,
		6,
		7,
		8,
		9
	].flatMap((e) => [{
		n: e,
		c: "b"
	}, {
		n: e,
		c: "w"
	}]),
	{
		n: 5,
		c: "g"
	},
	{
		n: 5,
		c: "g"
	}
], I = /* @__PURE__ */ new Set([
	18,
	19,
	20
]), L = {
	1: [1, 2],
	2: [3, 4],
	4: [6, 7],
	5: [8, 9]
}, R = /* @__PURE__ */ new Set([13, 20]);
function z(e) {
	let t = (e) => e === "b" ? 0 : e === "w" ? 1 : 2;
	return [...e].sort((e, n) => e.n - n.n || t(e.c) - t(n.c));
}
function B(e, t, n) {
	let r = (e) => ({
		t: "pos",
		at: n.flatMap((t, n) => e(t) ? [n] : [])
	});
	switch (e) {
		case 0: return r((e) => e.n === 0);
		case 1:
		case 2:
		case 4:
		case 5: return r((e) => e.n === t);
		case 3: return r((e) => e.n === 5);
		case 6: return {
			t: "num",
			n: n.filter((e) => e.n % 2 == 0).length
		};
		case 7: return {
			t: "num",
			n: n.filter((e) => e.n % 2 == 1).length
		};
		case 8: return {
			t: "num",
			n: n.filter((e) => e.c === "b").length
		};
		case 9: return {
			t: "num",
			n: n.filter((e) => e.c === "w").length
		};
		case 10: return {
			t: "num",
			n: n.filter((e) => e.c === "b").reduce((e, t) => e + t.n, 0)
		};
		case 11: return {
			t: "num",
			n: n.filter((e) => e.c === "w").reduce((e, t) => e + t.n, 0)
		};
		case 12: return {
			t: "num",
			n: n.slice(0, 3).reduce((e, t) => e + t.n, 0)
		};
		case 13: return {
			t: "num",
			n: n.slice(1, 4).reduce((e, t) => e + t.n, 0)
		};
		case 14: return {
			t: "num",
			n: n.slice(-3).reduce((e, t) => e + t.n, 0)
		};
		case 15:
		case 16: {
			let t = [];
			for (let r = 0; r < n.length - 1; r += 1) (e === 15 ? n[r].c === n[r + 1].c : Math.abs(n[r].n - n[r + 1].n) === 1) && t.push([r, r + 1]);
			return {
				t: "pairs",
				at: t
			};
		}
		case 17: {
			let e = /* @__PURE__ */ new Map();
			for (let t of n) e.set(t.n, (e.get(t.n) ?? 0) + 1);
			return {
				t: "num",
				n: [...e.values()].filter((e) => e === 2).length
			};
		}
		case 18: return {
			t: "num",
			n: n.reduce((e, t) => e + t.n, 0)
		};
		case 19: return {
			t: "num",
			n: n[n.length - 1].n - n[0].n
		};
		default: return {
			t: "bool",
			yes: t === "ge5" ? n[2].n >= 5 : n[2].n <= 4
		};
	}
}
var V = (e) => e === 4 ? 4 : 5;
function H(t, n, r) {
	let i = 0, a = [...F];
	for (let t = a.length - 1; t > 0; --t) {
		let n = e(r, i, t + 1);
		i += 1, [a[t], a[n]] = [a[n], a[t]];
	}
	let o = V(n.length), s = 0, c = {};
	for (let e of n) c[e] = z(a.slice(s, s + o)), s += o;
	let l = n.length > 2 ? z(a.slice(s, s + o)) : [], u = Array.from({ length: 21 }, (e, t) => t).filter((e) => !(n.length === 4 && R.has(e)));
	for (let t = u.length - 1; t > 0; --t) {
		let n = e(r, i, t + 1);
		i += 1, [u[t], u[n]] = [u[n], u[t]];
	}
	let d = e(r, i, n.length);
	return i += 1, {
		state: {
			players: n,
			startIdx: d,
			turn: d,
			hands: c,
			center: l,
			deck: u.slice(6),
			field: u.slice(0, 6),
			log: [],
			turns: Object.fromEntries(n.map((e) => [e, 0])),
			pstate: Object.fromEntries(n.map((e) => [e, "active"])),
			declared: Object.fromEntries(n.map((e) => [e, !1])),
			closing: null,
			counterBy: null,
			winner: [],
			phase: "play",
			rngCursor: i
		},
		fx: n.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: { count: o },
			for: [e],
			secret: { hand: c[e] },
			...t > 0 ? { with: !0 } : {}
		}))
	};
}
function U(e) {
	let t = e.players.length;
	for (let n = 1; n <= t; n += 1) {
		let r = (e.turn + n) % t;
		if (t === 2 || e.pstate[e.players[r]] === "active") {
			e.turn = r;
			return;
		}
	}
}
function W(e) {
	if (e.players.length === 2) return e.field.length === 0 && (e.phase = "done", e.winner = [], !0);
	let t = e.players.filter((t) => e.pstate[t] === "active");
	return t.length === 0 || e.field.length === 0 || e.closing !== null && t.every((t) => e.turns[t] >= e.closing) ? (e.phase = "done", e.winner = e.players.filter((t) => e.pstate[t] === "done"), !0) : !1;
}
var G = (e, t) => e.length === t.length && e.every((e, n) => e.n === t[n].n && e.c === t[n].c);
function ee(e, t, n) {
	if (t.type === "tick") return { state: e };
	if (t.type === "ask") {
		if (e.phase !== "play") return { code: "games.tagiron.errPhase" };
		if (e.players[e.turn] !== n.by) return { code: "games.tagiron.errNotYourTurn" };
		if (e.pstate[n.by] !== "active") return { code: "games.tagiron.errPhase" };
		if (!e.field.includes(t.card)) return { code: "games.tagiron.errBadCard" };
		let r = L[t.card];
		if (r && !(typeof t.option == "number" && r.includes(t.option)) || t.card === 20 && t.option !== "ge5" && t.option !== "le4" || !r && t.card !== 20 && t.option !== void 0) return { code: "games.tagiron.errBadOption" };
		let i = structuredClone(e), a = I.has(t.card) || i.players.length === 4 ? i.players : i.players.filter((e) => e !== n.by), o = {};
		for (let e of a) o[e] = B(t.card, t.option, i.hands[e]);
		return i.log.push({
			k: "ask",
			by: n.by,
			card: t.card,
			...t.option === void 0 ? {} : { option: t.option },
			answers: o
		}), i.field = i.field.filter((e) => e !== t.card), i.deck.length > 0 && i.field.push(i.deck.shift()), i.turns[n.by] += 1, W(i) || U(i), {
			state: i,
			fx: [{
				kind: "ask",
				rid: n.by,
				data: { card: t.card }
			}]
		};
	}
	let r = t.tiles;
	if (e.players.length === 2) {
		if (e.phase === "counter") {
			if (e.counterBy !== n.by) return { code: "games.tagiron.errNotYourTurn" };
			let t = e.players[e.startIdx], i = G(r, e.hands[t]), a = structuredClone(e);
			return a.log.push({
				k: "declare",
				by: n.by,
				ok: i
			}), a.phase = "done", a.winner = i ? [...a.players] : [t], {
				state: a,
				fx: [{
					kind: "declare",
					rid: n.by,
					data: { ok: i }
				}]
			};
		}
		if (e.phase !== "play") return { code: "games.tagiron.errPhase" };
		if (e.players[e.turn] !== n.by) return { code: "games.tagiron.errNotYourTurn" };
		if (r.length !== 5) return { code: "games.tagiron.errBadGuess" };
		let t = e.players.find((e) => e !== n.by), i = G(r, e.hands[t]), a = structuredClone(e);
		a.log.push({
			k: "declare",
			by: n.by,
			ok: i
		});
		let o = [{
			kind: "declare",
			rid: n.by,
			data: { ok: i }
		}];
		return i ? n.by === e.players[e.startIdx] ? (a.phase = "counter", a.counterBy = t) : (a.phase = "done", a.winner = [n.by]) : (a.turns[n.by] += 1, W(a) || U(a)), {
			state: a,
			fx: o
		};
	}
	if (e.phase !== "play") return { code: "games.tagiron.errPhase" };
	if (e.players[e.turn] !== n.by) return { code: "games.tagiron.errNotYourTurn" };
	if (e.pstate[n.by] !== "active" || e.declared[n.by]) return { code: "games.tagiron.errPhase" };
	if (r.length !== e.center.length) return { code: "games.tagiron.errBadGuess" };
	let i = G(r, e.center), a = structuredClone(e);
	return a.declared[n.by] = !0, a.turns[n.by] += 1, a.log.push({
		k: "declare",
		by: n.by,
		ok: i
	}), i ? (a.pstate[n.by] = "done", a.closing === null && (a.closing = a.turns[n.by])) : a.pstate[n.by] = "out", W(a) || U(a), {
		state: a,
		fx: [{
			kind: "declare",
			rid: n.by,
			data: { ok: i }
		}]
	};
}
function K(e, t) {
	let n = e.phase === "done" ? e.players.length === 2 ? Object.fromEntries(e.players.map((t) => [t, e.hands[t]])) : { $center: e.center } : null;
	return {
		public: {
			phase: e.phase,
			turn: e.phase === "counter" ? e.counterBy : e.players[e.turn],
			tileCount: V(e.players.length),
			field: [...e.field],
			deckCount: e.deck.length,
			players: e.players.map((t) => ({
				rid: t,
				state: e.pstate[t],
				declared: e.declared[t],
				turns: e.turns[t]
			})),
			closing: e.closing,
			log: e.log,
			reveal: n
		},
		private: { hand: e.hands[t] ?? [] }
	};
}
function q(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.winner, ...e.players.filter((t) => !e.winner.includes(t))];
	return {
		phase: "done",
		winner: [...e.winner],
		ranking: t
	};
}
var te = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: E,
	schemas: {
		action: k,
		publicView: N,
		privateView: P
	},
	setup: H,
	reduce: ee,
	viewFor: K,
	status: q
}, ne = {
	6: "even",
	7: "odd",
	8: "black",
	9: "white",
	10: "blackSum",
	11: "whiteSum",
	12: "left",
	13: "mid",
	14: "right",
	17: "pair",
	18: "sum",
	19: "diff"
};
function re(e, t, n) {
	let r = Array.from({ length: n }, () => null), i = null, a = [];
	for (let n of e) {
		if (n.k !== "ask") continue;
		let e = n.answers[t];
		if (e) {
			if (n.card <= 5) {
				let t = n.card === 0 ? 0 : n.card === 3 ? 5 : typeof n.option == "number" ? n.option : null;
				if (t === null || e.t !== "pos") continue;
				if (e.at.length === 0) a.push({
					k: "none",
					n: t
				});
				else for (let n of e.at) r[n] = t;
			} else if (n.card === 15 || n.card === 16) e.t === "pairs" && a.push({
				k: n.card === 15 ? "same" : "seq",
				at: e.at
			});
			else if (n.card === 20) e.t === "bool" && (i = n.option === "ge5" === e.yes ? "ge5" : "le4");
			else {
				let t = ne[n.card];
				t && e.t === "num" && a.push({
					k: t,
					n: e.n
				});
			}
		}
	}
	return {
		pins: r,
		middle: i,
		facts: a
	};
}
//#endregion
//#region src/games/tagiron/tile.tsx
var ie = {
	b: {
		bg: "#292524",
		fg: "#fafaf9",
		mark: "dot"
	},
	w: {
		bg: "#fafaf9",
		fg: "#292524",
		mark: "ring"
	},
	g: {
		bg: "#059669",
		fg: "#fafaf9",
		mark: "star"
	}
};
function J({ tile: e, w: t = 52, elevated: n = !1 }) {
	let r = Math.round(t * 1.35), i = ie[e.c], a = t * .16;
	return /* @__PURE__ */ v("svg", {
		width: t,
		height: r,
		viewBox: "0 0 52 70",
		className: `rounded border-2 border-ink ${n ? "shadow-[2px_2px_0_var(--color-ink)]" : ""}`,
		role: "img",
		"aria-label": `${e.c}${e.n}`,
		children: [
			/* @__PURE__ */ _("rect", {
				x: "1",
				y: "1",
				width: "50",
				height: "68",
				rx: "4",
				fill: i.bg,
				stroke: "var(--color-ink)",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ _("text", {
				x: "26",
				y: "46",
				textAnchor: "middle",
				fontSize: "34",
				fontWeight: "800",
				fill: i.fg,
				opacity: "0.16",
				fontFamily: "inherit",
				children: e.n
			}),
			/* @__PURE__ */ _("text", {
				x: "26",
				y: "45",
				textAnchor: "middle",
				fontSize: "30",
				fontWeight: "800",
				fill: i.fg,
				fontFamily: "inherit",
				children: e.n
			}),
			i.mark === "dot" && /* @__PURE__ */ _("circle", {
				cx: "9",
				cy: "61",
				r: a / 2 + 2,
				fill: i.fg
			}),
			i.mark === "ring" && /* @__PURE__ */ _("circle", {
				cx: "9",
				cy: "61",
				r: a / 2 + 1.5,
				fill: "none",
				stroke: i.fg,
				strokeWidth: "2"
			}),
			i.mark === "star" && /* @__PURE__ */ _("path", {
				d: "M9 56 l1.6 3.2 3.5.5 -2.5 2.4 .6 3.5 -3.2-1.7 -3.2 1.7 .6-3.5 -2.5-2.4 3.5-.5 Z",
				fill: i.fg
			})
		]
	});
}
function ae({ w: e = 52, accent: t = "#0e7490", label: n }) {
	let r = Math.round(e * 1.35);
	return /* @__PURE__ */ v("svg", {
		width: e,
		height: r,
		viewBox: "0 0 52 70",
		className: "rounded border-2 border-ink",
		role: "img",
		"aria-label": n ?? "?",
		children: [
			/* @__PURE__ */ _("defs", { children: /* @__PURE__ */ v("pattern", {
				id: "tagiron-back",
				width: "8",
				height: "8",
				patternTransform: "rotate(45)",
				patternUnits: "userSpaceOnUse",
				children: [/* @__PURE__ */ _("rect", {
					width: "8",
					height: "8",
					fill: t
				}), /* @__PURE__ */ _("line", {
					x1: "0",
					y1: "0",
					x2: "0",
					y2: "8",
					stroke: "rgba(255,255,255,0.18)",
					strokeWidth: "3"
				})]
			}) }),
			/* @__PURE__ */ _("rect", {
				x: "1",
				y: "1",
				width: "50",
				height: "68",
				rx: "4",
				fill: "url(#tagiron-back)",
				stroke: "var(--color-ink)",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ _("text", {
				x: "26",
				y: "46",
				textAnchor: "middle",
				fontSize: "30",
				fontWeight: "800",
				fill: "#ffffff",
				fontFamily: "inherit",
				children: n ?? "?"
			})
		]
	});
}
//#endregion
//#region src/games/tagiron/view-player.tsx
var Y = [
	"games.tagiron.q0",
	"games.tagiron.q1",
	"games.tagiron.q2",
	"games.tagiron.q3",
	"games.tagiron.q4",
	"games.tagiron.q5",
	"games.tagiron.q6",
	"games.tagiron.q7",
	"games.tagiron.q8",
	"games.tagiron.q9",
	"games.tagiron.q10",
	"games.tagiron.q11",
	"games.tagiron.q12",
	"games.tagiron.q13",
	"games.tagiron.q14",
	"games.tagiron.q15",
	"games.tagiron.q16",
	"games.tagiron.q17",
	"games.tagiron.q18",
	"games.tagiron.q19",
	"games.tagiron.q20"
];
function oe(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ _(le, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function se(e, t) {
	let i = r(null);
	return n(() => {
		let n = i.current, r = n?.querySelector(".game-screen-layout");
		if (!n || !r) return;
		let a = window.matchMedia("(orientation: landscape)"), o = [
			"pad",
			"gap",
			"top",
			"actions",
			"notebook-width",
			"notebook-height",
			"market-height",
			"question-cols",
			"question-height",
			"question-font",
			"label-font",
			"tile",
			"clue-tile",
			"note-font",
			"facts-height",
			"avatar",
			"seat-width",
			"name-font",
			"phase-font",
			"log-font",
			"button-font"
		], s = () => {
			delete n.dataset.tagironLayout;
			for (let e of o) r.style.removeProperty(`--tagiron-${e}`);
		}, c = (e, t, n = "px") => {
			let i = n ? `${t.toFixed(4)}${n}` : String(t);
			r.style.getPropertyValue(`--tagiron-${e}`) !== i && r.style.setProperty(`--tagiron-${e}`, i);
		}, l = (e, t, n) => Math.min(n, Math.max(e, t)), u = () => {
			let { width: r, height: i } = n.getBoundingClientRect();
			if (e !== 2 || !a.matches || r < 900 || i < 400) {
				s();
				return;
			}
			let o = l(6, Math.min(r, i) * .01, 12), u = l(8, Math.min(r, i) * .012, 14), d = r - 2 * o, f = i - 2 * o, p = r < i * 1.25, m = p ? l(96, f * .12, 112) : l(96, f * .14, 144), h = p ? 140 : l(140, f * .18, 176), g = p ? d : (d - u) * .56, _ = p ? l(250, f * .33, 340) : f - m - u, v = p ? d : d - g - u, y = p ? f - m - _ - h - 3 * u : _ - h - u, b = l(18, Math.min(g * .04, _ * .07), 28), x = l(14, (p ? g * .5 : g) * .026, 22), S = p ? 48 : Math.min(l(40, _ * .16, 140), _ - 24 - b * 1.25 - 3 * u - x * 3.6 - 44 * 2.7), C = ((p ? (g - 24 - u) / 2 : g - 24) - (t - 1) * u) / t, w = p ? (_ - 24 - b * 1.25 - 2 * u - x * 3.6 - S) / 1.35 : (_ - 24 - b * 1.25 - 3 * u - x * 3.6 - S) / 2.7, T = Math.max(44, Math.min(C, w)), E = p ? 3 : 2, D = Math.ceil(6 / E), O = (v - 24 - (E - 1) * u) / E, k = Math.max(110, (y - 24 - b * 1.25 - u - (D - 1) * u) / D), A = {
				pad: o,
				gap: u,
				top: m,
				actions: h,
				"notebook-width": g,
				"notebook-height": _,
				"market-height": y,
				"question-height": k,
				"question-font": l(18, Math.min(O * .095, k * .17), 32),
				"label-font": b,
				tile: T,
				"clue-tile": T,
				"note-font": x,
				"facts-height": S,
				avatar: l(48, m * .55, 76),
				"seat-width": l(96, d / 12, 160),
				"name-font": l(16, m * .17, 22),
				"phase-font": l(18, m * .2, 28),
				"log-font": l(14, m * .16, 20),
				"button-font": l(18, h * .16, 28)
			}, j = p ? "shelf" : "side";
			n.dataset.tagironLayout !== j && (n.dataset.tagironLayout = j);
			for (let [e, t] of Object.entries(A)) c(e, t);
			c("question-cols", E, "");
		}, d = new ResizeObserver(u);
		return d.observe(n), a.addEventListener("change", u), u(), () => {
			d.disconnect(), a.removeEventListener("change", u), s();
		};
	}, [e, t]), i;
}
function ce(e, t) {
	let i = r(null);
	return n(() => {
		let n = i.current, r = n?.querySelector(".game-screen-layout");
		if (!n || !r) return;
		let a = window.matchMedia("(orientation: landscape)"), o = [
			"center-width",
			"mark-font",
			"target-note-font",
			"target-mark-font"
		], s = [
			"pad",
			"gap",
			"top",
			"actions",
			"target-height",
			"peer-height",
			"market-height",
			"target-tile",
			"hand-tile",
			"peer-tile",
			"note-font",
			"label-font",
			"facts-height",
			"facts-width",
			"opponents",
			"question-height",
			"question-font",
			"avatar",
			"seat-width",
			"name-font",
			"phase-font",
			"log-font",
			"button-font",
			...o
		], c = () => {
			delete n.dataset.tagironMulti;
			for (let e of s) r.style.removeProperty(`--tagiron-multi-${e}`);
		}, l = (e, t, n) => Math.min(n, Math.max(e, t)), u = (e, t, n = "px") => {
			let i = n ? `${t.toFixed(4)}${n}` : String(t);
			r.style.getPropertyValue(`--tagiron-multi-${e}`) !== i && r.style.setProperty(`--tagiron-multi-${e}`, i);
		}, d = () => {
			let { width: i, height: s } = n.getBoundingClientRect();
			if (e < 3 || e > 4 || !a.matches || i < 900 || s < 600) {
				c();
				return;
			}
			let d = l(6, Math.min(i, s) * .01, 12), f = l(8, Math.min(i, s) * .012, 14), p = i - 2 * d, m = s - 2 * d, h = l(92, m * .09, 144), g = l(140, m * .13, 176), _ = m - h - g - 2 * f - 20, v = p - 20, y = l(18, Math.min(v * .02, _ * .035), 28), b = l(14, Math.min(v * .012, _ * .024), 28), x = (v - 2 * f) / 3, S = Math.max(110, _ * .13), C = y * 1.25 + f + 2 * S + f, w = (v - (e - 2) * f) / (e - 1), T = w >= 480, E = T ? Math.max(120, w * .22) : 0, D = l(44, Math.min(p, m) * .07, 108), O = 20 + y * 1.25 + f + D * 1.35 + b * 3.6, k = Math.max(190, O, (_ - C - 2 * f) * .5), A = Math.max(220, O + (T ? 0 : 40 + f), _ - C - k - 2 * f), j = T ? A - 20 - y * 1.25 - f : 40, M = (v - f) / 2, N = Math.max(44, Math.min((M - 20 - (t - 1) * f) / t, (k - 20 - y * 1.25 - f - b * 3.6) / 1.35)), P = Math.max(44, Math.min((M - 20 - (t - 1) * f) / t, (k - 20 - y * 1.25 - f) / 1.35)), F = Math.max(44, Math.min((w - 20 - (t - 1) * f - (T ? E + f : 0)) / t, (A - 20 - y * 1.25 - f - b * 3.6 - (T ? 0 : j + f)) / 1.35));
			if (i >= 1800 && s >= 900 && i >= s * 1.7) {
				let r = Math.max(27.5, l(18, Math.min(x * .075, S * .25), 32)), i = Math.max(150, 44 + r * 3.6), a = y * 1.25 + f + i, o = Math.max(520, _ - a - f), s = (o - f) / 2, c = v * (e === 4 ? .22 : .28), m = (v - c - 2 * f) / 2, C = e === 4 ? m : 2 * m + f, w = l(80, m * .14, 120), T = Math.max(b, l(18, Math.min(m * .034, s * .073), 28)), E = Math.max(16, T * .8), D = Math.ceil(t / 2), O = (c - 20 - (D - 1) * f) / D, k = Math.max(b, Math.min(l(20, Math.min(c * .055, s * .08), 28), O / 6.1)), A = Math.max(16, k * .8), j = o - 20 - y * 1.25 - f, M = Math.min(O, ((j - f) / 2 - k * 1.2 - A * 1.2) / 1.35), I = Math.min((C - 20 - (t - 1) * f) / t, (s - 20 - y * 1.25 - f) / 1.35), L = Math.min((m - 20 - (t - 1) * f - w - f) / t, (s - 20 - y * 1.25 - f - T * 2.4 - E * 1.2) / 1.35);
				if (M >= N && I >= P && L >= F) {
					let t = e === 4 ? "desk4" : "desk3";
					n.dataset.tagironMulti !== t && (n.dataset.tagironMulti = t);
					let m = {
						pad: d,
						gap: f,
						top: h,
						actions: g,
						"target-height": o,
						"peer-height": s,
						"market-height": a,
						"center-width": c,
						"target-tile": M,
						"hand-tile": I,
						"peer-tile": L,
						"note-font": T,
						"mark-font": E,
						"target-note-font": k,
						"target-mark-font": A,
						"label-font": y,
						"facts-height": s - 20 - y * 1.25 - f,
						"facts-width": w,
						"question-height": i,
						"question-font": r,
						avatar: l(42, h * .5, 72),
						"seat-width": l(84, p / 14, 144),
						"name-font": l(16, h * .18, 24),
						"phase-font": l(18, h * .2, 28),
						"log-font": l(14, h * .16, 20),
						"button-font": l(18, g * .15, 28)
					};
					for (let [e, t] of Object.entries(m)) u(e, t);
					u("opponents", e - 1, "");
					return;
				}
			}
			for (let e of o) r.style.getPropertyValue(`--tagiron-multi-${e}`) && r.style.removeProperty(`--tagiron-multi-${e}`);
			let I = T ? "wide" : "stack";
			n.dataset.tagironMulti !== I && (n.dataset.tagironMulti = I);
			let L = {
				pad: d,
				gap: f,
				top: h,
				actions: g,
				"target-height": k,
				"peer-height": A,
				"market-height": C,
				"target-tile": N,
				"hand-tile": P,
				"peer-tile": F,
				"note-font": b,
				"label-font": y,
				"facts-height": j,
				"facts-width": E,
				"question-height": S,
				"question-font": l(18, Math.min(x * .075, S * .25), 32),
				avatar: l(42, h * .5, 72),
				"seat-width": l(84, p / 14, 144),
				"name-font": l(16, h * .18, 24),
				"phase-font": l(18, h * .2, 28),
				"log-font": l(14, h * .16, 20),
				"button-font": l(18, g * .15, 28)
			};
			for (let [e, t] of Object.entries(L)) u(e, t);
			u("opponents", e - 1, "");
		}, f = new ResizeObserver(d);
		return f.observe(n), a.addEventListener("change", d), d(), () => {
			f.disconnect(), a.removeEventListener("change", d), c();
		};
	}, [e, t]), i;
}
function le({ pub: e, priv: t, members: n, myRid: r, send: a }) {
	let s = c(), l = se(n.length, e.tileCount), u = ce(e.players.length, e.tileCount), { ref: h } = o("tagiron-fx-metric"), y = (e) => n.find((t) => t.rid === e)?.name ?? e, [b, x] = i(null), [S, C] = i(void 0), [w, T] = i(!1), [D, O] = i({}), [k, A] = i(null), j = (e, t) => D[e]?.[t] ?? X, M = (t, n, r) => O((i) => {
		let a = Array.from({ length: e.tileCount }, (e, n) => i[t]?.[n] ?? X);
		return a[n] = r(a[n]), {
			...i,
			[t]: a
		};
	}), N = e.players.find((e) => e.rid === r), P = e.phase === "play" && e.turn === r && N?.state === "active", F = e.phase === "counter" && e.turn === r, I = P || F, [R, z] = i(""), B = `${e.phase}:${e.turn}`;
	R !== B && (z(B), x(null), C(void 0));
	let V = "info", H, U;
	if (e.phase === "counter") {
		let t = [...e.log].reverse().find((e) => e.k === "declare");
		V = F ? "accent" : "warn", H = F ? s("games.tagiron.counterYou") : s("games.tagiron.counterWait", {
			name: y(t?.by ?? ""),
			counter: y(e.turn)
		});
	} else P ? (V = "accent", H = s("games.tagiron.turnYou"), e.closing !== null && (U = s("games.tagiron.targetCenter", { n: e.tileCount }))) : N?.state === "done" ? (V = "done", H = s("games.tagiron.youDone"), U = s("games.tagiron.turnWait", { name: y(e.turn) })) : N?.state === "out" ? (V = "warn", H = s("games.tagiron.youOut"), U = s("games.tagiron.turnWait", { name: y(e.turn) })) : H = s("games.tagiron.turnWait", { name: y(e.turn) });
	let W = (e) => e.t === "pos" ? e.at.length ? s("games.tagiron.ansPos", { at: e.at.map((e) => e + 1).join("·") }) : s("games.tagiron.ansNone") : e.t === "pairs" ? e.at.length ? s("games.tagiron.ansPairs", { at: e.at.map(([e, t]) => `${e + 1}-${t + 1}`).join("·") }) : s("games.tagiron.ansNone") : e.t === "bool" ? s(e.yes ? "games.tagiron.ansYes" : "games.tagiron.ansNo") : String(e.n), G = (e, t) => typeof t == "number" ? s("games.tagiron.qLocate", { n: t }) : s(t === "ge5" ? "games.tagiron.q20ge5" : t === "le4" ? "games.tagiron.q20le4" : Y[e]), ee = (e) => {
		if (e.k === "declare") return s(e.ok ? "games.tagiron.logDeclareOk" : "games.tagiron.logDeclareWrong", { name: y(e.by) });
		let t = Object.entries(e.answers).map(([e, t]) => `${y(e)}:${W(t)}`).join("  ");
		return `${s("games.tagiron.logAsk", {
			name: y(e.by),
			card: G(e.card, e.option)
		})} ${t}`;
	}, K = b === null ? void 0 : L[b], q = b !== null && (b === null || K === void 0 && b !== 20 || S !== void 0), te = (e) => {
		P && (x(e), C(void 0));
	}, ne = /* @__PURE__ */ _("div", {
		className: "tagiron-actions safe-b flex h-full min-h-0 flex-col justify-center gap-1.5 pb-1",
		children: b !== null && P ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("div", {
			className: "tagiron-options flex min-h-6 items-center justify-center gap-1.5 text-xs font-bold",
			children: [
				/* @__PURE__ */ _("span", {
					className: "truncate",
					children: s(Y[b])
				}),
				K?.map((e) => /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => C(e),
					className: `min-h-11 rounded-lg border-2 border-ink px-2 font-display text-sm font-extrabold ${S === e ? "bg-info-soft text-info-ink" : "bg-surface"}`,
					children: s("games.tagiron.askNumber", { n: e })
				}, e)),
				b === 20 && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => C("ge5"),
					className: `min-h-11 rounded-lg border-2 border-ink px-2 font-display text-sm font-extrabold ${S === "ge5" ? "bg-info-soft text-info-ink" : "bg-surface"}`,
					children: s("games.tagiron.askGe5")
				}), /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => C("le4"),
					className: `min-h-11 rounded-lg border-2 border-ink px-2 font-display text-sm font-extrabold ${S === "le4" ? "bg-info-soft text-info-ink" : "bg-surface"}`,
					children: s("games.tagiron.askLe4")
				})] })
			]
		}), /* @__PURE__ */ v("div", {
			className: "flex gap-1.5",
			children: [/* @__PURE__ */ _("button", {
				type: "button",
				onClick: () => x(null),
				className: "btn-base flex-1 bg-surface",
				children: s("games.tagiron.cancel")
			}), /* @__PURE__ */ _("button", {
				type: "button",
				disabled: !q,
				onClick: () => {
					b !== null && q && (a({
						type: "ask",
						card: b,
						...S === void 0 ? {} : { option: S }
					}), x(null), C(void 0));
				},
				className: "btn-base flex-2 bg-pop text-white disabled:opacity-50",
				children: s("games.tagiron.askConfirm")
			})]
		})] }) : /* @__PURE__ */ _("button", {
			type: "button",
			disabled: !I || e.phase === "play" && N?.declared === !0 && e.players.length > 2,
			onClick: () => T(!0),
			className: "btn-base bg-pop text-white disabled:opacity-50",
			children: s("games.tagiron.declare")
		})
	});
	return /* @__PURE__ */ v("div", {
		ref: e.players.length === 2 ? l : u,
		className: "tagiron-screen h-full min-h-0",
		children: [
			/* @__PURE__ */ _("span", {
				ref: h,
				className: "tagiron-fx-metric",
				"aria-hidden": !0
			}),
			/* @__PURE__ */ _(d, {
				adaptive: !0,
				scroll: !1,
				banner: /* @__PURE__ */ v("div", {
					className: "tagiron-banner flex flex-col gap-2",
					children: [
						/* @__PURE__ */ _("div", {
							className: "tagiron-phase",
							children: /* @__PURE__ */ _(p, {
								tone: V,
								text: H,
								sub: U,
								chip: s("games.tagiron.deckLeft", { n: e.deckCount }),
								accent: E.accent
							})
						}),
						/* @__PURE__ */ _("div", {
							className: "tagiron-players",
							children: /* @__PURE__ */ _(m, {
								members: n,
								myRid: r,
								variant: "medal",
								anchorOf: (e) => `seat:${e}`,
								action: (t) => e.phase !== "done" && e.turn === t ? "pending" : null,
								status: (t) => {
									let n = e.players.find((e) => e.rid === t);
									return n ? n.state === "done" ? /* @__PURE__ */ _(he, {
										className: "bg-done-soft text-done-ink",
										children: s("games.tagiron.stDone")
									}) : n.state === "out" ? /* @__PURE__ */ _(he, {
										className: "bg-danger-soft text-danger-ink",
										children: s("games.tagiron.stOut")
									}) : null : null;
								}
							})
						}),
						/* @__PURE__ */ _("div", {
							className: "tagiron-log",
							children: /* @__PURE__ */ _(f, {
								log: e.log,
								line: ee
							})
						})
					]
				}),
				actionsHeight: "tagiron-actions-height",
				actions: ne,
				children: /* @__PURE__ */ v("div", {
					className: "tagiron-main frame flex h-full min-h-0 flex-col gap-2 overflow-y-auto p-2",
					children: [/* @__PURE__ */ v("div", {
						className: "tagiron-notebook",
						children: [
							/* @__PURE__ */ _("p", {
								className: "tagiron-target text-center text-xs font-bold text-ink-soft",
								children: e.players.length === 2 ? s("games.tagiron.targetOpponent") : s("games.tagiron.targetCenter", { n: e.tileCount })
							}),
							/* @__PURE__ */ _(de, {
								pub: e,
								myRid: r,
								nameOf: y,
								noteAt: j,
								onEdit: (e, t) => A({
									key: e,
									idx: t
								})
							}),
							/* @__PURE__ */ _("div", {
								className: "tagiron-hand flex flex-none items-center justify-center gap-1.5",
								"aria-label": s("games.tagiron.myTiles"),
								children: (t?.hand ?? []).map((e, t) => /* @__PURE__ */ _(ge, {
									name: `tile:${e.c}${e.n}`,
									children: /* @__PURE__ */ _(J, {
										tile: e,
										w: 40,
										elevated: !0
									})
								}, `${e.c}${e.n}:${t}`))
							})
						]
					}), /* @__PURE__ */ v("div", {
						className: "tagiron-market",
						children: [/* @__PURE__ */ _("p", {
							className: "tagiron-question-label section-label",
							children: s("games.tagiron.pickQuestion")
						}), /* @__PURE__ */ _("div", {
							className: "tagiron-questions grid flex-none grid-cols-2 gap-1.5",
							children: e.field.map((e) => /* @__PURE__ */ _(_e, {
								id: e,
								selected: b === e,
								disabled: !P,
								onPick: () => te(e)
							}, e))
						})]
					})]
				})
			}),
			/* @__PURE__ */ _(ve, {
				open: w,
				tileCount: e.tileCount,
				onClose: () => T(!1),
				onConfirm: (e) => {
					a({
						type: "declare",
						tiles: e
					}), T(!1);
				}
			}),
			k && /* @__PURE__ */ _(ye, {
				name: k.key === "$center" ? s("games.tagiron.centerShort") : y(k.key),
				idx: k.idx,
				pin: k.key === "$center" ? null : re(e.log, k.key, e.tileCount).pins[k.idx],
				note: j(k.key, k.idx),
				onToggleDigit: (e) => M(k.key, k.idx, (t) => ({
					...t,
					d: t.d ^ 1 << e
				})),
				onToggleColor: (e) => M(k.key, k.idx, (t) => e === "b" ? {
					...t,
					b: !t.b
				} : {
					...t,
					w: !t.w
				}),
				onReset: () => M(k.key, k.idx, () => X),
				onClose: () => A(null)
			})
		]
	});
}
var X = {
	d: 0,
	b: !1,
	w: !1
}, ue = (e) => Array.from({ length: 10 }, (e, t) => t).filter((t) => !(e.d & 1 << t)).join("");
function de({ pub: e, myRid: t, nameOf: n, noteAt: r, onEdit: i }) {
	let a = c(), o = e.players.map((e) => e.rid).filter((e) => e !== t);
	return e.players.length === 2 ? /* @__PURE__ */ _(me, {
		pub: e,
		rid: o[0],
		noteAt: (e) => r(o[0], e),
		onEdit: (e) => i(o[0], e)
	}) : /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("div", {
		className: "tagiron-center flex flex-none justify-center gap-2",
		children: Array.from({ length: e.tileCount }, (e, t) => /* @__PURE__ */ _(fe, {
			note: r("$center", t),
			label: a("games.tagiron.noteTitle", {
				name: a("games.tagiron.centerShort"),
				n: t + 1
			}),
			onEdit: () => i("$center", t)
		}, t))
	}), /* @__PURE__ */ _("div", {
		className: "tagiron-opponents",
		children: o.map((t) => /* @__PURE__ */ _(me, {
			pub: e,
			rid: t,
			name: n(t),
			noteAt: (e) => r(t, e),
			onEdit: (e) => i(t, e)
		}, t))
	})] });
}
function fe({ pin: e, note: t, midBadge: n, label: r, onEdit: i }) {
	let a = e != null, o = t.b && t.w ? "✗" : t.b ? "○" : t.w ? "●" : "";
	return /* @__PURE__ */ v("button", {
		type: "button",
		"aria-label": r,
		onClick: i,
		className: "tagiron-clue-slot flex w-12 flex-none flex-col items-center transition-transform active:translate-y-0.5",
		children: [
			a && e === 5 ? /* @__PURE__ */ _(J, {
				tile: {
					n: 5,
					c: "g"
				},
				w: 48
			}) : /* @__PURE__ */ _(ae, {
				w: 48,
				accent: E.accent,
				label: a ? String(e) : void 0
			}),
			!a && /* @__PURE__ */ _("span", {
				className: "tagiron-note-digits w-14 text-center font-mono text-[9px] leading-3 whitespace-nowrap tabular-nums text-ink-soft",
				children: ue(t)
			}),
			/* @__PURE__ */ _("span", {
				className: `tagiron-note-mark text-[9px] leading-3 font-bold ${o === "✗" ? "text-danger-ink" : "text-info-ink"}`,
				children: [n, o].filter(Boolean).join(" ") || " "
			})
		]
	});
}
var pe = {
	even: "games.tagiron.clueEven",
	odd: "games.tagiron.clueOdd",
	black: "games.tagiron.clueBlack",
	white: "games.tagiron.clueWhite",
	blackSum: "games.tagiron.clueBlackSum",
	whiteSum: "games.tagiron.clueWhiteSum",
	left: "games.tagiron.clueLeft",
	mid: "games.tagiron.clueMid",
	right: "games.tagiron.clueRight",
	pair: "games.tagiron.cluePair",
	sum: "games.tagiron.clueSum",
	diff: "games.tagiron.clueDiff",
	same: "games.tagiron.clueSame",
	seq: "games.tagiron.clueSeq",
	none: "games.tagiron.clueNone"
};
function me({ pub: e, rid: t, name: n, noteAt: r, onEdit: i }) {
	let a = c(), o = re(e.log, t, e.tileCount), s = Math.floor(e.tileCount / 2), l = (e) => {
		if ("at" in e) {
			let t = e.at.length ? e.at.map(([e, t]) => `${e + 1}-${t + 1}`).join("·") : a("games.tagiron.ansNone");
			return a(pe[e.k], { at: t });
		}
		return a(pe[e.k], { n: e.n });
	}, u = n ?? a("games.tagiron.oppShort");
	return /* @__PURE__ */ v("div", {
		className: "tagiron-clue-block flex flex-none flex-col gap-1",
		children: [
			n && /* @__PURE__ */ _("p", {
				className: "text-center text-[10px] font-bold text-ink-soft",
				children: n
			}),
			/* @__PURE__ */ _("div", {
				className: "tagiron-clue-row flex items-start justify-center gap-2",
				children: o.pins.map((e, t) => /* @__PURE__ */ _(fe, {
					pin: e,
					note: r(t),
					midBadge: o.middle && t === s ? o.middle === "ge5" ? "≥5" : "≤4" : null,
					label: a("games.tagiron.noteTitle", {
						name: u,
						n: t + 1
					}),
					onEdit: () => i(t)
				}, t))
			}),
			o.facts.length > 0 && /* @__PURE__ */ _("div", {
				className: "tagiron-facts flex flex-wrap justify-center gap-1",
				children: o.facts.map((e, t) => /* @__PURE__ */ _("span", {
					className: "rounded border border-ink/30 bg-surface px-1 font-mono text-[9px] leading-3.5 tabular-nums text-ink-soft",
					children: l(e)
				}, t))
			})
		]
	});
}
function he({ className: e, children: t }) {
	return /* @__PURE__ */ _("span", {
		className: `rounded-md border border-ink px-1 text-[10px] leading-4 font-bold ${e}`,
		children: t
	});
}
function ge({ name: e, children: t }) {
	let { ref: n } = o(e);
	return /* @__PURE__ */ _("span", {
		ref: n,
		className: "flex-none",
		children: t
	});
}
function _e({ id: e, selected: t, disabled: n, onPick: r }) {
	let i = c(), { ref: a } = o(`qcard:${e}`), s = I.has(e);
	return /* @__PURE__ */ v("button", {
		ref: a,
		type: "button",
		"aria-label": i(Y[e]),
		"aria-pressed": t,
		disabled: n,
		onClick: r,
		className: `tagiron-question flex min-h-14 flex-col items-start gap-0.5 rounded-lg border-2 p-2 text-left transition-transform active:translate-y-0.5 disabled:cursor-default ${t ? "border-info bg-info-soft" : "border-ink bg-surface"} ${n ? "opacity-80" : ""}`,
		children: [/* @__PURE__ */ _("span", {
			className: "line-clamp-2 text-xs leading-4 font-bold",
			children: i(Y[e])
		}), s && /* @__PURE__ */ _("span", {
			className: "rounded-md border border-ink bg-warn-soft px-1 text-[10px] leading-4 font-bold text-warn-ink",
			children: i("games.tagiron.sharedBadge")
		})]
	});
}
function ve({ open: e, tileCount: t, onClose: n, onConfirm: r }) {
	let o = c(), [s, l] = i([]), [d, f] = i(0), [p, m] = i(!1);
	e !== p && (m(e), e && (l(Array.from({ length: t }, () => ({
		n: 0,
		c: "b"
	}))), f(0)));
	let h = s[d], g = (e) => l((t) => t.map((t, n) => n === d ? e : t));
	return /* @__PURE__ */ _(a, {
		open: e,
		onClose: n,
		label: o("games.tagiron.declare"),
		children: /* @__PURE__ */ v("div", {
			className: "tagiron-declare-sheet flex flex-col gap-3 p-1",
			style: { "--tagiron-declare-count": t },
			children: [
				/* @__PURE__ */ _("p", {
					className: "tagiron-sheet-title text-sm font-bold",
					children: o("games.tagiron.declareTitle")
				}),
				/* @__PURE__ */ _("div", {
					className: "tagiron-declare-preview flex justify-center gap-1.5",
					children: s.map((e, t) => /* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => f(t),
						className: `rounded transition-transform ${d === t ? "-translate-y-1 ring-3 ring-ink" : ""}`,
						"aria-label": `${t + 1}`,
						children: /* @__PURE__ */ _(J, {
							tile: e,
							w: 52
						})
					}, t))
				}),
				/* @__PURE__ */ _("div", {
					className: "tagiron-sheet-digits grid grid-cols-5 gap-1.5",
					children: Array.from({ length: 10 }, (e, t) => /* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => h && g({
							n: t,
							c: t === 5 ? "g" : h.c === "g" ? "b" : h.c
						}),
						className: `min-h-11 rounded-lg border-2 border-ink font-display text-lg font-extrabold ${h?.n === t ? "bg-info-soft text-info-ink" : "bg-surface"}`,
						children: t
					}, t))
				}),
				/* @__PURE__ */ _("div", {
					className: "tagiron-sheet-colors grid grid-cols-2 gap-1.5",
					children: ["b", "w"].map((e) => /* @__PURE__ */ _("button", {
						type: "button",
						disabled: h?.n === 5,
						onClick: () => h && g({
							n: h.n,
							c: e
						}),
						className: `min-h-11 rounded-lg border-2 border-ink font-bold disabled:opacity-40 ${e === "b" ? "bg-stone-800 text-stone-50" : "bg-surface"} ${h?.c === e || h?.n === 5 && 0 ? "ring-3 ring-info" : ""}`,
						children: e === "b" ? "●" : "○"
					}, e))
				}),
				/* @__PURE__ */ v("button", {
					type: "button",
					onClick: () => s.length === t && r(s),
					className: "tagiron-sheet-confirm btn-base bg-pop text-white",
					children: [
						/* @__PURE__ */ _(u, {
							size: 18,
							"aria-hidden": !0
						}),
						" ",
						o("games.tagiron.declareConfirm")
					]
				})
			]
		})
	});
}
function ye({ name: e, idx: t, pin: n, note: r, onToggleDigit: i, onToggleColor: o, onReset: s, onClose: l }) {
	let u = c(), d = u("games.tagiron.noteTitle", {
		name: e,
		n: t + 1
	});
	return /* @__PURE__ */ _(a, {
		open: !0,
		onClose: l,
		label: d,
		children: /* @__PURE__ */ v("div", {
			className: "tagiron-note-sheet flex flex-col gap-2 p-1",
			children: [
				/* @__PURE__ */ _("p", {
					className: "tagiron-sheet-title text-sm font-bold",
					children: d
				}),
				n !== null && /* @__PURE__ */ _("p", {
					className: "text-xs font-bold text-info-ink",
					children: u("games.tagiron.notePinned", { n })
				}),
				/* @__PURE__ */ _("p", {
					className: "section-label",
					children: u("games.tagiron.noteDigits")
				}),
				/* @__PURE__ */ _("div", {
					className: "tagiron-sheet-digits grid grid-cols-5 gap-1.5",
					children: Array.from({ length: 10 }, (e, t) => {
						let a = !!(r.d & 1 << t);
						return /* @__PURE__ */ _("button", {
							type: "button",
							disabled: n !== null,
							"aria-pressed": a,
							onClick: () => i(t),
							className: `min-h-11 rounded-lg border-2 border-ink bg-surface font-display text-lg font-extrabold disabled:opacity-70 ${a ? "text-ink-soft line-through opacity-40" : ""}`,
							children: t
						}, t);
					})
				}),
				/* @__PURE__ */ _("p", {
					className: "section-label",
					children: u("games.tagiron.noteColors")
				}),
				/* @__PURE__ */ _("div", {
					className: "tagiron-sheet-colors grid grid-cols-2 gap-1.5",
					children: ["b", "w"].map((e) => /* @__PURE__ */ _("button", {
						type: "button",
						"aria-pressed": r[e],
						onClick: () => o(e),
						className: `min-h-11 rounded-lg border-2 border-ink font-bold ${e === "b" ? "bg-stone-800 text-stone-50" : "bg-surface"} ${r[e] ? "line-through opacity-40" : ""}`,
						children: e === "b" ? "●" : "○"
					}, e))
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					onClick: s,
					className: "tagiron-sheet-reset btn-quiet",
					children: u("games.tagiron.noteReset")
				})
			]
		})
	});
}
//#endregion
//#region src/games/tagiron/deduce.ts
var be = z([...F.filter((e) => e.c !== "g"), {
	n: 5,
	c: "g"
}]), Z = (e) => `${e.c}${e.n}`;
function xe(e, t) {
	let n = be.filter((t) => (e.get(Z(t)) ?? 0) > 0), r = [], i = [], a = (o) => {
		if (i.length === t) {
			r.push([...i]);
			return;
		}
		for (let r = o; r < n.length; r += 1) {
			let o = n[r], s = Z(o), c = e.get(s) ?? 0;
			for (let e = 0; e < c && i.length < t; e += 1) i.push(o), a(r + 1);
			for (let e = 0; e < c; e += 1) i.pop();
		}
	};
	return a(0), r;
}
var Q = (...e) => {
	let t = /* @__PURE__ */ new Map();
	for (let e of F) t.set(Z(e), (t.get(Z(e)) ?? 0) + 1);
	for (let n of e) for (let e of n) t.set(Z(e), (t.get(Z(e)) ?? 0) - 1);
	return t;
}, Se = (e, t) => {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(Z(t), (n.get(Z(t)) ?? 0) + 1);
	for (let [e, r] of n) if ((t.get(e) ?? 0) < r) return !1;
	return !0;
}, Ce = (e, t) => JSON.stringify(e) === JSON.stringify(t);
function we(e, t, n) {
	let r = e;
	for (let e of t) {
		if (e.k !== "ask") continue;
		let t = e.answers[n];
		t && (r = r.filter((n) => Ce(B(e.card, e.option, n), t)));
	}
	return r;
}
function Te(e, t) {
	let n = e.public, r = e.private?.hand ?? [], i = n.players.map((e) => e.rid).filter((e) => e !== t), a = /* @__PURE__ */ new Map();
	for (let e of i) a.set(e, we(xe(Q(r), n.tileCount), n.log, e));
	return i.length === 1 ? {
		targets: a.get(i[0]) ?? [],
		perOpponent: a
	} : {
		targets: xe(Q(r), n.tileCount).filter((e) => {
			let t = Q(r, e);
			for (let e of i) if (!(a.get(e) ?? []).some((e) => Se(e, t))) return !1;
			return !0;
		}),
		perOpponent: a
	};
}
//#endregion
//#region src/games/tagiron/bot.ts
function Ee(e, t, n) {
	let r = null;
	for (let i of e.field) {
		let a = L[i] ? [...L[i]] : i === 20 ? ["ge5", "le4"] : [void 0];
		for (let o of a) {
			let a = I.has(i) || e.players.length === 4, s = 0;
			for (let [e, r] of t) {
				if (!a && e === n || r.length === 0) continue;
				let t = /* @__PURE__ */ new Map();
				for (let e of r) {
					let n = JSON.stringify(B(i, o, e));
					t.set(n, (t.get(n) ?? 0) + 1);
				}
				let c = 0;
				for (let e of t.values()) c += e * e / r.length;
				s += r.length - c;
			}
			(!r || s > r.gain) && (r = {
				card: i,
				option: o,
				gain: s
			});
		}
	}
	return r ? {
		card: r.card,
		option: r.option
	} : null;
}
var De = (e, t) => {
	let n = e.public;
	if (n.phase === "done") return null;
	let r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	let i = Te(e, t.rid), a = i.targets[0];
	if (n.phase === "counter") return n.turn === t.rid && a ? { action: {
		type: "declare",
		tiles: a
	} } : null;
	if (n.turn !== t.rid || r.state !== "active") return null;
	let o = n.closing !== null && r.turns + 1 >= n.closing;
	if (a && (i.targets.length === 1 || o && !r.declared)) return { action: {
		type: "declare",
		tiles: a
	} };
	if (t.difficulty === "weak") {
		let e = n.field[(n.log.length + n.deckCount) % n.field.length], t = L[e], r = t ? t[n.log.length % 2] : e === 20 ? n.log.length % 2 == 0 ? "ge5" : "le4" : void 0;
		return { action: {
			type: "ask",
			card: e,
			...r === void 0 ? {} : { option: r }
		} };
	}
	let s = Ee(n, i.perOpponent, t.rid);
	return s ? { action: {
		type: "ask",
		card: s.card,
		...s.option === void 0 ? {} : { option: s.option }
	} } : null;
}, Oe = (e, t, n) => e.type === "declare" ? n("games.tagiron.hintDeclare") : e.type === "ask" ? n("games.tagiron.hintAsk", { card: n(`games.tagiron.q${e.card}`) }) : "", $ = 56;
function ke({ spacious: e, children: t }) {
	return e ? /* @__PURE__ */ _("span", {
		style: {
			display: "block",
			width: $,
			height: Math.round($ * 1.35)
		},
		children: t
	}) : t;
}
var Ae = {
	deal(e, t) {
		let n = (t.anchor("tagiron-fx-metric")?.w ?? 0) > 0, r = e.secret;
		if (r && Array.isArray(r.hand)) {
			let i = t.anchor("qcard:0") ?? t.anchor(`seat:${e.rid}`);
			if (!i) return null;
			let a = [], o = [];
			for (let [e, s] of r.hand.entries()) {
				let r = t.anchor(`tile:${s.c}${s.n}`);
				r && (o.push(`tile:${s.c}${s.n}`), a.push(/* @__PURE__ */ _(b, {
					from: i,
					to: r,
					ms: 320,
					delay: e * 60,
					children: /* @__PURE__ */ _(ke, {
						spacious: n,
						children: /* @__PURE__ */ _(J, {
							tile: s,
							w: $,
							elevated: !0
						})
					})
				}, `${s.c}${s.n}`)));
			}
			return a.length ? {
				ms: 320 + a.length * 60,
				node: a,
				hide: o
			} : null;
		}
		let i = e.rid ? t.anchor(`seat:${e.rid}`) : null, a = t.anchor("qcard:0") ?? i;
		if (!a || !i) return null;
		let o = e.data?.count, s = typeof o == "number" ? o : 5;
		return {
			ms: 320 + s * 60,
			node: Array.from({ length: s }, (e, t) => /* @__PURE__ */ _(b, {
				from: a,
				to: i,
				ms: 320,
				delay: t * 60,
				children: /* @__PURE__ */ _(ke, {
					spacious: n,
					children: /* @__PURE__ */ _(ae, {
						w: $,
						accent: E.accent
					})
				})
			}, t))
		};
	},
	ask(e, t) {
		let n = e.data, r = typeof n?.card == "number" ? t.anchor(`qcard:${n.card}`) : null;
		return r ? {
			ms: 700,
			node: /* @__PURE__ */ _(x, {
				at: r,
				ms: 700
			})
		} : null;
	},
	declare(e, t) {
		let n = e.data;
		if (typeof n?.ok != "boolean") return null;
		let r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return r ? {
			ms: 1100,
			node: /* @__PURE__ */ _(y, {
				at: r,
				ms: 1e3,
				children: /* @__PURE__ */ _("span", {
					style: (t.anchor("tagiron-fx-metric")?.w ?? 0) > 0 ? { fontSize: Math.max(36, Math.min(80, r.w * .8)) } : void 0,
					className: `font-display text-3xl font-extrabold ${n.ok ? "text-done-ink" : "text-danger-ink"}`,
					children: n.ok ? "✓" : "✗"
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/tagiron/game-over-row.tsx
function je({ public: e, rid: t }) {
	let n = c(), r = e;
	if (!r.reveal) return null;
	let i = r.reveal.$center;
	if (i) return t === r.players[0]?.rid ? /* @__PURE__ */ v("div", {
		className: "tagiron-result-row mt-1",
		style: { "--tagiron-result-count": r.tileCount },
		children: [/* @__PURE__ */ _("span", {
			className: "tagiron-result-label mr-1 text-xs font-bold text-ink-soft",
			children: n("games.tagiron.targetCenter", { n: r.tileCount })
		}), /* @__PURE__ */ _("span", {
			className: "tagiron-result-tiles inline-flex gap-1 align-middle",
			children: i.map((e, t) => /* @__PURE__ */ _(J, {
				tile: e,
				w: 30
			}, `${e.c}${e.n}:${t}`))
		})]
	}) : null;
	let a = r.reveal[t];
	return a ? /* @__PURE__ */ v("div", {
		className: "tagiron-result-row mt-1",
		style: { "--tagiron-result-count": r.tileCount },
		children: [/* @__PURE__ */ _("span", {
			className: "tagiron-result-label mr-1 text-xs font-bold text-ink-soft",
			children: n("games.tagiron.myTiles")
		}), /* @__PURE__ */ _("span", {
			className: "tagiron-result-tiles inline-flex gap-1 align-middle",
			children: a.map((e, t) => /* @__PURE__ */ _(J, {
				tile: e,
				w: 30
			}, `${e.c}${e.n}:${t}`))
		})]
	}) : null;
}
//#endregion
//#region src/games/tagiron/game-over.tsx
function Me(e, t) {
	let n = e.players.length, r = n === 4 ? 4 : 5;
	return e.phase !== "done" || n < 2 || n > 4 || e.tileCount !== r || !e.reveal || t.ranking.length !== n || new Set(t.ranking).size !== n || !t.ranking.every((t) => e.players.some((e) => e.rid === t)) ? !1 : n === 2 ? t.ranking.every((t) => e.reveal?.[t]?.length === r) : e.reveal.$center?.length === r;
}
function Ne(e, t) {
	return e === 2 && (t === 0 || t === 2) ? "games.tagiron.overDraw" : e > 2 && t === 0 ? "games.tagiron.overNoWinner" : e > 2 && t > 1 ? "games.tagiron.overSharedWin" : null;
}
function Pe(e, t, i, a) {
	let o = r(null);
	return n(() => {
		let n = o.current;
		if (!n) return;
		let r = window.matchMedia("(orientation: landscape)"), s = [
			"pad",
			"gap",
			"top",
			"actions",
			"panel-pad",
			"tile",
			"flow-tile",
			"row-h",
			"center-h",
			"rank-h",
			"identity-w",
			"identity-h",
			"avatar",
			"name-font",
			"meta-font",
			"score-font",
			"heading-font",
			"outcome-font",
			"center-font",
			"button-font",
			"rank-cols"
		], c = (e, t, r = "px") => {
			let i = r ? `${t.toFixed(4)}${r}` : String(t);
			n.style.getPropertyValue(`--tagiron-over-${e}`) !== i && n.style.setProperty(`--tagiron-over-${e}`, i);
		}, l = (e, t, n) => Math.min(n, Math.max(e, t)), u = () => {
			let { width: o, height: u } = n.getBoundingClientRect(), d = r.matches && o >= 900 && u >= 400, f = e === 2 && o / u < 1.25, p = d ? e === 2 ? f ? "duel-stack" : "duel" : "shelf" : "flow";
			if (n.dataset.tagironOver !== p && (n.dataset.tagironOver = p), !d) {
				delete n.dataset.tagironOverCard;
				let a = r.matches && o >= 600, l = a ? "true" : "false";
				n.dataset.tagironOverWide !== l && (n.dataset.tagironOverWide = l);
				for (let e of s) e !== "actions" && e !== "flow-tile" && n.style.getPropertyValue(`--tagiron-over-${e}`) && n.style.removeProperty(`--tagiron-over-${e}`);
				let d = i > 1 && !a ? 104 : i > 0 ? 48 : 44;
				if (c("actions", d), a) {
					let n = u - 8 - 52 - d - 16, r = (o - 8 - 26 - (e === 2 ? 208 : 0) - (t - 1) * 8) / t, i = n - 26 - (e === 2 ? 0 : 33);
					c("flow-tile", Math.max(52, Math.min(r, i * 52 / 70)));
				} else n.style.getPropertyValue("--tagiron-over-flow-tile") && n.style.removeProperty("--tagiron-over-flow-tile");
				return;
			}
			delete n.dataset.tagironOverWide, n.style.getPropertyValue("--tagiron-over-flow-tile") && n.style.removeProperty("--tagiron-over-flow-tile");
			let m = l(6, Math.min(o, u) * .01, 12), h = l(8, Math.min(o, u) * .012, 14), g = l(52, u * .085, 88), _ = i > 0 ? l(56, u * .08, 80) : 44, v = u - 2 * m - g - _ - 2 * h, y = o - 2 * m, b = l(8, Math.min(o, u) * .012, 16), x = 70 / 52, S = e === 4 && o / u < 1.25 ? 2 : e, C = Math.ceil(e / S), w = l(22, o * .022, 32), T = f ? y - 2 * b - 6 : Math.max(220, y * .25), E, D, O = 0, k = 0, A = v;
			if (e === 2) E = (v - h) / 2, O = f ? l(96, E * .3, 120) : E - 2 * b - 6, D = f ? Math.min((y - 2 * b - 6 - 4 * h) / 5, (E - 2 * b - 6 - O - h) / x) : Math.min((y - 2 * b - 6 - T - 5 * h) / 5, (E - 2 * b - 6) / x);
			else {
				let e = C * (C > 1 ? l(104, u * .13, 160) : l(112, u * .16, 176)) + (C - 1) * h;
				D = Math.min((y - 2 * b - 6 - (t - 1) * h) / t, (v - e - 2 * h - 2 * b - 6 - w * 1.25) / x), k = 2 * b + 6 + w * 1.25 + h + D * x, A = v - k - h, E = (A - (C - 1) * h) / C;
			}
			let j = (y - (S - 1) * h) / S, M = e > 2 && j < 360 && E >= 240, N = M ? "vertical" : "horizontal";
			n.dataset.tagironOverCard !== N && (n.dataset.tagironOverCard = N);
			let P = f ? l(22, O * .3, 34) : e === 2 ? l(20, E * .13, 48) : l(22, Math.min(E * .17, j * .09), 40), F = l(14, E * .055, 18), I = l(24, E * .19, 80), L = E - 2 * b - 6 - h - P * 1.25 - 4 - 2 * (F * 1.25 + 4) - (a ? h + I * 1.1 : 0), R = f ? l(48, O * .85, 96) : e === 2 ? l(48, E * .38, 112) : M ? Math.min(E * .54, j * .65, L) : l(48, E * .5, 180), z = {
				pad: m,
				gap: h,
				top: g,
				actions: _,
				"panel-pad": b,
				tile: D,
				"row-h": E,
				"center-h": k,
				"rank-h": A,
				"identity-w": T,
				"identity-h": O,
				avatar: R,
				"name-font": P,
				"meta-font": F,
				"score-font": I,
				"heading-font": l(24, g * .46, 42),
				"outcome-font": l(16, g * .25, 22),
				"center-font": w,
				"button-font": l(18, _ * .34, 26)
			};
			for (let [e, t] of Object.entries(z)) c(e, t);
			c("rank-cols", S, "");
		}, d = new ResizeObserver(u);
		return d.observe(n), r.addEventListener("change", u), u(), () => {
			d.disconnect(), r.removeEventListener("change", u), delete n.dataset.tagironOver, delete n.dataset.tagironOverCard, delete n.dataset.tagironOverWide;
			for (let e of s) n.style.removeProperty(`--tagiron-over-${e}`);
		};
	}, [
		e,
		t,
		i,
		a
	]), o;
}
function Fe(e) {
	let t = N.safeParse(e.public);
	if (t.success && Me(t.data, e.result)) return /* @__PURE__ */ _(Ie, {
		...e,
		pub: t.data
	});
	let n = t.success && t.data.phase === "done" ? t.data : null;
	return /* @__PURE__ */ _(T, {
		result: e.result,
		members: e.members,
		myRid: e.myRid,
		accent: E.accent,
		onPlayAgain: e.onPlayAgain,
		onBackToLobby: e.onBackToLobby,
		renderRowExtra: n ? (t) => /* @__PURE__ */ _(je, {
			public: n,
			rid: t,
			myRid: e.myRid
		}) : void 0
	});
}
function Ie({ pub: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let o = c(), u = s((e) => e.locale), f = e.players.length, p = f === 2, m = Pe(f, e.tileCount, Number(!!i) + Number(!!a), t.ranking.some((e) => t.scores?.[e] !== void 0)), g = Ne(f, t.winner.length), y = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? h(t, u) : e;
	};
	return /* @__PURE__ */ v("div", {
		ref: m,
		className: "tagiron-over",
		style: {
			"--tagiron-over-accent": E.accent,
			"--tagiron-over-tile-count": e.tileCount
		},
		children: [/* @__PURE__ */ _(w, {}), /* @__PURE__ */ _(d, {
			adaptive: !0,
			scroll: !1,
			actionsHeight: "tagiron-over-action-height",
			banner: /* @__PURE__ */ v("header", {
				className: "tagiron-over-heading",
				children: [/* @__PURE__ */ _("h1", { children: o("session.result.title") }), g && /* @__PURE__ */ _("p", { children: o(g) })]
			}),
			actions: i || a ? /* @__PURE__ */ v("div", {
				className: "tagiron-over-actions",
				children: [i && /* @__PURE__ */ _("button", {
					type: "button",
					className: "btn-base text-white",
					style: { background: E.accent },
					onClick: i,
					children: o("session.result.playAgain")
				}), a && /* @__PURE__ */ _("button", {
					type: "button",
					className: "btn-quiet",
					onClick: a,
					children: o("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ _("p", {
				className: "tagiron-over-wait",
				children: o("session.result.waitHost")
			}),
			children: /* @__PURE__ */ _("div", {
				className: "tagiron-over-body",
				children: /* @__PURE__ */ v("div", {
					className: `tagiron-over-composition${p ? " tagiron-over-duel" : ""}`,
					children: [!p && /* @__PURE__ */ v("section", {
						className: "tagiron-over-center",
						children: [/* @__PURE__ */ _("h2", { children: o("games.tagiron.overCenter") }), /* @__PURE__ */ _("div", {
							className: "tagiron-over-tiles",
							children: e.reveal?.$center?.map((e, t) => /* @__PURE__ */ _(J, {
								tile: e,
								w: 52
							}, `${e.c}${e.n}:${t}`))
						})]
					}), /* @__PURE__ */ _("ol", {
						className: "tagiron-over-ranking",
						children: t.ranking.map((i, a) => {
							let s = n.find((e) => e.rid === i), c = t.winner.includes(i), u = t.autopilot?.[i];
							return /* @__PURE__ */ v("li", {
								className: "tagiron-over-card",
								"data-winner": c,
								children: [/* @__PURE__ */ v("div", {
									className: "tagiron-over-identity",
									children: [
										/* @__PURE__ */ v("span", {
											className: "tagiron-over-avatar",
											style: { backgroundColor: C[(s?.colorIndex ?? 0) % C.length].hex },
											children: [
												s && /* @__PURE__ */ _("img", {
													src: S[s.avatar % S.length],
													alt: "",
													draggable: !1
												}),
												/* @__PURE__ */ _("b", {
													className: "tagiron-over-rank",
													children: a + 1
												}),
												c && /* @__PURE__ */ _("span", {
													className: "tagiron-over-crown",
													"aria-hidden": !0,
													children: "👑"
												})
											]
										}),
										/* @__PURE__ */ v("div", {
											className: "tagiron-over-person",
											children: [/* @__PURE__ */ _("strong", {
												title: y(i),
												children: y(i)
											}), /* @__PURE__ */ v("span", {
												className: "tagiron-over-meta",
												children: [i === r && /* @__PURE__ */ _("small", { children: o("lobby.you") }), u !== void 0 && u > 0 && /* @__PURE__ */ v("small", {
													className: "tagiron-over-autopilot",
													children: [/* @__PURE__ */ _(l, { size: 14 }), o("session.autopilot.share", { n: Math.round(u * 100) })]
												})]
											})]
										}),
										t.scores?.[i] !== void 0 && /* @__PURE__ */ _("b", {
											className: "tagiron-over-score",
											children: t.scores[i]
										})
									]
								}), p && /* @__PURE__ */ _("div", {
									className: "tagiron-over-tiles",
									role: "group",
									"aria-label": o("games.tagiron.overHand", { name: y(i) }),
									children: e.reveal?.[i]?.map((e, t) => /* @__PURE__ */ _(J, {
										tile: e,
										w: 52
									}, `${e.c}${e.n}:${t}`))
								})]
							}, i);
						})
					})]
				})
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/tagiron/entry.tsx
var Le = {
	definition: te,
	View: oe,
	bot: De,
	describe: Oe,
	fx: Ae,
	OverView: Fe,
	RowView: je,
	locales: {
		zh: {
			name: "逻辑对决",
			desc: "用提问缩小范围,抢先破译对方的数字密码",
			rules: "目标:猜中目标牌的数字与颜色,全部正确才算猜中。\n· 2 人局猜中对手的 5 张牌。\n· 3-4 人局猜中桌面中央扣置的牌(3 人 5 张、4 人 4 张)。\n准备:\n· 数字牌共 20 枚:数字 0 至 9 每个数字两枚,分别为黑色与白色。\n· 其中 5 的两枚为绿色。\n· 每人随机取牌(2-3 人 5 张、4 人 4 张),按数字升序从左到右排列。\n· 同数字时黑色在左。\n· 3-4 人局另扣置同样数量的牌于桌面中央;2 人局剩余牌移出游戏。\n· 问卡共 21 张,洗混后翻开 6 张作公共场。\n· 4 人局先除外「中间 3 张之和」与「中间的牌」两张。\n流程:\n· 轮到你时二选一:从场上选 1 张问卡提问,或宣言猜测。\n· 提问的回答者:2 人局由对手回答;3 人局由另两人回答;4 人局所有提问均全员作答。\n· 标注「共享」的卡由全员作答(含提问者);问过的卡弃掉,从牌堆补一张入场。\n· 宣言:按从左到右顺序报出目标全部牌的数字与颜色;只告知全对或有错,不透露错在何处。\n· 2 人局猜错后留在游戏中,之后回合可再次宣言。\n· 3-4 人局每人仅有一次宣言机会,猜错即出局,但仍须回答他人提问。\n结束:\n· 2 人局:先手猜中时,后手获得一次立即反猜的机会,也猜中则平局;问卡耗尽仍无人猜中为平局。\n· 3-4 人局:有人猜中后,其余在局者补完当前轮次,所有猜中者并列获胜。\n· 全员出局或问卡耗尽则无胜者。",
			q0: "数字 0 在哪里?",
			q1: "数字 1 或 2 在哪里?",
			q2: "数字 3 或 4 在哪里?",
			q3: "数字 5 在哪里?",
			q4: "数字 6 或 7 在哪里?",
			q5: "数字 8 或 9 在哪里?",
			q6: "偶数有几张?(含 0)",
			q7: "奇数有几张?",
			q8: "黑色数字牌有几张?",
			q9: "白色数字牌有几张?",
			q10: "黑色数字之和是?",
			q11: "白色数字之和是?",
			q12: "左起 3 张之和是?",
			q13: "中间 3 张之和是?",
			q14: "右起 3 张之和是?",
			q15: "相邻同色的牌在哪里?",
			q16: "数字相邻连续的牌在哪里?",
			q17: "相同数字的对子有几组?",
			q18: "全部数字之和是?",
			q19: "最大数减最小数是?",
			q20: "中间的牌 ≥5 还是 ≤4?",
			sharedBadge: "共享",
			qLocate: "数字 {{n}} 在哪里?",
			q20ge5: "中间的牌 ≥5?",
			q20le4: "中间的牌 ≤4?",
			turnYou: "轮到你:提问或宣言",
			turnWait: "等 {{name}} 行动…",
			counterYou: "对手猜中了!你有一次反猜机会",
			counterWait: "{{name}} 猜中了,等 {{counter}} 反猜…",
			youDone: "你已猜中,等待补完当前轮…",
			youOut: "你已出局,观看中",
			deckLeft: "牌堆 {{n}}",
			myTiles: "我的牌",
			targetOpponent: "目标:对手的 5 张",
			targetCenter: "目标:中央 {{n}} 张",
			clueEven: "偶{{n}}",
			clueOdd: "奇{{n}}",
			clueBlack: "●{{n}}",
			clueWhite: "○{{n}}",
			clueBlackSum: "●和{{n}}",
			clueWhiteSum: "○和{{n}}",
			clueLeft: "左{{n}}",
			clueMid: "中{{n}}",
			clueRight: "右{{n}}",
			cluePair: "对子{{n}}",
			clueSum: "总和{{n}}",
			clueDiff: "差{{n}}",
			clueSame: "同色{{at}}",
			clueSeq: "连续{{at}}",
			clueNone: "无{{n}}",
			oppShort: "对手",
			centerShort: "中央",
			noteTitle: "笔记:{{name}} 第 {{n}} 张",
			noteDigits: "点掉不可能的数字",
			noteColors: "点掉不可能的颜色(5 恒为绿色)",
			noteReset: "重置此格",
			notePinned: "定位卡已钉死:数字 {{n}}",
			pickQuestion: "点一张问卡提问",
			askConfirm: "发问",
			askNumber: "问数字 {{n}}",
			askGe5: "问「≥5?」",
			askLe4: "问「≤4?」",
			declare: "宣言猜测",
			declareTitle: "按从左到右顺序填出答案",
			declareConfirm: "确认宣言",
			declareUsed: "宣言机会已用",
			cancel: "取消",
			stDone: "已猜中",
			stOut: "已出局",
			logAsk: "{{name}} 问「{{card}}」",
			ansPos: "第 {{at}} 张",
			ansPairs: "第 {{at}} 张",
			ansNone: "没有",
			ansYes: "是",
			ansNo: "否",
			logDeclareOk: "{{name}} 宣言:正确!",
			logDeclareWrong: "{{name}} 宣言:错误",
			errPhase: "现在不能这么做",
			errNotYourTurn: "还没轮到你",
			errBadCard: "这张问卡不在场上",
			errBadOption: "子选项不对",
			errBadGuess: "猜测的数量不对",
			overHand: "{{name}} 的数字牌",
			overCenter: "中央谜底",
			overDraw: "平局",
			overNoWinner: "无胜者",
			overSharedWin: "共同获胜",
			hintAsk: "提问「{{card}}」",
			hintDeclare: "信息够了,直接宣言"
		},
		en: {
			name: "Break the Code",
			desc: "Ask sharp questions and crack the hidden code first",
			rules: "Goal: guess the numbers and colors of the target tiles; everything must be exactly right.\n· With 2 players, guess your opponent's 5 tiles.\n· With 3-4 players, guess the face-down tiles in the center (5 with 3 players, 4 with 4 players).\nSetup:\n· 20 cipher tiles: numbers 0-9 each come in one black and one white copy.\n· Both 5s are green.\n· Each player takes tiles at random (5 with 2-3 players, 4 with 4 players) and sorts them ascending from left to right.\n· Black comes before white on ties.\n· With 3-4 players the same number of tiles is placed face down in the center; with 2 players the rest is removed.\n· 21 question cards are shuffled and 6 are revealed face up.\n· With 4 players, remove \"sum of the middle 3\" and \"the middle tile\" first.\nPlay:\n· On your turn, either ask one of the face-up question cards, or declare your guess.\n· Answers: with 2 players only your opponent answers; with 3 players the other two answer; with 4 players every question is answered by everyone.\n· Cards marked \"shared\" are answered by everyone including you; the asked card is discarded and replaced from the deck.\n· Declare: announce all target tiles from left to right, number and color; you only learn whether you were entirely right or wrong, never which part.\n· With 2 players a wrong guess just ends your turn and you may try again later.\n· With 3-4 players you may declare only once per game, and a wrong guess knocks you out (you still answer questions).\nEnd:\n· With 2 players: if the starting player guesses right, the other player gets one immediate counter-guess — a correct one means a tie; if the question cards run out with no correct guess, the game is a draw.\n· With 3-4 players: once someone guesses right, the remaining players finish the current round; everyone who guessed right wins together.\n· If everyone is eliminated or the questions run out, there is no winner.",
			q0: "Where are your 0s?",
			q1: "Where are your 1s or 2s?",
			q2: "Where are your 3s or 4s?",
			q3: "Where are your 5s?",
			q4: "Where are your 6s or 7s?",
			q5: "Where are your 8s or 9s?",
			q6: "How many even tiles? (0 counts)",
			q7: "How many odd tiles?",
			q8: "How many black tiles?",
			q9: "How many white tiles?",
			q10: "Sum of your black numbers?",
			q11: "Sum of your white numbers?",
			q12: "Sum of your 3 leftmost tiles?",
			q13: "Sum of your 3 middle tiles?",
			q14: "Sum of your 3 rightmost tiles?",
			q15: "Which neighboring tiles share a color?",
			q16: "Which neighboring tiles are consecutive?",
			q17: "How many same-number pairs?",
			q18: "Sum of all your numbers?",
			q19: "Highest minus lowest number?",
			q20: "Is the middle tile ≥5 or ≤4?",
			sharedBadge: "Shared",
			qLocate: "Where are the {{n}}s?",
			q20ge5: "Is the middle tile ≥5?",
			q20le4: "Is the middle tile ≤4?",
			turnYou: "Your turn: ask or declare",
			turnWait: "Waiting for {{name}}…",
			counterYou: "Your opponent cracked it! One counter-guess left",
			counterWait: "{{name}} cracked it — waiting for {{counter}} to counter…",
			youDone: "You cracked it! Waiting for the round to finish…",
			youOut: "You are out — spectating",
			deckLeft: "Deck {{n}}",
			myTiles: "My tiles",
			targetOpponent: "Target: opponent's 5 tiles",
			targetCenter: "Target: {{n}} center tiles",
			clueEven: "E{{n}}",
			clueOdd: "O{{n}}",
			clueBlack: "●{{n}}",
			clueWhite: "○{{n}}",
			clueBlackSum: "●Σ{{n}}",
			clueWhiteSum: "○Σ{{n}}",
			clueLeft: "L{{n}}",
			clueMid: "M{{n}}",
			clueRight: "R{{n}}",
			cluePair: "pair {{n}}",
			clueSum: "Σ{{n}}",
			clueDiff: "Δ{{n}}",
			clueSame: "same {{at}}",
			clueSeq: "seq {{at}}",
			clueNone: "no {{n}}",
			oppShort: "Opponent",
			centerShort: "Center",
			noteTitle: "Notes: {{name}} #{{n}}",
			noteDigits: "Tap numbers to rule out",
			noteColors: "Rule out a color (5 is always green)",
			noteReset: "Reset this slot",
			notePinned: "Number {{n}} confirmed by a locate card",
			pickQuestion: "Tap a question card to ask",
			askConfirm: "Ask",
			askNumber: "Ask about {{n}}",
			askGe5: "Ask \"≥5?\"",
			askLe4: "Ask \"≤4?\"",
			declare: "Declare",
			declareTitle: "Fill in the answer from left to right",
			declareConfirm: "Confirm declaration",
			declareUsed: "Declaration already used",
			cancel: "Cancel",
			stDone: "Cracked it",
			stOut: "Out",
			logAsk: "{{name}} asked \"{{card}}\"",
			ansPos: "tile {{at}}",
			ansPairs: "tiles {{at}}",
			ansNone: "none",
			ansYes: "yes",
			ansNo: "no",
			logDeclareOk: "{{name}} declared: correct!",
			logDeclareWrong: "{{name}} declared: wrong",
			errPhase: "Not allowed right now",
			errNotYourTurn: "Not your turn",
			errBadCard: "That card is not on the table",
			errBadOption: "Invalid option",
			errBadGuess: "Wrong number of tiles",
			overHand: "{{name}}'s tiles",
			overCenter: "Center solution",
			overDraw: "Draw",
			overNoWinner: "No winner",
			overSharedWin: "Shared victory",
			hintAsk: "Ask \"{{card}}\"",
			hintDeclare: "You have enough — declare now"
		}
	}
};
//#endregion
export { Le as default };
