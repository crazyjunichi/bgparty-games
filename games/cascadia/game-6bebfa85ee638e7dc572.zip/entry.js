import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { BottomSheet as s } from "@bgparty/sdk/bottom-sheet";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconBack as u, IconBot as d, IconDisconnected as f, IconExpand as p, IconLog as m, IconRecenter as h, IconRotate as g } from "@bgparty/sdk/icons";
import { PhaseBanner as _ } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as v } from "@bgparty/sdk/ui/game-screen";
import { Texture as y } from "@bgparty/sdk/texture";
import { Fragment as b, jsx as x, jsxs as S } from "react/jsx-runtime";
import { useFrame as C, useThree as w } from "@react-three/fiber";
import { CanvasTexture as T, DoubleSide as E, MeshLambertMaterial as D, Path as O, Plane as k, Raycaster as ee, SRGBColorSpace as te, Shape as A, ShapeGeometry as j, Vector2 as ne, Vector3 as M } from "three";
import { ResilientCanvas as re } from "@bgparty/sdk/three/resilient-canvas";
import { usePrefersReducedMotion as ie } from "@bgparty/sdk/fx/use-reduced-motion";
import { botAvatarOf as N, isBotRid as P } from "@bgparty/sdk/lobby";
import { useFxAnchor as ae } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as oe } from "@bgparty/sdk/fx/delta-number";
import { PLAYER_COLORS as se } from "@bgparty/sdk/player-colors";
import { seatName as F } from "@bgparty/sdk/ui/player-strip";
import { botPersonality as I } from "@bgparty/sdk/bot-personality";
import { Floater as L, PulseBox as R } from "@bgparty/sdk/fx/primitives";
import { Confetti as ce } from "@bgparty/sdk/ui/confetti";
import { OptionCheckbox as le, OptionRadio as ue, OptionSection as de } from "@bgparty/sdk/ui/game-options";
//#region src/games/cascadia/hex.ts
var fe = [
	[0, 1],
	[1, 0],
	[1, -1],
	[0, -1],
	[-1, 0],
	[-1, 1]
];
function z(e, t) {
	return `${e},${t}`;
}
function B(e) {
	let t = e.indexOf(",");
	return [Number(e.slice(0, t)), Number(e.slice(t + 1))];
}
function V(e, t) {
	let [n, r] = B(e), [i, a] = fe[t];
	return z(n + i, r + a);
}
function H(e) {
	let [t, n] = B(e);
	return fe.map(([e, r]) => z(t + e, n + r));
}
function U(e, t, n) {
	let r = ((n - t) % 6 + 6) % 6;
	return e.edges ? e.edges[r] : r >= 3 ? e.h[0] : e.h[1];
}
function W(e) {
	let t = new Set(e), n = [];
	for (let e of [...t]) {
		if (!t.has(e)) continue;
		t.delete(e);
		let r = [e];
		for (let e = 0; e < r.length; e++) for (let n of H(r[e])) t.delete(n) && r.push(n);
		n.push(r);
	}
	return n;
}
function pe(e, t, n) {
	let [r, i] = B(e), [a, o] = B(t), s = a - r, c = o - i;
	for (let [e, t] of fe) {
		let a = e === 0 ? c * t : s * e;
		if (!(a <= 0) && s === a * e && c === a * t) {
			for (let o = 1; o < a; o++) if (n(z(r + e * o, i + t * o))) return !1;
			return !0;
		}
	}
	return !1;
}
//#endregion
//#region src/games/cascadia/meta.ts
var me = {
	id: "cascadia",
	tier: "released",
	mechanics: ["drafting", "tile-placement"],
	interactionTags: [],
	nameKey: "games.cascadia.name",
	descKey: "games.cascadia.desc",
	rulesKey: "games.cascadia.rules",
	icon: "🏔️",
	iconImg: "games/cascadia.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/cascadia/en.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [2, 3],
	playerRange: (e) => ({
		min: 2,
		max: e && typeof e == "object" && (e.expansionTiles === !0 || e.landmarks === !0) ? 6 : 4
	}),
	accent: "#16a34a",
	releasedAt: "2026-09-12",
	search: {
		py: "ka si ka di ya zhi lv",
		init: "kskdyzl"
	},
	hotseat: "cover"
}, he = /* @__PURE__ */ "WPR:s.WP:sf.MRF:b.PR:sb.MPF:e.RMF:b.MM:b.MPR:bfh.PMF:e.PWR:eh.FR:es.PF:f.RW:sf.PP:sef.PP:f.RR:s.RR:sbh.MF:eb.FF:feb.MPW:bf.FM:fh.FPR:esh.WW:shf.PWR:s.MWF:bse.RF:he.MM:heb.MWP:sbf.FWR:efh.MP:bs.FP:fh.FW:bh.WF:fe.FF:e.WW:fb.WMR:h.WM:se.RM:bh.WW:h.PF:eb.RP:hs.FW:f.PM:sh.MRW:ef.MWR:h".split(".");
function ge(e) {
	let [t, n] = e.split(":"), r = t.split("");
	return {
		h: r,
		animals: n.split(""),
		...r.length === 3 ? { edges: [
			r[2],
			r[1],
			r[1],
			r[0],
			r[0],
			r[2]
		] } : {}
	};
}
var _e = he.map(ge), ve = [
	[
		"WWWWWW:s",
		"PRRMMP:sbf",
		"FRRRFF:eh"
	],
	[
		"FFFFFF:f",
		"WWPPPW:shf",
		"RRMMMR:be"
	],
	[
		"PPPPPP:e",
		"FFMMMF:heb",
		"WWRRRW:fs"
	],
	[
		"MMMMMM:h",
		"RRPPPR:fbh",
		"FFWWWF:es"
	],
	[
		"RRRRRR:b",
		"WWMMMW:fbh",
		"FFPPPF:es"
	]
], ye = ve.flat().map((e) => {
	let [t, n] = e.split(":"), r = t.split(""), i = [...new Set(r)];
	return i.length === 1 && i.push(i[0]), {
		h: i,
		edges: r,
		animals: n.split("")
	};
}), be = ve.map((e, t) => [
	{
		tile: 145 + t * 3,
		q: 0,
		r: 0,
		rot: 0
	},
	{
		tile: 146 + t * 3,
		q: -1,
		r: 1,
		rot: 0
	},
	{
		tile: 147 + t * 3,
		q: 0,
		r: 1,
		rot: 0
	}
]), G = [
	"M",
	"F",
	"P",
	"W",
	"R"
], K = [
	"b",
	"e",
	"s",
	"h",
	"f"
], q = {
	b: "#92400e",
	e: "#d9a45b",
	s: "#f87171",
	h: "#3b82f6",
	f: "#fb923c"
}, xe = /* @__PURE__ */ "FFb.FFb.FFe.FFf.FFf.FPbe.FPbf.FPef.FPes.FPfs.FPsef.FRbs.FReb.FReh.FRfb.FRfs.FRhef.FWbf.FWbs.FWeh.FWes.FWfh.FWseh.MFbf.MFef.MFfeb.MFhb.MFhe.MFheb.MMb.MMe.MMe.MMh.MMh.MPbs.MPes.MPfeb.MPhe.MPhf.MPsbf.MWbs.MWef.MWeh.MWfbh.MWhs.MWseb.PPe.PPe.PPf.PPs.PPs.PReh.PRes.PRfb.PRfbh.PRfh.PRsbf.PWef.PWes.PWfh.PWsef.PWsh.PWshf.RMbe.RMhb.RMhe.RMsb.RMsbh.RMsh.RRb.RRb.RRh.RRh.RRs.WRfh.WRfs.WRhb.WRsb.WRsbh.WRsh.WWf.WWf.WWh.WWs.WWs".split("."), Se = [
	[
		"MMb",
		"FWhef",
		"RPsb"
	],
	[
		"RRs",
		"PFseb",
		"MWfh"
	],
	[
		"PPf",
		"WRshf",
		"FMbe"
	],
	[
		"FFe",
		"MRheb",
		"WPfs"
	],
	[
		"WWh",
		"RFseh",
		"PMbf"
	]
];
function Ce(e) {
	return {
		h: [e[0], e[1]],
		animals: e.slice(2).split("")
	};
}
var we = xe.map(Ce), Te = Se.flat().map(Ce), J = [
	...we,
	...Te,
	..._e,
	...ye
], Ee = Se.map((e, t) => {
	let n = 85 + t * 3;
	return [
		{
			tile: n,
			q: 0,
			r: 1,
			rot: 0
		},
		{
			tile: n + 1,
			q: 0,
			r: 0,
			rot: 1
		},
		{
			tile: n + 2,
			q: 1,
			r: 0,
			rot: 2
		}
	];
});
function Y(e) {
	return e.animals.length === 1;
}
function De(e) {
	return new Set(e.h).size === 1;
}
var Oe = K.flatMap((e) => Array(20).fill(e)), ke = [
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"P1",
	"P2",
	"P3"
], Ae = ke.slice(0, 12), je = {
	M: "games.cascadia.habitatM",
	F: "games.cascadia.habitatF",
	P: "games.cascadia.habitatP",
	W: "games.cascadia.habitatW",
	R: "games.cascadia.habitatR"
}, Me = {
	M: "🏔️",
	F: "🌲",
	P: "🌾",
	W: "🌿",
	R: "🌊"
}, Ne = {
	A: "games.cascadia.landmarkWildlife",
	B: "games.cascadia.landmarkWildlife",
	C: "games.cascadia.landmarkWildlife",
	D: "games.cascadia.landmarkWildlife",
	E: "games.cascadia.landmarkE",
	F: "games.cascadia.landmarkF",
	G: "games.cascadia.landmarkG",
	H: "games.cascadia.landmarkH",
	I: "games.cascadia.landmarkI",
	J: "games.cascadia.landmarkJ",
	K: "games.cascadia.landmarkK",
	L: "games.cascadia.landmarkL",
	P1: "games.cascadia.landmarkP1",
	P2: "games.cascadia.landmarkP2",
	P3: "games.cascadia.landmarkP3"
}, Pe = {
	F: [
		["b"],
		["e"],
		["f"],
		["h", "s"]
	],
	M: [
		["h"],
		["b"],
		["e"],
		["f", "s"]
	],
	P: [
		["e"],
		["f"],
		["s"],
		["h", "b"]
	],
	R: [
		["s"],
		["h"],
		["b"],
		["e", "f"]
	],
	W: [
		["f"],
		["s"],
		["h"],
		["b", "e"]
	]
};
function Fe(e, t) {
	return Pe[e][[
		"A",
		"B",
		"C",
		"D"
	].indexOf(t)] ?? [];
}
function Ie(e, t) {
	let n = new Set(Object.keys(e).filter((n) => J[e[n].tile].h.includes(t))), r = [];
	for (; n.size;) {
		let i = n.values().next().value;
		n.delete(i);
		let a = [i];
		for (let r = 0; r < a.length; r++) {
			let i = a[r], o = e[i];
			for (let r = 0; r < 6; r++) {
				let s = V(i, r), c = e[s];
				c && n.has(s) && U(J[o.tile], o.rot, r) === t && U(J[c.tile], c.rot, (r + 3) % 6) === t && (n.delete(s), a.push(s));
			}
		}
		r.push(a);
	}
	return r.sort((e, t) => t.length - e.length);
}
function Le(e, t) {
	let n = e[t];
	if (!n || n.animal || n.landmark) return [];
	let r = new Set(Object.values(e).flatMap((e) => e.landmark ? [e.landmark.habitat] : []));
	return G.filter((i) => !r.has(i) && J[n.tile].h.includes(i) && Ie(e, i).some((e) => e.includes(t) && e.length >= 5));
}
function Re(e) {
	let t = {
		M: 0,
		F: 0,
		P: 0,
		W: 0,
		R: 0
	}, n = {
		M: 0,
		F: 0,
		P: 0,
		W: 0,
		R: 0
	};
	for (let r of G) {
		let i = Ie(e, r), a = i[0]?.length ?? 0;
		n[r] = a;
		let o = Object.values(e).find((e) => e.landmark?.habitat === r)?.landmark?.card;
		if (!o) continue;
		let s = i.flat(), c = Fe(r, o);
		if (c.length) t[r] = s.filter((t) => e[t].animal && c.includes(e[t].animal)).length;
		else switch (o) {
			case "E":
				t[r] = Math.max(0, ...i.filter((e) => e.length === a).map((t) => new Set(t.flatMap((t) => e[t].animal ? [e[t].animal] : [])).size));
				break;
			case "F":
				t[r] = Math.floor(s.filter((t) => e[t].animal && Y(J[e[t].tile])).length / 2) * 3;
				break;
			case "G":
				t[r] = i.length;
				break;
			case "H":
				t[r] = i.filter((e) => e.length >= 2).length * 2;
				break;
			case "I":
				n[r] = a + (i[1]?.length ?? 0);
				break;
			case "J":
				n[r] = a + 2;
				break;
			case "K":
				t[r] = Math.max(0, 6 - i.length);
				break;
			case "L":
				t[r] = 3;
				break;
			case "P1":
				t[r] = 4;
				break;
			case "P2":
				t[r] = K.reduce((t, n) => t + Math.floor(s.filter((t) => e[t].animal === n).length / 2), 0);
				break;
			case "P3": t[r] = a < 5 ? 0 : Math.min(5, Math.floor(a / 2) - 1);
		}
	}
	return {
		points: t,
		corridors: n
	};
}
//#endregion
//#region src/games/cascadia/schema.ts
var ze = t.enum([
	"b",
	"e",
	"s",
	"h",
	"f"
]), Be = t.enum([
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"KS",
	"EC"
]), Ve = t.enum([
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"KS",
	"EC"
]), He = t.enum([
	"M",
	"F",
	"P",
	"W",
	"R"
]), Ue = t.enum(ke), We = t.object({
	cards: t.enum([
		"random",
		"A",
		"family",
		"intermediate"
	]).default("random"),
	expansionCards: t.boolean().default(!1),
	kickstarter: t.boolean().default(!1),
	ecosystem: t.boolean().default(!1),
	expansionTiles: t.boolean().default(!1),
	landmarks: t.boolean().default(!1),
	landmarkPromos: t.boolean().default(!1)
}).default({
	cards: "random",
	expansionCards: !1,
	kickstarter: !1,
	ecosystem: !1,
	expansionTiles: !1,
	landmarks: !1,
	landmarkPromos: !1
}), Ge = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("pick"),
		tile: t.int().min(0).max(3),
		token: t.int().min(0).max(3)
	}),
	t.object({ type: t.literal("wipe3") }),
	t.object({
		type: t.literal("wipeTokens"),
		indices: t.array(t.int().min(0).max(3)).min(1).max(4)
	}),
	t.object({
		type: t.literal("placeTile"),
		q: t.int().min(-30).max(30),
		r: t.int().min(-30).max(30),
		rot: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("placeToken"),
		q: t.int().min(-30).max(30),
		r: t.int().min(-30).max(30)
	}),
	t.object({ type: t.literal("skipToken") }),
	t.object({
		type: t.literal("chooseStarter"),
		tile: t.int().min(0).max(144)
	}),
	t.object({
		type: t.literal("placeLandmark"),
		habitat: He,
		card: Ue
	}),
	t.object({ type: t.literal("skipLandmark") })
]), Ke = t.string(), qe = t.union([
	t.object({
		b: Ve,
		e: Be,
		s: Be,
		h: Ve,
		f: Be
	}).refine((e) => e.e !== "EC" && e.s !== "EC" && e.f !== "EC"),
	t.literal("family"),
	t.literal("intermediate")
]), Je = t.object({
	tile: t.int().min(0),
	rot: t.int().min(0).max(5),
	animal: ze.optional(),
	landmark: t.object({
		habitat: He,
		card: Ue
	}).optional()
}), Ye = t.object({
	b: t.number(),
	e: t.number(),
	s: t.number(),
	h: t.number(),
	f: t.number()
}), Xe = t.object({
	M: t.number(),
	F: t.number(),
	P: t.number(),
	W: t.number(),
	R: t.number()
}), Ze = t.object({
	rid: Ke,
	animals: Ye,
	corridors: Xe,
	landmarks: Xe,
	bonus: t.number(),
	nature: t.number(),
	total: t.number()
}), Qe = t.object({
	phase: t.enum(["play", "done"]),
	cards: qe,
	landmarksEnabled: t.boolean(),
	extraTiles: t.array(t.int().min(0)),
	landmarkSupply: t.object({
		M: t.array(Ue),
		F: t.array(Ue),
		P: t.array(Ue),
		W: t.array(Ue),
		R: t.array(Ue)
	}),
	display: t.array(t.object({
		tile: t.int().min(0),
		token: ze
	})).length(4),
	tilesLeft: t.int().min(0),
	players: t.array(t.object({
		rid: Ke,
		board: t.record(t.string(), Je),
		nature: t.int().min(0)
	})),
	turn: t.object({
		playerIdx: t.int().min(0),
		stage: t.enum([
			"draft",
			"tile",
			"token",
			"starterPick",
			"starterTile",
			"landmark"
		]),
		starterTile: t.int().min(0).optional(),
		placedKey: t.string().optional(),
		wipe3Used: t.boolean(),
		picked: t.object({
			tileIdx: t.int().min(0).max(3),
			tokenIdx: t.int().min(0).max(3),
			tile: t.int().min(0),
			token: ze
		}).optional()
	}),
	final: t.array(Ze).optional()
}), $e = t.object({}), X = (e, t) => e[Math.min(Math.max(t, 0), e.length - 1)];
function et(e) {
	let t = 0;
	for (; e;) e &= e - 1, t++;
	return t;
}
function tt(e, t) {
	if (e > 16) {
		let n = Array.from({ length: e }, () => []);
		for (let [r, i] of t) if (!(i <= 0)) for (let t = 0; t < e; t++) r & 1 << t && n[t].push([r, i]);
		let r = /* @__PURE__ */ new Map([[0, 0]]), i = (t) => {
			let a = r.get(t);
			if (a !== void 0) return a;
			let o = 0, s = [], c = Infinity;
			for (let r = 0; r < e; r++) {
				if (!(t & 1 << r)) continue;
				let e = n[r].filter(([e]) => (e & t) === e);
				if (e.length < c && (o = r, s = e, c = e.length, c === 0)) break;
			}
			let l = i(t & ~(1 << o));
			for (let [e, n] of s) l = Math.max(l, i(t ^ e) + n);
			return r.set(t, l), l;
		};
		return i((1 << e) - 1);
	}
	let n = Array.from({ length: e }, () => []);
	for (let [e, r] of t) n[31 - Math.clz32(e & -e)].push([e, r]);
	let r = new Float64Array(1 << e);
	for (let e = 1; e < r.length; e++) {
		let t = e & -e, i = r[e ^ t];
		for (let [a, o] of n[31 - Math.clz32(t)]) (a & ~e) === 0 && (i = Math.max(i, r[e ^ a] + o));
		r[e] = i;
	}
	return r[r.length - 1];
}
function nt(e) {
	let t = {
		b: [],
		e: [],
		s: [],
		h: [],
		f: []
	};
	for (let [n, r] of Object.entries(e)) r.animal && t[r.animal].push(n);
	return t;
}
function rt(e, t) {
	let n = W(e).map((e) => e.length);
	switch (t) {
		case "A": return X([
			0,
			4,
			11,
			19,
			27
		], n.filter((e) => e === 2).length);
		case "B": return n.filter((e) => e === 3).length * 10;
		case "C": {
			let e = n.reduce((e, t) => e + (t === 1 ? 2 : t === 2 ? 5 : t === 3 ? 8 : 0), 0);
			return n.includes(1) && n.includes(2) && n.includes(3) && (e += 3), e;
		}
		case "D": return n.reduce((e, t) => e + (t === 2 ? 5 : t === 3 ? 8 : t === 4 ? 13 : 0), 0);
		default: return 0;
	}
}
function it(e) {
	let t = new Set(e);
	return W(e.filter((e) => H(e).filter((e) => t.has(e)).length < 3));
}
function at(e, t, n) {
	let r = it(t);
	switch (n) {
		case "A": return r.reduce((e, t) => e + X([
			0,
			2,
			5,
			8,
			12,
			16,
			20,
			25
		], t.length), 0);
		case "B": return r.reduce((e, t) => e + X([
			0,
			2,
			4,
			9,
			11,
			17
		], t.length), 0);
		case "C": return r.reduce((e, t) => e + (t.length === 3 ? 10 : t.length === 4 ? 12 : t.length >= 5 ? 15 : 0), 0);
		case "D": {
			let t = 0;
			for (let n of r) {
				if (n.length < 3) continue;
				let r = new Set(n), i = /* @__PURE__ */ new Set();
				for (let t of n) for (let n of H(t)) !r.has(n) && e[n]?.animal && i.add(n);
				t += n.length + i.size;
			}
			return t;
		}
		default: return 0;
	}
}
function ot(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let [r, i] of e) for (let a = 0; a < 6; a++) {
		let o = 1 << i;
		n.set(o, t[1]);
		let s = r;
		for (let r = 2; r <= 4; r++) {
			s = V(s, a);
			let i = e.get(s);
			if (i === void 0) break;
			o |= 1 << i, n.set(o, t[r]);
		}
	}
	return n;
}
function st(e, t) {
	switch (t) {
		case "A": {
			let t = 0;
			for (let n of W(e)) {
				let e = new Map(n.map((e, t) => [e, t]));
				t += tt(n.length, ot(e, [
					0,
					2,
					5,
					9,
					13
				]));
			}
			return t;
		}
		case "B": {
			let t = 0;
			for (let n of W(e)) {
				let e = new Map(n.map((e, t) => [e, t])), r = ot(e, [
					0,
					2,
					5,
					0,
					0
				]);
				for (let [t, n] of e) {
					for (let i = 0; i < 6; i++) {
						let a = e.get(V(t, i)), o = e.get(V(t, (i + 1) % 6));
						a !== void 0 && o !== void 0 && r.set(1 << n | 1 << a | 1 << o, 9);
					}
					for (let i = 0; i < 6; i++) for (let a = 0; a < 6; a++) {
						if (a === i || a === (i + 3) % 6) continue;
						let o = e.get(V(t, i)), s = e.get(V(t, a)), c = e.get(V(V(t, i), a));
						o !== void 0 && s !== void 0 && c !== void 0 && r.set(1 << n | 1 << o | 1 << s | 1 << c, 13);
					}
				}
				t += tt(n.length, r);
			}
			return t;
		}
		case "C": return W(e).reduce((e, t) => e + X([
			0,
			2,
			4,
			7,
			10,
			14,
			18,
			23,
			28
		], t.length), 0);
		case "D": {
			let t = new Map(e.map((e, t) => [e, t])), n = /* @__PURE__ */ new Set();
			for (let t of e) for (let e of H(t)) n.add(e);
			let r = /* @__PURE__ */ new Map();
			for (let e of n) {
				let n = 0;
				for (let r = 0; r < 6; r++) {
					let i = t.get(V(e, r));
					i !== void 0 && (n |= 1 << i);
				}
				n && r.set(n, X([
					0,
					2,
					5,
					8,
					12,
					16,
					21
				], et(n)));
			}
			return tt(e.length, r);
		}
		default: return 0;
	}
}
function ct(e, t, n) {
	let r = new Set(t), i = t.filter((e) => !H(e).some((e) => r.has(e))), a = (e, t) => pe(e, t, (e) => r.has(e));
	switch (n) {
		case "A": return X([
			0,
			2,
			5,
			8,
			11,
			14,
			18,
			22,
			26
		], i.length);
		case "B": {
			let e = i.filter((e) => t.some((t) => t !== e && a(e, t))).length;
			return e < 2 ? 0 : X([
				0,
				0,
				5,
				9,
				12,
				16,
				20,
				24,
				28
			], e);
		}
		case "C": {
			let e = 0;
			for (let n = 0; n < t.length; n++) for (let r = n + 1; r < t.length; r++) a(t[n], t[r]) && e++;
			return e * 3;
		}
		case "D": {
			let n = /* @__PURE__ */ new Map();
			for (let r = 0; r < t.length; r++) for (let i = r + 1; i < t.length; i++) {
				if (!a(t[r], t[i])) continue;
				let o = /* @__PURE__ */ new Set(), [s, c] = B(t[r]), [l, u] = B(t[i]), d = Math.max(Math.abs(l - s), Math.abs(u - c), Math.abs(l - s + u - c)), f = (l - s) / d, p = (u - c) / d;
				for (let t = 1; t < d; t++) {
					let n = e[`${s + f * t},${c + p * t}`]?.animal;
					n && n !== "h" && o.add(n);
				}
				let m = X([
					0,
					4,
					7,
					9
				], o.size);
				n.set(1 << r | 1 << i, m);
			}
			return tt(t.length, n);
		}
		default: return 0;
	}
}
function lt(e, t, n) {
	switch (n) {
		case "A": {
			let n = 0;
			for (let r of t) {
				let t = /* @__PURE__ */ new Set();
				for (let n of H(r)) {
					let r = e[n]?.animal;
					r && t.add(r);
				}
				n += Math.min(t.size, 5);
			}
			return n;
		}
		case "B": {
			let n = 0;
			for (let r of t) {
				let t = /* @__PURE__ */ new Map();
				for (let n of H(r)) {
					let r = e[n]?.animal;
					r && r !== "f" && t.set(r, (t.get(r) ?? 0) + 1);
				}
				let i = [...t.values()].filter((e) => e >= 2).length;
				n += X([
					0,
					3,
					5,
					7
				], i);
			}
			return n;
		}
		case "C": {
			let n = 0;
			for (let r of t) {
				let t = /* @__PURE__ */ new Map();
				for (let n of H(r)) {
					let r = e[n]?.animal;
					r && r !== "f" && t.set(r, (t.get(r) ?? 0) + 1);
				}
				n += Math.min(Math.max(0, ...t.values()), 6);
			}
			return n;
		}
		case "D": {
			let n = new Set(t), r = /* @__PURE__ */ new Map();
			for (let i = 0; i < t.length; i++) for (let a = 0; a < 6; a++) {
				let o = V(t[i], a), s = t.indexOf(o);
				if (s <= i) continue;
				let c = /* @__PURE__ */ new Map();
				for (let r of [t[i], o]) for (let t of H(r)) {
					if (n.has(t)) continue;
					let r = e[t]?.animal;
					r && r !== "f" && c.set(r, (c.get(r) ?? 0) + 1);
				}
				let l = [...c.values()].filter((e) => e >= 2).length;
				r.set(1 << i | 1 << s, X([
					0,
					5,
					7,
					9,
					11
				], l));
			}
			return tt(t.length, r);
		}
		default: return 0;
	}
}
function ut(e, t) {
	return W(e).reduce((e, n) => {
		let r = n.length;
		return t === "family" ? e + (r === 1 ? 2 : r === 2 ? 5 : 9) : e + (r === 2 ? 5 : r === 3 ? 8 : r >= 4 ? 12 : 0);
	}, 0);
}
var dt = [
	0,
	3,
	6,
	9,
	13,
	17,
	22,
	27
], ft = [
	0,
	5,
	12,
	20,
	29
];
function pt(e, t) {
	let n = new Set(t);
	return [...new Set(t.flatMap(H))].filter((t) => !n.has(t) && e[t]?.animal);
}
function mt(e, t) {
	let [n, r] = B(e), [i, a] = B(t), o = Math.max(Math.abs(n - i), Math.abs(r - a), Math.abs(n + r - i - a));
	return Array.from({ length: o - 1 }, (e, t) => `${n + (i - n) * (t + 1) / o},${r + (a - r) * (t + 1) / o}`);
}
function ht(e, t) {
	let n = new Map(e.map((e, t) => [e, t])), r = /* @__PURE__ */ new Map(), i = (e, t) => {
		e.every((e) => n.has(e)) && r.set(e.reduce((e, t) => e | 1 << n.get(t), 0), t);
	};
	for (let n of e) {
		i([n], t[1]);
		for (let e = 0; e < 6; e++) {
			let r = V(n, e), a = V(n, (e + 1) % 6);
			i([n, r], t[2]), i([
				n,
				r,
				a
			], t[3]), i([
				n,
				r,
				a,
				V(r, (e + 1) % 6)
			], t[4]);
		}
	}
	return r;
}
function gt(e) {
	let t = new Map(e.map((e, t) => [e, t])), n = /* @__PURE__ */ new Map(), r = (i, a) => {
		let o = `${i}:${a.join(",")}`, s = n.get(o);
		if (s !== void 0) return s;
		if (!i) return a.reduce((e, t) => e + X(ft, t), 0);
		let c = 31 - Math.clz32(i & -i), l = i & ~(1 << c), u = r(l, a);
		for (let n = 0; n < 6; n++) {
			let i = t.get(V(e[c], n));
			if (i === void 0 || !(l & 1 << i)) continue;
			let o = [...a];
			o[n % 3] = Math.min(4, o[n % 3] + 1), u = Math.max(u, r(l & ~(1 << i), o));
		}
		return n.set(o, u), u;
	};
	return r((1 << e.length) - 1, [
		0,
		0,
		0
	]);
}
function _t(e, t, n, r) {
	let i = W(t), a = (t, n) => J[e[t].tile].h.includes(n);
	if (n === "b") {
		let t = i.filter((e) => e.length === 1).flat();
		return r === "E" ? t.filter((t) => H(t).some((t) => !e[t])).length * 3 : r === "F" ? i.filter((t) => t.length >= 3 && new Set(pt(e, t).map((t) => e[t].animal)).size === 4).length * 12 : r === "G" ? X(ft, i.filter((e) => e.length === 2 && e.some((e) => a(e, "F"))).length) : r === "EC" ? X(dt, t.filter((t) => H(t).some((t) => e[t]?.animal === "s")).length) : Math.max(...[
			1,
			2,
			3,
			4
		].map((e) => i.filter((t) => t.length === e).length * [
			0,
			2,
			5,
			9,
			13
		][e]), 0);
	}
	if (n === "e") {
		if (r === "KS") return gt(t);
		if (r === "E") {
			let e = i.filter((e) => e.length === 3 && e.some((t) => {
				let n = e.filter((e) => e !== t);
				return Array.from({ length: 6 }, (e, t) => t).some((e) => n.includes(V(t, e)) && n.includes(V(t, (e + 2) % 6)));
			})).length;
			return X([
				0,
				10,
				21,
				33
			], e);
		}
		let n = ht(t, r === "G" ? [
			0,
			3,
			6,
			10,
			14
		] : [
			0,
			0,
			0,
			13,
			0
		]);
		for (let [i, o] of [...n]) {
			let s = t.filter((e, t) => i & 1 << t);
			r === "G" ? s.some((e) => a(e, "P")) || n.delete(i) : s.length === 3 ? n.set(i, o - pt(e, s).length) : n.delete(i);
		}
		return tt(t.length, n);
	}
	if (n === "s") return it(t).reduce((t, n) => {
		if (r === "E") {
			if (n.length === 1) return t + 2;
			let e = new Set(n), r = n.find((t) => H(t).filter((t) => e.has(t)).length === 1);
			if (!r) return t;
			let i = [], a = /* @__PURE__ */ new Set([r]), o = r;
			for (; a.size < n.length;) {
				let n = Array.from({ length: 6 }, (e, t) => t).find((t) => e.has(V(o, t)) && !a.has(V(o, t)));
				if (n === void 0) return t;
				i.push(n), o = V(o, n), a.add(o);
			}
			let s = ((i[1] ?? i[0] + 1) - i[0] + 6) % 6, c = (s === 1 || s === 5) && i.every((e, t) => e === i[t % 2]);
			return t + (c ? X([
				0,
				2,
				5,
				9,
				13,
				17,
				21
			], n.length) : 0);
		}
		if (r === "F") {
			let r = pt(e, n).filter((t) => e[t].animal === "b").length;
			return t + X([
				0,
				1,
				3,
				7,
				10,
				13,
				17,
				22
			], n.length) + r;
		}
		if (r === "G") return t + X([
			0,
			2,
			4,
			7,
			10,
			14
		], n.length) + n.filter((e) => a(e, "R")).length;
		if (n.length < 3) return t;
		let i = pt(e, n);
		for (let n of K.filter((e) => e !== "s")) for (let r of W(Object.keys(e).filter((t) => e[t].animal === n))) {
			let e = r.filter((e) => i.includes(e)).length;
			t += X([
				0,
				1,
				3,
				5
			], e);
		}
		return t;
	}, 0);
	if (n === "h") {
		let n = new Set(t), i = (e, t) => pe(e, t, (e) => n.has(e));
		if (r === "E") {
			let e = t.map((e) => t.filter((t) => t !== e && i(e, t)).length), n = 0;
			for (let r = 0; r < t.length; r++) for (let a = r + 1; a < t.length; a++) e[r] === 1 && e[a] === 1 && !H(t[r]).includes(t[a]) && i(t[r], t[a]) && n++;
			return n * 7;
		}
		if (r === "F" || r === "EC") {
			let n = (t, n) => Object.keys(e).some((r) => e[r].animal !== n || H(t).includes(r) ? !1 : pe(t, r, (t) => e[t]?.animal === "h" || e[t]?.animal === n)), i = t.filter((e) => n(e, "f") && (r !== "EC" || n(e, "e"))).length;
			return X(r === "EC" ? dt : [
				0,
				2,
				5,
				8,
				10,
				16,
				18,
				25
			], i);
		}
		if (r === "KS") {
			let n = new Set(t.flatMap(H).filter((t) => !e[t]));
			return X([
				0,
				2,
				4,
				7,
				10,
				14,
				18,
				22,
				27
			], [
				3,
				6,
				9,
				12,
				16,
				20,
				25,
				30
			].filter((e) => n.size >= e).length);
		}
		let a = /* @__PURE__ */ new Map();
		for (let n = 0; n < t.length; n++) for (let r = n + 1; r < t.length; r++) !H(t[n]).includes(t[r]) && i(t[n], t[r]) && new Set(mt(t[n], t[r]).flatMap((t) => e[t] ? J[e[t].tile].h : [])).size >= 3 && a.set(1 << n | 1 << r, 1);
		return X([
			0,
			7,
			14,
			22,
			30
		], tt(t.length, a));
	}
	return t.reduce((t, n) => {
		let i = H(n), a = i.flatMap((t) => e[t]?.animal ? [e[t].animal] : []);
		if (r === "E") return t + (a.length === 6 ? 4 : a.length >= 4 ? 2 : 0);
		if (r === "F") return t + (new Set(a).size === 2 ? 3 : 0);
		if (r === "G") return t + new Set(i.flatMap((t, n) => e[t] ? [U(J[e[t].tile], e[t].rot, (n + 3) % 6)] : [])).size;
		let o = new Set(K.filter((e) => e !== "f").map((e) => a.filter((t) => t === e).length));
		return t + [
			1,
			2,
			3
		].reduce((e, t) => e + (o.has(t) ? [
			0,
			1,
			2,
			2
		][t] : 0), 0);
	}, 0);
}
function vt(e, t, n) {
	let r = nt(e), i = {
		b: 0,
		e: 0,
		s: 0,
		h: 0,
		f: 0
	};
	for (let n of K) if (t === "family" || t === "intermediate") i[n] = ut(r[n], t);
	else {
		let a = t[n];
		i[n] = [
			"A",
			"B",
			"C",
			"D"
		].includes(a) ? n === "b" ? rt(r[n], a) : n === "e" ? st(r[n], a) : n === "s" ? at(e, r[n], a) : n === "h" ? ct(e, r[n], a) : lt(e, r[n], a) : _t(e, r[n], n, a);
	}
	let { points: a, corridors: o } = Re(e), s = K.reduce((e, t) => e + i[t], 0), c = G.reduce((e, t) => e + o[t], 0), l = G.reduce((e, t) => e + a[t], 0);
	return {
		animals: i,
		corridors: o,
		landmarks: a,
		nature: n,
		total: s + c + l + n
	};
}
function yt(e, t) {
	let n = e.map(() => 0);
	for (let r of G) {
		let i = e.map((e) => e[r]), a = Math.max(...i);
		if (a === 0) continue;
		let o = i.flatMap((e, t) => e === a ? [t] : []);
		if (t === 2) {
			for (let e of o) n[e] += o.length === 1 ? 2 : 1;
			continue;
		}
		if (o.length === 1) {
			n[o[0]] += 3;
			let e = Math.max(...i.filter((e) => e < a)), t = i.flatMap((t, n) => t === e ? [n] : []);
			t.length === 1 && (n[t[0]] += 1);
		} else for (let e of o) n[e] += o.length === 2 ? 2 : 1;
	}
	return n;
}
function bt(t, n) {
	for (let r = t.length - 1; r > 0; --r) {
		let i = e(n.seed, n.rngCursor, r + 1);
		n.rngCursor += 1, [t[r], t[i]] = [t[i], t[r]];
	}
}
function xt(e, t) {
	let n = t.map((t) => e.display[t].token);
	for (let n of t) e.display[n].token = e.bag.pop();
	e.bag.push(...n), bt(e.bag, e);
}
function St(e) {
	let t = 0;
	for (; e.display.every((t) => t.token === e.display[0].token);) xt(e, [
		0,
		1,
		2,
		3
	]), t += 1;
	return t;
}
function Ct(e) {
	for (let t of K) if (e.display.filter((e) => e.token === t).length === 3) return t;
	return null;
}
function wt(e) {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r of Object.keys(e)) for (let i of H(r)) !e[i] && !n.has(i) && (n.add(i), t.push(i));
	return t;
}
function Tt(e, t) {
	return Object.entries(e).filter(([, e]) => !e.animal && !e.landmark && J[e.tile].animals.includes(t)).map(([e]) => e);
}
function Et(e) {
	let t = e.turn.picked;
	if (e.stack.length === 0) return e.phase = "done", [{ kind: "gameEnd" }];
	e.display[t.tileIdx].tile = e.stack.pop(), e.display[t.tokenIdx].token = e.bag.pop();
	let n = [], r = St(e);
	return r > 0 && n.push({
		kind: "wipe",
		data: {
			auto: !0,
			count: r
		}
	}), e.turn = {
		playerIdx: (e.turn.playerIdx + 1) % e.players.length,
		stage: "draft",
		wipe3Used: !1
	}, n;
}
function Dt(t, n, r) {
	t = We.parse(t);
	let i = {
		seed: r,
		rngCursor: 0,
		players: n,
		cards: "family",
		landmarksEnabled: t.landmarks,
		extraTiles: [],
		landmarkSupply: {
			M: [],
			F: [],
			P: [],
			W: [],
			R: []
		},
		stack: [],
		bag: [],
		display: [],
		boards: {},
		nature: {},
		turn: {
			playerIdx: 0,
			stage: "draft",
			wipe3Used: !1
		},
		phase: "play"
	};
	if (t.cards === "family" || t.cards === "intermediate") i.cards = t.cards;
	else {
		let n = {
			b: "A",
			e: "A",
			s: "A",
			h: "A",
			f: "A"
		};
		if (t.cards === "random") for (let a of K) {
			let o = [
				"A",
				"B",
				"C",
				"D"
			];
			t.expansionCards && o.push("E", "F", "G"), t.kickstarter && o.push("KS"), t.ecosystem && (a === "b" || a === "h") && o.push("EC"), n[a] = o[e(r, i.rngCursor, o.length)], i.rngCursor += 1;
		}
		i.cards = n;
	}
	let a = we.map((e, t) => t), o = t.expansionTiles || t.landmarks;
	if (o && a.push(..._e.map((e, t) => 100 + t)), n.length < 2 || n.length > (o ? 6 : 4)) throw Error("Cascadia player count exceeds configured tile supply");
	if (bt(a, i), i.stack = a.slice(0, 20 * n.length + 3 + (t.landmarks ? n.length : 0)), t.landmarks) {
		for (; i.stack.filter((e) => Y(J[e])).length < n.length;) bt(a, i), i.stack = a.slice(0, 20 * n.length + 3 + n.length);
		i.extraTiles = i.stack.filter((e) => Y(J[e])).slice(0, n.length);
		let e = new Set(i.extraTiles);
		i.stack = i.stack.filter((t) => !e.has(t)), bt(i.stack, i);
		for (let e of G) {
			let r = [...Ae];
			t.landmarkPromos && (e === "F" && r.push("P2", "P3"), e === "W" && r.push("P1")), bt(r, i), i.landmarkSupply[e] = r.slice(0, n.length);
		}
		i.turn = {
			playerIdx: n.length - 1,
			stage: "starterPick",
			wipe3Used: !1
		};
	}
	i.bag = o ? K.flatMap((e) => Array(27).fill(e)) : [...Oe], bt(i.bag, i);
	let s = o ? [...Ee, ...be] : Ee, c = s.map((e, t) => t);
	bt(c, i);
	for (let e = 0; e < n.length; e++) {
		let t = {};
		for (let n of s[c[e]]) t[z(n.q, n.r)] = {
			tile: n.tile,
			rot: n.rot
		};
		i.boards[n[e]] = t, i.nature[n[e]] = 0;
	}
	for (let e = 0; e < 4; e++) i.display.push({
		tile: i.stack.pop(),
		token: i.bag.pop()
	});
	return St(i), { state: i };
}
function Ot(t, n, r) {
	let i = t.players[t.turn.playerIdx];
	if (t.phase !== "play" || r.by !== i) return { code: "games.cascadia.errNotYourTurn" };
	if (n.type === "chooseStarter") {
		if (t.turn.stage !== "starterPick" || !t.extraTiles.includes(n.tile)) return { code: "games.cascadia.errBadTile" };
		let e = structuredClone(t);
		return e.turn.starterTile = n.tile, e.turn.stage = "starterTile", { state: e };
	}
	if (n.type === "placeLandmark" || n.type === "skipLandmark") {
		if (t.turn.stage !== "landmark" || !t.turn.placedKey) return { code: "games.cascadia.errNotYourTurn" };
		let e = structuredClone(t);
		if (n.type === "placeLandmark") {
			if (!Le(e.boards[r.by], e.turn.placedKey).includes(n.habitat) || !e.landmarkSupply[n.habitat].includes(n.card)) return { code: "games.cascadia.errBadLandmark" };
			e.boards[r.by][e.turn.placedKey].landmark = {
				habitat: n.habitat,
				card: n.card
			}, e.landmarkSupply[n.habitat] = e.landmarkSupply[n.habitat].filter((e) => e !== n.card);
		}
		return e.turn.stage = "token", { state: e };
	}
	if (n.type === "pick" || n.type === "wipe3" || n.type === "wipeTokens") {
		if (t.turn.stage !== "draft") return { code: "games.cascadia.errNotYourTurn" };
		let e = structuredClone(t);
		if (n.type === "wipe3") {
			if (e.turn.wipe3Used) return { code: "games.cascadia.errWipeUsed" };
			let t = Ct(e);
			if (!t) return { code: "games.cascadia.errNoThree" };
			e.turn.wipe3Used = !0;
			let n = e.display.flatMap((e, n) => e.token === t ? [n] : []);
			return xt(e, n), {
				state: e,
				fx: [{
					kind: "wipe",
					rid: r.by,
					data: { indices: n }
				}]
			};
		}
		if (n.type === "wipeTokens") {
			if (e.nature[r.by] < 1) return { code: "games.cascadia.errNoNature" };
			let t = [...new Set(n.indices)];
			return --e.nature[r.by], xt(e, t), {
				state: e,
				fx: [{
					kind: "wipe",
					rid: r.by,
					data: {
						indices: t,
						nature: !0
					}
				}]
			};
		}
		if (n.tile !== n.token && e.nature[r.by] < 1) return { code: "games.cascadia.errNoNature" };
		n.tile !== n.token && --e.nature[r.by];
		let i = {
			tileIdx: n.tile,
			tokenIdx: n.token,
			tile: e.display[n.tile].tile,
			token: e.display[n.token].token
		};
		return e.turn.picked = i, e.turn.stage = "tile", {
			state: e,
			fx: [{
				kind: "draft",
				rid: r.by,
				data: {
					...i,
					mixed: n.tile !== n.token
				}
			}]
		};
	}
	if (n.type === "placeTile") {
		let e = t.turn.stage === "starterTile" && t.turn.starterTile !== void 0;
		if (!e && (t.turn.stage !== "tile" || !t.turn.picked)) return { code: "games.cascadia.errNotYourTurn" };
		let i = t.boards[r.by], a = z(n.q, n.r);
		if (i[a] || !H(a).some((e) => i[e])) return { code: "games.cascadia.errBadTile" };
		let o = structuredClone(t);
		return o.boards[r.by][a] = {
			tile: e ? o.turn.starterTile : o.turn.picked.tile,
			rot: n.rot
		}, e ? (o.extraTiles = o.extraTiles.filter((e) => e !== o.turn.starterTile), o.turn = {
			playerIdx: o.turn.playerIdx === 0 ? 0 : o.turn.playerIdx - 1,
			stage: o.turn.playerIdx === 0 ? "draft" : "starterPick",
			wipe3Used: !1
		}) : (o.turn.placedKey = a, o.turn.stage = o.landmarksEnabled && Le(o.boards[r.by], a).length ? "landmark" : "token"), {
			state: o,
			fx: [{
				kind: "placeTile",
				rid: r.by,
				data: {
					q: n.q,
					r: n.r,
					rot: n.rot
				}
			}]
		};
	}
	if (t.turn.stage !== "token" || !t.turn.picked) return { code: "games.cascadia.errNotYourTurn" };
	let a = structuredClone(t), o = a.turn.picked.token;
	if (n.type === "placeToken") {
		let e = a.boards[r.by][z(n.q, n.r)];
		if (!e || e.animal || e.landmark || !J[e.tile].animals.includes(o)) return { code: "games.cascadia.errBadToken" };
		e.animal = o;
		let t = [{
			kind: "placeToken",
			rid: r.by,
			data: {
				q: n.q,
				r: n.r,
				animal: o
			}
		}];
		return Y(J[e.tile]) && (a.nature[r.by] += 1, t.push({
			kind: "pinecone",
			rid: r.by,
			data: { n: a.nature[r.by] }
		})), t.push(...Et(a)), {
			state: a,
			fx: t
		};
	}
	return n.type === "skipToken" ? (a.bag.splice(e(a.seed, a.rngCursor, a.bag.length + 1), 0, o), a.rngCursor += 1, {
		state: a,
		fx: [{
			kind: "skipToken",
			rid: r.by,
			data: { animal: o }
		}, ...Et(a)]
	}) : { code: "games.cascadia.errNotYourTurn" };
}
function kt(e) {
	let t = e.players.map((t) => vt(e.boards[t], e.cards, e.nature[t])), n = yt(t.map((e) => e.corridors), e.players.length);
	return e.players.map((e, r) => ({
		rid: e,
		animals: t[r].animals,
		corridors: t[r].corridors,
		landmarks: t[r].landmarks,
		bonus: n[r],
		nature: t[r].nature,
		total: t[r].total + n[r]
	}));
}
function At(e) {
	return {
		public: {
			phase: e.phase,
			cards: e.cards,
			landmarksEnabled: e.landmarksEnabled,
			extraTiles: e.extraTiles,
			landmarkSupply: e.landmarkSupply,
			display: e.display,
			tilesLeft: e.stack.length,
			players: e.players.map((t) => ({
				rid: t,
				board: e.boards[t],
				nature: e.nature[t]
			})),
			turn: e.turn,
			...e.phase === "done" ? { final: kt(e) } : {}
		},
		private: {}
	};
}
function jt(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = kt(e), n = [...e.players].sort((e, n) => {
		let r = t.find((t) => t.rid === e), i = t.find((e) => e.rid === n);
		return i.total - r.total || i.nature - r.nature;
	}), r = t.find((e) => e.rid === n[0]);
	return {
		phase: "done",
		winner: n.filter((e) => {
			let n = t.find((t) => t.rid === e);
			return n.total === r.total && n.nature === r.nature;
		}),
		ranking: n,
		scores: Object.fromEntries(t.map((e) => [e.rid, e.total]))
	};
}
var Mt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: me,
	schemas: {
		action: Ge,
		publicView: Qe,
		privateView: $e,
		config: We
	},
	setup: Dt,
	reduce: Ot,
	viewFor: At,
	status: jt
}, Nt = {
	b: /* @__PURE__ */ S(b, { children: [
		/* @__PURE__ */ x("circle", {
			cx: -7.5,
			cy: -6.3,
			r: 3.8
		}),
		/* @__PURE__ */ x("circle", {
			cx: 7.5,
			cy: -6.3,
			r: 3.8
		}),
		/* @__PURE__ */ x("ellipse", {
			cx: 0,
			cy: 2.5,
			rx: 12.5,
			ry: 11
		})
	] }),
	e: /* @__PURE__ */ S(b, { children: [
		/* @__PURE__ */ x("path", { d: "M-4.5,-4.5 C-5.3,-0.5 -4.8,3.8 -3.2,8 C-2.3,10.4 -1.2,12 0,12 C1.2,12 2.3,10.4 3.2,8 C4.8,3.8 5.3,-0.5 4.5,-4.5 C3,-5.8 1.5,-6.3 0,-6.3 C-1.5,-6.3 -3,-5.8 -4.5,-4.5 Z" }),
		/* @__PURE__ */ x("ellipse", {
			cx: -7.5,
			cy: -2.5,
			rx: 4,
			ry: 2,
			transform: "rotate(-20 -7.5 -2.5)"
		}),
		/* @__PURE__ */ x("ellipse", {
			cx: 7.5,
			cy: -2.5,
			rx: 4,
			ry: 2,
			transform: "rotate(20 7.5 -2.5)"
		}),
		/* @__PURE__ */ x("path", {
			d: "M-4,-4.5 L-7.5,-11 M-7.5,-11 L-12,-11.5 M-7.5,-11 L-9.5,-16 M4,-4.5 L7.5,-11 M7.5,-11 L12,-11.5 M7.5,-11 L9.5,-16",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: 2.6,
			strokeLinecap: "round"
		})
	] }),
	s: /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("path", { d: "M-13,0 C-9,-6.5 -2,-9 4,-6.5 L11,-10 C8.5,-6 7.5,-3 7.2,0 C7.5,3 8.5,6 11,10 L4,6.5 C-2,9 -9,6.5 -13,0 Z" }), /* @__PURE__ */ x("circle", {
		cx: -7,
		cy: -2,
		r: 1.7,
		fill: q.s
	})] }),
	h: /* @__PURE__ */ S(b, { children: [
		/* @__PURE__ */ x("path", { d: "M-0.5,-2.5 C-4,-8 -8,-12 -12.5,-14 L-14,-10.5 L-11,-11.5 L-12,-7.5 L-9,-9 L-9.5,-5 C-7,-2.5 -4,-1 -1.5,-0.5 Z" }),
		/* @__PURE__ */ x("path", { d: "M0.5,-2.5 C4,-8 8,-12 12.5,-14 L14,-10.5 L11,-11.5 L12,-7.5 L9,-9 L9.5,-5 C7,-2.5 4,-1 1.5,-0.5 Z" }),
		/* @__PURE__ */ x("circle", {
			cx: 0,
			cy: -4.6,
			r: 2.4
		}),
		/* @__PURE__ */ x("path", { d: "M-2.2,-0.5 L0,11 L2.2,-0.5 Z" })
	] }),
	f: /* @__PURE__ */ x("path", { d: "M-10,-13 L-4,-6.5 C-2.2,-7.4 -1,-7.6 0,-7.6 C1,-7.6 2.2,-7.4 4,-6.5 L10,-13 C10.4,-8.5 10,-5 8.8,-2.8 C9.8,-1 10.2,0.6 10,2.2 C9,7.5 4.5,11 0,12.5 C-4.5,11 -9,7.5 -10,2.2 C-10.2,0.6 -9.8,-1 -8.8,-2.8 C-10,-5 -10.4,-8.5 -10,-13 Z" })
};
function Pt({ animal: e, color: t = "#fff" }) {
	return /* @__PURE__ */ x("g", {
		fill: t,
		color: t,
		children: Nt[e]
	});
}
function Ft({ animal: e, r: t = 21 }) {
	return /* @__PURE__ */ S("g", {
		transform: `scale(${t / 21})`,
		children: [
			/* @__PURE__ */ x("circle", {
				r: 21,
				fill: q[e],
				className: "stroke-ink",
				strokeWidth: 2.5
			}),
			/* @__PURE__ */ x("circle", {
				r: 16.8,
				fill: "none",
				stroke: "#fff",
				strokeOpacity: .4,
				strokeWidth: 1.6
			}),
			/* @__PURE__ */ x("path", {
				d: "M-11 -13.5 A 17.5 17.5 0 0 1 11 -13.5",
				fill: "none",
				stroke: "#fff",
				strokeOpacity: .55,
				strokeWidth: 2,
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ x(Pt, { animal: e })
		]
	});
}
function It({ animal: e, withDisc: t, className: n }) {
	return /* @__PURE__ */ S("svg", {
		viewBox: "-17 -17 34 34",
		className: n,
		"aria-hidden": !0,
		children: [t && /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("circle", {
			r: 16,
			fill: q[e],
			className: "stroke-ink",
			strokeWidth: 1.6
		}), /* @__PURE__ */ x("circle", {
			r: 12.6,
			fill: "none",
			stroke: "#fff",
			strokeOpacity: .4,
			strokeWidth: 1.4
		})] }), /* @__PURE__ */ x(Pt, { animal: e })]
	});
}
//#endregion
//#region src/games/cascadia/target-outline.tsx
function Lt({ points: e, radius: t, round: n = !1 }) {
	let r = ie(), i = (r, i) => {
		let a = {
			className: r,
			fill: "none",
			vectorEffect: "non-scaling-stroke",
			children: i
		};
		return e === void 0 ? t === void 0 ? /* @__PURE__ */ x("rect", {
			...a,
			x: 1,
			y: 1,
			rx: n ? "50%" : 4,
			style: {
				width: "calc(100% - 2px)",
				height: "calc(100% - 2px)"
			}
		}) : /* @__PURE__ */ x("circle", {
			...a,
			r: t
		}) : /* @__PURE__ */ x("polygon", {
			...a,
			points: e
		});
	};
	return /* @__PURE__ */ S("g", {
		className: "cascadia-target-outline",
		"aria-hidden": "true",
		pointerEvents: "none",
		children: [i("cascadia-target-outline__base"), i("cascadia-target-outline__march", !r && /* @__PURE__ */ x("animate", {
			attributeName: "stroke-dashoffset",
			from: "0",
			to: "-20",
			dur: "1s",
			repeatCount: "indefinite"
		}))]
	});
}
function Rt({ round: e = !1 }) {
	return /* @__PURE__ */ x("svg", {
		className: "cascadia-choice-outline",
		"aria-hidden": "true",
		focusable: "false",
		children: /* @__PURE__ */ x(Lt, { round: e })
	});
}
//#endregion
//#region src/games/cascadia/board-view.tsx
var zt = {
	M: "#a8a29e",
	F: "#22c55e",
	P: "#facc15",
	W: "#9fc97b",
	R: "#14a8cf"
}, Bt = Math.sqrt(3);
function Z(e) {
	let [t, n] = B(e);
	return [Bt * (t + n / 2) * 50, 1.5 * n * 50];
}
function Vt(e) {
	let t = (90 - 60 * ((e % 6 + 6) % 6)) * Math.PI / 180;
	return [50 * Math.cos(t), 50 * Math.sin(t)];
}
var Ht = (e) => e.map((e) => Vt(e).join(",")).join(" ");
function Ut(e, t) {
	let n = t && e.w >= 540 && e.h >= 340 ? Math.max(1.3, Math.min(e.w, e.h) / 250) : 1.3;
	return {
		fit: n,
		zoom: Math.max(3, n * 2.3)
	};
}
function Wt(e, t, n = !1) {
	let r = Object.keys(e);
	if (r.length === 0 || t.w === 0) return {
		cx: 0,
		cy: 0,
		s: 1
	};
	let i = r.map(Z), a = i.map((e) => e[0]), o = i.map((e) => e[1]), s = Math.min(...a) - 80, c = Math.max(...a) + 80, l = Math.min(...o) - 65, u = Math.max(...o) + 65, d = Math.min(t.w / (c - s), t.h / (u - l), Ut(t, n).fit);
	return {
		cx: (s + c) / 2,
		cy: (l + u) / 2,
		s: d
	};
}
var Gt = {
	M: "#6f6963",
	F: "#15803d",
	P: "#c98a06",
	W: "#5e8f3e",
	R: "#0b7a99"
}, Kt = "M0 -13 L5.5 -4.5 L2.5 -4.5 L7.5 4 L3 4 L3 8.5 L-3 8.5 L-3 4 L-7.5 4 L-2.5 -4.5 L-5.5 -4.5 Z", qt = {
	M: /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("path", {
		d: "M-15 10 L-6 -8 L3 10 Z",
		stroke: "none"
	}), /* @__PURE__ */ x("path", {
		d: "M-1 10 L7 -4 L15 10 Z",
		stroke: "none"
	})] }),
	F: /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("path", {
		d: Kt,
		transform: "translate(-6 0)",
		stroke: "none"
	}), /* @__PURE__ */ x("path", {
		d: Kt,
		transform: "translate(7 3) scale(0.72)",
		stroke: "none"
	})] }),
	P: /* @__PURE__ */ S("g", {
		fill: "none",
		strokeWidth: 2.6,
		strokeLinecap: "round",
		children: [/* @__PURE__ */ x("path", { d: "M-8 9 C-9 3 -12 -1 -15 -4 M-8 9 C-8 3 -8 -2 -8 -8 M-8 9 C-7 3 -4 -1 -1 -4" }), /* @__PURE__ */ x("path", { d: "M9 9 C8 4 6 0 3 -3 M9 9 C9 4 10 0 13 -3" })]
	}),
	W: /* @__PURE__ */ S(b, { children: [
		/* @__PURE__ */ S("g", {
			fill: "none",
			strokeWidth: 2.4,
			strokeLinecap: "round",
			children: [/* @__PURE__ */ x("path", { d: "M-14 3 Q-7 -1 0 3 T14 3" }), /* @__PURE__ */ x("path", { d: "M-10 9 Q-3 5 4 9" })]
		}),
		/* @__PURE__ */ x("path", {
			d: "M9 9 L9 -5",
			fill: "none",
			strokeWidth: 2.2,
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ x("ellipse", {
			cx: 9,
			cy: -8,
			rx: 2.2,
			ry: 3.6,
			stroke: "none"
		})
	] }),
	R: /* @__PURE__ */ S("g", {
		fill: "none",
		strokeWidth: 2.6,
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ x("path", { d: "M-14 -6 Q-7 -10.5 0 -6 T14 -6" }),
			/* @__PURE__ */ x("path", { d: "M-11 1 Q-4 -3.5 3 1 T17 1" }),
			/* @__PURE__ */ x("path", { d: "M-14 8 Q-7 3.5 0 8 T14 8" })
		]
	})
};
function Jt({ h: e, half: t }) {
	let n = [
		[-34, 0],
		[-29, 15],
		[-29, -15]
	], r = [
		[34, 0],
		[29, 15],
		[29, -15]
	];
	return (t === "left" ? n : t === "right" ? r : [...n, ...r]).map(([t, n]) => /* @__PURE__ */ x("g", {
		transform: `translate(${t} ${n}) scale(0.5)`,
		fill: Gt[e],
		stroke: Gt[e],
		opacity: .4,
		pointerEvents: "none",
		children: qt[e]
	}, `${t},${n}`));
}
function Yt({ tile: e, rot: t, ghost: n }) {
	let r = J[e], i = De(r);
	return /* @__PURE__ */ S("g", {
		opacity: n ? .55 : 1,
		children: [i ? /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("polygon", {
			points: Ht([
				0,
				1,
				2,
				3,
				4,
				5
			]),
			fill: zt[r.h[0]]
		}), /* @__PURE__ */ x(Jt, {
			h: r.h[0],
			half: "both"
		})] }) : r.edges ? /* @__PURE__ */ x(b, { children: Array.from({ length: 6 }, (e, n) => /* @__PURE__ */ x("polygon", {
			points: "0,0 " + Ht([n, n + 1]),
			fill: zt[U(r, t, n)]
		}, n)) }) : /* @__PURE__ */ S(b, { children: [
			/* @__PURE__ */ x("polygon", {
				points: Ht([
					t + 3,
					t + 4,
					t + 5,
					t
				]),
				fill: zt[r.h[0]]
			}),
			/* @__PURE__ */ x("polygon", {
				points: Ht([
					t,
					t + 1,
					t + 2,
					t + 3
				]),
				fill: zt[r.h[1]]
			}),
			/* @__PURE__ */ S("g", {
				transform: `rotate(${-t * 60})`,
				children: [/* @__PURE__ */ x(Jt, {
					h: r.h[0],
					half: "left"
				}), /* @__PURE__ */ x(Jt, {
					h: r.h[1],
					half: "right"
				})]
			})
		] }), /* @__PURE__ */ x("polygon", {
			points: Ht([
				0,
				1,
				2,
				3,
				4,
				5
			]),
			fill: "none",
			className: "stroke-ink",
			strokeWidth: 3,
			strokeLinejoin: "round",
			strokeDasharray: n ? "8 6" : void 0
		})]
	});
}
var Xt = {
	1: [[0, 0]],
	2: [[-17, 0], [17, 0]],
	3: [
		[0, -20],
		[-17.3, 10],
		[17.3, 10]
	]
};
function Zt({ tile: e }) {
	let t = J[e], n = Xt[t.animals.length];
	return /* @__PURE__ */ S("g", {
		pointerEvents: "none",
		children: [t.animals.map((e, t) => {
			let [r, i] = n[t];
			return /* @__PURE__ */ S("g", {
				transform: `translate(${r}, ${i})`,
				children: [/* @__PURE__ */ x("g", {
					transform: "scale(0.8)",
					children: /* @__PURE__ */ x(Pt, {
						animal: e,
						color: q[e]
					})
				}), /* @__PURE__ */ x("circle", {
					r: 16.5,
					fill: "none",
					stroke: "#fff",
					strokeWidth: 2.5,
					strokeDasharray: "8 6",
					opacity: .85
				})]
			}, t);
		}), Y(t) && /* @__PURE__ */ x("text", {
			x: 26,
			y: -24,
			textAnchor: "middle",
			fontSize: 16,
			children: "🌲"
		})]
	});
}
function Qt({ habitat: e }) {
	return /* @__PURE__ */ S("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ x("circle", {
			r: 28,
			fill: "#fff6db",
			stroke: zt[e],
			strokeWidth: 5
		}), /* @__PURE__ */ x("text", {
			textAnchor: "middle",
			dominantBaseline: "central",
			fontSize: 33,
			children: Me[e]
		})]
	});
}
function $t({ board: e }) {
	let t = Object.keys(e);
	if (t.length === 0) return null;
	let n = t.map(Z), r = n.map((e) => e[0]), i = n.map((e) => e[1]), a = 52.5, o = Math.min(...r) - a, s = Math.max(...r) + a, c = Math.min(...i) - a, l = Math.max(...i) + a;
	return /* @__PURE__ */ x("svg", {
		viewBox: `${o} ${c} ${s - o} ${l - c}`,
		className: "h-full w-full",
		"aria-hidden": !0,
		children: t.map((t) => {
			let n = e[t], [r, i] = Z(t);
			return /* @__PURE__ */ S("g", {
				transform: `translate(${r}, ${i})`,
				children: [
					/* @__PURE__ */ x(Yt, {
						tile: n.tile,
						rot: n.rot
					}),
					n.landmark && /* @__PURE__ */ x(Qt, { habitat: n.landmark.habitat }),
					n.animal && /* @__PURE__ */ x("g", {
						pointerEvents: "none",
						children: /* @__PURE__ */ x(Ft, { animal: n.animal })
					})
				]
			}, t);
		})
	});
}
function en({ board: e, viewRid: t, tileSpots: n, tokenSpots: s, activeToken: c, ghostTile: l, ghostToken: u, onTapHex: d, rotationControl: f, adaptive: p = !1 }) {
	let m = a(null), [h, g] = o({
		w: 0,
		h: 0
	}), [_, v] = o(null), y = a({
		cx: 0,
		cy: 0,
		s: 1
	});
	r(() => {
		let e = m.current, t = new ResizeObserver(() => g({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let b = `${t}:${+(h.w > 0)}`, [C, w] = o("");
	C !== b && h.w > 0 && (w(b), v(Wt(e, h, p)));
	let T = _ ?? Wt(e, h, p);
	r(() => {
		y.current = T;
	}), r(() => {
		let e = m.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = y.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = Math.min(Math.max(r.s * i, .35), Ut({
				w: e.clientWidth,
				h: e.clientHeight
			}, p).zoom), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			y.current = u, v(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [p]);
	let E = a(/* @__PURE__ */ new Map()), D = a(0), O = a(0), k = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), E.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), E.current.size === 1 && (D.current = 0), E.current.size === 2) {
			let [e, t] = [...E.current.values()];
			O.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, ee = (e) => {
		let t = E.current.get(e.pointerId);
		if (!t) return;
		let n = m.current.getBoundingClientRect();
		if (E.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			D.current += Math.abs(n) + Math.abs(r);
			let i = y.current, a = {
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			};
			y.current = a, v(a);
		} else if (E.current.size === 2) {
			E.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...E.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (O.current > 0 && i > 0) {
				let e = y.current, a = Math.min(Math.max(e.s * i / O.current, .35), Ut(h, p).zoom), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				y.current = u, v(u);
			}
			O.current = i, D.current = 99;
			return;
		}
		E.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, te = (t) => {
		let r = E.current.size === 1 && D.current < 10;
		if (E.current.delete(t.pointerId), O.current = 0, !r || !d) return;
		let i = m.current.getBoundingClientRect(), a = y.current, o = a.cx + (t.clientX - i.left - i.width / 2) / a.s, c = a.cy + (t.clientY - i.top - i.height / 2) / a.s, l = n ? [...n] : s ? [...s] : Object.keys(e), u = null, f = 47.5;
		for (let e of l) {
			let [t, n] = Z(e), r = Math.hypot(t - o, n - c);
			r < f && (f = r, u = e);
		}
		u && d(u);
	}, A = i(() => Object.entries(e), [e]), j = l && f ? (() => {
		let [t, n] = Z(l.key), r = h.w / 2 + (t - T.cx) * T.s, i = h.h / 2 + (n - T.cy) * T.s, a = Bt / 2 * 50 * T.s, o = 50 * T.s, s = [
			{
				left: r + a + 32,
				top: i
			},
			{
				left: r - a - 32,
				top: i
			},
			{
				left: r,
				top: i + o + 32
			},
			{
				left: r,
				top: i - o - 32
			}
		], c = Object.keys(e).map((e) => {
			let [t, n] = Z(e);
			return {
				x: h.w / 2 + (t - T.cx) * T.s,
				y: h.h / 2 + (n - T.cy) * T.s
			};
		});
		return s.find((e) => e.left >= 30 && e.left <= h.w - 30 && e.top >= 30 && e.top <= h.h - 30 && c.every((t) => Math.abs(e.left - t.x) > 36 * T.s + 28 || Math.abs(e.top - t.y) > 36 * T.s + 28)) ?? {
			left: Math.max(30, Math.min(h.w - 30, r)),
			top: Math.max(30, Math.min(h.h - 30, i + o + 32))
		};
	})() : null;
	return /* @__PURE__ */ S("div", {
		ref: m,
		className: "relative h-full w-full overflow-hidden",
		children: [/* @__PURE__ */ x("svg", {
			className: "h-full w-full touch-none select-none",
			onPointerDown: k,
			onPointerMove: ee,
			onPointerUp: te,
			onPointerCancel: te,
			children: /* @__PURE__ */ S("g", {
				transform: `translate(${h.w / 2 - T.cx * T.s}, ${h.h / 2 - T.cy * T.s}) scale(${T.s})`,
				children: [
					n && [...n].map((e) => {
						if (e === l?.key) return null;
						let [t, n] = Z(e);
						return /* @__PURE__ */ S("g", {
							transform: `translate(${t}, ${n})`,
							children: [/* @__PURE__ */ x("polygon", {
								points: Ht([
									0,
									1,
									2,
									3,
									4,
									5
								]),
								fill: "var(--color-ink)",
								fillOpacity: .05
							}), /* @__PURE__ */ x(Lt, { points: Ht([
								0,
								1,
								2,
								3,
								4,
								5
							]) })]
						}, `s${e}`);
					}),
					A.map(([e, t]) => {
						let [n, r] = Z(e);
						return /* @__PURE__ */ S("g", {
							transform: `translate(${n}, ${r})`,
							children: [
								/* @__PURE__ */ x(Yt, {
									tile: t.tile,
									rot: t.rot
								}),
								t.landmark ? /* @__PURE__ */ x(Qt, { habitat: t.landmark.habitat }) : t.animal ? /* @__PURE__ */ x("g", {
									pointerEvents: "none",
									children: /* @__PURE__ */ x(Ft, { animal: t.animal })
								}) : /* @__PURE__ */ x(Zt, { tile: t.tile }),
								c && s?.has(e) && e !== u?.key && /* @__PURE__ */ x(Lt, { radius: 30 })
							]
						}, e);
					}),
					l && (() => {
						let [e, t] = Z(l.key);
						return /* @__PURE__ */ S("g", {
							transform: `translate(${e}, ${t})`,
							children: [/* @__PURE__ */ x(Yt, {
								tile: l.tile,
								rot: l.rot,
								ghost: !0
							}), /* @__PURE__ */ x("g", {
								opacity: .55,
								children: /* @__PURE__ */ x(Zt, { tile: l.tile })
							})]
						});
					})(),
					u && (() => {
						let [e, t] = Z(u.key);
						return /* @__PURE__ */ S("g", {
							transform: `translate(${e}, ${t})`,
							opacity: .7,
							pointerEvents: "none",
							children: [/* @__PURE__ */ x("circle", {
								r: 30,
								fill: "none",
								className: "stroke-ink",
								strokeOpacity: .65,
								strokeWidth: 3,
								strokeDasharray: "9 7"
							}), /* @__PURE__ */ x(Ft, { animal: u.animal })]
						});
					})()
				]
			})
		}), j && /* @__PURE__ */ x("div", {
			className: "cascadia-board-rotation",
			style: j,
			children: f
		})]
	});
}
//#endregion
//#region src/games/cascadia/board3d.tsx
var tn = Math.sqrt(3), nn = 40, rn = 2 * Math.tan(nn * Math.PI / 360), Q = new M(3.1, 10, 8.4).normalize(), an = .06, on = .073, sn = .55, cn = {
	b: "#84380d",
	e: "#96621f",
	s: "#bf353e",
	h: "#2563be",
	f: "#c35a16"
}, ln = new ee(), un = new k(new M(0, 1, 0), -.073), dn = new M(), fn = {
	M: new D({
		color: "#adb9b6",
		side: E,
		flatShading: !0
	}),
	F: new D({
		color: "#75aa7d",
		side: E,
		flatShading: !0
	}),
	P: new D({
		color: "#dec881",
		side: E,
		flatShading: !0
	}),
	W: new D({
		color: "#a6c7a8",
		side: E,
		flatShading: !0
	}),
	R: new D({
		color: "#82bed0",
		side: E,
		flatShading: !0
	})
}, $ = {
	soil: new D({
		color: "#8f806a",
		flatShading: !0
	}),
	soilBottom: new D({
		color: "#6f675c",
		flatShading: !0
	}),
	rock: new D({
		color: "#819395",
		flatShading: !0
	}),
	snow: new D({
		color: "#e8ebe4",
		flatShading: !0
	}),
	evergreen: new D({
		color: "#43775f",
		flatShading: !0
	}),
	evergreenLight: new D({
		color: "#5f9371",
		flatShading: !0
	}),
	trunk: new D({
		color: "#726c58",
		flatShading: !0
	}),
	grass: new D({
		color: "#b6bb70",
		flatShading: !0
	}),
	grassLight: new D({
		color: "#e4d796",
		flatShading: !0
	}),
	wetland: new D({
		color: "#81abb0",
		flatShading: !0
	}),
	river: new D({
		color: "#4e9eba",
		flatShading: !0
	}),
	riverLight: new D({
		color: "#b9dde0",
		flatShading: !0
	})
}, pn = /* @__PURE__ */ new Map();
function mn(e, t, n) {
	let r = `${e}:${t}:${n}`, i = pn.get(r);
	if (i) return i;
	let a = document.createElement("canvas");
	a.width = a.height = 128;
	let o = a.getContext("2d");
	o.translate(64, 64), o.scale(3, 3), o.fillStyle = t, o.strokeStyle = t, o.lineCap = "round", o.lineJoin = "round", e === "b" ? (o.beginPath(), o.arc(-8, -7, 4, 0, Math.PI * 2), o.arc(8, -7, 4, 0, Math.PI * 2), o.fill(), o.beginPath(), o.ellipse(0, 3, 13, 11, 0, 0, Math.PI * 2), o.fill()) : e === "e" ? (o.fill(new Path2D("M-5 -5 Q0 -9 5 -5 L4 6 Q2 13 0 13 Q-2 13 -4 6 Z")), o.beginPath(), o.ellipse(-8, -3, 4, 2.5, -.3, 0, Math.PI * 2), o.ellipse(8, -3, 4, 2.5, .3, 0, Math.PI * 2), o.fill(), o.lineWidth = 3, o.beginPath(), o.moveTo(-4, -5), o.lineTo(-8, -14), o.lineTo(-13, -15), o.moveTo(-8, -12), o.lineTo(-10, -18), o.moveTo(4, -5), o.lineTo(8, -14), o.lineTo(13, -15), o.moveTo(8, -12), o.lineTo(10, -18), o.stroke()) : e === "s" ? o.fill(new Path2D("M-14 0 Q-5 -10 5 -6 L13 -11 Q8 -3 8 0 Q8 3 13 11 L5 6 Q-5 10 -14 0 Z")) : e === "h" ? o.fill(new Path2D("M0 -3 Q-6 -12 -15 -16 L-14 -10 L-10 -10 L-12 -5 L-6 -2 L-2 -1 L0 12 L2 -1 L6 -2 L12 -5 L10 -10 L14 -10 L15 -16 Q6 -12 0 -3 Z")) : o.fill(new Path2D("M-12 -15 L-5 -7 Q0 -10 5 -7 L12 -15 Q12 -6 9 -3 Q13 5 5 11 L0 14 L-5 11 Q-13 5 -9 -3 Q-12 -6 -12 -15 Z"));
	let s = a;
	if (n) {
		s = document.createElement("canvas"), s.width = s.height = a.width;
		let e = s.getContext("2d");
		for (let t = 0; t < 8; t++) {
			let n = t * Math.PI / 4;
			e.drawImage(a, Math.cos(n) * 3, Math.sin(n) * 3);
		}
		e.globalCompositeOperation = "source-in", e.fillStyle = "#fff8e8", e.fillRect(0, 0, s.width, s.height), e.globalCompositeOperation = "source-over", e.drawImage(a, 0, 0);
	}
	let c = new T(s);
	return c.colorSpace = te, pn.set(r, c), c;
}
function hn(e) {
	let t = (90 - (e % 6 + 6) % 6 * 60) * Math.PI / 180;
	return [Math.cos(t), Math.sin(t)];
}
function gn(e) {
	let t = new A();
	e.forEach((e, n) => {
		let [r, i] = e === -1 ? [0, 0] : hn(e);
		n === 0 ? t.moveTo(r, -i) : t.lineTo(r, -i);
	}), t.closePath();
	let n = new j(t);
	return n.rotateX(-Math.PI / 2), n;
}
var _n = Array.from({ length: 6 }, (e, t) => gn([
	-1,
	t,
	t + 1
])), vn = gn([
	0,
	1,
	2,
	3,
	4,
	5
]), yn = new A(), bn = new O();
for (let e = 0; e < 6; e++) {
	let [t, n] = hn(e);
	e === 0 ? yn.moveTo(t, -n) : yn.lineTo(t, -n);
	let [r, i] = hn(5 - e);
	e === 0 ? bn.moveTo(r * .965, -i * .965) : bn.lineTo(r * .965, -i * .965);
}
yn.closePath(), bn.closePath(), yn.holes.push(bn);
var xn = new j(yn);
xn.rotateX(-Math.PI / 2);
var Sn = Array.from({ length: 6 }, (e, t) => [gn([
	t + 3,
	t + 4,
	t + 5,
	t
]), gn([
	t,
	t + 1,
	t + 2,
	t + 3
])]);
function Cn() {
	return /* @__PURE__ */ S("group", { children: [
		/* @__PURE__ */ x("mesh", {
			position: [
				0,
				.035,
				0
			],
			material: $.trunk,
			children: /* @__PURE__ */ x("cylinderGeometry", { args: [
				.018,
				.025,
				.07,
				5
			] })
		}),
		/* @__PURE__ */ x("mesh", {
			position: [
				0,
				.085,
				0
			],
			material: $.evergreen,
			children: /* @__PURE__ */ x("coneGeometry", { args: [
				.085,
				.12,
				5
			] })
		}),
		/* @__PURE__ */ x("mesh", {
			position: [
				0,
				.135,
				0
			],
			material: $.evergreenLight,
			children: /* @__PURE__ */ x("coneGeometry", { args: [
				.055,
				.08,
				5
			] })
		})
	] });
}
function wn({ habitat: e, side: t }) {
	let n = t === "left" ? -.74 : .74;
	return [-.28, .28].map((t, r) => /* @__PURE__ */ x("group", {
		position: [
			n,
			.075,
			t
		],
		children: e === "M" ? /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("mesh", {
			position: [
				0,
				.07,
				0
			],
			material: $.rock,
			children: /* @__PURE__ */ x("coneGeometry", { args: [
				.105,
				.14,
				5
			] })
		}), /* @__PURE__ */ x("mesh", {
			position: [
				0,
				.14,
				0
			],
			material: $.snow,
			children: /* @__PURE__ */ x("coneGeometry", { args: [
				.034,
				.045,
				5
			] })
		})] }) : e === "F" ? /* @__PURE__ */ x(Cn, {}) : e === "P" ? /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("mesh", {
			position: [
				0,
				.025,
				0
			],
			scale: [
				1,
				.45,
				1
			],
			material: r ? $.grassLight : $.grass,
			children: /* @__PURE__ */ x("sphereGeometry", { args: [
				.105,
				6,
				4
			] })
		}), /* @__PURE__ */ x("mesh", {
			position: [
				.035,
				.055,
				0
			],
			material: $.grass,
			children: /* @__PURE__ */ x("coneGeometry", { args: [
				.025,
				.09,
				4
			] })
		})] }) : e === "W" ? /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				.004,
				0
			],
			material: $.wetland,
			children: /* @__PURE__ */ x("circleGeometry", { args: [.11, 8] })
		}), /* @__PURE__ */ x("mesh", {
			position: [
				.04,
				.05,
				0
			],
			material: $.grass,
			children: /* @__PURE__ */ x("coneGeometry", { args: [
				.022,
				.1,
				4
			] })
		})] }) : /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				.004,
				0
			],
			material: $.river,
			children: /* @__PURE__ */ x("circleGeometry", { args: [.115, 8] })
		}), /* @__PURE__ */ x("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				.008,
				0
			],
			material: $.riverLight,
			children: /* @__PURE__ */ x("ringGeometry", { args: [
				.045,
				.055,
				12,
				1,
				0,
				Math.PI
			] })
		})] })
	}, t));
}
function Tn({ animal: e, color: t, size: n, x: r = 0, z: i = 0, y: a, outlined: o = !1 }) {
	let s = mn(e, t, o);
	return /* @__PURE__ */ S("mesh", {
		rotation: [
			-Math.PI / 2,
			0,
			0
		],
		position: [
			r,
			a,
			i
		],
		children: [/* @__PURE__ */ x("planeGeometry", { args: [n, n] }), /* @__PURE__ */ x("meshBasicMaterial", {
			map: s,
			transparent: !0,
			depthWrite: !1,
			side: E,
			toneMapped: !1
		})]
	});
}
function En({ tile: e, animal: t, selected: n, activeToken: r }) {
	let i = J[e].animals;
	if (t) return /* @__PURE__ */ S("group", { children: [
		/* @__PURE__ */ S("mesh", {
			position: [
				0,
				.13,
				0
			],
			children: [/* @__PURE__ */ x("cylinderGeometry", { args: [
				.35,
				.35,
				.12,
				24
			] }), /* @__PURE__ */ x("meshLambertMaterial", {
				color: "#5b574d",
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ S("mesh", {
			position: [
				0,
				.192,
				0
			],
			children: [/* @__PURE__ */ x("cylinderGeometry", { args: [
				.34,
				.34,
				.025,
				24
			] }), /* @__PURE__ */ x("meshLambertMaterial", {
				color: q[t],
				flatShading: !0
			})]
		}),
		/* @__PURE__ */ S("mesh", {
			position: [
				0,
				.207,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ x("ringGeometry", { args: [
				.285,
				.304,
				28
			] }), /* @__PURE__ */ x("meshBasicMaterial", {
				color: "#fff7e5",
				transparent: !0,
				opacity: .72,
				side: E
			})]
		}),
		/* @__PURE__ */ x(Tn, {
			animal: t,
			color: "#fffdf4",
			size: .47,
			y: .21
		})
	] });
	let a = i.length === 1 ? [[0, 0]] : i.length === 2 ? [[-.25, 0], [.25, 0]] : [
		[0, -.24],
		[-.235, .16],
		[.235, .16]
	];
	return /* @__PURE__ */ S("group", { children: [
		!n && i.map((e, t) => /* @__PURE__ */ x(Tn, {
			animal: e,
			color: cn[e],
			size: i.length === 1 ? .76 : i.length === 2 ? .52 : .46,
			x: a[t][0],
			z: a[t][1],
			y: .084,
			outlined: !0
		}, e)),
		n && r && /* @__PURE__ */ S("mesh", {
			position: [
				0,
				.14,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ x("ringGeometry", { args: [
				.5650000000000001,
				.6100000000000001,
				40
			] }), /* @__PURE__ */ x("meshBasicMaterial", {
				color: q[r],
				side: E
			})]
		}),
		n && r && /* @__PURE__ */ S("group", { children: [/* @__PURE__ */ S("mesh", {
			position: [
				0,
				.18,
				0
			],
			children: [/* @__PURE__ */ x("cylinderGeometry", { args: [
				.34,
				.34,
				.1,
				24
			] }), /* @__PURE__ */ x("meshLambertMaterial", {
				color: q[r],
				transparent: !0,
				opacity: .68,
				depthWrite: !1
			})]
		}), /* @__PURE__ */ x(Tn, {
			animal: r,
			color: "#ffffff",
			size: .43,
			y: .235
		})] })
	] });
}
function Dn({ habitat: e }) {
	return /* @__PURE__ */ S("group", {
		position: [
			0,
			.103,
			0
		],
		children: [/* @__PURE__ */ S("mesh", { children: [/* @__PURE__ */ x("cylinderGeometry", { args: [
			.3,
			.34,
			.06,
			6
		] }), /* @__PURE__ */ x("meshLambertMaterial", { color: "#f8edc9" })] }), e === "F" ? /* @__PURE__ */ x("group", {
			position: [
				0,
				.04,
				0
			],
			scale: 2.5,
			children: /* @__PURE__ */ x(Cn, {})
		}) : e === "M" ? /* @__PURE__ */ S("group", {
			position: [
				0,
				.24,
				0
			],
			children: [/* @__PURE__ */ x("mesh", {
				material: $.rock,
				children: /* @__PURE__ */ x("coneGeometry", { args: [
					.28,
					.48,
					4
				] })
			}), /* @__PURE__ */ x("mesh", {
				position: [
					0,
					.17,
					0
				],
				material: $.snow,
				children: /* @__PURE__ */ x("coneGeometry", { args: [
					.09,
					.15,
					4
				] })
			})]
		}) : e === "R" ? /* @__PURE__ */ x("group", { children: [
			0,
			1,
			2
		].map((e) => /* @__PURE__ */ x("mesh", {
			position: [
				-.18 + e * .18,
				.11,
				0
			],
			rotation: [
				Math.PI / 6,
				0,
				0
			],
			material: $.river,
			children: /* @__PURE__ */ x("boxGeometry", { args: [
				.12,
				.22,
				.43
			] })
		}, e)) }) : /* @__PURE__ */ x("group", { children: [
			0,
			1,
			2,
			3,
			4
		].map((t) => /* @__PURE__ */ x("mesh", {
			position: [
				(t % 3 - 1) * .15,
				.18,
				(t > 2 ? 1 : -1) * .08
			],
			material: e === "W" ? $.grass : $.grassLight,
			children: /* @__PURE__ */ x("coneGeometry", { args: [
				e === "W" ? .065 : .1,
				.3 + t % 2 * .12,
				4
			] })
		}, t)) })]
	});
}
function On({ tile: e, rot: t, animal: n, landmark: r, selectedToken: i, activeToken: a, ghost: o }) {
	let s = J[e], c = De(s);
	return /* @__PURE__ */ S("group", {
		position: [
			0,
			o ? .18 : 0,
			0
		],
		children: [
			/* @__PURE__ */ x("mesh", {
				material: [
					$.soil,
					$.soilBottom,
					$.soilBottom
				],
				children: /* @__PURE__ */ x("cylinderGeometry", { args: [
					1,
					1,
					.14,
					6
				] })
			}),
			c ? /* @__PURE__ */ x("mesh", {
				geometry: vn,
				material: fn[s.h[0]],
				position: [
					0,
					on,
					0
				]
			}) : s.edges ? /* @__PURE__ */ x(b, { children: _n.map((e, n) => /* @__PURE__ */ x("mesh", {
				geometry: e,
				material: fn[U(s, t, n)],
				position: [
					0,
					on,
					0
				]
			}, n)) }) : /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("mesh", {
				geometry: Sn[t][0],
				material: fn[s.h[0]],
				position: [
					0,
					on,
					0
				]
			}), /* @__PURE__ */ x("mesh", {
				geometry: Sn[t][1],
				material: fn[s.h[1]],
				position: [
					0,
					on,
					0
				]
			})] }),
			s.edges ? [
				1,
				3,
				5
			].map((e) => /* @__PURE__ */ x("group", {
				rotation: [
					0,
					(e - 1) * Math.PI / 3,
					0
				],
				children: /* @__PURE__ */ x(wn, {
					habitat: U(s, t, e),
					side: "right"
				})
			}, e)) : /* @__PURE__ */ S("group", {
				rotation: [
					0,
					t * Math.PI / 3,
					0
				],
				children: [/* @__PURE__ */ x(wn, {
					habitat: s.h[0],
					side: "left"
				}), /* @__PURE__ */ x(wn, {
					habitat: s.h[1],
					side: "right"
				})]
			}),
			r ? /* @__PURE__ */ x(Dn, { habitat: r }) : /* @__PURE__ */ x(En, {
				tile: e,
				animal: n,
				selected: i,
				activeToken: a
			}),
			o && /* @__PURE__ */ x("mesh", {
				geometry: xn,
				position: [
					0,
					.076,
					0
				],
				children: /* @__PURE__ */ x("meshBasicMaterial", {
					color: "#bd7b24",
					side: E
				})
			})
		]
	});
}
function kn(e) {
	let [t, n] = B(e);
	return [tn * (t + n / 2), 1.5 * n];
}
function An(e, t, n, r, i) {
	let a = i.h / rn, o = Math.hypot(Q.x, Q.z), s = e - r.cx, c = t - an, l = n - r.cz, u = a / r.scale - (s * Q.x + c * Q.y + l * Q.z);
	return {
		x: i.w / 2 + (s * Q.z - l * Q.x) / o * a / u,
		y: i.h / 2 - (-s * Q.y * Q.x / o + c * o - l * Q.y * Q.z / o) * a / u
	};
}
function jn(e, t, n, r) {
	let [i, a] = kn(e), o = Array.from({ length: 6 }, (e, r) => {
		let [o, s] = hn(r);
		return An(i + o, .253, a + s, t, n);
	}), s = An(i, .253, a, t, n), c = Math.min(...o.map((e) => e.x)), l = Math.max(...o.map((e) => e.x)), u = Math.min(...o.map((e) => e.y)), d = Math.max(...o.map((e) => e.y)), f = [
		{
			left: l + 32,
			top: s.y
		},
		{
			left: c - 32,
			top: s.y
		},
		{
			left: s.x,
			top: d + 32
		},
		{
			left: s.x,
			top: u - 32
		}
	], p = Object.entries(r).map(([e, r]) => {
		let [i, a] = kn(e), o = [-.55, sn].flatMap((e) => [-.55, sn].map((o) => An(i + e, r.animal ? .21 : .084, a + o, t, n)));
		return {
			left: Math.min(...o.map((e) => e.x)),
			right: Math.max(...o.map((e) => e.x)),
			top: Math.min(...o.map((e) => e.y)),
			bottom: Math.max(...o.map((e) => e.y))
		};
	});
	return f.find((e) => e.left >= 30 && e.left <= n.w - 30 && e.top >= 30 && e.top <= n.h - 30 && !(e.left > n.w - 86 && e.top > n.h - 86) && p.every((t) => e.left + 28 < t.left || e.left - 28 > t.right || e.top + 28 < t.top || e.top - 28 > t.bottom)) ?? {
		left: Math.max(30, Math.min(n.w - 30, s.x)),
		top: Math.max(30, Math.min(n.h - 86, d + 32))
	};
}
function Mn(e, t) {
	let n = t && e.w >= 540 && e.h >= 340, r = n ? Math.max(85, Math.min(e.w, e.h) / 4) : 85;
	return {
		fit: r,
		zoom: n ? Math.max(135, r * 1.6) : 135
	};
}
function Nn(e, t, n, r = !1) {
	let i = [...Object.keys(e), ...t ?? []].map(kn);
	if (!i.length || !n.w || !n.h) return {
		cx: 0,
		cz: 0,
		scale: 45
	};
	let a = i.map((e) => e[0]), o = i.map((e) => e[1]), s = Math.min(...a) - 1.27, c = Math.max(...a) + 1.27, l = Math.min(...o) - 1.3, u = Math.max(...o) + 1.3, d = (s + c) / 2, f = (l + u) / 2, p = n.h / rn, m = Math.hypot(Q.x, Q.z), h = Q.z / m, g = -Q.x / m, _ = -Q.y * Q.x / m, v = m, y = -Q.y * Q.z / m, b = (e) => {
		let t = p / e;
		for (let e of [s, c]) for (let r of [l, u]) for (let i of [0, .45]) {
			let a = e - d, o = i - an, s = r - f, c = t - (a * Q.x + o * Q.y + s * Q.z);
			if (c <= 0) return !1;
			let l = (a * h + s * g) * p / c, u = (a * _ + o * v + s * y) * p / c;
			if (Math.abs(l) > n.w / 2 - 10 || Math.abs(u) > n.h / 2 - 10) return !1;
		}
		return !0;
	}, x = 12, S = Mn(n, r).fit;
	for (let e = 0; e < 18; e++) {
		let e = (x + S) / 2;
		b(e) ? x = e : S = e;
	}
	return {
		cx: d,
		cz: f,
		scale: x
	};
}
function Pn({ view: e, cameraRef: t }) {
	let n = w((e) => e.camera), i = w((e) => e.invalidate), a = w((e) => e.size.height);
	return r(() => (t.current = n, () => {
		t.current = null;
	}), [n, t]), r(() => {
		i();
	}, [
		i,
		e,
		a
	]), C(() => {
		let n = t.current;
		if (!n) return;
		let r = a / (rn * e.scale);
		n.position.set(e.cx + Q.x * r, an + Q.y * r, e.cz + Q.z * r), n.lookAt(e.cx, an, e.cz), n.updateProjectionMatrix();
	}), null;
}
function Fn(e, t) {
	let n = tn / 3 * e - t / 3, r = 2 / 3 * t, i = Math.round(n), a = Math.round(r), o = Math.round(-n - r), s = Math.abs(i - n), c = Math.abs(o + n + r), l = Math.abs(a - r);
	return s > c && s > l ? i = -o - a : l > c && (a = -i - o), `${i},${a}`;
}
function In() {
	try {
		let e = document.createElement("canvas");
		return !!(e.getContext("webgl2") ?? e.getContext("webgl"));
	} catch {
		return !1;
	}
}
function Ln({ board: e, viewRid: t, tileSpots: n, tokenSpots: s, activeToken: c, ghostTile: l, ghostToken: u, onTapHex: d, rotationControl: f, adaptive: p = !1 }) {
	let m = a(null), g = a(null), [_, v] = o({
		w: 0,
		h: 0
	}), [b, C] = o({
		cx: 0,
		cz: 0,
		scale: 45
	}), w = a(b), [T, D] = o(""), [O, k] = o(!1), [ee, te] = o(0), A = a(/* @__PURE__ */ new Map()), j = a(0), M = a(0), ie = i(() => Object.entries(e), [e]);
	r(() => {
		let e = m.current, t = new ResizeObserver(() => v({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let N = `${t}:${_.w}:${_.h}:${ee}`;
	_.w && _.h && N !== T && (D(N), C(Nn(e, n, _, p))), r(() => {
		w.current = b;
	}, [b]), r(() => {
		let e = m.current, t = (t) => {
			if (O) return;
			t.preventDefault();
			let n = w.current, r = {
				...n,
				scale: Math.max(14, Math.min(Mn({
					w: e.clientWidth,
					h: e.clientHeight
				}, p).zoom, n.scale * (t.deltaY < 0 ? 1.13 : 1 / 1.13)))
			};
			w.current = r, C(r);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [p, O]);
	let P = (e, t) => {
		let n = m.current, r = g.current;
		if (!n || !r) return null;
		let i = n.getBoundingClientRect();
		return ln.setFromCamera(new ne((e - i.left) / i.width * 2 - 1, -((t - i.top) / i.height) * 2 + 1), r), ln.ray.intersectPlane(un, dn)?.clone() ?? null;
	}, ae = (e) => {
		if (!O && (e.currentTarget.setPointerCapture(e.pointerId), A.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), A.current.size === 1 && (j.current = 0), A.current.size === 2)) {
			let [e, t] = [...A.current.values()];
			M.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, oe = (e) => {
		let t = A.current.get(e.pointerId);
		if (!t || O) return;
		let n = e.clientX - t.x, r = e.clientY - t.y;
		if (A.current.size === 1) {
			j.current += Math.abs(n) + Math.abs(r);
			let i = P(t.x, t.y), a = P(e.clientX, e.clientY);
			if (i && a) {
				let e = w.current, t = {
					...e,
					cx: e.cx + i.x - a.x,
					cz: e.cz + i.z - a.z
				};
				w.current = t, C(t);
			}
		} else if (A.current.size === 2) {
			A.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, n] = [...A.current.values()], r = Math.hypot(t.x - n.x, t.y - n.y);
			if (M.current && r) {
				let e = w.current, t = {
					...e,
					scale: Math.max(14, Math.min(Mn(_, p).zoom, e.scale * r / M.current))
				};
				w.current = t, C(t);
			}
			M.current = r, j.current = 99;
		}
		A.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, se = (e) => {
		let t = A.current.size === 1 && j.current < 10;
		if (A.current.delete(e.pointerId), A.current.size < 2 && (M.current = 0), !t || O) return;
		let r = P(e.clientX, e.clientY);
		if (!r) return;
		let i = Fn(r.x, r.z);
		(n?.has(i) || s?.has(i)) && d?.(i);
	}, F = (e) => {
		A.current.delete(e.pointerId), M.current = 0, j.current = 99;
	}, I = l && f && _.w && _.h ? jn(l.key, b, _, e) : null, L = (e, t) => {
		let [n, r] = kn(e);
		return Array.from({ length: t === void 0 ? 6 : 48 }, (e, i) => {
			let [a, o] = t === void 0 ? hn(i) : [Math.cos(i * Math.PI / 24) * t, Math.sin(i * Math.PI / 24) * t], s = An(n + a, t === void 0 ? .075 : .14, r + o, b, _);
			return `${s.x},${s.y}`;
		}).join(" ");
	};
	return /* @__PURE__ */ S("div", {
		ref: m,
		className: "cascadia-board3d",
		onPointerDown: ae,
		onPointerMove: oe,
		onPointerUp: se,
		onPointerCancel: F,
		children: [
			/* @__PURE__ */ x(y, {
				kind: "sheen",
				base: "#e4ebdb",
				className: "absolute inset-0 size-full"
			}),
			/* @__PURE__ */ S(re, {
				camera: {
					fov: nn,
					near: .1,
					far: 120
				},
				dpr: [1, 2],
				frameloop: "demand",
				gl: {
					antialias: !0,
					alpha: !0,
					powerPreference: "low-power"
				},
				style: {
					position: "absolute",
					inset: 0
				},
				onRecoveryChange: k,
				recoveryFallback: /* @__PURE__ */ x(en, {
					board: e,
					viewRid: t,
					tileSpots: n,
					tokenSpots: s,
					activeToken: c,
					ghostTile: l,
					ghostToken: u,
					onTapHex: d,
					rotationControl: f,
					adaptive: p
				}),
				children: [
					/* @__PURE__ */ x("ambientLight", { intensity: 1.45 }),
					/* @__PURE__ */ x("directionalLight", {
						position: [
							-5,
							10,
							7
						],
						intensity: 1.55
					}),
					/* @__PURE__ */ x(Pn, {
						view: b,
						cameraRef: g
					}),
					n && [...n].map((e) => {
						if (l?.key === e) return null;
						let [t, n] = kn(e);
						return /* @__PURE__ */ x("group", {
							position: [
								t,
								on,
								n
							],
							children: /* @__PURE__ */ x("mesh", {
								geometry: vn,
								children: /* @__PURE__ */ x("meshBasicMaterial", {
									color: "#d6e9d2",
									transparent: !0,
									opacity: .3,
									side: E,
									depthWrite: !1
								})
							})
						}, `spot:${e}`);
					}),
					ie.map(([e, t]) => {
						let [n, r] = kn(e);
						return /* @__PURE__ */ x("group", {
							position: [
								n,
								0,
								r
							],
							children: /* @__PURE__ */ x(On, {
								tile: t.tile,
								rot: t.rot,
								animal: t.animal,
								landmark: t.landmark?.habitat,
								selectedToken: u?.key === e,
								activeToken: c
							})
						}, e);
					}),
					l && (() => {
						let [e, t] = kn(l.key);
						return /* @__PURE__ */ x("group", {
							position: [
								e,
								0,
								t
							],
							children: /* @__PURE__ */ x(On, {
								tile: l.tile,
								rot: l.rot,
								ghost: !0
							})
						});
					})()
				]
			}),
			!O && _.w > 0 && _.h > 0 && /* @__PURE__ */ S("svg", {
				className: "cascadia-board-targets",
				viewBox: `0 0 ${_.w} ${_.h}`,
				"aria-hidden": "true",
				focusable: "false",
				children: [n && [...n].filter((e) => e !== l?.key).map((e) => /* @__PURE__ */ x(Lt, { points: L(e) }, `tile:${e}`)), c && s && [...s].filter((e) => e !== u?.key).map((e) => /* @__PURE__ */ x(Lt, { points: L(e, .5900000000000001) }, `token:${e}`))]
			}),
			!O && I && /* @__PURE__ */ x("div", {
				className: "cascadia-board-rotation",
				style: I,
				onPointerDown: (e) => e.stopPropagation(),
				onPointerMove: (e) => e.stopPropagation(),
				onPointerUp: (e) => e.stopPropagation(),
				children: f
			}),
			/* @__PURE__ */ x("button", {
				type: "button",
				className: "cascadia-board3d__recenter",
				"aria-label": "回到版图全景",
				onPointerDown: (e) => e.stopPropagation(),
				onClick: () => te((e) => e + 1),
				children: /* @__PURE__ */ x(h, {
					size: 20,
					"aria-hidden": !0
				})
			})
		]
	});
}
//#endregion
//#region src/games/cascadia/extension-cards.ts
var Rn = {
	bE: {
		hint: "games.cascadia.extHintBearE",
		description: "games.cascadia.extRuleBearE",
		layout: "single"
	},
	bF: {
		hint: "games.cascadia.extHintBearF",
		description: "games.cascadia.extRuleBearF",
		layout: "triangle"
	},
	bG: {
		hint: "games.cascadia.extHintBearG",
		description: "games.cascadia.extRuleBearG",
		layout: "pair"
	},
	bKS: {
		hint: "games.cascadia.extHintBearKS",
		description: "games.cascadia.extRuleBearKS",
		layout: "pair"
	},
	bEC: {
		hint: "games.cascadia.extHintBearEC",
		description: "games.cascadia.extRuleBearEC",
		layout: "single"
	},
	eE: {
		hint: "games.cascadia.extHintElkE",
		description: "games.cascadia.extRuleElkE",
		layout: "halfRing"
	},
	eF: {
		hint: "games.cascadia.extHintElkF",
		description: "games.cascadia.extRuleElkF",
		layout: "triangle"
	},
	eG: {
		hint: "games.cascadia.extHintElkG",
		description: "games.cascadia.extRuleElkG",
		layout: "triangle"
	},
	eKS: {
		hint: "games.cascadia.extHintElkKS",
		description: "games.cascadia.extRuleElkKS",
		layout: "pair"
	},
	sE: {
		hint: "games.cascadia.extHintSalmonE",
		description: "games.cascadia.extRuleSalmonE",
		layout: "chain"
	},
	sF: {
		hint: "games.cascadia.extHintSalmonF",
		description: "games.cascadia.extRuleSalmonF",
		layout: "chain"
	},
	sG: {
		hint: "games.cascadia.extHintSalmonG",
		description: "games.cascadia.extRuleSalmonG",
		layout: "chain"
	},
	sKS: {
		hint: "games.cascadia.extHintSalmonKS",
		description: "games.cascadia.extRuleSalmonKS",
		layout: "chain"
	},
	hE: {
		hint: "games.cascadia.extHintHawkE",
		description: "games.cascadia.extRuleHawkE",
		layout: "sight"
	},
	hF: {
		hint: "games.cascadia.extHintHawkF",
		description: "games.cascadia.extRuleHawkF",
		layout: "sight"
	},
	hG: {
		hint: "games.cascadia.extHintHawkG",
		description: "games.cascadia.extRuleHawkG",
		layout: "sight"
	},
	hKS: {
		hint: "games.cascadia.extHintHawkKS",
		description: "games.cascadia.extRuleHawkKS",
		layout: "single"
	},
	hEC: {
		hint: "games.cascadia.extHintHawkEC",
		description: "games.cascadia.extRuleHawkEC",
		layout: "sight"
	},
	fE: {
		hint: "games.cascadia.extHintFoxE",
		description: "games.cascadia.extRuleFoxE",
		layout: "surrounded"
	},
	fF: {
		hint: "games.cascadia.extHintFoxF",
		description: "games.cascadia.extRuleFoxF",
		layout: "surrounded"
	},
	fG: {
		hint: "games.cascadia.extHintFoxG",
		description: "games.cascadia.extRuleFoxG",
		layout: "single"
	},
	fKS: {
		hint: "games.cascadia.extHintFoxKS",
		description: "games.cascadia.extRuleFoxKS",
		layout: "surrounded"
	}
}, zn = {
	bA: {
		hint: "games.cascadia.scoreHintBearA",
		metric: "games.cascadia.scoreMetricPairs",
		steps: [
			["1", 4],
			["2", 11],
			["3", 19],
			["4+", 27]
		],
		example: "1 → 4"
	},
	bB: {
		hint: "games.cascadia.scoreHintBearB",
		metric: "games.cascadia.scoreMetricGroupSize",
		steps: [["3", 10]],
		example: "3 → 10"
	},
	bC: {
		hint: "games.cascadia.scoreHintBearC",
		metric: "games.cascadia.scoreMetricGroupSize",
		steps: [
			["1", 2],
			["2", 5],
			["3", 8]
		]
	},
	bD: {
		hint: "games.cascadia.scoreHintBearD",
		metric: "games.cascadia.scoreMetricGroupSize",
		steps: [
			["2", 5],
			["3", 8],
			["4", 13]
		],
		example: "3 → 8"
	},
	eA: {
		hint: "games.cascadia.scoreHintElkA",
		metric: "games.cascadia.scoreMetricLineLength",
		steps: [
			["1", 2],
			["2", 5],
			["3", 9],
			["4", 13]
		],
		example: "4 → 13"
	},
	eB: {
		hint: "games.cascadia.scoreHintElkB",
		metric: "games.cascadia.scoreMetricShape",
		steps: [
			["1", 2],
			["2", 5],
			["3", 9],
			["4", 13]
		],
		example: "4 → 13"
	},
	eC: {
		hint: "games.cascadia.scoreHintElkC",
		metric: "games.cascadia.scoreMetricGroupSize",
		steps: [
			["1", 2],
			["2", 4],
			["3", 7],
			["4", 10],
			["5", 14],
			["6", 18],
			["7", 23],
			["8+", 28]
		],
		example: "4 → 10"
	},
	eD: {
		hint: "games.cascadia.scoreHintElkD",
		metric: "games.cascadia.scoreMetricRingSize",
		steps: [
			["1", 2],
			["2", 5],
			["3", 8],
			["4", 12],
			["5", 16],
			["6", 21]
		],
		example: "6 → 21"
	},
	sA: {
		hint: "games.cascadia.scoreHintSalmonA",
		metric: "games.cascadia.scoreMetricRunLength",
		steps: [
			["1", 2],
			["2", 5],
			["3", 8],
			["4", 12],
			["5", 16],
			["6", 20],
			["7+", 25]
		],
		example: "4 → 12"
	},
	sB: {
		hint: "games.cascadia.scoreHintSalmonB",
		metric: "games.cascadia.scoreMetricRunLength",
		steps: [
			["1", 2],
			["2", 4],
			["3", 9],
			["4", 11],
			["5+", 17]
		],
		example: "3 → 9"
	},
	sC: {
		hint: "games.cascadia.scoreHintSalmonC",
		metric: "games.cascadia.scoreMetricRunLength",
		steps: [
			["3", 10],
			["4", 12],
			["5+", 15]
		],
		example: "3 → 10"
	},
	sD: {
		hint: "games.cascadia.scoreHintSalmonD",
		metric: "games.cascadia.scoreMetricRunLength",
		formula: "games.cascadia.scoreFormulaSalmonD"
	},
	hA: {
		hint: "games.cascadia.scoreHintHawkA",
		metric: "games.cascadia.scoreMetricHawks",
		steps: [
			["1", 2],
			["2", 5],
			["3", 8],
			["4", 11],
			["5", 14],
			["6", 18],
			["7", 22],
			["8+", 26]
		],
		example: "3 → 8"
	},
	hB: {
		hint: "games.cascadia.scoreHintHawkB",
		metric: "games.cascadia.scoreMetricHawks",
		steps: [
			["2", 5],
			["3", 9],
			["4", 12],
			["5", 16],
			["6", 20],
			["7", 24],
			["8", 28]
		],
		example: "2 → 5"
	},
	hC: {
		hint: "games.cascadia.scoreHintHawkC",
		metric: "games.cascadia.scoreMetricSightPairs",
		formula: "games.cascadia.scoreFormulaHawkC"
	},
	hD: {
		hint: "games.cascadia.scoreHintHawkD",
		metric: "games.cascadia.scoreMetricBetweenKinds",
		steps: [
			["1", 4],
			["2", 7],
			["3+", 9]
		],
		example: "1 → 4"
	},
	fA: {
		hint: "games.cascadia.scoreHintFoxA",
		metric: "games.cascadia.scoreMetricNeighborKinds",
		steps: [
			["1", 1],
			["2", 2],
			["3", 3],
			["4", 4],
			["5", 5]
		],
		example: "4 → 4"
	},
	fB: {
		hint: "games.cascadia.scoreHintFoxB",
		metric: "games.cascadia.scoreMetricNeighborPairs",
		steps: [
			["1", 3],
			["2", 5],
			["3", 7]
		],
		example: "2 → 5"
	},
	fC: {
		hint: "games.cascadia.scoreHintFoxC",
		metric: "games.cascadia.scoreMetricNeighborMax",
		formula: "games.cascadia.scoreFormulaFoxC"
	},
	fD: {
		hint: "games.cascadia.scoreHintFoxD",
		metric: "games.cascadia.scoreMetricNeighborPairs",
		steps: [
			["1", 5],
			["2", 7],
			["3", 9],
			["4", 11]
		],
		example: "2 → 7"
	},
	family: {
		hint: "games.cascadia.scoreHintFamily",
		metric: "games.cascadia.scoreMetricGroupSize",
		steps: [
			["1", 2],
			["2", 5],
			["3+", 9]
		],
		example: "3+ → 9"
	},
	intermediate: {
		hint: "games.cascadia.scoreHintIntermediate",
		metric: "games.cascadia.scoreMetricGroupSize",
		steps: [
			["2", 5],
			["3", 8],
			["4+", 12]
		],
		example: "4+ → 12"
	}
};
function Bn(e, t) {
	return e === "family" || e === "intermediate" ? e : `${t}${e[t]}`;
}
function Vn(e, t) {
	let n = Bn(e, t);
	return Rn[n]?.hint ?? zn[n].hint;
}
function Hn(e, t) {
	let n = (t) => t.map(([t, n]) => ({
		x: t,
		y: n,
		animal: e
	})), r = Rn[t];
	if (r) {
		let i = [
			[60, 17],
			[75, 26],
			[75, 44],
			[60, 53],
			[45, 44],
			[45, 26]
		];
		if (t === "bE" || t === "hKS") return { marks: [...n([[60, 35]]), ...i.map(([e, t]) => ({
			x: e,
			y: t,
			muted: !0
		}))] };
		if (t === "bF") return { marks: [
			...n([
				[52, 26],
				[68, 26],
				[60, 40]
			]),
			{
				x: 36,
				y: 26,
				animal: "s"
			},
			{
				x: 44,
				y: 49,
				animal: "e"
			},
			{
				x: 76,
				y: 49,
				animal: "h"
			},
			{
				x: 84,
				y: 26,
				animal: "f"
			}
		] };
		if (t === "bG") return { marks: [{
			x: 52,
			y: 35,
			animal: e,
			habitat: "F"
		}, ...n([[68, 35]])] };
		if (t === "bKS") return { marks: n([
			[24, 35],
			[50, 35],
			[66, 35],
			[89, 27],
			[89, 44],
			[104, 35]
		]) };
		if (t === "bEC") return { marks: [...n([[52, 35]]), {
			x: 68,
			y: 35,
			animal: "s"
		}] };
		if (t === "eE") return { marks: n([
			[45, 26],
			[60, 35],
			[60, 53]
		]) };
		if (t === "eF") return { marks: [...n([
			[52, 26],
			[68, 26],
			[60, 40]
		]), {
			x: 84,
			y: 26,
			animal: "b"
		}] };
		if (t === "eG") return { marks: [{
			x: 52,
			y: 26,
			animal: e,
			habitat: "P"
		}, ...n([[68, 26], [60, 40]])] };
		if (t === "eKS") return { marks: n([
			[26, 26],
			[42, 26],
			[76, 44],
			[92, 44]
		]) };
		if (t === "sF" || t === "sKS") return { marks: [
			...n([
				[36, 26],
				[52, 26],
				[68, 26]
			]),
			{
				x: 44,
				y: 42,
				animal: "b"
			},
			...t === "sKS" ? [{
				x: 60,
				y: 42,
				animal: "b"
			}] : []
		] };
		if (t === "sG") return { marks: [{
			x: 36,
			y: 26,
			animal: e,
			habitat: "R"
		}, ...n([[52, 26], [68, 26]])] };
		if (t === "hG") return {
			marks: [
				...n([[20, 35], [100, 35]]),
				{
					x: 44,
					y: 35,
					habitat: "M"
				},
				{
					x: 60,
					y: 35,
					habitat: "F"
				},
				{
					x: 76,
					y: 35,
					habitat: "P"
				}
			],
			strokes: [[
				30,
				35,
				90,
				35
			]]
		};
		if (t === "hEC") return {
			marks: [
				...n([[45, 44]]),
				{
					x: 90,
					y: 44,
					animal: "f"
				},
				{
					x: 45,
					y: 17,
					animal: "e"
				}
			],
			strokes: [[
				57,
				44,
				78,
				44
			], [
				45,
				32,
				45,
				29
			]]
		};
		if (t === "fF") return { marks: [...n([[60, 35]]), ...i.map(([e, t], n) => ({
			x: e,
			y: t,
			animal: n < 3 ? "b" : "s"
		}))] };
		if (t === "fG") return { marks: [...n([[60, 35]]), ...i.map(([e, t], n) => ({
			x: e,
			y: t,
			habitat: [
				"M",
				"F",
				"P",
				"W",
				"R",
				"F"
			][n]
		}))] };
		if (t === "fKS") return { marks: [...n([[60, 35]]), ...i.map(([e, t], n) => ({
			x: e,
			y: t,
			animal: n === 0 ? "b" : n < 3 ? "s" : "e"
		}))] };
		let a = r.layout;
		return a === "pair" ? { marks: n([[49, 35], [70, 35]]) } : a === "triangle" ? { marks: n([
			[50, 24],
			[40, 43],
			[62, 43]
		]) } : a === "halfRing" ? {
			marks: n([
				[40, 24],
				[62, 24],
				[73, 43]
			]),
			center: !0
		} : a === "chain" ? { marks: n([
			[25, 43],
			[43, 32],
			[63, 32],
			[81, 21]
		]) } : a === "surrounded" ? { marks: [
			...n([[60, 35]]),
			{
				x: 39,
				y: 35,
				animal: "b"
			},
			{
				x: 49,
				y: 17,
				animal: "b"
			},
			{
				x: 71,
				y: 17,
				animal: "s"
			},
			{
				x: 81,
				y: 35,
				animal: "s"
			},
			{
				x: 71,
				y: 53,
				animal: "e"
			},
			{
				x: 49,
				y: 53,
				animal: "e"
			}
		] } : a === "sight" ? {
			marks: [...n([[27, 35]]), {
				x: 92,
				y: 35,
				animal: t === "hF" ? "f" : "h"
			}],
			strokes: [[
				40,
				35,
				79,
				35
			]]
		} : { marks: n([[60, 35]]) };
	}
	switch (t) {
		case "bA": return { marks: n([[52, 35], [68, 35]]) };
		case "bB": return { marks: n([
			[52, 27],
			[68, 27],
			[60, 43]
		]) };
		case "bC": return { marks: n([
			[22, 35],
			[44, 35],
			[58, 35],
			[78, 27],
			[92, 27],
			[85, 43]
		]) };
		case "bD": return { marks: n([
			[52, 27],
			[68, 27],
			[60, 43]
		]) };
		case "eA": return { marks: n([
			[36, 35],
			[52, 35],
			[68, 35],
			[84, 35]
		]) };
		case "eB": return { marks: n([
			[52, 25],
			[68, 25],
			[44, 41],
			[60, 41]
		]) };
		case "eC": return { marks: n([
			[36, 25],
			[52, 25],
			[60, 41],
			[76, 41]
		]) };
		case "eD": return {
			marks: n([
				[60, 20],
				[75, 27],
				[75, 43],
				[60, 50],
				[45, 43],
				[45, 27]
			]),
			center: !0
		};
		case "sA": return { marks: n([
			[32, 28],
			[48, 28],
			[64, 28],
			[72, 44]
		]) };
		case "sB": return { marks: n([
			[44, 28],
			[60, 28],
			[68, 44]
		]) };
		case "sC": return { marks: n([
			[44, 28],
			[60, 28],
			[68, 44]
		]) };
		case "sD": return { marks: [
			...n([
				[38, 28],
				[54, 28],
				[62, 44]
			]),
			{
				x: 78,
				y: 44,
				animal: "f"
			},
			{
				x: 82,
				y: 25,
				animal: "e"
			}
		] };
		case "hA": return { marks: n([
			[22, 35],
			[60, 35],
			[98, 35]
		]) };
		case "hB": return {
			marks: n([[24, 35], [96, 35]]),
			strokes: [[
				38,
				35,
				82,
				35
			]]
		};
		case "hC": return {
			marks: n([
				[26, 47],
				[60, 23],
				[94, 47]
			]),
			strokes: [
				[
					36,
					43,
					51,
					29
				],
				[
					69,
					29,
					84,
					43
				],
				[
					40,
					47,
					80,
					47
				]
			]
		};
		case "hD": return {
			marks: [...n([[20, 35], [100, 35]]), {
				x: 60,
				y: 35,
				animal: "b"
			}],
			strokes: [[
				34,
				35,
				46,
				35
			], [
				74,
				35,
				86,
				35
			]]
		};
		case "fA": return { marks: [
			...n([[60, 35]]),
			{
				x: 44,
				y: 35,
				animal: "b"
			},
			{
				x: 52,
				y: 21,
				animal: "e"
			},
			{
				x: 68,
				y: 21,
				animal: "s"
			},
			{
				x: 76,
				y: 35,
				animal: "h"
			}
		] };
		case "fB": return { marks: [
			...n([[60, 35]]),
			{
				x: 44,
				y: 35,
				animal: "b"
			},
			{
				x: 52,
				y: 21,
				animal: "b"
			},
			{
				x: 68,
				y: 21,
				animal: "s"
			},
			{
				x: 76,
				y: 35,
				animal: "s"
			}
		] };
		case "fC": return { marks: [
			...n([[60, 35]]),
			{
				x: 44,
				y: 35,
				animal: "s"
			},
			{
				x: 52,
				y: 21,
				animal: "s"
			},
			{
				x: 68,
				y: 21,
				animal: "s"
			}
		] };
		case "fD": return { marks: [
			...n([[52, 35], [68, 35]]),
			{
				x: 36,
				y: 35,
				animal: "b"
			},
			{
				x: 44,
				y: 21,
				animal: "b"
			},
			{
				x: 76,
				y: 21,
				animal: "s"
			},
			{
				x: 84,
				y: 35,
				animal: "s"
			}
		] };
		case "family": return { marks: n([
			[52, 27],
			[68, 27],
			[60, 43]
		]) };
		case "intermediate": return { marks: n([
			[52, 25],
			[68, 25],
			[44, 41],
			[60, 41]
		]) };
	}
	return { marks: [] };
}
function Un({ mark: e }) {
	return /* @__PURE__ */ S("g", {
		transform: `translate(${e.x} ${e.y})`,
		opacity: e.muted ? .4 : 1,
		children: [/* @__PURE__ */ x("polygon", {
			points: "-10,0 -5,-8.7 5,-8.7 10,0 5,8.7 -5,8.7",
			fill: e.habitat ? zt[e.habitat] : e.animal ? q[e.animal] : "#e5e9da",
			stroke: e.animal || e.habitat ? "#fbf6e9" : "#708e79",
			strokeWidth: "1.5",
			strokeDasharray: !e.animal && !e.habitat ? "2 2" : void 0
		}), e.animal && /* @__PURE__ */ S(b, { children: [e.habitat && /* @__PURE__ */ x("circle", {
			r: "7",
			fill: q[e.animal]
		}), /* @__PURE__ */ x("g", {
			transform: e.habitat ? "scale(.28)" : "scale(.38)",
			children: /* @__PURE__ */ x(Pt, { animal: e.animal })
		})] })]
	});
}
function Wn({ cards: e, animal: t, compact: n = !1 }) {
	let r = Hn(t, Bn(e, t));
	return /* @__PURE__ */ S("svg", {
		className: n ? "cascadia-score-diagram cascadia-score-diagram--compact" : "cascadia-score-diagram",
		viewBox: "10 10 100 50",
		"aria-hidden": "true",
		children: [
			r.strokes?.map(([e, t, n, r], i) => /* @__PURE__ */ S("g", {
				stroke: "#4e8068",
				strokeWidth: "1.8",
				strokeLinecap: "round",
				children: [/* @__PURE__ */ x("line", {
					x1: e,
					y1: t,
					x2: n,
					y2: r
				}), /* @__PURE__ */ x("circle", {
					cx: (e + n) / 2,
					cy: (t + r) / 2,
					r: "1.5",
					fill: "#4e8068",
					stroke: "none"
				})]
			}, i)),
			r.center && /* @__PURE__ */ x("polygon", {
				points: "60,26 65,29 65,41 60,44 55,41 55,29",
				fill: "#e5e9da",
				stroke: "#a6bca5",
				strokeWidth: "1"
			}),
			r.marks.map((e, t) => /* @__PURE__ */ x(Un, { mark: e }, t))
		]
	});
}
function Gn({ cards: e, animal: t, score: n, description: r }) {
	let i = l(), a = Bn(e, t), o = zn[a] ?? {
		hint: Rn[a].hint,
		metric: "games.cascadia.scoreMetricPoints"
	};
	return /* @__PURE__ */ S("div", {
		className: "cascadia-score-detail",
		"data-animal": t,
		children: [
			/* @__PURE__ */ x("p", {
				className: "cascadia-score-detail__lead",
				children: i(o.hint)
			}),
			/* @__PURE__ */ S("div", {
				className: "cascadia-score-detail__picture",
				children: [/* @__PURE__ */ x(Wn, {
					cards: e,
					animal: t
				}), o.example && /* @__PURE__ */ x("span", {
					className: "cascadia-score-detail__example",
					children: o.example
				})]
			}),
			o.steps && /* @__PURE__ */ S("div", {
				className: "cascadia-score-detail__ladder",
				children: [/* @__PURE__ */ S("div", {
					className: "cascadia-score-detail__labels",
					children: [/* @__PURE__ */ x("span", { children: i(o.metric) }), /* @__PURE__ */ x("span", { children: i("games.cascadia.scoreMetricPoints") })]
				}), /* @__PURE__ */ x("div", {
					className: "cascadia-score-detail__steps",
					children: o.steps.map(([e, t]) => /* @__PURE__ */ S("div", {
						className: "cascadia-score-detail__step",
						children: [/* @__PURE__ */ x("span", { children: e }), /* @__PURE__ */ x("strong", { children: t })]
					}, e))
				})]
			}),
			o.formula && /* @__PURE__ */ x("p", {
				className: "cascadia-score-detail__formula",
				children: i(o.formula)
			}),
			/* @__PURE__ */ x("div", {
				className: "cascadia-score-detail__note",
				children: /* @__PURE__ */ x("p", { children: r })
			}),
			/* @__PURE__ */ x("p", {
				className: "cascadia-score-detail__now",
				children: i("games.cascadia.cardScoreNow", { n })
			})
		]
	});
}
//#endregion
//#region src/games/cascadia/landmark-cards.tsx
function Kn({ habitat: e, card: t, score: n, selected: r, onClick: i }) {
	let a = l(), o = /* @__PURE__ */ S(b, { children: [
		/* @__PURE__ */ S("div", {
			className: "cascadia-landmark-card__heading",
			children: [
				/* @__PURE__ */ x("span", {
					"aria-hidden": !0,
					children: Me[e]
				}),
				/* @__PURE__ */ S("strong", { children: [
					a(je[e]),
					" ",
					t
				] }),
				/* @__PURE__ */ x("span", {
					className: "cascadia-landmark-card__animals",
					children: Fe(e, t).map((e) => /* @__PURE__ */ x(It, {
						animal: e,
						withDisc: !0,
						className: "size-6"
					}, e))
				}),
				r && /* @__PURE__ */ x("span", {
					"aria-hidden": !0,
					children: "✓"
				})
			]
		}),
		/* @__PURE__ */ x("p", { children: a(Ne[t], { habitat: a(je[e]) }) }),
		n !== void 0 && /* @__PURE__ */ x("span", {
			className: "cascadia-landmark-card__score",
			children: t === "I" || t === "J" ? a("games.cascadia.landmarkCorridorEffect") : a("games.cascadia.cardScoreNow", { n })
		})
	] }), s = { borderLeftColor: zt[e] };
	return i ? /* @__PURE__ */ x("button", {
		type: "button",
		className: "cascadia-landmark-card",
		style: s,
		"aria-pressed": r,
		"aria-label": a("games.cascadia.landmarkCardAria", {
			habitat: a(je[e]),
			card: t
		}),
		onClick: i,
		children: o
	}) : /* @__PURE__ */ x("article", {
		className: "cascadia-landmark-card",
		style: s,
		children: o
	});
}
//#endregion
//#region src/games/cascadia/player-seat.tsx
function qn({ member: e, isMe: t, active: n, picked: r, nature: i, score: a, onPick: o }) {
	let s = l(), u = c((e) => e.locale), { ref: p } = ae(`seat:${e.rid}`), m = F(e, u), h = e.online ? t ? s("lobby.you") : P(e.rid) ? s("lobby.bot") : null : s("lobby.offline"), g = [
		s("games.cascadia.playerAria", {
			name: m,
			nature: i,
			score: a
		}),
		h,
		n ? s("lobby.thinking") : null
	].filter(Boolean).join(", ");
	return /* @__PURE__ */ S("button", {
		ref: p,
		type: "button",
		className: "cascadia-player-seat",
		style: { "--cascadia-player-color": se[e.colorIndex % se.length].hex },
		"data-active": n,
		"data-online": e.online,
		"aria-pressed": r,
		"aria-current": n ? "step" : void 0,
		"aria-label": g,
		title: m,
		onClick: o,
		children: [/* @__PURE__ */ S("span", {
			className: "cascadia-player-seat__heading",
			"aria-hidden": !0,
			children: [/* @__PURE__ */ x("span", {
				className: "cascadia-player-seat__name",
				children: m
			}), (h || n) && /* @__PURE__ */ S("span", {
				className: "cascadia-player-seat__badge",
				"data-active": n,
				children: [e.online ? t ? /* @__PURE__ */ x("span", {
					className: "cascadia-player-seat__you",
					children: s("lobby.you")
				}) : P(e.rid) ? /* @__PURE__ */ x(d, {
					size: 12,
					className: "cascadia-player-seat__bot"
				}) : null : /* @__PURE__ */ x(f, {
					size: 12,
					className: "cascadia-player-seat__offline"
				}), n && /* @__PURE__ */ x("span", {
					className: "cascadia-player-seat__acting",
					children: "•••"
				})]
			})]
		}), /* @__PURE__ */ S("span", {
			className: "cascadia-player-seat__numbers",
			"aria-hidden": !0,
			children: [/* @__PURE__ */ S("span", {
				className: "cascadia-player-seat__nature",
				children: [/* @__PURE__ */ x("svg", {
					viewBox: "0 0 8 12",
					className: "cascadia-player-seat__tree",
					children: /* @__PURE__ */ x("path", {
						fill: "currentColor",
						d: "M4 0 0 6h2L0 9h3v3h2V9h3L6 6h2Z"
					})
				}), /* @__PURE__ */ x("span", {
					className: "font-mono tabular-nums",
					children: i
				})]
			}), /* @__PURE__ */ S("span", {
				className: "cascadia-player-seat__score font-mono tabular-nums",
				children: [/* @__PURE__ */ x(oe, { value: a }), /* @__PURE__ */ x("span", {
					className: "cascadia-player-seat__unit",
					children: s("games.cascadia.playerPoints")
				})]
			})]
		})]
	});
}
//#endregion
//#region src/games/cascadia/view-player.tsx
var Jn = {
	b: "games.cascadia.animalB",
	e: "games.cascadia.animalE",
	s: "games.cascadia.animalS",
	h: "games.cascadia.animalH",
	f: "games.cascadia.animalF"
}, Yn = {
	b: {
		A: "games.cascadia.cardBearA",
		B: "games.cascadia.cardBearB",
		C: "games.cascadia.cardBearC",
		D: "games.cascadia.cardBearD"
	},
	e: {
		A: "games.cascadia.cardElkA",
		B: "games.cascadia.cardElkB",
		C: "games.cascadia.cardElkC",
		D: "games.cascadia.cardElkD"
	},
	s: {
		A: "games.cascadia.cardSalmonA",
		B: "games.cascadia.cardSalmonB",
		C: "games.cascadia.cardSalmonC",
		D: "games.cascadia.cardSalmonD"
	},
	h: {
		A: "games.cascadia.cardHawkA",
		B: "games.cascadia.cardHawkB",
		C: "games.cascadia.cardHawkC",
		D: "games.cascadia.cardHawkD"
	},
	f: {
		A: "games.cascadia.cardFoxA",
		B: "games.cascadia.cardFoxB",
		C: "games.cascadia.cardFoxC",
		D: "games.cascadia.cardFoxD"
	}
}, Xn = {
	draft: "games.cascadia.stageDraft",
	tile: "games.cascadia.stageTile",
	token: "games.cascadia.stageToken",
	starterPick: "games.cascadia.stageStarterPick",
	starterTile: "games.cascadia.stageStarterTile",
	landmark: "games.cascadia.stageLandmark"
};
function Zn(e) {
	let t = e.public;
	return /* @__PURE__ */ x(Qn, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Qn({ pub: e, members: t, myRid: n, send: r }) {
	let a = l(), [c] = o(In), u = c ? Ln : en, d = e.players.find((e) => e.rid === n), [f, p] = o(n), [m, h] = o(null), [C, w] = o(null), [T, E] = o(null), [D, O] = o(null), [k, ee] = o(null), [te, A] = o(!1), [j, ne] = o(!1), [M, re] = o(!1), [ie, N] = o("claimed"), [P, ae] = o(null), oe = e.players[e.turn.playerIdx]?.rid, se = e.phase === "play" && oe === n, F = se && f === n && !!d, I = e.turn.stage, L = e.turn.picked, R = I === "starterTile" ? e.turn.starterTile : L?.tile, [ce, le] = o(""), ue = `${e.turn.playerIdx}:${I}:${f}`;
	ce !== ue && (le(ue), h(null), w(null), E(null), O(null), ae(null));
	let de = I === "landmark" && F;
	M !== de && (re(de), ne(de), de && N("available"));
	let fe = i(() => {
		let t = e.players.map((t) => vt(t.board, e.cards, t.nature)), n = yt(t.map((e) => e.corridors), e.players.length), r = {};
		return e.players.forEach((e, i) => {
			r[e.rid] = {
				total: t[i].total + n[i],
				animals: t[i].animals
			};
		}), r;
	}, [e.players, e.cards]), z = e.players.length, V = Math.floor((20 * z - 1 - e.tilesLeft) / z) + 1, H = i(() => F && (I === "tile" || I === "starterTile") && d ? new Set(wt(d.board)) : void 0, [
		F,
		I,
		d
	]), U = i(() => F && I === "token" && d && L ? new Set(Tt(d.board, L.token)) : void 0, [
		F,
		I,
		d,
		L
	]), W = (e) => t.find((t) => t.rid === e)?.name ?? e, pe = m !== null && m.tile !== m.token, me = (d?.nature ?? 0) >= 1, he = K.find((t) => e.display.filter((e) => e.token === t).length === 3) ?? null, ge = F && I === "draft" && !e.turn.wipe3Used && he !== null, _e = (e) => {
		F && I === "draft" && (w(null), h((t) => t?.tile === e && t.token === e ? null : {
			tile: e,
			token: e
		}));
	}, ve = (e) => {
		if (F && I === "draft") {
			if (C) {
				w((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]);
				return;
			}
			h((t) => t ? {
				tile: t.tile,
				token: e === t.token ? t.tile : e
			} : {
				tile: e,
				token: e
			});
		}
	}, ye = (e) => {
		(I === "tile" || I === "starterTile") && H?.has(e) ? E({
			key: e,
			rot: 0
		}) : I === "token" && U?.has(e) && O(e);
	}, be = "info", xe;
	se ? (be = "accent", xe = a(Xn[I])) : xe = a("games.cascadia.waitTurn", { name: W(oe ?? "") });
	let Se = e.players.find((e) => e.rid === f), Ce = F && I === "landmark" && d && e.turn.placedKey ? Le(d.board, e.turn.placedKey) : [], we = Object.values(Se?.board ?? {}).flatMap((e) => e.landmark ? [e.landmark] : []), Te = Se ? Re(Se.board).points : {
		M: 0,
		F: 0,
		P: 0,
		W: 0,
		R: 0
	}, Ee = (t) => e.cards === "family" || e.cards === "intermediate" ? null : e.cards[t], Y = (t) => Ee(t) ?? a(e.cards === "family" ? "games.cascadia.cardsFamilyMark" : "games.cascadia.cardsIntermediateMark");
	return /* @__PURE__ */ x(v, {
		adaptive: !0,
		scroll: !1,
		className: "cascadia-screen",
		children: /* @__PURE__ */ S("div", {
			className: "cascadia-game h-full min-h-0",
			children: [
				/* @__PURE__ */ S("header", {
					className: "cascadia-header",
					children: [/* @__PURE__ */ x("div", {
						className: "cascadia-phase",
						"data-active": se,
						children: /* @__PURE__ */ x(_, {
							tone: be,
							text: xe,
							chip: a("games.cascadia.roundShort", {
								n: V,
								total: 20
							}),
							accent: "var(--cascadia-forest)"
						})
					}), /* @__PURE__ */ x("div", {
						className: "cascadia-players",
						style: {
							"--cascadia-player-columns": z > 4 ? 3 : z,
							"--cascadia-wide-player-columns": z
						},
						children: /* @__PURE__ */ x("ul", { children: t.filter((t) => e.players.some((e) => e.rid === t.rid)).map((t) => {
							let r = e.players.find((e) => e.rid === t.rid);
							return /* @__PURE__ */ x("li", { children: /* @__PURE__ */ x(qn, {
								member: t,
								isMe: t.rid === n,
								active: e.phase === "play" && t.rid === oe,
								picked: f === t.rid,
								nature: r.nature,
								score: fe[t.rid]?.total ?? 0,
								onPick: () => p(t.rid)
							}) }, t.rid);
						}) })
					})]
				}),
				/* @__PURE__ */ x("ul", {
					className: "cascadia-score-strip",
					children: K.map((t) => /* @__PURE__ */ x("li", { children: /* @__PURE__ */ S("button", {
						type: "button",
						"aria-label": a("games.cascadia.scoreCardAria", {
							animal: a(Jn[t]),
							card: Y(t),
							n: fe[f]?.animals[t] ?? 0
						}),
						onClick: () => {
							ee(t), A(!0);
						},
						"data-animal": t,
						className: "cascadia-score-card",
						children: [
							/* @__PURE__ */ S("span", {
								className: "cascadia-score-card__top",
								children: [
									/* @__PURE__ */ x(It, {
										animal: t,
										withDisc: !0,
										className: "cascadia-score-card__icon"
									}),
									/* @__PURE__ */ x("span", {
										className: "cascadia-score-card__mark",
										children: Y(t)
									}),
									/* @__PURE__ */ x("span", {
										className: "cascadia-score-card__points font-mono tabular-nums",
										children: fe[f]?.animals[t] ?? 0
									})
								]
							}),
							/* @__PURE__ */ x(Wn, {
								cards: e.cards,
								animal: t,
								compact: !0
							}),
							/* @__PURE__ */ x("span", {
								className: "cascadia-score-card__hint",
								children: a(Vn(e.cards, t))
							})
						]
					}) }, t))
				}),
				/* @__PURE__ */ S("div", {
					className: "cascadia-scene relative min-h-0 flex-1 overflow-hidden",
					children: [
						!c && /* @__PURE__ */ x(y, {
							kind: "dots",
							base: "#edf0e2",
							line: "#e1e5cf",
							className: "absolute inset-0 size-full"
						}),
						Se && /* @__PURE__ */ x(u, {
							adaptive: !0,
							board: Se.board,
							viewRid: f,
							tileSpots: F ? H : void 0,
							tokenSpots: F ? U : void 0,
							activeToken: F && I === "token" && L ? L.token : null,
							ghostTile: F && R !== void 0 && (I === "tile" || I === "starterTile") && T ? {
								key: T.key,
								tile: R,
								rot: T.rot
							} : null,
							ghostToken: F && I === "token" && L && D ? {
								key: D,
								animal: L.token
							} : null,
							onTapHex: F ? ye : void 0,
							rotationControl: F && (I === "tile" || I === "starterTile") && T && R !== void 0 && !De(J[R]) ? /* @__PURE__ */ x("button", {
								type: "button",
								"aria-label": a("games.cascadia.rotate"),
								onClick: () => E((e) => e && {
									...e,
									rot: (e.rot + 1) % 6
								}),
								className: "cascadia-rotate-button",
								children: /* @__PURE__ */ x(g, {
									size: 23,
									"aria-hidden": !0
								})
							}) : void 0
						}),
						e.landmarksEnabled && /* @__PURE__ */ S("button", {
							type: "button",
							className: "cascadia-landmark-entry",
							onClick: () => {
								N("claimed"), ne(!0);
							},
							children: [
								a("games.cascadia.landmarks"),
								" ",
								we.length,
								"/5"
							]
						})
					]
				}),
				/* @__PURE__ */ S("div", {
					className: "cascadia-bottom flex flex-none flex-col gap-1.5",
					children: [/* @__PURE__ */ x("div", {
						className: "cascadia-supply flex flex-none items-start justify-center gap-1.5",
						style: { "--cascadia-supply-rows": I === "starterPick" ? Math.max(1, Math.ceil(e.extraTiles.length / 2)) : 2 },
						children: I === "starterPick" ? e.extraTiles.map((t) => /* @__PURE__ */ S("button", {
							type: "button",
							className: "cascadia-starter-choice",
							disabled: !F,
							"aria-label": a("games.cascadia.tileAria", { n: e.extraTiles.indexOf(t) + 1 }),
							onClick: () => r({
								type: "chooseStarter",
								tile: t
							}),
							children: [/* @__PURE__ */ S("svg", {
								viewBox: "-55 -55 110 110",
								"aria-hidden": !0,
								children: [/* @__PURE__ */ x(Yt, {
									tile: t,
									rot: 0
								}), /* @__PURE__ */ x(Zt, { tile: t })]
							}), F && /* @__PURE__ */ x(Rt, {})]
						}, t)) : e.display.map((e, t) => {
							let n = m?.tile === t || I !== "draft" && L?.tileIdx === t, r = m?.token === t || (C?.includes(t) ?? !1) || I !== "draft" && L?.tokenIdx === t;
							return /* @__PURE__ */ S("div", {
								className: "cascadia-supply__pair flex flex-col items-center gap-0.5",
								"data-selected": n || r,
								children: [
									/* @__PURE__ */ x("button", {
										type: "button",
										className: "cascadia-supply__pair-hit",
										"aria-label": a("games.cascadia.pairAria", {
											n: t + 1,
											animal: a(Jn[e.token])
										}),
										"aria-pressed": n && r,
										disabled: !F || I !== "draft" || C !== null,
										onClick: () => _e(t)
									}),
									/* @__PURE__ */ S("button", {
										type: "button",
										"aria-label": a("games.cascadia.tileAria", { n: t + 1 }),
										disabled: !F || I !== "draft",
										onClick: () => _e(t),
										"data-selected": n,
										"aria-pressed": n,
										className: "cascadia-supply__tile grid size-14 place-items-center rounded border-2 border-ink bg-surface p-0.5 shadow-[2px_2px_0_var(--color-ink)]",
										children: [/* @__PURE__ */ S("svg", {
											viewBox: "-55 -55 110 110",
											className: "h-full w-full",
											"aria-hidden": !0,
											children: [/* @__PURE__ */ x(Yt, {
												tile: e.tile,
												rot: 0
											}), /* @__PURE__ */ x(Zt, { tile: e.tile })]
										}), F && I === "draft" && C === null && /* @__PURE__ */ x(Rt, {})]
									}),
									/* @__PURE__ */ S("button", {
										type: "button",
										"aria-label": a(Jn[e.token]),
										disabled: !F || I !== "draft",
										onClick: () => ve(t),
										"data-selected": r,
										"aria-pressed": r,
										className: `cascadia-supply__token grid size-8 place-items-center rounded-full border-2 border-ink shadow-[inset_0_0_0_2px_rgb(255_255_255/0.35)] ${C?.includes(t) ? "bg-warn-soft" : ""}`,
										style: { background: C?.includes(t) ? void 0 : q[e.token] },
										children: [/* @__PURE__ */ x(It, {
											animal: e.token,
											className: "size-5"
										}), F && I === "draft" && /* @__PURE__ */ x(Rt, { round: !0 })]
									})
								]
							}, t);
						})
					}), /* @__PURE__ */ x("div", {
						className: "cascadia-controls safe-b flex flex-none items-stretch gap-1.5 pb-1",
						children: se ? I === "starterPick" ? /* @__PURE__ */ x("p", {
							className: "cascadia-waiting flex min-h-12 flex-1 items-center justify-center text-sm",
							children: a("games.cascadia.stageStarterPick")
						}) : I === "landmark" ? /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("button", {
							type: "button",
							disabled: !F,
							className: "btn-quiet min-h-12 px-3 text-xs",
							onClick: () => r({ type: "skipLandmark" }),
							children: a("games.cascadia.skipLandmark")
						}), /* @__PURE__ */ x("button", {
							type: "button",
							disabled: !F,
							className: "cascadia-control-main btn-base min-h-12 flex-1 text-sm text-white",
							onClick: () => {
								N("available"), ne(!0);
							},
							children: a("games.cascadia.landmarkConfirm")
						})] }) : I === "draft" ? C ? /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("button", {
							type: "button",
							onClick: () => w(null),
							className: "cascadia-control-secondary btn-quiet min-h-12 flex-none px-3 text-xs font-bold",
							children: a("games.cascadia.wipeCancel")
						}), /* @__PURE__ */ x("button", {
							type: "button",
							disabled: C.length === 0,
							onClick: () => {
								r({
									type: "wipeTokens",
									indices: C
								}), w(null);
							},
							className: "cascadia-control-main btn-base min-h-12 flex-1 text-sm text-white",
							children: a("games.cascadia.wipeTokensConfirm", { n: C.length })
						})] }) : /* @__PURE__ */ S(b, { children: [
							/* @__PURE__ */ x("button", {
								type: "button",
								disabled: !ge,
								onClick: () => r({ type: "wipe3" }),
								className: "cascadia-control-secondary btn-quiet min-h-12 flex-none px-2 text-[11px] font-bold",
								children: a("games.cascadia.wipe3")
							}),
							/* @__PURE__ */ x("button", {
								type: "button",
								disabled: !F || !me,
								onClick: () => {
									h(null), w([]);
								},
								className: "cascadia-control-secondary btn-quiet min-h-12 flex-none px-2 text-[11px] font-bold",
								children: a("games.cascadia.wipeTokens")
							}),
							/* @__PURE__ */ x("button", {
								type: "button",
								disabled: !F || !m || pe && !me,
								onClick: () => {
									r({
										type: "pick",
										tile: m.tile,
										token: m.token
									}), h(null);
								},
								className: "cascadia-control-main btn-base min-h-12 flex-1 text-sm text-white",
								children: a(pe ? "games.cascadia.pickMixed" : "games.cascadia.pickConfirm")
							})
						] }) : I === "tile" || I === "starterTile" ? /* @__PURE__ */ x(b, { children: /* @__PURE__ */ x("button", {
							type: "button",
							disabled: !T,
							onClick: () => {
								let [e, t] = B(T.key);
								r({
									type: "placeTile",
									q: e,
									r: t,
									rot: T.rot
								}), E(null);
							},
							className: "cascadia-control-main btn-base min-h-12 flex-1 text-sm text-white",
							children: a("games.cascadia.placeTileConfirm")
						}) }) : /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x("button", {
							type: "button",
							onClick: () => r({ type: "skipToken" }),
							className: "cascadia-control-secondary btn-quiet min-h-12 flex-none px-3 text-xs font-bold",
							children: a("games.cascadia.skipToken")
						}), /* @__PURE__ */ x("button", {
							type: "button",
							disabled: !D,
							onClick: () => {
								let [e, t] = B(D);
								r({
									type: "placeToken",
									q: e,
									r: t
								}), O(null);
							},
							className: "cascadia-control-main btn-base min-h-12 flex-1 text-sm text-white",
							children: L ? a("games.cascadia.placeTokenConfirm", { animal: a(Jn[L.token]) }) : ""
						})] }) : /* @__PURE__ */ x("p", {
							className: "cascadia-waiting flex min-h-12 flex-1 items-center justify-center text-xs font-bold",
							children: a("games.cascadia.watchHint")
						})
					})]
				}),
				/* @__PURE__ */ x(s, {
					open: te,
					onClose: () => A(!1),
					label: a(k ? Jn[k] : "games.cascadia.optCards"),
					title: k && /* @__PURE__ */ S("span", {
						className: "cascadia-score-title",
						children: [
							/* @__PURE__ */ x(It, {
								animal: k,
								withDisc: !0,
								className: "cascadia-score-title__icon"
							}),
							a(Jn[k]),
							/* @__PURE__ */ x("span", {
								className: "cascadia-score-title__mark",
								children: e.cards === "family" || e.cards === "intermediate" ? a(e.cards === "family" ? "games.cascadia.cardsFamily" : "games.cascadia.cardsIntermediate") : e.cards[k]
							})
						]
					}),
					children: k && /* @__PURE__ */ x(Gn, {
						cards: e.cards,
						animal: k,
						score: fe[f]?.animals[k] ?? 0,
						description: a(e.cards === "family" ? "games.cascadia.cardFamily" : e.cards === "intermediate" ? "games.cascadia.cardIntermediate" : Rn[`${k}${e.cards[k]}`]?.description ?? Yn[k][e.cards[k]])
					})
				}),
				/* @__PURE__ */ S(s, {
					open: j,
					onClose: () => ne(!1),
					label: a("games.cascadia.landmarks"),
					title: a("games.cascadia.landmarks"),
					footer: F && I === "landmark" && /* @__PURE__ */ S("div", {
						className: "cascadia-landmark-actions",
						children: [/* @__PURE__ */ x("button", {
							type: "button",
							className: "btn-quiet min-h-12 px-3",
							onClick: () => {
								r({ type: "skipLandmark" }), ne(!1);
							},
							children: a("games.cascadia.skipLandmark")
						}), /* @__PURE__ */ x("button", {
							type: "button",
							className: "btn-base min-h-12 flex-1 text-white",
							style: { background: "var(--cascadia-forest, #3f7358)" },
							disabled: !P,
							onClick: () => {
								P && (r({
									type: "placeLandmark",
									...P
								}), ne(!1));
							},
							children: a("games.cascadia.landmarkConfirm")
						})]
					}),
					children: [/* @__PURE__ */ S("div", {
						className: "cascadia-landmark-tabs",
						children: [/* @__PURE__ */ x("button", {
							type: "button",
							"aria-pressed": ie === "claimed",
							onClick: () => N("claimed"),
							children: a("games.cascadia.myLandmarks")
						}), /* @__PURE__ */ x("button", {
							type: "button",
							"aria-pressed": ie === "available",
							onClick: () => N("available"),
							children: a("games.cascadia.landmarkSupply")
						})]
					}), /* @__PURE__ */ x("div", {
						className: "cascadia-landmark-list",
						children: ie === "claimed" ? we.length ? we.map((e) => /* @__PURE__ */ x(Kn, {
							...e,
							score: Te[e.habitat]
						}, e.habitat)) : /* @__PURE__ */ x("p", { children: a("games.cascadia.landmarkEmpty") }) : G.filter((e) => I !== "landmark" || !F || Ce.includes(e)).map((t) => /* @__PURE__ */ S("section", { children: [/* @__PURE__ */ S("h3", { children: [
							Me[t],
							" ",
							a(je[t])
						] }), e.landmarkSupply[t].map((e) => /* @__PURE__ */ x(Kn, {
							habitat: t,
							card: e,
							selected: P?.habitat === t && P.card === e,
							onClick: Ce.includes(t) ? () => ae({
								habitat: t,
								card: e
							}) : void 0
						}, e))] }, t))
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/games/cascadia/bot.ts
function $n(e, t) {
	let n = 0, r = 0;
	for (let i of K) {
		let a = Object.keys(e).filter((t) => e[t].animal === i);
		if (a.length === 0) continue;
		if (t === "family" || t === "intermediate") {
			for (let e of W(a)) e.length === 1 ? n += 1 : t === "intermediate" && e.length < 4 && (n += .5);
			continue;
		}
		let o = t[i];
		if ([
			"A",
			"B",
			"C",
			"D"
		].includes(o)) {
			if (i === "b") for (let e of W(a)) {
				let t = e.length;
				o === "A" ? t === 1 ? n += 1 : t > 2 && (r += t - 2) : o === "B" ? t === 1 ? n += 1 : t === 2 ? n += 1.5 : t > 3 && (r += t - 3) : o === "C" ? t === 1 || t === 2 ? n += 1 : t > 3 && (r += t - 3) : t === 1 ? n += 1 : t > 4 && (r += t - 4);
			}
			else if (i === "s") {
				let e = new Set(a);
				r += a.filter((t) => H(t).filter((t) => e.has(t)).length >= 3).length;
				for (let e of it(a)) {
					let t = e.length;
					o === "A" ? n += t < 7 ? .3 * t : 0 : o === "B" ? n += t < 5 ? .4 * t : 0 : t < 3 && (n += t);
				}
			} else if (i === "e") {
				if (o === "A" || o === "B") for (let e of W(a)) e.length === 1 && (n += .5);
			} else if (i === "h") {
				if (o === "B") {
					let e = new Set(a);
					n += a.filter((t) => !H(t).some((t) => e.has(t))).length;
				} else o === "D" && (n += .7 * a.length);
			} else if (o === "D") {
				let e = new Set(a);
				n += a.filter((t) => !H(t).some((t) => e.has(t))).length;
			}
		}
	}
	return {
		build: n,
		over: r
	};
}
var er = {
	pineconeW: 1,
	mixedPremium: .2,
	buildW: .6,
	overW: 1,
	majorityW: .5,
	noiseW: 1
};
function tr(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function nr() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function rr(e = er) {
	return (t, n) => {
		let r = t.public;
		if (r.phase !== "play") return null;
		let i = r.players[r.turn.playerIdx];
		if (!i || i.rid !== n.rid) return null;
		let a = I(N(n.rid)), o = n.difficulty === "weak", s = () => (nr() - .5) * a.noise * 2 * e.noiseW, c = r.players.filter((e) => e.rid !== i.rid).map((e) => Re(e.board).corridors), l = (t, n) => {
			let i = vt(t, r.cards, n), a = $n(t, r.cards), o = yt([...c, i.corridors], r.players.length).at(-1);
			return i.total + (e.pineconeW - 1) * n + e.majorityW * o + e.buildW * a.build - e.overW * a.over;
		}, u = l(i.board, i.nature), d = (e, t, n, r, a) => {
			let o = +!!Y(J[n]), s = {
				...e,
				[t]: {
					tile: n,
					rot: r,
					animal: a
				}
			};
			return l(s, i.nature + o) - l(e, i.nature);
		}, f = (e, t) => {
			let n = null, r = t !== void 0 && J[e].animals.includes(t);
			for (let a of wt(i.board)) for (let o = 0; o < 6; o++) {
				let c = {
					...i.board,
					[a]: {
						tile: e,
						rot: o
					}
				}, f = l(c, i.nature) - u;
				r && (f += Math.max(d(c, a, e, o, t), 0)), f += s(), (!n || f > n.delta) && (n = {
					key: a,
					rot: o,
					delta: f,
					board: c
				});
			}
			return n;
		}, p = (e) => {
			let t = null;
			for (let n of Tt(i.board, e)) {
				let r = i.board[n], a = d(i.board, n, r.tile, r.rot, e) + s();
				(!t || a > t.delta) && (t = {
					key: n,
					delta: a
				});
			}
			return t;
		};
		if (r.turn.stage === "starterPick") {
			let e = r.extraTiles.map((e) => ({
				tile: e,
				value: f(e)?.delta ?? 0
			}));
			return { action: {
				type: "chooseStarter",
				tile: (o ? tr(e) : e.reduce((e, t) => t.value > e.value ? t : e)).tile
			} };
		}
		if (r.turn.stage === "landmark") {
			let e = r.turn.placedKey, t = [];
			for (let n of Le(i.board, e)) for (let a of r.landmarkSupply[n]) {
				let r = {
					...i.board,
					[e]: {
						...i.board[e],
						landmark: {
							habitat: n,
							card: a
						}
					}
				};
				t.push({
					habitat: n,
					card: a,
					value: l(r, i.nature) - u + s()
				});
			}
			if (!t.length) return { action: { type: "skipLandmark" } };
			let n = o ? tr(t) : t.reduce((e, t) => t.value > e.value ? t : e);
			return { action: {
				type: "placeLandmark",
				habitat: n.habitat,
				card: n.card
			} };
		}
		if (r.turn.stage === "draft") {
			if (!r.turn.wipe3Used && r.display.some((e, t, n) => n.filter((t) => t.token === e.token).length === 3)) return { action: { type: "wipe3" } };
			let t = r.display.map((e) => f(e.tile)), n = r.display.map((e) => p(e.token)), a = [];
			for (let o = 0; o < 4; o++) for (let s = 0; s < 4; s++) {
				if (o !== s && i.nature < 1) continue;
				let c = n[s]?.delta ?? 0, l = t[o];
				l && J[r.display[o].tile].animals.includes(r.display[s].token) && (c = Math.max(c, d(l.board, l.key, r.display[o].tile, l.rot, r.display[s].token)));
				let u = o === s ? 0 : e.pineconeW + e.mixedPremium, f = (l?.delta ?? 0) + Math.max(c, 0) - u;
				a.push({
					tile: o,
					token: s,
					value: f
				});
			}
			let s = o ? tr(a) : a.reduce((e, t) => t.value > e.value ? t : e);
			return { action: {
				type: "pick",
				tile: s.tile,
				token: s.token
			} };
		}
		let m = r.turn.picked;
		if (r.turn.stage === "tile" || r.turn.stage === "starterTile") {
			let e = wt(i.board);
			if (o) {
				let [t, n] = B(tr(e));
				return { action: {
					type: "placeTile",
					q: t,
					r: n,
					rot: Math.floor(nr() * 6)
				} };
			}
			let t = f(r.turn.starterTile ?? m.tile, m?.token), [n, a] = B(t ? t.key : e[0]);
			return { action: {
				type: "placeTile",
				q: n,
				r: a,
				rot: t?.rot ?? 0
			} };
		}
		let h = p(m.token);
		if ((!h || !o && h.delta <= 0) && (!o || !h || nr() < .5)) return { action: { type: "skipToken" } };
		let [g, _] = B(o && h ? tr(Tt(i.board, m.token)) : h.key);
		return { action: {
			type: "placeToken",
			q: g,
			r: _
		} };
	};
}
var ir = rr(), ar = {
	b: "games.cascadia.animalB",
	e: "games.cascadia.animalE",
	s: "games.cascadia.animalS",
	h: "games.cascadia.animalH",
	f: "games.cascadia.animalF"
}, or = (e, t, n) => {
	switch (e.type) {
		case "wipe3": return n("games.cascadia.wipe3");
		case "pick": {
			let r = t.public.display[e.token]?.token, i = r ? n(ar[r]) : "";
			return e.tile === e.token ? n("games.cascadia.hintPick", {
				n: e.tile + 1,
				animal: i
			}) : n("games.cascadia.hintPickMixed", {
				tile: e.tile + 1,
				token: e.token + 1,
				animal: i
			});
		}
		case "placeTile": return n("games.cascadia.stageTile");
		case "chooseStarter": return n("games.cascadia.stageStarterPick");
		case "placeLandmark": return n("games.cascadia.landmarkConfirm");
		case "skipLandmark": return n("games.cascadia.skipLandmark");
		case "placeToken": {
			let e = t.public.turn.picked;
			return n("games.cascadia.placeTokenConfirm", { animal: e ? n(ar[e.token]) : "" });
		}
		case "skipToken": return n("games.cascadia.skipToken");
		default: return "";
	}
}, sr = {
	draft(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ x(R, {
				at: n,
				ms: 600
			})
		} : null;
	},
	placeTile(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ x(R, {
				at: n,
				ms: 600
			})
		} : null;
	},
	placeToken(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || typeof n?.animal != "string" ? null : {
			ms: 1e3,
			node: /* @__PURE__ */ x(L, {
				at: r,
				ms: 1e3,
				children: /* @__PURE__ */ x(It, {
					animal: n.animal,
					withDisc: !0,
					className: "size-9"
				})
			})
		};
	},
	pinecone(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 1200,
			node: /* @__PURE__ */ x(L, {
				at: n,
				ms: 1200,
				children: "🌲+1"
			})
		} : null;
	},
	wipe(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ x(R, {
				at: n,
				ms: 500
			})
		} : null;
	},
	skipToken() {
		return null;
	},
	gameEnd() {
		return null;
	}
};
//#endregion
//#region src/games/cascadia/endgame-review.tsx
function cr({ board: e, renderResult: t, ...n }) {
	let s = l(), [c, d] = o(!0), [f, h] = o(null), g = a(null), _ = a(null), v = a(null);
	r(() => {
		if (!f) return;
		v.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => h(null), 5e3);
		return () => clearTimeout(e);
	}, [f]);
	let y = (e) => {
		h(null), d(e), requestAnimationFrame(() => (e ? g : _).current?.focus({ preventScroll: !0 }));
	}, b = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => h({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => h({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => h({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), C = {
		...n,
		...b
	};
	return /* @__PURE__ */ S("div", {
		className: "cascadia-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ x("div", {
				className: "cascadia-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ x("div", {
				className: "cascadia-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ S("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), y(!1));
					},
					className: "cascadia-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ S("header", {
							className: "cascadia-endgame-heading",
							children: [/* @__PURE__ */ S("div", {
								className: "cascadia-endgame-brand",
								children: [/* @__PURE__ */ x("span", {
									"aria-hidden": "true",
									children: me.icon
								}), s(me.nameKey)]
							}), /* @__PURE__ */ x("button", {
								type: "button",
								ref: g,
								className: "btn-quiet",
								"aria-label": s("games.cascadia.reviewHide"),
								title: s("games.cascadia.reviewHide"),
								onClick: () => y(!1),
								children: /* @__PURE__ */ x(p, { size: 19 })
							})]
						}),
						/* @__PURE__ */ x("div", {
							className: "cascadia-endgame-result",
							inert: f !== null,
							children: t(C)
						}),
						f && /* @__PURE__ */ S("div", {
							className: "cascadia-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || h(null);
							},
							children: [/* @__PURE__ */ x("button", {
								type: "button",
								ref: v,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = f.run;
									h(null), e();
								},
								children: s(f.label === "again" ? "games.cascadia.reviewConfirmAgain" : "games.cascadia.reviewConfirmLobby")
							}), /* @__PURE__ */ x("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									h(null), g.current?.focus({ preventScroll: !0 });
								},
								children: s("games.cascadia.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ x("div", {
				className: "cascadia-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ S("button", {
					type: "button",
					className: "btn-base",
					ref: _,
					onClick: () => y(!0),
					children: [
						/* @__PURE__ */ x(m, { size: 18 }),
						s("games.cascadia.reviewShow"),
						/* @__PURE__ */ x(u, { size: 18 })
					]
				})
			})
		]
	});
}
function lr({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: u, renderRowExtra: f, summary: m, navigation: h, content: g, afterRanking: _, scoreUnit: v, rankOf: y, bodyKey: C }) {
	let w = l(), T = c((e) => e.locale), [E, D] = o({}), O = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? F(n, T) : e;
	}, k = (t, n) => y?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), ee = e.ranking.some((t) => e.scores?.[t] !== void 0), te = (t, n) => /* @__PURE__ */ S("div", {
		className: "cascadia-score-identity",
		children: [
			/* @__PURE__ */ S("span", {
				className: "cascadia-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ x("span", {
					"aria-label": w("games.cascadia.reviewWinner"),
					children: "♛ "
				}), ee && k(t, n)]
			}),
			/* @__PURE__ */ S("span", {
				className: "cascadia-score-name",
				children: [O(t), t === r && /* @__PURE__ */ x("small", { children: w("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ S("small", {
				className: "cascadia-score-autopilot",
				children: [
					/* @__PURE__ */ x(d, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), A = (t) => e.ranking.map((n) => /* @__PURE__ */ x("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ S("div", {
		className: "cascadia-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ x(ce, {}),
			h,
			/* @__PURE__ */ S("div", {
				className: "cascadia-score-body",
				children: [
					m && /* @__PURE__ */ x("div", {
						className: "cascadia-score-summary",
						children: m
					}),
					i !== void 0 && /* @__PURE__ */ x("p", {
						className: "cascadia-score-hints",
						children: w("session.hint.usedCount", { n: i })
					}),
					g ?? (u?.length ? /* @__PURE__ */ x("div", {
						className: "cascadia-score-table-scroll",
						children: /* @__PURE__ */ S("table", {
							className: "cascadia-score-table",
							"aria-label": w(me.nameKey),
							children: [
								/* @__PURE__ */ x("thead", { children: /* @__PURE__ */ S("tr", { children: [/* @__PURE__ */ x("th", { scope: "col" }), /* @__PURE__ */ x(b, { children: e.ranking.map((t, n) => /* @__PURE__ */ x("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: te(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ x("tbody", { children: u.map((e, t) => /* @__PURE__ */ S(n, { children: [/* @__PURE__ */ S("tr", { children: [/* @__PURE__ */ x("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ S("button", {
										type: "button",
										"aria-expanded": !!E[t],
										onClick: () => D((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ x(p, { size: 15 }), e.label]
									}) : e.label
								}), A(e)] }), E[t] && e.details?.map((e, t) => /* @__PURE__ */ S("tr", {
									className: "cascadia-score-sub",
									children: [/* @__PURE__ */ x("th", {
										scope: "row",
										children: e.label
									}), A(e)]
								}, t))] }, t)) }),
								ee && /* @__PURE__ */ x("tfoot", { children: /* @__PURE__ */ S("tr", { children: [/* @__PURE__ */ x("th", {
									scope: "row",
									children: w("games.cascadia.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ x("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ x("ol", {
						className: "cascadia-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ S("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ S("div", {
								className: "cascadia-score-rankline",
								children: [te(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ S("strong", {
									className: "cascadia-score-points",
									children: [e.scores[t], v && /* @__PURE__ */ x("small", { children: v })]
								})]
							}), f?.(t)]
						}, t))
					})),
					_,
					!!u?.length && f && /* @__PURE__ */ x("div", {
						className: "cascadia-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ S("details", { children: [/* @__PURE__ */ x("summary", { children: O(e) }), f(e)] }, e))
					})
				]
			}, C),
			/* @__PURE__ */ S("footer", {
				className: "cascadia-score-actions",
				children: [
					s && /* @__PURE__ */ x("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: w("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ x("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: w("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ x("p", { children: w("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/cascadia/game-over.tsx
var ur = {
	M: "games.cascadia.habitatM",
	F: "games.cascadia.habitatF",
	P: "games.cascadia.habitatP",
	W: "games.cascadia.habitatW",
	R: "games.cascadia.habitatR"
}, dr = {
	b: "games.cascadia.animalB",
	e: "games.cascadia.animalE",
	s: "games.cascadia.animalS",
	h: "games.cascadia.animalH",
	f: "games.cascadia.animalF"
};
function fr(e) {
	let t = l(), n = c((e) => e.locale), r = e.public, [i, a] = o("scores"), s = (e) => r.final?.find((t) => t.rid === e), u = [
		{
			label: t("games.cascadia.reviewWildlife"),
			value: (e) => {
				let t = s(e);
				return t ? Object.values(t.animals).reduce((e, t) => e + t, 0) : "—";
			},
			details: K.map((e) => ({
				label: /* @__PURE__ */ S("span", {
					className: "cascadia-result-animal",
					children: [
						/* @__PURE__ */ x(It, {
							animal: e,
							withDisc: !0,
							className: "size-5"
						}),
						t(dr[e]),
						r.cards !== "family" && r.cards !== "intermediate" && /* @__PURE__ */ x("small", { children: r.cards[e] })
					]
				}),
				value: (t) => s(t)?.animals[e] ?? "—"
			}))
		},
		{
			label: t("games.cascadia.reviewHabitats"),
			value: (e) => {
				let t = s(e);
				return t ? Object.values(t.corridors).reduce((e, t) => e + t, 0) : "—";
			},
			details: G.map((e) => ({
				label: t(ur[e]),
				value: (t) => s(t)?.corridors[e] ?? "—"
			}))
		},
		{
			label: t("games.cascadia.scoreBonus"),
			value: (e) => s(e)?.bonus ?? "—"
		},
		{
			label: t("games.cascadia.scoreNature"),
			value: (e) => s(e)?.nature ?? "—"
		},
		...r.landmarksEnabled ? [{
			label: t("games.cascadia.landmarks"),
			value: (e) => {
				let t = s(e);
				return t ? Object.values(t.landmarks).reduce((e, t) => e + t, 0) : "—";
			},
			details: G.map((e) => ({
				label: t(ur[e]),
				value: (t) => s(t)?.landmarks[e] ?? "—"
			}))
		}] : []
	], d = (t) => {
		let n = s(t);
		return e.result.ranking.findIndex((e) => {
			let t = s(e);
			return t?.total === n?.total && t?.nature === n?.nature;
		}) + 1;
	}, f = /* @__PURE__ */ x("div", {
		className: "cascadia-result-boards",
		children: e.result.ranking.map((t) => {
			let i = r.players.find((e) => e.rid === t), a = s(t), o = e.members.find((e) => e.rid === t);
			return i && a && /* @__PURE__ */ S("section", { children: [
				/* @__PURE__ */ S("header", { children: [/* @__PURE__ */ x("strong", { children: o ? F(o, n) : t }), /* @__PURE__ */ x("b", { children: a.total })] }),
				/* @__PURE__ */ x("div", {
					className: "cascadia-result-board",
					children: /* @__PURE__ */ x($t, { board: i.board })
				}),
				r.landmarksEnabled && /* @__PURE__ */ x("div", {
					className: "cascadia-landmark-list",
					children: Object.values(i.board).flatMap((e) => e.landmark ? [e.landmark] : []).map((e) => /* @__PURE__ */ x(Kn, {
						...e,
						score: a.landmarks[e.habitat]
					}, e.habitat))
				})
			] }, t);
		})
	});
	return /* @__PURE__ */ x(lr, {
		...e,
		renderRowExtra: void 0,
		bodyKey: i,
		rows: u,
		rankOf: d,
		navigation: /* @__PURE__ */ S("div", {
			className: "cascadia-result-tabs",
			role: "group",
			"aria-label": t("games.cascadia.reviewOverview"),
			children: [/* @__PURE__ */ x("button", {
				type: "button",
				"aria-pressed": i === "scores",
				onClick: () => a("scores"),
				children: t("games.cascadia.reviewOverview")
			}), /* @__PURE__ */ x("button", {
				type: "button",
				"aria-pressed": i === "boards",
				onClick: () => a("boards"),
				children: t("games.cascadia.reviewBoards")
			})]
		}),
		content: i === "boards" ? f : void 0
	});
}
function pr(e) {
	return /* @__PURE__ */ x(cr, {
		...e,
		board: /* @__PURE__ */ x(Zn, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ x(fr, { ...e })
	});
}
//#endregion
//#region src/games/cascadia/options.tsx
var mr = [
	{
		id: "random",
		label: "games.cascadia.optRandom",
		hint: "games.cascadia.optRandomHint"
	},
	{
		id: "A",
		label: "games.cascadia.optA",
		hint: "games.cascadia.optAHint"
	},
	{
		id: "family",
		label: "games.cascadia.optFamily",
		hint: "games.cascadia.optFamilyHint"
	},
	{
		id: "intermediate",
		label: "games.cascadia.optIntermediate",
		hint: "games.cascadia.optIntermediateHint"
	}
];
function hr({ value: e, onChange: t }) {
	let n = l(), r = We.safeParse(e), i = r.success ? r.data : We.parse(void 0);
	return /* @__PURE__ */ S(b, { children: [
		/* @__PURE__ */ x(de, {
			title: n("games.cascadia.optCards"),
			children: mr.map((e) => /* @__PURE__ */ x(ue, {
				name: "cascadia-cards",
				value: e.id,
				checked: i.cards === e.id,
				label: n(e.label),
				hint: n(e.hint),
				accent: me.accent,
				onChange: () => t({
					...i,
					cards: e.id
				})
			}, e.id))
		}),
		/* @__PURE__ */ S(de, {
			title: n("games.cascadia.optExpansions"),
			children: [
				/* @__PURE__ */ x(le, {
					name: "cascadia-expansionTiles",
					value: "expansionTiles",
					checked: i.expansionTiles || i.landmarks,
					label: n("games.cascadia.optExpansionTiles"),
					onChange: () => t({
						...i,
						expansionTiles: !(i.expansionTiles || i.landmarks),
						landmarks: !1
					})
				}),
				/* @__PURE__ */ x(le, {
					name: "cascadia-landmarks",
					value: "landmarks",
					checked: i.landmarks,
					label: n("games.cascadia.optLandmarks"),
					hint: n("games.cascadia.optLandmarksHint"),
					onChange: () => t({
						...i,
						landmarks: !i.landmarks,
						expansionTiles: !i.landmarks || i.expansionTiles
					})
				}),
				i.cards === "random" && /* @__PURE__ */ x(le, {
					name: "cascadia-expansionCards",
					value: "expansionCards",
					checked: i.expansionCards,
					label: n("games.cascadia.optExpansionCards"),
					onChange: () => t({
						...i,
						expansionCards: !i.expansionCards
					})
				})
			]
		}),
		(i.cards === "random" || i.landmarks) && /* @__PURE__ */ S(de, {
			title: n("games.cascadia.optPromos"),
			children: [i.cards === "random" && /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x(le, {
				name: "cascadia-kickstarter",
				value: "kickstarter",
				checked: i.kickstarter,
				label: n("games.cascadia.optKickstarter"),
				onChange: () => t({
					...i,
					kickstarter: !i.kickstarter
				})
			}), /* @__PURE__ */ x(le, {
				name: "cascadia-ecosystem",
				value: "ecosystem",
				checked: i.ecosystem,
				label: n("games.cascadia.optEcosystem"),
				onChange: () => t({
					...i,
					ecosystem: !i.ecosystem
				})
			})] }), i.landmarks && /* @__PURE__ */ x(le, {
				name: "cascadia-landmarkPromos",
				value: "landmarkPromos",
				checked: i.landmarkPromos,
				label: n("games.cascadia.optLandmarkPromos"),
				hint: n("games.cascadia.optLandmarkPromosHint"),
				onChange: () => t({
					...i,
					landmarkPromos: !i.landmarkPromos
				})
			})]
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/cascadia/entry.tsx
var gr = {
	definition: Mt,
	View: Zn,
	bot: ir,
	describe: or,
	fx: sr,
	OverView: pr,
	Options: hr,
	locales: {
		zh: {
			reviewWildlife: "野生动物",
			reviewHabitats: "栖息地",
			reviewOverview: "计分总览",
			reviewBoards: "版图详情",
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			optExpansions: "自然地标（Cascadia: Landmarks）",
			optExpansionCards: "动物计分卡（E–G，15 张）",
			optKickstarter: "基础版 Kickstarter 宣传卡（5 张）",
			optEcosystem: "Ecosystem Connections 宣传卡（2 张）",
			optExpansionTiles: "扩展板块与动物标记（支持 6 人）",
			optLandmarks: "地标玩法",
			optLandmarksHint: "加入地标卡、地标放置和额外起始板块。",
			optLandmarkPromos: "自然地标宣传卡（部分，3 张）",
			optLandmarkPromosHint: "森林 P2、P3 和湿地 P1。",
			optPromos: "官方宣传卡",
			stageStarterPick: "选择额外的关键板块",
			stageStarterTile: "放置额外的关键板块",
			stageLandmark: "选择地标计分卡，或跳过放置",
			landmarks: "地标",
			landmarkSupply: "公共地标卡",
			myLandmarks: "已获得的地标卡",
			landmarkEmpty: "尚未获得地标卡",
			landmarkConfirm: "放置地标并领取卡牌",
			skipLandmark: "跳过地标",
			landmarkWildlife: "每枚位于含{{habitat}}板块的指定动物标记得 1 分。",
			landmarkE: "最大{{habitat}}走廊中的每种动物得 1 分；并列时取种类最多的一条走廊。",
			landmarkF: "每两块已放动物、且含{{habitat}}的关键板块得 3 分。",
			landmarkG: "每条{{habitat}}走廊得 1 分，单块板块也算一条走廊。",
			landmarkH: "每条至少两块板块的{{habitat}}走廊得 2 分。",
			landmarkI: "{{habitat}}走廊计分时，将最大的两条走廊大小相加，并据此比较多数奖励。",
			landmarkJ: "最大{{habitat}}走廊大小加 2，同时用于走廊计分和多数奖励。",
			landmarkK: "6 分减去{{habitat}}走廊数量，最低 0 分。",
			landmarkL: "直接获得 3 分。",
			landmarkP1: "直接获得 4 分。",
			landmarkP2: "含森林的板块上，每两枚同种动物标记得 1 分，无须相邻。",
			landmarkP3: "最大森林走廊为 5/6–7/8–9/10–11/12+ 块时，得 1/2/3/4/5 分。",
			errBadLandmark: "当前不能放置该地标或领取该卡牌。",
			chooseStarter: "选择板块",
			pairAria: "选择第{{n}}组板块与{{animal}}标记",
			landmarkCardAria: "{{habitat}}{{card}} 地标卡",
			landmarkCorridorEffect: "已计入走廊得分",
			extHintBearE: "边缘的独居熊",
			extRuleBearE: "每只不与其他熊相邻、且至少邻接一个没有板块的位置的熊得 3 分。",
			extHintBearF: "熊群与四种邻居",
			extRuleBearF: "每个至少 3 只的熊群，若邻接其余四种动物，得 12 分。邻接动物数量和空位不受限制。",
			extHintBearG: "森林中的熊对子",
			extRuleBearG: "恰好两只相连的熊构成对子，至少一只位于含森林的板块。1/2/3/4+ 对得 5/12/20/29 分。",
			extHintBearKS: "同尺寸熊群",
			extRuleBearKS: "只选择一种熊群尺寸计分：每个 1/2/3/4 只的熊群得 2/5/9/13 分，取总分最高的一种尺寸。其他尺寸不得分。",
			extHintBearEC: "独居熊邻接鲑鱼",
			extRuleBearEC: "不与其他熊相邻、且邻接至少一条鲑鱼的熊计分。1–7+ 只得 3/6/9/13/17/22/27 分。",
			extHintElkE: "三只组成半环",
			extRuleElkE: "每个恰好 3 只、呈指定半环形且不邻接其他麋鹿的群落计分。1/2/3+ 群得 10/21/33 分，阵型可旋转。",
			extHintElkF: "三角鹿群远离动物",
			extRuleElkF: "每个三角形的 3 只麋鹿得 13 分，周围每枚动物标记扣 1 分。同一枚邻接标记只扣一次，群外麋鹿也扣分。每只麋鹿只能归入一个计分组。",
			extHintElkG: "草原上的指定阵型",
			extRuleElkG: "单只、相邻对子、三角形、菱形分别得 3/6/10/14 分；每组至少一只麋鹿位于含草原的板块。阵型可旋转，每只麋鹿只计入一组。",
			extHintElkKS: "同朝向麋鹿对子",
			extRuleElkKS: "按三种朝向分别统计相邻麋鹿对子，每种朝向 1/2/3/4+ 对得 5/12/20/29 分。不同朝向的得分相加，每只麋鹿只用于一对。",
			extHintSalmonE: "交替转弯的鱼群",
			extRuleSalmonE: "鱼群必须符合指定的锯齿形，可旋转或镜像。1/2/3/4/5/6+ 条得 2/5/9/13/17/21 分。每条鲑鱼最多邻接两条鲑鱼。",
			extHintSalmonF: "鱼群和邻近的熊",
			extRuleSalmonF: "每条鱼群按 1–7+ 条得 1/3/7/10/13/17/22 分，邻接该鱼群的每只熊再加 1 分。同一只熊对同一鱼群只计一次，可为不同鱼群计分。",
			extHintSalmonG: "河流中的鱼群",
			extRuleSalmonG: "每条鱼群按 1/2/3/4/5+ 条得 2/4/7/10/14 分，其中每条位于含河流板块的鲑鱼再加 1 分。",
			extHintSalmonKS: "鱼群旁的动物群",
			extRuleSalmonKS: "至少 3 条的鱼群，按邻接的其他同种动物群计分。每群中直接邻接鱼群的动物为 1/2/3+ 只时，得 1/3/5 分；同种不同群可分别计分。",
			extHintHawkE: "只互相看见的鹰",
			extRuleHawkE: "每对不相邻、互相可见且各自看不见其他鹰的鹰得 7 分。视线只被其他鹰阻挡。",
			extHintHawkF: "鹰望见狐狸",
			extRuleHawkF: "至少望见一只不相邻狐狸的鹰计分。1–7+ 只得 2/5/8/10/16/18/25 分。相邻狐狸会阻断该方向更远的狐狸，其他鹰也阻挡视线。",
			extHintHawkG: "跨越三种地形的鹰",
			extRuleHawkG: "每对不相邻、互相可见且两者之间含至少三种地形的鹰计分。1/2/3/4+ 对得 7/14/22/30 分。两端板块不计入中间地形，每只鹰只用于一对。",
			extHintHawkKS: "鹰旁的未铺板块空位",
			extRuleHawkKS: "统计所有鹰周围没有板块的位置并去重。3/6/9/12/16/20/25/30+ 个空位得 2/4/7/10/14/18/22/27 分。",
			extHintHawkEC: "鹰望见麋鹿和狐狸",
			extRuleHawkEC: "同时有直线视野通向不相邻麋鹿和狐狸的鹰计分。1–7+ 只得 3/6/9/13/17/22/27 分。",
			extHintFoxE: "被动物围绕的狐狸",
			extRuleFoxE: "每只狐狸周围六格全有动物得 4 分，四至五格有动物得 2 分，其余不得分；狐狸也算邻接动物。",
			extHintFoxF: "恰好两种动物邻居",
			extRuleFoxF: "每只狐狸若恰好邻接两种动物，得 3 分；相邻狐狸也算一种。邻接动物总数不限。",
			extHintFoxG: "相接边的地形多样性",
			extRuleFoxG: "每只狐狸按相邻板块接触其板块的边所含的不同地形数计分，每种 1 分。狐狸所在板块自身的地形不计。",
			extHintFoxKS: "邻居的三种数量",
			extRuleFoxKS: "忽略相邻狐狸，按其他动物的同种数量 1/2/3 只分别得 1/2/2 分。每种数量最多计一次，单只狐狸最多 5 分；超过三只的种类不得分。",
			name: "卡斯卡迪亚之旅",
			desc: "拼六边形栖息地,安顿五种野生动物",
			rules: "目标:每人固定 20 回合;终局按 5 张动物计分卡、5 种地形走廊和自然标记计分,总分最高者获胜。\n流程(每回合):\n· 从中央 4 对「板块 + 标记」中选一对。\n· 板块放进自己的版图,必须挨着已有板块。\n· 将动物标记放到印有该动物、且没有动物或地标的板块上；无法放置或不愿放置时，将该标记放回袋中。\n自然标记:\n· 把动物标记放到只印一种动物的关键板块上（关键板块可以包含多种地形）,获得 1 个自然标记。\n· 花 1 个自然标记可以混选任意板块与标记,或移除任意数量的展示标记，并重新抽取相同数量的标记。\n· 展示标记有 3 个相同时,每回合可以免费更换这3个标记一次；4个标记相同时，自动更换这些标记。\n终局计分:\n· 根据5张动物计分卡、每种地形的最长走廊及剩余自然标记计算得分。每种地形的最大走廊另有加分。\n· 总分相同时，剩余自然标记较多的玩家获胜；若仍然相同，则共享胜利。\n地标扩展（可选）：\n· 开局按逆序选择并放置一块额外关键板块。每种地形公开的地标卡数量等于人数。\n· 刚放的板块所在的连续栖息地至少五块时，可以在该板块上放对应地标。\n· 放置地标后，领取该地形的一张公开卡；也可以跳过。每人每类地标最多一个。\n· 地标占位后不能再放动物，放地标不奖励自然标记。本回合选取的动物仍可放在其他合法板块上。\n· 按地标卡条件计分。I/J 卡调整走廊大小，同时影响走廊得分和多数奖励。\n扩展选项：\n· 扩展板块支持二至六人，可独立使用。\n· 随机动物卡可分别混入 E–G、Kickstarter 和 Ecosystem Connections。\n· 地标宣传卡包含森林 P2、P3 及湿地 P1 三张。",
			roundShort: "回合 {{n}}/{{total}}",
			stageDraft: "选一对板块 + 标记",
			stageTile: "把板块放进版图",
			stageToken: "放置标记,或放回袋中",
			waitTurn: "等 {{name}} 操作…",
			watchHint: "轮到你时,这里会出现操作按钮",
			natureAria: "{{n}} 个自然标记",
			playerAria: "查看{{name}}的版图：{{nature}} 个自然标记，预计总分 {{score}} 分",
			playerPoints: "分",
			tileAria: "板块 {{n}}",
			pickConfirm: "拿取",
			pickMixed: "混选 🌲−1",
			wipe3: "擦除 3 同",
			wipeTokens: "🌲 擦除",
			wipeTokensConfirm: "擦除 {{n}} 个 🌲−1",
			wipeCancel: "取消",
			rotate: "旋转",
			placeTileConfirm: "放在这里",
			placeTokenConfirm: "放置{{animal}}",
			skipToken: "放回袋中",
			cardsFamily: "家庭卡",
			cardsIntermediate: "中级卡",
			cardsFamilyMark: "家",
			cardsIntermediateMark: "中",
			animalB: "熊",
			animalE: "麋鹿",
			animalS: "鲑鱼",
			animalH: "鹰",
			animalF: "狐狸",
			habitatM: "山脉",
			habitatF: "森林",
			habitatP: "草原",
			habitatW: "湿地",
			habitatR: "河流",
			scoreBonus: "走廊最大加分",
			scoreNature: "自然标记",
			cardScoreNow: "当前 {{n}} 分",
			scoreCardAria: "{{animal}}{{card}}计分卡，当前 {{n}} 分，点开查看图解",
			scoreHintBearA: "恰好两只成对",
			scoreHintBearB: "三只熊成群",
			scoreHintBearC: "1–3只熊群",
			scoreHintBearD: "两至四只成群",
			scoreHintElkA: "麋鹿连成直线",
			scoreHintElkB: "四种指定阵型",
			scoreHintElkC: "相连群落越大越好",
			scoreHintElkD: "围成环",
			scoreHintSalmonA: "连成鱼群",
			scoreHintSalmonB: "连成鱼群",
			scoreHintSalmonC: "三条起计分",
			scoreHintSalmonD: "鱼群与邻近动物",
			scoreHintHawkA: "彼此不相邻",
			scoreHintHawkB: "隔空相望",
			scoreHintHawkC: "可见鹰成对",
			scoreHintHawkD: "视线中动物",
			scoreHintFoxA: "邻域多样",
			scoreHintFoxB: "邻域同种成对",
			scoreHintFoxC: "邻域最多的同种",
			scoreHintFoxD: "双狐邻域对子",
			scoreHintFamily: "同种相连成群",
			scoreHintIntermediate: "两只起计分",
			scoreMetricPairs: "熊对子数",
			scoreMetricGroupSize: "群落只数",
			scoreMetricLineLength: "直线只数",
			scoreMetricShape: "阵型只数",
			scoreMetricRingSize: "环上只数",
			scoreMetricRunLength: "鱼群条数",
			scoreMetricHawks: "符合条件的鹰",
			scoreMetricSightPairs: "可见的鹰对子",
			scoreMetricBetweenKinds: "中间动物种类",
			scoreMetricNeighborKinds: "邻近动物种类",
			scoreMetricNeighborPairs: "邻近同种对子",
			scoreMetricNeighborMax: "邻近最多的同种",
			scoreMetricPoints: "对应得分",
			scoreFormulaSalmonD: "每条至少 3 条的鱼群：每条鲑鱼 1 分，邻近的每枚动物标记再加 1 分。",
			scoreFormulaHawkC: "每对互相可见的鹰得 3 分；相邻的鹰也算互相可见。",
			scoreFormulaFoxC: "每只狐狸取周围数量最多的一种其他动物：有几只就得几分。",
			cardBearA: "每对熊(恰好 2 只相连)计分:1/2/3/4+ 对 → 4/11/19/27 分;3 只以上连在一起不得分",
			cardBearB: "每组恰好 3 只相连的熊得 10 分",
			cardBearC: "每组熊群按大小计分:1/2/3 只 → 2/5/8 分;三种大小都有再 +3 分",
			cardBearD: "每组熊群按大小计分:2/3/4 只 → 5/8/13 分",
			cardSalmonA: "每群相连的鲑鱼按条数计分:1–7+ 条 → 2/5/8/12/16/20/25 分;与 3 条以上鲑鱼相邻的鲑鱼不计",
			cardSalmonB: "每群相连的鲑鱼:1–5+ 条 → 2/4/9/11/17 分;与 3 条以上鲑鱼相邻的鲑鱼不计",
			cardSalmonC: "每群相连的鲑鱼:3/4/5+ 条 → 10/12/15 分;与 3 条以上鲑鱼相邻的鲑鱼不计",
			cardSalmonD: "每群至少 3 条的鲑鱼:群内每条 1 分,与鱼群相邻的每个动物再各 1 分;与 3 条以上鲑鱼相邻的鲑鱼不计",
			cardElkA: "麋鹿按直线分组:1/2/3/4 只 → 2/5/9/13 分;每只只属于一组,自动取总分最高的分法",
			cardElkB: "麋鹿按形状分组:单只 2 分、直线对 5 分、三角 9 分、菱形 13 分;每只只属于一组,自动取总分最高的分法",
			cardElkC: "每群相连的麋鹿:1–8+ 只 → 2/4/7/10/14/18/23/28 分",
			cardElkD: "围绕同一中心格的 6 个邻位形成环:1–6 只麋鹿 → 2/5/8/12/16/21 分,允许缺口,中心格内容不限;每只只属于一个环,自动取总分最高的分法",
			cardHawkA: "互不相邻的鹰:1–8+ 只 → 2/5/8/11/14/18/22/26 分",
			cardHawkB: "互不相邻且同一直线、中间无其他鹰的鹰:2–8 只 → 5/9/12/16/20/24/28 分",
			cardHawkC: "每对同一直线且中间无其他鹰的鹰(相邻也算)得 3 分",
			cardHawkD: "每对同一直线且中间无其他鹰的鹰,按两鹰之间的其他动物种类数计分:1/2/3+ 种 → 4/7/9 分;每只只属于一对,自动取总分最高的配法",
			cardFoxA: "每只狐狸按周围(含自身)的动物种类数计分:1–5 种 → 1–5 分",
			cardFoxB: "每只狐狸按周围成对(≥2 只)的其他动物种类数计分:1/2/3 种 → 3/5/7 分",
			cardFoxC: "每只狐狸:周围数量最多的那种其他动物有几只就得几分",
			cardFoxD: "每对相邻的狐狸按周围 8 格中同种 ≥2 只的动物种类数计分:1–4 种 → 5/7/9/11 分;每只只属于一对,自动取总分最高的配法",
			cardFamily: "每种动物按相连群落计分:1/2/3+ 只 → 2/5/9 分",
			cardIntermediate: "每种动物按相连群落计分:2/3/4+ 只 → 5/8/12 分,单只不计分",
			optCards: "计分卡",
			optRandom: "随机",
			optRandomHint: "每种动物从所选卡池随机抽取一张",
			optA: "全 A",
			optAHint: "上手推荐:全部用 A 卡",
			optFamily: "家庭卡",
			optFamilyHint: "变体:同种连通块 1/2/3+ → 2/5/9",
			optIntermediate: "中级卡",
			optIntermediateHint: "变体:同种连通块 2/3/4+ → 5/8/12",
			errNotYourTurn: "还没轮到你",
			errWipeUsed: "这回合已经擦过了",
			errNoThree: "没有恰好 3 个相同的标记",
			errNoNature: "自然标记不够",
			errBadTile: "板块必须挨着已有板块放",
			errBadToken: "这块板块放不下该标记",
			hintPick: "拿第 {{n}} 对(板块 + {{animal}})",
			hintPickMixed: "混选:第 {{tile}} 块板块 + 第 {{token}} 个标记({{animal}}),🌲−1"
		},
		en: {
			reviewWildlife: "Wildlife",
			reviewHabitats: "Habitats",
			reviewOverview: "Scores",
			reviewBoards: "Habitats in detail",
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			optExpansions: "Cascadia: Landmarks",
			optExpansionCards: "Wildlife scoring cards (E–G, 15 cards)",
			optKickstarter: "Base game Kickstarter promos (5 cards)",
			optEcosystem: "Ecosystem Connections promos (2 cards)",
			optExpansionTiles: "Expansion tiles and tokens (up to 6 players)",
			optLandmarks: "Landmarks module",
			optLandmarksHint: "Adds landmark scoring, landmark placement and an extra starting tile.",
			optLandmarkPromos: "Landmarks promos (partial, 3 cards)",
			optLandmarkPromosHint: "Forest P2/P3 and Wetland P1.",
			optPromos: "Official promo cards",
			stageStarterPick: "Choose an extra keystone tile",
			stageStarterTile: "Place your extra keystone tile",
			stageLandmark: "Choose a landmark scoring card, or skip placement",
			landmarks: "Landmarks",
			landmarkSupply: "Available landmarks",
			myLandmarks: "Claimed landmark cards",
			landmarkEmpty: "No landmark cards claimed",
			landmarkConfirm: "Place landmark and claim card",
			skipLandmark: "Skip landmark",
			landmarkWildlife: "Score 1 per depicted wildlife token on a {{habitat}} tile.",
			landmarkE: "Score 1 per wildlife type in your largest {{habitat}} corridor. For tied corridors, use the one with most types.",
			landmarkF: "Score 3 per pair of wildlife-occupied {{habitat}} keystone tiles.",
			landmarkG: "Score 1 per {{habitat}} corridor, including single-tile corridors.",
			landmarkH: "Score 2 per {{habitat}} corridor of at least two tiles.",
			landmarkI: "Combine your two largest {{habitat}} corridors for habitat scoring and majority bonuses.",
			landmarkJ: "Add 2 to your largest {{habitat}} corridor for habitat scoring and majority bonuses.",
			landmarkK: "Score 6 minus the number of {{habitat}} corridors, to a minimum of 0.",
			landmarkL: "Score 3 points.",
			landmarkP1: "Score 4 points.",
			landmarkP2: "Score 1 per pair of the same wildlife on forest tiles. They need not be adjacent.",
			landmarkP3: "Your largest forest corridor scores 1/2/3/4/5 for 5/6–7/8–9/10–11/12+ tiles.",
			errBadLandmark: "That landmark or scoring card is not available.",
			chooseStarter: "Choose tile",
			pairAria: "Select tile and {{animal}} token from pair {{n}}",
			landmarkCardAria: "{{habitat}} landmark card {{card}}",
			landmarkCorridorEffect: "Included in habitat score",
			extHintBearE: "Lone bears at edges",
			extRuleBearE: "Each bear with no adjacent bears and at least one adjacent space without a habitat tile scores 3 points.",
			extHintBearF: "Bears and four neighbors",
			extRuleBearF: "Each bear group of at least 3 scores 12 if adjacent to all four other wildlife types. Extra animals and empty spaces are allowed.",
			extHintBearG: "Forest bear pairs",
			extRuleBearG: "Isolated pairs of bears with at least one bear on a forest tile score 5/12/20/29 for 1/2/3/4+ pairs.",
			extHintBearKS: "Equal bear groups",
			extRuleBearKS: "Score only one group size: each group of 1/2/3/4 bears scores 2/5/9/13. Use the size giving the highest total.",
			extHintBearEC: "Lone bears with salmon",
			extRuleBearEC: "Bears adjacent to salmon but no other bears score 3/6/9/13/17/22/27 for 1–7+ qualifying bears.",
			extHintElkE: "Three-elk half rings",
			extRuleElkE: "Isolated groups of exactly 3 elk in the illustrated half-ring score 10/21/33 for 1/2/3+ groups. The shape may rotate.",
			extHintElkF: "Quiet elk triangles",
			extRuleElkF: "Each triangle of 3 elk scores 13 minus 1 per distinct adjacent animal, including other elk. Each elk may belong to only one scoring group.",
			extHintElkG: "Prairie formations",
			extRuleElkG: "Singles, pairs, triangles and diamonds score 3/6/10/14 if at least one elk in the group is on prairie. Shapes may rotate; each elk scores in only one group.",
			extHintElkKS: "Oriented elk pairs",
			extRuleElkKS: "Count adjacent elk pairs separately for each of the three orientations. Each orientation scores 5/12/20/29 for 1/2/3/4+ pairs. Each elk belongs to only one pair.",
			extHintSalmonE: "Zig-zag salmon",
			extRuleSalmonE: "Runs must form the illustrated zig-zag, rotated or mirrored. 1/2/3/4/5/6+ salmon score 2/5/9/13/17/21. Salmon adjacent to three or more salmon do not score.",
			extHintSalmonF: "Salmon and bears",
			extRuleSalmonF: "Runs of 1–7+ salmon score 1/3/7/10/13/17/22 plus 1 per distinct adjacent bear. A bear may score for separate runs.",
			extHintSalmonG: "River salmon",
			extRuleSalmonG: "Runs of 1/2/3/4/5+ salmon score 2/4/7/10/14 plus 1 for each salmon on a river tile.",
			extHintSalmonKS: "Gathering salmon",
			extRuleSalmonKS: "For each run of 3+ salmon, each adjacent group of other wildlife scores 1/3/5 for 1/2/3+ animals directly adjacent to the run. Separate groups score separately.",
			extHintHawkE: "Exclusive hawk pairs",
			extRuleHawkE: "Each pair of non-adjacent hawks that see each other and no other hawks scores 7. Other hawks block line of sight.",
			extHintHawkF: "Hawks seeing foxes",
			extRuleHawkF: "Hawks seeing a non-adjacent fox score 2/5/8/10/16/18/25 for 1–7+ qualifying hawks. An adjacent fox or intervening hawk blocks that sight line.",
			extHintHawkG: "Hawks across habitats",
			extRuleHawkG: "Pairs of non-adjacent hawks seeing across at least three habitat types score 7/14/22/30 for 1/2/3/4+ pairs. Endpoint tiles do not count; each hawk belongs to only one pair.",
			extHintHawkKS: "Hawks at open edges",
			extRuleHawkKS: "Count distinct adjacent spaces without tiles around all hawks. 3/6/9/12/16/20/25/30+ spaces score 2/4/7/10/14/18/22/27.",
			extHintHawkEC: "Hawks seeing elk and foxes",
			extRuleHawkEC: "Hawks with direct sight lines to both a non-adjacent elk and a non-adjacent fox score 3/6/9/13/17/22/27 for 1–7+ qualifying hawks.",
			extHintFoxE: "Surrounded foxes",
			extRuleFoxE: "Each fox scores 4 if all six adjacent spaces contain wildlife, or 2 for four or five occupied spaces. Adjacent foxes count.",
			extHintFoxF: "Exactly two wildlife types",
			extRuleFoxF: "Each fox adjacent to exactly two wildlife types scores 3. Foxes count as a type; the number of adjacent animals is unrestricted.",
			extHintFoxG: "Adjacent habitat diversity",
			extRuleFoxG: "Each fox scores 1 per distinct habitat type on the touching edges of adjacent tiles. Its own tile habitats do not count.",
			extHintFoxKS: "Diverse neighbor counts",
			extRuleFoxKS: "Ignoring foxes, neighboring species counts of 1/2/3 score 1/2/2. Each quantity scores at most once, up to 5 per fox. Species with more than three neighbors do not score.",
			name: "Cascadia",
			desc: "Build hex habitats, house five kinds of wildlife",
			rules: "Goal: everyone takes exactly 20 turns; final scoring covers the 5 wildlife cards, the longest corridor of each of the 5 habitats, and leftover nature tokens — the highest total wins.\nEach turn:\n· Draft one of the 4 tile + token pairs from the middle.\n· Add the tile to your environment; it must touch an existing tile.\n· Place the token on a tile printed with that animal that holds neither wildlife nor a landmark; if you cannot or do not want to, return it to the bag.\nNature tokens:\n· Placing a token on a keystone tile printed with just one wildlife type (which may contain multiple habitats) earns 1 nature token.\n· Spending 1 nature token lets you mix any tile with any token, or wipe any number of displayed tokens for redraws.\n· When 3 displayed tokens match, you may wipe them free once per turn; 4 matching tokens are wiped automatically.\nFinal scoring:\n· Score the 5 wildlife scoring cards, the longest corridor of each habitat, and leftover nature tokens. The largest corridor of each habitat earns an additional bonus.\n· Ties break on nature tokens; a further tie shares the victory.\nLandmarks (optional):\n· Before play, choose and place an extra keystone tile in reverse player order. Each habitat has public landmark cards equal to player count.\n· If the tile you just placed belongs to a corridor of at least five tiles, you may place a matching landmark on it.\n· Claim a matching public card when placing a landmark, or skip the landmark. Each player may claim each type once.\n· Landmark tiles cannot hold wildlife. Placing a landmark earns no nature token. Your drafted wildlife may still go on another legal tile.\n· Score each landmark card as described. Cards I/J alter habitat corridor points and majority bonuses.\nExpansion options:\n· Expansion tiles work independently and support two to six players.\n· Random wildlife cards may include E–G, Kickstarter and Ecosystem Connections separately.\n· The landmark promo option contains Forest P2/P3 and Wetland P1.",
			roundShort: "Turn {{n}}/{{total}}",
			stageDraft: "Pick a tile + token pair",
			stageTile: "Place the habitat tile",
			stageToken: "Place the token, or return it",
			waitTurn: "Waiting for {{name}}…",
			watchHint: "Action buttons appear here on your turn",
			natureAria: "{{n}} nature tokens",
			playerAria: "View {{name}}’s board: {{nature}} nature tokens, estimated total {{score}} points",
			playerPoints: "pt",
			tileAria: "Tile {{n}}",
			pickConfirm: "Take",
			pickMixed: "Mix 🌲−1",
			wipe3: "Wipe 3 alike",
			wipeTokens: "🌲 Wipe",
			wipeTokensConfirm: "Wipe {{n}} 🌲−1",
			wipeCancel: "Cancel",
			rotate: "Rotate",
			placeTileConfirm: "Place here",
			placeTokenConfirm: "Place {{animal}}",
			skipToken: "Return to bag",
			cardsFamily: "Family card",
			cardsIntermediate: "Intermediate card",
			cardsFamilyMark: "F",
			cardsIntermediateMark: "I",
			animalB: "bear",
			animalE: "elk",
			animalS: "salmon",
			animalH: "hawk",
			animalF: "fox",
			habitatM: "Mountain",
			habitatF: "Forest",
			habitatP: "Prairie",
			habitatW: "Wetland",
			habitatR: "River",
			scoreBonus: "Corridor majority",
			scoreNature: "Nature tokens",
			cardScoreNow: "now {{n}} pts",
			scoreCardAria: "{{animal}} card {{card}}, now {{n}} points; open diagram",
			scoreHintBearA: "Exact pairs",
			scoreHintBearB: "Three bears",
			scoreHintBearC: "Sizes 1–3",
			scoreHintBearD: "Groups 2–4",
			scoreHintElkA: "Straight line",
			scoreHintElkB: "Four shapes",
			scoreHintElkC: "Herd size",
			scoreHintElkD: "Elk ring",
			scoreHintSalmonA: "Salmon run",
			scoreHintSalmonB: "Salmon run",
			scoreHintSalmonC: "Runs of 3+",
			scoreHintSalmonD: "Run + animals",
			scoreHintHawkA: "Separate",
			scoreHintHawkB: "Line of sight",
			scoreHintHawkC: "Visible pairs",
			scoreHintHawkD: "Between",
			scoreHintFoxA: "Variety",
			scoreHintFoxB: "Pairs nearby",
			scoreHintFoxC: "Most nearby",
			scoreHintFoxD: "Fox pair",
			scoreHintFamily: "Connected groups",
			scoreHintIntermediate: "Groups of 2+",
			scoreMetricPairs: "Bear pairs",
			scoreMetricGroupSize: "Group size",
			scoreMetricLineLength: "Line length",
			scoreMetricShape: "Shape size",
			scoreMetricRingSize: "Elk in ring",
			scoreMetricRunLength: "Run length",
			scoreMetricHawks: "Qualifying hawks",
			scoreMetricSightPairs: "Visible pairs",
			scoreMetricBetweenKinds: "Animal types between",
			scoreMetricNeighborKinds: "Neighbor types",
			scoreMetricNeighborPairs: "Neighbor pairs",
			scoreMetricNeighborMax: "Largest neighbor group",
			scoreMetricPoints: "Points",
			scoreFormulaSalmonD: "Each run of at least 3 scores 1 point per salmon, plus 1 per adjacent animal token.",
			scoreFormulaHawkC: "Each pair of hawks with line of sight scores 3 points; adjacent hawks also count.",
			scoreFormulaFoxC: "For each fox, count the most numerous other animal type around it; that count is its score.",
			cardBearA: "Each pair of bears (exactly 2 connected) scores: 1/2/3/4+ pairs → 4/11/19/27; groups of 3+ connected bears score nothing",
			cardBearB: "Each group of exactly 3 connected bears scores 10",
			cardBearC: "Each bear group scores by size: 1/2/3 bears → 2/5/8; +3 more if you have all three sizes",
			cardBearD: "Each bear group scores by size: 2/3/4 bears → 5/8/13",
			cardSalmonA: "Each connected salmon run scores by length: 1–7+ → 2/5/8/12/16/20/25; salmon adjacent to 3+ other salmon are excluded",
			cardSalmonB: "Each connected salmon run: 1–5+ → 2/4/9/11/17; salmon adjacent to 3+ other salmon are excluded",
			cardSalmonC: "Each connected salmon run: 3/4/5+ → 10/12/15; salmon adjacent to 3+ other salmon are excluded",
			cardSalmonD: "Each run of 3+ salmon: 1 per salmon in the run, plus 1 per animal token adjacent to the run; salmon adjacent to 3+ other salmon are excluded",
			cardElkA: "Elk score in straight lines: 1/2/3/4 → 2/5/9/13; each elk joins only one line, the best split is taken automatically",
			cardElkB: "Elk score by shape: single 2, line pair 5, triangle 9, diamond 13; each elk joins one shape, the best split is taken automatically",
			cardElkC: "Each connected elk group: 1–8+ → 2/4/7/10/14/18/23/28",
			cardElkD: "Ring in the 6 hexes around a center space: 1–6 elk → 2/5/8/12/16/21, gaps allowed and the center may contain anything; each elk joins one ring, the best split is taken automatically",
			cardHawkA: "Hawks not adjacent to each other: 1–8+ → 2/5/8/11/14/18/22/26",
			cardHawkB: "Hawks not adjacent to each other with line of sight (same line, no hawk between): 2–8 → 5/9/12/16/20/24/28",
			cardHawkC: "Each pair of hawks with line of sight (adjacent counts) scores 3",
			cardHawkD: "Each hawk pair with line of sight scores by animal variety strictly between them: 1/2/3+ → 4/7/9; each hawk joins one pair, the best match is taken automatically",
			cardFoxA: "Each fox scores by animal variety around it (including itself): 1–5 → 1–5",
			cardFoxB: "Each fox scores by other animal types with 2+ around it: 1/2/3 types → 3/5/7",
			cardFoxC: "Each fox scores the count of the most numerous other animal type around it",
			cardFoxD: "Each adjacent fox pair scores by animal types with 2+ in the 8 hexes around them: 1–4 → 5/7/9/11; each fox joins one pair, the best match is taken automatically",
			cardFamily: "Each animal scores by connected group: 1/2/3+ → 2/5/9",
			cardIntermediate: "Each animal scores by connected group: 2/3/4+ → 5/8/12; singles score nothing",
			optCards: "Scoring cards",
			optRandom: "Random",
			optRandomHint: "Draw one card per animal from the selected pools",
			optA: "All A",
			optAHint: "First game: every animal uses card A",
			optFamily: "Family",
			optFamilyHint: "Variant: groups of 1/2/3+ → 2/5/9",
			optIntermediate: "Intermediate",
			optIntermediateHint: "Variant: groups of 2/3/4+ → 5/8/12",
			errNotYourTurn: "Not your turn yet",
			errWipeUsed: "Already wiped this turn",
			errNoThree: "No token appears exactly 3 times",
			errNoNature: "Not enough nature tokens",
			errBadTile: "Tiles must touch your existing tiles",
			errBadToken: "That tile cannot hold this token",
			hintPick: "Take pair {{n}} (tile + {{animal}})",
			hintPickMixed: "Mix: tile {{tile}} + token {{token}} ({{animal}}), 🌲−1"
		}
	}
};
//#endregion
export { gr as default };
