import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { useT as i } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as a } from "@bgparty/sdk/player-colors";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { Fragment as s, jsx as c, jsxs as l } from "react/jsx-runtime";
import { Floater as u, FlySprite as d, PulseBox as f } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as p } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as m, OptionSection as h } from "@bgparty/sdk/ui/game-options";
//#region src/games/wizard/meta.ts
var g = {
	id: "wizard",
	tier: "beta",
	mechanics: ["trick-taking"],
	interactionTags: [],
	nameKey: "games.wizard.name",
	descKey: "games.wizard.desc",
	rulesKey: "games.wizard.rules",
	icon: "🧙",
	iconImg: "games/wizard.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/wizard/en.pdf" },
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [4, 5],
	accent: "#e1c064",
	releasedAt: "2026-09-16",
	search: {
		py: "wu shi pai",
		init: "wsp"
	},
	hotseat: "cover"
}, _ = t.enum([
	"yellow",
	"red",
	"green",
	"blue"
]), v = t.object({
	s: t.enum([
		"yellow",
		"red",
		"green",
		"blue",
		"wizard",
		"jester"
	]),
	v: t.int().min(1).max(13)
}), y = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("bid"),
		n: t.int().min(0).max(20)
	}),
	t.object({
		type: t.literal("pickTrump"),
		suit: _
	}),
	t.object({
		type: t.literal("play"),
		card: v
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), b = t.object({ length: t.enum(["full", "quick"]).catch("full") }).default({ length: "full" }), x = t.string(), S = t.array(t.object({
	rid: x,
	card: v
})), C = t.object({
	bid: t.int().nonnegative(),
	won: t.int().nonnegative(),
	delta: t.int()
}), w = t.object({
	round: t.int().min(1),
	entries: t.record(x, C)
}), T = t.object({
	phase: t.enum([
		"trump",
		"bid",
		"play",
		"roundEnd",
		"done"
	]),
	round: t.int().min(1),
	totalRounds: t.int().min(1),
	dealer: x,
	trump: _.nullable(),
	flipped: v.nullable(),
	actor: x.nullable(),
	players: t.array(t.object({
		rid: x,
		handCount: t.int().nonnegative(),
		bid: t.int().nonnegative().nullable(),
		tricksWon: t.int().nonnegative(),
		score: t.int()
	})),
	forbiddenBid: t.int().nonnegative().nullable(),
	trick: t.object({
		leader: x,
		plays: S
	}),
	lastTrick: t.object({
		plays: S,
		winner: x
	}).nullable(),
	roundDelta: t.record(x, t.int()).nullable(),
	history: t.array(w)
}), ee = t.object({
	hand: t.array(v),
	mustFollow: _.nullable()
}), E = [
	"yellow",
	"red",
	"green",
	"blue"
], D = 2600, O = (e) => e.s !== "wizard" && e.s !== "jester";
function te() {
	let e = [];
	for (let t of E) for (let n = 1; n <= 13; n += 1) e.push({
		s: t,
		v: n
	});
	for (let t = 1; t <= 4; t += 1) e.push({
		s: "wizard",
		v: t
	}, {
		s: "jester",
		v: t
	});
	return e;
}
function k(e, t) {
	let n = Math.floor(60 / t);
	return e.length === "quick" ? Math.ceil(n / 2) : n;
}
function A(e) {
	let t = e.find((e) => O(e.card));
	return t ? t.card.s : null;
}
function j(e, t) {
	let n = e.find((e) => e.card.s === "wizard");
	if (n) return n.rid;
	if (t) {
		let n = e.filter((e) => e.card.s === t);
		if (n.length > 0) return n.reduce((e, t) => t.card.v > e.card.v ? t : e).rid;
	}
	let r = A(e);
	return r ? e.filter((e) => e.card.s === r).reduce((e, t) => t.card.v > e.card.v ? t : e).rid : e[0].rid;
}
function ne(e) {
	let t = e.players.length;
	return Array.from({ length: t }, (n, r) => e.players[(e.dealerIdx + 1 + r) % t]);
}
function M(e) {
	return ne(e)[Object.keys(e.bids).length];
}
function N(e) {
	if (e.phase !== "bid" || M(e) !== e.players[e.dealerIdx]) return null;
	let t = Object.values(e.bids).reduce((e, t) => e + t, 0), n = e.round - t;
	return n >= 0 ? n : null;
}
function re(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function P(e) {
	let t = e.players.map((t, n) => ({
		kind: "deal",
		rid: t,
		data: { count: e.hands[t].length },
		for: [t],
		secret: { cards: e.hands[t] },
		...n > 0 ? { with: !0 } : {}
	}));
	return e.flipped && t.push({
		kind: "flip",
		data: { card: e.flipped },
		with: !0
	}), t;
}
function F(e) {
	let t = e.players.length, n = re(e, te());
	e.hands = {}, e.players.forEach((t, r) => {
		e.hands[t] = n.slice(r * e.round, (r + 1) * e.round);
	});
	let r = n.slice(t * e.round);
	e.flipped = r.length > 0 ? r[0] : null, e.trump = null, e.bids = {}, e.tricks = [], e.lastTrick = null, e.roundDelta = null;
	let i = e.players[(e.dealerIdx + 1) % t];
	e.trick = {
		leader: i,
		plays: []
	}, e.turn = i, e.flipped && e.flipped.s === "wizard" ? e.phase = "trump" : (e.trump = e.flipped && O(e.flipped) ? e.flipped.s : null, e.phase = "bid");
}
function I(e) {
	let t = {}, n = {};
	for (let r of e.players) {
		let i = e.tricks.filter((e) => e.winner === r).length, a = e.bids[r] ?? 0, o = a === i ? 20 + 10 * i : -10 * Math.abs(a - i);
		e.scores[r] += o, t[r] = {
			bid: a,
			won: i,
			delta: o
		}, n[r] = o;
	}
	return e.history.push({
		round: e.round,
		entries: t
	}), e.roundDelta = n, e.phase = "roundEnd", e.beatMs = D, e.players.map((e, t) => ({
		kind: "roundScore",
		rid: e,
		data: { delta: n[e] },
		...t > 0 ? { with: !0 } : {}
	}));
}
var L = (e) => ({ code: e }), R = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: g,
	schemas: {
		action: y,
		publicView: T,
		privateView: ee,
		config: b
	},
	setup(e, t, n) {
		let r = {
			phase: "bid",
			seed: n,
			rngCursor: 0,
			players: [...t],
			dealerIdx: 0,
			round: 1,
			totalRounds: k(e, t.length),
			hands: {},
			trump: null,
			flipped: null,
			bids: {},
			tricks: [],
			trick: {
				leader: t[1 % t.length],
				plays: []
			},
			turn: t[1 % t.length],
			scores: Object.fromEntries(t.map((e) => [e, 0])),
			history: [],
			roundDelta: null,
			lastTrick: null,
			beatMs: 0
		};
		return F(r), {
			state: r,
			fx: P(r)
		};
	},
	reduce(e, t, { by: n }) {
		let r = structuredClone(e);
		switch (t.type) {
			case "tick": return r.phase === "roundEnd" ? r.round >= r.totalRounds ? (r.phase = "done", { state: r }) : (r.round += 1, r.dealerIdx = (r.dealerIdx + 1) % r.players.length, F(r), {
				state: r,
				fx: P(r)
			}) : { state: r };
			case "pickTrump": return r.phase === "trump" ? n === r.players[r.dealerIdx] ? (r.trump = t.suit, r.phase = "bid", {
				state: r,
				fx: [{
					kind: "trumpPick",
					rid: n,
					data: { suit: t.suit }
				}]
			}) : L("games.wizard.errTurn") : L("games.wizard.errPhase");
			case "bid": {
				if (r.phase !== "bid") return L("games.wizard.errPhase");
				if (n !== M(r)) return L("games.wizard.errTurn");
				if (t.n > r.round) return L("games.wizard.errBid");
				let e = N(r);
				if (e !== null && t.n === e) return L("games.wizard.errBidForbidden");
				r.bids[n] = t.n;
				let i = [{
					kind: "bid",
					rid: n,
					data: { n: t.n }
				}];
				return Object.keys(r.bids).length === r.players.length && (r.phase = "play"), {
					state: r,
					fx: i
				};
			}
			case "play": {
				if (r.phase !== "play") return L("games.wizard.errPhase");
				if (r.turn !== n) return L("games.wizard.errTurn");
				let e = r.hands[n], i = e.findIndex((e) => e.s === t.card.s && e.v === t.card.v);
				if (i < 0) return L("games.wizard.errCard");
				let a = A(r.trick.plays);
				if (a && O(t.card) && t.card.s !== a && e.some((e) => e.s === a)) return L("games.wizard.errFollow");
				e.splice(i, 1), r.trick.plays.push({
					rid: n,
					card: t.card
				});
				let o = [{
					kind: "play",
					rid: n,
					data: {
						card: t.card,
						index: r.trick.plays.length - 1
					}
				}];
				if (r.trick.plays.length < r.players.length) r.turn = r.players[(r.players.indexOf(n) + 1) % r.players.length];
				else {
					let e = j(r.trick.plays, r.trump), t = {
						plays: [...r.trick.plays],
						winner: e
					};
					r.tricks.push(t), r.lastTrick = t, o.push({
						kind: "gather",
						rid: e,
						data: { count: r.players.length }
					}), r.trick = {
						leader: e,
						plays: []
					}, r.turn = e, r.tricks.length >= r.round && o.push(...I(r));
				}
				return {
					state: r,
					fx: o
				};
			}
		}
	},
	viewFor(e, t) {
		let n = e.hands[t] ?? [], r = e.phase === "play" && e.turn === t ? A(e.trick.plays) : null, i = r !== null && n.some((e) => e.s === r) ? r : null, a = (e) => e.s === "wizard" ? 4 : e.s === "jester" ? 5 : E.indexOf(e.s), o = e.phase === "bid" ? M(e) : e.phase === "play" ? e.turn : e.phase === "trump" ? e.players[e.dealerIdx] : null;
		return {
			public: {
				phase: e.phase,
				round: e.round,
				totalRounds: e.totalRounds,
				dealer: e.players[e.dealerIdx],
				trump: e.trump,
				flipped: e.flipped,
				actor: o,
				players: e.players.map((t) => ({
					rid: t,
					handCount: e.hands[t]?.length ?? 0,
					bid: e.bids[t] ?? null,
					tricksWon: e.tricks.filter((e) => e.winner === t).length,
					score: e.scores[t] ?? 0
				})),
				forbiddenBid: N(e),
				trick: {
					leader: e.trick.leader,
					plays: e.trick.plays.map((e) => ({
						rid: e.rid,
						card: e.card
					}))
				},
				lastTrick: e.lastTrick ? {
					plays: e.lastTrick.plays.map((e) => ({
						rid: e.rid,
						card: e.card
					})),
					winner: e.lastTrick.winner
				} : null,
				roundDelta: e.roundDelta,
				history: e.history.map((e) => ({
					round: e.round,
					entries: e.entries
				}))
			},
			private: {
				hand: [...n].sort((e, t) => a(e) - a(t) || e.v - t.v),
				mustFollow: i
			}
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]), n = e.scores[t[0]];
		return {
			phase: "done",
			winner: t.filter((t) => e.scores[t] === n),
			ranking: t,
			scores: { ...e.scores }
		};
	},
	nextTickIn(e) {
		return e.phase === "roundEnd" ? e.beatMs : null;
	}
}, z = [
	"yellow",
	"red",
	"green",
	"blue"
], ie = {
	yellow: { className: "wz-yellow" },
	red: { className: "wz-red" },
	green: { className: "wz-green" },
	blue: { className: "wz-blue" }
};
function B(e) {
	return `games.wizard.suit.${e}`;
}
var V = (e) => `${e.s}-${e.v}`;
function ae(e) {
	return e.s === "wizard" ? "games.wizard.cardWizard" : e.s === "jester" ? "games.wizard.cardJester" : null;
}
function H({ suit: e, className: t = "" }) {
	let n = {
		yellow: /* @__PURE__ */ l(s, { children: [
			/* @__PURE__ */ c("path", { d: "M10 2 16 4 20 10 18 17 12 21 5 18 2 11 5 5Z" }),
			/* @__PURE__ */ c("path", { d: "M9 8 14 8 16 13 11 16 7 13Z" }),
			/* @__PURE__ */ c("path", { d: "m10 21-2 3m5-3 2 3" })
		] }),
		red: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M11 23 13 1M13 3l7 4-2 5-5 1M12 7 4 10l3 5 5 1M6 21l13-1" }) }),
		green: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M4 22 10 2l5 6 6-7M8 12 1 9m8 5 10 5m-6-12 6 1" }) }),
		blue: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M12 1 9 23M4 8l8-5 9 5M2 19l8-6 10 6" }) })
	};
	return /* @__PURE__ */ c("svg", {
		"aria-hidden": "true",
		viewBox: "0 0 24 25",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.8",
		strokeLinecap: "square",
		strokeLinejoin: "bevel",
		className: `wz-rune ${ie[e].className} ${t}`,
		children: n[e]
	});
}
function U({ card: e, size: t, dimmed: n, style: r }) {
	let a = i(), o = ae(e), u = o ? a(o) : `${a(B(e.s))} ${e.v}`, d = e.s === "wizard" || e.s === "jester", f = d ? null : e.s;
	return /* @__PURE__ */ c("span", {
		"aria-label": u,
		style: r,
		className: `wz-card wz-card--${t} ${d ? "wz-card--portrait" : `wz-card--${f}`} ${n ? "wz-card--dimmed" : ""}`,
		children: d ? /* @__PURE__ */ l(s, { children: [
			/* @__PURE__ */ c("img", {
				className: "wz-card-art",
				src: `games/wizard/${e.s}-${e.v}.webp`,
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ c("span", {
				"aria-hidden": "true",
				className: "wz-card-index wz-card-index--special",
				children: e.s === "wizard" ? "W" : "J"
			}),
			/* @__PURE__ */ c("span", {
				"aria-hidden": "true",
				className: "wz-card-special-name",
				children: o ? a(o) : ""
			})
		] }) : f && /* @__PURE__ */ l(s, { children: [
			/* @__PURE__ */ l("span", {
				"aria-hidden": "true",
				className: "wz-card-index",
				children: [/* @__PURE__ */ c("span", { children: e.v }), /* @__PURE__ */ c(H, { suit: f })]
			}),
			/* @__PURE__ */ c(H, {
				suit: f,
				className: "wz-card-emblem"
			}),
			/* @__PURE__ */ c("span", {
				"aria-hidden": "true",
				className: "wz-card-scratch"
			})
		] })
	});
}
function W({ accent: e, style: t }) {
	return /* @__PURE__ */ c("span", {
		className: "wz-card-back",
		style: {
			...t,
			borderColor: e
		},
		children: /* @__PURE__ */ c("span", {
			className: "wz-card-back-mark",
			children: "✥"
		})
	});
}
//#endregion
//#region src/games/wizard/view-player.tsx
function oe(e) {
	return /* @__PURE__ */ c(se, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var G = (e) => e.s !== "wizard" && e.s !== "jester";
function se({ pub: e, priv: t, members: u, myRid: d, send: f }) {
	let p = i(), m = (e) => u.find((t) => t.rid === e)?.name ?? e, h = (e) => {
		let t = u.find((t) => t.rid === e);
		return t ? a[t.colorIndex % a.length].hex : void 0;
	}, { ref: g } = r("table"), { ref: _ } = r("trick"), v = t?.hand ?? [], y = e.phase === "play" && e.actor === d, b = e.phase === "bid" && e.actor === d, x = e.phase === "trump" && e.actor === d, [S, C] = n(null), [w, T] = n(null), [ee, E] = n(!1), D = `${e.phase}|${e.round}|${e.actor}|${v.length}|${e.trick.plays.length}`, [O, te] = n(D);
	O !== D && (te(D), C(null), T(null));
	let k = (e) => y && (!t?.mustFollow || !G(e) || e.s === t.mustFollow), A = (e) => {
		k(e) && C(S && V(S) === V(e) ? null : e);
	}, j = (e) => {
		let t = ae(e);
		return t ? p(t) : `${p(B(e.s))} ${e.v}`;
	}, ne = e.phase === "trump" ? x ? p("games.wizard.trumpPrompt") : p("games.wizard.trumpWaiting", { name: m(e.dealer) }) : e.phase === "bid" ? b ? p("games.wizard.bidPrompt") : p("games.wizard.bidWaiting", { name: m(e.actor ?? "") }) : e.phase === "play" ? y ? p("games.wizard.turnYou") : p("games.wizard.turnWait", { name: m(e.actor ?? "") }) : e.phase === "roundEnd" ? p("games.wizard.roundEnd") : p("games.wizard.done"), M = e.phase === "play" ? y ? t?.mustFollow ? p("games.wizard.handFollow", { suit: p(B(t.mustFollow)) }) : p("games.wizard.handPlayHint") : p("games.wizard.handWaitingTurn") : e.phase === "trump" || e.phase === "bid" ? p("games.wizard.handWait") : "", N = e.players.reduce((e, t) => e + t.tricksWon, 0) + 1, re = e.phase === "trump" ? p("games.wizard.trumpFlippedWizard") : e.phase === "play" ? p("games.wizard.trickChip", {
		n: N,
		total: e.round
	}) : e.phase === "roundEnd" ? p("games.wizard.nextRoundSoon") : e.phase === "done" ? p("games.wizard.resultTitle") : p("games.wizard.phaseSub"), P = Math.max(0, e.players.findIndex((t) => t.rid === e.trick.leader)), F = e.players.map((t, n) => e.players[(P + n) % e.players.length]), I = e.trick.plays.find((e) => G(e.card))?.card.s, L = /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ l("div", {
		className: "wz-header",
		children: [/* @__PURE__ */ c("span", {
			className: "wz-round-chip",
			children: p("games.wizard.roundChip", {
				n: e.round,
				total: e.totalRounds
			})
		}), /* @__PURE__ */ l("span", {
			className: "wz-phase-copy",
			children: [/* @__PURE__ */ c("strong", { children: ne }), /* @__PURE__ */ c("small", { children: re })]
		})]
	}), /* @__PURE__ */ c("div", {
		className: "wz-seats",
		children: e.players.map((t) => {
			let n = u.find((e) => e.rid === t.rid);
			if (!n) return null;
			let r = (e.phase === "trump" ? e.dealer : e.actor) === t.rid && e.phase !== "roundEnd" && e.phase !== "done", i = e.roundDelta?.[t.rid];
			return /* @__PURE__ */ l("div", {
				className: `wz-seat ${r ? "wz-seat--active" : ""} ${n.online ? "" : "wz-seat--offline"}`,
				children: [
					/* @__PURE__ */ c(de, {
						rid: t.rid,
						name: m(t.rid),
						color: h(t.rid)
					}),
					/* @__PURE__ */ l("div", {
						className: "wz-seat-copy",
						children: [/* @__PURE__ */ l("div", {
							className: "wz-seat-name",
							children: [/* @__PURE__ */ c("span", { children: m(t.rid) }), t.rid === e.dealer && /* @__PURE__ */ c("b", {
								title: p("games.wizard.dealerAria"),
								children: "D"
							})]
						}), /* @__PURE__ */ l("strong", {
							"aria-label": p("games.wizard.scoreAria", { n: t.score }),
							children: [
								t.score,
								" ",
								/* @__PURE__ */ c("small", { children: p("games.wizard.points") })
							]
						})]
					}),
					/* @__PURE__ */ c("span", {
						className: "wz-seat-bid",
						"aria-label": t.bid === null ? p("games.wizard.bidPending") : p("games.wizard.bidAria", {
							n: t.bid,
							won: t.tricksWon
						}),
						children: t.bid === null ? p("games.wizard.bidPending") : `${t.tricksWon}/${t.bid}`
					}),
					i !== void 0 && /* @__PURE__ */ c("span", {
						className: `wz-seat-delta ${i >= 0 ? "wz-seat-delta--plus" : ""}`,
						children: i >= 0 ? `+${i}` : i
					})
				]
			}, t.rid);
		})
	})] }), R = /* @__PURE__ */ l("div", {
		className: "wz-hand-tray",
		children: [/* @__PURE__ */ l("div", {
			className: "wz-hand-caption",
			children: [/* @__PURE__ */ c("strong", { children: p("games.wizard.handTitle") }), /* @__PURE__ */ c("span", { children: M })]
		}), t && (e.phase === "trump" || e.phase === "bid" || e.phase === "play") ? /* @__PURE__ */ c("div", {
			className: "wz-hand-scroll",
			children: /* @__PURE__ */ c("div", {
				className: "wz-hand-cards",
				children: v.map((e) => {
					let t = k(e), n = S !== null && V(S) === V(e);
					return /* @__PURE__ */ c("button", {
						type: "button",
						disabled: !t,
						onClick: () => A(e),
						"aria-label": j(e),
						"aria-pressed": n,
						className: `wz-hand-button ${n ? "wz-hand-button--selected" : ""} ${t ? "" : "wz-hand-button--inactive"}`,
						children: /* @__PURE__ */ c(ue, {
							card: e,
							raised: n,
							dimmed: y && !t
						})
					}, V(e));
				})
			})
		}) : /* @__PURE__ */ c("div", {
			className: "wz-hand-empty",
			children: p("games.wizard.roundEnd")
		})]
	});
	return /* @__PURE__ */ l("div", {
		className: "wz-root",
		children: [/* @__PURE__ */ c(o, {
			adaptive: !0,
			className: "wz-screen",
			banner: L,
			actions: R,
			actionsHeight: "wz-hand-slot",
			scroll: !1,
			children: /* @__PURE__ */ l("div", {
				ref: g,
				className: "wz-table",
				children: [/* @__PURE__ */ l("div", {
					className: "wz-table-head",
					children: [
						/* @__PURE__ */ c("div", {
							className: "wz-trump-card",
							children: e.flipped ? /* @__PURE__ */ c(U, {
								card: e.flipped,
								size: "mini"
							}) : /* @__PURE__ */ c("span", {
								className: "wz-trump-empty",
								children: "✥"
							})
						}),
						/* @__PURE__ */ l("div", {
							className: "wz-trump-copy",
							children: [/* @__PURE__ */ c("small", { children: p("games.wizard.trumpLabel") }), /* @__PURE__ */ c("strong", { children: e.trump ? /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c(H, { suit: e.trump }), p(B(e.trump))] }) : e.phase === "trump" ? p("games.wizard.trumpUndecided") : p("games.wizard.trumpNone") })]
						}),
						/* @__PURE__ */ l("div", {
							className: "wz-table-count",
							children: [/* @__PURE__ */ c("small", { children: e.phase === "play" ? p("games.wizard.trickCountLabel") : p("games.wizard.roundCountLabel") }), /* @__PURE__ */ c("strong", { children: e.phase === "play" ? `${N}/${e.round}` : e.round })]
						}),
						e.history.length > 0 && /* @__PURE__ */ c("button", {
							type: "button",
							className: "wz-score-trigger",
							onClick: () => E(!0),
							children: p("games.wizard.scoreboard")
						})
					]
				}), /* @__PURE__ */ l("div", {
					className: "wz-stone",
					children: [
						/* @__PURE__ */ l("svg", {
							"aria-hidden": "true",
							className: "wz-stone-etch",
							viewBox: "0 0 360 480",
							preserveAspectRatio: "none",
							fill: "none",
							stroke: "currentColor",
							children: [/* @__PURE__ */ c("path", {
								d: "M18 63 58 42 84 62 116 50m-49 0 10 24-15 16m271-50-38 21-24-8-28 21m46-8 10 26-14 19M34 174l21-22 30 11 15-18m-18 17 3 27-19 16m229-16-16-18-26 7-17-21m44 10 20 23-4 27M29 318l41 10 17-19 24 16m-40 5 12 22-8 18m237-46-30-19-23 19-25-12m57 13-8 29 21 9M55 422l30-24 24 9 14-19m164 9-30 17-22-15-15 18",
								strokeWidth: "1.5"
							}), /* @__PURE__ */ c("path", {
								d: "m134 44 6 12 16-4m113 62 12 5-4 15M20 250l19-6 10 13m84 75-8 17 11 11m163-118-15 12 7 13M188 30l15 7m-122 92 12 4m184 244-10 12m-160 55 18 7",
								strokeWidth: ".9"
							})]
						}),
						/* @__PURE__ */ c("div", {
							className: "wz-stone-runes",
							"aria-hidden": "true",
							children: z.map((e) => /* @__PURE__ */ c(H, { suit: e }, e))
						}),
						e.phase === "trump" && /* @__PURE__ */ l("div", {
							className: "wz-center-state",
							children: [
								/* @__PURE__ */ c("span", {
									className: "wz-state-icon",
									children: "✥"
								}),
								/* @__PURE__ */ c("h2", { children: p("games.wizard.trumpFlippedWizard") }),
								/* @__PURE__ */ c("p", { children: x ? p("games.wizard.trumpChooseHint") : p("games.wizard.trumpWaiting", { name: m(e.dealer) }) }),
								x && /* @__PURE__ */ c("div", {
									className: "wz-trump-choices",
									children: z.map((e) => /* @__PURE__ */ l("button", {
										type: "button",
										onClick: () => f({
											type: "pickTrump",
											suit: e
										}),
										className: "wz-trump-choice",
										children: [/* @__PURE__ */ c(H, { suit: e }), p(B(e))]
									}, e))
								})
							]
						}),
						e.phase === "bid" && /* @__PURE__ */ l("div", {
							className: "wz-center-state wz-center-state--bid",
							children: [
								/* @__PURE__ */ c("span", {
									className: "wz-eyebrow",
									children: p("games.wizard.bidEyebrow")
								}),
								/* @__PURE__ */ c("h2", { children: p("games.wizard.bidQuestion", { n: e.round }) }),
								/* @__PURE__ */ c("p", { children: b ? p("games.wizard.bidPickHint") : p("games.wizard.bidWaiting", { name: m(e.actor ?? "") }) }),
								b && /* @__PURE__ */ c("div", {
									className: "wz-bid-scroll",
									children: /* @__PURE__ */ c("div", {
										className: "wz-bid-chips",
										children: Array.from({ length: e.round + 1 }, (t, n) => {
											let r = e.forbiddenBid === n;
											return /* @__PURE__ */ c("button", {
												type: "button",
												disabled: r,
												"aria-pressed": w === n,
												onClick: () => T(w === n ? null : n),
												className: `wz-bid-chip ${w === n ? "wz-bid-chip--selected" : ""} ${r ? "wz-bid-chip--forbidden" : ""}`,
												children: n
											}, n);
										})
									})
								}),
								b && e.dealer === d && e.forbiddenBid !== null && /* @__PURE__ */ c("div", {
									className: "wz-bid-forbidden",
									children: p("games.wizard.bidForbiddenHint", { n: e.forbiddenBid })
								}),
								b && w !== null && /* @__PURE__ */ l("div", {
									className: "wz-board-action",
									children: [/* @__PURE__ */ l("div", { children: [/* @__PURE__ */ c("small", { children: p("games.wizard.chosenBid") }), /* @__PURE__ */ c("strong", { children: p("games.wizard.bidConfirm", { n: w }) })] }), /* @__PURE__ */ c("button", {
										type: "button",
										className: "wz-primary",
										onClick: () => {
											f({
												type: "bid",
												n: w
											}), T(null);
										},
										children: p("games.wizard.bidSend")
									})]
								})
							]
						}),
						e.phase === "play" && /* @__PURE__ */ l("div", {
							className: "wz-play-state",
							children: [
								/* @__PURE__ */ l("div", {
									className: "wz-trick-heading",
									children: [/* @__PURE__ */ c("span", { children: p("games.wizard.trickChip", {
										n: N,
										total: e.round
									}) }), /* @__PURE__ */ c("span", { children: I ? /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c(H, { suit: I }), p("games.wizard.leadSuit", { suit: p(B(I)) })] }) : p("games.wizard.trickLead", { name: m(e.trick.leader) }) })]
								}),
								/* @__PURE__ */ c("div", {
									ref: _,
									className: "wz-trick-grid",
									style: { gridTemplateColumns: `repeat(${F.length}, minmax(0, 1fr))` },
									children: F.map((t, n) => /* @__PURE__ */ c(ce, {
										index: n,
										name: m(t.rid),
										card: e.trick.plays[n]?.card,
										preview: n === e.trick.plays.length ? S : null,
										active: n === e.trick.plays.length && e.actor === t.rid
									}, t.rid))
								}),
								e.lastTrick && /* @__PURE__ */ l("div", {
									className: "wz-last-trick",
									children: [/* @__PURE__ */ c("span", { children: p("games.wizard.lastTrick", { name: m(e.lastTrick.winner) }) }), /* @__PURE__ */ c("span", {
										className: "wz-last-cards",
										children: e.lastTrick.plays.map((e, t) => /* @__PURE__ */ c(U, {
											card: e.card,
											size: "mini"
										}, `${e.rid}-${t}`))
									})]
								}),
								S && y && /* @__PURE__ */ l("div", {
									className: "wz-board-action wz-board-action--play",
									children: [
										/* @__PURE__ */ l("div", { children: [/* @__PURE__ */ c("small", { children: p("games.wizard.chosenCard") }), /* @__PURE__ */ c("strong", { children: j(S) })] }),
										/* @__PURE__ */ c("button", {
											type: "button",
											className: "wz-cancel",
											onClick: () => C(null),
											children: p("games.wizard.cancel")
										}),
										/* @__PURE__ */ c("button", {
											type: "button",
											className: "wz-primary",
											onClick: () => {
												f({
													type: "play",
													card: S
												}), C(null);
											},
											children: p("games.wizard.playCard")
										})
									]
								})
							]
						}),
						(e.phase === "roundEnd" || e.phase === "done") && /* @__PURE__ */ c(fe, { count: e.players.length }),
						(e.phase === "roundEnd" || e.phase === "done") && /* @__PURE__ */ l("div", {
							className: "wz-results",
							children: [
								/* @__PURE__ */ c("span", {
									className: "wz-eyebrow",
									children: e.phase === "done" ? p("games.wizard.done") : p("games.wizard.roundEnd")
								}),
								/* @__PURE__ */ c("h2", { children: p("games.wizard.resultTitle") }),
								/* @__PURE__ */ c("div", {
									className: "wz-result-list",
									children: e.players.map((t) => {
										let n = e.roundDelta?.[t.rid] ?? 0;
										return /* @__PURE__ */ l("div", {
											className: "wz-result-row",
											children: [
												/* @__PURE__ */ c("span", {
													className: "wz-result-name",
													style: { borderColor: h(t.rid) },
													children: m(t.rid)
												}),
												/* @__PURE__ */ c("span", { children: p("games.wizard.bidVsWon", {
													bid: t.bid ?? 0,
													won: t.tricksWon
												}) }),
												/* @__PURE__ */ c("strong", {
													className: n >= 0 ? "wz-positive" : "wz-negative",
													children: n >= 0 ? `+${n}` : n
												}),
												/* @__PURE__ */ c("b", { children: t.score })
											]
										}, t.rid);
									})
								}),
								e.phase === "roundEnd" && /* @__PURE__ */ c("p", { children: p("games.wizard.nextRoundSoon") })
							]
						})
					]
				})]
			})
		}), ee && /* @__PURE__ */ l("div", {
			className: "wz-modal",
			children: [/* @__PURE__ */ c("button", {
				type: "button",
				"aria-label": p("games.wizard.close"),
				className: "wz-modal-backdrop",
				onClick: () => E(!1)
			}), /* @__PURE__ */ l("div", {
				className: "wz-score-sheet",
				children: [/* @__PURE__ */ l("div", {
					className: "wz-score-title",
					children: [/* @__PURE__ */ c("strong", { children: p("games.wizard.scoreboard") }), /* @__PURE__ */ c("button", {
						type: "button",
						onClick: () => E(!1),
						children: p("games.wizard.close")
					})]
				}), /* @__PURE__ */ c("div", {
					className: "wz-score-scroll",
					children: /* @__PURE__ */ l("table", { children: [/* @__PURE__ */ c("thead", { children: /* @__PURE__ */ l("tr", { children: [/* @__PURE__ */ c("th", { children: "#" }), e.players.map((e) => /* @__PURE__ */ c("th", { children: m(e.rid) }, e.rid))] }) }), /* @__PURE__ */ l("tbody", { children: [e.history.map((t) => /* @__PURE__ */ l("tr", { children: [/* @__PURE__ */ c("th", { children: t.round }), e.players.map((e) => {
						let n = t.entries[e.rid];
						return /* @__PURE__ */ c("td", { children: n ? p("games.wizard.scoreCell", {
							bid: n.bid,
							won: n.won,
							delta: n.delta >= 0 ? `+${n.delta}` : `${n.delta}`
						}) : "·" }, e.rid);
					})] }, t.round)), /* @__PURE__ */ l("tr", {
						className: "wz-score-total",
						children: [/* @__PURE__ */ c("th", { children: "★" }), e.players.map((e) => /* @__PURE__ */ c("td", { children: e.score }, e.rid))]
					})] })] })
				})]
			})]
		})]
	});
}
function ce({ index: e, name: t, card: n, preview: i, active: a }) {
	let { ref: o } = r(`tslot:${e}`);
	return /* @__PURE__ */ l("div", {
		className: `wz-trick-slot ${a ? "wz-trick-slot--active" : ""} ${i ? "wz-trick-slot--preview" : ""}`,
		children: [/* @__PURE__ */ c("div", {
			className: "wz-trick-card-area",
			children: /* @__PURE__ */ c("span", {
				ref: o,
				className: "wz-slot-card-box",
				children: n ? /* @__PURE__ */ c(le, {
					index: e,
					card: n
				}) : i ? /* @__PURE__ */ c("span", {
					className: "wz-preview-card",
					children: /* @__PURE__ */ c(U, {
						card: i,
						size: "table"
					})
				}) : /* @__PURE__ */ c("span", {
					"aria-hidden": "true",
					className: "wz-slot-mark",
					children: "✦"
				})
			})
		}), /* @__PURE__ */ c("span", {
			className: "wz-slot-name",
			children: t
		})]
	});
}
function le({ index: e, card: t }) {
	let { ref: n, hidden: i } = r(`tcard:${e}`);
	return /* @__PURE__ */ c("span", {
		ref: n,
		className: "wz-anchored-card",
		style: { visibility: i ? "hidden" : void 0 },
		children: /* @__PURE__ */ c(U, {
			card: t,
			size: "table"
		})
	});
}
function ue({ card: e, raised: t, dimmed: n }) {
	let { ref: i, hidden: a } = r(`hand:${V(e)}`);
	return /* @__PURE__ */ c("span", {
		ref: i,
		className: `wz-anchored-card ${t ? "wz-hand-raised" : ""}`,
		style: { visibility: a ? "hidden" : void 0 },
		children: /* @__PURE__ */ c(U, {
			card: e,
			size: "hand",
			dimmed: n
		})
	});
}
function de({ rid: e, name: t, color: n }) {
	let { ref: i } = r(`seat:${e}`);
	return /* @__PURE__ */ c("span", {
		ref: i,
		className: "wz-seat-marker",
		style: { backgroundColor: n },
		"aria-label": t,
		children: t.slice(0, 1)
	});
}
function fe({ count: e }) {
	let { ref: t } = r("trick");
	return /* @__PURE__ */ c("div", {
		ref: t,
		"aria-hidden": "true",
		className: "wz-result-trick-anchors",
		style: { gridTemplateColumns: `repeat(${e}, minmax(0, 1fr))` },
		children: Array.from({ length: e }, (e, t) => /* @__PURE__ */ c(pe, { index: t }, t))
	});
}
function pe({ index: e }) {
	let { ref: t } = r(`tslot:${e}`);
	return /* @__PURE__ */ c("span", {
		ref: t,
		className: "wz-slot-card-box"
	});
}
//#endregion
//#region src/games/wizard/bot.ts
var K = (e) => e.s !== "wizard" && e.s !== "jester", q = [
	"yellow",
	"red",
	"green",
	"blue"
], J = (e, t) => e.s === t.s && e.v === t.v;
function Y() {
	let e = [];
	for (let t of q) for (let n = 1; n <= 13; n += 1) e.push({
		s: t,
		v: n
	});
	for (let t = 1; t <= 4; t += 1) e.push({
		s: "wizard",
		v: t
	}, {
		s: "jester",
		v: t
	});
	return e;
}
function me(e, t) {
	let n = .85 * e.filter((e) => e.s === "wizard").length;
	for (let r of q) e.filter((e) => e.s === r).sort((e, t) => t.v - e.v).forEach((e, i) => {
		let a = Math.max(0, Math.min(.95, (e.v - 2 * i) / 14));
		r === t && (a = Math.min(.95, a + .25)), n += a;
	});
	if (t) {
		let r = q.filter((n) => n !== t && !e.some((e) => e.s === n)).length;
		n += .2 * r * Math.min(2, e.filter((e) => e.s === t).length);
	}
	return n;
}
function he(e, t, n) {
	if (t.length === 0) return !0;
	if (e.s === "jester" || t.some((e) => e.card.s === "wizard")) return !1;
	if (e.s === "wizard") return !0;
	let r = A(t);
	return n && e.s === n ? t.filter((e) => e.card.s === n).every((t) => t.card.v < e.v) : n && t.some((e) => e.card.s === n) || !r || e.s !== r ? !1 : t.filter((e) => e.card.s === r).every((t) => t.card.v < e.v);
}
function X(e, t, n) {
	if (e.s === "wizard") return 200;
	if (e.s === "jester") return 0;
	if (n && e.s === n) return 100 + e.v;
	let r = A(t);
	return r && e.s === r ? 20 + e.v : e.v / 10;
}
function ge(e, t, n) {
	return e.s === "wizard" ? !0 : !n || e.s === "jester" || n.wizardsLeft > 0 ? !1 : t && e.s === t ? n.suitLeft[t].every((t) => t < e.v) : t && n.suitLeft[t].length > 0 ? !1 : n.suitLeft[e.s].every((t) => t < e.v);
}
function _e(e, t, n, r, i) {
	let a = e.filter((e) => e.s === "wizard"), o = e.filter((e) => e.s === "jester"), s = e.filter(K);
	if (n > 0) {
		if (r && a.length > 0) return a[0];
		let n = s.filter((e) => ge(e, t, i));
		if (n.length > 0) return n.reduce((e, n) => X(n, [], t) < X(e, [], t) ? n : e);
		let o = s.filter((e) => e.s === t);
		if (o.length > 0) return o.reduce((e, t) => t.v > e.v ? t : e);
		if (s.length > 0) {
			let e = i ? s.filter((e) => i.noVoid(e.s)) : s;
			return (e.length > 0 ? e : s).reduce((e, t) => t.v > e.v ? t : e);
		}
		return e[0];
	}
	if (o.length > 0) return o[0];
	let c = s.filter((e) => e.s !== t), l = c.length > 0 ? c : s;
	return l.length > 0 ? l.reduce((e, t) => t.v < e.v ? t : e) : e[0];
}
function ve(e, t, n, r, i) {
	let a = e.filter((e) => he(e, t, n)), o = e.filter((e) => !he(e, t, n));
	if (r > 0 && a.length > 0) return (i ? a : a.filter((e) => e.s !== "wizard").length > 0 ? a.filter((e) => e.s !== "wizard") : a).reduce((e, r) => X(r, t, n) < X(e, t, n) ? r : e);
	if (o.length > 0) {
		let e = o.filter((e) => e.s === "jester");
		return e.length > 0 ? e[0] : o.reduce((e, r) => X(r, t, n) > X(e, t, n) ? r : e);
	}
	return e.reduce((e, r) => X(r, t, n) < X(e, t, n) ? r : e);
}
function ye(e, t, n) {
	let r = e[t] ?? (e[t] = []);
	r.includes(n) || r.push(n);
}
function be(e, t) {
	let n = !e || e.round !== t.round ? {
		round: t.round,
		done: 0,
		seen: [],
		voids: {}
	} : e, r = t.players.reduce((e, t) => e + t.tricksWon, 0);
	if (r > n.done && t.lastTrick) {
		let e = A(t.lastTrick.plays);
		for (let r of t.lastTrick.plays) n.seen.push(r.card), e && K(r.card) && r.card.s !== e && ye(n.voids, r.rid, e);
		n.done = r;
	}
	return n;
}
function xe(e, t, n) {
	let r = e.trick.plays, i = [...n.seen, ...r.map((e) => e.card)], a = Y().filter((n) => !i.some((e) => J(e, n)) && !t.some((e) => J(e, n)) && !(e.flipped && J(n, e.flipped))), o = Object.fromEntries(Object.entries(n.voids).map(([e, t]) => [e, [...t]])), s = A(r);
	if (s) for (let e of r) K(e.card) && e.card.s !== s && ye(o, e.rid, s);
	return {
		wizardsLeft: a.filter((e) => e.s === "wizard").length,
		suitLeft: Object.fromEntries(q.map((e) => [e, a.filter((t) => t.s === e).map((e) => e.v)])),
		noVoid: (e) => !Object.values(o).some((t) => t.includes(e))
	};
}
var Se = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32, Ce = (globalThis.__WIZARD_MC__ ?? {}).samples ?? 16;
function we(e, t, n, r, i) {
	let a = Object.fromEntries(t.map((t) => [t, e[t]])), o = Object.fromEntries(t.map((e) => [e, 0])), s = t[0], c = e[i].length;
	for (let e = 0; e < c; e += 1) {
		let e = [], i = t.indexOf(s);
		for (let s = 0; s < t.length; s += 1) {
			let c = t[(i + s) % t.length], l = a[c], u = A(e), d = u && l.some((e) => e.s === u) ? l.filter((e) => e.s === u || !K(e)) : l, f = (n[c] ?? 0) - o[c], p = f >= l.length, m = e.length === 0 ? _e(d, r, f, p) : ve(d, e, r, f, p);
			a[c] = l.filter((e) => !J(e, m)), e.push({
				rid: c,
				card: m
			});
		}
		s = j(e, r), o[s] += 1;
	}
	return o[i];
}
function Te(e) {
	let t = e.players.map((e) => e.rid), n = t.indexOf(e.dealer);
	return t.map((e, r) => t[(n + 1 + r) % t.length]);
}
function Ee(e, t, n, r) {
	let i = Math.max(0, Math.min(n, Math.round(me(e, t))));
	return r === i && (i = i + 1 <= n ? i + 1 : i - 1), i;
}
function De(e, t) {
	return e === t ? 20 + 10 * t : -10 * Math.abs(e - t);
}
function Oe(e, t, n) {
	let r = Te(e), i = e.flipped, a = Y().filter((e) => !t.some((t) => J(t, e)) && !(i && J(e, i))), o = {};
	for (let t of e.players) t.bid !== null && (o[t.rid] = t.bid);
	return {
		hand: [...t],
		order: r,
		others: r.filter((e) => e !== n),
		pool: a,
		done: o,
		round: e.round,
		me: n
	};
}
function ke(e, t, n, r) {
	let { hand: i, order: a, others: o, pool: s, done: c, round: l, me: u } = e, d = 0;
	for (let e = 0; e < r; e += 1) {
		let e = [...s];
		for (let t = e.length - 1; t > 0; --t) {
			let n = Math.floor(Se() * (t + 1));
			[e[t], e[n]] = [e[n], e[t]];
		}
		let r = { [u]: [...i] };
		o.forEach((t, n) => {
			r[t] = e.slice(n * l, (n + 1) * l);
		});
		let f = {
			...c,
			[u]: n
		};
		for (let e of a) {
			if (f[e] !== void 0) continue;
			let n = a.indexOf(e) === a.length - 1, i = l - Object.values(f).reduce((e, t) => e + t, 0);
			f[e] = Ee(r[e], t, l, n && i >= 0 ? i : null);
		}
		d += De(n, we(r, a, f, t, u));
	}
	return d / r;
}
function Z(e, t, n, r, i = Ce) {
	let a = Oe(e, t, n), o = -1, s = -Infinity;
	for (let t = 0; t <= a.round; t += 1) {
		if (t === e.forbiddenBid) continue;
		let n = ke(a, r, t, i);
		n > s && (s = n, o = t);
	}
	return {
		n: o,
		score: s
	};
}
function Ae(e, t, n) {
	let r = q[0], i = -Infinity;
	for (let a of q) {
		let { score: o } = Z(e, t, n, a, 8);
		o > i && (i = o, r = a);
	}
	return r;
}
var je = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	let i = t.rid, a = t.difficulty === "weak", o = r.hand;
	if (n.actor !== i || o.length === 0) return null;
	if (n.phase === "trump") {
		let e;
		return e = a ? q[o.length % q.length] : Ae(n, o, i), { action: {
			type: "pickTrump",
			suit: e
		} };
	}
	if (n.phase === "bid") return { action: {
		type: "bid",
		n: a ? (n.round + o.length) % (n.round + 1) : Z(n, o, i, n.trump).n
	} };
	if (n.phase !== "play") return null;
	let s = be(t.memory ?? null, n), c = r.mustFollow ? o.filter((e) => e.s === r.mustFollow || !K(e)) : o;
	if (c.length === 0) return null;
	if (a) return {
		action: {
			type: "play",
			card: c[(n.round + n.trick.plays.length) % c.length]
		},
		memory: s
	};
	let l = xe(n, o, s), u = n.players.find((e) => e.rid === i), d = (u?.bid ?? 0) - (u?.tricksWon ?? 0), f = d >= o.length;
	return {
		action: {
			type: "play",
			card: n.trick.plays.length === 0 ? _e(c, n.trump, d, f, l) : ve(c, n.trick.plays, n.trump, d, f)
		},
		memory: s
	};
}, Me = {
	yellow: "games.wizard.suit.yellow",
	red: "games.wizard.suit.red",
	green: "games.wizard.suit.green",
	blue: "games.wizard.suit.blue"
}, Ne = (e, t, n) => {
	if (e.type === "bid") return n("games.wizard.bidConfirm", { n: e.n });
	if (e.type === "pickTrump") return n("games.wizard.hintPickTrump", { suit: n(Me[e.suit]) });
	if (e.type !== "play") return "";
	let r = e.card;
	return n("games.wizard.hintPlay", { card: r.s === "wizard" ? n("games.wizard.cardWizard") : r.s === "jester" ? n("games.wizard.cardJester") : n("games.wizard.hintCard", {
		suit: n(Me[r.s]),
		n: r.v
	}) });
};
//#endregion
//#region src/games/wizard/fx.tsx
function Q(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function Pe(e) {
	if (typeof e != "object" || !e) return null;
	let t = e;
	return typeof t.s == "string" && typeof t.v == "number" ? t : null;
}
function Fe(e) {
	if (!Array.isArray(e)) return null;
	let t = e.map(Pe);
	return t.every((e) => e !== null) ? t : null;
}
function Ie(e, t, n) {
	let r = e.w / n;
	return {
		x: e.x + t * r + (r - 44) / 2,
		y: e.y + 3,
		w: 44,
		h: 64
	};
}
function $(e) {
	return {
		width: e.w,
		height: e.h,
		"--wz-card-unit": `${e.w}px`,
		transform: "none"
	};
}
var Le = {
	deal(e, t) {
		let n = e.secret, r = n ? Fe(n.cards) : null, i = t.anchor("table");
		if (r) {
			if (!i) return null;
			let e = [], n = [];
			for (let [a, o] of r.entries()) {
				let r = t.anchor(`hand:${V(o)}`);
				if (!r) continue;
				let s = {
					x: i.x + i.w / 2 - r.w / 2,
					y: i.y + i.h / 2 - r.h / 2,
					w: r.w,
					h: r.h
				};
				n.push(`hand:${V(o)}`), e.push(/* @__PURE__ */ c(d, {
					from: s,
					to: r,
					ms: 320,
					delay: a * 45,
					children: /* @__PURE__ */ c(U, {
						card: o,
						size: "hand",
						style: $(r)
					})
				}, V(o)));
			}
			return e.length ? {
				ms: 320 + e.length * 45,
				node: e,
				hide: n
			} : null;
		}
		let a = Q(t, e.rid);
		if (!i || !a) return null;
		let o = t.anchor("tslot:0") ?? {
			x: 0,
			y: 0,
			w: 44,
			h: 64
		}, s = {
			x: i.x + i.w / 2 - o.w / 2,
			y: i.y + i.h / 2 - o.h / 2,
			w: o.w,
			h: o.h
		}, l = e.data?.count, u = typeof l == "number" ? l : 10;
		return {
			ms: 320 + u * 45,
			node: Array.from({ length: u }, (e, t) => /* @__PURE__ */ c(d, {
				from: s,
				to: a,
				ms: 320,
				delay: t * 45,
				children: /* @__PURE__ */ c(W, {
					accent: g.accent,
					style: $(s)
				})
			}, t))
		};
	},
	flip(e, t) {
		let n = t.anchor("table");
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ c(f, {
				at: n,
				ms: 500
			})
		} : null;
	},
	trumpPick(e, t) {
		let n = Q(t, e.rid);
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ c(f, {
				at: n,
				ms: 500
			})
		} : null;
	},
	bid(e, t) {
		let n = Q(t, e.rid);
		if (!n) return null;
		let r = e.data?.n;
		return {
			ms: 900,
			node: /* @__PURE__ */ l(u, {
				at: n,
				ms: 800,
				delay: 60,
				children: ["✦", typeof r == "number" ? r : "?"]
			})
		};
	},
	play(e, t) {
		let n = Pe(e.data?.card), r = e.data?.index, i = Q(t, e.rid);
		if (!n || !i || typeof r != "number") return null;
		let a = t.anchor("trick"), o = t.anchor(`tslot:${r}`), s = t.anchor(`tcard:${r}`) ?? o ?? (a ? Ie(a, r, r + 1) : null);
		return s ? {
			ms: 400,
			node: /* @__PURE__ */ c(d, {
				from: i,
				to: s,
				ms: 380,
				children: /* @__PURE__ */ c(U, {
					card: n,
					size: "table",
					style: $(s)
				})
			}),
			hide: [`tcard:${r}`]
		} : null;
	},
	gather(e, t) {
		let n = Q(t, e.rid), r = t.anchor("trick");
		if (!n || !r) return null;
		let i = e.data?.count, a = typeof i == "number" ? i : 4;
		return {
			ms: 500,
			node: Array.from({ length: a }, (e, i) => {
				let o = t.anchor(`tslot:${i}`) ?? Ie(r, i, a);
				return /* @__PURE__ */ c(d, {
					from: o,
					to: n,
					ms: 420,
					delay: i * 50,
					children: /* @__PURE__ */ c(W, {
						accent: g.accent,
						style: $(o)
					})
				}, i);
			})
		};
	},
	roundScore(e, t) {
		let n = Q(t, e.rid);
		if (!n) return null;
		let r = e.data?.delta;
		return typeof r == "number" ? {
			ms: 1200,
			node: /* @__PURE__ */ c(u, {
				at: n,
				ms: 1100,
				delay: 120,
				children: r >= 0 ? `+${r}` : r
			})
		} : null;
	}
};
//#endregion
//#region src/games/wizard/game-over.tsx
function Re(e) {
	return /* @__PURE__ */ c("div", {
		className: "wz-game-over",
		children: /* @__PURE__ */ c(p, {
			...e,
			accent: g.accent
		})
	});
}
//#endregion
//#region src/games/wizard/options.tsx
function ze({ value: e, onChange: t }) {
	let n = i(), r = b.safeParse(e), a = r.success ? r.data : b.parse(void 0), o = [{
		key: "full",
		label: n("games.wizard.optFull"),
		hint: n("games.wizard.optFullHint")
	}, {
		key: "quick",
		label: n("games.wizard.optQuick"),
		hint: n("games.wizard.optQuickHint")
	}];
	return /* @__PURE__ */ c(h, {
		title: n("games.wizard.optLength"),
		children: o.map((e) => /* @__PURE__ */ c(m, {
			name: "wizard-length",
			value: e.key,
			checked: a.length === e.key,
			label: e.label,
			hint: e.hint,
			accent: g.accent,
			onChange: () => t({ length: e.key })
		}, e.key))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/wizard/entry.tsx
var Be = {
	definition: R,
	View: oe,
	bot: je,
	describe: Ne,
	fx: Le,
	OverView: Re,
	Options: ze,
	locales: {
		zh: {
			name: "巫师牌",
			desc: "吃墩预言:先叫墩再开打,报得越准得分越高",
			rules: "目标:每轮预报自己要赢的墩数,预报精准得分,总分最高者胜。\n准备:\n· 牌共 60 张:四种花色各 1~13,另有 4 张巫师和 4 张小丑。\n· 第 1 轮每人 1 张牌,之后每轮多发 1 张,直到发完全部牌。\n流程:\n· 发牌后翻一张牌定将色;翻到巫师由庄家看手牌后选将色,翻到小丑则本轮无将。\n· 最后一轮牌全部发完、无牌可翻,本轮无将。\n· 从庄家左手边开始依次叫墩;庄家最后叫,且所叫墩数不得使全场总叫墩数等于本轮墩数。\n· 庄家左手边的玩家开第一墩,之后每墩由赢墩者引牌。\n· 手中持有首引花色时必须跟出;巫师和小丑随时可出。\n· 墩的归属:首个巫师最大;无巫师时比较将牌点数;连将牌也没有时,比较首引花色的点数。\n· 一墩全是小丑时,第一个打出的小丑赢。\n· 小丑首引时,跟牌花色由之后打出的第一张数字牌决定。\n结算:\n· 实际赢得的墩数与预报完全相同时，获得20分，另按每墩10分计入得分。两者不同时，每相差一墩扣除10分。\n· 庄家每轮顺时针轮换;最后一轮结算后总分最高者胜,可并列。",
			optLength: "局长",
			optFull: "完整局",
			optFullHint: "打满全部轮次(3人20轮/4人15轮)",
			optQuick: "快速局",
			optQuickHint: "轮数减半,约 20 分钟",
			roundChip: "第 {{n}}/{{total}} 轮",
			phaseSub: "预言本轮将赢的墩数",
			points: "分",
			bidPending: "未报",
			trumpLabel: "本轮将牌",
			trumpUndecided: "待选将色",
			trickCountLabel: "当前墩",
			roundCountLabel: "本轮墩数",
			handTitle: "你的手牌",
			handWait: "预报后才可出牌",
			handFollow: "须跟 {{suit}} · 特殊牌不限",
			handPlayHint: "选一张牌，再确认落点",
			handWaitingTurn: "等待本墩轮到你",
			trumpChooseHint: "刻下本轮将色",
			bidEyebrow: "四 色 预 言",
			bidPickHint: "选择预报筹码",
			chosenBid: "已选预报",
			chosenCard: "已选手牌",
			leadSuit: "首引：{{suit}}",
			resultTitle: "预言揭晓",
			trumpIs: "将牌:{{suit}}",
			trumpNone: "本轮无将",
			trumpFlippedWizard: "翻出了巫师,由庄家选将色",
			trumpPrompt: "你是庄家:选择本轮将色",
			trumpWaiting: "翻出了巫师,等 {{name}} 选将色…",
			bidPrompt: "轮到你叫墩",
			bidWaiting: "等 {{name}} 叫墩…",
			bidQuestion: "本轮 {{n}} 墩,你要赢几墩?",
			bidForbiddenHint: "你是庄家:不能叫 {{n}}(总叫墩不能等于墩数)",
			bidConfirm: "预报赢 {{n}} 墩",
			bidSend: "叫墩",
			turnYou: "轮到你出牌",
			turnWait: "等 {{name}} 出牌…",
			trickLead: "等 {{name}} 开墩",
			trickChip: "第 {{n}}/{{total}} 墩",
			lastTrick: "上一墩 {{name}} 赢:",
			roundEnd: "本轮结算",
			done: "对局结束",
			nextRoundSoon: "即将进入下一轮…",
			bidVsWon: "叫 {{bid}} / 赢 {{won}}",
			scoreboard: "计分板",
			scoreCell: "{{bid}}→{{won}}·{{delta}}",
			close: "关闭",
			cancel: "取消",
			playCard: "出牌",
			dealerAria: "庄家",
			scoreAria: "{{n}} 分",
			bidAria: "叫 {{n}} 墩,已赢 {{won}} 墩",
			cardWizard: "巫师",
			cardJester: "小丑",
			suit: {
				yellow: "黄色",
				red: "红色",
				green: "绿色",
				blue: "蓝色"
			},
			errPhase: "现在不能这么做",
			errTurn: "还没轮到你",
			errBid: "叫墩数超出本轮墩数",
			errBidForbidden: "总叫墩不能等于本轮墩数",
			errCard: "手里没有这张牌",
			errFollow: "必须跟花色",
			hintPickTrump: "选 {{suit}} 做将色",
			hintCard: "{{suit}} {{n}}",
			hintPlay: "打出 {{card}}"
		},
		en: {
			name: "Wizard",
			desc: "Trick-taking prophecy: bid your tricks, then play — exact bids score big",
			rules: "Goal: each round, predict how many tricks you will win. Exact predictions score; highest total wins.\nSetup:\n· 60 cards: four suits of 1–13, plus 4 Wizards and 4 Jesters.\n· Round 1 deals 1 card each; every round deals one more, until the whole deck is dealt.\nPlay:\n· After dealing, flip a card for trump; a flipped Wizard lets the dealer pick trump after seeing their hand, a Jester means no trump.\n· The last round deals out the whole deck, so nothing is flipped: no trump.\n· Bidding starts left of the dealer; the dealer bids last, and their bid may not make the total bids equal the trick count.\n· The player left of the dealer leads the first trick; each later trick is led by its winner.\n· You must follow suit when you can; Wizards and Jesters may be played anytime.\n· Trick winner: the first Wizard; otherwise the highest trump; otherwise the highest card of the led suit.\n· If a trick is all Jesters, the first Jester played wins it.\n· When a Jester leads, the suit is set by the first number card played afterwards.\nScoring:\n· If you win exactly the number of tricks you bid, score 20 points plus 10 points per trick. Otherwise, lose 10 points for each trick by which your result differs from your bid.\n· The deal rotates clockwise each round; after the final round, highest score wins (ties allowed).",
			optLength: "Game length",
			optFull: "Full game",
			optFullHint: "All rounds (20 with 3p, 15 with 4p)",
			optQuick: "Quick game",
			optQuickHint: "Half the rounds, ~20 min",
			roundChip: "Round {{n}}/{{total}}",
			phaseSub: "Predict your tricks this round",
			points: "pts",
			bidPending: "No bid",
			trumpLabel: "Trump card",
			trumpUndecided: "Choose trump",
			trickCountLabel: "Current trick",
			roundCountLabel: "Tricks this round",
			handTitle: "Your hand",
			handWait: "Play after bidding",
			handFollow: "Follow {{suit}} · specials free",
			handPlayHint: "Choose a card, then confirm",
			handWaitingTurn: "Waiting for your turn",
			trumpChooseHint: "Choose the trump suit",
			bidEyebrow: "FOUR SUIT PROPHECY",
			bidPickHint: "Choose a bid token",
			chosenBid: "Selected bid",
			chosenCard: "Selected card",
			leadSuit: "Lead: {{suit}}",
			resultTitle: "Prophecy revealed",
			trumpIs: "Trump: {{suit}}",
			trumpNone: "No trump",
			trumpFlippedWizard: "A Wizard was flipped — dealer picks trump",
			trumpPrompt: "You dealt: pick this round’s trump",
			trumpWaiting: "Wizard flipped — waiting for {{name}} to pick trump…",
			bidPrompt: "Your bid",
			bidWaiting: "Waiting for {{name}} to bid…",
			bidQuestion: "How many will you win out of {{n}}?",
			bidForbiddenHint: "You dealt: you cannot bid {{n}} (bids may not total the trick count)",
			bidConfirm: "Bid {{n}} tricks",
			bidSend: "Bid",
			turnYou: "Your turn to play",
			turnWait: "Waiting for {{name}} to play…",
			trickLead: "Waiting for {{name}} to lead",
			trickChip: "Trick {{n}}/{{total}}",
			lastTrick: "Last trick: {{name}} won",
			roundEnd: "Round scored",
			done: "Game over",
			nextRoundSoon: "Next round starting…",
			bidVsWon: "bid {{bid}} / won {{won}}",
			scoreboard: "Scores",
			scoreCell: "{{bid}}→{{won}}·{{delta}}",
			close: "Close",
			cancel: "Cancel",
			playCard: "Play",
			dealerAria: "Dealer",
			scoreAria: "{{n}} points",
			bidAria: "bid {{n}}, won {{won}}",
			cardWizard: "Wizard",
			cardJester: "Jester",
			suit: {
				yellow: "Yellow",
				red: "Red",
				green: "Green",
				blue: "Blue"
			},
			errPhase: "Not right now",
			errTurn: "Not your turn",
			errBid: "Bid exceeds this round’s trick count",
			errBidForbidden: "Total bids may not equal the trick count",
			errCard: "You don’t have that card",
			errFollow: "You must follow suit",
			hintPickTrump: "Make {{suit}} trump",
			hintCard: "{{suit}} {{n}}",
			hintPlay: "Play {{card}}"
		}
	}
};
//#endregion
export { Be as default };
