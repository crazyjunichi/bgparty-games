import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { ConfirmButton as r } from "@bgparty/sdk/confirm-button";
import { useFxAnchor as i } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as a } from "@bgparty/sdk/fx/delta-number";
import { useT as o } from "@bgparty/sdk/i18n";
import { Texture as s } from "@bgparty/sdk/texture";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { LogTicker as l } from "@bgparty/sdk/ui/log-sheet";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as d } from "@bgparty/sdk/ui/player-strip";
import { IconCheck as f } from "@bgparty/sdk/icons";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { Floater as g, FlySprite as _, PulseBox as v } from "@bgparty/sdk/fx/primitives";
import { AVATARS as y } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as b } from "@bgparty/sdk/player-colors";
import { Confetti as x } from "@bgparty/sdk/ui/confetti";
//#region src/games/regicide/meta.ts
var ee = {
	id: "regicide",
	tier: "beta",
	mechanics: ["hand-management"],
	interactionTags: ["cooperative"],
	nameKey: "games.regicide.name",
	descKey: "games.regicide.desc",
	rulesKey: "games.regicide.rules",
	icon: "🗡️",
	iconImg: "games/regicide.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/regicide/en.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#7e22ce",
	releasedAt: "2026-09-14",
	search: {
		py: "shi jun zhe",
		init: "sjz"
	},
	hotseat: "cover"
}, S = t.int().min(0).max(53), C = t.string(), w = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		cards: t.array(S).min(1).max(8)
	}),
	t.object({
		type: t.literal("jester"),
		next: C
	}),
	t.object({ type: t.literal("yield") }),
	t.object({
		type: t.literal("defend"),
		cards: t.array(S).min(0).max(8)
	})
]), T = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("play"),
		rid: C,
		cards: t.array(S).min(1),
		dmg: t.int().nonnegative(),
		doubled: t.boolean(),
		heal: t.int().nonnegative(),
		draw: t.int().nonnegative(),
		shieldUp: t.int().nonnegative()
	}),
	t.object({
		k: t.literal("defend"),
		rid: C,
		count: t.int().nonnegative(),
		need: t.int().nonnegative()
	}),
	t.object({
		k: t.literal("yield"),
		rid: C
	}),
	t.object({
		k: t.literal("jester"),
		rid: C,
		next: C
	}),
	t.object({
		k: t.literal("slain"),
		card: S,
		exact: t.boolean()
	}),
	t.object({
		k: t.literal("fallen"),
		rid: C
	})
]), E = t.object({
	phase: t.enum([
		"play",
		"defend",
		"done"
	]),
	turn: C,
	handLimit: t.int().min(1),
	enemy: t.object({
		card: S,
		hp: t.int(),
		maxHp: t.int(),
		atk: t.int(),
		shield: t.int().nonnegative(),
		immune: t.boolean()
	}).nullable(),
	defendNeed: t.int().nonnegative().nullable(),
	castleLeft: t.int().nonnegative(),
	tavernCount: t.int().nonnegative(),
	discard: t.array(S),
	kills: t.int().nonnegative(),
	result: t.enum(["win", "lose"]).nullable(),
	players: t.array(t.object({
		rid: C,
		handCount: t.int().nonnegative()
	})),
	log: t.array(T)
}), D = t.object({ hand: t.array(S) }), O = (e) => e >= 52, k = (e) => Math.floor(e / 13), A = (e) => e % 13 + 1;
function j(e) {
	if (O(e)) return 0;
	let t = A(e);
	return t === 11 ? 10 : t === 12 ? 15 : t === 13 ? 20 : t;
}
function M(e) {
	let t = A(e);
	return t === 11 ? {
		atk: 10,
		hp: 20
	} : t === 12 ? {
		atk: 15,
		hp: 30
	} : {
		atk: 20,
		hp: 40
	};
}
var N = (e) => e <= 1 ? 8 : e === 2 ? 7 : e === 3 ? 6 : 5, P = (e) => e <= 2 ? 0 : e - 2, F = (e) => Math.max(0, M(e.castle[0]).atk - e.shield), te = 60;
function I(e, t) {
	e.log.push(t), e.log.length > te && e.log.splice(0, e.log.length - te);
}
function L(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function R(e) {
	let t = [];
	return e.players.forEach((n, r) => {
		t.push({
			kind: "deal",
			rid: n,
			data: { count: e.hands[n].length },
			for: [n],
			secret: { cards: e.hands[n] },
			...r > 0 ? { with: !0 } : {}
		});
	}), t;
}
function z(e, t, n) {
	let r = {
		seed: n,
		rngCursor: 0,
		players: t,
		handLimit: N(t.length),
		castle: [],
		enemyHp: 0,
		shield: 0,
		immune: !0,
		tavern: [],
		discard: [],
		hands: {},
		turnIdx: 0,
		phase: "play",
		defendNeed: 0,
		kills: 0,
		result: null,
		log: []
	}, i = (e) => [
		0,
		1,
		2,
		3
	].map((t) => t * 13 + e - 1);
	r.castle = [
		...L(r, i(11)),
		...L(r, i(12)),
		...L(r, i(13))
	];
	let a = [];
	for (let e = 0; e < 4; e += 1) for (let t = 1; t <= 10; t += 1) a.push(e * 13 + t - 1);
	for (let e = 0; e < P(t.length); e += 1) a.push(52 + e);
	r.tavern = L(r, a);
	for (let e of t) r.hands[e] = r.tavern.splice(0, r.handLimit);
	return r.enemyHp = M(r.castle[0]).hp, {
		state: r,
		fx: R(r)
	};
}
function B(e) {
	if (e.length === 0 || e.some(O) || new Set(e).size !== e.length) return !1;
	if (e.length === 1) return !0;
	let t = e.map(A);
	return e.length === 2 && t.includes(1) ? !0 : t.every((e) => e === t[0]) && e.reduce((e, t) => e + j(t), 0) <= 10;
}
function ne(e, t, n) {
	let r = [
		0,
		0,
		0,
		0
	];
	for (let t of e) r[k(t)] += j(t);
	let i = (e) => n && t === e, a = r[3] > 0 && !i(3);
	return {
		damage: e.reduce((e, t) => e + j(t), 0) * (a ? 2 : 1),
		heal: i(1) ? 0 : r[1],
		draw: i(2) ? 0 : r[2],
		shieldUp: i(0) ? 0 : r[0],
		doubled: a
	};
}
function V(t, n) {
	let r = Math.min(n, t.discard.length);
	for (let n = 0; n < r; n += 1) {
		let n = e(t.seed, t.rngCursor, t.discard.length);
		t.rngCursor += 1, t.tavern.push(t.discard.splice(n, 1)[0]);
	}
	return r > 0 && (t.tavern = L(t, t.tavern)), r;
}
function re(e, t) {
	let n = {}, r = t, i = e.turnIdx;
	for (; r > 0 && e.tavern.length > 0;) {
		let t = e.players[i];
		if (e.hands[t].length < e.handLimit) {
			let i = e.tavern.shift();
			e.hands[t].push(i), (n[t] ??= []).push(i), --r;
		}
		if (i = (i + 1) % e.players.length, i === e.turnIdx && e.players.every((t) => e.hands[t].length >= e.handLimit)) break;
	}
	return n;
}
function ie(e, t) {
	let n = e.castle.shift(), r = e.enemyHp === 0;
	if (r ? e.tavern.unshift(n) : e.discard.push(n), e.kills += 1, I(e, {
		k: "slain",
		card: n,
		exact: r
	}), e.castle.length === 0) {
		e.phase = "done", e.result = "win", t.push({
			kind: "slain",
			data: {
				card: n,
				exact: r,
				last: !0
			}
		});
		return;
	}
	e.enemyHp = M(e.castle[0]).hp, e.shield = 0, e.immune = !0, t.push({
		kind: "slain",
		data: {
			card: n,
			exact: r,
			last: !1
		}
	});
}
function H(e) {
	let t = F(e);
	t > 0 ? (e.phase = "defend", e.defendNeed = t) : e.turnIdx = (e.turnIdx + 1) % e.players.length;
}
function U(e) {
	return e.phase !== "play" || !e.players.every((t) => e.hands[t].length === 0) ? !1 : (e.phase = "done", e.result = "lose", !0);
}
var W = (e, t, n) => {
	let r = [...e.hands[t]];
	return n.every((e) => {
		let t = r.indexOf(e);
		return t < 0 ? !1 : (r.splice(t, 1), !0);
	});
}, G = (e, t) => {
	let n = [...e];
	for (let e of t) n.splice(n.indexOf(e), 1);
	return n;
};
function K(e, t, n) {
	if (e.phase === "done") return { code: "games.regicide.errDone" };
	if (n.by !== e.players[e.turnIdx]) return { code: "games.regicide.errNotYourTurn" };
	if (t.type === "defend") {
		if (e.phase !== "defend") return { code: "games.regicide.errNotYourTurn" };
		if (!W(e, n.by, t.cards)) return { code: "games.regicide.errBadCards" };
		let r = e.hands[n.by], i = t.cards.reduce((e, t) => e + j(t), 0), a = structuredClone(e);
		return a.hands[n.by] = G(r, t.cards), a.discard.push(...t.cards), i < a.defendNeed ? t.cards.length < r.length || r.reduce((e, t) => e + j(t), 0) >= a.defendNeed ? { code: "games.regicide.errDefendMore" } : (a.phase = "done", a.result = "lose", I(a, {
			k: "defend",
			rid: n.by,
			count: t.cards.length,
			need: a.defendNeed
		}), I(a, {
			k: "fallen",
			rid: n.by
		}), {
			state: a,
			fx: [{
				kind: "suffer",
				rid: n.by,
				data: { cards: t.cards }
			}, {
				kind: "fallen",
				rid: n.by
			}]
		}) : (a.phase = "play", a.turnIdx = (a.turnIdx + 1) % a.players.length, I(a, {
			k: "defend",
			rid: n.by,
			count: t.cards.length,
			need: a.defendNeed
		}), U(a), {
			state: a,
			fx: [{
				kind: "suffer",
				rid: n.by,
				data: { cards: t.cards }
			}]
		});
	}
	if (e.phase !== "play") return { code: "games.regicide.errNotYourTurn" };
	if (t.type === "yield") {
		let t = structuredClone(e);
		return H(t), I(t, {
			k: "yield",
			rid: n.by
		}), U(t), {
			state: t,
			fx: [{
				kind: "yield",
				rid: n.by
			}]
		};
	}
	if (t.type === "jester") {
		let r = e.hands[n.by].find(O);
		if (r === void 0) return { code: "games.regicide.errNoJester" };
		let i = e.players.indexOf(t.next);
		if (i < 0) return { code: "games.regicide.errBadNext" };
		let a = structuredClone(e);
		return a.hands[n.by] = a.hands[n.by].filter((e) => e !== r), a.discard.push(r), a.immune = !1, a.turnIdx = i, I(a, {
			k: "jester",
			rid: n.by,
			next: t.next
		}), U(a), {
			state: a,
			fx: [{
				kind: "jester",
				rid: n.by,
				data: {
					card: r,
					next: t.next
				}
			}]
		};
	}
	if (!B(t.cards)) return { code: "games.regicide.errBadCombo" };
	if (!W(e, n.by, t.cards)) return { code: "games.regicide.errBadCards" };
	let r = structuredClone(e), i = r.castle[0], a = ne(t.cards, k(i), r.immune);
	r.hands[n.by] = G(r.hands[n.by], t.cards);
	let o = V(r, a.heal), s = re(r, a.draw);
	r.shield += a.shieldUp, r.enemyHp -= a.damage, r.discard.push(...t.cards);
	let c = Object.values(s).reduce((e, t) => e + t.length, 0);
	I(r, {
		k: "play",
		rid: n.by,
		cards: t.cards,
		dmg: a.damage,
		doubled: a.doubled,
		heal: o,
		draw: c,
		shieldUp: a.shieldUp
	});
	let l = [{
		kind: "attack",
		rid: n.by,
		data: {
			cards: t.cards,
			damage: a.damage,
			doubled: a.doubled,
			heal: o,
			shieldUp: a.shieldUp
		}
	}];
	for (let [e, t] of Object.entries(s)) l.push({
		kind: "draw",
		rid: e,
		data: { count: t.length },
		for: [e],
		secret: { cards: t },
		with: !0
	});
	return r.enemyHp > 0 ? H(r) : (ie(r, l), r.phase !== "done" && (r.turnIdx = (r.turnIdx + 1) % r.players.length)), U(r), {
		state: r,
		fx: l
	};
}
function ae(e, t) {
	let n = e.phase === "done" ? null : e.castle[0];
	return {
		public: {
			phase: e.phase,
			turn: e.players[e.turnIdx],
			handLimit: e.handLimit,
			enemy: n == null ? null : {
				card: n,
				hp: e.enemyHp,
				maxHp: M(n).hp,
				atk: M(n).atk,
				shield: e.shield,
				immune: e.immune
			},
			defendNeed: e.phase === "defend" ? e.defendNeed : null,
			castleLeft: e.castle.length,
			tavernCount: e.tavern.length,
			discard: e.discard,
			kills: e.kills,
			result: e.result,
			players: e.players.map((t) => ({
				rid: t,
				handCount: e.hands[t]?.length ?? 0
			})),
			log: e.log.map((e) => ({ ...e }))
		},
		private: { hand: [...e.hands[t] ?? []] }
	};
}
function oe(e) {
	return e.phase === "done" ? {
		phase: "done",
		winner: e.result === "win" ? [...e.players] : [],
		ranking: [...e.players],
		scores: Object.fromEntries(e.players.map((t) => [t, e.kills]))
	} : { phase: e.phase };
}
var se = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: ee,
	schemas: {
		action: w,
		publicView: E,
		privateView: D
	},
	setup: z,
	reduce: K,
	viewFor: ae,
	status: oe
}, q = [
	"♠",
	"♥",
	"♦",
	"♣"
], J = [
	"A",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"10",
	"J",
	"Q",
	"K"
], ce = [
	"games.regicide.suitSpade",
	"games.regicide.suitHeart",
	"games.regicide.suitDiamond",
	"games.regicide.suitClub"
], le = {
	11: "games.regicide.royalJack",
	12: "games.regicide.royalQueen",
	13: "games.regicide.royalKing"
}, ue = (e) => k(e) === 1 || k(e) === 2 ? "rg-card--red" : "rg-card--black";
function Y({ className: e = "" }) {
	return /* @__PURE__ */ h("svg", {
		className: e,
		viewBox: "0 0 100 74",
		fill: "none",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M8 57 3 20l19 12L36 7l14 25L64 7l14 25 19-12-5 37H8Z",
				fill: "currentColor",
				stroke: "var(--color-ink)",
				strokeWidth: "4",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ m("path", {
				d: "m53 7-9 18 10 6-7 14 8 12",
				stroke: "var(--color-ink)",
				strokeWidth: "3",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ m("path", {
				d: "M8 57h84v12H8z",
				fill: "currentColor",
				stroke: "var(--color-ink)",
				strokeWidth: "4",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ m("path", {
				d: "m50 36 7 8-7 8-7-8 7-8Z",
				fill: "var(--rg-gem, #ce4451)",
				stroke: "var(--color-ink)",
				strokeWidth: "2"
			})
		]
	});
}
function de({ rank: e, suit: t }) {
	let n = e === 13 ? 68 : e === 12 ? 59 : 51, r = e === 13 ? 50 : e === 12 ? 44 : 39;
	return /* @__PURE__ */ h("svg", {
		className: "rg-court-emblem",
		viewBox: "0 0 160 176",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M0 35 160 0M0 79 160 44M0 123 160 88M0 167 160 132",
				stroke: "#ffffff",
				strokeOpacity: ".10",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ m("path", {
				d: `M80 ${87 - n} ${80 + n * .73} 87 80 ${87 + n} ${80 - n * .73} 87Z`,
				fill: "#96788c",
				stroke: "#e3bb70",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ m("path", {
				d: `M80 ${87 - r} ${80 + r * .73} 87 80 ${87 + r} ${80 - r * .73} 87Z`,
				fill: "#31565a",
				stroke: "#f4d797",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ m("path", {
				d: "M80 47 110 87 80 127 50 87Z",
				fill: "#f6ead4",
				stroke: "var(--color-ink)",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ m("text", {
				x: "80",
				y: "108",
				textAnchor: "middle",
				fontSize: "58",
				fontWeight: "800",
				fill: t === 1 || t === 2 ? "#ce4451" : "#463149",
				children: q[t]
			}),
			/* @__PURE__ */ m("circle", {
				cx: "17",
				cy: "20",
				r: "3",
				fill: "#e3bb70"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "143",
				cy: "20",
				r: "3",
				fill: "#e3bb70"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "17",
				cy: "156",
				r: "3",
				fill: "#e3bb70"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "143",
				cy: "156",
				r: "3",
				fill: "#e3bb70"
			})
		]
	});
}
function X({ id: e, size: t, selected: n = !1, elevated: r = !1, target: i = !1, hp: a, maxHp: s, damagePreview: c = 0, dimensions: l }) {
	let u = o(), d = O(e), g = d ? 0 : A(e), _ = d ? -1 : k(e), v = d ? "✦" : q[_], y = d ? u("games.regicide.jesterAria") : `${u(ce[_])} ${J[g - 1]}`, b = typeof a == "number" && typeof s == "number" && s > 0 ? Math.max(0, Math.min(s, a)) : null, x = b === null ? 0 : Math.min(b, Math.max(0, c));
	return /* @__PURE__ */ m("span", {
		"aria-label": y,
		"data-suit": _,
		style: l ? {
			width: l.width,
			height: l.height,
			"--rg-hand-w": `${l.width}px`,
			"--rg-hand-h": `${l.height}px`,
			"--rg-enemy-w": `${l.width}px`,
			"--rg-enemy-h": `${l.height}px`
		} : void 0,
		className: `rg-card rg-card--${t} ${d ? "rg-card--jester" : ue(e)} ${n ? "rg-card--selected" : ""} ${r ? "rg-card--elevated" : ""} ${i ? "rg-card--target" : ""}`,
		children: t === "enemy" ? /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ h("span", {
				className: "rg-card__royal-head",
				children: [/* @__PURE__ */ h("span", {
					className: "rg-card__royal-rank",
					children: [J[g - 1], /* @__PURE__ */ m("span", {
						className: "rg-card__royal-suit",
						children: v
					})]
				}), /* @__PURE__ */ m("span", {
					className: "rg-card__royal-name",
					children: u(le[g])
				})]
			}),
			/* @__PURE__ */ h("span", {
				className: "rg-card__court-field",
				children: [
					/* @__PURE__ */ m(de, {
						rank: g,
						suit: _
					}),
					/* @__PURE__ */ m(Y, { className: "rg-card__court-crown" }),
					/* @__PURE__ */ h("span", {
						className: "rg-card__court-caption",
						children: [
							J[g - 1],
							" · ",
							v
						]
					})
				]
			}),
			/* @__PURE__ */ h("span", {
				className: "rg-card__life",
				children: [/* @__PURE__ */ h("span", {
					className: "rg-card__life-text",
					children: [/* @__PURE__ */ m("span", { children: u("games.regicide.health") }), /* @__PURE__ */ h("strong", {
						className: "font-mono tabular-nums",
						children: [
							b ?? "—",
							" / ",
							s ?? "—"
						]
					})]
				}), /* @__PURE__ */ h("span", {
					className: "rg-card__life-track",
					children: [/* @__PURE__ */ m("span", {
						className: "rg-card__life-fill",
						style: { width: `${b === null ? 0 : b / s * 100}%` }
					}), x > 0 && /* @__PURE__ */ m("span", {
						className: "rg-card__life-preview",
						style: {
							left: `${(b - x) / s * 100}%`,
							width: `${x / s * 100}%`
						}
					})]
				})]
			}),
			i && c > 0 && /* @__PURE__ */ h("span", {
				className: "rg-card__hit font-mono tabular-nums",
				children: ["−", c]
			})
		] }) : /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ h("span", {
				className: "rg-card__corner",
				children: [/* @__PURE__ */ m("strong", {
					className: "font-mono tabular-nums",
					children: d ? "0" : J[g - 1]
				}), /* @__PURE__ */ m("span", {
					"aria-hidden": !0,
					children: v
				})]
			}),
			/* @__PURE__ */ m(Y, { className: "rg-card__watermark" }),
			/* @__PURE__ */ m("span", {
				className: "rg-card__pip",
				"aria-hidden": !0,
				children: v
			}),
			n && /* @__PURE__ */ m("span", {
				className: "rg-card__check",
				children: /* @__PURE__ */ m(f, {
					size: 11,
					strokeWidth: 3,
					"aria-hidden": !0
				})
			})
		] })
	});
}
function fe({ kind: e = "tavern", pile: t = !1, dimensions: n }) {
	return /* @__PURE__ */ h("span", {
		className: `rg-card-back rg-card-back--${e} ${t ? "rg-card-back--pile" : ""}`,
		style: n ? {
			width: n.width,
			height: n.height,
			"--rg-hand-w": `${n.width}px`,
			"--rg-hand-h": `${n.height}px`
		} : void 0,
		"aria-hidden": !0,
		children: [/* @__PURE__ */ m("span", { className: "rg-card-back__line" }), /* @__PURE__ */ m(Y, { className: "rg-card-back__crown" })]
	});
}
//#endregion
//#region src/games/regicide/view-player.tsx
function pe(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ m(ge, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function me(e) {
	return [...e].sort((e, t) => (O(e) ? 99 : k(e) * 13 + he(e)) - (O(t) ? 99 : k(t) * 13 + he(t)));
}
var he = (e) => e % 13;
function ge({ pub: e, priv: t, members: l, myRid: f, send: g }) {
	let _ = o(), v = (e) => l.find((t) => t.rid === e)?.name ?? e, { ref: y } = i("enemy"), { ref: b } = i("tavern"), { ref: x } = i("discard"), { ref: S } = i("hand-size"), [C, w] = n([]), [T, E] = n(null), D = me(t?.hand ?? []), M = e.turn === f, N = e.phase === "play" && M, P = e.phase === "defend" && M && e.defendNeed !== null, F = `${e.phase}|${e.turn}|${e.defendNeed}|${D.join(".")}`, [te, I] = n(F);
	te !== F && (I(F), w([]), E(null));
	let L = C.length === 1 && O(C[0]), R = !L && B(C), z = R && e.enemy ? ne(C, k(e.enemy.card), e.enemy.immune) : null, V = C.reduce((e, t) => e + j(t), 0), re = D.reduce((e, t) => e + j(t), 0), ie = P && e.defendNeed !== null && re >= e.defendNeed, H = (e) => {
		(N || P) && (w(C.includes(e) ? C.filter((t) => t !== e) : [...C, e]), E(null));
	}, U, W;
	e.phase === "defend" ? (U = P ? "warn" : "info", W = P ? _("games.regicide.defendYou", { n: e.defendNeed ?? 0 }) : _("games.regicide.defendWait", { name: v(e.turn) })) : N ? (U = "accent", W = _("games.regicide.turnYou")) : (U = "info", W = _("games.regicide.turnWait", { name: v(e.turn) }));
	let G = z ? [
		z.doubled ? _("games.regicide.previewClub") : "",
		z.shieldUp > 0 ? _("games.regicide.previewSpade", { n: z.shieldUp }) : "",
		z.heal > 0 ? _("games.regicide.previewHeart", { n: z.heal }) : "",
		z.draw > 0 ? _("games.regicide.previewDiamond", { n: z.draw }) : ""
	].filter(Boolean).join(" · ") : "", K = N && C.length > 0 && R, ae = P && C.length > 0 && e.defendNeed !== null && V >= e.defendNeed, oe = /* @__PURE__ */ h("div", {
		className: "rg-banner",
		children: [/* @__PURE__ */ m(u, {
			tone: U,
			text: W,
			chip: _("games.regicide.progress", { n: e.kills }),
			accent: ee.accent
		}), /* @__PURE__ */ m("div", {
			className: "rg-seats" + (l.length > 2 ? " rg-seats--medal" : " rg-seats--plate"),
			children: /* @__PURE__ */ m(d, {
				adaptive: !0,
				variant: l.length > 2 ? "medal" : "plate",
				members: l,
				myRid: f,
				anchorOf: (e) => "seat:" + e,
				action: (t) => e.phase !== "done" && t === e.turn ? "pending" : null,
				status: (t) => {
					let n = e.players.find((e) => e.rid === t);
					return n ? /* @__PURE__ */ m("span", {
						className: "font-mono text-xs font-bold tabular-nums",
						children: _("games.regicide.stripHand", { n: n.handCount })
					}) : null;
				},
				onPick: N && L ? (e) => E(T === e ? null : e) : void 0,
				picked: N && L ? (e) => T === e : void 0
			})
		})]
	}), se = /* @__PURE__ */ h("div", {
		className: "rg-actions",
		children: [/* @__PURE__ */ m("div", {
			className: "rg-actions__controls",
			children: N && C.length === 0 ? /* @__PURE__ */ m("button", {
				type: "button",
				className: "rg-action rg-action--quiet",
				onClick: () => g({ type: "yield" }),
				children: _("games.regicide.yieldBtn")
			}) : N ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("button", {
				type: "button",
				className: "rg-action",
				onClick: () => {
					w([]), E(null);
				},
				children: _("games.regicide.cancel")
			}), L ? /* @__PURE__ */ m("button", {
				type: "button",
				className: "rg-action rg-action--primary",
				disabled: T === null,
				onClick: () => {
					T !== null && (g({
						type: "jester",
						next: T
					}), w([]), E(null));
				},
				children: _("games.regicide.jesterPlay")
			}) : /* @__PURE__ */ m("button", {
				type: "button",
				className: "rg-action rg-action--primary",
				disabled: !R,
				onClick: () => {
					g({
						type: "play",
						cards: C
					}), w([]);
				},
				children: _("games.regicide.play")
			})] }) : P ? ie ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("button", {
				type: "button",
				className: "rg-action",
				disabled: C.length === 0,
				onClick: () => w([]),
				children: _("games.regicide.cancel")
			}), /* @__PURE__ */ m("button", {
				type: "button",
				className: "rg-action rg-action--primary",
				disabled: e.defendNeed === null || V < e.defendNeed,
				onClick: () => {
					g({
						type: "defend",
						cards: C
					}), w([]);
				},
				children: _("games.regicide.defendBtn")
			})] }) : /* @__PURE__ */ m(r, {
				className: "w-full min-h-12",
				label: _("games.regicide.succumb"),
				confirmLabel: _("games.regicide.succumbConfirm"),
				onConfirm: () => g({
					type: "defend",
					cards: D
				})
			}) : /* @__PURE__ */ m("span", {
				className: "rg-action rg-action--static",
				children: W
			})
		}), /* @__PURE__ */ h("div", {
			className: "rg-actions__hand",
			children: [
				/* @__PURE__ */ m("span", {
					ref: S,
					className: "rg-actions__measure",
					"aria-hidden": !0
				}),
				/* @__PURE__ */ h("div", {
					className: "rg-actions__hand-label",
					children: [/* @__PURE__ */ m("span", { children: _("games.regicide.yourHand") }), /* @__PURE__ */ h("span", {
						className: "font-mono tabular-nums",
						children: [
							D.length,
							" / ",
							e.handLimit
						]
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: "rg-actions__hand-scroll",
					children: /* @__PURE__ */ h("div", {
						className: "rg-actions__cards",
						children: [t && D.map((e) => /* @__PURE__ */ m("button", {
							type: "button",
							"aria-label": O(e) ? _("games.regicide.jesterAria") : _(ce[k(e)]) + " " + J[A(e) - 1],
							"aria-pressed": C.includes(e),
							disabled: !N && !P,
							onClick: () => H(e),
							children: /* @__PURE__ */ m(_e, {
								id: e,
								selected: C.includes(e)
							})
						}, e)), D.length === 0 && /* @__PURE__ */ m("span", {
							className: "rg-actions__empty",
							children: _("games.regicide.handEmpty")
						})]
					})
				})
			]
		})]
	});
	return /* @__PURE__ */ m("div", {
		className: "rg-screen",
		children: /* @__PURE__ */ m(c, {
			adaptive: !0,
			className: "rg-layout",
			banner: oe,
			actions: se,
			actionsHeight: "rg-actions-slot",
			scroll: !1,
			children: /* @__PURE__ */ h("div", {
				className: "rg-field",
				children: [/* @__PURE__ */ m(s, {
					kind: "sheen",
					base: "#dce9df",
					className: "rg-field__texture"
				}), /* @__PURE__ */ h("div", {
					className: "rg-field__table",
					children: [
						/* @__PURE__ */ h("div", {
							className: "rg-scene",
							children: [
								/* @__PURE__ */ m("span", {
									className: "rg-scene__eyebrow",
									children: _("games.regicide.currentRoyal")
								}),
								/* @__PURE__ */ m("div", {
									className: "rg-scene__piles",
									children: /* @__PURE__ */ h("div", {
										className: "rg-pile",
										children: [/* @__PURE__ */ m("span", {
											className: "rg-pile__label",
											children: _("games.regicide.castleLabel")
										}), /* @__PURE__ */ h("span", {
											className: "rg-pile__stack",
											children: [/* @__PURE__ */ m(fe, {
												kind: "castle",
												pile: !0
											}), /* @__PURE__ */ m("span", {
												className: "rg-pile__count",
												children: e.castleLeft
											})]
										})]
									})
								}),
								/* @__PURE__ */ m("div", {
									className: "rg-scene__enemy",
									children: /* @__PURE__ */ m("div", {
										ref: y,
										children: e.enemy ? /* @__PURE__ */ m(X, {
											id: e.enemy.card,
											size: "enemy",
											hp: e.enemy.hp,
											maxHp: e.enemy.maxHp,
											damagePreview: K ? z?.damage ?? 0 : 0,
											target: K
										}) : /* @__PURE__ */ m(Y, { className: "h-20 w-24 text-[#d5ab56]" })
									})
								}),
								/* @__PURE__ */ h("div", {
									className: "rg-scene__piles",
									children: [/* @__PURE__ */ h("div", {
										className: "rg-pile",
										children: [/* @__PURE__ */ m("span", {
											className: "rg-pile__label",
											children: _("games.regicide.tavernLabel")
										}), /* @__PURE__ */ h("span", {
											ref: b,
											className: "rg-pile__stack",
											children: [/* @__PURE__ */ m(fe, { pile: !0 }), /* @__PURE__ */ m("span", {
												className: "rg-pile__count",
												children: e.tavernCount
											})]
										})]
									}), /* @__PURE__ */ h("div", {
										className: "rg-pile rg-pile--discard" + (ae ? " rg-pile--target" : ""),
										children: [/* @__PURE__ */ m("span", {
											className: "rg-pile__label",
											children: _("games.regicide.discardLabel")
										}), /* @__PURE__ */ h("span", {
											ref: x,
											className: "rg-pile__stack",
											children: [e.discard.length > 0 ? /* @__PURE__ */ m(X, {
												id: e.discard[e.discard.length - 1],
												size: "mini"
											}) : /* @__PURE__ */ m("span", {
												className: "rg-discard-empty",
												"aria-hidden": !0,
												children: "↧"
											}), /* @__PURE__ */ m("span", {
												className: "rg-pile__count",
												children: e.discard.length
											})]
										})]
									})]
								})
							]
						}),
						/* @__PURE__ */ h("div", {
							className: "rg-stats",
							children: [
								/* @__PURE__ */ h("span", {
									className: "rg-stat",
									children: [
										/* @__PURE__ */ m("span", {
											className: "rg-stat__icon",
											"aria-hidden": !0,
											children: "⚔"
										}),
										/* @__PURE__ */ m("span", { children: _("games.regicide.attackLabel") }),
										e.enemy?.shield ? /* @__PURE__ */ m("span", {
											className: "rg-stat__old font-mono tabular-nums",
											children: e.enemy.atk
										}) : null,
										/* @__PURE__ */ m("strong", {
											className: "font-mono tabular-nums",
											children: /* @__PURE__ */ m(a, { value: Math.max(0, (e.enemy?.atk ?? 0) - (e.enemy?.shield ?? 0)) })
										})
									]
								}),
								/* @__PURE__ */ h("span", {
									className: "rg-stat rg-stat--shield",
									children: [
										/* @__PURE__ */ m("span", {
											className: "rg-stat__icon",
											"aria-hidden": !0,
											children: "♠"
										}),
										/* @__PURE__ */ m("span", { children: _("games.regicide.shieldLabel") }),
										/* @__PURE__ */ h("strong", {
											className: "font-mono tabular-nums",
											children: [e.enemy?.shield ?? 0, K && z && z.shieldUp > 0 ? " → " + ((e.enemy?.shield ?? 0) + z.shieldUp) : ""]
										})
									]
								}),
								/* @__PURE__ */ h("span", {
									className: "rg-stat rg-stat--immune",
									children: [/* @__PURE__ */ m("span", {
										className: "rg-stat__icon",
										"aria-hidden": !0,
										children: e.enemy ? q[k(e.enemy.card)] : "✦"
									}), /* @__PURE__ */ m("span", { children: e.enemy?.immune ? _("games.regicide.immuneLabel") : _("games.regicide.immuneBroken") })]
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							className: "rg-forecast",
							role: "status",
							children: N && C.length === 0 ? /* @__PURE__ */ h("span", {
								className: "rg-forecast__idle",
								children: [/* @__PURE__ */ m(Y, {}), _("games.regicide.chooseHand")]
							}) : N && L ? /* @__PURE__ */ h("div", {
								className: "rg-forecast__panel",
								children: [/* @__PURE__ */ m("strong", {
									className: "rg-forecast__value",
									children: _("games.regicide.jesterPick")
								}), /* @__PURE__ */ h("span", {
									className: "rg-forecast__detail",
									children: [/* @__PURE__ */ m("span", { children: T ? v(T) : _("games.regicide.nextUnset") }), /* @__PURE__ */ m("small", { children: _("games.regicide.jesterHint") })]
								})]
							}) : N && z ? /* @__PURE__ */ h("div", {
								className: "rg-forecast__panel",
								children: [/* @__PURE__ */ m("strong", {
									className: "rg-forecast__value",
									children: _("games.regicide.previewDmg", { n: z.damage })
								}), /* @__PURE__ */ h("span", {
									className: "rg-forecast__detail",
									children: [/* @__PURE__ */ m("span", { children: G || _("games.regicide.plainAttack") }), /* @__PURE__ */ m("small", { children: _("games.regicide.attackTarget") })]
								})]
							}) : N ? /* @__PURE__ */ h("div", {
								className: "rg-forecast__panel rg-forecast__panel--warn",
								children: [/* @__PURE__ */ m("strong", {
									className: "rg-forecast__value",
									children: _("games.regicide.badCombo")
								}), /* @__PURE__ */ m("span", {
									className: "rg-forecast__detail",
									children: /* @__PURE__ */ m("span", { children: _("games.regicide.comboHint") })
								})]
							}) : P ? /* @__PURE__ */ h("div", {
								className: "rg-forecast__panel" + (V < (e.defendNeed ?? 0) ? " rg-forecast__panel--warn" : ""),
								children: [/* @__PURE__ */ m("strong", {
									className: "rg-forecast__value",
									children: _("games.regicide.defendSum", {
										a: V,
										b: e.defendNeed ?? 0
									})
								}), /* @__PURE__ */ m("span", {
									className: "rg-forecast__detail",
									children: /* @__PURE__ */ m("span", { children: _(ae ? "games.regicide.defendTarget" : ie ? "games.regicide.defendHint" : "games.regicide.succumb") })
								})]
							}) : /* @__PURE__ */ h("span", {
								className: "rg-forecast__idle",
								children: [/* @__PURE__ */ m(Y, {}), _("games.regicide.waitHint")]
							})
						}),
						/* @__PURE__ */ m("div", {
							className: "rg-log",
							children: /* @__PURE__ */ m(ye, {
								log: e.log,
								nameOf: v
							})
						})
					]
				})]
			})
		})
	});
}
function _e({ id: e, selected: t }) {
	let { ref: n, hidden: r } = i(`hand:${e}`);
	return /* @__PURE__ */ m("span", {
		ref: n,
		className: "inline-flex",
		style: { visibility: r ? "hidden" : void 0 },
		children: /* @__PURE__ */ m(X, {
			id: e,
			size: "hand",
			selected: t,
			elevated: !0
		})
	});
}
var ve = (e) => `${q[k(e)]}${J[A(e) - 1]}`;
function ye({ log: e, nameOf: t }) {
	let n = o();
	return /* @__PURE__ */ m(l, {
		log: e,
		line: (e) => {
			switch (e.k) {
				case "play": {
					let r = e.cards.map(ve).join("+"), i = e.doubled ? n("games.regicide.logPlayDoubled", {
						name: t(e.rid),
						cards: r,
						dmg: e.dmg
					}) : n("games.regicide.logPlay", {
						name: t(e.rid),
						cards: r,
						dmg: e.dmg
					}), a = [
						e.heal > 0 ? n("games.regicide.logExtraHeart", { n: e.heal }) : "",
						e.draw > 0 ? n("games.regicide.logExtraDiamond", { n: e.draw }) : "",
						e.shieldUp > 0 ? n("games.regicide.logExtraSpade", { n: e.shieldUp }) : ""
					].filter(Boolean).join(" ");
					return a ? `${i} · ${a}` : i;
				}
				case "defend": return n("games.regicide.logDefend", {
					name: t(e.rid),
					n: e.count,
					need: e.need
				});
				case "yield": return n("games.regicide.logYield", { name: t(e.rid) });
				case "jester": return n("games.regicide.logJester", {
					name: t(e.rid),
					next: t(e.next)
				});
				case "slain": return e.exact ? n("games.regicide.logSlainExact", { card: ve(e.card) }) : n("games.regicide.logSlain", { card: ve(e.card) });
				case "fallen": return n("games.regicide.logFallen", { name: t(e.rid) });
			}
		}
	});
}
//#endregion
//#region src/games/regicide/bot.ts
var Z = (e) => e.reduce((e, t) => e + j(t), 0);
function be(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function xe(e) {
	let t = e.filter((e) => !O(e)), n = [];
	for (let e = 1; e < 1 << t.length; e += 1) {
		let r = t.filter((t, n) => e & 1 << n);
		B(r) && n.push(r);
	}
	return n;
}
function Se(e, t, n = -1, r = !1) {
	let i = null, a = null;
	for (let o = 1; o < 1 << e.length; o += 1) {
		let s = e.filter((e, t) => o & 1 << t), c = Z(s);
		if (c < t) continue;
		let l = [
			c,
			-(r ? s.filter((e) => k(e) === n).length : 0),
			s.filter((e) => j(e) >= 10).length,
			s.length
		];
		(a === null || l[0] < a[0] || l[0] === a[0] && (l[1] < a[1] || l[1] === a[1] && (l[2] < a[2] || l[2] === a[2] && l[3] < a[3]))) && (i = s, a = l);
	}
	return i;
}
function Ce(e, t, n, r) {
	let i = ne(t, k(r.card), r.immune), a = r.hp - i.damage, o = a <= 0, s = Math.max(0, r.atk - r.shield - i.shieldUp), c = o ? [] : Se(n, s, k(r.card), r.immune), l = o || c !== null, u = j(r.card), d = Math.min(i.damage, r.hp) * 1.2;
	o && (d += 150 + u * 8), a === 0 && (d += 100 + u * 4);
	let f = Math.max(0, r.atk - r.shield);
	if (i.shieldUp > 0 && (d += Math.min(i.shieldUp, f) * (f >= 15 ? 4 : 2)), i.draw > 0) {
		let t = e.players.reduce((t, n) => t + Math.max(0, e.handLimit - n.handCount), 0);
		d += i.draw * (n.length <= 2 ? 4 : 1.5 + t / (e.handLimit * e.players.length) * 3);
	}
	return i.heal > 0 && (d += i.heal * (e.discard.length > e.tavernCount ? 2.5 : .5)), d -= Z(t) + (c ? Z(c) : 0), {
		score: d,
		survives: l
	};
}
var we = (e, t) => {
	let n = e.public, r = e.private;
	if (n.phase === "done" || n.turn !== t.rid || !r) return null;
	let i = r.hand;
	if (n.phase === "defend") {
		let e = n.defendNeed ?? 0;
		if (Z(i) < e) return { action: {
			type: "defend",
			cards: i
		} };
		if (t.difficulty === "weak") {
			let t = [...i].sort((e, t) => j(t) - j(e)), n = [], r = 0;
			for (let i of t) {
				if (r >= e) break;
				n.push(i), r += j(i);
			}
			return { action: {
				type: "defend",
				cards: n
			} };
		}
		let r = Se(i, e, n.enemy ? k(n.enemy.card) : -1, n.enemy?.immune ?? !1);
		return r ? { action: {
			type: "defend",
			cards: r
		} } : { action: {
			type: "defend",
			cards: i
		} };
	}
	if (i.length === 0) return { action: { type: "yield" } };
	let a = i.find(O), o = xe(i), s = [...n.players].sort((e, t) => t.handCount - e.handCount)[0]?.rid ?? t.rid;
	if (t.difficulty === "weak") return a !== void 0 && (o.length === 0 || be([
		!0,
		!1,
		!1,
		!1
	])) ? { action: {
		type: "jester",
		next: be(n.players.map((e) => e.rid))
	} } : o.length === 0 ? { action: { type: "yield" } } : { action: {
		type: "play",
		cards: be(o)
	} };
	let c = n.enemy;
	if (!c) return null;
	let l = Se(i, Math.max(0, c.atk - c.shield), k(c.card), c.immune), u = c.atk - c.shield > 0 && l ? -Z(l) : -Infinity, d = null, f = -Infinity;
	for (let e of o) {
		let { score: t, survives: r } = Ce(n, e, i.filter((t) => !e.includes(t)), c), a = r ? t : t - 1e4;
		a > f && (f = a, d = e);
	}
	if (a !== void 0) {
		let e = f < -9e3 && u === -Infinity, t = c.immune ? Z(i.filter((e) => k(e) === k(c.card))) : 0;
		if (e || t >= 10) return { action: {
			type: "jester",
			next: s
		} };
	}
	return d && f >= u ? { action: {
		type: "play",
		cards: d
	} } : u > -Infinity ? { action: { type: "yield" } } : o.length > 0 ? { action: {
		type: "play",
		cards: o.reduce((e, t) => Z(e) <= Z(t) ? e : t)
	} } : { action: { type: "yield" } };
};
//#endregion
//#region src/games/regicide/fx.tsx
function Q(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function Te(e) {
	return !Array.isArray(e) || !e.every((e) => typeof e == "number") ? null : e;
}
function $(e) {
	return e ? {
		width: e.w,
		height: e.h
	} : void 0;
}
function Ee(e, t, n) {
	if (!e) return null;
	let r = t.secret, i = r ? Te(r.cards) : null;
	if (i) {
		let t = [], r = [];
		for (let [a, o] of i.entries()) {
			let i = n.anchor(`hand:${o}`);
			i && (r.push(`hand:${o}`), t.push(/* @__PURE__ */ m(_, {
				from: e,
				to: i,
				ms: 320,
				delay: a * 50,
				children: /* @__PURE__ */ m(X, {
					id: o,
					size: "hand",
					elevated: !0,
					dimensions: $(i)
				})
			}, o)));
		}
		return t.length ? {
			ms: 320 + t.length * 50,
			node: t,
			hide: r
		} : null;
	}
	let a = Q(n, t.rid);
	if (!a) return null;
	let o = t.data?.count, s = typeof o == "number" ? o : 1;
	return {
		ms: 320 + s * 50,
		node: Array.from({ length: s }, (t, r) => /* @__PURE__ */ m(_, {
			from: e,
			to: a,
			ms: 320,
			delay: r * 50,
			children: /* @__PURE__ */ m(fe, { dimensions: $(n.anchor("hand-size")) })
		}, r))
	};
}
var De = {
	deal(e, t) {
		return Ee(t.anchor("tavern"), e, t);
	},
	draw(e, t) {
		return Ee(t.anchor("tavern"), e, t);
	},
	attack(e, t) {
		let n = e.data, r = Te(n?.cards), i = t.anchor("enemy"), a = Q(t, e.rid);
		if (!r || !i || !a) return null;
		let o = r.map((e, n) => /* @__PURE__ */ m(_, {
			from: a,
			to: i,
			ms: 380,
			delay: n * 60,
			children: /* @__PURE__ */ m(X, {
				id: e,
				size: "hand",
				elevated: !0,
				dimensions: $(t.anchor("hand-size"))
			})
		}, e)), s = 300 + r.length * 60;
		return o.push(/* @__PURE__ */ m(v, {
			at: i,
			ms: 500,
			delay: s
		}, "hit")), typeof n?.damage == "number" && n.damage > 0 && o.push(/* @__PURE__ */ m(g, {
			at: i,
			ms: 900,
			delay: s,
			children: `-${n.damage}`
		}, "dmg")), {
			ms: s + 700,
			node: o
		};
	},
	suffer(e, t) {
		let n = e.data, r = Te(n?.cards) ?? [], i = t.anchor("discard"), a = Q(t, e.rid);
		return !i || !a || r.length === 0 ? null : {
			ms: 420 + r.length * 50,
			node: r.map((e, n) => /* @__PURE__ */ m(_, {
				from: a,
				to: i,
				ms: 400,
				delay: n * 50,
				children: /* @__PURE__ */ m(X, {
					id: e,
					size: "hand",
					elevated: !0,
					dimensions: $(t.anchor("hand-size"))
				})
			}, e))
		};
	},
	slain(e, t) {
		let n = e.data, r = t.anchor("enemy"), i = t.anchor(n?.exact ? "tavern" : "discard");
		return !r || !i || typeof n?.card != "number" ? null : {
			ms: 520,
			node: /* @__PURE__ */ m(_, {
				from: r,
				to: i,
				ms: 500,
				children: /* @__PURE__ */ m(X, {
					id: n.card,
					size: "hand",
					elevated: !0,
					dimensions: $(r)
				})
			})
		};
	},
	jester(e, t) {
		let n = t.anchor("enemy");
		return n ? {
			ms: 800,
			node: [/* @__PURE__ */ m(v, {
				at: n,
				ms: 600
			}, "p"), /* @__PURE__ */ m(g, {
				at: n,
				ms: 800,
				children: "🃏"
			}, "j")]
		} : null;
	},
	yield(e, t) {
		let n = Q(t, e.rid);
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ m(v, {
				at: n,
				ms: 500
			})
		} : null;
	},
	fallen(e, t) {
		let n = Q(t, e.rid);
		return n ? {
			ms: 1e3,
			node: /* @__PURE__ */ m(g, {
				at: n,
				ms: 1e3,
				children: "💀"
			})
		} : null;
	}
};
//#endregion
//#region src/games/regicide/game-over.tsx
function Oe({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let a = o(), s = t, c = e.winner.length > 0, l = r ?? i;
	return /* @__PURE__ */ m("div", {
		className: "rg-over-shell",
		children: /* @__PURE__ */ h("div", {
			className: "rg-over" + (c ? " rg-over--win" : " rg-over--lose"),
			children: [
				c && /* @__PURE__ */ m(x, {}),
				/* @__PURE__ */ h("div", {
					className: "rg-over__hero",
					children: [
						/* @__PURE__ */ m("span", {
							className: "rg-over__seal",
							children: a(c ? "games.regicide.overSealWin" : "games.regicide.overSealLose")
						}),
						/* @__PURE__ */ m(Y, { className: "rg-over__crest" }),
						/* @__PURE__ */ m("h1", { children: a(c ? "games.regicide.overWin" : "games.regicide.overLose") }),
						/* @__PURE__ */ m("p", { children: a("games.regicide.overProgress", { n: s.kills }) }),
						/* @__PURE__ */ m("div", {
							className: "rg-over__track",
							"aria-label": a("games.regicide.overProgress", { n: s.kills }),
							children: Array.from({ length: 12 }, (e, t) => /* @__PURE__ */ m("span", {
								className: "rg-over__pip" + (t < s.kills ? " rg-over__pip--slain" : ""),
								"aria-hidden": !0,
								children: t < 4 ? "J" : t < 8 ? "Q" : "K"
							}, t))
						})
					]
				}),
				/* @__PURE__ */ h("div", {
					className: "rg-over__party",
					children: [/* @__PURE__ */ m("p", { children: a("games.regicide.overParty") }), /* @__PURE__ */ m("ul", { children: e.ranking.map((e) => {
						let t = n.find((t) => t.rid === e);
						return /* @__PURE__ */ h("li", { children: [
							t && /* @__PURE__ */ m("span", {
								className: "rg-over__avatar",
								style: { background: b[t.colorIndex % b.length].hex },
								children: /* @__PURE__ */ m("img", {
									src: y[t.avatar % y.length],
									alt: ""
								})
							}),
							/* @__PURE__ */ m("span", {
								className: "rg-over__name",
								children: t?.name ?? e
							}),
							/* @__PURE__ */ m("span", {
								className: "rg-over__mark",
								"aria-hidden": !0,
								children: c ? "✦" : "×"
							})
						] }, e);
					}) })]
				}),
				l ? /* @__PURE__ */ h("div", {
					className: "rg-over__actions safe-b",
					children: [r && /* @__PURE__ */ m("button", {
						className: "btn-base w-full cursor-pointer text-white",
						style: { background: ee.accent },
						onClick: r,
						children: a("session.result.playAgain")
					}), i && /* @__PURE__ */ m("button", {
						className: "btn-quiet w-full cursor-pointer",
						onClick: i,
						children: a("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ m("p", {
					className: "rg-over__wait safe-b",
					children: a("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/regicide/entry.tsx
var ke = {
	definition: se,
	View: pe,
	bot: we,
	fx: De,
	OverView: Oe,
	locales: {
		zh: {
			name: "弑君者",
			desc: "合作讨伐:全队接力挑战 12 位 J/Q/K 君王,扑克牌就是武器",
			rules: "目标:全队合作,依次击败城堡中的 12 位君王(4 张 J、4 张 Q、4 张 K);击败最后的 K 即全员获胜。\n牌的点数：A 为 1 点，2 至 10 按牌面数字计算，J 为 10 点，Q 为 15 点，K 为 20 点。\n敌人的生命值：J 为 20 点，Q 为 30 点，K 为 40 点。\n流程(轮到你):\n· 打出一张牌进行攻击；也可以打出多张点数相同的牌，但点数合计不能超过 10 点，或将一张 A 与任意另一张牌一同打出。\n· 敌人未被击败时，会发动反击。你须弃置点数合计不低于敌人攻击力的手牌；无法满足要求时，全队立即落败。\n· 也可以放弃攻击,直接承受反击。\n花色能力(按打出牌的面值生效):\n· ♣ 本次攻击伤害翻倍。\n· ♥ 从弃牌堆中随机取出与本次打出的红桃牌点数合计相同数量的卡牌，将其洗入牌库；弃牌不足时，使用全部弃牌。\n· ♦ 从当前玩家开始，全队按顺序轮流各抽一张牌，抽取的总张数等于本次打出的方块牌点数合计。手牌已达到上限的玩家跳过；牌库为空或全队手牌均已满时，停止抽牌。\n· ♠ 永久降低当前敌人的攻击力。\n特殊规则:\n· 敌人免疫自己的花色:该花色的牌只算伤害,不发动能力。\n· 小丑只能单独打出:解除当前敌人的免疫、跳过本次反击,并指定下一位行动者。\n· 伤害恰好等于敌人剩余生命时,敌人放回牌库顶,之后可被抽成手牌;否则进弃牌堆。\n· 手牌上限：2 人游戏中每人最多持有 7 张手牌，3 人时为 6 张，4 人时为 5 张。\n· 小丑数量：3 人游戏使用 1 张，4 人游戏使用 2 张。",
			progress: "已击败 {{n}}/12",
			royalJack: "腐化先锋",
			royalQueen: "腐化女王",
			royalKing: "腐化暴君",
			health: "生命",
			currentRoyal: "当前君王",
			castleLabel: "城堡",
			tavernLabel: "酒馆",
			discardLabel: "弃牌",
			attackLabel: "反击",
			shieldLabel: "护盾",
			immuneLabel: "免疫",
			immuneBroken: "免疫解除",
			chooseHand: "从手牌选牌,围攻当前君王",
			yourHand: "你的手牌",
			nextUnset: "点选一位玩家的名牌",
			jesterHint: "小丑解除免疫,且跳过本次反击",
			plainAttack: "普通攻击",
			attackTarget: "有效攻击 · 命中君王",
			comboHint: "同点数合计≤10,或 A 带一张",
			defendTarget: "弃牌堆已就绪",
			defendHint: "选牌合计达到反击值即可承受",
			waitHint: "等队友行动,留意君王状态",
			stripHand: "{{n}} 张",
			immuneChip: "免疫 {{suit}}",
			turnYou: "轮到你 · 出牌或跳过",
			turnWait: "等 {{name}} 出牌…",
			defendYou: "敌人反击 · 弃牌合计 ≥ {{n}}",
			defendWait: "等 {{name}} 承受反击…",
			previewDmg: "伤害 {{n}}",
			previewClub: "♣×2",
			previewSpade: "♠护盾+{{n}}",
			previewHeart: "♥回血 {{n}}",
			previewDiamond: "♦抽牌 {{n}}",
			badCombo: "这组牌出不了",
			cancel: "取消",
			play: "攻击",
			jesterPick: "指定下一位",
			jesterPlay: "打出小丑",
			jesterAria: "小丑",
			defendSum: "已选 {{a}} / 需 {{b}}",
			defendBtn: "弃牌承受",
			succumb: "弃光也不够…",
			succumbConfirm: "全员阵亡,确认?",
			yieldBtn: "跳过攻击(直接承受反击)",
			handEmpty: "手牌已空",
			overWin: "弑君成功!",
			overLose: "全员阵亡",
			overProgress: "击败 {{n}}/12 位君王",
			overSealWin: "弑君完成",
			overSealLose: "讨伐失败",
			overParty: "讨伐队伍",
			suitSpade: "黑桃",
			suitHeart: "红桃",
			suitDiamond: "方块",
			suitClub: "梅花",
			pileCastle: "城堡 {{n}}",
			pileTavern: "酒馆 {{n}}",
			pileDiscard: "弃牌 {{n}}",
			logAria: "对局日志",
			logPlay: "{{name}} 打出 {{cards}},{{dmg}} 伤害",
			logPlayDoubled: "{{name}} 打出 {{cards}},♣翻倍 {{dmg}} 伤害",
			logDefend: "{{name}} 弃 {{n}} 张承受反击(需 {{need}})",
			logYield: "{{name}} 跳过,承受反击",
			logJester: "{{name}} 打出小丑,{{next}} 接续",
			logSlain: "击倒了 {{card}}",
			logSlainExact: "完美击杀 {{card}},回到牌库顶",
			logFallen: "{{name}} 承受不住——全员阵亡",
			logExtraHeart: "♥洗回 {{n}}",
			logExtraDiamond: "♦补 {{n}} 张",
			logExtraSpade: "♠盾+{{n}}",
			errDone: "对局已结束",
			errNotYourTurn: "现在轮不到你",
			errBadCards: "手里没有这些牌",
			errBadCombo: "这组牌出不了:同点数合计≤10,或 A 带一张",
			errDefendMore: "弃牌合计还不够",
			errNoJester: "手里没有小丑",
			errBadNext: "没有这位玩家"
		},
		en: {
			name: "Regicide",
			desc: "Co-op card battle: take down 12 royal J/Q/K together",
			rules: "Goal: work together to defeat the 12 royals in the castle (4 Jacks, 4 Queens, 4 Kings); defeating the final King wins the game for everyone.\nCard values: An Ace is worth 1 point; cards numbered 2–10 use their printed number. A Jack is worth 10 points, a Queen 15 points, and a King 20 points.\nEnemy health: A Jack has 20 health, a Queen 30 health, and a King 40 health.\nOn your turn:\n· Play one card to attack; you may also play several cards of the same rank (total ≤ 10), or an Ace together with any one card.\n· If the enemy survives, it strikes back: discard cards totaling at least its attack; if you cannot, everyone loses.\n· You may also yield and take the counterattack without attacking.\nSuit powers (scaled by the values played):\n· ♣ doubles this attack’s damage.\n· ♥: Randomly take a number of cards from the discard pile equal to the total value of Hearts played, then shuffle them into the deck. Use all discards if there are not enough.\n· ♦: Starting with the current player, each player draws one card in turn, up to a total number of cards equal to the value of Diamonds played. Skip full hands, and stop if the deck is empty or every hand is full.\n· ♠ permanently lowers the current enemy’s attack.\nSpecial rules:\n· An enemy is immune to its own suit: cards of that suit deal damage but grant no power.\n· A Jester must be played alone: it breaks the current enemy’s immunity, skips the counterattack, and lets you choose who acts next.\n· Damage exactly equal to the enemy’s remaining health is a perfect kill: the royal goes on top of the deck and can later be drawn as a hand card; otherwise it is discarded.\n· Hand limit: 7 cards with 2 players, 6 with 3, 5 with 4. Jesters: 1 with 3 players, 2 with 4.",
			progress: "Slain {{n}}/12",
			royalJack: "Corrupted Jack",
			royalQueen: "Corrupted Queen",
			royalKing: "Corrupted King",
			health: "HP",
			currentRoyal: "CURRENT ROYAL",
			castleLabel: "Castle",
			tavernLabel: "Tavern",
			discardLabel: "Discard",
			attackLabel: "Strike",
			shieldLabel: "Shield",
			immuneLabel: "Immune",
			immuneBroken: "No immunity",
			chooseHand: "Choose cards to attack the royal",
			yourHand: "Your hand",
			nextUnset: "Choose a player plate",
			jesterHint: "Jester breaks immunity and skips the strike",
			plainAttack: "Plain attack",
			attackTarget: "Valid attack · royal targeted",
			comboHint: "Same rank ≤10, or an Ace plus one card",
			defendTarget: "Discard pile is ready",
			defendHint: "Pick enough value to absorb the strike",
			waitHint: "Watch the royal while your ally acts",
			stripHand: "{{n}} cards",
			immuneChip: "Immune to {{suit}}",
			turnYou: "Your turn · attack or yield",
			turnWait: "Waiting for {{name}}…",
			defendYou: "Counterattack · discard at least {{n}}",
			defendWait: "Waiting for {{name}} to suffer the hit…",
			previewDmg: "DMG {{n}}",
			previewClub: "♣×2",
			previewSpade: "♠shield +{{n}}",
			previewHeart: "♥heal {{n}}",
			previewDiamond: "♦draw {{n}}",
			badCombo: "Not a legal play",
			cancel: "Cancel",
			play: "Attack",
			jesterPick: "Pick the next player",
			jesterPlay: "Play Jester",
			jesterAria: "Jester",
			defendSum: "Picked {{a}} / need {{b}}",
			defendBtn: "Discard",
			succumb: "Not enough even all-in…",
			succumbConfirm: "Everyone falls. Sure?",
			yieldBtn: "Yield (take the hit)",
			handEmpty: "Hand empty",
			overWin: "Regicide complete!",
			overLose: "All fallen",
			overProgress: "Slain {{n}}/12 royals",
			overSealWin: "REGICIDE COMPLETE",
			overSealLose: "QUEST FAILED",
			overParty: "The party",
			suitSpade: "Spades",
			suitHeart: "Hearts",
			suitDiamond: "Diamonds",
			suitClub: "Clubs",
			pileCastle: "Castle {{n}}",
			pileTavern: "Tavern {{n}}",
			pileDiscard: "Discard {{n}}",
			logAria: "Game log",
			logPlay: "{{name}} played {{cards}} for {{dmg}}",
			logPlayDoubled: "{{name}} played {{cards}} for {{dmg}} (♣ doubled)",
			logDefend: "{{name}} discarded {{n}} to defend (needs {{need}})",
			logYield: "{{name}} yielded and took the hit",
			logJester: "{{name}} played a Jester, {{next}} is up",
			logSlain: "{{card}} defeated",
			logSlainExact: "{{card}} exact-killed, back on the deck",
			logFallen: "{{name}} fell — the party is defeated",
			logExtraHeart: "♥{{n}} shuffled back",
			logExtraDiamond: "♦+{{n}} cards",
			logExtraSpade: "♠+{{n}} shield",
			errDone: "Game over",
			errNotYourTurn: "Not your turn",
			errBadCards: "Those cards are not in your hand",
			errBadCombo: "Illegal play: same rank ≤ 10, or an Ace plus one card",
			errDefendMore: "Not enough to suffer the hit",
			errNoJester: "No Jester in hand",
			errBadNext: "No such player"
		}
	}
};
//#endregion
export { ke as default };
