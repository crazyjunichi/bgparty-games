import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { useT as o } from "@bgparty/sdk/i18n";
import { IconCheck as s, IconClose as c, IconEye as l, IconHistory as u, IconRecenter as d, IconRotate as f, IconTrash as p, IconZoomIn as m, IconZoomOut as h } from "@bgparty/sdk/icons";
import { playTurn as ee, useSoundEdge as te } from "@bgparty/sdk/sfx";
import { useWakeLock as g } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as ne } from "@bgparty/sdk/ui/game-screen";
import { Texture as re } from "@bgparty/sdk/texture";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { OptionRadio as b, OptionSection as x } from "@bgparty/sdk/ui/game-options";
//#region src/games/tantrix/data.ts
var S = [
	"R",
	"Y",
	"G",
	"B"
], C = {
	R: "#ef5054",
	Y: "#ffd54b",
	G: "#57c988",
	B: "#5398ff"
}, w = /* @__PURE__ */ ".YYBRBR.YYBRRB.RRBBYY.YRBRYB.YYRBBR.RBYBRY.BBYRYR.BBRYRY.YBRBYR.YYRBRB.RRBYBY.RRYBYB.BBYRRY.YYBBRR.GGRYYR.GGYRRY.YYGRGR.YYRGRG.RRGYGY.RRYGYG.GGRRYY.YYGRRG.GYYRRG.GGBRRB.GGRRBB.BBGRRG.RRBGBG.GGBBRR.RRGBGB.GGRBBR.GGRYRY.RYGYRG.GGYRYR.GYRYGR.GRYRGY.GGRBRB.BBGRGR.BBRGRG.RBGBRG.RGBGRB.GGBRBR.BGRGBR.GGBBYY.BGYGBY.GGYYBB.GGBYBY.GGYBBY.GGBYYB.YYGBBG.YGBGYB.BYGYBG.GGYBYB.YYGBGB.YYBGBG.BBGYGY.BBYGYG".split("."), T = [
	...[
		"Y",
		"R",
		"R",
		"B",
		"B",
		"B",
		"Y",
		"R",
		"B",
		"Y"
	].map((e, t) => ({
		id: `d${t + 1}`,
		series: "discovery",
		tiles: Array.from({ length: Math.min(t + 3, 10) }, (e, t) => t + 1),
		kind: "loop",
		targets: [e],
		allTiles: !0,
		noHoles: !1
	})),
	{
		id: "r1",
		series: "rainbow",
		tiles: [
			3,
			5,
			8,
			12,
			14,
			43,
			46,
			50,
			52,
			54
		],
		kind: "loop",
		targets: [...S],
		allTiles: !0,
		noHoles: !0
	},
	{
		id: "r2",
		series: "rainbow",
		tiles: [
			19,
			21,
			24,
			25,
			29,
			31,
			32,
			40,
			41,
			42
		],
		kind: "loop",
		targets: [...S],
		allTiles: !0,
		noHoles: !0
	},
	{
		id: "r3",
		series: "rainbow",
		tiles: [
			2,
			11,
			15,
			17,
			20,
			30,
			38,
			39,
			44,
			45,
			51,
			56
		],
		kind: "doubleLoop",
		targets: [...S],
		allTiles: !1,
		noHoles: !0
	},
	{
		id: "r4",
		series: "rainbow",
		tiles: [
			18,
			22,
			23,
			26,
			27,
			33,
			34,
			35,
			36,
			47,
			53,
			55
		],
		kind: "loop",
		targets: [...S],
		allTiles: !1,
		noHoles: !0
	},
	{
		id: "r5",
		series: "rainbow",
		tiles: [
			1,
			4,
			6,
			7,
			9,
			10,
			13,
			16,
			28,
			37,
			48,
			49
		],
		kind: "doubleLine",
		targets: [
			"R",
			"Y",
			"B"
		],
		allTiles: !1,
		noHoles: !0
	}
];
function E(e) {
	return T.find((t) => t.id === e) ?? T[0];
}
//#endregion
//#region src/games/tantrix/hex.ts
var D = [
	[1, 0],
	[0, 1],
	[-1, 1],
	[-1, 0],
	[0, -1],
	[1, -1]
], O = (e, t) => `${e},${t}`, k = (e) => e.split(",").map(Number);
function A(e, t) {
	let [n, r] = k(e), [i, a] = D[(t + 6) % 6];
	return O(n + i, r + a);
}
var j = (e) => Array.from({ length: 6 }, (t, n) => w[e.tile][(n - e.rot + 6) % 6]), M = (e, t) => D.flatMap((n, r) => e[A(t, r)] ? [r] : []);
function ie(e) {
	let t = Object.keys(e);
	if (!t.length) return ["0,0"];
	let n = /* @__PURE__ */ new Set();
	for (let r of t) for (let t = 0; t < 6; t++) {
		let i = A(r, t);
		e[i] || n.add(i);
	}
	return [...n];
}
var N = (e) => ie(e).filter((t) => M(e, t).length >= 3);
function P(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of N(e)) for (let r = 0; r < 6; r++) if (!e[A(n, r)]) for (let i of [-1, 1]) {
		if (!e[A(n, r + i)]) continue;
		let a = A(n, r);
		for (let n = 0; n < 56 && !e[a] && (e[A(a, r + i)] || e[A(a, r + i * 2)]); n++, a = A(a, r)) t.add(a);
	}
	return t;
}
function F(e, t, n = !0) {
	let r = O(t.q, t.r);
	if (e[r]) return !1;
	let i = M(e, r);
	if (n && Object.keys(e).length && !i.length) return !1;
	let a = j(t);
	return i.every((t) => a[t] === j(e[A(r, t)])[(t + 3) % 6]);
}
function I(e, t, n, r) {
	if (!F(e, t)) return !1;
	if (!n) return !0;
	let i = O(t.q, t.r);
	if ((r ?? P(e)).has(i)) return !1;
	let a = {
		...e,
		[i]: {
			tile: t.tile,
			rot: t.rot
		}
	};
	for (let e = 0; e < 6; e++) {
		let t = A(i, e);
		if (a[t]) continue;
		let n = M(a, t);
		if (n.length >= 4) return !1;
		if (n.length === 3) {
			let e = n.map((e) => j(a[A(t, e)])[(e + 3) % 6]);
			if (new Set(e).size === 1) return !1;
		}
	}
	return !0;
}
function L(e, t, n, r = !1) {
	let i = r ? N(e) : ie(e), a = n ? P(e) : /* @__PURE__ */ new Set(), o = [];
	for (let r of t) for (let t of i) {
		let [i, s] = k(t);
		for (let t = 0; t < 6; t++) {
			let c = {
				tile: r,
				q: i,
				r: s,
				rot: t
			};
			I(e, c, n, a) && o.push(c);
		}
	}
	return o;
}
function R(e, t) {
	let n = new Set(Object.keys(e).filter((n) => j(e[n]).includes(t))), r = [];
	for (let i of [...n]) {
		if (!n.delete(i)) continue;
		let a = [i], o = !0;
		for (let r = 0; r < a.length; r++) {
			let i = a[r], s = j(e[i]);
			for (let r = 0; r < 6; r++) {
				if (s[r] !== t) continue;
				let c = A(i, r);
				!e[c] || j(e[c])[(r + 3) % 6] !== t ? o = !1 : n.delete(c) && a.push(c);
			}
		}
		r.push({
			tiles: a,
			loop: o
		});
	}
	return r;
}
function z(e, t) {
	let n = R(e, t), r = Math.max(0, ...n.filter((e) => !e.loop).map((e) => e.tiles.length)), i = Math.max(0, ...n.filter((e) => e.loop).map((e) => e.tiles.length));
	return {
		line: r,
		loop: i,
		score: Math.max(r, i * 2)
	};
}
function B(e) {
	let t = Object.keys(e);
	if (!t.length) return !1;
	let n = /* @__PURE__ */ new Set([t[0]]);
	for (let t of n) for (let r = 0; r < 6; r++) {
		let i = A(t, r);
		e[i] && n.add(i);
	}
	return n.size === t.length;
}
function V(e) {
	let t = Object.keys(e).map(k);
	if (!t.length) return !1;
	let n = t.map(([e]) => e), r = t.map(([, e]) => e), i = Math.min(...n) - 1, a = Math.max(...n) + 1, o = Math.min(...r) - 1, s = Math.max(...r) + 1, c = /* @__PURE__ */ new Set([O(i, o)]);
	for (let t of c) for (let n = 0; n < 6; n++) {
		let r = A(t, n), [l, u] = k(r);
		l >= i && l <= a && u >= o && u <= s && !e[r] && c.add(r);
	}
	return c.size + t.length < (a - i + 1) * (s - o + 1);
}
function H(e, t) {
	let n = Object.values(e).map((e) => e.tile);
	if (n.length !== t.tiles.length || new Set(n).size !== n.length || n.some((e) => !t.tiles.includes(e)) || !B(e) || Object.entries(e).some(([t, n]) => {
		let r = { ...e };
		delete r[t];
		let [i, a] = k(t);
		return !F(r, {
			...n,
			q: i,
			r: a
		}, !1);
	}) || t.noHoles && V(e)) return [];
	let r = t.targets.filter((r) => {
		let i = t.allTiles ? n.length : n.filter((e) => w[e].includes(r)).length;
		return i >= 3 && R(e, r).some((e) => e.tiles.length === i && e.loop === (t.kind !== "doubleLine"));
	});
	return r.length >= (t.kind === "loop" ? 1 : 2) ? r : [];
}
var U = (e) => Object.fromEntries(S.map((t) => [t, z(e, t)])), W = {
	id: "tantrix",
	tier: "beta",
	mechanics: ["tile-placement", "route-building"],
	interactionTags: [],
	nameKey: "games.tantrix.name",
	descKey: "games.tantrix.desc",
	rulesKey: "games.tantrix.rules",
	icon: "🧩",
	iconImg: "games/tantrix.webp",
	minPlayers: 1,
	maxPlayers: 4,
	rulesUrl: { en: "https://www.tantrix.com/english/TantrixGameRules.html" },
	bestPlayers: [2],
	playerRange: (e) => e?.mode === "strategy" ? {
		min: 2,
		max: 4
	} : {
		min: 1,
		max: 1
	},
	accent: "#4268b0",
	releasedAt: "2026-10-17T15:31:35+08:00",
	search: {
		py: "tan suo qi",
		init: "tsq"
	},
	hotseat: "open"
}, G = t.enum([
	"R",
	"Y",
	"G",
	"B"
]), K = t.int().min(1).max(56), q = t.int().min(-100).max(100), J = t.object({
	mode: t.enum([
		"strategy",
		"discovery",
		"rainbow"
	]).default("discovery"),
	puzzle: t.enum([
		"d1",
		"d2",
		"d3",
		"d4",
		"d5",
		"d6",
		"d7",
		"d8",
		"d9",
		"d10",
		"r1",
		"r2",
		"r3",
		"r4",
		"r5"
	]).default("d1")
}).prefault({}), ae = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("chooseColor"),
		color: G
	}),
	t.object({
		type: t.literal("place"),
		tile: K,
		q,
		r: q,
		rot: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("remove"),
		tile: K
	}),
	t.object({ type: t.literal("undo") }),
	t.object({ type: t.literal("reset") })
]), Y = t.record(t.string().regex(/^-?\d+,-?\d+$/), t.object({
	tile: K,
	rot: t.int().min(0).max(5)
})), X = t.object({
	mode: t.enum([
		"strategy",
		"discovery",
		"rainbow"
	]),
	puzzle: t.string(),
	phase: t.enum([
		"colors",
		"play",
		"done"
	]),
	step: t.enum([
		"before",
		"free",
		"after"
	]),
	board: Y,
	players: t.array(t.object({
		rid: t.string(),
		color: G.nullable(),
		hand: t.array(K),
		score: t.int().nonnegative(),
		line: t.int().nonnegative(),
		loop: t.int().nonnegative()
	})),
	active: t.string(),
	bagCount: t.int().nonnegative(),
	turn: t.int().positive(),
	last: t.string().nullable(),
	undoCount: t.int().nonnegative(),
	moves: t.int().nonnegative(),
	deadlock: t.boolean(),
	solvedColors: t.array(G)
}), oe = t.object({});
//#endregion
//#region src/games/tantrix/rules.ts
function se(t, n, r) {
	let i = J.parse(t), a = E(i.puzzle);
	i.mode !== "strategy" && a.series !== i.mode && (i.puzzle = i.mode === "rainbow" ? "r1" : "d1");
	let o = Array.from({ length: 56 }, (e, t) => t + 1), s = 0;
	for (let t = o.length - 1; t > 0; t--) {
		let n = e(r, s++, t + 1);
		[o[t], o[n]] = [o[n], o[t]];
	}
	return { state: {
		config: i,
		players: [...n],
		colors: {},
		hands: Object.fromEntries(n.map((e) => [e, []])),
		bag: i.mode === "strategy" ? o : [],
		board: {},
		active: 0,
		phase: i.mode === "strategy" ? "colors" : "play",
		step: "before",
		turn: 1,
		last: null,
		history: [],
		moves: 0,
		deadlock: !1,
		solvedColors: [],
		rngCursor: s
	} };
}
function ce(e) {
	for (let t of e.players) e.hands[t].push(e.bag.shift());
	e.active = e.players.reduce((t, n, r) => e.hands[n][0] > e.hands[e.players[t]][0] ? r : t, 0);
	for (let t of e.players) e.hands[t].push(...e.bag.splice(0, 5));
	e.phase = "play", le(e);
}
function le(e) {
	if (Object.keys(e.board).length === 56) {
		e.phase = "done";
		return;
	}
	for (let t = 0; t <= e.players.length; t++) {
		let t = e.hands[e.players[e.active]], n = e.bag.length > 0;
		if (e.step !== "free" && L(e.board, t, n, !0).length) return;
		if (e.step === "before" && (e.step = "free"), e.step === "free" && t.length) {
			L(e.board, t, n).length || (e.phase = "done", e.deadlock = !0);
			return;
		}
		e.active = (e.active + 1) % e.players.length, e.turn++, e.step = "before";
	}
	e.phase = "done";
}
function ue(e, t, n) {
	if (e.phase === "done" || n.by !== e.players[e.active]) return { code: "games.tantrix.errTurn" };
	let r = structuredClone(e);
	if (t.type === "chooseColor") return r.phase !== "colors" || Object.values(r.colors).includes(t.color) ? { code: "games.tantrix.errColor" } : (r.colors[n.by] = t.color, Object.keys(r.colors).length === r.players.length ? ce(r) : r.active++, { state: r });
	if (r.phase !== "play") return { code: "games.tantrix.errTurn" };
	if (r.config.mode !== "strategy") {
		if (t.type === "undo") {
			let e = r.history.pop();
			return e ? (Object.assign(r, e), { state: r }) : { code: "games.tantrix.errUndo" };
		}
		let e = { ...r.board };
		if (t.type === "reset") return Object.keys(e).length ? (r.history.push({
			board: e,
			last: r.last,
			moves: r.moves
		}), r.board = {}, r.last = null, r.moves++, { state: r }) : { code: "games.tantrix.errUndo" };
		let n = E(r.config.puzzle);
		if (!n.tiles.includes(t.tile)) return { code: "games.tantrix.errTile" };
		let i = Object.keys(e).find((n) => e[n].tile === t.tile);
		if (i && delete e[i], t.type === "remove") {
			if (!i) return { code: "games.tantrix.errTile" };
		} else {
			if (!F(e, t, !1)) return { code: "games.tantrix.errMatch" };
			e[O(t.q, t.r)] = {
				tile: t.tile,
				rot: t.rot
			};
		}
		return r.history.push({
			board: r.board,
			last: r.last,
			moves: r.moves
		}), r.board = e, r.last = t.type === "place" ? O(t.q, t.r) : null, r.moves++, r.solvedColors = H(e, n), r.solvedColors.length && (r.phase = "done"), { state: r };
	}
	if (t.type !== "place") return { code: "games.tantrix.errTurn" };
	let i = r.hands[n.by];
	if (!i.includes(t.tile)) return { code: "games.tantrix.errTile" };
	let a = O(t.q, t.r);
	return r.step !== "free" && !N(r.board).includes(a) ? { code: "games.tantrix.errForced" } : I(r.board, t, r.bag.length > 0) ? (r.board[a] = {
		tile: t.tile,
		rot: t.rot
	}, r.hands[n.by] = i.filter((e) => e !== t.tile), r.bag.length && r.hands[n.by].push(r.bag.shift()), r.step === "free" && (r.step = "after"), r.last = a, r.moves++, le(r), { state: r }) : { code: "games.tantrix.errMatch" };
}
function de(e) {
	let t = U(e.board);
	return {
		public: {
			mode: e.config.mode,
			puzzle: e.config.puzzle,
			phase: e.phase,
			step: e.step,
			board: e.board,
			active: e.players[e.active],
			bagCount: e.bag.length,
			turn: e.turn,
			players: e.players.map((n) => ({
				rid: n,
				color: e.colors[n] ?? null,
				hand: e.config.mode === "strategy" ? e.hands[n] : E(e.config.puzzle).tiles.filter((t) => !Object.values(e.board).some((e) => e.tile === t)),
				...e.colors[n] ? t[e.colors[n]] : {
					line: 0,
					loop: 0,
					score: 0
				}
			})),
			last: e.last,
			undoCount: e.history.length,
			moves: e.moves,
			deadlock: e.deadlock,
			solvedColors: e.solvedColors
		},
		private: {}
	};
}
function fe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	if (e.config.mode !== "strategy") return {
		phase: "done",
		winner: [...e.players],
		ranking: [...e.players],
		scores: { [e.players[0]]: E(e.config.puzzle).tiles.length }
	};
	let t = Object.fromEntries(e.players.map((t) => [t, e.deadlock ? 0 : U(e.board)[e.colors[t]].score])), n = [...e.players].sort((e, n) => t[n] - t[e]);
	return {
		phase: "done",
		ranking: n,
		scores: t,
		winner: n.filter((e) => t[e] === t[n[0]])
	};
}
var pe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: W,
	schemas: {
		action: ae,
		publicView: X,
		privateView: oe,
		config: J
	},
	setup: se,
	reduce: ue,
	viewFor: de,
	status: fe
}, me = (e) => Array.from({ length: 6 }, (t, n) => {
	let r = (30 + n * 60) * Math.PI / 180;
	return `${Math.cos(r) * e},${Math.sin(r) * e}`;
}).join(" "), Z = me(49.2);
function he({ tile: e, rot: t = 0, selected: n = !1, ghost: r = !1 }) {
	let i = j({
		tile: e,
		rot: t
	});
	return /* @__PURE__ */ y("g", {
		className: r ? "tantrix-piece tantrix-piece--preview" : "tantrix-piece",
		children: [r && /* @__PURE__ */ v("polygon", {
			points: Z,
			transform: "translate(0 6)",
			fill: "#706f65",
			opacity: .28
		}), /* @__PURE__ */ y("g", {
			transform: r ? "translate(0 -3)" : void 0,
			children: [
				n && /* @__PURE__ */ v("polygon", {
					points: me(55),
					fill: "var(--tantrix-accent-soft, #e6f2f6)",
					stroke: "var(--tantrix-accent, #357ca2)",
					strokeWidth: 2.8
				}),
				/* @__PURE__ */ v("polygon", {
					points: Z,
					fill: "#10161c",
					stroke: "#111720",
					strokeWidth: 1.3,
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ v("polygon", {
					points: me(47.7),
					fill: "#232a32",
					stroke: "#646b72",
					strokeWidth: .8,
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ v("path", {
					d: "M-40.6 -23.8 0 -47.7 40.6 -23.8",
					fill: "none",
					stroke: "#a0a6a8",
					strokeWidth: 1.1,
					opacity: .55
				}),
				S.filter((e) => i.includes(e)).map((e) => {
					let t = i.indexOf(e), n = i.lastIndexOf(e);
					n - t > 3 && ([t, n] = [n, t + 6]);
					let r = n - t, a = t * Math.PI / 3, o = Math.cos(a) * 43.35, s = Math.sin(a) * 43.35, c = Math.cos(n * Math.PI / 3) * 43.35, l = Math.sin(n * Math.PI / 3) * 43.35, u = r === 1 ? 25.03 : 75.08, d = r === 3 ? `M${o} ${s} L${c} ${l}` : `M${o} ${s} A${u} ${u} 0 0 0 ${c} ${l}`, f = 0, p = 0;
					if (r !== 3) {
						let e = o - u * Math.sin(a), t = s + u * Math.cos(a), n = a - Math.PI / 2 - (Math.PI - r * Math.PI / 3) / 2;
						f = e + u * Math.cos(n), p = t + u * Math.sin(n);
					}
					return /* @__PURE__ */ y("g", { children: [
						/* @__PURE__ */ v("path", {
							d,
							fill: "none",
							stroke: "#101820",
							strokeWidth: 14.1
						}),
						/* @__PURE__ */ v("path", {
							d,
							fill: "none",
							stroke: C[e],
							strokeWidth: 10.8
						}),
						/* @__PURE__ */ v("text", {
							x: f,
							y: p + 2.5,
							textAnchor: "middle",
							fontSize: "var(--tantrix-tile-letter, 7.2px)",
							fontWeight: 800,
							fontFamily: "Arial, sans-serif",
							fill: "#1d2730",
							children: e
						})
					] }, e);
				}),
				/* @__PURE__ */ v("rect", {
					x: -10,
					y: 32.4,
					width: 20,
					height: 10.8,
					rx: 3,
					fill: "#232a32"
				}),
				/* @__PURE__ */ v("text", {
					x: 0,
					y: 40.2,
					fontSize: "var(--tantrix-tile-number, 8.8px)",
					fontWeight: 650,
					fill: "#d1d6d5",
					textAnchor: "middle",
					fontFamily: "Arial, sans-serif",
					children: e
				})
			]
		})]
	});
}
function ge({ tile: e, rot: t = 0, selected: n = !1 }) {
	return /* @__PURE__ */ y("svg", {
		viewBox: "-57 -57 114 118",
		className: "tantrix-tile-art",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ v("polygon", {
			points: Z,
			transform: "translate(0 4)",
			fill: "#706f65",
			opacity: .28
		}), /* @__PURE__ */ v(he, {
			tile: e,
			rot: t,
			selected: n
		})]
	});
}
//#endregion
//#region src/games/tantrix/board-view.tsx
var _e = 50;
function Q(e) {
	let [t, n] = k(e);
	return [Math.sqrt(3) * _e * (t + n / 2), 1.5 * _e * n];
}
function ve(e, t) {
	let n = (Math.sqrt(3) * e / 3 - t / 3) / _e, r = 2 * t / 150, i = Math.round(n), a = Math.round(r), o = Math.round(-n - r), s = Math.abs(i - n), c = Math.abs(o + n + r), l = Math.abs(a - r);
	return s > c && s > l ? i = -o - a : l >= c && (a = -i - o), O(i, a);
}
function ye(e, t, n, r) {
	let i = e.map(Q);
	i.length || i.push([0, 0]);
	let a = i.map(([e]) => e), o = i.map(([, e]) => e), s = Math.min(...a), c = Math.max(...a), l = Math.min(...o), u = Math.max(...o);
	return {
		cx: (s + c) / 2,
		cy: (l + u) / 2,
		scale: Math.max(.15, Math.min(r, (t - 26) / (c - s + 118), (n - 126) / (u - l + 118)))
	};
}
function be(e, t, n, r) {
	let i = e.scale;
	for (let a of t) {
		let [t, o] = Q(a);
		for (let [a, s] of [
			[e.cx - t + 59, n / 2 - 13],
			[t - e.cx + 59, n / 2 - 13],
			[e.cy - o + 59, r * .46 - 34],
			[o - e.cy + 59, r * .54 - 68]
		]) a > 0 && (i = Math.min(i, s / a));
	}
	return i = Math.max(.15, i), i < e.scale ? {
		...e,
		scale: i
	} : e;
}
function xe(e, t, n, r, i, a, o, s) {
	let c = [];
	for (let l of [!1, !0]) {
		let u = (l ? Math.max(94, (a - 1) * 50 - 6) : (a - 1) * 50 + 88) * s, d = (l ? 102 : 48) * s;
		for (let a of [
			"below",
			"above",
			"right",
			"left"
		]) for (let s of [
			0,
			18,
			38,
			62,
			92
		]) {
			let f = a === "right" ? e + n * 51 + 16 + s : a === "left" ? e - n * 51 - u - 16 - s : e - u / 2, p = a === "below" ? t + n * 51 + 16 + s : a === "above" ? t - n * 51 - d - 16 - s : t - d / 2, m = Math.max(12, Math.min(r - u - 12, f)), h = Math.max(42, Math.min(i - d - 68, p)), ee = [...o, {
				x: e - n * 44 - 6,
				y: t - n * 51 - 6,
				w: n * 88 + 12,
				h: n * 102 + 12
			}].reduce((e, t) => e + Math.max(0, Math.min(m + u + 4, t.x + t.w) - Math.max(m - 4, t.x)) * Math.max(0, Math.min(h + d + 4, t.y + t.h) - Math.max(h - 4, t.y)), 0), te = Math.hypot(e - Math.max(m, Math.min(m + u, e)), t - Math.max(h, Math.min(h + d, t)));
			c.push({
				x: m,
				y: h,
				w: u,
				stacked: l,
				score: ee * 50 + te + (l ? 8 : 0)
			});
		}
	}
	return c.sort((e, t) => e.score - t.score)[0];
}
function Se({ board: e, framingBoard: t = e, spots: r = [], forced: s = [], selected: c, ghost: l, last: u, onTap: f, editable: p = !1, controls: ee, controlCount: te = 0, maxScale: g = 1, notice: ne, adaptive: _ = !1 }) {
	let b = o(), x = i(null), [S, C] = a({
		w: 0,
		h: 0
	}), [w, T] = a({
		camera: null,
		keys: "",
		w: 0,
		h: 0
	}), E = i(/* @__PURE__ */ new Map()), D = i(0), A = [.../* @__PURE__ */ new Set([...Object.keys(t), ...l ? [O(l.q, l.r)] : []])].sort(), j = A.join("|"), M = S.w !== w.w || S.h !== w.h, ie = _ ? Math.max(g, Math.min(2.4, S.w / 500, S.h / 320)) : g, N = _ ? Math.max(1, Math.min(1.5, S.w / 700, S.h / 500)) : 1, P = w.camera ?? ye(A, S.w, S.h, ie);
	if (S.w > 0 && S.h > 0 && (j !== w.keys || M)) {
		let e = new Set(w.keys.split("|")), t = A.filter((t) => !e.has(t));
		w.camera && (P = be(w.camera, M ? A : t, S.w, S.h)), T({
			camera: P,
			keys: j,
			...S
		});
	}
	let F = (e) => T((t) => ({
		...t,
		camera: e(t.camera ?? P)
	})), I = (e) => {
		let [t, n] = Q(e);
		return [S.w / 2 + (t - P.cx) * P.scale, S.h * .46 + (n - P.cy) * P.scale];
	};
	n(() => {
		let e = x.current;
		if (!e) return;
		let t = new ResizeObserver(([e]) => C({
			w: e.contentRect.width,
			h: e.contentRect.height
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let L = (e) => {
		e.currentTarget.setPointerCapture(e.pointerId), E.current.set(e.pointerId, [e.clientX, e.clientY]), D.current = E.current.size === 1 ? 0 : 99;
	}, R = (e) => {
		let t = E.current.get(e.pointerId);
		if (!t) return;
		let n = e.clientX - t[0], r = e.clientY - t[1];
		if (E.current.size === 1) D.current += Math.abs(n) + Math.abs(r), D.current > 6 && F((e) => ({
			...e,
			cx: e.cx - n / e.scale,
			cy: e.cy - r / e.scale
		}));
		else {
			let n = [...E.current.entries()].find(([t]) => t !== e.pointerId)?.[1];
			if (n) {
				let r = Math.hypot(t[0] - n[0], t[1] - n[1]), i = Math.hypot(e.clientX - n[0], e.clientY - n[1]), a = e.currentTarget.getBoundingClientRect(), o = (t[0] + n[0]) / 2 - a.left - S.w / 2, s = (t[1] + n[1]) / 2 - a.top - S.h * .46, c = (e.clientX + n[0]) / 2 - a.left - S.w / 2, l = (e.clientY + n[1]) / 2 - a.top - S.h * .46;
				r > 0 && F((e) => {
					let t = Math.max(.15, Math.min(2.4, e.scale * i / r));
					return {
						scale: t,
						cx: e.cx + o / e.scale - c / t,
						cy: e.cy + s / e.scale - l / t
					};
				});
			}
			D.current = 99;
		}
		E.current.set(e.pointerId, [e.clientX, e.clientY]);
	}, z = (e) => F((t) => {
		let n = Math.max(.15, Math.min(2.4, t.scale * e));
		if (!l) return {
			...t,
			scale: n
		};
		let [r, i] = Q(O(l.q, l.r));
		return {
			scale: n,
			cx: r - (r - t.cx) * t.scale / n,
			cy: i - (i - t.cy) * t.scale / n
		};
	}), B = u && e[u] ? u : null, V = l ? O(l.q, l.r) : null, H = r.filter((e) => {
		let [t, n] = I(e), r = P.scale * 50;
		return t - r * .87 >= 6 && t + r * .87 <= S.w - 6 && n - r >= 34 && n + r <= S.h - 68;
	}), [U, W] = V ? I(V) : [0, 0], G = Object.keys(e).filter((e) => e !== V).map((e) => {
		let [t, n] = I(e);
		return {
			x: t - P.scale * 43,
			y: n - P.scale * 49,
			w: P.scale * 86,
			h: P.scale * 98
		};
	}), K = l && ee && te && S.w > 0 ? xe(U, W, P.scale, S.w, S.h, te, G, N) : null;
	return /* @__PURE__ */ y("div", {
		className: "tantrix-board",
		ref: x,
		children: [
			/* @__PURE__ */ v(re, {
				kind: "sheen",
				base: "var(--tantrix-table, #e6e5dc)",
				className: "absolute inset-0 size-full tantrix-table-light"
			}),
			ne && /* @__PURE__ */ v("div", {
				className: "tantrix-board-notice",
				children: ne
			}),
			/* @__PURE__ */ v("svg", {
				className: "tantrix-board-svg",
				"aria-label": b("games.tantrix.board"),
				onPointerDown: L,
				onPointerMove: R,
				onPointerUp: (e) => E.current.delete(e.pointerId),
				onPointerCancel: (e) => {
					E.current.delete(e.pointerId), D.current = 99;
				},
				onClick: (e) => {
					if (D.current > 6 || !f) return;
					let t = e.currentTarget.getBoundingClientRect();
					f(ve(P.cx + (e.clientX - t.left - S.w / 2) / P.scale, P.cy + (e.clientY - t.top - S.h * .46) / P.scale));
				},
				children: /* @__PURE__ */ y("g", {
					transform: `translate(${S.w / 2},${S.h * .46}) scale(${P.scale}) translate(${-P.cx},${-P.cy})`,
					children: [
						H.filter((e) => e !== V).map((e) => {
							let [t, n] = k(e), r = s.includes(e);
							return /* @__PURE__ */ y("g", {
								transform: `translate(${Q(e).join(" ")})`,
								role: f ? "button" : void 0,
								tabIndex: f ? 0 : void 0,
								"data-cell": e,
								"aria-label": b("games.tantrix.placeAt", {
									q: t,
									r: n
								}),
								onKeyDown: (t) => {
									(t.key === "Enter" || t.key === " ") && (t.preventDefault(), f?.(e));
								},
								children: [
									/* @__PURE__ */ v("polygon", {
										points: Z,
										fill: r ? "var(--tantrix-warn-soft)" : "var(--tantrix-accent-soft)",
										fillOpacity: .7,
										stroke: r ? "var(--tantrix-warn)" : "var(--tantrix-accent)",
										strokeWidth: 1.8,
										strokeDasharray: r ? "5 4" : "3 5"
									}),
									/* @__PURE__ */ v("circle", {
										r: r ? 12 : 5,
										fill: r ? "#f5dcac" : "var(--tantrix-accent)",
										stroke: r ? "var(--tantrix-warn)" : "none",
										strokeWidth: 1.3
									}),
									r && /* @__PURE__ */ v("text", {
										textAnchor: "middle",
										y: 6,
										fontSize: 18,
										fontWeight: 800,
										fill: "var(--tantrix-warn)",
										children: "!"
									})
								]
							}, `s${e}`);
						}),
						s.filter((e) => !r.includes(e) && e !== V).map((e) => /* @__PURE__ */ y("g", {
							transform: `translate(${Q(e).join(" ")})`,
							children: [
								/* @__PURE__ */ v("polygon", {
									points: Z,
									fill: "var(--tantrix-warn-soft)",
									fillOpacity: .7,
									stroke: "var(--tantrix-warn)",
									strokeWidth: 1.8,
									strokeDasharray: "5 4"
								}),
								/* @__PURE__ */ v("circle", {
									r: 12,
									fill: "#f5dcac",
									stroke: "var(--tantrix-warn)",
									strokeWidth: 1.3
								}),
								/* @__PURE__ */ v("text", {
									y: 6,
									textAnchor: "middle",
									fontSize: 18,
									fontWeight: 800,
									fill: "var(--tantrix-warn)",
									children: "!"
								})
							]
						}, `f${e}`)),
						Object.entries(e).filter(([e]) => e !== V).map(([e, t]) => /* @__PURE__ */ y("g", {
							transform: `translate(${Q(e).join(" ")})`,
							role: f && p ? "button" : void 0,
							tabIndex: f && p ? 0 : void 0,
							"aria-label": b("games.tantrix.tile", { n: t.tile }),
							"data-cell": e,
							onKeyDown: (t) => {
								(t.key === "Enter" || t.key === " ") && (t.preventDefault(), f?.(e));
							},
							children: [/* @__PURE__ */ v(he, {
								...t,
								selected: c === e
							}), B === e && /* @__PURE__ */ v("polygon", {
								points: Z,
								fill: "none",
								stroke: "var(--tantrix-accent, #357ca2)",
								opacity: .7,
								strokeWidth: 1.6
							})]
						}, e)),
						l && /* @__PURE__ */ v("g", {
							transform: `translate(${Q(O(l.q, l.r)).join(" ")})`,
							pointerEvents: "none",
							children: /* @__PURE__ */ v(he, {
								...l,
								ghost: !0,
								selected: !0
							})
						})
					]
				})
			}),
			K && U > -30 && U < S.w + 30 && W > -30 && W < S.h + 30 && /* @__PURE__ */ v("div", {
				className: "tantrix-local-controls",
				role: "group",
				"aria-label": b("games.tantrix.placement"),
				"data-stacked": K.stacked,
				style: {
					left: K.x,
					top: K.y,
					width: K.w,
					"--tantrix-tools": te - 1,
					"--tantrix-control-scale": N
				},
				children: ee
			}),
			/* @__PURE__ */ y("div", {
				className: "tantrix-map-tools",
				children: [
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "tantrix-icon-button",
						"aria-label": b("games.tantrix.fit"),
						onClick: () => F(() => ye(A, S.w, S.h, ie)),
						children: /* @__PURE__ */ v(d, { size: 20 })
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "tantrix-icon-button",
						"aria-label": b("games.tantrix.zoomOut"),
						onClick: () => z(1 / 1.3),
						children: /* @__PURE__ */ v(h, { size: 20 })
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "tantrix-icon-button",
						"aria-label": b("games.tantrix.zoomIn"),
						onClick: () => z(1.3),
						children: /* @__PURE__ */ v(m, { size: 20 })
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/tantrix/labels.ts
var $ = {
	R: "games.tantrix.red",
	Y: "games.tantrix.yellow",
	G: "games.tantrix.green",
	B: "games.tantrix.blue"
}, Ce = {
	d1: "games.tantrix.d1",
	d2: "games.tantrix.d2",
	d3: "games.tantrix.d3",
	d4: "games.tantrix.d4",
	d5: "games.tantrix.d5",
	d6: "games.tantrix.d6",
	d7: "games.tantrix.d7",
	d8: "games.tantrix.d8",
	d9: "games.tantrix.d9",
	d10: "games.tantrix.d10",
	r1: "games.tantrix.r1",
	r2: "games.tantrix.r2",
	r3: "games.tantrix.r3",
	r4: "games.tantrix.r4",
	r5: "games.tantrix.r5"
};
//#endregion
//#region src/games/tantrix/view-player.tsx
function we({ public: e, members: t, myRid: n, send: r }) {
	return g(), /* @__PURE__ */ v(Te, {
		pub: e,
		members: t,
		myRid: n,
		send: r
	});
}
function Te({ pub: e, members: t, myRid: d, send: m }) {
	let h = o(), [g, re] = a(null), [b, x] = a(0), [w, T] = a(null), [D, A] = a(!1), [j, M] = a(!1), P = i(null), I = i(/* @__PURE__ */ new Map());
	n(() => {
		let e = P.current;
		D ? e && !e.open && e.showModal() : e?.close();
	}, [D]), n(() => {
		if (!j) return;
		let e = window.setTimeout(() => M(!1), 3e3);
		return () => window.clearTimeout(e);
	}, [j]), n(() => {
		let e = !0;
		return queueMicrotask(() => {
			e && (re(null), T(null), M(!1));
		}), () => {
			e = !1;
		};
	}, [
		e.moves,
		e.turn,
		e.phase,
		d
	]);
	let R = e.mode !== "strategy", z = e.players.find((e) => e.rid === d), B = e.active === d && e.phase === "play";
	te(B || e.phase === "colors" && e.active === d, ee);
	let V = t.some((e) => e.rid.startsWith("local:")), H = (e) => t.find((t) => t.rid === e)?.name ?? e, U = g === null ? void 0 : Object.keys(e.board).find((t) => e.board[t].tile === g), W = r(() => {
		if (!R || !U) return e.board;
		let t = { ...e.board };
		return delete t[U], t;
	}, [
		e.board,
		R,
		U
	]), G = r(() => !R && B && g !== null ? L(e.board, [g], e.bagCount > 0, e.step !== "free") : [], [
		R,
		B,
		g,
		e.board,
		e.bagCount,
		e.step
	]), K = r(() => R && g !== null ? [.../* @__PURE__ */ new Set([...ie(W), ...U ? [U] : []])].filter((e) => {
		let [t, n] = k(e);
		return Math.abs(t) <= 100 && Math.abs(n) <= 100 && Array.from({ length: 6 }, (e, r) => F(W, {
			tile: g,
			q: t,
			r: n,
			rot: r
		}, !1)).some(Boolean);
	}) : [], [
		R,
		g,
		W,
		U
	]), q = B && g !== null ? R ? K : [...new Set(G.map((e) => O(e.q, e.r)))] : [], J = g !== null && w !== null ? {
		tile: g,
		rot: b,
		q: k(w)[0],
		r: k(w)[1]
	} : null, ae = !!J && (R ? F(W, J, !1) : G.some((e) => e.q === J.q && e.r === J.r && e.rot === b)), Y = J ? R ? Array.from({ length: 6 }, (e, t) => t).filter((e) => F(W, {
		...J,
		rot: e
	}, !1)) : G.filter((e) => e.q === J.q && e.r === J.r).map((e) => e.rot) : [], X = E(e.puzzle), oe = X.series === "discovery" ? h("games.tantrix.loopGoal", { color: h($[X.targets[0]]) }) : X.kind === "doubleLoop" ? h("games.tantrix.doubleGoal") : X.kind === "doubleLine" ? h("games.tantrix.geniusGoal") : h("games.tantrix.anyGoal"), se = X.series === "discovery" || X.allTiles ? h("games.tantrix.allTilesGoal") : h(X.kind === "doubleLine" ? "games.tantrix.geniusDetail" : X.kind === "loop" ? "games.tantrix.singleColourGoal" : "games.tantrix.colouredTilesGoal"), ce = e.phase === "colors" ? h(e.active === d ? "games.tantrix.chooseColor" : "games.tantrix.waitingColor", { name: H(e.active) }) : B ? h("games.tantrix.yourTurn") : h("games.tantrix.waiting", { name: H(e.active) }), le = (t) => {
		let n = R ? Object.keys(e.board).find((n) => e.board[n].tile === t) : void 0;
		re(t === g ? null : t), T(t !== g && n ? n : null), M(!1), x(n ? e.board[n].rot : 0);
	}, ue = () => {
		re(null), T(null), g !== null && I.current.get(g)?.focus();
	}, de = (t) => {
		if (!B) return;
		if (R && e.board[t] && (U !== t || g === null)) {
			le(e.board[t].tile);
			return;
		}
		if (g === null || !q.includes(t) && U !== t) return;
		T(t);
		let [n, r] = k(t), i = R ? Array.from({ length: 6 }, (e, t) => t).filter((e) => F(W, {
			tile: g,
			q: n,
			r,
			rot: e
		}, !1)) : G.filter((e) => e.q === n && e.r === r).map((e) => e.rot);
		!i.includes(b) && i.length && x(i[0]);
	}, fe = 2 + +(Y.length > 1) + (R && U ? 1 : 0);
	return /* @__PURE__ */ y("div", {
		className: `tantrix-screen${R ? " tantrix-screen--puzzle" : ""}${V ? " tantrix-screen--hotseat" : ""}`,
		onKeyDown: (e) => {
			e.key === "Escape" && g !== null && !D && (e.preventDefault(), ue());
		},
		children: [/* @__PURE__ */ y(ne, {
			adaptive: !0,
			className: "tantrix-layout",
			scroll: !1,
			actionsHeight: "tantrix-action-height",
			banner: /* @__PURE__ */ v("div", {
				className: "tantrix-banner",
				children: R ? /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ y("h1", {
						className: "tantrix-puzzle-title font-display",
						children: [h(e.mode === "discovery" ? "games.tantrix.discovery" : "games.tantrix.rainbow"), e.mode === "rainbow" && /* @__PURE__ */ y(_, { children: [" · ", h(Ce[e.puzzle])] })]
					}),
					/* @__PURE__ */ v("h2", {
						className: "tantrix-puzzle-goal",
						children: oe
					}),
					/* @__PURE__ */ y("div", {
						className: "tantrix-puzzle-detail",
						children: [/* @__PURE__ */ v("span", { children: se }), /* @__PURE__ */ y("strong", { children: [
							Object.keys(e.board).length,
							" / ",
							X.tiles.length
						] })]
					})
				] }) : /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ y("div", {
					className: "tantrix-phase",
					role: "status",
					children: [
						/* @__PURE__ */ v("h1", { children: ce }),
						/* @__PURE__ */ v("p", { children: h(e.phase === "colors" || !B ? "games.tantrix.strategy" : e.step === "free" ? "games.tantrix.freeMove" : "games.tantrix.forcedMove") }),
						e.phase !== "colors" && /* @__PURE__ */ v("span", {
							className: "tantrix-round",
							children: h("games.tantrix.turn", { n: e.turn })
						})
					]
				}), /* @__PURE__ */ v("div", {
					className: "tantrix-status-bar",
					children: e.players.map((t) => /* @__PURE__ */ y("div", {
						className: "tantrix-seat",
						"data-active": t.rid === e.active,
						"data-color": t.color ?? "",
						children: [
							t.color && /* @__PURE__ */ v("span", {
								className: "tantrix-color-dot",
								style: { background: C[t.color] },
								children: t.color
							}),
							/* @__PURE__ */ v("span", {
								className: "tantrix-seat-name",
								title: H(t.rid),
								children: t.rid === d ? h("games.tantrix.you") : H(t.rid)
							}),
							/* @__PURE__ */ v("span", {
								className: "tantrix-seat-color",
								children: t.color ? h($[t.color]) : h("games.tantrix.unselected")
							}),
							e.phase !== "colors" && /* @__PURE__ */ v("strong", {
								className: "font-display",
								children: t.score
							})
						]
					}, t.rid))
				})] })
			}),
			actions: /* @__PURE__ */ y("div", {
				className: "tantrix-actions",
				children: [
					/* @__PURE__ */ y("div", {
						className: "tantrix-dock-head",
						children: [/* @__PURE__ */ v("strong", { children: h(R ? "games.tantrix.hand" : "games.tantrix.yourTiles") }), R ? /* @__PURE__ */ y("div", {
							className: "tantrix-puzzle-tools",
							children: [/* @__PURE__ */ v("button", {
								type: "button",
								className: "tantrix-icon-button",
								"aria-label": h("games.tantrix.undo"),
								disabled: !B || !e.undoCount,
								onClick: () => m({ type: "undo" }),
								children: /* @__PURE__ */ v(u, { size: 20 })
							}), /* @__PURE__ */ v("button", {
								type: "button",
								className: `tantrix-icon-button${j ? " tantrix-reset-armed danger-stripes" : ""}`,
								"aria-label": h(j ? "games.tantrix.resetConfirm" : "games.tantrix.reset"),
								disabled: !B || !Object.keys(e.board).length,
								onBlur: () => M(!1),
								onClick: () => {
									j ? (M(!1), m({ type: "reset" })) : M(!0);
								},
								children: v(j ? s : f, { size: 20 })
							})]
						}) : /* @__PURE__ */ y("button", {
							type: "button",
							className: "tantrix-open-button",
							onClick: () => A(!0),
							children: [/* @__PURE__ */ v(l, { size: 20 }), h("games.tantrix.opponents")]
						})]
					}),
					/* @__PURE__ */ v("div", {
						className: "tantrix-hand",
						"aria-label": h("games.tantrix.hand"),
						children: (z?.hand ?? []).map((e) => /* @__PURE__ */ v("button", {
							type: "button",
							className: "tantrix-hand-tile",
							disabled: !B,
							"aria-pressed": e === g,
							ref: (t) => {
								t ? I.current.set(e, t) : I.current.delete(e);
							},
							"aria-label": h("games.tantrix.tile", { n: e }),
							onClick: () => le(e),
							children: /* @__PURE__ */ v(ge, {
								tile: e,
								selected: e === g
							})
						}, e))
					}),
					/* @__PURE__ */ v("span", {
						className: "sr-only",
						role: "status",
						children: B && g !== null ? w === null ? h(q.length ? "games.tantrix.selectPosition" : "games.tantrix.noMoves") : h("games.tantrix.tile", { n: g }) : null
					})
				]
			}),
			children: [/* @__PURE__ */ v(Se, {
				board: ae ? W : e.board,
				framingBoard: e.board,
				spots: q,
				forced: R ? [] : N(e.board),
				adaptive: !0,
				maxScale: R ? 1.02 : .9,
				selected: U,
				ghost: ae ? J : null,
				last: e.last,
				onTap: B ? de : void 0,
				editable: R,
				notice: !R && e.phase !== "colors" ? /* @__PURE__ */ v("span", { children: h(e.bagCount ? "games.tantrix.bag" : "games.tantrix.endgame", { n: e.bagCount }) }) : g !== null && !q.length ? /* @__PURE__ */ v("span", {
					role: "status",
					children: h("games.tantrix.noMoves")
				}) : void 0,
				controlCount: fe,
				controls: B && ae ? /* @__PURE__ */ y(_, { children: [
					Y.length > 1 && /* @__PURE__ */ v("button", {
						type: "button",
						className: "tantrix-piece-button",
						"aria-label": h("games.tantrix.rotate"),
						onClick: () => x(Y[(Y.indexOf(b) + 1) % Y.length]),
						children: /* @__PURE__ */ v(f, { size: 20 })
					}),
					R && U && /* @__PURE__ */ v("button", {
						type: "button",
						className: "tantrix-piece-button",
						"aria-label": h("games.tantrix.remove"),
						onClick: () => {
							g !== null && (m({
								type: "remove",
								tile: g
							}), ue());
						},
						children: /* @__PURE__ */ v(p, { size: 20 })
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "tantrix-piece-button",
						"aria-label": h("games.tantrix.cancel"),
						onClick: ue,
						children: /* @__PURE__ */ v(c, { size: 20 })
					}),
					/* @__PURE__ */ y("button", {
						type: "button",
						className: "tantrix-piece-button tantrix-place-button font-display",
						"aria-label": h("games.tantrix.confirm"),
						onClick: () => {
							J && ae && (m({
								type: "place",
								...J
							}), re(null), T(null));
						},
						children: [/* @__PURE__ */ v(s, { size: 20 }), h("games.tantrix.place")]
					})
				] }) : void 0
			}), e.phase === "colors" && /* @__PURE__ */ v("div", {
				className: "tantrix-color-picker",
				children: S.map((t) => /* @__PURE__ */ y("button", {
					type: "button",
					className: "tantrix-color-choice",
					"aria-label": h("games.tantrix.chooseTarget", { color: h($[t]) }),
					disabled: e.active !== d || e.players.some((e) => e.color === t),
					onClick: () => m({
						type: "chooseColor",
						color: t
					}),
					children: [/* @__PURE__ */ v("span", {
						className: "tantrix-color-token",
						children: /* @__PURE__ */ v("span", {
							style: {
								borderColor: C[t],
								color: C[t]
							},
							children: t
						})
					}), /* @__PURE__ */ v("span", { children: h($[t]) })]
				}, t))
			})]
		}), /* @__PURE__ */ v("dialog", {
			ref: P,
			className: "tantrix-open-hands",
			"aria-label": h("games.tantrix.opponents"),
			onCancel: () => A(!1),
			onClose: () => A(!1),
			onClick: (e) => {
				e.target === e.currentTarget && A(!1);
			},
			children: /* @__PURE__ */ y("div", {
				className: "tantrix-hands-panel",
				children: [/* @__PURE__ */ y("div", {
					className: "tantrix-panel-head",
					children: [/* @__PURE__ */ v("strong", { children: h("games.tantrix.opponents") }), /* @__PURE__ */ v("button", {
						type: "button",
						className: "tantrix-icon-button",
						onClick: () => A(!1),
						"aria-label": h("games.tantrix.close"),
						children: /* @__PURE__ */ v(c, { size: 20 })
					})]
				}), e.players.map((e) => /* @__PURE__ */ y("div", {
					className: "tantrix-opponent",
					children: [/* @__PURE__ */ y("div", {
						className: "tantrix-opponent-name",
						children: [/* @__PURE__ */ v("span", {
							className: "tantrix-color-dot",
							style: { background: e.color ? C[e.color] : void 0 },
							children: e.color ?? "·"
						}), /* @__PURE__ */ v("span", {
							title: H(e.rid),
							children: e.rid === d ? h("games.tantrix.you") : H(e.rid)
						})]
					}), /* @__PURE__ */ v("div", {
						className: "tantrix-opponent-tiles",
						children: e.hand.map((e) => /* @__PURE__ */ v("div", {
							className: "tantrix-mini-tile",
							"aria-label": h("games.tantrix.tile", { n: e }),
							children: /* @__PURE__ */ v(ge, { tile: e })
						}, e))
					})]
				}, e.rid))]
			})
		})]
	});
}
//#endregion
//#region src/games/tantrix/bot.ts
var Ee = (e, t) => {
	let n = e.public;
	if (n.mode !== "strategy" || n.phase === "done" || n.active !== t.rid) return null;
	if (n.phase === "colors") return { action: {
		type: "chooseColor",
		color: S.find((e) => !n.players.some((t) => t.color === e))
	} };
	let r = n.players.find((e) => e.rid === t.rid), i = L(n.board, r.hand, n.bagCount > 0, n.step !== "free");
	if (!i.length) return null;
	if (t.difficulty === "weak") {
		let e = Math.floor(4294967296 / i.length) * i.length, t;
		do
			t = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
		while (t >= e);
		return { action: {
			type: "place",
			...i[t % i.length]
		} };
	}
	let a = i[0], o = -Infinity, s = n.players.filter((e) => e.rid !== t.rid && e.color);
	for (let e of i) {
		let t = {
			...n.board,
			[O(e.q, e.r)]: {
				tile: e.tile,
				rot: e.rot
			}
		}, i = z(t, r.color), c = i.score * 5 + i.line * .8;
		for (let e of s) c -= (z(t, e.color).score - e.score) * 3;
		let l = r.hand.filter((t) => t !== e.tile);
		c += Math.min(8, L(t, l, n.bagCount > 1, !0).length) * .3, c > o && (a = e, o = c);
	}
	return { action: {
		type: "place",
		...a
	} };
};
//#endregion
//#region src/games/tantrix/game-over.tsx
function De({ public: e, result: t, members: n, myRid: r, onPlayAgain: i, onPlayAgainWithConfig: a, onBackToLobby: s }) {
	let c = o(), l = e, u = l.mode !== "strategy", d = T.findIndex((e) => e.id === l.puzzle), f = T[d + 1]?.series === l.mode ? T[d + 1] : void 0, p = (e) => n.find((t) => t.rid === e)?.name ?? e, m = l.players.find((e) => e.rid === t.winner[0]);
	return /* @__PURE__ */ y("main", {
		className: "tantrix-over",
		children: [
			/* @__PURE__ */ y("header", {
				className: "tantrix-over-head",
				children: [/* @__PURE__ */ v("h1", {
					className: "tantrix-over-title font-display",
					children: c(u ? "games.tantrix.finished" : l.deadlock ? "games.tantrix.deadlock" : "games.tantrix.victory")
				}), !u && !l.deadlock && m && /* @__PURE__ */ y("div", {
					className: "tantrix-winner",
					children: [
						m.color && /* @__PURE__ */ v("span", {
							className: "tantrix-color-dot",
							style: { background: C[m.color] },
							children: m.color
						}),
						/* @__PURE__ */ v("span", { children: t.winner.length > 1 ? c("games.tantrix.tied") : c("games.tantrix.winner", { name: p(m.rid) }) }),
						/* @__PURE__ */ v("strong", {
							className: "font-display",
							children: c("games.tantrix.points", { n: t.scores?.[m.rid] ?? m.score })
						})
					]
				})]
			}),
			/* @__PURE__ */ v("div", {
				className: "tantrix-over-board",
				children: /* @__PURE__ */ v(Se, {
					adaptive: !0,
					board: l.board,
					last: l.last,
					maxScale: .8
				})
			}),
			/* @__PURE__ */ v("div", {
				className: "tantrix-over-results",
				children: u ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ y("div", {
					className: "tantrix-result-row",
					children: [/* @__PURE__ */ v("strong", { children: c(Ce[l.puzzle]) }), /* @__PURE__ */ v("span", { children: c("games.tantrix.moves", { n: l.moves }) })]
				}), /* @__PURE__ */ v("div", {
					className: "tantrix-result-row",
					children: l.solvedColors.map((e) => /* @__PURE__ */ y("span", { children: [
						e,
						" · ",
						c($[e])
					] }, e))
				})] }) : t.ranking.map((e) => {
					let n = l.players.find((t) => t.rid === e);
					return /* @__PURE__ */ y("div", {
						className: "tantrix-result-row",
						children: [
							n.color && /* @__PURE__ */ v("span", {
								className: "tantrix-color-dot",
								style: { background: C[n.color] },
								"aria-label": c($[n.color]),
								children: n.color
							}),
							/* @__PURE__ */ y("div", {
								className: "tantrix-result-detail",
								children: [/* @__PURE__ */ v("div", { children: e === r ? c("games.tantrix.you") : p(e) }), /* @__PURE__ */ y("div", { children: [
									c("games.tantrix.line", { n: n.line }),
									" · ",
									c("games.tantrix.loop", { n: n.loop })
								] })]
							}),
							/* @__PURE__ */ v("strong", {
								className: "font-display",
								children: c("games.tantrix.points", { n: t.scores?.[e] ?? n.score })
							})
						]
					}, e);
				})
			}),
			/* @__PURE__ */ y("footer", {
				className: "tantrix-over-actions",
				children: [
					s && /* @__PURE__ */ v("button", {
						type: "button",
						className: "tantrix-piece-button font-display",
						onClick: s,
						children: c(u ? "games.tantrix.back" : "session.result.backToLobby")
					}),
					i && /* @__PURE__ */ v("button", {
						type: "button",
						className: `tantrix-piece-button font-display${!f || !a ? " tantrix-place-button" : ""}`,
						onClick: i,
						children: c("games.tantrix.replay")
					}),
					f && a && /* @__PURE__ */ v("button", {
						type: "button",
						className: "tantrix-piece-button tantrix-place-button font-display",
						onClick: () => a({
							mode: l.mode,
							puzzle: f.id
						}),
						children: c("games.tantrix.next")
					}),
					!i && !s && /* @__PURE__ */ v("span", { children: c("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/tantrix/options.tsx
function Oe({ value: e, onChange: t }) {
	let n = o(), r = J.safeParse(e), i = r.success ? r.data : J.parse(void 0);
	return /* @__PURE__ */ y("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ y(x, {
			title: n("games.tantrix.optMode"),
			children: [
				/* @__PURE__ */ v(b, {
					name: "tantrix-mode",
					value: "strategy",
					checked: i.mode === "strategy",
					label: n("games.tantrix.strategy"),
					hint: n("games.tantrix.strategyHint"),
					accent: W.accent,
					onChange: () => t({
						...i,
						mode: "strategy"
					})
				}),
				/* @__PURE__ */ v(b, {
					name: "tantrix-mode",
					value: "discovery",
					checked: i.mode === "discovery",
					label: n("games.tantrix.discovery"),
					hint: n("games.tantrix.puzzleHint"),
					accent: W.accent,
					onChange: () => t({
						mode: "discovery",
						puzzle: "d1"
					})
				}),
				/* @__PURE__ */ v(b, {
					name: "tantrix-mode",
					value: "rainbow",
					checked: i.mode === "rainbow",
					label: n("games.tantrix.rainbow"),
					hint: n("games.tantrix.puzzleHint"),
					accent: W.accent,
					onChange: () => t({
						mode: "rainbow",
						puzzle: "r1"
					})
				})
			]
		}), i.mode !== "strategy" && /* @__PURE__ */ v(x, {
			title: n("games.tantrix.optPuzzle"),
			children: T.filter((e) => e.series === i.mode).map((e) => /* @__PURE__ */ v(b, {
				name: "tantrix-puzzle",
				value: e.id,
				checked: i.puzzle === e.id,
				label: n(Ce[e.id]),
				accent: W.accent,
				onChange: () => t({
					...i,
					puzzle: e.id
				})
			}, e.id))
		})]
	});
}
//#endregion
//#region src/games/tantrix/guide.tsx
function ke() {
	let e = o(), t = (e) => `translate(${Q(e).join(" ")})`;
	return /* @__PURE__ */ y("div", {
		className: "tantrix-guide",
		children: [
			/* @__PURE__ */ y("figure", { children: [/* @__PURE__ */ y("svg", {
				viewBox: "-105 -58 210 116",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ v("g", {
					transform: "translate(-43 0)",
					children: /* @__PURE__ */ v(he, { tile: 3 })
				}), /* @__PURE__ */ v("g", {
					transform: "translate(43 0)",
					children: /* @__PURE__ */ v(he, {
						tile: 3,
						rot: 3
					})
				})]
			}), /* @__PURE__ */ v("figcaption", { children: e("games.tantrix.matchGuide") })] }),
			/* @__PURE__ */ y("figure", { children: [/* @__PURE__ */ y("svg", {
				viewBox: "-130 -70 260 200",
				"aria-hidden": "true",
				children: [
					[
						"-1,0",
						"-1,1",
						"0,1"
					].map((e) => /* @__PURE__ */ v("g", {
						transform: t(e),
						children: /* @__PURE__ */ v("polygon", {
							points: Z,
							fill: "#202632",
							stroke: "#75808c",
							strokeWidth: 2
						})
					}, e)),
					/* @__PURE__ */ v("polygon", {
						points: Z,
						fill: "none",
						stroke: "var(--color-warn)",
						strokeDasharray: "7 5",
						strokeWidth: 4
					}),
					/* @__PURE__ */ v("text", {
						textAnchor: "middle",
						y: 9,
						fontSize: 30,
						fill: "var(--color-warn-ink)",
						children: "!"
					})
				]
			}), /* @__PURE__ */ v("figcaption", { children: e("games.tantrix.forceGuide") })] }),
			/* @__PURE__ */ y("figure", { children: [/* @__PURE__ */ y("svg", {
				viewBox: "-210 -65 420 220",
				"aria-hidden": "true",
				children: [[
					"-2,0",
					"-2,1",
					"-1,1",
					"0,1",
					"1,1"
				].map((e) => /* @__PURE__ */ v("g", {
					transform: t(e),
					children: /* @__PURE__ */ v("polygon", {
						points: Z,
						fill: "#202632",
						stroke: "#75808c",
						strokeWidth: 2
					})
				}, e)), [
					"A",
					"B",
					"C"
				].map((e, n) => /* @__PURE__ */ y("g", {
					transform: t(`${n - 1},0`),
					children: [/* @__PURE__ */ v("polygon", {
						points: Z,
						fill: "none",
						stroke: "var(--color-info-ink)",
						strokeWidth: 2,
						strokeDasharray: "6 5"
					}), /* @__PURE__ */ v("text", {
						textAnchor: "middle",
						y: 8,
						fontSize: 27,
						fill: "var(--color-ink)",
						children: e
					})]
				}, e))]
			}), /* @__PURE__ */ v("figcaption", { children: e("games.tantrix.controlGuide") })] }),
			/* @__PURE__ */ y("figure", { children: [/* @__PURE__ */ y("svg", {
				viewBox: "-55 -60 195 200",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ v("path", {
					d: "M0 0 L86.6 0 L43.3 75 Z",
					fill: "none",
					stroke: "#5398ff",
					strokeWidth: 12,
					strokeLinejoin: "round"
				}), [
					"0,0",
					"1,0",
					"0,1"
				].map((e) => /* @__PURE__ */ y("g", {
					transform: t(e),
					children: [/* @__PURE__ */ v("circle", {
						r: 22,
						fill: "#202632"
					}), /* @__PURE__ */ v("text", {
						y: 8,
						textAnchor: "middle",
						fontSize: 22,
						fill: "#ffd54b",
						children: "2"
					})]
				}, e))]
			}), /* @__PURE__ */ v("figcaption", { children: e("games.tantrix.loopGuide") })] })
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/tantrix/entry.tsx
var Ae = {
	definition: pe,
	View: we,
	bot: Ee,
	OverView: De,
	Options: Oe,
	Guide: ke,
	locales: {
		zh: {
			name: "探索棋",
			desc: "连接彩色线路，挑战策略对局与单人谜题",
			rules: "目标:\n· 策略对局中，延长自己的颜色线路或组成闭环。\n· 解谜模式中，使用题目指定的全部棋片完成目标。\n准备:\n· 标准套装有 56 块棋片，每块包含三种颜色的连接线。\n· 策略对局支持 2–4 人，每人选择一种不同的目标颜色。\n· 每人先抽一块，编号最高者先手，再各抽五块。\n· 所有人的六块手牌公开，每放一块立即补抽，袋空后不再补抽。\n策略流程:\n· 相接棋片的连接线必须同色，已经确认的棋片不能移动。\n· 每回合先填补能够填入的强制空位，再自由放置一块。\n· 自由落子后，再填补能够填入的强制空位，随后换下一人。\n· 被三块或更多棋片包围的空位是强制空位。\n· 有多种合法补位时，由当前玩家选择棋片、位置及方向。\n袋空前的限制:\n· 不得制造三条同色连接线朝内的强制空位。\n· 不得在强制空位周围放置第四块棋片。\n· 强制空位两侧的受控边不得继续放置棋片，见下图。\n· 抽走袋中最后一块后，这三项限制立即解除。\n· 袋空后，颜色匹配与强制补位规则仍然有效。\n策略结算:\n· 全部棋片放完后，比较每人的最长线路与最长闭环。\n· 线路每块计 1 分，闭环每块计 2 分，只取其中较高的分数。\n· 分数最高者获胜，同分并列；自由落子无合法位置时判和。\nDiscovery:\n· 使用从 1 号起的前 3–10 块棋片，组成指定颜色闭环。\n· 七块棋片的谜题采用标准 Game Pack 的蓝色目标。\n· 十块棋片分别提供红、蓝、黄三种目标题。\nRainbow:\n· 初级与进阶：自选一种颜色，闭环经过全部棋片。\n· 教授：同时组成两色闭环，每环经过含该色的全部棋片。\n· 大师：自选一种颜色，闭环经过含该色的全部棋片。\n· 天才：在红、黄、蓝中选两色，同时形成两条开放线路。\n· 天才的每条线路须经过含该色的全部棋片。\n· Rainbow 的全部棋片须相连，且不得围出空洞。\n解谜操作:\n· 棋片可以移动、旋转或收回，也可以撤销上一步。\n· 所有相接边仍须同色，全部目标达成后自动完成。",
			strategy: "策略对局",
			discovery: "Discovery",
			rainbow: "Rainbow",
			optMode: "玩法",
			optPuzzle: "选择谜题",
			strategyHint: "2–4 人 · 公开手牌",
			puzzleHint: "1 人 · 自由拼接",
			d1: "3 块 · 黄色闭环",
			d2: "4 块 · 红色闭环",
			d3: "5 块 · 红色闭环",
			d4: "6 块 · 蓝色闭环",
			d5: "7 块 · 蓝色闭环",
			d6: "8 块 · 蓝色闭环",
			d7: "9 块 · 黄色闭环",
			d8: "10 块 · 红色闭环",
			d9: "10 块 · 蓝色闭环",
			d10: "10 块 · 黄色闭环",
			r1: "初级",
			r2: "进阶",
			r3: "教授",
			r4: "大师",
			r5: "天才",
			red: "红色",
			yellow: "黄色",
			green: "绿色",
			blue: "蓝色",
			chooseColor: "选择你的目标颜色",
			waitingColor: "等待 {{name}} 选择颜色",
			freeMove: "自由放置一块棋片",
			forcedMove: "填补强制空位",
			waiting: "等待{{name}}落子",
			yourTurn: "轮到你落子",
			you: "你",
			yourTiles: "你的棋片",
			unselected: "未选色",
			loopGoal: "组成{{color}}闭环",
			anyGoal: "组成一种颜色的闭环",
			doubleGoal: "同时组成两色闭环",
			geniusGoal: "选择红、黄、蓝中两色组成开放线路",
			allTilesGoal: "经过全部棋片",
			colouredTilesGoal: "各经过含该色的全部棋片",
			geniusDetail: "各经过含该色的全部棋片",
			singleColourGoal: "经过含该色的全部棋片",
			placement: "棋片放置操作",
			place: "放置",
			chooseTarget: "选择{{color}}作为目标颜色",
			noMoves: "这块棋片没有可用位置",
			targetLoop: "组成{{color}}闭环，经过全部棋片",
			targetAny: "一种颜色的闭环经过全部棋片",
			targetDouble: "两色闭环，各经过含该色的全部棋片",
			targetMaster: "一种颜色的闭环经过含该色的全部棋片",
			targetGenius: "红、黄、蓝中两色，各形成完整的开放线路",
			bag: "袋中 {{n}}",
			endgame: "袋已空",
			turn: "回合 {{n}}",
			confirm: "确认放置",
			rotate: "旋转棋片",
			cancel: "取消选择",
			remove: "收回棋片",
			undo: "撤销",
			reset: "重置谜题",
			resetConfirm: "确认重置",
			opponents: "公开手牌",
			close: "关闭",
			fit: "适配全盘",
			latest: "最近落子",
			zoomIn: "放大",
			zoomOut: "缩小",
			tile: "{{n}} 号棋片",
			placeAt: "放置到 {{q}}，{{r}}",
			board: "探索棋棋盘",
			hand: "待用棋片",
			selectTile: "选择棋片，再点棋盘上的位置",
			selectPosition: "选择位置，旋转后确认放置",
			noFit: "当前方向不匹配，请旋转棋片",
			empty: "选择棋片开始拼接",
			finished: "谜题完成",
			victory: "对局结束",
			deadlock: "无合法落子，本局和棋",
			line: "最长线路 {{n}}",
			loop: "最长闭环 {{n}}",
			points: "{{n}} 分",
			replay: "再玩一次",
			next: "下一题",
			back: "返回选题",
			moves: "操作 {{n}} 次",
			winner: "{{name}}获胜",
			tied: "并列获胜",
			matchGuide: "相接棋片在接触边上的连接线颜色必须一致。",
			forceGuide: "被3块或更多棋片包围的空位称为强制空位。自由落子前后，都必须先填补手牌能够填入的强制空位。",
			controlGuide: "袋中仍有棋片时，必须先填补A处的强制空位，才能沿该侧在B处或C处放置棋片。",
			loopGuide: "策略对局中，最长闭环的每块棋片计2分，是开放线路每块棋片分值的两倍。",
			errTurn: "现在不能执行此操作",
			errColor: "这种颜色已经被选择",
			errTile: "请选择可用的棋片",
			errMatch: "这个位置或方向不符合放置规则",
			errForced: "请先填补能够填入的强制空位",
			errUndo: "当前没有可以撤销的操作"
		},
		en: {
			name: "Tantrix",
			desc: "Connect colourful tracks in strategy games and solo puzzles",
			rules: "Goal:\n· In Strategy, extend your colour’s line or form a loop.\n· In puzzles, use every specified tile to complete the objectives.\nSetup:\n· The standard set has 56 tiles, each with tracks in three colours.\n· Strategy is for 2–4 players, each choosing a different colour.\n· Draw one tile each; the highest number starts. Draw five more each.\n· All six tiles are public. Replace each played tile until the bag is empty.\nStrategy turns:\n· All touching tracks must match. Confirmed tiles cannot move.\n· First fill any forced spaces you can, then make one free move.\n· Fill any forced spaces you can again, then pass to the next player.\n· An empty space bordered by three or more tiles is forced.\n· When several plays fit, the active player chooses tile, space and rotation.\nRestrictions before the bag is empty:\n· Do not create a forced space with three inward links of one colour.\n· Do not place a fourth tile around a forced space.\n· Do not play along the controlled sides of a forced space; see below.\n· These three restrictions end immediately when the last tile is drawn.\n· Matching colours and filling forced spaces still apply in the endgame.\nStrategy scoring:\n· Once all tiles are played, compare each player’s longest line and loop.\n· Lines score 1 per tile; loops score 2. Only the better score counts.\n· Highest score wins; ties share victory. No legal free move means a draw.\nDiscovery:\n· Use tiles 1 through 3–10 to form the specified loop through every tile.\n· The seven-tile challenge uses the standard Game Pack’s blue objective.\n· Ten tiles have separate red, blue and yellow challenges.\nRainbow:\n· Junior and Student: choose a colour and loop through all tiles.\n· Professor: form two coloured loops, each using every tile of its colour.\n· Master: choose a colour and loop through every tile with that colour.\n· Genius: choose two of red, yellow and blue and form two open lines.\n· Each Genius line must pass through every tile with its colour.\n· In Rainbow, all tiles must connect, without enclosing holes.\nPuzzle controls:\n· Move, rotate or return tiles, or undo the previous action.\n· Every touching edge must match. Complete all objectives to finish.",
			strategy: "Strategy",
			discovery: "Discovery",
			rainbow: "Rainbow",
			optMode: "Mode",
			optPuzzle: "Choose a puzzle",
			strategyHint: "2–4 players · Open hands",
			puzzleHint: "1 player · Rearrange freely",
			d1: "3 tiles · Yellow",
			d2: "4 tiles · Red",
			d3: "5 tiles · Red",
			d4: "6 tiles · Blue",
			d5: "7 tiles · Blue",
			d6: "8 tiles · Blue",
			d7: "9 tiles · Yellow",
			d8: "10 tiles · Red",
			d9: "10 tiles · Blue",
			d10: "10 tiles · Yellow",
			r1: "Junior",
			r2: "Student",
			r3: "Professor",
			r4: "Master",
			r5: "Genius",
			red: "Red",
			yellow: "Yellow",
			green: "Green",
			blue: "Blue",
			chooseColor: "Choose your colour",
			waitingColor: "Waiting for {{name}} to choose",
			freeMove: "Place one tile freely",
			forcedMove: "Fill the forced spaces you can",
			waiting: "Waiting for {{name}}",
			yourTurn: "Your turn",
			you: "You",
			yourTiles: "Your tiles",
			unselected: "No colour",
			loopGoal: "Form a {{color}} loop",
			anyGoal: "Form a loop in one colour",
			doubleGoal: "Form two coloured loops",
			geniusGoal: "Form two lines in red, yellow or blue",
			allTilesGoal: "Through every tile",
			colouredTilesGoal: "Each through every tile of its colour",
			geniusDetail: "Each through every tile of its colour",
			singleColourGoal: "Through every tile of its colour",
			placement: "Tile placement controls",
			place: "Place",
			chooseTarget: "Choose {{color}} as your target",
			noMoves: "This tile has no legal position",
			targetLoop: "A {{color}} loop through every tile",
			targetAny: "One coloured loop through every tile",
			targetDouble: "Two loops, each using every tile of its colour",
			targetMaster: "One loop using every tile of its colour",
			targetGenius: "Two complete open lines in red, yellow or blue",
			bag: "Bag {{n}}",
			endgame: "Bag empty",
			turn: "Turn {{n}}",
			confirm: "Place tile",
			rotate: "Rotate tile",
			cancel: "Deselect",
			remove: "Return tile",
			undo: "Undo",
			reset: "Reset puzzle",
			resetConfirm: "Confirm reset",
			opponents: "Open hands",
			close: "Close",
			fit: "Fit board",
			latest: "Last tile",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			tile: "Tile {{n}}",
			placeAt: "Place at {{q}}, {{r}}",
			board: "Tantrix board",
			hand: "Available tiles",
			selectTile: "Choose a tile, then a space",
			selectPosition: "Choose a space, rotate and confirm",
			noFit: "Rotate the tile to match",
			empty: "Choose a tile to begin",
			finished: "Puzzle solved",
			victory: "Game over",
			deadlock: "No legal move — game drawn",
			line: "Longest line {{n}}",
			loop: "Longest loop {{n}}",
			points: "{{n}} points",
			replay: "Play again",
			next: "Next puzzle",
			back: "Choose a puzzle",
			moves: "{{n}} actions",
			winner: "{{name}} wins",
			tied: "Joint winners",
			matchGuide: "The tracks on every pair of touching tile edges must have matching colours.",
			forceGuide: "An empty space bordered by three or more tiles is a forced space. Before and after your free move, fill every forced space that you can fill from your hand.",
			controlGuide: "While tiles remain in the bag, you must fill the forced space at A before placing a tile at B or C along that side.",
			loopGuide: "In Strategy, each tile in your longest loop scores 2 points, twice the 1 point per tile in an open line.",
			errTurn: "You cannot do that now",
			errColor: "That colour is already taken",
			errTile: "Choose an available tile",
			errMatch: "That position or rotation is not allowed",
			errForced: "Fill the forced spaces you can first",
			errUndo: "There is nothing to undo"
		}
	}
};
//#endregion
export { Ae as default };
