import { z as e } from "zod";
import { useEffect as t, useRef as n, useState as r } from "react";
import { useT as i } from "@bgparty/sdk/i18n";
import { useWakeLock as a } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { Fragment as c, jsx as l, jsxs as u } from "react/jsx-runtime";
import { FlySprite as d, PulseBox as f } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as p, OptionSection as m } from "@bgparty/sdk/ui/game-options";
//#region src/games/decorum/meta.ts
var h = {
	id: "decorum",
	tier: "alpha",
	mechanics: ["deduction", "tile-placement"],
	interactionTags: ["cooperative", "communication-limits"],
	nameKey: "games.decorum.name",
	descKey: "games.decorum.desc",
	rulesKey: "games.decorum.rules",
	icon: "🏠",
	iconImg: "games/decorum.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#205dcc",
	releasedAt: "2026-11-04T00:40:00+08:00",
	search: {
		py: "tong fang yi meng",
		init: "tfym"
	},
	hotseat: "cover",
	botDelayMs: 900
}, g = [
	0,
	1,
	2,
	3
], _ = [
	0,
	1,
	2
], v = [
	[
		0,
		1,
		2
	],
	[
		1,
		2,
		0
	],
	[
		0,
		2,
		1
	],
	[
		2,
		1,
		0
	]
], y = [
	[
		3,
		2,
		0,
		1
	],
	[
		0,
		3,
		1,
		2
	],
	[
		2,
		1,
		3,
		0
	]
], b = (e) => e == null || e === 12 ? -1 : e % 4, x = (e) => e == null || e === 12 ? -1 : Math.floor(e / 4), S = (e) => e == null || e === 12 ? -1 : y[Math.floor(e / 4)][e % 4], C = [[0, 1], [2, 3]], w = [[0, 2], [1, 3]], T = [
	0,
	1,
	2,
	3
], E = (e) => e.reduce((e, t) => e + t, 0), D = (e) => [...new Set(e)], O = class e {
	house;
	owner;
	constructor(e, t) {
		this.house = e, this.owner = t;
	}
	get rooms() {
		return this.house.rooms;
	}
	get mine() {
		return this.house.roommates[this.owner];
	}
	get side() {
		return this.mine % 2 == 0 ? w[0] : w[1];
	}
	get otherSide() {
		return this.mine % 2 == 0 ? w[1] : w[0];
	}
	objects(e = T) {
		return e.flatMap((e) => this.rooms[e].slots.filter((e) => e !== null && e !== 12));
	}
	slots(e = T) {
		return e.flatMap((e) => this.rooms[e].slots);
	}
	features(e = T) {
		return [...this.objects(e).map(b), ...e.map((e) => this.rooms[e].wall)];
	}
	n(e = "", t = T) {
		if (e.startsWith("p")) return E(t.flatMap((t) => this.rooms[t].pets.map((t, n) => {
			let r = n < 2, i = n % 2 == 0;
			return e.includes("c") && !r || e.includes("d") && r || e.includes("s") && !i || e.includes("b") && i ? 0 : t;
		})));
		if (e === "e") return this.slots(t).filter((e) => e === null).length;
		if (e === "g") return this.slots(t).filter((e) => e === 12).length;
		if (e === "filled") return this.slots(t).filter((e) => e !== null).length;
		let n = [...e].find((e) => "RYGB".includes(e)), r = n === void 0 ? -1 : "RYGB".indexOf(n);
		if (e.startsWith("W")) return t.filter((e) => r < 0 || this.rooms[e].wall === r).length;
		if (e.startsWith("F")) return this.features(t).filter((e) => r < 0 || e === r).length;
		let i = [...e].find((e) => "chl".includes(e)), a = [...e].find((e) => "maru".includes(e));
		return this.objects(t).filter((e) => (r < 0 || b(e) === r) && (i === void 0 || x(e) === "chl".indexOf(i)) && (a === void 0 || S(e) === "maru".indexOf(a))).length;
	}
	distinct(e, t = T) {
		return D(e === "feature" ? this.features(t) : e === "wall" ? t.map((e) => this.rooms[e].wall) : this.objects(t).map(e === "style" ? S : b)).length;
	}
	all(e, t = T) {
		return t.every(e);
	}
	some(e, t = T) {
		return t.some(e);
	}
	warm(e = T) {
		return this.n("FR", e) + this.n("FY", e);
	}
	cool(e = T) {
		return this.n("FG", e) + this.n("FB", e);
	}
	objectWarm(e = T) {
		return this.n("R", e) + this.n("Y", e);
	}
	objectCool(e = T) {
		return this.n("G", e) + this.n("B", e);
	}
	most(e, t, n = T) {
		return [...t].filter((t) => t !== e).every((t) => this.n(e, n) > this.n(t, n));
	}
	noDuplicates(e = T) {
		let t = this.objects(e);
		return D(t).length === t.length;
	}
	allObjects(t, n = T) {
		return Array.from({ length: 12 }, (e, t) => t).filter((n) => new e({
			rooms: [{
				wall: 0,
				slots: [n],
				pets: []
			}],
			roommates: [0]
		}, 0).n(t, [0]) > 0).every((e) => this.objects(n).includes(e));
	}
	ordered(e, t) {
		return e.every((n, r) => r === 0 || t.indexOf(n) >= t.indexOf(e[r - 1]));
	}
	edge(e, t = !1) {
		let n = this.rooms[e].slots.filter((e) => e !== null);
		return (t ? n.at(-1) : n[0]) ?? null;
	}
	cyclic(e, t = !0) {
		let n = (t ? [
			0,
			1,
			3,
			2
		] : [
			0,
			2,
			3,
			1
		]).map((t) => e[t]);
		return n.every((e, t) => e >= 0 && n[(t + 1) % 4] === (e + 1) % 4);
	}
}, k = {
	c1p1q1: {
		id: "c1p1q1",
		key: "games.decorum.conditions.c1p1q1",
		source: "390_53984c0975.png",
		test: (e) => e.all((t) => e.rooms[t].wall === 3, [0, 2])
	},
	c1p1q2: {
		id: "c1p1q2",
		key: "games.decorum.conditions.c1p1q2",
		source: "390_53984c0975.png",
		test: (e) => e.n("lY") >= 1
	},
	c1p1q3: {
		id: "c1p1q3",
		key: "games.decorum.conditions.c1p1q3",
		source: "390_53984c0975.png",
		test: (e) => e.n("filled", [3]) === 0
	},
	c1p2q1: {
		id: "c1p2q1",
		key: "games.decorum.conditions.c1p2q1",
		source: "392_8a1c9d6016.png",
		test: (e) => e.n("l", [0, 2]) === 0
	},
	c1p2q2: {
		id: "c1p2q2",
		key: "games.decorum.conditions.c1p2q2",
		source: "392_8a1c9d6016.png",
		test: (e) => e.n("a") <= 1
	},
	c1p2q3: {
		id: "c1p2q3",
		key: "games.decorum.conditions.c1p2q3",
		source: "392_8a1c9d6016.png",
		test: (e) => e.n("filled", [2, 3]) >= 2
	},
	c2p1q1: {
		id: "c2p1q1",
		key: "games.decorum.conditions.c2p1q1",
		source: "396_00624ba97f.png",
		test: (e) => e.all((t) => e.distinct("style", [t]) <= 1)
	},
	c2p1q2: {
		id: "c2p1q2",
		key: "games.decorum.conditions.c2p1q2",
		source: "396_00624ba97f.png",
		test: (e) => e.distinct("style") === 4
	},
	c2p1q3: {
		id: "c2p1q3",
		key: "games.decorum.conditions.c2p1q3",
		source: "396_00624ba97f.png",
		test: (e) => _.every((t) => e.n("chl"[t]) > 0)
	},
	c2p1q4: {
		id: "c2p1q4",
		key: "games.decorum.conditions.c2p1q4",
		source: "396_00624ba97f.png",
		test: (e) => e.n("WY", [2, 3]) === 1 && e.n("WG", [2, 3]) === 1
	},
	c2p2q1: {
		id: "c2p2q1",
		key: "games.decorum.conditions.c2p2q1",
		source: "398_ad3925f51b.png",
		test: (e) => e.all((t) => e.distinct("color", [t]) <= 1)
	},
	c2p2q2: {
		id: "c2p2q2",
		key: "games.decorum.conditions.c2p2q2",
		source: "398_ad3925f51b.png",
		test: (e) => e.distinct("color") === 4
	},
	c2p2q3: {
		id: "c2p2q3",
		key: "games.decorum.conditions.c2p2q3",
		source: "398_ad3925f51b.png",
		test: (e) => e.distinct("wall") === 4
	},
	c2p2q4: {
		id: "c2p2q4",
		key: "games.decorum.conditions.c2p2q4",
		source: "398_ad3925f51b.png",
		test: (e) => e.n("hG") >= 1
	},
	c3p1q1: {
		id: "c3p1q1",
		key: "games.decorum.conditions.c3p1q1",
		source: "402_8894df7448.png",
		test: (e) => e.all((t) => e.n("r", [t]) >= 1)
	},
	c3p1q2: {
		id: "c3p1q2",
		key: "games.decorum.conditions.c3p1q2",
		source: "402_8894df7448.png",
		test: (e) => e.all((t) => e.objects([t]).some((n) => S(n) === 2 && b(n) === e.rooms[t].wall))
	},
	c3p1q3: {
		id: "c3p1q3",
		key: "games.decorum.conditions.c3p1q3",
		source: "402_8894df7448.png",
		test: (e) => e.allObjects("r")
	},
	c3p1q4: {
		id: "c3p1q4",
		key: "games.decorum.conditions.c3p1q4",
		source: "402_8894df7448.png",
		test: (e) => e.n("m", [2, 3]) === 0
	},
	c3p2q1: {
		id: "c3p2q1",
		key: "games.decorum.conditions.c3p2q1",
		source: "404_ac03eb75ff.png",
		test: (e) => e.all((t) => e.distinct("style", [t]) === e.n("", [t]))
	},
	c3p2q2: {
		id: "c3p2q2",
		key: "games.decorum.conditions.c3p2q2",
		source: "404_ac03eb75ff.png",
		test: (e) => e.n("l", [0, 2]) === 0
	},
	c3p2q3: {
		id: "c3p2q3",
		key: "games.decorum.conditions.c3p2q3",
		source: "404_ac03eb75ff.png",
		test: (e) => e.all((t) => e.n("G", [t]) >= 1)
	},
	c3p2q4: {
		id: "c3p2q4",
		key: "games.decorum.conditions.c3p2q4",
		source: "404_ac03eb75ff.png",
		test: (e) => e.all((t) => e.rooms[t].wall === 0, [1, 3])
	},
	c4p1q1: {
		id: "c4p1q1",
		key: "games.decorum.conditions.c4p1q1",
		source: "408_015db139b1.png",
		test: (e) => e.allObjects("B")
	},
	c4p1q2: {
		id: "c4p1q2",
		key: "games.decorum.conditions.c4p1q2",
		source: "408_015db139b1.png",
		test: (e) => e.n("filled", [2]) > e.n("filled", [0]) && e.n("filled", [3]) > e.n("filled", [1])
	},
	c4p1q3: {
		id: "c4p1q3",
		key: "games.decorum.conditions.c4p1q3",
		source: "408_015db139b1.png",
		test: (e) => g.every((t) => e.n("F" + "RYGB"[t]) >= 2)
	},
	c4p1q4: {
		id: "c4p1q4",
		key: "games.decorum.conditions.c4p1q4",
		source: "408_015db139b1.png",
		test: (e) => e.warm([0, 1]) === 0
	},
	c4p2q1: {
		id: "c4p2q1",
		key: "games.decorum.conditions.c4p2q1",
		source: "410_e51f119683.png",
		test: (e) => e.all((t) => e.distinct("feature", [t]) === e.features([t]).length)
	},
	c4p2q2: {
		id: "c4p2q2",
		key: "games.decorum.conditions.c4p2q2",
		source: "410_e51f119683.png",
		test: (e) => e.allObjects("u")
	},
	c4p2q3: {
		id: "c4p2q3",
		key: "games.decorum.conditions.c4p2q3",
		source: "410_e51f119683.png",
		test: (e) => e.n("l", [2, 3]) === 0
	},
	c4p2q4: {
		id: "c4p2q4",
		key: "games.decorum.conditions.c4p2q4",
		source: "410_e51f119683.png",
		test: (e) => w.every((t) => e.distinct("feature", t) === 4)
	},
	c5p1q1: {
		id: "c5p1q1",
		key: "games.decorum.conditions.c5p1q1",
		source: "414_c206870c23.png",
		test: (e) => e.all((t) => e.rooms[t].wall >= 2, [1, 3]) && e.all((t) => e.rooms[t].wall < 2, [0, 2])
	},
	c5p1q2: {
		id: "c5p1q2",
		key: "games.decorum.conditions.c5p1q2",
		source: "414_c206870c23.png",
		test: (e) => e.n("l") === e.n("lR") + e.n("lY") && e.n("h") === e.n("hG") + e.n("hB")
	},
	c5p1q3: {
		id: "c5p1q3",
		key: "games.decorum.conditions.c5p1q3",
		source: "414_c206870c23.png",
		test: (e) => e.distinct("color") === 4
	},
	c5p1q4: {
		id: "c5p1q4",
		key: "games.decorum.conditions.c5p1q4",
		source: "414_c206870c23.png",
		test: (e) => T.filter((t) => e.distinct("color", [t]) === 1).length >= 2
	},
	c5p2q1: {
		id: "c5p2q1",
		key: "games.decorum.conditions.c5p2q1",
		source: "416_4895fd2605.png",
		test: (e) => e.all((t) => e.objects([t]).every((n) => b(n) < 2 != e.rooms[t].wall < 2))
	},
	c5p2q2: {
		id: "c5p2q2",
		key: "games.decorum.conditions.c5p2q2",
		source: "416_4895fd2605.png",
		test: (e) => e.objectWarm() === 4 && e.objectCool() === 4
	},
	c5p2q3: {
		id: "c5p2q3",
		key: "games.decorum.conditions.c5p2q3",
		source: "416_4895fd2605.png",
		test: (e) => e.objects().filter((e) => x(e) === 0).every((t) => e.objects().filter((e) => e === t).length === 2)
	},
	c5p2q4: {
		id: "c5p2q4",
		key: "games.decorum.conditions.c5p2q4",
		source: "416_4895fd2605.png",
		test: (e) => e.n("m") === 0
	},
	c6p1q1: {
		id: "c6p1q1",
		key: "games.decorum.conditions.c6p1q1",
		source: "420_b8ab079fdc.png",
		test: (e) => e.all((t) => e.rooms[t].slots[0] !== null && e.rooms[t].slots[2] !== null)
	},
	c6p1q2: {
		id: "c6p1q2",
		key: "games.decorum.conditions.c6p1q2",
		source: "420_b8ab079fdc.png",
		test: (e) => e.n("FR") >= 3 && e.n("FG") >= 3
	},
	c6p1q3: {
		id: "c6p1q3",
		key: "games.decorum.conditions.c6p1q3",
		source: "420_b8ab079fdc.png",
		test: (e) => e.n("u") * 2 >= e.n("filled")
	},
	c6p1q4: {
		id: "c6p1q4",
		key: "games.decorum.conditions.c6p1q4",
		source: "420_b8ab079fdc.png",
		test: (e) => e.n("l") === e.n("h")
	},
	c6p2q1: {
		id: "c6p2q1",
		key: "games.decorum.conditions.c6p2q1",
		source: "422_c20c715f6e.png",
		test: (e) => C.every((t) => e.ordered(e.objects(t).map(S), [
			1,
			0,
			2,
			3
		]))
	},
	c6p2q2: {
		id: "c6p2q2",
		key: "games.decorum.conditions.c6p2q2",
		source: "422_c20c715f6e.png",
		test: (e) => e.all((t) => e.rooms[t].wall !== 0 || e.n("filled", [t]) <= 1)
	},
	c6p2q3: {
		id: "c6p2q3",
		key: "games.decorum.conditions.c6p2q3",
		source: "422_c20c715f6e.png",
		test: (e) => e.n("FB") >= 4 && e.n("FY") >= 4
	},
	c6p2q4: {
		id: "c6p2q4",
		key: "games.decorum.conditions.c6p2q4",
		source: "422_c20c715f6e.png",
		test: (e) => e.all((t) => e.n("e", [t]) > 0 || e.distinct("feature", [t]) === 4)
	},
	c7p1q1: {
		id: "c7p1q1",
		key: "games.decorum.conditions.c7p1q1",
		source: "426_537ab36c6b.png",
		test: (e) => e.n("filled") === 10
	},
	c7p1q2: {
		id: "c7p1q2",
		key: "games.decorum.conditions.c7p1q2",
		source: "426_537ab36c6b.png",
		test: (e) => e.distinct("wall") === 4
	},
	c7p1q3: {
		id: "c7p1q3",
		key: "games.decorum.conditions.c7p1q3",
		source: "426_537ab36c6b.png",
		test: (e) => e.n("lY", [2]) >= 1
	},
	c7p1q4: {
		id: "c7p1q4",
		key: "games.decorum.conditions.c7p1q4",
		source: "426_537ab36c6b.png",
		test: (e) => e.warm() === e.cool()
	},
	c7p2q1: {
		id: "c7p2q1",
		key: "games.decorum.conditions.c7p2q1",
		source: "428_fad94d9d18.png",
		test: (e) => e.n("h", [0]) + e.n("c", [0]) === 0
	},
	c7p2q2: {
		id: "c7p2q2",
		key: "games.decorum.conditions.c7p2q2",
		source: "428_fad94d9d18.png",
		test: (e) => e.all((t) => e.objects([t]).some((n) => x(n) === 2 && b(n) === e.rooms[t].wall))
	},
	c7p2q3: {
		id: "c7p2q3",
		key: "games.decorum.conditions.c7p2q3",
		source: "428_fad94d9d18.png",
		test: (e) => e.warm([0, 1]) === 0
	},
	c7p2q4: {
		id: "c7p2q4",
		key: "games.decorum.conditions.c7p2q4",
		source: "428_fad94d9d18.png",
		test: (e) => e.noDuplicates()
	},
	c8p1q1: {
		id: "c8p1q1",
		key: "games.decorum.conditions.c8p1q1",
		source: "432_afd48b231f.png",
		test: (e) => e.n("WB") % 2 == 1
	},
	c8p1q2: {
		id: "c8p1q2",
		key: "games.decorum.conditions.c8p1q2",
		source: "432_afd48b231f.png",
		test: (e) => e.all((t) => e.n("c", [t]) > 0 == (e.rooms[t].wall === 0))
	},
	c8p1q3: {
		id: "c8p1q3",
		key: "games.decorum.conditions.c8p1q3",
		source: "432_afd48b231f.png",
		test: (e) => e.n("B", [0, 1]) % 2 == 1
	},
	c8p1q4: {
		id: "c8p1q4",
		key: "games.decorum.conditions.c8p1q4",
		source: "432_afd48b231f.png",
		test: (e) => e.n("FG") === 0
	},
	c8p2q1: {
		id: "c8p2q1",
		key: "games.decorum.conditions.c8p2q1",
		source: "434_db8360ebb9.png",
		test: (e) => e.n("WR") > 0 && e.n("WR") % 2 == 0
	},
	c8p2q2: {
		id: "c8p2q2",
		key: "games.decorum.conditions.c8p2q2",
		source: "434_db8360ebb9.png",
		test: (e) => e.all((t) => e.distinct("feature", [t]) % 2 == 1)
	},
	c8p2q3: {
		id: "c8p2q3",
		key: "games.decorum.conditions.c8p2q3",
		source: "434_db8360ebb9.png",
		test: (e) => e.n("Y") % 2 == 1
	},
	c8p2q4: {
		id: "c8p2q4",
		key: "games.decorum.conditions.c8p2q4",
		source: "434_db8360ebb9.png",
		test: (e) => e.n("l") % 2 == 1
	},
	c9p1q1: {
		id: "c9p1q1",
		key: "games.decorum.conditions.c9p1q1",
		source: "438_f2c18635fa.png",
		test: (e) => e.all((t) => e.n("l", [t]) === 0 || e.n("h", [t]) === 0)
	},
	c9p1q2: {
		id: "c9p1q2",
		key: "games.decorum.conditions.c9p1q2",
		source: "438_f2c18635fa.png",
		test: (e) => C.every((t) => e.n("l", t) >= 1)
	},
	c9p1q3: {
		id: "c9p1q3",
		key: "games.decorum.conditions.c9p1q3",
		source: "438_f2c18635fa.png",
		test: (e) => C.every((t) => e.distinct("feature", t) === 4)
	},
	c9p1q4: {
		id: "c9p1q4",
		key: "games.decorum.conditions.c9p1q4",
		source: "438_f2c18635fa.png",
		test: (e) => w.every((t) => e.distinct("feature", t) === 4)
	},
	c9p1q5: {
		id: "c9p1q5",
		key: "games.decorum.conditions.c9p1q5",
		source: "438_f2c18635fa.png",
		test: (e) => w.every((t) => e.n("WY", t) === 1 && e.n("WB", t) === 1)
	},
	c9p2q1: {
		id: "c9p2q1",
		key: "games.decorum.conditions.c9p2q1",
		source: "440_01bbc9a713.png",
		test: (e) => e.all((t) => e.rooms[t].wall < 2 || e.n("l", [t]) > 0)
	},
	c9p2q2: {
		id: "c9p2q2",
		key: "games.decorum.conditions.c9p2q2",
		source: "440_01bbc9a713.png",
		test: (e) => C.every((t) => e.n("h", t) >= 1)
	},
	c9p2q3: {
		id: "c9p2q3",
		key: "games.decorum.conditions.c9p2q3",
		source: "440_01bbc9a713.png",
		test: (e) => e.rooms[0].wall === e.rooms[3].wall && _.every((t) => e.rooms[0].slots[v[0].indexOf(t)] === e.rooms[3].slots[v[3].indexOf(t)])
	},
	c9p2q4: {
		id: "c9p2q4",
		key: "games.decorum.conditions.c9p2q4",
		source: "440_01bbc9a713.png",
		test: (e) => C.every((t) => e.distinct("style", t) === 4)
	},
	c9p2q5: {
		id: "c9p2q5",
		key: "games.decorum.conditions.c9p2q5",
		source: "440_01bbc9a713.png",
		test: (e) => w.every((t) => e.distinct("style", t) === 4)
	},
	c10p1q1: {
		id: "c10p1q1",
		key: "games.decorum.conditions.c10p1q1",
		source: "444_a94952266f.png",
		test: (e) => e.n("WY") === 1 && [
			1,
			5,
			9
		].every((t) => e.objects().filter((e) => e === t).length === 1)
	},
	c10p1q2: {
		id: "c10p1q2",
		key: "games.decorum.conditions.c10p1q2",
		source: "444_a94952266f.png",
		test: (e) => e.distinct("style", [3]) <= 1
	},
	c10p1q3: {
		id: "c10p1q3",
		key: "games.decorum.conditions.c10p1q3",
		source: "444_a94952266f.png",
		test: (e) => e.all((t) => e.warm([t]) >= e.cool([t]))
	},
	c10p1q4: {
		id: "c10p1q4",
		key: "games.decorum.conditions.c10p1q4",
		source: "444_a94952266f.png",
		test: (e) => e.all((t) => e.n("l", [t]) === 1)
	},
	c10p2q1: {
		id: "c10p2q1",
		key: "games.decorum.conditions.c10p2q1",
		source: "446_a0da0b3e82.png",
		test: (e) => e.n("Y", [1]) === 0
	},
	c10p2q2: {
		id: "c10p2q2",
		key: "games.decorum.conditions.c10p2q2",
		source: "446_a0da0b3e82.png",
		test: (e) => e.all((t) => e.n("Y", [t]) === 0 || e.n("B", [t]) > 0)
	},
	c10p2q3: {
		id: "c10p2q3",
		key: "games.decorum.conditions.c10p2q3",
		source: "446_a0da0b3e82.png",
		test: (e) => e.n("WG") + e.n("WB") >= 2
	},
	c10p2q4: {
		id: "c10p2q4",
		key: "games.decorum.conditions.c10p2q4",
		source: "446_a0da0b3e82.png",
		test: (e) => e.n("G") === 1
	},
	c11p1q1: {
		id: "c11p1q1",
		key: "games.decorum.conditions.c11p1q1",
		source: "450_3a8dc63ffe.png",
		test: (e) => D(T.map((t) => b(e.edge(t)))).length === 4 && e.all((t) => e.edge(t) !== null)
	},
	c11p1q2: {
		id: "c11p1q2",
		key: "games.decorum.conditions.c11p1q2",
		source: "450_3a8dc63ffe.png",
		test: (e) => e.n("FR", [2, 3]) === 1 && e.n("FY", [2, 3]) === 0
	},
	c11p1q3: {
		id: "c11p1q3",
		key: "games.decorum.conditions.c11p1q3",
		source: "450_3a8dc63ffe.png",
		test: (e) => e.rooms[1].wall === 0 && e.distinct("style", [1]) === 1 && e.all((t) => e.distinct("style", [t]) === 2, [
			0,
			2,
			3
		])
	},
	c11p1q4: {
		id: "c11p1q4",
		key: "games.decorum.conditions.c11p1q4",
		source: "450_3a8dc63ffe.png",
		test: (e) => _.every((t) => T.filter((n) => e.rooms[n].slots[v[n].indexOf(t)] === null).length === 1)
	},
	c11p2q1: {
		id: "c11p2q1",
		key: "games.decorum.conditions.c11p2q1",
		source: "452_3b52f8e480.png",
		test: (e) => D(T.map((t) => b(e.edge(t, !0)))).length === 4 && e.all((t) => e.edge(t, !0) !== null)
	},
	c11p2q2: {
		id: "c11p2q2",
		key: "games.decorum.conditions.c11p2q2",
		source: "452_3b52f8e480.png",
		test: (e) => e.all((t) => g.filter((n) => n !== e.rooms[t].wall).every((n) => e.n("RYGB"[e.rooms[t].wall], [t]) > e.n("RYGB"[n], [t])))
	},
	c11p2q3: {
		id: "c11p2q3",
		key: "games.decorum.conditions.c11p2q3",
		source: "452_3b52f8e480.png",
		test: (e) => e.n("FG", [0, 1]) === 1 && e.n("FB", [0, 1]) === 0
	},
	c11p2q4: {
		id: "c11p2q4",
		key: "games.decorum.conditions.c11p2q4",
		source: "452_3b52f8e480.png",
		test: (e) => e.n("m", [0, 1]) === 0 && e.n("r", [2, 3]) === 0
	},
	c12p1q1: {
		id: "c12p1q1",
		key: "games.decorum.conditions.c12p1q1",
		source: "456_8149ded3b6.png",
		test: (e) => C.some((t) => e.n("g", t) === e.n("g"))
	},
	c12p1q2: {
		id: "c12p1q2",
		key: "games.decorum.conditions.c12p1q2",
		source: "456_8149ded3b6.png",
		test: (e) => e.all((t) => e.rooms[t].slots[v[t].indexOf(0)] !== 12)
	},
	c12p1q3: {
		id: "c12p1q3",
		key: "games.decorum.conditions.c12p1q3",
		source: "456_8149ded3b6.png",
		test: (e) => e.all((t) => e.objects([t]).some((n) => b(n) === e.rooms[t].wall))
	},
	c12p1q4: {
		id: "c12p1q4",
		key: "games.decorum.conditions.c12p1q4",
		source: "456_8149ded3b6.png",
		test: (e) => e.n("G") <= 1
	},
	c12p2q1: {
		id: "c12p2q1",
		key: "games.decorum.conditions.c12p2q1",
		source: "458_62458e505d.png",
		test: (e) => _.some((t) => T.filter((n) => e.rooms[n].slots[v[n].indexOf(t)] === 12).length === e.n("g"))
	},
	c12p2q2: {
		id: "c12p2q2",
		key: "games.decorum.conditions.c12p2q2",
		source: "458_62458e505d.png",
		test: (e) => e.all((t) => e.n("g", [t]) === 0 || e.rooms[t].wall < 2)
	},
	c12p2q3: {
		id: "c12p2q3",
		key: "games.decorum.conditions.c12p2q3",
		source: "458_62458e505d.png",
		test: (e) => e.n("filled") > e.n("e")
	},
	c12p2q4: {
		id: "c12p2q4",
		key: "games.decorum.conditions.c12p2q4",
		source: "458_62458e505d.png",
		test: (e) => e.n("a") + e.n("r") + e.n("u") === 0
	},
	c13p1q1: {
		id: "c13p1q1",
		key: "games.decorum.conditions.c13p1q1",
		source: "462_eb70862f45.png",
		test: (e) => _.every((t) => T.some((n) => e.rooms[n].slots[v[n].indexOf(t)] === 12))
	},
	c13p1q2: {
		id: "c13p1q2",
		key: "games.decorum.conditions.c13p1q2",
		source: "462_eb70862f45.png",
		test: (e) => e.n("u") === 2 * (e.n() - e.n("u"))
	},
	c13p1q3: {
		id: "c13p1q3",
		key: "games.decorum.conditions.c13p1q3",
		source: "462_eb70862f45.png",
		test: (e) => e.n("G") === e.n("r")
	},
	c13p1q4: {
		id: "c13p1q4",
		key: "games.decorum.conditions.c13p1q4",
		source: "462_eb70862f45.png",
		test: (e) => e.all((t) => e.objects([t]).every((n) => b(n) !== e.rooms[t].wall))
	},
	c13p2q1: {
		id: "c13p2q1",
		key: "games.decorum.conditions.c13p2q1",
		source: "464_ffbee003e7.png",
		test: (e) => e.all((t) => e.n("g", [t]) <= 1)
	},
	c13p2q2: {
		id: "c13p2q2",
		key: "games.decorum.conditions.c13p2q2",
		source: "464_ffbee003e7.png",
		test: (e) => e.all((t) => (e.rooms[t].slots[1] === null || b(e.rooms[t].slots[1]) === 2) && e.rooms[t].wall !== 2 && [0, 2].every((n) => e.rooms[t].slots[n] !== null && b(e.rooms[t].slots[n]) !== 2))
	},
	c13p2q3: {
		id: "c13p2q3",
		key: "games.decorum.conditions.c13p2q3",
		source: "464_ffbee003e7.png",
		test: (e) => e.distinct("feature") === 4
	},
	c13p2q4: {
		id: "c13p2q4",
		key: "games.decorum.conditions.c13p2q4",
		source: "464_ffbee003e7.png",
		test: (e) => e.distinct("wall") === 1
	},
	c14p1q1: {
		id: "c14p1q1",
		key: "games.decorum.conditions.c14p1q1",
		source: "468_8d5e7c42af.png",
		test: (e) => T.filter((t) => e.n("g", [t]) <= 1).length >= 2
	},
	c14p1q2: {
		id: "c14p1q2",
		key: "games.decorum.conditions.c14p1q2",
		source: "468_8d5e7c42af.png",
		test: (e) => e.distinct("style") <= 2
	},
	c14p1q3: {
		id: "c14p1q3",
		key: "games.decorum.conditions.c14p1q3",
		source: "468_8d5e7c42af.png",
		test: (e) => e.n("e") <= 1
	},
	c14p1q4: {
		id: "c14p1q4",
		key: "games.decorum.conditions.c14p1q4",
		source: "468_8d5e7c42af.png",
		test: (e) => e.all((t) => e.rooms[t].wall === Math.max(0, b(e.rooms[3 - t].slots[1])))
	},
	c14p2q1: {
		id: "c14p2q1",
		key: "games.decorum.conditions.c14p2q1",
		source: "470_2aaed04955.png",
		test: (e) => C.every((t) => e.slots(t).every((e, t, n) => e !== 12 || n[t - 1] === 12 || n[t + 1] === 12))
	},
	c14p2q2: {
		id: "c14p2q2",
		key: "games.decorum.conditions.c14p2q2",
		source: "470_2aaed04955.png",
		test: (e) => e.all((t) => [
			null,
			12,
			0
		].includes(e.rooms[t].slots[v[t].indexOf(0)]))
	},
	c14p2q3: {
		id: "c14p2q3",
		key: "games.decorum.conditions.c14p2q3",
		source: "470_2aaed04955.png",
		test: (e) => e.distinct("color") === 4
	},
	c14p2q4: {
		id: "c14p2q4",
		key: "games.decorum.conditions.c14p2q4",
		source: "470_2aaed04955.png",
		test: (e) => e.distinct("wall") === 4
	},
	c14p2q5: {
		id: "c14p2q5",
		key: "games.decorum.conditions.c14p2q5",
		source: "470_2aaed04955.png",
		test: (e) => e.n("u") >= 1 && e.n("r") >= 1
	},
	c15p1q1: {
		id: "c15p1q1",
		key: "games.decorum.conditions.c15p1q1",
		source: "474_036688847d.png",
		test: (e) => e.n("pds") === 1 && e.n("pdb") === 1
	},
	c15p1q2: {
		id: "c15p1q2",
		key: "games.decorum.conditions.c15p1q2",
		source: "474_036688847d.png",
		test: (e) => e.all((t) => e.n("p", [t]) === 0 || e.n("FR", [t]) === 0)
	},
	c15p1q3: {
		id: "c15p1q3",
		key: "games.decorum.conditions.c15p1q3",
		source: "474_036688847d.png",
		test: (e) => C.every((t) => e.n("l", t) >= 1)
	},
	c15p1q4: {
		id: "c15p1q4",
		key: "games.decorum.conditions.c15p1q4",
		source: "474_036688847d.png",
		test: (e) => C.every((t) => e.n("pdb", t) === 0 || e.n("p", t) === 1)
	},
	c15p1q5: {
		id: "c15p1q5",
		key: "games.decorum.conditions.c15p1q5",
		source: "474_036688847d.png",
		test: (e) => e.all((t) => e.n("p", [t]) === 0 || e.n("m", [t]) + e.n("u", [t]) === 0)
	},
	c15p2q1: {
		id: "c15p2q1",
		key: "games.decorum.conditions.c15p2q1",
		source: "476_cd8bbaf615.png",
		test: (e) => e.n("pcs") >= 1
	},
	c15p2q2: {
		id: "c15p2q2",
		key: "games.decorum.conditions.c15p2q2",
		source: "476_cd8bbaf615.png",
		test: (e) => e.all((t) => e.n("p", [t]) === 0 || e.n("l", [t]) === 0)
	},
	c15p2q3: {
		id: "c15p2q3",
		key: "games.decorum.conditions.c15p2q3",
		source: "476_cd8bbaf615.png",
		test: (e) => e.noDuplicates()
	},
	c15p2q4: {
		id: "c15p2q4",
		key: "games.decorum.conditions.c15p2q4",
		source: "476_cd8bbaf615.png",
		test: (e) => [..."maru"].every((t) => e.n(t) >= 2)
	},
	c15p2q5: {
		id: "c15p2q5",
		key: "games.decorum.conditions.c15p2q5",
		source: "476_cd8bbaf615.png",
		test: (e) => e.all((t) => e.n("FG", [t]) >= 1)
	},
	c16p1q1: {
		id: "c16p1q1",
		key: "games.decorum.conditions.c16p1q1",
		source: "480_ba731aeadc.png",
		test: (e) => e.all((t) => e.distinct("style", [t]) === e.n("p", [t]))
	},
	c16p1q2: {
		id: "c16p1q2",
		key: "games.decorum.conditions.c16p1q2",
		source: "480_ba731aeadc.png",
		test: (e) => e.n("FG") === e.n("p") + 1
	},
	c16p1q3: {
		id: "c16p1q3",
		key: "games.decorum.conditions.c16p1q3",
		source: "480_ba731aeadc.png",
		test: (e) => e.n("ps") === e.n("pb")
	},
	c16p1q4: {
		id: "c16p1q4",
		key: "games.decorum.conditions.c16p1q4",
		source: "480_ba731aeadc.png",
		test: (e) => e.all((t) => e.n("pdb", [t]) === 0 || e.n("pcs", [t]) === 0)
	},
	c16p1q5: {
		id: "c16p1q5",
		key: "games.decorum.conditions.c16p1q5",
		source: "480_ba731aeadc.png",
		test: (e) => w.every((t) => e.n("FR", t) === 0 || e.n("FB", t) === 0)
	},
	c16p2q1: {
		id: "c16p2q1",
		key: "games.decorum.conditions.c16p2q1",
		source: "482_91467048ab.png",
		test: (e) => w.every((t) => e.n("e", t) === e.n("ps", t))
	},
	c16p2q2: {
		id: "c16p2q2",
		key: "games.decorum.conditions.c16p2q2",
		source: "482_91467048ab.png",
		test: (e) => e.distinct("wall") === e.n("pcb")
	},
	c16p2q3: {
		id: "c16p2q3",
		key: "games.decorum.conditions.c16p2q3",
		source: "482_91467048ab.png",
		test: (e) => e.all((t) => e.n("u", [t]) >= 1)
	},
	c16p2q4: {
		id: "c16p2q4",
		key: "games.decorum.conditions.c16p2q4",
		source: "482_91467048ab.png",
		test: (e) => C.every((t) => e.n("FR", t) === 0 || e.n("FB", t) === 0)
	},
	c16p2q5: {
		id: "c16p2q5",
		key: "games.decorum.conditions.c16p2q5",
		source: "482_91467048ab.png",
		test: (e) => e.all((t) => e.n("p", [t]) >= 1)
	},
	c16p2q6: {
		id: "c16p2q6",
		key: "games.decorum.conditions.c16p2q6",
		source: "482_91467048ab.png",
		test: (e) => e.n("p") === 6
	},
	c17p1q1: {
		id: "c17p1q1",
		key: "games.decorum.conditions.c17p1q1",
		source: "492_18a3b7ac7c.png",
		test: (e) => g.every((t) => e.some((n) => e.n("pc", [n]) > 0 && e.n("RYGB"[t], [n]) > 0))
	},
	c17p1q2: {
		id: "c17p1q2",
		key: "games.decorum.conditions.c17p1q2",
		source: "492_18a3b7ac7c.png",
		test: (e) => g.every((t) => e.some((n) => e.n("pd", [n]) > 0 && e.n("RYGB"[t], [n]) > 0))
	},
	c17p1q3: {
		id: "c17p1q3",
		key: "games.decorum.conditions.c17p1q3",
		source: "492_18a3b7ac7c.png",
		test: (e) => [..."maru"].every((t) => e.n(t) >= 2) && e.n("FG", [0, 1]) === 0
	},
	c17p1q4: {
		id: "c17p1q4",
		key: "games.decorum.conditions.c17p1q4",
		source: "492_18a3b7ac7c.png",
		test: (e) => T.filter((t) => e.n("pc", [t]) > 0 && e.n("pd", [t]) === 0).length >= 2 && T.filter((t) => e.n("p", [t]) === 3).length >= 2
	},
	c17p1q5: {
		id: "c17p1q5",
		key: "games.decorum.conditions.c17p1q5",
		source: "492_18a3b7ac7c.png",
		test: (e) => e.all((t) => e.objects([t]).some((n) => x(n) === 2 && b(n) === e.rooms[t].wall))
	},
	c17p1q6: {
		id: "c17p1q6",
		key: "games.decorum.conditions.c17p1q6",
		source: "492_18a3b7ac7c.png",
		test: (e) => e.all((t) => e.n("pdb", [t]) === e.n("FR", [t]))
	},
	c17p2q1: {
		id: "c17p2q1",
		key: "games.decorum.conditions.c17p2q1",
		source: "494_4de1be89df.png",
		test: (e) => e.all((t) => e.n("pd", [t]) >= +(e.rooms[t].slots[0] !== null && e.rooms[t].slots[1] !== null) + +(e.rooms[t].slots[1] !== null && e.rooms[t].slots[2] !== null))
	},
	c17p2q2: {
		id: "c17p2q2",
		key: "games.decorum.conditions.c17p2q2",
		source: "494_4de1be89df.png",
		test: (e) => e.all((t) => e.n("pc", [t]) === 0 || e.n("pd", [t]) === 0, [
			0,
			2,
			3
		])
	},
	c17p2q3: {
		id: "c17p2q3",
		key: "games.decorum.conditions.c17p2q3",
		source: "494_4de1be89df.png",
		test: (e) => e.all((t) => e.distinct("style", [t]) === 1) && e.n("m", [0, 1]) === 0
	},
	c17p2q4: {
		id: "c17p2q4",
		key: "games.decorum.conditions.c17p2q4",
		source: "494_4de1be89df.png",
		test: (e) => e.n("p") % 2 == 1 && e.n("ps") >= 2 && e.n("ps") % 2 == 0
	},
	c17p2q5: {
		id: "c17p2q5",
		key: "games.decorum.conditions.c17p2q5",
		source: "494_4de1be89df.png",
		test: (e) => e.all((t) => e.n("pc", [t]) === e.n("FB", [t]))
	},
	c18p1q1: {
		id: "c18p1q1",
		key: "games.decorum.conditions.c18p1q1",
		source: "486_ae0522421d.png",
		test: (e) => e.all((t) => e.n("pc", [t]) > 0 == (e.rooms[t].slots[v[t].indexOf(0)] !== null))
	},
	c18p1q2: {
		id: "c18p1q2",
		key: "games.decorum.conditions.c18p1q2",
		source: "486_ae0522421d.png",
		test: (e) => e.all((t) => e.n("pd", [t]) > 0 == (e.rooms[t].slots[v[t].indexOf(1)] !== null))
	},
	c18p1q3: {
		id: "c18p1q3",
		key: "games.decorum.conditions.c18p1q3",
		source: "486_ae0522421d.png",
		test: (e) => e.all((t) => e.distinct("style", [t]) <= 1)
	},
	c18p1q4: {
		id: "c18p1q4",
		key: "games.decorum.conditions.c18p1q4",
		source: "486_ae0522421d.png",
		test: (e) => e.n("g", [0, 1]) > e.n("g", [2, 3])
	},
	c18p2q1: {
		id: "c18p2q1",
		key: "games.decorum.conditions.c18p2q1",
		source: "488_70cb4a5d6b.png",
		test: (e) => e.all((t) => e.n("pb", [t]) === 0 || e.n("g", [t]) === 0)
	},
	c18p2q2: {
		id: "c18p2q2",
		key: "games.decorum.conditions.c18p2q2",
		source: "488_70cb4a5d6b.png",
		test: (e) => e.some((t) => e.n("g", [t]) + e.n("p", [t]) === 0)
	},
	c18p2q3: {
		id: "c18p2q3",
		key: "games.decorum.conditions.c18p2q3",
		source: "488_70cb4a5d6b.png",
		test: (e) => e.n("pc") > e.n("pd")
	},
	c18p2q4: {
		id: "c18p2q4",
		key: "games.decorum.conditions.c18p2q4",
		source: "488_70cb4a5d6b.png",
		test: (e) => e.allObjects("l")
	},
	c19p1q1: {
		id: "c19p1q1",
		key: "games.decorum.conditions.c19p1q1",
		source: "498_3379c6cfbf.png",
		test: (e) => e.n("p", w[0]) !== e.n("p", w[1]) && w.every((t, n) => e.distinct("wall", t) === 1 && e.rooms[t[0]].wall < 2 == e.n("p", t) > e.n("p", w[1 - n]))
	},
	c19p1q2: {
		id: "c19p1q2",
		key: "games.decorum.conditions.c19p1q2",
		source: "498_3379c6cfbf.png",
		test: (e) => e.n("pd") === T.filter((t) => e.edge(t, !0) === 12).length
	},
	c19p1q3: {
		id: "c19p1q3",
		key: "games.decorum.conditions.c19p1q3",
		source: "498_3379c6cfbf.png",
		test: (e) => e.all((t) => e.n("u", [t]) === 0 || e.rooms[t].wall === 2)
	},
	c19p1q4: {
		id: "c19p1q4",
		key: "games.decorum.conditions.c19p1q4",
		source: "498_3379c6cfbf.png",
		test: (e) => e.n("p") === 5
	},
	c19p1q5: {
		id: "c19p1q5",
		key: "games.decorum.conditions.c19p1q5",
		source: "498_3379c6cfbf.png",
		test: (e) => e.all((t) => e.n("p", [t]) > 0 == e.n("r", [t]) > 0)
	},
	c19p2q1: {
		id: "c19p2q1",
		key: "games.decorum.conditions.c19p2q1",
		source: "500_3ce9930618.png",
		test: (e) => e.n("ps") === T.filter((t) => e.edge(t) === 12).length
	},
	c19p2q2: {
		id: "c19p2q2",
		key: "games.decorum.conditions.c19p2q2",
		source: "500_3ce9930618.png",
		test: (e) => T.filter((t) => e.n("p", [t]) > e.n("g", [t])).length <= 1
	},
	c19p2q3: {
		id: "c19p2q3",
		key: "games.decorum.conditions.c19p2q3",
		source: "500_3ce9930618.png",
		test: (e) => e.n("a", [2, 3]) === 0 && e.n("FG", [2, 3]) === 0 && e.n("FY", [0, 1]) === 0 && [0, 1].every((t) => e.rooms[t].slots[v[t].indexOf(1)] === null)
	},
	c19p2q4: {
		id: "c19p2q4",
		key: "games.decorum.conditions.c19p2q4",
		source: "500_3ce9930618.png",
		test: (e) => w.every((t) => t.filter((t) => e.n("e", [t]) === 0).length === 1)
	},
	c19p2q5: {
		id: "c19p2q5",
		key: "games.decorum.conditions.c19p2q5",
		source: "500_3ce9930618.png",
		test: (e) => e.n("filled") === e.n("p") + 3
	},
	c20p1q1: {
		id: "c20p1q1",
		key: "games.decorum.conditions.c20p1q1",
		source: "506_323c0d093e.png",
		test: (e) => e.all((t) => e.n("g", [t]) > 0 || e.n("e", [t]) === 0)
	},
	c20p1q2: {
		id: "c20p1q2",
		key: "games.decorum.conditions.c20p1q2",
		source: "506_323c0d093e.png",
		test: (e) => C.every((t) => e.distinct("style", t) <= 2)
	},
	c20p1q3: {
		id: "c20p1q3",
		key: "games.decorum.conditions.c20p1q3",
		source: "506_323c0d093e.png",
		test: (e) => e.all((t) => e.n("pc", [t]) === e.n("FB", [t]))
	},
	c20p1q4: {
		id: "c20p1q4",
		key: "games.decorum.conditions.c20p1q4",
		source: "506_323c0d093e.png",
		test: (e) => e.all((t) => e.n("l", [t]) === 0 || e.n("pb", [t]) > 0) && D(e.objects().filter((e) => x(e) === 2).map(S)).length === e.n("l")
	},
	c20p1q5: {
		id: "c20p1q5",
		key: "games.decorum.conditions.c20p1q5",
		source: "506_323c0d093e.png",
		test: (e) => e.n("ps") === e.n("l") && e.n("l", [2, 3]) > e.n("l", [0, 1]) && e.n("ps", [0, 1]) > e.n("ps", [2, 3])
	},
	c20p2q1: {
		id: "c20p2q1",
		key: "games.decorum.conditions.c20p2q1",
		source: "510_f2fd056a97.png",
		test: (e) => C.every((t) => e.distinct("feature", t) === 3 && e.n("p", t) === 3)
	},
	c20p2q2: {
		id: "c20p2q2",
		key: "games.decorum.conditions.c20p2q2",
		source: "510_f2fd056a97.png",
		test: (e) => e.all((t) => e.n("c", [t]) === 0 || e.n("ps", [t]) > 0)
	},
	c20p2q3: {
		id: "c20p2q3",
		key: "games.decorum.conditions.c20p2q3",
		source: "510_f2fd056a97.png",
		test: (e) => e.all((t) => e.n("g", [t]) === 0 || e.n("p", [t]) === 1 && e.warm([t]) > 0 && e.cool([t]) > 0)
	},
	c20p2q4: {
		id: "c20p2q4",
		key: "games.decorum.conditions.c20p2q4",
		source: "510_f2fd056a97.png",
		test: (e) => e.n("pd") === e.n("c") && e.n("c", [0, 1]) > e.n("c", [2, 3]) && e.n("pd", [2, 3]) > e.n("pd", [0, 1])
	},
	c20p2q5: {
		id: "c20p2q5",
		key: "games.decorum.conditions.c20p2q5",
		source: "510_f2fd056a97.png",
		test: (e) => e.most("a", "maru") && e.distinct("feature") === 4 && e.distinct("style") === 4
	},
	m1p1q1: {
		id: "m1p1q1",
		key: "games.decorum.conditions.m1p1q1",
		source: "128_ca48075a1d.png",
		test: (e) => e.all((t) => e.distinct("feature", [t]) === 2)
	},
	m1p1q2: {
		id: "m1p1q2",
		key: "games.decorum.conditions.m1p1q2",
		source: "128_ca48075a1d.png",
		test: (e) => e.most("r", "maru")
	},
	m1p1q3: {
		id: "m1p1q3",
		key: "games.decorum.conditions.m1p1q3",
		source: "128_ca48075a1d.png",
		test: (e) => e.n("filled", [0, 1]) === e.n("filled", [2, 3])
	},
	m1p2q1: {
		id: "m1p2q1",
		key: "games.decorum.conditions.m1p2q1",
		source: "130_c956009b11.png",
		test: (e) => e.all((t) => e.distinct("style", [t]) >= 2)
	},
	m1p2q2: {
		id: "m1p2q2",
		key: "games.decorum.conditions.m1p2q2",
		source: "130_c956009b11.png",
		test: (e) => e.distinct("wall") === 4
	},
	m1p2q3: {
		id: "m1p2q3",
		key: "games.decorum.conditions.m1p2q3",
		source: "130_c956009b11.png",
		test: (e) => e.allObjects("Y")
	},
	m1p3q1: {
		id: "m1p3q1",
		key: "games.decorum.conditions.m1p3q1",
		source: "132_ab7e50fda4.png",
		test: (e) => e.allObjects("R")
	},
	m1p3q2: {
		id: "m1p3q2",
		key: "games.decorum.conditions.m1p3q2",
		source: "132_ab7e50fda4.png",
		test: (e) => e.n("FB", [2, 3]) === 0
	},
	m1p3q3: {
		id: "m1p3q3",
		key: "games.decorum.conditions.m1p3q3",
		source: "132_ab7e50fda4.png",
		test: (e) => e.distinct("style") === 4
	},
	m1p4q1: {
		id: "m1p4q1",
		key: "games.decorum.conditions.m1p4q1",
		source: "134_d822a96889.png",
		test: (e) => e.allObjects("h")
	},
	m1p4q2: {
		id: "m1p4q2",
		key: "games.decorum.conditions.m1p4q2",
		source: "134_d822a96889.png",
		test: (e) => e.all((t) => e.n("FR", [t]) >= 1)
	},
	m1p4q3: {
		id: "m1p4q3",
		key: "games.decorum.conditions.m1p4q3",
		source: "134_d822a96889.png",
		test: (e) => e.n("e") === 4
	},
	m2p1q1: {
		id: "m2p1q1",
		key: "games.decorum.conditions.m2p1q1",
		source: "156_0ade5bd335.png",
		test: (e) => e.n("", [0, 1]) === e.n("a", [0, 1])
	},
	m2p1q2: {
		id: "m2p1q2",
		key: "games.decorum.conditions.m2p1q2",
		source: "156_0ade5bd335.png",
		test: (e) => C.some((t) => e.distinct("wall", t) === 1)
	},
	m2p1q3: {
		id: "m2p1q3",
		key: "games.decorum.conditions.m2p1q3",
		source: "156_0ade5bd335.png",
		test: (e) => e.n("filled") === 7
	},
	m2p2q1: {
		id: "m2p2q1",
		key: "games.decorum.conditions.m2p2q1",
		source: "158_77962bb5bd.png",
		test: (e) => e.n("WG") + e.n("WB") > 2
	},
	m2p2q2: {
		id: "m2p2q2",
		key: "games.decorum.conditions.m2p2q2",
		source: "158_77962bb5bd.png",
		test: (e) => e.objects([0, 2]).every((t) => !e.objects([1, 3]).includes(t))
	},
	m2p2q3: {
		id: "m2p2q3",
		key: "games.decorum.conditions.m2p2q3",
		source: "158_77962bb5bd.png",
		test: (e) => e.distinct("style") === 4
	},
	m2p3q1: {
		id: "m2p3q1",
		key: "games.decorum.conditions.m2p3q1",
		source: "160_1258bf41ee.png",
		test: (e) => e.rooms[3].wall === 0
	},
	m2p3q2: {
		id: "m2p3q2",
		key: "games.decorum.conditions.m2p3q2",
		source: "160_1258bf41ee.png",
		test: (e) => e.some((t) => e.n("B", [t]) === 3)
	},
	m2p3q3: {
		id: "m2p3q3",
		key: "games.decorum.conditions.m2p3q3",
		source: "160_1258bf41ee.png",
		test: (e) => e.most("h", "chl")
	},
	m2p4q1: {
		id: "m2p4q1",
		key: "games.decorum.conditions.m2p4q1",
		source: "162_a44a7597b8.png",
		test: (e) => e.n("u") === 1
	},
	m2p4q2: {
		id: "m2p4q2",
		key: "games.decorum.conditions.m2p4q2",
		source: "162_a44a7597b8.png",
		test: (e) => e.rooms[0].wall === 3
	},
	m2p4q3: {
		id: "m2p4q3",
		key: "games.decorum.conditions.m2p4q3",
		source: "162_a44a7597b8.png",
		test: (e) => e.all((t) => e.objects([t]).every((n) => b(n) !== e.rooms[t].wall))
	},
	m3p1q1: {
		id: "m3p1q1",
		key: "games.decorum.conditions.m3p1q1",
		source: "184_09ef39a900.png",
		test: (e) => e.all((t) => e.objects([t]).every((n) => b(n) !== e.rooms[t ^ 2].wall))
	},
	m3p1q2: {
		id: "m3p1q2",
		key: "games.decorum.conditions.m3p1q2",
		source: "184_09ef39a900.png",
		test: (e) => e.all((t) => e.n("Y", [t]) > 0 == (e.rooms[t].wall === 3))
	},
	m3p1q3: {
		id: "m3p1q3",
		key: "games.decorum.conditions.m3p1q3",
		source: "184_09ef39a900.png",
		test: (e) => e.n("r") === e.n("a")
	},
	m3p2q1: {
		id: "m3p2q1",
		key: "games.decorum.conditions.m3p2q1",
		source: "186_a5facd2011.png",
		test: (e) => e.allObjects("c")
	},
	m3p2q2: {
		id: "m3p2q2",
		key: "games.decorum.conditions.m3p2q2",
		source: "186_a5facd2011.png",
		test: (e) => e.all((t) => e.objects([t]).filter((e) => x(e) === 0).every((n) => b(n) === e.rooms[3 - t].wall))
	},
	m3p2q3: {
		id: "m3p2q3",
		key: "games.decorum.conditions.m3p2q3",
		source: "186_a5facd2011.png",
		test: (e) => e.all((t) => e.rooms[t].slots.every((n, r) => n === null || e.rooms[t ^ 2].slots[r] !== null && S(n) !== S(e.rooms[t ^ 2].slots[r])))
	},
	m3p3q1: {
		id: "m3p3q1",
		key: "games.decorum.conditions.m3p3q1",
		source: "188_8220d7112c.png",
		test: (e) => e.all((t) => e.n("e", [t]) === 1)
	},
	m3p3q2: {
		id: "m3p3q2",
		key: "games.decorum.conditions.m3p3q2",
		source: "188_8220d7112c.png",
		test: (e) => e.all((t) => e.rooms[t].slots.every((n, r) => n !== null || e.rooms[t ^ 2].slots[r] === null))
	},
	m3p3q3: {
		id: "m3p3q3",
		key: "games.decorum.conditions.m3p3q3",
		source: "188_8220d7112c.png",
		test: (e) => e.all((t) => e.n("G", [t]) === 0 || e.rooms[t].wall === 0)
	},
	m3p4q1: {
		id: "m3p4q1",
		key: "games.decorum.conditions.m3p4q1",
		source: "190_969304de36.png",
		test: (e) => e.allObjects("m")
	},
	m3p4q2: {
		id: "m3p4q2",
		key: "games.decorum.conditions.m3p4q2",
		source: "190_969304de36.png",
		test: (e) => g.filter((e) => e !== 3).every((t) => e.n("FB") > e.n("F" + "RYGB"[t]))
	},
	m3p4q3: {
		id: "m3p4q3",
		key: "games.decorum.conditions.m3p4q3",
		source: "190_969304de36.png",
		test: (e) => e.all((t) => e.n("u", [t]) === 0 || e.rooms[t].wall === 2)
	},
	m4p1q1: {
		id: "m4p1q1",
		key: "games.decorum.conditions.m4p1q1",
		source: "212_31e6b0bc3c.png",
		test: (e) => e.n("r", [0]) === 0
	},
	m4p1q2: {
		id: "m4p1q2",
		key: "games.decorum.conditions.m4p1q2",
		source: "212_31e6b0bc3c.png",
		test: (e) => e.n("e", [3]) === 0
	},
	m4p1q3: {
		id: "m4p1q3",
		key: "games.decorum.conditions.m4p1q3",
		source: "212_31e6b0bc3c.png",
		test: (e) => e.n("G", [1, 3]) === 0
	},
	m4p2q1: {
		id: "m4p2q1",
		key: "games.decorum.conditions.m4p2q1",
		source: "214_76c4f12eab.png",
		test: (e) => [..."maru"].every((t) => e.n(t) % 2 == 0)
	},
	m4p2q2: {
		id: "m4p2q2",
		key: "games.decorum.conditions.m4p2q2",
		source: "214_76c4f12eab.png",
		test: (e) => e.n("FR", [0]) === 0
	},
	m4p2q3: {
		id: "m4p2q3",
		key: "games.decorum.conditions.m4p2q3",
		source: "214_76c4f12eab.png",
		test: (e) => e.n("e", [1]) === 0
	},
	m4p3q1: {
		id: "m4p3q1",
		key: "games.decorum.conditions.m4p3q1",
		source: "216_70376d0473.png",
		test: (e) => e.n("e", [0]) === 0
	},
	m4p3q2: {
		id: "m4p3q2",
		key: "games.decorum.conditions.m4p3q2",
		source: "216_70376d0473.png",
		test: (e) => e.n("FR", [2]) === 0
	},
	m4p3q3: {
		id: "m4p3q3",
		key: "games.decorum.conditions.m4p3q3",
		source: "216_70376d0473.png",
		test: (e) => D(g.map((t) => e.n("F" + "RYGB"[t]))).length === 1
	},
	m4p4q1: {
		id: "m4p4q1",
		key: "games.decorum.conditions.m4p4q1",
		source: "218_0ef03d0be9.png",
		test: (e) => e.n("r", [2]) === 0
	},
	m4p4q2: {
		id: "m4p4q2",
		key: "games.decorum.conditions.m4p4q2",
		source: "218_0ef03d0be9.png",
		test: (e) => e.n("WG") === 0
	},
	m4p4q3: {
		id: "m4p4q3",
		key: "games.decorum.conditions.m4p4q3",
		source: "218_0ef03d0be9.png",
		test: (e) => e.n("a", [1, 3]) === 0
	},
	m5p1q1: {
		id: "m5p1q1",
		key: "games.decorum.conditions.m5p1q1",
		source: "240_06b452d547.png",
		test: (e) => e.all((t) => e.ordered(e.objects([t]).map(b), [
			0,
			1,
			2,
			3
		]))
	},
	m5p1q2: {
		id: "m5p1q2",
		key: "games.decorum.conditions.m5p1q2",
		source: "240_06b452d547.png",
		test: (e) => e.n("r") === 1
	},
	m5p1q3: {
		id: "m5p1q3",
		key: "games.decorum.conditions.m5p1q3",
		source: "240_06b452d547.png",
		test: (e) => e.all((t) => e.n("l", [t]) === 1)
	},
	m5p2q1: {
		id: "m5p2q1",
		key: "games.decorum.conditions.m5p2q1",
		source: "242_d10839e314.png",
		test: (e) => e.n("R") <= 1
	},
	m5p2q2: {
		id: "m5p2q2",
		key: "games.decorum.conditions.m5p2q2",
		source: "242_d10839e314.png",
		test: (e) => e.n("e", [2, 3]) > e.n("e", [0, 1])
	},
	m5p2q3: {
		id: "m5p2q3",
		key: "games.decorum.conditions.m5p2q3",
		source: "242_d10839e314.png",
		test: (e) => e.objects([1]).some((t) => e.objects([2]).includes(t))
	},
	m5p3q1: {
		id: "m5p3q1",
		key: "games.decorum.conditions.m5p3q1",
		source: "244_ab973470bd.png",
		test: (e) => e.n("FR") === 4
	},
	m5p3q2: {
		id: "m5p3q2",
		key: "games.decorum.conditions.m5p3q2",
		source: "244_ab973470bd.png",
		test: (e) => e.n("e", [0, 2]) > e.n("e", [1, 3])
	},
	m5p3q3: {
		id: "m5p3q3",
		key: "games.decorum.conditions.m5p3q3",
		source: "244_ab973470bd.png",
		test: (e) => e.n("a") === e.n("m")
	},
	m5p4q1: {
		id: "m5p4q1",
		key: "games.decorum.conditions.m5p4q1",
		source: "246_04cdf39660.png",
		test: (e) => w.every((t) => e.n("c", t) <= 1)
	},
	m5p4q2: {
		id: "m5p4q2",
		key: "games.decorum.conditions.m5p4q2",
		source: "246_04cdf39660.png",
		test: (e) => e.all((t) => [b(e.rooms[0].slots[0]), b(e.rooms[1].slots[0])].includes(e.rooms[t].wall))
	},
	m5p4q3: {
		id: "m5p4q3",
		key: "games.decorum.conditions.m5p4q3",
		source: "246_04cdf39660.png",
		test: (e) => e.n("u") === e.n("r")
	},
	m6p1q1: {
		id: "m6p1q1",
		key: "games.decorum.conditions.m6p1q1",
		source: "268_765a246ea0.png",
		test: (e) => e.n("l", [e.mine]) === 1
	},
	m6p1q2: {
		id: "m6p1q2",
		key: "games.decorum.conditions.m6p1q2",
		source: "268_765a246ea0.png",
		test: (e) => e.rooms[e.mine].wall === 1
	},
	m6p1q3: {
		id: "m6p1q3",
		key: "games.decorum.conditions.m6p1q3",
		source: "268_765a246ea0.png",
		test: (e) => e.allObjects("c")
	},
	m6p2q1: {
		id: "m6p2q1",
		key: "games.decorum.conditions.m6p2q1",
		source: "270_770d80e16b.png",
		test: (e) => e.n("", [e.mine]) === e.n("B", [e.mine])
	},
	m6p2q2: {
		id: "m6p2q2",
		key: "games.decorum.conditions.m6p2q2",
		source: "270_770d80e16b.png",
		test: (e) => e.n("filled", [e.mine]) === 3
	},
	m6p2q3: {
		id: "m6p2q3",
		key: "games.decorum.conditions.m6p2q3",
		source: "270_770d80e16b.png",
		test: (e) => e.allObjects("h")
	},
	m6p3q1: {
		id: "m6p3q1",
		key: "games.decorum.conditions.m6p3q1",
		source: "272_8c81e7a243.png",
		test: (e) => e.n("u", [e.mine]) >= 1
	},
	m6p3q2: {
		id: "m6p3q2",
		key: "games.decorum.conditions.m6p3q2",
		source: "272_8c81e7a243.png",
		test: (e) => e.n("l", [0, 2]) === 0
	},
	m6p3q3: {
		id: "m6p3q3",
		key: "games.decorum.conditions.m6p3q3",
		source: "272_8c81e7a243.png",
		test: (e) => e.n("m", [0, 1]) === 1
	},
	m6p4q1: {
		id: "m6p4q1",
		key: "games.decorum.conditions.m6p4q1",
		source: "274_52ed04b51b.png",
		test: (e) => e.n("G") === 3
	},
	m6p4q2: {
		id: "m6p4q2",
		key: "games.decorum.conditions.m6p4q2",
		source: "274_52ed04b51b.png",
		test: (e) => e.n("l") >= 2
	},
	m6p4q3: {
		id: "m6p4q3",
		key: "games.decorum.conditions.m6p4q3",
		source: "274_52ed04b51b.png",
		test: (e) => e.rooms[e.mine].wall === 0
	},
	m7p1q1: {
		id: "m7p1q1",
		key: "games.decorum.conditions.m7p1q1",
		source: "296_ae0dafa863.png",
		test: (e) => e.n("filled", e.side) > e.n("filled", e.otherSide)
	},
	m7p1q2: {
		id: "m7p1q2",
		key: "games.decorum.conditions.m7p1q2",
		source: "296_ae0dafa863.png",
		test: (e) => e.all((t) => e.distinct("feature", [t]) >= 3)
	},
	m7p1q3: {
		id: "m7p1q3",
		key: "games.decorum.conditions.m7p1q3",
		source: "296_ae0dafa863.png",
		test: (e) => g.filter((e) => e !== 2).every((t) => e.n("FG") > e.n("F" + "RYGB"[t]))
	},
	m7p2q1: {
		id: "m7p2q1",
		key: "games.decorum.conditions.m7p2q1",
		source: "298_a135cc4984.png",
		test: (e) => e.n("filled", [e.mine]) === 3
	},
	m7p2q2: {
		id: "m7p2q2",
		key: "games.decorum.conditions.m7p2q2",
		source: "298_a135cc4984.png",
		test: (e) => e.rooms[e.mine].wall === e.rooms[2].wall && g.filter((t) => t !== e.rooms[2].wall).every((t) => e.n("RYGB"[e.rooms[2].wall]) < e.n("RYGB"[t]))
	},
	m7p2q3: {
		id: "m7p2q3",
		key: "games.decorum.conditions.m7p2q3",
		source: "298_a135cc4984.png",
		test: (e) => e.noDuplicates()
	},
	m7p3q1: {
		id: "m7p3q1",
		key: "games.decorum.conditions.m7p3q1",
		source: "300_91da081a6f.png",
		test: (e) => e.allObjects("R") && e.allObjects("Y")
	},
	m7p3q2: {
		id: "m7p3q2",
		key: "games.decorum.conditions.m7p3q2",
		source: "300_91da081a6f.png",
		test: (e) => [..."aru"].every((t) => e.n("m") < e.n(t))
	},
	m7p3q3: {
		id: "m7p3q3",
		key: "games.decorum.conditions.m7p3q3",
		source: "300_91da081a6f.png",
		test: (e) => e.all((t) => e.n("FR", [t]) >= 1)
	},
	m7p4q1: {
		id: "m7p4q1",
		key: "games.decorum.conditions.m7p4q1",
		source: "302_37b07d0284.png",
		test: (e) => e.some((t) => e.distinct("feature", [t]) === 4)
	},
	m7p4q2: {
		id: "m7p4q2",
		key: "games.decorum.conditions.m7p4q2",
		source: "302_37b07d0284.png",
		test: (e) => e.objectWarm() === e.objectCool() + 1
	},
	m7p4q3: {
		id: "m7p4q3",
		key: "games.decorum.conditions.m7p4q3",
		source: "302_37b07d0284.png",
		test: (e) => e.n("cB", [e.mine]) === 1
	},
	m8p1q1: {
		id: "m8p1q1",
		key: "games.decorum.conditions.m8p1q1",
		source: "324_52ddf21dd2.png",
		test: (e) => e.cyclic(e.rooms.map((e) => e.wall))
	},
	m8p1q2: {
		id: "m8p1q2",
		key: "games.decorum.conditions.m8p1q2",
		source: "324_52ddf21dd2.png",
		test: (e) => e.n("e", [e.mine + 2]) === 0
	},
	m8p1q3: {
		id: "m8p1q3",
		key: "games.decorum.conditions.m8p1q3",
		source: "324_52ddf21dd2.png",
		test: (e) => e.n("c") === 2
	},
	m8p2q1: {
		id: "m8p2q1",
		key: "games.decorum.conditions.m8p2q1",
		source: "326_c2a5c991ae.png",
		test: (e) => e.cyclic(e.rooms.map((e) => b(e.slots[1])), !1)
	},
	m8p2q2: {
		id: "m8p2q2",
		key: "games.decorum.conditions.m8p2q2",
		source: "326_c2a5c991ae.png",
		test: (e) => e.n("FG", e.side) > e.n("FG", e.otherSide) && e.n("filled", e.side) < e.n("filled", e.otherSide)
	},
	m8p2q3: {
		id: "m8p2q3",
		key: "games.decorum.conditions.m8p2q3",
		source: "326_c2a5c991ae.png",
		test: (e) => e.most("Y", "RYGB") && e.most("a", "maru")
	},
	m8p3q1: {
		id: "m8p3q1",
		key: "games.decorum.conditions.m8p3q1",
		source: "328_1167ee4121.png",
		test: (e) => e.cyclic(T.map((t) => b(e.rooms[t].slots[v[t].indexOf(2)])))
	},
	m8p3q2: {
		id: "m8p3q2",
		key: "games.decorum.conditions.m8p3q2",
		source: "328_1167ee4121.png",
		test: (e) => e.n("r", e.side) > 0 && e.n("r", e.otherSide) === 0
	},
	m8p3q3: {
		id: "m8p3q3",
		key: "games.decorum.conditions.m8p3q3",
		source: "328_1167ee4121.png",
		test: (e) => e.all((t) => e.distinct("feature", [t]) <= 3)
	},
	m8p4q1: {
		id: "m8p4q1",
		key: "games.decorum.conditions.m8p4q1",
		source: "330_1b05986b79.png",
		test: (e) => e.distinct("style", [0, 1]) === 3 && e.distinct("style", [2, 3]) === 2
	},
	m8p4q2: {
		id: "m8p4q2",
		key: "games.decorum.conditions.m8p4q2",
		source: "330_1b05986b79.png",
		test: (e) => e.all((t) => e.objects([t]).filter((e) => x(e) === 0).every((n) => b(n) < 2 == e.rooms[t].wall < 2))
	},
	m8p4q3: {
		id: "m8p4q3",
		key: "games.decorum.conditions.m8p4q3",
		source: "330_1b05986b79.png",
		test: (e) => e.n("B", [2, 3]) === 0
	},
	m9p1q1: {
		id: "m9p1q1",
		key: "games.decorum.conditions.m9p1q1",
		source: "352_228fa6eb84.png",
		test: (e) => e.n("FG", e.side) === 0 && e.n("FG", e.otherSide) > 0
	},
	m9p1q2: {
		id: "m9p1q2",
		key: "games.decorum.conditions.m9p1q2",
		source: "352_228fa6eb84.png",
		test: (e) => e.n("hu", [1 - e.mine]) === 1
	},
	m9p1q3: {
		id: "m9p1q3",
		key: "games.decorum.conditions.m9p1q3",
		source: "352_228fa6eb84.png",
		test: (e) => T.filter((t) => t !== e.mine).every((t) => e.n("a", [e.mine]) > e.n("a", [t]))
	},
	m9p2q1: {
		id: "m9p2q1",
		key: "games.decorum.conditions.m9p2q1",
		source: "354_232af5e607.png",
		test: (e) => e.n("a", [0, 1]) === e.n("a", [2, 3])
	},
	m9p2q2: {
		id: "m9p2q2",
		key: "games.decorum.conditions.m9p2q2",
		source: "354_232af5e607.png",
		test: (e) => e.distinct("style", [0, 1]) === 4
	},
	m9p2q3: {
		id: "m9p2q3",
		key: "games.decorum.conditions.m9p2q3",
		source: "354_232af5e607.png",
		test: (e) => e.n("R") === 0
	},
	m9p3q1: {
		id: "m9p3q1",
		key: "games.decorum.conditions.m9p3q1",
		source: "356_926d3d469d.png",
		test: (e) => e.objects().every((t) => e.objects().filter((e) => e === t).length === 2)
	},
	m9p3q2: {
		id: "m9p3q2",
		key: "games.decorum.conditions.m9p3q2",
		source: "356_926d3d469d.png",
		test: (e) => e.n("m", e.side) > 0 && e.n("m", e.otherSide) === 0
	},
	m9p3q3: {
		id: "m9p3q3",
		key: "games.decorum.conditions.m9p3q3",
		source: "356_926d3d469d.png",
		test: (e) => e.distinct("feature", [e.mine + 2]) === 1
	},
	m9p4q1: {
		id: "m9p4q1",
		key: "games.decorum.conditions.m9p4q1",
		source: "358_87542bbd3b.png",
		test: (e) => e.cool([e.mine + 2]) === 0
	},
	m9p4q2: {
		id: "m9p4q2",
		key: "games.decorum.conditions.m9p4q2",
		source: "358_87542bbd3b.png",
		test: (e) => e.n("G") === 0
	},
	m9p4q3: {
		id: "m9p4q3",
		key: "games.decorum.conditions.m9p4q3",
		source: "358_87542bbd3b.png",
		test: (e) => e.n("FY") === e.n("FB")
	},
	m10p1q1: {
		id: "m10p1q1",
		key: "games.decorum.conditions.m10p1q1",
		source: "380_49e3e1373b.png",
		test: (e) => e.n("r", [e.mine]) > 0 && e.n("R", [e.mine]) > 0
	},
	m10p1q2: {
		id: "m10p1q2",
		key: "games.decorum.conditions.m10p1q2",
		source: "380_49e3e1373b.png",
		test: (e) => e.n("l", [0, 1]) === 1 && e.objects([0, 1]).filter((e) => x(e) !== 2).every((t) => S(t) !== S(e.objects([0, 1]).find((e) => x(e) === 2)))
	},
	m10p1q3: {
		id: "m10p1q3",
		key: "games.decorum.conditions.m10p1q3",
		source: "380_49e3e1373b.png",
		test: (e) => C.every((t) => e.distinct("style", t) === 4) && e.allObjects("a")
	},
	m10p2q1: {
		id: "m10p2q1",
		key: "games.decorum.conditions.m10p2q1",
		source: "384_527f323190.png",
		test: (e) => e.n("FY", [e.mine]) === 2
	},
	m10p2q2: {
		id: "m10p2q2",
		key: "games.decorum.conditions.m10p2q2",
		source: "384_527f323190.png",
		test: (e) => e.distinct("style", [e.mine]) === e.n("", [e.mine])
	},
	m10p2q3: {
		id: "m10p2q3",
		key: "games.decorum.conditions.m10p2q3",
		source: "384_527f323190.png",
		test: (e) => e.noDuplicates() && e.some((t) => e.distinct("style", [t]) === 1)
	},
	m10p3q1: {
		id: "m10p3q1",
		key: "games.decorum.conditions.m10p3q1",
		source: "382_0f0a3cb1bc.png",
		test: (e) => e.distinct("feature", [e.mine]) === 2 && D(e.features([e.mine])).every((t) => e.n("F" + "RYGB"[t], [e.mine]) === 2 && e.n("F" + "RYGB"[t], [1 - e.mine]) === 0)
	},
	m10p3q2: {
		id: "m10p3q2",
		key: "games.decorum.conditions.m10p3q2",
		source: "382_0f0a3cb1bc.png",
		test: (e) => e.allObjects("m")
	},
	m10p3q3: {
		id: "m10p3q3",
		key: "games.decorum.conditions.m10p3q3",
		source: "382_0f0a3cb1bc.png",
		test: (e) => e.n("FG", [0, 1]) === e.n("FG", [2, 3]) && e.n("FB", [0, 1]) === e.n("FB", [2, 3])
	},
	m10p4q1: {
		id: "m10p4q1",
		key: "games.decorum.conditions.m10p4q1",
		source: "386_76a095173e.png",
		test: (e) => _.some((t) => e.allObjects("chl"[t])) && e.distinct("wall") === 4
	},
	m10p4q2: {
		id: "m10p4q2",
		key: "games.decorum.conditions.m10p4q2",
		source: "386_76a095173e.png",
		test: (e) => C.every((t) => e.objects([t[0]]).every((n) => !e.objects([t[1]]).some((e) => S(n) === S(e))))
	},
	m10p4q3: {
		id: "m10p4q3",
		key: "games.decorum.conditions.m10p4q3",
		source: "386_76a095173e.png",
		test: (e) => e.n("G", [e.mine]) > 0 && e.n("l", [e.mine]) > 0
	}
}, A = [
	{
		id: "c1",
		rooms: [
			{
				wall: 3,
				slots: [
					3,
					4,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 2,
				slots: [
					null,
					10,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					null,
					8,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					null,
					5,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c1",
		conditions: [[
			"c1p1q1",
			"c1p1q2",
			"c1p1q3"
		], [
			"c1p2q1",
			"c1p2q2",
			"c1p2q3"
		]],
		characters: ["Spencer", "Blake"]
	},
	{
		id: "c2",
		rooms: [
			{
				wall: 3,
				slots: [
					null,
					null,
					8
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					null,
					null,
					2
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					3,
					11,
					4
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					10,
					null,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c2",
		conditions: [[
			"c2p1q1",
			"c2p1q2",
			"c2p1q3",
			"c2p1q4"
		], [
			"c2p2q1",
			"c2p2q2",
			"c2p2q3",
			"c2p2q4"
		]],
		characters: ["Agent Eve", "Rob Boss"]
	},
	{
		id: "c3",
		rooms: [
			{
				wall: 0,
				slots: [
					null,
					null,
					8
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					4,
					8,
					1
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					2,
					11,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					10,
					null,
					2
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c3",
		conditions: [[
			"c3p1q1",
			"c3p1q2",
			"c3p1q3",
			"c3p1q4"
		], [
			"c3p2q1",
			"c3p2q2",
			"c3p2q3",
			"c3p2q4"
		]],
		characters: ["The Duke", "Annie"]
	},
	{
		id: "c4",
		rooms: [
			{
				wall: 3,
				slots: [
					0,
					null,
					11
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					7,
					9,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					null,
					10,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					null,
					5,
					1
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c4",
		conditions: [[
			"c4p1q1",
			"c4p1q2",
			"c4p1q3",
			"c4p1q4"
		], [
			"c4p2q1",
			"c4p2q2",
			"c4p2q3",
			"c4p2q4"
		]],
		characters: ["Clive", "The Stevinator"]
	},
	{
		id: "c5",
		rooms: [
			{
				wall: 2,
				slots: [
					null,
					7,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 2,
				slots: [
					6,
					null,
					1
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					1,
					null,
					7
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					8,
					7,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c5",
		conditions: [[
			"c5p1q1",
			"c5p1q2",
			"c5p1q3",
			"c5p1q4"
		], [
			"c5p2q1",
			"c5p2q2",
			"c5p2q3",
			"c5p2q4"
		]],
		characters: ["Claire", "Ry"]
	},
	{
		id: "c6",
		rooms: [
			{
				wall: 0,
				slots: [
					3,
					6,
					11
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					null,
					null,
					2
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					1,
					null,
					7
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					10,
					7,
					0
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c6",
		conditions: [[
			"c6p1q1",
			"c6p1q2",
			"c6p1q3",
			"c6p1q4"
		], [
			"c6p2q1",
			"c6p2q2",
			"c6p2q3",
			"c6p2q4"
		]],
		characters: ["Spencer", "Dale the Ghost Hunter"]
	},
	{
		id: "c7",
		rooms: [
			{
				wall: 0,
				slots: [
					2,
					null,
					10
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					5,
					9,
					3
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					3,
					8,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 2,
				slots: [
					9,
					5,
					2
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c7",
		conditions: [[
			"c7p1q1",
			"c7p1q2",
			"c7p1q3",
			"c7p1q4"
		], [
			"c7p2q1",
			"c7p2q2",
			"c7p2q3",
			"c7p2q4"
		]],
		characters: ["Alfred", "Barney"]
	},
	{
		id: "c8",
		rooms: [
			{
				wall: 2,
				slots: [
					null,
					null,
					11
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					7,
					8,
					1
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					1,
					10,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					8,
					7,
					3
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c8",
		conditions: [[
			"c8p1q1",
			"c8p1q2",
			"c8p1q3",
			"c8p1q4"
		], [
			"c8p2q1",
			"c8p2q2",
			"c8p2q3",
			"c8p2q4"
		]],
		characters: ["Claire", "Clarissa Delish"]
	},
	{
		id: "c9",
		rooms: [
			{
				wall: 0,
				slots: [
					null,
					5,
					9
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 2,
				slots: [
					null,
					8,
					1
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					0,
					11,
					6
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					null,
					null,
					3
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c9",
		conditions: [[
			"c9p1q1",
			"c9p1q2",
			"c9p1q3",
			"c9p1q4",
			"c9p1q5"
		], [
			"c9p2q1",
			"c9p2q2",
			"c9p2q3",
			"c9p2q4",
			"c9p2q5"
		]],
		characters: ["Nick", "Knack"]
	},
	{
		id: "c10",
		rooms: [
			{
				wall: 1,
				slots: [
					1,
					null,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					null,
					9,
					3
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					2,
					8,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					8,
					5,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c10",
		conditions: [[
			"c10p1q1",
			"c10p1q2",
			"c10p1q3",
			"c10p1q4"
		], [
			"c10p2q1",
			"c10p2q2",
			"c10p2q3",
			"c10p2q4"
		]],
		characters: ["Agent Eve", "The Flux"]
	},
	{
		id: "c11",
		rooms: [
			{
				wall: 1,
				slots: [
					0,
					7,
					9
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 2,
				slots: [
					null,
					10,
					1
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 2,
				slots: [
					1,
					10,
					4
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 2,
				slots: [
					9,
					7,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c11",
		conditions: [[
			"c11p1q1",
			"c11p1q2",
			"c11p1q3",
			"c11p1q4"
		], [
			"c11p2q1",
			"c11p2q2",
			"c11p2q3",
			"c11p2q4"
		]],
		characters: ["Clive", "The Clive Experience"]
	},
	{
		id: "c12",
		rooms: [
			{
				wall: 0,
				slots: [
					null,
					null,
					11
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 2,
				slots: [
					6,
					null,
					12
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					1,
					null,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					10,
					5,
					12
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !0,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c12",
		conditions: [[
			"c12p1q1",
			"c12p1q2",
			"c12p1q3",
			"c12p1q4"
		], [
			"c12p2q1",
			"c12p2q2",
			"c12p2q3",
			"c12p2q4"
		]],
		characters: ["Aunt Judy", "Just Steve"]
	},
	{
		id: "c13",
		rooms: [
			{
				wall: 1,
				slots: [
					1,
					5,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					4,
					12,
					12
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 2,
				slots: [
					2,
					8,
					6
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					11,
					12,
					12
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !0,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c13",
		conditions: [[
			"c13p1q1",
			"c13p1q2",
			"c13p1q3",
			"c13p1q4"
		], [
			"c13p2q1",
			"c13p2q2",
			"c13p2q3",
			"c13p2q4"
		]],
		characters: ["Ollie Falcon", "Ry"]
	},
	{
		id: "c14",
		rooms: [
			{
				wall: 0,
				slots: [
					12,
					12,
					11
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					6,
					8,
					12
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					0,
					9,
					6
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					12,
					12,
					12
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !0,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c14",
		conditions: [[
			"c14p1q1",
			"c14p1q2",
			"c14p1q3",
			"c14p1q4"
		], [
			"c14p2q1",
			"c14p2q2",
			"c14p2q3",
			"c14p2q4",
			"c14p2q5"
		]],
		characters: ["Ghost of Spencer’s Mom", "Blake"]
	},
	{
		id: "c15",
		rooms: [
			{
				wall: 2,
				slots: [
					3,
					6,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					null,
					11,
					3
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					null,
					8,
					6
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					8,
					null,
					0
				],
				pets: [
					0,
					0,
					1,
					1
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !0,
		hasGifts: !0,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c15",
		conditions: [[
			"c15p1q1",
			"c15p1q2",
			"c15p1q3",
			"c15p1q4",
			"c15p1q5"
		], [
			"c15p2q1",
			"c15p2q2",
			"c15p2q3",
			"c15p2q4",
			"c15p2q5"
		]],
		characters: ["Annie", "The Duke"]
	},
	{
		id: "c16",
		rooms: [
			{
				wall: 1,
				slots: [
					2,
					4,
					null
				],
				pets: [
					1,
					0,
					0,
					1
				]
			},
			{
				wall: 2,
				slots: [
					null,
					12,
					1
				],
				pets: [
					1,
					0,
					0,
					1
				]
			},
			{
				wall: 3,
				slots: [
					1,
					10,
					12
				],
				pets: [
					0,
					1,
					0,
					1
				]
			},
			{
				wall: 0,
				slots: [
					null,
					6,
					12
				],
				pets: [
					1,
					0,
					1,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !0,
		hasGifts: !0,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c16",
		conditions: [[
			"c16p1q1",
			"c16p1q2",
			"c16p1q3",
			"c16p1q4",
			"c16p1q5"
		], [
			"c16p2q1",
			"c16p2q2",
			"c16p2q3",
			"c16p2q4",
			"c16p2q5",
			"c16p2q6"
		]],
		characters: ["Claire", "Ry"]
	},
	{
		id: "c17",
		rooms: [
			{
				wall: 3,
				slots: [
					3,
					null,
					null
				],
				pets: [
					0,
					1,
					0,
					1
				]
			},
			{
				wall: 0,
				slots: [
					null,
					10,
					null
				],
				pets: [
					0,
					0,
					0,
					1
				]
			},
			{
				wall: 1,
				slots: [
					null,
					11,
					5
				],
				pets: [
					1,
					0,
					1,
					0
				]
			},
			{
				wall: 3,
				slots: [
					null,
					4,
					1
				],
				pets: [
					0,
					1,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !0,
		hasGifts: !0,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c17",
		conditions: [[
			"c17p1q1",
			"c17p1q2",
			"c17p1q3",
			"c17p1q4",
			"c17p1q5",
			"c17p1q6"
		], [
			"c17p2q1",
			"c17p2q2",
			"c17p2q3",
			"c17p2q4",
			"c17p2q5"
		]],
		characters: ["Ghost of Spencer’s Mom", "Dale the Ghost Hunter"]
	},
	{
		id: "c18",
		rooms: [
			{
				wall: 1,
				slots: [
					12,
					7,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					null,
					12,
					0
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					12,
					null,
					null
				],
				pets: [
					0,
					0,
					0,
					1
				]
			},
			{
				wall: 0,
				slots: [
					12,
					6,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !0,
		hasGifts: !0,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c18",
		conditions: [[
			"c18p1q1",
			"c18p1q2",
			"c18p1q3",
			"c18p1q4"
		], [
			"c18p2q1",
			"c18p2q2",
			"c18p2q3",
			"c18p2q4"
		]],
		characters: ["The Steve Experience", "Steve"]
	},
	{
		id: "c19",
		rooms: [
			{
				wall: 3,
				slots: [
					0,
					12,
					11
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					5,
					12,
					0
				],
				pets: [
					0,
					0,
					1,
					1
				]
			},
			{
				wall: 2,
				slots: [
					1,
					12,
					null
				],
				pets: [
					1,
					1,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					null,
					12,
					0
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !0,
		hasGifts: !0,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c19",
		conditions: [[
			"c19p1q1",
			"c19p1q2",
			"c19p1q3",
			"c19p1q4",
			"c19p1q5"
		], [
			"c19p2q1",
			"c19p2q2",
			"c19p2q3",
			"c19p2q4",
			"c19p2q5"
		]],
		characters: ["The Time Machine", "Eve: The Flux"]
	},
	{
		id: "c20",
		rooms: [
			{
				wall: 1,
				slots: [
					2,
					4,
					null
				],
				pets: [
					1,
					0,
					0,
					1
				]
			},
			{
				wall: 2,
				slots: [
					null,
					12,
					1
				],
				pets: [
					1,
					0,
					0,
					1
				]
			},
			{
				wall: 3,
				slots: [
					1,
					10,
					12
				],
				pets: [
					0,
					1,
					0,
					1
				]
			},
			{
				wall: 0,
				slots: [
					null,
					6,
					12
				],
				pets: [
					1,
					0,
					1,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !0,
		hasGifts: !0,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.c20",
		conditions: [[
			"c20p1q1",
			"c20p1q2",
			"c20p1q3",
			"c20p1q4",
			"c20p1q5"
		], [
			"c20p2q1",
			"c20p2q2",
			"c20p2q3",
			"c20p2q4",
			"c20p2q5"
		]],
		characters: ["Spencer", "Blake"]
	},
	{
		id: "m1",
		rooms: [
			{
				wall: 3,
				slots: [
					null,
					null,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					7,
					8,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					1,
					null,
					7
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					null,
					6,
					3
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.m1",
		conditions: [
			[
				"m1p1q1",
				"m1p1q2",
				"m1p1q3"
			],
			[
				"m1p2q1",
				"m1p2q2",
				"m1p2q3"
			],
			[
				"m1p3q1",
				"m1p3q2",
				"m1p3q3"
			],
			[
				"m1p4q1",
				"m1p4q2",
				"m1p4q3"
			]
		],
		characters: [
			"1",
			"2",
			"3",
			"4"
		]
	},
	{
		id: "m2",
		rooms: [
			{
				wall: 1,
				slots: [
					3,
					5,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					7,
					null,
					2
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					0,
					null,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					10,
					4,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.m2",
		conditions: [
			[
				"m2p1q1",
				"m2p1q2",
				"m2p1q3"
			],
			[
				"m2p2q1",
				"m2p2q2",
				"m2p2q3"
			],
			[
				"m2p3q1",
				"m2p3q2",
				"m2p3q3"
			],
			[
				"m2p4q1",
				"m2p4q2",
				"m2p4q3"
			]
		],
		characters: [
			"1",
			"2",
			"3",
			"4"
		]
	},
	{
		id: "m3",
		rooms: [
			{
				wall: 0,
				slots: [
					null,
					null,
					10
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					null,
					11,
					0
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					null,
					10,
					7
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					9,
					6,
					0
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.m3",
		conditions: [
			[
				"m3p1q1",
				"m3p1q2",
				"m3p1q3"
			],
			[
				"m3p2q1",
				"m3p2q2",
				"m3p2q3"
			],
			[
				"m3p3q1",
				"m3p3q2",
				"m3p3q3"
			],
			[
				"m3p4q1",
				"m3p4q2",
				"m3p4q3"
			]
		],
		characters: [
			"1",
			"2",
			"3",
			"4"
		]
	},
	{
		id: "m4",
		rooms: [
			{
				wall: 2,
				slots: [
					0,
					7,
					8
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					5,
					null,
					3
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 2,
				slots: [
					2,
					null,
					5
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 2,
				slots: [
					8,
					null,
					3
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.m4",
		conditions: [
			[
				"m4p1q1",
				"m4p1q2",
				"m4p1q3"
			],
			[
				"m4p2q1",
				"m4p2q2",
				"m4p2q3"
			],
			[
				"m4p3q1",
				"m4p3q2",
				"m4p3q3"
			],
			[
				"m4p4q1",
				"m4p4q2",
				"m4p4q3"
			]
		],
		characters: [
			"1",
			"2",
			"3",
			"4"
		]
	},
	{
		id: "m5",
		rooms: [
			{
				wall: 3,
				slots: [
					3,
					null,
					8
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					7,
					8,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					0,
					null,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					8,
					7,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !1,
		titleKey: "games.decorum.scenarios.m5",
		conditions: [
			[
				"m5p1q1",
				"m5p1q2",
				"m5p1q3"
			],
			[
				"m5p2q1",
				"m5p2q2",
				"m5p2q3"
			],
			[
				"m5p3q1",
				"m5p3q2",
				"m5p3q3"
			],
			[
				"m5p4q1",
				"m5p4q2",
				"m5p4q3"
			]
		],
		characters: [
			"1",
			"2",
			"3",
			"4"
		]
	},
	{
		id: "m6",
		rooms: [
			{
				wall: 3,
				slots: [
					3,
					null,
					9
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					5,
					8,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					2,
					11,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					null,
					7,
					1
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			1,
			1
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !0,
		titleKey: "games.decorum.scenarios.m6",
		conditions: [
			[
				"m6p1q1",
				"m6p1q2",
				"m6p1q3"
			],
			[
				"m6p2q1",
				"m6p2q2",
				"m6p2q3"
			],
			[
				"m6p3q1",
				"m6p3q2",
				"m6p3q3"
			],
			[
				"m6p4q1",
				"m6p4q2",
				"m6p4q3"
			]
		],
		characters: [
			"1",
			"2",
			"3",
			"4"
		]
	},
	{
		id: "m7",
		rooms: [
			{
				wall: 0,
				slots: [
					1,
					6,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					7,
					null,
					2
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					1,
					9,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 3,
				slots: [
					null,
					4,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			0,
			1,
			1
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !0,
		titleKey: "games.decorum.scenarios.m7",
		conditions: [
			[
				"m7p1q1",
				"m7p1q2",
				"m7p1q3"
			],
			[
				"m7p2q1",
				"m7p2q2",
				"m7p2q3"
			],
			[
				"m7p3q1",
				"m7p3q2",
				"m7p3q3"
			],
			[
				"m7p4q1",
				"m7p4q2",
				"m7p4q3"
			]
		],
		characters: [
			"1",
			"2",
			"3",
			"4"
		]
	},
	{
		id: "m8",
		rooms: [
			{
				wall: 0,
				slots: [
					3,
					null,
					8
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					6,
					8,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					3,
					8,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					8,
					7,
					1
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			1,
			1,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !0,
		titleKey: "games.decorum.scenarios.m8",
		conditions: [
			[
				"m8p1q1",
				"m8p1q2",
				"m8p1q3"
			],
			[
				"m8p2q1",
				"m8p2q2",
				"m8p2q3"
			],
			[
				"m8p3q1",
				"m8p3q2",
				"m8p3q3"
			],
			[
				"m8p4q1",
				"m8p4q2",
				"m8p4q3"
			]
		],
		characters: [
			"1",
			"2",
			"3",
			"4"
		]
	},
	{
		id: "m9",
		rooms: [
			{
				wall: 3,
				slots: [
					2,
					4,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 0,
				slots: [
					5,
					11,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					1,
					11,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 2,
				slots: [
					10,
					null,
					1
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			1,
			1,
			0,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !0,
		titleKey: "games.decorum.scenarios.m9",
		conditions: [
			[
				"m9p1q1",
				"m9p1q2",
				"m9p1q3"
			],
			[
				"m9p2q1",
				"m9p2q2",
				"m9p2q3"
			],
			[
				"m9p3q1",
				"m9p3q2",
				"m9p3q3"
			],
			[
				"m9p4q1",
				"m9p4q2",
				"m9p4q3"
			]
		],
		characters: [
			"1",
			"2",
			"3",
			"4"
		]
	},
	{
		id: "m10",
		rooms: [
			{
				wall: 3,
				slots: [
					null,
					null,
					8
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					7,
					9,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 2,
				slots: [
					3,
					8,
					null
				],
				pets: [
					0,
					0,
					0,
					0
				]
			},
			{
				wall: 1,
				slots: [
					null,
					6,
					3
				],
				pets: [
					0,
					0,
					0,
					0
				]
			}
		],
		roommates: [
			0,
			1,
			1,
			0
		],
		hasPets: !1,
		hasGifts: !1,
		hasRoommates: !0,
		titleKey: "games.decorum.scenarios.m10",
		conditions: [
			[
				"m10p1q1",
				"m10p1q2",
				"m10p1q3"
			],
			[
				"m10p2q1",
				"m10p2q2",
				"m10p2q3"
			],
			[
				"m10p3q1",
				"m10p3q2",
				"m10p3q3"
			],
			[
				"m10p4q1",
				"m10p4q2",
				"m10p4q3"
			]
		],
		characters: [
			"1",
			"2",
			"3",
			"4"
		]
	}
];
//#endregion
//#region src/games/decorum/moves.ts
function j(e, t) {
	let n = [], r = e.rooms.flatMap((e) => e.slots), i = [
		0,
		1,
		2,
		3
	].map((t) => e.rooms.reduce((e, n) => e + n.pets[t], 0));
	if (e.rooms.forEach((a, o) => {
		for (let e = 0; e < 4; e += 1) e !== a.wall && n.push({
			type: "paint",
			room: o,
			color: e
		});
		if (a.slots.forEach((t, i) => {
			if (t === 12) e.rooms.forEach((e, t) => e.slots.forEach((e, r) => {
				e === null && n.push({
					type: "gift",
					room: o,
					slot: i,
					toRoom: t,
					toSlot: r
				});
			}));
			else {
				t !== null && n.push({
					type: "object",
					room: o,
					slot: i,
					object: null
				});
				for (let e = 0; e < 4; e += 1) {
					let a = v[o][i] * 4 + e;
					a !== t && r.filter((e) => e === a).length < 4 && n.push({
						type: "object",
						room: o,
						slot: i,
						object: a
					});
				}
			}
		}), t.hasPets) {
			for (let e = 0; e < 4; e += 1) if (i[e] < 8 && n.push({
				type: "addPet",
				room: o,
				pet: e
			}), a.pets[e] > 0) {
				n.push({
					type: "pet",
					room: o,
					pet: e,
					toRoom: null,
					toPet: null
				});
				for (let t = 0; t < 4; t += 1) t !== o && n.push({
					type: "pet",
					room: o,
					pet: e,
					toRoom: t,
					toPet: e
				});
				for (let t of [e ^ 1, e ^ 2]) i[t] < 8 && n.push({
					type: "pet",
					room: o,
					pet: e,
					toRoom: o,
					toPet: t
				});
			}
		}
	}), t.hasRoommates) {
		let r = 1 - e.roommates[t.seat], i = e.roommates.flatMap((e, t) => e === r ? [t] : []);
		i.length < 2 && n.push({
			type: "roommate",
			kick: null
		});
		for (let e of i) n.push({
			type: "roommate",
			kick: e
		});
	}
	return t.canPass && n.push({ type: "pass" }), n;
}
function M(e, t, n) {
	let r = structuredClone(e);
	if (t.type === "object" && (r.rooms[t.room].slots[t.slot] = t.object), t.type === "paint" && (r.rooms[t.room].wall = t.color), t.type === "gift" && (r.rooms[t.room].slots[t.slot] = null, r.rooms[t.toRoom].slots[t.toSlot] = 12), t.type === "addPet" && (r.rooms[t.room].pets[t.pet] += 1), t.type === "pet" && (--r.rooms[t.room].pets[t.pet], t.toRoom !== null && t.toPet !== null && (r.rooms[t.toRoom].pets[t.toPet] += 1)), t.type === "roommate") {
		let e = r.roommates[n];
		r.roommates[n] = 1 - e, t.kick !== null && (r.roommates[t.kick] = e);
	}
	return r;
}
function ee(e, t) {
	return e.type === t.type && Object.entries(e).every(([e, n]) => Reflect.get(t, e) === n);
}
function N(e, t) {
	return t.type === "object" ? x(t.object ?? e.rooms[t.room].slots[t.slot]) : -1;
}
function P(e) {
	return {
		rooms: structuredClone(e.rooms),
		roommates: [...e.roommates]
	};
}
//#endregion
//#region src/games/decorum/schema.ts
var F = e.int().min(0).max(3), I = e.int().min(0).max(2), L = e.int().min(0).max(3), R = e.object({
	campaign: e.int().min(1).max(20).default(1),
	multiplayer: e.int().min(1).max(10).default(1)
}).default({
	campaign: 1,
	multiplayer: 1
}), z = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("object"),
		room: F,
		slot: I,
		object: e.int().min(0).max(11).nullable()
	}),
	e.object({
		type: e.literal("paint"),
		room: F,
		color: e.int().min(0).max(3)
	}),
	e.object({
		type: e.literal("gift"),
		room: F,
		slot: I,
		toRoom: F,
		toSlot: I
	}),
	e.object({
		type: e.literal("pet"),
		room: F,
		pet: L,
		toRoom: F.nullable(),
		toPet: L.nullable()
	}),
	e.object({
		type: e.literal("addPet"),
		room: F,
		pet: L
	}),
	e.object({
		type: e.literal("roommate"),
		kick: e.int().min(0).max(3).nullable()
	}),
	e.object({ type: e.literal("pass") })
]), B = e.discriminatedUnion("type", [
	...z.options,
	e.object({
		type: e.literal("comment"),
		mood: e.enum([
			"positive",
			"negative",
			"neutral"
		])
	}),
	e.object({
		type: e.literal("share"),
		condition: e.string(),
		to: e.string()
	}),
	e.object({
		type: e.literal("recall"),
		condition: e.string()
	}),
	e.object({ type: e.literal("finishSharing") }),
	e.object({ type: e.literal("earlyMeeting") }),
	e.object({
		type: e.literal("vote"),
		agree: e.boolean()
	})
]), te = e.object({
	wall: F,
	slots: e.array(e.int().min(0).max(12).nullable()).length(3),
	pets: e.array(e.int().min(0).max(8)).length(4)
}), V = e.object({
	owner: e.string(),
	condition: e.string(),
	to: e.string()
}), ne = e.object({
	rid: e.string(),
	mood: e.enum([
		"positive",
		"negative",
		"neutral"
	]),
	turn: e.int()
}), re = e.object({
	rooms: e.array(te).length(4),
	roommates: e.array(F)
}), ie = e.object({
	by: e.string(),
	move: z,
	forbidden: e.boolean(),
	turn: e.int()
}), ae = e.object({
	...re.shape,
	scenario: e.string(),
	round: e.int().min(1).max(30),
	hearts: e.int().min(0).max(5),
	phase: e.enum([
		"act",
		"comment",
		"meeting",
		"early",
		"done"
	]),
	active: e.string(),
	players: e.array(e.object({
		rid: e.string(),
		character: e.string(),
		fulfilled: e.boolean(),
		commented: e.boolean(),
		meetingDone: e.boolean()
	})),
	turn: e.int(),
	lastChange: ie.nullable(),
	comments: e.array(ne),
	previous: re.nullable(),
	publicShared: e.array(V),
	earlyVotes: e.array(e.string()),
	history: e.array(ie),
	revealed: e.array(e.object({
		rid: e.string(),
		conditions: e.array(e.object({
			id: e.string(),
			met: e.boolean()
		}))
	})),
	won: e.boolean(),
	score: e.int().nonnegative(),
	bonus: e.int().nonnegative()
}), oe = e.object({
	conditions: e.array(e.object({
		id: e.string(),
		met: e.boolean()
	})),
	shared: e.array(V),
	given: e.array(V),
	sharedThisMeeting: e.boolean(),
	ban: e.int().nullable()
});
//#endregion
//#region src/games/decorum/rules.ts
function H(e, t) {
	let n = new O(e, e.players.indexOf(t));
	return (e.conditions[t] ?? []).map((e) => ({
		id: e,
		met: k[e].test(n)
	}));
}
var U = (e, t) => H(e, t).every((e) => e.met), se = (e) => (e.players.length === 2 ? 3 : 5) - e.meetings, ce = (e) => A.find((t) => t.id === e.scenario);
function le(e, t) {
	return e.scenario === "c20" ? t === 0 ? 2 : 0 : null;
}
function ue(e) {
	e.phase = "done", e.won = e.players.every((t) => U(e, t)), e.bonus = e.won ? se(e) * 2 : 0, e.score = e.players.flatMap((t) => H(e, t)).filter((e) => e.met).length * 3 + e.bonus;
}
function de(e) {
	e.phase = "meeting", e.meetingDone = [], e.sharedThisMeeting = [], e.earlyVotes = [];
}
function fe(e) {
	if (e.players.every((t) => U(e, t))) {
		ue(e);
		return;
	}
	if (e.commented = [], e.seat += 1, e.seat === e.players.length) {
		if (e.seat = 0, e.round === 30) {
			ue(e);
			return;
		}
		if ((e.players.length === 2 ? [
			15,
			20,
			25
		] : [
			5,
			10,
			15,
			20,
			25
		]).includes(e.round)) {
			de(e);
			return;
		}
		e.round += 1;
	}
	e.phase = "act";
}
function pe(e, t) {
	let n = A.find((n) => n.id === (t.length === 2 ? "c" + e.campaign : "m" + e.multiplayer)), r = {};
	return t.forEach((e, t) => {
		r[e] = [...n.conditions[t]];
	}), t.length === 3 && n.conditions[3].forEach((e, n) => r[t[n]].push(e)), { state: {
		...P(n),
		roommates: n.roommates.slice(0, t.length),
		players: [...t],
		scenario: n.id,
		conditions: r,
		round: 1,
		turn: 0,
		seat: 0,
		meetings: 0,
		phase: "act",
		comments: [],
		commented: [],
		shared: [],
		sharedThisMeeting: [],
		meetingDone: [],
		previous: null,
		lastChange: null,
		history: [],
		earlyVotes: [],
		won: !1,
		score: 0,
		bonus: 0
	} };
}
var W = (e) => ({ code: {
	errTurn: "games.decorum.errTurn",
	errAction: "games.decorum.errAction",
	errShare: "games.decorum.errShare",
	errPass: "games.decorum.errPass",
	errVote: "games.decorum.errVote"
}[e] });
function me(e, t, n) {
	let r = e.players.indexOf(n.by);
	if (r < 0 || e.phase === "done") return W("errTurn");
	let i = structuredClone(e);
	if (t.type === "earlyMeeting") return i.phase !== "act" || i.meetings !== 0 ? W("errVote") : (i.phase = "early", i.earlyVotes = [n.by], { state: i });
	if (t.type === "vote") return i.phase !== "early" || i.earlyVotes.includes(n.by) ? W("errVote") : t.agree ? (i.earlyVotes.push(n.by), i.earlyVotes.length === i.players.length && (i.round = i.players.length === 2 ? 15 : 5, i.seat = 0, de(i)), { state: i }) : (i.phase = "act", i.earlyVotes = [], { state: i });
	if (t.type === "comment") return i.phase !== "comment" || r === i.seat || i.commented.includes(n.by) ? W("errTurn") : (i.comments.push({
		rid: n.by,
		mood: t.mood,
		turn: i.turn
	}), i.commented.push(n.by), i.commented.length === i.players.length - 1 && fe(i), { state: i });
	if (t.type === "share" || t.type === "recall" || t.type === "finishSharing") {
		if (i.phase !== "meeting" || i.meetingDone.includes(n.by)) return W("errShare");
		if (t.type === "finishSharing") {
			if (!i.sharedThisMeeting.includes(n.by)) return W("errShare");
			i.meetingDone.push(n.by), i.meetingDone.length === i.players.length && (i.meetings += 1, i.round += 1, i.phase = "act", i.seat = 0);
		} else if (t.type === "recall") {
			if (i.players.length === 2 || !i.conditions[n.by].includes(t.condition)) return W("errShare");
			i.shared = i.shared.filter((e) => e.owner !== n.by || e.condition !== t.condition);
		} else {
			if (!i.conditions[n.by].includes(t.condition) || t.to === n.by || !i.players.includes(t.to) || i.sharedThisMeeting.includes(n.by)) return W("errShare");
			i.shared = i.shared.filter((e) => e.owner !== n.by || e.condition !== t.condition), i.shared.push({
				owner: n.by,
				condition: t.condition,
				to: t.to
			}), i.sharedThisMeeting.push(n.by);
		}
		return { state: i };
	}
	if (i.phase !== "act" || r !== i.seat) return W("errTurn");
	let a = t;
	if (a.type === "pass" && !U(i, n.by)) return W("errPass");
	let o = ce(i);
	if (!j(i, {
		hasPets: o.hasPets,
		hasRoommates: o.hasRoommates,
		canPass: U(i, n.by),
		seat: r
	}).some((e) => ee(e, a))) return W("errAction");
	i.previous = P(i), i.turn += 1;
	let s = le(i, r), c = s !== null && N(i, a) === s;
	if (i.lastChange = {
		by: n.by,
		move: a,
		forbidden: c,
		turn: i.turn
	}, i.history.push(i.lastChange), c) return fe(i), {
		state: i,
		fx: [{
			kind: "decorum-forbidden",
			rid: n.by,
			data: { room: "room" in a ? a.room : 0 }
		}]
	};
	let l = M(i, a, r);
	i.rooms = l.rooms, i.roommates = l.roommates;
	let u = a.type === "pass" ? [] : [{
		kind: "decorum-change",
		rid: n.by,
		data: {
			move: a,
			before: i.previous.rooms.map((e) => ({ ...e })),
			roommates: i.previous.roommates,
			players: i.players
		}
	}];
	return i.players.every((e) => U(i, e)) ? (ue(i), {
		state: i,
		fx: u
	}) : (i.phase = "comment", i.commented = [], {
		state: i,
		fx: u
	});
}
function he(e, t) {
	let n = ce(e), r = e.players.indexOf(t);
	return {
		public: {
			...P(e),
			scenario: e.scenario,
			round: e.round,
			hearts: se(e),
			phase: e.phase,
			active: e.players[e.seat],
			players: e.players.map((t, r) => ({
				rid: t,
				character: n.characters[r],
				fulfilled: U(e, t),
				commented: e.commented.includes(t),
				meetingDone: e.meetingDone.includes(t)
			})),
			turn: e.turn,
			lastChange: structuredClone(e.lastChange),
			comments: structuredClone(e.comments),
			previous: e.previous ? P(e.previous) : null,
			publicShared: e.players.length === 2 ? structuredClone(e.shared) : [],
			earlyVotes: [...e.earlyVotes],
			history: structuredClone(e.history),
			revealed: e.phase === "done" ? e.players.map((t) => ({
				rid: t,
				conditions: H(e, t)
			})) : [],
			won: e.won,
			score: e.score,
			bonus: e.bonus
		},
		...r < 0 ? {} : { private: {
			conditions: H(e, t),
			shared: e.shared.filter((e) => e.to === t).map((e) => ({ ...e })),
			given: e.shared.filter((e) => e.owner === t).map((e) => ({ ...e })),
			sharedThisMeeting: e.sharedThisMeeting.includes(t),
			ban: le(e, r)
		} }
	};
}
var ge = {
	meta: h,
	saveCompatibility: { version: "1" },
	schemas: {
		action: B,
		config: R,
		publicView: ae,
		privateView: oe
	},
	setup: pe,
	reduce: me,
	viewFor: he,
	status: (e) => ({
		phase: e.phase,
		...e.phase === "done" ? {
			winner: e.won ? [...e.players] : [],
			ranking: [...e.players],
			scores: Object.fromEntries(e.players.map((t) => [t, e.score]))
		} : {}
	})
}, G = [
	"#db3742",
	"#ffca2c",
	"#0bb44d",
	"#007fb9"
], K = [
	"games.decorum.red",
	"games.decorum.yellow",
	"games.decorum.green",
	"games.decorum.blue"
], q = [
	"games.decorum.curio",
	"games.decorum.hanging",
	"games.decorum.lamp"
], _e = [
	"games.decorum.modern",
	"games.decorum.antique",
	"games.decorum.retro",
	"games.decorum.unusual"
], J = [
	"games.decorum.smallCat",
	"games.decorum.bigCat",
	"games.decorum.smallDog",
	"games.decorum.bigDog"
];
function Y(e, t) {
	return t === 12 ? e("games.decorum.gift") : e("games.decorum.objectName", {
		color: e(K[b(t)]),
		style: e(_e[S(t)]),
		type: e(q[x(t)])
	});
}
function X({ object: e, pet: t, className: n = "" }) {
	return /* @__PURE__ */ l("img", {
		className: `decorum-art ${n}`,
		src: `games/decorum/${t === void 0 ? e === 12 ? "gift" : `object-${e}` : `pet-${t}`}.svg`,
		alt: "",
		draggable: !1
	});
}
function ve() {
	return /* @__PURE__ */ l("svg", {
		className: "decorum-target-ring",
		"aria-hidden": !0,
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		children: /* @__PURE__ */ l("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "5",
			pathLength: "100"
		})
	});
}
function ye({ type: e }) {
	return /* @__PURE__ */ l("svg", {
		viewBox: "0 0 60 76",
		width: "55%",
		height: "65%",
		"aria-hidden": !0,
		style: { color: "#a1a1a1" },
		children: /* @__PURE__ */ l("path", {
			d: [
				"M13 63V27a17 17 0 0 1 34 0v36l6 6H7Z",
				"M10 16h15l5-6 5 6h15v52H10ZM17 23h26v38H17Z",
				"M15 12h30l8 39H7ZM27 51h6v13h13v5H14v-5h13Z"
			][e],
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2"
		})
	});
}
function Z({ name: e, children: t, className: n = "", style: r }) {
	let { ref: i, hidden: a } = s(e);
	return /* @__PURE__ */ l("div", {
		ref: i,
		className: n,
		style: {
			...r,
			visibility: a ? "hidden" : void 0
		},
		children: t
	});
}
function be() {
	return /* @__PURE__ */ l("svg", {
		viewBox: "0 0 30 28",
		width: "20",
		height: "19",
		"aria-hidden": !0,
		children: /* @__PURE__ */ l("path", {
			d: "M15 25C-11 8 7-7 15 5C23-7 41 8 15 25Z",
			fill: "currentColor"
		})
	});
}
//#endregion
//#region src/games/decorum/board.tsx
var xe = [
	"games.decorum.room0",
	"games.decorum.room1",
	"games.decorum.room2",
	"games.decorum.room3"
];
function Q(e, t, n) {
	return e(n && t < 2 ? t === 0 ? "games.decorum.bedroomA" : "games.decorum.bedroomB" : xe[t]);
}
function Se({ pub: e, nameOf: t, controls: n }) {
	let r = i(), a = A.find((t) => t.id === e.scenario);
	return /* @__PURE__ */ u("div", {
		className: "decorum-house",
		children: [/* @__PURE__ */ l("div", {
			className: "decorum-roof",
			children: /* @__PURE__ */ l("span", { children: "DÉCORUM" })
		}), /* @__PURE__ */ l("div", {
			className: "decorum-rooms",
			children: e.rooms.map((i, o) => /* @__PURE__ */ u("section", {
				className: "decorum-room",
				style: { "--decorum-wall": G[i.wall] },
				"aria-label": Q(r, o, a.hasRoommates),
				children: [/* @__PURE__ */ l(Z, {
					name: `wall:${o}`,
					className: "decorum-room-header",
					children: /* @__PURE__ */ u("button", {
						className: "decorum-wall",
						type: "button",
						disabled: !n,
						onClick: () => n?.wall(o),
						children: [/* @__PURE__ */ l("strong", { children: Q(r, o, a.hasRoommates) }), /* @__PURE__ */ l("span", { children: r(K[i.wall]) })]
					})
				}), /* @__PURE__ */ u("div", {
					className: "decorum-room-interior",
					style: { backgroundImage: `url(games/decorum/${a.hasRoommates && o < 2 ? "roommate-room" : "room"}-${o}.svg)` },
					children: [
						/* @__PURE__ */ l("div", {
							className: "decorum-slots",
							children: i.slots.map((e, t) => {
								let i = n?.targets.some((e) => e.type === "object" && e.room === o && e.slot === t || e.type === "gift" && e.toRoom === o && e.toSlot === t), s = n?.selected?.room === o && n.selected.slot === t;
								return /* @__PURE__ */ u("button", {
									type: "button",
									className: "decorum-slot",
									"data-selected": s,
									"data-empty": e === null,
									disabled: !n,
									onClick: () => n?.slot(o, t),
									"aria-label": `${Q(r, o, a.hasRoommates)} · ${e === null ? r(q[v[o][t]]) : Y(r, e)}`,
									children: [
										/* @__PURE__ */ l(Z, {
											name: `slot:${o}:${t}`,
											className: "decorum-slot-content",
											children: e === null ? /* @__PURE__ */ l(ye, { type: v[o][t] }) : /* @__PURE__ */ l(X, { object: e })
										}),
										/* @__PURE__ */ l("span", {
											className: "decorum-slot-label",
											children: r(e === 12 ? "games.decorum.gift" : q[v[o][t]])
										}),
										i && /* @__PURE__ */ l(ve, {})
									]
								}, t);
							})
						}),
						a.hasPets && /* @__PURE__ */ l("div", {
							className: "decorum-pets",
							children: i.pets.map((e, t) => /* @__PURE__ */ l("button", {
								className: "decorum-pet-button",
								"data-empty": e === 0,
								type: "button",
								disabled: !n || e === 0,
								tabIndex: e === 0 ? -1 : void 0,
								onClick: () => n?.pet(o, t),
								"aria-label": r("games.decorum.petCount", {
									pet: r(J[t]),
									n: e
								}),
								children: /* @__PURE__ */ l(Z, {
									name: `pet:${o}:${t}`,
									className: "decorum-pet-content",
									children: e > 0 && /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l(X, { pet: t }), /* @__PURE__ */ l("b", { children: e })] })
								})
							}, t))
						}),
						n?.targets.some((e) => e.type === "addPet" && e.room === o || e.type === "pet" && e.toRoom === o) && /* @__PURE__ */ u("button", {
							className: "decorum-pet-target",
							type: "button",
							onClick: () => n.pet(o, -1),
							"aria-label": Q(r, o, a.hasRoommates),
							children: [/* @__PURE__ */ l(ve, {}), r("games.decorum.pet")]
						}),
						a.hasRoommates && o < 2 && /* @__PURE__ */ u("div", {
							className: "decorum-roommates",
							children: [/* @__PURE__ */ l(Z, {
								name: `roommates:${o}`,
								className: "decorum-roommate-row",
								children: e.players.filter((t, n) => e.roommates[n] === o).map((n) => /* @__PURE__ */ u(Z, {
									name: `roommate:${n.rid}`,
									className: "decorum-roommate",
									children: [/* @__PURE__ */ l("span", { children: e.players.indexOf(n) + 1 }), /* @__PURE__ */ l("small", { children: t(n.rid) })]
								}, n.rid))
							}), n && /* @__PURE__ */ l("button", {
								type: "button",
								onClick: () => n.roommate(o),
								children: r("games.decorum.moveRoom")
							})]
						})
					]
				})]
			}, o))
		})]
	});
}
//#endregion
//#region src/games/decorum/view-player.tsx
function Ce(e) {
	return a(), /* @__PURE__ */ l(we, { ...e }, e.myRid);
}
function we({ public: e, private: n, members: a, myRid: s, send: d }) {
	let f = i(), p = e, m = n, [h, g] = r(null), [_, y] = r(null), [b, x] = r(null), [S, C] = r(() => window.matchMedia("(min-width:701px)").matches);
	t(() => {
		let e = window.matchMedia("(min-width:701px)"), t = () => C(e.matches);
		return e.addEventListener("change", t), () => e.removeEventListener("change", t);
	}, []);
	let w = A.find((e) => e.id === p.scenario), T = p.players.findIndex((e) => e.rid === s), E = p.players[T], D = (e) => a.find((t) => t.rid === e)?.name ?? e, O = p.phase === "act" && p.active === s && !!m, M = O ? j(p, {
		seat: T,
		canPass: E.fulfilled,
		hasPets: w.hasPets,
		hasRoommates: w.hasRoommates
	}) : [], N = (e) => M.some((t) => ee(t, e)), P = (e) => {
		d(e), g(null), y(null), x(null);
	}, F = h ? M.filter((e) => h.type === "object" ? e.type === "object" && e.object === h.object : h.type === "paint" ? e.type === "paint" && e.color === h.color : h.type === "gift" ? e.type === "gift" && e.room === h.room && e.slot === h.slot : h.type === "addPet" ? e.type === "addPet" && e.pet === h.pet : e.type === "pet" && e.room === h.room && e.pet === h.pet && e.toRoom !== h.room && e.toRoom !== null) : [], I = (e, t) => {
		if (h?.type === "object") {
			let n = {
				type: "object",
				room: e,
				slot: t,
				object: h.object
			};
			N(n) && P(n);
			return;
		}
		if (h?.type === "gift") {
			let n = {
				type: "gift",
				room: h.room,
				slot: h.slot,
				toRoom: e,
				toSlot: t
			};
			N(n) && P(n);
			return;
		}
		if (!h) {
			if (p.rooms[e].slots[t] === 12) {
				g({
					type: "gift",
					room: e,
					slot: t
				});
				return;
			}
			y({
				type: "object",
				room: e,
				slot: t
			});
		}
	}, L = (e) => {
		if (h?.type === "paint") {
			let t = {
				type: "paint",
				room: e,
				color: h.color
			};
			N(t) && P(t);
		} else h || y({
			type: "paint",
			room: e
		});
	}, R = (e, t) => {
		let n = F.find((t) => t.type === "addPet" && t.room === e || t.type === "pet" && t.toRoom === e);
		if (n) {
			P(n);
			return;
		}
		t >= 0 && !h && y({
			type: "pet",
			room: e,
			pet: t
		});
	}, z = p.phase === "comment" && p.active !== s && !!E && !E.commented, B = p.phase === "meeting" && !!m && !E?.meetingDone, te = O && _ !== null, V = O && h && (h.type === "gift" ? {
		room: h.room,
		slot: h.slot
	} : h.type === "pet" ? {
		room: h.room,
		pet: h.pet
	} : void 0), ne = p.phase === "meeting" ? f("games.decorum.meeting") : p.phase === "early" ? f("games.decorum.earlyPending") : p.phase === "comment" ? f("games.decorum.reactPrompt") : f("games.decorum.turn", { name: D(p.active) });
	return /* @__PURE__ */ l("div", {
		className: "decorum-screen",
		children: /* @__PURE__ */ l(o, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ u("header", {
				className: "decorum-top",
				children: [
					/* @__PURE__ */ u("div", {
						className: "decorum-title",
						children: [/* @__PURE__ */ l("b", { children: "DÉCORUM" }), /* @__PURE__ */ l("span", { children: f(w.titleKey) })]
					}),
					/* @__PURE__ */ u("div", {
						className: "decorum-time",
						children: [/* @__PURE__ */ l("strong", { children: f("games.decorum.round", { n: p.round }) }), /* @__PURE__ */ l("span", {
							"aria-label": f("games.decorum.hearts", { n: p.hearts }),
							children: Array.from({ length: p.hearts }, (e, t) => /* @__PURE__ */ l(be, {}, t))
						})]
					}),
					/* @__PURE__ */ l("div", {
						className: "decorum-players",
						children: p.players.map((e, t) => /* @__PURE__ */ u("div", {
							className: "decorum-player",
							"data-active": p.active === e.rid,
							"data-self": e.rid === s,
							children: [
								/* @__PURE__ */ l("i", { children: t + 1 }),
								/* @__PURE__ */ u("div", { children: [/* @__PURE__ */ l("b", { children: D(e.rid) }), /* @__PURE__ */ l("small", { children: e.character === String(t + 1) ? f("games.decorum.roommate", { n: t + 1 }) : e.character })] }),
								/* @__PURE__ */ l("span", {
									title: f(e.fulfilled ? "games.decorum.fulfilled" : "games.decorum.unfulfilled"),
									children: e.fulfilled ? "✓" : "○"
								})
							]
						}, e.rid))
					})
				]
			}),
			children: /* @__PURE__ */ u("div", {
				className: "decorum-layout",
				children: [
					/* @__PURE__ */ u("details", {
						className: "decorum-rack",
						open: S,
						onToggle: (e) => C(e.currentTarget.open),
						children: [/* @__PURE__ */ l("summary", { children: /* @__PURE__ */ l(Z, {
							name: "rack",
							children: f("games.decorum.inventory")
						}) }), /* @__PURE__ */ u("div", {
							className: "decorum-rack-body",
							children: [
								q.map((e, t) => /* @__PURE__ */ u("section", { children: [/* @__PURE__ */ l("h2", { children: f(e) }), /* @__PURE__ */ l("div", {
									className: "decorum-supply-row",
									children: Array.from({ length: 4 }, (e, n) => {
										let r = t * 4 + n, i = 4 - p.rooms.flatMap((e) => e.slots).filter((e) => e === r).length;
										return /* @__PURE__ */ u("button", {
											type: "button",
											disabled: !O || i === 0,
											"data-selected": O && h?.type === "object" && h.object === r,
											onClick: () => {
												y(null), g({
													type: "object",
													object: r
												});
											},
											"aria-label": Y(f, r),
											children: [/* @__PURE__ */ l(Z, {
												name: `supply:${r}`,
												children: /* @__PURE__ */ l(X, { object: r })
											}), /* @__PURE__ */ l("small", { children: i })]
										}, r);
									})
								})] }, e)),
								/* @__PURE__ */ u("section", { children: [/* @__PURE__ */ l("h2", { children: f("games.decorum.paint") }), /* @__PURE__ */ l("div", {
									className: "decorum-paints",
									children: K.map((e, t) => /* @__PURE__ */ l("button", {
										type: "button",
										disabled: !O,
										style: { background: G[t] },
										"data-selected": O && h?.type === "paint" && h.color === t,
										onClick: () => {
											y(null), g({
												type: "paint",
												color: t
											});
										},
										"aria-label": f(e),
										children: /* @__PURE__ */ l("span", { children: f(e) })
									}, e))
								})] }),
								w.hasPets && /* @__PURE__ */ u("section", { children: [/* @__PURE__ */ l("h2", { children: f("games.decorum.pet") }), /* @__PURE__ */ l("div", {
									className: "decorum-supply-row",
									children: J.map((e, t) => /* @__PURE__ */ u("button", {
										type: "button",
										disabled: !O || p.rooms.reduce((e, n) => e + n.pets[t], 0) >= 8,
										onClick: () => {
											y(null), g({
												type: "addPet",
												pet: t
											});
										},
										"aria-label": f(e),
										children: [/* @__PURE__ */ l(Z, {
											name: `supply-pet:${t}`,
											children: /* @__PURE__ */ l(X, { pet: t })
										}), /* @__PURE__ */ l("small", { children: f(e) })]
									}, e))
								})] })
							]
						})]
					}),
					/* @__PURE__ */ u("main", {
						className: "decorum-main",
						children: [
							/* @__PURE__ */ u("div", {
								className: "decorum-phase",
								role: "status",
								children: [/* @__PURE__ */ l("strong", { children: ne }), O && h && /* @__PURE__ */ l("button", {
									type: "button",
									onClick: () => g(null),
									children: f("games.decorum.cancel")
								})]
							}),
							/* @__PURE__ */ l(Se, {
								pub: p,
								nameOf: D,
								controls: O ? {
									slot: I,
									wall: L,
									pet: R,
									roommate: (e) => {
										p.roommates[T] !== e && y({
											type: "roommate",
											room: e
										});
									},
									targets: F,
									selected: V || void 0
								} : void 0
							}),
							O && h && /* @__PURE__ */ l("p", {
								className: "decorum-selection-note",
								children: h.type === "gift" ? f("games.decorum.chooseTarget") : h.type === "pet" || h.type === "addPet" || h.type === "paint" ? f("games.decorum.chooseRoom") : f("games.decorum.chooseObject")
							}),
							/* @__PURE__ */ u("div", {
								className: "decorum-response",
								children: [
									z ? [
										"positive",
										"neutral",
										"negative"
									].map((e) => /* @__PURE__ */ l("button", {
										type: "button",
										onClick: () => P({
											type: "comment",
											mood: e
										}),
										children: f({
											positive: "games.decorum.positive",
											negative: "games.decorum.negative",
											neutral: "games.decorum.neutral"
										}[e])
									}, e)) : p.phase === "early" && E && !p.earlyVotes.includes(s) ? /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("button", {
										type: "button",
										onClick: () => P({
											type: "vote",
											agree: !0
										}),
										children: f("games.decorum.agree")
									}), /* @__PURE__ */ l("button", {
										type: "button",
										onClick: () => P({
											type: "vote",
											agree: !1
										}),
										children: f("games.decorum.decline")
									})] }) : O && E.fulfilled ? /* @__PURE__ */ l("button", {
										type: "button",
										onClick: () => P({ type: "pass" }),
										children: f("games.decorum.pass")
									}) : null,
									p.comments.filter((e) => e.turn === p.turn).map((e) => /* @__PURE__ */ l("span", { children: f("games.decorum.commentFrom", {
										name: D(e.rid),
										comment: f({
											positive: "games.decorum.positive",
											negative: "games.decorum.negative",
											neutral: "games.decorum.neutral"
										}[e.mood])
									}) }, e.rid)),
									p.lastChange?.forbidden && /* @__PURE__ */ l("p", { children: f("games.decorum.forbidden") })
								]
							}),
							O && p.hearts === (p.players.length === 2 ? 3 : 5) && /* @__PURE__ */ l("button", {
								className: "decorum-early",
								type: "button",
								onClick: () => P({ type: "earlyMeeting" }),
								children: f("games.decorum.earlyMeeting")
							}),
							/* @__PURE__ */ u("details", {
								className: "decorum-history",
								children: [/* @__PURE__ */ u("summary", { children: [
									f("games.decorum.actionLog"),
									" · ",
									p.history.length
								] }), /* @__PURE__ */ l("ol", { children: p.history.slice().reverse().map((e, t) => /* @__PURE__ */ u("li", { children: [
									f("games.decorum.changed", { name: D(e.by) }),
									" · ",
									Te(f, e.move, w.hasRoommates),
									e.forbidden && ` · ${f("games.decorum.forbidden")}`
								] }, t)) })]
							}),
							te && /* @__PURE__ */ u("div", {
								className: "decorum-picker",
								role: "dialog",
								"aria-modal": "false",
								"aria-label": f(_.type === "paint" ? "games.decorum.paint" : _.type === "pet" ? "games.decorum.pet" : _.type === "roommate" ? "games.decorum.moveRoom" : "games.decorum.inventory"),
								children: [
									/* @__PURE__ */ u("header", { children: [/* @__PURE__ */ l("strong", { children: Q(f, _.room, w.hasRoommates) }), /* @__PURE__ */ l("button", {
										type: "button",
										onClick: () => y(null),
										children: f("games.decorum.close")
									})] }),
									_.type === "object" && /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("div", {
										className: "decorum-picker-options",
										children: Array.from({ length: 4 }, (e, t) => v[_.room][_.slot] * 4 + t).map((e) => /* @__PURE__ */ u("button", {
											type: "button",
											disabled: !N({
												type: "object",
												room: _.room,
												slot: _.slot,
												object: e
											}),
											onClick: () => P({
												type: "object",
												room: _.room,
												slot: _.slot,
												object: e
											}),
											children: [/* @__PURE__ */ l(X, { object: e }), /* @__PURE__ */ l("small", { children: Y(f, e) })]
										}, e))
									}), p.rooms[_.room].slots[_.slot] !== null && /* @__PURE__ */ l("button", {
										className: "decorum-remove",
										type: "button",
										onClick: () => P({
											type: "object",
											room: _.room,
											slot: _.slot,
											object: null
										}),
										children: f("games.decorum.remove")
									})] }),
									_.type === "paint" && /* @__PURE__ */ l("div", {
										className: "decorum-picker-options decorum-picker-colors",
										children: K.map((e, t) => /* @__PURE__ */ l("button", {
											type: "button",
											style: { background: G[t] },
											disabled: !N({
												type: "paint",
												room: _.room,
												color: t
											}),
											onClick: () => P({
												type: "paint",
												room: _.room,
												color: t
											}),
											children: f(e)
										}, e))
									}),
									_.type === "pet" && /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("div", {
										className: "decorum-picker-options",
										children: [_.pet ^ 1, _.pet ^ 2].map((e) => /* @__PURE__ */ u("button", {
											type: "button",
											disabled: !N({
												type: "pet",
												room: _.room,
												pet: _.pet,
												toRoom: _.room,
												toPet: e
											}),
											onClick: () => P({
												type: "pet",
												room: _.room,
												pet: _.pet,
												toRoom: _.room,
												toPet: e
											}),
											children: [/* @__PURE__ */ l(X, { pet: e }), /* @__PURE__ */ l("small", { children: f(J[e]) })]
										}, e))
									}), /* @__PURE__ */ u("div", {
										className: "decorum-picker-actions",
										children: [/* @__PURE__ */ l("button", {
											type: "button",
											onClick: () => {
												g({
													type: "pet",
													room: _.room,
													pet: _.pet
												}), y(null);
											},
											children: f("games.decorum.movePet")
										}), /* @__PURE__ */ l("button", {
											type: "button",
											onClick: () => P({
												type: "pet",
												room: _.room,
												pet: _.pet,
												toRoom: null,
												toPet: null
											}),
											children: f("games.decorum.removePet")
										})]
									})] }),
									_.type === "roommate" && M.filter((e) => e.type === "roommate").map((e) => /* @__PURE__ */ l("button", {
										type: "button",
										onClick: () => P(e),
										children: e.kick === null ? f("games.decorum.noKick") : f("games.decorum.kick", { name: D(p.players[e.kick].rid) })
									}, String(e.kick)))
								]
							})
						]
					}),
					m && /* @__PURE__ */ u("aside", {
						className: "decorum-private",
						children: [
							/* @__PURE__ */ u("div", {
								className: "decorum-condition-card",
								children: [
									/* @__PURE__ */ u("header", { children: [
										/* @__PURE__ */ l("b", { children: E.character === String(T + 1) ? D(s) : E.character }),
										/* @__PURE__ */ l("h2", { children: f("games.decorum.conditionsTitle") }),
										/* @__PURE__ */ l("span", { children: f("games.decorum.satisfiedCount", {
											n: m.conditions.filter((e) => e.met).length,
											total: m.conditions.length
										}) })
									] }),
									/* @__PURE__ */ l("ul", { children: m.conditions.map((e) => /* @__PURE__ */ u("li", {
										"data-met": e.met,
										children: [/* @__PURE__ */ l("span", {
											className: "decorum-condition-check",
											"aria-label": f(e.met ? "games.decorum.met" : "games.decorum.notMet"),
											children: e.met ? "✓" : "○"
										}), /* @__PURE__ */ u("div", { children: [
											/* @__PURE__ */ l("p", { children: f(k[e.id].key) }),
											B && !m.sharedThisMeeting && /* @__PURE__ */ l("button", {
												type: "button",
												onClick: () => x(e.id),
												children: f("games.decorum.share")
											}),
											B && p.players.length > 2 && m.given.some((t) => t.condition === e.id) && /* @__PURE__ */ l("button", {
												type: "button",
												onClick: () => P({
													type: "recall",
													condition: e.id
												}),
												children: f("games.decorum.recall")
											}),
											m.given.filter((t) => t.condition === e.id).map((e) => /* @__PURE__ */ l("small", { children: f("games.decorum.sharedWith", { name: D(e.to) }) }, e.to))
										] })]
									}, e.id)) }),
									B && b && !m.sharedThisMeeting && /* @__PURE__ */ u("div", {
										className: "decorum-recipients",
										children: [p.players.filter((e) => e.rid !== s).map((e) => /* @__PURE__ */ l("button", {
											type: "button",
											onClick: () => P({
												type: "share",
												condition: b,
												to: e.rid
											}),
											children: f("games.decorum.shareTo", { name: D(e.rid) })
										}, e.rid)), /* @__PURE__ */ l("button", {
											type: "button",
											onClick: () => x(null),
											children: f("games.decorum.cancel")
										})]
									}),
									B && m.sharedThisMeeting && /* @__PURE__ */ l("button", {
										className: "decorum-primary",
										type: "button",
										onClick: () => P({ type: "finishSharing" }),
										children: f("games.decorum.finishSharing")
									}),
									p.phase === "meeting" && E.meetingDone && /* @__PURE__ */ l("p", { children: f("games.decorum.meetingWait") })
								]
							}),
							m.ban !== null && /* @__PURE__ */ u("section", {
								className: "decorum-ban",
								children: [/* @__PURE__ */ l("h2", { children: f("games.decorum.specialRule") }), /* @__PURE__ */ l("p", { children: f(m.ban === 2 ? "games.decorum.banLamp" : "games.decorum.banCurio") })]
							}),
							(p.players.length === 2 ? p.publicShared : m.shared).filter((e) => e.owner !== s).length > 0 && /* @__PURE__ */ u("section", {
								className: "decorum-shared",
								children: [/* @__PURE__ */ l("h2", { children: f("games.decorum.sharedTitle") }), (p.players.length === 2 ? p.publicShared : m.shared).filter((e) => e.owner !== s).map((e) => /* @__PURE__ */ u("article", { children: [/* @__PURE__ */ l("small", { children: f("games.decorum.conditionFrom", { name: D(e.owner) }) }), /* @__PURE__ */ l("p", { children: f(k[e.condition].key) })] }, `${e.owner}:${e.condition}`))]
							})
						]
					})
				]
			})
		})
	});
}
function Te(e, t, n) {
	if (t.type === "pass") return e("games.decorum.pass");
	if (t.type === "roommate") return e("games.decorum.moveRoom");
	let r = Q(e, t.room, n);
	return t.type === "paint" ? e("games.decorum.logPaint", {
		room: r,
		color: e(K[t.color])
	}) : t.type === "object" ? e(t.object === null ? "games.decorum.logRemove" : "games.decorum.logObject", {
		room: r,
		object: t.object === null ? e(q[v[t.room][t.slot]]) : Y(e, t.object)
	}) : t.type === "gift" ? e("games.decorum.logMove", {
		object: e("games.decorum.gift"),
		room: r,
		to: Q(e, t.toRoom, n)
	}) : t.type === "addPet" ? e("games.decorum.logObject", {
		room: r,
		object: e(J[t.pet])
	}) : t.toRoom === null ? e("games.decorum.logRemove", {
		room: r,
		object: e(J[t.pet])
	}) : t.toRoom === t.room ? e("games.decorum.logObject", {
		room: r,
		object: e(J[t.toPet])
	}) : e("games.decorum.logMove", {
		object: e(J[t.pet]),
		room: r,
		to: Q(e, t.toRoom, n)
	});
}
//#endregion
//#region src/games/decorum/bot.ts
var Ee = {
	sharedWeight: .9,
	visitPenalty: .22,
	dislikePenalty: .6
}, De = (e) => {
	let t = 2166136261;
	for (let n of e) t = Math.imul(t ^ n.charCodeAt(0), 16777619);
	return t >>> 0;
}, Oe = (e) => JSON.stringify([e.rooms, e.roommates]);
function ke(e, t, n) {
	let r = e.players.findIndex((e) => e.rid === n), i = [...t.conditions.map((e) => ({
		id: e.id,
		seat: r,
		own: !0
	})), ...[...t.shared, ...e.publicShared].map((t) => ({
		id: t.condition,
		seat: e.players.findIndex((e) => e.rid === t.owner),
		own: t.owner === n
	}))];
	return i.filter((e, t) => i.findIndex((t) => t.id === e.id && t.seat === e.seat) === t);
}
function Ae(e, t, n) {
	return t.reduce((t, r) => t + (k[r.id].test(new O(e, r.seat)) ? r.own ? 1 : n : 0), 0);
}
function je(e = Ee) {
	return ({ public: t, private: n }, r) => {
		if (!n || t.phase === "done") return null;
		let i = t.players.findIndex((e) => e.rid === r.rid), a = t.players[i], o = r.memory, s = {
			salt: o?.salt ?? De(r.rid),
			seen: o?.seen ?? [],
			lastTurn: o?.lastTurn ?? -1,
			disliked: o?.disliked ?? []
		};
		if (t.phase === "early") return t.earlyVotes.includes(r.rid) ? null : {
			action: {
				type: "vote",
				agree: !0
			},
			memory: s
		};
		if (t.phase === "meeting") {
			if (a.meetingDone) return null;
			if (n.sharedThisMeeting) return {
				action: { type: "finishSharing" },
				memory: s
			};
			let e = n.conditions.filter((e) => !n.given.some((t) => t.condition === e.id)), o = (e.find((e) => !e.met) ?? e[0] ?? n.conditions.find((e) => !e.met) ?? n.conditions[0]).id, c = t.players[(i + 1 + Math.floor(t.round / 5)) % t.players.length].rid;
			return {
				action: {
					type: "share",
					condition: o,
					to: c === r.rid ? t.players[(i + 1) % t.players.length].rid : c
				},
				memory: s
			};
		}
		if (t.phase === "comment") {
			if (t.active === r.rid || a.commented) return null;
			let e = n.conditions.filter((e) => e.met).length, o = t.previous ? n.conditions.filter((e) => k[e.id].test(new O(t.previous, i))).length : e;
			return {
				action: {
					type: "comment",
					mood: e > o ? "positive" : e < o ? "negative" : "neutral"
				},
				memory: s
			};
		}
		if (t.active !== r.rid) return null;
		let c = Oe(t);
		s.lastTurn !== t.turn && (t.lastChange?.by === r.rid && t.comments.some((e) => e.turn === t.turn && e.mood === "negative") && s.disliked.push(c), s.seen.push(c), s.seen = s.seen.slice(-24), s.lastTurn = t.turn);
		let l = A.find((e) => e.id === t.scenario), u = j(t, {
			hasPets: l.hasPets,
			hasRoommates: l.hasRoommates,
			canPass: a.fulfilled,
			seat: i
		}).filter((e) => n.ban === null || N(t, e) !== n.ban), d = ke(t, n, r.rid), f = u[0], p = -Infinity;
		for (let n of u) {
			let a = M(t, n, i), o = Oe(a), c = r.difficulty === "weak", l = Ae(a, d, c ? 0 : e.sharedWeight) - (c ? 0 : e.visitPenalty) * s.seen.filter((e) => e === o).length - (c ? 0 : e.dislikePenalty) * +!!s.disliked.includes(o) + (n.type === "pass" ? .01 : 0) + De(`${s.salt}:${t.turn}:${JSON.stringify(n)}`) % 1e3 / 1e6;
			l > p && (p = l, f = n);
		}
		return {
			action: f,
			memory: s
		};
	};
}
var Me = je();
//#endregion
//#region src/games/decorum/fx.tsx
function $({ at: e, object: r, pet: i, ms: a, enter: o = !1 }) {
	let s = n(null);
	return t(() => {
		let e = s.current?.animate([{
			opacity: +!o,
			transform: o ? "scale(.85)" : "scale(1)"
		}, {
			opacity: +!!o,
			transform: o ? "scale(1)" : "scale(.85)"
		}], {
			duration: a,
			easing: "ease-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, [o, a]), /* @__PURE__ */ l("div", {
		ref: s,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ l(X, {
			object: r,
			pet: i
		})
	});
}
function Ne({ at: e, color: r }) {
	let i = n(null);
	return t(() => {
		let e = i.current?.animate([
			{ clipPath: "inset(0 100% 0 0)" },
			{
				clipPath: "inset(0 0 0 0)",
				offset: .7
			},
			{ opacity: 0 }
		], {
			duration: 520,
			easing: "ease-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, []), /* @__PURE__ */ l("div", {
		ref: i,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			background: G[r],
			border: "2px solid white"
		}
	});
}
var Pe = {
	"decorum-forbidden": (e, t) => {
		let n = e.data, r = t.anchor(`wall:${n.room}`);
		return r ? {
			ms: 420,
			node: /* @__PURE__ */ l(f, {
				at: r,
				ms: 420
			})
		} : null;
	},
	"decorum-change": (e, t) => {
		let n = e.data, r = n.move, i = t.queued ? 180 : 420, a = (e, n, r, a, o = !0) => {
			let s = t.anchor(e), c = t.anchor(n), u = s && s.w > 0 ? s : t.anchor("rack");
			if (!u || !c) {
				let e = u ?? c;
				return e ? {
					ms: i,
					hide: c && !t.queued ? [n] : [],
					node: /* @__PURE__ */ l($, {
						at: e,
						object: r,
						pet: a,
						ms: i,
						enter: !!c
					})
				} : null;
			}
			let f = c.w > 0 ? c.h / c.w : 1, p = {
				...u,
				y: u.y + (u.h - u.w * f) / 2,
				h: u.w * f
			};
			return {
				ms: i,
				hide: o && !t.queued ? [n] : [],
				node: /* @__PURE__ */ l(d, {
					from: p,
					to: c,
					ms: i,
					children: /* @__PURE__ */ l("div", {
						style: {
							width: p.w,
							height: p.h
						},
						children: /* @__PURE__ */ l(X, {
							object: r,
							pet: a
						})
					})
				})
			};
		};
		if (r.type === "paint") {
			let e = t.anchor(`wall:${r.room}`);
			return e ? {
				ms: 520,
				node: /* @__PURE__ */ l(Ne, {
					at: e,
					color: r.color
				})
			} : null;
		}
		if (r.type === "object") {
			let e = n.before[r.room].slots[r.slot];
			if (r.object === null) return e === null ? null : a(`slot:${r.room}:${r.slot}`, `supply:${e}`, e, void 0, !1);
			let o = a(`supply:${r.object}`, `slot:${r.room}:${r.slot}`, r.object), s = t.anchor(`slot:${r.room}:${r.slot}`);
			return o && e !== null && s ? {
				...o,
				node: /* @__PURE__ */ u(c, { children: [o.node, /* @__PURE__ */ l($, {
					at: s,
					object: e,
					ms: Math.min(i, 260)
				})] })
			} : o;
		}
		if (r.type === "gift") return a(`slot:${r.room}:${r.slot}`, `slot:${r.toRoom}:${r.toSlot}`, 12);
		if (r.type === "addPet") return a(`supply-pet:${r.pet}`, `pet:${r.room}:${r.pet}`, void 0, r.pet);
		if (r.type === "pet") {
			if (r.toRoom === null) return a(`pet:${r.room}:${r.pet}`, `supply-pet:${r.pet}`, void 0, r.pet, !1);
			if (r.toRoom === r.room) {
				let e = t.anchor(`pet:${r.room}:${r.pet}`), n = t.anchor(`pet:${r.room}:${r.toPet}`);
				return e && n ? {
					ms: i,
					hide: t.queued ? [] : [`pet:${r.room}:${r.toPet}`],
					node: /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l($, {
						at: e,
						pet: r.pet,
						ms: i
					}), /* @__PURE__ */ l($, {
						at: n,
						pet: r.toPet,
						ms: i,
						enter: !0
					})] })
				} : null;
			}
			return a(`pet:${r.room}:${r.pet}`, `pet:${r.toRoom}:${r.toPet}`, void 0, r.pet);
		}
		if (r.type === "roommate") {
			let a = [n.players.indexOf(e.rid), ...r.kick === null ? [] : [r.kick]], o = [], s = a.map((e) => {
				let r = n.players[e], a = t.anchor(`roommates:${n.roommates[e]}`), s = t.anchor(`roommate:${r}`);
				if (!a || !s) return null;
				let c = n.roommates.slice(0, e).filter((t) => t === n.roommates[e]).length, f = {
					x: a.x + c * (a.w / 2 + 2),
					y: a.y,
					w: s.w,
					h: s.h
				};
				return o.push(`roommate:${r}`), /* @__PURE__ */ l(d, {
					from: f,
					to: s,
					ms: i,
					children: /* @__PURE__ */ u("div", {
						className: "decorum-roommate",
						style: {
							width: s.w,
							height: s.h,
							maxWidth: "none"
						},
						children: [/* @__PURE__ */ l("span", { children: e + 1 }), /* @__PURE__ */ l("small", { children: t.member(r)?.name ?? r })]
					})
				}, r);
			});
			return {
				ms: i,
				hide: t.queued ? [] : o,
				node: /* @__PURE__ */ l(c, { children: s })
			};
		}
		return null;
	}
};
//#endregion
//#region src/games/decorum/game-over.tsx
function Fe(e) {
	let t = i(), n = e.public, [a, o] = r(!1), [s, d] = r(!1), [f, p] = r(0), m = A.find((e) => e.id === n.scenario), h = n.revealed.flatMap((e) => e.conditions), g = n.revealed[f], _ = (t) => e.members.find((e) => e.rid === t)?.name ?? t, v = +n.scenario.slice(1), y = v < (n.players.length === 2 ? 20 : 10);
	return /* @__PURE__ */ u("div", {
		className: "decorum-ending",
		"data-review": a,
		children: [
			/* @__PURE__ */ l("header", {
				className: "decorum-ending-top",
				children: /* @__PURE__ */ l("b", { children: "DÉCORUM" })
			}),
			/* @__PURE__ */ u("div", {
				className: "decorum-ending-body",
				children: [/* @__PURE__ */ l("div", {
					className: "decorum-ending-house",
					children: /* @__PURE__ */ l(Se, {
						pub: n,
						nameOf: _
					})
				}), !a && /* @__PURE__ */ u("div", {
					className: "decorum-ending-info",
					children: [
						/* @__PURE__ */ l("h1", { children: t(n.won ? "games.decorum.success" : "games.decorum.failure") }),
						/* @__PURE__ */ u("p", { children: [
							t(m.titleKey),
							" · ",
							t("games.decorum.round", { n: n.round })
						] }),
						/* @__PURE__ */ l("p", { children: t("games.decorum.score") }),
						/* @__PURE__ */ l("div", {
							className: "decorum-score",
							children: n.score
						}),
						/* @__PURE__ */ u("p", { children: [
							t("games.decorum.satisfiedCount", {
								n: h.filter((e) => e.met).length,
								total: h.length
							}),
							" · ",
							h.filter((e) => e.met).length * 3
						] }),
						/* @__PURE__ */ l("p", { children: t("games.decorum.heartBonus", { n: n.bonus }) }),
						/* @__PURE__ */ u("div", {
							className: "decorum-result-buttons",
							children: [/* @__PURE__ */ l("button", {
								type: "button",
								onClick: () => d(!s),
								children: t("games.decorum.revealAll")
							}), /* @__PURE__ */ l("button", {
								type: "button",
								onClick: () => o(!0),
								children: t("games.decorum.reviewHouse")
							})]
						}),
						s && /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("div", {
							className: "decorum-result-tabs",
							children: n.revealed.map((e, t) => /* @__PURE__ */ l("button", {
								type: "button",
								"aria-pressed": t === f,
								onClick: () => p(t),
								children: _(e.rid)
							}, e.rid))
						}), g && /* @__PURE__ */ u("div", {
							className: "decorum-condition-card",
							children: [/* @__PURE__ */ u("header", { children: [/* @__PURE__ */ l("b", { children: _(g.rid) }), /* @__PURE__ */ l("span", { children: t("games.decorum.satisfiedCount", {
								n: g.conditions.filter((e) => e.met).length,
								total: g.conditions.length
							}) })] }), /* @__PURE__ */ l("ul", { children: g.conditions.map((e) => /* @__PURE__ */ u("li", {
								"data-met": e.met,
								children: [/* @__PURE__ */ l("span", {
									className: "decorum-condition-check",
									"aria-label": t(e.met ? "games.decorum.met" : "games.decorum.notMet"),
									children: e.met ? "✓" : "○"
								}), /* @__PURE__ */ l("p", { children: t(k[e.id].key) })]
							}, e.id)) })]
						})] })
					]
				})]
			}),
			/* @__PURE__ */ u("footer", {
				className: "decorum-ending-controls",
				children: [
					a && /* @__PURE__ */ l("button", {
						type: "button",
						onClick: () => o(!1),
						children: t("games.decorum.reviewConditions")
					}),
					e.onPlayAgain && /* @__PURE__ */ l("button", {
						type: "button",
						onClick: e.onPlayAgain,
						children: t("games.decorum.replay")
					}),
					e.onPlayAgainWithConfig && y && /* @__PURE__ */ l("button", {
						type: "button",
						onClick: () => e.onPlayAgainWithConfig?.(n.players.length === 2 ? { campaign: v + 1 } : { multiplayer: v + 1 }),
						children: t("games.decorum.nextScenario")
					}),
					e.onBackToLobby && /* @__PURE__ */ l("button", {
						type: "button",
						onClick: e.onBackToLobby,
						children: t("games.decorum.back")
					}),
					!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ l("p", { children: t("games.decorum.waitingHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/decorum/options.tsx
function Ie({ value: e, onChange: t }) {
	let n = i(), r = R.safeParse(e), a = r.success ? r.data : R.parse(void 0);
	return /* @__PURE__ */ u("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ l("p", { children: n("games.decorum.scenarioForPlayers") }), ["campaign", "multiplayer"].map((e) => /* @__PURE__ */ l(m, {
			title: n(e === "campaign" ? "games.decorum.campaign" : "games.decorum.multiplayer"),
			columns: 2,
			children: A.filter((t) => t.id.startsWith(e === "campaign" ? "c" : "m")).map((r, i) => /* @__PURE__ */ l(p, {
				name: `decorum-${e}`,
				value: r.id,
				checked: a[e] === i + 1,
				label: `${i + 1}. ${n(r.titleKey)}`,
				accent: h.accent,
				onChange: () => t({
					...a,
					[e]: i + 1
				})
			}, r.id))
		}, e))]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/decorum/entry.tsx
var Le = {
	definition: ge,
	View: Ce,
	bot: Me,
	fx: Pe,
	OverView: Fe,
	Options: Ie,
	locales: {
		zh: {
			name: "同房异梦",
			desc: "藏起自己的装修条件，在有限交流中共同布置一个让所有人满意的家。",
			rules: "目标：\n共同布置四个房间，满足每位玩家的所有私有条件。基础版包含双人20关战役及三、四人10个独立场景。每条条件按卡面完整的一项计算，其中的多个要求必须同时满足。\n准备：\n按所选场景布置墙色、物件、礼物、宠物与室友位置。两人使用双人战役，三至四人使用多人场景。三人局将第四位玩家的三条条件依次分给前三位玩家。自己的条件不能向其他人透露，定期交流时除外。\n流程：\n从第一位玩家开始，每回合进行一次行动：向对应空槽添加一件物件、移除一件物件、把一件物件换成同类型的另一种，或重漆一个房间。不能直接交换两个房间的物件或墙色。只有自己的所有条件已经满足时才能跳过。\n物件只有十二种固定组合，每种最多四件。\n· 台灯：现代蓝、古典黄、复古红、奇异绿。\n· 壁饰：现代红、古典绿、复古蓝、奇异黄。\n· 摆件：现代绿、古典蓝、复古黄、奇异红。\n红、黄为暖色，绿、蓝为冷色。墙面有颜色但没有类型或风格。\n行动后检查满足情况，其他玩家用积极、消极或中立回应。回应可以表示妥协，不要求与条件变化完全一致；不能解释自己的条件或给出额外提示。多人局可以选择中立作为不发表意见。所有人满意时共同获胜。\n交流：\n双人局在第15、20、25轮结束后各交流一次，每人向对方公开自己的一条条件。多人局每5轮交流一次，共5次；每人选择自己的一条条件私下分享给另一人。以后交流可以收回已经分享的条件并交给别人，不能转分享他人的条件。第一次交流前，全体可以一致同意提前交流，但会失去跳过的轮数。\n特殊场景：\n· 礼物占用任意一类物件槽，计为物件，但没有颜色、类型或风格。礼物不能增加或移除；一次行动可以把一份礼物移到任意空槽。\n· 宠物不占物件槽，分大猫、小猫、大狗、小狗，每种最多八只；一次行动可以添加、移除或移动一只宠物，也可以换成同种不同大小或同大小不同种的宠物。\n· 有室友标记的场景中，一次行动可以将自己移到另一间卧室。另一间已有两人时必须选择一人换到原房；只有一人时可以选择换人或直接入住。第20关中，Spencer不能增减或更换台灯，Blake不能增减或更换摆件；违反时撤销变动但消耗行动，跳过回应。\n位置与计分：\n保留各房间三个物件槽的左右顺序。“最左、最右”忽略空槽；“紧邻”不忽略空槽。礼物参与物件和占用槽位数量，宠物不计为物件。所有人在任意一次行动后满足全部条件即获胜，否则最多30轮后结束。每条满足的条件获得3分；全员条件全部满足时，每个剩余交流爱心获得2分。",
			campaign: "双人战役",
			multiplayer: "三至四人场景",
			scenario: "场景",
			scenarioForPlayers: "场景随实际人数使用对应组别。",
			round: "第 {{n}} / 30 轮",
			hearts: "剩余交流 {{n}} 次",
			turn: "轮到 {{name}} 布置",
			reactPrompt: "回应这次改变",
			meeting: "交流时间",
			meetingWait: "等待室友分享条件",
			conditionsTitle: "我的条件",
			sharedTitle: "已分享的条件",
			fulfilled: "全部满足",
			unfulfilled: "尚未全部满足",
			positive: "我喜欢",
			negative: "我不喜欢",
			neutral: "我可以接受",
			pass: "跳过行动",
			inventory: "物件架",
			paint: "墙色",
			lamp: "台灯",
			hanging: "壁饰",
			curio: "摆件",
			gift: "礼物",
			pet: "宠物",
			empty: "空槽",
			remove: "移除物件",
			moveGift: "移动礼物",
			movePet: "移动宠物",
			removePet: "移除宠物",
			sharedWith: "已分享给 {{name}}",
			logPaint: "将{{room}}漆成{{color}}",
			logObject: "在{{room}}放置{{object}}",
			logRemove: "从{{room}}移除{{object}}",
			logMove: "将{{object}}从{{room}}移到{{to}}",
			swapPet: "更换宠物",
			chooseTarget: "请选择目标空槽",
			chooseRoom: "请选择目标房间",
			chooseObject: "选择物件，再点击房间的对应槽位",
			cancel: "取消",
			myRoom: "我的卧室",
			moveRoom: "搬入这间卧室",
			kick: "与 {{name}} 交换卧室",
			noKick: "直接入住",
			share: "分享这条条件",
			shareTo: "分享给 {{name}}",
			recall: "收回这条条件",
			recallDone: "已收回",
			finishSharing: "完成分享",
			earlyMeeting: "提议提前交流",
			agree: "同意提前交流",
			decline: "继续布置",
			earlyPending: "室友提议提前交流",
			conditionsSecret: "条件仅自己可见，交流时才能分享。",
			revealAll: "查看全部条件",
			success: "终于像个家了",
			failure: "还需要一点默契",
			score: "共同得分",
			satisfiedCount: "已满足 {{n}} / {{total}} 条条件",
			heartBonus: "爱心奖励 {{n}} 分",
			replay: "再试一次",
			nextScenario: "下一场景",
			back: "返回大厅",
			waitingHost: "等待主机继续",
			reviewHouse: "回看房间",
			reviewConditions: "查看条件",
			close: "关闭",
			roommate: "室友 {{n}}",
			objectName: "{{color}} · {{style}} · {{type}}",
			petCount: "{{pet}} × {{n}}",
			selected: "已选择",
			forbidden: "这次行动违反了本关的禁令，行动已消耗。",
			specialRule: "本关禁令",
			banLamp: "你不能增加、移除或更换台灯。",
			banCurio: "你不能增加、移除或更换摆件。",
			actionLog: "布置记录",
			changed: "{{name}} 完成了一次布置",
			met: "已满足",
			notMet: "未满足",
			conditionFrom: "{{name}} 的条件",
			commentFrom: "{{name}}：{{comment}}",
			errTurn: "现在不能执行这个行动。",
			errAction: "这个位置不能进行所选操作。",
			errShare: "只能在交流时分享自己的条件。",
			errPass: "满足自己的全部条件后才能跳过。",
			errStock: "物件架中没有足够的物件或宠物。",
			errVote: "现在不能发起或回应提前交流。",
			room0: "浴室",
			room1: "卧室",
			room2: "客厅",
			room3: "厨房",
			bedroomA: "卧室 A",
			bedroomB: "卧室 B",
			red: "红色",
			yellow: "黄色",
			green: "绿色",
			blue: "蓝色",
			modern: "现代",
			antique: "古典",
			retro: "复古",
			unusual: "奇异",
			smallCat: "小猫",
			bigCat: "大猫",
			smallDog: "小狗",
			bigDog: "大狗",
			conditions: {
				c1p1q1: "左侧的两个房间都必须漆成蓝色。",
				c1p1q2: "全屋必须至少有一盏黄色古典台灯。",
				c1p1q3: "厨房内不能有物件。",
				c1p2q1: "左侧的两个房间都不能有台灯。",
				c1p2q2: "全屋最多只能有一件古典风格的物件。",
				c1p2q3: "楼下必须至少有两件物件。",
				c2p1q1: "每个房间最多只能有一种物件风格。",
				c2p1q2: "全屋必须包含全部四种物件风格。",
				c2p1q3: "全屋必须包含全部三类物件。",
				c2p1q4: "楼下必须有一间黄色房间和一间绿色房间。",
				c2p2q1: "每个房间内的物件只能有一种颜色。",
				c2p2q2: "全屋必须包含全部四种颜色的物件。",
				c2p2q3: "全屋必须有红、黄、绿、蓝四种墙色各一间。",
				c2p2q4: "全屋必须至少有一件绿色古典壁饰。",
				c3p1q1: "每个房间必须至少有一件复古风格的物件。",
				c3p1q2: "每个房间的墙色必须与房内至少一件复古物件的颜色相同。",
				c3p1q3: "全屋必须包含全部三种复古物件。",
				c3p1q4: "楼下不能有现代风格的物件。",
				c3p2q1: "同一个房间内不能有两件风格相同的物件。",
				c3p2q2: "左侧的两个房间都不能有台灯。",
				c3p2q3: "每个房间必须至少有一件绿色物件。",
				c3p2q4: "右侧的两个房间都必须漆成红色。",
				c4p1q1: "全屋必须包含全部三种蓝色物件。",
				c4p1q2: "楼下的每个房间都必须比其正上方房间的物件更多。",
				c4p1q3: "红、黄、绿、蓝每种颜色都必须至少出现两次，物件和墙色均计入。",
				c4p1q4: "楼上不能出现暖色，物件和墙色均计入。",
				c4p2q1: "每个房间内的颜色都不能重复，物件和墙色均计入。",
				c4p2q2: "全屋必须包含全部三种奇异风格的物件。",
				c4p2q3: "楼下不能有台灯。",
				c4p2q4: "左右两侧都必须包含全部四种颜色，物件和墙色均计入。",
				c5p1q1: "右侧两间房必须使用冷色墙面，左侧两间房必须使用暖色墙面。",
				c5p1q2: "所有台灯都必须是暖色，所有壁饰都必须是冷色。",
				c5p1q3: "全屋必须包含全部四种颜色的物件。",
				c5p1q4: "至少两个房间内的物件必须各自只有一种颜色，两间房的颜色可以不同。",
				c5p2q1: "暖色墙面的房间只能放冷色物件，冷色墙面的房间只能放暖色物件。",
				c5p2q2: "全屋必须恰好有四件暖色物件和四件冷色物件。",
				c5p2q3: "全屋每一种已经出现的摆件都必须恰好有两件。",
				c5p2q4: "全屋不能有现代风格的物件。",
				c6p1q1: "每个房间只有中间的物件槽可以空置。",
				c6p1q2: "红色和绿色都必须至少出现三次，物件和墙色均计入。",
				c6p1q3: "全屋至少一半的物件必须是奇异风格。",
				c6p1q4: "全屋的台灯数量与壁饰数量必须相等。",
				c6p2q1: "每一层从左到右的物件风格必须依次为古典、现代、复古、奇异，可以重复或缺少风格。",
				c6p2q2: "每间红色墙面的房间最多只能有一件物件。",
				c6p2q3: "蓝色和黄色都必须至少出现四次，物件和墙色均计入。",
				c6p2q4: "物件槽全部放满的房间必须包含全部四种颜色，墙色计入。",
				c7p1q1: "全屋必须恰好有十件物件。",
				c7p1q2: "全屋必须包含全部四种墙色。",
				c7p1q3: "客厅必须有一盏黄色古典台灯。",
				c7p1q4: "全屋暖色与冷色的出现次数必须相等，物件和墙色均计入。",
				c7p2q1: "浴室内不能有壁饰或摆件。",
				c7p2q2: "每个房间必须有一盏与墙色相同的台灯。",
				c7p2q3: "楼上只能出现冷色，物件和墙色均计入。",
				c7p2q4: "全屋不能有类型、颜色、风格完全相同的重复物件。",
				c8p1q1: "必须恰好有一间或三间蓝色墙面的房间。",
				c8p1q2: "有摆件的房间必须使用红色墙面，红色墙面的房间也必须有摆件。",
				c8p1q3: "楼上必须有奇数件蓝色物件。",
				c8p1q4: "全屋不能出现绿色，物件和墙色均计入。",
				c8p2q1: "必须恰好有两间或四间红色墙面的房间。",
				c8p2q2: "每个房间必须恰好包含一种或三种颜色，物件和墙色均计入。",
				c8p2q3: "全屋必须有奇数件黄色物件。",
				c8p2q4: "全屋必须有奇数盏台灯。",
				c9p1q1: "同一个房间内不能同时有台灯和壁饰。",
				c9p1q2: "每一层必须至少有一盏台灯。",
				c9p1q3: "每一层必须包含全部四种颜色，物件和墙色均计入。",
				c9p1q4: "左右两侧都必须包含全部四种颜色，物件和墙色均计入。",
				c9p1q5: "左右两侧都必须各有一间黄色房间和一间蓝色房间。",
				c9p2q1: "每个房间必须使用暖色墙面，或至少有一盏台灯。",
				c9p2q2: "每一层必须至少有一件壁饰。",
				c9p2q3: "厨房与浴室的物件和墙色必须完全相同。",
				c9p2q4: "每一层必须包含全部四种物件风格。",
				c9p2q5: "左右两侧都必须包含全部四种物件风格。",
				c10p1q1: "必须恰好有一间黄色墙面的房间，三种黄色物件也必须各有一件。",
				c10p1q2: "厨房最多只能有一种物件风格。",
				c10p1q3: "每个房间内暖色的出现次数都不能少于冷色，物件和墙色均计入。",
				c10p1q4: "每个房间必须有一盏台灯。",
				c10p2q1: "卧室内不能有黄色物件。",
				c10p2q2: "有黄色物件的房间必须也有蓝色物件。",
				c10p2q3: "至少两间房间必须使用冷色墙面。",
				c10p2q4: "全屋必须恰好有一件绿色物件。",
				c11p1q1: "四个房间最左侧物件的颜色必须互不相同，空槽不计。",
				c11p1q2: "楼下必须恰好出现一次红色，其余都必须是冷色，物件和墙色均计入。",
				c11p1q3: "卧室必须使用红色墙面且恰好有一种物件风格，其余房间都必须恰好有两种风格。",
				c11p1q4: "全屋每一类物件槽都必须恰好空置一个。",
				c11p2q1: "四个房间最右侧物件的颜色必须互不相同，空槽不计。",
				c11p2q2: "每个房间的墙色必须与房内数量最多的物件颜色相同，最多的颜色不能并列。",
				c11p2q3: "楼上必须恰好出现一次绿色，其余都必须是暖色，物件和墙色均计入。",
				c11p2q4: "楼上不能有现代风格的物件，楼下不能有复古风格的物件。",
				c12p1q1: "所有礼物都必须放在同一层。",
				c12p1q2: "摆件槽内不能放礼物。",
				c12p1q3: "每个房间必须至少有一件与墙色相同的物件。",
				c12p1q4: "全屋最多只能有一件绿色物件。",
				c12p2q1: "所有礼物都必须放在同一类物件槽内。",
				c12p2q2: "有礼物的房间必须使用暖色墙面。",
				c12p2q3: "全屋已放置物件的槽位必须多于空槽。",
				c12p2q4: "全屋不能有古典、复古或奇异风格的物件。",
				c13p1q1: "三类物件槽中都必须至少有一个槽位放有礼物。",
				c13p1q2: "奇异风格的物件数量必须恰好是其他风格物件总数的两倍。",
				c13p1q3: "全屋绿色物件的数量与复古物件的数量必须相等。",
				c13p1q4: "每件物件的颜色都必须与所在房间的墙色不同。",
				c13p2q1: "每个房间最多只能有一份礼物。",
				c13p2q2: "每个房间的中间槽必须空置或放置绿色物件；其余槽位不能空置或放绿色物件，墙面也不能是绿色。",
				c13p2q3: "全屋必须包含全部四种颜色，物件和墙色均计入。",
				c13p2q4: "四个房间的墙色必须相同。",
				c14p1q1: "至少两个房间必须各自最多只有一份礼物。",
				c14p1q2: "全屋最多只能有两种物件风格。",
				c14p1q3: "全屋最多只能有一个空槽。",
				c14p1q4: "每个房间的墙色必须与对角房间中间槽内的物件颜色相同；该槽为空或放有礼物时，墙面必须是红色。",
				c14p2q1: "每份礼物的紧邻左侧或右侧必须还有一份礼物，忽略同层房间之间的内墙。",
				c14p2q2: "每个摆件槽必须空置、放置礼物，或放置红色奇异摆件。",
				c14p2q3: "全屋必须包含全部四种颜色的物件。",
				c14p2q4: "全屋必须包含全部四种墙色。",
				c14p2q5: "全屋必须至少有一件奇异物件和一件复古物件。",
				c15p1q1: "全屋必须恰好有一只小狗和一只大狗。",
				c15p1q2: "有宠物的房间不能出现红色，物件和墙色均计入。",
				c15p1q3: "每一层必须至少有一盏台灯。",
				c15p1q4: "有大狗的一层不能有其他宠物。",
				c15p1q5: "有宠物的房间不能有现代或奇异风格的物件。",
				c15p2q1: "全屋必须至少有一只小猫。",
				c15p2q2: "有宠物的房间不能有台灯。",
				c15p2q3: "全屋不能有类型、颜色、风格完全相同的重复物件。",
				c15p2q4: "全屋每一种物件风格都必须至少有两件。",
				c15p2q5: "每个房间必须至少出现一次绿色，物件和墙色均计入。",
				c16p1q1: "每个房间内的物件风格种数必须与宠物数量相等。",
				c16p1q2: "全屋绿色的出现次数必须恰好比宠物数量多一，物件和墙色均计入。",
				c16p1q3: "全屋小型宠物与大型宠物的数量必须相等。",
				c16p1q4: "有大狗的房间不能有小猫。",
				c16p1q5: "左右任何一侧都不能同时出现红色和蓝色，物件和墙色均计入。",
				c16p2q1: "左右两侧各自的空槽数量必须与该侧小型宠物数量相等。",
				c16p2q2: "全屋墙色的种数必须与大猫的数量相等。",
				c16p2q3: "每个房间必须至少有一件奇异风格的物件。",
				c16p2q4: "楼上和楼下都不能同时出现红色和蓝色，物件和墙色均计入。",
				c16p2q5: "每个房间必须至少有一只宠物。",
				c16p2q6: "全屋必须恰好有六只宠物。",
				c17p1q1: "红、黄、绿、蓝每种颜色的物件都必须至少有一次与猫同处一间房。",
				c17p1q2: "红、黄、绿、蓝每种颜色的物件都必须至少有一次与狗同处一间房。",
				c17p1q3: "全屋每种风格的物件都必须至少有两件，楼上不能出现绿色，物件和墙色均计入。",
				c17p1q4: "至少两间房必须有猫且没有狗，至少两间房必须恰好有三只宠物。",
				c17p1q5: "每个房间必须有一盏与墙色相同的台灯。",
				c17p1q6: "每个房间的大狗数量必须与该房间红色的出现次数相等，物件和墙色均计入。",
				c17p2q1: "每个房间内每有一对紧邻且放有物件的槽位，就必须至少有一只狗。",
				c17p2q2: "猫和狗只有在卧室内才能共处一间房。",
				c17p2q3: "每个房间必须恰好有一种物件风格，楼上不能有现代风格的物件。",
				c17p2q4: "全屋宠物总数必须是奇数，小型宠物数量必须是至少为二的偶数。",
				c17p2q5: "每个房间的猫数量必须与该房间蓝色的出现次数相等，物件和墙色均计入。",
				c18p1q1: "有猫的房间必须放满摆件槽，放满摆件槽的房间也必须有猫；摆件或礼物均可占槽。",
				c18p1q2: "有狗的房间必须放满壁饰槽，放满壁饰槽的房间也必须有狗；壁饰或礼物均可占槽。",
				c18p1q3: "每个房间最多只能有一种物件风格，礼物没有风格。",
				c18p1q4: "楼上的礼物必须比楼下多。",
				c18p2q1: "有大型宠物的房间不能有礼物。",
				c18p2q2: "至少一间房间内既没有礼物，也没有宠物。",
				c18p2q3: "全屋的猫必须比狗多。",
				c18p2q4: "全屋必须包含全部四种颜色的台灯。",
				c19p1q1: "宠物较多的一侧，两间房必须使用同一种暖色墙面；另一侧两间房必须使用同一种冷色墙面，两侧宠物数量不能相等。",
				c19p1q2: "全屋狗的数量必须与最右侧物件为礼物的房间数相等，空槽不计。",
				c19p1q3: "有奇异风格物件的房间必须使用绿色墙面。",
				c19p1q4: "全屋必须恰好有五只宠物。",
				c19p1q5: "有宠物的房间必须有复古物件，有复古物件的房间也必须有宠物。",
				c19p2q1: "全屋小型宠物的数量必须与最左侧物件为礼物的房间数相等，空槽不计。",
				c19p2q2: "最多只能有一间房间的宠物比礼物多。",
				c19p2q3: "楼下不能有古典物件或绿色；楼上的壁饰槽必须全部空置，也不能出现黄色。颜色均计入物件与墙色。",
				c19p2q4: "左右两侧都必须恰好各有一间物件槽全部放满的房间。",
				c19p2q5: "全屋的物件总数必须恰好比宠物数量多三，礼物计为物件。",
				c20p1q1: "没有礼物的房间不能有空槽。",
				c20p1q2: "每一层最多只能有两种物件风格。",
				c20p1q3: "每个房间的猫数量必须与该房间蓝色的出现次数相等，物件和墙色均计入。",
				c20p1q4: "有台灯的房间必须有大型宠物，全屋的台灯风格不能重复。",
				c20p1q5: "小型宠物与台灯的总数必须相等；楼下的台灯必须比楼上多，楼上的小型宠物必须比楼下多。",
				c20p2q1: "每一层都必须恰好包含三种颜色和三只宠物，物件和墙色均计入。",
				c20p2q2: "有摆件的房间必须有小型宠物。",
				c20p2q3: "有礼物的房间必须恰好有一只宠物，并同时包含暖色与冷色，物件和墙色均计入。",
				c20p2q4: "狗与摆件的总数必须相等；楼上的摆件必须比楼下多，楼下的狗必须比楼上多。",
				c20p2q5: "古典物件必须比其他每种风格都多；全屋必须包含全部四种颜色和全部四种物件风格。",
				m1p1q1: "每个房间必须恰好包含两种颜色，物件和墙色均计入。",
				m1p1q2: "全屋复古物件必须比其他每种风格的物件都多。",
				m1p1q3: "楼上与楼下的物件数量必须相等。",
				m1p2q1: "每个房间必须至少有两种物件风格。",
				m1p2q2: "全屋必须包含全部四种墙色。",
				m1p2q3: "全屋必须包含全部三种黄色物件。",
				m1p3q1: "全屋必须包含全部三种红色物件。",
				m1p3q2: "楼下不能出现蓝色，物件和墙色均计入。",
				m1p3q3: "全屋必须包含全部四种物件风格。",
				m1p4q1: "全屋必须包含全部四种壁饰。",
				m1p4q2: "每个房间必须至少出现一次红色，物件和墙色均计入。",
				m1p4q3: "全屋必须恰好有四个空槽。",
				m2p1q1: "楼上只能放古典风格的物件。",
				m2p1q2: "楼上或楼下至少有一层的两间房墙色相同。",
				m2p1q3: "全屋必须恰好有七件物件。",
				m2p2q1: "冷色墙面的房间必须比暖色墙面的房间多。",
				m2p2q2: "左侧与右侧不能出现类型、颜色、风格完全相同的物件。",
				m2p2q3: "全屋必须包含全部四种物件风格。",
				m2p3q1: "厨房必须使用红色墙面。",
				m2p3q2: "至少一间房间必须有三件蓝色物件。",
				m2p3q3: "全屋壁饰必须比其他每类物件都多。",
				m2p4q1: "全屋必须恰好有一件奇异风格的物件。",
				m2p4q2: "浴室必须使用蓝色墙面。",
				m2p4q3: "楼上与楼下的物件都不能与所在房间的墙色相同。",
				m3p1q1: "每件物件的颜色都必须与正上方或正下方房间的墙色不同。",
				m3p1q2: "有黄色物件的房间必须使用蓝色墙面，蓝色墙面的房间也必须有黄色物件。",
				m3p1q3: "全屋复古物件与古典物件的数量必须相等。",
				m3p2q1: "全屋必须包含全部四种摆件。",
				m3p2q2: "每件摆件的颜色都必须与其对角房间的墙色相同。",
				m3p2q3: "每件物件的正上方或正下方都必须有另一件物件，且两者风格必须不同。",
				m3p3q1: "每个房间必须恰好有一个空槽。",
				m3p3q2: "每个空槽的正上方或正下方也必须是空槽。",
				m3p3q3: "有绿色物件的房间必须使用红色墙面。",
				m3p4q1: "全屋必须包含全部三种现代物件。",
				m3p4q2: "全屋蓝色的出现次数必须比其他每种颜色都多，物件和墙色均计入。",
				m3p4q3: "有奇异风格物件的房间必须使用绿色墙面。",
				m4p1q1: "浴室内不能有复古风格的物件。",
				m4p1q2: "厨房内不能有空槽。",
				m4p1q3: "右侧的两个房间都不能有绿色物件。",
				m4p2q1: "每种物件风格的数量都必须是偶数，可以为零。",
				m4p2q2: "浴室内不能出现红色，物件和墙色均计入。",
				m4p2q3: "卧室内不能有空槽。",
				m4p3q1: "浴室内不能有空槽。",
				m4p3q2: "客厅内不能出现红色，物件和墙色均计入。",
				m4p3q3: "全屋四种颜色的出现次数必须相等，物件和墙色均计入。",
				m4p4q1: "客厅内不能有复古风格的物件。",
				m4p4q2: "全屋不能有绿色墙面。",
				m4p4q3: "右侧的两个房间都不能有古典风格的物件。",
				m5p1q1: "每个房间的物件从左到右必须依次为红、黄、绿、蓝，可以缺少或重复颜色。",
				m5p1q2: "全屋必须恰好有一件复古风格的物件。",
				m5p1q3: "每个房间必须有一盏台灯。",
				m5p2q1: "全屋最多只能有一件红色物件。",
				m5p2q2: "楼下的空槽必须比楼上多。",
				m5p2q3: "卧室与客厅必须至少有一种类型、颜色、风格完全相同的物件。",
				m5p3q1: "全屋必须恰好出现四次红色，物件和墙色均计入。",
				m5p3q2: "左侧的空槽必须比右侧多。",
				m5p3q3: "全屋古典物件与现代物件的数量必须相等。",
				m5p4q1: "左右两侧都最多只能有一件摆件。",
				m5p4q2: "每个房间的墙色都必须与浴室摆件或卧室壁饰的颜色相同。",
				m5p4q3: "全屋奇异物件与复古物件的数量必须相等。",
				m6p1q1: "你所在的卧室必须有一盏台灯。",
				m6p1q2: "你所在的卧室必须使用黄色墙面。",
				m6p1q3: "全屋必须包含全部四种摆件。",
				m6p2q1: "你所在的卧室只能放蓝色物件。",
				m6p2q2: "你所在的卧室必须恰好有三件物件。",
				m6p2q3: "全屋必须包含全部四种壁饰。",
				m6p3q1: "你所在的卧室必须至少有一件奇异风格的物件。",
				m6p3q2: "左侧的两个房间都不能有台灯。",
				m6p3q3: "楼上必须恰好有一件现代风格的物件。",
				m6p4q1: "全屋必须恰好有三件绿色物件。",
				m6p4q2: "全屋必须至少有两盏台灯。",
				m6p4q3: "你所在的卧室必须使用红色墙面。",
				m7p1q1: "你所在卧室的这一侧，物件必须比另一侧多。",
				m7p1q2: "每个房间必须至少包含三种颜色，物件和墙色均计入。",
				m7p1q3: "全屋绿色的出现次数必须比其他每种颜色都多，物件和墙色均计入。",
				m7p2q1: "你所在的卧室必须恰好有三件物件。",
				m7p2q2: "你所在卧室与客厅的墙色，都必须是全屋物件数量唯一最少的颜色。",
				m7p2q3: "全屋不能有类型、颜色、风格完全相同的重复物件。",
				m7p3q1: "全屋必须包含全部三种红色物件和全部三种黄色物件。",
				m7p3q2: "全屋现代物件必须比其他每种风格的物件都少。",
				m7p3q3: "每个房间必须至少出现一次红色，物件和墙色均计入。",
				m7p4q1: "至少一间房间必须包含全部四种颜色，物件和墙色均计入。",
				m7p4q2: "全屋暖色物件必须恰好比冷色物件多一件。",
				m7p4q3: "你所在的卧室必须有一件蓝色古典摆件。",
				m8p1q1: "从任意红色房间开始，顺时针的墙色必须依次为红、黄、绿、蓝，不能重复或缺少颜色。",
				m8p1q2: "你所在卧室正下方的房间不能有空槽。",
				m8p1q3: "全屋必须恰好有两件摆件。",
				m8p2q1: "从中间槽放有红色物件的房间开始，逆时针各房间中间槽的物件颜色必须依次为红、黄、绿、蓝，不能重复或缺少颜色。",
				m8p2q2: "你所在卧室的这一侧，绿色出现次数必须更多，物件数量必须更少；颜色计入物件和墙面。",
				m8p2q3: "全屋黄色物件必须比其他每种颜色的物件都多，古典物件也必须比其他每种风格都多。",
				m8p3q1: "从有红色台灯的房间开始，顺时针各房间的台灯必须依次为红、黄、绿、蓝，不能重复或缺少颜色。",
				m8p3q2: "只有你所在卧室的这一侧可以有复古物件，且这一侧必须至少有一件。",
				m8p3q3: "每个房间最多只能包含三种颜色，物件和墙色均计入。",
				m8p4q1: "楼上必须恰好有三种物件风格，楼下必须恰好有两种。",
				m8p4q2: "暖色墙面的房间不能有冷色摆件，冷色墙面的房间不能有暖色摆件。",
				m8p4q3: "楼下不能有蓝色物件。",
				m9p1q1: "你所在卧室的这一侧不能出现绿色，另一侧必须出现绿色，物件和墙色均计入。",
				m9p1q2: "另一间卧室必须有一件奇异风格的壁饰。",
				m9p1q3: "你所在卧室的古典物件必须比其他每间房间都多。",
				m9p2q1: "楼上与楼下的古典物件数量必须相等。",
				m9p2q2: "楼上必须包含全部四种物件风格。",
				m9p2q3: "全屋不能有红色物件。",
				m9p3q1: "全屋每一种已经出现的物件都必须恰好有两件。",
				m9p3q2: "全屋的现代物件都必须放在你所在卧室的这一侧，而且必须至少有一件。",
				m9p3q3: "你所在卧室正下方的房间必须恰好只有一种颜色，物件和墙色均计入。",
				m9p4q1: "你所在卧室正下方的房间只能出现暖色，物件和墙色均计入。",
				m9p4q2: "全屋不能有绿色物件。",
				m9p4q3: "全屋黄色与蓝色的出现次数必须相等，物件和墙色均计入。",
				m10p1q1: "你所在的卧室必须有复古物件和红色物件，一件物件可以同时满足两项。",
				m10p1q2: "楼上必须恰好有一盏台灯，楼上其他物件的风格都必须与这盏台灯不同。",
				m10p1q3: "每一层必须包含全部四种物件风格，全屋必须包含全部三种古典物件。",
				m10p2q1: "你所在的卧室必须恰好出现两次黄色，物件和墙色均计入。",
				m10p2q2: "你所在卧室内的物件风格不能重复。",
				m10p2q3: "全屋不能有类型、颜色、风格完全相同的重复物件，且至少一间房必须恰好有一种物件风格。",
				m10p3q1: "你所在卧室必须恰好有两种颜色，且各出现两次；另一间卧室不能出现这两种颜色。物件和墙色均计入。",
				m10p3q2: "全屋必须包含全部三种现代物件。",
				m10p3q3: "楼上与楼下的绿色出现次数必须相等，蓝色出现次数也必须相等，物件和墙色均计入。",
				m10p4q1: "至少一类物件必须包含全部四种风格，全屋墙面也必须包含全部四种颜色。",
				m10p4q2: "每一层的两个房间之间不能有相同风格的物件。",
				m10p4q3: "你所在的卧室必须有绿色物件和台灯，一件物件可以同时满足两项。"
			},
			scenarios: {
				c1: "欢迎回家",
				c2: "此生一次",
				c3: "摇滚生活",
				c4: "节拍之外",
				c5: "异性相吸",
				c6: "闹鬼的家",
				c7: "搬家入住",
				c8: "格格不入",
				c9: "孪生倒影",
				c10: "未雨绸缪",
				c11: "即兴合奏",
				c12: "礼尚往来",
				c13: "明星待遇",
				c14: "彼岸来礼",
				c15: "爱之猎犬",
				c16: "宠物计划",
				c17: "爱的幽灵",
				c18: "重新组队",
				c19: "时不我待",
				c20: "甜蜜的家",
				m1: "三人成众",
				m2: "同屋合住",
				m3: "越过界线",
				m4: "各站一边",
				m5: "远大前程",
				m6: "来来回回",
				m7: "有取有舍",
				m8: "慢慢来",
				m9: "奇怪室友",
				m10: "枕头大战"
			}
		},
		en: {
			name: "Décorum",
			desc: "Keep your decorating conditions secret and build a home that makes every housemate happy.",
			rules: "Goal:\nDecorate four rooms to fulfill every player's secret conditions. The base game includes a 20-scenario two-player campaign and 10 standalone scenarios for three or four players. Every complete bullet on a condition card is one condition, including all its clauses.\nSetup:\nUse the selected scenario's walls, objects, gifts, pets and roommate positions. Two players use the campaign; three or four use the standalone scenarios. With three players, give player four's three conditions to players one, two and three respectively. Keep conditions secret except during scheduled sharing.\nTurns:\nStarting with player one, make one change: add an object to its matching empty slot, remove an object, swap it for a different object of the same type, or repaint one room. Objects and wall colors may not be exchanged directly between rooms. You may pass only when all your own conditions are fulfilled.\nThere are twelve fixed object combinations, four copies of each.\n· Lamps: modern blue, antique yellow, retro red, unusual green.\n· Wall hangings: modern red, antique green, retro blue, unusual yellow.\n· Curios: modern green, antique blue, retro yellow, unusual red.\nRed and yellow are warm; green and blue are cool. Walls have color but no type or style.\nAfter an action, check fulfillment. Other players give a positive, negative or neutral response. A response may express compromise; it need not mechanically reflect a condition change. Do not explain conditions or give additional hints. In multiplayer, neutral can stand for not commenting. Everyone wins when all conditions are fulfilled.\nSharing:\nWith two players, hold a heart-to-heart after rounds 15, 20 and 25. Each player reveals one of their own conditions. With three or four players, hold a house meeting every five rounds, five times in total. Each player privately shares one own condition with one housemate. At later meetings you may recall cards and share them with someone else. Never pass on another player's conditions. Before the first meeting, all players may agree to meet early, losing the skipped rounds.\nSpecial scenarios:\n· Gifts occupy any object slot and count as objects, but have no color, type or style. They cannot be added or removed. Moving one gift to an empty slot takes one action.\n· Pets use no object slots. There are small cats, big cats, small dogs and big dogs, up to eight of each. One action adds, removes or moves one pet, or swaps one for the same species in another size or the same size in another species.\n· In roommate scenarios, one action moves your own token to the other bedroom. If it already holds two people, choose one to move back to your old bedroom. With one occupant, you may either swap with them or join them. In scenario 20, Spencer may not add, remove or swap lamps; Blake may not add, remove or swap curios. Breaking a ban undoes the change, consumes the action and skips comments.\nPosition and scoring:\nThe left-to-right order of slots matters. Leftmost and rightmost ignore empty slots; directly adjacent does not. Gifts count as objects and filled slots; pets are not objects. All players win as soon as every condition is fulfilled after an action. Otherwise play ends after at most 30 rounds. Score three points per fulfilled condition, plus two points per remaining heart if every condition is fulfilled.",
			campaign: "Two-player campaign",
			multiplayer: "Three / four players",
			scenario: "Scenario",
			scenarioForPlayers: "The actual player count selects the corresponding scenario group.",
			round: "Round {{n}} / 30",
			hearts: "{{n}} meetings left",
			turn: "{{name}} is decorating",
			reactPrompt: "Respond to this change",
			meeting: "Time to talk",
			meetingWait: "Waiting for housemates to share",
			conditionsTitle: "My conditions",
			sharedTitle: "Shared conditions",
			fulfilled: "Fulfilled",
			unfulfilled: "Not yet fulfilled",
			positive: "I love it",
			negative: "I dislike it",
			neutral: "I can accept it",
			pass: "Pass",
			inventory: "Object board",
			paint: "Wall color",
			lamp: "Lamp",
			hanging: "Wall hanging",
			curio: "Curio",
			gift: "Gift",
			pet: "Pet",
			empty: "Empty slot",
			remove: "Remove object",
			moveGift: "Move gift",
			movePet: "Move pet",
			removePet: "Remove pet",
			sharedWith: "Shared with {{name}}",
			logPaint: "Painted the {{room}} {{color}}",
			logObject: "Placed {{object}} in the {{room}}",
			logRemove: "Removed {{object}} from the {{room}}",
			logMove: "Moved {{object}} from the {{room}} to the {{to}}",
			swapPet: "Swap pet",
			chooseTarget: "Choose an empty target slot",
			chooseRoom: "Choose a destination room",
			chooseObject: "Select an object, then its matching room slot",
			cancel: "Cancel",
			myRoom: "My bedroom",
			moveRoom: "Move into this bedroom",
			kick: "Swap bedrooms with {{name}}",
			noKick: "Move in without swapping",
			share: "Share this condition",
			shareTo: "Share with {{name}}",
			recall: "Recall this condition",
			recallDone: "Recalled",
			finishSharing: "Finish sharing",
			earlyMeeting: "Propose an early meeting",
			agree: "Agree to meet early",
			decline: "Keep decorating",
			earlyPending: "A housemate proposes meeting early",
			conditionsSecret: "Only you can see your conditions until a meeting.",
			revealAll: "Show all conditions",
			success: "A place to call home",
			failure: "A little more compromise",
			score: "Shared score",
			satisfiedCount: "{{n}} / {{total}} conditions met",
			heartBonus: "Heart bonus: {{n}} points",
			replay: "Try again",
			nextScenario: "Next scenario",
			back: "Back to lobby",
			waitingHost: "Waiting for the host",
			reviewHouse: "Review house",
			reviewConditions: "Review conditions",
			close: "Close",
			roommate: "Housemate {{n}}",
			objectName: "{{color}} · {{style}} · {{type}}",
			petCount: "{{pet}} × {{n}}",
			selected: "Selected",
			forbidden: "That action broke this scenario’s ban. The turn is consumed.",
			specialRule: "Scenario ban",
			banLamp: "You may not add, remove or swap lamps.",
			banCurio: "You may not add, remove or swap curios.",
			actionLog: "Decorating history",
			changed: "{{name}} made a change",
			met: "Met",
			notMet: "Not met",
			conditionFrom: "{{name}}’s condition",
			commentFrom: "{{name}}: {{comment}}",
			errTurn: "You cannot do that right now.",
			errAction: "That action is not allowed at this location.",
			errShare: "Share only your own conditions during a meeting.",
			errPass: "Fulfill all your conditions before passing.",
			errStock: "The supply has no more of that object or pet.",
			errVote: "An early meeting cannot be proposed or voted on now.",
			room0: "Bathroom",
			room1: "Bedroom",
			room2: "Living room",
			room3: "Kitchen",
			bedroomA: "Bedroom A",
			bedroomB: "Bedroom B",
			red: "Red",
			yellow: "Yellow",
			green: "Green",
			blue: "Blue",
			modern: "Modern",
			antique: "Antique",
			retro: "Retro",
			unusual: "Unusual",
			smallCat: "Small cat",
			bigCat: "Big cat",
			smallDog: "Small dog",
			bigDog: "Big dog",
			conditions: {
				c1p1q1: "Each room on the left must be painted blue.",
				c1p1q2: "The house must contain at least one yellow antique lamp.",
				c1p1q3: "The kitchen must contain no objects.",
				c1p2q1: "The left side must contain no lamps.",
				c1p2q2: "The house must contain at most one antique object.",
				c1p2q3: "Downstairs must contain at least two objects.",
				c2p1q1: "Each room must contain at most one style.",
				c2p1q2: "The house must contain every style.",
				c2p1q3: "The house must contain every object type.",
				c2p1q4: "Downstairs must have a yellow room and a green room.",
				c2p2q1: "Each room may contain objects of only one color.",
				c2p2q2: "The house must contain objects of all four colors.",
				c2p2q3: "The house must have a room painted in each color.",
				c2p2q4: "The house must contain a green antique wall hanging.",
				c3p1q1: "Each room must contain a retro object.",
				c3p1q2: "Each wall must match a retro object in its room.",
				c3p1q3: "The house must contain every retro object.",
				c3p1q4: "Downstairs must contain no modern objects.",
				c3p2q1: "No room may contain two objects of the same style.",
				c3p2q2: "The left side must contain no lamps.",
				c3p2q3: "Each room must contain a green object.",
				c3p2q4: "Both rooms on the right must be painted red.",
				c4p1q1: "The house must contain every blue object.",
				c4p1q2: "Each downstairs room must have more objects than the room above it.",
				c4p1q3: "Every color must appear at least twice as objects or walls.",
				c4p1q4: "Upstairs must contain no warm features.",
				c4p2q1: "No color may repeat in a room, counting objects and walls.",
				c4p2q2: "The house must contain every unusual object.",
				c4p2q3: "Downstairs must contain no lamps.",
				c4p2q4: "Each side must contain all four colors as objects or walls.",
				c5p1q1: "Rooms on the right must have cool walls; rooms on the left must have warm walls.",
				c5p1q2: "Every lamp must be warm; every wall hanging must be cool.",
				c5p1q3: "The house must contain objects of all four colors.",
				c5p1q4: "At least two rooms must contain objects of exactly one color; the colors may differ.",
				c5p2q1: "Every object in a warm-walled room must be cool, and every object in a cool-walled room must be warm.",
				c5p2q2: "The house must contain exactly four warm and four cool objects.",
				c5p2q3: "Every specific curio present must appear exactly twice.",
				c5p2q4: "The house must contain no modern objects.",
				c6p1q1: "Only the middle slot of each room may be empty.",
				c6p1q2: "Red and green must each appear at least three times as objects or walls.",
				c6p1q3: "At least half of the objects must be unusual.",
				c6p1q4: "There must be equal numbers of lamps and wall hangings.",
				c6p2q1: "Objects on each floor, left to right across both rooms, must follow antique, modern, retro, unusual order; repeats and omissions are allowed.",
				c6p2q2: "Every red-walled room must contain at most one object.",
				c6p2q3: "Blue and yellow must each appear at least four times as objects or walls.",
				c6p2q4: "Every room with no empty slots must contain all four colors, counting walls.",
				c7p1q1: "The house must contain exactly ten objects.",
				c7p1q2: "The house must have all four wall colors.",
				c7p1q3: "The living room must contain a yellow antique lamp.",
				c7p1q4: "The house must contain equal numbers of warm and cool features.",
				c7p2q1: "The bathroom must contain no wall hangings or curios.",
				c7p2q2: "Every room must have a lamp matching its wall color.",
				c7p2q3: "Upstairs must contain only cool features.",
				c7p2q4: "No specific object may appear more than once.",
				c8p1q1: "An odd number of rooms, one or three, must have blue walls.",
				c8p1q2: "Curios and red walls are inseparable in each room.",
				c8p1q3: "Upstairs must contain an odd number of blue objects.",
				c8p1q4: "The house must contain no green objects or walls.",
				c8p2q1: "Exactly two or four rooms must have red walls.",
				c8p2q2: "Each room must contain an odd number of distinct colors, counting walls.",
				c8p2q3: "The house must contain an odd number of yellow objects.",
				c8p2q4: "The house must contain an odd number of lamps.",
				c9p1q1: "No room may contain both a lamp and a wall hanging.",
				c9p1q2: "Each floor must contain a lamp.",
				c9p1q3: "Each floor must contain all four colors as objects or walls.",
				c9p1q4: "Each side must contain all four colors as objects or walls.",
				c9p1q5: "Each side must have one yellow room and one blue room.",
				c9p2q1: "Each room must have warm walls or contain a lamp.",
				c9p2q2: "Each floor must contain a wall hanging.",
				c9p2q3: "The kitchen and bathroom must have identical objects and wall colors.",
				c9p2q4: "Each floor must contain every style.",
				c9p2q5: "Each side must contain every style.",
				c10p1q1: "Exactly one room must have yellow walls and each yellow object must appear exactly once.",
				c10p1q2: "The kitchen must contain at most one style.",
				c10p1q3: "Each room must contain at least as many warm features as cool features.",
				c10p1q4: "Each room must contain a lamp.",
				c10p2q1: "The bedroom must contain no yellow objects.",
				c10p2q2: "Every room with a yellow object must also contain a blue object.",
				c10p2q3: "At least two rooms must have cool walls.",
				c10p2q4: "The house must contain exactly one green object.",
				c11p1q1: "The leftmost objects of the four rooms must all have different colors.",
				c11p1q2: "Downstairs must contain red exactly once; all other features must be cool.",
				c11p1q3: "The bedroom must be red and have exactly one style; every other room must have exactly two styles.",
				c11p1q4: "Exactly one slot of each object type must be empty.",
				c11p2q1: "The rightmost objects of the four rooms must all have different colors.",
				c11p2q2: "Each wall must match the uniquely most common object color in that room.",
				c11p2q3: "Upstairs must contain green exactly once; all other features must be warm.",
				c11p2q4: "Upstairs must have no modern objects; downstairs must have no retro objects.",
				c12p1q1: "All gifts must be on the same floor.",
				c12p1q2: "Curio slots must contain no gifts.",
				c12p1q3: "Each room must have an object matching its wall color.",
				c12p1q4: "The house must contain at most one green object.",
				c12p2q1: "All gifts must occupy the same type of object slot.",
				c12p2q2: "Every room with a gift must have warm walls.",
				c12p2q3: "More slots must be filled than empty.",
				c12p2q4: "The house must contain no antique, retro, or unusual objects.",
				c13p1q1: "There must be at least one gift in each type of object slot.",
				c13p1q2: "There must be twice as many unusual objects as all other styles combined.",
				c13p1q3: "There must be equal numbers of green objects and retro objects.",
				c13p1q4: "No object may match its room's wall color.",
				c13p2q1: "Each room must contain at most one gift.",
				c13p2q2: "Every middle slot must be empty or contain a green object. Green features and empty slots may appear nowhere else.",
				c13p2q3: "The house must contain all four colors as objects or walls.",
				c13p2q4: "All four rooms must have the same wall color.",
				c14p1q1: "At least two rooms must each contain at most one gift.",
				c14p1q2: "The house must contain at most two styles.",
				c14p1q3: "The house must contain at most one empty slot.",
				c14p1q4: "Each wall must match the object in the diagonally opposite room's middle slot. If that slot is empty or a gift, the wall must be red.",
				c14p2q1: "Every gift must have another gift directly to its left or right, ignoring the interior wall.",
				c14p2q2: "Each curio slot must be empty, contain a gift, or contain a red unusual curio.",
				c14p2q3: "The house must contain objects of all four colors.",
				c14p2q4: "The house must have all four wall colors.",
				c14p2q5: "The house must contain an unusual object and a retro object.",
				c15p1q1: "The house must contain exactly one small dog and one big dog.",
				c15p1q2: "Rooms with pets must contain no red objects or walls.",
				c15p1q3: "Each floor must contain a lamp.",
				c15p1q4: "Any floor with a big dog must contain no other pets.",
				c15p1q5: "Rooms with pets must contain no modern or unusual objects.",
				c15p2q1: "The house must contain a small cat.",
				c15p2q2: "Rooms with pets must contain no lamps.",
				c15p2q3: "The house must contain no duplicate objects.",
				c15p2q4: "Each style must appear at least twice.",
				c15p2q5: "Each room must contain green as an object or wall.",
				c16p1q1: "In each room, the number of styles must equal the number of pets.",
				c16p1q2: "Green features must outnumber pets by exactly one.",
				c16p1q3: "There must be equal numbers of small and big pets.",
				c16p1q4: "A room with a big dog may not contain a small cat.",
				c16p1q5: "Neither side may contain both red and blue features.",
				c16p2q1: "On each side, the number of empty slots must equal the number of small pets.",
				c16p2q2: "The number of different wall colors must equal the number of big cats.",
				c16p2q3: "Each room must contain an unusual object.",
				c16p2q4: "Neither floor may contain both red and blue features.",
				c16p2q5: "Each room must contain a pet.",
				c16p2q6: "The house must contain exactly six pets.",
				c17p1q1: "Cats must share a room with objects of every color at least once each.",
				c17p1q2: "Dogs must share a room with objects of every color at least once each.",
				c17p1q3: "The house must contain at least two objects of every style, and upstairs must contain no green features.",
				c17p1q4: "At least two rooms must contain cats but no dogs, and at least two rooms must contain exactly three pets.",
				c17p1q5: "Each room must have a lamp matching its wall color.",
				c17p1q6: "Each room must contain exactly one big dog per red feature in that room.",
				c17p2q1: "Each room must contain at least one dog per adjacent pair of occupied object slots.",
				c17p2q2: "Cats and dogs may share a room only in the bedroom.",
				c17p2q3: "Each room must contain exactly one style, and upstairs must contain no modern objects.",
				c17p2q4: "There must be an odd number of pets and a positive even number of small pets.",
				c17p2q5: "Each room must contain exactly one cat per blue feature.",
				c18p1q1: "Cats and occupied curio slots are inseparable, whether occupied by a curio or gift.",
				c18p1q2: "Dogs and occupied wall-hanging slots are inseparable.",
				c18p1q3: "Each room must contain at most one style; gifts have no style.",
				c18p1q4: "There must be more gifts upstairs than downstairs.",
				c18p2q1: "Rooms with big pets must contain no gifts.",
				c18p2q2: "At least one room must contain neither gifts nor pets.",
				c18p2q3: "There must be more cats than dogs.",
				c18p2q4: "The house must contain a lamp in every color.",
				c19p1q1: "The side with more pets must have two walls in the same warm color; the other side must have two walls in the same cool color. Pet counts may not tie.",
				c19p1q2: "There must be as many dogs as rooms whose rightmost object is a gift.",
				c19p1q3: "Every room with an unusual object must have green walls.",
				c19p1q4: "The house must contain exactly five pets.",
				c19p1q5: "Pets and retro objects are inseparable in each room.",
				c19p2q1: "There must be as many small pets as rooms whose leftmost object is a gift.",
				c19p2q2: "At most one room may contain more pets than gifts.",
				c19p2q3: "Downstairs must have no antiques or green features; upstairs must have no filled wall-hanging slots or yellow features.",
				c19p2q4: "Each side must contain exactly one room with no empty slots.",
				c19p2q5: "There must be exactly three more objects than pets.",
				c20p1q1: "Rooms without gifts must have no empty slots.",
				c20p1q2: "Each floor must contain at most two styles.",
				c20p1q3: "Each room must contain exactly one cat per blue feature.",
				c20p1q4: "Rooms with lamps must have a big pet, and no lamp style may repeat in the house.",
				c20p1q5: "There must be equal numbers of small pets and lamps, more lamps downstairs, and more small pets upstairs.",
				c20p2q1: "Each floor must contain exactly three colors as objects or walls and exactly three pets.",
				c20p2q2: "Rooms with curios must contain a small pet.",
				c20p2q3: "Rooms with gifts must contain exactly one pet and both warm and cool features.",
				c20p2q4: "There must be as many dogs as curios, more curios upstairs, and more dogs downstairs.",
				c20p2q5: "Antiques must outnumber each other style; all four colors and all four styles must appear.",
				m1p1q1: "Each room must contain exactly two colors as objects or walls.",
				m1p1q2: "Retro objects must outnumber each other style.",
				m1p1q3: "Upstairs and downstairs must have equal numbers of objects.",
				m1p2q1: "Each room must contain at least two styles.",
				m1p2q2: "The house must have all four wall colors.",
				m1p2q3: "The house must contain all three yellow objects.",
				m1p3q1: "The house must contain all three red objects.",
				m1p3q2: "Downstairs must contain no blue features.",
				m1p3q3: "The house must contain all four styles.",
				m1p4q1: "The house must contain all four wall hangings.",
				m1p4q2: "Each room must contain red as an object or wall.",
				m1p4q3: "Exactly four object slots must be empty.",
				m2p1q1: "Upstairs may contain only antique objects.",
				m2p1q2: "At least one floor must have two rooms with the same wall color.",
				m2p1q3: "The house must contain exactly seven objects.",
				m2p2q1: "More rooms must have cool walls than warm walls.",
				m2p2q2: "No specific object on the left may also appear on the right.",
				m2p2q3: "The house must contain all four styles.",
				m2p3q1: "The kitchen must have red walls.",
				m2p3q2: "At least one room must contain three blue objects.",
				m2p3q3: "Wall hangings must outnumber each other object type.",
				m2p4q1: "There must be exactly one unusual object.",
				m2p4q2: "The bathroom must have blue walls.",
				m2p4q3: "No object on either floor may match its room's wall color.",
				m3p1q1: "Each object must differ in color from the wall of the room directly above or below it.",
				m3p1q2: "Yellow objects and blue walls are inseparable.",
				m3p1q3: "Retro and antique objects must be equally numerous.",
				m3p2q1: "The house must contain all four curios.",
				m3p2q2: "Each curio must match the diagonally opposite room's wall.",
				m3p2q3: "Every object must have an object directly above or below it, of a different style.",
				m3p3q1: "Each room must contain exactly one empty slot.",
				m3p3q2: "Each empty slot must have an empty slot directly above or below.",
				m3p3q3: "Rooms with green objects must have red walls.",
				m3p4q1: "The house must contain every modern object.",
				m3p4q2: "Blue features must outnumber each other color.",
				m3p4q3: "Rooms with unusual objects must have green walls.",
				m4p1q1: "The bathroom must contain no retro objects.",
				m4p1q2: "The kitchen must contain no empty slots.",
				m4p1q3: "The right side must contain no green objects.",
				m4p2q1: "Every style must appear an even number of times, including zero.",
				m4p2q2: "The bathroom must contain no red features.",
				m4p2q3: "The bedroom must contain no empty slots.",
				m4p3q1: "The bathroom must contain no empty slots.",
				m4p3q2: "The living room must contain no red features.",
				m4p3q3: "All four colors must appear equally often as objects or walls.",
				m4p4q1: "The living room must contain no retro objects.",
				m4p4q2: "There must be no green walls.",
				m4p4q3: "The right side must contain no antique objects.",
				m5p1q1: "Objects in each room must follow red, yellow, green, blue order from left to right; omissions and repeats are allowed.",
				m5p1q2: "There must be exactly one retro object.",
				m5p1q3: "Each room must contain a lamp.",
				m5p2q1: "There must be at most one red object.",
				m5p2q2: "Downstairs must have more empty slots than upstairs.",
				m5p2q3: "The bedroom and living room must share at least one identical object.",
				m5p3q1: "Red must appear exactly four times as objects or walls.",
				m5p3q2: "The left side must have more empty slots than the right.",
				m5p3q3: "Antique and modern objects must be equally numerous.",
				m5p4q1: "Each side must contain at most one curio.",
				m5p4q2: "Every wall must match the bathroom curio or the bedroom wall hanging.",
				m5p4q3: "Unusual and retro objects must be equally numerous.",
				m6p1q1: "Your room must contain a lamp.",
				m6p1q2: "Your room must have yellow walls.",
				m6p1q3: "The house must contain all four curios.",
				m6p2q1: "Your room may contain only blue objects.",
				m6p2q2: "Your room must contain exactly three objects.",
				m6p2q3: "The house must contain all four wall hangings.",
				m6p3q1: "Your room must contain an unusual object.",
				m6p3q2: "The left side must contain no lamps.",
				m6p3q3: "Upstairs must contain exactly one modern object.",
				m6p4q1: "There must be exactly three green objects.",
				m6p4q2: "The house must contain at least two lamps.",
				m6p4q3: "Your room must have red walls.",
				m7p1q1: "The side containing your room must have more objects than the other side.",
				m7p1q2: "Each room must contain at least three colors as objects or walls.",
				m7p1q3: "Green must outnumber each other color as objects or walls.",
				m7p2q1: "Your room must contain exactly three objects.",
				m7p2q2: "Your room and the living room must have walls in the uniquely least common object color.",
				m7p2q3: "No specific object may repeat.",
				m7p3q1: "The house must contain every red object and every yellow object.",
				m7p3q2: "There must be fewer modern objects than each other style.",
				m7p3q3: "Each room must contain red as an object or wall.",
				m7p4q1: "At least one room must contain all four colors as objects or walls.",
				m7p4q2: "There must be exactly one more warm object than cool objects.",
				m7p4q3: "Your room must contain a blue antique curio.",
				m8p1q1: "Walls must follow red, yellow, green, blue clockwise, with no repetitions or omissions.",
				m8p1q2: "The room directly below your room must have no empty slots.",
				m8p1q3: "There must be exactly two curios.",
				m8p2q1: "The middle-slot objects must follow red, yellow, green, blue counterclockwise, with no repetitions or omissions.",
				m8p2q2: "Your room's side must have strictly more green features and strictly fewer objects than the other side.",
				m8p2q3: "Yellow objects must outnumber each other color, and antiques must outnumber each other style.",
				m8p3q1: "Lamps must follow red, yellow, green, blue clockwise, with no repetitions or omissions.",
				m8p3q2: "Only your room's side may contain retro objects, and it must contain at least one.",
				m8p3q3: "Each room must contain at most three colors as objects or walls.",
				m8p4q1: "Upstairs must contain exactly three styles; downstairs exactly two.",
				m8p4q2: "Warm-walled rooms may not contain cool curios; cool-walled rooms may not contain warm curios.",
				m8p4q3: "Downstairs must contain no blue objects.",
				m9p1q1: "Your room's side must have no green features, and the other side must have green features.",
				m9p1q2: "The other bedroom must contain an unusual wall hanging.",
				m9p1q3: "Your room must have more antique objects than every other room.",
				m9p2q1: "Upstairs and downstairs must have equal numbers of antiques.",
				m9p2q2: "Upstairs must contain all four styles.",
				m9p2q3: "The house must contain no red objects.",
				m9p3q1: "Each specific object present must appear exactly twice.",
				m9p3q2: "Your room's side must contain every modern object in the house, and at least one must be present.",
				m9p3q3: "The room below your room must contain exactly one color, counting walls.",
				m9p4q1: "The room below your room must contain only warm features.",
				m9p4q2: "The house must contain no green objects.",
				m9p4q3: "Yellow and blue features must be equally numerous.",
				m10p1q1: "Your room must have a retro object and a red object; one object may satisfy both.",
				m10p1q2: "Upstairs must contain exactly one lamp; no other upstairs object may share its style.",
				m10p1q3: "Each floor must contain every style, and the house must contain every antique object.",
				m10p2q1: "Your room must contain yellow exactly twice as objects or walls.",
				m10p2q2: "No object style may repeat in your room.",
				m10p2q3: "The house must have no identical objects and at least one room with exactly one style.",
				m10p3q1: "Your room must contain exactly two colors, twice each; neither color may occur in the other bedroom, counting walls.",
				m10p3q2: "The house must contain every modern object.",
				m10p3q3: "Upstairs and downstairs must have equal amounts of green and equal amounts of blue.",
				m10p4q1: "One object type must appear in all four styles, and all four wall colors must appear.",
				m10p4q2: "On each floor, the two rooms may not share any object style.",
				m10p4q3: "Your room must contain a green object and a lamp; one object may satisfy both."
			},
			scenarios: {
				c1: "Welcome Home",
				c2: "Once in a Lifetime",
				c3: "Rock & Roll",
				c4: "Off Beat",
				c5: "Opposites Attract",
				c6: "Haunting House",
				c7: "Moving In",
				c8: "Mismatched",
				c9: "Splitting Image",
				c10: "Futureproofing",
				c11: "Jam Session",
				c12: "Present Company",
				c13: "Star Treatment",
				c14: "Gifts from Beyond",
				c15: "The Hounds of Love",
				c16: "Pet Projects",
				c17: "Spirit of Love",
				c18: "Banding Together",
				c19: "Out of Time",
				c20: "Home Sweet Home",
				m1: "Three’s a Crowd",
				m2: "Bunkin’",
				m3: "Cross the Line",
				m4: "Taking Sides",
				m5: "Great Expectations",
				m6: "Back & Forth",
				m7: "Give & Take",
				m8: "Take Your Time",
				m9: "Strange Bedfellows",
				m10: "Pillow Fight"
			}
		}
	}
};
//#endregion
export { Le as default };
