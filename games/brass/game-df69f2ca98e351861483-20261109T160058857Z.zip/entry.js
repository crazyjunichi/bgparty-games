import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { avatarNameAt as o, useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { playTurn as l, useSoundEdge as u } from "@bgparty/sdk/sfx";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { botAvatarOf as g } from "@bgparty/sdk/lobby";
import { ConfirmButton as _ } from "@bgparty/sdk/confirm-button";
import { IconClose as v, IconExpand as y, IconLog as b } from "@bgparty/sdk/icons";
//#region src/games/brass/data.ts
var x = (e, t, n, r, i, a, o, s, c, l, u, d = 0, f = 0, p = !1) => ({
	industry: e,
	level: t,
	count: n,
	canal: r,
	rail: i,
	cost: a,
	coal: o,
	iron: s,
	vp: c,
	income: l,
	links: u,
	beer: d,
	produce: f,
	noDevelop: p
}), S = [
	x("brewery", 1, 2, !0, !1, 5, 0, 1, 4, 4, 2),
	x("brewery", 2, 2, !0, !0, 7, 0, 1, 5, 5, 2),
	x("brewery", 3, 2, !0, !0, 9, 0, 1, 7, 5, 2),
	x("brewery", 4, 1, !1, !0, 9, 0, 1, 10, 5, 2),
	x("coal", 1, 1, !0, !1, 5, 0, 0, 1, 4, 2, 0, 2),
	x("coal", 2, 2, !0, !0, 7, 0, 0, 2, 7, 1, 0, 3),
	x("coal", 3, 2, !0, !0, 8, 0, 1, 3, 6, 1, 0, 4),
	x("coal", 4, 2, !0, !0, 10, 0, 1, 4, 5, 1, 0, 5),
	x("cotton", 1, 3, !0, !1, 12, 0, 0, 5, 5, 1, 1),
	x("cotton", 2, 2, !0, !0, 14, 1, 0, 5, 4, 2, 1),
	x("cotton", 3, 3, !0, !0, 16, 1, 1, 9, 3, 1, 1),
	x("cotton", 4, 3, !0, !0, 18, 1, 1, 12, 2, 1, 1),
	x("iron", 1, 1, !0, !1, 5, 1, 0, 3, 3, 1, 0, 4),
	x("iron", 2, 1, !0, !0, 7, 1, 0, 5, 3, 1, 0, 4),
	x("iron", 3, 1, !0, !0, 9, 1, 0, 7, 2, 1, 0, 5),
	x("iron", 4, 1, !0, !0, 12, 1, 0, 9, 1, 1, 0, 6),
	x("manufacturer", 1, 1, !0, !1, 8, 1, 0, 3, 5, 2, 1),
	x("manufacturer", 2, 2, !0, !0, 10, 0, 1, 5, 1, 1, 1),
	x("manufacturer", 3, 1, !0, !0, 12, 2, 0, 4, 4, 0, 0),
	x("manufacturer", 4, 1, !0, !0, 8, 0, 1, 3, 6, 1, 1),
	x("manufacturer", 5, 2, !0, !0, 16, 1, 0, 8, 2, 2, 2),
	x("manufacturer", 6, 1, !0, !0, 20, 0, 0, 7, 6, 1, 1),
	x("manufacturer", 7, 1, !0, !0, 16, 1, 1, 9, 4, 0, 0),
	x("manufacturer", 8, 2, !0, !0, 20, 0, 2, 11, 1, 1, 1),
	x("pottery", 1, 1, !0, !0, 17, 0, 1, 10, 5, 1, 1, 0, !0),
	x("pottery", 2, 1, !0, !0, 0, 1, 0, 1, 1, 1, 1),
	x("pottery", 3, 1, !0, !0, 22, 2, 0, 11, 5, 1, 2, 0, !0),
	x("pottery", 4, 1, !0, !0, 0, 1, 0, 1, 1, 1, 1),
	x("pottery", 5, 1, !1, !0, 24, 2, 0, 20, 5, 1, 2)
];
function C(e, t) {
	let n = S.find((n) => n.industry === e && n.level === t);
	if (!n) throw Error(`no tile ${e} ${t}`);
	return n;
}
function w(e) {
	return S.filter((t) => t.industry === e).flatMap((e) => Array(e.count).fill(e.level)).reverse();
}
var T = [
	{
		id: "belper",
		nameKey: "games.brass.city.belper",
		region: "derbyshire",
		slots: [
			["cotton", "manufacturer"],
			["coal"],
			["pottery"]
		],
		x: 725,
		y: 55
	},
	{
		id: "derby",
		nameKey: "games.brass.city.derby",
		region: "derbyshire",
		slots: [
			["cotton", "brewery"],
			["cotton", "manufacturer"],
			["iron"]
		],
		x: 745,
		y: 160
	},
	{
		id: "leek",
		nameKey: "games.brass.city.leek",
		region: "staffordshire",
		slots: [["cotton", "manufacturer"], ["cotton", "coal"]],
		x: 440,
		y: 45
	},
	{
		id: "stokeOnTrent",
		nameKey: "games.brass.city.stokeOnTrent",
		region: "staffordshire",
		slots: [
			["cotton", "manufacturer"],
			["pottery", "iron"],
			["manufacturer"]
		],
		x: 310,
		y: 110
	},
	{
		id: "stone",
		nameKey: "games.brass.city.stone",
		region: "staffordshire",
		slots: [["cotton", "brewery"], ["manufacturer", "coal"]],
		x: 195,
		y: 185
	},
	{
		id: "uttoxeter",
		nameKey: "games.brass.city.uttoxeter",
		region: "staffordshire",
		slots: [["manufacturer", "brewery"], ["cotton", "brewery"]],
		x: 475,
		y: 160
	},
	{
		id: "stafford",
		nameKey: "games.brass.city.stafford",
		region: "midlands",
		slots: [["manufacturer", "brewery"], ["pottery"]],
		x: 260,
		y: 270
	},
	{
		id: "burtonOnTrent",
		nameKey: "games.brass.city.burtonOnTrent",
		region: "midlands",
		slots: [["manufacturer", "coal"], ["brewery"]],
		x: 620,
		y: 280
	},
	{
		id: "cannock",
		nameKey: "games.brass.city.cannock",
		region: "midlands",
		slots: [["manufacturer", "coal"], ["coal"]],
		x: 350,
		y: 355
	},
	{
		id: "tamworth",
		nameKey: "games.brass.city.tamworth",
		region: "midlands",
		slots: [["cotton", "coal"], ["cotton", "coal"]],
		x: 635,
		y: 380
	},
	{
		id: "walsall",
		nameKey: "games.brass.city.walsall",
		region: "midlands",
		slots: [["iron", "manufacturer"], ["manufacturer", "brewery"]],
		x: 430,
		y: 430
	},
	{
		id: "wolverhampton",
		nameKey: "games.brass.city.wolverhampton",
		region: "blackCountry",
		slots: [["manufacturer"], ["manufacturer", "coal"]],
		x: 255,
		y: 425
	},
	{
		id: "coalbrookdale",
		nameKey: "games.brass.city.coalbrookdale",
		region: "blackCountry",
		slots: [
			["iron", "brewery"],
			["iron"],
			["coal"]
		],
		x: 110,
		y: 455
	},
	{
		id: "dudley",
		nameKey: "games.brass.city.dudley",
		region: "blackCountry",
		slots: [["coal"], ["iron"]],
		x: 295,
		y: 510
	},
	{
		id: "kidderminster",
		nameKey: "games.brass.city.kidderminster",
		region: "blackCountry",
		slots: [["cotton", "coal"], ["cotton"]],
		x: 195,
		y: 600
	},
	{
		id: "worcester",
		nameKey: "games.brass.city.worcester",
		region: "blackCountry",
		slots: [["cotton"], ["cotton"]],
		x: 210,
		y: 720
	},
	{
		id: "birmingham",
		nameKey: "games.brass.city.birmingham",
		region: "birmingham",
		slots: [
			["cotton", "manufacturer"],
			["manufacturer"],
			["iron"],
			["manufacturer"]
		],
		x: 530,
		y: 535
	},
	{
		id: "coventry",
		nameKey: "games.brass.city.coventry",
		region: "birmingham",
		slots: [
			["pottery"],
			["manufacturer", "coal"],
			["iron", "manufacturer"]
		],
		x: 750,
		y: 565
	},
	{
		id: "nuneaton",
		nameKey: "games.brass.city.nuneaton",
		region: "birmingham",
		slots: [["manufacturer", "brewery"], ["cotton", "coal"]],
		x: 710,
		y: 460
	},
	{
		id: "redditch",
		nameKey: "games.brass.city.redditch",
		region: "birmingham",
		slots: [["manufacturer", "coal"], ["iron"]],
		x: 490,
		y: 640
	}
], E = [
	{
		id: "shrewsbury",
		nameKey: "games.brass.city.shrewsbury",
		slots: 1,
		minPlayers: 2,
		bonus: {
			kind: "vp",
			amount: 4
		},
		x: 25,
		y: 360
	},
	{
		id: "gloucester",
		nameKey: "games.brass.city.gloucester",
		slots: 2,
		minPlayers: 2,
		bonus: {
			kind: "develop",
			amount: 1
		},
		x: 75,
		y: 790
	},
	{
		id: "oxford",
		nameKey: "games.brass.city.oxford",
		slots: 2,
		minPlayers: 2,
		bonus: {
			kind: "income",
			amount: 2
		},
		x: 610,
		y: 740
	},
	{
		id: "warrington",
		nameKey: "games.brass.city.warrington",
		slots: 2,
		minPlayers: 3,
		bonus: {
			kind: "money",
			amount: 5
		},
		x: 180,
		y: 15
	},
	{
		id: "nottingham",
		nameKey: "games.brass.city.nottingham",
		slots: 2,
		minPlayers: 4,
		bonus: {
			kind: "vp",
			amount: 3
		},
		x: 835,
		y: 95
	}
], D = [{
	id: "farmN",
	x: 385,
	y: 390
}, {
	id: "farmS",
	x: 175,
	y: 660
}], O = {
	2: [
		"blank",
		"blank",
		"any",
		"cotton",
		"manufacturer"
	],
	3: [
		"blank",
		"blank",
		"blank",
		"any",
		"cotton",
		"manufacturer",
		"pottery"
	],
	4: [
		"blank",
		"blank",
		"blank",
		"any",
		"cotton",
		"cotton",
		"manufacturer",
		"manufacturer",
		"pottery"
	]
}, k = (e, t, n = !0, r = !0) => ({
	id: e,
	nodes: t,
	canal: n,
	rail: r
}), A = [
	k("belper-derby", ["belper", "derby"]),
	k("belper-leek", ["belper", "leek"], !1, !0),
	k("birmingham-coventry", ["birmingham", "coventry"]),
	k("birmingham-dudley", ["birmingham", "dudley"]),
	k("birmingham-nuneaton", ["birmingham", "nuneaton"], !1, !0),
	k("birmingham-oxford", ["birmingham", "oxford"]),
	k("birmingham-redditch", ["birmingham", "redditch"], !1, !0),
	k("birmingham-tamworth", ["birmingham", "tamworth"]),
	k("birmingham-walsall", ["birmingham", "walsall"]),
	k("birmingham-worcester", ["birmingham", "worcester"]),
	k("burtonOnTrent-cannock", ["burtonOnTrent", "cannock"], !1, !0),
	k("burtonOnTrent-derby", ["burtonOnTrent", "derby"]),
	k("burtonOnTrent-stone", ["burtonOnTrent", "stone"]),
	k("burtonOnTrent-tamworth", ["burtonOnTrent", "tamworth"]),
	k("burtonOnTrent-walsall", ["burtonOnTrent", "walsall"], !0, !1),
	k("cannock-stafford", ["cannock", "stafford"]),
	k("cannock-farmN", ["cannock", "farmN"]),
	k("cannock-walsall", ["cannock", "walsall"]),
	k("cannock-wolverhampton", ["cannock", "wolverhampton"]),
	k("coalbrookdale-kidderminster", ["coalbrookdale", "kidderminster"]),
	k("coalbrookdale-shrewsbury", ["coalbrookdale", "shrewsbury"]),
	k("coalbrookdale-wolverhampton", ["coalbrookdale", "wolverhampton"]),
	k("coventry-nuneaton", ["coventry", "nuneaton"], !1, !0),
	k("derby-nottingham", ["derby", "nottingham"]),
	k("derby-uttoxeter", ["derby", "uttoxeter"], !1, !0),
	k("dudley-kidderminster", ["dudley", "kidderminster"]),
	k("dudley-wolverhampton", ["dudley", "wolverhampton"]),
	k("gloucester-redditch", ["gloucester", "redditch"]),
	k("gloucester-worcester", ["gloucester", "worcester"]),
	k("kidderminster-worcester", [
		"kidderminster",
		"farmS",
		"worcester"
	]),
	k("leek-stokeOnTrent", ["leek", "stokeOnTrent"]),
	k("nuneaton-tamworth", ["nuneaton", "tamworth"]),
	k("redditch-oxford", ["redditch", "oxford"]),
	k("stafford-stone", ["stafford", "stone"]),
	k("stokeOnTrent-stone", ["stokeOnTrent", "stone"]),
	k("stokeOnTrent-warrington", ["stokeOnTrent", "warrington"]),
	k("stone-uttoxeter", ["stone", "uttoxeter"], !1, !0),
	k("tamworth-walsall", ["tamworth", "walsall"], !1, !0),
	k("walsall-wolverhampton", ["walsall", "wolverhampton"])
];
function j(e) {
	let t = T.find((t) => t.id === e);
	if (t) return {
		x: t.x,
		y: t.y
	};
	let n = E.find((t) => t.id === e);
	if (n) return {
		x: n.x,
		y: n.y
	};
	let r = D.find((t) => t.id === e);
	if (r) return {
		x: r.x,
		y: r.y
	};
	throw Error(`no node ${e}`);
}
[...[
	,
	,
	,
	,
].fill({ kind: "wildLocation" }), ...[
	,
	,
	,
	,
].fill({ kind: "wildIndustry" })];
function M(e) {
	let t = (e, t) => Array(t).fill({
		kind: "location",
		city: e
	}), n = (e, t) => Array(t).fill({
		kind: "industry",
		industries: [e]
	}), r = (e) => Array(e).fill({
		kind: "industry",
		industries: ["cotton", "manufacturer"]
	}), i = [
		...t("stafford", 2),
		...t("burtonOnTrent", 2),
		...t("cannock", 2),
		...t("tamworth", 1),
		...t("walsall", 1),
		...t("coalbrookdale", 3),
		...t("dudley", 2),
		...t("kidderminster", 2),
		...t("wolverhampton", 2),
		...t("worcester", 2),
		...t("birmingham", 3),
		...t("coventry", 3),
		...t("nuneaton", 1),
		...t("redditch", 1)
	], a = [
		...n("iron", 4),
		...n("coal", 2),
		...n("pottery", 2),
		...n("brewery", 5)
	], o = 0;
	return e >= 3 && (i.push(...t("leek", 2), ...t("stokeOnTrent", 3), ...t("stone", 2), ...t("uttoxeter", 1)), o = 6), e >= 4 && (i.push(...t("belper", 2), ...t("derby", 3), ...t("uttoxeter", 1)), a.push(...n("coal", 1), ...n("pottery", 1)), o = 8), [
		...i,
		...a,
		...r(o)
	];
}
var N = [
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7
], P = [
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5
];
function F(e) {
	return e <= 10 ? e - 10 : e <= 30 ? 1 + Math.floor((e - 11) / 2) : e <= 60 ? 11 + Math.floor((e - 31) / 3) : e <= 96 ? 21 + Math.floor((e - 61) / 4) : 30;
}
function I(e) {
	return e <= 0 ? e + 10 : e <= 10 ? 2 * e + 10 : e <= 20 ? 3 * e - 2 : e <= 29 ? 4 * e - 20 : 99;
}
var ee = [
	"cotton",
	"manufacturer",
	"pottery"
], te = {
	id: "brass",
	tier: "alpha",
	mechanics: ["route-building"],
	interactionTags: [],
	nameKey: "games.brass.name",
	descKey: "games.brass.desc",
	rulesKey: "games.brass.rules",
	icon: "🏭",
	iconImg: "games/brass.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/brass/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	accent: "#8a5a2b",
	releasedAt: "2026-09-17",
	search: {
		py: "bo ming han",
		init: "bmh"
	},
	hotseat: "cover"
}, L = t.enum([
	"cotton",
	"manufacturer",
	"pottery",
	"brewery",
	"coal",
	"iron"
]), R = t.enum([
	"belper",
	"derby",
	"leek",
	"stokeOnTrent",
	"stone",
	"uttoxeter",
	"stafford",
	"burtonOnTrent",
	"cannock",
	"tamworth",
	"walsall",
	"wolverhampton",
	"coalbrookdale",
	"dudley",
	"kidderminster",
	"worcester",
	"birmingham",
	"coventry",
	"nuneaton",
	"redditch"
]), z = t.enum(["farmN", "farmS"]), B = t.enum([
	"shrewsbury",
	"gloucester",
	"oxford",
	"warrington",
	"nottingham"
]), V = t.union([t.object({
	city: R,
	slot: t.int().nonnegative()
}), t.object({ farm: z })]), ne = t.union([t.object({
	kind: t.literal("tile"),
	at: V
}), t.object({
	kind: t.literal("merchant"),
	index: t.int().nonnegative()
})]), H = t.int().nonnegative(), re = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("build"),
		card: H,
		at: V,
		industry: L.optional()
	}),
	t.object({
		type: t.literal("network"),
		card: H,
		links: t.array(t.string().min(1)).min(1).max(2),
		beerFrom: V.optional()
	}),
	t.object({
		type: t.literal("develop"),
		card: H,
		industries: t.array(L).min(1).max(2)
	}),
	t.object({
		type: t.literal("sell"),
		card: H,
		sales: t.array(t.object({
			tile: V,
			beers: t.array(ne)
		})).min(1),
		bonusDevelop: t.array(L).max(2).optional()
	}),
	t.object({
		type: t.literal("loan"),
		card: H
	}),
	t.object({
		type: t.literal("scout"),
		cards: t.tuple([
			H,
			H,
			H
		])
	}),
	t.object({
		type: t.literal("pass"),
		card: H
	}),
	t.object({
		type: t.literal("payDebt"),
		tiles: t.array(V).min(1)
	})
]), ie = t.union([
	t.object({
		kind: t.literal("location"),
		city: R
	}),
	t.object({
		kind: t.literal("industry"),
		industries: t.array(L).min(1).max(2)
	}),
	t.object({ kind: t.literal("wildLocation") }),
	t.object({ kind: t.literal("wildIndustry") })
]), ae = t.object({
	industry: L,
	level: t.int().min(1),
	owner: t.int().nonnegative(),
	flipped: t.boolean(),
	cubes: t.int().nonnegative()
}), oe = t.enum([
	"cotton",
	"manufacturer",
	"pottery",
	"any",
	"blank"
]), se = t.object({
	phase: t.enum(["play", "done"]),
	era: t.enum(["canal", "rail"]),
	round: t.int().min(1),
	order: t.array(t.int().nonnegative()),
	turnIdx: t.int().nonnegative(),
	actionsLeft: t.int().min(0),
	players: t.array(t.object({
		rid: t.string(),
		money: t.int(),
		incomeLevel: t.int(),
		vp: t.int(),
		linkStock: t.int().nonnegative(),
		handCount: t.int().nonnegative(),
		stacks: t.record(t.string(), t.array(t.int().min(1))),
		spent: t.int().nonnegative()
	})),
	board: t.record(t.string(), ae),
	links: t.record(t.string(), t.int().nonnegative()),
	merchants: t.array(t.object({
		location: B,
		buys: oe,
		beer: t.boolean()
	})),
	coalMarket: t.int().nonnegative(),
	ironMarket: t.int().nonnegative(),
	deckCount: t.int().nonnegative(),
	wilds: t.object({
		location: t.int().nonnegative(),
		industry: t.int().nonnegative()
	}),
	pendingDebt: t.array(t.object({
		rid: t.string(),
		need: t.int().min(1)
	})),
	eraScores: t.array(t.object({
		era: t.enum(["canal", "rail"]),
		rid: t.string(),
		industryVp: t.int(),
		linkVp: t.int()
	})).nullable(),
	winner: t.string().nullable()
}), U = t.object({ hand: t.array(ie) }), W = (e) => ({ code: e }), ce = (e) => "city" in e ? `${e.city}:${e.slot}` : `farm:${e.farm}`, G = (e) => "city" in e ? e.city : e.farm;
function le(t, n, r) {
	for (let i = t.length - 1; i > 0; i--) {
		let a = e(n, r, i + 1);
		r++, [t[i], t[a]] = [t[a], t[i]];
	}
	return r;
}
function K(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of A) if (e.links[n.id] !== void 0) for (let e of n.nodes) for (let r of n.nodes) e !== r && (t.has(e) || t.set(e, []), t.get(e).push(r));
	return t;
}
function ue(e, t) {
	let n = /* @__PURE__ */ new Map([[t, 0]]), r = [t];
	for (; r.length > 0;) {
		let t = r.shift();
		for (let i of e.get(t) ?? []) n.has(i) || (n.set(i, n.get(t) + 1), r.push(i));
	}
	return n;
}
function q(e, t) {
	let n = /* @__PURE__ */ new Set();
	for (let [r, i] of Object.entries(e.board)) i.owner === t && n.add(r.startsWith("farm:") ? r.slice(5) : r.split(":")[0]);
	for (let [r, i] of Object.entries(e.links)) {
		if (i !== t) continue;
		let e = A.find((e) => e.id === r);
		for (let t of e.nodes) n.add(t);
	}
	return n;
}
var de = (e, t) => Object.values(e.board).some((e) => e.owner === t) || Object.values(e.links).some((e) => e === t);
function fe(e, t) {
	t.flipped = !0, t.cubes = 0, e.incomeSpace[t.owner] = Math.min(99, e.incomeSpace[t.owner] + C(t.industry, t.level).income);
}
function J(e, t) {
	t.cubes--, t.cubes === 0 && fe(e, t);
}
var pe = (e, t, n) => t === 0 ? n : e[e.length - t];
function me(e, t, n, r) {
	let i = K(e);
	for (let a = 0; a < n; a++) {
		let n = ue(i, r), a = null, o = Infinity, s = !1;
		for (let [r, i] of Object.entries(e.board)) {
			if (i.industry !== "coal" || i.flipped || i.cubes === 0) continue;
			let e = r.split(":")[0], c = n.get(e);
			if (c === void 0) continue;
			let l = i.owner === t;
			(c < o || c === o && l && !s) && (a = r, o = c, s = l);
		}
		if (a) {
			J(e, e.board[a]);
			continue;
		}
		if (!E.some((e) => n.has(e.id))) return W("games.brass.errNoCoal");
		let c = pe(N, e.coalMarket, 8);
		if (e.money[t] < c) return W("games.brass.errCantAfford");
		e.money[t] -= c, e.spent[t] += c, e.coalMarket > 0 && e.coalMarket--;
	}
	return null;
}
function he(e, t, n) {
	for (let r = 0; r < n; r++) {
		let n = Object.entries(e.board).filter(([, e]) => e.industry === "iron" && !e.flipped && e.cubes > 0), r = n.find(([, e]) => e.owner === t) ?? n[0];
		if (r) {
			J(e, r[1]);
			continue;
		}
		let i = pe(P, e.ironMarket, 6);
		if (e.money[t] < i) return W("games.brass.errCantAfford");
		e.money[t] -= i, e.spent[t] += i, e.ironMarket > 0 && e.ironMarket--;
	}
	return null;
}
function ge(e, t, n, r) {
	if (n.industry !== "coal" && n.industry !== "iron") return;
	if (n.industry === "coal") {
		let t = ue(K(e), r);
		if (!E.some((e) => t.has(e.id))) return;
	}
	let i = n.industry === "coal" ? N : P;
	for (; n.cubes > 0;) {
		let r = n.industry === "coal" ? e.coalMarket : e.ironMarket;
		if (r >= i.length) break;
		let a = i[i.length - r - 1];
		e.money[t] += a, n.cubes--, n.industry === "coal" ? e.coalMarket++ : e.ironMarket++;
	}
	n.cubes === 0 && fe(e, n);
}
function Y(e, t, n) {
	let r = e.hands[e.players[t]], i = r[n];
	return i ? (r.splice(n, 1), i.kind === "wildLocation" ? e.wilds.location++ : i.kind === "wildIndustry" ? e.wilds.industry++ : e.discard.push(i), i) : W("games.brass.errBadCard");
}
function _e(e, t) {
	let n = e.hands[e.players[t]];
	for (; n.length < 8 && e.deck.length > 0;) n.push(e.deck.pop());
}
function ve(e, t, n, r, i) {
	let a = "farm" in r;
	if (n.kind === "location") return a || r.city !== n.city ? W("games.brass.errBadCard") : i === void 0 ? W("games.brass.errNeedIndustry") : { industry: i };
	if (n.kind === "wildLocation") return a ? W("games.brass.errBadCard") : i === void 0 ? W("games.brass.errNeedIndustry") : { industry: i };
	let o;
	if (n.kind === "industry") {
		if (n.industries.length === 1) {
			if (i !== void 0 && i !== n.industries[0]) return W("games.brass.errBadCard");
			o = n.industries[0];
		} else {
			if (i === void 0 || !n.industries.includes(i)) return W("games.brass.errNeedIndustry");
			o = i;
		}
	} else {
		if (i === void 0) return W("games.brass.errNeedIndustry");
		o = i;
	}
	return a ? o === "brewery" ? { industry: o } : W("games.brass.errFarmBrewery") : de(e, t) && !q(e, t).has(r.city) ? W("games.brass.errNotInNetwork") : { industry: o };
}
function ye(e, t, n) {
	let r = e.hands[e.players[t]][n.card];
	if (!r) return W("games.brass.errBadCard");
	let i = ve(e, t, r, n.at, n.industry);
	if ("code" in i) return i;
	let { industry: a } = i, o = e.stacks[e.players[t]][a];
	if (!o || o.length === 0) return W("games.brass.errNoTile");
	let s = o[o.length - 1], c = C(a, s);
	if (e.era === "canal" && !c.canal || e.era === "rail" && !c.rail) return W("games.brass.errEraLocked");
	let l = ce(n.at), u = e.board[l], d = G(n.at);
	if (u) {
		if (u.industry !== a || s <= u.level) return W("games.brass.errBadOverbuild");
		if (u.owner !== t) {
			if (a !== "coal" && a !== "iron") return W("games.brass.errBadOverbuild");
			let t = Object.values(e.board).some((e) => e.industry === a && !e.flipped && e.cubes > 0), n = a === "coal" ? e.coalMarket > 0 : e.ironMarket > 0;
			if (t || n) return W("games.brass.errBadOverbuild");
		}
	} else {
		let r = n.at;
		if ("farm" in r) {
			if (a !== "brewery") return W("games.brass.errBadSlot");
		} else {
			let n = T.find((e) => e.id === r.city), i = n.slots[r.slot];
			if (!i || !i.includes(a)) return W("games.brass.errBadSlot");
			if (i.length > 1 && n.slots.some((t, r) => t.length === 1 && t[0] === a && e.board[`${n.id}:${r}`] === void 0)) return W("games.brass.errSingleSlotFirst");
			if (e.era === "canal" && Object.keys(e.board).some((r) => r.startsWith(`${n.id}:`) && e.board[r].owner === t)) return W("games.brass.errOnePerCity");
		}
	}
	if (e.money[t] < c.cost) return W("games.brass.errCantAfford");
	let f = he(e, t, c.iron);
	if (f) return f;
	let p = me(e, t, c.coal, d);
	if (p) return p;
	e.money[t] -= c.cost, e.spent[t] += c.cost;
	let m = Y(e, t, n.card);
	if ("code" in m) return m;
	o.pop();
	let h = a === "coal" || a === "iron" ? c.produce : a === "brewery" ? e.era === "canal" ? 1 : 2 : 0;
	return e.board[l] = {
		industry: a,
		level: s,
		owner: t,
		flipped: !1,
		cubes: h
	}, ge(e, t, e.board[l], d), null;
}
function be(e, t, n) {
	if (!e.hands[e.players[t]][n.card]) return W("games.brass.errBadCard");
	if (e.era === "canal" && n.links.length !== 1) return W("games.brass.errBadLinks");
	let r = [];
	for (let t of n.links) {
		let n = A.find((e) => e.id === t);
		if (!n || e.links[t] !== void 0 || (e.era === "canal" ? !n.canal : !n.rail)) return W("games.brass.errBadLinks");
		r.push(n);
	}
	if (new Set(n.links).size !== n.links.length) return W("games.brass.errBadLinks");
	if (e.linkStock[t] < n.links.length) return W("games.brass.errNoTile");
	let i = e.era === "canal" ? 3 : n.links.length === 1 ? 5 : 15;
	if (e.money[t] < i) return W("games.brass.errCantAfford");
	if (n.links.length === 2) {
		if (!n.beerFrom) return W("games.brass.errNeedBeer");
		let t = e.board[ce(n.beerFrom)];
		if (!t || t.industry !== "brewery" || t.flipped || t.cubes === 0) return W("games.brass.errNeedBeer");
	}
	let a = q(e, t), o = !de(e, t);
	for (let n = 0; n < r.length; n++) {
		let i = r[n];
		if (!o && !i.nodes.some((e) => a.has(e))) return W("games.brass.errNotInNetwork");
		if (e.era === "rail") {
			e.links[i.id] = t;
			let n = K(e), r = (() => {
				let r = ue(n, i.nodes[0]), a = ue(n, i.nodes[i.nodes.length - 1]), o = null, s = Infinity, c = !1;
				for (let [n, i] of Object.entries(e.board)) {
					if (i.industry !== "coal" || i.flipped || i.cubes === 0) continue;
					let e = n.split(":")[0], l = Math.min(r.get(e) ?? Infinity, a.get(e) ?? Infinity);
					if (l === Infinity) continue;
					let u = i.owner === t;
					(l < s || l === s && u && !c) && (o = n, s = l, c = u);
				}
				if (o) return J(e, e.board[o]), null;
				if (!E.some((e) => r.has(e.id) || a.has(e.id))) return W("games.brass.errNoCoal");
				let l = pe(N, e.coalMarket, 8);
				return e.money[t] < l ? W("games.brass.errCantAfford") : (e.money[t] -= l, e.spent[t] += l, e.coalMarket > 0 && e.coalMarket--, null);
			})();
			if (r) return delete e.links[i.id], r;
		} else e.links[i.id] = t;
		for (let e of i.nodes) a.add(e);
	}
	if (n.links.length === 2 && n.beerFrom) {
		let i = e.board[ce(n.beerFrom)];
		if (i.owner !== t) {
			let t = ue(K(e), G(n.beerFrom));
			if (!r[1].nodes.some((e) => t.has(e))) return W("games.brass.errBeerNotConnected");
		}
		J(e, i);
	}
	e.money[t] -= i, e.spent[t] += i, e.linkStock[t] -= n.links.length;
	let s = Y(e, t, n.card);
	return "code" in s ? s : null;
}
function xe(e, t, n) {
	if (!e.hands[e.players[t]][n.card]) return W("games.brass.errBadCard");
	let r = he(e, t, n.industries.length);
	if (r) return r;
	for (let r of n.industries) {
		let n = e.stacks[e.players[t]][r];
		if (!n || n.length === 0) return W("games.brass.errNoTile");
		if (C(r, n[n.length - 1]).noDevelop) return W("games.brass.errLightbulb");
		n.pop();
	}
	let i = Y(e, t, n.card);
	return "code" in i ? i : null;
}
function Se(e, t, n) {
	let r = e.stacks[e.players[t]][n];
	return !r || r.length === 0 ? W("games.brass.errNoTile") : C(n, r[r.length - 1]).noDevelop ? W("games.brass.errLightbulb") : (r.pop(), null);
}
function Ce(e, t, n) {
	if (!e.hands[e.players[t]][n.card]) return W("games.brass.errBadCard");
	let r = K(e), i = 0;
	for (let a of n.sales) {
		let n = ce(a.tile), o = e.board[n];
		if (!o || o.owner !== t || o.flipped || !ee.includes(o.industry)) return W("games.brass.errBadSell");
		let s = C(o.industry, o.level);
		if (a.beers.length !== s.beer) return W("games.brass.errNeedBeer");
		let c = ue(r, G(a.tile));
		if (e.merchants.filter((e) => (e.buys === "any" || e.buys === o.industry) && c.has(e.location)).length === 0) return W("games.brass.errNoMerchant");
		let l = /* @__PURE__ */ new Set();
		for (let n of a.beers) if (n.kind === "merchant") {
			let t = e.merchants[n.index];
			if (!t || !t.beer) return W("games.brass.errNeedBeer");
			if (t.buys !== "any" && t.buys !== o.industry || !c.has(t.location)) return W("games.brass.errNoMerchant");
			l.add(n.index);
		} else {
			let r = ce(n.at), i = e.board[r];
			if (!i || i.industry !== "brewery" || i.flipped || i.cubes === 0) return W("games.brass.errNeedBeer");
			if (i.owner !== t && !c.has(G(n.at))) return W("games.brass.errBeerNotConnected");
		}
		if (l.size > 1) return W("games.brass.errOneMerchant");
		for (let n of a.beers) if (n.kind === "merchant") {
			let r = e.merchants[n.index];
			r.beer = !1;
			let a = E.find((e) => e.id === r.location).bonus;
			a.kind === "vp" ? e.vp[t] += a.amount : a.kind === "money" ? e.money[t] += a.amount : a.kind === "income" ? e.incomeSpace[t] = Math.min(99, e.incomeSpace[t] + a.amount) : i++;
		} else J(e, e.board[ce(n.at)]);
		fe(e, o);
	}
	let a = n.bonusDevelop ?? [];
	if (a.length !== i) return W("games.brass.errBonusDevelop");
	for (let n of a) {
		let r = Se(e, t, n);
		if (r) return r;
	}
	let o = Y(e, t, n.card);
	return "code" in o ? o : null;
}
function we(e, t, n) {
	if (!e.hands[e.players[t]][n.card]) return W("games.brass.errBadCard");
	let r = F(e.incomeSpace[t]);
	if (r - 3 < -10) return W("games.brass.errLoanFloor");
	e.money[t] += 30, e.incomeSpace[t] = I(r - 3);
	let i = Y(e, t, n.card);
	return "code" in i ? i : null;
}
function Te(e, t, n) {
	let r = e.hands[e.players[t]];
	if (r.some((e) => e.kind === "wildLocation" || e.kind === "wildIndustry")) return W("games.brass.errHasWild");
	if (e.wilds.location === 0 || e.wilds.industry === 0) return W("games.brass.errNoWild");
	if (new Set(n.cards).size !== 3 || n.cards.some((e) => !r[e])) return W("games.brass.errBadCard");
	for (let r of [...n.cards].sort((e, t) => t - e)) {
		let n = Y(e, t, r);
		if ("code" in n) return n;
	}
	return e.wilds.location--, e.wilds.industry--, r.push({ kind: "wildLocation" }, { kind: "wildIndustry" }), null;
}
function Ee(e, t, n) {
	let r = e.pendingDebt.find((n) => n.rid === e.players[t]);
	if (!r) return W("games.brass.errNoDebt");
	let i = 0, a = [];
	for (let o of n.tiles) {
		let n = ce(o), s = e.board[n];
		if (!s || s.owner !== t) return W("games.brass.errBadSell");
		if (i >= r.need) return W("games.brass.errOverpay");
		a.push(n), i += Math.floor(C(s.industry, s.level).cost / 2);
	}
	for (let t of a) delete e.board[t];
	e.money[t] += i;
	let o = Math.min(e.money[t], r.need);
	return e.money[t] -= o, r.need -= o, r.need <= 0 ? e.pendingDebt = e.pendingDebt.filter((e) => e !== r) : Object.values(e.board).some((e) => e.owner === t) || (e.vp[t] = Math.max(0, e.vp[t] - r.need), e.pendingDebt = e.pendingDebt.filter((e) => e !== r)), null;
}
function De(e) {
	return e.era === "canal" && e.round === 1 ? 1 : 2;
}
function Oe(e) {
	let t = e.players.map(() => 0), n = e.players.map(() => 0), r = (t) => {
		if (E.some((e) => e.id === t)) return 2;
		let n = 0;
		for (let [r, i] of Object.entries(e.board)) i.flipped && (r.startsWith("farm:") ? r.slice(5) : r.split(":")[0]) === t && (n += C(i.industry, i.level).links);
		return n;
	};
	for (let [t, i] of Object.entries(e.links)) {
		let e = A.find((e) => e.id === t);
		n[i] += r(e.nodes[0]) + r(e.nodes[e.nodes.length - 1]);
	}
	for (let n of Object.values(e.board)) n.flipped && (t[n.owner] += C(n.industry, n.level).vp);
	e.players.forEach((r, i) => {
		e.vp[i] += t[i] + n[i], e.eraScores ||= [], e.eraScores.push({
			era: e.era,
			rid: r,
			industryVp: t[i],
			linkVp: n[i]
		});
	});
}
function ke(e) {
	if (Oe(e), e.era === "rail") {
		e.phase = "done";
		let t = e.players.map((e, t) => t).sort((t, n) => {
			if (e.vp[t] !== e.vp[n]) return e.vp[n] - e.vp[t];
			let r = F(e.incomeSpace[t]), i = F(e.incomeSpace[n]);
			return r === i ? e.money[n] - e.money[t] : i - r;
		});
		e.winner = e.players[t[0]];
		return;
	}
	for (let t of Object.keys(e.board)) e.board[t].level === 1 && delete e.board[t];
	for (let t of e.merchants) t.buys !== "blank" && (t.beer = !0);
	e.deck = e.discard, e.discard = [], e.rngCursor = le(e.deck, e.seed, e.rngCursor);
	for (let t of e.players) e.hands[t] = [], _e(e, e.players.indexOf(t));
	e.era = "rail", e.round = 1, e.links = {}, e.turnIdx = 0, e.actionsLeft = De(e);
}
function Ae(e) {
	e.order = [...e.order].sort((t, n) => e.spent[t] - e.spent[n]), e.spent = e.players.map(() => 0);
	let t = e.deck.length === 0 && e.players.every((t) => e.hands[t].length === 0);
	if (t && e.era === "rail" || e.players.forEach((t, n) => {
		let r = F(e.incomeSpace[n]);
		if (r >= 0) e.money[n] += r;
		else {
			let i = -r, a = Math.min(e.money[n], i);
			e.money[n] -= a;
			let o = i - a;
			o > 0 && (Object.values(e.board).some((e) => e.owner === n) || (e.vp[n] = Math.max(0, e.vp[n] - o), o = 0), o > 0 && e.pendingDebt.push({
				rid: t,
				need: o
			}));
		}
	}), e.pendingDebt.length > 0) {
		e.afterDebt = t ? "endEra" : "nextRound";
		return;
	}
	t ? ke(e) : (e.round++, e.turnIdx = 0, e.actionsLeft = De(e));
}
function je(e) {
	if (_e(e, e.order[e.turnIdx]), e.actionsLeft--, !(e.actionsLeft > 0)) {
		for (e.turnIdx++; e.turnIdx < e.players.length;) {
			e.actionsLeft = De(e);
			let t = e.players[e.order[e.turnIdx]];
			if (e.hands[t].length > 0) return;
			e.turnIdx++;
		}
		Ae(e);
	}
}
function Me(e, t, n) {
	let r = 0, i = M(t.length);
	r = le(i, n, r);
	let a = t.map((e, t) => t);
	r = le(a, n, r);
	let o = {};
	for (let e of t) o[e] = [];
	for (let e = 0; e < 8; e++) for (let e of t) o[e].push(i.pop());
	let s = [];
	for (let e = 0; e < t.length; e++) s.push(i.pop());
	let c = [...O[t.length]];
	r = le(c, n, r);
	let l = [];
	for (let e of E) if (!(t.length < e.minPlayers)) for (let t = 0; t < e.slots; t++) {
		let t = c.pop();
		l.push({
			location: e.id,
			buys: t,
			beer: t !== "blank"
		});
	}
	let u = {};
	for (let e of t) u[e] = {
		cotton: w("cotton"),
		manufacturer: w("manufacturer"),
		pottery: w("pottery"),
		brewery: w("brewery"),
		coal: w("coal"),
		iron: w("iron")
	};
	return { state: {
		seed: n,
		rngCursor: r,
		players: t,
		phase: "play",
		era: "canal",
		round: 1,
		order: a,
		turnIdx: 0,
		actionsLeft: 1,
		spent: t.map(() => 0),
		hands: o,
		deck: i,
		discard: s,
		wilds: {
			location: 4,
			industry: 4
		},
		board: {},
		links: {},
		stacks: u,
		money: t.map(() => 17),
		incomeSpace: t.map(() => 10),
		vp: t.map(() => 0),
		coalMarket: 13,
		ironMarket: 8,
		merchants: l,
		linkStock: t.map(() => 14),
		pendingDebt: [],
		afterDebt: null,
		eraScores: null,
		winner: null
	} };
}
function Ne(e, t, n) {
	let r = structuredClone(e), i = r.players.indexOf(n.by);
	if (i < 0 || r.phase !== "play") return W("games.brass.errNotPlaying");
	if (r.pendingDebt.length > 0) {
		if (t.type !== "payDebt") return W("games.brass.errDebtPending");
		if (!r.pendingDebt.some((e) => e.rid === n.by)) return W("games.brass.errNoDebt");
		let e = Ee(r, i, t);
		if (e) return e;
		if (r.pendingDebt.length === 0) {
			let e = r.afterDebt;
			r.afterDebt = null, e === "endEra" ? ke(r) : (r.round++, r.turnIdx = 0, r.actionsLeft = De(r));
		}
		return { state: r };
	}
	if (t.type === "payDebt") return W("games.brass.errNoDebt");
	if (r.order[r.turnIdx] !== i) return W("games.brass.errNotYourTurn");
	let a = [], o;
	switch (t.type) {
		case "build":
			o = ye(r, i, t);
			break;
		case "network":
			o = be(r, i, t);
			break;
		case "develop":
			o = xe(r, i, t);
			break;
		case "sell":
			o = Ce(r, i, t);
			break;
		case "loan":
			o = we(r, i, t);
			break;
		case "scout":
			o = Te(r, i, t);
			break;
		case "pass": {
			let e = Y(r, i, t.card);
			o = "code" in e ? e : null;
			break;
		}
	}
	return o || (je(r), {
		state: r,
		fx: a
	});
}
function Pe(e, t) {
	return {
		public: {
			phase: e.phase,
			era: e.era,
			round: e.round,
			order: e.order,
			turnIdx: e.turnIdx,
			actionsLeft: e.actionsLeft,
			players: e.players.map((t, n) => ({
				rid: t,
				money: e.money[n],
				incomeLevel: F(e.incomeSpace[n]),
				vp: e.vp[n],
				linkStock: e.linkStock[n],
				handCount: e.hands[t].length,
				stacks: Object.fromEntries(Object.entries(e.stacks[t]).map(([e, t]) => [e, [...t]])),
				spent: e.spent[n]
			})),
			board: structuredClone(e.board),
			links: { ...e.links },
			merchants: e.merchants.map((e) => ({ ...e })),
			coalMarket: e.coalMarket,
			ironMarket: e.ironMarket,
			deckCount: e.deck.length,
			wilds: { ...e.wilds },
			pendingDebt: e.pendingDebt.map((e) => ({ ...e })),
			eraScores: e.eraScores ? e.eraScores.map((e) => ({ ...e })) : null,
			winner: e.winner
		},
		private: { hand: [...e.hands[t]] }
	};
}
function Fe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.players.map((e, t) => t).sort((t, n) => {
		if (e.vp[t] !== e.vp[n]) return e.vp[n] - e.vp[t];
		let r = F(e.incomeSpace[t]), i = F(e.incomeSpace[n]);
		return r === i ? e.money[n] - e.money[t] : i - r;
	}), n = t.filter((n) => e.vp[n] === e.vp[t[0]] && F(e.incomeSpace[n]) === F(e.incomeSpace[t[0]]) && e.money[n] === e.money[t[0]]);
	return {
		phase: e.phase,
		winner: n.map((t) => e.players[t]),
		ranking: t.map((t) => e.players[t]),
		scores: Object.fromEntries(e.players.map((t, n) => [t, e.vp[n]]))
	};
}
var Ie = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: te,
	schemas: {
		action: re,
		publicView: se,
		privateView: U
	},
	setup: Me,
	reduce: Ne,
	viewFor: Pe,
	status: Fe
}, Le = {
	cotton: {
		icon: "🧵",
		color: "var(--color-brass-cotton)"
	},
	manufacturer: {
		icon: "🏭",
		color: "var(--color-brass-manufacturer)"
	},
	pottery: {
		icon: "🏺",
		color: "var(--color-brass-pottery)"
	},
	brewery: {
		icon: "🍺",
		color: "var(--color-brass-brewery)"
	},
	coal: {
		icon: "🪨",
		color: "var(--color-brass-coal)"
	},
	iron: {
		icon: "⛏️",
		color: "var(--color-brass-iron)"
	}
};
function Re({ industry: e, x: t = 12, y: n = 12, size: r = 24 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${t - r / 2},${n - r / 2}) scale(${r / 24})`,
		fill: "none",
		stroke: Le[e].color,
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			e === "cotton" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M5 6c2-3 5-3 7 0 2-3 5-3 7 0 2 3 0 5-2 6 3 2 2 5-1 6-2 1-3 0-4-2-1 2-3 3-5 2-3-1-4-4-1-6-2-1-3-3-1-6Z" }), /* @__PURE__ */ m("path", { d: "M12 14v7" })] }),
			e === "manufacturer" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M3 20V9l6 4V9l6 4V5h5v15Z" }), /* @__PURE__ */ m("path", { d: "M7 17h2m3 0h2m3 0h2" })] }),
			e === "pottery" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M7 3h10M9 3v4c0 2-4 4-4 9 0 3 3 5 7 5s7-2 7-5c0-5-4-7-4-9V3" }), /* @__PURE__ */ m("path", { d: "M7 15h10" })] }),
			e === "brewery" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M7 4h10v4l-2 3v9H9v-9L7 8Z" }), /* @__PURE__ */ m("path", { d: "M7 8h10m-8 7h6" })] }),
			e === "coal" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "m3 17 5-10 9-3 4 11-7 6Z" }), /* @__PURE__ */ m("path", { d: "m8 7 5 7 8 1m-8-1 1 7" })] }),
			e === "iron" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M3 8h18l-2 5-6 1-2 3H7l-2-3-2-1Z" }), /* @__PURE__ */ m("path", { d: "M8 17h8v4H8z" })] })
		]
	});
}
function ze({ industry: e, size: t = 22 }) {
	return /* @__PURE__ */ m("svg", {
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: /* @__PURE__ */ m(Re, { industry: e })
	});
}
//#endregion
//#region src/games/brass/name-keys.ts
var X = {
	belper: "games.brass.city.belper",
	derby: "games.brass.city.derby",
	leek: "games.brass.city.leek",
	stokeOnTrent: "games.brass.city.stokeOnTrent",
	stone: "games.brass.city.stone",
	uttoxeter: "games.brass.city.uttoxeter",
	stafford: "games.brass.city.stafford",
	burtonOnTrent: "games.brass.city.burtonOnTrent",
	cannock: "games.brass.city.cannock",
	tamworth: "games.brass.city.tamworth",
	walsall: "games.brass.city.walsall",
	wolverhampton: "games.brass.city.wolverhampton",
	coalbrookdale: "games.brass.city.coalbrookdale",
	dudley: "games.brass.city.dudley",
	kidderminster: "games.brass.city.kidderminster",
	worcester: "games.brass.city.worcester",
	birmingham: "games.brass.city.birmingham",
	coventry: "games.brass.city.coventry",
	nuneaton: "games.brass.city.nuneaton",
	redditch: "games.brass.city.redditch",
	shrewsbury: "games.brass.city.shrewsbury",
	gloucester: "games.brass.city.gloucester",
	oxford: "games.brass.city.oxford",
	warrington: "games.brass.city.warrington",
	nottingham: "games.brass.city.nottingham",
	farmN: "games.brass.city.farmN",
	farmS: "games.brass.city.farmS"
}, Be = {
	cotton: "games.brass.industry.cotton",
	manufacturer: "games.brass.industry.manufacturer",
	pottery: "games.brass.industry.pottery",
	brewery: "games.brass.industry.brewery",
	coal: "games.brass.industry.coal",
	iron: "games.brass.industry.iron"
}, Z = 30, Ve = 3, He = 5;
function Ue(e, t) {
	let n = T.find((t) => t.id === e), r = Math.min(n.slots.length, 2), i = Math.ceil(n.slots.length / 2), a = 10 + r * Z + (r - 1) * Ve, o = 10 + i * Z + (i - 1) * Ve;
	return {
		x: n.x - a / 2 + He + Z / 2 + t % 2 * 33,
		y: n.y - o / 2 + He + Z / 2 + Math.floor(t / 2) * 33
	};
}
function We(e) {
	let t = T.find((t) => t.id === e), n = Math.min(t.slots.length, 2), r = Math.ceil(t.slots.length / 2), i = 10 + n * Z + (n - 1) * Ve, a = 10 + r * Z + (r - 1) * Ve;
	return {
		x: t.x - i / 2,
		y: t.y - a / 2,
		w: i,
		h: a
	};
}
var Q = {
	x0: -30,
	y0: -30,
	x1: 890,
	y1: 835
}, Ge = (e) => Math.min(e.w / (Q.x1 - Q.x0), e.h / (Q.y1 - Q.y0)), Ke = (e, t) => {
	let n = t ? j(t) : {
		x: 430,
		y: 510
	};
	return {
		cx: n.x,
		cy: n.y,
		s: Math.max(.1, Ge(e) * (t ? 2.2 : 2.5))
	};
}, qe = (e) => new Map(Object.entries(e).map(([e, t]) => [e, {
	owner: t.owner,
	level: t.level,
	flipped: t.flipped
}]));
function Je({ pub: e, members: t, hot: o, pickedLinks: s, pickedTiles: l, focusNode: u, onTapSlot: d, onTapLink: g, onTapTile: _ }) {
	let v = c(), y = (n) => a[(t.find((t) => t.rid === e.players[n]?.rid)?.avatar ?? 0) % a.length], b = (n) => f[(t.find((t) => t.rid === e.players[n]?.rid)?.colorIndex ?? 0) % f.length].hex, x = (n) => t.find((t) => t.rid === e.players[n]?.rid)?.name ?? v(f[0].nameKey), S = r(null), [C, w] = i({
		w: 0,
		h: 0
	}), [O, k] = i(null), M = r(Ke(C, u)), N = `${JSON.stringify(e.board)}|${JSON.stringify(e.links)}`, [P, F] = i(() => ({
		signature: N,
		tiles: qe(e.board),
		links: new Set(Object.keys(e.links)),
		placed: /* @__PURE__ */ new Set(),
		flipped: /* @__PURE__ */ new Set(),
		newLinks: /* @__PURE__ */ new Set()
	}));
	if (P.signature !== N) {
		let t = qe(e.board), n = new Set(Object.keys(e.links));
		F({
			signature: N,
			tiles: t,
			links: n,
			placed: new Set([...t].filter(([e, t]) => {
				let n = P.tiles.get(e);
				return !n || n.owner !== t.owner || n.level !== t.level;
			}).map(([e]) => e)),
			flipped: new Set([...t].filter(([e, t]) => !P.tiles.get(e)?.flipped && t.flipped).map(([e]) => e)),
			newLinks: new Set([...n].filter((e) => !P.links.has(e)))
		});
	}
	n(() => {
		let e = S.current, t = new ResizeObserver(() => w({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let I = O ?? Ke(C, u);
	n(() => {
		M.current = I;
	});
	let ee = r({
		w: 0,
		h: 0
	});
	n(() => {
		let e = ee.current;
		if (e.w > 0 && C.w > 0 && (e.w !== C.w || e.h !== C.h)) {
			let t = Ge(C) / Ge(e);
			k((e) => e ? {
				...e,
				s: e.s * t
			} : null);
		}
		ee.current = C;
	}, [C]);
	let te = (e) => {
		let t = M.current;
		k({
			...t,
			s: Math.max(Ge(C) * .85, Math.min(3, t.s * e))
		});
	}, L = () => k({
		cx: (Q.x0 + Q.x1) / 2,
		cy: (Q.y0 + Q.y1) / 2,
		s: Ge(C)
	});
	n(() => {
		let e = S.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = M.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = Math.max(Ge({
				w: n.width,
				h: n.height
			}) * .85, Math.min(3, r.s * i)), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			M.current = u, k(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, []);
	let R = r(/* @__PURE__ */ new Map()), z = r(0), B = r(0), V = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), R.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), R.current.size === 1 && (z.current = 0), R.current.size === 2) {
			let [e, t] = [...R.current.values()];
			B.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, ne = (e) => {
		let t = R.current.get(e.pointerId);
		if (!t) return;
		let n = S.current.getBoundingClientRect();
		if (R.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			z.current += Math.abs(n) + Math.abs(r);
			let i = M.current, a = {
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			};
			M.current = a, k(a);
		} else if (R.current.size === 2) {
			R.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...R.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (B.current > 0 && i > 0) {
				let e = M.current, a = Math.max(Ge({
					w: n.width,
					h: n.height
				}) * .85, Math.min(3, e.s * i / B.current)), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				M.current = u, k(u);
			}
			B.current = i, z.current = 99;
			return;
		}
		R.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, H = (e, t, n, r, i, a) => {
		let o = i - n, s = a - r, c = o * o + s * s, l = c === 0 ? 0 : Math.max(0, Math.min(1, ((e - n) * o + (t - r) * s) / c));
		return Math.hypot(e - (n + l * o), t - (r + l * s));
	};
	return /* @__PURE__ */ h("div", {
		ref: S,
		className: "brass-board",
		children: [
			/* @__PURE__ */ h("svg", {
				className: "brass-board__svg",
				onPointerDown: V,
				onPointerMove: ne,
				onPointerUp: (e) => {
					let t = R.current.size === 1 && z.current < 10;
					if (R.current.delete(e.pointerId), B.current = 0, !t || !o) return;
					let n = S.current.getBoundingClientRect(), r = M.current, i = r.cx + (e.clientX - n.left - n.width / 2) / r.s, a = r.cy + (e.clientY - n.top - n.height / 2) / r.s, s = (e) => e.startsWith("farm:") ? j(e.slice(5)) : Ue(e.split(":")[0], Number(e.split(":")[1]));
					if (o.tiles && _) {
						let e = null, t = Math.max(22, 22 / r.s);
						for (let n of o.tiles) {
							let r = s(n), o = Math.hypot(r.x - i, r.y - a);
							o < t && (t = o, e = n);
						}
						e && _(e);
						return;
					}
					if (o.slots && d) {
						let e = null, t = Math.max(22, 22 / r.s);
						for (let n of o.slots) {
							let r = s(n), o = Math.hypot(r.x - i, r.y - a);
							o < t && (t = o, e = n);
						}
						e && d(e);
						return;
					}
					if (o.links && g) {
						let e = null, t = Math.max(18, 22 / r.s);
						for (let n of o.links) {
							let r = A.find((e) => e.id === n);
							for (let o = 0; o + 1 < r.nodes.length; o++) {
								let s = j(r.nodes[o]), c = j(r.nodes[o + 1]), l = H(i, a, s.x, s.y, c.x, c.y);
								l < t && (t = l, e = n);
							}
						}
						e && g(e);
					}
				},
				onPointerCancel: (e) => {
					R.current.delete(e.pointerId), B.current = 0;
				},
				role: "img",
				"aria-label": v("games.brass.mapLabel"),
				children: [/* @__PURE__ */ m("defs", { children: /* @__PURE__ */ m("filter", {
					id: "brass-board-shadow",
					x: "-30%",
					y: "-30%",
					width: "160%",
					height: "170%",
					children: /* @__PURE__ */ m("feDropShadow", {
						dx: "2",
						dy: "3",
						stdDeviation: "1.2",
						floodColor: "#1b2624",
						floodOpacity: "0.45"
					})
				}) }), /* @__PURE__ */ h("g", {
					transform: `translate(${C.w / 2 - I.cx * I.s}, ${C.h / 2 - I.cy * I.s}) scale(${I.s})`,
					children: [
						/* @__PURE__ */ m("image", {
							href: "./games/brass/map.webp",
							x: Q.x0,
							y: Q.y0,
							width: Q.x1 - Q.x0,
							height: Q.y1 - Q.y0,
							preserveAspectRatio: "none"
						}),
						/* @__PURE__ */ m("rect", {
							x: Q.x0,
							y: Q.y0,
							width: Q.x1 - Q.x0,
							height: Q.y1 - Q.y0,
							fill: "var(--color-brass-cream)",
							opacity: .06
						}),
						A.map((t) => {
							let n = e.links[t.id], r = t.nodes.map((e) => j(e)), i = r.map((e, t) => `${t === 0 ? "M" : "L"}${e.x},${e.y}`).join(" "), a = s?.has(t.id) ?? !1, c = o?.links?.has(t.id) ?? !1, l = e.era === "canal" ? t.canal : t.rail, u = (e.era === "canal" || !t.rail) && t.canal, d = {
								x: (r[0].x + r[r.length - 1].x) / 2,
								y: (r[0].y + r[r.length - 1].y) / 2
							};
							return /* @__PURE__ */ h("g", {
								className: P.newLinks.has(t.id) ? "brass-board__new-link" : void 0,
								opacity: l || n !== void 0 ? 1 : .32,
								children: [
									/* @__PURE__ */ m("title", { children: `${t.nodes.map((e) => v(X[e])).join(" – ")}${n === void 0 ? "" : ` · ${x(n)}`}` }),
									/* @__PURE__ */ m("path", {
										d: i,
										fill: "none",
										stroke: "var(--color-brass-slate-deep)",
										strokeWidth: n === void 0 ? 7 : 9,
										strokeLinecap: "round",
										strokeLinejoin: "round",
										opacity: .83
									}),
									/* @__PURE__ */ m("path", {
										d: i,
										fill: "none",
										stroke: a ? "var(--color-brass-gold)" : u ? "var(--color-brass-canal)" : "var(--color-brass-copper)",
										strokeWidth: n === void 0 ? c ? 6.5 : 4 : 5.8,
										strokeLinecap: "round",
										strokeLinejoin: "round"
									}),
									!u && /* @__PURE__ */ m("path", {
										d: i,
										fill: "none",
										stroke: "var(--color-brass-slate-deep)",
										strokeWidth: 1.5,
										strokeDasharray: "3 5"
									}),
									c && /* @__PURE__ */ h(p, { children: [
										/* @__PURE__ */ m("path", {
											d: i,
											fill: "none",
											stroke: "var(--color-brass-cream)",
											strokeWidth: 1.5
										}),
										/* @__PURE__ */ m("circle", {
											cx: d.x,
											cy: d.y,
											r: 11,
											fill: "var(--color-brass-gold)",
											stroke: "var(--color-brass-cream)",
											strokeWidth: 2
										}),
										/* @__PURE__ */ m("text", {
											x: d.x,
											y: d.y + 4,
											textAnchor: "middle",
											fontSize: 13,
											fontWeight: 900,
											fill: "var(--color-brass-slate-deep)",
											children: "+"
										})
									] }),
									a && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
										cx: d.x,
										cy: d.y,
										r: 11,
										fill: "var(--color-brass-gold)",
										stroke: "var(--color-brass-cream)",
										strokeWidth: 2
									}), /* @__PURE__ */ m("text", {
										x: d.x,
										y: d.y + 4,
										textAnchor: "middle",
										fontSize: 12,
										fontWeight: 900,
										fill: "var(--color-brass-slate-deep)",
										children: "✓"
									})] }),
									n !== void 0 && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
										cx: d.x,
										cy: d.y,
										r: 10,
										fill: "var(--color-brass-slate-deep)",
										stroke: b(n),
										strokeWidth: 2
									}), /* @__PURE__ */ m("image", {
										href: y(n),
										x: d.x - 8,
										y: d.y - 8,
										width: 16,
										height: 16,
										preserveAspectRatio: "xMidYMid meet",
										pointerEvents: "none"
									})] })
								]
							}, t.id);
						}),
						T.map((t) => {
							let n = We(t.id), r = v(X[t.id]), i = Math.max(n.w + 4, Math.min(160, r.length * (/[\u4e00-\u9fff]/.test(r) ? 11 : 7) + 12)), a = t.slots.some((e, n) => o?.slots?.has(`${t.id}:${n}`));
							return /* @__PURE__ */ h("g", { children: [
								/* @__PURE__ */ m("title", { children: r }),
								a && /* @__PURE__ */ m("rect", {
									x: n.x - 7,
									y: n.y - 7,
									width: n.w + 14,
									height: n.h + 14,
									rx: 12,
									fill: "var(--color-brass-gold)",
									opacity: .36
								}),
								/* @__PURE__ */ m("rect", {
									x: n.x,
									y: n.y + 3,
									width: n.w,
									height: n.h,
									rx: 7,
									fill: "var(--color-brass-slate-deep)",
									filter: "url(#brass-board-shadow)"
								}),
								/* @__PURE__ */ m("rect", {
									x: n.x,
									y: n.y,
									width: n.w,
									height: n.h,
									rx: 7,
									fill: "var(--color-brass-slate)",
									stroke: "var(--color-brass-gold)",
									strokeWidth: 2
								}),
								t.slots.map((n, r) => {
									let i = Ue(t.id, r), a = `${t.id}:${r}`, s = e.board[a], c = P.placed.has(a) ? "placed" : P.flipped.has(a) ? "flipped" : void 0, u = o?.slots?.has(a) ?? !1, d = l?.has(a) ?? !1;
									return /* @__PURE__ */ h("g", { children: [
										u && /* @__PURE__ */ m("rect", {
											x: i.x - Z / 2 - 3,
											y: i.y - Z / 2 - 3,
											width: 36,
											height: 36,
											rx: 5,
											fill: "var(--color-brass-gold)",
											stroke: "var(--color-brass-cream)",
											strokeWidth: 2
										}),
										d && /* @__PURE__ */ m("rect", {
											x: i.x - Z / 2 - 4,
											y: i.y - Z / 2 - 4,
											width: 38,
											height: 38,
											rx: 6,
											fill: "none",
											stroke: "var(--color-brass-gold)",
											strokeWidth: 3
										}),
										s ? /* @__PURE__ */ m(Ye, {
											x: i.x,
											y: i.y,
											industry: s.industry,
											level: s.level,
											flipped: s.flipped,
											cubes: s.cubes,
											ownerAvatar: y(s.owner),
											ownerColor: b(s.owner),
											ownerName: x(s.owner),
											dim: o?.tiles != null && !o.tiles.has(a),
											motion: c
										}) : /* @__PURE__ */ h("g", { children: [
											/* @__PURE__ */ m("rect", {
												x: i.x - Z / 2,
												y: i.y - Z / 2,
												width: Z,
												height: Z,
												rx: 3,
												fill: "var(--color-brass-slot)",
												stroke: "var(--color-brass-gold)",
												strokeWidth: .8
											}),
											n.map((e, t) => /* @__PURE__ */ m(Re, {
												industry: e,
												x: i.x + (t - (n.length - 1) / 2) * 11,
												y: i.y,
												size: n.length === 1 ? 19 : 13
											}, e)),
											u && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
												cx: i.x + Z / 2 - 1,
												cy: i.y - Z / 2 + 1,
												r: 5.7,
												fill: "var(--color-brass-gold)",
												stroke: "var(--color-brass-cream)",
												strokeWidth: 1
											}), /* @__PURE__ */ m("text", {
												x: i.x + Z / 2 - 1,
												y: i.y - Z / 2 + 3.5,
												textAnchor: "middle",
												fontSize: 8,
												fontWeight: 900,
												fill: "var(--color-brass-slate-deep)",
												children: "+"
											})] })
										] })
									] }, a);
								}),
								/* @__PURE__ */ m("rect", {
									x: t.x - i / 2,
									y: n.y + n.h + 2,
									width: i,
									height: 18,
									rx: 3,
									fill: "var(--color-brass-cream)",
									stroke: "var(--color-brass-copper)",
									strokeWidth: 1.3
								}),
								/* @__PURE__ */ m("text", {
									x: t.x,
									y: n.y + n.h + 15,
									textAnchor: "middle",
									fontSize: 11,
									fontWeight: 900,
									fill: "var(--color-brass-slate-deep)",
									textLength: r.length > 12 ? i - 7 : void 0,
									lengthAdjust: "spacingAndGlyphs",
									children: r
								})
							] }, t.id);
						}),
						D.map((t) => {
							let n = `farm:${t.id}`, r = e.board[n], i = P.placed.has(n) ? "placed" : P.flipped.has(n) ? "flipped" : void 0, a = o?.slots?.has(n) ?? !1, s = l?.has(n) ?? !1;
							return /* @__PURE__ */ h("g", { children: [
								a && /* @__PURE__ */ m("circle", {
									cx: t.x,
									cy: t.y,
									r: 22,
									fill: "var(--color-brass-gold)",
									stroke: "var(--color-brass-cream)",
									strokeWidth: 2
								}),
								s && /* @__PURE__ */ m("circle", {
									cx: t.x,
									cy: t.y,
									r: 23,
									fill: "none",
									stroke: "var(--color-brass-gold)",
									strokeWidth: 3
								}),
								r ? /* @__PURE__ */ m(Ye, {
									x: t.x,
									y: t.y,
									industry: "brewery",
									level: r.level,
									flipped: r.flipped,
									cubes: r.cubes,
									ownerAvatar: y(r.owner),
									ownerColor: b(r.owner),
									ownerName: x(r.owner),
									motion: i
								}) : /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("circle", {
									cx: t.x,
									cy: t.y,
									r: 17,
									fill: "var(--color-brass-slate)",
									stroke: "var(--color-brass-gold)",
									strokeWidth: 2
								}), /* @__PURE__ */ m(Re, {
									industry: "brewery",
									x: t.x,
									y: t.y,
									size: 20
								})] }),
								/* @__PURE__ */ m("rect", {
									x: t.x - 29,
									y: t.y + 19,
									width: 58,
									height: 16,
									rx: 3,
									fill: "var(--color-brass-cream)",
									stroke: "var(--color-brass-copper)",
									strokeWidth: 1
								}),
								/* @__PURE__ */ m("text", {
									x: t.x,
									y: t.y + 31,
									textAnchor: "middle",
									fontSize: 10,
									fontWeight: 800,
									fill: "var(--color-brass-slate-deep)",
									children: v(X[t.id])
								})
							] }, t.id);
						}),
						e.merchants.map((e, t) => {
							let n = E.find((t) => t.id === e.location), r = j(e.location);
							return /* @__PURE__ */ h("g", {
								opacity: e.buys === "blank" ? .65 : 1,
								children: [
									/* @__PURE__ */ m("path", {
										d: `M${r.x - 17} ${r.y - 17}h34v25l-17 9-17-9Z`,
										fill: "var(--color-brass-slate-deep)",
										stroke: "var(--color-brass-gold)",
										strokeWidth: 2
									}),
									e.buys === "blank" ? /* @__PURE__ */ m("text", {
										x: r.x,
										y: r.y + 5,
										textAnchor: "middle",
										fontSize: 19,
										fontWeight: 900,
										fill: "var(--color-brass-cream)",
										children: "×"
									}) : e.buys === "any" ? /* @__PURE__ */ m("text", {
										x: r.x,
										y: r.y + 5,
										textAnchor: "middle",
										fontSize: 19,
										fill: "var(--color-brass-gold)",
										children: "★"
									}) : /* @__PURE__ */ m(Re, {
										industry: e.buys,
										x: r.x,
										y: r.y,
										size: 21
									}),
									e.beer && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
										cx: r.x + 17,
										cy: r.y - 16,
										r: 9,
										fill: "var(--color-brass-cream)",
										stroke: "var(--color-brass-copper)",
										strokeWidth: 1.5
									}), /* @__PURE__ */ m(Re, {
										industry: "brewery",
										x: r.x + 17,
										y: r.y - 16,
										size: 13
									})] }),
									/* @__PURE__ */ m("rect", {
										x: r.x - 32,
										y: r.y + 20,
										width: 64,
										height: 16,
										rx: 3,
										fill: "var(--color-brass-cream)",
										stroke: "var(--color-brass-copper)",
										strokeWidth: 1
									}),
									/* @__PURE__ */ m("text", {
										x: r.x,
										y: r.y + 32,
										textAnchor: "middle",
										fontSize: 10,
										fontWeight: 800,
										fill: "var(--color-brass-slate-deep)",
										children: v(X[n.id])
									})
								]
							}, `${e.location}-${t}`);
						})
					]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: "brass-board__era",
				"aria-hidden": "true",
				children: v(e.era === "canal" ? "games.brass.eraCanal" : "games.brass.eraRail")
			}),
			/* @__PURE__ */ h("div", {
				className: "brass-board__toolbar",
				children: [
					/* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => te(1.25),
						"aria-label": v("games.brass.zoomIn"),
						children: "＋"
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => te(.8),
						"aria-label": v("games.brass.zoomOut"),
						children: "－"
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						onClick: L,
						"aria-label": v("games.brass.showFullMap"),
						children: v("games.brass.showFullMap")
					})
				]
			})
		]
	});
}
function Ye({ x: e, y: t, industry: n, level: r, flipped: i, cubes: a, ownerAvatar: o, ownerColor: s, ownerName: c, dim: l, motion: u }) {
	return /* @__PURE__ */ h("g", {
		opacity: l ? .4 : 1,
		className: `brass-board__tile ${u ? `brass-board__tile--${u}` : ""}`,
		children: [
			/* @__PURE__ */ m("title", { children: `${c} · ${r}` }),
			/* @__PURE__ */ m("rect", {
				x: e - Z / 2,
				y: t - Z / 2 + 2,
				width: Z,
				height: Z,
				rx: 3,
				fill: "var(--color-brass-slate-deep)"
			}),
			/* @__PURE__ */ m("rect", {
				x: e - Z / 2,
				y: t - Z / 2,
				width: Z,
				height: Z,
				rx: 3,
				fill: i ? "var(--color-brass-copper)" : "var(--color-brass-slate)",
				stroke: "var(--color-brass-gold)",
				strokeWidth: 1.6
			}),
			/* @__PURE__ */ m(Re, {
				industry: n,
				x: e,
				y: t - 1,
				size: 19
			}),
			/* @__PURE__ */ m("rect", {
				x: e - Z / 2 + 1.5,
				y: t - Z / 2 + 1.5,
				width: 10,
				height: 9,
				rx: 2,
				fill: "var(--color-brass-cream)"
			}),
			/* @__PURE__ */ m("text", {
				x: e - Z / 2 + 6.5,
				y: t - Z / 2 + 8.5,
				textAnchor: "middle",
				fontSize: 7.5,
				fontWeight: 900,
				fill: "var(--color-brass-slate-deep)",
				children: r
			}),
			/* @__PURE__ */ m("circle", {
				cx: e + Z / 2 - 5.5,
				cy: t + Z / 2 - 5.5,
				r: 5.5,
				fill: s
			}),
			/* @__PURE__ */ m("image", {
				href: o,
				x: e + Z / 2 - 10,
				y: t + Z / 2 - 10,
				width: 9,
				height: 9,
				preserveAspectRatio: "xMidYMid meet",
				pointerEvents: "none"
			}),
			a > 0 && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
				cx: e + Z / 2 - 3,
				cy: t - Z / 2 + 3,
				r: 5.5,
				fill: "var(--color-brass-cream)",
				stroke: "var(--color-brass-copper)",
				strokeWidth: 1
			}), /* @__PURE__ */ m("text", {
				x: e + Z / 2 - 3,
				y: t - Z / 2 + 5.8,
				textAnchor: "middle",
				fontSize: 8,
				fontWeight: 900,
				fill: "var(--color-brass-slate-deep)",
				children: a
			})] }),
			i && /* @__PURE__ */ m("text", {
				x: e - Z / 2 + 4,
				y: t + Z / 2 - 3,
				fontSize: 8,
				fill: "var(--color-brass-cream)",
				children: "★"
			})
		]
	});
}
//#endregion
//#region src/games/brass/bot.ts
var Xe = {
	moneyW: .1,
	incBase: 1,
	incPerRound: .5,
	resFlipE: .7,
	sellReadyE: .7,
	sellFarE: .2,
	breweryE: .6,
	canalL1W: 0,
	overbuildLossW: 1.5,
	denyW: .5,
	buildW: 1.4,
	sellW: 1.3,
	merchantBeerW: 1,
	gloucesterW: 0,
	developW: 2,
	scoutBase: 4,
	scoutCardW: 1,
	networkW: 1,
	networkMerchantW: 1,
	merchantBaseW: 2,
	breweryBarrelW: 2,
	linkIconW: 1,
	loanW: 1,
	passW: -2,
	cardW: 0,
	railRatio: .7
};
function Ze(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function $(e) {
	if (e.startsWith("farm:")) return { farm: e.slice(5) };
	let [t, n] = e.split(":");
	return {
		city: t,
		slot: Number(n)
	};
}
function Qe(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of A) if (e.links[n.id] !== void 0) for (let e of n.nodes) for (let r of n.nodes) e !== r && (t.has(e) || t.set(e, []), t.get(e).push(r));
	return t;
}
function $e(e, t) {
	let n = /* @__PURE__ */ new Map([[t, 0]]), r = [t];
	for (; r.length > 0;) {
		let t = r.shift();
		for (let i of e.get(t) ?? []) n.has(i) || (n.set(i, n.get(t) + 1), r.push(i));
	}
	return n;
}
function et(e, t) {
	return new Set($e(e, t).keys());
}
function tt(e, t) {
	let n = /* @__PURE__ */ new Set();
	for (let [r, i] of Object.entries(e.board)) i.owner === t && n.add(r.startsWith("farm:") ? r.slice(5) : r.split(":")[0]);
	for (let [r, i] of Object.entries(e.links)) if (i === t) for (let e of A.find((e) => e.id === r).nodes) n.add(e);
	return n;
}
var nt = (e, t) => Object.values(e.board).some((e) => e.owner === t) || Object.values(e.links).some((e) => e === t), rt = (e, t, n) => t === 0 ? n : e[e.length - t], it = [
	"cotton",
	"manufacturer",
	"pottery",
	"brewery",
	"coal",
	"iron"
];
function at(e, t) {
	let n = 0;
	for (let t of Object.values(e.board)) t.industry === "iron" && !t.flipped && (n += t.cubes);
	let r = e.ironMarket, i = 0;
	for (let e = 0; e < t; e++) {
		if (n > 0) {
			n--;
			continue;
		}
		i += rt(P, r, 6), r > 0 && r--;
	}
	return i;
}
function ot(e, t, n) {
	if (n.length === 0) return 0;
	let r = Qe(e), i = n.map((e) => e.map((e) => $e(r, e))), a = [];
	for (let [n, r] of Object.entries(e.board)) {
		if (r.industry !== "coal" || r.flipped || r.cubes === 0) continue;
		let e = n.split(":")[0], o = i.map((t) => Math.min(...t.map((t) => t.get(e) ?? Infinity)));
		a.push({
			cubes: r.cubes,
			own: r.owner === t,
			d: o
		});
	}
	let o = (e) => E.some((t) => i[e].some((e) => e.has(t.id))), s = e.coalMarket, c = 0;
	for (let e = 0; e < n.length; e++) {
		a.sort((t, n) => t.d[e] - n.d[e] || (t.own === n.own ? 0 : t.own ? -1 : 1));
		let t = a.find((t) => t.cubes > 0 && t.d[e] < Infinity);
		if (t) {
			t.cubes--;
			continue;
		}
		if (!o(e)) return null;
		c += rt(N, s, 8), s > 0 && s--;
	}
	return c;
}
function st(e, t, n, r) {
	return ot(e, t, Array.from({ length: n }, () => r));
}
function ct(e, t, n) {
	let r = e.public, i = Qe(r), a = r.players.length, o = (r.deckCount + r.players.reduce((e, t) => e + t.handCount, 0)) / (2 * a), s = r.era === "canal" ? o * (1 + n.railRatio) : o, c = n.moneyW * (n.incBase + n.incPerRound * s), l = /* @__PURE__ */ new Map(), u = (e) => {
		let t = l.get(e);
		return t || (t = new Set($e(i, e).keys()), l.set(e, t)), t;
	};
	return {
		pub: r,
		me: t,
		P: n,
		adj: i,
		net: tt(r, t),
		homeless: !nt(r, t),
		hand: e.private?.hand ?? [],
		money: r.players[t].money,
		incomeVal: c,
		buyerReach: (e, t) => r.merchants.some((n) => (n.buys === "any" || n.buys === t) && u(e).has(n.location)),
		merchantReach: (e) => E.some((t) => u(e).has(t.id))
	};
}
function lt(e, t, n, r) {
	let { pub: i, P: a } = e;
	return t === "coal" ? e.merchantReach(n) && N.length - i.coalMarket >= r.produce ? 1 : a.resFlipE : t === "iron" ? P.length - i.ironMarket >= r.produce ? 1 : a.resFlipE : t === "brewery" ? a.breweryE : e.buyerReach(n, t) ? a.sellReadyE : a.sellFarE;
}
function ut(e, t, n) {
	let r = C(t, n);
	return r.vp + r.income * e;
}
function dt(e, t) {
	let { pub: n } = e;
	if (t.kind === "wildLocation" || t.kind === "wildIndustry") return 4;
	if (t.kind === "location") {
		let e = T.find((e) => e.id === t.city);
		return e.slots.some((t, r) => !n.board[`${e.id}:${r}`]) ? 2 : 0;
	}
	return T.some((r) => (e.homeless || e.net.has(r.id)) && r.slots.some((e, i) => !n.board[`${r.id}:${i}`] && e.some((e) => t.industries.includes(e)))) || D.some((n) => e.net.has(n.id) && t.industries.includes("brewery")) ? 3 : 1;
}
function ft(e) {
	let t = 0, n = Infinity;
	return e.hand.forEach((r, i) => {
		let a = dt(e, r);
		a < n && (n = a, t = i);
	}), t;
}
function pt(e) {
	let { pub: t, me: n, P: r, hand: i, money: a } = e, o = [], s = (s, c, l, u) => {
		let d = t.players[n].stacks[l], f = d?.[d.length - 1];
		if (f === void 0) return;
		let p = C(l, f);
		if ((t.era === "canal" ? !p.canal : !p.rail) || u && (u.level >= f || u.owner !== n && (l !== "coal" && l !== "iron" || Object.values(t.board).some((e) => e.industry === l && !e.flipped && e.cubes > 0) || (l === "coal" ? t.coalMarket : t.ironMarket) > 0))) return;
		let m = "city" in c ? c.city : c.farm, h = at(t, p.iron), g = st(t, n, p.coal, [m]);
		if (g === null) return;
		let _ = p.cost + h + g;
		if (a < _) return;
		let v = lt(e, l, m, p), y = r.buildW * v * ut(e.incomeVal, l, f) - _ * r.moneyW - r.cardW * dt(e, i[s]);
		if (t.era === "canal" && f === 1 && (y -= r.canalL1W * (1 - v)), l === "brewery") {
			let e = t.era === "canal" ? 1 : 2, i = Object.values(t.board).filter((e) => e.owner === n && !e.flipped && ee.includes(e.industry)).length;
			y += r.breweryBarrelW * e * (i > 0 ? 1 : .3);
		}
		if (u) {
			let t = ut(e.incomeVal, l, u.level);
			u.owner === n ? y -= r.overbuildLossW * t : y += r.denyW * t;
		}
		o.push({
			action: {
				type: "build",
				card: s,
				at: c,
				industry: l
			},
			score: y
		});
	};
	return i.forEach((r, i) => {
		let a, o = null, c = !1;
		r.kind === "location" ? a = T.filter((e) => e.id === r.city) : r.kind === "wildLocation" ? a = T : (o = r.kind === "industry" ? r.industries : it, a = e.homeless ? T : T.filter((t) => e.net.has(t.id)), c = o.includes("brewery") && (e.homeless || D.some((t) => e.net.has(t.id))));
		for (let e of a) {
			let r = Object.keys(t.board).filter((r) => r.startsWith(`${e.id}:`) && t.board[r].owner === n).length;
			e.slots.forEach((n, a) => {
				let c = `${e.id}:${a}`, l = t.board[c];
				if (l) {
					if (o && !o.includes(l.industry)) return;
					s(i, {
						city: e.id,
						slot: a
					}, l.industry, {
						owner: l.owner,
						level: l.level
					});
					return;
				}
				if (!(t.era === "canal" && r > 0)) for (let r of o ?? n) n.includes(r) && (n.length > 1 && e.slots.some((n, i) => n.length === 1 && n[0] === r && !t.board[`${e.id}:${i}`]) || s(i, {
					city: e.id,
					slot: a
				}, r, null));
			});
		}
		if (c) for (let n of D) t.board[`farm:${n.id}`] || (e.homeless || e.net.has(n.id)) && s(i, { farm: n.id }, "brewery", null);
	}), o;
}
function mt(e) {
	let { pub: t, me: n, P: r } = e, i = ft(e);
	if (e.hand[i] === void 0) return null;
	let a = [], o = 0, s = 0, c = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Set(), u = e.adj;
	for (let [i, d] of Object.entries(t.board)) {
		if (d.owner !== n || d.flipped || !ee.includes(d.industry)) continue;
		let f = i.startsWith("farm:") ? i.slice(5) : i.split(":")[0], p = new Set($e(u, f).keys()), m = C(d.industry, d.level);
		if (!t.merchants.some((e) => (e.buys === "any" || e.buys === d.industry) && p.has(e.location))) continue;
		let h = [], g = -1, _ = !1, v = 0, y = t.merchants.findIndex((e, t) => e.beer && !c.has(t) && (e.buys === "any" || e.buys === d.industry) && p.has(e.location));
		if (y >= 0 && h.length < m.beer) {
			g = y, h.push({
				kind: "merchant",
				index: y
			});
			let n = E.find((e) => e.id === t.merchants[y].location).bonus;
			n.kind === "vp" ? v = r.merchantBeerW * n.amount : n.kind === "money" ? v = r.merchantBeerW * n.amount * r.moneyW : n.kind === "income" ? v = r.merchantBeerW * n.amount * e.incomeVal : _ = !0;
		}
		let b = [];
		for (let [e, r] of Object.entries(t.board)) {
			if (h.length >= m.beer) break;
			if (r.industry !== "brewery" || r.flipped || r.cubes === 0 || l.has(e) || b.includes(e)) continue;
			let t = e.startsWith("farm:") ? e.slice(5) : e.split(":")[0];
			(r.owner === n || p.has(t)) && (h.push({
				kind: "tile",
				at: $(e)
			}), b.push(e));
		}
		if (!(h.length < m.beer)) {
			g >= 0 && (c.add(g), o += v, _ && (s++, o += r.gloucesterW));
			for (let e of b) l.add(e);
			a.push({
				tile: $(i),
				beers: h
			}), o += m.vp + m.income * e.incomeVal;
		}
	}
	if (a.length === 0) return null;
	let d = /* @__PURE__ */ new Map();
	for (let [e, r] of Object.entries(t.players[n].stacks)) d.set(e, [...r]);
	let f = [];
	for (let e = 0; e < s; e++) {
		let e = [...d.entries()].filter(([e, t]) => t.length > 0 && !C(e, t[t.length - 1]).noDevelop).sort((e, t) => t[1].length - e[1].length)[0];
		e && (f.push(e[0]), e[1].pop());
	}
	return f.length < s ? null : {
		action: {
			type: "sell",
			card: i,
			sales: a,
			bonusDevelop: f.length > 0 ? f : void 0
		},
		score: r.sellW * o - r.cardW * dt(e, e.hand[i])
	};
}
function ht(e) {
	let { pub: t, me: n, P: r } = e, i = ft(e);
	if (e.hand[i] === void 0) return [];
	let a = (n, i) => {
		if (i === void 0) return 0;
		let a = C(n, i);
		return (t.era === "canal" ? !a.canal : !a.rail) ? 0 : (n === "coal" || n === "iron" ? r.resFlipE : n === "brewery" ? r.breweryE : t.merchants.some((e) => e.buys === "any" || e.buys === n) ? r.sellReadyE : r.sellFarE) * ut(e.incomeVal, n, i);
	}, o = [];
	for (let e of it) {
		let r = t.players[n].stacks[e];
		if (!r || r.length === 0) continue;
		let i = r[r.length - 1];
		C(e, i).noDevelop || o.push({
			ind: e,
			gain: a(e, r[r.length - 2]) - a(e, i)
		});
	}
	if (o.length === 0) return [];
	let s = [], c = r.cardW * dt(e, e.hand[i]), l = (n, a) => {
		let o = at(t, n.length);
		if (e.money < o) return;
		let l = r.developW * a - o * r.moneyW - c;
		s.push({
			action: {
				type: "develop",
				card: i,
				industries: n
			},
			score: l
		});
	};
	for (let e of o) l([e.ind], e.gain);
	for (let e = 0; e < o.length; e++) for (let r = e; r < o.length; r++) {
		if (e === r) {
			let r = t.players[n].stacks[o[e].ind];
			if (r.length < 2 || C(o[e].ind, r[r.length - 2]).noDevelop) continue;
			let i = a(o[e].ind, r[r.length - 3]) - a(o[e].ind, r[r.length - 2]);
			l([o[e].ind, o[e].ind], o[e].gain + i);
			continue;
		}
		l([o[e].ind, o[r].ind], o[e].gain + o[r].gain);
	}
	return s;
}
function gt(e) {
	let { pub: t, P: n, hand: r } = e;
	if (r.length < 3 || r.some((e) => e.kind === "wildLocation" || e.kind === "wildIndustry") || t.wilds.location === 0 || t.wilds.industry === 0) return null;
	let i = r.map((t, n) => ({
		i: n,
		v: dt(e, t)
	})).sort((e, t) => e.v - t.v).slice(0, 3), a = n.scoutBase - n.scoutCardW * i.reduce((e, t) => e + t.v, 0);
	return {
		action: {
			type: "scout",
			cards: [
				i[0].i,
				i[1].i,
				i[2].i
			]
		},
		score: a
	};
}
function _t(e) {
	let { pub: t, me: n, P: r, money: i } = e, a = ft(e);
	if (e.hand[a] === void 0) return [];
	let o = r.cardW * dt(e, e.hand[a]), s = (i, a) => {
		if (a.has(i)) return 0;
		let o = 0, s = t.merchants.find((e) => e.location === i);
		if (s) {
			for (let [i, a] of Object.entries(t.board)) {
				if (a.owner !== n || a.flipped || !ee.includes(a.industry) || s.buys !== "any" && s.buys !== a.industry) continue;
				let t = i.startsWith("farm:") ? i.slice(5) : i.split(":")[0];
				e.buyerReach(t, a.industry) || (o += r.networkMerchantW * ut(e.incomeVal, a.industry, a.level) * (r.sellReadyE - r.sellFarE));
			}
			for (let i of e.hand) {
				let a = i.kind === "industry" ? i.industries : i.kind === "wildIndustry" ? it : null;
				if (!a) continue;
				let c = 0;
				for (let r of a) {
					if (!ee.includes(r) || s.buys !== "any" && s.buys !== r) continue;
					let i = t.players[n].stacks[r], a = i?.[i.length - 1];
					a !== void 0 && (c = Math.max(c, ut(e.incomeVal, r, a)));
				}
				o += r.merchantBaseW * c * (r.sellReadyE - r.sellFarE);
			}
		}
		let c = T.find((e) => e.id === i);
		if (c) {
			let a = 0;
			e.hand.forEach((o) => {
				let s = null;
				if (o.kind === "industry") s = o.industries;
				else if (o.kind === "wildIndustry") s = it;
				else if (o.kind === "location" && o.city !== c.id) return;
				c.slots.forEach((o, l) => {
					if (!t.board[`${c.id}:${l}`]) for (let c of s ?? o) {
						if (!o.includes(c)) continue;
						let s = t.players[n].stacks[c], l = s?.[s.length - 1];
						if (l === void 0) continue;
						let u = C(c, l);
						if (t.era === "canal" ? !u.canal : !u.rail) continue;
						let d = c === "coal" || c === "iron" ? r.resFlipE : c === "brewery" ? r.breweryE : e.buyerReach(i, c) ? r.sellReadyE : r.sellFarE;
						a = Math.max(a, d * ut(e.incomeVal, c, l));
					}
				});
			}), o += a;
		}
		return o;
	}, c = (e) => {
		let n = (e) => {
			if (E.some((t) => t.id === e)) return 2;
			let n = 0;
			for (let [r, i] of Object.entries(t.board)) i.flipped && (r.startsWith("farm:") ? r.slice(5) : r.split(":")[0]) === e && (n += C(i.industry, i.level).links);
			return n;
		};
		return n(e.nodes[0]) + n(e.nodes[e.nodes.length - 1]);
	}, l = (e) => (t.era === "canal" ? e.canal : e.rail) && t.links[e.id] === void 0, u = [];
	if (t.players[n].linkStock < 1) return u;
	let d = t.era === "canal" ? 3 : 5, f = [];
	for (let p of A) {
		if (!l(p) || !e.homeless && !p.nodes.some((t) => e.net.has(t))) continue;
		let m = 0;
		if (t.era === "rail") {
			let e = st(t, n, 1, [...p.nodes]);
			if (e === null) continue;
			m = e;
		}
		if (i < d + m) continue;
		let h = p.nodes.reduce((t, n) => t + s(n, e.net), 0), g = r.networkW * h + r.linkIconW * c(p) - (d + m) * r.moneyW - o;
		f.push({
			link: p,
			score: g,
			coal: m
		}), u.push({
			action: {
				type: "network",
				card: a,
				links: [p.id]
			},
			score: g
		});
	}
	if (t.era === "rail" && t.players[n].linkStock >= 2 && i >= 15) {
		let l = (() => {
			let e = null, r = null;
			for (let [i, a] of Object.entries(t.board)) a.industry !== "brewery" || a.flipped || a.cubes === 0 || (a.owner === n ? e = $(i) : r ??= $(i));
			return e ?? r;
		})();
		if (l) {
			let d = "city" in l ? l.city : l.farm, p = t.board["city" in l ? `${l.city}:${l.slot}` : `farm:${l.farm}`].owner === n, m = [...f].sort((e, t) => t.score - e.score).slice(0, 6);
			for (let f = 0; f < m.length; f++) for (let h = 0; h < m.length; h++) {
				if (f === h) continue;
				let g = new Set(e.net);
				for (let e of m[f].link.nodes) g.add(e);
				if (!m[h].link.nodes.some((e) => g.has(e))) continue;
				if (!p) {
					let t = /* @__PURE__ */ new Map();
					for (let [n, r] of e.adj) t.set(n, [...r]);
					for (let e of [m[f].link, m[h].link]) for (let n of e.nodes) for (let r of e.nodes) n !== r && (t.has(n) || t.set(n, []), t.get(n).push(r));
					let n = $e(t, d);
					if (!m[h].link.nodes.some((e) => n.has(e))) continue;
				}
				let _ = ot(t, n, [[...m[f].link.nodes], [...m[f].link.nodes, ...m[h].link.nodes]]);
				if (_ === null || i < 15 + _) continue;
				let v = m[f].link.nodes.reduce((t, n) => t + s(n, e.net), 0) + m[h].link.nodes.reduce((e, t) => e + s(t, g), 0), y = r.networkW * v + r.linkIconW * (c(m[f].link) + c(m[h].link)) - (15 + _) * r.moneyW - o;
				u.push({
					action: {
						type: "network",
						card: a,
						links: [m[f].link.id, m[h].link.id],
						beerFrom: l
					},
					score: y
				});
			}
		}
	}
	return u;
}
function vt(e) {
	let { pub: t, me: n, P: r } = e;
	if (t.players[n].incomeLevel - 3 < -10) return null;
	let i = ft(e);
	if (e.hand[i] === void 0) return null;
	let a = r.loanW * (30 * r.moneyW - 3 * e.incomeVal) - r.cardW * dt(e, e.hand[i]);
	return {
		action: {
			type: "loan",
			card: i
		},
		score: a
	};
}
function yt(e) {
	let t = ft(e);
	return {
		action: {
			type: "pass",
			card: t
		},
		score: e.P.passW - e.P.cardW * dt(e, e.hand[t])
	};
}
var bt = ((e = {}) => {
	let t = {
		...Xe,
		...e
	};
	return (e, n) => {
		let r = e.public;
		if (r.phase !== "play") return null;
		let i = r.players.findIndex((e) => e.rid === n.rid);
		if (i < 0) return null;
		let a = r.pendingDebt.find((e) => e.rid === n.rid);
		if (a) {
			let e = [], t = 0, n = Object.entries(r.board).filter(([, e]) => e.owner === i).sort((e, t) => C(e[1].industry, e[1].level).cost - C(t[1].industry, t[1].level).cost);
			for (let [i] of n) {
				if (t >= a.need) break;
				e.push($(i)), t += Math.floor(C(r.board[i].industry, r.board[i].level).cost / 2);
			}
			return e.length > 0 ? { action: {
				type: "payDebt",
				tiles: e
			} } : null;
		}
		if (r.order[r.turnIdx] !== i || r.actionsLeft === 0 || (e.private?.hand ?? []).length === 0) return null;
		let o = ct(e, i, t), s = mt(o), c = gt(o), l = vt(o), u = [
			...pt(o),
			...ht(o),
			..._t(o),
			...s ? [s] : [],
			...c ? [c] : [],
			...l ? [l] : [],
			yt(o)
		];
		return n.difficulty === "weak" ? { action: Ze(u).action } : (u.sort((e, t) => t.score - e.score), { action: u[0].action });
	};
})(), xt = (e, t, n) => {
	let r = (e) => {
		let r = "city" in e ? e.city : e.farm, i = t.public.board["city" in e ? `${e.city}:${e.slot}` : `farm:${e.farm}`], a = n(X[r]);
		return i ? `${a}·${n(Be[i.industry])}` : a;
	};
	switch (e.type) {
		case "build": {
			let t = n(X["city" in e.at ? e.at.city : e.at.farm]), r = e.industry ? n(Be[e.industry]) : "";
			return `${n("games.brass.action.build")}:${t} ${r}`;
		}
		case "network": {
			let t = e.links.map((e) => A.find((t) => t.id === e)?.nodes.map((e) => n(X[e])).join("—") ?? e).join(", ");
			return `${n("games.brass.action.network")}:${t}`;
		}
		case "develop": return `${n("games.brass.action.develop")}:${e.industries.map((e) => n(Be[e])).join(", ")}`;
		case "sell": return `${n("games.brass.action.sell")}:${e.sales.map((e) => r(e.tile)).join(", ")}`;
		case "loan": return n("games.brass.action.loan");
		case "scout": return n("games.brass.action.scout");
		case "pass": return n("games.brass.action.pass");
		case "payDebt": return `${n("games.brass.payDebt")}:${e.tiles.map((e) => r(e)).join(", ")}`;
	}
}, St = [
	"cotton",
	"manufacturer",
	"pottery",
	"brewery",
	"coal",
	"iron"
], Ct = {
	build: "games.brass.action.build",
	network: "games.brass.action.network",
	develop: "games.brass.action.develop",
	sell: "games.brass.action.sell"
}, wt = (e) => e.startsWith("farm:") ? e.slice(5) : e.split(":")[0];
function Tt(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ m(Et, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Et({ pub: e, priv: t, members: n, myRid: r, send: o }) {
	let s = c(), f = (e) => n.find((t) => t.rid === e)?.name ?? e, g = e.players.findIndex((e) => e.rid === r), _ = e.players[g], v = t?.hand ?? [], y = e.phase === "play" && g >= 0 && e.order[e.turnIdx] === g && e.actionsLeft > 0, b = e.pendingDebt.find((e) => e.rid === r), x = e.pendingDebt.find((e) => e.rid !== r), S = e.phase === "play" ? e.players[e.order[e.turnIdx]]?.rid : void 0;
	u(y || !!b, l);
	let [w, O] = i("idle"), [k, j] = i(null), [M, F] = i(null), [I, te] = i([]), [L, R] = i(null), [z, B] = i([]), [V, ne] = i([]), [H, re] = i([]), [ie, ae] = i([]), [oe, se] = i([]), [U, W] = i(null), [ce, G] = i(!1), [le, K] = i(!1), [ue, q] = i(!1), [de, fe] = i(null), J = () => {
		O("idle"), j(null), F(null), te([]), R(null), B([]), ne([]), re([]), ae([]), se([]), W(null), G(!1), K(!1), q(!1), fe(null);
	}, pe = `${e.phase}|${e.era}|${e.round}|${e.turnIdx}|${e.actionsLeft}|${v.length}|${b?.need ?? ""}`, [me, he] = i(pe);
	me !== pe && (he(pe), J());
	let ge = Qe(e), Y = tt(e, g), _e = g >= 0 && !nt(e, g), ve = (e) => {
		let t = _?.stacks[e];
		return t && t.length > 0 ? t[t.length - 1] : void 0;
	}, ye = (t) => {
		let n = ve(t);
		if (n === void 0) return !1;
		let r = C(t, n);
		return e.era === "canal" ? r.canal : r.rail;
	}, be = (t) => {
		let n = Qe(e);
		for (let e of t) {
			let t = A.find((t) => t.id === e);
			for (let e of t.nodes) for (let r of t.nodes) e !== r && (n.has(e) || n.set(e, []), n.get(e).push(r));
		}
		return n;
	}, xe = (() => {
		if (w !== "build" || k == null || !y || !_) return null;
		let t = v[k];
		if (!t) return null;
		let n = /* @__PURE__ */ new Map(), r, i = null;
		t.kind === "location" ? r = [t.city] : t.kind === "wildLocation" ? r = T.map((e) => e.id) : (i = t.kind === "industry" ? t.industries : St, r = _e ? T.map((e) => e.id) : T.filter((e) => Y.has(e.id)).map((e) => e.id));
		for (let t of r) {
			let r = T.find((e) => e.id === t), a = r.slots.some((n, r) => e.board[`${t}:${r}`]?.owner === g);
			r.slots.forEach((o, s) => {
				let c = `${t}:${s}`;
				if (e.board[c] || e.era === "canal" && a) return;
				let l = (i ?? o).filter((e) => o.includes(e) && ye(e));
				l = l.filter((n) => o.length === 1 || !r.slots.some((r, i) => r.length === 1 && r[0] === n && !e.board[`${t}:${i}`])), l.length > 0 && n.set(c, l);
			});
		}
		if (i?.includes("brewery") && ye("brewery")) for (let t of D) e.board[`farm:${t.id}`] || n.set(`farm:${t.id}`, ["brewery"]);
		for (let [r, a] of Object.entries(e.board)) {
			if (a.owner !== g) continue;
			let e = ve(a.industry);
			if (!(e === void 0 || e <= a.level || !ye(a.industry))) {
				if (i) {
					if (!i.includes(a.industry) || !_e && !Y.has(wt(r))) continue;
				} else if (t.kind === "location" && r.split(":")[0] !== t.city) continue;
				n.set(r, [a.industry]);
			}
		}
		for (let t of ["coal", "iron"]) {
			if (!i?.includes(t) || !ye(t) || Object.values(e.board).some((e) => e.industry === t && !e.flipped && e.cubes > 0) || (t === "coal" ? e.coalMarket : e.ironMarket) !== 0) continue;
			let r = ve(t);
			for (let [i, a] of Object.entries(e.board)) a.owner === g || a.industry !== t || r === void 0 || r <= a.level || (_e || Y.has(wt(i))) && n.set(i, [t]);
		}
		return n;
	})(), Se = (t) => {
		if (e.era === "canal") return !0;
		let n = A.find((e) => e.id === t), r = be([...I, t]), i = /* @__PURE__ */ new Set();
		for (let e of [n.nodes[0], n.nodes[n.nodes.length - 1]]) for (let t of et(r, e)) i.add(t);
		return E.some((e) => i.has(e.id)) ? !0 : Object.entries(e.board).some(([e, t]) => t.industry === "coal" && !t.flipped && t.cubes > 0 && i.has(wt(e)));
	}, Ce = (() => {
		if (w !== "network" || k == null || !y) return null;
		let t = Math.min(e.era === "canal" ? 1 : 2, _?.linkStock ?? 0);
		if (I.length >= t) return /* @__PURE__ */ new Set();
		let n = new Set(Y);
		for (let e of I) for (let t of A.find((t) => t.id === e).nodes) n.add(t);
		let r = /* @__PURE__ */ new Set();
		for (let t of A) e.links[t.id] !== void 0 || I.includes(t.id) || (e.era === "canal" ? !t.canal : !t.rail) || (_e || t.nodes.some((e) => n.has(e))) && Se(t.id) && r.add(t.id);
		return r;
	})(), we = I.length === 2 ? (() => {
		let t = be(I), n = A.find((e) => e.id === I[1]), r = /* @__PURE__ */ new Set();
		for (let e of [n.nodes[0], n.nodes[n.nodes.length - 1]]) for (let n of et(t, e)) r.add(n);
		return Object.entries(e.board).filter(([e, t]) => t.industry !== "brewery" || t.flipped || t.cubes === 0 ? !1 : t.owner === g || r.has(wt(e))).map(([e]) => e);
	})() : [], Te = (t, n, r, i) => {
		let a = e.board[t];
		if (!a) return null;
		let o = C(a.industry, a.level), s = et(ge, wt(t)), c = [], l = !1, u = e.merchants.findIndex((e, t) => e.beer && !n.has(t) && (e.buys === "any" || e.buys === a.industry) && s.has(e.location));
		u >= 0 && c.length < o.beer && (c.push({
			kind: "merchant",
			index: u
		}), l = e.merchants[u].location === "gloucester");
		for (let [t, n] of Object.entries(e.board)) {
			if (c.length >= o.beer) break;
			if (n.industry !== "brewery" || n.flipped || n.cubes <= (r.get(t) ?? 0) || n.owner !== g && !s.has(wt(t))) continue;
			let e = n.cubes - (r.get(t) ?? 0);
			for (let n = 0; n < e && c.length < o.beer; n++) c.push({
				kind: "tile",
				at: $(t)
			});
		}
		if (c.length < o.beer) return null;
		if (i) {
			c.some((e) => e.kind === "merchant") && n.add(u);
			for (let e of c) if (e.kind === "tile") {
				let t = "city" in e.at ? `${e.at.city}:${e.at.slot}` : `farm:${e.at.farm}`;
				r.set(t, (r.get(t) ?? 0) + 1);
			}
		}
		return {
			beers: c,
			gloucester: l
		};
	}, Ee = /* @__PURE__ */ new Map(), De = 0;
	{
		let e = /* @__PURE__ */ new Set(), t = /* @__PURE__ */ new Map();
		for (let n of V) {
			let r = Te(n, e, t, !0);
			r && (Ee.set(n, r.beers), r.gloucester && De++);
		}
	}
	let Oe = (() => {
		let t = /* @__PURE__ */ new Set();
		if (w !== "sell" || !y) return t;
		let n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Map();
		for (let e of V) Te(e, n, r, !0);
		for (let [i, a] of Object.entries(e.board)) {
			if (a.owner !== g || a.flipped || !ee.includes(a.industry) || V.includes(i)) continue;
			let o = et(ge, wt(i));
			e.merchants.some((e) => (e.buys === "any" || e.buys === a.industry) && o.has(e.location)) && Te(i, new Set(n), new Map(r), !1) && t.add(i);
		}
		return t;
	})(), ke = (e, t = []) => {
		let n = _?.stacks[e] ?? [], r = n[n.length - 1 - t.filter((t) => t === e).length];
		return r !== void 0 && !C(e, r).noDevelop;
	}, Ae = oe.reduce((t, n) => {
		let r = e.board[n];
		return t + (r ? Math.floor(C(r.industry, r.level).cost / 2) : 0);
	}, 0), je = b && Ae < b.need ? new Set(Object.entries(e.board).filter(([e, t]) => t.owner === g && !oe.includes(e)).map(([e]) => e)) : /* @__PURE__ */ new Set(), Me = y && v.length >= 3 && !v.some((e) => e.kind === "wildLocation" || e.kind === "wildIndustry") && e.wilds.location > 0 && e.wilds.industry > 0, Ne = (e, t) => {
		o({
			type: "build",
			card: k,
			at: $(e),
			industry: t
		}), J();
	}, Pe = (e) => {
		let t = xe?.get(e);
		if (t) {
			if (U?.key === e) {
				W(null);
				return;
			}
			t.length === 1 ? W({
				key: e,
				ind: t[0]
			}) : F({
				key: e,
				inds: t
			});
		}
	}, Fe = (e) => {
		I.includes(e) ? (te((t) => t.filter((t) => t !== e)), R(null)) : Ce?.has(e) && (te((t) => [...t, e]), R(null));
	}, Ie = () => {
		o({
			type: "network",
			card: k,
			links: I,
			beerFrom: L ? $(L) : void 0
		}), J();
	}, Re = () => {
		o({
			type: "sell",
			card: k,
			sales: V.map((e) => ({
				tile: $(e),
				beers: Ee.get(e)
			})),
			bonusDevelop: H.length > 0 ? H : void 0
		}), J();
	}, Z = b ? { tiles: /* @__PURE__ */ new Set([...je, ...oe]) } : y ? w === "build" && xe ? { slots: new Set(xe.keys()) } : w === "network" && Ce ? { links: /* @__PURE__ */ new Set([...Ce, ...I]) } : w === "sell" ? { tiles: /* @__PURE__ */ new Set([...Oe, ...V]) } : null : null, Ve = b ? s("games.brass.debtYou", { n: b.need }) : x ? s("games.brass.debtWait", { name: f(x.rid) }) : e.phase === "done" ? `🏆 ${f(e.winner ?? "")}` : y ? s("games.brass.turnYou", { n: e.actionsLeft }) : s("games.brass.turnWait", { name: f(S ?? "") }), He = `${s(e.era === "canal" ? "games.brass.eraCanal" : "games.brass.eraRail")} · ${s("games.brass.roundLabel", { n: e.round })}`, Ue = k == null ? void 0 : v[k], We = de ?? (w === "build" && Ue?.kind === "location" ? Ue.city : null), Q = U ? C(U.ind, ve(U.ind) ?? 1) : null, Ge = V.reduce((e, t) => e + (Ee.get(t)?.length ?? 0), 0), Ke = new Set(b ? oe : w === "sell" ? V : U ? [U.key] : []), qe = xe ? [...new Set([...xe.keys()].map(wt))] : [], Ye = b ? s("games.brass.debtYou", { n: b.need }) : s(U ? "games.brass.confirm" : w === "build" ? "games.brass.selectSlot" : w === "network" ? "games.brass.selectLink" : w === "sell" ? "games.brass.selectTile" : w === "develop" ? "games.brass.selectIndustry" : w === "scout" ? "games.brass.scoutPick" : k == null ? "games.brass.selectCard" : "games.brass.selectAction"), Xe = (e) => {
		o({
			type: e,
			card: k
		}), J();
	};
	return /* @__PURE__ */ m("div", {
		className: "brass-screen",
		children: /* @__PURE__ */ m(d, {
			adaptive: !0,
			className: "brass-layout",
			scroll: !1,
			actionsHeight: "brass-console-height",
			banner: /* @__PURE__ */ h("div", {
				className: "brass-banner",
				children: [/* @__PURE__ */ h("div", {
					className: "brass-banner__top",
					children: [/* @__PURE__ */ h("div", {
						className: "brass-banner__identity",
						children: [/* @__PURE__ */ m("strong", { children: s("games.brass.name") }), /* @__PURE__ */ m("span", { children: He })]
					}), /* @__PURE__ */ m("p", {
						className: "brass-banner__turn",
						role: "status",
						children: Ve
					})]
				}), /* @__PURE__ */ m("div", {
					className: "brass-players",
					role: "list",
					children: e.players.map((t) => {
						let i = n.find((e) => e.rid === t.rid), o = t.rid === S || e.pendingDebt.some((e) => e.rid === t.rid);
						return /* @__PURE__ */ h("div", {
							className: `brass-player ${o ? "brass-player--active" : ""}`,
							role: "listitem",
							children: [
								/* @__PURE__ */ m("span", {
									className: "brass-player__portrait",
									children: /* @__PURE__ */ m("img", {
										src: `./${a[(i?.avatar ?? 0) % a.length]}`,
										alt: ""
									})
								}),
								/* @__PURE__ */ h("span", {
									className: "brass-player__body",
									children: [/* @__PURE__ */ h("span", {
										className: "brass-player__name",
										children: [/* @__PURE__ */ m("strong", { children: f(t.rid) }), t.rid === r && /* @__PURE__ */ m("em", { children: s("games.brass.you") })]
									}), /* @__PURE__ */ h("span", {
										className: "brass-player__numbers",
										children: [
											/* @__PURE__ */ h("span", { children: ["£", t.money] }),
											/* @__PURE__ */ m("span", { children: s("games.brass.incomeLabel", { n: t.incomeLevel }) }),
											/* @__PURE__ */ m("span", { children: s("games.brass.vpLabel", { n: t.vp }) })
										]
									})]
								}),
								/* @__PURE__ */ m("span", {
									className: "brass-player__hand",
									children: t.handCount
								})
							]
						}, t.rid);
					})
				})]
			}),
			overlay: /* @__PURE__ */ h("div", {
				className: "brass-overlays",
				children: [
					e.eraScores && e.eraScores.length > 0 && /* @__PURE__ */ m("div", {
						className: "brass-overlays__score",
						children: e.eraScores.map((e, t) => /* @__PURE__ */ h("span", { children: [
							f(e.rid),
							" ",
							s("games.brass.industryVp", { n: e.industryVp }),
							" + ",
							s("games.brass.linkVp", { n: e.linkVp })
						] }, `${e.era}-${e.rid}-${t}`))
					}),
					M && /* @__PURE__ */ h("div", {
						className: "brass-overlay brass-overlay--choices",
						children: [
							/* @__PURE__ */ m("strong", { children: s("games.brass.selectIndustry") }),
							/* @__PURE__ */ m("div", {
								className: "brass-overlay__row",
								children: M.inds.map((e) => /* @__PURE__ */ h("button", {
									type: "button",
									onClick: () => {
										W({
											key: M.key,
											ind: e
										}), F(null);
									},
									children: [/* @__PURE__ */ m(ze, {
										industry: e,
										size: 18
									}), s(Be[e])]
								}, e))
							}),
							/* @__PURE__ */ m("button", {
								className: "brass-overlay__close",
								type: "button",
								onClick: () => F(null),
								children: s("games.brass.cancel")
							})
						]
					}),
					ue && /* @__PURE__ */ h("div", {
						className: "brass-overlay brass-overlay--list",
						children: [
							/* @__PURE__ */ m("strong", { children: s("games.brass.candidateCities", { n: qe.length }) }),
							/* @__PURE__ */ m("div", {
								className: "brass-overlay__row",
								children: qe.map((e) => /* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => {
										fe(e), q(!1);
									},
									children: s(X[e])
								}, e))
							}),
							/* @__PURE__ */ m("button", {
								className: "brass-overlay__close",
								type: "button",
								onClick: () => q(!1),
								children: s("games.brass.cancel")
							})
						]
					}),
					le && /* @__PURE__ */ h("div", {
						className: "brass-overlay brass-overlay--market",
						children: [
							/* @__PURE__ */ m("strong", { children: s("games.brass.marketPrices") }),
							/* @__PURE__ */ h("div", {
								className: "brass-overlay__prices",
								children: [/* @__PURE__ */ m("span", { children: s("games.brass.coalMarket") }), N.map((t, n) => /* @__PURE__ */ m("b", {
									className: n >= N.length - e.coalMarket ? "filled" : "",
									children: t
								}, `coal-${n}`))]
							}),
							/* @__PURE__ */ h("div", {
								className: "brass-overlay__prices",
								children: [/* @__PURE__ */ m("span", { children: s("games.brass.ironMarket") }), P.map((t, n) => /* @__PURE__ */ m("b", {
									className: n >= P.length - e.ironMarket ? "filled" : "",
									children: t
								}, `iron-${n}`))]
							}),
							/* @__PURE__ */ m("button", {
								className: "brass-overlay__close",
								type: "button",
								onClick: () => K(!1),
								children: s("games.brass.cancel")
							})
						]
					}),
					ce && /* @__PURE__ */ h("div", {
						className: "brass-overlay brass-overlay--more",
						children: [
							/* @__PURE__ */ m("strong", { children: s("games.brass.moreActions") }),
							/* @__PURE__ */ h("button", {
								type: "button",
								disabled: k == null || (_?.incomeLevel ?? -10) - 3 < -10,
								onClick: () => Xe("loan"),
								children: [/* @__PURE__ */ m("b", { children: s("games.brass.action.loan") }), /* @__PURE__ */ m("span", { children: s("games.brass.loanEffect") })]
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								disabled: !Me,
								onClick: () => {
									O("scout"), G(!1), j(null);
								},
								children: [/* @__PURE__ */ m("b", { children: s("games.brass.action.scout") }), /* @__PURE__ */ m("span", { children: s("games.brass.scoutEffect") })]
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								disabled: k == null,
								onClick: () => Xe("pass"),
								children: [/* @__PURE__ */ m("b", { children: s("games.brass.action.pass") }), /* @__PURE__ */ m("span", { children: s("games.brass.passEffect") })]
							}),
							/* @__PURE__ */ m("button", {
								className: "brass-overlay__close",
								type: "button",
								onClick: () => G(!1),
								children: s("games.brass.cancel")
							})
						]
					}),
					w === "network" && I.length === 2 && /* @__PURE__ */ h("div", {
						className: "brass-overlay brass-overlay--choices",
						children: [/* @__PURE__ */ m("strong", { children: s("games.brass.selectBeer") }), /* @__PURE__ */ m("div", {
							className: "brass-overlay__row",
							children: we.map((t) => {
								let n = e.board[t]?.owner, r = n === void 0 ? void 0 : e.players[n]?.rid;
								return /* @__PURE__ */ h("button", {
									type: "button",
									className: L === t ? "selected" : "",
									onClick: () => R((e) => e === t ? null : t),
									children: [/* @__PURE__ */ m(ze, {
										industry: "brewery",
										size: 18
									}), n === g ? s("games.brass.beerFromOwn") : s("games.brass.beerFromOpponent", { name: f(r ?? "") })]
								}, t);
							})
						})]
					}),
					w === "sell" && V.length > 0 && /* @__PURE__ */ h("div", {
						className: "brass-overlay brass-overlay--summary",
						children: [
							/* @__PURE__ */ h("strong", { children: [
								s("games.brass.action.sell"),
								" · ",
								V.length
							] }),
							/* @__PURE__ */ h("span", { children: ["🍺 ×", Ge] }),
							De > 0 && /* @__PURE__ */ h("span", { children: [
								s("games.brass.bonusDevelop"),
								" ",
								H.length,
								"/",
								De
							] })
						]
					}),
					U && Q && !M && /* @__PURE__ */ h("div", {
						className: "brass-overlay brass-overlay--build",
						children: [/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ h("strong", { children: [
							s(X[wt(U.key)]),
							" · ",
							s(Be[U.ind]),
							" ",
							Q.level
						] }), /* @__PURE__ */ m("span", { children: Q.cost > (_?.money ?? 0) ? s("games.brass.errCantAfford") : s("games.brass.buildPreview") })] }), /* @__PURE__ */ h("p", { children: [
							"£",
							Q.cost,
							Q.coal > 0 && `  ·  ${Le.coal.icon} ×${Q.coal}`,
							Q.iron > 0 && `  ·  ${Le.iron.icon} ×${Q.iron}`
						] })]
					})
				]
			}),
			actions: /* @__PURE__ */ h("div", {
				className: "brass-console",
				children: [
					/* @__PURE__ */ h("div", {
						className: "brass-console__markets",
						children: [/* @__PURE__ */ m(Ot, {
							label: s("games.brass.coalMarket"),
							kind: "coal",
							prices: N,
							count: e.coalMarket,
							emptyPrice: 8,
							onClick: () => {
								K((e) => !e), G(!1), q(!1);
							}
						}), /* @__PURE__ */ m(Ot, {
							label: s("games.brass.ironMarket"),
							kind: "iron",
							prices: P,
							count: e.ironMarket,
							emptyPrice: 6,
							onClick: () => {
								K((e) => !e), G(!1), q(!1);
							}
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "brass-mat",
						children: [/* @__PURE__ */ m("span", {
							className: "brass-mat__label",
							children: s("games.brass.yourMat")
						}), /* @__PURE__ */ m("div", {
							className: "brass-mat__tiles",
							children: St.map((e) => {
								let t = _?.stacks[e] ?? [], n = t[t.length - 1], r = w === "sell" && De > H.length, i = w === "develop" ? z.length < 2 && ke(e, z) : r && ke(e, H), a = w === "develop" ? z.filter((t) => t === e).length : H.filter((t) => t === e).length;
								return /* @__PURE__ */ h("button", {
									type: "button",
									disabled: !i,
									className: `brass-mat__tile ${i ? "is-pickable" : ""} ${a > 0 ? "is-selected" : ""}`,
									title: s(Be[e]),
									onClick: () => {
										w === "develop" && z.length < 2 && ke(e, z) ? B((t) => [...t, e]) : r && ke(e, H) && re((t) => [...t, e]);
									},
									children: [
										/* @__PURE__ */ m(ze, {
											industry: e,
											size: 21
										}),
										/* @__PURE__ */ m("span", { children: n === void 0 ? "—" : `${n} ×${t.length}` }),
										a > 0 && /* @__PURE__ */ h("i", { children: ["✓", a > 1 ? a : ""] })
									]
								}, e);
							})
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "brass-hand",
						children: [/* @__PURE__ */ h("span", {
							className: "brass-hand__label",
							children: [
								s("games.brass.handLabel"),
								" ",
								/* @__PURE__ */ m("b", { children: v.length }),
								/* @__PURE__ */ h("span", {
									className: "brass-hand__supply",
									children: [
										s("games.brass.deckLabel", { n: e.deckCount }),
										" · ",
										s("games.brass.wildLabel"),
										" ",
										e.wilds.location,
										"+",
										e.wilds.industry
									]
								})
							]
						}), /* @__PURE__ */ m("div", {
							className: "brass-hand__cards",
							children: v.map((e, t) => /* @__PURE__ */ m(Dt, {
								card: e,
								selected: w === "scout" ? ie.includes(t) : k === t,
								disabled: !y || !!b,
								onClick: () => {
									if (w === "scout") {
										ae((e) => e.includes(t) ? e.filter((e) => e !== t) : e.length < 3 ? [...e, t] : e);
										return;
									}
									j((e) => e === t ? null : t), O("idle"), W(null), F(null), q(!1), fe(null);
								}
							}, `${t}-${e.kind}`))
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "brass-console__guide",
						children: [/* @__PURE__ */ m("strong", { children: Ye }), /* @__PURE__ */ h("span", { children: [
							s("games.brass.deckLabel", { n: e.deckCount }),
							" · ",
							s("games.brass.wildLabel"),
							" ",
							e.wilds.location,
							"+",
							e.wilds.industry
						] })]
					}),
					/* @__PURE__ */ m("div", {
						className: "brass-actions",
						children: b ? /* @__PURE__ */ h(p, { children: [
							/* @__PURE__ */ h("span", {
								className: "brass-actions__hint",
								children: [
									"£",
									Ae,
									"/£",
									b.need
								]
							}),
							/* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => se([]),
								children: s("games.brass.cancel")
							}),
							/* @__PURE__ */ m("button", {
								type: "button",
								className: "is-primary",
								disabled: oe.length === 0 || Ae < b.need,
								onClick: () => {
									o({
										type: "payDebt",
										tiles: oe.map($)
									}), J();
								},
								children: s("games.brass.payDebt")
							})
						] }) : w === "idle" ? /* @__PURE__ */ h(p, { children: [[
							"build",
							"network",
							"develop",
							"sell"
						].map((e) => /* @__PURE__ */ m("button", {
							type: "button",
							className: k == null ? "" : "is-ready",
							disabled: !y || k == null,
							onClick: () => {
								O(e), G(!1), K(!1);
							},
							children: s(Ct[e])
						}, e)), /* @__PURE__ */ m("button", {
							type: "button",
							onClick: () => {
								G((e) => !e), K(!1);
							},
							children: s("games.brass.moreActions")
						})] }) : /* @__PURE__ */ h(p, { children: [
							/* @__PURE__ */ m("span", {
								className: "brass-actions__hint",
								children: Ye
							}),
							w === "build" && qe.length > 1 && /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => {
									q((e) => !e), K(!1);
								},
								children: s("games.brass.candidateCities", { n: qe.length })
							}),
							/* @__PURE__ */ m("button", {
								type: "button",
								onClick: J,
								children: s("games.brass.cancel")
							}),
							w === "build" && /* @__PURE__ */ m("button", {
								type: "button",
								className: "is-primary",
								disabled: !U || !!(Q && _ && _.money < Q.cost),
								onClick: () => U && Ne(U.key, U.ind),
								children: s("games.brass.confirm")
							}),
							w === "network" && /* @__PURE__ */ m("button", {
								type: "button",
								className: "is-primary",
								disabled: I.length === 0 || I.length > (_?.linkStock ?? 0) || (e.era === "canal" ? (_?.money ?? 0) < 3 : I.length === 1 ? (_?.money ?? 0) < 5 : (_?.money ?? 0) < 15 || L == null),
								onClick: Ie,
								children: I.length === 2 ? s("games.brass.doubleRail") : s("games.brass.confirm")
							}),
							w === "develop" && /* @__PURE__ */ m("button", {
								type: "button",
								className: "is-primary",
								disabled: z.length === 0,
								onClick: () => {
									o({
										type: "develop",
										card: k,
										industries: z
									}), J();
								},
								children: s("games.brass.confirm")
							}),
							w === "sell" && /* @__PURE__ */ m("button", {
								type: "button",
								className: "is-primary",
								disabled: V.length === 0 || V.some((e) => !Ee.has(e)) || H.length !== De,
								onClick: Re,
								children: s("games.brass.confirm")
							}),
							w === "scout" && /* @__PURE__ */ m("button", {
								type: "button",
								className: "is-primary",
								disabled: ie.length !== 3,
								onClick: () => {
									o({
										type: "scout",
										cards: [
											ie[0],
											ie[1],
											ie[2]
										]
									}), J();
								},
								children: s("games.brass.confirm")
							})
						] })
					})
				]
			}),
			children: /* @__PURE__ */ h("div", {
				className: "brass-map-wrap",
				children: [/* @__PURE__ */ m(Je, {
					pub: e,
					members: n,
					hot: Z,
					pickedLinks: new Set(I),
					pickedTiles: Ke,
					focusNode: We,
					onTapSlot: w === "build" ? Pe : void 0,
					onTapLink: w === "network" ? Fe : void 0,
					onTapTile: b ? (e) => se((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]) : w === "sell" ? (e) => {
						ne((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]), re([]);
					} : void 0
				}, We ?? "map"), /* @__PURE__ */ m("div", {
					className: "brass-map-wrap__hint",
					children: Ye
				})]
			})
		})
	});
}
function Dt({ card: e, selected: t, disabled: n, onClick: r }) {
	let i = c(), a = e.kind === "location" ? i(X[e.city]) : e.kind === "industry" ? e.industries.map((e) => i(Be[e])).join(" / ") : i(e.kind === "wildLocation" ? "games.brass.cardWildLocation" : "games.brass.cardWildIndustry"), o = e.kind === "location" || e.kind === "wildLocation" ? i("games.brass.cardLocation") : i("games.brass.cardIndustry");
	return /* @__PURE__ */ h("button", {
		type: "button",
		className: `brass-hand__card ${t ? "is-selected" : ""}`,
		disabled: n,
		onClick: r,
		"aria-pressed": t,
		title: a,
		children: [
			/* @__PURE__ */ m("span", {
				className: "brass-hand__type",
				children: o
			}),
			/* @__PURE__ */ m("span", {
				className: "brass-hand__symbol",
				children: e.kind === "industry" ? e.industries.map((t) => /* @__PURE__ */ m(ze, {
					industry: t,
					size: e.industries.length > 1 ? 17 : 24
				}, t)) : e.kind === "wildIndustry" ? "★" : "⌖"
			}),
			/* @__PURE__ */ m("span", {
				className: "brass-hand__name",
				children: a
			})
		]
	});
}
function Ot({ label: e, kind: t, prices: n, count: r, emptyPrice: i, onClick: a }) {
	let o = c(), s = r > 0 ? n[Math.max(0, n.length - r)] : i;
	return /* @__PURE__ */ h("button", {
		type: "button",
		className: "brass-market",
		onClick: a,
		"aria-label": `${e} · £${s} · ${o("games.brass.marketStock", { n: r })}`,
		children: [/* @__PURE__ */ h("span", {
			className: "brass-market__info",
			children: [/* @__PURE__ */ m("strong", { children: e }), /* @__PURE__ */ h("small", { children: [
				/* @__PURE__ */ m(ze, {
					industry: t,
					size: 13
				}),
				" ",
				o("games.brass.marketStock", { n: r })
			] })]
		}), /* @__PURE__ */ h("b", {
			className: "brass-market__price",
			children: ["£", s]
		}, `${t}-${r}`)]
	});
}
//#endregion
//#region src/games/brass/game-over.tsx
function kt({ public: e, result: t, members: n, myRid: l, onPlayAgain: u, onBackToLobby: d, hintCount: f }) {
	let x = e, S = c(), w = s((e) => e.locale), [T, E] = i(!0), [D, O] = i(null), k = r(null), A = r(null), j = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? g(e) === null ? t.name : o(w, t.avatar) : e;
	}, M = (e) => S(X[e.startsWith("farm:") ? e.slice(5) : e.split(":")[0]]), N = (e) => {
		O(null), E(e), requestAnimationFrame(() => (e ? A : k).current?.focus());
	}, P = (e) => {
		let n = x.players.find((t) => t.rid === e);
		return t.ranking.findIndex((e) => {
			let t = x.players.find((t) => t.rid === e);
			return t.vp === n.vp && t.incomeLevel === n.incomeLevel && t.money === n.money;
		}) + 1;
	}, F = D ? x.board[D] : void 0, I = F ? C(F.industry, F.level) : void 0;
	return /* @__PURE__ */ h("div", {
		className: "brass-game-over",
		children: [
			/* @__PURE__ */ h("div", {
				className: "brass-final-board",
				inert: T,
				children: [
					/* @__PURE__ */ m(Je, {
						pub: x,
						members: n,
						hot: { tiles: new Set(Object.keys(x.board)) },
						pickedTiles: D ? /* @__PURE__ */ new Set([D]) : void 0,
						onTapTile: O
					}),
					/* @__PURE__ */ h("select", {
						className: "brass-final-select",
						"aria-label": S("games.brass.tileDetails"),
						value: D ?? "",
						onChange: (e) => O(e.target.value || null),
						children: [/* @__PURE__ */ m("option", {
							value: "",
							children: S("games.brass.tileDetails")
						}), Object.entries(x.board).map(([e, t]) => /* @__PURE__ */ h("option", {
							value: e,
							children: [
								M(e),
								" · ",
								S(Be[t.industry]),
								" ",
								t.level,
								" · ",
								j(x.players[t.owner].rid)
							]
						}, e))]
					}),
					F && I && D && /* @__PURE__ */ h("aside", {
						className: "brass-final-detail",
						"aria-label": S("games.brass.tileDetails"),
						children: [
							/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ m("strong", { children: M(D) }), /* @__PURE__ */ m("button", {
								type: "button",
								"aria-label": S("common.qr.close"),
								onClick: () => O(null),
								children: /* @__PURE__ */ m(v, { size: 20 })
							})] }),
							/* @__PURE__ */ h("div", {
								className: "brass-final-tile",
								children: [/* @__PURE__ */ m(ze, { industry: F.industry }), /* @__PURE__ */ h("strong", { children: [
									S(Be[F.industry]),
									" · ",
									S("games.brass.tileLevel", { n: F.level })
								] })]
							}),
							/* @__PURE__ */ h("p", { children: [
								j(x.players[F.owner].rid),
								" · ",
								S(F.flipped ? "games.brass.tileFlipped" : "games.brass.tileUnflipped")
							] }),
							/* @__PURE__ */ h("p", { children: [
								S("games.brass.industryVp", { n: F.flipped ? I.vp : 0 }),
								" · ",
								S("games.brass.linkIcons", { n: F.flipped ? I.links : 0 })
							] }),
							F.cubes > 0 && /* @__PURE__ */ m("p", { children: S("games.brass.tileResources", { n: F.cubes }) })
						]
					})
				]
			}),
			/* @__PURE__ */ h("section", {
				className: "brass-result",
				hidden: !T,
				"aria-label": S("session.result.title"),
				children: [
					/* @__PURE__ */ h("header", {
						className: "brass-result-header",
						children: [/* @__PURE__ */ m("button", {
							ref: A,
							type: "button",
							className: "brass-final-button",
							"aria-label": S("games.brass.viewBoard"),
							title: S("games.brass.viewBoard"),
							onClick: () => N(!1),
							children: /* @__PURE__ */ m(y, { size: 18 })
						}), f !== void 0 && /* @__PURE__ */ m("span", { children: S("session.hint.usedCount", { n: f }) })]
					}),
					/* @__PURE__ */ m("ol", {
						className: "brass-result-list",
						children: t.ranking.map((e) => {
							let r = n.find((t) => t.rid === e), i = x.players.find((t) => t.rid === e), o = t.winner.includes(e);
							return /* @__PURE__ */ h("li", {
								className: `brass-result-player${o ? " brass-result-winner" : ""}`,
								children: [
									/* @__PURE__ */ h("div", {
										className: "brass-result-identity",
										children: [
											/* @__PURE__ */ m("span", {
												className: "brass-result-rank",
												children: P(e)
											}),
											r && /* @__PURE__ */ m("img", {
												src: a[r.avatar % a.length],
												alt: "",
												draggable: !1
											}),
											/* @__PURE__ */ h("strong", { children: [
												o && /* @__PURE__ */ m("span", {
													"aria-label": S("games.brass.winner"),
													children: "👑 "
												}),
												j(e),
												e === l && /* @__PURE__ */ m("small", { children: S("lobby.you") })
											] }),
											/* @__PURE__ */ m("b", {
												className: "brass-result-total",
												children: t.scores?.[e] ?? i.vp
											})
										]
									}),
									/* @__PURE__ */ m("dl", {
										className: "brass-result-eras",
										children: ["canal", "rail"].map((t) => {
											let n = x.eraScores?.find((n) => n.rid === e && n.era === t);
											return /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("dt", { children: S(t === "canal" ? "games.brass.eraCanal" : "games.brass.eraRail") }), /* @__PURE__ */ m("dd", { children: n ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("span", { children: S("games.brass.industryVp", { n: n.industryVp }) }), /* @__PURE__ */ m("span", { children: S("games.brass.linkVp", { n: n.linkVp }) })] }) : "—" })] }, t);
										})
									}),
									/* @__PURE__ */ h("div", {
										className: "brass-result-assets",
										children: [/* @__PURE__ */ m("span", { children: S("games.brass.incomeLabel", { n: i.incomeLevel }) }), /* @__PURE__ */ m("span", { children: S("games.brass.moneyLabel", { n: i.money }) })]
									}),
									t.autopilot?.[e] !== void 0 && t.autopilot[e] > 0 && /* @__PURE__ */ m("small", { children: S("session.autopilot.share", { n: Math.round(t.autopilot[e] * 100) }) })
								]
							}, e);
						})
					}),
					T && /* @__PURE__ */ h("footer", {
						className: "brass-result-actions",
						children: [
							u && /* @__PURE__ */ m(_, {
								className: "brass-final-button brass-final-primary",
								label: S("session.result.playAgain"),
								confirmLabel: S("games.brass.confirmAgain"),
								onConfirm: u
							}),
							d && /* @__PURE__ */ m(_, {
								className: "brass-final-button",
								label: S("session.result.backToLobby"),
								confirmLabel: S("games.brass.confirmBack"),
								onConfirm: d
							}),
							!u && !d && /* @__PURE__ */ m("p", { children: S("session.result.waitHost") })
						]
					})
				]
			}),
			!T && /* @__PURE__ */ h("button", {
				ref: k,
				type: "button",
				className: "brass-final-button brass-result-toggle",
				onClick: () => N(!0),
				children: [/* @__PURE__ */ m(b, { size: 18 }), S("games.brass.viewResults")]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/brass/entry.tsx
var At = {
	definition: Ie,
	View: Tt,
	bot: bt,
	describe: xt,
	OverView: kt,
	locales: {
		zh: {
			name: "伯明翰",
			desc: "工业革命英格兰:建厂、铺路、卖货,两个时代的经济博弈",
			rules: "目标:运河与铁路两个时代,翻面产业与连接在时代末计分,总分最高者胜。\n回合:每轮每人 2 个行动(运河时代首轮仅 1 个),每执行1个行动，须弃置1张手牌。\n六个行动:\n· 建造——弃置1张位置牌，在该城市建造任意产业，不要求该城市已接入自己的网络；也可以弃置1张产业牌，在自己网络内的城市建造对应产业。 取出自己该产业等级最低的板块，并支付所需金钱、煤炭和铁；存在只印有该产业图标的空槽时，必须使用该空槽。\n\n· 网络——运河时代支付£3，建造1条运河；铁路时代支付£5，建造1条铁路。 也可支付 £15 加 1 份啤酒建 2 条铁路(啤酒须来自酒厂);每条铁路消耗 1 份煤。\n\n· 研发——移除自己板上 1-2 块最低级板块,每块消耗 1 份铁;灯泡陶器不可研发。\n· 出售——翻面你的棉纺厂/制造商/陶器厂:须连通收购该产业的商人,消耗板块所示数量的啤酒。 一次出售行动可以出售多块产业板块;使用商人旁的啤酒还额外获得该商人的奖励。\n\n· 贷款——获得£30，并将收入等级降低3级。\n· 侦察——弃置3张手牌，获得2张百搭牌。\n资源:\n· 煤从最近的连通煤矿免费获取,煤矿没煤了才向市场购买(须连通商人)。\n· 铁从任意铁厂免费获取,铁厂没铁了才购买。\n· 啤酒可任意使用自家酒厂的,使用对手酒厂的啤酒须与其连通。\n时代:牌堆与手牌全空时时代结束;翻面产业和连接计分,运河时代末移除全部 1 级板块后进入铁路时代。\n回合末:本轮花费金钱最少的玩家，在下一轮首先行动;按照收入等级领取金钱(收入为负时要支付差额,钱不够就变卖板块)。",
			city: {
				belper: "贝尔珀",
				derby: "德比",
				leek: "利克",
				stokeOnTrent: "特伦特河畔斯托克",
				stone: "斯通",
				uttoxeter: "阿托克西特",
				stafford: "斯塔福德",
				burtonOnTrent: "特伦特河畔伯顿",
				cannock: "坎诺克",
				tamworth: "塔姆沃思",
				walsall: "沃尔索尔",
				wolverhampton: "伍尔弗汉普顿",
				coalbrookdale: "科尔布鲁克代尔",
				dudley: "达德利",
				kidderminster: "基德明斯特",
				worcester: "伍斯特",
				birmingham: "伯明翰",
				coventry: "考文垂",
				nuneaton: "纽尼顿",
				redditch: "雷迪奇",
				shrewsbury: "什鲁斯伯里",
				gloucester: "格洛斯特",
				oxford: "牛津",
				warrington: "沃灵顿",
				nottingham: "诺丁汉",
				farmN: "北农场",
				farmS: "南农场"
			},
			industry: {
				cotton: "棉纺厂",
				manufacturer: "制造商",
				pottery: "陶器厂",
				brewery: "啤酒厂",
				coal: "煤矿",
				iron: "铁厂"
			},
			action: {
				build: "建造",
				network: "网络",
				develop: "研发",
				sell: "出售",
				loan: "贷款",
				scout: "侦察",
				pass: "跳过"
			},
			errNotPlaying: "对局已结束",
			errNotYourTurn: "还没轮到你",
			errBadCard: "这张牌不能这么用",
			errNeedIndustry: "指定要建的产业",
			errFarmBrewery: "农场只能建啤酒厂(用啤酒产业牌或百搭产业牌)",
			errNotInNetwork: "目标不在你的网络内",
			errNoTile: "该产业的板块用完了",
			errEraLocked: "这个时代不能建这块板块",
			errBadOverbuild: "这里不能覆盖建造(需同产业更高等级;覆盖对手仅限煤/铁且该资源全图耗尽)",
			errBadSlot: "这个槽位不能建该产业",
			errSingleSlotFirst: "有只印该产业图标的空槽,必须优先放那里",
			errOnePerCity: "运河时代每城限建 1 块",
			errCantAfford: "钱不够",
			errNoCoal: "没有可用的煤(需连通煤矿或商人)",
			errBadLinks: "这条线不能建",
			errNeedBeer: "需要啤酒(双铁路须来自酒厂)",
			errBeerNotConnected: "对手的酒厂须连通第二条铁路",
			errLightbulb: "灯泡陶器不能被研发",
			errBadSell: "这块板块不能出售",
			errNoMerchant: "没有连通收购该产业的商人",
			errOneMerchant: "一次出售只能用一位商人的啤酒",
			errBonusDevelop: "免费研发数量与格洛斯特啤酒数不符",
			errLoanFloor: "收入不能再降了",
			errHasWild: "手上已有百搭,不能再侦察",
			errNoWild: "百搭牌已取完",
			errNoDebt: "你没有待偿还的缺口",
			errDebtPending: "先变卖板块偿还负收入",
			errOverpay: "够付即停,不能多卖",
			eraCanal: "运河时代",
			viewBoard: "查看版图",
			viewResults: "查看结算",
			tileDetails: "产业详情",
			tileLevel: "{{n}} 级",
			tileFlipped: "已翻面",
			tileUnflipped: "未翻面",
			tileResources: "剩余资源 {{n}}",
			linkIcons: "连接图标 {{n}}",
			winner: "获胜",
			confirmAgain: "确定再来一局",
			confirmBack: "确定返回房间",
			eraRail: "铁路时代",
			roundLabel: "第 {{n}} 轮",
			turnYou: "轮到你:还剩 {{n}} 个行动",
			turnWait: "等 {{name}} 行动…",
			deckLabel: "牌库 {{n}}",
			coalMarket: "煤市场",
			ironMarket: "铁市场",
			marketEmpty: "空",
			wildLabel: "百搭",
			handLabel: "手牌",
			yourMat: "你的玩家板",
			moneyLabel: "£{{n}}",
			incomeLabel: "收入 {{n}}",
			vpLabel: "{{n}} 分",
			linkStock: "连接 {{n}}",
			merchantBeer: "商人啤酒",
			merchantBlank: "不收购",
			merchantAny: "全收",
			bonusDevelop: "免费研发",
			bonusIncome: "收入+2",
			bonusVp: "+{{n}} 分",
			bonusMoney: "+£{{n}}",
			selectCard: "先选一张手牌",
			selectSlot: "选择槽位",
			selectLink: "选择线路",
			selectTile: "选择板块",
			selectIndustry: "选择产业",
			scoutPick: "选择 3 张牌换 2 张百搭",
			selectBeer: "选择啤酒来源",
			beerFromOwn: "自家酒厂",
			beerFromOpponent: "{{name}} 的酒厂",
			beerFromMerchant: "商人啤酒(得奖励)",
			confirm: "确认",
			cancel: "取消",
			actionsLeft: "剩 {{n}} 动",
			debtYou: "负收入缺口 £{{n}}:变卖板块偿还",
			debtWait: "等 {{name}} 变卖偿债…",
			payDebt: "变卖偿债",
			doubleRail: "双铁路(£15+1 啤酒)",
			sellMore: "继续出售",
			eraScoreTitle: "{{era}}计分",
			industryVp: "产业 {{n}}",
			linkVp: "连接 {{n}}",
			finalBreakdown: "得分明细",
			cardLocation: "位置牌",
			cardIndustry: "产业牌",
			cardDual: "棉纺/制造商",
			cardWildLocation: "百搭位置",
			cardWildIndustry: "百搭产业",
			you: "你",
			selectAction: "选择行动",
			candidateCities: "可选地点 {{n}}",
			marketPrices: "市场价格",
			marketStock: "库存 {{n}}",
			moreActions: "更多",
			loanEffect: "获得 £30，收入降 3 级",
			scoutEffect: "弃 3 张牌，换 2 张百搭",
			passEffect: "弃 1 张牌，跳过此行动",
			buildPreview: "建造费用与资源需求",
			mapLabel: "伯明翰工业地图，可拖动与缩放",
			zoomIn: "放大地图",
			zoomOut: "缩小地图",
			showFullMap: "全图"
		},
		en: {
			name: "Brass: Birmingham",
			desc: "Industrial revolution England: build, connect, and sell across two eras",
			rules: "Goal: across the Canal and Rail eras, flipped industries and links score at the end of each era; most VP wins.\nTurns: each round every player takes 2 actions (only 1 in the first Canal round); every action discards 1 card.\nThe six actions:\n· Build — discard a location card to build any industry in that city (no network needed), or an industry card to build in your network. Take your lowest-level tile of that industry and pay its cost in money and coal/iron; if a slot showing only that industry is free, you must use it.\n\n· Network — in the Canal Era, pay £3 to build 1 canal link. In the Rail Era, pay £5 to build 1 rail link, or pay £15 and consume 1 beer to build 2 rail links. This beer must come from a brewery, and each rail link also consumes 1 coal.\n\n· Develop — remove 1 or 2 of your lowest-level industry tiles, consuming 1 iron for each tile removed. Potteries marked with a lightbulb cannot be developed.\n· Sell — flip your Cotton Mills, Manufacturers and Potteries: each must connect to a merchant buying that industry and consume the beer shown. You may sell several tiles in one action; beer taken from beside a merchant also earns that merchant’s bonus.\n\n· Loan — take £30 and drop 3 income levels.\n· Scout — discard 3 cards for 2 wild cards.\nResources:\n· Coal is taken free from the closest connected mine; only when mines run out do you buy from the market (needs a merchant connection).\n· Iron is taken free from any iron works; only when they run out do you buy it.\n· Beer from your own breweries is used freely; opponents' breweries must be connected.\nEras: an era ends when the deck and all hands are empty; flipped industries and links score, and after the Canal Era all level 1 tiles are removed.\nEnd of round: whoever spent least goes first next round; collect income (when income is negative you must pay the difference — sell tiles if short).",
			city: {
				belper: "Belper",
				derby: "Derby",
				leek: "Leek",
				stokeOnTrent: "Stoke-on-Trent",
				stone: "Stone",
				uttoxeter: "Uttoxeter",
				stafford: "Stafford",
				burtonOnTrent: "Burton-on-Trent",
				cannock: "Cannock",
				tamworth: "Tamworth",
				walsall: "Walsall",
				wolverhampton: "Wolverhampton",
				coalbrookdale: "Coalbrookdale",
				dudley: "Dudley",
				kidderminster: "Kidderminster",
				worcester: "Worcester",
				birmingham: "Birmingham",
				coventry: "Coventry",
				nuneaton: "Nuneaton",
				redditch: "Redditch",
				shrewsbury: "Shrewsbury",
				gloucester: "Gloucester",
				oxford: "Oxford",
				warrington: "Warrington",
				nottingham: "Nottingham",
				farmN: "Farm (N)",
				farmS: "Farm (S)"
			},
			industry: {
				cotton: "Cotton Mill",
				manufacturer: "Manufacturer",
				pottery: "Pottery",
				brewery: "Brewery",
				coal: "Coal Mine",
				iron: "Iron Works"
			},
			action: {
				build: "Build",
				network: "Network",
				develop: "Develop",
				sell: "Sell",
				loan: "Loan",
				scout: "Scout",
				pass: "Pass"
			},
			errNotPlaying: "The game is over",
			errNotYourTurn: "Not your turn yet",
			errBadCard: "This card cannot be used for that",
			errNeedIndustry: "Choose which industry to build",
			errFarmBrewery: "Farms take breweries only (brewery industry or wild industry card)",
			errNotInNetwork: "Target is not in your network",
			errNoTile: "No tiles of that industry left",
			errEraLocked: "This tile cannot be built in this era",
			errBadOverbuild: "Cannot overbuild here (same industry, higher level; opponent tiles only coal/iron when that resource is exhausted)",
			errBadSlot: "This slot cannot hold that industry",
			errSingleSlotFirst: "A single-icon slot for this industry is free — you must use it",
			errOnePerCity: "Only 1 tile per city in the Canal Era",
			errCantAfford: "Not enough money",
			errNoCoal: "No coal available (needs a connected mine or merchant)",
			errBadLinks: "Cannot build a link here",
			errNeedBeer: "Beer required (double rail needs a brewery)",
			errBeerNotConnected: "Opponent's brewery must connect to the second rail link",
			errLightbulb: "Lightbulb Potteries cannot be developed",
			errBadSell: "This tile cannot be sold",
			errNoMerchant: "No connected merchant buys that industry",
			errOneMerchant: "One sale may use only one merchant's beer",
			errBonusDevelop: "Free develops must match Gloucester beers consumed",
			errLoanFloor: "Income cannot go lower",
			errHasWild: "Already holding a wild card",
			errNoWild: "No wild cards left",
			errNoDebt: "You have no shortfall to cover",
			errDebtPending: "Sell tiles to cover negative income first",
			errOverpay: "Stop as soon as the shortfall is covered",
			eraCanal: "Canal Era",
			viewBoard: "View board",
			viewResults: "View results",
			tileDetails: "Industry details",
			tileLevel: "Level {{n}}",
			tileFlipped: "Flipped",
			tileUnflipped: "Not flipped",
			tileResources: "Resources left: {{n}}",
			linkIcons: "Link icons {{n}}",
			winner: "Winner",
			confirmAgain: "Confirm new game",
			confirmBack: "Confirm return to lobby",
			eraRail: "Rail Era",
			roundLabel: "Round {{n}}",
			turnYou: "Your turn: {{n}} action(s) left",
			turnWait: "Waiting for {{name}}…",
			deckLabel: "Deck {{n}}",
			coalMarket: "Coal market",
			ironMarket: "Iron market",
			marketEmpty: "empty",
			wildLabel: "Wild",
			handLabel: "Hand",
			yourMat: "Your player mat",
			moneyLabel: "£{{n}}",
			incomeLabel: "Income {{n}}",
			vpLabel: "{{n}} VP",
			linkStock: "{{n}} links",
			merchantBeer: "Merchant beer",
			merchantBlank: "Buys nothing",
			merchantAny: "Buys all",
			bonusDevelop: "Free develop",
			bonusIncome: "Income +2",
			bonusVp: "+{{n}} VP",
			bonusMoney: "+£{{n}}",
			selectCard: "Pick a card first",
			selectSlot: "Pick a slot",
			selectLink: "Pick a link",
			selectTile: "Pick a tile",
			selectIndustry: "Pick an industry",
			scoutPick: "Pick 3 cards for 2 wilds",
			selectBeer: "Pick beer sources",
			beerFromOwn: "Your brewery",
			beerFromOpponent: "{{name}}'s brewery",
			beerFromMerchant: "Merchant beer (bonus)",
			confirm: "Confirm",
			cancel: "Cancel",
			actionsLeft: "{{n}} left",
			debtYou: "Negative income shortfall £{{n}}: sell tiles to cover it",
			debtWait: "Waiting for {{name}} to sell tiles…",
			payDebt: "Sell tiles",
			doubleRail: "Double rail (£15 + 1 beer)",
			sellMore: "Sell another",
			eraScoreTitle: "{{era}} scoring",
			industryVp: "Industry {{n}}",
			linkVp: "Links {{n}}",
			finalBreakdown: "Score breakdown",
			cardLocation: "Location",
			cardIndustry: "Industry",
			cardDual: "Cotton/Manufacturer",
			cardWildLocation: "Wild location",
			cardWildIndustry: "Wild industry",
			you: "You",
			selectAction: "Choose an action",
			candidateCities: "{{n}} places",
			marketPrices: "Market prices",
			marketStock: "{{n}} in stock",
			moreActions: "More",
			loanEffect: "Gain £30; drop 3 income levels",
			scoutEffect: "Discard 3 cards for 2 wilds",
			passEffect: "Discard 1 card and pass",
			buildPreview: "Build cost and resources",
			mapLabel: "Birmingham industrial map, drag or zoom to explore",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			showFullMap: "Full map"
		}
	}
};
//#endregion
export { At as default };
